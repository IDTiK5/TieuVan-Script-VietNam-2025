-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TokyoMapDraw

local v_u_1 = {}
local v_u_2 = {
	["paper"] = "D8CDB2",
	["paperLight"] = "E6DCC4",
	["paperEdge"] = "A99C7E",
	["crease"] = "BDB091",
	["grid"] = "C3B697",
	["ink"] = "372F26",
	["inkSoft"] = "6A5E4C",
	["field"] = "CFC598",
	["park"] = "B9BE92",
	["forest"] = "B4B98F",
	["tree"] = "7C8758",
	["water"] = "8DA4AE",
	["waterInk"] = "44606E",
	["bank"] = "BDC0A6",
	["lot"] = "C6BCA5",
	["road"] = "F0E8D4",
	["roadCase"] = "5D5345",
	["highway"] = "F2DFA9",
	["build"] = "8C806D",
	["buildEdge"] = "4A4136",
	["landmark"] = "9C4B39",
	["landmarkEdge"] = "5E2A1F",
	["red"] = "B0322A",
	["redDeep"] = "7E2019",
	["green"] = "3E6E4A",
	["granite"] = "CBC1AB",
	["graniteJoint"] = "B5AA92",
	["deckInk"] = "B79F78",
	["rail"] = "4A4136"
}
v_u_1.HEX = v_u_2
v_u_1.KEY = {
	{ "landmark", "Landmark" },
	{ "build", "Building" },
	{ "forest", "Gardens" },
	{ "water", "Water" },
	{ "road", "Road" }
}
local v_u_3 = {
	["ground"] = 2,
	["pads"] = 3,
	["case"] = 4,
	["fill"] = 5,
	["rails"] = 6,
	["builds"] = 7,
	["deck"] = 8,
	["props"] = 8,
	["labels"] = 9
}
local v_u_4 = {
	"ground",
	"pads",
	"case",
	"fill",
	"rails",
	"builds",
	"deck",
	"props",
	"labels"
}
v_u_1.LAYER_Z = v_u_3
v_u_1.LAYER_ORDER = v_u_4
local v_u_5 = nil
local v_u_6 = false
function v_u_1._setData(p7) -- name: _setData
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	v_u_5 = p7
	v_u_6 = true
end
function v_u_1.available() -- name: available
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	if v_u_5 == nil and not v_u_6 then
		v_u_6 = true
		local v9, v10 = pcall(function()
			local v8 = script
			return require(v8.Parent:WaitForChild("TokyoMapData", 5))
		end)
		if v9 and type(v10) == "table" then
			v_u_5 = v10
		end
	end
	local v11 = v_u_5
	local v12
	if v11 == nil then
		v12 = false
	else
		local v13 = v11.LOTS
		if type(v13) == "table" and #v11.LOTS > 0 then
			local v14 = v11.HALF
			v12 = type(v14) == "number"
		else
			v12 = false
		end
	end
	return v12
end
function v_u_1.data() -- name: data
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	if v_u_5 == nil and not v_u_6 then
		v_u_6 = true
		local v16, v17 = pcall(function()
			local v15 = script
			return require(v15.Parent:WaitForChild("TokyoMapData", 5))
		end)
		if v16 and type(v17) == "table" then
			v_u_5 = v17
		end
	end
	return v_u_5
end
function v_u_1.placeOf(p18) -- name: placeOf
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	if v_u_5 == nil and not v_u_6 then
		v_u_6 = true
		local v20, v21 = pcall(function()
			local v19 = script
			return require(v19.Parent:WaitForChild("TokyoMapData", 5))
		end)
		if v20 and type(v21) == "table" then
			v_u_5 = v21
		end
	end
	local v22 = v_u_5
	if v22 then
		local v23 = v22.PLACES
		if type(v23) == "table" and type(p18) == "string" then
			local v24 = v22.PLACES[string.lower(p18)]
			if type(v24) == "table" then
				return v24[1], v24[2], v24[3]
			else
				return nil, nil, nil
			end
		end
	end
	return nil, nil, nil
end
function v_u_1.gridRef(p25, p26) -- name: gridRef
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	if v_u_5 == nil and not v_u_6 then
		v_u_6 = true
		local v28, v29 = pcall(function()
			local v27 = script
			return require(v27.Parent:WaitForChild("TokyoMapData", 5))
		end)
		if v28 and type(v29) == "table" then
			v_u_5 = v29
		end
	end
	local v30 = v_u_5
	local v31 = not v30 and 800 or v30.HALF
	local v32 = not v30 and 200 or v30.CELL
	local v33 = not v30 and {
		"A",
		"B",
		"C",
		"D",
		"E",
		"F",
		"G",
		"H"
	} or v30.GRID_LETTERS
	local v34 = v31 * 2 / v32 + 0.5
	local v35 = math.floor(v34)
	local v36 = (p25 + v31) / v32
	local v37 = math.floor(v36) + 1
	local v38 = math.clamp(v37, 1, v35)
	local v39 = (p26 + v31) / v32
	local v40 = math.floor(v39) + 1
	local v41 = math.clamp(v40, 1, v35)
	return (v33[v38] or "?") .. tostring(v41)
end
local function v_u_49(p_u_42) -- name: codePoints
	local v_u_43 = {}
	local v_u_44 = utf8
	if v_u_44.codes then
		if pcall(function()
			-- upvalues: (copy) v_u_44, (copy) p_u_42, (copy) v_u_43
			for _, v45 in v_u_44.codes(p_u_42) do
				local v46 = v_u_43
				table.insert(v46, v45)
			end
		end) then
			return v_u_43
		end
		table.clear(v_u_43)
	end
	for v47 = 1, #p_u_42 do
		local v48 = string.byte
		table.insert(v_u_43, v48(p_u_42, v47))
	end
	return v_u_43
end
function v_u_1.textWidth(p50, p51) -- name: textWidth
	-- upvalues: (copy) v_u_49
	local v52 = 0
	for _, v53 in v_u_49(p50) do
		local v54
		if v53 >= 11904 then
			v54 = p51
		else
			v54 = p51 * 0.56
		end
		v52 = v52 + v54
	end
	return v52
end
function v_u_1.upper(p55) -- name: upper
	local v56 = string.upper(p55)
	return string.gsub(v56, utf8.char(333), utf8.char(332))
end
local function v_u_64(p57) -- name: spaced
	-- upvalues: (copy) v_u_49
	local v58 = utf8.char(8202)
	local v59 = v_u_49
	local v60 = string.upper(p57)
	local v61 = {}
	for _, v62 in v59((string.gsub(v60, utf8.char(333), utf8.char(332)))) do
		local v63 = utf8.char
		table.insert(v61, v63(v62))
	end
	return table.concat(v61, v58)
end
v_u_1.spaced = v_u_64
function v_u_1.plan(p_u_65, p66, p67) -- name: plan
	-- upvalues: (copy) v_u_49, (copy) v_u_64, (copy) v_u_1
	local v68 = p67 or {}
	local v_u_70 = v68.lift or function(p69, _)
		return p69
	end
	local v71 = v68.isPhone == true
	local v_u_72 = p_u_65.HALF
	local v73 = p66 * 0.035
	local v74 = math.floor(v73)
	local v_u_75 = p66 - v74 * 2
	local v_u_76 = v_u_75 / (v_u_72 * 2)
	local v77 = p66 / 880
	local v_u_78 = {}
	local function v104(p79, p80, p81, p82, p83, p84, p85, p86, p87) -- name: rect
		-- upvalues: (copy) v_u_72, (copy) v_u_76, (copy) v_u_78
		local v88 = math.min(p80, p82)
		local v89 = math.min(p81, p83)
		local v90 = (v88 + v_u_72) * v_u_76
		local v91 = (v89 + v_u_72) * v_u_76
		local v92 = math.max(p80, p82)
		local v93 = math.max(p81, p83)
		local v94 = (v92 + v_u_72) * v_u_76
		local v95 = (v93 + v_u_72) * v_u_76
		local v96 = p87 or 1
		local v97 = {
			["t"] = "rect",
			["L"] = nil,
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["c"] = nil,
			["a"] = nil,
			["L"] = p79,
			["x"] = math.floor(v90),
			["y"] = math.floor(v91)
		}
		local v98 = v94 - v90
		local v99 = math.ceil(v98)
		v97.w = math.max(v96, v99)
		local v100 = v95 - v91
		local v101 = math.ceil(v100)
		v97.h = math.max(v96, v101)
		v97.c = p84
		v97.a = p85 or 0
		if p86 then
			for v102, v103 in p86 do
				v97[v102] = v103
			end
		end
		v_u_78[#v_u_78 + 1] = v97
		return v97
	end
	local v105 = p_u_65.FIELD
	v104("ground", v105[1], v105[2], v105[3], v105[4], "field", 0.55, {
		["name"] = "Field"
	})
	local function v127(p106, p107, p108, p109, p110, p111, p112, p113, p114, p115) -- name: dashed
		-- upvalues: (copy) v_u_78
		local v116 = p109 - p107
		local v117 = p110 - p108
		local v118 = v116 * v116 + v117 * v117
		local v119 = math.sqrt(v118)
		if v119 >= 1 then
			local v120 = v116 / v119
			local v121 = v117 / v119
			local v122 = 0
			local v123 = 0
			while v122 < v119 and v123 < 400 do
				v123 = v123 + 1
				local v124 = v122 + p111
				local v125 = math.min(v119, v124)
				if v125 - v122 > 1 then
					local v126 = {
						["t"] = "seg",
						["L"] = nil,
						["x0"] = nil,
						["y0"] = nil,
						["x1"] = nil,
						["y1"] = nil,
						["th"] = nil,
						["c"] = nil,
						["a"] = nil,
						["L"] = p106,
						["x0"] = p107 + v120 * v122,
						["y0"] = p108 + v121 * v122,
						["x1"] = p107 + v120 * v125,
						["y1"] = p108 + v121 * v125,
						["th"] = p113,
						["c"] = p114,
						["a"] = p115 or 0
					}
					v_u_78[#v_u_78 + 1] = v126
				end
				v122 = v125 + p112
			end
		end
	end
	local v_u_128 = 0
	local function v131(p129, p130) -- name: px
		-- upvalues: (copy) v_u_72, (copy) v_u_76
		return (p129 + v_u_72) * v_u_76, (p130 + v_u_72) * v_u_76
	end
	for _, v132 in p_u_65.WATERS do
		v104("ground", v132[3], v132[4], v132[5], v132[6], "water", 0, {
			["name"] = "Water_" .. v132[1]
		}).id = v132[1]
		if v132[7] == "harbor" then
			v104("ground", v132[3], v132[6], v132[5], v132[6] + 1.2 / v_u_76, "waterInk", 0.35, {
				["name"] = "Shore"
			})
			local v133 = v132[4] + 14
			local v134 = 0
			while v133 < v132[6] - 4 do
				local v135 = v134 % 2 == 0 and 0 or 55
				local v136 = v132[3] + 14 + v135
				while v136 < v132[5] - 30 do
					local v137 = (v136 + v_u_72) * v_u_76
					local v138 = (v133 + v_u_72) * v_u_76
					local v139 = (v136 + 22 + v_u_72) * v_u_76
					local v140 = (v133 + v_u_72) * v_u_76
					local v141 = v77 * 1.2 + 0.5
					local v142 = math.floor(v141)
					local v143 = {
						["t"] = "seg",
						["L"] = "ground",
						["x0"] = nil,
						["y0"] = nil,
						["x1"] = nil,
						["y1"] = nil,
						["th"] = nil,
						["c"] = "waterInk",
						["a"] = 0.55,
						["x0"] = v137,
						["y0"] = v138,
						["x1"] = v139,
						["y1"] = v140,
						["th"] = math.max(1, v142)
					}
					v_u_78[#v_u_78 + 1] = v143
					v136 = v136 + 110
				end
				v133 = v133 + 22
				v134 = v134 + 1
			end
		else
			v104("ground", v132[3], v132[4], v132[5], v132[4] + 1.2 / v_u_76, "waterInk", 0.35, {
				["name"] = "Shore"
			})
			v104("ground", v132[3], v132[6] - 1.2 / v_u_76, v132[5], v132[6], "waterInk", 0.35, {
				["name"] = "Shore"
			})
		end
	end
	local v144 = v_u_72 * 2 / p_u_65.CELL + 0.5
	local v145 = math.floor(v144)
	for v146 = 1, v145 - 1 do
		local v147 = v146 * v_u_75 / v145
		local v148 = math.floor(v147)
		v_u_78[#v_u_78 + 1] = {
			["t"] = "rect",
			["L"] = "ground",
			["x"] = nil,
			["y"] = 0,
			["w"] = 1,
			["h"] = nil,
			["c"] = "grid",
			["a"] = 0.3,
			["name"] = "Grid",
			["x"] = v148,
			["h"] = v_u_75
		}
		v_u_78[#v_u_78 + 1] = {
			["t"] = "rect",
			["L"] = "ground",
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 1,
			["c"] = "grid",
			["a"] = 0.3,
			["name"] = "Grid",
			["y"] = v148,
			["w"] = v_u_75
		}
	end
	local v149 = 0
	for _, v150 in p_u_65.OPEN do
		local v151 = v150[2]
		local v152 = "lot"
		local v153 = 0.2
		if v151 == "promenade" then
			v152 = "bank"
			v153 = 0.15
		elseif v151 == "quay" or v151 == "plaza" then
			v152 = "granite"
			v153 = 0
		elseif v151 == "yard" then
			v152 = "lot"
			v153 = 0.45
		elseif v151 == "garden" then
			v152 = "forest"
			v153 = 0.05
		end
		v104("pads", v150[3], v150[4], v150[5], v150[6], v152, v153, {
			["name"] = "Open_" .. v150[1]
		}).id = v150[1]
		if v151 == "plaza" then
			local v154 = v150[3] + 40
			while v154 < v150[5] do
				v104("pads", v154, v150[4], v154 + 0.5 / v_u_76, v150[6], "graniteJoint", 0.55, {
					["name"] = "Joint"
				})
				v154 = v154 + 40
			end
			local v155 = v150[4] + 40
			while v155 < v150[6] do
				v104("pads", v150[3], v155, v150[5], v155 + 0.5 / v_u_76, "graniteJoint", 0.55, {
					["name"] = "Joint"
				})
				v155 = v155 + 40
			end
		else
			if v151 ~= "garden" then
				continue
			end
			local v156 = v150[3] + 14
			local v157 = 0
			while v156 < v150[5] - 6 do
				local v158 = v150[4] + 12
				local v159 = 0
				while v158 < v150[6] - 6 do
					local v160 = v150[1] .. tostring(v157) .. "_" .. tostring(v159)
					local v161 = 0
					for v162 = 1, #v160 do
						v161 = (v161 * 31 + string.byte(v160, v162)) % 65521
					end
					local v163 = v156 + (v161 % 11 - 5)
					local v164 = v158 + (v161 // 11 % 11 - 5)
					local v165 = (v163 + v_u_72) * v_u_76
					local v166 = (v164 + v_u_72) * v_u_76
					local v167 = (v161 % 5 + 9) * v_u_76
					local v168 = {
						["t"] = "dot",
						["L"] = "pads",
						["x"] = nil,
						["y"] = nil,
						["d"] = nil,
						["c"] = "tree",
						["a"] = 0.18,
						["st"] = nil,
						["x"] = v165,
						["y"] = v166,
						["d"] = math.max(3, v167)
					}
					v_u_78[#v_u_78 + 1] = v168
					v149 = v149 + 1
					v158 = v158 + 26
					v159 = v159 + 1
				end
				v156 = v156 + 26
				v157 = v157 + 1
			end
		end
	end
	local v169 = v77 * 1.6 + 0.5
	local v170 = math.floor(v169)
	local v171 = math.max(1, v170)
	for _, v172 in p_u_65.ROADS do
		local v173 = v172[1]
		local v174 = v172[2]
		local v175 = (v173 + v_u_72) * v_u_76
		local v176 = (v174 + v_u_72) * v_u_76
		local v177 = v172[3]
		local v178 = v172[4]
		local v179 = (v177 + v_u_72) * v_u_76
		local v180 = (v178 + v_u_72) * v_u_76
		local v181 = v172[6]
		local v182 = v181 == "service" and 0.35 or (v181 == "walk" and 0.5 or (v181 == "street" and 0.1 or 0))
		local v183 = v181 == "main" and "highway" or (v181 == "walk" and "paperLight" or "road")
		local v184 = {
			["t"] = "rect",
			["L"] = "case",
			["name"] = "Case",
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["c"] = "roadCase",
			["a"] = nil,
			["road"] = nil,
			["x"] = math.floor(v175) - v171,
			["y"] = math.floor(v176) - v171
		}
		local v185 = v179 - v175
		v184.w = math.ceil(v185) + v171 * 2
		local v186 = v180 - v176
		v184.h = math.ceil(v186) + v171 * 2
		v184.a = v182
		v184.road = v172[5]
		v_u_78[#v_u_78 + 1] = v184
		local v187 = {
			["t"] = "rect",
			["L"] = "fill",
			["name"] = "Road",
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["c"] = nil,
			["a"] = 0,
			["road"] = nil,
			["x"] = math.floor(v175),
			["y"] = math.floor(v176)
		}
		local v188 = v179 - v175
		local v189 = math.ceil(v188)
		v187.w = math.max(1, v189)
		local v190 = v180 - v176
		local v191 = math.ceil(v190)
		v187.h = math.max(1, v191)
		v187.c = v183
		v187.road = v172[5]
		v_u_78[#v_u_78 + 1] = v187
		if v172[9] ~= 1 then
			continue
		end
		local v192 = (v175 + v179) / 2
		local v193 = (v176 + v180) / 2
		if v172[7] == "x" then
			v127("fill", v175, v193, v179, v193, 6, 5, 1, "inkSoft", 0.5)
		else
			v127("fill", v192, v176, v192, v180, 6, 5, 1, "inkSoft", 0.5)
		end
	end
	local v194 = p_u_65.RAIL_RAMP
	v104("rails", v194[1], v194[2], v194[3], v194[4], "lot", 0.35, {
		["name"] = "RailRamp"
	})
	for _, v195 in { v194[1], v194[3] } do
		local v196 = v194[2]
		local v197 = (v195 + v_u_72) * v_u_76
		local v198 = (v196 + v_u_72) * v_u_76
		local v199 = v194[4]
		local _ = (v195 + v_u_72) * v_u_76
		local v200 = {
			["t"] = "seg",
			["L"] = "rails",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = 1,
			["c"] = "buildEdge",
			["a"] = 0.5,
			["x0"] = v197,
			["y0"] = v198,
			["x1"] = v197,
			["y1"] = (v199 + v_u_72) * v_u_76
		}
		v_u_78[#v_u_78 + 1] = v200
	end
	local v201 = p_u_65.VIADUCT
	v104("rails", v201[1], v201[2], v201[3], v201[4], "lot", 0, {
		["name"] = "Viaduct"
	})
	for _, v202 in { v201[1], v201[3] } do
		local v203 = v201[2]
		local v204 = (v202 + v_u_72) * v_u_76
		local v205 = (v203 + v_u_72) * v_u_76
		local v206 = v201[4]
		local _ = (v202 + v_u_72) * v_u_76
		local v207 = {
			["t"] = "seg",
			["L"] = "rails",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = 1,
			["c"] = "buildEdge",
			["a"] = 0.3,
			["x0"] = v204,
			["y0"] = v205,
			["x1"] = v204,
			["y1"] = (v206 + v_u_72) * v_u_76
		}
		v_u_78[#v_u_78 + 1] = v207
	end
	local v208 = v201[2] + 20
	while v208 < v201[4] do
		local v209 = (v201[1] + v_u_72) * v_u_76
		local v210 = (v208 + v_u_72) * v_u_76
		local v211 = (v201[3] + v_u_72) * v_u_76
		local _ = (v208 + v_u_72) * v_u_76
		v_u_78[#v_u_78 + 1] = {
			["t"] = "seg",
			["L"] = "rails",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = 1,
			["c"] = "buildEdge",
			["a"] = 0.55,
			["x0"] = v209,
			["y0"] = v210,
			["x1"] = v211,
			["y1"] = v210
		}
		v208 = v208 + 20
	end
	local v212 = v77 * 1.3 + 0.5
	local v213 = math.floor(v212)
	local v214 = math.max(1, v213)
	for _, v215 in p_u_65.TRACKS do
		local v216 = v215[2]
		for v217 = 1, #v216 - 2, 2 do
			local v218 = v216[v217]
			local v219 = v216[v217 + 1]
			local v220 = (v218 + v_u_72) * v_u_76
			local v221 = (v219 + v_u_72) * v_u_76
			local v222 = v216[v217 + 2]
			local v223 = v216[v217 + 3]
			local v224 = {
				["t"] = "seg",
				["L"] = "rails",
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = nil,
				["y1"] = nil,
				["th"] = nil,
				["c"] = "rail",
				["a"] = 0.05,
				["x0"] = v220,
				["y0"] = v221,
				["x1"] = (v222 + v_u_72) * v_u_76,
				["y1"] = (v223 + v_u_72) * v_u_76,
				["th"] = v214
			}
			v_u_78[#v_u_78 + 1] = v224
			if v216[v217] ~= v216[v217 + 2] then
				continue
			end
			local v225 = v216[v217 + 1]
			local v226 = v216[v217 + 3]
			local v227 = math.min(v225, v226) + 6
			local v228 = v216[v217 + 1]
			local v229 = v216[v217 + 3]
			local v230 = math.max(v228, v229)
			local v231 = v216[v217]
			while v227 < v230 do
				local v232 = (v231 - 3.4 + v_u_72) * v_u_76
				local v233 = (v227 + v_u_72) * v_u_76
				local v234 = (v231 + 3.4 + v_u_72) * v_u_76
				local _ = (v227 + v_u_72) * v_u_76
				v_u_78[#v_u_78 + 1] = {
					["t"] = "seg",
					["L"] = "rails",
					["x0"] = nil,
					["y0"] = nil,
					["x1"] = nil,
					["y1"] = nil,
					["th"] = 1,
					["c"] = "rail",
					["a"] = 0.4,
					["x0"] = v232,
					["y0"] = v233,
					["x1"] = v234,
					["y1"] = v233
				}
				v227 = v227 + 24
			end
		end
	end
	local v235 = p_u_65.PLATFORM
	v104("rails", v235[1], v235[2], v235[3], v235[4], "paperLight", 0, {
		["name"] = "Platform",
		["st"] = nil,
		["st"] = {
			["c"] = "inkSoft",
			["th"] = 1,
			["a"] = 0.35
		}
	})
	local v236 = p_u_65.CONCOURSE
	v104("rails", v236[1], v236[2], v236[3], v236[4], "paperLight", 0.3, {
		["name"] = "Concourse"
	})
	for _, v237 in p_u_65.TRAINS do
		v104("rails", v237[1], v237[2], v237[3], v237[4], "build", 0.25, {
			["name"] = "Train"
		})
	end
	for _, v238 in p_u_65.CROSSINGS do
		local v239 = v238[2]
		local v240 = v238[3]
		local v241 = (v239 + v_u_72) * v_u_76
		local v242 = (v240 + v_u_72) * v_u_76
		local v243 = v77 * 6
		local v244 = math.max(3, v243)
		local v245 = v241 - v244
		local v246 = v242 - v244
		local v247 = v241 + v244
		local v248 = v242 + v244
		local v249 = v77 * 1.5 + 0.5
		local v250 = math.floor(v249)
		local v251 = {
			["t"] = "seg",
			["L"] = "rails",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = nil,
			["c"] = "ink",
			["a"] = 0.05,
			["x0"] = v245,
			["y0"] = v246,
			["x1"] = v247,
			["y1"] = v248,
			["th"] = math.max(1, v250)
		}
		v_u_78[#v_u_78 + 1] = v251
		local v252 = v241 - v244
		local v253 = v242 + v244
		local v254 = v241 + v244
		local v255 = v242 - v244
		local v256 = v77 * 1.5 + 0.5
		local v257 = math.floor(v256)
		local v258 = {
			["t"] = "seg",
			["L"] = "rails",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = nil,
			["c"] = "ink",
			["a"] = 0.05,
			["x0"] = v252,
			["y0"] = v253,
			["x1"] = v254,
			["y1"] = v255,
			["th"] = math.max(1, v257)
		}
		v_u_78[#v_u_78 + 1] = v258
	end
	local v259 = 0
	local v260 = {}
	local v261 = {}
	local v_u_262 = {}
	for _, v263 in p_u_65.LOTS do
		v259 = v259 + 1
		local v264 = v263[1]
		local v265 = v263[4]
		local v266 = v263[5]
		local v267 = v263[6]
		local v268 = v263[7]
		local v269 = p_u_65.LANDMARKS[v264]
		local v270 = v269 ~= nil
		local v271 = v263[11] == 1
		local v272 = "lot"
		local v273
		if v270 then
			v273 = {
				["name"] = "B_" .. v264,
				["st"] = {
					["c"] = "landmarkEdge",
					["th"] = 1,
					["a"] = 0.1
				}
			}
			v272 = "landmark"
		elseif v271 then
			v273 = {
				["name"] = "B_" .. v264,
				["st"] = {
					["c"] = "buildEdge",
					["th"] = 1,
					["a"] = 0.15
				}
			}
			v272 = "build"
		else
			v273 = {
				["name"] = nil,
				["border"] = "paperEdge",
				["name"] = "B_" .. v264
			}
		end
		v104("builds", v265 - v267 / 2, v266 - v268 / 2, v265 + v267 / 2, v266 + v268 / 2, v272, 0, v273, 2).id = v264
		v260[string.lower(v264)] = { v265, v266, v269 or (p_u_65.NAMES[v264] or (v263[9] == "" and "Building" or v263[9])) }
		local v274 = (v265 + v_u_72) * v_u_76
		local v275 = (v266 + v_u_72) * v_u_76
		local v276 = {
			v274 - v267 * v_u_76 / 2 - 1,
			v275 - v268 * v_u_76 / 2 - 1,
			v274 + v267 * v_u_76 / 2 + 1,
			v275 + v268 * v_u_76 / 2 + 1
		}
		table.insert(v_u_262, v276)
		if not v270 then
			continue
		end
		local v277 = {
			["text"] = v269,
			["id"] = v264,
			["x"] = v274,
			["y"] = v275,
			["wpx"] = v267 * v_u_76,
			["hpx"] = v268 * v_u_76,
			["area"] = v264 == "hoshimi_building" and 500000000 or v267 * v268
		}
		table.insert(v261, v277)
	end
	local v278 = p_u_65.DECK
	v104("deck", v278[1], v278[2], v278[3], v278[4], "highway", 0.12, {
		["name"] = "Deck"
	})
	local v279 = v77 * 1.5 + 0.5
	local v280 = math.floor(v279)
	local v281 = math.max(1, v280)
	for _, v282 in { v278[2], v278[4] } do
		local v283 = (v278[1] + v_u_72) * v_u_76
		local v284 = (v282 + v_u_72) * v_u_76
		local v285 = (v278[3] + v_u_72) * v_u_76
		local _ = (v282 + v_u_72) * v_u_76
		v_u_78[#v_u_78 + 1] = {
			["t"] = "seg",
			["L"] = "deck",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = nil,
			["c"] = "roadCase",
			["a"] = 0,
			["x0"] = v283,
			["y0"] = v284,
			["x1"] = v285,
			["y1"] = v284,
			["th"] = v281
		}
	end
	local v286 = v278[1]
	local v287 = (v278[2] + v278[4]) / 2
	local v288 = (v286 + v_u_72) * v_u_76
	local v289 = (v287 + v_u_72) * v_u_76
	local v290 = v278[3]
	local v291 = (v278[2] + v278[4]) / 2
	local v292 = (v290 + v_u_72) * v_u_76
	local _ = (v291 + v_u_72) * v_u_76
	v127("deck", v288, v289, v292, v289, 7, 6, 1, "ink", 0.45)
	for _, v293 in p_u_65.SPANS do
		v104("deck", v293[2], v278[2], v293[3], v278[4], "paperLight", 0.5, {
			["name"] = "Span_" .. v293[1]
		}).id = v293[1]
		for _, v294 in { v293[2], v293[3] } do
			local v295 = v278[2]
			local v296 = (v294 + v_u_72) * v_u_76
			local v297 = (v295 + v_u_72) * v_u_76
			local v298 = v278[4]
			local _ = (v294 + v_u_72) * v_u_76
			local v299 = {
				["t"] = "seg",
				["L"] = "deck",
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = nil,
				["y1"] = nil,
				["th"] = 1,
				["c"] = "ink",
				["a"] = 0.2,
				["x0"] = v296,
				["y0"] = v297,
				["x1"] = v296,
				["y1"] = (v298 + v_u_72) * v_u_76
			}
			v_u_78[#v_u_78 + 1] = v299
		end
	end
	for _, v300 in p_u_65.RAMPS do
		v104("deck", v300[3], v300[4], v300[5], v300[6], "highway", 0, {
			["name"] = "Ramp_" .. v300[1],
			["st"] = {
				["c"] = "roadCase",
				["th"] = 1,
				["a"] = 0.1
			}
		}).id = v300[1]
		local v301 = (v300[4] + v300[6]) / 2
		local v302 = v300[8] < v300[7] and -1 or 1
		for v303 = 1, 3 do
			local v304 = (v300[7] + (v300[8] - v300[7]) * (v303 / 4) + v_u_72) * v_u_76
			local v305 = (v301 + v_u_72) * v_u_76
			local v306 = v77 * 3 * v302
			local v307 = v77 * 3
			local v308 = {
				["t"] = "seg",
				["L"] = "deck",
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = nil,
				["y1"] = nil,
				["th"] = 1,
				["c"] = "roadCase",
				["a"] = 0.1,
				["x0"] = v304 - v306,
				["y0"] = v305 - v307,
				["x1"] = v304 + v306,
				["y1"] = v305
			}
			v_u_78[#v_u_78 + 1] = v308
			local v309 = {
				["t"] = "seg",
				["L"] = "deck",
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = nil,
				["y1"] = nil,
				["th"] = 1,
				["c"] = "roadCase",
				["a"] = 0.1,
				["x0"] = v304 - v306,
				["y0"] = v305 + v307,
				["x1"] = v304 + v306,
				["y1"] = v305
			}
			v_u_78[#v_u_78 + 1] = v309
		end
		local v310 = v300[7]
		local v311 = v300[4]
		local v312 = (v310 + v_u_72) * v_u_76
		local v313 = (v311 + v_u_72) * v_u_76
		local v314 = v300[7]
		local v315 = v300[6]
		local _ = (v314 + v_u_72) * v_u_76
		local v316 = {
			["t"] = "seg",
			["L"] = "deck",
			["x0"] = nil,
			["y0"] = nil,
			["x1"] = nil,
			["y1"] = nil,
			["th"] = 2,
			["c"] = "roadCase",
			["a"] = 0.1,
			["x0"] = v312,
			["y0"] = v313,
			["x1"] = v312,
			["y1"] = (v315 + v_u_72) * v_u_76
		}
		v_u_78[#v_u_78 + 1] = v316
	end
	for _, v317 in p_u_65.STAIRS do
		v104("deck", v317[2], v317[3], v317[4], v317[5], "roadCase", 0.25, {
			["name"] = "Stair_" .. v317[1]
		}).id = v317[1]
		local v318 = v317[2] + 5
		while v318 < v317[4] do
			local v319 = v317[3]
			local v320 = (v318 + v_u_72) * v_u_76
			local v321 = (v319 + v_u_72) * v_u_76
			local v322 = v317[5]
			local _ = (v318 + v_u_72) * v_u_76
			local v323 = (v322 + v_u_72) * v_u_76
			local v324 = {
				["t"] = "seg",
				["L"] = "deck",
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = nil,
				["y1"] = nil,
				["th"] = 1,
				["c"] = "ink",
				["a"] = 0.35,
				["x0"] = v320,
				["y0"] = v321 - 1,
				["x1"] = v320,
				["y1"] = v323 + 1
			}
			v_u_78[#v_u_78 + 1] = v324
			v318 = v318 + 6
		end
	end
	local v325 = p_u_65.TOLL
	v104("deck", v325[1], v278[2], v325[2], v278[4], "paperLight", 0.55, {
		["name"] = "TollPlaza"
	})
	for _, v326 in p_u_65.TOLL_ISLANDS do
		v104("deck", v326[1], v326[2], v326[3], v326[4], "build", 0.15, {
			["name"] = "TollIsland"
		}, 2)
	end
	local v327 = v325[3]
	local v328 = v278[2]
	local v329 = (v327 + v_u_72) * v_u_76
	local v330 = (v328 + v_u_72) * v_u_76
	local v331 = v325[3]
	local v332 = v278[4]
	local _ = (v331 + v_u_72) * v_u_76
	local v333 = (v332 + v_u_72) * v_u_76
	local v334 = v77 * 2.5 + 0.5
	local v335 = math.floor(v334)
	local v336 = math.max(1, v335)
	local v337 = {
		["t"] = "seg",
		["L"] = "deck",
		["x0"] = nil,
		["y0"] = nil,
		["x1"] = nil,
		["y1"] = nil,
		["th"] = nil,
		["c"] = "redDeep",
		["a"] = 0,
		["x0"] = v329,
		["y0"] = v330,
		["x1"] = v329,
		["y1"] = v333,
		["th"] = math.max(2, v336)
	}
	v_u_78[#v_u_78 + 1] = v337
	for _, v338 in { v330, v333 } do
		local v339 = v77 * 4
		local v340 = {
			["t"] = "dot",
			["L"] = "deck",
			["x"] = nil,
			["y"] = nil,
			["d"] = nil,
			["c"] = "ink",
			["a"] = 0,
			["st"] = nil,
			["x"] = v329,
			["y"] = v338,
			["d"] = math.max(3, v339)
		}
		v_u_78[#v_u_78 + 1] = v340
	end
	local v341 = p_u_65.CLUB
	local v342 = v341.rooms
	local v343 = v342[1]
	local v344 = v342[2]
	local v345 = (v343 + v_u_72) * v_u_76
	local v346 = (v344 + v_u_72) * v_u_76
	local v347 = v342[3]
	local v348 = v342[4]
	local v349 = (v347 + v_u_72) * v_u_76
	local v350 = (v348 + v_u_72) * v_u_76
	local v351 = v77 * 5
	local v352 = math.max(4, v351)
	local v353 = v77 * 4
	local v354 = math.max(3, v353)
	local v355 = v77 * 1.2 + 0.5
	local v356 = math.floor(v355)
	local v357 = math.max(1, v356)
	v127("props", v345, v346, v349, v346, v352, v354, v357, "ink", 0.15)
	v127("props", v349, v346, v349, v350, v352, v354, v357, "ink", 0.15)
	v127("props", v349, v350, v345, v350, v352, v354, v357, "ink", 0.15)
	v127("props", v345, v350, v345, v346, v352, v354, v357, "ink", 0.15)
	for _, v358 in v341.cores do
		local v359 = v104("props", v358[1], v358[2], v358[3], v358[4], "paperLight", 0.15, {
			["name"] = "ClubStair",
			["st"] = nil,
			["st"] = {
				["c"] = "ink",
				["th"] = 1,
				["a"] = 0.2
			}
		}, 3)
		local v360 = v358[4] - v358[2] >= v358[3] - v358[1]
		for v361 = 1, 5 do
			if v360 then
				local v362 = v358[2] + (v358[4] - v358[2]) * (v361 / 6)
				local v363 = (v358[1] + v_u_72) * v_u_76
				local v364 = (v362 + v_u_72) * v_u_76
				local v365 = (v358[3] + v_u_72) * v_u_76
				local _ = (v362 + v_u_72) * v_u_76
				v_u_78[#v_u_78 + 1] = {
					["t"] = "seg",
					["L"] = "props",
					["x0"] = nil,
					["y0"] = nil,
					["x1"] = nil,
					["y1"] = nil,
					["th"] = 1,
					["c"] = "ink",
					["a"] = 0.35,
					["x0"] = v363,
					["y0"] = v364,
					["x1"] = v365,
					["y1"] = v364
				}
			else
				local v366 = v358[1] + (v358[3] - v358[1]) * (v361 / 6)
				local v367 = v358[2]
				local v368 = (v366 + v_u_72) * v_u_76
				local v369 = (v367 + v_u_72) * v_u_76
				local v370 = v358[4]
				local _ = (v366 + v_u_72) * v_u_76
				local v371 = {
					["t"] = "seg",
					["L"] = "props",
					["x0"] = nil,
					["y0"] = nil,
					["x1"] = nil,
					["y1"] = nil,
					["th"] = 1,
					["c"] = "ink",
					["a"] = 0.35,
					["x0"] = v368,
					["y0"] = v369,
					["x1"] = v368,
					["y1"] = (v370 + v_u_72) * v_u_76
				}
				v_u_78[#v_u_78 + 1] = v371
			end
		end
		v359.id = "club_stair"
	end
	local v372 = v341.forecourt
	local v373 = v341.lobby
	v104("props", v372[1], v372[2], v372[3], v372[4], "paperLight", 0, {
		["name"] = "ClubForecourt",
		["st"] = nil,
		["st"] = {
			["c"] = "ink",
			["th"] = 1,
			["a"] = 0.2
		}
	}, 3)
	v104("props", v373[1], v373[2], v373[3], v373[4], "paperLight", 0.1, {
		["name"] = "ClubLobby",
		["st"] = nil,
		["st"] = {
			["c"] = "ink",
			["th"] = 1,
			["a"] = 0.2
		}
	}, 3)
	local v374 = v341.entrance[1]
	local v375 = v341.entrance[2]
	local v376 = (v374 + v_u_72) * v_u_76
	local v377 = (v375 + v_u_72) * v_u_76
	local v378 = v77 * 5
	local v379 = {
		["t"] = "dot",
		["L"] = "props",
		["x"] = nil,
		["y"] = nil,
		["d"] = nil,
		["c"] = "ink",
		["a"] = 0,
		["st"] = nil,
		["x"] = v376,
		["y"] = v377,
		["d"] = math.max(4, v378),
		["st"] = {
			["c"] = "paperLight",
			["th"] = 1,
			["a"] = 0
		}
	}
	v_u_78[#v_u_78 + 1] = v379
	local v380 = v341.exit[1]
	local v381 = v341.exit[2]
	local v382 = (v380 + v_u_72) * v_u_76
	local v383 = (v381 + v_u_72) * v_u_76
	local v384 = v77 * 5
	local v385 = {
		["t"] = "dot",
		["L"] = "props",
		["x"] = nil,
		["y"] = nil,
		["d"] = nil,
		["c"] = "redDeep",
		["a"] = 0,
		["st"] = nil,
		["x"] = v382,
		["y"] = v383,
		["d"] = math.max(4, v384),
		["st"] = {
			["c"] = "paperLight",
			["th"] = 1,
			["a"] = 0
		}
	}
	v_u_78[#v_u_78 + 1] = v385
	local v386 = {
		["cx"] = (v345 + v349) / 2,
		["cy"] = (v346 + v350) / 2,
		["wpx"] = v349 - v345,
		["hpx"] = v350 - v346
	}
	local v387 = p_u_65.FERMATA
	local v388 = v387.hull
	local v389 = (v388[2] + v388[4]) / 2
	for v390 = 0, 4 do
		local v391 = v388[1] + v390 * 8
		local v392 = (v388[4] - v388[2]) / 2 * (v390 + 1) / 5
		v104("props", v391, v389 - v392, v391 + 8, v389 + v392, "build", 0, {
			["name"] = "ShipBow"
		})
	end
	v104("props", v388[1] + 40, v388[2], v388[3], v388[4], "build", 0, {
		["name"] = "Ship",
		["st"] = nil,
		["st"] = {
			["c"] = "buildEdge",
			["th"] = 1,
			["a"] = 0.1
		}
	})
	local v393 = v387.deck
	v104("props", v393[1], v393[2], v393[3], v393[4], "paperLight", 0.35, {
		["name"] = "ShipDeck"
	})
	local v394 = v387.house
	v104("props", v394[1], v394[2], v394[3], v394[4], "landmark", 0, {
		["name"] = "ShipHouse",
		["st"] = nil,
		["st"] = {
			["c"] = "landmarkEdge",
			["th"] = 1,
			["a"] = 0.1
		}
	}, 3)
	local v395 = v387.gangway
	v104("props", v395[1], v395[2], v395[3], v395[4], "ink", 0.2, {
		["name"] = "Gangway"
	}, 2)
	local v396 = v388[1]
	local v397 = v388[2]
	local v398 = (v396 + v_u_72) * v_u_76
	local v399 = (v397 + v_u_72) * v_u_76
	local v400 = v388[3]
	local v401 = v388[4]
	local v402 = (v400 + v_u_72) * v_u_76
	local v403 = (v401 + v_u_72) * v_u_76
	local v404 = {
		v398 - 1,
		v399 - 1,
		v402 + 1,
		v403 + 1
	}
	table.insert(v_u_262, v404)
	local v_u_405 = {}
	local v_u_406 = {}
	local v_u_407 = {}
	local v_u_408 = false
	local function v_u_415(p409, p410, p411, p412, p413) -- name: overlaps
		for _, v414 in p413 do
			if p409 >= v414[3] or (v414[1] >= p411 or (p410 >= v414[4] or v414[2] >= p412)) then
				continue
			end
			return true
		end
		return false
	end
	local function v_u_422(p416, p417, p418, p419, p420, p421) -- name: free
		-- upvalues: (copy) v_u_75, (copy) v_u_415, (copy) v_u_405, (copy) v_u_262
		if p416 < 3 or (p417 < 3 or (v_u_75 - 3 < p418 or v_u_75 - 3 < p419)) then
			return false
		end
		if v_u_415(p416, p417, p418, p419, v_u_405) then
			return false
		end
		if p421 and v_u_415(p416, p417, p418, p419, p421) then
			return false
		end
		if p420 then
			p420 = v_u_415(p416, p417, p418, p419, v_u_262)
		end
		return not p420
	end
	local function v_u_462(p423, p424, p425, p426, p427, p428, p429, p430, p431, p432, p433) -- name: label
		-- upvalues: (copy) v_u_70, (ref) v_u_49, (copy) v_u_422, (copy) v_u_75, (copy) v_u_405, (copy) v_u_406, (ref) v_u_128, (copy) v_u_78, (ref) v_u_408, (copy) v_u_407
		local v434 = v_u_70(p426, p432)
		local v435 = 0
		for _, v436 in v_u_49(p423) do
			local v437
			if v436 >= 11904 then
				v437 = v434
			else
				v437 = v434 * 0.56
			end
			v435 = v435 + v437
		end
		local v438 = v435 + 6
		local v439 = v434 + 2
		local v440
		if p429 then
			v440 = p429.rot
		else
			v440 = p429
		end
		if v440 then
			if math.abs(v440) ~= 90 then
				local v441 = v438
				v438 = v439
				v439 = v441
			end
		else
			local v442 = v438
			v438 = v439
			v439 = v442
		end
		if not (p430 or v_u_422(p424 - v439 / 2, p425 - v438 / 2, p424 + v439 / 2, p425 + v438 / 2, p431, p433)) then
			return nil
		end
		if p430 then
			local v443 = v439 / 2 + 3
			local v444 = v439 / 2 + 3
			local v445 = v_u_75 - v439 / 2 - 3
			local v446 = math.max(v444, v445)
			p424 = math.clamp(p424, v443, v446)
			local v447 = v438 / 2 + 3
			local v448 = v438 / 2 + 3
			local v449 = v_u_75 - v438 / 2 - 3
			local v450 = math.max(v448, v449)
			p425 = math.clamp(p425, v447, v450)
		end
		local v451 = {
			p424 - v439 / 2,
			p425 - v438 / 2,
			p424 + v439 / 2,
			p425 + v438 / 2
		}
		local v452 = v_u_405
		table.insert(v452, v451)
		v_u_406[v451] = true
		v_u_128 = v_u_128 + 1
		local v453 = 0
		local v454 = 20
		for _, v455 in v_u_49(p423) do
			local v456
			if v455 >= 11904 then
				v456 = v434
			else
				v456 = v434 * 0.56
			end
			v453 = v453 + v456
		end
		local v457 = v453 * 1.12 + 10
		local v458 = {
			["t"] = "text",
			["L"] = "labels",
			["str"] = nil,
			["x"] = nil,
			["y"] = nil,
			["sz"] = nil,
			["f"] = nil,
			["c"] = nil,
			["w"] = nil,
			["h"] = nil,
			["rect"] = nil,
			["str"] = p423,
			["x"] = p424,
			["y"] = p425,
			["sz"] = v434,
			["f"] = p427,
			["c"] = p428,
			["w"] = math.max(v454, v457),
			["h"] = v434 + 4,
			["rect"] = v451
		}
		if p429 then
			for v459, v460 in p429 do
				v458[v459] = v460
			end
		end
		v_u_78[#v_u_78 + 1] = v458
		if v_u_408 then
			local v461 = v_u_407
			table.insert(v461, {
				["id"] = "",
				["kind"] = "name",
				["rect"] = nil,
				["item"] = nil,
				["rect"] = v451,
				["item"] = v458
			})
		end
		return v458
	end
	local v463 = v77 * 19
	local v464 = math.floor(v463)
	local v465 = v_u_70(math.max(13, v464), "text")
	local v466 = v77 * 196
	local v467 = math.floor(v466)
	local v468 = 52 * v77
	local v469 = math.floor(v468)
	if v71 then
		local v470 = 0
		for _, v471 in v_u_49((v_u_64("TOKYO"))) do
			local v472
			if v471 >= 11904 then
				v472 = v465
			else
				v472 = v465 * 0.56
			end
			v470 = v470 + v472
		end
		local v473 = v470 * 1.25 + 14
		local v474 = math.ceil(v473)
		v467 = math.max(v467, v474)
		local v475 = 34 * v77
		local v476 = math.floor(v475)
		local v477 = v465 + 10
		v469 = math.max(v476, v477)
	end
	local v478 = {}
	local v479 = {}
	local v480 = 10 * v77
	local v481 = math.floor(v480)
	local v482 = 10 * v77
	local v483 = math.floor(v482)
	local v484 = 10 * v77
	local v485 = math.floor(v484) + v467
	local v486 = 10 * v77
	__set_list(v479, 1, {v481, v483, v485, math.floor(v486) + v469})
	local v487 = {}
	local v488 = v_u_75 - 34 * v77 - v77 * 19
	local v489 = v77 * 40 - v77 * 22
	local v490 = 15 * v77
	local v491 = math.floor(v490)
	__set_list(v487, 1, {v488, v489 - math.max(11, v491), v_u_75 - 34 * v77 + v77 * 19, v77 * 40 + v77 * 19})
	local v492 = {}
	local v493 = v77 * 14 - 8
	local v494 = v_u_75 - v77 * 26 - v77 * 9 - 9
	local v495 = v77 * 14 + 100 / p_u_65.STUDS_TO_M * v_u_76 + 34
	local v496 = v_u_75 - v77 * 26
	local v497 = v77 * 5
	__set_list(v492, 1, {v493, v494, v495, v496 + math.max(3, v497) + 3})
	__set_list(v478, 1, {v479, v487, v492})
	local v498 = 13 * v77 + 0.5
	local v499 = math.floor(v498)
	local v500 = math.max(10, v499)
	local v501 = v77 * 11 + 0.5
	local v502 = math.floor(v501)
	local v_u_503 = math.max(9, v502)
	local v_u_504 = {}
	table.sort(v261, function(p505, p506)
		return p505.area > p506.area
	end)
	local v507 = p_u_65.FERMATA.hull
	local v508 = v507[1]
	local v509 = v507[2]
	local v510 = (v508 + v_u_72) * v_u_76
	local v511 = (v509 + v_u_72) * v_u_76
	local v512 = v507[3]
	local v513 = v507[4]
	local v514 = (v512 + v_u_72) * v_u_76
	local v515 = (v513 + v_u_72) * v_u_76
	local v516 = {
		["text"] = "FERMATA",
		["id"] = "fermata",
		["x"] = nil,
		["y"] = nil,
		["wpx"] = nil,
		["hpx"] = nil,
		["area"] = 1000000000,
		["x"] = (v510 + v514) / 2,
		["y"] = (v511 + v515) / 2,
		["wpx"] = v514 - v510,
		["hpx"] = v515 - v511
	}
	table.insert(v261, 1, v516)
	local function v525(p517, p518, p519) -- name: jpLine
		-- upvalues: (copy) p_u_65, (copy) v_u_70, (copy) v_u_503, (copy) v_u_462, (copy) v_u_504
		local v520 = p_u_65.JP[p517]
		if v520 and p518 then
			local v521 = v_u_70(v_u_503, "caption")
			local v522 = p518.y + p518.sz / 2 + v521 / 2 + 2
			local v523 = p518.y - p518.sz / 2 - v521 / 2 - 2
			for _, v524 in p518.y >= p519.y and { v522, v523 } or { v523, v522 } do
				if not v_u_462(v520, p518.x, v524, v_u_503, "body", "redDeep", nil, false, false, "caption", v_u_504) then
					continue
				end
				return
			end
		end
	end
	for _, v526 in v261 do
		local v527 = {
			v526.x - v526.wpx / 2 - 1,
			v526.y - v526.hpx / 2 - 1,
			v526.x + v526.wpx / 2 + 1,
			v526.y + v526.hpx / 2 + 1
		}
		table.insert(v_u_504, v527)
	end
	for _, v528 in v478 do
		table.insert(v_u_504, v528)
	end
	local v529 = v_u_70(v500, "text")
	local v530 = v_u_75 >= 700 and 14 or (v_u_75 >= 500 and 10 or (v_u_75 >= 380 and 7 or 5))
	for v531, v532 in v261 do
		local v533 = v532.text
		local v534 = string.upper(v533)
		local v535 = string.gsub(v534, utf8.char(333), utf8.char(332))
		local v536 = 0
		for _, v537 in v_u_49(v535) do
			local v538
			if v537 >= 11904 then
				v538 = v529
			else
				v538 = v529 * 0.56
			end
			v536 = v536 + v538
		end
		local v539 = v536 + 6
		local v540 = v529 + 2
		local v541 = v532.wpx
		local v542 = v532.hpx
		local v543 = { v532.x, v532.y + v542 / 2 + v540 / 2 + 3 }
		local v544 = { v532.x, v532.y - v542 / 2 - v540 / 2 - 3 }
		local v545 = { v532.x + v541 / 2 + v539 / 2 + 3, v532.y }
		local v546 = { v532.x - v541 / 2 - v539 / 2 - 3, v532.y }
		local v547 = {
			v543,
			v544,
			v545,
			v546,
			{ v532.x + v541 / 2 + v539 / 2 + 3, v532.y + v542 / 2 + v540 / 2 },
			{ v532.x - v541 / 2 - v539 / 2 - 3, v532.y + v542 / 2 + v540 / 2 },
			{ v532.x + v541 / 2 + v539 / 2 + 3, v532.y - v542 / 2 - v540 / 2 },
			{ v532.x - v541 / 2 - v539 / 2 - 3, v532.y - v542 / 2 - v540 / 2 }
		}
		local v548 = v532.id == "fermata" and {
			v545,
			v546,
			v543,
			v544
		} or v547
		local v549 = nil
		for _, v550 in v548 do
			v549 = v_u_462(v535, v550[1], v550[2], v500, "headB", "redDeep", nil, false, false, "text", v_u_504)
			if not v549 then
				continue
			end
		end
		if not v549 and v531 <= v530 then
			v549 = v_u_462(v535, v548[1][1], v548[1][2], v500, "headB", "redDeep", nil, true, false, "text")
		end
		if not v549 then
			break
		end
		v549.id = v532.id
		v525(v532.id, v549, v532)
	end
	local v551 = #v_u_405
	for _, v552 in v478 do
		local v553 = {}
		local v554 = v552[1]
		local v555 = math.max(0, v554)
		local v556 = v552[2]
		local v557 = math.max(0, v556)
		local v558 = v552[3]
		local v559 = math.min(v_u_75, v558)
		local v560 = v552[4]
		__set_list(v553, 1, {v555, v557, v559, (math.min(v_u_75, v560))})
		table.insert(v_u_405, v553)
	end
	if v68.clean == true then
		v_u_408 = true
	else
		v_u_408 = false
	end
	if v386 and (v386.wpx >= 26 and v386.hpx >= 16) then
		local v561 = 10 * v77 + 0.5
		local v562 = math.floor(v561)
		local v563 = math.max(9, v562)
		local v564 = v_u_462("B1F", v386.cx, v386.cy, v563, "headB", "ink", {
			["sc"] = "paperLight",
			["sa"] = 0.2,
			["name"] = "ClubB1F"
		}, true, false, "caption")
		if v564 then
			v564.id = "club_b1f"
		end
	end
	local v565 = v77 * 11 + 0.5
	local v566 = math.floor(v565)
	local v567 = math.max(9, v566)
	local v568 = v_u_70(v567, "caption")
	local v569 = {}
	local v570 = {}
	for _, v571 in p_u_65.ROADS do
		table.insert(v569, v571)
	end
	table.sort(v569, function(p572, p573)
		local v574 = (p572[6] == "main" or p572[6] == "walk") and 0 or 1
		local v575 = (p573[6] == "main" or p573[6] == "walk") and 0 or 1
		if v574 ~= v575 then
			return v574 < v575
		end
		local v576 = p572[3] - p572[1]
		local v577 = p572[4] - p572[2]
		local v578 = math.max(v576, v577)
		local v579 = p573[3] - p573[1]
		local v580 = p573[4] - p573[2]
		return math.max(v579, v580) < v578
	end)
	for _, v581 in v569 do
		local v582 = v581[5]
		local v583 = v581[3] - v581[1] > v581[4] - v581[2]
		local v584
		if v583 then
			v584 = v581[3] - v581[1]
		else
			v584 = v581[4] - v581[2]
		end
		if v582 == "" or v570[v582] then
			continue
		end
		local v585 = v584 * v_u_76
		local v586 = string.upper(v582)
		local v587 = 0
		for _, v588 in v_u_49((string.gsub(v586, utf8.char(333), utf8.char(332)))) do
			local v589
			if v588 >= 11904 then
				v589 = v568
			else
				v589 = v568 * 0.56
			end
			v587 = v587 + v589
		end
		if v587 * 0.9 >= v585 then
			break
		end
		for _, v590 in {
			0.5,
			0.3,
			0.7,
			0.15,
			0.85,
			0.4,
			0.6
		} do
			local v591
			if v583 then
				v591 = v581[1] + (v581[3] - v581[1]) * v590
			else
				v591 = (v581[1] + v581[3]) / 2
			end
			local v592
			if v583 then
				v592 = (v581[2] + v581[4]) / 2
			else
				v592 = v581[2] + (v581[4] - v581[2]) * v590
			end
			local v593 = (v591 + v_u_72) * v_u_76
			local v594 = (v592 + v_u_72) * v_u_76
			local v595 = string.upper(v582)
			if not v_u_462(string.gsub(v595, utf8.char(333), utf8.char(332)), v593, v594, v567, "bodyM", "inkSoft", {
				["rot"] = nil,
				["sc"] = nil,
				["sa"] = 0.1,
				["rot"] = v583 and 0 or 90,
				["sc"] = v581[6] == "main" and "highway" or "road"
			}, false, false, "caption") then
				continue
			end
			v570[v582] = true
		end
	end
	local v596 = 13 * v77 + 0.5
	local v597 = math.floor(v596)
	local v598 = math.max(10, v597)
	local v599 = {
		{ 0.5, 0.5 },
		{ 0.5, 0.1 },
		{ 0.5, 0.9 },
		{ 0.25, 0.5 },
		{ 0.75, 0.5 },
		{ 0.25, 0.14 },
		{ 0.75, 0.14 },
		{ 0.25, 0.86 },
		{ 0.75, 0.86 },
		{ 0.1, 0.5 },
		{ 0.9, 0.5 }
	}
	for _, v600 in p_u_65.AREAS do
		if not v600[6] then
			continue
		end
		local v601 = v600[5]
		local v602 = v600[7] == true
		local v603 = v_u_64(v600[2])
		local v604 = v600[1]
		local v605 = v604 == "harbour" and true or v604 == "inner_canal"
		local v606 = v605 and "waterInk" or (v604 == "expressway" and "ink" or (v604 == "rail_viaduct" and "rail" or "inkSoft"))
		local v607 = {
			["sc"] = v605 and "water" or (v604 == "expressway" and "highway" or "paper"),
			["sa"] = v605 and 0.3 or 0.45
		}
		if v602 then
			v607.rot = 90
		end
		local v608 = false
		for v609 = 1, 2 do
			for _, v610 in v599 do
				local v611 = v601[1] + (v601[3] - v601[1]) * v610[1]
				local v612 = v601[2] + (v601[4] - v601[2]) * v610[2]
				local v613 = v_u_462(v603, (v611 + v_u_72) * v_u_76, (v612 + v_u_72) * v_u_76, v598, "head", v606, v607, false, v609 == 1, "caption")
				if not v613 then
					continue
				end
				v613.id = v604
				v608 = true
			end
			if not v608 then
				continue
			end
			break
			break
		end
	end
	for _, v614 in { 0.3333333333333333, 0.6666666666666666 } do
		local v615 = p66 * v614
		local v616 = math.floor(v615)
		v_u_78[#v_u_78 + 1] = {
			["t"] = "rect",
			["L"] = "sheet",
			["x"] = nil,
			["y"] = 0,
			["w"] = 2,
			["h"] = nil,
			["c"] = "paperLight",
			["a"] = 0.35,
			["z"] = 20,
			["name"] = "Crease",
			["x"] = v616,
			["h"] = p66
		}
		local v617 = {
			["t"] = "rect",
			["L"] = "sheet",
			["x"] = nil,
			["y"] = 0,
			["w"] = 1,
			["h"] = nil,
			["c"] = "crease",
			["a"] = 0.5,
			["z"] = 20,
			["name"] = "Crease",
			["x"] = v616 + 2,
			["h"] = p66
		}
		v_u_78[#v_u_78 + 1] = v617
	end
	local v618 = p66 * 0.5
	local v619 = math.floor(v618)
	v_u_78[#v_u_78 + 1] = {
		["t"] = "rect",
		["L"] = "sheet",
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 2,
		["c"] = "paperLight",
		["a"] = 0.4,
		["z"] = 20,
		["name"] = "Crease",
		["y"] = v619,
		["w"] = p66
	}
	local v620 = {
		["t"] = "rect",
		["L"] = "sheet",
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 1,
		["c"] = "crease",
		["a"] = 0.55,
		["z"] = 20,
		["name"] = "Crease",
		["y"] = v619 + 2,
		["w"] = p66
	}
	v_u_78[#v_u_78 + 1] = v620
	local v621 = v77 * 12 + 0.5
	local v622 = math.floor(v621)
	local v623 = v_u_70(math.max(9, v622), "caption")
	local function v640(p624, p625, p626, p627, p628, p629, p630, p631) -- name: sheetText
		-- upvalues: (ref) v_u_49, (copy) v_u_78
		local v632 = 0
		local v633 = 20
		local v634 = {
			["t"] = "text",
			["L"] = "sheet",
			["str"] = nil,
			["x"] = nil,
			["y"] = nil,
			["sz"] = nil,
			["f"] = nil,
			["c"] = nil,
			["w"] = nil,
			["h"] = nil,
			["z"] = nil,
			["sa"] = 1,
			["str"] = p624,
			["x"] = p625,
			["y"] = p626,
			["sz"] = p627,
			["f"] = p628,
			["c"] = p629
		}
		for _, v635 in v_u_49(p624) do
			local v636
			if v635 >= 11904 then
				v636 = p627
			else
				v636 = p627 * 0.56
			end
			v632 = v632 + v636
		end
		local v637 = v632 * 1.12 + 10
		v634.w = math.max(v633, v637)
		v634.h = p627 + 4
		v634.z = p630
		if p631 then
			for v638, v639 in p631 do
				v634[v638] = v639
			end
		end
		v_u_78[#v_u_78 + 1] = v634
		return v634
	end
	for v641 = 1, v145 do
		local v642 = v74 + v_u_75 * (v641 - 0.5) / v145
		for _, v643 in { v74 / 2, p66 - v74 / 2 } do
			v640(p_u_65.GRID_LETTERS[v641] or "?", v642, v643, v623, "head", "inkSoft", 21)
		end
		for _, v644 in { v74 / 2, p66 - v74 / 2 } do
			v640(tostring(v641), v644, v642, v623, "head", "inkSoft", 21)
		end
	end
	local v645 = {}
	local v646 = {}
	local v647 = {
		["t"] = "rect",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["c"] = "paperLight",
		["a"] = 0,
		["z"] = 10,
		["name"] = "Cartouche",
		["st"] = nil
	}
	local v648 = 10 * v77
	v647.x = math.floor(v648)
	local v649 = 10 * v77
	v647.y = math.floor(v649)
	v647.w = v467
	v647.h = v469
	v647.st = {
		["c"] = "ink",
		["th"] = 1,
		["a"] = 0
	}
	v_u_78[#v_u_78 + 1] = v647
	local v650
	if v71 then
		v650 = { v467 / 2, v469 / 2 }
	else
		v650 = { 98 * v77, v77 * 19 }
	end
	local v651 = {
		["t"] = "text",
		["L"] = "area",
		["str"] = nil,
		["x"] = nil,
		["y"] = nil,
		["sz"] = nil,
		["f"] = "headB",
		["c"] = "ink",
		["w"] = nil,
		["h"] = nil,
		["z"] = 11,
		["sa"] = 1,
		["name"] = "CartTitle",
		["str"] = v_u_64("TOKYO")
	}
	local v652 = 10 * v77
	v651.x = math.floor(v652) + v650[1]
	local v653 = 10 * v77
	v651.y = math.floor(v653) + v650[2]
	v651.sz = v465
	local v654
	if v71 then
		v654 = v467 - 4
	else
		v654 = 190 * v77
	end
	v651.w = v654
	local v655
	if v71 then
		v655 = v469 - 4
	else
		v655 = v77 * 24
	end
	v651.h = v655
	v_u_78[#v_u_78 + 1] = v651
	table.insert(v646, v651)
	if not v71 then
		local v656 = v77 * 11
		local v657 = math.floor(v656)
		local v658 = v_u_70(math.max(9, v657), "caption")
		local v659 = {
			["t"] = "text",
			["L"] = "area",
			["str"] = "Minato, December 1987",
			["x"] = nil,
			["y"] = nil,
			["sz"] = nil,
			["f"] = "body",
			["c"] = "inkSoft",
			["w"] = nil,
			["h"] = nil,
			["z"] = 11,
			["sa"] = 1,
			["name"] = "CartSub"
		}
		local v660 = 10 * v77
		v659.x = math.floor(v660) + 98 * v77
		local v661 = 10 * v77
		v659.y = math.floor(v661) + 39 * v77
		v659.sz = v658
		v659.w = 190 * v77
		v659.h = v77 * 14
		v_u_78[#v_u_78 + 1] = v659
		table.insert(v646, v659)
	end
	local v662 = v68.clean == true
	local v663 = 15 * v77
	local v664 = math.floor(v663)
	local v665 = v_u_70(math.max(11, v664), "text")
	local v666 = v_u_75 - 34 * v77
	local v667 = v77 * 40
	if v662 then
		local v668 = 17 * v77 + v665 + 4
		v667 = math.max(v667, v668)
		local v669 = {
			v666 - 17 * v77 - 2,
			v667 - 17 * v77 - v665 - 4,
			v666 + 17 * v77 + 2,
			v667 + 17 * v77 + 2
		}
		table.insert(v645, v669)
		local v670 = {}
		local v671 = 10 * v77
		local v672 = math.floor(v671)
		local v673 = 10 * v77
		local v674 = math.floor(v673)
		local v675 = 10 * v77
		local v676 = math.floor(v675) + v467
		local v677 = 10 * v77
		__set_list(v670, 1, {v672, v674, v676, math.floor(v677) + v469})
		table.insert(v645, v670)
	end
	local v678 = {
		["t"] = "text",
		["L"] = "area",
		["str"] = "N",
		["x"] = nil,
		["y"] = nil,
		["sz"] = nil,
		["f"] = "headB",
		["c"] = "ink",
		["w"] = nil,
		["h"] = nil,
		["z"] = 10,
		["sa"] = 1,
		["name"] = "North",
		["x"] = v666
	}
	local v679
	if v662 then
		v679 = 17 * v77 + v665 * 0.5 + 3
	else
		v679 = v77 * 22
	end
	v678.y = v667 - v679
	v678.sz = v665
	local v680 = v665 * 1.3
	v678.w = math.max(20, v680)
	v678.h = v665 + 4
	v_u_78[#v_u_78 + 1] = v678
	local v681 = {
		["t"] = "rect",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["w"] = 2,
		["h"] = nil,
		["c"] = "ink",
		["a"] = 0,
		["z"] = 10,
		["name"] = "Needle",
		["x"] = v666 - 1,
		["y"] = v667 - v77 * 14,
		["h"] = 28 * v77
	}
	v_u_78[#v_u_78 + 1] = v681
	local v682 = {
		["t"] = "dia",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["d"] = nil,
		["c"] = "red",
		["a"] = 0,
		["z"] = 10,
		["name"] = "NeedleTip",
		["x"] = v666,
		["y"] = v667 - v77 * 9,
		["d"] = 7 * v77
	}
	v_u_78[#v_u_78 + 1] = v682
	local v683 = {
		["t"] = "rect",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 1,
		["c"] = "ink",
		["a"] = 0,
		["z"] = 10,
		["name"] = "Cross",
		["x"] = v666 - v77 * 8,
		["y"] = v667,
		["w"] = 16 * v77
	}
	v_u_78[#v_u_78 + 1] = v683
	local v684 = {
		["t"] = "dot",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["d"] = nil,
		["c"] = "paper",
		["a"] = 1,
		["z"] = 10,
		["name"] = "Ring",
		["st"] = nil,
		["x"] = v666,
		["y"] = v667,
		["d"] = 34 * v77,
		["st"] = {
			["c"] = "ink",
			["th"] = 1,
			["a"] = 0.3
		}
	}
	v_u_78[#v_u_78 + 1] = v684
	local v685 = 100 / p_u_65.STUDS_TO_M * v_u_76
	local v686 = v77 * 14
	local v687 = v_u_75 - v77 * 26
	local v688 = v77 * 5
	local v689 = math.max(3, v688)
	local v690 = {
		["t"] = "rect",
		["L"] = "area",
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["c"] = "paperLight",
		["a"] = 0.45,
		["z"] = 9,
		["name"] = "ScalePlate",
		["x"] = v686 - 8,
		["y"] = v687 - v77 * 9 - 9,
		["w"] = v685 + 42,
		["h"] = v689 + v77 * 9 + 14
	}
	v_u_78[#v_u_78 + 1] = v690
	for v691 = 0, 3 do
		local v692 = {
			["t"] = "rect",
			["L"] = "area",
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["c"] = nil,
			["a"] = 0,
			["z"] = 10,
			["name"] = "Scale",
			["st"] = nil,
			["x"] = v686 + v691 * v685 / 4,
			["y"] = v687,
			["w"] = v685 / 4,
			["h"] = v689,
			["c"] = v691 % 2 == 0 and "ink" or "paperLight",
			["st"] = {
				["c"] = "ink",
				["th"] = 1,
				["a"] = 0
			}
		}
		v_u_78[#v_u_78 + 1] = v692
	end
	local v693
	if v662 then
		v693 = v77 * 9 + 3
	else
		v693 = v77 * 9
	end
	local v694 = v77 * 11
	local v695 = math.floor(v694)
	local v696 = v_u_70(math.max(9, v695), "caption")
	local v697 = {
		["t"] = "text",
		["L"] = "area",
		["str"] = "0",
		["x"] = nil,
		["y"] = nil,
		["sz"] = nil,
		["f"] = "bodyM",
		["c"] = "ink",
		["w"] = nil,
		["h"] = nil,
		["z"] = 10,
		["sa"] = 0.4,
		["name"] = "Scale0",
		["x"] = v686,
		["y"] = v687 - v693,
		["sz"] = v696
	}
	local v698 = v696 * 1.3
	v697.w = math.max(20, v698)
	v697.h = v696 + 4
	v_u_78[#v_u_78 + 1] = v697
	local v699 = {
		["t"] = "text",
		["L"] = "area",
		["str"] = "100 m",
		["x"] = nil,
		["y"] = nil,
		["sz"] = nil,
		["f"] = "bodyM",
		["c"] = "ink",
		["w"] = nil,
		["h"] = nil,
		["z"] = 10,
		["sa"] = 0.4,
		["name"] = "Scale100",
		["x"] = v686 + v685,
		["y"] = v687 - v693,
		["sz"] = v696
	}
	local v700 = 0
	for _, v701 in v_u_49("100 m") do
		local v702
		if v701 >= 11904 then
			v702 = v696
		else
			v702 = v696 * 0.56
		end
		v700 = v700 + v702
	end
	v699.w = v700 * 1.12 + 10
	v699.h = v696 + 4
	v_u_78[#v_u_78 + 1] = v699
	if v662 then
		local v703 = {
			v686 - 8,
			v687 - v693 - 9,
			v686 + v685 + 34,
			v687 + v689 + 3
		}
		table.insert(v645, v703)
	end
	local v704 = {}
	for _, v705 in p_u_65.AREAS do
		local v706 = {
			["id"] = v705[1],
			["name"] = v705[2],
			["ref"] = v_u_1.gridRef(v705[3], v705[4])
		}
		table.insert(v704, v706)
	end
	return {
		["items"] = v_u_78,
		["size"] = p66,
		["margin"] = v74,
		["inner"] = v_u_75,
		["scale"] = v_u_76,
		["k"] = v77,
		["half"] = v_u_72,
		["placed"] = v_u_405,
		["nameRects"] = v_u_406,
		["removable"] = v_u_407,
		["reserved"] = v645,
		["nLandmarks"] = v551,
		["places"] = v704,
		["placeAt"] = v260,
		["cart"] = {
			["w"] = v467,
			["h"] = v469
		},
		["stats"] = {
			["frames"] = #v_u_78,
			["labels"] = v_u_128,
			["lots"] = v259,
			["trees"] = v149
		},
		["toPx"] = v131,
		["toWorld"] = function(p707, p708) -- name: toWorld
			-- upvalues: (copy) v_u_76, (copy) v_u_72
			return p707 / v_u_76 - v_u_72, p708 / v_u_76 - v_u_72
		end
	}
end
local v_u_709 = nil
local function v_u_719() -- name: inkTable
	-- upvalues: (ref) v_u_709, (copy) v_u_2
	if v_u_709 then
		return v_u_709
	end
	local v710 = {}
	for v711, v712 in v_u_2 do
		v710[v711] = Color3.fromHex(v712)
	end
	local v714, v715 = pcall(function()
		local v713 = script
		return require(v713.Parent:WaitForChild("MapDraw", 5))
	end)
	if v714 and type(v715) == "table" then
		local v716 = v715.INK
		if type(v716) == "table" then
			for v717, v718 in v715.INK do
				v710[v717] = v718
			end
		end
	end
	v710.deck = v710.deckInk
	v_u_709 = v710
	return v710
end
local v_u_720 = nil
local v_u_721 = nil
function v_u_1._setHooks(p722, p723) -- name: _setHooks
	-- upvalues: (ref) v_u_720, (ref) v_u_721
	v_u_720 = p722
	v_u_721 = p723
end
function v_u_1.build(p724, p725, _, p726, p_u_727) -- name: build
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_720, (ref) v_u_721, (copy) v_u_719, (copy) v_u_1, (copy) v_u_4, (copy) v_u_3
	if v_u_5 == nil and not v_u_6 then
		v_u_6 = true
		local v729, v730 = pcall(function()
			local v728 = script
			return require(v728.Parent:WaitForChild("TokyoMapData", 5))
		end)
		if v729 and type(v730) == "table" then
			v_u_5 = v730
		end
	end
	local v731 = v_u_5
	assert(v731, "TokyoMapData missing")
	local v_u_732 = v_u_720 or require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
	local v733 = nil
	local v734
	if v_u_721 == nil then
		local v735
		v735, v734 = pcall(function()
			return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapTagPlace", 5))
		end)
		if v735 then
			if type(v734) ~= "table" then
				v734 = v733
			end
		else
			v734 = v733
		end
	elseif v_u_721 == false then
		v734 = nil
	else
		v734 = v_u_721
	end
	local v736 = v_u_719()
	v_u_1.INK = v736
	local v737
	if p_u_727 then
		v737 = p_u_727.phone
	else
		v737 = v_u_732.isPhone()
	end
	local function v744(p738, p739) -- name: lift
		-- upvalues: (copy) v_u_732, (copy) p_u_727
		local v740 = v_u_732.phoneText
		local v741 = p739 or "caption"
		local v742
		if p_u_727 then
			v742 = p_u_727.scale
		else
			v742 = nil
		end
		local v743
		if p_u_727 then
			v743 = p_u_727.phone
		else
			v743 = nil
		end
		return v740(p738, v741, v742, v743)
	end
	local v745
	if v734 == nil then
		v745 = false
	else
		v745 = v734.clean() == true
	end
	local v_u_746 = v_u_1.plan(v731, p725, {
		["lift"] = v744,
		["isPhone"] = v737,
		["clean"] = v745
	})
	local v_u_747 = v_u_746.half
	local v_u_748 = v_u_746.scale
	local v749 = p726 and p726.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
	local v750 = p726 and p726.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v751 = p726 and p726.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v752 = p726 and p726.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v753 = {
		["Name"] = "Sheet",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v736.paper,
		["Size"] = UDim2.fromOffset(p725, p725)
	}
	local v754 = Instance.new("Frame")
	v754.BorderSizePixel = 0
	local v755 = {
		["head"] = v749,
		["headB"] = v750,
		["body"] = v751,
		["bodyM"] = v752
	}
	for v756, v757 in v753 do
		v754[v756] = v757
	end
	v754.Parent = p724
	local v758 = v736.paperEdge
	local v759 = Instance.new("UIStroke")
	v759.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v759.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v759.Color = v758
	v759.Thickness = 2
	v759.Transparency = 0
	v759.Parent = v754
	local v760 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v736.paperLight,
		["Position"] = UDim2.fromOffset(v_u_746.margin, v_u_746.margin),
		["Size"] = UDim2.fromOffset(v_u_746.inner, v_u_746.inner)
	}
	local v761 = Instance.new("Frame")
	v761.BorderSizePixel = 0
	for v762, v763 in v760 do
		v761[v762] = v763
	end
	v761.Parent = v754
	local v764 = v736.ink
	local v765 = Instance.new("UIStroke")
	v765.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v765.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v765.Color = v764
	v765.Thickness = 1
	v765.Transparency = 0
	v765.Parent = v761
	local v766 = {}
	for _, v767 in v_u_4 do
		local v768 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Name"] = v767,
			["Size"] = UDim2.fromScale(1, 1),
			["ZIndex"] = v_u_3[v767]
		}
		local v769 = Instance.new("Frame")
		v769.BorderSizePixel = 0
		for v770, v771 in v768 do
			v769[v770] = v771
		end
		v769.Parent = v761
		v766[v767] = v769
	end
	local v772 = {}
	for _, v773 in v_u_746.items do
		local v774
		if v773.L == "sheet" then
			v774 = v754
		elseif v773.L == "area" then
			v774 = v761
		else
			v774 = v766[v773.L]
		end
		local v775 = v773.z
		local v776 = nil
		if v773.t == "rect" then
			local v777 = {
				["BackgroundColor3"] = v736[v773.c],
				["BackgroundTransparency"] = v773.a,
				["Position"] = UDim2.fromOffset(v773.x, v773.y),
				["Size"] = UDim2.fromOffset(v773.w, v773.h)
			}
			if v773.name then
				v777.Name = v773.name
			end
			if v775 then
				v777.ZIndex = v775
			end
			v776 = Instance.new("Frame")
			v776.BorderSizePixel = 0
			for v778, v779 in v777 do
				v776[v778] = v779
			end
			v776.Parent = v774
			if v773.border then
				v776.BorderSizePixel = 1
				v776.BorderMode = Enum.BorderMode.Inset
				v776.BorderColor3 = v736[v773.border]
			end
			if v773.st then
				local v780 = v736[v773.st.c]
				local v781 = v773.st.th
				local v782 = v773.st.a
				local v783 = Instance.new("UIStroke")
				v783.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				v783.BorderStrokePosition = Enum.BorderStrokePosition.Inner
				v783.Color = v780
				v783.Thickness = v781
				v783.Transparency = v782 or 0
				v783.Parent = v776
			end
			if v773.road then
				v776:SetAttribute("Road", v773.road)
			end
		elseif v773.t == "seg" then
			local v784 = v773.x1 - v773.x0
			local v785 = v773.y1 - v773.y0
			local v786 = v784 * v784 + v785 * v785
			local v787 = math.sqrt(v786)
			local v788 = {
				["Name"] = "Seg",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["BackgroundColor3"] = v736[v773.c],
				["BackgroundTransparency"] = v773.a,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset((v773.x0 + v773.x1) / 2, (v773.y0 + v773.y1) / 2),
				["Size"] = UDim2.fromOffset(v787 + v773.th * 0.5, v773.th)
			}
			local v789 = math.atan2(v785, v784)
			v788.Rotation = math.deg(v789)
			if v775 then
				v788.ZIndex = v775
			end
			v776 = Instance.new("Frame")
			v776.BorderSizePixel = 0
			for v790, v791 in v788 do
				v776[v790] = v791
			end
			v776.Parent = v774
		elseif v773.t == "dot" or v773.t == "dia" then
			local v792 = {
				["Name"] = v773.name or (v773.t == "dot" and "Dot" or "Dia"),
				["BackgroundColor3"] = v736[v773.c],
				["BackgroundTransparency"] = v773.a,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v773.x, v773.y),
				["Size"] = UDim2.fromOffset(v773.d, v773.d)
			}
			if v773.t == "dia" then
				v792.Rotation = 45
			end
			if v775 then
				v792.ZIndex = v775
			end
			v776 = Instance.new("Frame")
			v776.BorderSizePixel = 0
			for v793, v794 in v792 do
				v776[v793] = v794
			end
			v776.Parent = v774
			if v773.t == "dot" then
				local v795 = Instance.new("UICorner")
				v795.CornerRadius = UDim.new(0.5, 0)
				v795.Parent = v776
			end
			if v773.st then
				local v796 = v736[v773.st.c]
				local v797 = v773.st.th
				local v798 = v773.st.a
				local v799 = Instance.new("UIStroke")
				v799.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				v799.BorderStrokePosition = Enum.BorderStrokePosition.Inner
				v799.Color = v796
				v799.Thickness = v797
				v799.Transparency = v798 or 0
				v799.Parent = v776
			end
		elseif v773.t == "text" then
			v776 = Instance.new("TextLabel")
			v776.Name = v773.name or "Txt"
			v776.BackgroundTransparency = 1
			v776.AnchorPoint = Vector2.new(0.5, 0.5)
			v776.Position = UDim2.fromOffset(v773.x, v773.y)
			v776.Size = UDim2.fromOffset(v773.w, v773.h)
			v776.FontFace = v755[v773.f] or v751
			v776.TextSize = v773.sz
			v776.TextColor3 = v736[v773.c]
			v776.TextStrokeColor3 = v736[v773.sc or "paper"]
			v776.TextStrokeTransparency = v773.sa or 0.25
			v776.Text = v773.str
			v776.TextTruncate = Enum.TextTruncate.AtEnd
			if v773.rot then
				v776.Rotation = v773.rot
			end
			if v773.bg then
				v776.BackgroundColor3 = v736[v773.bg]
				v776.BackgroundTransparency = v773.bga or 0
			end
			if v775 then
				v776.ZIndex = v775
			end
			v776.Parent = v774
		end
		if not v776 then
			continue
		end
		v772[v773] = v776
	end
	local v800 = {}
	for _, v801 in v_u_746.removable do
		local v802 = {
			["id"] = v801.id,
			["kind"] = v801.kind,
			["rect"] = v801.rect,
			["obj"] = v772[v801.item]
		}
		table.insert(v800, v802)
	end
	local v_u_803 = v_u_746.placeAt
	local function v806(p804) -- name: placeOf
		-- upvalues: (copy) v_u_803, (ref) v_u_1
		local v805 = v_u_803[string.lower(p804)]
		if v805 then
			return v805[1], v805[2], v805[3]
		else
			return v_u_1.placeOf(p804)
		end
	end
	local v807 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v808 = Instance.new("Frame")
	v808.BorderSizePixel = 0
	local function v813(p809, p810) -- name: toPx
		-- upvalues: (copy) v_u_746
		local v811, v812 = v_u_746.toPx(p809, p810)
		return Vector2.new(v811, v812)
	end
	for v814, v815 in v807 do
		v808[v814] = v815
	end
	v808.Parent = v761
	v754:SetAttribute("Frames", #v_u_746.items)
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["labelLayer"] = nil,
		["nameRects"] = nil,
		["removable"] = nil,
		["reserved"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["field"] = true,
		["positions"] = true,
		["placeOf"] = nil,
		["places"] = nil,
		["stats"] = nil,
		["frame"] = v754,
		["area"] = v761,
		["marks"] = v808,
		["toPx"] = v813,
		["toWorld"] = function(p816, p817) -- name: toWorld
			-- upvalues: (copy) v_u_748, (copy) v_u_747
			return Vector2.new(p816 / v_u_748 - v_u_747, p817 / v_u_748 - v_u_747)
		end,
		["inside"] = function(p818, p819) -- name: inside
			-- upvalues: (copy) v_u_747
			local v820
			if math.abs(p818) <= v_u_747 then
				v820 = math.abs(p819) <= v_u_747
			else
				v820 = false
			end
			return v820
		end,
		["placed"] = v_u_746.placed,
		["labelLayer"] = v766.labels,
		["nameRects"] = v_u_746.nameRects,
		["removable"] = v800,
		["reserved"] = v_u_746.reserved,
		["nLandmarks"] = v_u_746.nLandmarks,
		["scale"] = v_u_748,
		["k"] = v_u_746.k,
		["ink"] = v736,
		["inner"] = v_u_746.inner,
		["innerW"] = v_u_746.inner,
		["innerH"] = v_u_746.inner,
		["placeOf"] = v806,
		["places"] = v_u_746.places,
		["stats"] = v_u_746.stats
	}
end
function v_u_1.inkTable() -- name: inkTable
	-- upvalues: (copy) v_u_719
	return v_u_719()
end
return v_u_1