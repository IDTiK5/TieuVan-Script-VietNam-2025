-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayWhy

local v_u_1 = {}
local v_u_2 = {
	["Normal"] = 1,
	["Hard"] = 2,
	["Nightmare"] = 3
}
local function v_u_4(p3) -- name: joinOr
	return table.concat(p3, " or ")
end
v_u_1.NOTE_MAX = 3
function v_u_1.taskNotes(p5, p6, p7, p8, p9) -- name: taskNotes
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v10 = {}
	if type(p7) == "table" then
		local v11 = p7.order
		if type(v11) == "table" then
			local v12 = p7.tasks
			if type(v12) == "table" and type(p5) == "table" then
				local v13 = p5.get
				if type(v13) == "function" and type(p6) == "table" then
					local v14
					if type(p9) == "string" and (p9 ~= "" and p9 ~= "Any") then
						v14 = string.lower(p9)
					else
						v14 = nil
					end
					for _, v15 in p7.order do
						local v16 = p7.tasks[v15]
						local v17
						if type(v16) == "table" and v16.state == "active" then
							v17 = p5.get(v15)
						else
							v17 = nil
						end
						if type(v17) ~= "table" then
							continue
						end
						local v18 = v17.objectives
						if type(v18) ~= "table" then
							continue
						end
						local v19 = 0
						local v20 = {}
						local v21 = {}
						local v22 = 0
						for v23, v24 in v17.objectives do
							local v25 = v16.progress
							local v26
							if type(v25) == "table" then
								local v27 = v16.progress[v23]
								v26 = tonumber(v27) or 0
							else
								v26 = 0
							end
							local v28 = v16.need
							local v29
							if type(v28) == "table" then
								local v30 = v16.need[v23]
								v29 = tonumber(v30)
								if not v29 then
									local v31 = v24.count
									v29 = tonumber(v31) or 1
								end
							else
								local v32 = v24.count
								v29 = tonumber(v32) or 1
							end
							if v26 >= v29 then
								continue
							end
							v19 = v19 + 1
							local v33 = p6.difficultyNeeds(v24)
							local v34 = p6.timeNeeds(v24)
							local v35
							if #v33 > 0 then
								v35 = table.find(v33, p8) == nil
							else
								v35 = false
							end
							local v36
							if v14 == nil or #v34 <= 0 then
								v36 = false
							else
								v36 = table.find(v34, v14) == nil
							end
							if not (v35 or v36) then
								continue
							end
							v22 = v22 + 1
							if v35 then
								for _, v37 in v33 do
									if table.find(v20, v37) ~= nil then
										continue
									end
									table.insert(v20, v37)
								end
							end
							if not v36 then
								continue
							end
							for _, v38 in v34 do
								if table.find(v21, v38) ~= nil then
									continue
								end
								table.insert(v21, v38)
							end
						end
						if v22 <= 0 then
							break
						end
						table.sort(v20, function(p39, p40)
							-- upvalues: (ref) v_u_2
							return (v_u_2[p39] or 9) < (v_u_2[p40] or 9)
						end)
						local v41 = v17.title
						local v42 = tostring(v41)
						local v43
						if #v20 > 0 and #v21 > 0 then
							v43 = ("%s, at %s"):format(table.concat(v20, " or "), v_u_4(v21))
						elseif #v20 > 0 then
							v43 = table.concat(v20, " or ")
						else
							v43 = "a " .. table.concat(v21, " or ") .. " raid"
						end
						local v44
						if v22 == v19 then
							v44 = ("%s needs %s"):format(v42, v43)
						else
							v44 = ("%s: one goal needs %s"):format(v42, v43)
						end
						table.insert(v10, {
							["id"] = v15,
							["title"] = v42,
							["text"] = v44
						})
					end
					return v10
				end
			end
		end
	end
	return v10
end
function v_u_1.taskNoteText(p45) -- name: taskNoteText
	-- upvalues: (copy) v_u_1
	if type(p45) ~= "table" or #p45 == 0 then
		return ""
	end
	local v46 = v_u_1.NOTE_MAX
	local v47 = #p45
	local v48 = {}
	for v49 = 1, math.min(v46, v47) do
		local v50 = p45[v49].text
		v48[v49] = tostring(v50)
	end
	if #p45 > v_u_1.NOTE_MAX then
		local v51 = #p45 - v_u_1.NOTE_MAX
		table.insert(v48, ("and %d more"):format(v51))
	end
	return table.concat(v48, "\n")
end
function v_u_1.taskKicker(p52, p53, p54, p55) -- name: taskKicker
	if type(p54) == "string" and (p54 ~= "" and (p55 ~= "ready" and p55 ~= "done")) then
		return "NOT PLAYABLE YET  \194\183  " .. p54
	else
		return p52 .. "  \194\183  " .. tostring(p53)
	end
end
function v_u_1.taskLoad(p56) -- name: taskLoad
	if p56 then
		return "NOTHING WAS LOST  \194\183  TAP TO TRY AGAIN", "Could not load your tasks"
	else
		return "", "Loading tasks..."
	end
end
function v_u_1.diffLock(p57, p58, p59) -- name: diffLock
	-- upvalues: (copy) v_u_1
	if type(p59) == "table" then
		local v60 = v_u_1.mapLock(p57, p58, p59)
		if v60 ~= nil then
			return v60
		end
	end
	if p57 ~= "Hard" then
		return {
			["short"] = "Doc\'s task PATIENT ZERO",
			["long"] = "Finish Doc\'s task PATIENT ZERO (TASKS tab). It needs Hard.",
			["status"] = "Nightmare opens with Doc\'s task PATIENT ZERO.",
			["member"] = "Your squad plays Nightmare. Doc\'s task PATIENT ZERO opens it."
		}
	end
	local v61
	if type(p58) == "table" and p58.kind == "raids" then
		local v62 = p58.need
		local v63 = tonumber(v62) or 0
		v61 = (v63 ~= v63 or v63 < 0) and 0 or math.floor(v63)
	else
		v61 = 1
	end
	if v61 <= 1 then
		return {
			["short"] = "Unlocks after your first raid",
			["long"] = "Unlocks after your first real raid. The tutorial does not count.",
			["status"] = "Hard unlocks after your first real raid.",
			["member"] = "Your squad plays Hard. You unlock it after your first raid."
		}
	end
	local v64 = p58.have
	local v65 = tonumber(v64) or 0
	local v66 = (v65 ~= v65 or v65 < 0) and 0 or math.floor(v65)
	local v67 = math.min(v66, v61)
	return {
		["short"] = ("Finish %d/%d raids"):format(v67, v61),
		["long"] = ("Finish %d raids to unlock Hard (%d done). The tutorial does not count."):format(v61, v67),
		["status"] = ("Hard unlocks after %d raids (%d done)."):format(v61, v67),
		["member"] = ("Your squad plays Hard. You need %d raids first."):format(v61)
	}
end
function v_u_1.mapLock(p68, _, p69) -- name: mapLock
	if p69.unknown == true then
		return {
			["short"] = "Loading",
			["long"] = "Your unlocks are still loading. Try again in a moment.",
			["status"] = "Your unlocks are still loading.",
			["member"] = "Your unlocks are still loading."
		}
	end
	local v70 = p69.map
	if type(v70) ~= "string" or p69.map == "" then
		return nil
	end
	local v71 = p69.map
	local v72 = tostring(v71)
	local v73 = p69.how
	local v74 = type(v73) ~= "string" and "" or p69.how
	if p69.first == true then
		if p68 == "Hard" then
			return nil
		end
		local v75 = {
			["short"] = "Defeat a boss on Hard",
			["long"] = nil,
			["status"] = "Nightmare opens with a boss on Hard.",
			["member"] = "Your squad plays Nightmare. A boss on Hard opens it."
		}
		if v74 == "" then
			v74 = ("Defeat a boss on Hard on %s to unlock Nightmare."):format(v72)
		end
		v75.long = v74
		return v75
	end
	local v76 = {
		["short"] = p68 == "Hard" and "Boss on Hard, or quests" or "Boss on Nightmare, or quests"
	}
	if v74 == "" then
		v74 = ("%s is locked on %s."):format(p68, v72)
	end
	v76.long = v74
	v76.status = ("%s is locked on %s."):format(p68, v72)
	v76.member = ("Your squad plays %s on %s. Locked for you."):format(p68, v72)
	return v76
end
function v_u_1.nameList(p77) -- name: nameList
	local v78 = {}
	if type(p77) == "table" then
		for _, v79 in p77 do
			local v80 = tostring(v79)
			local v81 = utf8.len(v80)
			if v81 == nil then
				v80 = string.sub(v80, 1, 16)
			elseif v81 > 16 then
				for v82 = #v80, 1, -1 do
					local v83 = utf8.len((string.sub(v80, 1, v82)))
					if v83 == nil or v83 > 16 then
						continue
					end
					v80 = string.sub(v80, 1, v82)
				end
			end
			table.insert(v78, v80)
		end
	end
	local v84 = #v78
	if v84 == 0 then
		return "A squad mate"
	elseif v84 == 1 then
		return v78[1]
	elseif v84 == 2 then
		return v78[1] .. " and " .. v78[2]
	elseif v84 == 3 then
		return v78[1] .. ", " .. v78[2] .. " and " .. v78[3]
	else
		return ("%s, %s and %d more"):format(v78[1], v78[2], v84 - 2)
	end
end
function v_u_1.lackLock(p85, p86, p87) -- name: lackLock
	-- upvalues: (copy) v_u_1
	local v88 = type(p85) == "table" and #p85 or 0
	local v89 = v_u_1.nameList(p85)
	local v90
	if v88 > 2 then
		v90 = ("%d squad mates"):format(v88)
	else
		v90 = v89
	end
	local v91 = v88 > 1 and "have" or "has"
	local v92 = ("%s %s %s here"):format(v90, v88 > 1 and "lack" or "lacks", p86)
	local v93 = {}
	local v94
	if v88 == 1 then
		v94 = v_u_1.nameList(p85) .. " lacks it"
	else
		v94 = ("%d mates lack it"):format(v88)
	end
	v93.short = v94
	v93.long = ("%s %s not unlocked %s on %s."):format(v89, v91, p86, p87)
	v93.status = v92
	v93.member = v92
	return v93
end
function v_u_1.memberStatus(p95) -- name: memberStatus
	if type(p95) ~= "table" then
		return nil
	end
	if p95.closed ~= true then
		if p95.diffOk == false then
			local v96 = p95.lock
			if type(v96) == "table" then
				local v97 = {
					["text"] = nil,
					["tone"] = "danger",
					["btn"] = "Locked"
				}
				local v98 = p95.lock.member
				v97.text = tostring(v98)
				return v97
			end
		end
		if p95.freeRaid == true then
			local v99 = p95.freeIn
			local v100 = tonumber(v99) or 0
			if ((v100 ~= v100 or v100 < 0) and 0 or math.floor(v100)) > 0 then
				local v101 = p95.freeIn
				local v102 = tonumber(v101) or 0
				local v103 = (v102 ~= v102 or v102 < 0) and 0 or math.floor(v102)
				return {
					["text"] = nil,
					["tone"] = "accent",
					["btn"] = nil,
					["text"] = ("Your squad uses a free raid. Yours is ready in %d:%02d."):format(v103 // 60, v103 % 60)
				}
			end
		end
		return nil
	end
	local v104 = {
		["text"] = nil,
		["tone"] = "danger",
		["btn"] = nil
	}
	local v105 = p95.closedText or "Deployments are closed."
	v104.text = tostring(v105)
	return v104
end
function v_u_1.gateWords(p106) -- name: gateWords
	return p106 == "locked" and {
		["tag"] = "Not open yet",
		["row"] = "Not open yet",
		["chip"] = "NOT OPEN YET",
		["stampT"] = "Not open yet",
		["stampS"] = "We will open it for everyone. Watch the Discord.",
		["btn"] = "Not open yet",
		["summary"] = "NOT OPEN YET"
	} or (p106 == "raids" and {
		["tag"] = "Locked",
		["row"] = "Locked",
		["chip"] = "LOCKED",
		["stampT"] = "Locked",
		["stampS"] = "Finish more raids to open it",
		["btn"] = "Locked",
		["summary"] = "LOCKED"
	} or (p106 == "test" and {
		["tag"] = "Test access",
		["row"] = "Test access",
		["chip"] = "TEST ACCESS",
		["stampT"] = "Test access",
		["stampS"] = "",
		["btn"] = "Deploy",
		["summary"] = "TEST"
	} or {
		["tag"] = "Coming soon",
		["row"] = "Coming soon",
		["chip"] = "COMING SOON",
		["stampT"] = "Coming soon",
		["stampS"] = "Not open for deployment yet",
		["btn"] = "Coming soon",
		["summary"] = "COMING SOON"
	}))
end
v_u_1.FREE_BLOCKED = "Switch off FREE RAID below to deploy with your own kit."
v_u_1.WEATHER = "Weather is random each raid"
function v_u_1.publicOnlyTip() -- name: publicOnlyTip
	return "Every raid here is public. Your squad queues together and meets other squads in the same region."
end
function v_u_1.privateTip() -- name: privateTip
	return "Your squad gets a raid of its own. No matchmaking, and no other squad can join it later. Fewer encounters with other survivors. This is not the squad setting: that one only decides who can join your squad."
end
function v_u_1.groupLine(p107) -- name: groupLine
	return (type(p107) ~= "string" or p107 == "") and "Looking for other squads" or "In your group: " .. p107 .. " (you included)"
end
function v_u_1.raidLine(p108) -- name: raidLine
	return (type(p108) ~= "string" or p108 == "") and "" or "In your raid: " .. p108
end
function v_u_1.stopHint(p109) -- name: stopHint
	return p109 and "Stop search cancels the deploy." or "Starts when the timer ends. Stop search cancels the deploy."
end
v_u_1.WAIT_AFTER = 15
function v_u_1.connectLine(p110, p111) -- name: connectLine
	-- upvalues: (copy) v_u_1
	local v112 = tonumber(p110) or 0
	local v113 = (v112 ~= v112 or v112 < 0) and 0 or math.floor(v112)
	if v113 < 5 then
		return "Starting the raid now"
	elseif v113 < v_u_1.WAIT_AFTER then
		return "Connecting to the raid server" .. (p111 or "")
	else
		return v_u_1.waitLine(v113)
	end
end
function v_u_1.waitLine(p114) -- name: waitLine
	-- upvalues: (copy) v_u_1
	local v115 = tonumber(p114) or 0
	local v116 = (v115 ~= v115 or v115 < 0) and 0 or math.floor(v115)
	if v116 < v_u_1.WAIT_AFTER then
		return nil
	else
		return ("Still working (%d s). Nothing is lost."):format(v116)
	end
end
function v_u_1.radioRow(p117, p118, p119) -- name: radioRow
	return p118 and "Always open" or (not p117 and "Needs a radio, level 1" or tostring(p119 or ""))
end
function v_u_1.radioNote(p120, p121, p122) -- name: radioNote
	if p120 then
		local v123 = tonumber(p121) or 0
		return ("All %d exits are open every raid, each with its condition."):format((v123 ~= v123 or v123 < 0) and 0 or math.floor(v123))
	else
		local v124 = tonumber(p122) or 0
		return ((v124 ~= v124 or v124 < 0) and 0 or math.floor(v124)) >= 1 and "Each raid opens the roadblock plus 2 to 3 of these. The raid decides which." or "Each raid opens the roadblock plus 2 to 3 other exits. A radio in your hideout tells you what they are."
	end
end
return v_u_1