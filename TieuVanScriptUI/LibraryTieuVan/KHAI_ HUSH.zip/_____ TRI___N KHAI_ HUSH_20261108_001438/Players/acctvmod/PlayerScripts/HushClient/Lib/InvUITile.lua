-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITile

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v_u_3:WaitForChild("Theme"))
local v_u_5 = require(v_u_3:WaitForChild("Items"))
local v_u_6 = require(v_u_3:WaitForChild("Grid"))
local v_u_7 = require(script.Parent:WaitForChild("ItemIcons"))
local v_u_8 = require(script.Parent:WaitForChild("InvUILock"))
local v_u_9 = require(script.Parent:WaitForChild("InvUISlotHint"))
local v_u_10 = v_u_4.color
local v_u_11 = {
	["hint"] = v_u_9
}
local v_u_12 = {}
function v_u_11.setWishlist(p13) -- name: setWishlist
	-- upvalues: (ref) v_u_12
	v_u_12 = p13 or {}
end
function v_u_11.isWished(p14) -- name: isWished
	-- upvalues: (ref) v_u_12
	local v15
	if p14 == nil then
		v15 = false
	else
		v15 = v_u_12[p14] == true
	end
	return v15
end
local v_u_16 = {}
local v_u_17 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_18 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_11.setFocus(p19) -- name: setFocus
	-- upvalues: (ref) v_u_16, (copy) v_u_17
	v_u_16 = p19 or {}
	local v20 = {}
	for _, v21 in v_u_17 do
		table.insert(v20, v21)
	end
	for _, v22 in v20 do
		pcall(v22)
	end
end
function v_u_11.isFocus(p23) -- name: isFocus
	-- upvalues: (ref) v_u_16
	local v24
	if p23 == nil then
		v24 = false
	else
		v24 = v_u_16[p23] == true
	end
	return v24
end
function v_u_11.focusFrame() -- name: focusFrame
	-- upvalues: (copy) v_u_18
	for v25 in v_u_18 do
		if not (v25.Parent and (v25:IsA("GuiObject") and v25.Visible)) then
			continue
		end
		return v25
	end
	return nil
end
local v_u_26 = nil
local v_u_27 = nil
local function v_u_32(p28, p29) -- name: gunLine
	-- upvalues: (ref) v_u_27
	if v_u_27 == nil then
		local v30, v31 = pcall(function()
			return require((script.Parent:WaitForChild("InvUIGunsmith", 3)))
		end)
		if not v30 or type(v31) ~= "table" then
			v31 = false
		end
		v_u_27 = v31
	end
	if v_u_27 then
		return v_u_27.tipBody(p28, p29)
	else
		return p28
	end
end
local v_u_33 = nil
local function v_u_39() -- name: sellPerkMul
	-- upvalues: (copy) v_u_3
	local v_u_34 = v_u_3:FindFirstChild("PerkStats")
	local v_u_35 = game:GetService("Players").LocalPlayer
	if not (v_u_34 and v_u_35) then
		return 1
	end
	local v37, v38 = pcall(function()
		-- upvalues: (copy) v_u_34, (copy) v_u_35
		local v36 = require(v_u_34)
		return v36.priceMul(v36.fromPlayer(v_u_35), "sell")
	end)
	return (not v37 or (type(v38) ~= "number" or (v38 ~= v38 or v38 <= 0))) and 1 or v38
end
local v_u_40 = nil
local v_u_41 = nil
local function v_u_49(p42) -- name: weaponDef
	-- upvalues: (ref) v_u_41, (copy) v_u_3
	if not p42 then
		return nil
	end
	if v_u_41 == nil then
		local v_u_43 = v_u_3:FindFirstChild("Weapons")
		local v44, v45 = pcall(function()
			-- upvalues: (copy) v_u_43
			return require(v_u_43)
		end)
		if not v44 or type(v45) ~= "table" then
			v45 = false
		end
		v_u_41 = v45
	end
	if v_u_41 and v_u_41.get then
		local v46 = v_u_41.get
		local v47, v48 = pcall(v46, p42)
		if v47 then
			return v48
		end
	end
	return nil
end
local v_u_50 = nil
local function v_u_54() -- name: attachWear
	-- upvalues: (ref) v_u_50, (copy) v_u_3
	if v_u_50 == nil then
		local v_u_51 = v_u_3:FindFirstChild("AttachWear")
		local v52, v53 = pcall(function()
			-- upvalues: (copy) v_u_51
			return require(v_u_51)
		end)
		if not v52 or type(v53) ~= "table" then
			v53 = false
		end
		v_u_50 = v53
	end
	return v_u_50 or nil
end
function v_u_11.shownDur(p55, p56) -- name: shownDur
	-- upvalues: (copy) v_u_5, (copy) v_u_54
	if type(p55) ~= "table" then
		return nil
	end
	local v57 = p56 or v_u_5.get(p55.id)
	if v57 and v57.equip == "ears" then
		return nil
	end
	local v58 = p55.dur
	if type(v58) == "number" then
		local v59 = p55.dur
		return math.clamp(v59, 0, 1)
	end
	local v60 = v_u_54()
	local v61 = p56 or v_u_5.get(p55.id)
	return v60 and v60.wears(v61) and 1 or nil
end
local function v_u_67(p62) -- name: wearingMod
	-- upvalues: (copy) v_u_54, (copy) v_u_5
	local v63 = v_u_54()
	if v63 and type(p62) == "table" then
		local v64 = p62.mods
		if type(v64) == "table" then
			for _, v65 in p62.mods do
				local v66
				if type(v65) == "table" then
					v66 = v_u_5.get(v65.id)
				else
					v66 = false
				end
				if not (v66 and v63.wears(v66)) then
					continue
				end
				return v65, v66
			end
			return nil, nil
		end
	end
	return nil, nil
end
local function v_u_79(p68) -- name: weaponsFor
	-- upvalues: (copy) v_u_49, (ref) v_u_41
	local v69 = {}
	if not p68 then
		return v69
	end
	v_u_49("pistol_g17")
	if v_u_41 and v_u_41.all then
		local v70 = v_u_41.all
		local v71, v72 = pcall(v70)
		if v71 and type(v72) == "table" then
			for _, v73 in v72 do
				if type(v73) ~= "table" or (v73.kind ~= "firearm" or v73.ammoKey ~= p68) then
					continue
				end
				table.insert(v69, v73)
			end
		end
	end
	table.sort(v69, function(p74, p75)
		local v76 = p74.id
		local v77 = tostring(v76)
		local v78 = p75.id
		return v77 < tostring(v78)
	end)
	return v69
end
local function v_u_84(p80) -- name: commas
	local v81 = math.abs(p80) + 0.5
	local v82 = math.floor(v81)
	local v83 = tostring(v82):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if v83:sub(1, 1) == "," then
		v83 = v83:sub(2)
	end
	return (p80 < 0 and "-" or "") .. v83
end
function v_u_11.money(p85) -- name: money
	-- upvalues: (copy) v_u_84
	return "$" .. v_u_84(p85)
end
function v_u_11.kg(p86) -- name: kg
	return string.format("%.1f kg", p86)
end
function v_u_11.pairStats(p_u_87) -- name: pairStats
	-- upvalues: (copy) v_u_3
	local function v88()
		-- upvalues: (ref) v_u_3, (copy) p_u_87
		return require((v_u_3:WaitForChild("TwinRules", 3))).apply(p_u_87)
	end
	local v89, v90 = pcall(v88)
	if v89 and type(v90) == "table" then
		return v90
	else
		return p_u_87
	end
end
function v_u_11.pairLines(p91) -- name: pairLines
	-- upvalues: (copy) v_u_10
	if type(p91) ~= "table" or p91.tw ~= true then
		return {}
	end
	local v92 = p91.items
	local v93
	if type(v92) == "table" then
		v93 = p91.items[1]
	else
		v93 = nil
	end
	local v94 = {}
	local v95 = { "Pair", "Fires in turn, reloads both", v_u_10.accent }
	local v96 = {}
	local v97 = "Magazines"
	local v98
	if type(p91) == "table" then
		local v99 = p91.ammo
		if type(v99) == "number" then
			local v100 = p91.ammo
			local v101 = math.floor(v100)
			v98 = tostring(v101)
		else
			v98 = "?"
		end
	else
		v98 = "?"
	end
	local v102 = " + "
	local v103
	if type(v93) == "table" then
		local v104 = v93.ammo
		if type(v104) == "number" then
			local v105 = v93.ammo
			local v106 = math.floor(v105)
			v103 = tostring(v106)
		else
			v103 = "?"
		end
	else
		v103 = "?"
	end
	__set_list(v96, 1, {v97, v98 .. v102 .. v103 .. " rounds"})
	__set_list(v94, 1, {v95, v96, { "Split", "At the Gunsmith, free" }})
	return v94
end
function v_u_11.value(p107) -- name: value
	-- upvalues: (copy) v_u_5, (copy) v_u_54, (copy) v_u_11
	local v108 = v_u_5.get(p107.id)
	if not v108 then
		return 0
	end
	local v109 = v108.value
	local v110 = p107.n or 1
	local v111 = v109 * math.max(1, v110)
	local v112 = v_u_54()
	local v113 = p107.dur
	if type(v113) == "number" and (v108.category == "armor" or (v108.category == "helmet" or (v108.category == "firearm" or (v108.category == "melee" or (v108.uses or v112 and v112.wears(v108)))))) then
		local v114 = p107.dur
		v111 = v111 * (math.clamp(v114, 0, 1) * 0.65 + 0.35)
	end
	local v115 = p107.mods
	if type(v115) == "table" then
		for _, v116 in p107.mods do
			if type(v116) ~= "table" then
				continue
			end
			v111 = v111 + v_u_11.value(v116)
		end
	end
	local v117 = p107.items
	for _, v118 in type(v117) ~= "table" and {} or p107.items do
		v111 = v111 + v_u_11.value(v118)
	end
	local v119 = v111 + 0.5
	return math.floor(v119)
end
function v_u_11.weight(p120) -- name: weight
	-- upvalues: (copy) v_u_5, (copy) v_u_11
	local v121 = v_u_5.get(p120.id)
	if not v121 then
		return 0
	end
	local v122 = v121.weight
	local v123 = p120.n or 1
	local v124 = v122 * math.max(1, v123)
	local v125 = p120.items
	for _, v126 in type(v125) ~= "table" and {} or p120.items do
		v124 = v124 + v_u_11.weight(v126)
	end
	return v124
end
local function v_u_130(p127) -- name: pct
	local v128 = string.format
	local v129 = p127 * 100 + 0.5
	return v128("%d%%", (math.floor(v129)))
end
local v_u_131 = {
	["9mm"] = "9MM",
	["45"] = ".45",
	["357"] = ".357",
	["12ga"] = "12 GA",
	["556"] = "5.56",
	["762"] = "7.62",
	["308"] = ".308"
}
function v_u_11.caliberTag(p132) -- name: caliberTag
	-- upvalues: (copy) v_u_131
	if type(p132) == "table" and p132.category == "firearm" then
		local v133 = p132.caliber
		if type(v133) == "string" then
			return v_u_131[p132.caliber] or string.upper(p132.caliber)
		end
	end
	return nil
end
function v_u_11.caliberLabel(p134) -- name: caliberLabel
	-- upvalues: (copy) v_u_5, (copy) v_u_11
	if type(p134) == "table" and p134.category == "firearm" then
		local v135 = p134.caliber
		if type(v135) == "string" then
			return v_u_5.CALIBER_LABEL and v_u_5.CALIBER_LABEL[p134.caliber] or v_u_11.caliberTag(p134)
		end
	end
	return nil
end
function v_u_11.statLines(p_u_136, p137) -- name: statLines
	-- upvalues: (copy) v_u_5, (copy) v_u_49, (copy) v_u_11, (copy) v_u_67, (copy) v_u_54, (ref) v_u_41, (copy) v_u_10, (ref) v_u_33, (ref) v_u_40, (copy) v_u_130
	local v138 = v_u_5.get(p_u_136.id)
	local v139 = {}
	if not v138 then
		return v139
	end
	local v140 = v138.category
	if v140 == "firearm" then
		local v_u_141 = v_u_49(v138.weaponId or v138.id)
		if v_u_141 and p_u_136.tw == true then
			v_u_141 = v_u_11.pairStats(v_u_141)
		end
		local v142 = {}
		local v143 = "Caliber"
		local v144 = v_u_5.CALIBER_LABEL and v_u_5.CALIBER_LABEL[v138.caliber]
		if not v144 then
			local v145 = string.upper
			local v146 = v138.caliber or "?"
			v144 = v145((tostring(v146)))
		end
		__set_list(v142, 1, {v143, v144})
		table.insert(v139, v142)
		if v_u_141 then
			if v_u_141.damage and not v_u_141.flare then
				local v147 = v_u_141.damage
				local v148 = tostring(v147) .. (not v_u_141.pellets and "" or " x" .. v_u_141.pellets)
				local v149 = p_u_136.ammo
				local v150 = type(v149) == "number" and p_u_136.ammo > 0 and p_u_136.ammoId
				if v150 then
					v150 = v_u_5.get(p_u_136.ammoId)
				end
				if v150 then
					local v151 = v150.dmgMul
					if type(v151) == "number" then
						local v152 = v150.dmgMul - 1
						if math.abs(v152) > 0.001 then
							local v153 = string.format
							local v154 = v150.ammoType or ""
							local v155 = tostring(v154)
							local v156 = v_u_141.damage * v150.dmgMul + 0.5
							v148 = v148 .. v153(" (%s %d)", v155, (math.floor(v156)))
						end
					end
				end
				table.insert(v139, { "Damage", v148 })
			end
			if v_u_141.rpm then
				local v157 = {}
				local v158 = v_u_141.rpm
				__set_list(v157, 1, {"Fire rate", tostring(v158) .. " rpm"})
				table.insert(v139, v157)
			end
			if v_u_141.noise then
				local v159 = v_u_141.noise
				local v160 = v_u_67(p_u_136)
				local v161 = v_u_54()
				if v160 and (v161 and (v_u_41 and v_u_41.stats)) then
					local v162 = v_u_41.stats
					local v163 = v_u_141.id
					local v164 = p_u_136.mods
					local v165, v166 = pcall(v162, v163, v164)
					if v165 and (type(v166) == "table" and v166.suppressed) then
						local v167 = v166.noise
						if type(v167) == "number" then
							v159 = v161.noise(v166.noise, v_u_141.noise, v161.durOf(v160))
						end
					end
				end
				local v168 = { "Noise", tostring(v159) .. " m", v_u_10.accent }
				table.insert(v139, v168)
			end
			local v_u_169
			if p137 then
				if v_u_33 == nil then
					local v170, v171 = pcall(function()
						return require((script.Parent:WaitForChild("InvUIWeaponStats", 3)))
					end)
					if not v170 or type(v171) ~= "table" then
						v171 = false
					end
					v_u_33 = v171
				end
				v_u_169 = v_u_33 or nil
			else
				v_u_169 = nil
			end
			if v_u_169 then
				local function v177()
					-- upvalues: (copy) v_u_169, (ref) v_u_141, (copy) p_u_136, (ref) v_u_41
					local v172 = v_u_169.rows
					local v173 = v_u_169.statsFor
					local v174 = v_u_141
					local v175 = p_u_136.mods
					local v176
					if v_u_41 then
						v176 = v_u_41.stats
					else
						v176 = nil
					end
					return v172(v173(v174, v175, v176))
				end
				local v178, v179 = pcall(v177)
				if v178 and type(v179) == "table" then
					for _, v180 in v179 do
						table.insert(v139, v180)
					end
				end
			end
			if p137 then
				local v181 = v_u_141.fixedScope == true
				if not v181 and (v_u_41 and v_u_41.attachment) then
					local v182 = p_u_136.mods
					if type(v182) == "table" then
						for _, v183 in p_u_136.mods do
							local v184 = v_u_41.attachment
							local v185
							if type(v183) == "table" then
								v185 = v183.id
							else
								v185 = nil
							end
							local v186, v187 = pcall(v184, v185)
							if not v186 or (type(v187) ~= "table" or v187.mount ~= "Sight") then
								continue
							end
							v181 = true
						end
					end
				end
				local v188 = game:GetService("Players").LocalPlayer
				local v189
				if v181 and v188 then
					v189 = v188:GetAttribute("PerkOpticNote")
				else
					v189 = nil
				end
				if type(v189) == "string" and v189 ~= "" then
					local v190 = { "Optic Drill", (string.gsub(v189, "^OPTIC DRILL: ", "")) }
					table.insert(v139, v190)
				end
			end
		end
		local v191 = v_u_141 and v_u_141.capacity or v138.capacity
		if v_u_141 and (v_u_41 and v_u_41.stats) then
			local v192 = p_u_136.mods
			if type(v192) == "table" then
				local v193 = v_u_41.stats
				local v194 = v_u_141.id
				local v195 = p_u_136.mods
				local v196, v197 = pcall(v193, v194, v195)
				if v196 and type(v197) == "table" then
					local v198 = v197.capacity
					if type(v198) == "number" then
						v191 = v197.capacity
					end
				end
			end
		end
		local v199 = p_u_136.ammo
		if type(v199) == "number" then
			local v200 = p_u_136.ammoId
			if v200 then
				v200 = v_u_5.get(p_u_136.ammoId)
			end
			local v201 = { "Loaded", string.format("%d / %s%s", p_u_136.ammo, tostring(v191 or "?"), not v200 and "" or "  " .. v200.short) }
			table.insert(v139, v201)
		elseif v191 then
			local v202 = { "Capacity", (tostring(v191)) }
			table.insert(v139, v202)
		end
		local v203 = p_u_136.mods
		if type(v203) == "table" then
			for v204, v205 in p_u_136.mods do
				local v206
				if type(v205) == "table" then
					v206 = v_u_5.get(v205.id)
				else
					v206 = false
				end
				if not v206 then
					continue
				end
				local v207 = {}
				local v208 = string.upper
				local v209 = tostring(v204)
				local v210 = v208((string.sub(v209, 1, 1)))
				local v211 = tostring(v204)
				__set_list(v207, 1, {v210 .. string.sub(v211, 2), v206.name, v_u_10.info})
				table.insert(v139, v207)
			end
			local v212 = v_u_67(p_u_136)
			local v213 = v_u_54()
			if v212 and v213 then
				local v214 = v213.durOf(v212)
				local v215 = v213.stage(v214)
				local v216 = {}
				local v217 = "Suppressor"
				local v218 = string.format
				local v219 = v214 * 100 + 0.5
				local v220 = v218("%d %%  %s", math.floor(v219), v213.label(v214))
				local v221
				if v215 >= 3 then
					v221 = v_u_10.danger
				elseif v215 >= 1 then
					v221 = v_u_10.accent
				else
					v221 = v_u_10.success
				end
				__set_list(v216, 1, {v217, v220, v221})
				table.insert(v139, v216)
			end
		end
	elseif v140 == "melee" then
		local v222 = v_u_49(v138.weaponId or v138.id)
		if v222 and v222.damage then
			local v223 = {}
			local v224 = v222.damage
			__set_list(v223, 1, {"Damage", (tostring(v224))})
			table.insert(v139, v223)
		end
		if v222 and v222.staminaCost then
			local v225 = {}
			local v226 = v222.staminaCost
			__set_list(v225, 1, {"Stamina", (tostring(v226))})
			table.insert(v139, v225)
		end
	elseif v140 == "ammo" then
		for _, v227 in v_u_11.ammoLines(v138) do
			table.insert(v139, v227)
		end
	elseif v140 == "armor" or v140 == "helmet" then
		if v138.armorClass then
			local v228 = {}
			local v229 = v138.armorClass
			__set_list(v228, 1, {"Armor class", (tostring(v229))})
			table.insert(v139, v228)
		end
		if v138.zombieBiteBlock then
			local v230 = {}
			local v231 = v138.equip == "legs" and "Leg bite block" or "Bite block"
			local v232 = v138.zombieBiteBlock
			local v233 = string.format
			local v234 = v232 * 100 + 0.5
			__set_list(v230, 1, {v231, v233("%d%%", (math.floor(v234))), v_u_10.infection})
			table.insert(v139, v230)
		end
		if v138.gasMask == true then
			local v235 = { "Mist filter", "Yes", v_u_10.success }
			table.insert(v139, v235)
		end
		if v138.stepNoiseMul then
			local v236 = {}
			local v237 = 1 - v138.stepNoiseMul
			local v238 = string.format
			local v239 = v237 * 100 + 0.5
			__set_list(v236, 1, {"Footstep noise", "-" .. v238("%d%%", (math.floor(v239))), v_u_10.success})
			table.insert(v139, v236)
		end
		if v138.legProtect then
			local v240 = {}
			local v241 = v138.legProtect
			local v242 = string.format
			local v243 = v241 * 100 + 0.5
			__set_list(v240, 1, {"Leg protection", v242("%d%%", (math.floor(v243))), v_u_10.success})
			table.insert(v139, v240)
		end
		local v244 = v138.hearing
		if type(v244) == "table" then
			local v245 = {}
			local v246 = "Gunfire hearing damage"
			local v247
			if v244.trauma <= 0 then
				v247 = "none"
			else
				local v248 = 1 - v244.trauma
				local v249 = string.format
				local v250 = v248 * 100 + 0.5
				v247 = "-" .. v249("%d%%", (math.floor(v250)))
			end
			__set_list(v245, 1, {v246, v247, v_u_10.success})
			table.insert(v139, v245)
			if (v244.boost or 1) > 1.01 then
				local v251 = {}
				local v252 = v244.boost - 1
				local v253 = string.format
				local v254 = v252 * 100 + 0.5
				__set_list(v251, 1, {"Zombies and steps", "heard +" .. v253("%d%%", (math.floor(v254))) .. " further", v_u_10.success})
				table.insert(v139, v251)
			elseif (v244.boost or 1) < 0.99 then
				local v255 = {}
				local v256 = 1 - v244.boost
				local v257 = string.format
				local v258 = v256 * 100 + 0.5
				__set_list(v255, 1, {"Zombies and steps", "heard " .. v257("%d%%", (math.floor(v258))) .. " less", v_u_10.accent})
				table.insert(v139, v255)
			end
			if v244.amp then
				local v259 = {}
				local v260 = v244.amp[3]
				__set_list(v259, 1, {"Quiet sounds", "+" .. tostring(v260) .. " dB, loud ones held down", v_u_10.success})
				table.insert(v139, v259)
			elseif v244.eq then
				local v261 = { "Everything around you", "quieter and duller", v_u_10.accent }
				table.insert(v139, v261)
			end
		end
		if v138.grid and v138.grid.slots then
			local v262 = { "Pouches", v_u_5.gridCells(v138) .. " cells: " .. v_u_5.pouchSummary(v138), v_u_10.accent }
			table.insert(v139, v262)
		elseif v138.grid then
			local v263 = { "Pouches", v138.grid.w .. " x " .. v138.grid.h }
			table.insert(v139, v263)
		end
		local v264 = p_u_136.items
		if #(type(v264) ~= "table" and {} or p_u_136.items) > 0 then
			local v265 = {}
			local v266 = p_u_136.items
			local v267 = #(type(v266) ~= "table" and {} or p_u_136.items)
			local v268 = p_u_136.items
			__set_list(v265, 1, {"Inside", v267 .. (#(type(v268) ~= "table" and {} or p_u_136.items) == 1 and " item" or " items"), v_u_10.accent})
			table.insert(v139, v265)
		end
	elseif v140 == "bag" or v140 == "secure" then
		if v138.grid then
			local v269 = { "Capacity", v138.grid.w .. " x " .. v138.grid.h .. "  (" .. v138.grid.w * v138.grid.h .. " cells)" }
			table.insert(v139, v269)
		end
		local v270 = p_u_136.items
		if #(type(v270) ~= "table" and {} or p_u_136.items) > 0 then
			local v271 = {}
			local v272 = p_u_136.items
			local v273 = #(type(v272) ~= "table" and {} or p_u_136.items)
			local v274 = p_u_136.items
			__set_list(v271, 1, {"Inside", v273 .. (#(type(v274) ~= "table" and {} or p_u_136.items) == 1 and " item" or " items"), v_u_10.accent})
			table.insert(v139, v271)
		end
	elseif v140 == "medical" and v138.use then
		local v275 = v138.use
		if v275.heal then
			local v276 = {}
			local v277 = v275.heal
			__set_list(v276, 1, {"Heals", tostring(v277) .. " HP", v_u_10.success})
			table.insert(v139, v276)
		end
		if v275.stopsBleeding then
			local v278 = { "Stops bleeding", "Yes", v_u_10.success }
			table.insert(v139, v278)
		end
		if v275.fixesFracture then
			local v279 = { "Fixes fracture", "Yes", v_u_10.success }
			table.insert(v139, v279)
		end
		if v275.cure then
			local v280 = { "Cures infection", "Fully", v_u_10.infection }
			table.insert(v139, v280)
		elseif v275.infectionDelay then
			local v281 = {}
			local v282 = v275.infectionDelay
			__set_list(v281, 1, {"Delays infection", tostring(v282) .. " s", v_u_10.infection})
			table.insert(v139, v281)
		end
		local v283 = v275.staminaBuff
		if type(v283) == "number" and v275.staminaBuff > 0 then
			local v284 = v275.staminaDrainMul
			local v285 = type(v284) ~= "number" and 1 or v275.staminaDrainMul
			local v286 = {}
			local v287 = string.format
			local v288 = 1 - v285
			local v289 = string.format
			local v290 = v288 * 100 + 0.5
			__set_list(v286, 1, {"Sprint drain", v287("-%s for %d:%02d", v289("%d%%", (math.floor(v290))), v275.staminaBuff // 60, v275.staminaBuff % 60), v_u_10.success})
			table.insert(v139, v286)
		end
		if v275.time then
			local v291 = { "Use time", string.format("%.1f s", v275.time) }
			table.insert(v139, v291)
		end
	elseif v140 == "attachment" then
		if v138.slot then
			local v292 = { "Slot", string.upper(v138.slot) }
			table.insert(v139, v292)
		end
		if v_u_40 == nil then
			local v293, v294 = pcall(function()
				return require((script.Parent:WaitForChild("InvUIWhy", 3)))
			end)
			if not v293 or type(v294) ~= "table" then
				v294 = false
			end
			v_u_40 = v294
		end
		local v295 = v_u_40 or nil
		if v295 then
			local v296 = v295.fitsLine
			local v297 = v138.slot
			local v298 = v138.fits
			local function v301(p299)
				-- upvalues: (ref) v_u_5
				local v300 = v_u_5.get(p299)
				if v300 then
					return v300.short
				else
					return nil
				end
			end
			local v302, v303 = pcall(v296, v297, v298, v301)
			if v302 and type(v303) == "table" then
				local v304 = {
					v303[1],
					v303[2],
					v_u_10.info,
					["wide"] = true
				}
				table.insert(v139, v304)
			end
		end
		local v305 = v138.mods or {}
		local v306 = v_u_54()
		if v306 and v306.wears(v138) then
			local v307 = v306.durOf(p_u_136)
			local v308 = v306.stage(v307)
			local v309
			if v308 >= 3 then
				v309 = v_u_10.danger
			elseif v308 >= 1 then
				v309 = v_u_10.accent
			else
				v309 = v_u_10.success
			end
			local v310 = { "Condition", v306.meter(v307, 10), v309 }
			table.insert(v139, v310)
			local v311 = { "Suppression", v306.label(v307), v309 }
			table.insert(v139, v311)
			local v312 = { "Rated life", string.format("~%d shots", v138.wearShots), v_u_10.text2 }
			table.insert(v139, v312)
		elseif v305.noiseMul then
			local v313 = {}
			local v314 = v305.noiseMul
			local v315 = string.format
			local v316 = v314 * 100 + 0.5
			__set_list(v313, 1, {"Noise", v315("%d%%", (math.floor(v316))), v_u_10.success})
			table.insert(v139, v313)
		end
		if v305.recoilMul then
			local v317 = { "Recoil", v_u_130(v305.recoilMul) }
			table.insert(v139, v317)
		end
		if v138.slot == "mag" then
			local v318 = v138.fits
			if type(v318) == "table" then
				for _, v323 in v138.fits do
					local v320 = v_u_49(v323)
					local v321 = v_u_5.get(v323)
					if not (v320 and (v320.extCapacity and v320.capacity)) then
						continue
					end
					local v322 = {}
					if v321 then
						local v323 = v321.short
					end
					__set_list(v322, 1, {v323, string.format("%d rds (+%d)", v320.extCapacity, v320.extCapacity - v320.capacity), v_u_10.success})
					table.insert(v139, v322)
				end
			end
		end
	elseif v140 == "throwable" and v138.throw then
		local v324 = {}
		local v325 = v138.throw.noise
		__set_list(v324, 1, {"Noise", tostring(v325) .. " m", v_u_10.accent})
		table.insert(v139, v324)
		if v138.throw.damage then
			local v326 = {}
			local v327 = v138.throw.damage
			__set_list(v326, 1, {"Damage", (tostring(v327))})
			table.insert(v139, v326)
		end
	elseif v140 == "key" or v138.opens then
		local v328 = {}
		local v329 = v138.opensLabel or (v138.opens or "?")
		__set_list(v328, 1, {"Opens", (tostring(v329))})
		table.insert(v139, v328)
		local v330, v331 = v_u_5.usesLeft(p_u_136)
		if v330 and v331 then
			local v332 = {}
			local v333 = "Uses"
			local v334 = v331 == 1 and "Single use" or string.format("%d of %d left", v330, v331)
			local v335
			if v330 <= 1 then
				v335 = v_u_10.accent
			else
				v335 = nil
			end
			__set_list(v332, 1, {v333, v334, v335})
			table.insert(v139, v332)
		end
		if v138.lockTier == "reinforced" then
			local v336 = { "Door", "Reinforced", v_u_10.accent }
			table.insert(v139, v336)
			local v337 = { "Crowbar / kick", "No", v_u_10.danger }
			table.insert(v139, v337)
		elseif v138.lockTier == "secure" then
			table.insert(v139, { "Door", "Secured" })
			local v338 = { "Crowbar", "6 s, loud", v_u_10.accent }
			table.insert(v139, v338)
		end
	end
	local v339 = v_u_11.shownDur(p_u_136, v138)
	if v339 and not v138.uses then
		local v340 = {}
		local v341 = "Durability"
		local v342 = string.format
		local v343 = v339 * 100 + 0.5
		local v344 = v342("%d%%", (math.floor(v343)))
		local v345
		if v339 < 0.3 then
			v345 = v_u_10.danger
		elseif v339 < 0.6 then
			v345 = v_u_10.accent
		else
			v345 = nil
		end
		__set_list(v340, 1, {v341, v344, v345})
		table.insert(v139, v340)
	end
	return v139
end
function v_u_11.ammoLines(p346) -- name: ammoLines
	-- upvalues: (copy) v_u_5, (copy) v_u_79, (copy) v_u_10
	local v347 = {}
	if type(p346) ~= "table" or p346.category ~= "ammo" then
		return v347
	end
	local v348 = {}
	local v349 = "Caliber"
	local v350 = v_u_5.CALIBER_LABEL and v_u_5.CALIBER_LABEL[p346.caliber]
	if not v350 then
		local v351 = string.upper
		local v352 = p346.caliber or "?"
		v350 = v351((tostring(v352)))
	end
	__set_list(v348, 1, {v349, v350})
	table.insert(v347, v348)
	local v353 = v_u_5.AMMO_TYPES or {}
	local v354 = p346.ammoType
	if v354 then
		v354 = v353[p346.ammoType]
	end
	local v355 = {}
	local v356 = "Type"
	local v357
	if v354 then
		v357 = v354.long
	else
		local v358 = p346.ammoType
		if not v358 then
			local v359 = p346.tier or 1
			v358 = "Tier " .. tostring(v359)
		end
		v357 = tostring(v358)
	end
	__set_list(v355, 1, {v356, v357})
	table.insert(v347, v355)
	local v360 = v_u_79(p346.caliber)
	local v361 = p346.dmgMul
	local v362 = type(v361) ~= "number" and 1 or p346.dmgMul
	if #v360 > 0 then
		local v363 = {}
		for _, v364 in v360 do
			local v365 = v364.name or v364.id
			local v366 = tostring(v365)
			table.insert(v363, v366)
		end
		local v367 = { "Fits", table.concat(v363, ", "), v_u_10.info }
		table.insert(v347, v367)
		for _, v368 in v360 do
			local v369 = v368.damage
			if type(v369) ~= "number" or v368.flare then
				continue
			end
			local v370 = v_u_5.get(v368.id)
			local v371
			if #v360 > 1 then
				local v372 = "Per hit  \194\183  "
				local v373
				if v370 then
					v373 = v370.short
				else
					local v374 = v368.name
					v373 = tostring(v374)
				end
				v371 = v372 .. v373
			else
				v371 = "Per hit"
			end
			local v375 = v368.damage * v362 + 0.5
			local v376 = math.floor(v375)
			local v377 = { v371, tostring(v376) .. (not v368.pellets and "" or " x" .. v368.pellets) }
			table.insert(v347, v377)
		end
	end
	local v378 = p346.flareTip
	if type(v378) == "string" then
		local v379 = { "Effect", p346.flareTip, v_u_10.info }
		table.insert(v347, v379)
		return v347
	end
	if v362 > 1.001 then
		local v380 = {}
		local v381 = string.format
		local v382 = (v362 - 1) * 100 + 0.5
		__set_list(v380, 1, {"Flesh damage", v381("+%d%%", (math.floor(v382))), v_u_10.success})
		table.insert(v347, v380)
	elseif v362 < 0.999 then
		local v383 = {}
		local v384 = string.format
		local v385 = (1 - v362) * 100 + 0.5
		__set_list(v383, 1, {"Flesh damage", v384("-%d%%", (math.floor(v385))), v_u_10.danger})
		table.insert(v347, v383)
	else
		table.insert(v347, { "Flesh damage", "Standard" })
	end
	local v386 = p346.pen
	if type(v386) == "number" then
		local v387 = p346.pen
		local v388 = math.clamp(v387, 0, 1)
		local v389 = {}
		local v390 = "Ignores armor"
		local v391 = string.format
		local v392 = v388 * 100 + 0.5
		local v393 = v391("%d%% (%s)", math.floor(v392), v388 >= 0.7 and "high" or (v388 >= 0.4 and "medium" or (v388 >= 0.2 and "low" or "very low")))
		local v394
		if v388 >= 0.7 then
			v394 = v_u_10.success
		elseif v388 < 0.2 then
			v394 = v_u_10.danger
		else
			v394 = nil
		end
		__set_list(v389, 1, {v390, v393, v394})
		table.insert(v347, v389)
	end
	return v347
end
function v_u_11.ammoSubtitle(p395) -- name: ammoSubtitle
	-- upvalues: (copy) v_u_5, (copy) v_u_79
	local v396 = v_u_5.get(p395)
	if not v396 or v396.category ~= "ammo" then
		return nil
	end
	local v397 = {}
	for _, v398 in v_u_79(v396.caliber) do
		local v399 = v398.name or v398.id
		local v400 = tostring(v399)
		table.insert(v397, v400)
	end
	local v401 = v396.dmgMul
	local v402 = type(v401) ~= "number" and 1 or v396.dmgMul
	local v403 = {}
	if #v397 > 0 then
		local v404 = table.concat
		table.insert(v403, v404(v397, ", "))
	end
	if v402 > 1.001 then
		local v405 = string.format
		local v406 = (v402 - 1) * 100 + 0.5
		local v407 = math.floor(v406)
		table.insert(v403, v405("+%d%% flesh", v407))
	elseif v402 < 0.999 then
		local v408 = string.format
		local v409 = (1 - v402) * 100 + 0.5
		local v410 = math.floor(v409)
		table.insert(v403, v408("-%d%% flesh", v410))
	end
	local v411 = v396.pen
	if type(v411) == "number" then
		local v412 = string.format
		local v413 = v396.pen
		local v414 = math.clamp(v413, 0, 1) * 100 + 0.5
		local v415 = math.floor(v414)
		table.insert(v403, v412("ignores %d%% armor", v415))
	end
	return table.concat(v403, "  \194\183  ")
end
local function v_u_449(p_u_416, p_u_417, p418) -- name: compareLines
	-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_130, (copy) v_u_49, (ref) v_u_33, (ref) v_u_41
	local v_u_419 = {}
	local v420 = v_u_5.get(p_u_416.id)
	local v_u_421 = v_u_5.get(p_u_417.id)
	if not v420 or (not v_u_421 or p_u_417.uid == p_u_416.uid) then
		return v_u_419
	end
	local function v434(p422, p423, p424, p425, p426) -- name: row
		-- upvalues: (copy) v_u_419, (copy) v_u_421, (ref) v_u_10
		if p423 and (p424 and p423 ~= p424) then
			local v427
			if p425 then
				v427 = p424 < p423
			else
				v427 = p423 < p424
			end
			local v428 = p426 or tostring
			local v429 = v_u_419
			local v430 = {}
			local v431 = "vs " .. v_u_421.short .. ": " .. p422
			local v432 = v428(p424) .. "  >  " .. v428(p423)
			local v433
			if v427 then
				v433 = v_u_10.success
			else
				v433 = v_u_10.danger
			end
			__set_list(v430, 1, {v431, v432, v433})
			table.insert(v429, v430)
		end
	end
	v434("Armor", v420.armorClass, v_u_421.armorClass, true)
	v434("Bite block", v420.zombieBiteBlock, v_u_421.zombieBiteBlock, true, v_u_130)
	v434("Footstep noise", v420.stepNoiseMul, v_u_421.stepNoiseMul, false, v_u_130)
	v434("Leg protection", v420.legProtect, v_u_421.legProtect, true, v_u_130)
	if v420.grid and v_u_421.grid then
		v434("Cells", v_u_5.gridCells(v420), v_u_5.gridCells(v_u_421), true)
	end
	local v_u_435 = v_u_49(v420.weaponId or v420.id)
	local v_u_436 = v_u_49(v_u_421.weaponId or v_u_421.id)
	if v_u_435 and v_u_436 then
		v434("Damage", v_u_435.damage, v_u_436.damage, true)
		v434("Fire rate", v_u_435.rpm, v_u_436.rpm, true)
		v434("Noise", v_u_435.noise, v_u_436.noise, false)
		local v_u_437
		if p418 and (v420.category == "firearm" and v_u_421.category == "firearm") then
			if v_u_33 == nil then
				local v438, v439 = pcall(function()
					return require((script.Parent:WaitForChild("InvUIWeaponStats", 3)))
				end)
				if not v438 or type(v439) ~= "table" then
					v439 = false
				end
				v_u_33 = v439
			end
			v_u_437 = v_u_33 or nil
		else
			v_u_437 = nil
		end
		if v_u_437 then
			local v_u_440
			if v_u_41 then
				v_u_440 = v_u_41.stats
			else
				v_u_440 = nil
			end
			local v441, v442 = pcall(function()
				-- upvalues: (copy) v_u_437, (copy) v_u_435, (copy) p_u_416, (copy) v_u_440, (copy) v_u_436, (copy) p_u_417, (copy) v_u_421
				return v_u_437.compare(v_u_437.statsFor(v_u_435, p_u_416.mods, v_u_440), v_u_437.statsFor(v_u_436, p_u_417.mods, v_u_440), v_u_421.short)
			end)
			if v441 and type(v442) == "table" then
				for _, v443 in v442 do
					local v444 = {}
					local v445 = v443[1]
					local v446 = v443[2]
					local v447
					if v443[3] then
						v447 = v_u_10.success
					else
						v447 = v_u_10.danger
					end
					__set_list(v444, 1, {v445, v446, v447})
					table.insert(v_u_419, v444)
				end
			end
		end
	end
	v434("Weight", v420.weight, v_u_421.weight, false, function(p448)
		return string.format("%.1f", p448)
	end)
	return v_u_419
end
local v_u_450 = {
	["doc"] = "Doc",
	["gunner"] = "Gunner",
	["scrapper"] = "Rook"
}
local v_u_451 = {
	["Task item"] = "Needed for a task",
	["Last copy"] = "Last copy, kept",
	["Not empty"] = "Empty it first",
	["Not bought"] = "Not traded now",
	["Not sold"] = "Not for sale"
}
local v_u_452 = {}
local v_u_453 = nil
function v_u_11.setSellSource(p454) -- name: setSellSource
	-- upvalues: (ref) v_u_453
	v_u_453 = p454
end
function v_u_11.traderName(p455) -- name: traderName
	-- upvalues: (copy) v_u_450, (copy) v_u_452, (copy) v_u_3
	if type(p455) ~= "string" then
		return "?"
	end
	if v_u_450[p455] then
		return v_u_450[p455]
	end
	local v456 = v_u_452.Traders
	if v456 == nil then
		local v_u_457 = "Traders"
		local function v458()
			-- upvalues: (ref) v_u_3, (copy) v_u_457
			return require((v_u_3:WaitForChild(v_u_457, 5)))
		end
		local v459
		v459, v456 = pcall(v458)
		if not v459 or type(v456) ~= "table" then
			v456 = false
		end
		v_u_452.Traders = v456
	end
	local v460 = v456 or nil
	local v461 = v460 and v460.get
	if v461 then
		v461 = v460.get(p455)
	end
	if not v461 then
		return p455
	end
	local v462 = v461.name
	return tostring(v462)
end
local v_u_463 = {
	["prof"] = false
}
local function v_u_528(p_u_464) -- name: sellEnv
	-- upvalues: (ref) v_u_453, (ref) v_u_463, (copy) v_u_452, (copy) v_u_3, (copy) v_u_5
	local v465 = nil
	local v466
	if v_u_453 then
		local v467 = v_u_453
		local v468
		v468, v466 = pcall(v467)
		if v468 then
			if type(v466) ~= "table" then
				v466 = v465
			end
		else
			v466 = v465
		end
	else
		v466 = v465
	end
	if v_u_463.prof == v466 and v_u_463.env then
		return v_u_463.env, v_u_463.stashSel, v_u_463.known
	end
	local v469 = v_u_452.Tasks
	if v469 == nil then
		local v_u_470 = "Tasks"
		local function v471()
			-- upvalues: (ref) v_u_3, (copy) v_u_470
			return require((v_u_3:WaitForChild(v_u_470, 5)))
		end
		local v472
		v472, v469 = pcall(v471)
		if not v472 or type(v469) ~= "table" then
			v469 = false
		end
		v_u_452.Tasks = v469
	end
	local v_u_473 = v469 or nil
	local v474
	if v466 then
		local v475 = v466.tasks
		if type(v475) == "table" then
			v474 = v466.tasks
		else
			v474 = nil
		end
	else
		v474 = nil
	end
	local v_u_476
	if v474 then
		local v477 = v474.done
		v_u_476 = type(v477) ~= "table" and {} or v474.done
	else
		v_u_476 = {}
	end
	local v478
	if v466 == nil then
		v478 = false
	else
		local v479 = v466.passes
		if type(v479) == "table" then
			v478 = v466.passes.vip == true
		else
			v478 = false
		end
	end
	local v480
	if v466 then
		local v481 = v466.inv
		if type(v481) == "table" then
			v480 = v466.inv
		else
			v480 = nil
		end
	else
		v480 = nil
	end
	local v482
	if v480 then
		local v483 = v480.containers
		v482 = type(v483) ~= "table" and {} or v480.containers
	else
		v482 = {}
	end
	local v484
	if v480 then
		local v485 = v480.kit
		if type(v485) == "table" then
			v484 = v480.kit
		else
			v484 = nil
		end
	else
		v484 = nil
	end
	local v486
	if v484 then
		local v487 = v484.slots
		v486 = type(v487) ~= "table" and {} or v484.slots
	else
		v486 = {}
	end
	local v488 = v482.stash
	local v489
	if type(v488) == "table" then
		local v490 = v488.items
		v489 = type(v490) ~= "table" and {} or v488.items
	else
		v489 = {}
	end
	local v_u_491 = {}
	for _, v492 in v482 do
		if type(v492) ~= "table" then
			continue
		end
		local v493 = v492.items
		if type(v493) ~= "table" then
			continue
		end
		local v494 = v492.items
		table.insert(v_u_491, v494)
	end
	local v495 = {}
	for _, v496 in v486 do
		if type(v496) ~= "table" then
			continue
		end
		local v497 = v496.id
		if type(v497) ~= "string" then
			continue
		end
		table.insert(v495, v496)
	end
	table.insert(v_u_491, v495)
	local v_u_498 = {}
	local function v_u_503(p499, p500) -- name: mark
		-- upvalues: (copy) v_u_498, (copy) v_u_503
		if type(p499) == "table" and p500 <= 5 then
			for _, v501 in p499 do
				if type(v501) ~= "table" then
					continue
				end
				local v502 = v501.uid
				if type(v502) == "string" then
					v_u_498[v501.uid] = true
				end
				v_u_503(v501.items, p500 + 1)
				v_u_503(v501.mods, p500 + 1)
			end
		end
	end
	for _, v504 in v_u_491 do
		v_u_503(v504, 0)
	end
	local v505 = {}
	local v506 = {}
	for _, v507 in v489 do
		if type(v507) ~= "table" then
			continue
		end
		local v508 = v507.id
		if type(v508) ~= "string" then
			continue
		end
		local v509 = v507.uid
		if type(v509) ~= "string" then
			continue
		end
		local v510 = v507.id
		local v511 = p_u_464.groupOf(v510)
		if v511 ~= "tape" and v511 ~= "vhs" then
			continue
		end
		v506[v507.uid] = v505[v507.id] or 0
		local v512 = v507.id
		local v513 = v505[v507.id] or 0
		local v514 = v507.n
		local v515 = tonumber(v514) or 1
		v505[v512] = v513 + math.max(1, v515)
	end
	local v_u_516 = {}
	local v527 = {
		["valueOf"] = nil,
		["isKey"] = nil,
		["openTask"] = nil,
		["copies"] = nil,
		["vip"] = nil,
		["vhsOn"] = false,
		["valueOf"] = function(p517) -- name: valueOf
			-- upvalues: (ref) v_u_5
			local v518 = v_u_5.get(p517)
			if v518 then
				v518 = v518.value
			end
			return (type(v518) ~= "number" or v518 ~= v518) and 0 or math.max(0, v518)
		end,
		["isKey"] = function(p519) -- name: isKey
			-- upvalues: (ref) v_u_5
			local v520 = v_u_5.get(p519)
			local v521
			if v520 == nil then
				v521 = false
			else
				local v522 = v520.tags
				if type(v522) == "table" then
					v521 = table.find(v520.tags, "key") ~= nil
				else
					v521 = false
				end
			end
			return v521
		end,
		["openTask"] = function(p523) -- name: openTask
			-- upvalues: (copy) v_u_473, (copy) p_u_464, (copy) v_u_476
			if v_u_473 then
				return p_u_464.openQuestTask(v_u_473, v_u_476, p523)
			else
				return nil
			end
		end,
		["copies"] = function(p524) -- name: copies
			-- upvalues: (copy) v_u_516, (copy) v_u_491, (copy) p_u_464
			local v525 = v_u_516[p524]
			if v525 == nil then
				v525 = 0
				for _, v526 in v_u_491 do
					v525 = v525 + p_u_464.copiesIn(v526, p524)
				end
				v_u_516[p524] = v525
			end
			return v525
		end,
		["vip"] = v478
	}
	v_u_463 = {
		["prof"] = v466,
		["env"] = v527,
		["stashSel"] = v506,
		["known"] = v_u_498
	}
	return v527, v506, v_u_498
end
function v_u_11.sellQuote(p_u_529, p530) -- name: sellQuote
	-- upvalues: (copy) v_u_452, (copy) v_u_3, (copy) v_u_528
	if type(p530) == "table" then
		local v531 = p530.quote
		if type(v531) == "table" then
			return p530.quote
		end
	end
	local v532 = v_u_452.Traders
	if v532 == nil then
		local v_u_533 = "Traders"
		local function v534()
			-- upvalues: (ref) v_u_3, (copy) v_u_533
			return require((v_u_3:WaitForChild(v_u_533, 5)))
		end
		local v535
		v535, v532 = pcall(v534)
		if not v535 or type(v532) ~= "table" then
			v532 = false
		end
		v_u_452.Traders = v532
	end
	local v_u_536 = v532 or nil
	if type(p_u_529) == "table" then
		local v537 = p_u_529.id
		if type(v537) == "string" and (v_u_536 and v_u_536.quote) then
			local function v557()
				-- upvalues: (ref) v_u_528, (copy) v_u_536, (ref) v_u_452, (ref) v_u_3, (copy) p_u_529
				local v_u_538, v539, v540 = v_u_528(v_u_536)
				local v541 = v_u_452.Config
				if v541 == nil then
					local v_u_542 = "Config"
					local function v543()
						-- upvalues: (ref) v_u_3, (copy) v_u_542
						return require((v_u_3:WaitForChild(v_u_542, 5)))
					end
					local v544
					v544, v541 = pcall(v543)
					if not v544 or type(v541) ~= "table" then
						v541 = false
					end
					v_u_452.Config = v541
				end
				local v545 = v541 or nil
				local v546
				if v545 == nil or v545.flag == nil then
					v546 = false
				else
					v546 = v545.flag("VhsTapes") == true
				end
				v_u_538.vhsOn = v546
				local v547 = v_u_536
				local v548 = p_u_529.id
				local v549 = v547.groupOf(v548)
				local v550, v551
				if v549 == "tape" and true or v549 == "vhs" then
					local v552 = p_u_529.uid
					if type(v552) == "string" then
						v550 = v539[v552]
					else
						v550 = nil
					end
					if type(v552) == "string" and (v552 ~= "" and not v540[v552]) then
						local v553 = p_u_529.n
						local v554 = tonumber(v553) or 1
						local v_u_555 = math.max(1, v554)
						v551 = table.clone(v_u_538)
						function v551.copies(p556)
							-- upvalues: (copy) v_u_538, (ref) p_u_529, (copy) v_u_555
							return v_u_538.copies(p556) + (p556 ~= p_u_529.id and 0 or v_u_555)
						end
					else
						v551 = v_u_538
					end
				else
					v551 = v_u_538
					v550 = nil
				end
				return v_u_536.quote(p_u_529, v551, v550)
			end
			local v558, v559 = pcall(v557)
			if v558 then
				return v559
			else
				return nil
			end
		end
	end
	return nil
end
local function v_u_567(p560, p561) -- name: sellWalk
	-- upvalues: (copy) v_u_11, (copy) v_u_567
	if type(p560) ~= "table" or p561 > 4 then
		return 0
	end
	local v562 = 0
	for _, v563 in p560 do
		if type(v563) ~= "table" then
			continue
		end
		local v564 = v563.id
		if type(v564) ~= "string" then
			continue
		end
		local v565 = v_u_11.sellQuote(v563)
		if type(v565) == "table" then
			local v566 = v565.price
			if type(v566) == "number" and v565.price == v565.price then
				v562 = v562 + v565.price
			end
		end
		v562 = v562 + v_u_567(v563.items, p561 + 1)
	end
	return v562
end
function v_u_11.sellTotal(p568) -- name: sellTotal
	-- upvalues: (copy) v_u_567
	local v569 = v_u_567(p568, 0)
	return math.floor(v569)
end
function v_u_11.sellStash(p570) -- name: sellStash
	-- upvalues: (copy) v_u_11
	local v571
	if type(p570) == "table" then
		v571 = p570.containers
	else
		v571 = nil
	end
	if type(v571) == "table" then
		local v572 = v571.stash
		if type(v572) == "table" then
			return v_u_11.sellTotal(v571.stash.items)
		end
	end
	return nil
end
function v_u_11.sellKit(p573) -- name: sellKit
	-- upvalues: (copy) v_u_11, (copy) v_u_567
	local v574
	if type(p573) == "table" then
		v574 = p573.containers
	else
		v574 = nil
	end
	if type(v574) ~= "table" then
		return nil
	end
	local v575 = 0
	local v576 = p573.kit
	local v577
	if type(v576) == "table" then
		v577 = v576.slots
	else
		v577 = nil
	end
	if type(v577) == "table" then
		for v578, v579 in v577 do
			if v578 == "secure" or type(v579) ~= "table" then
				continue
			end
			local v580 = v579.id
			if type(v580) ~= "string" then
				continue
			end
			local v581 = v_u_11.sellQuote(v579)
			if type(v581) ~= "table" then
				continue
			end
			local v582 = v581.price
			if type(v582) ~= "number" or v581.price ~= v581.price then
				continue
			end
			v575 = v575 + v581.price
		end
	end
	for v583, v584 in v574 do
		if v583 == "stash" or (v583 == "ground" or (v583 == "nearby" or type(v584) ~= "table")) then
			continue
		end
		v575 = v575 + v_u_567(v584.items, 0)
	end
	return math.floor(v575)
end
function v_u_11.sellLines(p585, p586) -- name: sellLines
	-- upvalues: (copy) v_u_11, (copy) v_u_39, (copy) v_u_10, (copy) v_u_452, (copy) v_u_3, (copy) v_u_451
	local v587 = {}
	local v588 = v_u_11.sellQuote(p585, p586)
	if type(v588) ~= "table" then
		return v587
	end
	local v589
	if type(p586) == "table" then
		local v590 = p586.quote
		if type(v590) == "table" then
			v589 = 1
		else
			v589 = v588.perkMul ~= nil and 1 or v_u_39()
		end
	else
		v589 = v588.perkMul ~= nil and 1 or v_u_39()
	end
	local v591 = v589 - 1
	local v592
	if math.abs(v591) > 0.0005 then
		v592 = table.clone(v588)
		local v593 = v588.price
		local v594 = (tonumber(v593) or 0) * v589 + 1e-6
		v592.price = math.floor(v594)
		local v595 = v588.prices
		local v596 = {}
		for v597, v598 in type(v595) ~= "table" and {} or v588.prices do
			local v599 = (tonumber(v598) or 0) * v589 + 1e-6
			v596[v597] = math.floor(v599)
		end
		v592.prices = v596
		local v600 = {}
		local v601 = "Trader cut"
		local v602 = string.format("%+.0f%% (perks)", (v589 - 1) * 100)
		local v603
		if v589 < 1 then
			v603 = v_u_10.danger
		else
			v603 = v_u_10.success
		end
		__set_list(v600, 1, {v601, v602, v603})
		v600.wide = true
		table.insert(v587, v600)
	else
		v592 = v588
	end
	local v604 = v592.prices
	local v605 = type(v604) ~= "table" and {} or v592.prices
	local v606 = p585.n
	local v607 = tonumber(v606) or 1
	local v608 = math.floor(v607)
	local v609 = math.max(1, v608)
	local v610 = v592.best
	local v611
	if type(v610) == "string" then
		v611 = v592.best
	else
		v611 = nil
	end
	local v612
	if v611 then
		local v613 = v605[v611]
		v612 = tonumber(v613)
		if not v612 then
			local v614 = v592.price
			v612 = tonumber(v614) or 0
		end
	else
		v612 = 0
	end
	local v615
	if type(p586) == "table" then
		local v616 = p586.here
		if type(v616) == "string" then
			v615 = p586.here
		else
			v615 = nil
		end
	else
		v615 = nil
	end
	if v615 then
		local v617 = v605[v615]
		local v618 = tonumber(v617)
		if v618 then
			local v619 = {
				"Sells here for",
				v_u_11.money(v618),
				v_u_10.accent,
				["wide"] = true
			}
			table.insert(v587, v619)
			if v609 > 1 then
				local v620 = v618 / v609 * 100 + 0.5
				local v621 = math.floor(v620)
				local v622
				if v621 % 100 == 0 then
					v622 = v_u_11.money(v621 // 100)
				else
					v622 = v_u_11.money(v621 // 100) .. string.format(".%02d", v621 % 100)
				end
				table.insert(v587, {
					"Per unit",
					v622,
					nil,
					["wide"] = true
				})
			end
			if v611 and (v611 ~= v615 and v618 < v612) then
				local v623 = {
					"Best price",
					v_u_11.money(v612) .. " (" .. v_u_11.traderName(v611) .. ")",
					v_u_10.info,
					["wide"] = true
				}
				table.insert(v587, v623)
			end
			return v587
		end
		if v611 then
			local v624 = {
				"Sells here for",
				"Not bought here",
				v_u_10.text2,
				["wide"] = true
			}
			table.insert(v587, v624)
			local v625 = {
				"Best price",
				v_u_11.money(v612) .. " (" .. v_u_11.traderName(v611) .. ")",
				v_u_10.info,
				["wide"] = true
			}
			table.insert(v587, v625)
			if v609 > 1 then
				local v626 = v612 / v609 * 100 + 0.5
				local v627 = math.floor(v626)
				local v628
				if v627 % 100 == 0 then
					v628 = v_u_11.money(v627 // 100)
				else
					v628 = v_u_11.money(v627 // 100) .. string.format(".%02d", v627 % 100)
				end
				table.insert(v587, {
					"Per unit",
					v628,
					nil,
					["wide"] = true
				})
			end
			return v587
		end
	end
	if not v611 then
		local v629 = v_u_452.Traders
		if v629 == nil then
			local v_u_630 = "Traders"
			local function v631()
				-- upvalues: (ref) v_u_3, (copy) v_u_630
				return require((v_u_3:WaitForChild(v_u_630, 5)))
			end
			local v632
			v632, v629 = pcall(v631)
			if not v632 or type(v629) ~= "table" then
				v629 = false
			end
			v_u_452.Traders = v629
		end
		local v633 = v629 or nil
		for _, v634 in not v633 and {} or v633.ORDER do
			if not v605[v634] then
				continue
			end
			local v635 = v605[v634]
			v612 = tonumber(v635) or 0
			v611 = v634
		end
	end
	if v611 then
		local v636 = {
			"Sells for",
			v_u_11.money(v612) .. " (" .. v_u_11.traderName(v611) .. ")",
			v_u_10.accent,
			["wide"] = true
		}
		table.insert(v587, v636)
		if v609 > 1 then
			local v637 = v612 / v609 * 100 + 0.5
			local v638 = math.floor(v637)
			local v639
			if v638 % 100 == 0 then
				v639 = v_u_11.money(v638 // 100)
			else
				v639 = v_u_11.money(v638 // 100) .. string.format(".%02d", v638 % 100)
			end
			table.insert(v587, {
				"Per unit",
				v639,
				nil,
				["wide"] = true
			})
		end
		return v587
	end
	local v640 = v_u_451
	local v641 = v592.whyShort
	local v642 = {
		"Can\'t be sold",
		v640[tostring(v641)] or "No trader buys it",
		v_u_10.text2,
		["wide"] = true
	}
	table.insert(v587, v642)
	return v587
end
function v_u_11.ownName(p643, p644) -- name: ownName
	-- upvalues: (copy) v_u_5
	local v645
	if type(p643) == "table" then
		local v646 = p643.cname
		if type(v646) == "string" and (p643.cname ~= "" and p644 ~= nil) then
			v645 = v_u_5.renamable(p644)
		else
			v645 = false
		end
	else
		v645 = false
	end
	return v645
end
function v_u_11.ownShort(p647, p648) -- name: ownShort
	-- upvalues: (copy) v_u_11
	if not v_u_11.ownName(p647, p648) then
		return p648.short
	end
	local v649 = p647.cname
	if (utf8.len(v649) or #v649) <= 10 then
		return v649
	end
	local v650 = utf8.offset(v649, 11)
	local v651
	if v650 then
		local v652 = v650 - 1
		v651 = string.sub(v649, 1, v652)
	else
		v651 = string.sub(v649, 1, 10)
	end
	return v651 .. "."
end
function v_u_11.tooltip(p_u_653, p654, p655) -- name: tooltip
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_11, (copy) v_u_6, (copy) v_u_9, (ref) v_u_40, (copy) v_u_10, (copy) v_u_449, (copy) v_u_32
	local v656 = v_u_5.get(p_u_653.id)
	if not v656 then
		local v657 = {
			["title"] = nil,
			["body"] = "Unknown item"
		}
		local v658 = p_u_653.id
		v657.title = tostring(v658)
		return v657
	end
	local v659 = {
		{ v_u_5.displayCategory(v656.category), v_u_5.RARITY_NAMES[v_u_5.shownRarity(v656)] or "", v_u_4.rarityColor(v_u_5.shownRarity(v656)) }
	}
	local v660
	if type(p655) == "table" then
		v660 = p655.detail == true
	else
		v660 = false
	end
	for _, v661 in v_u_11.statLines(p_u_653, v660) do
		table.insert(v659, v661)
	end
	for _, v662 in v_u_11.pairLines(p_u_653) do
		table.insert(v659, v662)
	end
	if (p_u_653.n or 1) > 1 then
		local v663 = { "Stack", string.format("%d / %d", p_u_653.n, v656.stack) }
		table.insert(v659, v663)
	end
	local v664 = { "Weight", v_u_11.kg(v_u_11.weight(p_u_653)) }
	table.insert(v659, v664)
	local v665 = v_u_11.sellLines
	local v666, v667 = pcall(v665, p_u_653, p655)
	if v666 and type(v667) == "table" then
		for _, v668 in v667 do
			table.insert(v659, v668)
		end
	end
	local v669, v670 = v_u_6.size({
		["uid"] = "",
		["id"] = nil,
		["x"] = 0,
		["y"] = 0,
		["r"] = false,
		["n"] = 1,
		["id"] = p_u_653.id
	})
	local v671 = { "Size", v669 .. " x " .. v670 }
	table.insert(v659, v671)
	local v672 = v_u_9.tipLine
	local v673 = p_u_653._slot
	local v674, v675 = pcall(v672, v656, p_u_653, v673)
	if v674 and v675 then
		table.insert(v659, v675)
	end
	if p_u_653.fir then
		if v_u_40 == nil then
			local v676, v677 = pcall(function()
				return require((script.Parent:WaitForChild("InvUIWhy", 3)))
			end)
			if not v676 or type(v677) ~= "table" then
				v677 = false
			end
			v_u_40 = v677
		end
		local v678 = v_u_40 or nil
		local v679 = {
			"Found in raid",
			not v678 and "Yes" or v678.firValue(),
			v_u_10.info,
			["wide"] = true
		}
		table.insert(v659, v679)
	end
	if p_u_653.gift ~= nil then
		local v680 = {
			"Gift",
			"Can\'t be sold or traded.",
			v_u_10.info,
			["wide"] = true
		}
		table.insert(v659, v680)
	end
	if p654 then
		for _, v681 in v_u_449(p_u_653, p654, v660) do
			table.insert(v659, v681)
		end
	end
	local v682 = v_u_11.caliberLabel(v656)
	local v683
	if v682 then
		v683 = v656.name .. "  \194\183  " .. v682
	else
		v683 = v656.name
	end
	if v_u_11.ownName(p_u_653, v656) then
		v683 = p_u_653.cname
		local v684 = { "Item", v656.name }
		table.insert(v659, 1, v684)
	end
	local v685 = v_u_5.shownDesc(v656)
	if p_u_653.id == "ammo_flare_7" then
		local v686 = game:GetService("Players").LocalPlayer
		if v686 and v686:GetAttribute("CargoHeld") == true then
			local v687 = { "Pilot", "Will not come", v_u_10.danger }
			table.insert(v659, v687)
			local v688 = v656.desc
			v685 = tostring(v688) .. "\nYour last cargo is still in your mail. The pilot won\'t come."
		end
	end
	local v689 = v_u_32(v685, p_u_653.id)
	local v690, v691 = pcall(function()
		-- upvalues: (copy) p_u_653
		return require(script.Parent:WaitForChild("InvUIRoll", 3)).tipFilled(p_u_653)
	end)
	if v690 and type(v691) == "string" then
		if type(v689) == "string" and v689 ~= "" then
			v691 = v689 .. "\n" .. v691
		end
	else
		v691 = v689
	end
	return {
		["title"] = v683,
		["body"] = v691,
		["lines"] = v659,
		["color"] = v_u_4.rarityColor(v_u_5.shownRarity(v656))
	}
end
local v_u_692 = {
	["sight"] = 1,
	["muzzle"] = 2,
	["tactical"] = 3,
	["mag"] = 4,
	["grip"] = 5,
	["stock"] = 6
}
function v_u_11.modList(p693) -- name: modList
	-- upvalues: (copy) v_u_692
	local v694 = {}
	if type(p693) ~= "table" then
		return v694
	end
	for v695, v697 in p693 do
		local v697
		if type(v697) == "table" then
			v697 = v697.id
		elseif type(v697) ~= "string" then
			v697 = nil
		end
		if type(v697) ~= "string" then
			continue
		end
		local v698 = {
			["slot"] = tostring(v695),
			["id"] = v697
		}
		table.insert(v694, v698)
	end
	table.sort(v694, function(p699, p700)
		-- upvalues: (ref) v_u_692
		local v701 = v_u_692[p699.slot] or 9
		local v702 = v_u_692[p700.slot] or 9
		if v701 == v702 then
			return p699.id < p700.id
		else
			return v701 < v702
		end
	end)
	return v694
end
local function v_u_715(p703, p704, p705, p706, p707, p708, p709, p710) -- name: bar
	local v711 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["ZIndex"] = nil,
		["BackgroundColor3"] = p708,
		["Position"] = UDim2.fromOffset(p704, p705),
		["Size"] = UDim2.fromOffset(p706, p707),
		["Rotation"] = p710 or 0,
		["ZIndex"] = p709
	}
	local v712 = Instance.new("Frame")
	for v713, v714 in v711 do
		v712[v713] = v714
	end
	if p703 then
		v712.Parent = p703
	end
	return v712
end
local function v_u_738(p716, p717, p718, p719, p720) -- name: drawGlyph
	-- upvalues: (copy) v_u_715, (copy) v_u_10
	if p717 == "sight" then
		local v721 = {
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Position"] = UDim2.fromOffset(2, 2),
			["Size"] = UDim2.fromOffset(9, 9),
			["ZIndex"] = p720
		}
		local v722 = Instance.new("Frame")
		for v723, v724 in v721 do
			v722[v723] = v724
		end
		if p716 then
			v722.Parent = p716
		end
		local v725 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v726 = Instance.new("UICorner")
		for v727, v728 in v725 do
			v726[v727] = v728
		end
		if v722 then
			v726.Parent = v722
		end
		local v729 = {
			["Color"] = nil,
			["Thickness"] = 1,
			["ApplyStrokeMode"] = nil,
			["BorderStrokePosition"] = nil,
			["Color"] = p719,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner
		}
		local v730 = Instance.new("UIStroke")
		for v731, v732 in v729 do
			v730[v731] = v732
		end
		if v722 then
			v730.Parent = v722
		end
		v_u_715(p716, 6, 6, 1, 1, p719, p720)
		if string.find(p718, "scope", 1, true) then
			v_u_715(p716, 6, 2, 1, 9, p719, p720)
			v_u_715(p716, 2, 6, 9, 1, p719, p720)
			return
		end
	elseif p717 == "muzzle" then
		v_u_715(p716, 1, 6, 6, 1, p719, p720)
		v_u_715(p716, 6, 4, 6, 5, p719, p720)
		if string.find(p718, "compensator", 1, true) then
			v_u_715(p716, 8, 4, 1, 5, v_u_10.bgDeep, p720 + 1)
			v_u_715(p716, 10, 4, 1, 5, v_u_10.bgDeep, p720 + 1)
			return
		end
	elseif p717 == "tactical" then
		if string.find(p718, "laser", 1, true) then
			v_u_715(p716, 1, 5, 4, 3, p719, p720)
			v_u_715(p716, 5, 6, 7, 1, v_u_10.danger, p720)
			return
		end
		v_u_715(p716, 1, 5, 4, 3, p719, p720)
		local v733 = v_u_715(p716, 5, 3, 7, 7, p719, p720)
		local v734 = {
			["Transparency"] = NumberSequence.new(0.2, 0.85)
		}
		local v735 = Instance.new("UIGradient")
		for v736, v737 in v734 do
			v735[v736] = v737
		end
		if v733 then
			v735.Parent = v733
			return
		end
	else
		if p717 == "mag" then
			v_u_715(p716, 5, 1, 4, 11, p719, p720, 8)
			return
		end
		if p717 == "grip" then
			v_u_715(p716, 1, 3, 11, 2, p719, p720)
			v_u_715(p716, 5, 5, 3, 7, p719, p720)
			return
		end
		if p717 == "stock" then
			v_u_715(p716, 3, 4, 9, 2, p719, p720)
			v_u_715(p716, 1, 4, 3, 7, p719, p720)
			return
		end
		v_u_715(p716, 4, 4, 5, 5, p719, p720)
	end
end
function v_u_11.modBadges(p739, p740) -- name: modBadges
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_4, (copy) v_u_738, (copy) v_u_54, (copy) v_u_5
	local v741 = v_u_11.modList(p739)
	if #v741 == 0 then
		return nil
	end
	local v742 = p740 or {}
	local v743 = v742.zindex or 4
	local v744 = v742.max or 4
	local v745 = #v741
	local v746 = math.min(v745, v744)
	local v747 = {
		["Name"] = "ModBadges",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Position"] = v742.position or UDim2.fromOffset(2, 2),
		["AnchorPoint"] = v742.anchor or Vector2.zero,
		["Size"] = UDim2.fromOffset(v746 * 14 - 1, 13),
		["ZIndex"] = v743
	}
	local v748 = Instance.new("Frame")
	for v749, v750 in v747 do
		v748[v749] = v750
	end
	local v751 = {}
	for v752 = 1, v746 do
		local v753 = v741[v752]
		local v754 = v753.id
		table.insert(v751, v754)
		local v755 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["ClipsDescendants"] = true,
			["Name"] = "Mod_" .. v753.slot,
			["BackgroundColor3"] = v_u_10.bgDeep,
			["Position"] = UDim2.fromOffset((v752 - 1) * 14, 0),
			["Size"] = UDim2.fromOffset(13, 13),
			["ZIndex"] = v743
		}
		local v756 = Instance.new("Frame")
		for v757, v758 in v755 do
			v756[v757] = v758
		end
		if v748 then
			v756.Parent = v748
		end
		v756:SetAttribute("AttId", v753.id)
		if v752 == v746 and v746 < #v741 then
			local v759 = {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextSize"] = 9,
				["Text"] = nil,
				["ZIndex"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_4.font.monoBold,
				["TextColor3"] = v_u_10.info,
				["Text"] = "+" .. #v741 - v746 + 1,
				["ZIndex"] = v743 + 1
			}
			local v760 = Instance.new("TextLabel")
			for v761, v762 in v759 do
				v760[v761] = v762
			end
			if not v756 then
				break
			end
			v760.Parent = v756
		else
			v_u_738(v756, v753.slot, v753.id, v_u_10.info, v743 + 1)
			local v763
			if type(p739) == "table" then
				v763 = p739[v753.slot] or nil
			else
				v763 = nil
			end
			local v764 = v_u_54()
			if type(v763) ~= "table" or not (v764 and v764.wears(v_u_5.get(v753.id))) then
				break
			end
			local v765 = v764.durOf(v763)
			if v765 >= 0.999 then
				break
			end
			local v766 = {
				["Name"] = "Wear",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = v_u_10.bgDeep,
				["Position"] = UDim2.new(0, 0, 1, -2),
				["Size"] = UDim2.new(1, 0, 0, 2),
				["ZIndex"] = v743 + 2
			}
			local v767 = Instance.new("Frame")
			for v768, v769 in v766 do
				v767[v768] = v769
			end
			if v756 then
				v767.Parent = v756
			end
			local v770 = {
				["Name"] = "WearFill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil
			}
			local v771
			if v764.stage(v765) >= 3 then
				v771 = v_u_10.danger
			elseif v764.stage(v765) >= 1 then
				v771 = v_u_10.accent
			else
				v771 = v_u_10.success
			end
			v770.BackgroundColor3 = v771
			v770.Position = UDim2.new(0, 0, 1, -2)
			v770.Size = UDim2.new(math.max(v765, 0.08), 0, 0, 2)
			v770.ZIndex = v743 + 3
			local v772 = Instance.new("Frame")
			for v773, v774 in v770 do
				v772[v773] = v774
			end
			if v756 then
				v772.Parent = v756
			end
			local v775 = v765 * 100 + 0.5
			v756:SetAttribute("Wear", (math.floor(v775)))
		end
	end
	v748:SetAttribute("Mods", table.concat(v751, ","))
	if v742.parent then
		v748.Parent = v742.parent
	end
	return v748
end
function v_u_11.modBadgesWidth(p776, p777) -- name: modBadgesWidth
	local v778 = math.min(p776, p777 or 4)
	return v778 <= 0 and 0 or v778 * 14 - 1
end
function v_u_11.create(p779, p780, p781) -- name: create
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (ref) v_u_26, (copy) v_u_17, (copy) v_u_18, (copy) v_u_2, (copy) v_u_11, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6, (copy) v_u_49, (ref) v_u_41, (copy) v_u_8, (copy) v_u_9, (ref) v_u_12, (ref) v_u_16, (copy) v_u_67
	local v_u_782 = p781 or {}
	local v_u_783 = v_u_782.zindex or 3
	local v784 = {
		["Name"] = "Item",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["BorderSizePixel"] = 0,
		["ZIndex"] = nil,
		["Active"] = true,
		["BackgroundColor3"] = v_u_10.raised,
		["ZIndex"] = v_u_783
	}
	local v_u_785 = Instance.new("Frame")
	for v786, v787 in v784 do
		v_u_785[v786] = v787
	end
	local v788 = {
		["Name"] = "Tint",
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = nil,
		["BackgroundTransparency"] = v_u_4.alpha.rarity,
		["Size"] = UDim2.fromScale(1, 1),
		["ZIndex"] = v_u_783
	}
	local v_u_789 = Instance.new("Frame")
	for v790, v791 in v788 do
		v_u_789[v790] = v791
	end
	if v_u_785 then
		v_u_789.Parent = v_u_785
	end
	local v792 = {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 0) })
	}
	local v793 = Instance.new("UIGradient")
	for v794, v795 in v792 do
		v793[v794] = v795
	end
	if v_u_789 then
		v793.Parent = v_u_789
	end
	local v796 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil,
		["Transparency"] = 0,
		["Color"] = v_u_10.line,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v_u_797 = Instance.new("UIStroke")
	for v798, v799 in v796 do
		v_u_797[v798] = v799
	end
	if v_u_785 then
		v_u_797.Parent = v_u_785
	end
	pcall(function()
		-- upvalues: (copy) v_u_797
		v_u_797.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	local v800 = {
		["Name"] = "IconHolder",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["ZIndex"] = nil,
		["Size"] = UDim2.new(1, -6, 1, -6),
		["Position"] = UDim2.fromOffset(3, 3),
		["ZIndex"] = v_u_783 + 1
	}
	local v_u_801 = Instance.new("Frame")
	for v802, v803 in v800 do
		v_u_801[v802] = v803
	end
	if v_u_785 then
		v_u_801.Parent = v_u_785
	end
	local v804
	if v_u_4.isPhone == nil then
		v804 = false
	else
		v804 = v_u_4.isPhone()
	end
	local v_u_805 = v804 and 16 or 13
	local v806 = v_u_4.phoneText(10, "caption")
	local v807 = {
		["Name"] = "Short",
		["BackgroundTransparency"] = 1,
		["Font"] = nil,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = 11,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["TextTruncate"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Text"] = "",
		["TextScaled"] = true,
		["Font"] = Enum.Font.Unknown,
		["FontFace"] = v_u_4.font.bodyMedium,
		["TextColor3"] = v_u_10.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -4, 0, 2),
		["Size"] = UDim2.new(1, -8, 0, v_u_805),
		["ZIndex"] = v_u_783 + 2
	}
	local v_u_808 = Instance.new("TextLabel")
	local v809 = v804 and 16 or 14
	local v810 = v804 and 14 or 11
	local v_u_811 = v804 and 16 or 13
	local v_u_812 = v804 and 26 or 20
	for v813, v814 in v807 do
		v_u_808[v813] = v814
	end
	if v_u_785 then
		v_u_808.Parent = v_u_785
	end
	local v_u_815 = v_u_4.phoneText(8, "scaled")
	local v816 = {
		["MaxTextSize"] = math.max(11, v_u_815),
		["MinTextSize"] = v_u_815
	}
	local v_u_817 = Instance.new("UITextSizeConstraint")
	for v818, v819 in v816 do
		v_u_817[v818] = v819
	end
	if v_u_808 then
		v_u_817.Parent = v_u_808
	end
	local v820 = {
		["Name"] = "Count",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = 12,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Text"] = "",
		["TextStrokeTransparency"] = 0.6,
		["TextStrokeColor3"] = nil,
		["TextScaled"] = true,
		["FontFace"] = v_u_4.font.monoBold,
		["TextColor3"] = v_u_10.text,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextYAlignment"] = Enum.TextYAlignment.Bottom,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -4, 1, -3),
		["Size"] = UDim2.new(1, -8, 0, v809),
		["ZIndex"] = v_u_783 + 2,
		["TextStrokeColor3"] = v_u_10.bgDeep
	}
	local v_u_821 = Instance.new("TextLabel")
	for v822, v823 in v820 do
		v_u_821[v822] = v823
	end
	if v_u_785 then
		v_u_821.Parent = v_u_785
	end
	local v824 = {}
	local v825 = v_u_4.phoneText
	v824.MaxTextSize = math.max(12, v825(7, "scaled"))
	v824.MinTextSize = v_u_4.phoneText(7, "scaled")
	local v826 = Instance.new("UITextSizeConstraint")
	for v827, v828 in v824 do
		v826[v827] = v828
	end
	if v_u_821 then
		v826.Parent = v_u_821
	end
	local v829 = {
		["Name"] = "Caliber",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = 10,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Text"] = "",
		["Visible"] = false,
		["TextStrokeTransparency"] = 0.7,
		["TextStrokeColor3"] = nil,
		["TextScaled"] = true,
		["FontFace"] = v_u_4.font.monoBold,
		["TextColor3"] = v_u_10.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextYAlignment"] = Enum.TextYAlignment.Bottom,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -4, 1, -(not v804 and 16 or v809 + 3)),
		["Size"] = UDim2.new(1, -8, 0, v810),
		["ZIndex"] = v_u_783 + 2,
		["TextStrokeColor3"] = v_u_10.bgDeep
	}
	local v_u_830 = Instance.new("TextLabel")
	for v831, v832 in v829 do
		v_u_830[v831] = v832
	end
	if v_u_785 then
		v_u_830.Parent = v_u_785
	end
	local v833 = {}
	local v834 = v_u_4.phoneText
	v833.MaxTextSize = math.max(10, v834(7, "scaled"))
	v833.MinTextSize = v_u_4.phoneText(7, "scaled")
	local v835 = Instance.new("UITextSizeConstraint")
	for v836, v837 in v833 do
		v835[v836] = v837
	end
	if v_u_830 then
		v835.Parent = v_u_830
	end
	v_u_785.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_26, (copy) v_u_785
		if v_u_26 == nil then
			local v838, v839 = pcall(function()
				return require((script.Parent:WaitForChild("HushUI")))
			end)
			if not v838 then
				v839 = false
			end
			v_u_26 = v839
		end
		local v_u_840 = v_u_26 or nil
		if v_u_840 and (v_u_840.device and (v_u_840.device() == "Gamepad" and v_u_840.showTooltip)) then
			task.defer(function()
				-- upvalues: (ref) v_u_785, (copy) v_u_840
				local v841 = game:GetService("GuiService")
				if v_u_785.Parent and v841.SelectedObject == v_u_785 then
					local v842 = v_u_840.showTooltip
					local v843 = v_u_785
					pcall(v842, v843)
				end
			end)
		end
	end)
	v_u_785.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_26, (copy) v_u_785
		if v_u_26 == nil then
			local v844, v845 = pcall(function()
				return require((script.Parent:WaitForChild("HushUI")))
			end)
			if not v844 then
				v845 = false
			end
			v_u_26 = v845
		end
		local v846 = v_u_26 or nil
		if v846 and (v846.tooltipOwner and (v846.hideTooltip and v846.tooltipOwner() == v_u_785)) then
			local v847 = v846.hideTooltip
			pcall(v847)
		end
	end)
	local v848 = {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_10.bgDeep,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 3, 1, -2),
		["Size"] = UDim2.new(0.45, 0, 0, 3),
		["ZIndex"] = v_u_783 + 2
	}
	local v_u_849 = Instance.new("Frame")
	for v850, v851 in v848 do
		v_u_849[v850] = v851
	end
	if v_u_785 then
		v_u_849.Parent = v_u_785
	end
	local v852 = {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = nil,
		["BackgroundColor3"] = v_u_10.success,
		["Size"] = UDim2.fromScale(1, 1),
		["ZIndex"] = v_u_783 + 3
	}
	local v_u_853 = Instance.new("Frame")
	for v854, v855 in v852 do
		v_u_853[v854] = v855
	end
	if v_u_849 then
		v_u_853.Parent = v_u_849
	end
	local v856 = {
		["Name"] = "Quick",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = nil,
		["Visible"] = false,
		["Text"] = "",
		["BackgroundColor3"] = v_u_10.accent,
		["FontFace"] = v_u_4.font.monoBold,
		["TextColor3"] = v_u_10.ink,
		["TextSize"] = v806,
		["Size"] = UDim2.fromOffset(v_u_811, v_u_811),
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 2, 1, -2),
		["ZIndex"] = v_u_783 + 3
	}
	local v_u_857 = Instance.new("TextLabel")
	for v858, v859 in v856 do
		v_u_857[v858] = v859
	end
	if v_u_785 then
		v_u_857.Parent = v_u_785
	end
	local v860 = {
		["Name"] = "SecondSlot",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = nil,
		["Visible"] = false,
		["Text"] = "2ND",
		["BackgroundColor3"] = v_u_10.bgDeep,
		["FontFace"] = v_u_4.font.monoBold,
		["TextColor3"] = v_u_10.accent,
		["TextSize"] = v806,
		["Size"] = UDim2.fromOffset(v_u_811 * 2 + 4, v_u_811),
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -2),
		["ZIndex"] = v_u_783 + 3
	}
	local v_u_861 = Instance.new("TextLabel")
	for v862, v863 in v860 do
		v_u_861[v862] = v863
	end
	if v_u_785 then
		v_u_861.Parent = v_u_785
	end
	local v864 = {
		["Name"] = "Mods",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["ZIndex"] = nil,
		["Visible"] = false,
		["Text"] = "",
		["BackgroundColor3"] = v_u_10.bgDeep,
		["FontFace"] = v_u_4.font.monoBold,
		["TextColor3"] = v_u_10.info,
		["TextSize"] = v806,
		["Size"] = UDim2.fromOffset(v_u_812, v_u_811),
		["Position"] = UDim2.fromOffset(2, 2),
		["ZIndex"] = v_u_783 + 3
	}
	local v_u_865 = Instance.new("TextLabel")
	for v866, v867 in v864 do
		v_u_865[v866] = v867
	end
	if v_u_785 then
		v_u_865.Parent = v_u_785
	end
	local v868 = {
		["Name"] = "Fir",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_10.info,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 3, 1, -7),
		["Size"] = UDim2.fromOffset(4, 4),
		["ZIndex"] = v_u_783 + 3
	}
	local v_u_869 = Instance.new("Frame")
	for v870, v871 in v868 do
		v_u_869[v870] = v871
	end
	if v_u_785 then
		v_u_869.Parent = v_u_785
	end
	local v_u_872 = nil
	local function v_u_884(p873) -- name: setLock
		-- upvalues: (ref) v_u_872, (ref) v_u_10, (copy) v_u_783, (copy) v_u_785, (ref) v_u_26
		if p873 and not v_u_872 then
			local v874 = {
				["Name"] = "Lock",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = v_u_10.accent,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -2, 0.5, 0),
				["Size"] = UDim2.fromOffset(13, 13),
				["ZIndex"] = v_u_783 + 3
			}
			local v875 = v_u_785
			local v876 = Instance.new("Frame")
			for v877, v878 in v874 do
				v876[v877] = v878
			end
			if v875 then
				v876.Parent = v875
			end
			if v_u_26 == nil then
				local v879, v880 = pcall(function()
					return require((script.Parent:WaitForChild("HushUI")))
				end)
				if not v879 then
					v880 = false
				end
				v_u_26 = v880
			end
			local v881 = v_u_26 or nil
			if v881 and v881.icon then
				local v882 = v881.icon
				local v883 = {
					["parent"] = nil,
					["size"] = 9,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["zindex"] = nil,
					["parent"] = v876,
					["color"] = v_u_10.ink,
					["position"] = UDim2.fromScale(0.5, 0.5),
					["anchor"] = Vector2.new(0.5, 0.5),
					["zindex"] = v_u_783 + 4
				}
				pcall(v882, "lock", v883)
			end
			v_u_872 = v876
		end
		if v_u_872 then
			v_u_872.Visible = p873
		end
	end
	local v_u_885 = nil
	local function v_u_897(p886) -- name: setWish
		-- upvalues: (ref) v_u_885, (ref) v_u_10, (copy) v_u_783, (copy) v_u_785, (ref) v_u_26
		if p886 and not v_u_885 then
			local v887 = {
				["Name"] = "Wish",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = v_u_10.accent,
				["Position"] = UDim2.fromOffset(2, 2),
				["Size"] = UDim2.fromOffset(13, 13),
				["ZIndex"] = v_u_783 + 3
			}
			local v888 = v_u_785
			local v889 = Instance.new("Frame")
			for v890, v891 in v887 do
				v889[v890] = v891
			end
			if v888 then
				v889.Parent = v888
			end
			if v_u_26 == nil then
				local v892, v893 = pcall(function()
					return require((script.Parent:WaitForChild("HushUI")))
				end)
				if not v892 then
					v893 = false
				end
				v_u_26 = v893
			end
			local v894 = v_u_26 or nil
			if v894 and v894.icon then
				local v895 = v894.icon
				local v896 = {
					["parent"] = nil,
					["size"] = 9,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["zindex"] = nil,
					["parent"] = v889,
					["color"] = v_u_10.ink,
					["position"] = UDim2.fromScale(0.5, 0.5),
					["anchor"] = Vector2.new(0.5, 0.5),
					["zindex"] = v_u_783 + 4
				}
				pcall(v895, "star", v896)
			end
			v_u_885 = v889
		end
		if v_u_885 then
			v_u_885.Visible = p886
		end
	end
	local v_u_898 = nil
	local v_u_899 = nil
	local v_u_900 = nil
	local v_u_901 = {}
	local v_u_902 = nil
	local function v_u_904() -- name: stopFocusTweens
		-- upvalues: (copy) v_u_901
		for _, v_u_903 in v_u_901 do
			pcall(function()
				-- upvalues: (copy) v_u_903
				v_u_903:Cancel()
			end)
		end
		table.clear(v_u_901)
	end
	local function v_u_935(p905) -- name: setFocus
		-- upvalues: (ref) v_u_898, (ref) v_u_10, (copy) v_u_785, (ref) v_u_899, (copy) v_u_783, (ref) v_u_26, (ref) v_u_900, (copy) v_u_904, (ref) v_u_17, (ref) v_u_18, (copy) v_u_901, (ref) v_u_2, (copy) v_u_935, (ref) v_u_11, (ref) v_u_902
		if p905 then
			if not v_u_898 then
				local v906 = {
					["Name"] = "TutorialFocus",
					["Color"] = nil,
					["Thickness"] = 3,
					["ApplyStrokeMode"] = nil,
					["Transparency"] = 0,
					["Color"] = v_u_10.accent,
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
				}
				local v907 = v_u_785
				local v_u_908 = Instance.new("UIStroke")
				for v909, v910 in v906 do
					v_u_908[v909] = v910
				end
				if v907 then
					v_u_908.Parent = v907
				end
				pcall(function()
					-- upvalues: (copy) v_u_908
					v_u_908.BorderStrokePosition = Enum.BorderStrokePosition.Inner
				end)
				v_u_898 = v_u_908
				local v911 = {
					["Name"] = "TutorialWash",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.9,
					["BorderSizePixel"] = 0,
					["Active"] = false,
					["Size"] = nil,
					["ZIndex"] = nil,
					["BackgroundColor3"] = v_u_10.accent,
					["Size"] = UDim2.fromScale(1, 1),
					["ZIndex"] = v_u_783 + 1
				}
				local v912 = v_u_785
				local v913 = Instance.new("Frame")
				for v914, v915 in v911 do
					v913[v914] = v915
				end
				if v912 then
					v913.Parent = v912
				end
				v_u_899 = v913
				local v916 = {
					["Name"] = "TutorialHand",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Active"] = false,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = nil,
					["BackgroundColor3"] = v_u_10.accent,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -2, 0, 2),
					["Size"] = UDim2.fromOffset(18, 18),
					["ZIndex"] = v_u_783 + 3
				}
				local v917 = v_u_785
				local v918 = Instance.new("Frame")
				for v919, v920 in v916 do
					v918[v919] = v920
				end
				if v917 then
					v918.Parent = v917
				end
				if v_u_26 == nil then
					local v921, v922 = pcall(function()
						return require((script.Parent:WaitForChild("HushUI")))
					end)
					if not v921 then
						v922 = false
					end
					v_u_26 = v922
				end
				local v923 = v_u_26 or nil
				if v923 and v923.icon then
					local v924 = v923.icon
					local v925 = {
						["parent"] = nil,
						["size"] = 14,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["zindex"] = nil,
						["parent"] = v918,
						["color"] = v_u_10.ink,
						["position"] = UDim2.fromScale(0.5, 0.5),
						["anchor"] = Vector2.new(0.5, 0.5),
						["zindex"] = v_u_783 + 4
					}
					pcall(v924, "hand", v925)
				end
				v_u_900 = v918
				v_u_785.Destroying:Connect(function()
					-- upvalues: (ref) v_u_904, (ref) v_u_17, (ref) v_u_785, (ref) v_u_18
					v_u_904()
					v_u_17[v_u_785] = nil
					v_u_18[v_u_785] = nil
				end)
			end
			local v926 = v_u_898
			local v927 = v_u_899
			local v928 = v_u_900
			if v926 and (v927 and v928) then
				v926.Enabled = true
				v927.Visible = true
				v928.Visible = true
				if #v_u_901 == 0 then
					local v_u_929 = TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
					for _, v_u_930 in {
						{
							v926,
							{
								["Transparency"] = 0.6
							}
						},
						{
							v927,
							{
								["BackgroundTransparency"] = 0.78
							}
						}
					} do
						local function v931()
							-- upvalues: (ref) v_u_2, (copy) v_u_930, (copy) v_u_929
							return v_u_2:Create(v_u_930[1], v_u_929, v_u_930[2])
						end
						local v932, v933 = pcall(v931)
						if not (v932 and v933) then
							continue
						end
						v933:Play()
						local v934 = v_u_901
						table.insert(v934, v933)
					end
				end
			end
			v_u_18[v_u_785] = true
			v_u_17[v_u_785] = function()
				-- upvalues: (ref) v_u_935, (ref) v_u_11, (ref) v_u_902
				v_u_935(v_u_11.isFocus(v_u_902))
			end
		else
			v_u_904()
			if v_u_898 then
				v_u_898.Enabled = false
			end
			if v_u_899 then
				v_u_899.Visible = false
			end
			if v_u_900 then
				v_u_900.Visible = false
			end
			v_u_18[v_u_785] = nil
			v_u_17[v_u_785] = nil
		end
	end
	local v_u_936 = nil
	local v_u_937 = nil
	local v_u_938 = nil
	local v_u_939 = ""
	local v_u_940 = nil
	local v_u_941 = false
	local v_u_942 = v_u_782.lazy ~= true
	local v_u_943 = false
	v_u_785.Destroying:Connect(function()
		-- upvalues: (ref) v_u_943
		v_u_943 = true
	end)
	local function v_u_950(p944) -- name: acquireIcon
		-- upvalues: (ref) v_u_7, (copy) v_u_801, (copy) v_u_783, (copy) v_u_782, (ref) v_u_936, (ref) v_u_937, (ref) v_u_941
		local v945 = v_u_7.get(p944.id, p944.r == true, {
			["parent"] = v_u_801,
			["zindex"] = v_u_783 + 1,
			["mods"] = p944.mods,
			["skin"] = v_u_782.skin == true and true or nil
		})
		v_u_936 = v945
		local v946 = v_u_7.keyOf
		local v947 = p944.id
		local v948 = p944.mods
		local v949
		if v_u_782.skin == true then
			v949 = v_u_7.resolveSkin(p944.id, true)
		else
			v949 = nil
		end
		v_u_937 = v946(v947, v948, v949)
		if v_u_941 then
			v945.ImageTransparency = 0.75
		end
	end
	local function v1021(p951, p952) -- name: set
		-- upvalues: (ref) v_u_940, (ref) v_u_5, (ref) v_u_6, (copy) v_u_785, (ref) v_u_4, (copy) v_u_789, (copy) v_u_797, (ref) v_u_10, (ref) v_u_936, (ref) v_u_7, (ref) v_u_937, (copy) v_u_782, (ref) v_u_942, (ref) v_u_943, (copy) v_u_950, (copy) v_u_808, (ref) v_u_11, (copy) v_u_817, (copy) v_u_815, (copy) v_u_821, (ref) v_u_49, (ref) v_u_41, (copy) v_u_830, (copy) v_u_849, (copy) v_u_853, (copy) v_u_869, (copy) v_u_884, (ref) v_u_8, (copy) v_u_857, (copy) v_u_861, (ref) v_u_9, (ref) v_u_12, (copy) v_u_897, (ref) v_u_902, (ref) v_u_16, (ref) v_u_898, (copy) v_u_935, (ref) v_u_67, (ref) v_u_939, (ref) v_u_938, (copy) v_u_783, (copy) v_u_865, (copy) v_u_812, (copy) v_u_805, (copy) v_u_811
		v_u_940.inst = p951
		local v953 = v_u_5.get(p951.id)
		local v954, v955 = v_u_6.size(p951)
		v_u_785.Size = UDim2.fromOffset(v954 * p952 - 2, v955 * p952 - 2)
		local v956 = v_u_785
		local v957 = p951.uid
		v956.Name = "Item_" .. tostring(v957)
		local v958 = v_u_4.rarityColor(not v953 and 1 or v_u_5.shownRarity(v953))
		v_u_789.BackgroundColor3 = v958
		local v959 = v_u_797
		if not (v953 and v953.gold) then
			v958 = v_u_10.line:Lerp(v958, 0.35)
		end
		v959.Color = v958
		v_u_797.Thickness = v953 and v953.gold and 2 or 1
		if v_u_936 and not v_u_7.alive(v_u_936) then
			v_u_936 = nil
			v_u_937 = nil
		end
		local v960 = v_u_937
		local v961 = v_u_7.keyOf
		local v962 = p951.id
		local v963 = p951.mods
		local v964
		if v_u_782.skin == true then
			v964 = v_u_7.resolveSkin(p951.id, true)
		else
			v964 = nil
		end
		if v960 == v961(v962, v963, v964) then
			if v_u_936 then
				v_u_7.setRotated(v_u_936, p951.r == true)
			end
		else
			if v_u_936 then
				v_u_7.release(v_u_936)
				v_u_936 = nil
				v_u_937 = nil
			end
			if v_u_942 and not v_u_943 then
				v_u_950(p951)
			end
		end
		local v965 = v_u_808
		local v966 = v953 and string.upper(v_u_11.ownShort(p951, v953))
		if not v966 then
			local v967 = p951.id
			v966 = tostring(v967)
		end
		v965.Text = v966
		local v968 = v_u_817
		local v969 = v_u_815
		local v970 = p952 < 48 and 10 or 11
		v968.MaxTextSize = math.max(v969, v970)
		v_u_808.Visible = v954 * p952 >= 40
		if (v953 and (v953.stack or 1) or 1) > 1 and (p951.n or 1) >= 1 then
			local v971 = v_u_821
			local v972 = p951.n or 1
			v971.Text = tostring(v972)
			v_u_821.TextColor3 = v_u_10.text
		elseif v953 and v953.category == "firearm" then
			local v973 = p951.ammo
			if type(v973) == "number" then
				local v974 = v_u_49(v953.weaponId or v953.id)
				local v975 = v974 and v974.capacity or v953.capacity
				if v974 then
					local v976 = p951.mods
					if type(v976) == "table" and (v_u_41 and v_u_41.stats) then
						local v977 = v_u_41.stats
						local v978 = v974.id
						local v979 = p951.mods
						local v980, v981 = pcall(v977, v978, v979)
						if v980 and type(v981) == "table" then
							local v982 = v981.capacity
							if type(v982) == "number" then
								v975 = v981.capacity
							end
						end
					end
				end
				local v983 = v_u_821
				local v984
				if v975 then
					v984 = string.format("%d/%d", p951.ammo, v975)
				else
					local v985 = p951.ammo
					v984 = tostring(v985)
				end
				v983.Text = v984
				local v986 = v_u_821
				local v987
				if p951.ammo == 0 then
					if p951._slot then
						v987 = v_u_10.danger
					else
						v987 = v_u_10.muted
					end
				else
					v987 = v_u_10.text
				end
				v986.TextColor3 = v987
			else
				v_u_821.Text = ""
			end
		else
			v_u_821.Text = ""
		end
		local v988 = v_u_11.caliberTag(v953)
		v_u_830.Text = v988 or ""
		local v989 = v_u_830
		local v990
		if v988 == nil or v955 * p952 < 46 then
			v990 = false
		else
			v990 = v954 * p952 >= 40
		end
		v989.Visible = v990
		local v991 = v_u_11.shownDur(p951, v953)
		if v991 then
			v_u_849.Visible = true
			v_u_853.Size = UDim2.fromScale(v991, 1)
			local v992 = v_u_853
			local v993
			if v991 < 0.3 then
				v993 = v_u_10.danger
			elseif v991 < 0.6 then
				v993 = v_u_10.accent
			else
				v993 = v_u_10.success
			end
			v992.BackgroundColor3 = v993
		else
			v_u_849.Visible = false
		end
		v_u_869.Visible = p951.fir == true
		v_u_884(v_u_8.shown(p951))
		local v994 = p951._quick
		v_u_857.Visible = type(v994) == "number"
		v_u_857.Text = type(v994) ~= "number" and "" or tostring(v994)
		local v995 = v_u_861
		local v996
		if p951.tw == true and v954 * p952 >= 60 then
			v996 = true
		elseif p951._slot == "secondary" and (v954 * p952 >= 96 and v953 ~= nil) then
			v996 = v_u_9.applies(v953, "secondary")
		else
			v996 = false
		end
		v995.Visible = v996
		v_u_861.Text = p951.tw == true and "x2" or "2ND"
		local v997 = 0
		local v998 = p951.mods
		if type(v998) == "table" then
			for _, v999 in p951.mods do
				if type(v999) ~= "table" then
					continue
				end
				v997 = v997 + 1
			end
		end
		local v1000 = v_u_12[p951.id] == true
		v_u_897(v1000)
		v_u_902 = p951.id
		local v1001 = v_u_16[p951.id] == true
		if v1001 or v_u_898 ~= nil then
			v_u_935(v1001)
		end
		local v1002 = 0
		if v997 == 0 then
			local v1003 = p951.items
			if type(v1003) == "table" and (not p951._slot and p951.tw ~= true) then
				for _, v1004 in p951.items do
					if type(v1004) ~= "table" then
						continue
					end
					v1002 = v1002 + 1
				end
			end
		end
		local v1005 = v_u_11.modBadgesWidth(v997)
		local v1006
		if v997 > 0 then
			v1006 = v954 * p952 >= v1005 + 34 + (v1000 and 15 or 0)
		else
			v1006 = false
		end
		local v1007 = ""
		local v1008 = v_u_67(p951)
		if v1008 then
			local v1009 = v1008.dur
			if type(v1009) == "number" then
				local v1010 = v1008.dur
				local v1011 = math.clamp(v1010, 0, 1) * 20
				v1007 = "w" .. math.floor(v1011)
			end
		end
		local v1012 = not v1006 and "" or v_u_7.keyOf(p951.id, p951.mods) .. "#" .. v997 .. v1007
		if v1012 ~= v_u_939 then
			v_u_939 = v1012
			if v_u_938 then
				v_u_938:Destroy()
				v_u_938 = nil
			end
			if v1006 then
				v_u_938 = v_u_11.modBadges(p951.mods, {
					["parent"] = v_u_785,
					["zindex"] = v_u_783 + 3
				})
			end
		end
		if v_u_938 then
			v_u_938.Position = UDim2.fromOffset(v1000 and 17 or 2, 2)
		end
		local v1013 = v_u_865
		local v1014
		if v997 > 0 and not v1006 or v1002 > 0 then
			v1014 = v954 * p952 >= 60
		else
			v1014 = false
		end
		v1013.Visible = v1014
		local v1015 = v_u_865
		local v1016
		if v997 > 0 then
			v1016 = "+" .. v997
		else
			v1016 = tostring(v1002)
		end
		v1015.Text = v1016
		local v1017 = v_u_865
		local v1018
		if v997 > 0 then
			v1018 = v_u_10.info
		else
			v1018 = v_u_10.accent
		end
		v1017.TextColor3 = v1018
		v_u_865.Position = UDim2.fromOffset(v1000 and 17 or 2, 2)
		local v1019
		if v_u_938 then
			v1019 = v1005 + 2
		else
			v1019 = not v_u_865.Visible and 0 or v_u_812 + 2
		end
		v_u_808.Size = UDim2.new(1, -8 - v1019 - (v1000 and 15 or 0), 0, v_u_805)
		local v1020 = not v_u_857.Visible and 3 or v_u_811 + 4
		v_u_869.Position = UDim2.new(0, v1020, 1, -7)
		v_u_849.Position = UDim2.new(0, v1020, 1, -2)
	end
	local v1034 = {
		["frame"] = v_u_785,
		["inst"] = p779,
		["set"] = v1021,
		["setGhosted"] = function(p1022) -- name: setGhosted
			-- upvalues: (ref) v_u_941, (copy) v_u_785, (copy) v_u_789, (ref) v_u_936
			if v_u_941 ~= p1022 then
				v_u_941 = p1022
				v_u_785.BackgroundTransparency = p1022 and 0.7 or 0.05
				v_u_789.Visible = not p1022
				if v_u_936 then
					v_u_936.ImageTransparency = p1022 and 0.75 or 0
				end
			end
		end,
		["flash"] = function() -- name: flash
			-- upvalues: (ref) v_u_10, (copy) v_u_783, (copy) v_u_785, (ref) v_u_4, (ref) v_u_936, (ref) v_u_941
			local v1023 = {
				["Name"] = "Flash",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.55,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = v_u_10.accent,
				["Size"] = UDim2.fromScale(1, 1),
				["ZIndex"] = v_u_783 + 4
			}
			local v1024 = v_u_785
			local v_u_1025 = Instance.new("Frame")
			for v1026, v1027 in v1023 do
				v_u_1025[v1026] = v1027
			end
			if v1024 then
				v_u_1025.Parent = v1024
			end
			local v1028 = game:GetService("TweenService"):Create(v_u_1025, v_u_4.tweenInfo and v_u_4.tweenInfo("slower") or TweenInfo.new(0.45), {
				["BackgroundTransparency"] = 1
			})
			v1028.Completed:Connect(function()
				-- upvalues: (copy) v_u_1025
				v_u_1025:Destroy()
			end)
			v1028:Play()
			local v1029 = v_u_936
			if v1029 then
				v1029.ImageTransparency = 1
				local v1030 = {
					["ImageTransparency"] = v_u_941 and 0.75 or 0
				}
				game:GetService("TweenService"):Create(v1029, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v1030):Play()
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (ref) v_u_942, (ref) v_u_936, (ref) v_u_7, (ref) v_u_937, (ref) v_u_943, (copy) v_u_785
			v_u_942 = false
			if v_u_936 then
				v_u_7.release(v_u_936)
				v_u_936 = nil
				v_u_937 = nil
			end
			v_u_943 = true
			local v1031 = v_u_785.Destroy
			local v1032 = v_u_785
			pcall(v1031, v1032)
		end,
		["showIcon"] = function(p1033) -- name: showIcon
			-- upvalues: (ref) v_u_936, (ref) v_u_7, (ref) v_u_937, (ref) v_u_943, (ref) v_u_942, (ref) v_u_940, (copy) v_u_950
			if v_u_936 and not v_u_7.alive(v_u_936) then
				v_u_936 = nil
				v_u_937 = nil
			end
			if v_u_943 then
				if v_u_936 then
					v_u_7.release(v_u_936)
					v_u_936 = nil
					v_u_937 = nil
				end
			else
				v_u_942 = p1033
				if p1033 then
					if not v_u_936 and v_u_940.inst then
						v_u_950(v_u_940.inst)
						return
					end
				elseif v_u_936 then
					v_u_7.release(v_u_936)
					v_u_936 = nil
					v_u_937 = nil
				end
			end
		end,
		["hasIcon"] = function() -- name: hasIcon
			-- upvalues: (ref) v_u_936, (ref) v_u_7, (ref) v_u_937
			if v_u_936 and not v_u_7.alive(v_u_936) then
				v_u_936 = nil
				v_u_937 = nil
			end
			return v_u_936 ~= nil
		end,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_943
			return not v_u_943
		end
	}
	v1021(p779, p780)
	if v_u_782.parent then
		v_u_785.Parent = v_u_782.parent
	end
	return v1034
end
v_u_11.SLOT_TOP = 2
function v_u_11.slotHeights(p1035, p1036, p1037, p1038, p1039) -- name: slotHeights
	-- upvalues: (copy) v_u_4, (copy) v_u_11
	if p1038 == nil then
		p1038 = v_u_4.isPhone ~= nil and v_u_4.isPhone()
		if not p1038 then
			if v_u_4.isTouch == nil then
				p1038 = false
			else
				p1038 = v_u_4.isTouch()
			end
		end
	end
	if not p1038 then
		return p1035, p1036, p1037
	end
	local v1040 = (p1039 or v_u_4.touch(44)) + v_u_11.SLOT_TOP + 3
	return math.max(p1035, v1040), math.max(p1036, v1040), math.max(p1037, v1040)
end
function v_u_11.slotFit(p1041, p1042, p1043) -- name: slotFit
	-- upvalues: (copy) v_u_4, (copy) v_u_11
	local v1044 = p1041.frame
	local v1045 = p1042 and 19 or 23
	local v1046 = p1042 and 3 or 4
	if p1043 == nil then
		p1043 = v_u_4.isPhone ~= nil and v_u_4.isPhone()
		if not p1043 then
			if v_u_4.isTouch == nil then
				p1043 = false
			else
				p1043 = v_u_4.isTouch()
			end
		end
	end
	local v1047 = v1044:FindFirstChild("SlotPad")
	if p1043 then
		local v1048 = v_u_11.SLOT_TOP
		v1044.Size = UDim2.new(1, -8, 1, -(v1048 + v1046))
		v1044.Position = UDim2.fromOffset(4, v1048)
		if not (v1047 and v1047:IsA("UIPadding")) then
			v1047 = Instance.new("UIPadding")
			v1047.Name = "SlotPad"
			v1047.Parent = v1044
		end
		v1047.PaddingTop = UDim.new(0, v1045 - v1048)
	else
		v1044.Size = UDim2.new(1, -8, 1, -(v1045 + v1046))
		v1044.Position = UDim2.fromOffset(4, v1045)
		if v1047 then
			v1047:Destroy()
		end
	end
end
return v_u_11