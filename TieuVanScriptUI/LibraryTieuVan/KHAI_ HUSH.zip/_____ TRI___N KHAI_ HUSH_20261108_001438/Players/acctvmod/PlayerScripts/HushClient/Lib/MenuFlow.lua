-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuFlow

local v_u_71 = {
	["RETRY_MIN"] = 0.5,
	["RETRY_MARGIN"] = 0.15,
	["PASS_AGE"] = 15,
	["retryDelay"] = function(p1, p2, p3, p4) -- name: retryDelay
		-- upvalues: (copy) v_u_71
		local v5 = {}
		if type(p1) == "table" then
			for _, v6 in p1 do
				if type(v6) ~= "number" or p2 - v6 > p4 then
					continue
				end
				table.insert(v5, v6)
			end
		end
		table.sort(v5)
		if #v5 < p3 then
			return v_u_71.RETRY_MIN
		end
		local v7 = v5[#v5 - p3 + 1] + p4 - p2 + v_u_71.RETRY_MARGIN
		if v7 < v_u_71.RETRY_MIN then
			v7 = v_u_71.RETRY_MIN
		end
		return v7
	end,
	["homeFocus"] = function(p8, p9) -- name: homeFocus
		if p9 ~= true or type(p8) ~= "table" then
			return "none", nil
		end
		local v10 = p8.focusHome
		if type(v10) == "function" then
			return "shell", nil
		end
		local v11 = p8.homeApi
		if type(v11) == "table" then
			local v12 = v11.padFirst
			if type(v12) == "function" then
				local v13 = v11.padFirst
				local v14, v15 = pcall(v13)
				if v14 and v15 ~= nil then
					return "direct", v15
				end
			end
		end
		return "none", nil
	end,
	["startServices"] = function(p_u_16) -- name: startServices
		local v_u_17 = {
			["rail"] = false,
			["guide"] = false
		}
		if type(p_u_16) ~= "table" then
			return v_u_17
		end
		pcall(function()
			-- upvalues: (copy) p_u_16, (copy) v_u_17
			local v18 = p_u_16.cctx.lib.MenuRail
			if type(v18) == "table" then
				local v19 = v18.bind
				if type(v19) == "function" then
					v18.bind(p_u_16)
					v_u_17.rail = true
				end
			end
		end)
		pcall(function()
			-- upvalues: (copy) p_u_16, (copy) v_u_17
			local v20 = p_u_16.cctx.lib.MailGuide
			if type(v20) == "table" then
				local v21 = v20.attach
				if type(v21) == "function" then
					v20.attach(p_u_16)
					v_u_17.guide = true
				end
			end
		end)
		return v_u_17
	end,
	["passSetup"] = function(p_u_22) -- name: passSetup
		if type(p_u_22) ~= "table" then
			return nil
		end
		local v_u_23 = "MenuPassRules"
		local v24, v25 = pcall(function()
			-- upvalues: (copy) p_u_22, (copy) v_u_23
			return p_u_22[v_u_23]
		end)
		if not v24 or type(v25) ~= "table" then
			v25 = nil
		end
		if v25 == nil then
			return nil
		end
		local v_u_26 = "GameMode"
		local v27, v_u_28 = pcall(function()
			-- upvalues: (copy) p_u_22, (copy) v_u_26
			return p_u_22[v_u_26]
		end)
		if not v27 or type(v_u_28) ~= "table" then
			v_u_28 = nil
		end
		local v_u_29 = "SeasonRules"
		local v30, v31 = pcall(function()
			-- upvalues: (copy) p_u_22, (copy) v_u_29
			return p_u_22[v_u_29]
		end)
		if not v30 or type(v31) ~= "table" then
			v31 = nil
		end
		local v_u_32 = "pve"
		local v_u_33 = false
		local function v35()
			-- upvalues: (copy) v_u_28, (ref) v_u_32, (ref) v_u_33
			if v_u_28 ~= nil and v_u_28.isPvpve() then
				v_u_32 = "pvpve"
			end
			local v34
			if v_u_28 == nil then
				v34 = false
			else
				v34 = v_u_28.rule("killCardCosmetics") == true
			end
			v_u_33 = v34
			if v_u_28 ~= nil and v_u_28.rule("seasonPass") == false then
				v_u_32 = "off"
			end
		end
		pcall(v35)
		if v_u_32 == "off" then
			return nil
		end
		local v36 = {
			["R"] = v25,
			["SR"] = v31
		}
		local v37 = {
			["mode"] = v_u_32,
			["killCard"] = v_u_33
		}
		local v_u_38 = "SeasonOp1"
		local v39, v40 = pcall(function()
			-- upvalues: (copy) p_u_22, (copy) v_u_38
			return p_u_22[v_u_38]
		end)
		if not v39 or type(v40) ~= "table" then
			v40 = nil
		end
		v37.ops = v40
		local v41
		if v31 == nil then
			v41 = nil
		else
			v41 = v31.TUNE
		end
		v37.tune = v41
		v36.ctx = v37
		return v36
	end,
	["passClaimable"] = function(p42, p43) -- name: passClaimable
		if type(p42) == "table" and type(p43) == "table" then
			local v44 = p42.R
			local v45 = p42.SR
			local v46 = v44.model(p43, p42.ctx)
			local v47 = v44.claimPlan(v46)
			local v48 = v44.widget(v46, v47, 0)
			if type(v48) == "table" and v48.show == true then
				local v49 = (type(v47) ~= "table" or v47.ok ~= true) and 0 or (v47.count or 0) + (v47.milestones or 0)
				local v50 = 0
				if type(v45) == "table" then
					local v51 = v45.attention
					if type(v51) == "function" then
						local v52 = v45.attention(v49, false, false)
						if type(v52) == "table" then
							local v53 = v52.count
							if type(v53) == "number" then
								v50 = v52.count
							end
						end
					end
				end
				local v54 = true
				if v50 > 0 then
					return v54, v50
				else
					return v54, nil
				end
			else
				return false, nil
			end
		else
			return false, nil
		end
	end,
	["refreshPass"] = function(p_u_55, p_u_56) -- name: refreshPass
		-- upvalues: (copy) v_u_71
		if type(p_u_55) == "table" and type(p_u_56) == "table" then
			local v57 = p_u_56.spawn
			if type(v57) == "function" then
				local v58 = p_u_56.setAttr
				if type(v58) == "function" then
					local function v59()
						-- upvalues: (ref) v_u_71, (copy) p_u_55
						return v_u_71.passSetup(p_u_55.cctx.shared)
					end
					local v60, v_u_61 = pcall(v59)
					if not v60 or v_u_61 == nil then
						return false
					end
					p_u_56.spawn(function()
						-- upvalues: (copy) p_u_55, (copy) v_u_61, (ref) v_u_71, (copy) p_u_56
						local function v62()
							-- upvalues: (ref) p_u_55, (ref) v_u_61, (ref) v_u_71
							return p_u_55.fetch(v_u_61.R.GET, nil, v_u_71.PASS_AGE)
						end
						local v63, v64 = pcall(v62)
						if v63 and type(v64) == "table" then
							local v65 = p_u_56.alive
							if type(v65) ~= "function" or p_u_56.alive() then
								local v66 = v_u_71.passClaimable
								local v67 = v_u_61
								local v68, v69, v70 = pcall(v66, v67, v64)
								if v68 and v69 == true then
									p_u_56.setAttr("PassClaimable", v70)
								end
							end
						else
							return
						end
					end)
					return true
				end
			end
		end
		return false
	end
}
return v_u_71