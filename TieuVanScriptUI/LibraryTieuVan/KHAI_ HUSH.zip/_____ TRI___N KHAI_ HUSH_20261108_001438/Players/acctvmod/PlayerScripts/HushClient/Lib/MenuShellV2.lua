-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuShellV2

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v_u_5 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_6 = {
	["street"] = true,
	["character"] = true,
	["wide"] = true,
	["debrief"] = true,
	["intro"] = true,
	["hideout"] = true,
	["play"] = true
}
function v_u_4.underTopbar(p7, p8, p9, p10, p11, p12, p13, p14) -- name: underTopbar
	local v15 = p7 + p11
	local v16 = p8 + p12
	local v17
	if v15 < p13 - 0.5 and (v16 < p14 - 0.5 and v15 + p9 > 0.5) then
		v17 = v16 + p10 > 0.5
	else
		v17 = false
	end
	return v17
end
function v_u_4.labelCut(p18, p19, p20, p21, p22, p23, p24) -- name: labelCut
	if p18 == "" or (p19 >= 1 or p20 <= 0) then
		p21 = false
	elseif p21 then
		p21 = not (p22 or p23)
		if p21 then
			p21 = not p24
		end
	end
	return p21
end
function v_u_4.slab(p25, p_u_26) -- name: slab
	-- upvalues: (copy) v_u_5
	local v_u_27 = p25.ui
	local v_u_28 = p25.theme
	local v_u_29 = v_u_28.color
	local v_u_30 = p_u_26.kind or "row"
	local v31 = v_u_27.new
	local v32 = "TextButton"
	local v33 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Selectable"] = true,
		["Name"] = p_u_26.name or "Slab"
	}
	local v34
	if v_u_30 == "accent" then
		v34 = v_u_29.accent
	else
		v34 = v_u_29.raised
	end
	v33.BackgroundColor3 = v34
	v33.BackgroundTransparency = v_u_30 == "accent" and 0 or 0.12
	v33.LayoutOrder = p_u_26.order or 0
	local v_u_35 = v31(v32, v33, p_u_26.parent)
	if p_u_26.rect then
		local v36 = p_u_26.rect
		v_u_35.Position = UDim2.fromOffset(v36.x, v36.y)
		v_u_35.Size = UDim2.fromOffset(v36.w, v36.h)
	elseif p_u_26.size then
		v_u_35.Size = p_u_26.size
	end
	v_u_35.SelectionImageObject = v_u_27.selectionImage()
	local v_u_37 = v_u_27.new("UIScale", {
		["Name"] = "Press"
	}, v_u_35)
	local v38 = v_u_27.stroke
	local v39
	if v_u_30 == "accent" then
		v39 = v_u_29.accent
	else
		v39 = v_u_29.line
	end
	local v_u_40 = v38(v_u_35, v39)
	local v41 = v_u_27.new
	local v42 = "Frame"
	local v43 = {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3
	}
	local v44
	if v_u_30 == "accent" then
		v44 = v_u_29.bgDeep
	else
		v44 = v_u_29.accent
	end
	v43.BackgroundColor3 = v44
	v43.Size = UDim2.new(0, 3, 1, 0)
	local v_u_45 = v41(v42, v43, v_u_35)
	local v_u_46 = v_u_27.new("Frame", {
		["Name"] = "Underline",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Visible"] = nil,
		["BackgroundColor3"] = v_u_29.accent,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(0, 0, 0, 2),
		["Visible"] = v_u_30 ~= "accent"
	}, v_u_35)
	local v47 = (v_u_30 == "chip" or v_u_30 == "accent") and true or p_u_26.align == "center"
	local v48 = p_u_26.sub
	local v49 = type(v48) == "string"
	local v50
	if v_u_30 == "accent" then
		v50 = v_u_29.bgDeep
	else
		v50 = v_u_29.text
	end
	local v51 = v_u_30 == "accent" and "h1" or (v_u_30 == "row" and "h2" or "bodyStrong")
	local v52 = p_u_26.textSize or (v_u_30 == "accent" and 28 or (v_u_30 == "row" and 20 or (v_u_30 == "back" and 16 or 14)))
	local v53 = v_u_30 == "row" and 56 or 8
	local v_u_54 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Label",
		["text"] = nil,
		["style"] = nil,
		["textSize"] = nil,
		["color"] = nil,
		["align"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["zindex"] = 2,
		["parent"] = v_u_35,
		["text"] = p_u_26.text or "",
		["style"] = v51,
		["textSize"] = v52,
		["color"] = v50,
		["align"] = v47 and "center" or "left",
		["position"] = UDim2.new(0, v47 and 6 or 16, 0, 0),
		["size"] = UDim2.new(1, -(v47 and 12 or 16) - v53, 1, v49 and -14 or 0)
	})
	local v55 = v_u_27.label
	local v56 = {
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["track"] = false,
		["align"] = nil,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 2,
		["parent"] = v_u_35,
		["text"] = p_u_26.sub or ""
	}
	local v57
	if v_u_30 == "accent" then
		v57 = v_u_29.bgDeep
	else
		v57 = v_u_29.text2
	end
	v56.color = v57
	v56.align = v47 and "center" or "left"
	v56.position = UDim2.new(0, v47 and 6 or 16, 1, -16)
	v56.size = UDim2.new(1, -(v47 and 12 or 16) - v53, 0, 14)
	local v_u_58 = v55(v56)
	v_u_58.Visible = v49
	local v_u_59 = v_u_27.label({
		["parent"] = nil,
		["name"] = "Chevron",
		["text"] = "\226\128\186",
		["style"] = "h2",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["track"] = false,
		["zindex"] = 2,
		["parent"] = v_u_35,
		["color"] = v_u_29.text2,
		["position"] = UDim2.new(1, -16, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0, 20, 1, 0)
	})
	v_u_59.Visible = v_u_30 == "row"
	local v_u_60 = v_u_30 == "row" and 24 or 18
	local v61 = v_u_27.new
	local v62 = "Frame"
	local v63 = {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_29.accent,
		["AnchorPoint"] = Vector2.new(1, v_u_30 == "row" and 0.5 or 0)
	}
	local v64
	if v_u_30 == "row" then
		v64 = UDim2.new(1, -14, 0.5, 0)
	else
		v64 = UDim2.new(1, -2, 0, 2)
	end
	v63.Position = v64
	v63.Size = UDim2.fromOffset(v_u_60, v_u_60)
	local v_u_65 = v61(v62, v63, v_u_35)
	local v_u_66 = v_u_27.label({
		["parent"] = nil,
		["name"] = "N",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["track"] = false,
		["zindex"] = 5,
		["parent"] = v_u_65,
		["textSize"] = v_u_30 == "row" and 13 or 11,
		["color"] = v_u_29.bgDeep,
		["size"] = UDim2.fromScale(1, 1)
	})
	v_u_66.FontFace = v_u_28.font.monoBold
	local v_u_67 = false
	local v_u_68 = false
	local v_u_69 = true
	local v_u_70 = 0
	local function v_u_86() -- name: paint
		-- upvalues: (copy) v_u_30, (copy) v_u_35, (ref) v_u_69, (copy) v_u_29, (ref) v_u_67, (copy) v_u_40, (copy) v_u_54, (copy) v_u_58, (ref) v_u_68, (ref) v_u_70, (copy) v_u_27, (copy) v_u_46
		if v_u_30 == "accent" then
			local v71 = v_u_35
			local v72
			if v_u_69 then
				if v_u_67 then
					v72 = v_u_29.accentDim
				else
					v72 = v_u_29.accent
				end
			else
				v72 = v_u_29.raised2
			end
			v71.BackgroundColor3 = v72
			local v73 = v_u_40
			local v74
			if v_u_69 then
				v74 = v_u_29.accent
			else
				v74 = v_u_29.line
			end
			v73.Color = v74
			local v75 = v_u_54
			local v76
			if v_u_69 then
				v76 = v_u_29.bgDeep
			else
				v76 = v_u_29.muted
			end
			v75.TextColor3 = v76
			local v77 = v_u_58
			local v78
			if v_u_69 then
				v78 = v_u_29.bgDeep
			else
				v78 = v_u_29.muted
			end
			v77.TextColor3 = v78
		else
			local v79 = v_u_67
			if v79 then
				v79 = v_u_69
			end
			local v80 = v_u_40
			local v81
			if v_u_68 then
				v81 = v_u_29.accent
			elseif v79 then
				v81 = v_u_29.lineStrong
			elseif v_u_70 > 0 then
				v81 = v_u_29.accentDim
			else
				v81 = v_u_29.line
			end
			v80.Color = v81
			local v82 = v_u_35
			local v83
			if v79 or v_u_68 then
				v83 = v_u_29.raised2
			else
				v83 = v_u_29.raised
			end
			v82.BackgroundColor3 = v83
			v_u_27.tween(v_u_46, {
				["Size"] = UDim2.new((v79 or v_u_68) and 1 or 0, 0, 0, 2)
			}, v79 and "slow" or "fast")
			local v84 = v_u_54
			local v85
			if v_u_69 then
				if v_u_68 then
					v85 = v_u_29.accent
				else
					v85 = v_u_29.text
				end
			else
				v85 = v_u_29.muted
			end
			v84.TextColor3 = v85
		end
	end
	v_u_35.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_67, (copy) v_u_27, (copy) v_u_28, (copy) v_u_86
		v_u_67 = true
		v_u_27.sound(v_u_28.sounds.hover)
		v_u_86()
	end)
	v_u_35.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_67, (copy) v_u_27, (copy) v_u_37, (copy) v_u_86
		v_u_67 = false
		v_u_27.tween(v_u_37, {
			["Scale"] = 1
		}, "fast")
		v_u_86()
	end)
	v_u_35.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_67, (copy) v_u_27, (copy) v_u_28, (copy) v_u_86
		v_u_67 = true
		v_u_27.sound(v_u_28.sounds.hover)
		v_u_86()
	end)
	v_u_35.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_67, (copy) v_u_86
		v_u_67 = false
		v_u_86()
	end)
	v_u_35.InputBegan:Connect(function(p87)
		-- upvalues: (ref) v_u_69, (copy) v_u_27, (copy) v_u_37, (copy) v_u_28
		if v_u_69 and (p87.UserInputType == Enum.UserInputType.MouseButton1 or p87.UserInputType == Enum.UserInputType.Touch) then
			v_u_27.tween(v_u_37, {
				["Scale"] = v_u_28.motion.pressScale
			}, 0.06)
		end
	end)
	v_u_35.InputEnded:Connect(function(p88)
		-- upvalues: (copy) v_u_27, (copy) v_u_37, (ref) v_u_67, (copy) v_u_86
		if p88.UserInputType == Enum.UserInputType.MouseButton1 or p88.UserInputType == Enum.UserInputType.Touch then
			v_u_27.tween(v_u_37, {
				["Scale"] = 1
			}, "fast")
			if p88.UserInputType == Enum.UserInputType.Touch then
				v_u_67 = false
				v_u_86()
			end
		end
	end)
	local function v89() -- name: pressed
		-- upvalues: (ref) v_u_69, (copy) v_u_27, (copy) v_u_28, (copy) p_u_26
		if v_u_69 then
			v_u_27.sound(v_u_28.sounds.click)
			if p_u_26.onClick then
				task.spawn(p_u_26.onClick)
			end
		end
	end
	v_u_35.Activated:Connect(v89)
	if p_u_26.tip then
		v_u_27.tooltip(v_u_35, p_u_26.tip)
	end
	v_u_86()
	local v90 = {
		["btn"] = v_u_35,
		["label"] = v_u_54,
		["sub"] = v_u_58,
		["chip"] = v_u_65,
		["press"] = v89
	}
	v_u_5[v_u_35] = v90
	function v90.setText(p91) -- name: setText
		-- upvalues: (copy) v_u_27, (copy) v_u_54
		v_u_27.setText(v_u_54, p91)
	end
	function v90.setSub(p92) -- name: setSub
		-- upvalues: (copy) v_u_58
		if p92 == nil or p92 == "" then
			v_u_58.Visible = false
		else
			v_u_58.Visible = true
			if v_u_58.Text ~= p92 then
				v_u_58.Text = p92
			end
		end
	end
	local v_u_93 = -1
	function v90.setBadge(p94) -- name: setBadge
		-- upvalues: (ref) v_u_93, (ref) v_u_70, (copy) v_u_65, (copy) v_u_45, (copy) v_u_30, (copy) v_u_59, (copy) v_u_66, (copy) v_u_60, (copy) v_u_86
		local v95 = tonumber(p94) or 0
		local v96 = math.floor(v95)
		local v97 = math.max(0, v96)
		if v97 ~= v_u_93 then
			v_u_93 = v97
			v_u_70 = v97
			v_u_65.Visible = v97 > 0
			local v98 = v_u_45
			local v99
			if v97 > 0 then
				v99 = v_u_30 ~= "accent"
			else
				v99 = false
			end
			v98.Visible = v99
			if v_u_30 == "row" then
				v_u_59.Visible = v97 <= 0
			end
			local v100 = v97 > 9 and "9+" or tostring(v97)
			if v_u_66.Text ~= v100 then
				v_u_66.Text = v100
			end
			local v101 = v_u_65
			local v102 = UDim2.fromOffset
			local v103
			if v97 > 9 then
				v103 = v_u_60 + 8
			else
				v103 = v_u_60
			end
			v101.Size = v102(v103, v_u_60)
			v_u_86()
		end
	end
	function v90.setSelected(p104) -- name: setSelected
		-- upvalues: (ref) v_u_68, (copy) v_u_86
		v_u_68 = p104
		v_u_86()
	end
	function v90.setEnabled(p105) -- name: setEnabled
		-- upvalues: (ref) v_u_69, (copy) v_u_35, (copy) v_u_86
		v_u_69 = p105
		v_u_35.Selectable = p105
		v_u_86()
	end
	function v90.badge() -- name: badge
		-- upvalues: (ref) v_u_70
		return v_u_70
	end
	return v90
end
function v_u_4.build(p_u_106, p_u_107, p_u_108) -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_1, (copy) v_u_3
	local v_u_109 = p_u_106.ui
	local v_u_110 = p_u_106.theme
	local v111 = v_u_110.color
	local v_u_112 = p_u_108.route
	local v_u_113 = p_u_108.categories
	local v_u_114 = p_u_108.layout
	local v115 = p_u_108.home
	local v_u_116 = p_u_108.director
	local v_u_117 = {}
	local v_u_118 = true
	local v_u_119 = {}
	local v_u_120 = {}
	local v_u_121 = v_u_112.new()
	local v_u_122 = v_u_110.safeRefSize()
	local v_u_123 = v_u_110.touch(44)
	local v_u_124 = v_u_110.isPhone() or v_u_122.X < 900
	local v125 = not p_u_108.floorX and 0 or p_u_108.floorX()
	local v127 = p_u_108.insetKey or function()
		-- upvalues: (ref) v_u_2
		local v126 = v_u_2.TopbarInset
		return ("%d,%d"):format(v126.Min.X, v126.Max.Y)
	end
	local v128, v129 = pcall(v127)
	local v_u_130 = not v128 and "" or tostring(v129)
	local v_u_131 = v_u_112.headerGap(v_u_124)
	local v_u_132 = v_u_109.new("Frame", {
		["Name"] = "MenuShell",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}, p_u_107)
	v_u_117.pagesFrame = v_u_109.new("Frame", {
		["Name"] = "Pages",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_132)
	local v_u_133 = v_u_109.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_132)
	local v_u_134 = v_u_109.new("Frame", {
		["Name"] = "Home",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_132)
	local v135 = v_u_114.page(v_u_122, {
		["touch"] = nil,
		["phone"] = nil,
		["subs"] = 0,
		["touch"] = v_u_123,
		["phone"] = v_u_124
	})
	local v136 = v_u_112.headerShift(v135, v125, v_u_131)
	local v_u_137 = v_u_4.slab(p_u_106, {
		["parent"] = nil,
		["name"] = "Back",
		["rect"] = nil,
		["text"] = "BACK",
		["kind"] = "back",
		["align"] = "center",
		["textSize"] = nil,
		["onClick"] = nil,
		["tip"] = nil,
		["parent"] = v_u_133,
		["rect"] = v136.back,
		["textSize"] = v_u_124 and 16 or 18,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_117
			v_u_117.back()
		end,
		["tip"] = function() -- name: tip
			return {
				["title"] = "BACK",
				["body"] = "Go back one step."
			}
		end
	})
	local v_u_138 = nil
	local v139
	if v_u_109.device() == "Touch" then
		v139 = ""
	else
		local v140 = v_u_109.hint
		local v141, v142 = pcall(v140, "back")
		v139 = (not v141 or type(v142) ~= "string") and "" or v142
	end
	if v139 ~= "" then
		v_u_138 = v_u_109.label({
			["parent"] = nil,
			["name"] = "Hint",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["track"] = false,
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["zindex"] = 3,
			["parent"] = v_u_137.btn,
			["text"] = v139,
			["color"] = v111.text2,
			["position"] = UDim2.new(1, -8, 0, 4),
			["anchor"] = Vector2.new(1, 0),
			["size"] = UDim2.new(0, 36, 0, 12)
		})
	end
	local v_u_143 = v_u_109.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "h1",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_133,
		["textSize"] = v_u_124 and 24 or 30,
		["position"] = UDim2.fromOffset(v136.title.x, v136.title.y),
		["size"] = UDim2.fromOffset(v136.title.w, v136.title.h)
	})
	local v144 = v_u_109.new("Frame", {
		["Name"] = "Cash",
		["BackgroundTransparency"] = 1
	}, v_u_133)
	local v145 = v135.cash
	v144.Position = UDim2.fromOffset(v145.x, v145.y)
	v144.Size = UDim2.fromOffset(v145.w, v145.h)
	v_u_109.label({
		["parent"] = nil,
		["text"] = "Cash",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v144,
		["color"] = v111.text2,
		["size"] = UDim2.new(1, 0, 0, 14),
		["position"] = UDim2.fromOffset(0, 2)
	})
	v_u_117.cashLabel = v_u_109.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = "$-",
		["style"] = "monoL",
		["textSize"] = 20,
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v144,
		["color"] = v111.accent,
		["position"] = UDim2.fromOffset(0, 16),
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	local v_u_146 = v_u_109.new("ScrollingFrame", {
		["Name"] = "Subs",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 0,
		["Visible"] = false,
		["ZIndex"] = 5,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
		["ScrollingDirection"] = Enum.ScrollingDirection.X
	}, v_u_132)
	local v_u_147 = {}
	local v_u_148 = nil
	local v149 = v115.build
	local v151 = {
		["cctx"] = p_u_108.cctx,
		["lib"] = p_u_108.lib,
		["has"] = p_u_108.has,
		["route"] = v_u_112,
		["categories"] = v_u_113,
		["layout"] = v_u_114,
		["slab"] = v_u_4.slab,
		["ref"] = v_u_122,
		["touch"] = v_u_123,
		["phone"] = v_u_124,
		["floorX"] = v125,
		["visible"] = p_u_108.visible,
		["now"] = p_u_108.now,
		["activate"] = function(p150) -- name: activate
			-- upvalues: (copy) v_u_117
			v_u_117.activate(p150)
		end
	}
	local v152, v153 = pcall(v149, p_u_106, v_u_134, v151)
	if v152 then
		v_u_148 = v153
	else
		warn("[MenuShellV2] home failed:", v153)
		game:GetService("Players").LocalPlayer:SetAttribute("ClientError", "menu home: " .. tostring(v153))
	end
	v_u_117.homeApi = v_u_148
	local v_u_154 = nil
	local v_u_155 = nil
	local v_u_156 = nil
	local v_u_157 = 0
	local function v_u_170(p158, p159) -- name: sceneFor
		-- upvalues: (copy) p_u_108, (copy) v_u_116, (ref) v_u_6
		local v160 = "street"
		local v161 = "play"
		if p158 == nil then
			local v_u_162 = false
			local function v163()
				-- upvalues: (ref) v_u_162, (ref) p_u_108
				v_u_162 = p_u_108.cctx.config.flag("MenuV2Vista") == true
			end
			pcall(v163)
			if v_u_162 and (v_u_116 and (v_u_116.defs and v_u_116.defs.vista ~= nil)) then
				return "vista", "home"
			end
		else
			local v164 = p158.scene
			local v165 = p158.shot
			if p159 then
				local v166 = p159.tab
				if type(v166) == "table" then
					local v167 = p159.tab.scene
					if type(v167) == "function" then
						local v168 = p159.tab.scene
						local v169
						v169, v160, v161 = pcall(v168)
						if v169 and type(v160) == "string" then
							if type(v161) ~= "string" then
								v161 = v165
								v160 = v164
							end
						else
							v161 = v165
							v160 = v164
						end
					else
						v161 = v165
						v160 = v164
					end
				else
					v161 = v165
					v160 = v164
				end
			else
				v161 = v165
				v160 = v164
			end
		end
		if v_u_116 == nil or (v_u_116.defs == nil or v_u_116.defs[v160] == nil) then
			return "street", "wide"
		elseif v160 == "street" and v_u_6[v161] ~= true then
			return "street", "wide"
		else
			return v160, v161
		end
	end
	function v_u_117.cam() -- name: cam
		-- upvalues: (copy) v_u_116, (ref) v_u_118, (copy) v_u_170, (ref) v_u_156, (ref) v_u_154
		if v_u_116 ~= nil and v_u_118 then
			local v171, v172 = v_u_170(v_u_156, v_u_154)
			local v173 = v_u_116.go
			local v174 = v_u_116
			pcall(v173, v174, v171, v172)
		end
	end
	local function v_u_193(p_u_175, p176) -- name: paintSubs
		-- upvalues: (copy) v_u_147, (copy) v_u_146, (copy) v_u_114, (copy) v_u_122, (copy) v_u_123, (copy) v_u_124, (copy) v_u_112, (ref) v_u_4, (copy) p_u_106, (copy) v_u_131, (copy) v_u_117
		for _, v177 in v_u_147 do
			v177.btn:Destroy()
		end
		table.clear(v_u_147)
		if p_u_175 then
			local v178 = p_u_175.subs
			if type(v178) == "table" then
				local v179
				if p_u_175 then
					local v180 = p_u_175.subs
					v179 = type(v180) == "table" and #p_u_175.subs or 0
				else
					v179 = 0
				end
				local v181 = {
					["touch"] = v_u_123,
					["phone"] = v_u_124,
					["subs"] = v179
				}
				local v182 = v_u_114.page(v_u_122, v181)
				local v183 = v_u_146
				local v184 = v182.subs
				v183.Position = UDim2.fromOffset(v184.x, v184.y)
				v183.Size = UDim2.fromOffset(v184.w, v184.h)
				v_u_146.Visible = true
				v_u_146.CanvasPosition = Vector2.new(0, 0)
				local v185 = v_u_112.subOf(p_u_175, p176)
				local v186 = not v182.subChips[1] and 120 or v182.subChips[1].w
				local v187 = v182.subs.h
				for v188, v_u_189 in p_u_175.subs do
					local v190 = v_u_4.slab(p_u_106, {
						["parent"] = nil,
						["name"] = nil,
						["rect"] = nil,
						["text"] = nil,
						["kind"] = "sub",
						["align"] = "center",
						["onClick"] = nil,
						["parent"] = v_u_146,
						["name"] = "Sub_" .. v_u_189.id,
						["rect"] = {
							["x"] = nil,
							["y"] = 0,
							["w"] = nil,
							["h"] = nil,
							["x"] = (v188 - 1) * (v186 + v_u_131),
							["w"] = v186,
							["h"] = v187
						},
						["text"] = v_u_189.text,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_117, (copy) p_u_175, (copy) v_u_189
							v_u_117.go(p_u_175.id, v_u_189.id)
						end
					})
					local v191 = v190.setSelected
					local v192
					if v185 == nil then
						v192 = false
					else
						v192 = v185.id == v_u_189.id
					end
					v191(v192)
					v_u_147[v_u_189.id] = v190
				end
				v_u_146.CanvasSize = UDim2.fromOffset(#p_u_175.subs * (v186 + v_u_131) - v_u_131, 0)
				return
			end
		end
		v_u_146.Visible = false
	end
	local function v_u_202(p194, _, p195) -- name: showPage
		-- upvalues: (copy) p_u_108, (copy) v_u_114, (copy) v_u_122, (copy) v_u_123, (copy) v_u_124, (copy) v_u_110, (copy) v_u_109
		local v196 = p_u_108.pageFor(p195)
		if v196 == nil then
			return nil
		end
		local v197
		if p194 then
			local v198 = p194.subs
			v197 = type(v198) == "table" and #p194.subs or 0
		else
			v197 = 0
		end
		local v199 = {
			["touch"] = v_u_123,
			["phone"] = v_u_124,
			["subs"] = v197
		}
		local v200 = v_u_114.page(v_u_122, v199).body
		local v201 = v196.frame
		v201.AnchorPoint = Vector2.new(0, 0)
		v201.Size = UDim2.fromOffset(v200.w, v200.h)
		v201.Visible = true
		v201.Position = UDim2.fromOffset(v200.x, v200.y + v_u_110.motion.slide)
		v_u_109.tween(v201, {
			["Position"] = UDim2.fromOffset(v200.x, v200.y)
		}, "slow")
		p_u_108.callTab(v196, "show")
		v_u_109.fade(v201, 0, "slow", {
			["from"] = v_u_109.fadeAlpha(v201) <= 0 and 1 or nil
		})
		return v196
	end
	local function v_u_209(p203, p204) -- name: hidePage
		-- upvalues: (copy) p_u_108, (copy) v_u_109, (ref) v_u_154
		if p203 == nil then
			return
		else
			local v_u_205 = p203.frame
			p_u_108.callTab(p203, "hide")
			if not p204 then
				v_u_109.tween(v_u_205, {
					["Position"] = UDim2.new(v_u_205.Position.X.Scale, v_u_205.Position.X.Offset, v_u_205.Position.Y.Scale, v_u_205.Position.Y.Offset + 6)
				}, "fast")
				local v208 = {
					["onDone"] = function() -- name: onDone
						-- upvalues: (copy) v_u_205, (ref) v_u_154
						local v206 = v_u_205
						local v207 = v_u_154
						if v207 then
							v207 = v_u_154.frame
						end
						if v206 ~= v207 then
							v_u_205.Visible = false
						end
					end
				}
				v_u_109.fade(v_u_205, 1, "fast", v208)
			end
		end
	end
	local function v_u_214(p210, _) -- name: pageOk
		-- upvalues: (copy) v_u_112, (copy) p_u_108
		local v211 = p210.subs
		if type(v211) == "table" or p210.page ~= nil then
			local v212 = p210.subs
			local v213
			if type(v212) == "table" then
				v213 = v_u_112.subOf(p210, nil)
				if v213 then
					v213 = v213.page
				end
			else
				v213 = p210.page
			end
			if v213 then
				v213 = v213[1]
			end
			if v213 and not p_u_108.has(v213) then
				return false
			end
		end
		return true
	end
	local function v_u_232(p215, p216) -- name: apply
		-- upvalues: (ref) v_u_157, (ref) v_u_154, (ref) v_u_156, (ref) v_u_155, (copy) v_u_209, (copy) v_u_133, (copy) v_u_146, (copy) v_u_134, (copy) v_u_109, (ref) v_u_148, (copy) v_u_117, (ref) v_u_118, (copy) p_u_107, (ref) v_u_2, (copy) p_u_108, (copy) v_u_113, (copy) v_u_112, (copy) v_u_202, (copy) v_u_143, (copy) v_u_193, (copy) v_u_137
		v_u_157 = v_u_157 + 1
		local v217 = v_u_154
		if p215 == nil then
			v_u_156 = nil
			v_u_155 = nil
			v_u_154 = nil
			v_u_209(v217, false)
			v_u_133.Visible = false
			v_u_146.Visible = false
			v_u_134.Visible = true
			v_u_109.fade(v_u_134, 0, "slow", {
				["from"] = 1
			})
			if v_u_148 then
				local v218 = v_u_148.show
				pcall(v218)
			end
			v_u_117.cam()
			local v_u_219 = v_u_148 and (v_u_148.padFirst and v_u_148.padFirst()) or nil
			if v_u_109.device() == "Gamepad" then
				local v_u_220 = nil
				task.defer(function()
					-- upvalues: (ref) v_u_118, (copy) v_u_219, (ref) p_u_107, (copy) v_u_220, (ref) v_u_2
					if v_u_118 and (v_u_219 and (v_u_219.Parent and (v_u_219:IsDescendantOf(p_u_107) and (v_u_220 == nil or v_u_220())))) then
						v_u_2.SelectedObject = v_u_219
					end
				end)
			end
			p_u_108.onChange(nil, nil, nil, nil)
		else
			local v221 = v_u_113.byId(p215)
			local v222 = v_u_112.pageKey(v221, p216)
			local v223 = v_u_202(v221, p216, v222)
			if v217 == nil or v217 == v223 then
				if v217 ~= nil then
					local _ = v217 == v223
				end
			else
				v_u_209(v217, false)
			end
			v_u_156 = v221
			v_u_155 = v222
			v_u_154 = v223
			v_u_134.Visible = false
			if v_u_148 then
				local v224 = v_u_148.hide
				pcall(v224)
			end
			v_u_133.Visible = true
			v_u_109.setText(v_u_143, v221.text)
			v_u_193(v221, p216)
			v_u_117.cam()
			local v225 = v_u_137.btn
			local v_u_226
			if v223 then
				local v227 = v223.tab
				if type(v227) == "table" then
					local v228 = v223.tab.padFirst
					if type(v228) == "function" then
						local v229 = v223.tab.padFirst
						local v230
						v230, v_u_226 = pcall(v229)
						if v230 and (typeof(v_u_226) == "Instance" and (v_u_226:IsA("GuiObject") and (v_u_226.Visible and v_u_226.Parent ~= nil))) then
							if v_u_226.Selectable ~= true then
								v_u_226 = v225
							end
						else
							v_u_226 = v225
						end
					else
						v_u_226 = v225
					end
				else
					v_u_226 = v225
				end
			else
				v_u_226 = v225
			end
			if v_u_109.device() == "Gamepad" then
				local v_u_231 = nil
				task.defer(function()
					-- upvalues: (ref) v_u_118, (copy) v_u_226, (ref) p_u_107, (copy) v_u_231, (ref) v_u_2
					if v_u_118 and (v_u_226 and (v_u_226.Parent and (v_u_226:IsDescendantOf(p_u_107) and (v_u_231 == nil or v_u_231())))) then
						v_u_2.SelectedObject = v_u_226
					end
				end)
			end
			p_u_108.onChange(p215, p216, v222, v221)
		end
	end
	function v_u_117.category() -- name: category
		-- upvalues: (copy) v_u_121
		return v_u_121.id
	end
	function v_u_117.sub() -- name: sub
		-- upvalues: (copy) v_u_121
		return v_u_121.sub
	end
	function v_u_117.pageKey() -- name: pageKey
		-- upvalues: (ref) v_u_155
		return v_u_155
	end
	function v_u_117.page() -- name: page
		-- upvalues: (ref) v_u_154
		return v_u_154
	end
	function v_u_117.party() -- name: party
		-- upvalues: (ref) v_u_148
		if v_u_148 then
			return v_u_148.party
		else
			return nil
		end
	end
	function v_u_117.go(p233, p234) -- name: go
		-- upvalues: (ref) v_u_118, (copy) v_u_117, (copy) v_u_113, (copy) p_u_108, (copy) v_u_112, (copy) v_u_214, (ref) v_u_154, (copy) v_u_121, (ref) v_u_155, (copy) v_u_232
		if not v_u_118 then
			return false
		end
		if p233 == nil then
			v_u_117.home()
			return true
		end
		local v235 = v_u_113.byId(p233)
		if v235 == nil then
			return false
		end
		local v236 = false
		for _, v237 in p_u_108.visible() do
			if v237.id ~= p233 then
				continue
			end
			v236 = true
		end
		if not v236 and v235.parent == nil then
			return false
		end
		local v238 = v_u_112.pageKey(v235, p234)
		if v235.page == nil then
			local v239 = v235.subs
			if type(v239) ~= "table" then
				if v235.action ~= "hideout" and v235.action ~= "enterHideout" then
					return false
				end
				p_u_108.enterHideout()
				return true
			end
		end
		if not v_u_214(v235, v238) then
			local v240 = p_u_108.fallback
			if v240 then
				v240 = p_u_108.fallback[p233]
			end
			local v241
			if type(v240) == "table" then
				v241 = v240[1]
			else
				v241 = v240
			end
			local v242
			if type(v240) == "table" then
				v242 = v240[2]
			else
				v242 = nil
			end
			if v241 and v241 ~= p233 then
				local v243 = v_u_117.go(v241, nil)
				if v243 and v242 ~= nil then
					local v244 = v_u_154
					if v244 ~= nil then
						local v245 = v244.tab
						if type(v245) == "table" then
							local v246 = v244.tab.showSub
							if type(v246) == "function" then
								local v247 = v244.tab.showSub
								pcall(v247, v242)
							end
						end
					end
				end
				return v243
			end
		end
		if not v_u_112.go(v_u_121, p233, p234) and (v_u_154 ~= nil and v_u_155 == v238) then
			return true
		end
		v_u_232(p233, v_u_121.sub)
		return true
	end
	function v_u_117.home() -- name: home
		-- upvalues: (ref) v_u_118, (copy) v_u_121, (copy) v_u_112, (ref) v_u_154, (copy) v_u_134, (copy) v_u_232
		if v_u_118 then
			local v248 = v_u_121.id
			v_u_112.home(v_u_121)
			if v248 == nil and v_u_154 == nil then
				if not v_u_134.Visible then
					v_u_232(nil, nil)
				end
			else
				v_u_232(nil, nil)
			end
		else
			return
		end
	end
	function v_u_117.focusHome() -- name: focusHome
		-- upvalues: (ref) v_u_118, (copy) v_u_121, (copy) v_u_132, (ref) v_u_148, (copy) v_u_109, (copy) p_u_107, (ref) v_u_2
		if v_u_118 and (v_u_121.id == nil and (v_u_132.Visible and v_u_148 ~= nil)) then
			local v249 = v_u_148.padFirst
			if type(v249) == "function" and v_u_109.device() == "Gamepad" then
				local v250 = v_u_148.padFirst
				local v251, v_u_252 = pcall(v250)
				if not v251 or v_u_252 == nil then
					return false
				end
				local function v_u_254()
					-- upvalues: (ref) v_u_121, (ref) v_u_132
					local v253
					if v_u_121.id == nil then
						v253 = v_u_132.Visible
					else
						v253 = false
					end
					return v253
				end
				if v_u_109.device() == "Gamepad" then
					task.defer(function()
						-- upvalues: (ref) v_u_118, (copy) v_u_252, (ref) p_u_107, (copy) v_u_254, (ref) v_u_2
						if v_u_118 and (v_u_252 and (v_u_252.Parent and (v_u_252:IsDescendantOf(p_u_107) and (v_u_254 == nil or v_u_254())))) then
							v_u_2.SelectedObject = v_u_252
						end
					end)
				end
				return true
			end
		end
		return false
	end
	function v_u_117.back() -- name: back
		-- upvalues: (ref) v_u_118, (copy) v_u_121, (copy) v_u_109, (ref) v_u_154, (copy) v_u_110, (copy) v_u_112, (copy) v_u_232
		if not v_u_118 then
			return false
		end
		if v_u_121.id == nil then
			return false
		end
		local v255 = v_u_109.modalCount
		local v256, v257 = pcall(v255)
		if v256 and (type(v257) == "number" and v257 > 0) then
			return false
		end
		local v258 = v_u_154
		if v258 then
			local v259 = v258.tab
			if type(v259) == "table" then
				local v260 = v258.tab.onBack
				if type(v260) == "function" then
					local v261 = v258.tab.onBack
					local v262, v263 = pcall(v261)
					if v262 and v263 == true then
						return true
					end
				end
			end
		end
		v_u_109.sound(v_u_110.sounds.tab)
		local v264, v265 = v_u_112.back(v_u_121)
		if v264 == nil then
			v_u_232(nil, nil)
		else
			v_u_232(v264, v265)
		end
		return true
	end
	function v_u_117.activate(p266) -- name: activate
		-- upvalues: (copy) p_u_108, (ref) v_u_148, (copy) v_u_117
		if p266 == nil then
			return
		elseif p266.action == "hideout" then
			p_u_108.enterHideout()
			return
		elseif p266.action ~= "deploy" or (not v_u_148 or (not v_u_148.deploy or v_u_148.deploy() ~= true)) then
			v_u_117.go(p266.id, nil)
		end
	end
	function v_u_117.setVisible(p267) -- name: setVisible
		-- upvalues: (copy) v_u_132
		v_u_132.Visible = p267
	end
	function v_u_117.setCash(p268) -- name: setCash
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.setCash then
			v_u_148.setCash(p268)
		end
	end
	function v_u_117.setRowText(p269, p270) -- name: setRowText
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.setRowText then
			v_u_148.setRowText(p269, p270)
		end
	end
	function v_u_117.badges() -- name: badges
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.badges then
			local v271 = v_u_148.badges
			pcall(v271)
		end
	end
	function v_u_117.tick() -- name: tick
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.tick then
			local v272 = v_u_148.tick
			pcall(v272)
		end
	end
	function v_u_117.refresh(p273, p274) -- name: refresh
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.refresh then
			local v275 = v_u_148.refresh
			pcall(v275, p273, p274)
		end
	end
	function v_u_117.rowButton(p276) -- name: rowButton
		-- upvalues: (ref) v_u_148
		if v_u_148 and v_u_148.rowButton then
			return v_u_148.rowButton(p276)
		else
			return nil
		end
	end
	function v_u_117.press(p277) -- name: press
		-- upvalues: (copy) v_u_132, (ref) v_u_5
		for _, v281 in v_u_132:GetDescendants() do
			if not v281:IsA("TextButton") or (v281.Name ~= p277 or v_u_5[v281] == nil) then
				continue
			end
			local v279 = v281
			local v280 = true
			while v281 ~= nil and v281 ~= v_u_132.Parent do
				if v281:IsA("GuiObject") and not v281.Visible then
					v280 = false
					break
				end
				local v281 = v281.Parent
			end
			if not v280 then
				break
			end
			v_u_5[v279].press()
			return true
		end
		return false
	end
	function v_u_117.audit(p282) -- name: audit
		-- upvalues: (copy) p_u_107, (copy) v_u_110, (copy) v_u_122, (copy) v_u_132, (ref) v_u_2, (ref) v_u_4
		local v283 = {}
		local v284 = p_u_107:FindFirstChildOfClass("UIScale")
		local v285
		if v284 then
			v285 = v284.Scale
		else
			v285 = v_u_110.uiScale()
		end
		local v286 = p282 or (not v_u_110.isTouch() and 0 or v_u_110.touch(44))
		local v287 = p_u_107.AbsolutePosition
		local v288 = Vector2.new(v_u_122.X * v285, v_u_122.Y * v285)
		local function v290(p289) -- name: shown
			-- upvalues: (ref) v_u_132
			while p289 ~= nil and p289 ~= v_u_132.Parent do
				if p289:IsA("GuiObject") and not p289.Visible then
					return false
				end
				p289 = p289.Parent
			end
			return true
		end
		local function v293(p291) -- name: scrolled
			-- upvalues: (ref) v_u_132
			local v292 = p291.Parent
			while v292 ~= nil and v292 ~= v_u_132 do
				if v292:IsA("ScrollingFrame") then
					return true
				end
				v292 = v292.Parent
			end
			return false
		end
		local v294 = {}
		for _, v295 in v_u_132:GetDescendants() do
			if not v295:IsA("TextButton") or (not v290(v295) or v295.AbsoluteSize.X <= 0) then
				continue
			end
			table.insert(v294, v295)
		end
		for _, v296 in v294 do
			local v297 = v296.AbsolutePosition
			local v298 = v296.AbsoluteSize
			if v298.X / v285 < v286 - 0.5 or v298.Y / v285 < v286 - 0.5 then
				local v299 = v296.Name
				local v300 = v298.X / v285
				local v301 = v298.Y / v285
				table.insert(v283, ("small %s %dx%d"):format(v299, v300, v301))
			end
			if v293(v296) or v297.X >= v287.X - 0.5 and (v297.Y >= v287.Y - 0.5 and (v297.X + v298.X <= v287.X + v288.X + 0.5 and v297.Y + v298.Y <= v287.Y + v288.Y + 0.5)) then
				continue
			end
			local v302 = v296.Name
			table.insert(v283, ("outside %s"):format(v302))
		end
		local v_u_303 = 0
		local v_u_304 = 0
		local function v308()
			-- upvalues: (ref) v_u_2, (ref) v_u_303, (ref) v_u_304
			local v305 = v_u_2.TopbarInset
			local v306 = v305.Min.X
			local v307 = v305.Max.Y
			v_u_303 = v306
			v_u_304 = v307
		end
		pcall(v308)
		local v309 = v_u_303 <= 0 and 120 or v_u_303
		local v310 = v_u_304 <= 0 and 58 or v_u_304
		local v_u_311 = 0
		local v_u_312 = 0
		local function v316()
			-- upvalues: (ref) v_u_2, (ref) v_u_311, (ref) v_u_312
			local v313 = v_u_2:GetGuiInset()
			local v314 = v313.X
			local v315 = v313.Y
			v_u_311 = v314
			v_u_312 = v315
		end
		pcall(v316)
		local v317 = v_u_312
		local v318 = v_u_311
		for _, v319 in v294 do
			local v320 = v319.AbsolutePosition
			local v321 = v319.AbsoluteSize
			if not v_u_4.underTopbar(v320.X, v320.Y, v321.X, v321.Y, v318, v317, v309, v310) then
				continue
			end
			local v322 = v319.Name
			table.insert(v283, ("under the Roblox buttons %s"):format(v322))
		end
		for v323 = 1, #v294 do
			for v324 = v323 + 1, #v294 do
				local v325 = v294[v323]
				local v326 = v294[v324]
				if v293(v325) or (v293(v326) or (v325:IsDescendantOf(v326) or v326:IsDescendantOf(v325))) then
					continue
				end
				local v327 = v325.AbsolutePosition
				local v328 = v325.AbsoluteSize
				local v329 = v326.AbsolutePosition
				local v330 = v326.AbsoluteSize
				if v327.X >= v329.X + v330.X - 1 or (v329.X >= v327.X + v328.X - 1 or (v327.Y >= v329.Y + v330.Y - 1 or v329.Y >= v327.Y + v328.Y - 1)) then
					continue
				end
				local v331 = v325.Name
				local v332 = v326.Name
				table.insert(v283, ("overlap %s / %s"):format(v331, v332))
			end
		end
		for _, v333 in v_u_132:GetDescendants() do
			if not (v333:IsA("TextLabel") and v_u_4.labelCut(v333.Text, v333.TextTransparency, v333.AbsoluteSize.X, v290(v333), v333.TextFits, v333.TextTruncate ~= Enum.TextTruncate.None, v333.TextScaled)) then
				continue
			end
			local v334 = v333:GetFullName():sub(-40)
			local v335 = v333.Text
			table.insert(v283, ("cut %s \'%s\'"):format(v334, v335:sub(1, 20)))
		end
		return ("buttons=%d issues=%d %s"):format(#v294, #v283, table.concat(v283, " | "):sub(1, 900))
	end
	function v_u_117.destroy() -- name: destroy
		-- upvalues: (ref) v_u_118, (copy) v_u_119, (copy) v_u_120, (ref) v_u_148, (copy) v_u_132
		if v_u_118 then
			v_u_118 = false
			for _, v336 in v_u_119 do
				v336:Disconnect()
			end
			table.clear(v_u_119)
			for _, v337 in v_u_120 do
				pcall(v337)
			end
			table.clear(v_u_120)
			if v_u_148 and v_u_148.destroy then
				local v338 = v_u_148.destroy
				pcall(v338)
			end
			v_u_132:Destroy()
		end
	end
	local v_u_339 = false
	local function v_u_348() -- name: checkSize
		-- upvalues: (ref) v_u_339, (ref) v_u_118, (copy) v_u_110, (copy) v_u_122, (copy) v_u_123, (copy) v_u_124, (copy) p_u_108, (ref) v_u_2, (copy) v_u_130
		v_u_339 = false
		if not v_u_118 then
			return
		end
		local v340 = v_u_110.safeRefSize()
		local v341 = v_u_110.isPhone() or v340.X < 900
		local v342 = v340.X - v_u_122.X
		if math.abs(v342) > 1 then
			if p_u_108.onResize then
				p_u_108.onResize()
			end
			return
		else
			local v343 = v340.Y - v_u_122.Y
			if math.abs(v343) > 1 or (v_u_110.touch(44) ~= v_u_123 or v341 ~= v_u_124) then
				if p_u_108.onResize then
					p_u_108.onResize()
				end
				return
			else
				local v345 = p_u_108.insetKey or function()
					-- upvalues: (ref) v_u_2
					local v344 = v_u_2.TopbarInset
					return ("%d,%d"):format(v344.Min.X, v344.Max.Y)
				end
				local v346, v347 = pcall(v345)
				if (not v346 and "" or tostring(v347)) ~= v_u_130 then
					if p_u_108.onResize then
						p_u_108.onResize()
					end
				end
			end
		end
	end
	local v349 = p_u_107:GetPropertyChangedSignal("AbsoluteSize")
	local function v350()
		-- upvalues: (ref) v_u_339, (copy) v_u_348
		if not v_u_339 then
			v_u_339 = true
			task.delay(0.3, v_u_348)
		end
	end
	table.insert(v_u_119, v349:Connect(v350))
	local function v354()
		-- upvalues: (copy) v_u_119, (ref) v_u_2, (ref) v_u_339, (copy) v_u_348
		local v351 = v_u_119
		local v352 = v_u_2:GetPropertyChangedSignal("TopbarInset")
		local function v353()
			-- upvalues: (ref) v_u_339, (ref) v_u_348
			if not v_u_339 then
				v_u_339 = true
				task.delay(0.3, v_u_348)
			end
		end
		table.insert(v351, v352:Connect(v353))
	end
	pcall(v354)
	local v_u_355
	if v_u_339 then
		v_u_355 = v_u_339
	else
		v_u_339 = true
		task.delay(0.8, v_u_348)
		v_u_355 = v_u_339
	end
	local v_u_356 = p_u_108.lib("MenuBackGate")
	local v_u_357 = nil
	local function v_u_383() -- name: gateFacts
		-- upvalues: (copy) v_u_109, (copy) p_u_108, (ref) v_u_1, (ref) v_u_118, (copy) v_u_132, (copy) v_u_121
		local v358 = {}
		local v359 = v_u_109.backTaken
		local v360
		if type(v359) == "function" then
			local v361, v362 = pcall(v359)
			v360 = (not v361 or type(v362) ~= "number") and 0 or v362
		else
			v360 = 0
		end
		local v363 = v_u_109.modalsClosed
		local v364
		if type(v363) == "function" then
			local v365, v366 = pcall(v363)
			v364 = (not v365 or type(v366) ~= "number") and 0 or v366
		else
			v364 = 0
		end
		v358.counter = v360 + v364
		local v367 = v_u_109.modalCount
		local v368
		if type(v367) == "function" then
			local v369, v370 = pcall(v367)
			v368 = (not v369 or type(v370) ~= "number") and 0 or v370
		else
			v368 = 0
		end
		v358.modals = v368
		local v_u_371 = nil
		local function v372()
			-- upvalues: (ref) v_u_371, (ref) p_u_108
			v_u_371 = p_u_108.cctx.controllers.HuntClient
		end
		pcall(v372)
		local v373
		if v_u_371 == nil then
			v373 = false
		else
			local v374 = v_u_371.isOpen
			if type(v374) == "function" then
				local v375 = v_u_371.isOpen
				local v376
				v373, v376 = pcall(v375)
				if v373 then
					v373 = v376 == true
				end
			else
				v373 = false
			end
		end
		v358.hunt = v373
		local v377 = v_u_109.dropdownOpen
		local v378
		if type(v377) == "function" then
			local v379
			v378, v379 = pcall(v377)
			if v378 then
				v378 = v379 == true
			end
		else
			v378 = false
		end
		v358.dropdown = v378
		local v380 = p_u_108.blocked
		local v381
		if type(v380) == "function" then
			local v382
			v381, v382 = pcall(v380)
			if v381 then
				v381 = v382 == true
			end
		else
			v381 = false
		end
		v358.blocked = v381
		v358.textBox = v_u_1:GetFocusedTextBox() ~= nil
		v358.alive = v_u_118
		v358.visible = v_u_132.Visible
		v358.home = v_u_121.id == nil
		return v358
	end
	local function v_u_395(p384) -- name: backInput
		-- upvalues: (ref) v_u_118, (ref) v_u_357, (copy) v_u_356, (copy) v_u_383, (copy) v_u_117, (copy) v_u_109
		if v_u_118 and v_u_357 ~= nil then
			if v_u_356.decide(v_u_357, p384, (v_u_383())) then
				v_u_117.back()
				local v385 = v_u_356.frame
				local v386 = v_u_357
				local v387 = v_u_109.backTaken
				local v388
				if type(v387) == "function" then
					local v389, v390 = pcall(v387)
					v388 = (not v389 or type(v390) ~= "number") and 0 or v390
				else
					v388 = 0
				end
				local v391 = v_u_109.modalsClosed
				local v392
				if type(v391) == "function" then
					local v393, v394 = pcall(v391)
					v392 = (not v393 or type(v394) ~= "number") and 0 or v394
				else
					v392 = 0
				end
				v385(v386, v388 + v392)
			end
		end
	end
	if v_u_356 == nil then
		warn("[MenuShellV2] lib MenuBackGate is missing: Escape and pad B do not go BACK (the BACK button still does)")
		game:GetService("Players").LocalPlayer:SetAttribute("ClientError", "menu shell: lib MenuBackGate missing")
	else
		local v396 = v_u_356.new
		local v397 = v_u_109.backTaken
		local v398
		if type(v397) == "function" then
			local v399, v400 = pcall(v397)
			v398 = (not v399 or type(v400) ~= "number") and 0 or v400
		else
			v398 = 0
		end
		local v401 = v_u_109.modalsClosed
		local v402
		if type(v401) == "function" then
			local v403, v404 = pcall(v401)
			v402 = (not v403 or type(v404) ~= "number") and 0 or v404
		else
			v402 = 0
		end
		v_u_357 = v396(v398 + v402)
		local v405 = v_u_3.Heartbeat
		local function v416()
			-- upvalues: (copy) v_u_356, (ref) v_u_357, (copy) v_u_109
			local v406 = v_u_356.frame
			local v407 = v_u_357
			local v408 = v_u_109.backTaken
			local v409
			if type(v408) == "function" then
				local v410, v411 = pcall(v408)
				v409 = (not v410 or type(v411) ~= "number") and 0 or v411
			else
				v409 = 0
			end
			local v412 = v_u_109.modalsClosed
			local v413
			if type(v412) == "function" then
				local v414, v415 = pcall(v412)
				v413 = (not v414 or type(v415) ~= "number") and 0 or v415
			else
				v413 = 0
			end
			v406(v407, v409 + v413)
		end
		table.insert(v_u_119, v405:Connect(v416))
	end
	local v417 = v_u_1.InputBegan
	local function v419(p418)
		-- upvalues: (ref) v_u_357, (copy) v_u_395, (copy) v_u_356, (copy) v_u_383
		if p418.UserInputType == Enum.UserInputType.Keyboard and p418.KeyCode == Enum.KeyCode.Escape then
			if v_u_357 == nil then
				return
			end
			task.defer(v_u_395, v_u_356.key(v_u_357, (v_u_383())))
		end
	end
	table.insert(v_u_119, v417:Connect(v419))
	local v420 = p_u_108.lib("VirtualPad")
	if v420 and v420.InputBegan then
		local v421 = v420.InputBegan
		local function v423(p422)
			-- upvalues: (ref) v_u_357, (copy) v_u_395, (copy) v_u_356, (copy) v_u_383
			if p422.KeyCode == Enum.KeyCode.ButtonB then
				if v_u_357 == nil then
					return
				end
				task.defer(v_u_395, v_u_356.key(v_u_357, (v_u_383())))
			end
		end
		table.insert(v_u_119, v421:Connect(v423))
	end
	local v429 = v_u_109.onDevice(function()
		-- upvalues: (ref) v_u_138, (copy) v_u_109, (ref) v_u_355, (copy) v_u_348
		if v_u_138 then
			local v424 = v_u_138
			local v425
			if v_u_109.device() == "Touch" then
				v425 = ""
			else
				local v426 = v_u_109.hint
				local v427, v428 = pcall(v426, "back")
				v425 = (not v427 or type(v428) ~= "string") and "" or v428
			end
			v424.Text = v425
		end
		if not v_u_355 then
			v_u_355 = true
			task.delay(0.4, v_u_348)
		end
	end)
	if type(v429) == "function" then
		table.insert(v_u_120, v429)
	end
	return v_u_117
end
return v_u_4