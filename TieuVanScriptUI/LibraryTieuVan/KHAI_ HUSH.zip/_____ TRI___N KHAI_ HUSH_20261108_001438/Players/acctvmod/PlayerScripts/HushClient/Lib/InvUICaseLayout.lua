-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUICaseLayout

local v_u_72 = {
	["SB"] = 6,
	["MAX_ONE"] = 0.55,
	["MAX_ALL"] = 0.6,
	["MIN_ROWS"] = 2,
	["MIN_ROWS_MANY"] = 3,
	["columnVisible"] = function(p1, p2, p3, p4) -- name: columnVisible
		local v5 = p1 < 1300 and true or p2 < 640
		local v6 = v5 and 8 or 16
		local v7 = p2 - (p4 + v6) - v6
		if v5 then
			v5 = p3 or p2 < 560
		end
		local v8 = v7 - (v5 and 38 or 56) - 8
		return math.max(0, v8)
	end,
	["innerWidth"] = function(p9, p10) -- name: innerWidth
		-- upvalues: (copy) v_u_72
		return p9 + (not p10 and 0 or v_u_72.SB)
	end,
	["plan"] = function(p11, p12, p13, p14) -- name: plan
		-- upvalues: (copy) v_u_72
		local v15 = #p13
		local v16 = {}
		local v17 = {
			["items"] = nil,
			["used"] = 0,
			["left"] = nil,
			["fits"] = true,
			["tight"] = false,
			["items"] = {},
			["left"] = p11
		}
		if v15 == 0 or p12 <= 0 then
			return v17
		end
		local v18 = p14.chrome
		local v19 = p14.head
		local v20 = p14.focus or v15
		local v21 = math.clamp(v20, 1, v15)
		local v22
		if v15 == 1 then
			v22 = v_u_72.MAX_ONE
		else
			v22 = v_u_72.MAX_ALL
		end
		local v23 = p11 * v22
		local v24 = math.floor(v23)
		local v25
		if v15 > 1 then
			v25 = v_u_72.MIN_ROWS_MANY
		else
			v25 = v_u_72.MIN_ROWS
		end
		local v26 = 0
		local v_u_27 = {}
		local v_u_28 = {}
		for v29 = 1, v15 do
			local v30 = p13[v29]
			local v31 = math.floor(v30)
			local v32 = math.max(1, v31)
			v16[v29] = v32
			v_u_27[v29] = v18 + v32 * p12
			v_u_28[v29] = v18 + math.min(v32, v25) * p12
			v26 = v26 + v_u_28[v29]
		end
		local v33 = {}
		local v34
		if v26 <= v24 then
			local v35 = v24 - v26
			local v36 = {}
			for v37 = 1, v15 do
				v36[v37] = v37
			end
			table.sort(v36, function(p38, p39)
				-- upvalues: (copy) v_u_27, (copy) v_u_28
				local v40 = v_u_27[p38] - v_u_28[p38]
				local v41 = v_u_27[p39] - v_u_28[p39]
				if v40 == v41 then
					return p38 < p39
				else
					return v40 < v41
				end
			end)
			v34 = v15
			for _, v42 in v36 do
				local v43 = v_u_27[v42] - v_u_28[v42]
				local v44 = v35 / v15
				local v45 = math.floor(v44)
				local v46 = math.min(v43, v45)
				v35 = v35 - v46
				v15 = v15 - 1
				local v47 = v_u_28[v42] + v46
				local v48 = v16[v42]
				local v49 = v_u_72.MIN_ROWS
				local v50 = (v47 - v18) / p12
				local v51 = math.floor(v50)
				local v52 = math.min(v48, v49)
				local v53 = math.max(v51, v52)
				local v54 = math.min(v53, v48)
				v33[v42] = {
					["shown"] = nil,
					["scroll"] = nil,
					["collapsed"] = false,
					["h"] = nil,
					["shown"] = v54,
					["scroll"] = v54 < v16[v42],
					["h"] = v18 + v54 * p12
				}
			end
		elseif v15 == 1 then
			local v55 = v16[1]
			local v56 = v_u_72.MIN_ROWS
			local v57 = math.min(v55, v56)
			v33[1] = {
				["shown"] = nil,
				["scroll"] = nil,
				["collapsed"] = false,
				["h"] = nil,
				["shown"] = v57,
				["scroll"] = v57 < v16[1],
				["h"] = v18 + v57 * p12
			}
			v17.tight = p11 < v18 + v57 * p12
			v34 = v15
		else
			v34 = v15
			for v58 = 1, v15 do
				if v58 == v21 then
					local v59 = v_u_27[v58]
					local v60 = v24 - (v34 - 1) * v19
					local v61 = (math.min(v59, v60) - v18) / p12
					local v62 = math.floor(v61)
					local v63 = math.max(v62, 1)
					local v64 = v16[v58]
					local v65 = math.min(v63, v64)
					local v66 = v16[v58]
					local v67 = v_u_72.MIN_ROWS
					if v65 < math.min(v66, v67) and (v34 - 1) * v19 + v18 + p12 * 4 <= p11 then
						local v68 = v16[v58]
						local v69 = v_u_72.MIN_ROWS
						v65 = math.min(v68, v69)
					end
					v33[v58] = {
						["shown"] = nil,
						["scroll"] = nil,
						["collapsed"] = false,
						["h"] = nil,
						["shown"] = v65,
						["scroll"] = v65 < v16[v58],
						["h"] = v18 + v65 * p12
					}
					v15 = v34
				else
					v33[v58] = {
						["shown"] = 0,
						["scroll"] = false,
						["collapsed"] = true,
						["h"] = nil,
						["h"] = v19
					}
					v15 = v34
				end
				v34 = v15
			end
		end
		local v70 = 0
		for v71 = 1, v34 do
			v70 = v70 + v33[v71].h
		end
		v17.items = v33
		v17.used = v70
		v17.left = p11 - v70
		v17.fits = v70 <= p11
		if not v17.fits then
			v17.tight = true
		end
		return v17
	end
}
return v_u_72