-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MapTaskList

local v_u_1 = game:GetService("HttpService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = {}
local v_u_5 = nil
local function v_u_9(p6, p7) -- name: contains
	local v8 = string.gsub(" " .. string.lower((string.gsub(tostring(p7), "[^%w]+", " "))) .. " ", " $", "")
	if v8 == " " or v8 == "" then
		return false
	else
		return string.find(" " .. string.lower((string.gsub(tostring(p6), "[^%w]+", " "))) .. " ", v8, 1, true) ~= nil
	end
end
function v_u_4.decode(p10) -- name: decode
	-- upvalues: (copy) v_u_1
	if type(p10) ~= "string" or p10 == "" then
		return {}
	end
	local v11 = v_u_1.JSONDecode
	local v12 = v_u_1
	local v13, v14 = pcall(v11, v12, p10)
	return (not v13 or type(v14) ~= "table") and {} or v14
end
function v_u_4.progressText(p15, p16) -- name: progressText
	return ("%d / %d"):format(p15, p16)
end
function v_u_4.objective(p17, p18, p19, p20) -- name: objective
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (ref) v_u_5, (copy) v_u_3
	local v21
	if p20 then
		v21 = p20.defs
	else
		v21 = p20
	end
	local v22 = p17.count
	local v23 = tonumber(v22) or 1
	local v24 = math.max(1, v23)
	local v25 = p18 ~= nil
	local v26 = math.clamp(p18 or 0, 0, v24)
	local v27 = p17.desc or (p17.event or "")
	local v28 = tostring(v27)
	local v29 = nil
	local v30 = p17.filter
	if type(v30) == "table" then
		local v31 = p17.filter.id
		if type(v31) == "string" then
			v29 = p17.filter.id
		end
	end
	local v32
	if p17.fir == true then
		v32 = not v_u_9(v28, "found in raid")
	else
		v32 = false
	end
	local v33 = nil
	if (p17.event == "handover" or p17.event == "found") and (v29 and p20) then
		local v34 = p20.itemName
		if type(v34) == "function" then
			local v35 = p20.itemName(v29)
			if type(v35) == "string" and v35 ~= "" then
				v33 = "ITEM: " .. v35 .. (v32 and " (found in raid)" or "")
			end
		end
	end
	if not v33 then
		local v36 = p17.bring
		if type(v36) == "string" and p20 then
			local v37 = p20.itemName
			if type(v37) == "function" then
				local v38 = p20.itemName(p17.bring)
				if type(v38) == "string" and v38 ~= "" then
					v33 = "ITEM: " .. v38
				end
			end
		end
	end
	if v32 and not v33 then
		v28 = v28 .. "  [found in raid]"
	end
	local v39 = nil
	if v21 then
		local v40 = v21.objectiveMap
		if type(v40) == "function" then
			v39 = v21.objectiveMap(p17)
		end
	end
	local v41
	if v39 == nil or p20 == nil then
		v41 = false
	else
		local v42 = p20.mapId
		if type(v42) == "string" then
			v41 = v39 ~= p20.mapId
		else
			v41 = false
		end
	end
	local v43
	if v41 and v39 then
		if v21 then
			v21 = v21.MAP_TAGS
		end
		if type(v21) == "table" and v21[v39] then
			v43 = v21[v39]
		else
			v43 = string.upper(v39)
		end
		local v44 = p17.room
		local v45
		if type(v44) == "string" and p20 then
			local v46 = p20.roomName
			if type(v46) == "function" then
				local v47 = p20.roomName(v39, p17.room)
				if type(v47) == "string" and v47 ~= "" then
					v43 = v43 .. "  \194\183  " .. string.upper(v47)
				end
			else
				v45 = p17.room
				v43 = v43 .. (type(v45) ~= "string" and "" or "  \194\183  " .. string.upper(p17.room))
			end
		else
			v45 = p17.room
			v43 = v43 .. (type(v45) ~= "string" and "" or "  \194\183  " .. string.upper(p17.room))
		end
	else
		v43 = nil
	end
	local v48 = nil
	local v49 = p17.where
	if type(v49) == "string" then
		v48 = p17.where
	else
		local v50 = p17.room
		if type(v50) == "string" then
			v48 = string.upper(p17.room)
		end
	end
	local v51 = nil
	if v48 and p20 then
		local v52 = p20.placeName
		if type(v52) == "function" then
			v51 = p20.placeName(v48)
		end
	end
	local v53
	if v25 then
		v53 = v24 <= v26
	else
		v53 = v25
	end
	local v54 = {
		["text"] = v28,
		["need"] = v24
	}
	local v55
	if v25 then
		v55 = v26
	else
		v55 = nil
	end
	v54.have = v55
	v54.done = v53
	local v56
	if v25 then
		local v57 = v24 - v26
		v56 = math.clamp(p19 or 0, 0, v57)
	else
		v56 = 0
	end
	v54.pend = v56
	local v58
	if v25 then
		v58 = v_u_4.progressText(v26, v24)
	else
		v58 = nil
	end
	v54.right = v58
	local v59 = p17.hint
	local v60
	if type(v59) == "string" and not v53 then
		v60 = p17.hint
	else
		v60 = nil
	end
	v54.hint = v60
	local v61 = p17.tip
	local v62
	if type(v61) == "string" and (p17.tip ~= "" and not v53) then
		v62 = p17.tip
	else
		v62 = nil
	end
	v54.tip = v62
	local v63
	if v53 then
		v63 = nil
	else
		v63 = v33
	end
	v54.item = v63
	v54.place = v51
	v54.tag = v43
	v54.other = v41
	v54.event = p17.event
	local v64
	if v53 or (v41 or p20 and p20.conds == false) then
		v64 = nil
	else
		if not v_u_5 then
			local function v66()
				-- upvalues: (ref) v_u_3, (ref) v_u_5
				local v65 = v_u_3:FindFirstChild("Hush")
				if v65 then
					v65 = v65:FindFirstChild("Shared")
				end
				if v65 then
					v65 = v65:FindFirstChild("TaskConds")
				end
				if v65 then
					v_u_5 = require(v65)
				end
			end
			pcall(v66)
		end
		v64 = v_u_5
		if not (v64 and v64.enabled()) then
			v64 = nil
		end
	end
	if v64 then
		local v67 = v64.parts(p17, {
			["firChip"] = v33 == nil
		})
		if v64.marked(v67) then
			v54.parts = v67
		end
		if v54.hint then
			local v68 = v64.textParts(p17, v54.hint, "hint")
			if v64.marked(v68) then
				v54.hintParts = v68
			end
		end
		if v54.tip then
			local v69 = v64.textParts(p17, v54.tip, "tip")
			if v64.marked(v69) then
				v54.tipParts = v69
			end
		end
		if v54.item then
			local v70 = v64.textParts(p17, v54.item, "item")
			if v64.marked(v70) then
				v54.itemParts = v70
			end
		end
	end
	return v54
end
function v_u_4.headPlace(p71, p72) -- name: headPlace
	local v73 = p72 or 24
	local v74 = #p71
	if v74 == 0 then
		return "Anywhere"
	end
	local v75 = table.concat(p71, ", ")
	if v74 == 1 or #v75 <= v73 then
		return v75
	end
	local v76 = nil
	local v77 = {}
	local v78 = {}
	for _, v79 in p71 do
		local v80, v81 = string.match(v79, "^(%a%a%a+) (.*%d.*)$")
		if not v80 or v76 ~= nil and v80 ~= v76 then
			v76 = nil
			break
		end
		table.insert(v77, v81)
		v76 = v80
	end
	if v76 and #v77 == v74 then
		local v82 = v76 .. (string.lower((string.sub(v76, -1))) == "s" and "" or "s")
		if v74 > 2 then
			local v83 = v77[1]
			local v84 = v77[2]
			local v85 = v74 - 2
			table.insert(v78, ("%s %s, %s +%d"):format(v82, v83, v84, v85))
		end
		local v86 = v77[1]
		local v87 = v74 - 1
		table.insert(v78, ("%s %s +%d"):format(v82, v86, v87))
	end
	if v74 == 2 then
		local v88 = p71[1] .. ", " .. p71[2]
		table.insert(v78, v88)
	else
		local v89 = p71[1]
		local v90 = p71[2]
		local v91 = v74 - 2
		table.insert(v78, ("%s, %s +%d"):format(v89, v90, v91))
	end
	local v92 = p71[1]
	local v93 = v74 - 1
	table.insert(v78, ("%s +%d"):format(v92, v93))
	for _, v94 in v78 do
		if #v94 > v73 then
			continue
		end
		return v94
	end
	return v78[#v78]
end
function v_u_4.diff(p95, p96) -- name: diff
	local v97 = type(p95) ~= "table" and {} or p95
	local v98 = type(p96) ~= "table" and {} or p96
	local v99 = #v97 == #v98
	local v100 = {}
	local v101 = {}
	for v102, v103 in v97 do
		if type(v103) == "table" then
			local v104 = v103.id
			v100[tostring(v104)] = v103
		end
		local v105 = v98[v102]
		if not v99 or type(v103) == "table" and (type(v105) == "table" and v103.id == v105.id) then
			continue
		end
		v99 = false
	end
	for _, v106 in v98 do
		if type(v106) ~= "table" then
			continue
		end
		local v107 = v106.id
		local v108 = v100[tostring(v107)]
		if not v108 or v108.sig == v106.sig then
			continue
		end
		local v109 = v106.id
		local v110 = tostring(v109)
		table.insert(v101, v110)
	end
	return {
		["same"] = v99,
		["changed"] = v101
	}
end
function v_u_4.build(p111) -- name: build
	-- upvalues: (copy) v_u_4
	local v_u_112 = p111.defs
	local v113 = {}
	for _, v114 in p111.detail or {} do
		if type(v114) ~= "table" then
			continue
		end
		local v115 = v114.id
		if type(v115) ~= "string" then
			continue
		end
		v113[v114.id] = v114
	end
	local v_u_116 = {}
	local v117 = {}
	if v_u_112 then
		local v118 = v_u_112.list
		if type(v118) == "table" then
			for v119, v120 in v_u_112.list do
				v_u_116[v120.id] = v119
				local v121 = v120.title
				local v122
				if v117[v120.title] == nil then
					v122 = v120.id
				else
					v122 = false
				end
				v117[v121] = v122
			end
		end
	end
	local v_u_123 = {}
	local v_u_124 = {}
	local function v133(p125, p126) -- name: entryFor
		-- upvalues: (copy) v_u_124, (copy) v_u_112, (copy) v_u_123
		local v127 = v_u_124[p125]
		if v127 then
			return v127
		end
		local v128
		if v_u_112 then
			local v129 = v_u_112.get
			if type(v129) == "function" then
				v128 = v_u_112.get(p125)
			else
				v128 = nil
			end
		else
			v128 = nil
		end
		local v130 = {
			["id"] = nil,
			["title"] = nil,
			["def"] = nil,
			["wheres"] = nil,
			["kind"] = "any",
			["id"] = p125
		}
		local v131
		if v128 then
			v131 = v128.title
		else
			v131 = p126 or p125
		end
		v130.title = v131
		v130.def = v128
		v130.wheres = {}
		v_u_124[p125] = v130
		local v132 = v_u_123
		table.insert(v132, v130)
		return v130
	end
	for _, v134 in p111.places or {} do
		if type(v134) ~= "table" then
			continue
		end
		local v135 = v134.where
		if type(v135) ~= "string" then
			continue
		end
		local v136 = v134.id
		if type(v136) ~= "string" then
			local v137 = v134.title
			v136 = v117[tostring(v137)]
			if type(v136) ~= "string" then
				local v138 = v134.title
				v136 = "title:" .. tostring(v138)
			end
		end
		local v139 = v134.title
		local v140 = v133(v136, (tostring(v139)))
		if table.find(v140.wheres, v134.where) then
			continue
		end
		local v141 = v140.wheres
		local v142 = v134.where
		table.insert(v141, v142)
	end
	if p111.anywhere ~= false and v_u_112 then
		local v143 = v_u_112.get
		if type(v143) == "function" then
			local v144 = {}
			for v145 in v113 do
				table.insert(v144, v145)
			end
			table.sort(v144)
			for _, v146 in v144 do
				if v_u_124[v146] then
					continue
				end
				local v147 = v_u_112.get(v146)
				local v148 = v113[v146]
				if not v147 then
					continue
				end
				local v149 = v147.objectives
				if type(v149) ~= "table" then
					continue
				end
				local v150 = v148.h
				if type(v150) ~= "table" then
					continue
				end
				local v151 = false
				for v152, v153 in v147.objectives do
					local v154 = v153.count
					local v155 = tonumber(v154) or 1
					local v156 = math.max(1, v155)
					local v157 = v_u_112.objectiveMap
					local v158
					if type(v157) == "function" then
						v158 = v_u_112.objectiveMap(v153)
					else
						v158 = nil
					end
					local v159 = v148.h[v152]
					if (tonumber(v159) or 0) >= v156 or v158 ~= nil and (p111.mapId ~= nil and v158 ~= p111.mapId) then
						continue
					end
					v151 = true
				end
				if not v151 then
					break
				end
				v133(v146, nil)
			end
		end
	end
	local v160 = {
		["defs"] = v_u_112,
		["mapId"] = p111.mapId,
		["itemName"] = p111.itemName,
		["placeName"] = p111.placeName
	}
	for _, v161 in v_u_123 do
		local v162 = {}
		local v163 = {}
		for _, v164 in v161.wheres do
			local v165 = p111.placeName
			local v166
			if type(v165) == "function" then
				v166 = p111.placeName(v164)
			else
				v166 = nil
			end
			if type(v166) ~= "string" or v166 == "" then
				continue
			end
			table.insert(v162, v164)
			if table.find(v163, v166) then
				continue
			end
			table.insert(v163, v166)
		end
		table.sort(v163)
		v161.wheres = v162
		v161.kind = #v163 > 0 and "place" or "any"
		v161.placeText = #v163 <= 0 and "Anywhere" or table.concat(v163, ", ")
		v161.headText = v_u_4.headPlace(v163)
		local v167 = v113[v161.id]
		v161.lines = {}
		v161.open = 0
		local v168, v169, v170, v171, v172
		if v161.def then
			local v173 = v161.def.objectives
			if type(v173) == "table" then
				for v174, v175 in v161.def.objectives do
					local v176 = v_u_4.objective
					local v177
					if v167 then
						local v178 = v167.h
						if type(v178) == "table" then
							local v179 = v167.h[v174]
							v177 = tonumber(v179)
						else
							v177 = nil
						end
					else
						v177 = nil
					end
					local v180
					if v167 then
						local v181 = v167.p
						if type(v181) == "table" then
							local v182 = v167.p[v174]
							v180 = tonumber(v182)
						else
							v180 = nil
						end
					else
						v180 = nil
					end
					local v183 = v176(v175, v177, v180, v160)
					local v184 = v161.lines
					table.insert(v184, v183)
					if v183.done or v183.other then
						continue
					end
					v161.open = v161.open + 1
				end
				if #v163 <= 1 then
					for _, v185 in v161.lines do
						v185.place = nil
					end
				end
				local v186 = p111.giverName
				local v187
				if type(v186) == "function" then
					v187 = p111.giverName(v161.def.giver)
				else
					v187 = nil
				end
				if type(v187) ~= "string" then
					local v188 = string.upper
					local v189 = v161.def.giver
					v187 = v188((tostring(v189)))
				end
				v161.giver = v187
				v161.side = v161.def.side == true
				v161.squad = v161.def.squad == true
				if v167 then
					v168 = v167.h
					if type(v168) == "table" then
						v169 = table.concat(v167.h, ",")
						v170 = table.concat
						v171 = v167.p
						v172 = v169 .. "/" .. v170(type(v171) == "table" and (v167.p or {}) or {}, ",")
					else
						v172 = ""
					end
				else
					v172 = ""
				end
				v161.sig = v172
			else
				v161.giver = ""
				v161.side = false
				v161.squad = false
				if v167 then
					v168 = v167.h
					if type(v168) == "table" then
						v169 = table.concat(v167.h, ",")
						v170 = table.concat
						v171 = v167.p
						v172 = v169 .. "/" .. v170(type(v171) == "table" and (v167.p or {}) or {}, ",")
					else
						v172 = ""
					end
				else
					v172 = ""
				end
				v161.sig = v172
			end
		else
			v161.giver = ""
			v161.side = false
			v161.squad = false
			if v167 then
				v168 = v167.h
				if type(v168) == "table" then
					v169 = table.concat(v167.h, ",")
					v170 = table.concat
					v171 = v167.p
					v172 = v169 .. "/" .. v170(type(v171) == "table" and (v167.p or {}) or {}, ",")
				else
					v172 = ""
				end
			else
				v172 = ""
			end
			v161.sig = v172
		end
	end
	table.sort(v_u_123, function(p190, p191)
		-- upvalues: (copy) v_u_116
		if p190.kind == p191.kind then
			if p190.kind == "place" and p190.placeText ~= p191.placeText then
				return p190.placeText < p191.placeText
			else
				local v192 = v_u_116[p190.id] or 1000000000
				local v193 = v_u_116[p191.id] or 1000000000
				if v192 == v193 then
					return p190.id < p191.id
				else
					return v192 < v193
				end
			end
		else
			return p190.kind == "place"
		end
	end)
	local v194 = 0
	for _, v195 in v_u_123 do
		if v195.kind == "place" then
			v194 = v194 + 1
			v195.num = v194
		else
			v195.num = nil
		end
	end
	return v_u_123
end
function v_u_4.structKey(p196, p197) -- name: structKey
	-- upvalues: (copy) v_u_4
	local v198 = {}
	for _, v199 in v_u_4.decode(p196) do
		if type(v199) ~= "table" then
			continue
		end
		local v200 = v199.id or v199.title
		local v201 = tostring(v200)
		local v202 = v199.where
		local v203 = v201 .. "@" .. tostring(v202)
		table.insert(v198, v203)
	end
	table.sort(v198)
	local v204 = {}
	for _, v205 in v_u_4.decode(p197) do
		if type(v205) ~= "table" then
			continue
		end
		local v206 = v205.id
		local v207 = tostring(v206)
		table.insert(v204, v207)
	end
	table.sort(v204)
	return table.concat(v198, ";") .. "|" .. table.concat(v204, ";")
end
local v_u_208 = 0
function v_u_4.stamp() -- name: stamp
	-- upvalues: (ref) v_u_208
	return v_u_208
end
function v_u_4.touch() -- name: touch
	-- upvalues: (ref) v_u_208
	v_u_208 = v_u_208 + 1
end
function v_u_4.structSig(p209, p210) -- name: structSig
	-- upvalues: (copy) v_u_4, (ref) v_u_208
	return v_u_4.structKey(p209, p210) .. (v_u_208 <= 0 and "" or "~" .. v_u_208)
end
local v_u_211 = {
	["openId"] = nil,
	["rows"] = nil,
	["entries"] = nil,
	["list"] = nil,
	["conn"] = nil,
	["env"] = nil,
	["pending"] = false,
	["rows"] = {},
	["entries"] = {}
}
function v_u_4.reset() -- name: reset
	-- upvalues: (copy) v_u_211
	local v212 = v_u_211.conn
	v_u_211.conn = nil
	if v212 then
		v212:Disconnect()
	end
	v_u_211.openId = nil
	v_u_211.rows = {}
	v_u_211.entries = {}
	v_u_211.list = nil
	v_u_211.env = nil
end
function v_u_4.openId() -- name: openId
	-- upvalues: (copy) v_u_211
	return v_u_211.openId
end
function v_u_4.state() -- name: state
	-- upvalues: (copy) v_u_211
	local v213 = {}
	for _, v214 in v_u_211.entries do
		local v215 = v214.id
		table.insert(v213, v215)
	end
	local v216 = 0
	for _ in v_u_211.rows do
		v216 = v216 + 1
	end
	return {
		["open"] = v_u_211.openId,
		["rows"] = v216,
		["ids"] = v213
	}
end
local v_u_217 = nil
local function v_u_224(p218, p219) -- name: applyState
	-- upvalues: (copy) v_u_211, (ref) v_u_217
	local v220 = v_u_211.rows[p218]
	if v220 and v220.row.Parent then
		local v221 = v_u_211.env.Theme.color
		if p219 and not v220.filled then
			v_u_217(v220, v220.entry)
		end
		v220.body.Visible = p219
		v220.down.Visible = not p219
		v220.up.Visible = p219
		local v222 = v220.head
		local v223
		if p219 then
			v223 = v221.raised2
		else
			v223 = v221.raised
		end
		v222.BackgroundColor3 = v223
		v220.row:SetAttribute("Open", p219)
	end
end
local function v_u_232(p225) -- name: setOpen
	-- upvalues: (copy) v_u_211, (copy) v_u_224
	local v226 = v_u_211.openId
	if v226 and v226 ~= p225 then
		local v227 = v_u_211.rows[v226]
		if v227 and v227.row.Parent then
			local v228 = v_u_211.env.Theme.color
			v227.body.Visible = false
			v227.down.Visible = true
			v227.up.Visible = false
			v227.head.BackgroundColor3 = v228.raised
			v227.row:SetAttribute("Open", false)
		end
	end
	v_u_211.openId = p225
	if p225 then
		v_u_224(p225, true)
	end
	local v229 = v_u_211.env
	if v229 then
		local v230 = v229.onChange
		if type(v230) == "function" and v226 ~= p225 then
			local v231 = v229.onChange
			pcall(v231, p225)
		end
	end
end
v_u_217 = function(p233, p234)
	-- upvalues: (copy) v_u_211, (ref) v_u_5, (copy) v_u_3
	local v_u_235 = v_u_211.env.UI
	local v_u_236 = v_u_211.env.Theme
	local v237 = v_u_236.color
	local v238 = v_u_236.isPhone()
	for _, v239 in p233.body:GetChildren() do
		if not v239:IsA("GuiObject") then
			continue
		end
		v239:Destroy()
	end
	local v240 = p234.giver .. (p234.side and "  \194\183  Side job" or "") .. (p234.squad and "  \194\183  Squad" or "")
	if v240 ~= "" then
		v_u_235.label({
			["parent"] = nil,
			["name"] = "Meta",
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = 13,
			["color"] = nil,
			["size"] = nil,
			["order"] = 0,
			["track"] = false,
			["parent"] = p233.body,
			["text"] = v240,
			["color"] = v237.text2,
			["size"] = UDim2.new(1, 0, 0, 17)
		})
	end
	if #p234.lines == 0 then
		v_u_235.label({
			["parent"] = nil,
			["name"] = "Empty",
			["text"] = "The TASKS tab in the menu has the details.",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["track"] = false,
			["parent"] = p233.body,
			["color"] = v237.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
	end
	local v241 = v238 and 56 or 60
	if not v_u_5 then
		local function v243()
			-- upvalues: (ref) v_u_3, (ref) v_u_5
			local v242 = v_u_3:FindFirstChild("Hush")
			if v242 then
				v242 = v242:FindFirstChild("Shared")
			end
			if v242 then
				v242 = v242:FindFirstChild("TaskConds")
			end
			if v242 then
				v_u_5 = require(v242)
			end
		end
		pcall(v243)
	end
	local v_u_244 = v_u_5
	if not (v_u_244 and v_u_244.enabled()) then
		v_u_244 = nil
	end
	for v245, v246 in p234.lines do
		local v_u_247 = v_u_235.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Name"] = "Obj" .. v245,
			["LayoutOrder"] = v245,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p233.body)
		v_u_235.layout(v_u_247, "v", 3)
		local v248 = v_u_235.new("Frame", {
			["Name"] = "Top",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_247)
		local v249 = not v246.right and 0 or v241 + 6
		local v250 = v246.parts
		local v251
		if v_u_244 and v250 then
			v251 = v_u_244.richFor(v250, v_u_236)
		else
			v251 = nil
		end
		local v252 = v_u_235.label
		local v253 = {
			["parent"] = nil,
			["name"] = "Desc",
			["text"] = nil,
			["rich"] = nil,
			["style"] = "body",
			["textSize"] = 14,
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v248,
			["text"] = v251 or v246.text,
			["rich"] = v251 ~= nil
		}
		local v254
		if v246.done or v246.other then
			v254 = v237.muted
		else
			v254 = v237.text
		end
		v253.color = v254
		v253.size = UDim2.new(1, -v249, 0, 0)
		v252(v253)
		if v246.right then
			local v255 = v_u_235.label
			local v256 = {
				["parent"] = nil,
				["name"] = "Progress",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 13,
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v248,
				["text"] = v246.done and "Done" or v246.right
			}
			local v257
			if v246.done then
				v257 = v237.success
			else
				v257 = v237.accent
			end
			v256.color = v257
			v256.anchor = Vector2.new(1, 0)
			v256.position = UDim2.new(1, 0, 0, 1)
			v256.size = UDim2.fromOffset(v241, 18)
			v255(v256)
		end
		local v_u_258 = 2
		if v246.have and v246.need > 1 then
			local v259 = v_u_235.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v237.line,
				["LayoutOrder"] = v_u_258,
				["Size"] = UDim2.new(1, 0, 0, 4)
			}, v_u_247)
			local v260 = v_u_235.new
			local v261 = "Frame"
			local v262 = {
				["Name"] = "Fill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil
			}
			local v263
			if v246.done then
				v263 = v237.success
			else
				v263 = v237.accent
			end
			v262.BackgroundColor3 = v263
			local v264 = UDim2.fromScale
			local v265 = v246.have / v246.need
			v262.Size = v264(math.clamp(v265, 0, 1), 1)
			v260(v261, v262, v259)
			v_u_258 = v_u_258 + 1
		end
		local function v271(p266, p267, p268, p269) -- name: extra
			-- upvalues: (copy) v_u_244, (copy) v_u_236, (copy) v_u_235, (copy) v_u_247, (ref) v_u_258
			local v270
			if v_u_244 and p269 then
				v270 = v_u_244.richFor(p269, v_u_236)
			else
				v270 = nil
			end
			v_u_235.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["rich"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["track"] = false,
				["parent"] = v_u_247,
				["name"] = p266,
				["text"] = v270 or p267,
				["rich"] = v270 ~= nil,
				["color"] = p268,
				["size"] = UDim2.new(1, 0, 0, 0),
				["order"] = v_u_258
			})
			v_u_258 = v_u_258 + 1
		end
		if v246.pend and v246.pend > 0 then
			v271("Pending", ("%d found, extract to count it"):format(v246.pend), v237.success)
		end
		if v246.item then
			v271("Item", v246.item, v237.accent, v246.itemParts)
		end
		if v246.hint then
			v271("Hint", v246.hint, v237.text2, v246.hintParts)
		end
		if v246.tip then
			v271("Tip", v246.tip, v237.text2, v246.tipParts)
		end
		if v246.place and not v246.done then
			v271("Place", "At " .. v246.place, v237.accent)
		end
		if not v246.tag then
			continue
		end
		local v272 = "Tag"
		local v273 = "Counts on " .. v246.tag
		local v274
		if v_u_244 and v_u_236.cond then
			v274 = v_u_236.cond.map
		else
			v274 = v237.info
		end
		v271(v272, v273, v274)
	end
	p233.sig = p234.sig
	p233.filled = true
end
local function v_u_314(p_u_275, p276) -- name: makeRow
	-- upvalues: (copy) v_u_211, (copy) v_u_232, (copy) v_u_224
	local v_u_277 = v_u_211.env
	local v_u_278 = v_u_277.UI
	local v279 = v_u_277.Theme
	local v_u_280 = v279.color
	local v281 = v279.isPhone()
	local v282 = v_u_278.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Name"] = "TaskRow_" .. p_u_275.id,
		["LayoutOrder"] = p276,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_211.list)
	v_u_278.new("UIListLayout", {
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 0)
	}, v282)
	v282:SetAttribute("TaskId", p_u_275.id)
	local v283 = v279.touch(v281 and 46 or 48)
	local v_u_284 = v_u_278.new("TextButton", {
		["Name"] = "Head",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["LayoutOrder"] = 1,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_280.raised,
		["Size"] = UDim2.new(1, 0, 0, v283)
	}, v282)
	v_u_278.stroke(v_u_284, v_u_280.line)
	v_u_278.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_280.accent,
		["Size"] = UDim2.new(0, 2, 1, 0)
	}, v_u_284)
	local v285 = (v283 - 40) / 2
	local v286 = math.floor(v285)
	local v287
	if p_u_275.num then
		local v288 = v_u_278.new("Frame", {
			["Name"] = "Num",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_280.accent,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Size"] = UDim2.fromOffset(24, 24)
		}, v_u_284)
		v_u_278.new("UICorner", {
			["CornerRadius"] = UDim.new(0, 5)
		}, v288)
		local v289 = v_u_278.label
		local v290 = {
			["parent"] = nil,
			["name"] = "N",
			["text"] = nil,
			["style"] = "bodyStrong",
			["textSize"] = 14,
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["track"] = false,
			["parent"] = v288
		}
		local v291 = p_u_275.num
		v290.text = tostring(v291)
		v290.color = Color3.fromHex("1B1712")
		v290.size = UDim2.fromScale(1, 1)
		v289(v290)
		v287 = 42
	else
		v287 = 12
	end
	v_u_278.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "bodyStrong",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_284,
		["text"] = p_u_275.title,
		["position"] = UDim2.fromOffset(v287, v286),
		["size"] = UDim2.new(1, -(v287 + 34), 0, 20)
	})
	local v292 = v_u_278.label
	local v293 = {
		["parent"] = nil,
		["name"] = "Where",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_284,
		["text"] = p_u_275.headText or p_u_275.placeText
	}
	local v294
	if p_u_275.kind == "place" then
		v294 = v_u_280.accent
	else
		v294 = v_u_280.text2
	end
	v293.color = v294
	v293.position = UDim2.fromOffset(v287, v286 + 20)
	v293.size = UDim2.new(1, -(v287 + 34), 0, 18)
	v292(v293)
	local v295 = v_u_278.icon("chevronDown", {
		["size"] = 16,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["color"] = v_u_280.text2,
		["position"] = UDim2.new(1, -22, 0.5, 0),
		["anchor"] = Vector2.new(0.5, 0.5)
	})
	v295.Parent = v_u_284
	local v296 = v_u_278.icon("chevronUp", {
		["size"] = 16,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["color"] = v_u_280.accent,
		["position"] = UDim2.new(1, -22, 0.5, 0),
		["anchor"] = Vector2.new(0.5, 0.5)
	})
	v296.Visible = false
	v296.Parent = v_u_284
	local v297 = v_u_278.new("Frame", {
		["Name"] = "Body",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.5,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 2,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_280.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v282)
	v_u_278.stroke(v297, v_u_280.line)
	v_u_278.pad(v297, {
		12,
		10,
		8,
		10
	})
	v_u_278.layout(v297, "v", 8)
	v_u_211.rows[p_u_275.id] = {
		["row"] = nil,
		["head"] = nil,
		["body"] = nil,
		["down"] = nil,
		["up"] = nil,
		["headH"] = nil,
		["sig"] = "",
		["filled"] = false,
		["entry"] = nil,
		["row"] = v282,
		["head"] = v_u_284,
		["body"] = v297,
		["down"] = v295,
		["up"] = v296,
		["headH"] = v283,
		["entry"] = p_u_275
	}
	v_u_284.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_211, (copy) p_u_275, (copy) v_u_284, (copy) v_u_280
		if v_u_211.openId ~= p_u_275.id then
			v_u_284.BackgroundColor3 = v_u_280.raised2
		end
	end)
	v_u_284.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_211, (copy) p_u_275, (copy) v_u_284, (copy) v_u_280
		if v_u_211.openId ~= p_u_275.id then
			v_u_284.BackgroundColor3 = v_u_280.raised
		end
	end)
	v_u_284.SelectionImageObject = v_u_278.selectionImage()
	v_u_284.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_211, (copy) p_u_275, (copy) v_u_284, (copy) v_u_280
		if v_u_211.openId ~= p_u_275.id then
			v_u_284.BackgroundColor3 = v_u_280.raised2
		end
	end)
	v_u_284.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_211, (copy) p_u_275, (copy) v_u_284, (copy) v_u_280
		if v_u_211.openId ~= p_u_275.id then
			v_u_284.BackgroundColor3 = v_u_280.raised
		end
	end)
	v_u_284.Activated:Connect(function()
		-- upvalues: (copy) v_u_278, (ref) v_u_211, (copy) p_u_275, (ref) v_u_232, (copy) v_u_277
		v_u_278.sound("click")
		local v298 = v_u_211.openId ~= p_u_275.id
		local v299 = v_u_232
		local v300
		if v298 then
			v300 = p_u_275.id
		else
			v300 = nil
		end
		v299(v300)
		if v298 then
			local v_u_301 = p_u_275.id
			local function v_u_310() -- name: pass
				-- upvalues: (ref) v_u_211, (copy) v_u_301
				local v302 = v_u_211.rows[v_u_301]
				local v303 = v_u_211.list
				if v_u_211.openId == v_u_301 and (v302 and (v303 and (v302.row.Parent and v303.Parent))) then
					if v302.head.AbsoluteSize.Y > 0.01 then
						local v304 = v303.CanvasPosition.Y
						local v305 = v302.row.AbsolutePosition.Y - v303.AbsolutePosition.Y + v304
						local v306 = v302.row.AbsoluteSize.Y
						local v307 = v303.AbsoluteSize.Y
						if v305 >= v304 then
							if v305 + v306 > v304 + v307 then
								local v308 = v305 + v306 - v307
								v305 = math.min(v305, v308)
							else
								v305 = v304
							end
						end
						local v309 = v305 - v304
						if math.abs(v309) > 0.5 then
							v303.CanvasPosition = Vector2.new(0, (math.max(0, v305)))
						end
					end
				else
					return
				end
			end
			task.defer(function()
				-- upvalues: (copy) v_u_310
				task.wait()
				v_u_310()
				task.wait(0.15)
				v_u_310()
				task.wait(0.5)
				v_u_310()
			end)
			local v311 = v_u_277.onOpen
			if type(v311) == "function" then
				local v312 = v_u_277.onOpen
				local v313 = p_u_275
				pcall(v312, v313)
			end
		end
	end)
	if v_u_211.openId == p_u_275.id then
		v_u_224(p_u_275.id, true)
	end
end
local function v_u_338() -- name: refresh
	-- upvalues: (copy) v_u_211, (copy) v_u_2, (copy) v_u_4, (ref) v_u_217
	v_u_211.pending = false
	local v315 = v_u_211.env
	local v316 = v_u_211.list
	local v317
	if v315 and (v316 and v316.Parent) then
		local v318 = v315.collect
		if type(v318) == "function" then
			local v319 = v_u_211.env
			local v320, v321, v322, v323, v324, v325, v326, v327, v328
			if v319 then
				local v329 = v319.isOpen
				if type(v329) == "function" then
					local v330 = v319.isOpen
					local v331
					v320, v331 = pcall(v330)
					if v320 then
						v320 = v331 == true
					end
					if v320 then
						v321 = v315.collect
						v322, v323 = pcall(v321)
						if v322 and type(v323) == "table" then
							v324 = v_u_4.diff(v_u_211.entries, v323)
							for v336, v337 in v323 do
								v325 = v_u_211.rows[v337.id]
								if not (v325 and v325.row.Parent) then
									continue
								end
								v325.entry = v337
								if not v325.filled or v325.sig == v337.sig then
									continue
								end
								v_u_217(v325, v337)
							end
							if v324.same then
								v_u_211.entries = v323
							else
								v_u_4.touch()
								v_u_211.entries = v323
								v326 = v315.repaint
								if type(v326) == "function" then
									v327 = v315.repaint
									pcall(v327)
								end
							end
						else
							return
						end
					else
						v_u_4.touch()
						return
					end
				else
					v328 = v_u_2.LocalPlayer
					if v328 == nil then
						v320 = false
					else
						v320 = v328:GetAttribute("MapOpen") == true
					end
					if v320 then
						v321 = v315.collect
						v322, v323 = pcall(v321)
						if v322 and type(v323) == "table" then
							v324 = v_u_4.diff(v_u_211.entries, v323)
							for v336, v337 in v323 do
								v325 = v_u_211.rows[v337.id]
								if not (v325 and v325.row.Parent) then
									continue
								end
								v325.entry = v337
								if not v325.filled or v325.sig == v337.sig then
									continue
								end
								v_u_217(v325, v337)
							end
							if v324.same then
								v_u_211.entries = v323
							else
								v_u_4.touch()
								v_u_211.entries = v323
								v326 = v315.repaint
								if type(v326) == "function" then
									v327 = v315.repaint
									pcall(v327)
								end
							end
						else
							return
						end
					else
						v_u_4.touch()
						return
					end
				end
			else
				v328 = v_u_2.LocalPlayer
				if v328 == nil then
					v320 = false
				else
					v320 = v328:GetAttribute("MapOpen") == true
				end
				if v320 then
					v321 = v315.collect
					v322, v323 = pcall(v321)
					if v322 and type(v323) == "table" then
						v324 = v_u_4.diff(v_u_211.entries, v323)
						for v336, v337 in v323 do
							v325 = v_u_211.rows[v337.id]
							if not (v325 and v325.row.Parent) then
								continue
							end
							v325.entry = v337
							if not v325.filled or v325.sig == v337.sig then
								continue
							end
							v_u_217(v325, v337)
						end
						if v324.same then
							v_u_211.entries = v323
						else
							v_u_4.touch()
							v_u_211.entries = v323
							v326 = v315.repaint
							if type(v326) == "function" then
								v327 = v315.repaint
								pcall(v327)
							end
						end
					else
						return
					end
				else
					v_u_4.touch()
					return
				end
			end
		else
			v317 = v_u_211.conn
			v_u_211.conn = nil
			if v317 then
				v317:Disconnect()
			end
			return
		end
	else
		v317 = v_u_211.conn
		v_u_211.conn = nil
		if v317 then
			v317:Disconnect()
		end
		return
	end
end
function v_u_4.paint(p339) -- name: paint
	-- upvalues: (copy) v_u_211, (copy) v_u_314, (copy) v_u_2, (copy) v_u_4, (copy) v_u_338
	local v340 = p339.UI
	local v341 = p339.Theme.color
	local v342 = v_u_211.conn
	v_u_211.conn = nil
	if v342 then
		v342:Disconnect()
	end
	v_u_211.env = p339
	v_u_211.list = p339.parent
	v_u_211.rows = {}
	v_u_211.entries = p339.entries or {}
	if #v_u_211.entries == 0 then
		return {
			["rows"] = 0
		}
	end
	local v343 = false
	for _, v344 in v_u_211.entries do
		if v344.id ~= v_u_211.openId then
			continue
		end
		v343 = true
	end
	if not v343 then
		v_u_211.openId = nil
	end
	local v345 = p339.order or 900
	v340.label({
		["parent"] = nil,
		["name"] = "TasksHead",
		["text"] = "Tasks",
		["style"] = "caps",
		["textSize"] = 13,
		["color"] = nil,
		["size"] = nil,
		["valign"] = "bottom",
		["track"] = false,
		["parent"] = p339.parent,
		["color"] = v341.text2,
		["size"] = UDim2.new(1, 0, 0, 22)
	}).LayoutOrder = v345
	local v346 = v340.label
	local v347 = {
		["parent"] = nil,
		["name"] = "TasksHint",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = p339.parent
	}
	local v348 = p339.hintText
	local v349
	if type(v348) == "string" then
		v349 = p339.hintText
	else
		local v350 = p339.verb or "Tap"
		v349 = tostring(v350) .. " a task to see what to do."
	end
	v347.text = v349
	v347.color = v341.muted
	v347.size = UDim2.new(1, 0, 0, 18)
	v346(v347).LayoutOrder = v345 + 1
	for v351, v352 in v_u_211.entries do
		v_u_314(v352, v345 + 1 + v351)
	end
	local v353 = v_u_2.LocalPlayer
	if v353 then
		v_u_211.conn = v353:GetAttributeChangedSignal("TaskDetail"):Connect(function()
			-- upvalues: (ref) v_u_211, (ref) v_u_2, (ref) v_u_4, (ref) v_u_338
			local v354 = v_u_211.env
			local v355, v356
			if v354 then
				local v357 = v354.isOpen
				if type(v357) == "function" then
					local v358 = v354.isOpen
					local v359
					v355, v359 = pcall(v358)
					if v355 then
						v355 = v359 == true
					end
					if v355 then
						if not v_u_211.pending then
							v_u_211.pending = true
							task.defer(v_u_338)
						end
					else
						v_u_4.touch()
					end
				else
					v356 = v_u_2.LocalPlayer
					if v356 == nil then
						v355 = false
					else
						v355 = v356:GetAttribute("MapOpen") == true
					end
					if v355 then
						if not v_u_211.pending then
							v_u_211.pending = true
							task.defer(v_u_338)
						end
					else
						v_u_4.touch()
					end
				end
			else
				v356 = v_u_2.LocalPlayer
				if v356 == nil then
					v355 = false
				else
					v355 = v356:GetAttribute("MapOpen") == true
				end
				if v355 then
					if not v_u_211.pending then
						v_u_211.pending = true
						task.defer(v_u_338)
					end
				else
					v_u_4.touch()
				end
			end
		end)
	end
	return {
		["rows"] = #v_u_211.entries
	}
end
function v_u_4.toggle(p_u_360) -- name: toggle
	-- upvalues: (copy) v_u_211, (copy) v_u_232
	if v_u_211.env then
		if p_u_360 == nil or v_u_211.openId == p_u_360 then
			local v361 = v_u_211.openId
			if v361 and v361 ~= nil then
				local v362 = v_u_211.rows[v361]
				if v362 and v362.row.Parent then
					local v363 = v_u_211.env.Theme.color
					v362.body.Visible = false
					v362.down.Visible = true
					v362.up.Visible = false
					v362.head.BackgroundColor3 = v363.raised
					v362.row:SetAttribute("Open", false)
				end
			end
			v_u_211.openId = nil
			local v364 = v_u_211.env
			if v364 then
				local v365 = v364.onChange
				if type(v365) == "function" and v361 ~= nil then
					local v366 = v364.onChange
					pcall(v366, nil)
				end
			end
			return true
		else
			if not v_u_211.rows[p_u_360] then
				return false
			end
			v_u_232(p_u_360)
			local function v_u_375() -- name: pass
				-- upvalues: (ref) v_u_211, (copy) p_u_360
				local v367 = v_u_211.rows[p_u_360]
				local v368 = v_u_211.list
				if v_u_211.openId == p_u_360 and (v367 and (v368 and (v367.row.Parent and v368.Parent))) then
					if v367.head.AbsoluteSize.Y > 0.01 then
						local v369 = v368.CanvasPosition.Y
						local v370 = v367.row.AbsolutePosition.Y - v368.AbsolutePosition.Y + v369
						local v371 = v367.row.AbsoluteSize.Y
						local v372 = v368.AbsoluteSize.Y
						if v370 >= v369 then
							if v370 + v371 > v369 + v372 then
								local v373 = v370 + v371 - v372
								v370 = math.min(v370, v373)
							else
								v370 = v369
							end
						end
						local v374 = v370 - v369
						if math.abs(v374) > 0.5 then
							v368.CanvasPosition = Vector2.new(0, (math.max(0, v370)))
						end
					end
				else
					return
				end
			end
			task.defer(function()
				-- upvalues: (copy) v_u_375
				task.wait()
				v_u_375()
				task.wait(0.15)
				v_u_375()
				task.wait(0.5)
				v_u_375()
			end)
			for _, v376 in v_u_211.entries do
				if v376.id ~= p_u_360 then
					continue
				end
				local v377 = v_u_211.env.onOpen
				if type(v377) ~= "function" then
					continue
				end
				local v378 = v_u_211.env.onOpen
				pcall(v378, v376)
			end
			return true
		end
	else
		return false
	end
end
function v_u_4.openWhere(p379) -- name: openWhere
	-- upvalues: (copy) v_u_211, (copy) v_u_4
	if not v_u_211.env then
		return false
	end
	local v380 = {}
	for _, v381 in v_u_211.entries do
		if not table.find(v381.wheres, p379) then
			continue
		end
		table.insert(v380, v381)
	end
	if #v380 == 0 then
		return false
	end
	local v382 = v380[1]
	for v383, v384 in v380 do
		if v384.id ~= v_u_211.openId then
			continue
		end
		v382 = v380[v383 % #v380 + 1]
	end
	return v_u_4.toggle(v382.id)
end
return v_u_4