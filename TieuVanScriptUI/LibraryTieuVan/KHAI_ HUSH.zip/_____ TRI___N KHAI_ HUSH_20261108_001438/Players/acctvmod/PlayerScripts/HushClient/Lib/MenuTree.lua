-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTree

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("TweenService")
local v6 = {}
local function v_u_13(p_u_7, p_u_8) -- name: libOf
	local v9, v10 = pcall(function()
		-- upvalues: (copy) p_u_7, (copy) p_u_8
		return p_u_7.cctx.lib[p_u_8]
	end)
	if v9 and type(v10) == "table" then
		return v10
	else
		local v11, v12 = pcall(function()
			-- upvalues: (copy) p_u_8
			return require(script.Parent:WaitForChild(p_u_8, 5))
		end)
		if v11 and type(v12) == "table" then
			return v12
		else
			return nil
		end
	end
end
local v_u_14 = false
local v_u_15 = {
	"gun",
	"grit",
	"ghost",
	"life",
	"kit"
}
local v_u_16 = {
	["gun"] = "GUNCRAFT",
	["grit"] = "GRIT",
	["ghost"] = "GHOST",
	["life"] = "LIFELINE",
	["kit"] = "KIT"
}
function v6.new(p_u_17, p18) -- name: new
	-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (ref) v_u_14, (copy) v_u_15, (copy) v_u_16, (copy) v_u_4
	local v_u_19 = p_u_17.ui
	local v_u_20 = p_u_17.theme
	local v_u_21 = v_u_20.color
	local v_u_22 = v_u_13(p_u_17, "MenuTreeLayout")
	local v_u_23 = v_u_13(p_u_17, "TextFitting")
	local v_u_24 = v_u_13(p_u_17, "PerkGuide")
	local v_u_25 = v_u_13(p_u_17, "VirtualPad")
	local v_u_26 = v_u_1.LocalPlayer
	local v_u_27 = v_u_22.TEXT
	local v_u_28 = {}
	local v_u_29 = true
	local v_u_30 = false
	local v_u_31 = nil
	local v_u_32 = false
	local v_u_33 = false
	local v_u_34 = "A"
	local v_u_35 = "gun"
	local v_u_36 = nil
	local v_u_37 = false
	local v_u_38 = false
	local v_u_39 = false
	local v_u_40 = false
	local v_u_41 = false
	local v_u_42 = false
	local v_u_43 = 0
	local v_u_44 = nil
	local v_u_45 = {}
	local v_u_46 = {}
	local v_u_47 = {}
	local v_u_48 = nil
	local v_u_49 = nil
	local v_u_50 = {}
	local v_u_51 = ""
	local v_u_52 = nil
	local v_u_53 = v_u_19.new("Frame", {
		["Name"] = "PerksPage",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, p18)
	local v_u_54 = v_u_19.new("Frame", {
		["Name"] = "PerksBody",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_53)
	local v_u_55 = v_u_19.label({
		["parent"] = nil,
		["name"] = "PadHint",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["track"] = false,
		["size"] = nil,
		["position"] = nil,
		["visible"] = false,
		["parent"] = v_u_53,
		["color"] = v_u_21.text2,
		["size"] = UDim2.new(1, 0, 0, 16),
		["position"] = UDim2.new(0, 0, 1, -16)
	})
	local function v_u_63() -- name: panelSize
		-- upvalues: (copy) v_u_53, (copy) v_u_20
		local v56 = v_u_53.AbsoluteSize
		local v_u_57 = 1
		local function v59()
			-- upvalues: (ref) v_u_57, (ref) v_u_20
			local v58 = v_u_20.uiScale
			v_u_57 = math.max(0.1, v58())
		end
		pcall(v59)
		if v56.X <= 0 or v56.Y <= 0 then
			return 800, 300
		end
		local v60 = v56.X / v_u_57
		local v61 = math.floor(v60)
		local v62 = v56.Y / v_u_57
		return v61, math.floor(v62)
	end
	local v_u_64 = {
		["accent"] = v_u_21.accent,
		["info"] = v_u_21.info,
		["success"] = v_u_21.success,
		["text"] = v_u_21.text,
		["text2"] = v_u_21.text2,
		["muted"] = v_u_21.muted,
		["danger"] = v_u_21.danger,
		["raised"] = v_u_21.raised,
		["line"] = v_u_21.line,
		["accentDeep"] = v_u_21.accentDeep,
		["dangerDeep"] = v_u_21.dangerDeep
	}
	local v_u_65 = {
		["ok"] = "success",
		["info"] = "text2",
		["bad"] = "danger",
		["muted"] = "text2"
	}
	local v_u_66 = {
		["ok"] = "check",
		["info"] = "info",
		["bad"] = "warning",
		["muted"] = nil
	}
	local function v_u_80(p67, p68) -- name: pIcon
		-- upvalues: (copy) v_u_20, (copy) v_u_19
		local v69 = {}
		for v70, v71 in p68 do
			v69[v70] = v71
		end
		if v69.thickness == nil then
			local v72 = v69.size
			local v73 = (type(v72) ~= "number" and 20 or v69.size) / 11 + 0.5
			local v74 = math.floor(v73)
			local v_u_75 = 1
			local function v76()
				-- upvalues: (ref) v_u_75, (ref) v_u_20
				v_u_75 = v_u_20.uiScale()
			end
			pcall(v76)
			local v77 = v_u_75
			local v78 = 1.2 / math.max(0.5, v77) + 0.5
			local v79 = math.floor(v78)
			v69.thickness = math.max(v74, 1, v79)
		end
		return v_u_19.icon(p67, v69)
	end
	local function v_u_88(p81, p82, p83, p84, p85, p86) -- name: frameAt
		-- upvalues: (copy) v_u_19, (copy) v_u_21
		local v87 = v_u_19.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Name"] = p82,
			["BackgroundColor3"] = p84 or v_u_21.raised,
			["BackgroundTransparency"] = p85 or 0.12
		}, p81)
		v87.Position = UDim2.fromOffset(p83.x, p83.y)
		v87.Size = UDim2.fromOffset(p83.w, p83.h)
		if p86 then
			v_u_19.stroke(v87, p86)
		end
		return v87
	end
	local function v_u_110(p89, p90, p91, p92, p93, p94, p95, p96, p97) -- name: lbl
		-- upvalues: (copy) v_u_19, (copy) v_u_23, (copy) v_u_20
		local v98 = v_u_19.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = nil,
			["textSize"] = nil,
			["color"] = nil,
			["align"] = nil,
			["track"] = false,
			["wrap"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = p89,
			["name"] = p90,
			["text"] = p91,
			["style"] = p93 or "small",
			["textSize"] = p97,
			["color"] = p94,
			["align"] = p95,
			["wrap"] = p96,
			["size"] = UDim2.fromOffset(p92.w, p92.h),
			["position"] = UDim2.fromOffset(p92.x, p92.y)
		})
		if not p96 and v_u_23 then
			local v99 = v_u_23.fit
			if type(v99) == "function" then
				local v100 = v98.TextSize
				local v_u_101 = 1
				local function v102()
					-- upvalues: (ref) v_u_101, (ref) v_u_20
					v_u_101 = v_u_20.uiScale()
				end
				pcall(v102)
				local v103 = v_u_101
				local v104 = 11 / math.max(0.5, v103)
				local v105 = math.ceil(v104)
				local v106 = math.min(v100, v105)
				local v107 = v_u_23.fit
				local v108 = p92.w - 2
				local v109 = math.max(10, v108)
				pcall(v107, v98, v109, v106)
			end
		end
		return v98
	end
	local function v_u_114() -- name: hintSize
		-- upvalues: (copy) v_u_22, (copy) v_u_20
		local v111 = v_u_22.hintSize
		local v_u_112 = 1
		local function v113()
			-- upvalues: (ref) v_u_112, (ref) v_u_20
			v_u_112 = v_u_20.uiScale()
		end
		pcall(v113)
		return v111(v_u_112)
	end
	local function v_u_131(p115, p116, p117, p118, p119, p120, p121) -- name: hint
		-- upvalues: (copy) v_u_22, (copy) v_u_20, (copy) v_u_19, (copy) v_u_21, (copy) v_u_23
		local v122 = v_u_22.hintSize
		local v_u_123 = 1
		local function v124()
			-- upvalues: (ref) v_u_123, (ref) v_u_20
			v_u_123 = v_u_20.uiScale()
		end
		pcall(v124)
		local v125 = v122(v_u_123)
		local v126 = v_u_19.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["textSize"] = nil,
			["color"] = nil,
			["align"] = nil,
			["track"] = false,
			["wrap"] = nil,
			["fitWrap"] = false,
			["valign"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = p115,
			["name"] = p116,
			["text"] = p117,
			["textSize"] = v125,
			["color"] = p119 or v_u_21.text,
			["align"] = p121,
			["wrap"] = p120,
			["valign"] = p120 and "top" or "center",
			["size"] = UDim2.fromOffset(p118.w, p118.h),
			["position"] = UDim2.fromOffset(p118.x, p118.y)
		})
		if p120 then
			v126.TextTruncate = Enum.TextTruncate.AtEnd
		elseif v_u_23 then
			local v127 = v_u_23.fit
			if type(v127) == "function" then
				local v128 = v_u_23.fit
				local v129 = p118.w - 2
				local v130 = math.max(10, v129)
				pcall(v128, v126, v130, v125)
			end
		end
		v126:SetAttribute("HintSize", v125)
		return v126
	end
	local function v_u_146(p132, p133, p134, p135, p136, p137) -- name: button
		-- upvalues: (copy) v_u_19
		local v138 = v_u_19.button
		local v139 = {
			["parent"] = p132,
			["name"] = p133,
			["text"] = p135,
			["kind"] = p136 or "secondary",
			["height"] = p134.h,
			["width"] = p134.w
		}
		local v140 = p134.w - 16
		v139.maxTextWidth = math.max(20, v140)
		v139.onClick = p137
		local v141, v142 = v138(v139)
		v141.Position = UDim2.fromOffset(p134.x, p134.y)
		v141.Size = UDim2.fromOffset(p134.w, p134.h)
		local v143 = v141:FindFirstChild("Inner")
		if v143 then
			v143 = v143:FindFirstChildOfClass("UIPadding")
		end
		if v143 then
			local v144 = UDim.new(0, 8)
			local v145 = UDim.new(0, 8)
			v143.PaddingLeft = v144
			v143.PaddingRight = v145
		end
		return v141, v142
	end
	local function v_u_158(p147, p148, p149) -- name: quietDisabled
		-- upvalues: (copy) v_u_22, (copy) v_u_19, (copy) v_u_21, (copy) v_u_64, (copy) v_u_80
		p148.setEnabled(false)
		if p148.label then
			p148.label.Visible = false
		end
		local v150 = v_u_22.buttonLook(false)
		local v151 = v_u_19.new
		local v152 = "Frame"
		local v153 = {
			["Name"] = "DisabledBacking",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2
		}
		local v154
		if v150.bg == "bg" then
			v154 = v_u_21.bg
		else
			v154 = v_u_21.raised
		end
		v153.BackgroundColor3 = v154
		v153.Size = UDim2.fromScale(1, 1)
		local v155 = v151(v152, v153, p147)
		v_u_19.stroke(v155, v_u_64[v150.stroke] or v_u_21.text, v150.strokeThick, v150.strokeA)
		local v156 = v_u_19.label({
			["parent"] = nil,
			["name"] = "DisabledText",
			["text"] = nil,
			["style"] = "h3",
			["textSize"] = 14,
			["color"] = nil,
			["align"] = "center",
			["track"] = true,
			["size"] = nil,
			["parent"] = p147,
			["text"] = p149,
			["color"] = v_u_64[v150.text] or v_u_21.text,
			["size"] = UDim2.fromScale(1, 1)
		})
		v156.ZIndex = 3
		v156.TextTransparency = v150.textA
		v156.TextTruncate = Enum.TextTruncate.AtEnd
		if v150.lock then
			local v157 = v_u_80("lock", {
				["size"] = 12,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 3,
				["color"] = v_u_64[v150.text] or v_u_21.text,
				["position"] = UDim2.new(0, 6, 0.5, 0),
				["anchor"] = Vector2.new(0, 0.5)
			})
			v157.Name = "DisabledLock"
			v157.Parent = p147
		end
	end
	local function v_u_172(p159, p160) -- name: twoLines
		if not p160 then
			return p159
		end
		local v161 = string.find(p159, ": ", 1, true)
		if v161 then
			local v162 = string.sub(p159, 1, v161)
			local v163 = v161 + 2
			return v162 .. "\n" .. string.sub(p159, v163)
		end
		local v164 = 1000000000
		local v165 = nil
		for v166 = 1, #p159 do
			if string.sub(p159, v166, v166) ~= " " then
				continue
			end
			local v167 = v166 - #p159 / 2
			if math.abs(v167) >= v164 then
				continue
			end
			local v168 = v166 - #p159 / 2
			v164 = math.abs(v168)
			v165 = v166
		end
		if not v165 then
			return p159
		end
		local v169 = v165 - 1
		local v170 = string.sub(p159, 1, v169)
		local v171 = v165 + 1
		return v170 .. "\n" .. string.sub(p159, v171)
	end
	local function v_u_177(p173, p174) -- name: clear
		-- upvalues: (copy) v_u_46
		if p174 ~= true then
			for _, v_u_175 in v_u_46 do
				pcall(function()
					-- upvalues: (copy) v_u_175
					v_u_175:Cancel()
				end)
			end
			table.clear(v_u_46)
		end
		for _, v176 in p173:GetChildren() do
			v176:Destroy()
		end
	end
	local function v_u_179() -- name: holdCancel
		-- upvalues: (ref) v_u_44
		if v_u_44 then
			local function v178()
				-- upvalues: (ref) v_u_44
				v_u_44.conn:Disconnect()
				v_u_44.endConn:Disconnect()
			end
			pcall(v178)
			if v_u_44.bar and v_u_44.bar.Parent then
				v_u_44.bar.Size = UDim2.new(0, 0, 0, 4)
			end
			v_u_44 = nil
		end
	end
	local function v_u_187(p_u_180, p_u_181) -- name: holdStart
		-- upvalues: (copy) v_u_179, (copy) v_u_22, (ref) v_u_2, (ref) v_u_29, (copy) v_u_25, (ref) v_u_3, (ref) v_u_44
		v_u_179()
		if p_u_180 then
			local v_u_182 = {
				["bar"] = p_u_180,
				["st"] = v_u_22.newHold(os.clock())
			}
			v_u_182.conn = v_u_2.Heartbeat:Connect(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_179, (ref) v_u_22, (copy) v_u_182, (copy) p_u_180, (copy) p_u_181
				if v_u_29 then
					local v183, v184 = v_u_22.holdStep(v_u_182.st, os.clock(), false)
					if p_u_180.Parent then
						p_u_180.Size = UDim2.new(math.min(v184, 1), 0, 0, 4)
					end
					if v183 then
						v_u_179()
						p_u_181()
					end
				else
					v_u_179()
				end
			end)
			local v185
			if v_u_25 and v_u_25.InputEnded then
				v185 = v_u_25.InputEnded
			else
				v185 = v_u_3.InputEnded
			end
			v_u_182.endConn = v185:Connect(function(p186)
				-- upvalues: (ref) v_u_179
				if (p186.UserInputType == Enum.UserInputType.MouseButton1 or p186.UserInputType == Enum.UserInputType.Touch) and true or p186.KeyCode == Enum.KeyCode.ButtonA then
					v_u_179()
				end
			end)
			v_u_44 = v_u_182
		end
	end
	local function v_u_189(p188) -- name: holdBarIn
		-- upvalues: (copy) v_u_19, (copy) v_u_21
		return v_u_19.new("Frame", {
			["Name"] = "HoldBar",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 8,
			["BackgroundColor3"] = v_u_21.text,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(0, 0, 0, 4)
		}, p188)
	end
	local function v_u_197(p_u_190) -- name: pulse
		-- upvalues: (copy) v_u_20, (ref) v_u_5, (copy) v_u_46
		local v_u_191 = false
		local function v192()
			-- upvalues: (ref) v_u_191, (ref) v_u_20
			v_u_191 = v_u_20.reduced() == true
		end
		pcall(v192)
		if not v_u_191 then
			local function v193()
				-- upvalues: (ref) v_u_5, (copy) p_u_190
				return v_u_5:Create(p_u_190, TweenInfo.new(1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
					["Transparency"] = 0.7
				})
			end
			local v194, v195 = pcall(v193)
			if v194 and v195 then
				v195:Play()
				local v196 = v_u_46
				table.insert(v196, v195)
			end
		end
	end
	local function v_u_201(p198) -- name: nodesOfBranch
		-- upvalues: (ref) v_u_31
		local v199 = {}
		for _, v200 in v_u_31 and v_u_31.nodes or {} do
			if v200.branch ~= p198 then
				continue
			end
			table.insert(v199, v200)
		end
		return v199
	end
	local function v_u_210(p202) -- name: tiersOf
		-- upvalues: (copy) v_u_201
		local v203 = {
			0,
			0,
			0,
			0,
			0
		}
		local v204 = {
			{},
			{},
			{},
			{},
			{}
		}
		for _, v205 in v_u_201(p202) do
			local v206 = v205.tier
			local v207 = tonumber(v206) or 1
			local v208 = math.clamp(v207, 1, 5)
			v203[v208] = v203[v208] + 1
			local v209 = v204[v208]
			table.insert(v209, v205)
		end
		return v203, v204
	end
	local function v_u_214(p211) -- name: firstPick
		-- upvalues: (copy) v_u_201
		local v212 = nil
		for _, v213 in v_u_201(p211) do
			if v213.learnable == true then
				return v213.id
			end
			if v212 ~= nil or v213.state == "max" then
				continue
			end
			v212 = v213
		end
		if v212 then
			return v212.id
		else
			return nil
		end
	end
	local v_u_215 = nil
	local v_u_216 = nil
	local function v_u_222(p217, p218, p219) -- name: doOp
		-- upvalues: (ref) v_u_31, (ref) v_u_42, (ref) v_u_43, (copy) v_u_179, (copy) p_u_17
		local v220
		if v_u_31 == nil or v_u_31.canChange ~= true then
			v220 = false
		else
			v220 = v_u_31.on ~= false
		end
		if v220 then
			if not v_u_42 or os.clock() - v_u_43 >= 3 then
				local v221 = os.clock()
				v_u_42 = true
				v_u_43 = v221
				v_u_179()
				p_u_17.op({
					["op"] = "tree",
					["act"] = nil,
					["id"] = nil,
					["rank"] = nil,
					["act"] = p217,
					["id"] = p218,
					["rank"] = p219
				})
			end
		else
			return
		end
	end
	function v_u_28.onBack() -- name: onBack
		-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_215, (ref) v_u_40, (ref) v_u_34
		if v_u_37 or v_u_38 then
			v_u_37 = false
			v_u_38 = false
			v_u_215()
			return true
		end
		if v_u_40 then
			v_u_40 = false
			v_u_215()
			return true
		end
		if v_u_34 == "A" then
			return false
		end
		v_u_34 = "A"
		v_u_215()
		return true
	end
	local function v_u_229(p223) -- name: selectNode
		-- upvalues: (ref) v_u_52, (ref) v_u_40, (ref) v_u_34, (copy) v_u_179, (ref) v_u_36, (ref) v_u_41, (ref) v_u_215, (copy) v_u_47, (copy) v_u_21, (ref) v_u_216
		local v224
		if v_u_52 == nil or v_u_52.B == nil then
			v224 = false
		else
			v224 = v_u_52.B.mode == "sheet"
		end
		if v224 and (not v_u_40 and v_u_34 == "B") then
			v_u_179()
			v_u_36 = p223
			v_u_40 = true
			v_u_41 = true
			v_u_215()
		elseif v_u_36 ~= p223 then
			v_u_179()
			v_u_36 = p223
			for v225, v226 in v_u_47 do
				if not v226.stroke then
					continue
				end
				v226.stroke.Thickness = v225 == p223 and 2 or (v226.thick or 1)
				local v227 = v226.stroke
				local v228
				if v225 == p223 then
					v228 = v_u_21.accent
				else
					v228 = v226.edge
				end
				v227.Color = v228
				v226.stroke.Transparency = v225 == p223 and 0 or v226.edgeA
			end
			v_u_216()
		end
	end
	local function v_u_267(p230, p231, p232, p233) -- name: drawBar
		-- upvalues: (ref) v_u_52, (copy) v_u_22, (copy) v_u_20, (copy) v_u_64, (copy) v_u_21, (copy) v_u_19, (copy) v_u_24, (copy) v_u_131, (copy) v_u_80, (copy) v_u_110
		local v234
		if v_u_52 == nil then
			v234 = false
		else
			v234 = v_u_52.chipOne == true
		end
		local v235 = v_u_22.hintSize
		local v_u_236 = 1
		local function v237()
			-- upvalues: (ref) v_u_236, (ref) v_u_20
			v_u_236 = v_u_20.uiScale()
		end
		pcall(v237)
		local v238 = v235(v_u_236)
		for v239, v240 in p232 do
			local v241 = p233.chips[v239]
			if not v241 then
				continue
			end
			local v242 = v_u_64[v241.color] or v_u_21.text
			local v243 = "Chip_" .. v241.id
			local v244 = {
				["x"] = p231.x + v240.x,
				["y"] = p231.y,
				["w"] = v240.w,
				["h"] = v240.h
			}
			local v245 = v_u_21.raised
			local v246 = v_u_19.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Name"] = v243,
				["BackgroundColor3"] = v245 or v_u_21.raised
			}, p230)
			v246.Position = UDim2.fromOffset(v244.x, v244.y)
			v246.Size = UDim2.fromOffset(v244.w, v244.h)
			v_u_19.stroke(v246, v242, 1, 0.55)
			v246:SetAttribute("Value", v241.value)
			local v247 = v240.w < 120
			local v248
			if v234 or v247 then
				v248 = v241.labelShort or v241.label
			else
				v248 = v241.label
			end
			if v234 then
				local v249 = v_u_24.charCount(v248) * v238 * v_u_22.EM
				local v250 = math.ceil(v249) + 2
				v_u_131(v246, "Label", v248, {
					["x"] = 6,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v250,
					["h"] = v240.h
				}, v_u_21.text2)
				local v251 = v250 + 6 + 4
				if v241.icon then
					local v252 = v_u_80(v241.icon, {
						["size"] = 12,
						["color"] = nil,
						["color"] = v242
					})
					local v253 = UDim2.fromOffset
					local v254 = (v240.h - 12) / 2
					v252.Position = v253(v251, (math.floor(v254)))
					v252.Parent = v246
					v251 = v251 + 16
				end
				local v255 = v_u_110
				local v256 = v_u_22.chipValue
				local v257 = v240.w - v251 - 4
				local v_u_258 = 1
				local function v259()
					-- upvalues: (ref) v_u_258, (ref) v_u_20
					v_u_258 = v_u_20.uiScale()
				end
				pcall(v259)
				v255(v246, "Value", v256(v241, v247, v257, v_u_258), {
					["x"] = nil,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["x"] = v251,
					["w"] = v240.w - v251 - 4,
					["h"] = v240.h
				}, "bodyStrong", v242)
			else
				v_u_131(v246, "Label", v248, {
					["x"] = 6,
					["y"] = 1,
					["w"] = nil,
					["h"] = 15,
					["w"] = v240.w - 12
				}, v_u_21.text2)
				local v260
				if v241.icon then
					local v261 = v_u_80(v241.icon, {
						["size"] = 12,
						["color"] = nil,
						["color"] = v242
					})
					v261.Position = UDim2.fromOffset(6, v240.h - 21 + 3)
					v261.Parent = v246
					v260 = 22
				else
					v260 = 6
				end
				local v262 = v_u_110
				local v263 = v_u_22.chipValue
				local v264 = v240.w - v260 - 4
				local v_u_265 = 1
				local function v266()
					-- upvalues: (ref) v_u_265, (ref) v_u_20
					v_u_265 = v_u_20.uiScale()
				end
				pcall(v266)
				v262(v246, "Value", v263(v241, v247, v264, v_u_265), {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 18,
					["x"] = v260,
					["y"] = v240.h - 21,
					["w"] = v240.w - v260 - 4
				}, "bodyStrong", v242)
			end
		end
	end
	local function v_u_273(p268, p269, p270) -- name: drawNote
		-- upvalues: (copy) v_u_88, (copy) v_u_21, (copy) v_u_80, (copy) v_u_64, (copy) v_u_22, (copy) v_u_114, (copy) v_u_131
		if p270 and p269 then
			v_u_88(p268, "BonusBacking", p269, v_u_21.bg, 0.2, v_u_21.line)
			local v271 = v_u_80(p270.icon or "info", {
				["size"] = 14,
				["color"] = nil,
				["color"] = v_u_64[p270.color] or v_u_21.text
			})
			v271.Position = UDim2.fromOffset(p269.x + 4, p269.y + 3)
			v271.Parent = p268
			local v272 = p269.h <= v_u_22.lineH(v_u_114()) + 4
			v_u_131(p268, "BonusNote", p270.text, {
				["x"] = p269.x + 22,
				["y"] = p269.y + 2,
				["w"] = p269.w - 26,
				["h"] = p269.h - 4
			}, v_u_64[p270.color] or v_u_21.text, not v272)
		end
	end
	local function v_u_300(p274) -- name: helpButton
		-- upvalues: (copy) v_u_19, (copy) v_u_21, (copy) v_u_54, (ref) v_u_14, (copy) v_u_22, (copy) v_u_27, (copy) v_u_114, (copy) v_u_23, (copy) v_u_20, (ref) v_u_38, (ref) v_u_37, (ref) v_u_215, (copy) v_u_197
		local v_u_275 = v_u_19.new("TextButton", {
			["Name"] = "HelpButton",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = v_u_21.accentDeep
		}, v_u_54)
		v_u_275.Position = UDim2.fromOffset(p274.x, p274.y)
		v_u_275.Size = UDim2.fromOffset(p274.w, p274.h)
		local v276 = v_u_19.stroke(v_u_275, v_u_21.accent, 2, 0)
		v_u_275:SetAttribute("FocusId", "help")
		local function v277()
			-- upvalues: (copy) v_u_275, (ref) v_u_19
			v_u_275.SelectionImageObject = v_u_19.selectionImage()
		end
		pcall(v277)
		v_u_275:SetAttribute("Seen", v_u_14)
		local v278
		if p274.w < v_u_22.HELP_W_LONG then
			v278 = v_u_27.helpShort
		else
			v278 = v_u_27.help
		end
		v_u_275:SetAttribute("Word", v278)
		local v279 = p274.h - 10
		local v280 = math.min(24, v279)
		local v281 = v_u_19.new
		local v282 = {
			["Name"] = "Badge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Position"] = nil,
			["BackgroundColor3"] = v_u_21.accent,
			["Size"] = UDim2.fromOffset(v280, v280)
		}
		local v283 = UDim2.fromOffset
		local v284 = (p274.h - v280) / 2
		v282.Position = v283(8, (math.floor(v284)))
		local v285 = v281("Frame", v282, v_u_275)
		v_u_19.new("UICorner", {
			["CornerRadius"] = UDim.new(0.5, 0)
		}, v285)
		v_u_19.label({
			["parent"] = nil,
			["name"] = "Mark",
			["text"] = "?",
			["style"] = "h3",
			["textSize"] = 16,
			["color"] = nil,
			["align"] = "center",
			["track"] = false,
			["size"] = nil,
			["parent"] = v285,
			["color"] = v_u_21.bg,
			["size"] = UDim2.fromScale(1, 1)
		}).TextTruncate = Enum.TextTruncate.None
		local v286 = v280 + 8 + 8
		local v287 = v_u_19.label
		local v288 = {
			["parent"] = nil,
			["name"] = "Word",
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = nil,
			["color"] = nil,
			["align"] = "left",
			["track"] = true,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_275,
			["text"] = v278
		}
		local v289 = v_u_114
		v288.textSize = math.max(14, v289())
		v288.color = v_u_21.text
		v288.size = UDim2.fromOffset(p274.w - v286 - 8, p274.h)
		v288.position = UDim2.fromOffset(v286, 0)
		local v290 = v287(v288)
		if v_u_23 then
			local v291 = v_u_23.fit
			if type(v291) == "function" then
				local v292 = v_u_23.fit
				local v293 = p274.w - v286 - 10
				local v294 = math.max(10, v293)
				local v_u_295 = 1
				local function v296()
					-- upvalues: (ref) v_u_295, (ref) v_u_20
					v_u_295 = v_u_20.uiScale()
				end
				pcall(v296)
				local v297 = v_u_295
				local v298 = 11 / math.max(0.5, v297)
				local v299 = math.ceil(v298)
				pcall(v292, v290, v294, v299)
			end
		end
		v_u_275.Activated:Connect(function()
			-- upvalues: (ref) v_u_38, (ref) v_u_37, (ref) v_u_14, (ref) v_u_215
			v_u_38 = not v_u_38
			v_u_37 = false
			if v_u_38 then
				v_u_14 = true
			end
			v_u_215()
		end)
		if not v_u_14 then
			v_u_197(v276)
		end
	end
	local function v_u_315(p301, p302, p303, p304) -- name: drawLegend
		-- upvalues: (copy) v_u_22, (copy) v_u_20, (copy) v_u_24, (copy) v_u_88, (copy) v_u_21, (copy) v_u_80, (copy) v_u_64, (copy) v_u_131
		local v305 = v_u_22.hintSize
		local v_u_306 = 1
		local function v307()
			-- upvalues: (ref) v_u_306, (ref) v_u_20
			v_u_306 = v_u_20.uiScale()
		end
		pcall(v307)
		v305(v_u_306)
		for v308, v309 in v_u_24.legendItems() do
			local v310 = p304.rects[v308]
			if not v310 then
				continue
			end
			local v311 = v_u_88(p301, "Legend_" .. v309.id, {
				["x"] = p302 + v310.x,
				["y"] = p303 + v310.y,
				["w"] = v310.w,
				["h"] = v310.h
			}, v_u_21.bg, 0.2, v_u_21.line)
			local v312 = v_u_80(v309.icon, {
				["size"] = 14,
				["color"] = nil,
				["color"] = v_u_64[v309.iconColor] or v_u_21.text
			})
			local v313 = UDim2.fromOffset
			local v314 = (v310.h - 14) / 2
			v312.Position = v313(6, (math.floor(v314)))
			v312.Parent = v311
			v_u_131(v311, "Text", v309.label, {
				["x"] = 24,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v310.w - 26,
				["h"] = v310.h
			}, v_u_21.text)
		end
	end
	local function v_u_413(p316) -- name: buildA
		-- upvalues: (copy) v_u_110, (copy) v_u_54, (copy) v_u_22, (ref) v_u_31, (copy) v_u_21, (copy) v_u_300, (copy) v_u_24, (copy) v_u_267, (copy) v_u_273, (copy) v_u_19, (copy) v_u_146, (copy) v_u_27, (ref) v_u_37, (ref) v_u_38, (ref) v_u_215, (copy) v_u_88, (copy) p_u_17, (copy) v_u_20, (copy) v_u_50, (ref) v_u_16, (copy) v_u_80, (copy) v_u_197, (ref) v_u_34, (ref) v_u_35, (ref) v_u_40, (ref) v_u_36, (copy) v_u_214
		local v317 = p316.A
		v_u_110(v_u_54, "Level", v_u_22.levelText(v_u_31), v317.level, "h3", v_u_21.accent):SetAttribute("Text", v_u_22.levelText(v_u_31))
		v_u_300(v317.help)
		local v318 = v_u_24.bar(v_u_31, nil)
		v_u_267(v_u_54, v317.pbar, v317.chips, v318)
		v_u_273(v_u_54, v317.note, v318.note)
		local v319, v320 = v_u_22.levelProgress(v_u_31)
		local v321 = v_u_54
		local v322 = v317.bar
		local v323 = v_u_21.line
		local v324 = v_u_19.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = v323 or v_u_21.raised
		}, v321)
		v324.Position = UDim2.fromOffset(v322.x, v322.y)
		v324.Size = UDim2.fromOffset(v322.w, v322.h)
		local v325 = v_u_54
		local v326 = {
			["x"] = v317.bar.x,
			["y"] = v317.bar.y
		}
		local v327 = v317.bar.w * v319
		v326.w = math.floor(v327)
		v326.h = v317.bar.h
		local v328 = v_u_21.accent
		local v329 = v_u_19.new("Frame", {
			["Name"] = "BarFill",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = v328 or v_u_21.raised
		}, v325)
		v329.Position = UDim2.fromOffset(v326.x, v326.y)
		v329.Size = UDim2.fromOffset(v326.w, v326.h)
		v_u_110(v_u_54, "BarText", v320, v317.barText, "small", v_u_21.text2, "right")
		v_u_146(v_u_54, "SheetButton", v317.sheetBtn, v_u_27.sheet, "secondary", function()
			-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_215
			v_u_37 = not v_u_37
			v_u_38 = false
			v_u_215()
		end)
		if v317.banner then
			local v330 = v_u_88(v_u_54, "Banner", v317.banner, v_u_21.accentDeep, 0.05, v_u_21.accent)
			v_u_19.label({
				["parent"] = nil,
				["name"] = "BannerText",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["valign"] = "center",
				["track"] = false,
				["size"] = nil,
				["position"] = nil,
				["parent"] = v330,
				["text"] = v_u_27.updated,
				["color"] = v_u_21.text,
				["size"] = UDim2.fromOffset(v317.bannerText.w, v317.bannerText.h),
				["position"] = UDim2.fromOffset(v317.bannerText.x, v317.bannerText.y)
			})
			v_u_146(v330, "BannerOk", v317.bannerOk, "OK", "primary", function()
				-- upvalues: (ref) v_u_31, (ref) p_u_17, (ref) v_u_215
				v_u_31.patchRefund = false
				p_u_17.op({
					["op"] = "tree",
					["act"] = "ack"
				})
				v_u_215()
			end)
		end
		local v331 = v_u_19.new("ScrollingFrame", {
			["Name"] = "Tiles",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["ScrollBarThickness"] = v_u_20.scrollBar,
			["ScrollBarImageColor3"] = v_u_21.lineStrong,
			["CanvasSize"] = UDim2.fromOffset(0, v317.contentH + 8),
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, v_u_54)
		local v332 = v317.viewport
		v331.Position = UDim2.fromOffset(v332.x, v332.y)
		v331.Size = UDim2.fromOffset(v332.w, v332.h)
		v331.CanvasPosition = Vector2.new(0, v_u_50.A or 0)
		local v333
		if v_u_31 == nil or v_u_31.canChange ~= true then
			v333 = false
		else
			v333 = v_u_31.on ~= false
		end
		for _, v_u_334 in v_u_22.TILE_IDS do
			local v335 = v317.tiles[v_u_334]
			local v_u_336 = v_u_334 == "flaws"
			local v337 = nil
			for _, v338 in v_u_31.branches or {} do
				if v338.id ~= v_u_334 then
					continue
				end
				v337 = v338
			end
			local v_u_339 = v_u_19.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["Name"] = "Tile_" .. v_u_334,
				["BackgroundColor3"] = v_u_21.raised
			}, v331)
			v_u_339.Position = UDim2.fromOffset(v335.x, v335.y)
			v_u_339.Size = UDim2.fromOffset(v335.w, v335.h)
			local v340
			if v_u_336 then
				v340 = 0
			else
				local v341
				if v337 then
					v341 = v337.learnable
				else
					v341 = v337
				end
				local v342 = tonumber(v341) or 0
				v340 = math.floor(v342)
			end
			local v343 = v_u_19.stroke
			local v344
			if v340 > 0 and v333 then
				v344 = v_u_21.accent
			else
				v344 = v_u_21.line
			end
			local v345 = v343(v_u_339, v344)
			v_u_339:SetAttribute("FocusId", "tile:" .. v_u_334)
			local function v346()
				-- upvalues: (copy) v_u_339, (ref) v_u_19
				v_u_339.SelectionImageObject = v_u_19.selectionImage()
			end
			pcall(v346)
			local v347 = v_u_22.tileInner
			local v348 = v335.w
			local v349 = v335.h
			local v_u_350 = 1
			local function v351()
				-- upvalues: (ref) v_u_350, (ref) v_u_20
				v_u_350 = v_u_20.uiScale()
			end
			pcall(v351)
			local v352 = v347(v348, v349, v_u_350)
			local v353, v354
			if v_u_336 then
				v353, v354 = v_u_22.flawTileText(v_u_31)
			else
				v353, v354 = v_u_22.tileText(v337 or {}, v_u_31)
			end
			local v355 = v_u_110
			local v356 = v_u_339
			local v357 = "Name"
			local v358
			if v_u_336 then
				v358 = v_u_27.flaws
			else
				v358 = v_u_16[v_u_334] or v_u_334
			end
			v355(v356, v357, v358, v352.name, "h3", v_u_21.text)
			v_u_110(v_u_339, "Line1", v353, v352.line1, "small", v_u_21.text)
			local v359 = v_u_110
			local v360 = v_u_339
			local v361 = "Line2"
			local v362 = v352.line2
			local v363 = "small"
			local v364
			if v340 > 0 and v333 then
				v364 = v_u_21.accent
			else
				v364 = v_u_21.text2
			end
			v359(v360, v361, v354, v362, v363, v364)
			local v365
			if v_u_336 then
				v365 = "warning"
			elseif v340 > 0 and v333 then
				v365 = "plus"
			elseif v337 then
				local v366 = v337.spent
				v365 = (tonumber(v366) or 0) >= 16 and "check" or nil
			else
				v365 = nil
			end
			if v365 then
				local v367 = v_u_80
				local v368 = {
					["size"] = 20,
					["color"] = nil
				}
				local v369
				if v_u_336 then
					v369 = v_u_21.text2
				elseif v365 == "check" then
					v369 = v_u_21.success
				else
					v369 = v_u_21.accent
				end
				v368.color = v369
				local v370 = v367(v365, v368)
				v370.Position = UDim2.fromOffset(v352.badge.x + 4, v352.badge.y + 4)
				v370.Parent = v_u_339
			end
			local v371 = v_u_22.TILE_ICONS[v_u_334]
			if v352.icon and v371 then
				local v372 = v_u_22.tileIconTone(v_u_334, v340, v333)
				local v373 = v_u_19.new
				local v374 = "ImageLabel"
				local v375 = {
					["Name"] = "Icon",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Image"] = nil,
					["ScaleType"] = nil,
					["ImageColor3"] = nil,
					["Image"] = v371.asset,
					["ScaleType"] = Enum.ScaleType.Fit
				}
				local v376
				if v372 == "accent" then
					v376 = v_u_21.accent
				elseif v372 == "danger" then
					v376 = v_u_21.danger
				else
					v376 = v_u_21.muted
				end
				v375.ImageColor3 = v376
				local v377 = v373(v374, v375, v_u_339)
				v377.Size = UDim2.fromOffset(v352.icon.w, v352.icon.h)
				v377.Position = UDim2.fromOffset(v352.icon.x, v352.icon.y)
				v377:SetAttribute("Source", v371.source)
				v377:SetAttribute("Tone", v372)
			end
			if v340 > 0 and v333 then
				v_u_197(v345)
			end
			local v378
			if v_u_336 then
				local v379 = v_u_31.flawSlots
				if v379 then
					v379 = v_u_31.flawSlots.used
				end
				local v380 = tonumber(v379) or 0
				v378 = math.floor(v380) / 3
			else
				local v381 = 1
				if v337 then
					v337 = v337.spent
				end
				local v382 = (tonumber(v337) or 0) / 16
				v378 = math.min(v381, v382)
			end
			local v383 = v352.bar
			local v384 = v_u_21.line
			local v385 = v_u_19.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = v384 or v_u_21.raised
			}, v_u_339)
			v385.Position = UDim2.fromOffset(v383.x, v383.y)
			v385.Size = UDim2.fromOffset(v383.w, v383.h)
			local v386 = {
				["x"] = v352.bar.x,
				["y"] = v352.bar.y
			}
			local v387 = v352.bar.w * v378
			v386.w = math.floor(v387)
			v386.h = v352.bar.h
			local v388
			if v_u_336 then
				v388 = v_u_21.danger
			else
				v388 = v_u_21.accent
			end
			local v389 = v_u_19.new("Frame", {
				["Name"] = "BarFill",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = v388 or v_u_21.raised
			}, v_u_339)
			v389.Position = UDim2.fromOffset(v386.x, v386.y)
			v389.Size = UDim2.fromOffset(v386.w, v386.h)
			v_u_339.Activated:Connect(function()
				-- upvalues: (copy) v_u_336, (ref) v_u_34, (ref) v_u_37, (ref) v_u_38, (ref) v_u_215, (copy) v_u_334, (ref) v_u_35, (ref) v_u_40, (ref) v_u_36, (ref) v_u_214
				if v_u_336 then
					v_u_34 = "F"
					v_u_37 = false
					v_u_38 = false
					v_u_215()
				else
					local v390 = v_u_334
					v_u_34 = "B"
					v_u_35 = v390
					v_u_37 = false
					v_u_38 = false
					v_u_40 = false
					v_u_36 = v_u_214(v390)
					v_u_215()
				end
			end)
		end
		local v391 = v317.mastery
		v_u_110(v331, "MasteryHead", v_u_27.mastery, v391.head, "caps", v_u_21.text2)
		for v392, v393 in v391.rows do
			local v394 = (v_u_31.mastery or {})[v392]
			if not v394 then
				continue
			end
			local v395 = v394.class
			local v396 = "Mastery_" .. tostring(v395)
			local v397 = v_u_21.raised
			local v398 = v_u_19.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Name"] = v396,
				["BackgroundColor3"] = v397 or v_u_21.raised
			}, v331)
			v398.Position = UDim2.fromOffset(v393.x, v393.y)
			v398.Size = UDim2.fromOffset(v393.w, v393.h)
			v_u_110(v398, "Text", v_u_22.masteryText(v394), {
				["x"] = 10,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v393.w - 10 - 110,
				["h"] = v393.h
			}, "small", v_u_21.text)
			local v399 = v394.starsMax
			for v400 = 1, tonumber(v399) or 5 do
				local v401 = v_u_80
				local v402 = "star"
				local v403 = {
					["size"] = 16,
					["color"] = nil
				}
				local v404 = v394.stars
				local v405
				if v400 <= (tonumber(v404) or 0) then
					v405 = v_u_21.accent
				else
					v405 = v_u_21.lineStrong
				end
				v403.color = v405
				local v406 = v401(v402, v403)
				local v407 = UDim2.fromOffset
				local v408 = v393.w - 110 + (v400 - 1) * 20
				local v409 = (v393.h - 16) / 2
				v406.Position = v407(v408, (math.floor(v409)))
				v406.Parent = v398
			end
		end
		local v410 = 0
		local v411 = 0
		for _, v412 in v_u_31.firsts or {} do
			v410 = v410 + 1
			if not v412.done then
				continue
			end
			v411 = v411 + 1
		end
		v_u_110(v331, "Firsts", ("FIRSTS  %d of %d done"):format(v411, v410), v391.firsts, "small", v_u_21.text2)
	end
	local function v_u_418(p414) -- name: reqLine
		-- upvalues: (copy) v_u_22, (ref) v_u_31
		local v415 = {}
		for _, v416 in v_u_22.requirements(p414, v_u_31) do
			if v416.ok then
				continue
			end
			local v417 = v416.text
			table.insert(v415, v417)
		end
		if #v415 == 0 or p414.state == "max" then
			return nil
		else
			return "Needs: " .. table.concat(v415, "  \194\183  ")
		end
	end
	v_u_216 = function()
		-- upvalues: (ref) v_u_48, (ref) v_u_31, (ref) v_u_52, (ref) v_u_36, (copy) v_u_22, (copy) v_u_418, (copy) v_u_110, (copy) v_u_21, (copy) v_u_131, (copy) v_u_24, (copy) v_u_65, (copy) v_u_64, (copy) v_u_66, (copy) v_u_88, (copy) v_u_80, (copy) v_u_172, (copy) v_u_146, (copy) v_u_19, (copy) v_u_158, (ref) v_u_49, (copy) v_u_189, (copy) v_u_222, (copy) v_u_25, (copy) v_u_187, (copy) v_u_27
		local v419 = v_u_48
		if v419 == nil or (not v419.Parent or v_u_31 == nil) then
			return
		end
		for _, v420 in v419:GetChildren() do
			v420:Destroy()
		end
		local v421 = v_u_52
		if v421 then
			v421 = v_u_52.B
		end
		if not v421 then
			return
		end
		local v422 = v_u_36
		if v_u_31 and v422 then
			for _, v424 in v_u_31.nodes or {} do
				if v424.id ~= v422 then
					continue
				end
			end
		end
		local v424 = nil
		local v_u_425 = v_u_22.detail(v424, v_u_31)
		local v426
		if v424 then
			v426 = v_u_418(v424)
		else
			v426 = nil
		end
		if v_u_425.name ~= "" then
			v_u_110(v419, "Name", v_u_425.name, v421.name, "bodyStrong", v_u_21.accent)
		end
		v_u_131(v419, "Text", v_u_425.text, v421.text, v_u_21.text, true)
		local v427, v428 = v_u_24.reason(v424, v_u_31, v426)
		local v429 = v421.mode == "stack"
		local v430 = v421.mode == "sheet"
		if v427 ~= "" and v424 then
			local v431 = v_u_64[v_u_65[v428]] or v_u_21.text
			local v432 = v_u_66[v428]
			local v433 = v421.why
			v_u_88(v419, "WhyBacking", {
				["x"] = v433.x - 4,
				["y"] = v433.y - 1,
				["w"] = v433.w + 8,
				["h"] = v433.h + 2
			}, v_u_21.bg, 0.2, v_u_21.line)
			local v434 = v433.x
			if v432 then
				local v435 = v_u_80(v432, {
					["size"] = 14,
					["color"] = nil,
					["color"] = v431
				})
				v435.Position = UDim2.fromOffset(v433.x, v433.y + 2)
				v435.Parent = v419
				v434 = v433.x + 18
			end
			v_u_131(v419, "Why", v427, {
				["x"] = v434,
				["y"] = v433.y,
				["w"] = v433.w - (v434 - v433.x),
				["h"] = v433.h
			}, v431, true):SetAttribute("Kind", v428)
		end
		if v429 or (v427 == "" or not v424) then
			v_u_131(v419, "Now", v_u_425.now, v421.now, v_u_21.text2)
		end
		local v_u_436
		if v424 then
			local v437 = v424.rank
			local v438 = tonumber(v437) or 0
			v_u_436 = math.floor(v438)
		else
			v_u_436 = 0
		end
		local v439 = v_u_172(v_u_425.learnLabel, v430)
		local v_u_440, v441 = v_u_146(v419, "LearnButton", v421.learn, v439, "primary", nil)
		v_u_440:SetAttribute("FocusId", "learn")
		local function v442()
			-- upvalues: (copy) v_u_440, (ref) v_u_19
			v_u_440.SelectionImageObject = v_u_19.selectionImage()
		end
		pcall(v442)
		if v430 and v441.label then
			v441.label.TextSize = 14
		end
		if not v_u_425.learnOn then
			v_u_158(v_u_440, v441, v439)
		end
		v_u_49 = v_u_189(v_u_440)
		local v_u_443 = v_u_36
		local v_u_444 = v_u_49
		local function v_u_446()
			-- upvalues: (copy) v_u_425, (copy) v_u_443
			local v445 = v_u_425.learnOn
			if v445 then
				v445 = v_u_443 ~= nil
			end
			return v445
		end
		local function v_u_447()
			-- upvalues: (ref) v_u_222, (copy) v_u_443, (copy) v_u_436
			v_u_222("learn", v_u_443, v_u_436)
		end
		local v448
		if v_u_25 then
			local v449 = v_u_25.guiInputBegan
			if type(v449) == "function" then
				v448 = v_u_25.guiInputBegan(v_u_440)
			else
				v448 = v_u_440.InputBegan
			end
		else
			v448 = v_u_440.InputBegan
		end
		v448:Connect(function(p450)
			-- upvalues: (copy) v_u_446, (ref) v_u_187, (copy) v_u_444, (copy) v_u_447
			if ((p450.UserInputType == Enum.UserInputType.MouseButton1 or p450.UserInputType == Enum.UserInputType.Touch) and true or p450.KeyCode == Enum.KeyCode.ButtonA) and v_u_446() then
				v_u_187(v_u_444, v_u_447)
			end
		end)
		local v_u_451, v452 = v_u_146(v419, "UndoButton", v421.undo, v_u_27.undo, "secondary", function()
			-- upvalues: (copy) v_u_425, (copy) v_u_443, (ref) v_u_222, (copy) v_u_436
			if v_u_425.undoOn and v_u_443 then
				v_u_222("undo", v_u_443, v_u_436)
			end
		end)
		v_u_451:SetAttribute("FocusId", "undo")
		local function v453()
			-- upvalues: (copy) v_u_451, (ref) v_u_19
			v_u_451.SelectionImageObject = v_u_19.selectionImage()
		end
		pcall(v453)
		if v430 and v452.label then
			v452.label.TextSize = 14
		end
		if v_u_425.undoOn then
			local v454 = v_u_22.buttonLook(true, "undo")
			v_u_19.stroke(v_u_451, v_u_64[v454.stroke] or v_u_21.text, v454.strokeThick, v454.strokeA).Name = "ReadyEdge"
		else
			v_u_158(v_u_451, v452, v_u_27.undo)
		end
		local v455 = v_u_172(v_u_425.unlearnLabel, v430)
		local v_u_456, v457 = v_u_146(v419, "UnlearnButton", v421.unlearn, v455, "danger", nil)
		v_u_456:SetAttribute("FocusId", "unlearn")
		local function v458()
			-- upvalues: (copy) v_u_456, (ref) v_u_19
			v_u_456.SelectionImageObject = v_u_19.selectionImage()
		end
		pcall(v458)
		if v430 and v457.label then
			v457.label.TextSize = 14
		end
		if v_u_425.unlearnOn then
			local v459 = v_u_22.buttonLook(true, "unlearn")
			v_u_19.stroke(v_u_456, v_u_64[v459.stroke] or v_u_21.text, v459.strokeThick, v459.strokeA).Name = "ReadyEdge"
		else
			v_u_158(v_u_456, v457, v455)
		end
		local v_u_460 = v_u_189(v_u_456)
		local function v_u_462()
			-- upvalues: (copy) v_u_425, (copy) v_u_443
			local v461 = v_u_425.unlearnOn
			if v461 then
				v461 = v_u_443 ~= nil
			end
			return v461
		end
		local function v_u_463()
			-- upvalues: (ref) v_u_222, (copy) v_u_443, (copy) v_u_436
			v_u_222("unlearn", v_u_443, v_u_436)
		end
		local v464
		if v_u_25 then
			local v465 = v_u_25.guiInputBegan
			if type(v465) == "function" then
				v464 = v_u_25.guiInputBegan(v_u_456)
			else
				v464 = v_u_456.InputBegan
			end
		else
			v464 = v_u_456.InputBegan
		end
		v464:Connect(function(p466)
			-- upvalues: (copy) v_u_462, (ref) v_u_187, (copy) v_u_460, (copy) v_u_463
			if ((p466.UserInputType == Enum.UserInputType.MouseButton1 or p466.UserInputType == Enum.UserInputType.Touch) and true or p466.KeyCode == Enum.KeyCode.ButtonA) and v_u_462() then
				v_u_187(v_u_460, v_u_463)
			end
		end)
		if v_u_425.trial and (v_u_425.trial.done ~= true and (v_u_425.trial.need and v_u_425.trial.need > 0)) then
			local v467 = v421.now.w
			local v468 = math.max(40, v467)
			local v469 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 3,
				["x"] = v421.now.x,
				["y"] = v421.now.y + v421.now.h - 3,
				["w"] = v468
			}
			local v470 = v_u_21.line
			local v471 = v_u_19.new("Frame", {
				["Name"] = "TrialBar",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = v470 or v_u_21.raised
			}, v419)
			v471.Position = UDim2.fromOffset(v469.x, v469.y)
			v471.Size = UDim2.fromOffset(v469.w, v469.h)
			local v472 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 3,
				["x"] = v421.now.x,
				["y"] = v421.now.y + v421.now.h - 3
			}
			local v473 = (v_u_425.trial.have or 0) / v_u_425.trial.need
			local v474 = v468 * math.clamp(v473, 0, 1)
			v472.w = math.floor(v474)
			local v475 = v_u_21.accent
			local v476 = v_u_19.new("Frame", {
				["Name"] = "TrialFill",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = v475 or v_u_21.raised
			}, v419)
			v476.Position = UDim2.fromOffset(v472.x, v472.y)
			v476.Size = UDim2.fromOffset(v472.w, v472.h)
		end
	end
	local function v_u_566(p477) -- name: buildB
		-- upvalues: (copy) v_u_146, (copy) v_u_54, (ref) v_u_40, (copy) v_u_27, (copy) v_u_28, (copy) v_u_110, (ref) v_u_16, (ref) v_u_35, (copy) v_u_21, (ref) v_u_39, (ref) v_u_215, (copy) v_u_19, (copy) v_u_300, (copy) v_u_24, (ref) v_u_31, (copy) v_u_267, (copy) v_u_273, (ref) v_u_37, (ref) v_u_38, (copy) v_u_210, (copy) v_u_20, (copy) v_u_50, (copy) v_u_315, (copy) v_u_114, (copy) v_u_22, (copy) v_u_80, (copy) v_u_131, (copy) v_u_64, (ref) v_u_36, (copy) v_u_47, (copy) v_u_197, (copy) v_u_229, (copy) v_u_25, (copy) v_u_187, (ref) v_u_49, (copy) v_u_222, (ref) v_u_48, (copy) v_u_88, (ref) v_u_216, (ref) v_u_41
		local v478 = p477.B
		local v479 = v_u_146
		local v480 = v_u_54
		local v481 = "BackButton"
		local v482 = v478.back
		local v483
		if v_u_40 and v478.mode == "sheet" then
			v483 = v_u_27.close
		else
			v483 = v_u_27.back
		end
		v479(v480, v481, v482, v483, "secondary", function()
			-- upvalues: (ref) v_u_28
			v_u_28.onBack()
		end)
		v_u_110(v_u_54, "BranchName", v_u_16[v_u_35] or v_u_35, v478.title, "h3", v_u_21.accent)
		if v478.legendBtn then
			local v_u_484 = v_u_146(v_u_54, "LegendButton", v478.legendBtn, v_u_27.legend, v_u_39 and "primary" or "secondary", function()
				-- upvalues: (ref) v_u_39, (ref) v_u_215
				v_u_39 = not v_u_39
				v_u_215()
			end)
			v_u_484:SetAttribute("Open", v_u_39)
			v_u_484:SetAttribute("FocusId", "legend")
			local function v485()
				-- upvalues: (copy) v_u_484, (ref) v_u_19
				v_u_484.SelectionImageObject = v_u_19.selectionImage()
			end
			pcall(v485)
		end
		v_u_300(v478.help)
		local v486 = v_u_24.bar(v_u_31, v_u_35)
		v_u_267(v_u_54, v478.bar, v478.chips, v486)
		v_u_273(v_u_54, v478.note, v486.note)
		v_u_146(v_u_54, "SheetButton", v478.sheetBtn, v_u_27.sheet, "secondary", function()
			-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_215
			v_u_37 = not v_u_37
			v_u_38 = false
			v_u_215()
		end)
		local _, v487 = v_u_210(v_u_35)
		local v488 = v478.ladderLayout
		local v489 = v_u_19.new("ScrollingFrame", {
			["Name"] = "Ladder",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["ScrollBarThickness"] = v_u_20.scrollBar,
			["ScrollBarImageColor3"] = v_u_21.lineStrong,
			["CanvasSize"] = UDim2.fromOffset(0, v488.height + 8 + (not v_u_40 and 0 or v478.sheetPad)),
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, v_u_54)
		local v490 = v478.ladder
		v489.Position = UDim2.fromOffset(v490.x, v490.y)
		v489.Size = UDim2.fromOffset(v490.w, v490.h)
		v489.CanvasPosition = Vector2.new(0, v_u_50["B" .. v_u_35] or 0)
		local v491 = {}
		if v478.legendOpen then
			v_u_315(v489, 0, 0, v_u_24.legend(v478.contentW, v_u_114()))
			if v478.legendNote then
				v_u_273(v489, v478.legendNote, v486.note)
			end
		end
		local v492 = (v_u_31.tiers or {})[v_u_35] or {}
		for v493, v494 in v488.tiers do
			local v495 = v492[v493] or {
				["gate"] = 0,
				["have"] = 0,
				["open"] = true
			}
			local v496 = v_u_24.tierHeader(v_u_35, v493, v495)
			local v497 = ""
			for _, v498 in v487[v493] or {} do
				if not v498.choice then
					continue
				end
				v497 = "  \194\183  pick one of two"
			end
			local v499 = "TierHead_" .. v493
			local v500 = v494.head
			local v501 = v_u_21.bg
			local v502 = v_u_19.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.4,
				["BorderSizePixel"] = 0,
				["Name"] = v499,
				["BackgroundColor3"] = v501 or v_u_21.raised
			}, v489)
			v502.Position = UDim2.fromOffset(v500.x, v500.y)
			v502.Size = UDim2.fromOffset(v500.w, v500.h)
			local v503 = v_u_22.tierHeadInner(v494.head.w)
			local v504 = v_u_80
			local v505 = v496.open and "check" or "lock"
			local v506 = {
				["size"] = 14,
				["color"] = nil
			}
			local v507
			if v496.open then
				v507 = v_u_21.success
			else
				v507 = v_u_21.text2
			end
			v506.color = v507
			local v508 = v504(v505, v506)
			v508.Position = UDim2.fromOffset(v503.icon.x, v503.icon.y)
			v508.Parent = v502
			local v509 = v_u_131
			local v510 = "Text"
			local v511 = v496.text .. v497
			local v512 = v503.text
			local v513
			if v496.open then
				v513 = v_u_21.text2
			else
				v513 = v_u_21.text
			end
			v509(v502, v510, v511, v512, v513)
			if v503.bar and v496.gate > 0 then
				local v514 = v503.bar
				local v515 = v_u_21.line
				local v516 = v_u_19.new("Frame", {
					["Name"] = "Prog",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = v515 or v_u_21.raised
				}, v502)
				v516.Position = UDim2.fromOffset(v514.x, v514.y)
				v516.Size = UDim2.fromOffset(v514.w, v514.h)
				local v517 = {
					["x"] = v503.bar.x,
					["y"] = v503.bar.y
				}
				local v518 = v503.bar.w * v496.frac
				v517.w = math.floor(v518)
				v517.h = v503.bar.h
				local v519 = v_u_21.accent
				local v520 = v_u_19.new("Frame", {
					["Name"] = "ProgFill",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0,
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = v519 or v_u_21.raised
				}, v502)
				v520.Position = UDim2.fromOffset(v517.x, v517.y)
				v520.Size = UDim2.fromOffset(v517.w, v517.h)
			end
			for v521, v_u_522 in v487[v493] or {} do
				local v523 = v494.nodes[v521]
				if not v523 then
					continue
				end
				v491[v_u_522.id] = v523
				local v524 = v_u_24.nodeState(v_u_522, v_u_31)
				local v525 = v_u_64[v524.bg] or v_u_21.text
				local v526 = v524.bgA
				local v527 = v_u_64[v524.edge] or v_u_21.text
				local v528 = v524.edgeA
				local v529 = v524.icon
				local v530 = v_u_64[v524.iconColor] or v_u_21.text
				local v_u_531 = v_u_19.new("TextButton", {
					["Name"] = nil,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Name"] = "Node_" .. v_u_522.id,
					["BackgroundColor3"] = v525,
					["BackgroundTransparency"] = v526
				}, v489)
				v_u_531.Position = UDim2.fromOffset(v523.x, v523.y)
				v_u_531.Size = UDim2.fromOffset(v523.w, v523.h)
				local v532 = v_u_522.id == v_u_36
				local v533 = v_u_19.stroke
				local v534
				if v532 then
					v534 = v_u_21.accent
				else
					v534 = v527
				end
				local v535 = v533(v_u_531, v534, v532 and 2 or (v524.thick or 1), v532 and 0 or v528)
				v_u_531:SetAttribute("FocusId", "node:" .. v_u_522.id)
				local function v536()
					-- upvalues: (copy) v_u_531, (ref) v_u_19
					v_u_531.SelectionImageObject = v_u_19.selectionImage()
				end
				pcall(v536)
				v_u_531:SetAttribute("NodeId", v_u_522.id)
				v_u_531:SetAttribute("State", v_u_522.state)
				v_u_531:SetAttribute("Kind", v524.kind)
				v_u_47[v_u_522.id] = {
					["btn"] = v_u_531,
					["stroke"] = v535,
					["edge"] = v527,
					["edgeA"] = v528,
					["thick"] = v524.thick
				}
				local v537 = v_u_22.nodeInner(v523.w)
				if v529 then
					local v538 = v_u_80(v529, {
						["size"] = 20,
						["color"] = nil,
						["color"] = v530
					})
					v538.Position = UDim2.fromOffset(v537.icon.x, v537.icon.y)
					v538.Parent = v_u_531
				end
				if v524.lock then
					local v539 = v_u_80(v524.lock, {
						["size"] = 14,
						["color"] = nil,
						["color"] = v_u_21.text2
					})
					v539.Position = UDim2.fromOffset(v537.lock.x, v537.lock.y)
					v539.Parent = v_u_531
				end
				local v540, v541 = v_u_22.statusLine(v_u_522)
				local v542 = v_u_110
				local v543 = "Name"
				local v544 = v_u_522.name
				local v545 = v537.name
				local v546 = "bodyStrong"
				local v547
				if v524.kind == "locked" then
					v547 = v_u_21.text2
				else
					v547 = v_u_21.text
				end
				v542(v_u_531, v543, v544, v545, v546, v547)
				local v548 = v_u_131
				local v549 = "Line"
				local v550 = v537.line
				local v551
				if v541 == "ready" then
					v551 = v_u_21.accent
				elseif v541 == "fresh" then
					v551 = v_u_21.success
				elseif v541 == "blocked" then
					v551 = v_u_21.danger
				else
					v551 = v_u_21.text2
				end
				v548(v_u_531, v549, v540, v550, v551)
				if v524.kind == "available" then
					local v552
					if v_u_31 == nil or v_u_31.canChange ~= true then
						v552 = false
					else
						v552 = v_u_31.on ~= false
					end
					if v552 and not v532 then
						v_u_197(v535)
					end
				end
				v_u_531.Activated:Connect(function()
					-- upvalues: (ref) v_u_229, (copy) v_u_522
					v_u_229(v_u_522.id)
				end)
				local v_u_553 = v_u_522.id
				local v554
				if v_u_25 then
					local v555 = v_u_25.guiInputBegan
					if type(v555) == "function" then
						v554 = v_u_25.guiInputBegan(v_u_531)
					else
						v554 = v_u_531.InputBegan
					end
				else
					v554 = v_u_531.InputBegan
				end
				v554:Connect(function(p556)
					-- upvalues: (ref) v_u_229, (copy) v_u_553, (ref) v_u_31, (ref) v_u_22, (ref) v_u_187, (ref) v_u_49, (ref) v_u_222
					if p556.KeyCode == Enum.KeyCode.ButtonA then
						v_u_229(v_u_553)
						local v557 = v_u_553
						local v559
						if v_u_31 and v557 then
							for _, v559 in v_u_31.nodes or {} do
								if v559.id ~= v557 then
									continue
								end
							end
							v559 = nil
						else
							v559 = nil
						end
						if v_u_22.detail(v559, v_u_31).learnOn then
							local v560 = v559.rank
							local v561 = tonumber(v560) or 0
							local v_u_562 = math.floor(v561)
							v_u_187(v_u_49, function()
								-- upvalues: (ref) v_u_222, (ref) v_u_553, (copy) v_u_562
								v_u_222("learn", v_u_553, v_u_562)
							end)
						end
					end
				end)
			end
		end
		if v478.mode ~= "sheet" or v_u_40 then
			v_u_48 = v_u_88(v_u_54, "Detail", v478.detail, v_u_21.bg, 0, v_u_21.line)
			v_u_48.Active = true
			v_u_216()
		end
		if v_u_41 and (v_u_36 and v491[v_u_36]) then
			v_u_41 = false
			local v563 = v478.detail.y - v478.ladder.y
			if v478.mode == "sheet" and v_u_22.NODE_H + 8 <= v563 then
				local v564 = v491[v_u_36]
				local v565 = v_u_50["B" .. v_u_35] or 0
				if v564.y < v565 then
					v565 = v564.y - 4
				elseif v564.y + v564.h > v565 + v563 then
					v565 = v564.y + v564.h - v563 + 4
				end
				v489.CanvasPosition = Vector2.new(0, (math.max(0, v565)))
			end
		end
	end
	local function v_u_670(p567) -- name: buildF
		-- upvalues: (copy) v_u_146, (copy) v_u_54, (copy) v_u_27, (copy) v_u_28, (copy) v_u_110, (copy) v_u_21, (copy) v_u_300, (copy) v_u_24, (ref) v_u_31, (copy) v_u_267, (copy) v_u_88, (copy) v_u_80, (copy) v_u_131, (copy) v_u_22, (copy) v_u_114, (copy) v_u_19, (copy) v_u_20, (copy) v_u_50, (copy) v_u_158, (copy) v_u_189, (copy) v_u_222, (copy) v_u_25, (copy) v_u_187
		local v568 = p567.F
		v_u_146(v_u_54, "BackButton", v568.back, v_u_27.back, "secondary", function()
			-- upvalues: (ref) v_u_28
			v_u_28.onBack()
		end)
		v_u_110(v_u_54, "FlawsName", v_u_27.flaws, v568.title, "h3", v_u_21.accent)
		v_u_300(v568.help)
		local v569 = v_u_24.bar(v_u_31, nil)
		v_u_267(v_u_54, v568.bar, v568.chips, v569)
		local v570 = v_u_31.flawSlots or {}
		local v571 = v_u_110
		local v572 = v_u_54
		local v573 = v570.used
		local v574 = tonumber(v573) or 0
		local v575 = math.floor(v574)
		local v576 = v570.max
		local v577 = tonumber(v576) or 0
		v571(v572, "SlotsText", ("%d of %d slots used"):format(v575, (math.floor(v577))), v568.free, "small", v_u_21.text, "right")
		local v578 = v_u_24.flawGive(v_u_31)
		local v579 = {}
		for _, v580 in v_u_31.flaws or {} do
			if not v580.active then
				continue
			end
			table.insert(v579, v580)
		end
		local v581 = v570.at or { 5, 15, 25 }
		for v582, v583 in v568.slots do
			local v584 = v579[v582]
			local v585 = v570.max
			local v586 = v582 <= (tonumber(v585) or 0)
			local v587 = v_u_88
			local v588 = v_u_54
			local v589 = "Slot_" .. v582
			local v590
			if v584 then
				v590 = v_u_21.dangerDeep
			else
				v590 = v_u_21.raised
			end
			local v591 = 0.15
			local v592
			if v584 then
				v592 = v_u_21.danger
			else
				v592 = v_u_21.line
			end
			local v593 = v587(v588, v589, v583, v590, v591, v592)
			local v594 = v584 and "warning" or (v586 and "plus" or "lock")
			local v595 = v_u_80
			local v596 = {
				["size"] = 18,
				["color"] = nil
			}
			local v597
			if v584 then
				v597 = v_u_21.danger
			elseif v586 then
				v597 = v_u_21.text2
			else
				v597 = v_u_21.muted
			end
			v596.color = v597
			local v598 = v595(v594, v596)
			local v599 = UDim2.fromOffset
			local v600 = (v583.h - 18) / 2
			v598.Position = v599(8, (math.floor(v600)))
			v598.Parent = v593
			local v601
			if v584 then
				v601 = v584.name
			elseif v586 then
				v601 = v_u_27.slotFree
			else
				local v602 = v581[v582]
				v601 = ("FIELD LEVEL %d"):format(tonumber(v602) or 5)
			end
			if v584 then
				v_u_110(v593, "Text", v601, {
					["x"] = 32,
					["y"] = 3,
					["w"] = nil,
					["h"] = 18,
					["w"] = v583.w - 40
				}, "small", v_u_21.text)
				local v603 = v_u_131
				local v604 = v584.id
				v603(v593, "Bonus", ("+%d %s"):format(v578[tostring(v604)] or 0, v_u_24.BRANCH_NAME[v584.branch] or ""), {
					["x"] = 32,
					["y"] = 21,
					["w"] = nil,
					["h"] = 19,
					["w"] = v583.w - 40
				}, v_u_21.info)
			else
				local v605 = v_u_110
				local v606 = v593
				local v607 = "Text"
				local v608 = {
					["x"] = 32,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v583.w - 40,
					["h"] = v583.h
				}
				local v609 = "small"
				local v610
				if v586 then
					v610 = v_u_21.text
				else
					v610 = v_u_21.text2
				end
				v605(v606, v607, v601, v608, v609, v610)
			end
		end
		v_u_88(v_u_54, "NoteBacking", v568.note, v_u_21.bg, 0.2, v_u_21.line)
		v_u_131(v_u_54, "Note", v_u_27.flawNote, {
			["x"] = v568.note.x + 8,
			["y"] = v568.note.y + 2,
			["w"] = v568.note.w - 16,
			["h"] = v568.note.h - 4
		}, v_u_21.text, v568.note.h > v_u_22.lineH(v_u_114()) + 4)
		local v611 = {}
		for v612, v613 in v_u_31.flaws or {} do
			table.insert(v611, {
				["f"] = v613,
				["i"] = v612
			})
		end
		table.sort(v611, function(p614, p615)
			if p614.f.active == p615.f.active then
				return p614.i < p615.i
			else
				return p614.f.active == true
			end
		end)
		for v616, v617 in v611 do
			v611[v616] = v617.f
		end
		local v618 = v_u_19.new
		local v619 = {
			["Name"] = "FlawList",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["ScrollBarThickness"] = v_u_20.scrollBar,
			["ScrollBarImageColor3"] = v_u_21.lineStrong
		}
		local v620 = UDim2.fromOffset
		local v621 = v_u_22.flawCards
		local v622 = v568.contentW
		local v623 = #v611
		local v624 = {
			["touch"] = v_u_20.isTouch()
		}
		local v_u_625 = 1
		local function v626()
			-- upvalues: (ref) v_u_625, (ref) v_u_20
			v_u_625 = v_u_20.uiScale()
		end
		pcall(v626)
		v624.scale = v_u_625
		v619.CanvasSize = v620(0, v621(v622, v623, v624).height + 8)
		v619.ScrollingDirection = Enum.ScrollingDirection.Y
		v619.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
		local v627 = v618("ScrollingFrame", v619, v_u_54)
		local v628 = v568.list
		v627.Position = UDim2.fromOffset(v628.x, v628.y)
		v627.Size = UDim2.fromOffset(v628.w, v628.h)
		v627.CanvasPosition = Vector2.new(0, v_u_50.F or 0)
		local v629 = v_u_22.flawCards
		local v630 = v568.contentW
		local v631 = #v611
		local v632 = {
			["touch"] = v_u_20.isTouch()
		}
		local v_u_633 = 1
		local function v634()
			-- upvalues: (ref) v_u_633, (ref) v_u_20
			v_u_633 = v_u_20.uiScale()
		end
		pcall(v634)
		v632.scale = v_u_633
		local v635 = v629(v630, v631, v632)
		for v636, v637 in v611 do
			local v638 = v635.rects[v636]
			if not v638 then
				continue
			end
			local v639 = v_u_88
			local v640 = "Flaw_" .. v637.id
			local v641
			if v637.active then
				v641 = v_u_21.dangerDeep
			else
				v641 = v_u_21.raised
			end
			local v642 = 0.15
			local v643
			if v637.active then
				v643 = v_u_21.danger
			else
				v643 = v_u_21.line
			end
			local v644 = v639(v627, v640, v638, v641, v642, v643)
			v_u_19.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["track"] = false,
				["size"] = nil,
				["position"] = nil,
				["parent"] = v644,
				["text"] = v637.name,
				["color"] = v_u_21.text,
				["size"] = UDim2.fromOffset(v635.name.w, v635.name.h),
				["position"] = UDim2.fromOffset(v635.name.x, v635.name.y)
			}):SetAttribute("FlawTitle", true)
			if v637.value and v637.value ~= "" then
				v_u_131(v644, "Effect", v_u_22.valueWords(v637.value), v635.effect, v_u_21.accent, true)
			end
			local v645 = v_u_131
			local v646 = v637.text or ""
			v645(v644, "Text", tostring(v646), v635.desc, v_u_21.text2, true)
			local v647 = v_u_24.flawLines(v637, v_u_31, v578)
			local v648 = v_u_80("info", {
				["size"] = 14,
				["color"] = nil,
				["color"] = v_u_21.info
			})
			v648.Position = UDim2.fromOffset(v635.meta1.x, v635.meta1.y + 2)
			v648.Parent = v644
			v_u_131(v644, "Meta", v647.line1, {
				["x"] = v635.meta1.x + 18,
				["y"] = v635.meta1.y,
				["w"] = v635.meta1.w - 18,
				["h"] = v635.meta1.h
			}, v_u_21.info)
			local v649 = v635.meta2.x
			if v647.kind2 == "bad" then
				local v650 = v_u_80("warning", {
					["size"] = 14,
					["color"] = nil,
					["color"] = v_u_21.danger
				})
				v650.Position = UDim2.fromOffset(v635.meta2.x, v635.meta2.y + 2)
				v650.Parent = v644
				v649 = v649 + 18
			end
			local v651 = v_u_131
			local v652 = "Meta2"
			local v653 = v647.line2
			local v654 = {
				["x"] = v649,
				["y"] = v635.meta2.y,
				["w"] = v635.meta2.w - (v649 - v635.meta2.x),
				["h"] = v635.meta2.h
			}
			local v655
			if v647.kind2 == "bad" then
				v655 = v_u_21.danger
			else
				v655 = v_u_21.text2
			end
			v651(v644, v652, v653, v654, v655, true):SetAttribute("Kind", v647.kind2)
			local v656
			if v637.active then
				v656 = v_u_27.drop
			else
				v656 = v_u_27.take
			end
			local v_u_657
			if v_u_31 == nil or v_u_31.canChange ~= true then
				v_u_657 = false
			else
				v_u_657 = v_u_31.on ~= false
			end
			if v_u_657 then
				if v637.active then
					v_u_657 = v637.canDrop == true
				else
					v_u_657 = v637.canTake == true
				end
			end
			local v_u_658, v659 = v_u_146(v644, "FlawButton", v635.btn, v656, v637.active and "secondary" or "danger", nil)
			v_u_658:SetAttribute("FocusId", "flaw:" .. v637.id)
			local function v660()
				-- upvalues: (copy) v_u_658, (ref) v_u_19
				v_u_658.SelectionImageObject = v_u_19.selectionImage()
			end
			pcall(v660)
			if not v_u_657 then
				v_u_158(v_u_658, v659, v656)
			end
			local v_u_661 = v_u_189(v_u_658)
			local v_u_662 = v637.id
			local v_u_663 = v637.active and "unflaw" or "flaw"
			local v_u_664 = v637.active and 1 or 0
			local function v_u_665()
				-- upvalues: (copy) v_u_657
				return v_u_657
			end
			local function v_u_666()
				-- upvalues: (ref) v_u_222, (copy) v_u_663, (copy) v_u_662, (copy) v_u_664
				v_u_222(v_u_663, v_u_662, v_u_664)
			end
			local v667
			if v_u_25 then
				local v668 = v_u_25.guiInputBegan
				if type(v668) == "function" then
					v667 = v_u_25.guiInputBegan(v_u_658)
				else
					v667 = v_u_658.InputBegan
				end
			else
				v667 = v_u_658.InputBegan
			end
			v667:Connect(function(p669)
				-- upvalues: (copy) v_u_665, (ref) v_u_187, (copy) v_u_661, (copy) v_u_666
				if ((p669.UserInputType == Enum.UserInputType.MouseButton1 or p669.UserInputType == Enum.UserInputType.Touch) and true or p669.KeyCode == Enum.KeyCode.ButtonA) and v_u_665() then
					v_u_187(v_u_661, v_u_666)
				end
			end)
		end
	end
	local function v_u_701(p671) -- name: buildS
		-- upvalues: (copy) v_u_88, (copy) v_u_54, (copy) v_u_21, (copy) v_u_110, (copy) v_u_27, (copy) v_u_146, (copy) v_u_28, (ref) v_u_31, (copy) v_u_22, (copy) v_u_19, (copy) v_u_20, (copy) v_u_50
		local v_u_672 = p671.S
		local v673 = v_u_88(v_u_54, "Sheet", v_u_672.panel, v_u_21.bg, 0.02, v_u_21.lineStrong)
		v_u_110(v673, "Title", v_u_27.sheetTitle, v_u_672.title, "h3", v_u_21.accent)
		v_u_146(v673, "CloseButton", v_u_672.close, "CLOSE", "secondary", function()
			-- upvalues: (ref) v_u_28
			v_u_28.onBack()
		end)
		local v674 = v_u_31.sheet or {}
		local v_u_675 = v_u_22.SHEET_ROW_H
		local v_u_676 = v_u_19.new("ScrollingFrame", {
			["Name"] = "SheetList",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["ScrollBarThickness"] = v_u_20.scrollBar,
			["ScrollBarImageColor3"] = v_u_21.lineStrong,
			["CanvasSize"] = UDim2.fromOffset(0, (#v674 + 1) * v_u_675 + 8),
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, v673)
		local v677 = v_u_672.list
		v_u_676.Position = UDim2.fromOffset(v677.x, v677.y)
		v_u_676.Size = UDim2.fromOffset(v677.w, v677.h)
		v_u_676.CanvasPosition = Vector2.new(0, v_u_50.S or 0)
		if #v674 == 0 then
			v_u_19.label({
				["parent"] = nil,
				["name"] = "Empty",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["track"] = false,
				["size"] = nil,
				["position"] = nil,
				["parent"] = v_u_676,
				["text"] = v_u_27.sheetEmpty,
				["color"] = v_u_21.text2,
				["size"] = UDim2.new(1, -16, 0, 40),
				["position"] = UDim2.fromOffset(8, 8)
			})
		else
			local v_u_678 = v_u_672.row
			local function v691(p679, p680, p681, p682, p683, p684) -- name: row
				-- upvalues: (copy) v_u_675, (copy) v_u_676, (copy) v_u_672, (ref) v_u_21, (ref) v_u_19, (ref) v_u_110, (copy) v_u_678
				local v685 = (p679 - 1) * v_u_675
				if p679 % 2 == 0 then
					local v686 = v_u_676
					local v687 = "Stripe_" .. p679
					local v688 = {
						["x"] = 0,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["y"] = v685,
						["w"] = v_u_672.row.source.x + v_u_672.row.source.w + 8,
						["h"] = v_u_675
					}
					local v689 = v_u_21.raised
					local v690 = v_u_19.new("Frame", {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.6,
						["BorderSizePixel"] = 0,
						["Name"] = v687,
						["BackgroundColor3"] = v689 or v_u_21.raised
					}, v686)
					v690.Position = UDim2.fromOffset(v688.x, v688.y)
					v690.Size = UDim2.fromOffset(v688.w, v688.h)
				end
				v_u_110(v_u_676, "Stat_" .. p679, p680, {
					["x"] = v_u_678.label.x,
					["y"] = v685,
					["w"] = v_u_678.label.w,
					["h"] = v_u_675
				}, p684, p683)
				v_u_110(v_u_676, "Value_" .. p679, p681, {
					["x"] = v_u_678.value.x,
					["y"] = v685,
					["w"] = v_u_678.value.w,
					["h"] = v_u_675
				}, p684, v_u_21.accent, "right")
				v_u_110(v_u_676, "Source_" .. p679, p682, {
					["x"] = v_u_678.source.x,
					["y"] = v685,
					["w"] = v_u_678.source.w,
					["h"] = v_u_675
				}, p684, v_u_21.text2)
			end
			v691(1, "STAT", "VALUE", "SOURCE", v_u_21.muted, "micro")
			for v692, v693 in v674 do
				local v694 = v693.source or ""
				local v695 = tostring(v694)
				if v693.cap then
					local v696 = v693.cap
					v695 = v695 .. "  \194\183  " .. tostring(v696)
				end
				local v697 = v692 + 1
				local v698 = v693.label or v693.stat
				local v699 = tostring(v698)
				local v700 = v693.value or ""
				v691(v697, v699, tostring(v700), v695, v_u_21.text, "small")
			end
		end
	end
	local function v_u_714(p702) -- name: buildG
		-- upvalues: (copy) v_u_88, (copy) v_u_54, (copy) v_u_21, (copy) v_u_110, (copy) v_u_24, (copy) v_u_146, (copy) v_u_28, (copy) v_u_22, (copy) v_u_114, (copy) v_u_19, (copy) v_u_20, (copy) v_u_50, (copy) v_u_64, (copy) v_u_80, (copy) v_u_131, (copy) v_u_315
		local v703 = p702.G
		local v704 = v_u_88(v_u_54, "Guide", v703.panel, v_u_21.bg, 0.02, v_u_21.lineStrong)
		v_u_110(v704, "Title", v_u_24.TEXT.helpTitle, v703.title, "h3", v_u_21.accent)
		v_u_146(v704, "CloseButton", v703.close, "CLOSE", "secondary", function()
			-- upvalues: (ref) v_u_28
			v_u_28.onBack()
		end)
		local v705 = v703.list.w - v_u_22.SCROLL
		local v706 = v_u_24.guideRows(v705, v_u_114())
		local v707 = v_u_19.new("ScrollingFrame", {
			["Name"] = "GuideList",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["ScrollBarThickness"] = v_u_20.scrollBar,
			["ScrollBarImageColor3"] = v_u_21.lineStrong,
			["CanvasSize"] = UDim2.fromOffset(0, v706.height + 8),
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, v704)
		local v708 = v703.list
		v707.Position = UDim2.fromOffset(v708.x, v708.y)
		v707.Size = UDim2.fromOffset(v708.w, v708.h)
		v707.CanvasPosition = Vector2.new(0, v_u_50.G or 0)
		for _, v709 in v706.rows do
			local v710 = v709.section
			local v711 = v_u_64[v710.color] or v_u_21.text
			local v712
			if v710.icon then
				local v713 = v_u_80(v710.icon, {
					["size"] = 12,
					["color"] = nil,
					["color"] = v711
				})
				v713.Position = UDim2.fromOffset(8, v709.y + 2)
				v713.Parent = v707
				v712 = 24
			else
				v712 = 8
			end
			v_u_110(v707, "Head_" .. v710.id, v710.head, {
				["x"] = v712,
				["y"] = v709.y,
				["w"] = v705 - v712 - 8,
				["h"] = v709.headH
			}, "caps", v711, nil, nil, v_u_114())
			v_u_131(v707, "Text_" .. v710.id, v710.text, {
				["x"] = 8,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v709.textY,
				["w"] = v705 - 16,
				["h"] = v709.textH
			}, v_u_21.text, true)
		end
		v_u_131(v707, "LegendHead", "LEGEND", {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = 16,
			["y"] = v706.legendY,
			["w"] = v705 - 16
		}, v_u_21.text2)
		v_u_315(v707, 8, v706.legendY + 16, v706.legend)
	end
	local function v_u_719() -- name: saveScroll
		-- upvalues: (copy) v_u_54, (ref) v_u_35, (copy) v_u_50
		for _, v715 in v_u_54:GetChildren() do
			if v715:IsA("ScrollingFrame") then
				local v716
				if v715.Name == "Tiles" then
					v716 = "A"
				elseif v715.Name == "Ladder" then
					v716 = "B" .. v_u_35
				else
					v716 = v715.Name == "FlawList" and "F" or nil
				end
				if not v716 then
					continue
				end
				v_u_50[v716] = v715.CanvasPosition.Y
			elseif v715.Name == "Sheet" then
				local v717 = v715:FindFirstChild("SheetList")
				if not (v717 and v717:IsA("ScrollingFrame")) then
					continue
				end
				v_u_50.S = v717.CanvasPosition.Y
			else
				if v715.Name ~= "Guide" then
					continue
				end
				local v718 = v715:FindFirstChild("GuideList")
				if not (v718 and v718:IsA("ScrollingFrame")) then
					continue
				end
				v_u_50.G = v718.CanvasPosition.Y
			end
		end
	end
	local function v_u_734(p720) -- name: message
		-- upvalues: (copy) v_u_63, (copy) v_u_19, (copy) v_u_54, (copy) v_u_21
		local v721, v722 = v_u_63()
		local v723 = v_u_19.label
		local v724 = {
			["parent"] = nil,
			["name"] = "Message",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["align"] = "center",
			["valign"] = "center",
			["track"] = false,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_54,
			["text"] = p720,
			["color"] = v_u_21.text2
		}
		local v725 = UDim2.fromOffset
		local v726 = v721 - 40
		v724.size = v725(math.min(v726, 520), (math.min(v722, 120)))
		local v727 = UDim2.fromOffset
		local v728 = v721 - 40
		local v729 = (v721 - math.min(v728, 520)) / 2
		local v730 = math.floor(v729)
		local v731 = math.max(20, v730)
		local v732 = v722 - 120
		local v733 = math.max(0, v732) / 2
		v724.position = v727(v731, (math.floor(v733)))
		v723(v724)
	end
	v_u_215 = function()
		-- upvalues: (ref) v_u_29, (copy) v_u_28, (ref) v_u_34, (ref) v_u_4, (copy) v_u_54, (copy) v_u_719, (copy) v_u_179, (copy) v_u_177, (copy) v_u_47, (ref) v_u_48, (ref) v_u_49, (copy) v_u_63, (copy) v_u_19, (ref) v_u_38, (ref) v_u_37, (copy) v_u_22, (copy) v_u_55, (ref) v_u_31, (copy) v_u_734, (ref) v_u_32, (copy) p_u_17, (copy) v_u_27, (ref) v_u_52, (copy) v_u_210, (ref) v_u_35, (copy) v_u_20, (copy) v_u_24, (ref) v_u_39, (ref) v_u_40, (ref) v_u_51, (copy) v_u_714, (copy) v_u_701, (copy) v_u_566, (copy) v_u_670, (copy) v_u_413, (ref) v_u_30, (ref) v_u_36, (copy) v_u_26
		if v_u_29 then
			local v735 = v_u_28.onPage
			if type(v735) == "function" then
				local v736 = v_u_28.onPage
				local v737 = v_u_34
				pcall(v736, v737)
			end
			local v738 = v_u_4.SelectedObject
			local v739
			if v738 and v738:IsDescendantOf(v_u_54) then
				v739 = v738:GetAttribute("FocusId")
			else
				v739 = nil
			end
			v_u_719()
			v_u_179()
			v_u_177(v_u_54)
			table.clear(v_u_47)
			v_u_48 = nil
			v_u_49 = nil
			local v740, v741 = v_u_63()
			local v_u_742 = "Keyboard"
			local function v743()
				-- upvalues: (ref) v_u_742, (ref) v_u_19
				v_u_742 = v_u_19.device()
			end
			pcall(v743)
			local v744 = v_u_38 and "G" or (v_u_37 and "S" or v_u_34)
			local v745 = v_u_22.padHint(v_u_742, v744)
			local v746 = v745 and 16 or 0
			v_u_55.Visible = v745 ~= nil
			if v745 then
				v_u_55.Text = v745
			end
			local v747 = v_u_54
			local v748 = UDim2.fromOffset
			local v749 = v741 - v746
			v747.Size = v748(v740, (math.max(0, v749)))
			if v_u_31 == nil then
				local v750 = v_u_734
				local v751
				if v_u_32 then
					v751 = p_u_17.failText and p_u_17.failText("tree", v_u_27.unavailable) or v_u_27.unavailable
				else
					v751 = v_u_27.loading
				end
				v750(v751)
				v_u_52 = nil
				return
			else
				local v752 = v_u_22.offText(v_u_31)
				if v752 == nil then
					local v753 = v_u_210(v_u_35)
					local v_u_754 = 1
					local function v755()
						-- upvalues: (ref) v_u_754, (ref) v_u_20
						v_u_754 = v_u_20.uiScale()
					end
					pcall(v755)
					local v_u_756 = v740 * v_u_754
					local function v757()
						-- upvalues: (ref) v_u_756, (ref) v_u_20
						v_u_756 = v_u_20.viewport().X
					end
					pcall(v757)
					local v758 = v_u_24.bar
					local v759 = v_u_31
					local v760
					if v_u_34 == "B" then
						v760 = v_u_35
					else
						v760 = nil
					end
					local v761 = (v758(v759, v760).bonus or 0) > 0
					local v762 = v_u_22.compute
					local v763 = v741 - v746
					local v764 = {}
					local v_u_765 = 1
					local function v766()
						-- upvalues: (ref) v_u_765, (ref) v_u_20
						v_u_765 = v_u_20.uiScale()
					end
					pcall(v766)
					v764.scale = v_u_765
					v764.touch = v_u_20.isTouch()
					v764.realW = v_u_756
					v764.tiers = v753
					v764.flaws = #(v_u_31.flaws or {})
					v764.mastery = #(v_u_31.mastery or {})
					v764.banner = v_u_31.patchRefund == true
					v764.bonus = v761
					v764.legendOpen = v_u_39
					local v767 = v_u_24.legend
					local v768 = v740 - v_u_22.SCROLL
					local v769 = v_u_22.hintSize
					local v_u_770 = 1
					local function v771()
						-- upvalues: (ref) v_u_770, (ref) v_u_20
						v_u_770 = v_u_20.uiScale()
					end
					pcall(v771)
					v764.legendH = v767(v768, v769(v_u_770)).height + 4
					local v772 = v762(v740, v763, v764)
					v_u_52 = v772
					if v772.B and v772.B.mode ~= "sheet" then
						v_u_40 = false
					end
					v_u_51 = ("%dx%d"):format(v740, v741)
					if v_u_38 then
						v_u_714(v772)
					elseif v_u_37 then
						v_u_701(v772)
					elseif v_u_34 == "B" then
						v_u_566(v772)
					elseif v_u_34 == "F" then
						v_u_670(v772)
					else
						v_u_413(v772)
					end
					if v739 then
						for _, v_u_773 in v_u_54:GetDescendants() do
							if not v_u_773:IsA("GuiButton") or v_u_773:GetAttribute("FocusId") ~= v739 then
								continue
							end
							local function v774()
								-- upvalues: (ref) v_u_4, (copy) v_u_773
								v_u_4.SelectedObject = v_u_773
							end
							pcall(v774)
						end
					end
					if v_u_742 == "Gamepad" and (v739 == nil and v_u_30) then
						local v_u_775 = nil
						if v_u_34 == "B" and (not v_u_37 and (not v_u_38 and (v_u_36 and v_u_47[v_u_36]))) then
							v_u_775 = v_u_47[v_u_36].btn
						elseif v_u_34 == "A" and not v_u_37 then
							v_u_775 = v_u_54:FindFirstChild("Tile_gun", true)
						elseif v_u_34 == "F" and not v_u_37 then
							v_u_775 = v_u_54:FindFirstChild("FlawButton", true)
						end
						if v_u_775 then
							local function v776()
								-- upvalues: (ref) v_u_4, (ref) v_u_775
								v_u_4.SelectedObject = v_u_775
							end
							pcall(v776)
						end
					end
					if v_u_26 then
						local v777 = v_u_36
						v_u_26:SetAttribute("MenuTree", ("page=%s branch=%s sel=%s nodes=%d cols=%d on=%d sheet=%d guide=%d"):format(v_u_34, v_u_35, tostring(v777), #(v_u_31.nodes or {}), not v772.B and 0 or v772.B.cols, v_u_31.on and 1 or 0, v_u_37 and 1 or 0, v_u_38 and 1 or 0))
					end
				else
					v_u_734(v752)
					v_u_52 = nil
				end
			end
		else
			return
		end
	end
	function v_u_28.relayout() -- name: relayout
		-- upvalues: (ref) v_u_29, (ref) v_u_30, (copy) v_u_63, (ref) v_u_51, (ref) v_u_215
		if v_u_29 and v_u_30 then
			local v778, v779 = v_u_63()
			if ("%dx%d"):format(v778, v779) ~= v_u_51 then
				v_u_215()
			end
		end
	end
	function v_u_28.state() -- name: state
		-- upvalues: (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_40, (ref) v_u_39, (ref) v_u_31
		return {
			["page"] = v_u_34,
			["branch"] = v_u_35,
			["sel"] = v_u_36,
			["sheet"] = v_u_37,
			["guide"] = v_u_38,
			["detail"] = v_u_40,
			["legend"] = v_u_39,
			["view"] = v_u_31
		}
	end
	local v780 = v_u_53:GetPropertyChangedSignal("AbsoluteSize")
	table.insert(v_u_45, v780:Connect(function()
		-- upvalues: (copy) v_u_28
		v_u_28.relayout()
	end))
	if p_u_17.changed and p_u_17.changed.Connect then
		local v781 = p_u_17.changed
		local function v786(p782, p783)
			-- upvalues: (ref) v_u_42, (ref) v_u_31, (ref) v_u_32, (copy) p_u_17, (ref) v_u_215
			if p782 == "result" and (type(p783) == "table" and p783.op == "tree") then
				v_u_42 = false
				local v784 = p783.data
				if type(v784) == "table" then
					v_u_31 = p783.data
					v_u_32 = false
					local v785 = p_u_17.invalidate
					pcall(v785, "tree")
					v_u_215()
				end
			end
		end
		table.insert(v_u_45, v781:Connect(v786))
	end
	local v787
	if v_u_25 and v_u_25.InputBegan then
		v787 = v_u_25.InputBegan
	else
		v787 = v_u_3.InputBegan
	end
	local function v800(p788)
		-- upvalues: (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (copy) v_u_26, (ref) v_u_37, (ref) v_u_38, (ref) v_u_215, (ref) v_u_14, (ref) v_u_36, (ref) v_u_34, (copy) v_u_22, (copy) v_u_222, (ref) v_u_15, (ref) v_u_35, (ref) v_u_40, (copy) v_u_214
		if v_u_29 and (v_u_30 and v_u_31 ~= nil) then
			local v789 = v_u_26
			if v789 then
				v789 = v_u_26:FindFirstChildOfClass("PlayerGui")
			end
			if v789 then
				v789 = v789:FindFirstChild("HushModal")
			end
			if v789 and v789:FindFirstChild("Modal", true) then
				return
			else
				local v790 = p788.KeyCode
				if v790 == Enum.KeyCode.ButtonY then
					v_u_37 = not v_u_37
					v_u_38 = false
					v_u_215()
					return
				elseif v790 == Enum.KeyCode.ButtonL1 then
					v_u_38 = not v_u_38
					v_u_37 = false
					if v_u_38 then
						v_u_14 = true
					end
					v_u_215()
				elseif v790 == Enum.KeyCode.ButtonX then
					local v791 = v_u_36
					local v793
					if v_u_31 and v791 then
						for _, v793 in v_u_31.nodes or {} do
							if v793.id ~= v791 then
								continue
							end
						end
						v793 = nil
					else
						v793 = nil
					end
					if v_u_34 == "B" and (not v_u_37 and (v793 and v_u_22.detail(v793, v_u_31).undoOn)) then
						local v794 = v_u_222
						local v795 = v793.id
						local v796 = v793.rank
						local v797 = tonumber(v796) or 0
						v794("undo", v795, (math.floor(v797)))
						return
					end
				elseif v790 == Enum.KeyCode.ButtonL2 then
					if v_u_34 == "B" and not v_u_37 then
						if not v_u_38 then
							local v798 = v_u_15[((table.find(v_u_15, v_u_35) or 1) - 1 + -1) % #v_u_15 + 1]
							v_u_34 = "B"
							v_u_35 = v798
							v_u_37 = false
							v_u_38 = false
							v_u_40 = false
							v_u_36 = v_u_214(v798)
							v_u_215()
						end
					end
				elseif v790 == Enum.KeyCode.ButtonR2 and (v_u_34 == "B" and not v_u_37) then
					if v_u_38 then
						return
					end
					local v799 = v_u_15[((table.find(v_u_15, v_u_35) or 1) - 1 + 1) % #v_u_15 + 1]
					v_u_34 = "B"
					v_u_35 = v799
					v_u_37 = false
					v_u_38 = false
					v_u_40 = false
					v_u_36 = v_u_214(v799)
					v_u_215()
				end
			end
		else
			return
		end
	end
	table.insert(v_u_45, v787:Connect(v800))
	local v_u_801 = nil
	local function v802()
		-- upvalues: (ref) v_u_801, (copy) v_u_19, (ref) v_u_30, (ref) v_u_215
		v_u_801 = v_u_19.onDevice(function()
			-- upvalues: (ref) v_u_30, (ref) v_u_215
			if v_u_30 then
				v_u_215()
			end
		end)
	end
	pcall(v802)
	local function v_u_816(p803, p804) -- name: runCmd
		-- upvalues: (ref) v_u_36, (ref) v_u_31, (ref) v_u_34, (ref) v_u_35, (ref) v_u_37, (ref) v_u_38, (ref) v_u_40, (copy) v_u_214, (ref) v_u_215, (copy) v_u_28, (ref) v_u_14, (copy) v_u_229, (copy) v_u_22, (copy) v_u_222, (ref) v_u_33, (ref) v_u_29, (copy) p_u_17, (ref) v_u_32
		local v805 = v_u_36
		if v_u_31 and v805 then
			for _, v807 in v_u_31.nodes or {} do
				if v807.id ~= v805 then
					continue
				end
			end
		end
		local v807 = nil
		local v808
		if v807 then
			local v809 = v807.rank
			local v810 = tonumber(v809) or 0
			v808 = math.floor(v810)
		else
			v808 = 0
		end
		if p803 == "branch" and (p804 and p804 ~= "") then
			v_u_34 = "B"
			v_u_35 = p804
			v_u_37 = false
			v_u_38 = false
			v_u_40 = false
			v_u_36 = v_u_214(p804)
			v_u_215()
			return
		elseif p803 == "flaws" then
			v_u_34 = "F"
			v_u_37 = false
			v_u_38 = false
			v_u_215()
			return
		elseif p803 == "back" then
			v_u_28.onBack()
			return
		elseif p803 == "sheet" then
			v_u_37 = not v_u_37
			v_u_38 = false
			v_u_215()
			return
		elseif p803 == "guide" then
			v_u_38 = not v_u_38
			v_u_37 = false
			if v_u_38 then
				v_u_14 = true
			end
			v_u_215()
			return
		elseif p803 == "select" and (p804 and p804 ~= "") then
			v_u_229(p804)
			return
		elseif p803 == "learn" and (v807 and v_u_22.detail(v807, v_u_31).learnOn) then
			v_u_222("learn", v807.id, v808)
			return
		elseif p803 == "undo" and (v807 and v_u_22.detail(v807, v_u_31).undoOn) then
			v_u_222("undo", v807.id, v808)
			return
		elseif p803 == "unlearn" and (v807 and v_u_22.detail(v807, v_u_31).unlearnOn) then
			v_u_222("unlearn", v807.id, v808)
			return
		elseif (p803 == "take" or p803 == "drop") and (p804 and p804 ~= "") then
			for _, v811 in v_u_31 and v_u_31.flaws or {} do
				if v811.id ~= p804 or (p803 ~= "take" or v811.canTake ~= true) and (p803 ~= "drop" or v811.canDrop ~= true) then
					continue
				end
				v_u_222(p803 == "take" and "flaw" or "unflaw", p804, p803 == "take" and 0 or 1)
			end
		elseif p803 == "refresh" and not v_u_33 then
			if not v_u_29 then
				return
			end
			v_u_33 = true
			local v_u_812 = true
			task.spawn(function()
				-- upvalues: (ref) p_u_17, (copy) v_u_812, (ref) v_u_33, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_215
				local function v813()
					-- upvalues: (ref) p_u_17, (ref) v_u_812
					return p_u_17.fetch("tree", nil, v_u_812 and 0 or 6)
				end
				local v814, v815 = pcall(v813)
				v_u_33 = false
				if v_u_29 then
					if v814 and type(v815) == "table" then
						v_u_31 = v815
						v_u_32 = false
					elseif v_u_31 == nil then
						v_u_32 = true
					end
					v_u_215()
				end
			end)
		end
	end
	v_u_28.cmd = v_u_816
	if v_u_2:IsStudio() and v_u_26 then
		local v817 = v_u_26:GetAttributeChangedSignal("MenuTreeCmd")
		table.insert(v_u_45, v817:Connect(function()
			-- upvalues: (copy) v_u_26, (copy) v_u_816
			local v818 = v_u_26:GetAttribute("MenuTreeCmd")
			if type(v818) == "string" and v818 ~= "" then
				v_u_26:SetAttribute("MenuTreeCmd", nil)
				local v819, v820 = string.match(v818, "^(%a+)%s*(%S*)$")
				if v819 then
					v_u_816(v819, v820)
				end
			end
		end))
	end
	function v_u_28.show() -- name: show
		-- upvalues: (ref) v_u_30, (ref) v_u_215, (ref) v_u_33, (ref) v_u_29, (copy) p_u_17, (ref) v_u_31, (ref) v_u_32
		v_u_30 = true
		v_u_215()
		if not v_u_33 then
			if not v_u_29 then
				return
			end
			v_u_33 = true
			local v_u_821 = true
			task.spawn(function()
				-- upvalues: (ref) p_u_17, (copy) v_u_821, (ref) v_u_33, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_215
				local function v822()
					-- upvalues: (ref) p_u_17, (ref) v_u_821
					return p_u_17.fetch("tree", nil, v_u_821 and 0 or 6)
				end
				local v823, v824 = pcall(v822)
				v_u_33 = false
				if v_u_29 then
					if v823 and type(v824) == "table" then
						v_u_31 = v824
						v_u_32 = false
					elseif v_u_31 == nil then
						v_u_32 = true
					end
					v_u_215()
				end
			end)
		end
	end
	function v_u_28.hide() -- name: hide
		-- upvalues: (ref) v_u_30, (copy) v_u_179
		v_u_30 = false
		v_u_179()
	end
	function v_u_28.refresh(p825) -- name: refresh
		-- upvalues: (ref) v_u_30, (copy) p_u_17, (ref) v_u_33, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_215
		if v_u_30 and (p825 == nil or p825 == "profile") then
			local v826 = p_u_17.invalidate
			pcall(v826, "tree")
			if not v_u_33 then
				if not v_u_29 then
					return
				end
				v_u_33 = true
				local v_u_827 = false
				task.spawn(function()
					-- upvalues: (ref) p_u_17, (copy) v_u_827, (ref) v_u_33, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_215
					local function v828()
						-- upvalues: (ref) p_u_17, (ref) v_u_827
						return p_u_17.fetch("tree", nil, v_u_827 and 0 or 6)
					end
					local v829, v830 = pcall(v828)
					v_u_33 = false
					if v_u_29 then
						if v829 and type(v830) == "table" then
							v_u_31 = v830
							v_u_32 = false
						elseif v_u_31 == nil then
							v_u_32 = true
						end
						v_u_215()
					end
				end)
			end
		end
	end
	function v_u_28.destroy() -- name: destroy
		-- upvalues: (ref) v_u_29, (ref) v_u_30, (copy) v_u_179, (copy) v_u_45, (ref) v_u_801, (copy) v_u_177, (copy) v_u_54, (copy) v_u_53
		v_u_29 = false
		v_u_30 = false
		v_u_179()
		for _, v_u_831 in v_u_45 do
			pcall(function()
				-- upvalues: (copy) v_u_831
				v_u_831:Disconnect()
			end)
		end
		table.clear(v_u_45)
		local v832 = v_u_801
		if type(v832) == "function" then
			local v833 = v_u_801
			pcall(v833)
		end
		v_u_177(v_u_54)
		v_u_53:Destroy()
	end
	v_u_215()
	return v_u_28
end
v6.mount = v6.new
return v6