-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIPad

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("VirtualPad"))
local v_u_5 = {}
local v_u_6 = v1.LocalPlayer
local v_u_7 = Enum.KeyCode
local v_u_8 = {
	[v_u_7.DPadUp] = Vector2.new(0, -1),
	[v_u_7.DPadDown] = Vector2.new(0, 1),
	[v_u_7.DPadLeft] = Vector2.new(-1, 0),
	[v_u_7.DPadRight] = Vector2.new(1, 0)
}
local v_u_9 = {
	[v_u_7.ButtonR1] = {
		["kind"] = "box",
		["dir"] = 1
	},
	[v_u_7.ButtonL1] = {
		["kind"] = "box",
		["dir"] = -1
	},
	[v_u_7.ButtonR2] = {
		["kind"] = "side",
		["dir"] = 1
	},
	[v_u_7.ButtonL2] = {
		["kind"] = "side",
		["dir"] = -1
	}
}
local v_u_10 = nil
local v_u_11 = {
	["started"] = false,
	["setOn"] = nil,
	["setAt"] = 0,
	["dir"] = nil,
	["heldAt"] = 0,
	["nextAt"] = 0,
	["steps"] = 0,
	["jumps"] = 0,
	["last"] = "",
	["tipShown"] = false,
	["marked"] = nil,
	["lastIn"] = nil,
	["marked"] = setmetatable({}, {
		["__mode"] = "k"
	}),
	["lastIn"] = setmetatable({}, {
		["__mode"] = "k"
	})
}
local v_u_12 = nil
local v_u_13 = nil
function v_u_5.selectable(p_u_14, p_u_15) -- name: selectable
	-- upvalues: (copy) v_u_11, (ref) v_u_12, (ref) v_u_13
	p_u_14.Selectable = true
	v_u_11.marked[p_u_14] = true
	v_u_12 = v_u_12 or p_u_15
	v_u_13()
	pcall(function()
		-- upvalues: (copy) p_u_14, (copy) p_u_15
		p_u_14.SelectionImageObject = p_u_15.selectionImage()
	end)
end
function v_u_5.active() -- name: active
	-- upvalues: (ref) v_u_10
	return v_u_10 ~= nil
end
function v_u_5.cursor() -- name: cursor
	-- upvalues: (ref) v_u_10
	if v_u_10 then
		return v_u_10.pos
	else
		return nil
	end
end
local function v_u_23(p16, p17) -- name: scrollerAt
	-- upvalues: (copy) v_u_4
	local v18 = p16.m
	if v18 then
		v18 = p16.m.root
	end
	if typeof(v18) ~= "Instance" then
		return nil
	end
	local v19 = nil
	for _, v20 in v18:GetDescendants() do
		if not (v20:IsA("ScrollingFrame") and v_u_4.shown(v20)) then
			continue
		end
		local v21 = v20.AbsolutePosition
		local v22 = v20.AbsolutePosition + v20.AbsoluteWindowSize
		if p17.X < v21.X or (p17.X > v22.X or (p17.Y < v21.Y or p17.Y > v22.Y)) then
			continue
		end
		v19 = v20
	end
	return v19
end
local function v_u_28(p24) -- name: bounds
	local v25 = p24.m
	if v25 then
		v25 = p24.m.root
	end
	if typeof(v25) == "Instance" and v25:IsA("GuiObject") then
		return v25.AbsolutePosition, v25.AbsolutePosition + v25.AbsoluteSize
	else
		local v26 = workspace.CurrentCamera
		local v27 = Vector2.zero
		if v26 then
			return v27, v26.ViewportSize
		else
			return v27, Vector2.new(1920, 1080)
		end
	end
end
local function v_u_33(p_u_29, p30) -- name: finish
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_4, (copy) v_u_2
	if v_u_10 == p_u_29 then
		v_u_10 = nil
		for _, v_u_31 in p_u_29.conns do
			pcall(function()
				-- upvalues: (copy) v_u_31
				v_u_31:Disconnect()
			end)
		end
		if p_u_29.hb then
			p_u_29.hb:Disconnect()
		end
		v_u_6:SetAttribute("PadFocusHold", nil)
		v_u_6:SetAttribute("InvUIPadMove", nil)
		if p30 then
			task.delay(0.15, function()
				-- upvalues: (ref) v_u_10, (copy) p_u_29, (ref) v_u_4, (ref) v_u_2
				if not v_u_10 then
					local _, v32 = p_u_29.api.tileOf(p_u_29.m, p_u_29.uid)
					if v32 and (v32.Parent and (v32.Selectable and v_u_4.shown(v32))) then
						v_u_2.SelectedObject = v32
					end
				end
			end)
		end
	end
end
local function v_u_62(p34, p35) -- name: step
	-- upvalues: (copy) v_u_33, (copy) v_u_23, (copy) v_u_28
	local v36 = p34.api.drag()
	if v36 and v36.uid == p34.uid then
		local v37 = p34.api.cell(p34.m)
		local v38 = p34.pos + p35 * v37
		local v39 = v_u_23(p34, p34.pos)
		if v39 then
			local v40 = v39.AbsolutePosition
			local v41 = v39.AbsolutePosition + v39.AbsoluteWindowSize
			local v42 = v39.AbsoluteCanvasSize.Y - v39.AbsoluteWindowSize.Y
			local v43 = math.max(0, v42)
			local v44 = v39.CanvasPosition
			if p35.Y > 0 and (v38.Y > v41.Y - v37 * 0.5 and v44.Y < v43 - 0.5) then
				local v45 = Vector2.new
				local v46 = v44.X
				local v47 = v44.Y + v37
				v39.CanvasPosition = v45(v46, (math.min(v43, v47)))
				v38 = p34.pos
			elseif p35.Y < 0 and (v38.Y < v40.Y + v37 * 0.5 and v44.Y > 0.5) then
				local v48 = Vector2.new
				local v49 = v44.X
				local v50 = v44.Y - v37
				v39.CanvasPosition = v48(v49, (math.max(0, v50)))
				v38 = p34.pos
			end
		end
		local v51, v52 = v_u_28(p34)
		local v53 = Vector2.new
		local v54 = v38.X
		local v55 = v51.X + 2
		local v56 = v52.X - 2
		local v57 = math.clamp(v54, v55, v56)
		local v58 = v38.Y
		local v59 = v51.Y + 2
		local v60 = v52.Y - 2
		local v61 = v53(v57, (math.clamp(v58, v59, v60)))
		p34.pos = v61
		p34.api.updateDrag(v61)
		p34.api.sound("tick")
	else
		v_u_33(p34, true)
	end
end
function v_u_5.begin(p_u_63, p_u_64, p_u_65) -- name: begin
	-- upvalues: (ref) v_u_10, (copy) v_u_33, (copy) v_u_2, (copy) v_u_6, (ref) v_u_12, (ref) v_u_13, (copy) v_u_4, (copy) v_u_8, (copy) v_u_62, (copy) v_u_9, (copy) v_u_5, (copy) v_u_7, (copy) v_u_3
	if v_u_10 then
		v_u_33(v_u_10, false)
	end
	if p_u_65.drag() then
		return
	else
		local v66, v67 = p_u_65.tileOf(p_u_63, p_u_64)
		if v67 then
			local v68 = v67:FindFirstAncestorOfClass("ScrollingFrame")
			if v68 then
				local v69 = v68.AbsolutePosition.Y
				local v70 = v68.AbsoluteWindowSize.Y
				local v71 = v67.AbsolutePosition.Y
				local v72 = v67.AbsoluteSize.Y
				local v73 = v68.AbsoluteCanvasSize.Y - v70
				local v74 = math.max(0, v73)
				if v71 < v69 or v71 + v72 > v69 + v70 then
					local v75 = v68.CanvasPosition
					local v76 = Vector2.new
					local v77 = v75.X
					local v78 = v75.Y + (v71 - v69) - (v70 - v72) * 0.5
					v68.CanvasPosition = v76(v77, (math.clamp(v78, 0, v74)))
				end
			end
			local v79 = v67.AbsolutePosition + v67.AbsoluteSize * 0.5
			v_u_2.SelectedObject = nil
			v_u_6:SetAttribute("PadFocusHold", true)
			v_u_6:SetAttribute("InvUIPadMove", p_u_64)
			p_u_65.beginDrag({
				["m"] = nil,
				["uid"] = nil,
				["tile"] = nil,
				["tileFrame"] = nil,
				["io"] = nil,
				["start"] = nil,
				["t"] = nil,
				["touch"] = false,
				["m"] = p_u_63,
				["uid"] = p_u_64,
				["tile"] = v66,
				["tileFrame"] = v67,
				["start"] = v79,
				["t"] = os.clock()
			}, v79)
			local v80 = p_u_65.drag()
			if v80 and v80.uid == p_u_64 then
				local v_u_81 = {
					["m"] = nil,
					["uid"] = nil,
					["api"] = nil,
					["pos"] = nil,
					["held"] = nil,
					["heldAt"] = 0,
					["nextAt"] = 0,
					["conns"] = nil,
					["hb"] = nil,
					["startedAt"] = nil,
					["m"] = p_u_63,
					["uid"] = p_u_64,
					["api"] = p_u_65,
					["pos"] = v79,
					["conns"] = {},
					["startedAt"] = os.clock()
				}
				v_u_10 = v_u_81
				local v82 = v_u_6:GetAttribute("Place") == "Menu" and "Side: LT / RT" or "Container: LB / RB"
				local v83 = p_u_65.toast
				local v84 = string.format
				local v85 = p_u_65.hint
				pcall(v83, v84("Move: D-Pad   %s   Place: A   Rotate: %s   Cancel: B", v82, v85("rotateItem")))
				local v86 = v_u_12
				if not v86 then
					if p_u_65 then
						v86 = p_u_65.hushUI
					else
						v86 = p_u_65
					end
				end
				v_u_12 = v86
				v_u_13()
				local v87 = v_u_81.conns
				local v88 = v_u_4.InputBegan
				local function v101(p89)
					-- upvalues: (ref) v_u_10, (copy) v_u_81, (ref) v_u_8, (ref) v_u_62, (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (copy) p_u_65, (copy) p_u_64, (ref) v_u_33
					if v_u_10 == v_u_81 then
						local v90 = p89.UserInputType
						if typeof(v90) == "EnumItem" then
							local v91 = p89.UserInputType.Name
							if string.sub(v91, 1, 7) == "Gamepad" then
								local v92 = p89.KeyCode
								local v93 = v_u_8[v92]
								if v93 then
									local v94 = v_u_81
									local v95 = v_u_81
									local v96 = v_u_81
									local v97 = os.clock()
									local v98 = os.clock() + 0.32
									v94.held = v93
									v95.heldAt = v97
									v96.nextAt = v98
									v_u_62(v_u_81, v93)
								elseif v_u_9[v92] then
									local v99 = v_u_9[v92]
									if v99.kind ~= "box" or v_u_6:GetAttribute("Place") ~= "Menu" then
										v_u_5._moveJump(v_u_81, v99.kind, v99.dir)
										return
									end
								elseif v92 == v_u_7.ButtonA then
									if os.clock() - v_u_81.startedAt < 0.15 then
										return
									end
									local v100 = p_u_65.drag()
									if v100 and v100.uid == p_u_64 then
										p_u_65.endDrag(v_u_81.pos, false)
									end
									v_u_33(v_u_81, true)
								end
							end
						end
					end
				end
				table.insert(v87, v88:Connect(v101))
				local v102 = v_u_81.conns
				local v103 = v_u_4.InputEnded
				local function v105(p104)
					-- upvalues: (ref) v_u_10, (copy) v_u_81, (ref) v_u_8
					if v_u_10 == v_u_81 and (v_u_8[p104.KeyCode] and v_u_81.held == v_u_8[p104.KeyCode]) then
						v_u_81.held = nil
					end
				end
				table.insert(v102, v103:Connect(v105))
				v_u_81.hb = v_u_3.Heartbeat:Connect(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_81, (copy) p_u_65, (copy) p_u_64, (copy) p_u_63, (ref) v_u_33, (ref) v_u_4, (ref) v_u_7, (ref) v_u_62
					if v_u_10 == v_u_81 then
						local v106 = p_u_65.drag()
						if v106 and (v106.uid == p_u_64 and (p_u_63.isShown and p_u_63.isShown())) then
							local v107 = nil
							local v108 = v_u_4.gamepadState
							local v109, v110 = pcall(v108)
							if v109 and type(v110) == "table" then
								for _, v111 in v110 do
									if v111.KeyCode ~= v_u_7.Thumbstick1 then
										continue
									end
									local v112 = Vector2.new(v111.Position.X, -v111.Position.Y)
									if v112.Magnitude <= 0.6 then
										continue
									end
									local v113 = v112.X
									local v114 = math.abs(v113)
									local v115 = v112.Y
									if math.abs(v115) < v114 then
										local v116 = Vector2.new
										local v117 = v112.X
										v107 = v116(math.sign(v117), 0)
									else
										local v118 = Vector2.new
										local v119 = v112.Y
										v107 = v118(0, (math.sign(v119)))
									end
								end
							end
							local v120 = os.clock()
							if v107 and v_u_81.held == nil then
								local v121 = v_u_81
								local v122 = v_u_81
								local v123 = v_u_81
								local v124 = v120 + 0.32
								v121.held = v107
								v122.heldAt = v120
								v123.nextAt = v124
								v_u_62(v_u_81, v107)
							elseif v_u_81.held and v_u_81.nextAt <= v120 then
								if not (v_u_4.isDown(v_u_7.DPadUp) or v_u_4.isDown(v_u_7.DPadDown) or (v_u_4.isDown(v_u_7.DPadLeft) or v_u_4.isDown(v_u_7.DPadRight))) and v107 == nil then
									v_u_81.held = nil
									return
								end
								local v125 = (v120 - v_u_81.heldAt - 0.32) / 1
								local v126 = math.clamp(v125, 0, 1)
								v_u_81.nextAt = v120 + 0.09 + v126 * -0.05499999999999999
								v_u_62(v_u_81, v107 or v_u_81.held)
							end
						else
							if v106 and v106.uid == p_u_64 then
								p_u_65.endDrag(v_u_81.pos, true)
							end
							v_u_33(v_u_81, v106 == nil)
							return
						end
					else
						return
					end
				end)
			else
				v_u_6:SetAttribute("PadFocusHold", nil)
				v_u_6:SetAttribute("InvUIPadMove", nil)
			end
		else
			return
		end
	end
end
local v_u_127 = {
	["up"] = Vector2.new(0, -1),
	["down"] = Vector2.new(0, 1),
	["left"] = Vector2.new(-1, 0),
	["right"] = Vector2.new(1, 0)
}
local v_u_128 = {
	["up"] = "NextSelectionUp",
	["down"] = "NextSelectionDown",
	["left"] = "NextSelectionLeft",
	["right"] = "NextSelectionRight"
}
local function v_u_131(p129) -- name: columnOf
	local v130 = p129.Parent
	while v130 and v130.Parent do
		if v130.Parent.Name == "Columns" then
			return v130
		end
		if v130.Name == "HushInventoryUI" then
			break
		end
		v130 = v130.Parent
	end
	return p129:FindFirstAncestorWhichIsA("ScrollingFrame")
end
local function v_u_135(p132) -- name: containerOf
	-- upvalues: (copy) v_u_131
	local v133 = p132.Parent
	while v133 do
		local v134 = v133.Name
		if string.sub(v134, 1, 5) == "Grid_" then
			return v133
		end
		if v133.Name == "HushInventoryUI" then
			break
		end
		v133 = v133.Parent
	end
	return v_u_131(p132)
end
local function v_u_174(p136, p137, p138) -- name: bestFrom
	local v139 = Vector2.new
	local v140 = p137.Y
	local v141 = math.abs(v140)
	local v142 = p137.X
	local v143 = v139(v141, (math.abs(v142)))
	local v144 = p136.AbsolutePosition
	local v145 = p136.AbsoluteSize
	local v146 = v144 + v145 / 2
	local v147
	if v143.X > 0 then
		v147 = v144.X
	else
		v147 = v144.Y
	end
	local v148
	if v143.X > 0 then
		v148 = v145.X
	else
		v148 = v145.Y
	end
	local v149 = v147 + v148
	local v150 = p137.Y ~= 0
	local v151 = (1 / 0)
	local v152 = nil
	for _, v153 in p138 do
		if v153 == p136 or (v153:IsDescendantOf(p136) or p136:IsDescendantOf(v153)) then
			continue
		end
		local v154 = v153.AbsolutePosition
		local v155 = v153.AbsoluteSize
		local v156 = v154 + v155 / 2
		local v157 = (v156 - v146):Dot(p137)
		local v158
		if p137.Y > 0 then
			v158 = v154.Y - (v144.Y + v145.Y)
		elseif p137.Y < 0 then
			v158 = v144.Y - (v154.Y + v155.Y)
		elseif p137.X > 0 then
			v158 = v154.X - (v144.X + v145.X)
		else
			v158 = v144.X - (v154.X + v155.X)
		end
		local v159
		if v150 then
			local v160 = v145.Y
			local v161 = v155.Y
			v159 = math.min(v160, v161)
		else
			local v162 = v145.X
			local v163 = v155.X
			v159 = math.min(v162, v163)
		end
		local v164 = v159 * 0.25
		if v157 <= 2 or -v164 >= v158 then
			continue
		end
		local v165
		if v143.X > 0 then
			v165 = v154.X
		else
			v165 = v154.Y
		end
		local v166
		if v143.X > 0 then
			v166 = v155.X
		else
			v166 = v155.Y
		end
		local v167 = v165 + v166
		local v168 = v165 - v149
		local v169 = v147 - v167
		local v170 = math.max(0, v168, v169)
		local v171 = (v156 - v146):Dot(v143)
		local v172 = math.abs(v171)
		local v173 = math.max(0, v158) + v170 * 4 + v172 * 0.35
		if v173 >= v151 then
			continue
		end
		v152 = v153
		v151 = v173
	end
	return v152
end
local v_u_175 = {
	["root"] = nil,
	["at"] = 0,
	["list"] = nil,
	["list"] = {}
}
local function v_u_182(p176) -- name: candidates
	-- upvalues: (copy) v_u_175, (copy) v_u_4
	local v177 = os.clock()
	if v_u_175.root == p176 and v177 - v_u_175.at < 0.25 then
		return v_u_175.list
	end
	local v178 = {}
	for _, v179 in v_u_4.selectables(p176) do
		if v179:IsA("ScrollingFrame") then
			continue
		end
		table.insert(v178, v179)
	end
	local v180 = v_u_175
	local v181 = v_u_175
	v_u_175.root = p176
	v180.at = v177
	v181.list = v178
	return v178
end
local function v_u_196(p183) -- name: scrollIntoView
	local v184 = p183:FindFirstAncestorWhichIsA("ScrollingFrame")
	if v184 then
		local v185 = v184.AbsolutePosition
		local v186 = v184.AbsoluteWindowSize
		local v187 = p183.AbsolutePosition
		local v188 = p183.AbsoluteSize
		local v189 = v184.CanvasPosition
		local v190 = 0
		if v187.Y < v185.Y then
			v190 = v187.Y - v185.Y - 8
		elseif v187.Y + v188.Y > v185.Y + v186.Y then
			v190 = v187.Y + v188.Y - (v185.Y + v186.Y) + 8
		end
		if v190 ~= 0 then
			local v191 = v184.AbsoluteCanvasSize.Y - v186.Y
			local v192 = math.max(0, v191)
			local v193 = Vector2.new
			local v194 = v189.X
			local v195 = v189.Y + v190
			v184.CanvasPosition = v193(v194, (math.clamp(v195, 0, v192)))
		end
	end
end
local function v_u_200(p_u_197) -- name: clearNext
	-- upvalues: (copy) v_u_128
	if p_u_197 and p_u_197.Parent then
		for _, v_u_198 in v_u_128 do
			local v199 = p_u_197[v_u_198]
			if v199 == nil or v199 == p_u_197 then
				continue
			end
			pcall(function()
				-- upvalues: (copy) p_u_197, (copy) v_u_198
				p_u_197[v_u_198] = nil
			end)
		end
	end
end
local function v_u_212(p_u_201, p202) -- name: setNeighbours
	-- upvalues: (copy) v_u_182, (copy) v_u_127, (copy) v_u_174, (copy) v_u_11, (copy) v_u_128
	local v203 = v_u_182(p202)
	for v204, v205 in v_u_127 do
		local v_u_206 = v_u_174(p_u_201, v205, v203)
		if v_u_206 then
			local v207
			if typeof(v_u_206) == "Instance" and v_u_206:IsA("GuiObject") then
				v207 = v_u_206:GetAttribute("PadDefault") == true and true or v_u_11.marked[v_u_206] == true
			else
				v207 = false
			end
			if not v207 then
				v_u_206 = nil
			end
		else
			v_u_206 = nil
		end
		local v_u_208 = v_u_128[v204]
		if p_u_201[v_u_208] == v_u_206 then
			continue
		end
		pcall(function()
			-- upvalues: (copy) p_u_201, (copy) v_u_208, (copy) v_u_206
			p_u_201[v_u_208] = v_u_206
		end)
	end
	local v209 = v_u_11
	local v210 = v_u_11
	local v211 = os.clock()
	v209.setOn = p_u_201
	v210.setAt = v211
end
local function v_u_225() -- name: heldDir
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_127
	if v_u_4.isDown(v_u_7.DPadUp) then
		return v_u_127.up
	end
	if v_u_4.isDown(v_u_7.DPadDown) then
		return v_u_127.down
	end
	if v_u_4.isDown(v_u_7.DPadLeft) then
		return v_u_127.left
	end
	if v_u_4.isDown(v_u_7.DPadRight) then
		return v_u_127.right
	end
	local v213 = v_u_4.gamepadState
	local v214, v215 = pcall(v213)
	if v214 and type(v215) == "table" then
		for _, v216 in v215 do
			if v216.KeyCode ~= v_u_7.Thumbstick1 then
				continue
			end
			local v217 = Vector2.new(v216.Position.X, -v216.Position.Y)
			if v217.Magnitude <= 0.6 then
				continue
			end
			local v218 = v217.X
			local v219 = math.abs(v218)
			local v220 = v217.Y
			if math.abs(v220) < v219 then
				local v221 = Vector2.new
				local v222 = v217.X
				return v221(math.sign(v222), 0)
			else
				local v223 = Vector2.new
				local v224 = v217.Y
				return v223(0, (math.sign(v224)))
			end
		end
	end
	return nil
end
local function v_u_231() -- name: tip
	-- upvalues: (copy) v_u_11, (ref) v_u_12, (copy) v_u_6
	if not v_u_11.tipShown then
		v_u_11.tipShown = true
		local v226 = v_u_12
		if not v226 then
			local v227
			v227, v226 = pcall(function()
				return require((script.Parent:WaitForChild("HushUI", 2)))
			end)
			if not v227 then
				v226 = nil
			end
		end
		if v226 then
			local v228 = v226.toast
			if type(v228) == "function" then
				local v229 = v_u_6:GetAttribute("Place") == "Menu" and "Hold to go faster  \194\183  LT / RT: other side" or "Hold to go faster  \194\183  LB / RB: next container  \194\183  LT / RT: other side"
				local v230 = v226.toast
				pcall(v230, v229, "info", nil, 6)
			end
		end
	end
end
local function v_u_239(p232, p233) -- name: firstOf
	-- upvalues: (copy) v_u_11
	if p233 then
		p233 = v_u_11.lastIn[p233]
	end
	if p233 and table.find(p232, p233) then
		return p233
	end
	local v234 = nil
	for _, v235 in p232 do
		if v234 then
			local v236 = v235.AbsolutePosition
			local v237 = v234.AbsolutePosition
			if v236.Y >= v237.Y - 2 then
				local v238 = v236.Y - v237.Y
				if math.abs(v238) > 2 or v236.X >= v237.X then
					continue
				end
			end
			v234 = v235
		else
			v234 = v235
		end
	end
	return v234
end
local function v_u_262(p240, p241) -- name: groupsOf
	-- upvalues: (copy) v_u_182, (copy) v_u_11, (copy) v_u_131, (copy) v_u_135
	local v_u_242 = {}
	local v243 = {}
	for _, v244 in v_u_182(p240) do
		local v245
		if typeof(v244) == "Instance" and v244:IsA("GuiObject") then
			v245 = v244:GetAttribute("PadDefault") == true and true or v_u_11.marked[v244] == true
		else
			v245 = false
		end
		if not v245 then
			continue
		end
		local v246
		if p241 == "side" then
			v246 = v_u_131(v244)
		else
			v246 = v_u_135(v244)
		end
		if not v246 then
			continue
		end
		if not v_u_242[v246] then
			v_u_242[v246] = {}
			table.insert(v243, v246)
		end
		local v247 = v_u_242[v246]
		table.insert(v247, v244)
	end
	local function v_u_254(p248) -- name: key
		-- upvalues: (ref) v_u_131, (copy) v_u_242
		local v249 = v_u_131(p248) or p248
		local v250 = not v249:IsA("GuiObject") and 0 or v249.AbsolutePosition.X
		local v251 = (1 / 0)
		for _, v252 in v_u_242[p248] do
			local v253 = v252.AbsolutePosition.Y
			v251 = math.min(v251, v253)
		end
		return v250, v251
	end
	table.sort(v243, function(p255, p256)
		-- upvalues: (copy) v_u_254
		local v257, v258 = v_u_254(p255)
		local v259, v260 = v_u_254(p256)
		local v261 = v257 - v259
		if math.abs(v261) > 4 then
			return v257 < v259
		else
			return v258 < v260
		end
	end)
	return v243, v_u_242
end
local function v_u_280(p263, p264) -- name: browseJump
	-- upvalues: (copy) v_u_2, (copy) v_u_262, (copy) v_u_131, (copy) v_u_135, (copy) v_u_239, (copy) v_u_11, (copy) v_u_196, (copy) v_u_6
	local v265 = v_u_2.SelectedObject
	local v266
	if typeof(v265) == "Instance" then
		v266 = v265:FindFirstAncestor("HushInventoryUI")
	else
		v266 = nil
	end
	if not (v265 and v266) then
		return false
	end
	local v267, v268 = v_u_262(v266, p263)
	if #v267 == 0 then
		return false
	end
	local v269
	if p263 == "side" then
		v269 = v_u_131(v265)
	else
		v269 = v_u_135(v265)
	end
	local v270 = 0
	for v271, v272 in v267 do
		if v272 ~= v269 then
			continue
		end
		v270 = v271
	end
	if v270 == 0 then
		v270 = p264 > 0 and 0 or #v267 + 1
	end
	local v273 = #v267
	local v274 = nil
	local v275 = nil
	for v276 = 1, v273 do
		local v277 = v267[(v270 - 1 + p264 * v276) % v273 + 1]
		if v277 == v269 then
			continue
		end
		v274 = v_u_239(v268[v277], v277)
		if v274 then
			v275 = v277
			break
		end
		v275 = v277
	end
	if not v274 then
		return false
	end
	if v269 then
		local v278
		if typeof(v265) == "Instance" and v265:IsA("GuiObject") then
			v278 = v265:GetAttribute("PadDefault") == true and true or v_u_11.marked[v265] == true
		else
			v278 = false
		end
		if v278 then
			v_u_11.lastIn[v269] = v265
		end
	end
	v_u_2.SelectedObject = v274
	v_u_196(v274)
	local v279 = v_u_11
	v279.jumps = v279.jumps + 1
	v_u_11.last = p263 .. (p264 > 0 and "+" or "-") .. ":" .. (not v275 and "?" or v275.Name)
	v_u_6:SetAttribute("InvPadNav", string.format("steps=%d jumps=%d last=%s", v_u_11.steps, v_u_11.jumps, v_u_11.last))
	return true
end
v_u_5._browseJump = v_u_280
function v_u_5._moveJump(p281, p282, p283) -- name: _moveJump
	-- upvalues: (copy) v_u_4, (copy) v_u_131, (copy) v_u_196, (copy) v_u_11, (copy) v_u_6
	local v284 = p281.m
	if v284 then
		v284 = p281.m.root
	end
	if typeof(v284) == "Instance" then
		local v285 = {}
		for _, v286 in v284:GetDescendants() do
			if not v286:IsA("GuiObject") then
				continue
			end
			local v287 = v286.Name
			if string.sub(v287, 1, 5) ~= "Grid_" then
				local v288 = v286.Name
				if string.sub(v288, 1, 5) ~= "Slot_" then
					continue
				end
			end
			if not v_u_4.shown(v286) then
				continue
			end
			table.insert(v285, v286)
		end
		if #v285 == 0 then
			return
		else
			table.sort(v285, function(p289, p290)
				-- upvalues: (ref) v_u_131
				local v291 = v_u_131(p289)
				local v292
				if v291 and v291:IsA("GuiObject") then
					v292 = v291.AbsolutePosition.X
				else
					v292 = p289.AbsolutePosition.X
				end
				local v293 = v_u_131(p290)
				local v294
				if v293 and v293:IsA("GuiObject") then
					v294 = v293.AbsolutePosition.X
				else
					v294 = p290.AbsolutePosition.X
				end
				local v295 = v292 - v294
				if math.abs(v295) > 4 then
					return v292 < v294
				else
					local v296 = p289.AbsolutePosition.Y - p290.AbsolutePosition.Y
					if math.abs(v296) > 2 then
						return p289.AbsolutePosition.Y < p290.AbsolutePosition.Y
					else
						return p289.AbsolutePosition.X < p290.AbsolutePosition.X
					end
				end
			end)
			local v297 = (1 / 0)
			local v298 = 0
			for v299, v300 in v285 do
				local v301 = v300.AbsolutePosition
				local v302 = v300.AbsolutePosition + v300.AbsoluteSize
				local v303 = p281.pos
				local v304 = v301.X - v303.X
				local v305 = v303.X - v302.X
				local v306 = math.max(v304, 0, v305)
				local v307 = v301.Y - v303.Y
				local v308 = v303.Y - v302.Y
				local v309 = v306 + math.max(v307, 0, v308)
				if v309 >= v297 then
					continue
				end
				v298 = v299
				v297 = v309
			end
			local v310 = nil
			if p282 == "side" then
				local v311 = v_u_131(v285[v298])
				local v312 = {}
				for _, v313 in v285 do
					local v314 = v_u_131(v313)
					if not v314 or table.find(v312, v314) then
						continue
					end
					table.insert(v312, v314)
				end
				local v315 = v312[((table.find(v312, v311) or 1) - 1 + p283) % #v312 + 1]
				for _, v316 in v285 do
					if v_u_131(v316) ~= v315 then
						continue
					end
					v310 = v316
				end
			else
				v310 = v285[(v298 - 1 + p283) % #v285 + 1]
			end
			if v310 then
				v_u_196(v310)
				local v317 = p281.api.cell(p281.m)
				local v318 = v310.AbsolutePosition
				local v319 = Vector2.new
				local v320 = v310.AbsoluteSize.X
				local v321 = math.min(v317, v320) * 0.5
				local v322 = v310.AbsoluteSize.Y
				local v323 = v318 + v319(v321, math.min(v317, v322) * 0.5)
				p281.pos = v323
				p281.api.updateDrag(v323)
				p281.api.sound("tick")
				local v324 = v_u_11
				v324.jumps = v324.jumps + 1
				v_u_11.last = "move-" .. p282 .. (p283 > 0 and "+" or "-") .. ":" .. v310.Name
				v_u_6:SetAttribute("InvPadNav", string.format("steps=%d jumps=%d last=%s", v_u_11.steps, v_u_11.jumps, v_u_11.last))
			end
		end
	else
		return
	end
end
local function v_u_340() -- name: browseStep
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (copy) v_u_11, (copy) v_u_2, (copy) v_u_200, (copy) v_u_196, (copy) v_u_212, (copy) v_u_231, (copy) v_u_225, (copy) v_u_174, (copy) v_u_182, (copy) v_u_135
	if v_u_10 == nil and (v_u_6:GetAttribute("InputDevice") == "Gamepad" and v_u_6:GetAttribute("PadFocusHold") ~= true) then
		local v325 = v_u_2.SelectedObject
		if v_u_11.setOn and v_u_11.setOn ~= v325 then
			v_u_200(v_u_11.setOn)
			v_u_11.setOn = nil
		end
		local v326
		if typeof(v325) == "Instance" and v325:IsA("GuiObject") then
			v326 = v325:GetAttribute("PadDefault") == true and true or v_u_11.marked[v325] == true
		else
			v326 = false
		end
		if v326 then
			local v327
			if typeof(v325) == "Instance" then
				v327 = v325:FindFirstAncestor("HushInventoryUI")
			else
				v327 = nil
			end
			if v327 then
				local v328 = os.clock()
				if v_u_11.setOn ~= v325 or v328 - v_u_11.setAt > 0.5 then
					if v_u_11.setOn ~= v325 then
						v_u_196(v325)
					end
					v_u_212(v325, v327)
					v_u_231()
				end
				local v329 = v_u_225()
				if v329 == nil then
					v_u_11.dir = nil
					return
				elseif v_u_11.dir == v329 then
					if v328 >= v_u_11.nextAt then
						local v330 = (v328 - v_u_11.heldAt - 0.3) / 1
						local v331 = math.clamp(v330, 0, 1)
						v_u_11.nextAt = v328 + 0.12 + v331 * -0.08499999999999999
						local v332 = v_u_174(v325, v329, (v_u_182(v327)))
						if v332 then
							local v333
							if typeof(v332) == "Instance" and v332:IsA("GuiObject") then
								v333 = v332:GetAttribute("PadDefault") == true and true or v_u_11.marked[v332] == true
							else
								v333 = false
							end
							if v333 then
								local v334 = v_u_135(v325)
								if v334 then
									v_u_11.lastIn[v334] = v325
								end
								v_u_200(v325)
								v_u_2.SelectedObject = v332
								v_u_196(v332)
								local v335 = v_u_11
								v335.steps = v335.steps + 1
								v_u_11.last = "step"
								v_u_212(v332, v327)
								v_u_6:SetAttribute("InvPadNav", string.format("steps=%d jumps=%d last=%s", v_u_11.steps, v_u_11.jumps, v_u_11.last))
							end
						end
					end
				else
					local v336 = v_u_11
					local v337 = v_u_11
					local v338 = v_u_11
					local v339 = v328 + 0.3
					v336.dir = v329
					v337.heldAt = v328
					v338.nextAt = v339
					return
				end
			else
				v_u_11.dir = nil
				return
			end
		else
			v_u_11.dir = nil
			return
		end
	else
		v_u_11.dir = nil
		return
	end
end
v_u_13 = function()
	-- upvalues: (copy) v_u_11, (copy) v_u_3, (copy) v_u_340, (copy) v_u_6, (copy) v_u_4, (ref) v_u_10, (copy) v_u_9, (copy) v_u_2, (copy) v_u_280
	if not v_u_11.started then
		v_u_11.started = true
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_340, (ref) v_u_6
			local v341 = v_u_340
			local v342, v343 = pcall(v341)
			if not v342 then
				v_u_6:SetAttribute("ClientError", "InvUIPad browse: " .. tostring(v343))
			end
		end)
		v_u_4.InputBegan:Connect(function(p344)
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_6, (ref) v_u_2, (ref) v_u_11, (ref) v_u_280
			if v_u_10 == nil then
				local v345 = p344.UserInputType
				if typeof(v345) == "EnumItem" then
					local v346 = p344.UserInputType.Name
					if string.sub(v346, 1, 7) == "Gamepad" then
						local v347 = v_u_9[p344.KeyCode]
						if v347 then
							if v347.kind ~= "box" or v_u_6:GetAttribute("Place") ~= "Menu" then
								local v348 = v_u_2.SelectedObject
								local v349
								if typeof(v348) == "Instance" and v348:IsA("GuiObject") then
									v349 = v348:GetAttribute("PadDefault") == true and true or v_u_11.marked[v348] == true
								else
									v349 = false
								end
								if not v349 then
									local v350 = v_u_2.SelectedObject
									local v351
									if typeof(v350) == "Instance" then
										v351 = v350:FindFirstAncestor("HushInventoryUI")
									else
										v351 = nil
									end
									if not v351 then
										return
									end
								end
								local v352 = v_u_280
								local v353 = v347.kind
								local v354 = v347.dir
								pcall(v352, v353, v354)
							end
						else
							return
						end
					end
				end
			end
		end)
	end
end
task.defer(v_u_13)
function v_u_5.browseState() -- name: browseState
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_6
	local v355 = v_u_2.SelectedObject
	local v356 = {
		["started"] = v_u_11.started,
		["pad"] = v_u_6:GetAttribute("InputDevice") == "Gamepad"
	}
	local v357
	if typeof(v355) == "Instance" and v355:IsA("GuiObject") then
		v357 = v355:GetAttribute("PadDefault") == true and true or v_u_11.marked[v355] == true
	else
		v357 = false
	end
	v356.tile = v357
	local v358
	if v355 then
		v358 = v355:GetFullName()
	else
		v358 = nil
	end
	v356.sel = v358
	v356.steps = v_u_11.steps
	v356.jumps = v_u_11.jumps
	v356.last = v_u_11.last
	v356.dir = v_u_11.dir
	local v359
	if v355 then
		v359 = {}
		local v360 = v355.NextSelectionUp
		if v360 then
			v360 = v355.NextSelectionUp.Name
		end
		v359.up = v360
		local v361 = v355.NextSelectionDown
		if v361 then
			v361 = v355.NextSelectionDown.Name
		end
		v359.down = v361
		local v362 = v355.NextSelectionLeft
		if v362 then
			v362 = v355.NextSelectionLeft.Name
		end
		v359.left = v362
		local v363 = v355.NextSelectionRight
		if v363 then
			v363 = v355.NextSelectionRight.Name
		end
		v359.right = v363
	else
		v359 = nil
	end
	v356.next = v359
	return v356
end
return v_u_5