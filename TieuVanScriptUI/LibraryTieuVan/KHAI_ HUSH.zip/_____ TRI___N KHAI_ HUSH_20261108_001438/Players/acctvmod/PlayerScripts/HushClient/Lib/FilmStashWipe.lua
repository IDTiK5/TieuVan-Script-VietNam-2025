-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmStashWipe

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v4 = {}
local v_u_5 = v1.LocalPlayer
function v4.mount(p6, p_u_7, p8, p9) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_2
	local v10 = type(p9) ~= "table" and {} or p9
	if type(p8) == "table" then
		local v11 = p8.color
		if type(v11) ~= "table" then
			p8 = v_u_3.Theme
		end
	else
		p8 = v_u_3.Theme
	end
	local v_u_12 = p8.color
	local v13 = v10.inner
	local v14 = type(v13) ~= "number" and 438 or v10.inner
	local v15 = v10.gui
	local v_u_16
	if v10.player == nil then
		v_u_16 = v_u_5
	else
		v_u_16 = v10.player
	end
	local v17 = 0
	local v_u_18 = true
	if v15 then
		v15.Destroying:Connect(function()
			-- upvalues: (ref) v_u_18
			v_u_18 = false
		end)
	end
	local v19 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Stash wipe  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p6,
		["color"] = v_u_12.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v20 = v10.order
	local v21, v22
	if type(v20) == "function" then
		v21 = v10.order()
		v22 = v17
	else
		v17 = v17 + 1
		v21 = v17
		v22 = v17
	end
	v19.LayoutOrder = v21
	local v23 = v_u_3.label({
		["parent"] = nil,
		["name"] = "WipeNote",
		["text"] = "The PVP stash wipe runs when a PVP profile loads after the date. Skins, Kill Card items, trophies and game pass perks stay. Players see a timer from 30 days before. Type a date (YYYY-MM-DD or YYYY-MM-DD HH:MM, UTC) and press SET. Other servers follow within 5 minutes. A date in the past is refused.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p6,
		["color"] = v_u_12.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v24 = v10.order
	local v25
	if type(v24) == "function" then
		v25 = v10.order()
	else
		v17 = v22 + 1
		v25 = v17
		v22 = v17
	end
	v23.LayoutOrder = v25
	local v26 = v_u_3.new
	local v27 = {
		["Name"] = "WipeDateRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v28 = UDim2.new
	local v29 = p8.touch
	v27.Size = v28(1, 0, 0, type(v29) ~= "function" and 36 or p8.touch(36))
	local v30 = v26("Frame", v27, p6)
	local v31 = v10.order
	local v32
	if type(v31) == "function" then
		v32 = v10.order()
	else
		v17 = v22 + 1
		v32 = v17
		v22 = v17
	end
	v30.LayoutOrder = v32
	v_u_3.layout(v30, "h", 6)
	local v33 = v_u_3.input
	local v34 = {
		["parent"] = nil,
		["name"] = "WipeDate",
		["size"] = nil,
		["placeholder"] = "2026-12-01 18:30  (UTC, 0 = none)",
		["parent"] = v30
	}
	local v35 = UDim2.fromOffset
	local v36 = p8.touch
	v34.size = v35(v14, type(v36) ~= "function" and 36 or p8.touch(36))
	local v37, v_u_38 = v33(v34)
	v37.LayoutOrder = 1
	local v39 = v_u_3.new
	local v40 = {
		["Name"] = "WipeButtons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v41 = UDim2.new
	local v42 = p8.touch
	v40.Size = v41(1, 0, 0, type(v42) ~= "function" and 34 or p8.touch(34))
	local v43 = v39("Frame", v40, p6)
	local v44 = v10.order
	local v45
	if type(v44) == "function" then
		v45 = v10.order()
	else
		v17 = v22 + 1
		v45 = v17
		v22 = v17
	end
	v43.LayoutOrder = v45
	v_u_3.layout(v43, "h", 6)
	local v_u_46 = v_u_3.label({
		["parent"] = nil,
		["name"] = "WipeStatus",
		["text"] = "Idle.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p6,
		["color"] = v_u_12.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v47 = v10.order
	local v48
	if type(v47) == "function" then
		v48 = v10.order()
	else
		v17 = v22 + 1
		v48 = v17
		v22 = v17
	end
	v_u_46.LayoutOrder = v48
	local v49 = v_u_3.new("ScrollingFrame", {
		["Name"] = "WipeOut",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollingDirection"] = nil,
		["BackgroundColor3"] = v_u_12.raised,
		["Size"] = UDim2.new(1, 0, 0, 150),
		["CanvasSize"] = UDim2.new(0, 0, 0, 0),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, p6)
	local v50 = v10.order
	local v51
	if type(v50) == "function" then
		v51 = v10.order()
	else
		v17 = v22 + 1
		v51 = v17
	end
	v49.LayoutOrder = v51
	local v_u_52 = v_u_3.label({
		["parent"] = nil,
		["name"] = "WipeText",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v49,
		["color"] = v_u_12.text2,
		["size"] = UDim2.new(1, -8, 0, 0)
	})
	local v_u_53 = false
	local v_u_54 = "none"
	local function v_u_68(p_u_55, p56) -- name: call
		-- upvalues: (ref) v_u_53, (copy) p_u_7, (ref) v_u_3, (copy) v_u_46, (copy) v_u_12, (copy) v_u_16, (ref) v_u_54, (ref) v_u_18, (copy) v_u_52
		if v_u_53 then
			return
		else
			local v57 = p_u_7
			if type(v57) == "function" then
				v_u_53 = true
				v_u_3.setText(v_u_46, p56)
				v_u_46.TextColor3 = v_u_12.text2
				if v_u_16 then
					v_u_16:SetAttribute("FilmStashWipe", ("busy=%d|last=%s"):format(v_u_53 and 1 or 0, v_u_54))
				end
				p_u_7("wipe.schedule", p_u_55, function(p58)
					-- upvalues: (ref) v_u_53, (ref) v_u_18, (ref) v_u_54, (copy) p_u_55, (ref) v_u_3, (ref) v_u_46, (ref) v_u_12, (ref) v_u_52, (ref) v_u_16
					v_u_53 = false
					if v_u_18 then
						if type(p58) == "table" then
							v_u_54 = p58.ok == true and "ok" or "bad"
							local v59 = p58.msg
							local v60
							if type(v59) == "string" and p58.msg ~= "" then
								v60 = p58.msg
							else
								v60 = p58.ok == true and "Done." or "Refused or failed."
							end
							if p_u_55.action == "schedule" then
								local v61 = p58.ok ~= true
								v_u_3.setText(v_u_46, v60)
								local v62 = v_u_46
								local v63
								if v61 then
									v63 = v_u_12.danger
								else
									v63 = v_u_12.text2
								end
								v62.TextColor3 = v63
							else
								local v64 = p58.ok == true and "Done." or v60
								local v65 = p58.ok ~= true
								v_u_3.setText(v_u_46, v64)
								local v66 = v_u_46
								local v67
								if v65 then
									v67 = v_u_12.danger
								else
									v67 = v_u_12.text2
								end
								v66.TextColor3 = v67
								if p58.ok == true then
									v_u_3.setText(v_u_52, v60)
								end
							end
						else
							v_u_54 = "bad"
							v_u_3.setText(v_u_46, "The server did not answer.")
							v_u_46.TextColor3 = v_u_12.danger
						end
						if v_u_16 then
							v_u_16:SetAttribute("FilmStashWipe", ("busy=%d|last=%s"):format(v_u_53 and 1 or 0, v_u_54))
						end
					end
				end)
			else
				v_u_3.setText(v_u_46, "No connection to the server.")
				v_u_46.TextColor3 = v_u_12.danger
			end
		end
	end
	local function v_u_70() -- name: setDate
		-- upvalues: (copy) v_u_38, (ref) v_u_3, (copy) v_u_46, (copy) v_u_12, (copy) v_u_68
		local v69 = v_u_38.Text
		if type(v69) == "string" and not string.match(v69, "^%s*$") then
			v_u_68({
				["action"] = "schedule",
				["date"] = nil,
				["date"] = v69
			}, "Saving the date ...")
		else
			v_u_3.setText(v_u_46, "Type a date first, for example 2026-12-01 18:30.")
			v_u_46.TextColor3 = v_u_12.danger
		end
	end
	local function v71() -- name: cancel
		-- upvalues: (copy) v_u_68
		v_u_68({
			["action"] = "schedule",
			["date"] = "0"
		}, "Cancelling the wipe ...")
	end
	local function v72() -- name: status
		-- upvalues: (copy) v_u_68
		v_u_68({
			["action"] = "status"
		}, "Reading the wipe date ...")
	end
	local function v73() -- name: dry
		-- upvalues: (copy) v_u_68
		v_u_68({
			["action"] = "dry"
		}, "Running the dry run ...")
	end
	local v74 = (v14 - 18) / 4
	local v75 = math.floor(v74)
	local v76 = v_u_3.button
	local v77 = {
		["parent"] = nil,
		["text"] = "Set",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v43
	}
	local v78 = p8.touch
	v77.height = type(v78) ~= "function" and 34 or p8.touch(34)
	v77.width = v75
	v77.maxTextWidth = v75 - 12
	v77.onClick = v_u_70
	v76(v77).Name = "WipeSet"
	local v79 = v_u_3.button
	local v80 = {
		["parent"] = nil,
		["text"] = "Cancel",
		["kind"] = "danger",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v43
	}
	local v81 = p8.touch
	v80.height = type(v81) ~= "function" and 34 or p8.touch(34)
	v80.width = v75
	v80.maxTextWidth = v75 - 12
	v80.onClick = v71
	v79(v80).Name = "WipeCancel"
	local v82 = v_u_3.button
	local v83 = {
		["parent"] = nil,
		["text"] = "Status",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v43
	}
	local v84 = p8.touch
	v83.height = type(v84) ~= "function" and 34 or p8.touch(34)
	v83.width = v75
	v83.maxTextWidth = v75 - 12
	v83.onClick = v72
	v82(v83).Name = "WipeStatusBtn"
	local v85 = v_u_3.button
	local v86 = {
		["parent"] = nil,
		["text"] = "Dry run",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v43
	}
	local v87 = p8.touch
	v86.height = type(v87) ~= "function" and 34 or p8.touch(34)
	v86.width = v75
	v86.maxTextWidth = v75 - 12
	v86.onClick = v73
	v85(v86).Name = "WipeDry"
	if v_u_2:IsStudio() and v_u_16 then
		local v_u_91 = v_u_16:GetAttributeChangedSignal("FilmStashWipeCmd"):Connect(function()
			-- upvalues: (copy) v_u_16, (copy) v_u_38, (copy) v_u_70, (copy) v_u_68
			local v88 = v_u_16:GetAttribute("FilmStashWipeCmd")
			if type(v88) == "string" and v88 ~= "" then
				v_u_16:SetAttribute("FilmStashWipeCmd", nil)
				local v89, v90 = string.match(v88, "^(%a+)%s*(.-)$")
				if v89 == "date" then
					v_u_38.Text = v90
					return
				elseif v89 == "set" then
					v_u_70()
					return
				elseif v89 == "cancel" then
					v_u_68({
						["action"] = "schedule",
						["date"] = "0"
					}, "Cancelling the wipe ...")
					return
				elseif v89 == "status" then
					v_u_68({
						["action"] = "status"
					}, "Reading the wipe date ...")
				elseif v89 == "dry" then
					v_u_68({
						["action"] = "dry"
					}, "Running the dry run ...")
				end
			else
				return
			end
		end)
		if v15 then
			v15.Destroying:Connect(function()
				-- upvalues: (copy) v_u_91
				v_u_91:Disconnect()
			end)
		end
	end
	if v_u_16 then
		v_u_16:SetAttribute("FilmStashWipe", ("busy=%d|last=%s"):format(v_u_53 and 1 or 0, v_u_54))
	end
	task.defer(v72)
	return {
		["set"] = v_u_70,
		["cancel"] = v71,
		["status"] = v72,
		["dry"] = v73,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_18
			return v_u_18
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_53, (ref) v_u_54
			return {
				["busy"] = v_u_53,
				["last"] = v_u_54
			}
		end
	}
end
return v4