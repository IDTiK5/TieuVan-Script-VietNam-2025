-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuDirectorState

local v_u_5 = {
	["new"] = function(p1) -- name: new
		local v2
		if p1 == nil then
			local v3
			v3, v2 = pcall(function()
				return require(script.Parent:WaitForChild("MenuShotMath"))
			end)
			if not v3 then
				v2 = p1
			end
		else
			v2 = p1
		end
		local v4
		if v2 == nil then
			v4 = false
		else
			v4 = v2.TUNE ~= nil
		end
		assert(v4, "MenuDirectorState.new needs MenuShotMath")
		return {
			["sm"] = nil,
			["phase"] = "idle",
			["t0"] = 0,
			["dur"] = 0,
			["fromScene"] = "",
			["fromShot"] = "",
			["toScene"] = "",
			["toShot"] = "",
			["kind"] = "set",
			["started"] = false,
			["reduced"] = false,
			["ready"] = false,
			["readyAt"] = 0,
			["fo"] = 0,
			["fi"] = 0,
			["tail"] = nil,
			["arrivedPending"] = false,
			["seq"] = 0,
			["sm"] = v2
		}
	end
}
local function v_u_13(p6, p7) -- name: advance
	for _ = 1, 8 do
		local v8 = p6.phase
		if v8 == "glide" then
			if p7 - p6.t0 < p6.dur - 1e-9 then
				return
			end
			p6.phase = "idle"
			p6.arrivedPending = true
		elseif v8 == "fadeOut" then
			if p7 - p6.t0 < p6.fo - 1e-9 then
				return
			end
			p6.t0 = p6.t0 + p6.fo
			p6.phase = "wait"
		elseif v8 == "wait" then
			local v9 = p6.t0 + p6.sm.TUNE.streamWaitMax
			if p6.ready then
				local v10 = p6.t0
				local v11 = p6.readyAt
				local v12 = math.max(v10, v11)
				v9 = math.min(v9, v12)
			end
			if v9 - 1e-9 > p7 then
				return
			end
			p6.t0 = v9
			p6.phase = "fadeIn"
		else
			if v8 ~= "fadeIn" then
				return
			end
			if p7 - p6.t0 < p6.fi - 1e-9 then
				return
			end
			p6.phase = "idle"
			p6.arrivedPending = true
		end
	end
end
function v_u_5.snap(p14, p15, p16, p17, p18) -- name: snap
	p14.fromScene = p15
	p14.fromShot = p16
	p14.toScene = p15
	p14.toShot = p16
	p14.kind = p17
	p14.phase = "idle"
	p14.tail = nil
	p14.started = true
	p14.ready = true
	p14.readyAt = p18
	p14.arrivedPending = true
	p14.seq = p14.seq + 1
end
function v_u_5.request(p19, p20, p21, p22, p23, p24, p25) -- name: request
	-- upvalues: (copy) v_u_13, (copy) v_u_5
	local v26 = p25 or {}
	local v27 = p24 == true
	v_u_13(p19, p23)
	if not p19.started or v26.instant == true then
		v_u_5.snap(p19, p20, p21, p22, p23)
		return true
	end
	local v28
	if p20 == p19.toScene then
		v28 = p21 == p19.toShot
	else
		v28 = false
	end
	if v28 and v26.cut ~= true then
		return false
	end
	local v29 = p19.phase
	p19.arrivedPending = false
	p19.seq = p19.seq + 1
	if v29 == "fadeOut" or v29 == "wait" then
		if p20 == p19.toScene or v29 ~= "wait" then
			if p20 ~= p19.toScene then
				p19.ready = false
			end
		else
			p19.ready = false
			p19.t0 = p23
		end
		p19.toScene = p20
		p19.toShot = p21
		p19.kind = p22
		return true
	end
	local v30 = p19.phase
	local v31
	if v30 == "fadeOut" then
		local v32 = (p23 - p19.t0) / p19.fo
		local v33 = math.clamp(v32, 0, 1)
		v31 = v33 * v33
	elseif v30 == "wait" then
		v31 = 1
	elseif v30 == "fadeIn" then
		local v34 = (p23 - p19.t0) / p19.fi
		local v35 = math.clamp(v34, 0, 1)
		v31 = 1 - (1 - (1 - v35) * (1 - v35))
	else
		local v36 = p19.tail
		if v36 == nil then
			v31 = 0
		else
			local v37 = (p23 - v36.t0) / v36.dur
			if v37 >= 1 then
				p19.tail = nil
				v31 = 0
			else
				local v38 = v36.a0
				local v39 = math.clamp(v37, 0, 1)
				v31 = v38 * (1 - (1 - (1 - v39) * (1 - v39)))
			end
		end
	end
	local v40 = p20 == p19.toScene
	local v41 = p19.toScene
	local v42 = p19.toShot
	p19.fromScene = v41
	p19.fromShot = v42
	p19.toScene = p20
	p19.toShot = p21
	p19.kind = p22
	p19.reduced = v27
	local v43 = p19.sm.TUNE
	if v27 then
		p19.fo = v43.reducedFade / 2
		p19.fi = v43.reducedFade / 2
	else
		p19.fo = v43.fadeOut
		p19.fi = v43.fadeIn
	end
	if v40 and (not v27 and v26.cut ~= true) then
		p19.phase = "glide"
		p19.t0 = p23
		p19.dur = p19.sm._glideSeconds(v26.dist or 0)
		if v31 > 0.001 then
			p19.tail = {
				["a0"] = v31,
				["t0"] = p23,
				["dur"] = p19.fi
			}
		else
			p19.tail = nil
		end
		return true
	end
	local v44 = math.clamp(v31, 0, 1)
	local v45 = math.sqrt(v44)
	p19.phase = "fadeOut"
	p19.t0 = p23 - v45 * p19.fo
	p19.tail = nil
	p19.ready = false
	return true
end
function v_u_5.setReady(p46, p47) -- name: setReady
	if not p46.ready then
		p46.ready = true
		p46.readyAt = p47
	end
end
function v_u_5.target(p48) -- name: target
	if p48.started then
		return p48.toScene, p48.toShot
	else
		return nil, nil
	end
end
function v_u_5.busy(p49, p50) -- name: busy
	-- upvalues: (copy) v_u_13
	if p50 ~= nil then
		v_u_13(p49, p50)
	end
	return p49.phase ~= "idle"
end
function v_u_5.step(p51, p52) -- name: step
	-- upvalues: (copy) v_u_13
	v_u_13(p51, p52)
	local v53 = p51.phase
	local v54 = 1
	if v53 == "glide" then
		if p51.dur > 0 then
			local v55 = (p52 - p51.t0) / p51.dur
			v54 = math.clamp(v55, 0, 1)
		else
			v54 = 1
		end
	elseif v53 == "fadeOut" then
		local v56 = (p52 - p51.t0) / p51.fo
		v54 = math.clamp(v56, 0, 1)
	elseif v53 == "wait" then
		local v57 = (p52 - p51.t0) / p51.sm.TUNE.streamWaitMax
		v54 = math.clamp(v57, 0, 1)
	elseif v53 == "fadeIn" then
		local v58 = (p52 - p51.t0) / p51.fi
		v54 = math.clamp(v58, 0, 1)
	end
	local v59 = p51.arrivedPending
	p51.arrivedPending = false
	local v60 = v53 == "glide" and "glide" or (v53 ~= "idle" and "cut" or "hold")
	local v61 = 0
	if v53 == "glide" then
		v61 = p51.dur
	elseif v53 == "fadeOut" then
		v61 = p51.fo
	elseif v53 == "fadeIn" then
		v61 = p51.fi
	end
	local v62 = {
		["phase"] = v53,
		["t"] = v54,
		["from"] = {
			["scene"] = p51.fromScene,
			["shot"] = p51.fromShot,
			["free"] = v53 ~= "idle"
		},
		["to"] = {
			["scene"] = p51.toScene,
			["shot"] = p51.toShot
		}
	}
	local v63 = p51.phase
	local v64
	if v63 == "fadeOut" then
		local v65 = (p52 - p51.t0) / p51.fo
		local v66 = math.clamp(v65, 0, 1)
		v64 = v66 * v66
	elseif v63 == "wait" then
		v64 = 1
	elseif v63 == "fadeIn" then
		local v67 = (p52 - p51.t0) / p51.fi
		local v68 = math.clamp(v67, 0, 1)
		v64 = 1 - (1 - (1 - v68) * (1 - v68))
	else
		local v69 = p51.tail
		if v69 == nil then
			v64 = 0
		else
			local v70 = (p52 - v69.t0) / v69.dur
			if v70 >= 1 then
				p51.tail = nil
				v64 = 0
			else
				local v71 = v69.a0
				local v72 = math.clamp(v70, 0, 1)
				v64 = v71 * (1 - (1 - (1 - v72) * (1 - v72)))
			end
		end
	end
	v62.alpha = v64
	v62.arrived = v59
	v62.seq = p51.seq
	v62.dur = v61
	v62.cam = v60
	v62.kind = p51.kind
	return v62
end
return v_u_5