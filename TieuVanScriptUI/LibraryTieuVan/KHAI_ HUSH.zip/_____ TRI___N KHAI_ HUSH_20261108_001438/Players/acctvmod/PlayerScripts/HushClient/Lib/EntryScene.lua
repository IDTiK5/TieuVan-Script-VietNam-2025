-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryScene

local v_u_1 = require(script.Parent:WaitForChild("EntryMath"))
local v_u_2 = {
	["HAND"] = 1.2,
	["FADE_IN"] = 0.5,
	["ISO_FOV"] = 22
}
local v_u_3 = {
	["walk_in"] = "EntryKindWalk",
	["heli_rope"] = "EntryKindHeli",
	["pickup_drop"] = "EntryKindPickup"
}
v_u_2.KIND_MODULE = v_u_3
local v_u_4 = {}
local v_u_5 = {}
function v_u_2.kindOf(p6) -- name: kindOf
	-- upvalues: (copy) v_u_3, (ref) v_u_4, (ref) v_u_5
	if type(p6) ~= "string" then
		return nil
	end
	local v7 = v_u_3[p6]
	if not v7 then
		return nil
	end
	if v_u_4[v7] then
		return v_u_4[v7]
	end
	if v_u_5[v7] then
		return nil
	end
	local v8 = script.Parent
	local v9
	if v8 then
		v9 = v8:FindFirstChild(v7)
	else
		v9 = nil
	end
	if not v9 then
		v_u_5[v7] = true
		return nil
	end
	local v10 = require
	local v11, v12 = pcall(v10, v9)
	if v11 and type(v12) == "table" then
		local v13 = v12.sample
		if type(v13) == "function" then
			v_u_4[v7] = v12
			return v12
		end
	end
	v_u_5[v7] = true
	return nil
end
function v_u_2.reset() -- name: reset
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	v_u_4 = {}
	v_u_5 = {}
end
function v_u_2.geo(p14) -- name: geo
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v15, v16 = v_u_1.axes(p14.yaw)
	local v17 = {}
	local v18 = {}
	for v19, v20 in p14.m do
		v17[v19] = {
			["x"] = v20.x,
			["y"] = v20.y,
			["z"] = v20.z
		}
		v18[v19] = v20.u
	end
	local v21 = {
		["k"] = p14.k,
		["n"] = #p14.m,
		["dur"] = p14.dur,
		["seed"] = p14.seed or 0,
		["side"] = p14.side == -1 and -1 or 1,
		["yaw"] = p14.yaw,
		["f"] = v15,
		["r"] = v16,
		["c"] = {
			["x"] = p14.bx,
			["y"] = p14.by,
			["z"] = p14.bz
		},
		["cen"] = v_u_1.centroid(v17),
		["places"] = v17,
		["uids"] = v18
	}
	local v22 = v_u_2.HAND
	local v23 = p14.dur * 0.4
	v21.hand = math.min(v22, v23)
	v21.test = p14.test == true
	return v21
end
function v_u_2.blendCam(p24, p25, p26) -- name: blendCam
	if p26 <= 0 then
		return p24
	end
	if p26 >= 1 then
		return p25
	end
	local v27 = {}
	local v28 = p24.px
	v27.px = v28 + (p25.px - v28) * p26
	local v29 = p24.py
	v27.py = v29 + (p25.py - v29) * p26
	local v30 = p24.pz
	v27.pz = v30 + (p25.pz - v30) * p26
	local v31 = p24.tx
	v27.tx = v31 + (p25.tx - v31) * p26
	local v32 = p24.ty
	v27.ty = v32 + (p25.ty - v32) * p26
	local v33 = p24.tz
	v27.tz = v33 + (p25.tz - v33) * p26
	local v34 = p24.fov
	v27.fov = v34 + (p25.fov - v34) * p26
	return v27
end
function v_u_2.iso(p35, p36, p37, p38, p39) -- name: iso
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v40 = p39 or 0.7853981633974483
	local v41 = v_u_1.axes(p36)
	local v42 = math.cos(v40)
	local v43 = math.sin(v40)
	return {
		["px"] = p35.x - v41.x * v42 * p37,
		["py"] = p35.y + v43 * p37,
		["pz"] = p35.z - v41.z * v42 * p37,
		["tx"] = p35.x,
		["ty"] = p35.y,
		["tz"] = p35.z,
		["fov"] = p38 or v_u_2.ISO_FOV
	}
end
function v_u_2.fade(p44) -- name: fade
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	return p44 <= 0 and 1 or 1 - v_u_1.smooth(p44 / v_u_2.FADE_IN)
end
local function v_u_49(p45) -- name: plainState
	local v46 = {}
	for v47, v48 in p45.places do
		v46[v47] = {
			["x"] = nil,
			["y"] = nil,
			["z"] = nil,
			["yaw"] = nil,
			["pose"] = "idle",
			["k"] = 0,
			["vx"] = 0,
			["vz"] = 0,
			["vis"] = false,
			["x"] = v48.x,
			["y"] = v48.y,
			["z"] = v48.z,
			["yaw"] = p45.yaw
		}
	end
	return {
		["cam"] = nil,
		["actors"] = nil,
		["props"] = nil,
		["actors"] = v46,
		["props"] = {}
	}
end
function v_u_2.check(p50) -- name: check
	-- upvalues: (copy) v_u_1
	if type(p50) == "table" then
		local v51 = p50.actors
		if type(v51) == "table" then
			local v52 = p50.props
			if type(v52) == "table" then
				if p50.cam then
					for _, v53 in {
						"px",
						"py",
						"pz",
						"tx",
						"ty",
						"tz",
						"fov"
					} do
						if v_u_1.finite(p50.cam[v53]) then
							continue
						end
						return false
					end
				end
				for _, v54 in p50.actors do
					for _, v55 in {
						"x",
						"y",
						"z",
						"yaw",
						"k",
						"vx",
						"vz"
					} do
						if v_u_1.finite(v54[v55]) then
							continue
						end
						return false
					end
				end
				for _, v56 in p50.props do
					if type(v56) ~= "table" then
						continue
					end
					for _, v57 in v56 do
						if type(v57) == "number" and not v_u_1.finite(v57) then
							return false
						end
						if type(v57) ~= "table" then
							continue
						end
						for _, v58 in v57 do
							if type(v58) == "number" and not v_u_1.finite(v58) then
								return false
							end
							if type(v58) ~= "table" then
								continue
							end
							for _, v59 in v58 do
								if type(v59) ~= "number" or v_u_1.finite(v59) then
									continue
								end
								return false
							end
						end
					end
				end
				return true
			end
		end
	end
	return false
end
function v_u_2.sample(p60, p61, p62) -- name: sample
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_49
	local v63 = not v_u_1.finite(p61) and 0 or p61
	local v64 = v_u_2.kindOf(p60.k)
	local v65 = nil
	local v66
	if v64 then
		local v67 = v64.sample
		local v68
		v68, v66 = pcall(v67, p60, v63)
		if v68 then
			if not v_u_2.check(v66) then
				v66 = v65
			end
		else
			v66 = v65
		end
	else
		v66 = v65
	end
	local v69 = v66 or v_u_49(p60)
	if v69.cam and p62 then
		local v70 = v_u_1.smooth(v_u_1.unlerp(p60.dur - p60.hand, p60.dur, v63))
		v69.cam = v_u_2.blendCam(v69.cam, p62, v70)
	end
	v69.t = v63
	v69.fade = v_u_2.fade(v63)
	return v69
end
function v_u_2.cues(p71) -- name: cues
	-- upvalues: (copy) v_u_2
	local v72 = v_u_2.kindOf(p71.k)
	if v72 then
		local v73 = v72.cues
		if type(v73) == "function" then
			local v74 = v72.cues
			local v75, v76 = pcall(v74, p71)
			if v75 and type(v76) == "table" then
				return v76
			end
		end
	end
	return {}
end
function v_u_2.tail(p77) -- name: tail
	-- upvalues: (copy) v_u_2
	local v78 = v_u_2.kindOf(p77.k)
	if v78 then
		local v79 = v78.TAIL
		if type(v79) == "number" then
			return v78.TAIL
		end
	end
	return 0
end
return v_u_2