-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AshgroveEndFx

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = {
	["SMOKE_SECONDS"] = 14,
	["PLUG_SECONDS"] = 5,
	["COLLAPSE_SECONDS"] = 9,
	["MAX_EMITTERS"] = 24,
	["RANGE"] = 700
}
local v_u_7 = {
	["smoke"] = 9,
	["plug"] = 60,
	["collapse"] = 70
}
function v_u_6.window(p8, p9, p10) -- name: window
	if type(p8) == "number" and (p8 == p8 and (type(p9) == "number" and (p9 == p9 and (type(p10) == "number" and (p10 == p10 and p10 > 0))))) then
		if p9 < p8 or p8 + p10 < p9 then
			return nil
		else
			return (p9 - p8) / p10
		end
	else
		return nil
	end
end
function v_u_6.rateFor(p11, p12) -- name: rateFor
	-- upvalues: (copy) v_u_7
	local v13 = v_u_7[p11]
	if not v13 or (type(p12) ~= "number" or p12 ~= p12) then
		return 0
	end
	local v14 = math.clamp(p12, 0, 1)
	local v15 = v14 / 0.12
	local v16 = math.clamp(v15, 0, 1)
	local v17 = (1 - v14) / 0.55
	local v18 = math.clamp(v17, 0, 1)
	return v13 * math.min(v16, v18)
end
local v_u_19 = nil
local v_u_20 = {}
local v_u_21 = false
local v_u_22 = nil
local v_u_23 = {}
local v_u_24 = 0
local v_u_25 = nil
local function v_u_42(p26, p27, p28, p29, p30) -- name: makeEmitter
	-- upvalues: (copy) v_u_20, (copy) v_u_6, (ref) v_u_19, (copy) v_u_5
	if v_u_20[p26] then
		return false
	end
	local v31 = 0
	for _ in v_u_20 do
		v31 = v31 + 1
	end
	if v_u_6.MAX_EMITTERS <= v31 then
		return false
	end
	local v32 = Instance.new("Part")
	v32.Name = "Fx_" .. p26
	v32.Anchored = true
	v32.CanCollide = false
	v32.CanQuery = false
	v32.CanTouch = false
	v32.CastShadow = false
	v32.Transparency = 1
	local v33 = p27 == "smoke" and 2 or 8
	local v34 = p27 == "smoke" and 2 or 8
	v32.Size = Vector3.new(v33, 1, v34)
	v32.CFrame = CFrame.new(p28)
	local v35 = Instance.new("ParticleEmitter")
	v35.Name = "Cloud"
	v35.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v35.Rate = 0
	v35.Enabled = false
	local v36
	if p27 == "smoke" then
		v36 = NumberRange.new(5, 8)
	else
		v36 = NumberRange.new(3.5, 6)
	end
	v35.Lifetime = v36
	local v37
	if p27 == "smoke" then
		v37 = NumberRange.new(4, 7)
	else
		v37 = NumberRange.new(5, 11)
	end
	v35.Speed = v37
	local v38
	if p27 == "smoke" then
		v38 = Vector2.new(12, 12)
	else
		v38 = Vector2.new(70, 70)
	end
	v35.SpreadAngle = v38
	v35.EmissionDirection = Enum.NormalId.Top
	v35.Acceleration = p27 == "smoke" and Vector3.new(1.2, 1.5, 0.6) or Vector3.new(0, -1.5, 0)
	v35.Rotation = NumberRange.new(0, 360)
	v35.RotSpeed = NumberRange.new(-15, 15)
	local v39
	if p27 == "smoke" then
		v39 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 11) })
	else
		v39 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 4), NumberSequenceKeypoint.new(1, 18) })
	end
	v35.Size = v39
	v35.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.15, 0.55), NumberSequenceKeypoint.new(1, 1) })
	local v40
	if p27 == "smoke" then
		v40 = ColorSequence.new(Color3.fromRGB(78, 76, 74), Color3.fromRGB(118, 116, 114))
	else
		v40 = ColorSequence.new(Color3.fromRGB(128, 120, 108), Color3.fromRGB(150, 144, 134))
	end
	v35.Color = v40
	v35.LightEmission = 0
	v35.LightInfluence = 0.8
	v35.Parent = v32
	local v41 = v_u_19
	if not (v41 and v41.Parent) then
		v41 = Instance.new("Folder")
		v41.Name = "AshgroveEndFx"
		v41.Parent = v_u_5
		v_u_19 = v41
	end
	v32.Parent = v41
	v_u_20[p26] = {
		["part"] = v32,
		["pe"] = v35,
		["kind"] = p27,
		["at"] = p29,
		["dur"] = p30
	}
	return true
end
local function v_u_48(p43) -- name: findTagged
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v44 = {}
	for _, v45 in v_u_2:GetTagged(p43) do
		if not v45:IsDescendantOf(v_u_5) then
			continue
		end
		if v45:IsA("BasePart") then
			table.insert(v44, v45)
		else
			if not v45:IsA("Model") then
				continue
			end
			local v46 = v45:GetPivot()
			local v47 = Instance.new("Part")
			v47.Position = v46.Position
			table.insert(v44, v47)
		end
	end
	return v44
end
function v_u_6.poll(p49) -- name: poll
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_5, (copy) v_u_23, (copy) v_u_6, (copy) v_u_48, (copy) v_u_42, (ref) v_u_25, (copy) v_u_20
	local v50 = p49 or v_u_1.now()
	local v51 = v_u_3:FindFirstChild("HushRuntime")
	if v51 then
		v51 = v51:FindFirstChild("Raid")
	end
	local v52 = v_u_5.CurrentCamera
	local v53 = not v52 and Vector3.new(0, 0, 0) or v52.CFrame.Position
	if v51 then
		local v54 = v51:GetAttribute("AshTramCut")
		if type(v54) == "number" and (v54 == v54 and (not v_u_23["cut" .. tostring(v54)] and v_u_6.window(v54, v50, v_u_6.SMOKE_SECONDS) ~= nil)) then
			v_u_23["cut" .. tostring(v54)] = true
			for v55, v56 in v_u_48("AshMast") do
				if (v56.Position - v53).Magnitude > v_u_6.RANGE then
					continue
				end
				v_u_42("mast" .. v55, "smoke", v56.Position + Vector3.new(0, 14, 0), v54, v_u_6.SMOKE_SECONDS)
			end
		end
		local v57 = v51:GetAttribute("AshPlug")
		if v57 == "open" and (v_u_25 ~= nil and (v_u_25 ~= "open" and not v_u_23["plug" .. tostring(v51:GetAttribute("RaidId"))])) then
			v_u_23["plug" .. tostring(v51:GetAttribute("RaidId"))] = true
			for v58, v59 in v_u_48("AshPlug") do
				if (v59.Position - v53).Magnitude > v_u_6.RANGE then
					continue
				end
				v_u_42("plugblast" .. v58, "plug", v59.Position + Vector3.new(0, -1, -4.8), v50, v_u_6.PLUG_SECONDS)
			end
		end
		v_u_25 = v57
		local v60 = v51:GetAttribute("AshCollapse")
		if type(v60) == "number" and (v60 == v60 and (not v_u_23["col" .. tostring(v60)] and v_u_6.window(v60, v50, v_u_6.COLLAPSE_SECONDS) ~= nil)) then
			v_u_23["col" .. tostring(v60)] = true
			for v61, v62 in v_u_48("AshCageGate") do
				if (v62.Position - v53).Magnitude > v_u_6.RANGE then
					continue
				end
				v_u_42("gate" .. v61, "collapse", v62.Position - Vector3.new(0, 1, 0), v60, v_u_6.COLLAPSE_SECONDS)
			end
			for v63, v64 in v_u_48("AshPlug") do
				if (v64.Position - v53).Magnitude > v_u_6.RANGE then
					continue
				end
				v_u_42("plugcol" .. v63, "collapse", v64.Position + Vector3.new(0, -1, -4.8), v60, v_u_6.COLLAPSE_SECONDS)
			end
		end
	else
		v_u_25 = nil
		table.clear(v_u_23)
	end
	for v65, v66 in v_u_20 do
		local v67 = v_u_6.window(v66.at, v50, v66.dur)
		if v67 == nil then
			v66.pe.Enabled = false
			v66.pe.Rate = 0
			if v66.at + v66.dur + 9 >= v50 then
				continue
			end
			v66.part:Destroy()
			v_u_20[v65] = nil
		else
			local v68 = v_u_6.rateFor(v66.kind, v67)
			v66.pe.Rate = v68
			v66.pe.Enabled = v68 > 0.01
		end
	end
end
function v_u_6.count() -- name: count
	-- upvalues: (copy) v_u_20
	local v69 = 0
	for _ in v_u_20 do
		v69 = v69 + 1
	end
	return v69
end
function v_u_6.stop() -- name: stop
	-- upvalues: (ref) v_u_22, (copy) v_u_20, (copy) v_u_23, (ref) v_u_25, (ref) v_u_19, (ref) v_u_21
	if v_u_22 then
		v_u_22:Disconnect()
		v_u_22 = nil
	end
	for v70, v71 in v_u_20 do
		v71.part:Destroy()
		v_u_20[v70] = nil
	end
	table.clear(v_u_23)
	v_u_25 = nil
	if v_u_19 then
		v_u_19:Destroy()
		v_u_19 = nil
	end
	v_u_21 = false
end
function v_u_6.start() -- name: start
	-- upvalues: (ref) v_u_21, (ref) v_u_22, (copy) v_u_4, (ref) v_u_24, (copy) v_u_6
	if not v_u_21 then
		v_u_21 = true
		v_u_22 = v_u_4.Heartbeat:Connect(function(p72)
			-- upvalues: (ref) v_u_24, (ref) v_u_6
			v_u_24 = v_u_24 + p72
			if v_u_24 >= 0.25 then
				v_u_24 = 0
				local v73 = v_u_6.poll
				local v74, v75 = pcall(v73)
				if not v74 then
					warn("[AshgroveEndFx] poll failed:", v75)
				end
			end
		end)
	end
end
return v_u_6