-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryKindHeli

local v_u_1 = require(script.Parent:WaitForChild("EntryMath"))
local v_u_5 = {
	["HOVER"] = 30,
	["START_BACK"] = 260,
	["START_UP"] = 40,
	["FLY_IN"] = 3.6,
	["ROPE_DROP"] = 0.8,
	["SLIDE"] = 2.4,
	["STAGGER"] = 0.7,
	["RECOVER"] = 0.4,
	["TAIL"] = 3,
	["DOOR"] = {
		["x"] = 6.3,
		["y"] = 3,
		["z"] = 0.7
	},
	["DOOR_X_LEFT"] = -4.7,
	["ROPE_GAP"] = 1.6,
	["GRIP_UP"] = 2,
	["GRIP_BACK"] = 0.56,
	["LIFT"] = 3,
	["RETRACT"] = 0.8,
	["timing"] = function(p2) -- name: timing
		-- upvalues: (copy) v_u_5
		local v3 = v_u_5.FLY_IN + v_u_5.ROPE_DROP
		local v4 = v3 + v_u_5.STAGGER * (p2.n - 1) + v_u_5.SLIDE
		return {
			["flyIn"] = v_u_5.FLY_IN,
			["ropesAt"] = v_u_5.FLY_IN,
			["slideStart"] = v3,
			["lastLand"] = v4,
			["leave"] = v4 - 0.3
		}
	end
}
local function v_u_18(p6, p7, p8, p9, p10, p11) -- name: heliPoint
	local v12 = p6.pitch or 0
	local v13 = math.cos(v12)
	local v14 = p6.pitch or 0
	local v15 = math.sin(v14)
	local v16 = p10 * v13 - p11 * v15
	local v17 = p10 * v15 + p11 * v13
	return {
		["x"] = p6.x + p8.x * p9 - p7.x * v17,
		["y"] = p6.y + v16,
		["z"] = p6.z + p8.z * p9 - p7.z * v17
	}
end
function v_u_5.ropeTop(p19, p20, p21, p22) -- name: ropeTop
	-- upvalues: (copy) v_u_5, (copy) v_u_18
	local v23 = v_u_5.DOOR
	local v24 = v_u_18
	local v25
	if p22 == 1 then
		v25 = v23.x
	else
		v25 = v_u_5.DOOR_X_LEFT
	end
	return v24(p19, p21, p20, v25, v23.y, v23.z)
end
function v_u_5.slot(p26, p27) -- name: slot
	-- upvalues: (copy) v_u_5
	local v28 = p26.n
	local v29 = 0
	for v30 = 1, v28 do
		local v31 = p26.places[v30]
		local v32 = v31.x * p26.r.x + v31.z * p26.r.z
		local v33 = p26.places[p27]
		if v32 >= v33.x * p26.r.x + v33.z * p26.r.z then
			local v34 = p26.places[v30]
			local v35 = v34.x * p26.r.x + v34.z * p26.r.z
			local v36 = p26.places[p27]
			if v35 ~= v36.x * p26.r.x + v36.z * p26.r.z or v30 >= p27 then
				continue
			end
		end
		v29 = v29 + 1
	end
	local v37 = v28 / 2
	local v38 = v29 < math.floor(v37) and -1 or 1
	local v39 = 0
	for v40 = 1, v28 do
		if v40 == p27 then
			continue
		end
		local v41 = 0
		for v42 = 1, v28 do
			local v43 = p26.places[v42]
			local v44 = v43.x * p26.r.x + v43.z * p26.r.z
			local v45 = p26.places[v40]
			if v44 >= v45.x * p26.r.x + v45.z * p26.r.z then
				local v46 = p26.places[v42]
				local v47 = v46.x * p26.r.x + v46.z * p26.r.z
				local v48 = p26.places[v40]
				if v47 ~= v48.x * p26.r.x + v48.z * p26.r.z or v42 >= v40 then
					continue
				end
			end
			v41 = v41 + 1
		end
		local v49 = v28 / 2
		if (v41 < math.floor(v49) and -1 or 1) ~= v38 then
			break
		end
		local v50 = p26.places[v40]
		local v51 = v50.x * p26.f.x + v50.z * p26.f.z
		local v52 = p26.places[p27]
		if v52.x * p26.f.x + v52.z * p26.f.z >= v51 then
			local v53 = p26.places[v40]
			local v54 = v53.x * p26.f.x + v53.z * p26.f.z
			local v55 = p26.places[p27]
			if v54 ~= v55.x * p26.f.x + v55.z * p26.f.z or v40 >= p27 then
				break
			end
		end
		v39 = v39 + 1
	end
	local v56 = v_u_5.DOOR.z
	if v28 >= 3 then
		local v57
		if v39 == 0 then
			v57 = -v_u_5.ROPE_GAP
		else
			v57 = v_u_5.ROPE_GAP
		end
		v56 = v56 + v57
	end
	return v38, v56
end
function v_u_5.ropeTopOf(p58, p59, p60) -- name: ropeTopOf
	-- upvalues: (copy) v_u_5, (copy) v_u_18
	local v61, v62 = v_u_5.slot(p59, p60)
	local v63 = v_u_18
	local v64 = p59.f
	local v65 = p59.r
	local v66
	if v61 == 1 then
		v66 = v_u_5.DOOR.x
	else
		v66 = v_u_5.DOOR_X_LEFT
	end
	return v63(p58, v64, v65, v66, v_u_5.DOOR.y, v62)
end
local function v_u_70(p67, p68) -- name: gripEnd
	-- upvalues: (copy) v_u_5
	local v69 = p67.places[p68]
	return {
		["x"] = v69.x - p67.f.x * v_u_5.GRIP_BACK,
		["y"] = v69.y + v_u_5.LIFT + v_u_5.GRIP_UP,
		["z"] = v69.z - p67.f.z * v_u_5.GRIP_BACK
	}
end
v_u_5.gripEnd = v_u_70
local function v_u_77(p71, p72, p73) -- name: ropeFoot
	local v74 = p72.y - p73
	local v75 = p71.y - p72.y
	local v76 = v74 / math.max(v75, 1)
	return {
		["x"] = p72.x + (p72.x - p71.x) * v76,
		["y"] = p73,
		["z"] = p72.z + (p72.z - p71.z) * v76
	}
end
local function v_u_99(p78, p79, p80, p81) -- name: heliState
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v82 = p78.f
	local v83 = p81.x
	local v84 = p81.y
	local v85 = p81.z
	local v86 = true
	local v87
	if p80 < p79.flyIn then
		local v88 = v_u_1.clamp(p80 / p79.flyIn, 0, 1)
		local v89 = 1 - v_u_1.easeOut(v88)
		v83 = v83 - v82.x * v_u_5.START_BACK * v89
		v85 = v85 - v82.z * v_u_5.START_BACK * v89
		v84 = v84 + v_u_5.START_UP * v89
		local v90 = -0.10471975511965978 * v89
		local v91 = 3.141592653589793 * v88
		v87 = v90 + math.sin(v91) * 0.20943951023931956
	else
		v87 = 0
	end
	if p79.flyIn <= p80 then
		local v92 = p80 - p79.flyIn
		local v93 = v92 * 1.3
		v83 = v83 + math.sin(v93) * 0.25
		local v94 = v92 * 1.1
		v85 = v85 + math.cos(v94) * 0.25
		local v95 = v92 * 2.1
		v84 = v84 + math.sin(v95) * 0.18
	end
	if p79.leave <= p80 then
		local v96 = p80 - p79.leave
		local v97 = 11 * v96 * v96
		local v98 = 6 * v96 * v96
		v83 = v83 + v82.x * v97
		v85 = v85 + v82.z * v97
		v84 = v84 + v98
		v87 = -0.17453292519943295 * v_u_1.smooth(v96 / 1.2)
		if v_u_5.TAIL + 6 < v96 then
			v86 = false
		end
	end
	return {
		["x"] = v83,
		["y"] = v84,
		["z"] = v85,
		["yaw"] = p78.yaw,
		["pitch"] = v87,
		["vis"] = v86
	}
end
function v_u_5.sample(p100, p101) -- name: sample
	-- upvalues: (copy) v_u_5, (copy) v_u_99, (copy) v_u_77, (copy) v_u_70, (copy) v_u_1
	local v102 = v_u_5.timing(p100)
	local v103 = p100.f
	local v104 = p100.r
	local v105 = p100.cen
	local v106 = v_u_99(p100, v102, p101, {
		["x"] = v105.x,
		["y"] = v105.y + v_u_5.HOVER,
		["z"] = v105.z
	})
	local v107 = v102.leave
	local v108 = v102.lastLand + 0.1
	local v109 = math.max(v107, v108)
	local v110 = {}
	for v111, v112 in p100.places do
		local v113 = v_u_5.slot(p100, v111)
		local v114 = v_u_5.ropeTopOf(v106, p100, v111)
		local v115 = v_u_77(v114, v_u_70(p100, v111), v112.y + 0.2)
		local v116 = v102.ropesAt > p101 and 0 or v_u_1.easeIn((p101 - v102.ropesAt) / v_u_5.ROPE_DROP)
		if v109 <= p101 then
			v116 = v116 * (1 - v_u_1.smooth((p101 - v109) / v_u_5.RETRACT))
		end
		local v117 = {
			["id"] = v111,
			["side"] = v113,
			["tx"] = v114.x,
			["ty"] = v114.y,
			["tz"] = v114.z,
			["gx"] = v115.x,
			["gy"] = v115.y,
			["gz"] = v115.z,
			["len"] = v116
		}
		table.insert(v110, v117)
	end
	local v118 = {}
	for v119, v120 in p100.places do
		local v121 = v_u_5.ropeTopOf(v106, p100, v119)
		local v122 = v_u_70(p100, v119)
		local v123 = v102.slideStart + v_u_5.STAGGER * (v119 - 1)
		local v124 = v_u_1.clamp((p101 - v123) / v_u_5.SLIDE, 0, 1)
		local v125 = {
			["x"] = nil,
			["y"] = nil,
			["z"] = nil,
			["yaw"] = nil,
			["pose"] = "idle",
			["k"] = 0,
			["vx"] = 0,
			["vz"] = 0,
			["vis"] = true,
			["x"] = v120.x,
			["y"] = v120.y,
			["z"] = v120.z,
			["yaw"] = p100.yaw
		}
		if p101 < v123 or v124 < 1 then
			local v126 = v_u_1.easeInOut(v124)
			local v127 = v_u_1.lerp(v121.y, v122.y, v126)
			local v128 = v_u_1.clamp
			local v129 = v121.y - v127
			local v130 = v121.y - v122.y
			local v131 = v128(v129 / math.max(v130, 1), 0, 1)
			local v132 = v_u_1.lerp(v121.x, v122.x, v131)
			local v133 = v_u_1.lerp(v121.z, v122.z, v131)
			v125.x = v132 + p100.f.x * v_u_5.GRIP_BACK
			v125.z = v133 + p100.f.z * v_u_5.GRIP_BACK
			v125.y = v127 - v_u_5.GRIP_UP - v_u_5.LIFT
			v125.pose = "rappel"
			v125.k = v124
			v125.vis = v123 <= p101
			v125.hx = v132
			v125.hy = v127
			v125.hz = v133
		else
			local v134 = p101 - (v123 + v_u_5.SLIDE)
			if v134 < v_u_5.RECOVER then
				v125.pose = "crouch_land"
				v125.k = 1 - v_u_1.smooth(v134 / v_u_5.RECOVER)
			end
		end
		v118[v119] = v125
	end
	local v135 = (v102.flyIn - 0.6 > p101 or p101 >= v102.leave + 1.5) and 0 or v_u_1.smooth((p101 - (v102.flyIn - 0.6)) / 0.8) * (1 - v_u_1.smooth((p101 - v102.leave) / 1.5))
	local v136 = v102.flyIn
	local v137 = {
		["x"] = v105.x + v103.x * 18 - v104.x * p100.side * 4,
		["y"] = v105.y + 2.5,
		["z"] = v105.z + v103.z * 18 - v104.z * p100.side * 4
	}
	local v138 = {
		["x"] = v105.x + v103.x * 34 + v104.x * p100.side * 14,
		["y"] = v105.y + 10,
		["z"] = v105.z + v103.z * 34 + v104.z * p100.side * 14
	}
	local v139 = {
		["x"] = v105.x + v103.x * 14 + v104.x * p100.side * 8,
		["y"] = v105.y + 4,
		["z"] = v105.z + v103.z * 14 + v104.z * p100.side * 8
	}
	local v140 = v_u_1.smooth(v_u_1.unlerp(2.4, v102.slideStart + 0.2, p101))
	local v141 = p100.dur - p100.hand
	local v142 = v_u_1.smooth(v_u_1.unlerp(v102.slideStart + 0.8, v141, p101))
	local v143 = v_u_1.mix(v_u_1.mix(v137, v138, v140), v139, v142)
	local v144 = {
		["x"] = v105.x,
		["y"] = v105.y + 14,
		["z"] = v105.z
	}
	local v145 = {
		["x"] = v105.x,
		["y"] = v105.y + 1.5,
		["z"] = v105.z
	}
	local v146 = {
		["x"] = v106.x,
		["y"] = v106.y,
		["z"] = v106.z
	}
	local v147 = v_u_1.smooth(v_u_1.unlerp(v136 - 0.5, v102.slideStart, p101))
	local v148 = v_u_1.smooth(v_u_1.unlerp(v102.slideStart + 0.8, v141, p101))
	local v149 = v_u_1.mix(v_u_1.mix(v146, v144, v147), v145, v148)
	local v150 = v_u_1.lerp(v_u_1.lerp(60, 52, v140), 50, v142)
	return {
		["cam"] = {
			["px"] = v143.x,
			["py"] = v143.y,
			["pz"] = v143.z,
			["tx"] = v149.x,
			["ty"] = v149.y,
			["tz"] = v149.z,
			["fov"] = v150
		},
		["actors"] = v118,
		["props"] = {
			["heli"] = v106,
			["ropes"] = v110,
			["dust"] = {
				["x"] = v105.x,
				["y"] = v105.y,
				["z"] = v105.z,
				["a"] = v135
			}
		}
	}
end
function v_u_5.cues(p151) -- name: cues
	-- upvalues: (copy) v_u_5
	local v152 = v_u_5.timing(p151)
	return {
		{
			["t"] = 0.1,
			["name"] = "heli_flyby"
		},
		{
			["t"] = nil,
			["name"] = "rope_drop",
			["t"] = v152.slideStart
		},
		{
			["t"] = nil,
			["name"] = "heli_leave",
			["t"] = v152.leave
		}
	}
end
return v_u_5