-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PromptPredict

local v1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = {}
local v_u_4 = {
	["pickups"] = 0,
	["restored"] = 0,
	["confirmed"] = 0,
	["opened"] = 0
}
local function v_u_7(p5) -- name: itemModel
	local v6 = p5.Parent
	while v6 and v6 ~= workspace do
		if v6:GetAttribute("ItemUid") ~= nil then
			return v6
		end
		v6 = v6.Parent
	end
	return nil
end
local function v_u_10(p8) -- name: containerOf
	local v9 = p8.Parent
	while v9 and v9 ~= workspace do
		if v9:GetAttribute("ContainerId") ~= nil then
			return v9
		end
		v9 = v9.Parent
	end
	return nil
end
function v1.onTriggered(p11, p12) -- name: onTriggered
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10
	if v_u_2:GetAttribute("Place") == "Raid" then
		local v13 = p11.ActionText
		local v14 = v_u_7(p11)
		if v14 and v13 == "Pick up" then
			if not v_u_3[v14] then
				local v15 = {
					["model"] = v14,
					["prompt"] = p11,
					["parts"] = {},
					["t"] = os.clock()
				}
				local v16 = v_u_2:GetNetworkPing()
				local v17 = math.clamp(v16, 0, 1) * 4 + 0.9
				v15.win = math.max(1.5, v17)
				local v18 = nil
				for _, v19 in v14:IsA("BasePart") and { v14 } or {} do
					v15.parts[v19] = v19.LocalTransparencyModifier
				end
				for _, v20 in v14:GetDescendants() do
					if not v20:IsA("BasePart") then
						continue
					end
					v15.parts[v20] = v20.LocalTransparencyModifier
					v18 = v18 or v20.Position
				end
				for v21 in v15.parts do
					v21.LocalTransparencyModifier = 1
				end
				p11.Enabled = false
				v_u_3[v14] = v15
				local v22 = v_u_4
				v22.pickups = v22.pickups + 1
				local v23 = p12 and p12.controllers
				if v23 then
					v23 = p12.controllers.Audio
				end
				if v23 and (v23.play3D and v18) then
					local v24 = v23.play3D
					pcall(v24, "item_pickup", v18, {
						["volume"] = 1
					})
				end
			end
		else
			if v_u_10(p11) and v13 == "Search" then
				local v25 = p12 and p12.controllers
				if v25 then
					v25 = p12.controllers.InventoryUI
				end
				if v25 and (v25.open and (v25.isOpen and not v25.isOpen())) then
					local v26 = v25.open
					pcall(v26)
					local v27 = v_u_4
					v27.opened = v27.opened + 1
				end
			end
			return
		end
	else
		return
	end
end
function v1.step(_) -- name: step
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	if next(v_u_3) ~= nil then
		local v28 = os.clock()
		for v29, v30 in v_u_3 do
			if v29.Parent and v29:IsDescendantOf(workspace) then
				if v28 - v30.t <= v30.win then
					continue
				end
				v_u_3[v29] = nil
				for v31, v32 in v30.parts do
					if not v31.Parent then
						continue
					end
					v31.LocalTransparencyModifier = v32
				end
				if v30.prompt.Parent then
					v30.prompt.Enabled = true
				end
				local v33 = v_u_4
				v33.restored = v33.restored + 1
			else
				v_u_3[v29] = nil
				local v34 = v_u_4
				v34.confirmed = v34.confirmed + 1
			end
		end
	end
end
function v1.state() -- name: state
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v35 = 0
	for _ in v_u_3 do
		v35 = v35 + 1
	end
	return string.format("hidden=%d pickups=%d confirmed=%d restored=%d opened=%d", v35, v_u_4.pickups, v_u_4.confirmed, v_u_4.restored, v_u_4.opened)
end
return v1