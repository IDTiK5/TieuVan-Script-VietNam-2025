-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Atmosphere

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("GuiService")
local v_u_7 = {
	["name"] = "Atmosphere",
	["order"] = 6
}
local v_u_8 = nil
local v_u_9 = v_u_1.LocalPlayer
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = false
local v_u_24 = {
	["map"] = false,
	["on"] = false,
	["at"] = 0,
	["fp"] = false,
	["far"] = false
}
local v_u_25 = "Menu"
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = {}
local v_u_30 = {}
local v_u_31 = {}
local v_u_32 = 0
local v_u_33 = 0
local v_u_34 = false
local v_u_35 = 0
local v_u_36 = 0
local v_u_37 = 0
local v_u_38 = {}
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = nil
local v_u_44 = 3
local v_u_45 = false
local v_u_46 = nil
local v_u_47 = Vector3.new(0, 0, 0)
local v_u_48 = 0
local v_u_49 = RaycastParams.new()
v_u_49.FilterType = Enum.RaycastFilterType.Exclude
local v_u_50 = false
local v_u_51 = nil
local v_u_52 = 0
local v_u_53 = 0
local v_u_54 = 0
local v_u_55 = 0
local v_u_56 = "auto"
local v_u_57 = false
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = 0
local v_u_61 = nil
local v_u_62 = false
local v_u_63 = 0
local v_u_64 = nil
local v_u_65 = false
local v_u_66 = nil
local v_u_67 = false
local v_u_68 = {}
local v_u_69 = false
local v_u_70 = false
local v_u_71 = false
local v_u_72 = -10
local v_u_73 = false
local v_u_74 = nil
local v_u_75 = nil
local v_u_76 = {}
local v_u_77 = {}
v_u_7.changed = nil
local function v_u_78(...) -- name: log
	-- upvalues: (ref) v_u_8
	if v_u_8 then
		v_u_8.log("Atmosphere", ...)
	end
end
local function v_u_95() -- name: ensureInstances
	-- upvalues: (copy) v_u_77, (copy) v_u_2, (ref) v_u_43
	if not v_u_77.atmosphere or v_u_77.atmosphere.Parent ~= v_u_2 then
		local v79 = v_u_77
		local v80 = v_u_2:FindFirstChild("Atmosphere")
		local v81 = v80 and v80.ClassName == "Atmosphere" or v_u_2:FindFirstChildOfClass("Atmosphere")
		if not v81 then
			v81 = Instance.new("Atmosphere")
			v81.Name = "Atmosphere"
			v81.Parent = v_u_2
		end
		v79.atmosphere = v81
	end
	if not v_u_77.sky or v_u_77.sky.Parent ~= v_u_2 then
		local v82 = v_u_77
		local v83 = v_u_2:FindFirstChild("Sky")
		local v84 = v83 and v83.ClassName == "Sky" or v_u_2:FindFirstChildOfClass("Sky")
		if not v84 then
			v84 = Instance.new("Sky")
			v84.Name = "Sky"
			v84.Parent = v_u_2
		end
		v82.sky = v84
		v_u_43 = nil
	end
	if not v_u_77.bloom or v_u_77.bloom.Parent ~= v_u_2 then
		local v85 = v_u_77
		local v86 = v_u_2:FindFirstChild("Bloom")
		local v87 = v86 and v86.ClassName == "BloomEffect" or v_u_2:FindFirstChildOfClass("BloomEffect")
		if not v87 then
			v87 = Instance.new("BloomEffect")
			v87.Name = "Bloom"
			v87.Parent = v_u_2
		end
		v85.bloom = v87
	end
	if not v_u_77.sunrays or v_u_77.sunrays.Parent ~= v_u_2 then
		local v88 = v_u_77
		local v89 = v_u_2:FindFirstChild("SunRays")
		local v90 = v89 and v89.ClassName == "SunRaysEffect" or v_u_2:FindFirstChildOfClass("SunRaysEffect")
		if not v90 then
			v90 = Instance.new("SunRaysEffect")
			v90.Name = "SunRays"
			v90.Parent = v_u_2
		end
		v88.sunrays = v90
	end
	if not v_u_77.dof or v_u_77.dof.Parent ~= v_u_2 then
		local v91 = v_u_77
		local v92 = v_u_2:FindFirstChild("DepthOfField")
		local v93 = v92 and v92.ClassName == "DepthOfFieldEffect" or v_u_2:FindFirstChildOfClass("DepthOfFieldEffect")
		if not v93 then
			v93 = Instance.new("DepthOfFieldEffect")
			v93.Name = "DepthOfField"
			v93.Parent = v_u_2
		end
		v91.dof = v93
	end
	if not v_u_77.grade or v_u_77.grade.Parent ~= v_u_2 then
		local v94 = v_u_2:FindFirstChild("HushGrade")
		if not (v94 and v94:IsA("ColorCorrectionEffect")) then
			v94 = Instance.new("ColorCorrectionEffect")
			v94.Name = "HushGrade"
			v94.Parent = v_u_2
		end
		v_u_77.grade = v94
	end
end
local v_u_96 = {
	["kestrel"] = {
		["interior"] = 0.55,
		["bloom"] = 0.5,
		["bloomThreshold"] = 0.3,
		["exposure"] = -0.2
	},
	["unknown5"] = {
		["interior"] = 0.6,
		["bloom"] = 0.55,
		["bloomThreshold"] = 0.35,
		["exposure"] = -0.35
	},
	["overture"] = {
		["interior"] = 0.6,
		["bloom"] = 0.45,
		["bloomThreshold"] = 0.3,
		["exposure"] = -0.15
	},
	["tokyo"] = {
		["interior"] = 0.55,
		["bloom"] = 0.5,
		["bloomThreshold"] = 0.3,
		["exposure"] = -0.2
	}
}
local v_u_97 = Color3.fromRGB(205, 220, 255)
local v_u_98 = Color3.fromRGB(150, 165, 200)
local v_u_99 = {}
local function v_u_155(p100, p101) -- name: apply
	-- upvalues: (copy) v_u_95, (ref) v_u_10, (ref) v_u_44, (ref) v_u_25, (copy) v_u_4, (copy) v_u_96, (copy) v_u_68, (ref) v_u_66, (copy) v_u_98, (copy) v_u_2, (copy) v_u_99, (copy) v_u_76, (copy) v_u_77, (copy) v_u_97, (ref) v_u_39, (ref) v_u_40
	v_u_95()
	local v102 = p100.Lighting
	local v103 = v_u_10.lowQualityFloor
	local v104 = v_u_44
	local v105 = p100.fx
	if v105 then
		v105 = p100.fx.lum
	end
	local v106
	if v102 then
		v106 = v102.ExposureCompensation
	else
		v106 = v102
	end
	local v107 = v103(v104, v105, v106)
	local v108
	if v_u_25 == "Raid" then
		local v109 = v_u_4:FindFirstChild("HushRuntime")
		local v110
		if v109 then
			v110 = v109:GetAttribute("MapId")
		else
			v110 = nil
		end
		if type(v110) == "string" then
			v108 = v_u_96[v110]
		else
			v108 = nil
		end
	else
		v108 = nil
	end
	local v111 = p100.fx
	local v112 = v_u_68.club
	local v113 = not v112 and 0 or v112.k
	local v114
	if v111 then
		local v115 = v111.moonExp
		v114 = type(v115) ~= "number" and 0 or v111.moonExp * v113
	else
		v114 = 0
	end
	if v102 then
		for v116, v118 in v102 do
			local v118
			if v107 and v116 == "Ambient" then
				v118 = v_u_10.maxColor(v118, v107.Ambient)
			elseif v107 and v116 == "OutdoorAmbient" then
				v118 = v_u_10.maxColor(v118, v107.OutdoorAmbient)
			elseif v107 and v116 == "ExposureCompensation" then
				v118 = v118 + v107.exposure
			end
			if v108 and v116 == "ExposureCompensation" then
				v118 = v118 + v108.exposure
			end
			if v114 ~= 0 and v116 == "ExposureCompensation" then
				v118 = v118 - v114
			end
			if v_u_66 then
				if v116 == "ExposureCompensation" then
					v118 = v118 + v_u_66.exposure
				elseif v116 == "Ambient" and v_u_66.ambient then
					v118 = v_u_10.maxColor(v118, v_u_66.ambient)
				elseif v116 == "OutdoorAmbient" and v_u_66.outdoor then
					v118 = v_u_10.maxColor(v118, v_u_66.outdoor)
				end
			end
			if v116 == "Brightness" then
				v118 = v118 + p101 * 2.2
			elseif v116 == "ExposureCompensation" then
				v118 = v118 + p101 * 0.8
			elseif v116 == "OutdoorAmbient" and p101 > 0 then
				v118 = v118:Lerp(v_u_98, p101 * 0.75)
			end
			if v_u_2[v116] == v118 then
				continue
			end
			v_u_2[v116] = v118
		end
	end
	local v119 = p100.Atmosphere
	if v107 and v119 then
		local v120 = v119.Density
		if type(v120) == "number" then
			table.clear(v_u_99)
			for v121, v122 in v119 do
				v_u_99[v121] = v122
			end
			v_u_99.Density = v119.Density * v107.haze
			v119 = v_u_99
		end
	end
	if v119 then
		for _, v123 in v_u_68 do
			if v123.k <= 0.001 then
				continue
			end
			table.clear(v_u_76)
			for v124, v125 in v119 do
				v_u_76[v124] = v125
			end
			for v126, v127 in v123.vals do
				local v128 = v_u_76[v126]
				if type(v127) == "number" and type(v128) == "number" then
					v_u_76[v126] = v128 + (v127 - v128) * v123.k
				else
					if typeof(v127) ~= "Color3" or typeof(v128) ~= "Color3" then
						continue
					end
					v_u_76[v126] = v128:Lerp(v127, v123.k)
				end
			end
			v119 = v_u_76
		end
	end
	local v129 = v_u_77.atmosphere
	if v129 and v119 then
		for v130, v131 in v119 do
			if v129[v130] == v131 then
				continue
			end
			v129[v130] = v131
		end
	end
	local v132 = p100.Grade
	if v132 and v_u_77.grade then
		local v133 = v_u_77.grade
		local v134
		if v111 then
			local v135 = v111.moonLift
			v134 = type(v135) ~= "number" and 0 or v111.moonLift * v113
		else
			v134 = 0
		end
		local v136
		if v111 then
			local v137 = v111.moonCon0
			v136 = type(v137) ~= "number" and 0 or (v111.moonCon0 - (v132.Contrast or 0)) * v113
		else
			v136 = 0
		end
		v133.Brightness = (v132.Brightness or 0) - v134 + p101 * 0.06
		v133.Contrast = (v132.Contrast or 0) + v136
		v133.Saturation = v132.Saturation or 0
		local v138 = v132.TintColor or Color3.new(1, 1, 1)
		if v111 then
			local v139 = v111.moonTint0
			if typeof(v139) == "Color3" and v113 > 0 then
				v138 = v138:Lerp(v111.moonTint0, v113)
			end
		end
		if p101 > 0 then
			v138 = v138:Lerp(v_u_97, p101 * 0.5)
		end
		v133.TintColor = v138
		v133.Enabled = true
	end
	local v140 = p100.Bloom
	if v140 and v_u_77.bloom then
		local v141 = v_u_77.bloom
		v141.Enabled = v_u_44 >= 2
		v141.Intensity = (v140.Intensity or 0) * (not v108 and 1 or v108.bloom) + p101 * 0.5
		v141.Size = v140.Size or 24
		v141.Threshold = (v140.Threshold or 1.5) + (not v108 and 0 or v108.bloomThreshold)
	end
	local v142 = p100.SunRays
	if v142 and v_u_77.sunrays then
		local v143 = v_u_77.sunrays
		local v144
		if v_u_44 >= 3 then
			v144 = (v142.Intensity or 0) > 0.001
		else
			v144 = false
		end
		v143.Enabled = v144
		v143.Intensity = v142.Intensity or 0
		v143.Spread = v142.Spread or 0.5
	end
	local v145 = p100.DoF
	if v145 and v_u_77.dof then
		local v146 = v_u_77.dof
		local v147
		if v145.Enabled == true then
			v147 = v_u_44 >= 2
		else
			v147 = false
		end
		v146.Enabled = v147
		v146.FarIntensity = v145.FarIntensity or 0
		v146.NearIntensity = v145.NearIntensity or 0
		local v148 = v_u_39 or v_u_40
		local v149
		if v148 then
			v149 = v148[1]
		else
			v149 = v145.FocusDistance or 50
		end
		v146.FocusDistance = v149
		local v150
		if v148 then
			v150 = v148[2]
		else
			v150 = v145.InFocusRadius or 50
		end
		v146.InFocusRadius = v150
	end
	local v151 = v_u_77.sky
	local v152 = p100.Sky
	if v151 then
		if not v152 then
			return
		end
		for v153, v154 in v152 do
			if v151[v153] == v154 then
				continue
			end
			v151[v153] = v154
		end
	end
end
local v_u_156 = {
	"SkyboxBk",
	"SkyboxDn",
	"SkyboxFt",
	"SkyboxLf",
	"SkyboxRt",
	"SkyboxUp"
}
local function v_u_160(p157) -- name: skySource
	-- upvalues: (copy) v_u_4
	local v158 = v_u_4:FindFirstChild("HushAssets")
	if v158 then
		v158 = v158:FindFirstChild("Sky")
	end
	if v158 then
		local v159 = v158:FindFirstChild(p157) or v158:FindFirstChild("Default")
		if v159 and v159:IsA("Sky") then
			return v159
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_171(p161) -- name: applySkyTextures
	-- upvalues: (copy) v_u_77, (copy) v_u_160, (ref) v_u_43, (ref) v_u_42, (copy) v_u_156
	local v_u_162 = v_u_77.sky
	if v_u_162 then
		local v_u_163 = v_u_160(p161)
		local v164 = p161 .. (not v_u_163 and ":orig" or ":" .. v_u_163:GetFullName())
		if v164 ~= v_u_43 or not v_u_162.Parent then
			v_u_43 = v164
			if v_u_42 == nil then
				local v165 = {}
				for _, v166 in v_u_156 do
					v165[v166] = v_u_162[v166]
				end
				v_u_42 = v165
			end
			local function v170()
				-- upvalues: (copy) v_u_163, (ref) v_u_156, (ref) v_u_42, (copy) v_u_162
				local v167 = v_u_163
				for _, v168 in v_u_156 do
					local v169
					if v167 then
						v169 = v167[v168]
					else
						v169 = v_u_42[v168]
					end
					if v_u_162[v168] == v169 then
						continue
					end
					v_u_162[v168] = v169
				end
			end
			pcall(v170)
		end
	else
		return
	end
end
local function v_u_175() -- name: info
	-- upvalues: (ref) v_u_25, (ref) v_u_10, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28
	local v172 = {
		["place"] = v_u_25
	}
	local v173
	if v_u_25 == "Raid" then
		v173 = not v_u_10.isTime(v_u_26) and "Dusk" or v_u_26
	else
		v173 = nil
	end
	v172.timeOfDay = v173
	local v174
	if v_u_25 == "Raid" then
		v174 = not v_u_10.isWeather(v_u_27) and "Clear" or v_u_27
	else
		v174 = nil
	end
	v172.weather = v174
	v172.override = v_u_28
	return v172
end
local function v_u_197() -- name: resolveTarget
	-- upvalues: (ref) v_u_25, (copy) v_u_4, (ref) v_u_28, (ref) v_u_10, (ref) v_u_22, (copy) v_u_24, (ref) v_u_26, (ref) v_u_27, (ref) v_u_23
	local v176
	if v_u_25 == "Raid" then
		v176 = v_u_4:FindFirstChild("HushRuntime")
	else
		v176 = nil
	end
	local v177
	if v176 then
		v177 = v176:GetAttribute("MapId")
	else
		v177 = nil
	end
	local v178 = v_u_28
	if v178 then
		local v179 = v_u_10.resolve
		local v180 = v178.place
		local v181 = v178.time
		local v182 = v178.weather
		local v183 = nil
		local v184 = v_u_22
		local v185 = nil
		local v186 = v_u_24.fp
		local v187 = v_u_24.far
		if v178.place ~= "Raid" or type(v177) ~= "string" then
			v177 = nil
		end
		return v179(v180, v181, v182, v183, v184, v185, v186, v187, v177)
	else
		local v188 = v_u_10.resolve
		local v189 = v_u_25
		local v190 = v_u_26
		local v191 = v_u_27
		local v192 = v_u_25 == "Raid" and v_u_24.on and "underground" or nil
		local v193 = v_u_22
		local v194 = v_u_25 == "Raid" and v_u_23 and "hunt" or nil
		local v195 = v_u_24.fp
		local v196 = v_u_24.far
		if type(v177) ~= "string" then
			v177 = nil
		end
		return v188(v189, v190, v191, v192, v193, v194, v195, v196, v177)
	end
end
local function v_u_208(p198) -- name: retarget
	-- upvalues: (copy) v_u_197, (ref) v_u_29, (ref) v_u_10, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (copy) v_u_155, (ref) v_u_14, (ref) v_u_28, (ref) v_u_25, (ref) v_u_26, (copy) v_u_95, (copy) v_u_171, (ref) v_u_12, (ref) v_u_70, (ref) v_u_44, (copy) v_u_175, (copy) v_u_78, (copy) v_u_9, (copy) v_u_7, (ref) v_u_8
	local v199 = v_u_197()
	if next(v_u_29) == nil then
		v_u_29 = v_u_10.copy(v199)
		p198 = 0
	end
	v_u_30 = v_u_10.copy(v_u_29)
	v_u_31 = v199
	v_u_32 = os.clock()
	v_u_33 = p198
	if p198 <= 0 then
		v_u_29 = v_u_10.copy(v_u_31)
		v_u_34 = false
		v_u_155(v_u_29, v_u_14 and v_u_14.flash() or 0)
	else
		v_u_34 = true
	end
	local v200 = v_u_31.fx or {}
	local v201 = v_u_28
	local v202
	if v201 then
		v202 = v201.place
	else
		v202 = v_u_25
	end
	local v203
	if v201 then
		v203 = v201.time
	else
		v203 = v_u_26
	end
	local v204
	if v202 == "Raid" then
		v204 = not v_u_10.isTime(v203) and "Dusk" or v203
	else
		v204 = v202 == "Hideout" and "Hideout" or "Menu"
	end
	v_u_95()
	v_u_171(v204)
	if v_u_12 then
		v_u_12.setState({
			["street"] = nil,
			["boost"] = nil,
			["interior"] = true,
			["street"] = v200.streetLamps == true,
			["boost"] = v200.lampBoost or 1
		})
	end
	if v_u_14 then
		v_u_14.setLightning((v_u_25 == "Transit" or v_u_70) and 0 or (v200.lightning or 0))
		local v205 = v_u_14.setBolts
		local v206
		if v_u_25 == "Menu" and v_u_44 >= 2 then
			v206 = not v_u_70
		else
			v206 = false
		end
		v205(v206)
	end
	local v207 = v_u_175()
	v_u_78("retarget", v207.place, v207.timeOfDay, v207.weather, p198)
	v_u_9:SetAttribute("AtmoPlace", v207.place)
	v_u_9:SetAttribute("AtmoTime", v207.timeOfDay or "")
	v_u_9:SetAttribute("AtmoWeather", v207.weather or "")
	if v_u_7.changed then
		v_u_7.changed:Fire(v207)
	end
	if v_u_8 then
		v_u_8.emit("atmo.changed", v207)
	end
end
local function v_u_213() -- name: autoQuality
	-- upvalues: (copy) v_u_5
	local v209, v210 = pcall(function()
		return UserSettings():GetService("UserGameSettings").SavedQualityLevel
	end)
	local v211
	if v209 and v210 then
		local v212 = v210.Value
		v211 = v212 == 0 and 3 or (v212 <= 3 and 1 or (v212 <= 6 and 2 or (v212 <= 8 and 3 or 4)))
	else
		v211 = 3
	end
	if v_u_5.TouchEnabled and not v_u_5.KeyboardEnabled then
		v211 = math.min(v211, 2)
	end
	return v211
end
local function v_u_216(p214) -- name: applyQuality
	-- upvalues: (ref) v_u_44, (ref) v_u_17, (ref) v_u_19, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (copy) v_u_9, (ref) v_u_29, (copy) v_u_155
	local v215 = math.floor(p214)
	v_u_44 = math.clamp(v215, 1, 4)
	if v_u_17 then
		v_u_17:setQuality(v_u_44)
	end
	if v_u_19 then
		v_u_19:setQuality(v_u_44)
	end
	if v_u_12 then
		v_u_12.setQuality(v_u_44)
	end
	if v_u_13 then
		v_u_13.setQuality(v_u_44)
	end
	if v_u_14 then
		v_u_14.setQuality(v_u_44)
	end
	if v_u_15 then
		v_u_15.setQuality(v_u_44)
	end
	if v_u_16 then
		v_u_16.setQuality(v_u_44)
	end
	v_u_9:SetAttribute("AtmoQuality", v_u_44)
	if next(v_u_29) ~= nil then
		v_u_155(v_u_29, 0)
	end
end
function v_u_7.setQuality(p217) -- name: setQuality
	-- upvalues: (ref) v_u_45, (copy) v_u_216, (copy) v_u_213
	local v218 = tonumber(p217)
	if p217 == nil or (p217 == "auto" or (p217 == "Auto" or (v218 == nil or v218 < 1))) then
		v_u_45 = false
		v_u_216((v_u_213()))
	else
		v_u_45 = true
		v_u_216(v218)
	end
end
function v_u_7.quality() -- name: quality
	-- upvalues: (ref) v_u_44
	return v_u_44
end
function v_u_7.isInside() -- name: isInside
	-- upvalues: (ref) v_u_52, (ref) v_u_50, (ref) v_u_51, (ref) v_u_8, (copy) v_u_9, (ref) v_u_46, (copy) v_u_3, (ref) v_u_25
	local v219 = os.clock()
	if v219 - v_u_52 < 0.5 then
		return v_u_50
	end
	v_u_52 = v219
	local v220 = false
	v_u_51 = nil
	local v221 = v_u_8
	if v221 then
		v221 = v_u_8.controllers.Vision
	end
	if v221 and v221.isInside then
		local v222 = v221.isInside
		local v223, v224 = pcall(v222)
		if v223 then
			if v224 == nil then
				v220 = false
			else
				v220 = v224 ~= false
			end
			if type(v224) == "string" then
				v_u_51 = v224
			end
		end
	end
	if not v220 then
		local v225 = v_u_9.Character
		if v225 then
			v225 = v225:FindFirstChild("HumanoidRootPart")
		end
		if v225 then
			local v226 = v_u_9.Character
			local v227 = RaycastParams.new()
			v227.FilterType = Enum.RaycastFilterType.Exclude
			v227.FilterDescendantsInstances = { v226, v_u_46 }
			v220 = v_u_3:Raycast(v225.Position + Vector3.new(0, 2, 0), Vector3.new(0, 40, 0), v227) ~= nil
		end
	end
	local v228 = v_u_25 == "Hideout" and true or v220
	v_u_50 = v228
	return v228
end
function v_u_7.lightLevel(p229) -- name: lightLevel
	-- upvalues: (ref) v_u_29, (copy) v_u_9, (copy) v_u_7, (ref) v_u_12, (ref) v_u_14
	local v230 = v_u_29.fx
	local v231 = v230 and (v230.lightLevel or 1) or 1
	if not p229 then
		p229 = v_u_9.Character
		if p229 then
			p229 = p229:FindFirstChild("HumanoidRootPart")
		end
		if p229 then
			p229 = p229.Position
		end
		if v_u_7.isInside() then
			v231 = v231 * 0.45
		end
	end
	local v232 = not (p229 and v_u_12) and 0 or v_u_12.lightAt(p229)
	local v233 = not v_u_14 and 0 or v_u_14.flash() * 0.5
	local v234 = v231 + v232 + v233
	return math.clamp(v234, 0, 1)
end
function v_u_7.isDark(p235) -- name: isDark
	-- upvalues: (copy) v_u_7
	return v_u_7.lightLevel(p235) < 0.3
end
function v_u_7.visionRange() -- name: visionRange
	-- upvalues: (ref) v_u_29
	local v236 = v_u_29.fx
	return not (v236 and v236.vision) and 100 or v236.vision
end
function v_u_7.current() -- name: current
	-- upvalues: (copy) v_u_175
	return v_u_175()
end
function v_u_7.strike(p237) -- name: strike
	-- upvalues: (ref) v_u_14, (ref) v_u_70
	if v_u_14 and not v_u_70 then
		v_u_14.strike(p237)
	end
end
function v_u_7.setOverride(p238, p239, p240, p241) -- name: setOverride
	-- upvalues: (ref) v_u_28, (copy) v_u_208
	v_u_28 = {
		["place"] = p238,
		["time"] = p239,
		["weather"] = p240
	}
	v_u_208(p241 or 3)
end
function v_u_7.clearOverride(p242) -- name: clearOverride
	-- upvalues: (ref) v_u_28, (copy) v_u_208
	if v_u_28 then
		v_u_28 = nil
		v_u_208(p242 or 3)
	end
end
function v_u_7.setFocus(p243, p244) -- name: setFocus
	-- upvalues: (ref) v_u_39, (ref) v_u_29, (copy) v_u_155
	if p243 then
		v_u_39 = { p243, p244 or 12 }
	else
		v_u_39 = nil
	end
	if next(v_u_29) ~= nil then
		v_u_155(v_u_29, 0)
	end
end
function v_u_7.setFxAnchor(p245) -- name: setFxAnchor
	-- upvalues: (ref) v_u_41
	v_u_41 = p245
end
local v_u_246 = 0
local function v_u_251(p247) -- name: flushFlashSend
	-- upvalues: (ref) v_u_61, (ref) v_u_246, (copy) v_u_9, (ref) v_u_25, (ref) v_u_26, (ref) v_u_57, (ref) v_u_60, (copy) v_u_4
	if v_u_61 == nil and v_u_246 <= p247 then
		v_u_246 = p247 + 3
		local v248 = v_u_9.Character
		if v248 and (v_u_25 == "Raid" and v_u_26 ~= nil or v_u_25 == "Hideout") and (v248:GetAttribute("Dead") ~= true and v248:GetAttribute("Flashlight") == true ~= v_u_57) then
			v_u_61 = v_u_57
		end
	end
	local v249 = v_u_61
	if v249 ~= nil and p247 - v_u_60 >= 0.2 then
		v_u_61 = nil
		v_u_60 = p247
		local v250 = v_u_4:FindFirstChild("HushNet")
		if v250 then
			v250 = v250:FindFirstChild("atmo.flashlight")
		end
		if v250 and v250:IsA("RemoteEvent") then
			v250:FireServer(v249)
		end
	end
end
local function v_u_255(p_u_252) -- name: setFlashState
	-- upvalues: (ref) v_u_57, (ref) v_u_13, (ref) v_u_61, (copy) v_u_9, (ref) v_u_8
	if p_u_252 ~= v_u_57 then
		v_u_57 = p_u_252
		if v_u_13 then
			v_u_13.setLocal(p_u_252)
		end
		v_u_61 = p_u_252
		v_u_9:SetAttribute("AtmoFlashlight", p_u_252)
		local v_u_253 = v_u_8
		if v_u_253 then
			v_u_253 = v_u_8.controllers.Input
		end
		if v_u_253 and v_u_253.touch then
			pcall(function()
				-- upvalues: (copy) v_u_253, (copy) p_u_252
				local v254 = v_u_253.touch()
				if v254 and v254.setToggle then
					v254:setToggle("flashlight", p_u_252)
				end
			end)
		end
	end
end
function v_u_7.setFlashlight(p256) -- name: setFlashlight
	-- upvalues: (ref) v_u_56, (ref) v_u_58, (ref) v_u_59, (copy) v_u_255
	if p256 == nil then
		v_u_56 = "auto"
		v_u_58 = nil
		v_u_59 = nil
	else
		v_u_56 = p256 and "on" or "off"
		v_u_255(p256)
	end
end
function v_u_7.toggleFlashlight() -- name: toggleFlashlight
	-- upvalues: (ref) v_u_25, (copy) v_u_7, (ref) v_u_57
	if v_u_25 == "Raid" or v_u_25 == "Hideout" then
		v_u_7.setFlashlight(not v_u_57)
	end
end
local function v_u_267(p257) -- name: nvgColor
	if type(p257) == "table" then
		local v258 = p257[1]
		if type(v258) == "number" then
			local v259 = p257[2]
			if type(v259) == "number" then
				local v260 = p257[3]
				if type(v260) == "number" then
					local v261 = Color3.new
					local v262 = p257[1] / 255
					local v263 = math.clamp(v262, 0, 1)
					local v264 = p257[2] / 255
					local v265 = math.clamp(v264, 0, 1)
					local v266 = p257[3] / 255
					return v261(v263, v265, (math.clamp(v266, 0, 1)))
				end
			end
		end
	end
	return nil
end
function v_u_7.setNightVision(p268) -- name: setNightVision
	-- upvalues: (ref) v_u_66, (ref) v_u_67, (copy) v_u_267
	if type(p268) == "table" then
		local v269 = p268.exposure
		if type(v269) == "number" and p268.exposure == p268.exposure then
			v_u_66 = {
				["exposure"] = p268.exposure,
				["ambient"] = v_u_267(p268.ambient),
				["outdoor"] = v_u_267(p268.outdoor)
			}
			v_u_67 = true
			return
		end
	end
	if v_u_66 ~= nil then
		v_u_66 = nil
		v_u_67 = true
	end
end
function v_u_7.nightVisionOn() -- name: nightVisionOn
	-- upvalues: (ref) v_u_66
	return v_u_66 ~= nil
end
function v_u_7.setOverlay(p270, p271, p272) -- name: setOverlay
	-- upvalues: (copy) v_u_68
	if type(p270) == "string" then
		local v273 = (type(p272) ~= "number" or p272 ~= p272) and 1.5 or math.clamp(p272, 0.05, 30)
		local v274 = v_u_68[p270]
		if type(p271) == "table" then
			if not v274 then
				v274 = {
					["vals"] = nil,
					["target"] = 0,
					["k"] = 0,
					["fade"] = nil,
					["vals"] = {},
					["fade"] = v273
				}
				v_u_68[p270] = v274
			end
			table.clear(v274.vals)
			for v275, v276 in p271 do
				if v275 == "weight" then
					continue
				end
				v274.vals[v275] = v276
			end
			local v277 = p271.weight
			v274.target = (type(v277) ~= "number" or v277 ~= v277) and 1 or math.clamp(v277, 0, 1)
			v274.fade = v273
		elseif v274 then
			v274.target = 0
			v274.fade = v273
		end
	else
		return
	end
end
function v_u_7.overlayWeight(p278) -- name: overlayWeight
	-- upvalues: (copy) v_u_68
	local v279 = v_u_68[p278]
	return not v279 and 0 or v279.k
end
function v_u_7.flashingOff() -- name: flashingOff
	-- upvalues: (ref) v_u_70
	return v_u_70
end
function v_u_7.flashlightOn() -- name: flashlightOn
	-- upvalues: (ref) v_u_57
	return v_u_57
end
function v_u_7.flashlightRange() -- name: flashlightRange
	-- upvalues: (ref) v_u_13
	if v_u_13 and v_u_13.localProfile then
		local v280 = v_u_13.localProfile
		local v281, v282 = pcall(v280)
		if v281 and type(v282) == "table" then
			local v283 = v282.range
			if type(v283) == "number" then
				return v282.range
			end
		end
	end
	return 55
end
local function v_u_290(p284) -- name: updateAutoFlashlight
	-- upvalues: (ref) v_u_25, (ref) v_u_57, (copy) v_u_255, (copy) v_u_9, (ref) v_u_26, (copy) v_u_24, (ref) v_u_64, (ref) v_u_65, (ref) v_u_56, (ref) v_u_58, (ref) v_u_59, (copy) v_u_7, (ref) v_u_29
	if v_u_25 == "Raid" or v_u_25 == "Hideout" then
		local v285 = v_u_9.Character
		if v285 and v285:GetAttribute("Dead") ~= true then
			if v_u_25 == "Raid" and (v_u_26 == "Night" or v_u_24.map) then
				local v286 = v285:GetAttribute("Downed") == true
				if v_u_64 ~= v285 or v_u_65 and not v286 then
					v_u_64 = v285
					v_u_56 = "on"
					v_u_58 = nil
					v_u_59 = nil
					v_u_255(true)
					v_u_9:SetAttribute("AtmoFlashNight", v_u_65 and not v286 and "revive" or "spawn")
				end
				v_u_65 = v286
			end
			if v_u_56 == "auto" and v_u_25 == "Raid" then
				if v_u_57 then
					v_u_58 = nil
					local v287 = v_u_29.fx
					local v288 = v287 and (v287.lightLevel or 1) or 1
					if v_u_7.isInside() then
						v288 = v288 * 0.45
					end
					if math.clamp(v288, 0, 1) > 0.5 then
						v_u_59 = v_u_59 or p284
						if p284 - v_u_59 > 2.5 then
							v_u_255(false)
							return
						end
					else
						v_u_59 = nil
					end
				else
					local v289 = v_u_7.lightLevel(nil)
					v_u_59 = nil
					if v289 >= 0.3 then
						v_u_58 = nil
						return
					end
					v_u_58 = v_u_58 or p284
					if p284 - v_u_58 > 0.6 then
						v_u_255(true)
						return
					end
				end
			end
		else
			return
		end
	else
		if v_u_57 then
			v_u_255(false)
		end
		return
	end
end
local function v_u_297() -- name: tryBindInput
	-- upvalues: (ref) v_u_8, (copy) v_u_7, (ref) v_u_62
	local v291 = v_u_8
	if v291 then
		v291 = v_u_8.controllers.Input
	end
	if v291 and v291.bind then
		local v292 = v291.bind
		local function v293()
			-- upvalues: (ref) v_u_7
			v_u_7.toggleFlashlight()
		end
		local v294 = pcall(v292, "flashlight", v293)
		v_u_62 = v294
		if v294 and v291.touchButton then
			local v295 = v291.touchButton
			local v296 = {
				["text"] = "LIGHT",
				["anchor"] = "TR",
				["pos"] = nil,
				["size"] = 46,
				["toggle"] = true,
				["pos"] = Vector2.new(-52, 246)
			}
			pcall(v295, "flashlight", v296)
		end
	end
end
local function v_u_304(p298, p299) -- name: onThunder
	-- upvalues: (ref) v_u_8, (ref) v_u_25
	local v300 = v_u_8
	if v300 then
		v300 = v_u_8.controllers.Audio
	end
	if v300 and v_u_25 ~= "Transit" then
		if v_u_25 == "Hideout" then
			p299 = p299 * 0.35
		end
		if v300.thunder then
			local v301 = v300.thunder
			pcall(v301, p298, p299)
		else
			local v302 = p298 < 2500 and 1 or 0.85
			if v300.play then
				local v303 = v300.play
				pcall(v303, "ev_thunder", {
					["volume"] = p299,
					["pitch"] = v302
				})
			end
		end
	else
		return
	end
end
local function v_u_308(p305, _) -- name: onFlicker
	-- upvalues: (ref) v_u_8
	local v306 = v_u_8
	if v306 then
		v306 = v_u_8.controllers.Audio
	end
	if v306 and v306.play3D then
		local v307 = v306.play3D
		pcall(v307, "light_flicker", p305, {
			["volume"] = 0.5
		})
	end
end
local function v_u_315(p309, p310) -- name: onFlashToggle
	-- upvalues: (ref) v_u_8
	local v311 = v_u_8
	if v311 then
		v311 = v_u_8.controllers.Audio
	end
	if v311 and v311.play3D then
		local v312 = p309:FindFirstChild("UpperTorso") or p309:FindFirstChild("HumanoidRootPart")
		if v312 and v312:IsA("BasePart") then
			local v313 = v311.play3D
			local v314 = v312.Position
			pcall(v313, "item_flashlight", v314, {
				["volume"] = p310 and 0.7 or 0.5,
				["pitch"] = p310 and 1 or 0.92
			})
		end
	end
end
local v_u_316 = {}
local v_u_317 = {}
local v_u_318 = 0
local function v_u_348(p319, p320) -- name: updateHum
	-- upvalues: (copy) v_u_316, (ref) v_u_12, (copy) v_u_317, (ref) v_u_318, (ref) v_u_8, (ref) v_u_44, (ref) v_u_25
	for v321, v322 in v_u_316 do
		local v323 = v_u_12.levelOf(v321)
		local v324 = v323 <= 0.3 and 0 or v323
		local v325 = v_u_317[v321] or 1
		local v326 = v324 - v325
		if math.abs(v326) <= 0.08 or (type(v322) ~= "table" or not v322.setVolume) then
			continue
		end
		v_u_317[v321] = v324
		local v327 = v322.setVolume
		local v328 = v325 < v324 and 0.05 or 0.03
		pcall(v327, v322, v324, v328)
	end
	if p319 - v_u_318 < 1 then
		return
	end
	v_u_318 = p319
	local v329 = v_u_8
	if v329 then
		v329 = v_u_8.controllers.Audio
	end
	local v330 = {}
	local v331 = v_u_44 >= 2 and 2 or 1
	if v329 and (v329.loop and (v_u_25 == "Raid" or v_u_25 == "Hideout")) then
		local v332 = v_u_12.nearestTubes(p320, 32, v331 + 2)
		local v333 = 0
		for _, v334 in v332 do
			if not v_u_316[v334] or v333 >= v331 then
				continue
			end
			v330[v334] = true
			v333 = v333 + 1
		end
		for _, v335 in v332 do
			if v331 <= v333 then
				break
			end
			if v330[v335] or (v335.Position - p320).Magnitude > 26 then
				continue
			end
			v330[v335] = true
			v333 = v333 + 1
		end
	end
	local v336 = {}
	for v337 in v_u_316 do
		if v330[v337] and v337.Parent then
			continue
		end
		table.insert(v336, v337)
	end
	for _, v338 in v336 do
		local v_u_339 = v_u_316[v338]
		if v_u_339 ~= nil then
			pcall(function()
				-- upvalues: (copy) v_u_339
				local v340 = v_u_339
				if typeof(v340) == "Instance" then
					v_u_339:Destroy()
				else
					local v341 = v_u_339
					if type(v341) == "table" then
						local v342 = v_u_339.stop or v_u_339.Stop or (v_u_339.destroy or v_u_339.Destroy)
						if v342 then
							v342(v_u_339)
							return
						end
					else
						local v343 = v_u_339
						if type(v343) == "function" then
							v_u_339()
						end
					end
				end
			end)
		end
		v_u_316[v338] = nil
		v_u_317[v338] = nil
	end
	for v344 in v330 do
		if v_u_316[v344] then
			continue
		end
		local v345 = v329.loop
		local v346, v347 = pcall(v345, "amb_hum", v344, {
			["fadeIn"] = 0.6
		})
		if not v346 or v347 == nil then
			continue
		end
		v_u_316[v344] = v347
		v_u_317[v344] = 1
	end
end
local function v_u_369(p_u_349, p_u_350) -- name: bindRaid
	-- upvalues: (ref) v_u_37, (ref) v_u_8, (ref) v_u_22, (ref) v_u_10, (ref) v_u_23, (ref) v_u_26, (ref) v_u_27, (copy) v_u_208, (copy) v_u_38, (ref) v_u_25, (copy) v_u_369, (copy) v_u_3, (ref) v_u_15
	task.spawn(function()
		-- upvalues: (copy) p_u_349, (ref) v_u_37, (ref) v_u_8, (ref) v_u_22, (ref) v_u_10, (ref) v_u_23, (ref) v_u_26, (ref) v_u_27, (ref) v_u_208, (copy) p_u_350, (ref) v_u_38, (ref) v_u_25, (ref) v_u_369, (ref) v_u_3, (ref) v_u_15
		local v_u_351 = nil
		while p_u_349 == v_u_37 and not v_u_351 do
			v_u_351 = v_u_8.session.waitForRaid(30)
		end
		if p_u_349 == v_u_37 and v_u_351 then
			local function v_u_356(p352) -- name: read
				-- upvalues: (ref) v_u_351, (ref) v_u_22, (ref) v_u_10, (ref) v_u_23, (ref) v_u_26, (ref) v_u_27, (ref) v_u_208
				local v353 = v_u_351:GetAttribute("TimeOfDay")
				local v354 = v_u_351:GetAttribute("Weather")
				v_u_22 = v_u_10.snowLevel(v_u_351:GetAttribute("SnowLevel"), v_u_351:GetAttribute("Difficulty"))
				v_u_23 = v_u_351:GetAttribute("Hunt") == true
				if type(v353) ~= "string" then
					v353 = nil
				end
				v_u_26 = v353
				if type(v354) == "string" and v_u_10.isWeather(v354) then
					v_u_27 = v354
				else
					local v355 = v_u_351:GetAttribute("RaidId")
					v_u_27 = v_u_10.weatherForSeed((tostring(v355 or "raid")))
				end
				v_u_208(p352)
			end
			v_u_356(p_u_350)
			local v357 = v_u_38
			local v358 = v_u_351:GetAttributeChangedSignal("TimeOfDay")
			table.insert(v357, v358:Connect(function()
				-- upvalues: (copy) v_u_356
				v_u_356(14)
			end))
			local v359 = v_u_38
			local v360 = v_u_351:GetAttributeChangedSignal("Weather")
			table.insert(v359, v360:Connect(function()
				-- upvalues: (copy) v_u_356
				v_u_356(10)
			end))
			local v361 = v_u_38
			local v362 = v_u_351:GetAttributeChangedSignal("SnowLevel")
			table.insert(v361, v362:Connect(function()
				-- upvalues: (copy) v_u_356
				v_u_356(6)
			end))
			local v363 = v_u_38
			local v364 = v_u_351.AncestryChanged
			local function v367(_, p365)
				-- upvalues: (ref) p_u_349, (ref) v_u_37, (ref) v_u_25, (ref) v_u_38, (ref) v_u_369
				if p365 == nil and (p_u_349 == v_u_37 and v_u_25 == "Raid") then
					for _, v366 in v_u_38 do
						v366:Disconnect()
					end
					table.clear(v_u_38)
					v_u_37 = v_u_37 + 1
					v_u_369(v_u_37, 3)
				end
			end
			table.insert(v363, v364:Connect(v367))
			local v368 = v_u_3:WaitForChild("Raid", 30)
			if v368 and (p_u_349 == v_u_37 and v_u_15) then
				v_u_15.watch(v368)
			end
		end
	end)
end
local function v_u_401(p370, p371) -- name: onPlace
	-- upvalues: (copy) v_u_24, (ref) v_u_37, (copy) v_u_38, (ref) v_u_64, (ref) v_u_65, (ref) v_u_29, (ref) v_u_25, (ref) v_u_14, (ref) v_u_15, (ref) v_u_58, (ref) v_u_59, (copy) v_u_255, (copy) v_u_316, (copy) v_u_317, (ref) v_u_56, (ref) v_u_26, (ref) v_u_27, (ref) v_u_22, (ref) v_u_23, (ref) v_u_8, (ref) v_u_10, (copy) v_u_208, (copy) v_u_369, (copy) v_u_3
	local v372 = v_u_24
	v_u_24.on = false
	v372.map = false
	v_u_24.fp = false
	v_u_24.far = false
	v_u_37 = v_u_37 + 1
	local v_u_373 = v_u_37
	for _, v374 in v_u_38 do
		v374:Disconnect()
	end
	table.clear(v_u_38)
	v_u_64 = nil
	v_u_65 = false
	local v375 = p371 == "Transit" and true or next(v_u_29) == nil
	if p370 == "Transit" then
		v_u_25 = "Transit"
		if v_u_14 then
			v_u_14.setLightning(0)
		end
		if v_u_15 then
			v_u_15.unwatchAll()
		end
		v_u_58 = nil
		v_u_59 = nil
		v_u_255(false)
		for _, v_u_376 in v_u_316 do
			if v_u_376 == nil then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_376
				local v377 = v_u_376
				if typeof(v377) == "Instance" then
					v_u_376:Destroy()
				else
					local v378 = v_u_376
					if type(v378) == "table" then
						local v379 = v_u_376.stop or v_u_376.Stop or (v_u_376.destroy or v_u_376.Destroy)
						if v379 then
							v379(v_u_376)
							return
						end
					else
						local v380 = v_u_376
						if type(v380) == "function" then
							v_u_376()
						end
					end
				end
			end)
		end
		table.clear(v_u_316)
		table.clear(v_u_317)
		return
	else
		v_u_25 = p370
		if v_u_15 then
			v_u_15.unwatchAll()
		end
		if p370 == "Raid" then
			v_u_56 = "auto"
			v_u_26 = nil
			v_u_27 = nil
			v_u_22 = nil
			v_u_23 = false
			local v_u_381 = v375 and 0 or 4
			task.spawn(function()
				-- upvalues: (copy) v_u_373, (ref) v_u_37, (ref) v_u_8, (ref) v_u_22, (ref) v_u_10, (ref) v_u_23, (ref) v_u_26, (ref) v_u_27, (ref) v_u_208, (copy) v_u_381, (ref) v_u_38, (ref) v_u_25, (ref) v_u_369, (ref) v_u_3, (ref) v_u_15
				local v_u_382 = nil
				while v_u_373 == v_u_37 and not v_u_382 do
					v_u_382 = v_u_8.session.waitForRaid(30)
				end
				if v_u_373 == v_u_37 and v_u_382 then
					local function v_u_387(p383) -- name: read
						-- upvalues: (ref) v_u_382, (ref) v_u_22, (ref) v_u_10, (ref) v_u_23, (ref) v_u_26, (ref) v_u_27, (ref) v_u_208
						local v384 = v_u_382:GetAttribute("TimeOfDay")
						local v385 = v_u_382:GetAttribute("Weather")
						v_u_22 = v_u_10.snowLevel(v_u_382:GetAttribute("SnowLevel"), v_u_382:GetAttribute("Difficulty"))
						v_u_23 = v_u_382:GetAttribute("Hunt") == true
						if type(v384) ~= "string" then
							v384 = nil
						end
						v_u_26 = v384
						if type(v385) == "string" and v_u_10.isWeather(v385) then
							v_u_27 = v385
						else
							local v386 = v_u_382:GetAttribute("RaidId")
							v_u_27 = v_u_10.weatherForSeed((tostring(v386 or "raid")))
						end
						v_u_208(p383)
					end
					v_u_387(v_u_381)
					local v388 = v_u_38
					local v389 = v_u_382:GetAttributeChangedSignal("TimeOfDay")
					table.insert(v388, v389:Connect(function()
						-- upvalues: (copy) v_u_387
						v_u_387(14)
					end))
					local v390 = v_u_38
					local v391 = v_u_382:GetAttributeChangedSignal("Weather")
					table.insert(v390, v391:Connect(function()
						-- upvalues: (copy) v_u_387
						v_u_387(10)
					end))
					local v392 = v_u_38
					local v393 = v_u_382:GetAttributeChangedSignal("SnowLevel")
					table.insert(v392, v393:Connect(function()
						-- upvalues: (copy) v_u_387
						v_u_387(6)
					end))
					local v394 = v_u_38
					local v395 = v_u_382.AncestryChanged
					local function v398(_, p396)
						-- upvalues: (ref) v_u_373, (ref) v_u_37, (ref) v_u_25, (ref) v_u_38, (ref) v_u_369
						if p396 == nil and (v_u_373 == v_u_37 and v_u_25 == "Raid") then
							for _, v397 in v_u_38 do
								v397:Disconnect()
							end
							table.clear(v_u_38)
							v_u_37 = v_u_37 + 1
							v_u_369(v_u_37, 3)
						end
					end
					table.insert(v394, v395:Connect(v398))
					local v399 = v_u_3:WaitForChild("Raid", 30)
					if v399 and (v_u_373 == v_u_37 and v_u_15) then
						v_u_15.watch(v399)
					end
				end
			end)
			return
		elseif p370 == "Hideout" then
			v_u_56 = "auto"
			v_u_208(v375 and 0 or 2)
		else
			v_u_26 = nil
			v_u_27 = nil
			v_u_22 = nil
			v_u_23 = false
			v_u_208(v375 and 0 or 2.5)
			local v400 = v_u_3:FindFirstChild("HushLocal")
			if v400 and v_u_15 then
				v_u_15.watch(v400)
			end
		end
	end
end
local function v_u_428(p402) -- name: computeFocus
	-- upvalues: (ref) v_u_41, (ref) v_u_48, (ref) v_u_47, (ref) v_u_25, (ref) v_u_8, (copy) v_u_9, (copy) v_u_3, (copy) v_u_49, (ref) v_u_40
	if v_u_41 then
		return v_u_41
	end
	if p402 - v_u_48 < 0.1 then
		return v_u_47
	end
	v_u_48 = p402
	if v_u_25 == "Raid" or v_u_25 == "Hideout" then
		local v403 = nil
		local v404 = nil
		local v405 = v_u_8
		if v405 then
			v405 = v_u_8.controllers.Camera
		end
		local v406, v407
		if v405 and v405.subject then
			local v408 = v405.subject
			local v409
			v409, v406 = pcall(v408)
			if v409 and (typeof(v406) == "Instance" and (v406:IsA("BasePart") and v406.Parent)) then
				if v405.focus then
					local v410 = v405.focus
					local v411
					v411, v407 = pcall(v410)
					if v411 then
						if typeof(v407) ~= "Vector3" then
							v407 = v404
						end
					else
						v407 = v404
					end
				else
					v407 = v404
				end
			else
				v407 = v404
				v406 = v403
			end
		else
			v407 = v404
			v406 = v403
		end
		if not v406 then
			v406 = v_u_9.Character
			if v406 then
				v406 = v406:FindFirstChild("HumanoidRootPart")
			end
		end
		if v406 then
			local v412 = v406.Parent
			if v412 then
				v412 = v412:FindFirstChildOfClass("Humanoid")
			end
			local v413 = not v412 and 2 or v412.HipHeight
			local v414 = v406.Position
			local v415 = v413 + v406.Size.Y * 0.5
			local v416 = v414 - Vector3.new(0, v415, 0)
			if v407 then
				local v417 = v407.X - v416.X
				local v418 = v407.Z - v416.Z
				if v417 * v417 + v418 * v418 < 900 then
					local v419 = v407.X
					local v420 = v416.Y
					local v421 = v407.Z
					v416 = Vector3.new(v419, v420, v421)
				end
			end
			v_u_47 = v416
			return v_u_47
		end
	end
	local v422 = v_u_3.CurrentCamera
	if v422 then
		local v423 = v422.CFrame
		local v424 = v_u_3:Raycast(v423.Position, v423.LookVector * 500, v_u_49)
		if v424 then
			v_u_47 = v424.Position
			local v425 = v424.Distance
			local v426 = {}
			local v427 = v425 * 0.35
			__set_list(v426, 1, {v425, (math.clamp(v427, 6, 40))})
			v_u_40 = v426
		else
			v_u_47 = v422.Focus.Position
			v_u_40 = nil
		end
	end
	return v_u_47
end
local function v_u_433() -- name: refreshExclude
	-- upvalues: (ref) v_u_46, (copy) v_u_1, (copy) v_u_49, (ref) v_u_17, (ref) v_u_19, (ref) v_u_15
	local v429 = {}
	if v_u_46 then
		local v430 = v_u_46
		table.insert(v429, v430)
	end
	for _, v431 in v_u_1:GetPlayers() do
		if not v431.Character then
			continue
		end
		local v432 = v431.Character
		table.insert(v429, v432)
	end
	v_u_49.FilterDescendantsInstances = v429
	if v_u_17 then
		v_u_17:setExclude(v429)
	end
	if v_u_19 then
		v_u_19:setExclude(v429)
	end
	if v_u_15 and v_u_46 then
		v_u_15.setPuddles(v_u_46, v429)
	end
end
function v_u_7.init(p_u_434) -- name: init
	-- upvalues: (ref) v_u_8, (ref) v_u_10, (copy) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_18, (ref) v_u_20, (copy) v_u_3, (ref) v_u_46, (ref) v_u_17, (ref) v_u_19, (ref) v_u_21, (copy) v_u_304, (copy) v_u_308, (copy) v_u_315, (ref) v_u_44, (copy) v_u_213, (copy) v_u_9, (ref) v_u_45, (copy) v_u_216, (copy) v_u_433, (ref) v_u_29, (copy) v_u_155, (ref) v_u_22, (copy) v_u_208, (copy) v_u_428, (ref) v_u_56, (ref) v_u_57, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_34
	v_u_8 = p_u_434
	v_u_10 = p_u_434.shared.LightingPresets
	v_u_7.changed = p_u_434.shared.Signal.new()
	v_u_11 = p_u_434.lib.WeatherRain
	v_u_12 = p_u_434.lib.WeatherLamps
	v_u_13 = p_u_434.lib.WeatherFlashlight
	v_u_14 = p_u_434.lib.WeatherSky
	v_u_15 = p_u_434.lib.WeatherWet
	v_u_16 = p_u_434.lib.WeatherDust
	v_u_18 = p_u_434.lib.WeatherSnow
	v_u_20 = p_u_434.lib.AshHumFx
	local v435 = v_u_3:FindFirstChild("HushLocal")
	if not v435 then
		v435 = Instance.new("Folder")
		v435.Name = "HushLocal"
		v435.Parent = v_u_3
	end
	local v436 = Instance.new("Folder")
	v436.Name = "Atmosphere"
	v436.Parent = v435
	v_u_46 = v436
	v_u_17 = v_u_11.new(v436)
	v_u_19 = v_u_18.new(v436)
	v_u_21 = v_u_20.new(v436)
	local v437, v438 = pcall(function()
		-- upvalues: (copy) p_u_434
		return p_u_434.lib.AshgroveTram
	end)
	if v437 and type(v438) == "table" then
		local v439 = v438.start
		if type(v439) == "function" then
			local v440 = v438.start
			pcall(v440)
		end
	end
	local v441, v442 = pcall(function()
		-- upvalues: (copy) p_u_434
		return p_u_434.lib.OvertureAudio
	end)
	if v441 and type(v442) == "table" then
		local v443 = v442.start
		if type(v443) == "function" then
			local v444 = v442.start
			pcall(v444, p_u_434)
		end
	end
	local v445, v446 = pcall(function()
		-- upvalues: (copy) p_u_434
		return p_u_434.lib.ClubLights
	end)
	if v445 and type(v446) == "table" then
		local v447 = v446.start
		if type(v447) == "function" then
			local v448 = v446.start
			pcall(v448, p_u_434)
		end
	end
	v_u_14.init(v436)
	v_u_16.init(v436)
	v_u_14.onThunder = v_u_304
	v_u_12.onFlicker = v_u_308
	v_u_13.onToggle = v_u_315
	v_u_44 = v_u_213()
	local v449 = v_u_9:GetAttribute("GfxQuality")
	if type(v449) == "number" and v449 >= 1 then
		v_u_44 = v449
		v_u_45 = true
	end
	v_u_216(v_u_44)
	v_u_433()
	v_u_29 = v_u_10.resolve(p_u_434.session.place(v_u_9), nil, nil)
	v_u_155(v_u_29, 0)
	p_u_434.command("atmo.preset", function(p450)
		-- upvalues: (ref) v_u_7
		local v451 = p450[1] or "Dusk"
		local v452 = p450[2]
		if v451 == "Menu" or v451 == "Hideout" then
			local v453 = v_u_7.setOverride
			local v454 = p450[3]
			v453(v451, nil, nil, tonumber(v454) or 2)
		else
			local v455 = v_u_7.setOverride
			local v456 = p450[3]
			v455("Raid", v451, v452 or "Clear", tonumber(v456) or 2)
		end
		return "override " .. v451 .. " " .. tostring(v452)
	end)
	p_u_434.command("atmo.snow", function(p457)
		-- upvalues: (ref) v_u_22, (ref) v_u_208, (ref) v_u_19, (ref) v_u_44
		local v458 = p457[1]
		local v459 = tonumber(v458)
		if v459 and (v459 >= 1 and v459 <= 3) then
			v_u_22 = math.floor(v459)
			v_u_208(2)
		elseif v458 == "off" then
			v_u_22 = nil
			v_u_208(2)
		end
		local v460 = v_u_19:stats()
		local v461 = v_u_22
		return string.format("snow level=%s q=%d cells=%d active=%d covered=%d rate=%.0f/s flakes~%d", tostring(v461), v_u_44, v460.cells, v460.active, v460.covered, v460.rate, v460.flakes)
	end)
	p_u_434.command("atmo.anchor", function(p462)
		-- upvalues: (ref) v_u_7
		local v463 = p462[1]
		local v464 = tonumber(v463)
		local v465 = p462[2]
		local v466 = tonumber(v465)
		local v467 = p462[3]
		local v468 = tonumber(v467)
		if v464 and (v466 and v468) then
			v_u_7.setFxAnchor((Vector3.new(v464, v466, v468)))
			return "anchor " .. v464 .. " " .. v466 .. " " .. v468
		else
			v_u_7.setFxAnchor(nil)
			return "anchor cleared"
		end
	end)
	p_u_434.command("atmo.lamps", function(p469)
		-- upvalues: (ref) v_u_428, (ref) v_u_12, (ref) v_u_29
		local v470 = v_u_428(os.clock())
		local v471 = v_u_12.stats()
		local v472 = {}
		local v473 = string.format
		local v474 = v470.X
		local v475 = v470.Y
		local v476 = v470.Z
		local v477 = v471.active
		local v478 = v471.total
		local v479 = v471.street
		local v480 = v471.shadows
		local v481 = v471.nearest
		local v482 = (v_u_29.fx or {}).streetLamps == true
		__set_list(v472, 1, {v473("focus=%d,%d,%d lamps=%d/%d street=%d shadows=%d nearestWanting=%d streetOn=%s", v474, v475, v476, v477, v478, v479, v480, v481, (tostring(v482)))})
		local v483 = v_u_12.nearest
		local v484 = p469[1]
		for _, v485 in v483(v470, tonumber(v484) or 6) do
			local v486 = string.format
			local v487 = v485.kind
			local v488 = v485.dist
			local v489 = v485.want
			local v490 = tostring(v489)
			local v491 = v485.active
			local v492 = tostring(v491)
			local v493 = v485.dead
			local v494 = tostring(v493)
			local v495 = v485.level
			local v496 = v485.enabled
			local v497 = tostring(v496)
			local v498 = v485.brightness
			local v499 = v485.tube and " tube" or ""
			table.insert(v472, v486("%s d=%d want=%s active=%s dead=%s level=%.2f enabled=%s b=%.2f%s", v487, v488, v490, v492, v494, v495, v497, v498, v499))
		end
		return table.concat(v472, " | ")
	end)
	p_u_434.command("atmo.clear", function()
		-- upvalues: (ref) v_u_7
		v_u_7.clearOverride(2)
		return "override cleared"
	end)
	p_u_434.command("atmo.moon", function(p500)
		-- upvalues: (ref) v_u_10, (ref) v_u_208
		local v501 = v_u_10.MOON_TUNE
		for _, v502 in p500 do
			if v502 == "reset" then
				table.clear(v501)
			else
				local v503, v504 = string.match(v502, "^(%a+)=(%-?[%d%.]+)$")
				local v505 = tonumber(v504)
				if not v503 or (not v505 or v503 ~= "ambient" and (v503 ~= "bright" and (v503 ~= "exposure" and (v503 ~= "contrast" and v503 ~= "lift")))) then
					return "usage: atmo.moon [reset] [ambient=1] [bright=1] [exposure=0] [contrast=0.2] [lift=0]"
				end
				v501[v503] = v505
			end
		end
		if #p500 > 0 then
			v_u_208(0.5)
		end
		local v506 = {}
		for v507, v508 in v501 do
			local v509 = v507 .. "=" .. tostring(v508)
			table.insert(v506, v509)
		end
		table.sort(v506)
		return "moon tune: " .. (#v506 <= 0 and "defaults" or table.concat(v506, " "))
	end)
	p_u_434.command("atmo.quality", function(p510)
		-- upvalues: (ref) v_u_9, (ref) v_u_7, (ref) v_u_44, (ref) v_u_45
		local v511 = p510[1]
		local v512 = v_u_9:GetAttribute("GfxQuality")
		local v513 = (type(v512) ~= "number" or v512 < 1) and "auto" or tostring(v512)
		local v514 = ""
		if v511 == "setting" or v511 == "user" then
			v_u_7.setQuality(v513 == "auto" and "auto" or v512)
			v514 = " restored"
		elseif v511 ~= nil and v511 ~= "" then
			v_u_7.setQuality(v511)
			v514 = " debug override"
		end
		return "quality " .. v_u_44 .. (v_u_45 and " (forced)" or " (auto)") .. v514 .. " setting=" .. v513
	end)
	p_u_434.command("atmo.strike", function(p515)
		-- upvalues: (ref) v_u_7
		local v516 = v_u_7.strike
		local v517 = p515[1]
		v516((tonumber(v517)))
		return "strike"
	end)
	p_u_434.command("atmo.flashlight", function(p518)
		-- upvalues: (ref) v_u_7, (ref) v_u_56, (ref) v_u_57
		local v519 = p518[1]
		if v519 == "on" then
			v_u_7.setFlashlight(true)
		elseif v519 == "off" then
			v_u_7.setFlashlight(false)
		else
			v_u_7.setFlashlight(nil)
		end
		local v520 = v_u_57
		return "flashlight " .. v_u_56 .. " " .. tostring(v520)
	end)
	p_u_434.command("atmo.health", function()
		-- upvalues: (ref) v_u_7
		local v521, v522 = v_u_7.blockErrors()
		return ("errors=%d blocks=%d %s"):format(v521, v522, v_u_7.health())
	end)
	p_u_434.command("atmo.fault", function(p523)
		-- upvalues: (copy) p_u_434, (ref) v_u_7
		local function v524()
			-- upvalues: (ref) p_u_434
			return game:GetService("RunService"):IsStudio() or p_u_434.config.IS_TEST == true
		end
		local v525, v526 = pcall(v524)
		if not v525 or v526 ~= true then
			return "not allowed"
		end
		local v527 = p523[1]
		local v528 = v_u_7.setTestThrow
		local v529
		if v527 == nil or (v527 == "" or v527 == "off") then
			v529 = nil
		else
			v529 = v527
		end
		v528(v529)
		return "fault " .. tostring(v527 or "off")
	end)
	p_u_434.command("atmo.stats", function()
		-- upvalues: (ref) v_u_12, (ref) v_u_17, (ref) v_u_15, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_44, (ref) v_u_34, (ref) v_u_7, (ref) v_u_57, (ref) v_u_56, (ref) v_u_13
		local v530 = v_u_12.stats()
		local v531 = v_u_17:stats()
		local v532 = v_u_15.stats()
		local v533 = string.format
		local v534 = v_u_25
		local v535 = v_u_26
		local v536 = tostring(v535)
		local v537 = v_u_27
		local v538 = tostring(v537)
		local v539 = v_u_44
		local v540 = v_u_34
		local v541 = tostring(v540)
		local v542 = v530.active
		local v543 = v530.total
		local v544 = v530.shadows
		local v545 = v530.flicker
		local v546 = v530.dead
		local v547 = v531.active
		local v548 = v531.cells
		local v549 = v531.covered
		local v550 = v532.wet
		local v551 = v532.parts
		local v552 = v532.puddles
		local v553 = v_u_7.lightLevel(nil)
		local v554 = v_u_7.isInside
		local v555 = v_u_57
		return v533("place=%s time=%s weather=%s q=%d blending=%s lamps=%d/%d (shadows %d, flicker %d, dead %d) rain=%d/%d cells covered=%d wet=%.2f parts=%d puddles=%d light=%.2f inside=%s flash=%s(%s) torches=%d", v534, v536, v538, v539, v541, v542, v543, v544, v545, v546, v547, v548, v549, v550, v551, v552, v553, tostring(v554()), tostring(v555), v_u_56, v_u_13.count())
	end)
end
function v_u_7.start() -- name: start
	-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_13, (copy) v_u_9, (copy) v_u_7, (ref) v_u_45, (copy) v_u_216, (copy) v_u_213, (copy) v_u_401, (copy) v_u_297
	local function v556()
		-- upvalues: (ref) v_u_8
		v_u_8.lib.PerkSight.start(v_u_8)
	end
	pcall(v556)
	v_u_12.start()
	v_u_13.start(v_u_9)
	v_u_9:GetAttributeChangedSignal("GfxQuality"):Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_7
		local v557 = v_u_9:GetAttribute("GfxQuality")
		if type(v557) == "number" or type(v557) == "string" then
			v_u_7.setQuality(v557)
		elseif v557 == nil then
			v_u_7.setQuality("auto")
		end
	end)
	local function v558()
		-- upvalues: (ref) v_u_45, (ref) v_u_216, (ref) v_u_213
		UserSettings():GetService("UserGameSettings"):GetPropertyChangedSignal("SavedQualityLevel"):Connect(function()
			-- upvalues: (ref) v_u_45, (ref) v_u_216, (ref) v_u_213
			if not v_u_45 then
				v_u_216((v_u_213()))
			end
		end)
	end
	pcall(v558)
	v_u_8.session.onPlaceChanged(function(p559, p560)
		-- upvalues: (ref) v_u_401
		v_u_401(p559, p560)
	end)
	v_u_297()
end
local v_u_561 = nil
local v_u_562 = 0
local v_u_563 = {}
local v_u_564 = {}
local v_u_565 = 0
local v_u_566 = Vector3.new(0, 0, 0)
local v_u_567 = nil
function v_u_7.setTestThrow(p568) -- name: setTestThrow
	-- upvalues: (ref) v_u_567
	v_u_567 = p568
end
local function v_u_584(p_u_569, p570, ...) -- name: guarded
	-- upvalues: (ref) v_u_567, (copy) v_u_563, (copy) v_u_564, (copy) v_u_9, (ref) v_u_8
	local v_u_571, v572
	if v_u_567 == p_u_569 then
		v_u_571 = "test throw in " .. p_u_569
		v572 = false
	else
		v572, v_u_571 = pcall(p570, ...)
	end
	if v572 then
		return true
	end
	local v573 = v_u_563[p_u_569]
	if not v573 then
		v573 = {
			["n"] = 0,
			["last"] = ""
		}
		v_u_563[p_u_569] = v573
		local v574 = v_u_564
		table.insert(v574, p_u_569)
	end
	v573.n = v573.n + 1
	local v575 = tostring(v_u_571)
	v573.last = string.sub(v575, 1, 160)
	if v573.n == 1 or v573.n % 600 == 0 then
		warn("[Atmosphere] step block", p_u_569, "failed:", v_u_571)
		local function v580()
			-- upvalues: (ref) v_u_9, (copy) p_u_569, (ref) v_u_571
			local v576 = v_u_9
			local v577 = p_u_569
			local v578 = v_u_571
			local v579 = tostring(v578)
			v576:SetAttribute("ClientError", "Atmosphere " .. v577 .. ": " .. string.sub(v579, 1, 160))
		end
		pcall(v580)
	end
	if v573.n == 5 then
		local v_u_581 = "atmo " .. p_u_569
		local v_u_582 = tostring(v_u_571)
		local function v583()
			-- upvalues: (ref) v_u_8, (copy) v_u_581, (copy) v_u_582
			v_u_8.lib.MoveWatch.fault(v_u_581, v_u_582)
		end
		pcall(v583)
	end
	return false
end
function v_u_7.health() -- name: health
	-- upvalues: (copy) v_u_564, (copy) v_u_563, (ref) v_u_562
	local v585 = {}
	for _, v586 in v_u_564 do
		local v587 = v_u_563[v586]
		local v588 = v587.n
		local v589 = v587.last
		table.insert(v585, ("%s x%d (%s)"):format(v586, v588, v589))
	end
	local v590 = "stageCleared " .. v_u_562
	table.insert(v585, v590)
	return table.concat(v585, " | ")
end
function v_u_7.blockErrors() -- name: blockErrors
	-- upvalues: (copy) v_u_564, (copy) v_u_563
	local v591 = 0
	for _, v592 in v_u_564 do
		v591 = v591 + v_u_563[v592].n
	end
	return v591, #v_u_564
end
local function v_u_602(p593) -- name: stageRunning
	-- upvalues: (copy) v_u_9, (ref) v_u_561, (ref) v_u_8, (ref) v_u_562
	if v_u_9:GetAttribute("CrateStageOn") ~= true then
		v_u_561 = nil
		return false
	end
	local v_u_594 = false
	local function v597()
		-- upvalues: (ref) v_u_8, (ref) v_u_594
		local v595 = v_u_8.lib.CrateStage.active()
		local v596
		if v595 == nil then
			v596 = false
		else
			v596 = v595:isPlaying()
		end
		v_u_594 = v596
	end
	pcall(v597)
	if v_u_594 then
		v_u_561 = nil
		return true
	end
	if v_u_561 == nil then
		v_u_561 = p593
		return true
	end
	if p593 - v_u_561 < 1.5 then
		return true
	end
	v_u_561 = nil
	v_u_562 = v_u_562 + 1
	local function v598()
		-- upvalues: (ref) v_u_9
		v_u_9:SetAttribute("CrateStageOn", false)
		v_u_9:SetAttribute("ClientError", "CrateStageOn was stale and was cleared")
	end
	pcall(v598)
	local v_u_599 = "stage stale"
	local v_u_600 = "CrateStageOn true without a running stage"
	local function v601()
		-- upvalues: (ref) v_u_8, (copy) v_u_599, (copy) v_u_600
		v_u_8.lib.MoveWatch.fault(v_u_599, v_u_600)
	end
	pcall(v601)
	return false
end
local function v_u_604(p603) -- name: stepFocus
	-- upvalues: (ref) v_u_566, (copy) v_u_428
	v_u_566 = v_u_428(p603)
end
local function v_u_607(p605, p606) -- name: stepLamps
	-- upvalues: (ref) v_u_12
	v_u_12.step(p605, p606)
end
local function v_u_623(p608) -- name: stepUnderground
	-- upvalues: (copy) v_u_24, (ref) v_u_25, (ref) v_u_8, (copy) v_u_9, (copy) v_u_208, (ref) v_u_10
	if p608 - v_u_24.at > 0.25 then
		v_u_24.at = p608
		local v_u_609 = false
		local function v615()
			-- upvalues: (ref) v_u_25, (ref) v_u_8, (ref) v_u_24, (ref) v_u_9, (ref) v_u_609
			local v610
			if v_u_25 == "Raid" then
				v610 = v_u_8.shared.MapInfo.fromRuntime()
			else
				v610 = nil
			end
			local v611 = v_u_24
			local v612
			if v610 == nil then
				v612 = false
			else
				v612 = v610.underground == true
			end
			v611.map = v612
			if v_u_24.map then
				local v613 = v_u_9.Character
				if v613 then
					v613 = v613:FindFirstChild("HumanoidRootPart")
				end
				local v614
				if v613 == nil then
					v614 = false
				else
					v614 = v613.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y
				end
				v_u_609 = v614
			end
		end
		if pcall(v615) and v_u_609 ~= v_u_24.on then
			v_u_24.on = v_u_609
			v_u_9:SetAttribute("AtmoUnderground", v_u_609)
			v_u_208(1.5)
		end
		local v616
		if v_u_25 == "Raid" then
			local function v619()
				-- upvalues: (ref) v_u_8
				local v617 = v_u_8.controllers.FpView
				local v618
				if v617 == nil then
					v618 = false
				else
					v618 = v617.viewOn() == true
				end
				return v618
			end
			local v620
			v616, v620 = pcall(v619)
			if v616 then
				v616 = v620 == true
			end
		else
			v616 = false
		end
		local v621
		if v616 then
			local v622 = v_u_9:GetAttribute("ZombieViewR")
			if type(v622) == "number" and v622 == v622 then
				v621 = v_u_10.FPTP_FAR_FROM < v622
			else
				v621 = false
			end
		else
			v621 = false
		end
		if v616 ~= v_u_24.fp or v621 ~= v_u_24.far then
			v_u_24.fp = v616
			v_u_24.far = v621
			v_u_9:SetAttribute("AtmoFptp", v616)
			v_u_208(1.5)
		end
	end
end
local function v_u_627(p624) -- name: stepBlend
	-- upvalues: (ref) v_u_34, (ref) v_u_33, (ref) v_u_32, (ref) v_u_10, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31
	if v_u_34 then
		local v625
		if v_u_33 > 0 then
			local v626 = (p624 - v_u_32) / v_u_33
			v625 = math.clamp(v626, 0, 1)
		else
			v625 = 1
		end
		v_u_10.blendInto(v_u_29, v_u_30, v_u_31, v625 * v625 * (3 - v625 * 2))
		if v625 >= 1 then
			v_u_34 = false
		end
	end
end
local function v_u_650(p628, p629) -- name: stepOverlay
	-- upvalues: (copy) v_u_68, (ref) v_u_69, (ref) v_u_72, (ref) v_u_71, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4, (ref) v_u_25, (ref) v_u_73, (ref) v_u_75, (copy) v_u_208, (ref) v_u_74, (ref) v_u_8, (ref) v_u_70, (ref) v_u_14, (ref) v_u_31, (ref) v_u_44
	for _, v630 in v_u_68 do
		if v630.k == v630.target then
			continue
		end
		local v631 = v630.fade
		local v632 = p628 / math.max(v631, 0.05)
		local v633
		if v630.k < v630.target then
			local v634 = v630.k + v632
			local v635 = v630.target
			v633 = math.min(v634, v635)
		else
			local v636 = v630.k - v632
			local v637 = v630.target
			v633 = math.max(v636, v637)
		end
		v630.k = v633
		v_u_69 = true
	end
	if p629 - v_u_72 > 0.25 then
		v_u_72 = p629
		local v638 = v_u_9:GetAttribute("ReduceFlashing")
		if type(v638) ~= "boolean" then
			local function v639()
				-- upvalues: (ref) v_u_6
				return v_u_6.ReducedMotionEnabled
			end
			local v640
			v638, v640 = pcall(v639)
			if v638 then
				v638 = v640 == true
			end
		end
		v_u_71 = v638
		local v641 = v_u_4:FindFirstChild("HushRuntime")
		local v642
		if v_u_25 == "Raid" and v641 ~= nil then
			v642 = v641:GetAttribute("MapId") == "tokyo"
		else
			v642 = false
		end
		if v642 ~= v_u_73 then
			v_u_73 = v642
			v_u_75 = nil
			v_u_208(1)
		end
		if v_u_73 and v_u_75 == nil then
			if v_u_74 == nil then
				local function v643()
					-- upvalues: (ref) v_u_8
					return v_u_8.shared.ClubLightsPlan
				end
				local v644, v645 = pcall(v643)
				if not v644 or type(v645) ~= "table" then
					v645 = false
				end
				v_u_74 = v645
			end
			if v_u_74 then
				v_u_75 = v_u_74.guardNew()
			end
		end
	end
	local v646 = v_u_68.club
	local v647 = v_u_71
	if not v647 then
		if v646 == nil then
			v647 = false
		else
			v647 = v646.target > 0 and true or v646.k > 0.001
		end
	end
	if v647 ~= v_u_70 then
		v_u_70 = v647
		if v_u_14 then
			v_u_14.setLightning((v_u_25 == "Transit" or v_u_70) and 0 or ((v_u_31.fx or {}).lightning or 0))
			local v648 = v_u_14.setBolts
			local v649
			if v_u_25 == "Menu" and v_u_44 >= 2 then
				v649 = not v_u_70
			else
				v649 = false
			end
			v648(v649)
		end
		v_u_69 = true
	end
end
local function v_u_654(p651, p652) -- name: stepSky
	-- upvalues: (ref) v_u_14, (ref) v_u_47, (ref) v_u_70, (ref) v_u_75, (ref) v_u_74, (ref) v_u_565, (ref) v_u_34, (ref) v_u_36, (ref) v_u_69, (ref) v_u_67, (ref) v_u_35, (copy) v_u_155, (ref) v_u_29
	v_u_14.step(p651, v_u_47)
	local v653 = v_u_14.flash()
	if v_u_70 then
		v653 = 0
	elseif v_u_75 and v_u_74 then
		v653 = v_u_74.guardStep(v_u_75, v653, p652)
	end
	v_u_565 = v653
	if v_u_34 or (v653 > 0 or (v_u_36 > 0 or (v_u_69 or (v_u_67 or p652 - v_u_35 > 2)))) then
		v_u_67 = false
		v_u_69 = false
		v_u_155(v_u_29, v653)
		v_u_35 = p652
	end
	v_u_36 = v653
end
local function v_u_666(p655) -- name: stepLampState
	-- upvalues: (ref) v_u_55, (ref) v_u_29, (ref) v_u_10, (ref) v_u_44, (ref) v_u_25, (copy) v_u_4, (copy) v_u_96, (ref) v_u_12, (copy) v_u_7, (ref) v_u_51
	if p655 - v_u_55 > 0.5 then
		v_u_55 = p655
		local v656 = v_u_29.fx or {}
		local v657 = v_u_10.lowQualityFloor
		local v658 = v_u_44
		local v659 = v656.lum
		local v660 = v_u_29.Lighting
		if v660 then
			v660 = v_u_29.Lighting.ExposureCompensation
		end
		local v661 = v657(v658, v659, v660)
		local v662
		if v_u_25 == "Raid" then
			local v663 = v_u_4:FindFirstChild("HushRuntime")
			local v664
			if v663 then
				v664 = v663:GetAttribute("MapId")
			else
				v664 = nil
			end
			if type(v664) == "string" then
				v662 = v_u_96[v664]
			else
				v662 = nil
			end
		else
			v662 = nil
		end
		local v665 = (v656.interiorLamp or 1) * (not v661 and 1 or v661.interior) * (not v662 and 1 or v662.interior)
		v_u_12.setState({
			["boost"] = v656.lampBoost or 1,
			["interiorMul"] = v665
		})
		v_u_12.setRaidPower(v_u_25 == "Raid")
		if v_u_25 == "Raid" then
			v_u_7.isInside()
			v_u_12.setInside(v_u_51)
			return
		end
		v_u_12.setInside(nil)
	end
end
local function v_u_672(p667) -- name: stepDof
	-- upvalues: (copy) v_u_77, (ref) v_u_40, (ref) v_u_39
	local v668 = v_u_77.dof
	local v669 = v_u_40
	if v668 and (v668.Enabled and (not v_u_39 and v669)) then
		local v670 = p667 * 3
		local v671 = math.min(1, v670)
		v668.FocusDistance = v668.FocusDistance + (v669[1] - v668.FocusDistance) * v671
		v668.InFocusRadius = v668.InFocusRadius + (v669[2] - v668.InFocusRadius) * v671
	end
end
local function v_u_678(p673, p674, p675) -- name: stepRain
	-- upvalues: (ref) v_u_29, (ref) v_u_25, (ref) v_u_54, (copy) v_u_433, (ref) v_u_17, (ref) v_u_565, (ref) v_u_21, (ref) v_u_19
	local v676 = v_u_29.fx or {}
	local v677
	if v_u_25 == "Transit" then
		v677 = false
	else
		v677 = v_u_25 ~= "Hideout"
	end
	if p674 - v_u_54 > 2 then
		v_u_54 = p674
		v_u_433()
	end
	v_u_17:update(p673, p675, v677 and (v676.rain or 0) or 0, v676.wind or 0, v_u_565)
	v_u_21:update(p673, p675)
	v_u_19:update(p673, p675, v677 and (v676.snow or 0) or 0, v676.wind or 0)
end
local function v_u_683(p679) -- name: stepFog
	-- upvalues: (ref) v_u_29, (ref) v_u_25, (ref) v_u_14, (ref) v_u_15
	local v680 = v_u_29.fx or {}
	local v681
	if v_u_25 == "Transit" then
		v681 = false
	else
		v681 = v_u_25 ~= "Hideout"
	end
	local v682 = v_u_29.Atmosphere and v_u_29.Atmosphere.Color or Color3.new(0.6, 0.6, 0.6)
	v_u_14.setFog(v681 and (v680.fogBank or 0) or 0, v682, v680.wind or 0)
	v_u_15.set((v681 or v_u_25 == "Transit") and (v680.wet or 0) or 0)
	v_u_15.step()
	v_u_15.stepPuddles(p679)
end
local function v_u_687(p684, p685) -- name: stepHumDust
	-- upvalues: (copy) v_u_348, (ref) v_u_25, (copy) v_u_7, (ref) v_u_16
	v_u_348(p684, p685)
	local v686 = v_u_25 == "Hideout" and 1 or (v_u_25 == "Raid" and v_u_7.isInside() and 0.8 or 0)
	v_u_16.set(v686)
	v_u_16.step(p685)
end
local function v_u_698(p688, p689, p690) -- name: stepFlashlight
	-- upvalues: (ref) v_u_29, (ref) v_u_13, (copy) v_u_290, (copy) v_u_251
	local v691 = v_u_29.fx or {}
	local v692 = (v691.rain or 0) * 0.7
	local v693 = (v691.snow or 0) * 0.5
	local v694 = v691.fogBank or 0
	local v695 = math.max(v692, v693, v694)
	local v696 = v691.lightLevel or 1
	local v697 = v695 * (1 - math.clamp(v696, 0, 1))
	v_u_13.setAir(v697)
	v_u_290(p689)
	v_u_251(p689)
	v_u_13.step(p688, p690)
end
local function v_u_700(p699) -- name: stepInputBind
	-- upvalues: (ref) v_u_62, (ref) v_u_63, (copy) v_u_297
	if not v_u_62 and v_u_63 <= p699 then
		v_u_63 = p699 + 2
		v_u_297()
	end
end
local function v_u_705(p701) -- name: stepStats
	-- upvalues: (ref) v_u_53, (copy) v_u_9, (copy) v_u_7, (ref) v_u_12
	if p701 - v_u_53 > 1 then
		v_u_53 = p701
		local v702 = v_u_9
		local v703 = v_u_7.lightLevel(nil) * 100
		v702:SetAttribute("AtmoLight", math.floor(v703) / 100)
		local v704 = v_u_12.stats()
		v_u_9:SetAttribute("AtmoLamps", v704.active .. "/" .. v704.total)
		v_u_9:SetAttribute("AtmoLampNear", v704.nearest)
		v_u_9:SetAttribute("AtmoFlashRange", v_u_7.flashlightRange())
	end
end
function v_u_7.step(p706) -- name: step
	-- upvalues: (ref) v_u_566, (ref) v_u_47, (copy) v_u_602, (copy) v_u_584, (copy) v_u_607, (copy) v_u_604, (copy) v_u_666, (copy) v_u_623, (copy) v_u_627, (copy) v_u_650, (copy) v_u_654, (copy) v_u_672, (copy) v_u_678, (copy) v_u_683, (copy) v_u_687, (copy) v_u_698, (copy) v_u_700, (copy) v_u_705
	local v707 = os.clock()
	v_u_566 = v_u_47
	if v_u_602(v707) then
		v_u_584("lamps", v_u_607, p706, v_u_47)
	else
		v_u_584("focus", v_u_604, v707)
		local v708 = v_u_566
		v_u_584("lampState", v_u_666, v707)
		v_u_584("lamps", v_u_607, p706, v708)
		v_u_584("underground", v_u_623, v707)
		v_u_584("blend", v_u_627, v707)
		v_u_584("overlay", v_u_650, p706, v707)
		v_u_584("sky", v_u_654, p706, v707)
		v_u_584("dof", v_u_672, p706)
		v_u_584("rain", v_u_678, p706, v707, v708)
		v_u_584("fog", v_u_683, v708)
		v_u_584("dust", v_u_687, v707, v708)
		v_u_584("flash", v_u_698, p706, v707, v708)
		v_u_584("input", v_u_700, v707)
		v_u_584("stats", v_u_705, v707)
	end
end
return v_u_7