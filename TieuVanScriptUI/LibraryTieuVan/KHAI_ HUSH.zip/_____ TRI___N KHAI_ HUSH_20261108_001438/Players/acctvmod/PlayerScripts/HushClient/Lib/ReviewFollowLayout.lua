-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewFollowLayout

local v_u_68 = {
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["MARGIN"] = 10,
	["TOP"] = 8,
	["opts"] = function(p1, p2, p3) -- name: opts
		local v4 = math.max(p1, 0.1)
		local v5
		if p2 then
			local v6 = 44 / v4
			local v7 = math.ceil(v6)
			v5 = math.max(36, v7)
		else
			local v8 = 30 / v4
			local v9 = math.ceil(v8)
			v5 = math.max(36, v9)
		end
		local v10 = {
			["scale"] = nil,
			["touch"] = nil,
			["phone"] = nil,
			["tap"] = nil,
			["pad"] = 8,
			["gap"] = 8,
			["scale"] = v4,
			["touch"] = p2
		}
		if p3 == nil then
			p3 = p2
		end
		v10.phone = p3
		v10.tap = v5
		return v10
	end,
	["fs"] = function(p11, p12) -- name: fs
		if not p11.phone then
			return p12
		end
		local v13 = 11 / p11.scale
		local v14 = math.ceil(v13)
		return math.max(p12, v14)
	end,
	["textW"] = function(p15, p16, p17) -- name: textW
		-- upvalues: (copy) v_u_68
		local v18 = tostring(p15 or "")
		local v19 = (utf8.len(v18) or #v18) * p16
		local v20
		if p17 == true then
			v20 = v_u_68.CHAR_CAPS
		else
			v20 = v_u_68.CHAR
		end
		local v21 = v19 * v20 + 2
		return math.ceil(v21)
	end,
	["clip1"] = function(p22, p23, p24, p25) -- name: clip1
		-- upvalues: (copy) v_u_68
		local v26 = tostring(p22 or "")
		if v_u_68.textW(v26, p24, p25) <= p23 then
			return v26
		end
		local v27 = 1
		local v28 = p23 - 2
		local v29
		if p25 == true then
			v29 = v_u_68.CHAR_CAPS
		else
			v29 = v_u_68.CHAR
		end
		local v30 = v28 / (p24 * v29)
		local v31 = math.floor(v30) - 3
		local v32 = math.max(v27, v31)
		return string.sub(v26, 1, v32) .. "..."
	end,
	["bar"] = function(p33, _, p34, p35) -- name: bar
		-- upvalues: (copy) v_u_68
		local v36 = v_u_68.MARGIN
		local v37 = p34.pad
		local v38 = p34.gap
		local v39 = v_u_68.fs(p34, 13)
		local v40 = v39 * 1.3
		local v41 = math.ceil(v40)
		local v42 = p33 - 2 * v36
		local v43 = math.max(v42, 120)
		local v44 = p35.button or "STOP FOLLOWING"
		local v45 = tostring(v44)
		local v46 = v_u_68.textW(v45, v39, true) + 2 * v37 + 4
		local v47 = v43 - 2 * v37
		local v48 = math.min(v46, v47)
		local v49 = p34.tap
		local v50 = v41 + 8
		local v51 = math.max(v49, v50)
		local v52 = p35.text or ""
		local v53 = tostring(v52)
		local v54 = v_u_68.textW(v53, v39, true)
		local v55 = v37 + v54 + v38 + v48 + v37 <= v43
		local v56 = {
			["stacked"] = not v55
		}
		if v55 then
			local v57 = v37 + v54 + v38 + v48 + v37
			local v58 = v51 + 2 * v37
			local v59 = (p33 - v57) / 2
			local v60 = math.floor(v59)
			v56.panel = {
				["x"] = v60,
				["y"] = v_u_68.TOP,
				["w"] = v57,
				["h"] = v58
			}
			v56.text = {
				["rect"] = {
					["x"] = v60 + v37,
					["y"] = v_u_68.TOP + v37,
					["w"] = v54,
					["h"] = v51
				},
				["str"] = v53,
				["size"] = v39
			}
			v56.button = {
				["rect"] = {
					["x"] = v60 + v37 + v54 + v38,
					["y"] = v_u_68.TOP + v37,
					["w"] = v48,
					["h"] = v51
				},
				["label"] = v45,
				["size"] = v39
			}
			return v56
		end
		local v61 = v43 - 2 * v37
		local v62 = v37 + v41 + v38 + v51 + v37
		local v63 = (p33 - v43) / 2
		local v64 = math.floor(v63)
		v56.panel = {
			["x"] = v64,
			["y"] = v_u_68.TOP,
			["w"] = v43,
			["h"] = v62
		}
		v56.text = {
			["rect"] = {
				["x"] = v64 + v37,
				["y"] = v_u_68.TOP + v37,
				["w"] = v61,
				["h"] = v41
			},
			["str"] = v_u_68.clip1(v53, v61, v39, true),
			["size"] = v39
		}
		local v65 = math.min(v48, v61)
		local v66 = {}
		local v67 = (v43 - v65) / 2
		v66.rect = {
			["x"] = v64 + math.floor(v67),
			["y"] = v_u_68.TOP + v37 + v41 + v38,
			["w"] = v65,
			["h"] = v51
		}
		v66.label = v45
		v66.size = v39
		v56.button = v66
		return v56
	end
}
return v_u_68