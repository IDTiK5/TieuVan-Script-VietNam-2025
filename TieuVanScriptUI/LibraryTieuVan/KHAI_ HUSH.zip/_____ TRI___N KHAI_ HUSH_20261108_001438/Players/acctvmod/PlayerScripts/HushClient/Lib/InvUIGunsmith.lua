-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIGunsmith

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = nil
function v_u_2.bind(p5) -- name: bind
	-- upvalues: (ref) v_u_3
	v_u_3 = p5
end
function v_u_2.know() -- name: know
	-- upvalues: (ref) v_u_3
	if v_u_3 == nil then
		return nil
	else
		local v6 = v_u_3
		local v7, v8 = pcall(v6)
		if v7 and type(v8) == "table" then
			return v8
		else
			return nil
		end
	end
end
function v_u_2.chip(p9) -- name: chip
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (copy) v_u_2
	if v_u_4 == nil then
		local function v10()
			-- upvalues: (ref) v_u_1
			return require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Gunsmith", 10))
		end
		local v11, v12 = pcall(v10)
		if not v11 or type(v12) ~= "table" then
			v12 = false
		end
		v_u_4 = v12
	end
	local v13 = v_u_4 or nil
	if v13 then
		local v14 = v13.chip
		if type(v14) == "function" then
			local v15 = v13.chip
			local v16 = v_u_2.know
			local v17, v18, v19 = pcall(v15, p9, v16())
			if v17 and type(v18) == "string" then
				return v18, v19
			else
				return nil, nil
			end
		end
	end
	return nil, nil
end
function v_u_2.tipBody(p20, p21) -- name: tipBody
	-- upvalues: (copy) v_u_2
	local v22 = v_u_2.chip(p21)
	if v22 == nil then
		return p20
	elseif type(p20) == "string" and p20 ~= "" then
		return p20 .. "\n" .. v22
	else
		return v22
	end
end
function v_u_2.color(p23, p24) -- name: color
	if p23 == "locked" then
		return p24.accent
	elseif p23 == "progress" then
		return p24.info
	elseif p23 == "open" then
		return p24.success
	else
		return p24.text2
	end
end
function v_u_2.addRow(p25, p26, p27) -- name: addRow
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v28, v29 = v_u_2.chip(p26)
	if v28 == nil then
		return nil
	end
	local v30 = v_u_1:WaitForChild("Hush"):WaitForChild("Shared")
	local v31 = require(v30:WaitForChild("Theme")).color
	local v32 = v_u_2.color(v29, v31)
	local v33 = Instance.new("Frame")
	v33.Name = "GunsmithChip"
	v33.LayoutOrder = p27
	v33.BackgroundColor3 = v31.raised
	v33.BackgroundTransparency = 0.25
	v33.BorderSizePixel = 0
	v33.Size = UDim2.new(1, -6, 0, 0)
	v33.AutomaticSize = Enum.AutomaticSize.Y
	v33.ZIndex = 63
	v33:SetAttribute("Kind", v29)
	local v34 = Instance.new("Frame")
	v34.Name = "Tick"
	v34.BackgroundColor3 = v32
	v34.BorderSizePixel = 0
	v34.Size = UDim2.new(0, 3, 1, 0)
	v34.ZIndex = 64
	v34.Parent = v33
	local v35 = Instance.new("Frame")
	v35.Name = "Body"
	v35.BackgroundTransparency = 1
	v35.BorderSizePixel = 0
	v35.Size = UDim2.new(1, 0, 0, 0)
	v35.AutomaticSize = Enum.AutomaticSize.Y
	v35.ZIndex = 64
	v35.Parent = v33
	local v36 = Instance.new("UIPadding")
	local v37 = UDim.new(0, 12)
	local v38 = UDim.new(0, 8)
	local v39 = UDim.new(0, 6)
	local v40 = UDim.new(0, 6)
	v36.PaddingLeft = v37
	v36.PaddingRight = v38
	v36.PaddingTop = v39
	v36.PaddingBottom = v40
	v36.Parent = v35
	local v41 = require(script.Parent:WaitForChild("HushUI")).label({
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["size"] = nil,
		["track"] = false,
		["text"] = v28,
		["color"] = v32,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v41.Name = "Text"
	v41.ZIndex = 64
	v41.Parent = v35
	v33.Parent = p25
	return v33
end
return v_u_2