-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUILootGlow

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(v4:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme")).color
local v_u_6 = {
	["RANGE"] = 8,
	["DY"] = 5,
	["MAX"] = 8,
	["INTERVAL"] = 0.2
}
local v_u_7 = v2.LocalPlayer
local v8 = nil
local v9
if script and script.Parent then
	v9 = script.Parent:FindFirstChild("HideUiRules")
else
	v9 = nil
end
local v_u_10
if v9 then
	local v11 = require
	local v12
	v12, v_u_10 = pcall(v11, v9)
	if not v12 or type(v_u_10) ~= "table" then
		v_u_10 = v8
	end
else
	v_u_10 = v8
end
function v_u_6.range() -- name: range
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v13 = v_u_7:GetAttribute("LootReach")
	if type(v13) == "number" and (v_u_6.RANGE <= v13 and v13 <= 20) then
		return v13
	else
		return v_u_6.RANGE
	end
end
local v_u_14 = {}
local v_u_15 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = {}
local v_u_19 = RaycastParams.new()
v_u_19.FilterType = Enum.RaycastFilterType.Exclude
v_u_19.IgnoreWater = true
local v_u_20 = OverlapParams.new()
v_u_20.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_23() -- name: getFolder
	-- upvalues: (ref) v_u_16
	if v_u_16 and v_u_16.Parent then
		return v_u_16
	end
	local v21 = workspace:FindFirstChild("HushLocal")
	if not v21 then
		v21 = Instance.new("Folder")
		v21.Name = "HushLocal"
		v21.Parent = workspace
	end
	local v22 = v21:FindFirstChild("LootGlow")
	if not v22 then
		v22 = Instance.new("Folder")
		v22.Name = "LootGlow"
		v22.Parent = v21
	end
	v_u_16 = v22
	return v22
end
local function v_u_42(p_u_24) -- name: adorneeFor
	-- upvalues: (copy) v_u_15, (copy) v_u_7, (copy) v_u_20, (copy) v_u_1
	if p_u_24:IsA("Model") then
		local v25 = p_u_24:GetAttribute("StashVehicle")
		if type(v25) == "string" then
			local v26 = workspace:FindFirstChild("Raid")
			local v27
			if v26 == nil then
				v27 = nil
			else
				v27 = v26:FindFirstChild("Vehicles")
			end
			local v28
			if v27 == nil then
				v28 = nil
			else
				v28 = v27:FindFirstChild(v25)
			end
			if v28 ~= nil then
				return v28
			end
		end
		return p_u_24
	end
	local v29 = v_u_15[p_u_24]
	if v29 and v29.Parent then
		return v29
	end
	local v30
	if p_u_24:IsA("BasePart") and p_u_24.Transparency >= 0.9 then
		local v31 = {}
		local v32 = workspace:FindFirstChild("HushLocal")
		if v32 then
			table.insert(v31, v32)
		end
		if v_u_7.Character then
			local v33 = v_u_7.Character
			table.insert(v31, v33)
		end
		v_u_20.FilterDescendantsInstances = v31
		local function v34()
			-- upvalues: (copy) p_u_24, (ref) v_u_20
			return workspace:GetPartBoundsInBox(p_u_24.CFrame, p_u_24.Size + Vector3.new(1, 1, 1), v_u_20)
		end
		local v35, v36 = pcall(v34)
		local v37 = {}
		v30 = nil
		local v38 = 0
		local v39
		if v35 and v36 then
			v39 = p_u_24
			for _, v40 in v36 do
				if v40 == p_u_24 or v40.Transparency >= 0.6 then
					continue
				end
				local v41 = v40:FindFirstAncestorOfClass("Model")
				if not v41 or v_u_1:HasTag(v41, "HushBuilding") then
					continue
				end
				v37[v41] = (v37[v41] or 0) + 1
				if v38 >= v37[v41] then
					continue
				end
				v38 = v37[v41]
				v30 = v41
			end
		else
			v39 = p_u_24
		end
		if not v30 then
			v30 = v39
		end
	else
		v30 = p_u_24
	end
	v_u_15[p_u_24] = v30
	return v30
end
function v_u_6.holdsLoot(p43) -- name: holdsLoot
	local v44
	if p43.Parent == nil or p43:GetAttribute("Looted") ~= false then
		v44 = false
	else
		v44 = p43:GetAttribute("CarriedByZombie") ~= true
	end
	return v44
end
local function v_u_59(p45, p46, p47, p48) -- name: blockedBetween
	-- upvalues: (copy) v_u_15, (copy) v_u_19, (copy) v_u_1
	local v49 = p46 - p45
	local v50 = v49.X
	local v51 = v49.Z
	if Vector3.new(v50, 0, v51).Magnitude <= 2.5 or v49.Magnitude < 0.6 then
		return false
	end
	local v52 = { p48, p47 }
	local v53 = workspace:FindFirstChild("HushLocal")
	if v53 then
		table.insert(v52, v53)
	end
	local v54 = v_u_15[p47]
	if v54 then
		table.insert(v52, v54)
	end
	v_u_19.FilterDescendantsInstances = v52
	local v55 = workspace:Raycast(p45, v49.Unit * (v49.Magnitude - 0.4), v_u_19)
	local v56
	if v55 then
		v56 = v55.Instance
	else
		v56 = v55
	end
	if not v55 or (not v56 or (not v56.CanCollide or v56.Transparency >= 0.95)) then
		return false
	end
	if v_u_1:HasTag(v56, "HushWall") or (v_u_1:HasTag(v56, "HushWallBase") or v_u_1:HasTag(v56, "HushWindow")) then
		return true
	end
	local v57 = v56:FindFirstAncestorOfClass("Model")
	if v57 and (v_u_1:HasTag(v57, "HushDoor") and v57:GetAttribute("State") == "Closed") then
		return true
	end
	local v58
	if v56.Size.Y >= 5 then
		v58 = (v55.Position - p46).Magnitude > 2.5
	else
		v58 = false
	end
	return v58
end
local function v_u_67(p60, p61, p62) -- name: style
	-- upvalues: (copy) v_u_5, (copy) v_u_3
	local v63 = p61 and 0.82 or 0.88
	local v64 = p61 and 0 or 0.2
	local v65
	if p61 then
		v65 = v_u_5.accent
	else
		v65 = v_u_5.text
	end
	p60.FillColor = v65
	local v66
	if p61 then
		v66 = v_u_5.accent
	else
		v66 = v_u_5.text
	end
	p60.OutlineColor = v66
	if p62 then
		p60.FillTransparency = 1
		p60.OutlineTransparency = 1
		v_u_3:Create(p60, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["FillTransparency"] = v63,
			["OutlineTransparency"] = v64
		}):Play()
	else
		p60.FillTransparency = v63
		p60.OutlineTransparency = v64
	end
end
v_u_6.adorneeFor = v_u_42
function v_u_6.holdsTask(_) -- name: holdsTask
	return false
end
v_u_6.TAG_TEXT = "TASK ITEM"
function v_u_6.clear() -- name: clear
	-- upvalues: (copy) v_u_14, (copy) v_u_18
	for _, v68 in v_u_14 do
		local v69 = v68.hl.Destroy
		local v70 = v68.hl
		pcall(v69, v70)
	end
	table.clear(v_u_14)
	table.clear(v_u_18)
end
local function v_u_73() -- name: eligible
	-- upvalues: (copy) v_u_7
	if v_u_7:GetAttribute("Place") == "Raid" then
		local v71 = v_u_7.Character
		local v72
		if v71 then
			v72 = v71:FindFirstChild("HumanoidRootPart")
		else
			v72 = v71
		end
		if v71 and (v72 and (v71:GetAttribute("Dead") ~= true and v71:GetAttribute("Downed") ~= true)) then
			return v72, v71
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_6.step(p74, _) -- name: step
	-- upvalues: (ref) v_u_17, (copy) v_u_6, (copy) v_u_7, (ref) v_u_10, (copy) v_u_14, (copy) v_u_73, (copy) v_u_1, (copy) v_u_18, (copy) v_u_42, (copy) v_u_59, (copy) v_u_67, (copy) v_u_23, (copy) v_u_5
	v_u_17 = v_u_17 + p74
	if v_u_17 < v_u_6.INTERVAL then
		return
	end
	v_u_17 = 0
	local v75 = v_u_7:GetAttribute("ObjectOutlines")
	local v76 = v_u_7:GetAttribute("UiHidden")
	local v77
	if v_u_10 then
		v77 = v_u_10.outlinesOn(v75, v76) == true
	elseif v75 == false then
		v77 = false
	else
		v77 = v76 ~= true
	end
	if not v77 then
		if next(v_u_14) then
			v_u_6.clear()
		end
		return
	end
	local v78, v79 = v_u_73()
	if not (v78 and v79) then
		if next(v_u_14) then
			v_u_6.clear()
		end
		return
	end
	local v80 = v78.Position
	local v81 = v80 + Vector3.new(0, 1.5, 0)
	local v82 = workspace:FindFirstChild("HushPreview")
	local v83 = v_u_6.range()
	local v84 = v_u_7:GetAttribute("TutorialFocusId")
	local v85 = {}
	for _, v86 in v_u_1:GetTagged("HushContainer") do
		if v86:GetAttribute("Cargo") == true or (not v_u_6.holdsLoot(v86) or v84 ~= nil and v86:GetAttribute("ContainerId") == v84) then
			continue
		end
		local v87
		if v86:IsA("Model") then
			v87 = v86:GetPivot().Position
		elseif v86:IsA("BasePart") then
			v87 = v86.Position
		else
			v87 = nil
		end
		if not v87 then
			continue
		end
		local v88 = v87.Y - v80.Y
		if math.abs(v88) > v_u_6.DY then
			continue
		end
		local v89 = v87.X - v80.X
		local v90 = v87.Z - v80.Z
		local v91 = Vector3.new(v89, 0, v90).Magnitude
		if v91 > v83 or (not v86:IsDescendantOf(workspace) or v82 and v86:IsDescendantOf(v82)) then
			continue
		end
		table.insert(v85, {
			["inst"] = v86,
			["d"] = v91,
			["pos"] = v87
		})
	end
	table.sort(v85, function(p92, p93)
		return p92.d < p93.d
	end)
	table.clear(v_u_18)
	local v94 = 0
	local v95 = {}
	for _, v96 in v85 do
		if v_u_6.MAX <= v94 then
			break
		end
		local v97 = v_u_42(v96.inst)
		if v_u_59(v81, v96.pos, v96.inst, v79) then
			continue
		end
		v94 = v94 + 1
		v95[v96.inst] = true
		local v98 = v_u_14[v96.inst]
		if v98 and (not v98.hl.Parent or v98.hl.Adornee ~= v97) then
			local v99 = v98.hl.Destroy
			local v100 = v98.hl
			pcall(v99, v100)
			v_u_14[v96.inst] = nil
			v98 = nil
		end
		if v98 then
			if v98.wish ~= false then
				v98.wish = false
				local v101 = v98.hl
				v101.FillColor = v_u_5.text
				v101.OutlineColor = v_u_5.text
				v101.FillTransparency = 0.88
				v101.OutlineTransparency = 0.2
			end
		else
			local v102 = Instance.new("Highlight")
			local v103 = v96.inst:GetAttribute("ContainerId") or v96.inst.Name
			v102.Name = "Glow_" .. tostring(v103)
			v102.DepthMode = Enum.HighlightDepthMode.Occluded
			v102.Adornee = v97
			v_u_67(v102, false, true)
			v102.Parent = v_u_23()
			v_u_14[v96.inst] = {
				["hl"] = nil,
				["wish"] = false,
				["hl"] = v102
			}
		end
		local v104 = v_u_18
		local v105 = string.format
		local v106 = v96.inst.Name
		local v107 = v96.d
		table.insert(v104, v105("%s %.1f", v106, v107))
	end
	local v108 = {}
	for v109 in v_u_14 do
		if v95[v109] then
			continue
		end
		table.insert(v108, v109)
	end
	for _, v110 in v108 do
		local v111 = v_u_14[v110]
		v_u_14[v110] = nil
		if not v111 then
			continue
		end
		local v112 = v111.hl.Destroy
		local v113 = v111.hl
		pcall(v112, v113)
	end
end
function v_u_6.state() -- name: state
	-- upvalues: (copy) v_u_14, (copy) v_u_18
	local v114 = 0
	local v115 = 0
	for _, v116 in v_u_14 do
		v114 = v114 + 1
		if not v116.wish then
			continue
		end
		v115 = v115 + 1
	end
	return string.format("n=%d wish=%d | %s", v114, v115, table.concat(v_u_18, " | "))
end
return v_u_6