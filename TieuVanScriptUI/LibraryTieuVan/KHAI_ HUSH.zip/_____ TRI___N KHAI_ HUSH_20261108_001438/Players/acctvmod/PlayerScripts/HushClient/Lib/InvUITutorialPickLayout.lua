-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITutorialPickLayout

local v_u_53 = {
	["HEIGHT"] = 40,
	["HEIGHT_TOUCH"] = 44,
	["MAX_W"] = 520,
	["MIN_W"] = 240,
	["SIDE"] = 16,
	["GAP"] = 6,
	["PAD"] = 8,
	["EM"] = 0.6,
	["TEXT"] = {
		["take"] = "Quick take",
		["sub"] = "or double click",
		["tap"] = "Tap the glowing item to take it"
	},
	["barHeight"] = function(p1) -- name: barHeight
		-- upvalues: (copy) v_u_53
		if p1 then
			return v_u_53.HEIGHT_TOUCH
		else
			return v_u_53.HEIGHT
		end
	end,
	["rect"] = function(p2, p3, p4, p5, p6) -- name: rect
		-- upvalues: (copy) v_u_53
		local v7 = v_u_53.barHeight(p4)
		local v8 = p2.X - 2 * v_u_53.SIDE
		local v9 = math.max(160, v8)
		local v10 = p3 + 8
		if p5 ~= nil and (p6 ~= nil and (p6.X > 0 and p6.Y > 0)) then
			local v11 = p6.X
			local v12 = v_u_53.MIN_W
			local v13 = math.max(v11, v12)
			local v14 = math.min(v13, v9)
			local v15 = p5.X
			local v16 = p2.X - 8 - v14
			local v17 = math.max(8, v16)
			local v18 = math.clamp(v15, 8, v17)
			local v19 = p5.Y - v7 - v_u_53.GAP
			if p3 <= v19 then
				return {
					["x"] = v18,
					["y"] = v19,
					["w"] = v14,
					["h"] = v7
				}
			end
			local v20 = p5.Y + p6.Y + v_u_53.GAP
			if v20 + v7 <= p2.Y - 4 then
				return {
					["x"] = v18,
					["y"] = v20,
					["w"] = v14,
					["h"] = v7
				}
			end
		end
		local v21 = v_u_53.MAX_W
		local v22 = math.min(v21, v9)
		local v23 = {}
		local v24 = (p2.X - v22) / 2
		v23.x = math.floor(v24)
		v23.y = v10
		v23.w = v22
		v23.h = v7
		return v23
	end,
	["rows"] = function(p25) -- name: rows
		-- upvalues: (copy) v_u_53
		return p25 == "Touch" and {
			["chip"] = false,
			["text"] = nil,
			["text"] = v_u_53.TEXT.tap
		} or (p25 == "Gamepad" and {
			["chip"] = true,
			["text"] = nil,
			["text"] = v_u_53.TEXT.take
		} or {
			["chip"] = true,
			["text"] = nil,
			["sub"] = nil,
			["text"] = v_u_53.TEXT.take,
			["sub"] = v_u_53.TEXT.sub
		})
	end,
	["fit"] = function(p26, p27, p28, p29, p30) -- name: fit
		-- upvalues: (copy) v_u_53
		local v31 = math.floor(p30 or 1)
		local v32 = math.max(1, v31)
		local v33 = p27 * v32 * (v32 > 1 and 0.9 or 1)
		local v34 = math.max(p28, p29)
		local v35 = math.floor(v34)
		local v36 = math.min(p28, p29)
		while v36 <= v35 do
			if #p26 * v35 * v_u_53.EM <= v33 + 0.01 then
				return v35, true
			end
			v35 = v35 - 1
		end
		return v36, false
	end,
	["content"] = function(p37, p38, p39, p40, p41) -- name: content
		-- upvalues: (copy) v_u_53
		local v42 = v_u_53.PAD
		local v43 = v_u_53.rows(p39)
		local v44, v45
		if p41 then
			local v46 = p38 - 8
			v44 = {
				["x"] = v42,
				["y"] = (p38 - v46) / 2,
				["w"] = v46,
				["h"] = v46
			}
			v45 = v42 + (v46 + v42)
		else
			v45 = v42
			v44 = nil
		end
		local v47
		if v43.chip and p40 > 0 then
			local v48 = v_u_53.HEIGHT_TOUCH <= p38 and 28 or 22
			v47 = {
				["x"] = v45,
				["y"] = (p38 - v48) / 2,
				["w"] = p40,
				["h"] = v48
			}
			v45 = v45 + (p40 + v42)
		else
			v47 = nil
		end
		local v49 = p37 - v45 - v42
		local v50 = math.max(0, v49)
		local v51 = nil
		local v52
		if v43.sub then
			v52 = {
				["x"] = nil,
				["y"] = 4,
				["w"] = nil,
				["h"] = 18,
				["x"] = v45,
				["w"] = v50
			}
			v51 = {
				["x"] = nil,
				["y"] = 22,
				["w"] = nil,
				["h"] = 14,
				["x"] = v45,
				["w"] = v50
			}
		else
			v52 = {
				["x"] = nil,
				["y"] = 4,
				["w"] = nil,
				["h"] = nil,
				["x"] = v45,
				["w"] = v50,
				["h"] = p38 - 8
			}
		end
		return {
			["icon"] = v44,
			["chip"] = v47,
			["text"] = v52,
			["sub"] = v51
		}
	end
}
return v_u_53