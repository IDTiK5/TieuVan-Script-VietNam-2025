-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuVotes

local v_u_1 = game:GetService("GuiService")
local v_u_2 = {}
local v_u_3 = nil
function v_u_2.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_3
	local v4
	if v_u_3 == nil then
		v4 = false
	else
		v4 = v_u_3.alive == true
	end
	return v4
end
function v_u_2.close() -- name: close
	-- upvalues: (ref) v_u_3
	local v5 = v_u_3
	if v5 and (v5.alive and v5.api) then
		v5.api.close()
	end
end
local function v_u_12(p6, p7, p8) -- name: metaText
	local v9 = p7.p
	local v10 = v9.closesAt
	local v11
	if type(v10) == "number" and v9.closesAt > 0 then
		v11 = v9.closesAt
	else
		v11 = nil
	end
	if p7.closed then
		return (not v11 or v11 > p8) and "Closed" or (p8 - v11 < 60 and "Closed just now" or "Closed " .. p6.Rail.spanText(p8 - v11) .. " ago")
	else
		return not v11 and "No closing date" or "Closes in " .. p6.Rail.spanText(v11 - p8)
	end
end
local function v_u_22() -- name: paintTexts
	-- upvalues: (ref) v_u_3, (copy) v_u_12
	local v13 = v_u_3
	if v13 and v13.alive then
		local v14 = v13.Rail.votesLive()
		if v14 then
			local v15 = v13.Rail.serverNow()
			for _, v16 in v14.rows do
				local v17 = v13.cards
				local v18 = v16.p.id
				local v19 = v17[tostring(v18)]
				if not v19 then
					continue
				end
				local v20 = v_u_12(v13, v16, v15)
				if v19.meta.Text == v20 then
					continue
				end
				v19.meta.Text = v20
			end
			local v21 = ("%d OPEN  \194\183  %d WAITING FOR YOUR VOTE"):format(v14.open, v14.openUnvoted)
			if v13.summary.Text ~= v21 then
				v13.summary.Text = v21
			end
		end
	else
		return
	end
end
local function v_u_32(p23, p24, p25, p26) -- name: voteButton
	-- upvalues: (copy) v_u_2
	local v27 = p23.UI
	local v28 = p23.Theme
	local v_u_29 = p25.id
	local v_u_30 = p26.id
	local _, v31 = v27.button({
		["parent"] = nil,
		["name"] = "Vote",
		["text"] = "Vote",
		["kind"] = "secondary",
		["width"] = 104,
		["height"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = p24,
		["height"] = v28.touch(36),
		["position"] = UDim2.new(1, -8, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_2, (copy) v_u_29, (copy) v_u_30
			v_u_2._cast(v_u_29, v_u_30)
		end
	})
	return v31
end
local function v_u_109(p33, p34, p35) -- name: buildCard
	-- upvalues: (copy) v_u_32
	local v36 = p33.UI
	local v37 = p33.Theme
	local v38 = p33.C
	local v39 = p33.Rail
	local v40 = p34.p
	local v41 = v40.id
	local v42 = tostring(v41)
	local v43 = not p34.closed
	local v44 = p34.mine ~= nil
	local v45 = p34.closed or v44
	local v46 = v36.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Poll_" .. v42,
		["BackgroundColor3"] = v38.raised,
		["Size"] = UDim2.new(1, -8, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p35
	}, p33.list)
	local v47 = v36.stroke
	local v48
	if v43 and not v44 then
		v48 = v38.accentDim
	else
		v48 = v38.line
	end
	v47(v46, v48)
	if v43 and not v44 then
		v36.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v38.accent,
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v46)
	end
	local v49 = v36.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v46)
	v36.pad(v49, {
		16,
		16,
		14,
		14
	})
	v36.layout(v49, "v", 10)
	local v50 = v36.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v49)
	local v51 = p34.closed and "CLOSED" or (v44 and "VOTED" or "OPEN")
	local v52 = p34.closed and "muted" or (v44 and "success" or "accent")
	v36.badge(v51, v52, {
		["parent"] = nil,
		["height"] = 20,
		["anchor"] = nil,
		["position"] = nil,
		["parent"] = v50,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, 0, 0, 1)
	})
	local v53 = v36.label
	local v54 = {
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "h3",
		["textSize"] = 17,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["size"] = nil,
		["parent"] = v50
	}
	local v55 = v40.title
	v54.text = tostring(v55)
	v54.size = UDim2.new(1, -100, 0, 0)
	v53(v54)
	local v56 = 2
	local v57 = v40.desc
	local v58 = type(v57) ~= "string" and "" or v40.desc
	if v58 ~= "" then
		v36.label({
			["parent"] = nil,
			["name"] = "Desc",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["order"] = nil,
			["parent"] = v49,
			["text"] = v58,
			["color"] = v38.text2,
			["order"] = v56
		})
		v56 = v56 + 1
	end
	local v59 = v36.label({
		["parent"] = nil,
		["name"] = "Meta",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["size"] = nil,
		["order"] = nil,
		["parent"] = v49,
		["color"] = v38.text2,
		["size"] = UDim2.new(1, 0, 0, 18),
		["order"] = v56
	})
	local v60 = v56 + 1
	local v61 = v36.new("Frame", {
		["Name"] = "Options",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v60
	}, v49)
	local v62 = v60 + 1
	v36.layout(v61, "v", 6)
	local v63 = v39.pollTotal(v40)
	local v64 = v37.touch(48)
	local v65 = {}
	local v66 = nil
	for v67, v_u_68 in v40.options do
		local v69 = v36.new
		local v70 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true
		}
		local v71 = v_u_68.id
		v70.Name = "Opt_" .. tostring(v71)
		v70.BackgroundColor3 = v38.bg
		v70.Size = UDim2.new(1, 0, 0, v64)
		v70.LayoutOrder = v67
		local v72 = v69("Frame", v70, v61)
		local v_u_73
		if v44 then
			v_u_73 = p34.mine == v_u_68.id
		else
			v_u_73 = v44
		end
		local v74 = v36.stroke
		local v75
		if v_u_73 then
			v75 = v38.accent
		else
			v75 = v38.line
		end
		v74(v72, v75)
		if v45 then
			local v76 = v_u_68.n
			local v77 = tonumber(v76) or 0
			local v78
			if v63 > 0 then
				local v79 = v77 / v63
				v78 = math.clamp(v79, 0, 1)
			else
				v78 = 0
			end
			local v80 = v36.new
			local v81 = "Frame"
			local v82 = {
				["Name"] = "Fill",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 1
			}
			local v83
			if v_u_73 then
				v83 = v38.accent
			else
				v83 = v38.lineStrong
			end
			v82.BackgroundColor3 = v83
			v82.BackgroundTransparency = v_u_73 and 0.6 or 0.35
			v82.Size = UDim2.new(p33.animate[v42] and 0 or v78, 0, 1, 0)
			local v84 = v80(v81, v82, v72)
			if p33.animate[v42] then
				v36.tween(v84, {
					["Size"] = UDim2.new(v78, 0, 1, 0)
				}, "slower")
			end
			local v85
			if v_u_73 then
				v36.icon("check", {
					["parent"] = nil,
					["size"] = 16,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["zindex"] = 3,
					["parent"] = v72,
					["color"] = v38.accent,
					["position"] = UDim2.new(0, 14, 0.5, 0),
					["anchor"] = Vector2.new(0, 0.5)
				})
				v85 = 38
			else
				v85 = 14
			end
			local v86 = v36.label
			local v87 = {
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = nil,
				["textSize"] = 15,
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["zindex"] = 3,
				["parent"] = v72
			}
			local v88 = v_u_68.text
			v87.text = tostring(v88)
			v87.style = v_u_73 and "bodyStrong" or "body"
			v87.position = UDim2.fromOffset(v85, 0)
			v87.size = UDim2.new(1, -v85 - 120, 1, 0)
			v86(v87).TextTruncate = Enum.TextTruncate.AtEnd
			local v89 = v36.label
			local v90 = {
				["parent"] = nil,
				["name"] = "Figures",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 13,
				["color"] = nil,
				["align"] = "right",
				["track"] = false,
				["position"] = nil,
				["anchor"] = nil,
				["size"] = nil,
				["zindex"] = 3,
				["parent"] = v72,
				["text"] = ("%d%%  \194\183  %d"):format(v39.percent(v77, v63), v77)
			}
			local v91
			if v_u_73 then
				v91 = v38.text
			else
				v91 = v38.text2
			end
			v90.color = v91
			v90.position = UDim2.new(1, -12, 0, 0)
			v90.anchor = Vector2.new(1, 0)
			v90.size = UDim2.fromOffset(104, v64)
			v89(v90)
			v36.tooltip(v72, function()
				-- upvalues: (copy) v_u_73, (copy) v_u_68
				local v92 = {
					["title"] = v_u_73 and "YOUR VOTE" or "OPTION"
				}
				local v93 = v_u_68.text
				v92.body = tostring(v93)
				return v92
			end)
		else
			local v94 = v36.label
			local v95 = {
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "body",
				["textSize"] = 15,
				["track"] = false,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v72
			}
			local v96 = v_u_68.text
			v95.text = tostring(v96)
			v95.position = UDim2.fromOffset(14, 0)
			v95.size = UDim2.new(1, -138, 1, 0)
			v94(v95).TextTruncate = Enum.TextTruncate.AtEnd
			local v97 = v_u_32(p33, v72, v40, v_u_68)
			table.insert(v65, v97)
			v66 = v66 or v72:FindFirstChild("Vote")
			v36.tooltip(v72, function()
				-- upvalues: (copy) v_u_68
				local v98 = {
					["title"] = "OPTION",
					["body"] = nil
				}
				local v99 = v_u_68.text
				v98.body = tostring(v99)
				return v98
			end)
		end
	end
	local v100 = v36.new("Frame", {
		["Name"] = "Foot",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 18),
		["LayoutOrder"] = v62
	}, v49)
	local v101 = v36.label({
		["parent"] = nil,
		["name"] = "Note",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["size"] = nil,
		["parent"] = v100,
		["color"] = v38.text2,
		["size"] = UDim2.new(1, -110, 1, 0)
	})
	local v102 = v36.label({
		["parent"] = nil,
		["name"] = "Total",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = 13,
		["color"] = nil,
		["align"] = "right",
		["track"] = false,
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["parent"] = v100,
		["color"] = v38.text2,
		["position"] = UDim2.new(1, 0, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.fromOffset(104, 18)
	})
	local v103 = p33.errors[v42]
	if v103 and os.clock() > v103.untilAt then
		p33.errors[v42] = nil
		v103 = nil
	end
	if v103 then
		v101.Text = v103.text
		v101.TextColor3 = v38.danger
	elseif p33.busy == v42 then
		v101.Text = "Sending your vote..."
	elseif p33.busy == nil or (v44 or p34.closed) then
		if v44 then
			local v104 = p34.mine
			local v105 = "You voted: "
			for _, v106 in v40.options do
				if v106.id ~= v104 then
					continue
				end
				local v107 = v106.text
				v108 = tostring(v107)
			end
			local v108 = "?"
			v101.Text = v105 .. v108
			v101.TextColor3 = v38.accent
		elseif p34.closed then
			v101.Text = "Closed. You did not vote in this poll."
		else
			v101.Text = "Results show after you vote."
		end
	else
		v101.Text = "Wait for your other vote to be sent."
	end
	if v45 then
		v102.Text = v63 == 1 and "1 vote" or ("%d votes"):format(v63)
	end
	return {
		["frame"] = v46,
		["meta"] = v59,
		["voteApis"] = v65,
		["firstVote"] = v66,
		["foot"] = v101,
		["voted"] = v44
	}
end
local function v_u_131(p110) -- name: signature
	local v111 = {}
	for _, v112 in p110 do
		local v113 = v112.p
		local v114 = {}
		for _, v115 in v113.options do
			local v116 = v115.id
			local v117 = tostring(v116)
			local v118 = v115.n
			local v119 = v117 .. "=" .. tostring(v118)
			table.insert(v114, v119)
		end
		local v120 = v113.id
		local v121 = tostring(v120)
		local v122 = v112.closed
		local v123 = tostring(v122)
		local v124 = v112.mine
		local v125 = tostring(v124)
		local v126 = v113.title
		local v127 = tostring(v126)
		local v128 = v113.desc
		local v129 = tostring(v128)
		local v130 = table.concat
		table.insert(v111, ("%s|%s|%s|%s|%s|%s"):format(v121, v123, v125, v127, v129, v130(v114, ",")))
	end
	return table.concat(v111, ";")
end
local function v_u_174(p_u_132) -- name: rebuild
	-- upvalues: (copy) v_u_131, (copy) v_u_109, (copy) v_u_22
	local v_u_133 = p_u_132.Rail
	local v_u_134 = p_u_132.Kit
	local v_u_135 = p_u_132.UI
	local v_u_136 = p_u_132.C
	local v_u_137 = v_u_133.votesLive()
	local v_u_138
	if v_u_137 then
		if not p_u_132.pinned then
			p_u_132.pin = p_u_132.Rail.pinOrder(v_u_137.rows)
			if p_u_132.Rail.stamp("votes") >= p_u_132.openedAt then
				p_u_132.pinned = true
			end
		end
		v_u_138 = p_u_132.Rail.pinnedRows(v_u_137.rows, p_u_132.pin)
	else
		v_u_138 = {}
	end
	local v139
	if v_u_137 then
		v139 = #v_u_138 == 0 and "empty" or v_u_131(v_u_138)
	else
		v139 = v_u_133.failed("votes") and "failed" or "loading"
	end
	local v140 = ""
	for v141, v142 in p_u_132.errors do
		v140 = v140 .. v141 .. v142.text
	end
	local v143 = p_u_132.busy ~= nil
	local v144 = v139 .. "#" .. v140 .. "#" .. tostring(v143)
	if v144 ~= p_u_132.sig then
		p_u_132.sig = v144
		local v145 = not v_u_137 or #v_u_138 == 0
		local v146 = p_u_132.list
		local v147 = UDim2.new
		local v148 = 1
		local v149 = 0
		local v150 = 0
		local v151
		if v145 then
			local v152 = p_u_132.listH
			v151 = math.min(v152, 176)
		else
			v151 = p_u_132.listH
		end
		v146.Size = v147(v148, v149, v150, v151)
		v_u_135.keepScroll(p_u_132.list, function()
			-- upvalues: (copy) v_u_134, (copy) p_u_132, (copy) v_u_137, (copy) v_u_138, (copy) v_u_135, (copy) v_u_133, (copy) v_u_136, (ref) v_u_109
			v_u_134.clear(p_u_132.list)
			p_u_132.cards = {}
			p_u_132.firstVote = nil
			if v_u_137 and #v_u_138 ~= 0 then
				local v153 = false
				for v154, v155 in v_u_138 do
					local v156 = v_u_109(p_u_132, v155, v154)
					local v157 = p_u_132.cards
					local v158 = v155.p.id
					v157[tostring(v158)] = v156
					if not p_u_132.firstVote and v156.firstVote then
						p_u_132.firstVote = v156.firstVote
					end
					for _, v159 in v156.voteApis do
						v159.setEnabled(p_u_132.busy == nil)
					end
					if not v155.closed or v155.p.total ~= nil then
						break
					end
					v153 = true
				end
				p_u_132.animate = {}
				if v153 and not p_u_132.refetch then
					p_u_132.refetch = true
					task.delay(1.5, function()
						-- upvalues: (ref) p_u_132, (ref) v_u_133
						p_u_132.refetch = false
						if p_u_132.alive then
							v_u_133.fetch(p_u_132.mc, "votes", {
								["force"] = true
							})
						end
					end)
				end
			else
				local v160 = v_u_135.new("Frame", {
					["Name"] = "Empty",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, -8, 0, 168)
				}, p_u_132.list)
				local v161 = v_u_133.glyph("vote", v160, 40, v_u_136.muted)
				v161.AnchorPoint = Vector2.new(0.5, 0)
				v161.Position = UDim2.new(0.5, 0, 0, 26)
				local v162 = v_u_137 and "No votes right now. New ones appear here." or (not v_u_133.failed("votes") and "Loading the votes..." or p_u_132.mc.failText("votes", "Votes are not available right now. Try again in a moment."))
				v_u_135.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["align"] = "center",
					["valign"] = "top",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v160,
					["text"] = v162,
					["color"] = v_u_136.text2,
					["position"] = UDim2.new(0.5, 0, 0, 84),
					["anchor"] = Vector2.new(0.5, 0),
					["size"] = UDim2.new(1, -64, 0, 60)
				}).TextYAlignment = Enum.TextYAlignment.Top
			end
		end)
		v_u_22()
		local v_u_163 = p_u_132.reveal
		if v_u_163 and (p_u_132.cards[v_u_163] and p_u_132.cards[v_u_163].voted) then
			p_u_132.reveal = nil
			task.delay(0.7, function()
				-- upvalues: (copy) p_u_132, (copy) v_u_163
				local v164 = p_u_132.cards[v_u_163]
				local v165 = p_u_132.list
				if p_u_132.alive and (v164 and (v164.frame.Parent and v165.Parent)) then
					local v166 = v165.AbsoluteSize.Y
					local v167 = v165.Size.Y.Offset
					local v168 = v166 / math.max(1, v167)
					local v169 = (v164.frame.AbsolutePosition.Y - v165.AbsolutePosition.Y) / v168
					local v170 = v164.frame.AbsoluteSize.Y / v168
					local v171 = v165.AbsoluteWindowSize.Y / v168
					if v171 >= v170 and (v169 < 0 or v169 + v170 > v171) then
						if v169 >= 0 then
							v169 = v169 + v170 - v171
						end
						local v172 = v165.CanvasPosition.Y + v169
						local v173 = math.max(0, v172)
						p_u_132.UI.tween(v165, {
							["CanvasPosition"] = Vector2.new(0, v173)
						}, "normal")
					end
				else
					return
				end
			end)
		end
	end
end
function v_u_2._cast(p175, p176) -- name: _cast
	-- upvalues: (ref) v_u_3, (copy) v_u_174
	local v177 = v_u_3
	if v177 and (v177.alive and not v177.busy) then
		local v178 = v177.mc
		local v179 = v177.Rail.votesLive()
		if v179 and not v177.pinned then
			v177.pin = v177.Rail.pinOrder(v179.rows)
		end
		v177.pinned = true
		v177.busy = tostring(p175)
		v177.busyAt = os.clock()
		v177.castAt = v177.updates
		v177.errors[tostring(p175)] = nil
		v_u_174(v177)
		if v177.Rail.stubActive("votes") then
			v177.Rail.stubVote(v178, tostring(p175), p176)
		else
			v178.op({
				["op"] = "voteCast",
				["poll"] = nil,
				["option"] = nil,
				["poll"] = p175,
				["option"] = p176
			})
		end
	else
		return
	end
end
local function v_u_185(p180, p181) -- name: onResult
	-- upvalues: (copy) v_u_174
	if type(p181) == "table" and p181.op == "voteCast" then
		local v182 = p180.busy
		if p181.ok == false then
			p180.busy = nil
			local v183 = p181.msg or p181.reason
			if not v183 then
				local v184 = p181.data
				if type(v184) == "table" then
					v183 = p181.data.reason
				else
					v183 = nil
				end
			end
			if v182 then
				p180.errors[v182] = {
					["text"] = (type(v183) ~= "string" or v183 == "") and "That did not work" or v183,
					["untilAt"] = os.clock() + 8
				}
			end
			p180.sig = ""
			v_u_174(p180)
			return
		else
			if v182 then
				p180.animate[v182] = true
				p180.reveal = v182
			end
			if p180.updates > p180.castAt then
				p180.busy = nil
				p180.sig = ""
				v_u_174(p180)
			else
				p180.fresh = true
			end
		end
	else
		return
	end
end
function v_u_2.update() -- name: update
	-- upvalues: (ref) v_u_3, (copy) v_u_174, (copy) v_u_22
	local v186 = v_u_3
	if v186 and v186.alive then
		v186.updates = v186.updates + 1
		if v186.fresh then
			v186.fresh = false
			v186.busy = nil
			v186.sig = ""
		end
		v_u_174(v186)
		v_u_22()
	end
end
function v_u_2.tick() -- name: tick
	-- upvalues: (ref) v_u_3, (copy) v_u_174, (copy) v_u_22
	local v187 = v_u_3
	if v187 and v187.alive then
		if v187.busy and os.clock() - v187.busyAt > 15 then
			v187.busy = nil
			v187.sig = ""
			v_u_174(v187)
		end
		for v188, v189 in v187.errors do
			if os.clock() <= v189.untilAt then
				continue
			end
			v187.errors[v188] = nil
			v187.sig = ""
			v_u_174(v187)
		end
		v_u_22()
	end
end
function v_u_2.open(p190, p191) -- name: open
	-- upvalues: (ref) v_u_3, (copy) v_u_1, (copy) v_u_185, (copy) v_u_2, (copy) v_u_174
	if not (v_u_3 and v_u_3.alive) then
		local v192 = p190.cctx.lib.MenuRail
		v192.bind(p190)
		local v_u_193 = p190.ui
		local v194 = p190.theme
		local v_u_195 = v194.color
		local v196 = v194.refSize()
		local v197 = v196.X - 32
		local v198 = math.min(720, v197)
		local v199 = v196.Y - 420
		local v_u_200 = math.clamp(v199, 150, 460)
		local v201 = v194.isTouch()
		local v_u_202 = {
			["alive"] = true,
			["mc"] = nil,
			["Rail"] = nil,
			["UI"] = nil,
			["Theme"] = nil,
			["C"] = nil,
			["Kit"] = nil,
			["cards"] = nil,
			["errors"] = nil,
			["animate"] = nil,
			["pin"] = nil,
			["pinned"] = false,
			["openedAt"] = nil,
			["reveal"] = nil,
			["sig"] = "",
			["listH"] = nil,
			["busy"] = nil,
			["busyAt"] = 0,
			["updates"] = 0,
			["castAt"] = 0,
			["returnTo"] = nil,
			["refetch"] = false,
			["mc"] = p190,
			["Rail"] = v192,
			["UI"] = v_u_193,
			["Theme"] = v194,
			["C"] = v_u_195,
			["Kit"] = p190.kit,
			["cards"] = {},
			["errors"] = {},
			["animate"] = {},
			["openedAt"] = os.clock(),
			["listH"] = v_u_200,
			["returnTo"] = p191
		}
		v_u_3 = v_u_202
		local v207 = {
			["title"] = "Votes",
			["body"] = "Help decide what comes next. You get one vote per poll, and it is final.",
			["width"] = nil,
			["build"] = nil,
			["buttons"] = nil,
			["onClose"] = nil,
			["width"] = v198,
			["build"] = function(p203) -- name: build
				-- upvalues: (copy) v_u_193, (copy) v_u_202, (copy) v_u_195, (copy) v_u_200
				local v204 = v_u_193.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 20)
				}, p203)
				v_u_202.summary = v_u_193.label({
					["parent"] = nil,
					["name"] = "Summary",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["track"] = false,
					["size"] = nil,
					["parent"] = v204,
					["color"] = v_u_195.text2,
					["size"] = UDim2.new(1, 0, 1, 0)
				})
				v_u_202.list = v_u_193.list({
					["parent"] = nil,
					["name"] = "VoteList",
					["size"] = nil,
					["gap"] = 12,
					["parent"] = p203,
					["size"] = UDim2.new(1, 0, 0, v_u_200)
				})
				v_u_202.list.LayoutOrder = 2
			end,
			["buttons"] = {
				{
					["text"] = "Close",
					["kind"] = "primary",
					["hint"] = nil,
					["hint"] = not v201 and "menu" or nil
				}
			},
			["onClose"] = function() -- name: onClose
				-- upvalues: (copy) v_u_202, (ref) v_u_3, (copy) v_u_193, (ref) v_u_1
				v_u_202.alive = false
				if v_u_202.conn then
					v_u_202.conn:Disconnect()
				end
				if v_u_202.unbind then
					local v205 = v_u_202.unbind
					pcall(v205)
				end
				if v_u_3 == v_u_202 then
					v_u_3 = nil
				end
				local v_u_206 = v_u_202.returnTo
				if v_u_206 and v_u_193.device() == "Gamepad" then
					task.delay(0.15, function()
						-- upvalues: (copy) v_u_206, (ref) v_u_193, (ref) v_u_1
						if v_u_206.Parent and (v_u_193.modalCount() == 0 and v_u_193.device() == "Gamepad") then
							v_u_1.SelectedObject = v_u_206
						end
					end)
				end
			end
		}
		v_u_202.api = v_u_193.modal(v207)
		v_u_202.conn = p190.changed:Connect(function(p208, p209)
			-- upvalues: (copy) v_u_202, (ref) v_u_185
			if p208 == "result" and v_u_202.alive then
				v_u_185(v_u_202, p209)
			end
		end)
		local v210 = p190.cctx.controllers.Input
		if v210 then
			local v211 = v210.bind
			if type(v211) == "function" then
				local v212 = v210.bind
				local function v213()
					-- upvalues: (ref) v_u_2
					v_u_2.close()
				end
				local v214, v215 = pcall(v212, "menu", v213)
				if v214 and type(v215) == "function" then
					v_u_202.unbind = v215
				end
			end
		end
		v_u_174(v_u_202)
		v192.fetch(p190, "votes", {
			["force"] = true
		})
		if v_u_193.device() == "Gamepad" then
			task.delay(0.2, function()
				-- upvalues: (copy) v_u_202, (ref) v_u_1
				if v_u_202.alive and (v_u_202.firstVote and v_u_202.firstVote.Parent) then
					v_u_1.SelectedObject = v_u_202.firstVote
				end
			end)
		end
	end
end
return v_u_2