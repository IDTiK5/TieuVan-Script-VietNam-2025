-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIXDebug

return {
	["install"] = function(p1, p_u_2) -- name: install
		local v_u_3 = p_u_2.AmmoUI
		local v_u_4 = p_u_2.Ext
		local v_u_5 = p_u_2.HushUI
		local v_u_6 = p_u_2.InventoryUI
		local v_u_7 = p_u_2.ItemIcons
		local v_u_8 = p_u_2.Items
		local v_u_9 = p_u_2.LootGlow
		local v_u_10 = p_u_2.SLOT_DEFS
		local v_u_11 = p_u_2.Theme
		local v_u_12 = p_u_2.mounts
		local v_u_13 = p_u_2.player
		local v_u_14 = p_u_2.actionsFor
		local v_u_15 = p_u_2.applyWishlist
		local v_u_16 = p_u_2.beginDrag
		local v_u_17 = p_u_2.buildDragStrip
		local v_u_18 = p_u_2.cellReal
		local v_u_19 = p_u_2.designRect
		local v_u_20 = p_u_2.endDrag
		local v_u_21 = p_u_2.locate
		local v_u_22 = p_u_2.openContext
		local v_u_23 = p_u_2.overlapArea
		local v_u_24 = p_u_2.primaryAction
		local v_u_25 = p_u_2.rotateDrag
		local v_u_26 = p_u_2.runAction
		local v_u_27 = p_u_2.screenDesign
		local v_u_28 = p_u_2.sectionOf
		local v_u_29 = p_u_2.setEqExpanded
		local v_u_30 = p_u_2.setMountSection
		local v_u_31 = p_u_2.setWishId
		local v_u_32 = p_u_2.slotItem
		local v_u_33 = p_u_2.stripAvoid
		local v_u_34 = p_u_2.stripButton
		local v_u_35 = p_u_2.updateDrag
		local v_u_36 = p_u_2.wishedId
		p1.command("invui.glow", function()
			-- upvalues: (copy) v_u_9
			return v_u_9.state()
		end)
		p1.command("invui.wishset", function(p37)
			-- upvalues: (copy) v_u_8, (copy) v_u_31, (copy) v_u_36
			local v38 = p37[1]
			if not (v38 and v_u_8.get(v38)) then
				return "usage: invui.wishset <itemId> <on|off>"
			end
			v_u_31(v38, p37[2] ~= "off")
			local v39 = v_u_36
			return v38 .. " -> " .. tostring(v39(v38))
		end)
		p1.command("invui.wish", function(p40)
			-- upvalues: (copy) p_u_2, (copy) v_u_15
			local v41 = table.concat(p40, ",")
			local v42 = p_u_2.setWishOverride
			if v41 == "" or v41 == "off" then
				v41 = nil
			end
			v42(v41)
			v_u_15()
			local v43 = 0
			for _ in p_u_2.wishSet() do
				v43 = v43 + 1
			end
			return "wishlist " .. v43 .. " ids"
		end)
		p1.command("invui.open", function()
			-- upvalues: (copy) v_u_6
			v_u_6.open()
			local v44 = v_u_6.isOpen
			return "open=" .. tostring(v44())
		end)
		p1.command("invui.close", function()
			-- upvalues: (copy) v_u_6
			v_u_6.close()
			local v45 = v_u_6.isOpen
			return "open=" .. tostring(v45())
		end)
		local function v_u_53(p46, p47) -- name: findUid
			-- upvalues: (copy) v_u_21, (copy) v_u_10, (copy) v_u_32
			local v48 = p46.work
			if v_u_21(v48, p47) then
				return p47
			end
			for _, v49 in v48 and (v48.containers or {}) or {} do
				for _, v50 in v49.items or {} do
					if v50.id ~= p47 then
						continue
					end
					return v50.uid
				end
			end
			for _, v51 in v_u_10 do
				local v52 = v_u_32(v48, v51.id)
				if not v52 or v52.id ~= p47 then
					continue
				end
				return v52.uid
			end
			return nil
		end
		local function v_u_55() -- name: activeMount
			-- upvalues: (copy) p_u_2, (copy) v_u_12
			if p_u_2.raidMount() and p_u_2.raidMount().opened then
				return p_u_2.raidMount()
			end
			for _, v54 in v_u_12 do
				if not v54.isShown() then
					continue
				end
				return v54
			end
			return nil
		end
		p1.command("invui.act", function(p56)
			-- upvalues: (copy) v_u_55, (copy) v_u_53, (copy) v_u_26
			local v57 = v_u_55()
			if not v57 then
				return "no inventory shown"
			end
			local v58 = v_u_53(v57, p56[2] or "")
			if not v58 then
				local v59 = p56[2]
				return "no item " .. tostring(v59)
			end
			v_u_26(v57, v58, p56[1] or "inspect")
			local v60 = p56[1]
			return "ran " .. tostring(v60) .. " on " .. v58
		end)
		local function v_u_66(p61, p62, p63) -- name: findIn
			-- upvalues: (copy) v_u_53
			if not p63 or p63 == "" then
				return v_u_53(p61, p62)
			end
			local v64 = p61.work and p61.work.containers
			if v64 then
				v64 = p61.work.containers[p63]
			end
			for _, v65 in v64 and v64.items or {} do
				if v65.uid ~= p62 and v65.id ~= p62 then
					continue
				end
				return v65.uid
			end
			return nil
		end
		p1.command("invui.ctx", function(p67)
			-- upvalues: (copy) v_u_55, (copy) v_u_53, (copy) v_u_22, (copy) v_u_27, (copy) v_u_11, (copy) v_u_3, (copy) v_u_14
			local v68 = v_u_55()
			local v69
			if v68 then
				v69 = v_u_53(v68, p67[1] or "")
			else
				v69 = v68
			end
			if not (v68 and v69) then
				return "no item"
			end
			local v70 = v_u_22
			local v71
			if p67[2] then
				local v72 = Vector2.new
				local v73 = p67[2]
				local v74 = tonumber(v73) or 0
				local v75 = p67[3]
				v71 = v72(v74, tonumber(v75) or 0)
			else
				v71 = v_u_27() * v_u_11.uiScale() * 0.5
			end
			v70(v68, v69, v71)
			return v_u_3.describe(v_u_14(v68, v69))
		end)
		p1.command("invui.dbl", function(p76)
			-- upvalues: (copy) v_u_55, (copy) v_u_66, (copy) v_u_4, (copy) v_u_24
			local v77 = v_u_55()
			if v77 then
				local v78 = v_u_66
				local v79 = p76[1] or ""
				local v80
				if p76[2] == "-" then
					v80 = nil
				else
					v80 = p76[2]
				end
				local v81 = v78(v77, v79, v80)
				if v81 then
					if p76[3] == "mouse" then
						v_u_4.mouseDouble(v77, v81)
					else
						v_u_24(v77, v81)
					end
					return "dbl " .. v81
				else
					local v82 = p76[1]
					return "no item " .. tostring(v82)
				end
			else
				return "no inventory shown"
			end
		end)
		p1.command("invui.tap", function(p83)
			-- upvalues: (copy) v_u_55, (copy) v_u_66, (copy) v_u_21, (copy) v_u_26
			local v84 = v_u_55()
			if not v84 then
				return "no inventory shown"
			end
			local v85 = v_u_66(v84, p83[1] or "", p83[2])
			if not v85 then
				local v86 = p83[1]
				return "no item " .. tostring(v86)
			end
			local v87 = v_u_21(v84.work, v85)
			v_u_26(v84, v85, v87 and v87.kind == "slot" and "unequip" or "quick")
			return "tap " .. v85
		end)
		p1.command("invui.drag", function(p88)
			-- upvalues: (copy) v_u_55, (copy) v_u_53, (copy) v_u_16, (copy) v_u_25, (copy) v_u_18, (copy) v_u_35, (copy) p_u_2, (copy) v_u_20
			local v89 = v_u_55()
			if not v89 then
				return "no inventory shown"
			end
			local v90 = v_u_53(v89, p88[1] or "")
			local v91 = v89.grids[p88[2] or ""]
			local v92 = v89.slots[p88[2] or ""]
			if not (v90 and (v91 or v92)) then
				return "bad args"
			end
			local v93 = v89.tiles[v90]
			local v94
			if v93 then
				v94 = v93.frame
			else
				v94 = nil
			end
			if not v94 then
				for _, v95 in v89.slots do
					if not v95.tile or v95.tile.inst.uid ~= v90 then
						continue
					end
					v94 = v95.tile.frame
				end
			end
			if not v94 then
				return "no tile"
			end
			v_u_16({
				["m"] = nil,
				["uid"] = nil,
				["tile"] = nil,
				["tileFrame"] = nil,
				["io"] = nil,
				["touch"] = false,
				["m"] = v89,
				["uid"] = v90,
				["tile"] = v93,
				["tileFrame"] = v94
			}, v94.AbsolutePosition + Vector2.new(4, 4))
			if p88[5] == "r" then
				v_u_25()
			end
			local v96 = v_u_18(v89)
			local v97
			if v91 then
				local v98 = v91.cells.AbsolutePosition
				local v99 = Vector2.new
				local v100 = p88[3]
				local v101 = (tonumber(v100) or 0) * v96
				local v102 = p88[4]
				v97 = v98 + v99(v101, (tonumber(v102) or 0) * v96) + Vector2.new(4, 4)
			else
				v97 = v92.frame.AbsolutePosition + v92.frame.AbsoluteSize * 0.5
			end
			v_u_35(v97)
			local v103 = p_u_2.drag()
			if v103 then
				v103 = p_u_2.drag().target
			end
			local v104
			if v103 then
				local v105 = v103.kind
				local v106 = v103.container or (v103.slot or v103.index)
				local v107 = tostring(v106)
				local v108 = v103.x
				local v109 = tostring(v108)
				local v110 = v103.y
				v104 = v105 .. " " .. v107 .. " " .. v109 .. "," .. tostring(v110)
			else
				v104 = "INVALID"
			end
			v_u_20(v97)
			return "drop -> " .. v104
		end)
		p1.command("invui.hold", function(p111)
			-- upvalues: (copy) v_u_55, (copy) p_u_2, (copy) v_u_20, (copy) v_u_53, (copy) v_u_16, (copy) v_u_25, (copy) v_u_18, (copy) v_u_35, (copy) v_u_17
			local v112 = v_u_55()
			if not v112 then
				return "no inventory shown"
			end
			if p_u_2.drag() then
				v_u_20(p_u_2.drag().pos, true)
			end
			local v113 = v_u_53(v112, p111[1] or "")
			local v114 = v112.grids[p111[2] or ""]
			if not (v113 and v114) then
				return "bad args"
			end
			local v115 = v112.tiles[v113]
			local v116
			if v115 then
				v116 = v115.frame
			else
				v116 = nil
			end
			if not v116 then
				for _, v117 in v112.slots do
					if not v117.tile or v117.tile.inst.uid ~= v113 then
						continue
					end
					v116 = v117.tile.frame
				end
			end
			if not v116 then
				return "no tile"
			end
			v_u_16({
				["m"] = nil,
				["uid"] = nil,
				["tile"] = nil,
				["tileFrame"] = nil,
				["io"] = nil,
				["touch"] = true,
				["m"] = v112,
				["uid"] = v113,
				["tile"] = v115,
				["tileFrame"] = v116
			}, v116.AbsolutePosition + v116.AbsoluteSize * 0.5)
			if not p_u_2.drag() then
				return "no drag"
			end
			if p111[5] == "r" then
				v_u_25()
			end
			local v118 = v_u_18(v112)
			local v119 = v114.cells.AbsolutePosition
			local v120 = Vector2.new
			local v121 = p111[3]
			local v122 = (tonumber(v121) or 0) * v118
			local v123 = p111[4]
			v_u_35(v119 + v120(v122, (tonumber(v123) or 0) * v118) + p_u_2.drag().grab)
			v_u_17(p_u_2.drag())
			local v124 = p_u_2.drag().target
			local v125 = "holding -> "
			local v126
			if v124 then
				local v127 = v124.kind
				local v128 = v124.container or v124.slot
				local v129 = tostring(v128)
				local v130 = v124.x
				local v131 = tostring(v130)
				local v132 = v124.y
				v126 = v127 .. " " .. v129 .. " " .. v131 .. "," .. tostring(v132)
			else
				v126 = "INVALID"
			end
			return v125 .. v126
		end)
		p1.command("invui.holdtab", function(p133)
			-- upvalues: (copy) p_u_2, (copy) v_u_35, (copy) v_u_28
			local v134 = p_u_2.drag()
			if not v134 then
				return "no drag"
			end
			local v135 = v134.m.secTabFrame
			local v136 = v135 and v135.Parent
			if v136 then
				local v137 = p133[1]
				v136 = v135:FindFirstChild("Tab_" .. tostring(v137), true)
			end
			if v136 and v136:IsA("GuiObject") then
				v_u_35(v136.AbsolutePosition + v136.AbsoluteSize * 0.5)
				local v138 = p133[1]
				return "over tab " .. tostring(v138) .. ", section now " .. v_u_28(v134.m)
			end
			local v139 = p133[1]
			local v140 = tostring(v139)
			local v141 = v134.m.narrow == true
			return "no tab " .. v140 .. " (narrow=" .. tostring(v141) .. ")"
		end)
		p1.command("invui.release", function()
			-- upvalues: (copy) p_u_2, (copy) v_u_20
			if not p_u_2.drag() then
				return "no drag"
			end
			local v142 = p_u_2.drag().target
			local v143
			if v142 then
				local v144 = v142.kind
				local v145 = v142.container or (v142.slot or v142.index)
				local v146 = tostring(v145)
				local v147 = v142.x
				local v148 = tostring(v147)
				local v149 = v142.y
				v143 = v144 .. " " .. v146 .. " " .. v148 .. "," .. tostring(v149)
			else
				v143 = "INVALID (returns)"
			end
			v_u_20(p_u_2.drag().pos)
			local v150 = "released -> "
			local v151 = " | sel="
			local v152 = p_u_2.sel()
			if v152 then
				v152 = p_u_2.sel().uid
			end
			return v150 .. v143 .. v151 .. tostring(v152)
		end)
		p1.command("invui.grab", function(p153)
			-- upvalues: (copy) v_u_4, (copy) p_u_2
			return v_u_4.TD.dbgGrab(p_u_2.drag(), p153, v_u_4.padApi)
		end)
		p1.command("invui.strip", function(p154)
			-- upvalues: (copy) p_u_2, (copy) v_u_34
			if not p_u_2.sel() then
				return "nothing selected"
			end
			v_u_34(p_u_2.sel().m, p_u_2.sel().uid, p154[1] or "cancel")
			local v155 = "pressed "
			local v156 = p154[1]
			local v157 = tostring(v156)
			local v158 = " | sel="
			local v159 = p_u_2.sel()
			if v159 then
				v159 = p_u_2.sel().uid
			end
			return v155 .. v157 .. v158 .. tostring(v159)
		end)
		p1.command("invui.sel", function()
			-- upvalues: (copy) p_u_2, (copy) v_u_21, (copy) v_u_19, (copy) v_u_33, (copy) v_u_23
			if not p_u_2.sel() then
				return "nothing selected"
			end
			local v160 = v_u_21(p_u_2.sel().m.work, p_u_2.sel().uid)
			local v161
			if v160 then
				if v160.kind == "slot" then
					v161 = "slot " .. v160.slot
				else
					local v162 = string.format
					local v163 = v160.container
					local v164 = v160.item.x
					local v165 = v160.item.y
					local v166 = v160.item.r == true
					v161 = v162("%s %d,%d r=%s", v163, v164, v165, (tostring(v166)))
				end
			else
				v161 = "gone"
			end
			local v167
			if p_u_2.sidePanel() and p_u_2.sidePanel().Parent then
				local v168 = v_u_19(p_u_2.sidePanel())
				local v169 = 0
				for _, v170 in v_u_33(p_u_2.sel().m, nil) do
					if v170.w < 1 then
						continue
					end
					v169 = v169 + v_u_23(v168, v170.r)
				end
				local v171 = {}
				for _, v172 in p_u_2.sidePanel():GetChildren() do
					if not v172:IsA("TextButton") then
						continue
					end
					local v173 = v172.Name
					table.insert(v171, v173)
				end
				local v174 = string.format
				local v175 = p_u_2.sidePanel()
				v167 = v174("%s @%d,%d %dx%d gridCover=%dpx2 [%s]", tostring(v175:GetAttribute("Shape")), v168[1], v168[2], v168[3] - v168[1], v168[4] - v168[2], v169, table.concat(v171, ","))
			else
				v167 = "none"
			end
			local v176 = string.format
			local v177 = "%s at %s | origin %s | strip %s"
			local v178 = p_u_2.sel().uid
			local v179 = p_u_2.sel().origin
			if v179 then
				v179 = p_u_2.sel().origin.container or p_u_2.sel().origin.slot
			end
			return v176(v177, v178, v161, tostring(v179), v167)
		end)
		p1.command("invui.rail", function(p180)
			-- upvalues: (copy) v_u_55, (copy) v_u_29
			local v181 = v_u_55()
			if v181 and v181.rail then
				v_u_29(v181, p180[1] ~= "close")
				local v182 = v181.rail.expanded
				return "rail expanded=" .. tostring(v182)
			else
				local v183 = "no rail (split="
				if v181 then
					v181 = v181.split
				end
				return v183 .. tostring(v181) .. ")"
			end
		end)
		p1.command("invui.fsm", function()
			-- upvalues: (copy) v_u_4, (copy) p_u_2
			local v184 = v_u_4.TD.fsm
			local v185 = p_u_2.drag()
			local v186 = string.format
			local v187 = "fsm=%s id=%s hold=%s | drag=%s parked=%s | sel=%s | healed=%d (%s) | idle for %.2f s"
			local v188 = v184.state
			local v189 = tostring(v188)
			local v190 = v184.id ~= nil
			local v191 = tostring(v190)
			local v192 = v184.instant
			local v193 = tostring(v192)
			local v194 = v185 ~= nil
			local v195 = tostring(v194)
			local v196
			if v185 == nil then
				v196 = false
			else
				v196 = v185.parked == true
			end
			local v197 = tostring(v196)
			local v198
			if p_u_2.sel() == nil then
				v198 = false
			else
				v198 = p_u_2.sel().uid
			end
			local v199 = tostring(v198)
			local v200 = v_u_4.TD.healed or 0
			local v201 = v_u_4.TD.lastHeal
			return v186(v187, v189, v191, v193, v195, v197, v199, v200, tostring(v201), os.clock() - (v184.t0 or 0))
		end)
		p1.command("invui.vanish", function(p202)
			-- upvalues: (copy) v_u_55, (copy) v_u_66, (copy) v_u_21
			local v203 = v_u_55()
			if not v203 then
				return "no inventory shown"
			end
			local v204 = v_u_66(v203, p202[1] or "", p202[2])
			local v205
			if v204 then
				v205 = v_u_21(v203.work, v204)
			else
				v205 = v204
			end
			if not v205 or v205.kind ~= "grid" then
				local v206 = p202[1]
				return "no grid item " .. tostring(v206)
			end
			local v207 = table.find(v205.c.items, v205.item)
			if not v207 then
				return "not found"
			end
			table.remove(v205.c.items, v207)
			local v208 = v205.container
			return "vanished " .. v204 .. " from " .. tostring(v208)
		end)
		p1.command("invui.cancel", function()
			-- upvalues: (copy) p_u_2, (copy) v_u_20
			if not p_u_2.drag() then
				return "no drag"
			end
			v_u_20(p_u_2.drag().pos, true)
			return "cancelled"
		end)
		p1.command("invui.quick", function(p209)
			-- upvalues: (copy) v_u_6
			local v210 = v_u_6.useQuick
			local v211 = p209[1]
			return v210(tonumber(v211) or 0)
		end)
		p1.command("invui.section", function(p212)
			-- upvalues: (copy) v_u_6, (copy) p_u_2, (copy) v_u_30, (copy) v_u_12, (copy) v_u_28
			local v213 = v_u_6.setSection(p212[1] or "both")
			if p_u_2.raidMount() and (not p_u_2.raidMount().dead and v213 ~= "bad section") then
				v_u_30(p_u_2.raidMount(), v213)
			end
			local v214 = {}
			for v215, v216 in v_u_12 do
				local v217 = string.format
				local v218 = v216.mode
				local v219 = v216.narrow == true
				local v220 = tostring(v219)
				local v221 = v_u_28
				table.insert(v214, v217("#%d %s narrow=%s section=%s", v215, v218, v220, v221(v216)))
			end
			return v213 .. " | " .. table.concat(v214, " | ")
		end)
		p1.command("invui.tip", function(p222)
			-- upvalues: (copy) v_u_5, (copy) v_u_55, (copy) v_u_53
			local v223 = v_u_5.showTooltip
			local v224 = v_u_5.hideTooltip
			if p222[1] == "off" then
				if type(v224) == "function" then
					pcall(v224)
				end
				return "hidden"
			else
				local v225 = v_u_55()
				if v225 then
					local v226 = v_u_53(v225, p222[1] or "")
					if v226 then
						local v227 = v225.tiles[v226]
						if v227 then
							v227 = v225.tiles[v226].frame
						end
						if not v227 then
							for _, v228 in v225.slots do
								if not v228.tile or v228.tile.inst.uid ~= v226 then
									continue
								end
								v227 = v228.tile.frame
							end
						end
						if v227 then
							if type(v223) == "function" then
								local v229, v230 = pcall(v223, v227)
								if v229 then
									return "tip " .. v226
								else
									return "failed: " .. tostring(v230)
								end
							else
								return "HushUI.showTooltip missing (package G)"
							end
						else
							return "no tile"
						end
					else
						local v231 = p222[1]
						return "no item " .. tostring(v231)
					end
				else
					return "no inventory shown"
				end
			end
		end)
		p1.command("invui.check", function()
			-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_10, (copy) v_u_32, (copy) v_u_21, (copy) p_u_2, (copy) v_u_13
			local v233 = v_u_4.Dbg.check(v_u_12, v_u_10, v_u_32, v_u_21, function(p232)
				-- upvalues: (ref) p_u_2
				if p232.fake then
					return p232.fake
				elseif p232.mode == "raid" then
					return p_u_2.raidSnap()
				else
					return p_u_2.menuSnap()
				end
			end)
			v_u_13:SetAttribute("InvUICheck", v233)
			return v233
		end)
		p1.command("invui.dump", function()
			-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_18, (copy) v_u_7
			return v_u_4.Dbg.dump(v_u_12, v_u_18, v_u_7)
		end)
	end
}