-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRail

local v_u_1 = not (script and (script.Parent and script.Parent:FindFirstChild("ServerClock"))) and {
	["now"] = function() -- name: now
		return workspace:GetServerTimeNow()
	end
} or require(script.Parent.ServerClock)
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v_u_5 = v2.LocalPlayer
local v_u_6 = script.Parent
local v7
if v_u_6 then
	v7 = v_u_6:FindFirstChild("MailRows")
else
	v7 = nil
end
local v_u_8
if v7 and v7:IsA("ModuleScript") then
	local v9 = require
	local v10
	v10, v_u_8 = pcall(v9, v7)
	if not v10 or type(v_u_8) ~= "table" then
		v_u_8 = nil
	end
else
	v_u_8 = nil
end
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = {
	["mail"] = nil,
	["votes"] = nil,
	["stub"] = nil,
	["busy"] = nil,
	["again"] = nil,
	["failed"] = nil,
	["waiters"] = nil,
	["at"] = nil,
	["offset"] = 0,
	["listeners"] = nil,
	["rail"] = nil,
	["mailSig"] = "",
	["syncAt"] = -1000000000,
	["refreshAt"] = -1000000000,
	["mc"] = nil,
	["expired"] = 0,
	["noteRun"] = 0,
	["tips"] = nil,
	["switchOn"] = false,
	["lastData"] = nil,
	["seen"] = nil,
	["flagged"] = false,
	["cargoGone"] = false,
	["stub"] = {
		["mail"] = nil,
		["votes"] = nil
	},
	["busy"] = {
		["mail"] = false,
		["votes"] = false
	},
	["again"] = {
		["mail"] = false,
		["votes"] = false
	},
	["failed"] = {
		["mail"] = false,
		["votes"] = false
	},
	["waiters"] = {
		["mail"] = {},
		["votes"] = {}
	},
	["at"] = {
		["mail"] = -1000000000,
		["votes"] = -1000000000
	},
	["listeners"] = {},
	["tips"] = {},
	["seen"] = {}
}
function v_u_4.waitText(p16) -- name: waitText
	local v17 = tonumber(p16)
	local v18 = (v17 == nil or v17 ~= v17) and 0 or v17
	local v19 = math.ceil(v18)
	local v20 = math.max(0, v19)
	if v20 <= 0 then
		return "now"
	elseif v20 < 60 then
		return ("%d s"):format(v20)
	else
		local v21 = v20 / 60
		local v22 = math.ceil(v21)
		local v23 = v22 // 60
		local v24 = v22 % 60
		if v23 > 0 then
			if v24 > 0 then
				return ("%d h %d min"):format(v23, v24)
			else
				return ("%d h"):format(v23)
			end
		else
			return ("%d min"):format(v24)
		end
	end
end
function v_u_4.spanText(p25) -- name: spanText
	local v26 = tonumber(p25)
	local v27 = (v26 == nil or v26 ~= v26) and 0 or v26
	local v28 = math.floor(v27)
	local v29 = math.max(0, v28)
	if v29 < 60 then
		return "under a minute"
	else
		local v30 = v29 // 60
		local v31 = v30 // 1440
		local v32 = v30 % 1440 // 60
		local v33 = v30 % 60
		if v31 > 0 then
			if v32 > 0 then
				return ("%d d %d h"):format(v31, v32)
			else
				return ("%d d"):format(v31)
			end
		elseif v32 > 0 then
			if v33 > 0 then
				return ("%d h %d min"):format(v32, v33)
			else
				return ("%d h"):format(v32)
			end
		else
			return ("%d min"):format(v33)
		end
	end
end
function v_u_4.percent(p34, p35) -- name: percent
	local v36 = tonumber(p35)
	local v37 = (v36 == nil or v36 ~= v36) and 0 or v36
	if v37 <= 0 then
		return 0
	end
	local v38 = tonumber(p34)
	local v39 = ((v38 == nil or v38 ~= v38) and 0 or v38) / v37 * 100 + 0.5
	local v40 = math.floor(v39)
	return math.clamp(v40, 0, 100)
end
function v_u_4.mailRows(p41, p42) -- name: mailRows
	local v43 = {}
	if type(p41) ~= "table" then
		return v43
	end
	for _, v44 in p41 do
		if type(v44) ~= "table" then
			continue
		end
		local v45 = v44.id
		if type(v45) ~= "string" then
			continue
		end
		local v46 = v44.item
		if type(v46) ~= "table" or v44.kind == "delivery" then
			continue
		end
		local v47 = v44.readyAt
		local v48 = tonumber(v47)
		local v49 = ((v48 == nil or v48 ~= v48) and 0 or v48) - p42
		local v50 = math.max(0, v49)
		local v51 = {
			["e"] = v44,
			["left"] = v50,
			["ready"] = v50 <= 0
		}
		table.insert(v43, v51)
	end
	table.sort(v43, function(p52, p53)
		if p52.ready == p53.ready then
			local v54 = p52.e.readyAt
			local v55 = tonumber(v54)
			local v56 = (v55 == nil or v55 ~= v55) and 0 or v55
			local v57 = p53.e.readyAt
			local v58 = tonumber(v57)
			local v59 = (v58 == nil or v58 ~= v58) and 0 or v58
			if v56 == v59 then
				return p52.e.id < p53.e.id
			else
				return v56 < v59
			end
		else
			return p52.ready
		end
	end)
	return v43
end
function v_u_4.mailStats(p60) -- name: mailStats
	local v61 = 0
	local v62 = 0
	local v63 = nil
	for _, v64 in p60 do
		if v64.ready then
			v61 = v61 + 1
		else
			v62 = v62 + 1
			if v63 ~= nil and v64.left >= v63 then
				continue
			end
			v63 = v64.left
		end
	end
	return v61, v62, v63
end
function v_u_4.mailSig(p65) -- name: mailSig
	local v66 = {}
	if type(p65) == "table" then
		for _, v67 in p65 do
			if type(v67) ~= "table" then
				continue
			end
			local v68 = v67.id
			local v69 = tostring(v68)
			local v70 = v67.readyAt
			local v71 = tonumber(v70)
			local v72 = (v71 == nil or v71 ~= v71) and 0 or v71
			local v73 = math.floor(v72)
			table.insert(v66, ("%s@%d"):format(v69, v73))
		end
	end
	table.sort(v66)
	return table.concat(v66, ",")
end
function v_u_4.mailLayoutSig(p74) -- name: mailLayoutSig
	local v75 = {}
	local v76 = {}
	for _, v77 in p74 do
		local v78 = v77.e.id
		table.insert(v75, v78)
		local v79 = v77.e.id .. (v77.ready and "+" or "-")
		table.insert(v76, v79)
	end
	table.sort(v75)
	return table.concat(v75, ","), table.concat(v76, ",")
end
function v_u_4.pollState(p80, p81) -- name: pollState
	local v82
	if p80.closed == true then
		v82 = true
	else
		local v83 = p80.closesAt
		if type(v83) == "number" and p80.closesAt > 0 then
			v82 = p80.closesAt <= p81
		else
			v82 = false
		end
	end
	local v84 = p80.mine
	if v82 then
		return v82, v84, 3
	elseif v84 == nil then
		return v82, v84, 1
	else
		return v82, v84, 2
	end
end
function v_u_4.pollRows(p85, p86) -- name: pollRows
	-- upvalues: (copy) v_u_4
	local v87 = {}
	if type(p85) ~= "table" then
		return v87
	end
	for v88, v89 in p85 do
		if type(v89) ~= "table" or v89.id == nil then
			continue
		end
		local v90 = v89.options
		if type(v90) ~= "table" then
			continue
		end
		local v91, v92, v93 = v_u_4.pollState(v89, p86)
		table.insert(v87, {
			["p"] = v89,
			["closed"] = v91,
			["mine"] = v92,
			["group"] = v93,
			["idx"] = v88
		})
	end
	table.sort(v87, function(p94, p95)
		if p94.group == p95.group then
			return p94.idx < p95.idx
		else
			return p94.group < p95.group
		end
	end)
	return v87
end
function v_u_4.pollTotal(p96) -- name: pollTotal
	local v97 = p96.total
	if type(v97) == "number" then
		return p96.total
	end
	local v98 = 0
	for _, v99 in p96.options do
		local v100 = v99.n
		local v101 = tonumber(v100)
		v98 = v98 + ((v101 == nil or v101 ~= v101) and 0 or v101)
	end
	return v98
end
function v_u_4.pinOrder(p102) -- name: pinOrder
	local v103 = {}
	for v104, v105 in p102 do
		local v106 = v105.p.id
		v103[tostring(v106)] = v104
	end
	return v103
end
function v_u_4.pinnedRows(p107, p_u_108) -- name: pinnedRows
	if p_u_108 == nil then
		return p107
	end
	local v109 = table.clone(p107)
	table.sort(v109, function(p110, p111)
		-- upvalues: (copy) p_u_108
		local v112 = p_u_108
		local v113 = p110.p.id
		local v114 = v112[tostring(v113)]
		local v115 = p_u_108
		local v116 = p111.p.id
		local v117 = v115[tostring(v116)]
		if v114 and v117 then
			return v114 < v117
		elseif v114 or v117 then
			return v114 ~= nil
		elseif p110.group == p111.group then
			return p110.idx < p111.idx
		else
			return p110.group < p111.group
		end
	end)
	return v109
end
function v_u_4.serverNow() -- name: serverNow
	-- upvalues: (copy) v_u_1, (copy) v_u_15
	return v_u_1.now() + v_u_15.offset
end
function v_u_4.listen(p_u_118) -- name: listen
	-- upvalues: (copy) v_u_15
	local v119 = v_u_15.listeners
	table.insert(v119, p_u_118)
	return function()
		-- upvalues: (ref) v_u_15, (copy) p_u_118
		local v120 = table.find(v_u_15.listeners, p_u_118)
		if v120 then
			table.remove(v_u_15.listeners, v120)
		end
	end
end
function v_u_4.fetch(p_u_121, p_u_122, p123, p124) -- name: fetch
	-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_1
	local v_u_125 = p123 or {}
	if v_u_15.stub[p_u_122] then
		v_u_15[p_u_122] = {
			["data"] = nil,
			["clock"] = nil,
			["stub"] = true,
			["data"] = v_u_4._stubData(p_u_122),
			["clock"] = os.clock()
		}
		v_u_15.failed[p_u_122] = false
		if p_u_122 == "mail" then
			v_u_4._absorb(v_u_15[p_u_122].data)
		end
		for _, v126 in table.clone(v_u_15.listeners) do
			pcall(v126, p_u_122)
		end
		if p124 then
			task.spawn(p124)
		end
		return
	else
		if p124 then
			local v127 = v_u_15.waiters[p_u_122]
			table.insert(v127, p124)
		end
		if v_u_15.busy[p_u_122] then
			if v_u_125.force then
				v_u_15.again[p_u_122] = true
			end
		else
			v_u_15.busy[p_u_122] = true
			task.spawn(function()
				-- upvalues: (copy) p_u_122, (copy) v_u_125, (ref) v_u_15, (copy) p_u_121, (ref) v_u_1, (ref) v_u_4
				local v128
				if p_u_122 == "mail" and (v_u_125.refresh == true and os.clock() - v_u_15.refreshAt > 15) then
					v_u_15.refreshAt = os.clock()
					v128 = {
						["refresh"] = true
					}
				else
					v128 = nil
				end
				local v129 = p_u_121.fetch
				local v130 = p_u_122
				local v131 = v_u_125.force and 0 or (v_u_125.maxAge or 15)
				local v132, v133 = pcall(v129, v130, v128, v131)
				v_u_15.busy[p_u_122] = false
				v_u_15.at[p_u_122] = os.clock()
				if v132 and (type(v133) == "table" and (v133.error == nil and v_u_15.stub[p_u_122] == nil)) then
					v_u_15[p_u_122] = {
						["data"] = v133,
						["clock"] = os.clock()
					}
					v_u_15.failed[p_u_122] = false
					if p_u_122 == "mail" then
						local v134 = v133.serverTime
						local v135 = tonumber(v134)
						if v135 then
							if v_u_1.calibrate then
								v_u_1.calibrate(v135)
							end
							local v136 = v135 - v_u_1.now()
							if math.abs(v136) < 3600 then
								v_u_15.offset = v136
							end
						end
						v_u_15.mailSig = v_u_4.mailSig(v133.entries)
						v_u_4._absorb(v133)
					end
				elseif v_u_15.stub[p_u_122] == nil then
					v_u_15.failed[p_u_122] = true
				end
				local v137 = p_u_122
				for _, v138 in table.clone(v_u_15.listeners) do
					pcall(v138, v137)
				end
				local v139 = v_u_15.waiters[p_u_122]
				v_u_15.waiters[p_u_122] = {}
				for _, v140 in v139 do
					pcall(v140)
				end
				if v_u_15.again[p_u_122] then
					v_u_15.again[p_u_122] = false
					v_u_4.fetch(p_u_121, p_u_122, {
						["force"] = true
					})
				end
			end)
		end
	end
end
function v_u_4.mailLive() -- name: mailLive
	-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_8
	local v141 = v_u_15.mail
	if v141 then
		local v142 = v141.data
		if type(v142) == "table" then
			local v143 = v_u_4.mailRows(v141.data.entries, v_u_4.serverNow())
			local v144, v145, v146 = v_u_4.mailStats(v143)
			local v147 = 0
			local v148 = 0
			local v149 = 0
			local v150
			if v_u_8 then
				local v151 = v_u_8.rowsOf
				local v152 = v141.data
				local v153 = os.clock()
				local v154 = v141.clock
				local v155
				if type(v154) == "number" then
					v155 = v141.clock
				else
					v155 = os.clock()
				end
				v150 = v151(v152, v153 - v155, v_u_4.serverNow())
				for _, v156 in v150 do
					if v156.expired then
						continue
					end
					if v156.src == "bm" then
						v147 = v147 + 1
					elseif v156.src == "lift" then
						v149 = v149 + 1
					else
						v148 = v148 + 1
					end
				end
			else
				v150 = {}
			end
			local v157 = v141.data.deliveries
			local v158 = type(v157) ~= "table" and {} or v141.data.deliveries
			local v159 = v141.data.switch
			local v160 = type(v159) ~= "table" and {} or v141.data.switch
			local v161 = {
				["rows"] = v143,
				["ready"] = v144,
				["pending"] = v145,
				["nextLeft"] = v146,
				["count"] = #v143
			}
			local v162 = v141.data.capacity
			local v163 = tonumber(v162)
			v161.capacity = (v163 == nil or v163 ~= v163) and 20 or v163
			v161.stub = v141.stub == true
			v161.deliveries = v150
			v161.waiting = v147 + v148 + v149
			v161.bm = v147
			v161.store = v148
			local v164
			if v150[1] and v150[1].cargo == true then
				v164 = v150[1]
			else
				v164 = nil
			end
			v161.cargo = v164
			v161.cargoGone = v_u_15.cargoGone
			local v165 = 1
			local v166 = v158.bmMax
			local v167 = not v_u_8 and 10 or v_u_8.TUNE.bmMax
			local v168 = tonumber(v166)
			if v168 == nil or v168 ~= v168 then
				v168 = v167
			end
			local v169 = math.floor(v168)
			v161.bmMax = math.max(v165, v169)
			local v170 = 1
			local v171 = v158.bmDays
			local v172 = not v_u_8 and 14 or v_u_8.TUNE.bmDays
			local v173 = tonumber(v171)
			if v173 == nil or v173 ~= v173 then
				v173 = v172
			end
			local v174 = math.floor(v173)
			v161.bmDays = math.max(v170, v174)
			v161.expired = v_u_15.expired
			v161.showDeliveries = #v150 > 0 and true or v160.on == true
			local v175
			if v_u_8 then
				local v176 = v_u_8.logRows
				v175 = type(v176) ~= "function" and {} or v_u_8.logRows(v141.data.insLog)
			else
				v175 = {}
			end
			v161.insLog = v175
			return v161
		end
	end
	return nil
end
function v_u_4._absorb(p_u_177) -- name: _absorb
	-- upvalues: (copy) v_u_15, (copy) v_u_8
	if type(p_u_177) == "table" and v_u_15.lastData ~= p_u_177 then
		v_u_15.lastData = p_u_177
		if v_u_8 then
			local v178 = v_u_15
			local v179 = v_u_15
			local v180, v181 = v_u_8.noteStep(v_u_15.noteRun, v_u_15.expired, p_u_177.expiredNote)
			v178.noteRun = v180
			v179.expired = v181
		else
			local v182 = p_u_177.expiredNote
			local v183 = tonumber(v182)
			local v184 = (v183 == nil or v183 ~= v183) and 0 or v183
			local v185 = math.floor(v184)
			if v185 > 0 then
				local v186 = v_u_15
				v186.expired = v186.expired + v185
			end
		end
		p_u_177.expiredNote = nil
		if p_u_177.cargoExpired == true then
			local v187 = v_u_15
			v187.expired = v187.expired + 1
			v_u_15.cargoGone = v_u_15.expired == 1
			p_u_177.cargoExpired = nil
		end
		local v188 = {}
		local v189 = p_u_177.tips
		if type(v189) == "table" then
			for _, v190 in {
				"mailStore",
				"mailBm",
				"mailLift",
				"mailPopOff"
			} do
				if p_u_177.tips[v190] ~= true then
					continue
				end
				v188[v190] = true
			end
		end
		v_u_15.tips = v188
		local v191 = v_u_15
		local v192 = p_u_177.switch
		local v193
		if type(v192) == "table" then
			v193 = p_u_177.switch.on == true
		else
			v193 = false
		end
		v191.switchOn = v193
		local v194 = p_u_177.cargo
		if type(v194) == "table" and (p_u_177.stubDeliveries ~= true and v_u_15.mc) then
			local function v197()
				-- upvalues: (ref) v_u_15, (copy) p_u_177
				local v195 = v_u_15.mc.cctx.lib.MailGuide
				if type(v195) == "table" then
					local v196 = v195.onMailData
					if type(v196) == "function" then
						v195.onMailData(v_u_15.mc, p_u_177)
					end
				end
			end
			pcall(v197)
		end
	end
end
function v_u_4.menuCtx() -- name: menuCtx
	-- upvalues: (copy) v_u_15
	return v_u_15.mc
end
function v_u_4.tips() -- name: tips
	-- upvalues: (copy) v_u_15
	return v_u_15.tips
end
function v_u_4.bmDays() -- name: bmDays
	-- upvalues: (copy) v_u_15, (copy) v_u_8
	local v198 = v_u_15.mail
	local v199
	if v198 then
		local v200 = v198.data
		if type(v200) == "table" then
			local v201 = v198.data.deliveries
			v199 = type(v201) ~= "table" and {} or v198.data.deliveries
		else
			v199 = {}
		end
	else
		v199 = {}
	end
	local v202 = 1
	local v203 = v199.bmDays
	local v204 = not v_u_8 and 14 or v_u_8.TUNE.bmDays
	local v205 = tonumber(v203)
	if v205 == nil or v205 ~= v205 then
		v205 = v204
	end
	local v206 = math.floor(v205)
	return math.max(v202, v206)
end
function v_u_4.expiredPending() -- name: expiredPending
	-- upvalues: (copy) v_u_15
	return v_u_15.expired
end
function v_u_4.clearExpired() -- name: clearExpired
	-- upvalues: (copy) v_u_15
	v_u_15.expired = 0
	v_u_15.cargoGone = false
end
function v_u_4.markSeen() -- name: markSeen
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_4
	local v207 = v_u_15.mail
	local v208 = false
	if v_u_8 and v207 then
		local v209 = v207.data
		if type(v209) == "table" then
			for _, v210 in v_u_8.rowsOf(v207.data, 0, v_u_4.serverNow()) do
				if v_u_15.seen[v210.id] then
					continue
				end
				v_u_15.seen[v210.id] = true
				v208 = true
			end
		end
	end
	if v_u_15.flagged then
		v_u_15.flagged = false
		v208 = true
	end
	local v211 = v208 and v_u_15.rail
	if v211 then
		local v212 = v211.paint
		if type(v212) == "function" then
			local v213 = v211.paint
			pcall(v213)
		end
	end
end
function v_u_4.flagDelivery(p214) -- name: flagDelivery
	-- upvalues: (copy) v_u_15, (copy) v_u_4
	v_u_15.flagged = true
	local v215 = v_u_15.rail
	if v215 then
		local v216 = v215.paint
		if type(v216) == "function" then
			local v217 = v215.paint
			pcall(v217)
		end
	end
	if p214 and not v_u_4.stubActive("mail") then
		v_u_4.fetch(p214, "mail", {
			["force"] = true
		})
	end
end
function v_u_4.pulseOn() -- name: pulseOn
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_4
	if v_u_15.flagged then
		return true
	end
	local v218 = v_u_15.mail
	if v_u_8 and v218 then
		local v219 = v218.data
		if type(v219) == "table" then
			local v220 = {}
			local v221 = os.clock()
			local v222 = v218.clock
			local v223
			if type(v222) == "number" then
				v223 = v218.clock
			else
				v223 = os.clock()
			end
			local v224 = v221 - v223
			for _, v225 in v_u_8.rowsOf(v218.data, v224, v_u_4.serverNow()) do
				if v225.expired then
					continue
				end
				local v226 = v225.id
				table.insert(v220, v226)
			end
			return v_u_8.pulseOn(v220, v_u_15.seen)
		end
	end
	return false
end
local v_u_227 = nil
local function v_u_232() -- name: cctxWhy
	-- upvalues: (ref) v_u_227
	if v_u_227 == nil then
		local v228, v229 = pcall(function()
			return require(script.Parent.MenuWhy)
		end)
		if not v228 or type(v229) ~= "table" then
			v229 = {
				["mailBoth"] = nil,
				["OFFLINE_SUB"] = "Offline, tap to retry",
				["VOTES_OFFLINE_TIP"] = "Votes are offline. Tap the card to try again.",
				["mailBoth"] = function(p230, p231) -- name: mailBoth
					return ("%d %s, %d %s"):format(p230, p230 == 1 and "letter" or "letters", p231, p231 == 1 and "delivery" or "deliveries")
				end
			}
		end
		v_u_227 = v229
	end
	return v_u_227
end
function v_u_4.mailSub(p233, p234) -- name: mailSub
	-- upvalues: (copy) v_u_232, (copy) v_u_4
	local v235
	if p233 then
		local v236 = p233.waiting
		v235 = type(v236) ~= "number" and 0 or p233.waiting
	else
		v235 = 0
	end
	if p234 > 0 and v235 > 0 then
		return v_u_232().mailBoth(p234, v235), "accent"
	elseif p234 > 0 then
		return p234 == 1 and "1 new letter" or ("%d new letters"):format(p234), "accent"
	elseif v235 > 0 then
		return v235 == 1 and "1 delivery waiting" or ("%d deliveries waiting"):format(v235), "text2"
	elseif p233.nextLeft then
		return "Next: " .. v_u_4.waitText(p233.nextLeft), "text2"
	elseif p233.ready > 0 then
		return p233.ready == 1 and "1 item to claim" or ("%d items to claim"):format(p233.ready), "text2"
	else
		return "No mail", "muted"
	end
end
function v_u_4.votesLive() -- name: votesLive
	-- upvalues: (copy) v_u_15, (copy) v_u_4
	local v237 = v_u_15.votes
	if v237 then
		local v238 = v237.data
		if type(v238) == "table" then
			local v239 = v_u_4.serverNow()
			local v240 = v_u_4.pollRows(v237.data.polls, v239)
			local v241 = 0
			local v242 = 0
			for _, v243 in v240 do
				if v243.group == 1 then
					v241 = v241 + 1
					v242 = v242 + 1
				else
					if v243.group ~= 2 then
						continue
					end
					v241 = v241 + 1
				end
			end
			return {
				["rows"] = v240,
				["open"] = v241,
				["openUnvoted"] = v242,
				["stub"] = v237.stub == true
			}
		end
	end
	return nil
end
function v_u_4.failed(p244) -- name: failed
	-- upvalues: (copy) v_u_15
	local v245
	if v_u_15.failed[p244] == true then
		v245 = v_u_15[p244] == nil
	else
		v245 = false
	end
	return v245
end
function v_u_4.stamp(p246) -- name: stamp
	-- upvalues: (copy) v_u_15
	local v247 = v_u_15[p246]
	if v247 then
		local v248 = v247.clock
		if type(v248) == "number" then
			return v247.clock
		end
	end
	return -1000000000
end
function v_u_4.stubActive(p249) -- name: stubActive
	-- upvalues: (copy) v_u_15
	return v_u_15.stub[p249] ~= nil
end
local v_u_250 = {
	"rifle_akm",
	"vest_platecarrier",
	"helmet_military",
	"bag_tactical",
	"rifle_ar15",
	"vest_military",
	"ears_muffs",
	"smg_mp5",
	"shotgun_870",
	"bag_military"
}
local v_u_251 = { "Stillwater", "The Hollow", "Kestrel Field" }
local v_u_252 = {
	-45,
	38,
	-5,
	72,
	160,
	12,
	-120,
	95,
	5,
	240
}
local function v_u_265(p253) -- name: stubMail
	-- upvalues: (copy) v_u_4, (copy) v_u_250, (copy) v_u_252, (copy) v_u_251
	local v254 = v_u_4.serverNow()
	local v255 = math.floor(v254)
	local v256, v257 = pcall(function()
		return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items"))
	end)
	local v258 = {}
	for v259 = 1, p253 do
		local v260 = v_u_250[(v259 - 1) % #v_u_250 + 1]
		local v261
		if v256 then
			v261 = v257.get(v260)
		else
			v261 = nil
		end
		local v262 = v255 + v_u_252[(v259 - 1) % #v_u_252 + 1] * 60
		local v263 = v_u_251[(v259 - 1) % 3 + 1]
		local v264 = {
			["id"] = nil,
			["kind"] = "insurance",
			["policyId"] = nil,
			["item"] = nil,
			["itemId"] = nil,
			["name"] = nil,
			["mapId"] = nil,
			["mapName"] = nil,
			["premium"] = nil,
			["raidEndAt"] = nil,
			["readyAt"] = nil,
			["note"] = "Insurance return",
			["id"] = "stub" .. v259,
			["policyId"] = "pol" .. v259,
			["item"] = {
				["uid"] = "stubuid" .. v259,
				["id"] = v260
			},
			["itemId"] = v260
		}
		if v261 then
			v260 = v261.name
		end
		v264.name = v260
		v264.mapId = string.lower((string.gsub(v263, " ", "")))
		v264.mapName = v263
		v264.premium = v259 * 1000
		v264.raidEndAt = v262 - 6000
		v264.readyAt = v262
		table.insert(v258, v264)
	end
	return {
		["entries"] = nil,
		["count"] = nil,
		["capacity"] = 20,
		["serverTime"] = nil,
		["rule"] = "An insured item comes back if you died and nobody carried it out.",
		["entries"] = v258,
		["count"] = p253,
		["serverTime"] = v255
	}
end
local v_u_266 = {
	{
		["title"] = "Which feature should we build next?",
		["desc"] = "Pick the one you would play first. We read every result before we plan the next update.",
		["options"] = nil,
		["counts"] = nil,
		["closesIn"] = 187200,
		["options"] = {
			"Squad voice chat",
			"A fourth map",
			"PvPvE mode",
			"Base building in the hideout"
		},
		["counts"] = {
			41,
			77,
			128,
			52
		}
	},
	{
		["title"] = "Should insured gear come back faster?",
		["desc"] = "Right now an insured item needs four raid lengths to arrive.",
		["options"] = nil,
		["counts"] = nil,
		["closesIn"] = 18600,
		["mine"] = 3,
		["options"] = { "Yes, twice as fast", "No, keep it as it is", "Only with INSURANCE PLUS" },
		["counts"] = { 63, 19, 35 }
	},
	{
		["title"] = "Night raids on Normal difficulty?",
		["desc"] = "",
		["options"] = nil,
		["counts"] = nil,
		["closed"] = true,
		["options"] = { "Add them", "Leave Normal at day and dusk" },
		["counts"] = { 88, 143 }
	},
	{
		["title"] = "Which of these long named upcoming features should we bring to the game first this season?",
		["desc"] = "A long description to see how the card wraps: every survivor gets one vote on every poll, the result is final, and the totals only show after you voted. Tell us what you want to see.",
		["options"] = nil,
		["counts"] = nil,
		["options"] = { "A very long option text that has to wrap or truncate: reworked weapon handling with proper recoil", "Short one", "Another fairly long option: night time storms with lightning and thunder over the whole town" },
		["counts"] = { 12, 4, 20 }
	},
	{
		["title"] = "Squad size",
		["desc"] = "Four is the cap today.",
		["options"] = nil,
		["counts"] = nil,
		["mine"] = 1,
		["options"] = { "Keep four", "Allow five" },
		["counts"] = { 5, 9 }
	},
	{
		["title"] = "Radio chatter in the menu",
		["desc"] = "",
		["options"] = nil,
		["counts"] = nil,
		["options"] = { "Keep it", "Turn it down", "Remove it" },
		["counts"] = { 1, 0, 0 }
	}
}
local v_u_267 = {}
local function v_u_288(p268) -- name: stubVotes
	-- upvalues: (copy) v_u_4, (copy) v_u_266, (ref) v_u_267
	local v269 = v_u_4.serverNow()
	local v270 = math.floor(v269)
	local v271 = #v_u_266
	local v272 = {}
	for v273 = 1, math.min(p268, v271) do
		local v274 = v_u_266[v273]
		local v275 = v274.mine
		if v_u_267[tostring(v273)] then
			v275 = v_u_267[tostring(v273)]
		end
		local v276 = 0
		local v277 = {}
		for v278, v279 in v274.options do
			local v280 = v274.counts[v278] or 0
			if v_u_267[tostring(v273)] and (not v274.mine and v_u_267[tostring(v273)] == v278) then
				v280 = v280 + 1
			end
			v276 = v276 + v280
			table.insert(v277, {
				["id"] = v278,
				["text"] = v279,
				["n"] = v280
			})
		end
		local v281 = v274.closed == true
		local v282 = v281 or v275 ~= nil
		if not v282 then
			for _, v283 in v277 do
				v283.n = nil
			end
		end
		local v284 = {
			["id"] = "poll" .. v273,
			["title"] = v274.title,
			["desc"] = v274.desc,
			["options"] = v277
		}
		if not v282 then
			v276 = nil
		end
		v284.total = v276
		local v285
		if v274.closesIn then
			v285 = v270 + v274.closesIn
		else
			v285 = nil
		end
		v284.closesAt = v285
		v284.closed = v281
		v284.mine = v275
		table.insert(v272, v284)
	end
	local v286 = 0
	for _, v287 in v272 do
		if v287.closed or v287.mine ~= nil then
			continue
		end
		v286 = v286 + 1
	end
	return {
		["ok"] = true,
		["polls"] = nil,
		["openUnvoted"] = nil,
		["polls"] = v272,
		["openUnvoted"] = v286
	}
end
function v_u_4._stubData(p289) -- name: _stubData
	-- upvalues: (copy) v_u_15, (ref) v_u_11, (copy) v_u_4, (copy) v_u_288
	local v290 = v_u_15.stub[p289]
	if p289 ~= "mail" then
		return v_u_288(not v290 and 0 or v290.n)
	end
	if not (v290 and v290.data) then
		local v291 = v_u_4.serverNow()
		local v292 = math.floor(v291)
		local _, _ = pcall(function()
			return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items"))
		end)
		return {
			["entries"] = nil,
			["count"] = 0,
			["capacity"] = 20,
			["serverTime"] = nil,
			["rule"] = "An insured item comes back if you died and nobody carried it out.",
			["entries"] = {},
			["serverTime"] = v292
		}
	end
	if v290.data.stubDeliveries ~= true or not v_u_11 then
		return v290.data
	end
	v_u_11.fresh(v290.data, v_u_4.serverNow())
	local v293 = table.clone(v290.data)
	v290.data.expiredNote = nil
	v290.data.cargoExpired = nil
	return v293
end
function v_u_4.setStub(p294, p295, p296) -- name: setStub
	-- upvalues: (ref) v_u_11, (copy) v_u_6, (copy) v_u_265, (copy) v_u_15, (copy) v_u_4, (ref) v_u_267
	if p295 == "mail" and type(p296) == "string" then
		local v297 = v_u_11
		if not v297 then
			local v298
			if v_u_6 then
				v298 = v_u_6:FindFirstChild("MailStub")
			else
				v298 = nil
			end
			if v298 and v298:IsA("ModuleScript") then
				local v299 = require
				local v300
				v300, v297 = pcall(v299, v298)
				if not v300 or type(v297) ~= "table" then
					v297 = nil
				end
			else
				v297 = nil
			end
		end
		v_u_11 = v297
		if v_u_11 then
			local v301
			if p296 == "mixed" then
				v301 = v_u_265(3).entries
			else
				v301 = nil
			end
			v_u_15.stub.mail = {
				["n"] = 0,
				["data"] = nil,
				["preset"] = nil,
				["data"] = v_u_11.build(p296, v_u_4.serverNow(), v301),
				["preset"] = p296
			}
			v_u_15.lastData = nil
			v_u_15.noteRun = 0
			v_u_4.fetch(p294, p295, {
				["force"] = true
			})
		end
	elseif p296 == nil or p296 < 0 then
		v_u_15.stub[p295] = nil
		v_u_15[p295] = nil
		v_u_4.fetch(p294, p295, {
			["force"] = true
		})
	else
		if p295 == "mail" then
			v_u_15.stub.mail = {
				["n"] = p296,
				["data"] = v_u_265(p296)
			}
		else
			v_u_267 = {}
			v_u_15.stub.votes = {
				["n"] = p296
			}
		end
		v_u_4.fetch(p294, p295, {
			["force"] = true
		})
	end
end
function v_u_4.stubClaim(p_u_302, p303) -- name: stubClaim
	-- upvalues: (copy) v_u_15, (ref) v_u_11, (copy) v_u_4, (ref) v_u_12
	local v304 = v_u_15.stub.mail
	local v305 = {
		["op"] = "mailClaim",
		["ok"] = false,
		["msg"] = "That delivery is no longer in your mailbox"
	}
	local v306 = false
	local v_u_307
	if v304 and (v304.data and (v304.data.stubDeliveries == true and v_u_11)) then
		v_u_307 = v_u_11.claim(v304.data, p303, v_u_4.serverNow())
		if v_u_307 then
			v306 = true
		else
			v_u_307 = v305
		end
	else
		v_u_307 = v305
	end
	if not v306 and (v304 and v304.data) then
		local v308 = v_u_4.serverNow()
		local v309 = v304.data.entries
		for v310, v311 in v309 do
			if v311.id ~= p303 and p303 ~= "all" then
				continue
			end
			if p303 == "all" then
				local v312 = 0
				for v313 = #v309, 1, -1 do
					local v314 = v309[v313].readyAt
					local v315 = tonumber(v314)
					if ((v315 == nil or v315 ~= v315) and 0 or v315) > v308 or v309[v313].id == "stub3" then
						continue
					end
					table.remove(v309, v313)
					v312 = v312 + 1
				end
				v_u_307 = {
					["op"] = "mailClaim",
					["ok"] = nil,
					["msg"] = nil,
					["data"] = nil,
					["ok"] = v312 > 0,
					["msg"] = v312 <= 0 and "Stash is full. Make room and claim again." or (v312 == 1 and "1 item is back in your stash" or ("%d items are back in your stash"):format(v312)) .. ". Stash is full, the rest stays in the mailbox.",
					["data"] = v312 > 0 and {
						["claimed"] = v312
					} or {
						["full"] = true
					}
				}
			else
				local v316 = v311.readyAt
				local v317 = tonumber(v316)
				if v308 < ((v317 == nil or v317 ~= v317) and 0 or v317) then
					v_u_307 = {
						["op"] = "mailClaim",
						["ok"] = false,
						["msg"] = nil,
						["data"] = nil
					}
					local v318 = v_u_4.waitText
					local v319 = v311.readyAt
					local v320 = tonumber(v319)
					v_u_307.msg = "Not there yet. Arrives in " .. v318(((v320 == nil or v320 ~= v320) and 0 or v320) - v308)
					local v321 = {}
					local v322 = v311.readyAt
					local v323 = tonumber(v322)
					v321.left = ((v323 == nil or v323 ~= v323) and 0 or v323) - v308
					v_u_307.data = v321
				elseif v311.id == "stub3" then
					v_u_307 = {
						["op"] = "mailClaim",
						["ok"] = false,
						["msg"] = "Stash is full. Make room and claim again.",
						["data"] = nil,
						["data"] = {
							["full"] = true
						}
					}
				else
					table.remove(v309, v310)
					v_u_307 = {
						["op"] = "mailClaim",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil
					}
					local v324 = v311.name
					v_u_307.msg = ("%s is back in your stash"):format((tostring(v324)))
					v_u_307.data = {
						["uid"] = v311.item.uid,
						["id"] = v311.itemId
					}
				end
			end
		end
	end
	if v_u_307.ok then
		local v325 = v_u_12.toast
		local v326 = v_u_307.msg
		pcall(v325, v326, "success")
	else
		local v327 = v_u_12.toast
		local v328 = v_u_307.msg
		pcall(v327, v328, "danger")
	end
	task.defer(function()
		-- upvalues: (copy) p_u_302, (ref) v_u_307
		p_u_302.changed:Fire("result", v_u_307)
	end)
end
function v_u_4.stubVote(p_u_329, p330, p331) -- name: stubVote
	-- upvalues: (copy) v_u_266, (ref) v_u_267, (ref) v_u_12
	local v332 = string.match
	local v333 = tostring(p330)
	local v334 = tonumber(v332(v333, "%d+"))
	local v_u_335
	if v334 and v_u_266[v334] then
		local v336 = v_u_266[v334]
		if v336.closed then
			v_u_335 = {
				["op"] = "voteCast",
				["ok"] = false,
				["msg"] = "This vote is closed."
			}
		elseif v336.mine or v_u_267[tostring(v334)] then
			v_u_335 = {
				["op"] = "voteCast",
				["ok"] = false,
				["msg"] = "You already voted."
			}
		elseif v336.options[tonumber(p331) or 0] then
			v_u_267[tostring(v334)] = tonumber(p331)
			v_u_335 = {
				["op"] = "voteCast",
				["ok"] = true,
				["msg"] = nil
			}
		else
			v_u_335 = {
				["op"] = "voteCast",
				["ok"] = false,
				["msg"] = "Unknown option."
			}
		end
	else
		v_u_335 = {
			["op"] = "voteCast",
			["ok"] = false,
			["msg"] = "Unknown vote"
		}
	end
	if not v_u_335.ok and v_u_335.msg then
		local v337 = v_u_12.toast
		local v338 = v_u_335.msg
		pcall(v337, v338, "danger")
	end
	task.defer(function()
		-- upvalues: (copy) p_u_329, (ref) v_u_335
		p_u_329.changed:Fire("result", v_u_335)
	end)
end
function v_u_4.glyph(p339, p340, p341, p_u_342) -- name: glyph
	-- upvalues: (ref) v_u_12
	local v_u_343 = v_u_12.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Name"] = "Glyph_" .. p339,
		["Size"] = UDim2.fromOffset(p341, p341)
	})
	v_u_12.new("UIAspectRatioConstraint", {
		["AspectRatio"] = 1
	}, v_u_343)
	local v344 = p341 / 12 + 0.5
	local v345 = math.floor(v344)
	local v_u_346 = math.max(1, v345)
	local function v358(p347, p348, p349, p350) -- name: line
		-- upvalues: (ref) v_u_12, (copy) v_u_346, (copy) p_u_342, (copy) v_u_343
		local v351 = p349 - p347
		local v352 = p350 - p348
		local v353 = v351 * v351 + v352 * v352
		local v354 = math.sqrt(v353)
		local v355 = v_u_12.new
		local v356 = {
			["Name"] = "g",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale((p347 + p349) / 2, (p348 + p350) / 2),
			["Size"] = UDim2.new(v354, v_u_346, 0, v_u_346)
		}
		local v357 = math.atan2(v352, v351)
		v356.Rotation = math.deg(v357)
		v356.BackgroundColor3 = p_u_342
		v355("Frame", v356, v_u_343)
	end
	local function v365(p359, p360, p361, p362, p363) -- name: rect
		-- upvalues: (ref) v_u_12, (copy) p_u_342, (copy) v_u_343, (copy) v_u_346
		local v364 = v_u_12.new("Frame", {
			["Name"] = "g",
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = UDim2.fromScale(p359, p360),
			["Size"] = UDim2.fromScale(p361, p362),
			["BackgroundColor3"] = p_u_342,
			["BackgroundTransparency"] = p363 and 0 or 1
		}, v_u_343)
		if not p363 then
			v_u_12.stroke(v364, p_u_342, v_u_346)
		end
	end
	if p339 == "mail" then
		v365(0.06, 0.2, 0.88, 0.6, false)
		v358(0.1, 0.26, 0.5, 0.58)
		v358(0.9, 0.26, 0.5, 0.58)
	else
		v365(0.08, 0.14, 0.2, 0.2, true)
		v358(0.4, 0.24, 0.92, 0.24)
		v365(0.08, 0.4, 0.2, 0.2, false)
		v358(0.4, 0.5, 0.82, 0.5)
		v365(0.08, 0.66, 0.2, 0.2, false)
		v358(0.4, 0.76, 0.66, 0.76)
	end
	if p340 then
		v_u_343.Parent = p340
	end
	return v_u_343
end
function v_u_4.bind(p366) -- name: bind
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_15
	v_u_12 = p366.ui
	v_u_13 = p366.theme
	v_u_14 = v_u_13.color
	v_u_15.mc = p366
end
local function v_u_372() -- name: insureMod
	-- upvalues: (copy) v_u_6
	local v367
	if v_u_6 then
		v367 = v_u_6:FindFirstChild("MenuInsure")
	else
		v367 = nil
	end
	if v367 and v367:IsA("ModuleScript") then
		local v368 = require
		local v369, v370 = pcall(v368, v367)
		if v369 and type(v370) == "table" then
			local v371 = v370.open
			if type(v371) == "function" then
				return v370
			end
		end
	end
	return nil
end
local function v_u_430(p373, p_u_374) -- name: makeCard
	-- upvalues: (ref) v_u_12, (ref) v_u_14, (ref) v_u_13, (copy) v_u_3
	local v375 = p_u_374.h
	local v376 = p_u_374.compact
	local v_u_377 = p_u_374.iconOnly == true
	local v_u_378 = v_u_12.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Selectable"] = true,
		["Name"] = p_u_374.name,
		["BackgroundColor3"] = v_u_14.raised,
		["Size"] = UDim2.new(1, 0, 0, v375),
		["LayoutOrder"] = p_u_374.order
	}, p373)
	v_u_378.SelectionImageObject = v_u_12.selectionImage()
	local v_u_379 = v_u_12.new("UIScale", {
		["Name"] = "Press"
	}, v_u_378)
	local v_u_380 = v_u_12.stroke(v_u_378, v_u_14.line)
	local v_u_381 = v_u_12.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_14.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v_u_378)
	local v_u_382 = v_u_12.new("Frame", {
		["Name"] = "Underline",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_14.accent,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(0, 0, 0, 2)
	}, v_u_378)
	local v383 = v376 and 20 or 24
	local v_u_384 = p_u_374.glyph(v_u_378, v383, v_u_14.text2)
	local v385
	if v_u_377 then
		local v386 = UDim2.fromOffset
		local v387 = p_u_374.w
		v385 = v386(((tonumber(v387) or v375) - v383) // 2, (v375 - v383) // 2)
	else
		v385 = UDim2.fromOffset(16, (v375 - v383) // 2)
	end
	v_u_384.Position = v385
	local v388 = v383 + 16 + 16
	local v389 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Label",
		["text"] = nil,
		["style"] = "h3",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_378,
		["text"] = p_u_374.label,
		["textSize"] = v376 and 16 or 18,
		["position"] = UDim2.fromOffset(v388, not v376 and 11 or (v375 - 22) // 2),
		["size"] = UDim2.new(1, -v388 - 44, 0, 22)
	})
	local v_u_390 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_378,
		["color"] = v_u_14.text2,
		["position"] = UDim2.fromOffset(v388, 35),
		["size"] = UDim2.new(1, -v388 - 44, 0, 18)
	})
	local v391 = not v376
	if v391 then
		v391 = not v_u_377
	end
	v_u_390.Visible = v391
	v389.Visible = not v_u_377
	local v_u_392 = v_u_12.label({
		["parent"] = nil,
		["name"] = "Chevron",
		["text"] = "\226\128\186",
		["style"] = "h2",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["anchor"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_378,
		["color"] = v_u_14.text2,
		["position"] = UDim2.new(1, -16, 0, 0),
		["anchor"] = Vector2.new(1, 0),
		["size"] = UDim2.new(0, 20, 1, 0)
	})
	v_u_392.Visible = not v_u_377
	local v393 = v_u_12.new
	local v394 = "Frame"
	local v395 = {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_14.accent
	}
	local v396
	if v_u_377 then
		v396 = Vector2.new(1, 0)
	else
		v396 = Vector2.new(1, 0.5)
	end
	v395.AnchorPoint = v396
	local v397
	if v_u_377 then
		v397 = UDim2.new(1, -3, 0, 3)
	else
		v397 = UDim2.new(1, -14, 0.5, 0)
	end
	v395.Position = v397
	v395.Size = UDim2.fromOffset(v_u_377 and 20 or 24, v_u_377 and 20 or 24)
	local v_u_398 = v393(v394, v395, v_u_378)
	local v_u_399 = v_u_12.label({
		["parent"] = nil,
		["name"] = "N",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = 13,
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["track"] = false,
		["zindex"] = 5,
		["parent"] = v_u_398,
		["color"] = v_u_14.bgDeep,
		["size"] = UDim2.fromScale(1, 1)
	})
	v_u_399.FontFace = v_u_13.font.monoBold
	local v_u_400 = false
	local v_u_401 = 0
	local function v_u_410() -- name: paint
		-- upvalues: (ref) v_u_400, (copy) v_u_380, (ref) v_u_14, (ref) v_u_401, (copy) v_u_378, (ref) v_u_12, (copy) v_u_382, (copy) v_u_384
		local v402 = v_u_400
		local v403 = v_u_380
		local v404
		if v402 then
			v404 = v_u_14.lineStrong
		elseif v_u_401 > 0 then
			v404 = v_u_14.accentDim
		else
			v404 = v_u_14.line
		end
		v403.Color = v404
		local v405 = v_u_378
		local v406
		if v402 then
			v406 = v_u_14.raised2
		else
			v406 = v_u_14.raised
		end
		v405.BackgroundColor3 = v406
		v_u_12.tween(v_u_382, {
			["Size"] = UDim2.new(v402 and 1 or 0, 0, 0, 2)
		}, v402 and "slow" or "fast")
		local v407 = v_u_12.setIconColor
		local v408 = v_u_384
		local v409
		if v_u_401 > 0 then
			v409 = v_u_14.accent
		elseif v402 then
			v409 = v_u_14.text
		else
			v409 = v_u_14.text2
		end
		v407(v408, v409)
	end
	v_u_378.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_400, (ref) v_u_12, (ref) v_u_13, (copy) v_u_410
		v_u_400 = true
		v_u_12.sound(v_u_13.sounds.hover)
		v_u_410()
	end)
	v_u_378.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_400, (ref) v_u_12, (copy) v_u_379, (copy) v_u_410
		v_u_400 = false
		v_u_12.tween(v_u_379, {
			["Scale"] = 1
		}, "fast")
		v_u_410()
	end)
	v_u_378.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_400, (ref) v_u_12, (ref) v_u_13, (copy) v_u_410
		v_u_400 = true
		v_u_12.sound(v_u_13.sounds.hover)
		v_u_410()
	end)
	v_u_378.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_400, (copy) v_u_410
		v_u_400 = false
		v_u_410()
	end)
	v_u_378.InputBegan:Connect(function(p411)
		-- upvalues: (ref) v_u_12, (copy) v_u_379, (ref) v_u_13
		if p411.UserInputType == Enum.UserInputType.MouseButton1 or p411.UserInputType == Enum.UserInputType.Touch then
			v_u_12.tween(v_u_379, {
				["Scale"] = v_u_13.motion.pressScale
			}, 0.06)
		end
	end)
	v_u_378.InputEnded:Connect(function(p412)
		-- upvalues: (ref) v_u_12, (copy) v_u_379, (ref) v_u_400, (copy) v_u_410
		if p412.UserInputType == Enum.UserInputType.MouseButton1 or p412.UserInputType == Enum.UserInputType.Touch then
			v_u_12.tween(v_u_379, {
				["Scale"] = 1
			}, "fast")
			if p412.UserInputType == Enum.UserInputType.Touch then
				v_u_400 = false
				v_u_410()
			end
		end
	end)
	v_u_378.Activated:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) p_u_374
		v_u_12.sound(v_u_13.sounds.click)
		if p_u_374.onClick then
			task.spawn(p_u_374.onClick)
		end
	end)
	if p_u_374.tip then
		v_u_12.tooltip(v_u_378, p_u_374.tip)
	end
	local v413 = {
		["btn"] = v_u_378,
		["label"] = v389,
		["sub"] = v_u_390,
		["badgeChip"] = v_u_398
	}
	local v_u_414 = -1
	function v413.setBadge(p415) -- name: setBadge
		-- upvalues: (ref) v_u_414, (ref) v_u_401, (copy) v_u_398, (copy) v_u_381, (copy) v_u_392, (copy) v_u_377, (copy) v_u_399, (copy) v_u_410
		local v416 = math.floor(p415)
		local v417 = math.max(0, v416)
		if v417 ~= v_u_414 then
			v_u_414 = v417
			v_u_401 = v417
			v_u_398.Visible = v417 > 0
			v_u_381.Visible = v417 > 0
			local v418 = v_u_392
			local v419
			if v417 <= 0 then
				v419 = not v_u_377
			else
				v419 = false
			end
			v418.Visible = v419
			local v420 = v417 > 9 and "9+" or tostring(v417)
			if v_u_399.Text ~= v420 then
				v_u_399.Text = v420
			end
			local v421 = v_u_398
			local v422
			if v_u_377 then
				v422 = UDim2.fromOffset(v417 > 9 and 28 or 20, 20)
			else
				v422 = UDim2.fromOffset(v417 > 9 and 32 or 24, 24)
			end
			v421.Size = v422
			v_u_410()
		end
	end
	function v413.setSub(p423, p424) -- name: setSub
		-- upvalues: (copy) v_u_390, (ref) v_u_14
		if v_u_390.Text ~= p423 then
			v_u_390.Text = p423
		end
		v_u_390.TextColor3 = p424 or v_u_14.text2
	end
	function v413.badge()
		-- upvalues: (ref) v_u_401
		return v_u_401
	end
	local v_u_425 = false
	local v_u_426 = nil
	function v413.setPulse(p427) -- name: setPulse
		-- upvalues: (ref) v_u_425, (ref) v_u_426, (ref) v_u_3, (ref) v_u_400, (copy) v_u_380, (ref) v_u_14, (copy) v_u_381, (ref) v_u_401, (copy) v_u_410
		if p427 == v_u_425 then
			return
		else
			v_u_425 = p427
			if p427 then
				v_u_426 = v_u_3.Heartbeat:Connect(function()
					-- upvalues: (ref) v_u_400, (ref) v_u_380, (ref) v_u_14, (ref) v_u_381
					if not v_u_400 then
						local v428 = os.clock() * 3.141592653589793 * 1.2
						local v429 = math.sin(v428) * 0.5 + 0.5
						v_u_380.Color = v_u_14.line:Lerp(v_u_14.accent, v429 * 0.75 + 0.25)
						v_u_381.Visible = true
						v_u_381.BackgroundTransparency = 0.7 - v429 * 0.7
					end
				end)
			else
				if v_u_426 then
					v_u_426:Disconnect()
					v_u_426 = nil
				end
				v_u_381.BackgroundTransparency = 0
				v_u_381.Visible = v_u_401 > 0
				v_u_410()
			end
		end
	end
	function v413.pulsing()
		-- upvalues: (ref) v_u_425
		return v_u_425
	end
	v_u_378.Destroying:Connect(function()
		-- upvalues: (ref) v_u_426
		if v_u_426 then
			v_u_426:Disconnect()
			v_u_426 = nil
		end
	end)
	v_u_410()
	return v413
end
local function v_u_444(p431, p432, p433, p434) -- name: makeSign
	-- upvalues: (ref) v_u_12, (ref) v_u_14
	local v435 = v_u_12.new("Frame", {
		["Name"] = "Sign",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Active"] = false,
		["Selectable"] = false,
		["BackgroundColor3"] = v_u_14.bg,
		["Size"] = UDim2.new(1, 0, 0, p433),
		["LayoutOrder"] = p432
	}, p431)
	v_u_12.stroke(v435, v_u_14.lineStrong)
	local v436 = v_u_12.new("Frame", {
		["Name"] = "Hazard",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_14.bgDeep,
		["Position"] = UDim2.fromOffset(1, 1),
		["Size"] = UDim2.new(1, -2, 0, 8)
	}, v435)
	for v437 = -1, 24 do
		v_u_12.new("Frame", {
			["Name"] = "Stripe",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = v_u_14.accentDim,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v437 * 12, 4),
			["Size"] = UDim2.fromOffset(5, 18)
		}, v436)
	end
	local v438 = p434 and 16 or 20
	v_u_12.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "PVPVE MODE",
		["style"] = "h3",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v435,
		["textSize"] = p434 and 17 or 18,
		["position"] = UDim2.fromOffset(16, v438),
		["size"] = UDim2.new(1, -32, 0, 22)
	})
	v_u_12.label({
		["parent"] = nil,
		["name"] = "Soon",
		["text"] = "COMING SOON",
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v435,
		["color"] = v_u_14.accent,
		["position"] = UDim2.fromOffset(16, v438 + 22),
		["size"] = UDim2.new(1, -32, 0, 16)
	})
	v_u_12.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = "HUSH is PvE for now. A PvPvE mode is planned.",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["wrap"] = true,
		["valign"] = "top",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v435,
		["color"] = v_u_14.text2,
		["position"] = UDim2.fromOffset(16, v438 + 44),
		["size"] = UDim2.new(1, -32, 0, p433 - (v438 + 44) - 10)
	}).Selectable = false
	for _, v439 in { 6, -9 } do
		local v440 = v_u_12.new
		local v441 = "Frame"
		local v442 = {
			["Name"] = "Rivet",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_14.lineStrong,
			["AnchorPoint"] = Vector2.new(0, 1)
		}
		local v443
		if v439 > 0 then
			v443 = UDim2.new(0, v439, 1, -6)
		else
			v443 = UDim2.new(1, v439, 1, -6)
		end
		v442.Position = v443
		v442.Size = UDim2.fromOffset(3, 3)
		v440(v441, v442, v435)
	end
	return v435
end
function v_u_4.signFits(p445, p446, p447) -- name: signFits
	return p446 * 3 + p447 + 24 <= p445
end
function v_u_4.plateHeight(p448, p449, p450) -- name: plateHeight
	local v451 = p448 and 92 or 120
	if not p449 then
		return v451
	end
	local v452 = 11 / math.max(p450, 0.1)
	local v453 = math.ceil(v452)
	local v454 = math.max(12, v453) * 1.25
	return v451 + math.ceil(v454) * 2 - 22
end
function v_u_4.rowWidth(p455, p456) -- name: rowWidth
	return math.max(1, p455) * p456 + (math.max(1, p455) - 1) * 8
end
function v_u_4.roomLimit(p457, p458, p459) -- name: roomLimit
	if p457 > 0 then
		p458 = math.min(p457, p458)
	end
	return p458 - p459 - 6 - 8
end
function v_u_4.phoneFit(p460, p461, p462, p463, p464) -- name: phoneFit
	local v465 = p460 + p461
	local v466 = 0
	for _ = 1, p464 do
		if p462 < v465 + p463 then
			break
		end
		v466 = v466 + 1
		v465 = v465 + (p463 + 8)
	end
	return v466
end
function v_u_4.pickTile(p467, p468, p469, p470, p471, p472, p473) -- name: pickTile
	-- upvalues: (copy) v_u_4
	local v474 = p467[1]
	local v475 = p472
	for _, v476 in p467 do
		v475 = v_u_4.phoneFit(p469, p468(v476) + 8, p470, p471, p472)
		if p473 <= v475 then
			v474 = v476
			break
		end
		v474 = v476
	end
	return v474, v475
end
function v_u_4.huntKinds(p477, p478) -- name: huntKinds
	local v479 = p477 == "mini" and { "mini", "phone", "slim" } or { "phone", "slim" }
	if p478 then
		table.remove(v479, #v479)
	end
	return v479
end
function v_u_4.rowSize(p480, p481) -- name: rowSize
	local v482 = 0
	local v483 = 0
	local v484 = 0
	for _, v485 in p480 do
		if not v485.visible then
			continue
		end
		v483 = v483 + (v485.w + (v482 <= 0 and 0 or p481))
		local v486 = v485.h
		v484 = math.max(v484, v486)
		v482 = v482 + 1
	end
	return v483, v484
end
function v_u_4.pickTiles(p487, p488, p489, p490, p491, p492, p493, p494) -- name: pickTiles
	-- upvalues: (copy) v_u_4
	local v495 = #p487
	local v496 = #p488
	local v497 = math.max(v495, v496, 1)
	local v498 = p487[1] or "full"
	local v499 = p488[1] or "full"
	local v500 = p493
	for v501 = 1, v497 do
		local v502 = #p487
		v498 = p487[math.min(v501, v502)] or v498
		local v503 = #p488
		v499 = p488[math.min(v501, v503)] or v499
		local v504 = p489("hunt", v498)
		local v505 = p489("door", v499)
		local v506 = 0
		if v504 > 0 then
			v506 = v506 + (v504 + 8)
		end
		if v505 > 0 then
			v506 = v506 + (v505 + 8)
		end
		v500 = v_u_4.phoneFit(p490, v506, p491, p492, p493)
		if p494 > v500 then
			continue
		end
	end
	return v498, v499, v500
end
function v_u_4.new(p_u_507, p_u_508) -- name: new
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_15, (copy) v_u_4, (copy) v_u_430, (copy) v_u_8, (copy) v_u_5, (copy) v_u_372, (copy) v_u_444, (copy) v_u_232
	v_u_12 = p_u_507.ui
	v_u_13 = p_u_507.theme
	v_u_14 = v_u_13.color
	v_u_15.mc = p_u_507
	local v509 = v_u_4.installHooks
	pcall(v509, p_u_507)
	pcall(function()
		-- upvalues: (copy) p_u_507
		local v_u_510 = p_u_507
		local v_u_511 = "MailGuide"
		local v512, v513 = pcall(function()
			-- upvalues: (copy) v_u_510, (copy) v_u_511
			return v_u_510.cctx.lib[v_u_511]
		end)
		if not v512 or type(v513) ~= "table" then
			v513 = nil
		end
		if v513 then
			local v514 = v513.attach
			if type(v514) == "function" then
				v513.attach(p_u_507)
			end
		end
	end)
	local v_u_515 = {}
	local v_u_516 = {}
	local v_u_517 = true
	local v_u_518 = false
	local v_u_519 = 0
	local v_u_520 = -1
	local v_u_521 = p_u_507.compact()
	local v522 = v_u_13.safeRefSize()
	local v_u_523
	if v_u_521 then
		local v524 = v_u_13.isPhone
		v_u_523 = type(v524) == "function" and v_u_13.isPhone() == true and 68 or 64
	else
		v_u_523 = 8
	end
	local v525 = v_u_4.plateHeight
	local v526 = v_u_13.isPhone
	local v527
	if type(v526) == "function" then
		v527 = v_u_13.isPhone() == true
	else
		v527 = false
	end
	local v_u_528 = v525(v_u_521, v527, v_u_13.uiScale())
	local v_u_529 = v_u_521 and 64 or 120
	local v530 = v522.Y - v_u_529 - 30 - v_u_523 - (v_u_528 + 6 + 16)
	local v_u_531 = "MenuHunt"
	local v532, v533 = pcall(function()
		-- upvalues: (copy) p_u_507, (copy) v_u_531
		return p_u_507.cctx.lib[v_u_531]
	end)
	if not v532 or type(v533) ~= "table" then
		v533 = nil
	end
	local v534 = false
	if v533 then
		local v535 = v533.new
		if type(v535) == "function" then
			local v536 = v533.openFor
			if type(v536) == "function" then
				local v537 = v533.openFor
				local v538 = p_u_507.cctx
				local v539
				v534, v539 = pcall(v537, v538, true)
				if v534 then
					v534 = v539 == true
				end
			end
		end
	end
	local v_u_540 = "MenuPvpveDoor"
	local v541, v542 = pcall(function()
		-- upvalues: (copy) p_u_507, (copy) v_u_540
		return p_u_507.cctx.lib[v_u_540]
	end)
	if not v541 or type(v542) ~= "table" then
		v542 = nil
	end
	local v543 = false
	if v542 then
		local v544 = v542.new
		if type(v544) == "function" then
			local v545 = v542.openFor
			if type(v545) == "function" then
				local v546 = v542.openFor
				local v547 = p_u_507.cctx
				local v548, v549 = pcall(v546, v547)
				v543 = v548
				if v543 then
					v543 = v549 == true
				end
			end
		end
	end
	local v550 = 0
	if v534 and v533 then
		local v551 = v533.touchExtra
		if type(v551) == "function" then
			local v552 = v533.touchExtra
			local v553 = v_u_13.touch
			local v554, v555 = pcall(v552, "full", v553(34))
			v550 = (not v554 or type(v555) ~= "number") and 0 or v555
		end
	end
	local v556 = v_u_521 or v530 < (not v534 and 328 or v550 + 344 + 24) + (v543 and 112 or 0)
	local v_u_557 = v556 and 216 or 264
	local v_u_558 = v_u_13.touch(v556 and 48 or 64)
	local v559 = v_u_13.isPhone
	local v_u_560
	if type(v559) == "function" then
		v_u_560 = v_u_13.isPhone() == true
	else
		v_u_560 = false
	end
	if v_u_560 then
		v_u_557 = v_u_558
	end
	local v561 = v556 and 104 or 112
	local v_u_562 = not v_u_560
	if v_u_562 then
		v_u_562 = v_u_4.signFits(v530, v_u_558, v561)
	end
	local function v563()
		-- upvalues: (copy) p_u_507, (ref) v_u_562
		if p_u_507.cctx.shared.GameMode.isPvpve() then
			v_u_562 = false
		end
	end
	pcall(v563)
	local v_u_564 = v_u_12.new("Frame", {
		["Name"] = "Rail",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 2,
		["Position"] = UDim2.fromOffset(24, v_u_523),
		["Size"] = UDim2.fromOffset(v_u_557, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_508)
	v_u_12.layout(v_u_564, "v", 8)
	v_u_515.frame = v_u_564
	v_u_515.level = v556 and "compact" or "full"
	local v_u_565 = nil
	local v_u_566 = v_u_560 and "phone" or (v556 and "mini" or "full")
	local v_u_567
	if v_u_560 and v543 then
		v_u_567 = v_u_12.new("Frame", {
			["Name"] = "TileRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Size"] = UDim2.fromOffset(0, 0)
		}, v_u_564)
		v_u_12.layout(v_u_567, "h", 8)
	else
		v_u_567 = v_u_564
	end
	local v_u_568 = nil
	local v_u_569 = false
	if v533 then
		local v570 = v533.new
		if type(v570) == "function" then
			local v571 = v533.new
			local v572 = p_u_507
			local v573 = v_u_564
			local v574 = 0
			local v575 = {
				["mode"] = v_u_566
			}
			local v576
			if v_u_560 then
				v576 = nil
			else
				v576 = v_u_557
			end
			v575.w = v576
			function v575.onSize() -- name: onSize
				-- upvalues: (ref) v_u_568, (ref) v_u_569
				if v_u_568 and not v_u_569 then
					v_u_569 = true
					local v577 = v_u_568
					pcall(v577)
					v_u_569 = false
				end
			end
			local v578, v579 = pcall(v571, v572, v573, v574, v575)
			if v578 then
				v_u_565 = v579
				if v_u_567 ~= v_u_564 and v579.frame ~= nil then
					v579.frame.Parent = v_u_567
				end
			else
				warn("[MenuRail] hunt tile failed:", v579)
			end
		end
	end
	v_u_515.tile = v_u_565
	local v_u_580 = nil
	if v543 then
		local v581 = v542.new
		local v583, v584 = pcall(v581, p_u_507, v_u_567, 1, {
			["mode"] = v_u_566,
			["cardH"] = v_u_558,
			["onSize"] = function() -- name: onSize
				-- upvalues: (ref) v_u_568, (ref) v_u_569
				if v_u_568 and not v_u_569 then
					v_u_569 = true
					local v582 = v_u_568
					pcall(v582)
					v_u_569 = false
				end
			end
		})
		if v583 then
			v_u_580 = v584
		else
			warn("[MenuRail] door tile failed:", v584)
		end
	end
	v_u_515.door = v_u_580
	local function v593() -- name: syncRow
		-- upvalues: (ref) v_u_567, (copy) v_u_564, (ref) v_u_565, (ref) v_u_580, (ref) v_u_4
		if v_u_567 ~= v_u_564 then
			local v585 = {}
			local v586 = {}
			local v587
			if v_u_565 then
				v587 = v_u_565.frame
			else
				v587 = nil
			end
			local v588
			if v_u_580 then
				v588 = v_u_580.frame
			else
				v588 = nil
			end
			__set_list(v586, 1, {v587, v588})
			for _, v589 in v586 do
				if v589 == nil then
					continue
				end
				local v590 = {
					["w"] = v589.Size.X.Offset,
					["h"] = v589.Size.Y.Offset,
					["visible"] = v589.Visible
				}
				table.insert(v585, v590)
			end
			local v591, v592 = v_u_4.rowSize(v585, 8)
			v_u_567.Size = UDim2.fromOffset(v591, v592)
		end
	end
	if v_u_567 ~= v_u_564 then
		local v594 = {}
		local v595
		if v_u_565 then
			v595 = v_u_565.frame
		else
			v595 = nil
		end
		local v596
		if v_u_580 then
			v596 = v_u_580.frame
		else
			v596 = nil
		end
		__set_list(v594, 1, {v595, v596})
		for _, v597 in v594 do
			if v597 == nil then
				continue
			end
			local v598 = v597:GetPropertyChangedSignal("Size")
			table.insert(v_u_516, v598:Connect(v593))
			local v599 = v597:GetPropertyChangedSignal("Visible")
			table.insert(v_u_516, v599:Connect(v593))
		end
		v593()
	end
	local v_u_600 = {}
	v_u_600.mail = v_u_430(v_u_564, {
		["name"] = "Mail",
		["label"] = "Mail",
		["glyph"] = nil,
		["order"] = 2,
		["h"] = nil,
		["iconOnly"] = nil,
		["w"] = nil,
		["compact"] = nil,
		["onClick"] = nil,
		["tip"] = nil,
		["glyph"] = function(p601, p602, p603) -- name: glyph
			-- upvalues: (ref) v_u_4
			return v_u_4.glyph("mail", p601, p602, p603)
		end,
		["h"] = v_u_558,
		["iconOnly"] = v_u_560,
		["w"] = v_u_557,
		["compact"] = v556,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_507, (copy) v_u_600
			local v_u_604 = p_u_507
			local v_u_605 = "MenuMail"
			local v606, v607 = pcall(function()
				-- upvalues: (copy) v_u_604, (copy) v_u_605
				return v_u_604.cctx.lib[v_u_605]
			end)
			if not v606 or type(v607) ~= "table" then
				v607 = nil
			end
			if v607 then
				local v608 = v607.open
				if type(v608) == "function" then
					v607.open(p_u_507, v_u_600.mail.btn)
				end
			end
		end,
		["tip"] = function() -- name: tip
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_5
			local v609 = v_u_4.mailLive()
			local v610 = "Letters from the HUSH team, and insured items that were lost in a raid."
			if v_u_8 and v609 then
				v610 = v_u_8.cardTip(v610, v609.waiting, v609.showDeliveries)
			end
			local v611 = v_u_5:GetAttribute("MailUnread")
			local v612
			if type(v611) == "number" then
				local v613 = math.floor(v611)
				v612 = math.max(0, v613)
			else
				v612 = 0
			end
			if v612 > 0 then
				v610 = ("%d unread %s. %s"):format(v612, v612 == 1 and "letter" or "letters", v610)
			elseif v609 and v609.ready > 0 then
				v610 = ("%d ready to claim. %s"):format(v609.ready, v610)
			elseif v609 and v609.nextLeft then
				v610 = ("Next arrival in %s. %s"):format(v_u_4.waitText(v609.nextLeft), v610)
			end
			return {
				["title"] = "MAIL",
				["body"] = nil,
				["body"] = v610
			}
		end
	})
	v_u_600.insure = v_u_430(v_u_564, {
		["name"] = "Insurance",
		["label"] = "Insurance",
		["glyph"] = nil,
		["order"] = 3,
		["h"] = nil,
		["iconOnly"] = nil,
		["w"] = nil,
		["compact"] = nil,
		["onClick"] = nil,
		["tip"] = nil,
		["glyph"] = function(p614, p615, p616) -- name: glyph
			-- upvalues: (ref) v_u_12
			return v_u_12.icon("shield", {
				["parent"] = p614,
				["size"] = p615,
				["color"] = p616
			})
		end,
		["h"] = v_u_558,
		["iconOnly"] = v_u_560,
		["w"] = v_u_557,
		["compact"] = v556,
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_372, (copy) p_u_507, (ref) v_u_12
			local v617 = v_u_372()
			if v617 then
				local v618 = v617.open
				local v619 = p_u_507
				if pcall(v618, v619) then
					return
				end
			end
			v_u_12.toast("Insurance is not available right now", "warn", "The window could not open. Close the menu and open it again.")
		end,
		["tip"] = function() -- name: tip
			-- upvalues: (ref) v_u_372
			local v620 = v_u_372()
			local v621 = nil
			if v620 then
				local v622 = v620.summary
				if type(v622) == "function" then
					local v623 = v620.summary
					local v624
					v624, v621 = pcall(v623)
					if not v624 then
						v621 = nil
					end
				end
			end
			local v625 = "Insure the gear in your kit before a raid. If you die and nobody carries it out, it comes back by mail."
			if type(v621) == "table" then
				local v626 = v621.used
				local v627 = tonumber(v626)
				local v628 = (v627 == nil or v627 ~= v627) and 0 or v627
				local v629 = v621.slots
				local v630 = tonumber(v629)
				v625 = ("%d of %d slots in use. %s"):format(v628, (v630 == nil or v630 ~= v630) and 0 or v630, v625)
			end
			return {
				["title"] = "INSURANCE",
				["body"] = nil,
				["body"] = v625
			}
		end
	})
	local v_u_631 = v_u_444(v_u_564, 4, v561, v556)
	v_u_631.Visible = v_u_562
	v_u_600.votes = v_u_430(v_u_564, {
		["name"] = "Votes",
		["label"] = "Votes",
		["glyph"] = nil,
		["order"] = 5,
		["h"] = nil,
		["iconOnly"] = nil,
		["w"] = nil,
		["compact"] = nil,
		["onClick"] = nil,
		["tip"] = nil,
		["glyph"] = function(p632, p633, p634) -- name: glyph
			-- upvalues: (ref) v_u_4
			return v_u_4.glyph("vote", p632, p633, p634)
		end,
		["h"] = v_u_558,
		["iconOnly"] = v_u_560,
		["w"] = v_u_557,
		["compact"] = v556,
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_4, (copy) p_u_507, (copy) v_u_600
			if v_u_4.failed("votes") then
				v_u_4.fetch(p_u_507, "votes", {
					["force"] = true
				})
			end
			local v_u_635 = p_u_507
			local v_u_636 = "MenuVotes"
			local v637, v638 = pcall(function()
				-- upvalues: (copy) v_u_635, (copy) v_u_636
				return v_u_635.cctx.lib[v_u_636]
			end)
			if not v637 or type(v638) ~= "table" then
				v638 = nil
			end
			if v638 then
				local v639 = v638.open
				if type(v639) == "function" then
					v638.open(p_u_507, v_u_600.votes.btn)
				end
			end
		end,
		["tip"] = function() -- name: tip
			-- upvalues: (ref) v_u_4, (ref) v_u_232
			local v640 = v_u_4.votesLive()
			local v641 = (v640 or not v_u_4.failed("votes")) and "Tell us what to build next. One vote per poll." or v_u_232().VOTES_OFFLINE_TIP
			if v640 and v640.openUnvoted > 0 then
				v641 = ("%d open %s waiting for your vote. %s"):format(v640.openUnvoted, v640.openUnvoted == 1 and "vote" or "votes", v641)
			end
			return {
				["title"] = "VOTES",
				["body"] = nil,
				["body"] = v641
			}
		end
	})
	v_u_515.cards = v_u_600
	v_u_515.sign = v_u_631
	local v_u_642 = {}
	local function v_u_656() -- name: paintInsure
		-- upvalues: (ref) v_u_372, (copy) v_u_600, (copy) v_u_642
		local v643 = v_u_372()
		local v644 = v_u_600.insure.btn
		local v645
		if v643 == nil then
			v645 = false
		else
			v645 = not v_u_642.insure
		end
		v644.Visible = v645
		if v643 then
			local v646 = ""
			local v647 = v643.summary
			if type(v647) == "function" then
				local v648 = v643.summary
				local v649, v650 = pcall(v648)
				if v649 and type(v650) == "table" then
					local v651 = v650.used
					local v652 = tonumber(v651)
					local v653 = (v652 == nil or v652 ~= v652) and 0 or v652
					local v654 = v650.slots
					local v655 = tonumber(v654)
					v646 = ("%d / %d slots"):format(v653, (v655 == nil or v655 ~= v655) and 0 or v655)
				end
			end
			v_u_600.insure.setSub(v646)
		end
	end
	local v_u_657 = nil
	local v_u_658 = -1000000000
	local v_u_659 = v_u_523
	local function v_u_675() -- name: avoidHint
		-- upvalues: (ref) v_u_657, (ref) v_u_658, (copy) v_u_564, (copy) v_u_523, (ref) v_u_13, (copy) p_u_508, (ref) v_u_659, (ref) v_u_12, (copy) v_u_528
		local v660 = v_u_657
		if not (v660 and (v660.Parent and v660.Visible)) and os.clock() - v_u_658 > 1.5 then
			v_u_658 = os.clock()
			local v661 = v_u_564:FindFirstAncestorOfClass("ScreenGui")
			local v662
			if v661 then
				v662 = v661:FindFirstChild("SquadHint", true)
			else
				v662 = nil
			end
			if v661 then
				v660 = v661:FindFirstChild("PaidHint", true)
			else
				v660 = nil
			end
			if v660 == nil or (not v660.Visible or v662 ~= nil and v662.Visible) then
				v660 = v662
			end
			v_u_657 = v660
		end
		local v663 = v_u_523
		if v660 and (v660.Parent and v660.Visible) then
			local v664 = v_u_13.uiScale()
			local v665 = v660.AbsolutePosition
			local v666 = v660.AbsoluteSize
			local v667 = v_u_564.AbsolutePosition
			local v668 = v_u_564.AbsoluteSize
			if v665.X < v667.X + v668.X and v665.X + v666.X > v667.X then
				local v669 = v_u_523
				local v670 = (v665.Y + v666.Y - p_u_508.AbsolutePosition.Y) / v664
				local v671 = math.ceil(v670) + 8
				v663 = math.max(v669, v671)
			end
		end
		if v663 ~= v_u_659 then
			v_u_659 = v663
			v_u_12.tween(v_u_564, {
				["Position"] = UDim2.fromOffset(24, v663)
			}, "normal")
		end
		local v672 = v_u_13.uiScale()
		local v673 = math.max(v672, 0.01)
		local v674 = v663 <= v_u_523 and true or v663 + v_u_564.AbsoluteSize.Y / v673 <= p_u_508.AbsoluteSize.Y / v673 - v_u_528 - 6 - 8
		if v_u_564.Visible ~= v674 then
			v_u_564.Visible = v674
		end
	end
	local function v_u_732(p_u_676, p677) -- name: fitPhone
		-- upvalues: (ref) v_u_13, (ref) v_u_4, (copy) p_u_508, (copy) v_u_529, (copy) v_u_528, (copy) v_u_600, (ref) v_u_372, (copy) v_u_566, (ref) v_u_580, (copy) v_u_560, (ref) v_u_565, (ref) v_u_659, (copy) v_u_558, (copy) v_u_521, (copy) v_u_564, (ref) v_u_557, (copy) v_u_642
		local v678 = v_u_13.uiScale()
		local v679 = math.max(v678, 0.01)
		local v680 = v_u_4.roomLimit(p_u_508.AbsoluteSize.Y / v679, v_u_13.safeRefSize().Y - v_u_529 - 30, v_u_528)
		local v681 = {}
		for v682, v683 in v_u_600 do
			if v682 == "insure" and v_u_372() == nil then
				continue
			end
			table.insert(v681, {
				["name"] = v682,
				["c"] = v683
			})
		end
		table.sort(v681, function(p684, p685)
			return p684.c.btn.LayoutOrder < p685.c.btn.LayoutOrder
		end)
		local v686 = #v681
		local v687 = v_u_566
		local v688 = v_u_566
		local v689, v690, v691, v692, v693, v694, v695, v696, v697, v698
		if p677 and (v_u_580 ~= nil and (v_u_566 ~= "full" and p_u_508.AbsoluteSize.Y > 0)) then
			local v_u_699 = v_u_560 and p_u_676
			local v700
			if p_u_676 then
				v700 = v_u_4.huntKinds(v_u_566, v_u_13.isTouch())
			else
				v700 = { v_u_566 }
			end
			local v701 = v_u_560 and { v_u_699 and "square" or "phone" } or (v_u_13.isTouch() and { "mini" } or { "mini", "slim" })
			local v702
			if p_u_676 then
				local v703 = v_u_565.speaksSentence
				if type(v703) == "function" and v_u_565.speaksSentence() == true then
					v702 = true
				else
					v702 = v_u_580.speaksSentence() == true
				end
			else
				v702 = v_u_580.speaksSentence() == true
			end
			local v704 = v_u_4.pickTiles
			local function v709(p705, p706)
				-- upvalues: (copy) p_u_676, (copy) v_u_699, (ref) v_u_565, (ref) v_u_580
				if p705 ~= "hunt" then
					return v_u_699 and 0 or v_u_580.heightFor(p706)
				end
				if not p_u_676 then
					return 0
				end
				if not v_u_699 then
					return v_u_565.heightFor(p706)
				end
				local v707 = v_u_565.heightFor(p706)
				local v708 = v_u_580.heightFor
				return math.max(v707, v708("square"))
			end
			local v710 = v_u_659
			local v711 = v_u_558
			local v712 = #v681
			local v713 = #v681
			v687, v688, v686 = v704(v700, v701, v709, v710, v680, v711, v712, (math.min(v702 and 1 or 2, v713)))
			v689 = false
			if not p_u_676 and (not p677 and (v_u_521 and p_u_508.AbsoluteSize.Y > 0)) then
				v690 = v_u_4.phoneFit(v_u_659, 0, v680, v_u_558, #v681)
				if v690 < #v681 then
					if v_u_560 then
						v689 = true
					else
						v691 = #v681
						v692 = math.min(2, v691)
						v686 = math.max(v692, v690)
					end
				end
			end
			v693 = v_u_564:FindFirstChildOfClass("UIListLayout")
			if v693 ~= nil then
				if v689 then
					v694 = Enum.FillDirection.Horizontal
				else
					v694 = Enum.FillDirection.Vertical
				end
				if v693.FillDirection ~= v694 then
					v693.FillDirection = v694
				end
				if v689 then
					v695 = v_u_4.rowWidth(#v681, v_u_558)
				else
					v695 = v_u_557
				end
				if v_u_564.Size.X.Offset ~= v695 then
					v_u_564.Size = UDim2.fromOffset(v695, 0)
				end
				if v689 then
					v696 = UDim2.fromOffset(v_u_558, v_u_558)
				else
					v696 = UDim2.new(1, 0, 0, v_u_558)
				end
				for v728, v729 in v681 do
					if v729.c.btn.Size == v696 then
						continue
					end
					v729.c.btn.Size = v696
				end
			end
			if v_u_565 ~= nil then
				v697 = v_u_565.setKind
				if type(v697) == "function" then
					v_u_565.setKind(v687)
				end
			end
			if v_u_580 ~= nil and p677 then
				v_u_580.setKind(v_u_566 == "full" and "full" or (v_u_560 and (p_u_676 and "square" or "phone") or v688))
			end
			for v730, v731 in v681 do
				v698 = v686 < v730
				v_u_642[v731.name] = v698
				if v731.name == "insure" then
					continue
				end
				v731.c.btn.Visible = not v698
			end
		else
			if v_u_565 ~= nil and (p_u_676 and (v_u_566 ~= "full" and p_u_508.AbsoluteSize.Y > 0)) then
				local v718 = v_u_565.heightFor
				if type(v718) == "function" then
					local v719 = v_u_4.huntKinds(v_u_566, v_u_13.isTouch())
					local v720 = v_u_565.speaksSentence
					local v721
					if type(v720) == "function" then
						v721 = v_u_565.speaksSentence() == true
					else
						v721 = false
					end
					local v722 = v_u_4.pickTile
					local v723 = v_u_565.heightFor
					local v724 = v_u_659
					local v725 = v_u_558
					local v726 = #v681
					local v727 = #v681
					v687, v686 = v722(v719, v723, v724, v680, v725, v726, (math.min(v721 and 1 or 2, v727)))
				end
			end
			v689 = false
			if not p_u_676 and (not p677 and (v_u_521 and p_u_508.AbsoluteSize.Y > 0)) then
				v690 = v_u_4.phoneFit(v_u_659, 0, v680, v_u_558, #v681)
				if v690 < #v681 then
					if v_u_560 then
						v689 = true
					else
						v691 = #v681
						v692 = math.min(2, v691)
						v686 = math.max(v692, v690)
					end
				end
			end
			v693 = v_u_564:FindFirstChildOfClass("UIListLayout")
			if v693 ~= nil then
				if v689 then
					v694 = Enum.FillDirection.Horizontal
				else
					v694 = Enum.FillDirection.Vertical
				end
				if v693.FillDirection ~= v694 then
					v693.FillDirection = v694
				end
				if v689 then
					v695 = v_u_4.rowWidth(#v681, v_u_558)
				else
					v695 = v_u_557
				end
				if v_u_564.Size.X.Offset ~= v695 then
					v_u_564.Size = UDim2.fromOffset(v695, 0)
				end
				if v689 then
					v696 = UDim2.fromOffset(v_u_558, v_u_558)
				else
					v696 = UDim2.new(1, 0, 0, v_u_558)
				end
				for v728, v729 in v681 do
					if v729.c.btn.Size == v696 then
						continue
					end
					v729.c.btn.Size = v696
				end
			end
			if v_u_565 ~= nil then
				v697 = v_u_565.setKind
				if type(v697) == "function" then
					v_u_565.setKind(v687)
				end
			end
			if v_u_580 ~= nil and p677 then
				v_u_580.setKind(v_u_566 == "full" and "full" or (v_u_560 and (p_u_676 and "square" or "phone") or v688))
			end
			for v730, v731 in v681 do
				v698 = v686 < v730
				v_u_642[v731.name] = v698
				if v731.name == "insure" then
					continue
				end
				v731.c.btn.Visible = not v698
			end
		end
	end
	local function v_u_754() -- name: paint
		-- upvalues: (ref) v_u_517, (copy) v_u_675, (ref) v_u_565, (ref) v_u_580, (ref) v_u_562, (copy) v_u_732, (copy) v_u_631, (ref) v_u_4, (ref) v_u_5, (copy) v_u_600, (ref) v_u_14, (ref) v_u_520, (ref) v_u_15, (copy) p_u_507, (ref) v_u_232, (copy) v_u_656
		if v_u_517 then
			local v733 = v_u_675
			pcall(v733)
			local v734
			if v_u_565 == nil then
				v734 = false
			else
				v734 = v_u_565.isOpen() == true
			end
			if v_u_580 ~= nil then
				local v735 = v_u_580.paint
				pcall(v735)
			end
			local v736
			if v_u_580 == nil then
				v736 = false
			else
				v736 = v_u_580.isOpen() == true
			end
			local v737 = v_u_562
			if v737 then
				v737 = not v734
				if v737 then
					v737 = not v736
				end
			end
			local v738 = v_u_732
			pcall(v738, v734, v736)
			if v_u_631.Visible ~= v737 then
				v_u_631.Visible = v737
			end
			local v739 = v_u_4.mailLive()
			local v740 = v_u_5:GetAttribute("MailUnread")
			local v741
			if type(v740) == "number" then
				local v742 = math.floor(v740)
				v741 = math.max(0, v742)
			else
				v741 = 0
			end
			if v739 then
				v_u_600.mail.setBadge(v739.ready + v739.waiting + v741)
				local v743, v744 = v_u_4.mailSub(v739, v741)
				local v745 = v_u_600.mail.setSub
				local v746
				if v744 == "accent" then
					v746 = v_u_14.accent
				elseif v744 == "muted" then
					v746 = v_u_14.muted
				else
					v746 = nil
				end
				v745(v743, v746)
				if v_u_520 >= 0 and (v_u_520 < v739.ready and (not v_u_4.stubActive("mail") and os.clock() - v_u_15.syncAt > 10)) then
					v_u_15.syncAt = os.clock()
					task.delay(1.2, function()
						-- upvalues: (ref) v_u_517, (ref) v_u_4, (ref) p_u_507
						if v_u_517 then
							v_u_4.fetch(p_u_507, "mail", {
								["force"] = true
							})
						end
					end)
				end
				v_u_520 = v739.ready
			else
				v_u_600.mail.setBadge(v741)
				local v747 = v_u_600.mail.setSub
				local v748
				if v741 > 0 then
					v748 = v741 == 1 and "1 new letter" or ("%d new letters"):format(v741)
				else
					v748 = not v_u_4.failed("mail") and "" or v_u_232().OFFLINE_SUB
				end
				local v749
				if v741 > 0 then
					v749 = v_u_14.accent
				else
					v749 = v_u_14.muted
				end
				v747(v748, v749)
			end
			v_u_600.mail.setPulse(v_u_4.pulseOn())
			local v750 = v_u_4.votesLive()
			if v750 then
				v_u_600.votes.setBadge(v750.openUnvoted)
				local v751 = v_u_600.votes.setSub
				local v752 = v750.open <= 0 and "Nothing open" or ("%d open"):format(v750.open)
				local v753
				if v750.open > 0 then
					v753 = v_u_14.text2
				else
					v753 = v_u_14.muted
				end
				v751(v752, v753)
			else
				v_u_600.votes.setBadge(0)
				v_u_600.votes.setSub(not v_u_4.failed("votes") and "" or v_u_232().OFFLINE_SUB, v_u_14.muted)
			end
			v_u_656()
		end
	end
	v_u_515.paint = v_u_754
	local v755 = v_u_5:GetAttributeChangedSignal("MailUnread")
	local function v756()
		-- upvalues: (ref) v_u_517, (copy) v_u_754
		if v_u_517 then
			v_u_754()
		end
	end
	table.insert(v_u_516, v755:Connect(v756))
	local function v_u_762(p757) -- name: refreshAll
		-- upvalues: (ref) v_u_4, (copy) p_u_507, (ref) v_u_372
		v_u_4.fetch(p_u_507, "mail", {
			["force"] = p757
		})
		v_u_4.fetch(p_u_507, "votes", {
			["force"] = p757
		})
		local v758 = v_u_372()
		if v758 then
			local v759 = v758.refresh
			if type(v759) == "function" then
				local v760 = v758.refresh
				local v761 = p_u_507
				pcall(v760, v761)
			end
		end
	end
	local v_u_770 = v_u_4.listen(function(p763)
		-- upvalues: (ref) v_u_517, (copy) v_u_754, (copy) p_u_507
		if v_u_517 then
			v_u_754()
			local v_u_764 = p_u_507
			local v_u_765 = p763 == "mail" and "MenuMail" or "MenuVotes"
			local v766, v767 = pcall(function()
				-- upvalues: (copy) v_u_764, (copy) v_u_765
				return v_u_764.cctx.lib[v_u_765]
			end)
			if not v766 or type(v767) ~= "table" then
				v767 = nil
			end
			if v767 then
				local v768 = v767.update
				if type(v768) == "function" then
					local v769 = v767.update
					pcall(v769)
				end
			end
		end
	end)
	local v_u_771 = nil
	local v_u_772 = false
	local function v_u_778() -- name: checkMailProfile
		-- upvalues: (copy) p_u_507, (ref) v_u_4, (ref) v_u_15, (ref) v_u_771, (ref) v_u_772, (ref) v_u_517, (ref) v_u_518, (copy) v_u_778
		local v773 = p_u_507.profile
		local v774 = v_u_4.mailSig
		local v775
		if type(v773) == "table" then
			v775 = v773.mail
		else
			v775 = nil
		end
		local v776 = v774(v775)
		if v776 == v_u_15.mailSig or v776 == v_u_771 then
			return
		else
			local v777 = 2 - (os.clock() - v_u_15.at.mail)
			if v777 > 0 then
				if not v_u_772 then
					v_u_772 = true
					task.delay(v777 + 0.1, function()
						-- upvalues: (ref) v_u_772, (ref) v_u_517, (ref) v_u_518, (ref) v_u_4, (ref) v_u_778
						v_u_772 = false
						if v_u_517 and (v_u_518 and not v_u_4.stubActive("mail")) then
							v_u_778()
						end
					end)
				end
			else
				v_u_771 = v776
				v_u_4.fetch(p_u_507, "mail", {
					["force"] = true
				})
			end
		end
	end
	local v_u_781 = p_u_507.changed:Connect(function(p779, p780)
		-- upvalues: (ref) v_u_517, (ref) v_u_4, (copy) p_u_507, (ref) v_u_518, (copy) v_u_778
		if v_u_517 then
			if p779 == "result" and type(p780) == "table" then
				if p780.op == "mailClaim" then
					v_u_4.fetch(p_u_507, "mail", {
						["force"] = true
					})
					return
				end
				if p780.op == "voteCast" then
					v_u_4.fetch(p_u_507, "votes", {
						["force"] = true
					})
					return
				end
			elseif p779 == "profile" and (v_u_518 and not v_u_4.stubActive("mail")) then
				v_u_778()
			end
		end
	end)
	function v_u_515.show() -- name: show
		-- upvalues: (ref) v_u_518, (ref) v_u_519, (ref) v_u_565, (ref) v_u_580, (copy) v_u_754, (copy) v_u_762
		v_u_518 = true
		v_u_519 = 0
		if v_u_565 then
			v_u_565.setActive(true)
		end
		if v_u_580 then
			v_u_580.setActive(true)
		end
		v_u_754()
		v_u_762(false)
	end
	function v_u_515.hide() -- name: hide
		-- upvalues: (ref) v_u_518, (ref) v_u_565, (ref) v_u_580, (copy) p_u_507, (ref) v_u_372
		v_u_518 = false
		if v_u_565 then
			v_u_565.setActive(false)
		end
		if v_u_580 then
			v_u_580.setActive(false)
		end
		for _, v_u_782 in { "MenuMail", "MenuVotes" } do
			local v_u_783 = p_u_507
			local v784, v785 = pcall(function()
				-- upvalues: (copy) v_u_783, (copy) v_u_782
				return v_u_783.cctx.lib[v_u_782]
			end)
			if not v784 or type(v785) ~= "table" then
				v785 = nil
			end
			if not v785 then
				continue
			end
			local v786 = v785.close
			if type(v786) ~= "function" then
				continue
			end
			local v787 = v785.close
			pcall(v787)
		end
		local v788 = v_u_372()
		if v788 then
			local v789 = v788.close
			if type(v789) == "function" then
				local v790 = v788.close
				pcall(v790)
			end
		end
	end
	function v_u_515.refresh(p791) -- name: refresh
		-- upvalues: (copy) v_u_754
		if p791 == "profile" then
			v_u_754()
		end
	end
	function v_u_515.tick() -- name: tick
		-- upvalues: (ref) v_u_517, (copy) v_u_754, (copy) p_u_507, (ref) v_u_519, (copy) v_u_762
		if v_u_517 then
			v_u_754()
			for _, v_u_792 in { "MenuMail", "MenuVotes" } do
				local v_u_793 = p_u_507
				local v794, v795 = pcall(function()
					-- upvalues: (copy) v_u_793, (copy) v_u_792
					return v_u_793.cctx.lib[v_u_792]
				end)
				if not v794 or type(v795) ~= "table" then
					v795 = nil
				end
				if not v795 then
					continue
				end
				local v796 = v795.tick
				if type(v796) ~= "function" then
					continue
				end
				local v797 = v795.tick
				pcall(v797)
			end
			v_u_519 = v_u_519 + 1
			if v_u_519 >= 60 then
				v_u_519 = 0
				v_u_762(false)
			end
		end
	end
	function v_u_515.destroy() -- name: destroy
		-- upvalues: (ref) v_u_517, (copy) v_u_770, (copy) v_u_781, (copy) v_u_516, (copy) v_u_515, (ref) v_u_565, (ref) v_u_580, (ref) v_u_15, (copy) v_u_564
		v_u_517 = false
		v_u_770()
		v_u_781:Disconnect()
		for _, v798 in v_u_516 do
			v798:Disconnect()
		end
		v_u_515.hide()
		if v_u_565 then
			local v799 = v_u_565.destroy
			pcall(v799)
		end
		if v_u_580 then
			local v800 = v_u_580.destroy
			pcall(v800)
		end
		if v_u_15.rail == v_u_515 then
			v_u_15.rail = nil
		end
		v_u_564:Destroy()
	end
	v_u_15.rail = v_u_515
	local _ = v_u_754
	v_u_754()
	return v_u_515
end
function v_u_4.attach(p801, p802, p803) -- name: attach
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v804 = v_u_4.new
	local v805, v_u_806 = pcall(v804, p801, p802)
	if not v805 then
		warn("[MenuRail] rail failed:", v_u_806)
		if v_u_5 then
			v_u_5:SetAttribute("ClientError", "menu rail: " .. tostring(v_u_806))
		end
		return nil
	end
	local v_u_807 = p803.show
	local v_u_808 = p803.hide
	local v_u_809 = p803.tick
	local v_u_810 = p803.destroy
	local v_u_811 = p803.refresh
	function p803.refresh(...) -- name: refresh
		-- upvalues: (copy) v_u_811, (copy) v_u_806
		if v_u_811 then
			v_u_811(...)
		end
		local v812 = v_u_806.refresh
		pcall(v812, ...)
	end
	function p803.show(...) -- name: show
		-- upvalues: (copy) v_u_807, (copy) v_u_806
		if v_u_807 then
			v_u_807(...)
		end
		local v813 = v_u_806.show
		pcall(v813)
	end
	function p803.hide(...) -- name: hide
		-- upvalues: (copy) v_u_806, (copy) v_u_808
		local v814 = v_u_806.hide
		pcall(v814)
		if v_u_808 then
			v_u_808(...)
		end
	end
	function p803.tick(...) -- name: tick
		-- upvalues: (copy) v_u_809, (copy) v_u_806
		if v_u_809 then
			v_u_809(...)
		end
		local v815 = v_u_806.tick
		pcall(v815)
	end
	function p803.destroy(...) -- name: destroy
		-- upvalues: (copy) v_u_806, (copy) v_u_810
		local v816 = v_u_806.destroy
		pcall(v816)
		if v_u_810 then
			v_u_810(...)
		end
	end
	p803.rail = v_u_806
	return v_u_806
end
local v_u_817 = false
function v_u_4.installHooks(p_u_818) -- name: installHooks
	-- upvalues: (ref) v_u_817, (copy) v_u_3, (ref) v_u_13, (copy) v_u_15, (ref) v_u_12, (copy) v_u_4, (copy) v_u_5, (copy) v_u_372, (copy) v_u_6
	if v_u_817 or not v_u_3:IsStudio() then
		return
	else
		local v819 = p_u_818.cctx
		local v820 = v819.command
		if type(v820) == "function" then
			v_u_817 = true
			v819.command("rail.state", function()
				-- upvalues: (ref) v_u_15, (ref) v_u_13, (copy) p_u_818, (ref) v_u_12, (ref) v_u_4
				local v821 = v_u_15.rail
				if not v821 then
					return "no rail (PLAY tab not built)"
				end
				local v822 = {}
				local v823 = "level=%s vis=%s"
				local v824 = v821.level
				local v825 = v821.frame.Visible
				if v825 then
					if v821.frame.Parent == nil then
						v825 = false
					else
						v825 = v821.frame.Parent.Visible
					end
				end
				__set_list(v822, 1, {v823:format(v824, (tostring(v825)))})
				for _, v826 in { "mail", "insure", "votes" } do
					local v827 = v821.cards[v826]
					local v828 = "%s[%s] vis=%s badge=%d sub=%q label=%q"
					local v829 = v827.btn
					local v830
					if v829 then
						local v831 = v_u_13.uiScale()
						local v832 = v829.AbsolutePosition / v831
						local v833 = v829.AbsoluteSize / v831
						v830 = ("%d,%d %dx%d"):format(v832.X, v832.Y, v833.X, v833.Y)
					else
						v830 = "-"
					end
					local v834 = v827.btn.Visible
					local v835 = tostring(v834)
					local v836 = v827.badge()
					local v837 = v827.sub.Text
					local v838 = v827.label.Text
					table.insert(v822, v828:format(v826, v830, v835, v836, v837, v838))
				end
				local v839 = v821.sign
				local v840 = 0
				for _, v841 in v839:GetDescendants() do
					if not v841:IsA("GuiButton") then
						continue
					end
					v840 = v840 + 1
				end
				local v842 = "sign[%s] title=%q soon=%q line=%q buttons=%d"
				local v843
				if v839 then
					local v844 = v_u_13.uiScale()
					local v845 = v839.AbsolutePosition / v844
					local v846 = v839.AbsoluteSize / v844
					v843 = ("%d,%d %dx%d"):format(v845.X, v845.Y, v846.X, v846.Y)
				else
					v843 = "-"
				end
				local v847 = v839:FindFirstChild("Title").Text
				local v848 = string.gsub(v847, utf8.char(8202), "")
				local v849 = v839:FindFirstChild("Soon").Text
				local v850 = string.gsub(v849, utf8.char(8202), "")
				local v851 = v839:FindFirstChild("Line").Text
				table.insert(v822, v842:format(v843, v848, v850, v851, v840))
				if v821.tile then
					local v852 = "tile[%s] vis=%s mode=%s open=%s sign vis=%s"
					local v853 = v821.tile.frame
					local v854
					if v853 then
						local v855 = v_u_13.uiScale()
						local v856 = v853.AbsolutePosition / v855
						local v857 = v853.AbsoluteSize / v855
						v854 = ("%d,%d %dx%d"):format(v856.X, v856.Y, v857.X, v857.Y)
					else
						v854 = "-"
					end
					local v858 = v821.tile.frame.Visible
					local v859 = tostring(v858)
					local v860 = v821.tile.mode
					local v861 = tostring(v860)
					local v862 = v821.tile.isOpen
					local v863 = tostring(v862())
					local v864 = v839.Visible
					local v865 = tostring(v864)
					table.insert(v822, v852:format(v854, v859, v861, v863, v865))
				else
					table.insert(v822, "tile=none")
				end
				local v_u_866 = p_u_818
				local v_u_867 = "MenuMail"
				local v868, v869 = pcall(function()
					-- upvalues: (copy) v_u_866, (copy) v_u_867
					return v_u_866.cctx.lib[v_u_867]
				end)
				if not v868 or type(v869) ~= "table" then
					v869 = nil
				end
				local v_u_870 = p_u_818
				local v_u_871 = "MenuVotes"
				local v872, v873 = pcall(function()
					-- upvalues: (copy) v_u_870, (copy) v_u_871
					return v_u_870.cctx.lib[v_u_871]
				end)
				if not v872 or type(v873) ~= "table" then
					v873 = nil
				end
				local v874 = "windows mail=%s votes=%s"
				local v875 = v869 and v869.isOpen
				if v875 then
					v875 = v869.isOpen()
				end
				local v876 = tostring(v875)
				local v877 = v873 and v873.isOpen
				if v877 then
					v877 = v873.isOpen()
				end
				local v878 = tostring(v877)
				table.insert(v822, v874:format(v876, v878))
				local v879 = "stub mail=%s votes=%s offset=%.2f modals=%d"
				local v880 = v_u_15.stub.mail
				if v880 then
					v880 = v_u_15.stub.mail.n
				end
				local v881 = tostring(v880)
				local v882 = v_u_15.stub.votes
				if v882 then
					v882 = v_u_15.stub.votes.n
				end
				local v883 = tostring(v882)
				local v884 = v_u_15.offset
				local v885 = v_u_12.modalCount
				table.insert(v822, v879:format(v881, v883, v884, v885()))
				local v886 = v_u_4.mailLive()
				if v886 then
					local v887 = "mail ready=%d pending=%d next=%s count=%d/%d"
					local v888 = v886.ready
					local v889 = v886.pending
					local v890 = v886.nextLeft
					if v890 then
						v890 = v_u_4.waitText(v886.nextLeft)
					end
					local v891 = tostring(v890)
					local v892 = v886.count
					local v893 = v886.capacity
					table.insert(v822, v887:format(v888, v889, v891, v892, v893))
				else
					table.insert(v822, "mail data=none")
				end
				local v894 = v_u_4.votesLive()
				if v894 then
					local v895 = #v894.rows
					local v896 = v894.open
					local v897 = v894.openUnvoted
					table.insert(v822, ("votes polls=%d open=%d unvoted=%d"):format(v895, v896, v897))
				else
					table.insert(v822, "votes data=none")
				end
				return table.concat(v822, "\n")
			end)
			v819.command("rail.layout", function()
				-- upvalues: (ref) v_u_15, (ref) v_u_5, (ref) v_u_13
				local v898 = v_u_15.rail
				if not v898 then
					return "no rail"
				end
				local v899 = v_u_5
				if v899 then
					v899 = v_u_5:FindFirstChildOfClass("PlayerGui")
				end
				if v899 then
					v899 = v899:FindFirstChild("HushMenu")
				end
				local function v904(p900) -- name: box
					-- upvalues: (ref) v_u_13
					if not (p900 and p900.Visible) then
						return nil
					end
					local v901 = v_u_13.uiScale()
					local v902 = p900.AbsolutePosition / v901
					local v903 = p900.AbsoluteSize / v901
					return {
						v902.X,
						v902.Y,
						v902.X + v903.X,
						v902.Y + v903.Y
					}
				end
				local v905 = v904(v898.frame)
				local v906 = {}
				local v907 = "rail %s | ref %s | scale %.2f"
				local v908 = v898.frame
				local v909
				if v908 then
					local v910 = v_u_13.uiScale()
					local v911 = v908.AbsolutePosition / v910
					local v912 = v908.AbsoluteSize / v910
					v909 = ("%d,%d %dx%d"):format(v911.X, v911.Y, v912.X, v912.Y)
				else
					v909 = "-"
				end
				local v913 = v_u_13.refSize
				__set_list(v906, 1, {v907:format(v909, tostring(v913()), v_u_13.uiScale())})
				for _, v914 in {
					"Plate",
					"Column",
					"PartyBar",
					"TopBar",
					"CurrentTask"
				} do
					local v915
					if v899 then
						v915 = v899:FindFirstChild(v914, true)
					else
						v915 = nil
					end
					local v916 = v904(v915)
					local v917
					if v916 and v905 then
						if v905[1] < v916[3] and (v916[1] < v905[3] and v905[2] < v916[4]) then
							v917 = v916[2] < v905[4]
						else
							v917 = false
						end
					else
						v917 = false
					end
					local v918 = "%s[%s] overlap=%s"
					local v919
					if v915 then
						local v920 = v_u_13.uiScale()
						local v921 = v915.AbsolutePosition / v920
						local v922 = v915.AbsoluteSize / v920
						v919 = ("%d,%d %dx%d"):format(v921.X, v921.Y, v922.X, v922.Y)
					else
						v919 = "-"
					end
					local v923 = tostring(v917)
					table.insert(v906, v918:format(v914, v919, v923))
				end
				return table.concat(v906, "\n")
			end)
			v819.command("rail.open", function(p924)
				-- upvalues: (ref) v_u_372, (copy) p_u_818
				local v925 = string.lower
				local v926 = p924[1] or ""
				local v927 = v925((tostring(v926)))
				if v927 == "insure" then
					local v928 = v_u_372()
					if not v928 then
						return "no MenuInsure module"
					end
					v928.open(p_u_818)
					return "opened insure"
				end
				local v_u_929 = p_u_818
				local v_u_930 = v927 == "mail" and "MenuMail" or (v927 == "votes" and "MenuVotes" or "")
				local v931, v932 = pcall(function()
					-- upvalues: (copy) v_u_929, (copy) v_u_930
					return v_u_929.cctx.lib[v_u_930]
				end)
				if not v931 or type(v932) ~= "table" then
					v932 = nil
				end
				if not v932 then
					return "usage: rail.open mail|votes|insure"
				end
				v932.open(p_u_818)
				return "opened " .. v927
			end)
			v819.command("rail.close", function()
				-- upvalues: (ref) v_u_372, (copy) p_u_818, (ref) v_u_12
				for _, v_u_933 in { "MenuMail", "MenuVotes", "MenuInsure" } do
					local v934
					if v_u_933 == "MenuInsure" then
						v934 = v_u_372()
					else
						local v_u_935 = p_u_818
						local v936
						v936, v934 = pcall(function()
							-- upvalues: (copy) v_u_935, (copy) v_u_933
							return v_u_935.cctx.lib[v_u_933]
						end)
						if not v936 or type(v934) ~= "table" then
							v934 = nil
						end
					end
					if not v934 then
						continue
					end
					local v937 = v934.close
					if type(v937) ~= "function" then
						continue
					end
					local v938 = v934.close
					pcall(v938)
				end
				return ("closed, modals=%d"):format(v_u_12.modalCount())
			end)
			v819.command("rail.stub", function(p939)
				-- upvalues: (ref) v_u_15, (ref) v_u_4, (copy) p_u_818, (ref) v_u_6
				local v940 = string.lower
				local v941 = p939[1] or ""
				local v942 = v940((tostring(v941)))
				if v942 == "off" then
					local v943 = v_u_15.stub
					local v944 = v_u_15.stub
					v943.mail = nil
					v944.votes = nil
					local v945 = v_u_15
					v_u_15.mail = nil
					v945.votes = nil
					v_u_4.fetch(p_u_818, "mail", {
						["force"] = true
					})
					v_u_4.fetch(p_u_818, "votes", {
						["force"] = true
					})
					return "stubs off"
				end
				if v942 ~= "mail" and v942 ~= "votes" then
					return "usage: rail.stub mail|votes <n> | rail.stub mail deliveries|mixed|expiry|full|empty|cargo|cargowarn | rail.stub off"
				end
				local v946 = p939[2]
				local v947 = tonumber(v946)
				local v948 = p939[2] == "off" and -1 or v947
				if v942 ~= "mail" or (v948 ~= nil or p939[2] == nil) then
					v_u_4.setStub(p_u_818, v942, v948 or 3)
					return ("stub %s = %s"):format(v942, (tostring(v948 or 3)))
				end
				local v949 = string.lower
				local v950 = p939[2]
				local v951 = v949((tostring(v950)))
				local v952
				if v_u_6 then
					v952 = v_u_6:FindFirstChild("MailStub")
				else
					v952 = nil
				end
				local v953
				if v952 and v952:IsA("ModuleScript") then
					local v954 = require
					local v955
					v955, v953 = pcall(v954, v952)
					if not v955 or type(v953) ~= "table" then
						v953 = nil
					end
				else
					v953 = nil
				end
				if not (v953 and table.find(v953.PRESETS, v951)) then
					return "usage: rail.stub mail <n> | deliveries|mixed|expiry|full|empty|cargo|cargowarn | off"
				end
				v_u_4.setStub(p_u_818, "mail", v951)
				return "stub mail = " .. v951
			end)
			v819.command("mail.guide", function(p956)
				-- upvalues: (copy) p_u_818
				local v957 = string.lower
				local v958 = p956[1] or ""
				local v959 = v957((tostring(v958)))
				if v959 ~= "store" and (v959 ~= "bm" and v959 ~= "cargo") then
					return "usage: mail.guide store|bm|cargo [later]"
				end
				local v_u_960 = p_u_818
				local v_u_961 = "MailGuide"
				local v962, v963 = pcall(function()
					-- upvalues: (copy) v_u_960, (copy) v_u_961
					return v_u_960.cctx.lib[v_u_961]
				end)
				if not v962 or type(v963) ~= "table" then
					v963 = nil
				end
				if not v963 then
					return "no MailGuide module"
				end
				if v959 == "cargo" then
					local v964 = v963.demoCargo
					local v965 = p_u_818
					return "guide: " .. tostring(v964(v965))
				end
				local v966 = v963.demo
				local v967 = p_u_818
				local v968 = p956[2] ~= "later"
				return "guide: " .. tostring(v966(v967, v959, v968))
			end)
			v819.command("mail.open", function(p969)
				-- upvalues: (copy) p_u_818
				local v_u_970 = p_u_818
				local v_u_971 = "MenuMail"
				local v972, v973 = pcall(function()
					-- upvalues: (copy) v_u_970, (copy) v_u_971
					return v_u_970.cctx.lib[v_u_971]
				end)
				if not v972 or type(v973) ~= "table" then
					v973 = nil
				end
				if not v973 then
					return "no MenuMail module"
				end
				if v973.isOpen() then
					v973.close()
					return "closed (call again to open)"
				end
				local v974 = string.lower
				local v975 = p969[1] or "deliveries"
				local v976 = v974((tostring(v975)))
				v973.open(p_u_818, nil, {
					["view"] = v976 == "letters" and "letters" or "deliveries"
				})
				return "opened mail on " .. v976
			end)
			v819.command("mail.claim", function(p977)
				-- upvalues: (copy) p_u_818
				local v_u_978 = p_u_818
				local v_u_979 = "MenuMail"
				local v980, v981 = pcall(function()
					-- upvalues: (copy) v_u_978, (copy) v_u_979
					return v_u_978.cctx.lib[v_u_979]
				end)
				if not v980 or type(v981) ~= "table" then
					v981 = nil
				end
				local v982 = p977[1] or ""
				local v983 = tostring(v982)
				if not v981 or (not v981.isOpen() or v983 == "") then
					return "usage: mail.claim <id|all> (the mail window must be open)"
				end
				v981._claim(v983)
				return "claim " .. v983
			end)
			v819.command("mail.layout", function()
				-- upvalues: (ref) v_u_5, (ref) v_u_13
				local v_u_984 = v_u_5
				if v_u_984 then
					v_u_984 = v_u_5:FindFirstChildOfClass("PlayerGui")
				end
				if v_u_984 then
					v_u_984 = v_u_984:FindFirstChild("HushModal")
				end
				if v_u_984 then
					v_u_984 = v_u_984:FindFirstChild("Modal", true)
				end
				if not v_u_984 then
					return "no modal open"
				end
				local v_u_985 = v_u_13.uiScale()
				local v986 = v_u_13.refSize()
				local function v988(p987) -- name: vis
					-- upvalues: (copy) v_u_984
					while p987 and p987 ~= v_u_984.Parent do
						if p987:IsA("GuiObject") and not p987.Visible then
							return false
						end
						p987 = p987.Parent
					end
					return true
				end
				local function v990(p989) -- name: box
					-- upvalues: (copy) v_u_985
					return {
						p989.AbsolutePosition.X / v_u_985,
						p989.AbsolutePosition.Y / v_u_985,
						(p989.AbsolutePosition.X + p989.AbsoluteSize.X) / v_u_985,
						(p989.AbsolutePosition.Y + p989.AbsoluteSize.Y) / v_u_985
					}
				end
				local v991 = v990(v_u_984)
				local v992 = {}
				local v993 = 0
				local v994
				if v991[3] - v991[1] <= v986.X + 0.5 then
					v994 = v991[4] - v991[2] <= v986.Y + 0.5
				else
					v994 = false
				end
				if not v994 then
					v993 = v993 + 1
				end
				local v995 = v991[1]
				local v996 = v991[2]
				local v997 = v991[3]
				local v998 = v991[4]
				local v999 = v991[3] - v991[1]
				local v1000 = v991[4] - v991[2]
				local v1001 = v986.X
				local v1002 = v986.Y
				local v1003 = tostring(v994)
				table.insert(v992, ("modal %.0f,%.0f to %.0f,%.0f (%.0fx%.0f) in ref %.0fx%.0f scale %.3f inside=%s"):format(v995, v996, v997, v998, v999, v1000, v1001, v1002, v_u_985, v1003))
				local v1004 = 0
				local v1005 = 1000000000
				local v1006 = 0
				local v1007 = 0
				local v1008 = 0
				local v1009 = 0
				for _, v1010 in v_u_984:GetDescendants() do
					if not (v1010:IsA("GuiObject") and v988(v1010)) then
						continue
					end
					if v1010:IsA("TextLabel") and v1010.Text ~= "" then
						v1006 = v1006 + 1
						local v1011 = v1010.TextBounds
						local v1012 = v1010.AbsoluteSize
						local v1013
						if v1011.X > v1012.X + 1.5 then
							v1013 = not v1010.TextWrapped
						else
							v1013 = false
						end
						local v1014
						if v1011.Y > v1012.Y + 1.5 then
							v1014 = v1010.TextWrapped
						else
							v1014 = false
						end
						if (v1013 or v1014) and v1010.TextTruncate ~= Enum.TextTruncate.AtEnd then
							v1008 = v1008 + 1
							local v1015 = v1010.Parent and (v1010.Parent.Name or "?") or "?"
							local v1016 = v1010.Name
							local v1017 = v1010.Text
							local v1018 = v1011.X
							local v1019 = v1011.Y
							local v1020 = v1012.X
							local v1021 = v1012.Y
							table.insert(v992, ("  CLIPPED %s.%s %q text %.0fx%.0f box %.0fx%.0f"):format(v1015, v1016, v1017, v1018, v1019, v1020, v1021))
						elseif v1010.TextTruncate == Enum.TextTruncate.AtEnd and not v1010.TextFits then
							v1009 = v1009 + 1
							local v1022 = v1010.Parent and (v1010.Parent.Name or "?") or "?"
							local v1023 = v1010.Name
							local v1024 = v1010.Text
							table.insert(v992, ("  cut (ellipsis) %s.%s %q"):format(v1022, v1023, v1024))
						end
						if v1010.TextSize < 10 then
							v1007 = v1007 + 1
						end
						local v1025 = v990(v1010)
						if v1025[3] <= v991[3] + 1 and v1025[1] >= v991[1] - 1 then
							continue
						end
						v993 = v993 + 1
						local v1026 = v1010.Name
						local v1027 = v1010.Text
						table.insert(v992, ("  OUTSIDE the modal: %s %q"):format(v1026, v1027))
					else
						if not v1010:IsA("GuiButton") then
							continue
						end
						v1004 = v1004 + 1
						local v1028 = v1010.AbsoluteSize.X
						local v1029 = v1010.AbsoluteSize.Y
						local v1030 = math.min(v1028, v1029)
						v1005 = math.min(v1005, v1030)
						if not v_u_13.isTouch() or v1030 >= 43.5 then
							continue
						end
						v993 = v993 + 1
						local v1031 = v1010.Parent and (v1010.Parent.Name or "?") or "?"
						local v1032 = v1010.Name
						local v1033 = v1010.AbsoluteSize.X
						local v1034 = v1010.AbsoluteSize.Y
						table.insert(v992, ("  TOUCH target %s.%s is %.0f x %.0f real px"):format(v1031, v1032, v1033, v1034))
					end
				end
				local v1035 = 0
				for _, v1036 in v_u_984:GetDescendants() do
					if not v1036:IsA("Frame") then
						continue
					end
					local v1037 = v1036.Name
					if string.sub(v1037, 1, 6) ~= "Mail_d" or not v988(v1036) then
						continue
					end
					local v1038 = {}
					for _, v1039 in v1036:GetChildren() do
						if not v1039:IsA("GuiObject") or (v1039.Name == "Edge" or (v1039.Name == "Dot" or not v1039.Visible)) then
							continue
						end
						local v1040 = { v1039.Name, (v990(v1039)) }
						table.insert(v1038, v1040)
					end
					for v1041 = 1, #v1038 do
						for v1042 = v1041 + 1, #v1038 do
							local v1043 = v1038[v1041][2]
							local v1044 = v1038[v1042][2]
							local v1045
							if v1043[1] < v1044[3] - 0.5 and (v1044[1] < v1043[3] - 0.5 and v1043[2] < v1044[4] - 0.5) then
								v1045 = v1044[2] < v1043[4] - 0.5
							else
								v1045 = false
							end
							if not v1045 then
								continue
							end
							v1035 = v1035 + 1
							local v1046 = v1036.Name
							local v1047 = v1038[v1041][1]
							local v1048 = v1038[v1042][1]
							table.insert(v992, ("  OVERLAP in %s: %s and %s"):format(v1046, v1047, v1048))
						end
					end
					local v1049 = v990(v1036)
					for _, v1050 in v1038 do
						if v1050[2][4] <= v1049[4] + 0.5 and v1050[2][3] <= v1049[3] + 0.5 then
							continue
						end
						v1035 = v1035 + 1
						local v1051 = v1036.Name
						local v1052 = v1050[1]
						table.insert(v992, ("  OUT OF ROW %s: %s"):format(v1051, v1052))
					end
				end
				local v1053 = v993 + (v1008 + v1035)
				local v1054 = v_u_13.isTouch
				local v1055 = tostring(v1054())
				table.insert(v992, 1, ("VERDICT problems=%d (clipped=%d overlaps=%d) labels=%d cut=%d tiny=%d buttons=%d minButton=%.0f real px touch=%s"):format(v1053, v1008, v1035, v1006, v1009, v1007, v1004, v1005, v1055))
				return table.concat(v992, "\n")
			end)
			v819.command("mail.state", function()
				-- upvalues: (ref) v_u_4, (ref) v_u_15, (copy) p_u_818
				local v1056 = v_u_4.mailLive()
				local v1057 = {}
				if v1056 then
					local v1058 = #v1056.rows
					local v1059 = v1056.ready
					local v1060 = v1056.pending
					local v1061 = v1056.waiting
					local v1062 = v1056.bm
					local v1063 = v1056.store
					local v1064 = v1056.bmMax
					local v1065 = v1056.bmDays
					local v1066 = v1056.expired
					local v1067 = v1056.showDeliveries
					local v1068 = tostring(v1067)
					table.insert(v1057, ("rows ins=%d ready=%d pending=%d deliveries=%d bm=%d store=%d bmMax=%d bmDays=%d expiredPending=%d show=%s"):format(v1058, v1059, v1060, v1061, v1062, v1063, v1064, v1065, v1066, v1068))
					for _, v1069 in v1056.deliveries do
						local v1070 = "  %s %s %q items=%d left=%s %q %s"
						local v1071 = v1069.id
						local v1072 = v1069.src
						local v1073 = v1069.title
						local v1074 = v1069.kinds
						local v1075 = v1069.left
						if v1075 then
							local v1076 = v1069.left
							v1075 = math.floor(v1076)
						end
						local v1077 = tostring(v1075)
						local v1078 = v1069.text
						local v1079 = v1069.level
						table.insert(v1057, v1070:format(v1071, v1072, v1073, v1074, v1077, v1078, v1079))
					end
				else
					table.insert(v1057, "mail data=none")
				end
				local v1080 = v_u_15.rail and v_u_15.rail.cards
				if v1080 then
					v1080 = v_u_15.rail.cards.mail
				end
				local v1081 = "card badge=%s pulse=%s flagged=%s seen=%d tips=%s/%s switch=%s"
				local v1082
				if v1080 then
					v1082 = v1080.badge()
				else
					v1082 = v1080
				end
				local v1083 = tostring(v1082)
				if v1080 then
					v1080 = v1080.pulsing()
				end
				local v1084 = tostring(v1080)
				local v1085 = v_u_15.flagged
				local v1086 = tostring(v1085)
				local v1087 = v1057
				local v1088 = 0
				for _ in v_u_15.seen do
					v1088 = v1088 + 1
				end
				local v1089 = v_u_15.tips.mailStore == true
				local v1090 = tostring(v1089)
				local v1091 = v_u_15.tips.mailBm == true
				local v1092 = tostring(v1091)
				local v1093 = v_u_15.switchOn
				local v1094 = tostring(v1093)
				table.insert(v1087, v1081:format(v1083, v1084, v1086, v1088, v1090, v1092, v1094))
				local v_u_1095 = p_u_818
				local v_u_1096 = "MailGuide"
				local v1097, v1098 = pcall(function()
					-- upvalues: (copy) v_u_1095, (copy) v_u_1096
					return v_u_1095.cctx.lib[v_u_1096]
				end)
				if not v1097 or type(v1098) ~= "table" then
					v1098 = nil
				end
				if v1098 then
					local v1099 = v1098.state()
					local v1100 = v1099.open
					local v1101 = tostring(v1100)
					local v1102 = v1099.queued
					table.insert(v1057, ("guide open=%s queued=%d"):format(v1101, v1102))
				end
				return table.concat(v1057, "\n")
			end)
			v819.command("rail.soon", function(p1103)
				-- upvalues: (ref) v_u_15, (ref) v_u_4
				-- block 21
				local v1104 = v_u_15.stub.mail
				local v1105 = p1103[1]
				local v1106 = tonumber(v1105)
				if not (v1104 and (v1104.data and v1106)) then
					return "usage: rail.soon <seconds> [id] (needs rail.stub mail <n>)"
				end
				local v1107 = v_u_4.serverNow()
				local v1108, v1109, v1110
				-- GenericForInit
v1108, v1109, v1110 = v1104.data.entries, nil, nil
[internal control] = v1110
-- end GenericForInit
				local v1111, v1112
				-- GenericForNext
v1111, v1112 = v1108(v1109, [internal control])
if v1111 ~= nil
[internal control] = v1111
-- end GenericForNext
				::l5::
				if v1112.kind == "delivery" and (p1103[2] ~= nil and v1112.id == p1103[2]) then
					v1112.exp = v1107 + v1106
					v1112.expLeft = v1106
					return ("%s expires in %d s"):format(v1112.id, v1106)
				end
				if v1112.kind == "delivery" then
					continue
				end
				if p1103[2] ~= nil then
					if p1103[2] == nil or v1112.id ~= p1103[2] then
						continue
					end
					v1112.readyAt = math.floor(v1107) + v1106
					return ("%s arrives in %d s"):format(v1112.id, v1106)
				end
				local v1113 = v1112.readyAt
				local v1114 = tonumber(v1113)
				if v1107 < ((v1114 == nil or v1114 ~= v1114) and 0 or v1114) then
					v1112.readyAt = math.floor(v1107) + v1106
					return ("%s arrives in %d s"):format(v1112.id, v1106)
				end
				if p1103[2] == nil or v1112.id ~= p1103[2] then
					continue
				end
				v1112.readyAt = math.floor(v1107) + v1106
				return ("%s arrives in %d s"):format(v1112.id, v1106)
				-- block 12
				goto l20
				-- block 13
				goto l5
				::l20::
				return "no such pending entry"
			end)
			v819.command("rail.claim", function(p1115)
				-- upvalues: (ref) v_u_4, (copy) p_u_818
				local v1116 = p1115[1] or ""
				local v1117 = tostring(v1116)
				if v1117 == "" then
					return "usage: rail.claim <id|all>"
				elseif v_u_4.stubActive("mail") then
					v_u_4.stubClaim(p_u_818, v1117)
					return "stub claim " .. v1117
				else
					local v1118 = p_u_818.op(v1117 == "all" and {
						["op"] = "mailClaim",
						["all"] = true
					} or {
						["op"] = "mailClaim",
						["id"] = nil,
						["id"] = v1117
					})
					return "sent req " .. tostring(v1118)
				end
			end)
			v819.command("rail.vote", function(p1119)
				-- upvalues: (ref) v_u_4, (copy) p_u_818
				local v1120 = p1119[1] or ""
				local v1121 = tostring(v1120)
				local v1122 = p1119[2]
				local v1123 = tonumber(v1122) or p1119[2]
				if v1121 == "" or v1123 == nil then
					return "usage: rail.vote <pollId> <optionId>"
				elseif v_u_4.stubActive("votes") then
					v_u_4.stubVote(p_u_818, v1121, v1123)
					return "stub vote " .. v1121
				else
					local v1124 = p_u_818.op({
						["op"] = "voteCast",
						["poll"] = nil,
						["option"] = nil,
						["poll"] = v1121,
						["option"] = v1123
					})
					return "sent req " .. tostring(v1124)
				end
			end)
			v819.command("rail.fetch", function()
				-- upvalues: (ref) v_u_4, (copy) p_u_818
				v_u_4.fetch(p_u_818, "mail", {
					["force"] = true,
					["refresh"] = true
				})
				v_u_4.fetch(p_u_818, "votes", {
					["force"] = true
				})
				return "fetching"
			end)
		end
	end
end
return v_u_4