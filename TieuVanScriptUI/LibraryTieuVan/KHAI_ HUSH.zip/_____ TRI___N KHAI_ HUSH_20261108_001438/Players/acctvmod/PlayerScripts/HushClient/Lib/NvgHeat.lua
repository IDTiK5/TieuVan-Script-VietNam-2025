-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / NvgHeat

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent:WaitForChild("VisionIndex"))
local v_u_4 = require(script.Parent:WaitForChild("NvgLogic"))
local v_u_5 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("NightVisionRules"))
local v_u_6 = {}
local v_u_7 = CFrame.new(0, -5000, 0)
local v_u_8 = {
	["on"] = false,
	["blend"] = 0,
	["cone"] = nil
}
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = false
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = 0
local v_u_15 = {}
local v_u_16 = 0
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = 0
local v_u_21 = 0
local v_u_22 = 0
local v_u_23 = 0
local v_u_24 = false
local v_u_25 = RaycastParams.new()
v_u_25.FilterType = Enum.RaycastFilterType.Include
v_u_25.IgnoreWater = true
v_u_25.RespectCanCollide = false
local function v_u_30() -- name: ensureFolder
	-- upvalues: (ref) v_u_10, (copy) v_u_9
	local v26 = v_u_10
	if v26 and v26.Parent then
		return v26
	end
	for _, v27 in v_u_9 do
		v27.torso:Destroy()
		v27.head:Destroy()
	end
	table.clear(v_u_9)
	local v28 = workspace:FindFirstChild("HushLocal")
	if not v28 then
		v28 = Instance.new("Folder")
		v28.Name = "HushLocal"
		v28.Parent = workspace
	end
	local v29 = v28:FindFirstChild("NvgHeat")
	if not v29 then
		v29 = Instance.new("Folder")
		v29.Name = "NvgHeat"
		v29.Parent = v28
	end
	v_u_10 = v29
	return v_u_10
end
local function v_u_35(p31, p32, p33) -- name: newPart
	-- upvalues: (copy) v_u_7
	local v34 = Instance.new("Part")
	v34.Name = p32
	v34.Shape = p33
	v34.Size = Vector3.new(1, 1, 1)
	v34.Anchored = true
	v34.CanCollide = false
	v34.CanQuery = false
	v34.CanTouch = false
	v34.CastShadow = false
	v34.Material = Enum.Material.Neon
	v34.Color = Color3.fromRGB(255, 80, 20)
	v34.Transparency = 1
	v34.CFrame = v_u_7
	v34.Parent = p31
	return v34
end
local function v_u_40(p36) -- name: targetAt
	-- upvalues: (copy) v_u_9, (copy) v_u_30, (copy) v_u_35
	local v37 = v_u_9[p36]
	if v37 then
		return v37
	end
	local v38 = v_u_30()
	if not v38 then
		return nil
	end
	local v39 = {
		["torso"] = nil,
		["head"] = nil,
		["t"] = 1,
		["color"] = nil,
		["far"] = true,
		["tw"] = 0,
		["th"] = 0,
		["td"] = 0,
		["hd"] = 0,
		["torso"] = v_u_35(v38, "Torso", Enum.PartType.Block),
		["head"] = v_u_35(v38, "Head", Enum.PartType.Ball)
	}
	v_u_9[p36] = v39
	return v39
end
local function v_u_53(p41) -- name: los
	-- upvalues: (copy) v_u_4, (copy) v_u_17, (ref) v_u_14, (ref) v_u_12, (copy) v_u_25, (ref) v_u_21, (copy) v_u_3
	local v42 = v_u_4.losGet(v_u_17, p41.key, v_u_14)
	if v42 ~= nil then
		return v42
	end
	local v43 = v_u_12
	if not v43 then
		return false
	end
	local v44 = true
	if #v_u_25.FilterDescendantsInstances > 0 then
		local v45 = p41.x
		local v46 = p41.y
		local v47 = p41.z
		local v48 = Vector3.new(v45, v46, v47) - v43
		local v49 = v48.Magnitude
		local v50 = v49 <= 0.01 and Vector3.new(0, 0, 0) or v48 / v49
		local v51 = 0
		for _ = 1, 6 do
			local v52 = workspace:Raycast(v43 + v50 * v51, v50 * (v49 - v51), v_u_25)
			v_u_21 = v_u_21 + 1
			if v52 then
				if v_u_3.isBlocker(v52.Instance) then
					v44 = false
				else
					v51 = v51 + (v52.Distance + 0.05)
					if v49 > v51 then
						continue
					end
				end
			end
		end
	else
		v44 = false
	end
	v_u_4.losPut(v_u_17, p41.key, v_u_14, v44)
	return v44
end
local function v_u_54() -- name: newCand
	return {
		["kind"] = "",
		["key"] = 0,
		["d2"] = 0,
		["dist"] = 0,
		["x"] = 0,
		["y"] = 0,
		["z"] = 0,
		["yaw"] = 0,
		["tw"] = 0,
		["th"] = 0,
		["td"] = 0,
		["hx"] = 0,
		["hy"] = 0,
		["hz"] = 0,
		["hd"] = 0,
		["strength"] = 1,
		["r"] = 255,
		["g"] = 255,
		["b"] = 255
	}
end
local function v_u_66(p55) -- name: hideFrom
	-- upvalues: (copy) v_u_9, (copy) v_u_18, (copy) v_u_19, (copy) v_u_7
	for v56 = p55, #v_u_9 do
		local v57 = v_u_9[v56]
		if v57.t < 1 and v57.t ~= 1 then
			v57.t = 1
			v57.torso.Transparency = 1
			v57.head.Transparency = 1
		end
		if v57.far then
			continue
		end
		v57.far = true
		local v58 = v_u_18
		local v59 = v57.torso
		table.insert(v58, v59)
		local v60 = v_u_19
		local v61 = v_u_7
		table.insert(v60, v61)
		local v62 = v_u_18
		local v63 = v57.head
		table.insert(v62, v63)
		local v64 = v_u_19
		local v65 = v_u_7
		table.insert(v64, v65)
	end
end
function v_u_6.configure(p67, p68, p69) -- name: configure
	-- upvalues: (copy) v_u_8
	v_u_8.on = p67 == true
	v_u_8.blend = type(p68) ~= "number" and 0 or p68
	v_u_8.cone = p69
end
function v_u_6.enabled() -- name: enabled
	-- upvalues: (copy) v_u_8, (ref) v_u_24
	local v70 = v_u_8.on
	if v70 then
		v70 = not v_u_24
	end
	return v70
end
local function v_u_80(p71, p72) -- name: beginImpl
	-- upvalues: (ref) v_u_14, (ref) v_u_16, (ref) v_u_11, (copy) v_u_8, (copy) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_22, (copy) v_u_25, (copy) v_u_6
	v_u_14 = p71
	v_u_16 = 0
	local v73 = v_u_11
	v_u_11 = false
	if v_u_8.on and (v_u_8.blend > 0.15 and p72) then
		local v74 = v_u_1.LocalPlayer
		local v75 = v74.Character
		if v74:GetAttribute("Place") == "Raid" and (v75 and v75:GetAttribute("Dead") ~= true) then
			v_u_11 = true
			v_u_12 = p72 + Vector3.new(0, 1.5, 0)
			v_u_13 = p72
		end
	end
	if v_u_11 and v_u_22 <= p71 then
		v_u_22 = p71 + 2
		local v76 = workspace:FindFirstChild("Raid")
		local v77 = {}
		if v76 then
			for _, v78 in { "Map", "Doors" } do
				local v79 = v76:FindFirstChild(v78)
				if not v79 then
					continue
				end
				table.insert(v77, v79)
			end
		end
		v_u_25.FilterDescendantsInstances = v77
	end
	if v73 and not v_u_11 then
		v_u_6.reset()
	end
	return v_u_11
end
function v_u_6.begin(p81, p82) -- name: begin
	-- upvalues: (ref) v_u_24, (copy) v_u_80
	if v_u_24 then
		return false
	end
	local v83 = v_u_80
	local v84, v85 = pcall(v83, p81, p82)
	if v84 then
		return v85 == true
	end
	if not v_u_24 then
		v_u_24 = true
		warn("[NvgHeat] " .. "begin" .. ": " .. tostring(v85))
	end
	return false
end
local function v_u_114(p86, p87) -- name: wantImpl
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (ref) v_u_16, (copy) v_u_15, (copy) v_u_54
	local v88, v89 = v_u_4.zombieHeat(p86.state, p86.dead)
	if v88 then
		local v90 = p86.def
		local v91 = v_u_4.zombieBody
		local v92
		if v90 then
			v92 = v90.height
		else
			v92 = nil
		end
		local v93
		if v90 then
			v93 = v90.headY
		else
			v93 = nil
		end
		local v94
		if v90 then
			v94 = v90.headR
		else
			v94 = nil
		end
		local v95, v96, v97, v98, v99, v100 = v91(v92, v93, v94, p86.state, p86.kind)
		local v101, v102 = v_u_5.heatTint("infected", v89)
		if v101 ~= nil then
			local v103 = p86.id
			v_u_16 = v_u_16 + 1
			local v104 = v_u_15[v_u_16]
			if not v104 then
				v104 = v_u_54()
				v_u_15[v_u_16] = v104
			end
			v104.kind = "infected"
			v104.key = v103
			v104.d2 = p87
			v104.dist = math.sqrt(p87)
			local v105 = p86.x
			local v106 = p86.y + v95
			local v107 = p86.z
			v104.x = v105
			v104.y = v106
			v104.z = v107
			v104.yaw = p86.ryaw or (p86.yaw or 0)
			v104.tw = v96
			v104.th = v97
			v104.td = v98
			local v108 = p86.x
			local v109 = p86.y + v99
			local v110 = p86.z
			v104.hx = v108
			v104.hy = v109
			v104.hz = v110
			v104.hd = v100
			v104.strength = v102
			local v111 = v101[1]
			local v112 = v101[2]
			local v113 = v101[3]
			v104.r = v111
			v104.g = v112
			v104.b = v113
		end
	else
		return
	end
end
function v_u_6.want(p115, p116, _) -- name: want
	-- upvalues: (ref) v_u_11, (ref) v_u_24, (copy) v_u_5, (copy) v_u_114
	if v_u_11 and not v_u_24 then
		local v117 = v_u_5.THERMAL_RANGE
		if v117 * v117 >= p116 then
			local v118 = v_u_114
			local v119, v120 = pcall(v118, p115, p116)
			if not (v119 or v_u_24) then
				v_u_24 = true
				warn("[NvgHeat] " .. "want" .. ": " .. tostring(v120))
			end
		end
	else
		return
	end
end
local function v_u_159() -- name: addPlayers
	-- upvalues: (copy) v_u_1, (ref) v_u_13, (copy) v_u_5, (copy) v_u_4, (ref) v_u_16, (copy) v_u_15, (copy) v_u_54
	local v121 = v_u_1.LocalPlayer
	local v122 = v_u_13
	if not v122 then
		return
	end
	local v123 = v_u_5.THERMAL_RANGE
	local v124, v125 = v_u_5.heatTint("player", false)
	if v124 == nil then
		return
	end
	local v126, v127, v128, v129, v130 = v_u_4.playerBody()
	for _, v131 in v_u_1:GetPlayers() do
		if v131 == v121 then
			continue
		end
		local v132 = v131.Character
		local v133
		if v132 then
			v133 = v132:FindFirstChild("HumanoidRootPart")
		else
			v133 = v132
		end
		if not (v132 and v133) then
			continue
		end
		local v134 = v132:FindFirstChildOfClass("Humanoid")
		if v132:GetAttribute("Dead") == true or v134 ~= nil and v134.Health <= 0 then
			continue
		end
		local v135 = v133.Position
		local v136 = v135.X - v122.X
		local v137 = v135.Z - v122.Z
		local v138 = v136 * v136 + v137 * v137
		if v123 * v123 < v138 then
			continue
		end
		local v139 = v131.UserId
		local v140 = "p" .. tostring(v139)
		v_u_16 = v_u_16 + 1
		local v141 = v_u_15[v_u_16]
		if not v141 then
			v141 = v_u_54()
			v_u_15[v_u_16] = v141
		end
		v141.kind = "player"
		v141.key = v140
		v141.d2 = v138
		v141.dist = math.sqrt(v138)
		local v142 = v135.X
		local v143 = v135.Y + v126
		local v144 = v135.Z
		v141.x = v142
		v141.y = v143
		v141.z = v144
		local v145 = v133.CFrame.LookVector
		local v146 = -v145.X
		local v147 = -v145.Z
		v141.yaw = math.atan2(v146, v147)
		v141.tw = v127
		v141.th = v128
		v141.td = v129
		local v148 = v132:FindFirstChild("Head")
		local v149, v150, v151, v152, v153, v154
		if v148 and v148:IsA("BasePart") then
			local v155 = v148.Position.Y - v135.Y
			if math.abs(v155) < 6 then
				local v156 = v148.Position.X
				local v157 = v148.Position.Y
				local v158 = v148.Position.Z
				v141.hx = v156
				v141.hy = v157
				v141.hz = v158
				v141.hd = v130
				v141.strength = v125
				v149 = v124[1]
				v150 = v124[2]
				v151 = v124[3]
				v141.r = v149
				v141.g = v150
				v141.b = v151
			else
				v152 = v135.X
				v153 = v135.Y + 2.4
				v154 = v135.Z
				v141.hx = v152
				v141.hy = v153
				v141.hz = v154
				v141.hd = v130
				v141.strength = v125
				v149 = v124[1]
				v150 = v124[2]
				v151 = v124[3]
				v141.r = v149
				v141.g = v150
				v141.b = v151
			end
		else
			v152 = v135.X
			v153 = v135.Y + 2.4
			v154 = v135.Z
			v141.hx = v152
			v141.hy = v153
			v141.hz = v154
			v141.hd = v130
			v141.strength = v125
			v149 = v124[1]
			v150 = v124[2]
			v151 = v124[3]
			v141.r = v149
			v141.g = v150
			v141.b = v151
		end
	end
end
local function v_u_187(p160, p161) -- name: placeTarget
	-- upvalues: (copy) v_u_40, (copy) v_u_4, (copy) v_u_8, (copy) v_u_18, (copy) v_u_19
	local v162 = v_u_40(p160)
	if v162 then
		if v162.tw ~= p161.tw or (v162.th ~= p161.th or v162.td ~= p161.td) then
			local v163 = p161.tw
			local v164 = p161.th
			local v165 = p161.td
			v162.tw = v163
			v162.th = v164
			v162.td = v165
			local v166 = v162.torso
			local v167 = p161.tw
			local v168 = p161.th
			local v169 = p161.td
			v166.Size = Vector3.new(v167, v168, v169)
		end
		if v162.hd ~= p161.hd then
			v162.hd = p161.hd
			local v170 = v162.head
			local v171 = p161.hd
			local v172 = p161.hd
			local v173 = p161.hd
			v170.Size = Vector3.new(v171, v172, v173)
		end
		local v174 = Color3.fromRGB(p161.r, p161.g, p161.b)
		if v162.color ~= v174 then
			v162.color = v174
			v162.torso.Color = v174
			v162.head.Color = v174
		end
		local v175 = v_u_4.transparency(p161.strength, v_u_8.blend)
		if v175 ~= v162.t then
			v162.t = v175
			v162.torso.Transparency = v175
			v162.head.Transparency = v175
		end
		v162.far = false
		local v176 = v_u_18
		local v177 = v162.torso
		table.insert(v176, v177)
		local v178 = v_u_19
		local v179 = CFrame.new(p161.x, p161.y, p161.z) * CFrame.Angles(0, p161.yaw, 0)
		table.insert(v178, v179)
		local v180 = v_u_18
		local v181 = v162.head
		table.insert(v180, v181)
		local v182 = v_u_19
		local v183 = CFrame.new
		local v184 = p161.hx
		local v185 = p161.hy
		local v186 = p161.hz
		table.insert(v182, v183(v184, v185, v186))
	end
end
local function v_u_195(p188) -- name: judgeCand
	-- upvalues: (copy) v_u_53, (copy) v_u_8, (copy) v_u_5
	local v189 = v_u_53(p188)
	local v190 = v_u_8.cone
	local v191
	if v190 == nil or not v189 then
		v191 = nil
	else
		local v192 = p188.x
		local v193 = p188.y
		local v194 = p188.z
		v191 = v190((Vector3.new(v192, v193, v194)))
	end
	return v_u_5.heatWanted(p188.dist, v189, v191, false, true)
end
local function v_u_197() -- name: finishImpl
	-- upvalues: (copy) v_u_18, (copy) v_u_19, (ref) v_u_11, (copy) v_u_159, (copy) v_u_4, (copy) v_u_15, (ref) v_u_16, (copy) v_u_5, (copy) v_u_195, (copy) v_u_187, (ref) v_u_14, (ref) v_u_23, (copy) v_u_17, (ref) v_u_20, (copy) v_u_66
	table.clear(v_u_18)
	table.clear(v_u_19)
	local v196
	if v_u_11 then
		v_u_159()
		v_u_4.sortNearest(v_u_15, v_u_16)
		v196 = v_u_4.pick(v_u_15, v_u_16, v_u_5.HEAT_MAX, v_u_4.JUDGE_MAX, v_u_195, v_u_187)
		if v_u_23 <= v_u_14 then
			v_u_23 = v_u_14 + 2
			v_u_4.losPrune(v_u_17, v_u_14)
		end
	else
		v196 = 0
	end
	if v196 < v_u_20 or not v_u_11 then
		v_u_66(v196 + 1)
	end
	v_u_20 = v196
	if #v_u_18 > 0 then
		workspace:BulkMoveTo(v_u_18, v_u_19, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
function v_u_6.finish(_) -- name: finish
	-- upvalues: (ref) v_u_24, (copy) v_u_197
	if not v_u_24 then
		local v198 = v_u_197
		local v199, v200 = pcall(v198)
		if not (v199 or v_u_24) then
			v_u_24 = true
			warn("[NvgHeat] " .. "finish" .. ": " .. tostring(v200))
		end
	end
end
function v_u_6.reset() -- name: reset
	-- upvalues: (ref) v_u_16, (ref) v_u_20, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19, (copy) v_u_9, (copy) v_u_7
	v_u_16 = 0
	v_u_20 = 0
	table.clear(v_u_17)
	table.clear(v_u_18)
	table.clear(v_u_19)
	for _, v201 in v_u_9 do
		if not v201.torso.Parent then
			continue
		end
		if v201.t ~= 1 then
			v201.t = 1
			v201.torso.Transparency = 1
			v201.head.Transparency = 1
		end
		v201.torso.CFrame = v_u_7
		v201.head.CFrame = v_u_7
		v201.far = true
	end
end
function v_u_6.stats() -- name: stats
	-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_20, (copy) v_u_5, (ref) v_u_21, (copy) v_u_9, (ref) v_u_24, (copy) v_u_8
	return {
		["active"] = v_u_11,
		["candidates"] = v_u_16,
		["shown"] = v_u_20,
		["parts"] = v_u_20 * v_u_5.HEAT_PARTS,
		["los"] = v_u_21,
		["pool"] = #v_u_9,
		["broken"] = v_u_24,
		["on"] = v_u_8.on,
		["blend"] = v_u_8.blend
	}
end
return v_u_6