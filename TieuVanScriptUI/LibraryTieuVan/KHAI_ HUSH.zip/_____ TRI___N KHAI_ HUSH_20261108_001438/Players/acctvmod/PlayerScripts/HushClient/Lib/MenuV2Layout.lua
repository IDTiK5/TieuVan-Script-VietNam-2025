-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuV2Layout

local v_u_5 = {
	["ROW_GAP"] = 4,
	["CASH_H"] = 36,
	["CASH_H_PHONE"] = 32,
	["DEPLOY_MIN_H_PHONE"] = 88,
	["DEPLOY_MIN_H"] = 120,
	["CLOCK_H_PHONE"] = 28,
	["CLOCK_H"] = 32,
	["CLOCK_GAP"] = 4,
	["INVITE_W_PHONE"] = 84,
	["INVITE_W"] = 110,
	["CARDS_MAX_H"] = 260,
	["BACK_W_PHONE"] = 104,
	["BACK_W"] = 128,
	["HEADER_MIN_H"] = 48,
	["CASH_W_PHONE"] = 150,
	["CASH_W"] = 200,
	["SUB_W_MAX"] = 200,
	["HIDEOUT_COUNT"] = 10,
	["rowH"] = function(p1, p2) -- name: rowH
		local v3 = tonumber(p1) or 44
		local v4 = p2 == true and 56 or 48
		return math.max(v3, v4)
	end
}
local function v_u_15(p6, p7, p8) -- name: fitRows
	-- upvalues: (copy) v_u_5
	local v9 = (p6.h + v_u_5.ROW_GAP) / (p7 + v_u_5.ROW_GAP)
	local v10 = math.floor(v9)
	local v11 = math.max(0, v10)
	local v12 = {}
	for v13 = 1, math.min(p8, v11) do
		local v14 = {
			["x"] = p6.x,
			["y"] = p6.y + (v13 - 1) * (p7 + v_u_5.ROW_GAP),
			["w"] = p6.w,
			["h"] = p7
		}
		table.insert(v12, v14)
	end
	return v12, v11 < p8
end
function v_u_5.home(p16, p17) -- name: home
	-- upvalues: (copy) v_u_5, (copy) v_u_15
	local v18 = 1280
	local v19 = 720
	if p16 ~= nil then
		local v20 = p16.X
		v18 = tonumber(v20) or v18
		local v21 = p16.Y
		v19 = tonumber(v21) or v19
	end
	local v22
	if p17 == nil then
		v22 = false
	else
		v22 = p17.phone == true
	end
	local v23 = 44
	if p17 ~= nil then
		local v24 = p17.touch
		if tonumber(v24) ~= nil then
			local v25 = p17.touch
			local v26 = tonumber(v25)
			local v27 = math.ceil(v26)
			v23 = math.max(1, v27)
		end
	end
	local v_u_28, v29
	if v22 then
		v_u_28 = 8
		v29 = 12
	else
		v_u_28 = 12
		v29 = 24
	end
	local v_u_30
	if v22 then
		v_u_30 = v23
	else
		v_u_30 = math.max(v23, 52)
	end
	local v31 = 0
	local v32
	if p17 then
		v32 = p17.count
	else
		v32 = p17
	end
	local v33 = tonumber(v32) or 0
	local v34 = math.floor(v33)
	local v35 = math.max(v31, v34)
	local v36
	if p17 then
		v36 = p17.partySlots
	else
		v36 = p17
	end
	local v37 = tonumber(v36) or 4
	local v38 = math.floor(v37)
	local v39 = math.min(4, v38)
	local v40 = math.max(1, v39)
	local v41
	if p17 then
		v41 = p17.notes
	else
		v41 = p17
	end
	local v42 = tonumber(v41) or 0
	local v43 = math.floor(v42)
	local v44 = math.min(3, v43)
	local v_u_45 = math.max(0, v44)
	local v46
	if p17 == nil then
		v46 = false
	else
		v46 = p17.cards == true
	end
	local v47 = v_u_5.rowH(v23, v22)
	local v48
	if v22 then
		v48 = v_u_5.CASH_H_PHONE
	else
		v48 = v_u_5.CASH_H
	end
	local v49 = v18 < v19
	local v50 = v18 - v29 * 2
	local v51, v52, v_u_53
	if v49 then
		v51 = v50
		v52 = v51
		v_u_53 = v29
		local v54 = v51
		v51 = v52
		v54 = v52
		v52 = v51
	else
		if v22 then
			local v55 = v18 * 0.29
			v51 = math.floor(v55)
			local v56 = v18 * 0.33
			v52 = math.floor(v56)
		else
			local v57 = v18 * 0.24
			local v58 = math.floor(v57)
			local v59 = math.min(380, v58)
			v51 = math.max(280, v59)
			local v60 = v18 * 0.22
			local v61 = math.floor(v60)
			local v62 = math.min(360, v61)
			v52 = math.max(260, v62)
		end
		v_u_53 = v18 - v29 - v52
	end
	local v63 = v23 * 2
	local v64
	if v22 then
		v64 = v_u_5.DEPLOY_MIN_H_PHONE
	else
		v64 = v_u_5.DEPLOY_MIN_H
	end
	local v65 = math.max(v63, v64)
	local v66 = {
		["x"] = v_u_53,
		["y"] = v19 - v29 - v65,
		["w"] = v52,
		["h"] = v65
	}
	local v67
	if v22 then
		v67 = v_u_5.CLOCK_H_PHONE
	else
		v67 = v_u_5.CLOCK_H
	end
	local v68 = {
		["x"] = v_u_53,
		["y"] = v66.y - v_u_5.CLOCK_GAP - v67,
		["w"] = v52,
		["h"] = v67
	}
	local v69
	if v22 then
		v69 = v_u_5.INVITE_W_PHONE
	else
		v69 = v_u_5.INVITE_W
	end
	local v70 = math.max(v23, v69)
	local v71 = {
		["x"] = v_u_53,
		["y"] = v29,
		["w"] = v52 - v70 - v_u_28,
		["h"] = v_u_30
	}
	local v72 = {
		["x"] = v_u_53 + v71.w + v_u_28,
		["y"] = v29,
		["w"] = v70,
		["h"] = v_u_30
	}
	local v73 = (v71.w - (v40 - 1) * 4) / v40
	local v74 = math.floor(v73)
	local v75 = v29
	local v76 = v75
	local v77 = v75
	v75 = v76
	v77 = v76
	local v78 = {}
	for v79 = 1, v40 do
		local v80 = {
			["x"] = v71.x + (v79 - 1) * (v74 + 4),
			["y"] = v71.y,
			["w"] = v74,
			["h"] = v71.h
		}
		table.insert(v78, v80)
	end
	local v81 = v29 + (v_u_30 + v_u_28)
	local v82 = (v52 - v_u_28) / 2
	local v83 = math.floor(v82)
	local v84 = {
		["pvp"] = {
			["x"] = v_u_53,
			["y"] = v81,
			["w"] = v83,
			["h"] = v_u_30
		},
		["view"] = {
			["x"] = v_u_53 + v83 + v_u_28,
			["y"] = v81,
			["w"] = v52 - v83 - v_u_28,
			["h"] = v_u_30
		}
	}
	local v85 = v81 + (v_u_30 + v_u_28)
	local v_u_86 = {}
	local v_u_87 = { "mail", "insure", "votes" }
	local v88 = (v52 - 2 * v_u_28) / 3
	local v_u_89 = math.floor(v88)
	local function v94(p90) -- name: placeNotes
		-- upvalues: (copy) v_u_45, (copy) v_u_86, (copy) v_u_87, (ref) v_u_53, (copy) v_u_89, (copy) v_u_28, (copy) v_u_30
		for v91 = 1, v_u_45 do
			local v92 = v_u_89
			local v93 = v_u_30
			v_u_86[v_u_87[v91]] = {
				["x"] = v_u_53 + (v91 - 1) * (v_u_89 + v_u_28),
				["y"] = p90,
				["w"] = v92,
				["h"] = v93
			}
		end
	end
	local v95, v96, v97, v98, v99
	if v49 then
		v95 = {
			["x"] = v76,
			["y"] = v85,
			["w"] = v50,
			["h"] = v48
		}
		v96 = v85 + v48 + v_u_28
		local v100 = v68.y
		if v_u_45 > 0 then
			v94(v68.y - v_u_28 - v_u_30)
			v100 = v68.y - v_u_28 - v_u_30
		end
		v97 = v100 - v_u_28
		v98 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 0,
			["h"] = 0,
			["x"] = v_u_53,
			["y"] = v85
		}
		v99 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 0,
			["h"] = 0,
			["x"] = v76,
			["y"] = v76
		}
	else
		if v_u_45 > 0 then
			v94(v85)
			v85 = v85 + (v_u_30 + v_u_28)
		end
		local v101 = v68.y - v_u_28 - v85
		local v102 = v_u_5.CARDS_MAX_H
		local v103 = math.min(v101, v102)
		v98 = v46 and v23 <= v103 and {
			["x"] = v_u_53,
			["y"] = v85,
			["w"] = v52,
			["h"] = v103
		} or {
			["x"] = nil,
			["y"] = nil,
			["w"] = 0,
			["h"] = 0,
			["x"] = v_u_53,
			["y"] = v85
		}
		v95 = {
			["x"] = v75,
			["y"] = v76,
			["w"] = v51,
			["h"] = v48
		}
		local v104 = v76 + v48 + v_u_28
		local v105 = 0
		if p17 then
			p17 = p17.topClear
		end
		local v106 = tonumber(p17) or 0
		local v107 = math.max(v105, v106)
		v96 = math.max(v104, v107)
		v97 = v19 - v76
		local v108 = v75 + v51 + v_u_28
		local v109 = v_u_53 - v_u_28 - v108
		v99 = {
			["x"] = v108,
			["y"] = v76,
			["w"] = math.max(0, v109),
			["h"] = v19 - v76 * 2
		}
	end
	local v110 = v97 - v96
	local v111 = {
		["x"] = v75,
		["y"] = v96,
		["w"] = v51,
		["h"] = math.max(0, v110)
	}
	local v112, v113 = v_u_15(v111, v47, v35)
	return {
		["list"] = v111,
		["rows"] = v112,
		["listScroll"] = v113,
		["deploy"] = v66,
		["clock"] = v68,
		["party"] = v71,
		["slots"] = v78,
		["invite"] = v72,
		["chips"] = v84,
		["notes"] = v_u_86,
		["cards"] = v98,
		["stage"] = v99,
		["cash"] = v95,
		["rowH"] = v47,
		["portrait"] = v49
	}
end
function v_u_5.page(p114, p115) -- name: page
	-- upvalues: (copy) v_u_5
	local v116 = 1280
	local v117 = 720
	if p114 ~= nil then
		local v118 = p114.X
		v116 = tonumber(v118) or v116
		local v119 = p114.Y
		v117 = tonumber(v119) or v117
	end
	local v120
	if p115 == nil then
		v120 = false
	else
		v120 = p115.phone == true
	end
	local v121 = 44
	if p115 ~= nil then
		local v122 = p115.touch
		if tonumber(v122) ~= nil then
			local v123 = p115.touch
			local v124 = tonumber(v123)
			local v125 = math.ceil(v124)
			v121 = math.max(1, v125)
		end
	end
	local v126, v127
	if v120 then
		v126 = 12
		v127 = 8
	else
		v126 = 24
		v127 = 12
	end
	local v128 = v116 - v126 * 2
	local v129 = v_u_5.HEADER_MIN_H
	local v130 = math.max(v121, v129)
	local v131 = {
		["x"] = v126,
		["y"] = v126,
		["w"] = v128,
		["h"] = v130
	}
	local v132
	if v120 then
		v132 = v_u_5.BACK_W_PHONE
	else
		v132 = v_u_5.BACK_W
	end
	local v133 = math.max(v121, v132)
	local v134 = {
		["x"] = v131.x,
		["y"] = v131.y,
		["w"] = v133,
		["h"] = v130
	}
	local v135
	if v120 then
		v135 = v_u_5.CASH_W_PHONE
	else
		v135 = v_u_5.CASH_W
	end
	local v136 = {
		["x"] = v131.x + v131.w - v135,
		["y"] = v131.y,
		["w"] = v135,
		["h"] = v130
	}
	local v137 = v134.x + v134.w + v127
	local v138 = v131.y
	local v139 = v136.x - v127 - v137
	local v140 = {
		["x"] = v137,
		["y"] = v138,
		["w"] = math.max(0, v139),
		["h"] = v130
	}
	local v141 = v131.y + v130 + v127
	local v142 = nil
	local v143 = {}
	local v144 = false
	local v145 = 0
	if p115 then
		p115 = p115.subs
	end
	local v146 = tonumber(p115) or 0
	local v147 = math.floor(v146)
	local v148 = math.max(v145, v147)
	if v148 > 0 then
		local v149 = math.max(v121, 44)
		local v150 = {
			["x"] = v126,
			["y"] = v141,
			["w"] = v128,
			["h"] = v149
		}
		local v151 = v_u_5.SUB_W_MAX
		local v152 = (v128 - (v148 - 1) * v127) / v148
		local v153 = math.floor(v152)
		local v154 = math.min(v151, v153)
		local v155 = math.max(v121, v154)
		local v156 = (v128 + v127) / (v155 + v127)
		local v157 = math.floor(v156)
		local v158 = math.max(1, v157)
		v144 = v158 < v148
		v142 = v150
		for v159 = 1, math.min(v148, v158) do
			local v160 = {
				["x"] = v150.x + (v159 - 1) * (v155 + v127),
				["y"] = v150.y,
				["w"] = v155,
				["h"] = v149
			}
			table.insert(v143, v160)
		end
		v141 = v141 + (v149 + v127)
	end
	local v161 = v117 - v126 - v141
	return {
		["header"] = v131,
		["back"] = v134,
		["title"] = v140,
		["cash"] = v136,
		["subs"] = v142,
		["subChips"] = v143,
		["subsScroll"] = v144,
		["body"] = {
			["x"] = v126,
			["y"] = v141,
			["w"] = v128,
			["h"] = math.max(0, v161)
		}
	}
end
function v_u_5.hideoutList(p162, p163) -- name: hideoutList
	-- upvalues: (copy) v_u_5, (copy) v_u_15
	local v164 = 1280
	local v165 = 720
	if p162 ~= nil then
		local v166 = p162.X
		v164 = tonumber(v166) or v164
		local v167 = p162.Y
		v165 = tonumber(v167) or v165
	end
	local v168
	if p163 == nil then
		v168 = false
	else
		v168 = p163.phone == true
	end
	local v169 = 44
	if p163 ~= nil then
		local v170 = p163.touch
		if tonumber(v170) ~= nil then
			local v171 = p163.touch
			local v172 = tonumber(v171)
			local v173 = math.ceil(v172)
			v169 = math.max(1, v173)
		end
	end
	local v174 = v168 and 8 or 12
	local v175, v176, v177, v178, v179, v180, v181, v182, v183, v184, v185, v186, v187, v188, v189, v190, v191, v192, v193, v194, v195, v196, v197, v198
	if p163 == nil then
		v175 = v_u_5.page(p162, {
			["touch"] = nil,
			["phone"] = nil,
			["subs"] = 0,
			["touch"] = v169,
			["phone"] = v168
		}).body
		v176 = 0
		if p163 then
			p163 = p163.count
		end
		v177 = tonumber(p163) or v_u_5.HIDEOUT_COUNT
		v178 = math.floor(v177)
		v179 = math.max(v176, v178)
		v180 = v_u_5.rowH(v169, v168)
		if v164 < v165 then
			v181 = v175.h * 0.42
			v182 = math.floor(v181)
			v183 = {
				["x"] = v175.x,
				["y"] = v175.y,
				["w"] = v175.w,
				["h"] = v182
			}
			v184 = v175.x
			v185 = v175.y + v182 + v174
			v186 = v175.w
			v187 = v175.h - v182 - v174
			v188 = {
				["x"] = v184,
				["y"] = v185,
				["w"] = v186,
				["h"] = math.max(0, v187)
			}
		else
			if v168 then
				v189 = v175.w * 0.3
				v190 = math.floor(v189)
			else
				v191 = v175.w * 0.26
				v192 = math.floor(v191)
				v193 = math.min(380, v192)
				v190 = math.max(260, v193)
			end
			v183 = {
				["x"] = v175.x,
				["y"] = v175.y,
				["w"] = v190,
				["h"] = v175.h
			}
			v194 = v175.x + v190 + v174
			v195 = v175.y
			v196 = v175.w - v190 - v174
			v188 = {
				["x"] = v194,
				["y"] = v195,
				["w"] = math.max(0, v196),
				["h"] = v175.h
			}
		end
		v197, v198 = v_u_15(v183, v180, v179)
		return {
			["list"] = v183,
			["rows"] = v197,
			["listScroll"] = v198,
			["panel"] = v188,
			["body"] = v175
		}
	else
		local v199 = p163.body
		if type(v199) == "table" then
			v175 = {
				["x"] = p163.body.x,
				["y"] = p163.body.y,
				["w"] = p163.body.w,
				["h"] = p163.body.h
			}
			v176 = 0
			if p163 then
				p163 = p163.count
			end
			v177 = tonumber(p163) or v_u_5.HIDEOUT_COUNT
			v178 = math.floor(v177)
			v179 = math.max(v176, v178)
			v180 = v_u_5.rowH(v169, v168)
			if v164 < v165 then
				v181 = v175.h * 0.42
				v182 = math.floor(v181)
				v183 = {
					["x"] = v175.x,
					["y"] = v175.y,
					["w"] = v175.w,
					["h"] = v182
				}
				v184 = v175.x
				v185 = v175.y + v182 + v174
				v186 = v175.w
				v187 = v175.h - v182 - v174
				v188 = {
					["x"] = v184,
					["y"] = v185,
					["w"] = v186,
					["h"] = math.max(0, v187)
				}
			else
				if v168 then
					v189 = v175.w * 0.3
					v190 = math.floor(v189)
				else
					v191 = v175.w * 0.26
					v192 = math.floor(v191)
					v193 = math.min(380, v192)
					v190 = math.max(260, v193)
				end
				v183 = {
					["x"] = v175.x,
					["y"] = v175.y,
					["w"] = v190,
					["h"] = v175.h
				}
				v194 = v175.x + v190 + v174
				v195 = v175.y
				v196 = v175.w - v190 - v174
				v188 = {
					["x"] = v194,
					["y"] = v195,
					["w"] = math.max(0, v196),
					["h"] = v175.h
				}
			end
			v197, v198 = v_u_15(v183, v180, v179)
			return {
				["list"] = v183,
				["rows"] = v197,
				["listScroll"] = v198,
				["panel"] = v188,
				["body"] = v175
			}
		else
			v175 = v_u_5.page(p162, {
				["touch"] = nil,
				["phone"] = nil,
				["subs"] = 0,
				["touch"] = v169,
				["phone"] = v168
			}).body
			v176 = 0
			if p163 then
				p163 = p163.count
			end
			v177 = tonumber(p163) or v_u_5.HIDEOUT_COUNT
			v178 = math.floor(v177)
			v179 = math.max(v176, v178)
			v180 = v_u_5.rowH(v169, v168)
			if v164 < v165 then
				v181 = v175.h * 0.42
				v182 = math.floor(v181)
				v183 = {
					["x"] = v175.x,
					["y"] = v175.y,
					["w"] = v175.w,
					["h"] = v182
				}
				v184 = v175.x
				v185 = v175.y + v182 + v174
				v186 = v175.w
				v187 = v175.h - v182 - v174
				v188 = {
					["x"] = v184,
					["y"] = v185,
					["w"] = v186,
					["h"] = math.max(0, v187)
				}
			else
				if v168 then
					v189 = v175.w * 0.3
					v190 = math.floor(v189)
				else
					v191 = v175.w * 0.26
					v192 = math.floor(v191)
					v193 = math.min(380, v192)
					v190 = math.max(260, v193)
				end
				v183 = {
					["x"] = v175.x,
					["y"] = v175.y,
					["w"] = v190,
					["h"] = v175.h
				}
				v194 = v175.x + v190 + v174
				v195 = v175.y
				v196 = v175.w - v190 - v174
				v188 = {
					["x"] = v194,
					["y"] = v195,
					["w"] = math.max(0, v196),
					["h"] = v175.h
				}
			end
			v197, v198 = v_u_15(v183, v180, v179)
			return {
				["list"] = v183,
				["rows"] = v197,
				["listScroll"] = v198,
				["panel"] = v188,
				["body"] = v175
			}
		end
	end
end
return v_u_5