-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / BreakablePredict

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {
	["VERSION"] = 1,
	["onSound"] = nil
}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = {}
local v_u_8 = -1000000000
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = {
	["predicted"] = 0,
	["restored"] = 0,
	["scans"] = 0
}
local function v_u_15(p12) -- name: partsOf
	local v13 = {}
	if p12:IsA("BasePart") then
		table.insert(v13, p12)
	end
	for _, v14 in p12:GetDescendants() do
		if not v14:IsA("BasePart") then
			continue
		end
		table.insert(v13, v14)
	end
	return v13
end
local function v_u_20(p16, p17) -- name: restoreTilt
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	for _, v_u_18 in p17.parts do
		if v_u_18.part.Parent == nil or not v_u_18.part.Anchored then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_18
			v_u_18.part.CFrame = v_u_18.cf
		end)
	end
	v_u_7[p16] = nil
	local v19 = v_u_11
	v19.restored = v19.restored + 1
end
local function v_u_44(p21) -- name: scan
	-- upvalues: (ref) v_u_4, (copy) v_u_2, (copy) v_u_9, (copy) v_u_11
	local v22
	if v_u_4 == nil then
		local function v24()
			-- upvalues: (ref) v_u_2
			local v23 = v_u_2:WaitForChild("Hush", 2)
			if v23 then
				v23 = v23:WaitForChild("Shared", 2)
			end
			if v23 then
				v23 = require(v23:WaitForChild("BreakableRules", 2))
			end
			return v23
		end
		local v25, v26 = pcall(v24)
		if v25 and type(v26) == "table" then
			v_u_4 = v26
		end
		v22 = v_u_4
	else
		v22 = v_u_4
	end
	table.clear(v_u_9)
	local v27 = v_u_11
	v27.scans = v27.scans + 1
	local v28 = p21.Position
	local v29 = workspace:FindFirstChild("Raid")
	if v29 then
		v29 = v29:FindFirstChild("Map")
	end
	if v29 == nil then
		return
	end
	local v30 = OverlapParams.new()
	v30.FilterType = Enum.RaycastFilterType.Include
	v30.FilterDescendantsInstances = { v29 }
	local v31 = {}
	for _, v43 in workspace:GetPartBoundsInRadius(v28, 70, v30) do
		if v43 == nil or v43 == v29 then
			continue
		end
		local v33 = v22.kindOf(v43:GetAttribute("Breakable"))
		if v33 ~= nil then
			if v31[v43] then
				break
			end
			v31[v43] = true
			local v34, v35
			if v43:IsA("Model") then
				v34, v35 = v43:GetBoundingBox()
			else
				v34 = v43.CFrame
				v35 = v43.Size
			end
			local v36 = v34.LookVector
			local v37 = v36.X * v36.X + v36.Z * v36.Z
			local v38 = math.sqrt(v37)
			local v39, v40
			if v38 > 0.001 then
				v39 = v36.X / v38
				v40 = v36.Z / v38
			else
				v39 = 0
				v40 = -1
			end
			local v41 = v_u_9
			local v42 = {
				["inst"] = v43,
				["kind"] = v33,
				["box"] = {
					["x"] = v34.Position.X,
					["y"] = v34.Position.Y,
					["z"] = v34.Position.Z,
					["fx"] = v39,
					["fz"] = v40,
					["hx"] = v35.X / 2 + 0.2,
					["hz"] = v35.Z / 2 + 0.2,
					["hy"] = v35.Y / 2
				}
			}
			table.insert(v41, v42)
			break
		end
		local v43 = v43.Parent
		continue
	end
end
local function v_u_69(p45, p46, p47) -- name: tilt
	-- upvalues: (copy) v_u_7, (copy) v_u_15, (copy) v_u_11, (copy) v_u_3, (ref) v_u_4, (copy) v_u_2
	local v48 = p45.inst
	if v_u_7[v48] == nil and v48.Parent ~= nil then
		local v49 = v_u_15(v48)
		local v50 = {
			["parts"] = {},
			["t0"] = os.clock(),
			["kind"] = p45.kind,
			["ax"] = p46,
			["az"] = p47
		}
		local v51 = p45.box.x
		local v52 = p45.box.y - p45.box.hy
		local v53 = p45.box.z
		v50.pivot = Vector3.new(v51, v52, v53)
		for _, v54 in v49 do
			if not v54.Anchored then
				continue
			end
			local v55 = v50.parts
			local v56 = {
				["part"] = v54,
				["cf"] = v54.CFrame
			}
			table.insert(v55, v56)
		end
		if #v50.parts ~= 0 then
			v_u_7[v48] = v50
			local v57 = v_u_11
			v57.predicted = v57.predicted + 1
			local v58 = v_u_3.onSound
			if type(v58) == "function" then
				local v59
				if v_u_4 == nil then
					local function v61()
						-- upvalues: (ref) v_u_2
						local v60 = v_u_2:WaitForChild("Hush", 2)
						if v60 then
							v60 = v60:WaitForChild("Shared", 2)
						end
						if v60 then
							v60 = require(v60:WaitForChild("BreakableRules", 2))
						end
						return v60
					end
					local v62, v63 = pcall(v61)
					if v62 and type(v63) == "table" then
						v_u_4 = v63
					end
					v59 = v_u_4
				else
					v59 = v_u_4
				end
				local v64 = v59.KINDS[p45.kind].fx
				local v65 = p45.box.x
				local v66 = p45.box.y
				local v67 = p45.box.z
				local v68 = Vector3.new(v65, v66, v67)
				pcall(v58, v64, v68)
			end
		end
	else
		return
	end
end
local function v_u_109() -- name: step
	-- upvalues: (ref) v_u_4, (copy) v_u_2, (ref) v_u_5, (ref) v_u_8, (copy) v_u_44, (ref) v_u_10, (copy) v_u_9, (copy) v_u_7, (copy) v_u_69, (copy) v_u_20
	local v70
	if v_u_4 == nil then
		local function v72()
			-- upvalues: (ref) v_u_2
			local v71 = v_u_2:WaitForChild("Hush", 2)
			if v71 then
				v71 = v71:WaitForChild("Shared", 2)
			end
			if v71 then
				v71 = require(v71:WaitForChild("BreakableRules", 2))
			end
			return v71
		end
		local v73, v74 = pcall(v72)
		if v73 and type(v74) == "table" then
			v_u_4 = v74
		end
		v70 = v_u_4
	else
		v70 = v_u_4
	end
	local v75 = v_u_5
	if v70 == nil or (v75 == nil or v75.Parent == nil) then
		return
	else
		local v76 = v75:FindFirstChild("Chassis")
		if v76 ~= nil and v76:IsA("BasePart") then
			local v77 = os.clock()
			if v77 - v_u_8 >= 0.5 then
				v_u_8 = v77
				v_u_44(v76)
			end
			local v78 = v76.CFrame
			local v79 = v78.LookVector
			local v80 = v79.X * v79.X + v79.Z * v79.Z
			local v81 = math.sqrt(v80)
			local v82, v83
			if v81 > 0.001 then
				v82 = v79.X / v81
				v83 = v79.Z / v81
			else
				v82 = 0
				v83 = -1
			end
			local v84 = v76.AssemblyLinearVelocity
			local v85 = v84.X * v84.X + v84.Z * v84.Z
			local v86 = math.sqrt(v85)
			local v87, v88
			if v86 > 0.5 then
				v87 = v84.X / v86
				v88 = v84.Z / v86
			else
				v88 = v83
				v87 = v82
			end
			local v89 = v76.Size
			local v90 = {
				["x"] = v78.Position.X,
				["y"] = v78.Position.Y,
				["z"] = v78.Position.Z,
				["fx"] = v82,
				["fz"] = v83,
				["hx"] = v89.X / 2,
				["hz"] = v89.Z / 2,
				["hy"] = v89.Y / 2,
				["dirx"] = v87,
				["dirz"] = v88
			}
			local v91 = v_u_10
			v_u_10 = v90
			if v70.TUNE.MIN_SPEED <= v86 then
				for _, v92 in v_u_9 do
					if v92.inst.Parent == nil or (v_u_7[v92.inst] ~= nil or not v70.sweptHit(v91, v90, v86 * v70.TUNE.AHEAD_S, v92.box)) then
						continue
					end
					v_u_69(v92, v87, v88)
				end
			end
			for v93, v94 in v_u_7 do
				local v95 = v77 - v94.t0
				local v96 = false
				for _, v97 in v94.parts do
					if v97.part.Parent == nil or v97.part.Anchored then
						continue
					end
					v96 = true
				end
				if v93.Parent == nil or (v96 or v70.TUNE.PREDICT_HOLD_S < v95) then
					if v96 or v93.Parent == nil then
						v_u_7[v93] = nil
					else
						v_u_20(v93, v94)
					end
				else
					local v98 = v95 / v70.TUNE.PREDICT_S
					local v99 = math.clamp(v98, 0, 1)
					local v100 = -v94.az
					local v101 = v94.ax
					local v102 = Vector3.new(v100, 0, v101)
					local v103 = CFrame.fromAxisAngle
					local v104 = v70.TUNE.PREDICT_DEG
					local v105 = v103(v102, -math.rad(v104) * v99)
					for _, v106 in v94.parts do
						if v106.part.Parent == nil or not v106.part.Anchored then
							continue
						end
						local v107 = v106.cf.Position - v94.pivot
						local v108 = v94.pivot + v105:VectorToWorldSpace(v107)
						v106.part.CFrame = CFrame.new(v108) * v105.Rotation * v106.cf.Rotation
					end
				end
			end
		end
	end
end
function v_u_3.start(p110) -- name: start
	-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6, (copy) v_u_1, (copy) v_u_109, (copy) v_u_11
	v_u_5 = p110
	v_u_10 = nil
	v_u_8 = -1000000000
	if v_u_6 == nil then
		v_u_6 = v_u_1.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_109, (ref) v_u_11
			local v111 = v_u_109
			if not pcall(v111) then
				local v112 = v_u_11
				v112.restored = v112.restored + 0
			end
		end)
	end
end
function v_u_3.stop() -- name: stop
	-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) v_u_7, (copy) v_u_20, (copy) v_u_9, (ref) v_u_6
	v_u_5 = nil
	v_u_10 = nil
	for v113, v114 in v_u_7 do
		v_u_20(v113, v114)
	end
	table.clear(v_u_9)
	if v_u_6 ~= nil then
		v_u_6:Disconnect()
		v_u_6 = nil
	end
end
function v_u_3.stats() -- name: stats
	-- upvalues: (copy) v_u_11
	return table.clone(v_u_11)
end
return v_u_3