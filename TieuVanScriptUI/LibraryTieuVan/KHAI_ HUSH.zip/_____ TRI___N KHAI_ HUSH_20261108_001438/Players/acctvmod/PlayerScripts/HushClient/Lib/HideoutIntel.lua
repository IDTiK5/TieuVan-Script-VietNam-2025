-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutIntel

return {
	["attach"] = function(p1, p_u_2, p_u_3, p_u_4, p_u_5) -- name: attach
		local v_u_6 = p_u_2.cctx
		if type(v_u_6) == "table" and v_u_6.config.flag("Hideout4") == true then
			local v7, v_u_8 = pcall(function()
				-- upvalues: (copy) v_u_6
				return v_u_6.shared.HideoutModules
			end)
			local v9, v_u_10 = pcall(function()
				-- upvalues: (copy) v_u_6
				return v_u_6.shared.Difficulty
			end)
			if v7 and (v9 and (type(v_u_8) == "table" and type(v_u_10) == "table")) then
				local v_u_11 = p_u_2.ui
				local v12 = p_u_2.theme
				local v13 = v12.color
				local v14 = v12.space.m
				local v_u_15 = v_u_11.new("Frame", {
					["Name"] = "BossIntel",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.25,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 90,
					["Visible"] = false,
					["BackgroundColor3"] = v13.raised,
					["Size"] = UDim2.new(1, 0, 0, 34)
				}, p1)
				v_u_11.stroke(v_u_15, v13.line)
				v_u_11.new("Frame", {
					["Name"] = "Dot",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Rotation"] = 45,
					["BackgroundColor3"] = v13.danger,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, v14, 0.5, 0),
					["Size"] = UDim2.fromOffset(6, 6)
				}, v_u_15)
				local v_u_16 = v_u_11.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = "",
					["style"] = "bodyStrong",
					["textSize"] = 14,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_15,
					["color"] = v13.text,
					["position"] = UDim2.fromOffset(v14 + 16, 0),
					["size"] = UDim2.new(1, -(v14 + 24), 1, 0)
				})
				v_u_16.TextTruncate = Enum.TextTruncate.AtEnd
				local v_u_17 = false
				local v_u_18 = ""
				local function v_u_24() -- name: update
					-- upvalues: (ref) v_u_17, (copy) v_u_8, (copy) v_u_10, (copy) p_u_4, (copy) p_u_3, (copy) v_u_15, (ref) v_u_18, (copy) v_u_11, (copy) v_u_16
					local v19 = {}
					local v20
					if v_u_17 then
						local function v21()
							-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) p_u_4, (ref) p_u_3
							return v_u_8.bossNames(v_u_10, p_u_4(), p_u_3())
						end
						local v22
						v22, v20 = pcall(v21)
						if v22 then
							if type(v20) ~= "table" then
								v20 = v19
							end
						else
							v20 = v19
						end
					else
						v20 = v19
					end
					local v23 = ""
					if #v20 == 1 then
						v23 = "A boss is in this raid: " .. v20[1]
					elseif #v20 > 1 then
						v23 = "Bosses are in this raid: " .. table.concat(v20, " and ")
					end
					v_u_15.Visible = v23 ~= ""
					if v23 ~= v_u_18 then
						v_u_18 = v23
						v_u_11.setText(v_u_16, v23)
					end
				end
				task.spawn(function()
					-- upvalues: (copy) p_u_2, (ref) v_u_17, (copy) p_u_5, (copy) v_u_24, (copy) v_u_15
					local v25 = p_u_2.fetch
					local v26, v27 = pcall(v25, "hideout", nil, 60)
					local v28
					if v26 and type(v27) == "table" then
						local v29 = v27.effects
						if type(v29) == "table" then
							v28 = v27.effects
						else
							v28 = nil
						end
					else
						v28 = nil
					end
					local v30
					if v28 == nil then
						v30 = false
					else
						v30 = v28.bossIntel == true
					end
					v_u_17 = v30
					if v_u_17 then
						local v31 = v27.modules
						local v32
						if type(v31) == "table" then
							v32 = v31.radio
						else
							v32 = nil
						end
						local v33 = p_u_5
						local v34 = 4
						local v35
						if type(v32) == "table" then
							local v36 = v32.lvl
							local v37 = tonumber(v36) or 4
							v35 = math.floor(v37)
						else
							v35 = 4
						end
						local v38 = math.max(v34, v35)
						if v33 ~= nil then
							local v39 = v33:FindFirstChild("Right")
							if v39 ~= nil and v39:IsA("TextLabel") then
								v39.Text = ("RADIO L%d"):format(v38)
							end
						end
					end
					v_u_24()
					while v_u_15.Parent do
						task.wait(0.5)
						v_u_24()
					end
				end)
			end
		else
			return
		end
	end
}