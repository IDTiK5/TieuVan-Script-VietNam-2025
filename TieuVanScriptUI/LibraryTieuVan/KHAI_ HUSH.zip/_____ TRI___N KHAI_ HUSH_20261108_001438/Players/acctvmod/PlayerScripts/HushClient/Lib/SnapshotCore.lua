-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SnapshotCore

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Lighting")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {
	["DEFAULT_RADIUS"] = 200,
	["MIN_RADIUS"] = 25,
	["MAX_RADIUS"] = 1000,
	["PART_CAP"] = 20000,
	["YIELD_SCAN"] = 4000,
	["YIELD_BUILD"] = 400,
	["FOLDER"] = "Snapshots",
	["INVISIBLE"] = 0.995,
	["HELP"] = {
		"1. Press TAKE SNAPSHOT. The copy lives only in this Play session and only on the CLIENT side.",
		"2. In Studio switch the Explorer to the client view (Test tab, Current: Client). Open Workspace, Snapshots and select the new Snapshot model.",
		"3. Right click it, Export Selection, save it as FBX or OBJ, then import the file in Blender (File, Import).",
		"4. Fallback: copy it (Ctrl+C), stop Play, paste it into the Workspace in Edit mode (Ctrl+V) and export it from there.",
		"The Configuration SnapshotInfo inside the model holds the camera, the lighting and the counts."
	}
}
local v_u_6 = {
	"Decal",
	"SurfaceAppearance",
	"Light",
	"ParticleEmitter",
	"Fire",
	"Smoke",
	"Sparkles",
	"Beam",
	"Trail",
	"Attachment",
	"DataModelMesh"
}
function v_u_5.clampRadius(p7) -- name: clampRadius
	-- upvalues: (copy) v_u_5
	local v8 = tonumber(p7)
	if v8 == nil or v8 ~= v8 then
		return v_u_5.DEFAULT_RADIUS
	end
	local v9 = v8 + 0.5
	local v10 = math.floor(v9)
	local v11 = v_u_5.MIN_RADIUS
	local v12 = v_u_5.MAX_RADIUS
	return math.clamp(v10, v11, v12)
end
function v_u_5.effective(p13, p14) -- name: effective
	return 1 - (1 - p13) * (1 - p14)
end
function v_u_5.available(p15) -- name: available
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	if p15 == nil then
		p15 = v_u_2:IsStudio()
	end
	if p15 then
		local v_u_16 = true
		local function v18()
			-- upvalues: (ref) v_u_4, (ref) v_u_16
			local v17 = require((v_u_4:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Config", 5)))
			if v17 and (v17.FLAGS and v17.FLAGS.Snapshot == false) then
				v_u_16 = false
			end
		end
		pcall(v18)
		p15 = v_u_16
	end
	return p15
end
local function v_u_23(p19) -- name: fmt
	local v20 = math.floor(p19)
	local v21 = tostring(v20)
	repeat
		local v22
		v21, v22 = string.gsub(v21, "^(-?%d+)(%d%d%d)", "%1,%2")
	until v22 == 0
	return v21
end
function v_u_5.summary(p24) -- name: summary
	-- upvalues: (copy) v_u_23
	local v25 = string.format("%s: %s parts (%s meshes), %s zombies, %s avatars, %s lights, %s decals, radius %d.", p24.name, v_u_23(p24.parts), v_u_23(p24.meshes), v_u_23(p24.zombies), v_u_23(p24.avatars), v_u_23(p24.lights), v_u_23(p24.decals), p24.radius)
	if p24.capped and p24.capped > 0 then
		v25 = v25 .. string.format(" Limit reached: %s parts left out, lower the radius.", (v_u_23(p24.capped)))
	end
	return v25 .. " It is in Workspace.Snapshots (client view)."
end
local function v_u_33(p_u_26, p27, p_u_28) -- name: readProps
	for _, v_u_29 in p27 do
		local v30, v_u_31 = pcall(function()
			-- upvalues: (copy) p_u_26, (copy) v_u_29
			return p_u_26[v_u_29]
		end)
		if not v30 or v_u_31 == nil then
			continue
		end
		local v32 = typeof(v_u_31)
		if v32 == "number" or (v32 == "string" or (v32 == "boolean" or (v32 == "Color3" or (v32 == "Vector3" or (v32 == "CFrame" or v32 == "Vector2"))))) then
			pcall(function()
				-- upvalues: (copy) p_u_28, (copy) v_u_29, (copy) v_u_31
				p_u_28:SetAttribute(v_u_29, v_u_31)
			end)
		else
			if v32 ~= "EnumItem" then
				continue
			end
			pcall(function()
				-- upvalues: (copy) p_u_28, (copy) v_u_29, (copy) v_u_31
				p_u_28:SetAttribute(v_u_29, v_u_31.Name)
			end)
		end
	end
end
local v_u_34 = {
	"ClockTime",
	"TimeOfDay",
	"Brightness",
	"Ambient",
	"OutdoorAmbient",
	"ColorShift_Top",
	"ColorShift_Bottom",
	"EnvironmentDiffuseScale",
	"EnvironmentSpecularScale",
	"ExposureCompensation",
	"FogColor",
	"FogStart",
	"FogEnd",
	"GeographicLatitude",
	"GlobalShadows",
	"ShadowSoftness",
	"Technology"
}
local v_u_35 = {
	["Atmosphere"] = {
		"Density",
		"Offset",
		"Color",
		"Decay",
		"Glare",
		"Haze"
	},
	["Sky"] = {
		"SkyboxBk",
		"SkyboxDn",
		"SkyboxFt",
		"SkyboxLf",
		"SkyboxRt",
		"SkyboxUp",
		"SunTextureId",
		"MoonTextureId",
		"StarCount",
		"CelestialBodiesShown",
		"SunAngularSize",
		"MoonAngularSize"
	},
	["BloomEffect"] = {
		"Intensity",
		"Size",
		"Threshold",
		"Enabled"
	},
	["ColorCorrectionEffect"] = {
		"Brightness",
		"Contrast",
		"Saturation",
		"TintColor",
		"Enabled"
	},
	["DepthOfFieldEffect"] = {
		"FarIntensity",
		"FocusDistance",
		"InFocusRadius",
		"NearIntensity",
		"Enabled"
	},
	["SunRaysEffect"] = { "Intensity", "Spread", "Enabled" },
	["BlurEffect"] = { "Size", "Enabled" },
	["Clouds"] = {
		"Cover",
		"Density",
		"Color",
		"Enabled"
	}
}
local function v_u_42(_, p36, p37) -- name: writeEffects
	-- upvalues: (copy) v_u_35, (copy) v_u_33
	for _, v38 in p36:GetChildren() do
		for v39, v40 in v_u_35 do
			if not v38:IsA(v39) then
				continue
			end
			local v41 = Instance.new("Configuration")
			v41.Name = v38.ClassName .. "_" .. v38.Name
			v41:SetAttribute("Class", v38.ClassName)
			v_u_33(v38, v40, v41)
			v41.Parent = p37
		end
	end
end
local function v_u_47(p43) -- name: lightsOn
	local v44 = {}
	for _, v45 in p43:GetChildren() do
		if v45:IsA("Light") then
			if not v45.Enabled then
				continue
			end
			table.insert(v44, v45)
		else
			if not v45:IsA("Attachment") then
				continue
			end
			for _, v46 in v45:GetChildren() do
				if not (v46:IsA("Light") and v46.Enabled) then
					continue
				end
				table.insert(v44, v46)
			end
		end
	end
	return v44
end
local function v_u_54(p48, p49) -- name: sanitize
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_54
	for _, v50 in p48:GetChildren() do
		for _, v51 in v_u_6 do
			if not v50:IsA(v51) then
				continue
			end
			v52 = true
		end
		local v52 = false
		if v52 then
			if v50:IsA("Decal") then
				local v53 = v_u_5.effective(v50.Transparency, v50.LocalTransparencyModifier)
				if v_u_5.INVISIBLE <= v53 then
					v50:Destroy()
				else
					v50.Transparency = v53
					v50.LocalTransparencyModifier = 0
					p49.decals = p49.decals + 1
				end
			elseif v50:IsA("Light") then
				if not v50.Enabled then
					break
				end
				p49.lights = p49.lights + 1
			else
				if not v50:IsA("Attachment") then
					break
				end
				v_u_54(v50, p49)
			end
		else
			v50:Destroy()
		end
	end
end
local function v_u_60(p55, p56) -- name: classOf
	-- upvalues: (copy) v_u_1
	local v57 = p56[p55]
	if v57 then
		return v57
	end
	local v58 = p55.Parent
	local v59 = p55:IsA("Model") and (p55:GetAttribute("ZombieId") ~= nil or v58 ~= nil and v58.Name == "Zombies") and "zombie" or (p55:IsA("Model") and (v_u_1:GetPlayerFromCharacter(p55) ~= nil or p55:FindFirstChildOfClass("Humanoid") ~= nil) and "avatar" or "other")
	p56[p55] = v59
	return v59
end
function v_u_5.clear(p61) -- name: clear
	-- upvalues: (copy) v_u_5
	local v62 = p61 or workspace:FindFirstChild(v_u_5.FOLDER)
	if not v62 then
		return 0
	end
	local v63 = #v62:GetChildren()
	v62:ClearAllChildren()
	return v63
end
local v_u_64 = false
function v_u_5.busy() -- name: busy
	-- upvalues: (ref) v_u_64
	return v_u_64
end
function v_u_5.take(p65) -- name: take
	-- upvalues: (copy) v_u_5, (ref) v_u_64, (copy) v_u_1, (copy) v_u_47, (copy) v_u_54, (copy) v_u_60, (copy) v_u_42, (copy) v_u_33, (copy) v_u_3, (copy) v_u_34
	local v_u_66 = p65 or {}
	if v_u_5.available(v_u_66.studio) then
		if v_u_64 then
			return nil, "A snapshot is already running."
		else
			local v_u_67 = v_u_66.root or workspace
			local v_u_68 = v_u_66.camera or workspace.CurrentCamera
			local v_u_69 = v_u_5.clampRadius(v_u_66.radius)
			local v_u_70 = v_u_66.partCap or v_u_5.PART_CAP
			local v_u_71 = v_u_66.center
			if v_u_71 == nil then
				local v72 = v_u_1.LocalPlayer
				if v72 then
					v72 = v_u_1.LocalPlayer.Character
				end
				if v72 then
					v72 = v72:FindFirstChild("HumanoidRootPart")
				end
				if v72 then
					v_u_71 = v72.Position
				elseif v_u_68 then
					v_u_71 = v_u_68.CFrame.Position
				end
			end
			if v_u_71 == nil then
				return nil, "No player and no camera yet."
			else
				v_u_64 = true
				local v_u_73 = os.clock()
				local function v115()
					-- upvalues: (copy) v_u_66, (copy) v_u_67, (ref) v_u_5, (copy) v_u_71, (copy) v_u_69, (copy) v_u_70, (ref) v_u_47, (ref) v_u_54, (ref) v_u_60, (copy) v_u_68, (ref) v_u_42, (ref) v_u_33, (ref) v_u_3, (ref) v_u_34, (copy) v_u_73
					local v74 = v_u_66.container or v_u_67:FindFirstChild(v_u_5.FOLDER)
					if not v74 then
						v74 = Instance.new("Folder")
						v74.Name = v_u_5.FOLDER
						v74.Parent = v_u_67
					end
					local v75 = 0
					local v76 = {}
					for _, v77 in v_u_67:GetDescendants() do
						v75 = v75 + 1
						if v75 % v_u_5.YIELD_SCAN == 0 then
							task.wait()
						end
						if not v77:IsA("BasePart") or (v77:IsA("Terrain") or v77:IsDescendantOf(v74)) then
							continue
						end
						local v78 = (v77.Position - v_u_71).Magnitude - v77.Size.Magnitude * 0.5
						if v78 > v_u_69 then
							continue
						end
						table.insert(v76, {
							["p"] = v77,
							["d"] = v78
						})
					end
					table.sort(v76, function(p79, p80)
						return p79.d < p80.d
					end)
					local v81 = #v76 - v_u_70
					local v82 = math.max(0, v81)
					local v83 = os.date("%Y%m%d_%H%M%S")
					local v84 = "Snapshot_" .. v83
					local v85 = 1
					while v74:FindFirstChild(v84) do
						v85 = v85 + 1
						v84 = "Snapshot_" .. v83 .. "_" .. v85
					end
					local v_u_86 = Instance.new("Model")
					v_u_86.Name = v84
					local v_u_87 = {}
					local function v_u_92(p88) -- name: mirrorOf
						-- upvalues: (ref) v_u_67, (copy) v_u_86, (copy) v_u_87, (copy) v_u_92
						if p88 == nil or p88 == v_u_67 then
							return v_u_86
						end
						local v89 = v_u_87[p88]
						if v89 then
							return v89
						end
						local v90 = v_u_92(p88.Parent)
						local v91
						if p88:IsA("Folder") then
							v91 = Instance.new("Folder")
						else
							v91 = Instance.new("Model")
						end
						v91.Name = p88.Name
						v91.Parent = v90
						v_u_87[p88] = v91
						return v91
					end
					local v93 = #v76
					local v94 = v_u_70
					local v95 = {}
					local v96 = {}
					local v97 = {
						["parts"] = 0,
						["meshes"] = 0,
						["zombies"] = 0,
						["avatars"] = 0,
						["invisible"] = 0
					}
					local v98 = {
						["decals"] = 0,
						["lights"] = 0
					}
					local v99 = {}
					for v100 = 1, math.min(v93, v94) do
						if v100 % v_u_5.YIELD_BUILD == 0 then
							task.wait()
						end
						local v101 = v76[v100].p
						if v101.Parent == nil then
							continue
						end
						local v102 = v_u_5.effective(v101.Transparency, v101.LocalTransparencyModifier)
						local v103 = v101.Parent
						while v103 and v103:IsA("BasePart") do
							v103 = v103.Parent
						end
						if v_u_5.INVISIBLE <= v102 then
							v97.invisible = v97.invisible + 1
							local v104 = v_u_47(v101)
							if #v104 <= 0 then
								break
							end
							local v105 = Instance.new("Part")
							v105.Name = "SnapLight_" .. v101.Name
							v105.Size = Vector3.new(0.2, 0.2, 0.2)
							v105.CFrame = v101.CFrame
							v105.Anchored = true
							v105.CanCollide = false
							v105.Transparency = 1
							for _, v_u_106 in v104 do
								local v107, v108 = pcall(function()
									-- upvalues: (copy) v_u_106
									return v_u_106:Clone()
								end)
								if not (v107 and v108) then
									continue
								end
								v108.Parent = v105
								v98.lights = v98.lights + 1
							end
							v105.Parent = v_u_92(v103)
						else
							local v109 = v101.Archivable
							if not v109 then
								v101.Archivable = true
							end
							local v110 = v101:Clone()
							if not v109 then
								v101.Archivable = false
							end
							if not v110 then
								break
							end
							v_u_54(v110, v98)
							v110.Transparency = v102
							v110.LocalTransparencyModifier = 0
							v110.Anchored = true
							v110.Parent = v_u_92(v103)
							v97.parts = v97.parts + 1
							local v111
							if v110:IsA("MeshPart") then
								v97.meshes = v97.meshes + 1
								v111 = 0
							else
								v111 = 0
							end
							while v103 and (v103 ~= v_u_67 and v111 < 12) do
								v111 = v111 + 1
								local v112 = v_u_60(v103, v99)
								if v112 == "zombie" then
									if v96[v103] then
										break
									end
									v96[v103] = true
									v97.zombies = v97.zombies + 1
									break
								end
								if v112 == "avatar" then
									if v95[v103] then
										break
									end
									v95[v103] = true
									v97.avatars = v97.avatars + 1
									break
								end
								v103 = v103.Parent
							end
						end
					end
					local v113 = Instance.new("Configuration")
					v113.Name = "SnapshotInfo"
					v113:SetAttribute("Time", os.date("%Y-%m-%d %H:%M:%S"))
					v113:SetAttribute("Radius", v_u_69)
					v113:SetAttribute("Center", v_u_71)
					v113:SetAttribute("Parts", v97.parts)
					v113:SetAttribute("MeshParts", v97.meshes)
					v113:SetAttribute("Zombies", v97.zombies)
					v113:SetAttribute("Avatars", v97.avatars)
					v113:SetAttribute("Lights", v98.lights)
					v113:SetAttribute("Decals", v98.decals)
					v113:SetAttribute("SkippedInvisible", v97.invisible)
					v113:SetAttribute("SkippedByCap", v82)
					v113:SetAttribute("Terrain", "not copied")
					if v_u_68 then
						v113:SetAttribute("CameraCFrame", v_u_68.CFrame)
						v113:SetAttribute("CameraFieldOfView", v_u_68.FieldOfView)
						local v114 = Instance.new("Part")
						v114.Name = "SnapshotCamera"
						v114.Size = Vector3.new(1, 1, 2)
						v114.CFrame = v_u_68.CFrame
						v114.Anchored = true
						v114.CanCollide = false
						v114.Transparency = 0.5
						v114.Parent = v_u_86
						v_u_42(v113, v_u_68, v113)
					end
					v_u_33(v_u_3, v_u_34, v113)
					v_u_42(v113, v_u_3, v113)
					v113.Parent = v_u_86
					v_u_86.Parent = v74
					return {
						["name"] = v84,
						["model"] = v_u_86,
						["parts"] = v97.parts,
						["meshes"] = v97.meshes,
						["zombies"] = v97.zombies,
						["avatars"] = v97.avatars,
						["lights"] = v98.lights,
						["decals"] = v98.decals,
						["invisible"] = v97.invisible,
						["capped"] = v82,
						["radius"] = v_u_69,
						["center"] = v_u_71,
						["seconds"] = os.clock() - v_u_73
					}
				end
				local v116, v117, v118 = pcall(v115)
				v_u_64 = false
				if v116 then
					return v117, v118
				else
					return nil, "Snapshot failed: " .. tostring(v117)
				end
			end
		end
	else
		return nil, "Snapshots only work in Studio."
	end
end
return v_u_5