-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuGroupStarter

return {
	["new"] = function(p_u_1, p_u_2) -- name: new
		local v_u_3 = p_u_1.ui
		local v_u_4 = p_u_1.theme
		local v_u_5 = v_u_4.color
		local v6 = p_u_1.kit
		local v_u_7 = {
			["ov"] = {}
		}
		local v_u_8 = "GroupStarterRules"
		local v9, v_u_10 = pcall(function()
			-- upvalues: (copy) p_u_1, (copy) v_u_8
			return p_u_1.cctx.shared[v_u_8]
		end)
		if not v9 or type(v_u_10) ~= "table" then
			v_u_10 = nil
		end
		local v11, v_u_12 = pcall(function()
			return require((script.Parent:WaitForChild("GroupStarterLayout", 5)))
		end)
		if v_u_10 == nil or (not v11 or type(v_u_12) ~= "table") then
			v6.empty(p_u_2, "The Starter Pack is not available right now.")
			function v_u_7.padFirst()
				return nil
			end
			return v_u_7
		end
		local v_u_13 = v_u_10.TEXT
		local v_u_14 = Vector2.new(0, 0)
		local v_u_15 = v_u_3.new("ScrollingFrame", {
			["Name"] = "StarterScroll",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ScrollBarThickness"] = 3,
			["ScrollBarImageColor3"] = nil,
			["ElasticBehavior"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["CanvasSize"] = UDim2.new(),
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ScrollBarImageColor3"] = v_u_5.lineStrong,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, p_u_2)
		local v_u_16 = v_u_3.new("Frame", {
			["Name"] = "StarterCard",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = v_u_5.raised,
			["BackgroundTransparency"] = v_u_4.alpha.raised
		}, v_u_15)
		v_u_3.stroke(v_u_16, v_u_5.line)
		v_u_3.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_5.accent,
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v_u_16)
		local v_u_17 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "h2",
			["color"] = nil,
			["textSize"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["parent"] = v_u_16,
			["text"] = v_u_13.heading,
			["color"] = v_u_5.accent,
			["textSize"] = v_u_12.TITLE_SIZE
		})
		local v_u_18 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Body",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["textSize"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["parent"] = v_u_16,
			["text"] = v_u_13.body,
			["color"] = v_u_5.text2,
			["textSize"] = v_u_12.BODY_SIZE
		})
		local v_u_19 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Status",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["textSize"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["align"] = "center",
			["parent"] = v_u_16,
			["color"] = v_u_5.text2,
			["textSize"] = v_u_12.STATUS_SIZE
		})
		local v_u_20 = {}
		local v_u_21 = false
		local v_u_22 = ""
		local v_u_23 = true
		local v_u_24 = false
		local v_u_25 = false
		local v_u_26 = nil
		local v_u_27 = false
		local v_u_28 = ""
		for v29, v30 in v_u_10.ITEMS do
			local v31 = v6.itemCell(v_u_16, v30.id, {
				["size"] = v_u_12.ICON
			})
			local v32
			if v30.n > 1 then
				local v33 = v_u_3.label
				local v34 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["textSize"] = nil,
					["align"] = "right",
					["parent"] = v_u_16,
					["name"] = "Count_" .. v30.id
				}
				local v35 = v30.n
				v34.text = "x" .. tostring(v35)
				v34.color = v_u_5.text
				v34.textSize = v_u_12.COUNT_SIZE
				v32 = v33(v34)
				v32.ZIndex = 5
			else
				v32 = nil
			end
			local v36 = v_u_3.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["textSize"] = nil,
				["wrap"] = true,
				["align"] = "center",
				["valign"] = "top",
				["parent"] = v_u_16,
				["name"] = "Name_" .. v30.id,
				["text"] = v6.itemName(v30.id),
				["color"] = v_u_5.text,
				["textSize"] = v_u_12.NAME_SIZE
			})
			local v37
			if v6.itemDef(v30.id) == nil then
				v37 = v30.label
			else
				v37 = v6.itemName(v30.id)
			end
			v36.Text = v37
			v_u_20[v29] = {
				["cell"] = v31,
				["count"] = v32,
				["name"] = v36
			}
		end
		local v_u_38 = nil
		local v_u_39 = nil
		local function v_u_44() -- name: paintButton
			-- upvalues: (ref) v_u_39, (copy) p_u_1, (ref) v_u_21, (copy) v_u_13, (ref) v_u_22, (ref) v_u_28, (copy) v_u_19, (copy) v_u_5
			if v_u_39 == nil then
				return
			else
				local v40 = p_u_1.profile
				local v41
				if type(v40) == "table" then
					v41 = p_u_1.profile
				else
					v41 = nil
				end
				local v42
				if v41 == nil then
					v42 = false
				else
					v42 = v41.groupStarter ~= nil
				end
				if v_u_21 then
					v_u_39.setEnabled(false)
				elseif v42 then
					v_u_39.setText(v_u_13.button)
					v_u_39.setEnabled(false)
					if v_u_22 == "" then
						local v43 = v_u_13.claimed
						v_u_28 = v43
						v_u_19.Text = v43
						v_u_19.TextColor3 = v_u_5.text2
						return
					end
				else
					v_u_39.setText(v_u_13.button)
					v_u_39.setEnabled(true)
				end
			end
		end
		local function v_u_81() -- name: apply
			-- upvalues: (ref) v_u_23, (copy) p_u_2, (copy) v_u_4, (copy) v_u_7, (ref) v_u_14, (copy) v_u_13, (copy) v_u_12, (copy) v_u_20, (ref) v_u_24, (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19, (ref) v_u_38
			if v_u_23 and p_u_2.Parent then
				local v45 = v_u_4.uiScale
				local v46 = math.max(0.01, v45())
				local v47 = v_u_7.ov.size
				local v48
				if typeof(v47) == "Vector2" then
					v48 = v_u_7.ov.size
				else
					v48 = p_u_2.AbsoluteSize
				end
				if v48.X >= 50 and v48.Y >= 50 then
					local v49 = v48.X / v46
					local v50 = v48.Y / v46
					v_u_14 = v48
					local v51 = ""
					for _, v52 in {
						"granted",
						"grantedStash",
						"notmember",
						"notmemberNoPrompt",
						"pending",
						"declined",
						"unknown",
						"notyet",
						"young",
						"claimed",
						"raid",
						"temp",
						"mode",
						"off",
						"rate",
						"busy",
						"loading",
						"gone",
						"error",
						"network"
					} do
						local v53 = v_u_13[v52]
						if type(v53) ~= "string" or #v53 <= #v51 then
							continue
						end
						v51 = v53
					end
					local v54 = v_u_12.layout(v49, v50, {
						["count"] = #v_u_20,
						["scale"] = v46,
						["touch"] = v_u_4.isTouch(),
						["btnH"] = v_u_4.touch(44),
						["texts"] = {
							["title"] = v_u_13.heading,
							["body"] = v_u_13.body,
							["status"] = v51
						}
					})
					v_u_24 = v54.scroll == true
					v_u_15.CanvasSize = UDim2.fromOffset(0, v54.content.h)
					v_u_15.ScrollBarThickness = v_u_24 and 3 or 0
					local v55 = v_u_16
					local v56 = v54.card
					v55.Position = UDim2.fromOffset(v56.x, v56.y)
					v55.Size = UDim2.fromOffset(v56.w, v56.h)
					local v57 = v_u_17
					local v58 = v54.title
					local v59 = {
						["x"] = v58.x - v54.card.x,
						["y"] = v58.y - v54.card.y,
						["w"] = v58.w,
						["h"] = v58.h
					}
					v57.Position = UDim2.fromOffset(v59.x, v59.y)
					v57.Size = UDim2.fromOffset(v59.w, v59.h)
					local v60 = v_u_18
					local v61 = v54.body
					local v62 = {
						["x"] = v61.x - v54.card.x,
						["y"] = v61.y - v54.card.y,
						["w"] = v61.w,
						["h"] = v61.h
					}
					v60.Position = UDim2.fromOffset(v62.x, v62.y)
					v60.Size = UDim2.fromOffset(v62.w, v62.h)
					local v63 = v_u_19
					local v64 = v54.status
					local v65 = {
						["x"] = v64.x - v54.card.x,
						["y"] = v64.y - v54.card.y,
						["w"] = v64.w,
						["h"] = v64.h
					}
					v63.Position = UDim2.fromOffset(v65.x, v65.y)
					v63.Size = UDim2.fromOffset(v65.w, v65.h)
					for v66, v67 in v_u_20 do
						local v68 = v54.tiles[v66]
						if not v68 then
							continue
						end
						local v69 = v67.cell
						local v70 = v68.icon
						local v71 = {
							["x"] = v70.x - v54.card.x,
							["y"] = v70.y - v54.card.y,
							["w"] = v70.w,
							["h"] = v70.h
						}
						v69.Position = UDim2.fromOffset(v71.x, v71.y)
						v69.Size = UDim2.fromOffset(v71.w, v71.h)
						if v67.count then
							local v72 = v67.count
							local v73 = v68.count
							local v74 = {
								["x"] = v73.x - v54.card.x,
								["y"] = v73.y - v54.card.y,
								["w"] = v73.w,
								["h"] = v73.h
							}
							v72.Position = UDim2.fromOffset(v74.x, v74.y)
							v72.Size = UDim2.fromOffset(v74.w, v74.h)
						end
						local v75 = v67.name
						local v76 = v68.name
						local v77 = {
							["x"] = v76.x - v54.card.x,
							["y"] = v76.y - v54.card.y,
							["w"] = v76.w,
							["h"] = v76.h
						}
						v75.Position = UDim2.fromOffset(v77.x, v77.y)
						v75.Size = UDim2.fromOffset(v77.w, v77.h)
					end
					local v78 = v_u_38
					local v79 = v54.button
					local v80 = {
						["x"] = v79.x - v54.card.x,
						["y"] = v79.y - v54.card.y,
						["w"] = v79.w,
						["h"] = v79.h
					}
					v78.Position = UDim2.fromOffset(v80.x, v80.y)
					v78.Size = UDim2.fromOffset(v80.w, v80.h)
				end
			else
				return
			end
		end
		local function v_u_89() -- name: prompt
			-- upvalues: (copy) p_u_1, (copy) v_u_7
			local v_u_82 = 0
			local function v83()
				-- upvalues: (ref) v_u_82, (ref) p_u_1
				v_u_82 = p_u_1.cctx.config.COMMUNITY_GROUP_ID
			end
			pcall(v83)
			local v84 = v_u_82
			if type(v84) ~= "number" or v_u_82 <= 0 then
				return false, nil
			end
			local v85 = v_u_7.ov.prompt
			if type(v85) == "function" then
				return v_u_7.ov.prompt(v_u_82)
			end
			local function v86()
				-- upvalues: (ref) v_u_82
				return game:GetService("GroupService"):PromptJoinAsync(v_u_82)
			end
			local v87, v88 = pcall(v86)
			return v87, v88
		end
		local function v_u_126() -- name: run
			-- upvalues: (ref) v_u_26, (copy) p_u_1, (copy) v_u_10, (copy) v_u_3, (ref) v_u_23, (copy) v_u_13, (ref) v_u_22, (ref) v_u_25, (ref) v_u_28, (copy) v_u_19, (copy) v_u_5, (ref) v_u_27, (ref) v_u_39, (copy) v_u_89
			v_u_26 = nil
			local v90 = p_u_1.cctx.net.invoke
			local v91 = v_u_10.WORD
			local v92, v93 = pcall(v90, "groupstarter.claim", v91)
			if v92 and type(v93) == "table" then
				local v94 = v93.status
				if type(v94) == "string" then
					local v95 = v93.text
					if type(v95) ~= "string" then
						v93 = nil
					end
				else
					v93 = nil
				end
			else
				v93 = nil
			end
			v_u_26 = os.clock()
			if v93 ~= nil and v93.ok == true then
				local v96 = v_u_3.toast
				local v97 = v93.status == "granted" and "Starter Pack sent to your MAIL" or "Starter Pack added to your stash"
				pcall(v96, v97, "success")
			end
			if v_u_23 then
				if v93 == nil then
					local v98 = v_u_13.network
					v_u_22 = "network"
					v_u_25 = false
					v_u_28 = v98
					v_u_19.Text = v98
					v_u_19.TextColor3 = v_u_5.danger
					return
				elseif v93.ok == true then
					local v99 = v93.status
					local v100 = v93.text
					v_u_22 = v99
					v_u_25 = true
					v_u_28 = v100
					v_u_19.Text = v100
					v_u_19.TextColor3 = v_u_5.success
					return
				elseif v93.status == "notmember" then
					if v_u_27 then
						local v101 = v_u_13.notyet
						v_u_22 = "notmember"
						v_u_25 = false
						v_u_28 = v101
						v_u_19.Text = v101
						v_u_19.TextColor3 = v_u_5.danger
						return
					else
						v_u_27 = true
						v_u_39.setText(v_u_13.buttonPrompt)
						local v102 = v_u_13.notmember
						v_u_28 = v102
						v_u_19.Text = v102
						v_u_19.TextColor3 = v_u_5.text2
						local v103, v104 = v_u_89()
						if v_u_23 then
							if v103 then
								local v105 = v_u_10.afterPrompt(v104)
								if v105 == "pending" then
									local v106 = v_u_13.pending
									v_u_22 = "pending"
									v_u_25 = false
									v_u_28 = v106
									v_u_19.Text = v106
									v_u_19.TextColor3 = v_u_5.text2
									return
								elseif v105 == "declined" then
									local v107 = v_u_13.declined
									v_u_22 = "declined"
									v_u_25 = false
									v_u_28 = v107
									v_u_19.Text = v107
									v_u_19.TextColor3 = v_u_5.text2
									return
								else
									v_u_39.setText(v_u_13.buttonBusy)
									local v108 = v_u_10.gapLeft(v_u_26, os.clock())
									if v108 > 0 then
										task.wait(v108)
										if not v_u_23 then
											return
										end
									end
									local v109 = p_u_1.cctx.net.invoke
									local v110 = v_u_10.WORD
									local v111, v112 = pcall(v109, "groupstarter.claim", v110)
									if v111 and type(v112) == "table" then
										local v113 = v112.status
										if type(v113) == "string" then
											local v114 = v112.text
											if type(v114) ~= "string" then
												v112 = nil
											end
										else
											v112 = nil
										end
									else
										v112 = nil
									end
									if v112 ~= nil and v112.ok == true then
										local v115 = v_u_3.toast
										local v116 = v112.status == "granted" and "Starter Pack sent to your MAIL" or "Starter Pack added to your stash"
										pcall(v115, v116, "success")
									end
									if v_u_23 then
										if v112 == nil then
											local v117 = v_u_13.network
											v_u_22 = "network"
											v_u_25 = false
											v_u_28 = v117
											v_u_19.Text = v117
											v_u_19.TextColor3 = v_u_5.danger
											return
										elseif v112.ok == true then
											local v118 = v112.status
											local v119 = v112.text
											v_u_22 = v118
											v_u_25 = true
											v_u_28 = v119
											v_u_19.Text = v119
											v_u_19.TextColor3 = v_u_5.success
											return
										elseif v112.status == "notmember" then
											local v120 = v_u_13.notyet
											v_u_22 = "notmember"
											v_u_25 = false
											v_u_28 = v120
											v_u_19.Text = v120
											v_u_19.TextColor3 = v_u_5.danger
										else
											local v121 = v112.status
											local v122 = v112.text
											v_u_22 = v121
											v_u_25 = false
											v_u_28 = v122
											v_u_19.Text = v122
											v_u_19.TextColor3 = v_u_5.danger
										end
									else
										return
									end
								end
							else
								local v123 = v_u_13.notmemberNoPrompt
								v_u_22 = "notmember"
								v_u_25 = false
								v_u_28 = v123
								v_u_19.Text = v123
								v_u_19.TextColor3 = v_u_5.danger
								return
							end
						else
							return
						end
					end
				else
					local v124 = v93.status
					local v125 = v93.text
					v_u_22 = v124
					v_u_25 = false
					v_u_28 = v125
					v_u_19.Text = v125
					v_u_19.TextColor3 = v_u_5.danger
					return
				end
			else
				return
			end
		end
		local function v_u_135() -- name: press
			-- upvalues: (ref) v_u_21, (ref) v_u_23, (copy) p_u_1, (copy) v_u_13, (ref) v_u_22, (ref) v_u_25, (ref) v_u_28, (copy) v_u_19, (copy) v_u_5, (copy) v_u_44, (ref) v_u_27, (ref) v_u_39, (copy) v_u_126, (copy) v_u_10
			if v_u_21 or not v_u_23 then
				return
			else
				local v127 = p_u_1.profile
				local v128
				if type(v127) == "table" then
					v128 = p_u_1.profile
				else
					v128 = nil
				end
				local v129
				if v128 == nil then
					v129 = false
				else
					v129 = v128.groupStarter ~= nil
				end
				if v129 then
					local v130 = v_u_13.claimed
					v_u_22 = "claimed"
					v_u_25 = false
					v_u_28 = v130
					v_u_19.Text = v130
					v_u_19.TextColor3 = v_u_5.text2
					v_u_44()
				else
					v_u_21 = true
					v_u_27 = false
					v_u_22 = ""
					v_u_28 = ""
					v_u_19.Text = ""
					v_u_19.TextColor3 = v_u_5.text2
					v_u_39.setText(v_u_13.buttonBusy)
					v_u_39.setEnabled(false)
					task.spawn(function()
						-- upvalues: (ref) v_u_126, (ref) v_u_21, (ref) v_u_23, (ref) v_u_10, (ref) v_u_22, (ref) v_u_25, (ref) v_u_28, (ref) v_u_19, (ref) v_u_5, (ref) v_u_44
						local v131 = v_u_126
						local v132, v133 = pcall(v131)
						v_u_21 = false
						if not v132 then
							warn("[MenuGroupStarter] claim failed:", (tostring(v133)))
							if v_u_23 then
								local v134 = v_u_10.TEXT.error
								v_u_22 = "error"
								v_u_25 = false
								v_u_28 = v134
								v_u_19.Text = v134
								v_u_19.TextColor3 = v_u_5.danger
							end
						end
						if v_u_23 then
							v_u_44()
						end
					end)
				end
			end
		end
		local v136, v137 = v_u_3.button({
			["parent"] = nil,
			["name"] = "StarterClaim",
			["text"] = nil,
			["kind"] = "primary",
			["height"] = 44,
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_16,
			["text"] = v_u_13.button,
			["size"] = UDim2.fromOffset(200, v_u_4.touch(44)),
			["onClick"] = v_u_135
		})
		v_u_38 = v136
		v_u_39 = v137
		p_u_2:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (ref) v_u_23, (copy) p_u_2, (ref) v_u_14, (copy) v_u_81
			if v_u_23 and (p_u_2.AbsoluteSize - v_u_14).Magnitude > 1 then
				v_u_81()
			end
		end)
		p_u_2.Destroying:Connect(function()
			-- upvalues: (ref) v_u_23
			v_u_23 = false
		end)
		v_u_81()
		v_u_44()
		function v_u_7.show() -- name: show
			-- upvalues: (copy) v_u_81, (copy) v_u_44
			v_u_81()
			v_u_44()
		end
		function v_u_7.hide() -- name: hide end
		function v_u_7.refresh(_) -- name: refresh
			-- upvalues: (ref) v_u_23, (copy) v_u_44
			if v_u_23 then
				v_u_44()
			end
		end
		function v_u_7.padFirst() -- name: padFirst
			-- upvalues: (ref) v_u_38
			return v_u_38
		end
		function v_u_7.press() -- name: press
			-- upvalues: (copy) v_u_135
			v_u_135()
		end
		function v_u_7.state() -- name: state
			-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_28, (ref) v_u_25, (ref) v_u_39, (ref) v_u_27, (ref) v_u_24
			return {
				["busy"] = v_u_21,
				["status"] = v_u_22,
				["text"] = v_u_28,
				["ok"] = v_u_25,
				["button"] = v_u_39.label.Text,
				["promptTried"] = v_u_27,
				["scroll"] = v_u_24
			}
		end
		function v_u_7.destroy() -- name: destroy
			-- upvalues: (ref) v_u_23
			v_u_23 = false
		end
		return v_u_7
	end
}