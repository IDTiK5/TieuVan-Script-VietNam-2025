-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuDebrief

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("UserInputService")
local v4 = {}
local v_u_5 = v1.LocalPlayer
local v_u_6 = {
	["Extracted"] = {
		["text"] = "Extracted",
		["kind"] = "success",
		["line"] = "You made it out."
	},
	["Died"] = {
		["text"] = "Killed in action",
		["kind"] = "danger",
		["line"] = "Your kit stays behind. The secure case came home."
	},
	["MissingInAction"] = {
		["text"] = "Missing in action",
		["kind"] = "warn",
		["line"] = "The raid clock ran out. Everything but the secure case is gone."
	},
	["Left"] = {
		["text"] = "Left the raid",
		["kind"] = "warn",
		["line"] = "Leaving a raid counts as lost. The secure case came home."
	}
}
function v4.new(p_u_7, p8, p_u_9, p_u_10, p_u_11) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2
	local v_u_12 = p_u_7.ui
	local v13 = p_u_7.theme
	local v_u_14 = v13.color
	local v_u_15 = p_u_7.kit
	local v_u_16 = p_u_7.compact()
	local v_u_17 = {}
	local v_u_18 = true
	local v19 = v_u_6
	local v20 = p_u_9.outcome
	local v21 = v19[tostring(v20)] or v_u_6.Left
	local v22 = v13.kindColor(v21.kind)
	local v23 = p_u_9.extra
	local v_u_24 = type(v23) == "table" and (p_u_9.extra or {}) or {}
	local v_u_25 = p_u_7.cctx.shared.HudWhy
	local v_u_26 = v_u_12.new("Frame", {
		["Name"] = "Debrief",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["ZIndex"] = 40,
		["Size"] = UDim2.fromScale(1, 1),
		["Position"] = UDim2.fromOffset(0, v13.motion.slide)
	}, p8)
	local v27 = v_u_12.new("Frame", {
		["Name"] = "Shade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_14.bgDeep,
		["Size"] = UDim2.new(0.62, 0, 1, 0)
	}, v_u_26)
	v_u_12.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.08), NumberSequenceKeypoint.new(0.7, 0.35), NumberSequenceKeypoint.new(1, 1) })
	}, v27)
	local v28 = v_u_16 and 560 or 720
	local v29 = v_u_16 and 20 or 72
	local v30 = v_u_12.new("Frame", {
		["Name"] = "Column",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_16 and 24 or 64, v29),
		["Size"] = UDim2.new(0, v28, 1, -v29 - 24)
	}, v_u_26)
	local v_u_31 = v_u_12.list({
		["parent"] = v30,
		["size"] = UDim2.new(1, 0, 1, -70),
		["gap"] = v_u_16 and 10 or 14
	})
	local v32 = v_u_12.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, 0, 0, v_u_16 and 90 or 124)
	}, v_u_31)
	v_u_12.label({
		["parent"] = nil,
		["text"] = "After action report",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v32,
		["color"] = v_u_14.text2,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "display",
		["textSize"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v32,
		["text"] = v21.text,
		["textSize"] = v_u_16 and 48 or 72,
		["color"] = v22,
		["position"] = UDim2.fromOffset(0, 16),
		["size"] = UDim2.new(1, 0, 0, v_u_16 and 56 or 80)
	})
	v_u_12.new("Frame", {
		["Name"] = "Rule",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v22,
		["Position"] = UDim2.new(0, 0, 1, -6),
		["Size"] = UDim2.fromOffset(64, 3)
	}, v32)
	local v33 = {}
	if p_u_9.extractName then
		local v34 = p_u_9.extractName
		local v35 = "via " .. tostring(v34)
		table.insert(v33, v35)
	end
	local v36 = v_u_12.clock
	local v37 = p_u_9.durationSec
	local v38 = tonumber(v37) or 0
	table.insert(v33, v36(v38))
	for _, v39 in { "difficulty", "timeOfDay", "weather" } do
		local v40 = p_u_9[v39] or v_u_24[v39]
		if type(v40) ~= "string" then
			continue
		end
		table.insert(v33, v40)
	end
	local v_u_41 = p_u_9.practice == true
	local v_u_42 = p_u_9.fallback == true
	local v43
	if p_u_9.freeRaid == true then
		v43 = not v_u_41
	else
		v43 = false
	end
	local v44 = v_u_24.items
	local v45
	if type(v44) == "table" then
		v45 = v_u_24.items or nil
	else
		v45 = nil
	end
	local v46 = v21.line
	local v47 = v_u_24.map
	local v_u_48
	if type(v47) == "string" and v_u_24.map ~= "" then
		v_u_48 = v_u_24.map
	else
		v_u_48 = nil
	end
	if p_u_9.outcome == "Died" then
		local v_u_49 = nil
		local function v55()
			-- upvalues: (copy) p_u_7, (copy) v_u_24, (ref) v_u_49
			local v50 = p_u_7.cctx.shared.InsuranceRules
			local v51 = p_u_7.profile
			local v52
			if type(v51) == "table" then
				local v53 = v51.passes
				if type(v53) == "table" then
					v52 = v51.passes[v50.TUNE.passId] == true
				else
					v52 = false
				end
			else
				v52 = false
			end
			local v54 = v_u_24.mapId
			if type(v54) == "string" and v_u_24.mapId ~= "" then
				v_u_49 = v50.delayText(v_u_24.mapId, v52)
			end
		end
		pcall(v55)
		v46 = v_u_25.deathLine(v_u_48, v_u_25.insuredCount(p_u_7.profile) > 0, v_u_49)
	end
	if v43 then
		v46 = p_u_9.outcome == "Extracted" and "You made it out with the random kit." or (not v_u_48 and "The random kit stays behind." or ("The random kit stays in %s."):format(v_u_48))
	end
	local v56 = p_u_9.film == true and "Film session." or v46
	local v57 = v_u_41 and (p_u_9.outcome == "Extracted" and "Practice run complete." or "Practice run over.") or v56
	local v_u_58 = "   " .. table.concat(v33, "  \194\183  ")
	local v_u_59 = v_u_12.label({
		["parent"] = nil,
		["name"] = "OutcomeLine",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 2,
		["parent"] = v_u_31,
		["text"] = v57 .. v_u_58,
		["color"] = v_u_14.text2
	})
	local v_u_60 = nil
	if p_u_9.outcome == "Died" and (p_u_9.freeRaid ~= true and (not v_u_41 and p_u_9.film ~= true)) then
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_60, (ref) v_u_18, (copy) v_u_59, (copy) v_u_24, (copy) v_u_25, (copy) v_u_48, (copy) v_u_58
			if p_u_7.changed and p_u_7.changed.Connect then
				v_u_60 = p_u_7.changed:Connect(function(p61)
					-- upvalues: (ref) v_u_18, (ref) v_u_59, (ref) p_u_7, (ref) v_u_24, (ref) v_u_25, (ref) v_u_48, (ref) v_u_58
					if p61 == "profile" and (v_u_18 and v_u_59.Parent) then
						local v62 = v_u_59
						local v_u_63 = nil
						local function v69()
							-- upvalues: (ref) p_u_7, (ref) v_u_24, (ref) v_u_63
							local v64 = p_u_7.cctx.shared.InsuranceRules
							local v65 = p_u_7.profile
							local v66
							if type(v65) == "table" then
								local v67 = v65.passes
								if type(v67) == "table" then
									v66 = v65.passes[v64.TUNE.passId] == true
								else
									v66 = false
								end
							else
								v66 = false
							end
							local v68 = v_u_24.mapId
							if type(v68) == "string" and v_u_24.mapId ~= "" then
								v_u_63 = v64.delayText(v_u_24.mapId, v66)
							end
						end
						pcall(v69)
						v62.Text = v_u_25.deathLine(v_u_48, v_u_25.insuredCount(p_u_7.profile) > 0, v_u_63) .. v_u_58
					end
				end)
			end
		end)
		v_u_26.Destroying:Connect(function()
			-- upvalues: (ref) v_u_60
			if v_u_60 then
				local function v70()
					-- upvalues: (ref) v_u_60
					v_u_60:Disconnect()
				end
				pcall(v70)
				v_u_60 = nil
			end
		end)
	end
	if v_u_42 then
		v_u_12.label({
			["parent"] = nil,
			["name"] = "FallbackNote",
			["text"] = "Summary from your saved raid record. Some details are not available.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v_u_31,
			["color"] = v_u_14.text2
		})
	end
	if v_u_5:GetAttribute("CargoHeld") == true and (p_u_9.film ~= true and not v_u_41) then
		local v71, v72 = pcall(function()
			-- upvalues: (copy) p_u_7
			return p_u_7.cctx.lib.MailRows
		end)
		local v73
		if v71 and type(v72) == "table" then
			local v74 = v72.TEXT
			v73 = type(v74) ~= "table" and "Cargo package waiting in your mail (7 days)." or v72.TEXT.cargoDebrief
		else
			v73 = "Cargo package waiting in your mail (7 days)."
		end
		v_u_12.label({
			["parent"] = nil,
			["name"] = "CargoNote",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v_u_31,
			["text"] = v73,
			["color"] = v_u_14.accent
		})
	end
	if v43 then
		local v75 = 0
		for v76, v77 in (not v45 or p_u_9.outcome ~= "Extracted") and {} or v45 do
			local v78 = tostring(v76)
			local v79
			if string.sub(v78, 1, 7) == "secure_" then
				v79 = true
			else
				local v80 = v_u_15.itemDef(v78)
				if v80 == nil then
					v79 = false
				else
					v79 = v80.category == "secure" and true or v80.equip == "secure"
				end
			end
			if v79 then
				continue
			end
			local v81 = v_u_15.itemDef(v78)
			local v82
			if v81 == nil then
				v82 = false
			else
				local v83 = v81.stack
				v82 = (tonumber(v83) or 1) > 1
			end
			local v84
			if v82 then
				v84 = 1
			else
				local v85 = tonumber(v77) or 1
				local v86 = math.floor(v85)
				v84 = math.max(1, v86)
			end
			v75 = v75 + v84
		end
		local v87 = v_u_12.new("Frame", {
			["Name"] = "FreeRaid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_14.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_31)
		v_u_12.stroke(v87, v_u_14.info)
		v_u_12.pad(v87, {
			16,
			16,
			10,
			12
		})
		v_u_12.layout(v87, "v", 4)
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Free raid  \194\183  random kit",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v87,
			["color"] = v_u_14.info,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Your own loadout was not used. It is untouched and waiting in CHARACTER.",
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v87,
			["color"] = v_u_14.text
		})
		local v88 = p_u_9.outcome ~= "Extracted" and "The random kit is lost. Anything in your secure case went to your stash." or (v_u_42 and "The items of the random kit went to your stash." or (v75 == 1 and "1 item from the random kit went to your stash." or ("%d items from the random kit went to your stash."):format(v75)))
		local v89 = v_u_12.label
		local v90 = {
			["parent"] = nil,
			["name"] = "Stashed",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v87,
			["text"] = v88
		}
		local v91
		if p_u_9.outcome == "Extracted" and v75 > 0 then
			v91 = v_u_14.success
		else
			v91 = v_u_14.text2
		end
		v90.color = v91
		v89(v90)
	end
	if p_u_9.film == true then
		local v92 = v_u_12.new("Frame", {
			["Name"] = "FilmSession",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_14.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_31)
		v_u_12.stroke(v92, v_u_14.info)
		v_u_12.pad(v92, {
			16,
			16,
			10,
			12
		})
		v_u_12.layout(v92, "v", 4)
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Film session: nothing saved",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v92,
			["color"] = v_u_14.info,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Loot, kills, deaths and task progress of this raid were not saved. Your loadout is untouched.",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v92,
			["color"] = v_u_14.text2
		})
	end
	if v_u_41 then
		local v93 = v_u_12.new("Frame", {
			["Name"] = "PracticeRun",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_14.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_31)
		v_u_12.stroke(v93, v_u_14.info)
		v_u_12.pad(v93, {
			16,
			16,
			10,
			12
		})
		v_u_12.layout(v93, "v", 4)
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Practice run  \194\183  no reward",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v93,
			["color"] = v_u_14.info,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v_u_12.label({
			["parent"] = nil,
			["text"] = "Tutorial practice: nothing you found, carried or killed was saved. Your stash, loadout and cash are exactly as before.",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v93,
			["color"] = v_u_14.text2
		})
	end
	local v_u_94 = v_u_12.new("Frame", {
		["Name"] = "Stats",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 3,
		["Size"] = UDim2.new(1, 0, 0, v_u_16 and 70 or 86)
	}, v_u_31)
	v_u_12.layout(v_u_94, "h", 8)
	local function v98(p95, p96) -- name: stat
		-- upvalues: (copy) v_u_12, (copy) v_u_14, (copy) v_u_94, (copy) v_u_16
		local v97 = v_u_12.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_14.bg,
			["Size"] = UDim2.new(0.25, -6, 1, 0),
			["LayoutOrder"] = p96
		}, v_u_94)
		v_u_12.stroke(v97, v_u_14.line)
		v_u_12.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v97,
			["text"] = p95,
			["color"] = v_u_14.text2,
			["position"] = UDim2.fromOffset(12, 8),
			["size"] = UDim2.new(1, -24, 0, 14)
		})
		return v_u_12.label({
			["parent"] = nil,
			["text"] = "0",
			["style"] = "monoL",
			["textSize"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v97,
			["textSize"] = v_u_16 and 22 or 28,
			["position"] = UDim2.fromOffset(12, v_u_16 and 28 or 34),
			["size"] = UDim2.new(1, -24, 0, v_u_16 and 28 or 36)
		})
	end
	local v_u_99 = v98("Loot value", 1)
	local v_u_100 = v98("Kills", 2)
	local v_u_101 = v98("Experience", 3)
	local v102 = v98("Time", 4)
	local v103
	if p_u_9.outcome == "Extracted" then
		v103 = v_u_14.accent
	else
		v103 = v_u_14.text2
	end
	v_u_99.TextColor3 = v103
	local v104 = v_u_12.clock
	local v105 = p_u_9.durationSec
	v102.Text = v104(tonumber(v105) or 0)
	local v_u_106
	if v_u_42 then
		local v107 = p_u_9.xp
		if type(v107) == "table" then
			v_u_106 = next(p_u_9.xp) ~= nil
		else
			v_u_106 = false
		end
	else
		v_u_106 = v_u_42
	end
	if v_u_42 and not v_u_106 then
		v_u_101.Text = "-"
	end
	local v_u_108 = nil
	local v109 = 0
	local v110 = p_u_9.difficulty or v_u_24.difficulty
	local v111, v112 = pcall(function()
		return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Difficulty", 5)))
	end)
	local v113
	if v111 and v112 then
		local v114 = v112.hazardPay
		v113 = type(v114) ~= "function" and 0 or v112.hazardPay(v110)
	else
		v113 = 0
	end
	local v115 = p_u_9.lootValue
	local v116 = tonumber(v115) or 0
	local v117 = v_u_24.hazardPay
	local v118 = tonumber(v117)
	local v_u_119
	if v118 and (v118 == v118 and v118 >= 0) then
		v_u_119 = math.floor(v118)
	else
		v_u_119 = nil
	end
	if p_u_9.outcome == "Extracted" and v113 > 0 then
		local v120
		if v_u_119 then
			v120 = v_u_119 > 0
		else
			v120 = v116 > 0
		end
		if v120 and (not v_u_41 and p_u_9.film ~= true) then
			if not v_u_119 then
				local v121 = v116 * v113
				v_u_119 = math.floor(v121)
			end
			local v122 = v_u_12.new("Frame", {
				["Name"] = "HazardPay",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 4,
				["BackgroundColor3"] = v_u_14.bg,
				["Size"] = UDim2.new(1, 0, 0, v_u_16 and 40 or 46)
			}, v_u_31)
			v_u_12.stroke(v122, v_u_14.line)
			v_u_12.label({
				["parent"] = nil,
				["text"] = "Hazard pay",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v122,
				["color"] = v_u_14.text2,
				["position"] = UDim2.fromOffset(12, 5),
				["size"] = UDim2.new(0.62, -12, 0, 14)
			})
			local v123 = v_u_12.label
			local v124 = {
				["parent"] = nil,
				["name"] = "Why",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v122
			}
			local v125 = tostring(v110)
			local v126 = v113 * 100 + 0.5
			v124.text = ("%s  \194\183  %d %% of the loot value, paid in cash"):format(v125, (math.floor(v126)))
			v124.color = v_u_14.text
			v124.position = UDim2.fromOffset(12, v_u_16 and 19 or 22)
			v124.size = UDim2.new(0.62, -12, 0, 18)
			v123(v124)
			v_u_108 = v_u_12.label({
				["parent"] = nil,
				["name"] = "Amount",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = nil,
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v122,
				["text"] = "+" .. v_u_15.money(0),
				["textSize"] = v_u_16 and 20 or 24,
				["color"] = v_u_14.accent,
				["position"] = UDim2.new(0.62, 0, 0, v_u_16 and 6 or 8),
				["size"] = UDim2.new(0.38, -12, 0, v_u_16 and 28 or 30)
			})
		else
			v_u_119 = v109
		end
	else
		v_u_119 = v109
	end
	local v127 = v_u_24.countsLine
	if type(v127) == "table" then
		local v128 = v127.text
		if type(v128) == "string" and (not v_u_41 and p_u_9.film ~= true) then
			local v129 = v_u_12.new("Frame", {
				["Name"] = "CountsForYou",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 5,
				["BackgroundColor3"] = v_u_14.bg,
				["Size"] = UDim2.new(1, 0, 0, v_u_16 and 52 or 58)
			}, v_u_31)
			v_u_12.stroke(v129, v_u_14.line)
			local v130 = v_u_12.label
			local v131 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v129
			}
			local v132 = v127.title or "Leaderboard and faction"
			v131.text = tostring(v132)
			v131.color = v_u_14.text2
			v131.position = UDim2.fromOffset(12, 5)
			v131.size = UDim2.new(0.62, -12, 0, 14)
			v130(v131)
			local v133 = v_u_12.label
			local v134 = {
				["parent"] = nil,
				["name"] = "Why",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v129,
				["text"] = v127.text,
				["color"] = v_u_14.text,
				["position"] = UDim2.fromOffset(12, 20)
			}
			local v135 = UDim2.new
			local v136 = v127.right
			local v137 = type(v136) == "string" and 0.62 or 1
			local v138 = v127.right
			v134.size = v135(v137, type(v138) == "string" and -12 or -24, 0, 34)
			v133(v134)
			local v139 = v127.right
			if type(v139) == "string" then
				v_u_12.label({
					["parent"] = nil,
					["name"] = "Amount",
					["text"] = nil,
					["style"] = "monoL",
					["textSize"] = nil,
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v129,
					["text"] = v127.right,
					["textSize"] = v_u_16 and 20 or 24,
					["color"] = v_u_14.accent,
					["position"] = UDim2.new(0.62, 0, 0, v_u_16 and 6 or 8),
					["size"] = UDim2.new(0.38, -12, 0, v_u_16 and 28 or 30)
				})
			end
		end
	end
	local v_u_140 = nil
	local v_u_141 = nil
	local v_u_142 = nil
	local v_u_143 = 0
	local v_u_144 = {
		["doc"] = "Doc",
		["gunner"] = "Gunner",
		["scrapper"] = "Scrapper"
	}
	pcall(function()
		-- upvalues: (copy) p_u_7, (copy) v_u_144
		for v145, v146 in p_u_7.cctx.shared.Traders.defs do
			local v147 = v146.name
			if type(v147) ~= "string" or #v146.name <= 0 then
				continue
			end
			local v148 = v_u_144
			local v149 = v146.name
			local v150 = string.sub(v149, 1, 1)
			local v151 = string.lower
			local v152 = v146.name
			v148[v145] = v150 .. v151((string.sub(v152, 2)))
		end
	end)
	local function v_u_195() -- name: applyPartner
		-- upvalues: (ref) v_u_140, (ref) v_u_18, (copy) p_u_9, (copy) v_u_41, (copy) p_u_7, (copy) v_u_144, (copy) v_u_25, (copy) v_u_16, (copy) v_u_12, (copy) v_u_14, (copy) v_u_31, (copy) v_u_24, (ref) v_u_142, (ref) v_u_143
		if not v_u_140 and (v_u_18 and (p_u_9.outcome == "Extracted" and (not v_u_41 and p_u_9.film ~= true))) then
			local function v153()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.config.flag("Partners")
			end
			local v154, v155 = pcall(v153)
			local v156 = p_u_7.profile
			local v157
			if type(v156) == "table" then
				v157 = p_u_7.profile.lastRaid
			else
				v157 = nil
			end
			local v158
			if type(v157) == "table" then
				local v159 = v157.partner
				if type(v159) == "table" then
					v158 = v157.partner
				else
					v158 = nil
				end
			else
				v158 = nil
			end
			if v154 and (v155 == true and v158) then
				local v160 = os.time()
				local v161 = v157.at
				if v160 - (tonumber(v161) or 0) <= 900 then
					local v162 = v158.ep
					local v163 = tonumber(v162) or 0
					local v164 = math.floor(v163)
					local v_u_165 = math.max(0, v164)
					local v166 = v158.total
					local v167 = tonumber(v166) or 0
					local v168 = math.floor(v167)
					local v169 = v158.need
					local v170 = tonumber(v169) or 100
					local v171 = math.floor(v170)
					local v172 = math.max(1, v171)
					local v173 = v158.rep
					local v174 = {}
					local v175 = false
					for _, v176 in type(v173) ~= "table" and {} or v158.rep do
						if type(v176) ~= "table" then
							continue
						end
						local v177 = "%s +%s REP"
						local v178 = v_u_144
						local v179 = v176.trader
						local v180 = v178[tostring(v179)]
						if not v180 then
							local v181 = v176.trader
							v180 = tostring(v181)
						end
						local v182 = v176.pts
						local v183 = tonumber(v182) or 0
						local v184 = tostring(v183)
						table.insert(v174, v177:format(v180, v184))
						if v176.trader ~= v158.chosen then
							continue
						end
						v175 = true
					end
					local v185
					if #v174 > 0 then
						v185 = "Reputation  " .. table.concat(v174, "  \194\183  ")
						local v186 = v158.chosen
						if type(v186) == "string" and (not v175 and v158.chosenDefault ~= true) then
							v185 = v185 .. ("  (%s is at 150 rep or below LV 4)"):format(v_u_144[v158.chosen] or v158.chosen)
						end
					else
						v185 = v_u_25.noRepLine
					end
					local v187 = v_u_25.epHelp(v168, v172)
					local v188 = (v_u_16 and 40 or 46) + 22 + (v185 and 22 or 0)
					local v189 = v_u_12.new("Frame", {
						["Name"] = "MissionPoints",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.15,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = 6,
						["BackgroundColor3"] = v_u_14.bg,
						["Size"] = UDim2.new(1, 0, 0, v188)
					}, v_u_31)
					v_u_12.stroke(v189, v_u_14.line)
					v_u_12.label({
						["parent"] = nil,
						["text"] = "Mission points",
						["style"] = "micro",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v189,
						["color"] = v_u_14.text2,
						["position"] = UDim2.fromOffset(12, 5),
						["size"] = UDim2.new(0.62, -12, 0, 14)
					})
					local v190 = v_u_12.label
					local v191 = {
						["parent"] = nil,
						["name"] = "Why",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v189
					}
					local v192 = p_u_9.difficulty or v_u_24.difficulty or (v158.diff or "Normal")
					v191.text = ("%s  \194\183  EP %d / %d"):format(tostring(v192), math.min(v168, v172), v172)
					v191.color = v_u_14.text
					v191.position = UDim2.fromOffset(12, v_u_16 and 19 or 22)
					v191.size = UDim2.new(0.62, -12, 0, 18)
					v190(v191)
					v_u_142 = v_u_12.label({
						["parent"] = nil,
						["name"] = "Amount",
						["text"] = "+0 EP",
						["style"] = "monoL",
						["textSize"] = nil,
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v189,
						["textSize"] = v_u_16 and 20 or 24,
						["color"] = v_u_14.accent,
						["position"] = UDim2.new(0.62, 0, 0, v_u_16 and 6 or 8),
						["size"] = UDim2.new(0.38, -12, 0, v_u_16 and 28 or 30)
					})
					v_u_12.label({
						["parent"] = nil,
						["name"] = "Help",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v189,
						["text"] = v187,
						["color"] = v_u_14.text2,
						["position"] = UDim2.fromOffset(12, (v_u_16 and 40 or 46) - 2),
						["size"] = UDim2.new(1, -24, 0, 18)
					})
					if v185 then
						v_u_12.label({
							["parent"] = nil,
							["name"] = "Rep",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v189,
							["text"] = v185,
							["color"] = v_u_14.text2,
							["position"] = UDim2.fromOffset(12, (v_u_16 and 40 or 46) + 20),
							["size"] = UDim2.new(1, -24, 0, 18)
						})
					end
					v_u_140 = v189
					v_u_143 = v_u_165
					v189:SetAttribute("Ep", v_u_165)
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_18, (ref) v_u_142, (ref) v_u_12, (copy) v_u_165
						if v_u_18 and v_u_142 then
							v_u_12.countUp(v_u_142, v_u_165, {
								["duration"] = 0.8,
								["format"] = nil,
								["format"] = function(p193) -- name: format
									local v194 = p193 + 0.5
									return ("+%d EP"):format((math.floor(v194)))
								end
							})
						end
					end)
					return
				end
			end
		end
	end
	pcall(v_u_195)
	if not v_u_140 then
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_141, (copy) v_u_195
			if p_u_7.changed and p_u_7.changed.Connect then
				v_u_141 = p_u_7.changed:Connect(function(p196)
					-- upvalues: (ref) v_u_195
					if p196 == "profile" then
						local v197 = v_u_195
						pcall(v197)
					end
				end)
			end
		end)
	end
	local v_u_198 = nil
	local v_u_199 = nil
	local function v_u_221() -- name: applyMod
		-- upvalues: (ref) v_u_198, (ref) v_u_18, (copy) v_u_41, (copy) p_u_9, (copy) p_u_7, (copy) v_u_12, (copy) v_u_14, (copy) v_u_16, (copy) v_u_31, (copy) v_u_15
		if not v_u_198 and (v_u_18 and (not v_u_41 and p_u_9.film ~= true)) then
			local function v200()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.config.flag("RaidMods")
			end
			local v201, v202 = pcall(v200)
			local v203 = p_u_7.profile
			local v204
			if type(v203) == "table" then
				v204 = p_u_7.profile.lastRaid
			else
				v204 = nil
			end
			local v205
			if type(v204) == "table" then
				local v206 = v204.mod
				if type(v206) == "table" then
					v205 = v204.mod
				else
					v205 = nil
				end
			else
				v205 = nil
			end
			if v201 and (v202 == true and v205) then
				local v207 = os.time()
				local v208 = v204.at
				if v207 - (tonumber(v208) or 0) <= 900 then
					local v209, v210 = pcall(function()
						return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("RaidMods", 5)))
					end)
					local v211
					if v209 and type(v210) == "table" then
						v211 = v210.get(v205.id)
					else
						v211 = nil
					end
					if v211 then
						local v212 = v205.extracted == true
						local v213 = v210.debriefLine
						local v214 = v205.bonus
						local v215, v_u_216 = v213(v211, tonumber(v214) or 0, v212)
						local v217 = v_u_12.new("Frame", {
							["Name"] = "RaidCondition",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.15,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["LayoutOrder"] = 7,
							["BackgroundColor3"] = v_u_14.bg,
							["Size"] = UDim2.new(1, 0, 0, v_u_16 and 40 or 46)
						}, v_u_31)
						v_u_12.stroke(v217, v_u_14.line)
						v_u_12.label({
							["parent"] = nil,
							["text"] = "Raid condition",
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v217,
							["color"] = v_u_14.text2,
							["position"] = UDim2.fromOffset(12, 5),
							["size"] = UDim2.new(0.62, -12, 0, 14)
						})
						v_u_12.label({
							["parent"] = nil,
							["name"] = "Why",
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v217,
							["text"] = v215,
							["color"] = v_u_14.text,
							["position"] = UDim2.fromOffset(12, v_u_16 and 19 or 22),
							["size"] = UDim2.new(v_u_216 and 0.62 or 1, v_u_216 and -12 or -24, 0, 18)
						})
						if v_u_216 then
							local v_u_218 = v_u_12.label({
								["parent"] = nil,
								["name"] = "Amount",
								["text"] = nil,
								["style"] = "monoL",
								["textSize"] = nil,
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v217,
								["text"] = "+" .. v_u_15.money(0),
								["textSize"] = v_u_16 and 20 or 24,
								["color"] = v_u_14.accent,
								["position"] = UDim2.new(0.62, 0, 0, v_u_16 and 6 or 8),
								["size"] = UDim2.new(0.38, -12, 0, v_u_16 and 28 or 30)
							})
							task.delay(0.2, function()
								-- upvalues: (ref) v_u_18, (copy) v_u_218, (ref) v_u_12, (copy) v_u_216, (ref) v_u_15
								if v_u_18 and v_u_218.Parent then
									local v220 = {
										["duration"] = 0.9,
										["format"] = nil,
										["format"] = function(p219) -- name: format
											-- upvalues: (ref) v_u_15
											return "+" .. v_u_15.money(p219)
										end
									}
									v_u_12.countUp(v_u_218, v_u_216, v220)
								end
							end)
						end
						v217:SetAttribute("Bonus", v_u_216 or 0)
						v217:SetAttribute("Condition", v211.id)
						v_u_198 = v217
					end
				end
			end
		end
	end
	pcall(v_u_221)
	if not v_u_198 then
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_199, (copy) v_u_221
			if p_u_7.changed and p_u_7.changed.Connect then
				v_u_199 = p_u_7.changed:Connect(function(p222)
					-- upvalues: (ref) v_u_221
					if p222 == "profile" then
						local v223 = v_u_221
						pcall(v223)
					end
				end)
			end
		end)
	end
	v_u_26.Destroying:Connect(function()
		-- upvalues: (ref) v_u_199
		if v_u_199 then
			local function v224()
				-- upvalues: (ref) v_u_199
				v_u_199:Disconnect()
			end
			pcall(v224)
			v_u_199 = nil
		end
	end)
	local v_u_225 = nil
	local v_u_226 = nil
	local function v_u_250() -- name: applyTree
		-- upvalues: (ref) v_u_225, (ref) v_u_18, (copy) v_u_41, (copy) p_u_9, (copy) p_u_7, (copy) v_u_12, (copy) v_u_14, (copy) v_u_16, (copy) v_u_31
		if v_u_225 or (not v_u_18 or (v_u_41 or p_u_9.film == true)) then
			return
		else
			local function v227()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.config.flag("SkillTree")
			end
			local v228, v229 = pcall(v227)
			if not v228 or v229 ~= false then
				local v230 = p_u_7.profile
				local v231
				if type(v230) == "table" then
					v231 = p_u_7.profile.lastRaid
				else
					v231 = nil
				end
				local v232
				if type(v231) == "table" then
					local v233 = v231.tree
					if type(v233) == "table" then
						v232 = v231.tree
					else
						v232 = nil
					end
				else
					v232 = nil
				end
				if v232 then
					local v234 = os.time()
					local v235 = v231.at
					if v234 - (tonumber(v235) or 0) <= 900 then
						local function v236()
							-- upvalues: (ref) p_u_7
							return p_u_7.cctx.lib.MenuTreeLayout
						end
						local v237, v238 = pcall(v236)
						local v239 = nil
						if v237 and type(v238) == "table" then
							local v240 = v238.debriefText
							if type(v240) == "function" then
								local v241 = v238.debriefText
								local v242
								v242, v239 = pcall(v241, v232)
								if not v242 or type(v239) ~= "string" then
									v239 = nil
								end
							end
						end
						if v239 then
							local v243 = v_u_12.new("Frame", {
								["Name"] = "FieldXp",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.15,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = 19,
								["BackgroundColor3"] = v_u_14.bg,
								["Size"] = UDim2.new(1, 0, 0, v_u_16 and 40 or 46)
							}, v_u_31)
							v_u_12.stroke(v243, v_u_14.line)
							v_u_12.label({
								["parent"] = nil,
								["text"] = "Skill tree",
								["style"] = "micro",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["parent"] = v243,
								["color"] = v_u_14.text2,
								["position"] = UDim2.fromOffset(12, 5),
								["size"] = UDim2.new(1, -24, 0, 14)
							})
							v_u_12.label({
								["parent"] = nil,
								["name"] = "Line",
								["text"] = nil,
								["style"] = "body",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["track"] = false,
								["parent"] = v243,
								["text"] = v239,
								["color"] = v_u_14.accent,
								["position"] = UDim2.fromOffset(12, v_u_16 and 19 or 22),
								["size"] = UDim2.new(1, -24, 0, 18)
							})
							local v244 = v232.fe
							local v245 = tonumber(v244) or 0
							v243:SetAttribute("Fe", (math.floor(v245)))
							local v246 = v232.fl
							local v247 = tonumber(v246) or 0
							v243:SetAttribute("FieldLevel", (math.floor(v247)))
							local v248 = v232.up
							local v249 = tonumber(v248) or 0
							v243:SetAttribute("Up", (math.floor(v249)))
							v_u_225 = v243
						end
					end
				end
			end
		end
	end
	pcall(v_u_250)
	if not v_u_225 then
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_226, (copy) v_u_250
			if p_u_7.changed and p_u_7.changed.Connect then
				v_u_226 = p_u_7.changed:Connect(function(p251)
					-- upvalues: (ref) v_u_250
					if p251 == "profile" then
						local v252 = v_u_250
						pcall(v252)
					end
				end)
			end
		end)
	end
	v_u_26.Destroying:Connect(function()
		-- upvalues: (ref) v_u_226
		if v_u_226 then
			local function v253()
				-- upvalues: (ref) v_u_226
				v_u_226:Disconnect()
			end
			pcall(v253)
			v_u_226 = nil
		end
	end)
	local v_u_254 = v_u_12.new("Frame", {
		["Name"] = "Contracts",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 52,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_31)
	v_u_12.layout(v_u_254, "v", 4)
	local v_u_255 = false
	local v_u_256 = nil
	local function v_u_292() -- name: applyContracts
		-- upvalues: (ref) v_u_255, (ref) v_u_18, (copy) v_u_41, (copy) p_u_9, (copy) p_u_7, (copy) v_u_15, (copy) v_u_254, (copy) v_u_14, (copy) v_u_144
		if not v_u_255 and (v_u_18 and (not v_u_41 and p_u_9.film ~= true)) then
			local v257 = p_u_7.profile
			local v258
			if type(v257) == "table" then
				v258 = p_u_7.profile.lastRaid
			else
				v258 = nil
			end
			local v259
			if type(v258) == "table" then
				local v260 = v258.contracts
				if type(v260) == "table" then
					v259 = v258.contracts
				else
					v259 = nil
				end
			else
				v259 = nil
			end
			if v259 then
				local v261 = os.time()
				local v262 = v258.at
				if v261 - (tonumber(v262) or 0) <= 900 then
					v_u_255 = true
					local v263 = 0
					for _, v264 in v259 do
						if type(v264) ~= "table" then
							continue
						end
						local v265 = v264.rows
						if type(v265) ~= "table" then
							continue
						end
						v263 = v263 + 1
						if v263 == 1 then
							v_u_15.section(v_u_254, "Contract progress", 0)
						end
						for v266, v267 in v264.rows do
							local v268 = v267.have
							local v269 = tonumber(v268) or 0
							local v270 = math.floor(v269)
							local v271 = v267.need
							local v272 = tonumber(v271) or 1
							local v273 = math.floor(v272)
							local v274 = math.max(1, v273)
							local v275 = v264.title
							local v276 = tostring(v275)
							local v277 = v267.desc
							local v278 = v276 .. "  \194\183  " .. tostring(v277) .. (v264.ready == true and v266 == #v264.rows and "  \194\183  READY" or "")
							local v279 = v_u_15.bar
							local v280 = v_u_254
							local v281 = {
								["label"] = nil,
								["right"] = nil,
								["value"] = nil,
								["color"] = nil,
								["order"] = nil,
								["labelStyle"] = "body",
								["label"] = v278,
								["right"] = ("%d / %d"):format(math.min(v270, v274), v274)
							}
							local v282 = v270 / v274
							v281.value = math.min(1, v282)
							local v283
							if v274 <= v270 then
								v283 = v_u_14.success
							else
								v283 = v_u_14.accent
							end
							v281.color = v283
							v281.order = v263 * 10 + v266
							local v284 = v279(v280, v281)
							if v284.left then
								v284.left.Size = UDim2.new(0.78, 0, 0, 20)
							end
							if not v284.right then
								continue
							end
							v284.right.Position = UDim2.fromScale(0.78, 0)
							v284.right.Size = UDim2.new(0.22, 0, 0, 20)
						end
						if v264.ready ~= true then
							break
						end
						local v285 = v_u_15.stat
						local v286 = v_u_254
						local v287 = v264.title
						local v288 = tostring(v287) .. " is ready"
						local v289 = string.upper
						local v290 = v_u_144
						local v291 = v264.trader
						v285(v286, v288, "HAND IN AT " .. v289(v290[tostring(v291)] or "THE TRADER"), v263 * 10 + 9, v_u_14.success)
					end
					return
				end
			end
		end
	end
	pcall(v_u_292)
	if not v_u_255 then
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_256, (copy) v_u_292
			if p_u_7.changed and p_u_7.changed.Connect then
				v_u_256 = p_u_7.changed:Connect(function(p293)
					-- upvalues: (ref) v_u_292
					if p293 == "profile" then
						local v294 = v_u_292
						pcall(v294)
					end
				end)
			end
		end)
	end
	v_u_26.Destroying:Connect(function()
		-- upvalues: (ref) v_u_256
		if v_u_256 then
			local function v295()
				-- upvalues: (ref) v_u_256
				v_u_256:Disconnect()
			end
			pcall(v295)
			v_u_256 = nil
		end
	end)
	local v296 = p_u_9.kills
	local v297 = type(v296) == "table" and (p_u_9.kills or {}) or {}
	local v_u_298 = 0
	for _, v299 in v297 do
		v_u_298 = v_u_298 + (tonumber(v299) or 0)
	end
	local v300 = p_u_9.xp
	local v301 = type(v300) == "table" and (p_u_9.xp or {}) or {}
	local v_u_302 = 0
	for _, v303 in v301 do
		v_u_302 = v_u_302 + (tonumber(v303) or 0)
	end
	if next(v297) then
		v_u_15.section(v_u_31, "Infected put down", 10)
		local v304 = v_u_12.new("Frame", {
			["Name"] = "Kills",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 11,
			["Size"] = UDim2.new(1, 0, 0, 30)
		}, v_u_31)
		v_u_12.layout(v304, "h", 6)
		local v305 = 0
		for v306, v307 in v297 do
			v305 = v305 + 1
			v_u_12.badge(("%s x%d"):format(string.upper(string.gsub(tostring(v306), "boss_", "")), tonumber(v307) or 0), string.find(tostring(v306), "boss") and "danger" or "muted", {
				["parent"] = nil,
				["order"] = nil,
				["height"] = 24,
				["parent"] = v304,
				["order"] = v305
			})
		end
	end
	if not v_u_41 and p_u_9.film ~= true then
		pcall(function()
			-- upvalues: (copy) p_u_7, (copy) v_u_31, (ref) v_u_18
			local v308 = p_u_7.cctx.lib.MenuDebriefTally
			if v308 then
				local v309 = {
					["order"] = 15,
					["alive"] = nil,
					["alive"] = function() -- name: alive
						-- upvalues: (ref) v_u_18
						return v_u_18
					end
				}
				v308.attach(p_u_7, v_u_31, v309)
			end
		end)
	end
	if next(v301) then
		v_u_15.section(v_u_31, "Skills", 20)
		local v_u_310 = nil
		local function v311()
			-- upvalues: (ref) v_u_310, (copy) p_u_7
			v_u_310 = p_u_7.cctx.shared.Skills
		end
		pcall(v311)
		local v312 = p_u_7.derived()
		local v313 = v_u_310
		local v314 = 0
		for v315, v316 in v301 do
			v314 = v314 + 1
			local v317
			if v313 and v313.defs[v315] then
				v317 = v313.defs[v315].name
			else
				v317 = tostring(v315)
			end
			local v318 = v312.skills
			local v319
			if type(v318) == "table" then
				v319 = v312.skills[v315] or nil
			else
				v319 = nil
			end
			local v320
			if v319 then
				local v321 = v319.level
				v320 = tonumber(v321) or 0
			else
				v320 = 0
			end
			local v_u_322
			if v319 then
				local v323 = v319.progress
				v_u_322 = tonumber(v323) or 0
			else
				v_u_322 = 0
			end
			local v324 = v_u_15.bar
			local v325 = {
				["label"] = nil,
				["right"] = nil,
				["value"] = 0,
				["order"] = nil,
				["color"] = nil,
				["labelStyle"] = "body",
				["label"] = v317
			}
			local v326 = tonumber(v316) or 0
			v325.right = ("+%d XP  \194\183  LV %d"):format(math.floor(v326), v320)
			v325.order = 20 + v314
			v325.color = v_u_14.info
			local v_u_327 = v324(v_u_31, v325)
			task.delay(0.9 + v314 * 0.12, function()
				-- upvalues: (ref) v_u_18, (copy) v_u_327, (copy) v_u_322
				if v_u_18 then
					v_u_327.set(v_u_322)
				end
			end)
		end
	end
	local v328 = {}
	if v45 and p_u_9.outcome == "Extracted" then
		for v329, v330 in v45 do
			if v43 then
				local v331 = tostring(v329)
				local v332
				if string.sub(v331, 1, 7) == "secure_" then
					v332 = true
				else
					local v333 = v_u_15.itemDef(v331)
					if v333 == nil then
						v332 = false
					else
						v332 = v333.category == "secure" and true or v333.equip == "secure"
					end
				end
				if v332 then
					continue
				end
			end
			local v334 = {
				["id"] = tostring(v329),
				["cnt"] = tonumber(v330)
			}
			table.insert(v328, v334)
		end
	end
	if #v328 > 0 then
		v_u_15.section(v_u_31, v43 and "Carried out  \194\183  now in your stash" or "Carried out", 40)
		local v335 = v_u_12.new("Frame", {
			["Name"] = "Items",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 41,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_31)
		v_u_12.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(60, 60),
			["CellPadding"] = UDim2.fromOffset(4, 4),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v335)
		for v336, v337 in v328 do
			if v336 > 24 then
				continue
			end
			v_u_15.itemCell(v335, v337.id, {
				["size"] = 60,
				["count"] = nil,
				["order"] = nil,
				["wish"] = nil,
				["count"] = v337.cnt,
				["order"] = v336,
				["wish"] = not v13.isPhone()
			})
		end
	end
	local v_u_338 = v_u_12.new("Frame", {
		["Name"] = "Tasks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 51,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_31)
	v_u_12.layout(v_u_338, "v", 4)
	task.spawn(function()
		-- upvalues: (copy) p_u_7, (ref) v_u_18, (copy) p_u_10, (copy) v_u_15, (copy) v_u_338, (copy) v_u_14, (copy) v_u_41, (copy) p_u_9, (copy) v_u_42, (copy) v_u_24, (copy) v_u_25, (copy) v_u_12, (ref) v_u_5
		p_u_7.invalidate("tasks")
		local v_u_339 = p_u_7.fetch("tasks", nil, 0)
		if v_u_18 and type(v_u_339) == "table" then
			local v340 = v_u_339.tasks
			if type(v340) == "table" then
				local v_u_341 = nil
				local function v342()
					-- upvalues: (ref) v_u_341, (ref) p_u_7
					v_u_341 = p_u_7.cctx.shared.Tasks
				end
				pcall(v342)
				local v343 = p_u_10
				local v344
				if type(v343) == "table" then
					local v345 = p_u_10.tasks
					v344 = type(v345) == "table" and (p_u_10.tasks or {}) or {}
				else
					v344 = {}
				end
				local v346 = v_u_339.order
				local v_u_347 = v_u_341
				local v348 = 0
				for _, v349 in type(v346) == "table" and (v_u_339.order or {}) or {} do
					local v350 = v344[v349] or {}
					local v351 = v_u_339.tasks[v349] or {}
					local function v355(p352) -- name: sum
						local v353 = 0
						for _, v354 in type(p352) == "table" and p352 and p352 or {} do
							v353 = v353 + (tonumber(v354) or 0)
						end
						return v353
					end
					local v356
					if v355(v351.progress) > v355(v350.progress) then
						v356 = true
					elseif v351.state == "ready" then
						v356 = v350.state ~= "ready"
					else
						v356 = false
					end
					if not v356 or v351.state ~= "active" and v351.state ~= "ready" then
						continue
					end
					v348 = v348 + 1
					if v348 == 1 then
						v_u_15.section(v_u_338, "Task progress", 0)
					end
					if v_u_347 then
						local v357 = v_u_347.get(v349)
					end
					local v358 = v351.need
					local v359 = 0
					for v360, v361 in type(v358) == "table" and (v351.need or {}) or {} do
						local v362 = v351.progress
						if v362 then
							v362 = v351.progress[v360]
						end
						local v363 = tonumber(v362) or 0
						local v364 = math.min(v363, v361)
						local v365 = v350.progress
						local v366
						if type(v365) == "table" then
							v366 = v350.progress[v360]
						else
							v366 = false
						end
						if (tonumber(v366) or 0) >= v364 and (v359 ~= 0 or (v351.state ~= "ready" or v360 ~= #v351.need)) then
							continue
						end
						v359 = v359 + 1
						local v367 = v357 and v357.objectives
						if v367 then
							v367 = v357.objectives[v360]
						end
						local v368
						if v357 then
							v368 = v357.title or v349
						else
							v368 = v349
						end
						local v369 = v367 and v367.desc or ""
						local v370 = v368 .. "  \194\183  " .. tostring(v369) .. (v351.state == "ready" and "  \194\183  READY" or "")
						local v371 = v_u_15.bar
						local v372 = v_u_338
						local v373 = {
							["label"] = nil,
							["right"] = nil,
							["value"] = nil,
							["color"] = nil,
							["order"] = nil,
							["labelStyle"] = "body",
							["label"] = v370,
							["right"] = ("%d / %d"):format(v364, v361),
							["value"] = v361 <= 0 and 1 or v364 / v361
						}
						local v374
						if v361 <= v364 then
							v374 = v_u_14.success
						else
							v374 = v_u_14.accent
						end
						v373.color = v374
						v373.order = v348 * 10 + v360
						local v375 = v371(v372, v373)
						if v375.left then
							v375.left.Size = UDim2.new(0.78, 0, 0, 20)
						end
						if not v375.right then
							continue
						end
						v375.right.Position = UDim2.fromScale(0.78, 0)
						v375.right.Size = UDim2.new(0.22, 0, 0, 20)
					end
				end
				if not v_u_41 and (p_u_9.film ~= true and not v_u_42) then
					local function v391()
						-- upvalues: (ref) p_u_7, (copy) v_u_339, (ref) p_u_9, (ref) v_u_24, (ref) v_u_25, (ref) v_u_347, (ref) v_u_15, (ref) v_u_338, (ref) v_u_12, (ref) v_u_14, (ref) v_u_5
						local v376 = p_u_7.cctx.shared.TaskConds
						local v377 = v_u_339.order
						local v378 = {}
						for _, v379 in type(v377) == "table" and (v_u_339.order or {}) or {} do
							local v380 = v_u_339.tasks[v379]
							if type(v380) ~= "table" or v380.state ~= "active" then
								continue
							end
							table.insert(v378, v379)
						end
						local v381 = {
							["difficulty"] = p_u_9.difficulty or v_u_24.difficulty,
							["timeOfDay"] = p_u_9.timeOfDay or v_u_24.timeOfDay
						}
						local v388 = v_u_25.notCountedLines(v_u_347, v376, v378, v381, function(p382, p383)
							-- upvalues: (ref) v_u_339
							local v384 = v_u_339.tasks[p382]
							local v385 = v384.progress
							if v385 then
								v385 = v384.progress[p383]
							end
							local v386 = tonumber(v385) or 0
							local v387 = v384.need
							if v387 then
								v387 = v384.need[p383]
							end
							return (tonumber(v387) or 1) <= v386
						end)
						if #v388 > 0 then
							v_u_15.section(v_u_338, "Tasks that did not count", 90)
							for v389, v390 in v388 do
								v_u_12.label({
									["parent"] = nil,
									["name"] = "NotCounted",
									["text"] = nil,
									["style"] = "body",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_338,
									["text"] = v390,
									["color"] = v_u_14.accent,
									["order"] = 90 + v389
								})
							end
						end
						if v_u_5:GetAttribute("HudTasksWaiting") == true then
							v_u_12.label({
								["parent"] = nil,
								["name"] = "TrackerNote",
								["text"] = "The raid tracker had no room on your screen. All your tasks are in TASKS.",
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 99,
								["parent"] = v_u_338,
								["color"] = v_u_14.text2
							})
						end
					end
					pcall(v391)
				end
				return
			end
		end
	end)
	local v392 = v_u_24.squad
	local v393 = type(v392) == "table" and (v_u_24.squad or {}) or {}
	if #v393 > 1 then
		v_u_15.section(v_u_31, "Squad", 60)
		for v394, v395 in v393 do
			local v396 = v395.status or "?"
			local v397 = tostring(v396)
			local v398 = v_u_15.stat
			local v399 = v395.displayName or (v395.name or "?")
			local v400 = tostring(v399)
			local v401 = string.upper(v397)
			local v402 = 60 + v394
			local v403
			if v397 == "Extracted" then
				v403 = v_u_14.success
			elseif v397 == "Dead" then
				v403 = v_u_14.danger
			else
				v403 = v_u_14.text2
			end
			v398(v_u_31, v400, v401, v402, v403)
		end
	end
	local v_u_404 = (p_u_9.film ~= true and not v_u_41 and true or false) and script.Parent:FindFirstChild("MenuReport")
	if v_u_404 then
		pcall(function()
			-- upvalues: (copy) v_u_404, (copy) p_u_7, (copy) v_u_31, (copy) v_u_24
			require(v_u_404).attachDebrief(p_u_7, v_u_31, v_u_24, 80)
		end)
	end
	local v_u_405 = v_u_12.button({
		["parent"] = nil,
		["text"] = "Continue",
		["kind"] = "primary",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v30,
		["size"] = UDim2.new(0, 300, 0, v13.touch(52)),
		["position"] = UDim2.fromScale(0, 1),
		["anchor"] = Vector2.new(0, 1),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_17
			v_u_17.close()
		end
	})
	v_u_405.Name = "Continue"
	v_u_405:SetAttribute("PadDefault", true)
	if p_u_9.outcome == "Extracted" and (not v43 and (p_u_9.film ~= true and not v_u_41)) then
		local v406 = require
		local v407 = script.Parent:WaitForChild("InvUIMoveAll", 5)
		local v408, v409 = pcall(v406, v407)
		if v408 and type(v409) == "table" then
			local v410 = v13.isPhone() and 168 or (v_u_16 and 200 or 300)
			v_u_405.Size = UDim2.new(0, v410, 0, v13.touch(52))
			local v411 = v409.debriefRow
			local v412 = {
				["position"] = UDim2.new(0, v410 + 12, 1, 0),
				["width"] = v28 - v410 - 12,
				["height"] = v13.touch(52)
			}
			pcall(v411, p_u_7, v30, v412)
		end
	end
	task.delay(1.2, function()
		-- upvalues: (ref) v_u_18, (copy) v_u_405, (ref) v_u_3, (ref) v_u_2
		if v_u_18 and (v_u_405.Parent and (v_u_3.GamepadEnabled or require(script.Parent:WaitForChild("VirtualPad")).active)) then
			local function v413()
				-- upvalues: (ref) v_u_2, (ref) v_u_405
				v_u_2.SelectedObject = v_u_405
			end
			pcall(v413)
		end
	end)
	function v_u_17.close() -- name: close
		-- upvalues: (ref) v_u_18, (ref) v_u_141, (ref) v_u_2, (copy) v_u_26, (copy) p_u_7, (copy) p_u_11
		if v_u_18 then
			v_u_18 = false
			if v_u_141 then
				local function v414()
					-- upvalues: (ref) v_u_141
					v_u_141:Disconnect()
				end
				pcall(v414)
				v_u_141 = nil
			end
			if v_u_2.SelectedObject and v_u_2.SelectedObject:IsDescendantOf(v_u_26) then
				v_u_2.SelectedObject = nil
			end
			v_u_26.Visible = false
			local v415 = p_u_7.cctx.controllers.Audio
			if v415 and v415.setMusicState then
				local v416 = v415.setMusicState
				pcall(v416, "menu")
			end
			task.delay(0.25, function()
				-- upvalues: (ref) v_u_26
				v_u_26:Destroy()
			end)
			task.spawn(p_u_11)
		end
	end
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (ref) v_u_18, (ref) v_u_141, (copy) v_u_26
		v_u_18 = false
		if v_u_141 then
			local function v417()
				-- upvalues: (ref) v_u_141
				v_u_141:Disconnect()
			end
			pcall(v417)
			v_u_141 = nil
		end
		v_u_26:Destroy()
	end
	v_u_12.sound(p_u_9.outcome == "Extracted" and "extracted" or "death")
	v_u_12.tween(v_u_26, {
		["Position"] = UDim2.fromOffset(0, 0)
	}, "slower")
	task.delay(0.5, function()
		-- upvalues: (ref) v_u_18, (copy) v_u_12, (copy) v_u_99, (copy) p_u_9, (copy) v_u_15
		if v_u_18 then
			local v418 = v_u_12.countUp
			local v419 = v_u_99
			local v420 = p_u_9.lootValue
			local v422 = {
				["duration"] = 1.6,
				["format"] = nil,
				["format"] = function(p421) -- name: format
					-- upvalues: (ref) v_u_15
					return v_u_15.money(p421)
				end
			}
			v418(v419, tonumber(v420) or 0, v422)
		end
	end)
	task.delay(0.8, function()
		-- upvalues: (ref) v_u_18, (copy) v_u_12, (copy) v_u_100, (copy) v_u_24, (ref) v_u_298
		if v_u_18 then
			local v423 = v_u_12.countUp
			local v424 = v_u_100
			local v425 = v_u_24.killsTotal
			v423(v424, tonumber(v425) or v_u_298, {
				["duration"] = 0.8
			})
		end
	end)
	if v_u_108 then
		task.delay(2.1, function()
			-- upvalues: (ref) v_u_18, (ref) v_u_108, (copy) v_u_12, (ref) v_u_119, (copy) v_u_15
			if v_u_18 and v_u_108 then
				local v427 = {
					["duration"] = 0.9,
					["format"] = nil,
					["format"] = function(p426) -- name: format
						-- upvalues: (ref) v_u_15
						return "+" .. v_u_15.money(p426)
					end
				}
				v_u_12.countUp(v_u_108, v_u_119, v427)
			end
		end)
	end
	task.delay(1, function()
		-- upvalues: (ref) v_u_18, (copy) v_u_42, (copy) v_u_106, (copy) v_u_12, (copy) v_u_101, (copy) v_u_24, (ref) v_u_302
		if v_u_18 and (not v_u_42 or v_u_106) then
			local v428 = v_u_12.countUp
			local v429 = v_u_101
			local v430 = v_u_24.xpTotal
			v428(v429, tonumber(v430) or v_u_302, {
				["duration"] = 1,
				["format"] = nil,
				["format"] = function(p431) -- name: format
					local v432 = p431 + 0.5
					return ("+%d"):format((math.floor(v432)))
				end
			})
		end
	end)
	return v_u_17
end
return v4