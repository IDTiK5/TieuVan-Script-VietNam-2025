-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / LiftSendUp

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = ""
local v_u_13 = 0
local v_u_14 = -1000000000
function v_u_2.hide() -- name: hide
	-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_12
	if v_u_5 then
		v_u_5.Visible = false
	end
	v_u_10 = nil
	if v_u_9 then
		local v15 = v_u_9
		v_u_9.t = 0
		v15.fired = false
	end
	v_u_12 = ""
end
function v_u_2.destroy() -- name: destroy
	-- upvalues: (copy) v_u_2, (ref) v_u_11, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
	v_u_2.hide()
	if v_u_11 then
		v_u_11:Disconnect()
		v_u_11 = nil
	end
	if v_u_4 then
		v_u_4:Destroy()
	end
	v_u_4 = nil
	v_u_5 = nil
	v_u_6 = nil
	v_u_7 = nil
	v_u_8 = nil
end
local function v_u_32(p16) -- name: build
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_2, (ref) v_u_11, (copy) v_u_1
	if v_u_4 and (v_u_4.Parent and v_u_5) then
		return true
	else
		local v_u_17 = p16 and p16.lib
		if v_u_17 then
			v_u_17 = p16.lib.HushUI
		end
		local v_u_18 = p16 and p16.shared
		if v_u_18 then
			v_u_18 = p16.shared.Theme
		end
		if v_u_17 and v_u_18 then
			local function v30()
				-- upvalues: (copy) v_u_17, (copy) v_u_18, (ref) v_u_4, (ref) v_u_10, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
				local v19, v20 = v_u_17.screen("HushLiftSendUp", v_u_18.layer.inventory + 6, {
					["insets"] = "Device"
				})
				v_u_4 = v19
				local v21 = v_u_18.color
				local v22 = Instance.new("Frame")
				v22.Name = "Pill"
				v22.AnchorPoint = Vector2.new(0.5, 0)
				v22.Size = UDim2.fromOffset(300, 34)
				v22.BackgroundColor3 = Color3.fromRGB(14, 12, 20)
				v22.BackgroundTransparency = 0.12
				v22.BorderSizePixel = 0
				v22.Visible = false
				v22.Parent = v20
				local v23 = Instance.new("UICorner")
				v23.CornerRadius = UDim.new(0, 6)
				v23.Parent = v22
				local v24 = Instance.new("UIStroke")
				v24.Color = Color3.fromRGB(168, 96, 255)
				v24.Thickness = 1.5
				v24.Parent = v22
				local v25 = Instance.new("Frame")
				v25.Name = "Fill"
				v25.BackgroundColor3 = Color3.fromRGB(168, 96, 255)
				v25.BackgroundTransparency = 0.45
				v25.BorderSizePixel = 0
				v25.Size = UDim2.new(0, 0, 1, 0)
				v25.Parent = v22
				local v26 = Instance.new("UICorner")
				v26.CornerRadius = UDim.new(0, 6)
				v26.Parent = v25
				local v27 = v_u_17.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "caps",
					["textSize"] = 13,
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["track"] = false,
					["parent"] = v22,
					["color"] = v21.text,
					["size"] = UDim2.fromScale(1, 1)
				})
				v27.ZIndex = 3
				local v28 = Instance.new("TextButton")
				v28.Name = "Hold"
				v28.BackgroundTransparency = 1
				v28.Text = ""
				v28.AutoButtonColor = false
				v28.Size = UDim2.fromScale(1, 1)
				v28.ZIndex = 4
				v28.Parent = v22
				v28.InputBegan:Connect(function(p29)
					-- upvalues: (ref) v_u_10
					if p29.UserInputType == Enum.UserInputType.MouseButton1 or p29.UserInputType == Enum.UserInputType.Touch then
						v_u_10 = p29
					end
				end)
				v_u_5 = v22
				v_u_6 = v25
				v_u_7 = v27
				v_u_8 = v28
			end
			if pcall(v30) then
				if not v_u_11 then
					v_u_11 = v_u_1.InputEnded:Connect(function(p31)
						-- upvalues: (ref) v_u_10
						if p31 == v_u_10 then
							v_u_10 = nil
						end
					end)
				end
				return true
			else
				v_u_2.destroy()
				return false
			end
		else
			return false
		end
	end
end
local function v_u_40(p33) -- name: place
	-- upvalues: (ref) v_u_5
	local v34 = p33.shared.Theme
	local v35 = v_u_5
	if v35 then
		local v36 = v34.refSize()
		local v37 = v34.isPhone()
		v35.Size = UDim2.fromOffset(v37 and 250 or 300, v37 and 32 or 34)
		local v38 = UDim2.fromOffset
		local v39 = v36.X / 2
		v35.Position = v38(math.floor(v39), v37 and 6 or 10)
	end
end
function v_u_2.update(p_u_41, p42, p43) -- name: update
	-- upvalues: (ref) v_u_3, (copy) v_u_2, (copy) v_u_32, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (copy) v_u_40, (ref) v_u_10, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14, (ref) v_u_12
	local v44 = not v_u_3 and script.Parent:FindFirstChild("LiftClientRules")
	if v44 then
		local v45 = require
		local v46, v47 = pcall(v45, v44)
		if v46 then
			v_u_3 = v47
		end
	end
	local v48 = v_u_3
	if not v48 or (p42 == nil or p42.canSendUp ~= true) then
		v_u_2.hide()
		return
	end
	if not v_u_32(p_u_41) then
		return
	end
	if not v_u_9 then
		v_u_9 = v48.holdNew()
	end
	local v49 = v_u_5
	local v50 = v_u_7
	local v51 = v_u_6
	if not v49.Visible then
		v49.Visible = true
		v_u_40(p_u_41)
	end
	local v52 = p_u_41.controllers
	if v52 then
		v52 = p_u_41.controllers.Input
	end
	local v53 = false
	if v52 then
		local v54 = v52.device
		if type(v54) == "function" then
			local v55 = v52.device
			local v56
			v53, v56 = pcall(v55)
			if v53 then
				v53 = v56 == "Gamepad"
			end
		end
	end
	local v57
	if v_u_10 == nil then
		if v53 then
			local function v59()
				-- upvalues: (ref) v_u_1
				local v58 = v_u_1:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonL1)
				if v58 then
					v58 = v_u_1:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR1)
				end
				return v58
			end
			local v60
			v57, v60 = pcall(v59)
			if v57 then
				v57 = v60 == true
			end
		else
			v57 = v53
		end
	else
		v57 = true
	end
	local v61, v62 = v48.holdStep(v_u_9, v57, p43, true)
	v51.Size = UDim2.new(v61, 0, 1, 0)
	if v62 then
		v_u_13 = v_u_13 + 1
		v_u_14 = os.clock()
		task.spawn(function()
			-- upvalues: (copy) p_u_41
			local v63 = p_u_41.net.fire
			pcall(v63, "lift.op", {
				["op"] = "sendUp"
			})
		end)
	end
	local v64
	if os.clock() - v_u_14 < 2.5 and v61 >= 1 then
		v64 = "SENT"
	elseif v53 then
		v64 = "HOLD LB + RB TO SEND UP  " .. v48.clock(p42.left)
	else
		v64 = "HOLD TO SEND UP  " .. v48.clock(p42.left)
	end
	local v65, v66, v67
	if v64 == v_u_12 then
		v65 = p42.tone == "danger"
		v66 = v49:FindFirstChildOfClass("UIStroke")
		if v66 then
			if v65 then
				v67 = Color3.fromRGB(235, 80, 70)
			else
				v67 = Color3.fromRGB(168, 96, 255)
			end
			v66.Color = v67
		end
	else
		v_u_12 = v64
		local v68 = p_u_41.lib.HushUI
		if v68 then
			local v69 = v68.setText
			if type(v69) == "function" then
				v68.setText(v50, v64)
				v65 = p42.tone == "danger"
				v66 = v49:FindFirstChildOfClass("UIStroke")
				if v66 then
					if v65 then
						v67 = Color3.fromRGB(235, 80, 70)
					else
						v67 = Color3.fromRGB(168, 96, 255)
					end
					v66.Color = v67
				end
				return
			end
			v50.Text = v64
		else
			v50.Text = v64
		end
		v65 = p42.tone == "danger"
		v66 = v49:FindFirstChildOfClass("UIStroke")
		if v66 then
			if v65 then
				v67 = Color3.fromRGB(235, 80, 70)
			else
				v67 = Color3.fromRGB(168, 96, 255)
			end
			v66.Color = v67
		end
	end
end
function v_u_2.state() -- name: state
	-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_10
	local v70 = string.format
	local v71 = "sendup shown=%s sent=%d held=%s"
	local v72
	if v_u_5 == nil then
		v72 = false
	else
		v72 = v_u_5.Visible
	end
	local v73 = tostring(v72)
	local v74 = v_u_13
	local v75 = v_u_10 ~= nil
	return v70(v71, v73, v74, (tostring(v75)))
end
return v_u_2