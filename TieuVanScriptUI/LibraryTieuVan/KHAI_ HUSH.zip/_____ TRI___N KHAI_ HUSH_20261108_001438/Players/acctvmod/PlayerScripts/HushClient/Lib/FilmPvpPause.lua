-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPvpPause

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("PvpPauseRules"))
local v_u_6 = {
	["POLL_SEC"] = 20
}
local v_u_7 = v1.LocalPlayer
function v_u_6.clamp(p8, p9) -- name: clamp
	-- upvalues: (copy) v_u_5
	local v10 = p9 or v_u_5.MSG_MAX
	if type(p8) ~= "string" then
		return "", 0
	end
	local v11 = utf8.len(p8)
	if v11 == nil then
		return p8, #p8
	end
	if v10 < v11 then
		local v12 = utf8.offset(p8, v10 + 1)
		if v12 ~= nil then
			local v13 = v12 - 1
			return string.sub(p8, 1, v13), v10
		end
	end
	return p8, v11
end
function v_u_6.mount(p14, p_u_15, p16, p17) -- name: mount
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3
	local v18 = type(p17) ~= "table" and {} or p17
	if type(p16) == "table" then
		local v19 = p16.color
		if type(v19) ~= "table" then
			p16 = v_u_4.Theme
		end
	else
		p16 = v_u_4.Theme
	end
	local v_u_20 = p16.color
	local v21 = v18.inner
	local v22 = type(v21) ~= "number" and 438 or v18.inner
	local v23 = v18.gui
	local v_u_24
	if v18.player == nil then
		v_u_24 = v_u_7
	else
		v_u_24 = v18.player
	end
	local v25 = v18.sendQuiet
	local v_u_26
	if type(v25) == "function" then
		v_u_26 = v18.sendQuiet
	else
		v_u_26 = p_u_15
	end
	local v27 = 0
	local v_u_28 = true
	if v23 then
		v23.Destroying:Connect(function()
			-- upvalues: (ref) v_u_28
			v_u_28 = false
		end)
	end
	local v29 = v_u_5.f8Layout
	local v30 = p16.touch
	local v31 = v29(v22, type(v30) ~= "function" and 34 or p16.touch(34))
	local v32 = v_u_4.label({
		["parent"] = nil,
		["text"] = "PVP pause  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p14,
		["color"] = v_u_20.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v33 = v18.order
	local v34, v35
	if type(v33) == "function" then
		v34 = v18.order()
		v35 = v27
	else
		v27 = v27 + 1
		v34 = v27
		v35 = v27
	end
	v32.LayoutOrder = v34
	local v36 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PausePvpNote",
		["text"] = "Emergency brake for PVP. PAUSE PVP stops every new PVP raid search and deploy, shuts the travel door from the PVE lobby and shows the message to the players. Raids that already run are not touched and nobody is kicked. RESUME PVP opens everything again. Other servers follow within 15 seconds. Leave the box empty for the standard sentence.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p14,
		["color"] = v_u_20.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v37 = v18.order
	local v38
	if type(v37) == "function" then
		v38 = v18.order()
	else
		v27 = v35 + 1
		v38 = v27
		v35 = v27
	end
	v36.LayoutOrder = v38
	local v_u_39 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PausePvpStatus",
		["text"] = "Reading the pause state ...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p14,
		["color"] = v_u_20.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v40 = v18.order
	local v41
	if type(v40) == "function" then
		v41 = v18.order()
	else
		v27 = v35 + 1
		v41 = v27
		v35 = v27
	end
	v_u_39.LayoutOrder = v41
	local v_u_42 = v_u_4.new("Frame", {
		["Name"] = "PausePvpControls",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(v31.w, v31.h)
	}, p14)
	local v43 = v18.order
	local v44
	if type(v43) == "function" then
		v44 = v18.order()
	else
		v27 = v35 + 1
		v44 = v27
	end
	v_u_42.LayoutOrder = v44
	local v_u_45 = nil
	local v_u_46 = nil
	local _, v50 = v_u_4.input({
		["parent"] = nil,
		["name"] = "PausePvpMsg",
		["size"] = nil,
		["position"] = nil,
		["placeholder"] = "Message for the players (140 characters, empty = standard)",
		["onChange"] = nil,
		["parent"] = v_u_42,
		["size"] = UDim2.fromOffset(v31.input.w, v31.input.h),
		["position"] = UDim2.fromOffset(v31.input.x, v31.input.y),
		["onChange"] = function(p47) -- name: onChange
			-- upvalues: (ref) v_u_46, (ref) v_u_6, (ref) v_u_45, (ref) v_u_4, (ref) v_u_5
			if v_u_46 == nil then
				return
			else
				local v48, v49 = v_u_6.clamp(p47)
				if v48 == p47 then
					if v_u_45 ~= nil then
						v_u_4.setText(v_u_45, ("%d/%d"):format(v49, v_u_5.MSG_MAX))
					end
				else
					v_u_46.Text = v48
				end
			end
		end
	})
	v_u_46 = v50
	v_u_45 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PausePvpCount",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_42,
		["text"] = ("0/%d"):format(v_u_5.MSG_MAX),
		["color"] = v_u_20.muted,
		["size"] = UDim2.fromOffset(v31.counter.w, v31.counter.h),
		["position"] = UDim2.fromOffset(v31.counter.x, v31.counter.y)
	})
	local v_u_51 = false
	local v_u_52 = "none"
	local v_u_53 = nil
	local function v_u_63(p54) -- name: take
		-- upvalues: (ref) v_u_52, (ref) v_u_53, (ref) v_u_4, (copy) v_u_39, (copy) v_u_20, (copy) v_u_24, (ref) v_u_51
		if type(p54) == "table" then
			v_u_52 = p54.ok == true and "ok" or "bad"
			local v55 = p54.data
			if type(v55) == "table" then
				local v56 = p54.data.paused
				if type(v56) == "boolean" then
					v_u_53 = p54.data.paused
				end
			end
			local v57 = p54.msg
			local v58
			if type(v57) == "string" and p54.msg ~= "" then
				v58 = p54.msg
			else
				v58 = p54.ok == true and "Done." or "Refused or failed."
			end
			local v59 = p54.ok ~= true
			v_u_4.setText(v_u_39, v58)
			local v60 = v_u_39
			local v61
			if v_u_53 == true or v59 == true then
				v61 = v_u_20.danger
			elseif v_u_53 == false then
				v61 = v_u_20.success
			else
				v61 = v_u_20.text2
			end
			v60.TextColor3 = v61
		else
			v_u_52 = "bad"
			v_u_4.setText(v_u_39, "The server did not answer.")
			local v62 = v_u_39
			local _ = v_u_53 == true
			v62.TextColor3 = v_u_20.danger
		end
		if v_u_24 then
			v_u_24:SetAttribute("FilmPvpPause", ("busy=%d|last=%s|paused=%s"):format(v_u_51 and 1 or 0, v_u_52, v_u_53 == true and "1" or (v_u_53 == false and "0" or "?")))
		end
	end
	local function v_u_71(p64, p65) -- name: call
		-- upvalues: (ref) v_u_51, (copy) p_u_15, (ref) v_u_4, (copy) v_u_39, (ref) v_u_53, (copy) v_u_20, (copy) v_u_24, (ref) v_u_52, (ref) v_u_28, (copy) v_u_63
		if v_u_51 then
			return
		else
			local v66 = p_u_15
			if type(v66) == "function" then
				v_u_51 = true
				v_u_4.setText(v_u_39, p65)
				local v67 = v_u_39
				local v68
				if v_u_53 == true then
					v68 = v_u_20.danger
				elseif v_u_53 == false then
					v68 = v_u_20.success
				else
					v68 = v_u_20.text2
				end
				v67.TextColor3 = v68
				if v_u_24 then
					v_u_24:SetAttribute("FilmPvpPause", ("busy=%d|last=%s|paused=%s"):format(v_u_51 and 1 or 0, v_u_52, v_u_53 == true and "1" or (v_u_53 == false and "0" or "?")))
				end
				p_u_15("pvp.pause", p64, function(p69)
					-- upvalues: (ref) v_u_51, (ref) v_u_28, (ref) v_u_63
					v_u_51 = false
					if v_u_28 then
						v_u_63(p69)
					end
				end)
			else
				v_u_4.setText(v_u_39, "No connection to the server.")
				local v70 = v_u_39
				local _ = v_u_53 == true
				v70.TextColor3 = v_u_20.danger
			end
		end
	end
	local function v72() -- name: pause
		-- upvalues: (ref) v_u_6, (ref) v_u_46, (copy) v_u_71
		v_u_71({
			["action"] = "pause",
			["msg"] = nil,
			["msg"] = v_u_6.clamp(not v_u_46 and "" or v_u_46.Text)
		}, "Pausing PVP ...")
	end
	local function v73() -- name: resume
		-- upvalues: (copy) v_u_71
		v_u_71({
			["action"] = "resume"
		}, "Resuming PVP ...")
	end
	local function v74() -- name: status
		-- upvalues: (copy) v_u_71
		v_u_71({
			["action"] = "status"
		}, "Reading the pause state ...")
	end
	local function v80(p75, p76, p77, p78, p79) -- name: mk
		-- upvalues: (ref) v_u_4, (copy) v_u_42
		return v_u_4.button({
			["parent"] = v_u_42,
			["name"] = p77,
			["text"] = p75,
			["kind"] = p76,
			["size"] = UDim2.fromOffset(p78.w, p78.h),
			["position"] = UDim2.fromOffset(p78.x, p78.y),
			["maxTextWidth"] = p78.w - 12,
			["onClick"] = p79
		})
	end
	v80("Pause PVP", "danger", "PausePvpPause", v31.pause, v72)
	v80("Resume PVP", "primary", "PausePvpResume", v31.resume, v73)
	if v18.noPoll ~= true then
		task.spawn(function()
			-- upvalues: (ref) v_u_28, (ref) v_u_6, (ref) v_u_51, (copy) v_u_26, (copy) v_u_63
			while v_u_28 do
				task.wait(v_u_6.POLL_SEC)
				if not v_u_28 then
					break
				end
				if v_u_51 then
					continue
				end
				local v81 = v_u_26
				if type(v81) ~= "function" then
					continue
				end
				v_u_26("pvp.pause", {
					["action"] = "status"
				}, function(p82)
					-- upvalues: (ref) v_u_28, (ref) v_u_51, (ref) v_u_63
					if v_u_28 and (not v_u_51 and type(p82) == "table") then
						v_u_63(p82)
					end
				end)
			end
		end)
	end
	if v_u_3:IsStudio() and v_u_24 then
		local v_u_86 = v_u_24:GetAttributeChangedSignal("FilmPvpPauseCmd"):Connect(function()
			-- upvalues: (copy) v_u_24, (ref) v_u_46, (ref) v_u_6, (copy) v_u_71
			local v83 = v_u_24:GetAttribute("FilmPvpPauseCmd")
			if type(v83) == "string" and v83 ~= "" then
				v_u_24:SetAttribute("FilmPvpPauseCmd", nil)
				local v84, v85 = string.match(v83, "^(%a+)%s*(.-)$")
				if v84 == "msg" then
					if v_u_46 then
						v_u_46.Text = v85
						return
					end
				else
					if v84 == "pause" then
						v_u_71({
							["action"] = "pause",
							["msg"] = nil,
							["msg"] = v_u_6.clamp(not v_u_46 and "" or v_u_46.Text)
						}, "Pausing PVP ...")
						return
					end
					if v84 == "resume" then
						v_u_71({
							["action"] = "resume"
						}, "Resuming PVP ...")
						return
					end
					if v84 == "status" then
						v_u_71({
							["action"] = "status"
						}, "Reading the pause state ...")
					end
				end
			end
		end)
		if v23 then
			v23.Destroying:Connect(function()
				-- upvalues: (copy) v_u_86
				v_u_86:Disconnect()
			end)
		end
	end
	if v_u_24 then
		v_u_24:SetAttribute("FilmPvpPause", ("busy=%d|last=%s|paused=%s"):format(v_u_51 and 1 or 0, v_u_52, v_u_53 == true and "1" or (v_u_53 == false and "0" or "?")))
	end
	task.defer(v74)
	return {
		["pause"] = v72,
		["resume"] = v73,
		["status"] = v74,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_28
			return v_u_28
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_51, (ref) v_u_52, (ref) v_u_53
			return {
				["busy"] = v_u_51,
				["last"] = v_u_52,
				["paused"] = v_u_53
			}
		end
	}
end
return v_u_6