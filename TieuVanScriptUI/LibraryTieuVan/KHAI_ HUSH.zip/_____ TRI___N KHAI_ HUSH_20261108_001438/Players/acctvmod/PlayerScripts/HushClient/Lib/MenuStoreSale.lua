-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreSale

local v_u_1 = game:GetService("RunService")
local v2 = {}
local v_u_3 = utf8.char(57346)
function v2.new(p4, p_u_5) -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v_u_6 = p4.ui
	local v_u_7 = p4.theme
	local v_u_8 = v_u_7.color
	local v_u_9 = p4.cctx
	local v_u_10 = v_u_9.shared.SaleRules
	local v_u_11 = v_u_9.lib.MenuStoreSaleLayout
	local v_u_12, v_u_13 = pcall(function()
		-- upvalues: (copy) v_u_9
		return v_u_9.lib.ServerClock
	end)
	local v_u_14, v_u_15 = pcall(function()
		-- upvalues: (copy) v_u_9
		return v_u_9.lib.KillCardBgFx
	end)
	local v_u_16 = {}
	local v_u_17 = true
	local v_u_18 = {}
	local v_u_19 = {}
	local v_u_20 = false
	local function v_u_21() -- name: nowSec
		-- upvalues: (copy) v_u_12, (copy) v_u_13
		if v_u_12 and (v_u_13 and v_u_13.now) then
			return v_u_13.now()
		else
			return os.time()
		end
	end
	function v_u_16.activeOf(p22, p23) -- name: activeOf
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_10
		if not p23 then
			if v_u_12 and (v_u_13 and v_u_13.now) then
				p23 = v_u_13.now()
			else
				p23 = os.time()
			end
		end
		local v24 = {}
		if type(p22) ~= "table" then
			return v24
		end
		for _, v25 in p22 do
			local v26
			if type(v25) == "table" then
				local v27 = v25.sale
				if type(v27) == "table" and (not v25.owned and (v25.enabled ~= false and not v25.offSale)) then
					local v28 = v_u_10.clientView
					local v29 = v25.sale
					local v30 = v25.price
					v26 = v28(v29, tonumber(v30), p23)
				else
					v26 = nil
				end
			else
				v26 = nil
			end
			if v26 == nil then
				continue
			end
			table.insert(v24, {
				["product"] = v25,
				["view"] = v26
			})
		end
		table.sort(v24, function(p31, p32)
			local v33 = p31.view.pct or -1
			local v34 = p32.view.pct or -1
			if v33 ~= v34 then
				return v34 < v33
			end
			local v35 = p31.view.ends or (1 / 0)
			local v36 = p32.view.ends or (1 / 0)
			if v35 ~= v36 then
				return v35 < v36
			end
			local v37 = p31.product.name
			local v38 = tostring(v37)
			local v39 = p32.product.name
			return v38 < tostring(v39)
		end)
		local v40 = {}
		for _, v41 in v24 do
			local v42 = v41.product
			table.insert(v40, v42)
		end
		return v40
	end
	local function v_u_51(p43, p44, p45, p46, p47, p48, p49) -- name: lab
		-- upvalues: (copy) v_u_6, (copy) v_u_7
		local v50 = v_u_6.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["textSize"] = nil,
			["color"] = nil,
			["align"] = nil,
			["size"] = nil,
			["position"] = nil,
			["fit"] = true,
			["track"] = false,
			["rich"] = nil,
			["parent"] = p43,
			["text"] = p44,
			["textSize"] = p45,
			["color"] = p46,
			["align"] = p48,
			["size"] = UDim2.fromOffset(p47.w, p47.h),
			["position"] = UDim2.fromOffset(p47.x, p47.y),
			["rich"] = p49
		})
		v50.FontFace = v_u_7.font.headingBold
		v50.ZIndex = 9
		return v50
	end
	function v_u_16.decorateCard(p52, p_u_53, p_u_54, p55) -- name: decorateCard
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6, (copy) v_u_8, (copy) v_u_51, (copy) v_u_19, (ref) v_u_3, (copy) v_u_18, (copy) p_u_5, (copy) v_u_21
		local v56
		if v_u_12 and (v_u_13 and v_u_13.now) then
			v56 = v_u_13.now()
		else
			v56 = os.time()
		end
		local v_u_57
		if type(p_u_53) == "table" then
			local v58 = p_u_53.sale
			if type(v58) == "table" and (not p_u_53.owned and (p_u_53.enabled ~= false and not p_u_53.offSale)) then
				local v59 = v_u_10.clientView
				local v60 = p_u_53.sale
				local v61 = p_u_53.price
				v_u_57 = v59(v60, tonumber(v61), v56)
			else
				v_u_57 = nil
			end
		else
			v_u_57 = nil
		end
		if v_u_57 == nil then
			return false
		end
		local v_u_62 = p55 or {}
		local v_u_63 = v_u_57.ends ~= nil
		local v77 = (function() -- name: plan
			-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) p_u_53, (ref) v_u_10, (copy) v_u_57, (ref) v_u_11, (copy) p_u_54, (copy) v_u_63, (ref) v_u_6, (copy) v_u_62
			local v64
			if v_u_12 and (v_u_13 and v_u_13.now) then
				v64 = v_u_13.now()
			else
				v64 = os.time()
			end
			local v65 = p_u_53
			local v66
			if type(v65) == "table" then
				local v67 = v65.sale
				if type(v67) == "table" and (not v65.owned and (v65.enabled ~= false and not v65.offSale)) then
					local v68 = v_u_10.clientView
					local v69 = v65.sale
					local v70 = v65.price
					v66 = v68(v69, tonumber(v70), v64)
				else
					v66 = nil
				end
			else
				v66 = nil
			end
			local v71 = v66 or v_u_57
			local v72 = v_u_11.tile
			local v73 = {
				["art"] = p_u_54.art,
				["buy"] = p_u_54.buy,
				["gift"] = p_u_54.gift,
				["hasEnds"] = v_u_63,
				["pct"] = v71.pct
			}
			local v74
			if v71.was == nil then
				v74 = nil
			else
				local v75 = v71.was
				v74 = "R$ " .. v_u_6.commas(v75)
			end
			v73.wasText = v74
			local v76
			if v_u_63 then
				v76 = v_u_10.TEXT.endsIn .. v_u_10.timerText(v_u_57.ends - v64)
			else
				v76 = nil
			end
			v73.countText = v76
			v73.ownTimer = v_u_62.timer ~= nil
			v73.hasTag = v_u_62.tag ~= nil
			v73.tagW = v_u_62.tagW
			v73.forceBand = v_u_62.force == true
			return v72(v73)
		end)()
		local v_u_78 = v_u_6.new("Frame", {
			["Name"] = "SaleDecor",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 8,
			["Size"] = UDim2.fromScale(1, 1)
		}, p52)
		v_u_78.Active = false
		local v79 = v_u_6.new("Frame", {
			["Name"] = "SaleBand",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 8,
			["BackgroundColor3"] = v_u_8.danger,
			["Position"] = UDim2.fromOffset(v77.band.x, v77.band.y),
			["Size"] = UDim2.fromOffset(v77.band.w, v77.band.h)
		}, v_u_78)
		v_u_6.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 9,
			["BackgroundColor3"] = v_u_8.accent,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v79)
		v_u_51(v_u_78, v77.label.text, v_u_11.LABEL_SIZE, v_u_8.text, v77.label.rect, nil).Name = "SaleLabel"
		if v77.pill then
			local v80 = v_u_6.new("Frame", {
				["Name"] = "SalePill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 9,
				["BackgroundColor3"] = v_u_8.accent,
				["Position"] = UDim2.fromOffset(v77.pill.rect.x, v77.pill.rect.y),
				["Size"] = UDim2.fromOffset(v77.pill.rect.w, v77.pill.rect.h)
			}, v_u_78)
			v_u_6.corner(v80, 4)
			local v81 = v_u_51(v80, v77.pill.text, v_u_11.PILL_SIZE, v_u_8.ink, v_u_11.rect(0, 0, v77.pill.rect.w, v77.pill.rect.h), "center")
			v81.Name = "Percent"
			v81.Position = UDim2.fromScale(0, 0)
			v81.Size = UDim2.fromScale(1, 1)
			local v82 = v_u_6.new("UIScale", {
				["Name"] = "Pulse",
				["Scale"] = 1
			}, v80)
			local v83 = v_u_19
			table.insert(v83, v82)
		end
		local v_u_84
		if v77.old and v_u_57.was ~= nil then
			local v85 = v_u_51
			local v86 = v_u_57.was
			local v87 = ("<s><font face=\"GothamBold\">%s</font> %s</s>"):format(v_u_3, v_u_6.commas(v86))
			local v88 = v_u_11.OLD_SIZE
			local v89
			if v77.old.where == "band" then
				v89 = v_u_8.text
			else
				v89 = v_u_8.text2
			end
			v_u_84 = v85(v_u_78, v87, v88, v89, v77.old.rect, v77.old.where == "beside" and "right" or nil, true)
			v_u_84.Name = "SaleOld"
			v_u_84.TextTransparency = v77.old.where == "band" and 0.15 or 0
		else
			v_u_84 = nil
		end
		local v_u_90
		if v77.countdown then
			v_u_90 = v_u_51(v_u_78, v77.countdown.text, v_u_11.COUNT_SIZE, v_u_8.accent, v77.countdown.rect, "right")
			v_u_90.Name = "SaleCountdown"
		else
			v_u_90 = nil
		end
		if v77.tagY and v_u_62.tag then
			local v91 = v_u_62.tag
			if typeof(v91) == "Instance" then
				v_u_62.tag.Position = UDim2.fromOffset(10, v77.tagY)
				v_u_62.tag.ZIndex = 10
			end
		end
		if v77.timerY and v_u_62.timer then
			local v92 = v_u_62.timer
			if typeof(v92) == "Instance" then
				v_u_62.timer.Position = UDim2.new(1, -10, 0, v77.timerY)
				v_u_62.timer.ZIndex = 10
			end
		end
		for _, v93 in p52:GetChildren() do
			if not v93:IsA("UIStroke") then
				continue
			end
			v93.Color = v_u_8.accent
		end
		local v_u_104 = {
			["update"] = function(p94) -- name: update
				-- upvalues: (copy) p_u_53, (ref) v_u_10, (copy) v_u_78, (ref) v_u_84, (ref) v_u_90, (copy) v_u_57, (ref) v_u_8
				local v95 = p_u_53
				local v96
				if type(v95) == "table" then
					local v97 = v95.sale
					if type(v97) == "table" and (not v95.owned and (v95.enabled ~= false and not v95.offSale)) then
						local v98 = v_u_10.clientView
						local v99 = v95.sale
						local v100 = v95.price
						v96 = v98(v99, tonumber(v100), p94)
					else
						v96 = nil
					end
				else
					v96 = nil
				end
				if v96 == nil then
					v_u_78.Visible = false
				else
					if v_u_84 ~= nil then
						v_u_84.Visible = v96.was ~= nil
					end
					if v_u_90 ~= nil and v_u_57.ends ~= nil then
						local v101 = v_u_57.ends - p94
						v_u_90.Text = v_u_10.TEXT.endsIn .. v_u_10.timerText(v101)
						local v102 = v_u_90
						local v103
						if v_u_10.tone(v101) == "normal" then
							v103 = v_u_8.accent
						else
							v103 = v_u_8.danger
						end
						v102.TextColor3 = v103
					end
				end
			end
		}
		local v105 = v_u_18
		table.insert(v105, v_u_104)
		if p_u_5.onPrice ~= nil then
			p_u_5.onPrice(p_u_53, function()
				-- upvalues: (copy) v_u_104, (ref) v_u_21
				v_u_104.update(v_u_21())
			end)
		end
		v_u_104.update(v56)
		return true
	end
	function v_u_16.detailStrip(p106, p_u_107, p108, p109) -- name: detailStrip
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6, (copy) v_u_8, (copy) v_u_51, (ref) v_u_3, (copy) v_u_18, (copy) p_u_5, (copy) v_u_21
		local v110
		if v_u_12 and (v_u_13 and v_u_13.now) then
			v110 = v_u_13.now()
		else
			v110 = os.time()
		end
		local v_u_111
		if type(p_u_107) == "table" then
			local v112 = p_u_107.sale
			if type(v112) == "table" and (not p_u_107.owned and (p_u_107.enabled ~= false and not p_u_107.offSale)) then
				local v113 = v_u_10.clientView
				local v114 = p_u_107.sale
				local v115 = p_u_107.price
				v_u_111 = v113(v114, tonumber(v115), v110)
			else
				v_u_111 = nil
			end
		else
			v_u_111 = nil
		end
		if v_u_111 == nil then
			return 0
		end
		local v116 = v_u_111.ends ~= nil
		local v117 = v_u_11.strip
		local v118 = {
			["hasEnds"] = v116,
			["pct"] = v_u_111.pct
		}
		local v119
		if v_u_111.was == nil then
			v119 = nil
		else
			local v120 = v_u_111.was
			v119 = "R$ " .. v_u_6.commas(v120)
		end
		v118.wasText = v119
		local v121
		if v116 then
			v121 = v_u_10.TEXT.endsIn .. v_u_10.timerText(v_u_111.ends - v110)
		else
			v121 = nil
		end
		v118.countText = v121
		v118.text = v_u_111.text
		local v122 = v117(p108, v118)
		local v_u_123 = v_u_6.new("Frame", {
			["Name"] = "SaleStrip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.82,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_8.danger,
			["Position"] = UDim2.fromOffset(0, p109),
			["Size"] = UDim2.fromOffset(p108, v122.h)
		}, p106)
		v_u_6.stroke(v_u_123, v_u_8.danger, 1, 0.1)
		v_u_6.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_8.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v_u_123)
		local v124 = v_u_51
		local v125 = v_u_123
		local v126
		if v116 then
			v126 = v_u_10.TEXT.stripLimited
		else
			v126 = v_u_10.TEXT.stripOpen
		end
		local v127 = v124(v125, v126, 13, v_u_8.danger, v122.head, nil)
		v127.ZIndex = 3
		v127.Name = "SaleHead"
		local v128 = v_u_51(v_u_123, v122.big.text, 24, v_u_8.accent, v122.big.rect, nil)
		v128.ZIndex = 3
		v128.Name = "SaleBig"
		local v_u_129
		if v122.old and v_u_111.was ~= nil then
			local v130 = v_u_51
			local v131 = v_u_111.was
			v_u_129 = v130(v_u_123, ("<s><font face=\"GothamBold\">%s</font> %s</s>"):format(v_u_3, v_u_6.commas(v131)), 16, v_u_8.text2, v122.old.rect, nil, true)
			v_u_129.ZIndex = 3
			v_u_129.Name = "SaleOld"
		else
			v_u_129 = nil
		end
		local v_u_132
		if v122.count then
			v_u_132 = v_u_51(v_u_123, v122.count.text, 12, v_u_8.accent, v122.count.rect, "right")
			v_u_132.ZIndex = 3
			v_u_132.Name = "SaleCountdown"
		else
			v_u_132 = nil
		end
		if v122.text then
			local v133 = v_u_6.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v_u_123,
				["text"] = v122.text.text,
				["color"] = v_u_8.text,
				["size"] = UDim2.fromOffset(v122.text.rect.w, v122.text.rect.h),
				["position"] = UDim2.fromOffset(v122.text.rect.x, v122.text.rect.y)
			})
			v133.Name = "SaleText"
			v133.ZIndex = 3
			v133.RichText = false
		end
		local v_u_144 = {
			["update"] = function(p134) -- name: update
				-- upvalues: (copy) p_u_107, (ref) v_u_10, (copy) v_u_123, (ref) v_u_129, (ref) v_u_132, (copy) v_u_111, (ref) v_u_8
				local v135 = p_u_107
				local v136
				if type(v135) == "table" then
					local v137 = v135.sale
					if type(v137) == "table" and (not v135.owned and (v135.enabled ~= false and not v135.offSale)) then
						local v138 = v_u_10.clientView
						local v139 = v135.sale
						local v140 = v135.price
						v136 = v138(v139, tonumber(v140), p134)
					else
						v136 = nil
					end
				else
					v136 = nil
				end
				if v136 == nil then
					v_u_123.Visible = false
				else
					if v_u_129 ~= nil then
						v_u_129.Visible = v136.was ~= nil
					end
					if v_u_132 ~= nil and v_u_111.ends ~= nil then
						local v141 = v_u_111.ends - p134
						v_u_132.Text = v_u_10.TEXT.endsIn .. v_u_10.timerText(v141)
						local v142 = v_u_132
						local v143
						if v_u_10.tone(v141) == "normal" then
							v143 = v_u_8.accent
						else
							v143 = v_u_8.danger
						end
						v142.TextColor3 = v143
					end
				end
			end
		}
		local v145 = v_u_18
		table.insert(v145, v_u_144)
		if p_u_5.onPrice ~= nil then
			p_u_5.onPrice(p_u_107, function()
				-- upvalues: (copy) v_u_144, (ref) v_u_21
				v_u_144.update(v_u_21())
			end)
		end
		return v122.h
	end
	function v_u_16.saleRow(p146, p147, p148, p149, p150, p151) -- name: saleRow
		-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_6, (copy) v_u_8, (copy) v_u_10, (copy) v_u_12, (copy) v_u_13, (copy) v_u_18, (copy) p_u_5
		local v152 = #p147
		if v152 == 0 then
			return nil
		end
		local v153 = v_u_7.touch(40)
		local v154 = v_u_11.row(p148, {
			["cols"] = p149.cols,
			["cardW"] = p149.cardW,
			["cardH"] = p149.cardH,
			["n"] = v152,
			["touchH"] = v153
		})
		local v155 = v_u_6.new("Frame", {
			["Name"] = "SaleRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v154.h),
			["LayoutOrder"] = p151
		}, p146)
		v_u_6.new("Frame", {
			["Name"] = "Square",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_8.danger,
			["Position"] = UDim2.fromOffset(v154.square.x, v154.square.y),
			["Size"] = UDim2.fromOffset(v154.square.w, v154.square.h)
		}, v155)
		v_u_6.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v155,
			["text"] = v_u_10.TEXT.rowTitle,
			["position"] = UDim2.fromOffset(v154.title.x, v154.title.y),
			["size"] = UDim2.fromOffset(v154.title.w, v154.title.h)
		}).Name = "Title"
		local v_u_156 = nil
		local v157
		if v_u_12 and (v_u_13 and v_u_13.now) then
			v157 = v_u_13.now()
		else
			v157 = os.time()
		end
		for _, v158 in p147 do
			local v159
			if type(v158) == "table" then
				local v160 = v158.sale
				if type(v160) == "table" and (not v158.owned and (v158.enabled ~= false and not v158.offSale)) then
					local v161 = v_u_10.clientView
					local v162 = v158.sale
					local v163 = v158.price
					v159 = v161(v162, tonumber(v163), v157)
				else
					v159 = nil
				end
			else
				v159 = nil
			end
			if v159 == nil or (v159.ends == nil or v_u_156 ~= nil and v159.ends >= v_u_156) then
				continue
			end
			v_u_156 = v159.ends
		end
		local v_u_164 = ("%d item%s"):format(v152, v152 == 1 and "" or "s")
		local v_u_165 = v_u_6.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v155,
			["text"] = v_u_164,
			["color"] = v_u_8.text2,
			["position"] = UDim2.fromOffset(v154.count.x, v154.count.y),
			["size"] = UDim2.fromOffset(v154.count.w, v154.count.h)
		})
		v_u_165.Name = "Info"
		if v_u_156 ~= nil then
			local v167 = {
				["update"] = function(p166) -- name: update
					-- upvalues: (ref) v_u_156, (copy) v_u_165, (copy) v_u_164, (ref) v_u_10
					if v_u_156 ~= nil then
						v_u_165.Text = v_u_164 .. "  \194\183  first ends in " .. v_u_10.timerText(v_u_156 - p166)
					end
				end
			}
			local v168 = v_u_18
			table.insert(v168, v167)
			v167.update(v157)
		end
		if v154.seeAll then
			v_u_6.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["position"] = nil,
				["name"] = "SeeAll",
				["onClick"] = nil,
				["parent"] = v155,
				["text"] = v_u_10.TEXT.seeAll:format(v152),
				["height"] = v154.seeAll.h,
				["width"] = v154.seeAll.w,
				["position"] = UDim2.fromOffset(v154.seeAll.x, v154.seeAll.y),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_5
					if p_u_5.open ~= nil then
						p_u_5.open("SALE")
					end
				end
			})
		end
		for v169, v170 in v154.cards do
			p150(v155, p147[v169], v170, v169)
		end
		return v155
	end
	function v_u_16.tick() -- name: tick
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_18, (ref) v_u_20, (copy) p_u_5
		local v171
		if v_u_12 and (v_u_13 and v_u_13.now) then
			v171 = v_u_13.now()
		else
			v171 = os.time()
		end
		for _, v172 in v_u_18 do
			if v172.update == nil then
				continue
			end
			local v173 = v172.update
			pcall(v173, v171)
		end
		if not v_u_20 and p_u_5.onExpired ~= nil then
			for _, v174 in v_u_18 do
				if v174.endsAt == nil or v174.endsAt > v171 then
					continue
				end
				v_u_20 = true
				p_u_5.onExpired()
				return
			end
		end
	end
	function v_u_16.watchEnds(p175) -- name: watchEnds
		-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_10, (copy) v_u_18
		local v176 = nil
		if type(p175) == "table" then
			local v177
			if v_u_12 and (v_u_13 and v_u_13.now) then
				v177 = v_u_13.now()
			else
				v177 = os.time()
			end
			for _, v178 in p175 do
				local v179
				if type(v178) == "table" then
					local v180 = v178.sale
					if type(v180) == "table" and (not v178.owned and (v178.enabled ~= false and not v178.offSale)) then
						local v181 = v_u_10.clientView
						local v182 = v178.sale
						local v183 = v178.price
						v179 = v181(v182, tonumber(v183), v177)
					else
						v179 = nil
					end
				else
					v179 = nil
				end
				if v179 == nil or (v179.ends == nil or v176 ~= nil and v179.ends >= v176) then
					continue
				end
				v176 = v179.ends
			end
		end
		if v176 ~= nil then
			local v184 = v_u_18
			table.insert(v184, {
				["endsAt"] = v176
			})
		end
	end
	function v_u_16.reset() -- name: reset
		-- upvalues: (copy) v_u_18, (copy) v_u_19, (ref) v_u_20
		table.clear(v_u_18)
		table.clear(v_u_19)
		v_u_20 = false
	end
	local v_u_192 = v_u_1.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_19, (copy) p_u_5, (copy) v_u_14, (copy) v_u_15, (copy) v_u_11
		if #v_u_19 ~= 0 and (p_u_5.isVisible == nil or p_u_5.isVisible()) then
			local v185 = 1
			local v186
			if v_u_14 and (v_u_15 and v_u_15.reducedMotion) then
				local v187 = v_u_15.reducedMotion
				local v188
				v186, v188 = pcall(v187)
				if v186 then
					v186 = v188 == true
				end
			else
				v186 = false
			end
			if not v186 then
				local v189 = v_u_11.PULSE_MAX - 1
				local v190 = os.clock() * 2 * 3.141592653589793 / 1.6
				v185 = 1 + v189 * (math.sin(v190) * 0.5 + 0.5)
			end
			for _, v191 in v_u_19 do
				if v191.Parent == nil then
					continue
				end
				v191.Scale = v185
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_17, (copy) p_u_5, (copy) v_u_16
		while v_u_17 do
			if p_u_5.isVisible == nil or p_u_5.isVisible() then
				local v193 = v_u_16.tick
				pcall(v193)
			end
			task.wait(1)
		end
	end)
	function v_u_16.destroy() -- name: destroy
		-- upvalues: (ref) v_u_17, (copy) v_u_192, (copy) v_u_18, (copy) v_u_19
		v_u_17 = false
		v_u_192:Disconnect()
		table.clear(v_u_18)
		table.clear(v_u_19)
	end
	return v_u_16
end
return v2