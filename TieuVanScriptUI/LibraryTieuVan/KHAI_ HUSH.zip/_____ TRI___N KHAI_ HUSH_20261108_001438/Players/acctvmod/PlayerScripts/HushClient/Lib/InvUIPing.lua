-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIPing

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = v1.LocalPlayer
local v5 = {}
local function v_u_12(p6) -- name: worldPosOf
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v7 = p6.c
	local v8 = type(v7) == "table" and p6.c.sub == true and {
		["container"] = p6.c.parent,
		["item"] = {
			["uid"] = p6.c.bagUid,
			["id"] = p6.item.id
		}
	} or p6
	if v8.container == "ground" then
		for _, v9 in v_u_2:GetTagged("HushItem") do
			if not v9.Parent or (v9:GetAttribute("ItemUid") ~= v8.item.uid or not v9:IsA("Model")) then
				continue
			end
			return v9:GetPivot().Position
		end
	else
		for _, v10 in v_u_2:GetTagged("HushContainer") do
			if not v10.Parent or v10:GetAttribute("ContainerId") ~= v8.container then
				continue
			end
			if v10:IsA("Model") then
				return v10:GetPivot().Position
			end
			if not v10:IsA("BasePart") then
				continue
			end
			return v10.Position
		end
	end
	local v11 = v_u_4.Character
	if v11 then
		v11 = v11:FindFirstChild("HumanoidRootPart")
	end
	if v11 then
		return v11.Position
	else
		return nil
	end
end
local v_u_13 = 0
function v5.ping(p14, p15, p16) -- name: ping
	-- upvalues: (ref) v_u_13, (copy) v_u_2, (copy) v_u_12, (copy) v_u_3, (copy) v_u_4
	local v17 = os.clock()
	if v17 - v_u_13 < 0.6 then
		return false
	end
	if p14.container ~= "ground" then
		for _, v18 in v_u_2:GetTagged("HushContainer") do
			if not v18.Parent or (v18:GetAttribute("ContainerId") ~= p14.container or v18:GetAttribute("Cargo") ~= true) then
				continue
			end
			p16("What lies in a cargo crate is private, so it cannot be pinged.", "info")
			return false
		end
	end
	local v19 = v_u_12(p14)
	if not (p15 and (p15.pingItem and v19)) then
		p16("You cannot ping this item.", "info")
		return false
	end
	v_u_13 = v17
	local v20 = "Ground"
	local v21 = p14.c
	if type(v21) == "table" and p14.c.sub == true then
		local v22 = p14.c.label or "Bag"
		v20 = tostring(v22)
	elseif p14.container ~= "ground" then
		v20 = "Nearby"
		for _, v_u_23 in v_u_2:GetTagged("HushContainer") do
			if not v_u_23.Parent or v_u_23:GetAttribute("ContainerId") ~= p14.container then
				continue
			end
			local v24 = v_u_23:GetAttribute("Label")
			if type(v24) == "string" and v24 ~= "" then
				v20 = v24
			else
				local function v25()
					-- upvalues: (ref) v_u_3, (copy) v_u_23
					return require(v_u_3:WaitForChild("LootTables")).label(v_u_23:GetAttribute("Kind"))
				end
				local v26, v27 = pcall(v25)
				if v26 and type(v27) == "string" then
					if v27 ~= "" then
						v20 = v27
					end
				end
			end
		end
	end
	local v28 = p15.pingItem
	local v29 = p14.item.id
	local v30 = pcall(v28, v29, v19, v20)
	if v30 then
		v_u_4:SetAttribute("InvUILastPing", p14.item.id)
	end
	return v30
end
return v5