-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TextFitting

local v_u_22 = {
	["EM"] = 0.6,
	["pickSize"] = function(p1, p2, p3, p4) -- name: pickSize
		local v5 = math.max(p3, p4)
		local v6 = math.min(p3, p4)
		local v7 = math.floor(v5)
		while v6 <= v7 do
			if p1(v7) <= p2 + 0.01 then
				return v7, true
			end
			v7 = v7 - 1
		end
		return v6, false
	end,
	["estimate"] = function(p8, p9) -- name: estimate
		-- upvalues: (copy) v_u_22
		return #p8 * p9 * v_u_22.EM
	end,
	["fit"] = function(p_u_10, p11, p12, p13) -- name: fit
		-- upvalues: (copy) v_u_22
		for _, v14 in p_u_10:GetChildren() do
			if not v14:IsA("UITextSizeConstraint") then
				continue
			end
			v14:Destroy()
		end
		p_u_10.TextScaled = false
		p_u_10.TextWrapped = false
		p_u_10.TextTruncate = Enum.TextTruncate.None
		local v_u_15 = p_u_10.Text
		local v16 = p_u_10:GetAttribute("FitFrom")
		if type(v16) ~= "number" then
			v16 = p_u_10.TextSize
		end
		p_u_10:SetAttribute("FitFrom", v16)
		local v19 = p13 or function(p17)
			-- upvalues: (copy) p_u_10, (ref) v_u_22, (copy) v_u_15
			p_u_10.TextSize = p17
			local v18 = p_u_10.TextBounds.X
			if v18 > 0 then
				return v18
			else
				return v_u_22.estimate(v_u_15, p17)
			end
		end
		local v20, v21 = v_u_22.pickSize(v19, p11, v16, p12 or 9)
		p_u_10.TextSize = v20
		p_u_10.TextTruncate = Enum.TextTruncate.AtEnd
		return v20, v21
	end
}
return v_u_22