-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmEntryLogic

local v_u_37 = {
	["PAUSE"] = 1.5,
	["new"] = function(p_u_1) -- name: new
		-- upvalues: (copy) v_u_37
		local v_u_36 = {
			["sequence"] = function() -- name: sequence
				-- upvalues: (copy) p_u_1
				local v2 = {}
				for _, v3 in p_u_1.KINDS do
					local v4 = v3.id
					table.insert(v2, v4)
				end
				return v2
			end,
			["durationText"] = function(p5, p6) -- name: durationText
				-- upvalues: (copy) p_u_1
				return string.format("%.1f s", p_u_1.duration(p5, p6))
			end,
			["auditLine"] = function(p7, p8) -- name: auditLine
				-- upvalues: (copy) p_u_1
				local v9 = p_u_1.TEXTS
				if p7 == nil then
					return "Audit at this marker: not checked yet. Press CHECK AUDIT."
				end
				if p7 == "ok" or p8 == "plain" then
					return v9.f8AuditOk
				end
				local v10 = string.match(p7, "^blocked:%s*(.-)%s*$")
				local v11 = (v10 == nil or v10 == "") and "unknown" or v10
				local v12 = string.format(v9.f8AuditBlocked, v11)
				if p8 == "walk_in" then
					v12 = string.gsub(v12, "WALK IN", "PLAIN")
				end
				return v12
			end,
			["progressText"] = function(p13, p14, p15, p16) -- name: progressText
				-- upvalues: (copy) p_u_1
				local v17 = p_u_1.kindById(p15)
				local v18 = string.format
				local v19 = p_u_1.TEXTS.f8Progress
				local v20
				if v17 then
					v20 = v17.name
				else
					v20 = string.upper((tostring(p15)))
				end
				return v18(v19, p13, p14, v20, p_u_1.duration(p15, p16))
			end,
			["markerOptions"] = function(p21, p22) -- name: markerOptions
				-- upvalues: (copy) p_u_1
				local v23 = {
					{
						["id"] = "here",
						["text"] = nil,
						["text"] = p_u_1.TEXTS.f8Here
					}
				}
				local v24 = {}
				local v25 = {}
				if type(p22) == "table" then
					for _, v26 in p22 do
						if type(v26) ~= "table" then
							continue
						end
						local v27 = v26.id
						if type(v27) ~= "string" or (v26.id == "" or (v26.id == "here" or v25[v26.id])) then
							continue
						end
						v25[v26.id] = true
						local v28 = v26.id
						table.insert(v24, v28)
					end
				end
				table.sort(v24)
				for _, v29 in v24 do
					local v30 = {
						["id"] = v29,
						["text"] = p_u_1.markerName(p21, v29)
					}
					table.insert(v23, v30)
				end
				return v23
			end,
			["totalSeconds"] = function(p31) -- name: totalSeconds
				-- upvalues: (copy) v_u_36, (copy) p_u_1, (ref) v_u_37
				local v32 = v_u_36.sequence()
				local v33 = 0
				for v34, v35 in v32 do
					v33 = v33 + p_u_1.duration(v35, p31)
					if v34 >= #v32 then
						continue
					end
					v33 = v33 + v_u_37.PAUSE
				end
				return v33
			end
		}
		return v_u_36
	end
}
return v_u_37