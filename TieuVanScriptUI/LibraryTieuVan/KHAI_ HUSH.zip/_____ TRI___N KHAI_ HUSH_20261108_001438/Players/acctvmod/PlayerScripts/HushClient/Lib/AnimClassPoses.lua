-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimClassPoses

local v_u_1 = math.rad
local v_u_2 = {}
local v3 = {
	["hold"] = "rifle",
	["poses"] = nil,
	["two"] = nil,
	["leftRoll"] = -70,
	["support"] = Vector3.new(0, 0.12, -1.22),
	["reload"] = nil,
	["maxShift"] = 1.1,
	["stance"] = nil,
	["poses"] = {
		["aim"] = {
			["x"] = 0.07,
			["y"] = -0.23,
			["z"] = -0.54,
			["yaw"] = 4,
			["pitch"] = -8,
			["roll"] = -8
		},
		["ready"] = {
			["x"] = -0.22,
			["y"] = -0.06,
			["z"] = -0.79,
			["yaw"] = 30,
			["pitch"] = -22,
			["roll"] = 8
		},
		["sprint"] = {
			["x"] = -0.66,
			["y"] = -0.29,
			["z"] = -1.02,
			["yaw"] = 60,
			["pitch"] = -24,
			["roll"] = -10
		},
		["sneak"] = {
			["x"] = 0.23,
			["y"] = -0.16,
			["z"] = -0.7,
			["yaw"] = 0,
			["pitch"] = 4,
			["roll"] = 4
		}
	},
	["two"] = {
		["ready"] = true,
		["aim"] = true,
		["sneak"] = true,
		["sprint"] = true
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0.08, -0.1, 0.07),
		["tilt"] = {
			["pitch"] = -29,
			["yaw"] = 22,
			["roll"] = 22
		}
	},
	["stance"] = {
		["aim"] = -0.57,
		["ready"] = -0.58
	}
}
v_u_2.rifle = v3
local function v12(p4, p5) -- name: derive
	-- upvalues: (copy) v_u_2
	local v6 = v_u_2[p4]
	local v7 = table.clone(v6)
	v7.poses = {}
	for v8, v9 in v6.poses do
		v7.poses[v8] = table.clone(v9)
	end
	v7.stance = table.clone(v6.stance)
	v7.reload = table.clone(v6.reload)
	v7.reload.tilt = table.clone(v6.reload.tilt)
	for v10, v11 in p5 do
		v7[v10] = v11
	end
	return v7
end
local v13 = {
	["poses"] = nil,
	["support"] = Vector3.new(0, 0.1, -0.9),
	["stance"] = nil,
	["reload"] = nil,
	["poses"] = {
		["aim"] = {
			["x"] = 0.07,
			["y"] = -0.07,
			["z"] = -0.94,
			["yaw"] = 0,
			["pitch"] = 8,
			["roll"] = 0
		},
		["ready"] = {
			["x"] = -0.22,
			["y"] = 0.02,
			["z"] = -0.87,
			["yaw"] = 30,
			["pitch"] = -18,
			["roll"] = 8
		},
		["sprint"] = {
			["x"] = -0.74,
			["y"] = -0.53,
			["z"] = -1.02,
			["yaw"] = 60,
			["pitch"] = -24,
			["roll"] = -2
		},
		["sneak"] = {
			["x"] = 0.23,
			["y"] = -0.07,
			["z"] = -0.86,
			["yaw"] = 0,
			["pitch"] = 0,
			["roll"] = 0
		},
		["busy"] = {
			["x"] = 0.02,
			["y"] = -0.57,
			["z"] = -0.37,
			["yaw"] = 14,
			["pitch"] = -62,
			["roll"] = -12
		}
	},
	["stance"] = {
		["aim"] = -0.57,
		["ready"] = -0.58
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0.08, -0.1, 0.07),
		["tilt"] = {
			["pitch"] = -44,
			["yaw"] = 22,
			["roll"] = 10
		}
	}
}
v_u_2.smg = v12("rifle", v13)
local v14 = {
	["poses"] = nil,
	["support"] = Vector3.new(0, 0.12, -1),
	["poses"] = {
		["aim"] = {
			["x"] = -0.01,
			["y"] = -0.07,
			["z"] = -0.62,
			["yaw"] = 0,
			["pitch"] = -4,
			["roll"] = -8
		},
		["ready"] = {
			["x"] = -0.3,
			["y"] = 0.1,
			["z"] = -0.79,
			["yaw"] = 30,
			["pitch"] = -22,
			["roll"] = 4
		},
		["sprint"] = {
			["x"] = -0.98,
			["y"] = -0.29,
			["z"] = -1.02,
			["yaw"] = 56,
			["pitch"] = -28,
			["roll"] = -10
		},
		["sneak"] = {
			["x"] = 0.07,
			["y"] = -0.16,
			["z"] = -0.78,
			["yaw"] = 0,
			["pitch"] = 8,
			["roll"] = 8
		},
		["busy"] = {
			["x"] = -0.06,
			["y"] = -0.57,
			["z"] = -0.45,
			["yaw"] = 6,
			["pitch"] = -30,
			["roll"] = -4
		}
	}
}
v_u_2.sniper = v12("rifle", v14)
local v15 = {
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0.32, -0.02, -0.33),
		["tilt"] = {
			["pitch"] = -39,
			["yaw"] = 32,
			["roll"] = 28
		}
	}
}
v_u_2.bullpup = v12("rifle", v15)
local v16 = {
	["poses"] = {
		["aim"] = {
			["x"] = -0.25,
			["y"] = -0.39,
			["z"] = -0.62,
			["yaw"] = -4,
			["pitch"] = 0,
			["roll"] = 0
		},
		["ready"] = {
			["x"] = -0.46,
			["y"] = -0.14,
			["z"] = -0.87,
			["yaw"] = 30,
			["pitch"] = -10,
			["roll"] = 8
		},
		["sprint"] = {
			["x"] = -0.58,
			["y"] = -0.53,
			["z"] = -1.02,
			["yaw"] = 60,
			["pitch"] = -24,
			["roll"] = -10
		},
		["sneak"] = {
			["x"] = -0.09,
			["y"] = -0.16,
			["z"] = -0.62,
			["yaw"] = 0,
			["pitch"] = 0,
			["roll"] = 8
		}
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, -0.15, 0.2),
		["tilt"] = {
			["pitch"] = -18,
			["yaw"] = 10,
			["roll"] = 22
		}
	}
}
v_u_2.mg = v12("rifle", v16)
local v17 = {
	["poses"] = nil,
	["reload"] = nil,
	["bashRam"] = 0.6,
	["sway"] = 1,
	["equip"] = nil,
	["poses"] = {
		["aim"] = {
			["x"] = 0.05,
			["y"] = -0.45,
			["z"] = -0.85,
			["yaw"] = -4,
			["pitch"] = 0,
			["roll"] = 0
		},
		["ready"] = {
			["x"] = -0.46,
			["y"] = -0.92,
			["z"] = -0.87,
			["yaw"] = 30,
			["pitch"] = -10,
			["roll"] = 8
		},
		["sprint"] = {
			["x"] = -0.58,
			["y"] = -0.95,
			["z"] = -1.02,
			["yaw"] = 60,
			["pitch"] = -16,
			["roll"] = -14
		},
		["sneak"] = {
			["x"] = -0.09,
			["y"] = -0.75,
			["z"] = -0.62,
			["yaw"] = 0,
			["pitch"] = 0,
			["roll"] = 8
		},
		["busy"] = {
			["x"] = 0.34,
			["y"] = -0.89,
			["z"] = -0.61,
			["yaw"] = 14,
			["pitch"] = -38,
			["roll"] = 4
		}
	},
	["reload"] = {
		["kind"] = "rotary",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, -0.2, 0.12),
		["tilt"] = {
			["pitch"] = -4,
			["yaw"] = 0,
			["roll"] = 6
		}
	},
	["equip"] = {
		["dur"] = 1,
		["from"] = nil,
		["from"] = {
			["x"] = 0.85,
			["y"] = -0.3,
			["z"] = 0.45,
			["yaw"] = -20,
			["pitch"] = 24,
			["roll"] = 10
		}
	}
}
v_u_2.rotary = v12("mg", v17)
local v18 = {
	["hold"] = "shotgun",
	["poses"] = nil,
	["stance"] = nil,
	["support"] = Vector3.new(0, 0.1, -1.3),
	["reload"] = nil,
	["poses"] = {
		["aim"] = {
			["x"] = -0.01,
			["y"] = 0.01,
			["z"] = -1.07,
			["yaw"] = 4,
			["pitch"] = 4,
			["roll"] = 4
		},
		["ready"] = {
			["x"] = -0.14,
			["y"] = -0.14,
			["z"] = -0.67,
			["yaw"] = 30,
			["pitch"] = -6,
			["roll"] = 8
		},
		["sprint"] = {
			["x"] = -0.5,
			["y"] = -0.13,
			["z"] = -1.02,
			["yaw"] = 60,
			["pitch"] = -16,
			["roll"] = -10
		},
		["sneak"] = {
			["x"] = 0.06,
			["y"] = -0.18,
			["z"] = -1.17,
			["yaw"] = 2,
			["pitch"] = 1,
			["roll"] = -7
		},
		["busy"] = {
			["x"] = -0.06,
			["y"] = -0.73,
			["z"] = -0.45,
			["yaw"] = 22,
			["pitch"] = -54,
			["roll"] = 0
		}
	},
	["stance"] = {
		["aim"] = -0.57,
		["ready"] = -0.58
	},
	["reload"] = {
		["kind"] = "single",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, -0.15, 0.2),
		["port"] = Vector3.new(0, -0.3, -0.45),
		["tilt"] = {
			["pitch"] = -24,
			["yaw"] = 12,
			["roll"] = 35
		}
	}
}
v_u_2.shotgun = v12("rifle", v18)
v_u_2.launcher = v12("shotgun", {})
local v19 = {
	["hold"] = "pistol",
	["poses"] = nil,
	["two"] = nil,
	["leftRoll"] = 12,
	["support"] = Vector3.new(-0.2, -0.06, 0.1),
	["reload"] = nil,
	["maxShift"] = 0.9,
	["stance"] = nil,
	["poses"] = {
		["aim"] = {
			["x"] = -0.65,
			["y"] = -0.22,
			["z"] = -1.37,
			["yaw"] = 0,
			["pitch"] = 0,
			["roll"] = 0
		},
		["ready"] = {
			["x"] = -0.59,
			["y"] = -0.67,
			["z"] = -1.03,
			["yaw"] = 4,
			["pitch"] = -28,
			["roll"] = 0
		},
		["sprint"] = {
			["x"] = -0.41,
			["y"] = -0.7,
			["z"] = -0.94,
			["yaw"] = 6,
			["pitch"] = -70,
			["roll"] = 0
		},
		["sneak"] = {
			["x"] = -0.61,
			["y"] = -0.46,
			["z"] = -1.04,
			["yaw"] = 0,
			["pitch"] = -4,
			["roll"] = 0
		}
	},
	["two"] = {
		["ready"] = true,
		["aim"] = true,
		["sneak"] = true
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, 0, 0.1),
		["magWell"] = Vector3.new(0, -0.35, 0.08),
		["tilt"] = {
			["pitch"] = -22,
			["yaw"] = 8,
			["roll"] = 24
		}
	},
	["stance"] = {
		["aim"] = 0,
		["ready"] = 0
	}
}
v_u_2.pistol = v19
local v20 = {
	["poses"] = {
		["aim"] = {
			["x"] = -0.65,
			["y"] = -0.22,
			["z"] = -1.37,
			["yaw"] = 0,
			["pitch"] = 0,
			["roll"] = 0
		},
		["ready"] = {
			["x"] = -0.59,
			["y"] = -0.67,
			["z"] = -1.03,
			["yaw"] = 4,
			["pitch"] = -28,
			["roll"] = 0
		},
		["sprint"] = {
			["x"] = -0.41,
			["y"] = -0.78,
			["z"] = -0.7,
			["yaw"] = 2,
			["pitch"] = -50,
			["roll"] = -4
		},
		["sneak"] = {
			["x"] = -0.61,
			["y"] = -0.46,
			["z"] = -1.04,
			["yaw"] = 0,
			["pitch"] = -4,
			["roll"] = 0
		}
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, 0, 0.12),
		["magWell"] = Vector3.new(0, -0.05, -0.3),
		["tilt"] = {
			["pitch"] = -30,
			["yaw"] = 10,
			["roll"] = 30
		}
	}
}
v_u_2.revolver = v12("pistol", v20)
local v21 = {
	["hold"] = "melee1h",
	["poses"] = nil,
	["two"] = nil,
	["leftRoll"] = 0,
	["support"] = Vector3.new(0, 0, 0),
	["reload"] = nil,
	["maxShift"] = 0.7,
	["stance"] = nil,
	["poses"] = {
		["ready"] = {
			["x"] = 0.3,
			["y"] = -1,
			["z"] = -0.5,
			["yaw"] = -8,
			["pitch"] = 38,
			["roll"] = 0
		},
		["aim"] = {
			["x"] = 0.05,
			["y"] = -0.62,
			["z"] = -0.95,
			["yaw"] = 8,
			["pitch"] = 58,
			["roll"] = 0
		},
		["sprint"] = {
			["x"] = 0.45,
			["y"] = -0.95,
			["z"] = -0.3,
			["yaw"] = -10,
			["pitch"] = 62,
			["roll"] = 0
		}
	},
	["two"] = {},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, 0, 0),
		["tilt"] = {
			["pitch"] = 0,
			["yaw"] = 0,
			["roll"] = 0
		}
	},
	["stance"] = {
		["aim"] = 0,
		["ready"] = 0
	}
}
v_u_2.melee1h = v21
local v22 = {
	["hold"] = "melee2h",
	["poses"] = nil,
	["two"] = nil,
	["leftRoll"] = 0,
	["support"] = Vector3.new(0, 0, 0.55),
	["reload"] = nil,
	["maxShift"] = 0.7,
	["stance"] = nil,
	["poses"] = {
		["ready"] = {
			["x"] = -0.5,
			["y"] = -0.85,
			["z"] = -1.05,
			["yaw"] = 12,
			["pitch"] = 60,
			["roll"] = 0
		},
		["aim"] = {
			["x"] = -0.55,
			["y"] = -0.6,
			["z"] = -1.05,
			["yaw"] = 20,
			["pitch"] = 66,
			["roll"] = 0
		},
		["sprint"] = {
			["x"] = -0.45,
			["y"] = -0.8,
			["z"] = -0.85,
			["yaw"] = 30,
			["pitch"] = 68,
			["roll"] = 0
		},
		["busy"] = {
			["x"] = -0.66,
			["y"] = -0.85,
			["z"] = -1.21,
			["yaw"] = 0,
			["pitch"] = 68,
			["roll"] = 0
		}
	},
	["two"] = {
		["ready"] = true,
		["aim"] = true,
		["sprint"] = true
	},
	["reload"] = {
		["kind"] = "mag",
		["tilt"] = nil,
		["shift"] = Vector3.new(0, 0, 0),
		["tilt"] = {
			["pitch"] = 0,
			["yaw"] = 0,
			["roll"] = 0
		}
	},
	["stance"] = {
		["aim"] = 0,
		["ready"] = 0
	}
}
v_u_2.melee2h = v22
local v23 = {
	["x"] = -0.06,
	["y"] = -0.57,
	["z"] = -0.37,
	["yaw"] = 18,
	["pitch"] = -50,
	["roll"] = -4
}
local v24 = {
	["x"] = -0.35,
	["y"] = -0.75,
	["z"] = -0.55,
	["yaw"] = 6,
	["pitch"] = -45,
	["roll"] = 0
}
local v_u_25 = {}
for v26, v27 in v_u_2 do
	if v27.poses.busy ~= nil or string.find(v26, "melee", 1, true) ~= nil then
		continue
	end
	local v28 = v27.poses
	local v29 = table.clone
	local v30
	if v27.hold == "pistol" then
		v30 = v24
	else
		v30 = v23
	end
	v28.busy = v29(v30)
end
v_u_25.CLASSES = v_u_2
v_u_25.TWIN_SHIFT = 0.2
v_u_25.TWIN_YAW = 3
local v_u_31 = {}
for _, v32 in { "pistol", "revolver" } do
	local v33 = v_u_2[v32]
	local v34 = table.clone(v33)
	v34.poses = {}
	for v35, v36 in v33.poses do
		local v37 = table.clone(v36)
		v37.x = v37.x + v_u_25.TWIN_SHIFT
		v37.yaw = v37.yaw + v_u_25.TWIN_YAW
		v34.poses[v35] = v37
	end
	v34.two = {}
	v34.stance = table.clone(v33.stance)
	v34.reload = table.clone(v33.reload)
	v34.reload.tilt = table.clone(v33.reload.tilt)
	v_u_31[v32 .. "_twin"] = v34
end
v_u_25.TWIN_SPECS = v_u_31
function v_u_25.twinName(p38) -- name: twinName
	-- upvalues: (copy) v_u_31
	if v_u_31[p38 .. "_twin"] == nil then
		return nil
	else
		return p38 .. "_twin"
	end
end
function v_u_25.mirrorGrip(p39, p40, p41) -- name: mirrorGrip
	local v42, v43, v44, v45, v46, v47, v48, v49, v50, v51, v52, v53 = p39:ToObjectSpace(p40):GetComponents()
	return p39 * CFrame.new(p41 * 2 - v42, v43, v44, v45, -v46, -v47, -v48, v49, v50, -v51, v52, v53)
end
local v54 = {
	["revolver_357"] = {
		["class"] = "revolver"
	},
	["rifle_aug"] = {
		["class"] = "bullpup"
	},
	["melee_axe"] = {
		["slide"] = 0.5,
		["shift"] = Vector3.new(0, 0, -0.08)
	},
	["melee_nailbat"] = {
		["shift"] = Vector3.new(0, 0, -0.08)
	}
}
local v55 = {
	["poses"] = {
		["ready"] = {
			["x"] = 0.34,
			["y"] = -1.1,
			["z"] = -0.5,
			["yaw"] = -6,
			["pitch"] = 12,
			["roll"] = 0
		},
		["aim"] = {
			["x"] = 0.1,
			["y"] = -0.74,
			["z"] = -0.9,
			["yaw"] = 6,
			["pitch"] = 15,
			["roll"] = 0
		},
		["sprint"] = {
			["x"] = 0.45,
			["y"] = -1,
			["z"] = -0.4,
			["yaw"] = -10,
			["pitch"] = 18,
			["roll"] = 0
		}
	}
}
v54.melee_katana = v55
v_u_25.BY_ID = v54
local v_u_56 = {
	["pistol"] = "pistol",
	["rifle"] = "rifle",
	["shotgun"] = "shotgun"
}
function v_u_25.classOf(p57, p58, p59) -- name: classOf
	-- upvalues: (copy) v_u_2, (copy) v_u_25, (copy) v_u_56
	local v60 = (p59 or {}).PoseClass
	if type(v60) == "string" and v_u_2[v60] then
		return v60
	end
	local v61 = string.gsub(p57 or "", "_gold$", "")
	local v62 = v_u_25.BY_ID[v61]
	if v62 and (v62.class and v_u_2[v62.class]) then
		return v62.class
	end
	if p58 then
		local v63 = p58.class
		if type(v63) == "string" and v_u_2[p58.class] then
			return p58.class
		end
	end
	local v64
	if p58 then
		v64 = p58.holdType
	else
		v64 = nil
	end
	return v_u_56[v64 or ""] or "pistol"
end
function v_u_25.spec(p65) -- name: spec
	-- upvalues: (copy) v_u_2, (copy) v_u_31
	return v_u_2[p65] or (v_u_31[p65] or v_u_2.pistol)
end
function v_u_25.adjOf(p66, p67) -- name: adjOf
	-- upvalues: (copy) v_u_25
	local v68 = p67 or {}
	local v69 = string.gsub(p66 or "", "_gold$", "")
	local v70 = v_u_25.BY_ID[v69] or {}
	local v71 = {}
	local v72 = v68.PoseShift
	local v73
	if typeof(v72) == "Vector3" then
		v73 = v68.PoseShift
	else
		v73 = v70.shift
	end
	v71.shift = v73
	local v74 = v68.PosePitch
	local v75
	if type(v74) == "number" then
		v75 = v68.PosePitch
	else
		v75 = v70.pitch
	end
	v71.pitch = v75
	local v76 = v68.PoseSupport
	local v77
	if typeof(v76) == "Vector3" then
		v77 = v68.PoseSupport
	else
		v77 = v70.support
	end
	v71.support = v77
	local v78 = v68.PoseSlide
	local v79
	if type(v78) == "number" then
		v79 = v68.PoseSlide
	else
		v79 = v70.slide
	end
	v71.slide = v79
	local v80 = v68.PoseBusy
	local v81
	if typeof(v80) == "Vector3" then
		v81 = v68.PoseBusy
	else
		v81 = v70.busy
	end
	v71.busy = v81
	local v82 = v68.PoseBusyPitch
	local v83
	if type(v82) == "number" then
		v83 = v68.PoseBusyPitch
	else
		v83 = v70.busyPitch
	end
	v71.busyPitch = v83
	local v84 = v68.PoseYaw
	local v85
	if type(v84) == "number" then
		v85 = v68.PoseYaw
	else
		v85 = v70.yaw
	end
	v71.yaw = v85
	local v86 = v68.PoseBash
	local v87
	if typeof(v86) == "Vector3" then
		v87 = v68.PoseBash
	else
		v87 = v70.bash
	end
	v71.bash = v87
	local v88 = v68.PoseBashRoll
	local v89
	if type(v88) == "number" then
		v89 = v68.PoseBashRoll
	else
		v89 = v70.bashRoll
	end
	v71.bashRoll = v89
	local v90 = v68.PoseReload
	local v91
	if typeof(v90) == "Vector3" then
		v91 = v68.PoseReload
	else
		v91 = v70.reload
	end
	v71.reload = v91
	local v92 = v68.PoseReloadDrop
	local v93
	if type(v92) == "number" then
		v93 = v68.PoseReloadDrop
	else
		v93 = v70.reloadDrop
	end
	v71.reloadDrop = v93
	local v94 = v68.PoseBashRam
	local v95
	if type(v94) == "number" then
		v95 = v68.PoseBashRam
	else
		v95 = v70.bashRam
	end
	v71.bashRam = v95
	v71.poses = v70.poses
	return v71
end
function v_u_25.fromModel(p96) -- name: fromModel
	local v97 = {}
	if p96 then
		for _, v98 in {
			"PoseClass",
			"PoseShift",
			"PosePitch",
			"PoseSupport",
			"PoseSlide",
			"PoseBusy",
			"PoseBusyPitch",
			"PoseYaw",
			"PoseBash",
			"PoseBashRoll",
			"PoseReload",
			"PoseReloadDrop",
			"PoseBashRam"
		} do
			local v99 = p96:GetAttribute(v98)
			if v99 == nil then
				continue
			end
			v97[v98] = v99
		end
	end
	return v97
end
function v_u_25.hasPose(p100, p101) -- name: hasPose
	-- upvalues: (copy) v_u_25
	return v_u_25.spec(p100).poses[p101] ~= nil
end
function v_u_25.twoHanded(p102, p103) -- name: twoHanded
	-- upvalues: (copy) v_u_25
	return v_u_25.spec(p102).two[p103] == true
end
function v_u_25.supportFallback(p104) -- name: supportFallback
	-- upvalues: (copy) v_u_25
	return v_u_25.spec(p104).support
end
function v_u_25.leftRoll(p105) -- name: leftRoll
	-- upvalues: (copy) v_u_25, (copy) v_u_1
	return CFrame.Angles(0, 0, (v_u_1(v_u_25.spec(p105).leftRoll)))
end
function v_u_25.gripOf(p106, p107, p108, p109) -- name: gripOf
	-- upvalues: (copy) v_u_1
	local v110 = p109 and (p109.shift or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0)
	local v111 = p109 and (p109.pitch or 0) or 0
	local v112 = CFrame.new
	local v113 = p106.x
	local v114 = p106.y
	local v115 = p106.z
	return v112(p107 + (Vector3.new(v113, v114, v115) + v110) * p108) * CFrame.Angles(0, v_u_1(p106.yaw + (p109 and p109.yaw or 0)), 0) * CFrame.Angles(v_u_1(p106.pitch + v111), 0, (v_u_1(p106.roll)))
end
function v_u_25.grip(p116, p117, p118, p119, p120) -- name: grip
	-- upvalues: (copy) v_u_25, (copy) v_u_1
	local v121 = v_u_25.spec(p116)
	local v122
	if p120 and p120.poses then
		v122 = p120.poses
	else
		v122 = nil
	end
	local v123 = v122 and (v122[p117] or v122.ready) or (v121.poses[p117] or v121.poses.ready)
	local v124 = p120 and (p120.shift or Vector3.new(0, 0, 0)) or Vector3.new(0, 0, 0)
	local v125 = p120 and (p120.pitch or 0) or 0
	if p117 == "busy" and p120 then
		v124 = v124 + (p120.busy or Vector3.new(0, 0, 0))
		v125 = v125 + (p120.busyPitch or 0)
	end
	local v126 = CFrame.new
	local v127 = v123.x
	local v128 = v123.y
	local v129 = v123.z
	return v126(p118 + (Vector3.new(v127, v128, v129) + v124) * p119) * CFrame.Angles(0, v_u_1(v123.yaw + (p120 and p120.yaw or 0)), 0) * CFrame.Angles(v_u_1(v123.pitch + v125), 0, (v_u_1(v123.roll)))
end
return v_u_25