-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmVotes

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = v_u_3.Theme
local v_u_5 = v_u_4.color
local v_u_6 = {}
local v_u_7 = v1.LocalPlayer
local function v_u_12(p8) -- name: inText
	local v9 = math.floor(p8)
	local v10 = math.max(0, v9)
	if v10 < 60 then
		return ("%d s"):format(v10)
	elseif v10 < 3600 then
		local v11 = v10 / 60
		return ("%d min"):format((math.ceil(v11)))
	elseif v10 < 86400 then
		return ("%d h %02d min"):format(v10 // 3600, v10 % 3600 // 60)
	else
		return ("%d d %d h"):format(v10 // 86400, v10 % 86400 // 3600)
	end
end
function v_u_6.countText(p13, p14, p15) -- name: countText
	return ("%d vote%s  \194\183  %d of %d open"):format(p13, p13 == 1 and "" or "s", p14, p15)
end
function v_u_6.build(p_u_16) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_12, (copy) v_u_2
	local v_u_17 = p_u_16.body
	local v_u_18 = p_u_16.api
	local _ = p_u_16.handle
	local v_u_19 = true
	p_u_16.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_19
		v_u_19 = false
	end)
	local function v_u_20(_, _) end
	local function v_u_21(_, _) end
	local v_u_22 = 0
	local function v26(p23, p24) -- name: section
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_22
		local v25 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p24,
			["text"] = p23,
			["color"] = v_u_5.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_22 = v_u_22 + 1
		v25.LayoutOrder = v_u_22
		return v25
	end
	local function v31(p27, p28, p29) -- name: note
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_22
		local v30 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p28,
			["text"] = p27,
			["color"] = p29 or v_u_5.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_22 = v_u_22 + 1
		v30.LayoutOrder = v_u_22
		return v30
	end
	local function v35(p32, p33) -- name: row
		-- upvalues: (ref) v_u_3, (ref) v_u_4
		local v34 = v_u_3.new("Frame", {
			["Name"] = "Row",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(p33))
		}, p32)
		v_u_3.layout(v34, "h", 6)
		return v34
	end
	local v36 = v_u_3.new("Frame", {
		["Name"] = "VotesHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(32))
	}, v_u_17)
	v_u_22 = v_u_22 + 1
	v36.LayoutOrder = v_u_22
	v_u_3.layout(v36, "h", 6)
	local v_u_37 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VotesCount",
		["text"] = "Votes ...",
		["style"] = "bodyStrong",
		["size"] = nil,
		["parent"] = v36,
		["size"] = UDim2.fromOffset(p_u_16.inner - 126, v_u_4.touch(32))
	})
	v_u_37.LayoutOrder = 1
	local v38 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v36,
		["onClick"] = function()
			-- upvalues: (ref) v_u_20, (ref) v_u_21
			v_u_20("")
			v_u_21(false)
		end
	}
	local v39, _ = v_u_3.button(v38)
	local v40 = v39
	v40.Name = "VotesRefresh"
	v40.LayoutOrder = 2
	local v_u_41 = false
	local v_u_42 = false
	local function v_u_43(_) end
	local v44 = p_u_16.inner
	local function v45()
		-- upvalues: (ref) v_u_42, (ref) v_u_43, (ref) v_u_41
		v_u_42 = true
		v_u_43(not v_u_41)
	end
	local v46, v_u_47 = v_u_3.button({
		["parent"] = nil,
		["text"] = "+ New vote",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_17,
		["width"] = v44,
		["onClick"] = v45,
		["maxTextWidth"] = (v44 or 160) - 12
	})
	v46.Name = "VoteNewToggle"
	v_u_22 = v_u_22 + 1
	v46.LayoutOrder = v_u_22
	local v_u_48 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VotesBusy",
		["text"] = "Saving ... this can take a few seconds.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_17,
		["color"] = v_u_5.accent,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_22 = v_u_22 + 1
	v_u_48.LayoutOrder = v_u_22
	v_u_48.Visible = false
	local v_u_49 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VotesListError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_17,
		["color"] = v_u_5.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_22 = v_u_22 + 1
	v_u_49.LayoutOrder = v_u_22
	v_u_49.Visible = false
	local v_u_50 = v_u_3.new("Frame", {
		["Name"] = "VoteForm",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_17)
	v_u_22 = v_u_22 + 1
	v_u_50.LayoutOrder = v_u_22
	v_u_50.Visible = false
	v_u_3.layout(v_u_50, "v", 8)
	v26("New vote", v_u_50)
	v31("Players see these votes in the main menu (left side). Counts stay hidden for a player until he has voted, you see them always. A vote is final for the player.", v_u_50)
	local v51, v_u_52 = v_u_3.input({
		["parent"] = nil,
		["name"] = "VoteTitle",
		["size"] = nil,
		["placeholder"] = nil,
		["maxLength"] = 80,
		["parent"] = v_u_50,
		["size"] = UDim2.new(1, 0, 0, v_u_4.touch(36)),
		["placeholder"] = ("Title (up to %d characters)"):format(80)
	})
	v_u_22 = v_u_22 + 1
	v51.LayoutOrder = v_u_22
	local v53, v_u_54 = v_u_3.input({
		["parent"] = nil,
		["name"] = "VoteDesc",
		["size"] = nil,
		["placeholder"] = nil,
		["maxLength"] = 240,
		["parent"] = v_u_50,
		["size"] = UDim2.new(1, 0, 0, v_u_4.touch(72)),
		["placeholder"] = ("Description (optional, up to %d)"):format(240)
	})
	v_u_22 = v_u_22 + 1
	v53.LayoutOrder = v_u_22
	v_u_54.MultiLine = true
	v_u_54.TextWrapped = true
	v_u_54.TextTruncate = Enum.TextTruncate.None
	v_u_54.TextYAlignment = Enum.TextYAlignment.Top
	v_u_54.Position = UDim2.fromOffset(12, 8)
	v_u_54.Size = UDim2.new(1, -24, 1, -16)
	local v_u_55 = v_u_3.new("Frame", {
		["Name"] = "VoteOptions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_50)
	v_u_22 = v_u_22 + 1
	v_u_55.LayoutOrder = v_u_22
	v_u_3.layout(v_u_55, "v", 6)
	local v_u_56 = {}
	local v_u_57 = nil
	local v_u_58 = nil
	local function v_u_61() -- name: paintOptions
		-- upvalues: (copy) v_u_56, (ref) v_u_57, (ref) v_u_58
		for v59, v60 in v_u_56 do
			v60.row.LayoutOrder = v59
			v60.box.PlaceholderText = ("Option %d (up to %d)"):format(v59, 60)
			v60.remove.setEnabled(#v_u_56 > 2)
		end
		if v_u_57 then
			v_u_57.setEnabled(#v_u_56 < 6)
		end
		if v_u_58 then
			v_u_58.Text = ("%d of %d options"):format(#v_u_56, 6)
		end
	end
	local function v_u_72(p62) -- name: addOption
		-- upvalues: (copy) v_u_56, (ref) v_u_3, (ref) v_u_4, (copy) v_u_55, (copy) v_u_61
		if #v_u_56 < 6 then
			local v_u_63 = v_u_3.new("Frame", {
				["Name"] = "OptionRow",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(36))
			}, v_u_55)
			v_u_3.layout(v_u_63, "h", 6)
			local v64, v65 = v_u_3.input({
				["parent"] = nil,
				["name"] = "OptionText",
				["size"] = nil,
				["placeholder"] = "Option",
				["maxLength"] = 60,
				["parent"] = v_u_63,
				["size"] = UDim2.new(1, -(v_u_4.touch(34) + 6), 1, 0)
			})
			v64.LayoutOrder = 1
			v65.Text = p62 or ""
			local v_u_66 = {
				["row"] = v_u_63,
				["box"] = v65
			}
			local v68 = {
				["parent"] = nil,
				["name"] = "OptionRemove",
				["icon"] = "close",
				["size"] = 34,
				["kind"] = "ghost",
				["tooltip"] = "Remove this option",
				["onClick"] = nil,
				["parent"] = v_u_63,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_56, (copy) v_u_66, (copy) v_u_63, (ref) v_u_61
					if #v_u_56 > 2 then
						local v67 = table.find(v_u_56, v_u_66)
						if v67 then
							table.remove(v_u_56, v67)
							v_u_63:Destroy()
							v_u_61()
						end
					end
				end
			}
			local v69, v70 = v_u_3.iconButton(v68)
			v69.LayoutOrder = 2
			v_u_66.remove = v70
			local v71 = v_u_56
			table.insert(v71, v_u_66)
			v_u_61()
		end
	end
	v_u_72()
	v_u_72()
	local v73 = v_u_3.new("Frame", {
		["Name"] = "OptionBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(32))
	}, v_u_50)
	v_u_22 = v_u_22 + 1
	v73.LayoutOrder = v_u_22
	v_u_3.layout(v73, "h", 8)
	local v74, v75 = v_u_3.button({
		["parent"] = nil,
		["text"] = "+ Add option",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 150,
		["onClick"] = nil,
		["maxTextWidth"] = 138,
		["parent"] = v73,
		["onClick"] = function()
			-- upvalues: (copy) v_u_72
			v_u_72()
		end
	})
	v74.Name = "VoteAddOption"
	v74.LayoutOrder = 1
	v_u_57 = v75
	v_u_58 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VoteOptionCount",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v73,
		["color"] = v_u_5.text2,
		["size"] = UDim2.fromOffset(120, v_u_4.touch(32))
	})
	v_u_58.LayoutOrder = 2
	v_u_61()
	local v76 = v35(v_u_50, 36)
	v_u_22 = v_u_22 + 1
	v76.LayoutOrder = v_u_22
	v_u_3.label({
		["parent"] = nil,
		["text"] = "Closes in",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v76,
		["color"] = v_u_5.text2,
		["size"] = UDim2.fromOffset(70, v_u_4.touch(36))
	}).LayoutOrder = 1
	local v77, v_u_78 = v_u_3.input({
		["parent"] = nil,
		["name"] = "VoteHours",
		["width"] = 84,
		["placeholder"] = "hours",
		["maxLength"] = 6,
		["text"] = "0",
		["parent"] = v76
	})
	v77.LayoutOrder = 2
	v_u_3.label({
		["parent"] = nil,
		["text"] = "hours (0 = until you close it)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v76,
		["color"] = v_u_5.text2,
		["size"] = UDim2.fromOffset(p_u_16.inner - 70 - 84 - 12, v_u_4.touch(36))
	}).LayoutOrder = 3
	local v_u_79 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VotesError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_50,
		["color"] = v_u_5.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_22 = v_u_22 + 1
	v_u_79.LayoutOrder = v_u_22
	v_u_79.Visible = false
	v_u_20 = function(p80, p81)
		-- upvalues: (copy) v_u_79, (copy) v_u_49, (ref) v_u_7
		local v82 = p80 or ""
		v_u_79.Text = p81 == true and "" or v82
		local v83 = v_u_79
		local v84
		if p81 == true then
			v84 = false
		else
			v84 = v82 ~= ""
		end
		v83.Visible = v84
		v_u_49.Text = p81 ~= true and "" or v82
		local v85 = v_u_49
		local v86
		if p81 == true then
			v86 = v82 ~= ""
		else
			v86 = false
		end
		v85.Visible = v86
		v_u_7:SetAttribute("FilmVotesError", v82)
	end
	v_u_43 = function(p87)
		-- upvalues: (ref) v_u_41, (copy) v_u_50, (copy) v_u_47, (ref) v_u_7, (copy) v_u_17
		v_u_41 = p87
		v_u_50.Visible = p87
		v_u_47.setText(p87 and "Hide the form" or "+ New vote")
		v_u_7:SetAttribute("FilmVotesForm", p87)
		if not p87 then
			v_u_17.CanvasPosition = Vector2.zero
		end
	end
	local v_u_88 = {}
	local v_u_89 = 0
	local v_u_90 = 12
	local v_u_91 = ""
	local v_u_92 = true
	local v_u_93 = {}
	local v_u_94 = nil
	local v_u_95 = false
	local v_u_96 = {}
	local v_u_97 = nil
	local v_u_98 = nil
	local v_u_99 = nil
	local function v_u_105(p100, p101, p102) -- name: setBusy
		-- upvalues: (ref) v_u_95, (copy) v_u_48, (ref) v_u_7, (ref) v_u_97, (copy) v_u_96, (ref) v_u_98
		v_u_95 = p100
		v_u_48.Visible = p100
		v_u_7:SetAttribute("FilmVotesBusy", p100)
		if v_u_97 then
			v_u_97.setEnabled(not p100)
		end
		for _, v103 in v_u_96 do
			v103.setEnabled(not p100)
		end
		if p100 then
			if p101 ~= nil and p102 ~= nil then
				v_u_98 = {
					["api"] = p101,
					["text"] = p102
				}
				p101.setText("Saving...")
				return
			end
		else
			local v104 = v_u_98
			v_u_98 = nil
			if v104 ~= nil then
				v104.api.setText(v104.text)
			end
		end
	end
	local function v_u_110(p106) -- name: apply
		-- upvalues: (ref) v_u_88, (ref) v_u_89, (ref) v_u_90, (copy) v_u_37, (ref) v_u_6, (ref) v_u_7, (ref) v_u_92, (ref) v_u_42, (ref) v_u_43, (ref) v_u_94
		if type(p106) == "table" then
			local v107 = p106.polls
			if type(v107) == "table" then
				v_u_88 = p106.polls
				local v108 = p106.open
				v_u_89 = tonumber(v108) or 0
				local v109 = p106.maxOpen
				v_u_90 = tonumber(v109) or 12
				v_u_37.Text = v_u_6.countText(#v_u_88, v_u_89, v_u_90)
				v_u_7:SetAttribute("FilmVotes", ("%d|%d|%d"):format(#v_u_88, v_u_89, v_u_90))
				if v_u_92 then
					v_u_92 = false
					if #v_u_88 == 0 and not v_u_42 then
						v_u_43(true)
					end
				end
				v_u_94()
				return
			end
		end
	end
	local v111 = p_u_16.inner
	local function v125()
		-- upvalues: (copy) v_u_56, (copy) v_u_52, (copy) v_u_54, (copy) v_u_78, (ref) v_u_20, (ref) v_u_97, (copy) v_u_72, (ref) v_u_43, (copy) v_u_110, (ref) v_u_95, (ref) v_u_99, (copy) v_u_105, (copy) v_u_18
		local v112 = {}
		for _, v113 in v_u_56 do
			local v114 = v113.box.Text
			table.insert(v112, v114)
		end
		local v115 = {
			["title"] = v_u_52.Text,
			["desc"] = v_u_54.Text,
			["options"] = v112
		}
		local v116 = string.gsub(v_u_78.Text, "%s", "")
		v115.hours = v116 == "" and 0 or v116
		v_u_20("")
		local v117 = {
			["draft"] = v115
		}
		local v118 = v_u_97
		local function v_u_123(p119)
			-- upvalues: (ref) v_u_52, (ref) v_u_54, (ref) v_u_78, (ref) v_u_56, (ref) v_u_72, (ref) v_u_43, (ref) v_u_110, (ref) v_u_20
			if p119 and p119.ok then
				v_u_52.Text = ""
				v_u_54.Text = ""
				v_u_78.Text = "0"
				for v120 = #v_u_56, 1, -1 do
					v_u_56[v120].row:Destroy()
					table.remove(v_u_56, v120)
				end
				v_u_72()
				v_u_72()
				v_u_43(false)
				v_u_110(p119.data)
			else
				local v121 = v_u_20
				local v122 = p119 and p119.msg or "The server did not answer."
				v121((tostring(v122)))
			end
		end
		if not v_u_95 then
			v_u_99 = nil
			v_u_105(true, v118, "Create vote")
			v_u_18.call("votes.create", v117, function(p124)
				-- upvalues: (ref) v_u_99, (ref) v_u_105, (copy) v_u_123
				v_u_99 = nil
				v_u_105(false)
				v_u_123(p124)
			end)
		end
	end
	local v126, v127 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Create vote",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_50,
		["width"] = v111,
		["onClick"] = v125,
		["maxTextWidth"] = (v111 or 160) - 12
	})
	v_u_97 = v127
	v126.Name = "VoteCreate"
	v_u_22 = v_u_22 + 1
	v126.LayoutOrder = v_u_22
	v26("Votes  \194\183  newest first", v_u_17)
	local v_u_128 = v_u_3.new("Frame", {
		["Name"] = "VoteList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_17)
	v_u_22 = v_u_22 + 1
	v_u_128.LayoutOrder = v_u_22
	v_u_3.layout(v_u_128, "v", 8)
	local v_u_129 = v_u_3.label({
		["parent"] = nil,
		["name"] = "VoteEmpty",
		["text"] = "No votes yet. Create the first one with the button above.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_128,
		["color"] = v_u_5.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_129.LayoutOrder = 0
	local function v_u_229(p_u_130, p131) -- name: buildCard
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_128, (ref) v_u_12, (ref) v_u_4, (copy) p_u_16, (ref) v_u_20, (copy) v_u_110, (ref) v_u_95, (ref) v_u_99, (copy) v_u_105, (copy) v_u_18, (copy) v_u_93, (ref) v_u_94, (ref) v_u_19, (copy) v_u_96, (ref) v_u_98
		local v132 = v_u_3.new
		local v133 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil
		}
		local v134 = p_u_130.id
		v133.Name = "Poll_" .. tostring(v134)
		v133.BackgroundColor3 = v_u_5.raised
		v133.Size = UDim2.new(1, 0, 0, 0)
		v133.AutomaticSize = Enum.AutomaticSize.Y
		v133.LayoutOrder = p131
		local v135 = v132("Frame", v133, v_u_128)
		local v136 = v_u_3.stroke
		local v137
		if p_u_130.closed then
			v137 = v_u_5.line
		else
			v137 = v_u_5.accent
		end
		v136(v135, v137)
		v_u_3.pad(v135, {
			10,
			10,
			8,
			10
		})
		v_u_3.layout(v135, "v", 6)
		local v138 = 0
		local v139 = v_u_3.label
		local v140 = {
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "bodyStrong",
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v135
		}
		local v141 = p_u_130.title
		v140.text = tostring(v141)
		v140.size = UDim2.new(1, 0, 0, 0)
		local v142 = v139(v140)
		v138 = v138 + 1
		v142.LayoutOrder = v138
		local v143, v144
		if p_u_130.expired then
			v143 = v_u_5.muted
			v144 = "CLOSED (time is up)"
		elseif p_u_130.closed then
			v143 = v_u_5.muted
			v144 = "CLOSED"
		else
			v143 = v_u_5.success
			v144 = "OPEN"
		end
		local v145 = os.time()
		if p_u_130.closed then
			local v146 = p_u_130.closedAt or p_u_130.closesAt
			if v146 then
				local v147 = "  \194\183  "
				local v148 = v145 - v146
				local v149 = math.floor(v148)
				local v150 = math.max(0, v149)
				local v151
				if v150 < 60 then
					v151 = "just now"
				elseif v150 < 3600 then
					v151 = ("%d min ago"):format(v150 // 60)
				elseif v150 < 86400 then
					v151 = ("%d h ago"):format(v150 // 3600)
				else
					v151 = ("%d d ago"):format(v150 // 86400)
				end
				v144 = v144 .. v147 .. v151
			end
		else
			v144 = v144 .. (not p_u_130.closesAt and "  \194\183  no closing time" or ("  \194\183  closes in %s"):format(v_u_12(p_u_130.closesAt - v145)))
		end
		local v152 = p_u_130.total
		local v153 = v144 .. ("  \194\183  %d vote%s"):format(tonumber(v152) or 0, p_u_130.total == 1 and "" or "s")
		local v154 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Meta",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v135,
			["text"] = v153,
			["color"] = v143,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v138 = v138 + 1
		v154.LayoutOrder = v138
		local v155 = p_u_130.desc
		local v156
		if type(v155) == "string" and p_u_130.desc ~= "" then
			local v157 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["parent"] = v135,
				["text"] = p_u_130.desc,
				["color"] = v_u_5.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v138 = v138 + 1
			v157.LayoutOrder = v138
			v156 = v138
		else
			v156 = v138
		end
		local v158 = p_u_130.total
		local v159 = tonumber(v158) or 0
		local v160 = 0
		for _, v161 in p_u_130.options do
			local v162 = v161.n
			local v163 = tonumber(v162) or 0
			v160 = math.max(v160, v163)
		end
		for _, v164 in p_u_130.options do
			local v165 = v164.n
			local v166 = tonumber(v165) or 0
			local v167 = v159 <= 0 and 0 or v166 / v159
			local v168 = v_u_3.new
			local v169 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil
			}
			local v170 = v164.id
			v169.Name = "Option_" .. tostring(v170)
			v169.BackgroundColor3 = v_u_5.bgDeep
			v169.Size = UDim2.new(1, 0, 0, 26)
			v138 = v156 + 1
			v169.LayoutOrder = v138
			local v171 = v168("Frame", v169, v135)
			v_u_3.stroke(v171, v_u_5.line)
			local v172 = v_u_3.new
			local v173 = "Frame"
			local v174 = {
				["Name"] = "Fill",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil
			}
			local v175
			if v166 == v160 and v166 > 0 then
				v175 = v_u_5.accent
			else
				v175 = v_u_5.lineStrong
			end
			v174.BackgroundColor3 = v175
			v174.BackgroundTransparency = v166 == v160 and v166 > 0 and 0.45 or 0.35
			v174.Size = UDim2.new(v167, 0, 1, 0)
			v172(v173, v174, v171)
			local v176 = v_u_3.label
			local v177 = {
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v171
			}
			local v178 = v164.text
			v177.text = tostring(v178)
			v177.color = v_u_5.text
			v177.position = UDim2.fromOffset(8, 0)
			v177.size = UDim2.new(1, -96, 1, 0)
			v176(v177).ZIndex = 3
			local v179 = v_u_3.label
			local v180 = {
				["parent"] = nil,
				["name"] = "Count",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v171
			}
			local v181 = v167 * 100 + 0.5
			v180.text = ("%d  \194\183  %d%%"):format(v166, (math.floor(v181)))
			v180.color = v_u_5.text
			v180.position = UDim2.new(1, -8, 0, 0)
			v180.size = UDim2.new(0, 84, 1, 0)
			local v182 = v179(v180)
			v182.AnchorPoint = Vector2.new(1, 0)
			v182.ZIndex = 3
			v156 = v138
		end
		local v183 = v_u_3.new
		local v184 = {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(32))
		}
		v138 = v156 + 1
		v184.LayoutOrder = v138
		local v185 = v183("Frame", v184, v135)
		v_u_3.layout(v185, "h", 6)
		local v186 = (p_u_16.inner - 20 - 6) / 2
		local v187 = math.floor(v186)
		local v_u_188 = p_u_130.closed and "Reopen" or "Close vote"
		local v_u_189 = nil
		local v190 = p_u_130.closed and "primary" or "secondary"
		local function v201()
			-- upvalues: (ref) v_u_20, (copy) p_u_130, (ref) v_u_189, (copy) v_u_188, (ref) v_u_110, (ref) v_u_95, (ref) v_u_99, (ref) v_u_105, (ref) v_u_18
			v_u_20("", true)
			local v191 = {
				["id"] = p_u_130.id,
				["closed"] = not p_u_130.closed
			}
			local v192 = v_u_189
			local v193 = v_u_188
			local v194 = p_u_130.id
			local v195 = "close:" .. tostring(v194)
			local function v_u_199(p196)
				-- upvalues: (ref) v_u_110, (ref) v_u_20
				if p196 and p196.ok then
					v_u_110(p196.data)
				else
					local v197 = v_u_20
					local v198 = p196 and p196.msg or "The server did not answer."
					v197(tostring(v198), true)
				end
			end
			if not v_u_95 then
				v_u_99 = v195
				v_u_105(true, v192, v193)
				v_u_18.call("votes.close", v191, function(p200)
					-- upvalues: (ref) v_u_99, (ref) v_u_105, (copy) v_u_199
					v_u_99 = nil
					v_u_105(false)
					v_u_199(p200)
				end)
			end
		end
		local v202, v203 = v_u_3.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v185,
			["text"] = v_u_188,
			["kind"] = v190,
			["width"] = v187,
			["onClick"] = v201,
			["maxTextWidth"] = (v187 or 160) - 12
		})
		local v204 = v203
		v202.Name = "VoteClose"
		local v205
		if v_u_93[p_u_130.id] == nil then
			v205 = false
		else
			v205 = os.clock() - v_u_93[p_u_130.id] < 5
		end
		local v_u_206 = v205 and "Click again to delete" or "Delete"
		local v_u_207 = nil
		local function v219()
			-- upvalues: (ref) v_u_93, (copy) p_u_130, (ref) v_u_20, (ref) v_u_207, (copy) v_u_206, (ref) v_u_110, (ref) v_u_94, (ref) v_u_95, (ref) v_u_99, (ref) v_u_105, (ref) v_u_18, (ref) v_u_19
			local v208 = v_u_93[p_u_130.id]
			if v208 == nil or os.clock() - v208 >= 5 then
				v_u_93[p_u_130.id] = os.clock()
				v_u_94(true)
				task.delay(5.2, function()
					-- upvalues: (ref) v_u_19, (ref) v_u_93, (ref) p_u_130, (ref) v_u_94
					if v_u_19 and (v_u_93[p_u_130.id] ~= nil and os.clock() - v_u_93[p_u_130.id] >= 5) then
						v_u_93[p_u_130.id] = nil
						v_u_94(true)
					end
				end)
				return
			else
				v_u_93[p_u_130.id] = nil
				v_u_20("", true)
				local v209 = {
					["id"] = p_u_130.id
				}
				local v210 = v_u_207
				local v211 = v_u_206
				local v212 = p_u_130.id
				local v213 = "delete:" .. tostring(v212)
				local function v_u_217(p214)
					-- upvalues: (ref) v_u_110, (ref) v_u_20, (ref) v_u_94
					if p214 and p214.ok then
						v_u_110(p214.data)
					else
						local v215 = v_u_20
						local v216 = p214 and p214.msg or "The server did not answer."
						v215(tostring(v216), true)
						v_u_94(true)
					end
				end
				if not v_u_95 then
					v_u_99 = v213
					v_u_105(true, v210, v211)
					v_u_18.call("votes.delete", v209, function(p218)
						-- upvalues: (ref) v_u_99, (ref) v_u_105, (copy) v_u_217
						v_u_99 = nil
						v_u_105(false)
						v_u_217(p218)
					end)
				end
			end
		end
		local v220, v221 = v_u_3.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "danger",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v185,
			["text"] = v_u_206,
			["width"] = v187,
			["onClick"] = v219,
			["maxTextWidth"] = (v187 or 160) - 12
		})
		v_u_207 = v221
		v220.Name = "VoteDelete"
		if v205 then
			v_u_3.stroke(v220, v_u_5.danger)
		end
		local v222 = v_u_96
		table.insert(v222, v204)
		local v223 = v_u_96
		local v224 = v_u_207
		table.insert(v223, v224)
		if v_u_95 then
			v204.setEnabled(false)
			v_u_207.setEnabled(false)
			local v225 = v_u_99
			local v226 = p_u_130.id
			if v225 == "close:" .. tostring(v226) then
				v_u_98 = {
					["api"] = v204,
					["text"] = v_u_188
				}
				v204.setText("Saving...")
			else
				local v227 = v_u_99
				local v228 = p_u_130.id
				if v227 == "delete:" .. tostring(v228) then
					v_u_98 = {
						["api"] = v_u_207,
						["text"] = v_u_206
					}
					v_u_207.setText("Saving...")
				end
			end
		end
	end
	v_u_94 = function(p230)
		-- upvalues: (ref) v_u_2, (ref) v_u_88, (copy) v_u_93, (ref) v_u_91, (ref) v_u_128, (copy) v_u_129, (copy) v_u_96, (copy) v_u_229
		local v231 = v_u_2:JSONEncode(v_u_88)
		local v232 = os.time() // 60
		local v233 = v231 .. "|" .. tostring(v232)
		for v234, v235 in v_u_93 do
			local v236 = os.clock() - v235 < 5
			v233 = v233 .. "|c" .. v234 .. tostring(v236)
		end
		if v233 ~= v_u_91 or p230 == true then
			v_u_91 = v233
			for _, v237 in v_u_128:GetChildren() do
				if not v237:IsA("GuiObject") or v237 == v_u_129 then
					continue
				end
				v237:Destroy()
			end
			table.clear(v_u_96)
			v_u_129.Visible = #v_u_88 == 0
			for v238, v239 in v_u_88 do
				v_u_229(v239, v238)
			end
		end
	end
	v_u_21 = function(p_u_240, p_u_241)
		-- upvalues: (copy) v_u_110, (ref) v_u_20, (copy) v_u_18
		local function v245(p242) -- name: done
			-- upvalues: (ref) v_u_110, (copy) p_u_240, (ref) v_u_20, (copy) p_u_241
			if p242 and p242.ok then
				v_u_110(p242.data)
			elseif not p_u_240 then
				local v243 = v_u_20
				local v244 = p242 and (p242.msg or "The server did not answer.") or "The server did not answer."
				v243(tostring(v244), true)
			end
			if p_u_241 then
				p_u_241(p242)
			end
		end
		if p_u_240 then
			v_u_18.callQuiet("votes.list", {}, v245)
		else
			v_u_18.call("votes.list", {}, v245)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_19, (copy) p_u_16, (copy) v_u_17, (ref) v_u_21
		local v246 = false
		local v247 = 0
		while v_u_19 do
			local v248 = p_u_16.gui.Enabled
			if v248 then
				v248 = v_u_17.Visible
			end
			if v248 and (not v246 or os.clock() - v247 >= 15) then
				v247 = os.clock()
				v_u_21(true)
			end
			task.wait(0.3)
			v246 = v248
		end
	end)
	return {
		["refresh"] = function() -- name: refresh
			-- upvalues: (ref) v_u_21
			v_u_21(false)
		end,
		["list"] = function() -- name: list
			-- upvalues: (ref) v_u_88
			return v_u_88
		end,
		["formState"] = function() -- name: formState
			-- upvalues: (copy) v_u_56, (copy) v_u_52, (copy) v_u_79, (copy) v_u_49, (ref) v_u_88, (ref) v_u_41, (ref) v_u_95
			local v249 = {}
			for _, v250 in v_u_56 do
				local v251 = v250.box.Text
				table.insert(v249, v251)
			end
			return {
				["title"] = v_u_52.Text,
				["options"] = v249,
				["optionRows"] = #v_u_56,
				["error"] = v_u_79.Text,
				["listError"] = v_u_49.Text,
				["polls"] = #v_u_88,
				["formOpen"] = v_u_41,
				["busy"] = v_u_95
			}
		end
	}
end
return v_u_6