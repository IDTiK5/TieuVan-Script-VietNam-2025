-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Comms

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {
	{
		["id"] = "danger",
		["text"] = "Danger",
		["icon"] = "warning",
		["color"] = "danger",
		["calls"] = nil,
		["calls"] = {}
	},
	{
		["id"] = "help",
		["text"] = "Help",
		["icon"] = "help",
		["color"] = "danger",
		["calls"] = nil,
		["calls"] = {}
	},
	{
		["id"] = "loot",
		["text"] = "Loot",
		["icon"] = "loot",
		["color"] = "info",
		["calls"] = nil,
		["calls"] = {}
	},
	{
		["id"] = "extract",
		["text"] = "Extract",
		["icon"] = "extract",
		["color"] = "success",
		["calls"] = nil,
		["calls"] = {}
	},
	{
		["id"] = "social",
		["text"] = "Social",
		["icon"] = "thanks",
		["color"] = "text",
		["calls"] = nil,
		["calls"] = {}
	},
	{
		["id"] = "move",
		["text"] = "Move",
		["icon"] = "follow",
		["color"] = "accent",
		["calls"] = nil,
		["calls"] = {}
	}
}
local v_u_4 = {}
local v5 = {
	{
		["id"] = "horde",
		["text"] = "Horde!",
		["icon"] = "horde",
		["color"] = "danger",
		["located"] = true,
		["life"] = 10,
		["cat"] = "danger"
	},
	{
		["id"] = "runner",
		["text"] = "Runner!",
		["icon"] = "warning",
		["color"] = "danger",
		["located"] = true,
		["life"] = 8,
		["cat"] = "danger"
	},
	{
		["id"] = "boss",
		["text"] = "Boss!",
		["icon"] = "skull",
		["color"] = "danger",
		["located"] = true,
		["life"] = 12,
		["cat"] = "danger"
	},
	{
		["id"] = "shout",
		["text"] = "Shout",
		["icon"] = "siren",
		["color"] = "danger",
		["located"] = false,
		["life"] = 6,
		["cat"] = "danger"
	},
	{
		["id"] = "help",
		["text"] = "Need help",
		["icon"] = "help",
		["color"] = "danger",
		["located"] = false,
		["life"] = 10,
		["cat"] = "help"
	},
	{
		["id"] = "medic",
		["text"] = "Need medic",
		["icon"] = "heart",
		["color"] = "danger",
		["located"] = false,
		["life"] = 10,
		["cat"] = "help"
	},
	{
		["id"] = "ammo",
		["text"] = "Need ammo",
		["icon"] = "ammo",
		["color"] = "accent",
		["located"] = false,
		["life"] = 8,
		["cat"] = "help"
	},
	{
		["id"] = "downed",
		["text"] = "Downed nearby",
		["icon"] = "heart",
		["color"] = "danger",
		["located"] = true,
		["life"] = 10,
		["cat"] = "help"
	},
	{
		["id"] = "loot",
		["text"] = "Loot here",
		["icon"] = "loot",
		["color"] = "info",
		["located"] = true,
		["life"] = 10,
		["cat"] = "loot"
	},
	{
		["id"] = "item",
		["text"] = "Item here",
		["icon"] = "search",
		["color"] = "info",
		["located"] = true,
		["life"] = 10,
		["cat"] = "loot"
	},
	{
		["id"] = "need",
		["text"] = "Need this",
		["icon"] = "star",
		["color"] = "accent",
		["located"] = true,
		["life"] = 10,
		["cat"] = "loot"
	},
	{
		["id"] = "follow",
		["text"] = "Follow me",
		["icon"] = "follow",
		["color"] = "accent",
		["located"] = false,
		["life"] = 8,
		["cat"] = "move"
	},
	{
		["id"] = "hold",
		["text"] = "Hold here",
		["icon"] = "hand",
		["color"] = "accent",
		["located"] = true,
		["life"] = 8,
		["cat"] = "move"
	},
	{
		["id"] = "go",
		["text"] = "Go there",
		["icon"] = "ping",
		["color"] = "accent",
		["located"] = true,
		["life"] = 8,
		["cat"] = "move"
	},
	{
		["id"] = "regroup",
		["text"] = "Regroup",
		["icon"] = "squad",
		["color"] = "accent",
		["located"] = false,
		["life"] = 8,
		["cat"] = "move"
	},
	{
		["id"] = "extract",
		["text"] = "Extract here",
		["icon"] = "extract",
		["color"] = "success",
		["located"] = true,
		["life"] = 12,
		["cat"] = "extract"
	},
	{
		["id"] = "extractnow",
		["text"] = "Extract now",
		["icon"] = "clock",
		["color"] = "success",
		["located"] = false,
		["life"] = 8,
		["cat"] = "extract"
	},
	{
		["id"] = "thanks",
		["text"] = "Thanks",
		["icon"] = "thanks",
		["color"] = "text",
		["located"] = false,
		["life"] = 5,
		["cat"] = "social"
	},
	{
		["id"] = "yes",
		["text"] = "Yes",
		["icon"] = "check",
		["color"] = "success",
		["located"] = false,
		["life"] = 5,
		["cat"] = "social"
	},
	{
		["id"] = "no",
		["text"] = "No",
		["icon"] = "close",
		["color"] = "danger",
		["located"] = false,
		["life"] = 5,
		["cat"] = "social"
	},
	{
		["id"] = "sorry",
		["text"] = "Sorry",
		["icon"] = "info",
		["color"] = "text",
		["located"] = false,
		["life"] = 5,
		["cat"] = "social"
	}
}
local v_u_6 = {}
local v_u_7 = {
	["name"] = "Comms",
	["order"] = 42
}
for _, v8 in v_u_3 do
	v_u_4[v8.id] = v8
end
for _, v9 in v5 do
	v_u_6[v9.id] = v9
	local v10 = v_u_4[v9.cat].calls
	local v11 = v9.id
	table.insert(v10, v11)
end
v_u_6.waypoint = {
	["id"] = "waypoint",
	["text"] = "Waypoint",
	["icon"] = "map",
	["color"] = "info",
	["located"] = true,
	["life"] = 0,
	["cat"] = ""
}
v_u_7.KINDS = v5
v_u_7.CATEGORIES = v_u_3
local v_u_12 = 168
local v_u_13 = 150
function v_u_7.catWidth(p14) -- name: catWidth
	local v15 = p14 - 8
	local v16 = math.floor(v15)
	return math.min(150, v16)
end
function v_u_7.ringRadius(p17) -- name: ringRadius
	-- upvalues: (copy) v_u_7
	local v18 = p17 / 2 - 8
	local v19 = 168
	while v19 > 120 and v18 < v19 + v_u_7.catWidth(v19) / 2 + 16 + 176 do
		v19 = v19 - 1
	end
	return v19
end
local v_u_20 = {
	["reached"] = 0,
	["cancelled"] = 0,
	["closed"] = 0
}
local v_u_21 = (-1 / 0)
local v_u_22 = {}
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = v_u_1.LocalPlayer
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = {}
local v_u_30 = {}
local v_u_31 = {}
local v_u_32 = {}
local v_u_33 = {}
local v_u_34 = {}
local v_u_35 = {}
local v_u_36 = nil
local v_u_37 = nil
local v_u_38 = false
local v_u_39 = false
local v_u_40 = 0
local v_u_41 = Vector2.zero
local v_u_42 = Vector2.zero
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = 0
local v_u_46 = nil
local v_u_47 = 0
local v_u_48 = "loot"
local v_u_49 = {}
local v_u_50 = nil
local function v_u_56(p_u_51) -- name: itemName
	-- upvalues: (ref) v_u_23
	if type(p_u_51) ~= "string" or p_u_51 == "" then
		return nil
	end
	local function v52()
		-- upvalues: (ref) v_u_23, (copy) p_u_51
		return v_u_23.shared.Items.get(p_u_51)
	end
	local v53, v54 = pcall(v52)
	if v53 and type(v54) == "table" then
		local v55 = v54.name
		if type(v55) == "string" then
			return v54.name
		end
	end
	return nil
end
local function v_u_62(p57) -- name: extractPart
	-- upvalues: (ref) v_u_23, (copy) v_u_26
	local v58 = v_u_23
	if v58 then
		v58 = v_u_23.runtime
	end
	if v58 then
		v58 = v58:FindFirstChild("Raid")
	end
	if v58 then
		v58 = v58:FindFirstChild("Extracts")
	end
	local v59
	if v58 then
		v59 = v58:FindFirstChild(p57)
	else
		v59 = v58
	end
	if v59 and v59:IsA("BasePart") then
		return v59
	else
		if v58 then
			for _, v60 in v58:GetChildren() do
				if not v60:IsA("BasePart") or v60:GetAttribute("ExtractId") ~= p57 then
					continue
				end
				return v60
			end
		end
		local v61 = v_u_26:FindFirstChildOfClass("PlayerGui")
		if v61 then
			v61 = v61:FindFirstChild("HushPersonalExtracts")
		end
		if v61 then
			v61 = v61:FindFirstChild(p57)
		end
		if v61 and v61:IsA("BasePart") then
			return v61
		else
			return nil
		end
	end
end
local function v_u_115(p63, p64, p65, p66, p67, p68) -- name: addMarker
	-- upvalues: (copy) v_u_6, (ref) v_u_50, (ref) v_u_24, (ref) v_u_25, (copy) v_u_56, (copy) v_u_26, (copy) v_u_49, (ref) v_u_23
	local v69 = v_u_6[p63]
	if not v69 then
		return
	end
	local v70 = p68 or {}
	local v71
	if v_u_50 and v_u_50.Parent then
		v71 = v_u_50
	else
		local v72
		v72, v71 = v_u_24.screen("HushPings", v_u_25.layer.world + 1, {
			["insets"] = "None"
		})
		v_u_50 = v71
	end
	local v73 = v69.text
	local v74 = p66 .. (p67 and "" or " (nearby)")
	local v75 = v69.life
	local v76 = "call"
	local v77 = v_u_56(v70.item)
	if p63 == "item" and v77 then
		if #v77 > 28 then
			v77 = string.sub(v77, 1, 27) .. "\226\128\166"
		end
		local v78 = v70.label
		if type(v78) == "string" and v70.label ~= "" then
			local v79 = v70.label
			if #v79 > 20 then
				v79 = string.sub(v79, 1, 19) .. "\226\128\166"
			end
			v74 = v79 .. "  \194\183  " .. v74
		end
		local v80 = v70.item
		v76 = "item:" .. tostring(v80)
		v75 = 10
	elseif p63 == "extract" then
		local v81 = v70.extractName
		if type(v81) == "string" and v70.extractName ~= "" then
			v77 = v70.extractName
			if #v77 > 28 then
				v77 = string.sub(v77, 1, 27) .. "\226\128\166"
			end
			v74 = "Extraction  \194\183  " .. v74
			v76 = "extract"
			v75 = 25
		elseif p63 == "waypoint" then
			v77 = p65 == v_u_26.UserId and "Your waypoint" or "Waypoint"
			v74 = p65 == v_u_26.UserId and "Map" or p66
			v76 = "waypoint"
			v75 = (1 / 0)
		else
			v77 = v73
		end
	elseif p63 == "waypoint" then
		v77 = p65 == v_u_26.UserId and "Your waypoint" or "Waypoint"
		v74 = p65 == v_u_26.UserId and "Map" or p66
		v76 = "waypoint"
		v75 = (1 / 0)
	else
		v77 = v73
	end
	local v82 = 0
	for v83 = #v_u_49, 1, -1 do
		local v84 = v_u_49[v83]
		if v84.from ~= p65 then
			continue
		end
		if v84.slot == v76 then
			local v85 = v_u_49[v83]
			v85.f:Destroy()
			v85.arrow:Destroy()
			v85.cap:Destroy()
			table.remove(v_u_49, v83)
		else
			if v76 == "call" then
				continue
			end
			local v86 = v84.slot
			if string.sub(v86, 1, 5) ~= "item:" or string.sub(v76, 1, 5) ~= "item:" then
				continue
			end
			v82 = v82 + 1
		end
	end
	if v82 >= 3 then
		for v87 = 1, #v_u_49 do
			local v88 = v_u_49[v87]
			if v88.from ~= p65 then
				continue
			end
			local v89 = v88.slot
			if string.sub(v89, 1, 5) ~= "item:" then
				continue
			end
			local v90 = v_u_49[v87]
			v90.f:Destroy()
			v90.arrow:Destroy()
			v90.cap:Destroy()
			table.remove(v_u_49, v87)
		end
	end
	local v91 = v75 * 1.5
	local v92
	if v76 == "extract" and p65 == v_u_26.UserId then
		local v93 = v70.extract
		v92 = type(v93) == "string"
	else
		v92 = false
	end
	if v92 then
		v91 = (1 / 0)
	end
	while #v_u_49 >= 14 do
		local v94 = 1
		for v95, v96 in v_u_49 do
			if v96.persist or v96.wp then
				continue
			end
			v94 = v95
		end
		local v97 = v_u_49[v94]
		v97.f:Destroy()
		v97.arrow:Destroy()
		v97.cap:Destroy()
		table.remove(v_u_49, v94)
	end
	local v98 = v69.color
	local v99 = v_u_25.color[v98] or v_u_25.color.text
	local v100 = v_u_24.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Name"] = "Ping_" .. p63,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(220, 86)
	}, v71)
	v_u_24.icon("ping", {
		["parent"] = nil,
		["size"] = 22,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v100,
		["color"] = v99,
		["position"] = UDim2.new(0.5, 0, 1, -2),
		["anchor"] = Vector2.new(0.5, 1)
	})
	v_u_24.new("Frame", {
		["Name"] = "Stem",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v99,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -20),
		["Size"] = UDim2.fromOffset(1, 8)
	}, v100)
	local v101 = v_u_24.new("Frame", {
		["Name"] = "Tag",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_25.color.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0),
		["Size"] = UDim2.fromOffset(0, 40),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v100)
	v_u_24.stroke(v101, v99, 1, 0.3)
	v_u_24.pad(v101, {
		8,
		14,
		2,
		2
	})
	v_u_24.icon(v69.icon, {
		["parent"] = nil,
		["size"] = 14,
		["color"] = nil,
		["position"] = nil,
		["parent"] = v101,
		["color"] = v99,
		["position"] = UDim2.fromOffset(0, 2)
	})
	local v102 = v_u_24.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["position"] = nil,
		["textSize"] = 14,
		["parent"] = v101,
		["text"] = v77,
		["color"] = v99,
		["size"] = UDim2.fromOffset(0, 18),
		["position"] = UDim2.fromOffset(20, 0)
	})
	local v103 = v_u_24.label({
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = nil,
		["style"] = "monoS",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["position"] = nil,
		["track"] = false,
		["parent"] = v101,
		["text"] = v74,
		["color"] = v_u_25.color.text2,
		["size"] = UDim2.fromOffset(0, 16),
		["position"] = UDim2.fromOffset(0, 18)
	})
	v102.TextTruncate = Enum.TextTruncate.None
	v103.TextTruncate = Enum.TextTruncate.None
	local v104 = v_u_24.label({
		["parent"] = nil,
		["name"] = "Dist",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v100,
		["color"] = v_u_25.color.text2,
		["size"] = UDim2.new(1, 0, 0, 14),
		["position"] = UDim2.new(0, 0, 1, -44)
	})
	local v105 = v_u_24.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Name"] = "Arrow_" .. p63,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(26, 26)
	}, v71)
	v_u_24.icon("chevronUp", {
		["parent"] = nil,
		["size"] = 26,
		["color"] = nil,
		["thickness"] = 3,
		["parent"] = v105,
		["color"] = v99
	})
	local v106 = v_u_24.label({
		["parent"] = nil,
		["name"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["anchor"] = nil,
		["size"] = nil,
		["parent"] = v71,
		["name"] = "Cap_" .. p63,
		["color"] = v99,
		["anchor"] = Vector2.new(0.5, 0.5),
		["size"] = UDim2.fromOffset(170, 16)
	})
	v106.Visible = false
	local v107 = v_u_49
	local v108 = {
		["f"] = nil,
		["t"] = 0,
		["life"] = nil,
		["pos"] = nil,
		["follow"] = nil,
		["arrow"] = nil,
		["cap"] = nil,
		["dist"] = nil,
		["kind"] = nil,
		["from"] = nil,
		["slot"] = nil,
		["title"] = nil,
		["persist"] = nil,
		["extractId"] = nil,
		["wp"] = nil,
		["f"] = v100,
		["life"] = v91,
		["pos"] = p64
	}
	local v109
	if v69.located or (v70.fixed == true or v76 ~= "call") then
		v109 = nil
	else
		v109 = p65
	end
	v108.follow = v109
	v108.arrow = v105
	v108.cap = v106
	v108.dist = v104
	v108.kind = p63
	v108.from = p65
	v108.slot = v76
	local v110
	if #v77 <= 18 then
		v110 = v77
	else
		v110 = string.sub(v77, 1, 17) .. "\226\128\166"
	end
	v108.title = v110
	v108.persist = v92 and true or nil
	local v111
	if v92 then
		v111 = v70.extract
	else
		v111 = nil
	end
	v108.extractId = v111
	v108.wp = v76 == "waypoint" and true or nil
	table.insert(v107, v108)
	v100:SetAttribute("Caller", p66)
	v100:SetAttribute("Title", v77)
	v100:SetAttribute("Life", (v92 or v76 == "waypoint") and -1 or v91)
	v_u_24.sound("ping")
	local v112 = v_u_23.controllers.Audio
	if v112 and v112.play3D then
		if p63 == "shout" then
			local v113 = v112.play3D
			pcall(v113, "z_human_shout", p64, {
				["volume"] = 0.8
			})
			return
		end
		if p63 ~= "waypoint" then
			local v114 = v112.play3D
			pcall(v114, "ev_radio_burst", p64, {
				["volume"] = 0.4
			})
		end
	end
end
local function v_u_119(p116) -- name: endWaypoint
	-- upvalues: (copy) v_u_49
	local v117 = false
	for _, v118 in v_u_49 do
		if not v118.wp or (v118.from ~= p116 or v118.fadingOut) then
			continue
		end
		v118.wp = false
		v118.life = v118.t + 1.2
		v117 = true
	end
	return v117
end
local function v_u_132(p120, p121, p122, p123, p124, p125, p126, p127) -- name: makeSeg
	-- upvalues: (ref) v_u_25, (ref) v_u_24
	local v128 = v_u_25.color
	local v129 = v_u_24.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Name"] = p121,
		["BackgroundColor3"] = v128.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p122, p123)
	}, p120)
	local v130 = v_u_24.stroke(v129, v128.line)
	local v131 = v_u_24.new("Frame", {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = p126,
		["Size"] = UDim2.new(0, 2, 1, 0)
	}, v129)
	v_u_24.icon(p124, {
		["parent"] = nil,
		["size"] = 18,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v129,
		["color"] = p126,
		["position"] = UDim2.new(0, 14, 0.5, 0),
		["anchor"] = Vector2.new(0, 0.5)
	})
	return {
		["btn"] = v129,
		["stroke"] = v130,
		["bar"] = v131,
		["label"] = v_u_24.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["textSize"] = nil,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v129,
			["text"] = p125,
			["textSize"] = p127,
			["color"] = v128.text,
			["position"] = UDim2.fromOffset(42, 0),
			["size"] = UDim2.new(1, -50, 1, 0)
		})
	}
end
local function v_u_164() -- name: buildWheel
	-- upvalues: (ref) v_u_27, (ref) v_u_25, (ref) v_u_12, (copy) v_u_7, (ref) v_u_24, (ref) v_u_13, (ref) v_u_28, (ref) v_u_36, (ref) v_u_37, (copy) v_u_3, (copy) v_u_32, (copy) v_u_33, (copy) v_u_132, (copy) v_u_29, (ref) v_u_38, (ref) v_u_43, (ref) v_u_44, (copy) v_u_31, (copy) v_u_6, (copy) v_u_30
	if not (v_u_27 and v_u_27.Parent) then
		local v133 = v_u_25.color
		v_u_12 = v_u_7.ringRadius(v_u_24.Theme.refSize().X)
		v_u_13 = v_u_7.catWidth(v_u_12)
		local v134, v135 = v_u_24.screen("HushCommsWheel", v_u_25.layer.hud + 3, {
			["insets"] = "None",
			["enabled"] = false
		})
		v_u_27 = v134
		v_u_24.new("TextButton", {
			["Name"] = "Catcher",
			["Text"] = "",
			["BackgroundTransparency"] = 1,
			["AutoButtonColor"] = false,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}, v135).Activated:Connect(function()
			-- upvalues: (ref) v_u_24, (ref) v_u_7
			if v_u_24.device() == "Touch" then
				v_u_7.close()
			end
		end)
		local v136 = v_u_24.new
		local v137 = {
			["Name"] = "Wheel",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		}
		local v138 = UDim2.fromOffset
		local v139 = (v_u_12 + v_u_13 / 2 + 16 + 176) * 2 + 16
		local v140 = v_u_12 * 2 * 0.9
		v137.Size = v138(v139, math.ceil(v140) + 120)
		local v141 = v136("Frame", v137, v135)
		v_u_28 = v141
		v_u_24.new("UIScale", {
			["Name"] = "Pop"
		}, v141)
		local v142 = v_u_24.new("Frame", {
			["Name"] = "Ring",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v133.bg,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(104, 104)
		}, v141)
		v_u_24.new("UICorner", {
			["CornerRadius"] = UDim.new(1, 0)
		}, v142)
		v_u_24.stroke(v142, v133.line, 1, 0.2)
		v_u_36 = v_u_24.label({
			["parent"] = nil,
			["name"] = "Center",
			["text"] = "Quick call",
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v141,
			["color"] = v133.text2,
			["position"] = UDim2.new(0.5, 0, 0.5, -6),
			["anchor"] = Vector2.new(0.5, 0.5),
			["size"] = UDim2.fromOffset(150, 20)
		})
		v_u_37 = v_u_24.label({
			["parent"] = nil,
			["name"] = "Hint",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v141,
			["color"] = v133.muted,
			["position"] = UDim2.new(0.5, 0, 0.5, 14),
			["anchor"] = Vector2.new(0.5, 0.5),
			["size"] = UDim2.fromOffset(96, 14)
		})
		local v143 = v_u_25.touch(48)
		local v144 = v_u_25.touch(44)
		for v145, v_u_146 in v_u_3 do
			local v147 = (v145 - 1) * 60 + 30
			local v148 = math.rad(v147)
			local v149 = Vector2.new(math.sin(v148) * v_u_12, -math.cos(v148) * v_u_12 * 0.9)
			v_u_32[v_u_146.id] = v149
			v_u_33[v_u_146.id] = v148
			local v150 = v_u_146.color
			local v151 = v_u_25.color[v150] or v_u_25.color.text
			local v152 = v_u_132(v141, "Cat_" .. v_u_146.id, v_u_13, v143, v_u_146.icon, v_u_146.text, v151, 16)
			v152.btn.Position = UDim2.new(0.5, v149.X, 0.5, v149.Y)
			local v153 = v149.X >= 0 and 1 or -1
			v_u_24.icon(v153 > 0 and "chevronRight" or "chevronLeft", {
				["parent"] = nil,
				["size"] = 12,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v152.btn,
				["color"] = v133.muted,
				["position"] = UDim2.new(1, -6, 0.5, 0),
				["anchor"] = Vector2.new(1, 0.5)
			})
			v_u_29[v_u_146.id] = v152
			v152.btn.Activated:Connect(function()
				-- upvalues: (ref) v_u_38, (ref) v_u_24, (ref) v_u_43, (copy) v_u_146, (ref) v_u_7, (ref) v_u_44
				if v_u_38 then
					if v_u_24.device() == "Touch" then
						if v_u_43 == v_u_146.id then
							v_u_7.send(v_u_146.calls[1])
							v_u_7.close()
						else
							v_u_43 = v_u_146.id
							v_u_44 = nil
							v_u_7._paint()
							v_u_24.sound("tick")
						end
					else
						v_u_7.send(v_u_146.calls[1])
						v_u_7.close()
						return
					end
				else
					return
				end
			end)
			local v154 = v_u_24.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["Name"] = "Calls_" .. v_u_146.id,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(176, #v_u_146.calls * (v144 + 6) - 6)
			}, v141)
			v_u_31[v_u_146.id] = v154
			for v155, v_u_156 in v_u_146.calls do
				local v157 = v_u_6[v_u_156]
				local v158 = v_u_132
				local v159 = "Call_" .. v_u_156
				local v160 = v157.icon
				local v161 = v157.text
				local v162 = v157.color
				local v163 = v158(v154, v159, 176, v144, v160, v161, v_u_25.color[v162] or v_u_25.color.text, 15)
				v163.btn.Position = UDim2.fromOffset(88, (v155 - 1) * (v144 + 6) + v144 / 2)
				v_u_30[v_u_156] = v163
				v163.btn.Activated:Connect(function()
					-- upvalues: (ref) v_u_38, (ref) v_u_7, (copy) v_u_156
					if v_u_38 then
						v_u_7.send(v_u_156)
						v_u_7.close()
					end
				end)
			end
		end
	end
end
local function v_u_195() -- name: layoutColumns
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_41, (copy) v_u_3, (copy) v_u_32, (copy) v_u_31, (ref) v_u_13, (copy) v_u_34, (copy) v_u_35
	local v165 = v_u_24.Theme.refSize()
	local v166 = v_u_25.touch(44)
	local v167 = 8 - v_u_41.Y
	local v168 = v165.Y - 8 - v_u_41.Y
	for _, v169 in v_u_3 do
		local v170 = v_u_32[v169.id]
		local v171 = v_u_31[v169.id]
		if not (v170 and v171) then
			continue
		end
		local v172 = v170.X >= 0 and 1 or -1
		local v173 = #v169.calls * (v166 + 6) - 6
		local v174 = v170.X + v172 * (v_u_13 / 2 + 16 + 88)
		local v175 = v170.Y
		local v176 = v167 + v173 / 2
		local v177 = v167 + v173 / 2
		local v178 = v168 - v173 / 2
		local v179 = math.max(v177, v178)
		local v180 = math.clamp(v175, v176, v179)
		if v_u_25.isPhone() then
			local v181 = v_u_25.touch(48)
			local v182 = v165.X / 2 - 8 - 88
			for _, v183 in v_u_3 do
				local v184 = v_u_32[v183.id]
				if v183.id == v169.id or not v184 then
					continue
				end
				local v185
				if v180 - v173 / 2 < v184.Y + v181 / 2 then
					v185 = v180 + v173 / 2 > v184.Y - v181 / 2
				else
					v185 = false
				end
				local v186
				if v174 - 88 < v184.X + v_u_13 / 2 then
					v186 = v174 + 88 > v184.X - v_u_13 / 2
				else
					v186 = false
				end
				if not (v185 and v186) then
					continue
				end
				local v187 = v184.X + v172 * (v_u_13 / 2 + 8 + 88)
				if v172 > 0 then
					local v188 = math.max(v174, v187)
					local v189 = math.max(v174, v182)
					v174 = math.min(v188, v189)
				else
					local v190 = math.min(v174, v187)
					local v191 = -v182
					local v192 = math.min(v174, v191)
					v174 = math.max(v190, v192)
				end
			end
		end
		v171.Position = UDim2.new(0.5, v174, 0.5, v180)
		v_u_34[v169.id] = {
			["x0"] = v174 - 88,
			["y0"] = v180 - v173 / 2,
			["x1"] = v174 + 88,
			["y1"] = v180 + v173 / 2,
			["side"] = v172
		}
		for v193, v194 in v169.calls do
			v_u_35[v194] = v180 - v173 / 2 + (v193 - 1) * (v166 + 6) + v166 / 2
		end
	end
end
function v_u_7._paint() -- name: _paint
	-- upvalues: (ref) v_u_25, (copy) v_u_29, (ref) v_u_43, (copy) v_u_30, (ref) v_u_44, (copy) v_u_31, (ref) v_u_36, (copy) v_u_6, (copy) v_u_4, (ref) v_u_24, (ref) v_u_37
	local v196 = v_u_25.color
	for v197, v198 in v_u_29 do
		local v199 = v197 == v_u_43
		local v200 = v198.stroke
		local v201
		if v199 then
			v201 = v196.accent
		else
			v201 = v196.line
		end
		v200.Color = v201
		local v202 = v198.btn
		local v203
		if v199 then
			v203 = v196.accentDeep
		else
			v203 = v196.bg
		end
		v202.BackgroundColor3 = v203
		v198.bar.Size = UDim2.new(0, v199 and 4 or 2, 1, 0)
	end
	for v204, v205 in v_u_30 do
		local v206 = v204 == v_u_44
		local v207 = v205.stroke
		local v208
		if v206 then
			v208 = v196.accent
		else
			v208 = v196.line
		end
		v207.Color = v208
		local v209 = v205.btn
		local v210
		if v206 then
			v210 = v196.accentDeep
		else
			v210 = v196.bg
		end
		v209.BackgroundColor3 = v210
		v205.bar.Size = UDim2.new(0, v206 and 4 or 2, 1, 0)
	end
	for v211, v212 in v_u_31 do
		v212.Visible = v211 == v_u_43
	end
	if v_u_36 then
		local v213 = v_u_44
		if v213 then
			v213 = v_u_6[v_u_44]
		end
		local v214 = v_u_43
		if v214 then
			v214 = v_u_4[v_u_43]
		end
		local v215 = "Quick call"
		local v216 = v196.text2
		if v213 then
			v215 = v213.text
			local v217 = v213.color
			v216 = v_u_25.color[v217]
			if not v216 then
				v216 = v_u_25.color.text
			end
		elseif v214 then
			local v218 = v_u_6[v214.calls[1]]
			if v_u_24.device() == "Touch" then
				v215 = v214.text
			else
				v215 = v218.text
			end
			local v219 = v214.color
			v216 = v_u_25.color[v219]
			if not v216 then
				v216 = v_u_25.color.text
			end
		end
		v_u_24.setText(v_u_36, v215)
		v_u_36.TextColor3 = v216
	end
	if v_u_37 then
		local v220 = v_u_24.device()
		v_u_24.setText(v_u_37, v220 == "Touch" and (v_u_43 and "Tap a call" or "Pick a topic") or "Release to send")
	end
end
local function v_u_223() -- name: showWheel
	-- upvalues: (ref) v_u_39, (ref) v_u_38, (ref) v_u_27, (ref) v_u_28, (ref) v_u_24
	if not v_u_39 and (v_u_38 and (v_u_27 and v_u_28)) then
		v_u_39 = true
		local v221 = v_u_28
		local v222 = v221:FindFirstChild("Pop")
		v222.Scale = 0.94
		v_u_24.tween(v222, {
			["Scale"] = 1
		}, "normal")
		v_u_24.fade(v221, 0, "fast", {
			["from"] = 1
		})
		v_u_27.Enabled = true
		v_u_24.sound("open")
	end
end
function v_u_7.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_38
	return v_u_38
end
function v_u_7.open() -- name: open
	-- upvalues: (ref) v_u_38, (ref) v_u_23, (copy) v_u_26, (copy) v_u_164, (ref) v_u_27, (ref) v_u_28, (ref) v_u_39, (ref) v_u_40, (ref) v_u_43, (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_25, (copy) v_u_2, (ref) v_u_42, (ref) v_u_41, (copy) v_u_195, (copy) v_u_7, (copy) v_u_223
	if not v_u_38 then
		local v224
		if v_u_23 == nil then
			v224 = false
		else
			v224 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v224 then
			v_u_164()
			if v_u_27 and v_u_28 then
				v_u_38 = true
				v_u_39 = false
				v_u_40 = os.clock()
				v_u_43 = nil
				v_u_44 = nil
				v_u_45 = v_u_40
				v_u_46 = nil
				local v225 = v_u_24.device()
				local v226 = v_u_24.Theme.refSize()
				local v227 = v_u_12 + v_u_13 / 2 + 16 + 176 + 8
				local v228 = v_u_12 * 0.9
				local v229 = math.ceil(v228) + v_u_25.touch(48) / 2 + 8
				if v225 == "Keyboard" then
					local v230 = v_u_24.toDesign(v_u_2:GetMouseLocation())
					v_u_42 = v230
					local v231 = Vector2.new
					local v232 = v230.X
					local v233 = v226.X / 2
					local v234 = math.min(v227, v233)
					local v235 = v226.X / 2
					local v236 = v226.X - v227
					local v237 = math.max(v235, v236)
					local v238 = math.clamp(v232, v234, v237)
					local v239 = v230.Y
					local v240 = v226.Y / 2
					local v241 = math.min(v229, v240)
					local v242 = v226.Y / 2
					local v243 = v226.Y - v229
					local v244 = math.max(v242, v243)
					v_u_41 = v231(v238, (math.clamp(v239, v241, v244)))
				else
					v_u_41 = Vector2.new(v226.X / 2, v226.Y / 2)
				end
				local v245 = v_u_28
				local v246
				if v225 == "Keyboard" then
					v246 = UDim2.fromOffset(v_u_41.X, v_u_41.Y)
				else
					v246 = UDim2.fromScale(0.5, 0.5)
				end
				v245.Position = v246
				v_u_195()
				v_u_7._paint()
				if v225 == "Touch" then
					v_u_223()
				else
					task.delay(0.14, function()
						-- upvalues: (ref) v_u_38, (ref) v_u_40, (ref) v_u_223
						if v_u_38 and os.clock() - v_u_40 >= 0.13 then
							v_u_223()
						end
					end)
				end
			else
				return
			end
		end
	end
end
function v_u_7.close() -- name: close
	-- upvalues: (ref) v_u_38, (ref) v_u_39, (ref) v_u_28, (ref) v_u_24, (ref) v_u_27
	if v_u_38 then
		v_u_38 = false
		local v247 = v_u_39
		v_u_39 = false
		if v_u_28 and v247 then
			v_u_24.fade(v_u_28, 1, "fast")
		end
		task.delay(v247 and 0.13 or 0, function()
			-- upvalues: (ref) v_u_38, (ref) v_u_27
			if not v_u_38 and v_u_27 then
				v_u_27.Enabled = false
			end
		end)
	end
end
function v_u_7.send(p248) -- name: send
	-- upvalues: (copy) v_u_6, (ref) v_u_23, (copy) v_u_26, (ref) v_u_21, (ref) v_u_24, (ref) v_u_47, (ref) v_u_48, (copy) v_u_115
	local v249 = v_u_6[p248]
	if v249 then
		local v250
		if v_u_23 == nil then
			v250 = false
		else
			v250 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v250 then
			local v251 = v_u_26.Character
			if v251 then
				v251 = v251:FindFirstChild("HumanoidRootPart")
			end
			if v251 then
				if p248 == "shout" then
					local v252 = 20 - (os.clock() - v_u_21)
					if v252 > 0 then
						v_u_24.sound("error")
						local v253 = v_u_24.toast
						local v254 = ("Shout ready in %d s"):format((math.ceil(v252)))
						pcall(v253, v254, "info")
						return
					end
				end
				local v255 = os.clock()
				local v256
				if v255 - v_u_47 < 0.5 then
					v_u_24.sound("error")
					v256 = true
				else
					v_u_47 = v255
					v256 = false
				end
				if not v256 then
					if p248 == "shout" then
						v_u_21 = os.clock()
					end
					local v257 = v251.Position
					local v258
					if v249.located then
						v_u_48 = p248
						local v259 = v_u_23.controllers.Input
						if v259 and v259.aimPoint then
							local v260 = v259.aimPoint
							local v261
							v261, v258 = pcall(v260)
							if v261 then
								if typeof(v258) ~= "Vector3" then
									v258 = v257
								end
							else
								v258 = v257
							end
						else
							v258 = v257
						end
					else
						v258 = v257
					end
					v_u_115(p248, v258, v_u_26.UserId, v_u_26.DisplayName, true)
					local v_u_262 = {
						["kind"] = p248,
						["pos"] = v258
					}
					task.spawn(function()
						-- upvalues: (ref) v_u_23, (copy) v_u_262
						local v263 = v_u_23.net.fire
						local v264 = v_u_262
						pcall(v263, "comm.ping", v264)
					end)
				end
			else
				return
			end
		end
	end
end
function v_u_7.pingItem(p265, p266, p267) -- name: pingItem
	-- upvalues: (ref) v_u_23, (copy) v_u_26, (copy) v_u_56, (ref) v_u_47, (ref) v_u_24, (copy) v_u_115
	if type(p265) == "string" and typeof(p266) == "Vector3" then
		local v268
		if v_u_23 == nil then
			v268 = false
		else
			v268 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v268 and v_u_56(p265) then
			local v269 = os.clock()
			local v270
			if v269 - v_u_47 < 0.5 then
				v_u_24.sound("error")
				v270 = true
			else
				v_u_47 = v269
				v270 = false
			end
			if not v270 then
				if type(p267) == "string" and p267 ~= "" then
					if #p267 > 24 then
						p267 = string.sub(p267, 1, 23) .. "\226\128\166"
					end
				else
					p267 = nil
				end
				v_u_115("item", p266, v_u_26.UserId, v_u_26.DisplayName, true, {
					["item"] = nil,
					["label"] = nil,
					["fixed"] = true,
					["item"] = p265,
					["label"] = p267
				})
				local v_u_271 = {
					["kind"] = "item",
					["pos"] = nil,
					["item"] = nil,
					["label"] = nil,
					["pos"] = p266,
					["item"] = p265,
					["label"] = p267
				}
				task.spawn(function()
					-- upvalues: (ref) v_u_23, (copy) v_u_271
					local v272 = v_u_23.net.fire
					local v273 = v_u_271
					pcall(v272, "comm.ping", v273)
				end)
			end
		end
	end
end
function v_u_7.pingExtract(p274) -- name: pingExtract
	-- upvalues: (ref) v_u_23, (copy) v_u_26, (copy) v_u_62, (copy) v_u_49, (copy) v_u_7, (ref) v_u_47, (ref) v_u_24, (copy) v_u_115
	if type(p274) == "string" and p274 ~= "" then
		local v275
		if v_u_23 == nil then
			v275 = false
		else
			v275 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v275 then
			local v276 = v_u_62(p274)
			if v276 then
				for _, v277 in v_u_49 do
					if not v277.persist or (v277.extractId ~= p274 or v277.fadingOut) then
						continue
					end
					v_u_7.cancelExtractPing()
					return
				end
				local v278 = os.clock()
				local v279
				if v278 - v_u_47 < 0.5 then
					v_u_24.sound("error")
					v279 = true
				else
					v_u_47 = v278
					v279 = false
				end
				if not v279 then
					local v280 = v276:GetAttribute("Name")
					local v281 = v_u_115
					local v282 = "extract"
					local v283 = v276.Position
					local v284 = v_u_26.UserId
					local v285 = v_u_26.DisplayName
					local v286 = true
					local v287 = {
						["extract"] = nil,
						["extractName"] = nil,
						["fixed"] = true,
						["extract"] = p274
					}
					if type(v280) ~= "string" then
						v280 = p274
					end
					v287.extractName = v280
					v281(v282, v283, v284, v285, v286, v287)
					local v_u_288 = {
						["kind"] = "extract",
						["extract"] = nil,
						["pos"] = nil,
						["extract"] = p274,
						["pos"] = v276.Position
					}
					task.spawn(function()
						-- upvalues: (ref) v_u_23, (copy) v_u_288
						local v289 = v_u_23.net.fire
						local v290 = v_u_288
						pcall(v289, "comm.ping", v290)
					end)
				end
			else
				return
			end
		end
	end
end
function v_u_7.pingAt(p291, p292) -- name: pingAt
	-- upvalues: (copy) v_u_6, (ref) v_u_23, (copy) v_u_26, (ref) v_u_47, (ref) v_u_24, (copy) v_u_115
	if v_u_6[p291] and typeof(p292) == "Vector3" then
		local v293
		if v_u_23 == nil then
			v293 = false
		else
			v293 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v293 then
			local v294 = os.clock()
			local v295
			if v294 - v_u_47 < 0.5 then
				v_u_24.sound("error")
				v295 = true
			else
				v_u_47 = v294
				v295 = false
			end
			if not v295 then
				v_u_115(p291, p292, v_u_26.UserId, v_u_26.DisplayName, true, {
					["fixed"] = true
				})
				local v_u_296 = {
					["kind"] = nil,
					["pos"] = nil,
					["fixed"] = true,
					["kind"] = p291,
					["pos"] = p292
				}
				task.spawn(function()
					-- upvalues: (ref) v_u_23, (copy) v_u_296
					local v297 = v_u_23.net.fire
					local v298 = v_u_296
					pcall(v297, "comm.ping", v298)
				end)
			end
		end
	end
end
function v_u_7.setWaypoint(p299) -- name: setWaypoint
	-- upvalues: (ref) v_u_23, (copy) v_u_26, (ref) v_u_47, (ref) v_u_24, (copy) v_u_49, (copy) v_u_115
	if typeof(p299) == "Vector3" and (p299.X == p299.X and p299.Z == p299.Z) then
		local v300
		if v_u_23 == nil then
			v300 = false
		else
			v300 = v_u_23.session.place(v_u_26) == "Raid"
		end
		if v300 then
			local v301 = os.clock()
			local v302
			if v301 - v_u_47 < 0.5 then
				v_u_24.sound("error")
				v302 = true
			else
				v_u_47 = v301
				v302 = false
			end
			if v302 then
				return false
			end
			for v303 = #v_u_49, 1, -1 do
				if not v_u_49[v303].wp or v_u_49[v303].from ~= v_u_26.UserId then
					continue
				end
				local v304 = v_u_49[v303]
				v304.f:Destroy()
				v304.arrow:Destroy()
				v304.cap:Destroy()
				table.remove(v_u_49, v303)
			end
			v_u_115("waypoint", p299, v_u_26.UserId, v_u_26.DisplayName, true, {
				["fixed"] = true
			})
			v_u_26:SetAttribute("CommsWaypoint", p299)
			local v_u_305 = {
				["kind"] = "waypoint",
				["pos"] = nil,
				["fixed"] = true,
				["pos"] = p299
			}
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (copy) v_u_305
				local v306 = v_u_23.net.fire
				local v307 = v_u_305
				pcall(v306, "comm.ping", v307)
			end)
			return true
		end
	end
	return false
end
function v_u_7.clearWaypoint() -- name: clearWaypoint
	-- upvalues: (copy) v_u_119, (copy) v_u_26, (ref) v_u_24, (ref) v_u_23
	local v308 = v_u_119(v_u_26.UserId)
	v_u_26:SetAttribute("CommsWaypoint", nil)
	v_u_26:SetAttribute("CommsWaypointM", nil)
	if v308 then
		if v_u_24 then
			v_u_24.sound("click")
		end
		local v_u_309 = {
			["kind"] = "waypointclear"
		}
		task.spawn(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_309
			local v310 = v_u_23.net.fire
			local v311 = v_u_309
			pcall(v310, "comm.ping", v311)
		end)
	end
	return v308
end
function v_u_7.waypoint() -- name: waypoint
	-- upvalues: (copy) v_u_49, (copy) v_u_26
	for _, v312 in v_u_49 do
		if not v312.wp or (v312.from ~= v_u_26.UserId or v312.fadingOut) then
			continue
		end
		return v312.pos
	end
	return nil
end
function v_u_7.waypoints() -- name: waypoints
	-- upvalues: (copy) v_u_49, (copy) v_u_26
	local v313 = {}
	for _, v314 in v_u_49 do
		if not v314.wp or v314.fadingOut then
			continue
		end
		local v315 = v314.f:GetAttribute("Caller")
		local v316 = {
			["from"] = v314.from,
			["name"] = type(v315) ~= "string" and "?" or v315,
			["pos"] = v314.pos,
			["own"] = v314.from == v_u_26.UserId
		}
		table.insert(v313, v316)
	end
	return v313
end
function v_u_7.shoutCooldown() -- name: shoutCooldown
	-- upvalues: (ref) v_u_21
	local v317 = 20 - (os.clock() - v_u_21)
	return math.max(0, v317)
end
function v_u_7.extractPing() -- name: extractPing
	-- upvalues: (copy) v_u_49
	for _, v318 in v_u_49 do
		if not v318.persist or v318.fadingOut then
			continue
		end
		return v318.extractId, v318.pos
	end
	return nil, nil
end
function v_u_7.cancelExtractPing() -- name: cancelExtractPing
	-- upvalues: (copy) v_u_49, (copy) v_u_20, (ref) v_u_24
	local v319 = false
	for _, v320 in v_u_49 do
		if not v320.persist or v320.fadingOut then
			continue
		end
		if not v320.fadingOut and v320.persist then
			v320.persist = false
			v320.life = v320.t + 1.2
			v_u_20.cancelled = (v_u_20.cancelled or 0) + 1
		end
		v319 = true
	end
	if v319 and v_u_24 then
		v_u_24.sound("click")
	end
	return v319
end
function v_u_7.init(p321) -- name: init
	-- upvalues: (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (copy) v_u_26, (copy) v_u_62, (copy) v_u_115, (copy) v_u_49, (ref) v_u_47, (copy) v_u_7, (ref) v_u_38, (ref) v_u_39, (ref) v_u_43, (ref) v_u_44, (ref) v_u_46, (copy) v_u_20, (copy) v_u_119, (copy) v_u_22, (ref) v_u_27, (ref) v_u_28, (ref) v_u_36, (ref) v_u_37, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_223, (copy) v_u_4, (copy) v_u_6
	v_u_23 = p321
	v_u_24 = p321.lib.HushUI
	v_u_24.bind(p321)
	v_u_25 = p321.shared.Theme
	p321.command("comms.test", function(p322)
		-- upvalues: (ref) v_u_26, (ref) v_u_62, (ref) v_u_115, (ref) v_u_49
		local v323 = v_u_26.Character
		if v323 then
			v323 = v323:FindFirstChild("HumanoidRootPart")
		end
		if not v323 then
			return "no character"
		end
		local v324 = p322[1] or "loot"
		local v325 = v323.Position + v323.CFrame.LookVector * 20
		local v326 = nil
		if v324 == "item" and p322[2] then
			v326 = {
				["item"] = nil,
				["label"] = nil,
				["fixed"] = true,
				["item"] = p322[2],
				["label"] = p322[3] or "Cabinet"
			}
		elseif v324 == "extract" and p322[2] then
			local v327 = v_u_62(p322[2])
			if v327 then
				v325 = v327.Position
			end
			v326 = {
				["extract"] = nil,
				["extractName"] = nil,
				["fixed"] = true,
				["extract"] = p322[2],
				["extractName"] = v327 and v327:GetAttribute("Name") or p322[2]
			}
		end
		v_u_115(v324, v325, 1, "Tester", true, v326)
		return "marker added (" .. #v_u_49 .. ")"
	end)
	p321.command("comms.pingitem", function(p328)
		-- upvalues: (ref) v_u_26, (ref) v_u_47, (ref) v_u_7, (ref) v_u_49
		local v329 = v_u_26.Character
		if v329 then
			v329 = v329:FindFirstChild("HumanoidRootPart")
		end
		if not v329 then
			return "no character"
		end
		v_u_47 = 0
		local v330 = v329.Position + v329.CFrame.LookVector * 8
		local v331 = 14
		for _, v332 in game:GetService("CollectionService"):GetTagged("HushContainer") do
			local v333
			if v332:IsA("Model") then
				v333 = v332:GetPivot().Position
			elseif v332:IsA("BasePart") then
				v333 = v332.Position
			else
				v333 = nil
			end
			if not v333 or (v333 - v329.Position).Magnitude >= v331 then
				continue
			end
			v331 = (v333 - v329.Position).Magnitude
			v330 = v333
		end
		v_u_7.pingItem(p328[1] or "med_bandage", v330, p328[2])
		return "pinged item, markers=" .. #v_u_49
	end)
	p321.command("comms.pingextract", function(p334)
		-- upvalues: (ref) v_u_47, (ref) v_u_23, (ref) v_u_7, (ref) v_u_49
		v_u_47 = 0
		local v335 = p334[1]
		if not v335 then
			local v336 = v_u_23.runtime
			v335 = v336 and v336:FindFirstChild("Raid")
			if v335 then
				v335 = v336.Raid:FindFirstChild("Extracts")
			end
			if v335 then
				v335 = v335:GetChildren()[1]
			end
			if v335 then
				local v337 = v335:GetAttribute("ExtractId") or v335.Name
				v335 = tostring(v337)
			end
		end
		if not v335 then
			return "no extracts"
		end
		v_u_7.pingExtract(v335)
		return "pinged extract " .. v335 .. ", markers=" .. #v_u_49
	end)
	p321.command("comms.state", function()
		-- upvalues: (ref) v_u_49, (ref) v_u_38, (ref) v_u_39, (ref) v_u_43, (ref) v_u_44, (ref) v_u_46, (ref) v_u_20
		local v338 = {}
		for _, v339 in v_u_49 do
			local v340 = v339.life == (1 / 0) and "inf" or string.format("%.1f", v339.life)
			local v341 = v339.kind .. ":" .. v339.slot .. ":" .. v339.title .. ":" .. string.format("%.1f/", v339.t) .. v340 .. (v339.persist and ":persist" or "") .. (v339.f.Visible and ":on" or (v339.arrow.Visible and ":edge" or ":hidden"))
			table.insert(v338, v341)
		end
		local v342 = v_u_38
		local v343 = v_u_39
		local v344 = v_u_43
		local v345 = v_u_44
		local v346 = v_u_46
		return "open=" .. tostring(v342) .. " shown=" .. tostring(v343) .. " cat=" .. tostring(v344) .. " sub=" .. tostring(v345) .. " lock=" .. tostring(v346) .. " markers=" .. #v_u_49 .. ("  q131 reached=%d cancelled=%d closed=%d  "):format(v_u_20.reached, v_u_20.cancelled, v_u_20.closed) .. table.concat(v338, ", ")
	end)
	p321.command("comms.waypoint", function(p347)
		-- upvalues: (ref) v_u_47, (ref) v_u_7, (ref) v_u_115, (ref) v_u_49, (ref) v_u_119, (ref) v_u_26
		v_u_47 = 0
		local v348 = p347[1]
		if v348 == "clear" then
			local v349 = v_u_7.clearWaypoint
			return "cleared=" .. tostring(v349())
		elseif v348 == "mate" then
			local v350 = v_u_115
			local v351 = p347[2]
			local v352 = tonumber(v351) or 0
			local v353 = p347[3]
			local v354 = tonumber(v353) or 0
			v350("waypoint", Vector3.new(v352, 1, v354), 2, "Mate", true, {
				["fixed"] = true
			})
			return "mate waypoint, markers=" .. #v_u_49
		elseif v348 == "mateclear" then
			local v355 = v_u_119(2)
			return "mate cleared=" .. tostring(v355)
		else
			local v356 = p347[1]
			local v357 = tonumber(v356)
			local v358 = p347[2]
			local v359 = tonumber(v358)
			if v357 and v359 then
				local v360 = v_u_7.setWaypoint
				local v361 = Vector3.new(v357, 1, v359)
				return "set=" .. tostring(v360(v361))
			else
				local v362 = v_u_7.waypoint()
				local v363 = v_u_26
				return "waypoint=" .. tostring(v362) .. " m=" .. tostring(v363:GetAttribute("CommsWaypointM"))
			end
		end
	end)
	p321.command("comms.recv", function()
		-- upvalues: (ref) v_u_22, (ref) v_u_7
		local v364 = {}
		for v365, v366 in v_u_22 do
			local v367 = v365 .. "=" .. v366
			table.insert(v364, v367)
		end
		table.sort(v364)
		return table.concat(v364, " ") .. " shoutCd=" .. string.format("%.1f", v_u_7.shoutCooldown())
	end)
	p321.command("comms.cancel", function()
		-- upvalues: (ref) v_u_7
		local v368 = v_u_7.cancelExtractPing
		return "cancelled=" .. tostring(v368())
	end)
	p321.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_38, (ref) v_u_43, (ref) v_u_44, (ref) v_u_39, (ref) v_u_27, (ref) v_u_28, (ref) v_u_36, (ref) v_u_37, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_7, (ref) v_u_223
		local v369 = v_u_38
		local v370 = v_u_43
		local v371 = v_u_44
		v_u_38 = false
		v_u_39 = false
		if v_u_27 then
			v_u_27:Destroy()
		end
		v_u_27 = nil
		v_u_28 = nil
		v_u_36 = nil
		v_u_37 = nil
		table.clear(v_u_29)
		table.clear(v_u_30)
		table.clear(v_u_31)
		if v369 then
			v_u_7.open()
			v_u_43 = v370
			v_u_44 = v371
			v_u_223()
			v_u_7._paint()
		end
	end)
	p321.command("comms.wheel", function(p372)
		-- upvalues: (ref) v_u_38, (ref) v_u_7, (ref) v_u_4, (ref) v_u_43, (ref) v_u_44, (ref) v_u_6, (ref) v_u_223
		if v_u_38 and not p372[1] then
			v_u_7.close()
		else
			if not v_u_38 then
				v_u_7.open()
			end
			if p372[1] and v_u_4[p372[1]] then
				v_u_43 = p372[1]
				local v373
				if p372[2] and v_u_6[p372[2]] then
					v373 = p372[2]
				else
					v373 = nil
				end
				v_u_44 = v373
			end
			v_u_223()
			v_u_7._paint()
		end
		local v374 = v_u_38
		local v375 = v_u_43
		local v376 = v_u_44
		return "open=" .. tostring(v374) .. " cat=" .. tostring(v375) .. " sub=" .. tostring(v376)
	end)
end
function v_u_7.start() -- name: start
	-- upvalues: (ref) v_u_23, (copy) v_u_26, (copy) v_u_22, (copy) v_u_119, (copy) v_u_115, (copy) v_u_1, (ref) v_u_24, (ref) v_u_38, (copy) v_u_7, (ref) v_u_44, (ref) v_u_43, (ref) v_u_40, (copy) v_u_4, (ref) v_u_48, (copy) v_u_49
	task.spawn(function()
		-- upvalues: (ref) v_u_23, (ref) v_u_26, (ref) v_u_22, (ref) v_u_119, (ref) v_u_115
		v_u_23.net.listen("comm.ping", function(p377)
			-- upvalues: (ref) v_u_23, (ref) v_u_26, (ref) v_u_22, (ref) v_u_119, (ref) v_u_115
			if type(p377) == "table" then
				local v378 = p377.pos
				if typeof(v378) == "Vector3" then
					local v379 = p377.kind
					if type(v379) == "string" then
						local v380
						if v_u_23 == nil then
							v380 = false
						else
							v380 = v_u_23.session.place(v_u_26) == "Raid"
						end
						if v380 then
							local v381 = p377.from
							local v382 = tonumber(v381) or 0
							local v383
							if p377.kind == "waypoint" or p377.kind == "waypointclear" then
								v383 = p377.kind
							else
								v383 = (p377.kind == "item" or p377.item) and "item" or (p377.extract and "extractPing" or (p377.fixed and "mapPing" or "quick"))
							end
							local v384 = (p377.squad == true and "own_" or "foreign_") .. v383
							if p377.squad == true or v383 == "quick" then
								v_u_22[v384] = (v_u_22[v384] or 0) + 1
								if p377.kind == "waypointclear" then
									v_u_119(v382)
								else
									local v385 = v_u_115
									local v386 = p377.kind
									local v387 = p377.pos
									local v388 = p377.name or "?"
									local v389 = tostring(v388)
									local v390 = p377.squad == true
									local v391 = {}
									local v392 = p377.item
									local v393
									if type(v392) == "string" then
										v393 = p377.item
									else
										v393 = nil
									end
									v391.item = v393
									local v394 = p377.label
									local v395
									if type(v394) == "string" then
										v395 = p377.label
									else
										v395 = nil
									end
									v391.label = v395
									local v396 = p377.extract
									local v397
									if type(v396) == "string" then
										v397 = p377.extract
									else
										v397 = nil
									end
									v391.extract = v397
									local v398 = p377.extractName
									local v399
									if type(v398) == "string" then
										v399 = p377.extractName
									else
										v399 = nil
									end
									v391.extractName = v399
									v391.fixed = p377.fixed == true
									v385(v386, v387, v382, v389, v390, v391)
								end
							else
								v_u_22.droppedForeign = (v_u_22.droppedForeign or 0) + 1
								return
							end
						else
							return
						end
					end
				end
			end
		end)
	end)
	v_u_1.PlayerRemoving:Connect(function(p400)
		-- upvalues: (ref) v_u_119
		v_u_119(p400.UserId)
	end)
	local v401 = v_u_23.controllers.Input
	if v401 and v401.bind then
		v401.bind("ping", function()
			-- upvalues: (ref) v_u_24, (ref) v_u_38, (ref) v_u_7
			if v_u_24.device() == "Touch" then
				if v_u_38 then
					v_u_7.close()
				else
					v_u_7.open()
				end
			else
				v_u_7.open()
				return
			end
		end, function()
			-- upvalues: (ref) v_u_24, (ref) v_u_38, (ref) v_u_44, (ref) v_u_43, (ref) v_u_40, (ref) v_u_7, (ref) v_u_4, (ref) v_u_48
			if v_u_24.device() ~= "Touch" then
				if v_u_38 then
					local v402 = v_u_44
					local v403 = v_u_43
					local v404 = os.clock() - v_u_40 < 0.25
					v_u_7.close()
					if v402 then
						v_u_7.send(v402)
						return
					end
					if v403 then
						v_u_7.send(v_u_4[v403].calls[1])
						return
					end
					if v404 then
						v_u_7.send(v_u_48)
					end
				end
			end
		end)
	end
	v_u_23.session.onPlaceChanged(function(p405)
		-- upvalues: (ref) v_u_7, (ref) v_u_49, (ref) v_u_26
		if p405 ~= "Raid" then
			v_u_7.close()
			for v406 = #v_u_49, 1, -1 do
				local v407 = v_u_49[v406]
				v407.f:Destroy()
				v407.arrow:Destroy()
				v407.cap:Destroy()
				table.remove(v_u_49, v406)
			end
			v_u_26:SetAttribute("CommsWaypoint", nil)
			v_u_26:SetAttribute("CommsWaypointM", nil)
		end
	end)
end
local function v_u_414(p408) -- name: nearestCat
	-- upvalues: (copy) v_u_3, (copy) v_u_33
	local v409 = v_u_3[1].id
	local v410 = (1 / 0)
	for _, v411 in v_u_3 do
		local v412 = (p408 - v_u_33[v411.id] + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v413 = math.abs(v412)
		if v413 >= v410 then
			continue
		end
		v409 = v411.id
		v410 = v413
	end
	return v409
end
local function v_u_430(p415, p416) -- name: pickPointer
	-- upvalues: (ref) v_u_43, (ref) v_u_44, (copy) v_u_34, (ref) v_u_25, (copy) v_u_4, (copy) v_u_35, (ref) v_u_12, (copy) v_u_414, (ref) v_u_45
	if p416.Magnitude < 34 then
		v_u_43 = nil
		v_u_44 = nil
	else
		if v_u_43 then
			local v417 = v_u_34[v_u_43]
			local v418 = v_u_25.touch(44) * 0.6
			if v417 and (p415.Y >= v417.y0 - v418 and p415.Y <= v417.y1 + v418) and (v417.side > 0 and p415.X >= v417.x0 - 10 or v417.side < 0 and p415.X <= v417.x1 + 10) then
				local v419 = (1 / 0)
				local v420 = nil
				for _, v421 in v_u_4[v_u_43].calls do
					local v422 = (v_u_35[v421] or 0) - p415.Y
					local v423 = math.abs(v422)
					if v423 >= v419 then
						continue
					end
					v420 = v421
					v419 = v423
				end
				v_u_44 = v420
				return
			end
		end
		if v_u_12 < p415.Magnitude then
			p416 = p415
		end
		local v424 = v_u_414
		local v425 = Vector2.new(p416.X, p416.Y / 0.9)
		local v426 = v425.X
		local v427 = -v425.Y
		local v428 = math.atan2(v426, v427)
		if v428 < 0 then
			v428 = v428 + 6.283185307179586
		end
		local v429 = v424(v428)
		if v429 ~= v_u_43 then
			v_u_45 = os.clock()
		end
		v_u_43 = v429
		v_u_44 = nil
	end
end
local function v_u_443(p431, p432) -- name: padRow
	-- upvalues: (copy) v_u_4, (ref) v_u_44
	local v433 = v_u_4[p431].calls
	local v434 = #v433
	if v434 == 0 then
		return nil
	end
	local v435 = (p432 + 0.8) / 1.6
	local v436 = math.clamp(v435, 0, 0.999)
	local v437 = v436 * v434
	local v438 = math.floor(v437) + 1
	local v439
	if v_u_44 then
		v439 = table.find(v433, v_u_44)
	else
		v439 = nil
	end
	if v439 then
		local v440 = v438 - v439
		if math.abs(v440) == 1 then
			local v441
			if v439 < v438 then
				v441 = v439
			else
				v441 = v439 - 1
			end
			local v442 = v436 - v441 / v434
			if math.abs(v442) >= 0.05 then
				v439 = v438
			end
		else
			v439 = v438
		end
	else
		v439 = v438
	end
	return v433[v439]
end
local function v_u_453(p444) -- name: pickStick
	-- upvalues: (ref) v_u_46, (copy) v_u_4, (ref) v_u_43, (ref) v_u_44, (copy) v_u_443, (copy) v_u_414, (ref) v_u_45
	if p444.Magnitude < 0.3 then
		v_u_46 = nil
		return
	elseif v_u_46 and v_u_4[v_u_46] then
		local v445 = v_u_46
		local v446 = v_u_443(v_u_46, p444.Y)
		v_u_43 = v445
		v_u_44 = v446
		return
	elseif p444.Magnitude < 0.5 then
		return
	else
		local v447 = v_u_414
		local v448 = p444.X
		local v449 = -p444.Y
		local v450 = math.atan2(v448, v449)
		if v450 < 0 then
			v450 = v450 + 6.283185307179586
		end
		local v451 = v447(v450)
		local v452 = os.clock()
		if v451 == v_u_43 then
			if v452 - v_u_45 >= 0.2 then
				v_u_46 = v451
				v_u_44 = v_u_443(v451, p444.Y)
			end
		else
			v_u_43 = v451
			v_u_44 = nil
			v_u_45 = v452
		end
	end
end
v_u_7._pickStick = v_u_453
function v_u_7.step(p454) -- name: step
	-- upvalues: (ref) v_u_38, (ref) v_u_43, (ref) v_u_44, (ref) v_u_24, (copy) v_u_2, (copy) v_u_430, (ref) v_u_41, (ref) v_u_42, (ref) v_u_23, (copy) v_u_453, (ref) v_u_39, (ref) v_u_40, (copy) v_u_223, (copy) v_u_7, (copy) v_u_49, (copy) v_u_26, (ref) v_u_25, (copy) v_u_62, (copy) v_u_20, (copy) v_u_1
	if v_u_38 then
		local v455 = v_u_43
		local v456 = v_u_44
		local v457 = v_u_24.device()
		if v457 == "Keyboard" then
			local v458 = v_u_24.toDesign(v_u_2:GetMouseLocation())
			v_u_430(v458 - v_u_41, v458 - v_u_42)
		elseif v457 == "Gamepad" then
			for _, v459 in v_u_23.lib.VirtualPad.gamepadState() do
				if v459.KeyCode ~= Enum.KeyCode.Thumbstick2 then
					continue
				end
				v_u_453(Vector2.new(v459.Position.X, -v459.Position.Y))
			end
		end
		if not v_u_39 and (v457 ~= "Touch" and os.clock() - v_u_40 >= 0.14) then
			v_u_223()
		end
		if v_u_43 ~= v455 or v_u_44 ~= v456 then
			v_u_7._paint()
			if v_u_39 then
				v_u_24.sound("tick")
			end
		end
	end
	if #v_u_49 ~= 0 then
		local v460 = v_u_24.Theme.refSize()
		local v461 = v_u_26.Character
		if v461 then
			v461 = v461:FindFirstChild("HumanoidRootPart")
		end
		local v_u_462 = {}
		local v_u_463 = nil
		if v_u_24.device() == "Touch" and v_u_25.isPhone() then
			local function v474()
				-- upvalues: (ref) v_u_463, (ref) v_u_23, (ref) v_u_24, (copy) v_u_462
				v_u_463 = v_u_23.lib.SquadMarkersEdge
				local v464 = v_u_23.controllers.Input
				local v465 = v464 and v464.touchRects
				if v465 then
					v465 = v464.touchRects()
				end
				if type(v465) == "table" then
					local v466 = Vector2.zero
					local v467 = v464.touch
					if v467 then
						v467 = v464.touch()
					end
					if v467 then
						v467 = v467.root
					end
					if v467 and v467:IsA("GuiObject") then
						v466 = v467.AbsolutePosition
					end
					for v468, v469 in v465 do
						if typeof(v469) ~= "Rect" or v468 == "moveZone" then
							continue
						end
						local v470 = v_u_24.absToOverlay(v466 + v469.Min)
						local v471 = v_u_24.absToOverlay(v466 + v469.Max)
						local v472 = v_u_462
						local v473 = {
							v470.X,
							v470.Y,
							v471.X,
							v471.Y
						}
						table.insert(v472, v473)
					end
				end
			end
			pcall(v474)
		end
		for v475 = #v_u_49, 1, -1 do
			local v476 = v_u_49[v475]
			v476.t = v476.t + p454
			if v476.t >= v476.life then
				local v477 = v_u_49[v475]
				v477.f:Destroy()
				v477.arrow:Destroy()
				v477.cap:Destroy()
				table.remove(v_u_49, v475)
			else
				if v476.persist and v476.extractId then
					local v478 = v_u_62(v476.extractId)
					if v478 and v478:GetAttribute("Open") ~= false then
						if v461 then
							local v479 = v478.CFrame:PointToObjectSpace(v461.Position)
							local v480 = v479.X
							if math.abs(v480) <= v478.Size.X / 2 + 4 then
								local v481 = v479.Z
								if math.abs(v481) <= v478.Size.Z / 2 + 4 and (not v476.fadingOut and v476.persist) then
									v476.persist = false
									v476.life = v476.t + 1.2
									v_u_20.reached = (v_u_20.reached or 0) + 1
								end
							end
						end
					elseif not v476.fadingOut and v476.persist then
						v476.persist = false
						v476.life = v476.t + 1.2
						v_u_20.closed = (v_u_20.closed or 0) + 1
					end
					local v482 = v_u_26:GetAttribute("RaidStatus")
					if v476.persist and (v482 == "Dead" or v482 == "Extracted") and (not v476.fadingOut and v476.persist) then
						v476.persist = false
						v476.life = v476.t + 1.2
						v_u_20.closed = (v_u_20.closed or 0) + 1
					end
				end
				if v476.follow then
					local v483 = v_u_1:GetPlayerByUserId(v476.follow)
					if v483 then
						v483 = v483.Character
					end
					if v483 then
						v483 = v483:FindFirstChild("HumanoidRootPart")
					end
					if v483 then
						v476.pos = v483.Position + Vector3.new(0, 3.5, 0)
					end
				end
				local v484, v485, v486 = v_u_24.screenMarker(v476.pos, 60, 130, v460.X - 60, v460.Y - 60 - 40, true)
				local v487 = (v476.life - v476.t) / 1.2
				local v488 = math.clamp(v487, 0, 1)
				if not v476.fadingOut and v476.life - v476.t <= 1.2 then
					v476.fadingOut = true
					local v489 = v_u_24.fade
					local v490 = v476.f
					local v491 = v476.life - v476.t
					v489(v490, 1, (math.max(0.05, v491)))
				end
				local v492
				if v461 then
					local v493 = v476.pos - v461.Position
					local v494 = v493.X
					local v495 = v493.Z
					local v496 = Vector3.new(v494, 0, v495).Magnitude * 0.28 + 0.5
					local v497 = math.floor(v496)
					v492 = tostring(v497) .. " m"
					if v476.dist.Text ~= v492 then
						v476.dist.Text = v492
						if v476.wp and v476.from == v_u_26.UserId then
							v_u_26:SetAttribute("CommsWaypointM", v492)
						end
					end
				else
					v492 = ""
				end
				if v486 then
					v476.f.Visible = true
					v476.arrow.Visible = false
					v476.cap.Visible = false
					v476.f.Position = UDim2.fromOffset(v484.X, v484.Y)
				else
					v476.f.Visible = false
					v476.arrow.Visible = true
					v476.cap.Visible = true
					local v498
					if #v_u_462 > 0 and (v_u_463 and v_u_463.avoid) then
						local v499 = v_u_463.avoid
						local v500 = {
							60,
							130,
							v460.X - 60,
							v460.Y - 60 - 40
						}
						local v501
						v501, v498 = pcall(v499, v484, v_u_462, v500, 36)
						if v501 then
							if typeof(v498) ~= "Vector2" then
								v498 = v484
							end
						else
							v498 = v484
						end
					else
						v498 = v484
					end
					v476.arrow.Position = UDim2.fromOffset(v498.X, v498.Y)
					local v502 = v476.arrow
					local v503 = v485.X
					local v504 = -v485.Y
					local v505 = math.atan2(v503, v504)
					v502.Rotation = math.deg(v505)
					local v506 = v498 - v485 * 22
					local v507 = Vector2.new(v485.X > 0 and 1 or -1, 0)
					local v508 = v485.X
					local v509 = v506 - v507 * math.abs(v508) * 92
					local v510 = Vector2.new(0, v485.Y > 0 and 1 or -1)
					local v511 = v485.Y
					local v512 = v509 - v510 * math.abs(v511) * 14
					local v513 = v512.X
					local v514 = v460.X - 8 - 85
					local v515 = math.clamp(v513, 93, v514)
					v476.cap.Position = UDim2.fromOffset(v515, v512.Y)
					local v516 = string.upper(v476.title) .. "  " .. v492
					if v476.cap.Text ~= v516 then
						v476.cap.Text = v516
					end
					v476.cap.TextTransparency = 1 - v488
					for _, v517 in v476.arrow:GetDescendants() do
						if not v517:IsA("Frame") or v517.Name ~= "g" then
							continue
						end
						v517.BackgroundTransparency = 1 - v488
					end
				end
			end
		end
	end
end
return v_u_7