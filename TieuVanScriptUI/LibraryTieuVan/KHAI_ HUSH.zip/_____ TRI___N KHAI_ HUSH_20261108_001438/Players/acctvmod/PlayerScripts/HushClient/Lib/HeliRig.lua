-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HeliRig

local v_u_65 = {
	["model"] = function(p1) -- name: model
		local v2 = p1 and p1.shared
		if v2 then
			v2 = p1.shared.Assets
		end
		if v2 then
			local v3 = v2.get
			local v4, v5 = pcall(v3, "Vehicle", "Heli")
			if v4 and (typeof(v5) == "Instance" and v5:IsA("Model")) then
				local v6 = string.find(v5.Name, "_MISSING", 1, true) ~= nil
				for _, v7 in v5:GetDescendants() do
					if not string.find(v7.Name, "_MISSING", 1, true) then
						continue
					end
					v6 = true
				end
				if not v6 then
					for _, v8 in v5:GetDescendants() do
						if not v8:IsA("BasePart") then
							continue
						end
						v8.Anchored = true
						v8.CanCollide = false
						v8.CanQuery = false
						v8.CanTouch = false
					end
					return v5
				end
				v5:Destroy()
			end
		end
		local v9 = Instance.new("Model")
		v9.Name = "Heli"
		local v10 = Color3.fromRGB(58, 62, 50)
		local v11 = Color3.fromRGB(28, 29, 30)
		local v12 = CFrame.new(0, 4.6, 0)
		local v13 = Enum.Material.Metal
		local v14 = Instance.new("Part")
		v14.Name = "Body"
		v14.Anchored = true
		v14.CanCollide = false
		v14.CanQuery = false
		v14.CanTouch = false
		v14.Size = Vector3.new(6.5, 6, 13)
		v14.CFrame = v12
		v14.Color = v10
		v14.Material = v13 or Enum.Material.Metal
		v14.TopSurface = Enum.SurfaceType.Smooth
		v14.BottomSurface = Enum.SurfaceType.Smooth
		v14.Parent = v9
		local v15 = CFrame.new(0, 4.4, -7.6)
		local v16 = Enum.Material.Metal
		local v17 = Instance.new("Part")
		v17.Name = "Nose"
		v17.Anchored = true
		v17.CanCollide = false
		v17.CanQuery = false
		v17.CanTouch = false
		v17.Size = Vector3.new(6.2, 4.4, 3.5)
		v17.CFrame = v15
		v17.Color = v10
		v17.Material = v16 or Enum.Material.Metal
		v17.TopSurface = Enum.SurfaceType.Smooth
		v17.BottomSurface = Enum.SurfaceType.Smooth
		v17.Parent = v9
		local v18 = CFrame.new(0, 5.6, -8.4) * CFrame.Angles(-0.3490658503988659, 0, 0)
		local v19 = Color3.fromRGB(34, 44, 52)
		local v20 = Enum.Material.Glass
		local v21 = Instance.new("Part")
		v21.Name = "Canopy"
		v21.Anchored = true
		v21.CanCollide = false
		v21.CanQuery = false
		v21.CanTouch = false
		v21.Size = Vector3.new(5.6, 2.6, 2.2)
		v21.CFrame = v18
		v21.Color = v19
		v21.Material = v20 or Enum.Material.Metal
		v21.TopSurface = Enum.SurfaceType.Smooth
		v21.BottomSurface = Enum.SurfaceType.Smooth
		v21.Parent = v9
		v21.Transparency = 0.25
		local v22 = CFrame.new(0, 6.2, 13.5)
		local v23 = Enum.Material.Metal
		local v24 = Instance.new("Part")
		v24.Name = "Tail"
		v24.Anchored = true
		v24.CanCollide = false
		v24.CanQuery = false
		v24.CanTouch = false
		v24.Size = Vector3.new(1.6, 1.8, 15)
		v24.CFrame = v22
		v24.Color = v10
		v24.Material = v23 or Enum.Material.Metal
		v24.TopSurface = Enum.SurfaceType.Smooth
		v24.BottomSurface = Enum.SurfaceType.Smooth
		v24.Parent = v9
		local v25 = CFrame.new(0, 8, 20.6)
		local v26 = Enum.Material.Metal
		local v27 = Instance.new("Part")
		v27.Name = "Fin"
		v27.Anchored = true
		v27.CanCollide = false
		v27.CanQuery = false
		v27.CanTouch = false
		v27.Size = Vector3.new(0.4, 4.2, 2.4)
		v27.CFrame = v25
		v27.Color = v10
		v27.Material = v26 or Enum.Material.Metal
		v27.TopSurface = Enum.SurfaceType.Smooth
		v27.BottomSurface = Enum.SurfaceType.Smooth
		v27.Parent = v9
		local v28 = CFrame.new(0, 8.1, -0.5)
		local v29 = Enum.Material.Metal
		local v30 = Instance.new("Part")
		v30.Name = "Engine"
		v30.Anchored = true
		v30.CanCollide = false
		v30.CanQuery = false
		v30.CanTouch = false
		v30.Size = Vector3.new(4, 1.4, 3)
		v30.CFrame = v28
		v30.Color = v11
		v30.Material = v29 or Enum.Material.Metal
		v30.TopSurface = Enum.SurfaceType.Smooth
		v30.BottomSurface = Enum.SurfaceType.Smooth
		v30.Parent = v9
		for _, v31 in { -2.9, 2.9 } do
			local v32 = CFrame.new(v31, 0.3, -0.5)
			local v33 = Enum.Material.Metal
			local v34 = Instance.new("Part")
			v34.Name = "Skid"
			v34.Anchored = true
			v34.CanCollide = false
			v34.CanQuery = false
			v34.CanTouch = false
			v34.Size = Vector3.new(0.35, 0.35, 12)
			v34.CFrame = v32
			v34.Color = v11
			v34.Material = v33 or Enum.Material.Metal
			v34.TopSurface = Enum.SurfaceType.Smooth
			v34.BottomSurface = Enum.SurfaceType.Smooth
			v34.Parent = v9
			local v35 = CFrame.new(v31, 1.2, -3.5)
			local v36 = Enum.Material.Metal
			local v37 = Instance.new("Part")
			v37.Name = "Strut"
			v37.Anchored = true
			v37.CanCollide = false
			v37.CanQuery = false
			v37.CanTouch = false
			v37.Size = Vector3.new(0.3, 1.8, 0.3)
			v37.CFrame = v35
			v37.Color = v11
			v37.Material = v36 or Enum.Material.Metal
			v37.TopSurface = Enum.SurfaceType.Smooth
			v37.BottomSurface = Enum.SurfaceType.Smooth
			v37.Parent = v9
			local v38 = CFrame.new(v31, 1.2, 2.5)
			local v39 = Enum.Material.Metal
			local v40 = Instance.new("Part")
			v40.Name = "Strut"
			v40.Anchored = true
			v40.CanCollide = false
			v40.CanQuery = false
			v40.CanTouch = false
			v40.Size = Vector3.new(0.3, 1.8, 0.3)
			v40.CFrame = v38
			v40.Color = v11
			v40.Material = v39 or Enum.Material.Metal
			v40.TopSurface = Enum.SurfaceType.Smooth
			v40.BottomSurface = Enum.SurfaceType.Smooth
			v40.Parent = v9
		end
		local v41 = Instance.new("Model")
		v41.Name = "Rotor"
		local v42 = CFrame.new(0, 9.3, -0.5)
		local v43 = Enum.Material.Metal
		local v44 = Instance.new("Part")
		v44.Name = "Hub"
		v44.Anchored = true
		v44.CanCollide = false
		v44.CanQuery = false
		v44.CanTouch = false
		v44.Size = Vector3.new(0.8, 0.6, 0.8)
		v44.CFrame = v42
		v44.Color = v11
		v44.Material = v43 or Enum.Material.Metal
		v44.TopSurface = Enum.SurfaceType.Smooth
		v44.BottomSurface = Enum.SurfaceType.Smooth
		v44.Parent = v41
		for v45 = 0, 3 do
			local v46 = v45 * 3.141592653589793 / 2
			local v47 = CFrame.new(0, 9.4, -0.5) * CFrame.Angles(0, v46, 0) * CFrame.new(0, 0, 7.6)
			local v48 = Enum.Material.Metal
			local v49 = Instance.new("Part")
			v49.Name = "Blade"
			v49.Anchored = true
			v49.CanCollide = false
			v49.CanQuery = false
			v49.CanTouch = false
			v49.Size = Vector3.new(0.9, 0.12, 15)
			v49.CFrame = v47
			v49.Color = v11
			v49.Material = v48 or Enum.Material.Metal
			v49.TopSurface = Enum.SurfaceType.Smooth
			v49.BottomSurface = Enum.SurfaceType.Smooth
			v49.Parent = v41
		end
		v41.PrimaryPart = v44
		v41.Parent = v9
		local v50 = Instance.new("Model")
		v50.Name = "TailRotor"
		local v51 = CFrame.new(0.5, 8.4, 20.8)
		local v52 = Enum.Material.Metal
		local v53 = Instance.new("Part")
		v53.Name = "Hub"
		v53.Anchored = true
		v53.CanCollide = false
		v53.CanQuery = false
		v53.CanTouch = false
		v53.Size = Vector3.new(0.3, 0.3, 0.3)
		v53.CFrame = v51
		v53.Color = v11
		v53.Material = v52 or Enum.Material.Metal
		v53.TopSurface = Enum.SurfaceType.Smooth
		v53.BottomSurface = Enum.SurfaceType.Smooth
		v53.Parent = v50
		for v54 = 0, 1 do
			local v55 = CFrame.new(0.5, 8.4, 20.8) * CFrame.Angles(v54 * 3.141592653589793 / 2, 0, 0)
			local v56 = Enum.Material.Metal
			local v57 = Instance.new("Part")
			v57.Name = "Blade"
			v57.Anchored = true
			v57.CanCollide = false
			v57.CanQuery = false
			v57.CanTouch = false
			v57.Size = Vector3.new(0.1, 3.6, 0.35)
			v57.CFrame = v55
			v57.Color = v11
			v57.Material = v56 or Enum.Material.Metal
			v57.TopSurface = Enum.SurfaceType.Smooth
			v57.BottomSurface = Enum.SurfaceType.Smooth
			v57.Parent = v50
		end
		v50.PrimaryPart = v53
		v50.Parent = v9
		local v58 = CFrame.new(0, 10.3, 20.8)
		local v59 = Color3.fromRGB(255, 60, 50)
		local v60 = Enum.Material.Neon
		local v61 = Instance.new("Part")
		v61.Name = "NavLight"
		v61.Anchored = true
		v61.CanCollide = false
		v61.CanQuery = false
		v61.CanTouch = false
		v61.Size = Vector3.new(0.3, 0.3, 0.3)
		v61.CFrame = v58
		v61.Color = v59
		v61.Material = v60 or Enum.Material.Metal
		v61.TopSurface = Enum.SurfaceType.Smooth
		v61.BottomSurface = Enum.SurfaceType.Smooth
		v61.Parent = v9
		local v62 = Instance.new("PointLight")
		v62.Color = Color3.fromRGB(255, 60, 50)
		v62.Range = 10
		v62.Brightness = 2
		v62.Parent = v61
		v9.PrimaryPart = v14
		local v63 = CFrame.new(0, 0, 0)
		local v64 = v9.PrimaryPart
		if v64 then
			v64.PivotOffset = v64.CFrame:ToObjectSpace(v63)
		end
		v9.WorldPivot = v63
		return v9
	end
}
local function v_u_73(p66, p67, ...) -- name: audioCall
	local v68 = p66 and p66.controllers
	if v68 then
		v68 = p66.controllers.Audio
	end
	if v68 and not v68._broken then
		local v69 = v68[p67]
		if type(v69) == "function" then
			local v70 = v68[p67]
			local v71, v72 = pcall(v70, ...)
			if v71 then
				return v72
			end
		end
	end
	return nil
end
function v_u_65.create(p74, p75, p76) -- name: create
	-- upvalues: (copy) v_u_65, (copy) v_u_73
	local v77 = v_u_65.model(p74)
	local v78 = v77:GetPivot()
	local v79 = {}
	local v80 = p76 or {}
	for _, v81 in v77:GetDescendants() do
		if not (v81:IsA("BasePart") or v81:IsA("Model")) then
			continue
		end
		local v82 = v81.Name
		local v83 = string.sub(v82, 1, 9) == "TailRotor"
		if not v83 and (string.sub(v82, 1, 5) ~= "Rotor" and string.sub(v82, 1, 9) ~= "MainRotor") then
			continue
		end
		local v84 = v81.Parent
		if v84 and (v84 ~= v77 and v84:IsA("Model")) then
			local v85 = v84.Name
			if string.sub(v85, 1, 5) == "Rotor" or (string.sub(v85, 1, 9) == "MainRotor" or string.sub(v85, 1, 9) == "TailRotor") then
				continue
			end
		end
		local v86
		if v81:IsA("Model") then
			v86 = v81:GetPivot()
		else
			v86 = v81.CFrame
		end
		local v87 = {
			["inst"] = v81,
			["offset"] = v78:ToObjectSpace(v86),
			["speed"] = v83 and 38 or 24,
			["axis"] = v83 and "X" or "Y"
		}
		table.insert(v79, v87)
	end
	local v88 = {
		["model"] = nil,
		["rotors"] = nil,
		["light"] = nil,
		["lightPart"] = nil,
		["sound"] = nil,
		["spin"] = 0,
		["model"] = v77,
		["rotors"] = v79
	}
	if v80.light then
		local v89 = v78 * CFrame.new(0, 1.5, -6)
		local v90 = Instance.new("Part")
		v90.Name = "Searchlight"
		v90.Anchored = true
		v90.CanCollide = false
		v90.CanQuery = false
		v90.CanTouch = false
		v90.CastShadow = false
		v90.Transparency = 1
		v90.Size = Vector3.new(0.2, 0.2, 0.2)
		v90.CFrame = v89
		v90.Parent = v77
		local v91 = Instance.new("SpotLight")
		v91.Face = Enum.NormalId.Front
		v91.Angle = 38
		v91.Range = 110
		v91.Brightness = 4
		v91.Color = Color3.fromRGB(255, 244, 222)
		v91.Shadows = true
		v91.Parent = v90
		v88.light = v91
		v88.lightPart = v90
	end
	v77.Parent = p75
	if v80.sound ~= false then
		v88.sound = v_u_73(p74, "loop", v80.soundName or "ev_heli_rotor", v77.PrimaryPart or v77:FindFirstChildWhichIsA("BasePart"))
	end
	return v88
end
function v_u_65.pose(p92, p93, p94, p95) -- name: pose
	p92.model:PivotTo(p93)
	p92.spin = p92.spin + p94
	for _, v96 in p92.rotors do
		local v97 = p92.spin * v96.speed
		local v98
		if v96.axis == "X" then
			v98 = CFrame.Angles(v97, 0, 0)
		else
			v98 = CFrame.Angles(0, v97, 0)
		end
		local v99 = p93 * v96.offset * v98
		if v96.inst:IsA("Model") then
			v96.inst:PivotTo(v99)
		else
			v96.inst.CFrame = v99
		end
	end
	if p92.lightPart then
		local v100 = p95 * 0.6
		local v101 = math.sin(v100) * 0.5
		p92.lightPart.CFrame = p93 * CFrame.new(0, 1.2, -6) * CFrame.Angles(-1.0821041362364843, v101, 0)
	end
end
function v_u_65.size(p_u_102) -- name: size
	local v103, _, v104 = pcall(function()
		-- upvalues: (copy) p_u_102
		return p_u_102.model:GetBoundingBox()
	end)
	return (not v103 or typeof(v104) ~= "Vector3") and Vector3.new(6.5, 10, 24) or v104
end
function v_u_65.rotorAxes(p105) -- name: rotorAxes
	return #p105.rotors
end
function v_u_65.destroy(p_u_106) -- name: destroy
	if p_u_106 then
		local v_u_107 = p_u_106.sound
		if v_u_107 ~= nil then
			pcall(function()
				-- upvalues: (copy) v_u_107
				local v108 = v_u_107
				if typeof(v108) == "Instance" then
					v_u_107:Destroy()
				else
					local v109 = v_u_107
					if type(v109) == "table" then
						local v110 = v_u_107.stop or v_u_107.Stop or (v_u_107.destroy or v_u_107.Destroy)
						if type(v110) == "function" then
							v110(v_u_107)
							return
						end
					else
						local v111 = v_u_107
						if type(v111) == "function" then
							v_u_107()
						end
					end
				end
			end)
		end
		p_u_106.sound = nil
		pcall(function()
			-- upvalues: (copy) p_u_106
			p_u_106.model:Destroy()
		end)
	end
end
return v_u_65