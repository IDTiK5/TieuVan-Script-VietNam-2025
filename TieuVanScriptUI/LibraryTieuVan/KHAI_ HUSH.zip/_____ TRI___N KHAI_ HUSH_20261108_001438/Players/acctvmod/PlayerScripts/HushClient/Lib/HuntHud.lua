-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntHud

local v_u_662 = {
	["ROLE_SEC"] = 6,
	["LEAVE_ARM"] = 3,
	["HUNT_SEC"] = 180,
	["SPEC_ACTIONS"] = {
		["prev"] = "reload",
		["next"] = "swap"
	},
	["clock"] = function(p1) -- name: clock
		local v2 = math.ceil(p1)
		local v3 = math.max(0, v2)
		return ("%d:%02d"):format(v3 // 60, v3 % 60)
	end,
	["layout"] = function(p4, p5, p6, p7) -- name: layout
		-- upvalues: (copy) v_u_662
		local v8 = {}
		local v9 = p4.X
		local v10 = p4.Y
		local v11 = p5 and 224 or 320
		local v12 = p5 and 52 or 56
		local v13 = (v9 - v11) / 2
		v8.top = {
			["x0"] = v13,
			["y0"] = p6,
			["x1"] = v13 + v11,
			["y1"] = p6 + v12
		}
		local v14 = v8.top.x1 + 8
		local v15 = math.max(p7, v12)
		v8.leave = {
			["x0"] = v14,
			["y0"] = p6,
			["x1"] = v14 + (p5 and 88 or 112),
			["y1"] = p6 + v15
		}
		local v16 = p5 and 92 or 120
		local v17 = v8.top.x0 - 8 - v16
		local v18 = math.max(p7, v12)
		v8.pk = {
			["x0"] = v17,
			["y0"] = p6,
			["x1"] = v17 + v16,
			["y1"] = p6 + v18
		}
		local v19 = p5 and 84 or 132
		local v20 = v8.leave.x1 + 8
		local v21 = math.max(p7, v12)
		v8.howto = {
			["x0"] = v20,
			["y0"] = p6,
			["x1"] = v20 + v19,
			["y1"] = p6 + v21
		}
		local v22 = v8.leave.x0
		local v23 = math.max(p7, v12)
		v8.howtoWait = {
			["x0"] = v22,
			["y0"] = p6,
			["x1"] = v22 + v19,
			["y1"] = p6 + v23
		}
		local v24 = v8.leave.y1 - p6
		local v25 = math.max(v12, v24)
		local v26 = v9 - 32
		local v27 = math.min(v26, p5 and 260 or 300)
		local v28 = (v9 - v27) / 2
		local v29 = p6 + v25 + 4
		v8.shot = {
			["x0"] = v28,
			["y0"] = v29,
			["x1"] = v28 + v27,
			["y1"] = v29 + (p5 and 20 or 22)
		}
		local v30 = v9 - 32
		local v31 = math.min(v30, p5 and 520 or 640)
		local v32 = (v9 - v31) / 2
		local v33 = v8.shot.y1 + 4
		v8.banner = {
			["x0"] = v32,
			["y0"] = v33,
			["x1"] = v32 + v31,
			["y1"] = v33 + (p5 and 30 or 36)
		}
		local v34 = v9 - 32
		local v35 = math.min(v34, p5 and 440 or 560)
		local v36 = (v9 - v35) / 2
		local v37 = v8.banner.y1 + 16
		v8.role = {
			["x0"] = v36,
			["y0"] = v37,
			["x1"] = v36 + v35,
			["y1"] = v37 + (p5 and 92 or 104)
		}
		local v38 = v9 - 32
		local v39 = math.min(v38, p5 and 640 or 760)
		local v40 = p7 + 28
		local v41 = math.max(p5 and 98 or 96, v40)
		local v42 = (v9 - v39) / 2
		local v43 = v10 - (p5 and 16 or 56) - v41
		v8.spec = {
			["x0"] = v42,
			["y0"] = v43,
			["x1"] = v42 + v39,
			["y1"] = v43 + v41
		}
		local v44 = p5 and 96 or 130
		local v45 = p5 and 104 or 112
		local v46 = v8.spec.y0 + (v41 - p7) / 2
		local v47 = v8.spec.x1 - 10 - v45
		v8.specLeave = {
			["x0"] = v47,
			["y0"] = v46,
			["x1"] = v47 + v45,
			["y1"] = v46 + p7
		}
		local v48 = v8.specLeave.x0 - 6 - v44
		v8.specNext = {
			["x0"] = v48,
			["y0"] = v46,
			["x1"] = v48 + v44,
			["y1"] = v46 + p7
		}
		local v49 = v8.specNext.x0 - 6 - v44
		v8.specPrev = {
			["x0"] = v49,
			["y0"] = v46,
			["x1"] = v49 + v44,
			["y1"] = v46 + p7
		}
		local v50 = v8.spec.x0 + 10
		local v51 = v8.spec.y0 + 10
		local v52 = v8.specPrev.x0 - 8 - (v8.spec.x0 + 10)
		local v53 = v41 - 20
		v8.specText = {
			["x0"] = v50,
			["y0"] = v51,
			["x1"] = v50 + v52,
			["y1"] = v51 + v53
		}
		local v54 = v9 - 32
		local v55 = math.min(v54, 520)
		local v56 = p5 and 112 or 170
		local v57 = math.max(p7, 40)
		local v58 = v10 - (p5 and 12 or 56) - v57
		local v59 = (v9 - (v56 * 2 + 8)) / 2
		v8.traps = {
			["x0"] = v59,
			["y0"] = v58,
			["x1"] = v59 + (v56 * 2 + 8),
			["y1"] = v58 + v57
		}
		local v60 = v8.traps.x0
		v8.trapBear = {
			["x0"] = v60,
			["y0"] = v58,
			["x1"] = v60 + v56,
			["y1"] = v58 + v57
		}
		local v61 = v8.trapBear.x1 + 8
		v8.trapAlarm = {
			["x0"] = v61,
			["y0"] = v58,
			["x1"] = v61 + v56,
			["y1"] = v58 + v57
		}
		local v62 = v_u_662.lootRects(p4, p5, p7, 4)
		local v63 = v62[1].x0
		v8.loot = {
			["x0"] = v63,
			["y0"] = v58,
			["x1"] = v63 + (v62[4].x1 - v62[1].x0),
			["y1"] = v58 + v57
		}
		local v64 = v62[1]
		local v65 = v62[2]
		local v66 = v62[3]
		local v67 = v62[4]
		v8.lootMelee = v64
		v8.lootFrag = v65
		v8.lootFlash = v66
		v8.lootCola = v67
		for v68, v69 in v_u_662.endRects(p4, p5, p7, {
			["tiles"] = 3,
			["brk"] = true,
			["prog"] = true,
			["earned"] = 3
		}) do
			v8[v68] = v69
		end
		local v70 = (v9 - v55) / 2
		local v71 = (v10 - 120) / 2
		local v72 = v8.banner.y1 + 10
		local v73 = math.max(v71, v72)
		v8.home = {
			["x0"] = v70,
			["y0"] = v73,
			["x1"] = v70 + v55,
			["y1"] = v73 + 120
		}
		return v8
	end,
	["lootRects"] = function(p74, p75, p76, p77) -- name: lootRects
		local v78 = p74.X
		local v79 = p74.Y
		local v80 = math.floor(p77)
		local v81 = math.clamp(v80, 1, 4)
		local v82 = p75 and 70 or 118
		local v83 = p75 and 6 or 8
		local v84 = math.max(p76, 40)
		local v85 = v79 - (p75 and 12 or 56) - v84
		local v86 = (v78 - (v81 * v82 + (v81 - 1) * v83)) / 2
		local v87 = {}
		for v88 = 1, v81 do
			local v89 = v86 + (v88 - 1) * (v82 + v83)
			local v90 = {
				["x0"] = v89,
				["y0"] = v85,
				["x1"] = v89 + v82,
				["y1"] = v85 + v84
			}
			table.insert(v87, v90)
		end
		return v87
	end,
	["lootSlots"] = function(p91, p92) -- name: lootSlots
		local v93 = {}
		if type(p92) ~= "table" then
			return v93
		end
		local v94 = p91.LOOT
		local v95 = p92.melee
		local v96 = type(v95) ~= "string" and "" or p92.melee
		if v96 ~= "" then
			local v97 = {
				["which"] = "melee",
				["text"] = nil,
				["selected"] = nil,
				["text"] = v94.short[v96] or string.upper(v96),
				["selected"] = p92.held == "melee"
			}
			table.insert(v93, v97)
		end
		local v98 = p92.frag
		local v99 = tonumber(v98) or 0
		local v100 = math.floor(v99)
		local v101 = math.max(0, v100)
		if v101 > 0 then
			local v102 = {
				["which"] = "frag",
				["text"] = nil,
				["selected"] = nil,
				["text"] = p91.format(v94.button, v94.frag, v101),
				["selected"] = p92.sel == "throw_frag"
			}
			table.insert(v93, v102)
		end
		local v103 = p92.flash
		local v104 = tonumber(v103) or 0
		local v105 = math.floor(v104)
		local v106 = math.max(0, v105)
		if v106 > 0 then
			local v107 = {
				["which"] = "flash",
				["text"] = nil,
				["selected"] = nil,
				["text"] = p91.format(v94.button, v94.flash, v106),
				["selected"] = p92.sel == "throw_flash"
			}
			table.insert(v93, v107)
		end
		local v108 = p92.cola
		local v109 = tonumber(v108) or 0
		local v110 = math.floor(v109)
		local v111 = math.max(0, v110)
		if v111 > 0 then
			local v112 = {
				["which"] = "cola",
				["text"] = nil,
				["selected"] = false,
				["text"] = p91.format(v94.button, v94.cola, v111)
			}
			table.insert(v93, v112)
		end
		return v93
	end,
	["endRects"] = function(p113, p114, p115, p116) -- name: endRects
		local v117 = p113.X
		local v118 = p113.Y
		local v119 = v117 - 32
		local v120 = math.min(v119, p114 and 600 or 700)
		local v121 = p114 and 12 or 16
		local v122 = p114 and 6 or 10
		local v123 = v120 - v121 * 2
		local v124 = p114 and 52 or 64
		local v125 = p114 and 22 or 24
		local v126 = p114 and 70 or 76
		local v127 = p114 and 18 or 22
		local v128 = p114 and 52 or 56
		local v129 = p114 and 20 or 22
		local v130 = {
			["endBar"] = {
				["x0"] = v121,
				["y0"] = v121,
				["x1"] = v121 + v123,
				["y1"] = v121 + v124
			}
		}
		local v131 = v121 + (v124 + 4)
		v130.endRole = {
			["x0"] = v121,
			["y0"] = v131,
			["x1"] = v121 + v123,
			["y1"] = v131 + v125
		}
		local v132 = v131 + (v125 + v122)
		local v133 = p116.tiles
		local v134 = tonumber(v133) or 0
		local v135 = math.floor(v134)
		local v136 = math.clamp(v135, 0, 3)
		if v136 > 0 then
			local v137 = p114 and 6 or 10
			local v138 = (v123 - (v136 - 1) * v137) / v136
			local v139 = math.floor(v138)
			for v140 = 1, v136 do
				local v141 = "endTile" .. v140
				local v142 = v121 + (v140 - 1) * (v139 + v137)
				v130[v141] = {
					["x0"] = v142,
					["y0"] = v132,
					["x1"] = v142 + v139,
					["y1"] = v132 + v126
				}
			end
			local v143 = v132 + (v126 + 4)
			if p116.brk == true then
				v130.endBreak = {
					["x0"] = v121,
					["y0"] = v143,
					["x1"] = v121 + v123,
					["y1"] = v143 + v127
				}
				v132 = v143 + (v127 + v122)
			else
				v132 = v143 + (v122 - 4)
			end
		end
		if p116.prog == true then
			local v144 = p114 and 8 or 10
			v130.endProgBar = {
				["x0"] = v121,
				["y0"] = v132,
				["x1"] = v121 + v123,
				["y1"] = v132 + v144
			}
			local v145 = (v128 - v144 - 4) / 2
			local v146 = math.floor(v145)
			local v147 = v123 / 2
			local v148 = math.floor(v147)
			local v149 = v132 + v144 + 4
			v130.endProgText = {
				["x0"] = v121,
				["y0"] = v149,
				["x1"] = v121 + v148,
				["y1"] = v149 + v146
			}
			local v150 = v121 + v148
			local v151 = v132 + v144 + 4
			v130.endProgLeft = {
				["x0"] = v150,
				["y0"] = v151,
				["x1"] = v150 + (v123 - v148),
				["y1"] = v151 + v146
			}
			local v152 = v132 + v144 + 4 + v146
			v130.endProgCrate = {
				["x0"] = v121,
				["y0"] = v152,
				["x1"] = v121 + v148,
				["y1"] = v152 + v146
			}
			local v153 = v121 + v148
			local v154 = v132 + v144 + 4 + v146
			v130.endProgSteps = {
				["x0"] = v153,
				["y0"] = v154,
				["x1"] = v153 + (v123 - v148),
				["y1"] = v154 + v146
			}
			v132 = v132 + (v128 + v122)
		end
		local v155 = p116.earned
		local v156 = tonumber(v155) or 0
		local v157 = math.floor(v156)
		local v158 = math.clamp(v157, 0, 4)
		if v158 > 0 then
			local v159 = v158 * v129
			v130.endEarned = {
				["x0"] = v121,
				["y0"] = v132,
				["x1"] = v121 + v123,
				["y1"] = v132 + v159
			}
			v132 = v132 + (v158 * v129 + v122)
		end
		local v160 = math.max(p115, 40)
		v130.endBack = {
			["x0"] = v121,
			["y0"] = v132,
			["x1"] = v121 + v123,
			["y1"] = v132 + v160
		}
		local v161 = v132 + (v160 + v121)
		local v162 = (v117 - v120) / 2
		local v163 = (v118 - v161) / 2
		local v164 = math.max(v163, 8)
		v130.endcard = {
			["x0"] = v162,
			["y0"] = v164,
			["x1"] = v162 + v120,
			["y1"] = v164 + v161
		}
		return v130
	end,
	["endModel"] = function(p165, p166, p167, p168) -- name: endModel
		-- upvalues: (copy) v_u_662
		local v169 = p165.END
		local v170 = p168.role
		local v171 = {
			["tone"] = "neutral",
			["title"] = nil,
			["role"] = "",
			["tiles"] = nil,
			["brk"] = "",
			["prog"] = nil,
			["earned"] = nil
		}
		local v172 = p168.t or ""
		v171.title = tostring(v172)
		v171.tiles = {}
		v171.earned = {}
		local v173
		if p168.eligible == false then
			v173 = false
		else
			v173 = v170 == "stalker" and true or v170 == "survivor"
		end
		if v173 then
			v171.tone = p168.won == true and "win" or "lose"
			local v174
			if p168.won == true then
				v174 = v169.won
			else
				v174 = v169.lost
			end
			local v175 = " "
			local v176
			if v170 == "stalker" then
				v176 = v169.asStalker
			else
				v176 = v169.asSurvivor
			end
			v171.role = v174 .. v175 .. v176
		elseif v170 == "stalker" then
			v171.role = v169.wasStalker
		elseif v170 == "survivor" then
			v171.role = v169.wasSurvivor
		end
		local v177
		if type(p166) == "table" then
			local v178 = p166.PK_PER_CATCH
			v177 = type(v178) ~= "number" and 3 or p166.PK_PER_CATCH
		else
			v177 = 3
		end
		local v179
		if type(p166) == "table" then
			local v180 = p166.PK_PER_WIN
			v179 = type(v180) ~= "number" and 5 or p166.PK_PER_WIN
		else
			v179 = 5
		end
		local v181 = p168.pk
		if type(v181) == "table" then
			local v182 = v171.tiles
			local v183 = {
				["label"] = v169.pumpkins
			}
			local v184 = p165.format
			local v185 = p165.PUMPKIN.plus
			local v186 = v181.round
			local v187
			if type(v186) == "number" and v186 == v186 then
				local v188 = math.floor(v186)
				v187 = math.max(0, v188)
			else
				v187 = 0
			end
			v183.value = v184(v185, v187)
			v183.sub = v169.thisRound
			table.insert(v182, v183)
			if v170 == "stalker" then
				local v189 = v171.tiles
				local v190 = {
					["label"] = v169.catches
				}
				local v191 = v181.catches
				local v192
				if type(v191) == "number" and v191 == v191 then
					local v193 = math.floor(v191)
					v192 = math.max(0, v193)
				else
					v192 = 0
				end
				v190.value = tostring(v192)
				v190.sub = v169.caught
				table.insert(v189, v190)
			elseif v170 == "survivor" then
				local v194 = p168.survived
				if type(v194) == "number" then
					local v195 = v171.tiles
					local v196 = {
						["label"] = nil,
						["value"] = nil,
						["sub"] = ""
					}
					local v197
					if p168.outAfter == true then
						v197 = v169.outAt
					else
						v197 = v169.survived
					end
					v196.label = v197
					v196.value = v_u_662.clock(p168.survived)
					table.insert(v195, v196)
				end
			end
			local v198 = v171.tiles
			local v199 = {
				["label"] = v169.total
			}
			local v200 = v181.total
			local v201
			if type(v200) == "number" and v200 == v200 then
				local v202 = math.floor(v200)
				v201 = math.max(0, v202)
			else
				v201 = 0
			end
			v199.value = tostring(v201)
			v199.sub = v169.account
			table.insert(v198, v199)
			local v203 = {}
			local v204 = v181.picked
			local v205
			if type(v204) == "number" and v204 == v204 then
				local v206 = math.floor(v204)
				v205 = math.max(0, v206)
			else
				v205 = 0
			end
			if v205 > 0 then
				local v207 = p165.format
				local v208 = p165.PUMPKIN.picked
				local v209 = v181.picked
				local v210
				if type(v209) == "number" and v209 == v209 then
					local v211 = math.floor(v209)
					v210 = math.max(0, v211)
				else
					v210 = 0
				end
				table.insert(v203, v207(v208, v210))
			end
			local v212 = v181.catches
			local v213
			if type(v212) == "number" and v212 == v212 then
				local v214 = math.floor(v212)
				v213 = math.max(0, v214)
			else
				v213 = 0
			end
			if v213 > 0 then
				local v215 = p165.format
				local v216 = p165.PUMPKIN.catchBonus
				local v217 = v181.catches
				local v218
				if type(v217) == "number" and v217 == v217 then
					local v219 = math.floor(v217)
					v218 = math.max(0, v219)
				else
					v218 = 0
				end
				local v220 = v218 * v177
				table.insert(v203, v215(v216, v220))
			end
			local v221 = v181.bonus
			local v222
			if type(v221) == "number" and v221 == v221 then
				local v223 = math.floor(v221)
				v222 = math.max(0, v223)
			else
				v222 = 0
			end
			local v224 = v181.win ~= true and 0 or v179
			local v225 = math.min(v224, v222)
			if v225 > 0 then
				local v226 = p165.format
				local v227 = p165.PUMPKIN.winBonus
				table.insert(v203, v226(v227, v225))
			end
			if v222 - v225 > 0 then
				local v228 = p165.format
				local v229 = p165.PUMPKIN.roundBonus
				local v230 = v222 - v225
				table.insert(v203, v228(v229, v230))
			end
			v171.brk = table.concat(v203, "   ")
		end
		local v231 = p168.prog
		if type(v231) == "table" then
			local v232 = v231.pumpkins
			local v233
			if type(v232) == "number" and v232 == v232 then
				local v234 = math.floor(v232)
				v233 = math.max(0, v234)
			else
				v233 = 0
			end
			local v235 = {}
			local v236 = v231.nextAt
			if type(v236) == "number" then
				local v237 = 0
				if type(p167) == "table" then
					local v238 = p167.LADDER
					if type(v238) == "table" then
						for _, v239 in p167.LADDER do
							local v240 = v239.at
							if type(v240) ~= "number" or (v239.at > v233 or v237 >= v239.at) then
								continue
							end
							v237 = v239.at
						end
					end
				end
				local v241 = v231.nextAt - v237
				local v242 = math.max(1, v241)
				local v243 = (v233 - v237) / v242
				v235.frac = math.clamp(v243, 0, 1)
				v235.text = p165.format(p165.PUMPKIN.next, v231.nextAt)
				local v244 = p165.format
				local v245 = p165.PUMPKIN.nextLeft
				local v246 = v231.toNext
				local v247
				if type(v246) == "number" and v246 == v246 then
					local v248 = math.floor(v246)
					v247 = math.max(0, v248)
				else
					v247 = 0
				end
				v235.left = v244(v245, v247)
			else
				v235.frac = 1
				v235.text = p165.PUMPKIN.allDone
				v235.left = ""
			end
			local v249 = p165.format
			local v250 = p165.PUMPKIN.crateIn
			local v251 = 1
			local v252 = v231.crateIn
			local v253
			if type(v252) == "number" and v252 == v252 then
				local v254 = math.floor(v252)
				v253 = math.max(0, v254)
			else
				v253 = 0
			end
			v235.crate = v249(v250, (math.max(v251, v253)))
			local v255 = v231.steps
			local v256
			if type(v255) == "number" then
				local v257 = v231.stepsTotal
				if type(v257) == "number" then
					local v258 = p165.format
					local v259 = v169.rewardsDone
					local v260 = v231.steps
					local v261
					if type(v260) == "number" and v260 == v260 then
						local v262 = math.floor(v260)
						v261 = math.max(0, v262)
					else
						v261 = 0
					end
					local v263 = v231.stepsTotal
					local v264
					if type(v263) == "number" and v263 == v263 then
						local v265 = math.floor(v263)
						v264 = math.max(0, v265)
					else
						v264 = 0
					end
					v256 = v258(v259, v261, v264)
				else
					v256 = ""
				end
			else
				v256 = ""
			end
			v235.steps = v256
			v171.prog = v235
		end
		local v266 = {}
		local v267 = {}
		local v268 = p168.titles
		if type(v268) == "table" then
			for _, v269 in p168.titles do
				if type(v269) ~= "string" or v269 == "" then
					continue
				end
				table.insert(v267, v269)
			end
			if #v267 == 1 then
				local v270 = p165.format
				local v271 = p165.HUD.newTitle
				local v272 = v267[1]
				table.insert(v266, v270(v271, v272))
			elseif #v267 >= 2 then
				local v273 = v267[1] .. ", " .. v267[2]
				if #v267 > 2 then
					v273 = p165.format(v169.titlesMore, v273, #v267 - 2)
				end
				local v274 = p165.format
				local v275 = v169.newTitles
				table.insert(v266, v274(v275, v273))
			end
		end
		local v276 = p168.rewards
		if type(v276) == "table" then
			for _, v277 in p168.rewards do
				if type(v277) ~= "string" or v277 == "" then
					continue
				end
				local v278 = false
				for _, v279 in v267 do
					if string.find(v277, v279, 1, true) == nil then
						continue
					end
					v278 = true
				end
				if v278 then
					break
				end
				local v280 = p165.format
				local v281 = p165.PUMPKIN.earned
				table.insert(v266, v280(v281, v277))
			end
		end
		local v282 = nil
		local v283 = p168.crates
		local v284
		if type(v283) == "number" and v283 == v283 then
			local v285 = math.floor(v283)
			v284 = math.max(0, v285)
		else
			v284 = 0
		end
		if v284 > 0 then
			local v286 = p165.format
			local v287 = p165.PUMPKIN.crates
			local v288 = p168.crates
			local v289
			if type(v288) == "number" and v288 == v288 then
				local v290 = math.floor(v288)
				v289 = math.max(0, v290)
			else
				v289 = 0
			end
			v282 = v286(v287, v289)
		end
		if #v266 + (v282 == nil and 0 or 1) > 3 then
			local v291 = v282 == nil and 2 or 1
			local v292 = {}
			for v293 = 1, v291 do
				local v294 = v266[v293]
				table.insert(v292, v294)
			end
			if v282 ~= nil then
				table.insert(v292, v282)
			end
			local v295 = p165.format
			local v296 = v169.more
			local v297 = #v266 - v291
			table.insert(v292, v295(v296, v297))
			v266 = v292
		elseif v282 ~= nil then
			table.insert(v266, v282)
		end
		v171.earned = v266
		return v171
	end,
	["TOGETHER"] = {
		{
			"top",
			"leave",
			"pk",
			"howto",
			"shot",
			"banner",
			"role",
			"traps"
		},
		{
			"top",
			"howtoWait",
			"pk",
			"shot",
			"banner",
			"role"
		},
		{ "trapBear", "trapAlarm" },
		{
			"top",
			"leave",
			"pk",
			"howto",
			"shot",
			"banner",
			"role",
			"loot"
		},
		{
			"lootMelee",
			"lootFrag",
			"lootFlash",
			"lootCola"
		},
		{
			"top",
			"shot",
			"banner",
			"spec"
		},
		{
			"specText",
			"specPrev",
			"specNext",
			"specLeave"
		},
		{ "top", "banner", "home" },
		{
			"endBar",
			"endRole",
			"endTile1",
			"endBreak",
			"endProgBar",
			"endProgText",
			"endEarned",
			"endBack"
		},
		{
			"endBar",
			"endRole",
			"endTile1",
			"endTile2",
			"endTile3",
			"endBreak",
			"endProgBar",
			"endProgText",
			"endProgLeft",
			"endProgCrate",
			"endProgSteps",
			"endEarned",
			"endBack"
		}
	},
	["overlap"] = function(p298, p299) -- name: overlap
		local v300
		if p298.x0 < p299.x1 and (p299.x0 < p298.x1 and p298.y0 < p299.y1) then
			v300 = p299.y0 < p298.y1
		else
			v300 = false
		end
		return v300
	end,
	["splitRole"] = function(p301, p302) -- name: splitRole
		if type(p302) == "string" and p302 ~= "" then
			return p301, p302
		else
			local v303, v304 = string.match(p301, "^(.-):%s+(.+)$")
			if v303 == nil or (v304 == nil or v303 == "") then
				return p301, ""
			else
				return v303, string.upper((string.sub(v304, 1, 1))) .. string.sub(v304, 2)
			end
		end
	end,
	["counters"] = function(p305, p306, p307, p308) -- name: counters
		local v309 = math.floor(p306 or 0)
		local v310 = math.max(0, v309)
		local v311 = math.floor(p307 or v310)
		local v312 = math.max(v310, v311)
		local v313 = p305.format(p305.HUD.survivorsCount, v310, v312)
		if p308 ~= nil then
			local v314 = math.floor(p308)
			local v315 = math.max(0, v314)
			local v316 = "   "
			local v317 = p305.format
			local v318
			if v315 >= 2 then
				v318 = p305.HUD.stalkersCount
			else
				v318 = p305.HUD.stalkerCount
			end
			v313 = v313 .. v316 .. v317(v318, v315)
		end
		return v313
	end,
	["bannerOf"] = function(p319, p320, p321, p322) -- name: bannerOf
		if p322 then
			return p319.HUD.leaveAlive, "warn"
		end
		local v323 = p320.banner
		if type(v323) == "table" then
			local v324 = v323.t
			if type(v324) == "string" and p321 < (v323.untilT or 0) then
				return v323.t, v323.kind or "info"
			end
		end
		if p320.phase == "wait" then
			local v325 = p320.waitT
			if type(v325) == "string" then
				return p320.waitT, "info"
			end
		end
		if p320.phase ~= "hide" or (p320.role ~= "survivor" or p320.out ~= nil) then
			return nil, "info"
		end
		local v326
		if (p320.stalkers or 1) >= 2 and p319.HUD.hideSurvivorMany ~= nil then
			v326 = p319.HUD.hideSurvivorMany
		else
			v326 = p319.HUD.hideSurvivor
		end
		return v326, "info"
	end,
	["shotLeft"] = function(p327) -- name: shotLeft
		-- upvalues: (copy) v_u_662
		if p327.out ~= nil or (p327.result ~= nil or (p327.home ~= nil or p327.role == nil)) then
			return nil
		end
		local v328 = p327.endsAt
		if type(v328) == "number" and p327.endsAt > 0 then
			local v329 = p327.now
			if type(v329) == "number" then
				local v330 = p327.endsAt - p327.now
				local v331 = math.max(0, v330)
				if p327.phase == "hunt" then
					return v331
				end
				if p327.phase ~= "hide" then
					return nil
				end
				local v332 = p327.huntSec
				local v333
				if type(v332) == "number" and p327.huntSec > 0 then
					v333 = p327.huntSec
				else
					v333 = v_u_662.HUNT_SEC
				end
				return v331 + v333
			end
		end
		return nil
	end,
	["shotText"] = function(p334, p335) -- name: shotText
		-- upvalues: (copy) v_u_662
		local v336 = v_u_662.shotLeft(p335)
		if v336 == nil then
			return nil
		end
		local v337 = p334.format
		local v338
		if p335.role == "stalker" then
			v338 = p334.HUD.stalkerShotIn
		else
			v338 = p334.HUD.shotIn
		end
		return v337(v338, v_u_662.clock(v336))
	end,
	["new"] = function(p_u_339) -- name: new
		-- upvalues: (copy) v_u_662
		local v_u_340 = p_u_339.UI
		local v_u_341 = p_u_339.Theme
		local v_u_342 = p_u_339.Names
		local v_u_343 = v_u_341.color
		local v344 = {}
		local v_u_345 = true
		local v_u_346 = 0
		local v347 = Vector2.new(1920, 1080)
		local v348 = v_u_341.refSize()
		v347 = v348
		local v349 = v_u_341.touch(40)
		local v_u_350 = v_u_662.layout(v348, v_u_341.isPhone(), v_u_340.topInset(), v349)
		function v344.rects()
			-- upvalues: (ref) v_u_350
			return v_u_350
		end
		local v_u_351 = v_u_340.new("Frame", {
			["Name"] = "HuntHud",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_339.root)
		v344.holder = v_u_351
		local v_u_352 = v_u_341.touch(40)
		local v_u_353 = {
			["leave"] = function()
				-- upvalues: (ref) v_u_346, (copy) p_u_339, (ref) v_u_662
				if os.clock() < v_u_346 then
					v_u_346 = 0
					if p_u_339.onLeave then
						p_u_339.onLeave()
						return
					end
				else
					v_u_346 = os.clock() + v_u_662.LEAVE_ARM
				end
			end,
			["leaveOut"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onLeave then
					p_u_339.onLeave()
				end
			end,
			["next"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onNext then
					p_u_339.onNext()
				end
			end,
			["prev"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onPrev then
					p_u_339.onPrev()
				end
			end,
			["back"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onBack then
					p_u_339.onBack()
				end
			end,
			["howto"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onHowTo then
					p_u_339.onHowTo()
				end
			end,
			["trapBear"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onTrap then
					p_u_339.onTrap("bear")
				end
			end,
			["trapAlarm"] = function()
				-- upvalues: (copy) p_u_339
				if p_u_339.onTrap then
					p_u_339.onTrap("alarm")
				end
			end
		}
		local v_u_354 = v_u_346
		local v_u_355 = v_u_350
		local v_u_356 = v347
		for _, v_u_357 in {
			"melee",
			"frag",
			"flash",
			"cola"
		} do
			v_u_353["loot" .. string.upper((string.sub(v_u_357, 1, 1))) .. string.sub(v_u_357, 2)] = function()
				-- upvalues: (copy) p_u_339, (copy) v_u_357
				if p_u_339.onLoot then
					p_u_339.onLoot(v_u_357)
				end
			end
		end
		local v_u_358, v359 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "Top",
			["size"] = nil,
			["raised"] = true,
			["transparency"] = 0.2,
			["accent"] = nil,
			["padding"] = 6,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.accent
		})
		v_u_358.Visible = false
		local v_u_360 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Phase",
			["text"] = "",
			["style"] = "h3",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v359,
			["size"] = UDim2.new(0.55, 0, 0, v_u_341.isPhone() and 22 or 24),
			["position"] = UDim2.fromOffset(0, 0)
		})
		local v_u_361 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Time",
			["text"] = "",
			["style"] = "monoL",
			["align"] = "right",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v359,
			["size"] = UDim2.new(0.45, 0, 0, v_u_341.isPhone() and 22 or 24),
			["position"] = UDim2.new(0.55, 0, 0, 0)
		})
		local v_u_362 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Counters",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v359,
			["color"] = v_u_343.text2,
			["size"] = UDim2.new(1, 0, 0, 16),
			["position"] = UDim2.fromOffset(0, v_u_341.isPhone() and 22 or 28)
		})
		local v_u_363, v364 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "Pumpkins",
			["size"] = nil,
			["raised"] = true,
			["transparency"] = 0.2,
			["accent"] = nil,
			["padding"] = 6,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.accent
		})
		v_u_363.Visible = false
		local v_u_365 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Count",
			["text"] = "",
			["style"] = "bodyStrong",
			["fit"] = true,
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v364,
			["color"] = v_u_343.accent,
			["size"] = UDim2.new(1, 0, 0, v_u_341.isPhone() and 20 or 22),
			["position"] = UDim2.fromOffset(0, 0)
		})
		local v_u_366 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Total",
			["text"] = "",
			["style"] = "small",
			["fit"] = true,
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v364,
			["color"] = v_u_343.text2,
			["size"] = UDim2.new(1, 0, 0, 16),
			["position"] = UDim2.fromOffset(0, v_u_341.isPhone() and 22 or 26)
		})
		local v_u_367, v_u_368 = v_u_340.button({
			["parent"] = nil,
			["name"] = "LeaveAlive",
			["text"] = nil,
			["kind"] = "ghost",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_351,
			["text"] = v_u_342.MODE.leave,
			["size"] = UDim2.fromOffset(10, v_u_352),
			["onClick"] = v_u_353.leave
		})
		v_u_367.Visible = false
		local v369 = v_u_340.button
		local v370 = {
			["parent"] = nil,
			["name"] = "HowTo",
			["text"] = nil,
			["kind"] = "secondary",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_351
		}
		local v371
		if v_u_341.isPhone() then
			v371 = v_u_342.HOWTO.buttonShort
		else
			v371 = v_u_342.HOWTO.button
		end
		v370.text = v371
		v370.size = UDim2.fromOffset(10, v_u_352)
		v370.onClick = v_u_353.howto
		local v_u_372, _ = v369(v370)
		v_u_372.Visible = false
		local v_u_373 = v_u_340.new("Frame", {
			["Name"] = "Shot",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_343.bg
		}, v_u_351)
		v_u_340.stroke(v_u_373, v_u_343.line)
		local v_u_374 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "bodyStrong",
			["align"] = "center",
			["fit"] = true,
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_373,
			["color"] = v_u_343.accent,
			["size"] = UDim2.new(1, -12, 1, 0),
			["position"] = UDim2.fromOffset(6, 0)
		})
		local v_u_375 = v_u_340.new("Frame", {
			["Name"] = "Banner",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_343.bg
		}, v_u_351)
		v_u_340.stroke(v_u_375, v_u_343.line)
		local v_u_376 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "bodyStrong",
			["align"] = "center",
			["fit"] = true,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_375,
			["size"] = UDim2.new(1, -16, 1, 0),
			["position"] = UDim2.fromOffset(8, 0)
		})
		local v_u_377, v378 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "Role",
			["size"] = nil,
			["raised"] = true,
			["transparency"] = 0.1,
			["accent"] = nil,
			["padding"] = 10,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.danger
		})
		v_u_377.Visible = false
		local v_u_379 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = "h2",
			["align"] = "center",
			["fit"] = true,
			["size"] = nil,
			["parent"] = v378,
			["size"] = UDim2.new(1, 0, 0, 30)
		})
		local v_u_380 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v378,
			["color"] = v_u_343.text2,
			["size"] = UDim2.new(1, 0, 0, 40),
			["position"] = UDim2.fromOffset(0, 34)
		})
		local v_u_381, v382 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "Spectate",
			["size"] = nil,
			["accent"] = nil,
			["padding"] = 10,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.danger
		})
		v_u_381.Visible = false
		local v_u_383 = v_u_340.new("Frame", {
			["Name"] = "Text",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(100, 60)
		}, v382)
		local v_u_384 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Head",
			["text"] = "",
			["style"] = "h3",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_383,
			["color"] = v_u_343.danger,
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		local v_u_385 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_383,
			["color"] = v_u_343.text2,
			["size"] = UDim2.new(1, 0, 0, 36),
			["position"] = UDim2.fromOffset(0, 20)
		})
		local v_u_386 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Who",
			["text"] = "",
			["style"] = "bodyStrong",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_383,
			["size"] = UDim2.new(1, 0, 0, 18),
			["position"] = UDim2.fromOffset(0, 58)
		})
		local v_u_387, _ = v_u_340.button({
			["parent"] = nil,
			["name"] = "Prev",
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = 96,
			["height"] = nil,
			["onClick"] = nil,
			["parent"] = v382,
			["text"] = v_u_342.HUD.prev,
			["height"] = v_u_352,
			["onClick"] = v_u_353.prev
		})
		local v_u_388, _ = v_u_340.button({
			["parent"] = nil,
			["name"] = "Next",
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = 96,
			["height"] = nil,
			["onClick"] = nil,
			["parent"] = v382,
			["text"] = v_u_342.HUD.next,
			["height"] = v_u_352,
			["onClick"] = v_u_353.next
		})
		local v_u_389, _ = v_u_340.button({
			["parent"] = nil,
			["name"] = "Leave",
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = 104,
			["height"] = nil,
			["onClick"] = nil,
			["parent"] = v382,
			["text"] = v_u_342.MODE.leave,
			["height"] = v_u_352,
			["onClick"] = v_u_353.leaveOut
		})
		local function v392(p390) -- name: makeChip
			-- upvalues: (copy) v_u_340, (copy) v_u_343, (copy) v_u_341
			local v391 = v_u_340.new("Frame", {
				["Name"] = "KeyChip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 4,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_343.raised,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 6, 0.5, 0),
				["Size"] = UDim2.fromOffset(30, 22)
			}, p390)
			v_u_340.stroke(v391, v_u_343.lineStrong)
			return v_u_340.new("TextLabel", {
				["Name"] = "Key",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["Text"] = "",
				["ZIndex"] = 5,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_341.font.monoBold,
				["TextColor3"] = v_u_343.text
			}, v391)
		end
		local v_u_393 = v392(v_u_387)
		local v_u_394 = v392(v_u_388)
		local v_u_395, v396 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "End",
			["size"] = nil,
			["raised"] = true,
			["transparency"] = 0.05,
			["accent"] = nil,
			["padding"] = false,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.accent
		})
		v_u_395.Visible = false
		local v397 = v_u_341.isPhone()
		local v_u_398 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = "h1",
			["align"] = "center",
			["fit"] = true,
			["textSize"] = nil,
			["size"] = nil,
			["parent"] = v396,
			["textSize"] = v397 and 30 or 40,
			["size"] = UDim2.fromOffset(10, 10)
		})
		v_u_398.BackgroundTransparency = 0.1
		v_u_398.BackgroundColor3 = v_u_343.raised2
		local v_u_399 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Role",
			["text"] = "",
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["size"] = nil,
			["parent"] = v396,
			["color"] = v_u_343.text2,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_400 = {}
		for v401 = 1, 3 do
			local v402 = v_u_340.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Visible"] = false,
				["Name"] = "Tile" .. v401,
				["BackgroundColor3"] = v_u_343.bg
			}, v396)
			v_u_340.stroke(v402, v_u_343.line)
			v_u_400[v401] = {
				["f"] = v402,
				["l"] = v_u_340.label({
					["parent"] = nil,
					["name"] = "Label",
					["text"] = "",
					["style"] = "caps",
					["align"] = "center",
					["fit"] = true,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v402,
					["size"] = UDim2.new(1, -8, 0, 16),
					["position"] = UDim2.fromOffset(4, 3)
				}),
				["v"] = v_u_340.label({
					["parent"] = nil,
					["name"] = "Value",
					["text"] = "",
					["style"] = "h1",
					["align"] = "center",
					["fit"] = true,
					["color"] = nil,
					["textSize"] = nil,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v402,
					["color"] = v_u_343.accent,
					["textSize"] = v397 and 26 or 32,
					["size"] = UDim2.new(1, -8, 0, v397 and 30 or 36),
					["position"] = UDim2.fromOffset(4, v397 and 19 or 21)
				}),
				["s"] = v_u_340.label({
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = "",
					["style"] = "small",
					["align"] = "center",
					["fit"] = true,
					["color"] = nil,
					["textSize"] = nil,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v402,
					["color"] = v_u_343.text2,
					["textSize"] = not v397 and 14 or nil,
					["size"] = UDim2.new(1, -8, 0, 17),
					["position"] = UDim2.fromOffset(4, v397 and 51 or 58)
				})
			}
		end
		local v_u_403 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Breakdown",
			["text"] = "",
			["style"] = "small",
			["align"] = "center",
			["fit"] = true,
			["color"] = nil,
			["textSize"] = nil,
			["size"] = nil,
			["parent"] = v396,
			["color"] = v_u_343.text2,
			["textSize"] = not v397 and 15 or nil,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_404 = v_u_340.new("Frame", {
			["Name"] = "ProgBar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_343.line
		}, v396)
		local v_u_405 = v_u_340.new("Frame", {
			["Name"] = "Fill",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_343.accent,
			["Size"] = UDim2.fromScale(0, 1)
		}, v_u_404)
		local v_u_406 = v_u_340.label({
			["parent"] = nil,
			["name"] = "ProgText",
			["text"] = "",
			["style"] = "bodyStrong",
			["fit"] = true,
			["size"] = nil,
			["parent"] = v396,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_407 = v_u_340.label({
			["parent"] = nil,
			["name"] = "ProgLeft",
			["text"] = "",
			["style"] = "bodyStrong",
			["fit"] = true,
			["align"] = "right",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v396,
			["color"] = v_u_343.accent,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_408 = v_u_340.label({
			["parent"] = nil,
			["name"] = "ProgCrate",
			["text"] = "",
			["style"] = "small",
			["fit"] = true,
			["textSize"] = nil,
			["size"] = nil,
			["parent"] = v396,
			["textSize"] = not v397 and 14 or nil,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_409 = v_u_340.label({
			["parent"] = nil,
			["name"] = "ProgSteps",
			["text"] = "",
			["style"] = "small",
			["fit"] = true,
			["align"] = "right",
			["textSize"] = nil,
			["size"] = nil,
			["parent"] = v396,
			["textSize"] = not v397 and 14 or nil,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_410 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Titles",
			["text"] = "",
			["style"] = "bodyStrong",
			["color"] = nil,
			["align"] = "center",
			["wrap"] = true,
			["size"] = nil,
			["parent"] = v396,
			["color"] = v_u_343.accent,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_411, v_u_412 = v_u_340.button({
			["parent"] = nil,
			["name"] = "Back",
			["text"] = nil,
			["kind"] = "primary",
			["height"] = nil,
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v396,
			["text"] = v_u_342.MODE.back,
			["height"] = v_u_352,
			["size"] = UDim2.fromOffset(10, v_u_352),
			["onClick"] = v_u_353.back
		})
		local v_u_413, v_u_414 = v_u_340.button({
			["parent"] = nil,
			["name"] = "TrapBear",
			["text"] = "",
			["kind"] = "secondary",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, v_u_352),
			["onClick"] = v_u_353.trapBear
		})
		v_u_413.Visible = false
		local v_u_415, v_u_416 = v_u_340.button({
			["parent"] = nil,
			["name"] = "TrapAlarm",
			["text"] = "",
			["kind"] = "secondary",
			["size"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, v_u_352),
			["onClick"] = v_u_353.trapAlarm
		})
		v_u_415.Visible = false
		local v_u_417 = v392(v_u_413)
		local v_u_418 = v392(v_u_415)
		local v_u_419 = {}
		local v_u_420 = {}
		local v_u_421 = {}
		local v_u_422 = {
			["r"] = nil,
			["rects"] = nil
		}
		for _, v423 in {
			"melee",
			"frag",
			"flash",
			"cola"
		} do
			local v424 = "loot" .. string.upper((string.sub(v423, 1, 1))) .. string.sub(v423, 2)
			local v425, v426 = v_u_340.button({
				["parent"] = nil,
				["name"] = nil,
				["text"] = "",
				["kind"] = "secondary",
				["size"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_351,
				["name"] = "Loot" .. string.upper((string.sub(v423, 1, 1))) .. string.sub(v423, 2),
				["size"] = UDim2.fromOffset(10, v_u_352),
				["onClick"] = v_u_353[v424]
			})
			v425.Visible = false
			v_u_420[v423] = v425
			v_u_421[v423] = v426
			v_u_419[v423] = v392(v425)
		end
		local v_u_427 = ""
		local v_u_428, v429 = v_u_340.panel({
			["parent"] = nil,
			["name"] = "Home",
			["size"] = nil,
			["raised"] = true,
			["transparency"] = 0.05,
			["accent"] = nil,
			["padding"] = 14,
			["parent"] = v_u_351,
			["size"] = UDim2.fromOffset(10, 10),
			["accent"] = v_u_343.info
		})
		v_u_428.Visible = false
		local v_u_430 = v_u_340.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "h3",
			["align"] = "center",
			["wrap"] = true,
			["size"] = nil,
			["parent"] = v429,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_431, v_u_432, v_u_433, v_u_434
		if p_u_339.blindRoot then
			v_u_431 = v_u_340.new("Frame", {
				["Name"] = "Blind",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Visible"] = false,
				["ZIndex"] = 50,
				["Active"] = false,
				["BackgroundColor3"] = v_u_343.black,
				["Size"] = UDim2.fromScale(1, 1)
			}, p_u_339.blindRoot)
			v_u_432 = v_u_340.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = "",
				["style"] = "display",
				["align"] = "center",
				["color"] = nil,
				["fit"] = true,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 51,
				["parent"] = v_u_431,
				["color"] = v_u_343.text,
				["size"] = UDim2.new(0.8, 0, 0, 80),
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			})
			v_u_433 = v_u_340.label({
				["parent"] = nil,
				["name"] = "RoleTitle",
				["text"] = "",
				["style"] = "h2",
				["align"] = "center",
				["color"] = nil,
				["fit"] = true,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 51,
				["parent"] = v_u_431,
				["color"] = v_u_343.danger,
				["size"] = UDim2.new(0.8, 0, 0, 30),
				["position"] = UDim2.new(0.5, 0, 0.5, 70),
				["anchor"] = Vector2.new(0.5, 0)
			})
			v_u_434 = v_u_340.label({
				["parent"] = nil,
				["name"] = "RoleSub",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["align"] = "center",
				["wrap"] = true,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 51,
				["parent"] = v_u_431,
				["color"] = v_u_343.text2,
				["size"] = UDim2.new(0.8, 0, 0, 40),
				["position"] = UDim2.new(0.5, 0, 0.5, 106),
				["anchor"] = Vector2.new(0.5, 0)
			})
		else
			v_u_431 = nil
			v_u_433 = nil
			v_u_434 = nil
			v_u_432 = nil
		end
		local v_u_435 = false
		local function v483() -- name: relayout
			-- upvalues: (ref) v_u_355, (copy) v_u_341, (ref) v_u_356, (ref) v_u_662, (copy) v_u_340, (copy) v_u_358, (copy) v_u_367, (copy) v_u_363, (copy) v_u_373, (copy) v_u_375, (copy) v_u_377, (copy) v_u_381, (copy) v_u_413, (copy) v_u_415, (ref) v_u_427, (copy) v_u_395, (copy) v_u_372, (ref) v_u_435, (copy) v_u_422, (copy) v_u_428, (copy) v_u_383, (copy) v_u_387, (copy) v_u_388, (copy) v_u_389
			local v436 = v_u_341.refSize()
			v_u_356 = v436
			local v437 = v_u_341.touch(40)
			v_u_355 = v_u_662.layout(v436, v_u_341.isPhone(), v_u_340.topInset(), v437)
			local v438 = v_u_358
			local v439 = v_u_355.top
			local v440 = v439.x0 - v_u_356.X / 2
			v438.Position = UDim2.new(0.5, v440, 0, v439.y0)
			v438.Size = UDim2.fromOffset(v439.x1 - v439.x0, v439.y1 - v439.y0)
			local v441 = v_u_367
			local v442 = v_u_355.leave
			local v443 = v442.x0 - v_u_356.X / 2
			v441.Position = UDim2.new(0.5, v443, 0, v442.y0)
			v441.Size = UDim2.fromOffset(v442.x1 - v442.x0, v442.y1 - v442.y0)
			local v444 = v_u_363
			local v445 = v_u_355.pk
			local v446 = v445.x0 - v_u_356.X / 2
			v444.Position = UDim2.new(0.5, v446, 0, v445.y0)
			v444.Size = UDim2.fromOffset(v445.x1 - v445.x0, v445.y1 - v445.y0)
			local v447 = v_u_373
			local v448 = v_u_355.shot
			local v449 = v448.x0 - v_u_356.X / 2
			v447.Position = UDim2.new(0.5, v449, 0, v448.y0)
			v447.Size = UDim2.fromOffset(v448.x1 - v448.x0, v448.y1 - v448.y0)
			local v450 = v_u_375
			local v451 = v_u_355.banner
			local v452 = v451.x0 - v_u_356.X / 2
			v450.Position = UDim2.new(0.5, v452, 0, v451.y0)
			v450.Size = UDim2.fromOffset(v451.x1 - v451.x0, v451.y1 - v451.y0)
			local v453 = v_u_377
			local v454 = v_u_355.role
			local v455 = v454.x0 - v_u_356.X / 2
			v453.Position = UDim2.new(0.5, v455, 0, v454.y0)
			v453.Size = UDim2.fromOffset(v454.x1 - v454.x0, v454.y1 - v454.y0)
			local v456 = v_u_381
			local v457 = v_u_355.spec
			local v458 = v457.x0 - v_u_356.X / 2
			v456.Position = UDim2.new(0.5, v458, 1, -(v_u_356.Y - v457.y0))
			v456.Size = UDim2.fromOffset(v457.x1 - v457.x0, v457.y1 - v457.y0)
			local v459 = v_u_413
			local v460 = v_u_355.trapBear
			local v461 = v460.x0 - v_u_356.X / 2
			v459.Position = UDim2.new(0.5, v461, 1, -(v_u_356.Y - v460.y0))
			v459.Size = UDim2.fromOffset(v460.x1 - v460.x0, v460.y1 - v460.y0)
			local v462 = v_u_415
			local v463 = v_u_355.trapAlarm
			local v464 = v463.x0 - v_u_356.X / 2
			v462.Position = UDim2.new(0.5, v464, 1, -(v_u_356.Y - v463.y0))
			v462.Size = UDim2.fromOffset(v463.x1 - v463.x0, v463.y1 - v463.y0)
			v_u_427 = ""
			local v465 = v_u_395
			local v466 = v_u_355.endcard
			local v467 = v466.x0 - v_u_356.X / 2
			v465.Position = UDim2.new(0.5, v467, 0.5, v466.y0 - v_u_356.Y / 2)
			v465.Size = UDim2.fromOffset(v466.x1 - v466.x0, v466.y1 - v466.y0)
			local v468 = v_u_372
			local v469
			if v_u_435 then
				v469 = v_u_355.howtoWait
			else
				v469 = v_u_355.howto
			end
			local v470 = v469.x0 - v_u_356.X / 2
			v468.Position = UDim2.new(0.5, v470, 0, v469.y0)
			v468.Size = UDim2.fromOffset(v469.x1 - v469.x0, v469.y1 - v469.y0)
			v_u_422.r = nil
			local v471 = v_u_428
			local v472 = v_u_355.home
			local v473 = v472.x0 - v_u_356.X / 2
			v471.Position = UDim2.new(0.5, v473, 0.5, v472.y0 - v_u_356.Y / 2)
			v471.Size = UDim2.fromOffset(v472.x1 - v472.x0, v472.y1 - v472.y0)
			local v474 = {
				["x0"] = nil,
				["y0"] = nil,
				["x1"] = 0,
				["y1"] = 0,
				["x0"] = v_u_355.spec.x0 + 10,
				["y0"] = v_u_355.spec.y0 + 10
			}
			local v475 = v_u_383
			local v476 = v_u_355.specText
			v475.AnchorPoint = Vector2.zero
			v475.Position = UDim2.fromOffset(v476.x0 - v474.x0, v476.y0 - v474.y0)
			v475.Size = UDim2.fromOffset(v476.x1 - v476.x0, v476.y1 - v476.y0)
			local v477 = v_u_387
			local v478 = v_u_355.specPrev
			v477.AnchorPoint = Vector2.zero
			v477.Position = UDim2.fromOffset(v478.x0 - v474.x0, v478.y0 - v474.y0)
			v477.Size = UDim2.fromOffset(v478.x1 - v478.x0, v478.y1 - v478.y0)
			local v479 = v_u_388
			local v480 = v_u_355.specNext
			v479.AnchorPoint = Vector2.zero
			v479.Position = UDim2.fromOffset(v480.x0 - v474.x0, v480.y0 - v474.y0)
			v479.Size = UDim2.fromOffset(v480.x1 - v480.x0, v480.y1 - v480.y0)
			local v481 = v_u_389
			local v482 = v_u_355.specLeave
			v481.AnchorPoint = Vector2.zero
			v481.Position = UDim2.fromOffset(v482.x0 - v474.x0, v482.y0 - v474.y0)
			v481.Size = UDim2.fromOffset(v482.x1 - v482.x0, v482.y1 - v482.y0)
		end
		v483()
		v344.relayout = v483
		local v_u_484 = {
			["info"] = v_u_343.text,
			["warn"] = v_u_343.accent,
			["danger"] = v_u_343.danger
		}
		local v_u_485 = {}
		local v_u_486 = ""
		function v344.render(p487, p488) -- name: render
			-- upvalues: (ref) v_u_345, (ref) v_u_354, (copy) v_u_358, (copy) v_u_360, (copy) v_u_342, (copy) v_u_485, (copy) v_u_340, (copy) v_u_361, (ref) v_u_662, (copy) v_u_362, (copy) v_u_367, (copy) v_u_368, (copy) p_u_339, (copy) v_u_372, (ref) v_u_435, (ref) v_u_355, (ref) v_u_356, (copy) v_u_363, (copy) v_u_365, (copy) v_u_366, (copy) v_u_343, (copy) v_u_413, (copy) v_u_415, (copy) v_u_414, (copy) v_u_416, (copy) v_u_417, (copy) v_u_418, (ref) v_u_427, (copy) v_u_420, (copy) v_u_341, (copy) v_u_352, (copy) v_u_421, (copy) v_u_419, (copy) v_u_373, (copy) v_u_374, (copy) v_u_375, (copy) v_u_376, (copy) v_u_484, (copy) v_u_377, (copy) v_u_379, (copy) v_u_380, (copy) v_u_381, (copy) v_u_384, (copy) v_u_385, (copy) v_u_386, (copy) v_u_388, (copy) v_u_387, (copy) v_u_393, (copy) v_u_394, (copy) v_u_395, (copy) v_u_422, (copy) v_u_398, (copy) v_u_399, (copy) v_u_400, (copy) v_u_403, (copy) v_u_404, (copy) v_u_406, (copy) v_u_407, (copy) v_u_408, (copy) v_u_409, (copy) v_u_405, (copy) v_u_410, (copy) v_u_411, (ref) v_u_486, (copy) v_u_412, (copy) v_u_428, (copy) v_u_430, (ref) v_u_431, (ref) v_u_432, (ref) v_u_433, (ref) v_u_434
			if v_u_345 then
				local v489 = p487.result ~= nil
				local v490 = p487.home ~= nil
				local v491 = p487.phase
				local v492 = os.clock() < v_u_354
				local v493
				if v491 == nil then
					v493 = false
				else
					v493 = not v489
					if v493 then
						v493 = not v490
					end
				end
				v_u_358.Visible = v493
				if v493 then
					local v494 = v_u_360
					local v495 = v_u_342.PHASE[v491] or ""
					if v_u_485[v494] ~= v495 then
						v_u_485[v494] = v495
						v_u_340.setText(v494, v495)
					end
					local v496 = p487.endsAt
					local v497
					if type(v496) == "number" and (p487.endsAt > 0 and p487.now) then
						v497 = p487.endsAt - p487.now
					else
						v497 = nil
					end
					local v498 = v_u_361
					local v499 = (v497 == nil or (v491 == "wait" or v491 == "over")) and "" or v_u_662.clock(v497)
					if v_u_485[v498] ~= v499 then
						v_u_485[v498] = v499
						v_u_340.setText(v498, v499)
					end
					local v500 = v_u_362
					local v501 = v491 == "wait" and "" or v_u_662.counters(v_u_342, p487.alive, p487.s0, p487.stalkers)
					if v_u_485[v500] ~= v501 then
						v_u_485[v500] = v501
						v_u_340.setText(v500, v501)
					end
				end
				local v502
				if v493 then
					if p487.role == nil or p487.out ~= nil then
						v502 = false
					else
						v502 = (v491 == "hide" or v491 == "hunt") and true or v491 == "payback"
					end
				else
					v502 = v493
				end
				v_u_367.Visible = v502
				if v502 then
					v_u_368.setKind(v492 and "danger" or "ghost")
				elseif v_u_354 ~= 0 then
					v_u_354 = 0
				end
				local v503
				if v493 then
					local v504 = p_u_339.onHowTo
					if type(v504) == "function" and (p487.out == nil and p487.blind ~= true) then
						if v491 == "wait" then
							v503 = true
						elseif v491 == "hide" then
							v503 = p487.role == "survivor"
						else
							v503 = false
						end
					else
						v503 = false
					end
				else
					v503 = v493
				end
				v_u_372.Visible = v503
				if v491 == "wait" ~= v_u_435 then
					v_u_435 = v491 == "wait"
					local v505 = v_u_372
					local v506
					if v_u_435 then
						v506 = v_u_355.howtoWait
					else
						v506 = v_u_355.howto
					end
					local v507 = v506.x0 - v_u_356.X / 2
					v505.Position = UDim2.new(0.5, v507, 0, v506.y0)
					v505.Size = UDim2.fromOffset(v506.x1 - v506.x0, v506.y1 - v506.y0)
				end
				local v508
				if v493 then
					if p487.role == nil or (p487.out ~= nil or v491 ~= "hunt" and v491 ~= "payback") then
						v508 = false
					else
						local v509 = p487.pk
						v508 = type(v509) == "table"
					end
				else
					v508 = v493
				end
				v_u_363.Visible = v508
				if v508 then
					local v510 = v_u_365
					local v511 = v_u_342.format(v_u_342.PUMPKIN.chipCount, p487.pk.n or 0)
					if v_u_485[v510] ~= v511 then
						v_u_485[v510] = v511
						v_u_340.setText(v510, v511)
					end
					local v512 = v_u_366
					local v513 = p487.pk.t
					local v514 = type(v513) ~= "number" and "" or v_u_342.format(v_u_342.PUMPKIN.total, p487.pk.t)
					if v_u_485[v512] ~= v514 then
						v_u_485[v512] = v514
						v_u_340.setText(v512, v514)
					end
					local v515 = p487.pk.at
					local v516
					if type(v515) == "number" then
						v516 = p488 - p487.pk.at < 0.8
					else
						v516 = false
					end
					local v517 = v_u_365
					local v518
					if v516 then
						v518 = v_u_343.text
					else
						v518 = v_u_343.accent
					end
					v517.TextColor3 = v518
				end
				local v519 = p487.role == "stalker" and p487.out == nil and not (v489 or v490)
				if v519 then
					if v491 == "hunt" or v491 == "payback" then
						local v520 = p487.trap
						v519 = type(v520) == "table"
					else
						v519 = false
					end
				end
				v_u_413.Visible = v519
				v_u_415.Visible = v519
				if v519 then
					local v521 = p487.trap.bear or 0
					local v522 = math.floor(v521)
					local v523 = math.max(0, v522)
					local v524 = p487.trap.alarm or 0
					local v525 = math.floor(v524)
					local v526 = math.max(0, v525)
					local v527 = v_u_342.format(v_u_342.TRAP.button, v_u_342.TRAP.bearShort, v523)
					local v528 = v_u_342.format(v_u_342.TRAP.button, v_u_342.TRAP.alarmShort, v526)
					if v_u_485[v_u_413] ~= v527 then
						v_u_485[v_u_413] = v527
						v_u_414.setText(v527)
					end
					if v_u_485[v_u_415] ~= v528 then
						v_u_485[v_u_415] = v528
						v_u_416.setText(v528)
					end
					v_u_414.setEnabled(v523 > 0)
					v_u_416.setEnabled(v526 > 0)
					for _, v529 in {
						{ v_u_417, "bear" },
						{ v_u_418, "alarm" }
					} do
						local v530 = v529[1]
						local v531 = v529[2]
						local v532 = p_u_339.keyLabel
						local v533
						if type(v532) == "function" then
							local v534 = p_u_339.keyLabel
							local v535, v536 = pcall(v534, v531)
							v533 = (not v535 or type(v536) ~= "string") and "" or string.upper(v536)
						else
							v533 = ""
						end
						if v530.Text ~= v533 then
							v530.Text = v533
						end
						v530.Parent.Visible = v533 ~= ""
					end
				end
				local v537 = (p487.role ~= "survivor" or (p487.out ~= nil or (v489 or (v490 or v491 ~= "hide" and (v491 ~= "hunt" and v491 ~= "payback"))))) and {} or v_u_662.lootSlots(v_u_342, p487.loot)
				local v538 = ""
				for _, v539 in v537 do
					v538 = v538 .. v539.which .. ","
				end
				if v538 ~= v_u_427 then
					v_u_427 = v538
					for _, v540 in v_u_420 do
						v540.Visible = false
					end
					if #v537 > 0 then
						local v541 = v_u_662.lootRects(v_u_356, v_u_341.isPhone(), v_u_352, #v537)
						for v542, v543 in v537 do
							local v544 = v_u_420[v543.which]
							local v545 = v541[v542]
							local v546 = v545.x0 - v_u_356.X / 2
							v544.Position = UDim2.new(0.5, v546, 1, -(v_u_356.Y - v545.y0))
							v544.Size = UDim2.fromOffset(v545.x1 - v545.x0, v545.y1 - v545.y0)
							v_u_420[v543.which].Visible = true
						end
					end
				end
				for _, v547 in v537 do
					local v548 = v547.which
					if v_u_485[v_u_420[v548]] ~= v547.text then
						v_u_485[v_u_420[v548]] = v547.text
						v_u_421[v548].setText(v547.text)
					end
					v_u_421[v548].setKind(v547.selected and "primary" or "secondary")
					local v549 = ""
					local v550 = v_u_340.device
					if (type(v550) ~= "function" and "Keyboard" or v_u_340.device()) ~= "Touch" then
						if v548 == "melee" then
							v549 = v_u_340.hint("meleeSlot")
						elseif v548 == "cola" then
							local v551 = p_u_339.lootKey
							if type(v551) == "function" then
								local v552 = p_u_339.lootKey
								local v553, v554 = pcall(v552, v548)
								v549 = (not v553 or type(v554) ~= "string") and "" or v554
							end
						else
							v549 = v_u_340.hint("throw")
						end
					end
					local v555 = string.upper(v549)
					if v_u_419[v548].Text ~= v555 then
						v_u_419[v548].Text = v555
					end
					v_u_419[v548].Parent.Visible = v555 ~= ""
				end
				local v556
				if v493 then
					v556 = v_u_662.shotText(v_u_342, p487)
				else
					v556 = nil
				end
				v_u_373.Visible = v556 ~= nil
				if v556 ~= nil then
					local v557 = v_u_374
					if v_u_485[v557] ~= v556 then
						v_u_485[v557] = v556
						v_u_340.setText(v557, v556)
					end
					local v558 = v_u_662.shotLeft(p487) or 0
					local v559 = v_u_374
					local v560
					if p487.role == "stalker" or v558 <= 10 then
						v560 = v_u_343.danger
					else
						v560 = v_u_343.accent
					end
					v559.TextColor3 = v560
				end
				local v561, v562 = v_u_662.bannerOf(v_u_342, p487, p488, v492 and v502)
				local v563
				if v561 == nil then
					v563 = false
				else
					v563 = not v489
					if v563 then
						v563 = not v490
					end
				end
				v_u_375.Visible = v563
				if v563 then
					local v564 = v_u_376
					if v_u_485[v564] ~= v561 then
						v_u_485[v564] = v561
						v_u_340.setText(v564, v561)
					end
					v_u_376.TextColor3 = v_u_484[v562] or v_u_343.text
				end
				local v565 = p487.roleCard
				local v566
				if type(v565) == "table" and p488 < (v565.untilT or 0) then
					v566 = not v489
					if v566 then
						v566 = not v490
					end
				else
					v566 = false
				end
				v_u_377.Visible = v566
				if v566 then
					local v567 = v_u_379
					local v568 = v565.t or ""
					if v_u_485[v567] ~= v568 then
						v_u_485[v567] = v568
						v_u_340.setText(v567, v568)
					end
					local v569 = v_u_380
					local v570 = v565.sub or ""
					if v_u_485[v569] ~= v570 then
						v_u_485[v569] = v570
						v_u_340.setText(v569, v570)
					end
					local v571 = v_u_377:FindFirstChild("Accent")
					if v571 then
						local v572
						if v565.r == "stalker" then
							v572 = v_u_343.danger
						else
							v572 = v_u_343.info
						end
						v571.BackgroundColor3 = v572
					end
				end
				local v573
				if p487.out == nil then
					v573 = false
				else
					v573 = not v489
					if v573 then
						v573 = not v490
					end
				end
				v_u_381.Visible = v573
				if v573 then
					local v574 = v_u_384
					local v575 = p487.out.t or ""
					if v_u_485[v574] ~= v575 then
						v_u_485[v574] = v575
						v_u_340.setText(v574, v575)
					end
					v_u_385.Text = p487.out.sub or ""
					local v576 = v_u_386
					local v577 = p487.watching
					local v578 = (type(v577) ~= "string" or p487.watching == "") and "" or v_u_342.format(v_u_342.HUD.spectating, p487.watching)
					if v_u_485[v576] ~= v578 then
						v_u_485[v576] = v578
						v_u_340.setText(v576, v578)
					end
					v_u_388.Visible = true
					v_u_387.Visible = true
					local v579 = v_u_340.device
					local v580 = type(v579) ~= "function" and "Keyboard" or v_u_340.device()
					for _, v581 in {
						{ v_u_393, "prev" },
						{ v_u_394, "next" }
					} do
						local v582 = v581[1]
						local v583 = v581[2]
						local v584 = v580 == "Touch" and "" or string.upper(v_u_340.hint(v_u_662.SPEC_ACTIONS[v583]))
						if v582.Text ~= v584 then
							v582.Text = v584
						end
						v582.Parent.Visible = v584 ~= ""
					end
				end
				local v585 = v_u_395
				local v586
				if v489 then
					v586 = not v490
				else
					v586 = v489
				end
				v585.Visible = v586
				if v489 then
					local v587 = p487.result
					if v_u_422.r ~= v587 then
						v_u_422.r = v587
						local v588 = v_u_662.endModel(v_u_342, p_u_339.Rules, p_u_339.Rewards, v587)
						local v589 = {
							["tiles"] = #v588.tiles,
							["brk"] = v588.brk ~= "",
							["prog"] = v588.prog ~= nil,
							["earned"] = #v588.earned
						}
						local v590 = v_u_662.endRects(v_u_356, v_u_341.isPhone(), v_u_352, v589)
						v_u_422.rects = v590
						local v591 = v_u_395
						local v592 = v590.endcard
						local v593 = v592.x0 - v_u_356.X / 2
						v591.Position = UDim2.new(0.5, v593, 0.5, v592.y0 - v_u_356.Y / 2)
						v591.Size = UDim2.fromOffset(v592.x1 - v592.x0, v592.y1 - v592.y0)
						local v594 = v_u_398
						local v595 = v590.endBar
						v594.Visible = v595 ~= nil
						if v595 ~= nil then
							v594.Position = UDim2.fromOffset(v595.x0, v595.y0)
							v594.Size = UDim2.fromOffset(v595.x1 - v595.x0, v595.y1 - v595.y0)
						end
						local v596 = v_u_399
						local v597 = v590.endRole
						v596.Visible = v597 ~= nil
						if v597 ~= nil then
							v596.Position = UDim2.fromOffset(v597.x0, v597.y0)
							v596.Size = UDim2.fromOffset(v597.x1 - v597.x0, v597.y1 - v597.y0)
						end
						local v598 = v_u_398
						local v599 = v588.title
						if v_u_485[v598] ~= v599 then
							v_u_485[v598] = v599
							v_u_340.setText(v598, v599)
						end
						local v600 = v_u_399
						local v601 = v588.role
						if v_u_485[v600] ~= v601 then
							v_u_485[v600] = v601
							v_u_340.setText(v600, v601)
						end
						local v602 = v_u_398
						local v603
						if v588.tone == "win" then
							v603 = v_u_343.success
						elseif v588.tone == "lose" then
							v603 = v_u_343.danger
						else
							v603 = v_u_343.raised2
						end
						v602.BackgroundColor3 = v603
						local v604 = v_u_398
						local v605
						if v588.tone == "win" then
							v605 = v_u_343.ink
						elseif v588.tone == "lose" then
							v605 = v_u_343.white
						else
							v605 = v_u_343.text
						end
						v604.TextColor3 = v605
						for v606 = 1, 3 do
							local v607 = v_u_400[v606]
							local v608 = v607.f
							local v609 = v590["endTile" .. v606]
							v608.Visible = v609 ~= nil
							if v609 ~= nil then
								v608.Position = UDim2.fromOffset(v609.x0, v609.y0)
								v608.Size = UDim2.fromOffset(v609.x1 - v609.x0, v609.y1 - v609.y0)
							end
							local v610 = v588.tiles[v606]
							if v610 == nil then
								continue
							end
							local v611 = v607.l
							local v612 = v610.label
							if v_u_485[v611] ~= v612 then
								v_u_485[v611] = v612
								v_u_340.setText(v611, v612)
							end
							v607.v.Text = v610.value
							local v613 = v607.s
							local v614 = v610.sub
							if v_u_485[v613] == v614 then
								continue
							end
							v_u_485[v613] = v614
							v_u_340.setText(v613, v614)
						end
						local v615 = v_u_403
						local v616 = v590.endBreak
						v615.Visible = v616 ~= nil
						if v616 ~= nil then
							v615.Position = UDim2.fromOffset(v616.x0, v616.y0)
							v615.Size = UDim2.fromOffset(v616.x1 - v616.x0, v616.y1 - v616.y0)
						end
						v_u_403.Text = v588.brk
						local v617 = v_u_404
						local v618 = v590.endProgBar
						v617.Visible = v618 ~= nil
						if v618 ~= nil then
							v617.Position = UDim2.fromOffset(v618.x0, v618.y0)
							v617.Size = UDim2.fromOffset(v618.x1 - v618.x0, v618.y1 - v618.y0)
						end
						local v619 = v_u_406
						local v620 = v590.endProgText
						v619.Visible = v620 ~= nil
						if v620 ~= nil then
							v619.Position = UDim2.fromOffset(v620.x0, v620.y0)
							v619.Size = UDim2.fromOffset(v620.x1 - v620.x0, v620.y1 - v620.y0)
						end
						local v621 = v_u_407
						local v622 = v590.endProgLeft
						v621.Visible = v622 ~= nil
						if v622 ~= nil then
							v621.Position = UDim2.fromOffset(v622.x0, v622.y0)
							v621.Size = UDim2.fromOffset(v622.x1 - v622.x0, v622.y1 - v622.y0)
						end
						local v623 = v_u_408
						local v624 = v590.endProgCrate
						v623.Visible = v624 ~= nil
						if v624 ~= nil then
							v623.Position = UDim2.fromOffset(v624.x0, v624.y0)
							v623.Size = UDim2.fromOffset(v624.x1 - v624.x0, v624.y1 - v624.y0)
						end
						local v625 = v_u_409
						local v626 = v590.endProgSteps
						v625.Visible = v626 ~= nil
						if v626 ~= nil then
							v625.Position = UDim2.fromOffset(v626.x0, v626.y0)
							v625.Size = UDim2.fromOffset(v626.x1 - v626.x0, v626.y1 - v626.y0)
						end
						if v588.prog ~= nil then
							v_u_405.Size = UDim2.fromScale(v588.prog.frac, 1)
							v_u_406.Text = v588.prog.text
							v_u_407.Text = v588.prog.left
							v_u_408.Text = v588.prog.crate
							v_u_409.Text = v588.prog.steps
						end
						local v627 = v_u_410
						local v628 = v590.endEarned
						v627.Visible = v628 ~= nil
						if v628 ~= nil then
							v627.Position = UDim2.fromOffset(v628.x0, v628.y0)
							v627.Size = UDim2.fromOffset(v628.x1 - v628.x0, v628.y1 - v628.y0)
						end
						v_u_410.Text = table.concat(v588.earned, "\n")
						local v629 = v_u_411
						local v630 = v590.endBack
						v629.Visible = v630 ~= nil
						if v630 ~= nil then
							v629.Position = UDim2.fromOffset(v630.x0, v630.y0)
							v629.Size = UDim2.fromOffset(v630.x1 - v630.x0, v630.y1 - v630.y0)
						end
						local v631 = v_u_395:FindFirstChild("Accent")
						if v631 then
							local v632
							if v588.tone == "win" then
								v632 = v_u_343.success
							elseif v588.tone == "lose" then
								v632 = v_u_343.danger
							else
								v632 = v_u_343.accent
							end
							v631.BackgroundColor3 = v632
						end
					end
					local v633
					if v587.sec and v587.at then
						local v634 = v587.sec - (os.clock() - v587.at)
						local v635 = math.ceil(v634)
						v633 = math.max(0, v635)
					else
						v633 = nil
					end
					local v636
					if v633 == nil then
						v636 = v_u_342.MODE.back
					else
						v636 = ("%s %d"):format(v_u_342.MODE.back, v633)
					end
					if v_u_486 ~= v636 then
						v_u_486 = v636
						v_u_412.setText(v636)
					end
				end
				v_u_428.Visible = v490
				if v490 then
					v_u_430.Text = p487.home.t or ""
				end
				if v_u_431 then
					local v637
					if p487.blind == true then
						v637 = not v489
						if v637 then
							v637 = not v490
						end
					else
						v637 = false
					end
					v_u_431.Visible = v637
					if v637 and v_u_432 then
						local v638 = p487.endsAt
						local v639
						if type(v638) == "number" and p487.now then
							local v640 = p487.endsAt - p487.now
							local v641 = math.ceil(v640)
							v639 = math.max(0, v641)
						else
							v639 = 0
						end
						local v642 = v_u_432
						local v643 = v_u_342.format
						local v644
						if (p487.stalkers or 1) >= 2 and v_u_342.HUD.blindMany ~= nil then
							v644 = v_u_342.HUD.blindMany
						else
							v644 = v_u_342.HUD.blind
						end
						v642.Text = v643(v644, v639)
					end
					if v_u_433 and v_u_434 then
						local v645 = v637 and v566
						local v646 = v_u_434
						v_u_433.Visible = v645
						v646.Visible = v645
						if v645 then
							local v647 = v_u_433
							local v648 = v565.t or ""
							if v_u_485[v647] ~= v648 then
								v_u_485[v647] = v648
								v_u_340.setText(v647, v648)
							end
							local v649 = v_u_434
							local v650 = v565.sub or ""
							if v_u_485[v649] ~= v650 then
								v_u_485[v649] = v650
								v_u_340.setText(v649, v650)
							end
						end
					end
				end
			end
		end
		function v344.focusTargets() -- name: focusTargets
			-- upvalues: (copy) v_u_395, (copy) v_u_411, (copy) v_u_381, (copy) v_u_387, (copy) v_u_388, (copy) v_u_389, (copy) v_u_367, (copy) v_u_372
			local v651 = {}
			if v_u_395.Visible then
				local v652 = v_u_411
				table.insert(v651, v652)
			elseif v_u_381.Visible then
				local v653 = v_u_387
				table.insert(v651, v653)
				local v654 = v_u_388
				table.insert(v651, v654)
				local v655 = v_u_389
				table.insert(v651, v655)
			end
			if v_u_367.Visible then
				local v656 = v_u_367
				table.insert(v651, v656)
			end
			if v_u_372.Visible then
				local v657 = v_u_372
				table.insert(v651, v657)
			end
			return v651
		end
		function v344.visible() -- name: visible
			-- upvalues: (copy) v_u_358, (copy) v_u_367, (copy) v_u_372, (copy) v_u_363, (copy) v_u_373, (copy) v_u_375, (copy) v_u_377, (copy) v_u_381, (copy) v_u_395, (copy) v_u_413, (copy) v_u_420, (copy) v_u_428, (ref) v_u_431
			local v658 = {
				["top"] = v_u_358.Visible,
				["leave"] = v_u_367.Visible,
				["howto"] = v_u_372.Visible,
				["pk"] = v_u_363.Visible,
				["shot"] = v_u_373.Visible,
				["banner"] = v_u_375.Visible,
				["role"] = v_u_377.Visible,
				["spec"] = v_u_381.Visible,
				["endcard"] = v_u_395.Visible,
				["traps"] = v_u_413.Visible,
				["loot"] = v_u_420.melee.Visible or v_u_420.frag.Visible or (v_u_420.flash.Visible or v_u_420.cola.Visible),
				["home"] = v_u_428.Visible
			}
			local v659
			if v_u_431 == nil then
				v659 = false
			else
				v659 = v_u_431.Visible
			end
			v658.blind = v659
			return v658
		end
		function v344.buttons() -- name: buttons
			-- upvalues: (copy) v_u_372, (copy) v_u_367, (copy) v_u_387, (copy) v_u_388, (copy) v_u_389, (copy) v_u_411, (copy) v_u_413, (copy) v_u_415, (copy) v_u_420
			return {
				["howto"] = v_u_372,
				["leave"] = v_u_367,
				["prev"] = v_u_387,
				["next"] = v_u_388,
				["leaveOut"] = v_u_389,
				["back"] = v_u_411,
				["trapBear"] = v_u_413,
				["trapAlarm"] = v_u_415,
				["lootMelee"] = v_u_420.melee,
				["lootFrag"] = v_u_420.frag,
				["lootFlash"] = v_u_420.flash,
				["lootCola"] = v_u_420.cola
			}
		end
		function v344.armLeave() -- name: armLeave
			-- upvalues: (ref) v_u_354, (ref) v_u_662
			v_u_354 = os.clock() + v_u_662.LEAVE_ARM
		end
		function v344.press(p660) -- name: press
			-- upvalues: (copy) v_u_353
			local v661 = v_u_353[p660]
			if v661 then
				v661()
			end
		end
		function v344.destroy() -- name: destroy
			-- upvalues: (ref) v_u_345, (copy) v_u_351, (ref) v_u_431
			v_u_345 = false
			v_u_351:Destroy()
			if v_u_431 then
				v_u_431:Destroy()
			end
		end
		return v344
	end
}
return v_u_662