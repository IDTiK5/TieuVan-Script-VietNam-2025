-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AcClient

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_42 = {
	["PERIOD"] = 5,
	["REMOTE"] = "ac.hb",
	["CD_FP"] = 4,
	["CD_TP"] = 14,
	["CD_VEH"] = 45,
	["deviceClass"] = function(p4) -- name: deviceClass
		return p4 == "Touch" and "touch" or (p4 == "Gamepad" and "pad" or "kb")
	end,
	["build"] = function(p5) -- name: build
		-- upvalues: (copy) v_u_42
		if type(p5) == "table" then
			local v6 = p5.root
			if typeof(v6) == "Vector3" then
				local v7 = p5.root
				local v8 = 0
				local v9 = p5.focus
				local v10
				if typeof(v9) == "Vector3" then
					local v11 = p5.focus - v7
					local v12 = v11.X * v11.X + v11.Z * v11.Z
					v10 = math.sqrt(v12)
				else
					v10 = 0
				end
				local v13 = p5.camPos
				if typeof(v13) == "Vector3" then
					v8 = (p5.camPos - v7).Magnitude
				end
				local v14 = p5.override == true and "scripted" or (p5.mode ~= "iso" and (p5.mode ~= "spectate" and (p5.mode ~= "scripted" and (p5.mode ~= "fp" and p5.mode ~= "tp"))) and "other" or p5.mode)
				local v15 = p5.ride == true and (v14 == "fp" or v14 == "tp") and "veh" or v14
				local v16 = false
				if v15 == "fp" or (v15 == "tp" or v15 == "veh") then
					local v17 = p5.camPos
					if typeof(v17) == "Vector3" then
						local v18 = p5.head
						local v19
						if typeof(v18) == "Vector3" then
							v19 = p5.head
						else
							v19 = v7 + Vector3.new(0, 1.5, 0)
						end
						local v20 = (p5.camPos - v19).Magnitude
						local v21
						if v15 == "fp" then
							v21 = v_u_42.CD_FP
						elseif v15 == "veh" then
							v21 = v_u_42.CD_VEH
						else
							v21 = v_u_42.CD_TP
						end
						v16 = v21 < v20 and true or v16
					end
				end
				if v15 == "iso" then
					local v22 = p5.camPos
					if typeof(v22) == "Vector3" then
						local v23 = p5.camLook
						if typeof(v23) == "Vector3" then
							local v24 = p5.focus
							if typeof(v24) == "Vector3" then
								local v25 = p5.focus - p5.camPos
								if v25.Magnitude > 1 and p5.camLook.Magnitude > 0.1 then
									local v26 = v25.Unit:Dot(p5.camLook.Unit)
									local v27 = math.clamp(v26, -1, 1)
									local v28 = math.acos(v27)
									v16 = math.deg(v28) > 4 and true or v16
								end
							end
						end
					end
					local v29 = p5.camType
					v16 = type(v29) == "string" and p5.camType ~= "Scriptable" and true or v16
				end
				if v10 ~= v10 or v8 ~= v8 then
					return nil
				end
				local v30 = {
					["v"] = 1,
					["fd"] = nil,
					["cd"] = nil,
					["k"] = nil,
					["x"] = nil,
					["m"] = nil
				}
				local v31 = v10 * 10 + 0.5
				local v32 = math.floor(v31) / 10
				v30.fd = math.min(v32, 100000)
				local v33 = v8 * 10 + 0.5
				local v34 = math.floor(v33) / 10
				v30.cd = math.min(v34, 100000)
				v30.k = v_u_42.deviceClass(p5.device)
				v30.x = v16 and 1 or 0
				v30.m = v15
				return v30
			end
		end
		return nil
	end,
	["merge"] = function(p35, p36) -- name: merge
		if type(p35) == "table" then
			if type(p36) ~= "table" then
				return p35
			end
			local v37 = table.clone(p35)
			local v38 = p35.fd
			local v39 = p36.fd
			v37.fd = math.max(v38, v39)
			local v40 = p35.cd
			local v41 = p36.cd
			v37.cd = math.max(v40, v41)
			v37.x = (p35.x == 1 or p36.x == 1) and 1 or 0
			return v37
		elseif type(p36) == "table" then
			return p36
		else
			return nil
		end
	end
}
local function v_u_58(p43) -- name: gather
	-- upvalues: (copy) v_u_1
	local v44 = v_u_1.LocalPlayer.Character
	local v45
	if v44 then
		v45 = v44:FindFirstChild("HumanoidRootPart")
	else
		v45 = v44
	end
	if not v45 then
		return nil
	end
	local v46 = workspace.CurrentCamera
	local v47 = p43.controllers.Camera
	local v48 = p43.controllers.Input
	local v49 = {
		["root"] = v45.Position
	}
	local v50
	if v48 and v48.device then
		v50 = v48.device()
	else
		v50 = nil
	end
	v49.device = v50
	if v44 then
		v44 = v44:FindFirstChild("Head")
	end
	if v44 ~= nil and v44:IsA("BasePart") then
		v49.head = v44.Position
	end
	if v46 then
		v49.focus = v46.Focus.Position
		v49.camPos = v46.CFrame.Position
		v49.camLook = v46.CFrame.LookVector
		v49.camType = v46.CameraType.Name
	end
	if v47 then
		local v51
		if v47.mode then
			v51 = v47.mode()
		else
			v51 = nil
		end
		v49.mode = v51
		local v52
		if v47.hasOverride then
			v52 = v47.hasOverride()
		else
			v52 = false
		end
		v49.override = v52
	end
	local v53 = p43.controllers.VehicleClient
	if v53 ~= nil then
		local v54 = v53.riding
		if type(v54) == "function" then
			local v55 = v53.riding
			local v56, v57 = pcall(v55)
			if v56 then
				v56 = v57 == true
			end
			v49.ride = v56
		end
	end
	return v49
end
v_u_42.PRIVATE = {
	["Ammo"] = true,
	["Ammo2"] = true,
	["AmmoReserve"] = true,
	["AmmoTier"] = true,
	["Throwable"] = true,
	["ThrowableList"] = true,
	["Throwables"] = true
}
local v_u_59 = {}
local v_u_60 = false
local v_u_61 = nil
function v_u_42.applyPrivate(p62) -- name: applyPrivate
	-- upvalues: (copy) v_u_42, (copy) v_u_59, (ref) v_u_60
	if type(p62) ~= "table" then
		return 0
	end
	local v63 = #p62
	local v64 = 0
	for v65 = 1, math.min(v63, 40) - 1, 2 do
		local v66 = p62[v65]
		local v67 = p62[v65 + 1]
		local v68 = type(v67)
		if type(v66) ~= "string" or v_u_42.PRIVATE[v66] ~= true or (v68 ~= "string" or #v67 > 200) and (v68 ~= "boolean" and (v68 ~= "number" or v67 ~= v67)) then
			continue
		end
		v_u_59[v66] = v67
		v64 = v64 + 1
	end
	if v64 > 0 then
		v_u_60 = true
	end
	return v64
end
function v_u_42.pushPrivate(p69) -- name: pushPrivate
	-- upvalues: (ref) v_u_61, (ref) v_u_60, (copy) v_u_59
	if not p69 then
		return false
	end
	v_u_61 = p69
	v_u_60 = false
	local v70 = false
	for v71, v72 in v_u_59 do
		if p69:GetAttribute(v71) == v72 then
			continue
		end
		p69:SetAttribute(v71, v72)
		v70 = true
	end
	return v70
end
function v_u_42._privState()
	-- upvalues: (copy) v_u_59
	return v_u_59
end
local function v_u_82(p73, p_u_74) -- name: sampleAt
	-- upvalues: (copy) v_u_58, (copy) v_u_42
	local v_u_75 = false
	local v_u_76 = nil
	local v79 = p73:Connect(function()
		-- upvalues: (ref) v_u_75, (ref) v_u_58, (copy) p_u_74, (ref) v_u_76, (ref) v_u_42
		if not v_u_75 then
			v_u_75 = true
			local v77 = v_u_58(p_u_74)
			local v78
			if v77 then
				v78 = v_u_42.build(v77)
			else
				v78 = nil
			end
			v_u_76 = v78
		end
	end)
	local v80 = os.clock()
	local v81 = v_u_76
	while not v_u_75 and os.clock() - v80 < 0.3 do
		task.wait()
	end
	v79:Disconnect()
	return v81
end
v_u_42.WATCH_REMOTE = "rv.cam"
v_u_42.WATCH_HZ = 10
function v_u_42.watchPacket(p83, p84) -- name: watchPacket
	-- upvalues: (copy) v_u_2
	local function v85()
		-- upvalues: (ref) v_u_2
		return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	end
	local v86, v87 = pcall(v85)
	if not v86 or type(p83) ~= "table" then
		return nil
	end
	local v88 = table.clone(p83)
	v88.seq = p84
	return v87.buildCam(v88)
end
local function v_u_108(p89) -- name: watchFacts
	-- upvalues: (copy) v_u_1
	local v90 = v_u_1.LocalPlayer.Character
	local v91
	if v90 then
		v91 = v90:FindFirstChild("HumanoidRootPart")
	else
		v91 = v90
	end
	local v92 = workspace.CurrentCamera
	if not (v91 and v92) then
		return nil
	end
	local v93 = p89.controllers.Camera
	local v94 = v92.Focus.Position
	local v95 = {
		["yaw"] = not (v93 and v93.yaw) and 0 or v93.yaw(),
		["dist"] = (v92.CFrame.Position - v94).Magnitude,
		["fov"] = v92.FieldOfView,
		["ox"] = v94.X - v91.Position.X,
		["oh"] = v94.Y - v91.Position.Y,
		["oo"] = v94.Z - v91.Position.Z
	}
	local v96 = nil
	local v97
	if v93 and v93.aimPlanePoint then
		local v98 = v93.aimPlanePoint
		local v99
		v99, v97 = pcall(v98)
		if v99 then
			if typeof(v97) ~= "Vector3" then
				v97 = v96
			end
		else
			v97 = v96
		end
	else
		v97 = v96
	end
	if v97 then
		local v100 = v97.X - v91.Position.X
		local v101 = v97.Z - v91.Position.Z
		v95.aim = math.atan2(v100, v101)
	else
		local v102 = v91.CFrame.LookVector
		local v103 = v102.X
		local v104 = v102.Z
		v95.aim = math.atan2(v103, v104)
	end
	local v105 = v90:GetAttribute("Ammo")
	local v106 = v90:GetAttribute("AmmoReserve")
	local v107 = v90:GetAttribute("Weapon")
	if type(v105) == "number" then
		v95.ammo = v105
	end
	if type(v106) == "number" then
		v95.reserve = v106
	end
	if type(v107) == "string" and v107 ~= "" then
		v95.weapon = v107
	end
	return v95
end
local v_u_109 = false
function v_u_42.startWatchStream(p_u_110) -- name: startWatchStream
	-- upvalues: (ref) v_u_109, (copy) v_u_1, (copy) v_u_2, (copy) v_u_42, (copy) v_u_3, (copy) v_u_108
	if not v_u_109 then
		v_u_109 = true
		local v_u_111 = v_u_1.LocalPlayer
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_42, (ref) v_u_3, (ref) v_u_108, (copy) p_u_110, (copy) v_u_111
			local v_u_112 = v_u_2:WaitForChild("HushNet", 30)
			if v_u_112 then
				v_u_112 = v_u_112:WaitForChild(v_u_42.WATCH_REMOTE, 60)
			end
			if v_u_112 and (v_u_112:IsA("UnreliableRemoteEvent") or v_u_112:IsA("RemoteEvent")) then
				local v_u_113 = nil
				local v_u_114 = 0
				local v_u_115 = 0
				local function v_u_123(p116) -- name: setOn
					-- upvalues: (ref) v_u_113, (ref) v_u_114, (ref) v_u_3, (ref) v_u_42, (ref) v_u_108, (ref) p_u_110, (ref) v_u_115, (copy) v_u_112
					if p116 and v_u_113 == nil then
						v_u_114 = 0
						v_u_113 = v_u_3.Heartbeat:Connect(function(p117)
							-- upvalues: (ref) v_u_114, (ref) v_u_42, (ref) v_u_108, (ref) p_u_110, (ref) v_u_115, (ref) v_u_112
							v_u_114 = v_u_114 + p117
							local v118 = 1 / v_u_42.WATCH_HZ
							if v_u_114 >= v118 then
								local v119 = v_u_114 - v118
								v_u_114 = math.min(v119, v118)
								local function v122()
									-- upvalues: (ref) v_u_108, (ref) p_u_110, (ref) v_u_42, (ref) v_u_115, (ref) v_u_112
									local v120 = v_u_108(p_u_110)
									local v121
									if v120 then
										v121 = v_u_42.watchPacket(v120, v_u_115)
									else
										v121 = nil
									end
									if v121 then
										v_u_115 = (v_u_115 + 1) % 65536
										v_u_112:FireServer(v121)
									end
								end
								pcall(v122)
							end
						end)
					elseif not p116 and v_u_113 ~= nil then
						v_u_113:Disconnect()
						v_u_113 = nil
					end
				end
				v_u_123(v_u_111:GetAttribute("Watched") == true)
				v_u_111:GetAttributeChangedSignal("Watched"):Connect(function()
					-- upvalues: (copy) v_u_123, (ref) v_u_111
					v_u_123(v_u_111:GetAttribute("Watched") == true)
				end)
			end
		end)
	end
end
local v_u_124 = false
function v_u_42.start(p_u_125) -- name: start
	-- upvalues: (ref) v_u_124, (copy) v_u_42, (copy) v_u_1, (copy) v_u_2, (copy) v_u_82, (copy) v_u_3
	if not v_u_124 then
		v_u_124 = true
		v_u_42.startWatchStream(p_u_125)
		local v_u_126 = v_u_1.LocalPlayer
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_42, (copy) v_u_126
			local v127 = v_u_2:WaitForChild("HushNet", 30)
			if v127 then
				v127 = v127:WaitForChild("priv.attrs", 30)
			end
			if v127 and v127:IsA("RemoteEvent") then
				v127.OnClientEvent:Connect(function(p_u_128)
					-- upvalues: (ref) v_u_42, (ref) v_u_126
					local function v129()
						-- upvalues: (ref) v_u_42, (copy) p_u_128, (ref) v_u_126
						v_u_42.applyPrivate(p_u_128)
						v_u_42.pushPrivate(v_u_126.Character)
					end
					pcall(v129)
				end)
				while true do
					task.wait(0.1)
					local function v130()
						-- upvalues: (ref) v_u_42, (ref) v_u_126
						v_u_42.pushPrivate(v_u_126.Character)
					end
					pcall(v130)
				end
			else
				return
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_42, (copy) p_u_125, (copy) v_u_126, (ref) v_u_2, (ref) v_u_82, (ref) v_u_3
			task.wait(3 + math.random() * 2)
			while true do
				task.wait(v_u_42.PERIOD)
				local function v133()
					-- upvalues: (ref) p_u_125, (ref) v_u_126, (ref) v_u_2, (ref) v_u_42, (ref) v_u_82, (ref) v_u_3
					if p_u_125.config.flag("AntiCheat") == "off" or v_u_126:GetAttribute("Place") ~= "Raid" then
						return
					else
						local v131 = v_u_2:FindFirstChild("HushNet")
						if v131 then
							v131 = v131:FindFirstChild(v_u_42.REMOTE)
						end
						if v131 and v131:IsA("RemoteEvent") then
							local v132 = v_u_42.merge(v_u_82(v_u_3.Heartbeat, p_u_125), (v_u_82(v_u_3.RenderStepped, p_u_125)))
							if v132 then
								v131:FireServer(v132)
							end
						end
					end
				end
				pcall(v133)
			end
		end)
	end
end
return v_u_42