-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRotationCard

local v1 = {}
local v2, v_u_3 = pcall(function()
	return require(script.Parent:FindFirstChild("ServerClock"))
end)
if not v2 or type(v_u_3) ~= "table" then
	v_u_3 = nil
end
local function v_u_4() -- name: serverNow
	-- upvalues: (ref) v_u_3
	if v_u_3 then
		return v_u_3.now()
	else
		return os.time()
	end
end
function v1.build(p_u_5, p6, p7) -- name: build
	-- upvalues: (copy) v_u_4
	local v_u_8 = p7 or {}
	local v_u_9 = p_u_5.ui
	local v_u_10 = p_u_5.theme
	local v_u_11 = v_u_10.color
	local v_u_12 = p_u_5.cctx.lib.MenuRotationLayout
	local v_u_13 = nil
	local function v14()
		-- upvalues: (ref) v_u_13, (copy) p_u_5
		v_u_13 = p_u_5.cctx.lib.TextFitting
	end
	pcall(v14)
	local v15 = v_u_8.now
	local v_u_16
	if type(v15) == "function" then
		v_u_16 = v_u_8.now
	else
		v_u_16 = v_u_4
	end
	local v_u_17 = {}
	local v18 = v_u_8.w
	local v19 = tonumber(v18) or 440
	local v20 = v_u_8.phone
	if v20 == nil then
		local v21 = v_u_10.isPhone
		if type(v21) == "function" then
			v20 = v_u_10.isPhone() == true
		else
			v20 = false
		end
	end
	local v22 = {
		["phone"] = v20 == true,
		["compact"] = v_u_8.compact == true
	}
	local v_u_23 = v_u_12.layout(v19, v22)
	local v_u_24 = {}
	local v_u_25 = v_u_9.new("Frame", {
		["Name"] = "RotationCard",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["Active"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.raised,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, 0),
		["Size"] = UDim2.new(1, 0, 0, v_u_23.h)
	}, p6)
	v_u_9.stroke(v_u_25, v_u_11.line)
	local v26 = v_u_9.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Active"] = false,
		["BackgroundColor3"] = v_u_11.accent,
		["Position"] = UDim2.fromOffset(v_u_23.edge.x, v_u_23.edge.y),
		["Size"] = UDim2.fromOffset(v_u_23.edge.w, v_u_23.edge.h)
	}, v_u_25)
	v_u_9.label({
		["parent"] = nil,
		["name"] = "Now",
		["text"] = nil,
		["style"] = "caps",
		["textSize"] = nil,
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_25,
		["text"] = v_u_12.TEXT.now,
		["textSize"] = v_u_23.sizes.now,
		["color"] = v_u_11.accent,
		["position"] = UDim2.fromOffset(v_u_23.now.x, v_u_23.now.y),
		["size"] = UDim2.fromOffset(v_u_23.now.w, v_u_23.now.h)
	})
	local v_u_27 = v_u_9.label({
		["parent"] = nil,
		["name"] = "MapName",
		["text"] = "",
		["style"] = "h1",
		["textSize"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_25,
		["textSize"] = v_u_23.sizes.name,
		["position"] = UDim2.fromOffset(v_u_23.name.x, v_u_23.name.y),
		["size"] = UDim2.fromOffset(v_u_23.name.w, v_u_23.name.h)
	})
	local v_u_28 = v_u_9.label({
		["parent"] = nil,
		["name"] = "NextLine",
		["text"] = "",
		["style"] = "small",
		["textSize"] = nil,
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_25,
		["textSize"] = v_u_23.sizes.next,
		["color"] = v_u_11.text2,
		["position"] = UDim2.fromOffset(v_u_23.next.x, v_u_23.next.y),
		["size"] = UDim2.fromOffset(v_u_23.next.w, v_u_23.next.h)
	})
	local v_u_29 = v_u_9.new("Frame", {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["Active"] = false,
		["BackgroundColor3"] = v_u_11.accentDeep,
		["Position"] = UDim2.fromOffset(v_u_23.badge.x, v_u_23.badge.y),
		["Size"] = UDim2.fromOffset(v_u_23.badge.w, v_u_23.badge.h)
	}, v_u_25)
	v_u_9.stroke(v_u_29, v_u_11.accentDim)
	local v_u_30 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "micro",
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["parent"] = v_u_29,
		["text"] = v_u_12.TEXT.byHand,
		["textSize"] = v_u_23.sizes.badge,
		["color"] = v_u_11.accent,
		["position"] = UDim2.fromOffset(4, 0),
		["size"] = UDim2.new(1, -8, 1, 0)
	})
	local v_u_31 = v_u_9.new("Frame", {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Active"] = false,
		["BackgroundColor3"] = v_u_11.line,
		["Position"] = UDim2.fromOffset(v_u_23.bar.x, v_u_23.bar.y),
		["Size"] = UDim2.fromOffset(v_u_23.bar.w, v_u_23.bar.h)
	}, v_u_25)
	local v_u_32 = v_u_9.new("Frame", {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Active"] = false,
		["BackgroundColor3"] = v_u_11.accent,
		["Size"] = UDim2.fromOffset(0, v_u_23.bar.h)
	}, v_u_31)
	pcall(function()
		-- upvalues: (copy) v_u_9, (copy) v_u_25, (copy) v_u_12, (copy) v_u_17
		v_u_9.tooltip(v_u_25, function()
			-- upvalues: (ref) v_u_12, (ref) v_u_17
			return v_u_12.tooltip(v_u_17.view)
		end)
	end)
	local v_u_33 = {}
	local v_u_34 = ""
	local v_u_35 = 0
	local v_u_36 = nil
	local v_u_37 = {
		["map"] = nil,
		["nextMap"] = nil,
		["forced"] = false,
		["left"] = nil,
		["nextLine"] = "",
		["name"] = ""
	}
	local function v_u_46(p38, p39, p40, p41, p42, p43) -- name: fit
		-- upvalues: (copy) v_u_33, (ref) v_u_13, (copy) v_u_12
		local v44 = p43 .. "|" .. tostring(p40)
		if v_u_33[p39] ~= v44 then
			v_u_33[p39] = v44
			if v_u_13 then
				local v45 = v_u_13.fit
				if type(v45) == "function" then
					p38.TextSize = p41
					p38:SetAttribute("FitFrom", p41)
					v_u_13.fit(p38, p40, p42)
					return
				end
			end
			p38.TextSize = v_u_12.nameFit(p43, p40, p41, p42)
		end
	end
	function v_u_17.set(p47) -- name: set
		-- upvalues: (copy) v_u_12, (copy) v_u_8, (ref) v_u_34, (ref) v_u_35, (copy) v_u_16, (copy) v_u_17
		local v48 = v_u_12.view(p47)
		if v48 ~= nil then
			local v49 = v_u_8.nameOf
			if type(v49) == "function" then
				v48 = v_u_12.localize(v48, v_u_8.nameOf)
			end
		end
		local v50 = v_u_12.sig(v48)
		if v50 ~= v_u_34 then
			v_u_34 = v50
			v_u_35 = v_u_16()
			v_u_17.view = v48
		end
		if v48 == nil then
			v_u_17.view = nil
		end
	end
	function v_u_17.paint(p51) -- name: paint
		-- upvalues: (copy) v_u_16, (copy) v_u_17, (copy) v_u_27, (copy) v_u_33, (copy) v_u_9, (copy) v_u_28, (copy) v_u_12, (copy) v_u_29, (copy) v_u_32, (copy) v_u_23, (ref) v_u_37, (ref) v_u_35, (copy) v_u_46, (copy) v_u_30, (copy) v_u_31, (ref) v_u_36, (copy) v_u_10, (copy) v_u_11
		if type(p51) ~= "number" then
			p51 = v_u_16()
		end
		local v52 = v_u_17.view
		if v52 == nil then
			local v53 = v_u_27
			if v_u_33.name ~= "" then
				v_u_33.name = ""
				v_u_9.setText(v53, "")
			end
			local v54 = v_u_28
			local v55 = v_u_12.TEXT.waiting
			if v_u_33.next ~= v55 then
				v_u_33.next = v55
				v_u_9.setText(v54, v55)
			end
			v_u_29.Visible = false
			v_u_32.Size = UDim2.fromOffset(0, v_u_23.bar.h)
			v_u_37 = {
				["map"] = nil,
				["nextMap"] = nil,
				["forced"] = false,
				["left"] = nil,
				["nextLine"] = nil,
				["name"] = "",
				["fillW"] = 0,
				["nextLine"] = v_u_12.TEXT.waiting
			}
		else
			local v56 = v_u_12.remaining(v52, p51, v_u_35)
			local v57 = 0
			local v58 = string.upper(v52.mapName)
			local v59 = v_u_27
			if v_u_33.name ~= v58 then
				v_u_33.name = v58
				v_u_9.setText(v59, v58)
			end
			v_u_46(v_u_27, "nameFit", v_u_23.name.w, v_u_23.sizes.name, v_u_23.sizes.nameMin, v58)
			local v60 = v_u_12.nextLine(v52, v56)
			if v52.forced then
				v_u_29.Visible = true
				local v61 = v_u_28
				if v_u_33.next ~= "" then
					v_u_33.next = ""
					v_u_9.setText(v61, "")
				end
				local v62 = v_u_30
				local v63 = v_u_12.badgeText(v52)
				if v_u_33.badge ~= v63 then
					v_u_33.badge = v63
					v_u_9.setText(v62, v63)
				end
				v_u_31.Visible = false
			else
				v_u_29.Visible = false
				v_u_31.Visible = true
				local v64 = v_u_28
				if v_u_33.next ~= v60 then
					v_u_33.next = v60
					v_u_9.setText(v64, v60)
				end
				v_u_46(v_u_28, "nextFit", v_u_23.next.w, v_u_23.sizes.next, v_u_23.sizes.next - 2, v60)
				v57 = v_u_12.fillRect(v_u_23, v_u_12.fill(v52, v56)).w
				v_u_32.Size = UDim2.fromOffset(v57, v_u_23.bar.h)
			end
			if v_u_36 ~= nil and v_u_36 ~= v52.map then
				local v65 = v_u_10.reduced
				if type(v65) ~= "function" or not v_u_10.reduced() then
					v_u_27.TextColor3 = v_u_11.accent
					v_u_9.tween(v_u_27, {
						["TextColor3"] = v_u_11.text
					}, 0.8)
				end
			end
			v_u_36 = v52.map
			v_u_37 = {
				["map"] = v52.map,
				["nextMap"] = v52.nextMap,
				["forced"] = v52.forced,
				["left"] = v56,
				["nextLine"] = v60,
				["name"] = v58,
				["fillW"] = v57
			}
			local v66 = "map=%s next=%s forced=%d left=%s"
			local v67 = v52.map
			local v68 = tostring(v67)
			local v69 = v52.nextMap
			local v70 = tostring(v69)
			local v71 = v52.forced and 1 or 0
			local v72
			if v56 then
				local v73 = math.floor(v56)
				v72 = tostring(v73)
			else
				v72 = "?"
			end
			local v_u_74 = v66:format(v68, v70, v71, v72)
			if v_u_33.hook ~= v_u_74 then
				v_u_33.hook = v_u_74
				pcall(function()
					-- upvalues: (copy) v_u_74
					game:GetService("Players").LocalPlayer:SetAttribute("MenuRotation", v_u_74)
				end)
			end
		end
	end
	function v_u_17.place(p75) -- name: place
		-- upvalues: (copy) v_u_25, (copy) v_u_12, (copy) v_u_23
		v_u_25.AnchorPoint = Vector2.new(0, 1)
		v_u_25.Position = UDim2.new(0, 0, 1, -((tonumber(p75) or 0) + v_u_12.GAP))
		v_u_25.Size = UDim2.new(1, 0, 0, v_u_23.h)
	end
	function v_u_17.height() -- name: height
		-- upvalues: (copy) v_u_23
		return v_u_23.h
	end
	function v_u_17.band() -- name: band
		-- upvalues: (copy) v_u_23, (copy) v_u_12
		return v_u_23.h + v_u_12.GAP
	end
	function v_u_17.layout() -- name: layout
		-- upvalues: (copy) v_u_23
		return v_u_23
	end
	function v_u_17.state() -- name: state
		-- upvalues: (ref) v_u_37
		return v_u_37
	end
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (copy) v_u_24, (copy) v_u_25
		for _, v_u_76 in v_u_24 do
			pcall(function()
				-- upvalues: (copy) v_u_76
				v_u_76:Disconnect()
			end)
		end
		table.clear(v_u_24)
		local function v77()
			-- upvalues: (ref) v_u_25
			v_u_25:Destroy()
		end
		pcall(v77)
	end
	v_u_17.frame = v_u_25
	v_u_17.edge = v26
	v_u_17.nameLabel = v_u_27
	v_u_17.nextLabel = v_u_28
	v_u_17.badge = v_u_29
	v_u_17.bar = v_u_31
	v_u_17.fill = v_u_32
	v_u_17.view = nil
	return v_u_25, v_u_17
end
return v1