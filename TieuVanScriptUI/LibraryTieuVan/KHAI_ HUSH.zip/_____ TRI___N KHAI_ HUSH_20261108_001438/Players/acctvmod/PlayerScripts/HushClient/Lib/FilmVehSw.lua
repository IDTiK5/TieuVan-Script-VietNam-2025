-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmVehSw

local v_u_239 = {
	["ARM_S"] = 5,
	["MAX_LINES"] = 14,
	["TEXT"] = {
		["section"] = "Vehicles  |  all servers",
		["on"] = "VEHICLES ON",
		["confirm"] = "TAP AGAIN: ON",
		["off"] = "VEHICLES OFF",
		["default"] = "FOLLOW BUILD",
		["animOn"] = "BOARD ANIM ON",
		["animOff"] = "BOARD ANIM OFF",
		["armed"] = "Tap VEHICLES ON again within 5 seconds to switch the vehicles on in every server. The moderator on the Spark must know the vehicle codes first.",
		["spawn"] = "Spawn a car  |  this raid",
		["spawnNote"] = "Spawns the car 16 studs in front of you through the normal vehicle path. HOW TO START A CAR: sit in the driver seat, the hotwire starts at once, hit the Spark key (shown on the card) when the pointer is in the green zone; a miss costs nothing, just try again. PRE-WIRED skips the game, the engine starts as soon as you sit down. ALARM adds an alarm system that rings once when you sit down at a car that is not pre-wired. FULL TANK fills the tank. Needs vehicles ON in this server, owners only. The raid is not saved afterwards.",
		["note"] = "All buttons reach every server within a minute. OFF is the emergency brake: riders get out within 3 seconds, no new vehicles, the parked cars stay as cover. FOLLOW BUILD gives the decision back to Config.FLAGS.Vehicles. BOARD ANIM only switches the get in and get out animation."
	},
	["SPAWN_TYPES"] = {
		{
			["id"] = "Pickup",
			["label"] = "PICKUP"
		},
		{
			["id"] = "Supercar",
			["label"] = "VANTREL ECHO"
		},
		{
			["id"] = "Kart",
			["label"] = "KART"
		}
	},
	["spawnRequest"] = function(p1, p2) -- name: spawnRequest
		local v3 = type(p2) ~= "table" and {} or p2
		local v4 = {
			["type"] = p1
		}
		if v3.wired == true then
			v4.wired = true
		end
		if v3.alarm == true then
			v4.alarm = true
		end
		if v3.full == false then
			v4.full = false
		end
		return v4
	end,
	["optionText"] = function(p5, p6) -- name: optionText
		return (({
			["wired"] = "PRE-WIRED",
			["alarm"] = "ALARM",
			["full"] = "FULL TANK"
		})[p5] or string.upper(p5)) .. ": " .. (p6 and "ON" or "OFF")
	end,
	["armed"] = function(p7, p8) -- name: armed
		-- upvalues: (copy) v_u_239
		local v9
		if type(p7) == "number" and (type(p8) == "number" and (p7 == p7 and p7 <= p8)) then
			v9 = p8 - p7 <= v_u_239.ARM_S
		else
			v9 = false
		end
		return v9
	end,
	["lines"] = function(p10) -- name: lines
		-- upvalues: (copy) v_u_239
		local v11 = {}
		if type(p10) ~= "table" then
			table.insert(v11, {
				["name"] = "State",
				["text"] = "Reading the vehicle switch ...",
				["kind"] = "muted"
			})
			return v11
		end
		local v12 = p10.enabled == true
		table.insert(v11, {
			["name"] = "Effect",
			["text"] = nil,
			["kind"] = nil,
			["text"] = v12 and "Vehicles: ON in this server" or "Vehicles: OFF in this server",
			["kind"] = v12 and "ok" or "warn"
		})
		local v13 = p10.missing
		local v14 = type(v13) ~= "table" and {} or p10.missing
		if #v14 > 0 then
			local v15 = {}
			for v16, v17 in v14 do
				if v16 > 6 then
					local v18 = #v14 - 6
					table.insert(v15, ("and %d more"):format(v18))
					break
				end
				local v19 = tostring(v17)
				table.insert(v15, v19)
			end
			local v20 = {
				["name"] = "Lock",
				["text"] = nil,
				["kind"] = "warn",
				["text"] = "Lock closed, missing: " .. table.concat(v15, ", ")
			}
			table.insert(v11, v20)
		end
		local v21 = p10.lines
		local v22 = type(v21) ~= "table" and {} or p10.lines
		for v23, v24 in v22 do
			if v_u_239.MAX_LINES < v23 then
				local v25 = {
					["name"] = "More",
					["text"] = nil,
					["kind"] = "muted",
					["text"] = ("%d more lines in veh.status"):format(#v22 - v_u_239.MAX_LINES)
				}
				table.insert(v11, v25)
				return v11
			end
			local v26 = {
				["name"] = "Line" .. tostring(v23),
				["text"] = tostring(v24),
				["kind"] = v23 == 1 and "text" or "muted"
			}
			table.insert(v11, v26)
		end
		return v11
	end,
	["mount"] = function(p_u_27, p_u_28, p29, p30) -- name: mount
		-- upvalues: (copy) v_u_239
		local v_u_31 = require(script.Parent:WaitForChild("HushUI"))
		local v32 = game:GetService("Players")
		local v33 = game:GetService("RunService")
		local v_u_34 = v32.LocalPlayer
		local v_u_35 = type(p30) ~= "table" and {} or p30
		if type(p29) == "table" then
			local v36 = p29.color
			if type(v36) ~= "table" then
				p29 = v_u_31.Theme
			end
		else
			p29 = v_u_31.Theme
		end
		local v_u_37 = p29.color
		local v_u_38 = v_u_35.gui
		local v_u_39 = 0
		local v_u_40 = true
		if v_u_38 then
			v_u_38.Destroying:Connect(function()
				-- upvalues: (ref) v_u_40
				v_u_40 = false
			end)
		end
		local v41 = v_u_31.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p_u_27,
			["text"] = v_u_239.TEXT.section,
			["color"] = v_u_37.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v42 = v_u_35.order
		local v43
		if type(v42) == "function" then
			v43 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v43 = v_u_39
		end
		v41.LayoutOrder = v43
		local v_u_44 = v_u_31.new("Frame", {
			["Name"] = "VehSwList",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p_u_27)
		v_u_31.layout(v_u_44, "v", 2)
		local v45 = v_u_35.order
		local v46
		if type(v45) == "function" then
			v46 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v46 = v_u_39
		end
		v_u_44.LayoutOrder = v46
		local v_u_47 = nil
		local v_u_48 = false
		local v_u_49 = (-1 / 0)
		local v_u_50 = nil
		local v_u_51 = nil
		local v_u_52 = nil
		local v_u_53 = nil
		local function v_u_59() -- name: refresh
			-- upvalues: (ref) v_u_48, (copy) p_u_28, (copy) v_u_35, (ref) v_u_40, (ref) v_u_49, (ref) v_u_47, (ref) v_u_53
			if not v_u_48 then
				local v54 = p_u_28
				if type(v54) == "function" then
					v_u_48 = true
					local v55 = v_u_35.sendQuiet
					local v56
					if type(v55) == "function" then
						v56 = v_u_35.sendQuiet
					else
						v56 = p_u_28
					end
					v56("veh.status", {}, function(p57)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_49, (ref) v_u_47, (ref) v_u_53
						v_u_48 = false
						if v_u_40 then
							v_u_49 = os.clock()
							if type(p57) == "table" then
								local v58 = p57.data
								if type(v58) == "table" then
									v_u_47 = p57.data
								end
							end
							v_u_53(v_u_47)
						end
					end)
					return
				end
			end
		end
		local function v_u_80(p60) -- name: pressOn
			-- upvalues: (ref) v_u_239, (ref) v_u_50, (ref) v_u_52, (ref) v_u_48, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
			local v61 = os.clock()
			if p60 or v_u_239.armed(v_u_50, v61) then
				v_u_50 = nil
				local v62 = v_u_239.TEXT.on
				if v_u_52 ~= nil then
					local v63 = v_u_52.setText
					if type(v63) == "function" then
						local v64 = v_u_52.setText
						pcall(v64, v62)
					end
				end
				local v65 = {
					["cmd"] = "set",
					["value"] = "on",
					["confirm"] = true
				}
				if not v_u_48 then
					local v66 = p_u_28
					if type(v66) ~= "function" then
						return
					end
					v_u_48 = true
					v_u_31.setText(v_u_51, "Working ...")
					v_u_51.TextColor3 = v_u_37.text2
					p_u_28("veh.switch", v65, function(p67)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
						v_u_48 = false
						if v_u_40 then
							if type(p67) == "table" then
								local v68 = p67.msg or (p67.ok and "Done." or "Refused.")
								local v69 = tostring(v68)
								local v70 = p67.ok ~= true
								v_u_31.setText(v_u_51, v69)
								local v71 = v_u_51
								local v72
								if v70 then
									v72 = v_u_37.danger
								else
									v72 = v_u_37.text2
								end
								v71.TextColor3 = v72
							else
								v_u_31.setText(v_u_51, "The server did not answer.")
								v_u_51.TextColor3 = v_u_37.danger
							end
							v_u_59()
						end
					end)
				end
			else
				v_u_50 = v61
				local v73 = v_u_239.TEXT.confirm
				if v_u_52 ~= nil then
					local v74 = v_u_52.setText
					if type(v74) == "function" then
						local v75 = v_u_52.setText
						pcall(v75, v73)
					end
				end
				local v76 = v_u_239.TEXT.armed
				v_u_31.setText(v_u_51, v76)
				v_u_51.TextColor3 = v_u_37.text2
				task.delay(v_u_239.ARM_S + 0.1, function()
					-- upvalues: (ref) v_u_40, (ref) v_u_50, (ref) v_u_239, (ref) v_u_52
					if v_u_40 and (v_u_50 ~= nil and not v_u_239.armed(v_u_50, os.clock())) then
						v_u_50 = nil
						local v77 = v_u_239.TEXT.on
						if v_u_52 ~= nil then
							local v78 = v_u_52.setText
							if type(v78) == "function" then
								local v79 = v_u_52.setText
								pcall(v79, v77)
							end
						end
					end
				end)
			end
		end
		local function v85(p81) -- name: row
			-- upvalues: (copy) v_u_31, (copy) p_u_27, (copy) v_u_35, (ref) v_u_39
			local v82 = v_u_31.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Name"] = p81,
				["Size"] = UDim2.new(1, 0, 0, 40)
			}, p_u_27)
			v_u_31.layout(v82, "h", 6)
			local v83 = v_u_35.order
			local v84
			if type(v83) == "function" then
				v84 = v_u_35.order()
			else
				v_u_39 = v_u_39 + 1
				v84 = v_u_39
			end
			v82.LayoutOrder = v84
			return v82
		end
		local v86 = v85("VehSwRow")
		local v87 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 36,
			["width"] = 150,
			["maxTextWidth"] = 126,
			["onClick"] = nil,
			["parent"] = v86,
			["text"] = v_u_239.TEXT.on,
			["onClick"] = function()
				-- upvalues: (copy) v_u_80
				v_u_80(false)
			end
		}
		local v88, v89 = v_u_31.button(v87)
		v88.Name = "VehSwOn"
		v88.LayoutOrder = 1
		v_u_52 = v89
		local v101 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "danger",
			["height"] = 36,
			["width"] = 150,
			["maxTextWidth"] = 126,
			["onClick"] = nil,
			["parent"] = v86,
			["text"] = v_u_239.TEXT.off,
			["onClick"] = function()
				-- upvalues: (ref) v_u_50, (ref) v_u_239, (ref) v_u_52, (ref) v_u_48, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
				v_u_50 = nil
				local v90 = v_u_239.TEXT.on
				if v_u_52 ~= nil then
					local v91 = v_u_52.setText
					if type(v91) == "function" then
						local v92 = v_u_52.setText
						pcall(v92, v90)
					end
				end
				local v93 = {
					["cmd"] = "set",
					["value"] = "off"
				}
				if not v_u_48 then
					local v94 = p_u_28
					if type(v94) ~= "function" then
						return
					end
					v_u_48 = true
					v_u_31.setText(v_u_51, "Working ...")
					v_u_51.TextColor3 = v_u_37.text2
					p_u_28("veh.switch", v93, function(p95)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
						v_u_48 = false
						if v_u_40 then
							if type(p95) == "table" then
								local v96 = p95.msg or (p95.ok and "Done." or "Refused.")
								local v97 = tostring(v96)
								local v98 = p95.ok ~= true
								v_u_31.setText(v_u_51, v97)
								local v99 = v_u_51
								local v100
								if v98 then
									v100 = v_u_37.danger
								else
									v100 = v_u_37.text2
								end
								v99.TextColor3 = v100
							else
								v_u_31.setText(v_u_51, "The server did not answer.")
								v_u_51.TextColor3 = v_u_37.danger
							end
							v_u_59()
						end
					end)
				end
			end
		}
		local v102, _ = v_u_31.button(v101)
		v102.Name = "VehSwOff"
		v102.LayoutOrder = 2
		local v114 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 36,
			["width"] = 150,
			["maxTextWidth"] = 126,
			["onClick"] = nil,
			["parent"] = v86,
			["text"] = v_u_239.TEXT.default,
			["onClick"] = function()
				-- upvalues: (ref) v_u_50, (ref) v_u_239, (ref) v_u_52, (ref) v_u_48, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
				v_u_50 = nil
				local v103 = v_u_239.TEXT.on
				if v_u_52 ~= nil then
					local v104 = v_u_52.setText
					if type(v104) == "function" then
						local v105 = v_u_52.setText
						pcall(v105, v103)
					end
				end
				local v106 = {
					["cmd"] = "set",
					["value"] = "default"
				}
				if not v_u_48 then
					local v107 = p_u_28
					if type(v107) ~= "function" then
						return
					end
					v_u_48 = true
					v_u_31.setText(v_u_51, "Working ...")
					v_u_51.TextColor3 = v_u_37.text2
					p_u_28("veh.switch", v106, function(p108)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
						v_u_48 = false
						if v_u_40 then
							if type(p108) == "table" then
								local v109 = p108.msg or (p108.ok and "Done." or "Refused.")
								local v110 = tostring(v109)
								local v111 = p108.ok ~= true
								v_u_31.setText(v_u_51, v110)
								local v112 = v_u_51
								local v113
								if v111 then
									v113 = v_u_37.danger
								else
									v113 = v_u_37.text2
								end
								v112.TextColor3 = v113
							else
								v_u_31.setText(v_u_51, "The server did not answer.")
								v_u_51.TextColor3 = v_u_37.danger
							end
							v_u_59()
						end
					end)
				end
			end
		}
		local v115, _ = v_u_31.button(v114)
		v115.Name = "VehSwDefault"
		v115.LayoutOrder = 3
		local v116 = v85("VehAnimRow")
		local v125 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 36,
			["width"] = 170,
			["maxTextWidth"] = 146,
			["onClick"] = nil,
			["parent"] = v116,
			["text"] = v_u_239.TEXT.animOn,
			["onClick"] = function()
				-- upvalues: (ref) v_u_48, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
				local v117 = {
					["cmd"] = "set",
					["value"] = "on"
				}
				if not v_u_48 then
					local v118 = p_u_28
					if type(v118) ~= "function" then
						return
					end
					v_u_48 = true
					v_u_31.setText(v_u_51, "Working ...")
					v_u_51.TextColor3 = v_u_37.text2
					p_u_28("veh.anim", v117, function(p119)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
						v_u_48 = false
						if v_u_40 then
							if type(p119) == "table" then
								local v120 = p119.msg or (p119.ok and "Done." or "Refused.")
								local v121 = tostring(v120)
								local v122 = p119.ok ~= true
								v_u_31.setText(v_u_51, v121)
								local v123 = v_u_51
								local v124
								if v122 then
									v124 = v_u_37.danger
								else
									v124 = v_u_37.text2
								end
								v123.TextColor3 = v124
							else
								v_u_31.setText(v_u_51, "The server did not answer.")
								v_u_51.TextColor3 = v_u_37.danger
							end
							v_u_59()
						end
					end)
				end
			end
		}
		local v126, _ = v_u_31.button(v125)
		v126.Name = "VehAnimOn"
		v126.LayoutOrder = 1
		local v135 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 36,
			["width"] = 170,
			["maxTextWidth"] = 146,
			["onClick"] = nil,
			["parent"] = v116,
			["text"] = v_u_239.TEXT.animOff,
			["onClick"] = function()
				-- upvalues: (ref) v_u_48, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
				local v127 = {
					["cmd"] = "set",
					["value"] = "off"
				}
				if not v_u_48 then
					local v128 = p_u_28
					if type(v128) ~= "function" then
						return
					end
					v_u_48 = true
					v_u_31.setText(v_u_51, "Working ...")
					v_u_51.TextColor3 = v_u_37.text2
					p_u_28("veh.anim", v127, function(p129)
						-- upvalues: (ref) v_u_48, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
						v_u_48 = false
						if v_u_40 then
							if type(p129) == "table" then
								local v130 = p129.msg or (p129.ok and "Done." or "Refused.")
								local v131 = tostring(v130)
								local v132 = p129.ok ~= true
								v_u_31.setText(v_u_51, v131)
								local v133 = v_u_51
								local v134
								if v132 then
									v134 = v_u_37.danger
								else
									v134 = v_u_37.text2
								end
								v133.TextColor3 = v134
							else
								v_u_31.setText(v_u_51, "The server did not answer.")
								v_u_51.TextColor3 = v_u_37.danger
							end
							v_u_59()
						end
					end)
				end
			end
		}
		local v136, _ = v_u_31.button(v135)
		v136.Name = "VehAnimOff"
		v136.LayoutOrder = 2
		local v137 = v_u_31.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p_u_27,
			["text"] = v_u_239.TEXT.spawn,
			["color"] = v_u_37.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v138 = v_u_35.order
		local v139
		if type(v138) == "function" then
			v139 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v139 = v_u_39
		end
		v137.LayoutOrder = v139
		local v_u_140 = {
			["wired"] = false,
			["alarm"] = false,
			["full"] = true
		}
		local function v_u_142(p141) -- name: optText
			-- upvalues: (ref) v_u_239, (copy) v_u_140
			return v_u_239.optionText(p141, v_u_140[p141] == true)
		end
		local v143 = v85("VehSpawnRow")
		local v_u_144 = v_u_47
		local v_u_145 = v_u_49
		local v_u_146 = v_u_52
		local v_u_147 = v_u_50
		local v_u_148 = v_u_51
		local v_u_149 = v_u_48
		local v_u_150 = {}
		for v151, v_u_152 in v_u_239.SPAWN_TYPES do
			local v153 = "VehSpawn" .. v_u_152.id
			local v163 = {
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 36,
				["width"] = 110,
				["maxTextWidth"] = 86,
				["onClick"] = nil,
				["parent"] = v143,
				["text"] = v_u_152.label,
				["onClick"] = function()
					-- upvalues: (copy) v_u_152, (ref) v_u_239, (copy) v_u_140, (ref) v_u_149, (copy) p_u_28, (copy) v_u_31, (ref) v_u_148, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59
					local v154 = v_u_152.id
					local v155 = v_u_239.spawnRequest(v154, v_u_140)
					if not v_u_149 then
						local v156 = p_u_28
						if type(v156) ~= "function" then
							return
						end
						v_u_149 = true
						v_u_31.setText(v_u_148, "Working ...")
						v_u_148.TextColor3 = v_u_37.text2
						p_u_28("veh.spawn", v155, function(p157)
							-- upvalues: (ref) v_u_149, (ref) v_u_40, (ref) v_u_31, (ref) v_u_148, (ref) v_u_37, (ref) v_u_59
							v_u_149 = false
							if v_u_40 then
								if type(p157) == "table" then
									local v158 = p157.msg or (p157.ok and "Done." or "Refused.")
									local v159 = tostring(v158)
									local v160 = p157.ok ~= true
									v_u_31.setText(v_u_148, v159)
									local v161 = v_u_148
									local v162
									if v160 then
										v162 = v_u_37.danger
									else
										v162 = v_u_37.text2
									end
									v161.TextColor3 = v162
								else
									v_u_31.setText(v_u_148, "The server did not answer.")
									v_u_148.TextColor3 = v_u_37.danger
								end
								v_u_59()
							end
						end)
					end
				end
			}
			local v164, _ = v_u_31.button(v163)
			v164.Name = v153
			v164.LayoutOrder = v151
		end
		local v165 = v85("VehSpawnOptRow")
		for v166, v_u_167 in { "wired", "alarm", "full" } do
			local v168 = "VehSpawnOpt_" .. v_u_167
			local v172 = {
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 36,
				["width"] = 110,
				["maxTextWidth"] = 86,
				["onClick"] = nil,
				["parent"] = v165,
				["text"] = v_u_239.optionText(v_u_167, v_u_140[v_u_167] == true),
				["onClick"] = function()
					-- upvalues: (copy) v_u_140, (copy) v_u_167, (copy) v_u_150, (copy) v_u_142
					v_u_140[v_u_167] = not v_u_140[v_u_167]
					local v169 = v_u_150[v_u_167].setText
					local v170 = v_u_142
					local v171 = v_u_167
					pcall(v169, v170(v171))
				end
			}
			local v173, v174 = v_u_31.button(v172)
			v173.Name = v168
			v173.LayoutOrder = v166
			v_u_150[v_u_167] = v174
		end
		v_u_51 = v_u_31.label({
			["parent"] = nil,
			["name"] = "VehSwStatus",
			["text"] = "Open to read.",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_27,
			["color"] = v_u_37.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v175 = v_u_35.order
		local v176
		if type(v175) == "function" then
			v176 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v176 = v_u_39
		end
		v_u_51.LayoutOrder = v176
		local v177 = v_u_31.label({
			["parent"] = nil,
			["name"] = "VehSpawnNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_27,
			["text"] = v_u_239.TEXT.spawnNote,
			["color"] = v_u_37.muted,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v178 = v_u_35.order
		local v179
		if type(v178) == "function" then
			v179 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v179 = v_u_39
		end
		v177.LayoutOrder = v179
		local v180 = v_u_31.label({
			["parent"] = nil,
			["name"] = "VehSwNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_27,
			["text"] = v_u_239.TEXT.note,
			["color"] = v_u_37.muted,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v181 = v_u_35.order
		local v182
		if type(v181) == "function" then
			v182 = v_u_35.order()
		else
			v_u_39 = v_u_39 + 1
			v182 = v_u_39
		end
		v180.LayoutOrder = v182
		v_u_53 = function(p183)
			-- upvalues: (copy) v_u_44, (ref) v_u_239, (copy) v_u_37, (copy) v_u_31, (copy) v_u_34
			for _, v184 in v_u_44:GetChildren() do
				if not v184:IsA("GuiObject") then
					continue
				end
				v184:Destroy()
			end
			for v185, v186 in v_u_239.lines(p183) do
				local v187
				if v186.kind == "ok" then
					v187 = v_u_37.success
				elseif v186.kind == "warn" then
					v187 = v_u_37.danger
				elseif v186.kind == "muted" then
					v187 = v_u_37.muted
				else
					v187 = v_u_37.text2
				end
				local v188 = v_u_31.label
				local v189 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_44
				}
				local v190 = v186.name
				v189.name = "VehSwLine_" .. tostring(v190)
				local v191 = v186.text
				v189.text = tostring(v191)
				v189.color = v187
				v189.size = UDim2.new(1, 0, 0, 0)
				v188(v189).LayoutOrder = v185
			end
			local v192 = type(p183) ~= "table" and {} or p183
			if v_u_34 then
				local v193 = v192.missing
				local v194 = type(v193) == "table" and #v192.missing or 0
				local v195 = v192.lines
				local v196 = type(v195) == "table" and #v192.lines or 0
				v_u_34:SetAttribute("FilmVehSw", ("eff=%d|miss=%d|n=%d"):format(v192.enabled == true and 1 or 0, v194, v196))
			end
		end
		v_u_53(nil)
		if v33:IsStudio() and v_u_34 then
			local v_u_235 = v_u_34:GetAttributeChangedSignal("FilmVehCmd"):Connect(function()
				-- upvalues: (copy) v_u_34, (ref) v_u_147, (ref) v_u_239, (ref) v_u_146, (ref) v_u_149, (copy) p_u_28, (copy) v_u_31, (ref) v_u_51, (copy) v_u_37, (ref) v_u_40, (copy) v_u_59, (copy) v_u_140
				local v197 = v_u_34:GetAttribute("FilmVehCmd")
				if type(v197) == "string" and v197 ~= "" then
					v_u_34:SetAttribute("FilmVehCmd", nil)
					if v197 == "on" then
						os.clock()
						v_u_147 = nil
						local v198 = v_u_239.TEXT.on
						if v_u_146 ~= nil then
							local v199 = v_u_146.setText
							if type(v199) == "function" then
								local v200 = v_u_146.setText
								pcall(v200, v198)
							end
						end
						local v201 = {
							["cmd"] = "set",
							["value"] = "on",
							["confirm"] = true
						}
						if not v_u_149 then
							local v202 = p_u_28
							if type(v202) == "function" then
								v_u_149 = true
								v_u_31.setText(v_u_51, "Working ...")
								v_u_51.TextColor3 = v_u_37.text2
								p_u_28("veh.switch", v201, function(p203)
									-- upvalues: (ref) v_u_149, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
									v_u_149 = false
									if v_u_40 then
										if type(p203) == "table" then
											local v204 = p203.msg or (p203.ok and "Done." or "Refused.")
											local v205 = tostring(v204)
											local v206 = p203.ok ~= true
											v_u_31.setText(v_u_51, v205)
											local v207 = v_u_51
											local v208
											if v206 then
												v208 = v_u_37.danger
											else
												v208 = v_u_37.text2
											end
											v207.TextColor3 = v208
										else
											v_u_31.setText(v_u_51, "The server did not answer.")
											v_u_51.TextColor3 = v_u_37.danger
										end
										v_u_59()
									end
								end)
							end
						end
					elseif v197 == "off" or v197 == "default" then
						local v209 = {
							["cmd"] = "set",
							["value"] = nil,
							["value"] = v197
						}
						if not v_u_149 then
							local v210 = p_u_28
							if type(v210) == "function" then
								v_u_149 = true
								v_u_31.setText(v_u_51, "Working ...")
								v_u_51.TextColor3 = v_u_37.text2
								p_u_28("veh.switch", v209, function(p211)
									-- upvalues: (ref) v_u_149, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
									v_u_149 = false
									if v_u_40 then
										if type(p211) == "table" then
											local v212 = p211.msg or (p211.ok and "Done." or "Refused.")
											local v213 = tostring(v212)
											local v214 = p211.ok ~= true
											v_u_31.setText(v_u_51, v213)
											local v215 = v_u_51
											local v216
											if v214 then
												v216 = v_u_37.danger
											else
												v216 = v_u_37.text2
											end
											v215.TextColor3 = v216
										else
											v_u_31.setText(v_u_51, "The server did not answer.")
											v_u_51.TextColor3 = v_u_37.danger
										end
										v_u_59()
									end
								end)
							end
						end
					elseif v197 == "anim_on" or v197 == "anim_off" then
						local v217 = {
							["cmd"] = "set",
							["value"] = nil,
							["value"] = v197 == "anim_on" and "on" or "off"
						}
						if not v_u_149 then
							local v218 = p_u_28
							if type(v218) == "function" then
								v_u_149 = true
								v_u_31.setText(v_u_51, "Working ...")
								v_u_51.TextColor3 = v_u_37.text2
								p_u_28("veh.anim", v217, function(p219)
									-- upvalues: (ref) v_u_149, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
									v_u_149 = false
									if v_u_40 then
										if type(p219) == "table" then
											local v220 = p219.msg or (p219.ok and "Done." or "Refused.")
											local v221 = tostring(v220)
											local v222 = p219.ok ~= true
											v_u_31.setText(v_u_51, v221)
											local v223 = v_u_51
											local v224
											if v222 then
												v224 = v_u_37.danger
											else
												v224 = v_u_37.text2
											end
											v223.TextColor3 = v224
										else
											v_u_31.setText(v_u_51, "The server did not answer.")
											v_u_51.TextColor3 = v_u_37.danger
										end
										v_u_59()
									end
								end)
							end
						end
					else
						if string.sub(v197, 1, 6) == "spawn_" then
							for _, v225 in v_u_239.SPAWN_TYPES do
								if string.lower(v225.id) ~= string.sub(v197, 7) then
									continue
								end
								local v226 = v225.id
								local v227 = v_u_239.spawnRequest(v226, v_u_140)
								if v_u_149 then
									continue
								end
								local v228 = p_u_28
								if type(v228) ~= "function" then
									continue
								end
								v_u_149 = true
								v_u_31.setText(v_u_51, "Working ...")
								v_u_51.TextColor3 = v_u_37.text2
								p_u_28("veh.spawn", v227, function(p229)
									-- upvalues: (ref) v_u_149, (ref) v_u_40, (ref) v_u_31, (ref) v_u_51, (ref) v_u_37, (ref) v_u_59
									v_u_149 = false
									if v_u_40 then
										if type(p229) == "table" then
											local v230 = p229.msg or (p229.ok and "Done." or "Refused.")
											local v231 = tostring(v230)
											local v232 = p229.ok ~= true
											v_u_31.setText(v_u_51, v231)
											local v233 = v_u_51
											local v234
											if v232 then
												v234 = v_u_37.danger
											else
												v234 = v_u_37.text2
											end
											v233.TextColor3 = v234
										else
											v_u_31.setText(v_u_51, "The server did not answer.")
											v_u_51.TextColor3 = v_u_37.danger
										end
										v_u_59()
									end
								end)
							end
							return
						end
						if v197 == "refresh" then
							v_u_59()
						end
					end
				end
			end)
			if v_u_38 then
				v_u_38.Destroying:Connect(function()
					-- upvalues: (copy) v_u_235
					v_u_235:Disconnect()
				end)
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_40, (copy) v_u_38, (copy) p_u_27, (ref) v_u_149, (ref) v_u_145, (copy) v_u_59
			local v236 = false
			while v_u_40 do
				local v237 = v_u_38 == nil or v_u_38.Enabled
				if v237 then
					v237 = p_u_27.Visible
				end
				if v237 and (not v_u_149 and (not v236 or os.clock() - v_u_145 >= 5)) then
					v_u_145 = os.clock()
					v_u_59()
				end
				task.wait(0.5)
				v236 = v237
			end
		end)
		return {
			["refresh"] = v_u_59,
			["paint"] = function(p238) -- name: paint
				-- upvalues: (ref) v_u_144, (ref) v_u_53
				v_u_144 = p238
				v_u_53(p238)
			end
		}
	end
}
return v_u_239