-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / PlayerOutlineBoot

local v_u_1 = game:GetService("Players")
local v2 = {
	["name"] = "PlayerOutlineBoot",
	["order"] = 77
}
local v_u_3 = nil
local v_u_4 = 0
local v_u_5 = v_u_1.LocalPlayer
function v2.init(p_u_6) -- name: init
	-- upvalues: (ref) v_u_3, (copy) v_u_5, (copy) v_u_1
	local function v47()
		-- upvalues: (copy) p_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_1
		local v_u_7 = p_u_6.lib.PlayerOutline
		local v_u_8 = p_u_6.shared.Config
		local v_u_9 = p_u_6.shared.GameMode
		local v_u_10 = {}
		local v_u_11 = nil
		local v45 = {
			["localPlayer"] = v_u_5,
			["cfg"] = function() -- name: cfg
				-- upvalues: (copy) v_u_8
				return {
					["enabled"] = v_u_8.OUTLINE_ENABLED == true,
					["range"] = v_u_8.OUTLINE_RANGE,
					["transparency"] = v_u_8.OUTLINE_TRANSPARENCY,
					["max"] = v_u_8.OUTLINE_MAX,
					["floor"] = v_u_8.OUTLINE_BRIGHT_FLOOR,
					["minVis"] = v_u_8.OUTLINE_MIN_VIS,
					["mates"] = v_u_8.OUTLINE_MATES == true,
					["colors"] = {
						["mate"] = v_u_8.OUTLINE_COLOR_MATE,
						["other"] = v_u_8.OUTLINE_COLOR_OTHER
					}
				}
			end,
			["place"] = function() -- name: place
				-- upvalues: (ref) p_u_6, (ref) v_u_5
				local v12 = p_u_6.session.place
				local v13 = v_u_5
				local v14, v15 = pcall(v12, v13)
				if v14 then
					return v15
				else
					return nil
				end
			end,
			["pvpRule"] = function() -- name: pvpRule
				-- upvalues: (copy) v_u_9
				local v16
				if v_u_9 == nil then
					v16 = false
				else
					v16 = v_u_9.rule("pvp") == true
				end
				return v16
			end,
			["players"] = function() -- name: players
				-- upvalues: (copy) v_u_10, (ref) p_u_6, (ref) v_u_1
				table.clear(v_u_10)
				local v17 = p_u_6.controllers.SquadMarkers
				if v17 and v17.mates then
					local v18 = v17.mates
					local v19, v20 = pcall(v18)
					if v19 and type(v20) == "table" then
						for _, v21 in v20 do
							v_u_10[v21.userId] = true
						end
					end
				end
				return v_u_1:GetPlayers()
			end,
			["isMate"] = function(p22) -- name: isMate
				-- upvalues: (copy) v_u_10
				return v_u_10[p22.UserId] == true
			end,
			["isTeam"] = function(p23) -- name: isTeam
				-- upvalues: (ref) v_u_5
				local v24 = v_u_5:GetAttribute("HuntTeam")
				local v25
				if type(v24) == "string" and v24 ~= "" then
					v25 = p23:GetAttribute("HuntTeam") == v24
				else
					v25 = false
				end
				return v25
			end,
			["foreign"] = function() -- name: foreign
				-- upvalues: (ref) p_u_6, (copy) v_u_7, (ref) v_u_5
				local v26 = p_u_6.lib.VisionActors
				local v27, v28
				if v26 then
					local v29 = v26.highlightCount
					local v30, v31 = pcall(v29)
					local v32 = v26.teamCount
					local v33
					v33, v27 = pcall(v32)
					v28 = (not v30 or type(v31) ~= "number") and 0 or v31
					if not v33 or type(v27) ~= "number" then
						v27 = 0
					end
				else
					v28 = 0
					v27 = 0
				end
				return v_u_7.foreignEstimate(v28, v27, v_u_5:GetAttribute("HuntPlayer") == true)
			end,
			["vis"] = function(p34) -- name: vis
				-- upvalues: (ref) p_u_6
				local v35 = p_u_6.controllers.Vision
				if v35 and v35.visibility then
					local v36 = v35.visibility
					local v37, v38 = pcall(v36, p34)
					if v37 and type(v38) == "number" then
						return v38
					end
				end
				return 1
			end,
			["cameraMode"] = function() -- name: cameraMode
				-- upvalues: (ref) p_u_6
				local v39 = p_u_6.controllers.Camera
				if v39 and v39.mode then
					local v40 = v39.mode
					local v41, v42 = pcall(v40)
					if v41 then
						return v42
					end
				end
				return nil
			end,
			["parent"] = function() -- name: parent
				-- upvalues: (ref) v_u_11
				if v_u_11 and v_u_11.Parent then
					return v_u_11
				end
				local v43 = workspace:FindFirstChild("HushLocal")
				if not v43 then
					v43 = Instance.new("Folder")
					v43.Name = "HushLocal"
					v43.Parent = workspace
				end
				local v44 = v43:FindFirstChild("PlayerOutline")
				if not v44 then
					v44 = Instance.new("Folder")
					v44.Name = "PlayerOutline"
					v44.Parent = v43
				end
				v_u_11 = v44
				return v_u_11
			end
		}
		v_u_3 = v_u_7.new(v45)
		v_u_1.PlayerRemoving:Connect(function(p46)
			-- upvalues: (ref) v_u_3
			if v_u_3 then
				v_u_3:forget(p46.UserId)
			end
		end)
		p_u_6.command("playeroutline.state", function()
			-- upvalues: (ref) v_u_3
			return not v_u_3 and "not started" or v_u_3:state()
		end)
	end
	local v48, v49 = pcall(v47)
	if not v48 then
		v_u_3 = nil
		warn("[PlayerOutlineBoot] the player outline failed to start:", v49)
		v_u_5:SetAttribute("ClientError", "playeroutline: " .. tostring(v49))
	end
end
function v2.step(p50) -- name: step
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_5
	if v_u_3 then
		v_u_3:step(p50)
		v_u_4 = v_u_4 + p50
		if v_u_4 >= 1 then
			v_u_4 = 0
			local v51 = v_u_3:state()
			if v_u_5:GetAttribute("PlayerOutlineState") ~= v51 then
				v_u_5:SetAttribute("PlayerOutlineState", v51)
			end
		end
	end
end
return v2