-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSaleNotice

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {
	["TUNE"] = {
		["prefetchMin"] = 2,
		["prefetchMax"] = 8,
		["refetchMin"] = 2,
		["refetchMax"] = 20,
		["dotEvery"] = 5
	}
}
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
function v_u_4.setRules(p7) -- name: setRules
	-- upvalues: (ref) v_u_6
	v_u_6 = p7
end
local v_u_8 = {}
local v_u_9 = os.clock
local function v_u_16(p10, p11) -- name: defaultLookup
	local v12 = game:GetService("MarketplaceService")
	local v13
	if p11 == "pass" then
		v13 = Enum.InfoType.GamePass
	else
		v13 = Enum.InfoType.Product
	end
	local v14 = v12:GetProductInfoAsync(p10, v13)
	if type(v14) ~= "table" then
		return nil
	end
	local v15 = v14.PriceInRobux
	return tonumber(v15)
end
local v_u_17 = v_u_16
function v_u_4.setLookup(p18) -- name: setLookup
	-- upvalues: (ref) v_u_17, (copy) v_u_16
	if type(p18) ~= "function" then
		p18 = v_u_16
	end
	v_u_17 = p18
end
function v_u_4.setClock(p19) -- name: setClock
	-- upvalues: (ref) v_u_9
	if type(p19) ~= "function" then
		p19 = os.clock
	end
	v_u_9 = p19
end
function v_u_4.resetOwn() -- name: resetOwn
	-- upvalues: (copy) v_u_8
	table.clear(v_u_8)
end
function v_u_4.ownKnown(p20) -- name: ownKnown
	local v21
	if type(p20) == "table" then
		local v22 = p20.sale
		if type(v22) == "table" then
			local v23 = p20.sale.was
			if type(v23) == "number" and (p20.enabled ~= false and p20.owned ~= true) then
				v21 = p20.offSale ~= true
			else
				v21 = false
			end
		else
			v21 = false
		end
	else
		v21 = false
	end
	return not v21 and true or p20.ownChecked == true
end
function v_u_4.apply(p24) -- name: apply
	-- upvalues: (copy) v_u_8, (ref) v_u_9
	local v25 = 0
	if type(p24) ~= "table" then
		return 0
	end
	local v26 = p24.products
	if type(v26) ~= "table" then
		return 0
	end
	for _, v27 in p24.products do
		local v28
		if type(v27) == "table" then
			local v29 = v27.sale
			if type(v29) == "table" then
				local v30 = v27.sale.was
				if type(v30) == "number" and (v27.enabled ~= false and v27.owned ~= true) then
					v28 = v27.offSale ~= true
				else
					v28 = false
				end
			else
				v28 = false
			end
		else
			v28 = false
		end
		if not v28 or v27.ownChecked == true then
			continue
		end
		local v31 = v27.robloxId
		local v32 = tonumber(v31) or 0
		local v33 = math.floor(v32)
		if v33 <= 0 then
			v27.ownChecked = true
		else
			local v34 = v_u_8[tostring(v33)]
			if v34 == nil then
				v25 = v25 + 1
			else
				local v35 = v34.price
				local v36
				if type(v35) == "number" and (v35 == v35 and v35 >= 0) then
					v36 = v35 < (1 / 0)
				else
					v36 = false
				end
				if v36 and v_u_9() - v34.t <= 120 then
					local v37 = v34.price
					if v37 ~= nil then
						v27.price = v37
					end
					v27.ownChecked = true
				else
					v25 = v25 + 1
				end
			end
		end
	end
	return v25
end
function v_u_4.resolve(p38) -- name: resolve
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (ref) v_u_9, (ref) v_u_17
	if v_u_4.apply(p38) == 0 then
		return true
	end
	for _, v39 in p38.products do
		local v40
		if type(v39) == "table" then
			local v41 = v39.sale
			if type(v41) == "table" then
				local v42 = v39.sale.was
				if type(v42) == "number" and (v39.enabled ~= false and v39.owned ~= true) then
					v40 = v39.offSale ~= true
				else
					v40 = false
				end
			else
				v40 = false
			end
		else
			v40 = false
		end
		if not v40 or v39.ownChecked == true then
			continue
		end
		local v43 = v39.robloxId
		local v44 = tonumber(v43) or 0
		local v45 = math.floor(v44)
		local v46 = tostring(v45)
		local v47 = v_u_8[v46]
		local v48, v49, v50
		if v47 == nil then
			::l16::
			local v51 = v_u_17
			local v52 = v39.kind
			local v53 = tostring(v52)
			local v54, v55 = pcall(v51, v45, v53)
			v47 = {}
			if v54 then
				local v56
				if type(v55) == "number" and (v55 == v55 and v55 >= 0) then
					v56 = v55 < (1 / 0)
				else
					v56 = false
				end
				if not v56 then
					v55 = nil
				end
			else
				v55 = nil
			end
			v47.price = v55
			v47.t = v_u_9()
			v_u_8[v46] = v47
			if v47 == nil then
				continue
			end
			v48 = v47.price
			if type(v48) == "number" and (v48 == v48 and v48 >= 0) then
				v49 = v48 < (1 / 0)
			else
				v49 = false
			end
			if not v49 then
				continue
			end
			v50 = v47.price
			if v50 ~= nil then
				v39.price = v50
			end
			v39.ownChecked = true
		else
			local v57 = v47.price
			local v58
			if type(v57) == "number" and (v57 == v57 and v57 >= 0) then
				v58 = v57 < (1 / 0)
			else
				v58 = false
			end
			if v58 and v_u_9() - v47.t > 120 then
				goto l16
			end
			local v59 = v47.price
			local v60
			if type(v59) == "number" and (v59 == v59 and v59 >= 0) then
				v60 = v59 < (1 / 0)
			else
				v60 = false
			end
			if not v60 and v_u_9() - v47.t > 30 then
				goto l16
			end
			if v47 == nil then
				continue
			end
			v48 = v47.price
			if type(v48) == "number" and (v48 == v48 and v48 >= 0) then
				v49 = v48 < (1 / 0)
			else
				v49 = false
			end
			if not v49 then
				continue
			end
			v50 = v47.price
			if v50 ~= nil then
				v39.price = v50
			end
			v39.ownChecked = true
		end
	end
	return v_u_4.apply(p38) == 0
end
function v_u_4.candidates(p61, p62) -- name: candidates
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_4
	if v_u_6 == nil then
		local function v63()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v63)
	end
	local v64 = v_u_6
	local v65 = {}
	if v64 ~= nil and type(p61) == "table" then
		local v66 = p61.products
		if type(v66) == "table" then
			for _, v67 in p61.products do
				if type(v67) ~= "table" then
					continue
				end
				local v68 = v67.sale
				if type(v68) ~= "table" or (v67.enabled == false or (v67.owned == true or (v67.offSale == true or not v_u_4.ownKnown(v67)))) then
					continue
				end
				local v69 = v64.clientView
				local v70 = v67.sale
				local v71 = v67.price
				local v72 = v69(v70, tonumber(v71), p62)
				if v72 == nil then
					continue
				end
				local v73 = {
					["id"] = v67.id
				}
				local v74 = v67.name or v67.id
				v73.name = tostring(v74)
				v73.pct = v72.pct
				v73.ends = v72.ends
				v73.since = v72.since or 0
				table.insert(v65, v73)
			end
			return v65
		end
	end
	return v65
end
function v_u_4.candidate(p75, p76, p77, p78) -- name: candidate
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_4
	if v_u_6 == nil then
		local function v79()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v79)
	end
	local v80 = v_u_6
	if v80 == nil or p78 ~= "Menu" then
		return nil
	end
	local v81 = v_u_4.candidates(p75, p76)
	if #v81 == 0 then
		return nil
	end
	local v82 = v80.offerId(v80.stamp(v81))
	if type(p77) == "table" and p77[v82] == true then
		return nil
	end
	local v83 = v80.best(v81)
	local v84 = v80.noticeText(v83, #v81, p76)
	return {
		["id"] = v82,
		["title"] = v84.title,
		["body"] = v84.body,
		["more"] = v84.more,
		["name"] = v83.name,
		["pct"] = v83.pct,
		["ends"] = v83.ends,
		["count"] = #v81,
		["bestId"] = v83.id,
		["target"] = #v81 == 1 and {
			["kind"] = "product",
			["id"] = nil,
			["id"] = v83.id
		} or {
			["kind"] = "filter",
			["id"] = "SALE"
		}
	}
end
function v_u_4.decide(p85, p86, p87, p88, p89) -- name: decide
	-- upvalues: (copy) v_u_4
	if p88 == true then
		return v_u_4.candidate(p85, p86, p87, p89)
	else
		return nil
	end
end
function v_u_4.waitOver(p90) -- name: waitOver
	-- upvalues: (ref) v_u_6, (copy) v_u_2
	if v_u_6 == nil then
		local function v91()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v91)
	end
	local v92 = v_u_6
	local v93
	if type(p90) == "number" and v92 ~= nil then
		v93 = v92.TUNE.noticeWaitSec <= p90
	else
		v93 = false
	end
	return v93
end
local v_u_94 = nil
local v_u_95 = false
local v_u_96 = {}
local v_u_97 = nil
local v_u_98 = nil
local v_u_99 = nil
local v_u_100
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_100 = require(script.Parent.ServerClock)
else
	v_u_100 = {
		["now"] = function() -- name: now
			return os.time()
		end
	}
end
function v_u_4.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_97
	local v101
	if v_u_97 == nil or (v_u_97.api == nil or v_u_97.api.frame == nil) then
		v101 = false
	else
		v101 = v_u_97.api.frame.Parent ~= nil
	end
	return v101
end
function v_u_4.close() -- name: close
	-- upvalues: (ref) v_u_97
	local v102 = v_u_97
	v_u_97 = nil
	if v102 and v102.api then
		local v103 = v102.api.close
		pcall(v103)
	end
end
function v_u_4.state() -- name: state
	-- upvalues: (copy) v_u_96, (copy) v_u_4, (ref) v_u_97
	local v104 = 0
	for _ in v_u_96 do
		v104 = v104 + 1
	end
	local v105 = {
		["open"] = v_u_4.isOpen(),
		["shownCount"] = v104,
		["shown"] = v_u_96
	}
	local v106
	if v_u_97 then
		v106 = v_u_97.id
	else
		v106 = nil
	end
	v105.openId = v106
	return v105
end
local function v_u_114(p_u_107) -- name: idleNow
	local v108, v109 = pcall(function()
		-- upvalues: (copy) p_u_107
		return p_u_107.cctx.lib.MenuConnNotice
	end)
	if v108 and type(v109) == "table" then
		local v110 = v109.idle
		if type(v110) == "function" then
			local v111 = v109.idle
			local v112, v113 = pcall(v111, p_u_107)
			if v112 then
				v112 = v113 == true
			end
			return v112
		end
	end
	return false
end
local function v_u_131(p_u_115, p_u_116) -- name: open
	-- upvalues: (copy) v_u_4, (ref) v_u_6, (copy) v_u_2, (ref) v_u_97
	local v_u_117 = p_u_115.ui
	local v_u_118 = p_u_115.theme.color
	local v_u_119 = {
		["id"] = p_u_116.id,
		["openedAt"] = os.clock(),
		["ends"] = p_u_116.ends
	}
	local function v122() -- name: goStore
		-- upvalues: (ref) v_u_4, (copy) p_u_116, (copy) p_u_115
		v_u_4.close()
		local v_u_120 = p_u_116.target
		local function v121()
			-- upvalues: (copy) v_u_120, (ref) p_u_115
			if v_u_120.kind == "product" then
				p_u_115.openStore(v_u_120.id)
			else
				p_u_115.openStore("SALE")
			end
		end
		pcall(v121)
	end
	local v123 = v_u_117.modal
	local v125 = {
		["title"] = nil,
		["width"] = 360,
		["kind"] = "danger",
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["title"] = p_u_116.title,
		["build"] = function(p124) -- name: build
			-- upvalues: (copy) v_u_117, (copy) p_u_116, (copy) v_u_118
			v_u_117.label({
				["parent"] = nil,
				["name"] = "SaleName",
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 1,
				["track"] = false,
				["rich"] = false,
				["parent"] = p124,
				["text"] = p_u_116.name,
				["color"] = v_u_118.text
			})
			if p_u_116.pct ~= nil then
				v_u_117.badge(("-%d%%"):format(p_u_116.pct), "accent", {
					["parent"] = nil,
					["order"] = 2,
					["name"] = "SalePercent",
					["parent"] = p124
				})
			end
			v_u_117.label({
				["parent"] = nil,
				["name"] = "SaleBody",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["track"] = false,
				["rich"] = false,
				["parent"] = p124,
				["text"] = p_u_116.body,
				["color"] = v_u_118.text2
			})
			if p_u_116.more ~= nil then
				v_u_117.label({
					["parent"] = nil,
					["name"] = "SaleMore",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 4,
					["track"] = false,
					["rich"] = false,
					["parent"] = p124,
					["text"] = p_u_116.more,
					["color"] = v_u_118.accent
				})
			end
		end
	}
	local v126 = {}
	local v127 = {
		["text"] = nil,
		["kind"] = "primary",
		["onClick"] = nil
	}
	if v_u_6 == nil then
		local function v128()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v128)
	end
	v127.text = v_u_6.TEXT.view
	v127.onClick = v122
	local v129 = {
		["text"] = nil,
		["kind"] = "ghost",
		["onClick"] = nil
	}
	if v_u_6 == nil then
		local function v130()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v130)
	end
	v129.text = v_u_6.TEXT.later
	function v129.onClick() -- name: onClick
		-- upvalues: (ref) v_u_4
		v_u_4.close()
	end
	__set_list(v126, 1, {v127, v129})
	v125.buttons = v126
	function v125.onClose() -- name: onClose
		-- upvalues: (ref) v_u_97, (copy) v_u_119
		if v_u_97 == v_u_119 then
			v_u_97 = nil
		end
	end
	v_u_119.api = v123(v125)
	v_u_97 = v_u_119
end
local v_u_132 = false
local function v_u_150(p_u_133) -- name: step
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (ref) v_u_132, (copy) v_u_4, (copy) v_u_100, (copy) v_u_5, (ref) v_u_97, (copy) v_u_96, (ref) v_u_98, (ref) v_u_99, (copy) v_u_114, (copy) v_u_131
	if v_u_6 == nil then
		local function v134()
			-- upvalues: (ref) v_u_6, (ref) v_u_2
			v_u_6 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
		end
		pcall(v134)
	end
	local v135 = v_u_6
	if v135 == nil then
		return
	else
		local v136 = p_u_133.cache
		local v137
		if type(v136) == "table" then
			v137 = p_u_133.cache.store
		else
			v137 = nil
		end
		local v_u_138
		if type(v137) == "table" then
			local v139 = v137.data
			if type(v139) == "table" then
				v_u_138 = v137.data
			else
				v_u_138 = nil
			end
		else
			v_u_138 = nil
		end
		if v_u_138 ~= nil and (not v_u_132 and v_u_4.apply(v_u_138) ~= 0) then
			v_u_132 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_4, (copy) v_u_138, (ref) v_u_132, (copy) p_u_133
				local v140 = v_u_4.apply(v_u_138)
				local v141 = v_u_4.resolve
				local v142 = v_u_138
				pcall(v141, v142)
				v_u_132 = false
				if v_u_4.apply(v_u_138) < v140 then
					local function v144()
						-- upvalues: (ref) p_u_133
						local v143 = p_u_133.cctx.lib.MenuStoreFeaturedDot
						if v143 ~= nil then
							v143.refresh(p_u_133)
						end
					end
					pcall(v144)
				end
			end)
		end
		local v145 = v_u_100.now()
		local v146 = v_u_5:GetAttribute("Place")
		if v_u_97 == nil then
			if v_u_138 == nil then
				return
			else
				local v147 = v_u_4.candidate(v_u_138, v145, v_u_96, v146)
				if v147 == nil then
					v_u_98 = nil
					v_u_99 = nil
					return
				elseif v_u_114(p_u_133) then
					v_u_98 = nil
					v_u_99 = nil
					v_u_96[v147.id] = true
					v_u_131(p_u_133, v147)
					return
				elseif v_u_99 == v147.id and v_u_98 ~= nil then
					if v_u_4.waitOver(os.clock() - v_u_98) then
						v_u_96[v147.id] = true
						v_u_98 = nil
						v_u_99 = nil
					end
				else
					local v148 = v147.id
					local v149 = os.clock()
					v_u_99 = v148
					v_u_98 = v149
				end
			end
		elseif v_u_4.isOpen() then
			if os.clock() - v_u_97.openedAt >= v135.TUNE.noticeShowSec or v_u_97.ends ~= nil and v_u_97.ends <= v145 or v_u_5:GetAttribute("MenuOpen") ~= true then
				v_u_4.close()
			end
		else
			v_u_97 = nil
		end
	end
end
function v_u_4.start(p_u_151) -- name: start
	-- upvalues: (ref) v_u_94, (ref) v_u_95, (copy) v_u_4, (copy) v_u_2, (copy) v_u_150, (copy) v_u_3, (copy) v_u_96, (ref) v_u_98, (ref) v_u_99
	v_u_94 = p_u_151
	if not v_u_95 then
		v_u_95 = true
		local function v153()
			-- upvalues: (copy) p_u_151, (ref) v_u_4
			local v152 = p_u_151.cctx.lib.MenuStoreFeaturedDot
			if v152 ~= nil and v152.setOwnApply ~= nil then
				v152.setOwnApply(v_u_4.apply)
			end
		end
		pcall(v153)
		local v_u_154 = Random.new()
		local v155 = v_u_2:FindFirstChild("Config")
		if (v155 and (tonumber(v155:GetAttribute("StoreSaleOn")) or 0) or 0) > 0 then
			local v156 = p_u_151.cache
			local v157
			if type(v156) == "table" then
				v157 = p_u_151.cache.store
			else
				v157 = nil
			end
			local v158
			if type(v157) == "table" then
				local v159 = v157.data
				if type(v159) == "table" then
					v158 = v157.data
				else
					v158 = nil
				end
			else
				v158 = nil
			end
			if v158 == nil then
				local v160 = v_u_154:NextNumber(v_u_4.TUNE.prefetchMin, v_u_4.TUNE.prefetchMax)
				task.delay(v160, function()
					-- upvalues: (copy) p_u_151
					local function v161()
						-- upvalues: (ref) p_u_151
						p_u_151.fetch("store", nil, 0)
					end
					if pcall(v161) then
						local function v163()
							-- upvalues: (ref) p_u_151
							local v162 = p_u_151.cctx.lib.MenuStoreFeaturedDot
							if v162 ~= nil then
								v162.refresh(p_u_151)
							end
						end
						pcall(v163)
					end
				end)
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_154, (ref) v_u_4, (copy) p_u_151
			local v_u_164 = v_u_2:FindFirstChild("Config") or v_u_2:WaitForChild("Config", 30)
			if v_u_164 ~= nil then
				local v_u_165 = v_u_164:GetAttribute("StoreSaleV")
				v_u_164:GetAttributeChangedSignal("StoreSaleV"):Connect(function()
					-- upvalues: (copy) v_u_164, (ref) v_u_165, (ref) v_u_154, (ref) v_u_4, (ref) p_u_151
					local v166 = v_u_164:GetAttribute("StoreSaleV")
					if v166 ~= v_u_165 then
						v_u_165 = v166
						task.delay(v_u_154:NextNumber(v_u_4.TUNE.refetchMin, v_u_4.TUNE.refetchMax), function()
							-- upvalues: (ref) p_u_151
							local v167 = p_u_151.invalidate
							pcall(v167, "store")
							local function v168()
								-- upvalues: (ref) p_u_151
								p_u_151.fetch("store", nil, 0)
							end
							if pcall(v168) then
								local function v170()
									-- upvalues: (ref) p_u_151
									local v169 = p_u_151.cctx.lib.MenuStoreFeaturedDot
									if v169 ~= nil then
										v169.refresh(p_u_151)
									end
								end
								pcall(v170)
							end
						end)
					end
				end)
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_150, (copy) p_u_151, (ref) v_u_4
			local v171 = 0
			while true do
				task.wait(1)
				local v172 = v_u_150
				local v173 = p_u_151
				local v174, v175 = pcall(v172, v173)
				if not v174 then
					warn("[MenuSaleNotice] step failed:", v175)
				end
				v171 = v171 + 1
				if v_u_4.TUNE.dotEvery > v171 then
					continue
				end
				local function v177()
					-- upvalues: (ref) p_u_151
					local v176 = p_u_151.cctx.lib.MenuStoreFeaturedDot
					if v176 ~= nil then
						v176.refresh(p_u_151)
					end
				end
				pcall(v177)
				v171 = 0
			end
		end)
		if v_u_3:IsStudio() then
			local function v180()
				-- upvalues: (copy) p_u_151, (ref) v_u_4, (ref) v_u_96, (ref) v_u_98, (ref) v_u_99
				p_u_151.cctx.command("sale.state", function()
					-- upvalues: (ref) v_u_4
					local v178 = v_u_4.state()
					local v179 = v178.open
					return ("open=%s shown=%d"):format(tostring(v179), v178.shownCount)
				end)
				p_u_151.cctx.command("sale.reset", function()
					-- upvalues: (ref) v_u_96, (ref) v_u_4, (ref) v_u_98, (ref) v_u_99
					table.clear(v_u_96)
					v_u_4.resetOwn()
					v_u_98 = nil
					v_u_99 = nil
					return "reset"
				end)
			end
			pcall(v180)
		end
	end
end
return v_u_4