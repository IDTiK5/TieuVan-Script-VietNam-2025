-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Input

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("ProximityPromptService")
local v_u_6 = game:GetService("GuiService")
local v_u_7 = game:GetService("RunService")
local v8 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v9 = require(v8:WaitForChild("Signal"))
local v_u_10 = require(v8:WaitForChild("TerrainProbe"))
local v_u_11 = require(script.Parent.Parent:WaitForChild("Lib"):WaitForChild("VirtualPad"))
local v_u_12 = {
	["name"] = "Input",
	["order"] = 10,
	["deviceChanged"] = v9.new(),
	["RIDE_HOOK"] = true
}
local v_u_13 = Enum.KeyCode
local v_u_14 = Enum.UserInputType
local v_u_15 = {
	["fire"] = {
		["keys"] = {},
		["mouse"] = { v_u_14.MouseButton1 },
		["pad"] = { v_u_13.ButtonR2 }
	},
	["aim"] = {
		["keys"] = {},
		["mouse"] = { v_u_14.MouseButton2 },
		["pad"] = { v_u_13.ButtonL2 }
	},
	["reload"] = {
		["keys"] = { v_u_13.R },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonX }
	},
	["interact"] = {
		["keys"] = { v_u_13.F },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonA }
	},
	["sprint"] = {
		["keys"] = { v_u_13.LeftShift },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonL3 }
	},
	["sneak"] = {
		["keys"] = { v_u_13.LeftControl, v_u_13.C },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonB }
	},
	["inventory"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["ui"] = true,
		["keys"] = { v_u_13.Tab, v_u_13.I },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonSelect }
	},
	["swap"] = {
		["keys"] = { v_u_13.X },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonY }
	},
	["primary"] = {
		["keys"] = { v_u_13.One },
		["mouse"] = {},
		["pad"] = {}
	},
	["secondary"] = {
		["keys"] = { v_u_13.Two },
		["mouse"] = {},
		["pad"] = {}
	},
	["meleeSlot"] = {
		["keys"] = { v_u_13.Three },
		["mouse"] = {},
		["pad"] = {}
	},
	["quick1"] = {
		["keys"] = { v_u_13.Four },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadUp }
	},
	["quick2"] = {
		["keys"] = { v_u_13.Five },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadRight }
	},
	["quick3"] = {
		["keys"] = { v_u_13.Six },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadDown }
	},
	["quick4"] = {
		["keys"] = { v_u_13.Seven },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadLeft }
	},
	["map"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["ui"] = true,
		["padHold"] = nil,
		["keys"] = { v_u_13.M },
		["mouse"] = {},
		["pad"] = {},
		["padHold"] = { v_u_13.ButtonSelect }
	},
	["ping"] = {
		["keys"] = { v_u_13.Z },
		["mouse"] = { v_u_14.MouseButton3 },
		["pad"] = { v_u_13.ButtonL1 }
	},
	["menu"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["ui"] = true,
		["keys"] = { v_u_13.P },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonStart }
	},
	["rotateItem"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["ui"] = true,
		["keys"] = { v_u_13.R },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonY }
	},
	["camLeft"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.Q },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadLeft }
	},
	["camRight"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.E },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadRight }
	},
	["zoom"] = {
		["keys"] = {},
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonR3 }
	},
	["viewToggle"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["when"] = "fptp",
		["keys"] = { v_u_13.Y },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonR3 }
	},
	["flashlight"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.T },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadUp }
	},
	["nightVision"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.N },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadDown }
	},
	["tasks"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.J },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonY }
	},
	["hideUi"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["ui"] = true,
		["padWhen"] = "padMod",
		["keys"] = { v_u_13.F1 },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonX }
	},
	["throw"] = {
		["keys"] = { v_u_13.G },
		["mouse"] = {},
		["pad"] = {}
	},
	["melee"] = {
		["keys"] = { v_u_13.V },
		["mouse"] = {},
		["pad"] = { v_u_13.ButtonR1 }
	},
	["extracts"] = {
		["keys"] = { v_u_13.O },
		["mouse"] = {},
		["pad"] = {},
		["padHold"] = { v_u_13.ButtonR3 }
	},
	["fireMode"] = {
		["keys"] = { v_u_13.B },
		["mouse"] = {},
		["pad"] = {}
	},
	["promptUp"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["when"] = "promptList",
		["keys"] = {},
		["mouse"] = {},
		["pad"] = { v_u_13.DPadUp }
	},
	["promptDown"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["when"] = "promptList",
		["keys"] = { v_u_13.H },
		["mouse"] = {},
		["pad"] = { v_u_13.DPadDown }
	},
	["chat"] = {
		["keys"] = { v_u_13.Return },
		["mouse"] = {},
		["pad"] = {}
	}
}
v_u_12.ACTIONS = v_u_15
local v_u_16 = {
	["LeftShift"] = "Shift",
	["RightShift"] = "Shift",
	["LeftControl"] = "Ctrl",
	["RightControl"] = "Ctrl",
	["LeftAlt"] = "Alt",
	["One"] = "1",
	["Two"] = "2",
	["Three"] = "3",
	["Four"] = "4",
	["Five"] = "5",
	["Six"] = "6",
	["Seven"] = "7",
	["Eight"] = "8",
	["Nine"] = "9",
	["Zero"] = "0",
	["Space"] = "Space",
	["Return"] = "Enter",
	["Backquote"] = "`",
	["RightAlt"] = "Alt",
	["Semicolon"] = ";",
	["Quote"] = "\'",
	["Comma"] = ",",
	["Period"] = ".",
	["BackSlash"] = "\\",
	["Minus"] = "-",
	["Equals"] = "=",
	["LeftBracket"] = "[",
	["RightBracket"] = "]",
	["CapsLock"] = "Caps",
	["Insert"] = "Ins",
	["Delete"] = "Del",
	["PageUp"] = "PgUp",
	["PageDown"] = "PgDn",
	["Backspace"] = "Bksp",
	["ButtonR2"] = "RT",
	["ButtonL2"] = "LT",
	["ButtonR1"] = "RB",
	["ButtonL1"] = "LB",
	["ButtonR3"] = "RS",
	["ButtonL3"] = "LS",
	["ButtonSelect"] = "View",
	["ButtonStart"] = "Menu",
	["DPadUp"] = "D-Pad Up",
	["DPadDown"] = "D-Pad Down",
	["DPadLeft"] = "D-Pad Left",
	["DPadRight"] = "D-Pad Right",
	["ButtonA"] = "A",
	["ButtonB"] = "B",
	["ButtonX"] = "X",
	["ButtonY"] = "Y"
}
local v_u_17 = {
	["padMod"] = v_u_13.ButtonL1
}
v_u_12.PAD_MOD_KEY = v_u_17
local v_u_18 = {
	["MouseButton1"] = "LMB",
	["MouseButton2"] = "RMB",
	["MouseButton3"] = "MMB"
}
local v_u_19 = {
	["quickTake"] = {
		["keys"] = nil,
		["mouse"] = nil,
		["pad"] = nil,
		["touch"] = "Tap",
		["keys"] = { v_u_13.LeftControl },
		["mouse"] = { v_u_14.MouseButton1 },
		["pad"] = { v_u_13.ButtonA }
	}
}
local v_u_20 = {
	["fire"] = "Outer ring",
	["aim"] = "Aim stick",
	["interact"] = "Use",
	["reload"] = "Reload",
	["sprint"] = "Push stick",
	["sneak"] = "Sneak",
	["inventory"] = "Bag",
	["swap"] = "Swap",
	["meleeSlot"] = "Swap",
	["melee"] = "More",
	["ping"] = "More",
	["flashlight"] = "More",
	["nightVision"] = "NVG",
	["tasks"] = "Tap",
	["hideUi"] = "Settings",
	["throw"] = "More",
	["quick1"] = "More",
	["quick2"] = "More",
	["quick3"] = "More",
	["quick4"] = "More",
	["zoom"] = "Pinch",
	["camLeft"] = "Twist",
	["camRight"] = "Twist",
	["rotateItem"] = "Rotate",
	["fireMode"] = "Tap",
	["map"] = "Map",
	["extracts"] = "Exits",
	["promptUp"] = "Next",
	["promptDown"] = "Next",
	["chat"] = "Chat",
	["viewToggle"] = "View"
}
local v_u_21 = nil
local v_u_22 = v3.LocalPlayer
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = true
local v_u_29 = "Keyboard"
local v_u_30 = nil
local v_u_31 = false
local v_u_32 = false
local v_u_33 = false
local v_u_34 = false
local v_u_35 = Vector3.new(0, 0, 0)
local v_u_36 = Vector3.new(0, 0, 0)
local v_u_37 = 0
local v_u_38 = 0
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = false
local v_u_43 = "Menu"
function v_u_12.rideBusy(p44) -- name: rideBusy
	-- upvalues: (copy) v_u_22
	if p44 == nil then
		return false
	end
	local v45 = p44:GetAttribute("Action")
	return (p44:GetAttribute("RideVehicle") ~= nil or (v45 == "VehEnter" or (v45 == "VehExit" or (v45 == "VehExitFast" or (v45 == "VehAbort" or v45 == "Eject"))))) and true or v_u_22:GetAttribute("PredVehAnim") ~= nil
end
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = 0
local v_u_50 = {
	["yaw"] = 999,
	["sprint"] = false,
	["sneak"] = false,
	["aim"] = false
}
local v_u_51 = 0
local v_u_52 = nil
local v_u_53 = {
	["since"] = nil,
	["silentSince"] = nil,
	["hintAt"] = (-1 / 0),
	["hold"] = false,
	["pulled"] = false,
	["pull"] = nil
}
local v_u_54 = nil
local v_u_55 = false
local v_u_56 = false
local v_u_57 = 999
local v_u_58 = 0
local v_u_59 = nil
local v_u_60 = Vector2.zero
local v_u_61 = Vector2.zero
local v_u_62 = {}
local v_u_63 = {}
local v_u_64 = 0
local v_u_65 = nil
local v_u_66 = false
local v_u_67 = false
local v_u_68 = false
local v_u_69 = {
	["eventDevice"] = nil,
	["mouseTravel"] = 0,
	["mouseAt"] = 0,
	["simPreferred"] = nil,
	["wasInCharge"] = false,
	["blockMoveConn"] = nil,
	["blockedMoves"] = 0,
	["clears"] = 0,
	["assistSetting"] = nil,
	["assistLock"] = nil,
	["assistLockAt"] = 0,
	["assistStats"] = nil,
	["settingsFetched"] = false,
	["blockedAt"] = -1,
	["swallowed"] = 0,
	["holdPolls"] = 0,
	["raidSince"] = nil,
	["padTipShown"] = false,
	["rideTouch"] = false,
	["assistStats"] = {
		["pulls"] = 0,
		["last"] = 0
	}
}
local v_u_70 = {
	["loaded"] = false,
	["current"] = "",
	["capture"] = nil,
	["log"] = nil,
	["fetching"] = false,
	["log"] = {}
}
local v_u_71 = {
	["navOff"] = false,
	["stickIo"] = nil,
	["src"] = nil,
	["stickArmed"] = false,
	["stickHeld"] = nil,
	["navSteps"] = 0,
	["selChangedAt"] = 0,
	["aHit"] = 0,
	["aMiss"] = 0,
	["diagLines"] = 0,
	["diagWas"] = false,
	["diagDue"] = nil
}
local v72 = {
	["evt"] = {
		["v"] = nil,
		["at"] = 0,
		["v"] = Vector2.zero
	},
	["poll"] = {
		["v"] = nil,
		["at"] = 0,
		["v"] = Vector2.zero
	},
	["io"] = {
		["v"] = nil,
		["at"] = 0,
		["v"] = Vector2.zero
	}
}
v_u_71.src = v72
v_u_71.diagDue = {}
local v_u_73 = 0
local v_u_74 = {
	["mv"] = Vector3.new(0, 0, 0),
	["at"] = -1,
	["reasserts"] = 0
}
v_u_12._moveKeep = v_u_74
local function v_u_90() -- name: camBasis
	-- upvalues: (ref) v_u_21
	local v_u_75 = v_u_21
	if v_u_75 then
		v_u_75 = v_u_21.controllers.Camera
	end
	if v_u_75 and (v_u_75.forward and v_u_75.right) then
		local v76, v77, v78 = pcall(function()
			-- upvalues: (copy) v_u_75
			return v_u_75.forward(), v_u_75.right()
		end)
		if v76 and (typeof(v77) == "Vector3" and (typeof(v78) == "Vector3" and v77.Magnitude > 0.1)) then
			return v77.Unit, v78.Unit
		end
	end
	local v79 = workspace.CurrentCamera
	if v79 then
		local v80 = v79.CFrame.LookVector
		local v81 = v80.X
		local v82 = v80.Z
		local v83 = Vector3.new(v81, 0, v82)
		if v83.Magnitude < 0.05 then
			local v84 = v79.CFrame.UpVector
			local v85 = v84.X
			local v86 = v84.Z
			v83 = Vector3.new(v85, 0, v86)
		end
		if v83.Magnitude > 0.05 then
			local v87 = v83.Unit
			local v88 = -v87.Z
			local v89 = v87.X
			return v87, Vector3.new(v88, 0, v89)
		end
	end
	return Vector3.new(-0.70710677, 0, -0.70710677), Vector3.new(0.70710677, 0, -0.70710677)
end
local function v_u_99(p91, p92, p93) -- name: fire
	-- upvalues: (copy) v_u_15, (copy) v_u_27, (ref) v_u_28, (copy) v_u_70, (copy) v_u_26
	local v94 = v_u_15[p91]
	if p92 then
		if not (v_u_28 or v94 and v94.ui) then
			return
		end
		v_u_27[p91] = true
		local v95 = v_u_70.log
		table.insert(v95, p91)
		if #v_u_70.log > 40 then
			table.remove(v_u_70.log, 1)
		end
	else
		if not v_u_27[p91] then
			return
		end
		v_u_27[p91] = nil
	end
	local v96 = v_u_26[p91]
	if v96 then
		for _, v97 in table.clone(v96) do
			local v98
			if p92 then
				v98 = v97.b
			else
				v98 = v97.e
			end
			if not v98 then
				continue
			end
			task.spawn(v98, p93)
		end
	end
end
local v_u_100 = {
	"InventoryUI",
	"MapUI",
	"RaidSettings",
	"HuntClient"
}
local function v_u_108() -- name: panelOpen
	-- upvalues: (ref) v_u_21, (copy) v_u_100
	local v101 = v_u_21
	if v101 then
		v101 = v_u_21.controllers
	end
	if not v101 then
		return false
	end
	for _, v102 in v_u_100 do
		local v103 = v101[v102]
		if not v103 then
			continue
		end
		local v104 = v103.isOpen
		if type(v104) ~= "function" then
			continue
		end
		local v105 = v103.isOpen
		local v106, v107 = pcall(v105)
		if not v106 or v107 ~= true then
			continue
		end
		return true
	end
	return false
end
v_u_12._panelOpen = v_u_108
local v_u_109 = {
	["MapUI"] = "HushMap",
	["RaidSettings"] = "HushRaidSettings",
	["HuntClient"] = "HushHuntHowTo"
}
local v_u_110 = {}
local v_u_111 = 0
local v_u_112 = 0
local v_u_113 = {
	["panels"] = 0,
	["last"] = ""
}
v_u_12._healStats = v_u_113
local function v_u_119(p114) -- name: panelHasWindow
	-- upvalues: (copy) v_u_22, (copy) v_u_109
	if p114 == "InventoryUI" then
		return v_u_22:GetAttribute("InvUIOpen") == true
	end
	local v115 = v_u_109[p114]
	local v116 = v_u_22:FindFirstChildOfClass("PlayerGui")
	local v117
	if v115 and v116 then
		v117 = v116:FindFirstChild(v115)
	else
		v117 = nil
	end
	local v118 = v117 ~= nil and v117:IsA("ScreenGui")
	if v118 then
		v118 = v117.Enabled
	end
	return v118
end
local function v_u_137() -- name: healStalePanels
	-- upvalues: (ref) v_u_111, (ref) v_u_21, (ref) v_u_43, (ref) v_u_28, (copy) v_u_110, (copy) v_u_100, (copy) v_u_119, (copy) v_u_113, (ref) v_u_112
	local v120 = os.clock()
	if v120 < v_u_111 then
		return
	else
		v_u_111 = v120 + 0.25
		local v121 = v_u_21
		if v121 then
			v121 = v_u_21.controllers
		end
		if v121 and (v_u_43 == "Raid" and v_u_28) then
			for _, v122 in v_u_100 do
				local v123 = v121[v122]
				local v124 = false
				if v123 then
					local v125 = v123.isOpen
					if type(v125) == "function" then
						local v126 = v123.isOpen
						local v127
						v124, v127 = pcall(v126)
						if v124 then
							v124 = v127 == true
						end
					end
				end
				if v124 and not v_u_119(v122) then
					local v128 = v_u_110[v122]
					if v128 then
						if v120 - v128 < 1 then
							continue
						end
						v_u_110[v122] = nil
						local v129 = v_u_21.controllers[v122]
						local v130
						if v129 then
							local v131 = v129.close
							if type(v131) == "function" then
								local v132 = v129.close
								pcall(v132)
								local v133 = v129.isOpen
								local v134, v135 = pcall(v133)
								if v134 and v135 ~= true then
									local v136 = v_u_113
									v136.panels = v136.panels + 1
									v_u_113.last = v122
									v130 = true
								else
									v130 = false
								end
							else
								v130 = false
							end
						else
							v130 = false
						end
						if not v130 or v_u_112 >= 3 then
							continue
						end
						v_u_112 = v_u_112 + 1
						warn("[Input] panel " .. v122 .. " said open without a window: closed (R37 mobile_walk)")
					else
						v_u_110[v122] = v120
					end
				else
					v_u_110[v122] = nil
				end
			end
		else
			table.clear(v_u_110)
		end
	end
end
local v_u_138 = {
	["ctx"] = nil,
	["filters"] = nil,
	["eaten"] = nil,
	["provider"] = nil,
	["pitch"] = 0,
	["pitchSend"] = nil,
	["tapRects"] = nil,
	["ctx"] = {},
	["filters"] = {},
	["eaten"] = {},
	["tapRects"] = {}
}
local function v_u_148(p139, p140, p141) -- name: onAction
	-- upvalues: (copy) v_u_15, (ref) v_u_28, (copy) v_u_108, (copy) v_u_69, (copy) v_u_138, (ref) v_u_29, (copy) v_u_12, (copy) v_u_22, (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33, (ref) v_u_34, (copy) v_u_99
	if p140 then
		local v142 = v_u_15[p139]
		if not (v142 and v142.ui) then
			if not v_u_28 or v_u_108() then
				return
			end
			if os.clock() - v_u_69.blockedAt < 0.15 then
				local v143 = v_u_69
				v143.swallowed = v143.swallowed + 1
				return
			end
		end
		local v144 = v_u_138.filters[p139]
		v_u_138.eaten[p139] = nil
		if v144 ~= nil then
			local v145, v146 = pcall(v144)
			if v145 and v146 == true then
				v_u_138.eaten[p139] = true
				return
			end
		end
	elseif v_u_138.eaten[p139] then
		v_u_138.eaten[p139] = nil
		return
	end
	local v147 = v_u_29
	if not p140 or p139 ~= "sprint" and (p139 ~= "sneak" and (p139 ~= "quick1" or v147 ~= "Gamepad")) or not v_u_12.rideBusy(v_u_22.Character) then
		if p139 == "sprint" then
			if v147 == "Keyboard" or v147 == "Touch" then
				v_u_31 = p140
			elseif p140 then
				v_u_31 = not v_u_31
			end
			if v_u_31 then
				v_u_32 = false
			end
			if v_u_25 then
				v_u_25:setToggle("sprint", v_u_31)
				v_u_25:setToggle("sneak", v_u_32)
				v_u_25:setToggle("aim", v_u_33)
			end
		elseif p139 == "sneak" then
			if p140 then
				v_u_32 = not v_u_32
				if v_u_32 then
					v_u_31 = false
				end
				if v_u_25 then
					v_u_25:setToggle("sprint", v_u_31)
					v_u_25:setToggle("sneak", v_u_32)
					v_u_25:setToggle("aim", v_u_33)
				end
			end
		elseif p139 == "aim" then
			v_u_33 = p140
		elseif p139 == "fire" then
			v_u_34 = p140
		end
		v_u_99(p139, p140, p141)
	end
end
local function v_u_158(p149) -- name: actionsFor
	-- upvalues: (copy) v_u_15, (ref) v_u_68
	local v150 = {}
	local v151 = {}
	for v152, v153 in v_u_15 do
		if p149.UserInputType == Enum.UserInputType.Keyboard then
			if not table.find(v153.keys, p149.KeyCode) then
				continue
			end
			table.insert(v150, v152)
		else
			local v154 = p149.UserInputType
			local v155
			if v154 == Enum.UserInputType.Gamepad1 then
				v155 = true
			else
				local v156 = v154.Name
				v155 = string.sub(v156, 1, 7) == "Gamepad"
			end
			if v155 then
				if not table.find(v153.pad, p149.KeyCode) then
					continue
				end
				if v153.padWhen then
					local v157
					if v153.padWhen == "padMod" then
						v157 = v_u_68
					else
						v157 = false
					end
					if not v157 then
						continue
					end
					table.insert(v151, v152)
				else
					table.insert(v150, v152)
				end
			else
				if not table.find(v153.mouse, p149.UserInputType) then
					continue
				end
				table.insert(v150, v152)
			end
		end
	end
	if #v151 > 0 then
		return v151
	else
		return v150
	end
end
local function v_u_162() -- name: consumePadMod
	-- upvalues: (ref) v_u_21
	local v_u_159 = v_u_21
	if v_u_159 then
		v_u_159 = v_u_21.controllers.Comms
	end
	if v_u_159 then
		local v160 = v_u_159.isOpen
		if type(v160) == "function" then
			local v161 = v_u_159.close
			if type(v161) == "function" then
				pcall(function()
					-- upvalues: (copy) v_u_159
					if v_u_159.isOpen() then
						v_u_159.close()
					end
				end)
			end
		end
	end
end
local function v_u_172(p163) -- name: contextOn
	-- upvalues: (ref) v_u_21, (copy) v_u_138
	if p163 == "promptList" then
		local v164 = v_u_21
		if v164 then
			v164 = v_u_21.controllers.Prompts
		end
		if v164 then
			local v165 = v164.choiceListVisible
			if type(v165) == "function" then
				local v166 = v164.choiceListVisible
				local v167, v168 = pcall(v166)
				if v167 then
					v167 = v168 == true
				end
				return v167
			end
		end
	end
	local v169 = v_u_138.ctx[p163]
	if v169 == nil then
		return false
	end
	local v170, v171 = pcall(v169)
	if v170 then
		v170 = v171 == true
	end
	return v170
end
local function v_u_182(p173) -- name: routeContext
	-- upvalues: (copy) v_u_15, (copy) v_u_172
	local v174 = false
	for _, v175 in p173 do
		local v176 = v_u_15[v175]
		if not (v176 and v176.when) then
			continue
		end
		v174 = true
	end
	if v174 then
		local v177 = {}
		local v178 = {}
		local v179 = {}
		for _, v180 in p173 do
			local v181 = v_u_15[v180]
			if v181 then
				v181 = v181.when
			end
			if v181 then
				if v177[v181] == nil then
					v177[v181] = v_u_172(v181)
				end
				if not v177[v181] then
					continue
				end
				table.insert(v178, v180)
			else
				table.insert(v179, v180)
			end
		end
		if #v178 > 0 then
			return v178
		else
			return v179
		end
	else
		return p173
	end
end
v_u_12._routeContext = v_u_182
local function v_u_195(p183) -- name: arbitrate
	-- upvalues: (copy) v_u_182, (copy) v_u_15, (ref) v_u_28, (ref) v_u_42, (copy) v_u_22, (ref) v_u_43, (copy) v_u_108
	local v184 = v_u_182(p183)
	if #v184 < 2 then
		return v184
	end
	local v185 = false
	local v186 = false
	for _, v187 in v184 do
		local v188 = v_u_15[v187]
		if v188 and v188.ui then
			v185 = true
		else
			v186 = true
		end
	end
	if not (v185 and v186) then
		return v184
	end
	local v189
	if v_u_28 then
		local v190 = v_u_42
		if not v190 then
			if v_u_22.Character == nil then
				v190 = false
			else
				v190 = v_u_43 ~= "Transit"
			end
		end
		v189 = not v190 and true or v_u_108()
	else
		v189 = true
	end
	local v191 = {}
	for _, v192 in v184 do
		local v193 = v_u_15[v192]
		local v194
		if v193 == nil then
			v194 = false
		else
			v194 = v193.ui == true
		end
		if v194 ~= v189 then
			continue
		end
		table.insert(v191, v192)
	end
	return v191
end
v_u_12._arbitrate = v_u_195
v_u_12._onAction = v_u_148
v_u_12._fpx = v_u_138
local v_u_196 = {}
local function v_u_201(p197) -- name: padHoldActions
	-- upvalues: (copy) v_u_15
	local v198 = {}
	for v199, v200 in v_u_15 do
		if not (v200.padHold and table.find(v200.padHold, p197)) then
			continue
		end
		table.insert(v198, v199)
	end
	table.sort(v198)
	return v198
end
local v_u_202 = nil
local function v_u_226() -- name: stepPadHolds
	-- upvalues: (copy) v_u_196, (copy) v_u_11, (copy) v_u_4, (copy) v_u_201, (copy) v_u_148, (copy) v_u_138, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33, (ref) v_u_34, (copy) v_u_99, (copy) v_u_69, (ref) v_u_202
	if next(v_u_196) == nil then
		return
	end
	local v203 = os.clock()
	local v204 = {}
	for v205, v206 in v_u_196 do
		local v207, v208
		if v206.ut == nil then
			v207 = nil
			if v207 == false and v203 - v206.t > 0.05 then
				table.insert(v204, v205)
			else
				if v206.fired or v203 - v206.t < 0.45 then
					continue
				end
				v206.fired = true
				for v221, v222 in v_u_201(v205) do
					v_u_148(v222, true)
					if v_u_138.eaten[v222] then
						v_u_138.eaten[v222] = nil
					else
						v208 = v_u_29
						if v222 == "sprint" then
							if v208 == "Keyboard" or v208 == "Touch" then
								v_u_31 = false
							end
							if v_u_31 then
								v_u_32 = false
							end
							if v_u_25 then
								v_u_25:setToggle("sprint", v_u_31)
								v_u_25:setToggle("sneak", v_u_32)
								v_u_25:setToggle("aim", v_u_33)
							end
						elseif v222 ~= "sneak" then
							if v222 == "aim" then
								v_u_33 = false
							elseif v222 == "fire" then
								v_u_34 = false
							end
						end
						v_u_99(v222, false, nil)
					end
				end
			end
		else
			local v211
			if v206.virtual then
				v211 = v_u_11.isDown(v205)
				if v211 then
					v206.seen = true
					v207 = true
				elseif v206.seen then
					v207 = false
				else
					v207 = nil
				end
				if v207 == false and v203 - v206.t > 0.05 then
					table.insert(v204, v205)
				else
					if v206.fired or v203 - v206.t < 0.45 then
						continue
					end
					v206.fired = true
					for v221, v222 in v_u_201(v205) do
						v_u_148(v222, true)
						if v_u_138.eaten[v222] then
							v_u_138.eaten[v222] = nil
						else
							v208 = v_u_29
							if v222 == "sprint" then
								if v208 == "Keyboard" or v208 == "Touch" then
									v_u_31 = false
								end
								if v_u_31 then
									v_u_32 = false
								end
								if v_u_25 then
									v_u_25:setToggle("sprint", v_u_31)
									v_u_25:setToggle("sneak", v_u_32)
									v_u_25:setToggle("aim", v_u_33)
								end
							elseif v222 ~= "sneak" then
								if v222 == "aim" then
									v_u_33 = false
								elseif v222 == "fire" then
									v_u_34 = false
								end
							end
							v_u_99(v222, false, nil)
						end
					end
				end
			else
				local v214 = v_u_4.IsGamepadButtonDown
				local v215 = v_u_4
				local v216 = v206.ut
				local v217, v218 = pcall(v214, v215, v216, v205)
				if v217 then
					v211 = v218 == true
					if v211 then
						v206.seen = true
						v207 = true
					elseif v206.seen then
						v207 = false
					else
						v207 = nil
					end
					if v207 == false and v203 - v206.t > 0.05 then
						table.insert(v204, v205)
					else
						if v206.fired or v203 - v206.t < 0.45 then
							continue
						end
						v206.fired = true
						for v221, v222 in v_u_201(v205) do
							v_u_148(v222, true)
							if v_u_138.eaten[v222] then
								v_u_138.eaten[v222] = nil
							else
								v208 = v_u_29
								if v222 == "sprint" then
									if v208 == "Keyboard" or v208 == "Touch" then
										v_u_31 = false
									end
									if v_u_31 then
										v_u_32 = false
									end
									if v_u_25 then
										v_u_25:setToggle("sprint", v_u_31)
										v_u_25:setToggle("sneak", v_u_32)
										v_u_25:setToggle("aim", v_u_33)
									end
								elseif v222 ~= "sneak" then
									if v222 == "aim" then
										v_u_33 = false
									elseif v222 == "fire" then
										v_u_34 = false
									end
								end
								v_u_99(v222, false, nil)
							end
						end
					end
				else
					v207 = nil
					if v207 == false and v203 - v206.t > 0.05 then
						table.insert(v204, v205)
					else
						if v206.fired or v203 - v206.t < 0.45 then
							continue
						end
						v206.fired = true
						for v221, v222 in v_u_201(v205) do
							v_u_148(v222, true)
							if v_u_138.eaten[v222] then
								v_u_138.eaten[v222] = nil
							else
								v208 = v_u_29
								if v222 == "sprint" then
									if v208 == "Keyboard" or v208 == "Touch" then
										v_u_31 = false
									end
									if v_u_31 then
										v_u_32 = false
									end
									if v_u_25 then
										v_u_25:setToggle("sprint", v_u_31)
										v_u_25:setToggle("sneak", v_u_32)
										v_u_25:setToggle("aim", v_u_33)
									end
								elseif v222 ~= "sneak" then
									if v222 == "aim" then
										v_u_33 = false
									elseif v222 == "fire" then
										v_u_34 = false
									end
								end
								v_u_99(v222, false, nil)
							end
						end
					end
				end
			end
		end
	end
	for _, v223 in v204 do
		local v224 = v_u_196[v223]
		if not v224 then
			continue
		end
		local v225 = v_u_69
		v225.holdPolls = v225.holdPolls + 1
		v_u_202({
			["KeyCode"] = v223,
			["UserInputType"] = v224.ut
		})
	end
end
v_u_202 = function(p227) -- name: endPadHold
	-- upvalues: (copy) v_u_196, (copy) v_u_195, (copy) v_u_158, (ref) v_u_21, (copy) v_u_201, (copy) v_u_148, (copy) v_u_138, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33, (ref) v_u_34, (copy) v_u_99
	local v228 = v_u_196[p227.KeyCode]
	if not v228 then
		return false
	end
	v_u_196[p227.KeyCode] = nil
	if v228.fired then
		return true
	end
	local v229 = v_u_195((v_u_158(p227)))
	local v230 = v_u_21
	if v230 then
		v230 = v_u_21.controllers.MapUI
	end
	local v231
	if v230 then
		local v232 = v230.isOpen
		if type(v232) == "function" then
			local v233 = v230.isOpen
			local v234
			v231, v234 = pcall(v233)
			if v231 then
				v231 = v234 == true
			end
		else
			v231 = false
		end
	else
		v231 = false
	end
	if v231 then
		local v235 = v_u_201(p227.KeyCode)
		v229 = table.find(v235, "map") and { "map" } or v229
	end
	for _, v236 in v229 do
		v_u_148(v236, true)
	end
	for _, v237 in v229 do
		if v_u_138.eaten[v237] then
			v_u_138.eaten[v237] = nil
		else
			local v238 = v_u_29
			if v237 == "sprint" then
				if v238 == "Keyboard" or v238 == "Touch" then
					v_u_31 = false
				end
				if v_u_31 then
					v_u_32 = false
				end
				if v_u_25 then
					v_u_25:setToggle("sprint", v_u_31)
					v_u_25:setToggle("sneak", v_u_32)
					v_u_25:setToggle("aim", v_u_33)
				end
			elseif v237 ~= "sneak" then
				if v237 == "aim" then
					v_u_33 = false
				elseif v237 == "fire" then
					v_u_34 = false
				end
			end
			v_u_99(v237, false, nil)
		end
	end
	return true
end
local function v_u_244() -- name: detectDevice
	-- upvalues: (ref) v_u_30, (copy) v_u_11, (copy) v_u_69, (copy) v_u_4, (ref) v_u_29
	if v_u_30 then
		return v_u_30
	end
	if v_u_11.active and not v_u_11.realMode then
		return "Gamepad"
	end
	if v_u_69.eventDevice then
		return v_u_69.eventDevice
	end
	if v_u_69.simPreferred then
		return v_u_69.simPreferred
	end
	local function v239()
		-- upvalues: (ref) v_u_4
		return v_u_4.PreferredInput
	end
	local v240, v241 = pcall(v239)
	if v240 and v241 ~= nil then
		local v242 = tostring(v241)
		if string.find(v242, "Touch") then
			return "Touch"
		end
		if string.find(v242, "Gamepad") then
			return "Gamepad"
		end
		if string.find(v242, "Keyboard") then
			return "Keyboard"
		end
	end
	local v243 = v_u_4:GetLastInputType()
	return v243 == Enum.UserInputType.Touch and "Touch" or (string.find(v243.Name, "Gamepad") and "Gamepad" or ((v243 == Enum.UserInputType.Keyboard or string.find(v243.Name, "Mouse")) and "Keyboard" or (v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or v_u_29)))
end
local function v_u_254() -- name: refreshDevice
	-- upvalues: (copy) v_u_244, (ref) v_u_29, (copy) v_u_22, (ref) v_u_31, (ref) v_u_25, (ref) v_u_32, (ref) v_u_33, (copy) v_u_6, (ref) v_u_73, (ref) v_u_60, (ref) v_u_61, (copy) v_u_71, (copy) v_u_12, (ref) v_u_42, (ref) v_u_43, (ref) v_u_28, (copy) v_u_69
	local v245 = v_u_244()
	if v245 ~= v_u_29 then
		local v246 = v_u_29
		v_u_29 = v245
		v_u_22:SetAttribute("InputDevice", v245)
		if v245 == "Keyboard" and v246 ~= "Keyboard" then
			v_u_31 = false
			if v_u_25 then
				v_u_25:setToggle("sprint", v_u_31)
				v_u_25:setToggle("sneak", v_u_32)
				v_u_25:setToggle("aim", v_u_33)
			end
		end
		if v246 == "Gamepad" and (v245 ~= "Gamepad" and v_u_6.SelectedObject ~= nil) then
			v_u_6.SelectedObject = nil
		end
		if v245 == "Gamepad" then
			v_u_73 = 0
		else
			local v247 = Vector2.zero
			local v248 = Vector2.zero
			v_u_60 = v247
			v_u_61 = v248
			v_u_71.resetStick()
		end
		v_u_12.deviceChanged:Fire(v245)
	end
	if v_u_25 then
		local v249 = v_u_25
		local v250
		if v_u_29 == "Touch" then
			local v251 = v_u_42
			if not v251 then
				if v_u_22.Character == nil then
					v251 = false
				else
					v251 = v_u_43 ~= "Transit"
				end
			end
			v250 = v251 and v_u_28
			if v250 then
				local v252 = v_u_22.Character
				local v253
				if v252 == nil then
					v253 = false
				else
					v253 = v252:GetAttribute("Dead") == true
				end
				v250 = not v253
				if v250 then
					v250 = not v_u_69.rideTouch
				end
			end
		else
			v250 = false
		end
		v249:setVisible(v250)
	end
end
local function v_u_265(p255, p256) -- name: deviceOfInput
	-- upvalues: (copy) v_u_14, (copy) v_u_69, (copy) v_u_13
	local v257 = p255.UserInputType
	if v257 == v_u_14.Touch then
		return "Touch"
	end
	if v257 == v_u_14.Keyboard or (v257 == v_u_14.MouseButton1 or (v257 == v_u_14.MouseButton2 or (v257 == v_u_14.MouseButton3 or v257 == v_u_14.MouseWheel))) then
		return "Keyboard"
	end
	if v257 ~= v_u_14.MouseMovement then
		local v258
		if v257 == Enum.UserInputType.Gamepad1 then
			v258 = true
		else
			local v259 = v257.Name
			v258 = string.sub(v259, 1, 7) == "Gamepad"
		end
		if v258 then
			if not p256 then
				return "Gamepad"
			end
			local v260 = p255.KeyCode
			local v261 = p255.Position
			if typeof(v261) ~= "Vector3" then
				return nil
			end
			if v260 == v_u_13.Thumbstick1 or v260 == v_u_13.Thumbstick2 then
				return Vector2.new(v261.X, v261.Y).Magnitude >= 0.45 and "Gamepad" or nil
			end
			if v260 == v_u_13.ButtonL2 or v260 == v_u_13.ButtonR2 then
				return v261.Z >= 0.35 and "Gamepad" or nil
			end
		end
		return nil
	end
	local v262 = os.clock()
	if v262 - v_u_69.mouseAt > 0.4 then
		v_u_69.mouseTravel = 0
	end
	v_u_69.mouseAt = v262
	local v263 = p255.Delta
	local v264 = v_u_69
	v264.mouseTravel = v264.mouseTravel + (typeof(v263) ~= "Vector3" and 0 or Vector2.new(v263.X, v263.Y).Magnitude)
	if v_u_69.mouseTravel < 12 then
		return nil
	end
	v_u_69.mouseTravel = 0
	return "Keyboard"
end
function v_u_12._noteInput(p266, p267) -- name: noteInput
	-- upvalues: (copy) v_u_265, (copy) v_u_69, (copy) v_u_254
	local v268 = v_u_265(p266, p267)
	if v268 and v268 ~= v_u_69.eventDevice then
		v_u_69.eventDevice = v268
		v_u_254()
	end
end
function v_u_12.bind(p_u_269, p270, p271) -- name: bind
	-- upvalues: (copy) v_u_26
	local v272 = v_u_26[p_u_269]
	if not v272 then
		v272 = {}
		v_u_26[p_u_269] = v272
	end
	local v_u_273 = {
		["b"] = p270,
		["e"] = p271
	}
	table.insert(v272, v_u_273)
	return function()
		-- upvalues: (ref) v_u_26, (copy) p_u_269, (copy) v_u_273
		local v274 = v_u_26[p_u_269]
		local v275 = v274 and table.find(v274, v_u_273)
		if v275 then
			table.remove(v274, v275)
		end
	end
end
function v_u_12.hint(p276) -- name: hint
	-- upvalues: (copy) v_u_19, (ref) v_u_29, (copy) v_u_16, (copy) v_u_18, (copy) v_u_15, (copy) v_u_22, (copy) v_u_138, (copy) v_u_20, (copy) v_u_70, (copy) v_u_17
	local v277 = v_u_19[p276]
	if v277 then
		if v_u_29 == "Touch" then
			return v277.touch
		end
		if v_u_29 == "Gamepad" then
			local v278 = v277.pad[1]
			return v_u_16[v278.Name] or string.gsub(v278.Name, "^Button", "")
		end
		local v279 = v277.keys[1]
		local v280 = v277.mouse[1]
		return (v_u_16[v279.Name] or v279.Name) .. " + " .. (v_u_18[v280.Name] or v280.Name)
	else
		local v281 = v_u_15[p276]
		if v_u_29 == "Touch" then
			if p276 == "fire" then
				local v282 = v_u_22:GetAttribute("TouchFireHint")
				if type(v282) == "string" and v282 ~= "" then
					return v282
				end
			end
			if p276 == "aim" then
				local v283 = v_u_138.ctx.fptp
				local v284
				if v283 == nil then
					v284 = false
				else
					local v285
					v284, v285 = pcall(v283)
					if v284 then
						v284 = v285 == true
					end
				end
				if v284 then
					return "ADS"
				end
			end
			return v_u_20[p276] or "Tap"
		else
			local v286 = v_u_70.moveBinds[p276]
			if v286 then
				return (v_u_29 ~= "Keyboard" or not v286[1]) and "" or v_u_70.name(v286[1])
			elseif v281 then
				if v_u_29 == "Gamepad" then
					local v287 = v281.pad[1]
					local v288 = v281.padWhen
					if v288 then
						v288 = v_u_17[v281.padWhen]
					end
					if v287 and v288 then
						return (v_u_16[v288.Name] or v288.Name) .. " + " .. (v_u_16[v287.Name] or string.gsub(v287.Name, "^Button", ""))
					end
					if not v287 and p276 == "meleeSlot" then
						v287 = v_u_15.swap.pad[1]
					end
					if not v287 and (v281.padHold and v281.padHold[1]) then
						local v289 = v281.padHold[1]
						return "Hold " .. (v_u_16[v289.Name] or string.gsub(v289.Name, "^Button", ""))
					end
					if v287 or p276 ~= "fireMode" then
						return not v287 and "" or (v_u_16[v287.Name] or string.gsub(v287.Name, "^Button", ""))
					end
					local v290 = v_u_15.reload.pad[1]
					return not v290 and "" or "Hold " .. (v_u_16[v290.Name] or string.gsub(v290.Name, "^Button", ""))
				elseif p276 == "zoom" then
					return "Wheel"
				else
					local v291 = v281.kmOrder
					if v291 then
						return not v291[1] and "" or v_u_70.name(v291[1])
					else
						local v292 = v281.mouse[1]
						if v292 and #v281.keys == 0 then
							return v_u_18[v292.Name] or v292.Name
						else
							local v293 = v281.keys[1]
							if v293 then
								return v_u_16[v293.Name] or v293.Name
							else
								return not v292 and "" or (v_u_18[v292.Name] or v292.Name)
							end
						end
					end
				end
			else
				return ""
			end
		end
	end
end
function v_u_12.device() -- name: device
	-- upvalues: (ref) v_u_29
	return v_u_29
end
function v_u_12.setPadChordSwallow(p294) -- name: setPadChordSwallow
	-- upvalues: (ref) v_u_67
	v_u_67 = p294 == true
end
function v_u_12.moveVector() -- name: moveVector
	-- upvalues: (ref) v_u_36
	return v_u_36
end
function v_u_12.aimPoint() -- name: aimPoint
	-- upvalues: (ref) v_u_39
	return v_u_39
end
function v_u_12.aimYaw() -- name: aimYaw
	-- upvalues: (ref) v_u_37
	return v_u_37
end
function v_u_12.aimDir() -- name: aimDir
	-- upvalues: (ref) v_u_37
	local v295 = v_u_37
	local v296 = -math.sin(v295)
	local v297 = v_u_37
	local v298 = -math.cos(v297)
	return Vector3.new(v296, 0, v298)
end
function v_u_12.isSprinting() -- name: isSprinting
	-- upvalues: (ref) v_u_31, (ref) v_u_28
	local v299 = v_u_31
	if v299 then
		v299 = v_u_28
	end
	return v299
end
function v_u_12.gameBlocked() -- name: gameBlocked
	-- upvalues: (ref) v_u_28, (copy) v_u_108
	return not v_u_28 or v_u_108()
end
function v_u_12.isSneaking() -- name: isSneaking
	-- upvalues: (ref) v_u_32
	return v_u_32
end
function v_u_12.isAiming() -- name: isAiming
	-- upvalues: (ref) v_u_33, (ref) v_u_28
	local v300 = v_u_33
	if v300 then
		v300 = v_u_28
	end
	return v300
end
function v_u_12.isFiring() -- name: isFiring
	-- upvalues: (ref) v_u_34, (ref) v_u_28
	local v301 = v_u_34
	if v301 then
		v301 = v_u_28
	end
	return v301
end
function v_u_12.isActive(p302) -- name: isActive
	-- upvalues: (copy) v_u_27
	return v_u_27[p302] == true
end
function v_u_12.setToggle(p303, p304) -- name: setToggle
	-- upvalues: (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33
	if p303 == "sprint" then
		v_u_31 = p304
		if p304 then
			v_u_32 = false
		end
	elseif p303 == "sneak" then
		v_u_32 = p304
		if p304 then
			v_u_31 = false
		end
	end
	if v_u_25 then
		v_u_25:setToggle("sprint", v_u_31)
		v_u_25:setToggle("sneak", v_u_32)
		v_u_25:setToggle("aim", v_u_33)
	end
end
function v_u_12.setAimOverride(p305) -- name: setAimOverride
	-- upvalues: (ref) v_u_41, (copy) v_u_50, (ref) v_u_47, (ref) v_u_48
	if p305 == nil then
		v_u_41 = nil
	else
		local v306 = typeof(p305) == "Vector3"
		assert(v306, "setAimOverride expects a Vector3 or nil")
		local v307
		if p305.X == p305.X and p305.Z == p305.Z then
			local v308 = p305.X
			if math.abs(v308) < 1000000 then
				local v309 = p305.Z
				v307 = math.abs(v309) < 1000000
			else
				v307 = false
			end
		else
			v307 = false
		end
		assert(v307, "setAimOverride: point not finite")
		v_u_41 = p305
		v_u_50.yaw = 999
		if v_u_47 then
			v_u_47.invalidate(v_u_48)
		end
	end
end
function v_u_12.setEnabled(p310) -- name: setEnabled
	-- upvalues: (ref) v_u_28, (copy) v_u_27, (copy) v_u_15, (copy) v_u_138, (ref) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33, (ref) v_u_34, (copy) v_u_99, (copy) v_u_254
	if v_u_28 ~= p310 then
		v_u_28 = p310
		if not p310 then
			for v311 in table.clone(v_u_27) do
				local v312 = v_u_15[v311]
				if v312 and v312.ui then
					continue
				end
				if v_u_138.eaten[v311] then
					v_u_138.eaten[v311] = nil
				else
					local v313 = v_u_29
					if v311 == "sprint" then
						if v313 == "Keyboard" or v313 == "Touch" then
							v_u_31 = false
						end
						if v_u_31 then
							v_u_32 = false
						end
						if v_u_25 then
							v_u_25:setToggle("sprint", v_u_31)
							v_u_25:setToggle("sneak", v_u_32)
							v_u_25:setToggle("aim", v_u_33)
						end
					elseif v311 ~= "sneak" then
						if v311 == "aim" then
							v_u_33 = false
						elseif v311 == "fire" then
							v_u_34 = false
						end
					end
					v_u_99(v311, false, nil)
				end
			end
			v_u_33 = false
			v_u_34 = false
			if v_u_29 == "Keyboard" then
				v_u_31 = false
			end
			if v_u_25 then
				v_u_25:setToggle("sprint", v_u_31)
				v_u_25:setToggle("sneak", v_u_32)
				v_u_25:setToggle("aim", v_u_33)
			end
		end
		v_u_254()
	end
end
function v_u_12.touchButton(p314, p315) -- name: touchButton
	-- upvalues: (ref) v_u_25
	if v_u_25 then
		return v_u_25:addButton(p314, p315 or {})
	else
		return nil
	end
end
function v_u_12.touch() -- name: touch
	-- upvalues: (ref) v_u_25
	return v_u_25
end
function v_u_12.setTouchLightMain(p316) -- name: setTouchLightMain
	-- upvalues: (copy) v_u_12, (copy) v_u_20, (ref) v_u_25
	local v317 = p316 == true
	v_u_12._lightMain = v317
	v_u_20.flashlight = v317 and "Light" or "More"
	if v_u_25 and v_u_25.setLightMain then
		v_u_25:setLightMain(v317)
	end
end
function v_u_12.fireRepeat() -- name: fireRepeat
	-- upvalues: (ref) v_u_34, (ref) v_u_28, (ref) v_u_29, (ref) v_u_25
	local v318 = v_u_34 and v_u_28
	if v318 then
		if v_u_29 == "Touch" and v_u_25 ~= nil then
			v318 = v_u_25:triggerHeld() == true
		else
			v318 = false
		end
	end
	return v318
end
function v_u_12.aimSentAge() -- name: aimSentAge
	-- upvalues: (ref) v_u_37, (ref) v_u_57, (ref) v_u_58
	local v319 = (v_u_37 - v_u_57 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	return math.abs(v319) > 0.2 and 0 or os.clock() - v_u_58
end
function v_u_12.touchRects() -- name: touchRects
	-- upvalues: (ref) v_u_25, (copy) v_u_138
	if not (v_u_25 and v_u_25.visible) then
		return {}
	end
	local v320 = v_u_25.clusterRects
	local v321 = v_u_25
	local v322, v323 = pcall(v320, v321)
	local v324 = (not v322 or type(v323) ~= "table") and {} or v323
	for v325, v326 in v_u_138.tapRects do
		local v327, v328 = pcall(v326)
		if not v327 or typeof(v328) ~= "Rect" then
			continue
		end
		v324[v325] = v328
	end
	return v324
end
function v_u_12.setTapRect(p329, p330) -- name: setTapRect
	-- upvalues: (copy) v_u_138
	local v331 = v_u_138.tapRects
	if type(p330) ~= "function" then
		p330 = nil
	end
	v331[p329] = p330
end
function v_u_12.setContext(p332, p333) -- name: setContext
	-- upvalues: (copy) v_u_138
	if type(p332) == "string" and p332 ~= "" then
		local v334 = v_u_138.ctx
		if type(p333) ~= "function" then
			p333 = nil
		end
		v334[p332] = p333
	end
end
function v_u_12.setPressFilter(p335, p336) -- name: setPressFilter
	-- upvalues: (copy) v_u_138
	if type(p335) == "string" and p335 ~= "" then
		local v337 = v_u_138.filters
		if type(p336) ~= "function" then
			p336 = nil
		end
		v337[p335] = p336
	end
end
function v_u_12.setAimProvider(p338) -- name: setAimProvider
	-- upvalues: (copy) v_u_138
	if type(p338) == "table" then
		local v339 = p338.step
		if type(v339) == "function" then
			v_u_138.provider = p338
			return
		end
	end
	v_u_138.provider = nil
	v_u_138.pitch = 0
	v_u_138.pitchSend = nil
end
function v_u_12.aimPitch() -- name: aimPitch
	-- upvalues: (copy) v_u_138
	return v_u_138.provider == nil and 0 or v_u_138.pitch
end
function v_u_12.rawLook() -- name: rawLook
	-- upvalues: (ref) v_u_29, (ref) v_u_28, (copy) v_u_108, (ref) v_u_61, (ref) v_u_25
	local v340 = Vector2.zero
	if v_u_29 == "Gamepad" and (v_u_28 and not v_u_108()) then
		local v341 = v_u_61
		local v342 = v341.Magnitude
		if v342 < 0.15 then
			v340 = Vector2.zero
		else
			local v343 = v341.Unit
			local v344 = (v342 - 0.15) / 0.85
			v340 = v343 * math.clamp(v344, 0, 1)
		end
	end
	local v345 = nil
	if v_u_29 == "Touch" and v_u_25 ~= nil and (v_u_28 and not v_u_108()) then
		local v_u_346 = v_u_25
		local v347, v348 = pcall(function()
			-- upvalues: (copy) v_u_346
			return not v_u_346.aimHeldNow and true or v_u_346:aimHeldNow()
		end)
		if v347 and v348 == true then
			local v349, v350 = pcall(function()
				-- upvalues: (copy) v_u_346
				return v_u_346:aimVector()
			end)
			if v349 and typeof(v350) == "Vector2" then
				local v351, v352 = pcall(function()
					-- upvalues: (copy) v_u_346
					return v_u_346:aimDeflection()
				end)
				v345 = v350 * ((not v351 or type(v352) ~= "number") and 1 or math.clamp(v352, 0, 1))
			end
		end
	end
	return v340, v345
end
local v_u_353 = {}
local v_u_354 = {
	[v_u_13.W] = Vector2.new(0, 1),
	[v_u_13.Up] = Vector2.new(0, 1),
	[v_u_13.S] = Vector2.new(0, -1),
	[v_u_13.Down] = Vector2.new(0, -1),
	[v_u_13.D] = Vector2.new(1, 0),
	[v_u_13.Right] = Vector2.new(1, 0),
	[v_u_13.A] = Vector2.new(-1, 0),
	[v_u_13.Left] = Vector2.new(-1, 0)
}
v_u_70.MOVE = {
	["moveUp"] = Vector2.new(0, 1),
	["moveDown"] = Vector2.new(0, -1),
	["moveLeft"] = Vector2.new(-1, 0),
	["moveRight"] = Vector2.new(1, 0)
}
v_u_70.moveBinds = {
	["moveUp"] = { "W", "Up" },
	["moveDown"] = { "S", "Down" },
	["moveLeft"] = { "A", "Left" },
	["moveRight"] = { "D", "Right" }
}
v_u_70.MOUSE = {
	["MouseButton1"] = true,
	["MouseButton2"] = true,
	["MouseButton3"] = true
}
v_u_70.RESERVED = {
	["Escape"] = true,
	["F2"] = true,
	["F8"] = true,
	["F9"] = true,
	["F10"] = true,
	["F11"] = true,
	["F12"] = true,
	["Unknown"] = true,
	["Slash"] = true,
	["LeftSuper"] = true,
	["RightSuper"] = true,
	["LeftMeta"] = true,
	["RightMeta"] = true,
	["Menu"] = true,
	["Print"] = true,
	["SysReq"] = true,
	["Break"] = true,
	["Pause"] = true,
	["Power"] = true,
	["Help"] = true,
	["Mode"] = true,
	["Compose"] = true,
	["NumLock"] = true,
	["ScrollLock"] = true
}
v_u_70.MAX_PER_ACTION = 2
function v_u_70.ids() -- name: ids
	-- upvalues: (copy) v_u_70, (copy) v_u_15
	if v_u_70._ids then
		return v_u_70._ids
	end
	local v355 = {}
	local v356 = {
		"moveUp",
		"moveDown",
		"moveLeft",
		"moveRight"
	}
	for v357, v358 in v_u_15 do
		if #v358.keys + #v358.mouse <= 0 then
			continue
		end
		table.insert(v355, v357)
	end
	table.sort(v355)
	for _, v359 in v355 do
		table.insert(v356, v359)
	end
	v_u_70._ids = v356
	return v356
end
function v_u_70.list(p360) -- name: list
	-- upvalues: (copy) v_u_70, (copy) v_u_15
	local v361 = v_u_70.moveBinds[p360]
	if v361 then
		return table.clone(v361)
	end
	local v362 = v_u_15[p360]
	if not v362 then
		return nil
	end
	if v362.kmOrder then
		return table.clone(v362.kmOrder)
	end
	local v363 = {}
	for _, v364 in v362.keys do
		local v365 = v364.Name
		table.insert(v363, v365)
	end
	for _, v366 in v362.mouse do
		local v367 = v366.Name
		table.insert(v363, v367)
	end
	return v363
end
v_u_70.DEFAULT = {}
local v_u_368 = v_u_48
local v_u_369 = v_u_32
local v_u_370 = v_u_37
local v_u_371 = v_u_67
local v_u_372 = v_u_34
local v_u_373 = v_u_39
local v_u_374 = v_u_58
local v_u_375 = v_u_31
local v_u_376 = v_u_43
local v_u_377 = v_u_42
local v_u_378 = v_u_61
local v_u_379 = v_u_47
local v_u_380 = v_u_21
local v_u_381 = v_u_57
local v_u_382 = v_u_33
local v_u_383 = v_u_36
local v_u_384 = v_u_60
local v_u_385 = v_u_68
local v_u_386 = v_u_202
local v_u_387 = v_u_30
local v_u_388 = v_u_41
local v_u_389 = v_u_73
local v_u_390 = v_u_25
local v_u_391 = v_u_28
local v_u_392 = v_u_29
local function v_u_401() -- name: keyboardMove
	-- upvalues: (copy) v_u_4, (copy) v_u_353, (copy) v_u_354
	if v_u_4:GetFocusedTextBox() then
		return Vector2.zero
	else
		local v393 = Vector2.zero
		for v394 in v_u_353 do
			local v395 = v_u_354[v394]
			if not v395 then
				continue
			end
			v393 = v393 + v395
		end
		local v396 = Vector2.new
		local v397 = v393.X
		local v398 = math.clamp(v397, -1, 1)
		local v399 = v393.Y
		local v400 = v396(v398, (math.clamp(v399, -1, 1)))
		if v400.Magnitude > 1 then
			return v400.Unit
		else
			return v400
		end
	end
end
for _, v402 in v_u_70.ids() do
	v_u_70.DEFAULT[v402] = v_u_70.list(v402)
end
function v_u_70.enum(p_u_403) -- name: enum
	-- upvalues: (copy) v_u_70
	if v_u_70.MOUSE[p_u_403] then
		return Enum.UserInputType[p_u_403]
	else
		local v404, v405 = pcall(function()
			-- upvalues: (copy) p_u_403
			return Enum.KeyCode[p_u_403]
		end)
		if v404 then
			return v405
		else
			return nil
		end
	end
end
function v_u_70.valid(p406) -- name: valid
	-- upvalues: (copy) v_u_70
	if type(p406) == "string" and (#p406 ~= 0 and (#p406 <= 24 and not v_u_70.RESERVED[p406])) then
		if v_u_70.MOUSE[p406] then
			return true
		elseif string.match(p406, "^Button") or (string.match(p406, "^DPad") or string.match(p406, "^Thumbstick")) then
			return false
		else
			return v_u_70.enum(p406) ~= nil
		end
	else
		return false
	end
end
function v_u_70.name(p407) -- name: name
	-- upvalues: (copy) v_u_18, (copy) v_u_16
	if p407 == nil or p407 == "" then
		return "-"
	elseif v_u_18[p407] then
		return v_u_18[p407]
	elseif v_u_16[p407] then
		return v_u_16[p407]
	else
		local v408 = string.match(p407, "^Keypad(.+)$")
		if v408 then
			return "Num " .. (v_u_16[v408] or v408)
		else
			return p407
		end
	end
end
function v_u_70.put(p409, p410) -- name: put
	-- upvalues: (copy) v_u_70, (copy) v_u_15
	local v411 = {}
	for _, v412 in p410 do
		if not v_u_70.valid(v412) or (table.find(v411, v412) or #v411 >= v_u_70.MAX_PER_ACTION) then
			continue
		end
		table.insert(v411, v412)
	end
	if v_u_70.moveBinds[p409] then
		local v413 = {}
		for _, v414 in v411 do
			if v_u_70.MOUSE[v414] then
				continue
			end
			table.insert(v413, v414)
		end
		v_u_70.moveBinds[p409] = v413
		return
	else
		local v415 = v_u_15[p409]
		if v415 then
			local v416 = {}
			local v417 = {}
			for _, v418 in v411 do
				local v419 = v_u_70.enum(v418)
				if v_u_70.MOUSE[v418] then
					table.insert(v416, v419)
				else
					if not v419 then
						continue
					end
					table.insert(v417, v419)
				end
			end
			v415.keys = v417
			v415.mouse = v416
			v415.kmOrder = v411
		end
	end
end
function v_u_70.encode() -- name: encode
	-- upvalues: (copy) v_u_70
	local v420 = {}
	for _, v421 in v_u_70.ids() do
		local v422 = v_u_70.list(v421) or {}
		local v423 = v_u_70.DEFAULT[v421] or {}
		local v424
		if #v422 == #v423 then
			for v425, v426 in v422 do
				if v423[v425] == v426 then
					continue
				end
				v424 = false
			end
			v424 = true
		else
			v424 = false
		end
		if v424 then
			continue
		end
		local v427 = v421 .. "_" .. (#v422 <= 0 and "None" or table.concat(v422, "_"))
		table.insert(v420, v427)
	end
	return table.concat(v420, ",")
end
function v_u_70.decode(p428) -- name: decode
	-- upvalues: (copy) v_u_70
	local v429 = {}
	if type(p428) ~= "string" then
		return v429
	end
	for v430 in string.gmatch(p428, "[^,]+") do
		local v431 = string.split(v430, "_")
		local v432 = v431[1]
		if not v_u_70.DEFAULT[v432] or v429[v432] ~= nil then
			continue
		end
		local v433 = #v431
		local v434 = 1 + v_u_70.MAX_PER_ACTION
		local v435 = {}
		for v436 = 2, math.min(v433, v434) do
			if v431[v436] == "None" or not v_u_70.valid(v431[v436]) then
				continue
			end
			local v437 = v431[v436]
			table.insert(v435, v437)
		end
		v429[v432] = v435
	end
	return v429
end
function v_u_70.commit() -- name: commit
	-- upvalues: (copy) v_u_27, (copy) v_u_148, (copy) v_u_353, (copy) v_u_354, (copy) v_u_70, (copy) v_u_22, (copy) v_u_12, (ref) v_u_392
	for v438 in table.clone(v_u_27) do
		local v439 = v_u_148
		pcall(v439, v438, false)
	end
	table.clear(v_u_353)
	table.clear(v_u_354)
	for v440, v441 in v_u_70.moveBinds do
		for _, v442 in v441 do
			local v443 = v_u_70.enum(v442)
			if not v443 or v_u_70.MOUSE[v442] then
				continue
			end
			v_u_354[v443] = v_u_70.MOVE[v440]
		end
	end
	v_u_70.moveCustom = false
	for v444, v445 in v_u_70.moveBinds do
		local v446 = v_u_70.DEFAULT[v444] or {}
		local v447
		if #v445 == #v446 then
			for v448, v449 in v445 do
				if v446[v448] == v449 then
					continue
				end
				v447 = false
			end
			v447 = true
		else
			v447 = false
		end
		if v447 then
			continue
		end
		v_u_70.moveCustom = true
	end
	v_u_70.current = v_u_70.encode()
	v_u_22:SetAttribute("KeyBinds", v_u_70.current)
	v_u_12.bindingsChanged:Fire(v_u_70.current)
	v_u_12.deviceChanged:Fire(v_u_392)
end
v_u_70.keepReasserts = 0
function v_u_70.keepKeyMove() -- name: keepKeyMove
	-- upvalues: (copy) v_u_70, (ref) v_u_392, (ref) v_u_391, (ref) v_u_377, (copy) v_u_22, (ref) v_u_376, (copy) v_u_74
	if v_u_70.moveCustom and (v_u_392 == "Keyboard" and v_u_391) then
		local v450 = v_u_377
		if not v450 then
			if v_u_22.Character == nil then
				v450 = false
			else
				v450 = v_u_376 ~= "Transit"
			end
		end
		if v450 and os.clock() - v_u_74.at <= 0.25 then
			local v451 = v_u_22.Character
			local v452
			if v451 and v451.Parent then
				v452 = v451:FindFirstChildOfClass("Humanoid")
				v451:FindFirstChild("HumanoidRootPart")
			else
				v451 = nil
				v452 = nil
			end
			if v451 and (v452 and (v452.Health > 0 and v451:GetAttribute("Dead") ~= true)) then
				local v453 = v451:GetAttribute("Action")
				local v454 = v_u_22:GetAttribute("PredAction")
				if v453 ~= "Revive" and (v453 ~= "Climb" and (v453 ~= "Vault" and (type(v454) ~= "string" or v454 == ""))) then
					v452:Move(v_u_74.mv, false)
					local v455 = v_u_70
					v455.keepReasserts = v455.keepReasserts + 1
				end
			else
				return
			end
		end
	end
end
function v_u_70.conflicts(p456, p457) -- name: conflicts
	-- upvalues: (copy) v_u_15, (copy) v_u_70
	local v458 = {}
	for _, v459 in v_u_70.ids() do
		if v459 == p456 then
			continue
		end
		local v460 = v_u_70.list(v459) or {}
		if not table.find(v460, p457) then
			continue
		end
		local v461, v462, v463
		if v459 == "rotateItem" then
			local v464 = v_u_15[p456]
			local v465
			if v464 == nil then
				v465 = false
			else
				v465 = v464.ui == true
			end
			if v465 or v_u_70.moveBinds[p456] ~= nil then
				if p456 == "rotateItem" then
					v461 = v_u_15[v459]
					if v461 == nil then
						v462 = false
					else
						v462 = v461.ui == true
					end
					v463 = not v462
					if v463 then
						v463 = v_u_70.moveBinds[v459] == nil
					end
				else
					v463 = false
				end
				if v463 then
					continue
				end
				table.insert(v458, v459)
			else
				v463 = true
				if v463 then
					continue
				end
				table.insert(v458, v459)
			end
		else
			if p456 == "rotateItem" then
				v461 = v_u_15[v459]
				if v461 == nil then
					v462 = false
				else
					v462 = v461.ui == true
				end
				v463 = not v462
				if v463 then
					v463 = v_u_70.moveBinds[v459] == nil
				end
			else
				v463 = false
			end
			if v463 then
				continue
			end
			table.insert(v458, v459)
		end
	end
	return v458
end
v_u_12.bindingsChanged = v9.new()
function v_u_12.keyBindIds() -- name: keyBindIds
	-- upvalues: (copy) v_u_70
	return table.clone(v_u_70.ids())
end
function v_u_12.keyBinding(p466) -- name: keyBinding
	-- upvalues: (copy) v_u_70
	return v_u_70.list(p466)
end
function v_u_12.keyDefault(p467) -- name: keyDefault
	-- upvalues: (copy) v_u_70
	local v468 = v_u_70.DEFAULT[p467]
	if v468 then
		return table.clone(v468)
	else
		return nil
	end
end
function v_u_12.keyName(p469) -- name: keyName
	-- upvalues: (copy) v_u_70
	return v_u_70.name(p469)
end
function v_u_12.keyValid(p470) -- name: keyValid
	-- upvalues: (copy) v_u_70
	return v_u_70.valid(p470)
end
function v_u_12.keyReserved(p471) -- name: keyReserved
	-- upvalues: (copy) v_u_70
	local v472
	if type(p471) == "string" then
		v472 = v_u_70.RESERVED[p471] == true
	else
		v472 = false
	end
	return v472
end
function v_u_12.keyConflicts(p473, p474) -- name: keyConflicts
	-- upvalues: (copy) v_u_70
	return v_u_70.conflicts(p473, p474)
end
function v_u_12.rebindKey(p475, p476, p477, p478) -- name: rebindKey
	-- upvalues: (copy) v_u_70
	local v479 = v_u_70.list(p475)
	if v479 then
		local v480 = tonumber(p476) or 1
		local v481 = math.floor(v480)
		local v482 = v_u_70.MAX_PER_ACTION
		local v483 = math.clamp(v481, 1, v482)
		if p477 == nil then
			if v479[v483] then
				table.remove(v479, v483)
				v_u_70.put(p475, v479)
				v_u_70.commit()
			end
			return true, nil
		elseif v_u_70.valid(p477) and not (v_u_70.moveBinds[p475] and v_u_70.MOUSE[p477]) then
			if v479[v483] == p477 then
				return true, nil
			end
			local v484 = v_u_70.conflicts(p475, p477)
			if #v484 > 0 and not p478 then
				return false, v484
			end
			local v485 = v479[v483]
			local v486 = table.find(v479, p477)
			local v487
			if v486 then
				v479[v486] = v479[v483]
				v479[v483] = p477
				v487 = {}
				for v488 = 1, v_u_70.MAX_PER_ACTION do
					if not v479[v488] then
						continue
					end
					local v489 = v479[v488]
					table.insert(v487, v489)
				end
			elseif #v479 < v483 then
				table.insert(v479, p477)
				v487 = v479
			else
				v479[v483] = p477
				v487 = v479
			end
			for _, v490 in v484 do
				local v491 = v_u_70.list(v490) or {}
				local v492 = table.find(v491, p477)
				if not v492 then
					continue
				end
				if v485 and (not table.find(v491, v485) and (#v_u_70.conflicts(v490, v485) <= 1 and not (v_u_70.moveBinds[v490] and v_u_70.MOUSE[v485]))) then
					v491[v492] = v485
				else
					table.remove(v491, v492)
				end
				v_u_70.put(v490, v491)
			end
			v_u_70.put(p475, v487)
			v_u_70.commit()
			return true, nil
		else
			local v493 = false
			if v_u_70.RESERVED[p477] then
				return v493, "reserved"
			else
				return v493, "invalid"
			end
		end
	else
		return false, "unknown action"
	end
end
function v_u_12.resetKeys(p494) -- name: resetKeys
	-- upvalues: (copy) v_u_70
	for _, v495 in v_u_70.ids() do
		if p494 ~= nil and p494 ~= v495 then
			continue
		end
		v_u_70.put(v495, v_u_70.DEFAULT[v495])
	end
	v_u_70.commit()
end
function v_u_12.loadKeyBindings(p496) -- name: loadKeyBindings
	-- upvalues: (copy) v_u_70
	v_u_70.loaded = true
	local v497 = v_u_70.decode(p496)
	for _, v498 in v_u_70.ids() do
		v_u_70.put(v498, v497[v498] or v_u_70.DEFAULT[v498])
	end
	v_u_70.commit()
end
function v_u_12.keyBindingString() -- name: keyBindingString
	-- upvalues: (copy) v_u_70
	return v_u_70.current
end
function v_u_12.captureKey(p499, p500) -- name: captureKey
	-- upvalues: (copy) v_u_70
	if v_u_70.capture then
		local v501 = v_u_70.capture
		v_u_70.capture = nil
		task.spawn(v501.fn, nil, nil)
	end
	local v_u_502 = {
		["fn"] = p499,
		["onReserved"] = p500,
		["t0"] = os.clock()
	}
	v_u_70.capture = v_u_502
	task.delay(10, function()
		-- upvalues: (ref) v_u_70, (copy) v_u_502
		if v_u_70.capture == v_u_502 then
			v_u_70.capture = nil
			task.spawn(v_u_502.fn, nil, nil)
		end
	end)
	return function()
		-- upvalues: (ref) v_u_70, (copy) v_u_502
		if v_u_70.capture == v_u_502 then
			v_u_70.capture = nil
		end
	end
end
function v_u_12.capturing() -- name: capturing
	-- upvalues: (copy) v_u_70
	return v_u_70.capture ~= nil
end
function v_u_70.captureIo(p503) -- name: captureIo
	-- upvalues: (copy) v_u_70, (copy) v_u_4, (copy) v_u_13
	local v504 = v_u_70.capture
	if not v504 then
		return false
	end
	local v505 = p503.UserInputType
	v_u_70.lastIo = p503
	if v505 == Enum.UserInputType.Keyboard then
		if v_u_4:GetFocusedTextBox() then
			return false
		end
		local v506 = p503.KeyCode.Name
		if v506 == "Escape" then
			v_u_70.capture = nil
			local v507 = p503.Position
			local v508 = task.spawn
			local v509 = v504.fn
			local v510 = nil
			local v511
			if typeof(v507) == "Vector3" then
				v511 = Vector2.new(v507.X, v507.Y)
			else
				v511 = nil
			end
			v508(v509, v510, v511)
		elseif v_u_70.RESERVED[v506] or not v_u_70.valid(v506) then
			if v504.onReserved then
				task.spawn(v504.onReserved, v506)
			end
		else
			v_u_70.capture = nil
			local v512 = p503.Position
			local v513 = task.spawn
			local v514 = v504.fn
			local v515
			if typeof(v512) == "Vector3" then
				v515 = Vector2.new(v512.X, v512.Y)
			else
				v515 = nil
			end
			v513(v514, v506, v515)
		end
		return true
	end
	if v_u_70.MOUSE[v505.Name] then
		if os.clock() - v504.t0 < 0.15 then
			return true
		end
		local v516 = v505.Name
		v_u_70.capture = nil
		local v517 = p503.Position
		local v518 = task.spawn
		local v519 = v504.fn
		local v520
		if typeof(v517) == "Vector3" then
			v520 = Vector2.new(v517.X, v517.Y)
		else
			v520 = nil
		end
		v518(v519, v516, v520)
		return true
	end
	local v521
	if v505 == Enum.UserInputType.Gamepad1 then
		v521 = true
	else
		local v522 = v505.Name
		v521 = string.sub(v522, 1, 7) == "Gamepad"
	end
	if not v521 or p503.KeyCode ~= v_u_13.ButtonB then
		return false
	end
	v_u_70.capture = nil
	local v523 = p503.Position
	local v524 = task.spawn
	local v525 = v504.fn
	local v526 = nil
	local v527
	if typeof(v523) == "Vector3" then
		v527 = Vector2.new(v523.X, v523.Y)
	else
		v527 = nil
	end
	v524(v525, v526, v527)
	return false
end
function v_u_70.fetch() -- name: fetch
	-- upvalues: (copy) v_u_70, (ref) v_u_380, (copy) v_u_12
	if not v_u_70.loaded and (not v_u_70.fetching and v_u_380) then
		v_u_70.fetching = true
		task.spawn(function()
			-- upvalues: (ref) v_u_380, (ref) v_u_70, (ref) v_u_12
			for v528 = 1, 3 do
				local v529 = v_u_380.net.invoke
				local v530, v531 = pcall(v529, "menu.get", {
					["what"] = "settings"
				})
				if v530 and (type(v531) == "table" and v531.error == nil) then
					if not v_u_70.loaded then
						local v532 = v_u_12.loadKeyBindings
						local v533 = v531.keybinds
						v532(type(v533) ~= "string" and "" or v531.keybinds)
					end
					break
				end
				task.wait(v528 * 2)
			end
			v_u_70.fetching = false
		end)
	end
end
local function v_u_554() -- name: refreshZombieCache
	-- upvalues: (ref) v_u_64, (copy) v_u_62, (copy) v_u_63, (ref) v_u_380, (copy) v_u_22
	local v534 = os.clock()
	if v534 - v_u_64 < 0.2 then
		return
	else
		v_u_64 = v534
		table.clear(v_u_62)
		table.clear(v_u_63)
		local v535 = v_u_380
		if v535 then
			v535 = v_u_380.controllers.ZombieRender
		end
		if v535 then
			local v536 = v_u_22.Character
			local v537
			if v536 and v536.Parent then
				v536:FindFirstChildOfClass("Humanoid")
				v537 = v536:FindFirstChild("HumanoidRootPart")
			else
				v537 = nil
			end
			for _, v538 in { "targets", "visibleTargets", "positions" } do
				local v539 = v535[v538]
				if type(v539) ~= "function" then
					continue
				end
				local v540, v541
				if v537 then
					local v542 = v537.Position
					v540, v541 = pcall(v539, v542, 70)
				else
					v540, v541 = pcall(v539)
				end
				if not v540 or type(v541) ~= "table" then
					continue
				end
				for _, v543 in v541 do
					local v544 = nil
					local v545 = nil
					if typeof(v543) == "Vector3" then
						v544 = v543
					elseif typeof(v543) == "Instance" and v543:IsA("Model") then
						v544 = v543:GetPivot().Position
					elseif type(v543) == "table" then
						local v546 = v543.position
						if typeof(v546) == "Vector3" then
							v544 = v543.position
							local v547 = v543.visible
							if type(v547) == "boolean" then
								v545 = v543.visible
							end
						end
					end
					if v544 and v545 ~= false then
						local v548 = v_u_62
						table.insert(v548, v544)
						if v545 ~= nil then
							v_u_63[#v_u_62] = v545
						end
					end
					if #v_u_62 < 80 then
						continue
					end
					return
				end
				return
			end
		end
		local v549 = workspace:FindFirstChild("HushLocal")
		if v549 then
			for _, v550 in v549:GetDescendants() do
				local v551 = v550:IsA("Model") and (v550:GetAttribute("ZombieId") ~= nil and (v550:GetAttribute("Dead") ~= true and v550:GetAttribute("Corpse") ~= true)) and v550:FindFirstChild("HumanoidRootPart")
				if v551 then
					local v552 = v_u_62
					local v553 = v551.Position
					table.insert(v552, v553)
				end
				if #v_u_62 <= 80 then
					continue
				end
				return
			end
		end
	end
end
local function v_u_576(p555, p556, p557, p558) -- name: magnet
	-- upvalues: (copy) v_u_554, (ref) v_u_380, (copy) v_u_62, (copy) v_u_63
	v_u_554()
	local v559 = nil
	local v560 = p557 or 0.13962634015954636
	local v561 = v_u_380
	if v561 then
		v561 = v_u_380.controllers.Vision
	end
	for v562, v563 in v_u_62 do
		local v564 = v563.X - p555.Position.X
		local v565 = v563.Z - p555.Position.Z
		local v566 = Vector3.new(v564, 0, v565)
		local v567 = v566.Magnitude
		if v567 <= 1 or v567 >= 70 then
			continue
		end
		local v568 = v566.Unit:Dot(p556)
		local v569 = math.clamp(v568, -1, 1)
		local v570 = math.acos(v569)
		if v570 >= v560 then
			continue
		end
		local v571 = true
		local v572 = v_u_63[v562]
		if v572 == nil then
			if v561 and v561.isVisible then
				local v573 = v561.isVisible
				local v574, v575 = pcall(v573, v563)
				v571 = not v574 or v575 == true
			end
		else
			v571 = v572
		end
		if not v571 then
			continue
		end
		v559 = v566.Unit
		v560 = v570
	end
	if v559 then
		return p556:Lerp(v559, p558 or 0.75).Unit
	else
		return p556
	end
end
local v_u_577 = {
	["Touch"] = {
		["cone"] = 0.19198621771937624,
		["pull"] = 0.7,
		["stick"] = 0.2792526803190927
	},
	["Gamepad"] = {
		["cone"] = 0.13962634015954636,
		["pull"] = 0.5,
		["stick"] = 0.20943951023931956
	}
}
local function v_u_613(p578, p579, p580) -- name: assistAim
	-- upvalues: (copy) v_u_554, (ref) v_u_380, (copy) v_u_69, (copy) v_u_62, (copy) v_u_63
	v_u_554()
	local v581 = v_u_380
	if v581 then
		v581 = v_u_380.controllers.Vision
	end
	local v582 = p578.Position
	local v583 = v_u_69.assistLock
	local v584 = (1 / 0)
	local v585 = nil
	local v586 = 0
	for v587, v588 in v_u_62 do
		local v589 = v588.X - v582.X
		local v590 = v588.Z - v582.Z
		local v591 = Vector3.new(v589, 0, v590)
		local v592 = v591.Magnitude
		if v592 <= 1.5 or v592 >= 70 then
			continue
		end
		local v593 = v591.Unit:Dot(p579)
		local v594 = math.clamp(v593, -1, 1)
		local v595 = math.acos(v594)
		local v596
		if v583 == nil then
			v596 = false
		else
			local v597 = v588.X - v583.X
			local v598 = v588.Z - v583.Z
			v596 = Vector3.new(v597, 0, v598).Magnitude < 4
		end
		local v599
		if v596 then
			v599 = p580.stick
		else
			v599 = p580.cone
		end
		if v595 >= v599 then
			continue
		end
		local v600 = true
		local v601 = v_u_63[v587]
		if v601 == nil then
			if v581 and v581.isVisible then
				local v602 = v581.isVisible
				local v603, v604 = pcall(v602, v588)
				v600 = not v603 or v604 == true
			end
		else
			v600 = v601
		end
		if not v600 then
			continue
		end
		local v605 = v595 + v592 * 0.002 - (v596 and 0.06981317007977318 or 0)
		if v605 >= v584 then
			continue
		end
		v586 = v595
		v585 = v588
		v584 = v605
	end
	if not v585 then
		v_u_69.assistLock = nil
		return p579
	end
	v_u_69.assistLock = v585
	v_u_69.assistLockAt = os.clock()
	local v606 = v585.X - v582.X
	local v607 = v585.Z - v582.Z
	local v608 = Vector3.new(v606, 0, v607).Unit
	local v609 = p580.pull
	local v610 = v586 / p580.stick
	local v611 = v609 * (1 - math.clamp(v610, 0, 1) * 0.5)
	local v612 = v_u_69.assistStats
	v612.pulls = v612.pulls + 1
	v_u_69.assistStats.last = math.deg(v586)
	return p579:Lerp(v608, v611).Unit
end
function v_u_12.aimAssist() -- name: aimAssist
	-- upvalues: (copy) v_u_577, (ref) v_u_392, (copy) v_u_22
	local v614 = v_u_577[v_u_392]
	if v614 and v_u_22:GetAttribute("AimAssist") ~= false then
		return v614
	else
		return nil
	end
end
local function v_u_624(p_u_615) -- name: hookCharacter
	-- upvalues: (ref) v_u_65, (ref) v_u_38, (ref) v_u_370, (copy) v_u_254
	if v_u_65 ~= p_u_615 then
		v_u_65 = p_u_615
		local v_u_616 = p_u_615:FindFirstChildOfClass("Humanoid") or p_u_615:WaitForChild("Humanoid", 5)
		if v_u_616 and v_u_616:IsA("Humanoid") then
			v_u_616.AutoRotate = false
			pcall(function()
				-- upvalues: (copy) v_u_616
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.Climbing, false)
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.Seated, false)
				v_u_616:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
			end)
		end
		local v617 = p_u_615:FindFirstChild("HumanoidRootPart")
		if v617 then
			local v618 = v617.CFrame.LookVector
			local v619 = -v618.X
			local v620 = -v618.Z
			v_u_38 = math.atan2(v619, v620)
			v_u_370 = v_u_38
		end
		local function v622(p621) -- name: hidePrompt
			if p621:IsA("ProximityPrompt") and p621:GetAttribute("Kind") == "Revive" then
				p621.Enabled = false
			end
		end
		for _, v623 in p_u_615:GetDescendants() do
			if not v623:IsA("ProximityPrompt") or v623:GetAttribute("Kind") ~= "Revive" then
				continue
			end
			v623.Enabled = false
		end
		p_u_615.DescendantAdded:Connect(v622)
		p_u_615:GetAttributeChangedSignal("Dead"):Connect(function()
			-- upvalues: (ref) v_u_65, (copy) p_u_615, (ref) v_u_254
			if v_u_65 == p_u_615 then
				v_u_254()
			end
		end)
	end
end
local v_u_625 = {}
local function v_u_639(p626) -- name: aimMulFor
	-- upvalues: (ref) v_u_380, (copy) v_u_625, (ref) v_u_23, (copy) v_u_22
	local v627 = p626:GetAttribute("Weapon")
	if type(v627) ~= "string" or v627 == "" then
		return nil
	end
	local function v628()
		-- upvalues: (ref) v_u_380
		return v_u_380.shared.Weapons
	end
	local v629, v630 = pcall(v628)
	if not (v629 and v630) then
		return nil
	end
	local v631
	if v630.stats then
		local v632 = p626:GetAttribute("WeaponMods")
		local v633 = type(v632) ~= "string" or v632 == "" or v_u_625[v632]
		if not v633 then
			v633 = string.split(v632, ",")
			v_u_625[v632] = v633
		end
		local v634 = v630.stats
		local v635
		v635, v631 = pcall(v634, v627, v633)
		if not v635 then
			v631 = nil
		end
	else
		v631 = nil
	end
	if not v631 and v630.get then
		v631 = v630.get(v627)
	end
	local v636
	if v631 then
		v636 = v_u_23.aimSpeed(v631, v_u_23.perkOf(v_u_22), p626:GetAttribute("WeaponSlot"))
	else
		v636 = nil
	end
	if v636 then
		return v636
	end
	if v631 then
		local v637 = v631.aimSpeedMul
		if type(v637) == "number" and v631.aimSpeedMul == v631.aimSpeedMul then
			local v638 = v631.aimSpeedMul
			return math.clamp(v638, 0.2, 1.5)
		end
	end
	return nil
end
v_u_12._aimMulFor = v_u_639
v_u_12._terrainMulOf = v_u_10.mul
local v_u_640 = {
	["mul"] = 1,
	["water"] = 0,
	["grade"] = 0,
	["at"] = 0,
	["st"] = nil,
	["st"] = v_u_10.newState()
}
local function v_u_656(p641, p642, p643) -- name: probeTerrain
	-- upvalues: (copy) v_u_640, (ref) v_u_383, (copy) v_u_10
	local v644 = os.clock()
	if v644 - v_u_640.at >= 0.1 then
		v_u_640.at = v644
		local v645 = { p641 }
		local v646 = workspace:FindFirstChild("HushLocal")
		if v646 then
			table.insert(v645, v646)
		end
		local v647 = v_u_383.X
		local v648 = v_u_383.Z
		local v649 = Vector3.new(v647, 0, v648)
		local v650 = v_u_10.probe
		local v651
		if v649.Magnitude > 0.1 then
			v651 = v649.Unit
		else
			v651 = nil
		end
		local v652, v653 = v650(p643, p642, v645, v651, true)
		local v654 = v_u_10.settle(v_u_640.st, v_u_10.classify(v652), v644)
		local v655 = v654 >= 2 and 0 or v653
		v_u_640.water = v654
		v_u_640.grade = v655
		v_u_640.mul = v_u_10.mul(v655, v654)
	end
end
local function v_u_679(p657) -- name: predictedSpeed
	-- upvalues: (ref) v_u_382, (ref) v_u_391, (copy) v_u_639, (copy) v_u_22, (ref) v_u_23, (ref) v_u_375, (ref) v_u_383, (copy) v_u_10, (copy) v_u_640, (ref) v_u_369, (ref) v_u_24, (copy) v_u_2
	local v658
	if v_u_382 and v_u_391 then
		v658 = v_u_639(p657)
	else
		v658 = nil
	end
	local v659 = p657:GetAttribute("Weight")
	local v660 = p657:GetAttribute("MaxWeight")
	if v659 == nil then
		v659 = v_u_22:GetAttribute("Weight")
	end
	if v660 == nil then
		v660 = v_u_22:GetAttribute("MaxWeight")
	end
	local v661 = p657:GetAttribute("Exhausted") == true
	local v662 = p657:GetAttribute("Downed") == true
	local v663 = p657:GetAttribute("Stamina")
	local v664 = type(v663) ~= "number" and 100 or v663
	local v665 = p657:GetAttribute("SnareMul")
	local v666 = p657:GetAttribute("ChokeMul")
	local v667 = (type(v665) ~= "number" or (v665 ~= v665 or v665 >= 1)) and 1 or math.max(v665, 0.2)
	local v668
	if type(v666) == "number" and v666 == v666 then
		v668 = v666 > 1
	else
		v668 = false
	end
	local v669 = v_u_23.moveSpeed
	local v670 = {}
	local v671 = v_u_375 and (v_u_391 and (v_u_383.Magnitude > 0.1 and v_u_10.sprintOk(v_u_640.water)))
	if v671 then
		if v667 == 1 then
			v671 = not v668
		else
			v671 = false
		end
	end
	v670.sprint = v671
	v670.sneak = v_u_369
	local v672 = v_u_382
	if v672 then
		v672 = v_u_391
	end
	v670.aim = v672
	v670.fracture = p657:GetAttribute("Fracture") == true
	v670.downed = p657:GetAttribute("Downed") == true
	v670.dead = p657:GetAttribute("Dead") == true
	v670.weight = type(v659) ~= "number" and 0 or v659
	v670.maxWeight = type(v660) ~= "number" and 0 or v660
	v670.stamina = (v661 or v664 <= 1.5) and 0 or v664
	v670.aimMul = v658
	v670.action = p657:GetAttribute("Action")
	v670.perk = v_u_23.perkOf(v_u_22)
	local v673 = v669(v670, v_u_24)
	if not v662 then
		local v674 = v673 * v_u_640.mul
		if v661 then
			local v675 = p657:GetAttribute("ExhaustedWalkMul")
			if type(v675) ~= "number" or (v675 ~= v675 or (v675 <= 0.2 or v675 > 1)) then
				v675 = v_u_10.T.exhaustedWalkMul
			end
			v674 = v674 * v675
		end
		v673 = v674 * v667
		local v676 = p657:GetAttribute("SwingSlowMul")
		local v677 = p657:GetAttribute("SwingSlowTime")
		local v678 = p657:GetAttribute("MeleeSwingAt")
		if type(v676) == "number" and (v676 == v676 and (type(v677) == "number" and (v677 > 0 and (type(v678) == "number" and v_u_2.now() - v678 < v677)))) then
			v673 = v673 * math.clamp(v676, 0.3, 1)
		end
	end
	return v673
end
local function v_u_684() -- name: stateLib
	-- upvalues: (ref) v_u_379, (ref) v_u_380, (ref) v_u_368
	if v_u_379 ~= nil then
		return v_u_379
	end
	local function v680()
		-- upvalues: (ref) v_u_380
		return v_u_380.lib.StateSend
	end
	local v681, v682 = pcall(v680)
	if v681 and type(v682) == "table" then
		local v683 = v682.step
		if type(v683) == "function" then
			v_u_379 = v682
			v_u_368 = v682.new()
			return v_u_379
		end
		v_u_379 = false
	else
		v_u_379 = false
	end
	return v_u_379
end
local function v_u_709(p685, p686) -- name: sendStateLegacy
	-- upvalues: (ref) v_u_46, (ref) v_u_49, (ref) v_u_54, (ref) v_u_375, (ref) v_u_391, (ref) v_u_376, (copy) v_u_22, (ref) v_u_370, (copy) v_u_50, (ref) v_u_369, (ref) v_u_382, (ref) v_u_52, (ref) v_u_381, (ref) v_u_374, (ref) v_u_51
	if v_u_46 then
		local v687 = os.clock()
		if v687 - v_u_49 < 0.06666666666666667 and not p686 then
			return
		elseif v_u_54 and v_u_54.mute then
			return
		else
			local v_u_688 = v_u_375
			if v_u_688 then
				v_u_688 = v_u_391
			end
			local v689 = v_u_376 == "Raid"
			local v690
			if v689 then
				local v691 = v_u_22.Character
				if v691 and v691.Parent then
					v691:FindFirstChildOfClass("Humanoid")
					v690 = v691:FindFirstChild("HumanoidRootPart")
				else
					v690 = nil
				end
			else
				v690 = nil
			end
			local v692 = (v_u_370 - v_u_50.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
			local v693
			if math.abs(v692) > 0.02 or (v_u_688 ~= v_u_50.sprint or v_u_369 ~= v_u_50.sneak) then
				v693 = true
			else
				v693 = true
				local v694 = v_u_382
				if v694 then
					v694 = v_u_391
				end
				if v694 == v_u_50.aim then
					if v690 == nil then
						v693 = false
					else
						v693 = v_u_52 == nil and true or (v690.Position - v_u_52).Magnitude > 1
					end
				end
			end
			if v693 or p685 or v687 - v_u_49 >= (v689 and 0.25 or 0.5) then
				v_u_49 = v687
				local v695 = (v_u_370 - v_u_381 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				if math.abs(v695) > 0.2 then
					v_u_381 = v_u_370
					v_u_374 = v687
				end
				v_u_50.yaw = v_u_370
				v_u_50.sprint = v_u_688
				v_u_50.sneak = v_u_369
				local v696 = v_u_50
				local v697 = v_u_382
				if v697 then
					v697 = v_u_391
				end
				v696.aim = v697
				local v_u_698 = nil
				if v690 then
					local v699 = v690.Position
					if v699.X == v699.X and (v699.Y == v699.Y and v699.Z == v699.Z) then
						v_u_52 = v699
						v_u_51 = v_u_51 + 1
						v_u_698 = {}
						local v700 = v699.X * 10 + 0.5
						v_u_698.x = math.floor(v700) / 10
						local v701 = v699.Y * 10 + 0.5
						v_u_698.y = math.floor(v701) / 10
						local v702 = v699.Z * 10 + 0.5
						v_u_698.z = math.floor(v702) / 10
					end
				end
				local function v708()
					-- upvalues: (ref) v_u_46, (ref) v_u_370, (copy) v_u_688, (ref) v_u_369, (ref) v_u_382, (ref) v_u_391, (ref) v_u_698, (ref) v_u_51
					local v703 = v_u_46
					local v704 = {}
					local v705 = v_u_370 * 1000 + 0.5
					v704.aimYaw = math.floor(v705) / 1000
					v704.sprint = v_u_688
					v704.sneak = v_u_369
					local v706 = v_u_382
					if v706 then
						v706 = v_u_391
					end
					v704.aim = v706
					v704.p = v_u_698
					local v707
					if v_u_698 then
						v707 = v_u_51
					else
						v707 = nil
					end
					v704.q = v707
					v703:FireServer(v704)
				end
				if not pcall(v708) then
					v_u_46 = nil
				end
			end
		end
	else
		return
	end
end
local function v_u_726(p710, p711) -- name: sendState
	-- upvalues: (ref) v_u_46, (copy) v_u_684, (copy) v_u_709, (ref) v_u_368, (ref) v_u_54, (ref) v_u_376, (copy) v_u_22, (ref) v_u_370, (ref) v_u_375, (ref) v_u_391, (ref) v_u_369, (ref) v_u_382, (copy) v_u_138, (ref) v_u_381, (ref) v_u_374
	if v_u_46 then
		local v712 = v_u_684()
		if v712 then
			local v713 = os.clock()
			if v712.early(v_u_368, v713, p711) then
				return
			elseif v_u_54 and v_u_54.mute then
				return
			else
				local v714 = v_u_376 == "Raid"
				local v715
				if v714 then
					local v716 = v_u_22.Character
					if v716 and v716.Parent then
						v716:FindFirstChildOfClass("Humanoid")
						v715 = v716:FindFirstChild("HumanoidRootPart")
					else
						v715 = nil
					end
				else
					v715 = nil
				end
				local v717 = v712.step
				local v718 = v_u_368
				local v719 = {
					["yaw"] = v_u_370
				}
				local v720 = v_u_375
				if v720 then
					v720 = v_u_391
				end
				v719.sprint = v720
				v719.sneak = v_u_369
				local v721 = v_u_382
				if v721 then
					v721 = v_u_391
				end
				v719.aim = v721
				local v722
				if v715 then
					v722 = v715.Position
				else
					v722 = nil
				end
				v719.pos = v722
				v719.inRaid = v714
				v719.pitch = v_u_138.pitchSend
				local v_u_723 = v717(v718, v713, v719, {
					["force"] = p710 == true,
					["urgent"] = p711 == true
				})
				if v_u_723 ~= nil then
					local v724 = (v_u_370 - v_u_381 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
					if math.abs(v724) > 0.2 then
						v_u_381 = v_u_370
						v_u_374 = v713
					end
					local function v725()
						-- upvalues: (ref) v_u_46, (copy) v_u_723
						v_u_46:FireServer(v_u_723)
					end
					if not pcall(v725) then
						v_u_46 = nil
					end
				end
			end
		else
			v_u_709(p710, p711)
			return
		end
	else
		return
	end
end
function v_u_12.noteShot() -- name: noteShot
	-- upvalues: (copy) v_u_726
	v_u_726(false, true)
end
local v_u_727 = {
	["picks"] = 0,
	["drops"] = 0,
	["last"] = ""
}
local function v_u_732() -- name: modalOpen
	-- upvalues: (copy) v_u_22
	local v728 = v_u_22:FindFirstChildOfClass("PlayerGui")
	if v728 then
		v728 = v728:FindFirstChild("HushModal")
	end
	if v728 and (v728:IsA("ScreenGui") and v728.Enabled) then
		for _, v729 in v728:GetChildren() do
			if v729.Name ~= "Modal" or not (v729:IsA("GuiObject") and v729.Visible) then
				continue
			end
			return true
		end
		local v730 = v728:FindFirstChild("Root")
		if v730 then
			for _, v731 in v730:GetChildren() do
				if v731.Name ~= "Modal" or not (v731:IsA("GuiObject") and v731.Visible) then
					continue
				end
				return true
			end
		end
	end
	return false
end
local v_u_733 = {
	["MapUI"] = "HushMap",
	["RaidSettings"] = "HushRaidSettings",
	["HuntClient"] = "HushHuntHowTo"
}
local function v_u_744(p734) -- name: wdPanel
	-- upvalues: (ref) v_u_380, (copy) v_u_22, (copy) v_u_733
	local v735 = v_u_380
	if v735 then
		v735 = v_u_380.controllers[p734]
	end
	local v736 = false
	if v735 then
		local v737 = v735.isOpen
		if type(v737) == "function" then
			local v738 = v735.isOpen
			local v739
			v736, v739 = pcall(v738)
			if v736 then
				v736 = v739 == true
			end
		end
	end
	local v740
	if p734 == "InventoryUI" then
		v740 = v_u_22:GetAttribute("InvUIOpen") == true
	else
		local v741 = v_u_733[p734]
		local v742 = v_u_22:FindFirstChildOfClass("PlayerGui")
		local v743
		if v741 and v742 then
			v743 = v742:FindFirstChild(v741)
		else
			v743 = nil
		end
		v740 = v743 ~= nil and v743:IsA("ScreenGui")
		if v740 then
			v740 = v743.Enabled
		end
	end
	return v736, v740
end
function v_u_12.blockers() -- name: blockers
	-- upvalues: (ref) v_u_380, (copy) v_u_22, (copy) v_u_744, (ref) v_u_391, (copy) v_u_108, (ref) v_u_377, (ref) v_u_376, (copy) v_u_732, (ref) v_u_392, (ref) v_u_383, (ref) v_u_35, (copy) v_u_69
	local v745 = v_u_380
	if v745 then
		v745 = v_u_380.controllers.InventoryUI
	end
	local v746 = false
	if v745 then
		local v747 = v745.isOpen
		if type(v747) == "function" then
			local v748 = v745.isOpen
			local v749
			v746, v749 = pcall(v748)
			if v746 then
				v746 = v749 == true
			end
		end
	end
	local v750 = v_u_22:GetAttribute("InvUIOpen") == true
	local v751, v752 = v_u_744("MapUI")
	local v753, v754 = v_u_744("RaidSettings")
	local v755 = {
		["enabled"] = v_u_391,
		["blocked"] = not v_u_391 or v_u_108()
	}
	local v756 = v_u_377
	if not v756 then
		if v_u_22.Character == nil then
			v756 = false
		else
			v756 = v_u_376 ~= "Transit"
		end
	end
	v755.live = v756
	v755.modal = v_u_732()
	local v757 = v_u_22.Character
	local v758
	if v757 == nil then
		v758 = false
	else
		v758 = v757:GetAttribute("Dead") == true
	end
	v755.dead = v758
	v755.device = v_u_392
	v755.place = v_u_376
	v755.open = {
		["inv"] = v746,
		["map"] = v751,
		["set"] = v753
	}
	v755.proof = {
		["inv"] = v750,
		["map"] = v752,
		["set"] = v754
	}
	v755.mv = v_u_383
	v755.raw = v_u_35
	v755.blockedMoves = v_u_69.blockedMoves
	return v755
end
function v_u_12.heal(p759) -- name: heal
	-- upvalues: (copy) v_u_100, (copy) v_u_744, (ref) v_u_380, (ref) v_u_390, (ref) v_u_383, (ref) v_u_35, (copy) v_u_22
	if p759 == "panels" then
		local v760 = false
		for _, v761 in v_u_100 do
			local v762, v763 = v_u_744(v761)
			if not v762 or v763 then
				continue
			end
			local v764 = v_u_380.controllers[v761]
			if not v764 then
				continue
			end
			local v765 = v764.close
			if type(v765) ~= "function" then
				continue
			end
			local v766 = v764.close
			pcall(v766)
			v760 = true
		end
		return v760
	elseif p759 == "touch" then
		local v767 = v_u_390
		if not v767 then
			return false
		end
		local v768 = v767.moveTouch
		local v769 = v767.aimTouch
		local v770
		if v768 == nil or v768.UserInputState ~= Enum.UserInputState.End and v768.UserInputState ~= Enum.UserInputState.Cancel then
			v770 = false
		else
			v767:_endMove()
			v770 = true
		end
		if v769 ~= nil and (v769.UserInputState == Enum.UserInputState.End or v769.UserInputState == Enum.UserInputState.Cancel) then
			v767:_endAim(true)
			v770 = true
		end
		return v770
	elseif p759 == "nan" then
		local v771 = v_u_383.Magnitude
		local v772 = v_u_35.Magnitude
		if v771 == v771 and v772 == v772 then
			return false
		end
		v_u_383 = Vector3.new(0, 0, 0)
		v_u_35 = Vector3.new(0, 0, 0)
		return true
	else
		if p759 ~= "anchor" then
			return false
		end
		local v773 = v_u_22.Character
		local v774
		if v773 and v773.Parent then
			v773:FindFirstChildOfClass("Humanoid")
			v774 = v773:FindFirstChild("HumanoidRootPart")
		else
			v773 = nil
			v774 = nil
		end
		if not v773 or (not v774 or (not v774.Anchored or (v773:GetAttribute("HushHeld") ~= nil or (v773:GetAttribute("Dead") == true or v_u_22:GetAttribute("RaidStatus") ~= "Alive")))) then
			return false
		end
		v774.Anchored = false
		return true
	end
end
local function v_u_790() -- name: defaultFocus
	-- upvalues: (copy) v_u_22, (copy) v_u_11
	local v775 = v_u_22:FindFirstChildOfClass("PlayerGui")
	if not v775 then
		return nil
	end
	local v776 = {}
	for _, v777 in v775:GetChildren() do
		if not v777:IsA("ScreenGui") or (not v777.Enabled or (v777.Name == "TouchGui" or (v777.Name == "HushTouch" or v777.Name == "HushTouchTray"))) then
			continue
		end
		table.insert(v776, v777)
	end
	table.sort(v776, function(p778, p779)
		return p778.DisplayOrder > p779.DisplayOrder
	end)
	local v780 = workspace.CurrentCamera
	local v781
	if v780 then
		v781 = v780.ViewportSize
	else
		v781 = Vector2.new(1920, 1080)
	end
	for _, v782 in v776 do
		local v783 = (1 / 0)
		local v784 = nil
		for _, v785 in v_u_11.selectables(v782) do
			local v786 = v785.AbsoluteSize
			if v786.X >= v781.X * 0.85 and v786.Y >= v781.Y * 0.85 or v785:IsA("ScrollingFrame") then
				continue
			end
			local v787 = v785.AbsolutePosition
			local v788 = v787.Y / 8
			local v789 = math.floor(v788) * 100000 + v787.X
			if v785:GetAttribute("PadDefault") == true then
				v789 = v789 - 1000000000
			end
			if v789 >= v783 then
				continue
			end
			v784 = v785
			v783 = v789
		end
		if not v784 then
			break
		end
		return v784
	end
	return nil
end
v_u_12._defaultFocus = v_u_790
local function v_u_808() -- name: focusGuard
	-- upvalues: (ref) v_u_377, (copy) v_u_22, (ref) v_u_376, (ref) v_u_391, (copy) v_u_108, (copy) v_u_732, (copy) v_u_69, (copy) v_u_6, (ref) v_u_389, (ref) v_u_392, (copy) v_u_11, (copy) v_u_727, (copy) v_u_790
	local v791 = v_u_377
	if not v791 then
		if v_u_22.Character == nil then
			v791 = false
		else
			v791 = v_u_376 ~= "Transit"
		end
	end
	local v792 = not v791 or (not v_u_391 or v_u_108())
	if not v792 then
		local v793 = v_u_22.Character
		local v794
		if v793 == nil then
			v794 = false
		else
			v794 = v793:GetAttribute("Dead") == true
		end
		v792 = v794 or v_u_732()
	end
	local v795 = v_u_69.wasInCharge and not v792 and v_u_6.SelectedObject
	if v795 then
		local v796 = v795:FindFirstAncestorOfClass("ScreenGui")
		local v797
		if v796 == nil then
			v797 = false
		else
			v797 = v796:GetAttribute("PadFocusInGame") == true
		end
		if not v797 then
			v_u_6.SelectedObject = nil
			local v798 = v_u_69
			v798.clears = v798.clears + 1
		end
	end
	v_u_69.wasInCharge = v792
	local v799 = os.clock()
	if v799 - v_u_389 < 0.25 then
		return
	else
		v_u_389 = v799
		if not v792 then
			local v800 = v_u_6.SelectedObject
			if v800 and v_u_22:GetAttribute("PadFocusHold") ~= true then
				local v801 = v800:FindFirstAncestorOfClass("ScreenGui")
				local v802
				if v801 == nil then
					v802 = false
				else
					v802 = v801:GetAttribute("PadFocusInGame") == true
				end
				if not v802 then
					v_u_6.SelectedObject = nil
					local v803 = v_u_69
					v803.clears = v803.clears + 1
				end
			end
		end
		if v_u_392 == "Gamepad" and v_u_22:GetAttribute("PadFocusHold") ~= true then
			local v804 = v_u_6.SelectedObject
			if v804 and (v804.Parent == nil or not (v804.Selectable and v_u_11.shown(v804))) then
				v_u_6.SelectedObject = nil
				local v805 = v_u_727
				v805.drops = v805.drops + 1
				v804 = nil
			end
			local v806 = v804 == nil and (v792 and v_u_790())
			if v806 then
				v_u_6.SelectedObject = v806
				local v807 = v_u_727
				v807.picks = v807.picks + 1
				v_u_727.last = v_u_11.pathOf(v806)
			end
		end
	end
end
local function v_u_817() -- name: pollPad
	-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_71, (ref) v_u_378, (ref) v_u_384
	local v809 = v_u_11.gamepadState
	local v810, v811 = pcall(v809)
	if v810 and type(v811) == "table" then
		for _, v812 in v811 do
			local v813 = v812.KeyCode
			if v813 == v_u_13.Thumbstick1 then
				v_u_71.track("poll", Vector2.new(v812.Position.X, v812.Position.Y))
			else
				if v813 ~= v_u_13.Thumbstick2 then
					continue
				end
				v_u_378 = Vector2.new(v812.Position.X, v812.Position.Y)
			end
		end
		local v_u_814 = v_u_71.stickIo
		if v_u_814 and not v_u_11.active then
			local v815, v816 = pcall(function()
				-- upvalues: (copy) v_u_814
				return v_u_814.Position
			end)
			if v815 and typeof(v816) == "Vector3" then
				v_u_71.track("io", Vector2.new(v816.X, v816.Y))
			end
		end
		v_u_384 = v_u_71.fresh()
	end
end
v_u_71.STICK_OFF = 0.12
v_u_71.STICK_NAV = 0.6
v_u_71.STICK_REARM = 0.35
v_u_71.DIRS = {
	[v_u_13.DPadUp] = "up",
	[v_u_13.DPadDown] = "down",
	[v_u_13.DPadLeft] = "left",
	[v_u_13.DPadRight] = "right"
}
function v_u_71.mode() -- name: mode
	-- upvalues: (copy) v_u_22
	local v818 = v_u_22:GetAttribute("PadNavMode")
	return v818 ~= "window" and v818 ~= "engine" and "stick" or v818
end
function v_u_71.track(p819, p820) -- name: track
	-- upvalues: (copy) v_u_71
	local v821 = v_u_71.src[p819]
	if v821 and (p820 - v821.v).Magnitude > 0.03 then
		local v822 = os.clock()
		v821.v = p820
		v821.at = v822
	end
end
function v_u_71.fresh() -- name: fresh
	-- upvalues: (copy) v_u_71
	local v823 = Vector2.zero
	local v824 = -1
	for _, v825 in v_u_71.src do
		if v824 >= v825.at then
			continue
		end
		v823 = v825.v
		v824 = v825.at
	end
	return v823
end
function v_u_71.resetStick() -- name: resetStick
	-- upvalues: (copy) v_u_71
	for _, v826 in v_u_71.src do
		v826.v = Vector2.zero
		v826.at = 0
	end
	v_u_71.stickHeld = nil
	v_u_71.stickIo = nil
end
function v_u_71.setNav(p_u_827) -- name: setNav
	-- upvalues: (copy) v_u_71, (copy) v_u_6
	if p_u_827 ~= v_u_71.navOff then
		local function v828()
			-- upvalues: (ref) v_u_6, (copy) p_u_827
			v_u_6.GuiNavigationEnabled = not p_u_827
		end
		if pcall(v828) then
			v_u_71.navOff = p_u_827
		end
	end
end
function v_u_71.navStep(p829) -- name: navStep
	-- upvalues: (copy) v_u_11, (copy) v_u_71
	local v830 = v_u_11.nav(p829)
	local v831 = v_u_71
	v831.navSteps = v831.navSteps + 1
	return v830
end
function v_u_71.ownNav(p832) -- name: ownNav
	-- upvalues: (copy) v_u_71, (copy) v_u_6, (copy) v_u_22
	local v833 = v_u_71.navOff
	if v833 then
		if p832 then
			if v_u_6.SelectedObject == nil then
				p832 = false
			else
				p832 = v_u_22:GetAttribute("PadFocusHold") ~= true
			end
		end
	else
		p832 = v833
	end
	return p832
end
function v_u_71.stickDir(p834) -- name: stickDir
	local v835 = p834.X
	local v836 = math.abs(v835)
	local v837 = p834.Y
	return math.abs(v837) < v836 and (p834.X > 0 and "right" or "left") or (p834.Y > 0 and "up" or "down")
end
function v_u_71.step(p838) -- name: step
	-- upvalues: (copy) v_u_71, (ref) v_u_384, (ref) v_u_392
	local v839 = v_u_71.mode()
	local v840 = v_u_384
	local v841
	if v_u_392 == "Gamepad" then
		v841 = v839 ~= "engine"
	else
		v841 = false
	end
	local v842 = v_u_71.setNav
	if v841 then
		if v840.Magnitude >= v_u_71.STICK_OFF then
			v841 = true
		elseif v839 == "window" then
			v841 = p838
		else
			v841 = false
		end
	end
	v842(v841)
	local v843 = os.clock()
	if v840.Magnitude < v_u_71.STICK_REARM then
		local v844 = v_u_71
		v_u_71.stickArmed = true
		v844.stickHeld = nil
	elseif v_u_71.ownNav(p838) then
		if v840.Magnitude >= v_u_71.STICK_NAV then
			local v845 = v_u_71.stickDir(v840)
			if v_u_71.stickArmed then
				v_u_71.stickArmed = false
				if v843 - v_u_71.selChangedAt > 0.1 then
					v_u_71.navStep(v845)
				end
				v_u_71.stickHeld = v845
			elseif v_u_71.stickHeld ~= nil and v_u_71.stickHeld ~= v845 then
				v_u_71.navStep(v845)
				v_u_71.stickHeld = v845
			end
		end
	else
		local v846 = v_u_71
		v_u_71.stickArmed = false
		v846.stickHeld = nil
	end
	v_u_71.diagStep(p838)
end
function v_u_71.dpadBegan(p847, p848) -- name: dpadBegan
	-- upvalues: (copy) v_u_71
	local v849 = v_u_71.DIRS[p847.KeyCode]
	if not (v849 and v_u_71.ownNav(p848)) then
		return false
	end
	v_u_71.navStep(v849)
	return true
end
function v_u_71.probeA(p850) -- name: probeA
	-- upvalues: (copy) v_u_71, (copy) v_u_6, (copy) v_u_22
	if v_u_71.navOff and (type(p850) ~= "table" or not p850.virtual) then
		local v851 = v_u_6.SelectedObject
		if v851 and (v851:IsA("GuiButton") and v851.Active) then
			local v_u_852 = false
			local v_u_853 = v851.Activated:Connect(function()
				-- upvalues: (ref) v_u_852
				v_u_852 = true
			end)
			task.delay(0.3, function()
				-- upvalues: (copy) v_u_853, (ref) v_u_852, (ref) v_u_71, (ref) v_u_22
				v_u_853:Disconnect()
				if v_u_852 then
					local v854 = v_u_71
					v854.aHit = v854.aHit + 1
				else
					local v855 = v_u_71
					v855.aMiss = v855.aMiss + 1
					if v_u_71.mode() == "window" then
						v_u_22:SetAttribute("PadNavMode", "stick")
					end
					v_u_71.diag("aMiss")
				end
			end)
		end
	else
		return
	end
end
function v_u_71.line(p856) -- name: line
	-- upvalues: (copy) v_u_71, (copy) v_u_6, (ref) v_u_384, (copy) v_u_11, (ref) v_u_392, (copy) v_u_69, (ref) v_u_391
	local v857 = os.clock()
	local v858 = v_u_71.src
	local v_u_859 = true
	local function v860()
		-- upvalues: (ref) v_u_859, (ref) v_u_6
		v_u_859 = v_u_6.GuiNavigationEnabled
	end
	pcall(v860)
	local v861 = string.format
	local v862 = v_u_384
	local v863 = string.format("%.2f,%.2f", v862.X, v862.Y)
	local v864 = v858.evt.v
	local v865 = string.format("%.2f,%.2f", v864.X, v864.Y)
	local v866 = v858.evt
	local v867 = v866.at <= 0 and "-" or string.format("%.1fs", v857 - v866.at)
	local v868 = v858.poll.v
	local v869 = string.format("%.2f,%.2f", v868.X, v868.Y)
	local v870 = v858.poll
	local v871 = v870.at <= 0 and "-" or string.format("%.1fs", v857 - v870.at)
	local v872 = v858.io.v
	local v873 = string.format("%.2f,%.2f", v872.X, v872.Y)
	local v874 = v858.io
	local v875 = v874.at <= 0 and "-" or string.format("%.1fs", v857 - v874.at)
	local v876 = not v_u_6.SelectedObject and "nil" or v_u_11.pathOf(v_u_6.SelectedObject)
	local v877 = v_u_392
	local v878 = v_u_859 and "on" or "off"
	local v879 = v_u_71.mode()
	local v880 = v_u_69.wasInCharge
	local v881 = v_u_391
	return v861("[PadDiag] %s padMove=%s evt=%s(%s) poll=%s(%s) io=%s(%s) sel=%s dev=%s nav=%s mode=%s inCharge=%s enabled=%s steps=%d aHit=%d aMiss=%d", p856, v863, v865, v867, v869, v871, v873, v875, v876, v877, v878, v879, tostring(v880), tostring(v881), v_u_71.navSteps, v_u_71.aHit, v_u_71.aMiss)
end
function v_u_71.diag(p882) -- name: diag
	-- upvalues: (copy) v_u_71, (copy) v_u_22
	local v883 = v_u_71.line(p882)
	v_u_22:SetAttribute("PadDiag", v883)
	if v_u_71.diagLines < 300 then
		local v884 = v_u_71
		v884.diagLines = v884.diagLines + 1
		print(v883)
	end
	return v883
end
function v_u_71.diagStep(p885) -- name: diagStep
	-- upvalues: (ref) v_u_392, (copy) v_u_71
	if v_u_392 == "Gamepad" then
		local v886 = os.clock()
		if p885 ~= v_u_71.diagWas then
			v_u_71.diagWas = p885
			v_u_71.diag(p885 and "open" or "close")
			if not p885 then
				v_u_71.diagDue = { v886 + 0.4, v886 + 1.5 }
			end
		end
		local v887 = v_u_71.diagDue[1]
		if v887 and v887 <= v886 then
			table.remove(v_u_71.diagDue, 1)
			v_u_71.diag("after")
		end
	else
		v_u_71.diagWas = p885
		table.clear(v_u_71.diagDue)
	end
end
local function v_u_898() -- name: padTip
	-- upvalues: (ref) v_u_376, (copy) v_u_69, (ref) v_u_392, (ref) v_u_391, (copy) v_u_108, (copy) v_u_22, (ref) v_u_380, (copy) v_u_12
	if v_u_376 == "Raid" then
		local v888 = os.clock()
		if v_u_69.raidSince == nil then
			v_u_69.raidSince = v888
		end
		if not v_u_69.padTipShown and (v_u_392 == "Gamepad" and v888 - v_u_69.raidSince >= 4) and (v_u_391 and not v_u_108()) then
			local v889 = v_u_22.Character
			local v890
			if v889 == nil then
				v890 = false
			else
				v890 = v889:GetAttribute("Dead") == true
			end
			if not v890 then
				v_u_69.padTipShown = true
				local function v891()
					-- upvalues: (ref) v_u_380
					return v_u_380.lib.HushUI
				end
				local v892, v893 = pcall(v891)
				if v892 and v893 then
					local v894 = v893.toast
					if type(v894) == "function" then
						local v895 = v893.toast
						local v896 = v_u_12.hint("map") .. ": map  \194\183  " .. v_u_12.hint("inventory") .. ": bag"
						pcall(v895, v896, "info", nil, 6)
					end
				end
				return
			end
		end
	else
		local v897 = v_u_69
		v_u_69.raidSince = nil
		v897.padTipShown = false
	end
end
local function v_u_907(p899, p900, p901) -- name: netToast
	-- upvalues: (ref) v_u_380
	local function v902()
		-- upvalues: (ref) v_u_380
		return v_u_380.lib.HushUI
	end
	local v903, v904 = pcall(v902)
	if v903 and v904 then
		local v905 = v904.toast
		if type(v905) == "function" then
			local v906 = v904.toast
			pcall(v906, p899, "warn", p900, p901)
		end
	end
end
local function v_u_927(p908, p909, p910) -- name: netLagStep
	-- upvalues: (ref) v_u_54, (copy) v_u_53, (ref) v_u_376, (copy) v_u_907
	local v911 = os.clock()
	if v_u_54 then
		if not p909.Anchored then
			p909.Anchored = true
		end
		if p908:GetAttribute("HushHeld") == nil then
			p908:SetAttribute("HushHeld", 0)
		end
		if not v_u_53.hold then
			p909.CFrame = p909.CFrame + v_u_54.dir * (v_u_54.speed * p910)
		end
	end
	local v912 = p908:GetAttribute("NetDesync")
	if (v912 == "split" or v912 == "silent") and (p908:GetAttribute("Dead") ~= true and v_u_376 == "Raid") then
		if not v_u_53.since then
			v_u_53.since = v911
		end
		if v911 - v_u_53.since >= 0.6 and v911 - v_u_53.hintAt >= 8 then
			v_u_53.hintAt = v911
			v_u_907("CONNECTION LAG", "Your moves are not reaching the server.", 5)
		end
		if v912 ~= "silent" then
			local v913 = v_u_53
			v_u_53.silentSince = nil
			v913.hold = false
			return false
		end
		if not v_u_53.silentSince then
			v_u_53.silentSince = v911
		end
		local v914 = v_u_53.pull
		if v914 then
			local v915 = (v911 - v914.t0) / 0.3
			local v916 = math.clamp(v915, 0, 1)
			local v917 = p909.CFrame
			p909.CFrame = CFrame.new(v914.from:Lerp(v914.to, v916)) * v917.Rotation
			p909.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			if v916 >= 1 then
				v_u_53.pull = nil
			end
		end
		if v911 - v_u_53.silentSince >= 1 then
			v_u_53.hold = true
			if not v_u_53.pulled then
				v_u_53.pulled = true
				local v918 = p908:GetAttribute("NetSrvPos")
				if typeof(v918) == "Vector3" then
					local v919 = p909.Position
					local v920 = v918.X - v919.X
					local v921 = v918.Z - v919.Z
					local v922 = Vector3.new(v920, 0, v921).Magnitude
					if v922 > 3 and v922 < 300 then
						v_u_53.pull = {
							["from"] = v919,
							["to"] = v918,
							["t0"] = v911
						}
						v_u_907("Moved back", "Moved back to your last synced position.", 5)
					end
				end
			end
		end
		return v_u_53.hold
	end
	local v923 = v_u_53
	local v924 = v_u_53
	local v925 = v_u_53
	local v926 = v_u_53
	v_u_53.since = nil
	v923.silentSince = nil
	v924.hold = false
	v925.pulled = false
	v926.pull = nil
	return false
end
function v_u_12.step(p928) -- name: step
	-- upvalues: (copy) v_u_137, (ref) v_u_391, (copy) v_u_108, (copy) v_u_69, (copy) v_u_898, (copy) v_u_226, (copy) v_u_808, (ref) v_u_392, (copy) v_u_817, (copy) v_u_71, (copy) v_u_22, (ref) v_u_65, (copy) v_u_624, (copy) v_u_254, (ref) v_u_377, (ref) v_u_376, (ref) v_u_59, (ref) v_u_390, (copy) v_u_6, (ref) v_u_384, (copy) v_u_401, (ref) v_u_35, (copy) v_u_90, (ref) v_u_383, (ref) v_u_373, (copy) v_u_12, (ref) v_u_375, (ref) v_u_369, (ref) v_u_382, (copy) v_u_927, (copy) v_u_70, (copy) v_u_74, (copy) v_u_656, (copy) v_u_679, (copy) v_u_640, (ref) v_u_66, (ref) v_u_40, (copy) v_u_138, (ref) v_u_370, (ref) v_u_380, (copy) v_u_4, (ref) v_u_378, (copy) v_u_577, (copy) v_u_613, (ref) v_u_372, (copy) v_u_576, (ref) v_u_388, (ref) v_u_38, (ref) v_u_55, (ref) v_u_56, (copy) v_u_726
	v_u_137()
	if not v_u_391 or v_u_108() then
		v_u_69.blockedAt = os.clock()
	end
	v_u_898()
	v_u_226()
	v_u_808()
	if v_u_392 == "Gamepad" then
		v_u_817()
	end
	v_u_71.step(v_u_69.wasInCharge)
	local v929 = v_u_22.Character
	local v930, v931
	if v929 and v929.Parent then
		v930 = v929:FindFirstChildOfClass("Humanoid")
		v931 = v929:FindFirstChild("HumanoidRootPart")
	else
		v929 = nil
		v930 = nil
		v931 = nil
	end
	if v929 and v929 ~= v_u_65 then
		task.spawn(v_u_624, v929)
		task.defer(v_u_254)
	end
	local v932 = Vector2.zero
	if v_u_391 then
		local v933 = v_u_377
		if not v933 then
			if v_u_22.Character == nil then
				v933 = false
			else
				v933 = v_u_376 ~= "Transit"
			end
		end
		if v933 then
			if v_u_59 and os.clock() < v_u_59.untilT then
				v932 = v_u_59.v
			elseif v_u_392 == "Touch" and v_u_390 then
				v932 = v_u_390:moveVector()
			elseif v_u_392 == "Gamepad" then
				if v_u_6.SelectedObject ~= nil and true or v_u_108() then
					v932 = Vector2.zero
				else
					local v934 = v_u_384
					local v935 = v934.Magnitude
					if v935 < 0.18 then
						v932 = Vector2.zero
					else
						local v936 = v934.Unit
						local v937 = (v935 - 0.18) / 0.8200000000000001
						v932 = v936 * math.clamp(v937, 0, 1)
					end
				end
			else
				v932 = v_u_401()
			end
		end
	end
	local v938, v939 = v_u_90()
	v_u_35 = v939 * v932.X + v938 * v932.Y
	local v940 = v_u_35.Magnitude > v_u_383.Magnitude and 11 or 15
	local v941 = v_u_35
	local v942 = v_u_383 - v_u_35
	local v943 = -v940 * p928
	v_u_383 = v941 + v942 * math.exp(v943)
	if v_u_383.Magnitude < 0.02 and v_u_35.Magnitude == 0 then
		v_u_383 = Vector3.new(0, 0, 0)
	end
	if v929 and (v930 and v931) then
		local v944 = v929:GetAttribute("Dead") == true
		local v945 = v929:GetAttribute("Downed") == true
		local v946 = v929:GetAttribute("Action")
		local v947 = v_u_12.rideBusy(v929)
		local v948 = v946 == "Revive" and true or (v946 == "Takedown" and true or v947)
		if v947 ~= v_u_69.rideTouch then
			v_u_69.rideTouch = v947
			if v947 and (v_u_375 or v_u_369) then
				v_u_375 = false
				v_u_369 = false
				if v_u_390 then
					v_u_390:setToggle("sprint", v_u_375)
					v_u_390:setToggle("sneak", v_u_369)
					v_u_390:setToggle("aim", v_u_382)
				end
			end
			if v_u_390 then
				local v949 = v_u_390
				local v950 = not v947
				if v950 then
					if v_u_392 == "Touch" then
						local v951 = v_u_377
						if not v951 then
							if v_u_22.Character == nil then
								v951 = false
							else
								v951 = v_u_376 ~= "Transit"
							end
						end
						v950 = v951 and v_u_391
						if v950 then
							local v952 = v_u_22.Character
							local v953
							if v952 == nil then
								v953 = false
							else
								v953 = v952:GetAttribute("Dead") == true
							end
							v950 = not v953
						end
					else
						v950 = false
					end
				end
				v949:setVisible(v950)
			end
		end
		local v954
		if v947 then
			v954 = false
		else
			local v955 = v_u_927
			local v956
			v954, v956 = pcall(v955, v929, v931, p928)
			if v954 then
				v954 = v956 == true
			end
		end
		if v944 then
			v930:Move(Vector3.new(0, 0, 0), false)
		else
			local v957 = (v948 or v954) and Vector3.new(0, 0, 0) or v_u_383
			local v958 = v_u_69.zblock
			local v959
			if v958 then
				local v960 = v958.filter
				local v961
				v961, v959 = pcall(v960, v957, v929, v930, v931, p928)
				if v961 then
					if typeof(v959) ~= "Vector3" then
						v959 = v957
					end
				else
					v959 = v957
				end
			else
				v959 = v957
			end
			v930:Move(v959, false)
			if v_u_392 == "Touch" or v_u_392 == "Keyboard" and v_u_70.moveCustom then
				local v962 = v_u_74
				local v963 = v_u_74
				local v964 = os.clock()
				v962.mv = v959
				v963.at = v964
			end
			v_u_656(v929, v930, v931)
			local v965 = v_u_679(v929)
			local v966 = v930.WalkSpeed - v965
			if math.abs(v966) > 0.01 then
				v930.WalkSpeed = v965
			end
			if v_u_640.mul < 0.999 or v_u_640.water > 0 then
				local v967 = v931.AssemblyLinearVelocity
				local v968 = v967.X
				local v969 = v967.Z
				local v970 = Vector3.new(v968, 0, v969)
				local v971 = v965 * 1.08 + 0.4
				if v971 < v970.Magnitude then
					local v972 = v970.Unit * v971
					local v973 = v972.X
					local v974 = v967.Y
					local v975 = v972.Z
					v931.AssemblyLinearVelocity = Vector3.new(v973, v974, v975)
				end
			end
		end
		local v976 = v929:GetAttribute("Exhausted") == true
		if v976 and (not v_u_66 and v_u_375) then
			v_u_375 = false
			if v_u_390 then
				v_u_390:setToggle("sprint", v_u_375)
				v_u_390:setToggle("sneak", v_u_369)
				v_u_390:setToggle("aim", v_u_382)
			end
		end
		v_u_66 = v976
		local v977 = v931.Position
		local v978 = false
		v_u_40 = nil
		local v979 = false
		local v980 = nil
		if v_u_138.provider ~= nil then
			local v981 = v_u_138.provider.step
			local v982 = {
				["root"] = v931,
				["char"] = v929,
				["device"] = v_u_392,
				["enabled"] = v_u_391,
				["downed"] = v945
			}
			local v983, v984 = pcall(v981, p928, v982)
			if v983 and type(v984) == "table" then
				v979 = true
				local v985 = v984.yaw
				if type(v985) == "number" and v984.yaw == v984.yaw then
					v_u_370 = v984.yaw
				end
				local v986 = v_u_138
				local v987 = v984.pitch
				local v988
				if type(v987) == "number" and v984.pitch == v984.pitch then
					local v989 = v984.pitch
					v988 = math.clamp(v989, -1.45, 1.45)
				else
					v988 = 0
				end
				v986.pitch = v988
				v_u_138.pitchSend = v_u_138.pitch
				local v990 = v984.face
				if type(v990) == "number" and v984.face == v984.face then
					v980 = v984.face
				else
					v980 = nil
				end
				local v991 = v_u_370
				local v992 = -math.sin(v991)
				local v993 = v_u_370
				local v994 = -math.cos(v993)
				local v995 = Vector3.new(v992, 0, v994)
				local v996 = v984.point
				local v997
				if typeof(v996) == "Vector3" then
					v997 = v984.point
				else
					v997 = v977 + v995 * 12
				end
				v_u_373 = v997
			else
				v_u_138.pitch = 0
				v_u_138.pitchSend = nil
			end
		end
		if not v979 then
			if v_u_392 == "Keyboard" then
				local v998 = v_u_380
				if v998 then
					v998 = v_u_380.controllers.Camera
				end
				local v999 = nil
				local v1000
				if v998 and v998.aimPlanePoint then
					local v1001 = v998.aimPlanePoint
					local v1002
					v1002, v1000 = pcall(v1001, nil)
					if v1002 then
						if typeof(v1000) ~= "Vector3" then
							v1000 = v999
						end
					else
						v1000 = v999
					end
				else
					v1000 = v999
				end
				local v1003 = v_u_380
				if v1003 then
					v1003 = v_u_380.controllers.WeaponClient
				end
				local v1004 = false
				if v1003 then
					local v1005 = v1003.faceTarget
					if type(v1005) == "function" then
						local v1006 = v1003.faceTarget
						local v1007, v1008 = pcall(v1006)
						if v1007 and typeof(v1008) == "Vector3" then
							local v1009 = v1008.X
							local v1010 = v977.Y
							local v1011 = v1008.Z
							v1000 = Vector3.new(v1009, v1010, v1011)
							v1004 = true
						end
					end
				end
				if not v1000 then
					local v1012 = workspace.CurrentCamera
					if v1012 then
						local v1013 = v_u_4:GetMouseLocation()
						local v1014 = v1012:ViewportPointToRay(v1013.X, v1013.Y)
						local v1015 = v1014.Direction.Y
						if math.abs(v1015) > 0.0001 then
							local v1016 = (v977.Y - v1014.Origin.Y) / v1014.Direction.Y
							if v1016 > 0 then
								v1000 = v1014.Origin + v1014.Direction * v1016
							end
						end
					end
				end
				if v1000 then
					v_u_373 = v1000
					local v1017 = v1000.X - v977.X
					local v1018 = v1000.Z - v977.Z
					local v1019 = Vector3.new(v1017, 0, v1018)
					local v1020 = false
					if not v1004 then
						local v1021 = workspace.CurrentCamera
						if v1021 then
							local v1022, v1023 = v1021:WorldToViewportPoint(v977)
							if v1023 then
								local v1024 = v_u_4:GetMouseLocation()
								local v1025 = (Vector2.new(v1022.X, v1022.Y) - v1024).Magnitude
								local v1026 = v1021.ViewportSize.Y * 0.05
								v1020 = v1025 < math.max(26, v1026)
							end
						end
					end
					if v1019.Magnitude > 0.8 and not v1020 then
						local v1027 = -v1019.X
						local v1028 = -v1019.Z
						v_u_370 = math.atan2(v1027, v1028)
					end
				end
			else
				local v1029 = nil
				local v1030
				if v_u_392 == "Touch" and v_u_390 then
					v1030 = v_u_390:aimVector()
				elseif v_u_392 == "Gamepad" then
					local v1031 = v_u_378
					local v1032 = v1031.Magnitude
					if v1032 < 0.25 then
						v1030 = Vector2.zero
					else
						local v1033 = v1031.Unit
						local v1034 = (v1032 - 0.25) / 0.75
						v1030 = v1033 * math.clamp(v1034, 0, 1)
					end
					if v1030.Magnitude <= 0 then
						v1030 = v1029
					end
				else
					v1030 = v1029
				end
				if v1030 and v_u_391 then
					local v1035, v1036 = v_u_90()
					local v1037 = v1036 * v1030.X + v1035 * v1030.Y
					if v1037.Magnitude > 0.01 then
						local v1038 = v1037.Unit
						local v1039 = v_u_577[v_u_392]
						if not v1039 or v_u_22:GetAttribute("AimAssist") == false then
							v1039 = nil
						end
						if v1039 then
							v1038 = v_u_613(v931, v1038, v1039)
						end
						v_u_40 = v1038
						local v1040 = -v1038.X
						local v1041 = -v1038.Z
						v_u_370 = math.atan2(v1040, v1041)
					end
				else
					v978 = true
					if v_u_383.Magnitude > 0.15 then
						local v1042 = v_u_383
						local v1043 = -v1042.X
						local v1044 = -v1042.Z
						v_u_370 = math.atan2(v1043, v1044)
					end
					v_u_69.assistLock = nil
					if v_u_392 == "Touch" and (v_u_372 and v_u_391) then
						local v1045 = v_u_577[v_u_392]
						if not v1045 or v_u_22:GetAttribute("AimAssist") == false then
							v1045 = nil
						end
						if v1045 then
							local v1046 = v_u_370
							local v1047 = -math.sin(v1046)
							local v1048 = v_u_370
							local v1049 = -math.cos(v1048)
							local v1050 = Vector3.new(v1047, 0, v1049)
							local v1051 = v_u_576(v931, v1050, 0.3839724354387525, 1)
							if v1051:Dot(v1050) < 0.9999 then
								v_u_40 = v1051
								local v1052 = -v1051.X
								local v1053 = -v1051.Z
								v_u_370 = math.atan2(v1052, v1053)
								v978 = false
							end
						end
					end
				end
				local v1054 = v_u_370
				local v1055 = -math.sin(v1054)
				local v1056 = v_u_370
				local v1057 = -math.cos(v1056)
				v_u_373 = v977 + Vector3.new(v1055, 0, v1057) * (v_u_40 and 22 or 12)
			end
		end
		local v1058 = v_u_388
		if v1058 then
			local v1059 = v1058.X - v977.X
			local v1060 = v1058.Z - v977.Z
			local v1061 = Vector3.new(v1059, 0, v1060)
			if v1061.Magnitude > 0.8 then
				local v1062 = -v1061.X
				local v1063 = -v1061.Z
				v_u_370 = math.atan2(v1062, v1063)
			end
			local v1064 = v1058.X
			local v1065 = v977.Y
			local v1066 = v1058.Z
			v_u_373 = Vector3.new(v1064, v1065, v1066)
			v_u_40 = nil
			v978 = false
			if v979 then
				v980 = nil
			end
		end
		if not v979 and (not v1058 and (v_u_375 and (v_u_391 and (not v_u_382 and (not v_u_372 and (v_u_383.Magnitude > 0.3 and not v945)))))) then
			local v1067 = v_u_383
			local v1068 = -v1067.X
			local v1069 = -v1067.Z
			v_u_370 = math.atan2(v1068, v1069)
			v978 = true
		end
		if v979 then
			if not (v944 or v948) then
				local v1070 = v980 or v_u_370
				local v1071 = v931.CFrame.LookVector
				local v1072 = -v1071.X
				local v1073 = -v1071.Z
				local v1074 = (v1070 - math.atan2(v1072, v1073) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				if math.abs(v1074) > 0.0005 then
					v_u_38 = v1070
					v931.CFrame = CFrame.new(v977) * CFrame.Angles(0, v1070, 0)
				end
			end
		elseif not (v944 or v948) then
			local v1075 = v945 and 3 or (v978 and 11 or (v_u_392 == "Keyboard" and 24 or 16))
			local v1076 = (v945 and 2.5 or (v_u_375 and 9 or 16)) * p928
			local v1077 = v931.CFrame.LookVector
			local v1078 = -v1077.X
			local v1079 = -v1077.Z
			local v1080 = math.atan2(v1078, v1079)
			local v1081 = (v_u_370 - v1080 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
			local v1082 = -v1075 * p928
			local v1083 = v1081 * (1 - math.exp(v1082))
			local v1084 = -v1076
			local v1085 = math.clamp(v1083, v1084, v1076)
			if math.abs(v1081) > 0.002 then
				v_u_38 = v1080 + v1085
				v931.CFrame = CFrame.new(v977) * CFrame.Angles(0, v_u_38, 0)
			end
		end
		local v1086 = v_u_372
		if v1086 then
			if v_u_392 == "Touch" and v_u_390 ~= nil then
				v1086 = v_u_390:triggerHeld() == true
			else
				v1086 = false
			end
		end
		local v1087 = v_u_372
		if v1087 then
			v1087 = v_u_391
		end
		local v1088 = v1086 and not v_u_55
		if not v1088 then
			if v1087 then
				v1088 = not v_u_56
			else
				v1088 = v1087
			end
		end
		v_u_55 = v1086
		v_u_56 = v1087
		v_u_726(v1088, v1088)
	else
		v_u_373 = nil
	end
end
local v_u_1089 = false
local v_u_1090 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_1091 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_1092 = {
	["touchGuiHidden"] = 0,
	["pmDisabled"] = 0
}
local function v_u_1096(p_u_1093) -- name: hideTouchGui
	-- upvalues: (copy) v_u_1092, (copy) v_u_1090
	if p_u_1093.Name == "TouchGui" and p_u_1093:IsA("ScreenGui") then
		if p_u_1093.Enabled then
			p_u_1093.Enabled = false
			local v1094 = v_u_1092
			v1094.touchGuiHidden = v1094.touchGuiHidden + 1
		end
		if not v_u_1090[p_u_1093] then
			v_u_1090[p_u_1093] = true
			p_u_1093:GetPropertyChangedSignal("Enabled"):Connect(function()
				-- upvalues: (copy) p_u_1093, (ref) v_u_1092
				if p_u_1093.Enabled then
					p_u_1093.Enabled = false
					local v1095 = v_u_1092
					v1095.touchGuiHidden = v1095.touchGuiHidden + 1
				end
			end)
		end
	end
end
local function v_u_1106(p1097) -- name: disablePlayerModule
	-- upvalues: (copy) v_u_1091, (copy) v_u_1092
	if p1097:IsA("ModuleScript") then
		local v1098 = require
		local v1099, v1100 = pcall(v1098, p1097)
		if v1099 and (type(v1100) == "table" and v1100.GetControls) then
			local v1101 = v1100.GetControls
			local v1102, v1103 = pcall(v1101, v1100)
			if v1102 and (type(v1103) == "table" and v1103.Disable) then
				local v1104 = v1103.Disable
				if pcall(v1104, v1103) then
					v_u_1091[p1097] = true
					local v1105 = v_u_1092
					v1105.pmDisabled = v1105.pmDisabled + 1
				end
			end
		end
	end
end
local function v_u_1111() -- name: applyDefaultControlsOff
	-- upvalues: (copy) v_u_6, (copy) v_u_22, (copy) v_u_1096, (copy) v_u_1106
	local function v1107()
		-- upvalues: (ref) v_u_6
		if v_u_6.TouchControlsEnabled then
			v_u_6.TouchControlsEnabled = false
		end
	end
	pcall(v1107)
	local v1108 = v_u_22:FindFirstChildOfClass("PlayerGui")
	local v1109 = v1108 and v1108:FindFirstChild("TouchGui")
	if v1109 then
		v_u_1096(v1109)
	end
	local v1110 = v_u_22:FindFirstChildOfClass("PlayerScripts")
	if v1110 then
		v1110 = v1110:FindFirstChild("PlayerModule")
	end
	if v1110 then
		task.spawn(v_u_1106, v1110)
	end
end
local function v_u_1119() -- name: disableDefaultControls
	-- upvalues: (copy) v_u_1111, (ref) v_u_1089, (copy) v_u_6, (copy) v_u_22, (copy) v_u_1096, (copy) v_u_1091, (copy) v_u_1106
	v_u_1111()
	if not v_u_1089 then
		v_u_1089 = true
		local function v1113()
			-- upvalues: (ref) v_u_6
			v_u_6:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
				-- upvalues: (ref) v_u_6
				if v_u_6.TouchControlsEnabled then
					local function v1112()
						-- upvalues: (ref) v_u_6
						v_u_6.TouchControlsEnabled = false
					end
					pcall(v1112)
				end
			end)
		end
		pcall(v1113)
		local function v1114()
			-- upvalues: (ref) v_u_22, (ref) v_u_1111
			v_u_22:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
				-- upvalues: (ref) v_u_1111
				task.defer(v_u_1111)
			end)
			v_u_22:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
				-- upvalues: (ref) v_u_1111
				task.defer(v_u_1111)
			end)
		end
		pcall(v1114)
		task.spawn(function()
			-- upvalues: (ref) v_u_22, (ref) v_u_1096
			local v1115 = v_u_22:FindFirstChildOfClass("PlayerGui") or v_u_22:WaitForChild("PlayerGui", 30)
			if v1115 then
				v1115.ChildAdded:Connect(v_u_1096)
				local v1116 = v1115:FindFirstChild("TouchGui")
				if v1116 then
					v_u_1096(v1116)
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_22, (ref) v_u_1091, (ref) v_u_1106
			local v1117 = v_u_22:FindFirstChildOfClass("PlayerScripts") or v_u_22:WaitForChild("PlayerScripts", 30)
			if v1117 then
				v1117.ChildAdded:Connect(function(p1118)
					-- upvalues: (ref) v_u_1091, (ref) v_u_1106
					if p1118.Name == "PlayerModule" and not v_u_1091[p1118] then
						task.spawn(v_u_1106, p1118)
					end
				end)
			end
		end)
		v_u_22.CharacterAdded:Connect(function()
			-- upvalues: (ref) v_u_1111
			v_u_1111()
			task.delay(0.5, v_u_1111)
		end)
	end
end
local function v_u_1126() -- name: reassertTouchMove
	-- upvalues: (copy) v_u_74, (ref) v_u_392, (copy) v_u_22
	local v1120 = v_u_74.mv
	if v_u_392 == "Touch" and (v1120.Magnitude >= 0.3 and os.clock() - v_u_74.at <= 0.25) then
		local v1121 = v_u_22.Character
		local v1122
		if v1121 and v1121.Parent then
			v1122 = v1121:FindFirstChildOfClass("Humanoid")
			v1121:FindFirstChild("HumanoidRootPart")
		else
			v1121 = nil
			v1122 = nil
		end
		if v1121 and (v1122 and (v1122.Health > 0 and v1121:GetAttribute("Dead") ~= true)) then
			local v1123 = v1121:GetAttribute("Action")
			local v1124 = v_u_22:GetAttribute("PredAction")
			if v1123 ~= "Revive" and (v1123 ~= "Climb" and (v1123 ~= "Vault" and (type(v1124) ~= "string" or v1124 == ""))) then
				if v1122.MoveDirection.Magnitude < 0.05 then
					v1122:Move(v1120, false)
					local v1125 = v_u_74
					v1125.reasserts = v1125.reasserts + 1
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_12.init(p_u_1127) -- name: init
	-- upvalues: (ref) v_u_380, (ref) v_u_23, (copy) v_u_69, (ref) v_u_24, (copy) v_u_22, (ref) v_u_392, (copy) v_u_7, (ref) v_u_377, (ref) v_u_376, (ref) v_u_391, (copy) v_u_108, (copy) v_u_1126, (copy) v_u_70, (copy) v_u_148, (ref) v_u_369, (ref) v_u_375, (ref) v_u_390, (copy) v_u_12, (ref) v_u_54, (copy) v_u_53, (ref) v_u_368, (ref) v_u_51, (ref) v_u_383, (ref) v_u_370, (ref) v_u_382, (ref) v_u_372, (ref) v_u_388, (copy) v_u_1092, (copy) v_u_6, (ref) v_u_59, (ref) v_u_387, (copy) v_u_254, (copy) v_u_15, (copy) v_u_195, (copy) v_u_138, (copy) v_u_99, (copy) v_u_201, (copy) v_u_196, (copy) v_u_226, (ref) v_u_386, (copy) v_u_158, (copy) v_u_11, (copy) v_u_727, (copy) v_u_13, (ref) v_u_389, (copy) v_u_808, (copy) v_u_732, (copy) v_u_265, (copy) v_u_71, (copy) v_u_577, (copy) v_u_354
	v_u_380 = p_u_1127
	v_u_23 = p_u_1127.shared.Skills
	local function v1129()
		-- upvalues: (copy) p_u_1127, (ref) v_u_69
		local v1128 = p_u_1127.lib.ZombieBlock
		v1128.init(p_u_1127)
		v_u_69.zblock = v1128
	end
	pcall(v1129)
	v_u_24 = p_u_1127.config
	v_u_22:SetAttribute("InputDevice", v_u_392)
	if not v_u_69.blockMoveConn then
		local function v1134()
			-- upvalues: (ref) v_u_7, (ref) v_u_69, (ref) v_u_377, (ref) v_u_22, (ref) v_u_376, (ref) v_u_391, (ref) v_u_108, (ref) v_u_1126, (ref) v_u_70
			v_u_69.blockMoveConn = (v_u_7.PreAnimation or v_u_7.Stepped):Connect(function()
				-- upvalues: (ref) v_u_377, (ref) v_u_22, (ref) v_u_376, (ref) v_u_391, (ref) v_u_108, (ref) v_u_1126, (ref) v_u_70, (ref) v_u_69
				local v1130 = v_u_377
				if not v1130 then
					if v_u_22.Character == nil then
						v1130 = false
					else
						v1130 = v_u_376 ~= "Transit"
					end
				end
				if v1130 then
					if not v_u_391 or v_u_108() then
						local v1131 = v_u_22.Character
						local v1132
						if v1131 and v1131.Parent then
							v1132 = v1131:FindFirstChildOfClass("Humanoid")
							v1131:FindFirstChild("HumanoidRootPart")
						else
							v1131 = nil
							v1132 = nil
						end
						if v1131 and (v1132 and (v1132.Health > 0 and v1132.MoveDirection.Magnitude > 0.001)) then
							v1132:Move(Vector3.new(0, 0, 0), false)
							local v1133 = v_u_69
							v1133.blockedMoves = v1133.blockedMoves + 1
						end
					else
						v_u_1126()
						v_u_70.keepKeyMove()
					end
				else
					return
				end
			end)
		end
		pcall(v1134)
	end
	local v1135, v1136 = pcall(function()
		-- upvalues: (copy) p_u_1127
		return p_u_1127.lib.TouchControls
	end)
	if v1135 and v1136 then
		local v_u_1137 = nil
		local function v1138()
			-- upvalues: (ref) v_u_1137, (copy) p_u_1127
			v_u_1137 = p_u_1127.shared.Theme
		end
		pcall(v1138)
		local v1139 = v_u_22:WaitForChild("PlayerGui")
		local v1140 = v1136.new
		local v1148 = {
			["theme"] = v_u_1137,
			["onAction"] = function(p1141, p1142) -- name: onAction
				-- upvalues: (ref) v_u_148
				v_u_148(p1141, p1142)
			end,
			["isThrowMode"] = function() -- name: isThrowMode
				-- upvalues: (copy) p_u_1127
				local v1143 = p_u_1127.controllers
				if v1143 then
					v1143 = p_u_1127.controllers.WeaponClient
				end
				local v1144
				if v1143 == nil then
					v1144 = false
				else
					local v1145 = v1143.isThrowMode
					if type(v1145) == "function" then
						v1144 = v1143.isThrowMode() == true
					else
						v1144 = false
					end
				end
				return v1144
			end,
			["onSprint"] = function(p1146) -- name: onSprint
				-- upvalues: (ref) v_u_392, (ref) v_u_369, (ref) v_u_375, (ref) v_u_148
				if v_u_392 == "Touch" then
					if not (p1146 and v_u_369) then
						if p1146 ~= v_u_375 then
							v_u_148("sprint", p1146)
						end
					end
				else
					return
				end
			end,
			["onLayout"] = function() -- name: onLayout
				-- upvalues: (ref) v_u_390, (copy) p_u_1127, (ref) v_u_12
				if v_u_390 then
					local v1147 = v_u_390:info()
					p_u_1127.emit("touch.layout", v_u_12.touchRects(), {
						["visible"] = v_u_390.visible == true,
						["scale"] = v1147.scale,
						["viewport"] = v1147.viewport,
						["sizeLevel"] = v1147.sizeLevel
					})
				end
			end
		}
		local v1149, v1150 = pcall(v1140, v1139, v1148)
		if v1149 then
			v_u_390 = v1150
			if v_u_12._lightMain and v1150.setLightMain then
				v1150:setLightMain(true)
			end
		else
			warn("[Input] touch controls failed:", v1150)
		end
	end
	local v1151 = p_u_1127.on
	local function v1152()
		-- upvalues: (ref) v_u_390
		if v_u_390 then
			v_u_390:relayout()
		end
	end
	pcall(v1151, "ui.rebuild", v1152)
	for _, v1153 in { "weapon.fired", "weapon.melee" } do
		local v1154 = p_u_1127.on
		local function v1155()
			-- upvalues: (ref) v_u_390, (ref) v_u_392
			if v_u_390 and v_u_392 == "Touch" then
				v_u_390:shotTick()
			end
		end
		pcall(v1154, v1153, v1155)
	end
	p_u_1127.command("net.stall", function(p1156)
		-- upvalues: (ref) v_u_22, (ref) v_u_54, (ref) v_u_53, (ref) v_u_368, (ref) v_u_51
		local v1157 = v_u_22.Character
		local v1158
		if v1157 and v1157.Parent then
			v1157:FindFirstChildOfClass("Humanoid")
			v1158 = v1157:FindFirstChild("HumanoidRootPart")
		else
			v1157 = nil
			v1158 = nil
		end
		local v1159 = p1156[1] or "state"
		if v1159 == "off" then
			if v_u_54 and v1158 then
				v1158.Anchored = false
			end
			if v1157 then
				v1157:SetAttribute("HushHeld", nil)
			end
			v_u_54 = nil
			return "net.stall off"
		end
		if v1159 ~= "on" then
			if v1157 then
				v1157 = v1157:GetAttribute("NetDesync")
			end
			local v1160 = string.format
			local v1161 = "net.stall %s attr=%s hold=%s since=%s seq=%d"
			local v1162 = v_u_54 and "ON" or "off"
			local v1163 = tostring(v1157)
			local v1164 = v_u_53.hold
			local v1165 = tostring(v1164)
			local v1166 = v_u_53.since
			local v1167 = tostring(v1166)
			local v1168
			if v_u_368 then
				v1168 = v_u_368.seq
			else
				v1168 = v_u_51
			end
			return v1160(v1161, v1162, v1163, v1165, v1167, v1168)
		end
		local v1169 = p1156[2] == "mute"
		local v1170 = v1169 and 3 or 2
		local v1171 = p1156[v1170]
		local v1172 = tonumber(v1171) or 0
		local v1173 = p1156[v1170 + 1]
		local v1174 = tonumber(v1173) or 1
		local v1175 = p1156[v1170 + 2]
		local v1176 = tonumber(v1175) or 11
		local v1177 = Vector3.new(v1172, 0, v1174)
		v_u_54 = {
			["mute"] = nil,
			["dir"] = nil,
			["speed"] = nil,
			["savedAnchor"] = false,
			["mute"] = v1169,
			["dir"] = v1177.Magnitude <= 0 and Vector3.new(0, 0, 1) or v1177.Unit,
			["speed"] = v1176
		}
		local v1178 = string.format
		local v1179 = tostring(v1169)
		local v1180 = v_u_54.dir
		return v1178("net.stall on mute=%s dir=%s speed=%.1f", v1179, tostring(v1180), v1176)
	end)
	p_u_1127.command("input.state", function()
		-- upvalues: (ref) v_u_392, (ref) v_u_391, (ref) v_u_377, (ref) v_u_383, (ref) v_u_370, (ref) v_u_375, (ref) v_u_369, (ref) v_u_382, (ref) v_u_372, (ref) v_u_22, (ref) v_u_388, (ref) v_u_1092, (ref) v_u_6
		local v1181 = string.format
		local v1182 = "device=%s enabled=%s place=%s move=%s aimYaw=%.2f sprint=%s sneak=%s aim=%s fire=%s ws=%s override=%s touchGui=%s pm=%s tce=%s"
		local v1183 = v_u_392
		local v1184 = v_u_391
		local v1185 = tostring(v1184)
		local v1186 = v_u_377
		local v1187 = tostring(v1186)
		local v1188 = v_u_383
		local v1189 = tostring(v1188)
		local v1190 = v_u_370
		local v1191 = v_u_375
		local v1192 = tostring(v1191)
		local v1193 = v_u_369
		local v1194 = tostring(v1193)
		local v1195 = v_u_382
		local v1196 = tostring(v1195)
		local v1197 = v_u_372
		local v1198 = tostring(v1197)
		local v1199 = v_u_22.Character
		local v1200
		if v1199 and v1199.Parent then
			v1200 = v1199:FindFirstChildOfClass("Humanoid")
			v1199:FindFirstChild("HumanoidRootPart")
		else
			v1200 = nil
		end
		if v1200 then
			v1200 = v1200.WalkSpeed
		end
		local v1201 = tostring(v1200)
		local v1202 = not v_u_388 and "off" or string.format("%.1f,%.1f", v_u_388.X, v_u_388.Z)
		local v1203 = v_u_22:FindFirstChildOfClass("PlayerGui")
		if v1203 then
			v1203 = v1203:FindFirstChild("TouchGui")
		end
		local v1204 = v1203 and v1203:IsA("ScreenGui") and (v1203.Enabled and "ENABLED" or "off") or "none"
		local v1205 = v_u_1092.touchGuiHidden
		local v1206 = v1204 .. "/" .. tostring(v1205)
		local v1207 = v_u_1092.pmDisabled
		local v1208 = tostring(v1207)
		local v1209 = v_u_6.TouchControlsEnabled
		return v1181(v1182, v1183, v1185, v1187, v1189, v1190, v1192, v1194, v1196, v1198, v1201, v1202, v1206, v1208, (tostring(v1209)))
	end)
	p_u_1127.command("input.touch", function()
		-- upvalues: (ref) v_u_390, (ref) v_u_22
		if not v_u_390 then
			return "no touch controls"
		end
		local v1210 = v_u_390:info()
		local v1211 = {}
		local v1212 = string.format
		local v1213 = "visible=%s dead=%s scale=%.3f size=%d viewport=%dx%d canvas=%dx%d quickShift=%d"
		local v1214 = v_u_390.visible
		local v1215 = tostring(v1214)
		local v1216 = v_u_22.Character
		local v1217
		if v1216 == nil then
			v1217 = false
		else
			v1217 = v1216:GetAttribute("Dead") == true
		end
		__set_list(v1211, 1, {v1212(v1213, v1215, tostring(v1217), v1210.scale, v1210.sizeLevel, v1210.viewport.X, v1210.viewport.Y, v1210.canvas.X, v1210.canvas.Y, v1210.quickShift)})
		local v1218 = v_u_390.clusterRects
		local v1219 = v_u_390
		local v1220, v1221 = pcall(v1218, v1219)
		if v1220 then
			local v1222 = {}
			for v1223 in v1221 do
				table.insert(v1222, v1223)
			end
			table.sort(v1222)
			for _, v1224 in v1222 do
				local v1225 = v1221[v1224]
				local v1226 = string.format
				local v1227 = v1225.Min.X
				local v1228 = v1225.Min.Y
				local v1229 = v1225.Max.X
				local v1230 = v1225.Max.Y
				table.insert(v1211, v1226("%s=%d,%d..%d,%d", v1224, v1227, v1228, v1229, v1230))
			end
		end
		return table.concat(v1211, " ")
	end)
	p_u_1127.command("input.aimstick", function(p1231)
		-- upvalues: (ref) v_u_390, (ref) v_u_372, (ref) v_u_12
		if not v_u_390 then
			return "no touch controls"
		end
		if p1231[1] == nil or (p1231[1] == "off" or p1231[1] == "") then
			v_u_390:debugStick(nil)
		else
			local v1232 = v_u_390
			local v1233 = Vector2.new
			local v1234 = p1231[1]
			local v1235 = tonumber(v1234) or 0
			local v1236 = p1231[2]
			v1232:debugStick(v1233(v1235, tonumber(v1236) or 0))
		end
		local v1237 = string.format
		local v1238 = v_u_390.visible
		local v1239 = tostring(v1238)
		local v1240 = v_u_390
		local v1241 = tostring(v1240:aimHeldNow())
		local v1242 = v_u_390
		local v1243 = tostring(v1242:triggerHeld())
		local v1244 = v_u_372
		local v1245 = tostring(v1244)
		local v1246 = v_u_12.fireRepeat
		return v1237("visible=%s aimHeld=%s trigger=%s fire=%s repeat=%s defl=%.2f", v1239, v1241, v1243, v1245, tostring(v1246()), v_u_390:aimDeflection())
	end)
	p_u_1127.command("input.ring", function(p1247)
		-- upvalues: (ref) v_u_390, (ref) v_u_22
		if v_u_390 then
			local v1248 = v_u_390.ringCoach
			if type(v1248) == "function" then
				local v1249 = p1247[1] or "state"
				if v1249 == "start" then
					local v1250 = v_u_390
					local v1251 = p1247[2]
					v1250:startCoach(tonumber(v1251) or 6, "test")
				elseif v1249 == "stop" then
					v_u_390:stopCoach()
				elseif v1249 == "reset" then
					local v1252 = v_u_390
					local v1253 = v_u_390
					v_u_390.ringUsed = false
					v1252.stuckShown = false
					v1253.coachRaid = nil
				end
				local v1254 = v_u_390:ringCoach()
				local v1255 = string.format
				local v1256 = v_u_390.visible
				local v1257 = tostring(v1256)
				local v1258 = v1254.active
				local v1259 = tostring(v1258)
				local v1260 = v1254.reason
				local v1261 = tostring(v1260)
				local v1262 = v1254.left
				local v1263 = v1254.raid
				local v1264 = tostring(v1263)
				local v1265 = v1254.used
				local v1266 = tostring(v1265)
				local v1267 = v1254.stuckShown
				local v1268 = tostring(v1267)
				local v1269 = v1254.hint
				local v1270 = tostring(v1269)
				local v1271 = v1254.pulse
				local v1272 = v_u_22
				return v1255("visible=%s active=%s reason=%s left=%.1f raid=%s used=%s stuckShown=%s hint=%s pulse=%s pulseSize=%d coachAttr=%s", v1257, v1259, v1261, v1262, v1264, v1266, v1268, v1270, tostring(v1271), v1254.pulseSize, (tostring(v1272:GetAttribute("TouchRingCoach"))))
			end
		end
		return "no touch controls"
	end)
	p_u_1127.command("input.move", function(p1273)
		-- upvalues: (ref) v_u_59
		local v1274 = {}
		local v1275 = Vector2.new
		local v1276 = p1273[1]
		local v1277 = tonumber(v1276) or 0
		local v1278 = p1273[2]
		v1274.v = v1275(v1277, tonumber(v1278) or 1)
		local v1279 = os.clock()
		local v1280 = p1273[3]
		v1274.untilT = v1279 + (tonumber(v1280) or 1)
		v_u_59 = v1274
		return "moving"
	end)
	p_u_1127.command("input.device", function(p1281)
		-- upvalues: (ref) v_u_387, (ref) v_u_254, (ref) v_u_392
		local v1282
		if p1281[1] and (p1281[1] ~= "" and p1281[1] ~= "auto") then
			v1282 = p1281[1]
		else
			v1282 = nil
		end
		v_u_387 = v1282
		v_u_254()
		return "device " .. v_u_392
	end)
	p_u_1127.command("input.key", function(p1283)
		-- upvalues: (ref) v_u_15, (ref) v_u_195, (ref) v_u_148, (ref) v_u_138, (ref) v_u_392, (ref) v_u_375, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (ref) v_u_99, (ref) v_u_391, (ref) v_u_377, (ref) v_u_22, (ref) v_u_376, (ref) v_u_108, (ref) v_u_380
		local v_u_1284 = p1283[1]
		local v1285, v1286 = pcall(function()
			-- upvalues: (copy) v_u_1284
			return Enum.KeyCode[v_u_1284 or ""]
		end)
		if not (v1285 and v1286) then
			return "usage: input.key <KeyCode name> [press]"
		end
		local v1287 = {}
		for v1288, v1289 in v_u_15 do
			if not (table.find(v1289.keys, v1286) or table.find(v1289.pad, v1286)) then
				continue
			end
			table.insert(v1287, v1288)
		end
		table.sort(v1287)
		local v1290 = v_u_195(v1287)
		if p1283[2] == "press" then
			for _, v1291 in v1290 do
				v_u_148(v1291, true)
			end
			for _, v1292 in v1290 do
				if v_u_138.eaten[v1292] then
					v_u_138.eaten[v1292] = nil
				else
					local v1293 = v_u_392
					if v1292 == "sprint" then
						if v1293 == "Keyboard" or v1293 == "Touch" then
							v_u_375 = false
						end
						if v_u_375 then
							v_u_369 = false
						end
						if v_u_390 then
							v_u_390:setToggle("sprint", v_u_375)
							v_u_390:setToggle("sneak", v_u_369)
							v_u_390:setToggle("aim", v_u_382)
						end
					elseif v1292 ~= "sneak" then
						if v1292 == "aim" then
							v_u_382 = false
						elseif v1292 == "fire" then
							v_u_372 = false
						end
					end
					v_u_99(v1292, false, nil)
				end
			end
		end
		local v1294 = string.format
		local v1295 = "bound={%s} fires={%s} captured=%s enabled=%s promptList=%s"
		local v1296 = table.concat(v1287, ",")
		local v1297 = table.concat(v1290, ",")
		local v1298
		if v_u_391 then
			local v1299 = v_u_377
			if not v1299 then
				if v_u_22.Character == nil then
					v1299 = false
				else
					v1299 = v_u_376 ~= "Transit"
				end
			end
			v1298 = not v1299 and true or v_u_108()
		else
			v1298 = true
		end
		local v1300 = tostring(v1298)
		local v1301 = v_u_391
		local v1302 = tostring(v1301)
		local v1303 = v_u_380
		if v1303 then
			v1303 = v_u_380.controllers.Prompts
		end
		local v1304, v1305
		if not v1303 then
			v1304 = v_u_138.ctx.promptList
			if v1304 == nil then
				v1308 = false
			else
				v1308, v1305 = pcall(v1304)
				if v1308 then
					v1308 = v1305 == true
				end
			end
			return v1294(v1295, v1296, v1297, v1300, v1302, (tostring(v1308)))
		end
		local v1306 = v1303.choiceListVisible
		if type(v1306) ~= "function" then
			v1304 = v_u_138.ctx.promptList
			if v1304 == nil then
				v1308 = false
			else
				v1308, v1305 = pcall(v1304)
				if v1308 then
					v1308 = v1305 == true
				end
			end
			return v1294(v1295, v1296, v1297, v1300, v1302, (tostring(v1308)))
		end
		local v1307 = v1303.choiceListVisible
		local v1308, v1309 = pcall(v1307)
		if v1308 then
			v1308 = v1309 == true
		end
		return v1294(v1295, v1296, v1297, v1300, v1302, (tostring(v1308)))
	end)
	p_u_1127.command("input.pad", function(p_u_1310)
		-- upvalues: (ref) v_u_201, (ref) v_u_196, (ref) v_u_226, (ref) v_u_386, (ref) v_u_195, (ref) v_u_158, (ref) v_u_148, (ref) v_u_138, (ref) v_u_392, (ref) v_u_375, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (ref) v_u_99
		local v1311, v1312 = pcall(function()
			-- upvalues: (copy) p_u_1310
			return Enum.KeyCode[p_u_1310[1] or ""]
		end)
		if v1311 and v1312 then
			local v_u_1313 = {
				["UserInputType"] = Enum.UserInputType.Gamepad1,
				["KeyCode"] = v1312
			}
			local v1314 = p_u_1310[2]
			local v1315 = tonumber(v1314) or 0.1
			if #v_u_201(v1312) > 0 then
				v_u_196[v1312] = {
					["t"] = nil,
					["fired"] = false,
					["t"] = os.clock()
				}
				task.delay(v1315, function()
					-- upvalues: (ref) v_u_226, (ref) v_u_386, (copy) v_u_1313
					v_u_226()
					v_u_386(v_u_1313)
				end)
				return "padHold " .. v1312.Name .. " " .. v1315 .. "s"
			else
				local v1316 = v_u_195((v_u_158(v_u_1313)))
				for _, v1317 in v1316 do
					v_u_148(v1317, true)
					if v_u_138.eaten[v1317] then
						v_u_138.eaten[v1317] = nil
					else
						local v1318 = v_u_392
						if v1317 == "sprint" then
							if v1318 == "Keyboard" or v1318 == "Touch" then
								v_u_375 = false
							end
							if v_u_375 then
								v_u_369 = false
							end
							if v_u_390 then
								v_u_390:setToggle("sprint", v_u_375)
								v_u_390:setToggle("sneak", v_u_369)
								v_u_390:setToggle("aim", v_u_382)
							end
						elseif v1317 ~= "sneak" then
							if v1317 == "aim" then
								v_u_382 = false
							elseif v1317 == "fire" then
								v_u_372 = false
							end
						end
						v_u_99(v1317, false, nil)
					end
				end
				return "pad " .. v1312.Name .. " fires={" .. table.concat(v1316, ",") .. "}"
			end
		else
			return "usage: input.pad <KeyCode> <seconds>"
		end
	end)
	p_u_1127.command("pad.on", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_392
		v_u_11.setActive(true)
		return "" .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.off", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_392
		v_u_11.reset()
		return "" .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.state", function()
		-- upvalues: (ref) v_u_727, (ref) v_u_392, (ref) v_u_11
		local v1319 = string.format("focus picks=%d drops=%d last=%s", v_u_727.picks, v_u_727.drops, v_u_727.last)
		return (not v1319 and "" or v1319 .. " | ") .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.press", function(p1320)
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_392
		local v1321 = v_u_11.code(p1320[1])
		if not v1321 then
			return "usage: pad.press <A|B|X|Y|LB|RB|LT|RT|LS|RS|View|Menu|Up|Down|Left|Right|KeyCode> [holdSeconds]"
		end
		local v1322 = v_u_11.press
		local v1323 = p1320[2]
		v1322(v1321, (tonumber(v1323)))
		local v1324 = v_u_11.lastClick
		local v1325
		if v1321 == v_u_13.ButtonA and v1324 ~= "" then
			v1325 = "click " .. v1324
		else
			v1325 = nil
		end
		return (not v1325 and "" or v1325 .. " | ") .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.down", function(p1326)
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_392
		local v1327 = v_u_11.code(p1326[1])
		if not v1327 then
			return "usage: pad.down <button>"
		end
		v_u_11.down(v1327)
		local v1328
		if v1327 == v_u_13.ButtonA and v_u_11.lastClick ~= "" then
			v1328 = "click " .. v_u_11.lastClick
		else
			v1328 = nil
		end
		return (not v1328 and "" or v1328 .. " | ") .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.up", function(p1329)
		-- upvalues: (ref) v_u_11, (ref) v_u_392
		local v1330 = v_u_11.code(p1329[1])
		if not v1330 then
			return "usage: pad.up <button>"
		end
		v_u_11.up(v1330)
		return "" .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.stick", function(p1331)
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_392
		local v1332 = v_u_11.code(p1331[1])
		if v1332 ~= v_u_13.Thumbstick1 and v1332 ~= v_u_13.Thumbstick2 then
			return "usage: pad.stick <L|R> <x> <y> [seconds]   (y up, -1..1)"
		end
		local v1333 = v_u_11.stick
		local v1334 = Vector2.new
		local v1335 = p1331[2]
		local v1336 = tonumber(v1335) or 0
		local v1337 = p1331[3]
		local v1338 = v1334(v1336, tonumber(v1337) or 0)
		local v1339 = p1331[4]
		v1333(v1332, v1338, (tonumber(v1339)))
		return "" .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.trigger", function(p1340)
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_392
		local v1341 = v_u_11.code(p1340[1])
		if v1341 ~= v_u_13.ButtonR2 and v1341 ~= v_u_13.ButtonL2 then
			return "usage: pad.trigger <LT|RT> <0..1> [seconds]"
		end
		local v1342 = v_u_11.trigger
		local v1343 = p1340[2]
		local v1344 = tonumber(v1343) or 1
		local v1345 = p1340[3]
		v1342(v1341, v1344, (tonumber(v1345)))
		return "" .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.nav", function(p1346)
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_6
		local v1347 = p1346[1] or ""
		local v1348 = v_u_11.code(string.upper((string.sub(v1347, 1, 1))) .. string.sub(v1347, 2))
		if v1348 ~= v_u_13.DPadUp and (v1348 ~= v_u_13.DPadDown and (v1348 ~= v_u_13.DPadLeft and v1348 ~= v_u_13.DPadRight)) then
			return "usage: pad.nav <up|down|left|right> [n]"
		end
		local v1349 = p1346[2]
		local v1350 = tonumber(v1349) or 1
		for _ = 1, math.clamp(v1350, 1, 40) do
			v_u_11.press(v1348, 0)
		end
		return "focus " .. v_u_11.describe(v_u_6.SelectedObject)
	end)
	p_u_1127.command("pad.focus", function()
		-- upvalues: (ref) v_u_389, (ref) v_u_808, (ref) v_u_11, (ref) v_u_6, (ref) v_u_392, (ref) v_u_377, (ref) v_u_22, (ref) v_u_376, (ref) v_u_391, (ref) v_u_108, (ref) v_u_732
		v_u_389 = 0
		v_u_808()
		local v1351 = "focus "
		local v1352 = v_u_11.describe(v_u_6.SelectedObject)
		local v1353 = " device="
		local v1354 = v_u_392
		local v1355 = " uiInCharge="
		local v1356 = v_u_377
		if not v1356 then
			if v_u_22.Character == nil then
				v1356 = false
			else
				v1356 = v_u_376 ~= "Transit"
			end
		end
		local v1357 = not v1356 or (not v_u_391 or v_u_108())
		if not v1357 then
			local v1358 = v_u_22.Character
			local v1359
			if v1358 == nil then
				v1359 = false
			else
				v1359 = v1358:GetAttribute("Dead") == true
			end
			v1357 = v1359 or v_u_732()
		end
		return v1351 .. v1352 .. v1353 .. v1354 .. v1355 .. tostring(v1357)
	end)
	p_u_1127.command("pad.real", function(p1360)
		-- upvalues: (ref) v_u_11, (ref) v_u_392, (ref) v_u_69, (ref) v_u_254
		if p1360[1] == "off" then
			v_u_11.realMode = false
			v_u_11.reset()
			return "real off | " .. "device=" .. v_u_392 .. " " .. v_u_11.state()
		end
		v_u_11.realMode = true
		v_u_69.simPreferred = "Keyboard"
		v_u_69.eventDevice = "Keyboard"
		v_u_11.setActive(true)
		v_u_254()
		return "real on | " .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.mouse", function()
		-- upvalues: (ref) v_u_265, (ref) v_u_69, (ref) v_u_254, (ref) v_u_392, (ref) v_u_11
		local v1361 = v_u_265({
			["UserInputType"] = nil,
			["Delta"] = Vector3.new(30, 25, 0),
			["UserInputType"] = Enum.UserInputType.MouseMovement
		}, true)
		if v1361 and v1361 ~= v_u_69.eventDevice then
			v_u_69.eventDevice = v1361
			v_u_254()
		end
		local v1362 = string.format("clears=%d", v_u_69.clears)
		return (not v1362 and "" or v1362 .. " | ") .. "device=" .. v_u_392 .. " " .. v_u_11.state()
	end)
	p_u_1127.command("pad.guard", function()
		-- upvalues: (ref) v_u_196, (ref) v_u_392, (ref) v_u_377, (ref) v_u_22, (ref) v_u_376, (ref) v_u_391, (ref) v_u_108, (ref) v_u_732, (ref) v_u_11, (ref) v_u_6, (ref) v_u_69
		local v1363 = {}
		for v1364, v1365 in v_u_196 do
			local v1366 = v1364.Name .. (v1365.fired and "*" or "")
			table.insert(v1363, v1366)
		end
		local v1367 = string.format
		local v1368 = "device=%s inCharge=%s live=%s blocked=%s dead=%s modal=%s sel=%s clears=%d hold=%s eventDevice=%s swallowed=%d holdPolls=%d padTip=%s holds={%s}"
		local v1369 = v_u_392
		local v1370 = v_u_377
		if not v1370 then
			if v_u_22.Character == nil then
				v1370 = false
			else
				v1370 = v_u_376 ~= "Transit"
			end
		end
		local v1371 = not v1370 or (not v_u_391 or v_u_108())
		if not v1371 then
			local v1372 = v_u_22.Character
			local v1373
			if v1372 == nil then
				v1373 = false
			else
				v1373 = v1372:GetAttribute("Dead") == true
			end
			v1371 = v1373 or v_u_732()
		end
		local v1374 = tostring(v1371)
		local v1375 = v_u_377
		if not v1375 then
			if v_u_22.Character == nil then
				v1375 = false
			else
				v1375 = v_u_376 ~= "Transit"
			end
		end
		local v1376 = tostring(v1375)
		local v1377 = not v_u_391 or v_u_108()
		local v1378 = tostring(v1377)
		local v1379 = v_u_22.Character
		local v1380
		if v1379 == nil then
			v1380 = false
		else
			v1380 = v1379:GetAttribute("Dead") == true
		end
		local v1381 = tostring(v1380)
		local v1382 = v_u_732()
		local v1383 = tostring(v1382)
		local v1384 = v_u_11.describe(v_u_6.SelectedObject)
		local v1385 = v_u_69.clears
		local v1386 = v_u_22
		local v1387 = tostring(v1386:GetAttribute("PadFocusHold"))
		local v1388 = v_u_69.eventDevice
		local v1389 = tostring(v1388)
		local v1390 = v_u_69.swallowed
		local v1391 = v_u_69.holdPolls
		local v1392 = v_u_69.padTipShown
		return v1367(v1368, v1369, v1374, v1376, v1378, v1381, v1383, v1384, v1385, v1387, v1389, v1390, v1391, tostring(v1392), table.concat(v1363, ","))
	end)
	p_u_1127.command("pad.diag", function(p1393)
		-- upvalues: (ref) v_u_71
		if p1393[1] == "reset" then
			local v1394 = v_u_71
			local v1395 = v_u_71
			v_u_71.navSteps = 0
			v1394.aHit = 0
			v1395.aMiss = 0
		end
		return v_u_71.line("hook")
	end)
	p_u_1127.command("pad.navmode", function(p1396)
		-- upvalues: (ref) v_u_22, (ref) v_u_71
		local v1397 = p1396[1]
		if v1397 == "stick" or (v1397 == "window" or v1397 == "engine") then
			local v1398 = v_u_22
			local v1399 = "PadNavMode"
			if v1397 == "stick" then
				v1397 = nil
			end
			v1398:SetAttribute(v1399, v1397)
		end
		local v1400 = v_u_71.mode()
		local v1401 = v_u_71.navOff
		return "mode=" .. v1400 .. " navOff=" .. tostring(v1401)
	end)
	p_u_1127.command("input.assist", function(p1402)
		-- upvalues: (ref) v_u_22, (ref) v_u_69, (ref) v_u_577, (ref) v_u_392, (ref) v_u_370
		if p1402[1] == "on" or p1402[1] == "off" then
			v_u_22:SetAttribute("AimAssist", p1402[1] == "on")
		elseif p1402[1] == "clear" then
			v_u_22:SetAttribute("AimAssist", nil)
		elseif p1402[1] == "reset" then
			local v1403 = v_u_69.assistStats
			local v1404 = v_u_69.assistStats
			v1403.pulls = 0
			v1404.last = 0
		end
		local v1405 = v_u_577[v_u_392]
		if not v1405 or v_u_22:GetAttribute("AimAssist") == false then
			v1405 = nil
		end
		local v1406 = string.format
		local v1407 = "device=%s attr=%s active=%s cone=%.1f pull=%.2f pulls=%d lastAng=%.1f lock=%s aimYaw=%.3f"
		local v1408 = v_u_392
		local v1409 = v_u_22
		local v1410 = tostring(v1409:GetAttribute("AimAssist"))
		local v1411 = v1405 ~= nil
		local v1412 = tostring(v1411)
		local v1413
		if v1405 then
			local v1414 = v1405.cone
			v1413 = math.deg(v1414)
		else
			v1413 = 0
		end
		local v1415 = not v1405 and 0 or v1405.pull
		local v1416 = v_u_69.assistStats.pulls
		local v1417 = v_u_69.assistStats.last
		local v1418 = v_u_69.assistLock
		return v1406(v1407, v1408, v1410, v1412, v1413, v1415, v1416, v1417, tostring(v1418), v_u_370)
	end)
	p_u_1127.command("pad.reach", function(p1419)
		-- upvalues: (ref) v_u_11
		local v1420 = v_u_11.reach
		local v1421 = p1419[1]
		local v1422, v1423, v1424 = v1420((tonumber(v1421)))
		local v1425 = { string.format("reached=%d steps=%d unreachable=%d", v1422, v1424, #v1423) }
		for v1426, v1427 in v1423 do
			if v1426 > 12 then
				table.insert(v1425, "...")
				break
			end
			local v1428 = v_u_11.describe
			table.insert(v1425, v1428(v1427))
		end
		return table.concat(v1425, " || ")
	end)
	p_u_1127.command("input.action", function(p1429)
		-- upvalues: (ref) v_u_148, (ref) v_u_138, (ref) v_u_392, (ref) v_u_375, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (ref) v_u_99
		local v1430 = p1429[1]
		if not v1430 then
			return "usage: input.action <name> [down|up]"
		end
		local v1431 = p1429[2]
		if v1431 ~= "up" then
			v_u_148(v1430, true)
		end
		if v1431 ~= "down" then
			if v_u_138.eaten[v1430] then
				v_u_138.eaten[v1430] = nil
			else
				local v1432 = v_u_392
				if v1430 == "sprint" then
					if v1432 == "Keyboard" or v1432 == "Touch" then
						v_u_375 = false
					end
					if v_u_375 then
						v_u_369 = false
					end
					if v_u_390 then
						v_u_390:setToggle("sprint", v_u_375)
						v_u_390:setToggle("sneak", v_u_369)
						v_u_390:setToggle("aim", v_u_382)
					end
				elseif v1430 ~= "sneak" then
					if v1430 == "aim" then
						v_u_382 = false
					elseif v1430 == "fire" then
						v_u_372 = false
					end
				end
				v_u_99(v1430, false, nil)
			end
		end
		return "ok"
	end)
	p_u_1127.command("keys.state", function(p1433)
		-- upvalues: (ref) v_u_70, (ref) v_u_354
		if not p1433[1] then
			p1433 = v_u_70.ids()
		end
		local v1434 = {}
		for _, v1435 in p1433 do
			local v1436 = v_u_70.list(v1435)
			local v1437 = v1435 .. "=" .. (not v1436 and "?" or table.concat(v1436, "/"))
			table.insert(v1434, v1437)
		end
		local v1438 = string.format
		local v1439 = v_u_70.current
		local v1440 = v_u_70.loaded
		local v1441 = tostring(v1440)
		local v1442 = v_u_70.moveCustom == true
		local v1443 = tostring(v1442)
		local v1444 = v_u_70.keepReasserts
		local v1445 = v_u_70.capture ~= nil
		local v1446 = tostring(v1445)
		local v1447 = 0
		local v1448 = "str=%q loaded=%s custom=%s keep=%d capturing=%s moveKeys=%d | %s"
		for _ in v_u_354 do
			v1447 = v1447 + 1
		end
		return v1438(v1448, v1439, v1441, v1443, v1444, v1446, v1447, table.concat(v1434, " "))
	end)
	p_u_1127.command("keys.set", function(p1449)
		-- upvalues: (ref) v_u_12, (ref) v_u_70
		local v1450 = p1449[3]
		if v1450 == "none" or v1450 == "None" then
			v1450 = nil
		end
		local v1451 = v_u_12.rebindKey
		local v1452 = p1449[1] or ""
		local v1453 = p1449[2]
		local v1454, v1455 = v1451(v1452, tonumber(v1453) or 1, v1450, p1449[4] == "swap")
		local v1456 = string.format
		local v1457 = "ok=%s err=%s str=%q"
		local v1458 = tostring(v1454)
		local v1459
		if type(v1455) == "table" then
			v1459 = table.concat(v1455, ",")
		else
			v1459 = tostring(v1455)
		end
		return v1456(v1457, v1458, v1459, v_u_70.current)
	end)
	p_u_1127.command("keys.engine", function(p1460)
		-- upvalues: (ref) v_u_7, (ref) v_u_22
		local v1461 = p1460[1]
		local v1462 = tonumber(v1461) or 1
		local v1463 = math.clamp(v1462, 0.1, 5)
		local v1464 = p1460[2]
		local v1465 = tonumber(v1464) or 0
		local v1466 = p1460[3]
		local v1467 = tonumber(v1466) or -1
		local v_u_1468 = Vector3.new(v1465, 0, v1467)
		local v_u_1469 = os.clock() + v1463
		local v_u_1470 = nil
		v_u_1470 = v_u_7.PreRender:Connect(function()
			-- upvalues: (copy) v_u_1469, (ref) v_u_1470, (ref) v_u_22, (copy) v_u_1468
			if v_u_1469 < os.clock() then
				v_u_1470:Disconnect()
			else
				local v1471 = v_u_22.Character
				local v1472
				if v1471 and v1471.Parent then
					v1472 = v1471:FindFirstChildOfClass("Humanoid")
					v1471:FindFirstChild("HumanoidRootPart")
				else
					v1472 = nil
				end
				if v1472 then
					v1472:Move(v_u_1468, false)
				end
			end
		end)
		return "engine move emulated"
	end)
	p_u_1127.command("keys.reset", function(p1473)
		-- upvalues: (ref) v_u_12, (ref) v_u_70
		v_u_12.resetKeys(p1473[1])
		return string.format("str=%q", v_u_70.current)
	end)
	p_u_1127.command("keys.load", function(p1474)
		-- upvalues: (ref) v_u_12, (ref) v_u_70
		v_u_12.loadKeyBindings(p1474[1] == "-" and "" or (p1474[1] or ""))
		return string.format("str=%q", v_u_70.current)
	end)
	p_u_1127.command("keys.conflict", function(p1475)
		-- upvalues: (ref) v_u_70
		return table.concat(v_u_70.conflicts(p1475[1] or "", p1475[2] or ""), ",")
	end)
	p_u_1127.command("keys.log", function(p1476)
		-- upvalues: (ref) v_u_70
		local v1477 = table.concat(v_u_70.log, ",")
		if p1476[1] == "clear" then
			table.clear(v_u_70.log)
		end
		return v1477
	end)
	p_u_1127.command("keys.capture", function()
		-- upvalues: (ref) v_u_22, (ref) v_u_12
		v_u_22:SetAttribute("KeyCaptureResult", "waiting")
		v_u_12.captureKey(function(p1478)
			-- upvalues: (ref) v_u_22
			v_u_22:SetAttribute("KeyCaptureResult", p1478 or "cancel")
		end, function(p1479)
			-- upvalues: (ref) v_u_22
			v_u_22:SetAttribute("KeyCaptureResult", "reserved:" .. p1479)
		end)
		return "capturing"
	end)
	p_u_1127.command("keys.hint", function(p1480)
		-- upvalues: (ref) v_u_12
		local v1481 = {}
		for _, v1482 in p1480 do
			local v1483 = v1482 .. "=" .. v_u_12.hint(v1482)
			table.insert(v1481, v1483)
		end
		return table.concat(v1481, " ")
	end)
end
local function v_u_1488() -- name: syncSelectName
	-- upvalues: (copy) v_u_4, (copy) v_u_13, (copy) v_u_16
	local function v1484()
		-- upvalues: (ref) v_u_4, (ref) v_u_13
		return v_u_4:GetImageForKeyCode(v_u_13.ButtonSelect)
	end
	local v1485, v1486 = pcall(v1484)
	if v1485 and type(v1486) == "string" then
		local v1487 = string.lower(string.match(v1486, "([^/]+)$") or v1486)
		v_u_16.ButtonSelect = string.find(v1487, "touchpad") and "Touchpad" or (string.find(v1487, "share") and "Share" or (string.find(v1487, "create") and "Create" or "View"))
	end
end
v_u_12._syncSelectName = v_u_1488
function v_u_12.start() -- name: start
	-- upvalues: (copy) v_u_1119, (copy) v_u_1488, (copy) v_u_4, (copy) v_u_6, (copy) v_u_71, (copy) v_u_22, (ref) v_u_380, (ref) v_u_46, (copy) v_u_11, (ref) v_u_384, (ref) v_u_378, (ref) v_u_385, (copy) v_u_196, (copy) v_u_69, (copy) v_u_254, (copy) v_u_265, (copy) v_u_70, (copy) v_u_13, (ref) v_u_371, (ref) v_u_392, (copy) v_u_201, (copy) v_u_195, (copy) v_u_158, (copy) v_u_15, (copy) v_u_162, (copy) v_u_148, (copy) v_u_354, (copy) v_u_353, (ref) v_u_375, (copy) v_u_27, (copy) v_u_138, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (copy) v_u_99, (ref) v_u_386, (copy) v_u_5, (ref) v_u_377, (ref) v_u_376, (copy) v_u_12
	v_u_1119()
	local v1489 = v_u_1488
	pcall(v1489)
	v_u_4.GamepadConnected:Connect(function()
		-- upvalues: (ref) v_u_1488
		local v1490 = v_u_1488
		pcall(v1490)
	end)
	local function v1491()
		-- upvalues: (ref) v_u_6
		v_u_6.AutoSelectGuiEnabled = false
	end
	pcall(v1491)
	v_u_6:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		-- upvalues: (ref) v_u_71
		v_u_71.selChangedAt = os.clock()
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_22, (ref) v_u_380
		local v_u_1492 = v_u_22:FindFirstChildOfClass("PlayerGui") or v_u_22:WaitForChild("PlayerGui", 30)
		local function v1493()
			-- upvalues: (ref) v_u_380
			return v_u_380.lib.HushUI
		end
		local v1494, v_u_1495 = pcall(v1493)
		if v_u_1492 and (v1494 and v_u_1495) then
			local v1496 = v_u_1495.selectionImage
			if type(v1496) == "function" then
				pcall(function()
					-- upvalues: (copy) v_u_1492, (copy) v_u_1495
					v_u_1492.SelectionImageObject = v_u_1495.selectionImage()
				end)
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_380, (ref) v_u_46
		local function v1497()
			-- upvalues: (ref) v_u_380
			return v_u_380.net.unreliable("char.state")
		end
		local v1498, v1499 = pcall(v1497)
		if v1498 then
			v_u_46 = v1499
		end
	end)
	v_u_11.activeChanged:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_384, (ref) v_u_378, (ref) v_u_385, (ref) v_u_196, (ref) v_u_71, (ref) v_u_69, (ref) v_u_254
		if not v_u_11.active then
			local v1500 = Vector2.zero
			local v1501 = Vector2.zero
			v_u_384 = v1500
			v_u_378 = v1501
			v_u_385 = false
			table.clear(v_u_196)
			v_u_71.resetStick()
			local v1502 = v_u_69
			v_u_69.eventDevice = nil
			v1502.simPreferred = nil
		end
		v_u_254()
	end)
	v_u_11.InputBegan:Connect(function(p1503, p1504)
		-- upvalues: (ref) v_u_265, (ref) v_u_69, (ref) v_u_254, (ref) v_u_70, (ref) v_u_13, (ref) v_u_371, (ref) v_u_380, (ref) v_u_392, (ref) v_u_385, (ref) v_u_71, (ref) v_u_201, (ref) v_u_196, (ref) v_u_4, (ref) v_u_195, (ref) v_u_158, (ref) v_u_15, (ref) v_u_162, (ref) v_u_148
		local v1505 = v_u_265(p1503, false)
		if v1505 and v1505 ~= v_u_69.eventDevice then
			v_u_69.eventDevice = v1505
			v_u_254()
		end
		if v_u_70.capture and v_u_70.captureIo(p1503) then
			return
		elseif p1503.UserInputType == Enum.UserInputType.Touch then
			v_u_254()
		else
			local v1506 = p1503.UserInputType
			local v1507
			if v1506 == Enum.UserInputType.Gamepad1 then
				v1507 = true
			else
				local v1508 = v1506.Name
				v1507 = string.sub(v1508, 1, 7) == "Gamepad"
			end
			if v1507 then
				if p1503.KeyCode == v_u_13.Thumbstick1 or p1503.KeyCode == v_u_13.Thumbstick2 then
					return
				end
				if v_u_371 and (v_u_380 and (v_u_380.shared and (v_u_380.shared.StuckRules and v_u_380.shared.StuckRules.padSwallow(true, v_u_392, p1503.KeyCode.Name)))) then
					if p1503.KeyCode == v_u_13.ButtonL1 then
						v_u_385 = true
					end
					return
				end
				if p1503.KeyCode == v_u_13.ButtonL1 then
					v_u_385 = true
				end
				if v_u_71.dpadBegan(p1503, v_u_69.wasInCharge) then
					return
				end
				if p1503.KeyCode == v_u_13.ButtonA then
					v_u_71.probeA(p1503)
				end
				if p1504 and (p1503.KeyCode == v_u_13.ButtonA or (p1503.KeyCode == v_u_13.DPadUp or (p1503.KeyCode == v_u_13.DPadDown or (p1503.KeyCode == v_u_13.DPadLeft or p1503.KeyCode == v_u_13.DPadRight)))) then
					return
				end
				if #v_u_201(p1503.KeyCode) > 0 then
					local v1509
					if type(p1503) == "table" then
						v1509 = p1503.virtual == true
					else
						v1509 = false
					end
					v_u_196[p1503.KeyCode] = {
						["t"] = nil,
						["fired"] = false,
						["ut"] = nil,
						["virtual"] = nil,
						["t"] = os.clock(),
						["ut"] = p1503.UserInputType,
						["virtual"] = v1509
					}
					return
				end
			end
			if p1504 then
				local v1510 = p1503.UserInputType
				local v1511
				if v1510 == Enum.UserInputType.Gamepad1 then
					v1511 = true
				else
					local v1512 = v1510.Name
					v1511 = string.sub(v1512, 1, 7) == "Gamepad"
				end
				if not v1511 then
					if v_u_4:GetFocusedTextBox() or p1503.UserInputType == Enum.UserInputType.MouseButton1 then
						return
					end
					if p1503.UserInputType == Enum.UserInputType.Keyboard and v_u_4:GetFocusedTextBox() then
						return
					end
				end
			end
			for _, v1513 in v_u_195((v_u_158(p1503))) do
				local v1514 = p1503.UserInputType
				local v1515
				if v1514 == Enum.UserInputType.Gamepad1 then
					v1515 = true
				else
					local v1516 = v1514.Name
					v1515 = string.sub(v1516, 1, 7) == "Gamepad"
				end
				if v1515 and (v_u_15[v1513] and v_u_15[v1513].padWhen == "padMod") then
					v_u_162()
				end
				v_u_148(v1513, true)
			end
		end
	end)
	v_u_4.InputBegan:Connect(function(p1517)
		-- upvalues: (ref) v_u_354, (ref) v_u_4, (ref) v_u_70, (ref) v_u_353
		if p1517.UserInputType == Enum.UserInputType.Keyboard and (v_u_354[p1517.KeyCode] and (not v_u_4:GetFocusedTextBox() and (not v_u_70.capture and p1517 ~= v_u_70.lastIo))) then
			v_u_353[p1517.KeyCode] = true
		end
	end)
	v_u_4.InputBegan:Connect(function(p1518, p1519)
		-- upvalues: (ref) v_u_22, (ref) v_u_4, (ref) v_u_70, (ref) v_u_380
		if p1519 or (p1518.UserInputType ~= Enum.UserInputType.Keyboard or p1518.KeyCode ~= Enum.KeyCode.F2) then
			return
		elseif v_u_22:GetAttribute("OverwatchReviewer") == true and not (v_u_4:GetFocusedTextBox() or v_u_70.capture) then
			local function v1520()
				-- upvalues: (ref) v_u_380
				v_u_380.lib.ReviewDesk.toggle(v_u_380)
			end
			pcall(v1520)
		end
	end)
	v_u_4.WindowFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_353, (ref) v_u_375, (ref) v_u_392, (ref) v_u_27, (ref) v_u_15, (ref) v_u_138, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (ref) v_u_99
		table.clear(v_u_353)
		if v_u_375 and v_u_392 == "Keyboard" then
			v_u_375 = false
		end
		if v_u_392 == "Keyboard" then
			for v1521 in table.clone(v_u_27) do
				local v1522 = v_u_15[v1521]
				if not v1522 or v1522.ui then
					continue
				end
				if v_u_138.eaten[v1521] then
					v_u_138.eaten[v1521] = nil
				else
					local v1523 = v_u_392
					if v1521 == "sprint" then
						if v1523 == "Keyboard" or v1523 == "Touch" then
							v_u_375 = false
						end
						if v_u_375 then
							v_u_369 = false
						end
						if v_u_390 then
							v_u_390:setToggle("sprint", v_u_375)
							v_u_390:setToggle("sneak", v_u_369)
							v_u_390:setToggle("aim", v_u_382)
						end
					elseif v1521 ~= "sneak" then
						if v1521 == "aim" then
							v_u_382 = false
						elseif v1521 == "fire" then
							v_u_372 = false
						end
					end
					v_u_99(v1521, false, nil)
				end
			end
			v_u_382 = false
			v_u_372 = false
		end
	end)
	v_u_11.InputEnded:Connect(function(p1524)
		-- upvalues: (ref) v_u_353, (ref) v_u_13, (ref) v_u_385, (ref) v_u_386, (ref) v_u_15, (ref) v_u_27, (ref) v_u_138, (ref) v_u_392, (ref) v_u_375, (ref) v_u_369, (ref) v_u_390, (ref) v_u_382, (ref) v_u_372, (ref) v_u_99, (ref) v_u_158
		if p1524.UserInputType ~= Enum.UserInputType.Touch then
			if p1524.UserInputType == Enum.UserInputType.Keyboard then
				v_u_353[p1524.KeyCode] = nil
			end
			local v1525 = p1524.UserInputType
			local v1526
			if v1525 == Enum.UserInputType.Gamepad1 then
				v1526 = true
			else
				local v1527 = v1525.Name
				v1526 = string.sub(v1527, 1, 7) == "Gamepad"
			end
			if v1526 then
				if p1524.KeyCode == v_u_13.ButtonL1 then
					v_u_385 = false
				end
				if v_u_386(p1524) then
					return
				end
				for v1528, v1529 in v_u_15 do
					if not (v1529.padWhen and (v_u_27[v1528] and table.find(v1529.pad, p1524.KeyCode))) then
						continue
					end
					if v_u_138.eaten[v1528] then
						v_u_138.eaten[v1528] = nil
					else
						local v1530 = v_u_392
						if v1528 == "sprint" then
							if v1530 == "Keyboard" or v1530 == "Touch" then
								v_u_375 = false
							end
							if v_u_375 then
								v_u_369 = false
							end
							if v_u_390 then
								v_u_390:setToggle("sprint", v_u_375)
								v_u_390:setToggle("sneak", v_u_369)
								v_u_390:setToggle("aim", v_u_382)
							end
						elseif v1528 ~= "sneak" then
							if v1528 == "aim" then
								v_u_382 = false
							elseif v1528 == "fire" then
								v_u_372 = false
							end
						end
						v_u_99(v1528, false, nil)
					end
				end
			end
			for _, v1531 in v_u_158(p1524) do
				if not v_u_27[v1531] and (v1531 ~= "sprint" and (v1531 ~= "aim" and v1531 ~= "fire")) then
					continue
				end
				if v_u_138.eaten[v1531] then
					v_u_138.eaten[v1531] = nil
				else
					local v1532 = v_u_392
					if v1531 == "sprint" then
						if v1532 == "Keyboard" or v1532 == "Touch" then
							v_u_375 = false
						end
						if v_u_375 then
							v_u_369 = false
						end
						if v_u_390 then
							v_u_390:setToggle("sprint", v_u_375)
							v_u_390:setToggle("sneak", v_u_369)
							v_u_390:setToggle("aim", v_u_382)
						end
					elseif v1531 ~= "sneak" then
						if v1531 == "aim" then
							v_u_382 = false
						elseif v1531 == "fire" then
							v_u_372 = false
						end
					end
					v_u_99(v1531, false, nil)
				end
			end
		end
	end)
	v_u_11.InputChanged:Connect(function(p1533)
		-- upvalues: (ref) v_u_265, (ref) v_u_69, (ref) v_u_254, (ref) v_u_13, (ref) v_u_71, (ref) v_u_384, (ref) v_u_378
		local v1534 = v_u_265(p1533, true)
		if v1534 and v1534 ~= v_u_69.eventDevice then
			v_u_69.eventDevice = v1534
			v_u_254()
		end
		local v1535 = p1533.UserInputType
		local v1536
		if v1535 == Enum.UserInputType.Gamepad1 then
			v1536 = true
		else
			local v1537 = v1535.Name
			v1536 = string.sub(v1537, 1, 7) == "Gamepad"
		end
		if v1536 then
			if p1533.KeyCode == v_u_13.Thumbstick1 then
				if type(p1533) ~= "table" or not p1533.virtual then
					v_u_71.stickIo = p1533
				end
				v_u_71.track("evt", Vector2.new(p1533.Position.X, p1533.Position.Y))
				v_u_384 = v_u_71.fresh()
				return
			end
			if p1533.KeyCode == v_u_13.Thumbstick2 then
				v_u_378 = Vector2.new(p1533.Position.X, p1533.Position.Y)
			end
		end
	end)
	v_u_4.LastInputTypeChanged:Connect(v_u_254)
	local function v1538()
		-- upvalues: (ref) v_u_4, (ref) v_u_254
		v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(v_u_254)
	end
	pcall(v1538)
	v_u_4.GamepadDisconnected:Connect(function()
		-- upvalues: (ref) v_u_196, (ref) v_u_384, (ref) v_u_378, (ref) v_u_71, (ref) v_u_69, (ref) v_u_254
		table.clear(v_u_196)
		v_u_384 = Vector2.zero
		v_u_378 = Vector2.zero
		v_u_71.resetStick()
		if v_u_69.eventDevice == "Gamepad" then
			v_u_69.eventDevice = nil
		end
		v_u_254()
	end)
	local v_u_1539 = setmetatable({}, {
		["__mode"] = "k"
	})
	local function v_u_1543(p1540) -- name: applyReviveHold
		-- upvalues: (ref) v_u_22, (copy) v_u_1539
		if p1540:GetAttribute("Kind") == "Revive" and p1540:GetAttribute("OwnerUserId") ~= v_u_22.UserId then
			v_u_1539[p1540] = true
			local v1541 = v_u_22:GetAttribute("ReviveHoldTime")
			if type(v1541) == "number" and (v1541 == v1541 and (v1541 >= 0.5 and v1541 <= 15)) then
				local v1542 = p1540.HoldDuration - v1541
				if math.abs(v1542) > 0.01 then
					p1540.HoldDuration = v1541
				end
			end
		end
	end
	v_u_5.PromptShown:Connect(function(p1544)
		-- upvalues: (copy) v_u_1543
		local v1545 = v_u_1543
		pcall(v1545, p1544)
	end)
	v_u_22:GetAttributeChangedSignal("ReviveHoldTime"):Connect(function()
		-- upvalues: (copy) v_u_1539, (copy) v_u_1543
		for v1546 in v_u_1539 do
			if not v1546.Parent then
				continue
			end
			local v1547 = v_u_1543
			pcall(v1547, v1546)
		end
	end)
	v_u_380.session.onPlaceChanged(function(p1548)
		-- upvalues: (ref) v_u_377, (ref) v_u_376, (ref) v_u_22, (ref) v_u_69, (ref) v_u_380, (ref) v_u_70, (ref) v_u_375, (ref) v_u_369, (ref) v_u_382, (ref) v_u_372, (ref) v_u_390, (ref) v_u_254
		v_u_377 = p1548 == "Raid" and true or p1548 == "Hideout"
		v_u_376 = p1548
		if v_u_377 and (v_u_22:GetAttribute("AimAssist") == nil and not v_u_69.settingsFetched) then
			v_u_69.settingsFetched = true
			task.spawn(function()
				-- upvalues: (ref) v_u_380, (ref) v_u_22
				local v1549 = v_u_380.net.invoke
				local v1550, v1551 = pcall(v1549, "menu.get", {
					["what"] = "settings"
				})
				if v1550 and type(v1551) == "table" then
					local v1552 = v1551.aimAssist
					if type(v1552) == "boolean" and v_u_22:GetAttribute("AimAssist") == nil then
						v_u_22:SetAttribute("AimAssist", v1551.aimAssist)
					end
				end
			end)
		end
		if v_u_377 then
			v_u_70.fetch()
		end
		if not v_u_377 then
			v_u_375 = false
			v_u_369 = false
			v_u_382 = false
			v_u_372 = false
			if v_u_390 then
				v_u_390:setToggle("sprint", v_u_375)
				v_u_390:setToggle("sneak", v_u_369)
				v_u_390:setToggle("aim", v_u_382)
			end
		end
		v_u_254()
	end)
	v_u_254()
	local function v1553()
		-- upvalues: (ref) v_u_380, (ref) v_u_12
		v_u_380.lib.MoveWatch.start(v_u_380, v_u_12)
	end
	pcall(v1553)
	local function v1554()
		-- upvalues: (ref) v_u_380, (ref) v_u_12
		v_u_380.lib.StuckHelp.start(v_u_380, v_u_12)
	end
	pcall(v1554)
end
return v_u_12