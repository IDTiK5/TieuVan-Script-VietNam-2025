-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / QueueOptionsStore

local v_u_39 = {
	["PENDING_SECS"] = 4,
	["queueSig"] = function(p1) -- name: queueSig
		if type(p1) ~= "table" then
			return "nil"
		end
		local v2 = table.concat
		local v3 = {}
		local v4 = p1.optIn
		local v5 = tostring(v4)
		local v6 = p1.regionsOn
		local v7 = tostring(v6)
		local v8 = p1.freeOptIn
		local v9 = tostring(v8)
		local v10 = p1.regions
		local v11 = type(v10) ~= "table" and "" or table.concat(v10, ",")
		local v12 = p1.own
		local v13 = tostring(v12)
		local v14 = p1.agree
		local v15 = tostring(v14)
		local v16 = p1.of
		local v17 = tostring(v16)
		local v18 = p1.max
		__set_list(v3, 1, {v5, v7, v9, v11, v13, v15, v17, (tostring(v18))})
		return v2(v3, "|")
	end,
	["inputSig"] = function(p19) -- name: inputSig
		if type(p19) ~= "table" then
			return "nil"
		end
		local v20 = table.concat
		local v21 = {}
		local v22 = p19.pool
		local v23 = tostring(v22)
		local v24 = p19.reason
		local v25 = tostring(v24)
		local v26 = p19.line
		local v27 = tostring(v26)
		local v28 = p19.warn
		local v29 = tostring(v28)
		local v30 = p19.own
		local v31 = tostring(v30)
		local v32 = p19.allowKb
		local v33 = tostring(v32)
		local v34 = p19.kbDirect
		local v35 = tostring(v34)
		local v36 = p19.agree
		local v37 = tostring(v36)
		local v38 = p19.of
		__set_list(v21, 1, {v23, v25, v27, v29, v31, v33, v35, v37, (tostring(v38))})
		return v20(v21, "|")
	end
}
local function v_u_47(p40, p41) -- name: laid
	if type(p40) ~= "table" or p41 == nil then
		return p40
	end
	local v42 = {}
	for v43, v44 in p40 do
		v42[v43] = v44
	end
	for v45, v46 in p41.fields do
		v42[v45] = v46
	end
	return v42
end
function v_u_39.new() -- name: new
	-- upvalues: (copy) v_u_39, (copy) v_u_47
	local v48 = {}
	local v_u_49 = false
	local v_u_50 = {}
	local v_u_51 = {
		["queue"] = {
			["sigOf"] = nil,
			["server"] = nil,
			["patch"] = nil,
			["shown"] = nil,
			["sigOf"] = v_u_39.queueSig
		},
		["input"] = {
			["sigOf"] = nil,
			["server"] = nil,
			["patch"] = nil,
			["shown"] = nil,
			["sigOf"] = v_u_39.inputSig
		}
	}
	local function v_u_58(p52, p53) -- name: emit
		-- upvalues: (copy) v_u_50
		for _, v54 in table.clone(v_u_50) do
			if not v54.alive then
				continue
			end
			local v55 = v54.fn
			local v56, v57 = pcall(v55, p52, p53)
			if v56 then
				continue
			end
			warn("[QueueOptionsStore] view failed:", v57)
		end
	end
	local function v_u_66(p59, p60, p61) -- name: setLane
		-- upvalues: (copy) v_u_51, (ref) v_u_39, (ref) v_u_47, (copy) v_u_58
		local v62 = v_u_51[p59]
		if type(p60) ~= "table" then
			p60 = nil
		end
		if v62.patch ~= nil then
			local v63
			if type(p61) == "number" then
				local v64 = v62.patch.at
				if type(v64) == "number" then
					v63 = p61 - v62.patch.at >= v_u_39.PENDING_SECS
				else
					v63 = false
				end
			else
				v63 = false
			end
			if p60 == nil or (v63 or v62.sigOf(p60) ~= v62.patch.base) then
				v62.patch = nil
			end
		end
		v62.server = p60
		local v65 = v62.sigOf(v62.shown)
		v62.shown = v_u_47(p60, v62.patch)
		if v62.sigOf(v62.shown) ~= v65 then
			v_u_58(p59, nil)
		end
	end
	local function v_u_75(p67, p68, p69, p70) -- name: patchLane
		-- upvalues: (copy) v_u_51, (ref) v_u_47, (copy) v_u_58
		local v71 = v_u_51[p67]
		if v71.server == nil or type(p68) ~= "table" then
			return false
		end
		if v71.patch == nil then
			v71.patch = {
				["fields"] = {},
				["base"] = v71.sigOf(v71.server),
				["at"] = p69
			}
		end
		for v72, v73 in p68 do
			v71.patch.fields[v72] = v73
		end
		if type(p69) == "number" then
			v71.patch.at = p69
		end
		local v74 = v71.sigOf(v71.shown)
		v71.shown = v_u_47(v71.server, v71.patch)
		if v71.sigOf(v71.shown) ~= v74 then
			v_u_58(p67, p70)
		end
		return true
	end
	function v48.queue() -- name: queue
		-- upvalues: (copy) v_u_51
		return v_u_51.queue.shown
	end
	function v48.input() -- name: input
		-- upvalues: (copy) v_u_51
		return v_u_51.input.shown
	end
	function v48.locked() -- name: locked
		-- upvalues: (ref) v_u_49
		return v_u_49
	end
	function v48.setQueue(p76, p77) -- name: setQueue
		-- upvalues: (copy) v_u_66
		v_u_66("queue", p76, p77)
	end
	function v48.setInput(p78, p79) -- name: setInput
		-- upvalues: (copy) v_u_66
		v_u_66("input", p78, p79)
	end
	function v48.patchQueue(p80, p81, p82) -- name: patchQueue
		-- upvalues: (copy) v_u_75
		return v_u_75("queue", p80, p81, p82)
	end
	function v48.patchInput(p83, p84, p85) -- name: patchInput
		-- upvalues: (copy) v_u_75
		return v_u_75("input", p83, p84, p85)
	end
	function v48.setLocked(p86) -- name: setLocked
		-- upvalues: (ref) v_u_49, (copy) v_u_58
		local v87 = p86 == true
		if v_u_49 ~= v87 then
			v_u_49 = v87
			v_u_58("lock", nil)
		end
	end
	function v48.subscribe(p88) -- name: subscribe
		-- upvalues: (copy) v_u_50
		local v_u_89 = {
			["fn"] = nil,
			["alive"] = true,
			["fn"] = p88
		}
		local v90 = v_u_50
		table.insert(v90, v_u_89)
		return function()
			-- upvalues: (copy) v_u_89, (ref) v_u_50
			if v_u_89.alive then
				v_u_89.alive = false
				local v91 = table.find(v_u_50, v_u_89)
				if v91 then
					table.remove(v_u_50, v91)
				end
			end
		end
	end
	function v48.count() -- name: count
		-- upvalues: (copy) v_u_50
		return #v_u_50
	end
	function v48.pending() -- name: pending
		-- upvalues: (copy) v_u_51
		return v_u_51.queue.patch ~= nil, v_u_51.input.patch ~= nil
	end
	return v48
end
return v_u_39