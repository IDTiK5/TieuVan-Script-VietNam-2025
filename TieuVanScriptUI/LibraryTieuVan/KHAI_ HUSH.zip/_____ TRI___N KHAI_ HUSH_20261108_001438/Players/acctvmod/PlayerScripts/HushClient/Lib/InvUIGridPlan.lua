-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIGridPlan

local v_u_75 = {
	["SECTION_GAP"] = 10,
	["SECTION_PAD"] = 6,
	["GEAR_BOTTOM"] = 20,
	["PH_FLAT"] = 40,
	["decide"] = function(p1) -- name: decide
		-- upvalues: (copy) v_u_75
		local v2 = p1.dw
		local v3 = p1.dh
		local v4 = p1.touch == true
		local v5 = p1.mode == "raid"
		local v6 = p1.scale or 1
		local v7 = p1.zoom
		local v8 = (type(v7) ~= "number" or p1.zoom <= 0) and 1 or p1.zoom
		local v9 = p1.rightChrome or 34
		local v10 = p1.t36 or 36
		local v11 = p1.t40 or 40
		local v12 = v2 < 1300 and true or v3 < 640
		local v13 = v12 and v4
		local v14
		if p1.standalone then
			if v4 then
				v14 = v11 + 16
			else
				v14 = v12 and 48 or 64
			end
		else
			v14 = 0
		end
		local v15 = v12 and 8 or 16
		local v16 = v12 and 8 or 16
		local v17 = v13 and 208 or (v12 and 236 or 300)
		local v18 = 6
		local v19 = v5 and 7 or 10
		local v20 = not v4 and 36 or v10
		if p1.minCellFn then
			v20 = p1.minCellFn(v20, v6, v4)
		end
		local v21 = math.max(v5 and (v12 and 52 or 58) or 62, v20)
		local v22, v23, v24
		if v8 == 1 or not p1.limits then
			v22 = v21
			v23 = v20
			v24 = 28
		else
			v23, v22 = p1.limits(v20, v21, v8, v6, v4)
			v24 = p1.limits(28, 28, v8, v6, false)
		end
		local v25 = (v2 - v15 * 2 - v17 - v16 * 2 - 92) / (v18 + v19)
		local v26 = math.clamp(v25, v23, v22)
		local v27 = math.floor(v26)
		local v28 = v25 < v23
		local v29 = p1.rk or ""
		local v30 = v4 and v28
		local v31 = false
		local v32 = v11 + 6
		local v33
		if v4 and (v28 and v29 ~= "") then
			local v34 = p1.rightNeed or 10
			v18 = p1.gearNeed or 6
			local v35 = (v2 - v15 * 2 - v17 - v16 * 2 - 92) / (v18 + v34)
			if v23 <= v35 then
				local v36 = math.clamp(v35, v23, v22)
				v27 = math.floor(v36)
			else
				local v37 = (v2 - v15 * 2 - v32 - v16 * 2 - 92) / (v18 + v34)
				local v38 = math.clamp(v37, v23, v22)
				v27 = math.floor(v38)
				v31 = true
			end
			v28 = false
			v33 = true
		else
			v33 = false
		end
		local v39
		if v4 then
			if v5 then
				v39 = not v28
				if v39 then
					v39 = not v31
				end
			else
				v39 = v5
			end
		else
			v39 = v4
		end
		if v39 and p1.eqFold == true then
			local v40 = v33 and (p1.rightNeed or 10) or v19
			local v41 = (v2 - v15 * 2 - v32 - v16 * 2 - 92) / (v18 + v40)
			local v42 = math.clamp(v41, v23, v22)
			v27 = math.floor(v42)
			v31 = true
		end
		if v28 then
			local v43 = v2 * 0.3
			local v44 = math.floor(v43)
			v17 = math.clamp(v44, 170, 236)
			local v45 = (v2 - v15 * 2 - v17 - v16 - 50) / math.max(v18, v19)
			if v4 then
				v24 = v23
			end
			local v46 = math.min(v24, v22)
			local v47 = math.clamp(v45, v46, v22)
			v27 = math.floor(v47)
		end
		local v48 = 0
		local v49
		if v28 or (v33 or v5) then
			v49 = nil
		else
			local v50 = v19 * v27 + v9
			local v51 = v2 - v15 * 2 - v17 - v16 * 2 - (v18 * v27 + 42) - v50
			if v51 > 0 then
				v48 = math.min(v51, 96)
				local v52 = v51 - v48
				local v53 = math.min(v52, 48)
				v17 = v17 + v53
				v51 = v52 - v53
			end
			v49 = v50 + math.max(0, v51)
		end
		local v54
		if v31 then
			v54 = v32
		else
			v54 = v17
		end
		local v55
		if v28 then
			v55 = v2 - v15 * 2 - v54 - v16
		else
			v55 = v18 * v27 + 34 + 8 + v48
		end
		local v56, v57
		if v28 then
			v56 = nil
			v57 = nil
		else
			v57 = v54 + v16 + v55 + v16
			if v49 then
				v56 = v49
			elseif v33 then
				v56 = v2 - v15 * 2 - v57
			else
				local v58 = v2 - v15 * 2 - v57
				local v59 = v19 * v27 + 42
				v56 = math.max(v58, v59)
			end
		end
		local v60 = v14 + v15
		local v61 = v3 - v60 - v15
		local v62
		if v12 then
			v62 = v4 or v3 < 560
		else
			v62 = v12
		end
		local v63 = p1.widestOpen or 0
		if not v5 then
			v63 = math.max(v63, v19)
		end
		local v64
		if v28 then
			local v65 = math.max(v18, v19)
			if v29 ~= "" then
				v65 = math.max(v65, v63)
			end
			v64 = v65 * v27 > v2 - v15 * 2 - v17 - v16 - 50 + 0.01
		else
			v64 = v63 * v27 > v56 - v9 + 0.01 and true or v57 + v56 > v2 - v15 * 2 + 0.01
		end
		local v66 = (p1.t24 or 24) + 8
		local v67 = math.max(30, v66)
		local v68 = not v28
		if v68 then
			v68 = v61 >= 640
		end
		local v69 = 0
		local v70 = 0
		for _, v71 in p1.ownGrids or {} do
			v69 = v69 + 1
			if v71.ph then
				local v72
				if v68 then
					v72 = (v71.ph == "bag" and 4 or 2) * v27
				else
					v72 = v_u_75.PH_FLAT
				end
				v70 = v70 + v72
			else
				v70 = v70 + (v67 + v_u_75.SECTION_PAD + v71.h * v27)
			end
		end
		if v69 > 1 then
			v70 = v70 + (v69 - 1) * v_u_75.SECTION_GAP
		end
		local v73 = p1.headTop or 0
		local v74 = v61 - math.max(v62 and 38 or 56, v73) - v_u_75.GEAR_BOTTOM
		return {
			["compact"] = v12,
			["touch"] = v4,
			["phone"] = v13,
			["headerH"] = v14,
			["pad"] = v15,
			["gap"] = v16,
			["eqW"] = v17,
			["eqSlotW"] = v54,
			["gearCells"] = v18,
			["rightCells"] = v19,
			["minCell"] = v20,
			["maxCell"] = v21,
			["minZ"] = v23,
			["maxZ"] = v22,
			["cellAvail"] = v25,
			["cell"] = v27,
			["narrow"] = v28,
			["splitCandidate"] = v30,
			["split"] = v33,
			["rail"] = v31,
			["railW"] = v32,
			["foldable"] = v39,
			["gearExtra"] = v48,
			["rwFit"] = v49,
			["gearW"] = v55,
			["rx"] = v57,
			["rw"] = v56,
			["top"] = v60,
			["colH"] = v61,
			["tight"] = v62,
			["overflowX"] = v64,
			["overflowGear"] = v74 + 0.01 < v70,
			["gearStackH"] = v70,
			["gearAvailH"] = v74
		}
	end
}
return v_u_75