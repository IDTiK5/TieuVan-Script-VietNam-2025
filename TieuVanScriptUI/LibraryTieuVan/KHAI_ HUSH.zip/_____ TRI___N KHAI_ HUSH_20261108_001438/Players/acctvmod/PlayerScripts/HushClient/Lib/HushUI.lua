-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HushUI

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_7 = require(v_u_6:WaitForChild("Theme"))
local v8 = require(v_u_6:WaitForChild("Signal"))
local v_u_9 = require(v_u_6:WaitForChild("CloseButtonRule"))
local v_u_10 = v_u_7.color
local v_u_11 = v_u_7.motion
local v_u_12 = {
	["Theme"] = v_u_7
}
local v_u_13 = v_u_1.LocalPlayer
local v_u_14 = nil
function v_u_12.bind(p15) -- name: bind
	-- upvalues: (ref) v_u_14
	if p15 then
		v_u_14 = p15
	end
end
function v_u_12.new(p16, p17, p18) -- name: new
	local v19 = Instance.new(p16)
	if p17 then
		for v20, v21 in p17 do
			v19[v20] = v21
		end
	end
	if p18 then
		v19.Parent = p18
	end
	return v19
end
function v_u_12.tween(p22, p23, p24, p25, p26) -- name: tween
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	local v27 = v_u_3:Create(p22, v_u_7.tweenInfo(p24, p25, p26), p23)
	v27:Play()
	return v27
end
local v_u_28 = { "BackgroundTransparency", "TextTransparency", "TextStrokeTransparency" }
local v_u_29 = { "BackgroundTransparency", "ImageTransparency" }
local v_u_30 = { "BackgroundTransparency", "ScrollBarImageTransparency" }
local v_u_31 = { "BackgroundTransparency", "GroupTransparency" }
local v_u_32 = { "BackgroundTransparency" }
local v_u_33 = { "Transparency" }
local v_u_34 = {}
local v_u_35 = {}
local function v_u_40(p36) -- name: fadeProps
	-- upvalues: (copy) v_u_35, (copy) v_u_28, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31, (copy) v_u_32, (copy) v_u_33, (copy) v_u_34
	local v37 = p36.ClassName
	local v38 = v_u_35[v37]
	if v38 then
		return v38
	end
	local v39
	if p36:IsA("TextLabel") or (p36:IsA("TextButton") or p36:IsA("TextBox")) then
		v39 = v_u_28
	elseif p36:IsA("ImageLabel") or (p36:IsA("ImageButton") or p36:IsA("ViewportFrame")) then
		v39 = v_u_29
	elseif p36:IsA("ScrollingFrame") then
		v39 = v_u_30
	elseif p36:IsA("CanvasGroup") then
		v39 = v_u_31
	elseif p36:IsA("GuiObject") then
		v39 = v_u_32
	elseif p36:IsA("UIStroke") then
		v39 = v_u_33
	else
		v39 = v_u_34
	end
	v_u_35[v37] = v39
	return v39
end
local v_u_41 = {}
local v_u_42 = {}
local v_u_43 = nil
local function v_u_58(p44, p45) -- name: fadeOne
	-- upvalues: (copy) v_u_40, (copy) v_u_42
	local v46 = v_u_40(p44)
	if #v46 == 0 then
		return
	end
	local v47 = v_u_42[p44]
	if p45 <= 0 then
		if v47 then
			for v48, v49 in v47 do
				local v50 = p44[v48]
				local v51 = v50 - v49.a
				if math.abs(v51) > 0.002 or v50 == v49.b then
					continue
				end
				p44[v48] = v49.b
			end
			v_u_42[p44] = nil
		end
		return
	end
	if not v47 then
		v47 = {}
		v_u_42[p44] = v47
	end
	for _, v52 in v46 do
		local v53 = p44[v52]
		local v54 = v47[v52]
		local v55, v56
		if v54 then
			local v57 = v53 - v54.a
			if math.abs(v57) > 0.002 then
				v54 = {
					["b"] = v53,
					["a"] = v53
				}
				v47[v52] = v54
				v55 = v54.b + (1 - v54.b) * p45
				v56 = v55 - v53
				if math.abs(v56) > 0.0001 then
					p44[v52] = v55
				end
				v54.a = v55
			else
				v55 = v54.b + (1 - v54.b) * p45
				v56 = v55 - v53
				if math.abs(v56) > 0.0001 then
					p44[v52] = v55
				end
				v54.a = v55
			end
		else
			v54 = {
				["b"] = v53,
				["a"] = v53
			}
			v47[v52] = v54
			v55 = v54.b + (1 - v54.b) * p45
			v56 = v55 - v53
			if math.abs(v56) > 0.0001 then
				p44[v52] = v55
			end
			v54.a = v55
		end
	end
end
v_u_12.noFade = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_63(p59, p60) -- name: fadeWalk
	-- upvalues: (copy) v_u_12, (copy) v_u_41, (copy) v_u_58, (copy) v_u_63
	if not v_u_12.noFade[p59] then
		local v61 = v_u_41[p59]
		if v61 then
			p60 = p60 * (1 - v61.alpha)
		end
		v_u_58(p59, 1 - p60)
		for _, v62 in p59:GetChildren() do
			v_u_63(v62, p60)
		end
	end
end
local function v_u_71() -- name: fadeRestoreLeftovers
	-- upvalues: (copy) v_u_42
	for v_u_64, v65 in v_u_42 do
		for v_u_66, v_u_67 in v65 do
			local v68, v69 = pcall(function()
				-- upvalues: (copy) v_u_64, (copy) v_u_66
				return v_u_64[v_u_66]
			end)
			if not v68 or type(v69) ~= "number" then
				continue
			end
			local v70 = v69 - v_u_67.a
			if math.abs(v70) > 0.002 or v69 == v_u_67.b then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_64, (copy) v_u_66, (copy) v_u_67
				v_u_64[v_u_66] = v_u_67.b
			end)
		end
	end
	table.clear(v_u_42)
end
local function v_u_94() -- name: fadeStep
	-- upvalues: (copy) v_u_41, (copy) v_u_3, (copy) v_u_63, (copy) v_u_71, (ref) v_u_43
	local v72 = os.clock()
	local v73 = {}
	for v74, v75 in v_u_41 do
		local v76
		if v75.dur <= 0 then
			v76 = 1
		else
			local v77 = (v72 - v75.t0) / v75.dur
			v76 = math.clamp(v77, 0, 1)
		end
		v75.alpha = v75.from + (v75.to - v75.from) * v_u_3:GetValue(v76, v75.style, v75.dir)
		if v76 < 1 then
			continue
		end
		v75.alpha = v75.to
		table.insert(v73, v74)
	end
	for v78 in v_u_41 do
		local v79 = v78.Parent
		while true do
			local v80
			if not v79 then
				v80 = false
				break
			end
			if v_u_41[v79] then
				v80 = true
				break
			end
			v79 = v79.Parent
		end
		if v80 then
			break
		end
		local v81 = v_u_63
		local v82, v83 = pcall(v81, v78, 1)
		if v82 then
			break
		end
		warn("[HushUI] fade failed:", v83)
	end
	for _, v84 in v73 do
		local v85 = v_u_41[v84]
		if not v85 then
			continue
		end
		if v85.onDone then
			local v86 = v85.onDone
			local v87, v88 = pcall(v86)
			if not v87 then
				warn("[HushUI] fade onDone failed:", v88)
			end
		end
		if v_u_41[v84] ~= v85 then
			continue
		end
		v85.alpha = 0
		local v89 = v_u_63
		local v90 = v84.Parent
		local v91 = v84
		local v92 = 1
		while v90 do
			local v93 = v_u_41[v90]
			if v93 then
				v92 = v92 * (1 - v93.alpha)
			end
			v90 = v90.Parent
		end
		pcall(v89, v84, v92)
		v_u_41[v91] = nil
	end
	if next(v_u_41) == nil then
		v_u_71()
		if v_u_43 then
			v_u_43:Disconnect()
			v_u_43 = nil
		end
	end
end
function v_u_12.fade(p95, p96, p97, p98) -- name: fade
	-- upvalues: (copy) v_u_7, (copy) v_u_41, (copy) v_u_63, (ref) v_u_43, (copy) v_u_2, (copy) v_u_94
	local v99 = p98 or {}
	local v100 = v_u_7.tweenInfo(p97, v99.style, v99.dir)
	local v101 = v_u_41[p95]
	local v102 = v99.from
	local v103
	if type(v102) == "number" then
		v103 = v99.from
	else
		v103 = not v101 and 0 or v101.alpha
	end
	v_u_41[p95] = {
		["alpha"] = v103,
		["from"] = v103,
		["to"] = p96,
		["t0"] = os.clock(),
		["dur"] = v100.Time,
		["style"] = v100.EasingStyle,
		["dir"] = v100.EasingDirection,
		["onDone"] = v99.onDone
	}
	local v104 = v_u_63
	local v105 = p95.Parent
	local v106 = 1
	while v105 do
		local v107 = v_u_41[v105]
		if v107 then
			v106 = v106 * (1 - v107.alpha)
		end
		v105 = v105.Parent
	end
	pcall(v104, p95, v106)
	if not v_u_43 then
		v_u_43 = v_u_2.Heartbeat:Connect(v_u_94)
	end
end
function v_u_12.fadeStop(p108, p109) -- name: fadeStop
	-- upvalues: (copy) v_u_41, (copy) v_u_12
	if v_u_41[p108] or (p109 or 0) > 0 then
		v_u_12.fade(p108, p109 or 0, 0, {
			["from"] = p109 or 0
		})
	end
end
function v_u_12.fadeAlpha(p110) -- name: fadeAlpha
	-- upvalues: (copy) v_u_41
	local v111 = v_u_41[p110]
	return not v111 and 0 or v111.alpha
end
local v_u_112 = {}
local v_u_113 = nil
function v_u_12.hasSound(p114) -- name: hasSound
	-- upvalues: (ref) v_u_113, (copy) v_u_6
	if v_u_113 == nil then
		local function v116()
			-- upvalues: (ref) v_u_6
			local v115 = v_u_6:FindFirstChild("Sounds")
			if v115 and v115:IsA("ModuleScript") then
				return require(v115)
			else
				return nil
			end
		end
		local v117, v118 = pcall(v116)
		if not v117 or type(v118) ~= "table" then
			v118 = false
		end
		v_u_113 = v118
	end
	local v119 = v_u_113
	if not v119 then
		return false
	end
	local v120 = v119.ui
	if type(v120) == "table" and v119.ui[p114] ~= nil then
		return true
	end
	local v121 = v119.defs
	local v122
	if type(v121) == "table" then
		v122 = v119.defs["ui_" .. p114] ~= nil
	else
		v122 = false
	end
	return v122
end
function v_u_12.sound(p123, p124) -- name: sound
	-- upvalues: (copy) v_u_12, (copy) v_u_112, (ref) v_u_14
	if p124 then
		if v_u_12.hasSound(p123) then
			p124 = p123
		end
	else
		p124 = p123
	end
	local v125 = os.clock()
	if not v_u_112[p124] or v125 - v_u_112[p124] >= 0.04 then
		v_u_112[p124] = v125
		local v126 = v_u_14
		if v126 then
			v126 = v_u_14.controllers
		end
		local v127 = v126 and v126.Audio or nil
		if v127 and v127.ui then
			local v128 = v127.ui
			pcall(v128, p124)
		end
	end
end
function v_u_12.stroke(p129, p130, p131, p132) -- name: stroke
	-- upvalues: (copy) v_u_10, (copy) v_u_7
	local v133 = {
		["Color"] = p130 or v_u_10.line,
		["Thickness"] = p131 or v_u_7.stroke,
		["Transparency"] = p132 or 0,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["LineJoinMode"] = Enum.LineJoinMode.Miter
	}
	local v_u_134 = Instance.new("UIStroke")
	if v133 then
		for v135, v136 in v133 do
			v_u_134[v135] = v136
		end
	end
	pcall(function()
		-- upvalues: (copy) v_u_134
		v_u_134.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	v_u_134.Parent = p129
	return v_u_134
end
function v_u_12.corner(p137, p138) -- name: corner
	-- upvalues: (copy) v_u_7
	local v139 = {
		["CornerRadius"] = UDim.new(0, p138 or v_u_7.radius)
	}
	local v140 = Instance.new("UICorner")
	if v139 then
		for v141, v142 in v139 do
			v140[v141] = v142
		end
	end
	if p137 then
		v140.Parent = p137
	end
	return v140
end
function v_u_12.pad(p143, p144) -- name: pad
	-- upvalues: (copy) v_u_7
	local v145, v146, v147, v148
	if type(p144) == "table" then
		v145 = p144[1] or (p144.l or 0)
		v146 = p144[2] or (p144.r or 0)
		v147 = p144[3] or (p144.t or 0)
		v148 = p144[4] or (p144.b or 0)
	else
		v145 = p144 or v_u_7.space.m
		v148 = v145
		v147 = v148
		v146 = v147
		local v149 = v148
		v148 = v146
		v149 = v147
		v147 = v148
		v149 = v146
	end
	local v150 = {
		["PaddingLeft"] = UDim.new(0, v145),
		["PaddingRight"] = UDim.new(0, v146),
		["PaddingTop"] = UDim.new(0, v147),
		["PaddingBottom"] = UDim.new(0, v148)
	}
	local v151 = Instance.new("UIPadding")
	if v150 then
		for v152, v153 in v150 do
			v151[v152] = v153
		end
	end
	if p143 then
		v151.Parent = p143
	end
	return v151
end
function v_u_12.layout(p154, p155, p156, p157) -- name: layout
	-- upvalues: (copy) v_u_7
	local v158 = p155 == "h"
	local v159 = {}
	local v160
	if v158 then
		v160 = Enum.FillDirection.Horizontal
	else
		v160 = Enum.FillDirection.Vertical
	end
	v159.FillDirection = v160
	v159.Padding = UDim.new(0, p156 or v_u_7.space.s)
	v159.SortOrder = Enum.SortOrder.LayoutOrder
	local v161 = Instance.new("UIListLayout")
	if v159 then
		for v162, v163 in v159 do
			v161[v162] = v163
		end
	end
	if v158 then
		v161.VerticalAlignment = Enum.VerticalAlignment.Center
		if p157 == "center" then
			v161.HorizontalAlignment = Enum.HorizontalAlignment.Center
		elseif p157 == "right" then
			v161.HorizontalAlignment = Enum.HorizontalAlignment.Right
		end
	elseif p157 == "center" then
		v161.HorizontalAlignment = Enum.HorizontalAlignment.Center
	elseif p157 == "right" then
		v161.HorizontalAlignment = Enum.HorizontalAlignment.Right
	end
	v161.Parent = p154
	return v161
end
local function v_u_167(p164, p165) -- name: applyCommon
	if p165.name then
		p164.Name = p165.name
	end
	local v166 = p165.size
	if typeof(v166) == "UDim2" then
		p164.Size = p165.size
	end
	if p165.position then
		p164.Position = p165.position
	end
	if p165.anchor then
		p164.AnchorPoint = p165.anchor
	end
	if p165.zindex then
		p164.ZIndex = p165.zindex
	end
	if p165.order then
		p164.LayoutOrder = p165.order
	end
	if p165.visible ~= nil then
		p164.Visible = p165.visible
	end
end
local v_u_168 = {
	["Keyboard"] = {
		["fire"] = "LMB",
		["aim"] = "RMB",
		["reload"] = "R",
		["interact"] = "F",
		["sprint"] = "Shift",
		["sneak"] = "Ctrl",
		["inventory"] = "Tab",
		["swap"] = "X",
		["meleeSlot"] = "3",
		["quick1"] = "4",
		["quick2"] = "5",
		["quick3"] = "6",
		["quick4"] = "7",
		["map"] = "M",
		["ping"] = "Z",
		["menu"] = "Esc",
		["rotateItem"] = "R",
		["camLeft"] = "Q",
		["camRight"] = "E",
		["zoom"] = "Wheel",
		["flashlight"] = "L",
		["throw"] = "G",
		["melee"] = "V",
		["extracts"] = "O",
		["viewToggle"] = "Y"
	},
	["Gamepad"] = {
		["fire"] = "RT",
		["aim"] = "LT",
		["reload"] = "X",
		["interact"] = "A",
		["sprint"] = "L3",
		["sneak"] = "B",
		["inventory"] = "Back",
		["swap"] = "Y",
		["meleeSlot"] = "Y",
		["quick1"] = "Up",
		["quick2"] = "Right",
		["quick3"] = "Down",
		["quick4"] = "Left",
		["map"] = "Back",
		["ping"] = "RB",
		["menu"] = "Start",
		["rotateItem"] = "Y",
		["camLeft"] = "LB",
		["camRight"] = "RB",
		["zoom"] = "R3",
		["flashlight"] = "Up",
		["throw"] = "LB",
		["melee"] = "R3",
		["extracts"] = "Select",
		["viewToggle"] = "R3"
	}
}
function v_u_12.device() -- name: device
	-- upvalues: (ref) v_u_14, (copy) v_u_4
	local v169 = v_u_14
	if v169 then
		v169 = v_u_14.controllers
	end
	local v170 = v169 and v169.Input or nil
	if v170 and v170.device then
		local v171 = v170.device
		local v172, v173 = pcall(v171)
		if v172 and type(v173) == "string" then
			return v173
		end
	end
	local v174 = v_u_4:GetLastInputType()
	return v174 == Enum.UserInputType.Touch and "Touch" or (string.find(v174.Name, "Gamepad") and "Gamepad" or (v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"))
end
function v_u_12.hint(p175) -- name: hint
	-- upvalues: (ref) v_u_14, (copy) v_u_12, (copy) v_u_168
	local v176 = v_u_14
	if v176 then
		v176 = v_u_14.controllers
	end
	local v177 = v176 and v176.Input or nil
	if v177 and v177.hint then
		local v178 = v177.hint
		local v179, v180 = pcall(v178, p175)
		if v179 and type(v180) == "string" then
			return v180
		end
	end
	local v181 = v_u_168[v_u_12.device()]
	return v181 and v181[p175] or ""
end
local v_u_182 = v8.new()
local v_u_183 = ""
local v_u_184 = false
local function v_u_190() -- name: hookDevice
	-- upvalues: (ref) v_u_184, (ref) v_u_183, (copy) v_u_12, (copy) v_u_182, (copy) v_u_4, (ref) v_u_14
	if not v_u_184 then
		v_u_184 = true
		v_u_183 = v_u_12.device()
		local function v186() -- name: check
			-- upvalues: (ref) v_u_12, (ref) v_u_183, (ref) v_u_182
			local v185 = v_u_12.device()
			if v185 ~= v_u_183 then
				v_u_183 = v185
				v_u_182:Fire(v185)
			end
		end
		v_u_4.LastInputTypeChanged:Connect(v186)
		task.spawn(function()
			-- upvalues: (ref) v_u_14, (ref) v_u_12, (ref) v_u_183, (ref) v_u_182
			for _ = 1, 40 do
				local v187 = v_u_14
				if v187 then
					v187 = v_u_14.controllers
				end
				local v188 = v187 and v187.Input or nil
				if v188 then
					v188 = v188.deviceChanged
				end
				if v188 and v188.Connect then
					v188:Connect(function()
						-- upvalues: (ref) v_u_12, (ref) v_u_183, (ref) v_u_182
						local v189 = v_u_12.device()
						if v189 ~= v_u_183 then
							v_u_183 = v189
							v_u_182:Fire(v189)
						end
						v_u_182:Fire(v_u_12.device())
					end)
					return
				end
				task.wait(0.5)
			end
		end)
	end
end
function v_u_12.onDevice(p191) -- name: onDevice
	-- upvalues: (copy) v_u_190, (copy) v_u_182
	v_u_190()
	local v_u_192 = v_u_182:Connect(p191)
	return function()
		-- upvalues: (copy) v_u_192
		v_u_192:Disconnect()
	end
end
local v_u_193 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_12._hostFor(p194, p195, p196) -- name: hostFor
	if p194 then
		return p195:WaitForChild("PlayerGui"), false
	else
		local v197
		if p195 then
			v197 = p195:FindFirstChildOfClass("PlayerGui")
		else
			v197 = nil
		end
		if v197 then
			return v197, false
		else
			return p196, true
		end
	end
end
function v_u_12.toDesign(p198) -- name: toDesign
	-- upvalues: (copy) v_u_7
	local v199 = v_u_7.uiScale()
	return Vector2.new(p198.X / v199, p198.Y / v199)
end
v_u_12.backTakenN = 0
function v_u_12.takeBack() -- name: takeBack
	-- upvalues: (copy) v_u_12
	local v200 = v_u_12
	v200.backTakenN = v200.backTakenN + 1
end
function v_u_12.backTaken() -- name: backTaken
	-- upvalues: (copy) v_u_12
	return v_u_12.backTakenN
end
v_u_12.modalClosedN = 0
function v_u_12.modalsClosed() -- name: modalsClosed
	-- upvalues: (copy) v_u_12
	return v_u_12.modalClosedN
end
function v_u_12.topInset() -- name: topInset
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v201 = v_u_5.TopbarInset.Max.Y
	local v202 = (v201 <= 0 and 58 or v201) / v_u_7.uiScale()
	return math.ceil(v202) + v_u_7.space.s
end
local v_u_203 = nil
function v_u_12.pointer() -- name: pointer
	-- upvalues: (ref) v_u_203
	if not v_u_203 then
		v_u_203 = require(script.Parent:WaitForChild("UiPointer"))
	end
	return v_u_203
end
function v_u_12.absToOverlay(p204) -- name: absToOverlay
	-- upvalues: (copy) v_u_12, (copy) v_u_7
	local v205 = v_u_12.pointer().absToScreen(p204)
	local v206 = v_u_7.uiScale()
	return Vector2.new(v205.X / v206, v205.Y / v206)
end
function v_u_12.mouseIn(p207) -- name: mouseIn
	-- upvalues: (copy) v_u_12
	return v_u_12.pointer().mouseLocal(p207)
end
function v_u_12.viewportSpace() -- name: viewportSpace
	-- upvalues: (copy) v_u_12
	local v208 = v_u_12
	local v209 = v208._vs
	if v209 == nil then
		local v210 = false
		local v211 = script.Parent:FindFirstChild("ViewportSpace")
		if v211 and v211:IsA("ModuleScript") then
			local v212 = require
			local v213
			v213, v209 = pcall(v212, v211)
			if v213 then
				if type(v209) ~= "table" then
					v209 = v210
				end
			else
				v209 = v210
			end
		else
			v209 = v210
		end
		v208._vs = v209
	end
	return v209 or nil
end
function v_u_12.worldToScreen(p214, p215) -- name: worldToScreen
	-- upvalues: (copy) v_u_7, (copy) v_u_12
	local v216 = workspace.CurrentCamera
	if not v216 then
		return Vector2.zero, false, 0
	end
	local v217, v218 = v216:WorldToViewportPoint(p214)
	local v219 = v_u_7.uiScale()
	local v220 = Vector2.new(v217.X / v219, v217.Y / v219)
	if p215 == true then
		local v221 = v_u_12.viewportSpace()
		if v221 then
			v220 = v221.applyTo(v220, v221.offset(), v219)
		end
	end
	if v218 then
		v218 = v217.Z > 0
	end
	return v220, v218, v217.Z
end
function v_u_12.edgeClamp(p222, p223, p224, p225, p226, p227, p228) -- name: edgeClamp
	local v229 = Vector2.new((p224 + p226) / 2, (p225 + p227) / 2)
	if p223 > 0 and (p224 <= p222.X and (p222.X <= p226 and (p225 <= p222.Y and p222.Y <= p227))) then
		local v230 = p222 - v229
		local v231
		if v230.Magnitude > 0.001 then
			v231 = v230.Unit
		else
			v231 = Vector2.new(0, -1)
		end
		return p222, v231, true
	end
	local v232
	if p223 > 0 then
		v232 = p222 - v229
	else
		v232 = (p228 or v229) - p222
	end
	if v232.X ~= v232.X or (v232.Y ~= v232.Y or v232.Magnitude < 0.001) then
		v232 = Vector2.new(0, 1)
	end
	local v233 = v232.Unit
	local v234 = (p226 - p224) / 2
	local v235 = math.max(0, v234)
	local v236 = (p227 - p225) / 2
	local v237 = math.max(0, v236)
	local v238 = v233.X
	local v239 = math.abs(v238)
	local v240 = v235 / math.max(0.0001, v239)
	local v241 = v233.Y
	local v242 = math.abs(v241)
	local v243 = v237 / math.max(0.0001, v242)
	return v229 + v233 * math.min(v240, v243), v233, false
end
function v_u_12.screenMarker(p244, p245, p246, p247, p248, p249) -- name: screenMarker
	-- upvalues: (copy) v_u_12, (copy) v_u_7
	local v250, _, v251 = v_u_12.worldToScreen(p244, p249)
	local v252 = v_u_7.refSize()
	local v253, v254, v255 = v_u_12.edgeClamp(v250, v251, p245, p246, p247, p248, v252 / 2)
	return v253, v254, v255, v251
end
function v_u_12.safeInsets() -- name: safeInsets
	-- upvalues: (copy) v_u_7
	local v256 = v_u_7.uiScale()
	local v257 = v_u_7.safeInsets()
	return {
		["l"] = v257.left / v256,
		["t"] = v257.top / v256,
		["r"] = v257.right / v256,
		["b"] = v257.bottom / v256
	}
end
function v_u_12.modalLimits(p258, p259, p260) -- name: modalLimits
	local v261 = p259.X - p260.l - p260.r - 32
	local v262 = math.min(p258, v261)
	local v263 = p259.Y * 0.9
	local v264 = p259.Y - p260.t - p260.b - 16
	local v265 = math.min(v263, v264)
	return v262, math.floor(v265)
end
function v_u_12.placeTip(p266, p267, p268, p269) -- name: placeTip
	local v270 = p269.l + 8
	local v271 = p269.t + 8
	local v272 = p268.X - p269.r - 8
	local v273 = p268.Y - p269.b - 8
	local v274 = p266.X + 16
	local v275 = p266.Y + 18
	if v272 < v274 + p267.X then
		v274 = p266.X - p267.X - 12
	end
	if v273 < v275 + p267.Y then
		v275 = p266.Y - p267.Y - 12
	end
	local v276 = v272 - p267.X
	local v277 = math.min(v274, v276)
	local v278 = v273 - p267.Y
	local v279 = math.min(v275, v278)
	return Vector2.new(math.max(v270, v277), (math.max(v271, v279)))
end
function v_u_12.placeAround(p280, p281, p282, p283) -- name: placeAround
	local v284 = p283.l + 8
	local v285 = p283.t + 8
	local v286 = p282.X - p283.r - 8
	local v287 = p282.Y - p283.b - 8
	local v288 = (p281.x0 + p281.x1) / 2
	local v289 = (p281.y0 + p281.y1) / 2
	local v290 = p281.y0 - 8 - p280.Y
	if v285 <= v290 then
		local v291 = Vector2.new
		local v292 = v288 - p280.X / 2
		local v293 = v286 - p280.X
		local v294 = math.max(v284, v293)
		return v291(math.clamp(v292, v284, v294), v290)
	end
	local v295 = p281.y1 + 8
	if v295 + p280.Y <= v287 then
		local v296 = Vector2.new
		local v297 = v288 - p280.X / 2
		local v298 = v286 - p280.X
		local v299 = math.max(v284, v298)
		return v296(math.clamp(v297, v284, v299), v295)
	end
	local v300 = p281.x1 + 8
	if v300 + p280.X <= v286 then
		local v301 = Vector2.new
		local v302 = v289 - p280.Y / 2
		local v303 = v287 - p280.Y
		local v304 = math.max(v285, v303)
		return v301(v300, (math.clamp(v302, v285, v304)))
	end
	local v305 = p281.x0 - 8 - p280.X
	if v284 <= v305 then
		local v306 = Vector2.new
		local v307 = v289 - p280.Y / 2
		local v308 = v287 - p280.Y
		local v309 = math.max(v285, v308)
		return v306(v305, (math.clamp(v307, v285, v309)))
	end
	local v310 = Vector2.new
	local v311 = v288 - p280.X / 2
	local v312 = v286 - p280.X
	local v313 = math.max(v284, v312)
	local v314 = math.clamp(v311, v284, v313)
	local v315 = v287 - p280.Y
	local v316 = math.max(v285, v315)
	return v310(v314, (math.clamp(v290, v285, v316)))
end
function v_u_12.dropdownRect(p317, p318, p319, p320, p321) -- name: dropdownRect
	local v322 = p321.t + 8
	local v323 = p320.Y - p321.b - 8
	local v324 = math.min(p319, 7)
	local v325 = math.max(1, v324) * p318
	local v326 = v323 - (p317.y + p317.h + 2)
	local v327 = p317.y - 2 - v322
	local v328
	if v325 <= v326 then
		v328 = p317.y + p317.h + 2
	elseif v325 <= v327 then
		v328 = p317.y - v325 - 2
	else
		local v329 = math.max(v326, v327) / p318
		local v330 = math.floor(v329)
		v325 = math.max(1, v330) * p318
		if v327 <= v326 then
			v328 = p317.y + p317.h + 2
		else
			v328 = p317.y - v325 - 2
		end
	end
	local v331 = v323 - v325
	local v332 = math.max(v322, v331)
	local v333 = math.clamp(v328, v322, v332)
	local v334 = p317.x
	local v335 = p321.l
	local v336 = p321.l
	local v337 = p320.X - p321.r - p317.w
	local v338 = math.max(v336, v337)
	return math.clamp(v334, v335, v338), v333, p317.w, v325
end
local v_u_339 = {
	["Device"] = Enum.ScreenInsets.DeviceSafeInsets,
	["None"] = Enum.ScreenInsets.None,
	["CoreUI"] = Enum.ScreenInsets.CoreUISafeInsets
}
function v_u_12.screen(p340, p341, p342) -- name: screen
	-- upvalues: (copy) v_u_2, (copy) v_u_13, (copy) v_u_7, (copy) v_u_339, (copy) v_u_193
	local v343 = p342 or {}
	local v344 = v_u_2:IsRunning()
	local v345 = v_u_13
	local v346
	if v_u_2:IsRunning() then
		v346 = nil
	else
		v346 = game:GetService("StarterGui")
	end
	local v347
	if v344 then
		v346 = v345:WaitForChild("PlayerGui")
		v347 = false
	else
		local v348
		if v345 then
			v348 = v345:FindFirstChildOfClass("PlayerGui")
		else
			v348 = nil
		end
		if v348 then
			v346 = v348
			v347 = false
		else
			v347 = true
		end
	end
	local v349 = v346:FindFirstChild(p340)
	if v349 then
		v349:Destroy()
	end
	local v350 = {
		["Name"] = nil,
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = true,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = nil,
		["Enabled"] = nil,
		["Name"] = p340,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["DisplayOrder"] = p341 or v_u_7.layer.menu,
		["Enabled"] = v343.enabled == nil and true or v343.enabled
	}
	local v351 = Instance.new("ScreenGui")
	if v350 then
		for v352, v353 in v350 do
			v351[v352] = v353
		end
	end
	v351.ScreenInsets = v_u_339[v343.insets or "Device"] or Enum.ScreenInsets.DeviceSafeInsets
	if v347 then
		v351.Archivable = false
	end
	local v354 = {
		["Name"] = "Root",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(1920, 1080)
	}
	local v_u_355 = Instance.new("Frame")
	if v354 then
		for v356, v357 in v354 do
			v_u_355[v356] = v357
		end
	end
	if v351 then
		v_u_355.Parent = v351
	end
	local v358 = {
		["Name"] = "HushScale"
	}
	local v_u_359 = Instance.new("UIScale")
	if v358 then
		for v360, v361 in v358 do
			v_u_359[v360] = v361
		end
	end
	if v_u_355 then
		v_u_359.Parent = v_u_355
	end
	local function v363() -- name: refresh
		-- upvalues: (ref) v_u_7, (copy) v_u_359, (copy) v_u_355
		local v362 = v_u_7.uiScale()
		v_u_359.Scale = v362
		v_u_355.Size = UDim2.fromScale(1 / v362, 1 / v362)
	end
	local v_u_364 = v_u_7.scaleChanged:Connect(v363)
	local v_u_365 = v351:GetPropertyChangedSignal("AbsoluteSize"):Connect(v363)
	v351.Destroying:Connect(function()
		-- upvalues: (copy) v_u_364, (copy) v_u_365
		v_u_364:Disconnect()
		v_u_365:Disconnect()
	end)
	v351.Parent = v346
	local v366 = v_u_7.uiScale()
	v_u_359.Scale = v366
	v_u_355.Size = UDim2.fromScale(1 / v366, 1 / v366)
	task.defer(v363)
	v_u_193[v351] = true
	return v351, v_u_355
end
local function v_u_370(p367, p368, p369) -- name: styledText
	-- upvalues: (copy) v_u_7
	if p368.caps then
		p367 = string.upper(p367)
	end
	if p368.track > 0 and (p369 ~= false and (utf8.len(p367) and utf8.len(p367) <= 48)) then
		p367 = v_u_7.track(p367, p368.track)
	end
	return p367
end
local function v_u_379(p_u_371) -- name: guardWrap
	local v_u_372 = -1
	local v_u_373 = false
	local v_u_374 = 0
	local function v_u_375() -- name: recheck
		-- upvalues: (ref) v_u_374, (copy) p_u_371
		if v_u_374 < 4 and (p_u_371.Parent and (p_u_371.AutomaticSize == Enum.AutomaticSize.Y and p_u_371.TextWrapped)) then
			if p_u_371.TextBounds.Y > 0 and p_u_371.AbsoluteSize.Y + 1 < p_u_371.TextBounds.Y then
				v_u_374 = v_u_374 + 1
				p_u_371.AutomaticSize = Enum.AutomaticSize.None
				p_u_371.AutomaticSize = Enum.AutomaticSize.Y
			end
		end
	end
	p_u_371:GetPropertyChangedSignal("TextBounds"):Connect(function()
		-- upvalues: (copy) v_u_375
		task.defer(v_u_375)
	end)
	task.delay(0.15, v_u_375)
	task.delay(0.6, v_u_375)
	p_u_371:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) p_u_371, (ref) v_u_372, (ref) v_u_373
		local v376 = p_u_371.AbsoluteSize.X + 0.5
		local v377 = math.floor(v376)
		if v377 == v_u_372 then
			return
		else
			local v378 = v_u_372 < 0
			v_u_372 = v377
			if not (v378 or v_u_373) then
				v_u_373 = true
				task.defer(function()
					-- upvalues: (ref) v_u_373, (ref) p_u_371
					v_u_373 = false
					if p_u_371.Parent and p_u_371.AutomaticSize == Enum.AutomaticSize.Y then
						p_u_371.AutomaticSize = Enum.AutomaticSize.None
						p_u_371.AutomaticSize = Enum.AutomaticSize.Y
					end
				end)
			end
		end
	end)
end
local v_u_380 = {
	["micro"] = true,
	["monoS"] = true,
	["small"] = true,
	["caps"] = true
}
function v_u_12.label(p381) -- name: label
	-- upvalues: (copy) v_u_7, (copy) v_u_380, (copy) v_u_370, (copy) v_u_379, (copy) v_u_167
	local v382 = p381.style
	local v383 = v_u_7.styles[v382 or "body"] or v_u_7.styles.body
	local v384 = v_u_7.phoneText(p381.textSize or v383.size, v_u_380[p381.style or "body"] and "caption" or "text")
	local v385 = {
		["Name"] = "Label",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextTransparency"] = nil,
		["RichText"] = nil,
		["TextWrapped"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["FontFace"] = v383.font,
		["TextSize"] = v384,
		["TextColor3"] = p381.color or v383.color,
		["TextTransparency"] = p381.transparency or 0,
		["RichText"] = p381.rich == true,
		["TextWrapped"] = p381.wrap == true
	}
	local v386
	if p381.align == "center" then
		v386 = Enum.TextXAlignment.Center
	elseif p381.align == "right" then
		v386 = Enum.TextXAlignment.Right
	else
		v386 = Enum.TextXAlignment.Left
	end
	v385.TextXAlignment = v386
	local v387
	if p381.valign == "top" then
		v387 = Enum.TextYAlignment.Top
	elseif p381.valign == "bottom" then
		v387 = Enum.TextYAlignment.Bottom
	else
		v387 = Enum.TextYAlignment.Center
	end
	v385.TextYAlignment = v387
	local v388 = Instance.new("TextLabel")
	if v385 then
		for v389, v390 in v385 do
			v388[v389] = v390
		end
	end
	v388:SetAttribute("HushStyle", p381.style or "body")
	v388:SetAttribute("HushTrack", p381.track ~= false)
	local v391 = v_u_370
	local v392 = p381.text or ""
	v388.Text = v391(tostring(v392), v383, p381.track)
	if not p381.wrap then
		v388.TextTruncate = Enum.TextTruncate.AtEnd
	end
	if p381.fit then
		v388.TextScaled = true
		local v393 = {
			["MaxTextSize"] = v384
		}
		local v394 = v_u_7.phoneText
		local v395 = v384 * 0.55
		local v396 = math.floor(v395)
		local v397 = math.max(8, v396)
		v393.MinTextSize = math.min(v384, v394(v397, "scaled"))
		local v398 = Instance.new("UITextSizeConstraint")
		if v393 then
			for v399, v400 in v393 do
				v398[v399] = v400
			end
		end
		if v388 then
			v398.Parent = v388
		end
	elseif p381.wrap and (not p381.autoY and (not p381.autoX and p381.fitWrap ~= false)) then
		v388.TextScaled = true
		local v401 = {
			["Name"] = "WrapFit",
			["MaxTextSize"] = nil,
			["MinTextSize"] = nil,
			["MaxTextSize"] = v384
		}
		local v402 = v_u_7.phoneText
		local v403 = v384 * 0.72
		local v404 = math.floor(v403)
		local v405 = math.max(9, v404)
		v401.MinTextSize = math.min(v384, v402(v405, "scaled"))
		local v406 = Instance.new("UITextSizeConstraint")
		if v401 then
			for v407, v408 in v401 do
				v406[v407] = v408
			end
		end
		if v388 then
			v406.Parent = v388
		end
	end
	if p381.autoX and p381.autoY then
		v388.AutomaticSize = Enum.AutomaticSize.XY
	elseif p381.autoX then
		v388.AutomaticSize = Enum.AutomaticSize.X
	elseif p381.autoY then
		v388.AutomaticSize = Enum.AutomaticSize.Y
		if p381.wrap then
			v_u_379(v388)
		end
	end
	if not p381.size then
		if p381.autoX or p381.autoY then
			local v409 = UDim2.fromOffset
			local v410 = 0
			local v411
			if p381.autoY then
				v411 = 0
			else
				local v412 = v384 * 1.3
				v411 = math.ceil(v412)
			end
			v388.Size = v409(v410, v411)
			if p381.autoY and not p381.autoX then
				v388.Size = UDim2.new(1, 0, 0, 0)
			end
		else
			local v413 = UDim2.new
			local v414 = v384 * 1.3
			v388.Size = v413(1, 0, 0, (math.ceil(v414)))
		end
	end
	if p381.maxSize then
		local v415 = {
			["MaxSize"] = p381.maxSize
		}
		local v416 = Instance.new("UISizeConstraint")
		if v415 then
			for v417, v418 in v415 do
				v416[v417] = v418
			end
		end
		if v388 then
			v416.Parent = v388
		end
	end
	v_u_167(v388, p381)
	if p381.parent then
		v388.Parent = p381.parent
	end
	return v388
end
function v_u_12.setText(p419, p420) -- name: setText
	-- upvalues: (copy) v_u_7, (copy) v_u_370
	local v421 = p419:GetAttribute("HushStyle")
	local v422 = v_u_7.styles[v421 or "body"] or v_u_7.styles.body
	local v423 = v_u_370
	local v424
	if p419:GetAttribute("HushTrack") == false then
		v424 = false
	else
		v424 = nil
	end
	p419.Text = v423(p420, v422, v424)
end
local function v_u_440(p425, p426, p427, p428, p429) -- name: gLine
	local v430 = p428 - p426
	local v431 = p429 - p427
	local v432 = v430 * v430 + v431 * v431
	local v433 = math.sqrt(v432)
	local v434 = {
		["Name"] = "g",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale((p426 + p428) / 2, (p427 + p429) / 2),
		["Size"] = UDim2.new(v433, p425.t, 0, p425.t)
	}
	local v435 = math.atan2(v431, v430)
	v434.Rotation = math.deg(v435)
	v434.BackgroundColor3 = p425.c
	local v436 = p425.f
	local v437 = Instance.new("Frame")
	if v434 then
		for v438, v439 in v434 do
			v437[v438] = v439
		end
	end
	if v436 then
		v437.Parent = v436
	end
end
local function v_u_452(p441, p442, p443, p444, p445, p446) -- name: gRect
	-- upvalues: (copy) v_u_12
	local v447 = {
		["Name"] = "g",
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = UDim2.fromScale(p442, p443),
		["Size"] = UDim2.fromScale(p444, p445),
		["BackgroundColor3"] = p441.c,
		["BackgroundTransparency"] = p446 and 0 or 1
	}
	local v448 = p441.f
	local v449 = Instance.new("Frame")
	if v447 then
		for v450, v451 in v447 do
			v449[v450] = v451
		end
	end
	if v448 then
		v449.Parent = v448
	end
	if not p446 then
		v_u_12.stroke(v449, p441.c, p441.t)
	end
end
local function v_u_467(p453, p454, p455, p456, p457) -- name: gCircle
	-- upvalues: (copy) v_u_12
	local v458 = {
		["Name"] = "g",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(p454, p455),
		["Size"] = UDim2.fromScale(p456 * 2, p456 * 2),
		["BackgroundColor3"] = p453.c,
		["BackgroundTransparency"] = p457 and 0 or 1
	}
	local v459 = p453.f
	local v460 = Instance.new("Frame")
	if v458 then
		for v461, v462 in v458 do
			v460[v461] = v462
		end
	end
	if v459 then
		v460.Parent = v459
	end
	local v463 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v464 = Instance.new("UICorner")
	if v463 then
		for v465, v466 in v463 do
			v464[v465] = v466
		end
	end
	if v460 then
		v464.Parent = v460
	end
	if not p457 then
		v_u_12.stroke(v460, p453.c, p453.t)
	end
end
local function v_u_478(p468, p469, p470, p471, p472) -- name: gDiamond
	-- upvalues: (copy) v_u_12
	local v473 = {
		["Name"] = "g",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(p469, p470),
		["Size"] = UDim2.fromScale(p471, p471),
		["BackgroundColor3"] = p468.c,
		["BackgroundTransparency"] = p472 and 0 or 1
	}
	local v474 = p468.f
	local v475 = Instance.new("Frame")
	if v473 then
		for v476, v477 in v473 do
			v475[v476] = v477
		end
	end
	if v474 then
		v475.Parent = v474
	end
	if not p472 then
		v_u_12.stroke(v475, p468.c, p468.t)
	end
end
local v_u_545 = {
	["health"] = function(p479) -- name: health
		-- upvalues: (copy) v_u_452
		v_u_452(p479, 0.39, 0.15, 0.22, 0.7, true)
		v_u_452(p479, 0.15, 0.39, 0.7, 0.22, true)
	end,
	["stamina"] = function(p480) -- name: stamina
		-- upvalues: (copy) v_u_440
		v_u_440(p480, 0.62, 0.08, 0.34, 0.54)
		v_u_440(p480, 0.34, 0.54, 0.66, 0.46)
		v_u_440(p480, 0.66, 0.46, 0.38, 0.92)
	end,
	["bleeding"] = function(p481) -- name: bleeding
		-- upvalues: (copy) v_u_467, (copy) v_u_478
		v_u_467(p481, 0.5, 0.63, 0.23, true)
		v_u_478(p481, 0.5, 0.47, 0.33, true)
	end,
	["fracture"] = function(p482) -- name: fracture
		-- upvalues: (copy) v_u_440
		v_u_440(p482, 0.1, 0.55, 0.32, 0.36)
		v_u_440(p482, 0.32, 0.36, 0.48, 0.62)
		v_u_440(p482, 0.48, 0.62, 0.64, 0.38)
		v_u_440(p482, 0.64, 0.38, 0.9, 0.5)
	end,
	["infection"] = function(p483) -- name: infection
		-- upvalues: (copy) v_u_467
		v_u_467(p483, 0.5, 0.52, 0.1, true)
		for v484 = 0, 2 do
			local v485 = v484 * 120 - 90
			local v486 = math.rad(v485)
			v_u_467(p483, math.cos(v486) * 0.24 + 0.5, math.sin(v486) * 0.24 + 0.52, 0.16)
		end
	end,
	["clock"] = function(p487) -- name: clock
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p487, 0.5, 0.5, 0.4)
		v_u_440(p487, 0.5, 0.52, 0.5, 0.26)
		v_u_440(p487, 0.5, 0.52, 0.68, 0.62)
	end,
	["extract"] = function(p488) -- name: extract
		-- upvalues: (copy) v_u_440
		v_u_440(p488, 0.2, 0.2, 0.2, 0.8)
		v_u_440(p488, 0.32, 0.5, 0.84, 0.5)
		v_u_440(p488, 0.84, 0.5, 0.64, 0.3)
		v_u_440(p488, 0.84, 0.5, 0.64, 0.7)
	end,
	["ammo"] = function(p489) -- name: ammo
		-- upvalues: (copy) v_u_452, (copy) v_u_467, (copy) v_u_440
		v_u_452(p489, 0.38, 0.38, 0.24, 0.46, true)
		v_u_467(p489, 0.5, 0.38, 0.12, true)
		v_u_440(p489, 0.3, 0.9, 0.7, 0.9)
	end,
	["squad"] = function(p490) -- name: squad
		-- upvalues: (copy) v_u_467, (copy) v_u_452
		v_u_467(p490, 0.5, 0.32, 0.15)
		v_u_452(p490, 0.24, 0.58, 0.52, 0.3)
	end,
	["close"] = function(p491) -- name: close
		-- upvalues: (copy) v_u_440
		v_u_440(p491, 0.25, 0.25, 0.75, 0.75)
		v_u_440(p491, 0.75, 0.25, 0.25, 0.75)
	end,
	["check"] = function(p492) -- name: check
		-- upvalues: (copy) v_u_440
		v_u_440(p492, 0.2, 0.52, 0.42, 0.74)
		v_u_440(p492, 0.42, 0.74, 0.82, 0.28)
	end,
	["warning"] = function(p493) -- name: warning
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		v_u_440(p493, 0.5, 0.12, 0.9, 0.84)
		v_u_440(p493, 0.9, 0.84, 0.1, 0.84)
		v_u_440(p493, 0.1, 0.84, 0.5, 0.12)
		v_u_440(p493, 0.5, 0.38, 0.5, 0.6)
		v_u_452(p493, 0.465, 0.66, 0.07, 0.07, true)
	end,
	["ping"] = function(p494) -- name: ping
		-- upvalues: (copy) v_u_478
		v_u_478(p494, 0.5, 0.5, 0.56)
		v_u_478(p494, 0.5, 0.5, 0.16, true)
	end,
	["skull"] = function(p495) -- name: skull
		-- upvalues: (copy) v_u_467, (copy) v_u_452, (copy) v_u_440
		v_u_467(p495, 0.5, 0.42, 0.3)
		v_u_452(p495, 0.35, 0.36, 0.1, 0.1, true)
		v_u_452(p495, 0.55, 0.36, 0.1, 0.1, true)
		v_u_440(p495, 0.4, 0.74, 0.4, 0.9)
		v_u_440(p495, 0.5, 0.74, 0.5, 0.9)
		v_u_440(p495, 0.6, 0.74, 0.6, 0.9)
	end,
	["heart"] = function(p496) -- name: heart
		-- upvalues: (copy) v_u_467, (copy) v_u_478
		v_u_467(p496, 0.36, 0.4, 0.17, true)
		v_u_467(p496, 0.64, 0.4, 0.17, true)
		v_u_478(p496, 0.5, 0.54, 0.41, true)
	end,
	["settings"] = function(p497) -- name: settings
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p497, 0.5, 0.5, 0.2)
		for v498 = 0, 7 do
			local v499 = v498 * 45
			local v500 = math.rad(v499)
			v_u_440(p497, math.cos(v500) * 0.28 + 0.5, math.sin(v500) * 0.28 + 0.5, math.cos(v500) * 0.42 + 0.5, math.sin(v500) * 0.42 + 0.5)
		end
	end,
	["search"] = function(p501) -- name: search
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p501, 0.42, 0.42, 0.25)
		v_u_440(p501, 0.6, 0.6, 0.86, 0.86)
	end,
	["lock"] = function(p502) -- name: lock
		-- upvalues: (copy) v_u_452
		v_u_452(p502, 0.34, 0.16, 0.32, 0.4)
		v_u_452(p502, 0.22, 0.44, 0.56, 0.42, true)
	end,
	["plus"] = function(p503) -- name: plus
		-- upvalues: (copy) v_u_440
		v_u_440(p503, 0.5, 0.2, 0.5, 0.8)
		v_u_440(p503, 0.2, 0.5, 0.8, 0.5)
	end,
	["minus"] = function(p504) -- name: minus
		-- upvalues: (copy) v_u_440
		v_u_440(p504, 0.2, 0.5, 0.8, 0.5)
	end,
	["chevronDown"] = function(p505) -- name: chevronDown
		-- upvalues: (copy) v_u_440
		v_u_440(p505, 0.25, 0.375, 0.5, 0.625)
		v_u_440(p505, 0.5, 0.625, 0.75, 0.375)
	end,
	["chevronUp"] = function(p506) -- name: chevronUp
		-- upvalues: (copy) v_u_440
		v_u_440(p506, 0.25, 0.625, 0.5, 0.375)
		v_u_440(p506, 0.5, 0.375, 0.75, 0.625)
	end,
	["chevronLeft"] = function(p507) -- name: chevronLeft
		-- upvalues: (copy) v_u_440
		v_u_440(p507, 0.625, 0.25, 0.375, 0.5)
		v_u_440(p507, 0.375, 0.5, 0.625, 0.75)
	end,
	["chevronRight"] = function(p508) -- name: chevronRight
		-- upvalues: (copy) v_u_440
		v_u_440(p508, 0.375, 0.25, 0.625, 0.5)
		v_u_440(p508, 0.625, 0.5, 0.375, 0.75)
	end,
	["arrowUp"] = function(p509) -- name: arrowUp
		-- upvalues: (copy) v_u_440
		v_u_440(p509, 0.5, 0.18, 0.5, 0.86)
		v_u_440(p509, 0.25, 0.425, 0.5, 0.175)
		v_u_440(p509, 0.5, 0.175, 0.75, 0.425)
	end,
	["menu"] = function(p510) -- name: menu
		-- upvalues: (copy) v_u_440
		v_u_440(p510, 0.2, 0.3, 0.8, 0.3)
		v_u_440(p510, 0.2, 0.5, 0.8, 0.5)
		v_u_440(p510, 0.2, 0.7, 0.8, 0.7)
	end,
	["info"] = function(p511) -- name: info
		-- upvalues: (copy) v_u_467, (copy) v_u_440, (copy) v_u_452
		v_u_467(p511, 0.5, 0.5, 0.4)
		v_u_440(p511, 0.5, 0.44, 0.5, 0.72)
		v_u_452(p511, 0.465, 0.27, 0.07, 0.07, true)
	end,
	["cash"] = function(p512) -- name: cash
		-- upvalues: (copy) v_u_452, (copy) v_u_467
		v_u_452(p512, 0.12, 0.28, 0.76, 0.44)
		v_u_467(p512, 0.5, 0.5, 0.1)
	end,
	["star"] = function(p513) -- name: star
		-- upvalues: (copy) v_u_478, (copy) v_u_452
		v_u_478(p513, 0.5, 0.5, 0.5, true)
		v_u_452(p513, 0.25, 0.25, 0.5, 0.5, true)
	end,
	["hand"] = function(p514) -- name: hand
		-- upvalues: (copy) v_u_452, (copy) v_u_440
		v_u_452(p514, 0.28, 0.42, 0.44, 0.44, true)
		v_u_440(p514, 0.34, 0.42, 0.34, 0.16)
		v_u_440(p514, 0.5, 0.42, 0.5, 0.1)
		v_u_440(p514, 0.66, 0.42, 0.66, 0.16)
	end,
	["eye"] = function(p515) -- name: eye
		-- upvalues: (copy) v_u_478, (copy) v_u_467
		v_u_478(p515, 0.5, 0.5, 0.52)
		v_u_467(p515, 0.5, 0.5, 0.11, true)
	end,
	["loot"] = function(p516) -- name: loot
		-- upvalues: (copy) v_u_452, (copy) v_u_440
		v_u_452(p516, 0.16, 0.32, 0.68, 0.52)
		v_u_440(p516, 0.16, 0.5, 0.84, 0.5)
		v_u_452(p516, 0.44, 0.44, 0.12, 0.12, true)
	end,
	["follow"] = function(p517) -- name: follow
		-- upvalues: (copy) v_u_440
		v_u_440(p517, 0.255, 0.25, 0.505, 0.5)
		v_u_440(p517, 0.505, 0.5, 0.255, 0.75)
		v_u_440(p517, 0.495, 0.25, 0.745, 0.5)
		v_u_440(p517, 0.745, 0.5, 0.495, 0.75)
	end,
	["thanks"] = function(p518) -- name: thanks
		-- upvalues: (copy) v_u_467, (copy) v_u_478
		v_u_467(p518, 0.36, 0.4, 0.17, true)
		v_u_467(p518, 0.64, 0.4, 0.17, true)
		v_u_478(p518, 0.5, 0.54, 0.41, true)
	end,
	["horde"] = function(p519) -- name: horde
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p519, 0.3, 0.42, 0.13)
		v_u_467(p519, 0.7, 0.42, 0.13)
		v_u_467(p519, 0.5, 0.36, 0.15, true)
		v_u_440(p519, 0.2, 0.8, 0.8, 0.8)
	end,
	["help"] = function(p520) -- name: help
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p520, 0.5, 0.5, 0.4)
		v_u_440(p520, 0.5, 0.3, 0.5, 0.7)
		v_u_440(p520, 0.3, 0.5, 0.7, 0.5)
	end,
	["door"] = function(p521) -- name: door
		-- upvalues: (copy) v_u_452
		v_u_452(p521, 0.28, 0.12, 0.44, 0.76)
		v_u_452(p521, 0.58, 0.48, 0.07, 0.07, true)
	end,
	["trade"] = function(p522) -- name: trade
		-- upvalues: (copy) v_u_440
		v_u_440(p522, 0.18, 0.36, 0.82, 0.36)
		v_u_440(p522, 0.82, 0.36, 0.66, 0.22)
		v_u_440(p522, 0.82, 0.64, 0.18, 0.64)
		v_u_440(p522, 0.18, 0.64, 0.34, 0.78)
	end,
	["task"] = function(p523) -- name: task
		-- upvalues: (copy) v_u_452, (copy) v_u_440
		v_u_452(p523, 0.22, 0.14, 0.56, 0.74)
		v_u_440(p523, 0.34, 0.36, 0.66, 0.36)
		v_u_440(p523, 0.34, 0.52, 0.66, 0.52)
		v_u_440(p523, 0.34, 0.68, 0.54, 0.68)
	end,
	["hideout"] = function(p524) -- name: hideout
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		v_u_440(p524, 0.12, 0.48, 0.5, 0.16)
		v_u_440(p524, 0.5, 0.16, 0.88, 0.48)
		v_u_452(p524, 0.24, 0.46, 0.52, 0.4)
	end,
	["map"] = function(p525) -- name: map
		-- upvalues: (copy) v_u_440
		v_u_440(p525, 0.14, 0.24, 0.38, 0.14)
		v_u_440(p525, 0.38, 0.14, 0.62, 0.24)
		v_u_440(p525, 0.62, 0.24, 0.86, 0.14)
		v_u_440(p525, 0.14, 0.24, 0.14, 0.86)
		v_u_440(p525, 0.86, 0.14, 0.86, 0.76)
		v_u_440(p525, 0.14, 0.86, 0.38, 0.76)
		v_u_440(p525, 0.38, 0.76, 0.62, 0.86)
		v_u_440(p525, 0.62, 0.86, 0.86, 0.76)
	end,
	["backpack"] = function(p526) -- name: backpack
		-- upvalues: (copy) v_u_452, (copy) v_u_440
		v_u_452(p526, 0.24, 0.28, 0.52, 0.6)
		v_u_452(p526, 0.38, 0.12, 0.24, 0.18)
		v_u_440(p526, 0.34, 0.6, 0.66, 0.6)
	end,
	["weapon"] = function(p527) -- name: weapon
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		v_u_440(p527, 0.1, 0.4, 0.9, 0.4)
		v_u_452(p527, 0.1, 0.36, 0.5, 0.14, true)
		v_u_440(p527, 0.34, 0.5, 0.28, 0.78)
	end,
	["flare"] = function(p528) -- name: flare
		-- upvalues: (copy) v_u_452, (copy) v_u_478, (copy) v_u_440
		v_u_452(p528, 0.42, 0.42, 0.16, 0.46, true)
		v_u_478(p528, 0.5, 0.28, 0.2, true)
		v_u_440(p528, 0.5, 0.06, 0.5, 0.12)
		v_u_440(p528, 0.26, 0.2, 0.32, 0.24)
		v_u_440(p528, 0.74, 0.2, 0.68, 0.24)
	end,
	["parachute"] = function(p529) -- name: parachute
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		for v530 = 0, 5 do
			local v531 = 3.141592653589793 + 3.141592653589793 * v530 / 6
			local v532 = 3.141592653589793 + 3.141592653589793 * (v530 + 1) / 6
			v_u_440(p529, math.cos(v531) * 0.38 + 0.5, math.sin(v531) * 0.3 + 0.42, math.cos(v532) * 0.38 + 0.5, math.sin(v532) * 0.3 + 0.42)
		end
		v_u_440(p529, 0.12, 0.42, 0.88, 0.42)
		v_u_440(p529, 0.14, 0.42, 0.44, 0.72)
		v_u_440(p529, 0.86, 0.42, 0.56, 0.72)
		v_u_440(p529, 0.5, 0.42, 0.5, 0.72)
		v_u_452(p529, 0.39, 0.72, 0.22, 0.18, true)
	end,
	["heli"] = function(p533) -- name: heli
		-- upvalues: (copy) v_u_467, (copy) v_u_440
		v_u_467(p533, 0.4, 0.56, 0.16, true)
		v_u_440(p533, 0.52, 0.55, 0.9, 0.48)
		v_u_440(p533, 0.88, 0.4, 0.9, 0.56)
		v_u_440(p533, 0.1, 0.3, 0.74, 0.3)
		v_u_440(p533, 0.42, 0.3, 0.42, 0.42)
		v_u_440(p533, 0.22, 0.84, 0.6, 0.84)
		v_u_440(p533, 0.3, 0.72, 0.3, 0.84)
		v_u_440(p533, 0.5, 0.72, 0.5, 0.84)
	end,
	["siren"] = function(p534) -- name: siren
		-- upvalues: (copy) v_u_467, (copy) v_u_452, (copy) v_u_440
		v_u_467(p534, 0.5, 0.48, 0.2, true)
		v_u_452(p534, 0.3, 0.48, 0.4, 0.3, true)
		v_u_440(p534, 0.18, 0.86, 0.82, 0.86)
		v_u_440(p534, 0.5, 0.06, 0.5, 0.16)
		v_u_440(p534, 0.08, 0.4, 0.2, 0.44)
		v_u_440(p534, 0.92, 0.4, 0.8, 0.44)
		v_u_440(p534, 0.2, 0.14, 0.28, 0.22)
		v_u_440(p534, 0.8, 0.14, 0.72, 0.22)
	end,
	["truck"] = function(p535) -- name: truck
		-- upvalues: (copy) v_u_452, (copy) v_u_440, (copy) v_u_467
		v_u_452(p535, 0.06, 0.46, 0.52, 0.22)
		v_u_452(p535, 0.56, 0.3, 0.32, 0.38)
		v_u_440(p535, 0.62, 0.3, 0.62, 0.46)
		v_u_467(p535, 0.26, 0.74, 0.1, true)
		v_u_467(p535, 0.72, 0.74, 0.1, true)
	end,
	["shield"] = function(p536) -- name: shield
		-- upvalues: (copy) v_u_440
		v_u_440(p536, 0.22, 0.16, 0.78, 0.16)
		v_u_440(p536, 0.78, 0.16, 0.78, 0.5)
		v_u_440(p536, 0.78, 0.5, 0.5, 0.88)
		v_u_440(p536, 0.5, 0.88, 0.22, 0.5)
		v_u_440(p536, 0.22, 0.5, 0.22, 0.16)
		v_u_440(p536, 0.5, 0.16, 0.5, 0.68)
	end,
	["helmet"] = function(p537) -- name: helmet
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		for v538 = 0, 7 do
			local v539 = 3.141592653589793 + 3.141592653589793 * v538 / 8
			local v540 = 3.141592653589793 + 3.141592653589793 * (v538 + 1) / 8
			v_u_440(p537, math.cos(v539) * 0.34 + 0.5, math.sin(v539) * 0.34 + 0.58, math.cos(v540) * 0.34 + 0.5, math.sin(v540) * 0.34 + 0.58)
		end
		v_u_440(p537, 0.08, 0.58, 0.92, 0.58)
		v_u_452(p537, 0.2, 0.58, 0.6, 0.2)
	end,
	["headphones"] = function(p541) -- name: headphones
		-- upvalues: (copy) v_u_440, (copy) v_u_452
		for v542 = 0, 7 do
			local v543 = 3.141592653589793 + 3.141592653589793 * v542 / 8
			local v544 = 3.141592653589793 + 3.141592653589793 * (v542 + 1) / 8
			v_u_440(p541, math.cos(v543) * 0.3 + 0.5, math.sin(v543) * 0.3 + 0.56, math.cos(v544) * 0.3 + 0.5, math.sin(v544) * 0.3 + 0.56)
		end
		v_u_452(p541, 0.12, 0.5, 0.17, 0.32, true)
		v_u_452(p541, 0.71, 0.5, 0.17, 0.32, true)
	end
}
function v_u_12.glyphNames() -- name: glyphNames
	-- upvalues: (copy) v_u_545
	local v546 = {}
	for v547 in v_u_545 do
		table.insert(v546, v547)
	end
	table.sort(v546)
	return v546
end
function v_u_12.icon(p548, p549) -- name: icon
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_545, (copy) v_u_167
	local v550 = p549 or {}
	local v551 = v550.size or 20
	local v552 = v550.color or v_u_10.text
	local v553 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Name"] = "Icon_" .. p548
	}
	local v554
	if typeof(v551) == "UDim2" then
		v554 = v551
	else
		v554 = UDim2.fromOffset(v551, v551)
	end
	v553.Size = v554
	local v555 = Instance.new("Frame")
	if v553 then
		for v556, v557 in v553 do
			v555[v556] = v557
		end
	end
	v555:SetAttribute("HushIcon", p548)
	local v558 = {
		["AspectRatio"] = 1
	}
	local v559 = Instance.new("UIAspectRatioConstraint")
	if v558 then
		for v560, v561 in v558 do
			v559[v560] = v561
		end
	end
	if v555 then
		v559.Parent = v555
	end
	local v562 = v_u_7.icons[p548]
	if v562 then
		local v563 = {
			["Name"] = "Img",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ScaleType"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Image"] = v562,
			["ImageColor3"] = v552,
			["ScaleType"] = Enum.ScaleType.Fit
		}
		local v564 = Instance.new("ImageLabel")
		if v563 then
			for v565, v566 in v563 do
				v564[v565] = v566
			end
		end
		if v555 then
			v564.Parent = v555
		end
	else
		local v567 = v_u_545[p548] or v_u_545.info
		local v568 = typeof(v551) ~= "number" and 20 or v551
		local v569 = v550.thickness
		if not v569 then
			local v570 = v568 / 11 + 0.5
			local v571 = math.floor(v570)
			v569 = math.max(1, v571)
		end
		v567({
			["f"] = v555,
			["c"] = v552,
			["t"] = v569
		})
	end
	v_u_167(v555, {
		["position"] = v550.position,
		["anchor"] = v550.anchor,
		["zindex"] = v550.zindex,
		["name"] = v550.name
	})
	if v550.zindex then
		for _, v572 in v555:GetDescendants() do
			if not v572:IsA("GuiObject") then
				continue
			end
			v572.ZIndex = v550.zindex
		end
	end
	if v550.parent then
		v555.Parent = v550.parent
	end
	return v555
end
function v_u_12.setIconColor(p573, p574) -- name: setIconColor
	for _, v575 in p573:GetDescendants() do
		if v575:IsA("ImageLabel") then
			v575.ImageColor3 = p574
		elseif v575:IsA("Frame") then
			v575.BackgroundColor3 = p574
		else
			if not v575:IsA("UIStroke") then
				continue
			end
			v575.Color = p574
		end
	end
end
local v_u_576 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_577 = false
local function v_u_590(p578, p579) -- name: refreshChip
	-- upvalues: (copy) v_u_12
	local v_u_580 = p578:FindFirstChild("Key")
	if v_u_580 then
		local v581 = v_u_12.hint(p579)
		v_u_580.Text = string.upper(v581)
		p578.AutomaticSize = Enum.AutomaticSize.None
		local v582 = p578.Size.Y.Offset
		local v583 = (utf8.len(v_u_580.Text) or #v_u_580.Text) * v_u_580.TextSize * 0.6
		local v584, v585 = pcall(function()
			-- upvalues: (copy) v_u_580
			return v_u_580.TextBounds.X
		end)
		if v584 and (type(v585) == "number" and (v585 > 0 and v585 < v583 * 2)) then
			local v586 = v583 * 0.8
			v583 = math.max(v586, v585)
		end
		local v587 = math.ceil(v583) + 12
		local v588 = math.max(v582, v587)
		if p578.Size.X.Offset ~= v588 or p578.Size.X.Scale ~= 0 then
			p578.Size = UDim2.fromOffset(v588, v582)
		end
		local v589
		if v581 == "" then
			v589 = false
		else
			v589 = p578:GetAttribute("ForceHidden") ~= true
		end
		p578.Visible = v589
	end
end
function v_u_12.keyHint(p_u_591, p592) -- name: keyHint
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_7, (copy) v_u_167, (copy) v_u_576, (copy) v_u_590, (ref) v_u_577
	local v593 = p592 or {}
	local v594 = v593.size or 22
	local v595 = {
		["Name"] = "KeyHint",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.raised,
		["Size"] = UDim2.fromOffset(v594, v594)
	}
	local v_u_596 = Instance.new("Frame")
	if v595 then
		for v597, v598 in v595 do
			v_u_596[v597] = v598
		end
	end
	v_u_596:SetAttribute("Action", p_u_591)
	v_u_12.stroke(v_u_596, v_u_10.lineStrong)
	local v599 = {
		["Name"] = "Lip",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.lineStrong,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v600 = Instance.new("Frame")
	if v599 then
		for v601, v602 in v599 do
			v600[v601] = v602
		end
	end
	if v_u_596 then
		v600.Parent = v_u_596
	end
	local v603 = {
		["Name"] = "Key",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextXAlignment"] = nil,
		["TextColor3"] = nil,
		["Text"] = "",
		["Size"] = UDim2.new(1, 0, 1, -2),
		["FontFace"] = v_u_7.font.monoBold
	}
	local v604 = v_u_7.phoneText
	local v605 = v594 * 0.55
	local v606 = math.floor(v605)
	v603.TextSize = v604(math.max(11, v606), "caption")
	v603.TextXAlignment = Enum.TextXAlignment.Center
	v603.TextColor3 = v_u_10.text
	local v607 = Instance.new("TextLabel")
	if v603 then
		for v608, v609 in v603 do
			v607[v608] = v609
		end
	end
	if v_u_596 then
		v607.Parent = v_u_596
	end
	v_u_167(v_u_596, {
		["position"] = v593.position,
		["anchor"] = v593.anchor,
		["zindex"] = v593.zindex,
		["order"] = v593.order,
		["name"] = v593.name
	})
	v_u_576[v_u_596] = p_u_591
	v_u_590(v_u_596, p_u_591)
	local v610 = v_u_596:FindFirstChild("Key")
	if v610 then
		v610:GetPropertyChangedSignal("TextBounds"):Connect(function()
			-- upvalues: (copy) v_u_596, (ref) v_u_590, (copy) p_u_591
			if v_u_596.Parent then
				v_u_590(v_u_596, p_u_591)
			end
		end)
	end
	if not v_u_577 then
		v_u_577 = true
		v_u_12.onDevice(function()
			-- upvalues: (ref) v_u_576, (ref) v_u_590
			for v611, v612 in v_u_576 do
				if not v611.Parent then
					continue
				end
				v_u_590(v611, v612)
			end
		end)
	end
	if v593.parent then
		v_u_596.Parent = v593.parent
	end
	task.delay(1, function()
		-- upvalues: (copy) v_u_596, (ref) v_u_590, (copy) p_u_591
		if v_u_596.Parent then
			v_u_590(v_u_596, p_u_591)
		end
	end)
	return v_u_596
end
local v_u_613 = nil
function v_u_12.selectionImage() -- name: selectionImage
	-- upvalues: (ref) v_u_613, (copy) v_u_12, (copy) v_u_10
	if v_u_613 then
		return v_u_613
	end
	local v614 = {
		["Name"] = "HushSelection",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v615 = Instance.new("Frame")
	if v614 then
		for v616, v617 in v614 do
			v615[v616] = v617
		end
	end
	v_u_12.stroke(v615, v_u_10.accent, 2, 0)
	v_u_613 = v615
	return v615
end
function v_u_12.panel(p618) -- name: panel
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_12, (copy) v_u_167
	local v619 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Name"] = p618.name or "Panel"
	}
	local v620
	if p618.raised then
		v620 = v_u_10.raised
	else
		v620 = v_u_10.bg
	end
	v619.BackgroundColor3 = v620
	local v621 = p618.transparency
	if not v621 then
		if p618.raised then
			v621 = v_u_7.alpha.raised
		else
			v621 = v_u_7.alpha.panel
		end
	end
	v619.BackgroundTransparency = v621
	v619.Size = p618.size or UDim2.fromOffset(320, 200)
	local v622 = Instance.new("Frame")
	if v619 then
		for v623, v624 in v619 do
			v622[v623] = v624
		end
	end
	if p618.autoY then
		v622.AutomaticSize = Enum.AutomaticSize.Y
	end
	if p618.stroke ~= false then
		v_u_12.stroke(v622, p618.strokeColor or v_u_10.line)
	end
	if p618.sheen ~= false then
		local v625 = {
			["Rotation"] = 90,
			["Color"] = nil,
			["Color"] = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(215, 218, 224))
		}
		local v626 = Instance.new("UIGradient")
		if v625 then
			for v627, v628 in v625 do
				v626[v627] = v628
			end
		end
		if v622 then
			v626.Parent = v622
		end
	end
	if p618.accent then
		local v629 = {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2
		}
		local v630 = p618.accent
		local v631
		if typeof(v630) == "Color3" then
			v631 = p618.accent
		else
			v631 = v_u_10.accent
		end
		v629.BackgroundColor3 = v631
		v629.Size = UDim2.new(1, 0, 0, 2)
		local v632 = Instance.new("Frame")
		if v629 then
			for v633, v634 in v629 do
				v632[v633] = v634
			end
		end
		if v622 then
			v632.Parent = v622
		end
	end
	local v635
	if p618.title then
		local v636 = {
			["Name"] = "Header",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, p618.subtitle and 58 or 44)
		}
		local v637 = Instance.new("Frame")
		if v636 then
			for v638, v639 in v636 do
				v637[v638] = v639
			end
		end
		if v622 then
			v637.Parent = v622
		end
		v_u_12.pad(v637, {
			v_u_7.space.m,
			v_u_7.space.m,
			v_u_7.space.s,
			0
		})
		v_u_12.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["size"] = nil,
			["name"] = "Title",
			["parent"] = v637,
			["text"] = p618.title,
			["size"] = UDim2.new(1, 0, 0, 24)
		})
		if p618.subtitle then
			v_u_12.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["size"] = nil,
				["position"] = nil,
				["name"] = "Subtitle",
				["parent"] = v637,
				["text"] = p618.subtitle,
				["size"] = UDim2.new(1, 0, 0, 18),
				["position"] = UDim2.fromOffset(0, 26)
			})
		end
		v_u_12.divider({
			["parent"] = v637,
			["position"] = UDim2.new(0, 0, 1, 0),
			["size"] = UDim2.new(1, 0, 0, 1)
		})
		local v640 = {
			["Name"] = "Content",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, v637.Size.Y.Offset),
			["Size"] = UDim2.new(1, 0, 1, -v637.Size.Y.Offset)
		}
		v635 = Instance.new("Frame")
		if v640 then
			for v641, v642 in v640 do
				v635[v641] = v642
			end
		end
		if v622 then
			v635.Parent = v622
		end
		if p618.autoY then
			v635.AutomaticSize = Enum.AutomaticSize.Y
			v635.Size = UDim2.new(1, 0, 0, 0)
		end
	else
		local v643 = {
			["Name"] = "Content",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil
		}
		local v644
		if p618.autoY then
			v644 = UDim2.new(1, 0, 0, 0)
		else
			v644 = UDim2.fromScale(1, 1)
		end
		v643.Size = v644
		local v645
		if p618.autoY then
			v645 = Enum.AutomaticSize.Y
		else
			v645 = Enum.AutomaticSize.None
		end
		v643.AutomaticSize = v645
		v635 = Instance.new("Frame")
		if v643 then
			for v646, v647 in v643 do
				v635[v646] = v647
			end
		end
		if v622 then
			v635.Parent = v622
		end
	end
	if p618.padding ~= false then
		v_u_12.pad(v635, p618.padding or v_u_7.space.m)
	end
	if p618.layout then
		v_u_12.layout(v635, p618.layout, p618.gap, p618.align)
	end
	v_u_167(v622, p618)
	if p618.parent then
		v622.Parent = p618.parent
	end
	return v622, v635
end
function v_u_12.animateIn(p648, p649) -- name: animateIn
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	local v650 = p648:GetAttribute("HushHome")
	if not v650 then
		v650 = p648.Position
		p648:SetAttribute("HushHome", v650)
	end
	p648.Position = v650 + UDim2.fromOffset(0, p649 or v_u_11.slide)
	p648.Visible = true
	v_u_12.fade(p648, 0, "slow", {
		["from"] = 1
	})
	v_u_12.tween(p648, {
		["Position"] = v650
	}, "slow")
end
function v_u_12.animateOut(p_u_651, p_u_652) -- name: animateOut
	-- upvalues: (copy) v_u_12, (copy) v_u_11
	local v_u_653 = p_u_651:GetAttribute("HushHome") or p_u_651.Position
	v_u_12.tween(p_u_651, {
		["Position"] = v_u_653 + UDim2.fromOffset(0, v_u_11.slide)
	}, "fast")
	v_u_12.fade(p_u_651, 1, "fast", {
		["onDone"] = function() -- name: onDone
			-- upvalues: (copy) p_u_652, (copy) p_u_651, (copy) v_u_653
			if p_u_652 then
				p_u_651:Destroy()
			else
				p_u_651.Visible = false
				p_u_651.Position = v_u_653
			end
		end
	})
end
function v_u_12.fitWindow(p654, p655, p656) -- name: fitWindow
	local v657 = p655.X - p656.l - p656.r - 24
	local v658 = p655.Y - p656.t - p656.b - 24
	local v659 = p654.X
	local v660 = p654.Y
	local v661 = UDim2.new
	local v662 = v659.Scale
	local v663
	if v659.Scale == 0 then
		local v664 = v659.Offset
		v663 = math.min(v664, v657)
	else
		v663 = v659.Offset
	end
	local v665 = v660.Scale
	local v666
	if v660.Scale == 0 then
		local v667 = v660.Offset
		v666 = math.min(v667, v658)
	else
		v666 = v660.Offset
	end
	return v661(v662, v663, v665, v666)
end
function v_u_12.window(p_u_668) -- name: window
	-- upvalues: (copy) v_u_12, (copy) v_u_10, (copy) v_u_7
	local v669 = v_u_12.safeInsets()
	local v670 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["Visible"] = false,
		["Name"] = p_u_668.name or "Window",
		["BackgroundColor3"] = v_u_10.bg,
		["BackgroundTransparency"] = v_u_7.alpha.panel,
		["Size"] = v_u_12.fitWindow(p_u_668.size or UDim2.fromOffset(720, 520), v_u_7.refSize(), v669),
		["Position"] = p_u_668.position or UDim2.fromScale(0.5, 0.5),
		["AnchorPoint"] = p_u_668.anchor or Vector2.new(0.5, 0.5)
	}
	local v_u_671 = Instance.new("Frame")
	if v670 then
		for v672, v673 in v670 do
			v_u_671[v672] = v673
		end
	end
	v_u_12.stroke(v_u_671, v_u_10.line)
	local v674 = {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_10.accent,
		["Size"] = UDim2.new(0, 48, 0, 2)
	}
	local v675 = Instance.new("Frame")
	if v674 then
		for v676, v677 in v674 do
			v675[v676] = v677
		end
	end
	if v_u_671 then
		v675.Parent = v_u_671
	end
	local v678 = {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 64)
	}
	local v679 = Instance.new("Frame")
	if v678 then
		for v680, v681 in v678 do
			v679[v680] = v681
		end
	end
	if v_u_671 then
		v679.Parent = v_u_671
	end
	v_u_12.pad(v679, {
		v_u_7.space.l,
		v_u_7.space.m,
		v_u_7.space.m,
		0
	})
	local v_u_682 = v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h2",
		["size"] = nil,
		["name"] = "Title",
		["parent"] = v679,
		["text"] = p_u_668.title or "",
		["size"] = UDim2.new(1, -56, 0, 30)
	})
	if p_u_668.subtitle then
		v_u_12.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["size"] = nil,
			["position"] = nil,
			["name"] = "Subtitle",
			["parent"] = v679,
			["text"] = p_u_668.subtitle,
			["size"] = UDim2.new(1, -56, 0, 18),
			["position"] = UDim2.fromOffset(0, 30)
		})
	end
	v_u_12.divider({
		["parent"] = v_u_671,
		["position"] = UDim2.fromOffset(0, 64),
		["size"] = UDim2.new(1, 0, 0, 1)
	})
	local v683 = {
		["Name"] = "Content",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, 65),
		["Size"] = UDim2.new(1, 0, 1, -65)
	}
	local v684 = Instance.new("Frame")
	if v683 then
		for v685, v686 in v683 do
			v684[v685] = v686
		end
	end
	if v_u_671 then
		v684.Parent = v_u_671
	end
	v_u_12.pad(v684, {
		v_u_7.space.l,
		v_u_7.space.l,
		v_u_7.space.m,
		v_u_7.space.l
	})
	local v_u_687 = false
	local v689 = {
		["open"] = function() -- name: open
			-- upvalues: (ref) v_u_687, (ref) v_u_12, (ref) v_u_7, (copy) v_u_671
			if not v_u_687 then
				v_u_687 = true
				v_u_12.sound(v_u_7.sounds.open)
				v_u_12.animateIn(v_u_671)
			end
		end,
		["close"] = function() -- name: close
			-- upvalues: (ref) v_u_687, (ref) v_u_12, (ref) v_u_7, (copy) v_u_671, (copy) p_u_668
			if v_u_687 then
				v_u_687 = false
				v_u_12.sound(v_u_7.sounds.close)
				v_u_12.animateOut(v_u_671)
				if p_u_668.onClose then
					task.spawn(p_u_668.onClose)
				end
			end
		end,
		["isOpen"] = function() -- name: isOpen
			-- upvalues: (ref) v_u_687
			return v_u_687
		end,
		["setTitle"] = function(p688) -- name: setTitle
			-- upvalues: (ref) v_u_12, (copy) v_u_682
			v_u_12.setText(v_u_682, p688)
		end
	}
	v_u_12.closeIcon({
		["parent"] = nil,
		["size"] = 36,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v679,
		["position"] = UDim2.new(1, 0, 0, -4),
		["anchor"] = Vector2.new(1, 0),
		["onClick"] = v689.close
	})
	if p_u_668.zindex then
		v_u_671.ZIndex = p_u_668.zindex
	end
	if p_u_668.parent then
		v_u_671.Parent = p_u_668.parent
	end
	v_u_671:SetAttribute("HushHome", v_u_671.Position)
	return v_u_671, v684, v689
end
function v_u_12.divider(p690) -- name: divider
	-- upvalues: (copy) v_u_10, (copy) v_u_167
	local v691 = p690 or {}
	local v692 = v691.thickness or 1
	local v693 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Name"] = v691.name or "Divider",
		["BackgroundColor3"] = v691.color or v_u_10.line,
		["BackgroundTransparency"] = v691.transparency or 0
	}
	local v694 = v691.size
	if not v694 then
		if v691.vertical then
			v694 = UDim2.new(0, v692, 1, 0)
		else
			v694 = UDim2.new(1, 0, 0, v692)
		end
	end
	v693.Size = v694
	local v695 = Instance.new("Frame")
	if v693 then
		for v696, v697 in v693 do
			v695[v696] = v697
		end
	end
	v_u_167(v695, {
		["position"] = v691.position,
		["anchor"] = v691.anchor,
		["zindex"] = v691.zindex,
		["order"] = v691.order
	})
	if v691.parent then
		v695.Parent = v691.parent
	end
	return v695
end
local function v_u_700(p698) -- name: kindOf
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_9
	if p698 == "primary" then
		return {
			["bg"] = nil,
			["bgA"] = 0,
			["bgHover"] = nil,
			["text"] = nil,
			["textHover"] = nil,
			["stroke"] = nil,
			["strokeHover"] = nil,
			["line"] = nil,
			["font"] = nil,
			["bg"] = v_u_10.accent,
			["bgHover"] = Color3.fromHex("#F2B557"),
			["text"] = v_u_10.ink,
			["textHover"] = v_u_10.ink,
			["line"] = v_u_10.ink,
			["font"] = v_u_7.font.headingBold
		}
	end
	if p698 == "ghost" then
		return {
			["bg"] = nil,
			["bgA"] = 1,
			["bgHover"] = nil,
			["text"] = nil,
			["textHover"] = nil,
			["stroke"] = nil,
			["strokeHover"] = nil,
			["line"] = nil,
			["font"] = nil,
			["bg"] = v_u_10.raised,
			["bgHover"] = v_u_10.raised,
			["text"] = v_u_10.text2,
			["textHover"] = v_u_10.text,
			["line"] = v_u_10.accent,
			["font"] = v_u_7.font.heading
		}
	end
	if p698 ~= "close" then
		return p698 == "danger" and {
			["bg"] = nil,
			["bgA"] = 0.2,
			["bgHover"] = nil,
			["text"] = nil,
			["textHover"] = nil,
			["stroke"] = nil,
			["strokeHover"] = nil,
			["line"] = nil,
			["font"] = nil,
			["bg"] = v_u_10.dangerDeep,
			["bgHover"] = Color3.fromHex("#4A1A16"),
			["text"] = v_u_10.danger,
			["textHover"] = Color3.fromHex("#F0645A"),
			["stroke"] = v_u_10.danger,
			["strokeHover"] = Color3.fromHex("#F0645A"),
			["line"] = v_u_10.danger,
			["font"] = v_u_7.font.heading
		} or (p698 == "alert" and {
			["bg"] = nil,
			["bgA"] = 0,
			["bgHover"] = nil,
			["text"] = nil,
			["textHover"] = nil,
			["stroke"] = nil,
			["strokeHover"] = nil,
			["line"] = nil,
			["font"] = nil,
			["bg"] = v_u_10.danger,
			["bgHover"] = Color3.fromHex("#F0645A"),
			["text"] = v_u_10.white,
			["textHover"] = v_u_10.white,
			["stroke"] = Color3.fromHex("#F0645A"),
			["strokeHover"] = v_u_10.white,
			["line"] = v_u_10.white,
			["font"] = v_u_7.font.headingBold
		} or {
			["bg"] = nil,
			["bgA"] = 0.05,
			["bgHover"] = nil,
			["text"] = nil,
			["textHover"] = nil,
			["stroke"] = nil,
			["strokeHover"] = nil,
			["line"] = nil,
			["font"] = nil,
			["bg"] = v_u_10.raised,
			["bgHover"] = v_u_10.raised2,
			["text"] = v_u_10.text,
			["textHover"] = v_u_10.text,
			["stroke"] = v_u_10.line,
			["strokeHover"] = v_u_10.lineStrong,
			["line"] = v_u_10.accent,
			["font"] = v_u_7.font.heading
		})
	end
	local v699 = v_u_9.STYLE
	return {
		["bg"] = nil,
		["bgA"] = 0,
		["bgHover"] = nil,
		["text"] = nil,
		["textHover"] = nil,
		["stroke"] = nil,
		["strokeHover"] = nil,
		["line"] = nil,
		["font"] = nil,
		["bg"] = Color3.fromHex(v699.bg),
		["bgHover"] = Color3.fromHex(v699.bgHover),
		["text"] = Color3.fromHex(v699.text),
		["textHover"] = Color3.fromHex(v699.text),
		["stroke"] = Color3.fromHex(v699.stroke),
		["strokeHover"] = Color3.fromHex(v699.strokeHover),
		["line"] = Color3.fromHex(v699.strokeHover),
		["font"] = v_u_7.font.headingBold
	}
end
local function v_u_755(p_u_701, p702) -- name: makeButtonBase
	-- upvalues: (copy) v_u_700, (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (copy) v_u_11, (copy) v_u_167
	local v703 = v_u_700(p_u_701.kind)
	local v704 = v_u_7.touch
	local v705 = p_u_701.height
	if not v705 then
		local v706 = p_u_701.size
		if typeof(v706) == "number" then
			v705 = p_u_701.size
		else
			v705 = v_u_7.control
		end
	end
	local v707 = v704(v705)
	local v708 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = false,
		["Selectable"] = true,
		["Name"] = p_u_701.name or "Button",
		["BackgroundColor3"] = v703.bg,
		["BackgroundTransparency"] = v703.bgA
	}
	local v_u_709 = Instance.new("TextButton")
	if v708 then
		for v710, v711 in v708 do
			v_u_709[v710] = v711
		end
	end
	local v712 = p_u_701.size
	if typeof(v712) == "UDim2" then
		v_u_709.Size = p_u_701.size
	elseif p702 then
		v_u_709.Size = UDim2.fromOffset(v707, v707)
	else
		v_u_709.Size = UDim2.fromOffset(p_u_701.width or 0, v707)
		if not p_u_701.width then
			v_u_709.AutomaticSize = Enum.AutomaticSize.X
		end
	end
	local v713 = {
		["Name"] = "Press"
	}
	local v_u_714 = Instance.new("UIScale")
	if v713 then
		for v715, v716 in v713 do
			v_u_714[v715] = v716
		end
	end
	if v_u_709 then
		v_u_714.Parent = v_u_709
	end
	local v_u_717 = v_u_12.stroke(v_u_709, v703.stroke or v_u_10.line, 1, v703.stroke and 0 or 1)
	local v718 = {
		["Name"] = "Underline",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v703.line,
		["BackgroundTransparency"] = p_u_701.kind == "primary" and 0.55 or 0,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(0, 0, 0, 2)
	}
	local v_u_719 = Instance.new("Frame")
	if v718 then
		for v720, v721 in v718 do
			v_u_719[v720] = v721
		end
	end
	if v_u_709 then
		v_u_719.Parent = v_u_709
	end
	local v_u_722 = {
		["hover"] = false,
		["enabled"] = nil,
		["selected"] = false,
		["kind"] = nil,
		["enabled"] = p_u_701.disabled ~= true,
		["kind"] = v703
	}
	local v_u_723 = {}
	local v_u_724 = {}
	local function v_u_745(p725) -- name: paint
		-- upvalues: (copy) v_u_722, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_709, (copy) v_u_717, (copy) v_u_719, (copy) v_u_723, (copy) v_u_724
		local v726 = v_u_722.kind
		local v727 = v_u_722.hover
		if v727 then
			v727 = v_u_722.enabled
		end
		local v728
		if v727 then
			v728 = v726.bgHover
		else
			v728 = v726.bg
		end
		local v729
		if v_u_722.enabled then
			if v727 or v_u_722.selected then
				v729 = v726.textHover
			else
				v729 = v726.text
			end
		else
			v729 = v_u_10.muted
		end
		local v730
		if v_u_722.selected then
			v730 = v_u_10.accent
		elseif v727 then
			v730 = v726.strokeHover or v_u_10.line
		else
			v730 = v726.stroke or v_u_10.line
		end
		local v731 = (v_u_722.selected or v726.stroke) and 0 or 1
		local v732 = (v727 or v_u_722.selected) and 1 or 0
		local v733 = p725 and 0 or v_u_11.fast
		local v734 = v_u_12.tween
		local v735 = v_u_709
		local v736 = {
			["BackgroundColor3"] = v728
		}
		local v737
		if v_u_722.enabled then
			v737 = v726.bgA
		else
			local v738 = v726.bgA + 0.4
			v737 = math.min(1, v738)
		end
		v736.BackgroundTransparency = v737
		v734(v735, v736, v733)
		v_u_12.tween(v_u_717, {
			["Color"] = v730,
			["Transparency"] = v731
		}, v733)
		local v739 = v_u_12.tween
		local v740 = v_u_719
		local v741 = {
			["Size"] = UDim2.new(v732, 0, 0, 2)
		}
		local v742
		if v727 then
			v742 = v_u_11.slow
		else
			v742 = v_u_11.fast
		end
		v739(v740, v741, v742)
		for _, v743 in v_u_723 do
			v_u_12.tween(v743, {
				["TextColor3"] = v729
			}, v733)
		end
		for _, v744 in v_u_724 do
			v_u_12.setIconColor(v744, v729)
		end
	end
	v_u_709.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_722, (copy) p_u_701, (ref) v_u_12, (ref) v_u_7, (copy) v_u_745
		v_u_722.hover = true
		if v_u_722.enabled and p_u_701.sound ~= false then
			v_u_12.sound(v_u_7.sounds.hover)
		end
		v_u_745()
	end)
	v_u_709.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_722, (ref) v_u_12, (copy) v_u_714, (copy) v_u_745
		v_u_722.hover = false
		v_u_12.tween(v_u_714, {
			["Scale"] = 1
		}, "fast")
		v_u_745()
	end)
	v_u_709.SelectionImageObject = v_u_12.selectionImage()
	v_u_709.SelectionGained:Connect(function()
		-- upvalues: (copy) v_u_722, (copy) p_u_701, (ref) v_u_12, (ref) v_u_7, (copy) v_u_745
		v_u_722.hover = true
		if v_u_722.enabled and p_u_701.sound ~= false then
			v_u_12.sound(v_u_7.sounds.hover)
		end
		v_u_745()
	end)
	v_u_709.SelectionLost:Connect(function()
		-- upvalues: (copy) v_u_722, (copy) v_u_745
		v_u_722.hover = false
		v_u_745()
	end)
	v_u_709.InputBegan:Connect(function(p746)
		-- upvalues: (copy) v_u_722, (ref) v_u_12, (copy) v_u_714, (ref) v_u_11
		if (p746.UserInputType == Enum.UserInputType.MouseButton1 or p746.UserInputType == Enum.UserInputType.Touch) and v_u_722.enabled then
			v_u_12.tween(v_u_714, {
				["Scale"] = v_u_11.pressScale
			}, 0.06)
		end
	end)
	v_u_709.InputEnded:Connect(function(p747)
		-- upvalues: (ref) v_u_12, (copy) v_u_714, (copy) v_u_722, (copy) v_u_745
		if p747.UserInputType == Enum.UserInputType.MouseButton1 or p747.UserInputType == Enum.UserInputType.Touch then
			v_u_12.tween(v_u_714, {
				["Scale"] = 1
			}, "fast")
			if p747.UserInputType == Enum.UserInputType.Touch then
				v_u_722.hover = false
				v_u_745()
			end
		end
	end)
	v_u_709.Activated:Connect(function()
		-- upvalues: (copy) v_u_722, (copy) p_u_701, (ref) v_u_12, (ref) v_u_7
		if v_u_722.enabled then
			if p_u_701.sound ~= false then
				local v748 = v_u_12.sound
				local v749
				if p_u_701.kind == "primary" then
					v749 = v_u_7.sounds.confirm
				else
					v749 = v_u_7.sounds.click
				end
				v748(v749)
			end
			if p_u_701.onClick then
				task.spawn(p_u_701.onClick)
			end
		else
			if p_u_701.sound ~= false then
				v_u_12.sound(v_u_7.sounds.error)
			end
			local v750 = p_u_701.onDisabledClick
			if type(v750) == "function" then
				task.spawn(p_u_701.onDisabledClick)
			end
		end
	end)
	local v754 = {
		["setEnabled"] = function(p751) -- name: setEnabled
			-- upvalues: (copy) v_u_722, (copy) v_u_709, (copy) v_u_745
			v_u_722.enabled = p751
			v_u_709:SetAttribute("Disabled", not p751)
			v_u_745()
		end,
		["setSelected"] = function(p752) -- name: setSelected
			-- upvalues: (copy) v_u_722, (copy) v_u_745
			v_u_722.selected = p752
			v_u_745()
		end,
		["setKind"] = function(p753) -- name: setKind
			-- upvalues: (copy) v_u_722, (ref) v_u_700, (copy) v_u_745
			v_u_722.kind = v_u_700(p753)
			v_u_745(true)
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) v_u_709
			v_u_709:Destroy()
		end,
		["_visuals"] = v_u_723,
		["_icons"] = v_u_724,
		["_paint"] = v_u_745
	}
	v_u_167(v_u_709, {
		["position"] = p_u_701.position,
		["anchor"] = p_u_701.anchor,
		["zindex"] = p_u_701.zindex,
		["order"] = p_u_701.order
	})
	if p_u_701.tooltip then
		v_u_12.tooltip(v_u_709, function()
			-- upvalues: (copy) p_u_701
			return p_u_701.tooltip
		end)
	end
	return v_u_709, v754
end
function v_u_12.button(p756) -- name: button
	-- upvalues: (copy) v_u_755, (copy) v_u_700, (copy) v_u_7, (copy) v_u_12
	local v757, v758 = v_u_755(p756, false)
	local v759 = v_u_700(p756.kind)
	local v760 = {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.fromScale(v757.AutomaticSize == Enum.AutomaticSize.X and 0 or 1, 1)
	}
	local v761
	if v757.AutomaticSize == Enum.AutomaticSize.X then
		v761 = Enum.AutomaticSize.X
	else
		v761 = Enum.AutomaticSize.None
	end
	v760.AutomaticSize = v761
	local v762 = Instance.new("Frame")
	if v760 then
		for v763, v764 in v760 do
			v762[v763] = v764
		end
	end
	if v757 then
		v762.Parent = v757
	end
	local v765
	if v_u_7.isTouch() then
		local v766 = v_u_7.uiScale()
		local v767 = 20 / math.max(v766, 0.5)
		local v768 = math.ceil(v767)
		v765 = math.max(20, v768)
	else
		v765 = 20
	end
	local v769 = v_u_12.pad
	local v770 = {}
	local v771
	if p756.icon then
		v771 = v765 - 6
	else
		v771 = v765
	end
	__set_list(v770, 1, {v771, v765, 0, 0})
	v769(v762, v770)
	v_u_12.layout(v762, "h", 10, v757.AutomaticSize ~= Enum.AutomaticSize.X and "center" or nil)
	if p756.icon then
		local v772 = v_u_12.icon(p756.icon, {
			["size"] = 16,
			["color"] = nil,
			["order"] = 1,
			["color"] = v759.text
		})
		v772.LayoutOrder = 1
		v772.Parent = v762
		local v773 = v758._icons
		table.insert(v773, v772)
	end
	local v774 = p756.kind == "primary" and 17 or 15
	local v775 = {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["LayoutOrder"] = 2,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["FontFace"] = v759.font,
		["TextSize"] = v774,
		["TextColor3"] = v759.text,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.new(0, 0, 1, 0)
	}
	local v_u_776 = Instance.new("TextLabel")
	if v775 then
		for v777, v778 in v775 do
			v_u_776[v777] = v778
		end
	end
	if v762 then
		v_u_776.Parent = v762
	end
	v_u_776:SetAttribute("HushStyle", "h3")
	local v779 = p756.maxTextWidth or (not p756.width and 420 or p756.width - 60)
	local v780 = {
		["MaxSize"] = Vector2.new(math.max(20, v779), (1 / 0))
	}
	local v781 = Instance.new("UISizeConstraint")
	if v780 then
		for v782, v783 in v780 do
			v781[v782] = v783
		end
	end
	if v_u_776 then
		v781.Parent = v_u_776
	end
	local v784 = v758._visuals
	table.insert(v784, v_u_776)
	local function v786(p785) -- name: setText
		-- upvalues: (copy) v_u_776, (ref) v_u_7
		v_u_776.Text = v_u_7.track(string.upper(p785), 1)
	end
	local v787 = p756.text or ""
	v_u_776.Text = v_u_7.track(string.upper(v787), 1)
	v758.setText = v786
	v758.label = v_u_776
	if p756.hint then
		local v788 = v_u_12.keyHint(p756.hint, {
			["size"] = 20
		})
		v788.LayoutOrder = 3
		v788.Parent = v762
	end
	if p756.disabled then
		v758.setEnabled(false)
	else
		v758._paint(true)
	end
	if p756.parent then
		v757.Parent = p756.parent
	end
	return v757, v758
end
function v_u_12.iconButton(p789) -- name: iconButton
	-- upvalues: (copy) v_u_755, (copy) v_u_700, (copy) v_u_7, (copy) v_u_12
	local v790, v791 = v_u_755(p789, true)
	local v792 = v_u_700(p789.kind)
	local v793 = p789.size
	local v794
	if typeof(v793) == "number" then
		v794 = p789.size
	else
		v794 = v_u_7.control
	end
	local v795 = v_u_12.icon
	local v796 = p789.icon
	local v797 = {}
	local v798 = v794 * 0.45
	v797.size = math.floor(v798)
	v797.color = v792.text
	v797.position = UDim2.fromScale(0.5, 0.5)
	v797.anchor = Vector2.new(0.5, 0.5)
	local v799 = v795(v796, v797)
	v799.Parent = v790
	local v800 = v791._icons
	table.insert(v800, v799)
	function v791.setText() end
	if p789.disabled then
		v791.setEnabled(false)
	else
		v791._paint(true)
	end
	if p789.parent then
		v790.Parent = p789.parent
	end
	return v790, v791
end
function v_u_12.closeButton(p801) -- name: closeButton
	-- upvalues: (copy) v_u_12
	local v802 = {}
	for v803, v804 in p801 do
		v802[v803] = v804
	end
	v802.kind = "close"
	v802.icon = "close"
	v802.text = v802.text or "Close"
	v802.name = v802.name or "Close"
	local v805 = v802.height or 40
	v802.height = math.max(v805, 40)
	if not v802.width then
		local v806 = v802.size
		if typeof(v806) ~= "UDim2" then
			v802.width = 120
		end
	end
	return v_u_12.button(v802)
end
function v_u_12.closeIcon(p807) -- name: closeIcon
	-- upvalues: (copy) v_u_12
	local v808 = {}
	for v809, v810 in p807 do
		v808[v809] = v810
	end
	v808.kind = "close"
	v808.icon = "close"
	v808.name = v808.name or "Close"
	v808.tooltip = v808.tooltip or "Close"
	local v811 = v808.size
	local v812 = typeof(v811) ~= "number" and 40 or v808.size
	v808.size = math.max(v812, 36)
	return v_u_12.iconButton(v808)
end
function v_u_12.tabs(p_u_813) -- name: tabs
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (copy) v_u_167
	local v_u_814 = p_u_813.vertical == true
	local v815 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Name"] = p_u_813.name or "Tabs"
	}
	local v816 = p_u_813.size
	if not v816 then
		if v_u_814 then
			v816 = UDim2.new(0, 220, 1, 0)
		else
			v816 = UDim2.new(1, 0, 0, v_u_7.touch(44))
		end
	end
	v815.Size = v816
	local v817 = Instance.new("Frame")
	if v815 then
		for v818, v819 in v815 do
			v817[v818] = v819
		end
	end
	if not v_u_814 then
		v_u_12.divider({
			["parent"] = nil,
			["name"] = "Base",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v817,
			["position"] = UDim2.new(0, 0, 1, -1),
			["size"] = UDim2.new(1, 0, 0, 1)
		})
	end
	local v820 = {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 0,
		["ElasticBehavior"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new()
	}
	local v821
	if v_u_814 then
		v821 = Enum.AutomaticSize.Y
	else
		v821 = Enum.AutomaticSize.X
	end
	v820.AutomaticCanvasSize = v821
	local v822
	if v_u_814 then
		v822 = Enum.ScrollingDirection.Y
	else
		v822 = Enum.ScrollingDirection.X
	end
	v820.ScrollingDirection = v822
	v820.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
	local v_u_823 = Instance.new("ScrollingFrame")
	if v820 then
		for v824, v825 in v820 do
			v_u_823[v824] = v825
		end
	end
	if v817 then
		v_u_823.Parent = v817
	end
	v_u_12.layout(v_u_823, v_u_814 and "v" or "h", v_u_814 and 2 or v_u_7.space.l)
	local v_u_826 = p_u_813.selected
	local v_u_827 = {}
	local v_u_828 = {}
	local function v_u_843() -- name: paint
		-- upvalues: (copy) v_u_827, (ref) v_u_826, (ref) v_u_10, (copy) v_u_814, (ref) v_u_12
		for v829, v830 in v_u_827 do
			local v831 = v829 == v_u_826
			if v831 then
				v830.lbl.TextColor3 = v_u_10.text
				v830.line.BackgroundColor3 = v_u_10.accent
				local v832 = v830.line
				local v833
				if v_u_814 then
					v833 = UDim2.new(0, 2, 1, 0)
				else
					v833 = UDim2.new(1, 0, 0, 2)
				end
				v832.Size = v833
			end
			local v834 = v_u_12.tween
			local v835 = v830.lbl
			local v836 = {}
			local v837
			if v831 then
				v837 = v_u_10.text
			elseif v830.hover then
				v837 = v_u_10.text
			else
				v837 = v_u_10.text2
			end
			v836.TextColor3 = v837
			v834(v835, v836, "fast")
			local v838 = v_u_12.tween
			local v839 = v830.line
			local v840 = {}
			local v841
			if v_u_814 then
				v841 = UDim2.new(0, 2, (v831 or v830.hover) and 1 or 0, 0)
			else
				v841 = UDim2.new((v831 or v830.hover) and 1 or 0, 0, 0, 2)
			end
			v840.Size = v841
			local v842
			if v831 then
				v842 = v_u_10.accent
			else
				v842 = v_u_10.lineStrong
			end
			v840.BackgroundColor3 = v842
			v838(v839, v840, v830.hover and not v831 and "slow" or "fast")
			v830.btn.BackgroundTransparency = v_u_814 and v831 and 0.4 or 1
		end
	end
	function v_u_828.select(p844, p845) -- name: select
		-- upvalues: (copy) v_u_827, (ref) v_u_826, (copy) v_u_843, (ref) v_u_12, (ref) v_u_7, (copy) p_u_813
		if v_u_827[p844] then
			local v846 = v_u_826 ~= p844
			v_u_826 = p844
			v_u_843()
			if v846 then
				v_u_12.hideTooltip()
			end
			if v846 and not p845 then
				v_u_12.sound(v_u_7.sounds.tab)
				if p_u_813.onChange then
					task.spawn(p_u_813.onChange, p844)
				end
			end
		end
	end
	function v_u_828.get() -- name: get
		-- upvalues: (ref) v_u_826
		return v_u_826
	end
	local v_u_847 = v_u_826
	for v848, v_u_849 in p_u_813.tabs or {} do
		local v850 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Name"] = "Tab_" .. v_u_849.id,
			["BackgroundColor3"] = v_u_10.accentDeep,
			["LayoutOrder"] = v848
		}
		local v851
		if v_u_814 then
			v851 = UDim2.new(1, 0, 0, v_u_7.touch(40))
		else
			v851 = UDim2.new(0, v_u_7.touch(24), 1, 0)
		end
		v850.Size = v851
		local v852
		if v_u_814 then
			v852 = Enum.AutomaticSize.None
		else
			v852 = Enum.AutomaticSize.X
		end
		v850.AutomaticSize = v852
		local v853 = Instance.new("TextButton")
		if v850 then
			for v854, v855 in v850 do
				v853[v854] = v855
			end
		end
		if v_u_823 then
			v853.Parent = v_u_823
		end
		local v856 = {
			["Name"] = "Text",
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Text"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["AutomaticSize"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["FontFace"] = v_u_7.font.heading,
			["TextSize"] = v_u_814 and 16 or 17,
			["TextColor3"] = v_u_10.text2,
			["Text"] = v_u_7.track(string.upper(v_u_849.text or v_u_849.id), 1)
		}
		local v857
		if v_u_814 then
			v857 = UDim2.new(1, -16, 1, 0)
		else
			v857 = UDim2.new(0, 0, 1, 0)
		end
		v856.Size = v857
		local v858
		if v_u_814 then
			v858 = UDim2.fromOffset(16, 0)
		else
			v858 = UDim2.new()
		end
		v856.Position = v858
		local v859
		if v_u_814 then
			v859 = Enum.AutomaticSize.None
		else
			v859 = Enum.AutomaticSize.X
		end
		v856.AutomaticSize = v859
		v856.TextXAlignment = Enum.TextXAlignment.Left
		v856.TextTruncate = Enum.TextTruncate.AtEnd
		local v860 = Instance.new("TextLabel")
		if v856 then
			for v861, v862 in v856 do
				v860[v861] = v862
			end
		end
		if v853 then
			v860.Parent = v853
		end
		if not v_u_814 then
			v_u_12.pad(v853, {
				2,
				2,
				0,
				0
			})
		end
		local v863 = {
			["Name"] = "Line",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.accent
		}
		local v864
		if v_u_814 then
			v864 = Vector2.new(0, 0.5)
		else
			v864 = Vector2.new(0, 1)
		end
		v863.AnchorPoint = v864
		local v865
		if v_u_814 then
			v865 = UDim2.fromScale(0, 0.5)
		else
			v865 = UDim2.fromScale(0, 1)
		end
		v863.Position = v865
		local v866
		if v_u_814 then
			v866 = UDim2.new(0, 2, 0, 0)
		else
			v866 = UDim2.new(0, 0, 0, 2)
		end
		v863.Size = v866
		local v867 = Instance.new("Frame")
		if v863 then
			for v868, v869 in v863 do
				v867[v868] = v869
			end
		end
		if v853 then
			v867.Parent = v853
		end
		local v_u_870 = {
			["btn"] = nil,
			["lbl"] = nil,
			["line"] = nil,
			["hover"] = false,
			["btn"] = v853,
			["lbl"] = v860,
			["line"] = v867
		}
		v_u_827[v_u_849.id] = v_u_870
		v853.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_870, (copy) v_u_849, (ref) v_u_847, (ref) v_u_12, (ref) v_u_7, (copy) v_u_843
			v_u_870.hover = true
			if v_u_849.id ~= v_u_847 then
				v_u_12.sound(v_u_7.sounds.hover)
			end
			v_u_843()
		end)
		v853.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_870, (copy) v_u_843
			v_u_870.hover = false
			v_u_843()
		end)
		v853.SelectionImageObject = v_u_12.selectionImage()
		v853.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_870, (copy) v_u_843
			v_u_870.hover = true
			v_u_843()
		end)
		v853.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_870, (copy) v_u_843
			v_u_870.hover = false
			v_u_843()
		end)
		v853.Activated:Connect(function()
			-- upvalues: (copy) v_u_828, (copy) v_u_849
			v_u_828.select(v_u_849.id)
		end)
	end
	if not v_u_847 and (p_u_813.tabs and p_u_813.tabs[1]) then
		v_u_826 = p_u_813.tabs[1].id
	end
	v_u_843()
	if not v_u_814 then
		local v_u_871 = v_u_12.icon("chevronLeft", {
			["parent"] = nil,
			["size"] = 12,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 5,
			["parent"] = v817,
			["color"] = v_u_10.text2,
			["position"] = UDim2.new(0, 8, 0.5, 0),
			["anchor"] = Vector2.new(0.5, 0.5)
		})
		local v_u_872 = v_u_12.icon("chevronRight", {
			["parent"] = nil,
			["size"] = 12,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 5,
			["parent"] = v817,
			["color"] = v_u_10.text2,
			["position"] = UDim2.new(1, -8, 0.5, 0),
			["anchor"] = Vector2.new(0.5, 0.5)
		})
		v_u_871.Name = "MoreLeft"
		v_u_872.Name = "MoreRight"
		v_u_871.Visible = false
		v_u_872.Visible = false
		local v_u_873 = false
		local function v880() -- name: sync
			-- upvalues: (copy) v_u_823, (ref) v_u_873, (copy) v_u_871, (copy) v_u_872
			if v_u_823.Parent then
				local v874 = v_u_823.AbsoluteCanvasSize.X
				local v875 = v_u_823.AbsoluteWindowSize.X
				if v875 > 0 and v875 + 1 < v874 then
					if not v_u_873 then
						v_u_873 = true
						v_u_823.Position = UDim2.fromOffset(16, 0)
						v_u_823.Size = UDim2.new(1, -32, 1, 0)
					end
				elseif v_u_873 and v874 <= v875 + 1 then
					v_u_873 = false
					v_u_823.Position = UDim2.new()
					v_u_823.Size = UDim2.fromScale(1, 1)
				end
				local v876 = v_u_871
				local v877 = v_u_873
				if v877 then
					v877 = v_u_823.CanvasPosition.X > 1
				end
				v876.Visible = v877
				local v878 = v_u_872
				local v879 = v_u_873
				if v879 then
					v879 = v_u_823.CanvasPosition.X + v_u_823.AbsoluteWindowSize.X < v_u_823.AbsoluteCanvasSize.X - 1
				end
				v878.Visible = v879
			end
		end
		v_u_823:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v880)
		v_u_823:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v880)
		v_u_823:GetPropertyChangedSignal("CanvasPosition"):Connect(v880)
		task.defer(v880)
	end
	v_u_167(v817, p_u_813)
	if p_u_813.parent then
		v817.Parent = p_u_813.parent
	end
	return v817, v_u_828
end
function v_u_12.list(p881) -- name: list
	-- upvalues: (copy) v_u_7, (copy) v_u_10, (copy) v_u_12, (copy) v_u_167
	local v882 = p881 or {}
	local v883 = v882.horizontal == true
	local v884 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.2,
		["VerticalScrollBarInset"] = nil,
		["HorizontalScrollBarInset"] = nil,
		["ElasticBehavior"] = nil,
		["TopImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
		["BottomImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
		["Name"] = v882.name or "List",
		["Size"] = v882.size or UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new()
	}
	local v885
	if v883 then
		v885 = Enum.AutomaticSize.X
	else
		v885 = Enum.AutomaticSize.Y
	end
	v884.AutomaticCanvasSize = v885
	local v886
	if v883 then
		v886 = Enum.ScrollingDirection.X
	else
		v886 = Enum.ScrollingDirection.Y
	end
	v884.ScrollingDirection = v886
	v884.ScrollBarThickness = v_u_7.scrollBar
	v884.ScrollBarImageColor3 = v_u_10.lineStrong
	local v887
	if v883 or v882.padding ~= nil then
		v887 = Enum.ScrollBarInset.ScrollBar
	else
		v887 = Enum.ScrollBarInset.None
	end
	v884.VerticalScrollBarInset = v887
	v884.HorizontalScrollBarInset = Enum.ScrollBarInset.ScrollBar
	v884.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
	local v888 = Instance.new("ScrollingFrame")
	if v884 then
		for v889, v890 in v884 do
			v888[v889] = v890
		end
	end
	v_u_12.layout(v888, v883 and "h" or "v", v882.gap or v_u_7.space.xs)
	if v882.padding ~= false then
		v_u_12.pad(v888, v882.padding or {
			0,
			v883 and 0 or 6,
			0,
			v883 and 6 or 0
		})
	end
	v_u_167(v888, v882)
	if v882.parent then
		v888.Parent = v882.parent
	end
	return v888
end
local v_u_891 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_892 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_900(p893, p894) -- name: relPath
	local v895 = {}
	while p894 and p894 ~= p893 do
		local v896 = p894.Parent
		if not v896 then
			return nil
		end
		local v897 = 0
		for _, v898 in v896:GetChildren() do
			if v898.Name == p894.Name then
				v897 = v897 + 1
			end
			if v898 ~= p894 then
				continue
			end
		end
		local v899 = p894.Name .. "#" .. v897
		table.insert(v895, 1, v899)
		p894 = v896
	end
	if p894 == p893 then
		return table.concat(v895, "/")
	else
		return nil
	end
end
local function v_u_904(p_u_901, p_u_902) -- name: holdScroll
	-- upvalues: (copy) v_u_891
	v_u_891[p_u_901] = p_u_902
	p_u_901.CanvasPosition = p_u_902
	local v_u_903 = p_u_901:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(function()
		-- upvalues: (ref) v_u_891, (copy) p_u_901, (copy) p_u_902
		if v_u_891[p_u_901] == p_u_902 then
			p_u_901.CanvasPosition = p_u_902
		end
	end)
	task.delay(0.6, function()
		-- upvalues: (copy) v_u_903, (ref) v_u_891, (copy) p_u_901, (copy) p_u_902
		v_u_903:Disconnect()
		if v_u_891[p_u_901] == p_u_902 then
			v_u_891[p_u_901] = nil
		end
	end)
end
function v_u_12.keepScroll(p_u_905, p906) -- name: keepScroll
	-- upvalues: (copy) v_u_900, (copy) v_u_891, (copy) v_u_5, (copy) v_u_892, (copy) v_u_904, (copy) v_u_2
	local v_u_907 = {}
	local function v911(p908) -- name: scan
		-- upvalues: (copy) p_u_905, (ref) v_u_900
		if p_u_905:IsA("ScrollingFrame") then
			p908(p_u_905, "")
		end
		for _, v909 in p_u_905:GetDescendants() do
			if not v909:IsA("ScrollingFrame") then
				continue
			end
			local v910 = v_u_900(p_u_905, v909)
			if not v910 then
				continue
			end
			p908(v909, v910)
		end
	end
	v911(function(p912, p913)
		-- upvalues: (copy) v_u_907, (ref) v_u_891
		if v_u_907[p913] == nil then
			v_u_907[p913] = v_u_891[p912] or p912.CanvasPosition
		end
	end)
	local v914 = v_u_5.SelectedObject
	local v915
	if v914 and v914:IsDescendantOf(p_u_905) then
		v915 = v_u_900(p_u_905, v914)
	else
		v915 = nil
	end
	local v916 = v_u_892[p_u_905]
	if not v915 and (v916 and v914 == nil) then
		v915 = v916.path
	end
	if v915 then
		v_u_5.SelectedObject = nil
	end
	p906()
	local v_u_917 = {}
	v911(function(p918, p919)
		-- upvalues: (copy) v_u_907, (copy) v_u_917, (ref) v_u_891, (ref) v_u_904
		local v920 = v_u_907[p919]
		if v920 and not v_u_917[p919] then
			v_u_917[p919] = true
			if v920.Magnitude > 0.5 or v_u_891[p918] then
				v_u_904(p918, v920)
			end
		end
	end)
	if v915 then
		if v914 and v914:IsDescendantOf(p_u_905) then
			v_u_892[p_u_905] = nil
			v_u_5.SelectedObject = v914
		else
			local v_u_921 = {
				["path"] = v915
			}
			v_u_892[p_u_905] = v_u_921
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_892, (copy) p_u_905, (copy) v_u_921, (ref) v_u_5
				v_u_2.Heartbeat:Wait()
				v_u_2.Heartbeat:Wait()
				if v_u_892[p_u_905] ~= v_u_921 then
					return
				end
				local v_u_922 = p_u_905
				for v923 in string.gmatch(v_u_921.path, "[^/]+") do
					local v924, v925 = string.match(v923, "^(.*)#(%d+)$")
					local v926 = tonumber(v925) or 1
					v_u_922 = nil
					for _, v927 in v_u_922:GetChildren() do
						if v927.Name ~= v924 then
							continue
						end
						v926 = v926 - 1
						if v926 ~= 0 then
							continue
						end
						v_u_922 = v927
					end
					if v_u_922 then
						break
					end
					return
				end
				if not v_u_922 or (v_u_922 == p_u_905 or not v_u_922:IsA("GuiObject")) then
					v_u_892[p_u_905] = nil
					return
				end
				local function v931() -- name: inView
					-- upvalues: (copy) v_u_922, (ref) p_u_905
					local v928 = v_u_922.Parent
					while v928 and v928 ~= p_u_905.Parent do
						if v928:IsA("ScrollingFrame") then
							local v929 = v928.AbsolutePosition.Y
							local v930 = v_u_922.AbsolutePosition.Y
							if v930 < v929 - 1 or v930 + v_u_922.AbsoluteSize.Y > v929 + v928.AbsoluteWindowSize.Y + 1 then
								return false
							end
						end
						v928 = v928.Parent
					end
					return true
				end
				for _ = 1, 30 do
					if v931() then
						break
					end
					v_u_2.Heartbeat:Wait()
				end
				if v_u_892[p_u_905] == v_u_921 then
					v_u_892[p_u_905] = nil
					if v_u_5.SelectedObject == nil and (v_u_922:IsDescendantOf(p_u_905) and (v_u_922.Selectable and v_u_922.Visible)) then
						v_u_5.SelectedObject = v_u_922
					end
				end
			end)
		end
	else
		return
	end
end
local v_u_932 = {}
local function v_u_938(p933, p934) -- name: overlayScreen
	-- upvalues: (copy) v_u_932, (copy) v_u_12
	local v935 = v_u_932[p933]
	if v935 and v935.gui.Parent then
		return v935.root
	end
	local v936, v937 = v_u_12.screen(p933, p934, {
		["insets"] = "None"
	})
	v_u_932[p933] = {
		["gui"] = v936,
		["root"] = v937
	}
	return v937
end
local v_u_939 = nil
local v_u_940 = nil
local v_u_941 = nil
local function v_u_944(p942) -- name: shownOnScreen
	while p942 do
		if p942:IsA("GuiObject") then
			if not p942.Visible then
				return false
			end
		elseif p942:IsA("LayerCollector") then
			local v943 = p942.Enabled
			if v943 then
				v943 = p942.Parent ~= nil
			end
			return v943
		end
		p942 = p942.Parent
	end
	return false
end
local function v_u_951(p945, p946) -- name: mouseOver
	-- upvalues: (copy) v_u_12
	local v947 = v_u_12.pointer().mouseAbs()
	local v948 = p945.AbsolutePosition
	local v949 = p945.AbsoluteSize
	local v950
	if v947.X >= v948.X - p946 and (v947.Y >= v948.Y - p946 and v947.X <= v948.X + v949.X + p946) then
		v950 = v947.Y <= v948.Y + v949.Y + p946
	else
		v950 = false
	end
	return v950
end
local function v_u_953() -- name: usingMouse
	-- upvalues: (copy) v_u_4
	local v952 = v_u_4:GetLastInputType()
	return (v952 == Enum.UserInputType.MouseMovement or (v952 == Enum.UserInputType.MouseButton1 or (v952 == Enum.UserInputType.MouseButton2 or (v952 == Enum.UserInputType.MouseButton3 or v952 == Enum.UserInputType.MouseWheel)))) and true or v952 == Enum.UserInputType.Keyboard
end
function v_u_12.hideTooltip() -- name: hideTooltip
	-- upvalues: (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
	v_u_940 = nil
	if v_u_941 then
		v_u_941:Disconnect()
		v_u_941 = nil
	end
	if v_u_939 then
		v_u_939.Visible = false
	end
end
function v_u_12.tooltipOwner() -- name: tooltipOwner
	-- upvalues: (ref) v_u_939, (ref) v_u_940
	if v_u_939 and (v_u_939.Visible and v_u_939.Parent) then
		return v_u_940
	else
		return nil
	end
end
local function v_u_959(p954, p955, p956, p957) -- name: tipText
	-- upvalues: (copy) v_u_12
	local v958 = tostring(p955)
	if #v958 > 32 or string.find(v958, "\n", 1, true) then
		v_u_12.label({
			["parent"] = nil,
			["name"] = "TipText",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["size"] = nil,
			["maxSize"] = nil,
			["order"] = nil,
			["parent"] = p954,
			["text"] = v958,
			["color"] = p956,
			["size"] = UDim2.fromOffset(296, 0),
			["maxSize"] = Vector2.new(296, 600),
			["order"] = p957
		})
	else
		v_u_12.label({
			["parent"] = nil,
			["name"] = "TipText",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["autoX"] = true,
			["maxSize"] = nil,
			["order"] = nil,
			["parent"] = p954,
			["text"] = v958,
			["color"] = p956,
			["maxSize"] = Vector2.new(296, 30),
			["order"] = p957
		})
	end
end
local function v_u_962() -- name: contextMenuOpen
	-- upvalues: (copy) v_u_1
	local v960 = v_u_1.LocalPlayer
	if v960 then
		v960 = v960:FindFirstChildOfClass("PlayerGui")
	end
	if v960 then
		v960 = v960:FindFirstChild("HushInventoryOverlay")
	end
	if v960 then
		v960 = v960:FindFirstChild("ContextMenu", true)
	end
	local v961 = v960 ~= nil and v960:IsA("GuiObject")
	if v961 then
		v961 = v960.Visible
	end
	return v961
end
local function v_u_1010(p_u_963, p964, p_u_965, p_u_966) -- name: showTip
	-- upvalues: (copy) v_u_962, (copy) v_u_944, (copy) v_u_953, (copy) v_u_951, (copy) v_u_938, (copy) v_u_7, (ref) v_u_939, (copy) v_u_10, (copy) v_u_12, (copy) v_u_959, (ref) v_u_940, (ref) v_u_941, (copy) v_u_2
	if p964 == nil or p964 == "" then
		return
	elseif v_u_962() then
		return
	elseif v_u_944(p_u_963) then
		if p_u_965 ~= nil or (not v_u_953() or v_u_951(p_u_963, 2)) then
			local v_u_967 = v_u_938("HushTooltip", v_u_7.layer.tooltip)
			if v_u_939 then
				v_u_939:Destroy()
			end
			local v968 = {
				["Name"] = "Tooltip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.02,
				["BorderSizePixel"] = 0,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["ZIndex"] = 10,
				["BackgroundColor3"] = v_u_10.raised,
				["AutomaticSize"] = Enum.AutomaticSize.XY,
				["Size"] = UDim2.fromOffset(0, 0)
			}
			local v969 = Instance.new("Frame")
			if v968 then
				for v970, v971 in v968 do
					v969[v970] = v971
				end
			end
			if v_u_967 then
				v969.Parent = v_u_967
			end
			v_u_12.stroke(v969, v_u_10.lineStrong)
			local v972 = {
				["Name"] = "Accent",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 11,
				["BackgroundColor3"] = v_u_10.accent,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}
			local v973 = Instance.new("Frame")
			if v972 then
				for v974, v975 in v972 do
					v973[v974] = v975
				end
			end
			if v969 then
				v973.Parent = v969
			end
			local v976 = {
				["Name"] = "Body",
				["BackgroundTransparency"] = 1,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["ZIndex"] = 10,
				["AutomaticSize"] = Enum.AutomaticSize.XY,
				["Size"] = UDim2.fromOffset(0, 0)
			}
			local v977 = Instance.new("Frame")
			if v976 then
				for v978, v979 in v976 do
					v977[v978] = v979
				end
			end
			if v969 then
				v977.Parent = v969
			end
			v_u_12.pad(v977, {
				12,
				12,
				8,
				10
			})
			v_u_12.layout(v977, "v", 4)
			local v980 = v_u_12.safeInsets()
			local v981 = {}
			local v982 = Vector2.new
			local v983 = v_u_7.refSize().Y - v980.t - v980.b - 16
			local v984 = math.max(120, v983)
			v981.MaxSize = v982(320, (math.min(600, v984)))
			local v985 = Instance.new("UISizeConstraint")
			local v986
			if v981 then
				v986 = v977
				for v987, v988 in v981 do
					v985[v987] = v988
				end
			else
				v986 = v977
			end
			if v977 then
				v985.Parent = v977
			end
			local v989 = v_u_10.accent
			if type(p964) == "string" then
				v_u_959(v986, p964, v_u_10.text, nil)
			else
				v989 = p964.color or v_u_10.accent
				if p964.title then
					v_u_12.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "h3",
						["autoX"] = true,
						["maxSize"] = nil,
						["order"] = 1,
						["parent"] = v986,
						["text"] = p964.title,
						["maxSize"] = Vector2.new(296, 30)
					})
				end
				if p964.body then
					v_u_959(v986, p964.body, nil, 2)
				end
				for v990, v991 in p964.lines or {} do
					local v992 = {
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.fromOffset(280, 18),
						["LayoutOrder"] = 10 + v990
					}
					local v993 = Instance.new("Frame")
					local v994
					if v992 then
						v994 = v986
						for v995, v996 in v992 do
							v993[v995] = v996
						end
					else
						v994 = v986
					end
					if v986 then
						v993.Parent = v986
					end
					local v997 = v991.wide == true and 0.42 or 0.6
					v_u_12.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["size"] = nil,
						["parent"] = v993,
						["text"] = v991[1] or (v991.label or ""),
						["size"] = UDim2.new(v997, 0, 1, 0)
					})
					local v998 = v_u_12.label
					local v999 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "monoS",
						["color"] = nil,
						["align"] = "right",
						["size"] = nil,
						["position"] = nil,
						["parent"] = v993
					}
					local v1000 = v991[2] or (v991.value or "")
					v999.text = tostring(v1000)
					v999.color = v991[3] or (v991.color or v_u_10.text)
					v999.size = UDim2.new(1 - v997, 0, 1, 0)
					v999.position = UDim2.fromScale(v997, 0)
					v998(v999)
					v986 = v994
				end
			end
			v973.BackgroundColor3 = v989
			local v_u_1001 = v969
			v_u_939 = v969
			v_u_940 = p_u_963
			local function v_u_1006() -- name: place
				-- upvalues: (ref) v_u_1001, (ref) v_u_7, (copy) p_u_966, (ref) v_u_12, (copy) p_u_965, (copy) v_u_967
				if v_u_1001.Parent then
					local v1002 = v_u_7.refSize()
					local v1003 = v_u_1001.AbsoluteSize / v_u_7.uiScale()
					local v1004
					if p_u_966 then
						v1004 = v_u_12.placeAround(v1003, p_u_966, v1002, v_u_12.safeInsets())
					else
						local v1005
						if p_u_965 then
							v1005 = p_u_965
						else
							v1005 = v_u_12.mouseIn(v_u_967)
						end
						v1004 = v_u_12.placeTip(v1005, v1003, v1002, v_u_12.safeInsets())
					end
					v_u_1001.Position = UDim2.fromOffset(v1004.X, v1004.Y)
				end
			end
			v_u_1006()
			v_u_12.fade(v_u_1001, 0, "fast", {
				["from"] = 1
			})
			if v_u_941 then
				v_u_941:Disconnect()
			end
			local v_u_1007 = 0
			v_u_941 = v_u_2.Heartbeat:Connect(function()
				-- upvalues: (copy) p_u_963, (ref) v_u_944, (ref) v_u_962, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939, (copy) p_u_965, (ref) v_u_953, (ref) v_u_951, (ref) v_u_1007, (copy) v_u_1006
				if p_u_963.Parent and (v_u_944(p_u_963) and not v_u_962()) then
					if p_u_965 == nil and v_u_953() then
						if v_u_951(p_u_963, 4) then
							v_u_1007 = 0
						else
							v_u_1007 = v_u_1007 + 1
							if v_u_1007 >= 4 then
								local v1008 = p_u_963
								if not v1008 or v_u_940 == v1008 then
									v_u_940 = nil
									if v_u_941 then
										v_u_941:Disconnect()
										v_u_941 = nil
									end
									if v_u_939 then
										v_u_939.Visible = false
									end
								end
							end
						end
					end
					v_u_1006()
					return
				else
					local v1009 = p_u_963
					if not v1009 or v_u_940 == v1009 then
						v_u_940 = nil
						if v_u_941 then
							v_u_941:Disconnect()
							v_u_941 = nil
						end
						if v_u_939 then
							v_u_939.Visible = false
						end
					end
				end
			end)
		end
	else
		return
	end
end
v_u_12._tipFns = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_12.showTooltip(p1011) -- name: showTooltip
	-- upvalues: (copy) v_u_12, (copy) v_u_1010
	local v1012 = v_u_12._tipFns[p1011]
	if not v1012 then
		return false
	end
	local v1013, v1014 = pcall(v1012)
	if not v1013 or v1014 == nil then
		return false
	end
	local v1015 = v_u_12.absToOverlay(p1011.AbsolutePosition)
	local v1016 = v_u_12.absToOverlay(p1011.AbsolutePosition + p1011.AbsoluteSize)
	v_u_1010(p1011, v1014, v1016, {
		["x0"] = v1015.X,
		["y0"] = v1015.Y,
		["x1"] = v1016.X,
		["y1"] = v1016.Y
	})
	return v_u_12.tooltipOwner() == p1011
end
function v_u_12.tooltip(p_u_1017, p_u_1018) -- name: tooltip
	-- upvalues: (copy) v_u_12, (copy) v_u_1010, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
	v_u_12._tipFns[p_u_1017] = p_u_1018
	local v_u_1019 = {}
	local v_u_1020 = 0
	local v1021 = p_u_1017.MouseEnter
	local function v1026()
		-- upvalues: (ref) v_u_1020, (copy) p_u_1017, (copy) p_u_1018, (ref) v_u_1010
		v_u_1020 = v_u_1020 + 1
		local v_u_1022 = v_u_1020
		task.delay(0.35, function()
			-- upvalues: (copy) v_u_1022, (ref) v_u_1020, (ref) p_u_1017, (ref) p_u_1018, (ref) v_u_1010
			if v_u_1022 == v_u_1020 and p_u_1017.Parent then
				local v1023 = p_u_1018
				local v1024, v1025 = pcall(v1023)
				if v1024 then
					v_u_1010(p_u_1017, v1025)
				end
			end
		end)
	end
	table.insert(v_u_1019, v1021:Connect(v1026))
	local v1027 = p_u_1017.MouseLeave
	local function v1029()
		-- upvalues: (ref) v_u_1020, (copy) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
		v_u_1020 = v_u_1020 + 1
		local v1028 = p_u_1017
		if not v1028 or v_u_940 == v1028 then
			v_u_940 = nil
			if v_u_941 then
				v_u_941:Disconnect()
				v_u_941 = nil
			end
			if v_u_939 then
				v_u_939.Visible = false
			end
		end
	end
	table.insert(v_u_1019, v1027:Connect(v1029))
	local v1030 = p_u_1017.InputBegan
	local function v1033(p1031)
		-- upvalues: (ref) v_u_1020, (copy) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
		if p1031.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_1020 = v_u_1020 + 1
			local v1032 = p_u_1017
			if v1032 and v_u_940 ~= v1032 then
				return
			end
			v_u_940 = nil
			if v_u_941 then
				v_u_941:Disconnect()
				v_u_941 = nil
			end
			if v_u_939 then
				v_u_939.Visible = false
			end
		end
	end
	table.insert(v_u_1019, v1030:Connect(v1033))
	local v1034 = p_u_1017.InputBegan
	local function v1042(p1035)
		-- upvalues: (ref) v_u_1020, (copy) p_u_1017, (copy) p_u_1018, (ref) v_u_12, (ref) v_u_1010
		if p1035.UserInputType == Enum.UserInputType.Touch then
			v_u_1020 = v_u_1020 + 1
			local v_u_1036 = v_u_1020
			task.delay(0.45, function()
				-- upvalues: (copy) v_u_1036, (ref) v_u_1020, (ref) p_u_1017, (ref) p_u_1018, (ref) v_u_12, (ref) v_u_1010
				if v_u_1036 == v_u_1020 and p_u_1017.Parent then
					local v1037 = p_u_1018
					local v1038, v1039 = pcall(v1037)
					if v1038 then
						local v1040 = v_u_12.absToOverlay(p_u_1017.AbsolutePosition)
						local v1041 = v_u_12.absToOverlay(p_u_1017.AbsolutePosition + p_u_1017.AbsoluteSize)
						v_u_1010(p_u_1017, v1039, v1040, {
							["x0"] = v1040.X,
							["y0"] = v1040.Y,
							["x1"] = v1041.X,
							["y1"] = v1041.Y
						})
					end
				end
			end)
		end
	end
	table.insert(v_u_1019, v1034:Connect(v1042))
	local v1043 = p_u_1017.InputEnded
	local function v1046(p1044)
		-- upvalues: (ref) v_u_1020, (copy) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
		if p1044.UserInputType == Enum.UserInputType.Touch then
			v_u_1020 = v_u_1020 + 1
			task.delay(0.8, function()
				-- upvalues: (ref) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
				local v1045 = p_u_1017
				if not v1045 or v_u_940 == v1045 then
					v_u_940 = nil
					if v_u_941 then
						v_u_941:Disconnect()
						v_u_941 = nil
					end
					if v_u_939 then
						v_u_939.Visible = false
					end
				end
			end)
		end
	end
	table.insert(v_u_1019, v1043:Connect(v1046))
	local v1047 = p_u_1017.Destroying
	local function v1049()
		-- upvalues: (copy) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
		local v1048 = p_u_1017
		if not v1048 or v_u_940 == v1048 then
			v_u_940 = nil
			if v_u_941 then
				v_u_941:Disconnect()
				v_u_941 = nil
			end
			if v_u_939 then
				v_u_939.Visible = false
			end
		end
	end
	table.insert(v_u_1019, v1047:Connect(v1049))
	return function()
		-- upvalues: (copy) v_u_1019, (copy) p_u_1017, (ref) v_u_940, (ref) v_u_941, (ref) v_u_939
		for _, v1050 in v_u_1019 do
			v1050:Disconnect()
		end
		local v1051 = p_u_1017
		if not v1051 or v_u_940 == v1051 then
			v_u_940 = nil
			if v_u_941 then
				v_u_941:Disconnect()
				v_u_941 = nil
			end
			if v_u_939 then
				v_u_939.Visible = false
			end
		end
	end
end
local v_u_1052 = 0
local v_u_1053 = nil
function v_u_12.blur(p1054, p1055) -- name: blur
	-- upvalues: (ref) v_u_1052, (ref) v_u_1053, (copy) v_u_12
	local v1056 = v_u_1052 + (p1054 and 1 or -1)
	v_u_1052 = math.max(0, v1056)
	local v1057 = workspace.CurrentCamera
	if v1057 then
		if not (v_u_1053 and v_u_1053.Parent) then
			v_u_1053 = v1057:FindFirstChild("HushUIBlur")
			if not v_u_1053 then
				local v1058 = {
					["Name"] = "HushUIBlur",
					["Size"] = 0
				}
				local v1059 = Instance.new("BlurEffect")
				if v1058 then
					for v1060, v1061 in v1058 do
						v1059[v1060] = v1061
					end
				end
				if v1057 then
					v1059.Parent = v1057
				end
				v_u_1053 = v1059
			end
		end
		local v1062 = v_u_1053
		if v1062.Parent ~= v1057 then
			v1062.Parent = v1057
		end
		v_u_12.tween(v1062, {
			["Size"] = v_u_1052 <= 0 and 0 or math.min(12, p1055 or 12)
		}, "slow")
	end
end
local v_u_1063 = {}
local v_u_1064 = nil
local function v_u_1067() -- name: topModal
	-- upvalues: (copy) v_u_1063
	for v1065 = #v_u_1063, 1, -1 do
		local v1066 = v_u_1063[v1065]
		if v1066.frame.Parent ~= nil then
			return v1066
		end
		table.remove(v_u_1063, v1065)
	end
	return nil
end
local function v_u_1071(p1068) -- name: focusModal
	-- upvalues: (copy) v_u_12, (copy) v_u_1067, (copy) v_u_5
	if v_u_12.device() == "Gamepad" then
		local v1069 = nil
		for _, v1070 in p1068.frame:GetDescendants() do
			if not v1070:IsA("GuiButton") or (not v1070.Selectable or v1070:GetAttribute("PadDefault") ~= true) then
				continue
			end
			v1069 = v1070
		end
		if v1069 and v_u_1067() == p1068 then
			v_u_5.SelectedObject = v1069
		end
	end
end
function v_u_12.modalCount() -- name: modalCount
	-- upvalues: (copy) v_u_1067, (copy) v_u_1063
	return v_u_1067() and #v_u_1063 or 0
end
function v_u_12.modal(p_u_1072) -- name: modal
	-- upvalues: (ref) v_u_940, (ref) v_u_941, (ref) v_u_939, (copy) v_u_938, (copy) v_u_7, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_1063, (copy) v_u_2, (copy) v_u_1067, (copy) v_u_5, (copy) v_u_1071, (ref) v_u_1064
	v_u_940 = nil
	if v_u_941 then
		v_u_941:Disconnect()
		v_u_941 = nil
	end
	if v_u_939 then
		v_u_939.Visible = false
	end
	local v1073 = v_u_938("HushModal", v_u_7.layer.modal)
	local v1074 = v_u_12.modalCount()
	v_u_12.blur(true)
	v_u_12.sound(v_u_7.sounds.open)
	local v1075 = p_u_1072.dismissable ~= false
	local v1076 = {
		["Name"] = "Catcher",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Modal"] = true,
		["Selectable"] = false,
		["ZIndex"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["ZIndex"] = 1 + v1074 * 2
	}
	local v_u_1077 = Instance.new("TextButton")
	if v1076 then
		for v1078, v1079 in v1076 do
			v_u_1077[v1078] = v1079
		end
	end
	if v1073 then
		v_u_1077.Parent = v1073
	end
	local v1080 = v_u_12.safeInsets()
	local v1081, v_u_1082 = v_u_12.modalLimits(p_u_1072.width or 520, v_u_7.refSize(), v1080)
	local v1083 = UDim2.new(0.5, (v1080.l - v1080.r) / 2, 0.5, (v1080.t - v1080.b) / 2)
	local v_u_1084 = v1083 + UDim2.fromOffset(0, v_u_11.slide)
	local v1085
	if p_u_1072.buttons == nil then
		v1085 = false
	else
		v1085 = #p_u_1072.buttons > 0
	end
	local v1086 = {
		["Name"] = "Modal",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.02,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = nil,
		["BackgroundColor3"] = v_u_10.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = v1083,
		["Size"] = UDim2.fromOffset(v1081, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["ZIndex"] = 2 + v1074 * 2
	}
	local v_u_1087 = Instance.new("Frame")
	if v1086 then
		for v1088, v1089 in v1086 do
			v_u_1087[v1088] = v1089
		end
	end
	if v1073 then
		v_u_1087.Parent = v1073
	end
	v_u_12.stroke(v_u_1087, v_u_10.lineStrong)
	local v1090 = {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 5
	}
	local v1091
	if p_u_1072.kind == "danger" then
		v1091 = v_u_10.danger
	else
		v1091 = v_u_10.accent
	end
	v1090.BackgroundColor3 = v1091
	v1090.Size = UDim2.new(1, 0, 0, 2)
	local v1092 = Instance.new("Frame")
	if v1090 then
		for v1093, v1094 in v1090 do
			v1092[v1093] = v1094
		end
	end
	if v_u_1087 then
		v1092.Parent = v_u_1087
	end
	local v1095 = {
		["Name"] = "Stack",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	local v_u_1096 = Instance.new("Frame")
	if v1095 then
		for v1097, v1098 in v1095 do
			v_u_1096[v1097] = v1098
		end
	end
	if v_u_1087 then
		v_u_1096.Parent = v_u_1087
	end
	local v_u_1099 = v_u_12.layout(v_u_1096, "v", 0)
	local v1100 = {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.2,
		["VerticalScrollBarInset"] = nil,
		["ElasticBehavior"] = nil,
		["TopImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
		["BottomImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
		["LayoutOrder"] = 1,
		["ZIndex"] = 2,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ScrollBarThickness"] = v_u_7.scrollBar,
		["ScrollBarImageColor3"] = v_u_10.lineStrong,
		["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
		["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
	}
	local v_u_1101 = Instance.new("ScrollingFrame")
	if v1100 then
		for v1102, v1103 in v1100 do
			v_u_1101[v1102] = v1103
		end
	end
	if v_u_1096 then
		v_u_1101.Parent = v_u_1096
	end
	local v_u_1104 = v1085 and 3 or v_u_7.space.l
	local v_u_1105 = v_u_7.space.l
	v_u_12.pad(v_u_1101, {
		v_u_7.space.l,
		v_u_7.space.l,
		v_u_1105,
		v_u_1104
	})
	local v_u_1106 = v_u_12.layout(v_u_1101, "v", v_u_7.space.m)
	local v_u_1107 = not v1085 and 0 or v_u_7.space.m + v_u_7.touch(v_u_7.control) + v_u_7.space.l
	local v_u_1108 = false
	local v_u_1109 = false
	local v_u_1110 = nil
	local function v_u_1117() -- name: sizeBody
		-- upvalues: (copy) v_u_1101, (ref) v_u_12, (copy) v_u_1106, (ref) v_u_1105, (copy) v_u_1104, (ref) v_u_7, (copy) v_u_1082, (copy) v_u_1107, (ref) v_u_1109, (ref) v_u_1110, (ref) v_u_1108
		if v_u_1101.Parent then
			local v1111 = v_u_12.pointer().scaleOf(v_u_1101)
			local v1112 = v_u_1106.AbsoluteContentSize.Y / v1111 + v_u_1105 + v_u_1104
			local v1113 = v1111 / v_u_7.uiScale()
			local v1114 = v_u_1082 / math.max(0.25, v1113)
			local v1115 = math.floor(v1114) - v_u_1107
			if v1115 + 0.5 < v1112 and not v_u_1109 then
				v_u_1109 = true
				v_u_1105 = v_u_7.space.m
				local v1116 = v_u_1101:FindFirstChildOfClass("UIPadding")
				if v1116 then
					v1116.PaddingTop = UDim.new(0, v_u_1105)
				end
				v_u_1106.Padding = UDim.new(0, v_u_7.space.s)
				task.defer(v_u_1110)
			elseif v1115 + 0.5 < v1112 then
				if not v_u_1108 or v_u_1101.Size.Y.Offset ~= v1115 then
					v_u_1108 = true
					v_u_1101.AutomaticSize = Enum.AutomaticSize.None
					v_u_1101.Size = UDim2.new(1, 0, 0, v1115)
					return
				end
			elseif v_u_1108 then
				v_u_1108 = false
				v_u_1101.Size = UDim2.new(1, 0, 0, 0)
				v_u_1101.AutomaticSize = Enum.AutomaticSize.Y
			end
		else
			return
		end
	end
	local v_u_1118 = false
	local v_u_1119 = false
	v_u_1110 = function() -- name: sizeSafe
		-- upvalues: (ref) v_u_1118, (ref) v_u_1119, (ref) v_u_1110, (copy) v_u_1117
		if v_u_1118 then
			if not v_u_1119 then
				v_u_1119 = true
				task.defer(function()
					-- upvalues: (ref) v_u_1119, (ref) v_u_1110
					v_u_1119 = false
					v_u_1110()
				end)
			end
		else
			v_u_1118 = true
			local v1120 = v_u_1117
			local v1121, v1122 = pcall(v1120)
			v_u_1118 = false
			if not v1121 then
				warn("[HushUI] modal size failed:", v1122)
			end
		end
	end
	v_u_1106:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(v_u_1110)
	local v_u_1123 = 0
	local function v_u_1125() -- name: remeasure
		-- upvalues: (copy) v_u_1087, (copy) v_u_1099, (copy) v_u_1096
		if v_u_1087.Parent then
			local v1124 = v_u_1087.AbsoluteSize.Y - v_u_1099.AbsoluteContentSize.Y
			if math.abs(v1124) > 1 then
				v_u_1096.AutomaticSize = Enum.AutomaticSize.None
				v_u_1096.AutomaticSize = Enum.AutomaticSize.Y
				v_u_1087.AutomaticSize = Enum.AutomaticSize.None
				v_u_1087.AutomaticSize = Enum.AutomaticSize.Y
				return
			end
		end
	end
	local function v_u_1129() -- name: remeasureSafe
		-- upvalues: (ref) v_u_1118, (copy) v_u_1125
		if not v_u_1118 then
			v_u_1118 = true
			local v1126 = v_u_1125
			local v1127, v1128 = pcall(v1126)
			v_u_1118 = false
			if not v1127 then
				warn("[HushUI] modal remeasure failed:", v1128)
			end
		end
	end
	v_u_1099:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
		-- upvalues: (ref) v_u_1123, (ref) v_u_1118, (copy) v_u_1125, (copy) v_u_1129
		v_u_1123 = v_u_1123 + 1
		local v_u_1130 = v_u_1123
		task.defer(function()
			-- upvalues: (copy) v_u_1130, (ref) v_u_1123, (ref) v_u_1118, (ref) v_u_1125, (ref) v_u_1129
			if v_u_1130 == v_u_1123 then
				if not v_u_1118 then
					v_u_1118 = true
					local v1131 = v_u_1125
					local v1132, v1133 = pcall(v1131)
					v_u_1118 = false
					if not v1132 then
						warn("[HushUI] modal remeasure failed:", v1133)
					end
				end
				task.delay(0.1, v_u_1129)
			end
		end)
	end)
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h2",
		["order"] = 1,
		["size"] = nil,
		["parent"] = v_u_1101,
		["text"] = p_u_1072.title or "",
		["size"] = UDim2.new(1, 0, 0, 32)
	})
	if p_u_1072.body then
		v_u_12.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v_u_1101,
			["text"] = p_u_1072.body,
			["color"] = v_u_10.text2
		})
	end
	local v1134 = {
		["Name"] = "Content",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 3,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	local v1135 = Instance.new("Frame")
	local v_u_1136
	if v1134 then
		v_u_1136 = v_u_1108
		for v1137, v1138 in v1134 do
			v1135[v1137] = v1138
		end
	else
		v_u_1136 = v_u_1108
	end
	if v_u_1101 then
		v1135.Parent = v_u_1101
	end
	v_u_12.layout(v1135, "v", v_u_7.space.s)
	if p_u_1072.build then
		local v1139 = p_u_1072.build
		local v1140, v1141 = pcall(v1139, v1135)
		if not v1140 then
			warn("[HushUI] modal build failed:", v1141)
		end
	end
	local v_u_1142 = false
	local v_u_1143 = {
		["frame"] = v_u_1087,
		["content"] = v1135,
		["dismissable"] = v1075,
		["body"] = v_u_1101
	}
	local v1144 = v_u_1063
	table.insert(v1144, v_u_1143)
	local v_u_1145 = require(script.Parent:WaitForChild("VirtualPad"))
	local v_u_1150 = v_u_2.Heartbeat:Connect(function(p1146)
		-- upvalues: (ref) v_u_1136, (copy) v_u_1101, (ref) v_u_1067, (copy) v_u_1143, (ref) v_u_12, (copy) v_u_1145
		if v_u_1136 and (v_u_1101.Parent and (v_u_1067() == v_u_1143 and v_u_12.device() == "Gamepad")) then
			local v1147 = 0
			for _, v1148 in v_u_1145.gamepadState() do
				if v1148.KeyCode ~= Enum.KeyCode.Thumbstick2 then
					continue
				end
				v1147 = v1148.Position.Y
			end
			if math.abs(v1147) > 0.2 then
				local v1149 = v_u_1101
				v1149.CanvasPosition = v1149.CanvasPosition + Vector2.new(0, -v1147 * 600 * p1146)
			end
		end
	end)
	v_u_1087.Destroying:Connect(function()
		-- upvalues: (copy) v_u_1150
		v_u_1150:Disconnect()
	end)
	function v_u_1143.close() -- name: close
		-- upvalues: (ref) v_u_1142, (ref) v_u_12, (ref) v_u_1063, (copy) v_u_1143, (ref) v_u_5, (copy) v_u_1087, (ref) v_u_1067, (ref) v_u_1071, (ref) v_u_7, (copy) v_u_1084, (copy) v_u_1077, (copy) p_u_1072
		if not v_u_1142 then
			v_u_1142 = true
			local v1151 = v_u_12
			v1151.modalClosedN = v1151.modalClosedN + 1
			local v1152 = table.find(v_u_1063, v_u_1143)
			if v1152 then
				table.remove(v_u_1063, v1152)
			end
			if v_u_5.SelectedObject and v_u_5.SelectedObject:IsDescendantOf(v_u_1087) then
				v_u_5.SelectedObject = nil
			end
			local v1153 = v_u_1067()
			if v1153 then
				task.defer(v_u_1071, v1153)
			end
			v_u_12.blur(false)
			v_u_12.sound(v_u_7.sounds.close)
			local v1154 = {
				["Position"] = v_u_1084
			}
			v_u_12.tween(v_u_1087, v1154, "fast")
			local v1155 = {
				["onDone"] = function() -- name: onDone
					-- upvalues: (ref) v_u_1087, (ref) v_u_1077
					v_u_1087:Destroy()
					v_u_1077:Destroy()
				end
			}
			v_u_12.fade(v_u_1087, 1, "fast", v1155)
			if p_u_1072.onClose then
				task.spawn(p_u_1072.onClose)
			end
		end
	end
	local v_u_1156
	if v1085 then
		local v1157 = {
			["Name"] = "Footer",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["ZIndex"] = 2,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}
		local v1158 = Instance.new("Frame")
		if v1157 then
			v_u_1156 = v_u_1142
			for v1159, v1160 in v1157 do
				v1158[v1159] = v1160
			end
		else
			v_u_1156 = v_u_1142
		end
		if v_u_1096 then
			v1158.Parent = v_u_1096
		end
		v_u_12.pad(v1158, {
			v_u_7.space.l,
			v_u_7.space.l,
			v_u_7.space.m - 3,
			v_u_7.space.l
		})
		local v1161 = {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_7.touch(v_u_7.control))
		}
		local v1162 = Instance.new("Frame")
		if v1161 then
			for v1163, v1164 in v1161 do
				v1162[v1163] = v1164
			end
		end
		if v1158 then
			v1162.Parent = v1158
		end
		v_u_12.layout(v1162, "h", v_u_7.space.s, "right")
		for v1165, v_u_1166 in p_u_1072.buttons do
			local v1170 = v_u_12.button({
				["parent"] = v1162,
				["text"] = v_u_1166.text,
				["kind"] = v_u_1166.kind or (v1165 == #p_u_1072.buttons and "primary" or "secondary"),
				["hint"] = v_u_1166.hint,
				["order"] = v1165,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_1166, (copy) v_u_1143
					if v_u_1166.onClick then
						local v1167 = v_u_1166.onClick
						local v1168, v1169 = pcall(v1167)
						if v1168 and v1169 == true then
							return
						end
					end
					v_u_1143.close()
				end
			})
			if v1165 ~= #p_u_1072.buttons or not v1170 then
				continue
			end
			v1170:SetAttribute("PadDefault", true)
		end
	else
		v_u_1156 = v_u_1142
	end
	if v1075 then
		v_u_1077.Activated:Connect(v_u_1143.close)
	end
	if v_u_12.device() == "Gamepad" then
		task.defer(function()
			-- upvalues: (ref) v_u_1156, (ref) v_u_1071, (copy) v_u_1143
			if not v_u_1156 then
				v_u_1071(v_u_1143)
			end
		end)
	end
	if not v_u_1064 then
		v_u_1064 = require(script.Parent:WaitForChild("VirtualPad")).InputBegan:Connect(function(p1171)
			-- upvalues: (ref) v_u_1067, (ref) v_u_12
			if p1171.KeyCode == Enum.KeyCode.ButtonB then
				local v1172 = v_u_1067()
				if v1172 then
					v_u_12.takeBack()
					if v1172.dismissable then
						v1172.close()
					end
				end
			end
		end)
	end
	v_u_1087.Position = v_u_1084
	v_u_12.fade(v_u_1087, 0, "slow", {
		["from"] = 1
	})
	v_u_12.tween(v_u_1087, {
		["Position"] = v1083
	}, "slow")
	return v_u_1143
end
local v_u_1173 = nil
v_u_12.compactToasts = false
function v_u_12.toast(p1174, p1175, p1176, p1177) -- name: toast
	-- upvalues: (copy) v_u_938, (copy) v_u_7, (copy) v_u_12, (ref) v_u_1173, (copy) v_u_10
	local v1178 = v_u_938("HushToast", v_u_7.layer.toast)
	local v1179 = v_u_12.device() == "Touch"
	local v1180
	if v1179 then
		v1180 = v_u_12.compactToasts == true
	else
		v1180 = v1179
	end
	local v1181 = v1179 and 320 or 460
	local v1182 = (v1179 and 12 or v_u_12.topInset() + 8) + v_u_12.safeInsets().t
	if not (v_u_1173 and v_u_1173.Parent) then
		local v1183 = {
			["Name"] = "Toasts",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, v1182),
			["Size"] = UDim2.fromOffset(v1181, 400)
		}
		local v1184 = Instance.new("Frame")
		if v1183 then
			for v1185, v1186 in v1183 do
				v1184[v1185] = v1186
			end
		end
		if v1178 then
			v1184.Parent = v1178
		end
		v_u_1173 = v1184
		v_u_12.layout(v_u_1173, "v", 8, "center")
	end
	local v1187 = v_u_1173
	v1187.Size = UDim2.fromOffset(v1181, 400)
	v1187.Position = UDim2.new(0.5, 0, 0, v1182)
	local v1188 = 0
	for _, v1189 in v1187:GetChildren() do
		if v1189.Name ~= "Toast" then
			continue
		end
		v1188 = v1188 + 1
	end
	if v1188 >= 4 then
		local v1190 = (1 / 0)
		local v1191 = nil
		for _, v1192 in v1187:GetChildren() do
			if v1192.Name ~= "Toast" or (not v1192:IsA("GuiObject") or v1192.LayoutOrder >= v1190) then
				continue
			end
			v1190 = v1192.LayoutOrder
			v1191 = v1192
		end
		if v1191 then
			v1191:Destroy()
		end
	end
	local v1193 = v_u_7.kindColor(p1175)
	local v1194 = {
		["Name"] = "Toast",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.06,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_10.bg
	}
	local v1195
	if v1180 then
		v1195 = UDim2.new(1, 0, 0, 0)
	else
		v1195 = UDim2.fromOffset(v1181, 0)
	end
	v1194.Size = v1195
	v1194.AutomaticSize = Enum.AutomaticSize.Y
	local v1196 = os.clock() * 100
	v1194.LayoutOrder = math.floor(v1196) % 100000000
	local v_u_1197 = Instance.new("Frame")
	if v1194 then
		for v1198, v1199 in v1194 do
			v_u_1197[v1198] = v1199
		end
	end
	if v1187 then
		v_u_1197.Parent = v1187
	end
	v_u_12.stroke(v_u_1197, v_u_10.line)
	local v1200 = {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v1193,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}
	local v1201 = Instance.new("Frame")
	if v1200 then
		for v1202, v1203 in v1200 do
			v1201[v1202] = v1203
		end
	end
	if v_u_1197 then
		v1201.Parent = v_u_1197
	end
	local v1204 = {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	local v1205 = Instance.new("Frame")
	if v1204 then
		for v1206, v1207 in v1204 do
			v1205[v1206] = v1207
		end
	end
	if v_u_1197 then
		v1205.Parent = v_u_1197
	end
	v_u_12.pad(v1205, v1180 and {
		28,
		8,
		5,
		5
	} or {
		44,
		14,
		10,
		10
	})
	v_u_12.layout(v1205, "v", v1180 and 0 or 2)
	local v1208 = p1175 == "danger" and "warning" or (p1175 == "success" and "check" or (p1175 == "warn" and "warning" or (p1175 == "infection" and "infection" or "info")))
	local v1209 = v_u_12.icon
	local v1210 = {
		["parent"] = v_u_1197,
		["size"] = v1180 and 14 or 18,
		["color"] = v1193
	}
	local v1211
	if v1180 then
		v1211 = UDim2.new(0, 9, 0, 6)
	else
		v1211 = UDim2.new(0, 16, 0, 12)
	end
	v1210.position = v1211
	v1209(v1208, v1210)
	if v1180 then
		v_u_1197:SetAttribute("Compact", true)
		local v1212 = (not p1176 or p1176 == "") and "" or (string.match(p1176, "^[^%.!%?]+[%.!%?]?") or p1176)
		if v1212 == "" then
			local v1213 = #p1174 * 7.5 > (v_u_12.compactToastWidth or 240) - 40 and 2 or 1
			v_u_12.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 14,
				["wrap"] = true,
				["size"] = nil,
				["order"] = 1,
				["valign"] = "top",
				["parent"] = v1205,
				["text"] = p1174,
				["size"] = UDim2.new(1, 0, 0, v1213 * 18 - (v1213 == 2 and 2 or 0))
			})
		else
			v_u_12.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 14,
				["size"] = nil,
				["order"] = 1,
				["parent"] = v1205,
				["text"] = p1174,
				["size"] = UDim2.new(1, 0, 0, 18)
			})
			v_u_12.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["textSize"] = 12,
				["color"] = nil,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v1205,
				["text"] = v1212,
				["color"] = v_u_10.text2,
				["size"] = UDim2.new(1, 0, 0, 16)
			})
		end
		task.delay(2, function()
			-- upvalues: (copy) v_u_1197, (ref) v_u_12
			if v_u_1197.Parent then
				v_u_12.fade(v_u_1197, 0.5, "slow")
			end
		end)
	else
		v_u_12.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v1205,
			["text"] = p1174
		})
		if p1176 and p1176 ~= "" then
			v_u_12.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["parent"] = v1205,
				["text"] = p1176
			})
		end
	end
	local v1214 = v_u_12.sound
	local v1215
	if p1175 == "danger" then
		v1215 = v_u_7.sounds.error
	else
		v1215 = v_u_7.sounds.toast
	end
	v1214(v1215)
	v_u_12.fade(v_u_1197, 0, "slow", {
		["from"] = 1
	})
	task.delay(not v1180 and (p1177 or 4) or math.min(p1177 or 4, 3), function()
		-- upvalues: (copy) v_u_1197, (ref) v_u_12
		if v_u_1197.Parent then
			local v1216 = {
				["onDone"] = function() -- name: onDone
					-- upvalues: (ref) v_u_1197
					v_u_1197:Destroy()
				end
			}
			v_u_12.fade(v_u_1197, 1, "slow", v1216)
		end
	end)
end
function v_u_12.progress(p1217) -- name: progress
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_167
	local v_u_1218 = p1217.vertical == true
	local v1219 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Name"] = p1217.name or "Progress",
		["BackgroundColor3"] = p1217.bgColor or v_u_10.line,
		["BackgroundTransparency"] = p1217.bgTransparency or 0.2,
		["Size"] = p1217.size or UDim2.new(1, 0, 0, 4)
	}
	local v1220 = Instance.new("Frame")
	if v1219 then
		for v1221, v1222 in v1219 do
			v1220[v1221] = v1222
		end
	end
	local v1223
	if v_u_1218 then
		v1223 = Vector2.new(0, 1)
	else
		v1223 = Vector2.new(0, 0)
	end
	local v1224
	if v_u_1218 then
		v1224 = UDim2.fromScale(0, 1)
	else
		v1224 = UDim2.fromScale(0, 0)
	end
	local v_u_1225
	if p1217.ghost then
		local v1226 = {
			["Name"] = "Ghost",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["BackgroundColor3"] = p1217.ghostColor or v_u_10.text,
			["AnchorPoint"] = v1223,
			["Position"] = v1224
		}
		local v1227 = p1217.value or 1
		local v1228
		if v_u_1218 then
			v1228 = UDim2.fromScale(1, v1227)
		else
			v1228 = UDim2.fromScale(v1227, 1)
		end
		v1226.Size = v1228
		v_u_1225 = Instance.new("Frame")
		if v1226 then
			for v1229, v1230 in v1226 do
				v_u_1225[v1229] = v1230
			end
		end
		if v1220 then
			v_u_1225.Parent = v1220
		end
	else
		v_u_1225 = nil
	end
	local v1231 = {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = p1217.color or v_u_10.accent,
		["AnchorPoint"] = v1223,
		["Position"] = v1224
	}
	local v1232 = p1217.value or 0
	local v1233
	if v_u_1218 then
		v1233 = UDim2.fromScale(1, v1232)
	else
		v1233 = UDim2.fromScale(v1232, 1)
	end
	v1231.Size = v1233
	local v_u_1234 = Instance.new("Frame")
	if v1231 then
		for v1235, v1236 in v1231 do
			v_u_1234[v1235] = v1236
		end
	end
	if v1220 then
		v_u_1234.Parent = v1220
	end
	if p1217.segments and p1217.segments > 1 then
		for v1237 = 1, p1217.segments - 1 do
			local v1238 = {
				["Name"] = "Seg",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_10.bg,
				["AnchorPoint"] = Vector2.new(0.5, 0.5)
			}
			local v1239
			if v_u_1218 then
				v1239 = UDim2.fromScale(0.5, v1237 / p1217.segments)
			else
				v1239 = UDim2.fromScale(v1237 / p1217.segments, 0.5)
			end
			v1238.Position = v1239
			local v1240
			if v_u_1218 then
				v1240 = UDim2.new(1, 0, 0, 2)
			else
				v1240 = UDim2.new(0, 2, 1, 0)
			end
			v1238.Size = v1240
			local v1241 = Instance.new("Frame")
			if v1238 then
				for v1242, v1243 in v1238 do
					v1241[v1242] = v1243
				end
			end
			if not v1220 then
				continue
			end
			v1241.Parent = v1220
		end
	end
	local v_u_1244 = p1217.value or 0
	local v_u_1245 = 0
	local v1265 = {
		["frame"] = v1220,
		["fill"] = v_u_1234,
		["set"] = function(p1246, p1247) -- name: set
			-- upvalues: (ref) v_u_1244, (copy) v_u_1234, (copy) v_u_1218, (ref) v_u_12, (ref) v_u_1225, (ref) v_u_1245
			local v1248 = math.clamp(p1246, 0, 1)
			local v1249 = v_u_1244
			v_u_1244 = v1248
			if p1247 then
				local v1250 = v_u_1234
				local v1251
				if v_u_1218 then
					v1251 = UDim2.fromScale(1, v1248)
				else
					v1251 = UDim2.fromScale(v1248, 1)
				end
				v1250.Size = v1251
			else
				local v1252 = v_u_12.tween
				local v1253 = v_u_1234
				local v1254 = {}
				local v1255
				if v_u_1218 then
					v1255 = UDim2.fromScale(1, v1248)
				else
					v1255 = UDim2.fromScale(v1248, 1)
				end
				v1254.Size = v1255
				v1252(v1253, v1254, "normal")
			end
			if v_u_1225 then
				local v_u_1256 = v_u_1225
				if v1249 <= v1248 or p1247 then
					local v1257
					if v_u_1218 then
						v1257 = UDim2.fromScale(1, v1248)
					else
						v1257 = UDim2.fromScale(v1248, 1)
					end
					v_u_1256.Size = v1257
					return
				end
				v_u_1245 = v_u_1245 + 1
				local v_u_1258 = v_u_1245
				task.delay(0.45, function()
					-- upvalues: (copy) v_u_1258, (ref) v_u_1245, (copy) v_u_1256, (ref) v_u_12, (ref) v_u_1244, (ref) v_u_1218
					if v_u_1258 == v_u_1245 and v_u_1256.Parent then
						local v1259 = v_u_12.tween
						local v1260 = v_u_1256
						local v1261 = {}
						local v1262 = v_u_1244
						local v1263
						if v_u_1218 then
							v1263 = UDim2.fromScale(1, v1262)
						else
							v1263 = UDim2.fromScale(v1262, 1)
						end
						v1261.Size = v1263
						v1259(v1260, v1261, 0.5, Enum.EasingStyle.Quad)
					end
				end)
			end
		end,
		["get"] = function() -- name: get
			-- upvalues: (ref) v_u_1244
			return v_u_1244
		end,
		["setColor"] = function(p1264) -- name: setColor
			-- upvalues: (copy) v_u_1234
			v_u_1234.BackgroundColor3 = p1264
		end
	}
	v_u_167(v1220, p1217)
	if p1217.parent then
		v1220.Parent = p1217.parent
	end
	return v1265
end
function v_u_12.ring(p_u_1266) -- name: ring
	-- upvalues: (copy) v_u_10, (copy) v_u_167
	local v1267 = p_u_1266.size or 48
	local v_u_1268 = p_u_1266.segments or 28
	local v1269 = p_u_1266.thickness or 3
	local v1270 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Name"] = p_u_1266.name or "Ring"
	}
	local v1271
	if typeof(v1267) == "UDim2" then
		v1271 = v1267
	else
		v1271 = UDim2.fromOffset(v1267, v1267)
	end
	v1270.Size = v1271
	local v1272 = Instance.new("Frame")
	if v1270 then
		for v1273, v1274 in v1270 do
			v1272[v1273] = v1274
		end
	end
	local v1275 = {
		["AspectRatio"] = 1
	}
	local v1276 = Instance.new("UIAspectRatioConstraint")
	if v1275 then
		for v1277, v1278 in v1275 do
			v1276[v1277] = v1278
		end
	end
	if v1272 then
		v1276.Parent = v1272
	end
	local v1279 = 0.5 - v1269 / (typeof(v1267) ~= "number" and 48 or v1267) / 2
	local v1280 = 6.283185307179586 * v1279 / v_u_1268 * 0.62
	local v_u_1281 = p_u_1266.bgColor or v_u_10.line
	local v_u_1282 = p_u_1266.color or v_u_10.accent
	local v_u_1283 = {}
	for v1284 = 1, v_u_1268 do
		local v1285 = (v1284 - 0.5) / v_u_1268 * 3.141592653589793 * 2
		local v1286 = {
			["Name"] = "S",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["ZIndex"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5 + math.sin(v1285) * v1279, 0.5 - math.cos(v1285) * v1279),
			["Size"] = UDim2.new(v1280, 0, 0, v1269),
			["Rotation"] = math.deg(v1285),
			["BackgroundColor3"] = v_u_1281,
			["BackgroundTransparency"] = p_u_1266.bgTransparency or 0.3,
			["ZIndex"] = p_u_1266.zindex or 1
		}
		local v1287 = Instance.new("Frame")
		if v1286 then
			for v1288, v1289 in v1286 do
				v1287[v1288] = v1289
			end
		end
		if v1272 then
			v1287.Parent = v1272
		end
		v_u_1283[v1284] = v1287
	end
	local v1290 = {
		["frame"] = v1272
	}
	local v_u_1291 = -1
	function v1290.set(p1292) -- name: set
		-- upvalues: (copy) v_u_1268, (ref) v_u_1291, (copy) v_u_1283, (ref) v_u_1282, (copy) v_u_1281, (copy) p_u_1266
		local v1293 = math.clamp(p1292, 0, 1) * v_u_1268
		local v1294 = math.floor(v1293)
		local v1295 = v1293 - v1294
		if v1294 ~= v_u_1291 or v1295 >= 0.01 then
			v_u_1291 = v1294
			for v1296, v1297 in v_u_1283 do
				if v1296 <= v1294 then
					v1297.BackgroundColor3 = v_u_1282
					v1297.BackgroundTransparency = 0
				elseif v1296 == v1294 + 1 and v1295 > 0.01 then
					v1297.BackgroundColor3 = v_u_1282
					v1297.BackgroundTransparency = 1 - v1295
				else
					v1297.BackgroundColor3 = v_u_1281
					v1297.BackgroundTransparency = p_u_1266.bgTransparency or 0.3
				end
			end
		end
	end
	function v1290.setColor(p1298) -- name: setColor
		-- upvalues: (ref) v_u_1282, (ref) v_u_1291
		v_u_1282 = p1298
		v_u_1291 = -1
	end
	v1290.set(p_u_1266.value or 0)
	v_u_167(v1272, {
		["position"] = p_u_1266.position,
		["anchor"] = p_u_1266.anchor,
		["zindex"] = p_u_1266.zindex,
		["name"] = p_u_1266.name
	})
	if p_u_1266.parent then
		v1272.Parent = p_u_1266.parent
	end
	return v1290
end
function v_u_12.slider(p_u_1299) -- name: slider
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (copy) v_u_4, (copy) v_u_5, (copy) v_u_167
	local v_u_1300 = p_u_1299.min or 0
	local v_u_1301 = p_u_1299.max or 1
	local v_u_1302 = p_u_1299.step or 0
	local v1303 = p_u_1299.value or v_u_1300
	local v_u_1304 = math.clamp(v1303, v_u_1300, v_u_1301)
	local v_u_1308 = p_u_1299.format or function(p1305)
		-- upvalues: (copy) v_u_1302
		if v_u_1302 < 1 then
			return string.format("%.2f", p1305)
		end
		local v1306 = p1305 + 0.5
		local v1307 = math.floor(v1306)
		return tostring(v1307)
	end
	local v1309 = v_u_7.touch(28)
	local v1310 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Name"] = p_u_1299.name or "Slider",
		["Size"] = UDim2.new(0, p_u_1299.width or 360, 0, 20 + v1309)
	}
	local v_u_1311 = Instance.new("Frame")
	if v1310 then
		for v1312, v1313 in v1310 do
			v_u_1311[v1312] = v1313
		end
	end
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "body",
		["size"] = nil,
		["parent"] = v_u_1311,
		["text"] = p_u_1299.label or "",
		["size"] = UDim2.new(1, -80, 0, 20)
	})
	local v_u_1314 = v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "mono",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_1311,
		["text"] = v_u_1308(v_u_1304),
		["color"] = v_u_10.accent,
		["size"] = UDim2.new(0, 80, 0, 20),
		["position"] = UDim2.new(1, -80, 0, 0)
	})
	local v1315 = {
		["Name"] = "Hit",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["AutoButtonColor"] = false,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.new(0, 0, 0, 20),
		["Size"] = UDim2.new(1, 0, 0, v1309)
	}
	local v_u_1316 = Instance.new("TextButton")
	if v1315 then
		for v1317, v1318 in v1315 do
			v_u_1316[v1317] = v1318
		end
	end
	if v_u_1311 then
		v_u_1316.Parent = v_u_1311
	end
	local v1319 = {
		["Name"] = "Track",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.line,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.new(1, 0, 0, 4)
	}
	local v_u_1320 = Instance.new("Frame")
	if v1319 then
		for v1321, v1322 in v1319 do
			v_u_1320[v1321] = v1322
		end
	end
	if v_u_1316 then
		v_u_1320.Parent = v_u_1316
	end
	local v1323 = {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.accent,
		["Size"] = UDim2.fromScale(0, 1)
	}
	local v_u_1324 = Instance.new("Frame")
	if v1323 then
		for v1325, v1326 in v1323 do
			v_u_1324[v1325] = v1326
		end
	end
	if v_u_1320 then
		v_u_1324.Parent = v_u_1320
	end
	local v1327 = {
		["Name"] = "Knob",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_10.text,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(12, 16)
	}
	local v_u_1328 = Instance.new("Frame")
	if v1327 then
		for v1329, v1330 in v1327 do
			v_u_1328[v1329] = v1330
		end
	end
	if v_u_1320 then
		v_u_1328.Parent = v_u_1320
	end
	v_u_12.stroke(v_u_1328, v_u_10.accent)
	local v1331 = {}
	local function v_u_1343(p1332) -- name: setFromX
		-- upvalues: (copy) v_u_1320, (copy) v_u_1300, (copy) v_u_1301, (copy) v_u_1302, (ref) v_u_1304, (copy) v_u_1324, (copy) v_u_1328, (copy) v_u_1314, (copy) v_u_1308, (ref) v_u_12, (ref) v_u_7, (copy) p_u_1299
		local v1333 = v_u_1320.AbsolutePosition.X
		local v1334 = v_u_1320.AbsoluteSize.X
		local v1335 = math.max(1, v1334)
		local v1336 = (p1332 - v1333) / v1335
		local v1337 = v_u_1300 + math.clamp(v1336, 0, 1) * (v_u_1301 - v_u_1300)
		if v_u_1302 > 0 then
			local v1338 = (v1337 - v_u_1300) / v_u_1302 + 0.5
			v1337 = math.floor(v1338) * v_u_1302 + v_u_1300
		end
		local v1339 = v_u_1300
		local v1340 = v_u_1301
		local v1341 = math.clamp(v1337, v1339, v1340)
		if v1341 ~= v_u_1304 then
			v_u_1304 = v1341
			local v1342 = v_u_1300 >= v_u_1301 and 0 or (v_u_1304 - v_u_1300) / (v_u_1301 - v_u_1300)
			v_u_1324.Size = UDim2.fromScale(v1342, 1)
			v_u_1328.Position = UDim2.fromScale(v1342, 0.5)
			v_u_1314.Text = v_u_1308(v_u_1304)
			v_u_12.sound(v_u_7.sounds.tick)
			if p_u_1299.onChange then
				task.spawn(p_u_1299.onChange, v1341)
			end
		end
	end
	local v_u_1344 = nil
	local v_u_1345 = {}
	v_u_1311.Destroying:Connect(function()
		-- upvalues: (copy) v_u_1345
		for _, v1346 in v_u_1345 do
			v1346:Disconnect()
		end
	end)
	v_u_1316.InputBegan:Connect(function(p1347)
		-- upvalues: (ref) v_u_1344, (copy) v_u_1343, (ref) v_u_12, (copy) v_u_1328
		if p1347.UserInputType == Enum.UserInputType.MouseButton1 or p1347.UserInputType == Enum.UserInputType.Touch then
			v_u_1344 = p1347
			v_u_1343(p1347.Position.X)
			v_u_12.tween(v_u_1328, {
				["Size"] = UDim2.fromOffset(14, 20)
			}, "fast")
		end
	end)
	local v1348 = v_u_4.InputChanged
	local function v1350(p1349)
		-- upvalues: (ref) v_u_1344, (copy) v_u_1311, (copy) v_u_1343
		if v_u_1344 and v_u_1311.Parent then
			if p1349.UserInputType == Enum.UserInputType.MouseMovement or p1349.UserInputType == Enum.UserInputType.Touch and p1349 == v_u_1344 then
				v_u_1343(p1349.Position.X)
			end
		end
	end
	table.insert(v_u_1345, v1348:Connect(v1350))
	local v1351 = v_u_4.InputEnded
	local function v1353(p1352)
		-- upvalues: (ref) v_u_1344, (ref) v_u_12, (copy) v_u_1328
		if v_u_1344 and (p1352.UserInputType == Enum.UserInputType.MouseButton1 or p1352 == v_u_1344) then
			v_u_1344 = nil
			v_u_12.tween(v_u_1328, {
				["Size"] = UDim2.fromOffset(12, 16)
			}, "fast")
		end
	end
	table.insert(v_u_1345, v1351:Connect(v1353))
	v_u_1316.SelectionImageObject = v_u_12.selectionImage()
	v_u_1316.NextSelectionLeft = v_u_1316
	v_u_1316.NextSelectionRight = v_u_1316
	v_u_1316.SelectionGained:Connect(function()
		-- upvalues: (copy) v_u_1328, (ref) v_u_10
		v_u_1328.BackgroundColor3 = v_u_10.accent
	end)
	v_u_1316.SelectionLost:Connect(function()
		-- upvalues: (copy) v_u_1328, (ref) v_u_10
		v_u_1328.BackgroundColor3 = v_u_10.text
	end)
	local function v_u_1361(p1354) -- name: nudge
		-- upvalues: (copy) v_u_1302, (copy) v_u_1301, (copy) v_u_1300, (ref) v_u_1304, (copy) v_u_1324, (copy) v_u_1328, (copy) v_u_1314, (copy) v_u_1308, (ref) v_u_12, (ref) v_u_7, (copy) p_u_1299
		local v1355
		if v_u_1302 > 0 then
			v1355 = v_u_1302
		else
			v1355 = (v_u_1301 - v_u_1300) / 20
		end
		local v1356 = v_u_1304 + p1354 * v1355
		local v1357 = v_u_1300
		local v1358 = v_u_1301
		local v1359 = math.clamp(v1356, v1357, v1358)
		if v1359 ~= v_u_1304 then
			v_u_1304 = v1359
			local v1360 = v_u_1300 >= v_u_1301 and 0 or (v_u_1304 - v_u_1300) / (v_u_1301 - v_u_1300)
			v_u_1324.Size = UDim2.fromScale(v1360, 1)
			v_u_1328.Position = UDim2.fromScale(v1360, 0.5)
			v_u_1314.Text = v_u_1308(v_u_1304)
			v_u_12.sound(v_u_7.sounds.tick)
			if p_u_1299.onChange then
				task.spawn(p_u_1299.onChange, v1359)
			end
		end
	end
	local v1362 = require(script.Parent:WaitForChild("VirtualPad")).InputBegan
	local function v1365(p1363)
		-- upvalues: (ref) v_u_5, (copy) v_u_1316, (copy) v_u_1311, (copy) v_u_1361
		if v_u_5.SelectedObject == v_u_1316 and v_u_1311.Parent then
			local v1364 = p1363.KeyCode
			if v1364 == Enum.KeyCode.DPadLeft or v1364 == Enum.KeyCode.Left then
				v_u_1361(-1)
			elseif v1364 == Enum.KeyCode.DPadRight or v1364 == Enum.KeyCode.Right then
				v_u_1361(1)
			end
		else
			return
		end
	end
	table.insert(v_u_1345, v1362:Connect(v1365))
	function v1331.set(p1366) -- name: set
		-- upvalues: (ref) v_u_1304, (copy) v_u_1300, (copy) v_u_1301, (copy) v_u_1324, (copy) v_u_1328, (copy) v_u_1314, (copy) v_u_1308
		local v1367 = v_u_1300
		local v1368 = v_u_1301
		v_u_1304 = math.clamp(p1366, v1367, v1368)
		local v1369 = v_u_1300 >= v_u_1301 and 0 or (v_u_1304 - v_u_1300) / (v_u_1301 - v_u_1300)
		v_u_1324.Size = UDim2.fromScale(v1369, 1)
		v_u_1328.Position = UDim2.fromScale(v1369, 0.5)
		v_u_1314.Text = v_u_1308(v_u_1304)
	end
	function v1331.get() -- name: get
		-- upvalues: (ref) v_u_1304
		return v_u_1304
	end
	local v1370 = v_u_1300 >= v_u_1301 and 0 or (v_u_1304 - v_u_1300) / (v_u_1301 - v_u_1300)
	v_u_1324.Size = UDim2.fromScale(v1370, 1)
	v_u_1328.Position = UDim2.fromScale(v1370, 0.5)
	v_u_1314.Text = v_u_1308(v_u_1304)
	v_u_167(v_u_1311, p_u_1299)
	if p_u_1299.parent then
		v_u_1311.Parent = p_u_1299.parent
	end
	return v_u_1311, v1331
end
function v_u_12.toggle(p_u_1371) -- name: toggle
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (copy) v_u_167
	local v_u_1372 = p_u_1371.value == true
	local v1373 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Name"] = p_u_1371.name or "Toggle",
		["Size"] = UDim2.new(0, p_u_1371.width or 360, 0, v_u_7.touch(40))
	}
	local v1374 = Instance.new("TextButton")
	if v1373 then
		for v1375, v1376 in v1373 do
			v1374[v1375] = v1376
		end
	end
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "body",
		["size"] = nil,
		["parent"] = v1374,
		["text"] = p_u_1371.label or "",
		["size"] = UDim2.new(1, -64, 1, 0)
	})
	local v1377 = {
		["Name"] = "Switch",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.raised,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.fromScale(1, 0.5),
		["Size"] = UDim2.fromOffset(44, 22)
	}
	local v_u_1378 = Instance.new("Frame")
	if v1377 then
		for v1379, v1380 in v1377 do
			v_u_1378[v1379] = v1380
		end
	end
	if v1374 then
		v_u_1378.Parent = v1374
	end
	local v_u_1381 = v_u_12.stroke(v_u_1378, v_u_10.lineStrong)
	local v1382 = {
		["Name"] = "Knob",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.text2,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 4, 0.5, 0),
		["Size"] = UDim2.fromOffset(14, 14)
	}
	local v_u_1383 = Instance.new("Frame")
	if v1382 then
		for v1384, v1385 in v1382 do
			v_u_1383[v1384] = v1385
		end
	end
	if v_u_1378 then
		v_u_1383.Parent = v_u_1378
	end
	local v1386 = {}
	local function v_u_1402(p1387) -- name: render
		-- upvalues: (ref) v_u_12, (copy) v_u_1383, (ref) v_u_1372, (ref) v_u_10, (copy) v_u_1378, (copy) v_u_1381
		local v1388 = p1387 and 0 or "fast"
		local v1389 = v_u_12.tween
		local v1390 = v_u_1383
		local v1391 = {}
		local v1392
		if v_u_1372 then
			v1392 = UDim2.new(1, -18, 0.5, 0)
		else
			v1392 = UDim2.new(0, 4, 0.5, 0)
		end
		v1391.Position = v1392
		local v1393
		if v_u_1372 then
			v1393 = v_u_10.ink
		else
			v1393 = v_u_10.text2
		end
		v1391.BackgroundColor3 = v1393
		v1389(v1390, v1391, v1388)
		local v1394 = v_u_12.tween
		local v1395 = v_u_1378
		local v1396 = {}
		local v1397
		if v_u_1372 then
			v1397 = v_u_10.accent
		else
			v1397 = v_u_10.raised
		end
		v1396.BackgroundColor3 = v1397
		v1394(v1395, v1396, v1388)
		local v1398 = v_u_12.tween
		local v1399 = v_u_1381
		local v1400 = {}
		local v1401
		if v_u_1372 then
			v1401 = v_u_10.accent
		else
			v1401 = v_u_10.lineStrong
		end
		v1400.Color = v1401
		v1398(v1399, v1400, v1388)
	end
	v1374.Activated:Connect(function()
		-- upvalues: (ref) v_u_1372, (copy) v_u_1402, (ref) v_u_12, (ref) v_u_7, (copy) p_u_1371
		v_u_1372 = not v_u_1372
		v_u_1402()
		v_u_12.sound(v_u_7.sounds.toggle)
		if p_u_1371.onChange then
			task.spawn(p_u_1371.onChange, v_u_1372)
		end
	end)
	v1374.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_1372, (copy) v_u_1381, (ref) v_u_10
		v_u_12.sound(v_u_7.sounds.hover)
		if not v_u_1372 then
			v_u_1381.Color = v_u_10.text2
		end
	end)
	v1374.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_1402
		v_u_1402(true)
	end)
	v1374.SelectionImageObject = v_u_12.selectionImage()
	function v1386.set(p1403) -- name: set
		-- upvalues: (ref) v_u_1372, (copy) v_u_1402
		v_u_1372 = p1403 == true
		v_u_1402(true)
	end
	function v1386.get() -- name: get
		-- upvalues: (ref) v_u_1372
		return v_u_1372
	end
	v_u_1402(true)
	v_u_167(v1374, p_u_1371)
	if p_u_1371.parent then
		v1374.Parent = p_u_1371.parent
	end
	return v1374, v1386
end
local v_u_1404 = nil
local v_u_1405 = 0
function v_u_12.dropdownOpen() -- name: dropdownOpen
	-- upvalues: (ref) v_u_1404
	return v_u_1404 ~= nil
end
function v_u_12.dropdown(p_u_1406) -- name: dropdown
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_10, (ref) v_u_1404, (copy) v_u_938, (copy) v_u_5, (ref) v_u_1405, (copy) v_u_2, (copy) v_u_4, (copy) v_u_167
	local v_u_1407 = {}
	for _, v1408 in p_u_1406.options or {} do
		if type(v1408) == "string" then
			table.insert(v_u_1407, {
				["id"] = v1408,
				["text"] = v1408
			})
		else
			local v1409 = {}
			local v1410 = v1408.id
			v1409.id = tostring(v1410)
			local v1411 = v1408.text or v1408.id
			v1409.text = tostring(v1411)
			table.insert(v_u_1407, v1409)
		end
	end
	local v_u_1412 = not p_u_1406.value and v_u_1407[1]
	if v_u_1412 then
		v_u_1412 = v_u_1407[1].id
	end
	local v1413 = p_u_1406.width or 360
	local v1414 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Name"] = p_u_1406.name or "Dropdown",
		["Size"] = UDim2.new(0, v1413, 0, v_u_7.touch(40))
	}
	local v1415 = Instance.new("Frame")
	if v1414 then
		for v1416, v1417 in v1414 do
			v1415[v1416] = v1417
		end
	end
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "body",
		["size"] = nil,
		["parent"] = v1415,
		["text"] = p_u_1406.label or "",
		["size"] = UDim2.new(0.45, 0, 1, 0)
	})
	local v1418 = {
		["Name"] = "Box",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_10.raised,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.fromScale(1, 0.5),
		["Size"] = UDim2.new(0.55, 0, 0, v_u_7.touch(34))
	}
	local v_u_1419 = Instance.new("TextButton")
	if v1418 then
		for v1420, v1421 in v1418 do
			v_u_1419[v1420] = v1421
		end
	end
	if v1415 then
		v_u_1419.Parent = v1415
	end
	local v_u_1422 = v_u_12.stroke(v_u_1419, v_u_10.line)
	v_u_1419.SelectionImageObject = v_u_12.selectionImage()
	local v_u_1423 = v_u_12.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "body",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_1419,
		["size"] = UDim2.new(1, -40, 1, 0),
		["position"] = UDim2.fromOffset(12, 0)
	})
	v_u_12.icon("chevronDown", {
		["parent"] = nil,
		["size"] = 14,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v_u_1419,
		["color"] = v_u_10.text2,
		["position"] = UDim2.new(1, -12, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5)
	})
	local v1424 = {}
	local v_u_1425 = nil
	local function v_u_1426() -- name: close
		-- upvalues: (ref) v_u_1425, (copy) v_u_1422, (ref) v_u_10, (ref) v_u_1404, (copy) v_u_1426
		if v_u_1425 then
			v_u_1425:Destroy()
			v_u_1425 = nil
		end
		v_u_1422.Color = v_u_10.line
		if v_u_1404 == v_u_1426 then
			v_u_1404 = nil
		end
	end
	local function v_u_1486() -- name: open
		-- upvalues: (ref) v_u_1404, (ref) v_u_938, (ref) v_u_7, (ref) v_u_12, (copy) v_u_1419, (copy) v_u_1407, (ref) v_u_10, (ref) v_u_1412, (copy) v_u_1423, (ref) v_u_1425, (copy) v_u_1422, (copy) v_u_1426, (ref) v_u_5, (copy) p_u_1406, (ref) v_u_1405, (ref) v_u_2, (ref) v_u_4
		if v_u_1404 then
			v_u_1404()
		end
		local v1427 = v_u_938("HushPopup", v_u_7.layer.tooltip - 1)
		local v1428 = v_u_7.uiScale()
		local v1429 = v_u_12.absToOverlay(v_u_1419.AbsolutePosition)
		local v1430 = v_u_1419.AbsoluteSize / v1428
		local v1431 = v_u_7.touch(34)
		local v1432, v1433, v1434, v1435 = v_u_12.dropdownRect({
			["x"] = v1429.X,
			["y"] = v1429.Y,
			["w"] = v1430.X,
			["h"] = v1430.Y
		}, v1431, #v_u_1407, v_u_7.refSize(), v_u_12.safeInsets())
		local v1436 = {
			["Name"] = "DropdownList",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_10.raised,
			["Position"] = UDim2.fromOffset(v1432, v1433),
			["Size"] = UDim2.fromOffset(v1434, v1435)
		}
		local v_u_1437 = Instance.new("Frame")
		if v1436 then
			for v1438, v1439 in v1436 do
				v_u_1437[v1438] = v1439
			end
		end
		if v1427 then
			v_u_1437.Parent = v1427
		end
		v_u_12.stroke(v_u_1437, v_u_10.lineStrong)
		local v_u_1440 = v_u_12.list({
			["parent"] = nil,
			["gap"] = 0,
			["padding"] = false,
			["parent"] = v_u_1437
		})
		v_u_1440.ZIndex = 20
		for v1441, v_u_1442 in v_u_1407 do
			local v1443 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ZIndex"] = 21,
				["Name"] = "Opt_" .. v_u_1442.id
			}
			local v1444
			if v_u_1442.id == v_u_1412 then
				v1444 = v_u_10.accentDeep
			else
				v1444 = v_u_10.raised
			end
			v1443.BackgroundColor3 = v1444
			v1443.Size = UDim2.new(1, 0, 0, v1431)
			v1443.LayoutOrder = v1441
			local v_u_1445 = Instance.new("TextButton")
			if v1443 then
				for v1446, v1447 in v1443 do
					v_u_1445[v1446] = v1447
				end
			end
			if v_u_1440 then
				v_u_1445.Parent = v_u_1440
			end
			local v1448 = v_u_12.label
			local v1449 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["zindex"] = 22,
				["parent"] = v_u_1445,
				["text"] = v_u_1442.text
			}
			local v1450
			if v_u_1442.id == v_u_1412 then
				v1450 = v_u_10.accent
			else
				v1450 = v_u_10.text
			end
			v1449.color = v1450
			v1449.size = UDim2.new(1, -24, 1, 0)
			v1449.position = UDim2.fromOffset(12, 0)
			v1448(v1449)
			v_u_1445.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_12, (ref) v_u_7, (copy) v_u_1442, (ref) v_u_1412, (copy) v_u_1445, (ref) v_u_10
				v_u_12.sound(v_u_7.sounds.hover)
				if v_u_1442.id ~= v_u_1412 then
					v_u_1445.BackgroundColor3 = v_u_10.raised2
				end
			end)
			v_u_1445.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_1445, (copy) v_u_1442, (ref) v_u_1412, (ref) v_u_10
				local v1451 = v_u_1445
				local v1452
				if v_u_1442.id == v_u_1412 then
					v1452 = v_u_10.accentDeep
				else
					v1452 = v_u_10.raised
				end
				v1451.BackgroundColor3 = v1452
			end)
			v_u_1445.Activated:Connect(function()
				-- upvalues: (ref) v_u_1412, (copy) v_u_1442, (ref) v_u_1423, (ref) v_u_1407, (ref) v_u_1425, (ref) v_u_1422, (ref) v_u_10, (ref) v_u_1404, (ref) v_u_1426, (ref) v_u_12, (ref) v_u_1419, (ref) v_u_5, (ref) v_u_7, (ref) p_u_1406
				v_u_1412 = v_u_1442.id
				local v1453 = v_u_1423
				local v1454 = v_u_1412
				for _, v1455 in v_u_1407 do
					if v1455.id ~= v1454 then
						continue
					end
					v1456 = v1455.text
				end
				local v1456 = v1454 or ""
				v1453.Text = v1456
				if v_u_1425 then
					v_u_1425:Destroy()
					v_u_1425 = nil
				end
				v_u_1422.Color = v_u_10.line
				if v_u_1404 == v_u_1426 then
					v_u_1404 = nil
				end
				if v_u_12.device() == "Gamepad" and v_u_1419.Parent then
					local function v1457()
						-- upvalues: (ref) v_u_5, (ref) v_u_1419
						v_u_5.SelectedObject = v_u_1419
					end
					pcall(v1457)
				end
				v_u_12.sound(v_u_7.sounds.click)
				if p_u_1406.onChange then
					task.spawn(p_u_1406.onChange, v_u_1442.id)
				end
			end)
		end
		v_u_1425 = v_u_1437
		v_u_1422.Color = v_u_10.accent
		v_u_1404 = v_u_1426
		v_u_12.sound(v_u_7.sounds.open)
		local function v1462()
			-- upvalues: (copy) v_u_1437, (ref) v_u_12, (copy) v_u_1440, (ref) v_u_1412, (ref) v_u_5
			v_u_1437.SelectionGroup = true
			v_u_1437.SelectionBehaviorUp = Enum.SelectionBehavior.Stop
			v_u_1437.SelectionBehaviorDown = Enum.SelectionBehavior.Stop
			v_u_1437.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
			v_u_1437.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
			if v_u_12.device() == "Gamepad" then
				local v1458 = nil
				for _, v1459 in v_u_1440:GetChildren() do
					if not v1459:IsA("TextButton") then
						continue
					end
					if v1458 ~= nil then
						local v1460 = v_u_1412
						if v1459.Name ~= "Opt_" .. tostring(v1460) then
							continue
						end
					end
					local v1461 = v_u_1412
					if v1459.Name == "Opt_" .. tostring(v1461) then
						v1458 = v1459
						break
					end
					v1458 = v1459
				end
				if v1458 then
					v_u_5.SelectedObject = v1458
				end
			end
		end
		pcall(v1462)
		v_u_1405 = v_u_1405 + 1
		local v1463 = v_u_1405
		local v_u_1464 = "HushDropdownBack" .. tostring(v1463)
		local function v_u_1467()
			-- upvalues: (ref) v_u_12, (ref) v_u_1425, (ref) v_u_1422, (ref) v_u_10, (ref) v_u_1404, (ref) v_u_1426, (ref) v_u_1419, (ref) v_u_5
			local v1465 = v_u_12.device() == "Gamepad"
			if v_u_1425 then
				v_u_1425:Destroy()
				v_u_1425 = nil
			end
			v_u_1422.Color = v_u_10.line
			if v_u_1404 == v_u_1426 then
				v_u_1404 = nil
			end
			if v1465 and v_u_1419.Parent then
				local function v1466()
					-- upvalues: (ref) v_u_5, (ref) v_u_1419
					v_u_5.SelectedObject = v_u_1419
				end
				pcall(v1466)
			end
		end
		local function v1470()
			-- upvalues: (copy) v_u_1464, (ref) v_u_1425, (copy) v_u_1437, (ref) v_u_12, (copy) v_u_1467
			game:GetService("ContextActionService"):BindActionAtPriority(v_u_1464, function(_, p1468, p1469)
				-- upvalues: (ref) v_u_1425, (ref) v_u_1437, (ref) v_u_12, (ref) v_u_1467
				if p1468 == Enum.UserInputState.Begin and v_u_1425 == v_u_1437 then
					if p1469 == nil or p1469.KeyCode ~= Enum.KeyCode.ButtonStart then
						v_u_12.takeBack()
					end
					task.defer(v_u_1467)
				end
				return Enum.ContextActionResult.Sink
			end, false, Enum.ContextActionPriority.High.Value + 50, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonStart)
		end
		pcall(v1470)
		local v_u_1471 = nil
		v_u_1471 = v_u_2.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_1425, (copy) v_u_1437, (ref) v_u_1471, (copy) v_u_1464, (ref) v_u_1419, (ref) v_u_5, (ref) v_u_12, (ref) v_u_1422, (ref) v_u_10, (ref) v_u_1404, (ref) v_u_1426
			if v_u_1425 ~= v_u_1437 then
				v_u_1471:Disconnect()
				local function v1472()
					-- upvalues: (ref) v_u_1464
					game:GetService("ContextActionService"):UnbindAction(v_u_1464)
				end
				pcall(v1472)
				return
			end
			local v1473 = not v_u_1419:IsDescendantOf(game) or v_u_1419.AbsoluteSize.X <= 0
			if not v1473 then
				local v1474 = v_u_1419
				while v1474 and not v1474:IsA("LayerCollector") do
					if v1474:IsA("GuiObject") and not v1474.Visible then
						v1473 = true
						break
					end
					v1474 = v1474.Parent
				end
				v1473 = not v1473 and (v1474 and (v1474:IsA("LayerCollector") and not v1474.Enabled)) and true or v1473
			end
			local v1475 = v_u_5.SelectedObject
			local v1476 = v_u_12.device() == "Gamepad" and v1475 ~= nil and not v1475:IsDescendantOf(v_u_1437)
			if v1476 then
				v1476 = v1475 ~= v_u_1419
			end
			if v1473 or v1476 then
				if v_u_1425 then
					v_u_1425:Destroy()
					v_u_1425 = nil
				end
				v_u_1422.Color = v_u_10.line
				if v_u_1404 == v_u_1426 then
					v_u_1404 = nil
				end
			end
		end)
		local v_u_1477 = nil
		v_u_1477 = v_u_4.InputBegan:Connect(function(p1478)
			-- upvalues: (ref) v_u_1425, (copy) v_u_1437, (ref) v_u_1477, (ref) v_u_1419, (ref) v_u_1426
			if v_u_1425 == v_u_1437 then
				if p1478.UserInputType == Enum.UserInputType.MouseButton1 or p1478.UserInputType == Enum.UserInputType.Touch then
					local v1479 = Vector2.new(p1478.Position.X, p1478.Position.Y)
					local v1480 = v_u_1437.AbsolutePosition
					local v1481 = v_u_1437.AbsoluteSize
					local v1482 = v_u_1419.AbsolutePosition
					local v1483 = v_u_1419.AbsoluteSize
					local v1484
					if v1479.X >= v1480.X and (v1479.X <= v1480.X + v1481.X and v1479.Y >= v1480.Y) then
						v1484 = v1479.Y <= v1480.Y + v1481.Y
					else
						v1484 = false
					end
					local v1485
					if v1479.X >= v1482.X and (v1479.X <= v1482.X + v1483.X and v1479.Y >= v1482.Y) then
						v1485 = v1479.Y <= v1482.Y + v1483.Y
					else
						v1485 = false
					end
					if not (v1484 or v1485) then
						task.defer(v_u_1426)
						v_u_1477:Disconnect()
					end
				end
			else
				v_u_1477:Disconnect()
			end
		end)
	end
	v_u_1419.Activated:Connect(function()
		-- upvalues: (ref) v_u_1425, (copy) v_u_1422, (ref) v_u_10, (ref) v_u_1404, (copy) v_u_1426, (copy) v_u_1486
		if v_u_1425 then
			if v_u_1425 then
				v_u_1425:Destroy()
				v_u_1425 = nil
			end
			v_u_1422.Color = v_u_10.line
			if v_u_1404 == v_u_1426 then
				v_u_1404 = nil
				return
			end
		else
			v_u_1486()
		end
	end)
	v_u_1419.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_7, (ref) v_u_1425, (copy) v_u_1422, (ref) v_u_10
		v_u_12.sound(v_u_7.sounds.hover)
		if not v_u_1425 then
			v_u_1422.Color = v_u_10.lineStrong
		end
	end)
	v_u_1419.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_1425, (copy) v_u_1422, (ref) v_u_10
		if not v_u_1425 then
			v_u_1422.Color = v_u_10.line
		end
	end)
	v1415.Destroying:Connect(v_u_1426)
	v1424.open = v_u_1486
	v1424.close = v_u_1426
	function v1424.set(p1487) -- name: set
		-- upvalues: (ref) v_u_1412, (copy) v_u_1423, (copy) v_u_1407
		v_u_1412 = p1487
		local v1488 = v_u_1423
		local v1489 = v_u_1412
		for _, v1490 in v_u_1407 do
			if v1490.id ~= v1489 then
				continue
			end
			v1491 = v1490.text
		end
		local v1491 = v1489 or ""
		v1488.Text = v1491
	end
	function v1424.get() -- name: get
		-- upvalues: (ref) v_u_1412
		return v_u_1412
	end
	for _, v1492 in v_u_1407 do
		if v1492.id ~= v_u_1412 then
			continue
		end
		v1493 = v1492.text
	end
	local v1493 = v_u_1412 or ""
	v_u_1423.Text = v1493
	v_u_167(v1415, p_u_1406)
	if p_u_1406.parent then
		v1415.Parent = p_u_1406.parent
	end
	return v1415, v1424
end
function v_u_12.input(p_u_1494) -- name: input
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_12, (copy) v_u_167
	local v1495 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Name"] = p_u_1494.name or "Input",
		["BackgroundColor3"] = v_u_10.raised,
		["Size"] = p_u_1494.size or UDim2.fromOffset(p_u_1494.width or 320, v_u_7.touch(38))
	}
	local v1496 = Instance.new("Frame")
	if v1495 then
		for v1497, v1498 in v1495 do
			v1496[v1497] = v1498
		end
	end
	local v_u_1499 = v_u_12.stroke(v1496, v_u_10.line)
	local v1500 = {
		["Name"] = "Box",
		["BackgroundTransparency"] = 1,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["PlaceholderText"] = nil,
		["PlaceholderColor3"] = nil,
		["Text"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_7.font.body,
		["TextColor3"] = v_u_10.text,
		["PlaceholderText"] = p_u_1494.placeholder or "",
		["PlaceholderColor3"] = v_u_10.muted,
		["Text"] = p_u_1494.text or "",
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(12, 0),
		["Size"] = UDim2.new(1, -24, 1, 0)
	}
	local v_u_1501 = Instance.new("TextBox")
	if v1500 then
		for v1502, v1503 in v1500 do
			v_u_1501[v1502] = v1503
		end
	end
	if v1496 then
		v_u_1501.Parent = v1496
	end
	if p_u_1494.maxLength then
		v_u_1501:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_1501, (copy) p_u_1494
			if #v_u_1501.Text > p_u_1494.maxLength then
				local v1504 = v_u_1501
				local v1505 = v_u_1501.Text
				local v1506 = p_u_1494.maxLength
				v1504.Text = string.sub(v1505, 1, v1506)
			end
		end)
	end
	v_u_1501.Focused:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_1499, (ref) v_u_10
		v_u_12.tween(v_u_1499, {
			["Color"] = v_u_10.accent
		}, "fast")
	end)
	v_u_1501.FocusLost:Connect(function(p1507)
		-- upvalues: (ref) v_u_12, (copy) v_u_1499, (ref) v_u_10, (copy) p_u_1494, (copy) v_u_1501
		v_u_12.tween(v_u_1499, {
			["Color"] = v_u_10.line
		}, "fast")
		if p1507 and p_u_1494.onSubmit then
			task.spawn(p_u_1494.onSubmit, v_u_1501.Text)
		end
	end)
	if p_u_1494.onChange then
		v_u_1501:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) p_u_1494, (copy) v_u_1501
			p_u_1494.onChange(v_u_1501.Text)
		end)
	end
	v_u_167(v1496, {
		["position"] = p_u_1494.position,
		["anchor"] = p_u_1494.anchor,
		["zindex"] = p_u_1494.zindex,
		["order"] = p_u_1494.order
	})
	if p_u_1494.parent then
		v1496.Parent = p_u_1494.parent
	end
	return v1496, v_u_1501
end
function v_u_12.badge(p1508, p1509, p1510) -- name: badge
	-- upvalues: (copy) v_u_7, (copy) v_u_10, (copy) v_u_12, (copy) v_u_167
	local v1511 = p1510 or {}
	local v1512 = v_u_7.kindColor(p1509)
	local v1513 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Name"] = v1511.name or "Badge",
		["BackgroundColor3"] = v_u_10.bg,
		["Size"] = UDim2.fromOffset(0, v1511.height or 18),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}
	local v1514 = Instance.new("Frame")
	if v1513 then
		for v1515, v1516 in v1513 do
			v1514[v1515] = v1516
		end
	end
	v_u_12.stroke(v1514, v1512, 1, 0.35)
	v_u_12.pad(v1514, {
		6,
		6,
		0,
		0
	})
	v_u_12.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["parent"] = v1514,
		["text"] = p1508,
		["color"] = v1512,
		["size"] = UDim2.fromOffset(0, v1511.height or 18)
	})
	v_u_167(v1514, {
		["position"] = v1511.position,
		["anchor"] = v1511.anchor,
		["zindex"] = v1511.zindex,
		["order"] = v1511.order
	})
	if v1511.parent then
		v1514.Parent = v1511.parent
	end
	return v1514
end
local v_u_1517 = nil
local v_u_1518 = false
local v_u_1519 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_1520 = nil
function v_u_12.grain(p1521, p1522) -- name: grain
	-- upvalues: (ref) v_u_1518, (ref) v_u_1517, (copy) v_u_1519, (ref) v_u_1520, (copy) v_u_2
	local v_u_1523
	if v_u_1518 then
		v_u_1523 = v_u_1517
	else
		v_u_1518 = true
		local v1536, v1537 = pcall(function()
			local v1524 = game:GetService("AssetService")
			local v1525 = Vector2.new(96, 96)
			local v1526 = v1524:CreateEditableImage({
				["Size"] = v1525
			})
			local v1527 = buffer.create(v1525.X * v1525.Y * 4)
			local v1528 = Random.new(1337)
			for v1529 = 0, v1525.X * v1525.Y - 1 do
				local v1530 = v1528:NextInteger(0, 255)
				local v1531 = v1529 * 4
				buffer.writeu8(v1527, v1531, v1530)
				local v1532 = v1529 * 4 + 1
				buffer.writeu8(v1527, v1532, v1530)
				local v1533 = v1529 * 4 + 2
				buffer.writeu8(v1527, v1533, v1530)
				local v1534 = v1529 * 4 + 3
				local v1535 = v1528:NextInteger(0, 255)
				buffer.writeu8(v1527, v1534, v1535)
			end
			v1526:WritePixelsBuffer(Vector2.zero, v1525, v1527)
			return Content.fromObject(v1526)
		end)
		if v1536 then
			v_u_1517 = v1537
		end
		v_u_1523 = v_u_1517
	end
	if not v_u_1523 then
		return nil
	end
	local v1538 = {
		["Name"] = "Grain",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["ImageTransparency"] = nil,
		["ScaleType"] = nil,
		["TileSize"] = nil,
		["ResampleMode"] = nil,
		["ZIndex"] = 50,
		["Active"] = false,
		["Size"] = UDim2.new(1, 96, 1, 96),
		["Position"] = UDim2.fromOffset(-48, -48),
		["ImageTransparency"] = 1 - (p1522 or 0.05),
		["ScaleType"] = Enum.ScaleType.Tile,
		["TileSize"] = UDim2.fromOffset(96, 96),
		["ResampleMode"] = Enum.ResamplerMode.Pixelated
	}
	local v_u_1539 = Instance.new("ImageLabel")
	if v1538 then
		for v1540, v1541 in v1538 do
			v_u_1539[v1540] = v1541
		end
	end
	pcall(function()
		-- upvalues: (copy) v_u_1539, (copy) v_u_1523
		v_u_1539.ImageContent = v_u_1523
	end)
	v_u_1539.Parent = p1521
	v_u_1519[v_u_1539] = true
	if not v_u_1520 then
		local v_u_1542 = 0
		v_u_1520 = v_u_2.Heartbeat:Connect(function(p1543)
			-- upvalues: (ref) v_u_1542, (ref) v_u_1519
			v_u_1542 = v_u_1542 + p1543
			if v_u_1542 >= 0.041666666666666664 then
				v_u_1542 = 0
				for v1544 in v_u_1519 do
					if not (v1544.Parent and v1544.Visible) then
						continue
					end
					v1544.Position = UDim2.fromOffset(-math.random(0, 95), -math.random(0, 95))
				end
			end
		end)
	end
	return v_u_1539
end
function v_u_12.countUp(p_u_1545, p_u_1546, p1547) -- name: countUp
	local v1548 = p1547 or {}
	local v_u_1549 = v1548.from or 0
	local v_u_1550 = v1548.duration or 0.8
	local v_u_1554 = v1548.format or function(p1551)
		local v1552 = p1551 + 0.5
		local v1553 = math.floor(v1552)
		return tostring(v1553)
	end
	local v1555 = p_u_1545:GetAttribute("CountToken")
	local v_u_1556 = (type(v1555) ~= "number" and 0 or v1555) + 1
	p_u_1545:SetAttribute("CountToken", v_u_1556)
	local v_u_1557 = os.clock()
	task.spawn(function()
		-- upvalues: (copy) p_u_1545, (copy) v_u_1556, (copy) v_u_1557, (copy) v_u_1550, (copy) v_u_1554, (copy) v_u_1549, (copy) p_u_1546
		while p_u_1545.Parent and p_u_1545:GetAttribute("CountToken") == v_u_1556 do
			local v1558 = (os.clock() - v_u_1557) / v_u_1550
			local v1559 = math.clamp(v1558, 0, 1)
			local v1560 = 1 - (1 - v1559) ^ 4
			p_u_1545.Text = v_u_1554(v_u_1549 + (p_u_1546 - v_u_1549) * v1560)
			if v1559 >= 1 then
				break
			end
			task.wait()
		end
	end)
end
function v_u_12.commas(p1561) -- name: commas
	local v1562 = math.abs(p1561) + 0.5
	local v1563 = math.floor(v1562)
	local v1564 = tostring(v1563):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if v1564:sub(1, 1) == "," then
		v1564 = v1564:sub(2)
	end
	return (p1561 < 0 and "-" or "") .. v1564
end
function v_u_12.clock(p1565) -- name: clock
	local v1566 = math.floor(p1565)
	local v1567 = math.max(0, v1566)
	return string.format("%02d:%02d", v1567 // 60, v1567 % 60)
end
return v_u_12