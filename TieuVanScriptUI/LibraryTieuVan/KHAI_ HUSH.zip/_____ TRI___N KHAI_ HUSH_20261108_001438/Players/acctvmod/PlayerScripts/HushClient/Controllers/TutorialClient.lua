-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / TutorialClient

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = game:GetService("Players")
local v_u_4 = {
	["name"] = "TutorialClient",
	["order"] = 52
}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v3.LocalPlayer
local v_u_11 = "Menu"
local v_u_12 = nil
local v_u_13 = 0
local v_u_14 = ""
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = ""
local v_u_18 = {}
local v_u_19 = nil
local v_u_20 = 0
local v_u_21 = nil
local v_u_22 = -1
local v_u_23 = 0
local v_u_24 = 0
local v_u_25 = -1
local v_u_26 = 0
local v_u_27 = false
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = false
local v_u_32 = 0
local function v_u_34() -- name: destroyCard
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_22, (ref) v_u_21, (copy) v_u_10
	if v_u_12 then
		local function v33()
			-- upvalues: (ref) v_u_12
			v_u_12.gui:Destroy()
		end
		pcall(v33)
	end
	v_u_12 = nil
	v_u_13 = 0
	v_u_22 = -1
	v_u_21 = nil
	v_u_10:SetAttribute("TutorialCardShown", false)
	v_u_10:SetAttribute("TutorialCardStep", nil)
end
local function v_u_58(p_u_35) -- name: touchGap
	-- upvalues: (ref) v_u_7, (ref) v_u_5
	local v36 = v_u_7.refSize()
	local v37 = v_u_7.uiScale
	local v38 = math.max(0.1, v37())
	local v_u_39 = v_u_7.viewport()
	local v40 = 172 / v38
	local v41 = (v_u_39.X - 334) / v38
	local v42 = v36.Y - 82
	local v_u_43 = "Input"
	local function v44()
		-- upvalues: (ref) v_u_5, (copy) v_u_43
		return v_u_5.controllers[v_u_43]
	end
	local v45, v46 = pcall(v44)
	if not v45 or type(v46) ~= "table" then
		v46 = nil
	end
	local v47 = nil
	local v48
	if v46 then
		local v49 = v46.touchRects
		if type(v49) == "function" then
			local v50 = v46.touchRects
			local v51
			v51, v48 = pcall(v50)
			if v51 then
				if type(v48) ~= "table" then
					v48 = v47
				end
			else
				v48 = v47
			end
		else
			v48 = v47
		end
	else
		v48 = v47
	end
	local v52
	if v48 then
		v52 = v48.moveStick
	else
		v52 = v48
	end
	local v53
	if v48 then
		v53 = v48.rightCluster
	else
		v53 = v48
	end
	if v48 then
		v48 = v48.quickBar
	end
	if typeof(v52) ~= "Rect" or typeof(v53) ~= "Rect" then
		return v40, v41, v42, false
	end
	local v_u_54 = Vector2.zero
	if p_u_35 then
		pcall(function()
			-- upvalues: (copy) p_u_35, (copy) v_u_39, (ref) v_u_54
			local v55 = p_u_35.AbsolutePosition
			if v55.X >= 0 and (v55.X < v_u_39.X / 4 and (v55.Y >= 0 and v55.Y < v_u_39.Y / 4)) then
				v_u_54 = v55
			end
		end)
	end
	local v56 = (v52.Max.X - v_u_54.X) / v38
	local v57 = (v53.Min.X - v_u_54.X) / v38 - 8
	if typeof(v48) == "Rect" and v48.Min.Y > v_u_39.Y * 0.4 then
		v42 = (v48.Min.Y - v_u_54.Y) / v38 - 8
	end
	return v56, v57, v42, true
end
local function v_u_77(p59) -- name: cardLayout
	-- upvalues: (ref) v_u_7, (copy) v_u_58
	local v60 = v_u_7.refSize()
	local v61 = v_u_7.isTouch()
	local v62 = {
		["touch"] = v61
	}
	if not v61 then
		v62.btnH = v_u_7.controlS
		v62.skipW = 152
		local v63 = v60.X - 32
		local v64 = math.clamp(v63, 320, 480)
		v62.W = math.floor(v64)
		v62.textW = v62.W - 32
		v62.counterY = 16
		v62.titleY = 40
		v62.bodyY = 64
		v62.bodyH = 32
		v62.rowY = v62.bodyY + v62.bodyH + 8
		v62.H = v62.rowY + v62.btnH + 16
		return v62
	end
	local v65, v66, v67, v68 = v_u_58(p59)
	v62.live = v68
	v62.gapKey = ("%d,%d,%d"):format(math.floor(v65), math.floor(v66), (math.floor(v67)))
	if v66 - v65 < 200 and not v68 then
		v65 = v60.X * 0.3
		v66 = v60.X * 0.7
	end
	local v69 = v66 - v65
	v62.btnH = v_u_7.touch(32)
	local v70 = (v65 + v66) / 2
	v62.cx = math.floor(v70)
	v62.bottom = math.floor(v67)
	if v69 >= 400 then
		v62.skipW = 104
		local v71 = math.min(v69, 520)
		v62.W = math.floor(v71)
		v62.textW = v62.W - 16 - 12 - v62.skipW - 16
		v62.segY = 16
		v62.counterY = 24
		v62.titleY = 24
		v62.titleH = 24
		v62.bodyY = 52
		v62.bodyH = 48
		v62.bodyW = v62.textW
		local v72 = v62.bodyY + v62.bodyH + 8
		local v73 = v62.btnH + 32
		v62.H = math.max(v72, v73)
		return v62
	end
	v62.narrow = true
	v62.skipW = 96
	local v74 = math.max(v69, 232)
	v62.W = math.floor(v74)
	if v69 < v62.W then
		local v75 = v66 - v62.W / 2
		v62.cx = math.floor(v75)
	end
	v62.textW = v62.W - 16 - 12 - v62.skipW - 16
	v62.segY = 16
	v62.counterY = 9
	v62.titleY = 28
	v62.titleH = 40
	v62.bodyY = 72
	v62.bodyH = 48
	v62.bodyW = v62.W - 32
	v62.H = 80
	v62.Hx = v62.bodyY + v62.bodyH + 12
	if v62.W < 280 then
		v62.tight = true
		local v76 = v62.W - 32
		v62.titleY = 66
		v62.titleH = 40
		v62.titleW = v76
		v62.bodyY = 110
		v62.H = 114
		v62.Hx = v62.bodyY + v62.bodyH + 12
	end
	v62.dynBody = true
	v62.HxMax = v62.bodyY + 96 + 12
	return v62
end
local function v_u_82() -- name: setSkipText
	-- upvalues: (ref) v_u_12, (ref) v_u_20
	if v_u_12 and v_u_12.skipApi then
		local v78 = os.clock() < v_u_20
		local v79 = v_u_12.L
		if v79 then
			v79 = v_u_12.L.touch
		end
		local v80 = v_u_12.skipApi.setText
		local v81
		if v78 then
			v81 = v79 and "Sure?" or "Confirm skip"
		else
			v81 = v79 and "Skip" or "Skip tutorial"
		end
		pcall(v80, v81)
	end
end
local function v_u_99(p83) -- name: buildHints
	-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
	if v_u_12 then
		for _, v84 in v_u_12.hints:GetChildren() do
			if not v84:IsA("GuiObject") then
				continue
			end
			v84:Destroy()
		end
		local v85 = {}
		for v86, v87 in p83.hints do
			local v88 = v87.action
			local v_u_89 = "Input"
			local function v90()
				-- upvalues: (ref) v_u_5, (copy) v_u_89
				return v_u_5.controllers[v_u_89]
			end
			local v91, v92 = pcall(v90)
			if not v91 or type(v92) ~= "table" then
				v92 = nil
			end
			local v93
			if v92 then
				local v94 = v92.hint
				if type(v94) == "function" then
					local v95 = v92.hint
					local v96, v97 = pcall(v95, v88)
					v93 = (not v96 or type(v97) ~= "string") and "" or v97
				else
					v93 = ""
				end
			else
				v93 = ""
			end
			if v93 == "" or v85[v93] then
				continue
			end
			v85[v93] = true
			local v98 = v_u_6.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Hint" .. v86,
				["Size"] = UDim2.fromOffset(0, 22),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = v86
			}, v_u_12.hints)
			v_u_6.layout(v98, "h", 6, nil)
			v_u_6.keyHint(v87.action, {
				["size"] = 20,
				["order"] = 1
			}).Parent = v98
			v_u_6.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v98,
				["text"] = v87.text,
				["color"] = v_u_7.color.text2,
				["size"] = UDim2.fromOffset(0, 22)
			})
		end
	end
end
local function v_u_148(p100) -- name: paintCard
	-- upvalues: (ref) v_u_12, (ref) v_u_15, (copy) v_u_10, (ref) v_u_16, (ref) v_u_8, (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_17, (ref) v_u_18, (ref) v_u_6, (ref) v_u_21, (copy) v_u_2, (ref) v_u_7, (copy) v_u_99
	if v_u_12 then
		local v101
		if v_u_15 then
			v101 = v_u_15
		else
			local v102 = v_u_10:GetAttribute("TutorialStep")
			if type(v102) == "number" and v102 >= 1 then
				v101 = math.floor(v102)
			else
				v101 = nil
			end
		end
		if v101 then
			local v103
			if v_u_15 then
				v103 = v_u_16
			else
				v103 = v_u_10:GetAttribute("TutorialSub")
			end
			local v104 = type(v103) ~= "string" and "" or v103
			local v105
			if v_u_8.view then
				v105 = v_u_8.view(v101, v103)
			else
				v105 = v_u_8.get(v101)
			end
			if v105 then
				local v_u_106 = "Input"
				local function v107()
					-- upvalues: (ref) v_u_5, (copy) v_u_106
					return v_u_5.controllers[v_u_106]
				end
				local v108, v109 = pcall(v107)
				if not v108 or type(v109) ~= "table" then
					v109 = nil
				end
				local v110
				if v109 then
					local v111 = v109.device
					if type(v111) == "function" then
						local v112 = v109.device
						local v113, v114 = pcall(v112)
						v110 = (not v113 or type(v114) ~= "string") and "" or v114
					else
						v110 = ""
					end
				else
					v110 = ""
				end
				if v101 ~= v_u_13 or (v104 ~= v_u_14 or (p100 or v110 ~= v_u_17)) then
					v_u_17 = v110
					if v101 ~= v_u_13 then
						v_u_18 = {}
					end
					v_u_13 = v101
					v_u_14 = v104
					local v115 = v_u_10:GetAttribute("TutorialPractice") == true
					local v116 = v_u_6.setText
					local v117 = v_u_12.counter
					local v118
					if v_u_12.L.touch then
						v118 = ("%d/%d"):format(v101, v_u_8.COUNT)
					else
						v118 = (not v115 and "Tutorial" or v_u_8.PRACTICE.tag) .. "  \194\183  " .. v_u_8.counter(v101)
					end
					v116(v117, v118)
					if v_u_12.practiceTag then
						local v119 = v_u_12.practiceTag
						if v115 then
							v115 = v_u_12.L.touch == true
						end
						v119.Visible = v115
					end
					v_u_6.setText(v_u_12.title, v105.title)
					local v120 = v_u_21
					local v121
					if type(v120) == "number" then
						v121 = v_u_2.now() - v_u_21 < 4.5
					else
						v121 = false
					end
					if not v121 then
						v_u_12.body.Text = v_u_8.bodyFor(v105, v110)
						v_u_12.body.TextColor3 = v_u_7.color.text2
					end
					v_u_99(v105)
					for v122, v123 in v_u_12.segs do
						local v124
						if v122 < v101 then
							v124 = v_u_7.color.accent
						elseif v122 == v101 then
							v124 = v_u_7.color.text
						else
							v124 = v_u_7.color.line
						end
						v123.BackgroundColor3 = v124
						v123.BackgroundTransparency = v122 <= v101 and 0 or 0.2
					end
					v_u_10:SetAttribute("TutorialCardStep", v101)
					v_u_12.expandUntil = os.clock() + 8
					local v125 = v_u_6.sound
					pcall(v125, "tick")
				end
				local v_u_126 = v_u_10:GetAttribute("TutorialNoteAt")
				local v127 = v_u_10:GetAttribute("TutorialNote")
				if type(v_u_126) == "number" and (type(v127) == "string" and (v_u_126 ~= v_u_21 and v_u_2.now() - v_u_126 < 4.5)) then
					v_u_21 = v_u_126
					local v128 = v_u_12
					local v129 = v_u_12.expandUntil
					local v130 = os.clock() + 4.5
					v128.expandUntil = math.max(v129, v130)
					v_u_12.body.Text = v127
					local v131 = v_u_12.body
					local v132
					if v_u_8.NOTE_WARN and v_u_8.NOTE_WARN[v127] then
						v132 = v_u_7.color.accent
					else
						v132 = v_u_7.color.success
					end
					v131.TextColor3 = v132
					task.delay(4.5, function()
						-- upvalues: (ref) v_u_12, (ref) v_u_21, (copy) v_u_126, (ref) v_u_8, (ref) v_u_13, (ref) v_u_14, (ref) v_u_5, (ref) v_u_7
						if v_u_12 and v_u_21 == v_u_126 then
							local v133
							if v_u_8.view then
								local v134 = v_u_8.view
								local v135 = v_u_13
								local v136
								if v_u_14 == "" then
									v136 = nil
								else
									v136 = v_u_14
								end
								v133 = v134(v135, v136)
							else
								v133 = v_u_8.get(v_u_13)
							end
							if v133 then
								local v137 = v_u_12.body
								local v138 = v_u_8.bodyFor
								local v_u_139 = "Input"
								local function v140()
									-- upvalues: (ref) v_u_5, (copy) v_u_139
									return v_u_5.controllers[v_u_139]
								end
								local v141, v142 = pcall(v140)
								if not v141 or type(v142) ~= "table" then
									v142 = nil
								end
								local v143
								if v142 then
									local v144 = v142.device
									if type(v144) == "function" then
										local v145 = v142.device
										local v146, v147 = pcall(v145)
										v143 = (not v146 or type(v147) ~= "string") and "" or v147
									else
										v143 = ""
									end
								else
									v143 = ""
								end
								v137.Text = v138(v133, v143)
								v_u_12.body.TextColor3 = v_u_7.color.text2
							end
						end
					end)
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_178(p149, p_u_150) -- name: touchButtonRect
	-- upvalues: (ref) v_u_5, (ref) v_u_7
	local v_u_151 = "Input"
	local function v152()
		-- upvalues: (ref) v_u_5, (copy) v_u_151
		return v_u_5.controllers[v_u_151]
	end
	local v153, v154 = pcall(v152)
	if not v153 or type(v154) ~= "table" then
		v154 = nil
	end
	if v154 then
		local v155 = v154.touch
		if type(v155) == "function" then
			local v156 = v154.touch
			local v157, v_u_158 = pcall(v156)
			if not v157 or (type(v_u_158) ~= "table" or v_u_158.visible == false) then
				return nil, nil
			end
			local v159 = v_u_158.buttons
			local v_u_160
			if type(v159) == "table" then
				v_u_160 = v_u_158.buttons[p149] or nil
			else
				v_u_160 = nil
			end
			if v_u_160 then
				v_u_160 = v_u_160.gui
			end
			if not v_u_160 or (typeof(v_u_160) ~= "Instance" or not (v_u_160:IsA("GuiObject") and (v_u_160.Visible and v_u_160.Parent))) then
				return nil, nil
			end
			local v161 = v_u_7.uiScale
			local v162 = math.max(0.1, v161())
			local v_u_163 = v_u_7.viewport()
			local v_u_164 = nil
			local v_u_165 = nil
			local function v172()
				-- upvalues: (copy) v_u_158, (copy) v_u_160, (ref) v_u_164, (ref) v_u_165
				local v166 = v_u_158.canvas
				local v167 = v_u_158.scale.Scale
				local v168 = v_u_160.Position
				local v169 = v_u_160.Size
				v_u_164 = Vector2.new((v168.X.Scale * v166.X + v168.X.Offset) * v167, (v168.Y.Scale * v166.Y + v168.Y.Offset) * v167)
				local v170 = v169.X.Offset
				local v171 = v169.Y.Offset
				v_u_165 = math.max(v170, v171) * v167
			end
			pcall(v172)
			if not v_u_164 then
				v_u_164 = v_u_160.AbsolutePosition + v_u_160.AbsoluteSize / 2
				local v173 = v_u_160.AbsoluteSize.X
				local v174 = v_u_160.AbsoluteSize.Y
				v_u_165 = math.max(v173, v174)
			end
			local v_u_175 = Vector2.zero
			local function v177()
				-- upvalues: (copy) p_u_150, (copy) v_u_163, (ref) v_u_175
				local v176 = p_u_150.AbsolutePosition
				if v176.X >= 0 and (v176.X < v_u_163.X / 4 and (v176.Y >= 0 and v176.Y < v_u_163.Y / 4)) then
					v_u_175 = v176
				end
			end
			pcall(v177)
			return (v_u_164 - v_u_175) / v162, v_u_165 / v162
		end
	end
	return nil, nil
end
local function v_u_254(p179, p180) -- name: buildActionHint
	-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_7, (ref) v_u_6, (ref) v_u_5
	local v181 = v_u_8.ACTIONS
	if v181 then
		v181 = v_u_8.ACTIONS[p179]
	end
	if not (v_u_12 and v181) then
		return nil
	end
	local v182 = v_u_7.color
	local v183 = v_u_12.root
	local v184 = string.upper(v181.text)
	local v185 = {
		["key"] = p179 .. "|" .. p180,
		["action"] = p179,
		["input"] = v181.input,
		["device"] = p180,
		["fills"] = {}
	}
	if p180 == "Touch" then
		v185.input = v181.touch or v181.input
		local v186 = v_u_6.new("Frame", {
			["Name"] = "ActionHint",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 20,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(80, 80)
		}, v183)
		local v187 = v_u_6.new("Frame", {
			["Name"] = "Ring",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(1, 1)
		}, v186)
		v_u_6.corner(v187, 2)
		v185.ringStroke = v_u_6.stroke(v187, v182.accent, 3)
		local v188 = v_u_6.new("Frame", {
			["Name"] = "Wave",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(1, 1)
		}, v186)
		v_u_6.corner(v188, 2)
		v185.waveStroke = v_u_6.stroke(v188, v182.accent, 2)
		local v189 = v_u_6.new("Frame", {
			["Name"] = "Tag",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 21,
			["BackgroundColor3"] = v182.bg,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 0, -10),
			["Size"] = UDim2.fromOffset(#v184 <= 9 and 88 or #v184 * 8 + 16, 22)
		}, v186)
		v_u_6.stroke(v189, v182.accent, 1)
		local v190 = v_u_6.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["parent"] = v189,
			["text"] = v184,
			["color"] = v182.accent,
			["size"] = UDim2.fromScale(1, 1)
		})
		v_u_6.new("UITextSizeConstraint", {
			["MaxTextSize"] = 14,
			["MinTextSize"] = nil,
			["MinTextSize"] = v_u_7.phoneText(9, "scaled")
		}, v190)
		v190.TextScaled = true
		v190.ZIndex = 22
		v185.holder = v186
		v185.ring = v187
		v185.wave = v188
		return v185
	end
	local v191 = v181.input
	local v_u_192 = "Input"
	local function v193()
		-- upvalues: (ref) v_u_5, (copy) v_u_192
		return v_u_5.controllers[v_u_192]
	end
	local v194, v195 = pcall(v193)
	if not v194 or type(v195) ~= "table" then
		v195 = nil
	end
	local v196
	if v195 then
		local v197 = v195.hint
		if type(v197) == "function" then
			local v198 = v195.hint
			local v199, v200 = pcall(v198, v191)
			v196 = (not v199 or type(v200) ~= "string") and "" or v200
		else
			v196 = ""
		end
	else
		v196 = ""
	end
	if v196 == "" and v181.alt then
		local v201 = v181.alt
		local v_u_202 = "Input"
		local function v203()
			-- upvalues: (ref) v_u_5, (copy) v_u_202
			return v_u_5.controllers[v_u_202]
		end
		local v204, v205 = pcall(v203)
		if not v204 or type(v205) ~= "table" then
			v205 = nil
		end
		if v205 then
			local v206 = v205.hint
			if type(v206) == "function" then
				local v207 = v205.hint
				local v208, v209 = pcall(v207, v201)
				v196 = (not v208 or type(v209) ~= "string") and "" or v209
			else
				v196 = ""
			end
		else
			v196 = ""
		end
	end
	local v210
	if v181.alt then
		local v211 = v181.alt
		local v_u_212 = "Input"
		local function v213()
			-- upvalues: (ref) v_u_5, (copy) v_u_212
			return v_u_5.controllers[v_u_212]
		end
		local v214, v215 = pcall(v213)
		if not v214 or type(v215) ~= "table" then
			v215 = nil
		end
		if v215 then
			local v216 = v215.hint
			if type(v216) == "function" then
				local v217 = v215.hint
				local v218, v219 = pcall(v217, v211)
				v210 = (not v218 or type(v219) ~= "string") and "" or v219
			else
				v210 = ""
			end
		else
			v210 = ""
		end
	else
		v210 = ""
	end
	local v220
	if v210 == "" or v210 == v196 then
		v220 = false
	else
		local v221 = v181.input
		local v_u_222 = "Input"
		local function v223()
			-- upvalues: (ref) v_u_5, (copy) v_u_222
			return v_u_5.controllers[v_u_222]
		end
		local v224, v225 = pcall(v223)
		if not v224 or type(v225) ~= "table" then
			v225 = nil
		end
		local v226
		if v225 then
			local v227 = v225.hint
			if type(v227) == "function" then
				local v228 = v225.hint
				local v229, v230 = pcall(v228, v221)
				v226 = (not v229 or type(v230) ~= "string") and "" or v230
			else
				v226 = ""
			end
		else
			v226 = ""
		end
		v220 = v226 ~= ""
	end
	local v231
	if p180 == "Keyboard" then
		v231 = v196 == "LMB" and true or v196 == "RMB"
	else
		v231 = false
	end
	local v232 = (v220 or #v184 > 12) and 380 or 232
	local v233 = v_u_6.new("Frame", {
		["Name"] = "ActionHint",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v182.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(v232, 74)
	}, v183)
	v_u_6.stroke(v233, v182.accent, 1)
	v185.scale = v_u_6.new("UIScale", {
		["Scale"] = 1
	}, v233)
	local v234 = 34
	if v231 then
		local v235, v236 = v_u_5.lib.InvUITutorialPick.drawMouse(v233)
		v235.Position = UDim2.fromOffset(18, 12)
		v185.fills = v236
		if v196 == "RMB" then
			v236[1].Position = UDim2.fromOffset(18, 3)
			v236[2].Position = UDim2.fromOffset(0, 0)
			v236[3].Position = UDim2.fromOffset(0, 9)
		end
	else
		local v237 = v_u_6.keyHint
		local v238 = v181.input
		local v_u_239 = "Input"
		local function v240()
			-- upvalues: (ref) v_u_5, (copy) v_u_239
			return v_u_5.controllers[v_u_239]
		end
		local v241, v242 = pcall(v240)
		if not v241 or type(v242) ~= "table" then
			v242 = nil
		end
		local v243
		if v242 then
			local v244 = v242.hint
			if type(v244) == "function" then
				local v245 = v242.hint
				local v246, v247 = pcall(v245, v238)
				v243 = (not v246 or type(v247) ~= "string") and "" or v247
			else
				v243 = ""
			end
		else
			v243 = ""
		end
		local v248
		if v243 == "" then
			v248 = v181.alt or v181.input
		else
			v248 = v181.input
		end
		local v249 = v237(v248, {
			["size"] = 34
		})
		v249.Position = UDim2.fromOffset(18, 20)
		v249.Parent = v233
		v185.chip = v249
		local v250 = v249.Size.X.Offset
		v234 = math.max(34, v250)
		if v220 then
			v_u_6.label({
				["parent"] = nil,
				["text"] = "or",
				["style"] = "small",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["position"] = nil,
				["parent"] = v233,
				["color"] = v182.text2,
				["size"] = UDim2.fromOffset(22, 34),
				["position"] = UDim2.fromOffset(v234 + 18 + 4, 20)
			})
			local v251 = v_u_6.keyHint(v181.alt, {
				["size"] = 34
			})
			v251.Position = UDim2.fromOffset(v234 + 18 + 30, 20)
			v251.Parent = v233
			v185.chip2 = v251
			local v252 = v251.Size.X.Offset
			v234 = v234 + (math.max(34, v252) + 30)
		end
	end
	local v253 = v234 + 18 + 16
	v_u_6.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h3",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v233,
		["text"] = v184,
		["color"] = v182.text,
		["size"] = UDim2.fromOffset(v232 - v253 - 12, 24),
		["position"] = UDim2.fromOffset(v253, 14)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	if v231 then
		v196 = v196 == "RMB" and "Right mouse button" or "Left mouse button"
	elseif v220 then
		v196 = v181.sub or "or " .. v210
	end
	v_u_6.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v233,
		["text"] = v196,
		["color"] = v182.accent,
		["size"] = UDim2.fromOffset(v232 - v253 - 12, 18),
		["position"] = UDim2.fromOffset(v253, 42)
	})
	v185.holder = v233
	return v185
end
local function v_u_290(_) -- name: updateActionHint
	-- upvalues: (ref) v_u_12, (ref) v_u_19, (copy) v_u_10, (ref) v_u_8, (ref) v_u_18, (ref) v_u_11, (ref) v_u_15, (ref) v_u_5, (ref) v_u_7, (copy) v_u_254, (copy) v_u_178
	if not v_u_12 then
		return
	end
	local v255
	if v_u_19 then
		v255 = v_u_19
	else
		v255 = v_u_10:GetAttribute("TutorialAction")
		if type(v255) ~= "string" or v255 == "" then
			v255 = nil
		end
	end
	local v256 = v255 and v_u_8.ACTIONS
	if v256 then
		v256 = v_u_8.ACTIONS[v255]
	end
	local v257 = v256 ~= nil and (v_u_12.frame.Visible and not v_u_18[v255])
	if v257 then
		v257 = (v_u_11 == "Raid" or v_u_15 ~= nil) and true or v_u_19 ~= nil
	end
	if not v257 then
		if v_u_12.actionHint then
			v_u_12.actionHint.holder.Visible = false
		end
		return
	end
	local v_u_258 = "Input"
	local function v259()
		-- upvalues: (ref) v_u_5, (copy) v_u_258
		return v_u_5.controllers[v_u_258]
	end
	local v260, v261 = pcall(v259)
	if not v260 or type(v261) ~= "table" then
		v261 = nil
	end
	local v262
	if v261 then
		local v263 = v261.device
		if type(v263) == "function" then
			local v264 = v261.device
			local v265
			v265, v262 = pcall(v264)
			if not v265 or type(v262) ~= "string" then
				v262 = v_u_7.isTouch() and "Touch" or "Keyboard"
			end
		else
			v262 = v_u_7.isTouch() and "Touch" or "Keyboard"
		end
	else
		v262 = v_u_7.isTouch() and "Touch" or "Keyboard"
	end
	local v266 = v255 .. "|" .. v262
	if not v_u_12.actionHint or (v_u_12.actionHint.key ~= v266 or not v_u_12.actionHint.holder.Parent) then
		if v_u_12 and v_u_12.actionHint then
			local function v267()
				-- upvalues: (ref) v_u_12
				v_u_12.actionHint.holder:Destroy()
			end
			pcall(v267)
			v_u_12.actionHint = nil
		end
		v_u_12.actionHint = v_u_254(v255, v262)
		if not v_u_12.actionHint then
			return
		end
	end
	local v268 = v_u_12.actionHint
	local v269 = os.clock()
	local v270 = v269 * 1.25 % 1
	local v271 = v269 * 3.141592653589793 * 2 * 1.4
	local v272 = math.cos(v271) * 0.5 + 0.5
	if v268.device == "Touch" then
		local v273, v274 = v_u_178(v268.input, v_u_12.root)
		if v273 and v274 then
			local v275 = v274 + 14
			v268.holder.Size = UDim2.fromOffset(v275, v275)
			local v276 = v268.holder
			local v277 = UDim2.fromOffset
			local v278 = v273.X + 0.5
			local v279 = math.floor(v278)
			local v280 = v273.Y + 0.5
			v276.Position = v277(v279, (math.floor(v280)))
			v268.ringStroke.Transparency = (1 - v272) * 0.15
			v268.wave.Size = UDim2.new(1 + v270 * 0.45, 0, 1 + v270 * 0.45, 0)
			local v281 = v268.waveStroke
			local v282 = 0.2 + v270 * 0.8
			v281.Transparency = math.clamp(v282, 0, 1)
			v268.holder.Visible = true
		else
			v268.holder.Visible = false
		end
	else
		local v283 = v_u_7.refSize()
		local v284 = v268.holder
		local v285 = UDim2.fromOffset
		local v286 = v283.X / 2
		local v287 = math.floor(v286)
		local v288 = v283.Y * 0.74
		v284.Position = v285(v287, (math.floor(v288)))
		for _, v289 in v268.fills do
			v289.BackgroundTransparency = (1 - v272) * 0.8
		end
		if v268.chip then
			v268.chip.BackgroundTransparency = (1 - v272) * 0.5 + 0.1
		end
		if v268.chip2 then
			v268.chip2.BackgroundTransparency = (1 - v272) * 0.5 + 0.1
		end
		v268.scale.Scale = v272 * 0.04 + 1
		v268.holder.Visible = true
		return
	end
end
local function v_u_344() -- name: buildCard
	-- upvalues: (copy) v_u_34, (ref) v_u_6, (ref) v_u_7, (copy) v_u_77, (ref) v_u_8, (ref) v_u_20, (ref) v_u_12, (copy) v_u_4, (copy) v_u_82, (copy) v_u_148, (copy) v_u_10, (ref) v_u_22
	v_u_34()
	local v291, v292 = v_u_6.screen("HushTutorial", v_u_7.layer.hud + 1)
	local v293 = v_u_77(v292)
	local v294 = v293.W
	local v295 = v293.H
	local v296 = v293.btnH
	local v297, v298 = v_u_6.panel({
		["parent"] = nil,
		["name"] = "TutorialCard",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["accent"] = true,
		["padding"] = false,
		["parent"] = v292,
		["size"] = UDim2.fromOffset(v294, v295),
		["position"] = UDim2.new(0.5, 0, 0, v_u_6.topInset() + 8),
		["anchor"] = Vector2.new(0.5, 0)
	})
	v297.Parent = v292
	local v299 = v_u_7.color
	local v300
	if v293.narrow then
		v300 = v293.textW - 40
	else
		v300 = v293.textW
	end
	local v301
	if v293.touch then
		local v302 = (v300 - (v_u_8.COUNT - 1) * 4) / v_u_8.COUNT
		v301 = math.floor(v302)
	else
		v301 = 16
	end
	local v303 = v_u_8.COUNT * v301 + (v_u_8.COUNT - 1) * 4
	local v304 = v293.touch and 16 or v294 - 16 - v303
	local v305
	if v293.touch then
		v305 = v293.segY
	else
		v305 = v293.counterY + 7
	end
	local v306 = v293.narrow and 32 or (v293.touch and 40 or v294 - 32 - v303 - 8)
	local v307 = not v293.narrow and 16 or 16 + v293.textW - v306
	local v308 = (not v293.touch or v293.narrow) and 16 or 16 + v306
	local v309 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Counter",
		["text"] = "Tutorial",
		["style"] = nil,
		["color"] = nil,
		["align"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v298,
		["style"] = v293.touch and "monoS" or "caps",
		["color"] = v299.accent,
		["align"] = v293.narrow and "right" or nil,
		["size"] = UDim2.fromOffset(v306, v293.touch and not v293.narrow and 24 or 16),
		["position"] = UDim2.fromOffset(v307, v293.counterY)
	})
	local v310 = v_u_6.new("Frame", {
		["Name"] = "Segments",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v304, v305),
		["Size"] = UDim2.fromOffset(v303, 3)
	}, v298)
	local v311 = {}
	for v312 = 1, v_u_8.COUNT do
		local v313 = v_u_6.new("Frame", {
			["Name"] = nil,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = "Seg" .. v312,
			["BackgroundColor3"] = v299.line,
			["Position"] = UDim2.fromOffset((v312 - 1) * (v301 + 4), 0),
			["Size"] = UDim2.fromOffset(v301, 3)
		}, v310)
		table.insert(v311, v313)
	end
	local v314 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "h3",
		["textSize"] = nil,
		["wrap"] = nil,
		["valign"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v298,
		["textSize"] = v293.narrow and 16 or nil,
		["wrap"] = v293.narrow == true,
		["valign"] = v293.narrow and "top" or nil,
		["size"] = UDim2.fromOffset(v293.titleW or v293.textW - (v308 - 16), v293.titleH or 24),
		["position"] = UDim2.fromOffset(v308, v293.titleY)
	})
	if v293.narrow then
		v314.TextTruncate = Enum.TextTruncate.AtEnd
	end
	local v315 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = "",
		["style"] = "small",
		["wrap"] = true,
		["valign"] = "top",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v298,
		["size"] = UDim2.fromOffset(v293.bodyW or v293.textW, v293.bodyH),
		["position"] = UDim2.fromOffset(16, v293.bodyY)
	})
	v315.TextTruncate = Enum.TextTruncate.AtEnd
	if v293.dynBody then
		v315.TextTruncate = Enum.TextTruncate.None
		v315.AutomaticSize = Enum.AutomaticSize.Y
	end
	local v316 = v_u_6.new
	local v317 = {
		["Name"] = "Hints",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Visible"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromOffset(16, (v293.rowY or 0) + v296 / 2)
	}
	local v318 = UDim2.fromOffset
	local v319 = v294 - 32 - v293.skipW - 16
	v317.Size = v318(math.max(0, v319), 22)
	v317.Visible = not v293.touch
	local v320 = v316("Frame", v317, v298)
	v_u_6.layout(v320, "h", 16, nil)
	local v321 = v_u_6.button
	local v322 = {
		["parent"] = nil,
		["name"] = "Skip",
		["text"] = "Skip tutorial",
		["kind"] = "close",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v298,
		["size"] = UDim2.fromOffset(v293.skipW, v296)
	}
	local v323
	if v293.tight then
		v323 = UDim2.new(1, -16, 0, 8)
	elseif v293.narrow then
		v323 = UDim2.new(1, -16, 0, 12)
	elseif v293.touch then
		v323 = UDim2.new(1, -16, 0.5, 0)
	else
		v323 = UDim2.new(1, -16, 0, v293.rowY)
	end
	v322.position = v323
	local v324
	if v293.touch and not v293.narrow then
		v324 = Vector2.new(1, 0.5)
	else
		v324 = Vector2.new(1, 0)
	end
	v322.anchor = v324
	function v322.onClick() -- name: onClick
		-- upvalues: (ref) v_u_20, (ref) v_u_12, (ref) v_u_4, (ref) v_u_82
		if os.clock() < v_u_20 then
			v_u_20 = 0
			if v_u_12 and v_u_12.skipApi then
				local v325 = os.clock() < v_u_20
				local v326 = v_u_12.L
				if v326 then
					v326 = v_u_12.L.touch
				end
				local v327 = v_u_12.skipApi.setText
				local v328
				if v325 then
					v328 = v326 and "Sure?" or "Confirm skip"
				else
					v328 = v326 and "Skip" or "Skip tutorial"
				end
				pcall(v327, v328)
			end
			v_u_4.skip()
		else
			v_u_20 = os.clock() + 3
			if v_u_12 and v_u_12.skipApi then
				local v329 = os.clock() < v_u_20
				local v330 = v_u_12.L
				if v330 then
					v330 = v_u_12.L.touch
				end
				local v331 = v_u_12.skipApi.setText
				local v332
				if v329 then
					v332 = v330 and "Sure?" or "Confirm skip"
				else
					v332 = v330 and "Skip" or "Skip tutorial"
				end
				pcall(v331, v332)
			end
			task.delay(3.05, v_u_82)
		end
	end
	local v333, v334 = v321(v322)
	local v335 = v_u_6.new("Frame", {
		["Name"] = "Marker",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(60, 44)
	}, v292)
	local v336 = v_u_6.new("Frame", {
		["Name"] = "Diamond",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = v299.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 9),
		["Size"] = UDim2.fromOffset(12, 12)
	}, v335)
	v_u_6.stroke(v336, v299.accent, 1.5)
	v_u_6.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v299.accent,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(4, 4)
	}, v336)
	local v337 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Dist",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v335,
		["color"] = v299.accent,
		["size"] = UDim2.new(1, 0, 0, 14),
		["position"] = UDim2.fromOffset(0, 22)
	})
	local v338 = v_u_6.label({
		["parent"] = nil,
		["name"] = "PracticeTag",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v297,
		["text"] = v_u_8.PRACTICE and v_u_8.PRACTICE.tag or "Practice run",
		["color"] = v299.accent,
		["size"] = UDim2.fromOffset(120, 18),
		["position"] = UDim2.new(0, 16, 0, -4),
		["anchor"] = Vector2.new(0, 1)
	})
	v338.BackgroundColor3 = v299.bg
	v338.BackgroundTransparency = 0.15
	v338.Visible = false
	v_u_12 = {
		["gui"] = nil,
		["root"] = nil,
		["frame"] = nil,
		["counter"] = nil,
		["title"] = nil,
		["body"] = nil,
		["hints"] = nil,
		["segs"] = nil,
		["skip"] = nil,
		["skipApi"] = nil,
		["marker"] = nil,
		["dist"] = nil,
		["practiceTag"] = nil,
		["L"] = nil,
		["expandUntil"] = 0,
		["gui"] = v291,
		["root"] = v292,
		["frame"] = v297,
		["counter"] = v309,
		["title"] = v314,
		["body"] = v315,
		["hints"] = v320,
		["segs"] = v311,
		["skip"] = v333,
		["skipApi"] = v334,
		["marker"] = v335,
		["dist"] = v337,
		["practiceTag"] = v338,
		["L"] = v293
	}
	v_u_20 = 0
	if v_u_12 and v_u_12.skipApi then
		local v339 = os.clock() < v_u_20
		local v340 = v_u_12.L
		if v340 then
			v340 = v_u_12.L.touch
		end
		local v341 = v_u_12.skipApi.setText
		local v342
		if v339 then
			v342 = v340 and "Sure?" or "Confirm skip"
		else
			v342 = v340 and "Skip" or "Skip tutorial"
		end
		pcall(v341, v342)
	end
	v_u_148(true)
	v_u_10:SetAttribute("TutorialCardShown", true)
	local v343
	if v293.touch then
		v343 = v293.bottom + v_u_7.motion.slide
	else
		v343 = v_u_6.topInset() + 8 + v_u_7.motion.slide
	end
	v_u_22 = v343
end
local function v_u_352() -- name: syncCard
	-- upvalues: (ref) v_u_15, (ref) v_u_11, (copy) v_u_10, (ref) v_u_12, (copy) v_u_344, (copy) v_u_34, (copy) v_u_148, (ref) v_u_9
	local v345
	if v_u_15 then
		v345 = true
	elseif v_u_11 == "Raid" then
		local v346
		if v_u_15 then
			v346 = v_u_15
		else
			local v347 = v_u_10:GetAttribute("TutorialStep")
			if type(v347) == "number" and v347 >= 1 then
				v346 = math.floor(v347)
			else
				v346 = nil
			end
		end
		v345 = v346 ~= nil
	else
		v345 = false
	end
	if v345 then
		if v_u_12 then
			v_u_148(false)
			return
		end
		local v348 = v_u_344
		local v349, v350 = pcall(v348)
		if not v349 then
			warn("[TutorialClient] card failed:", v350)
			v_u_10:SetAttribute("ClientError", "TutorialClient card: " .. tostring(v350))
			v_u_34()
			return
		end
	elseif v_u_12 then
		v_u_34()
		if v_u_9 then
			local v351 = v_u_9.clear
			pcall(v351)
		end
	end
end
local function v_u_359() -- name: toastHeight
	-- upvalues: (copy) v_u_10, (ref) v_u_7
	local v353 = v_u_10:FindFirstChildOfClass("PlayerGui")
	if v353 then
		v353 = v353:FindFirstChild("HushToast")
	end
	if v353 then
		v353 = v353:FindFirstChild("Toasts", true)
	end
	if not v353 then
		return 0
	end
	local v354 = v353:FindFirstChildOfClass("UIListLayout")
	local v355 = false
	for _, v356 in v353:GetChildren() do
		if not (v356:IsA("GuiObject") and v356.Visible) then
			continue
		end
		v355 = true
	end
	if not (v354 and v355) then
		return 0
	end
	local v357 = v354.AbsoluteContentSize.Y
	local v358 = v_u_7.uiScale
	return v357 / math.max(0.1, v358())
end
local function v_u_420(p360) -- name: updateCard
	-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_15, (ref) v_u_7, (copy) v_u_359, (ref) v_u_6, (ref) v_u_22, (copy) v_u_10, (ref) v_u_13
	if v_u_12 then
		local v_u_361 = "HUD"
		local function v362()
			-- upvalues: (ref) v_u_5, (copy) v_u_361
			return v_u_5.controllers[v_u_361]
		end
		local v363, v364 = pcall(v362)
		if not v363 or type(v364) ~= "table" then
			v364 = nil
		end
		local v365 = true
		if v364 then
			local v366 = v364.isVisible
			if type(v366) == "function" then
				local v367 = v364.isVisible
				local v368, v369 = pcall(v367)
				v365 = not v368 or v369 ~= false
			end
		end
		local v370 = v365 or v_u_15 ~= nil
		v_u_12.frame.Visible = v370
		if v_u_12.L.narrow then
			local v371 = os.clock() < v_u_12.expandUntil
			v_u_12.body.Visible = v371
			local v372 = v_u_12.L.Hx
			if v_u_12.L.dynBody then
				local v373 = v_u_12.L.bodyY
				local v374 = v_u_12.body.AbsoluteSize.Y
				local v375 = v_u_7.uiScale
				local v376 = v374 / math.max(0.1, v375()) - 0.05
				local v377 = v373 + math.ceil(v376) + 12
				local v378 = v_u_12.L.Hx
				local v379 = v_u_12.L.HxMax
				v372 = math.clamp(v377, v378, v379)
			end
			local v380 = v_u_12.frame
			local v381 = UDim2.fromOffset
			local v382 = v_u_12.L.W
			if not v371 then
				v372 = v_u_12.L.H
			end
			v380.Size = v381(v382, v372)
		end
		local v383 = v_u_12.L
		local v384
		if v383.touch then
			v384 = v383.bottom
		else
			local v385 = v_u_359()
			v384 = v_u_6.topInset() + 8 + (v385 <= 1 and 0 or v385 + 8)
		end
		if v_u_22 < 0 then
			v_u_22 = v384
		else
			local v386 = v_u_22
			local v387 = v384 - v_u_22
			local v388 = p360 * 12
			v_u_22 = v386 + v387 * math.clamp(v388, 0, 1)
		end
		if v383.touch then
			v_u_12.frame.AnchorPoint = Vector2.new(0.5, 1)
			local v389 = v_u_12.frame
			local v390 = UDim2.fromOffset
			local v391 = v383.cx
			local v392 = v_u_22 + 0.5
			v389.Position = v390(v391, (math.floor(v392)))
		else
			local v393 = v_u_12.frame
			local v394 = UDim2.new
			local v395 = v_u_22 + 0.5
			v393.Position = v394(0.5, 0, 0, (math.floor(v395)))
		end
		local v396 = v_u_10
		local v397 = v_u_22 + 0.5
		v396:SetAttribute("TutorialCardY", (math.floor(v397)))
		local v398 = v_u_10:GetAttribute("TutorialTarget")
		local v399 = v_u_12.marker
		if v370 and typeof(v398) == "Vector3" then
			local v400 = v_u_7.refSize()
			local v401, v402, v403, v404
			if v383.touch then
				v401 = v400.X * 0.18
				v402 = v400.X * 0.6
				v403 = v400.Y * 0.36
				v404 = v400.Y * 0.5
			else
				v402 = v400.X - 56
				v404 = v400.Y - 56
				v401 = 56
				v403 = 56
			end
			local v405, _, v406 = v_u_6.screenMarker(v398, v401, v403, v402, v404)
			local v407 = v_u_10.Character
			if v407 then
				v407 = v407:FindFirstChild("HumanoidRootPart")
			end
			local v408
			if v407 and v407:IsA("BasePart") then
				v408 = v407.Position
			else
				v408 = nil
			end
			local v409
			if v408 then
				local v410 = v398.X - v408.X
				local v411 = v398.Z - v408.Z
				v409 = Vector3.new(v410, 0, v411).Magnitude
			else
				v409 = (1 / 0)
			end
			if v406 and (v409 < 70 and (v_u_13 == 5 and v_u_10:GetAttribute("TutorialTargetKind") ~= "exit")) then
				v399.Visible = false
				return
			else
				local v412 = UDim2.fromOffset
				local v413 = v405.X + 0.5
				local v414 = math.floor(v413)
				local v415 = v405.Y + 0.5
				v399.Position = v412(v414, (math.floor(v415)))
				v399.Visible = true
				if v408 then
					local v416 = v_u_12.dist
					local v417
					if v409 < 3 then
						v417 = "HERE"
					else
						local v418 = string.format
						local v419 = v409 * 0.28 + 0.5
						v417 = v418("%d m", (math.floor(v419)))
					end
					v416.Text = v417
				else
					v_u_12.dist.Text = ""
				end
			end
		else
			v399.Visible = false
			return
		end
	else
		return
	end
end
local function v_u_428(p421, p422) -- name: openModal
	-- upvalues: (ref) v_u_27, (ref) v_u_6, (ref) v_u_29, (ref) v_u_28
	if v_u_27 or not v_u_6 then
		return
	else
		v_u_27 = true
		v_u_29 = p421
		local v_u_423 = p422.onClose
		local v_u_424 = nil
		function p422.onClose()
			-- upvalues: (ref) v_u_28, (ref) v_u_424, (ref) v_u_27, (ref) v_u_29, (copy) v_u_423
			if v_u_28 == v_u_424 then
				v_u_27 = false
				v_u_28 = nil
				v_u_29 = nil
			end
			if v_u_423 then
				v_u_423()
			end
		end
		local v425 = v_u_6.modal
		local v426, v427 = pcall(v425, p422)
		if v426 then
			v_u_424 = v427
			v_u_28 = v427
		else
			v_u_27 = false
			v_u_29 = nil
			warn("[TutorialClient] modal failed:", v427)
		end
	end
end
local function v_u_435(p429) -- name: closeModal
	-- upvalues: (ref) v_u_27, (ref) v_u_29, (ref) v_u_28
	if not v_u_27 or p429 and not (v_u_29 and p429[v_u_29]) then
		return false
	end
	local v430 = v_u_28
	v_u_27 = false
	v_u_28 = nil
	v_u_29 = nil
	if type(v430) == "table" then
		local v431 = v430.close
		if type(v431) == "function" then
			local v432 = v430.close
			local v433, v434 = pcall(v432)
			if not v433 then
				warn("[TutorialClient] modal close failed:", v434)
			end
		end
	end
	return true
end
local v_u_436 = {
	["offer"] = true,
	["failed"] = true
}
local function v_u_437() -- name: closeStaleOffer
	-- upvalues: (copy) v_u_10, (copy) v_u_435, (copy) v_u_436, (ref) v_u_29
	if v_u_10:GetAttribute("TutorialDone") == true or (v_u_10:GetAttribute("TutorialStep") ~= nil and true or v_u_10:GetAttribute("Tutorial") == true) then
		return v_u_435(v_u_436)
	elseif v_u_29 == "offer" and v_u_10:GetAttribute("MenuTutorialCard") == true then
		return v_u_435({
			["offer"] = true
		})
	else
		return false
	end
end
local function v_u_447() -- name: itemsText
	-- upvalues: (ref) v_u_5, (ref) v_u_8
	local v438 = {}
	local v_u_439 = nil
	local function v440()
		-- upvalues: (ref) v_u_439, (ref) v_u_5
		v_u_439 = v_u_5.shared.Items
	end
	pcall(v440)
	local v441 = v_u_439
	for _, v442 in v_u_8.REWARD.items do
		local v443 = v441 and v441.get
		if v443 then
			v443 = v441.get(v442.id)
		end
		local v444 = "%dx %s"
		local v445 = v442.n
		local v446
		if v443 and v443.name then
			v446 = v443.name
		else
			v446 = v442.id
		end
		table.insert(v438, v444:format(v445, v446))
	end
	return table.concat(v438, ", ")
end
local function v_u_467(p448, p_u_449) -- name: showResult
	-- upvalues: (ref) v_u_9, (ref) v_u_32, (copy) v_u_428, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_447, (ref) v_u_5, (copy) v_u_4
	if v_u_9 then
		local v450 = v_u_9.clear
		pcall(v450)
	end
	v_u_32 = p_u_449
	if p448 == "complete" then
		v_u_428("complete", {
			["title"] = "Tutorial complete",
			["body"] = nil,
			["width"] = 540,
			["build"] = nil,
			["buttons"] = nil,
			["body"] = "You made it out. Everything you carried out is in your stash. " .. v_u_8.STEPS[6].body,
			["build"] = p_u_449 > 0 and function(p451)
				-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) p_u_449, (ref) v_u_447
				local v452 = v_u_7.color
				local v_u_453 = v_u_6.new("Frame", {
					["Name"] = "Reward",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["BackgroundColor3"] = v452.raised,
					["BackgroundTransparency"] = v_u_7.alpha.raised,
					["Size"] = UDim2.new(1, 0, 0, 64)
				}, p451)
				v_u_6.stroke(v_u_453, v452.line)
				local function v460(p454, p455, p456, p457, p458, p459) -- name: stat
					-- upvalues: (ref) v_u_6, (copy) v_u_453
					v_u_6.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "micro",
						["size"] = nil,
						["position"] = nil,
						["parent"] = v_u_453,
						["text"] = p456,
						["size"] = UDim2.fromOffset(p455, 16),
						["position"] = UDim2.fromOffset(p454, 12)
					})
					v_u_6.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = nil,
						["color"] = nil,
						["valign"] = "bottom",
						["size"] = nil,
						["position"] = nil,
						["parent"] = v_u_453,
						["text"] = p457,
						["style"] = p458,
						["color"] = p459,
						["size"] = UDim2.fromOffset(p455, 24),
						["position"] = UDim2.fromOffset(p454, 28)
					})
				end
				v460(16, 152, "Cash", "+$" .. v_u_6.commas(p_u_449), "monoL", v452.success)
				v_u_6.new("Frame", {
					["Name"] = "Rule",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v452.line,
					["Position"] = UDim2.fromOffset(176, 12),
					["Size"] = UDim2.fromOffset(1, 40)
				}, v_u_453)
				v460(192, 280, "Supplies", v_u_447(), "bodyStrong", v452.text)
			end or nil,
			["buttons"] = {
				{
					["text"] = "Continue",
					["kind"] = "secondary"
				},
				{
					["text"] = "Open tasks",
					["kind"] = "primary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_5
						local v_u_461 = "Menu"
						local function v462()
							-- upvalues: (ref) v_u_5, (copy) v_u_461
							return v_u_5.controllers[v_u_461]
						end
						local v463, v464 = pcall(v462)
						if not v463 or type(v464) ~= "table" then
							v464 = nil
						end
						if v464 then
							local v465 = v464.setTab
							if type(v465) == "function" then
								local v466 = v464.setTab
								pcall(v466, "tasks")
							end
						end
					end
				}
			}
		})
	elseif p448 == "failed" then
		v_u_428("failed", {
			["title"] = "Tutorial not finished",
			["body"] = nil,
			["width"] = 540,
			["buttons"] = nil,
			["body"] = "Nothing was lost: the tutorial raid never puts your own gear at risk. Run it again, or skip it and deploy for real. " .. (not v_u_8 and "" or v_u_8.skipLine()),
			["buttons"] = {
				{
					["text"] = "Skip",
					["kind"] = "secondary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_4
						v_u_4.skip()
					end
				},
				{
					["text"] = "Try again",
					["kind"] = "primary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_4
						v_u_4.begin()
					end
				}
			}
		})
	end
end
local function v_u_468() -- name: showOffer
	-- upvalues: (copy) v_u_428, (ref) v_u_8, (copy) v_u_4
	v_u_428("offer", {
		["title"] = "First time in Stillwater?",
		["body"] = nil,
		["width"] = 540,
		["buttons"] = nil,
		["body"] = "A five-minute night raid at the edge of town teaches you searching, quiet kills, noise and extracting. Nothing of yours is at stake. " .. (not v_u_8 and "" or v_u_8.skipLine()),
		["buttons"] = {
			{
				["text"] = "Skip",
				["kind"] = "secondary",
				["onClick"] = nil,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_4
					v_u_4.skip()
				end
			},
			{
				["text"] = "Start tutorial",
				["kind"] = "primary",
				["onClick"] = nil,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_4
					v_u_4.begin()
				end
			}
		}
	})
end
local function v_u_474() -- name: updateMenu
	-- upvalues: (ref) v_u_27, (copy) v_u_437, (ref) v_u_11, (copy) v_u_10, (ref) v_u_26, (ref) v_u_25, (ref) v_u_24, (copy) v_u_467, (ref) v_u_31, (copy) v_u_468
	if v_u_27 then
		v_u_437()
	end
	if v_u_11 == "Menu" and not v_u_27 then
		if v_u_10:GetAttribute("MenuReady") == true then
			local v469 = v_u_10:FindFirstChildOfClass("PlayerGui")
			if v469 then
				v469 = v469:FindFirstChild("Debrief", true)
			end
			local v470 = v469 ~= nil and v469:IsA("GuiObject")
			if v470 then
				v470 = v469.Visible
			end
			if not v470 then
				local v471 = v_u_10:GetAttribute("TutorialResultId")
				if type(v471) == "number" and v_u_26 < v471 then
					v_u_26 = v471
					local v472 = v_u_10:GetAttribute("TutorialResult")
					local v473 = v_u_10:GetAttribute("TutorialRewardCash")
					v_u_25 = v_u_24
					if v472 ~= "practice" then
						v_u_467(tostring(v472), type(v473) ~= "number" and 0 or v473)
					end
				else
					if v_u_25 < 0 and (not v_u_31 and (v_u_10:GetAttribute("TutorialDone") == false and v_u_10:GetAttribute("MenuTutorialCard") ~= true)) then
						v_u_25 = v_u_24
						v_u_468()
					end
					return
				end
			end
		end
	end
end
local function v_u_484() -- name: rebuildUi
	-- upvalues: (ref) v_u_12, (copy) v_u_344, (copy) v_u_34, (ref) v_u_27, (ref) v_u_29, (ref) v_u_28, (copy) v_u_468, (copy) v_u_467, (ref) v_u_32
	if v_u_12 then
		local v475 = v_u_344
		local v476, v477 = pcall(v475)
		if not v476 then
			warn("[TutorialClient] card rebuild failed:", v477)
			v_u_34()
		end
	end
	if v_u_27 and v_u_29 then
		local v478 = v_u_29
		if v_u_27 then
			local v479 = v_u_28
			v_u_27 = false
			v_u_28 = nil
			v_u_29 = nil
			if type(v479) == "table" then
				local v480 = v479.close
				if type(v480) == "function" then
					local v481 = v479.close
					local v482, v483 = pcall(v481)
					if not v482 then
						warn("[TutorialClient] modal close failed:", v483)
					end
				end
			end
		end
		if v478 == "offer" then
			v_u_468()
			return
		end
		v_u_467(v478, v_u_32)
	end
end
function v_u_4.begin() -- name: begin
	-- upvalues: (ref) v_u_30, (ref) v_u_11, (ref) v_u_5, (ref) v_u_8
	if os.clock() - v_u_30 < 2 then
		return false
	end
	if v_u_11 ~= "Menu" and v_u_11 ~= "Hideout" then
		return false
	end
	v_u_30 = os.clock()
	v_u_5.emit("transit.info", {
		["kind"] = "deploy",
		["map"] = "Stillwater",
		["difficulty"] = "Normal",
		["timeOfDay"] = nil,
		["tutorial"] = true,
		["timeOfDay"] = v_u_8.TIME_OF_DAY
	})
	local v_u_485 = "start"
	local v_u_486 = nil
	task.spawn(function()
		-- upvalues: (copy) v_u_485, (copy) v_u_486, (ref) v_u_5
		local v487 = {
			["op"] = v_u_485
		}
		for v488, v489 in v_u_486 or {} do
			v487[v488] = v489
		end
		local v490 = v_u_5.net.fire
		local v491, v492 = pcall(v490, "tutorial.op", v487)
		if not v491 then
			warn("[TutorialClient] tutorial.op failed:", v492)
		end
	end)
	return true
end
function v_u_4.skip() -- name: skip
	-- upvalues: (ref) v_u_5
	local v_u_493 = "skip"
	local v_u_494 = nil
	task.spawn(function()
		-- upvalues: (copy) v_u_493, (copy) v_u_494, (ref) v_u_5
		local v495 = {
			["op"] = v_u_493
		}
		for v496, v497 in v_u_494 or {} do
			v495[v496] = v497
		end
		local v498 = v_u_5.net.fire
		local v499, v500 = pcall(v498, "tutorial.op", v495)
		if not v499 then
			warn("[TutorialClient] tutorial.op failed:", v500)
		end
	end)
	return true
end
function v_u_4.replay() -- name: replay
	-- upvalues: (ref) v_u_30, (ref) v_u_11, (ref) v_u_5, (ref) v_u_8
	if os.clock() - v_u_30 < 2 then
		return false
	end
	if v_u_11 ~= "Menu" and v_u_11 ~= "Hideout" then
		return false
	end
	v_u_30 = os.clock()
	v_u_5.emit("transit.info", {
		["kind"] = "deploy",
		["map"] = "Stillwater",
		["difficulty"] = "Normal",
		["timeOfDay"] = nil,
		["tutorial"] = true,
		["practice"] = true,
		["timeOfDay"] = v_u_8.TIME_OF_DAY
	})
	local v_u_501 = {
		["replay"] = true
	}
	local v_u_502 = "start"
	task.spawn(function()
		-- upvalues: (copy) v_u_502, (copy) v_u_501, (ref) v_u_5
		local v503 = {
			["op"] = v_u_502
		}
		for v504, v505 in v_u_501 or {} do
			v503[v504] = v505
		end
		local v506 = v_u_5.net.fire
		local v507, v508 = pcall(v506, "tutorial.op", v503)
		if not v507 then
			warn("[TutorialClient] tutorial.op failed:", v508)
		end
	end)
	return true
end
function v_u_4.dismissOffer() -- name: dismissOffer
	-- upvalues: (ref) v_u_5
	local v_u_509 = "dismissOffer"
	local v_u_510 = nil
	task.spawn(function()
		-- upvalues: (copy) v_u_509, (copy) v_u_510, (ref) v_u_5
		local v511 = {
			["op"] = v_u_509
		}
		for v512, v513 in v_u_510 or {} do
			v511[v512] = v513
		end
		local v514 = v_u_5.net.fire
		local v515, v516 = pcall(v514, "tutorial.op", v511)
		if not v515 then
			warn("[TutorialClient] tutorial.op failed:", v516)
		end
	end)
	return true
end
function v_u_4.offerNew() -- name: offerNew
	-- upvalues: (copy) v_u_10
	return v_u_10:GetAttribute("TutorialOfferNew") == true
end
function v_u_4.offered() -- name: offered
	-- upvalues: (copy) v_u_10
	return v_u_10:GetAttribute("TutorialDone") == false
end
function v_u_4.isActive() -- name: isActive
	-- upvalues: (ref) v_u_11, (copy) v_u_10
	local v517
	if v_u_11 == "Raid" then
		v517 = v_u_10:GetAttribute("TutorialStep") ~= nil
	else
		v517 = false
	end
	return v517
end
function v_u_4.claimMenuCard(p518) -- name: claimMenuCard
	-- upvalues: (copy) v_u_10
	v_u_10:SetAttribute("MenuTutorialCard", p518 ~= false and true or nil)
end
local function v_u_527(p519, p520) -- name: onPlace
	-- upvalues: (ref) v_u_11, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_24, (ref) v_u_31, (ref) v_u_23, (ref) v_u_15, (ref) v_u_9, (copy) v_u_352
	v_u_11 = p519
	if p519 ~= p520 and (p519 ~= "Menu" and v_u_27) then
		local v521 = v_u_28
		v_u_27 = false
		v_u_28 = nil
		v_u_29 = nil
		if type(v521) == "table" then
			local v522 = v521.close
			if type(v522) == "function" then
				local v523 = v521.close
				local v524, v525 = pcall(v523)
				if not v524 then
					warn("[TutorialClient] modal close failed:", v525)
				end
			end
		end
	end
	if p519 == "Menu" then
		v_u_24 = v_u_24 + 1
		v_u_31 = false
		v_u_23 = -1.5
	end
	if p519 ~= "Raid" then
		v_u_15 = nil
		if v_u_9 then
			local v526 = v_u_9.clear
			pcall(v526)
		end
	end
	v_u_352()
end
local function v_u_549() -- name: cardMetrics
	-- upvalues: (ref) v_u_12, (copy) v_u_10, (ref) v_u_13
	if not v_u_12 then
		return "no card"
	end
	local v528 = {}
	local v529 = true
	for _, v530 in {
		"counter",
		"title",
		"body",
		"dist"
	} do
		local v531 = v_u_12[v530]
		if not v531 or (not v531:IsA("TextLabel") or (v531.Text == "" or v531.TextFits)) then
			continue
		end
		table.insert(v528, v530)
		v529 = false
	end
	local v532 = v_u_12.skipApi
	if v532 then
		v532 = v_u_12.skipApi.label
	end
	if v532 and (v532:IsA("TextLabel") and not v532.TextFits) then
		table.insert(v528, "skip")
		v529 = false
	end
	v_u_10:SetAttribute("TutorialCardFits", v529)
	local v533 = v_u_12.frame
	local v534 = v_u_13
	local v535 = v533.AbsoluteSize.X
	local v536 = v533.AbsoluteSize.Y
	local v537 = v533.AbsolutePosition.X
	local v538 = v533.AbsolutePosition.Y
	local v539 = tostring(v529)
	local v540 = #v528 <= 0 and "" or " bad=" .. table.concat(v528, ",")
	local v541 = v_u_12.skip.AbsoluteSize.X
	local v542 = v_u_12.skip.AbsoluteSize.Y
	local v543 = v_u_12.marker.Visible
	local v544 = tostring(v543)
	local v545 = v_u_12.dist.Text
	local v546 = v_u_12.L.gapKey or "-"
	local v547 = tostring(v546)
	local v548 = v_u_12.L.live == true
	return ("step=%d size=%dx%d pos=%d,%d fits=%s%s skipSize=%dx%d marker=%s %s gap=%s live=%s"):format(v534, v535, v536, v537, v538, v539, v540, v541, v542, v544, v545, v547, (tostring(v548)))
end
function v_u_4.init(p_u_550) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_31, (copy) v_u_484, (ref) v_u_12, (copy) v_u_58, (copy) v_u_344, (copy) v_u_34, (copy) v_u_549, (ref) v_u_19, (copy) v_u_10, (ref) v_u_18, (ref) v_u_15, (ref) v_u_16, (copy) v_u_352, (copy) v_u_148, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (copy) v_u_468, (copy) v_u_467
	v_u_5 = p_u_550
	v_u_8 = p_u_550.shared.TutorialSteps
	v_u_7 = p_u_550.shared.Theme
	v_u_6 = p_u_550.lib.HushUI
	if v_u_6 and v_u_6.bind then
		local v551 = v_u_6.bind
		pcall(v551, p_u_550)
	end
	local v552, v553 = pcall(function()
		-- upvalues: (copy) p_u_550
		return p_u_550.lib.TutorialWorldFx
	end)
	if not v552 or type(v553) ~= "table" then
		v553 = nil
	end
	v_u_9 = v553
	task.spawn(function()
		-- upvalues: (copy) p_u_550, (ref) v_u_6
		local function v558()
			-- upvalues: (ref) p_u_550, (ref) v_u_6
			p_u_550.net.listen("tutorial.result", function(p554)
				-- upvalues: (ref) v_u_6
				if type(p554) == "table" then
					if p554.ok == false then
						local v555 = p554.msg
						if type(v555) == "string" then
							local v556 = p554.msg
							if v_u_6 then
								local v557 = v_u_6.toast
								pcall(v557, v556, "warn", nil)
							end
						end
					end
				end
			end)
		end
		local v559, v560 = pcall(v558)
		if not v559 then
			warn("[TutorialClient] tutorial.result:", v560)
		end
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_550, (ref) v_u_31
		local function v561()
			-- upvalues: (ref) p_u_550, (ref) v_u_31
			p_u_550.net.listen("raid.debrief", function()
				-- upvalues: (ref) v_u_31
				v_u_31 = true
			end)
		end
		pcall(v561)
	end)
	p_u_550.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_484
		v_u_484()
	end)
	local v562 = p_u_550.on
	local function v569()
		-- upvalues: (ref) v_u_12, (ref) v_u_58, (ref) v_u_344, (ref) v_u_34
		if v_u_12 and (v_u_12.L and v_u_12.L.touch) then
			local v563, v564, v565 = v_u_58(v_u_12.root)
			if ("%d,%d,%d"):format(math.floor(v563), math.floor(v564), (math.floor(v565))) ~= v_u_12.L.gapKey then
				local v566 = v_u_344
				local v567, v568 = pcall(v566)
				if not v567 then
					warn("[TutorialClient] card relayout failed:", v568)
					v_u_34()
				end
			end
		end
	end
	pcall(v562, "touch.layout", v569)
	p_u_550.command("tutorial.card", function()
		-- upvalues: (ref) v_u_549
		return v_u_549()
	end)
	for _, v_u_570 in { "weapon.melee", "weapon.fired", "weapon.reload" } do
		local v571 = p_u_550.on
		local function v575()
			-- upvalues: (copy) v_u_570, (ref) v_u_19, (ref) v_u_10, (ref) v_u_8, (ref) v_u_18
			local v572 = v_u_570
			local v573
			if v_u_19 then
				v573 = v_u_19
			else
				v573 = v_u_10:GetAttribute("TutorialAction")
				if type(v573) ~= "string" or v573 == "" then
					v573 = nil
				end
			end
			local v574 = v573 and v_u_8.ACTIONS
			if v574 then
				v574 = v_u_8.ACTIONS[v573]
			end
			if v574 and table.find(v574.events, v572) then
				v_u_18[v573] = true
				if v_u_19 == v573 then
					v_u_19 = nil
				end
			end
		end
		pcall(v571, v_u_570, v575)
	end
	p_u_550.command("tutorial.action", function(p576)
		-- upvalues: (ref) v_u_19, (ref) v_u_8, (ref) v_u_18, (ref) v_u_12, (ref) v_u_10, (ref) v_u_5, (ref) v_u_7
		local v577 = p576[1]
		if not v577 or (v577 == "off" or not v_u_8.ACTIONS[v577]) then
			v577 = nil
		end
		v_u_19 = v577
		v_u_18 = {}
		local v578 = v_u_12
		if v578 then
			v578 = v_u_12.actionHint
		end
		if v578 then
			v578 = v578.holder
		end
		local v579 = "action=%s server=%s device=%s hint=%s shown=%s pos=%s size=%s err=%s"
		local v580 = v_u_19
		local v581 = tostring(v580)
		local v582 = v_u_10
		local v583 = tostring(v582:GetAttribute("TutorialAction"))
		local v_u_584 = "Input"
		local function v585()
			-- upvalues: (ref) v_u_5, (copy) v_u_584
			return v_u_5.controllers[v_u_584]
		end
		local v586, v587 = pcall(v585)
		if not v586 or type(v587) ~= "table" then
			v587 = nil
		end
		local v588
		if v587 then
			local v589 = v587.device
			if type(v589) == "function" then
				local v590 = v587.device
				local v591
				v591, v588 = pcall(v590)
				if not v591 or type(v588) ~= "string" then
					v588 = v_u_7.isTouch() and "Touch" or "Keyboard"
				end
			else
				v588 = v_u_7.isTouch() and "Touch" or "Keyboard"
			end
		else
			v588 = v_u_7.isTouch() and "Touch" or "Keyboard"
		end
		local v592
		if v_u_19 then
			local v593 = v_u_8.ACTIONS[v_u_19].input
			local v_u_594 = "Input"
			local function v595()
				-- upvalues: (ref) v_u_5, (copy) v_u_594
				return v_u_5.controllers[v_u_594]
			end
			local v596, v597 = pcall(v595)
			if not v596 or type(v597) ~= "table" then
				v597 = nil
			end
			if v597 then
				local v598 = v597.hint
				if type(v598) == "function" then
					local v599 = v597.hint
					local v600, v601 = pcall(v599, v593)
					v592 = (not v600 or type(v601) ~= "string") and "" or v601
				else
					v592 = ""
				end
			else
				v592 = ""
			end
		else
			v592 = "-"
		end
		local v602
		if v578 == nil then
			v602 = false
		else
			v602 = v578.Visible
		end
		local v603 = tostring(v602)
		local v604 = not v578 and "-" or ("%d,%d"):format(v578.AbsolutePosition.X, v578.AbsolutePosition.Y)
		local v605 = not v578 and "-" or ("%dx%d"):format(v578.AbsoluteSize.X, v578.AbsoluteSize.Y)
		local v606 = v_u_12
		if v606 then
			v606 = v_u_12.actionHintError
		end
		return v579:format(v581, v583, v588, v592, v603, v604, v605, (tostring(v606)))
	end)
	p_u_550.command("tutorial.preview", function(p607)
		-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_352, (ref) v_u_148, (ref) v_u_9, (ref) v_u_549
		local v608 = p607[1]
		local v609 = tonumber(v608) or 1
		local v610 = math.floor(v609)
		v_u_15 = math.clamp(v610, 1, 5)
		local v611
		if p607[2] and p607[2] ~= "" then
			v611 = p607[2]
		else
			v611 = nil
		end
		v_u_16 = v611
		v_u_352()
		v_u_148(true)
		if v_u_9 and (v_u_15 == 4 and v_u_16 == "outside") then
			local v612 = v_u_9.showBanner
			pcall(v612, true)
		end
		local v613 = v_u_15
		return "preview step " .. tostring(v613) .. ": " .. v_u_549()
	end)
	p_u_550.command("tutorial.hide", function()
		-- upvalues: (ref) v_u_15, (ref) v_u_352, (ref) v_u_12
		v_u_15 = nil
		v_u_352()
		return "card " .. (v_u_12 and "kept (tutorial running)" or "hidden")
	end)
	p_u_550.command("tutorial.offer", function()
		-- upvalues: (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_468
		if v_u_27 then
			local v614 = v_u_28
			v_u_27 = false
			v_u_28 = nil
			v_u_29 = nil
			if type(v614) == "table" then
				local v615 = v614.close
				if type(v615) == "function" then
					local v616 = v614.close
					local v617, v618 = pcall(v616)
					if not v617 then
						warn("[TutorialClient] modal close failed:", v618)
					end
				end
			end
		end
		v_u_468()
		return "offer shown"
	end)
	p_u_550.command("tutorial.modal", function()
		-- upvalues: (ref) v_u_28, (ref) v_u_27, (ref) v_u_29
		local v619 = v_u_28
		if v619 then
			v619 = v_u_28.frame
		end
		local v620 = "open=%s kind=%s frame=%s"
		local v621 = v_u_27
		local v622 = tostring(v621)
		local v623 = v_u_29
		local v624 = tostring(v623)
		local v625
		if v619 == nil then
			v625 = false
		else
			v625 = v619.Parent ~= nil
		end
		return v620:format(v622, v624, (tostring(v625)))
	end)
	p_u_550.command("tutorial.result", function(p626)
		-- upvalues: (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_467, (ref) v_u_8
		if v_u_27 then
			local v627 = v_u_28
			v_u_27 = false
			v_u_28 = nil
			v_u_29 = nil
			if type(v627) == "table" then
				local v628 = v627.close
				if type(v628) == "function" then
					local v629 = v627.close
					local v630, v631 = pcall(v629)
					if not v630 then
						warn("[TutorialClient] modal close failed:", v631)
					end
				end
			end
		end
		v_u_467(p626[1] or "complete", v_u_8.REWARD.cash)
		local v632 = p626[1] or "complete"
		return "result card " .. tostring(v632)
	end)
	p_u_550.command("onboarding.gate", function(p633)
		-- upvalues: (ref) v_u_5, (ref) v_u_10
		local function v634()
			-- upvalues: (ref) v_u_5
			return v_u_5.lib.MenuTutorialCard
		end
		local v635, v636 = pcall(v634)
		local v637
		if v635 and type(v636) == "table" then
			v637 = v636.lastMc or nil
		else
			v637 = nil
		end
		if not v637 then
			return "no menu card yet (open PLAY once)"
		end
		if p633[1] ~= "state" then
			v637.gateForce = true
			local v638 = v636.gateDeploy(v637, function()
				-- upvalues: (ref) v_u_10
				v_u_10:SetAttribute("OnboardingGateTest", "deploy anyway")
			end)
			return "gate shown=" .. tostring(v638)
		end
		local v639 = v636.firstRaid
		local v640 = tostring(v639(v637))
		local v641 = v637.firstRaidGateDeclined == true
		local v642 = tostring(v641)
		local v643 = v637.firstRaidGateOpen == true
		local v644 = tostring(v643)
		local v645 = v636.state
		return ("firstRaid=%s declined=%s open=%s state=%s"):format(v640, v642, v644, (tostring(v645(v637))))
	end)
	p_u_550.command("onboarding.coach", function(p646)
		-- upvalues: (ref) v_u_5
		local function v647()
			-- upvalues: (ref) v_u_5
			return v_u_5.lib.HUDExtractCoach
		end
		local v648, v649 = pcall(v647)
		local v650
		if v648 and type(v649) == "table" then
			v650 = v649.current or nil
		else
			v650 = nil
		end
		if not v650 then
			return "no coach (raid HUD not mounted)"
		end
		local v651 = p646[1] or "state"
		if v651 == "state" then
			return v650.state()
		end
		local v652 = v650.force
		return ("forced %s=%s | %s"):format(v651, tostring(v652(v651)), v650.state())
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_5, (copy) v_u_527, (copy) v_u_10, (copy) v_u_352, (copy) v_u_437, (ref) v_u_12, (copy) v_u_148
	v_u_5.session.onPlaceChanged(v_u_527)
	for _, v653 in {
		"TutorialStep",
		"Tutorial",
		"TutorialNoteAt",
		"TutorialSub"
	} do
		v_u_10:GetAttributeChangedSignal(v653):Connect(function()
			-- upvalues: (ref) v_u_352, (ref) v_u_437
			v_u_352()
			v_u_437()
		end)
	end
	v_u_10:GetAttributeChangedSignal("TutorialPractice"):Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_148
		if v_u_12 then
			v_u_148(true)
		end
	end)
	for _, v654 in { "TutorialDone", "MenuTutorialCard" } do
		v_u_10:GetAttributeChangedSignal(v654):Connect(function()
			-- upvalues: (ref) v_u_437
			v_u_437()
		end)
	end
end
function v_u_4.step(p655) -- name: step
	-- upvalues: (ref) v_u_9, (copy) v_u_10, (ref) v_u_12, (copy) v_u_420, (copy) v_u_290, (ref) v_u_11, (ref) v_u_23, (copy) v_u_474
	if v_u_9 then
		local v656 = v_u_9.step
		local v657, v658 = pcall(v656, p655)
		if not v657 then
			v_u_10:SetAttribute("ClientError", "TutorialWorldFx: " .. tostring(v658))
		end
	end
	if v_u_12 then
		v_u_420(p655)
		local v659 = v_u_290
		local v660, v661 = pcall(v659, p655)
		if not v660 and v_u_12 then
			v_u_12.actionHintError = tostring(v661)
		end
	end
	if v_u_11 == "Menu" then
		v_u_23 = v_u_23 + p655
		if v_u_23 >= 0.5 then
			v_u_23 = 0
			v_u_474()
		end
	end
end
return v_u_4