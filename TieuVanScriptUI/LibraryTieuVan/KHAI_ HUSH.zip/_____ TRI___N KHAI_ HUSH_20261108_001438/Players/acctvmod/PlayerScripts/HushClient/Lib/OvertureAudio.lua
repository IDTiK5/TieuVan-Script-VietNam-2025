-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / OvertureAudio

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = {
	["PLATE_OF"] = {
		["nw_lobby"] = "P",
		["core_u1"] = "U1",
		["nw_legal"] = "U1",
		["core_u2"] = "U2",
		["nw_stacks"] = "U2",
		["core_t"] = "T",
		["nw_founders"] = "T",
		["core_p"] = "T",
		["core_roof"] = "R",
		["nw_roof"] = "R",
		["nw_garage"] = "G",
		["svc_tunnel"] = "G",
		["p3_garage"] = "G",
		["y_fleet"] = "G",
		["h1_garage"] = "G",
		["a_vault"] = "V",
		["core_a"] = "V",
		["a_studios"] = "A",
		["hall_foyer"] = "F",
		["hall_main"] = "F"
	}
}
local v7 = {
	["S"] = {
		["strings"] = 1,
		["piano"] = 0.8,
		["choir"] = 1,
		["finale"] = 1,
		["beds"] = nil,
		["beds"] = {}
	},
	["B"] = {
		["strings"] = 0.3,
		["piano"] = 0.3,
		["choir"] = 0.4,
		["finale"] = 0.4,
		["beds"] = nil,
		["beds"] = {}
	},
	["P"] = {
		["strings"] = 0,
		["piano"] = 0.45,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_fan"] = 0.4
		}
	},
	["U1"] = {
		["strings"] = 0,
		["piano"] = 0,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_hum"] = 0.5
		}
	},
	["U2"] = {
		["strings"] = 0,
		["piano"] = 0,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["ov_tape"] = 1,
			["amb_room"] = 0.3,
			["ov_murmur"] = 0.15
		}
	},
	["T"] = {
		["strings"] = 0,
		["piano"] = 0.25,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_room"] = 0.4
		}
	},
	["R"] = {
		["strings"] = 0.3,
		["piano"] = 0,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_wind"] = 0.5,
			["amb_radio"] = 0.3
		}
	},
	["G"] = {
		["strings"] = 0,
		["piano"] = 0,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_hum"] = 0.5
		}
	},
	["V"] = {
		["strings"] = 0,
		["piano"] = 0,
		["choir"] = 0,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["ov_tape"] = 0.7,
			["amb_room"] = 0.3
		}
	},
	["A"] = {
		["strings"] = 0.3,
		["piano"] = 0.5,
		["choir"] = 0.3,
		["finale"] = 0,
		["beds"] = nil,
		["beds"] = {
			["amb_room"] = 0.2
		}
	},
	["F"] = {
		["strings"] = 1.4,
		["piano"] = 1.1,
		["choir"] = 1.3,
		["finale"] = 1.4,
		["beds"] = nil,
		["beds"] = {
			["ov_murmur"] = 0.4
		}
	}
}
v_u_6.MIX = v7
function v_u_6.harbor(p8) -- name: harbor
	local v9 = (p8 - 250) / 130
	return math.clamp(v9, 0, 1) * 0.9
end
function v_u_6.level(p10) -- name: level
	return (type(p10) ~= "number" or p10 ~= p10) and 0.55 or math.clamp(p10, 0, 1) * 0.45 + 0.55
end
local v_u_11 = nil
function v_u_6.plateAt(p12, p13) -- name: plateAt
	-- upvalues: (ref) v_u_11, (copy) v_u_6
	if v_u_11 == nil then
		local v14, v15 = pcall(function()
			return require(script.Parent:WaitForChild("OvertureMapData", 5))
		end)
		if not v14 or type(v15) ~= "table" then
			v15 = false
		end
		v_u_11 = v15
	end
	local v16 = v_u_11 or nil
	if not v16 or (type(p12) ~= "number" or type(p13) ~= "number") then
		return "S"
	end
	local v17 = (1 / 0)
	local v18 = nil
	for _, v19 in v16.LOTS do
		local v20 = v19[6] / 2
		local v21 = v19[7] / 2
		local v22 = p12 - v19[4]
		if math.abs(v22) > v20 then
			continue
		end
		local v23 = p13 - v19[5]
		if math.abs(v23) > v21 then
			continue
		end
		local v24 = v19[6] * v19[7]
		if v24 >= v17 then
			continue
		end
		v18 = v19[1]
		v17 = v24
	end
	return v18 and (v_u_6.PLATE_OF[v18] or "B") or "S"
end
function v_u_6.plan(p25) -- name: plan
	-- upvalues: (copy) v_u_6
	local v26 = p25.act
	local v27 = type(v26) ~= "number" and 0 or p25.act
	if v27 >= 3 then
		return {
			["beds"] = nil,
			["music"] = nil,
			["silent"] = true,
			["beds"] = {},
			["music"] = {
				["strings"] = 0,
				["piano"] = 0,
				["choir"] = 0,
				["finale"] = 0
			}
		}
	end
	local v28 = v_u_6.MIX[p25.plate] or v_u_6.MIX.S
	local v29 = v_u_6.level(p25.frac)
	local v30 = {
		["strings"] = 0.9 * v29 * v28.strings,
		["piano"] = 0.8 * v29 * v28.piano,
		["choir"] = v27 < 1 and 0 or 0.85 * v29 * v28.choir,
		["finale"] = v27 < 2 and 0 or 0.9 * v29 * v28.finale
	}
	local v31 = {}
	for v32, v33 in v28.beds do
		v31[v32] = v33
	end
	if p25.plate == "S" then
		local v34 = p25.z
		if type(v34) == "number" then
			local v35 = v_u_6.harbor(p25.z)
			if v35 > 0.02 then
				v31.ov_harbor = v35
			end
		end
	end
	return {
		["beds"] = nil,
		["music"] = nil,
		["silent"] = false,
		["beds"] = v31,
		["music"] = v30
	}
end
local v_u_36 = false
local v_u_37 = nil
local v_u_38 = {}
local v_u_39 = {}
local v_u_40 = 0
local v_u_41 = -1
local v_u_42 = 0
local v_u_43 = 0
local v_u_44 = false
local v_u_45 = nil
local v_u_46 = ""
local function v_u_57(p_u_47, p_u_48, p_u_49) -- name: setBed
	-- upvalues: (ref) v_u_45, (copy) v_u_38
	local v50 = v_u_45
	local v_u_51 = v50 and (v50.controllers and v50.controllers.Audio) or nil
	if v_u_51 then
		local v_u_52 = v_u_38[p_u_47]
		if p_u_48 > 0.01 then
			if v_u_52 then
				local v53 = v_u_52.vol - p_u_48
				if math.abs(v53) > 0.03 then
					v_u_52.vol = p_u_48
					pcall(function()
						-- upvalues: (copy) v_u_52, (copy) p_u_48, (copy) p_u_49
						v_u_52.bed:SetVolume(p_u_48, p_u_49 or 1.2)
					end)
					return
				end
			else
				local v55, v56 = pcall(function()
					-- upvalues: (copy) v_u_51, (copy) p_u_47, (copy) p_u_48
					local v54 = {
						["volume"] = nil,
						["fadeIn"] = 2,
						["volume"] = p_u_48
					}
					return v_u_51.loop(p_u_47, nil, v54)
				end)
				if v55 and v56 then
					v_u_38[p_u_47] = {
						["bed"] = v56,
						["vol"] = p_u_48
					}
					return
				end
			end
		elseif v_u_52 then
			v_u_38[p_u_47] = nil
			pcall(function()
				-- upvalues: (copy) v_u_52, (copy) p_u_49
				v_u_52.bed:Stop(p_u_49 or 1.5)
			end)
		end
	end
end
local function v_u_66(p_u_58, p_u_59, p60) -- name: setPos
	-- upvalues: (ref) v_u_45, (copy) v_u_39
	local v61 = v_u_45
	local v_u_62 = v61 and (v61.controllers and v61.controllers.Audio) or nil
	if v_u_62 then
		local v_u_63 = v_u_39[p_u_58]
		if p60 and not v_u_63 then
			local v64, v65 = pcall(function()
				-- upvalues: (copy) v_u_62, (copy) p_u_58, (copy) p_u_59
				return v_u_62.loop(p_u_58, p_u_59, {
					["volume"] = 1,
					["fadeIn"] = 1.5
				})
			end)
			if v64 and v65 then
				v_u_39[p_u_58] = {
					["bed"] = v65
				}
				return
			end
		elseif not p60 and v_u_63 then
			v_u_39[p_u_58] = nil
			pcall(function()
				-- upvalues: (copy) v_u_63
				v_u_63.bed:Stop(1.5)
			end)
		end
	end
end
local function v_u_72(p_u_67) -- name: stopAll
	-- upvalues: (copy) v_u_38, (copy) v_u_39
	for v68, v_u_69 in v_u_38 do
		v_u_38[v68] = nil
		pcall(function()
			-- upvalues: (copy) v_u_69, (copy) p_u_67
			v_u_69.bed:Stop(p_u_67)
		end)
	end
	for v70, v_u_71 in v_u_39 do
		v_u_39[v70] = nil
		pcall(function()
			-- upvalues: (copy) v_u_71, (copy) p_u_67
			v_u_71.bed:Stop(p_u_67)
		end)
	end
end
local function v_u_115() -- name: step
	-- upvalues: (copy) v_u_3, (copy) v_u_38, (copy) v_u_39, (ref) v_u_44, (copy) v_u_72, (ref) v_u_45, (ref) v_u_41, (ref) v_u_46, (copy) v_u_2, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6, (copy) v_u_57, (ref) v_u_11, (copy) v_u_66, (ref) v_u_42, (ref) v_u_43
	local v73 = v_u_3:FindFirstChild("HushRuntime")
	if v73 then
		v73 = v73:FindFirstChild("Raid")
	end
	if not v73 or (v73:GetAttribute("MapId") ~= "overture" or v73:GetAttribute("Ready") ~= true) then
		v73 = nil
	end
	if v73 then
		local v74 = v_u_45
		local v_u_75 = v74 and (v74.controllers and v74.controllers.Audio) or nil
		if v_u_75 then
			local v76 = v_u_2.LocalPlayer
			if v76 then
				v76 = v_u_2.LocalPlayer.Character
			end
			if v76 then
				v76 = v76:FindFirstChild("HumanoidRootPart")
			end
			local v77
			if v76 and v76:IsA("BasePart") then
				v77 = v76.Position
			else
				local v78 = v_u_5.CurrentCamera
				if v78 then
					v77 = v78.CFrame.Position
				else
					v77 = nil
				end
			end
			if v77 then
				local v79 = v73:GetAttribute("OvertureAct")
				local v80 = type(v79) ~= "number" and 0 or v79
				local v81 = v73:GetAttribute("StartedAt")
				local v82 = v73:GetAttribute("EndsAt")
				local v83 = (type(v81) ~= "number" or (type(v82) ~= "number" or v81 >= v82)) and 0 or (v_u_1.now() - v81) / (v82 - v81)
				local v84 = v_u_6.plateAt(v77.X, v77.Z)
				local v85 = v_u_6.plan({
					["frac"] = v83,
					["act"] = v80,
					["plate"] = v84,
					["z"] = v77.Z
				})
				if not (v_u_44 or v85.silent) then
					local v86 = v_u_75.musicState
					if type(v86) == "function" then
						local v87 = v_u_75.setMusicState
						if type(v87) == "function" then
							v_u_44 = true
							local v88 = v_u_75.setMusicState
							pcall(v88, "silent")
						end
					end
				end
				if v85.silent then
					if v_u_41 ~= 3 then
						v_u_72(0.05)
					end
					v_u_41 = 3
					v_u_46 = ("%s|3|silent"):format(v84)
					local v89 = v_u_2.LocalPlayer
					if v89 then
						v89:SetAttribute("OvertureAudio", v_u_46)
					end
				else
					if v80 ~= v_u_41 then
						if v80 == 2 and v_u_41 >= 0 then
							pcall(function()
								-- upvalues: (copy) v_u_75
								v_u_75.play("ov_sting", {
									["volume"] = 0.9
								})
							end)
						end
						v_u_41 = v80
					end
					v_u_57("ov_strings", v85.music.strings, 2)
					v_u_57("ov_piano", v85.music.piano, 2)
					v_u_57("ov_choir", v85.music.choir, 2.5)
					v_u_57("ov_finale", v85.music.finale, 2.5)
					local v90 = v85.beds
					for _, v91 in {
						"amb_fan",
						"amb_hum",
						"ov_tape",
						"amb_room",
						"ov_murmur",
						"amb_wind",
						"amb_radio",
						"ov_harbor"
					} do
						v_u_57(v91, v90[v91] or 0, 1.5)
					end
					if v_u_11 == nil then
						local v92, v93 = pcall(function()
							return require(script.Parent:WaitForChild("OvertureMapData", 5))
						end)
						if not v92 or type(v93) ~= "table" then
							v93 = false
						end
						v_u_11 = v93
					end
					local v94 = v_u_11 or nil
					if v94 then
						v94 = v94.PLACES.nw_legal
					end
					local v95
					if v94 then
						local v96 = v94[1]
						local v97 = v94[2]
						v95 = Vector3.new(v96, 3, v97)
					else
						v95 = nil
					end
					local v98 = v_u_66
					local v99 = "ov_teleprinter"
					local v100 = v95 or Vector3.new(0, 0, 0)
					local v101
					if v95 == nil then
						v101 = false
					else
						v101 = (v77 - v95).Magnitude < 160
					end
					v98(v99, v100, v101)
					local v102 = os.clock()
					if v84 == "S" then
						if v_u_42 <= v102 then
							v_u_42 = v102 + 40
							pcall(function()
								-- upvalues: (copy) v_u_75
								v_u_75.play3D("ov_foghorn", Vector3.new(490, 24, 484), {
									["volume"] = 1
								})
							end)
						end
						local v103 = v77.X
						if math.abs(v103) < 170 and (v77.Z > -60 and (v77.Z < 222 and v_u_43 <= v102)) then
							v_u_43 = v102 + math.random(60, 120)
							pcall(function()
								-- upvalues: (copy) v_u_75
								local v104 = v_u_75.play3D
								local v105 = math.random(-90, 90)
								local v106 = math.random
								v104("ov_feedback", Vector3.new(v105, 12, v106(0, 160)), {
									["volume"] = 1
								})
							end)
						end
					end
					v_u_46 = ("%s|%d|%.2f|%s"):format(v84, v80, v_u_6.level(v83), (function()
						-- upvalues: (ref) v_u_38
						local v107 = {}
						for v108 in v_u_38 do
							table.insert(v107, v108)
						end
						table.sort(v107)
						return table.concat(v107, ",")
					end)())
					local v109 = v_u_2.LocalPlayer
					if v109 then
						v109:SetAttribute("OvertureAudio", v_u_46)
					end
				end
			else
				return
			end
		else
			return
		end
	else
		if next(v_u_38) ~= nil or (next(v_u_39) ~= nil or v_u_44) then
			v_u_72(1.5)
			if v_u_44 then
				v_u_44 = false
				local v110 = v_u_45
				local v111 = v110 and (v110.controllers and v110.controllers.Audio) or nil
				if v111 then
					local v112 = v111.musicState
					if type(v112) == "function" and v111.musicState() == "silent" then
						local v113 = v111.setMusicState
						pcall(v113, "auto")
					end
				end
			end
		end
		v_u_41 = -1
		if v_u_46 ~= "" then
			v_u_46 = ""
			local v114 = v_u_2.LocalPlayer
			if v114 then
				v114:SetAttribute("OvertureAudio", nil)
			end
		end
		return
	end
end
local function v_u_141() -- name: genStep
	-- upvalues: (copy) v_u_3, (ref) v_u_45, (ref) v_u_41, (ref) v_u_11, (copy) v_u_39
	local v116 = v_u_3:FindFirstChild("HushRuntime")
	if v116 then
		v116 = v116:FindFirstChild("Raid")
	end
	if not v116 or (v116:GetAttribute("MapId") ~= "overture" or v116:GetAttribute("Ready") ~= true) then
		v116 = nil
	end
	local v117 = v_u_45
	local v_u_118 = v117 and (v117.controllers and v117.controllers.Audio) or nil
	if v_u_118 and v_u_41 ~= 3 then
		local v119
		if v116 == nil then
			v119 = false
		else
			v119 = v116:GetAttribute("PowerG1") == true
		end
		local v120
		if v116 == nil then
			v120 = false
		else
			v120 = v116:GetAttribute("PowerG2") == true
		end
		if v_u_11 == nil then
			local v121, v122 = pcall(function()
				return require(script.Parent:WaitForChild("OvertureMapData", 5))
			end)
			if not v121 or type(v122) ~= "table" then
				v122 = false
			end
			v_u_11 = v122
		end
		local v123 = v_u_11 or nil
		if v123 then
			v123 = v123.PLACES.d_gen
		end
		local v124
		if v123 then
			local v125 = v123[1]
			local v126 = v123[2]
			v124 = Vector3.new(v125, 3, v126)
		else
			v124 = nil
		end
		if v_u_11 == nil then
			local v127, v128 = pcall(function()
				return require(script.Parent:WaitForChild("OvertureMapData", 5))
			end)
			if not v127 or type(v128) ~= "table" then
				v128 = false
			end
			v_u_11 = v128
		end
		local v129 = v_u_11 or nil
		if v129 then
			v129 = v129.PLACES.nw_garage
		end
		local v130
		if v129 then
			local v131 = v129[1]
			local v132 = v129[2]
			v130 = Vector3.new(v131, 3, v132)
		else
			v130 = nil
		end
		local function v140(p133, p_u_134, p135) -- name: gen
			-- upvalues: (ref) v_u_39, (copy) v_u_118
			local v_u_136 = v_u_39[p133]
			if p135 and (p_u_134 and not v_u_136) then
				local function v137()
					-- upvalues: (ref) v_u_118, (copy) p_u_134
					return v_u_118.loop("ov_generator", p_u_134, {
						["volume"] = 1,
						["fadeIn"] = 1.5
					})
				end
				local v138, v139 = pcall(v137)
				if v138 and v139 then
					v_u_39[p133] = {
						["bed"] = v139
					}
					return
				end
			elseif not (p135 and p_u_134) and v_u_136 then
				v_u_39[p133] = nil
				pcall(function()
					-- upvalues: (copy) v_u_136
					v_u_136.bed:Stop(1.5)
				end)
			end
		end
		v140("gen1", v124, v119)
		v140("gen2", v130, v120)
	end
end
function v_u_6.status() -- name: status
	-- upvalues: (ref) v_u_46
	return v_u_46
end
function v_u_6.stop() -- name: stop
	-- upvalues: (copy) v_u_72, (ref) v_u_44, (ref) v_u_45, (ref) v_u_41, (ref) v_u_37, (ref) v_u_36
	v_u_72(0.5)
	if v_u_44 then
		v_u_44 = false
		local v142 = v_u_45
		local v143 = v142 and (v142.controllers and v142.controllers.Audio) or nil
		if v143 then
			local v144 = v143.musicState
			if type(v144) == "function" and v143.musicState() == "silent" then
				local v145 = v143.setMusicState
				pcall(v145, "auto")
			end
		end
	end
	v_u_41 = -1
	if v_u_37 then
		v_u_37:Disconnect()
		v_u_37 = nil
	end
	v_u_36 = false
end
function v_u_6.start(p146) -- name: start
	-- upvalues: (ref) v_u_45, (ref) v_u_36, (ref) v_u_37, (copy) v_u_4, (ref) v_u_40, (copy) v_u_115, (copy) v_u_141
	v_u_45 = p146
	if not v_u_36 then
		v_u_36 = true
		local v_u_147 = 0
		v_u_37 = v_u_4.Heartbeat:Connect(function(p148)
			-- upvalues: (ref) v_u_40, (ref) v_u_147, (ref) v_u_115, (ref) v_u_141
			v_u_40 = v_u_40 + p148
			v_u_147 = v_u_147 + p148
			if v_u_40 >= 0.5 then
				v_u_40 = 0
				local v149 = v_u_115
				local v150, v151 = pcall(v149)
				if not v150 then
					warn("[OvertureAudio]", v151)
				end
			end
			if v_u_147 >= 1 then
				v_u_147 = 0
				local v152 = v_u_141
				pcall(v152)
			end
		end)
	end
end
return v_u_6