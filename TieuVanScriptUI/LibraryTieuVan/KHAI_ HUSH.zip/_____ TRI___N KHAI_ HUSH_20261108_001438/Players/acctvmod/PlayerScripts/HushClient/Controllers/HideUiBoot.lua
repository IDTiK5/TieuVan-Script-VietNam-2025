-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / HideUiBoot

return {
	["name"] = "HideUiBoot",
	["order"] = 92,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.HideUi.start(p_u_1)
		end)
		if not v2 then
			warn("[HideUiBoot] the interface switch failed to start:", v3)
			p_u_1.player:SetAttribute("ClientError", "hideui: " .. tostring(v3))
		end
	end
}