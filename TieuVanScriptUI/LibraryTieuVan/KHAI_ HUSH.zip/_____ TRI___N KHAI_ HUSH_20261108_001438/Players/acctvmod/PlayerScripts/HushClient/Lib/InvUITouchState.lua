-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITouchState

local v_u_1 = {}
v_u_1.__index = v_u_1
v_u_1.HOLD = 0.25
v_u_1.SLOP = 14
v_u_1.TOL = 0.03
v_u_1.STALE = 1.5
function v_u_1.new(p2, p3) -- name: new
	-- upvalues: (copy) v_u_1
	local v4 = {
		["state"] = "idle",
		["hold"] = nil,
		["slop"] = nil,
		["id"] = nil,
		["x0"] = 0,
		["y0"] = 0,
		["x"] = 0,
		["y"] = 0,
		["t0"] = 0,
		["instant"] = false,
		["watch"] = nil,
		["reason"] = nil,
		["hold"] = p2 or v_u_1.HOLD,
		["slop"] = p3 or v_u_1.SLOP
	}
	local v5 = v_u_1
	return setmetatable(v4, v5)
end
function v_u_1.heal(p6, p7, p8) -- name: heal
	-- upvalues: (copy) v_u_1
	local v9 = p6.state
	if (v9 == "dragging" or v9 == "parked") and not p7 then
		p6.state = "idle"
		p6.id = nil
		p6.watch = nil
		p6.instant = false
		return "orphan " .. v9
	else
		if v9 ~= "pressing" or p8 - p6.t0 <= v_u_1.STALE then
			return nil
		end
		p6.state = "idle"
		p6.id = nil
		p6.instant = false
		return "stale press"
	end
end
function v_u_1.press(p10, p11, p12, p13, p14, p15) -- name: press
	-- upvalues: (copy) v_u_1
	if p10.state == "pressing" and p14 - p10.t0 > v_u_1.STALE then
		p10.state = "idle"
		p10.id = nil
	end
	if p10.state ~= "idle" then
		if p10.state ~= "parked" then
			return "ignore"
		end
		p10.watch = {
			["id"] = p11,
			["x"] = p12,
			["y"] = p13
		}
		return "watch"
	end
	local v16 = p15 == true
	p10.state = "pressing"
	p10.id = p11
	p10.x0 = p12
	p10.y0 = p13
	p10.x = p12
	p10.y = p13
	p10.t0 = p14
	p10.instant = v16
	p10.watch = nil
	return "pressing"
end
function v_u_1.begin(p17, p18, p19, p20) -- name: begin
	p17.state = "dragging"
	p17.id = p18
	p17.watch = nil
	p17.instant = false
	local v21 = p19 or p17.x
	local v22 = p20 or p17.y
	p17.x = v21
	p17.y = v22
	return "dragging"
end
function v_u_1.grab(p23, p24, p25, p26) -- name: grab
	if p23.state ~= "parked" then
		return "ignore"
	end
	p23.state = "dragging"
	p23.id = p24
	p23.x = p25
	p23.y = p26
	p23.watch = nil
	return "grab"
end
function v_u_1.tick(p27, p28) -- name: tick
	-- upvalues: (copy) v_u_1
	if p27.state ~= "pressing" or p28 - p27.t0 < p27.hold - v_u_1.TOL then
		return nil
	end
	p27.state = "dragging"
	p27.instant = false
	return "pickup"
end
function v_u_1.move(p29, p30, p31, p32) -- name: move
	local v33 = p29.state
	if v33 == "pressing" and p30 == p29.id then
		p29.x = p31
		p29.y = p32
		local v34 = p29.x0
		local v35 = p29.y0
		local v36 = p31 - v34
		local v37 = p32 - v35
		local v38 = v36 * v36 + v37 * v37
		if math.sqrt(v38) > p29.slop then
			if p29.instant then
				p29.state = "dragging"
				p29.instant = false
				return "pickup"
			else
				p29.state = "idle"
				p29.id = nil
				return "swipe"
			end
		else
			return nil
		end
	else
		if v33 ~= "dragging" or p30 ~= p29.id then
			if v33 == "parked" and (p29.watch and p30 == p29.watch.id) then
				local v39 = p29.watch.x
				local v40 = p29.watch.y
				local v41 = p31 - v39
				local v42 = p32 - v40
				local v43 = v41 * v41 + v42 * v42
				if math.sqrt(v43) > p29.slop then
					p29.watch = nil
					return "swipe"
				end
			end
			return nil
		end
		p29.x = p31
		p29.y = p32
		return "move"
	end
end
function v_u_1.lift(p44, p45) -- name: lift
	if p44.state == "pressing" and p45 == p44.id then
		p44.state = "idle"
		p44.id = nil
		return "tap"
	else
		if p44.state ~= "parked" or (not p44.watch or p45 ~= p44.watch.id) then
			return p44.state == "dragging" and p45 == p44.id and "up" or nil
		end
		p44.watch = nil
		return "watchend"
	end
end
function v_u_1.decide(p46) -- name: decide
	return p46.action and "action" or (p46.valid and "drop" or (p46.canPark == false and "keep" or "park"))
end
function v_u_1.finish(p47, p48) -- name: finish
	-- upvalues: (copy) v_u_1
	if p47.state ~= "dragging" then
		if p47.state ~= "parked" or not p48.action then
			return nil
		end
		p47.state = "idle"
		p47.id = nil
		p47.watch = nil
		return "action"
	end
	local v49 = v_u_1.decide(p48)
	if v49 ~= "park" then
		p47.state = "idle"
		p47.id = nil
		return v49
	end
	p47.state = "parked"
	p47.id = nil
	p47.watch = nil
	return v49
end
function v_u_1.cancel(p50, p51) -- name: cancel
	local v52 = p50.state
	p50.state = "idle"
	p50.id = nil
	p50.watch = nil
	p50.instant = false
	if v52 ~= "dragging" and v52 ~= "parked" then
		return v52 == "pressing" and "abort" or nil
	end
	p50.reason = p51 or "cancel"
	return "cancel"
end
function v_u_1.rotate(p53) -- name: rotate
	return (p53.state == "dragging" or p53.state == "parked") and "rotate" or nil
end
function v_u_1.holding(p54) -- name: holding
	return p54.state == "dragging" and true or p54.state == "parked"
end
return v_u_1