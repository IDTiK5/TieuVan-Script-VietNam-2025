-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ClanTagText

local v_u_1 = {
	["_mode"] = nil,
	["_tag"] = nil,
	["_gm"] = nil
}
local v_u_2 = {
	["tag"] = nil,
	["gm"] = nil,
	["style"] = nil
}
function v_u_1.enabled() -- name: enabled
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if v_u_1._mode == nil then
		local v3 = v_u_1._gm
		if v3 == nil then
			if v_u_2.gm == nil then
				local v4 = v_u_2
				local v_u_5 = "GameMode"
				local v7, v8 = pcall(function()
					-- upvalues: (copy) v_u_5
					local v6 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					if v6 then
						v6 = v6:FindFirstChild("Shared")
					end
					if v6 then
						v6 = v6:FindFirstChild(v_u_5)
					end
					if v6 then
						return require(v6)
					else
						return nil
					end
				end)
				if not v7 or type(v8) ~= "table" then
					v8 = nil
				end
				v4.gm = v8
			end
			v3 = v_u_2.gm
		end
		if v3 == nil then
			return false
		end
		local v9 = v3.rule
		local v10, v11 = pcall(v9, "clans")
		if v10 then
			v10 = v11 == true
		end
		return v10
	else
		local v12 = v_u_1._gm or v_u_2.gm
		if not v12 then
			local v_u_13 = "GameMode"
			local v14
			v14, v12 = pcall(function()
				-- upvalues: (copy) v_u_13
				local v15 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v15 then
					v15 = v15:FindFirstChild("Shared")
				end
				if v15 then
					v15 = v15:FindFirstChild(v_u_13)
				end
				if v15 then
					return require(v15)
				else
					return nil
				end
			end)
			if not v14 or type(v12) ~= "table" then
				v12 = nil
			end
		end
		if v12 == nil then
			return v_u_1._mode == "pvpve"
		else
			return v12.forMode(v_u_1._mode, "clans") == true
		end
	end
end
function v_u_1.tagOf(p16) -- name: tagOf
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if v_u_1.enabled() then
		local v17
		if v_u_1._tag == nil then
			if v_u_2.tag == nil then
				local v18 = v_u_2
				local v_u_19 = "ClanTag"
				local v21, v22 = pcall(function()
					-- upvalues: (copy) v_u_19
					local v20 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					if v20 then
						v20 = v20:FindFirstChild("Shared")
					end
					if v20 then
						v20 = v20:FindFirstChild(v_u_19)
					end
					if v20 then
						return require(v20)
					else
						return nil
					end
				end)
				if not v21 or type(v22) ~= "table" then
					v22 = nil
				end
				v18.tag = v22
			end
			v17 = v_u_2.tag
		else
			v17 = v_u_1._tag
		end
		if v17 == nil or p16 == nil then
			return nil
		else
			return v17.of(p16)
		end
	else
		return nil
	end
end
function v_u_1.mateTag(p23, p24, p25) -- name: mateTag
	-- upvalues: (copy) v_u_1
	if type(p24) == "string" and (p24 ~= "" and p24 == p25) then
		return v_u_1.tagOf(p23)
	else
		return nil
	end
end
function v_u_1.byUserId(p_u_26) -- name: byUserId
	-- upvalues: (copy) v_u_1
	if type(p_u_26) == "number" and v_u_1.enabled() then
		local v27, v28 = pcall(function()
			-- upvalues: (copy) p_u_26
			return game:GetService("Players"):GetPlayerByUserId(p_u_26)
		end)
		if v27 and v28 ~= nil then
			return v_u_1.tagOf(v28)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.given(p29) -- name: given
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if v_u_1.enabled() then
		local v30
		if v_u_1._tag == nil then
			if v_u_2.tag == nil then
				local v31 = v_u_2
				local v_u_32 = "ClanTag"
				local v34, v35 = pcall(function()
					-- upvalues: (copy) v_u_32
					local v33 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					if v33 then
						v33 = v33:FindFirstChild("Shared")
					end
					if v33 then
						v33 = v33:FindFirstChild(v_u_32)
					end
					if v33 then
						return require(v33)
					else
						return nil
					end
				end)
				if not v34 or type(v35) ~= "table" then
					v35 = nil
				end
				v31.tag = v35
			end
			v30 = v_u_2.tag
		else
			v30 = v_u_1._tag
		end
		if v30 == nil then
			return nil
		else
			return v30.clean(p29)
		end
	else
		return nil
	end
end
function v_u_1.label(p36, p37) -- name: label
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v38
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v39 = v_u_2
			local v_u_40 = "ClanTag"
			local v42, v43 = pcall(function()
				-- upvalues: (copy) v_u_40
				local v41 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v41 then
					v41 = v41:FindFirstChild("Shared")
				end
				if v41 then
					v41 = v41:FindFirstChild(v_u_40)
				end
				if v41 then
					return require(v41)
				else
					return nil
				end
			end)
			if not v42 or type(v43) ~= "table" then
				v43 = nil
			end
			v39.tag = v43
		end
		v38 = v_u_2.tag
	else
		v38 = v_u_1._tag
	end
	if v38 == nil then
		if type(p37) == "string" then
			return p37
		else
			return tostring(p37)
		end
	else
		return v38.label(p36, p37)
	end
end
function v_u_1.rich(p44, p45, p46, p47) -- name: rich
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v48
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v49 = v_u_2
			local v_u_50 = "ClanTag"
			local v52, v53 = pcall(function()
				-- upvalues: (copy) v_u_50
				local v51 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v51 then
					v51 = v51:FindFirstChild("Shared")
				end
				if v51 then
					v51 = v51:FindFirstChild(v_u_50)
				end
				if v51 then
					return require(v51)
				else
					return nil
				end
			end)
			if not v52 or type(v53) ~= "table" then
				v53 = nil
			end
			v49.tag = v53
		end
		v48 = v_u_2.tag
	else
		v48 = v_u_1._tag
	end
	if v48 == nil then
		return string.gsub(string.gsub(string.gsub(tostring(p45), "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
	else
		return v48.rich(p44, p45, p46, p47)
	end
end
function v_u_1.prefixRich(p54, p55, p56) -- name: prefixRich
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v57
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v58 = v_u_2
			local v_u_59 = "ClanTag"
			local v61, v62 = pcall(function()
				-- upvalues: (copy) v_u_59
				local v60 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v60 then
					v60 = v60:FindFirstChild("Shared")
				end
				if v60 then
					v60 = v60:FindFirstChild(v_u_59)
				end
				if v60 then
					return require(v60)
				else
					return nil
				end
			end)
			if not v61 or type(v62) ~= "table" then
				v62 = nil
			end
			v58.tag = v62
		end
		v57 = v_u_2.tag
	else
		v57 = v_u_1._tag
	end
	return v57 == nil and "" or v57.prefixRich(p54, p55, p56)
end
function v_u_1.forPlayer(p_u_63, p64) -- name: forPlayer
	-- upvalues: (copy) v_u_1
	if p64 == nil then
		local v65, v66 = pcall(function()
			-- upvalues: (copy) p_u_63
			return p_u_63.DisplayName
		end)
		p64 = not v65 and "?" or v66
	end
	return v_u_1.label(v_u_1.tagOf(p_u_63), p64)
end
function v_u_1.leaderTitle(p67) -- name: leaderTitle
	-- upvalues: (copy) v_u_1
	local v68 = (type(p67) ~= "table" or p67.leader == nil) and "?" or p67.leader
	local v69 = tostring(v68)
	local v70
	if type(p67) == "table" then
		if p67.ct == nil then
			v70 = v_u_1.byUserId(p67.leaderId)
		else
			v70 = v_u_1.given(p67.ct)
		end
	else
		v70 = nil
	end
	return v_u_1.label(v70, v69) .. "\'s squad"
end
function v_u_1.playerRowName(p71) -- name: playerRowName
	-- upvalues: (copy) v_u_1
	local v72 = type(p71) ~= "table" and "?" or (p71.displayName or p71.name)
	local v73 = tostring(v72)
	if type(p71) == "table" then
		return v_u_1.label(v_u_1.byUserId(p71.userId), v73)
	else
		return v73
	end
end
v_u_1._style = nil
v_u_1._colors = nil
v_u_1._reduced = nil
v_u_1.SWITCH_ATTR = "ShowClanColors"
local v_u_74 = {}
local v_u_75 = 0
local function v_u_83() -- name: styleLib
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	if v_u_1._style ~= nil then
		return v_u_1._style
	end
	if v_u_2.style == nil then
		local v76 = v_u_2
		local v_u_77 = "ClanStyle"
		local v79, v80 = pcall(function()
			-- upvalues: (copy) v_u_77
			local v78 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
			if v78 then
				v78 = v78:FindFirstChild("Shared")
			end
			if v78 then
				v78 = v78:FindFirstChild(v_u_77)
			end
			if v78 then
				return require(v78)
			else
				return nil
			end
		end)
		if not v79 or type(v80) ~= "table" then
			v80 = nil
		end
		v76.style = v80
		if v_u_2.style ~= nil and (v_u_2.tag ~= nil and v_u_2.style.bind ~= nil) then
			local v81 = v_u_2.style.bind
			local v82 = v_u_2.tag
			pcall(v81, v82)
		end
	end
	return v_u_2.style
end
function v_u_1.colorsOn() -- name: colorsOn
	-- upvalues: (copy) v_u_1
	if v_u_1._colors ~= nil then
		return v_u_1._colors
	end
	local function v85()
		-- upvalues: (ref) v_u_1
		local v84 = game:GetService("Players").LocalPlayer
		if v84 == nil then
			return nil
		else
			return v84:GetAttribute(v_u_1.SWITCH_ATTR)
		end
	end
	local v86, v87 = pcall(v85)
	if v86 then
		v86 = v87 == false
	end
	return not v86
end
function v_u_1.setColors(p_u_88) -- name: setColors
	-- upvalues: (copy) v_u_1
	local function v90()
		-- upvalues: (ref) v_u_1, (copy) p_u_88
		local v89 = game:GetService("Players").LocalPlayer
		if v89 ~= nil then
			v89:SetAttribute(v_u_1.SWITCH_ATTR, p_u_88 == true)
		end
	end
	pcall(v90)
end
function v_u_1.reduced() -- name: reduced
	-- upvalues: (copy) v_u_1
	if v_u_1._reduced ~= nil then
		return v_u_1._reduced
	end
	local v_u_91 = "Theme"
	local v93, v94 = pcall(function()
		-- upvalues: (copy) v_u_91
		local v92 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
		if v92 then
			v92 = v92:FindFirstChild("Shared")
		end
		if v92 then
			v92 = v92:FindFirstChild(v_u_91)
		end
		if v92 then
			return require(v92)
		else
			return nil
		end
	end)
	if not v93 or type(v94) ~= "table" then
		v94 = nil
	end
	if v94 == nil or v94.reduced == nil then
		return false
	end
	local v95 = v94.reduced
	local v96, v97 = pcall(v95)
	if v96 then
		v96 = v97 == true
	end
	return v96
end
function v_u_1.parseStyle(p98) -- name: parseStyle
	-- upvalues: (copy) v_u_1, (copy) v_u_83, (ref) v_u_74, (ref) v_u_75
	if type(p98) == "string" and (p98 ~= "" and (v_u_1.enabled() and v_u_1.colorsOn())) then
		local v99 = v_u_83()
		if v99 == nil then
			return nil
		else
			local v100 = v_u_74[p98]
			if v100 == nil then
				local v101 = v99.parse
				local v102, v103 = pcall(v101, p98)
				if not v102 or type(v103) ~= "table" then
					v103 = false
				end
				if v_u_75 >= 64 then
					v_u_74 = {}
					v_u_75 = 0
				end
				v_u_74[p98] = v103
				v_u_75 = v_u_75 + 1
				if v103 == false then
					return nil
				else
					return v103
				end
			elseif v100 == false then
				return nil
			else
				return v100
			end
		end
	else
		return nil
	end
end
function v_u_1.styleOf(p_u_104) -- name: styleOf
	-- upvalues: (copy) v_u_1
	if p_u_104 == nil or not v_u_1.enabled() then
		return nil
	elseif v_u_1.tagOf(p_u_104) == nil then
		return nil
	else
		local v105, v106 = pcall(function()
			-- upvalues: (copy) p_u_104
			return p_u_104:GetAttribute("ClanStyle")
		end)
		if v105 then
			return v_u_1.parseStyle(v106)
		else
			return nil
		end
	end
end
function v_u_1.mateStyle(p107, p108, p109) -- name: mateStyle
	-- upvalues: (copy) v_u_1
	if type(p108) == "string" and (p108 ~= "" and p108 == p109) then
		return v_u_1.styleOf(p107)
	else
		return nil
	end
end
function v_u_1.styleByUserId(p_u_110) -- name: styleByUserId
	-- upvalues: (copy) v_u_1
	if type(p_u_110) == "number" and v_u_1.enabled() then
		local v111, v112 = pcall(function()
			-- upvalues: (copy) p_u_110
			return game:GetService("Players"):GetPlayerByUserId(p_u_110)
		end)
		if v111 and v112 ~= nil then
			return v_u_1.styleOf(v112)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.givenStyle(p113) -- name: givenStyle
	-- upvalues: (copy) v_u_1
	return v_u_1.parseStyle(p113)
end
function v_u_1.richFor(p114, p115, p116, p117) -- name: richFor
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_83
	local v118
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v119 = v_u_2
			local v_u_120 = "ClanTag"
			local v122, v123 = pcall(function()
				-- upvalues: (copy) v_u_120
				local v121 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v121 then
					v121 = v121:FindFirstChild("Shared")
				end
				if v121 then
					v121 = v121:FindFirstChild(v_u_120)
				end
				if v121 then
					return require(v121)
				else
					return nil
				end
			end)
			if not v122 or type(v123) ~= "table" then
				v123 = nil
			end
			v119.tag = v123
		end
		v118 = v_u_2.tag
	else
		v118 = v_u_1._tag
	end
	if v118 == nil then
		return ""
	end
	if type(p115) ~= "table" then
		return v118.prefixRich(p114, p116, nil)
	end
	local v124 = v_u_83()
	if v124 == nil then
		return v118.prefixRich(p114, p116, nil)
	end
	local v125 = v124.rich
	local v126, v127 = pcall(v125, p114, p115, p116)
	if not v126 or (type(v127) ~= "string" or v127 == "") then
		return v118.prefixRich(p114, p116, nil)
	end
	local v128 = v124.MEDALS
	local v129 = p115.medal
	if (type(p117) ~= "table" or p117.medal ~= false) and (type(v129) == "number" and (v128 ~= nil and v128[v129] ~= nil)) then
		local v130 = #v127 - 1
		v127 = string.sub(v127, 1, v130) .. " <font color=\"" .. v128[v129] .. "\">\226\151\143</font> "
	end
	return v127
end
function v_u_1.outline(p131) -- name: outline
	-- upvalues: (copy) v_u_83
	local v132
	if type(p131) == "table" then
		local v133 = p131.color
		if type(v133) == "table" then
			v132 = #p131.color > 0
		else
			v132 = false
		end
	else
		v132 = false
	end
	if not v132 then
		return nil
	end
	local v134 = v_u_83()
	local v135
	if v134 == nil then
		v135 = nil
	else
		v135 = v134.OUTLINE
	end
	return type(v135) ~= "table" and 0.35 or v135.transparency
end
function v_u_1.chatStroke(p136) -- name: chatStroke
	-- upvalues: (copy) v_u_83
	local v137
	if type(p136) == "table" then
		local v138 = p136.color
		if type(v138) == "table" then
			v137 = #p136.color > 0
		else
			v137 = false
		end
	else
		v137 = false
	end
	if not v137 then
		return nil
	end
	local v139 = v_u_83()
	local v140
	if v139 == nil then
		v140 = nil
	else
		v140 = v139.OUTLINE
	end
	return type(v140) ~= "table" and 0.6 or v140.chat
end
function v_u_1.color3(p141) -- name: color3
	-- upvalues: (copy) v_u_83
	local v142 = v_u_83()
	if v142 == nil or type(p141) ~= "table" then
		return nil
	else
		local v143 = v142.color3
		local v144, v145 = pcall(v143, p141)
		if v144 then
			return v145
		else
			return nil
		end
	end
end
function v_u_1.animAlpha(p146, p147) -- name: animAlpha
	-- upvalues: (copy) v_u_1
	if type(p146) ~= "table" or (p146.anim ~= true or (type(p147) ~= "number" or (p147 ~= p147 or v_u_1.reduced()))) then
		return 0
	end
	local v148 = p147 * 3.9
	return math.sin(v148) * 0.225 + 0.225
end
function v_u_1.fitWidth(p149, p150, p151, p152) -- name: fitWidth
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v153
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v154 = v_u_2
			local v_u_155 = "ClanTag"
			local v157, v158 = pcall(function()
				-- upvalues: (copy) v_u_155
				local v156 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v156 then
					v156 = v156:FindFirstChild("Shared")
				end
				if v156 then
					v156 = v156:FindFirstChild(v_u_155)
				end
				if v156 then
					return require(v156)
				else
					return nil
				end
			end)
			if not v157 or type(v158) ~= "table" then
				v158 = nil
			end
			v154.tag = v158
		end
		v153 = v_u_2.tag
	else
		v153 = v_u_1._tag
	end
	local v159 = (type(p151) ~= "number" or p151 <= 0) and 12 or p151
	local v160 = (type(p152) ~= "number" or p152 <= 0) and 60 or p152
	if v153 == nil or not v153.valid(p149) then
		return 0
	end
	local v161 = #p149 + 2
	if type(p150) == "table" then
		local v162 = p150.medal
		if type(v162) == "number" then
			v161 = v161 + 2
		end
	end
	local v163 = v161 * v159 * 0.62
	local v164 = math.ceil(v163)
	return math.min(v160, v164)
end
local function v_u_172(p165) -- name: escText
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v166
	if v_u_1._tag == nil then
		if v_u_2.tag == nil then
			local v167 = v_u_2
			local v_u_168 = "ClanTag"
			local v170, v171 = pcall(function()
				-- upvalues: (copy) v_u_168
				local v169 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				if v169 then
					v169 = v169:FindFirstChild("Shared")
				end
				if v169 then
					v169 = v169:FindFirstChild(v_u_168)
				end
				if v169 then
					return require(v169)
				else
					return nil
				end
			end)
			if not v170 or type(v171) ~= "table" then
				v171 = nil
			end
			v167.tag = v171
		end
		v166 = v_u_2.tag
	else
		v166 = v_u_1._tag
	end
	if v166 == nil or v166.esc == nil then
		return string.gsub(string.gsub(string.gsub(tostring(p165), "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
	else
		return v166.esc(p165)
	end
end
v_u_1.esc = v_u_172
function v_u_1.leaderTitleRich(p173) -- name: leaderTitleRich
	-- upvalues: (copy) v_u_1, (copy) v_u_172
	local v174 = v_u_1.leaderTitle(p173)
	if type(p173) ~= "table" then
		return v174, false
	end
	local v175, v176
	if p173.ct == nil then
		v175 = v_u_1.byUserId(p173.leaderId)
		if v175 == nil then
			v176 = nil
		else
			v176 = v_u_1.styleByUserId(p173.leaderId)
		end
	else
		v175 = v_u_1.given(p173.ct)
		if v175 == nil then
			v176 = nil
		else
			v176 = v_u_1.givenStyle(p173.cs)
		end
	end
	if v175 == nil then
		return v174, false
	end
	local v177 = v_u_1.richFor(v175, v176, nil)
	local v178 = v_u_172
	local v179 = p173.leader == nil and "?" or p173.leader
	return v177 .. v178(tostring(v179) .. "\'s squad"), true
end
function v_u_1.playerRowRich(p180) -- name: playerRowRich
	-- upvalues: (copy) v_u_1, (copy) v_u_172
	local v181 = v_u_1.playerRowName(p180)
	if type(p180) ~= "table" then
		return v181, false
	end
	local v182 = v_u_1.byUserId(p180.userId)
	if v182 == nil then
		return v181, false
	end
	local v183 = p180.displayName or p180.name
	local v184 = tostring(v183)
	return v_u_1.richFor(v182, v_u_1.styleByUserId(p180.userId), nil) .. v_u_172(v184), true
end
return v_u_1