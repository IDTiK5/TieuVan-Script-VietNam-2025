-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIStorePlus

local v1 = {}
local v_u_2 = {}
function v1.setPasses(p3) -- name: setPasses
	-- upvalues: (ref) v_u_2
	if type(p3) == "table" then
		v_u_2 = p3
	end
end
local function v_u_18(p4, p5, p6) -- name: layoutOf
	local v7 = p6.theme
	local v8, v9 = pcall(function()
		return require((script.Parent:WaitForChild("InvUITouch", 3)))
	end)
	local v10 = v7.isTouch
	local v11
	if type(v10) == "function" then
		v11 = v7.isTouch() == true
	else
		v11 = false
	end
	local v12 = v7.uiScale
	local v13 = type(v12) ~= "function" and 1 or v7.uiScale()
	local v14 = p4.Size
	local v15 = v14.X.Offset
	local v16 = v14.Y.Offset
	if v8 and (type(v9) == "table" and (v9.plusLayout and (v15 > 0 and v16 > 0))) then
		return v9.plusLayout(v11, p5, v15, v16, v13), v11
	end
	local v17 = v7.touch(p5 and 24 or 30)
	return {
		["badge"] = nil,
		["hit"] = nil,
		["capReserve"] = 0,
		["corner"] = true,
		["badge"] = {
			["x"] = 0,
			["y"] = 0,
			["size"] = nil,
			["size"] = v17
		},
		["hit"] = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v17,
			["h"] = v17
		}
	}, v11
end
function v1.make(p19, p20, p_u_21) -- name: make
	-- upvalues: (copy) v_u_18
	local v22 = p_u_21.theme
	local v_u_23 = v22.color
	local v24, v25 = v_u_18(p19, p20, p_u_21)
	local v_u_26 = Instance.new("TextButton")
	v_u_26.Name = "StorePlus"
	v_u_26.AutoButtonColor = false
	v_u_26.BorderSizePixel = 0
	v_u_26.Text = ""
	v_u_26.ZIndex = 10
	if v24.corner or not v25 then
		v_u_26.AnchorPoint = Vector2.new(1, 1)
		v_u_26.Position = UDim2.new(1, -4, 1, -4)
	else
		v_u_26.Position = UDim2.fromOffset(v24.hit.x, v24.hit.y)
	end
	v_u_26.Size = UDim2.fromOffset(v24.hit.w, v24.hit.h)
	v_u_26.Selectable = true
	v_u_26.Visible = false
	v_u_26.Parent = p19
	local v27
	if v25 and not v24.corner then
		v_u_26.BackgroundTransparency = 1
		v27 = Instance.new("TextLabel")
		v27.Name = "Badge"
		v27.Active = false
		v27.Position = UDim2.fromOffset(v24.badge.x - v24.hit.x, v24.badge.y - v24.hit.y)
		v27.Size = UDim2.fromOffset(v24.badge.size, v24.badge.size)
		v27.ZIndex = 11
		v27.Parent = v_u_26
	else
		v27 = v_u_26
	end
	v27.BackgroundColor3 = v_u_23.accent
	v27.BackgroundTransparency = 0.05
	v27.Text = "+"
	v27.FontFace = v22.font.headingBold
	v27.TextColor3 = v_u_23.ink
	local v28
	if v27 == v_u_26 then
		v28 = 24
	else
		local v29 = v24.badge.size * 0.85
		local v30 = math.floor(v29)
		v28 = math.max(12, v30)
	end
	v27.TextSize = v28
	if v27 ~= v_u_26 then
		v27.BorderSizePixel = 0
	end
	local v31 = p_u_21.cap
	if v24.capReserve > 0 and (typeof(v31) == "Instance" and v31:IsA("GuiObject")) then
		local v32 = v31.Size.X
		v31.Size = UDim2.new(v32.Scale, v32.Offset - v24.capReserve, v31.Size.Y.Scale, v31.Size.Y.Offset)
	end
	pcall(function()
		-- upvalues: (copy) v_u_26, (copy) p_u_21
		v_u_26.SelectionImageObject = p_u_21.hushUI.selectionImage()
	end)
	v_u_26.MouseButton1Click:Connect(function()
		-- upvalues: (copy) p_u_21
		p_u_21.sound("click")
		local v33 = p_u_21.menu()
		if v33 and v33.openStore then
			local v34 = v33.openStore
			pcall(v34, "pass_secure")
		end
	end)
	local v35 = p_u_21.hushUI.tooltip
	pcall(v35, v_u_26, function()
		-- upvalues: (copy) v_u_23
		return {
			["title"] = "Secure Case 3x4",
			["body"] = "Twelve cells that survive every raid. Open the store page.",
			["color"] = nil,
			["color"] = v_u_23.accent
		}
	end)
	return v_u_26
end
function v1.update(p36, p37, p38) -- name: update
	-- upvalues: (ref) v_u_2
	if p36 and p36.plus then
		local v39 = p36.plus
		local v40
		if p38 == "raid" then
			v40 = false
		else
			if p37 then
				p37 = p37.id == "secure_3x4"
			end
			v40 = not p37
			if v40 then
				v40 = v_u_2.secure_case ~= true
			end
		end
		v39.Visible = v40
	end
end
return v1