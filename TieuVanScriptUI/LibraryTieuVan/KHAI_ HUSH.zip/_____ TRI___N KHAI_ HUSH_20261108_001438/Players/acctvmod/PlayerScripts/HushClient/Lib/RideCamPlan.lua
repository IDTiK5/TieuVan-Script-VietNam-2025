-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RideCamPlan

local v_u_1 = {
	["VERSION"] = 1,
	["CLASSIC_BOARD_TP"] = false,
	["TUNE"] = {
		["RETURN_DELAY"] = 1.5,
		["RETURN_OMEGA"] = 3.5,
		["HEADING_OMEGA"] = 4.5,
		["PIVOT_OMEGA_XZ"] = 14,
		["PIVOT_OMEGA_Y"] = 6,
		["AHEAD_SECONDS"] = 0.14,
		["AHEAD_CAP"] = 14,
		["PITCH_DEFAULT_DEG"] = 16,
		["PITCH_MIN_DEG"] = -8,
		["PITCH_MAX_DEG"] = 62,
		["DIST_OMEGA"] = 6,
		["DIST_RETURN"] = 6,
		["MIN_DIST"] = 2.5,
		["WALL_MARGIN"] = 0.35,
		["COLLISION_RADIUS"] = 0.6,
		["FOV_ADD_MAX"] = 10,
		["FOV_OMEGA"] = 4,
		["SIDE_DIST"] = 9,
		["SIDE_UP"] = 1.5,
		["SIDE_PITCH_DEG"] = 8,
		["SIDE_AZIMUTH_DEG"] = 50,
		["SIDE_INTO"] = 1.2,
		["LEAN_DIST"] = 2.4,
		["LEAN_UP"] = 0.5,
		["LEAN_SHOULDER"] = 0.9,
		["LEAN_AIM_FAR"] = 40,
		["LEAN_SMOOTH"] = 18,
		["LEAN_RESET_OMEGA"] = 12,
		["LEAN_WINDUP"] = 20,
		["MOUSE_RAD"] = 0.0035,
		["TOUCH_RAD"] = 0.0045,
		["STICK_RAD"] = 2.8,
		["STICK_DEADZONE"] = 0.16,
		["CLASSIC_STEP_EPS_ZOOM"] = 0.002,
		["CLASSIC_STEP_EPS_AHEAD"] = 0.05,
		["CLASSIC_AHEAD_OMEGA"] = 4.5,
		["EJECT_AHEAD_CAP"] = 120,
		["AIM_FRESH_S"] = 0.2
	}
}
local v_u_2 = v_u_1.TUNE
v_u_1.BLEND = {
	["DEFAULT"] = 0.3,
	["none_board"] = 0.3,
	["board_drive"] = 0.5,
	["drive_unboard"] = 0.4,
	["unboard_none"] = 0.25,
	["board_none"] = 0.25,
	["none_drive"] = 0.4,
	["drive_none"] = 0.3,
	["drive_lean"] = 0.2,
	["lean_drive"] = 0.2,
	["drive_eject"] = 0.1,
	["lean_eject"] = 0.1,
	["board_eject"] = 0.1,
	["unboard_eject"] = 0.1,
	["eject_none"] = 0.4
}
function v_u_1.num(p3, p4, p5, p6) -- name: num
	if type(p3) == "number" then
		if p3 ~= p3 then
			p3 = p4
		end
	else
		p3 = p4
	end
	if p5 == nil or p3 >= p5 then
		if p6 == nil or p6 >= p3 then
			return p3
		else
			return p6
		end
	else
		return p5
	end
end
function v_u_1.wrapPi(p7) -- name: wrapPi
	local v8 = (p7 + 3.141592653589793) / 6.283185307179586
	return p7 - 6.283185307179586 * math.floor(v8)
end
function v_u_1.wrap180(p9) -- name: wrap180
	local v10 = (p9 + 180) / 360
	return p9 - math.floor(v10) * 360
end
function v_u_1.spring(p11, p12, p13, p14, p15) -- name: spring
	local v16 = 0
	if type(p15) == "number" then
		if p15 ~= p15 then
			p15 = v16
		end
	else
		p15 = v16
	end
	local v17 = p15 < 0 and 0 or (p15 > 0.25 and 0.25 or p15)
	if v17 <= 0 then
		return p11, p12
	end
	local v18 = 1
	if type(p14) == "number" then
		if p14 ~= p14 then
			p14 = v18
		end
	else
		p14 = v18
	end
	local v19 = p14 < 0.01 and 0.01 or (p14 > 200 and 200 or p14)
	local v20 = p11 - p13
	local v21 = -v19 * v17
	local v22 = math.exp(v21)
	local v23 = p12 + v19 * v20
	return p13 + (v20 + v23 * v17) * v22, (p12 - v23 * v19 * v17) * v22
end
function v_u_1.springAngle(p24, p25, p26, p27, p28) -- name: springAngle
	-- upvalues: (copy) v_u_1
	local v29 = p24 - p26
	local v30 = (v29 + 3.141592653589793) / 6.283185307179586
	local v31 = v29 - 6.283185307179586 * math.floor(v30)
	local v32, v33 = v_u_1.spring(v31, p25, 0, p27, p28)
	local v34 = p26 + v32
	local v35 = (v34 + 3.141592653589793) / 6.283185307179586
	return v34 - 6.283185307179586 * math.floor(v35), v33
end
function v_u_1.omegaFor(p36) -- name: omegaFor
	local v37 = 0.5
	if type(p36) == "number" then
		if p36 ~= p36 then
			p36 = v37
		end
	else
		p36 = v37
	end
	local v38 = p36 < 0.05 and 0.05 or (p36 > 30 and 30 or p36)
	return 4.74 / math.max(v38, 0.05)
end
function v_u_1.smoothstep(p39) -- name: smoothstep
	local v40 = math.clamp(p39, 0, 1)
	return v40 * v40 * (3 - v40 * 2)
end
function v_u_1.lookFromMouse(p41, p42, p43) -- name: lookFromMouse
	-- upvalues: (copy) v_u_2
	local v44 = 1
	if type(p43) == "number" then
		if p43 ~= p43 then
			p43 = v44
		end
	else
		p43 = v44
	end
	local v45 = p43 < 0.05 and 0.05 or (p43 > 10 and 10 or p43)
	local v46 = 0
	if type(p41) == "number" then
		if p41 ~= p41 then
			p41 = v46
		end
	else
		p41 = v46
	end
	local v47 = -(p41 < -2000 and -2000 or (p41 > 2000 and 2000 or p41)) * v_u_2.MOUSE_RAD * v45
	local v48 = 0
	if type(p42) == "number" then
		if p42 ~= p42 then
			p42 = v48
		end
	else
		p42 = v48
	end
	return v47, (p42 < -2000 and -2000 or (p42 > 2000 and 2000 or p42)) * v_u_2.MOUSE_RAD * v45
end
function v_u_1.lookFromTouch(p49, p50, p51) -- name: lookFromTouch
	-- upvalues: (copy) v_u_2
	local v52 = 1
	if type(p51) == "number" then
		if p51 ~= p51 then
			p51 = v52
		end
	else
		p51 = v52
	end
	local v53 = p51 < 0.05 and 0.05 or (p51 > 10 and 10 or p51)
	local v54 = 0
	if type(p49) == "number" then
		if p49 ~= p49 then
			p49 = v54
		end
	else
		p49 = v54
	end
	local v55 = -(p49 < -2000 and -2000 or (p49 > 2000 and 2000 or p49)) * v_u_2.TOUCH_RAD * v53
	local v56 = 0
	if type(p50) == "number" then
		if p50 ~= p50 then
			p50 = v56
		end
	else
		p50 = v56
	end
	return v55, (p50 < -2000 and -2000 or (p50 > 2000 and 2000 or p50)) * v_u_2.TOUCH_RAD * v53
end
function v_u_1.lookFromStick(p57, p58, p59, p60) -- name: lookFromStick
	-- upvalues: (copy) v_u_2
	local v61 = 0
	if type(p59) == "number" then
		if p59 ~= p59 then
			p59 = v61
		end
	else
		p59 = v61
	end
	local v62 = p59 < 0 and 0 or (p59 > 0.25 and 0.25 or p59)
	local v63 = 1
	if type(p60) == "number" then
		if p60 ~= p60 then
			p60 = v63
		end
	else
		p60 = v63
	end
	local v64 = p60 < 0.05 and 0.05 or (p60 > 10 and 10 or p60)
	local v65 = 0
	if type(p57) == "number" then
		if p57 ~= p57 then
			p57 = v65
		end
	else
		p57 = v65
	end
	local v66 = p57 < -1 and -1 or (p57 > 1 and 1 or p57)
	local v67 = math.abs(v66)
	local v68 = -(v67 <= v_u_2.STICK_DEADZONE and 0 or (v66 < 0 and -1 or 1) * (v67 - v_u_2.STICK_DEADZONE) / (1 - v_u_2.STICK_DEADZONE)) * v_u_2.STICK_RAD * v62 * v64
	local v69 = 0
	if type(p58) == "number" then
		if p58 ~= p58 then
			p58 = v69
		end
	else
		p58 = v69
	end
	local v70 = p58 < -1 and -1 or (p58 > 1 and 1 or p58)
	local v71 = math.abs(v70)
	return v68, -(v71 <= v_u_2.STICK_DEADZONE and 0 or (v70 < 0 and -1 or 1) * (v71 - v_u_2.STICK_DEADZONE) / (1 - v_u_2.STICK_DEADZONE)) * v_u_2.STICK_RAD * v62 * v64
end
function v_u_1.newChase() -- name: newChase
	-- upvalues: (copy) v_u_2
	local v72 = {
		["ready"] = false,
		["heading"] = 0,
		["headingV"] = 0,
		["yawOff"] = 0,
		["yawOffV"] = 0,
		["elev"] = nil,
		["elevV"] = 0,
		["idle"] = 0,
		["px"] = 0,
		["py"] = 0,
		["pz"] = 0,
		["pvx"] = 0,
		["pvy"] = 0,
		["pvz"] = 0,
		["dist"] = 0,
		["distV"] = 0,
		["eff"] = 0,
		["fov"] = 70,
		["fovV"] = 0
	}
	local v73 = v_u_2.PITCH_DEFAULT_DEG
	v72.elev = math.rad(v73)
	return v72
end
function v_u_1.chaseStep(p74, p75, p76) -- name: chaseStep
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v77 = 0
	if type(p76) == "number" then
		if p76 ~= p76 then
			p76 = v77
		end
	else
		p76 = v77
	end
	local v78 = p76 < 0 and 0 or (p76 > 0.25 and 0.25 or p76)
	local v79 = p75.vehYaw
	local v80 = 0
	if type(v79) == "number" then
		if v79 ~= v79 then
			v79 = v80
		end
	else
		v79 = v80
	end
	local v81 = p75.speed
	local v82 = 0
	if type(v81) == "number" then
		if v81 ~= v81 then
			v81 = v82
		end
	else
		v81 = v82
	end
	local v83 = v81 < -400 and -400 or (v81 > 400 and 400 or v81)
	local v84 = -math.sin(v79)
	local v85 = -math.cos(v79)
	local v86 = v83 * v_u_2.AHEAD_SECONDS
	local v87 = -v_u_2.AHEAD_CAP
	local v88 = v_u_2.AHEAD_CAP
	local v89 = math.clamp(v86, v87, v88)
	local v90 = p75.pivotX
	local v91 = 0
	if type(v90) == "number" then
		if v90 ~= v90 then
			v90 = v91
		end
	else
		v90 = v91
	end
	local v92 = v90 + v84 * v89
	local v93 = p75.pivotY
	local v94 = 0
	if type(v93) == "number" then
		if v93 ~= v93 then
			v93 = v94
		end
	else
		v93 = v94
	end
	local v95 = p75.pivotZ
	local v96 = 0
	if type(v95) == "number" then
		if v95 ~= v95 then
			v95 = v96
		end
	else
		v95 = v96
	end
	local v97 = v95 + v85 * v89
	local v98 = p75.baseFov
	local v99 = 70
	if type(v98) == "number" then
		if v98 ~= v98 then
			v98 = v99
		end
	else
		v98 = v99
	end
	local v100 = v98 < 20 and 20 or (v98 > 120 and 120 or v98)
	local v101 = p75.tpDist
	local v102 = v_u_2.MIN_DIST
	local v103 = 16
	if type(v101) == "number" then
		if v101 ~= v101 then
			v101 = v103
		end
	else
		v101 = v103
	end
	if v102 == nil or v101 >= v102 then
		v102 = v101 > 60 and 60 or v101
	end
	if not p74.ready then
		p74.ready = true
		p74.heading = v79
		p74.headingV = 0
		p74.px = v92
		p74.py = v93
		p74.pz = v97
		p74.pvx = 0
		p74.pvy = 0
		p74.pvz = 0
		p74.dist = v102
		p74.distV = 0
		p74.eff = v102
		p74.fov = v100
		p74.fovV = 0
		p74.yawOff = 0
		p74.yawOffV = 0
		p74.idle = 0
		local v104 = v_u_2.PITCH_DEFAULT_DEG
		p74.elev = math.rad(v104)
		p74.elevV = 0
	end
	local v105 = p75.dyaw
	local v106 = 0
	if type(v105) == "number" then
		if v105 ~= v105 then
			v105 = v106
		end
	else
		v105 = v106
	end
	local v107 = v105 < -3.2 and -3.2 or (v105 > 3.2 and 3.2 or v105)
	local v108 = p75.delev
	local v109 = 0
	if type(v108) == "number" then
		if v108 ~= v108 then
			v108 = v109
		end
	else
		v108 = v109
	end
	local v110 = v108 < -3.2 and -3.2 or (v108 > 3.2 and 3.2 or v108)
	if v107 == 0 and v110 == 0 then
		p74.idle = p74.idle + v78
		if p74.idle >= v_u_2.RETURN_DELAY then
			local v111, v112 = v_u_1.springAngle(p74.yawOff, p74.yawOffV, 0, v_u_2.RETURN_OMEGA, v78)
			p74.yawOff = v111
			p74.yawOffV = v112
			local v113 = v_u_1.spring
			local v114 = p74.elev
			local v115 = p74.elevV
			local v116 = v_u_2.PITCH_DEFAULT_DEG
			local v117, v118 = v113(v114, v115, math.rad(v116), v_u_2.RETURN_OMEGA, v78)
			p74.elev = v117
			p74.elevV = v118
		end
	else
		p74.idle = 0
		local v119 = p74.yawOff + v107
		local v120 = (v119 + 3.141592653589793) / 6.283185307179586
		p74.yawOff = v119 - 6.283185307179586 * math.floor(v120)
		p74.yawOffV = 0
		local v121 = p74.elev + v110
		local v122 = v_u_2.PITCH_MIN_DEG
		local v123 = math.rad(v122)
		local v124 = v_u_2.PITCH_MAX_DEG
		local v125 = math.rad(v124)
		p74.elev = math.clamp(v121, v123, v125)
		p74.elevV = 0
	end
	local v126, v127 = v_u_1.springAngle(p74.heading, p74.headingV, v79, v_u_2.HEADING_OMEGA, v78)
	p74.heading = v126
	p74.headingV = v127
	local v128, v129 = v_u_1.spring(p74.px, p74.pvx, v92, v_u_2.PIVOT_OMEGA_XZ, v78)
	p74.px = v128
	p74.pvx = v129
	local v130, v131 = v_u_1.spring(p74.py, p74.pvy, v93, v_u_2.PIVOT_OMEGA_Y, v78)
	p74.py = v130
	p74.pvy = v131
	local v132, v133 = v_u_1.spring(p74.pz, p74.pvz, v97, v_u_2.PIVOT_OMEGA_XZ, v78)
	p74.pz = v132
	p74.pvz = v133
	local v134, v135 = v_u_1.spring(p74.dist, p74.distV, v102, v_u_2.DIST_OMEGA, v78)
	p74.dist = v134
	p74.distV = v135
	local v136 = math.abs(v83)
	local v137 = p75.maxSpeed
	local v138 = 60
	if type(v137) == "number" then
		if v137 ~= v137 then
			v137 = v138
		end
	else
		v137 = v138
	end
	local v139 = v137 < 1 and 1 or (v137 > 400 and 400 or v137)
	local v140 = v136 / math.max(v139, 1)
	local v141 = math.clamp(v140, 0, 1)
	local v142 = v100 + v_u_2.FOV_ADD_MAX * v141 ^ 1.5
	local v143, v144 = v_u_1.spring(p74.fov, p74.fovV, v142, v_u_2.FOV_OMEGA, v78)
	p74.fov = v143
	p74.fovV = v144
	local v145 = p74.heading + p74.yawOff
	local v146 = (v145 + 3.141592653589793) / 6.283185307179586
	local v147 = v145 - 6.283185307179586 * math.floor(v146)
	return v_u_1.place(p74, v147, p74.elev, p74.dist), {
		["yaw"] = v147,
		["elev"] = p74.elev,
		["dist"] = p74.dist
	}
end
function v_u_1.heading(p148, p149) -- name: heading
	local v150 = 0
	if type(p148) == "number" then
		if p148 ~= p148 then
			p148 = v150
		end
	else
		p148 = v150
	end
	local v151 = 0
	if type(p149) == "number" then
		if p149 ~= p149 then
			p149 = v151
		end
	else
		p149 = v151
	end
	if p148 == 0 and p149 == 0 then
		return 0
	end
	local v152 = -p148
	local v153 = -p149
	return math.atan2(v152, v153)
end
function v_u_1.place(p154, p155, p156, p157) -- name: place
	-- upvalues: (copy) v_u_2
	local v158 = -math.sin(p155)
	local v159 = -math.cos(p155)
	local v160 = v_u_2.MIN_DIST
	local v161 = math.max(p157, v160)
	local v162 = math.cos(p156)
	local v163 = math.sin(p156)
	return {
		["camX"] = p154.px - v158 * v161 * v162,
		["camY"] = p154.py + v161 * v163,
		["camZ"] = p154.pz - v159 * v161 * v162,
		["tgtX"] = p154.px,
		["tgtY"] = p154.py,
		["tgtZ"] = p154.pz,
		["fov"] = p154.fov
	}
end
function v_u_1.settle(p164, p165, p166, p167) -- name: settle
	-- upvalues: (copy) v_u_2
	local v168 = 0
	if type(p167) == "number" then
		if p167 ~= p167 then
			p167 = v168
		end
	else
		p167 = v168
	end
	local v169 = p167 < 0 and 0 or (p167 > 0.25 and 0.25 or p167)
	local v170 = v_u_2.MIN_DIST
	local v171 = v_u_2.MIN_DIST
	if type(p165) == "number" then
		if p165 ~= p165 then
			p165 = v170
		end
	else
		p165 = v170
	end
	if v171 == nil or p165 >= v171 then
		v171 = p165 > 100 and 100 or p165
	end
	local v172 = v_u_2.MIN_DIST
	local v173 = math.max(v171, v172)
	if type(p166) == "number" and p166 == p166 then
		local v174 = p166 - v_u_2.WALL_MARGIN
		local v175 = v_u_2.MIN_DIST
		local v176 = math.max(v174, v175)
		v173 = math.min(v173, v176)
	end
	if p164.eff == nil or p164.eff <= 0 then
		p164.eff = v173
	end
	if v173 < p164.eff then
		p164.eff = v173
	else
		local v177 = p164.eff
		local v178 = v173 - p164.eff
		local v179 = -v_u_2.DIST_RETURN * v169
		p164.eff = v177 + v178 * (1 - math.exp(v179))
		if v173 < p164.eff then
			p164.eff = v173
		end
	end
	return p164.eff
end
function v_u_1.sidePose(p180) -- name: sidePose
	-- upvalues: (copy) v_u_2
	local v181 = p180.vehYaw
	local v182 = 0
	if type(v181) == "number" then
		if v181 ~= v181 then
			v181 = v182
		end
	else
		v181 = v182
	end
	local v183 = math.cos(v181)
	local v184 = -math.sin(v181)
	local v185 = math.sin(v181)
	local v186 = math.cos(v181)
	local v187 = p180.side == "R" and 1 or -1
	local v188 = v183 * v187
	local v189 = v184 * v187
	local v190 = v_u_2.SIDE_AZIMUTH_DEG
	local v191 = math.rad(v190)
	local v192 = p180.yawOff
	local v193 = 0
	if type(v192) == "number" then
		if v192 ~= v192 then
			v192 = v193
		end
	else
		v192 = v193
	end
	local v194 = v191 + (v192 < -3.2 and -3.2 or (v192 > 3.2 and 3.2 or v192))
	local v195 = v188 * math.cos(v194) + v185 * math.sin(v194)
	local v196 = v189 * math.cos(v194) + v186 * math.sin(v194)
	local v197 = v_u_2.SIDE_PITCH_DEG
	local v198 = math.rad(v197)
	local v199 = p180.elevOff
	local v200 = 0
	if type(v199) == "number" then
		if v199 ~= v199 then
			v199 = v200
		end
	else
		v199 = v200
	end
	local v201 = v198 + (v199 < -1.2 and -1.2 or (v199 > 1.2 and 1.2 or v199))
	local v202 = math.cos(v201)
	local v203 = math.sin(v201)
	local v204 = p180.pivotX
	local v205 = 0
	if type(v204) == "number" then
		if v204 ~= v204 then
			v204 = v205
		end
	else
		v204 = v205
	end
	local v206 = p180.pivotY
	local v207 = 0
	if type(v206) == "number" then
		if v206 ~= v206 then
			v206 = v207
		end
	else
		v206 = v207
	end
	local v208 = v206 + v_u_2.SIDE_UP
	local v209 = p180.pivotZ
	local v210 = 0
	if type(v209) == "number" then
		if v209 ~= v209 then
			v209 = v210
		end
	else
		v209 = v210
	end
	local v211 = v_u_2.SIDE_DIST
	local v212 = {
		["camX"] = v204 + v195 * v211 * v202,
		["camY"] = v208 + v211 * v203,
		["camZ"] = v209 + v196 * v211 * v202,
		["tgtX"] = v204 - v188 * v_u_2.SIDE_INTO,
		["tgtY"] = v208 - 0.3,
		["tgtZ"] = v209 - v189 * v_u_2.SIDE_INTO
	}
	local v213 = p180.baseFov
	local v214 = 70
	if type(v213) == "number" then
		if v213 ~= v213 then
			v213 = v214
		end
	else
		v213 = v214
	end
	v212.fov = v213 < 20 and 20 or (v213 > 120 and 120 or v213)
	return v212, {
		["dist"] = v211,
		["pivotX"] = v204,
		["pivotY"] = v208,
		["pivotZ"] = v209
	}
end
function v_u_1.clampArc(p215, p216, p217) -- name: clampArc
	if type(p217) ~= "table" then
		local v218 = 0
		if type(p215) == "number" then
			if p215 ~= p215 then
				p215 = v218
			end
		else
			p215 = v218
		end
		local v219 = 0
		if type(p216) == "number" then
			if p216 ~= p216 then
				p216 = v219
			end
		else
			p216 = v219
		end
		return p215, p216
	end
	local v220 = p217.yaw
	local v221 = 0
	if type(v220) == "number" then
		if v220 ~= v220 then
			v220 = v221
		end
	else
		v220 = v221
	end
	local v222 = p217.half
	local v223 = 90
	if type(v222) == "number" then
		if v222 ~= v222 then
			v222 = v223
		end
	else
		v222 = v223
	end
	local v224 = v222 < 0 and 0 or (v222 > 180 and 180 or v222)
	local v225 = 0
	if type(p215) == "number" then
		if p215 ~= p215 then
			p215 = v225
		end
	else
		p215 = v225
	end
	local v226 = p215 - v220
	local v227 = (v226 + 180) / 360
	local v228 = v226 - math.floor(v227) * 360
	local v229 = -v224
	local v230 = math.clamp(v228, v229, v224)
	local v231 = p217.up
	local v232 = 45
	if type(v231) == "number" then
		if v231 ~= v231 then
			v231 = v232
		end
	else
		v231 = v232
	end
	local v233 = v231 < 0 and 0 or (v231 > 89 and 89 or v231)
	local v234 = p217.down
	local v235 = 35
	if type(v234) == "number" then
		if v234 ~= v234 then
			v234 = v235
		end
	else
		v234 = v235
	end
	local v236 = v234 < 0 and 0 or (v234 > 89 and 89 or v234)
	local v237 = v220 + v230
	local v238 = 0
	if type(p216) == "number" then
		if p216 ~= p216 then
			p216 = v238
		end
	else
		p216 = v238
	end
	local v239 = -v236
	return v237, math.clamp(p216, v239, v233)
end
function v_u_1.relFromYaw(p240, p241) -- name: relFromYaw
	local v242 = 0
	if type(p240) == "number" then
		if p240 ~= p240 then
			p240 = v242
		end
	else
		p240 = v242
	end
	local v243 = 0
	if type(p241) == "number" then
		if p241 ~= p241 then
			p241 = v243
		end
	else
		p241 = v243
	end
	local v244 = p240 - p241
	local v245 = (v244 + 3.141592653589793) / 6.283185307179586
	local v246 = -(v244 - 6.283185307179586 * math.floor(v245))
	local v247 = math.deg(v246)
	local v248 = (v247 + 180) / 360
	return v247 - math.floor(v248) * 360
end
function v_u_1.yawFromRel(p249, p250) -- name: yawFromRel
	local v251 = 0
	if type(p250) == "number" then
		if p250 ~= p250 then
			p250 = v251
		end
	else
		p250 = v251
	end
	local v252 = 0
	if type(p249) == "number" then
		if p249 ~= p249 then
			p249 = v252
		end
	else
		p249 = v252
	end
	local v253 = p250 - math.rad(p249)
	local v254 = (v253 + 3.141592653589793) / 6.283185307179586
	return v253 - 6.283185307179586 * math.floor(v254)
end
local v_u_255 = nil
function v_u_1.useArc(p256) -- name: useArc
	-- upvalues: (ref) v_u_255
	if type(p256) == "table" then
		local v257 = p256.soft
		if type(v257) ~= "function" then
			p256 = nil
		end
	else
		p256 = nil
	end
	v_u_255 = p256
end
function v_u_1.clampArcSoft(p258, p259, p260, p261) -- name: clampArcSoft
	-- upvalues: (ref) v_u_255, (copy) v_u_1
	if type(p260) ~= "table" then
		local v262 = 0
		if type(p258) == "number" then
			if p258 ~= p258 then
				p258 = v262
			end
		else
			p258 = v262
		end
		local v263 = 0
		if type(p259) == "number" then
			if p259 ~= p259 then
				p259 = v263
			end
		else
			p259 = v263
		end
		return p258, p259, 0, {
			["yaw"] = 0,
			["pitch"] = 0,
			["side"] = 1
		}
	end
	if v_u_255 == nil then
		local v264, v265 = v_u_1.clampArc(p258, p259, p260)
		return v264, v265, 0, {
			["yaw"] = 0,
			["pitch"] = 0,
			["side"] = 1
		}
	end
	local v266 = v_u_255.soft
	local v267 = 0
	if type(p258) == "number" then
		if p258 ~= p258 then
			p258 = v267
		end
	else
		p258 = v267
	end
	local v268 = 0
	if type(p259) == "number" then
		if p259 ~= p259 then
			p259 = v268
		end
	else
		p259 = v268
	end
	return v266(p260, p258, p259, p261)
end
function v_u_1.newLean() -- name: newLean
	return {
		["ready"] = false,
		["relDeg"] = 0,
		["pitchDeg"] = 0,
		["shownRel"] = 0,
		["shownPitch"] = 0,
		["shownV1"] = 0,
		["shownV2"] = 0,
		["t"] = 0,
		["hold"] = 1
	}
end
function v_u_1.leanStep(p269, p270, p271) -- name: leanStep
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (ref) v_u_255
	local v272 = 0
	if type(p271) == "number" then
		if p271 ~= p271 then
			p271 = v272
		end
	else
		p271 = v272
	end
	local v273 = p271 < 0 and 0 or (p271 > 0.25 and 0.25 or p271)
	local v274 = p270.vehYaw
	local v275 = 0
	if type(v274) == "number" then
		if v274 ~= v274 then
			v274 = v275
		end
	else
		v274 = v275
	end
	local v276 = p270.arc
	if not p269.ready then
		p269.ready = true
		local v277
		if type(v276) == "table" then
			v277 = v276.yaw
			local v278 = 0
			if type(v277) == "number" then
				if v277 ~= v277 then
					v277 = v278
				end
			else
				v277 = v278
			end
		else
			v277 = 0
		end
		p269.relDeg = v277
		p269.pitchDeg = 0
		p269.shownRel = v277
		p269.shownPitch = 0
	end
	local v279
	if type(v276) == "table" then
		v279 = v276.yaw
		local v280 = 0
		if type(v279) == "number" then
			if v279 ~= v279 then
				v279 = v280
			end
		else
			v279 = v280
		end
	else
		v279 = 0
	end
	local v281 = p269.relDeg - v279
	local v282 = (v281 + 180) / 360
	local v283 = v281 - math.floor(v282) * 360
	local v284 = p270.dyaw
	local v285 = 0
	if type(v284) == "number" then
		if v284 ~= v284 then
			v284 = v285
		end
	else
		v284 = v285
	end
	local v286 = v284 < -3.2 and -3.2 or (v284 > 3.2 and 3.2 or v284)
	local v287 = v283 - math.deg(v286)
	local v288 = p269.pitchDeg
	local v289 = p270.dpitch
	local v290 = 0
	if type(v289) == "number" then
		if v289 ~= v289 then
			v289 = v290
		end
	else
		v289 = v290
	end
	local v291 = v289 < -3.2 and -3.2 or (v289 > 3.2 and 3.2 or v289)
	local v292 = v288 + math.deg(v291)
	if type(v276) == "table" then
		local v293 = v276.half
		local v294 = 90
		if type(v293) == "number" then
			if v293 ~= v293 then
				v293 = v294
			end
		else
			v293 = v294
		end
		local v295 = v293 < 0 and 0 or (v293 > 180 and 180 or v293)
		if v295 >= 180 then
			local v296 = (v287 + 180) / 360
			v287 = v287 - math.floor(v296) * 360
		else
			local v297 = v_u_2.LEAN_WINDUP
			local v298 = (180 - v295) * 0.5
			local v299 = v295 + math.min(v297, v298)
			local v300 = -v299
			v287 = math.clamp(v287, v300, v299)
		end
		local v301 = 89
		local v302 = v276.down
		local v303 = 35
		if type(v302) == "number" then
			if v302 ~= v302 then
				v302 = v303
			end
		else
			v302 = v303
		end
		local v304 = (v302 < 0 and 0 or (v302 > 89 and 89 or v302)) + v_u_2.LEAN_WINDUP
		local v305 = -math.min(v301, v304)
		local v306 = 89
		local v307 = v276.up
		local v308 = 45
		if type(v307) == "number" then
			if v307 ~= v307 then
				v307 = v308
			end
		else
			v307 = v308
		end
		local v309 = (v307 < 0 and 0 or (v307 > 89 and 89 or v307)) + v_u_2.LEAN_WINDUP
		local v310 = math.min(v306, v309)
		v292 = math.clamp(v292, v305, v310)
	end
	p269.relDeg = v279 + v287
	p269.pitchDeg = v292
	local v311, v312, v313, v314 = v_u_1.clampArcSoft(p269.relDeg, p269.pitchDeg, v276, {
		["viewUp"] = p270.viewUp,
		["viewDown"] = p270.viewDown,
		["hold"] = p269.hold
	})
	p269.t = v313
	if type(v314) == "table" and v314.side ~= nil then
		p269.hold = v314.side
	end
	local v315 = -v_u_2.LEAN_SMOOTH * v273
	local v316 = 1 - math.exp(v315)
	local v317 = v311 - p269.shownRel
	local v318 = (v317 + 180) / 360
	local v319 = v317 - math.floor(v318) * 360
	local v320 = p269.shownRel + v319 * v316
	local v321 = (v320 + 180) / 360
	p269.shownRel = v320 - math.floor(v321) * 360
	p269.shownPitch = p269.shownPitch + (v312 - p269.shownPitch) * v316
	if v_u_255 ~= nil and (type(v276) == "table" and v_u_255.guardPitch ~= nil) then
		p269.shownPitch = v_u_255.guardPitch(v276, p269.shownRel, p269.shownPitch, {
			["viewUp"] = p270.viewUp,
			["viewDown"] = p270.viewDown
		})
	end
	local v322 = v_u_1.yawFromRel(p269.shownRel, v274)
	local v323 = p269.shownPitch
	local v324 = math.rad(v323)
	local v325 = -math.sin(v322) * math.cos(v324)
	local v326 = -math.cos(v322) * math.cos(v324)
	local v327 = math.sin(v324)
	local v328 = math.cos(v322)
	local v329 = -math.sin(v322)
	local v330 = p270.shoulder
	local v331 = 1
	if type(v330) == "number" then
		if v330 ~= v330 then
			v330 = v331
		end
	else
		v330 = v331
	end
	local v332 = v330 < 0 and -1 or 1
	local v333 = p270.headX
	local v334 = 0
	if type(v333) == "number" then
		if v333 ~= v333 then
			v333 = v334
		end
	else
		v333 = v334
	end
	local v335 = p270.headY
	local v336 = 0
	if type(v335) == "number" then
		if v335 ~= v335 then
			v335 = v336
		end
	else
		v335 = v336
	end
	local v337 = v335 + v_u_2.LEAN_UP
	local v338 = p270.headZ
	local v339 = 0
	if type(v338) == "number" then
		if v338 ~= v338 then
			v338 = v339
		end
	else
		v338 = v339
	end
	local v340 = {
		["camX"] = v333 - v325 * v_u_2.LEAN_DIST + v328 * v332 * v_u_2.LEAN_SHOULDER,
		["camY"] = v337 - v327 * v_u_2.LEAN_DIST,
		["camZ"] = v338 - v326 * v_u_2.LEAN_DIST + v329 * v332 * v_u_2.LEAN_SHOULDER,
		["tgtX"] = v333 + v325 * v_u_2.LEAN_AIM_FAR,
		["tgtY"] = v337 + v327 * v_u_2.LEAN_AIM_FAR,
		["tgtZ"] = v338 + v326 * v_u_2.LEAN_AIM_FAR
	}
	local v341 = p270.baseFov
	local v342 = 70
	if type(v341) == "number" then
		if v341 ~= v341 then
			v341 = v342
		end
	else
		v341 = v342
	end
	v340.fov = v341 < 20 and 20 or (v341 > 120 and 120 or v341)
	return v340, v322, v324, p269.t
end
function v_u_1.leanReset(p343, p344, p345) -- name: leanReset
	-- upvalues: (copy) v_u_2
	local v346 = 0
	if type(p345) == "number" then
		if p345 ~= p345 then
			p345 = v346
		end
	else
		p345 = v346
	end
	local v347 = p345 < 0 and 0 or (p345 > 0.25 and 0.25 or p345)
	local v348
	if type(p344) == "table" then
		v348 = p344.yaw
		local v349 = 0
		if type(v348) == "number" then
			if v348 ~= v348 then
				v348 = v349
			end
		else
			v348 = v349
		end
	else
		v348 = 0
	end
	local v350 = -v_u_2.LEAN_RESET_OMEGA * v347
	local v351 = 1 - math.exp(v350)
	local v352 = p343.relDeg - v348
	local v353 = (v352 + 180) / 360
	p343.relDeg = v348 + (v352 - math.floor(v353) * 360) * (1 - v351)
	p343.pitchDeg = p343.pitchDeg * (1 - v351)
	local v354 = p343.relDeg
	local v355 = p343.pitchDeg
	p343.shownRel = v354
	p343.shownPitch = v355
	p343.t = 0
end
function v_u_1.modeFor(p356, p357) -- name: modeFor
	return p356 == "ride" and (p357 == true and "lean" or "drive") or (p356 ~= "board" and (p356 ~= "unboard" and p356 ~= "eject") and "none" or p356)
end
function v_u_1.blendTime(p358, p359) -- name: blendTime
	-- upvalues: (copy) v_u_1
	return v_u_1.BLEND[tostring(p358) .. "_" .. tostring(p359)] or v_u_1.BLEND.DEFAULT
end
local v_u_360 = {
	"camX",
	"camY",
	"camZ",
	"tgtX",
	"tgtY",
	"tgtZ",
	"fov"
}
function v_u_1.blend(p361, p362, p363) -- name: blend
	-- upvalues: (copy) v_u_360
	if p361 == nil then
		return p362
	end
	if p362 == nil then
		return p361
	end
	local v364 = 1
	if type(p363) == "number" then
		if p363 ~= p363 then
			p363 = v364
		end
	else
		p363 = v364
	end
	local v365 = math.clamp(p363, 0, 1)
	local v366 = v365 * v365 * (3 - v365 * 2)
	local v367 = {}
	for _, v368 in v_u_360 do
		v367[v368] = p361[v368] + (p362[v368] - p361[v368]) * v366
	end
	return v367
end
function v_u_1.blendWeight(p369, p370) -- name: blendWeight
	if p369 == nil or (p369.dur == nil or p369.dur <= 0) then
		return 1
	end
	local v371 = (p370 - p369.t0) / p369.dur
	return math.clamp(v371, 0, 1)
end
function v_u_1.newClassic() -- name: newClassic
	return {
		["zoom"] = 1,
		["zoomV"] = 0,
		["ax"] = 0,
		["axV"] = 0,
		["az"] = 0,
		["azV"] = 0
	}
end
function v_u_1.classicStep(p372, p373, p374) -- name: classicStep
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v375 = 0
	if type(p374) == "number" then
		if p374 ~= p374 then
			p374 = v375
		end
	else
		p374 = v375
	end
	local v376 = p374 < 0 and 0 or (p374 > 0.25 and 0.25 or p374)
	local v377 = p373.zoomMax
	local v378 = 1.8
	if type(v377) == "number" then
		if v377 ~= v377 then
			v377 = v378
		end
	else
		v377 = v378
	end
	local v379 = v377 < 1 and 1 or (v377 > 4 and 4 or v377)
	local v380 = p373.zoom
	local v381 = 1
	if type(v380) == "number" then
		if v380 ~= v380 then
			v380 = v381
		end
	else
		v380 = v381
	end
	if v380 < 1 then
		v380 = 1
	elseif v379 ~= nil and v379 < v380 then
		v380 = v379
	end
	local v382 = math.clamp(v380, 1, v379)
	local v383 = v_u_1.omegaFor
	local v384
	if p372.zoom <= v382 then
		local v385 = p373.blendIn
		local v386 = 0.6
		if type(v385) == "number" then
			if v385 ~= v385 then
				v385 = v386
			end
		else
			v385 = v386
		end
		v384 = v385 < 0.05 and 0.05 or (v385 > 5 and 5 or v385)
	else
		local v387 = p373.blendOut
		local v388 = 0.5
		if type(v387) == "number" then
			if v387 ~= v387 then
				v387 = v388
			end
		else
			v387 = v388
		end
		v384 = v387 < 0.05 and 0.05 or (v387 > 5 and 5 or v387)
	end
	local v389 = v383(v384)
	local v390, v391 = v_u_1.spring(p372.zoom, p372.zoomV, v382, v389, v376)
	p372.zoom = v390
	p372.zoomV = v391
	local v392 = p372.zoom
	p372.zoom = math.clamp(v392, 1, v379)
	local v393 = p373.vehYaw
	local v394 = 0
	if type(v393) == "number" then
		if v393 ~= v393 then
			v393 = v394
		end
	else
		v393 = v394
	end
	local v395 = p373.ahead
	local v396 = 0
	if type(v395) == "number" then
		if v395 ~= v395 then
			v395 = v396
		end
	else
		v395 = v396
	end
	local v397 = v395 < 0 and 0 or (v395 > 100 and 100 or v395)
	local v398 = -math.sin(v393) * v397
	local v399 = -math.cos(v393) * v397
	local v400, v401 = v_u_1.spring(p372.ax, p372.axV, v398, v_u_2.CLASSIC_AHEAD_OMEGA, v376)
	p372.ax = v400
	p372.axV = v401
	local v402, v403 = v_u_1.spring(p372.az, p372.azV, v399, v_u_2.CLASSIC_AHEAD_OMEGA, v376)
	p372.az = v402
	p372.azV = v403
	local v404
	if v382 <= 1 and v397 <= 0 then
		local v405 = p372.zoom - 1
		if math.abs(v405) < v_u_2.CLASSIC_STEP_EPS_ZOOM then
			local v406 = p372.ax
			if math.abs(v406) < v_u_2.CLASSIC_STEP_EPS_AHEAD then
				local v407 = p372.az
				v404 = math.abs(v407) < v_u_2.CLASSIC_STEP_EPS_AHEAD
			else
				v404 = false
			end
		else
			v404 = false
		end
	else
		v404 = false
	end
	return p372.zoom, p372.ax, p372.az, v404
end
function v_u_1.ejectAhead(p408, p409, p410, p411) -- name: ejectAhead
	-- upvalues: (copy) v_u_2
	if type(p408) ~= "number" or (type(p409) ~= "number" or (type(p410) ~= "number" or (type(p411) ~= "number" or (p408 ~= p408 or (p409 ~= p409 or (p410 ~= p410 or p411 ~= p411)))))) then
		return 0, 0
	end
	local v412 = p408 - p410
	local v413 = p409 - p411
	local v414 = v412 * v412 + v413 * v413
	local v415 = math.sqrt(v414)
	if v_u_2.EJECT_AHEAD_CAP < v415 then
		local v416 = v_u_2.EJECT_AHEAD_CAP / v415
		v412 = v412 * v416
		v413 = v413 * v416
	end
	return v412, v413
end
function v_u_1.classicEject(p417, p418, p419) -- name: classicEject
	-- upvalues: (copy) v_u_1
	local v420 = 0
	if type(p419) == "number" then
		if p419 ~= p419 then
			p419 = v420
		end
	else
		p419 = v420
	end
	local v421 = p419 < 0 and 0 or (p419 > 0.25 and 0.25 or p419)
	local v422 = p418.zoomMax
	local v423 = 1.8
	if type(v422) == "number" then
		if v422 ~= v422 then
			v422 = v423
		end
	else
		v422 = v423
	end
	local v424 = v422 < 1 and 1 or (v422 > 4 and 4 or v422)
	local v425 = v_u_1.omegaFor
	local v426 = p418.blendOut
	local v427 = 0.5
	if type(v426) == "number" then
		if v426 ~= v426 then
			v426 = v427
		end
	else
		v426 = v427
	end
	local v428 = v425(v426 < 0.05 and 0.05 or (v426 > 5 and 5 or v426))
	local v429, v430 = v_u_1.spring(p417.zoom, p417.zoomV, 1, v428, v421)
	p417.zoom = v429
	p417.zoomV = v430
	local v431 = p417.zoom
	p417.zoom = math.clamp(v431, 1, v424)
	local v432, v433 = v_u_1.ejectAhead(p418.puppetX, p418.puppetZ, p418.rootX, p418.rootZ)
	p417.ax = v432
	p417.az = v433
	p417.axV = 0
	p417.azV = 0
	return p417.zoom, v432, v433
end
function v_u_1.aimFresh(p434) -- name: aimFresh
	-- upvalues: (copy) v_u_2
	local v435
	if type(p434) == "number" and (p434 == p434 and p434 >= 0) then
		v435 = p434 <= v_u_2.AIM_FRESH_S
	else
		v435 = false
	end
	return v435
end
return v_u_1