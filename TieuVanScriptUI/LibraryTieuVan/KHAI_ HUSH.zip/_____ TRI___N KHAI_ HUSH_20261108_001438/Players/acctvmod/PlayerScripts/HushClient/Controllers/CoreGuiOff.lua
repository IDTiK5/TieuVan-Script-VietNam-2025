-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / CoreGuiOff

local v_u_1 = game:GetService("StarterGui")
local v_u_2 = game:GetService("TextChatService")
local v_u_3 = {
	Enum.CoreGuiType.PlayerList,
	Enum.CoreGuiType.Backpack,
	Enum.CoreGuiType.Health,
	Enum.CoreGuiType.EmotesMenu
}
local v_u_4 = nil
local v_u_5 = nil
local v6 = {
	["name"] = "CoreGuiOff",
	["order"] = 1
}
for _, v_u_7 in { "SelfView", "Captures" } do
	local v8, v9 = pcall(function()
		-- upvalues: (copy) v_u_7
		return Enum.CoreGuiType[v_u_7]
	end)
	if not (v8 and v9) then
		continue
	end
	table.insert(v_u_3, v9)
end
local function v_u_12() -- name: disableCore
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	for _, v_u_10 in v_u_3 do
		local function v11()
			-- upvalues: (ref) v_u_1, (copy) v_u_10
			v_u_1:SetCoreGuiEnabled(v_u_10, false)
		end
		pcall(v11)
	end
end
local function v_u_21(p_u_13) -- name: setChatVisible
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (ref) v_u_4, (ref) v_u_5
	local function v16()
		-- upvalues: (ref) v_u_2, (copy) p_u_13
		local v14 = v_u_2:FindFirstChildOfClass("ChatWindowConfiguration")
		if v14 then
			v14.Enabled = p_u_13
		end
		local v15 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
		if v15 then
			v15.Enabled = p_u_13
		end
	end
	pcall(v16)
	local function v17()
		-- upvalues: (ref) v_u_1, (copy) p_u_13
		v_u_1:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, p_u_13)
	end
	pcall(v17)
	local function v20()
		-- upvalues: (ref) v_u_2, (copy) p_u_13, (ref) v_u_4, (ref) v_u_5
		local v18 = v_u_2:FindFirstChildOfClass("BubbleChatConfiguration")
		if v18 then
			if p_u_13 then
				if v_u_5 ~= nil then
					v18.Enabled = v_u_5
					v_u_5 = nil
				end
			else
				local v19 = v_u_4 and v_u_4.config
				if v19 then
					v19 = v_u_4.config.flag("SquadChat") == true
				end
				if v19 and (v_u_5 == nil and v18.Enabled) then
					v_u_5 = true
					v18.Enabled = false
					return
				end
			end
		end
	end
	pcall(v20)
end
local function v_u_58(p_u_22) -- name: bridgeViewport
	local v23, v_u_24 = pcall(function()
		-- upvalues: (copy) p_u_22
		return p_u_22.shared.Theme
	end)
	if v23 and (type(v_u_24) == "table" and v_u_24.devViewportChanged) then
		v_u_24.watch()
		v_u_24.devViewportChanged:Connect(function(p25)
			-- upvalues: (copy) p_u_22
			p_u_22.emit("ui.rebuild", p25)
		end)
		p_u_22.command("ui.viewport", function(p26)
			-- upvalues: (copy) p_u_22, (copy) v_u_24
			local v27 = p_u_22.player
			local v28 = p26[1]
			if v28 == "off" or v28 == "auto" then
				v27:SetAttribute("DevViewport", nil)
				local v29 = v_u_24.viewport
				return "DevViewport off -> viewport " .. tostring(v29())
			end
			if v28 == "rebuild" then
				p_u_22.emit("ui.rebuild", v_u_24.viewport())
				local v30 = v_u_24.viewport
				return "ui.rebuild fired at " .. tostring(v30())
			end
			local v31 = tonumber(v28)
			local v32 = p26[2]
			local v33 = tonumber(v32)
			if v31 and v33 then
				local v34 = math.floor(v31)
				local v35 = math.clamp(v34, 64, 7680)
				local v36 = math.floor(v33)
				local v37 = math.clamp(v36, 64, 4320)
				v27:SetAttribute("DevViewport", Vector2.new(v35, v37))
				return string.format("DevViewport %dx%d set, ui.rebuild follows", v35, v37)
			end
			local v38 = v_u_24.devViewport()
			local v39 = string.format
			local v40 = v_u_24.viewport
			local v41 = tostring(v40())
			local v42 = tostring(v38)
			local v43 = v_u_24.uiScale()
			local v44 = v_u_24.refSize
			local v45 = tostring(v44())
			local v46 = v_u_24.isTouch
			return v39("usage: ui.viewport <w> <h> | off | rebuild  (now: viewport=%s dev=%s scale=%.2f ref=%s touch=%s)", v41, v42, v43, v45, (tostring(v46())))
		end)
		p_u_22.command("ui.safe", function(p47)
			-- upvalues: (copy) p_u_22, (copy) v_u_24
			local v48 = p_u_22.player
			local v49 = p47[1]
			if v49 == "off" or v49 == "auto" then
				v48:SetAttribute("DevSafeInsets", nil)
				return "DevSafeInsets off"
			else
				local v50 = tonumber(v49)
				local v51 = p47[2]
				local v52 = tonumber(v51)
				local v53 = p47[3]
				local v54 = tonumber(v53)
				local v55 = p47[4]
				local v56 = tonumber(v55)
				if v50 and (v52 and (v54 and v56)) then
					v48:SetAttribute("DevSafeInsets", Rect.new(math.max(0, v50), math.max(0, v52), math.max(0, v54), (math.max(0, v56))))
					return string.format("DevSafeInsets %d %d %d %d set, ui.rebuild follows", v50, v52, v54, v56)
				else
					local v57 = v_u_24.safeInsets()
					return string.format("usage: ui.safe <left> <top> <right> <bottom> | off  (now: left %d top %d right %d bottom %d)", v57.left, v57.top, v57.right, v57.bottom)
				end
			end
		end)
	end
end
function v6.init(p59) -- name: init
	-- upvalues: (ref) v_u_4, (copy) v_u_58, (copy) v_u_12, (copy) v_u_1
	v_u_4 = p59
	local v60 = v_u_58
	pcall(v60, p59)
	v_u_12()
	local v_u_61 = "ResetButtonCallback"
	local v_u_62 = false
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (copy) v_u_61, (copy) v_u_62
		for _ = 1, 40 do
			local function v63()
				-- upvalues: (ref) v_u_1, (ref) v_u_61, (ref) v_u_62
				v_u_1:SetCore(v_u_61, v_u_62)
			end
			if pcall(v63) then
				return
			end
			task.wait(0.5)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_12
		for _ = 1, 10 do
			task.wait(2)
			v_u_12()
		end
	end)
end
function v6.start() -- name: start
	-- upvalues: (ref) v_u_4, (copy) v_u_21, (copy) v_u_12, (copy) v_u_1, (copy) v_u_3, (copy) v_u_2
	local v64 = v_u_4
	if v64 then
		v64 = v_u_4.session
	end
	if v64 and v64.onPlaceChanged then
		v64.onPlaceChanged(function(p65)
			-- upvalues: (ref) v_u_21, (ref) v_u_12
			v_u_21(p65 ~= "Raid")
			v_u_12()
		end)
	end
	local v66 = v_u_4
	if v66 then
		v66 = v_u_4.player
	end
	if v66 then
		v66.CharacterAdded:Connect(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_1
			v_u_12()
			local v_u_67 = "ResetButtonCallback"
			local v_u_68 = false
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (copy) v_u_67, (copy) v_u_68
				for _ = 1, 40 do
					local function v69()
						-- upvalues: (ref) v_u_1, (ref) v_u_67, (ref) v_u_68
						v_u_1:SetCore(v_u_67, v_u_68)
					end
					if pcall(v69) then
						return
					end
					task.wait(0.5)
				end
			end)
		end)
	end
	if v_u_4 and v_u_4.command then
		v_u_4.command("coregui.state", function()
			-- upvalues: (ref) v_u_3, (ref) v_u_1, (ref) v_u_2
			local v70 = {}
			for _, v71 in v_u_3 do
				local v72 = v_u_1
				local v73 = v71.Name .. "=" .. tostring(v72:GetCoreGuiEnabled(v71))
				table.insert(v70, v73)
			end
			local v74 = v_u_2:FindFirstChildOfClass("ChatWindowConfiguration")
			local v75 = "Chat="
			if v74 then
				v74 = v74.Enabled
			end
			local v76 = v75 .. tostring(v74)
			table.insert(v70, v76)
			local v77 = v_u_2:FindFirstChildOfClass("BubbleChatConfiguration")
			local v78 = "Bubbles="
			if v77 then
				v77 = v77.Enabled
			end
			local v79 = v78 .. tostring(v77)
			table.insert(v70, v79)
			return table.concat(v70, " ")
		end)
	end
end
return v6