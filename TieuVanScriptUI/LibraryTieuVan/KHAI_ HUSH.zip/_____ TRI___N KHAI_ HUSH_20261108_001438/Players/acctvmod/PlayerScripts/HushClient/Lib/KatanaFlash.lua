-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KatanaFlash

local v_u_1 = {
	["NAME"] = "KatanaFlash",
	["MAX"] = 4,
	["RANGE"] = 9
}
local v_u_2 = {
	"Blade",
	"Edge",
	"Katana_Blade",
	"BladePart"
}
local function v_u_6(p3) -- name: pickPart
	-- upvalues: (copy) v_u_2
	for _, v4 in v_u_2 do
		local v5 = p3:FindFirstChild(v4, true)
		if v5 == nil or not v5:IsA("BasePart") then
			continue
		end
		return v5
	end
	if p3:IsA("Model") and p3.PrimaryPart ~= nil then
		return p3.PrimaryPart
	elseif p3:IsA("BasePart") then
		return p3
	else
		return p3:FindFirstChildWhichIsA("BasePart", true)
	end
end
function v_u_1.set(p_u_7, p8) -- name: set
	-- upvalues: (copy) v_u_1, (copy) v_u_6
	if p_u_7 == nil then
		return false
	end
	local v_u_9 = (type(p8) ~= "number" or p8 ~= p8) and 0 or math.clamp(p8, 0, 1)
	local function v12()
		-- upvalues: (copy) p_u_7, (ref) v_u_1, (copy) v_u_9, (ref) v_u_6
		local v10 = p_u_7:FindFirstChild(v_u_1.NAME, true)
		if v_u_9 <= 0.001 then
			if v10 == nil or not v10.Enabled then
				return false
			end
			v10.Enabled = false
			return true
		end
		if v10 == nil then
			local v11 = v_u_6(p_u_7)
			if v11 == nil then
				return false
			end
			v10 = Instance.new("PointLight")
			v10.Name = v_u_1.NAME
			v10.Color = Color3.fromRGB(235, 245, 255)
			v10.Range = v_u_1.RANGE
			v10.Shadows = false
			v10.Parent = v11
		end
		v10.Brightness = v_u_1.MAX * v_u_9
		v10.Enabled = true
		return true
	end
	local v13, v14 = pcall(v12)
	if v13 then
		v13 = v14 == true
	end
	return v13
end
return v_u_1