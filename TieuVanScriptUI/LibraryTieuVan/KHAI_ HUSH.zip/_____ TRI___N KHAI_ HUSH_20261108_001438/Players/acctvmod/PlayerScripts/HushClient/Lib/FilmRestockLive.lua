-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmRestockLive

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
v_u_3.CONFIRM_SECONDS = 6
v_u_3.CONFIRM_GUARD = 0.4
v_u_3.PATCH_LEAD = 600
v_u_3.EXTENDS = {
	{ 3600, "+1 H" },
	{ 10800, "+3 H" },
	{ 21600, "+6 H" },
	{ 86400, "+24 H" }
}
v_u_3.FIXED_TEXT = "Fixed once the restock is saved. Use ADD ROW or start a new restock."
v_u_3.HIST_REPORTS = 5
v_u_3.HIST_LOG = 10
v_u_3.NAME_MAX = 24
local function v_u_9(p5) -- name: copy
	-- upvalues: (copy) v_u_9
	if type(p5) ~= "table" then
		return p5
	end
	local v6 = {}
	for v7, v8 in p5 do
		v6[v7] = v_u_9(v8)
	end
	return v6
end
local v_u_621 = nil
local v_u_624 = nil
function v_u_3.byIx(p12, p13) -- name: byIx
	if type(p12) ~= "table" then
		return nil
	end
	local v14 = p12[p13]
	if v14 == nil then
		v14 = p12[tostring(p13)]
	end
	return v14
end
local function v_u_19(p15) -- name: isFraction
	-- upvalues: (ref) v_u_624
	if type(p15) ~= "string" then
		return false
	end
	local v16 = string.gsub(p15, "^%s+", "")
	local v17 = string.gsub(v16, "%s+$", "")
	local v18 = false
	if v_u_624 == nil then
		v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
	end
	if v_u_624.parseNumber(v17) == nil then
		v18 = string.match(v17, "^%d*[%.,]%d+$") ~= nil
	end
	return v18
end
v_u_3.isFraction = v_u_19
local function v_u_29(p_u_20) -- name: itemName
	-- upvalues: (copy) v_u_2
	local v_u_21 = "Items"
	local function v22()
		-- upvalues: (ref) v_u_2, (copy) v_u_21
		return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_21, 5)))
	end
	local v23, v_u_24 = pcall(v22)
	if not v23 then
		v_u_24 = nil
	end
	local v26, v27 = pcall(function()
		-- upvalues: (copy) v_u_24, (copy) p_u_20
		if v_u_24 then
			local v25 = p_u_20
			if type(v25) == "string" then
				return v_u_24.get(p_u_20)
			end
		end
		return nil
	end)
	if v26 and type(v27) == "table" then
		local v28 = v27.name
		if type(v28) == "string" then
			return v27.name
		end
	end
	return tostring(p_u_20)
end
function v_u_3.mode(p30) -- name: mode
	if type(p30) == "table" then
		local v31 = p30.plan
		if type(v31) == "table" then
			local v32 = p30.plan
			return v32.st == "p" and (v32.ph == "over" and "over" or (v32.ho == true and "held" or (v32.ph == "soon" and "planned" or "live"))) or ((v32.st == "e" or (v32.st == "x" or v32.st == "c")) and "ended" or "none")
		end
	end
	return "none"
end
function v_u_3.patchOpen(p33, p34) -- name: patchOpen
	-- upvalues: (copy) v_u_3
	local v35
	if type(p33) == "table" then
		local v36 = p33.t0
		if type(v36) == "number" and (v36 == v36 and v36 ~= (1 / 0)) then
			v35 = v36 ~= (-1 / 0)
		else
			v35 = false
		end
		if v35 then
			if type(p34) == "number" and (p34 == p34 and p34 ~= (1 / 0)) then
				v35 = p34 ~= (-1 / 0)
			else
				v35 = false
			end
			if v35 then
				v35 = p34 < p33.t0 - v_u_3.PATCH_LEAD
			end
		end
	else
		v35 = false
	end
	return v35
end
function v_u_3.endLine(p37, p38) -- name: endLine
	-- upvalues: (ref) v_u_621, (copy) v_u_2, (ref) v_u_624
	if v_u_621 == nil then
		local v_u_39 = "BmRs"
		local function v40()
			-- upvalues: (ref) v_u_2, (copy) v_u_39
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_39, 5)))
		end
		local v41, v42 = pcall(v40)
		if not v41 then
			v42 = nil
		end
		v_u_621 = v42
	end
	local v43 = v_u_621
	if type(p37) == "table" then
		local v44 = p37.t1
		local v45
		if type(v44) == "number" and (v44 == v44 and v44 ~= (1 / 0)) then
			v45 = v44 ~= (-1 / 0)
		else
			v45 = false
		end
		if v45 and v43 ~= nil then
			local v46 = p37.t0
			local v47
			if type(v46) == "number" and (v46 == v46 and v46 ~= (1 / 0)) then
				v47 = v46 ~= (-1 / 0)
			else
				v47 = false
			end
			local v48 = not v47 and 0 or p37.t1 - p37.t0
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v49 = v_u_624.durationText(v48)
			return ("Ends %s, %s in all."):format(v43.fmtStart(p37.t1, p38), v49)
		end
	end
	return ""
end
function v_u_3.wordFromText(p50) -- name: wordFromText
	if type(p50) == "string" then
		local v51 = string.match(p50, "Type (%u+) to allow")
		if v51 == "PRICE" or (v51 == "AMOUNT" or v51 == "RARE") then
			return v51
		else
			return string.find(p50, "needs the typed word LONG", 1, true) and "LONG" or nil
		end
	else
		return nil
	end
end
function v_u_3.diffPlan(p_u_52, p_u_53, p_u_54) -- name: diffPlan
	-- upvalues: (ref) v_u_621, (copy) v_u_2, (copy) v_u_3, (ref) v_u_624
	local v_u_55 = {}
	local v_u_56 = {}
	local v_u_57 = 0
	if type(p_u_52) == "table" and type(p_u_53) == "table" then
		if v_u_621 == nil then
			local v_u_58 = "BmRs"
			local function v59()
				-- upvalues: (ref) v_u_2, (copy) v_u_58
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_58, 5)))
			end
			local v60, v61 = pcall(v59)
			if not v60 then
				v61 = nil
			end
			v_u_621 = v61
		end
		local v62 = v_u_621
		local v63
		if v62 then
			v63 = v62.RS
		else
			v63 = nil
		end
		local v64 = p_u_53.n
		local v65
		if type(v64) == "string" then
			local v66 = string.gsub(v64, "^%s+", "")
			v65 = string.gsub(v66, "%s+$", "")
		else
			v65 = ""
		end
		if v65 ~= "" and v65 ~= p_u_52.n then
			if #v65 > v_u_3.NAME_MAX then
				table.insert(v_u_55, "NAME is at most 24 characters.")
			else
				v_u_56.n = v65
				v_u_57 = v_u_57 + 1
			end
		end
		local function v92(p67, p68, p69, p70) -- name: intField
			-- upvalues: (copy) p_u_53, (ref) v_u_624, (copy) v_u_55, (ref) v_u_621, (ref) v_u_2, (copy) p_u_52, (copy) p_u_54, (ref) v_u_3, (copy) v_u_56, (ref) v_u_57
			local v71 = p_u_53[p67]
			local v72
			if type(v71) == "string" then
				local v73 = string.gsub(v71, "^%s+", "")
				v72 = string.gsub(v73, "%s+$", "")
			else
				v72 = ""
			end
			if v72 == "" then
				return
			else
				if v_u_624 == nil then
					v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
				end
				local v74 = v_u_624.parseNumber(v72)
				if v74 == nil or (v74 < p69 or p70 < v74) then
					local v75 = v_u_55
					local v76 = "%s must be a whole number from %s to %s."
					if v_u_621 == nil then
						local v_u_77 = "BmRs"
						local function v78()
							-- upvalues: (ref) v_u_2, (copy) v_u_77
							return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_77, 5)))
						end
						local v79, v80 = pcall(v78)
						if not v79 then
							v80 = nil
						end
						v_u_621 = v80
					end
					local v81 = v_u_621
					local v82
					if v81 and v81.commas then
						v82 = v81.commas(p69)
					else
						v82 = tostring(p69)
					end
					if v_u_621 == nil then
						local v_u_83 = "BmRs"
						local function v84()
							-- upvalues: (ref) v_u_2, (copy) v_u_83
							return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_83, 5)))
						end
						local v85, v86 = pcall(v84)
						if not v85 then
							v86 = nil
						end
						v_u_621 = v86
					end
					local v87 = v_u_621
					local v88
					if v87 and v87.commas then
						v88 = v87.commas(p70)
					else
						v88 = tostring(p70)
					end
					table.insert(v75, v76:format(p68, v82, v88))
				elseif v74 ~= p_u_52[p67] then
					if p67 == "pe" or p67 == "wd" then
						local v89 = p_u_54
						local v90
						if type(v89) == "number" and (v89 == v89 and v89 ~= (1 / 0)) then
							v90 = v89 ~= (-1 / 0)
						else
							v90 = false
						end
						if v90 and not v_u_3.patchOpen(p_u_52, p_u_54) then
							local v91 = v_u_55
							table.insert(v91, "EXPECTED PLAYERS and DRAW WINDOW can change until 10 minutes before the start.")
							return
						end
					end
					v_u_56[p67] = v74
					v_u_57 = v_u_57 + 1
				end
			end
		end
		local v93 = not v63 and {
			["mr"] = 50,
			["ma"] = 365,
			["mc"] = 365,
			["mx"] = 50
		} or v63.gateMax
		local v94 = v93.mr
		local v95 = p_u_53.mr
		local v96
		if type(v95) == "string" then
			local v97 = string.gsub(v95, "^%s+", "")
			v96 = string.gsub(v97, "%s+$", "")
		else
			v96 = ""
		end
		if v96 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v98 = v_u_624.parseNumber(v96)
			if v98 == nil or (v98 < 0 or v94 < v98) then
				local v99 = "%s must be a whole number from %s to %s."
				local v100 = "MIN RAIDS"
				if v_u_621 == nil then
					local v_u_101 = "BmRs"
					local function v102()
						-- upvalues: (ref) v_u_2, (copy) v_u_101
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_101, 5)))
					end
					local v103, v104 = pcall(v102)
					if not v103 then
						v104 = nil
					end
					v_u_621 = v104
				end
				local v105 = v_u_621
				local v106
				if v105 and v105.commas then
					v106 = v105.commas(0)
				else
					v106 = tostring(0)
				end
				if v_u_621 == nil then
					local v_u_107 = "BmRs"
					local function v108()
						-- upvalues: (ref) v_u_2, (copy) v_u_107
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_107, 5)))
					end
					local v109, v110 = pcall(v108)
					if not v109 then
						v110 = nil
					end
					v_u_621 = v110
				end
				local v111 = v_u_621
				local v112
				if v111 and v111.commas then
					v112 = v111.commas(v94)
				else
					v112 = tostring(v94)
				end
				table.insert(v_u_55, v99:format(v100, v106, v112))
			elseif v98 ~= p_u_52.mr then
				v_u_56.mr = v98
				v_u_57 = v_u_57 + 1
			end
		end
		local v113 = v93.ma
		local v114 = p_u_53.ma
		local v115
		if type(v114) == "string" then
			local v116 = string.gsub(v114, "^%s+", "")
			v115 = string.gsub(v116, "%s+$", "")
		else
			v115 = ""
		end
		if v115 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v117 = v_u_624.parseNumber(v115)
			if v117 == nil or (v117 < 0 or v113 < v117) then
				local v118 = "%s must be a whole number from %s to %s."
				local v119 = "MIN ACCOUNT AGE"
				if v_u_621 == nil then
					local v_u_120 = "BmRs"
					local function v121()
						-- upvalues: (ref) v_u_2, (copy) v_u_120
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_120, 5)))
					end
					local v122, v123 = pcall(v121)
					if not v122 then
						v123 = nil
					end
					v_u_621 = v123
				end
				local v124 = v_u_621
				local v125
				if v124 and v124.commas then
					v125 = v124.commas(0)
				else
					v125 = tostring(0)
				end
				if v_u_621 == nil then
					local v_u_126 = "BmRs"
					local function v127()
						-- upvalues: (ref) v_u_2, (copy) v_u_126
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_126, 5)))
					end
					local v128, v129 = pcall(v127)
					if not v128 then
						v129 = nil
					end
					v_u_621 = v129
				end
				local v130 = v_u_621
				local v131
				if v130 and v130.commas then
					v131 = v130.commas(v113)
				else
					v131 = tostring(v113)
				end
				table.insert(v_u_55, v118:format(v119, v125, v131))
			elseif v117 ~= p_u_52.ma then
				v_u_56.ma = v117
				v_u_57 = v_u_57 + 1
			end
		end
		local v132 = v93.mc
		local v133 = p_u_53.mc
		local v134
		if type(v133) == "string" then
			local v135 = string.gsub(v133, "^%s+", "")
			v134 = string.gsub(v135, "%s+$", "")
		else
			v134 = ""
		end
		if v134 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v136 = v_u_624.parseNumber(v134)
			if v136 == nil or (v136 < 0 or v132 < v136) then
				local v137 = "%s must be a whole number from %s to %s."
				local v138 = "MIN PLAYED DAYS"
				if v_u_621 == nil then
					local v_u_139 = "BmRs"
					local function v140()
						-- upvalues: (ref) v_u_2, (copy) v_u_139
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_139, 5)))
					end
					local v141, v142 = pcall(v140)
					if not v141 then
						v142 = nil
					end
					v_u_621 = v142
				end
				local v143 = v_u_621
				local v144
				if v143 and v143.commas then
					v144 = v143.commas(0)
				else
					v144 = tostring(0)
				end
				if v_u_621 == nil then
					local v_u_145 = "BmRs"
					local function v146()
						-- upvalues: (ref) v_u_2, (copy) v_u_145
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_145, 5)))
					end
					local v147, v148 = pcall(v146)
					if not v147 then
						v148 = nil
					end
					v_u_621 = v148
				end
				local v149 = v_u_621
				local v150
				if v149 and v149.commas then
					v150 = v149.commas(v132)
				else
					v150 = tostring(v132)
				end
				table.insert(v_u_55, v137:format(v138, v144, v150))
			elseif v136 ~= p_u_52.mc then
				v_u_56.mc = v136
				v_u_57 = v_u_57 + 1
			end
		end
		local v151 = v93.mx
		local v152 = p_u_53.mx
		local v153
		if type(v152) == "string" then
			local v154 = string.gsub(v152, "^%s+", "")
			v153 = string.gsub(v154, "%s+$", "")
		else
			v153 = ""
		end
		if v153 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v155 = v_u_624.parseNumber(v153)
			if v155 == nil or (v155 < 0 or v151 < v155) then
				local v156 = "%s must be a whole number from %s to %s."
				local v157 = "MIN EXTRACTIONS"
				if v_u_621 == nil then
					local v_u_158 = "BmRs"
					local function v159()
						-- upvalues: (ref) v_u_2, (copy) v_u_158
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_158, 5)))
					end
					local v160, v161 = pcall(v159)
					if not v160 then
						v161 = nil
					end
					v_u_621 = v161
				end
				local v162 = v_u_621
				local v163
				if v162 and v162.commas then
					v163 = v162.commas(0)
				else
					v163 = tostring(0)
				end
				if v_u_621 == nil then
					local v_u_164 = "BmRs"
					local function v165()
						-- upvalues: (ref) v_u_2, (copy) v_u_164
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_164, 5)))
					end
					local v166, v167 = pcall(v165)
					if not v166 then
						v167 = nil
					end
					v_u_621 = v167
				end
				local v168 = v_u_621
				local v169
				if v168 and v168.commas then
					v169 = v168.commas(v151)
				else
					v169 = tostring(v151)
				end
				table.insert(v_u_55, v156:format(v157, v163, v169))
			elseif v155 ~= p_u_52.mx then
				v_u_56.mx = v155
				v_u_57 = v_u_57 + 1
			end
		end
		local v170 = not v63 and 720 or v63.lkMax
		local v171 = p_u_53.lk
		local v172
		if type(v171) == "string" then
			local v173 = string.gsub(v171, "^%s+", "")
			v172 = string.gsub(v173, "%s+$", "")
		else
			v172 = ""
		end
		if v172 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v174 = v_u_624.parseNumber(v172)
			if v174 == nil or (v174 < 0 or v170 < v174) then
				local v175 = "%s must be a whole number from %s to %s."
				local v176 = "RESALE LOCK"
				if v_u_621 == nil then
					local v_u_177 = "BmRs"
					local function v178()
						-- upvalues: (ref) v_u_2, (copy) v_u_177
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_177, 5)))
					end
					local v179, v180 = pcall(v178)
					if not v179 then
						v180 = nil
					end
					v_u_621 = v180
				end
				local v181 = v_u_621
				local v182
				if v181 and v181.commas then
					v182 = v181.commas(0)
				else
					v182 = tostring(0)
				end
				if v_u_621 == nil then
					local v_u_183 = "BmRs"
					local function v184()
						-- upvalues: (ref) v_u_2, (copy) v_u_183
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_183, 5)))
					end
					local v185, v186 = pcall(v184)
					if not v185 then
						v186 = nil
					end
					v_u_621 = v186
				end
				local v187 = v_u_621
				local v188
				if v187 and v187.commas then
					v188 = v187.commas(v170)
				else
					v188 = tostring(v170)
				end
				table.insert(v_u_55, v175:format(v176, v182, v188))
			elseif v174 ~= p_u_52.lk then
				v_u_56.lk = v174
				v_u_57 = v_u_57 + 1
			end
		end
		v92("pe", "EXPECTED PLAYERS", 1, not v63 and 100000 or v63.peMax)
		v92("wd", "DRAW WINDOW", 0, not (v63 and v63.wdMax) and 10 or v63.wdMax)
		if p_u_53.rv ~= nil and p_u_53.rv ~= p_u_52.rv then
			local v189 = p_u_53.rv
			local v190
			if type(v189) == "number" and (v189 == v189 and v189 ~= (1 / 0)) then
				v190 = v189 ~= (-1 / 0)
			else
				v190 = false
			end
			if v190 then
				v190 = v189 == math.floor(v189)
			end
			if v190 and (p_u_53.rv >= 0 and p_u_53.rv <= 2) then
				v_u_56.rv = p_u_53.rv
				v_u_57 = v_u_57 + 1
			else
				table.insert(v_u_55, "SHOW TO PLAYERS is not valid.")
			end
		end
		if p_u_53.al ~= nil and p_u_53.al ~= p_u_52.al then
			local v191 = p_u_53.al
			local v192
			if type(v191) == "number" and (v191 == v191 and v191 ~= (1 / 0)) then
				v192 = v191 ~= (-1 / 0)
			else
				v192 = false
			end
			if v192 then
				v192 = v191 == math.floor(v191)
			end
			if v192 and p_u_53.al >= 0 and p_u_53.al <= (not v63 and 168 or v63.alMax) then
				v_u_56.al = p_u_53.al
				v_u_57 = v_u_57 + 1
			else
				table.insert(v_u_55, "SHOW TIMER FROM is not valid.")
			end
		end
		local v193 = p_u_53.rows
		if type(v193) == "table" then
			local v194 = p_u_52.ix
			if type(v194) == "table" then
				local v195 = {}
				local v196 = false
				for v197, v198 in p_u_53.rows do
					local v199 = p_u_52.ix[v197]
					if type(v199) ~= "table" or (v199.bad == true or type(v198) ~= "table") then
						continue
					end
					local v200 = {}
					local v201 = v198.u
					local v202
					if type(v201) == "string" then
						local v203 = string.gsub(v201, "^%s+", "")
						v202 = string.gsub(v203, "%s+$", "")
					else
						v202 = ""
					end
					if v202 ~= "" then
						if v_u_624 == nil then
							v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
						end
						local v204 = v_u_624.parseNumber(v202)
						if v204 == nil or v204 < 1 or (not v63 and 9999999 or v63.priceMax) < v204 then
							local v205 = "Row %d: PRICE EACH must be a whole number from 1 to %s."
							local v206 = not v63 and 9999999 or v63.priceMax
							if v_u_621 == nil then
								local v_u_207 = "BmRs"
								local function v208()
									-- upvalues: (ref) v_u_2, (copy) v_u_207
									return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_207, 5)))
								end
								local v209, v210 = pcall(v208)
								if not v209 then
									v210 = nil
								end
								v_u_621 = v210
							end
							local v211 = v_u_621
							local v212
							if v211 and v211.commas then
								v212 = v211.commas(v206)
							else
								v212 = tostring(v206)
							end
							table.insert(v_u_55, v205:format(v197, v212))
						elseif v204 ~= v199.u then
							v200.u = v204
						end
					end
					local v213 = v198.c
					local v214
					if type(v213) == "string" then
						local v215 = string.gsub(v213, "^%s+", "")
						v214 = string.gsub(v215, "%s+$", "")
					else
						v214 = ""
					end
					if v214 ~= "" then
						if v_u_624 == nil then
							v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
						end
						local v216 = v_u_624.parseNumber(v214)
						if v216 == nil or v216 < 0 or (not v63 and 10000000 or v63.stockMax) < v216 then
							table.insert(v_u_55, ("Row %d: LIMIT PER PLAYER must be a whole number, 0 for none."):format(v197))
						elseif v216 ~= v199.c then
							v200.c = v216
						end
					end
					if next(v200) == nil then
						continue
					end
					v195[v197] = v200
					v196 = true
					v_u_57 = v_u_57 + 1
					if v200.u == nil or v200.c == nil then
						continue
					end
					v_u_57 = v_u_57 + 1
				end
				if v196 then
					v_u_56.rows = v195
				end
			end
		end
		if #v_u_55 > 0 then
			return nil, v_u_55, 0
		elseif v_u_57 == 0 then
			return nil, v_u_55, 0
		else
			return v_u_56, v_u_55, v_u_57
		end
	else
		return nil, { "No restock." }, 0
	end
end
function v_u_3.editFields(p217, p218) -- name: editFields
	-- upvalues: (ref) v_u_621, (copy) v_u_2, (ref) v_u_624
	if v_u_621 == nil then
		local v_u_219 = "BmRs"
		local function v220()
			-- upvalues: (ref) v_u_2, (copy) v_u_219
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_219, 5)))
		end
		local v221, v222 = pcall(v220)
		if not v221 then
			v222 = nil
		end
		v_u_621 = v222
	end
	local v223 = v_u_621
	if v_u_624 == nil then
		v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
	end
	local v224 = v_u_624
	if type(p217) ~= "table" or type(p218) ~= "table" then
		return nil, "no form"
	end
	local v225 = p218.ix
	if type(v225) ~= "table" or v223 == nil then
		return nil, "no form"
	end
	if p217.replace == nil or p217.replace ~= p218.r then
		return nil, "the form is not an edit of this plan"
	end
	if p218.st ~= "p" or p218.ph ~= "soon" then
		return nil, "the plan has started"
	end
	local v226 = v223.parseTime
	local v227 = p217.startText
	local v228
	if type(v227) == "string" then
		local v229 = string.gsub(v227, "^%s+", "")
		v228 = string.gsub(v229, "%s+$", "")
	else
		v228 = ""
	end
	local v230 = v226(v228, p217.zone)
	if v230 == nil then
		return nil, "the start changed"
	end
	local v231 = v230 - p218.t0
	if math.abs(v231) >= 60 then
		return nil, "the start changed"
	end
	local v232 = p217.dur
	local v233
	if type(v232) == "number" and (v232 == v232 and v232 ~= (1 / 0)) then
		v233 = v232 ~= (-1 / 0)
	else
		v233 = false
	end
	if not v233 or p217.dur ~= p218.t1 - p218.t0 then
		return nil, "the duration changed"
	end
	local v234 = p217.rows
	if type(v234) ~= "table" or #p217.rows ~= #p218.ix then
		return nil, "the rows changed"
	end
	local v235 = {}
	for v236, v237 in p217.rows do
		local v238 = p218.ix[v236]
		if type(v238) ~= "table" or (v238.bad == true or (v238.off == true or v238.dr ~= nil)) then
			return nil, "a repeated or removed row"
		end
		local v239 = string.lower
		local v240 = v237.id
		local v241
		if type(v240) == "string" then
			local v242 = string.gsub(v240, "^%s+", "")
			v241 = string.gsub(v242, "%s+$", "")
		else
			v241 = ""
		end
		if v239(v241) ~= v238.id then
			return nil, "an item changed"
		end
		local v243 = v237.every
		local v244
		if type(v243) == "string" then
			local v245 = string.gsub(v243, "^%s+", "")
			v244 = string.gsub(v245, "%s+$", "")
		else
			v244 = ""
		end
		if v244 ~= "" then
			return nil, "a repeat was typed"
		end
		local v246 = v237.times
		local v247
		if type(v246) == "string" then
			local v248 = string.gsub(v246, "^%s+", "")
			v247 = string.gsub(v248, "%s+$", "")
		else
			v247 = ""
		end
		if v247 ~= "" then
			return nil, "a repeat was typed"
		end
		if v224.parseNumber(v237.s) ~= v238.s or (v224.parseNumber(v237.q1) ~= v238.q1 or (v224.parseNumber(v237.q2) ~= v238.q2 or v237.w ~= v238.w)) then
			return nil, "a fixed value of a row changed"
		end
		v235[v236] = {
			["u"] = v237.u,
			["c"] = v237.c
		}
	end
	return {
		["n"] = p217.name,
		["mr"] = p217.mr,
		["ma"] = p217.ma,
		["mc"] = p217.mc,
		["mx"] = p217.mx,
		["lk"] = p217.lk,
		["pe"] = p217.pe,
		["wd"] = p217.wd,
		["rv"] = p217.rv,
		["al"] = p217.al,
		["rows"] = v235
	}, nil
end
function v_u_3.editDiff(p249, p250, p251) -- name: editDiff
	-- upvalues: (copy) v_u_3
	local v252, v253 = v_u_3.editFields(p249, p250)
	if v252 == nil then
		return nil, {}, 0, v253
	end
	local v254, v255, v256 = v_u_3.diffPlan(p250, v252, p251)
	return v254, v255, v256, nil
end
local v_u_257 = {
	["soon"] = "WAITING",
	["draw"] = "OPENING",
	["live"] = "LIVE",
	["over"] = "OVER"
}
function v_u_3.rowTitle(p258, p259) -- name: rowTitle
	-- upvalues: (copy) v_u_29, (copy) v_u_257
	local v260 = { ("Row %d"):format(p258) }
	if type(p259) ~= "table" or p259.bad == true then
		table.insert(v260, "unreadable")
		return table.concat(v260, "  \194\183  ")
	end
	local v261 = v_u_29(p259.id)
	table.insert(v260, v261)
	local v262 = p259.dr
	if type(v262) == "table" then
		local v263 = p259.dr.i
		local v264
		if type(v263) == "number" and (v263 == v263 and v263 ~= (1 / 0)) then
			v264 = v263 ~= (-1 / 0)
		else
			v264 = false
		end
		if v264 then
			local v265 = p259.dr.n
			local v266
			if type(v265) == "number" and (v265 == v265 and v265 ~= (1 / 0)) then
				v266 = v265 ~= (-1 / 0)
			else
				v266 = false
			end
			if v266 then
				local v267 = p259.dr.i
				local v268 = p259.dr.n
				table.insert(v260, ("Drop %d of %d"):format(v267, v268))
			end
		end
	end
	local v269 = p259.off == true and "OUT OF SALE" or (v_u_257[p259.ph] or "WAITING")
	table.insert(v260, v269)
	return table.concat(v260, "  \194\183  ")
end
function v_u_3.rowStats(p270, p271) -- name: rowStats
	-- upvalues: (ref) v_u_621, (copy) v_u_2
	if type(p270) ~= "table" or p270.bad == true then
		return ""
	end
	if type(p271) == "table" then
		local v272 = p271.known
		local v273
		if type(v272) == "number" and (v272 == v272 and v272 ~= (1 / 0)) then
			v273 = v272 ~= (-1 / 0)
		else
			v273 = false
		end
		if v273 and p271.known >= 1 then
			local v274 = p271.cap
			local v275
			if type(v274) == "number" and (v274 == v274 and v274 ~= (1 / 0)) then
				v275 = v274 ~= (-1 / 0)
			else
				v275 = false
			end
			local v276
			if v275 and p271.cap > 0 then
				v276 = p271.cap
			else
				v276 = p270.s or 0
			end
			local v277
			if v276 > 0 then
				local v278 = (p271.sold or 0) * 100 / v276
				v277 = math.floor(v278)
			else
				v277 = 0
			end
			local v279 = {}
			local v280 = "sold %s of %s (%d percent)"
			local v281 = p271.sold or 0
			if v_u_621 == nil then
				local v_u_282 = "BmRs"
				local function v283()
					-- upvalues: (ref) v_u_2, (copy) v_u_282
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_282, 5)))
				end
				local v284, v285 = pcall(v283)
				if not v284 then
					v285 = nil
				end
				v_u_621 = v285
			end
			local v286 = v_u_621
			local v287
			if v286 and v286.commas then
				v287 = v286.commas(v281)
			else
				v287 = tostring(v281)
			end
			if v_u_621 == nil then
				local v_u_288 = "BmRs"
				local function v289()
					-- upvalues: (ref) v_u_2, (copy) v_u_288
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_288, 5)))
				end
				local v290, v291 = pcall(v289)
				if not v290 then
					v291 = nil
				end
				v_u_621 = v291
			end
			local v292 = v_u_621
			local v293
			if v292 and v292.commas then
				v293 = v292.commas(v276)
			else
				v293 = tostring(v276)
			end
			local v294 = v280:format(v287, v293, v277)
			local v295 = "left %s"
			local v296 = p271.rem or 0
			if v_u_621 == nil then
				local v_u_297 = "BmRs"
				local function v298()
					-- upvalues: (ref) v_u_2, (copy) v_u_297
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_297, 5)))
				end
				local v299, v300 = pcall(v298)
				if not v299 then
					v300 = nil
				end
				v_u_621 = v300
			end
			local v301 = v_u_621
			local v302
			if v301 and v301.commas then
				v302 = v301.commas(v296)
			else
				v302 = tostring(v296)
			end
			local v303 = v295:format(v302)
			local v304 = "out on servers %s"
			local v305 = p271.out or 0
			if v_u_621 == nil then
				local v_u_306 = "BmRs"
				local function v307()
					-- upvalues: (ref) v_u_2, (copy) v_u_306
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_306, 5)))
				end
				local v308, v309 = pcall(v307)
				if not v308 then
					v309 = nil
				end
				v_u_621 = v309
			end
			local v310 = v_u_621
			local v311
			if v310 and v310.commas then
				v311 = v310.commas(v305)
			else
				v311 = tostring(v305)
			end
			local v312 = v304:format(v311)
			local v313 = "lost %s"
			local v314 = p271.lost or 0
			if v_u_621 == nil then
				local v_u_315 = "BmRs"
				local function v316()
					-- upvalues: (ref) v_u_2, (copy) v_u_315
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_315, 5)))
				end
				local v317, v318 = pcall(v316)
				if not v317 then
					v318 = nil
				end
				v_u_621 = v318
			end
			local v319 = v_u_621
			local v320
			if v319 and v319.commas then
				v320 = v319.commas(v314)
			else
				v320 = tostring(v314)
			end
			__set_list(v279, 1, {v294, v303, v312, v313:format(v320)})
			if p271.est == true then
				local v321 = p271.k
				local v322
				if type(v321) == "number" and (v321 == v321 and v321 ~= (1 / 0)) then
					v322 = v321 ~= (-1 / 0)
				else
					v322 = false
				end
				if v322 then
					local v323 = p271.known
					local v324 = p271.k
					table.insert(v279, ("estimate from %d of %d stock records"):format(v323, v324))
				end
			end
			local v325 = p271.dead
			local v326
			if type(v325) == "number" and (v325 == v325 and v325 ~= (1 / 0)) then
				v326 = v325 ~= (-1 / 0)
			else
				v326 = false
			end
			if v326 and p271.dead > 0 then
				local v327 = p271.dead
				table.insert(v279, ("%d stock records are empty"):format(v327))
			end
			local v328 = p271.bad
			local v329
			if type(v328) == "number" and (v328 == v328 and v328 ~= (1 / 0)) then
				v329 = v328 ~= (-1 / 0)
			else
				v329 = false
			end
			if v329 and p271.bad > 0 then
				local v330 = p271.bad
				table.insert(v279, ("%d stock records could not be read"):format(v330))
			end
			return table.concat(v279, "  \194\183  ")
		end
	end
	local v331 = "Total %s at %s. The stock is not read yet. SCAN ALL reads every stock record."
	local v332 = p270.s or 0
	if v_u_621 == nil then
		local v_u_333 = "BmRs"
		local function v334()
			-- upvalues: (ref) v_u_2, (copy) v_u_333
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_333, 5)))
		end
		local v335, v336 = pcall(v334)
		if not v335 then
			v336 = nil
		end
		v_u_621 = v336
	end
	local v337 = v_u_621
	local v338
	if v337 and v337.commas then
		v338 = v337.commas(v332)
	else
		v338 = tostring(v332)
	end
	local v339 = p270.u or 0
	if v_u_621 == nil then
		local v_u_340 = "BmRs"
		local function v341()
			-- upvalues: (ref) v_u_2, (copy) v_u_340
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_340, 5)))
		end
		local v342, v343 = pcall(v341)
		if not v342 then
			v343 = nil
		end
		v_u_621 = v343
	end
	local v344 = v_u_621
	local v345
	if v344 and v344.money then
		v345 = v344.money(v339)
	else
		v345 = "$" .. tostring(v339)
	end
	return v331:format(v338, v345)
end
function v_u_3.scanLines(p346, p347, p348) -- name: scanLines
	-- upvalues: (ref) v_u_624, (ref) v_u_621, (copy) v_u_2, (copy) v_u_29
	local v349 = {}
	if type(p346) ~= "table" then
		return v349
	end
	local v350 = p346.at
	local v351
	if type(v350) == "number" and (v350 == v350 and v350 ~= (1 / 0)) then
		v351 = v350 ~= (-1 / 0)
	else
		v351 = false
	end
	local v352
	if v351 then
		local v353
		if type(p348) == "number" and (p348 == p348 and p348 ~= (1 / 0)) then
			v353 = p348 ~= (-1 / 0)
		else
			v353 = false
		end
		if v353 then
			local v354 = ", %s ago"
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v355 = v_u_624.durationText
			local v356 = p348 - p346.at
			v352 = v354:format(v355((math.max(0, v356))))
		else
			v352 = ""
		end
	else
		v352 = ""
	end
	local v357 = "Scan%s: %s stock records read, %s failed."
	local v358 = p346.lanes or 0
	if v_u_621 == nil then
		local v_u_359 = "BmRs"
		local function v360()
			-- upvalues: (ref) v_u_2, (copy) v_u_359
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_359, 5)))
		end
		local v361, v362 = pcall(v360)
		if not v361 then
			v362 = nil
		end
		v_u_621 = v362
	end
	local v363 = v_u_621
	local v364
	if v363 and v363.commas then
		v364 = v363.commas(v358)
	else
		v364 = tostring(v358)
	end
	local v365 = p346.failed or 0
	if v_u_621 == nil then
		local v_u_366 = "BmRs"
		local function v367()
			-- upvalues: (ref) v_u_2, (copy) v_u_366
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_366, 5)))
		end
		local v368, v369 = pcall(v367)
		if not v368 then
			v369 = nil
		end
		v_u_621 = v369
	end
	local v370 = v_u_621
	local v371
	if v370 and v370.commas then
		v371 = v370.commas(v365)
	else
		v371 = tostring(v365)
	end
	table.insert(v349, v357:format(v352, v364, v371))
	local v372 = p346.rows
	if type(v372) == "table" then
		local v373 = {}
		for v374 in p346.rows do
			local v375 = tonumber(v374)
			if v375 == nil then
				continue
			end
			table.insert(v373, v375)
		end
		table.sort(v373)
		for _, v376 in v373 do
			local v377 = p346.rows
			local v378
			if type(v377) == "table" then
				v378 = v377[v376]
				if v378 == nil then
					v378 = v377[tostring(v376)]
				end
			else
				v378 = nil
			end
			local v379
			if type(p347) == "table" then
				local v380 = p347.ix
				if type(v380) == "table" then
					v379 = p347.ix[v376]
				else
					v379 = nil
				end
			else
				v379 = nil
			end
			if type(v378) ~= "table" then
				continue
			end
			local v381 = "Row %d  %s: sold %s, left %s, out on servers %s, lost %s"
			local v382 = type(v379) ~= "table" and "" or v_u_29(v379.id)
			local v383 = v378.sold or 0
			if v_u_621 == nil then
				local v_u_384 = "BmRs"
				local function v385()
					-- upvalues: (ref) v_u_2, (copy) v_u_384
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_384, 5)))
				end
				local v386, v387 = pcall(v385)
				if not v386 then
					v387 = nil
				end
				v_u_621 = v387
			end
			local v388 = v_u_621
			local v389
			if v388 and v388.commas then
				v389 = v388.commas(v383)
			else
				v389 = tostring(v383)
			end
			local v390 = v378.rem or 0
			if v_u_621 == nil then
				local v_u_391 = "BmRs"
				local function v392()
					-- upvalues: (ref) v_u_2, (copy) v_u_391
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_391, 5)))
				end
				local v393, v394 = pcall(v392)
				if not v393 then
					v394 = nil
				end
				v_u_621 = v394
			end
			local v395 = v_u_621
			local v396
			if v395 and v395.commas then
				v396 = v395.commas(v390)
			else
				v396 = tostring(v390)
			end
			local v397 = v378.out or 0
			if v_u_621 == nil then
				local v_u_398 = "BmRs"
				local function v399()
					-- upvalues: (ref) v_u_2, (copy) v_u_398
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_398, 5)))
				end
				local v400, v401 = pcall(v399)
				if not v400 then
					v401 = nil
				end
				v_u_621 = v401
			end
			local v402 = v_u_621
			local v403
			if v402 and v402.commas then
				v403 = v402.commas(v397)
			else
				v403 = tostring(v397)
			end
			local v404 = v378.lost or 0
			if v_u_621 == nil then
				local v_u_405 = "BmRs"
				local function v406()
					-- upvalues: (ref) v_u_2, (copy) v_u_405
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_405, 5)))
				end
				local v407, v408 = pcall(v406)
				if not v407 then
					v408 = nil
				end
				v_u_621 = v408
			end
			local v409 = v_u_621
			local v410
			if v409 and v409.commas then
				v410 = v409.commas(v404)
			else
				v410 = tostring(v404)
			end
			table.insert(v349, v381:format(v376, v382, v389, v396, v403, v410))
		end
	end
	return v349
end
function v_u_3.historyLines(p411, _) -- name: historyLines
	-- upvalues: (ref) v_u_621, (copy) v_u_2, (copy) v_u_3, (copy) v_u_29
	local v412 = {}
	if v_u_621 == nil then
		local v_u_413 = "BmRs"
		local function v414()
			-- upvalues: (ref) v_u_2, (copy) v_u_413
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_413, 5)))
		end
		local v415, v416 = pcall(v414)
		if not v415 then
			v416 = nil
		end
		v_u_621 = v416
	end
	local v417 = v_u_621
	if type(p411) ~= "table" or v417 == nil then
		return v412
	end
	local v418 = p411.rows
	local v419 = type(v418) ~= "table" and {} or p411.rows
	if #v419 == 0 then
		table.insert(v412, "No report yet.")
	end
	local v420 = #v419
	local v421 = v_u_3.HIST_REPORTS
	for v422 = 1, math.min(v420, v421) do
		local v423 = v419[v422]
		if type(v423) ~= "table" then
			continue
		end
		local v424 = 0
		local v425 = 0
		local v426 = 0
		local v427 = 0
		for _, v428 in v423.items or {} do
			v424 = v424 + (v428.sold or 0)
			v425 = v425 + (v428.s or 0)
			v426 = v426 + (v428.rev or 0)
			v427 = v427 + (v428.lost or 0)
		end
		local v429 = "%s  \194\183  ended %s  \194\183  sold %s of %s  \194\183  revenue %s  \194\183  lost %s"
		local v430 = v423.n
		local v431 = tostring(v430)
		local v432 = v423.t1
		local v433
		if type(v432) == "number" and (v432 == v432 and v432 ~= (1 / 0)) then
			v433 = v432 ~= (-1 / 0)
		else
			v433 = false
		end
		local v434 = not v433 and "?" or v417.fmtStart(v423.t1)
		if v_u_621 == nil then
			local v_u_435 = "BmRs"
			local function v436()
				-- upvalues: (ref) v_u_2, (copy) v_u_435
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_435, 5)))
			end
			local v437, v438 = pcall(v436)
			if not v437 then
				v438 = nil
			end
			v_u_621 = v438
		end
		local v439 = v_u_621
		local v440
		if v439 and v439.commas then
			v440 = v439.commas(v424)
		else
			v440 = tostring(v424)
		end
		if v_u_621 == nil then
			local v_u_441 = "BmRs"
			local function v442()
				-- upvalues: (ref) v_u_2, (copy) v_u_441
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_441, 5)))
			end
			local v443, v444 = pcall(v442)
			if not v443 then
				v444 = nil
			end
			v_u_621 = v444
		end
		local v445 = v_u_621
		local v446
		if v445 and v445.commas then
			v446 = v445.commas(v425)
		else
			v446 = tostring(v425)
		end
		if v_u_621 == nil then
			local v_u_447 = "BmRs"
			local function v448()
				-- upvalues: (ref) v_u_2, (copy) v_u_447
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_447, 5)))
			end
			local v449, v450 = pcall(v448)
			if not v449 then
				v450 = nil
			end
			v_u_621 = v450
		end
		local v451 = v_u_621
		local v452
		if v451 and v451.money then
			v452 = v451.money(v426)
		else
			v452 = "$" .. tostring(v426)
		end
		if v_u_621 == nil then
			local v_u_453 = "BmRs"
			local function v454()
				-- upvalues: (ref) v_u_2, (copy) v_u_453
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_453, 5)))
			end
			local v455, v456 = pcall(v454)
			if not v455 then
				v456 = nil
			end
			v_u_621 = v456
		end
		local v457 = v_u_621
		local v458
		if v457 and v457.commas then
			v458 = v457.commas(v427)
		else
			v458 = tostring(v427)
		end
		table.insert(v412, v429:format(v431, v434, v440, v446, v452, v458))
		for _, v459 in v423.items or {} do
			local v460 = v459.rf
			local v461
			if type(v460) == "number" and (v460 == v460 and v460 ~= (1 / 0)) then
				v461 = v460 ~= (-1 / 0)
			else
				v461 = false
			end
			local v462
			if v461 and v459.rf > 0 then
				local v463 = ", reference %s"
				local v464 = v459.rf
				if v_u_621 == nil then
					local v_u_465 = "BmRs"
					local function v466()
						-- upvalues: (ref) v_u_2, (copy) v_u_465
						return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_465, 5)))
					end
					local v467, v468 = pcall(v466)
					if not v467 then
						v468 = nil
					end
					v_u_621 = v468
				end
				local v469 = v_u_621
				local v470
				if v469 and v469.money then
					v470 = v469.money(v464)
				else
					v470 = "$" .. tostring(v464)
				end
				v462 = v463:format(v470)
			else
				v462 = ""
			end
			local v471 = "    %s: sold %s of %s at %s, revenue %s, unsold %s, lost %s%s"
			local v472 = v_u_29(v459.id)
			local v473 = v459.sold or 0
			if v_u_621 == nil then
				local v_u_474 = "BmRs"
				local function v475()
					-- upvalues: (ref) v_u_2, (copy) v_u_474
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_474, 5)))
				end
				local v476, v477 = pcall(v475)
				if not v476 then
					v477 = nil
				end
				v_u_621 = v477
			end
			local v478 = v_u_621
			local v479
			if v478 and v478.commas then
				v479 = v478.commas(v473)
			else
				v479 = tostring(v473)
			end
			local v480 = v459.s or 0
			if v_u_621 == nil then
				local v_u_481 = "BmRs"
				local function v482()
					-- upvalues: (ref) v_u_2, (copy) v_u_481
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_481, 5)))
				end
				local v483, v484 = pcall(v482)
				if not v483 then
					v484 = nil
				end
				v_u_621 = v484
			end
			local v485 = v_u_621
			local v486
			if v485 and v485.commas then
				v486 = v485.commas(v480)
			else
				v486 = tostring(v480)
			end
			local v487 = v459.u or 0
			if v_u_621 == nil then
				local v_u_488 = "BmRs"
				local function v489()
					-- upvalues: (ref) v_u_2, (copy) v_u_488
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_488, 5)))
				end
				local v490, v491 = pcall(v489)
				if not v490 then
					v491 = nil
				end
				v_u_621 = v491
			end
			local v492 = v_u_621
			local v493
			if v492 and v492.money then
				v493 = v492.money(v487)
			else
				v493 = "$" .. tostring(v487)
			end
			local v494 = v459.rev or 0
			if v_u_621 == nil then
				local v_u_495 = "BmRs"
				local function v496()
					-- upvalues: (ref) v_u_2, (copy) v_u_495
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_495, 5)))
				end
				local v497, v498 = pcall(v496)
				if not v497 then
					v498 = nil
				end
				v_u_621 = v498
			end
			local v499 = v_u_621
			local v500
			if v499 and v499.money then
				v500 = v499.money(v494)
			else
				v500 = "$" .. tostring(v494)
			end
			local v501 = v459.unsold or 0
			if v_u_621 == nil then
				local v_u_502 = "BmRs"
				local function v503()
					-- upvalues: (ref) v_u_2, (copy) v_u_502
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_502, 5)))
				end
				local v504, v505 = pcall(v503)
				if not v504 then
					v505 = nil
				end
				v_u_621 = v505
			end
			local v506 = v_u_621
			local v507
			if v506 and v506.commas then
				v507 = v506.commas(v501)
			else
				v507 = tostring(v501)
			end
			local v508 = v459.lost or 0
			if v_u_621 == nil then
				local v_u_509 = "BmRs"
				local function v510()
					-- upvalues: (ref) v_u_2, (copy) v_u_509
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_509, 5)))
				end
				local v511, v512 = pcall(v510)
				if not v511 then
					v512 = nil
				end
				v_u_621 = v512
			end
			local v513 = v_u_621
			local v514
			if v513 and v513.commas then
				v514 = v513.commas(v508)
			else
				v514 = tostring(v508)
			end
			table.insert(v412, v471:format(v472, v479, v486, v493, v500, v507, v514, v462))
		end
	end
	local v515 = p411.log
	local v516 = type(v515) ~= "table" and {} or p411.log
	if #v516 > 0 then
		table.insert(v412, "Owner actions, newest first:")
	end
	local v517 = #v516
	local v518 = v_u_3.HIST_LOG
	for v519 = 1, math.min(v517, v518) do
		local v520 = v516[v519]
		if type(v520) ~= "table" then
			continue
		end
		local v521 = "    %s  \194\183  %s  \194\183  version %s"
		local v522 = v520.at
		local v523
		if type(v522) == "number" and (v522 == v522 and v522 ~= (1 / 0)) then
			v523 = v522 ~= (-1 / 0)
		else
			v523 = false
		end
		local v524 = not v523 and "?" or v417.fmtStart(v520.at)
		local v525 = v520.op
		local v526 = tostring(v525)
		local v527 = v520.ver or 0
		local v528 = tostring(v527)
		table.insert(v412, v521:format(v524, v526, v528))
	end
	return v412
end
function v_u_3.addRowDraft(p_u_529) -- name: addRowDraft
	-- upvalues: (ref) v_u_624, (copy) v_u_19
	local v_u_530 = {}
	local v531 = {}
	if type(p_u_529) == "table" then
		local v532 = string.lower
		local v533 = p_u_529.id
		local v534
		if type(v533) == "string" then
			local v535 = string.gsub(v533, "^%s+", "")
			v534 = string.gsub(v535, "%s+$", "")
		else
			v534 = ""
		end
		local v536 = v532(v534)
		if v536 == "" or (not string.match(v536, "^[a-z0-9_]+$") or #v536 > 40) then
			table.insert(v_u_530, "Pick an item.")
		end
		local v_u_537 = {
			["id"] = v536
		}
		local function v554(p538, p539, p540, p541) -- name: field
			-- upvalues: (copy) p_u_529, (copy) v_u_530, (ref) v_u_624, (ref) v_u_19, (copy) v_u_537
			local v542 = p_u_529[p538]
			local v543
			if type(v542) == "string" then
				local v544 = string.gsub(v542, "^%s+", "")
				v543 = string.gsub(v544, "%s+$", "")
			else
				v543 = ""
			end
			if v543 == "" then
				if not p540 then
					local v545 = v_u_530
					local v546 = p539 .. " is needed."
					table.insert(v545, v546)
				end
				return
			else
				if v_u_624 == nil then
					v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
				end
				local v547 = v_u_624.parseNumber(v543)
				if v547 == nil and v_u_19(v543) then
					local v548 = v_u_530
					local v549 = p539 .. " must be a whole number."
					table.insert(v548, v549)
					return
				elseif v547 == nil or v547 < p541 then
					local v550 = v_u_530
					local v551 = p539 .. " is not a valid number."
					table.insert(v550, v551)
					return
				elseif v547 == math.floor(v547) then
					v_u_537[p538] = v547
				else
					local v552 = v_u_530
					local v553 = p539 .. " must be a whole number."
					table.insert(v552, v553)
				end
			end
		end
		v554("u", "PRICE EACH", false, 1)
		v554("s", "TOTAL AMOUNT", false, 1)
		local v555 = p_u_529.q1
		local v556
		if type(v555) == "string" then
			local v557 = string.gsub(v555, "^%s+", "")
			v556 = string.gsub(v557, "%s+$", "")
		else
			v556 = ""
		end
		if v556 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v558 = v_u_624.parseNumber(v556)
			if v558 == nil and v_u_19(v556) then
				table.insert(v_u_530, "MIN PER BUY must be a whole number.")
			elseif v558 == nil or v558 < 1 then
				table.insert(v_u_530, "MIN PER BUY is not a valid number.")
			elseif v558 == math.floor(v558) then
				v_u_537.q1 = v558
			else
				table.insert(v_u_530, "MIN PER BUY must be a whole number.")
			end
		end
		local v559 = p_u_529.q2
		local v560
		if type(v559) == "string" then
			local v561 = string.gsub(v559, "^%s+", "")
			v560 = string.gsub(v561, "%s+$", "")
		else
			v560 = ""
		end
		if v560 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v562 = v_u_624.parseNumber(v560)
			if v562 == nil and v_u_19(v560) then
				table.insert(v_u_530, "MAX PER BUY must be a whole number.")
			elseif v562 == nil or v562 < 1 then
				table.insert(v_u_530, "MAX PER BUY is not a valid number.")
			elseif v562 == math.floor(v562) then
				v_u_537.q2 = v562
			else
				table.insert(v_u_530, "MAX PER BUY must be a whole number.")
			end
		end
		local v563 = p_u_529.c
		local v564
		if type(v563) == "string" then
			local v565 = string.gsub(v563, "^%s+", "")
			v564 = string.gsub(v565, "%s+$", "")
		else
			v564 = ""
		end
		if v564 ~= "" then
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v566 = v_u_624.parseNumber(v564)
			if v566 == nil and v_u_19(v564) then
				table.insert(v_u_530, "LIMIT PER PLAYER must be a whole number.")
			elseif v566 == nil or v566 < 0 then
				table.insert(v_u_530, "LIMIT PER PLAYER is not a valid number.")
			elseif v566 == math.floor(v566) then
				v_u_537.c = v566
			else
				table.insert(v_u_530, "LIMIT PER PLAYER must be a whole number.")
			end
		end
		local v567 = p_u_529.w
		local v568
		if type(v567) == "number" and (v567 == v567 and v567 ~= (1 / 0)) then
			v568 = v567 ~= (-1 / 0)
		else
			v568 = false
		end
		if v568 then
			v_u_537.w = p_u_529.w
		end
		local v569 = p_u_529.typed
		if type(v569) == "table" then
			for _, v570 in { "PRICE", "AMOUNT", "RARE" } do
				if p_u_529.typed[v570] ~= true then
					continue
				end
				v531[v570] = true
			end
		end
		if #v_u_530 > 0 then
			return nil, v_u_530, v531
		else
			return v_u_537, v_u_530, v531
		end
	else
		return nil, { "Pick an item." }, v531
	end
end
function v_u_3.replaceDefaults(p571, p572, p573, p574) -- name: replaceDefaults
	-- upvalues: (ref) v_u_624, (ref) v_u_621, (copy) v_u_2
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v609, v610, v611, v612, v_u_613, v614, v615, v616, v617, v618, v619, v620, v622, v623, v625, v626, v627, v628, v629, v630, v631, v632, v633, v634, v635, v636, v637, v638, v639, v640, v641, v642, v643, v644
	local v609, v610, v611, v612, v_u_613, v614, v615, v616, v617, v618, v619, v620, v_u_621, v622, v623, v_u_624, v625, v626, v627, v628, v629, v630, v631, v632, v633, v634, v635, v636, v637, v638, v639, v640, v641, v642, v643, v644
	local v645 = 10
	while true do
		if v645 == 1 then
			if type(p573) == "table" then
				v631 = p573.known
				if type(v631) == "number" and (v631 == v631 and v631 ~= (1 / 0)) then
					v632 = v631 ~= (-1 / 0)
				else
					v632 = false
				end
				if v632 and p573.known > 0 then
					v637 = p573.rem
					if type(v637) == "number" and (v637 == v637 and v637 ~= (1 / 0)) then
						v638 = v637 ~= (-1 / 0)
					else
						v638 = false
					end
					if v638 then
						v639 = p573.rem
					end
				end
			end
			if v639 == nil then
				v639 = v611.s
			end
			v640 = v611.q2 or 1
			v641 = math.max(v639, v640)
			v642 = math.floor(v641)
			v612.s = tostring(v642)
			v625 = 0
			if type(v620) == "table" then
				v645 = 6
			else
				v645 = 2
			end
		elseif v645 == 2 then
			if type(p573) == "table" then
				v626 = p573.out
				if type(v626) == "number" and (v626 == v626 and v626 ~= (1 / 0)) then
					v627 = v626 ~= (-1 / 0)
				else
					v627 = false
				end
				if v627 then
					v625 = p573.out
				end
			end
			v645 = 8
		elseif v645 == 3 then
			v628 = v620.rem
			if type(v628) == "number" and (v628 == v628 and v628 ~= (1 / 0)) then
				v629 = v628 ~= (-1 / 0)
			else
				v629 = false
			end
			if v629 then
				v645 = 5
			else
				v645 = 1
			end
		elseif v645 == 4 then
			if type(p573) == "table" then
				v631 = p573.known
				if type(v631) == "number" and (v631 == v631 and v631 ~= (1 / 0)) then
					v632 = v631 ~= (-1 / 0)
				else
					v632 = false
				end
				if v632 and p573.known > 0 then
					v637 = p573.rem
					if type(v637) == "number" and (v637 == v637 and v637 ~= (1 / 0)) then
						v638 = v637 ~= (-1 / 0)
					else
						v638 = false
					end
					if v638 then
						v639 = p573.rem
					end
				end
			end
			if v639 == nil then
				v639 = v611.s
			end
			v640 = v611.q2 or 1
			v641 = math.max(v639, v640)
			v642 = math.floor(v641)
			v612.s = tostring(v642)
			v625 = 0
			if type(v620) == "table" then
				v645 = 6
			else
				v645 = 9
			end
		elseif v645 == 5 then
			v639 = v620.rem
			if v639 == nil then
				v639 = v611.s
			end
			v640 = v611.q2 or 1
			v641 = math.max(v639, v640)
			v642 = math.floor(v641)
			v612.s = tostring(v642)
			v625 = 0
			if type(v620) == "table" then
				v645 = 6
			else
				v645 = 7
			end
		elseif v645 == 6 then
			v630 = v620.out
			if type(v630) == "number" and (v630 == v630 and v630 ~= (1 / 0)) then
				v643 = v630 ~= (-1 / 0)
			else
				v643 = false
			end
			if v643 then
				v625 = v620.out
			elseif type(p573) == "table" then
				v626 = p573.out
				if type(v626) == "number" and (v626 == v626 and v626 ~= (1 / 0)) then
					v627 = v626 ~= (-1 / 0)
				else
					v627 = false
				end
				if v627 then
					v625 = p573.out
				end
			end
			v645 = 8
		elseif v645 == 7 then
			if type(p573) == "table" then
				v626 = p573.out
				if type(v626) == "number" and (v626 == v626 and v626 ~= (1 / 0)) then
					v627 = v626 ~= (-1 / 0)
				else
					v627 = false
				end
				if v627 then
					v625 = p573.out
				end
			end
			v645 = 8
		elseif v645 == 8 then
			if v625 <= 0 then
				return v612, ""
			end
			v644 = "The %s units out on servers are written off."
			if v_u_621 == nil then
				v_u_613 = "BmRs"
				v614 = function()
					-- upvalues: (ref) v_u_2, (copy) v_u_613
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_613, 5)))
				end
				v615, v616 = pcall(v614)
				if not v615 then
					v616 = nil
				end
				v_u_621 = v616
			end
			v622 = v_u_621
			if v622 and v622.commas then
				v623 = v622.commas(v625)
			else
				v623 = tostring(v625)
			end
			return v612, v644:format(v623)
		elseif v645 == 9 then
			if type(p573) == "table" then
				v626 = p573.out
				if type(v626) == "number" and (v626 == v626 and v626 ~= (1 / 0)) then
					v627 = v626 ~= (-1 / 0)
				else
					v627 = false
				end
				if v627 then
					v625 = p573.out
				end
			end
			v645 = 8
		else
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			v609 = v_u_624
			if type(p571) == "table" then
				v610 = p571.ix
				if type(v610) == "table" then
					v611 = p571.ix[p572]
				else
					v611 = nil
				end
			else
				v611 = nil
			end
			v612 = v609.newRow()
			if type(v611) ~= "table" or v611.bad == true then
				return v612, ""
			end
			v612.id = v611.id
			v633 = v611.u
			v612.u = tostring(v633)
			v634 = v611.q1
			v635 = tostring(v634)
			v636 = v611.q2
			v617 = tostring(v636)
			v612.q1 = v635
			v612.q2 = v617
			v618 = v611.c
			v612.c = tostring(v618)
			v612.w = v611.w
			v639 = nil
			if type(p574) == "table" and p574.rid == p571.r then
				v619 = p574.rows
				if type(v619) == "table" then
					v620 = v619[p572]
					if v620 == nil then
						v620 = v619[tostring(p572)]
					end
				else
					v620 = nil
				end
			else
				v620 = nil
			end
			if type(v620) == "table" then
				v645 = 3
			else
				v645 = 4
			end
		end
	end
end
function v_u_3.build(p_u_646) -- name: build
	-- upvalues: (ref) v_u_624, (copy) v_u_4, (copy) v_u_3, (copy) v_u_19, (copy) v_u_2
	if v_u_624 == nil then
		v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
	end
	local v_u_647 = v_u_624
	local v_u_648 = v_u_647.kit({
		["body"] = p_u_646.body
	})
	local v_u_649 = v_u_648.HushUI
	local v_u_650 = v_u_648.Theme
	local v_u_651 = v_u_648.C
	local v_u_652 = p_u_646.call
	local v653 = p_u_646.inner
	local v_u_654 = true
	p_u_646.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_654
		v_u_654 = false
	end)
	local v_u_655 = {}
	local v_u_656 = nil
	local v_u_657 = false
	local function v_u_662() -- name: serverNow
		-- upvalues: (copy) p_u_646
		if p_u_646.now then
			local v658 = p_u_646.now
			local v659, v660 = pcall(v658)
			if v659 then
				local v661
				if type(v660) == "number" and (v660 == v660 and v660 ~= (1 / 0)) then
					v661 = v660 ~= (-1 / 0)
				else
					v661 = false
				end
				if v661 then
					return v660
				end
			end
		end
		return os.time()
	end
	local v_u_663 = v_u_649.new("Frame", {
		["Name"] = "RsLiveFrame",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_646.body)
	v_u_649.layout(v_u_663, "v", 8)
	local v_u_664 = v_u_649.new("Frame", {
		["Name"] = "RsHistFrame",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_646.body)
	v_u_649.layout(v_u_664, "v", 8)
	local v665 = v_u_647.kit({
		["body"] = v_u_663
	})
	local v666 = v_u_647.kit({
		["body"] = v_u_664
	})
	local v_u_667 = {}
	local v_u_668 = {}
	local v_u_669 = {}
	local v_u_670 = setmetatable({}, {
		["__mode"] = "k"
	})
	local function v_u_682(p671, p672, p673, p674, p_u_675) -- name: mkBox
		-- upvalues: (copy) v_u_649, (copy) v_u_650, (ref) v_u_657, (copy) v_u_670, (copy) v_u_667
		local v676, v_u_677 = v_u_649.input({
			["parent"] = p671,
			["name"] = p672,
			["size"] = UDim2.fromOffset(p674, v_u_650.touch(34)),
			["placeholder"] = p673
		})
		local v678 = {
			["box"] = nil,
			["frame"] = nil,
			["base"] = "",
			["box"] = v_u_677,
			["frame"] = v676
		}
		v_u_677:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_677, (ref) v_u_657, (ref) v_u_670, (copy) p_u_675
			local v679 = v_u_677
			local v680
			if v_u_657 or v_u_670[v679] == v679.Text then
				v680 = false
			else
				v_u_670[v679] = v679.Text
				v680 = true
			end
			if v680 then
				if p_u_675 then
					p_u_675()
				end
			end
		end)
		local v681 = v_u_667
		table.insert(v681, v678)
		return v678
	end
	local v_u_683 = nil
	local v_u_684 = nil
	local function v_u_685() end
	local v_u_686 = {}
	local function v_u_695(p687) -- name: sigOf
		-- upvalues: (copy) v_u_695
		if type(p687) ~= "table" then
			return type(p687) .. ":" .. tostring(p687)
		end
		local v688 = {}
		for v689 in p687 do
			table.insert(v688, v689)
		end
		table.sort(v688, function(p690, p691)
			return tostring(p690) < tostring(p691)
		end)
		local v692 = {}
		for _, v693 in v688 do
			local v694 = tostring(v693) .. "=" .. v_u_695(p687[v693])
			table.insert(v692, v694)
		end
		return "{" .. table.concat(v692, ",") .. "}"
	end
	local function v_u_708(p696, p697, p698) -- name: twoPress
		-- upvalues: (ref) v_u_656, (copy) v_u_695, (copy) v_u_669, (ref) v_u_3, (copy) v_u_686, (ref) v_u_684, (ref) v_u_683, (ref) v_u_4, (ref) v_u_685, (ref) v_u_654
		local v699 = os.clock()
		local v700
		if p698 then
			local v701 = v_u_656
			local v702
			if type(v701) == "table" then
				local v703 = v_u_656.plan
				if type(v703) == "table" then
					v702 = v_u_656.plan.r
				else
					v702 = nil
				end
			else
				v702 = nil
			end
			v700 = tostring(v702) .. "|" .. v_u_695(p698())
		else
			v700 = nil
		end
		local v704 = v_u_669[p696]
		local v705
		if v704 == nil then
			v705 = false
		else
			v705 = os.clock() - v704 < v_u_3.CONFIRM_SECONDS
		end
		if v705 and v699 - v_u_669[p696] >= v_u_3.CONFIRM_GUARD then
			if v700 == nil or v700 == v_u_686[p696] then
				v_u_669[p696] = nil
				v_u_686[p696] = nil
				p697()
				v_u_685()
			else
				v_u_669[p696] = v699
				v_u_686[p696] = v700
				v_u_684.Text = "The change is not the one you confirmed. Check it and press again."
				v_u_684.Visible = true
				v_u_683.Visible = false
				v_u_683.Text = ""
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "The change is not the one you confirmed. Check it and press again.")
				end
				v_u_685()
			end
		else
			local v706 = v_u_669[p696]
			local v707
			if v706 == nil then
				v707 = false
			else
				v707 = os.clock() - v706 < v_u_3.CONFIRM_SECONDS
			end
			if not v707 then
				v_u_669[p696] = v699
				v_u_686[p696] = v700
				task.delay(v_u_3.CONFIRM_SECONDS + 0.2, function()
					-- upvalues: (ref) v_u_654, (ref) v_u_685
					if v_u_654 then
						v_u_685()
					end
				end)
			end
			v_u_685()
			return
		end
	end
	local function v_u_720(p709, p_u_710, p711, p712, p713, p_u_714, p_u_715) -- name: pressBtn
		-- upvalues: (copy) v_u_668, (copy) v_u_708, (copy) v_u_648
		local function v717() -- name: handler
			-- upvalues: (ref) v_u_668, (copy) p_u_710, (ref) v_u_708, (copy) p_u_714, (copy) p_u_715
			local v716 = v_u_668[p_u_710]
			if not v716 or v716.enabled ~= false then
				v_u_708(p_u_710, p_u_714, p_u_715)
			end
		end
		local v718, v719 = v_u_648.btn(p709, p711, p712, p713, v717)
		v718.Name = "RsL_" .. p_u_710
		v_u_668[p_u_710] = {
			["api"] = nil,
			["text"] = nil,
			["enabled"] = true,
			["button"] = nil,
			["click"] = nil,
			["api"] = v719,
			["text"] = p711,
			["button"] = v718,
			["click"] = v717
		}
		return v718
	end
	local function v731(p721, p_u_722, p723, p724, p725, p_u_726) -- name: plainBtn
		-- upvalues: (copy) v_u_668, (copy) v_u_648
		local function v728() -- name: handler
			-- upvalues: (ref) v_u_668, (copy) p_u_722, (copy) p_u_726
			local v727 = v_u_668[p_u_722]
			if not v727 or v727.enabled ~= false then
				p_u_726()
			end
		end
		local v729, v730 = v_u_648.btn(p721, p723, p724, p725, v728)
		v729.Name = "RsL_" .. p_u_722
		v_u_668[p_u_722] = {
			["api"] = nil,
			["text"] = nil,
			["enabled"] = true,
			["button"] = nil,
			["plain"] = true,
			["click"] = nil,
			["api"] = v730,
			["text"] = p723,
			["button"] = v729,
			["click"] = v728
		}
		return v729, v730
	end
	local function v_u_738() -- name: paintPress
		-- upvalues: (copy) v_u_668, (copy) v_u_669, (ref) v_u_3
		for v732, v733 in v_u_668 do
			if v733.plain then
				v733.api.setText(v733.text)
			else
				local v734 = v733.api.setText
				local v735 = v_u_669[v732]
				local v736
				if v735 == nil then
					v736 = false
				else
					v736 = os.clock() - v735 < v_u_3.CONFIRM_SECONDS
				end
				local v737
				if v736 then
					v737 = "AGAIN: " .. v733.text
				else
					v737 = v733.text
				end
				v734(v737)
			end
		end
	end
	local v_u_739 = {}
	local function v_u_740() end
	v665.section("Live restock  \194\183  change while it runs")
	v665.note("Change the fields below and press SAVE CHANGE twice. The servers read it within 3 seconds, at the latest after 30 seconds. " .. v_u_3.FIXED_TEXT, v_u_651.text2, "RsLiveHint")
	v_u_683 = v665.note("", v_u_651.success, "RsLiveOk")
	v_u_683.Visible = false
	v_u_684 = v665.note("", v_u_651.danger, "RsLiveError")
	v_u_684.Visible = false
	local v_u_741 = {}
	local v_u_742 = {
		["rv"] = nil,
		["al"] = nil,
		["rvBase"] = nil,
		["alBase"] = nil
	}
	local v_u_743 = "Save change"
	local function v_u_744() end
	local function v_u_745() end
	local v_u_746 = v_u_649.new("Frame", {
		["Name"] = "RsLivePlan",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_651.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v665.nextOrder()
	}, v_u_663)
	v_u_649.stroke(v_u_746, v_u_651.line)
	v_u_649.pad(v_u_746, {
		10,
		10,
		8,
		10
	})
	v_u_649.layout(v_u_746, "v", 6)
	local v_u_747 = v653 - 20
	local v_u_748 = 0
	local function v_u_752(p749, p750) -- name: ccap
		-- upvalues: (ref) v_u_748, (copy) v_u_649, (copy) v_u_651
		v_u_748 = v_u_748 + 1
		local v751 = v_u_649.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = p749,
			["text"] = p750,
			["color"] = v_u_651.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v751.LayoutOrder = v_u_748
		return v751
	end
	local function v_u_756(p753, p754) -- name: crow
		-- upvalues: (ref) v_u_748, (copy) v_u_649, (copy) v_u_650
		v_u_748 = v_u_748 + 1
		local v755 = v_u_649.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = p754,
			["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
			["LayoutOrder"] = v_u_748
		}, p753)
		v_u_649.layout(v755, "h", 6)
		return v755
	end
	local function v762(p757, p758, p759, p760) -- name: cnote
		-- upvalues: (ref) v_u_748, (copy) v_u_649, (copy) v_u_651
		v_u_748 = v_u_748 + 1
		local v761 = v_u_649.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = p757,
			["name"] = p760,
			["text"] = p758,
			["color"] = p759 or v_u_651.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v761.RichText = false
		v761.LayoutOrder = v_u_748
		return v761
	end
	v_u_752(v_u_746, "NAME  (up to 24 characters)")
	v_u_741.n = v_u_682(v_u_756(v_u_746, "RsLiveNameRow"), "RsL_n", "Name", v_u_747, function()
		-- upvalues: (ref) v_u_745
		v_u_745()
	end)
	v_u_752(v_u_746, "MIN RAIDS  \194\183  MIN ACCOUNT AGE  \194\183  MIN PLAYED DAYS  \194\183  MIN EXTRACTIONS")
	local v763 = v_u_756(v_u_746, "RsLiveGates")
	local v764 = (v_u_747 - 18) / 4
	local v765 = math.floor(v764)
	local v_u_766 = v_u_654
	local v_u_767 = v_u_683
	local v_u_768 = v_u_684
	local v_u_769 = v_u_685
	local v_u_770 = v_u_656
	local v_u_771 = v_u_657
	local v_u_772 = v_u_748
	local v_u_773 = v_u_745
	for _, v774 in {
		"mr",
		"ma",
		"mc",
		"mx"
	} do
		v_u_741[v774] = v_u_682(v763, "RsL_" .. v774, v774, v765, function()
			-- upvalues: (ref) v_u_773
			v_u_773()
		end)
	end
	v_u_752(v_u_746, "EXPECTED PLAYERS  \194\183  DRAW WINDOW (s)  \194\183  RESALE LOCK (h)")
	local v775 = v_u_756(v_u_746, "RsLivePeople")
	local v776 = (v_u_747 - 12) / 3
	local v777 = math.floor(v776)
	for _, v778 in { "pe", "wd", "lk" } do
		v_u_741[v778] = v_u_682(v775, "RsL_" .. v778, v778, v777, function()
			-- upvalues: (ref) v_u_773
			v_u_773()
		end)
	end
	local v_u_779 = v762(v_u_746, "", v_u_651.text2, "RsLivePeNote")
	v_u_779.Visible = false
	local v_u_780 = {
		["rv"] = {},
		["al"] = {}
	}
	local function v797(p_u_781, p782, p783, p_u_784, p_u_785) -- name: choiceRow
		-- upvalues: (copy) v_u_752, (copy) v_u_746, (copy) v_u_756, (copy) v_u_747, (copy) v_u_648, (copy) v_u_780, (ref) v_u_773
		v_u_752(v_u_746, p782)
		local v786 = v_u_756(v_u_746, "RsLive_" .. p_u_781)
		local v787 = #p783
		local v788 = (v_u_747 - (v787 - 1) * 6) / v787
		local v789 = math.floor(v788)
		for v790, v_u_791 in p783 do
			local v794, v795 = v_u_648.btn(v786, v_u_791[2], "secondary", v789, function()
				-- upvalues: (copy) p_u_785, (copy) v_u_791, (ref) v_u_780, (copy) p_u_781, (copy) p_u_784, (ref) v_u_773
				p_u_785(v_u_791[1])
				for v792, v793 in v_u_780[p_u_781] do
					v793.setKind(v792 == p_u_784() and "primary" or "secondary")
				end
				v_u_773()
			end)
			v794.LayoutOrder = v790
			local v796 = v_u_791[1]
			v794.Name = "RsL_" .. p_u_781 .. "_" .. tostring(v796)
			v_u_780[p_u_781][v_u_791[1]] = v795
		end
	end
	v797("rv", "SHOW TO PLAYERS", v_u_647.SHOWS, function()
		-- upvalues: (copy) v_u_742
		return v_u_742.rv
	end, function(p798)
		-- upvalues: (copy) v_u_742
		v_u_742.rv = p798
	end)
	v797("al", "SHOW TIMER FROM", v_u_647.TIMERS, function()
		-- upvalues: (copy) v_u_742
		return v_u_742.al
	end, function(p799)
		-- upvalues: (copy) v_u_742
		v_u_742.al = p799
	end)
	local function v_u_803() -- name: paintChoices
		-- upvalues: (copy) v_u_780, (copy) v_u_742
		for _, v800 in { "rv", "al" } do
			for v801, v802 in v_u_780[v800] do
				v802.setKind(v801 == v_u_742[v800] and "primary" or "secondary")
			end
		end
	end
	local v_u_804 = {}
	local v_u_805 = {}
	local function v817(p806, p_u_807, p808) -- name: mkWordBox
		-- upvalues: (ref) v_u_772, (copy) v_u_649, (copy) v_u_650, (copy) v_u_747, (ref) v_u_771, (copy) v_u_670, (copy) v_u_805, (ref) v_u_744, (copy) v_u_804
		v_u_772 = v_u_772 + 1
		local v809 = v_u_649.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Name"] = "RsLWord_" .. p_u_807,
			["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
			["LayoutOrder"] = v_u_772
		}, p806)
		v_u_649.layout(v809, "h", 6)
		local _, v_u_810 = v_u_649.input({
			["parent"] = v809,
			["name"] = "RsL_Word_" .. p_u_807,
			["size"] = UDim2.fromOffset(v_u_747, v_u_650.touch(34)),
			["placeholder"] = p808
		})
		v_u_810:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_810, (ref) v_u_771, (ref) v_u_670, (copy) p_u_807, (ref) v_u_805, (ref) v_u_744
			local v811 = v_u_810
			local v812
			if v_u_771 or v_u_670[v811] == v811.Text then
				v812 = false
			else
				v_u_670[v811] = v811.Text
				v812 = true
			end
			if v812 then
				local v813 = string.upper
				local v814 = v_u_810.Text
				local v815
				if type(v814) == "string" then
					local v816 = string.gsub(v814, "^%s+", "")
					v815 = string.gsub(v816, "%s+$", "")
				else
					v815 = ""
				end
				v_u_805[p_u_807] = v813(v815) == p_u_807 and true or nil
				v_u_744()
			end
		end)
		v_u_804[p_u_807] = {
			["frame"] = v809,
			["box"] = v_u_810
		}
	end
	v817(v_u_746, "PRICE", "Type PRICE to allow this price")
	v817(v_u_746, "AMOUNT", "Type AMOUNT to allow no limit")
	v817(v_u_746, "LONG", "Type LONG to allow a restock longer than 24 hours")
	v_u_740 = function()
		-- upvalues: (copy) v_u_804, (copy) v_u_739, (copy) v_u_805
		for v818, v819 in v_u_804 do
			v819.frame.Visible = v_u_739[v818] == true and true or v_u_805[v818] == true
		end
	end
	local function v_u_822() -- name: clearWords
		-- upvalues: (copy) v_u_804, (ref) v_u_771, (copy) v_u_670, (copy) v_u_805, (copy) v_u_739, (ref) v_u_740
		for _, v820 in v_u_804 do
			local v821 = v820.box
			v_u_771 = true
			v821.Text = ""
			v_u_670[v821] = ""
			v_u_771 = false
		end
		table.clear(v_u_805)
		table.clear(v_u_739)
		v_u_740()
	end
	v_u_745 = function()
		-- upvalues: (copy) v_u_822, (ref) v_u_744
		v_u_822()
		v_u_744()
	end
	v_u_752(v_u_746, "START  \194\183  DURATION  (fixed)")
	local v823 = v_u_756(v_u_746, "RsLiveFixed")
	local v824 = (v_u_747 - 6) / 2
	local v_u_825 = v_u_682(v823, "RsL_fixStart", "start", math.floor(v824), nil)
	local v826 = (v_u_747 - 6) / 2
	local v_u_827 = v_u_682(v823, "RsL_fixDur", "duration", math.floor(v826), nil)
	local v828 = v_u_825.frame
	local v829 = v_u_825.box
	v829.TextEditable = false
	v829.TextColor3 = v_u_651.muted
	v828.BackgroundTransparency = 0.55
	local v830 = v_u_827.frame
	local v831 = v_u_827.box
	v831.TextEditable = false
	v831.TextColor3 = v_u_651.muted
	v830.BackgroundTransparency = 0.55
	v762(v_u_746, v_u_3.FIXED_TEXT, v_u_651.muted, "RsLiveFixedText")
	local v_u_832 = v762(v_u_746, "", v_u_651.text, "RsLiveEnd")
	v_u_752(v_u_746, "END LATER  (second press)")
	local v833 = v_u_756(v_u_746, "RsLiveExtend")
	local v834 = (v_u_747 - 18) / 4
	local v835 = math.floor(v834)
	local v_u_836 = v_u_745
	local v_u_837 = v_u_740
	for v838, v_u_839 in v_u_3.EXTENDS do
		v_u_720(v833, "ext" .. v_u_839[1], v_u_839[2], "secondary", v835, function()
			-- upvalues: (ref) v_u_770, (copy) v_u_805, (copy) v_u_839, (copy) v_u_822, (copy) v_u_739, (ref) v_u_768, (ref) v_u_4, (copy) v_u_652, (ref) v_u_767, (copy) p_u_646, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769
			local v840 = v_u_770
			local v841
			if type(v840) == "table" then
				v841 = v_u_770.plan
			else
				v841 = nil
			end
			local v842
			if type(v841) == "table" then
				v842 = v841.r
			else
				v842 = nil
			end
			if v842 ~= nil then
				local v843 = {
					["LONG"] = v_u_805.LONG == true and true or nil
				}
				local v844 = {
					["rid"] = v842,
					["hours"] = v_u_839[1] / 3600,
					["typed"] = v843
				}
				local function v_u_845()
					-- upvalues: (ref) v_u_822
					v_u_822()
				end
				local v_u_846 = v_u_739
				v_u_768.Text = ""
				v_u_768.Visible = false
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "")
				end
				local v_u_847 = "The restock ends later."
				v_u_652("extend", v844, function(p848)
					-- upvalues: (copy) v_u_847, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_845, (ref) v_u_4, (ref) v_u_3, (copy) v_u_846, (ref) v_u_837, (ref) v_u_769
					if type(p848) == "table" and p848.ok == true then
						local v849 = p848.msg or v_u_847
						local v850 = tostring(v849)
						v_u_767.Text = v850 or ""
						v_u_767.Visible = (v850 or "") ~= ""
						if v850 and v850 ~= "" then
							v_u_768.Visible = false
							v_u_768.Text = ""
							if p_u_646.handle then
								local v851 = p_u_646.handle.status
								if type(v851) == "function" then
									local v852 = p_u_646.handle.status
									pcall(v852, v850)
								end
							end
						end
						if v_u_845 then
							v_u_845(p848)
						end
					else
						local v853 = p848 and p848.msg or "The server did not answer."
						local v854 = tostring(v853)
						v_u_768.Text = v854 or ""
						v_u_768.Visible = (v854 or "") ~= ""
						if v854 and v854 ~= "" then
							v_u_767.Visible = false
							v_u_767.Text = ""
						end
						if v_u_4 then
							v_u_4:SetAttribute("FilmRestockLiveError", v854 or "")
						end
						local v855 = v_u_3.wordFromText(v854)
						if v855 ~= nil and v_u_846 ~= nil then
							v_u_846[v855] = true
							v_u_837()
						end
					end
					v_u_769()
				end, "write")
			end
		end).LayoutOrder = v838
	end
	local v_u_856 = v762(v_u_746, "", v_u_651.accent, "RsLiveChangeLine")
	local function v_u_864() -- name: collectFields
		-- upvalues: (copy) v_u_741, (copy) v_u_742, (copy) v_u_655
		local v857 = {
			["rows"] = {}
		}
		for _, v858 in {
			"n",
			"mr",
			"ma",
			"mc",
			"mx",
			"lk",
			"pe",
			"wd"
		} do
			local v859
			if v_u_741[v858] then
				v859 = v_u_741[v858].box.Text
			else
				v859 = nil
			end
			v857[v858] = v859
		end
		local v860 = v_u_742.rv
		local v861 = v_u_742.al
		v857.rv = v860
		v857.al = v861
		for v862, v863 in v_u_655._rowViews or {} do
			v857.rows[v862] = {
				["u"] = v863.boxes.u.box.Text,
				["c"] = v863.boxes.c.box.Text
			}
		end
		return v857
	end
	local function v_u_867() -- name: currentChange
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (copy) v_u_864, (copy) v_u_662
		local v865 = v_u_770
		local v866
		if type(v865) == "table" then
			v866 = v_u_770.plan
		else
			v866 = nil
		end
		if v866 == nil then
			return nil, {}, 0
		else
			return v_u_3.diffPlan(v866, v_u_864(), v_u_662())
		end
	end
	v_u_720(v_u_756(v_u_746, "RsLiveSaveRow"), "change", "Save change", "primary", 220, function()
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (copy) v_u_864, (copy) v_u_662, (ref) v_u_768, (ref) v_u_767, (ref) v_u_4, (copy) v_u_805, (copy) v_u_822, (copy) v_u_739, (copy) v_u_652, (copy) p_u_646, (ref) v_u_837, (ref) v_u_769
		local v868 = v_u_770
		local v869
		if type(v868) == "table" then
			v869 = v_u_770.plan
		else
			v869 = nil
		end
		local v870
		if type(v869) == "table" then
			v870 = v869.r
		else
			v870 = nil
		end
		local v871 = v_u_770
		local v872
		if type(v871) == "table" then
			v872 = v_u_770.plan
		else
			v872 = nil
		end
		local v873, v874
		if v872 == nil then
			v873 = {}
			v874 = nil
		else
			v874, v873 = v_u_3.diffPlan(v872, v_u_864(), v_u_662())
		end
		if v870 == nil or v874 == nil then
			local v875 = not v873[1] and "Nothing to change." or v873[1]
			v_u_768.Text = v875 or ""
			v_u_768.Visible = (v875 or "") ~= ""
			if v875 and v875 ~= "" then
				v_u_767.Visible = false
				v_u_767.Text = ""
			end
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", v875 or "")
			end
		else
			local v876 = {}
			for _, v877 in { "PRICE", "AMOUNT", "LONG" } do
				if v_u_805[v877] ~= true then
					continue
				end
				v876[v877] = true
			end
			local v878 = {
				["rid"] = v870,
				["patch"] = v874,
				["typed"] = v876
			}
			local function v_u_879()
				-- upvalues: (ref) v_u_822
				v_u_822()
			end
			local v_u_880 = v_u_739
			v_u_768.Text = ""
			v_u_768.Visible = false
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", "")
			end
			local v_u_881 = "Saved."
			v_u_652("patch", v878, function(p882)
				-- upvalues: (copy) v_u_881, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_879, (ref) v_u_4, (ref) v_u_3, (copy) v_u_880, (ref) v_u_837, (ref) v_u_769
				if type(p882) == "table" and p882.ok == true then
					local v883 = p882.msg or v_u_881
					local v884 = tostring(v883)
					v_u_767.Text = v884 or ""
					v_u_767.Visible = (v884 or "") ~= ""
					if v884 and v884 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v885 = p_u_646.handle.status
							if type(v885) == "function" then
								local v886 = p_u_646.handle.status
								pcall(v886, v884)
							end
						end
					end
					if v_u_879 then
						v_u_879(p882)
					end
				else
					local v887 = p882 and p882.msg or "The server did not answer."
					local v888 = tostring(v887)
					v_u_768.Text = v888 or ""
					v_u_768.Visible = (v888 or "") ~= ""
					if v888 and v888 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v888 or "")
					end
					local v889 = v_u_3.wordFromText(v888)
					if v889 ~= nil and v_u_880 ~= nil then
						v_u_880[v889] = true
						v_u_837()
					end
				end
				v_u_769()
			end, "write")
		end
	end, function()
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (copy) v_u_864, (copy) v_u_662, (copy) v_u_805
		local v890 = v_u_770
		local v891
		if type(v890) == "table" then
			v891 = v_u_770.plan
		else
			v891 = nil
		end
		local v892
		if v891 == nil then
			v892 = nil
		else
			v892 = v_u_3.diffPlan(v891, v_u_864(), v_u_662())
		end
		return {
			["patch"] = v892,
			["words"] = v_u_805
		}
	end)
	local function v903()
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (copy) v_u_864, (copy) v_u_662, (copy) v_u_856, (copy) v_u_651, (ref) v_u_743, (copy) v_u_668, (ref) v_u_4, (copy) v_u_738
		local v893 = v_u_770
		local v894
		if type(v893) == "table" then
			v894 = v_u_770.plan
		else
			v894 = nil
		end
		local v895, v896, v897
		if v894 == nil then
			v895 = nil
			v896 = {}
			v897 = 0
		else
			v895, v896, v897 = v_u_3.diffPlan(v894, v_u_864(), v_u_662())
		end
		if v895 == nil then
			if #v896 > 0 then
				v_u_856.Text = v896[1]
				v_u_856.TextColor3 = v_u_651.danger
			else
				v_u_856.Text = ""
			end
		else
			v_u_856.Text = ("%d %s changed. Nothing is sent before SAVE CHANGE."):format(v897, v897 == 1 and "field" or "fields")
			v_u_856.TextColor3 = v_u_651.accent
		end
		v_u_743 = v895 == nil and "Save change" or ("Save change (%d)"):format(v897)
		local v898 = v_u_743
		local v899 = v_u_668.change
		if v899 then
			v899.text = v898
		end
		local v900 = v895 ~= nil
		local v901 = v_u_668.change
		if v901 then
			v901.enabled = v900
			v901.api.setEnabled(v900)
		end
		if v_u_4 then
			local v902 = v_u_770
			v_u_4:SetAttribute("FilmRestockLive", ("%s|%d"):format(v_u_3.mode(v902), v897))
		end
		v_u_738()
	end
	local v_u_904 = v_u_649.new("Frame", {
		["Name"] = "RsLiveRows",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v665.nextOrder()
	}, v_u_663)
	v_u_649.layout(v_u_904, "v", 8)
	v_u_655._rowViews = {}
	local v_u_905 = v_u_647.newRow()
	local v_u_906 = nil
	local v_u_907 = ""
	local function v_u_908() end
	local function v_u_978(p_u_909) -- name: buildRowCard
		-- upvalues: (copy) v_u_649, (copy) v_u_651, (copy) v_u_904, (copy) v_u_650, (copy) v_u_747, (copy) v_u_682, (ref) v_u_836, (copy) v_u_668, (ref) v_u_624, (ref) v_u_19, (copy) v_u_720, (ref) v_u_770, (ref) v_u_768, (ref) v_u_767, (ref) v_u_4, (ref) v_u_771, (copy) v_u_670, (copy) v_u_652, (copy) p_u_646, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769, (copy) v_u_648, (copy) v_u_655
		local v_u_910 = v_u_649.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "RsLiveRow" .. p_u_909,
			["BackgroundColor3"] = v_u_651.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p_u_909
		}, v_u_904)
		v_u_649.stroke(v_u_910, v_u_651.line)
		v_u_649.pad(v_u_910, {
			10,
			10,
			8,
			10
		})
		v_u_649.layout(v_u_910, "v", 6)
		local v_u_911 = {
			["card"] = v_u_910,
			["boxes"] = {}
		}
		local v_u_912 = 0
		local function v915(p913) -- name: crow2
			-- upvalues: (ref) v_u_912, (ref) v_u_649, (ref) v_u_650, (copy) v_u_910
			v_u_912 = v_u_912 + 1
			local v914 = v_u_649.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = p913,
				["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
				["LayoutOrder"] = v_u_912
			}, v_u_910)
			v_u_649.layout(v914, "h", 6)
			return v914
		end
		local function v917(p916) -- name: cap2
			-- upvalues: (ref) v_u_912, (ref) v_u_649, (copy) v_u_910, (ref) v_u_651
			v_u_912 = v_u_912 + 1
			v_u_649.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_910,
				["text"] = p916,
				["color"] = v_u_651.muted,
				["size"] = UDim2.new(1, 0, 0, 14)
			}).LayoutOrder = v_u_912
		end
		v_u_912 = v_u_912 + 1
		v_u_911.title = v_u_649.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = "h3",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_910,
			["color"] = v_u_651.text,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_911.title.LayoutOrder = v_u_912
		v_u_911.title.RichText = false
		v_u_912 = v_u_912 + 1
		v_u_911.stats = v_u_649.label({
			["parent"] = nil,
			["name"] = "Stats",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_910,
			["color"] = v_u_651.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_911.stats.LayoutOrder = v_u_912
		v_u_911.stats.RichText = false
		v917("PRICE EACH  \194\183  LIMIT PER PLAYER  (you can change these)")
		local v918 = v915("Live")
		local v919 = (v_u_747 - 6) / 2
		local v920 = math.floor(v919)
		v_u_911.boxes.u = v_u_682(v918, "RsL_u_" .. p_u_909, "Price", v920, function()
			-- upvalues: (ref) v_u_836
			v_u_836()
		end)
		v_u_911.boxes.c = v_u_682(v918, "RsL_c_" .. p_u_909, "Limit", v920, function()
			-- upvalues: (ref) v_u_836
			v_u_836()
		end)
		v917("TOTAL  \194\183  MIN PER BUY  \194\183  MAX PER BUY  \194\183  PER  (fixed)")
		local v921 = v915("Fixed")
		local v922 = (v_u_747 - 18) / 4
		local v923 = math.floor(v922)
		v_u_911.boxes.s = v_u_682(v921, "RsL_s_" .. p_u_909, "Total", v923, nil)
		v_u_911.boxes.q1 = v_u_682(v921, "RsL_q1_" .. p_u_909, "Min", v923, nil)
		v_u_911.boxes.q2 = v_u_682(v921, "RsL_q2_" .. p_u_909, "Max", v923, nil)
		v_u_911.boxes.w = v_u_682(v921, "RsL_w_" .. p_u_909, "Per", v923, nil)
		for _, v924 in {
			"s",
			"q1",
			"q2",
			"w"
		} do
			local v925 = v_u_911.boxes[v924].frame
			local v926 = v_u_911.boxes[v924].box
			v926.TextEditable = false
			v926.TextColor3 = v_u_651.muted
			v925.BackgroundTransparency = 0.55
		end
		v917("TOP UP  (units to add to this row, second press)  \194\183  PULL  \194\183  REPLACE ROW")
		local v927 = v915("Actions")
		local v928 = v_u_682
		local v929 = "RsL_top_" .. p_u_909
		local v930 = (v_u_747 - 18) / 4
		v_u_911.topBox = v928(v927, v929, "Units, e.g. 2k", math.floor(v930), function()
			-- upvalues: (ref) v_u_668, (copy) p_u_909, (copy) v_u_911, (ref) v_u_624, (ref) v_u_19
			local v931 = v_u_668["top" .. p_u_909]
			if v931 then
				local v932 = v_u_911.topBox.box.Text
				if v_u_624 == nil then
					v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
				end
				local v933 = v_u_624.parseNumber(v932)
				v931.enabled = v933 ~= nil and v933 >= 1 and true or v_u_19(v_u_911.topBox.box.Text)
				v931.api.setEnabled(v931.enabled)
			end
		end)
		local v934 = v_u_720
		local v935 = "top" .. p_u_909
		local v936 = (v_u_747 - 18) / 4
		v934(v927, v935, "Top up", "secondary", math.floor(v936), function()
			-- upvalues: (ref) v_u_770, (copy) v_u_911, (ref) v_u_624, (ref) v_u_19, (ref) v_u_768, (ref) v_u_767, (ref) v_u_4, (copy) p_u_909, (ref) v_u_771, (ref) v_u_670, (ref) v_u_652, (ref) p_u_646, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769
			local v937 = v_u_770
			local v938
			if type(v937) == "table" then
				v938 = v_u_770.plan
			else
				v938 = nil
			end
			local v939
			if type(v938) == "table" then
				v939 = v938.r
			else
				v939 = nil
			end
			local v940 = v_u_911.topBox.box.Text
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			local v941 = v_u_624.parseNumber(v940)
			if v941 == nil and v_u_19(v_u_911.topBox.box.Text) then
				v_u_768.Text = "TOP UP must be a whole number of units."
				v_u_768.Visible = true
				v_u_767.Visible = false
				v_u_767.Text = ""
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "TOP UP must be a whole number of units.")
				end
				return
			elseif v939 == nil or (v941 == nil or v941 < 1) then
				v_u_768.Text = "TOP UP needs a number of units."
				v_u_768.Visible = true
				v_u_767.Visible = false
				v_u_767.Text = ""
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "TOP UP needs a number of units.")
				end
				return
			elseif v941 == math.floor(v941) then
				local v942 = {
					["rid"] = v939,
					["ix"] = p_u_909,
					["n"] = v941
				}
				local v_u_943 = "Row " .. p_u_909 .. " has more units."
				local function v_u_945()
					-- upvalues: (ref) v_u_911, (ref) v_u_771, (ref) v_u_670
					local v944 = v_u_911.topBox.box
					v_u_771 = true
					v944.Text = ""
					v_u_670[v944] = ""
					v_u_771 = false
				end
				v_u_768.Text = ""
				v_u_768.Visible = false
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "")
				end
				local v_u_946 = nil
				v_u_652("topup", v942, function(p947)
					-- upvalues: (copy) v_u_943, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_945, (ref) v_u_4, (ref) v_u_3, (copy) v_u_946, (ref) v_u_837, (ref) v_u_769
					if type(p947) == "table" and p947.ok == true then
						local v948 = p947.msg or v_u_943
						local v949 = tostring(v948)
						v_u_767.Text = v949 or ""
						v_u_767.Visible = (v949 or "") ~= ""
						if v949 and v949 ~= "" then
							v_u_768.Visible = false
							v_u_768.Text = ""
							if p_u_646.handle then
								local v950 = p_u_646.handle.status
								if type(v950) == "function" then
									local v951 = p_u_646.handle.status
									pcall(v951, v949)
								end
							end
						end
						if v_u_945 then
							v_u_945(p947)
						end
					else
						local v952 = p947 and p947.msg or "The server did not answer."
						local v953 = tostring(v952)
						v_u_768.Text = v953 or ""
						v_u_768.Visible = (v953 or "") ~= ""
						if v953 and v953 ~= "" then
							v_u_767.Visible = false
							v_u_767.Text = ""
						end
						if v_u_4 then
							v_u_4:SetAttribute("FilmRestockLiveError", v953 or "")
						end
						local v954 = v_u_3.wordFromText(v953)
						if v954 ~= nil and v_u_946 ~= nil then
							v_u_946[v954] = true
							v_u_837()
						end
					end
					v_u_769()
				end, "write")
			else
				v_u_768.Text = "TOP UP must be a whole number of units."
				v_u_768.Visible = true
				v_u_767.Visible = false
				v_u_767.Text = ""
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "TOP UP must be a whole number of units.")
				end
			end
		end, function()
			-- upvalues: (copy) v_u_911, (ref) v_u_624
			local v955 = {}
			local v956 = v_u_911.topBox.box.Text
			if v_u_624 == nil then
				v_u_624 = require(script.Parent:WaitForChild("FilmRestockForm"))
			end
			v955.n = v_u_624.parseNumber(v956)
			return v955
		end)
		local v957 = v_u_720
		local v958 = "pull" .. p_u_909
		local v959 = (v_u_747 - 18) / 4
		v957(v927, v958, "Pull", "danger", math.floor(v959), function()
			-- upvalues: (ref) v_u_770, (copy) p_u_909, (ref) v_u_768, (ref) v_u_4, (ref) v_u_652, (ref) v_u_767, (ref) p_u_646, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769
			local v960 = v_u_770
			local v961
			if type(v960) == "table" then
				v961 = v_u_770.plan
			else
				v961 = nil
			end
			local v962
			if type(v961) == "table" then
				v962 = v961.r
			else
				v962 = nil
			end
			if v962 ~= nil then
				local v963 = {
					["rid"] = v962,
					["ix"] = p_u_909
				}
				local v_u_964 = "Row " .. p_u_909 .. " is out of the sale."
				v_u_768.Text = ""
				v_u_768.Visible = false
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", "")
				end
				local v_u_965 = nil
				local v_u_966 = nil
				v_u_652("pull", v963, function(p967)
					-- upvalues: (copy) v_u_964, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_965, (ref) v_u_4, (ref) v_u_3, (copy) v_u_966, (ref) v_u_837, (ref) v_u_769
					if type(p967) == "table" and p967.ok == true then
						local v968 = p967.msg or v_u_964
						local v969 = tostring(v968)
						v_u_767.Text = v969 or ""
						v_u_767.Visible = (v969 or "") ~= ""
						if v969 and v969 ~= "" then
							v_u_768.Visible = false
							v_u_768.Text = ""
							if p_u_646.handle then
								local v970 = p_u_646.handle.status
								if type(v970) == "function" then
									local v971 = p_u_646.handle.status
									pcall(v971, v969)
								end
							end
						end
						if v_u_965 then
							v_u_965(p967)
						end
					else
						local v972 = p967 and p967.msg or "The server did not answer."
						local v973 = tostring(v972)
						v_u_768.Text = v973 or ""
						v_u_768.Visible = (v973 or "") ~= ""
						if v973 and v973 ~= "" then
							v_u_767.Visible = false
							v_u_767.Text = ""
						end
						if v_u_4 then
							v_u_4:SetAttribute("FilmRestockLiveError", v973 or "")
						end
						local v974 = v_u_3.wordFromText(v973)
						if v974 ~= nil and v_u_966 ~= nil then
							v_u_966[v974] = true
							v_u_837()
						end
					end
					v_u_769()
				end, "write")
			end
		end)
		local v975 = v_u_648.btn
		local v976 = (v_u_747 - 18) / 4
		v975(v927, "Replace row", "secondary", math.floor(v976), function()
			-- upvalues: (ref) v_u_655, (copy) p_u_909
			v_u_655.replaceRow(p_u_909)
		end).Name = "RsL_replace" .. p_u_909
		local v977 = v_u_668["top" .. p_u_909]
		if v977 then
			v977.enabled = false
			v977.api.setEnabled(false)
		end
		v_u_655._rowViews[p_u_909] = v_u_911
		return v_u_911
	end
	function v_u_655.replaceRow(p979) -- name: replaceRow
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (ref) v_u_905, (ref) v_u_906, (ref) v_u_907, (ref) v_u_908
		local v980 = v_u_770
		local v981
		if type(v980) == "table" then
			v981 = v_u_770.plan
		else
			v981 = nil
		end
		if v981 ~= nil then
			local v982 = v981.ix
			if type(v982) == "table" and (v981.ix[p979] ~= nil and v981.ix[p979].bad ~= true) then
				local v983 = v_u_770
				local v984
				if type(v983) == "table" then
					local v985 = v_u_770.sums
					if type(v985) == "table" then
						v984 = v985[p979]
						if v984 == nil then
							v984 = v985[tostring(p979)]
						end
					else
						v984 = nil
					end
				else
					v984 = nil
				end
				local v986 = v_u_3.replaceDefaults
				local v987 = v_u_770
				local v988
				if type(v987) == "table" then
					v988 = v_u_770.scan
				else
					v988 = nil
				end
				local v989, v990 = v986(v981, p979, v984, v988)
				v_u_905 = v989
				v_u_906 = p979
				v_u_907 = v990
				v_u_908()
				return
			end
		end
	end
	local function v_u_1025(p991, p992) -- name: syncRows
		-- upvalues: (copy) v_u_655, (copy) v_u_978, (ref) v_u_3, (ref) v_u_771, (copy) v_u_670, (copy) v_u_647, (copy) v_u_668
		local v993
		if type(p991) == "table" then
			local v994 = p991.ix
			v993 = type(v994) == "table" and #p991.ix or 0
		else
			v993 = 0
		end
		for v995 = v993 + 1, #v_u_655._rowViews do
			local v996 = v_u_655._rowViews[v995]
			if not v996 then
				continue
			end
			v996.card:Destroy()
			v_u_655._rowViews[v995] = nil
		end
		for v997 = 1, v993 do
			local v998 = p991.ix[v997]
			local v999 = v_u_655._rowViews[v997] or v_u_978(v997)
			v999.title.Text = v_u_3.rowTitle(v997, v998)
			local v1000
			if type(p992) == "table" then
				v1000 = p992[v997]
				if v1000 == nil then
					v1000 = p992[tostring(v997)]
				end
			else
				v1000 = nil
			end
			v999.stats.Text = v_u_3.rowStats(v998, v1000)
			if type(v998) == "table" and v998.bad ~= true then
				local v1001 = v999.boxes.u
				local v1002 = v998.u
				local v1003 = tostring(v1002)
				if v1001.box.Text == v1001.base or v1001.box.Text == "" then
					local v1004 = v1001.box
					v_u_771 = true
					v1004.Text = v1003
					v_u_670[v1004] = v1003
					v_u_771 = false
				end
				v1001.base = v1003
				local v1005 = v999.boxes.c
				local v1006 = v998.c
				local v1007 = tostring(v1006)
				if v1005.box.Text == v1005.base or v1005.box.Text == "" then
					local v1008 = v1005.box
					v_u_771 = true
					v1008.Text = v1007
					v_u_670[v1008] = v1007
					v_u_771 = false
				end
				v1005.base = v1007
				local v1009 = v999.boxes.s.box
				local v1010 = v998.s
				local v1011 = tostring(v1010)
				v_u_771 = true
				v1009.Text = v1011
				v_u_670[v1009] = v1011
				v_u_771 = false
				local v1012 = v999.boxes.q1.box
				local v1013 = v998.q1
				local v1014 = tostring(v1013)
				v_u_771 = true
				v1012.Text = v1014
				v_u_670[v1012] = v1014
				v_u_771 = false
				local v1015 = v999.boxes.q2.box
				local v1016 = v998.q2
				local v1017 = tostring(v1016)
				v_u_771 = true
				v1015.Text = v1017
				v_u_670[v1015] = v1017
				v_u_771 = false
				local v1018 = "1 H"
				for _, v1019 in v_u_647.WINDOWS do
					if v1019[1] ~= v998.w then
						continue
					end
					v1018 = v1019[2]
				end
				local v1020 = v999.boxes.w.box
				v_u_771 = true
				v1020.Text = v1018
				v_u_670[v1020] = v1018
				v_u_771 = false
			end
			local v1021
			if type(v998) == "table" then
				v1021 = v998.off == true
			else
				v1021 = false
			end
			local v1022 = type(v998) ~= "table" and true or v998.bad == true
			local v1023 = v_u_668["pull" .. v997]
			if v1023 then
				local v1024 = not v1021
				if v1024 then
					v1024 = not v1022
				end
				v1023.enabled = v1024
				v1023.api.setEnabled(v1023.enabled)
			end
			v999.card.BackgroundTransparency = v1021 and 0.4 or 0
		end
	end
	local v_u_1026 = v_u_649.new("Frame", {
		["Name"] = "RsLiveAdd",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_651.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v665.nextOrder()
	}, v_u_663)
	v_u_649.stroke(v_u_1026, v_u_651.line)
	v_u_649.pad(v_u_1026, {
		10,
		10,
		8,
		10
	})
	v_u_649.layout(v_u_1026, "v", 6)
	local v_u_1027 = 0
	local function v1030(p1028) -- name: acap
		-- upvalues: (ref) v_u_1027, (copy) v_u_649, (copy) v_u_1026, (copy) v_u_651
		v_u_1027 = v_u_1027 + 1
		local v1029 = v_u_649.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v_u_1026,
			["text"] = p1028,
			["color"] = v_u_651.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		v1029.LayoutOrder = v_u_1027
		return v1029
	end
	local function v1033(p1031) -- name: arow
		-- upvalues: (ref) v_u_1027, (copy) v_u_649, (copy) v_u_650, (copy) v_u_1026
		v_u_1027 = v_u_1027 + 1
		local v1032 = v_u_649.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = p1031,
			["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
			["LayoutOrder"] = v_u_1027
		}, v_u_1026)
		v_u_649.layout(v1032, "h", 6)
		return v1032
	end
	local function v1037(p1034, p1035) -- name: anote
		-- upvalues: (ref) v_u_1027, (copy) v_u_649, (copy) v_u_1026
		v_u_1027 = v_u_1027 + 1
		local v1036 = v_u_649.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v_u_1026,
			["name"] = p1035,
			["color"] = p1034,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v1036.RichText = false
		v1036.LayoutOrder = v_u_1027
		return v1036
	end
	v_u_1027 = v_u_1027 + 1
	local v_u_1038 = v_u_649.label({
		["parent"] = nil,
		["name"] = "AddTitle",
		["text"] = "Add a row",
		["style"] = "h3",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_1026,
		["color"] = v_u_651.text,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_1038.LayoutOrder = v_u_1027
	v_u_1038.RichText = false
	v1037(v_u_651.text2, "RsLiveAddHint").Text = "A new row has its own stock and its own limit window. It starts at the earliest 30 seconds after it is saved."
	local v_u_1039 = {}
	local v_u_1040 = {}
	local v_u_1041 = {}
	local function v_u_1042() end
	local v_u_1043 = {}
	local function v_u_1044() end
	v1030("ITEM  (type a name or an id)")
	local v_u_1045 = "id"
	v_u_1041.id = v_u_682(v1033("RsLiveAddItem"), "RsL_add_id", "Item: type a name or id, e.g. 9mm", v_u_747, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1045, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1045] = v_u_1041[v_u_1045].box.Text
		if v_u_1045 == "id" then
			local v1046 = v_u_905
			local v1047 = string.lower
			local v1048 = v_u_1041.id.box.Text
			local v1049
			if type(v1048) == "string" then
				local v1050 = string.gsub(v1048, "^%s+", "")
				v1049 = string.gsub(v1050, "%s+$", "")
			else
				v1049 = ""
			end
			v1046.id = v1047(v1049)
		end
		v_u_1044()
		if v_u_1045 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	v_u_1027 = v_u_1027 + 1
	local v_u_1051 = v_u_649.new("Frame", {
		["Name"] = "AddSuggestions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v_u_1027
	}, v_u_1026)
	v_u_649.layout(v_u_1051, "v", 4)
	v1030("PRICE EACH  \194\183  TOTAL AMOUNT (5k, 2m, 5.000)  \194\183  MIN PER BUY  \194\183  MAX PER BUY")
	local v1052 = v1033("RsLiveAddNums")
	local v1053 = (v_u_747 - 18) / 4
	local v1054 = math.floor(v1053)
	local v_u_1055 = "u"
	v_u_1041.u = v_u_682(v1052, "RsL_add_u", "Price $", v1054, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1055, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1055] = v_u_1041[v_u_1055].box.Text
		if v_u_1055 == "id" then
			local v1056 = v_u_905
			local v1057 = string.lower
			local v1058 = v_u_1041.id.box.Text
			local v1059
			if type(v1058) == "string" then
				local v1060 = string.gsub(v1058, "^%s+", "")
				v1059 = string.gsub(v1060, "%s+$", "")
			else
				v1059 = ""
			end
			v1056.id = v1057(v1059)
		end
		v_u_1044()
		if v_u_1055 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	local v_u_1061 = "s"
	v_u_1041.s = v_u_682(v1052, "RsL_add_s", "Total", v1054, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1061, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1061] = v_u_1041[v_u_1061].box.Text
		if v_u_1061 == "id" then
			local v1062 = v_u_905
			local v1063 = string.lower
			local v1064 = v_u_1041.id.box.Text
			local v1065
			if type(v1064) == "string" then
				local v1066 = string.gsub(v1064, "^%s+", "")
				v1065 = string.gsub(v1066, "%s+$", "")
			else
				v1065 = ""
			end
			v1062.id = v1063(v1065)
		end
		v_u_1044()
		if v_u_1061 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	local v_u_1067 = "q1"
	v_u_1041.q1 = v_u_682(v1052, "RsL_add_q1", "Min buy", v1054, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1067, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1067] = v_u_1041[v_u_1067].box.Text
		if v_u_1067 == "id" then
			local v1068 = v_u_905
			local v1069 = string.lower
			local v1070 = v_u_1041.id.box.Text
			local v1071
			if type(v1070) == "string" then
				local v1072 = string.gsub(v1070, "^%s+", "")
				v1071 = string.gsub(v1072, "%s+$", "")
			else
				v1071 = ""
			end
			v1068.id = v1069(v1071)
		end
		v_u_1044()
		if v_u_1067 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	local v_u_1073 = "q2"
	v_u_1041.q2 = v_u_682(v1052, "RsL_add_q2", "Max buy", v1054, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1073, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1073] = v_u_1041[v_u_1073].box.Text
		if v_u_1073 == "id" then
			local v1074 = v_u_905
			local v1075 = string.lower
			local v1076 = v_u_1041.id.box.Text
			local v1077
			if type(v1076) == "string" then
				local v1078 = string.gsub(v1076, "^%s+", "")
				v1077 = string.gsub(v1078, "%s+$", "")
			else
				v1077 = ""
			end
			v1074.id = v1075(v1077)
		end
		v_u_1044()
		if v_u_1073 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	v1030("LIMIT PER PLAYER  \194\183  PER (tap to change)")
	local v1079 = v1033("RsLiveAddLimit")
	local v1080 = (v_u_747 - 6) / 2
	local v1081 = math.floor(v1080)
	local v_u_1082 = "c"
	v_u_1041.c = v_u_682(v1079, "RsL_add_c", "Limit", v1081, function()
		-- upvalues: (ref) v_u_905, (copy) v_u_1082, (copy) v_u_1041, (ref) v_u_1044, (ref) v_u_1043, (copy) v_u_647, (ref) v_u_1042
		v_u_905[v_u_1082] = v_u_1041[v_u_1082].box.Text
		if v_u_1082 == "id" then
			local v1083 = v_u_905
			local v1084 = string.lower
			local v1085 = v_u_1041.id.box.Text
			local v1086
			if type(v1085) == "string" then
				local v1087 = string.gsub(v1085, "^%s+", "")
				v1086 = string.gsub(v1087, "%s+$", "")
			else
				v1086 = ""
			end
			v1083.id = v1084(v1086)
		end
		v_u_1044()
		if v_u_1082 == "id" then
			v_u_1043 = v_u_647.searchItems(v_u_1041.id.box.Text, v_u_647.SUGGEST_MAX)
		end
		v_u_1042()
	end)
	local v1088 = v_u_648.btn
	local v1089 = v_u_905.w
	local v_u_1090 = v_u_906
	local v_u_1091 = v_u_1042
	local v_u_1092 = v_u_905
	local v_u_1093 = v_u_1043
	local v1094 = v_u_1027
	local v_u_1095 = v_u_908
	local v_u_1096 = v903
	local v_u_1097 = v_u_907
	local v_u_1098 = v_u_1044
	local v_u_1099 = nil
	for _, v1100 in v_u_647.WINDOWS do
		if v1100[1] ~= v1089 then
			continue
		end
		v1101 = "per " .. v1100[2]
	end
	local v1101 = "per 1 H"
	local v1110, v1111 = v1088(v1079, v1101, "secondary", v1081, function()
		-- upvalues: (copy) v_u_647, (ref) v_u_1092, (ref) v_u_1098, (ref) v_u_1099, (ref) v_u_1091
		local v1102 = 1
		for v1103, v1104 in v_u_647.WINDOWS do
			if v1104[1] ~= v_u_1092.w then
				continue
			end
			v1102 = v1103
		end
		local v1105 = v1102 % #v_u_647.WINDOWS + 1
		v_u_1092.w = v_u_647.WINDOWS[v1105][1]
		v_u_1098()
		local v1106 = v_u_1099.setText
		local v1107 = v_u_1092.w
		for _, v1108 in v_u_647.WINDOWS do
			if v1108[1] ~= v1107 then
				continue
			end
			v1109 = "per " .. v1108[2]
		end
		local v1109 = "per 1 H"
		v1106(v1109)
		v_u_1091()
	end)
	local v1112 = v1111
	v1110.Name = "RsL_add_window"
	v1110.LayoutOrder = 2
	local v_u_1113 = v1037(v_u_651.text2, "RsLiveAddInfo")
	local v_u_1114 = v1037(v_u_651.danger, "RsLiveAddMsg")
	v_u_1113.Visible = false
	v_u_1114.Visible = false
	local v_u_1115 = v1112
	local v_u_1116 = {}
	for _, v_u_1117 in { "PRICE", "AMOUNT", "RARE" } do
		v_u_1027 = v1094 + 1
		local v1118 = v_u_649.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Name"] = "RsLAddWord_" .. v_u_1117,
			["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
			["LayoutOrder"] = v_u_1027
		}, v_u_1026)
		v_u_649.layout(v1118, "h", 6)
		local _, v_u_1119 = v_u_649.input({
			["parent"] = v1118,
			["name"] = "RsL_AddWord_" .. v_u_1117,
			["size"] = UDim2.fromOffset(v_u_747, v_u_650.touch(34)),
			["placeholder"] = "Type " .. v_u_1117 .. " to allow this"
		})
		v_u_1119:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_1119, (ref) v_u_771, (copy) v_u_670, (copy) v_u_1117, (ref) v_u_1092, (ref) v_u_1091
			local v1120 = v_u_1119
			local v1121
			if v_u_771 or v_u_670[v1120] == v1120.Text then
				v1121 = false
			else
				v_u_670[v1120] = v1120.Text
				v1121 = true
			end
			if v1121 then
				local v1122 = string.upper
				local v1123 = v_u_1119.Text
				local v1124
				if type(v1123) == "string" then
					local v1125 = string.gsub(v1123, "^%s+", "")
					v1124 = string.gsub(v1125, "%s+$", "")
				else
					v1124 = ""
				end
				local v1126 = v1122(v1124) == v_u_1117
				v_u_1092.typed[v_u_1117] = v1126 and true or nil
				v_u_1091()
			end
		end)
		v_u_1116[v_u_1117] = {
			["frame"] = v1118,
			["box"] = v_u_1119
		}
		v1094 = v_u_1027
	end
	v_u_1044 = function()
		-- upvalues: (ref) v_u_1092, (copy) v_u_1040, (copy) v_u_1116, (ref) v_u_771, (copy) v_u_670
		v_u_1092.typed = {}
		table.clear(v_u_1040)
		for _, v1127 in v_u_1116 do
			if v1127.box.Text == "" then
				continue
			end
			local v1128 = v1127.box
			v_u_771 = true
			v1128.Text = ""
			v_u_670[v1128] = ""
			v_u_771 = false
		end
	end
	local v1129 = v1033("RsLiveAddButtons")
	v_u_720(v1129, "add", "Add row", "primary", 220, function() -- name: doAdd
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (ref) v_u_1092, (ref) v_u_768, (ref) v_u_767, (ref) v_u_4, (ref) v_u_1090, (copy) v_u_652, (copy) p_u_646, (ref) v_u_1097, (copy) v_u_647, (copy) v_u_1040, (ref) v_u_1095, (ref) v_u_1091, (ref) v_u_769
		local v1130 = v_u_770
		local v1131
		if type(v1130) == "table" then
			v1131 = v_u_770.plan
		else
			v1131 = nil
		end
		local v1132
		if type(v1131) == "table" then
			v1132 = v1131.r
		else
			v1132 = nil
		end
		local v1133, v1134, v1135 = v_u_3.addRowDraft(v_u_1092)
		if v1132 == nil or v1133 == nil then
			local v1136 = not v1134[1] and "Nothing to add." or v1134[1]
			v_u_768.Text = v1136 or ""
			v_u_768.Visible = (v1136 or "") ~= ""
			if v1136 and v1136 ~= "" then
				v_u_767.Visible = false
				v_u_767.Text = ""
			end
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", v1136 or "")
			end
		else
			v_u_768.Text = ""
			v_u_768.Visible = false
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", "")
			end
			local v1137 = v_u_1090 ~= nil
			local v1138 = {
				["rid"] = v1132,
				["row"] = v1133,
				["typed"] = v1135
			}
			if v1137 then
				v1138.ix = v_u_1090
			end
			v_u_652(v1137 and "replace" or "append", v1138, function(p1139)
				-- upvalues: (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (ref) v_u_1092, (ref) v_u_1090, (ref) v_u_1097, (ref) v_u_647, (ref) v_u_1040, (ref) v_u_1095, (ref) v_u_4, (ref) v_u_3, (ref) v_u_1091, (ref) v_u_769
				if type(p1139) == "table" and p1139.ok == true then
					local v1140 = p1139.msg or "The row was added."
					local v1141 = tostring(v1140)
					v_u_767.Text = v1141 or ""
					v_u_767.Visible = (v1141 or "") ~= ""
					if v1141 and v1141 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v1142 = p_u_646.handle.status
							if type(v1142) == "function" then
								local v1143 = p_u_646.handle.status
								pcall(v1143, v1141)
							end
						end
					end
					v_u_1092 = v_u_647.newRow()
					v_u_1090 = nil
					v_u_1097 = ""
					table.clear(v_u_1040)
					v_u_1095()
				else
					local v1144 = p1139 and (p1139.msg or "The server did not answer.") or "The server did not answer."
					local v1145 = tostring(v1144)
					v_u_768.Text = v1145 or ""
					v_u_768.Visible = (v1145 or "") ~= ""
					if v1145 and v1145 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v1145 or "")
					end
					local v1146
					if type(p1139) == "table" then
						local v1147 = p1139.data
						if type(v1147) == "table" then
							v1146 = p1139.data.errors
						else
							v1146 = nil
						end
					else
						v1146 = nil
					end
					for _, v1148 in v_u_647.neededWords(v1146) do
						v_u_1040[v1148.word] = true
					end
					local v1149 = v_u_3.wordFromText(v1145)
					if v1149 ~= nil then
						v_u_1040[v1149] = true
					end
					v_u_1091()
				end
				v_u_769()
			end, "write")
		end
	end, function()
		-- upvalues: (ref) v_u_3, (ref) v_u_1092, (ref) v_u_1090
		local v1150, _, v1151 = v_u_3.addRowDraft(v_u_1092)
		return {
			["row"] = v1150,
			["typed"] = v1151,
			["ix"] = v_u_1090
		}
	end)
	v_u_648.btn(v1129, "Clear", "ghost", 120, function()
		-- upvalues: (ref) v_u_1092, (ref) v_u_1090, (ref) v_u_1097, (copy) v_u_647, (copy) v_u_1040, (ref) v_u_1095
		v_u_1092 = v_u_647.newRow()
		v_u_1090 = nil
		v_u_1097 = ""
		table.clear(v_u_1040)
		v_u_1095()
	end).Name = "RsL_addClear"
	local function v_u_1175(p_u_1152) -- name: pickAdd
		-- upvalues: (ref) v_u_2, (ref) v_u_1093, (copy) v_u_1039, (copy) v_u_647, (ref) v_u_1092, (ref) v_u_1095, (copy) v_u_652, (copy) v_u_1041, (ref) v_u_771, (copy) v_u_670, (ref) v_u_1091
		local v_u_1153 = "Items"
		local function v1154()
			-- upvalues: (ref) v_u_2, (copy) v_u_1153
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_1153, 5)))
		end
		local v1155, v1156 = pcall(v1154)
		if not v1155 then
			v1156 = nil
		end
		local v1157
		if v1156 then
			v1157 = v1156.get(p_u_1152)
		else
			v1157 = nil
		end
		if v1157 then
			v_u_1093 = {}
			local v1158 = v_u_1039[p_u_1152]
			local v1159 = v_u_647.rowFromItem
			local v1160
			if type(v1158) == "table" then
				v1160 = v1158.ref
			else
				v1160 = nil
			end
			v1159(v1157, v1160, v_u_1092)
			v_u_1092.typed = {}
			v_u_1095()
			if not v1158 then
				v_u_652("check", {
					["ids"] = { p_u_1152 }
				}, function(p1161)
					-- upvalues: (copy) p_u_1152, (ref) v_u_1039, (ref) v_u_1092, (ref) v_u_1041, (ref) v_u_771, (ref) v_u_670, (ref) v_u_1091
					if type(p1161) == "table" then
						local v1162 = p1161.data
						if type(v1162) == "table" then
							local v1163 = p1161.data.items
							if type(v1163) == "table" then
								local v1164 = p1161.data.items[p_u_1152]
								if type(v1164) == "table" then
									v_u_1039[p_u_1152] = v1164
									if v_u_1092.id == p_u_1152 then
										local v1165 = v1164.ref
										local v1166
										if type(v1165) == "number" and (v1165 == v1165 and v1165 ~= (1 / 0)) then
											v1166 = v1165 ~= (-1 / 0)
										else
											v1166 = false
										end
										if v1166 and v1164.ref >= 1 then
											local v1167 = v_u_1092.u
											local v1168
											if type(v1167) == "string" then
												local v1169 = string.gsub(v1167, "^%s+", "")
												v1168 = string.gsub(v1169, "%s+$", "")
											else
												v1168 = ""
											end
											if v1168 == "" or v_u_1092.u == "0" then
												local v1170 = v_u_1092
												local v1171 = v1164.ref + 0.5
												local v1172 = math.floor(v1171)
												v1170.u = tostring(v1172)
												local v1173 = v_u_1041.u.box
												local v1174 = v_u_1092.u
												v_u_771 = true
												v1173.Text = v1174
												v_u_670[v1173] = v1174
												v_u_771 = false
											end
										end
									end
									v_u_1091()
								end
							end
						end
					end
				end, "light")
			end
		end
	end
	v_u_655.pickAdd = v_u_1175
	v_u_1042 = function()
		-- upvalues: (copy) v_u_1038, (ref) v_u_1090, (copy) v_u_668, (ref) v_u_1051, (ref) v_u_1093, (copy) v_u_648, (copy) v_u_747, (copy) v_u_1175, (ref) v_u_3, (ref) v_u_1092, (copy) v_u_1039, (copy) v_u_647, (ref) v_u_1097, (copy) v_u_1113, (copy) v_u_1114, (copy) v_u_1116, (copy) v_u_1040, (ref) v_u_770, (copy) v_u_738
		v_u_1038.Text = v_u_1090 == nil and "Add a row" or ("Replace row %d"):format(v_u_1090)
		local v1176 = v_u_1090 ~= nil
		v_u_668.add.text = v1176 and "Replace row" or "Add row"
		for _, v1177 in v_u_1051:GetChildren() do
			if not v1177:IsA("GuiObject") then
				continue
			end
			v1177:Destroy()
		end
		v_u_1051.Visible = #v_u_1093 > 0
		for v1178, v_u_1179 in v_u_1093 do
			local v1180 = v_u_648.btn(v_u_1051, ("%s  \194\183  %s"):format(v_u_1179.name, v_u_1179.id), "secondary", v_u_747 - 10, function()
				-- upvalues: (ref) v_u_1175, (copy) v_u_1179
				v_u_1175(v_u_1179.id)
			end)
			v1180.Name = "RsL_Suggest_" .. v_u_1179.id
			v1180.LayoutOrder = v1178
		end
		local v1181, v1182 = v_u_3.addRowDraft(v_u_1092)
		local v1183 = {}
		if v1181 ~= nil then
			local v1184 = {
				[v_u_1092.id] = v_u_1039[v_u_1092.id]
			}
			local v1185 = v_u_647.rowEcho(v_u_1092, v1184)
			if v1185 ~= "" then
				table.insert(v1183, v1185)
			end
			local v1186 = v_u_647.rowInfo(v_u_1092, v1184)
			if v1186 ~= "" then
				table.insert(v1183, v1186)
			end
		end
		if v_u_1097 ~= "" then
			local v1187 = v_u_1097
			table.insert(v1183, v1187)
		end
		v_u_1113.Text = table.concat(v1183, "\n")
		v_u_1113.Visible = #v1183 > 0
		local v1188 = v_u_1114
		local v1189, v1190, v1191, v1192, v1193, v1194
		if v1181 == nil then
			local v1195 = v_u_1092.id
			local v1196
			if type(v1195) == "string" then
				local v1197 = string.gsub(v1195, "^%s+", "")
				v1196 = string.gsub(v1197, "%s+$", "")
			else
				v1196 = ""
			end
			if v1196 == "" then
				local v1198 = v_u_1092.u
				local v1199
				if type(v1198) == "string" then
					local v1200 = string.gsub(v1198, "^%s+", "")
					v1199 = string.gsub(v1200, "%s+$", "")
				else
					v1199 = ""
				end
				if v1199 == "" then
					local v1201 = v_u_1092.s
					local v1202
					if type(v1201) == "string" then
						local v1203 = string.gsub(v1201, "^%s+", "")
						v1202 = string.gsub(v1203, "%s+$", "")
					else
						v1202 = ""
					end
					if v1202 == "" then
						v1189 = ""
						v1188.Text = v1189
						v_u_1114.Visible = v_u_1114.Text ~= ""
						for v1212, v1213 in v_u_1116 do
							v1213.frame.Visible = v_u_1092.typed[v1212] == true and true or v_u_1040[v1212] == true
						end
						v1190 = v_u_668.add
						if v1181 == nil then
							v1191 = false
						else
							v1192 = v_u_770
							if type(v1192) == "table" then
								v1193 = v_u_770.plan
							else
								v1193 = nil
							end
							if type(v1193) == "table" then
								v1194 = v1193.r
							else
								v1194 = nil
							end
							v1191 = v1194 ~= nil
						end
						v1190.enabled = v1191
						v_u_668.add.api.setEnabled(v_u_668.add.enabled)
						v_u_738()
					else
						v1189 = v1182[1] or ""
						v1188.Text = v1189
						v_u_1114.Visible = v_u_1114.Text ~= ""
						for v1212, v1213 in v_u_1116 do
							v1213.frame.Visible = v_u_1092.typed[v1212] == true and true or v_u_1040[v1212] == true
						end
						v1190 = v_u_668.add
						if v1181 == nil then
							v1191 = false
						else
							v1192 = v_u_770
							if type(v1192) == "table" then
								v1193 = v_u_770.plan
							else
								v1193 = nil
							end
							if type(v1193) == "table" then
								v1194 = v1193.r
							else
								v1194 = nil
							end
							v1191 = v1194 ~= nil
						end
						v1190.enabled = v1191
						v_u_668.add.api.setEnabled(v_u_668.add.enabled)
						v_u_738()
					end
				else
					v1189 = v1182[1] or ""
					v1188.Text = v1189
					v_u_1114.Visible = v_u_1114.Text ~= ""
					for v1212, v1213 in v_u_1116 do
						v1213.frame.Visible = v_u_1092.typed[v1212] == true and true or v_u_1040[v1212] == true
					end
					v1190 = v_u_668.add
					if v1181 == nil then
						v1191 = false
					else
						v1192 = v_u_770
						if type(v1192) == "table" then
							v1193 = v_u_770.plan
						else
							v1193 = nil
						end
						if type(v1193) == "table" then
							v1194 = v1193.r
						else
							v1194 = nil
						end
						v1191 = v1194 ~= nil
					end
					v1190.enabled = v1191
					v_u_668.add.api.setEnabled(v_u_668.add.enabled)
					v_u_738()
					return
				end
			else
				v1189 = v1182[1] or ""
				v1188.Text = v1189
				v_u_1114.Visible = v_u_1114.Text ~= ""
				for v1212, v1213 in v_u_1116 do
					v1213.frame.Visible = v_u_1092.typed[v1212] == true and true or v_u_1040[v1212] == true
				end
				v1190 = v_u_668.add
				if v1181 == nil then
					v1191 = false
				else
					v1192 = v_u_770
					if type(v1192) == "table" then
						v1193 = v_u_770.plan
					else
						v1193 = nil
					end
					if type(v1193) == "table" then
						v1194 = v1193.r
					else
						v1194 = nil
					end
					v1191 = v1194 ~= nil
				end
				v1190.enabled = v1191
				v_u_668.add.api.setEnabled(v_u_668.add.enabled)
				v_u_738()
				return
			end
		else
			v1189 = ""
			v1188.Text = v1189
			v_u_1114.Visible = v_u_1114.Text ~= ""
			for v1212, v1213 in v_u_1116 do
				v1213.frame.Visible = v_u_1092.typed[v1212] == true and true or v_u_1040[v1212] == true
			end
			v1190 = v_u_668.add
			if v1181 == nil then
				v1191 = false
			else
				v1192 = v_u_770
				if type(v1192) == "table" then
					v1193 = v_u_770.plan
				else
					v1193 = nil
				end
				if type(v1193) == "table" then
					v1194 = v1193.r
				else
					v1194 = nil
				end
				v1191 = v1194 ~= nil
			end
			v1190.enabled = v1191
			v_u_668.add.api.setEnabled(v_u_668.add.enabled)
			v_u_738()
			return
		end
	end
	v_u_908 = function()
		-- upvalues: (copy) v_u_1041, (ref) v_u_1092, (ref) v_u_771, (copy) v_u_670, (copy) v_u_1116, (ref) v_u_1115, (copy) v_u_647, (ref) v_u_1042
		local v1214 = v_u_1041.id.box
		local v1215 = v_u_1092.id
		v_u_771 = true
		v1214.Text = v1215
		v_u_670[v1214] = v1215
		v_u_771 = false
		for _, v1216 in {
			"u",
			"s",
			"q1",
			"q2",
			"c"
		} do
			local v1217 = v_u_1041[v1216].box
			local v1218 = v_u_1092[v1216] or ""
			local v1219 = tostring(v1218)
			v_u_771 = true
			v1217.Text = v1219
			v_u_670[v1217] = v1219
			v_u_771 = false
		end
		for v1220, v1221 in v_u_1116 do
			local v1222 = v1221.box
			local v1223 = v_u_1092.typed[v1220] ~= true and "" or v1220
			v_u_771 = true
			v1222.Text = v1223
			v_u_670[v1222] = v1223
			v_u_771 = false
		end
		if v_u_1115 then
			local v1224 = v_u_1115.setText
			local v1225 = v_u_1092.w
			for _, v1226 in v_u_647.WINDOWS do
				if v1226[1] ~= v1225 then
					continue
				end
				v1227 = "per " .. v1226[2]
			end
			local v1227 = "per 1 H"
			v1224(v1227)
		end
		v_u_1042()
	end
	local v_u_1228 = v_u_649.new("Frame", {
		["Name"] = "RsLiveEditChange",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_651.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v665.nextOrder()
	}, v_u_663)
	v_u_649.stroke(v_u_1228, v_u_651.line)
	v_u_649.pad(v_u_1228, {
		10,
		10,
		8,
		10
	})
	v_u_649.layout(v_u_1228, "v", 6)
	local v_u_1229 = v_u_649.label({
		["parent"] = nil,
		["name"] = "EditChangeText",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_1228,
		["color"] = v_u_651.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_1229.RichText = false
	v_u_1229.LayoutOrder = 1
	local v1230 = v_u_649.new("Frame", {
		["Name"] = "EditChangeRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34))
	}, v_u_1228)
	v_u_649.layout(v1230, "h", 6)
	local function v_u_1235() -- name: formEditPatch
		-- upvalues: (copy) p_u_646, (ref) v_u_770, (ref) v_u_3, (copy) v_u_662
		local v1231
		if p_u_646.form then
			v1231 = p_u_646.form()
		else
			v1231 = nil
		end
		local v1232 = v_u_770
		local v1233
		if type(v1232) == "table" then
			v1233 = v_u_770.plan
		else
			v1233 = nil
		end
		if v1231 ~= nil and v1233 ~= nil then
			local v1234 = v1231.getState
			if type(v1234) == "function" then
				return v_u_3.editDiff(v1231.getState(), v1233, v_u_662())
			end
		end
		return nil, {}, 0, "no form"
	end
	v_u_720(v1230, "editChange", "Save as a change", "primary", 260, function()
		-- upvalues: (copy) v_u_1235, (ref) v_u_770, (ref) v_u_768, (ref) v_u_767, (ref) v_u_4, (copy) p_u_646, (copy) v_u_652, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769
		local v1236, v1237, _, v1238 = v_u_1235()
		local v1239 = v_u_770
		local v1240
		if type(v1239) == "table" then
			v1240 = v_u_770.plan
		else
			v1240 = nil
		end
		local v1241
		if type(v1240) == "table" then
			v1241 = v1240.r
		else
			v1241 = nil
		end
		if v1241 == nil or v1236 == nil then
			local v1242 = not v1237[1] and (v1238 or "Nothing to change.") or v1237[1]
			v_u_768.Text = v1242 or ""
			v_u_768.Visible = (v1242 or "") ~= ""
			if v1242 and v1242 ~= "" then
				v_u_767.Visible = false
				v_u_767.Text = ""
			end
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", v1242 or "")
			end
		else
			local v_u_1243 = p_u_646.form()
			local v1244 = {}
			for _, v1245 in v_u_1243.getState().rows do
				local v1246 = v1245.typed
				if type(v1246) ~= "table" then
					continue
				end
				for _, v1247 in { "PRICE", "AMOUNT" } do
					if v1245.typed[v1247] ~= true then
						continue
					end
					v1244[v1247] = true
				end
			end
			local v1248 = {
				["rid"] = v1241,
				["patch"] = v1236,
				["typed"] = v1244
			}
			local function v_u_1250()
				-- upvalues: (copy) v_u_1243
				local v1249 = v_u_1243.discard
				pcall(v1249)
			end
			v_u_768.Text = ""
			v_u_768.Visible = false
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", "")
			end
			local v_u_1251 = "Saved as a change. The plan stays."
			local v_u_1252 = nil
			v_u_652("patch", v1248, function(p1253)
				-- upvalues: (copy) v_u_1251, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_1250, (ref) v_u_4, (ref) v_u_3, (copy) v_u_1252, (ref) v_u_837, (ref) v_u_769
				if type(p1253) == "table" and p1253.ok == true then
					local v1254 = p1253.msg or v_u_1251
					local v1255 = tostring(v1254)
					v_u_767.Text = v1255 or ""
					v_u_767.Visible = (v1255 or "") ~= ""
					if v1255 and v1255 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v1256 = p_u_646.handle.status
							if type(v1256) == "function" then
								local v1257 = p_u_646.handle.status
								pcall(v1257, v1255)
							end
						end
					end
					if v_u_1250 then
						v_u_1250(p1253)
					end
				else
					local v1258 = p1253 and p1253.msg or "The server did not answer."
					local v1259 = tostring(v1258)
					v_u_768.Text = v1259 or ""
					v_u_768.Visible = (v1259 or "") ~= ""
					if v1259 and v1259 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v1259 or "")
					end
					local v1260 = v_u_3.wordFromText(v1259)
					if v1260 ~= nil and v_u_1252 ~= nil then
						v_u_1252[v1260] = true
						v_u_837()
					end
				end
				v_u_769()
			end, "write")
		end
	end)
	local function v_u_1268() -- name: paintEdit
		-- upvalues: (copy) v_u_1235, (copy) v_u_1228, (copy) v_u_1229, (copy) v_u_668
		local v1261, v1262, v1263 = v_u_1235()
		if v1261 == nil then
			if #v1262 > 0 then
				v_u_1228.Visible = true
				v_u_1229.Text = v1262[1]
				local v1264 = v_u_668.editChange
				if v1264 then
					v1264.enabled = false
					v1264.api.setEnabled(false)
					return
				end
			else
				v_u_1228.Visible = false
			end
		else
			v_u_1228.Visible = true
			v_u_1229.Text = ("EDIT: only fields that may change while the plan stays are different (%d). Save them as a change, so the plan keeps its line and its stock. Any other change makes a new plan."):format(v1263)
			local v1265 = ("Save as a change (%d)"):format(v1263)
			local v1266 = v_u_668.editChange
			if v1266 then
				v1266.text = v1265
			end
			local v1267 = v_u_668.editChange
			if v1267 then
				v1267.enabled = true
				v1267.api.setEnabled(true)
				return
			end
		end
	end
	local v1269 = v_u_649.new("Frame", {
		["Name"] = "RsLiveTools",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_651.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v665.nextOrder()
	}, v_u_663)
	v_u_649.stroke(v1269, v_u_651.line)
	v_u_649.pad(v1269, {
		10,
		10,
		8,
		10
	})
	v_u_649.layout(v1269, "v", 6)
	local v1270 = 0 + 1
	v_u_649.label({
		["parent"] = nil,
		["text"] = "RESUME NOW  \194\183  SCAN ALL",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v1269,
		["color"] = v_u_651.muted,
		["size"] = UDim2.new(1, 0, 0, 14)
	}).LayoutOrder = v1270
	local v1271 = v1270 + 1
	local v1272 = v_u_649.label({
		["parent"] = nil,
		["name"] = "ToolsHint",
		["text"] = "RESUME in the status block starts the sale again after 30 seconds. RESUME NOW starts it after 3 seconds. SCAN ALL reads every stock record (about 0.25 s each, at most once a minute).",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v1269,
		["color"] = v_u_651.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v1272.LayoutOrder = v1271
	v1272.RichText = false
	local v1273 = v1271 + 1
	local v1274 = v_u_649.new("Frame", {
		["Name"] = "ToolsRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_650.touch(34)),
		["LayoutOrder"] = v1273
	}, v1269)
	v_u_649.layout(v1274, "h", 6)
	local v1275 = (v_u_747 - 6) / 2
	v731(v1274, "resumeNow", "Resume now", "secondary", math.floor(v1275), function()
		-- upvalues: (ref) v_u_770, (ref) v_u_768, (ref) v_u_4, (copy) v_u_652, (ref) v_u_767, (copy) p_u_646, (ref) v_u_3, (ref) v_u_837, (ref) v_u_769
		local v1276 = v_u_770
		local v1277
		if type(v1276) == "table" then
			v1277 = v_u_770.plan
		else
			v1277 = nil
		end
		local v1278
		if type(v1277) == "table" then
			v1278 = v1277.r
		else
			v1278 = nil
		end
		if v1278 ~= nil then
			local v1279 = {
				["rid"] = nil,
				["now"] = true,
				["rid"] = v1278
			}
			v_u_768.Text = ""
			v_u_768.Visible = false
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", "")
			end
			local v_u_1280 = "The restock resumes in 3 seconds."
			local v_u_1281 = nil
			local v_u_1282 = nil
			v_u_652("resume", v1279, function(p1283)
				-- upvalues: (copy) v_u_1280, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (copy) v_u_1281, (ref) v_u_4, (ref) v_u_3, (copy) v_u_1282, (ref) v_u_837, (ref) v_u_769
				if type(p1283) == "table" and p1283.ok == true then
					local v1284 = p1283.msg or v_u_1280
					local v1285 = tostring(v1284)
					v_u_767.Text = v1285 or ""
					v_u_767.Visible = (v1285 or "") ~= ""
					if v1285 and v1285 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v1286 = p_u_646.handle.status
							if type(v1286) == "function" then
								local v1287 = p_u_646.handle.status
								pcall(v1287, v1285)
							end
						end
					end
					if v_u_1281 then
						v_u_1281(p1283)
					end
				else
					local v1288 = p1283 and p1283.msg or "The server did not answer."
					local v1289 = tostring(v1288)
					v_u_768.Text = v1289 or ""
					v_u_768.Visible = (v1289 or "") ~= ""
					if v1289 and v1289 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v1289 or "")
					end
					local v1290 = v_u_3.wordFromText(v1289)
					if v1290 ~= nil and v_u_1282 ~= nil then
						v_u_1282[v1290] = true
						v_u_837()
					end
				end
				v_u_769()
			end, "write")
		end
	end)
	local v1291 = (v_u_747 - 6) / 2
	v731(v1274, "scan", "Scan all", "secondary", math.floor(v1291), function()
		-- upvalues: (ref) v_u_770, (ref) v_u_768, (ref) v_u_4, (copy) v_u_652, (ref) v_u_767, (copy) p_u_646, (copy) v_u_655, (ref) v_u_769
		local v1292 = v_u_770
		local v1293
		if type(v1292) == "table" then
			v1293 = v_u_770.plan
		else
			v1293 = nil
		end
		local v1294
		if type(v1293) == "table" then
			v1294 = v1293.r
		else
			v1294 = nil
		end
		if v1294 ~= nil then
			v_u_768.Text = ""
			v_u_768.Visible = false
			if v_u_4 then
				v_u_4:SetAttribute("FilmRestockLiveError", "")
			end
			v_u_652("scan", {
				["rid"] = v1294
			}, function(p1295)
				-- upvalues: (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (ref) v_u_655, (ref) v_u_4, (ref) v_u_769
				if type(p1295) == "table" and p1295.ok == true then
					local v1296 = p1295.msg or "Scanning."
					local v1297 = tostring(v1296)
					v_u_767.Text = v1297 or ""
					v_u_767.Visible = (v1297 or "") ~= ""
					if v1297 and v1297 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v1298 = p_u_646.handle.status
							if type(v1298) == "function" then
								local v1299 = p_u_646.handle.status
								pcall(v1299, v1297)
							end
						end
					end
					if p_u_646.setFast then
						p_u_646.setFast(true)
					end
					v_u_655._scanning = true
				else
					local v1300 = p1295 and p1295.msg or "The server did not answer."
					local v1301 = tostring(v1300)
					v_u_768.Text = v1301 or ""
					v_u_768.Visible = (v1301 or "") ~= ""
					if v1301 and v1301 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v1301 or "")
					end
				end
				v_u_769()
			end, "light")
		end
	end)
	local v1302 = v1273 + 1
	local v_u_1303 = v_u_649.label({
		["parent"] = nil,
		["name"] = "ScanLines",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v1269,
		["color"] = v_u_651.text,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_1303.LayoutOrder = v1302
	v_u_1303.RichText = false
	v_u_1303.Visible = false
	v666.section("Restock  \194\183  history")
	local v_u_1304 = v666.note("", v_u_651.text, "RsHistLines")
	v_u_1304.Visible = false
	v731(v666.row(nil, "RsHistRow"), "history", "History", "ghost", 160, function()
		-- upvalues: (ref) v_u_768, (ref) v_u_4, (copy) v_u_652, (copy) v_u_655, (copy) v_u_1304, (ref) v_u_3, (copy) v_u_662, (ref) v_u_767, (copy) p_u_646
		v_u_768.Text = ""
		v_u_768.Visible = false
		if v_u_4 then
			v_u_4:SetAttribute("FilmRestockLiveError", "")
		end
		v_u_652("history", {}, function(p1305)
			-- upvalues: (ref) v_u_655, (ref) v_u_1304, (ref) v_u_3, (ref) v_u_662, (ref) v_u_767, (ref) v_u_768, (ref) p_u_646, (ref) v_u_4
			local v1306, v1307
			if type(p1305) == "table" and p1305.ok == true then
				local v1308 = p1305.data
				if type(v1308) == "table" then
					v_u_655._hist = p1305.data
					v_u_1304.Text = table.concat(v_u_3.historyLines(p1305.data, v_u_662()), "\n")
					v_u_1304.Visible = true
					local v1309 = p1305.msg or ""
					local v1310 = tostring(v1309)
					v_u_767.Text = v1310 or ""
					v_u_767.Visible = (v1310 or "") ~= ""
					if v1310 and v1310 ~= "" then
						v_u_768.Visible = false
						v_u_768.Text = ""
						if p_u_646.handle then
							local v1311 = p_u_646.handle.status
							if type(v1311) == "function" then
								local v1312 = p_u_646.handle.status
								pcall(v1312, v1310)
								return
							end
						end
					end
				else
					v1306 = p1305 and p1305.msg or "The history could not be read."
					v1307 = tostring(v1306)
					v_u_768.Text = v1307 or ""
					v_u_768.Visible = (v1307 or "") ~= ""
					if v1307 and v1307 ~= "" then
						v_u_767.Visible = false
						v_u_767.Text = ""
					end
					if v_u_4 then
						v_u_4:SetAttribute("FilmRestockLiveError", v1307 or "")
					end
				end
			else
				v1306 = p1305 and p1305.msg or "The history could not be read."
				v1307 = tostring(v1306)
				v_u_768.Text = v1307 or ""
				v_u_768.Visible = (v1307 or "") ~= ""
				if v1307 and v1307 ~= "" then
					v_u_767.Visible = false
					v_u_767.Text = ""
				end
				if v_u_4 then
					v_u_4:SetAttribute("FilmRestockLiveError", v1307 or "")
				end
				return
			end
		end, "light")
	end)
	local function v_u_1353() -- name: paintTop
		-- upvalues: (ref) v_u_770, (ref) v_u_3, (copy) v_u_663, (copy) p_u_646, (copy) v_u_832, (copy) v_u_647, (copy) v_u_825, (ref) v_u_771, (copy) v_u_670, (copy) v_u_827, (copy) v_u_741, (copy) v_u_651, (copy) v_u_779, (copy) v_u_742, (copy) v_u_803, (copy) v_u_668, (copy) v_u_655, (copy) v_u_1303
		local v1313 = v_u_770
		local v1314
		if type(v1313) == "table" then
			v1314 = v_u_770.plan
		else
			v1314 = nil
		end
		local v1315 = v_u_3.mode(v_u_770)
		v_u_663.Visible = (v1315 == "planned" or v1315 == "live") and true or v1315 == "held"
		if v1314 == nil then
			return
		end
		local v1316
		if p_u_646.now then
			local v1317 = p_u_646.now
			local v1318
			v1318, v1316 = pcall(v1317)
			if v1318 then
				local v1319
				if type(v1316) == "number" and (v1316 == v1316 and v1316 ~= (1 / 0)) then
					v1319 = v1316 ~= (-1 / 0)
				else
					v1319 = false
				end
				if not v1319 then
					v1316 = os.time()
				end
			else
				v1316 = os.time()
			end
		else
			v1316 = os.time()
		end
		v_u_832.Text = v_u_3.endLine(v1314, v1316)
		local v1320 = v_u_647
		local v1321 = v_u_825.box
		local v1322 = v1320.formatTime(v1314.t0, "berlin") .. " Berlin"
		v_u_771 = true
		v1321.Text = v1322
		v_u_670[v1321] = v1322
		v_u_771 = false
		local v1323 = v_u_827.box
		local v1324 = v1320.durationText(v1314.t1 - v1314.t0)
		v_u_771 = true
		v1323.Text = v1324
		v_u_670[v1323] = v1324
		v_u_771 = false
		local v1325 = v_u_741.n
		local v1326 = v1314.n
		local v1327 = type(v1326) ~= "string" and "" or v1314.n
		if v1325.box.Text == v1325.base or v1325.box.Text == "" then
			local v1328 = v1325.box
			v_u_771 = true
			v1328.Text = v1327
			v_u_670[v1328] = v1327
			v_u_771 = false
		end
		v1325.base = v1327
		for _, v1329 in {
			"mr",
			"ma",
			"mc",
			"mx",
			"pe",
			"wd",
			"lk"
		} do
			local v1330 = v_u_741[v1329]
			local v1331 = v1314[v1329]
			local v1332
			if type(v1331) == "number" and (v1331 == v1331 and v1331 ~= (1 / 0)) then
				v1332 = v1331 ~= (-1 / 0)
			else
				v1332 = false
			end
			local v1333 = not v1332 and "" or tostring(v1331)
			if v1330.box.Text == v1330.base or v1330.box.Text == "" then
				local v1334 = v1330.box
				v_u_771 = true
				v1334.Text = v1333
				v_u_670[v1334] = v1333
				v_u_771 = false
			end
			v1330.base = v1333
		end
		local v1335 = v_u_3.patchOpen(v1314, v1316)
		for _, v1336 in { "pe", "wd" } do
			local v1337 = v_u_741[v1336]
			v1337.box.TextEditable = v1335
			local v1338 = v1337.box
			local v1339
			if v1335 then
				v1339 = v_u_651.text
			else
				v1339 = v_u_651.muted
			end
			v1338.TextColor3 = v1339
			v1337.frame.BackgroundTransparency = v1335 and 0 or 0.55
		end
		v_u_779.Visible = not v1335
		v_u_779.Text = "EXPECTED PLAYERS and DRAW WINDOW can change until 10 minutes before the start."
		if v_u_742.rv == nil or v_u_742.rv == v_u_742.rvBase then
			v_u_742.rv = v1314.rv
		end
		if v_u_742.al == nil or v_u_742.al == v_u_742.alBase then
			v_u_742.al = v1314.al
		end
		local v1340 = v_u_742
		local v1341 = v_u_742
		local v1342 = v1314.rv
		local v1343 = v1314.al
		v1340.rvBase = v1342
		v1341.alBase = v1343
		v_u_803()
		local v1344 = v1314.ho == true
		local v1345 = v_u_668.resumeNow
		if v1345 then
			v1345.enabled = v1344
			v1345.api.setEnabled(v1344)
		end
		local v1346 = v_u_770
		local v1347
		if type(v1346) == "table" then
			local v1348 = v_u_770.jobs
			if type(v1348) == "table" then
				local v1349 = v_u_770.jobs.scan
				v1347 = type(v1349) == "table"
			else
				v1347 = false
			end
		else
			v1347 = false
		end
		if v_u_668.scan then
			v_u_668.scan.enabled = not v1347
			v_u_668.scan.api.setEnabled(not v1347)
			v_u_668.scan.text = not v1347 and "Scan all" or ("Scanning %d / %d"):format(v_u_770.jobs.scan.done or 0, v_u_770.jobs.scan.total or 0)
		end
		if v1347 then
			if p_u_646.setFast then
				p_u_646.setFast(true)
			end
			v_u_655._scanning = true
		elseif v_u_655._scanning then
			v_u_655._scanning = false
			if p_u_646.setFast then
				p_u_646.setFast(false)
			end
		end
		local v1350 = v_u_770
		local v1351
		if type(v1350) == "table" then
			local v1352 = v_u_770.scan
			v1351 = (type(v1352) ~= "table" or v_u_770.scan.rid ~= v1314.r) and {} or v_u_3.scanLines(v_u_770.scan, v1314, v1316)
		else
			v1351 = {}
		end
		v_u_1303.Text = table.concat(v1351, "\n")
		v_u_1303.Visible = #v1351 > 0
	end
	v_u_685 = function()
		-- upvalues: (copy) v_u_1353, (copy) v_u_738, (ref) v_u_1042, (copy) v_u_1268, (ref) v_u_1096
		v_u_1353()
		v_u_738()
		v_u_1042()
		v_u_1268()
		v_u_1096()
	end
	local v_u_1354 = nil
	local function v_u_1360() -- name: resetForNewPlan
		-- upvalues: (copy) v_u_667, (ref) v_u_771, (copy) v_u_670, (copy) v_u_742, (copy) v_u_669, (copy) v_u_686, (copy) v_u_822, (ref) v_u_1092, (ref) v_u_1090, (ref) v_u_1097, (copy) v_u_647, (copy) v_u_1040, (ref) v_u_908, (ref) v_u_768, (ref) v_u_4
		for _, v1355 in v_u_667 do
			v1355.base = ""
			if v1355.box.Text == "" then
				continue
			end
			local v1356 = v1355.box
			v_u_771 = true
			v1356.Text = ""
			v_u_670[v1356] = ""
			v_u_771 = false
		end
		local v1357 = v_u_742
		local v1358 = v_u_742
		local v1359 = v_u_742
		v_u_742.rv = nil
		v1357.al = nil
		v1358.rvBase = nil
		v1359.alBase = nil
		table.clear(v_u_669)
		table.clear(v_u_686)
		v_u_822()
		v_u_1092 = v_u_647.newRow()
		v_u_1090 = nil
		v_u_1097 = ""
		table.clear(v_u_1040)
		v_u_908()
		v_u_768.Text = ""
		v_u_768.Visible = false
		if v_u_4 then
			v_u_4:SetAttribute("FilmRestockLiveError", "")
		end
	end
	function v_u_655.onData(p1361) -- name: onData
		-- upvalues: (ref) v_u_770, (ref) v_u_1354, (copy) v_u_1360, (copy) v_u_1025, (ref) v_u_685
		v_u_770 = p1361
		local v1362 = v_u_770
		local v1363
		if type(v1362) == "table" then
			v1363 = v_u_770.plan
		else
			v1363 = nil
		end
		local v1364
		if type(v1363) == "table" then
			v1364 = v1363.r
		else
			v1364 = nil
		end
		if v1364 ~= nil and (v_u_1354 ~= nil and v1364 ~= v_u_1354) then
			v_u_1360()
		end
		if v1364 ~= nil then
			v_u_1354 = v1364
		end
		local v1365 = v_u_1025
		local v1366
		if type(p1361) == "table" then
			v1366 = p1361.sums
		else
			v1366 = nil
		end
		v1365(v1363, v1366)
		v_u_685()
	end
	if p_u_646.onStatus then
		p_u_646.onStatus(function(p1367)
			-- upvalues: (copy) v_u_655
			v_u_655.onData(p1367)
		end)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_766, (copy) v_u_663, (copy) v_u_664, (copy) v_u_738, (ref) v_u_770, (copy) v_u_832, (ref) v_u_3, (copy) v_u_662, (copy) v_u_1268
		while v_u_766 do
			if v_u_663.Visible or v_u_664.Visible then
				v_u_738()
				if v_u_663.Visible then
					local v1368 = v_u_770
					local v1369
					if type(v1368) == "table" then
						v1369 = v_u_770.plan
					else
						v1369 = nil
					end
					if v1369 ~= nil then
						v_u_832.Text = v_u_3.endLine(v1369, v_u_662())
					end
					v_u_1268()
				end
			end
			task.wait(0.5)
		end
	end)
	function v_u_655.press(p1370) -- name: press
		-- upvalues: (copy) v_u_668
		local v1371 = v_u_668[p1370]
		if v1371 == nil or v1371.enabled == false then
			return false
		end
		v1371.click()
		return true
	end
	function v_u_655.btn(p1372) -- name: btn
		-- upvalues: (copy) v_u_668
		return v_u_668[p1372]
	end
	function v_u_655.pressTwice(p1373, p1374) -- name: pressTwice
		-- upvalues: (copy) v_u_655, (ref) v_u_3
		if not v_u_655.press(p1373) then
			return false
		end
		task.wait(p1374 or v_u_3.CONFIRM_GUARD + 0.1)
		return v_u_655.press(p1373)
	end
	function v_u_655.setField(p1375, p1376) -- name: setField
		-- upvalues: (copy) v_u_741
		local v1377 = v_u_741[p1375]
		if v1377 then
			v1377.box.Text = p1376
		end
	end
	function v_u_655.setRowField(p1378, p1379, p1380) -- name: setRowField
		-- upvalues: (copy) v_u_655
		local v1381 = v_u_655._rowViews[p1378]
		if v1381 then
			if p1379 == "top" then
				v1381.topBox.box.Text = p1380
				return
			end
			v1381.boxes[p1379].box.Text = p1380
		end
	end
	function v_u_655.setChoice(p1382, p1383) -- name: setChoice
		-- upvalues: (copy) v_u_742, (copy) v_u_803, (ref) v_u_1096
		v_u_742[p1382] = p1383
		v_u_803()
		v_u_1096()
	end
	function v_u_655.setAdd(p1384, p1385) -- name: setAdd
		-- upvalues: (ref) v_u_1092, (ref) v_u_1090, (ref) v_u_908
		v_u_1092 = p1384
		v_u_1090 = p1385
		v_u_908()
	end
	function v_u_655.getAdd() -- name: getAdd
		-- upvalues: (ref) v_u_1092
		return v_u_1092
	end
	function v_u_655.setAddField(p1386, p1387) -- name: setAddField
		-- upvalues: (copy) v_u_1041
		if v_u_1041[p1386] then
			v_u_1041[p1386].box.Text = p1387
		end
	end
	function v_u_655.changePatch() -- name: changePatch
		-- upvalues: (copy) v_u_867
		return v_u_867()
	end
	function v_u_655.state() -- name: state
		-- upvalues: (copy) v_u_655, (ref) v_u_3, (ref) v_u_770, (copy) v_u_663, (ref) v_u_767, (ref) v_u_768, (copy) v_u_1303, (copy) v_u_1304, (ref) v_u_1090, (copy) v_u_856, (copy) v_u_669, (copy) v_u_739, (copy) v_u_1228
		local v1388 = {}
		for v1389, v1390 in v_u_655._rowViews do
			v1388[v1389] = {
				["title"] = v1390.title.Text,
				["stats"] = v1390.stats.Text,
				["u"] = v1390.boxes.u.box.Text,
				["c"] = v1390.boxes.c.box.Text
			}
		end
		local v1391 = {
			["mode"] = v_u_3.mode(v_u_770),
			["visible"] = v_u_663.Visible,
			["rows"] = v1388,
			["ok"] = v_u_767.Text,
			["err"] = v_u_768.Text,
			["scan"] = v_u_1303.Text,
			["hist"] = v_u_1304.Text,
			["adding"] = v_u_1090,
			["change"] = v_u_856.Text
		}
		local v1392 = {}
		local v1393 = v_u_669.change
		local v1394
		if v1393 == nil then
			v1394 = false
		else
			v1394 = os.clock() - v1393 < v_u_3.CONFIRM_SECONDS
		end
		v1392.change = v1394
		local v1395 = v_u_669.add
		local v1396
		if v1395 == nil then
			v1396 = false
		else
			v1396 = os.clock() - v1395 < v_u_3.CONFIRM_SECONDS
		end
		v1392.add = v1396
		v1391.confirming = v1392
		v1391.words = {
			["PRICE"] = v_u_739.PRICE,
			["AMOUNT"] = v_u_739.AMOUNT,
			["LONG"] = v_u_739.LONG
		}
		v1391.editCard = v_u_1228.Visible
		return v1391
	end
	function v_u_655.lines() -- name: lines
		-- upvalues: (ref) v_u_3, (ref) v_u_770, (copy) v_u_662
		local v1397 = v_u_3.scanLines
		local v1398 = v_u_770
		local v1399
		if type(v1398) == "table" then
			v1399 = v_u_770.scan
		else
			v1399 = nil
		end
		local v1400 = v_u_770
		local v1401
		if type(v1400) == "table" then
			v1401 = v_u_770.plan
		else
			v1401 = nil
		end
		return v1397(v1399, v1401, v_u_662())
	end
	function v_u_655.refresh() -- name: refresh
		-- upvalues: (copy) p_u_646
		if p_u_646.refresh then
			p_u_646.refresh()
		end
	end
	function v_u_655.clearConfirm() -- name: clearConfirm
		-- upvalues: (copy) v_u_669
		table.clear(v_u_669)
	end
	local v1402
	if p_u_646.status then
		v1402 = p_u_646.status()
	else
		v1402 = nil
	end
	if v1402 == nil then
		v_u_685()
	else
		v_u_655.onData(v1402)
	end
	return v_u_655
end
return v_u_3