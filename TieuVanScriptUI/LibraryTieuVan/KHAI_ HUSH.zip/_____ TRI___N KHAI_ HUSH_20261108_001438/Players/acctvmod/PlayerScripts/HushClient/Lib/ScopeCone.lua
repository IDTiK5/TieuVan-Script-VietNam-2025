-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ScopeCone

local v_u_71 = {
	["TUNE"] = {
		["RANGE_PER_DOUBLING"] = 0.5,
		["RANGE_CAP"] = 110,
		["HALF_BASE"] = 55,
		["HALF_MIN"] = 18,
		["SNIPER_MIN_MAG"] = 1.5,
		["CLASS_K"] = nil,
		["MOVE_SPEED"] = 2.5,
		["MOVE_KEEP"] = 0.35,
		["HALF_IN_RATE"] = 6,
		["HALF_OUT_RATE"] = 8,
		["CAM_FLOOR"] = nil,
		["SHIFT_BY_MAG"] = nil,
		["SHIFT_MAX"] = 26,
		["CLASS_K"] = {
			["sniper"] = 1,
			["rifle"] = 1,
			["mg"] = 0.75,
			["smg"] = 0.5
		},
		["CAM_FLOOR"] = {
			{
				["mag"] = 1.5,
				["dist"] = 132
			},
			{
				["mag"] = 4,
				["dist"] = 176
			}
		},
		["SHIFT_BY_MAG"] = {
			{ 1.5, 14 },
			{ 2, 16 },
			{ 4, 22 },
			{ 6, 26 }
		}
	},
	["k"] = function(p1) -- name: k
		-- upvalues: (copy) v_u_71
		return type(p1) == "string" and (v_u_71.TUNE.CLASS_K[p1] or 0) or 0
	end,
	["mag"] = function(p2, p3) -- name: mag
		-- upvalues: (copy) v_u_71
		local v4 = (type(p2) ~= "number" or (p2 ~= p2 or (p2 == (1 / 0) or p2 == (-1 / 0)))) and 1 or p2
		local v5 = math.max(1, v4)
		if p3 == "sniper" then
			local v6 = v_u_71.TUNE.SNIPER_MIN_MAG
			v5 = math.max(v5, v6)
		end
		return v5
	end,
	["scoped"] = function(p7, p8) -- name: scoped
		-- upvalues: (copy) v_u_71
		local v9
		if v_u_71.k(p8) > 0 then
			v9 = ((type(p7) ~= "number" or (p7 ~= p7 or (p7 == (1 / 0) or p7 == (-1 / 0)))) and 1 or p7) > 1
		else
			v9 = false
		end
		return v9
	end,
	["rangeMul"] = function(p10, p11, p12) -- name: rangeMul
		-- upvalues: (copy) v_u_71
		local v13 = v_u_71.k(p11)
		local v14 = (type(p10) ~= "number" or (p10 ~= p10 or (p10 == (1 / 0) or p10 == (-1 / 0)))) and 1 or p10
		if v13 <= 0 or v14 <= 1 then
			return 1
		end
		local v15 = v_u_71.TUNE
		local v16 = v15.RANGE_PER_DOUBLING * (math.log(v14) / 0.6931471805599453) * v13
		if ((type(p12) ~= "number" or (p12 ~= p12 or (p12 == (1 / 0) or p12 == (-1 / 0)))) and 0 or p12) > v15.MOVE_SPEED then
			v16 = v16 * v15.MOVE_KEEP
		end
		return 1 + v16
	end,
	["range"] = function(p17, p18, p19, p20) -- name: range
		-- upvalues: (copy) v_u_71
		local v21 = (type(p17) ~= "number" or (p17 ~= p17 or (p17 == (1 / 0) or p17 == (-1 / 0)))) and 0 or p17
		local v22 = v21 * v_u_71.rangeMul(p18, p19, p20)
		local v23 = v_u_71.TUNE.RANGE_CAP
		local v24 = math.min(v22, v23)
		return math.max(v21, v24)
	end,
	["halfDeg"] = function(p25, p26) -- name: halfDeg
		-- upvalues: (copy) v_u_71
		local v27 = v_u_71.TUNE
		local v28 = v_u_71.k(p26)
		local v29 = (type(p25) ~= "number" or (p25 ~= p25 or (p25 == (1 / 0) or p25 == (-1 / 0)))) and 1 or p25
		if v28 <= 0 or v29 <= 1 then
			return v27.HALF_BASE
		end
		local v30 = v27.HALF_BASE - (v27.HALF_BASE - v27.HALF_BASE / math.sqrt(v29)) * v28
		local v31 = v27.HALF_MIN
		local v32 = v27.HALF_BASE
		return math.clamp(v30, v31, v32)
	end,
	["camFloor"] = function(p33, p34) -- name: camFloor
		-- upvalues: (copy) v_u_71
		if p34 ~= nil and v_u_71.k(p34) <= 0 then
			return nil
		end
		local v35 = (type(p33) ~= "number" or (p33 ~= p33 or (p33 == (1 / 0) or p33 == (-1 / 0)))) and 1 or p33
		local v36 = nil
		for _, v37 in v_u_71.TUNE.CAM_FLOOR do
			if v37.mag > v35 then
				continue
			end
			v36 = v37.dist
		end
		return v36
	end,
	["shift"] = function(p38, p39) -- name: shift
		-- upvalues: (copy) v_u_71
		local v40 = v_u_71.TUNE
		local v41 = (type(p38) ~= "number" or (p38 ~= p38 or (p38 == (1 / 0) or p38 == (-1 / 0)))) and 1 or p38
		local v42 = 0
		for _, v43 in v40.SHIFT_BY_MAG do
			if v43[1] > v41 then
				continue
			end
			v42 = v43[2]
		end
		local v44 = v40.SHIFT_MAX
		local v45 = (type(p39) ~= "number" or (p39 ~= p39 or (p39 == (1 / 0) or p39 == (-1 / 0)))) and 0 or p39
		local v46 = math.max(0, v45)
		local v47 = math.max(v46, v42)
		return math.min(v44, v47)
	end,
	["blendHalf"] = function(p48, p49, p50) -- name: blendHalf
		-- upvalues: (copy) v_u_71
		local v51 = v_u_71.TUNE
		local v52 = v51.HALF_BASE
		if type(p48) == "number" and (p48 == p48 and (p48 ~= (1 / 0) and p48 ~= (-1 / 0))) then
			v52 = p48
		end
		local v53 = v51.HALF_BASE
		if type(p49) == "number" and (p49 == p49 and (p49 ~= (1 / 0) and p49 ~= (-1 / 0))) then
			v53 = p49
		end
		local v54 = (type(p50) ~= "number" or (p50 ~= p50 or (p50 == (1 / 0) or p50 == (-1 / 0)))) and 0 or p50
		local v55 = math.max(0, v54)
		local v56
		if v53 < v52 then
			v56 = v51.HALF_IN_RATE
		else
			v56 = v51.HALF_OUT_RATE
		end
		local v57 = v53 - v52
		local v58 = v55 * v56
		return v52 + v57 * math.min(1, v58)
	end,
	["active"] = function(p59, p60, p61, p62) -- name: active
		local v63
		if p59 == true and (p60 == true and p61 ~= true) then
			v63 = p62 == true
		else
			v63 = false
		end
		return v63
	end,
	["evaluate"] = function(p64, p65, p66, p67, p68, p69) -- name: evaluate
		-- upvalues: (copy) v_u_71
		local v70 = (type(p67) ~= "number" or (p67 ~= p67 or (p67 == (1 / 0) or p67 == (-1 / 0)))) and 0 or p67
		if p64 == true and v_u_71.scoped(p65, p66) then
			return v_u_71.range(v70, p65, p66, p68), v_u_71.halfDeg(p65, p66), v_u_71.camFloor(p65, p66), v_u_71.shift(p65, p69)
		else
			return v70, v_u_71.TUNE.HALF_BASE, nil, nil
		end
	end
}
return v_u_71