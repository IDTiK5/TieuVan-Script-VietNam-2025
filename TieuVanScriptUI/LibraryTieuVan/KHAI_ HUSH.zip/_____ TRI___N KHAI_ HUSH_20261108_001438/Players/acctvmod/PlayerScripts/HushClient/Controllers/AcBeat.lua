-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / AcBeat

return {
	["name"] = "AcBeat",
	["order"] = 92,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.AcClient.start(p_u_1)
		end)
		if not v2 then
			warn("[AcBeat] the camera heartbeat failed to start:", v3)
			p_u_1.player:SetAttribute("ClientError", "acbeat: " .. tostring(v3))
		end
	end
}