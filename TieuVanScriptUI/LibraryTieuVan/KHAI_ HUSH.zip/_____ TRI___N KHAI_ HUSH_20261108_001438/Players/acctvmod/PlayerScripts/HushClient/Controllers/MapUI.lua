-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / MapUI

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("TextService")
local v_u_6 = {
	["name"] = "MapUI",
	["order"] = 47
}
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = v_u_3.LocalPlayer
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {
	["free"] = 0,
	["top"] = 0,
	["keyH"] = 0,
	["phone"] = false,
	["split"] = false
}
local v_u_17 = false
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = ""
local v_u_21 = 0
local v_u_22 = {}
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = {}
local v_u_26 = {}
local v_u_27 = {
	["cursor"] = nil,
	["cursorOn"] = false,
	["cursorFrame"] = nil,
	["set"] = 0,
	["cleared"] = 0,
	["sig"] = "",
	["CLEAR_PX"] = 18,
	["cursor"] = Vector2.zero
}
local v_u_1772 = nil
local v_u_29 = {
	["seen"] = nil,
	["fetching"] = false,
	["card"] = nil,
	["rect"] = nil,
	["shown"] = 0
}
local v_u_30 = {}
local v_u_31 = {
	["mode"] = "town",
	["mapId"] = "",
	["level"] = "L1",
	["sheets"] = nil,
	["tabsApi"] = nil,
	["holder"] = nil,
	["w"] = 0,
	["h"] = 0,
	["built"] = 0,
	["forceId"] = nil,
	["sheets"] = {}
}
local v_u_32 = {
	["ctl"] = nil
}
local v_u_33 = {
	["bar"] = nil,
	["dirty"] = nil,
	["tok"] = 0,
	["applied"] = nil,
	["conn"] = nil,
	["dirty"] = {},
	["applied"] = {},
	["conn"] = {}
}
local function v_u_44() -- name: toggleState
	-- upvalues: (ref) v_u_7, (copy) v_u_10
	local function v34()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapToggleRule
	end
	local v35, v36 = pcall(v34)
	if not v35 or type(v36) ~= "table" then
		v36 = nil
	end
	if not v36 then
		return {
			["tasks"] = true,
			["labels"] = true
		}
	end
	local v37 = v36.state
	local v38 = v_u_7 and v_u_7.shared
	if v38 then
		v38 = v_u_7.shared.Config
	end
	local v39 = false
	local function v40()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapToggleRule
	end
	local v41, v42 = pcall(v40)
	if not v41 or type(v42) ~= "table" then
		v42 = nil
	end
	if v42 ~= nil then
		if v38 then
			local v43 = v38.flag
			if type(v43) == "function" then
				v38 = v38.flag("MapToggles") == false
			else
				v38 = false
			end
		end
		v39 = not v38
	end
	return v37(v39, v_u_10:GetAttribute(v36.attr.tasks), v_u_10:GetAttribute(v36.attr.labels))
end
local function v_u_50() -- name: hotspotIntel
	-- upvalues: (copy) v_u_10, (ref) v_u_7
	local v45 = v_u_10:FindFirstChildOfClass("PlayerGui")
	if v45 then
		v45 = v45:FindFirstChild("HushHotspotIntel")
	end
	if not v45 then
		return nil
	end
	local v46 = v_u_7
	if v46 then
		v46 = v_u_7.runtime
	end
	if v46 then
		v46 = v46:FindFirstChild("Raid")
	end
	if v46 and v45:GetAttribute("RaidId") ~= v46:GetAttribute("RaidId") then
		return nil
	end
	local v47 = v45:GetAttribute("Title")
	local v48 = v45:GetAttribute("X")
	local v49 = v45:GetAttribute("Z")
	return type(v47) == "string" and (type(v48) == "number" and type(v49) == "number") and {
		["title"] = v47,
		["x"] = v48,
		["z"] = v49,
		["r"] = tonumber(v45:GetAttribute("R")) or 20
	} or nil
end
local function v_u_58() -- name: currentMapId
	-- upvalues: (copy) v_u_31, (ref) v_u_7
	local v51 = v_u_31.forceId
	if type(v51) == "string" then
		return v_u_31.forceId
	end
	local v52 = v_u_7
	if v52 then
		v52 = v_u_7.runtime
	end
	local v53
	if v52 then
		v53 = v52:GetAttribute("MapId")
	else
		v53 = v52
	end
	if type(v53) == "string" and v53 ~= "" then
		return string.lower(v53)
	end
	local function v54()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapInfo.fromRuntime()
	end
	local v55, v56 = pcall(v54)
	if v55 and type(v56) == "table" then
		local v57 = v56.id
		if type(v57) == "string" and v56.id ~= "" then
			return string.lower(v56.id)
		end
	end
	if v52 then
		v52 = v52:FindFirstChild("Raid")
	end
	if v52 then
		v52 = v52:GetAttribute("Map")
	end
	return v52 == "The Hollow" and "hollow" or (v52 == "Kestrel Field" and "kestrel" or (v52 == "Overture Plaza" and "overture" or ((v52 == "???" or (v52 == "ASHGROVE" or v52 == "Ashgrove")) and "unknown5" or "stillwater")))
end
local function v_u_69() -- name: ownMapPx
	-- upvalues: (ref) v_u_13, (copy) v_u_10, (copy) v_u_31, (ref) v_u_7
	local v59 = v_u_13
	if v59 and not v59.noMap then
		local v60 = v59.toPx
		if type(v60) == "function" then
			local v61 = v_u_10.Character
			if v61 then
				v61 = v61:FindFirstChild("HumanoidRootPart")
			end
			if not v61 then
				return nil
			end
			local v62 = v61.Position
			local v63 = v59.inside
			if type(v63) == "function" and not v59.inside(v62.X, v62.Z) then
				return nil
			end
			if v59.hollow then
				local v64 = v62.Y + 2.5
				local v65
				if v_u_31.mode == "hollow" then
					local function v66()
						-- upvalues: (ref) v_u_7
						return v_u_7.shared.HollowLevels
					end
					local v67, v68 = pcall(v66)
					if not v67 or type(v68) ~= "table" then
						v68 = nil
					end
					if v68 then
						v65 = v68.levelOf(v64)
					else
						v65 = nil
					end
				else
					v65 = nil
				end
				if v65 ~= v59.level then
					return nil
				end
			end
			return v59.toPx(v62.X, v62.Z)
		end
	end
	return nil
end
local function v_u_104() -- name: collectEvents
	-- upvalues: (ref) v_u_7, (copy) v_u_2, (copy) v_u_58, (copy) v_u_31
	local v70 = {}
	local v71 = v_u_7
	if v71 then
		v71 = v_u_7.runtime
	end
	if v71 then
		v71 = v71:FindFirstChild("Raid")
	end
	if v71 then
		v71 = v71:FindFirstChild("Events")
	end
	local v_u_72 = nil
	local function v73()
		-- upvalues: (ref) v_u_72, (ref) v_u_7
		v_u_72 = v_u_7.shared.Extracts
	end
	pcall(v73)
	if not (v71 and v_u_72) then
		return v70
	end
	local v74 = v_u_2.now()
	local v75 = v_u_72
	for _, v76 in v71:GetChildren() do
		local v_u_77 = v76:GetAttribute("Kind")
		local v78 = tonumber(v76:GetAttribute("StartAt")) or v74
		local v_u_79 = tonumber(v76:GetAttribute("EndAt")) or v78 + 120
		if v_u_77 == "airdrop" and v76:GetAttribute("Looted") ~= true then
			local function v80()
				-- upvalues: (ref) v_u_7, (ref) v_u_58
				return v_u_7.shared.AirdropRules.skyOk(v_u_58(), nil)
			end
			local v81, v82 = pcall(v80)
			if v81 and v82 == false then
				goto l15
			end
			local v83 = v76:GetAttribute("Position")
			local v_u_84 = tonumber(v76:GetAttribute("LandAt")) or v78
			if typeof(v83) ~= "Vector3" then
				continue
			end
			local v92 = {
				["key"] = nil,
				["kind"] = "airdrop",
				["name"] = "Supply drop",
				["pos"] = nil,
				["color"] = "red",
				["detail"] = nil,
				["key"] = v76.Name,
				["pos"] = v83,
				["detail"] = function() -- name: detail
					-- upvalues: (ref) v_u_2, (copy) v_u_84, (copy) v_u_79
					local v85 = v_u_2.now()
					if v85 < v_u_84 then
						local v86 = v_u_84 - v85 + 0.5
						local v87 = math.floor(v86)
						local v88 = math.max(0, v87)
						return "Lands in " .. string.format("%d:%02d", v88 // 60, v88 % 60)
					end
					if v85 >= v_u_79 then
						return "Loot left"
					end
					local v89 = v_u_79 - v85 + 0.5
					local v90 = math.floor(v89)
					local v91 = math.max(0, v90)
					return "Smoke " .. string.format("%d:%02d", v91 // 60, v91 % 60)
				end
			}
			table.insert(v70, v92)
		else
			::l15::
			if v_u_77 ~= "helicopter" and v_u_77 ~= "horde" or v74 >= v_u_79 then
				continue
			end
			local v93 = v75.decodePath((v76:GetAttribute("Path")))
			if #v93 < 2 then
				continue
			end
			local v_u_94 = v_u_31.mode == "field"
			local v_u_95 = v_u_31.mapId == "unknown5"
			local v_u_96 = v_u_31.mapId == "overture"
			local v101 = {
				["key"] = v76.Name,
				["kind"] = v_u_77,
				["name"] = v_u_77 == "horde" and (v_u_95 and "Pithead horde" or (v_u_96 and "Audience horde" or (v_u_94 and "Quarantine horde" or "School horde"))) or "Helicopter",
				["path"] = v93,
				["color"] = v_u_77 == "horde" and "red" or "ink",
				["detail"] = function() -- name: detail
					-- upvalues: (copy) v_u_77, (copy) v_u_95, (copy) v_u_96, (copy) v_u_94, (copy) v_u_79, (ref) v_u_2
					if v_u_77 == "horde" then
						return v_u_95 and "Pouring out of the wash house" or (v_u_96 and "Filing out of the Shell" or (v_u_94 and "Breaking out of the hangars" or "Rolling toward Main St"))
					end
					local v97 = v_u_94 and "Over the field  " or "Over town  "
					local v98 = v_u_79 - v_u_2.now() + 0.5
					local v99 = math.floor(v98)
					local v100 = math.max(0, v99)
					return v97 .. string.format("%d:%02d", v100 // 60, v100 % 60)
				end
			}
			table.insert(v70, v101)
		end
	end
	table.sort(v70, function(p102, p103)
		return p102.key < p103.key
	end)
	return v70
end
local function v_u_134() -- name: collectMarks
	-- upvalues: (copy) v_u_31, (ref) v_u_7, (copy) v_u_10
	local v_u_105 = {}
	local function v127(p106, p107) -- name: add
		-- upvalues: (ref) v_u_31, (ref) v_u_7, (copy) v_u_105
		if p106:IsA("BasePart") and p106:GetAttribute("Open") == true then
			local v108 = p106:GetAttribute("ExtractId") or p106.Name
			local v109 = tostring(v108)
			local v110 = p106:GetAttribute("Condition") or ""
			local v111 = tostring(v110)
			local v112 = v111 == "" and (v109 == "roadblock" and "Always open" or "Open") or v111
			local v113 = p106:GetAttribute("State")
			local v114 = nil
			local v115
			if type(v113) == "string" and (v113 ~= "" and not ({
				["idle"] = true,
				["ready"] = true,
				["open"] = true
			})[string.lower(v113)]) then
				v112 = v112 .. "  \194\183  " .. string.upper((string.sub(v113, 1, 1))) .. string.sub(v113, 2)
				v115 = p106:GetAttribute("StateEndsAt")
				if type(v115) == "number" then
					if v115 <= 0 then
						v115 = v114
					end
				else
					v115 = v114
				end
			else
				v115 = v114
			end
			local v116
			if v_u_31.mode == "hollow" then
				local function v117()
					-- upvalues: (ref) v_u_7
					return v_u_7.lib.HollowMapDraw
				end
				local v118, v119 = pcall(v117)
				v116 = v118 and v119 and v119.levelOfExtract(v109)
				if not v116 then
					local v120 = p106.Position.Y
					if v_u_31.mode == "hollow" then
						local function v121()
							-- upvalues: (ref) v_u_7
							return v_u_7.shared.HollowLevels
						end
						local v122, v123 = pcall(v121)
						if not v122 or type(v123) ~= "table" then
							v123 = nil
						end
						if v123 then
							v116 = v123.levelOf(v120)
						else
							v116 = nil
						end
					else
						v116 = nil
					end
				end
			else
				v116 = nil
			end
			local v124 = v_u_105
			local v125 = {
				["id"] = v109
			}
			local v126 = p106:GetAttribute("Name") or v109
			v125.name = tostring(v126)
			v125.cond = v112
			v125.pos = p106.Position
			v125.size = p106.Size
			v125.personal = p107
			v125.ends = v115
			v125.level = v116
			table.insert(v124, v125)
		end
	end
	local v128 = v_u_7
	if v128 then
		v128 = v_u_7.runtime
	end
	if v128 then
		v128 = v128:FindFirstChild("Raid")
	end
	if v128 then
		v128 = v128:FindFirstChild("Extracts")
	end
	if v128 then
		for _, v129 in v128:GetChildren() do
			v127(v129, false)
		end
	end
	local v130 = v_u_10:FindFirstChildOfClass("PlayerGui")
	if v130 then
		v130 = v130:FindFirstChild("HushPersonalExtracts")
	end
	if v130 then
		for _, v131 in v130:GetChildren() do
			v127(v131, true)
		end
	end
	table.sort(v_u_105, function(p132, p133)
		if p132.id == "roadblock" == (p133.id == "roadblock") then
			return p132.name < p133.name
		else
			return p132.id == "roadblock"
		end
	end)
	return v_u_105
end
local function v_u_151(p135) -- name: signature
	-- upvalues: (copy) v_u_104, (copy) v_u_50, (copy) v_u_44, (ref) v_u_7, (copy) v_u_10
	local v136 = {}
	for _, v137 in p135 do
		local v138 = v137.id .. "|" .. v137.cond
		table.insert(v136, v138)
	end
	table.insert(v136, "#ev")
	for _, v139 in v_u_104() do
		local v140 = v139.key
		table.insert(v136, v140)
	end
	local v141 = v_u_50()
	local v142 = "#hot" .. (not v141 and "" or v141.title)
	table.insert(v136, v142)
	local v143 = v_u_44()
	local v144 = "#tg" .. (v143.tasks and "T" or "t") .. (v143.labels and "L" or "l")
	table.insert(v136, v144)
	local v145 = v_u_7 and v_u_7.shared
	if v145 then
		v145 = v_u_7.shared.Config
	end
	if v145 then
		local v146 = v145.flag
		if type(v146) == "function" then
			v145 = v145.flag("MapTaskDrop") == false
		else
			v145 = false
		end
	end
	if not v145 then
		local function v147()
			-- upvalues: (ref) v_u_7, (ref) v_u_10
			return v_u_7.lib.MapTaskList.structSig(v_u_10:GetAttribute("TaskPlaces"), v_u_10:GetAttribute("TaskDetail"))
		end
		local v148, v149 = pcall(v147)
		local v150 = "#tk" .. (not v148 and "" or v149)
		table.insert(v136, v150)
	end
	return table.concat(v136, ";")
end
local function v_u_155(p_u_152, p_u_153) -- name: addLive
	-- upvalues: (copy) v_u_30
	local v154 = v_u_30
	table.insert(v154, { p_u_152, p_u_153 })
	pcall(function()
		-- upvalues: (copy) p_u_152, (copy) p_u_153
		p_u_152.Text = p_u_153()
	end)
end
local function v_u_161() -- name: refreshLive
	-- upvalues: (copy) v_u_30
	for _, v156 in v_u_30 do
		local v157 = v156[1]
		if not v157.Parent then
			continue
		end
		local v158 = v156[2]
		local v159, v160 = pcall(v158)
		if not v159 or (type(v160) ~= "string" or v157.Text == v160) then
			continue
		end
		v157.Text = v160
	end
end
local v_u_162 = nil
local v_u_163 = nil
local v_u_164 = nil
local function v_u_179(p165) -- name: ping
	-- upvalues: (ref) v_u_7, (copy) v_u_26, (copy) v_u_25, (ref) v_u_8, (copy) v_u_10, (ref) v_u_17, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151, (ref) v_u_162
	local v166 = v_u_7 and v_u_7.controllers
	if v166 then
		v166 = v_u_7.controllers.Comms
	end
	local v167 = false
	local v168 = false
	if v166 then
		local v169 = v166.extractPing
		if type(v169) == "function" and not p165.personal then
			local v170 = v166.extractPing
			local v171
			v168, v171 = pcall(v170)
			if v168 then
				v168 = v171 == p165.id
			end
		end
	end
	if v166 then
		local v172 = v166.pingExtract
		if type(v172) == "function" and not p165.personal then
			local v173 = v166.pingExtract
			local v174 = p165.id
			v167 = pcall(v173, v174)
		end
	end
	if not v167 and v166 then
		local v175 = v166.pingAt
		if type(v175) == "function" then
			local v176 = v166.pingAt
			local v177 = p165.pos
			pcall(v176, "extract", v177)
		end
	end
	if v168 then
		v_u_26[p165.id] = os.clock() + 2.5
		v_u_25[p165.id] = nil
	else
		v_u_25[p165.id] = os.clock() + 2.5
		v_u_26[p165.id] = nil
	end
	if v_u_8 then
		v_u_8.sound("click")
	end
	v_u_10:SetAttribute("MapLastPing", p165.id)
	task.defer(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_162
		if v_u_17 then
			local v178 = v_u_134()
			v_u_20 = v_u_151(v178)
			v_u_162(v178)
		end
	end)
end
local v_u_180 = Color3.fromHex("2F5C8A")
local v_u_181 = Color3.fromRGB(46, 128, 214)
local function v_u_188(p182, p183) -- name: groundAt
	-- upvalues: (copy) v_u_10
	local v184 = RaycastParams.new()
	v184.FilterType = Enum.RaycastFilterType.Exclude
	local v185 = {}
	if v_u_10.Character then
		local v186 = v_u_10.Character
		table.insert(v185, v186)
	end
	v184.FilterDescendantsInstances = v185
	local v187 = workspace:Raycast(Vector3.new(p182, 400, p183), Vector3.new(0, -500, 0), v184)
	return not v187 and 1 or v187.Position.Y + 0.5
end
local function v_u_222(p189) -- name: waypointAtPx
	-- upvalues: (ref) v_u_13, (ref) v_u_7, (copy) v_u_31, (copy) v_u_27, (copy) v_u_10, (ref) v_u_17, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151, (ref) v_u_162, (copy) v_u_188, (ref) v_u_8
	if not (v_u_13 and v_u_13.toWorld) then
		return "no sheet"
	end
	local v190 = v_u_7 and v_u_7.controllers
	if v190 then
		v190 = v_u_7.controllers.Comms
	end
	if v190 then
		local v191 = v190.setWaypoint
		if type(v191) == "function" then
			if v_u_13.noMap then
				return "no map"
			end
			local v192 = Vector2.new
			local v193 = p189.X
			local v194 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
			local v195 = math.clamp(v193, 0, v194)
			local v196 = p189.Y
			local v197 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
			local v198 = v192(v195, (math.clamp(v196, 0, v197)))
			local v199 = v190.waypoint
			local v200
			if type(v199) == "function" then
				v200 = v190.waypoint()
			else
				v200 = nil
			end
			if v200 and v_u_13.hollow then
				local v201 = v200.Y + 2.5
				local v202
				if v_u_31.mode == "hollow" then
					local function v203()
						-- upvalues: (ref) v_u_7
						return v_u_7.shared.HollowLevels
					end
					local v204, v205 = pcall(v203)
					if not v204 or type(v205) ~= "table" then
						v205 = nil
					end
					if v205 then
						v202 = v205.levelOf(v201)
					else
						v202 = nil
					end
				else
					v202 = nil
				end
				if v202 ~= v_u_13.level then
					v200 = nil
				end
			end
			if v200 then
				local v206 = (v_u_13.toPx(v200.X, v200.Z) - v198).Magnitude
				local v207 = v_u_27.CLEAR_PX
				local v208 = v_u_13.k or 1
				if v206 <= v207 * math.max(v208, 0.6) then
					local v209 = v190.clearWaypoint
					pcall(v209)
					local v210 = v_u_27
					v210.cleared = v210.cleared + 1
					v_u_10:SetAttribute("MapLastWaypoint", "cleared")
					task.defer(function()
						-- upvalues: (ref) v_u_17, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_162
						if v_u_17 then
							local v211 = v_u_134()
							v_u_20 = v_u_151(v211)
							v_u_162(v211)
						end
					end)
					return "cleared"
				end
			end
			local v212 = v_u_13.toWorld(v198.X, v198.Y)
			local v213 = v212.X
			local v214
			if v_u_13.hollow then
				v214 = v_u_13.floorY + 0.5
			else
				v214 = v_u_188(v212.X, v212.Y)
			end
			local v215 = v212.Y
			local v216 = Vector3.new(v213, v214, v215)
			local v217 = v190.setWaypoint
			local v218, v219 = pcall(v217, v216)
			if not (v218 and v219) then
				return "refused"
			end
			local v220 = v_u_27
			v220.set = v220.set + 1
			v_u_10:SetAttribute("MapLastWaypoint", ("%.0f,%.0f"):format(v216.X, v216.Z))
			v_u_8.sound("click")
			task.defer(function()
				-- upvalues: (ref) v_u_17, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_162
				if v_u_17 then
					local v221 = v_u_134()
					v_u_20 = v_u_151(v221)
					v_u_162(v221)
				end
			end)
			return ("set %.0f,%.0f"):format(v216.X, v216.Z)
		end
	end
	return "no comms"
end
function v_u_6.waypointAt(p223, p224) -- name: waypointAt
	-- upvalues: (ref) v_u_13, (copy) v_u_222
	return not v_u_13 and "no sheet" or v_u_222(Vector2.new(p223 * (not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)), p224 * (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0))))
end
local function v_u_235() -- name: waypointSig
	-- upvalues: (ref) v_u_7
	local v225 = v_u_7 and v_u_7.controllers
	if v225 then
		v225 = v_u_7.controllers.Comms
	end
	if v225 then
		local v226 = v225.waypoints
		if type(v226) == "function" then
			local v227 = v225.waypoints
			local v228, v229 = pcall(v227)
			if not v228 or type(v229) ~= "table" then
				return ""
			end
			local v230 = {}
			for _, v231 in v229 do
				local v232 = v231.from
				local v233 = v231.pos.X
				local v234 = v231.pos.Z
				table.insert(v230, ("%d:%.0f:%.0f"):format(v232, v233, v234))
			end
			table.sort(v230)
			return table.concat(v230, "|")
		end
	end
	return ""
end
local function v_u_239() -- name: cursorFrame
	-- upvalues: (copy) v_u_27, (ref) v_u_13, (ref) v_u_8, (copy) v_u_180
	if v_u_27.cursorFrame and v_u_27.cursorFrame.Parent then
		return v_u_27.cursorFrame
	end
	if not (v_u_13 and v_u_13.area) then
		return nil
	end
	local v236 = v_u_8.new("Frame", {
		["Name"] = "PadCursor",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(30, 30)
	}, v_u_13.area)
	for _, v237 in { Vector2.new(30, 2), Vector2.new(2, 30) } do
		v_u_8.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_180,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(v237.X, v237.Y)
		}, v236)
	end
	local v238 = v_u_8.new("Frame", {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(16, 16)
	}, v236)
	v_u_8.new("UICorner", {
		["CornerRadius"] = UDim.new(0.5, 0)
	}, v238)
	v_u_8.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["BorderStrokePosition"] = nil,
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
		["Color"] = v_u_180
	}, v238)
	v_u_27.cursorFrame = v236
	return v236
end
local function v_u_242() -- name: destroyGui
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (copy) v_u_16, (copy) v_u_33, (ref) v_u_7, (copy) v_u_31, (copy) v_u_32, (copy) v_u_27, (copy) v_u_22, (copy) v_u_30, (ref) v_u_20
	if v_u_11 then
		v_u_11:Destroy()
	end
	v_u_11 = nil
	v_u_12 = nil
	v_u_13 = nil
	v_u_14 = nil
	v_u_15 = nil
	v_u_16.split = false
	v_u_33.bar = nil
	table.clear(v_u_33.applied)
	local function v240()
		-- upvalues: (ref) v_u_7
		v_u_7.lib.MapTaskList.reset()
	end
	pcall(v240)
	table.clear(v_u_31.sheets)
	v_u_31.tabsApi = nil
	v_u_31.holder = nil
	if v_u_32.ctl then
		local v241 = v_u_32.ctl.destroy
		pcall(v241)
		v_u_32.ctl = nil
	end
	v_u_27.cursorFrame = nil
	v_u_27.cursorOn = false
	table.clear(v_u_22)
	table.clear(v_u_30)
	v_u_20 = ""
end
local function v_u_255(p243, p244, p245, p246, p247, p248) -- name: seg
	-- upvalues: (ref) v_u_8
	local v249 = p245 - p244
	local v250 = v_u_8.new
	local v251 = {
		["Name"] = "Seg",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["ZIndex"] = nil,
		["BackgroundColor3"] = p247,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset((p244.X + p245.X) / 2, (p244.Y + p245.Y) / 2),
		["Size"] = UDim2.fromOffset(v249.Magnitude + p246 * 0.5, p246)
	}
	local v252 = v249.Y
	local v253 = v249.X
	local v254 = math.atan2(v252, v253)
	v251.Rotation = math.deg(v254)
	v251.ZIndex = p248
	return v250("Frame", v251, p243)
end
local function v_u_265(p256, p257, p258, p259, p260, p261, p262) -- name: arrowHead
	-- upvalues: (copy) v_u_255
	if p258.Magnitude >= 0.001 then
		local v263 = p258.Unit
		local v264 = Vector2.new(-v263.Y, v263.X)
		v_u_255(p256, p257, p257 - v263 * p259 + v264 * p259 * 0.6, p260, p261, p262)
		v_u_255(p256, p257, p257 - v263 * p259 - v264 * p259 * 0.6, p260, p261, p262)
	end
end
local v_u_266 = {
	["used"] = nil,
	["chips"] = nil,
	["tags"] = nil,
	["hidden"] = nil,
	["tmp"] = nil,
	["layer"] = nil,
	["stats"] = nil,
	["chips"] = {},
	["tags"] = {},
	["hidden"] = {},
	["tmp"] = {},
	["stats"] = {
		["clean"] = 0,
		["soft"] = 0,
		["forced"] = 0,
		["hid"] = 0
	}
}
local function v_u_272() -- name: cleanOn
	-- upvalues: (ref) v_u_7
	local v267 = v_u_7 and v_u_7.shared
	if v267 then
		v267 = v_u_7.shared.Config
	end
	if v267 then
		local v268 = v267.flag
		if type(v268) == "function" and v267.flag("MapLabelClean") == false then
			return false
		end
	end
	local function v269()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapTagPlace
	end
	local v270, v271 = pcall(v269)
	if v270 then
		v270 = type(v271) == "table"
	end
	return v270
end
local function v_u_281(p273, p274, p275) -- name: hideSoftUnder
	-- upvalues: (ref) v_u_7
	local v276 = v_u_7.shared.MapTagPlace
	local v277 = 0
	for v278 = #p273, 1, -1 do
		local v279 = p273[v278]
		local v280 = v279[6]
		if not v280 or v276.overlapArea(p274, v279, 1) <= 0 then
			continue
		end
		if v280.obj and v280.obj.Parent then
			v280.obj.Visible = false
		end
		if p275 then
			table.insert(p275, v279)
		end
		table.remove(p273, v278)
		v277 = v277 + 1
	end
	return v277
end
local function v_u_296() -- name: applyToggles
	-- upvalues: (copy) v_u_44, (ref) v_u_7, (copy) v_u_33, (copy) v_u_31, (ref) v_u_13
	local v282 = v_u_44()
	local function v283()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.MapTaskList.openId()
	end
	local v284, v_u_285 = pcall(v283)
	if not v284 or type(v_u_285) ~= "string" then
		v_u_285 = nil
	end
	if v_u_33.bar then
		v_u_33.bar.refresh()
	end
	local v286 = {}
	for _, v287 in v_u_31.sheets do
		table.insert(v286, v287)
	end
	if v_u_13 and not table.find(v286, v_u_13) then
		local v288 = v_u_13
		table.insert(v286, v288)
	end
	for _, v289 in v286 do
		local v290 = v289.labelLayer
		if v290 and v290.Parent then
			v290.Visible = v282.labels
		end
		if v289.nameLabels then
			for _, v291 in v289.nameLabels do
				if not v291.Parent or v291.Visible == v282.labels then
					continue
				end
				v291.Visible = v282.labels
			end
		end
		local v292 = v289.setObjectiveFilter
		if type(v292) ~= "function" then
			continue
		end
		local v293 = v282.tasks and "all" or "sel:" .. tostring(v_u_285)
		if v_u_33.applied[v289] == v293 then
			continue
		end
		v_u_33.applied[v289] = v293
		if v282.tasks then
			v289.setObjectiveFilter(nil)
		else
			v289.setObjectiveFilter(function(p294)
				-- upvalues: (copy) v_u_285
				local v295
				if v_u_285 == nil or type(p294) ~= "table" then
					v295 = false
				else
					v295 = p294.id == v_u_285
				end
				return v295
			end)
		end
	end
end
local function v_u_316(p297, p298, p299, p300, p301, p302, p303, p304) -- name: placeClean
	-- upvalues: (ref) v_u_7, (ref) v_u_13, (copy) v_u_266, (copy) v_u_281, (copy) v_u_255, (ref) v_u_8
	local v305 = v_u_7.shared.MapTagPlace
	local v306 = v305.pick({
		["anchor"] = nil,
		["sizes"] = nil,
		["W"] = nil,
		["H"] = nil,
		["edge"] = 4,
		["gap"] = 3,
		["rings"] = nil,
		["fixed"] = nil,
		["anchor"] = p299,
		["sizes"] = p300,
		["W"] = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0),
		["H"] = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0),
		["rings"] = p303 or 6,
		["fixed"] = p297
	})
	local v307 = {
		v306.x,
		v306.y,
		v306.x + v306.w,
		v306.y + v306.h
	}
	local v308 = v_u_266.stats
	v308.hid = v308.hid + v_u_281(p297, v307)
	v_u_266.stats[v306.quality] = (v_u_266.stats[v306.quality] or 0) + 1
	local v309 = {
		v307[1],
		v307[2],
		v307[3],
		v307[4],
		p301
	}
	table.insert(p297, v309)
	if v305.needsLeader(p299, v306.x, v306.y, v306.w, v306.h, 3) then
		local v310 = p304 and {
			p304.X,
			p304.Y,
			p304.X,
			p304.Y
		} or p299
		local v311, v312, v313, v314 = v305.leader(v310, v306.x, v306.y, v306.w, v306.h)
		v_u_255(p298, Vector2.new(v311, v312), Vector2.new(v313, v314), 1, p302, 3).Name = "Leader"
		if p304 then
			local v315 = v_u_8.new("Frame", {
				["Name"] = "LeaderDot",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = p302,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v311, v312),
				["Size"] = UDim2.fromOffset(4, 4)
			}, p298)
			v_u_8.new("UICorner", {
				["CornerRadius"] = UDim.new(0.5, 0)
			}, v315)
		end
	end
	return v306
end
local function v_u_444(p_u_317, p_u_318)
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_8, (copy) v_u_104, (ref) v_u_9, (copy) v_u_272, (copy) v_u_316, (copy) v_u_155, (copy) v_u_255, (copy) v_u_265, (ref) v_u_7
	if v_u_13 and v_u_14 then
		local v319 = not v_u_13.area and v_u_13.marks
		if v319 then
			v319 = v_u_13.marks.Parent
		end
		if v319 then
			local v320 = v319:FindFirstChild("EventMarks")
			if v320 then
				v320:Destroy()
			end
			local v_u_321 = v_u_8.new("Frame", {
				["Name"] = "EventMarks",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 11,
				["Size"] = UDim2.fromScale(1, 1)
			}, v319)
			if v_u_13.noMap or v_u_13.hollow and v_u_13.level ~= "L0" then
				return
			else
				local v322 = v_u_104()
				if #v322 ~= 0 then
					local v_u_323 = v_u_13.ink
					local v_u_324 = v_u_13.k
					local _ = v_u_13.inner
					local v_u_325 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
					local v_u_326 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
					local v_u_327 = v_u_9.color
					local v_u_328 = v_u_9.isPhone()
					local v_u_329 = v_u_9.font.headingBold
					local v_u_330 = v_u_9.font.body
					local v331 = v_u_324 * 13 + 0.5
					local v332 = math.floor(v331)
					local v333 = math.max(11, v332)
					local v_u_334
					if v_u_9 then
						v_u_334 = v_u_9.phoneText(v333, "text")
					else
						v_u_334 = v333
					end
					local v_u_335 = v_u_334 / v333
					local function v377(p336, p_u_337, p338) -- name: tagAt
						-- upvalues: (copy) v_u_324, (copy) v_u_335, (copy) v_u_328, (copy) v_u_334, (ref) v_u_272, (ref) v_u_316, (copy) p_u_317, (copy) v_u_321, (copy) v_u_323, (copy) v_u_325, (copy) v_u_326, (copy) p_u_318, (ref) v_u_8, (copy) v_u_329, (ref) v_u_155, (copy) v_u_330
						local v339 = v_u_324 * 150
						local v340 = math.max(v339, 112) * v_u_335
						local v341 = math.floor(v340)
						local v342
						if v_u_328 then
							v342 = v_u_334 + 7
						else
							local v343 = v_u_324 * 34
							local v344 = math.max(v343, 30)
							v342 = math.floor(v344)
						end
						local v345 = 0
						local v346 = 0
						local v347 = (1 / 0)
						if v_u_272() then
							local v348 = v_u_316(p_u_317, v_u_321, {
								p336.X - v_u_324 * 12,
								p336.Y - v_u_324 * 12,
								p336.X + v_u_324 * 12,
								p336.Y + v_u_324 * 12
							}, {
								{ v341, v342 }
							}, 4, v_u_323.inkSoft)
							v345 = v348.x
							v346 = v348.y
						else
							for v349, v350 in {
								{ p336.X + v_u_324 * 14, p336.Y - v342 / 2 },
								{ p336.X - v_u_324 * 14 - v341, p336.Y - v342 / 2 },
								{ p336.X - v341 / 2, p336.Y + v_u_324 * 14 },
								{ p336.X - v341 / 2, p336.Y - v_u_324 * 14 - v342 }
							} do
								local v351 = v350[1]
								local v352 = v_u_325 - v341 - 4
								local v353 = math.clamp(v351, 4, v352)
								local v354 = v350[2]
								local v355 = v_u_326 - v342 - 4
								local v356 = math.clamp(v354, 4, v355)
								local v357 = p_u_318(v353, v356, v353 + v341, v356 + v342) + v349 * 0.01
								if v357 >= v347 then
									continue
								end
								v346 = v356
								v345 = v353
								v347 = v357
							end
							local v358 = p_u_317
							local v359 = {
								v345,
								v346,
								v345 + v341,
								v346 + v342,
								4
							}
							table.insert(v358, v359)
						end
						local v360 = v_u_8.new("Frame", {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.04,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 4,
							["Name"] = "EvTag_" .. p_u_337.key,
							["BackgroundColor3"] = v_u_323.paperLight,
							["Position"] = UDim2.fromOffset(v345, v346),
							["Size"] = UDim2.fromOffset(v341, v342)
						}, v_u_321)
						v_u_8.new("UIStroke", {
							["ApplyStrokeMode"] = nil,
							["BorderStrokePosition"] = nil,
							["Color"] = nil,
							["Thickness"] = 1,
							["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
							["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
							["Color"] = p338
						}, v360)
						local v361 = v_u_8.new
						local v362 = "TextLabel"
						local v363 = {
							["Name"] = "Name",
							["BackgroundTransparency"] = 1,
							["Position"] = nil,
							["Size"] = nil,
							["FontFace"] = nil,
							["TextSize"] = nil,
							["TextColor3"] = nil,
							["TextXAlignment"] = nil,
							["TextTruncate"] = nil,
							["Text"] = nil,
							["ZIndex"] = 5,
							["Position"] = UDim2.fromOffset(5, v_u_328 and 0 or 2)
						}
						local v364
						if v_u_328 then
							v364 = UDim2.new(1, -8, 1, 0)
						else
							local v365 = UDim2.new
							local v366 = v_u_324 * 16
							v364 = v365(1, -8, 0, (math.max(v366, 14)))
						end
						v363.Size = v364
						v363.FontFace = v_u_329
						v363.TextSize = v_u_334
						v363.TextColor3 = p338
						v363.TextXAlignment = Enum.TextXAlignment.Left
						v363.TextTruncate = Enum.TextTruncate.AtEnd
						v363.Text = string.upper(p_u_337.name)
						local v367 = v361(v362, v363, v360)
						if v_u_328 then
							if p_u_337.kind == "airdrop" then
								v_u_155(v367, function()
									-- upvalues: (copy) p_u_337
									local v368 = string.match(p_u_337.detail(), "(%d+:%d%d)")
									return string.upper(p_u_337.name) .. (not v368 and "" or " " .. v368)
								end)
								return
							end
						else
							local v369 = v_u_8.new
							local v370 = {
								["Name"] = "Cond",
								["BackgroundTransparency"] = 1,
								["Position"] = nil,
								["Size"] = nil,
								["FontFace"] = nil,
								["TextSize"] = nil,
								["TextColor3"] = nil,
								["TextXAlignment"] = nil,
								["TextTruncate"] = nil,
								["Text"] = "",
								["ZIndex"] = 5
							}
							local v371 = UDim2.fromOffset
							local v372 = v_u_324 * 16
							v370.Position = v371(5, (math.max(v372, 14)))
							local v373 = UDim2.new
							local v374 = v_u_324 * 14
							v370.Size = v373(1, -8, 0, (math.max(v374, 12)))
							v370.FontFace = v_u_330
							local v375 = v_u_324 * 11 + 0.5
							local v376 = math.floor(v375)
							v370.TextSize = math.max(10, v376)
							v370.TextColor3 = v_u_323.inkSoft
							v370.TextXAlignment = Enum.TextXAlignment.Left
							v370.TextTruncate = Enum.TextTruncate.AtEnd
							v_u_155(v369("TextLabel", v370, v360), p_u_337.detail)
						end
					end
					for _, v378 in v322 do
						local v379
						if v378.color == "red" then
							v379 = v_u_323.red
						else
							v379 = v_u_323.ink
						end
						if v378.kind == "airdrop" and v378.pos then
							local v380 = v378.pos
							local v381 = v_u_13.toPx(v380.X, v380.Z)
							local v382 = v_u_324 * 22
							local v383 = math.max(16, v382)
							local v384 = v_u_324 * 3.5 + 0.5
							local v385 = math.floor(v384)
							local v386 = math.max(3, v385)
							for _, v387 in { 45, -45 } do
								v_u_8.new("Frame", {
									["Name"] = "X",
									["BackgroundColor3"] = nil,
									["BorderSizePixel"] = 0,
									["AnchorPoint"] = nil,
									["Position"] = nil,
									["Size"] = nil,
									["Rotation"] = nil,
									["ZIndex"] = 3,
									["BackgroundColor3"] = v_u_323.red,
									["AnchorPoint"] = Vector2.new(0.5, 0.5),
									["Position"] = UDim2.fromOffset(v381.X, v381.Y),
									["Size"] = UDim2.fromOffset(v383, v386),
									["Rotation"] = v387
								}, v_u_321)
							end
							local v388 = {
								v381.X - v383 / 2,
								v381.Y - v383 / 2,
								v381.X + v383 / 2,
								v381.Y + v383 / 2,
								3
							}
							table.insert(p_u_317, v388)
							v377(v381, v378, v_u_323.red)
						else
							if not v378.path then
								continue
							end
							local v389 = {}
							for _, v390 in v378.path do
								local v391 = v_u_13.toPx
								local v392 = v390.X
								local v393 = v390.Z
								table.insert(v389, v391(v392, v393))
							end
							local v394 = v378.kind == "horde"
							local v395
							if v394 then
								local v396 = v_u_324 * 5 + 0.5
								local v397 = math.floor(v396)
								v395 = math.max(4, v397)
							else
								local v398 = v_u_324 * 2 + 0.5
								local v399 = math.floor(v398)
								v395 = math.max(2, v399)
							end
							for v400 = 1, #v389 - 1 do
								local v401 = v389[v400]
								local v402 = v389[v400 + 1]
								if v394 then
									v_u_255(v_u_321, v401, v402, v395, v379, 2)
								else
									local v403 = v402 - v401
									local v404 = v403.Magnitude
									if v404 <= 1 then
										continue
									end
									local v405 = v403 / v404
									local v406 = v_u_324 * 9
									local v407 = v_u_324 * 7
									local v408 = 0
									while v408 < v404 do
										local v409 = v408 + v406
										local v410 = math.min(v404, v409)
										v_u_255(v_u_321, v401 + v405 * v408, v401 + v405 * v410, v395, v379, 2)
										v408 = v410 + v407
									end
								end
							end
							local v411 = #v389
							if v394 then
								local v412 = v_u_265
								local v413 = v389[v411]
								local v414 = v389[v411] - v389[v411 - 1]
								local v415 = v_u_324 * 18
								v412(v_u_321, v413, v414, math.max(14, v415), v395, v379, 2)
								v377(v389[1], v378, v379)
							else
								local v416 = #v389 / 2
								local v417 = math.floor(v416) + 1
								local v418 = math.max(2, v417)
								local v419 = v389[v418 - 1]
								local v420 = v389[v418]
								local v421 = v419:Lerp(v420, 0.6)
								local v422 = v_u_265
								local v423 = v420 - v419
								local v424 = v_u_324 * 14
								v422(v_u_321, v421, v423, math.max(12, v424), math.max(2, v395), v379, 2)
								local v425 = Vector2.new
								local v426 = v421.X
								local v427 = v_u_325 - 30
								local v428 = math.clamp(v426, 30, v427)
								local v429 = v421.Y
								local v430 = v_u_326 - 30
								v377(v425(v428, (math.clamp(v429, 30, v430))), v378, v379)
							end
						end
					end
					v_u_8.label({
						["parent"] = nil,
						["text"] = "Events",
						["style"] = "caps",
						["textSize"] = 13,
						["color"] = nil,
						["size"] = nil,
						["valign"] = "bottom",
						["track"] = false,
						["parent"] = v_u_14,
						["color"] = v_u_327.text2,
						["size"] = UDim2.new(1, 0, 0, 22)
					}).LayoutOrder = 1000
					for v431, v432 in v322 do
						local v_u_433 = v_u_8.new("TextButton", {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.2,
							["BorderSizePixel"] = 0,
							["Text"] = "",
							["AutoButtonColor"] = false,
							["LayoutOrder"] = nil,
							["Size"] = nil,
							["Name"] = "Ev_" .. v432.key,
							["BackgroundColor3"] = v_u_327.raised,
							["LayoutOrder"] = v431 + 1000,
							["Size"] = UDim2.new(1, 0, 0, v_u_9.touch(v_u_328 and 40 or 46))
						}, v_u_14)
						v_u_8.stroke(v_u_433, v_u_327.line)
						local v434 = v_u_8.icon
						local v435 = v432.kind == "airdrop" and "parachute" or (v432.kind == "horde" and "horde" or "heli")
						local v436 = {
							["parent"] = nil,
							["size"] = 14,
							["color"] = nil,
							["position"] = nil,
							["parent"] = v_u_433
						}
						local v437
						if v432.color == "red" then
							v437 = v_u_327.danger
						else
							v437 = v_u_327.accent
						end
						v436.color = v437
						v436.position = UDim2.fromOffset(8, 7)
						v434(v435, v436)
						v_u_8.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v_u_433,
							["text"] = v432.name,
							["position"] = UDim2.fromOffset(28, 3),
							["size"] = UDim2.new(1, -86, 0, 20)
						})
						v_u_155(v_u_8.label({
							["parent"] = nil,
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v_u_433,
							["color"] = v_u_327.text2,
							["position"] = UDim2.fromOffset(28, 22),
							["size"] = UDim2.new(1, -86, 0, 18)
						}), v432.detail)
						if v432.kind == "airdrop" and v432.pos then
							local v_u_438 = v_u_8.label({
								["parent"] = nil,
								["text"] = "Ping",
								["style"] = "caps",
								["color"] = nil,
								["align"] = "right",
								["anchor"] = nil,
								["position"] = nil,
								["size"] = nil,
								["parent"] = v_u_433,
								["color"] = v_u_327.accent,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, -10, 0.5, 0),
								["size"] = UDim2.fromOffset(56, 18)
							})
							v_u_433.MouseEnter:Connect(function()
								-- upvalues: (copy) v_u_433, (copy) v_u_327, (copy) v_u_438
								v_u_433.BackgroundColor3 = v_u_327.raised2
								v_u_438.TextColor3 = v_u_327.text
							end)
							v_u_433.MouseLeave:Connect(function()
								-- upvalues: (copy) v_u_433, (copy) v_u_327, (copy) v_u_438
								v_u_433.BackgroundColor3 = v_u_327.raised
								v_u_438.TextColor3 = v_u_327.accent
							end)
							local v_u_439 = v432.pos
							v_u_433.Activated:Connect(function()
								-- upvalues: (ref) v_u_7, (copy) v_u_439, (ref) v_u_8
								local v440 = v_u_7 and v_u_7.controllers
								if v440 then
									v440 = v_u_7.controllers.Comms
								end
								if v440 then
									local v441 = v440.pingAt
									if type(v441) == "function" then
										local v442 = v440.pingAt
										local v443 = v_u_439
										pcall(v442, "go", v443)
									end
								end
								v_u_8.sound("click")
							end)
						else
							v_u_433.Selectable = false
						end
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
local v_u_445 = {
	["pos"] = nil,
	["ms"] = 0,
	["pos"] = {}
}
local function v_u_454(p446) -- name: pulseTask
	-- upvalues: (copy) v_u_445, (ref) v_u_8, (ref) v_u_9
	for _, v447 in p446 do
		local v448 = v_u_445.pos[v447]
		if not (v448 and (v448.dia and v448.dia.Parent)) then
			continue
		end
		local v_u_449 = v448.d
		local v_u_450 = v_u_8.new("Frame", {
			["Name"] = "TaskPulse",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 9,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v448.p.X, v448.p.Y),
			["Size"] = UDim2.fromOffset(v_u_449, v_u_449)
		}, v448.dia.Parent)
		v_u_8.new("UICorner", {
			["CornerRadius"] = UDim.new(0.5, 0)
		}, v_u_450)
		local v_u_451 = v_u_8.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["BorderStrokePosition"] = nil,
			["Color"] = nil,
			["Thickness"] = 3,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
			["Color"] = v_u_9.color.accent
		}, v_u_450)
		local v_u_452 = game:GetService("TweenService")
		local v_u_453 = TweenInfo.new(0.55, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 1)
		pcall(function()
			-- upvalues: (copy) v_u_452, (copy) v_u_450, (copy) v_u_453, (copy) v_u_449, (copy) v_u_451
			v_u_452:Create(v_u_450, v_u_453, {
				["Size"] = UDim2.fromOffset(v_u_449 * 3.4, v_u_449 * 3.4)
			}):Play()
			v_u_452:Create(v_u_451, v_u_453, {
				["Transparency"] = 1
			}):Play()
		end)
		task.delay(1.3, function()
			-- upvalues: (copy) v_u_450
			v_u_450:Destroy()
		end)
	end
end
local function v_u_473(p_u_455) -- name: taskPlaceName
	-- upvalues: (ref) v_u_13, (ref) v_u_7
	if v_u_13 and not v_u_13.noMap then
		if v_u_13.hollow then
			local function v456()
				-- upvalues: (ref) v_u_7
				return v_u_7.lib.HollowMapDraw
			end
			local v457, v_u_458 = pcall(v456)
			if v457 and v_u_458 then
				local v459 = v_u_458.roomAt(p_u_455)
				if v459 then
					local v460, v461 = pcall(function()
						-- upvalues: (copy) v_u_458, (copy) p_u_455
						return v_u_458.roomName(p_u_455)
					end)
					if not v460 or (type(v461) ~= "string" or v461 == "") then
						v461 = "Room " .. p_u_455
					end
					if v459 == v_u_13.level then
						return v461
					else
						return tostring(v459) .. "  \194\183  " .. v461
					end
				else
					return nil
				end
			else
				return nil
			end
		else
			if v_u_13.field then
				local v462 = v_u_13.placeOf
				if type(v462) == "function" then
					local v463, v464, v465 = v_u_13.placeOf(p_u_455)
					if v463 and v464 then
						return v465 or p_u_455
					else
						return nil
					end
				end
			end
			local v_u_466 = nil
			local function v467()
				-- upvalues: (ref) v_u_466, (ref) v_u_7
				v_u_466 = v_u_7.lib.MapData
			end
			pcall(v467)
			if v_u_466 then
				local v468 = v_u_466.BUILDINGS
				if type(v468) == "table" then
					local v469 = v_u_466
					for _, v470 in v_u_466.BUILDINGS do
						if v470[2] ~= p_u_455 then
							continue
						end
						local v471 = v469.LANDMARKS
						local v472 = type(v471) == "table" and v469.LANDMARKS[p_u_455]
						if v472 then
							p_u_455 = v472
						elseif v470[8] ~= "" then
							p_u_455 = v470[8]
						end
						return p_u_455
					end
					return nil
				end
			end
			return nil
		end
	else
		return nil
	end
end
local function v_u_495() -- name: collectTaskEntries
	-- upvalues: (ref) v_u_7, (copy) v_u_10, (copy) v_u_58, (copy) v_u_473
	local v474 = v_u_7.lib.MapTaskList
	local v_u_475 = nil
	local function v476()
		-- upvalues: (ref) v_u_475, (ref) v_u_7
		v_u_475 = v_u_7.shared.Tasks
	end
	pcall(v476)
	local v477 = v_u_475
	return type(v477) ~= "table" and {} or v474.build({
		["places"] = v474.decode(v_u_10:GetAttribute("TaskPlaces")),
		["detail"] = v474.decode(v_u_10:GetAttribute("TaskDetail")),
		["defs"] = v_u_475,
		["mapId"] = v_u_58(),
		["placeName"] = v_u_473,
		["roomName"] = function(p478, p479) -- name: roomName
			-- upvalues: (ref) v_u_7
			local function v480()
				-- upvalues: (ref) v_u_7
				return v_u_7.lib.TaskPlaceNames
			end
			local v481, v482 = pcall(v480)
			if v481 and v482 then
				return v482.place(p478, p479)
			else
				return nil
			end
		end,
		["itemName"] = function(p_u_483) -- name: itemName
			-- upvalues: (ref) v_u_7
			local function v484()
				-- upvalues: (ref) v_u_7, (copy) p_u_483
				return v_u_7.shared.Items.get(p_u_483)
			end
			local v485, v486 = pcall(v484)
			if v485 and type(v486) == "table" then
				local v487 = v486.name
				if type(v487) == "string" then
					return v486.name
				end
			end
			return nil
		end,
		["giverName"] = function(p488) -- name: giverName
			-- upvalues: (ref) v_u_7
			local function v489()
				-- upvalues: (ref) v_u_7
				return v_u_7.shared.Traders
			end
			local v490, v491 = pcall(v489)
			local v492
			if v490 and type(v491) == "table" then
				local v493 = v491.defs
				if type(v493) == "table" then
					v492 = v491.defs[p488]
				else
					v492 = nil
				end
			else
				v492 = nil
			end
			if type(v492) == "table" then
				local v494 = v492.name
				if type(v494) == "string" then
					return v492.name
				end
			end
			return nil
		end
	})
end
local function v_u_502() -- name: clearTaskTag
	-- upvalues: (copy) v_u_266
	for _, v496 in v_u_266.tags do
		if typeof(v496) ~= "Instance" or not v496.Parent then
			continue
		end
		v496:Destroy()
	end
	table.clear(v_u_266.tags)
	local v497 = v_u_266.used
	for _, v498 in v_u_266.hidden do
		local v499 = v498[6]
		if v499 and (v499.obj and v499.obj.Parent) then
			v499.obj.Visible = true
		end
		if not v497 then
			continue
		end
		table.insert(v497, v498)
	end
	table.clear(v_u_266.hidden)
	if v497 and v_u_266.tmp then
		for _, v500 in v_u_266.tmp do
			local v501 = table.find(v497, v500)
			if not v501 then
				continue
			end
			table.remove(v497, v501)
		end
	end
	v_u_266.tmp = {}
end
local function v_u_549(p503) -- name: showTaskTag
	-- upvalues: (copy) v_u_502, (copy) v_u_266, (ref) v_u_13, (copy) v_u_272, (ref) v_u_7, (ref) v_u_9, (copy) v_u_281, (copy) v_u_255, (ref) v_u_8
	v_u_502()
	local v504 = v_u_266.used
	local v505 = v_u_266.layer
	if p503 and (v504 and (v505 and (v505.Parent and (v_u_13 and v_u_272())))) then
		local v506 = v_u_7.shared.MapTagPlace
		local v507 = v_u_13.ink
		local v508 = v_u_13.k
		local v509 = v508 * 13 + 0.5
		local v510 = math.floor(v509)
		local v511 = math.max(11, v510)
		local v512
		if v_u_9 then
			v512 = v_u_9.phoneText(v511, "text")
		else
			v512 = v511
		end
		local v513 = v512 / v511
		local v514
		if p503.num then
			local v515 = p503.num
			v514 = tostring(v515) .. "  \194\183  "
		else
			v514 = ""
		end
		local v516 = string.upper
		local v517 = p503.title
		local v518 = v514 .. v516((tostring(v517)))
		local v519 = ((utf8.len(v518) or #v518) * 7 + 20) * v508 * v513
		local v520 = v513 * 300
		local v521 = math.clamp(v519, 120, v520)
		local v522 = math.floor(v521)
		local v523
		if v_u_9.isPhone() then
			v523 = v512 + 7
		else
			local v524 = v508 * 22
			local v525 = math.max(v524, 20)
			v523 = math.floor(v525)
		end
		local v526 = 0
		for _, v527 in p503.wheres do
			local v528 = v_u_266.chips[v527]
			if not v528 or v526 >= 4 then
				continue
			end
			v526 = v526 + 1
			local v529 = v506.pick
			local v530 = {
				["anchor"] = nil,
				["sizes"] = nil,
				["W"] = nil,
				["H"] = nil,
				["edge"] = 4,
				["gap"] = 3,
				["rings"] = 6,
				["fixed"] = nil,
				["anchor"] = v528.rect
			}
			local v531 = {}
			local v532 = {}
			local v533 = v522 * 0.62
			local v534 = math.floor(v533)
			__set_list(v532, 1, {math.max(70, v534), v523})
			local v535 = {}
			local v536 = v522 * 0.4
			local v537 = math.floor(v536)
			__set_list(v535, 1, {math.max(46, v537), v523})
			__set_list(v531, 1, {{ v522, v523 }, v532, v535})
			v530.sizes = v531
			v530.W = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
			v530.H = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
			v530.fixed = v504
			local v538 = v529(v530)
			local v539 = {
				v538.x,
				v538.y,
				v538.x + v538.w,
				v538.y + v538.h,
				4
			}
			v_u_281(v504, v539, v_u_266.hidden)
			table.insert(v504, v539)
			local v540 = v_u_266.tmp
			table.insert(v540, v539)
			if v506.needsLeader(v528.rect, v538.x, v538.y, v538.w, v538.h, 3) then
				local v541, v542, v543, v544 = v506.leader(v528.rect, v538.x, v538.y, v538.w, v538.h)
				local v545 = v_u_255(v505, Vector2.new(v541, v542), Vector2.new(v543, v544), 1, v507.inkSoft, 7)
				v545.Name = "Leader"
				local v546 = v_u_266.tags
				table.insert(v546, v545)
			end
			local v547 = v_u_8.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.04,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 8,
				["Name"] = "TaskTag_" .. v527,
				["BackgroundColor3"] = v507.paperLight,
				["Position"] = UDim2.fromOffset(v538.x, v538.y),
				["Size"] = UDim2.fromOffset(v538.w, v538.h)
			}, v505)
			v_u_8.new("UIStroke", {
				["ApplyStrokeMode"] = nil,
				["BorderStrokePosition"] = nil,
				["Color"] = nil,
				["Thickness"] = 2,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
				["Color"] = v_u_9.color.accent
			}, v547)
			v_u_8.new("TextLabel", {
				["Name"] = "Name",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["FontFace"] = nil,
				["Text"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 9,
				["Position"] = UDim2.fromOffset(6, 0),
				["Size"] = UDim2.new(1, -12, 1, 0),
				["FontFace"] = v_u_9.font.headingBold,
				["Text"] = v518,
				["TextSize"] = v512,
				["TextColor3"] = v507.ink,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd
			}, v547)
			local v548 = v_u_266.tags
			table.insert(v548, v547)
		end
	end
end
function v_u_6.applySideSplit(p550) -- name: applySideSplit
	-- upvalues: (ref) v_u_14, (ref) v_u_15, (copy) v_u_16, (ref) v_u_7
	local v551 = v_u_14
	local v552 = v_u_15
	if v_u_16.split and (v551 and (v552 and v552.Parent)) then
		local v553, v554, v555 = v_u_7.shared.MapLayoutRule.sideSplit(v_u_16.free, p550, v_u_16.phone)
		v551.Size = UDim2.new(1, 0, 0, v553)
		v552.Visible = v554 > 0
		v552.Position = UDim2.fromOffset(0, v_u_16.top + v553 + v555)
		v552.Size = UDim2.new(1, 0, 0, v554)
	end
end
local function v_u_588() -- name: paintTaskList
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_8, (ref) v_u_15, (copy) v_u_16, (copy) v_u_495, (ref) v_u_7, (ref) v_u_9, (ref) v_u_17, (ref) v_u_162, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151, (copy) v_u_44, (copy) v_u_454, (copy) v_u_272, (copy) v_u_502, (copy) v_u_549, (copy) v_u_445, (copy) v_u_6
	if v_u_13 and v_u_14 then
		local v556 = v_u_8.device()
		local v557 = os.clock()
		local v558 = v_u_14
		local v559 = v_u_15
		if v_u_16.split and (v559 and v559.Parent) then
			for _, v560 in v559:GetChildren() do
				if not v560:IsA("GuiObject") then
					continue
				end
				v560:Destroy()
			end
		else
			v559 = v558
		end
		local v_u_561 = v_u_495()
		local v562 = v_u_7.lib.MapTaskList.paint
		local v564 = {
			["parent"] = nil,
			["UI"] = nil,
			["Theme"] = nil,
			["entries"] = nil,
			["order"] = 900,
			["verb"] = nil,
			["collect"] = nil,
			["repaint"] = nil,
			["hintText"] = nil,
			["onOpen"] = nil,
			["onChange"] = nil,
			["parent"] = v559,
			["UI"] = v_u_8,
			["Theme"] = v_u_9,
			["entries"] = v_u_561,
			["verb"] = v556 == "Touch" and "Tap" or (v556 == "Gamepad" and "Select" or "Click"),
			["collect"] = v_u_495,
			["repaint"] = function() -- name: repaint
				-- upvalues: (ref) v_u_17, (ref) v_u_162, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151
				task.defer(function()
					-- upvalues: (ref) v_u_17, (ref) v_u_162, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151
					if v_u_17 and v_u_162 then
						local v563 = v_u_134()
						v_u_20 = v_u_151(v563)
						v_u_162(v563)
					end
				end)
			end
		}
		local v565 = v_u_7 and v_u_7.shared
		if v565 then
			v565 = v_u_7.shared.Config
		end
		local v566 = false
		local function v567()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.MapToggleRule
		end
		local v568, v569 = pcall(v567)
		if not v568 or type(v569) ~= "table" then
			v569 = nil
		end
		if v569 ~= nil then
			if v565 then
				local v570 = v565.flag
				if type(v570) == "function" then
					v565 = v565.flag("MapToggles") == false
				else
					v565 = false
				end
			end
			v566 = not v565
		end
		local v571
		if v566 and not v_u_44().tasks then
			v571 = v_u_7.shared.MapToggleRule.hint(false, v556 == "Touch" and "Tap" or (v556 == "Gamepad" and "Select" or "Click"))
		else
			v571 = nil
		end
		v564.hintText = v571
		function v564.onOpen(p_u_572) -- name: onOpen
			-- upvalues: (ref) v_u_7, (ref) v_u_44, (ref) v_u_17, (ref) v_u_454
			local v573 = v_u_7 and v_u_7.shared
			if v573 then
				v573 = v_u_7.shared.Config
			end
			local v574 = false
			local function v575()
				-- upvalues: (ref) v_u_7
				return v_u_7.shared.MapToggleRule
			end
			local v576, v577 = pcall(v575)
			if not v576 or type(v577) ~= "table" then
				v577 = nil
			end
			if v577 ~= nil then
				if v573 then
					local v578 = v573.flag
					if type(v578) == "function" then
						v573 = v573.flag("MapToggles") == false
					else
						v573 = false
					end
				end
				v574 = not v573
			end
			if v574 and not v_u_44().tasks then
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_17, (ref) v_u_454, (copy) p_u_572
					if v_u_17 then
						v_u_454(p_u_572.wheres)
					end
				end)
			else
				v_u_454(p_u_572.wheres)
			end
		end
		function v564.onChange(p579) -- name: onChange
			-- upvalues: (ref) v_u_7, (ref) v_u_44, (ref) v_u_17, (ref) v_u_162, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_272, (ref) v_u_502, (copy) v_u_561, (ref) v_u_549
			local v580 = v_u_7 and v_u_7.shared
			if v580 then
				v580 = v_u_7.shared.Config
			end
			local v581 = false
			local function v582()
				-- upvalues: (ref) v_u_7
				return v_u_7.shared.MapToggleRule
			end
			local v583, v584 = pcall(v582)
			if not v583 or type(v584) ~= "table" then
				v584 = nil
			end
			if v584 ~= nil then
				if v580 then
					local v585 = v580.flag
					if type(v585) == "function" then
						v580 = v580.flag("MapToggles") == false
					else
						v580 = false
					end
				end
				v581 = not v580
			end
			if v581 and not v_u_44().tasks then
				task.defer(function()
					-- upvalues: (ref) v_u_17, (ref) v_u_162, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151
					if v_u_17 and v_u_162 then
						local v586 = v_u_134()
						v_u_20 = v_u_151(v586)
						v_u_162(v586)
					end
				end)
				return
			elseif v_u_272() then
				v_u_502()
				if p579 then
					for _, v587 in v_u_561 do
						if v587.id ~= p579 then
							continue
						end
						v_u_549(v587)
					end
				end
			end
		end
		v562(v564)
		v_u_445.ms = (os.clock() - v557) * 1000
		if v_u_16.split then
			v_u_6.applySideSplit(#v_u_561 > 0)
		end
	end
end
local function v_u_667(p589, p590, p591) -- name: paintTaskChips
	-- upvalues: (ref) v_u_7, (copy) v_u_495, (copy) v_u_44, (ref) v_u_8, (copy) v_u_266, (ref) v_u_9, (ref) v_u_13, (copy) v_u_316, (copy) v_u_445, (copy) v_u_549
	local v592 = v_u_7.shared.MapTagPlace
	local v593 = v_u_495()
	local v594 = v_u_44()
	if not v594.tasks then
		local function v595()
			-- upvalues: (ref) v_u_7
			return v_u_7.lib.MapTaskList.openId()
		end
		local v596, v597 = pcall(v595)
		if not v596 or type(v597) ~= "string" then
			v597 = nil
		end
		v593 = {}
		for _, v598 in v593 do
			if v597 == nil or v598.id ~= v597 then
				continue
			end
			table.insert(v593, v598)
		end
	end
	local v599 = {}
	local v600 = {}
	for _, v601 in v593 do
		if not v601.num then
			continue
		end
		for _, v602 in v601.wheres do
			local v603 = v599[v602]
			if not v603 then
				v603 = {
					["nums"] = {}
				}
				v599[v602] = v603
				table.insert(v600, v602)
			end
			local v604 = v603.nums
			local v605 = v601.num
			table.insert(v604, v605)
		end
	end
	local v606 = v_u_8.new("Frame", {
		["Name"] = "TaskMarks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 11,
		["Size"] = UDim2.fromScale(1, 1)
	}, p591)
	v_u_266.layer = v606
	v_u_266.tmp = {}
	local v607 = v_u_9.color
	local v608 = v_u_13.ink
	local v609 = v_u_13.k
	local v610 = v609 * 13 + 0.5
	local v611 = math.floor(v610)
	local v612 = math.max(11, v611)
	if v_u_9 then
		v612 = v_u_9.phoneText(v612, "text")
	end
	local v613 = v_u_9.uiScale()
	local v614 = 10 / math.max(v613, 0.3)
	local v615 = math.ceil(v614)
	local v616 = math.max(v612, v615)
	local v617 = v616 + 8
	local v618 = v_u_7.shared.MapLayoutRule
	local v619 = {}
	for _, v620 in v600 do
		local v621 = nil
		for _, v622 in p590.BUILDINGS do
			if v622[2] ~= v620 then
				continue
			end
			v621 = v622
		end
		if not v621 then
			break
		end
		local v623 = v_u_13.toPx(v621[3], v621[4])
		local v624 = v592.chipText(v599[v620].nums)
		local v625 = v592.chipWidth(v624, v617, v616)
		local v626 = v623.X
		local v627 = v623.Y
		local v628 = v623.X
		local v629 = v623.Y
		for _, v630 in v_u_13.removable or {} do
			if v630.id ~= v620 or not (v630.obj and (v630.obj.Parent and (v630.obj.Visible and v594.labels))) then
				continue
			end
			local v631 = v630.rect[1]
			v626 = math.min(v626, v631)
			local v632 = v630.rect[2]
			v627 = math.min(v627, v632)
			local v633 = v630.rect[3]
			v628 = math.max(v628, v633)
			local v634 = v630.rect[4]
			v629 = math.max(v629, v634)
		end
		local v635 = v_u_316(p589, v606, {
			v626,
			v627,
			v628,
			v629
		}, {
			{ v625, v617 }
		}, 5, v608.inkSoft, 6, v623)
		local v636 = v_u_8.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["Name"] = "Task_" .. v620,
			["BackgroundColor3"] = v607.accent,
			["Position"] = UDim2.fromOffset(v635.x, v635.y),
			["Size"] = UDim2.fromOffset(v625, v617)
		}, v606)
		v_u_8.new("UICorner", {
			["CornerRadius"] = UDim.new(0, 4)
		}, v636)
		local v637 = v_u_8.new
		local v638 = {
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
			["Color"] = v608.ink
		}
		local v639 = v609 * 1.5 + 0.5
		local v640 = math.floor(v639)
		v638.Thickness = math.max(1, v640)
		v637("UIStroke", v638, v636)
		v_u_8.new("TextLabel", {
			["Name"] = "N",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["FontFace"] = nil,
			["Text"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["ZIndex"] = 7,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_9.font.headingBold,
			["Text"] = v624,
			["TextSize"] = v616,
			["TextColor3"] = v608.ink
		}, v636)
		local v641 = Vector2.new(v635.x + v625 / 2, v635.y + v617 / 2)
		v_u_266.chips[v620] = {
			["rect"] = {
				v635.x,
				v635.y,
				v635.x + v625,
				v635.y + v617
			},
			["p"] = v641,
			["w"] = v625,
			["s"] = v617
		}
		v_u_445.pos[v620] = {
			["p"] = v641,
			["d"] = math.max(v625, v617),
			["dia"] = v636
		}
		table.insert(v619, {
			["where"] = v620,
			["c"] = v641,
			["w"] = v625,
			["s"] = v617
		})
	end
	local v642 = v_u_9.touch(0)
	for v643, v644 in v619 do
		local v645 = v644.w
		local v646 = v644.s
		if type(v618) == "table" then
			local v647 = v618.taskHit
			if type(v647) == "function" then
				local v648 = v618.taskHit(v644.s, v644.s, v642)
				local v649 = v644.w
				v645 = math.max(v649, v648)
				local v650 = v644.s
				v646 = math.max(v650, v648)
			end
		end
		for v651, v652 in v619 do
			if v651 == v643 then
				continue
			end
			local v653 = v652.c.X - v644.c.X
			local v654 = math.abs(v653)
			local v655 = v652.c.Y - v644.c.Y
			local v656 = math.abs(v655)
			if v654 * 2 - 2 >= v645 or v656 * 2 - 2 >= v646 then
				continue
			end
			if v656 <= v654 then
				local v657 = v644.w
				local v658 = v654 * 2 - 2
				v645 = math.max(v657, v658)
			else
				local v659 = v644.s
				local v660 = v656 * 2 - 2
				v646 = math.max(v659, v660)
			end
		end
		local v661 = v_u_8.new("TextButton", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = false,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Name"] = "TaskHit_" .. v644.where,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v644.c.X, v644.c.Y),
			["Size"] = UDim2.fromOffset(v645, v646)
		}, v_u_13.marks)
		local v_u_662 = v644.where
		v661.Activated:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_7, (copy) v_u_662
			v_u_8.sound("click")
			local v663 = v_u_7.lib.MapTaskList.openWhere
			local v664 = v_u_662
			if not pcall(v663, v664) then
				warn("[MapUI] task chip:", v_u_662)
			end
		end)
	end
	local v665 = v_u_7.lib.MapTaskList.openId()
	if v665 then
		for _, v666 in v593 do
			if v666.id ~= v665 then
				continue
			end
			v_u_549(v666)
		end
	end
end
local function v_u_783(p668, p669, p670) -- name: paintTaskSheet
	-- upvalues: (copy) v_u_445, (ref) v_u_13, (ref) v_u_14, (copy) v_u_10, (copy) v_u_44, (copy) v_u_272, (ref) v_u_7, (copy) v_u_667, (ref) v_u_8, (ref) v_u_9
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v671, v672, v673, v674, v675, v676, v677, v678, v679, v680, v681, v682, v683, v684, v685, v686, v687, v688, v689, v690, v_u_691, v692, v693, v694, v695, v696, v697, v698, v699, v700, v701, v702, v703, v704, v705, v706, v707, v708, v709, v710, v711, v712, v713, v714, v715, v716, v717, v718, v719, v720, v721, v722, v723, v724, v725, v726, v727, v728, v729, v730, v731, v732, v733, v734, v735, v736, v737, v738, v739, v740, v741, v742, v743, v744, v745, v746, v747, v748, v749, v750, v751, v752, v753, v754, v_u_755, v756, v757, v758, v759, v760, v761, v762, v763, v764, v765, v766
	local v767 = 7
	while true do
		if v767 == 1 then
			v675 = function()
				-- upvalues: (ref) v_u_7
				return v_u_7.lib.HollowMapDraw
			end
			v676, v690 = pcall(v675)
			v_u_691 = {
				["BUILDINGS"] = {},
				["LANDMARKS"] = {}
			}
			for _, v768 in v745 do
				if not v676 or (not v690 or type(v768) ~= "table") then
					continue
				end
				v752 = v768.where
				if type(v752) ~= "string" then
					continue
				end
				v753, v754, v692 = v690.roomAt(v768.where)
				if v753 ~= v_u_13.level then
					continue
				end
				v765 = v_u_691.BUILDINGS
				v766 = {
					"room",
					v768.where,
					v754,
					v692,
					0,
					0,
					0,
					v768.where
				}
				table.insert(v765, v766)
			end
			v767 = 3
		elseif v767 == 2 then
			if v_u_13.field then
				v767 = 4
			else
				v767 = 5
			end
		elseif v767 == 3 then
			if v_u_691 then
				v725 = v_u_691.BUILDINGS
				if type(v725) == "table" then
					v726 = {}
					v740 = {}
					for _, v769 in v745 do
						if type(v769) ~= "table" then
							continue
						end
						v674 = v769.where
						if type(v674) ~= "string" then
							continue
						end
						if not v726[v769.where] then
							v726[v769.where] = {}
							v693 = v769.where
							table.insert(v740, v693)
						end
						v694 = table.find
						v714 = v726[v769.where]
						v715 = v769.title
						if v694(v714, (tostring(v715))) then
							continue
						end
						v716 = v726[v769.where]
						v717 = v769.title
						v762 = tostring(v717)
						table.insert(v716, v762)
					end
					if p670 and v_u_272() then
						v_u_667(p668, v_u_691, v710)
					else
						v763 = v_u_8.new("Frame", {
							["Name"] = "TaskMarks",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["ZIndex"] = 11,
							["Size"] = UDim2.fromScale(1, 1)
						}, v710)
						v764 = v_u_9.color
						v724 = v_u_13.ink
						v711 = v_u_13.k
						v759 = v_u_13.inner
						v712 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
						v713 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
						v741 = v_u_9.isPhone()
						v742 = v711 * 13 + 0.5
						v677 = math.floor(v742)
						v678 = math.max(11, v677)
						if v_u_9 then
							v718 = v_u_9.phoneText(v678, "text")
						else
							v718 = v678
						end
						v719 = v718 / v678
						if p670 then
							v720 = nil
						else
							v720 = v_u_8.label({
								["parent"] = nil,
								["text"] = "Tasks",
								["style"] = "caps",
								["textSize"] = 13,
								["color"] = nil,
								["size"] = nil,
								["valign"] = "bottom",
								["track"] = false,
								["parent"] = v_u_14,
								["color"] = v764.text2,
								["size"] = UDim2.new(1, 0, 0, 22)
							})
							v720.LayoutOrder = 900
						end
						v721 = v_u_7.shared.MapLayoutRule
						v760 = 0
						v761 = {}
						for _, v_u_770 in v740 do
							v722 = nil
							for _, v771 in v_u_691.BUILDINGS do
								if v771[2] ~= v_u_770 then
									continue
								end
								v722 = v771
							end
							if not v722 then
								break
							end
							v760 = v760 + 1
							v723 = v_u_13.toPx(v722[3], v722[4])
							v747 = v711 * 12
							v748 = math.max(v747, 10)
							v687 = math.floor(v748)
							v688 = v_u_8.new("Frame", {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.15,
								["BorderSizePixel"] = 0,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["Rotation"] = 45,
								["ZIndex"] = 5,
								["Name"] = "Task_" .. v_u_770,
								["BackgroundColor3"] = v764.accent,
								["AnchorPoint"] = Vector2.new(0.5, 0.5),
								["Position"] = UDim2.fromOffset(v723.X, v723.Y),
								["Size"] = UDim2.fromOffset(v687, v687)
							}, v763)
							v_u_8.new("UIStroke", {
								["ApplyStrokeMode"] = nil,
								["BorderStrokePosition"] = nil,
								["Color"] = nil,
								["Thickness"] = 1,
								["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
								["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
								["Color"] = v724.ink
							}, v688)
							v749 = "TASK  \194\183  " .. table.concat(v726[v_u_770], ", ")
							v750 = (#v749 * 7 + 20) * v711 * v719
							v751 = v719 * 260
							v689 = math.clamp(v750, 120, v751)
							v735 = math.floor(v689)
							if v741 then
								v736 = v718 + 7
							else
								v671 = v711 * 22
								v672 = math.max(v671, 20)
								v736 = math.floor(v672)
							end
							v737 = (1 / 0)
							v738 = 0
							v739 = 0
							for v772, v773 in {
								{ v723.X + v711 * 12, v723.Y - v736 / 2 },
								{ v723.X - v711 * 12 - v735, v723.Y - v736 / 2 },
								{ v723.X - v735 / 2, v723.Y + v711 * 12 },
								{ v723.X - v735 / 2, v723.Y - v711 * 12 - v736 }
							} do
								v673 = v773[1]
								v695 = v712 - v735 - 4
								v679 = math.clamp(v673, 4, v695)
								v696 = v773[2]
								v680 = v713 - v736 - 4
								v681 = math.clamp(v696, 4, v680)
								v697 = p669(v679, v681, v679 + v735, v681 + v736) + v772 * 0.01
								if v697 >= v737 then
									continue
								end
								v739 = v681
								v738 = v679
								v737 = v697
							end
							v698 = {
								v738,
								v739,
								v738 + v735,
								v739 + v736,
								4
							}
							table.insert(p668, v698)
							v682 = v_u_8.new("Frame", {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.04,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["ZIndex"] = 4,
								["Name"] = "TaskTag_" .. v_u_770,
								["BackgroundColor3"] = v724.paperLight,
								["Position"] = UDim2.fromOffset(v738, v739),
								["Size"] = UDim2.fromOffset(v735, v736)
							}, v763)
							v_u_8.new("UIStroke", {
								["ApplyStrokeMode"] = nil,
								["BorderStrokePosition"] = nil,
								["Color"] = nil,
								["Thickness"] = 1,
								["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
								["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
								["Color"] = v764.accent
							}, v682)
							v_u_8.new("TextLabel", {
								["BackgroundTransparency"] = 1,
								["Position"] = nil,
								["Size"] = nil,
								["FontFace"] = nil,
								["Text"] = nil,
								["TextSize"] = nil,
								["TextColor3"] = nil,
								["TextXAlignment"] = nil,
								["TextTruncate"] = nil,
								["ZIndex"] = 5,
								["Position"] = UDim2.fromOffset(6, 0),
								["Size"] = UDim2.new(1, -12, 1, 0),
								["FontFace"] = v_u_9.font.headingBold,
								["Text"] = v749,
								["TextSize"] = v718,
								["TextColor3"] = v724.ink,
								["TextXAlignment"] = Enum.TextXAlignment.Left,
								["TextTruncate"] = Enum.TextTruncate.AtEnd
							}, v682)
							if p670 then
								v_u_445.pos[v_u_770] = {
									["p"] = v723,
									["d"] = v687,
									["dia"] = v688
								}
								v683 = v687 * 1.5
								v684 = math.max(v683, 22)
								if type(v721) == "table" then
									v685 = v721.taskHit
									if type(v685) == "function" then
										v684, v686 = v721.taskHit(v687, v736, v_u_9.touch(0))
									else
										v686 = v736
									end
								else
									v686 = v736
								end
								for _, v774 in {
									{
										"TaskHit_",
										v723.X - v684 / 2,
										v723.Y - v684 / 2,
										v684,
										v684
									},
									{
										"TaskTagHit_",
										v738,
										v739,
										v735,
										v736
									}
								} do
									v703 = v_u_8.new("TextButton", {
										["Name"] = nil,
										["BackgroundTransparency"] = 1,
										["Text"] = "",
										["AutoButtonColor"] = false,
										["Selectable"] = false,
										["Position"] = nil,
										["Size"] = nil,
										["ZIndex"] = 5,
										["Name"] = v774[1] .. v_u_770,
										["Position"] = UDim2.fromOffset(v774[2], v774[3]),
										["Size"] = UDim2.fromOffset(v774[4], v774[5])
									}, v_u_13.marks)
									if v774[1] == "TaskTagHit_" and v736 < v686 then
										v704 = {
											["btn"] = v703,
											["x"] = v738,
											["y"] = v739,
											["w"] = v735,
											["h"] = v736,
											["want"] = v686,
											["tag"] = {
												v738,
												v739,
												v738 + v735,
												v739 + v736
											},
											["mark"] = {
												v723.X - v687 / 2,
												v723.Y - v687 / 2,
												v723.X + v687 / 2,
												v723.Y + v687 / 2
											}
										}
										table.insert(v761, v704)
									end
									v703.Activated:Connect(function()
										-- upvalues: (ref) v_u_8, (ref) v_u_7, (copy) v_u_770
										v_u_8.sound("click")
										local v775 = v_u_7.lib.MapTaskList.openWhere
										local v776 = v_u_770
										if not pcall(v775, v776) then
											warn("[MapUI] task tag:", v_u_770)
										end
									end)
								end
							else
								v699 = v_u_8.new("Frame", {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = 0.2,
									["BorderSizePixel"] = 0,
									["LayoutOrder"] = nil,
									["Size"] = nil,
									["Name"] = "Task_" .. v_u_770,
									["BackgroundColor3"] = v764.raised,
									["LayoutOrder"] = v760 + 900,
									["Size"] = UDim2.new(1, 0, 0, v741 and 38 or 44)
								}, v_u_14)
								v_u_8.stroke(v699, v764.line)
								v_u_8.new("Frame", {
									["Name"] = "Edge",
									["BackgroundColor3"] = nil,
									["BorderSizePixel"] = 0,
									["Size"] = nil,
									["BackgroundColor3"] = v764.accent,
									["Size"] = UDim2.new(0, 2, 1, 0)
								}, v699)
								v700 = v_u_691.LANDMARKS
								v701 = type(v700) == "table" and v_u_691.LANDMARKS[v_u_770]
								if not v701 then
									if v722[8] == "" then
										v701 = v_u_770
									else
										v701 = v722[8]
									end
								end
								v_u_8.label({
									["parent"] = nil,
									["text"] = nil,
									["style"] = "bodyStrong",
									["position"] = nil,
									["size"] = nil,
									["track"] = false,
									["parent"] = v699,
									["text"] = tostring(v701),
									["position"] = UDim2.fromOffset(12, 3),
									["size"] = UDim2.new(1, -20, 0, 20)
								})
								v_u_8.label({
									["parent"] = nil,
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["track"] = false,
									["parent"] = v699,
									["text"] = table.concat(v726[v_u_770], ", "),
									["color"] = v764.accent,
									["position"] = UDim2.fromOffset(12, 21),
									["size"] = UDim2.new(1, -20, 0, 18)
								})
							end
						end
						if #v761 > 0 and type(v721) == "table" then
							v702 = v721.growTagBox
							if type(v702) == "function" then
								for v777, v778 in v761 do
									v705 = {}
									for v779, v780 in v761 do
										if v779 == v777 then
											continue
										end
										v727 = v780.tag
										table.insert(v705, v727)
										v728 = v780.mark
										table.insert(v705, v728)
									end
									v706, v707 = v721.growTagBox(v778.x, v778.y, v778.w, v778.h, v778.want, v705)
									if not v778.btn.Parent then
										break
									end
									v778.btn.Position = UDim2.fromOffset(v778.x, v706)
									v778.btn.Size = UDim2.fromOffset(v778.w, v707)
								end
							end
						end
						if v760 == 0 and v720 then
							v720:Destroy()
						end
						if v746 then
							v763.Visible = false
						end
					end
				end
			end
			return
		elseif v767 == 4 then
			v708 = v_u_13.placeOf
			if type(v708) == "function" then
				v767 = 6
			else
				v767 = 5
			end
		elseif v767 == 5 then
			v709 = function()
				-- upvalues: (ref) v_u_691, (ref) v_u_7
				v_u_691 = v_u_7.lib.MapData
			end
			pcall(v709)
			v767 = 3
		elseif v767 == 6 then
			v_u_691 = {
				["BUILDINGS"] = {},
				["LANDMARKS"] = {}
			}
			for _, v781 in v745 do
				if type(v781) ~= "table" then
					continue
				end
				v729 = v781.where
				if type(v729) ~= "string" then
					continue
				end
				v730, v731, v732 = v_u_13.placeOf(v781.where)
				if not (v730 and v731) then
					continue
				end
				v733 = v_u_691.BUILDINGS
				v734 = {
					"place",
					v781.where,
					v730,
					v731,
					0,
					0,
					0,
					v732 or v781.where
				}
				table.insert(v733, v734)
			end
			v767 = 3
		else
			table.clear(v_u_445.pos)
			if not (v_u_13 and v_u_14) then
				return
			end
			v710 = not v_u_13.area and v_u_13.marks
			if v710 then
				v710 = v_u_13.marks.Parent
			end
			if not v710 then
				return
			end
			v743 = v710:FindFirstChild("TaskMarks")
			if v743 then
				v743:Destroy()
			end
			v_u_755 = v_u_10:GetAttribute("TaskPlaces")
			if type(v_u_755) ~= "string" or v_u_755 == "" then
				return
			end
			v744, v745 = pcall(function()
				-- upvalues: (copy) v_u_755
				return game:GetService("HttpService"):JSONDecode(v_u_755)
			end)
			if not v744 or (type(v745) ~= "table" or #v745 == 0) then
				return
			end
			v746 = false
			if not (v_u_44().tasks or p670 and v_u_272()) then
				if p670 then
					v756 = function()
						-- upvalues: (ref) v_u_7
						return v_u_7.lib.MapTaskList.openId()
					end
					v757, v758 = pcall(v756)
					if not v757 or type(v758) ~= "string" then
						v758 = nil
					end
					v745 = {}
					for _, v782 in v745 do
						if v758 == nil or (type(v782) ~= "table" or v782.id ~= v758) then
							continue
						end
						table.insert(v745, v782)
					end
				else
					v746 = true
				end
			end
			v_u_691 = nil
			if v_u_13.noMap then
				return
			end
			if v_u_13.hollow then
				v767 = 1
			else
				v767 = 2
			end
		end
	end
end
local function v_u_795(p784, p785) -- name: paintTasks
	-- upvalues: (ref) v_u_7, (copy) v_u_783, (copy) v_u_588
	local v786 = v_u_7 and v_u_7.shared
	if v786 then
		v786 = v_u_7.shared.Config
	end
	if v786 then
		local v787 = v786.flag
		if type(v787) == "function" then
			v786 = v786.flag("MapTaskDrop") == false
		else
			v786 = false
		end
	end
	local v788 = not v786
	local v789 = v_u_783
	local v790, v791 = pcall(v789, p784, p785, v788)
	if not v790 then
		warn("[MapUI] task marks:", v791)
	end
	if v788 then
		local v792 = v_u_588
		local v793, v794 = pcall(v792)
		if not v793 then
			warn("[MapUI] task list:", v794)
		end
	end
end
local function v_u_860(p796, p797) -- name: paintHotspot
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_50, (ref) v_u_9, (ref) v_u_8, (copy) v_u_272, (copy) v_u_316
	if v_u_13 and (v_u_14 and not (v_u_13.noMap or v_u_13.hollow)) then
		local v798 = v_u_50()
		if v798 then
			local v799 = v_u_13.marks
			local v800 = v_u_9.color
			local v801 = v_u_13.ink
			local v802 = v_u_13.k or 1
			local v803 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
			local v804 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
			local v805 = v_u_9.isPhone()
			local v806 = v_u_13.toPx(v798.x, v798.z)
			local v807 = v798.r * 2 * (v_u_13.scale or 1) + v802 * 18
			local v808 = v802 * 30
			local v809 = v802 * 90
			local v810 = math.clamp(v807, v808, v809)
			local v_u_811 = math.floor(v810)
			local v_u_812 = v_u_8.new("Frame", {
				["Name"] = "HotspotRing",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.86,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v801.red,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v806.X, v806.Y),
				["Size"] = UDim2.fromOffset(v_u_811, v_u_811)
			}, v799)
			v_u_8.new("UICorner", {
				["CornerRadius"] = UDim.new(0.5, 0)
			}, v_u_812)
			local v813 = v_u_8.new
			local v814 = {
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
				["Color"] = v801.redDeep
			}
			local v815 = v802 * 3 + 0.5
			local v816 = math.floor(v815)
			v814.Thickness = math.max(2, v816)
			v813("UIStroke", v814, v_u_812)
			local v817 = v802 * 8
			local v818 = math.floor(v817)
			local v819 = math.max(6, v818)
			local v820 = v_u_8.new("Frame", {
				["Name"] = "HotspotCore",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v801.redDeep,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(v819, v819)
			}, v_u_812)
			v_u_8.new("UICorner", {
				["CornerRadius"] = UDim.new(0.5, 0)
			}, v820)
			pcall(function()
				-- upvalues: (copy) v_u_812, (copy) v_u_811
				game:GetService("TweenService"):Create(v_u_812, TweenInfo.new(1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
					["Size"] = nil,
					["BackgroundTransparency"] = 0.95,
					["Size"] = UDim2.fromOffset(v_u_811 * 1.22, v_u_811 * 1.22)
				}):Play()
			end)
			local v821 = v802 * 13 + 0.5
			local v822 = math.floor(v821)
			local v823 = math.max(11, v822)
			local v824
			if v_u_9 then
				v824 = v_u_9.phoneText(v823, "text")
			else
				v824 = v823
			end
			local v825 = v824 / v823
			local v826 = "HOTSPOT  \194\183  " .. string.upper(v798.title)
			local v827 = (utf8.len(v826) or #v826) * 7 * v802 * v825 + 20
			local v828 = v825 * 300
			local v829 = math.clamp(v827, 120, v828)
			local v830 = math.floor(v829)
			local v831
			if v805 then
				v831 = v824 + 7
			else
				local v832 = v802 * 22
				local v833 = math.max(v832, 20)
				v831 = math.floor(v833)
			end
			local v834 = v_u_811 * 0.61 + v802 * 4
			local v835 = 0
			local v836 = 0
			local v837 = (1 / 0)
			local v838 = {
				{ v806.X + v834, v806.Y - v831 / 2 },
				{ v806.X - v834 - v830, v806.Y - v831 / 2 },
				{ v806.X - v830 / 2, v806.Y + v834 },
				{ v806.X - v830 / 2, v806.Y - v834 - v831 }
			}
			if v805 then
				local v839 = v834 * 0.75
				for _, v840 in {
					{ v806.X + v839, v806.Y + v839 },
					{ v806.X - v839 - v830, v806.Y + v839 },
					{ v806.X + v839, v806.Y - v839 - v831 },
					{ v806.X - v839 - v830, v806.Y - v839 - v831 }
				} do
					table.insert(v838, v840)
				end
			end
			if v_u_272() then
				local v841 = v_u_316(p796, v799, {
					v806.X - v_u_811 / 2,
					v806.Y - v_u_811 / 2,
					v806.X + v_u_811 / 2,
					v806.Y + v_u_811 / 2
				}, {
					{ v830, v831 }
				}, 4, v801.redDeep)
				v835 = v841.x
				v836 = v841.y
			else
				for v842, v843 in v838 do
					local v844 = v843[1]
					local v845 = v803 - v830 - 4
					local v846 = math.clamp(v844, 4, v845)
					local v847 = v843[2]
					local v848 = v804 - v831 - 4
					local v849 = math.clamp(v847, 4, v848)
					local v850 = p797(v846, v849, v846 + v830, v849 + v831) + v842 * 0.01
					if v850 >= v837 then
						continue
					end
					v836 = v849
					v835 = v846
					v837 = v850
				end
				local v851 = {
					v835,
					v836,
					v835 + v830,
					v836 + v831,
					4
				}
				table.insert(p796, v851)
			end
			local v852 = v_u_8.new("Frame", {
				["Name"] = "HotspotTag",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.04,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 4,
				["BackgroundColor3"] = v801.paperLight,
				["Position"] = UDim2.fromOffset(v835, v836),
				["Size"] = UDim2.fromOffset(v830, v831)
			}, v799)
			v_u_8.new("UIStroke", {
				["ApplyStrokeMode"] = nil,
				["BorderStrokePosition"] = nil,
				["Color"] = nil,
				["Thickness"] = 1,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
				["Color"] = v801.redDeep
			}, v852)
			v_u_8.new("TextLabel", {
				["Name"] = "Name",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["FontFace"] = nil,
				["Text"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 5,
				["Position"] = UDim2.fromOffset(6, 0),
				["Size"] = UDim2.new(1, -12, 1, 0),
				["FontFace"] = v_u_9.font.headingBold,
				["Text"] = v826,
				["TextSize"] = v824,
				["TextColor3"] = v801.redDeep,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd
			}, v852)
			v_u_8.label({
				["parent"] = nil,
				["name"] = "HotspotHead",
				["text"] = "Hotspot",
				["style"] = "caps",
				["textSize"] = 13,
				["color"] = nil,
				["size"] = nil,
				["valign"] = "bottom",
				["track"] = false,
				["parent"] = v_u_14,
				["color"] = v800.text2,
				["size"] = UDim2.new(1, 0, 0, 22)
			}).LayoutOrder = 880
			local v853 = v_u_8.new("Frame", {
				["Name"] = "Row_Hotspot",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = 881,
				["Size"] = nil,
				["BackgroundColor3"] = v800.raised,
				["Size"] = UDim2.new(1, 0, 0, v805 and 38 or 44)
			}, v_u_14)
			v_u_8.stroke(v853, v800.line)
			v_u_8.new("Frame", {
				["Name"] = "Edge",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v801.red,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}, v853)
			local v854 = v_u_8.label
			local v855 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v853
			}
			local v856 = string.upper
			local v857 = v798.title
			local v858 = v856((string.sub(v857, 1, 1)))
			local v859 = v798.title
			v855.text = v858 .. string.sub(v859, 2)
			v855.position = UDim2.fromOffset(12, 3)
			v855.size = UDim2.new(1, -20, 0, 20)
			v854(v855)
			v_u_8.label({
				["parent"] = nil,
				["text"] = "More loot, more infected",
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v853,
				["color"] = v800.accent,
				["position"] = UDim2.fromOffset(12, 21),
				["size"] = UDim2.new(1, -20, 0, 18)
			})
		end
	else
		return
	end
end
local function v_u_876() -- name: paintPlaces
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8
	if v_u_13 and (v_u_14 and v_u_13.places) then
		local v861 = v_u_9.color
		local v862 = v_u_9.isPhone()
		v_u_8.label({
			["parent"] = nil,
			["name"] = "PlacesHead",
			["text"] = "Places",
			["style"] = "caps",
			["textSize"] = 13,
			["color"] = nil,
			["size"] = nil,
			["valign"] = "bottom",
			["track"] = false,
			["parent"] = v_u_14,
			["color"] = v861.text2,
			["size"] = UDim2.new(1, 0, 0, 22)
		}).LayoutOrder = 2000
		for v863, v864 in v_u_13.places do
			local v865 = v862 and 20 or 22
			local v866 = v_u_8.new
			local v867 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Size"] = nil
			}
			local v868 = v864.id
			v867.Name = "Place_" .. tostring(v868)
			v867.LayoutOrder = 2000 + v863
			v867.Size = UDim2.new(1, 0, 0, v865)
			local v869 = v866("Frame", v867, v_u_14)
			local v870 = v_u_8.label
			local v871 = {
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v869
			}
			local v872 = v864.name
			v871.text = tostring(v872)
			v871.color = v861.text2
			v871.position = UDim2.fromOffset(2, 0)
			v871.size = UDim2.new(1, -52, 1, 0)
			v870(v871)
			local v873 = v_u_8.label
			local v874 = {
				["parent"] = nil,
				["name"] = "Ref",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v869
			}
			local v875 = v864.ref
			v874.text = tostring(v875)
			v874.color = v861.muted
			v874.anchor = Vector2.new(1, 0)
			v874.position = UDim2.new(1, -2, 0, 0)
			v874.size = UDim2.fromOffset(44, v865)
			v873(v874)
		end
	end
end
v_u_162 = function(p877)
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_296, (copy) v_u_44, (copy) v_u_22, (copy) v_u_30, (ref) v_u_9, (copy) v_u_272, (copy) v_u_266, (copy) v_u_281, (copy) v_u_25, (copy) v_u_26, (ref) v_u_8, (copy) v_u_316, (copy) v_u_155, (copy) v_u_2, (copy) v_u_179, (ref) v_u_164, (ref) v_u_7, (ref) v_u_444, (copy) v_u_795, (copy) v_u_860, (copy) v_u_10, (copy) v_u_876, (ref) v_u_163
	if v_u_13 and v_u_14 then
		local v878 = v_u_13.marks
		for _, v879 in v878:GetChildren() do
			v879:Destroy()
		end
		for _, v880 in v_u_14:GetChildren() do
			if not v880:IsA("GuiObject") then
				continue
			end
			v880:Destroy()
		end
		local v881 = v_u_296
		local v882, v883 = pcall(v881)
		if not v882 then
			warn("[MapUI] toggles:", v883)
		end
		local v884 = v_u_44()
		table.clear(v_u_22)
		table.clear(v_u_30)
		local v885 = v_u_13.ink
		local v_u_886 = v_u_13.k
		local v887 = v_u_13.inner
		local v888 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
		local v889 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
		local v_u_890 = v_u_9.color
		local v891 = v_u_9.isPhone()
		local v892 = os.clock()
		local v893 = v_u_9.font.headingBold
		local v894 = v_u_9.font.body
		local v895 = v_u_13.nLandmarks or 0
		local v896 = v_u_272()
		local v897 = {}
		local v_u_898 = {}
		for _, v899 in v_u_13.removable or {} do
			if v899.obj and v899.obj.Parent then
				v899.obj.Visible = v884.labels
			end
			if not v896 then
				continue
			end
			v897[v899.rect] = v899
		end
		v_u_266.stats = {
			["clean"] = 0,
			["soft"] = 0,
			["forced"] = 0,
			["hid"] = 0
		}
		table.clear(v_u_266.chips)
		table.clear(v_u_266.tags)
		table.clear(v_u_266.hidden)
		v_u_266.tmp = {}
		for v900, v901 in v_u_13.placed or {} do
			if not v884.labels and (v_u_13.nameRects and v_u_13.nameRects[v901]) then
				continue
			end
			local v902 = {
				v901[1],
				v901[2],
				v901[3],
				v901[4],
				v900 <= v895 and 6 or 1,
				v897[v901] or false
			}
			table.insert(v_u_898, v902)
		end
		if v896 then
			for _, v903 in v_u_13.reserved or {} do
				local v904 = {
					v903[1],
					v903[2],
					v903[3],
					v903[4],
					6,
					false
				}
				table.insert(v_u_898, v904)
			end
		end
		for _, v905 in p877 do
			local v906 = not v_u_13.noMap
			if v906 then
				v906 = not v_u_13.hollow or (v905.level == nil and true or v905.level == v_u_13.level)
			end
			if not v906 then
				continue
			end
			local v907 = v_u_13.toPx(v905.pos.X, v905.pos.Z)
			local v908 = v905.size.X
			local v909 = v905.size.Z
			local v910 = math.max(v908, v909) * v_u_13.scale + v_u_886 * 12
			local v911 = v_u_886 * 18
			local v912 = v_u_886 * 40
			local v913 = math.clamp(v910, v911, v912) / 2 + 2
			if v896 then
				v_u_281(v_u_898, {
					v907.X - v913,
					v907.Y - v913,
					v907.X + v913,
					v907.Y + v913
				})
			end
			local v914 = {
				v907.X - v913,
				v907.Y - v913,
				v907.X + v913,
				v907.Y + v913,
				3
			}
			table.insert(v_u_898, v914)
		end
		local function v929(p915, p916, p917, p918) -- name: overlap
			-- upvalues: (copy) v_u_898
			local v919 = 0
			for _, v920 in v_u_898 do
				local v921 = v920[3]
				local v922 = math.min(p917, v921)
				local v923 = v920[1]
				local v924 = v922 - math.max(p915, v923)
				local v925 = v920[4]
				local v926 = math.min(p918, v925)
				local v927 = v920[2]
				local v928 = v926 - math.max(p916, v927)
				if v924 <= 0 or v928 <= 0 then
					continue
				end
				v919 = v919 + v924 * v928 * (v920[5] or 1)
			end
			return v919
		end
		local v930 = v_u_886 * 14 + 0.5
		local v931 = math.floor(v930)
		local v932 = math.max(11, v931)
		local v933
		if v_u_9 then
			v933 = v_u_9.phoneText(v932, "text")
		else
			v933 = v932
		end
		local v934 = v933 / v932
		local v935 = {}
		local v936 = {}
		for v937, v_u_938 in p877 do
			local v939 = v_u_13.toPx(v_u_938.pos.X, v_u_938.pos.Z)
			local v940 = v892 < (v_u_25[v_u_938.id] or 0)
			local v941 = not v940
			if v941 then
				v941 = v892 < (v_u_26[v_u_938.id] or 0)
			end
			local v942 = v940 and "Pinged for your squad" or (v941 and "Ping cleared" or nil)
			local v_u_943 = v_u_13.hollow
			if v_u_943 then
				if v_u_938.level == nil then
					v_u_943 = false
				else
					v_u_943 = v_u_938.level ~= v_u_13.level
				end
			end
			local v944 = not v_u_13.noMap
			if v944 then
				v944 = not v_u_13.hollow or (v_u_938.level == nil and true or v_u_938.level == v_u_13.level)
			end
			if v944 then
				local v945 = v_u_938.size.X
				local v946 = v_u_938.size.Z
				local v947 = math.max(v945, v946) * v_u_13.scale + v_u_886 * 12
				local v948 = v_u_886 * 18
				local v949 = v_u_886 * 40
				local v950 = math.clamp(v947, v948, v949)
				local v951 = v_u_8.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.78,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["Name"] = "X_" .. v_u_938.id,
					["BackgroundColor3"] = v885.red,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v939.X, v939.Y),
					["Size"] = UDim2.fromOffset(v950, v950)
				}, v878)
				v_u_8.new("UICorner", {
					["CornerRadius"] = UDim.new(0.5, 0)
				}, v951)
				local v952 = v_u_8.new
				local v953 = {
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
					["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
					["Color"] = v885.red
				}
				local v954 = v_u_886 * 2.5 + 0.5
				local v955 = math.floor(v954)
				v953.Thickness = math.max(2, v955)
				local v_u_956 = v952("UIStroke", v953, v951)
				for _, v957 in { 45, -45 } do
					local v958 = v_u_8.new
					local v959 = {
						["Name"] = "Cross",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Rotation"] = nil,
						["ZIndex"] = 3,
						["BackgroundColor3"] = v885.redDeep,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5)
					}
					local v960 = UDim2.new
					local v961 = v_u_886 * 2
					local v962 = math.floor(v961)
					v959.Size = v960(0.5, 0, 0, (math.max(1, v962)))
					v959.Rotation = v957
					v958("Frame", v959, v951)
				end
				local v963 = v891 or v887 < 520
				local v964, v965
				if v963 then
					local v966 = (utf8.len(v_u_938.name) or #v_u_938.name) * v933 * 0.52 + 12
					local v967 = v934 * 150
					local v968 = math.clamp(v966, 44, v967)
					v964 = math.floor(v968)
					v965 = v933 + 7
				else
					local v969 = v_u_886 * 168
					local v970 = math.max(v969, 124)
					v964 = math.floor(v970)
					local v971 = v_u_886 * 38
					local v972 = math.max(v971, 32)
					v965 = math.floor(v972)
				end
				local v973 = 0
				local v974 = 0
				local v975 = (1 / 0)
				if v896 then
					local v976 = {
						{ v964, v965 }
					}
					if not v963 then
						local v977 = {}
						local v978 = (utf8.len(v_u_938.name) or #v_u_938.name) * v933 * 0.52 + 12
						local v979 = v934 * 150
						local v980 = math.clamp(v978, 44, v979)
						__set_list(v977, 1, {math.floor(v980), v933 + 7})
						table.insert(v976, v977)
					end
					local v981 = v_u_316(v_u_898, v878, {
						v939.X - v950 / 2,
						v939.Y - v950 / 2,
						v939.X + v950 / 2,
						v939.Y + v950 / 2
					}, v976, 4, v885.inkSoft)
					v973 = v981.x
					v974 = v981.y
					if v981.size == 2 then
						v964 = v981.w
						v965 = v981.h
						v963 = true
					end
				else
					local v982 = v950 / 2 + v_u_886 * 6
					local v983 = {}
					for v984 = 0, 1 do
						local v985 = v982 + v984 * (v965 + v_u_886 * 4)
						local v986 = v985 * 0.75
						for _, v987 in {
							{ v939.X + v985, v939.Y - v965 / 2 },
							{ v939.X - v985 - v964, v939.Y - v965 / 2 },
							{ v939.X - v964 / 2, v939.Y + v985 },
							{ v939.X - v964 / 2, v939.Y - v985 - v965 },
							{ v939.X + v986, v939.Y + v986 },
							{ v939.X - v986 - v964, v939.Y + v986 },
							{ v939.X + v986, v939.Y - v986 - v965 },
							{ v939.X - v986 - v964, v939.Y - v986 - v965 }
						} do
							table.insert(v983, v987)
						end
					end
					for v988, v989 in v983 do
						local v990 = v989[1]
						local v991 = v888 - v964 - 4
						local v992 = math.clamp(v990, 4, v991)
						local v993 = v989[2]
						local v994 = v889 - v965 - 4
						local v995 = math.clamp(v993, 4, v994)
						local v996 = v929(v992, v995, v992 + v964, v995 + v965) + v988 * 0.01
						if v996 >= v975 then
							continue
						end
						v974 = v995
						v973 = v992
						v975 = v996
					end
					local v997 = {
						v973,
						v974,
						v973 + v964,
						v974 + v965,
						4
					}
					table.insert(v_u_898, v997)
				end
				local v998 = v_u_8.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.04,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Name"] = "Tag_" .. v_u_938.id,
					["BackgroundColor3"] = v885.paperLight,
					["Position"] = UDim2.fromOffset(v973, v974),
					["Size"] = UDim2.fromOffset(v964, v965)
				}, v878)
				local v_u_999 = v_u_8.new("UIStroke", {
					["ApplyStrokeMode"] = nil,
					["BorderStrokePosition"] = nil,
					["Color"] = nil,
					["Thickness"] = 1,
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
					["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
					["Color"] = v885.red
				}, v998)
				local v1000 = v_u_8.new
				local v1001 = "TextLabel"
				local v1002 = {
					["Name"] = "Name",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Text"] = nil,
					["ZIndex"] = 5
				}
				local v1003
				if v963 then
					v1003 = UDim2.fromOffset(5, 0)
				else
					local v1004 = UDim2.fromOffset
					local v1005 = v_u_886 * 6
					local v1006 = math.max(v1005, 4)
					local v1007 = v_u_886 * 2
					v1003 = v1004(v1006, (math.max(v1007, 2)))
				end
				v1002.Position = v1003
				local v1008
				if v963 then
					v1008 = UDim2.new(1, -8, 1, 0)
				else
					local v1009 = UDim2.new
					local v1010 = v_u_886 * 10
					local v1011 = -math.max(v1010, 6)
					local v1012 = v_u_886 * 18
					v1008 = v1009(1, v1011, 0, (math.max(v1012, 15)))
				end
				v1002.Size = v1008
				v1002.FontFace = v893
				v1002.TextSize = v933
				local v1013
				if v963 and v940 then
					v1013 = v885.green
				elseif v963 and v941 then
					v1013 = v885.inkSoft
				else
					v1013 = v885.redDeep
				end
				v1002.TextColor3 = v1013
				v1002.TextXAlignment = Enum.TextXAlignment.Left
				v1002.TextTruncate = Enum.TextTruncate.AtEnd
				v1002.Text = string.upper(v_u_938.name)
				local v1014 = v1000(v1001, v1002, v998)
				if v963 and (v_u_938.ends and not v942) then
					local v1015 = v_u_155
					local v_u_1016 = string.upper(v_u_938.name)
					v1015(v1014, function()
						-- upvalues: (copy) v_u_938, (copy) v_u_1016, (ref) v_u_2
						if not v_u_938.ends then
							return v_u_1016
						end
						local v1017 = v_u_1016
						local v1018 = v_u_938.ends - v_u_2.now() + 0.5
						local v1019 = math.floor(v1018)
						local v1020 = math.max(0, v1019)
						return v1017 .. " " .. string.format("%d:%02d", v1020 // 60, v1020 % 60)
					end)
				end
				local v1021 = v_u_8.new
				local v1022 = "TextLabel"
				local v1023 = {
					["Name"] = "Cond",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Text"] = nil,
					["Visible"] = nil,
					["ZIndex"] = 5
				}
				local v1024 = UDim2.fromOffset
				local v1025 = v_u_886 * 6
				local v1026 = math.max(v1025, 4)
				local v1027 = v_u_886 * 19
				v1023.Position = v1024(v1026, (math.max(v1027, 16)))
				local v1028 = UDim2.new
				local v1029 = v_u_886 * 10
				local v1030 = -math.max(v1029, 6)
				local v1031 = v_u_886 * 16
				v1023.Size = v1028(1, v1030, 0, (math.max(v1031, 13)))
				v1023.FontFace = v894
				local v1032 = v_u_886 * 12 + 0.5
				local v1033 = math.floor(v1032)
				v1023.TextSize = math.max(10, v1033)
				local v1034
				if v940 then
					v1034 = v885.green
				else
					v1034 = v885.inkSoft
				end
				v1023.TextColor3 = v1034
				v1023.TextXAlignment = Enum.TextXAlignment.Left
				v1023.TextTruncate = Enum.TextTruncate.AtEnd
				v1023.Text = v942 or v_u_938.cond
				v1023.Visible = not v963
				local v1035 = v1021(v1022, v1023, v998)
				if v_u_938.ends and not v942 then
					local v1036 = v_u_155
					local v_u_1037 = v_u_938.cond
					v1036(v1035, function()
						-- upvalues: (copy) v_u_938, (copy) v_u_1037, (ref) v_u_2
						if not v_u_938.ends then
							return v_u_1037
						end
						local v1038 = v_u_1037
						local v1039 = v_u_938.ends - v_u_2.now() + 0.5
						local v1040 = math.floor(v1039)
						local v1041 = math.max(0, v1040)
						return v1038 .. " " .. string.format("%d:%02d", v1041 // 60, v1041 % 60)
					end)
				end
				local v1042 = v_u_9.touch(44)
				local v1043 = v939.X - v950 / 2
				local v1044 = math.min(v1043, v973)
				local v1045 = v939.Y - v950 / 2
				local v1046 = math.min(v1045, v974)
				local v1047 = v939.X + v950 / 2
				local v1048 = v973 + v964
				local v1049 = math.max(v1047, v1048)
				local v1050 = v939.Y + v950 / 2
				local v1051 = v974 + v965
				local v1052 = math.max(v1050, v1051)
				local v1053 = v_u_8.new
				local v1054 = {
					["Name"] = nil,
					["BackgroundTransparency"] = 1,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 6,
					["Name"] = "Hit_" .. v_u_938.id
				}
				local v1055 = UDim2.fromOffset
				local v1056 = v1044 - 4
				local v1057 = (v1046 + v1052) / 2 - v1042 / 2
				v1054.Position = v1055(v1056, (math.min(v1046, v1057)))
				local v1058 = UDim2.fromOffset
				local v1059 = v1049 - v1044 + 8
				local v1060 = v1052 - v1046
				v1054.Size = v1058(v1059, (math.max(v1060, v1042)))
				local v1061 = v1053("TextButton", v1054, v878)
				v1061:SetAttribute("ExtractId", v_u_938.id)
				local v1062 = {
					v1061.Position.X.Offset,
					v1061.Position.Y.Offset,
					v1061.Position.X.Offset + v1061.Size.X.Offset,
					v1061.Position.Y.Offset + v1061.Size.Y.Offset,
					v939.X,
					v939.Y
				}
				table.insert(v936, v1062)
				table.insert(v935, v1061)
				v1061.MouseEnter:Connect(function()
					-- upvalues: (copy) v_u_956, (copy) v_u_886, (copy) v_u_999, (ref) v_u_8
					local v1063 = v_u_956
					local v1064 = v_u_886 * 3.5 + 0.5
					local v1065 = math.floor(v1064)
					v1063.Thickness = math.max(3, v1065)
					v_u_999.Thickness = 2
					v_u_8.sound("hover")
				end)
				v1061.MouseLeave:Connect(function()
					-- upvalues: (copy) v_u_956, (copy) v_u_886, (copy) v_u_999
					local v1066 = v_u_956
					local v1067 = v_u_886 * 2.5 + 0.5
					local v1068 = math.floor(v1067)
					v1066.Thickness = math.max(2, v1068)
					v_u_999.Thickness = 1
				end)
				v1061.Activated:Connect(function()
					-- upvalues: (ref) v_u_179, (copy) v_u_938
					v_u_179(v_u_938)
				end)
				v_u_22[v_u_938.id] = {
					["ring"] = v951,
					["tag"] = v998,
					["hit"] = v1061
				}
			end
			local v_u_1069 = v_u_8.new("TextButton", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["LayoutOrder"] = nil,
				["Size"] = nil,
				["Name"] = "Row_" .. v_u_938.id,
				["BackgroundColor3"] = v_u_890.raised,
				["LayoutOrder"] = v937,
				["Size"] = UDim2.new(1, 0, 0, v_u_9.touch(v891 and 46 or 58))
			}, v_u_14)
			v_u_8.stroke(v_u_1069, v_u_890.line)
			local v1070 = v_u_8.new
			local v1071 = "Frame"
			local v1072 = {
				["Name"] = "Dot",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil
			}
			local v1073
			if v_u_943 then
				v1073 = v_u_890.muted
			else
				v1073 = v_u_890.danger
			end
			v1072.BackgroundColor3 = v1073
			v1072.Position = UDim2.fromOffset(10, 13)
			v1072.Size = UDim2.fromOffset(6, 6)
			v1070(v1071, v1072, v_u_1069)
			local v1074
			if v_u_943 then
				local v1075 = v_u_938.level
				v1074 = tostring(v1075) .. "  \194\183  "
			else
				v1074 = ""
			end
			local v1076 = v_u_8.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_1069,
				["text"] = v1074 .. v_u_938.name,
				["position"] = UDim2.fromOffset(24, 4),
				["size"] = UDim2.new(1, -86, 0, 20)
			})
			if v_u_943 then
				v1076.TextColor3 = v_u_890.text2
				v_u_1069:SetAttribute("Level", v_u_938.level)
			end
			local v1077 = v_u_8.label
			local v1078 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["wrap"] = nil,
				["valign"] = "top",
				["track"] = false,
				["parent"] = v_u_1069,
				["text"] = v942 or v_u_938.cond
			}
			local v1079
			if v940 then
				v1079 = v_u_890.success
			elseif v941 then
				v1079 = v_u_890.muted
			elseif v_u_943 then
				v1079 = v_u_890.muted
			else
				v1079 = v_u_890.text2
			end
			v1078.color = v1079
			v1078.position = UDim2.fromOffset(24, 23)
			v1078.size = UDim2.new(1, -86, 0, v891 and 18 or 30)
			v1078.wrap = not v891
			local v1080 = v1077(v1078)
			if v_u_938.ends and not v942 then
				local v1081 = v_u_155
				local v_u_1082 = v_u_938.cond
				v1081(v1080, function()
					-- upvalues: (copy) v_u_938, (copy) v_u_1082, (ref) v_u_2
					if not v_u_938.ends then
						return v_u_1082
					end
					local v1083 = v_u_1082
					local v1084 = v_u_938.ends - v_u_2.now() + 0.5
					local v1085 = math.floor(v1084)
					local v1086 = math.max(0, v1085)
					return v1083 .. " " .. string.format("%d:%02d", v1086 // 60, v1086 % 60)
				end)
			end
			local v_u_1087 = v_u_8.label({
				["parent"] = nil,
				["text"] = "Ping",
				["style"] = "caps",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_1069,
				["color"] = v_u_890.accent,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -10, 0.5, 0),
				["size"] = UDim2.fromOffset(56, 18)
			})
			v_u_1069.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_1069, (copy) v_u_890, (copy) v_u_1087
				v_u_1069.BackgroundColor3 = v_u_890.raised2
				v_u_1087.TextColor3 = v_u_890.text
			end)
			v_u_1069.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_1069, (copy) v_u_890, (copy) v_u_1087
				v_u_1069.BackgroundColor3 = v_u_890.raised
				v_u_1087.TextColor3 = v_u_890.accent
			end)
			v_u_1069.Activated:Connect(function()
				-- upvalues: (ref) v_u_179, (copy) v_u_938, (copy) v_u_943, (ref) v_u_164
				v_u_179(v_u_938)
				if v_u_943 and v_u_938.level then
					local v_u_1088 = v_u_938.level
					task.defer(function()
						-- upvalues: (ref) v_u_164, (copy) v_u_1088
						v_u_164(v_u_1088)
					end)
				end
			end)
		end
		local function v1089()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.MapTagPlace
		end
		local v1090, v1091 = pcall(v1089)
		if v1090 and type(v1091) == "table" then
			local v1092 = v1091.splitHits
			if type(v1092) == "function" and #v936 > 1 then
				for v1093, v1094 in v1091.splitHits(v936, v_u_9.touch(44)) do
					local v1095 = v935[v1093]
					v1095.Position = UDim2.fromOffset(v1094[1], v1094[2])
					v1095.Size = UDim2.fromOffset(v1094[3] - v1094[1], v1094[4] - v1094[2])
				end
			end
		end
		if #p877 == 0 then
			v_u_8.label({
				["parent"] = nil,
				["text"] = "No exit is marked on this map.",
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_14,
				["color"] = v_u_890.muted,
				["size"] = UDim2.new(1, 0, 0, 20)
			})
		end
		v_u_266.used = v_u_898
		v_u_444(v_u_898, v929)
		local v1096 = v_u_795
		pcall(v1096, v_u_898, v929)
		local v1097 = v_u_860
		pcall(v1097, v_u_898, v929)
		v_u_10:SetAttribute("MapLabels", ("clean %d soft %d forced %d hid %d"):format(v_u_266.stats.clean, v_u_266.stats.soft, v_u_266.stats.forced, v_u_266.stats.hid))
		if v_u_13.field then
			local v1098 = v_u_876
			pcall(v1098)
		end
		local v1099 = v_u_163
		local v1100, v1101 = pcall(v1099)
		if not v1100 then
			warn("[MapUI] waypoints:", v1101)
		end
		if v_u_13.compactKey then
			local v1102 = v_u_8.label({
				["parent"] = nil,
				["name"] = "KeyLandmark",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["valign"] = "top",
				["track"] = false,
				["parent"] = v_u_14,
				["text"] = v_u_13.hollow and "Red names are landmarks. Coloured doors need that keycard." or "Red names on the map are landmarks: more loot inside.",
				["color"] = v_u_890.text2,
				["size"] = UDim2.new(1, 0, 0, 34)
			})
			v1102.LayoutOrder = 5000
			if v_u_9.isPhone() then
				v1102.AutomaticSize = Enum.AutomaticSize.Y
			end
		end
	end
end
v_u_163 = function()
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7, (copy) v_u_27, (copy) v_u_10, (ref) v_u_17, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151, (ref) v_u_162, (ref) v_u_8, (ref) v_u_18, (copy) v_u_32, (copy) v_u_222, (copy) v_u_31, (copy) v_u_180, (copy) v_u_235
	if v_u_13 and v_u_14 then
		local v1103 = v_u_13.marks
		local v_u_1104 = v_u_9.color
		local v1105 = v_u_13.k or 1
		local v1106 = v_u_9.isPhone()
		local function v_u_1112() -- name: clearOwn
			-- upvalues: (ref) v_u_7, (ref) v_u_27, (ref) v_u_10, (ref) v_u_17, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_162
			local v1107 = v_u_7 and v_u_7.controllers
			if v1107 then
				v1107 = v_u_7.controllers.Comms
			end
			if v1107 then
				local v1108 = v1107.clearWaypoint
				if type(v1108) == "function" then
					local v1109 = v1107.clearWaypoint
					pcall(v1109)
					local v1110 = v_u_27
					v1110.cleared = v1110.cleared + 1
					v_u_10:SetAttribute("MapLastWaypoint", "cleared")
					task.defer(function()
						-- upvalues: (ref) v_u_17, (ref) v_u_134, (ref) v_u_20, (ref) v_u_151, (ref) v_u_162
						if v_u_17 then
							local v1111 = v_u_134()
							v_u_20 = v_u_151(v1111)
							v_u_162(v1111)
						end
					end)
				end
			end
		end
		local v_u_1113 = v_u_8.new("TextButton", {
			["Name"] = "WaypointCatcher",
			["BackgroundTransparency"] = 1,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = false,
			["Size"] = nil,
			["ZIndex"] = 1,
			["Size"] = UDim2.fromScale(1, 1)
		}, v1103)
		if v_u_1113:IsA("TextButton") then
			v_u_1113.Activated:Connect(function(p1114)
				-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_13, (ref) v_u_32, (copy) v_u_1113, (ref) v_u_7, (ref) v_u_10, (ref) v_u_222
				if v_u_17 and (os.clock() - v_u_18 >= 0.2 and not (v_u_13.noMap or v_u_32.ctl and v_u_32.ctl.justDragged())) then
					local v1115 = v_u_1113.AbsoluteSize
					if v1115.X >= 1 and v1115.Y >= 1 then
						local v1116 = (v_u_7.lib.UiPointer.ioAbs(p1114) - v_u_1113.AbsolutePosition) / v1115 * Vector2.new(not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0), not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0))
						v_u_10:SetAttribute("MapLastClickPx", v1116)
						v_u_222(v1116)
					end
				else
					return
				end
			end)
		end
		local v1117 = v_u_7 and v_u_7.controllers
		if v1117 then
			v1117 = v_u_7.controllers.Comms
		end
		local v1118 = {}
		local v1119
		if v1117 then
			local v1120 = v1117.waypoints
			if type(v1120) == "function" then
				local v1121 = v1117.waypoints
				local v1122
				v1122, v1119 = pcall(v1121)
				if v1122 then
					if type(v1119) ~= "table" then
						v1119 = v1118
					end
				else
					v1119 = v1118
				end
			else
				v1119 = v1118
			end
		else
			v1119 = v1118
		end
		table.sort(v1119, function(p1123, p1124)
			return (p1123.own and 0 or 1) < (p1124.own and 0 or 1)
		end)
		local v1125 = v1105 * 18 + 0.5
		local v1126 = math.floor(v1125)
		local v1127 = math.max(14, v1126)
		for v1128, v1129 in v1119 do
			local v1130 = v_u_13.toPx(v1129.pos.X, v1129.pos.Z)
			local v1131
			if v_u_13.hollow then
				local v1132 = v1129.pos.Y + 2.5
				if v_u_31.mode == "hollow" then
					local function v1133()
						-- upvalues: (ref) v_u_7
						return v_u_7.shared.HollowLevels
					end
					local v1134, v1135 = pcall(v1133)
					if not v1134 or type(v1135) ~= "table" then
						v1135 = nil
					end
					if v1135 then
						v1131 = v1135.levelOf(v1132)
					else
						v1131 = nil
					end
				else
					v1131 = nil
				end
			else
				v1131 = nil
			end
			local v1136
			if v1131 == nil then
				v1136 = false
			else
				v1136 = v1131 ~= v_u_13.level
			end
			local v1137 = not v_u_13.noMap and ((v1136 and true or false) and v_u_13.inside)
			if v1137 then
				v1137 = v_u_13.inside(v1129.pos.X, v1129.pos.Z)
			end
			local v1138 = v_u_8.new
			local v1139 = v1129.own and "TextButton" or "Frame"
			local v1140 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["Visible"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = 45,
				["ZIndex"] = 7
			}
			local v1141 = v1129.from
			v1140.Name = "WP_" .. tostring(v1141)
			local v1142
			if v1136 then
				v1142 = v_u_13.ink.inkSoft
			else
				v1142 = v_u_180
			end
			v1140.BackgroundColor3 = v1142
			v1140.BackgroundTransparency = v1136 and 0.35 or 0.1
			v1140.Visible = v1137
			v1140.AnchorPoint = Vector2.new(0.5, 0.5)
			v1140.Position = UDim2.fromOffset(v1130.X, v1130.Y)
			v1140.Size = UDim2.fromOffset(v1127, v1127)
			local v1143 = v1138(v1139, v1140, v1103)
			if v1143:IsA("TextButton") then
				v1143.Text = ""
				v1143.AutoButtonColor = false
				v1143.Activated:Connect(function()
					-- upvalues: (copy) v_u_1112
					v_u_1112()
				end)
				local v1144 = v_u_9.touch(v1127)
				if v1127 < v1144 and v1137 then
					v_u_8.new("TextButton", {
						["Name"] = "WPHit",
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 8,
						["Selectable"] = false,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromOffset(v1130.X, v1130.Y),
						["Size"] = UDim2.fromOffset(v1144, v1144)
					}, v1103).Activated:Connect(function()
						-- upvalues: (copy) v_u_1112
						v_u_1112()
					end)
				end
			end
			v_u_8.new("UIStroke", {
				["ApplyStrokeMode"] = nil,
				["BorderStrokePosition"] = nil,
				["Color"] = nil,
				["Thickness"] = 2,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
				["Color"] = v_u_13.ink.paperLight
			}, v1143)
			local v1145 = (not v1136 and "" or tostring(v1131) .. " \194\183 ") .. (v1129.own and "WAYPOINT" or string.upper(v1129.name))
			local v1146 = v1105 * 12 + 0.5
			local v1147 = math.floor(v1146)
			local v1148 = math.max(10, v1147)
			local v1149
			if v_u_9 then
				v1149 = v_u_9.phoneText(v1148, "text")
			else
				v1149 = v1148
			end
			local v1150 = v1149 / v1148
			local v1151 = (utf8.len(v1145) or #v1145) * 7.5 * math.max(v1105, 0.8) * v1150 + 12
			local v1152 = v1150 * 130
			local v1153 = math.clamp(v1151, 50, v1152)
			local v1154 = math.floor(v1153)
			local v1155 = v1105 * 18
			local v1156 = math.floor(v1155)
			local v1157 = v1150 <= 1 and 0 or v1149 + 6
			local v1158 = math.max(16, v1156, v1157)
			local v1159 = v1130.X - v1154 / 2
			local v1160 = (not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)) - v1154 - 2
			local v1161 = math.clamp(v1159, 2, v1160)
			local v1162
			if v1130.Y + v1127 + v1158 < (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)) then
				v1162 = v1130.Y + v1127 * 0.75
			else
				v1162 = v1130.Y - v1127 * 0.75 - v1158
			end
			local v1163 = v_u_8.new
			local v1164 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.04,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 7,
				["Visible"] = nil
			}
			local v1165 = v1129.from
			v1164.Name = "WPTag_" .. tostring(v1165)
			v1164.BackgroundColor3 = v_u_13.ink.paperLight
			v1164.Position = UDim2.fromOffset(v1161, v1162)
			v1164.Size = UDim2.fromOffset(v1154, v1158)
			v1164.Visible = v1137
			local v1166 = v1163("Frame", v1164, v1103)
			local v1167 = v_u_8.new
			local v1168 = "UIStroke"
			local v1169 = {
				["ApplyStrokeMode"] = nil,
				["BorderStrokePosition"] = nil,
				["Color"] = nil,
				["Thickness"] = 1,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner
			}
			local v1170
			if v1136 then
				v1170 = v_u_13.ink.inkSoft
			else
				v1170 = v_u_180
			end
			v1169.Color = v1170
			v1167(v1168, v1169, v1166)
			local v1171 = v_u_8.new
			local v1172 = "TextLabel"
			local v1173 = {
				["Name"] = "Name",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["Text"] = nil,
				["ZIndex"] = 8,
				["Position"] = UDim2.fromOffset(4, 0),
				["Size"] = UDim2.new(1, -8, 1, 0),
				["FontFace"] = v_u_9.font.headingBold,
				["TextSize"] = v1149
			}
			local v1174
			if v1136 then
				v1174 = v_u_13.ink.inkSoft
			else
				v1174 = v_u_180
			end
			v1173.TextColor3 = v1174
			v1173.TextTruncate = Enum.TextTruncate.AtEnd
			v1173.Text = v1145
			v1171(v1172, v1173, v1166)
			local v1175 = v_u_8.new
			local v1176 = v1129.own and "TextButton" or "Frame"
			local v1177 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Size"] = nil
			}
			local v1178 = v1129.from
			v1177.Name = "WPRow_" .. tostring(v1178)
			v1177.BackgroundColor3 = v_u_1104.raised
			v1177.LayoutOrder = 801 + v1128
			v1177.Size = UDim2.new(1, 0, 0, v_u_9.touch(v1106 and 38 or 44))
			local v_u_1179 = v1175(v1176, v1177, v_u_14)
			v_u_8.stroke(v_u_1179, v_u_1104.line)
			v_u_8.new("Frame", {
				["Name"] = "Dot",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Rotation"] = 45,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_1104.info,
				["Position"] = UDim2.fromOffset(10, 13),
				["Size"] = UDim2.fromOffset(7, 7)
			}, v_u_1179)
			v_u_8.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_1179,
				["text"] = v1129.own and "Your waypoint" or v1129.name,
				["position"] = UDim2.fromOffset(26, 3),
				["size"] = UDim2.new(1, -96, 0, 20)
			})
			local v1180 = v_u_8.label
			local v1181 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v_u_1179,
				["text"] = (not v1136 and "" or "On " .. tostring(v1131) .. "  \194\183  ") .. (v1129.own and "Your squad sees it" or "Squad waypoint")
			}
			local v1182
			if v1136 then
				v1182 = v_u_1104.muted
			else
				v1182 = v_u_1104.text2
			end
			v1181.color = v1182
			v1181.position = UDim2.fromOffset(26, 22)
			v1181.size = UDim2.new(1, -96, 0, 18)
			v1180(v1181)
			if not v_u_1179:IsA("TextButton") then
				continue
			end
			v_u_1179.Text = ""
			v_u_1179.AutoButtonColor = false
			local v_u_1183 = v_u_8.label({
				["parent"] = nil,
				["text"] = "Clear",
				["style"] = "caps",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_1179,
				["color"] = v_u_1104.accent,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -10, 0.5, 0),
				["size"] = UDim2.fromOffset(60, 18)
			})
			v_u_1179.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_1179, (copy) v_u_1104, (copy) v_u_1183
				v_u_1179.BackgroundColor3 = v_u_1104.raised2
				v_u_1183.TextColor3 = v_u_1104.text
			end)
			v_u_1179.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_1179, (copy) v_u_1104, (copy) v_u_1183
				v_u_1179.BackgroundColor3 = v_u_1104.raised
				v_u_1183.TextColor3 = v_u_1104.accent
			end)
			v_u_1179.Activated:Connect(function()
				-- upvalues: (copy) v_u_1112
				v_u_1112()
			end)
		end
		if #v1119 > 0 then
			v_u_8.label({
				["parent"] = nil,
				["name"] = "WPHead",
				["text"] = "Waypoints",
				["style"] = "caps",
				["textSize"] = 13,
				["color"] = nil,
				["size"] = nil,
				["valign"] = "bottom",
				["track"] = false,
				["parent"] = v_u_14,
				["color"] = v_u_1104.text2,
				["size"] = UDim2.new(1, 0, 0, 22)
			}).LayoutOrder = 800
		end
		v_u_27.sig = v_u_235()
	end
end
local function v_u_1198(p1184) -- name: ensureSheet
	-- upvalues: (copy) v_u_31, (ref) v_u_7, (ref) v_u_9, (copy) v_u_10
	if v_u_31.sheets[p1184] then
		return v_u_31.sheets[p1184]
	end
	local v1185 = v_u_31.holder
	if not (v1185 and v1185.Parent) then
		return nil
	end
	local function v1186()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.HollowMapDraw
	end
	local v1187, v1188 = pcall(v1186)
	if not (v1187 and v1188) then
		return nil
	end
	local v1189 = os.clock()
	local v1190 = v1188.build
	local v1191 = v_u_31.w
	local v1192 = v_u_31.h
	local v1193 = v_u_9.font
	local v1194, v1195 = pcall(v1190, v1185, v1191, v1192, p1184, v1193)
	if not v1194 then
		warn("[MapUI] hollow sheet " .. p1184 .. ":", v1195)
		v_u_10:SetAttribute("ClientError", "map sheet " .. p1184 .. ": " .. tostring(v1195))
		return nil
	end
	local v1196 = (os.clock() - v1189) * 1000 + 0.5
	v1195.buildMs = math.floor(v1196)
	v1195.compactKey = v_u_31.compactKey
	v_u_31.sheets[p1184] = v1195
	local v1197 = v_u_31
	v1197.built = v1197.built + 1
	return v1195
end
v_u_164 = function(p1199, p1200)
	-- upvalues: (copy) v_u_31, (copy) v_u_1198, (ref) v_u_13, (copy) v_u_27, (copy) v_u_10, (copy) v_u_32, (ref) v_u_14, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151, (ref) v_u_162
	if v_u_31.mode == "hollow" then
		local v1201 = v_u_1198(p1199)
		if v1201 then
			v_u_31.level = p1199
			for v1202, v1203 in v_u_31.sheets do
				v1203.frame.Visible = v1202 == p1199
			end
			local v1204 = v_u_13
			v_u_13 = v1201
			if v1204 ~= v1201 and v_u_27.cursorFrame then
				v_u_27.cursorFrame:Destroy()
				v_u_27.cursorFrame = nil
				v_u_27.cursorOn = false
			end
			if v_u_31.tabsApi then
				v_u_31.tabsApi.select(p1199, true)
			end
			v_u_10:SetAttribute("MapLevel", p1199)
			if v_u_32.ctl then
				v_u_32.ctl.sync()
			end
			if not p1200 and (v_u_14 and v1204 ~= v1201) then
				local v1205 = v_u_134()
				v_u_20 = v_u_151(v1205)
				v_u_162(v1205)
			end
		end
	else
		return
	end
end
local function v_u_1216(p1206) -- name: cycleLevel
	-- upvalues: (copy) v_u_31, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_164
	if v_u_31.mode == "hollow" then
		local function v1207()
			-- upvalues: (ref) v_u_7
			return v_u_7.lib.HollowMapDraw.levels()
		end
		local v1208, v1209 = pcall(v1207)
		if v1208 and (type(v1209) == "table" and #v1209 ~= 0) then
			local v1210 = 1
			for v1211, v1212 in v1209 do
				if v1212.id ~= v_u_31.level then
					continue
				end
				v1210 = v1211
			end
			local v1213 = v1210 + p1206
			local v1214 = #v1209
			local v1215 = math.clamp(v1213, 1, v1214)
			if v1209[v1215].id ~= v_u_31.level then
				v_u_8.sound(not (v_u_9.sounds and v_u_9.sounds.tab) and "click" or v_u_9.sounds.tab)
				v_u_164(v1209[v1215].id)
			end
		end
	else
		return
	end
end
local function v_u_1225(p1217) -- name: levelKey
	-- upvalues: (ref) v_u_7
	local v1218 = v_u_7 and v_u_7.controllers
	if v1218 then
		v1218 = v_u_7.controllers.Input
	end
	if v1218 then
		local v1219 = v1218.keyBinding
		if type(v1219) == "function" then
			for _, v1220 in {
				{ "camLeft", -1 },
				{ "camRight", 1 }
			} do
				local v1221 = v1218.keyBinding
				local v1222 = v1220[1]
				local v1223, v1224 = pcall(v1221, v1222)
				if not v1223 or (type(v1224) ~= "table" or not table.find(v1224, p1217.Name)) then
					continue
				end
				return v1220[2]
			end
			return 0
		end
	end
	return 0
end
local function v_u_1232(p1226, p1227, p1228) -- name: noMapSheet
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
	local v1229 = v_u_7.lib.MapDraw.INK
	local v1230 = v_u_8.new("Frame", {
		["Name"] = "Sheet_None",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v1229.paper,
		["Size"] = UDim2.fromOffset(p1227, p1228)
	}, p1226)
	v_u_8.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["BorderStrokePosition"] = nil,
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["BorderStrokePosition"] = Enum.BorderStrokePosition.Inner,
		["Color"] = v1229.paperEdge
	}, v1230)
	local v1231 = v_u_8.new("Frame", {
		["Name"] = "Area",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v1230)
	v_u_8.new("TextLabel", {
		["Name"] = "NoMap",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["Text"] = "No map of this site",
		["TextTruncate"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.46),
		["Size"] = UDim2.new(1, -40, 0, 40),
		["FontFace"] = v_u_9.font.headingBold,
		["TextColor3"] = v1229.ink,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}, v1231)
	v_u_8.new("TextLabel", {
		["Name"] = "NoMapSub",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["Text"] = "The exits are listed on the right.",
		["TextTruncate"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.46, 34),
		["Size"] = UDim2.new(1, -40, 0, 22),
		["FontFace"] = v_u_9.font.body,
		["TextColor3"] = v1229.inkSoft,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}, v1231)
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["placed"] = nil,
		["nLandmarks"] = 0,
		["scale"] = 0.01,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["noMap"] = true,
		["frame"] = v1230,
		["area"] = v1231,
		["marks"] = v_u_8.new("Frame", {
			["Name"] = "Marks",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 12,
			["Size"] = UDim2.fromScale(1, 1)
		}, v1231),
		["toPx"] = function(_, _) -- name: toPx
			return Vector2.new(-1000, -1000)
		end,
		["toWorld"] = function(_, _) -- name: toWorld
			return Vector2.zero
		end,
		["placed"] = {},
		["k"] = math.min(p1227, p1228) / 880,
		["ink"] = v1229,
		["inner"] = math.min(p1227, p1228),
		["innerW"] = p1227,
		["innerH"] = p1228
	}
end
function v_u_6.zoomKey() -- name: zoomKey
	-- upvalues: (ref) v_u_7, (copy) v_u_31
	local v1233 = v_u_7.shared.MapZoomRule.key
	local v1234 = v_u_31.mapId
	local v1235
	if v_u_31.mode == "hollow" then
		v1235 = v_u_31.level
	else
		v1235 = nil
	end
	return v1233(v1234, v1235)
end
function v_u_6.zoomState() -- name: zoomState
	-- upvalues: (copy) v_u_32
	if v_u_32.ctl then
		return v_u_32.ctl.state()
	else
		return nil
	end
end
function v_u_6.zoomBy(p1236) -- name: zoomBy
	-- upvalues: (copy) v_u_32
	if v_u_32.ctl then
		v_u_32.ctl.zoomBy(p1236)
	end
end
function v_u_6.setZoom(p1237) -- name: setZoom
	-- upvalues: (copy) v_u_32
	if v_u_32.ctl then
		v_u_32.ctl.setZoom(p1237)
	end
end
function v_u_6.zoomReset() -- name: zoomReset
	-- upvalues: (copy) v_u_32
	if v_u_32.ctl then
		v_u_32.ctl.reset()
	end
end
function v_u_6.zoomMe() -- name: zoomMe
	-- upvalues: (copy) v_u_32
	if v_u_32.ctl then
		v_u_32.ctl.centerMe()
	end
end
function v_u_6.keyRows(p1238, p1239, p1240, p1241, p1242) -- name: keyRows
	-- upvalues: (copy) v_u_180, (copy) v_u_181
	if p1238 == "hollow" and p1241 then
		return {
			{ p1239.landmark, "Landmark" },
			{ p1239.paperLight, "Room, tunnel" },
			{ p1239.water, "Water" },
			{ p1241.TIER.green, "Keycard door" },
			{ p1241.POWER_INK, "Needs power" },
			{ p1239.red, "Marked exit" },
			{ v_u_180, "Waypoint" }
		}
	end
	local v1243 = {}
	local v1244 = { p1239.landmark, "Landmark" }
	local v1245 = { p1239.build, "Building" }
	local v1246 = { p1239.forest, "Woods" }
	local v1247
	if p1238 == "field" then
		if p1242 == "unknown5" then
			v1247 = { p1239.rock or p1239.tarmac, "Rock" }
		elseif p1242 == "overture" or p1242 == "tokyo" then
			v1247 = { p1239.water, "Water" }
		else
			v1247 = { p1239.tarmac, "Runway" }
		end
	else
		v1247 = { p1239.water, "River" }
	end
	__set_list(v1243, 1, {v1244, v1245, v1246, v1247, { p1239.road, "Road" }, { p1239.red, "Marked exit" }, { v_u_180, "Waypoint" }})
	if p1240 and (p1238 == "town" or p1238 == "field") then
		local v1248 = { v_u_181, "You, squad" }
		table.insert(v1243, v1248)
	end
	return v1243
end
local function v_u_1446() -- name: build
	-- upvalues: (copy) v_u_242, (ref) v_u_9, (ref) v_u_8, (ref) v_u_11, (copy) v_u_10, (copy) v_u_31, (copy) v_u_58, (ref) v_u_7, (ref) v_u_17, (ref) v_u_18, (copy) v_u_6, (ref) v_u_12, (ref) v_u_13, (copy) v_u_69, (copy) v_u_27, (copy) v_u_32, (ref) v_u_164, (copy) v_u_1232, (copy) v_u_29, (copy) v_u_33, (copy) v_u_44, (ref) v_u_14, (copy) v_u_16, (ref) v_u_15, (ref) v_u_20, (copy) v_u_134, (copy) v_u_151, (ref) v_u_162
	v_u_242()
	local v1249 = v_u_9.color
	local v_u_1250 = v_u_9.refSize()
	local v1251 = v_u_9.isPhone() or v_u_1250.Y < 600
	local v_u_1252, v1253 = v_u_8.screen("HushMap", 30, {
		["enabled"] = false
	})
	v_u_11 = v_u_1252
	local function v1270()
		-- upvalues: (ref) v_u_9, (copy) v_u_1252, (ref) v_u_10, (ref) v_u_1250
		local v1254 = v_u_9.uiScale()
		local v1255 = v_u_1252.AbsoluteSize
		local v1256
		if v_u_10:GetAttribute("MapDevNoCap") == true then
			v1256 = game:GetService("RunService"):IsStudio()
		else
			v1256 = false
		end
		if v1254 > 0 and (v1255.X > 1 and (v1255.Y > 1 and not v1256)) then
			local v1257 = Vector2.new
			local v1258 = v_u_1250.X
			local v1259 = v1255.X / v1254
			local v1260 = math.min(v1258, v1259)
			local v1261 = v_u_1250.Y
			local v1262 = v1255.Y / v1254
			v_u_1250 = v1257(v1260, (math.min(v1261, v1262)))
		end
		local v1263 = v_u_9.safeRefSize()
		local v1264 = Vector2.new
		local v1265 = v_u_1250.X
		local v1266 = v1263.X
		local v1267 = math.min(v1265, v1266)
		local v1268 = v_u_1250.Y
		local v1269 = v1263.Y
		v_u_1250 = v1264(v1267, (math.min(v1268, v1269)))
	end
	pcall(v1270)
	v_u_31.mapId = v_u_58()
	local function v1271()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.HollowMapDraw
	end
	local v1272, v1273 = pcall(v1271)
	local function v1274()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.KestrelMapDraw
	end
	local v1275, v1276 = pcall(v1274)
	if v1275 then
		if v1276 == nil then
			v1275 = false
		else
			v1275 = v1276.available()
		end
	end
	local function v1277()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.AshgroveMapDraw
	end
	local v1278, v1279 = pcall(v1277)
	if v1278 then
		if v1279 == nil then
			v1278 = false
		else
			v1278 = v1279.available()
		end
	end
	local function v1280()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.OvertureMapDraw
	end
	local v1281, v1282 = pcall(v1280)
	if v1281 then
		if v1282 == nil then
			v1281 = false
		else
			v1281 = v1282.available()
		end
	end
	local function v1283()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.TokyoMapDraw
	end
	local v1284, v1285 = pcall(v1283)
	if v1284 then
		if v1285 == nil then
			v1284 = false
		else
			v1284 = v1285.available()
		end
	end
	if v_u_31.mapId == "unknown5" then
		v1276 = v1279
	elseif v_u_31.mapId == "overture" then
		v1276 = v1282
	elseif v_u_31.mapId == "tokyo" then
		v1276 = v1285
	end
	v_u_31.mode = v_u_31.mapId == "stillwater" and "town" or (v_u_31.mapId == "hollow" and (v1272 and (v1273 and v1273.available())) and "hollow" or ((v_u_31.mapId == "kestrel" and v1275 or (v_u_31.mapId == "unknown5" and v1278 or v_u_31.mapId == "overture" and v1281)) and "field" or (v_u_31.mapId == "tokyo" and v1284 and "field" or "none")))
	v_u_10:SetAttribute("MapMode", v_u_31.mode)
	local v1286 = v_u_31.mode == "hollow"
	local v1287 = v_u_31.mode == "field"
	if v1286 then
		local v1288 = v_u_31
		local function v1289()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.HollowLevels
		end
		local v1290, v1291 = pcall(v1289)
		if not v1290 or type(v1291) ~= "table" then
			v1291 = nil
		end
		local v1292 = v_u_10.Character
		if v1292 then
			v1292 = v1292:FindFirstChild("HumanoidRootPart")
		end
		local v1293
		if v1291 and (v1292 and v1292:IsA("BasePart")) then
			v1293 = v1291.levelOf(v1292.Position.Y)
		else
			v1293 = nil
		end
		v1288.level = v1293 or v_u_31.level
	end
	local v1294 = v_u_8.device() == "Touch"
	local v1295 = v1251 and 8 or 24
	local v1296 = v_u_7.shared.MapLayoutRule
	local v1297, v1298 = v1296.closeSize(v1294, v1251, v_u_9.uiScale())
	local _, v1299 = v1296.closePlace(0, v1295, v1251, v1297, v1298)
	local v1300
	if v1251 then
		v1300 = 0
	else
		local v1301 = v1299 + v1298 + 4
		v1300 = math.max(56, v1301)
	end
	local v1302 = not v1251 and 0 or v1296.sideHeadH(v1251, v1299, v1298)
	local v1303 = v1251 and 220 or 320
	local v1304 = not v1286 and 0 or v_u_9.touch(v1251 and 36 or 40) + 6
	local v1305 = v_u_1250.Y - v1295 * 2 - v1300 - (v1251 and 0 or v1295) - v1304
	local v1306 = v_u_1250.X - v1295 * 4 - v1303
	local v1307 = math.min(v1305, v1306, 980)
	local v1308 = math.max(220, v1307)
	local v1309 = math.floor(v1308)
	local v1310 = v_u_1250.X - v1309 - v1295 * 5
	local v1311 = math.clamp(v1310, v1303, v1251 and 380 or 340)
	local v1312 = math.floor(v1311)
	local v1313, v1314
	if v1286 then
		local v1315 = v_u_1250.X * (v1251 and 0.22 or 0.2)
		local v1316 = math.clamp(v1315, v1251 and 220 or 260, 340)
		v1312 = math.floor(v1316)
		local v1317 = v_u_1250.X - v1312 - v1295 * 5
		local v1318 = math.clamp(v1317, 320, 1500)
		v1313 = math.floor(v1318)
		local v1319 = math.clamp(v1305, 220, 980)
		v1314 = math.floor(v1319)
	else
		v1314 = v1309
		v1313 = v1314
		local v1320 = v1314
		v1314 = v1313
		v1320 = v1313
	end
	local v1321 = v1313 + v1312 + v1295 * 3
	local v1322
	if v1251 then
		v1322 = v1295
	else
		v1322 = v1300 + v1295 / 2
	end
	local v1323 = v1322 + v1304
	local v1324 = v1323 + v1314 + v1295
	v_u_8.new("TextButton", {
		["Name"] = "OutsideTap",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v1253).Activated:Connect(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_6
		if v_u_17 and os.clock() - v_u_18 > 0.3 then
			v_u_6.close()
		end
	end)
	local v1325, v1326 = v_u_8.panel({
		["parent"] = nil,
		["name"] = "MapPanel",
		["size"] = nil,
		["anchor"] = nil,
		["position"] = nil,
		["accent"] = true,
		["padding"] = false,
		["parent"] = v1253,
		["size"] = UDim2.fromOffset(v1321, v1324),
		["anchor"] = Vector2.new(0.5, 0.5),
		["position"] = UDim2.fromScale(0.5, 0.5)
	})
	v_u_12 = v1325
	local v1327
	if v1251 then
		v1327 = v1295 * 2 + v1313
	else
		v1327 = v1295
	end
	local v1328
	if v1286 then
		v1328 = "Site map"
	elseif v1287 then
		v1328 = v_u_31.mapId == "unknown5" and "District map" or (v_u_31.mapId == "overture" and "Plaza map" or (v_u_31.mapId == "tokyo" and "City map" or "Field map"))
	else
		v1328 = v_u_31.mode == "none" and "Map" or "Town map"
	end
	local v1329 = v_u_8.label
	local v1330 = {
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v1326,
		["text"] = v1328,
		["style"] = v1251 and "h3" or "h2",
		["position"] = UDim2.fromOffset(v1327, not v1251 and 12 or v1295 + 4)
	}
	local v1331 = UDim2.fromOffset
	local v1332
	if v1251 then
		local v1333 = v1312 - v1297 - 6
		v1332 = math.max(60, v1333)
	else
		v1332 = 240
	end
	v1330.size = v1331(v1332, v1251 and 24 or 30)
	v1329(v1330)
	if not v1251 then
		local v1334 = v_u_8.label
		local v1335 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v1326
		}
		local v1336
		if v_u_31.mode == "none" then
			v1336 = "A paper map: your position is not on it. Read the buildings around you."
		else
			local v1337 = v_u_7 and v_u_7.shared
			if v1337 then
				v1337 = v_u_7.shared.Config
			end
			if v1337 then
				v1337 = v1337.MAP_SHOW_POSITION == false
			end
			v1336 = v1337 and "A paper map: your position is not on it. Read the buildings around you." or "A paper map: you are the blue dot, your squad shows as coloured dots."
		end
		v1335.text = v1336
		v1335.color = v1249.text2
		v1335.position = UDim2.fromOffset(v1295 + 150, 18)
		v1335.size = UDim2.new(1, -(v1295 + 150 + 170), 0, 20)
		v1334(v1335)
	end
	local v1338, v1339 = v1296.closePlace(v1321, v1295, v1251, v1297, v1298)
	v_u_8.button({
		["parent"] = nil,
		["name"] = "CloseMap",
		["text"] = "Close",
		["kind"] = "close",
		["icon"] = "close",
		["hint"] = nil,
		["position"] = nil,
		["height"] = nil,
		["width"] = nil,
		["onClick"] = nil,
		["parent"] = v1326,
		["hint"] = not v1294 and "map" or nil,
		["position"] = UDim2.fromOffset(v1338, v1339),
		["height"] = v1298,
		["width"] = v1297,
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_6
			v_u_6.close()
		end
	}).ZIndex = 30
	local v1340 = v_u_8.new("Frame", {
		["Name"] = "SheetHolder",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v1295, v1323),
		["Size"] = UDim2.fromOffset(v1313, v1314)
	}, v1326)
	local function v1341()
		-- upvalues: (ref) v_u_7
		return v_u_7.lib.MapZoom
	end
	local v1342, v1343 = pcall(v1341)
	local v1344
	if v1342 and type(v1343) == "table" then
		local v1345 = v1343.new
		local v1346 = {
			["holder"] = v1340,
			["W"] = v1313,
			["H"] = v1314,
			["UI"] = v_u_8,
			["Theme"] = v_u_9,
			["UiPointer"] = v_u_7.lib.UiPointer,
			["VirtualPad"] = v_u_7.lib.VirtualPad,
			["key"] = v_u_6.zoomKey,
			["sheet"] = function() -- name: sheet
				-- upvalues: (ref) v_u_13
				return v_u_13
			end,
			["isOpen"] = function() -- name: isOpen
				-- upvalues: (ref) v_u_17
				return v_u_17
			end,
			["own"] = v_u_69,
			["cursor"] = function() -- name: cursor
				-- upvalues: (ref) v_u_27
				if v_u_27.cursorOn then
					return v_u_27.cursor
				else
					return nil
				end
			end
		}
		local v1347, v1348 = pcall(v1345, v1346)
		if v1347 and type(v1348) == "table" then
			v_u_32.ctl = v1348
			v1344 = v1348.layer
		else
			warn("[MapUI] zoom:", v1348)
			v1344 = v1340
		end
	else
		v1344 = v1340
	end
	if v1286 then
		local v1349 = {}
		for _, v1350 in v1273.levels() do
			local v1351 = {
				["id"] = v1350.id,
				["text"] = v1350.id .. "  " .. v1350.short
			}
			table.insert(v1349, v1351)
		end
		local _, v1353 = v_u_8.tabs({
			["parent"] = nil,
			["name"] = "LevelTabs",
			["tabs"] = nil,
			["selected"] = nil,
			["size"] = nil,
			["position"] = nil,
			["onChange"] = nil,
			["parent"] = v1326,
			["tabs"] = v1349,
			["selected"] = v_u_31.level,
			["size"] = UDim2.fromOffset(v1313, v1304 - 6),
			["position"] = UDim2.fromOffset(v1295, v1323 - v1304),
			["onChange"] = function(p1352) -- name: onChange
				-- upvalues: (ref) v_u_164
				v_u_164(p1352)
			end
		})
		v_u_31.tabsApi = v1353
		v_u_31.holder = v1344
		local v1354 = v_u_31
		v_u_31.w = v1313
		v1354.h = v1314
		v_u_13 = nil
		v_u_31.compactKey = v1251
		v_u_164(v_u_31.level, true)
		if not v_u_13 then
			v_u_31.mode = "none"
			v_u_10:SetAttribute("MapMode", "none")
			v_u_13 = v_u_1232(v1340, v1313, v1314)
		end
	elseif v_u_31.mode == "none" then
		v_u_13 = v_u_1232(v1340, v1313, v1314)
	elseif v1287 then
		local v_u_1355 = nil
		local function v1356()
			-- upvalues: (ref) v_u_1355, (ref) v_u_7
			v_u_1355 = v_u_7.shared.MapInfo.fromRuntime()
		end
		pcall(v1356)
		local v1357 = v1276.build
		local v1358 = v_u_1355
		local v1359 = v_u_9.font
		local v1360, v1361 = pcall(v1357, v1344, v1309, v1358, v1359)
		if v1360 then
			v_u_13 = v1361
		else
			warn("[MapUI] field sheet:", v1361)
			v_u_10:SetAttribute("ClientError", "map field sheet: " .. tostring(v1361))
			v_u_31.mode = "none"
			v_u_10:SetAttribute("MapMode", "none")
			v_u_13 = v_u_1232(v1340, v1313, v1314)
		end
	else
		local v1362 = v_u_7.lib.MapDraw
		local v_u_1363 = v_u_7.shared.MapInfo
		local v_u_1364 = nil
		local function v1365()
			-- upvalues: (ref) v_u_1364, (copy) v_u_1363
			v_u_1364 = v_u_1363.fromRuntime()
		end
		pcall(v1365)
		v_u_13 = v1362.build(v1344, v1309, v_u_1364, v_u_9.font)
	end
	if v_u_32.ctl then
		v_u_32.ctl.sync()
	end
	local v1366 = math.min(v1313, v1314)
	local v1367 = v_u_29
	local v1368 = {}
	local v1369 = (v1313 - v1366) / 2
	v1368.x = v1295 + math.floor(v1369)
	local v1370 = (v1314 - v1366) / 2
	v1368.y = v1323 + math.floor(v1370)
	v1368.s = v1366
	v1368.parent = v1326
	v1367.rect = v1368
	v_u_29.card = nil
	local v1371 = v1323 + v1302 - v1304
	local v1372 = v_u_8.new("Frame", {
		["Name"] = "Side",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v1295 * 2 + v1313, v1371),
		["Size"] = UDim2.fromOffset(v1312, v1314 + v1304 - v1302)
	}, v1326)
	local v1373 = 0
	v_u_33.bar = nil
	local v1374 = v_u_7 and v_u_7.shared
	if v1374 then
		v1374 = v_u_7.shared.Config
	end
	local v1375 = false
	local function v1376()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapToggleRule
	end
	local v1377, v1378 = pcall(v1376)
	if not v1377 or type(v1378) ~= "table" then
		v1378 = nil
	end
	if v1378 ~= nil then
		if v1374 then
			local v1379 = v1374.flag
			if type(v1379) == "function" then
				v1374 = v1374.flag("MapToggles") == false
			else
				v1374 = false
			end
		end
		v1375 = not v1374
	end
	if v1375 then
		local function v1380()
			-- upvalues: (ref) v_u_7
			return v_u_7.lib.MapToggleBar
		end
		local v1381, v1382 = pcall(v1380)
		if v1381 and type(v1382) == "table" then
			local v1383 = v1382.build
			local v1384 = {
				["parent"] = v1372,
				["UI"] = v_u_8,
				["Theme"] = v_u_9
			}
			local function v1385()
				-- upvalues: (ref) v_u_7
				return v_u_7.shared.MapToggleRule
			end
			local v1386, v1387 = pcall(v1385)
			if not v1386 or type(v1387) ~= "table" then
				v1387 = nil
			end
			v1384.Rule = v1387
			v1384.width = v1312
			v1384.device = v_u_8.device()
			v1384.phone = v1251
			function v1384.get(p1388) -- name: get
				-- upvalues: (ref) v_u_44
				return v_u_44()[p1388] == true
			end
			function v1384.press(p1389) -- name: press
				-- upvalues: (ref) v_u_6, (ref) v_u_44
				v_u_6.setToggle(p1389, not v_u_44()[p1389])
			end
			local v1390, v1391 = pcall(v1383, v1384)
			if v1390 and type(v1391) == "table" then
				v_u_33.bar = v1391
				v1373 = v1391.height + 8
			else
				warn("[MapUI] toggle bar:", v1391)
			end
		end
	end
	v_u_8.label({
		["parent"] = nil,
		["text"] = "Marked exits",
		["style"] = "caps",
		["textSize"] = 14,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v1372,
		["color"] = v1249.text2,
		["position"] = UDim2.fromOffset(0, v1373),
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v1392 = v_u_8.device()
	local v1393 = v1294 and "Tap" or (v1392 == "Gamepad" and "Select" or "Click")
	local v1394
	if v1392 == "Gamepad" then
		local v1395 = "Stick: map cursor, "
		local v1396 = v_u_7 and v_u_7.controllers
		if v1396 then
			v1396 = v_u_7.controllers.Input
		end
		local v1397
		if v1396 then
			local v1398 = v1396.hint
			if type(v1398) == "function" then
				local v1399 = v1396.hint
				local v1400, v1401 = pcall(v1399, "reload")
				v1397 = (not v1400 or (type(v1401) ~= "string" or v1401 == "")) and "Button" or v1401
			else
				v1397 = "Button"
			end
		else
			v1397 = "Button"
		end
		v1394 = v1395 .. v1397 .. ": set or clear your waypoint."
	else
		v1394 = v1393 .. " anywhere else to set your waypoint, again to clear it."
	end
	local v1402
	if v1286 then
		if v1294 then
			v1402 = " Tap a level tab to see another level."
		elseif v1392 == "Gamepad" then
			v1402 = " Shoulder buttons: the other levels."
		else
			local v1403 = v_u_7 and v_u_7.controllers
			if v1403 then
				v1403 = v_u_7.controllers.Input
			end
			local v1404 = ""
			local v1405 = ""
			if v1403 then
				local v1406 = v1403.hint
				if type(v1406) == "function" then
					local v1407 = v1403.hint
					local v1408, v1409 = pcall(v1407, "camLeft")
					local v1410 = v1403.hint
					local v1411
					v1411, v1405 = pcall(v1410, "camRight")
					v1404 = (not v1408 or type(v1409) ~= "string") and "" or v1409
					if not v1411 or type(v1405) ~= "string" then
						v1405 = ""
					end
				end
			end
			v1402 = (v1404 == "" or v1405 == "") and " Click a level tab to see another level." or (" %s / %s or the tabs: other levels."):format(v1404, v1405)
		end
	else
		v1402 = ""
	end
	local v1412
	if v1251 then
		v1412 = v1286 and 86 or 50
	else
		v1412 = v1286 and (v1312 < 300 and 86 or 70) or 52
	end
	local v1413 = v_u_8.label
	local v1414 = {
		["parent"] = nil,
		["name"] = "Note",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["track"] = false,
		["parent"] = v1372
	}
	local v1415
	if v_u_31.mode == "none" then
		v1415 = v1393 .. " an exit to ping it for your squad."
	else
		v1415 = v1393 .. " an exit to ping it for your squad. " .. v1394
	end
	v1414.text = v1415 .. v1402
	v1414.color = v1249.muted
	v1414.position = UDim2.fromOffset(0, v1373 + 22)
	v1414.size = UDim2.new(1, 0, 0, v1412)
	local v1416 = v1413(v1414)
	local v1417
	if v1286 then
		v1417 = v1412 + 22 + 6
	else
		v1417 = v1251 and 74 or 80
	end
	local v1418 = v1417 + v1373
	local v1419 = (v1251 or v_u_31.mode == "none") and 0 or 182
	if v_u_33.bar and (v1251 and (v1419 == 0 and v_u_31.mode ~= "none")) then
		local _, v1420 = v1296.sideSplit(v1314 + v1304 - v1302 - v1418 - v1419, true, true)
		if v1420 < 149.5 then
			v1416.Visible = false
			v1418 = v1373 + 22 + 2
		end
	end
	v_u_14 = v_u_8.list({
		["parent"] = nil,
		["name"] = "Exits",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 6,
		["parent"] = v1372,
		["position"] = UDim2.fromOffset(0, v1418),
		["size"] = UDim2.new(1, 0, 1, -(v1418 + v1419))
	})
	local v1421 = v_u_16
	local v1422 = v_u_16
	local v1423 = v_u_16
	v_u_16.free = v1314 + v1304 - v1302 - v1418 - v1419
	v1421.top = v1418
	v1422.keyH = v1419
	v1423.phone = v1251
	local v1424 = v_u_16
	if v1251 then
		if v1419 == 0 then
			v1251 = v_u_31.mode ~= "none"
		else
			v1251 = false
		end
	end
	v1424.split = v1251
	if v_u_16.split then
		local v1425 = v_u_8.list({
			["parent"] = nil,
			["name"] = "Tasks",
			["position"] = nil,
			["size"] = nil,
			["gap"] = 6,
			["parent"] = v1372,
			["position"] = UDim2.fromOffset(0, v1418 + v_u_16.free),
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v1425.Visible = false
		v_u_15 = v1425
	end
	if v1419 > 0 then
		local v1426 = v_u_8.new("Frame", {
			["Name"] = "Key",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, v1419 - 8)
		}, v1372)
		v_u_8.divider({
			["parent"] = v1426,
			["size"] = UDim2.new(1, 0, 0, 1)
		})
		v_u_8.label({
			["parent"] = nil,
			["text"] = "Key",
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v1426,
			["color"] = v1249.muted,
			["position"] = UDim2.fromOffset(0, 8),
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		local v1427 = v_u_13.ink
		local v1428 = v_u_6.keyRows
		local v1429 = v_u_31.mode
		local v1430 = v_u_7 and v_u_7.shared
		if v1430 then
			v1430 = v_u_7.shared.Config
		end
		if v1430 then
			v1430 = v1430.MAP_SHOW_POSITION == false
		end
		local v1431 = not v1430
		if not v1286 then
			v1273 = nil
		end
		local v1432 = 0
		for v1433, v1434 in v1428(v1429, v1427, v1431, v1273, v_u_31.mapId) do
			local v1435 = (v1433 - 1) % 2
			local v1436 = (v1433 - 1) / 2
			local v1437 = math.floor(v1436)
			v1432 = v1437 + 1
			local v1438 = v1435 * (v1312 / 2)
			local v1439 = 30 + v1437 * 28
			local v1440 = v_u_8.new("Frame", {
				["Name"] = "Swatch",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v1434[1],
				["Position"] = UDim2.fromOffset(v1438, v1439 + 3),
				["Size"] = UDim2.fromOffset(18, 14)
			}, v1426)
			v_u_8.stroke(v1440, v1249.lineStrong)
			v_u_8.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v1426,
				["name"] = "Key_" .. v1434[2],
				["text"] = v1434[2],
				["color"] = v1249.text2,
				["position"] = UDim2.fromOffset(v1438 + 26, v1439),
				["size"] = UDim2.fromOffset(v1312 / 2 - 30, 20)
			})
		end
		local v1441 = 30 + v1432 * 28
		local v1442 = v_u_8.new("Frame", {
			["Name"] = "RedNameChip",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v1427.paperLight,
			["Position"] = UDim2.fromOffset(0, v1441 + 1),
			["Size"] = UDim2.fromOffset(52, 18)
		}, v1426)
		v_u_8.stroke(v1442, v1249.lineStrong)
		v_u_8.new("TextLabel", {
			["Name"] = "Sample",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["Text"] = "NAME",
			["TextTruncate"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_9.font.headingBold,
			["TextColor3"] = v1427.redDeep,
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		}, v1442)
		v_u_8.label({
			["parent"] = nil,
			["name"] = "Key_RedNames",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v1426,
			["text"] = v1286 and "Red name = landmark of the site" or "Red name = landmark: more loot inside",
			["color"] = v1249.text2,
			["position"] = UDim2.fromOffset(60, v1441),
			["size"] = UDim2.new(1, -60, 0, 20)
		})
	end
	local v1443 = v_u_13
	local v1444
	if v1419 <= 0 then
		v1444 = v_u_31.mode ~= "none"
	else
		v1444 = false
	end
	v1443.compactKey = v1444
	v_u_31.compactKey = v_u_13.compactKey
	v_u_20 = ""
	local v1445 = v_u_134()
	v_u_20 = v_u_151(v1445)
	v_u_162(v1445)
end
local function v_u_1501() -- name: mapHintLines
	-- upvalues: (ref) v_u_8, (ref) v_u_7
	local v1447 = v_u_8.device()
	if v1447 == "Touch" then
		local v1448 = {}
		local v1449 = "The MAP button opens and closes the map."
		local v1450 = "Tap a marked exit to ping it for your squad."
		local v1451 = "Tap anywhere else to set your waypoint, tap it again to clear it."
		local v1452 = "Quick comms: the "
		local v1453 = string.upper
		local v1454 = v_u_7 and v_u_7.controllers
		if v1454 then
			v1454 = v_u_7.controllers.Input
		end
		local v1455
		if v1454 then
			local v1456 = v1454.hint
			if type(v1456) == "function" then
				local v1457 = v1454.hint
				local v1458, v1459 = pcall(v1457, "ping")
				v1455 = (not v1458 or (type(v1459) ~= "string" or v1459 == "")) and "More" or v1459
			else
				v1455 = "More"
			end
		else
			v1455 = "More"
		end
		__set_list(v1448, 1, {v1449, v1450, v1451, v1452 .. v1453(v1455) .. " button, calls for your squad."})
		return v1448
	end
	if v1447 ~= "Gamepad" then
		local v1460 = {}
		local v1461 = v_u_7 and v_u_7.controllers
		if v1461 then
			v1461 = v_u_7.controllers.Input
		end
		local v1462
		if v1461 then
			local v1463 = v1461.hint
			if type(v1463) == "function" then
				local v1464 = v1461.hint
				local v1465, v1466 = pcall(v1464, "map")
				v1462 = (not v1465 or (type(v1466) ~= "string" or v1466 == "")) and "the map key" or v1466
			else
				v1462 = "the map key"
			end
		else
			v1462 = "the map key"
		end
		local v1467 = v1462 .. " opens and closes the map."
		local v1468 = "Click a marked exit to ping it for your squad."
		local v1469 = "Click anywhere else to set your waypoint, click it again to clear it."
		local v1470 = "Quick comms: hold "
		local v1471 = v_u_7 and v_u_7.controllers
		if v1471 then
			v1471 = v_u_7.controllers.Input
		end
		local v1472
		if v1471 then
			local v1473 = v1471.hint
			if type(v1473) == "function" then
				local v1474 = v1471.hint
				local v1475, v1476 = pcall(v1474, "ping")
				v1472 = (not v1475 or (type(v1476) ~= "string" or v1476 == "")) and "ping" or v1476
			else
				v1472 = "ping"
			end
		else
			v1472 = "ping"
		end
		__set_list(v1460, 1, {v1467, v1468, v1469, v1470 .. v1472 .. " for the call wheel."})
		return v1460
	end
	local v1477 = {}
	local v1478 = v_u_7 and v_u_7.controllers
	if v1478 then
		v1478 = v_u_7.controllers.Input
	end
	local v1479
	if v1478 then
		local v1480 = v1478.hint
		if type(v1480) == "function" then
			local v1481 = v1478.hint
			local v1482, v1483 = pcall(v1481, "map")
			v1479 = (not v1482 or (type(v1483) ~= "string" or v1483 == "")) and "View" or v1483
		else
			v1479 = "View"
		end
	else
		v1479 = "View"
	end
	local v1484 = v1479 .. " opens and closes the map."
	local v1485 = "Select a marked exit to ping it for your squad."
	local v1486 = "The stick moves the map cursor, "
	local v1487 = v_u_7 and v_u_7.controllers
	if v1487 then
		v1487 = v_u_7.controllers.Input
	end
	local v1488
	if v1487 then
		local v1489 = v1487.hint
		if type(v1489) == "function" then
			local v1490 = v1487.hint
			local v1491, v1492 = pcall(v1490, "reload")
			v1488 = (not v1491 or (type(v1492) ~= "string" or v1492 == "")) and "Button" or v1492
		else
			v1488 = "Button"
		end
	else
		v1488 = "Button"
	end
	local v1493 = v1486 .. v1488 .. " sets or clears your waypoint."
	local v1494 = "Quick comms: hold "
	local v1495 = v_u_7 and v_u_7.controllers
	if v1495 then
		v1495 = v_u_7.controllers.Input
	end
	local v1496
	if v1495 then
		local v1497 = v1495.hint
		if type(v1497) == "function" then
			local v1498 = v1495.hint
			local v1499, v1500 = pcall(v1498, "ping")
			v1496 = (not v1499 or (type(v1500) ~= "string" or v1500 == "")) and "LB" or v1500
		else
			v1496 = "LB"
		end
	else
		v1496 = "LB"
	end
	__set_list(v1477, 1, {v1484, v1485, v1493, v1494 .. v1496 .. " for the call wheel."})
	return v1477
end
local function v_u_1504() -- name: markHintSeen
	-- upvalues: (copy) v_u_29, (copy) v_u_10, (ref) v_u_7
	if v_u_29.seen ~= true then
		v_u_29.seen = true
		v_u_10:SetAttribute("MapHintSeen", true)
		if v_u_7 and v_u_7.net then
			local v1502 = v_u_7.net.fire
			if type(v1502) == "function" then
				task.spawn(function()
					-- upvalues: (ref) v_u_7
					local v1503 = v_u_7.net.fire
					pcall(v1503, "menu.op", {
						["op"] = "setting",
						["key"] = "mapHintSeen",
						["value"] = true
					})
				end)
			end
		end
	end
end
local function v_u_1527() -- name: showMapHint
	-- upvalues: (copy) v_u_29, (ref) v_u_9, (copy) v_u_1501, (ref) v_u_8, (copy) v_u_10, (copy) v_u_1504
	local v1505 = v_u_29.rect
	if v1505 and (v1505.parent and (v1505.parent.Parent and not (v_u_29.card and v_u_29.card.Parent))) then
		local v1506 = v_u_9.color
		local v1507 = v1505.s - 32
		local v1508 = math.min(v1507, 460)
		local v1509 = math.floor(v1508)
		local v1510 = v_u_1501()
		local v1511 = v_u_8.new
		local v1512 = {
			["Name"] = "MapHint",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 40,
			["BackgroundColor3"] = v1506.bg,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		}
		local v1513 = UDim2.fromOffset
		local v1514 = v1505.x
		local v1515 = v1505.s / 2
		local v1516 = v1514 + math.floor(v1515)
		local v1517 = v1505.y
		local v1518 = v1505.s / 2
		v1512.Position = v1513(v1516, v1517 + math.floor(v1518))
		v1512.Size = UDim2.fromOffset(v1509, 0)
		v1512.AutomaticSize = Enum.AutomaticSize.Y
		local v1519 = v1511("Frame", v1512, v1505.parent)
		v_u_8.stroke(v1519, v1506.accent)
		v_u_8.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 16),
			["PaddingRight"] = UDim.new(0, 16),
			["PaddingTop"] = UDim.new(0, 12),
			["PaddingBottom"] = UDim.new(0, 14)
		}, v1519)
		v_u_8.new("UIListLayout", {
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 6)
		}, v1519)
		v_u_8.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "How the map works",
			["style"] = "caps",
			["textSize"] = 15,
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v1519,
			["color"] = v1506.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		}).LayoutOrder = 0
		for v1520, v1521 in v1510 do
			local v1522 = v_u_8.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["valign"] = "top",
				["track"] = false,
				["parent"] = v1519,
				["name"] = "Line" .. v1520,
				["text"] = v1521,
				["color"] = v1506.text,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v1522.AutomaticSize = Enum.AutomaticSize.Y
			v1522.LayoutOrder = v1520
		end
		local v1523 = v_u_8.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 10,
			["Size"] = UDim2.new(1, 0, 0, v_u_9.touch(40) + 6)
		}, v1519)
		v_u_8.button({
			["parent"] = nil,
			["text"] = "Got it",
			["kind"] = "primary",
			["anchor"] = nil,
			["position"] = nil,
			["height"] = nil,
			["width"] = 130,
			["onClick"] = nil,
			["parent"] = v1523,
			["anchor"] = Vector2.new(1, 1),
			["position"] = UDim2.fromScale(1, 1),
			["height"] = v_u_9.touch(40),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_29, (ref) v_u_10, (ref) v_u_1504
				local v1524 = v_u_29.card
				v_u_29.card = nil
				if v1524 and v1524.Parent then
					v1524:Destroy()
				end
				v_u_10:SetAttribute("MapHintShown", false)
				v_u_1504()
			end
		}).Name = "GotIt"
		for _, v1525 in v1519:GetDescendants() do
			if not v1525:IsA("GuiObject") or v1525.ZIndex >= 41 then
				continue
			end
			v1525.ZIndex = 41
		end
		v_u_29.card = v1519
		local v1526 = v_u_29
		v1526.shown = v1526.shown + 1
		v_u_10:SetAttribute("MapHintShown", true)
	end
end
local function v_u_1532() -- name: maybeMapHint
	-- upvalues: (copy) v_u_29, (copy) v_u_1527, (copy) v_u_10, (ref) v_u_17
	if v_u_29.seen == true then
		return
	elseif v_u_29.seen == false then
		v_u_1527()
		return
	elseif not v_u_29.fetching then
		v_u_29.fetching = true
		task.spawn(function()
			-- upvalues: (ref) v_u_29, (ref) v_u_10, (ref) v_u_17, (ref) v_u_1527
			local v1528 = false
			local v_u_1529 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
			if v_u_1529 then
				v_u_1529 = v_u_1529:FindFirstChild("menu.get")
			end
			if v_u_1529 and v_u_1529:IsA("RemoteFunction") then
				local v1530, v1531 = pcall(function()
					-- upvalues: (copy) v_u_1529
					return v_u_1529:InvokeServer({
						["what"] = "settings"
					})
				end)
				v1528 = v1530 and (type(v1531) == "table" and (v1531.error == nil and v1531.mapHintSeen == true)) and true or v1528
			end
			v_u_29.fetching = false
			if v_u_29.seen == nil then
				v_u_29.seen = v1528
			end
			v_u_10:SetAttribute("MapHintSeen", v_u_29.seen == true)
			if v_u_29.seen == false and v_u_17 then
				v_u_1527()
			end
		end)
	end
end
local v_u_1533 = nil
local function v_u_1537(p1534) -- name: setReticleHidden
	-- upvalues: (copy) v_u_10, (ref) v_u_1533, (copy) v_u_4
	if p1534 then
		local v1535 = v_u_10:FindFirstChildOfClass("PlayerGui")
		if v1535 then
			v1535 = v1535:FindFirstChild("HushReticle")
		end
		if v1535 and (v1535:IsA("ScreenGui") and v1535.Enabled) then
			v1535.Enabled = false
			v_u_1533 = v1535
		end
		if v_u_4.MouseEnabled and not v_u_4.MouseIconEnabled then
			v_u_4.MouseIconEnabled = true
			return
		end
	else
		local v1536 = v_u_1533
		v_u_1533 = nil
		if v1536 and v1536.Parent then
			v1536.Enabled = true
		end
	end
end
local function v_u_1545(p1538) -- name: setPanels
	-- upvalues: (ref) v_u_7, (copy) v_u_1537
	local v1539 = v_u_7 and v_u_7.controllers
	if v1539 then
		v1539 = v_u_7.controllers.HUD
	end
	if v1539 and v1539.setVisible then
		local v1540 = v1539.setVisible
		pcall(v1540, not p1538)
	end
	local v1541 = v_u_7 and v_u_7.controllers
	if v1541 then
		v1541 = v_u_7.controllers.Prompts
	end
	if v1541 and v1541.setEnabled then
		local v1542 = v1541.setEnabled
		pcall(v1542, not p1538)
	end
	local v1543 = v_u_7 and v_u_7.controllers
	if v1543 then
		v1543 = v_u_7.controllers.Input
	end
	if v1543 and v1543.setEnabled then
		local v1544 = v1543.setEnabled
		pcall(v1544, not p1538)
	end
	v_u_1537(p1538)
end
local function v_u_1554() -- name: flushToggleSave
	-- upvalues: (ref) v_u_7, (copy) v_u_33, (copy) v_u_10
	local function v1546()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapToggleRule
	end
	local v1547, v1548 = pcall(v1546)
	if not v1547 or type(v1548) ~= "table" then
		v1548 = nil
	end
	if v1548 then
		for v1549 in v_u_33.dirty do
			local v1550 = v_u_10:GetAttribute(v1548.attr[v1549])
			if type(v1550) ~= "boolean" or not (v_u_7 and v_u_7.net) then
				continue
			end
			local v1551 = v_u_7.net.fire
			if type(v1551) ~= "function" then
				continue
			end
			local v1552 = v_u_7.net.fire
			local v1553 = {
				["op"] = "setting",
				["key"] = nil,
				["value"] = nil,
				["key"] = v1548.persist[v1549],
				["value"] = v1550
			}
			pcall(v1552, "menu.op", v1553)
		end
		table.clear(v_u_33.dirty)
	end
end
function v_u_6.setToggle(p1555, p1556) -- name: setToggle
	-- upvalues: (ref) v_u_7, (copy) v_u_10, (copy) v_u_33, (copy) v_u_1554, (ref) v_u_13, (ref) v_u_14, (ref) v_u_162, (copy) v_u_134, (ref) v_u_20, (copy) v_u_151
	local function v1557()
		-- upvalues: (ref) v_u_7
		return v_u_7.shared.MapToggleRule
	end
	local v1558, v1559 = pcall(v1557)
	if not v1558 or type(v1559) ~= "table" then
		v1559 = nil
	end
	if v1559 then
		local v1560 = v_u_7 and v_u_7.shared
		if v1560 then
			v1560 = v_u_7.shared.Config
		end
		local v1561 = false
		local function v1562()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.MapToggleRule
		end
		local v1563, v1564 = pcall(v1562)
		if not v1563 or type(v1564) ~= "table" then
			v1564 = nil
		end
		if v1564 ~= nil then
			if v1560 then
				local v1565 = v1560.flag
				if type(v1565) == "function" then
					v1560 = v1560.flag("MapToggles") == false
				else
					v1560 = false
				end
			end
			v1561 = not v1560
		end
		if v1561 and (p1555 == "tasks" or p1555 == "labels") then
			v_u_10:SetAttribute(v1559.attr[p1555], p1556)
			v_u_33.dirty[p1555] = true
			local v1566 = v_u_33
			v1566.tok = v1566.tok + 1
			local v_u_1567 = v_u_33.tok
			task.delay(0.8, function()
				-- upvalues: (copy) v_u_1567, (ref) v_u_33, (ref) v_u_1554
				if v_u_1567 == v_u_33.tok then
					v_u_1554()
				end
			end)
			if v_u_13 and (v_u_14 and v_u_162) then
				local v1568 = v_u_134()
				v_u_20 = v_u_151(v1568)
				v_u_162(v1568)
			end
			return true
		end
	end
	return false
end
function v_u_6.showLevel(p1569) -- name: showLevel
	-- upvalues: (copy) v_u_31, (ref) v_u_11, (ref) v_u_164
	if v_u_31.mode ~= "hollow" or not (v_u_11 and v_u_11.Parent) then
		return false
	end
	v_u_164(string.upper(p1569))
	return v_u_31.level == string.upper(p1569)
end
function v_u_6.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_17
	return v_u_17
end
function v_u_6.open() -- name: open
	-- upvalues: (ref) v_u_17, (ref) v_u_7, (copy) v_u_10, (ref) v_u_11, (copy) v_u_31, (copy) v_u_58, (copy) v_u_242, (copy) v_u_1446, (ref) v_u_164, (copy) v_u_134, (copy) v_u_151, (ref) v_u_20, (ref) v_u_162, (ref) v_u_12, (ref) v_u_18, (copy) v_u_1545, (ref) v_u_8, (copy) v_u_1532
	if not v_u_17 then
		local v1570 = v_u_7
		if v1570 then
			v1570 = v_u_7.session
		end
		local v1571, v1572
		if v1570 and v1570.place then
			local v1573 = v1570.place
			local v1574 = v_u_10
			local v1575
			v1575, v1571 = pcall(v1573, v1574)
			if not v1575 or type(v1571) ~= "string" then
				v1572 = v_u_10:GetAttribute("Place")
				v1571 = type(v1572) ~= "string" and "" or v1572
			end
		else
			v1572 = v_u_10:GetAttribute("Place")
			v1571 = type(v1572) ~= "string" and "" or v1572
		end
		if v1571 == "Raid" then
			local v1576 = v_u_10.Character
			local v1577
			if v1576 == nil then
				v1577 = false
			else
				v1577 = v1576:GetAttribute("Dead") == true
			end
			if not v1577 and game:GetService("Players").LocalPlayer:GetAttribute("HuntPlayer") ~= true then
				local v1578 = v_u_7 and v_u_7.controllers
				if v1578 then
					v1578 = v_u_7.controllers.InventoryUI
				end
				if v1578 and (v1578.isOpen and v1578.close) then
					local v1579 = v1578.isOpen
					local v1580, v1581 = pcall(v1579)
					if v1580 and v1581 then
						local v1582 = v1578.close
						pcall(v1582)
					end
				end
				local v1583 = v_u_7 and v_u_7.controllers
				if v1583 then
					v1583 = v_u_7.controllers.Comms
				end
				if v1583 and (v1583.isOpen and v1583.close) then
					local v1584 = v1583.isOpen
					local v1585, v1586 = pcall(v1584)
					if v1585 and v1586 then
						local v1587 = v1583.close
						pcall(v1587)
					end
				end
				if v_u_11 and (v_u_11.Parent and v_u_31.mapId ~= v_u_58()) then
					v_u_242()
				end
				if v_u_11 and v_u_11.Parent then
					if v_u_31.mode == "hollow" then
						local function v1588()
							-- upvalues: (ref) v_u_7
							return v_u_7.shared.HollowLevels
						end
						local v1589, v1590 = pcall(v1588)
						if not v1589 or type(v1590) ~= "table" then
							v1590 = nil
						end
						local v1591 = v_u_10.Character
						if v1591 then
							v1591 = v1591:FindFirstChild("HumanoidRootPart")
						end
						local v1592
						if v1590 and (v1591 and v1591:IsA("BasePart")) then
							v1592 = v1590.levelOf(v1591.Position.Y)
						else
							v1592 = nil
						end
						if v1592 and v1592 ~= v_u_31.level then
							v_u_164(v1592)
						end
					end
					local v1593 = v_u_134()
					local v1594 = v_u_151(v1593)
					if v1594 ~= v_u_20 then
						v_u_20 = v1594
						v_u_162(v1593)
					end
				else
					v_u_1446()
				end
				if v_u_11 and v_u_12 then
					v_u_17 = true
					v_u_18 = os.clock()
					v_u_10:SetAttribute("MapOpen", true)
					v_u_11.Enabled = true
					v_u_1545(true)
					v_u_8.blur(true, 8)
					local v1595 = v_u_12
					v1595.Position = UDim2.new(0.5, 0, 0.5, 8)
					v_u_8.fade(v1595, 0, "normal", {
						["from"] = 1
					})
					v_u_8.tween(v1595, {
						["Position"] = UDim2.fromScale(0.5, 0.5)
					}, "normal")
					v_u_8.sound("open")
					local v1596 = v_u_1532
					pcall(v1596)
				end
			end
		end
	end
end
function v_u_6.close() -- name: close
	-- upvalues: (ref) v_u_17, (ref) v_u_19, (copy) v_u_10, (copy) v_u_1554, (copy) v_u_29, (copy) v_u_1504, (copy) v_u_1545, (ref) v_u_8, (ref) v_u_11, (ref) v_u_12
	if v_u_17 then
		v_u_17 = false
		v_u_19 = os.clock()
		v_u_10:SetAttribute("MapOpen", false)
		v_u_1554()
		if v_u_29.card then
			local v1597 = v_u_29.card
			v_u_29.card = nil
			if v1597 and v1597.Parent then
				v1597:Destroy()
			end
			v_u_10:SetAttribute("MapHintShown", false)
			v_u_1504()
		end
		v_u_1545(false)
		v_u_8.blur(false)
		v_u_8.sound("close")
		local v_u_1598 = v_u_11
		local v1599 = v_u_12
		if v_u_1598 and v1599 then
			local v1600 = {
				["onDone"] = function() -- name: onDone
					-- upvalues: (ref) v_u_17, (copy) v_u_1598
					if not v_u_17 and v_u_1598.Parent then
						v_u_1598.Enabled = false
					end
				end
			}
			v_u_8.fade(v1599, 1, "fast", v1600)
		elseif v_u_1598 then
			v_u_1598.Enabled = false
		end
	else
		return
	end
end
function v_u_6.toggle() -- name: toggle
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (copy) v_u_6
	if v_u_17 then
		if os.clock() - v_u_18 > 0.2 then
			v_u_6.close()
			return
		end
	else
		v_u_6.open()
	end
end
local function v_u_1617() -- name: syncTouchButton
	-- upvalues: (ref) v_u_7, (ref) v_u_23, (ref) v_u_24, (copy) v_u_10
	local v1601 = v_u_7 and v_u_7.controllers
	if v1601 then
		v1601 = v_u_7.controllers.Input
	end
	if not (v_u_23 and v_u_23.Parent) and (v1601 and v1601.touchButton) then
		local v1602 = v1601.touchButton
		local v1603 = {
			["text"] = "MAP",
			["anchor"] = "TR",
			["pos"] = nil,
			["size"] = 46,
			["pos"] = Vector2.new(-106, 92)
		}
		local v1604, v1605 = pcall(v1602, "map", v1603)
		if v1604 and (typeof(v1605) == "Instance" and v1605:IsA("GuiObject")) then
			v_u_23 = v1605
		end
	end
	if not (v_u_24 and v_u_24.Parent) and (v1601 and v1601.touchButton) then
		local v1606 = v1601.touchButton
		local v1607 = {
			["text"] = "EXITS",
			["anchor"] = "TR",
			["pos"] = nil,
			["size"] = 42,
			["pos"] = Vector2.new(-114, 148)
		}
		local v1608, v1609 = pcall(v1606, "extracts", v1607)
		if v1608 and (typeof(v1609) == "Instance" and v1609:IsA("GuiObject")) then
			v_u_24 = v1609
		end
	end
	local v1610 = false
	local v1611 = v_u_7
	if v1611 then
		v1611 = v_u_7.session
	end
	local v1612, v1613
	if v1611 and v1611.place then
		local v1614 = v1611.place
		local v1615 = v_u_10
		local v1616
		v1616, v1612 = pcall(v1614, v1615)
		if v1616 and type(v1612) == "string" then
			if v1612 == "Raid" then
				v1610 = game:GetService("Players").LocalPlayer:GetAttribute("HuntPlayer") ~= true
			end
			if v_u_23 then
				v_u_23.Visible = v1610
			end
			if v_u_24 then
				v_u_24.Visible = v1610
			end
		else
			v1613 = v_u_10:GetAttribute("Place")
			v1612 = type(v1613) ~= "string" and "" or v1613
			if v1612 == "Raid" then
				v1610 = game:GetService("Players").LocalPlayer:GetAttribute("HuntPlayer") ~= true
			end
			if v_u_23 then
				v_u_23.Visible = v1610
			end
			if v_u_24 then
				v_u_24.Visible = v1610
			end
		end
	else
		v1613 = v_u_10:GetAttribute("Place")
		v1612 = type(v1613) ~= "string" and "" or v1613
		if v1612 == "Raid" then
			v1610 = game:GetService("Players").LocalPlayer:GetAttribute("HuntPlayer") ~= true
		end
		if v_u_23 then
			v_u_23.Visible = v1610
		end
		if v_u_24 then
			v_u_24.Visible = v1610
		end
		return
	end
end
function v_u_6.init(p_u_1618) -- name: init
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_6, (ref) v_u_17, (copy) v_u_29, (copy) v_u_10, (copy) v_u_1527, (copy) v_u_1504, (copy) v_u_1216, (ref) v_u_164, (ref) v_u_13, (copy) v_u_22, (copy) v_u_31, (copy) v_u_1545, (copy) v_u_242, (ref) v_u_11, (ref) v_u_1772, (ref) v_u_23, (ref) v_u_24, (copy) v_u_134, (copy) v_u_179, (copy) v_u_27, (copy) v_u_44, (copy) v_u_33, (copy) v_u_495, (copy) v_u_445
	v_u_7 = p_u_1618
	v_u_8 = p_u_1618.lib.HushUI
	v_u_8.bind(p_u_1618)
	v_u_9 = p_u_1618.shared.Theme
	p_u_1618.command("map.open", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_17
		v_u_6.open()
		local v1619 = v_u_17
		return "open=" .. tostring(v1619)
	end)
	p_u_1618.command("map.close", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_17
		v_u_6.close()
		local v1620 = v_u_17
		return "open=" .. tostring(v1620)
	end)
	p_u_1618.command("map.hint", function(p1621)
		-- upvalues: (ref) v_u_29, (ref) v_u_10, (ref) v_u_1527, (ref) v_u_1504
		local v1622 = p1621[1]
		if v1622 == "reset" then
			v_u_29.seen = nil
			local v1623 = v_u_29.card
			v_u_29.card = nil
			if v1623 and v1623.Parent then
				v1623:Destroy()
			end
			v_u_10:SetAttribute("MapHintShown", false)
		elseif v1622 == "show" then
			v_u_1527()
		elseif v1622 == "gotit" and v_u_29.card then
			local v1624 = v_u_29.card
			v_u_29.card = nil
			if v1624 and v1624.Parent then
				v1624:Destroy()
			end
			v_u_10:SetAttribute("MapHintShown", false)
			v_u_1504()
		end
		local v1625 = v_u_29.card
		local v1626
		if v1625 and v1625.Parent then
			local v1627 = {}
			for v1628 = 1, 4 do
				local v1629 = v1625:FindFirstChild("Line" .. v1628)
				if not (v1629 and v1629:IsA("TextLabel")) then
					continue
				end
				local v1630 = v1629.Text .. (v1629.TextFits and "" or " [NOFIT]")
				table.insert(v1627, v1630)
			end
			v1626 = string.format("%dx%d at %d,%d | %s", v1625.AbsoluteSize.X, v1625.AbsoluteSize.Y, v1625.AbsolutePosition.X, v1625.AbsolutePosition.Y, table.concat(v1627, " / "))
		else
			v1626 = "-"
		end
		local v1631 = string.format
		local v1632 = v_u_29.seen
		local v1633 = tostring(v1632)
		local v1634 = v_u_29.fetching
		return v1631("seen=%s fetching=%s shown=%d card=%s", v1633, tostring(v1634), v_u_29.shown, v1626)
	end)
	p_u_1618.command("map.zoom", function(p1635)
		-- upvalues: (ref) v_u_6
		local v1636 = p1635[1]
		if v1636 == "in" then
			v_u_6.zoomBy(1)
		elseif v1636 == "out" then
			v_u_6.zoomBy(-1)
		elseif v1636 == "reset" then
			v_u_6.zoomReset()
		elseif v1636 == "me" then
			v_u_6.zoomMe()
		elseif tonumber(v1636) then
			v_u_6.setZoom((tonumber(v1636)))
		end
		local v1637 = v_u_6.zoomState()
		if not v1637 then
			return "no zoom controller"
		end
		local v1638 = string.format
		local v1639 = v1637.key
		local v1640 = tostring(v1639)
		local v1641 = v1637.z
		local v1642 = v1637.x
		local v1643 = math.round(v1642)
		local v1644 = v1637.y
		local v1645 = math.round(v1644)
		local v1646 = v1637.follow
		return v1638("key=%s zoom=%.2f pos=%d,%d follow=%s", v1640, v1641, v1643, v1645, (tostring(v1646)))
	end)
	p_u_1618.command("map.level", function(p1647)
		-- upvalues: (ref) v_u_1216, (ref) v_u_164, (ref) v_u_13, (ref) v_u_22, (ref) v_u_31, (ref) v_u_7, (ref) v_u_10
		local v1648 = p1647[1]
		if v1648 == "next" then
			v_u_1216(1)
		elseif v1648 == "prev" then
			v_u_1216(-1)
		elseif type(v1648) == "string" and v1648 ~= "" then
			v_u_164(string.upper(v1648))
		end
		local v1649 = v_u_13
		if v1649 then
			v1649 = v_u_13.stats
		end
		local v1650 = {}
		for v1651 in v_u_22 do
			table.insert(v1650, v1651)
		end
		table.sort(v1650)
		local v1652 = string.format
		local v1653 = "mode=%s map=%s level=%s own=%s sheets=%d sheet=%dx%d scale=%.3f rooms=%s frames=%s labels=%s doors=%s links=%s buildMs=%s marks=%s"
		local v1654 = v_u_31.mode
		local v1655 = v_u_31.mapId
		local v1656 = v_u_31.level
		local v1657 = tostring(v1656)
		local function v1658()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.HollowLevels
		end
		local v1659, v1660 = pcall(v1658)
		if not v1659 or type(v1660) ~= "table" then
			v1660 = nil
		end
		local v1661 = v_u_10.Character
		if v1661 then
			v1661 = v1661:FindFirstChild("HumanoidRootPart")
		end
		local v1662
		if v1660 and (v1661 and v1661:IsA("BasePart")) then
			v1662 = v1660.levelOf(v1661.Position.Y)
		else
			v1662 = nil
		end
		local v1663 = tostring(v1662)
		local v1664 = v_u_31.built
		local v1665 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
		local v1666 = math.floor(v1665)
		local v1667 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
		local v1668 = math.floor(v1667)
		local v1669 = v_u_13 and v_u_13.scale or 0
		local v1670
		if v1649 then
			v1670 = v1649.rooms
		else
			v1670 = v1649
		end
		local v1671 = tostring(v1670)
		local v1672
		if v1649 then
			v1672 = v1649.frames
		else
			v1672 = v1649
		end
		local v1673 = tostring(v1672)
		local v1674
		if v1649 then
			v1674 = v1649.labels
		else
			v1674 = v1649
		end
		local v1675 = tostring(v1674)
		local v1676
		if v1649 then
			v1676 = v1649.doors
		else
			v1676 = v1649
		end
		local v1677 = tostring(v1676)
		if v1649 then
			v1649 = v1649.links
		end
		local v1678 = tostring(v1649)
		local v1679 = v_u_13
		if v1679 then
			v1679 = v_u_13.buildMs
		end
		return v1652(v1653, v1654, v1655, v1657, v1663, v1664, v1666, v1668, v1669, v1671, v1673, v1675, v1677, v1678, tostring(v1679), table.concat(v1650, ","))
	end)
	p_u_1618.command("map.as", function(p1680)
		-- upvalues: (ref) v_u_31, (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6
		if not game:GetService("RunService"):IsStudio() then
			return "Studio only"
		end
		local v1681 = p1680[1]
		local v1682 = v_u_31
		local v1683
		if v1681 == nil or (v1681 == "off" or v1681 == "") then
			v1683 = nil
		else
			v1683 = (string.lower(v1681) == "ashgrove" or v1681 == "5") and "unknown5" or string.lower(v1681)
		end
		v1682.forceId = v1683
		local v1684 = v_u_17
		if v1684 then
			v_u_17 = false
			v_u_1545(false)
			v_u_8.blur(false)
		end
		v_u_242()
		if v1684 then
			v_u_6.open()
		end
		local v1685 = v_u_31.forceId
		local v1686 = v_u_17
		return ("as=%s open=%s mode=%s"):format(tostring(v1685), tostring(v1686), v_u_31.mode)
	end)
	p_u_1618.command("map.pos", function(p1687)
		-- upvalues: (copy) p_u_1618, (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_31
		if not game:GetService("RunService"):IsStudio() then
			return "Studio only"
		end
		if p1687[1] == "on" or p1687[1] == "off" then
			p_u_1618.shared.Config.MAP_SHOW_POSITION = p1687[1] == "on"
			local v1688 = v_u_17
			if v1688 then
				v_u_17 = false
				v_u_1545(false)
				v_u_8.blur(false)
			end
			v_u_242()
			if v1688 then
				v_u_6.open()
			end
		end
		local v1689 = 0
		local v1690 = 0
		local v1691 = false
		local v1692 = "-"
		if v_u_11 then
			for _, v1693 in v_u_11:GetDescendants() do
				if v1693.Name == "Facing" then
					v1690 = v1690 + 1
				else
					local v1694 = v1693.Name
					if string.sub(v1694, 1, 4) == "Pos_" then
						v1689 = v1689 + 1
					elseif v1693.Name == "Key_You, squad" then
						v1691 = true
					else
						if not (v1693:IsA("TextLabel") and string.find(v1693.Text, "A paper map", 1, true)) then
							continue
						end
						v1692 = v1693.Text
					end
				end
			end
		end
		local v1695 = "switch=%s open=%s mode=%s marks=%d facing=%d keyRow=%s header=%s"
		local v1696 = v_u_7 and v_u_7.shared
		if v1696 then
			v1696 = v_u_7.shared.Config
		end
		if v1696 then
			v1696 = v1696.MAP_SHOW_POSITION == false
		end
		local v1697 = v_u_17
		return v1695:format(tostring(not v1696), tostring(v1697), v_u_31.mode, v1689, v1690, tostring(v1691), v1692)
	end)
	p_u_1618.command("map.at", function(p1698)
		-- upvalues: (ref) v_u_1772
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v1738, v1739, v1740, v1741, v1742, v1743, v1744, v1745, v1746, v1747, v1748, v1749, v1750, v1751, v1752, v1753, v1754, v1755, v1756, v1757, v1758, v1759, v1760, v1761, v1762, v1763, v1764, v1765, v1766, v1767, v1768, v1769, v1770, v1771, v1773, v1774, v1775, v1776, v1777
		local v1738, v1739, v1740, v1741, v1742, v1743, v1744, v1745, v1746, v1747, v1748, v1749, v1750, v1751, v1752, v1753, v1754, v1755, v1756, v1757, v1758, v1759, v1760, v1761, v1762, v1763, v1764, v1765, v1766, v1767, v1768, v1769, v1770, v1771, v_u_1772, v1773, v1774, v1775, v1776, v1777
		local v1778 = 10
		while true do
			if v1778 == 1 then
				if v1752 == "mate" and p1698[2] then
					v1778 = 8
				else
					v1778 = 4
				end
			elseif v1778 == 2 then
				v1764 = p1698[2]
				v1765 = tonumber(v1764)
				if v1765 then
					v1770 = math.clamp(v1765, 0.0001, 0.9999)
				else
					v1770 = nil
				end
				if v1770 then
					v1778 = 5
				else
					v1778 = 1
				end
			elseif v1778 == 3 then
				if v1752 == "mate" and p1698[2] then
					v1778 = 8
				else
					v1778 = 6
				end
			elseif v1778 == 4 then
				if v1752 == "drop" and (p1698[2] and v_u_1772) then
					v1771 = string.lower(p1698[2]) == "me" and "me" or "u" .. string.upper(p1698[2])
					for v1791, v1792 in v_u_1772 do
						if v1792.key ~= v1771 then
							continue
						end
						table.remove(v_u_1772, v1791)
					end
				elseif v1752 == "off" then
					v_u_1772 = nil
				elseif v1752 ~= nil then
					return "usage: map.at me <fx> <fy> [yaw] | mate <NAME> <fx> <fy> [yaw] | drop <me|NAME> | off"
				end
				v1778 = 9
			elseif v1778 == 5 then
				v1773 = p1698[3]
				v1774 = tonumber(v1773)
				if v1774 then
					v1775 = math.clamp(v1774, 0.0001, 0.9999)
				else
					v1775 = nil
				end
				if v1775 then
					v1758 = "me"
					v1759 = "YOU"
					v1760 = p1698[2]
					v1761 = tonumber(v1760)
					if v1761 then
						v1762 = math.clamp(v1761, 0.0001, 0.9999)
					else
						v1762 = nil
					end
					v1763 = p1698[3]
					v1776 = tonumber(v1763)
					if v1776 then
						v1777 = math.clamp(v1776, 0.0001, 0.9999)
					else
						v1777 = nil
					end
					v1742 = p1698[4]
					v1753(v1758, v1759, v1762, v1777, tonumber(v1742) or 0)
					v1743 = {}
					for v1793, v1794 in v_u_1772 or {} do
						v1744 = v1794.key
						v1745 = v1794.fx
						v1754 = v1794.fy
						table.insert(v1743, ("%s@%.3f,%.3f"):format(v1744, v1745, v1754))
					end
					return "fake=" .. (not v_u_1772 and "off" or table.concat(v1743, " "))
				end
				if v1752 == "mate" and p1698[2] then
					v1778 = 8
				else
					v1778 = 7
				end
			elseif v1778 == 6 then
				if v1752 == "drop" and (p1698[2] and v_u_1772) then
					v1771 = string.lower(p1698[2]) == "me" and "me" or "u" .. string.upper(p1698[2])
					for v1791, v1792 in v_u_1772 do
						if v1792.key ~= v1771 then
							continue
						end
						table.remove(v_u_1772, v1791)
					end
				elseif v1752 == "off" then
					v_u_1772 = nil
				elseif v1752 ~= nil then
					return "usage: map.at me <fx> <fy> [yaw] | mate <NAME> <fx> <fy> [yaw] | drop <me|NAME> | off"
				end
				v1778 = 9
			elseif v1778 == 7 then
				if v1752 == "drop" and (p1698[2] and v_u_1772) then
					v1771 = string.lower(p1698[2]) == "me" and "me" or "u" .. string.upper(p1698[2])
					for v1791, v1792 in v_u_1772 do
						if v1792.key ~= v1771 then
							continue
						end
						table.remove(v_u_1772, v1791)
					end
				elseif v1752 == "off" then
					v_u_1772 = nil
				elseif v1752 ~= nil then
					return "usage: map.at me <fx> <fy> [yaw] | mate <NAME> <fx> <fy> [yaw] | drop <me|NAME> | off"
				end
				v1778 = 9
			elseif v1778 == 8 then
				v1755 = p1698[3]
				v1756 = tonumber(v1755)
				if v1756 then
					v1757 = math.clamp(v1756, 0.0001, 0.9999)
				else
					v1757 = nil
				end
				if v1757 then
					v1738 = p1698[4]
					v1739 = tonumber(v1738)
					if v1739 then
						v1740 = math.clamp(v1739, 0.0001, 0.9999)
					else
						v1740 = nil
					end
					if v1740 then
						v1741 = "u" .. string.upper(p1698[2])
						v1766 = string.upper
						v1767 = p1698[2]
						v1768 = v1766((string.sub(v1767, 1, 6)))
						v1769 = p1698[3]
						v1746 = tonumber(v1769)
						if v1746 then
							v1747 = math.clamp(v1746, 0.0001, 0.9999)
						else
							v1747 = nil
						end
						v1748 = p1698[4]
						v1749 = tonumber(v1748)
						if v1749 then
							v1750 = math.clamp(v1749, 0.0001, 0.9999)
						else
							v1750 = nil
						end
						v1751 = p1698[5]
						v1753(v1741, v1768, v1747, v1750, tonumber(v1751) or 0)
						v1743 = {}
						for v1793, v1794 in v_u_1772 or {} do
							v1744 = v1794.key
							v1745 = v1794.fx
							v1754 = v1794.fy
							table.insert(v1743, ("%s@%.3f,%.3f"):format(v1744, v1745, v1754))
						end
						return "fake=" .. (not v_u_1772 and "off" or table.concat(v1743, " "))
					end
					if v1752 == "drop" and (p1698[2] and v_u_1772) then
						v1771 = string.lower(p1698[2]) == "me" and "me" or "u" .. string.upper(p1698[2])
						for v1791, v1792 in v_u_1772 do
							if v1792.key ~= v1771 then
								continue
							end
							table.remove(v_u_1772, v1791)
						end
					elseif v1752 == "off" then
						v_u_1772 = nil
					elseif v1752 ~= nil then
						return "usage: map.at me <fx> <fy> [yaw] | mate <NAME> <fx> <fy> [yaw] | drop <me|NAME> | off"
					end
				elseif v1752 == "drop" and (p1698[2] and v_u_1772) then
					v1771 = string.lower(p1698[2]) == "me" and "me" or "u" .. string.upper(p1698[2])
					for v1791, v1792 in v_u_1772 do
						if v1792.key ~= v1771 then
							continue
						end
						table.remove(v_u_1772, v1791)
					end
				elseif v1752 == "off" then
					v_u_1772 = nil
				elseif v1752 ~= nil then
					return "usage: map.at me <fx> <fy> [yaw] | mate <NAME> <fx> <fy> [yaw] | drop <me|NAME> | off"
				end
				v1778 = 9
			elseif v1778 == 9 then
				v1743 = {}
				for v1793, v1794 in v_u_1772 or {} do
					v1744 = v1794.key
					v1745 = v1794.fx
					v1754 = v1794.fy
					table.insert(v1743, ("%s@%.3f,%.3f"):format(v1744, v1745, v1754))
				end
				return "fake=" .. (not v_u_1772 and "off" or table.concat(v1743, " "))
			else
				if not game:GetService("RunService"):IsStudio() then
					return "Studio only"
				end
				v1752 = p1698[1]
				v1753 = function(p1795, p1796, p1797, p1798, p1799) -- name: put
					-- upvalues: (ref) v_u_1772
					local v1800 = v_u_1772 or {}
					for v1801, v1802 in v1800 do
						if v1802.key ~= p1795 then
							continue
						end
						table.remove(v1800, v1801)
					end
					table.insert(v1800, {
						["key"] = p1795,
						["name"] = p1796,
						["fx"] = p1797,
						["fy"] = p1798,
						["yaw"] = p1799
					})
					v_u_1772 = v1800
				end
				if v1752 == "me" then
					v1778 = 2
				else
					v1778 = 3
				end
			end
		end
	end)
	p_u_1618.command("map.state", function()
		-- upvalues: (ref) v_u_22, (ref) v_u_17, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (ref) v_u_23, (ref) v_u_24, (ref) v_u_31
		local v1803 = {}
		for v1804 in v_u_22 do
			table.insert(v1803, v1804)
		end
		table.sort(v1803)
		local v1805 = string.format
		local v1806 = "open=%s place=%s sheet=%s marks=%s touchBtn=%s exitsBtn=%s mode=%s level=%s"
		local v1807 = v_u_17
		local v1808 = tostring(v1807)
		local v1809 = v_u_7
		if v1809 then
			v1809 = v_u_7.session
		end
		local v1810, v1811, v1812
		if not (v1809 and v1809.place) then
			v1817 = v_u_10:GetAttribute("Place")
			v1816 = type(v1817) ~= "string" and "" or v1817
			v1818 = v_u_13
			if v1818 then
				v1810 = v_u_13.inner
				v1818 = math.floor(v1810)
			end
			v1819 = tostring(v1818)
			v1820 = table.concat(v1803, ",")
			if v_u_23 == nil then
				v1811 = false
			else
				v1811 = v_u_23.Visible
			end
			v1821 = tostring(v1811)
			if v_u_24 == nil then
				v1812 = false
			else
				v1812 = v_u_24.Visible
			end
			v1822 = tostring(v1812)
			v1823 = v_u_31.mode
			v1824 = v_u_31.mode ~= "hollow" and "-" or v_u_31.level
			return v1805(v1806, v1808, v1816, v1819, v1820, v1821, v1822, v1823, (tostring(v1824)))
		end
		local v1813 = v1809.place
		local v1814 = v_u_10
		local v1815, v1816 = pcall(v1813, v1814)
		if v1815 and type(v1816) == "string" then
			v1818 = v_u_13
			if v1818 then
				v1810 = v_u_13.inner
				v1818 = math.floor(v1810)
			end
			v1819 = tostring(v1818)
			v1820 = table.concat(v1803, ",")
			if v_u_23 == nil then
				v1811 = false
			else
				v1811 = v_u_23.Visible
			end
			v1821 = tostring(v1811)
			if v_u_24 == nil then
				v1812 = false
			else
				v1812 = v_u_24.Visible
			end
			v1822 = tostring(v1812)
			v1823 = v_u_31.mode
			v1824 = v_u_31.mode ~= "hollow" and "-" or v_u_31.level
			return v1805(v1806, v1808, v1816, v1819, v1820, v1821, v1822, v1823, (tostring(v1824)))
		end
		local v1817 = v_u_10:GetAttribute("Place")
		v1816 = type(v1817) ~= "string" and "" or v1817
		local v1818 = v_u_13
		if v1818 then
			v1810 = v_u_13.inner
			v1818 = math.floor(v1810)
		end
		local v1819 = tostring(v1818)
		local v1820 = table.concat(v1803, ",")
		if v_u_23 == nil then
			v1811 = false
		else
			v1811 = v_u_23.Visible
		end
		local v1821 = tostring(v1811)
		if v_u_24 == nil then
			v1812 = false
		else
			v1812 = v_u_24.Visible
		end
		local v1822 = tostring(v1812)
		local v1823 = v_u_31.mode
		local v1824 = v_u_31.mode ~= "hollow" and "-" or v_u_31.level
		return v1805(v1806, v1808, v1816, v1819, v1820, v1821, v1822, v1823, (tostring(v1824)))
	end)
	p_u_1618.command("map.ping", function(p1825)
		-- upvalues: (ref) v_u_134, (ref) v_u_179
		for _, v1826 in v_u_134() do
			if v1826.id ~= p1825[1] then
				continue
			end
			v_u_179(v1826)
			return "pinged " .. v1826.id
		end
		local v1827 = p1825[1]
		return "not marked: " .. tostring(v1827)
	end)
	p_u_1618.command("map.wp", function(p1828)
		-- upvalues: (ref) v_u_7, (ref) v_u_27, (ref) v_u_6
		local v1829 = p1828[1]
		local v1830 = tonumber(v1829)
		local v1831 = p1828[2]
		local v1832 = tonumber(v1831)
		if v1830 and v1832 then
			return v_u_6.waypointAt(v1830, v1832)
		end
		local v1833 = v_u_7 and v_u_7.controllers
		if v1833 then
			v1833 = v_u_7.controllers.Comms
		end
		local v1834 = "wp=%s set=%d cleared=%d sig=%s"
		local v1835 = v1833 and v1833.waypoint
		if v1835 then
			v1835 = v1833.waypoint()
		end
		return v1834:format(tostring(v1835), v_u_27.set, v_u_27.cleared, v_u_27.sig)
	end)
	p_u_1618.command("map.cursor", function(p1836)
		-- upvalues: (ref) v_u_13, (ref) v_u_27
		local v1837 = p1836[1]
		local v1838 = tonumber(v1837)
		local v1839 = p1836[2]
		local v1840 = tonumber(v1839)
		if v1838 and (v1840 and v_u_13) then
			v_u_27.cursor = Vector2.new(v1838 * (not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)), v1840 * (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)))
		end
		local v1841 = v_u_27.cursorOn
		local v1842 = tostring(v1841)
		local v1843 = v_u_27.cursor.X
		local v1844 = v_u_27.cursor.Y
		local v1845 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
		local v1846 = math.floor(v1845)
		local v1847 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
		return ("cursorOn=%s cursor=%.0f,%.0f inner=%s"):format(v1842, v1843, v1844, ("%dx%d"):format(v1846, (math.floor(v1847))))
	end)
	p_u_1618.command("map.key", function()
		-- upvalues: (ref) v_u_11
		local v1848 = {}
		if v_u_11 then
			for _, v1849 in v_u_11:GetDescendants() do
				if not v1849:IsA("TextLabel") then
					continue
				end
				local v1850 = v1849.Name
				if string.sub(v1850, 1, 4) ~= "Key_" and (v1849.Name ~= "KeyLandmark" and v1849.Name ~= "Note") then
					continue
				end
				local v1851 = v1849.Name
				local v1852 = v1849.AbsoluteSize.X
				local v1853 = v1849.AbsoluteSize.Y
				local v1854 = v1849.TextFits
				local v1855 = tostring(v1854)
				table.insert(v1848, ("%s[%dx%d fits=%s]"):format(v1851, v1852, v1853, v1855))
			end
		end
		return table.concat(v1848, " ")
	end)
	p_u_1618.command("map.toggle", function(p1856)
		-- upvalues: (ref) v_u_44, (ref) v_u_6, (ref) v_u_13, (ref) v_u_7, (ref) v_u_33
		local v1857 = p1856[1]
		local v1858 = p1856[2]
		if v1857 == "tasks" or v1857 == "labels" then
			local v1859 = not v_u_44()[v1857]
			if v1858 == "on" then
				v1859 = true
			elseif v1858 == "off" then
				v1859 = false
			end
			if not v_u_6.setToggle(v1857, v1859) then
				return "refused (flag MapToggles off or unknown switch)"
			end
		end
		local v1860 = v_u_44()
		local function v1863(p1861, p1862) -- name: shown
			while p1861 and p1861 ~= p1862 do
				if p1861:IsA("GuiObject") and not p1861.Visible then
					return false
				end
				p1861 = p1861.Parent
			end
			return true
		end
		local v1864 = 0
		local v1865 = 0
		local v1866 = 0
		local v1867 = 0
		local v1868 = 0
		local v1869 = 0
		if v_u_13 and v_u_13.frame then
			local v1870 = v_u_13.frame
			local v1871 = v_u_13.area
			local v1872
			if v1871 then
				v1872 = v1871:FindFirstChild("TaskMarks")
			else
				v1872 = v1871
			end
			if v1872 then
				for _, v1873 in v1872:GetChildren() do
					if not (v1873:IsA("GuiObject") and v1863(v1873, v1870)) then
						continue
					end
					local v1874 = v1873.Name
					if string.sub(v1874, 1, 5) == "Task_" then
						v1864 = v1864 + 1
					else
						local v1875 = v1873.Name
						if string.sub(v1875, 1, 8) ~= "TaskTag_" then
							continue
						end
						v1865 = v1865 + 1
					end
				end
			end
			if v1871 then
				v1871 = v1871:FindFirstChild("ObjectiveRooms")
			end
			v1866 = v1871 and #v1871:GetChildren() or v1866
			local v1876 = v_u_13.labelLayer
			if v1876 then
				for _, v1877 in v1876:GetChildren() do
					if not v1877:IsA("TextLabel") then
						continue
					end
					v1868 = v1868 + 1
					if not v1863(v1877, v1870) then
						continue
					end
					v1867 = v1867 + 1
				end
			end
			for _, v1878 in v_u_13.nameLabels or {} do
				v1868 = v1868 + 1
				if not (v1878.Parent and v1863(v1878, v1870)) then
					continue
				end
				v1867 = v1867 + 1
			end
			for _, v1879 in v1870:GetDescendants() do
				if not v1879:IsA("TextLabel") or (v1879.Text == "" or not v1863(v1879, v1870)) then
					continue
				end
				v1869 = v1869 + 1
			end
		end
		local v1880 = "flag=%s tasks=%s labels=%s chips=%d taskTags=%d tintedRooms=%d placeNames=%d/%d textLabels=%d bar=%s sel=%s"
		local v1881 = v_u_7 and v_u_7.shared
		if v1881 then
			v1881 = v_u_7.shared.Config
		end
		local v1882 = false
		local function v1883()
			-- upvalues: (ref) v_u_7
			return v_u_7.shared.MapToggleRule
		end
		local v1884, v1885 = pcall(v1883)
		if not v1884 or type(v1885) ~= "table" then
			v1885 = nil
		end
		if v1885 ~= nil then
			if v1881 then
				local v1886 = v1881.flag
				if type(v1886) == "function" then
					v1881 = v1881.flag("MapToggles") == false
				else
					v1881 = false
				end
			end
			v1882 = not v1881
		end
		local v1887 = tostring(v1882)
		local v1888 = v1860.tasks and "on" or "off"
		local v1889 = v1860.labels and "on" or "off"
		local v1890 = not v_u_33.bar and "none" or ("%dh"):format(v_u_33.bar.height)
		local function v1891()
			-- upvalues: (ref) v_u_7
			return v_u_7.lib.MapTaskList.openId()
		end
		local v1892, v1893 = pcall(v1891)
		if not v1892 or type(v1893) ~= "string" then
			v1893 = nil
		end
		return v1880:format(v1887, v1888, v1889, v1864, v1865, v1866, v1867, v1868, v1869, v1890, (tostring(v1893)))
	end)
	p_u_1618.command("map.tasks", function()
		-- upvalues: (ref) v_u_7, (ref) v_u_495, (ref) v_u_445
		local v1894 = v_u_7.lib.MapTaskList
		local v1895 = {}
		for _, v1896 in v_u_495() do
			local v1897 = v1896.id
			local v1898 = v1896.kind
			local v1899 = v1896.placeText
			local v1900 = v1896.open
			table.insert(v1895, ("%s[%s|%s|open=%d]"):format(v1897, v1898, v1899, v1900))
		end
		local v1901 = v1894.state()
		local v1902 = "drop=%s rows=%d openRow=%s paintMs=%.1f :: %s"
		local v1903 = v_u_7 and v_u_7.shared
		if v1903 then
			v1903 = v_u_7.shared.Config
		end
		if v1903 then
			local v1904 = v1903.flag
			if type(v1904) == "function" then
				v1903 = v1903.flag("MapTaskDrop") == false
			else
				v1903 = false
			end
		end
		local v1905 = tostring(not v1903)
		local v1906 = v1901.rows
		local v1907 = v1901.open
		return v1902:format(v1905, v1906, tostring(v1907), v_u_445.ms, table.concat(v1895, " "))
	end)
	p_u_1618.command("map.task", function(p1908)
		-- upvalues: (ref) v_u_7
		local v1909 = v_u_7.lib.MapTaskList
		local v1910 = v1909.toggle(p1908[1])
		local v1911 = p1908[1]
		local v1912 = tostring(v1911)
		local v1913 = tostring(v1910)
		local v1914 = v1909.openId
		return ("toggle %s -> %s open=%s"):format(v1912, v1913, (tostring(v1914())))
	end)
	p_u_1618.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6
		if v_u_11 then
			local v1915 = v_u_17
			if v1915 then
				v_u_17 = false
				v_u_1545(false)
				v_u_8.blur(false)
			end
			v_u_242()
			if v1915 then
				v_u_6.open()
			end
		end
	end)
end
function v_u_6.start() -- name: start
	-- upvalues: (ref) v_u_7, (copy) v_u_6, (copy) v_u_1617, (ref) v_u_17, (copy) v_u_1545, (ref) v_u_8, (copy) v_u_242, (ref) v_u_18, (copy) v_u_4, (copy) v_u_31, (copy) v_u_1225, (copy) v_u_44, (copy) v_u_32, (copy) v_u_1216, (copy) v_u_27, (copy) v_u_222, (copy) v_u_25, (copy) v_u_26
	local function v1916()
		-- upvalues: (ref) v_u_7
		v_u_7.lib.SquadPosClient.start(v_u_7)
	end
	local v1917, v1918 = pcall(v1916)
	if not v1917 then
		warn("[MapUI] SquadPosClient:", v1918)
	end
	local v_u_1919 = v_u_7 and v_u_7.controllers
	if v_u_1919 then
		v_u_1919 = v_u_7.controllers.Input
	end
	if v_u_1919 and v_u_1919.bind then
		local v1920 = v_u_1919.bind
		local function v1921()
			-- upvalues: (ref) v_u_6
			v_u_6.toggle()
		end
		pcall(v1920, "map", v1921)
	end
	if v_u_1919 and (v_u_1919.deviceChanged and v_u_1919.deviceChanged.Connect) then
		local function v1922()
			-- upvalues: (copy) v_u_1919, (ref) v_u_1617, (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6
			v_u_1919.deviceChanged:Connect(function()
				-- upvalues: (ref) v_u_1617, (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6
				task.defer(v_u_1617)
				if v_u_17 then
					task.defer(function()
						-- upvalues: (ref) v_u_17, (ref) v_u_1545, (ref) v_u_8, (ref) v_u_242, (ref) v_u_6
						if v_u_17 then
							v_u_17 = false
							v_u_1545(false)
							v_u_8.blur(false)
							v_u_242()
							v_u_6.open()
						end
					end)
				end
			end)
		end
		pcall(v1922)
	end
	v_u_7.lib.VirtualPad.InputBegan:Connect(function(p1923, p1924)
		-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (ref) v_u_31, (ref) v_u_1225, (ref) v_u_44, (ref) v_u_32, (ref) v_u_1216, (ref) v_u_27, (ref) v_u_222
		if not v_u_17 or os.clock() - v_u_18 < 0.2 then
			return
		end
		local v1925 = p1923.KeyCode
		if v1925 == Enum.KeyCode.Escape or v1925 == Enum.KeyCode.ButtonB then
			v_u_6.close()
			return
		end
		if (v1925 == Enum.KeyCode.T or v1925 == Enum.KeyCode.L) and p1923.UserInputType == Enum.UserInputType.Keyboard then
			local v1926 = v_u_7 and v_u_7.shared
			if v1926 then
				v1926 = v_u_7.shared.Config
			end
			local v1927 = false
			local function v1928()
				-- upvalues: (ref) v_u_7
				return v_u_7.shared.MapToggleRule
			end
			local v1929, v1930 = pcall(v1928)
			if not v1929 or type(v1930) ~= "table" then
				v1930 = nil
			end
			if v1930 ~= nil then
				if v1926 then
					local v1931 = v1926.flag
					if type(v1931) == "function" then
						v1926 = v1926.flag("MapToggles") == false
					else
						v1926 = false
					end
				end
				v1927 = not v1926
			end
			if v1927 and (not p1924 and (v_u_4:GetFocusedTextBox() == nil and (v_u_31.mode ~= "hollow" or v_u_1225(v1925) == 0))) then
				local function v1932()
					-- upvalues: (ref) v_u_7
					return v_u_7.shared.MapToggleRule
				end
				local v1933, v1934 = pcall(v1932)
				if not v1933 or type(v1934) ~= "table" then
					v1934 = nil
				end
				local v1935 = v1934 and v1934.keyFor(v1925.Name)
				if v1935 then
					v_u_6.setToggle(v1935, not v_u_44()[v1935])
					return
				end
			else
				if v1925 == Enum.KeyCode.ButtonR3 and v_u_32.ctl then
					v_u_32.ctl.centerMe()
					return
				end
				if v_u_31.mode == "hollow" and (v1925 == Enum.KeyCode.ButtonL1 or v1925 == Enum.KeyCode.ButtonR1) then
					v_u_1216(v1925 == Enum.KeyCode.ButtonR1 and 1 or -1)
					return
				end
				if v_u_31.mode == "hollow" and (p1923.UserInputType == Enum.UserInputType.Keyboard and v_u_1225(v1925) ~= 0) then
					v_u_1216((v_u_1225(v1925)))
					return
				end
				if v_u_27.cursorOn and (v1925 == Enum.KeyCode.ButtonX or v1925 == Enum.KeyCode.ButtonA and game:GetService("GuiService").SelectedObject == nil) then
					v_u_222(v_u_27.cursor)
				end
			end
		else
			if v1925 == Enum.KeyCode.ButtonR3 and v_u_32.ctl then
				v_u_32.ctl.centerMe()
				return
			end
			if v_u_31.mode == "hollow" and (v1925 == Enum.KeyCode.ButtonL1 or v1925 == Enum.KeyCode.ButtonR1) then
				v_u_1216(v1925 == Enum.KeyCode.ButtonR1 and 1 or -1)
				return
			end
			if v_u_31.mode == "hollow" and (p1923.UserInputType == Enum.UserInputType.Keyboard and v_u_1225(v1925) ~= 0) then
				v_u_1216((v_u_1225(v1925)))
				return
			end
			if v_u_27.cursorOn and (v1925 == Enum.KeyCode.ButtonX or v1925 == Enum.KeyCode.ButtonA and game:GetService("GuiService").SelectedObject == nil) then
				v_u_222(v_u_27.cursor)
			end
			return
		end
	end)
	local v1936 = v_u_7.session
	if v1936 and v1936.onPlaceChanged then
		v1936.onPlaceChanged(function()
			-- upvalues: (ref) v_u_17, (ref) v_u_6, (ref) v_u_242, (ref) v_u_25, (ref) v_u_26, (ref) v_u_1617
			if v_u_17 then
				v_u_6.close()
			end
			v_u_242()
			table.clear(v_u_25)
			table.clear(v_u_26)
			task.defer(v_u_1617)
		end)
	end
	v_u_1617()
end
local v_u_1937 = { Color3.fromRGB(229, 143, 46), Color3.fromRGB(76, 168, 108), Color3.fromRGB(160, 110, 210) }
local v_u_1938 = Color3.fromRGB(46, 128, 214)
local v_u_1939 = {
	["me"] = {
		["len"] = 11,
		["mid"] = 15.5
	},
	["mate"] = {
		["len"] = 8,
		["mid"] = 12
	}
}
local v_u_1940 = {}
local v_u_1941 = nil
local v_u_1942 = 0
local function v_u_1944() -- name: clearPositions
	-- upvalues: (copy) v_u_1940, (ref) v_u_1941
	for _, v1943 in v_u_1940 do
		v1943.root:Destroy()
	end
	table.clear(v_u_1940)
	if v_u_1941 then
		v_u_1941:Destroy()
		v_u_1941 = nil
	end
end
local function v_u_1967(p1945, p1946, p1947, p1948, p1949, p1950, p1951) -- name: tagLayout
	local v1952 = false
	local v1953 = p1946 + p1947 + 3
	local v1954
	if p1951 < v1953 + p1949 then
		v1954 = p1946 - p1947 - 3 - p1949
		if v1954 >= 0 then
			v1952 = true
		else
			v1954 = v1953
		end
	else
		v1954 = v1953
	end
	local v1955
	if v1954 < 0 or p1951 < v1954 + p1949 then
		local v1956 = p1951 - p1949
		local v1957 = math.max(0, v1956)
		v1955 = math.clamp(v1954, 0, v1957) - v1954
	else
		v1955 = 0
	end
	local v1958
	if p1948 <= p1950 then
		local v1959 = p1948 / 2
		local v1960 = p1950 - p1948 / 2
		v1958 = math.clamp(p1945, v1959, v1960)
	else
		v1958 = p1950 / 2
	end
	local v1961 = v1958 - p1945
	local v1962
	if v1961 > 1e-6 then
		local v1963 = v1961 - 1e-6
		v1962 = math.ceil(v1963)
	elseif v1961 < -1e-6 then
		local v1964 = v1961 + 1e-6
		v1962 = math.floor(v1964)
	else
		v1962 = 0
	end
	if v1955 > 1e-6 then
		local v1965 = v1955 - 1e-6
		return v1952, v1962, math.ceil(v1965)
	end
	if v1955 >= -1e-6 then
		return v1952, v1962, 0
	end
	local v1966 = v1955 + 1e-6
	return v1952, v1962, math.floor(v1966)
end
local function v_u_1981(p_u_1968, p_u_1969) -- name: insideRange
	-- upvalues: (ref) v_u_13
	local function v1980(p1970, p1971) -- name: edge
		-- upvalues: (ref) v_u_13, (copy) p_u_1968, (copy) p_u_1969
		local v1972
		if p1971 then
			local v1973 = v_u_13.toWorld(p1970 * p_u_1968, p_u_1969 * 0.5)
			v1972 = v_u_13.inside(v1973.X, v1973.Y)
		else
			local v1974 = v_u_13.toWorld(p_u_1968 * 0.5, p1970 * p_u_1969)
			v1972 = v_u_13.inside(v1974.X, v1974.Y)
		end
		if v1972 then
			return p1970
		end
		local v1975 = 0.5
		for _ = 1, 24 do
			local v1976 = (v1975 + p1970) / 2
			local v1977
			if p1971 then
				local v1978 = v_u_13.toWorld(v1976 * p_u_1968, p_u_1969 * 0.5)
				v1977 = v_u_13.inside(v1978.X, v1978.Y)
			else
				local v1979 = v_u_13.toWorld(p_u_1968 * 0.5, v1976 * p_u_1969)
				v1977 = v_u_13.inside(v1979.X, v1979.Y)
			end
			if v1977 then
				v1975 = v1976
			else
				p1970 = v1976
			end
		end
		return v1975
	end
	return v1980(0, true), v1980(1, true), v1980(0, false), v1980(1, false)
end
local function v_u_2003() -- name: fakeEntries
	-- upvalues: (ref) v_u_1772, (ref) v_u_13, (copy) v_u_1981, (copy) v_u_1938, (copy) v_u_1937
	local v1982 = {}
	if not (v_u_1772 and (v_u_13 and (v_u_13.toWorld and v_u_13.inside))) then
		return v1982
	end
	local v1983 = v_u_13.innerW or (v_u_13.inner or 0)
	local v1984 = v_u_13.innerH or (v_u_13.inner or 0)
	local v1985, v1986, v1987, v1988 = v_u_1981(v1983, v1984)
	local v1989 = v_u_13.floorY
	local v1990 = type(v1989) ~= "number" and 3 or v_u_13.floorY
	local v1991 = 0
	for _, v1992 in v_u_1772 do
		local v1993 = v_u_13.toWorld((v1985 + v1992.fx * (v1986 - v1985)) * v1983, (v1987 + v1992.fy * (v1988 - v1987)) * v1984)
		local v1994 = v1992.key == "me"
		if not v1994 then
			v1991 = v1991 + 1
		end
		local v1995 = v1992.yaw
		local v1996 = math.rad(v1995)
		local v1997 = {
			["key"] = v1992.key
		}
		local v1998 = v1993.X
		local v1999 = v1993.Y
		v1997.pos = Vector3.new(v1998, v1990, v1999)
		local v2000 = -math.sin(v1996)
		local v2001 = -math.cos(v1996)
		v1997.look = Vector3.new(v2000, 0, v2001)
		v1997.name = v1992.name
		local v2002
		if v1994 then
			v2002 = v_u_1938
		else
			v2002 = v_u_1937[(v1991 - 1) % #v_u_1937 + 1]
		end
		v1997.color = v2002
		v1997.me = v1994
		table.insert(v1982, v1997)
	end
	return v1982
end
local function v_u_2009() -- name: squadNet
	-- upvalues: (ref) v_u_7
	local v2004 = v_u_7 and v_u_7.shared
	if v2004 then
		v2004 = v_u_7.shared.Config
	end
	if v2004 then
		local v2005 = v2004.flag
		if type(v2005) == "function" and v2004.flag("SquadMapNet") ~= false then
			local function v2006()
				-- upvalues: (ref) v_u_7
				return v_u_7.lib.SquadPosClient
			end
			local v2007, v2008 = pcall(v2006)
			if v2007 and type(v2008) == "table" then
				return v2008.byUid(os.clock())
			else
				return nil
			end
		end
	end
	return nil
end
local function v_u_2044() -- name: collectPositionEntries
	-- upvalues: (ref) v_u_1772, (copy) v_u_2003, (copy) v_u_10, (copy) v_u_1938, (copy) v_u_3, (copy) v_u_2009, (copy) v_u_1937, (ref) v_u_7
	if v_u_1772 then
		return v_u_2003()
	end
	local v2010 = {}
	local v2011 = v_u_10.Character
	if v2011 then
		v2011 = v2011:FindFirstChild("HumanoidRootPart")
	end
	if v2011 then
		local v2012 = v2011.CFrame.LookVector
		local v2013 = {
			["key"] = "me",
			["pos"] = nil,
			["look"] = nil,
			["name"] = "YOU",
			["color"] = nil,
			["me"] = true,
			["pos"] = v2011.Position
		}
		local v2014 = v2012.X
		local v2015 = v2012.Z
		v2013.look = Vector3.new(v2014, 0, v2015)
		v2013.color = v_u_1938
		table.insert(v2010, v2013)
	end
	local v2016 = v_u_10:GetAttribute("SquadId")
	if type(v2016) == "string" and v2016 ~= "" then
		local v2017 = {}
		local v2018 = 0
		for _, v2019 in v_u_3:GetPlayers() do
			if v2019 == v_u_10 or v2019:GetAttribute("SquadId") ~= v2016 then
				continue
			end
			table.insert(v2017, v2019)
		end
		table.sort(v2017, function(p2020, p2021)
			return p2020.UserId < p2021.UserId
		end)
		local v2022 = v_u_2009()
		local v2023 = {}
		for _, v2024 in v2017 do
			v2018 = v2018 + 1
			local v2025 = nil
			local v2026 = 0
			if v2022 then
				local v2027 = v2022[v2024.UserId]
				if v2027 then
					v2025 = v2027.pos
					v2026 = v2027.yaw
					v2023[v2024.UserId] = true
				end
			else
				v2025 = v2024:GetAttribute("MapPos")
				v2026 = tonumber(v2024:GetAttribute("MapYaw")) or 0
			end
			if typeof(v2025) ~= "Vector3" then
				continue
			end
			local v2028 = {
				["key"] = nil,
				["pos"] = nil,
				["look"] = nil,
				["name"] = nil,
				["color"] = nil,
				["me"] = false,
				["key"] = "u" .. v2024.UserId,
				["pos"] = v2025
			}
			local v2029 = -math.sin(v2026)
			local v2030 = -math.cos(v2026)
			v2028.look = Vector3.new(v2029, 0, v2030)
			local v2031 = string.upper
			local v2032 = v2024.DisplayName
			v2028.name = v2031((string.sub(v2032, 1, 6)))
			v2028.color = v_u_1937[(v2018 - 1) % #v_u_1937 + 1]
			table.insert(v2010, v2028)
		end
		if v2022 then
			local v2033 = {}
			for v2034 in v2022 do
				if v2023[v2034] then
					continue
				end
				table.insert(v2033, v2034)
			end
			table.sort(v2033)
			for _, v2035 in v2033 do
				v2018 = v2018 + 1
				local v2036 = v2022[v2035]
				local v2037 = {
					["key"] = nil,
					["pos"] = nil,
					["look"] = nil,
					["name"] = nil,
					["color"] = nil,
					["me"] = false,
					["key"] = "u" .. v2035,
					["pos"] = v2036.pos
				}
				local v2038 = v2036.yaw
				local v2039 = -math.sin(v2038)
				local v2040 = v2036.yaw
				local v2041 = -math.cos(v2040)
				v2037.look = Vector3.new(v2039, 0, v2041)
				local v2042 = string.upper
				local v2043 = v_u_7.lib.SquadPosClient.nameOf(v2035)
				v2037.name = v2042((string.sub(v2043, 1, 6)))
				v2037.color = v_u_1937[(v2018 - 1) % #v_u_1937 + 1]
				table.insert(v2010, v2037)
			end
		end
	end
	return v2010
end
local function v_u_2106(p2045, p2046) -- name: refreshPositions
	-- upvalues: (ref) v_u_13, (ref) v_u_17, (ref) v_u_7, (copy) v_u_1944, (copy) v_u_2044, (copy) v_u_31, (copy) v_u_1940, (copy) v_u_1939, (ref) v_u_8, (ref) v_u_9, (copy) v_u_5, (copy) v_u_1967, (ref) v_u_1941, (copy) v_u_1938
	local v2047 = p2045 or v_u_13
	if (p2045 or v_u_17) and (v2047 and (v2047.hollow or v2047.positions) and v2047.marks) then
		local v2048 = v_u_7 and v_u_7.shared
		if v2048 then
			v2048 = v_u_7.shared.Config
		end
		if v2048 then
			v2048 = v2048.MAP_SHOW_POSITION == false
		end
		if not v2048 then
			local v2049 = v2047.marks
			local v2050 = p2046 or v_u_2044()
			local v2051 = v2047.innerW or (v2047.inner or 0)
			local v2052 = v2047.innerH or (v2047.inner or 0)
			local v2053 = {}
			local v2054 = {}
			for _, v2055 in v2050 do
				local v2056 = v2055.pos.Y + 2.5
				local v2057
				if v_u_31.mode == "hollow" then
					local function v2058()
						-- upvalues: (ref) v_u_7
						return v_u_7.shared.HollowLevels
					end
					local v2059, v2060 = pcall(v2058)
					if not v2059 or type(v2060) ~= "table" then
						v2060 = nil
					end
					if v2060 then
						v2057 = v2060.levelOf(v2056)
					else
						v2057 = nil
					end
				else
					v2057 = nil
				end
				if v2057 == v2047.level and v2047.inside(v2055.pos.X, v2055.pos.Z) then
					v2054[v2055.key] = true
					local v2061 = v_u_1940[v2055.key]
					if v2061 and (v2061.root.Parent ~= v2049 or v2061.tick.Parent ~= v2061.root) then
						v2061.root:Destroy()
						v_u_1940[v2055.key] = nil
						v2061 = nil
					end
					local v2062 = v2055.me and 16 or 12
					local v2063
					if v2055.me then
						v2063 = v_u_1939.me
					else
						v2063 = v_u_1939.mate
					end
					if not v2061 then
						local v2064 = v_u_8.new("Frame", {
							["Name"] = nil,
							["AnchorPoint"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["ZIndex"] = 40,
							["Name"] = "Pos_" .. v2055.key,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Size"] = UDim2.fromOffset(v2062, v2062),
							["BackgroundColor3"] = v2055.color
						}, v2049)
						local v2065 = Instance.new("UICorner")
						v2065.CornerRadius = UDim.new(1, 0)
						v2065.Parent = v2064
						local v2066 = Instance.new("UIStroke")
						v2066.Color = Color3.fromRGB(250, 246, 235)
						v2066.Thickness = 2
						v2066.Parent = v2064
						local v2067 = v_u_8.new("Frame", {
							["Name"] = "Facing",
							["AnchorPoint"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["ZIndex"] = 39,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Size"] = UDim2.fromOffset(v2063.len, 4),
							["BackgroundColor3"] = v2055.color
						}, v2064)
						local v_u_2068 = not v_u_9 and 11 or v_u_9.phoneText(11, "caption")
						local v_u_2069 = v2055.name
						local function v2070()
							-- upvalues: (ref) v_u_5, (copy) v_u_2069, (copy) v_u_2068
							return v_u_5:GetTextSize(v_u_2069, v_u_2068 or 11, Enum.Font.GothamBold, Vector2.new(400, 20)).X
						end
						local v2071, v2072 = pcall(v2070)
						if not v2071 or type(v2072) ~= "number" then
							v2072 = #v_u_2069 * 8
						end
						local v2073 = v2072 + 4
						local v2074 = math.ceil(v2073)
						local v2075 = v2074 + v2074 % 2
						v2061 = {
							["root"] = v2064,
							["tick"] = v2067,
							["label"] = v_u_8.new("TextLabel", {
								["Name"] = "Name",
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundTransparency"] = 1,
								["Text"] = nil,
								["TextColor3"] = nil,
								["TextStrokeColor3"] = nil,
								["TextStrokeTransparency"] = 0.2,
								["Font"] = nil,
								["TextSize"] = nil,
								["ZIndex"] = 41,
								["AnchorPoint"] = Vector2.new(0.5, 0),
								["Position"] = UDim2.new(0.5, 0, 1, 3),
								["Size"] = UDim2.fromOffset(v2075, v_u_2068 + 1),
								["Text"] = v2055.name,
								["TextColor3"] = v2055.color,
								["TextStrokeColor3"] = Color3.fromRGB(250, 246, 235),
								["Font"] = Enum.Font.GothamBold,
								["TextSize"] = v_u_2068
							}, v2064),
							["tw"] = v2075,
							["r"] = v2062 / 2,
							["th"] = v_u_2068 + 1
						}
						v_u_1940[v2055.key] = v2061
					end
					local v2076 = v2047.toPx(v2055.pos.X, v2055.pos.Z)
					local v2077 = v2047.toPx(v2055.pos.X + v2055.look.X * 6, v2055.pos.Z + v2055.look.Z * 6) - v2076
					local v2078
					if v2077.Magnitude > 0.01 then
						local v2079 = v2077.Y
						local v2080 = v2077.X
						v2078 = math.atan2(v2079, v2080)
					else
						v2078 = 0
					end
					local v2081 = v2076.X
					local v2082 = math.floor(v2081)
					local v2083 = v2076.Y
					local v2084 = math.floor(v2083)
					v2061.root.Position = UDim2.fromOffset(v2082, v2084)
					local v2085 = Vector2.new(math.cos(v2078), (math.sin(v2078))) * v2063.mid
					local v2086 = v2061.tick
					local v2087 = UDim2.new
					local v2088 = v2085.X
					local v2089 = math.round(v2088)
					local v2090 = v2085.Y
					v2086.Position = v2087(0.5, v2089, 0.5, (math.round(v2090)))
					v2061.tick.Rotation = math.deg(v2078)
					if v2051 <= 0 or v2052 <= 0 then
						continue
					end
					local v2091, v2092, v2093 = v_u_1967(v2082, v2084, v2061.r, v2061.tw, v2061.th or 12, v2051, v2052)
					v2061.label.AnchorPoint = Vector2.new(0.5, v2091 and 1 or 0)
					v2061.label.Position = UDim2.new(0.5, v2092, v2091 and 0 or 1, (v2091 and -3 or 3) + v2093)
				else
					if not v2047.hollow then
						continue
					end
					local v2094
					if v2057 then
						local v2095 = string.match
						v2094 = tonumber(v2095(v2057, "%d"))
					else
						v2094 = nil
					end
					local v2096 = string.match
					local v2097 = v2047.level
					local v2098 = tostring(v2097)
					local v2099 = tonumber(v2096(v2098, "%d"))
					local v2100 = v2094 and v2099 and (v2099 < v2094 and "BELOW" or "ABOVE") or "ELSEWHERE"
					local v2101 = string.format
					local v2102 = v2055.name
					local v2103 = not v2094 and "?" or tostring(v2094)
					table.insert(v2053, v2101("%s: LEVEL %s, %s", v2102, v2103, v2100))
				end
			end
			for v2104, v2105 in v_u_1940 do
				if v2054[v2104] then
					continue
				end
				v2105.root:Destroy()
				v_u_1940[v2104] = nil
			end
			if #v2053 > 0 then
				if not v_u_1941 or v_u_1941.Parent ~= v2049 then
					if v_u_1941 then
						v_u_1941:Destroy()
					end
					v_u_1941 = v_u_8.new("TextLabel", {
						["Name"] = "PositionNote",
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundTransparency"] = 1,
						["TextXAlignment"] = nil,
						["TextYAlignment"] = nil,
						["Font"] = nil,
						["TextSize"] = nil,
						["TextColor3"] = nil,
						["TextStrokeColor3"] = nil,
						["TextStrokeTransparency"] = 0.3,
						["ZIndex"] = 42,
						["Position"] = UDim2.fromOffset(10, 8),
						["Size"] = UDim2.fromOffset(220, 60),
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextYAlignment"] = Enum.TextYAlignment.Top,
						["Font"] = Enum.Font.GothamBold,
						["TextSize"] = not v_u_9 and 13 or v_u_9.phoneText(13, "text"),
						["TextColor3"] = v_u_1938,
						["TextStrokeColor3"] = Color3.fromRGB(250, 246, 235)
					}, v2049)
				end
				v_u_1941.Text = table.concat(v2053, "\n")
			elseif v_u_1941 then
				v_u_1941:Destroy()
				v_u_1941 = nil
			end
		end
	end
	v_u_1944()
end
v_u_6.posTest = {
	["refresh"] = v_u_2106,
	["clear"] = v_u_1944,
	["marks"] = v_u_1940,
	["tagLayout"] = v_u_1967,
	["tagWidth"] = function(p_u_2107, p_u_2108) -- name: tagWidth
		-- upvalues: (copy) v_u_5
		local function v2109()
			-- upvalues: (ref) v_u_5, (copy) p_u_2107, (copy) p_u_2108
			return v_u_5:GetTextSize(p_u_2107, p_u_2108 or 11, Enum.Font.GothamBold, Vector2.new(400, 20)).X
		end
		local v2110, v2111 = pcall(v2109)
		if not v2110 or type(v2111) ~= "number" then
			v2111 = #p_u_2107 * 8
		end
		local v2112 = v2111 + 4
		local v2113 = math.ceil(v2112)
		return v2113 + v2113 % 2
	end
}
function v_u_6.step(p2114) -- name: step
	-- upvalues: (ref) v_u_17, (ref) v_u_7, (copy) v_u_10, (copy) v_u_6, (ref) v_u_1533, (copy) v_u_4, (ref) v_u_13, (copy) v_u_239, (ref) v_u_8, (copy) v_u_27, (copy) v_u_32, (ref) v_u_1942, (copy) v_u_2106, (ref) v_u_21, (copy) v_u_134, (copy) v_u_151, (copy) v_u_25, (copy) v_u_26, (copy) v_u_235, (ref) v_u_20, (ref) v_u_162, (copy) v_u_161
	if not v_u_17 then
		return
	end
	local v2115 = v_u_7
	if v2115 then
		v2115 = v_u_7.session
	end
	local v2116, v2117, v2118, v2119, v2120, v2121, v2122, v2123, v2124, v2125, v2126, v2127, v2128, v2129, v2130, v2131, v2132, v2133, v2134, v2135, v2136, v2137, v2138, v2139, v2140, v2141, v2142, v2143, v2144
	if v2115 and v2115.place then
		local v2145 = v2115.place
		local v2146 = v_u_10
		local v2147
		v2147, v2116 = pcall(v2145, v2146)
		if v2147 and type(v2116) == "string" then
			if v2116 == "Raid" then
				v2117 = v_u_10.Character
				if v2117 == nil then
					v2118 = false
				else
					v2118 = v2117:GetAttribute("Dead") == true
				end
				if not v2118 then
					v2119 = v_u_10:FindFirstChildOfClass("PlayerGui")
					if v2119 then
						v2119 = v2119:FindFirstChild("HushReticle")
					end
					if v2119 and (v2119:IsA("ScreenGui") and v2119.Enabled) then
						v2119.Enabled = false
						v_u_1533 = v2119
					end
					if v_u_4.MouseEnabled and not v_u_4.MouseIconEnabled then
						v_u_4.MouseIconEnabled = true
					end
					if v_u_13 then
						v2120 = v_u_239()
					else
						v2120 = nil
					end
					if v2120 then
						v2121 = v_u_8.device() == "Gamepad"
						if v2121 and not v_u_27.cursorOn then
							v_u_27.cursorOn = true
							v2122 = v_u_7 and v_u_7.controllers
							if v2122 then
								v2122 = v_u_7.controllers.Comms
							end
							if v2122 then
								v2123 = v_u_7 and v_u_7.controllers
								if v2123 then
									v2123 = v_u_7.controllers.Comms
								end
								v2122 = v2123.waypoint
								if v2122 then
									v2124 = v_u_7 and v_u_7.controllers
									if v2124 then
										v2124 = v_u_7.controllers.Comms
									end
									v2122 = v2124.waypoint()
								end
							end
							v2125 = v_u_27
							if v2122 then
								v2126 = v_u_13.toPx(v2122.X, v2122.Z)
							else
								v2126 = Vector2.new((not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)) / 2, (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)) / 2)
							end
							v2125.cursor = v2126
						elseif not v2121 then
							v_u_27.cursorOn = false
						end
						v2120.Visible = v_u_27.cursorOn
						if v_u_27.cursorOn then
							v2127 = Vector2.zero
							for v2164, v2165 in v_u_7.lib.VirtualPad.gamepadState() do
								if v2165.KeyCode ~= Enum.KeyCode.Thumbstick1 and v2165.KeyCode ~= Enum.KeyCode.Thumbstick2 then
									continue
								end
								v2128 = Vector2.new(v2165.Position.X, -v2165.Position.Y)
								if v2128.Magnitude <= 0.18 then
									continue
								end
								v2127 = v2127 + v2128
							end
							if v2127.Magnitude > 0 then
								v2129 = v_u_13.inner * 0.55
								v2130 = v2127.Magnitude
								v2131 = v2129 * math.clamp(v2130, 0, 1) ^ 1.5
								if v_u_32.ctl then
									v2131 = v2131 * v_u_7.shared.MapZoomRule.padSpeed(v_u_32.ctl.zoom())
								end
								v2132 = v2127.Unit * v2131 * p2114
								v2133 = v_u_27
								v2134 = Vector2.new
								v2135 = v_u_27.cursor.X + v2132.X
								v2136 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
								v2137 = math.clamp(v2135, 0, v2136)
								v2138 = v_u_27.cursor.Y + v2132.Y
								v2139 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
								v2133.cursor = v2134(v2137, (math.clamp(v2138, 0, v2139)))
							end
							v2120.Position = UDim2.fromOffset(v_u_27.cursor.X, v_u_27.cursor.Y)
						end
					end
					if v_u_32.ctl then
						v_u_32.ctl.step(p2114)
					end
					v_u_1942 = v_u_1942 + p2114
					if v_u_1942 >= 0.2 then
						v_u_1942 = 0
						v_u_2106()
					end
					v_u_21 = v_u_21 + p2114
					if v_u_21 >= 0.5 then
						v_u_21 = 0
						v2140 = v_u_134()
						v2141 = v_u_151(v2140)
						v2142 = os.clock()
						v2143 = {}
						for v2166, v2167 in v_u_25 do
							if v2167 > v2142 then
								continue
							end
							table.insert(v2143, v2166)
						end
						for v2168, v2169 in v_u_26 do
							if v2169 > v2142 then
								continue
							end
							v_u_26[v2168] = nil
							v2141 = v2141 .. "#c" .. v2168
						end
						if v_u_235() ~= v_u_27.sig then
							v2141 = v2141 .. "#wp"
						end
						for v2170, v2171 in v2143 do
							v_u_25[v2171] = nil
							v2141 = v2141 .. "#" .. v2171
						end
						if v2141 ~= v_u_20 then
							v_u_20 = v_u_151(v2140)
							v_u_162(v2140)
						end
						v_u_161()
					end
				end
			end
			v_u_6.close()
		else
			v2144 = v_u_10:GetAttribute("Place")
			v2116 = type(v2144) ~= "string" and "" or v2144
			if v2116 == "Raid" then
				v2117 = v_u_10.Character
				if v2117 == nil then
					v2118 = false
				else
					v2118 = v2117:GetAttribute("Dead") == true
				end
				if not v2118 then
					v2119 = v_u_10:FindFirstChildOfClass("PlayerGui")
					if v2119 then
						v2119 = v2119:FindFirstChild("HushReticle")
					end
					if v2119 and (v2119:IsA("ScreenGui") and v2119.Enabled) then
						v2119.Enabled = false
						v_u_1533 = v2119
					end
					if v_u_4.MouseEnabled and not v_u_4.MouseIconEnabled then
						v_u_4.MouseIconEnabled = true
					end
					if v_u_13 then
						v2120 = v_u_239()
					else
						v2120 = nil
					end
					if v2120 then
						v2121 = v_u_8.device() == "Gamepad"
						if v2121 and not v_u_27.cursorOn then
							v_u_27.cursorOn = true
							v2122 = v_u_7 and v_u_7.controllers
							if v2122 then
								v2122 = v_u_7.controllers.Comms
							end
							if v2122 then
								v2123 = v_u_7 and v_u_7.controllers
								if v2123 then
									v2123 = v_u_7.controllers.Comms
								end
								v2122 = v2123.waypoint
								if v2122 then
									v2124 = v_u_7 and v_u_7.controllers
									if v2124 then
										v2124 = v_u_7.controllers.Comms
									end
									v2122 = v2124.waypoint()
								end
							end
							v2125 = v_u_27
							if v2122 then
								v2126 = v_u_13.toPx(v2122.X, v2122.Z)
							else
								v2126 = Vector2.new((not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)) / 2, (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)) / 2)
							end
							v2125.cursor = v2126
						elseif not v2121 then
							v_u_27.cursorOn = false
						end
						v2120.Visible = v_u_27.cursorOn
						if v_u_27.cursorOn then
							v2127 = Vector2.zero
							for v2164, v2165 in v_u_7.lib.VirtualPad.gamepadState() do
								if v2165.KeyCode ~= Enum.KeyCode.Thumbstick1 and v2165.KeyCode ~= Enum.KeyCode.Thumbstick2 then
									continue
								end
								v2128 = Vector2.new(v2165.Position.X, -v2165.Position.Y)
								if v2128.Magnitude <= 0.18 then
									continue
								end
								v2127 = v2127 + v2128
							end
							if v2127.Magnitude > 0 then
								v2129 = v_u_13.inner * 0.55
								v2130 = v2127.Magnitude
								v2131 = v2129 * math.clamp(v2130, 0, 1) ^ 1.5
								if v_u_32.ctl then
									v2131 = v2131 * v_u_7.shared.MapZoomRule.padSpeed(v_u_32.ctl.zoom())
								end
								v2132 = v2127.Unit * v2131 * p2114
								v2133 = v_u_27
								v2134 = Vector2.new
								v2135 = v_u_27.cursor.X + v2132.X
								v2136 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
								v2137 = math.clamp(v2135, 0, v2136)
								v2138 = v_u_27.cursor.Y + v2132.Y
								v2139 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
								v2133.cursor = v2134(v2137, (math.clamp(v2138, 0, v2139)))
							end
							v2120.Position = UDim2.fromOffset(v_u_27.cursor.X, v_u_27.cursor.Y)
						end
					end
					if v_u_32.ctl then
						v_u_32.ctl.step(p2114)
					end
					v_u_1942 = v_u_1942 + p2114
					if v_u_1942 >= 0.2 then
						v_u_1942 = 0
						v_u_2106()
					end
					v_u_21 = v_u_21 + p2114
					if v_u_21 >= 0.5 then
						v_u_21 = 0
						v2140 = v_u_134()
						v2141 = v_u_151(v2140)
						v2142 = os.clock()
						v2143 = {}
						for v2166, v2167 in v_u_25 do
							if v2167 > v2142 then
								continue
							end
							table.insert(v2143, v2166)
						end
						for v2168, v2169 in v_u_26 do
							if v2169 > v2142 then
								continue
							end
							v_u_26[v2168] = nil
							v2141 = v2141 .. "#c" .. v2168
						end
						if v_u_235() ~= v_u_27.sig then
							v2141 = v2141 .. "#wp"
						end
						for v2170, v2171 in v2143 do
							v_u_25[v2171] = nil
							v2141 = v2141 .. "#" .. v2171
						end
						if v2141 ~= v_u_20 then
							v_u_20 = v_u_151(v2140)
							v_u_162(v2140)
						end
						v_u_161()
					end
				end
			end
			v_u_6.close()
		end
	else
		v2144 = v_u_10:GetAttribute("Place")
		v2116 = type(v2144) ~= "string" and "" or v2144
		if v2116 == "Raid" then
			v2117 = v_u_10.Character
			if v2117 == nil then
				v2118 = false
			else
				v2118 = v2117:GetAttribute("Dead") == true
			end
			if not v2118 then
				v2119 = v_u_10:FindFirstChildOfClass("PlayerGui")
				if v2119 then
					v2119 = v2119:FindFirstChild("HushReticle")
				end
				if v2119 and (v2119:IsA("ScreenGui") and v2119.Enabled) then
					v2119.Enabled = false
					v_u_1533 = v2119
				end
				if v_u_4.MouseEnabled and not v_u_4.MouseIconEnabled then
					v_u_4.MouseIconEnabled = true
				end
				if v_u_13 then
					v2120 = v_u_239()
				else
					v2120 = nil
				end
				if v2120 then
					v2121 = v_u_8.device() == "Gamepad"
					if v2121 and not v_u_27.cursorOn then
						v_u_27.cursorOn = true
						v2122 = v_u_7 and v_u_7.controllers
						if v2122 then
							v2122 = v_u_7.controllers.Comms
						end
						if v2122 then
							v2123 = v_u_7 and v_u_7.controllers
							if v2123 then
								v2123 = v_u_7.controllers.Comms
							end
							v2122 = v2123.waypoint
							if v2122 then
								v2124 = v_u_7 and v_u_7.controllers
								if v2124 then
									v2124 = v_u_7.controllers.Comms
								end
								v2122 = v2124.waypoint()
							end
						end
						v2125 = v_u_27
						if v2122 then
							v2126 = v_u_13.toPx(v2122.X, v2122.Z)
						else
							v2126 = Vector2.new((not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)) / 2, (not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)) / 2)
						end
						v2125.cursor = v2126
					elseif not v2121 then
						v_u_27.cursorOn = false
					end
					v2120.Visible = v_u_27.cursorOn
					if v_u_27.cursorOn then
						v2127 = Vector2.zero
						for v2164, v2165 in v_u_7.lib.VirtualPad.gamepadState() do
							if v2165.KeyCode ~= Enum.KeyCode.Thumbstick1 and v2165.KeyCode ~= Enum.KeyCode.Thumbstick2 then
								continue
							end
							v2128 = Vector2.new(v2165.Position.X, -v2165.Position.Y)
							if v2128.Magnitude <= 0.18 then
								continue
							end
							v2127 = v2127 + v2128
						end
						if v2127.Magnitude > 0 then
							v2129 = v_u_13.inner * 0.55
							v2130 = v2127.Magnitude
							v2131 = v2129 * math.clamp(v2130, 0, 1) ^ 1.5
							if v_u_32.ctl then
								v2131 = v2131 * v_u_7.shared.MapZoomRule.padSpeed(v_u_32.ctl.zoom())
							end
							v2132 = v2127.Unit * v2131 * p2114
							v2133 = v_u_27
							v2134 = Vector2.new
							v2135 = v_u_27.cursor.X + v2132.X
							v2136 = not v_u_13 or v_u_13.innerW or (v_u_13.inner or 0)
							v2137 = math.clamp(v2135, 0, v2136)
							v2138 = v_u_27.cursor.Y + v2132.Y
							v2139 = not v_u_13 or v_u_13.innerH or (v_u_13.inner or 0)
							v2133.cursor = v2134(v2137, (math.clamp(v2138, 0, v2139)))
						end
						v2120.Position = UDim2.fromOffset(v_u_27.cursor.X, v_u_27.cursor.Y)
					end
				end
				if v_u_32.ctl then
					v_u_32.ctl.step(p2114)
				end
				v_u_1942 = v_u_1942 + p2114
				if v_u_1942 >= 0.2 then
					v_u_1942 = 0
					v_u_2106()
				end
				v_u_21 = v_u_21 + p2114
				if v_u_21 >= 0.5 then
					v_u_21 = 0
					v2140 = v_u_134()
					v2141 = v_u_151(v2140)
					v2142 = os.clock()
					v2143 = {}
					for v2166, v2167 in v_u_25 do
						if v2167 > v2142 then
							continue
						end
						table.insert(v2143, v2166)
					end
					for v2168, v2169 in v_u_26 do
						if v2169 > v2142 then
							continue
						end
						v_u_26[v2168] = nil
						v2141 = v2141 .. "#c" .. v2168
					end
					if v_u_235() ~= v_u_27.sig then
						v2141 = v2141 .. "#wp"
					end
					for v2170, v2171 in v2143 do
						v_u_25[v2171] = nil
						v2141 = v2141 .. "#" .. v2171
					end
					if v2141 ~= v_u_20 then
						v_u_20 = v_u_151(v2140)
						v_u_162(v2140)
					end
					v_u_161()
				end
			end
		end
		v_u_6.close()
		return
	end
end
return v_u_6