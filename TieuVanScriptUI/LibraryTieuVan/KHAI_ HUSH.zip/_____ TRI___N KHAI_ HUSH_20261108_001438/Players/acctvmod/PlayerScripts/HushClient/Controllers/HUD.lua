-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / HUD

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = {
	["name"] = "HUD",
	["order"] = 40
}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = v1.LocalPlayer
local v_u_9 = {
	"HUDVitals",
	"HUDWeapon",
	"HUDClock",
	"HUDSquad",
	"HUDQuick",
	"HUDEffects",
	"HUDDowned",
	"HUDEvents",
	"HUDTasks",
	"HUDNoise",
	"HUDLevel",
	"HUDRaidMod",
	"HUDStun"
}
local v_u_10 = 0
local v_u_11 = false
local v_u_12 = nil
local function v_u_14() -- name: phoneHud
	-- upvalues: (ref) v_u_7, (ref) v_u_4
	local v13
	if v_u_7 == nil or v_u_4 == nil then
		v13 = false
	else
		v13 = v_u_4.config.flag("PhoneHud") ~= false
	end
	return v13
end
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = true
local v_u_19 = ""
local v_u_20 = nil
local function v_u_25(p21, p22, ...) -- name: safe
	-- upvalues: (copy) v_u_8
	if type(p22) == "function" then
		local v23, v24 = pcall(p22, ...)
		if not v23 then
			warn("[HUD]", p21, v24)
			v_u_8:SetAttribute("ClientError", "HUD " .. p21 .. ": " .. tostring(v24))
		end
	end
end
local v_u_26 = { 0.9, 1, 1.15 }
local function v_u_42(p27) -- name: touchScale
	-- upvalues: (ref) v_u_4, (copy) v_u_26, (copy) v_u_8
	local v_u_28 = v_u_4 and v_u_4.controllers
	if v_u_28 then
		v_u_28 = v_u_4.controllers.Input
	end
	if v_u_28 then
		local v29 = v_u_28.touch
		if type(v29) == "function" then
			local v31, v32 = pcall(function()
				-- upvalues: (copy) v_u_28
				local v30 = v_u_28.touch()
				if v30 then
					v30 = v30:info().scale
				end
				return v30
			end)
			if v31 and (type(v32) == "number" and (v32 > 0.3 and v32 < 4)) then
				return v32
			end
		end
	end
	local v33 = p27.X
	local v34 = p27.Y
	local v35 = math.min(v33, v34)
	local v36 = math.max(1, v35)
	local v37 = v_u_26[v_u_8:GetAttribute("TouchSize")] or 1
	local v38 = v36 / 390
	local v39 = math.clamp(v38, 0.8, 1.7) * v37
	local v40 = v36 / 345
	local v41 = math.min(v39, v40)
	return math.max(v41, 0.9166666666666666)
end
local function v_u_154() -- name: touchFrame
	-- upvalues: (ref) v_u_6, (copy) v_u_42, (copy) v_u_2, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7, (copy) v_u_8
	local v_u_43 = v_u_6.viewport()
	local v_u_44 = v_u_6.uiScale()
	local v45 = v_u_42(v_u_43)
	local v46 = v45 / v_u_44
	local v47 = v_u_43.X / v45
	local v48 = v_u_43.Y / v45
	local v49 = v_u_6.safeInsets()
	local v50 = (v_u_43.X - v49.left - v49.right) / v_u_44
	local v51 = (v_u_43.Y - v49.top - v49.bottom) / v_u_44
	local v_u_52 = 0
	local function v54()
		-- upvalues: (ref) v_u_2, (ref) v_u_52, (copy) v_u_44
		local v53 = v_u_2.TopbarInset
		if v53.Width > 0 then
			v_u_52 = v53.Min.X / v_u_44 + 8
		end
	end
	pcall(v54)
	local v55 = {
		["tlRight"] = 76 * v46,
		["trLeft"] = v50 - 71 * v46,
		["clusterTop"] = (v48 - 250) * v46,
		["clusterLeft"] = (v47 - 312) * v46,
		["bottomTop"] = (v48 - 18) * v46,
		["quickCx"] = (186 + v47 - 312) / 2 * v46,
		["moveRight"] = 186 * v46,
		["moveTop"] = (v48 - 166) * v46,
		["buttonsTop"] = 67 * v46,
		["rowTop"] = 79 * v46,
		["rowRight"] = 21 * v46,
		["rowLeft"] = v50 - 180 * v46
	}
	local v56 = v_u_4 and v_u_4.controllers
	if v56 then
		v56 = v_u_4.controllers.Input
	end
	local v57
	if v56 then
		local v58 = v56.touchRects
		if type(v58) == "function" then
			local v59 = v56.touchRects
			local v60
			v60, v57 = pcall(v59)
			if v60 and type(v57) == "table" then
				local v61 = v57.rightCluster
				if typeof(v61) ~= "Rect" then
					v57 = nil
				end
			else
				v57 = nil
			end
		else
			v57 = nil
		end
	else
		v57 = nil
	end
	if v57 then
		local v_u_62 = Vector2.zero
		local function v69()
			-- upvalues: (ref) v_u_12, (ref) v_u_4, (copy) v_u_43, (ref) v_u_62
			local v63 = v_u_12
			if v63 then
				v63 = v_u_12.gui
			end
			local v64 = v_u_4 and v_u_4.controllers
			if v64 then
				v64 = v_u_4.controllers.Input
			end
			local v65 = v64 and v64.touch
			if v65 then
				v65 = v64.touch()
			end
			if v65 then
				v65 = v65.root
			end
			if v63 and (v63.Parent and (v65 and v65.Parent)) then
				local v66 = v63.AbsolutePosition - v65.AbsolutePosition
				local v67 = v66.X
				if math.abs(v67) < v_u_43.X / 4 then
					local v68 = v66.Y
					if math.abs(v68) < v_u_43.Y / 4 then
						v_u_62 = v66
					end
				end
			end
		end
		pcall(v69)
		local v70 = v57.leftColumn
		local v71 = v57.rightCluster
		local v72 = v57.rightColumn
		local v73 = v57.quickBar
		local v74 = v57.moveStick
		if typeof(v70) == "Rect" then
			v55.tlRight = (v70.Max.X - v_u_62.X) / v_u_44
		end
		if typeof(v72) == "Rect" then
			v55.trLeft = (v72.Min.X - v_u_62.X) / v_u_44
		end
		if typeof(v72) == "Rect" then
			v55.rowTop = (v72.Min.Y - v_u_62.Y) / v_u_44
			v55.rowRight = v50 - (v72.Max.X - v_u_62.X) / v_u_44
			v55.rowLeft = (v72.Min.X - v_u_62.X) / v_u_44
		end
		v55.clusterTop = (v71.Min.Y - v_u_62.Y) / v_u_44
		v55.clusterLeft = (v71.Min.X - v_u_62.X) / v_u_44
		if typeof(v74) == "Rect" then
			v55.moveRight = (v74.Max.X - v_u_62.X) / v_u_44
			v55.moveTop = (v74.Min.Y - v_u_62.Y) / v_u_44
		end
		if typeof(v73) == "Rect" then
			v55.bottomTop = (v73.Min.Y - v_u_62.Y) / v_u_44
			v55.quickCx = ((v73.Min.X + v73.Max.X) / 2 - v_u_62.X) / v_u_44
		else
			v55.bottomTop = v51 - 18 * v46
			v55.quickCx = (v55.moveRight + v55.clusterLeft) / 2
		end
		local v75 = (v71.Min.Y - v_u_62.Y) / v_u_44
		local v76 = v_u_62
		for _, v77 in { v70, v72 } do
			if typeof(v77) ~= "Rect" then
				continue
			end
			local v78 = (v77.Min.Y - v76.Y) / v_u_44
			v75 = math.min(v75, v78)
		end
		v55.buttonsTop = v75
		v55.brTops = {}
		v55.obstacles = {}
		local v_u_79 = nil
		local function v82()
			-- upvalues: (ref) v_u_4, (ref) v_u_79
			local v80 = v_u_4 and v_u_4.controllers
			if v80 then
				v80 = v_u_4.controllers.Input
			end
			local v81
			if v80 and v80.touch then
				v81 = v80.touch()
			else
				v81 = nil
			end
			v_u_79 = v81
		end
		pcall(v82)
		local v83 = v_u_79
		for v84, v85 in v57 do
			if typeof(v85) == "Rect" and (v84 == "moveStick" or (v84 == "tray" or (v84 == "rightColumn" or (v84 == "leftColumn" or string.sub(v84, 1, 2) == "m_")))) then
				local v86 = v55.obstacles
				local v87 = {
					(v85.Min.X - v76.X) / v_u_44,
					(v85.Min.Y - v76.Y) / v_u_44,
					(v85.Max.X - v76.X) / v_u_44,
					(v85.Max.Y - v76.Y) / v_u_44
				}
				table.insert(v86, v87)
			end
			if typeof(v85) ~= "Rect" or v84 ~= "tray" then
				continue
			end
			v55.tray = {
				(v85.Min.X - v76.X) / v_u_44,
				(v85.Min.Y - v76.Y) / v_u_44,
				(v85.Max.X - v76.X) / v_u_44,
				(v85.Max.Y - v76.Y) / v_u_44
			}
		end
		local v88 = nil
		local v89
		if v83 then
			local v90 = v83.controlRects
			if type(v90) == "function" then
				local v91 = v83.controlRects
				local v92
				v92, v89 = pcall(v91, v83)
				if v92 then
					if type(v89) ~= "table" then
						v89 = v88
					end
				else
					v89 = v88
				end
			else
				v89 = v88
			end
		else
			v89 = v88
		end
		for v93, v94 in v89 or {} do
			if typeof(v94) ~= "Rect" then
				continue
			end
			local v95 = v55.brTops
			local v96 = { (v94.Min.X - v76.X) / v_u_44, (v94.Max.X - v76.X) / v_u_44, (v94.Min.Y - v76.Y) / v_u_44 }
			table.insert(v95, v96)
			if v93 == "viewToggle" then
				local v97 = (v94.Min.X - v76.X) / v_u_44
				local v98 = (v94.Min.Y - v76.Y) / v_u_44
				v55.viewLeft = v97
				v55.viewTop = v98
			end
			local v99 = v83.buttons[v93]
			local v100 = v99 and v99.gui
			if v100 then
				v100 = v99.gui.Parent
			end
			if v100 and v99.gui.Visible ~= true then
				continue
			end
			local v101 = v55.obstacles
			local v102 = {
				(v94.Min.X - v76.X) / v_u_44,
				(v94.Min.Y - v76.Y) / v_u_44,
				(v94.Max.X - v76.X) / v_u_44,
				(v94.Max.Y - v76.Y) / v_u_44
			}
			table.insert(v101, v102)
		end
	end
	local v103 = v55.tlRight + 16 * v46
	local v104 = v_u_52
	local v105 = math.max(v103, v104)
	local v106
	if v_u_6.isPhone() then
		local v107 = v55.tlRight + 16 * v46
		v106 = math.min(v105, v107)
	else
		v106 = v105
	end
	local v108 = v50 - v55.trLeft + 16 * v46
	local v109 = 12 * v46
	local v110 = math.max(v108, v109)
	local v111 = nil
	if v_u_6.isPhone() then
		local v112
		if v_u_7 == nil or v_u_4 == nil then
			v112 = false
		else
			v112 = v_u_4.config.flag("PhoneHud") ~= false
		end
		if v112 then
			v111 = v_u_7.cluster({
				["rowTop"] = v55.rowTop,
				["rowRight"] = v55.rowRight
			})
			v110 = v111.right
			local v113 = v55.moveRight
			local v114 = v_u_7.K.SQUAD_MARGIN_L + v_u_7.K.SQUAD_W + 8
			v55.moveRight = math.max(v113, v114)
		end
	end
	if v_u_7 then
		local v115 = v_u_7.setFrame
		local v116
		if v111 then
			v116 = v111.weaponScale
		else
			v116 = nil
		end
		v115(v50, v51, v116)
	end
	local v117 = 12 * v46
	local v118 = v55.clusterLeft - 10 * v46
	local v119 = v55.quickCx + 60 * v46
	local v120 = math.max(v118, v119)
	local v_u_121 = 0
	local function v124()
		-- upvalues: (ref) v_u_8, (ref) v_u_121, (copy) v_u_44
		local v122 = v_u_8:FindFirstChildOfClass("PlayerGui")
		if v122 then
			v122 = v122:FindFirstChild("HushTestTag")
		end
		local v123
		if v122 then
			v123 = v122:FindFirstChild("TestTag", true)
		else
			v123 = nil
		end
		if v122 and (v122.Enabled and (v123 and (v123:IsA("GuiObject") and (v123.Visible and v123.AbsoluteSize.X > 4)))) then
			v_u_121 = v123.AbsoluteSize.X / v_u_44 / 2 + 8
		end
	end
	pcall(v124)
	local v125 = v50 / 2 - 160 - 16 - v105
	local v126 = math.max(180, v125)
	local v127 = v50 / 2 - 160 - 16 - v110
	local v128 = math.max(180, v127)
	local v129 = v_u_6.isPhone()
	if v129 then
		local v130 = v50 - v110 - v105
		if v111 then
			v126 = v_u_7.vitalsWidth({
				["refW"] = v50,
				["left"] = v105,
				["right"] = v110,
				["weaponScale"] = v111.weaponScale,
				["rowLeft"] = v55.rowLeft
			})
			v128 = v_u_7.K.WEAPON_W
		else
			local v131 = v130 - 238
			local v132 = math.min(256, v131)
			v126 = math.max(180, v132)
			local v133 = v130 - v126 - 10
			v128 = math.max(180, v133)
		end
		if v_u_121 > 0 then
			local v134 = v50 / 2 - v_u_121 - v105
			local v135 = math.min(v126, v134)
			v126 = math.max(150, v135)
		end
	end
	local v136 = v55.clusterTop - 12 * v46
	if v129 and v55.brTops then
		local v137 = v50 - v110
		local v138 = v137 - math.min(296, v128)
		local v139 = (1 / 0)
		for _, v140 in v55.brTops do
			if v140[1] >= v137 or v138 >= v140[2] then
				continue
			end
			local v141 = v140[3]
			v139 = math.min(v139, v141)
		end
		if v139 == (1 / 0) then
			v136 = v51
		else
			v136 = v139 - 12 * v46
		end
	end
	local v142 = v117 + 44
	local v143 = v136 - 20 - v142
	if v143 < 76 then
		local v144 = v117 + 34
		local v145 = v142 - (76 - v143)
		v142 = math.max(v144, v145)
		v143 = v136 - 20 - v142
	end
	local v146 = v143 / 76
	local v147 = math.clamp(v146, 0.7, 1)
	local v148 = v142 + v147 * 76 + 4
	local v149 = v148 + 12 <= v136 + 8 * v46
	if v111 then
		v142 = v111.weaponY
		v147 = v111.weaponScale
		v148 = v111.weaponBottom + 4
		v149 = false
	end
	local v150 = {
		["k"] = v46,
		["refW"] = v50,
		["rowLeft"] = v55.rowLeft,
		["viewLeft"] = v55.viewLeft,
		["viewTop"] = v55.viewTop,
		["corner"] = v111,
		["left"] = v105,
		["bandLeft"] = v106,
		["obstacles"] = v55.obstacles or {},
		["tray"] = v55.tray,
		["right"] = v110,
		["top"] = v117,
		["rightMaxY"] = v136,
		["weaponY"] = v142,
		["weaponScale"] = v147,
		["weightY"] = v148,
		["weightFits"] = v149,
		["vitalsW"] = v126,
		["weaponW"] = v128,
		["listW"] = not v111 and 300 or v_u_7.K.BAND_W,
		["listY"] = v117 + 96,
		["listBottom"] = v55.moveTop - 8 * v46
	}
	local v151 = v117 + 150
	local v152 = v55.buttonsTop - 4
	local v153 = math.min(v151, v152)
	v150.shadeH = math.max(24, v153)
	v150.refH = v51
	v150.promptBottom = v51 - v55.bottomTop + 8 * v46
	v150.promptRight = v120
	v150.promptMaxW = v120 - v55.moveRight
	v150.promptX = v120 - 130 * v46
	v150.live = v57 ~= nil
	return v150
end
v_u_3.touchFrame = v_u_154
local v_u_155 = {
	"RaidModTag",
	"LevelPlate",
	"FreeRaidTag",
	"Quick",
	"EventBar",
	"Tasks"
}
local function v_u_161(p156) -- name: bandBlockH
	-- upvalues: (ref) v_u_12, (ref) v_u_6
	local v157 = v_u_12
	if v157 then
		v157 = v_u_12.root
	end
	local v158
	if v157 then
		v158 = v157:FindFirstChild(p156)
	else
		v158 = nil
	end
	if not v158 or (not v158:IsA("GuiObject") or (not v158.Visible or (v158.AbsoluteSize.Y <= 2 or v158:GetAttribute("TopRow") == true))) then
		return 0
	end
	local v159 = v158.AbsoluteSize.Y
	local v160 = v_u_6.uiScale
	return v159 / math.max(0.01, v160())
end
function v_u_3.bandOffset(p162) -- name: bandOffset
	-- upvalues: (ref) v_u_6, (copy) v_u_155, (copy) v_u_161
	if not v_u_6.isPhone() then
		return 0
	end
	local v163 = 0
	for _, v164 in v_u_155 do
		if v164 == p162 then
			break
		end
		local v165 = v_u_161(v164)
		if v165 <= 0 then
			continue
		end
		v163 = v163 + (v165 + 6)
	end
	return v163
end
function v_u_3.trayOverlaps(p_u_166, p_u_167) -- name: trayOverlaps
	-- upvalues: (copy) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_4
	if p_u_166.Name == "Weapon" then
		local v168 = v_u_8.Character
		if v168 ~= nil and v168:GetAttribute("RideRole") == "driver" then
			return true
		end
	end
	if not v_u_6.isPhone() or v_u_5.device() ~= "Touch" then
		return false
	end
	local function v187()
		-- upvalues: (ref) v_u_4, (copy) p_u_166, (copy) p_u_167
		local v169 = v_u_4 and v_u_4.controllers
		if v169 then
			v169 = v_u_4.controllers.Input
		end
		local v170
		if v169 and v169.touch then
			v170 = v169.touch()
		else
			v170 = nil
		end
		if not v170 or (v170.trayOpen ~= true or not v169.touchRects) then
			return false
		end
		local v171 = v169.touchRects().tray
		local v172 = v170.root
		if typeof(v171) ~= "Rect" or not (v172 and v172:IsA("GuiObject")) then
			return false
		end
		local v173 = v172.AbsolutePosition
		local v174 = p_u_166.AbsolutePosition
		local v175 = p_u_166.AbsoluteSize
		local v176 = v173.X + v171.Max.X
		local v177 = v174.X + v175.X
		local v178 = math.min(v176, v177)
		local v179 = v173.X + v171.Min.X
		local v180 = v174.X
		local v181
		if p_u_167 < v178 - math.max(v179, v180) then
			local v182 = v173.Y + v171.Max.Y
			local v183 = v174.Y + v175.Y
			local v184 = math.min(v182, v183)
			local v185 = v173.Y + v171.Min.Y
			local v186 = v174.Y
			v181 = p_u_167 < v184 - math.max(v185, v186)
		else
			v181 = false
		end
		return v181
	end
	local v188, v189 = pcall(v187)
	if v188 then
		v188 = v189 == true
	end
	return v188
end
function v_u_3.columnRect(p190, p191, p192, p193) -- name: columnRect
	local v194 = { p190 + 320 }
	for _, v195 in p193 do
		local v196 = v195[1] - 8
		if v196 - p190 < 150 then
			continue
		end
		local v197 = p190 + 320
		local v198 = math.min(v196, v197)
		table.insert(v194, v198)
	end
	local v199 = 0
	local v200 = nil
	for _, v201 in v194 do
		local v202 = p192
		local v203 = true
		for _, v204 in p193 do
			if v204[1] >= v201 or (p190 >= v204[3] or p191 >= v204[4]) then
				continue
			end
			if v204[2] < p191 + 60 then
				v203 = false
				break
			end
			local v205 = v204[2] - 6
			p192 = math.min(p192, v205)
		end
		if v203 and p192 - p191 >= 60 then
			local v206 = (v201 - p190) * (p192 - p191)
			if v199 + 1 < v206 then
				v199 = v206
				p192 = v202
				v200 = {
					["x1"] = v201,
					["y1"] = p192
				}
			else
				p192 = v202
			end
		else
			p192 = v202
		end
	end
	return v200
end
function v_u_3.centerColumn(p207) -- name: centerColumn
	-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_6, (copy) v_u_154, (ref) v_u_7, (copy) v_u_3, (copy) v_u_15
	if not v_u_12 or (v_u_5.device() ~= "Touch" or not v_u_6.isPhone()) then
		return nil
	end
	local v208 = v_u_154()
	local v209, v210, v211, v212
	if v_u_7 and v208.corner then
		local v213 = v_u_7.notice({
			["refW"] = v208.refW,
			["refH"] = v208.refH,
			["bandLeft"] = v208.bandLeft,
			["right"] = v208.right,
			["weaponScale"] = v208.weaponScale,
			["rowLeft"] = v208.rowLeft,
			["vitalsRight"] = v208.left + v208.vitalsW,
			["viewLeft"] = v208.viewLeft,
			["viewTop"] = v208.viewTop
		})
		v209 = v213.x0
		v210 = v213.top
		v211 = v213.y1
		local v214 = v213.x1
		local v215, v216 = v_u_7.fractions("Notices")
		if v215 and v216 then
			local v217 = v_u_7.K.NOTICE_MAX_W
			local v218 = v_u_7.K.NOTICE_MIN_W
			local v219 = v213.w
			local v220 = math.max(v218, v219)
			local v221 = math.min(v217, v220)
			local v222 = v215 * v208.refW
			local v223 = v208.refW - v221 - 4
			local v224 = math.max(0, v223)
			local v225 = math.min(v222, v224)
			v209 = math.floor(v225)
			local v226 = v216 * v208.refH
			local v227 = v208.refH - 2 * v_u_7.K.NOTICE_CARD_H - v_u_7.K.NOTICE_GAP - 4
			local v228 = math.max(0, v227)
			local v229 = math.min(v226, v228)
			v210 = math.floor(v229)
			v214 = v209 + v221
			local v230 = v208.refH - 4
			local v231 = v210 + 2 * v_u_7.K.NOTICE_CARD_H + v_u_7.K.NOTICE_GAP + 4
			v211 = math.min(v230, v231)
		end
		if v208.tray and (v210 < v208.tray[4] and (v208.tray[2] < v211 and not (v215 and v216))) then
			local v232 = v208.tray[3] + 8
			v209 = math.max(v209, v232)
		end
		local v233 = v_u_7.K.NOTICE_MAX_W
		local v234 = v214 - v209
		local v235 = math.min(v233, v234)
		v212 = math.floor(v235)
		if v212 < v_u_7.K.NOTICE_MIN_W then
			v212 = math.max(v212, 1)
			v211 = v210
		end
	else
		v209 = v208.bandLeft + 300 + 8 * v208.k
		v210 = v208.weaponY + 124 * v208.weaponScale + 6 * v208.k
		if v208.tray and v210 < v208.tray[4] then
			local v236 = v208.tray[3] + 8
			v209 = math.max(v209, v236)
		end
		v211 = v208.refH - v208.promptBottom - 60 - 6
		local v237 = v_u_3.columnRect(v209, v210, v211, v208.obstacles or {})
		local v238 = not v237 and 150 or v237.x1 - v209
		local v239 = math.min(v238, 320)
		v212 = math.floor(v239)
		if v237 then
			v211 = v237.y1
		end
	end
	if p207 ~= true then
		local v240 = v_u_15.HUDDowned
		if v240 then
			local v241 = v240.height
			if type(v241) == "function" then
				local v242 = v240.height
				local v243, v244 = pcall(v242)
				if v243 and (type(v244) == "number" and v244 > 0) then
					v210 = v210 + (v244 + 6)
				end
			end
		end
	end
	return {
		["top"] = v210,
		["x0"] = v209,
		["x1"] = v209 + v212,
		["w"] = v212,
		["cx"] = v209 + v212 / 2,
		["y1"] = v211,
		["compact"] = v208.corner ~= nil
	}
end
local function v_u_259(p245) -- name: columnLimit
	-- upvalues: (copy) v_u_8, (ref) v_u_5, (ref) v_u_6
	local v246 = p245.y1
	local v247 = v_u_8:FindFirstChildOfClass("PlayerGui")
	if not v247 then
		return v246
	end
	local v248 = v_u_5.safeInsets()
	local v249 = v_u_6.uiScale
	local v250 = math.max(0.01, v249())
	for _, v251 in {
		{ "HushPrompts", "Choices" },
		{ "HushHUDFx", "Action" }
	} do
		local v252 = v247:FindFirstChild(v251[1])
		local v253
		if v252 and (v252:IsA("ScreenGui") and v252.Enabled) then
			v253 = v252:FindFirstChild(v251[2], true)
		else
			v253 = nil
		end
		if not v253 or (not v253:IsA("GuiObject") or (not v253.Visible or (v253.AbsoluteSize.X < 3 or v253.AbsoluteSize.Y < 3))) then
			continue
		end
		local v254 = v_u_5.absToOverlay(v253.AbsolutePosition)
		local v255 = v254.X - v248.l
		local v256 = v254.Y - v248.t
		if v255 >= p245.x1 or (v255 + v253.AbsoluteSize.X / v250 <= p245.x0 or v256 >= v246 + 6) then
			continue
		end
		local v257 = p245.top
		local v258 = v256 - 6
		v246 = math.max(v257, v258)
	end
	return v246
end
function v_u_3.columnLimit() -- name: columnLimit
	-- upvalues: (copy) v_u_3, (copy) v_u_259
	local v260 = v_u_3.centerColumn()
	if v260 then
		return v_u_259(v260)
	else
		return nil
	end
end
local v_u_261 = nil
function v_u_3.columnState() -- name: columnState
	-- upvalues: (ref) v_u_261
	return v_u_261
end
local v_u_262 = nil
local v_u_263 = {}
local v_u_264 = 1
function v_u_3.noticeSpot() -- name: noticeSpot
	-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_6, (copy) v_u_154
	if not v_u_12 or (v_u_5.device() ~= "Touch" or v_u_6.isPhone()) then
		return nil
	end
	local v265 = v_u_154()
	local v266 = {}
	local v267 = v265.refW / 2
	local v268 = v265.bandLeft + 300 + 8 * v265.k + 160
	v266.cx = math.max(v267, v268)
	local v269 = v265.weaponY + 124 * v265.weaponScale + 6 * v265.k
	v266.top = math.floor(v269)
	return v266
end
local function v_u_335() -- name: placeToasts
	-- upvalues: (copy) v_u_3, (ref) v_u_261, (ref) v_u_262, (copy) v_u_15, (ref) v_u_5, (ref) v_u_6, (copy) v_u_259, (ref) v_u_7
	local v270 = v_u_3.centerColumn()
	if not v270 then
		v_u_261 = nil
		local v271 = v_u_262
		if v271 and v271.Parent then
			local v272 = 0
			local v273 = v_u_15.HUDEvents
			local v274
			if v273 then
				local v275 = v273.cardHeight
				if type(v275) == "function" then
					local v276 = v273.cardHeight
					local v277
					v277, v274 = pcall(v276)
					if v277 then
						if type(v274) ~= "number" then
							v274 = v272
						end
					else
						v274 = v272
					end
				else
					v274 = v272
				end
			else
				v274 = v272
			end
			local v278 = v_u_5.safeInsets()
			local v279 = v_u_3.noticeSpot()
			local v280
			if v279 then
				local v281 = UDim2.fromOffset
				local v282 = v279.cx + v278.l
				local v283 = math.floor(v282)
				local v284 = v279.top + v278.t + (v274 <= 0 and 0 or v274 + 8)
				v280 = v281(v283, (math.floor(v284)))
			else
				local v285 = (v_u_5.device() == "Touch" and 12 or v_u_5.topInset() + 8) + v278.t
				local v286 = UDim2.new
				local v287 = 0.5
				local v288 = 0
				local v289 = 0
				if v274 > 0 then
					local v290 = v285 + v274 + 8
					v285 = math.floor(v290)
				end
				v280 = v286(v287, v288, v289, v285)
			end
			if v271.Position ~= v280 then
				v271.Position = v280
			end
		end
		return
	end
	local v291 = v_u_5.safeInsets()
	local v292 = v_u_6.uiScale
	local v293 = math.max(0.01, v292())
	local v294 = v_u_259(v270)
	v_u_5.compactToastWidth = v270.w
	local v295 = v270.top
	local v296 = false
	local v297 = v_u_15.HUDEvents
	if v297 then
		local v298 = v297.cardHeight
		if type(v298) == "function" then
			local v299 = v297.cardHeight
			local v300, v301 = pcall(v299)
			if v300 and (type(v301) == "number" and v301 > 0) then
				v295 = v295 + (v301 + 6)
				v296 = true
			end
		end
	end
	local v302 = v_u_262
	local v303 = 0
	local v304 = 0
	if v302 and v302.Parent then
		local v305 = UDim2.fromOffset
		local v306 = v270.cx + v291.l
		local v307 = math.floor(v306)
		local v308 = v295 + v291.t
		local v309 = v305(v307, (math.floor(v308)))
		local v310 = UDim2.fromOffset
		local v311 = v270.w
		local v312 = v310(math.floor(v311), 400)
		if v302.Position ~= v309 then
			v302.Position = v309
		end
		if v302.Size ~= v312 then
			v302.Size = v312
		end
		local v313 = {}
		for _, v314 in v302:GetChildren() do
			if v314.Name ~= "Toast" or not v314:IsA("GuiObject") then
				continue
			end
			table.insert(v313, v314)
			local v315 = v314:FindFirstChild("ColumnLimit")
			if not v315 then
				v315 = Instance.new("UISizeConstraint")
				v315.Name = "ColumnLimit"
				v315.Parent = v314
				local v316 = v314:FindFirstChild("Body")
				local v317
				if v316 then
					v317 = v316:FindFirstChildOfClass("UIPadding")
				else
					v317 = nil
				end
				if v317 and v314:GetAttribute("Compact") ~= true then
					v317.PaddingLeft = UDim.new(0, 36)
				end
			end
			if v315 then
				local v318 = v315.MaxSize.X
				local v319 = v270.w
				if v318 ~= math.floor(v319) then
					local v320 = Vector2.new
					local v321 = v270.w
					v315.MaxSize = v320(math.floor(v321), (1 / 0))
				end
			end
			if v314.AbsoluteSize.Y <= 2 then
				continue
			end
			v314:SetAttribute("H", v314.AbsoluteSize.Y / v293)
		end
		table.sort(v313, function(p322, p323)
			return p322.LayoutOrder < p323.LayoutOrder
		end)
		local v324 = v294 - v295
		local v325 = {}
		local v326
		if v270.compact then
			v326 = v_u_7.K.NOTICE_MAX - (v296 and 1 or 0)
		else
			v326 = #v313
		end
		for v327 = #v313, 1, -1 do
			if v326 <= v304 then
				break
			end
			local v328 = (v313[v327]:GetAttribute("H") or 40) + (v303 > 0 and 8 or 0)
			if v303 + v328 > v324 + 1 then
				break
			end
			v303 = v303 + v328
			v304 = v304 + 1
			v325[v313[v327]] = true
		end
		for _, v329 in v313 do
			local v330 = v325[v329] == true
			if v329.Visible == v330 then
				continue
			end
			v329.Visible = v330
		end
	end
	local v331 = v295 + (v303 <= 0 and 0 or v303 + 6)
	local v332 = v294 - v331
	if v270.compact then
		local v333 = v_u_7.K.NOTICE_MAX - (v296 and 1 or 0) - v304
		local v334 = math.max(0, v333) * 34 - 6
		v332 = math.min(v332, v334)
	end
	v_u_261 = {
		["cx"] = v270.cx,
		["w"] = v270.w,
		["feedTop"] = v331,
		["feedRoom"] = v332
	}
end
local function v_u_347() -- name: hookToasts
	-- upvalues: (copy) v_u_8, (ref) v_u_262, (copy) v_u_263, (copy) v_u_335
	local v336 = v_u_8:FindFirstChildOfClass("PlayerGui")
	if v336 then
		v336 = v336:FindFirstChild("HushToast")
	end
	if v336 then
		v336 = v336:FindFirstChild("Root")
	end
	if v336 then
		v336 = v336:FindFirstChild("Toasts")
	end
	if v336 ~= v_u_262 then
		for _, v337 in v_u_263 do
			v337:Disconnect()
		end
		table.clear(v_u_263)
		if not (v336 and v336:IsA("Frame")) then
			v336 = nil
		end
		v_u_262 = v336
		if v_u_262 then
			local v338 = v_u_263
			local v339 = v_u_262:GetPropertyChangedSignal("Position")
			local v340 = v_u_335
			table.insert(v338, v339:Connect(v340))
			local v341 = v_u_263
			local v342 = v_u_262:GetPropertyChangedSignal("Size")
			local v343 = v_u_335
			table.insert(v341, v342:Connect(v343))
			local v344 = v_u_263
			local v345 = v_u_262.ChildAdded
			local v346 = v_u_335
			table.insert(v344, v345:Connect(v346))
			v_u_335()
		end
	end
end
local function v_u_352(p348, p349, p350) -- name: shade
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	local v351 = v_u_5.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["Name"] = p349,
		["BackgroundColor3"] = v_u_6.color.bgDeep,
		["AnchorPoint"] = Vector2.new(0, p350 and 0 or 1),
		["Position"] = UDim2.fromScale(0, p350 and 0 or 1),
		["Size"] = UDim2.new(1, 0, 0, 160)
	}, p348)
	v_u_5.new("UIGradient", {
		["Rotation"] = p350 and 90 or -90,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(0.45, 0.78), NumberSequenceKeypoint.new(1, 1) })
	}, v351)
	return v351
end
local function v_u_358(p353) -- name: layoutShades
	-- upvalues: (ref) v_u_12, (copy) v_u_154, (ref) v_u_5
	if v_u_12 and v_u_12.shadeTop then
		if p353 then
			local v354 = v_u_154()
			local v355 = v_u_12.shadeTop
			local v356 = UDim2.new
			local v357 = v354.shadeH
			v355.Size = v356(1, 0, 0, (math.floor(v357)))
			v_u_12.shadeBottom.Visible = false
		else
			v_u_12.shadeTop.Size = UDim2.new(1, 0, 0, v_u_5.topInset() + 96)
			v_u_12.shadeBottom.Visible = true
			v_u_12.shadeBottom.Size = UDim2.new(1, 0, 0, 220)
		end
	else
		return
	end
end
local function v_u_372(p359) -- name: layoutFreeTag
	-- upvalues: (ref) v_u_12, (copy) v_u_154, (ref) v_u_6, (copy) v_u_3, (ref) v_u_5
	local v360 = v_u_12
	if v360 then
		v360 = v_u_12.freeTag
	end
	if v360 then
		if p359 then
			local v361 = v_u_154()
			v360.AnchorPoint = Vector2.new(0, 0)
			if v_u_6.isPhone() then
				local v362 = UDim2.fromOffset
				local v363 = v361.bandLeft or v361.left
				local v364 = math.floor(v363)
				local v365 = v361.listY
				local v366
				if type(v365) == "number" then
					v366 = v361.listY
				else
					v366 = v361.top + 96
				end
				local v367 = v366 + v_u_3.bandOffset("FreeRaidTag")
				v360.Position = v362(v364, (math.floor(v367)))
			else
				local v368 = UDim2.fromOffset
				local v369 = v361.left + (v361.vitalsW or 180) + 8
				local v370 = math.floor(v369)
				local v371 = v361.top + 42
				v360.Position = v368(v370, (math.floor(v371)))
			end
		else
			v360.AnchorPoint = Vector2.new(1, 0)
			v360.Position = UDim2.new(1, -40, 0, v_u_5.topInset() + 54)
			v360.Visible = true
			return
		end
	else
		return
	end
end
local function v_u_377() -- name: syncFreeTag
	-- upvalues: (ref) v_u_12, (copy) v_u_8, (ref) v_u_6, (ref) v_u_5, (copy) v_u_372
	if v_u_12 and v_u_12.root then
		local v373 = v_u_8:GetAttribute("FreeRaid") == true
		if v373 and not v_u_12.freeTag then
			local v374 = v_u_6.color
			local v375 = v_u_5.new("Frame", {
				["Name"] = "FreeRaidTag",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v374.bg,
				["Size"] = UDim2.fromOffset(0, 22),
				["AutomaticSize"] = Enum.AutomaticSize.X
			}, v_u_12.root)
			v_u_5.stroke(v375, v374.accent, 1, 0.25)
			v_u_5.pad(v375, {
				8,
				8,
				0,
				0
			})
			local v376 = v_u_5.label({
				["parent"] = nil,
				["text"] = "Free raid  \194\183  random kit",
				["style"] = "caps",
				["textSize"] = 12,
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["parent"] = v375,
				["color"] = v374.accent,
				["size"] = UDim2.fromOffset(0, 22)
			})
			v376.Name = "Text"
			v376.TextYAlignment = Enum.TextYAlignment.Center
			v_u_12.freeTag = v375
			v_u_372(v_u_5.device() == "Touch")
		elseif not v373 and v_u_12.freeTag then
			v_u_12.freeTag:Destroy()
			v_u_12.freeTag = nil
		end
		v_u_8:SetAttribute("HudFreeRaidTag", v373)
	end
end
local function v_u_383() -- name: relayout
	-- upvalues: (ref) v_u_5, (ref) v_u_12, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (copy) v_u_358, (copy) v_u_372, (copy) v_u_15, (copy) v_u_25
	local v378 = v_u_5.device() == "Touch"
	local v379 = v_u_5
	local v380 = v_u_12 ~= nil and (v378 and v_u_6.isPhone())
	if v380 then
		if v_u_7 == nil or v_u_4 == nil then
			v380 = false
		else
			v380 = v_u_4.config.flag("PhoneHud") ~= false
		end
	end
	v379.compactToasts = v380
	v_u_358(v378)
	v_u_372(v378)
	for v381, v382 in v_u_15 do
		v_u_25(v381 .. ".layout", v382.layout, v378)
	end
end
local v_u_384 = {
	"Clock",
	"Extracts",
	"EventBar",
	"Tasks",
	"FreeRaidTag",
	"Vitals",
	"Weapon",
	"Squad",
	"Quick",
	"LevelPlate",
	"RaidModTag"
}
local v_u_385 = {}
local v_u_386 = nil
local v_u_387 = 1
local function v_u_470() -- name: computeEdgeRects
	-- upvalues: (ref) v_u_12, (ref) v_u_6, (ref) v_u_5, (copy) v_u_8, (copy) v_u_384, (copy) v_u_15, (ref) v_u_4
	local v_u_388 = {}
	if not (v_u_12 and (v_u_12.root and v_u_12.root.Parent)) then
		return v_u_388
	end
	local v_u_389 = v_u_6.isPhone()
	local v390 = v_u_12.root
	local v391 = v_u_6.uiScale
	local v_u_392 = math.max(0.01, v391())
	local v_u_393 = v390.AbsolutePosition
	local v_u_394 = v_u_5.absToOverlay(v_u_393)
	local v_u_395 = Vector2.zero
	local v396 = v_u_8:GetAttribute("DevViewport")
	if typeof(v396) == "Vector2" and (v396.X > 0 and v396.Y > 0) then
		v_u_395 = v396 / v_u_392 - v390.AbsoluteSize / v_u_392
	end
	local function v407(p397, p398) -- name: add
		-- upvalues: (copy) v_u_393, (copy) v_u_392, (ref) v_u_395, (copy) v_u_394, (copy) v_u_388, (copy) v_u_389
		if p397 and (p397:IsA("GuiObject") and p397.Visible) then
			local v399 = p398 or p397
			if v399.Visible then
				local v400 = p397.AbsoluteSize
				if v400.X >= 3 and v400.Y >= 3 then
					local v401 = (p397.AbsolutePosition - v_u_393) / v_u_392
					local v402 = Vector2.new(v_u_395.X * v399.Position.X.Scale, v_u_395.Y * v399.Position.Y.Scale)
					local v403 = v_u_394 + v401 + v402
					local v404 = v403 + v400 / v_u_392
					local v405 = v_u_388
					local v406 = {
						v403.X,
						v403.Y,
						v404.X,
						v404.Y,
						v_u_389 and 2 or nil
					}
					table.insert(v405, v406)
				end
			else
				return
			end
		else
			return
		end
	end
	for _, v408 in v_u_384 do
		local v409 = v390:FindFirstChild(v408)
		if not v409 then
			continue
		end
		v407(v409)
		if v408 ~= "Clock" or not v409:IsA("GuiObject") then
			continue
		end
		v407(v409:FindFirstChild("Extracts"), v409)
	end
	local v410 = v_u_8:FindFirstChildOfClass("PlayerGui")
	if v410 and v_u_389 then
		for _, v411 in {
			{ "HushPrompts", "Card" },
			{ "HushPrompts", "Choices" },
			{ "HushHUDFx", "Action" }
		} do
			local v412 = v410:FindFirstChild(v411[1])
			local v413
			if v412 and (v412:IsA("ScreenGui") and v412.Enabled) then
				v413 = v412:FindFirstChild(v411[2], true)
			else
				v413 = nil
			end
			if not v413 or (not v413:IsA("GuiObject") or (not v413.Visible or (v413.AbsoluteSize.X < 3 or v413.AbsoluteSize.Y < 3))) then
				continue
			end
			local v414 = v_u_5.absToOverlay(v413.AbsolutePosition)
			local v415 = v414 + v413.AbsoluteSize / v_u_392
			local v416
			if v411[2] == "Action" then
				v416 = v413:FindFirstChild("CancelChip")
			else
				v416 = nil
			end
			if v416 and (v416:IsA("GuiObject") and v416.Visible) then
				local v417 = v_u_5.absToOverlay(v416.AbsolutePosition)
				local v418 = v417 + v416.AbsoluteSize / v_u_392
				local v419 = Vector2.new
				local v420 = v414.X
				local v421 = v417.X
				local v422 = math.min(v420, v421)
				local v423 = v414.Y
				local v424 = v417.Y
				v414 = v419(v422, (math.min(v423, v424)))
				local v425 = Vector2.new
				local v426 = v415.X
				local v427 = v418.X
				local v428 = math.max(v426, v427)
				local v429 = v415.Y
				local v430 = v418.Y
				v415 = v425(v428, (math.max(v429, v430)))
			end
			local v431 = {
				v414.X,
				v414.Y,
				v415.X,
				v415.Y,
				v_u_389 and 2 or nil
			}
			table.insert(v_u_388, v431)
		end
	end
	if v410 and (v_u_5.device() == "Touch" and v_u_389) then
		local function v437(p432) -- name: addRect
			-- upvalues: (ref) v_u_5, (copy) v_u_392, (copy) v_u_388, (copy) v_u_389
			if p432:IsA("GuiObject") and (p432.Visible and (p432.AbsoluteSize.X >= 3 and p432.AbsoluteSize.Y >= 3)) then
				local v433 = v_u_5.absToOverlay(p432.AbsolutePosition)
				local v434 = v433 + p432.AbsoluteSize / v_u_392
				local v435 = v_u_388
				local v436 = {
					v433.X,
					v433.Y,
					v434.X,
					v434.Y,
					v_u_389 and 0.4 or nil
				}
				table.insert(v435, v436)
			end
		end
		local v438 = v410:FindFirstChild("HushEventCard")
		local v439
		if v438 then
			v439 = v438:FindFirstChild("Root")
		else
			v439 = nil
		end
		for _, v440 in not v439 and {} or v439:GetChildren() do
			if v440.Name ~= "EventCard" then
				continue
			end
			v437(v440)
		end
		local v441 = v410:FindFirstChild("HushToast")
		local v442
		if v441 then
			v442 = v441:FindFirstChild("Toasts", true)
		else
			v442 = nil
		end
		for _, v443 in not v442 and {} or v442:GetChildren() do
			if v443.Name ~= "Toast" then
				continue
			end
			v437(v443)
		end
		local v444 = v410:FindFirstChild("HushBadge")
		local v445
		if v444 then
			v445 = v444:FindFirstChild("Feed", true)
		else
			v445 = nil
		end
		for _, v446 in not v445 and {} or v445:GetChildren() do
			if v446.Name ~= "Line" then
				continue
			end
			v437(v446)
		end
		local v447 = v_u_15.HUDDowned
		if v447 then
			local v448 = v447.rect
			if type(v448) == "function" then
				local v449 = v447.rect
				local v450, v451, v452 = pcall(v449)
				if v450 and (typeof(v451) == "Vector2" and typeof(v452) == "Vector2") then
					local v453 = v_u_5.absToOverlay(v451)
					local v454 = v453 + v452 / v_u_392
					local v455 = {
						v453.X,
						v453.Y,
						v454.X,
						v454.Y,
						v_u_389 and 2 or nil
					}
					table.insert(v_u_388, v455)
				end
			end
		end
	end
	if v_u_5.device() == "Touch" then
		local v_u_456 = v_u_4 and v_u_4.controllers
		if v_u_456 then
			v_u_456 = v_u_4.controllers.Input
		end
		if v_u_456 then
			local v457 = v_u_456.touchRects
			if type(v457) == "function" then
				local v458 = v_u_456.touchRects
				local v459, v460 = pcall(v458)
				if v459 and type(v460) == "table" then
					local v_u_461 = Vector2.zero
					local function v463()
						-- upvalues: (copy) v_u_456, (ref) v_u_461
						local v462 = v_u_456.touch
						if v462 then
							v462 = v_u_456.touch()
						end
						if v462 then
							v462 = v462.root
						end
						if v462 and v462:IsA("GuiObject") then
							v_u_461 = v462.AbsolutePosition
						end
					end
					pcall(v463)
					local v464 = v_u_461
					for v465, v466 in v460 do
						if typeof(v466) ~= "Rect" or v465 == "moveZone" then
							continue
						end
						local v467 = v_u_5.absToOverlay(v464 + v466.Min)
						local v468 = v_u_5.absToOverlay(v464 + v466.Max)
						local v469 = {
							v467.X,
							v467.Y,
							v468.X,
							v468.Y,
							v_u_389 and 3 or nil
						}
						table.insert(v_u_388, v469)
					end
				end
			end
		end
	end
	return v_u_388
end
local function v_u_483() -- name: publishEdgeRects
	-- upvalues: (ref) v_u_4, (ref) v_u_12, (ref) v_u_11, (ref) v_u_18, (ref) v_u_385, (ref) v_u_386, (copy) v_u_470, (ref) v_u_6, (ref) v_u_5
	local function v471()
		-- upvalues: (ref) v_u_4
		return v_u_4.lib.SquadMarkersEdge
	end
	local v472, v473 = pcall(v471)
	if not v472 or type(v473) ~= "table" then
		v473 = nil
	end
	if v_u_12 and (v_u_11 and v_u_18) then
		v_u_385 = v_u_470()
		local v474 = v_u_6.refSize()
		local function v475()
			-- upvalues: (ref) v_u_4
			return v_u_4.lib.SquadMarkersEdge
		end
		local v476, v477 = pcall(v475)
		if not v476 or type(v477) ~= "table" then
			v477 = nil
		end
		local v478
		if v477 and v477.safeBox then
			v478 = v477.safeBox(v474, v_u_5.safeInsets(), v_u_5.topInset(), 40, nil, v_u_6.isPhone())
		else
			v478 = {
				46,
				v_u_5.topInset(),
				v474.X - 46,
				v474.Y - 40
			}
		end
		v_u_386 = v478
		if v473 and v473.setHudRects then
			local v479 = v473.setHudRects
			local v480 = v_u_385
			local v481 = v_u_386
			pcall(v479, v480, v481)
		end
	else
		v_u_385 = {}
		v_u_386 = nil
		if v473 and v473.setHudRects then
			local v482 = v473.setHudRects
			pcall(v482, nil, nil)
		end
	end
end
local function v_u_490(p484) -- name: unmount
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (copy) v_u_15, (copy) v_u_25, (copy) v_u_16, (copy) v_u_17, (ref) v_u_12, (ref) v_u_5, (copy) v_u_263, (ref) v_u_262, (copy) v_u_483, (ref) v_u_18, (copy) v_u_8
	v_u_10 = v_u_10 + 1
	v_u_11 = false
	for v485, v486 in v_u_15 do
		v_u_25(v485 .. ".destroy", v486.destroy)
	end
	table.clear(v_u_15)
	for _, v487 in v_u_16 do
		v487:Disconnect()
	end
	table.clear(v_u_16)
	for _, v488 in v_u_17 do
		pcall(v488)
	end
	table.clear(v_u_17)
	if v_u_12 then
		if v_u_12.gui then
			v_u_12.gui:Destroy()
		end
		if v_u_12.fxGui then
			v_u_12.fxGui:Destroy()
		end
	end
	v_u_12 = nil
	v_u_5.compactToasts = false
	for _, v489 in v_u_263 do
		v489:Disconnect()
	end
	table.clear(v_u_263)
	v_u_262 = nil
	v_u_483()
	if not p484 then
		v_u_18 = true
		v_u_8:SetAttribute("HudVisible", true)
	end
	v_u_8:SetAttribute("HudMounted", false)
end
local v_u_491 = {}
local function v_u_503(p492) -- name: useQuick
	-- upvalues: (ref) v_u_11, (ref) v_u_18, (copy) v_u_8, (copy) v_u_491, (copy) v_u_15, (copy) v_u_25, (ref) v_u_5, (ref) v_u_4
	if v_u_11 and v_u_18 then
		local v493 = v_u_8.Character
		if v493 and (v493:GetAttribute("Downed") == true or v493:GetAttribute("Dead") == true) then
			return
		else
			local v494 = os.clock()
			if v494 - (v_u_491[p492] or (-1 / 0)) < 0.3 then
				return
			else
				v_u_491[p492] = v494
				local v495 = v_u_15.HUDQuick
				local v496
				if v495 and v495.uidAt then
					local v497 = v495.uidAt
					local v498, v499 = pcall(v497, p492)
					v496 = (not v498 or type(v499) ~= "string") and "" or v499
				else
					v496 = ""
				end
				if v496 == "" then
					if v495 and v495.pressed then
						v_u_25("quick.pressed", v495.pressed, p492, false)
					end
					v_u_5.sound("error")
				else
					if v495 and v495.pressed then
						v_u_25("quick.pressed", v495.pressed, p492, true)
					end
					local v500 = v_u_4.net.fire
					local v501, v502 = pcall(v500, "inv.op", {
						["op"] = "usequick",
						["index"] = nil,
						["index"] = p492
					})
					if not v501 then
						warn("[HUD] usequick", v502)
					end
				end
			end
		end
	else
		return
	end
end
local function v_u_520(p504) -- name: introBanner
	-- upvalues: (copy) v_u_8, (ref) v_u_10, (ref) v_u_12, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (copy) v_u_15, (copy) v_u_154
	local v505 = os.clock() + 25
	if v_u_8:GetAttribute("LoadingVisible") == true and os.clock() < v505 then
		task.wait(0.2)
		if p504 == v_u_10 then
			continue
		end
		return
	else
		task.wait(0.8)
		if p504 == v_u_10 and v_u_12 then
			local v506 = v_u_6.color
			local v507 = v_u_12.raid
			local v508 = v507 and (v507:GetAttribute("Map") or "The raid") or "The raid"
			local v509 = {}
			if v_u_8:GetAttribute("FreeRaid") == true then
				table.insert(v509, "Free raid, random kit")
			end
			for _, v510 in { "Difficulty", "TimeOfDay", "Weather" } do
				local v511
				if v507 then
					v511 = v507:GetAttribute(v510)
				else
					v511 = v507
				end
				if type(v511) ~= "string" or v511 == "" then
					continue
				end
				table.insert(v509, v511)
			end
			local v512
			if v_u_7 == nil or v_u_4 == nil then
				v512 = false
			else
				v512 = v_u_4.config.flag("PhoneHud") ~= false
			end
			local v513 = v512 and v_u_6.isPhone() and (v_u_5.device() == "Touch" and v_u_15.HUDEvents)
			if v513 then
				local v514 = v513.announce
				if type(v514) == "function" then
					local v515 = v513.announce
					local v516 = {
						["text"] = nil,
						["sub"] = nil,
						["kind"] = "info",
						["icon"] = "info",
						["event"] = "intro",
						["dur"] = 4,
						["sting"] = "none",
						["text"] = tostring(v508),
						["sub"] = table.concat(v509, "   /   ")
					}
					if pcall(v515, v516) then
						return
					end
				end
			end
			local v517, v518
			if v_u_5.device() == "Touch" then
				v517 = v_u_154().left
				v518 = 0.5
			else
				v517 = 64
				v518 = 0.62
			end
			local v_u_519 = v_u_5.new("Frame", {
				["Name"] = "Intro",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, v517, v518, 0),
				["Size"] = UDim2.fromOffset(620, 120)
			}, v_u_12.root)
			v_u_5.new("Frame", {
				["Name"] = "Rule",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Position"] = nil,
				["BackgroundColor3"] = v506.accent,
				["Size"] = UDim2.fromOffset(2, 96),
				["Position"] = UDim2.fromOffset(0, 12)
			}, v_u_519)
			v_u_5.label({
				["parent"] = nil,
				["text"] = "Raid in progress",
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_519,
				["color"] = v506.accent,
				["position"] = UDim2.fromOffset(18, 10),
				["size"] = UDim2.new(1, -18, 0, 18)
			})
			v_u_5.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h1",
				["textSize"] = 48,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v_u_519,
				["text"] = tostring(v508),
				["position"] = UDim2.fromOffset(16, 28),
				["size"] = UDim2.new(1, -18, 0, 56)
			})
			v_u_5.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_519,
				["text"] = table.concat(v509, "   /   "),
				["color"] = v506.text2,
				["position"] = UDim2.fromOffset(18, 84),
				["size"] = UDim2.new(1, -18, 0, 24)
			})
			v_u_5.fade(v_u_519, 0, 1.2, {
				["from"] = 1,
				["style"] = nil,
				["style"] = Enum.EasingStyle.Quint
			})
			v_u_5.tween(v_u_519, {
				["Position"] = UDim2.new(0, v517 + 8, v518, 0)
			}, 1.2, Enum.EasingStyle.Quint)
			task.wait(5)
			if v_u_519.Parent then
				v_u_5.fade(v_u_519, 1, 1.5, {
					["style"] = Enum.EasingStyle.Quad,
					["onDone"] = function() -- name: onDone
						-- upvalues: (copy) v_u_519
						v_u_519:Destroy()
					end
				})
			end
		end
	end
end
local v_u_521 = false
local v_u_522 = {
	["HUDClock"] = true,
	["HUDSquad"] = true,
	["HUDTasks"] = true,
	["HUDQuick"] = true,
	["HUDRaidMod"] = true,
	["HUDLevel"] = true
}
local function v_u_584(p_u_523) -- name: mount
	-- upvalues: (copy) v_u_15, (copy) v_u_490, (ref) v_u_10, (ref) v_u_4, (copy) v_u_8, (ref) v_u_5, (ref) v_u_6, (ref) v_u_18, (ref) v_u_12, (ref) v_u_20, (copy) v_u_154, (copy) v_u_14, (copy) v_u_3, (ref) v_u_385, (ref) v_u_386, (copy) v_u_352, (copy) v_u_9, (copy) v_u_522, (copy) v_u_25, (copy) v_u_377, (copy) v_u_383, (copy) v_u_16, (copy) v_u_17, (copy) v_u_503, (ref) v_u_11, (copy) v_u_483, (ref) v_u_521, (copy) v_u_520
	local v_u_524 = 0
	if p_u_523 then
		local v525 = v_u_15.HUDClock
		if v525 then
			local v526 = v525.revealLeft
			if type(v526) == "function" then
				local v527 = v525.revealLeft
				local v528, v529 = pcall(v527)
				if v528 and (type(v529) == "number" and v529 > 0) then
					v_u_524 = os.clock() + v529
				end
			end
		end
	end
	v_u_490(p_u_523)
	v_u_10 = v_u_10 + 1
	local v_u_530 = v_u_10
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_530, (ref) v_u_10, (ref) v_u_8, (ref) v_u_5, (ref) v_u_6, (ref) v_u_18, (ref) v_u_12, (ref) v_u_20, (ref) v_u_154, (ref) v_u_14, (ref) v_u_3, (ref) v_u_15, (ref) v_u_385, (ref) v_u_386, (ref) v_u_352, (ref) v_u_9, (ref) v_u_522, (ref) v_u_25, (ref) v_u_377, (ref) v_u_383, (ref) v_u_16, (ref) v_u_17, (ref) v_u_503, (ref) v_u_11, (ref) v_u_483, (copy) p_u_523, (ref) v_u_524, (ref) v_u_521, (ref) v_u_520
		local v_u_531 = v_u_4.session.waitForRaid(60)
		if v_u_530 == v_u_10 and v_u_4.session.place(v_u_8) == "Raid" then
			local v532 = v_u_8.Character
			local v533 = os.clock() + 30
			if v532 and v532:FindFirstChild("HumanoidRootPart") or os.clock() >= v533 then
				local v534, v535 = v_u_5.screen("HushHUD", v_u_6.layer.hud, {
					["insets"] = "Device"
				})
				local v536, v537 = v_u_5.screen("HushHUDFx", v_u_6.layer.hud - 1, {
					["insets"] = "None"
				})
				v534.Enabled = v_u_18
				v536.Enabled = v_u_18
				local v_u_538 = nil
				local v_u_539 = nil
				local function v540()
					-- upvalues: (ref) v_u_538, (ref) v_u_4
					v_u_538 = v_u_4.shared.Weapons
				end
				pcall(v540)
				local function v541()
					-- upvalues: (ref) v_u_539, (ref) v_u_4
					v_u_539 = v_u_4.shared.Sounds
				end
				pcall(v541)
				v_u_12 = {
					["UI"] = nil,
					["Theme"] = nil,
					["cctx"] = nil,
					["gui"] = nil,
					["fxGui"] = nil,
					["root"] = nil,
					["fx"] = nil,
					["raid"] = nil,
					["char"] = nil,
					["weapons"] = nil,
					["sounds"] = nil,
					["inv"] = nil,
					["touchFrame"] = nil,
					["phoneHud"] = nil,
					["bandOffset"] = nil,
					["trayOverlaps"] = nil,
					["centerColumn"] = nil,
					["columnLimit"] = nil,
					["noticeSpot"] = nil,
					["toastsUnderCard"] = true,
					["mods"] = nil,
					["edgeAvoid"] = nil,
					["UI"] = v_u_5,
					["Theme"] = v_u_6,
					["cctx"] = v_u_4,
					["gui"] = v534,
					["fxGui"] = v536,
					["root"] = v535,
					["fx"] = v537,
					["raid"] = v_u_531,
					["char"] = v532,
					["weapons"] = v_u_538,
					["sounds"] = v_u_539,
					["inv"] = v_u_20,
					["touchFrame"] = v_u_154,
					["phoneHud"] = v_u_14,
					["bandOffset"] = v_u_3.bandOffset,
					["trayOverlaps"] = v_u_3.trayOverlaps,
					["centerColumn"] = v_u_3.centerColumn,
					["columnLimit"] = v_u_3.columnLimit,
					["noticeSpot"] = v_u_3.noticeSpot,
					["mods"] = v_u_15,
					["edgeAvoid"] = function() -- name: edgeAvoid
						-- upvalues: (ref) v_u_385, (ref) v_u_386
						return v_u_385, v_u_386
					end,
					["shadeTop"] = v_u_352(v535, "ShadeTop", true),
					["shadeBottom"] = v_u_352(v535, "ShadeBottom", false)
				}
				for _, v_u_542 in v_u_9 do
					local function v543()
						-- upvalues: (ref) v_u_4, (copy) v_u_542
						return v_u_4.lib[v_u_542]
					end
					local v544, v545 = pcall(v543)
					local v546
					if v_u_522[v_u_542] then
						local function v547()
							-- upvalues: (ref) v_u_4, (copy) v_u_531
							return v_u_4.shared.HuntRules.hudHidden(v_u_531)
						end
						local v548
						v546, v548 = pcall(v547)
						if v546 then
							v546 = v548 == true
						end
					else
						v546 = false
					end
					if v546 then
						continue
					end
					if v544 and (type(v545) == "table" and v545.new) then
						local v549 = v545.new
						local v550 = v_u_12
						local v551, v552 = pcall(v549, v550)
						if v551 and type(v552) == "table" then
							v_u_15[v_u_542] = v552
						else
							warn("[HUD] module failed:", v_u_542, v552)
							v_u_8:SetAttribute("ClientError", "HUD " .. v_u_542 .. ": " .. tostring(v552))
						end
					else
						warn("[HUD] module missing:", v_u_542, v545)
					end
				end
				if v_u_12 then
					v_u_12.char = v532
				end
				for v553, v554 in v_u_15 do
					v_u_25(v553 .. ".setCharacter", v554.setCharacter, v532)
				end
				v_u_377()
				v_u_383()
				local v555 = v_u_16
				local v556 = v_u_8:GetAttributeChangedSignal("FreeRaid")
				local function v557()
					-- upvalues: (ref) v_u_530, (ref) v_u_10, (ref) v_u_377
					if v_u_530 == v_u_10 then
						v_u_377()
					end
				end
				table.insert(v555, v556:Connect(v557))
				local v558 = v_u_16
				local v559 = v_u_8.CharacterAdded
				local function v563(p560)
					-- upvalues: (ref) v_u_530, (ref) v_u_10, (ref) v_u_12, (ref) v_u_15, (ref) v_u_25
					if v_u_530 == v_u_10 then
						task.wait()
						if v_u_12 then
							v_u_12.char = p560
						end
						for v561, v562 in v_u_15 do
							v_u_25(v561 .. ".setCharacter", v562.setCharacter, p560)
						end
					end
				end
				table.insert(v558, v559:Connect(v563))
				local v564 = v_u_16
				local v565 = v_u_8.CharacterRemoving
				local function v568()
					-- upvalues: (ref) v_u_530, (ref) v_u_10, (ref) v_u_12, (ref) v_u_15, (ref) v_u_25
					if v_u_530 == v_u_10 then
						if v_u_12 then
							v_u_12.char = nil
						end
						for v566, v567 in v_u_15 do
							v_u_25(v566 .. ".setCharacter", v567.setCharacter, nil)
						end
					end
				end
				table.insert(v564, v565:Connect(v568))
				local v569 = v_u_4.controllers.Input
				if v569 and v569.bind then
					local v570 = v569.bind
					local function v571()
						-- upvalues: (ref) v_u_3
						v_u_3.revealExtracts()
					end
					local v572, v573 = pcall(v570, "extracts", v571)
					if v572 and type(v573) == "function" then
						local v574 = v_u_17
						table.insert(v574, v573)
					end
					for v_u_575 = 1, 4 do
						local v576 = v569.bind
						local v577 = "quick" .. v_u_575
						local function v578()
							-- upvalues: (ref) v_u_503, (copy) v_u_575
							v_u_503(v_u_575)
						end
						local v579, v580 = pcall(v576, v577, v578)
						if not v579 or type(v580) ~= "function" then
							continue
						end
						local v581 = v_u_17
						table.insert(v581, v580)
					end
				end
				v_u_11 = true
				v_u_8:SetAttribute("HudMounted", true)
				v_u_483()
				if p_u_523 then
					local v582 = v_u_8.Character
					if not v582 or v582:GetAttribute("Dead") ~= true and v582:GetAttribute("Downed") ~= true then
						local v583 = v_u_524 - os.clock()
						if v_u_521 then
							v_u_521 = false
							v_u_3.revealExtracts((math.max(7, v583)))
						elseif v583 > 0.3 then
							v_u_3.revealExtracts(v583)
						end
					end
				else
					v_u_521 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_520, (ref) v_u_530, (ref) v_u_10, (ref) v_u_521, (ref) v_u_3
						v_u_520(v_u_530)
						task.wait(1)
						if v_u_530 == v_u_10 and v_u_521 then
							v_u_521 = false
							v_u_3.revealExtracts(7)
						end
					end)
				end
			else
				task.wait(0.1)
				v532 = v_u_8.Character
				if v_u_530 == v_u_10 then
					continue
				end
				return
			end
		else
			return
		end
	end)
end
function v_u_3.isMounted() -- name: isMounted
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_3.setVisible(p585) -- name: setVisible
	-- upvalues: (ref) v_u_18, (ref) v_u_12, (copy) v_u_8
	local v586 = p585 ~= false
	if v586 ~= v_u_18 or v_u_12 and v_u_12.gui.Enabled ~= v586 then
		v_u_18 = v586
		v_u_8:SetAttribute("HudVisible", v586)
		if v_u_12 then
			if v_u_12.gui then
				v_u_12.gui.Enabled = v586
			end
			if v_u_12.fxGui then
				v_u_12.fxGui.Enabled = v586
			end
		end
	end
end
function v_u_3.isVisible() -- name: isVisible
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v_u_3.revealExtracts(p587) -- name: revealExtracts
	-- upvalues: (copy) v_u_15, (copy) v_u_25
	local v588 = v_u_15.HUDClock
	if v588 and v588.reveal then
		v_u_25("reveal", v588.reveal, p587)
	end
end
function v_u_3.notify(p589, p590, p591) -- name: notify
	-- upvalues: (ref) v_u_5
	v_u_5.toast(p589, p590, p591)
end
local function v_u_609(p592) -- name: routeNotify
	-- upvalues: (ref) v_u_4, (copy) v_u_15, (ref) v_u_5
	if type(p592) == "table" and p592.kind == "radio" then
		local function v593()
			-- upvalues: (ref) v_u_4
			return v_u_4.lib.RadioLine
		end
		local v594, v595 = pcall(v593)
		if v594 and type(v595) == "table" then
			local v596 = v595.init
			local v597 = v_u_4
			pcall(v596, v597)
			local v598 = v595.showPayload
			local v599, v600, v601 = pcall(v598, p592)
			if v599 and (v600 == true or v601 == "dup") then
				return
			end
		end
	end
	if type(p592) == "table" and p592.text then
		if p592.event == nil then
			local v602 = v_u_5.toast
			local v603 = p592.text
			v602(tostring(v603), p592.kind == "radio" and "info" or p592.kind, p592.sub)
		else
			local v604 = v_u_15.HUDEvents
			if v604 and v604.announce then
				local v605 = v604.announce
				if pcall(v605, p592) then
					return
				end
			end
			local v606 = p592.kind == "danger" and "warn" or p592.kind
			local v607 = v_u_5.toast
			local v608 = p592.text
			v607(tostring(v608), v606, p592.sub)
		end
	else
		if type(p592) == "string" then
			v_u_5.toast(p592, "info")
		end
		return
	end
end
function v_u_3.init(p_u_610) -- name: init
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_12, (copy) v_u_383, (ref) v_u_11, (copy) v_u_584, (ref) v_u_18, (copy) v_u_15, (copy) v_u_3, (copy) v_u_154, (ref) v_u_261, (copy) v_u_609
	v_u_4 = p_u_610
	v_u_5 = p_u_610.lib.HushUI
	v_u_5.bind(p_u_610)
	v_u_6 = p_u_610.shared.Theme
	local v611, v612 = pcall(function()
		-- upvalues: (copy) p_u_610
		return p_u_610.lib.HudLayout
	end)
	if not v611 or type(v612) ~= "table" then
		v612 = nil
	end
	v_u_7 = v612
	local function v615()
		-- upvalues: (copy) p_u_610, (ref) v_u_7, (ref) v_u_12, (ref) v_u_5, (ref) v_u_383
		local v613 = p_u_610.lib.HudLayoutStore
		if v_u_7 and v613 then
			v613.attach(v_u_7)
			v613.watch(p_u_610.config)
			local v_u_614 = false
			v_u_7.onChanged(function()
				-- upvalues: (ref) v_u_614, (ref) v_u_12, (ref) v_u_5, (ref) v_u_383
				if not v_u_614 then
					v_u_614 = true
					task.defer(function()
						-- upvalues: (ref) v_u_614, (ref) v_u_12, (ref) v_u_5, (ref) v_u_383
						v_u_614 = false
						if v_u_12 and v_u_5.device() == "Touch" then
							v_u_383()
						end
					end)
				end
			end)
		end
	end
	pcall(v615)
	local function v623()
		-- upvalues: (copy) p_u_610, (ref) v_u_12, (ref) v_u_11, (ref) v_u_4, (ref) v_u_584
		local v_u_616 = nil
		p_u_610.config.watchFlag("PhoneHud", function(p617)
			-- upvalues: (ref) v_u_616, (ref) v_u_12, (ref) v_u_11, (ref) v_u_4, (ref) v_u_584
			local v618 = p617 ~= false
			if v_u_616 ~= nil and (v_u_616 ~= v618 and (v_u_12 and v_u_11)) then
				local v619 = v_u_4 and v_u_4.controllers
				if v619 then
					v619 = v_u_4.controllers.Input
				end
				local v620
				if v619 and v619.touch then
					v620 = v619.touch()
				else
					v620 = nil
				end
				if v620 then
					local v621 = v620.relayout
					if type(v621) == "function" then
						local v622 = v620.relayout
						pcall(v622, v620)
					end
				end
				v_u_584(true)
			end
			v_u_616 = v618
		end)
	end
	pcall(v623)
	p_u_610.command("hud.state", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_18, (ref) v_u_15
		local v624 = {}
		local v625 = v_u_11
		local v626 = v_u_18
		__set_list(v624, 1, {"mounted=" .. tostring(v625), "visible=" .. tostring(v626)})
		for v627 in v_u_15 do
			table.insert(v624, v627)
		end
		return table.concat(v624, " ")
	end)
	p_u_610.command("hud.notify", function(p628)
		-- upvalues: (ref) v_u_3
		v_u_3.notify(table.concat(p628, " "), "warn", "Test notification")
		return "ok"
	end)
	p_u_610.command("hud.hit", function(p629)
		-- upvalues: (ref) v_u_15
		local v630 = v_u_15.HUDEffects
		if v630 then
			v630.onHit({
				["kind"] = p629[1] or "zombie"
			})
		end
		return "ok"
	end)
	p_u_610.command("hud.extracts", function()
		-- upvalues: (ref) v_u_3
		v_u_3.revealExtracts()
		return "ok"
	end)
	p_u_610.command("hud.column", function()
		-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_154, (ref) v_u_3, (ref) v_u_261
		if not v_u_12 or v_u_5.device() ~= "Touch" then
			return "no touch HUD"
		end
		local v631 = v_u_154()
		local v632 = v_u_3.centerColumn()
		local v633 = {}
		for _, v634 in v631.obstacles or {} do
			local v635 = string.format
			local v636 = v634[1]
			local v637 = v634[2]
			local v638 = v634[3]
			local v639 = v634[4]
			table.insert(v633, v635("%d,%d,%d,%d", v636, v637, v638, v639))
		end
		local v640 = v_u_261
		local v641 = string.format
		local v642 = v631.live
		return v641("live=%s k=%.3f left=%.0f bandLeft=%.0f top=%.0f listY=%.0f listBottom=%.0f weaponY=%.0f weaponScale=%.2f refH=%.0f promptBottom=%.0f promptRight=%.0f promptMaxW=%.0f | column %s | feed %s | obstacles %s", tostring(v642), v631.k, v631.left, v631.bandLeft or -1, v631.top, v631.listY, v631.listBottom, v631.weaponY, v631.weaponScale, v631.refH, v631.promptBottom, v631.promptRight, v631.promptMaxW, not v632 and "nil" or string.format("x0=%.0f x1=%.0f w=%.0f cx=%.0f top=%.0f y1=%.0f", v632.x0, v632.x1, v632.w, v632.cx, v632.top, v632.y1), not v640 and "nil" or string.format("top=%.0f room=%.0f", v640.feedTop, v640.feedRoom), table.concat(v633, " ; "))
	end)
	p_u_610.command("hud.fake", function(p643)
		-- upvalues: (ref) v_u_15
		local v644 = v_u_15.HUDSquad
		if p643[1] == "squad" and v644 then
			local v645 = v644.fake
			if type(v645) == "function" then
				local v646 = v644.fake
				local v647 = p643[2]
				v646(tonumber(v647) or 0)
				return "ok"
			end
		end
		return "usage: hud.fake squad <n>"
	end)
	p_u_610.command("events.state", function()
		-- upvalues: (ref) v_u_15
		local v648 = v_u_15.HUDEvents
		return not (v648 and v648.state) and "HUDEvents not mounted" or v648.state()
	end)
	p_u_610.command("events.summary", function()
		-- upvalues: (ref) v_u_15
		local v649 = v_u_15.HUDEvents
		if not (v649 and v649.summary) then
			return "HUDEvents not mounted"
		end
		local v650 = v649.summary
		return "summary=" .. tostring(v650())
	end)
	p_u_610.command("events.card", function(p651)
		-- upvalues: (ref) v_u_609
		local v652 = p651[1] or "airdrop"
		local v653 = workspace.CurrentCamera
		local v654 = not v653 and Vector3.new(0, 0, 0) or v653.Focus.Position + Vector3.new(120, 0, -80)
		local v655 = ({
			["airdrop"] = {
				["text"] = "Supply drop inbound",
				["sub"] = "A crate on a parachute. Red smoke will mark it.",
				["kind"] = "warn",
				["icon"] = "parachute",
				["pos"] = nil,
				["pos"] = v654
			},
			["heli"] = {
				["text"] = "Helicopter over Stillwater",
				["sub"] = "Rotor noise drags the dead along its path",
				["kind"] = "warn",
				["icon"] = "heli",
				["pos"] = nil,
				["pos"] = v654
			},
			["horde"] = {
				["text"] = "The school horde is awake",
				["sub"] = "Hundreds of feet. Stay off Main Street.",
				["kind"] = "danger",
				["icon"] = "horde",
				["pos"] = nil,
				["pos"] = v654
			},
			["siren"] = {
				["text"] = "Evacuation siren",
				["sub"] = "05:00 until the town is sealed. Get to an extract.",
				["kind"] = "danger",
				["icon"] = "siren",
				["sting"] = "none"
			},
			["flare"] = {
				["text"] = "Flare lit at the helipad",
				["sub"] = "Evac helicopter in 01:00. Every corpse in town heard that.",
				["kind"] = "warn",
				["icon"] = "flare",
				["pos"] = nil,
				["pos"] = v654
			},
			["pickup"] = {
				["text"] = "An engine roars at the gas station",
				["sub"] = "The pickup leaves in 00:45, room for 4",
				["kind"] = "warn",
				["icon"] = "truck",
				["pos"] = nil,
				["pos"] = v654
			}
		})[v652]
		if not v655 then
			return "unknown card " .. v652
		end
		v655.event = "test_" .. v652
		v_u_609(v655)
		return "ok " .. v652
	end)
	p_u_610.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_584, (ref) v_u_383
		if v_u_11 or v_u_12 then
			v_u_584(true)
		else
			v_u_383()
		end
	end)
	local v_u_656 = false
	local v657 = p_u_610.on
	local function v658()
		-- upvalues: (ref) v_u_656, (ref) v_u_12, (ref) v_u_5, (ref) v_u_383
		if not v_u_656 then
			v_u_656 = true
			task.defer(function()
				-- upvalues: (ref) v_u_656, (ref) v_u_12, (ref) v_u_5, (ref) v_u_383
				v_u_656 = false
				if v_u_12 and v_u_5.device() == "Touch" then
					v_u_383()
				end
			end)
		end
	end
	pcall(v657, "touch.layout", v658)
end
function v_u_3.start() -- name: start
	-- upvalues: (ref) v_u_4, (copy) v_u_609, (ref) v_u_20, (ref) v_u_12, (copy) v_u_15, (copy) v_u_25, (ref) v_u_19, (ref) v_u_5, (copy) v_u_383, (ref) v_u_11, (copy) v_u_584, (copy) v_u_490
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_609
		v_u_4.net.listen("raid.notify", v_u_609)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_20, (ref) v_u_12, (ref) v_u_15, (ref) v_u_25
		v_u_4.net.listen("inv.state", function(p659)
			-- upvalues: (ref) v_u_20, (ref) v_u_12, (ref) v_u_15, (ref) v_u_25
			v_u_20 = p659
			if v_u_12 then
				v_u_12.inv = p659
			end
			local v660 = v_u_15.HUDQuick
			if v660 and v660.onInv then
				v_u_25("onInv", v660.onInv, p659)
			end
		end)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_15, (ref) v_u_25
		v_u_4.net.listen("combat.hit", function(p661)
			-- upvalues: (ref) v_u_15, (ref) v_u_25
			local v662 = v_u_15.HUDEffects
			if v662 and v662.onHit then
				v_u_25("onHit", v662.onHit, p661)
			end
		end)
	end)
	v_u_19 = v_u_5.device()
	v_u_5.onDevice(function(p663)
		-- upvalues: (ref) v_u_19, (ref) v_u_383
		if p663 ~= v_u_19 then
			v_u_19 = p663
			v_u_383()
		end
	end)
	v_u_4.session.onPlaceChanged(function(p664)
		-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_584, (ref) v_u_490
		if p664 == "Raid" then
			if not (v_u_11 or v_u_12) then
				v_u_584()
				return
			end
		else
			v_u_490()
		end
	end)
end
function v_u_3.step(p665) -- name: step
	-- upvalues: (ref) v_u_11, (ref) v_u_387, (copy) v_u_483, (ref) v_u_264, (ref) v_u_12, (ref) v_u_5, (ref) v_u_6, (copy) v_u_347, (copy) v_u_335, (copy) v_u_372, (copy) v_u_15, (copy) v_u_8
	if v_u_11 then
		v_u_387 = v_u_387 + p665
		if v_u_387 >= 0.2 then
			v_u_387 = 0
			v_u_483()
		end
		v_u_264 = v_u_264 + p665
		if v_u_264 >= 0.25 then
			v_u_264 = 0
			if v_u_12 and (v_u_5.device() == "Touch" and v_u_6.isPhone()) then
				v_u_347()
				v_u_335()
			elseif v_u_12 then
				v_u_347()
				v_u_335()
			end
			if v_u_12 and v_u_12.freeTag and (v_u_5.device() == "Touch" and v_u_6.isPhone()) then
				v_u_372(true)
			end
		end
		if v_u_12 and v_u_12.freeTag and (v_u_5.device() == "Touch" and v_u_6.isPhone()) then
			local v666 = v_u_15.HUDClock
			local v667
			if v666 == nil then
				v667 = nil
			else
				v667 = v666.bandBusy or v666.isShown
			end
			local v668
			if type(v667) == "function" then
				v668 = v667() == true
			else
				v668 = false
			end
			local v669 = not v668
			if v_u_12.freeTag.Visible ~= v669 then
				v_u_12.freeTag.Visible = v669
			end
		end
		for v670, v671 in v_u_15 do
			if not v671.update then
				continue
			end
			local v672 = v671.update
			local v673, v674 = pcall(v672, p665)
			if v673 then
				continue
			end
			v671._err = (v671._err or 0) + 1
			if v671._err >= 4 then
				continue
			end
			warn("[HUD] update", v670, v674)
			v_u_8:SetAttribute("ClientError", "HUD update " .. v670 .. ": " .. tostring(v674))
		end
	end
end
return v_u_3