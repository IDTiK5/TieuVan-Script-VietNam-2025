-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIPouch

local v1 = {}
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("GuiService")
local v5, v_u_6 = pcall(function()
	local v4 = script.Parent
	return require((v4:WaitForChild("InvUIPouchRule", 3)))
end)
if not v5 or type(v_u_6) ~= "table" then
	v_u_6 = nil
end
local v8, v_u_9 = pcall(function()
	local v7 = script.Parent
	return require((v7:WaitForChild("InvUIWhy", 3)))
end)
if not v8 or type(v_u_9) ~= "table" then
	v_u_9 = nil
end
local v_u_10 = Color3.fromRGB(0, 0, 0)
local v_u_11 = Color3.fromRGB(64, 58, 44)
local v_u_12 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_13 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_14 = {
	"api",
	"drag",
	"pad",
	"tap",
	"hover"
}
local function v_u_35(p15, p16, p17, p18, p19, p20) -- name: apply
	local v21 = p17 + p19
	local v22 = p17 * p15.cr + 0.5
	local v23 = math.floor(v22) - p15.lo + p15.g
	local v24 = v21 * p15.cr + 0.5
	local v25 = math.floor(v24) - p15.lo
	local v26 = p18 + p20
	local v27 = p18 * p15.cr + 0.5
	local v28 = math.floor(v27) - p15.lo + p15.g
	local v29 = v26 * p15.cr + 0.5
	local v30 = math.floor(v29) - p15.lo
	p16.Position = UDim2.fromScale((v23 + 1) / p15.wf, (v28 + 1) / p15.hf)
	local v31 = UDim2.fromScale
	local v32 = v25 - v23 - 2
	local v33 = math.max(v32, 1) / p15.wf
	local v34 = v30 - v28 - 2
	p16.Size = v31(v33, math.max(v34, 1) / p15.hf)
end
function v1.place(p36, p37, p38, p39, p40, p41) -- name: place
	-- upvalues: (copy) v_u_12, (copy) v_u_35
	local v42 = v_u_12[p36]
	if v42 then
		p37:SetAttribute("PxRect", Rect.new(p38, p39, p38 + p40, p39 + p41))
		v_u_35(v42, p37, p38, p39, p40, p41)
	else
		local v43 = tonumber(p36:GetAttribute("PxCell")) or 48
		p37.Position = UDim2.fromOffset(p38 * v43 + 1, p39 * v43 + 1)
		p37.Size = UDim2.fromOffset(p40 * v43 - 2, p41 * v43 - 2)
	end
end
local function v_u_114(p44, p45, p46, p47) -- name: buildRig
	-- upvalues: (ref) v_u_6, (copy) v_u_10
	local v48 = p47.theme.color
	local v49 = p47.new
	local v50 = p45.slots
	local v51 = p46.g
	local v52
	if p47.theme.isPhone then
		local v53 = p47.theme.isPhone
		local v54
		v52, v54 = pcall(v53)
		if v52 then
			v52 = v54 == true
		end
	else
		v52 = false
	end
	local v55 = v_u_6.variant(v50)
	for v56, v57 in v50 do
		local v58 = v57.x
		local v59 = v57.x + v57.w
		local v60 = v58 * p46.cr + 0.5
		local v61 = math.floor(v60) - p46.lo + p46.g
		local v62 = v59 * p46.cr + 0.5
		local v63 = math.floor(v62) - p46.lo
		local v64 = v57.y
		local v65 = v57.y + v57.h
		local v66 = v64 * p46.cr + 0.5
		local v67 = math.floor(v66) - p46.lo + p46.g
		local v68 = v65 * p46.cr + 0.5
		local v69 = math.floor(v68) - p46.lo
		local v70 = v63 - v61
		local v71 = v69 - v67
		if v70 < 2 or v71 < 2 then
			continue
		end
		local v72 = v_u_6.class(v57.w, v57.h)
		local v73 = v_u_6.color(v72, v55[v56])
		local v74 = v49("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["Name"] = "Pouch" .. v56,
			["BackgroundColor3"] = v48.lineStrong,
			["BackgroundTransparency"] = v52 and 0.2 or 0.35,
			["Position"] = UDim2.fromOffset(v61, v67),
			["Size"] = UDim2.fromOffset(v70, v71)
		}, p44)
		v74:SetAttribute("PouchClass", v72)
		v74:SetAttribute("PouchVariant", v55[v56])
		v49("Frame", {
			["Name"] = "Field",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["BackgroundColor3"] = Color3.fromRGB(v73[1], v73[2], v73[3]),
			["Position"] = UDim2.fromOffset(1, 1),
			["Size"] = UDim2.fromOffset(v70 - 2, v71 - 2)
		}, v74)
	end
	for _, v75 in v_u_6.separators(v50) do
		local v76 = v75.k * p46.cr + 0.5
		local v77 = math.floor(v76) - p46.lo
		if v75.axis == "v" then
			local v78 = v75.a
			local v79 = v75.b
			local v80 = v78 * p46.cr + 0.5
			local v81 = math.floor(v80) - p46.lo + p46.g
			local v82 = v79 * p46.cr + 0.5
			local v83 = math.floor(v82) - p46.lo
			v49("Frame", {
				["Name"] = "SepV",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["BackgroundColor3"] = v_u_10,
				["Position"] = UDim2.fromOffset(v77, v81),
				["Size"] = UDim2.fromOffset(v51, v83 - v81)
			}, p44)
		else
			local v84 = v75.a
			local v85 = v75.b
			local v86 = v84 * p46.cr + 0.5
			local v87 = math.floor(v86) - p46.lo + p46.g
			local v88 = v85 * p46.cr + 0.5
			local v89 = math.floor(v88) - p46.lo
			v49("Frame", {
				["Name"] = "SepH",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["BackgroundColor3"] = v_u_10,
				["Position"] = UDim2.fromOffset(v87, v77),
				["Size"] = UDim2.fromOffset(v89 - v87, v51)
			}, p44)
		end
	end
	local v90 = v48.text2
	local v91 = p46.cr
	for _, v92 in v_u_6.ticks(v50, v91).list do
		local v93 = v50[v92.pouch]
		local v94 = v93.x
		local v95 = v93.x + v93.w
		local v96 = v94 * p46.cr + 0.5
		local v97 = math.floor(v96) - p46.lo + p46.g
		local v98 = v95 * p46.cr + 0.5
		local v99 = math.floor(v98) - p46.lo
		local v100 = v93.y
		local v101 = v93.y + v93.h
		local v102 = v100 * p46.cr + 0.5
		local v103 = math.floor(v102) - p46.lo + p46.g
		local v104 = v101 * p46.cr + 0.5
		local v105 = math.floor(v104) - p46.lo
		local v106 = v92.k * p46.cr + 0.5
		local v107 = math.floor(v106) - p46.lo
		local v108 = (v51 - 1) / 2
		local v109 = v107 + math.floor(v108)
		if v92.axis == "v" then
			local v110 = v_u_6.tickLen(v91, v105 - v103)
			local v111
			if v92.side == 1 then
				v111 = v103 + 1
			else
				v111 = v105 - 1 - v110
			end
			v49("Frame", {
				["Name"] = "Tick",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.65,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["BackgroundColor3"] = v90,
				["Position"] = UDim2.fromOffset(v109, v111),
				["Size"] = UDim2.fromOffset(1, v110)
			}, p44)
		else
			local v112 = v_u_6.tickLen(v91, v99 - v97)
			local v113
			if v92.side == 1 then
				v113 = v97 + 1
			else
				v113 = v99 - 1 - v112
			end
			v49("Frame", {
				["Name"] = "Tick",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.65,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["BackgroundColor3"] = v90,
				["Position"] = UDim2.fromOffset(v113, v109),
				["Size"] = UDim2.fromOffset(v112, 1)
			}, p44)
		end
	end
end
local function v_u_150(p115, p116, p117, p118) -- name: build
	-- upvalues: (ref) v_u_6, (copy) v_u_114, (copy) v_u_11, (copy) v_u_10
	local v119 = p118.theme.color
	local v120 = p118.new
	local v121 = p116.slots
	local v122 = p117.g
	if v121 and v_u_6 then
		v_u_114(p115, p116, p117, p118)
	else
		local v123 = v121 or {
			{
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p116.w,
				["h"] = p116.h
			}
		}
		local v124
		if v121 then
			v124 = v119.raised:Lerp(v_u_11, 0.3)
		else
			v124 = v119.raised
		end
		for v125, v126 in v123 do
			local v127 = v126.x
			local v128 = v126.x + v126.w
			local v129 = v127 * p117.cr + 0.5
			local v130 = math.floor(v129) - p117.lo + p117.g
			local v131 = v128 * p117.cr + 0.5
			local v132 = math.floor(v131) - p117.lo
			local v133 = v126.y
			local v134 = v126.y + v126.h
			local v135 = v133 * p117.cr + 0.5
			local v136 = math.floor(v135) - p117.lo + p117.g
			local v137 = v134 * p117.cr + 0.5
			local v138 = math.floor(v137) - p117.lo
			local v139 = v132 - v130
			local v140 = v138 - v136
			if v139 < 2 or v140 < 2 then
				continue
			end
			if v121 then
				local v141 = v120("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.35,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["Name"] = "Pouch" .. v125,
					["BackgroundColor3"] = v119.lineStrong,
					["Position"] = UDim2.fromOffset(v130, v136),
					["Size"] = UDim2.fromOffset(v139, v140)
				}, p115)
				v120("Frame", {
					["Name"] = "Field",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.05,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v124,
					["Position"] = UDim2.fromOffset(1, 1),
					["Size"] = UDim2.fromOffset(v139 - 2, v140 - 2)
				}, v141)
			else
				v120("Frame", {
					["Name"] = "Bed",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v124,
					["Position"] = UDim2.fromOffset(v130, v136),
					["Size"] = UDim2.fromOffset(v139, v140)
				}, p115)
			end
			for v142 = v126.x + 1, v126.x + v126.w - 1 do
				local v143 = {
					["Name"] = "VLine",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v_u_10
				}
				local v144 = UDim2.fromOffset
				local v145 = v142 * p117.cr + 0.5
				v143.Position = v144(math.floor(v145) - p117.lo, v136)
				v143.Size = UDim2.fromOffset(v122, v140)
				v120("Frame", v143, p115)
			end
			for v146 = v126.y + 1, v126.y + v126.h - 1 do
				local v147 = {
					["Name"] = "HLine",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v_u_10
				}
				local v148 = UDim2.fromOffset
				local v149 = v146 * p117.cr + 0.5
				v147.Position = v148(v130, math.floor(v149) - p117.lo)
				v147.Size = UDim2.fromOffset(v139, v122)
				v120("Frame", v147, p115)
			end
		end
	end
end
local function v_u_178(p151) -- name: render
	-- upvalues: (copy) v_u_13, (copy) v_u_12, (copy) v_u_14
	local v152 = v_u_13[p151]
	local v153 = v_u_12[p151]
	if v152 and v153 then
		local v154 = nil
		for _, v155 in v_u_14 do
			local v156 = v152.src[v155]
			if not v156 then
				continue
			end
			v154 = v156
		end
		local v157 = v152.markFrame
		if v157 and not v157.Parent then
			v152.markFrame = nil
			v157 = nil
		end
		if v154 then
			local v158 = p151:FindFirstChild("Px")
			if v158 then
				local v159 = v154.rect
				local v160 = v159.Min.X
				local v161 = v159.Max.X
				local v162 = v160 * v153.cr + 0.5
				local v163 = math.floor(v162) - v153.lo + v153.g
				local v164 = v161 * v153.cr + 0.5
				local v165 = math.floor(v164) - v153.lo
				local v166 = v159.Min.Y
				local v167 = v159.Max.Y
				local v168 = v166 * v153.cr + 0.5
				local v169 = math.floor(v168) - v153.lo + v153.g
				local v170 = v167 * v153.cr + 0.5
				local v171 = math.floor(v170) - v153.lo
				if v157 == nil then
					v157 = Instance.new("Frame")
					v157.Name = "PouchMark"
					v157.BorderSizePixel = 0
					v157.ZIndex = 2
					v157.Active = false
					local v172 = Instance.new("UIStroke")
					v172.Thickness = 2
					v172.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
					v172.Parent = v157
					v157.Parent = v158
					v152.markFrame = v157
				end
				v157.Visible = true
				v157.Position = UDim2.fromOffset(v163, v169)
				local v173 = UDim2.fromOffset
				local v174 = v165 - v163
				local v175 = math.max(v174, 1)
				local v176 = v171 - v169
				v157.Size = v173(v175, (math.max(v176, 1)))
				v157.BackgroundColor3 = v154.color
				v157.BackgroundTransparency = v154.alpha
				local v177 = v157:FindFirstChildOfClass("UIStroke")
				if v177 then
					v177.Color = v154.color
				end
			end
		else
			if v157 then
				v157.Visible = false
			end
			return
		end
	else
		return
	end
end
local function v_u_188(p179, p180, p181, p182, p183) -- name: setSource
	-- upvalues: (copy) v_u_13, (copy) v_u_178
	local v184 = v_u_13[p179]
	if v184 then
		if p181 == nil then
			if v184.src[p180] == nil then
				return
			end
			v184.src[p180] = nil
		else
			local v185 = v184.src[p180]
			local v186 = p182 or Color3.fromRGB(255, 255, 255)
			local v187 = p183 or 0.9
			if v185 and (v185.rect == p181 and (v185.color == v186 and v185.alpha == v187)) then
				return
			end
			v184.src[p180] = {
				["rect"] = p181,
				["color"] = v186,
				["alpha"] = v187
			}
		end
		v_u_178(p179)
	end
end
local function v_u_194(p189, p190, p191) -- name: pouchRect
	-- upvalues: (ref) v_u_6
	if v_u_6 then
		local v192 = v_u_6.pouchAt(p189.slots, p190, p191)
		local v193
		if v192 then
			v193 = p189.slots[v192]
		else
			v193 = nil
		end
		if v193 then
			return Rect.new(v193.x, v193.y, v193.x + v193.w, v193.y + v193.h)
		else
			return nil
		end
	else
		return nil
	end
end
function v1.pouchAt(p195, p196, p197) -- name: pouchAt
	-- upvalues: (copy) v_u_13, (copy) v_u_194
	local v198 = v_u_13[p195]
	if v198 then
		return v_u_194(v198, p196, p197)
	else
		return nil
	end
end
function v1.mark(p199, p200, p201, p202) -- name: mark
	-- upvalues: (copy) v_u_188
	v_u_188(p199, "api", p200, p201, p202)
end
function v1.subtitle(p_u_203, p204, p205, p_u_206) -- name: subtitle
	-- upvalues: (ref) v_u_9, (ref) v_u_6
	local v207 = string.format("%d / %d", p204, p205)
	if v_u_9 then
		local function v209()
			-- upvalues: (copy) p_u_203, (ref) v_u_9, (copy) p_u_206
			local v208 = p_u_203
			return (type(v208) ~= "table" and "" or v_u_9.limitTail(p_u_203.limit)) .. v_u_9.safeTail(p_u_206)
		end
		local v210, v211 = pcall(v209)
		if v210 and type(v211) == "string" then
			v207 = v207 .. v211
		end
	end
	if type(p_u_203) == "table" then
		local v212 = p_u_203.slots
		if type(v212) == "table" and v_u_6 then
			local v213 = v_u_6.summary(p_u_203.slots)
			if v213 ~= "" then
				return v207 .. "  |  " .. v213
			end
		end
	end
	return v207
end
local function v_u_218(p214, p215) -- name: visibleAt
	while p214 do
		if p214:IsA("GuiObject") then
			if not p214.Visible then
				return false
			end
			if p214:IsA("ScrollingFrame") then
				local v216 = p214.AbsolutePosition
				local v217 = p214.AbsoluteSize
				if p215.X < v216.X or (p215.Y < v216.Y or (p215.X >= v216.X + v217.X or p215.Y >= v216.Y + v217.Y)) then
					return false
				end
			end
		elseif p214:IsA("LayerCollector") then
			return p214.Enabled == true
		end
		p214 = p214.Parent
	end
	return false
end
local function v_u_227(p219, p220, p221) -- name: cellUnder
	local v222 = p219.AbsolutePosition
	local v223 = p219.AbsoluteSize
	if v223.X < 1 or (v223.Y < 1 or (p221.X < v222.X or (p221.Y < v222.Y or (p221.X >= v222.X + v223.X or p221.Y >= v222.Y + v223.Y)))) then
		return nil, nil
	end
	local v224 = (p221.X - v222.X) / (v223.X / p220.c.w)
	local v225 = math.floor(v224)
	local v226 = (p221.Y - v222.Y) / (v223.Y / p220.c.h)
	return v225, math.floor(v226)
end
local v_u_228 = false
local v_u_229 = nil
local function v_u_256(p230) -- name: start
	-- upvalues: (ref) v_u_228, (copy) v_u_2, (copy) v_u_13, (copy) v_u_227, (copy) v_u_218, (copy) v_u_194, (copy) v_u_188, (copy) v_u_178, (copy) v_u_3, (ref) v_u_229
	if not v_u_228 then
		v_u_228 = true
		local v_u_231 = p230.theme.color
		v_u_2.InputChanged:Connect(function(p232)
			-- upvalues: (ref) v_u_13, (ref) v_u_227, (ref) v_u_218, (ref) v_u_194, (ref) v_u_188, (copy) v_u_231
			if p232.UserInputType == Enum.UserInputType.MouseMovement then
				local v233 = Vector2.new(p232.Position.X, p232.Position.Y)
				for v234, v235 in v_u_13 do
					if v234.Parent == nil then
						continue
					end
					local v236, v237 = v_u_227(v234, v235, v233)
					local v238
					if v236 and (v237 and (v235.src.drag == nil and v_u_218(v234, v233))) then
						v238 = v_u_194(v235, v236, v237)
					else
						v238 = nil
					end
					v_u_188(v234, "hover", v238, v_u_231.lineStrong, 0.9)
				end
			end
		end)
		v_u_2.InputBegan:Connect(function(p239)
			-- upvalues: (ref) v_u_13, (ref) v_u_227, (ref) v_u_218, (ref) v_u_194, (ref) v_u_188, (copy) v_u_231, (ref) v_u_178
			if p239.UserInputType == Enum.UserInputType.Touch then
				local v240 = Vector2.new(p239.Position.X, p239.Position.Y)
				for v_u_241, v_u_242 in v_u_13 do
					if v_u_241.Parent == nil then
						continue
					end
					local v243, v244 = v_u_227(v_u_241, v_u_242, v240)
					if not (v243 and (v244 and v_u_218(v_u_241, v240))) then
						continue
					end
					local v245 = v_u_194(v_u_242, v243, v244)
					if not v245 then
						continue
					end
					v_u_242.tapToken = v_u_242.tapToken + 1
					local v_u_246 = v_u_242.tapToken
					v_u_188(v_u_241, "tap", v245, v_u_231.accent, 0.8)
					task.delay(0.6, function()
						-- upvalues: (copy) v_u_242, (copy) v_u_246, (copy) v_u_241, (ref) v_u_13, (ref) v_u_178
						if v_u_242.tapToken == v_u_246 then
							local v247 = v_u_241
							local v248 = v_u_13[v247]
							if not v248 then
								return
							end
							if v248.src.tap == nil then
								return
							end
							v248.src.tap = nil
							v_u_178(v247)
						end
					end)
				end
			end
		end)
		v_u_3:GetPropertyChangedSignal("SelectedObject"):Connect(function()
			-- upvalues: (ref) v_u_229, (ref) v_u_3, (ref) v_u_13, (ref) v_u_194, (ref) v_u_188, (copy) v_u_231, (ref) v_u_178
			local v249 = v_u_229
			v_u_229 = nil
			local v250 = v_u_3.SelectedObject
			local v251
			if v250 then
				v251 = v250.Parent
			else
				v251 = nil
			end
			local v252
			if v251 and v251:IsA("Frame") then
				v252 = v_u_13[v251]
			else
				v252 = nil
			end
			if v252 and v250 then
				local v253 = v250:GetAttribute("PxRect")
				local v254 = typeof(v253) == "Rect" and v_u_194(v252, v253.Min.X, v253.Min.Y)
				if v254 then
					v_u_229 = v251
					v_u_188(v251, "pad", v254, v_u_231.accent, 0.8)
				end
			end
			if v249 and v249 ~= v_u_229 then
				local v255 = v_u_13[v249]
				if not v255 then
					return
				end
				if v255.src.pad == nil then
					return
				end
				v255.src.pad = nil
				v_u_178(v249)
			end
		end)
	end
end
local function v_u_268(p_u_257, p_u_258, p_u_259) -- name: watchHighlight
	-- upvalues: (copy) v_u_13, (copy) v_u_178, (copy) v_u_194, (copy) v_u_188
	p_u_258.hl = p_u_259
	local function v267() -- name: update
		-- upvalues: (copy) p_u_259, (copy) p_u_257, (ref) v_u_13, (ref) v_u_178, (copy) p_u_258, (ref) v_u_194, (ref) v_u_188
		if p_u_259.Parent then
			if p_u_259.Visible then
				local v260 = p_u_258.cell
				local v261 = math.max(v260, 1)
				local v262 = p_u_259.Position.X.Offset / v261 + 0.01
				local v263 = math.floor(v262)
				local v264 = p_u_259.Position.Y.Offset / v261 + 0.01
				v_u_188(p_u_257, "drag", v_u_194(p_u_258, v263, (math.floor(v264))), p_u_259.BackgroundColor3, 0.85)
				return
			else
				local v265 = p_u_257
				local v266 = v_u_13[v265]
				if v266 then
					if v266.src.drag ~= nil then
						v266.src.drag = nil
						v_u_178(v265)
					end
				else
					return
				end
			end
		else
			return
		end
	end
	p_u_259:GetPropertyChangedSignal("Visible"):Connect(v267)
	p_u_259:GetPropertyChangedSignal("Position"):Connect(v267)
	p_u_259:GetPropertyChangedSignal("BackgroundColor3"):Connect(v267)
end
function v1.draw(p_u_269, p_u_270, p_u_271, _, p_u_272) -- name: draw
	-- upvalues: (ref) v_u_6, (copy) v_u_13, (copy) v_u_256, (copy) v_u_268, (copy) v_u_12, (copy) v_u_150, (copy) v_u_35, (copy) v_u_178
	if p_u_270.slots then
		p_u_269.BackgroundTransparency = 1
		for _, v273 in p_u_269:GetChildren() do
			if not v273:IsA("UIStroke") then
				continue
			end
			v273:Destroy()
		end
	end
	p_u_269:SetAttribute("PxCell", p_u_271)
	local v_u_274 = p_u_272.new("Frame", {
		["Name"] = "Px",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(1, 1)
	}, p_u_269)
	local v_u_275 = Instance.new("UIScale")
	v_u_275.Parent = v_u_274
	local v_u_276
	if p_u_270.slots and v_u_6 then
		v_u_276 = {
			["slots"] = nil,
			["c"] = nil,
			["cell"] = nil,
			["src"] = nil,
			["markFrame"] = nil,
			["tapToken"] = 0,
			["hl"] = nil,
			["slots"] = p_u_270.slots,
			["c"] = p_u_270,
			["cell"] = p_u_271,
			["src"] = {}
		}
		v_u_13[p_u_269] = v_u_276
		v_u_256(p_u_272)
		local v_u_277 = v_u_276
		p_u_269.ChildAdded:Connect(function(p278)
			-- upvalues: (ref) v_u_268, (copy) p_u_269, (copy) v_u_277
			if p278.Name == "Highlight" and p278:IsA("Frame") then
				v_u_268(p_u_269, v_u_277, p278)
			end
		end)
	else
		v_u_276 = nil
	end
	local v_u_279 = -1
	local function v297() -- name: layout
		-- upvalues: (copy) p_u_269, (copy) p_u_270, (copy) p_u_271, (copy) p_u_272, (ref) v_u_279, (copy) v_u_274, (ref) v_u_276, (copy) v_u_275, (ref) v_u_12, (ref) v_u_150, (ref) v_u_35, (ref) v_u_178
		local v280 = p_u_269.AbsoluteSize.X
		local v281 = p_u_270.w * p_u_271
		local v282
		if v280 > 0.5 and v281 > 0 then
			v282 = v280 / v281
		else
			v282 = p_u_272.theme.uiScale()
		end
		local v283 = v282 - v_u_279
		if math.abs(v283) >= 0.001 then
			v_u_279 = v282
			for _, v284 in v_u_274:GetChildren() do
				if v284:IsA("UIScale") then
					continue
				end
				v284:Destroy()
			end
			if v_u_276 then
				v_u_276.markFrame = nil
			end
			v_u_275.Scale = 1 / v282
			local v285 = 2 * v282 + 0.5
			local v286 = math.floor(v285)
			local v287 = math.max(2, v286)
			local v288 = {
				["eff"] = v282,
				["cr"] = p_u_271 * v282,
				["g"] = v287
			}
			local v289 = v287 / 2
			v288.lo = math.floor(v289)
			v288.wf = p_u_270.w * p_u_271 * v282
			v288.hf = p_u_270.h * p_u_271 * v282
			v288.cell = p_u_271
			v_u_12[p_u_269] = v288
			local v290 = v_u_274
			local v291 = UDim2.fromOffset
			local v292 = p_u_270.w * v288.cr + 0.5
			local v293 = math.floor(v292)
			local v294 = p_u_270.h * v288.cr + 0.5
			v290.Size = v291(v293, (math.floor(v294)))
			v_u_150(v_u_274, p_u_270, v288, p_u_272)
			for _, v295 in p_u_269:GetChildren() do
				local v296 = v295:GetAttribute("PxRect")
				if typeof(v296) ~= "Rect" or not v295:IsA("GuiObject") then
					continue
				end
				v_u_35(v288, v295, v296.Min.X, v296.Min.Y, v296.Max.X - v296.Min.X, v296.Max.Y - v296.Min.Y)
			end
			if v_u_276 then
				v_u_178(p_u_269)
			end
		end
	end
	v297()
	p_u_269:GetPropertyChangedSignal("AbsoluteSize"):Connect(v297)
end
return v1