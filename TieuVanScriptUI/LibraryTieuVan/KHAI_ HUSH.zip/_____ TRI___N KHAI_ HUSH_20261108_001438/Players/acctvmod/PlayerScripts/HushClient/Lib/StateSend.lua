-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / StateSend

local v1 = {
	["TUNE"] = {
		["MIN_DT"] = 0.06666666666666667,
		["KEEPALIVE_RAID"] = 0.25,
		["KEEPALIVE_OTHER"] = 0.5,
		["YAW_CHANGED"] = 0.02,
		["PITCH_CHANGED"] = 0.02,
		["POS_MOVED"] = 1,
		["URGENT_WIN"] = 1,
		["URGENT_MAX"] = 5,
		["TOTAL_MAX"] = 17
	}
}
local v_u_2 = v1.TUNE
function v1.new() -- name: new
	return {
		["lastSend"] = (-1 / 0),
		["lastYaw"] = 999,
		["lastSprint"] = false,
		["lastSneak"] = false,
		["lastAim"] = false,
		["lastPitch"] = nil,
		["lastPos"] = nil,
		["seq"] = 0,
		["sends"] = nil,
		["urgents"] = nil,
		["nSent"] = 0,
		["nUrgent"] = 0,
		["nRefused"] = 0,
		["maxPerSec"] = 0,
		["sends"] = {},
		["urgents"] = {}
	}
end
local function v_u_5(p3, p4) -- name: prune
	-- upvalues: (copy) v_u_2
	while #p3 > 0 and (p4 - p3[1] >= v_u_2.URGENT_WIN or p4 < p3[1]) do
		table.remove(p3, 1)
	end
end
function v1.invalidate(p6) -- name: invalidate
	p6.lastYaw = 999
end
function v1.early(p7, p8, p9) -- name: early
	-- upvalues: (copy) v_u_2
	local v10
	if p8 - p7.lastSend < v_u_2.MIN_DT then
		v10 = p9 ~= true
	else
		v10 = false
	end
	return v10
end
function v1.step(p11, p12, p13, p14) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v15
	if p14 == nil then
		v15 = false
	else
		v15 = p14.urgent == true
	end
	local v16
	if p14 == nil then
		v16 = false
	else
		v16 = p14.force == true
	end
	local v17 = p12 - p11.lastSend
	if v17 < v_u_2.MIN_DT and not v15 then
		return nil
	end
	local v18 = p13.pos
	local v19 = p13.pitch
	local v20
	if type(v19) == "number" and p13.pitch == p13.pitch then
		v20 = p13.pitch
	else
		v20 = nil
	end
	local v21 = (p13.yaw - p11.lastYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	local v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34
	if math.abs(v21) > v_u_2.YAW_CHANGED or (p13.sprint ~= p11.lastSprint or (p13.sneak ~= p11.lastSneak or p13.aim ~= p11.lastAim)) then
		v22 = true
		if not (v22 or v16) then
			if p13.inRaid then
				v23 = v_u_2.KEEPALIVE_RAID
			else
				v23 = v_u_2.KEEPALIVE_OTHER
			end
			if v17 < v23 then
				return nil
			end
		end
		v_u_5(p11.sends, p12)
		if #p11.sends >= v_u_2.TOTAL_MAX then
			if v17 < v_u_2.MIN_DT then
				p11.nRefused = p11.nRefused + 1
			end
			return nil
		end
		if v17 < v_u_2.MIN_DT then
			v_u_5(p11.urgents, p12)
			if #p11.urgents >= v_u_2.URGENT_MAX then
				p11.nRefused = p11.nRefused + 1
				return nil
			end
			v24 = p11.urgents
			table.insert(v24, p12)
			p11.nUrgent = p11.nUrgent + 1
		end
		v25 = p11.sends
		table.insert(v25, p12)
		if #p11.sends > p11.maxPerSec then
			p11.maxPerSec = #p11.sends
		end
		p11.nSent = p11.nSent + 1
		p11.lastSend = p12
		p11.lastYaw = p13.yaw
		p11.lastSprint = p13.sprint
		p11.lastSneak = p13.sneak
		p11.lastAim = p13.aim
		p11.lastPitch = v20
		if v18 == nil or (v18.X ~= v18.X or (v18.Y ~= v18.Y or v18.Z ~= v18.Z)) then
			v26 = nil
		else
			p11.lastPos = v18
			p11.seq = p11.seq + 1
			v26 = {}
			v27 = v18.X * 10 + 0.5
			v26.x = math.floor(v27) / 10
			v28 = v18.Y * 10 + 0.5
			v26.y = math.floor(v28) / 10
			v29 = v18.Z * 10 + 0.5
			v26.z = math.floor(v29) / 10
		end
		v30 = {}
		if v20 == nil then
			v31 = nil
		else
			v32 = v20 * 1000 + 0.5
			v31 = math.floor(v32) / 1000
		end
		v30.aimPitch = v31
		v33 = p13.yaw * 1000 + 0.5
		v30.aimYaw = math.floor(v33) / 1000
		v30.sprint = p13.sprint
		v30.sneak = p13.sneak
		v30.aim = p13.aim
		v30.p = v26
		if v26 then
			v34 = p11.seq
		else
			v34 = nil
		end
		v30.q = v34
		return v30
	else
		if v20 == nil then
			if v18 == nil then
				v22 = false
			else
				v22 = p11.lastPos == nil and true or (v18 - p11.lastPos).Magnitude > v_u_2.POS_MOVED
			end
		else
			if p11.lastPitch == nil then
				v22 = true
				if not (v22 or v16) then
					if p13.inRaid then
						v23 = v_u_2.KEEPALIVE_RAID
					else
						v23 = v_u_2.KEEPALIVE_OTHER
					end
					if v17 < v23 then
						return nil
					end
				end
				v_u_5(p11.sends, p12)
				if #p11.sends >= v_u_2.TOTAL_MAX then
					if v17 < v_u_2.MIN_DT then
						p11.nRefused = p11.nRefused + 1
					end
					return nil
				end
				if v17 < v_u_2.MIN_DT then
					v_u_5(p11.urgents, p12)
					if #p11.urgents >= v_u_2.URGENT_MAX then
						p11.nRefused = p11.nRefused + 1
						return nil
					end
					v24 = p11.urgents
					table.insert(v24, p12)
					p11.nUrgent = p11.nUrgent + 1
				end
				v25 = p11.sends
				table.insert(v25, p12)
				if #p11.sends > p11.maxPerSec then
					p11.maxPerSec = #p11.sends
				end
				p11.nSent = p11.nSent + 1
				p11.lastSend = p12
				p11.lastYaw = p13.yaw
				p11.lastSprint = p13.sprint
				p11.lastSneak = p13.sneak
				p11.lastAim = p13.aim
				p11.lastPitch = v20
				if v18 == nil or (v18.X ~= v18.X or (v18.Y ~= v18.Y or v18.Z ~= v18.Z)) then
					v26 = nil
				else
					p11.lastPos = v18
					p11.seq = p11.seq + 1
					v26 = {}
					v27 = v18.X * 10 + 0.5
					v26.x = math.floor(v27) / 10
					v28 = v18.Y * 10 + 0.5
					v26.y = math.floor(v28) / 10
					v29 = v18.Z * 10 + 0.5
					v26.z = math.floor(v29) / 10
				end
				v30 = {}
				if v20 == nil then
					v31 = nil
				else
					v32 = v20 * 1000 + 0.5
					v31 = math.floor(v32) / 1000
				end
				v30.aimPitch = v31
				v33 = p13.yaw * 1000 + 0.5
				v30.aimYaw = math.floor(v33) / 1000
				v30.sprint = p13.sprint
				v30.sneak = p13.sneak
				v30.aim = p13.aim
				v30.p = v26
				if v26 then
					v34 = p11.seq
				else
					v34 = nil
				end
				v30.q = v34
				return v30
			end
			local v35 = v20 - p11.lastPitch
			if math.abs(v35) > v_u_2.PITCH_CHANGED then
				v22 = true
				if not (v22 or v16) then
					if p13.inRaid then
						v23 = v_u_2.KEEPALIVE_RAID
					else
						v23 = v_u_2.KEEPALIVE_OTHER
					end
					if v17 < v23 then
						return nil
					end
				end
				v_u_5(p11.sends, p12)
				if #p11.sends >= v_u_2.TOTAL_MAX then
					if v17 < v_u_2.MIN_DT then
						p11.nRefused = p11.nRefused + 1
					end
					return nil
				end
				if v17 < v_u_2.MIN_DT then
					v_u_5(p11.urgents, p12)
					if #p11.urgents >= v_u_2.URGENT_MAX then
						p11.nRefused = p11.nRefused + 1
						return nil
					end
					v24 = p11.urgents
					table.insert(v24, p12)
					p11.nUrgent = p11.nUrgent + 1
				end
				v25 = p11.sends
				table.insert(v25, p12)
				if #p11.sends > p11.maxPerSec then
					p11.maxPerSec = #p11.sends
				end
				p11.nSent = p11.nSent + 1
				p11.lastSend = p12
				p11.lastYaw = p13.yaw
				p11.lastSprint = p13.sprint
				p11.lastSneak = p13.sneak
				p11.lastAim = p13.aim
				p11.lastPitch = v20
				if v18 == nil or (v18.X ~= v18.X or (v18.Y ~= v18.Y or v18.Z ~= v18.Z)) then
					v26 = nil
				else
					p11.lastPos = v18
					p11.seq = p11.seq + 1
					v26 = {}
					v27 = v18.X * 10 + 0.5
					v26.x = math.floor(v27) / 10
					v28 = v18.Y * 10 + 0.5
					v26.y = math.floor(v28) / 10
					v29 = v18.Z * 10 + 0.5
					v26.z = math.floor(v29) / 10
				end
				v30 = {}
				if v20 == nil then
					v31 = nil
				else
					v32 = v20 * 1000 + 0.5
					v31 = math.floor(v32) / 1000
				end
				v30.aimPitch = v31
				v33 = p13.yaw * 1000 + 0.5
				v30.aimYaw = math.floor(v33) / 1000
				v30.sprint = p13.sprint
				v30.sneak = p13.sneak
				v30.aim = p13.aim
				v30.p = v26
				if v26 then
					v34 = p11.seq
				else
					v34 = nil
				end
				v30.q = v34
				return v30
			end
			if v18 == nil then
				v22 = false
			else
				v22 = p11.lastPos == nil and true or (v18 - p11.lastPos).Magnitude > v_u_2.POS_MOVED
			end
		end
		if not (v22 or v16) then
			if p13.inRaid then
				v23 = v_u_2.KEEPALIVE_RAID
			else
				v23 = v_u_2.KEEPALIVE_OTHER
			end
			if v17 < v23 then
				return nil
			end
		end
		v_u_5(p11.sends, p12)
		if #p11.sends >= v_u_2.TOTAL_MAX then
			if v17 < v_u_2.MIN_DT then
				p11.nRefused = p11.nRefused + 1
			end
			return nil
		end
		if v17 < v_u_2.MIN_DT then
			v_u_5(p11.urgents, p12)
			if #p11.urgents >= v_u_2.URGENT_MAX then
				p11.nRefused = p11.nRefused + 1
				return nil
			end
			v24 = p11.urgents
			table.insert(v24, p12)
			p11.nUrgent = p11.nUrgent + 1
		end
		v25 = p11.sends
		table.insert(v25, p12)
		if #p11.sends > p11.maxPerSec then
			p11.maxPerSec = #p11.sends
		end
		p11.nSent = p11.nSent + 1
		p11.lastSend = p12
		p11.lastYaw = p13.yaw
		p11.lastSprint = p13.sprint
		p11.lastSneak = p13.sneak
		p11.lastAim = p13.aim
		p11.lastPitch = v20
		if v18 == nil or (v18.X ~= v18.X or (v18.Y ~= v18.Y or v18.Z ~= v18.Z)) then
			v26 = nil
		else
			p11.lastPos = v18
			p11.seq = p11.seq + 1
			v26 = {}
			v27 = v18.X * 10 + 0.5
			v26.x = math.floor(v27) / 10
			v28 = v18.Y * 10 + 0.5
			v26.y = math.floor(v28) / 10
			v29 = v18.Z * 10 + 0.5
			v26.z = math.floor(v29) / 10
		end
		v30 = {}
		if v20 == nil then
			v31 = nil
		else
			v32 = v20 * 1000 + 0.5
			v31 = math.floor(v32) / 1000
		end
		v30.aimPitch = v31
		v33 = p13.yaw * 1000 + 0.5
		v30.aimYaw = math.floor(v33) / 1000
		v30.sprint = p13.sprint
		v30.sneak = p13.sneak
		v30.aim = p13.aim
		v30.p = v26
		if v26 then
			v34 = p11.seq
		else
			v34 = nil
		end
		v30.q = v34
		return v30
	end
end
function v1.stats(p36) -- name: stats
	return {
		["sent"] = p36.nSent,
		["urgent"] = p36.nUrgent,
		["refused"] = p36.nRefused,
		["maxPerSec"] = p36.maxPerSec
	}
end
return v1