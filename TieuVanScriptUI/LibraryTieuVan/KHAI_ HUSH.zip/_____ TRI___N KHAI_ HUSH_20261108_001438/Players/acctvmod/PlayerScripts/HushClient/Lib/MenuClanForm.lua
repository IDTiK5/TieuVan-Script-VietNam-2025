-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanForm

local v_u_26 = {
	["numberInput"] = function(p1, p_u_2) -- name: numberInput
		local v3 = p1.UI
		local v4 = p1.Theme
		local _ = p1.M
		local v_u_5 = p_u_2.min or 0
		local v_u_6 = p_u_2.max or 9999
		local v7 = p_u_2.value
		local v8 = tonumber(v7) or 0
		local v9 = math.floor(v8)
		local v_u_10 = math.clamp(v9, v_u_5, v_u_6)
		local v11, v_u_12 = v3.input({
			["parent"] = p_u_2.parent,
			["name"] = p_u_2.name or "Number",
			["placeholder"] = p_u_2.placeholder or "0",
			["text"] = tostring(v_u_10),
			["maxLength"] = #tostring(v_u_6),
			["size"] = p_u_2.size or UDim2.fromOffset(p_u_2.width or 120, v4.touch(44)),
			["position"] = p_u_2.position
		})
		local v_u_13 = false
		v_u_12:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_13, (copy) v_u_12, (ref) v_u_10, (copy) v_u_5, (copy) v_u_6, (copy) p_u_2
			if not v_u_13 then
				local v14 = string.gsub(v_u_12.Text, "[^%d]", "")
				if v14 ~= v_u_12.Text then
					v_u_13 = true
					v_u_12.Text = v14
					v_u_13 = false
				end
				local v15 = tonumber(v14)
				if v15 ~= nil then
					local v16 = math.floor(v15)
					local v17 = v_u_5
					local v18 = v_u_6
					v_u_10 = math.clamp(v16, v17, v18)
					if p_u_2.onChange then
						p_u_2.onChange(v_u_10)
					end
				end
			end
		end)
		v_u_12.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_13, (copy) v_u_12, (ref) v_u_10
			v_u_13 = true
			local v19 = v_u_10
			v_u_12.Text = tostring(v19)
			v_u_13 = false
		end)
		return v11, v_u_12, function()
			-- upvalues: (ref) v_u_10
			return v_u_10
		end
	end,
	["field"] = function(p20, p21, p22, p23, p24, p25) -- name: field
		p20.UI.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = p21,
			["name"] = "Cap_" .. string.gsub(p22, "[^%w]", ""),
			["text"] = p22,
			["color"] = p20.C.text2,
			["position"] = UDim2.fromOffset(p23, p24),
			["size"] = UDim2.fromOffset(p25, 16)
		})
		return p20.U.frame(p21, "Field_" .. string.gsub(p22, "[^%w]", ""), UDim2.fromOffset(p25, p20.Theme.touch(44)), UDim2.fromOffset(p23, p24 + 18))
	end
}
local v_u_27 = {
	"Tag: 3 or 4 letters or digits, at least one letter.",
	"Name: 3 to 20 letters, digits and single spaces.",
	"Both go through the Roblox text filter and cannot be changed later.",
	"The pass is never used up. If a name is refused, choose another one."
}
function v_u_26.found(p_u_28, p29) -- name: found
	-- upvalues: (copy) v_u_27, (copy) v_u_26
	local v_u_30 = p_u_28.UI
	local v_u_31 = p_u_28.Theme
	local v_u_32 = p_u_28.C
	local v_u_33 = p_u_28.Kit
	local v_u_34 = p_u_28.U
	local v_u_35 = p_u_28.M
	local v_u_36 = p_u_28.m
	local v_u_37 = {}
	local v_u_38 = true
	local v_u_39 = ""
	local v_u_40 = ""
	local v_u_41 = "request"
	local v_u_42 = ""
	local v_u_43 = 0
	local v_u_44 = 0
	local v_u_45 = false
	local v_u_46 = 0
	local v_u_47 = nil
	local v_u_48 = nil
	local v49 = v_u_36.fieldW
	local v50 = v_u_36.inner
	local v_u_51 = math.min(v49, v50)
	local v_u_52 = v_u_30.list({
		["parent"] = nil,
		["name"] = "Form",
		["size"] = nil,
		["gap"] = 6,
		["padding"] = nil,
		["parent"] = p29,
		["size"] = UDim2.new(0, v_u_51 + 14, 1, 0),
		["padding"] = {
			0,
			6,
			0,
			12
		}
	})
	local v_u_53 = v_u_51 + 14 + v_u_36.colGap
	if v_u_36.twoCol and v_u_36.inner - v_u_53 >= 240 then
		local v54 = v_u_34.frame(p29, "Help", UDim2.new(0, v_u_36.inner - v_u_53, 1, 0), UDim2.fromOffset(v_u_53, 0))
		for v55, v56 in v_u_27 do
			v_u_30.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["valign"] = "top",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v54,
				["name"] = "Help" .. v55,
				["text"] = v56,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(0, (v55 - 1) * 46),
				["size"] = UDim2.new(1, 0, 0, 42)
			})
		end
	end
	local v_u_57 = nil
	local v_u_58 = nil
	local v_u_59 = nil
	local v_u_60 = nil
	local v_u_61 = nil
	local v_u_62 = nil
	local function v_u_99() -- name: build
		-- upvalues: (copy) v_u_33, (copy) v_u_52, (copy) p_u_28, (copy) v_u_35, (copy) v_u_34, (copy) v_u_32, (copy) v_u_30, (copy) v_u_36, (copy) v_u_53, (ref) v_u_27, (copy) v_u_31, (ref) v_u_26, (copy) v_u_51, (ref) v_u_39, (ref) v_u_47, (ref) v_u_57, (ref) v_u_40, (ref) v_u_48, (ref) v_u_58, (ref) v_u_41, (ref) v_u_62, (ref) v_u_61, (ref) v_u_43, (ref) v_u_44, (ref) v_u_42, (ref) v_u_60, (copy) v_u_37, (ref) v_u_59
		v_u_33.clear(v_u_52)
		local v63 = p_u_28.state()
		local v64, v65 = v_u_35.foundState(v63)
		if v64 == "nopass" then
			local v66 = v_u_34.frame(v_u_52, "B" .. 1, UDim2.new(1, -14, 0, 96), nil, 1)
			v66.BackgroundTransparency = 0.3
			v66.BackgroundColor3 = v_u_32.raised
			v_u_30.stroke(v66, v_u_32.line)
			v_u_30.label({
				["parent"] = nil,
				["name"] = "NoPass",
				["text"] = nil,
				["style"] = "body",
				["wrap"] = true,
				["valign"] = "top",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v66,
				["text"] = v65,
				["position"] = UDim2.fromOffset(12, 10),
				["size"] = UDim2.new(1, -24, 0, 40)
			})
			if p_u_28.canStore() then
				v_u_34.btn({
					["parent"] = nil,
					["text"] = "GET THE PASS",
					["kind"] = "primary",
					["width"] = 200,
					["name"] = "Store",
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v66,
					["position"] = UDim2.fromOffset(12, 48),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_28
						p_u_28.goStore()
					end
				})
			else
				v_u_30.label({
					["parent"] = nil,
					["name"] = "StoreHint",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v66,
					["text"] = v_u_35.UI.OPEN_STORE,
					["color"] = v_u_32.accent,
					["position"] = UDim2.fromOffset(12, 58),
					["size"] = UDim2.new(1, -24, 0, 20)
				})
			end
			if not v_u_36.twoCol or v_u_36.inner - v_u_53 < 240 then
				for v67, v68 in v_u_27 do
					v_u_30.label({
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["valign"] = "top",
						["size"] = nil,
						["order"] = nil,
						["parent"] = v_u_52,
						["name"] = "Help" .. v67,
						["text"] = v68,
						["color"] = v_u_32.text2,
						["size"] = UDim2.new(1, -14, 0, 34),
						["order"] = 10 + v67
					})
				end
			end
		else
			local v69 = 18 + v_u_31.touch(44) + 22
			local v70 = v_u_34.frame(v_u_52, "B" .. 1, UDim2.new(1, -14, 0, v69), nil, 1)
			local v71 = v_u_26.field(p_u_28, v70, "TAG", 0, 0, v_u_51 - 14)
			local _, v_u_72 = v_u_30.input({
				["parent"] = nil,
				["name"] = "Tag",
				["placeholder"] = "ABCD",
				["maxLength"] = nil,
				["text"] = nil,
				["size"] = nil,
				["parent"] = v71,
				["maxLength"] = v_u_35.TAG_MAX,
				["text"] = v_u_39,
				["size"] = UDim2.fromScale(1, 1)
			})
			v_u_47 = v_u_72
			local v_u_73 = false
			v_u_72:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_73, (ref) v_u_35, (copy) v_u_72, (ref) v_u_39, (ref) v_u_57
				if not v_u_73 then
					local v74 = v_u_35.normTag(v_u_72.Text)
					if v74 ~= v_u_72.Text then
						v_u_73 = true
						v_u_72.Text = v74
						v_u_73 = false
					end
					v_u_39 = v74
					v_u_57.set("", nil)
				end
			end)
			v_u_57 = v_u_34.status(v70, {
				["name"] = "TagErr",
				["text"] = "",
				["style"] = "small",
				["size"] = nil,
				["position"] = nil,
				["visible"] = false,
				["size"] = UDim2.new(1, 0, 0, 20),
				["position"] = UDim2.fromOffset(0, 18 + v_u_31.touch(44) + 2)
			})
			local v75 = 18 + v_u_31.touch(44) + 22
			local v76 = v_u_34.frame(v_u_52, "B" .. 2, UDim2.new(1, -14, 0, v75), nil, 2)
			local v77 = v_u_26.field(p_u_28, v76, "NAME", 0, 0, v_u_51 - 14)
			local _, v_u_78 = v_u_30.input({
				["parent"] = nil,
				["name"] = "Name",
				["placeholder"] = "Clan name",
				["maxLength"] = nil,
				["text"] = nil,
				["size"] = nil,
				["parent"] = v77,
				["maxLength"] = v_u_35.NAME_MAX,
				["text"] = v_u_40,
				["size"] = UDim2.fromScale(1, 1)
			})
			v_u_48 = v_u_78
			v_u_78:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_40, (copy) v_u_78, (ref) v_u_58
				v_u_40 = v_u_78.Text
				v_u_58.set("", nil)
			end)
			v_u_78.FocusLost:Connect(function()
				-- upvalues: (ref) v_u_35, (copy) v_u_78, (ref) v_u_40
				local v79 = v_u_35.normName(v_u_78.Text)
				if v79 ~= v_u_78.Text then
					v_u_78.Text = v79
				end
				v_u_40 = v79
			end)
			v_u_58 = v_u_34.status(v76, {
				["name"] = "NameErr",
				["text"] = "",
				["style"] = "small",
				["size"] = nil,
				["position"] = nil,
				["visible"] = false,
				["size"] = UDim2.new(1, 0, 0, 20),
				["position"] = UDim2.fromOffset(0, 18 + v_u_31.touch(44) + 2)
			})
			local v80 = 18 + v_u_31.touch(44) + 38
			local v81 = v_u_34.frame(v_u_52, "B" .. 3, UDim2.new(1, -14, 0, v80), nil, 3)
			v_u_30.label({
				["parent"] = nil,
				["text"] = "WHO CAN JOIN",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v81,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(1, 0, 0, 16)
			})
			local _, v83 = v_u_30.tabs({
				["parent"] = nil,
				["name"] = "Mode",
				["position"] = nil,
				["size"] = nil,
				["selected"] = nil,
				["tabs"] = nil,
				["onChange"] = nil,
				["parent"] = v81,
				["position"] = UDim2.fromOffset(0, 18),
				["size"] = UDim2.new(1, 0, 0, v_u_31.touch(44)),
				["selected"] = v_u_41,
				["tabs"] = {
					{
						["id"] = "open",
						["text"] = "Open"
					},
					{
						["id"] = "request",
						["text"] = "On request"
					},
					{
						["id"] = "private",
						["text"] = "Private"
					}
				},
				["onChange"] = function(p82) -- name: onChange
					-- upvalues: (ref) v_u_41, (ref) v_u_62, (ref) v_u_35
					v_u_41 = p82
					if v_u_62 then
						v_u_62.Text = v_u_35.MODE_HELP[p82] or ""
					end
				end
			})
			v_u_61 = v83
			v_u_62 = v_u_30.label({
				["parent"] = nil,
				["name"] = "ModeHelp",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["valign"] = "top",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v81,
				["text"] = v_u_35.MODE_HELP[v_u_41] or "",
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(0, 18 + v_u_31.touch(44) + 4),
				["size"] = UDim2.new(1, 0, 0, 32)
			})
			local v84 = 18 + v_u_31.touch(44) + 4
			local v85 = v_u_34.frame(v_u_52, "B" .. 4, UDim2.new(1, -14, 0, v84), nil, 4)
			local v86 = (v_u_51 - 14 - v_u_36.gap) / 2
			local v87 = math.floor(v86)
			local v88 = v_u_26.field(p_u_28, v85, "MIN RAIDS", 0, 0, v87)
			v_u_26.numberInput(p_u_28, {
				["parent"] = nil,
				["name"] = "Raids",
				["min"] = 0,
				["max"] = 9999,
				["value"] = nil,
				["size"] = nil,
				["onChange"] = nil,
				["parent"] = v88,
				["value"] = v_u_43,
				["size"] = UDim2.fromScale(1, 1),
				["onChange"] = function(p89) -- name: onChange
					-- upvalues: (ref) v_u_43
					v_u_43 = p89
				end
			})
			local v90 = v_u_26.field(p_u_28, v85, "MIN EXTRACTION %", v87 + v_u_36.gap, 0, v87)
			v_u_26.numberInput(p_u_28, {
				["parent"] = nil,
				["name"] = "Pct",
				["min"] = 0,
				["max"] = 100,
				["value"] = nil,
				["size"] = nil,
				["onChange"] = nil,
				["parent"] = v90,
				["value"] = v_u_44,
				["size"] = UDim2.fromScale(1, 1),
				["onChange"] = function(p91) -- name: onChange
					-- upvalues: (ref) v_u_44
					v_u_44 = p91
				end
			})
			local v92 = 18 + v_u_31.touch(44) + 4
			local v93 = v_u_34.frame(v_u_52, "B" .. 5, UDim2.new(1, -14, 0, v92), nil, 5)
			local v94 = v_u_26.field(p_u_28, v93, "DESCRIPTION (OPTIONAL)", 0, 0, v_u_51 - 14)
			local _, v_u_95 = v_u_30.input({
				["parent"] = nil,
				["name"] = "Desc",
				["placeholder"] = "A short line about your clan",
				["maxLength"] = nil,
				["text"] = nil,
				["size"] = nil,
				["parent"] = v94,
				["maxLength"] = v_u_35.DESC_MAX,
				["text"] = v_u_42,
				["size"] = UDim2.fromScale(1, 1)
			})
			v_u_95:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_42, (copy) v_u_95
				v_u_42 = v_u_95.Text
			end)
			local v96 = v_u_31.touch(44) + 30
			local v97 = v_u_34.frame(v_u_52, "B" .. 6, UDim2.new(1, -14, 0, v96), nil, 6)
			local _, v98 = v_u_34.btn({
				["parent"] = nil,
				["text"] = "FOUND CLAN",
				["kind"] = "primary",
				["width"] = 200,
				["name"] = "Found",
				["disabled"] = nil,
				["onClick"] = nil,
				["parent"] = v97,
				["disabled"] = v64 ~= "ok",
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_37
					v_u_37.submit()
				end
			})
			v_u_60 = v98
			v_u_59 = v_u_34.status(v97, {
				["name"] = "FormErr",
				["text"] = nil,
				["style"] = "small",
				["wrap"] = true,
				["valign"] = "top",
				["size"] = nil,
				["position"] = nil,
				["visible"] = nil,
				["kind"] = "warn",
				["text"] = v64 == "ok" and "" or v65,
				["size"] = UDim2.new(1, 0, 0, 24),
				["position"] = UDim2.fromOffset(0, v_u_31.touch(44) + 4),
				["visible"] = v64 ~= "ok"
			})
			if v64 ~= "ok" then
				v_u_59.set(v65, "warn")
			end
		end
	end
	function v_u_37.submit() -- name: submit
		-- upvalues: (ref) v_u_45, (ref) v_u_57, (ref) v_u_58, (ref) v_u_59, (copy) v_u_35, (ref) v_u_39, (ref) v_u_40, (ref) v_u_42, (ref) v_u_46, (ref) v_u_60, (ref) v_u_43, (ref) v_u_44, (copy) p_u_28, (ref) v_u_41, (ref) v_u_38
		if v_u_45 then
			return
		else
			v_u_57.set("", nil)
			v_u_58.set("", nil)
			v_u_59.set("", nil)
			local v100 = v_u_35.normTag(v_u_39)
			local v101 = v_u_35.normName(v_u_40)
			local v102
			if v_u_35.tagOk(v100) then
				v102 = false
			else
				v_u_57.set(v_u_35.TEXT.TAG_BAD, "danger")
				v102 = true
			end
			if not v_u_35.nameOk(v101) then
				v_u_58.set(v_u_35.TEXT.NAME_BAD, "danger")
				v102 = true
			end
			if not v_u_35.descOk(v_u_42) then
				v_u_42 = v_u_35.cleanDesc(v_u_42)
			end
			if not v102 then
				v_u_45 = true
				v_u_46 = v_u_46 + 1
				local v_u_103 = v_u_46
				v_u_60.busy(true, v_u_35.UI.FOUNDING)
				local v_u_104 = v_u_43
				local v_u_105 = v_u_44
				p_u_28.send("clanFound", {
					["tag"] = v100,
					["name"] = v101,
					["mode"] = v_u_41,
					["desc"] = v_u_35.cleanDesc(v_u_42)
				}, function(p106, p107, p108, p109)
					-- upvalues: (ref) v_u_45, (copy) v_u_104, (copy) v_u_105, (ref) p_u_28, (ref) v_u_38, (copy) v_u_103, (ref) v_u_46, (ref) v_u_60, (ref) v_u_35, (ref) v_u_57, (ref) v_u_58, (ref) v_u_59
					v_u_45 = false
					if p106 then
						if v_u_104 > 0 or v_u_105 > 0 then
							local v110 = {
								["raids"] = v_u_104,
								["pct"] = v_u_105
							}
							p_u_28.send("clanSetCriteria", v110, function() end, 20)
						end
						return
					elseif v_u_38 and v_u_103 == v_u_46 then
						local v111 = v_u_60.busy
						pcall(v111, false)
						local v112 = type(p108) ~= "table" and {} or p108
						local v113 = v_u_35.foundField(v112.code, v112)
						local v114 = v_u_35.reasonFor(p109 or {
							["msg"] = p107,
							["data"] = p108
						})
						if v113 == "tag" then
							v_u_57.set(v114, "danger")
							return
						elseif v113 == "name" then
							v_u_58.set(v114, "danger")
						else
							v_u_59.set(v114, "danger")
						end
					else
						return
					end
				end, v_u_35.FOUND_TIMEOUT)
			end
		end
	end
	function v_u_37.show() -- name: show
		-- upvalues: (copy) v_u_99
		v_u_99()
	end
	function v_u_37.hide() -- name: hide end
	function v_u_37.refresh(p115) -- name: refresh
		-- upvalues: (ref) v_u_45, (copy) v_u_35, (copy) p_u_28, (copy) v_u_37, (copy) v_u_99
		if p115 == "state" and not v_u_45 then
			local v116 = v_u_35.foundState(p_u_28.state())
			if v_u_37._kind ~= v116 then
				v_u_37._kind = v116
				v_u_99()
			end
		end
	end
	function v_u_37.tick() -- name: tick end
	function v_u_37.destroy() -- name: destroy
		-- upvalues: (ref) v_u_38
		v_u_38 = false
	end
	v_u_37._kind = v_u_35.foundState(p_u_28.state())
	v_u_99()
	return v_u_37
end
return v_u_26