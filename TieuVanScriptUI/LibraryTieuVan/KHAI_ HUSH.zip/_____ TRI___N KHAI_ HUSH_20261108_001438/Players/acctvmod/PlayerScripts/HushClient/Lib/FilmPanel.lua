-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPanel

local v_u_1 = not (script and (script.Parent and script.Parent:FindFirstChild("ServerClock"))) and {
	["now"] = function() -- name: now
		return workspace:GetServerTimeNow()
	end
} or require(script.Parent.ServerClock)
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = v_u_5:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_7 = require(script.Parent:WaitForChild("HushUI"))
local v_u_8 = v_u_7.Theme
local v_u_9 = v_u_8.color
local v_u_10 = {}
local v_u_11 = v2.LocalPlayer
local v12, v13 = pcall(function()
	-- upvalues: (copy) v_u_6
	return require((v_u_6:WaitForChild("Config", 5)))
end)
if v12 then
	if type(v13) == "table" then
		v12 = v13.IS_TEST == true
	else
		v12 = false
	end
end
local v_u_14 = (v12 and 30 or 0) + 660
local v_u_15 = v_u_14 - 32 - 10
v_u_10.MIN_W = v_u_14
v_u_10.MIN_H = 300
v_u_10.MAX_W = 1400
v_u_10.MAX_H = 1800
v_u_10.EDGE = 8
v_u_10._session = nil
function v_u_10.clampSize(p16, p17, p18, p19, p20, p21) -- name: clampSize
	-- upvalues: (copy) v_u_10
	local v22 = (type(p18) ~= "number" or (p18 ~= p18 or (p18 == (1 / 0) or p18 == (-1 / 0)))) and 0 or p18
	local v23 = math.max(0, v22)
	local v24 = (type(p19) ~= "number" or (p19 ~= p19 or (p19 == (1 / 0) or p19 == (-1 / 0)))) and 0 or p19
	local v25 = math.max(0, v24)
	local v26 = v_u_10.MAX_W
	if type(p20) == "number" and (p20 == p20 and (p20 ~= (1 / 0) and p20 ~= (-1 / 0))) then
		v26 = p20
	end
	local v27 = v_u_10.MAX_H
	if type(p21) == "number" and (p21 == p21 and (p21 ~= (1 / 0) and p21 ~= (-1 / 0))) then
		v27 = p21
	end
	local v28 = v_u_10.MIN_W
	local v29 = v_u_10.MAX_W
	local v30 = v26 - v23 - v_u_10.EDGE
	local v31 = math.min(v29, v30)
	local v32 = math.max(v28, v31)
	local v33 = v_u_10.MIN_H
	local v34 = v_u_10.MAX_H
	local v35 = v27 - v25 - v_u_10.EDGE
	local v36 = math.min(v34, v35)
	local v37 = math.max(v33, v36)
	local v38 = v_u_10.MIN_W
	if type(p16) == "number" and (p16 == p16 and (p16 ~= (1 / 0) and p16 ~= (-1 / 0))) then
		v38 = p16
	end
	local v39 = v_u_10.MIN_W
	local v40 = math.clamp(v38, v39, v32)
	local v41 = v_u_10.MIN_H
	if type(p17) == "number" and (p17 == p17 and (p17 ~= (1 / 0) and p17 ~= (-1 / 0))) then
		v41 = p17
	end
	local v42 = v_u_10.MIN_H
	return v40, math.clamp(v41, v42, v37)
end
function v_u_10.pvpRefundShown(p_u_43, p_u_44) -- name: pvpRefundShown
	if type(p_u_43) ~= "table" then
		return false
	end
	local v45, v46 = pcall(function()
		-- upvalues: (copy) p_u_44, (copy) p_u_43
		if p_u_44 == nil then
			return p_u_43.isPvpve()
		else
			return p_u_43.forMode(p_u_44, "pvp")
		end
	end)
	if v45 then
		v45 = v46 == true
	end
	return v45
end
function v_u_10.build(p_u_47) -- name: build
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_14, (copy) v_u_10, (copy) v_u_3, (copy) v_u_11, (copy) v_u_9, (copy) v_u_4, (copy) v_u_6, (copy) v_u_15, (copy) v_u_5, (copy) v_u_1
	local v_u_48, v_u_49 = v_u_7.screen("HushFilm", v_u_8.layer.modal + 10, {
		["insets"] = "None"
	})
	local v_u_50 = {
		["gui"] = v_u_48
	}
	local v_u_51 = {}
	local function v52()
		-- upvalues: (ref) v_u_8
		return v_u_8.viewport()
	end
	local v53, v54 = pcall(v52)
	local v55
	if v53 and (typeof(v54) == "Vector2" and v54.Y > 0) then
		local v56 = v54.Y
		local v57 = v_u_8.uiScale()
		local v58 = v56 / math.max(v57, 0.1)
		local v59 = math.floor(v58) - 72 - 8
		v55 = math.clamp(v59, 300, 720)
	else
		v55 = 720
	end
	local v_u_60, v61 = v_u_7.panel({
		["parent"] = nil,
		["name"] = "FilmPanel",
		["size"] = nil,
		["position"] = nil,
		["accent"] = true,
		["padding"] = false,
		["transparency"] = 0,
		["parent"] = v_u_49,
		["size"] = UDim2.fromOffset(v_u_14, v55),
		["position"] = UDim2.new(1, -v_u_14 - 24, 0, 72)
	})
	v_u_60.Active = true
	local v62 = v_u_10._session
	if v62 ~= nil then
		local function v63()
			-- upvalues: (ref) v_u_8
			return v_u_8.viewport()
		end
		local v64, v65 = pcall(v63)
		local v66 = v_u_8.uiScale()
		local v67 = math.max(v66, 0.1)
		if v64 and (typeof(v65) == "Vector2" and v65.Y > 0) then
			local v68, v69 = v_u_10.clampSize(v62.w, v62.h, 24, 72, v65.X / v67, v65.Y / v67)
			local v70 = v_u_10.MIN_W
			local v71 = v65.X / v67 - 24 - v_u_10.EDGE
			local v72 = math.max(v70, v71)
			local v73 = math.min(v68, v72)
			v_u_60.Size = UDim2.fromOffset(v73, v69)
			v_u_60.Position = UDim2.new(1, -v73 - 24, 0, 72)
		end
	end
	local v74 = v_u_7.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Active"] = true,
		["Size"] = UDim2.new(1, 0, 0, 64)
	}, v61)
	v_u_7.label({
		["parent"] = nil,
		["text"] = "FILM MODE",
		["style"] = "h3",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v74,
		["position"] = UDim2.fromOffset(16, 8),
		["size"] = UDim2.fromOffset(150, 24)
	})
	v_u_7.badge("FILM SESSION: NOTHING IS SAVED", "danger", {
		["parent"] = nil,
		["position"] = nil,
		["height"] = 18,
		["name"] = "Tainted",
		["parent"] = v74,
		["position"] = UDim2.fromOffset(16, 38)
	})
	local _, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Clean frame",
		["kind"] = "secondary",
		["height"] = 30,
		["width"] = 130,
		["position"] = nil,
		["tooltip"] = "Hide everything but the world (Ctrl+F8 brings it back)",
		["onClick"] = nil,
		["parent"] = v74,
		["position"] = UDim2.new(1, -184, 0, 10),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_47
			p_u_47.toggleClean()
		end
	})
	v_u_7.closeIcon({
		["parent"] = nil,
		["size"] = 30,
		["position"] = nil,
		["tooltip"] = "Close film mode (restores everything)",
		["onClick"] = nil,
		["parent"] = v74,
		["position"] = UDim2.new(1, -46, 0, 10),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_47
			p_u_47.close()
		end
	})
	v_u_7.divider({
		["parent"] = v74,
		["position"] = UDim2.new(0, 0, 1, -1),
		["size"] = UDim2.new(1, 0, 0, 1)
	})
	local v_u_75 = nil
	local v_u_76 = nil
	v74.InputBegan:Connect(function(p77)
		-- upvalues: (ref) v_u_75, (ref) v_u_76, (copy) v_u_60
		if p77.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_75 = Vector2.new(p77.Position.X, p77.Position.Y)
			v_u_76 = v_u_60.Position
		end
	end)
	local v_u_83 = v_u_3.InputChanged:Connect(function(p78)
		-- upvalues: (ref) v_u_75, (ref) v_u_76, (ref) v_u_8, (copy) v_u_60
		if v_u_75 and (v_u_76 and p78.UserInputType == Enum.UserInputType.MouseMovement) then
			local v79 = Vector2.new(p78.Position.X, p78.Position.Y) - v_u_75
			local v80 = v_u_8.uiScale()
			local v81 = v79 / math.max(v80, 0.1)
			local v82 = v_u_76
			v_u_60.Position = UDim2.new(v82.X.Scale, v82.X.Offset + v81.X, v82.Y.Scale, v82.Y.Offset + v81.Y)
		end
	end)
	local v_u_85 = v_u_3.InputEnded:Connect(function(p84)
		-- upvalues: (ref) v_u_75
		if p84.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_75 = nil
		end
	end)
	v_u_48.Destroying:Connect(function()
		-- upvalues: (copy) v_u_83, (copy) v_u_85
		v_u_83:Disconnect()
		v_u_85:Disconnect()
	end)
	local function v_u_101(p86, p87) -- name: applySize
		-- upvalues: (ref) v_u_8, (copy) v_u_60, (copy) v_u_49, (ref) v_u_10, (ref) v_u_11
		local v88 = v_u_8.uiScale()
		local v89 = math.max(v88, 0.1)
		local v90 = v_u_60.AbsolutePosition - v_u_49.AbsolutePosition
		local v91 = v_u_49.AbsoluteSize
		local v92 = v90.X / v89
		local v93 = v90.Y / v89
		local v94 = v91.X / v89
		local v95 = v91.Y / v89
		local v96, v97 = v_u_10.clampSize(p86, p87, 0, v93, v94, v95)
		if v94 < v92 + v96 + v_u_10.EDGE then
			local v98 = v_u_60
			local v99 = UDim2.fromOffset
			local v100 = v94 - v96 - v_u_10.EDGE
			v98.Position = v99(math.max(0, v100), v93)
		end
		v_u_60.Size = UDim2.fromOffset(v96, v97)
		v_u_10._session = {
			["w"] = v96,
			["h"] = v97
		}
		v_u_11:SetAttribute("FilmPanelSize", ("%d,%d"):format(v96, v97))
		return v96, v97
	end
	local v102 = v_u_7.new("Frame", {
		["Name"] = "ResizeGrip",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = true,
		["ZIndex"] = 60,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -2, 1, -2),
		["Size"] = UDim2.fromOffset(22, 22)
	}, v_u_60)
	for v103 = 1, 3 do
		local v104 = (v103 - 1) * 7 + 6
		local v105 = (v103 - 1) * 4 + 4
		v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Rotation"] = -45,
			["Size"] = nil,
			["ZIndex"] = 61,
			["Name"] = "GripLine" .. v103,
			["BackgroundColor3"] = v_u_9.text2,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(1, -v105, 1, -v105),
			["Size"] = UDim2.fromOffset(v104, 2)
		}, v102)
	end
	local v_u_106 = nil
	local v_u_107 = nil
	v102.InputBegan:Connect(function(p108)
		-- upvalues: (ref) v_u_8, (copy) v_u_60, (copy) v_u_49, (ref) v_u_106, (ref) v_u_107
		if p108.UserInputType == Enum.UserInputType.MouseButton1 then
			local v109 = v_u_8.uiScale()
			local v110 = math.max(v109, 0.1)
			local v111 = v_u_60.AbsolutePosition - v_u_49.AbsolutePosition
			local v112 = v_u_49.AbsoluteSize
			local v113 = v111.X / v110
			local v114 = v111.Y / v110
			local _ = v112.X / v110
			local _ = v112.Y / v110
			v_u_60.Position = UDim2.fromOffset(v113, v114)
			v_u_106 = Vector2.new(p108.Position.X, p108.Position.Y)
			local v115 = v_u_60.AbsoluteSize
			local v116 = v_u_8.uiScale()
			local v117 = v115 / math.max(v116, 0.1)
			v_u_107 = Vector2.new(v117.X, v117.Y)
		end
	end)
	local v_u_123 = v_u_3.InputChanged:Connect(function(p118)
		-- upvalues: (ref) v_u_106, (ref) v_u_107, (ref) v_u_8, (copy) v_u_101
		if v_u_106 and (v_u_107 and p118.UserInputType == Enum.UserInputType.MouseMovement) then
			local v119 = Vector2.new(p118.Position.X, p118.Position.Y) - v_u_106
			local v120 = v_u_8.uiScale()
			local v121 = v119 / math.max(v120, 0.1)
			local v122 = v_u_107
			v_u_101(v122.X + v121.X, v122.Y + v121.Y)
		end
	end)
	local v_u_125 = v_u_3.InputEnded:Connect(function(p124)
		-- upvalues: (ref) v_u_106
		if p124.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_106 = nil
		end
	end)
	v_u_48.Destroying:Connect(function()
		-- upvalues: (copy) v_u_123, (copy) v_u_125
		v_u_123:Disconnect()
		v_u_125:Disconnect()
	end)
	function v_u_50.resize(p126, p127) -- name: resize
		-- upvalues: (ref) v_u_8, (copy) v_u_60, (copy) v_u_49, (copy) v_u_101
		local v128 = v_u_8.uiScale()
		local v129 = math.max(v128, 0.1)
		local v130 = v_u_60.AbsolutePosition - v_u_49.AbsolutePosition
		local v131 = v_u_49.AbsoluteSize
		local v132 = v130.X / v129
		local v133 = v130.Y / v129
		local _ = v131.X / v129
		local _ = v131.Y / v129
		v_u_60.Position = UDim2.fromOffset(v132, v133)
		return v_u_101(p126, p127)
	end
	function v_u_50.size() -- name: size
		-- upvalues: (copy) v_u_60, (ref) v_u_8
		local v134 = v_u_60.AbsoluteSize
		local v135 = v_u_8.uiScale()
		local v136 = v134 / math.max(v135, 0.1)
		local v137 = v136.X + 0.5
		local v138 = math.floor(v137)
		local v139 = v136.Y + 0.5
		return v138, math.floor(v139)
	end
	if v_u_4:IsStudio() then
		local v_u_143 = v_u_11:GetAttributeChangedSignal("FilmPanelResize"):Connect(function()
			-- upvalues: (ref) v_u_11, (copy) v_u_50
			local v140 = v_u_11:GetAttribute("FilmPanelResize")
			if type(v140) == "string" and v140 ~= "" then
				v_u_11:SetAttribute("FilmPanelResize", nil)
				local v141, v142 = string.match(v140, "^(%d+)%s+(%d+)$")
				if v141 and v142 then
					v_u_50.resize(tonumber(v141), (tonumber(v142)))
				end
			end
		end)
		v_u_48.Destroying:Connect(function()
			-- upvalues: (copy) v_u_143
			v_u_143:Disconnect()
		end)
	end
	local v_u_144 = {
		{
			["id"] = "scenes",
			["text"] = "Scenes"
		},
		{
			["id"] = "camera",
			["text"] = "Camera"
		},
		{
			["id"] = "spawn",
			["text"] = "Spawn"
		},
		{
			["id"] = "loot",
			["text"] = "Loot"
		},
		{
			["id"] = "world",
			["text"] = "World"
		},
		{
			["id"] = "raid",
			["text"] = "Raid"
		},
		{
			["id"] = "server",
			["text"] = "Server"
		},
		{
			["id"] = "votes",
			["text"] = "Votes"
		},
		{
			["id"] = "mail",
			["text"] = "Mail"
		},
		{
			["id"] = "give",
			["text"] = "Give"
		},
		{
			["id"] = "codes",
			["text"] = "Codes"
		},
		{
			["id"] = "entry",
			["text"] = "Entry"
		},
		{
			["id"] = "restock",
			["text"] = "Restock"
		},
		{
			["id"] = "sale",
			["text"] = "Sale"
		}
	}
	local v_u_145 = "Config"
	local function v146()
		-- upvalues: (ref) v_u_6, (copy) v_u_145
		return require((v_u_6:WaitForChild(v_u_145, 5)))
	end
	local v147, v148 = pcall(v146)
	if not v147 then
		v148 = nil
	end
	local v149
	if v148 == nil then
		v149 = false
	else
		v149 = v148.IS_TEST == true
	end
	if v149 then
		table.insert(v_u_144, {
			["id"] = "test",
			["text"] = "Test"
		})
	end
	local v_u_150 = {}
	local v154, v_u_155 = v_u_7.tabs({
		["parent"] = nil,
		["tabs"] = nil,
		["selected"] = "scenes",
		["size"] = nil,
		["position"] = nil,
		["onChange"] = nil,
		["parent"] = v61,
		["tabs"] = v_u_144,
		["size"] = UDim2.new(1, -32, 0, 40),
		["position"] = UDim2.fromOffset(16, 68),
		["onChange"] = function(p151) -- name: onChange
			-- upvalues: (copy) v_u_150, (ref) v_u_11, (copy) v_u_50
			for v152, v153 in v_u_150 do
				v153.Visible = v152 == p151
			end
			v_u_11:SetAttribute("FilmTab", p151)
			if v_u_50.onTab then
				v_u_50.onTab(p151)
			end
		end
	})
	local v_u_156 = v154:FindFirstChild("Row")
	local v_u_157
	if v_u_156 then
		v_u_157 = v_u_156:FindFirstChildOfClass("UIListLayout")
	else
		v_u_157 = v_u_156
	end
	if v_u_157 and v_u_156 then
		local v_u_158 = false
		local function v168() -- name: fit
			-- upvalues: (ref) v_u_158, (copy) v_u_144, (copy) v_u_157, (copy) v_u_156
			if not v_u_158 then
				v_u_158 = true
				local v159 = #v_u_144
				local v160 = v_u_157.Padding.Offset
				local v161 = v_u_157.AbsoluteContentSize.X - v160 * (v159 - 1)
				local v162 = v_u_156.AbsoluteSize.X
				if v162 > 0 and v161 > 0 then
					local v163 = v162 - v161
					local v164 = v159 - 1
					local v165 = v163 / math.max(1, v164)
					local v166 = math.floor(v165)
					local v167 = math.clamp(v166, 2, 16)
					if v167 ~= v160 then
						v_u_157.Padding = UDim.new(0, v167)
					end
				end
				v_u_158 = false
			end
		end
		v_u_157:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(v168)
		v_u_156:GetPropertyChangedSignal("AbsoluteSize"):Connect(v168)
		task.defer(v168)
	end
	for _, v169 in v_u_144 do
		local v170 = v_u_7.list({
			["parent"] = nil,
			["name"] = nil,
			["gap"] = 8,
			["size"] = nil,
			["position"] = nil,
			["parent"] = v61,
			["name"] = "Body_" .. v169.id,
			["size"] = UDim2.new(1, -32, 1, -150),
			["position"] = UDim2.fromOffset(16, 116)
		})
		v170.Visible = v169.id == "scenes"
		v_u_150[v169.id] = v170
	end
	local v171, v172 = pcall(function()
		return require((script.Parent:WaitForChild("FilmVotes", 5)))
	end)
	if v171 and v172 then
		local v173 = v172.build
		local v174 = {
			["body"] = v_u_150.votes,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v175, v176 = pcall(v173, v174)
		if not v175 then
			warn("[FilmPanel] votes tab failed:", v176)
		end
	else
		warn("[FilmPanel] FilmVotes missing")
	end
	local v177, v178 = pcall(function()
		return require((script.Parent:WaitForChild("FilmMail", 5)))
	end)
	if v177 and v178 then
		local v179 = v178.build
		local v180 = {
			["body"] = v_u_150.mail,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v181, v182 = pcall(v179, v180)
		if not v181 then
			warn("[FilmPanel] mail tab failed:", v182)
		end
	else
		warn("[FilmPanel] FilmMail missing")
	end
	local v183, v184 = pcall(function()
		return require((script.Parent:WaitForChild("FilmGive", 5)))
	end)
	if v183 and v184 then
		local v185 = v184.build
		local v186 = {
			["body"] = v_u_150.give,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v187, v188 = pcall(v185, v186)
		if not v187 then
			warn("[FilmPanel] give tab failed:", v188)
		end
	end
	local v189, v190 = pcall(function()
		return require((script.Parent:WaitForChild("FilmCodes", 5)))
	end)
	if v189 and v190 then
		local v191 = v190.build
		local v192 = {
			["body"] = v_u_150.codes,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v193, v194 = pcall(v191, v192)
		if not v193 then
			warn("[FilmPanel] codes tab failed:", v194)
		end
	else
		warn("[FilmPanel] FilmCodes missing")
	end
	local v195, v196 = pcall(function()
		return require((script.Parent:WaitForChild("FilmEntry", 5)))
	end)
	if v195 and v196 then
		local v197 = v196.build
		local v198 = {
			["body"] = v_u_150.entry,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v199, v200 = pcall(v197, v198)
		if not v199 then
			warn("[FilmPanel] entry tab failed:", v200)
		end
	else
		warn("[FilmPanel] FilmEntry missing")
	end
	local v201, v202 = pcall(function()
		return require((script.Parent:WaitForChild("FilmRestock", 5)))
	end)
	if v201 and v202 then
		local v203 = v202.build
		local v204 = {
			["body"] = v_u_150.restock,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v205, v206 = pcall(v203, v204)
		if not v205 then
			warn("[FilmPanel] restock tab failed:", v206)
		end
	else
		warn("[FilmPanel] FilmRestock missing")
	end
	local v207, v208 = pcall(function()
		return require((script.Parent:WaitForChild("FilmStoreSale", 5)))
	end)
	if v207 and v208 then
		local v209 = v208.build
		local v210 = {
			["body"] = v_u_150.sale,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v211, v212 = pcall(v209, v210)
		if not v211 then
			warn("[FilmPanel] sale tab failed:", v212)
		end
	else
		warn("[FilmPanel] FilmStoreSale missing")
	end
	if v149 and v_u_150.test then
		local v213, v214 = pcall(function()
			return require((script.Parent:WaitForChild("FilmTest", 5)))
		end)
		if v213 and v214 then
			local v215 = v214.build
			local v216 = {
				["body"] = v_u_150.test,
				["api"] = p_u_47,
				["handle"] = v_u_50,
				["inner"] = v_u_15,
				["syncers"] = v_u_51,
				["gui"] = v_u_48
			}
			local v217, v218 = pcall(v215, v216)
			if not v217 then
				warn("[FilmPanel] test tab failed:", v218)
			end
		else
			warn("[FilmPanel] FilmTest missing")
		end
	end
	local v_u_219 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "Ready.",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v61,
		["color"] = v_u_9.text2,
		["position"] = UDim2.new(0, 16, 1, -30),
		["size"] = UDim2.new(1, -32, 0, 22)
	})
	v_u_219.TextTruncate = Enum.TextTruncate.AtEnd
	function v_u_50.status(p220, p221) -- name: status
		-- upvalues: (copy) v_u_219, (ref) v_u_9, (ref) v_u_11
		v_u_219.Text = p220
		local v222 = v_u_219
		local v223
		if p221 == "danger" then
			v223 = v_u_9.danger
		elseif p221 == "success" then
			v223 = v_u_9.success
		else
			v223 = v_u_9.text2
		end
		v222.TextColor3 = v223
		v_u_11:SetAttribute("FilmStatus", p220)
	end
	local v_u_224 = {}
	local function v228(p225, p226) -- name: section
		-- upvalues: (ref) v_u_7, (ref) v_u_9, (copy) v_u_224
		local v227 = v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p225,
			["text"] = p226,
			["color"] = v_u_9.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_224[p225] = (v_u_224[p225] or 0) + 1
		v227.LayoutOrder = v_u_224[p225]
		return v227
	end
	local function v_u_232(p229, p230) -- name: note
		-- upvalues: (ref) v_u_7, (ref) v_u_9, (copy) v_u_224
		local v231 = v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p229,
			["text"] = p230,
			["color"] = v_u_9.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_224[p229] = (v_u_224[p229] or 0) + 1
		v231.LayoutOrder = v_u_224[p229]
		return v231
	end
	local function v_u_236(p233, p234) -- name: row
		-- upvalues: (ref) v_u_7, (copy) v_u_224
		local v235 = v_u_7.new("Frame", {
			["Name"] = "Row",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, p234 or 32)
		}, p233)
		v_u_7.layout(v235, "h", 6)
		v_u_224[p233] = (v_u_224[p233] or 0) + 1
		v235.LayoutOrder = v_u_224[p233]
		return v235
	end
	local function v_u_244(p237, p238, p239, p240, p241) -- name: btn
		-- upvalues: (ref) v_u_7, (copy) v_u_224
		local v242, v243 = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = p237,
			["text"] = p238,
			["kind"] = p239 or "secondary",
			["width"] = p240,
			["onClick"] = p241,
			["maxTextWidth"] = (p240 or 140) - 12
		})
		v_u_224[p237] = (v_u_224[p237] or 0) + 1
		v242.LayoutOrder = v_u_224[p237]
		return v242, v243
	end
	local function v256(p245, p246, p247, p248, p249, p250, p251, p252) -- name: slider
		-- upvalues: (ref) v_u_7, (ref) v_u_15, (copy) v_u_224
		local v253 = {
			["parent"] = p245,
			["label"] = p246,
			["min"] = p247,
			["max"] = p248,
			["step"] = p249,
			["value"] = p250,
			["width"] = v_u_15,
			["onChange"] = p251,
			["format"] = p252
		}
		local v254, v255 = v_u_7.slider(v253)
		v_u_224[p245] = (v_u_224[p245] or 0) + 1
		v254.LayoutOrder = v_u_224[p245]
		return v255
	end
	local function v276(p257, p258, p259, p_u_260) -- name: segmented
		-- upvalues: (copy) v_u_236, (ref) v_u_15, (copy) v_u_244
		local v261 = v_u_236(p257, 32)
		local v_u_262 = {}
		local v263 = (v_u_15 - (#p258 - 1) * 6) / #p258
		local v264 = math.floor(v263)
		local v_u_265 = p259
		local function v269(p266) -- name: sel
			-- upvalues: (ref) v_u_265, (copy) v_u_262
			if p266 ~= v_u_265 then
				v_u_265 = p266
				for v267, v268 in v_u_262 do
					v268.setKind(v267 == p266 and "primary" or "secondary")
				end
			end
		end
		local v_u_270 = v_u_265
		for _, v_u_271 in p258 do
			local _, v275 = v_u_244(v261, v_u_271.text, v_u_271.id == p259 and "primary" or "secondary", v264, function()
				-- upvalues: (copy) v_u_271, (ref) v_u_270, (copy) v_u_262, (copy) p_u_260
				local v272 = v_u_271.id
				if v272 ~= v_u_270 then
					v_u_270 = v272
					for v273, v274 in v_u_262 do
						v274.setKind(v273 == v272 and "primary" or "secondary")
					end
				end
				p_u_260(v_u_271.id)
			end)
			v_u_262[v_u_271.id] = v275
		end
		return v269
	end
	local v277 = v_u_150.scenes
	local v_u_278 = {}
	local v_u_279 = nil
	local v_u_280 = v_u_7.new("Frame", {
		["Name"] = "SceneList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v277)
	v_u_7.layout(v_u_280, "v", 4)
	v_u_280.LayoutOrder = 2
	v_u_224[v277] = 2
	local v_u_281 = nil
	local v_u_282 = {}
	local function v_u_294() -- name: paint
		-- upvalues: (ref) v_u_282, (ref) v_u_279, (ref) v_u_9, (ref) v_u_278, (ref) v_u_281
		for v283, v284 in v_u_282 do
			local v285
			if v283 == v_u_279 then
				v285 = v_u_9.accentDeep
			else
				v285 = v_u_9.raised
			end
			v284.BackgroundColor3 = v285
			local v286 = v284:FindFirstChildOfClass("UIStroke")
			if not v286 then
				continue
			end
			local v287
			if v283 == v_u_279 then
				v287 = v_u_9.accent
			else
				v287 = v_u_9.line
			end
			v286.Color = v287
		end
		local v288 = "Pick a scene."
		for _, v289 in v_u_278 do
			if v289.id ~= v_u_279 then
				continue
			end
			local v290 = v289.desc or ""
			v288 = tostring(v290)
			if v289.hint then
				local v291 = v289.hint
				v288 = v288 .. "\nHint: " .. tostring(v291)
			end
			if v289.kind == "photo" then
				local v292 = v289.frame or "16:9"
				v288 = v288 .. "\nFrame: " .. tostring(v292) .. "   ACTION = freeze / unfreeze effects"
			else
				if not v289.camera then
					continue
				end
				local v293 = v289.camera
				v288 = v288 .. "\nCamera: " .. tostring(v293)
			end
		end
		v_u_281.Text = v288
	end
	local function v_u_314() -- name: rebuild
		-- upvalues: (copy) v_u_280, (ref) v_u_282, (ref) v_u_278, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_279, (copy) v_u_294
		for _, v295 in v_u_280:GetChildren() do
			if not v295:IsA("GuiObject") then
				continue
			end
			v295:Destroy()
		end
		v_u_282 = {}
		local v296 = {}
		local v297 = 0
		local v298 = false
		local v299 = 0
		for _, v300 in v_u_278 do
			if v300.kind == "photo" then
				continue
			end
			table.insert(v296, v300)
		end
		for _, v301 in v_u_278 do
			if v301.kind ~= "photo" then
				continue
			end
			table.insert(v296, v301)
		end
		for v302, v303 in v296 do
			local v304 = v303.id
			local v_u_305 = tostring(v304)
			local v306 = v303.kind == "photo"
			if v306 and not v298 then
				local v307 = v_u_7.label({
					["parent"] = nil,
					["text"] = "PHOTO  \194\183  ICON AND THUMBNAILS",
					["style"] = "caps",
					["color"] = nil,
					["size"] = nil,
					["parent"] = v_u_280,
					["color"] = v_u_9.accent,
					["size"] = UDim2.new(1, 0, 0, 26)
				})
				v307.Name = "Section_photo"
				v307.LayoutOrder = v302 * 2 - 1
				v298 = true
			end
			local v308
			if v306 then
				v308 = v299 + 1
				v299 = v308
			else
				v308 = v297 + 1
				v297 = v308
			end
			local v309 = v_u_7.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Scene_" .. v_u_305,
				["BackgroundColor3"] = v_u_9.raised,
				["Size"] = UDim2.new(1, 0, 0, 34),
				["LayoutOrder"] = v302 * 2
			}, v_u_280)
			v_u_7.stroke(v309, v_u_9.line)
			local v310 = v_u_7.label
			local v311 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v309
			}
			local v312 = string.format
			local v313 = v303.title or v_u_305
			v311.text = v312("%s%d  %s", v306 and "P" or "", v308, (tostring(v313)))
			v311.position = UDim2.fromOffset(10, 0)
			v311.size = UDim2.new(1, -20, 1, 0)
			v310(v311).TextTruncate = Enum.TextTruncate.AtEnd
			v309.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_7, (ref) v_u_8
				v_u_7.sound(v_u_8.sounds.hover)
			end)
			v309.Activated:Connect(function()
				-- upvalues: (ref) v_u_279, (copy) v_u_305, (ref) v_u_7, (ref) v_u_8, (ref) v_u_294
				v_u_279 = v_u_305
				v_u_7.sound(v_u_8.sounds.click)
				v_u_294()
			end)
			v_u_282[v_u_305] = v309
		end
		v_u_294()
	end
	local function v318() -- name: refresh
		-- upvalues: (copy) p_u_47, (ref) v_u_278, (ref) v_u_279, (copy) v_u_314, (copy) v_u_50
		p_u_47.call("scene.list", {}, function(p315)
			-- upvalues: (ref) v_u_278, (ref) v_u_279, (ref) v_u_314, (ref) v_u_50
			if p315 and p315.ok then
				local v316 = p315.data
				if type(v316) == "table" then
					v_u_278 = p315.data
					if not v_u_279 and v_u_278[1] then
						local v317 = v_u_278[1].id
						v_u_279 = tostring(v317)
					end
					v_u_314()
					v_u_50.status(string.format("%d scenes.", #v_u_278), "success")
				end
			end
		end)
	end
	local v319 = v_u_236(v277, 32)
	v319.LayoutOrder = 1
	v_u_224[v277] = 0
	local v320, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v319,
		["onClick"] = v318
	})
	v_u_224[v319] = (v_u_224[v319] or 0) + 1
	v320.LayoutOrder = v_u_224[v319]
	v_u_7.label({
		["parent"] = nil,
		["text"] = "F8 panel \194\183 Ctrl+F8 clean frame \194\183 Esc game camera",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v319,
		["color"] = v_u_9.muted,
		["size"] = UDim2.fromOffset(v_u_15 - 120, 32)
	}).LayoutOrder = 9
	v_u_224[v277] = 2
	v228(v277, "Scene")
	v_u_281 = v_u_232(v277, "Pick a scene.")
	local v321 = v_u_236(v277, 32)
	local v322 = (v_u_15 - 12) / 3
	local v323 = math.floor(v322)
	local function v329()
		-- upvalues: (ref) v_u_279, (copy) p_u_47
		if v_u_279 then
			local v324 = {
				["id"] = v_u_279
			}
			p_u_47.call("scene.load", v324, function(p325)
				-- upvalues: (ref) p_u_47
				if p325 and p325.ok then
					local v326 = p325.data
					if type(v326) == "table" and p325.data.pending then
						return
					end
				end
				if p325 and (p325.ok and p_u_47.sceneLoaded) then
					p_u_47.sceneLoaded(p325.data)
				end
				if p325 and p325.ok then
					local v327 = p325.data
					if type(v327) ~= "table" or p325.data.kind ~= "photo" then
						local v328 = p325.data
						if type(v328) == "table" then
							v328 = v328.camera or v328.cam or (v328.preset or v328)
						end
						if v328 ~= nil then
							p_u_47.applyPreset(v328)
						end
					end
				end
			end)
		end
	end
	local v330, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Load",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v321,
		["width"] = v323,
		["onClick"] = v329,
		["maxTextWidth"] = (v323 or 140) - 12
	})
	v_u_224[v321] = (v_u_224[v321] or 0) + 1
	v330.LayoutOrder = v_u_224[v321]
	local function v333()
		-- upvalues: (ref) v_u_278, (ref) v_u_279, (copy) p_u_47, (copy) v_u_50
		for _, v331 in v_u_278 do
			if v331.id ~= v_u_279 then
				continue
			end
			v332 = v331.kind
		end
		local v332 = nil
		if v332 == "photo" and (p_u_47.photo and p_u_47.photo.active()) then
			p_u_47.photo.setFxFrozen(not p_u_47.photo.fxFrozen())
			v_u_50.status(p_u_47.photo.fxFrozen() and "Effects frozen." or "Effects running.", "success")
		else
			p_u_47.call("scene.action", {})
		end
	end
	local v334, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Action",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v321,
		["width"] = v323,
		["onClick"] = v333,
		["maxTextWidth"] = (v323 or 140) - 12
	})
	v_u_224[v321] = (v_u_224[v321] or 0) + 1
	v334.LayoutOrder = v_u_224[v321]
	local v336, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Reset",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v321,
		["width"] = v323,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("scene.reset", {}, function(p335)
				-- upvalues: (ref) p_u_47
				if p335 and (p335.ok and p_u_47.sceneLoaded) then
					p_u_47.sceneLoaded(p335.data)
				end
			end)
		end,
		["maxTextWidth"] = (v323 or 140) - 12
	})
	v_u_224[v321] = (v_u_224[v321] or 0) + 1
	v336.LayoutOrder = v_u_224[v321]
	v_u_232(v277, "LOAD starts a private solo raid if needed and stages the scene (zombies frozen). Frame the shot, start recording, then ACTION.")
	v_u_50.refreshScenes = v318
	v228(v277, "Photo")
	local v337 = v_u_236(v277, 32)
	local v338 = (v_u_15 - 12) / 3
	local v339 = math.floor(v338)
	local v340, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Camera preset",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v337,
		["width"] = v339,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47, (copy) v_u_50
			if p_u_47.photoCamera and p_u_47.photoCamera() then
				v_u_50.status("Photo camera preset.", "success")
			else
				v_u_50.status("No photo scene loaded.", "danger")
			end
		end,
		["maxTextWidth"] = (v339 or 140) - 12
	})
	v_u_224[v337] = (v_u_224[v337] or 0) + 1
	v340.LayoutOrder = v_u_224[v337]
	local v341, v342 = v_u_7.button({
		["parent"] = nil,
		["text"] = "Freeze FX",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v337,
		["width"] = v339,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			if p_u_47.photo and p_u_47.photo.active() then
				p_u_47.photo.setFxFrozen(not p_u_47.photo.fxFrozen())
			end
		end,
		["maxTextWidth"] = (v339 or 140) - 12
	})
	v_u_224[v337] = (v_u_224[v337] or 0) + 1
	v341.LayoutOrder = v_u_224[v337]
	local v_u_343 = v342
	local v344, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Clear photo",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v337,
		["width"] = v339,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			if p_u_47.photoClear then
				p_u_47.photoClear()
			end
		end,
		["maxTextWidth"] = (v339 or 140) - 12
	})
	v_u_224[v337] = (v_u_224[v337] or 0) + 1
	v344.LayoutOrder = v_u_224[v337]
	local v_u_345 = p_u_47.look
	local v_u_349 = v276(v277, {
		{
			["id"] = "none",
			["text"] = "No frame"
		},
		{
			["id"] = "1:1",
			["text"] = "1:1 icon"
		},
		{
			["id"] = "16:9",
			["text"] = "16:9 thumb"
		}
	}, "none", function(p346)
		-- upvalues: (copy) v_u_345
		local _, v347, v348 = v_u_345.guides()
		v_u_345.setGuideFrame(p346 == "none" and "" or p346, v347, v348)
	end)
	local v353 = {
		["parent"] = nil,
		["label"] = "Rule of thirds",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v277,
		["width"] = v_u_15,
		["onChange"] = function(p350)
			-- upvalues: (copy) v_u_345
			local v351, _, v352 = v_u_345.guides()
			v_u_345.setGuideFrame(v351, p350, v352)
		end
	}
	local v354, v355 = v_u_7.toggle(v353)
	v_u_224[v277] = (v_u_224[v277] or 0) + 1
	v354.LayoutOrder = v_u_224[v277]
	local v_u_356 = v355
	local v358 = {
		["parent"] = nil,
		["label"] = "Guides in clean frame",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v277,
		["width"] = v_u_15,
		["onChange"] = function(p357)
			-- upvalues: (copy) p_u_47
			p_u_47.clean.exempt("HushFilmGuides", p357)
		end
	}
	local v359, v360 = v_u_7.toggle(v358)
	v_u_224[v277] = (v_u_224[v277] or 0) + 1
	v359.LayoutOrder = v_u_224[v277]
	local v_u_361 = v360
	v_u_232(v277, "PHOTO scenes: LOAD builds a frozen still (your avatar posed, zombies in poses, effects) and puts the free camera on the scene\'s frame. Fly to adjust (WASD, right mouse), then Ctrl+F8 and take the screenshot.")
	local v_u_362 = nil
	local function v366()
		-- upvalues: (copy) v_u_345, (copy) v_u_349, (copy) v_u_356, (copy) v_u_361, (copy) p_u_47, (ref) v_u_362, (copy) v_u_343
		local v363, v364 = v_u_345.guides()
		v_u_349(v363 ~= "1:1" and v363 ~= "16:9" and "none" or v363)
		v_u_356.set(v364)
		v_u_361.set(p_u_47.clean.isExempt("HushFilmGuides"))
		local v365
		if p_u_47.photo == nil then
			v365 = false
		else
			v365 = p_u_47.photo.fxFrozen()
		end
		if v365 ~= v_u_362 then
			v_u_362 = v365
			v_u_343.setText(v365 and "Unfreeze FX" or "Freeze FX")
		end
	end
	table.insert(v_u_51, v366)
	local v367 = v_u_150.camera
	local v_u_368 = p_u_47.cam
	v228(v367, "Camera")
	local v_u_370 = v276(v367, {
		{
			["id"] = "game",
			["text"] = "Game"
		},
		{
			["id"] = "free",
			["text"] = "Free"
		},
		{
			["id"] = "orbit",
			["text"] = "Orbit"
		},
		{
			["id"] = "follow",
			["text"] = "Follow"
		},
		{
			["id"] = "dolly",
			["text"] = "Dolly"
		}
	}, v_u_368.mode(), function(p369)
		-- upvalues: (copy) p_u_47
		p_u_47.setCamMode(p369)
	end)
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_370, (copy) v_u_368
		v_u_370(v_u_368.mode())
	end)
	v_u_232(v367, "Free: WASD, E/Q up/down, hold right mouse to look, Shift fast, Ctrl slow, wheel = speed. Esc = back to the game camera.")
	local v_u_372 = v256(v367, "Field of view", 10, 90, 1, v_u_368.get("fov"), function(p371)
		-- upvalues: (copy) v_u_368
		v_u_368.set("fov", p371)
	end)
	local v_u_374 = v256(v367, "Roll", -30, 30, 1, v_u_368.get("roll"), function(p373)
		-- upvalues: (copy) v_u_368
		v_u_368.set("roll", p373)
	end)
	local v_u_376 = v256(v367, "Handheld shake", 0, 1, 0.05, v_u_368.get("shake"), function(p375)
		-- upvalues: (copy) v_u_368
		v_u_368.set("shake", p375)
	end)
	local v_u_378 = v256(v367, "Smoothing", 0, 1, 0.05, v_u_368.get("smooth"), function(p377)
		-- upvalues: (copy) v_u_368
		v_u_368.set("smooth", p377)
	end)
	local v_u_380 = v256(v367, "Free fly speed", 2, 200, 1, v_u_368.get("speed"), function(p379)
		-- upvalues: (copy) v_u_368
		v_u_368.set("speed", p379)
	end)
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_372, (copy) v_u_368, (copy) v_u_374, (copy) v_u_376, (copy) v_u_378, (copy) v_u_380
		v_u_372.set(v_u_368.get("fov"))
		v_u_374.set(v_u_368.get("roll"))
		v_u_376.set(v_u_368.get("shake"))
		v_u_378.set(v_u_368.get("smooth"))
		v_u_380.set(v_u_368.get("speed"))
	end)
	v228(v367, "Orbit")
	local v_u_382 = v256(v367, "Auto-rotate (deg/s)", -45, 45, 1, v_u_368.get("orbitAuto"), function(p381)
		-- upvalues: (copy) v_u_368
		v_u_368.set("orbitAuto", p381)
	end)
	local v_u_384 = v256(v367, "Radius (wheel)", 3, 150, 1, v_u_368.get("orbitRadius"), function(p383)
		-- upvalues: (copy) v_u_368
		v_u_368.set("orbitRadius", p383)
	end)
	local v_u_386 = v256(v367, "Height angle", -10, 85, 1, v_u_368.get("orbitPitch"), function(p385)
		-- upvalues: (copy) v_u_368
		v_u_368.set("orbitPitch", p385)
	end)
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_382, (copy) v_u_368, (copy) v_u_384, (copy) v_u_386
		v_u_382.set(v_u_368.get("orbitAuto"))
		v_u_384.set(v_u_368.get("orbitRadius"))
		v_u_386.set(v_u_368.get("orbitPitch"))
	end)
	local v387 = v_u_236(v367, 32)
	local v388, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Around player",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 140,
		["onClick"] = nil,
		["maxTextWidth"] = 128,
		["parent"] = v387,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.setPoint(nil)
		end
	})
	v_u_224[v387] = (v_u_224[v387] or 0) + 1
	v388.LayoutOrder = v_u_224[v387]
	local v390, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Pick point",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 120,
		["onClick"] = nil,
		["maxTextWidth"] = 108,
		["parent"] = v387,
		["onClick"] = function()
			-- upvalues: (copy) v_u_50, (copy) p_u_47
			v_u_50.status("Click a point in the world.")
			p_u_47.pick(function(p389)
				-- upvalues: (ref) p_u_47
				if p389 then
					p_u_47.setPoint(p389)
				end
			end)
		end
	})
	v_u_224[v387] = (v_u_224[v387] or 0) + 1
	v390.LayoutOrder = v_u_224[v387]
	local v_u_391 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v387,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(v_u_15 - 272, 32)
	})
	v_u_391.LayoutOrder = 9
	local function v394()
		-- upvalues: (ref) v_u_391, (copy) p_u_47
		local v392 = v_u_391
		local v393 = p_u_47.point()
		v392.Text = "pt " .. (not v393 and "none" or string.format("%.0f, %.0f, %.0f", v393.X, v393.Y, v393.Z))
	end
	table.insert(v_u_51, v394)
	v228(v367, "Follow")
	local v_u_396 = v276(v367, {
		{
			["id"] = "shoulder",
			["text"] = "Shoulder"
		},
		{
			["id"] = "low",
			["text"] = "Low hero"
		},
		{
			["id"] = "top",
			["text"] = "Top-down"
		}
	}, v_u_368.get("follow"), function(p395)
		-- upvalues: (copy) v_u_368, (copy) p_u_47
		v_u_368.set("follow", p395)
		p_u_47.setCamMode("follow")
	end)
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_396, (copy) v_u_368
		v_u_396(v_u_368.get("follow"))
	end)
	v228(v367, "Dolly")
	local v397 = v_u_236(v367, 32)
	local v399, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Add key",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 100,
		["onClick"] = nil,
		["maxTextWidth"] = 88,
		["parent"] = v397,
		["onClick"] = function()
			-- upvalues: (copy) v_u_368, (copy) v_u_50
			local v398 = v_u_368.addKey()
			v_u_50.status(not v398 and "Six keys max." or "Key " .. v398 .. " / 6 added from the current view.", v398 and "success" or "danger")
		end
	})
	v_u_224[v397] = (v_u_224[v397] or 0) + 1
	v399.LayoutOrder = v_u_224[v397]
	local v400, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Clear",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = 80,
		["onClick"] = nil,
		["maxTextWidth"] = 68,
		["parent"] = v397,
		["onClick"] = function()
			-- upvalues: (copy) v_u_368
			v_u_368.clearKeys()
		end
	})
	v_u_224[v397] = (v_u_224[v397] or 0) + 1
	v400.LayoutOrder = v_u_224[v397]
	local v401, v402 = v_u_7.button({
		["parent"] = nil,
		["text"] = "Play",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = 90,
		["onClick"] = nil,
		["maxTextWidth"] = 78,
		["parent"] = v397,
		["onClick"] = function()
			-- upvalues: (copy) v_u_368, (copy) v_u_50, (copy) p_u_47
			if v_u_368.keys() < 2 then
				v_u_50.status("Add at least two keys.", "danger")
			else
				p_u_47.setCamMode("dolly")
				v_u_368.play()
			end
		end
	})
	v_u_224[v397] = (v_u_224[v397] or 0) + 1
	v401.LayoutOrder = v_u_224[v397]
	local v_u_403 = v402
	local v_u_404 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v397,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(v_u_15 - 288, 32)
	})
	v_u_404.LayoutOrder = 9
	local function v412()
		-- upvalues: (ref) v_u_404, (copy) v_u_368, (copy) v_u_403
		local v405 = v_u_404
		local v406 = string.format
		local v407 = "%d/6 %s"
		local v408 = v_u_368.keys()
		local v409
		if v_u_368.playing() then
			local v410 = string.format
			local v411 = v_u_368.progress() * 100
			v409 = v410("%d%%", (math.floor(v411)))
		else
			v409 = ""
		end
		v405.Text = v406(v407, v408, v409)
		v_u_403.setText(v_u_368.playing() and "Stop" or "Play")
	end
	table.insert(v_u_51, v412)
	local v_u_414 = v256(v367, "Path duration (s)", 2, 30, 0.5, v_u_368.get("dollyTime"), function(p413)
		-- upvalues: (copy) v_u_368
		v_u_368.set("dollyTime", p413)
	end)
	local v416 = {
		["parent"] = nil,
		["label"] = "Loop",
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["value"] = v_u_368.get("dollyLoop"),
		["width"] = v_u_15,
		["onChange"] = function(p415)
			-- upvalues: (copy) v_u_368
			v_u_368.set("dollyLoop", p415)
		end
	}
	local v417, v_u_418 = v_u_7.toggle(v416)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v417.LayoutOrder = v_u_224[v367]
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_414, (copy) v_u_368, (copy) v_u_418
		v_u_414.set(v_u_368.get("dollyTime"))
		v_u_418.set(v_u_368.get("dollyLoop"))
	end)
	v228(v367, "Depth of field")
	local v_u_419 = p_u_47.look
	local v_u_420 = 0.6
	local v_u_421 = 20
	local v423 = {
		["parent"] = nil,
		["label"] = "Focus",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["options"] = {
			{
				["id"] = "off",
				["text"] = "Off"
			},
			{
				["id"] = "player",
				["text"] = "On player"
			},
			{
				["id"] = "point",
				["text"] = "On picked point"
			},
			{
				["id"] = "distance",
				["text"] = "Fixed distance"
			}
		},
		["value"] = v_u_419.dof(),
		["width"] = v_u_15,
		["onChange"] = function(p422)
			-- upvalues: (copy) v_u_419, (ref) v_u_420, (ref) v_u_421
			v_u_419.setDof(p422, v_u_420, v_u_421)
		end
	}
	local v424, v425 = v_u_7.dropdown(v423)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v424.LayoutOrder = v_u_224[v367]
	local v_u_426 = v425
	v256(v367, "Strength", 0, 1, 0.05, v_u_420, function(p427)
		-- upvalues: (ref) v_u_420, (copy) v_u_419, (ref) v_u_421
		v_u_420 = p427
		if v_u_419.dof() ~= "off" then
			v_u_419.setDof(v_u_419.dof(), p427, v_u_421)
		end
	end)
	v256(v367, "Distance", 1, 200, 1, v_u_421, function(p428)
		-- upvalues: (ref) v_u_421, (copy) v_u_419, (ref) v_u_420
		v_u_421 = p428
		if v_u_419.dof() ~= "off" then
			v_u_419.setDof(v_u_419.dof(), v_u_420, p428)
		end
	end)
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_426, (copy) v_u_419
		v_u_426.set(v_u_419.dof())
	end)
	v228(v367, "Look")
	local v429 = {}
	for _, v430 in v_u_419.LOOKS do
		table.insert(v429, {
			["id"] = v430,
			["text"] = v430
		})
	end
	local v432 = {
		["parent"] = nil,
		["label"] = "Grade",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["options"] = v429,
		["value"] = v_u_419.look(),
		["width"] = v_u_15,
		["onChange"] = function(p431)
			-- upvalues: (copy) v_u_419
			v_u_419.setLook(p431)
		end
	}
	local v433, v434 = v_u_7.dropdown(v432)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v433.LayoutOrder = v_u_224[v367]
	local v_u_435 = v434
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_435, (copy) v_u_419
		v_u_435.set(v_u_419.look())
	end)
	local v_u_436 = false
	local v_u_437 = false
	local v439 = {
		["parent"] = nil,
		["label"] = "9:16 safe frame",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["width"] = v_u_15,
		["onChange"] = function(p438)
			-- upvalues: (ref) v_u_436, (copy) v_u_419, (ref) v_u_437
			v_u_436 = p438
			v_u_419.setGuides(v_u_436, v_u_437)
		end
	}
	local v440, v_u_441 = v_u_7.toggle(v439)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v440.LayoutOrder = v_u_224[v367]
	local v443 = {
		["parent"] = nil,
		["label"] = "Rule of thirds",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["width"] = v_u_15,
		["onChange"] = function(p442)
			-- upvalues: (ref) v_u_437, (copy) v_u_419, (ref) v_u_436
			v_u_437 = p442
			v_u_419.setGuides(v_u_436, v_u_437)
		end
	}
	local v444, v_u_445 = v_u_7.toggle(v443)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v444.LayoutOrder = v_u_224[v367]
	function v_u_50.resetGuides()
		-- upvalues: (ref) v_u_436, (ref) v_u_437, (copy) v_u_441, (copy) v_u_445
		v_u_436 = false
		v_u_437 = false
		v_u_441.set(false)
		v_u_445.set(false)
	end
	local v447 = {
		["parent"] = nil,
		["label"] = "Hide own character (local)",
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v367,
		["value"] = p_u_47.charHidden(),
		["width"] = v_u_15,
		["onChange"] = function(p446)
			-- upvalues: (copy) p_u_47
			p_u_47.setCharHidden(p446)
		end
	}
	local v448, v_u_449 = v_u_7.toggle(v447)
	v_u_224[v367] = (v_u_224[v367] or 0) + 1
	v448.LayoutOrder = v_u_224[v367]
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_449, (copy) p_u_47
		v_u_449.set(p_u_47.charHidden())
	end)
	local v450, v451 = pcall(function()
		return require((script.Parent:WaitForChild("FilmSnapshot", 5)))
	end)
	if v450 and v451 then
		local v452 = v451.build
		local v453 = {
			["body"] = v_u_150.camera,
			["api"] = p_u_47,
			["handle"] = v_u_50,
			["inner"] = v_u_15,
			["syncers"] = v_u_51,
			["gui"] = v_u_48
		}
		local v454, v455 = pcall(v452, v453)
		if not v454 then
			warn("[FilmPanel] snapshot section failed:", v455)
		end
	else
		warn("[FilmPanel] FilmSnapshot missing")
	end
	local v456 = v_u_150.spawn
	v228(v456, "Zombies")
	local v_u_457 = "ZombieTypes"
	local function v458()
		-- upvalues: (ref) v_u_6, (copy) v_u_457
		return require((v_u_6:WaitForChild(v_u_457, 5)))
	end
	local v459, v460 = pcall(v458)
	if not v459 then
		v460 = nil
	end
	local v461 = {}
	if v460 then
		local v462 = v460.list
		if type(v462) == "table" then
			for _, v463 in v460.list do
				if type(v463) ~= "table" then
					continue
				end
				local v464 = v463.id
				if type(v464) ~= "string" then
					continue
				end
				local v465 = {
					["id"] = v463.id,
					["text"] = v463.id
				}
				table.insert(v461, v465)
			end
		end
	end
	if #v461 == 0 then
		for _, v466 in {
			"walker",
			"runner",
			"crawler",
			"brute",
			"screamer",
			"listener",
			"hazmat",
			"ringer",
			"riot",
			"boss_surgeon",
			"boss_hale"
		} do
			table.insert(v461, {
				["id"] = v466,
				["text"] = v466
			})
		end
	end
	local v_u_467 = v461[1].id
	local v_u_468 = 6
	local v_u_469 = 10
	local v_u_470 = "frozen"
	local v_u_471 = "player"
	local v473 = {
		["parent"] = nil,
		["label"] = "Type",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v456,
		["options"] = v461,
		["value"] = v_u_467,
		["width"] = v_u_15,
		["onChange"] = function(p472)
			-- upvalues: (ref) v_u_467
			v_u_467 = p472
		end
	}
	local v474, _ = v_u_7.dropdown(v473)
	v_u_224[v456] = (v_u_224[v456] or 0) + 1
	v474.LayoutOrder = v_u_224[v456]
	v256(v456, "Count", 1, 60, 1, v_u_468, function(p475)
		-- upvalues: (ref) v_u_468
		v_u_468 = p475
	end)
	v256(v456, "Radius", 1, 60, 1, v_u_469, function(p476)
		-- upvalues: (ref) v_u_469
		v_u_469 = p476
	end)
	local v478 = {
		["parent"] = nil,
		["label"] = "Mode",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v456,
		["options"] = {
			{
				["id"] = "frozen",
				["text"] = "Frozen (until Action)"
			},
			{
				["id"] = "idle",
				["text"] = "Idle"
			},
			{
				["id"] = "wander",
				["text"] = "Wander"
			},
			{
				["id"] = "hunt",
				["text"] = "Hunt"
			}
		},
		["value"] = v_u_470,
		["width"] = v_u_15,
		["onChange"] = function(p477)
			-- upvalues: (ref) v_u_470
			v_u_470 = p477
		end
	}
	local v479, _ = v_u_7.dropdown(v478)
	v_u_224[v456] = (v_u_224[v456] or 0) + 1
	v479.LayoutOrder = v_u_224[v456]
	local v481 = {
		["parent"] = nil,
		["label"] = "Place",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v456,
		["options"] = {
			{
				["id"] = "player",
				["text"] = "Around me"
			},
			{
				["id"] = "cursor",
				["text"] = "At picked point"
			}
		},
		["value"] = v_u_471,
		["width"] = v_u_15,
		["onChange"] = function(p480)
			-- upvalues: (ref) v_u_471
			v_u_471 = p480
		end
	}
	local v482, _ = v_u_7.dropdown(v481)
	v_u_224[v456] = (v_u_224[v456] or 0) + 1
	v482.LayoutOrder = v_u_224[v456]
	local v483 = v_u_236(v456, 32)
	local v485, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Pick point",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 120,
		["onClick"] = nil,
		["maxTextWidth"] = 108,
		["parent"] = v483,
		["onClick"] = function()
			-- upvalues: (copy) v_u_50, (copy) p_u_47
			v_u_50.status("Click a point in the world.")
			p_u_47.pick(function(p484)
				-- upvalues: (ref) p_u_47
				if p484 then
					p_u_47.setPoint(p484)
				end
			end)
		end
	})
	v_u_224[v483] = (v_u_224[v483] or 0) + 1
	v485.LayoutOrder = v_u_224[v483]
	local v_u_486 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v483,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(v_u_15 - 130, 32)
	})
	v_u_486.LayoutOrder = 9
	local function v489()
		-- upvalues: (ref) v_u_486, (copy) p_u_47
		local v487 = v_u_486
		local v488 = p_u_47.point()
		v487.Text = "pt " .. (not v488 and "none" or string.format("%.0f, %.0f, %.0f", v488.X, v488.Y, v488.Z))
	end
	table.insert(v_u_51, v489)
	local v490 = v_u_236(v456, 32)
	local v491 = v_u_15
	local function v494()
		-- upvalues: (ref) v_u_467, (ref) v_u_468, (ref) v_u_469, (ref) v_u_470, (ref) v_u_471, (copy) p_u_47, (copy) v_u_50
		local v492 = {
			["type"] = v_u_467,
			["count"] = v_u_468,
			["radius"] = v_u_469,
			["mode"] = v_u_470
		}
		if v_u_471 == "cursor" then
			local v493 = p_u_47.point()
			if not v493 then
				v_u_50.status("Pick a point first.", "danger")
				return
			end
			v492.pos = v493
			v492.at = "cursor"
		else
			v492.at = "player"
		end
		p_u_47.call("zombies.spawn", v492)
	end
	local v495, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Spawn",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v490,
		["width"] = v491,
		["onClick"] = v494,
		["maxTextWidth"] = (v491 or 140) - 12
	})
	v_u_224[v490] = (v_u_224[v490] or 0) + 1
	v495.LayoutOrder = v_u_224[v490]
	local v496 = v_u_236(v456, 32)
	local v497 = (v_u_15 - 18) / 4
	local v498 = math.floor(v497)
	local v499, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Freeze",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v496,
		["width"] = v498,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("zombies.freeze", {
				["on"] = true
			})
		end,
		["maxTextWidth"] = (v498 or 140) - 12
	})
	v_u_224[v496] = (v_u_224[v496] or 0) + 1
	v499.LayoutOrder = v_u_224[v496]
	local v500, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Unfreeze",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v496,
		["width"] = v498,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("zombies.freeze", {
				["on"] = false
			})
		end,
		["maxTextWidth"] = (v498 or 140) - 12
	})
	v_u_224[v496] = (v_u_224[v496] or 0) + 1
	v500.LayoutOrder = v_u_224[v496]
	local v501, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Aggro",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v496,
		["width"] = v498,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("zombies.aggro", {
				["radius"] = 80
			})
		end,
		["maxTextWidth"] = (v498 or 140) - 12
	})
	v_u_224[v496] = (v_u_224[v496] or 0) + 1
	v501.LayoutOrder = v_u_224[v496]
	local v502, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Clear",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v496,
		["width"] = v498,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("zombies.clear", {})
		end,
		["maxTextWidth"] = (v498 or 140) - 12
	})
	v_u_224[v496] = (v_u_224[v496] or 0) + 1
	v502.LayoutOrder = v_u_224[v496]
	v_u_232(v456, "Clear removes every zombie of your raid; Aggro sends the zombies within 80 studs at you.")
	local v503 = v_u_150.loot
	v228(v503, "Items")
	local v_u_504 = "Items"
	local function v505()
		-- upvalues: (ref) v_u_6, (copy) v_u_504
		return require((v_u_6:WaitForChild(v_u_504, 5)))
	end
	local v506, v_u_507 = pcall(v505)
	if not v506 then
		v_u_507 = nil
	end
	local v_u_508 = nil
	local function v509()
		-- upvalues: (ref) v_u_508
		v_u_508 = require((script.Parent:WaitForChild("ItemIcons", 5)))
	end
	pcall(v509)
	local v_u_510 = 1
	v_u_232(v503, "Give: in the menu / hideout the item goes into your stash (profile), in a raid into your raid inventory. Drop needs a raid.")
	local v511 = {
		["parent"] = nil,
		["placeholder"] = "Search items (name or id)",
		["width"] = nil,
		["parent"] = v503,
		["width"] = v_u_15
	}
	local v512, v_u_513 = v_u_7.input(v511)
	v_u_224[v503] = (v_u_224[v503] or 0) + 1
	v512.LayoutOrder = v_u_224[v503]
	v256(v503, "Amount", 1, 60, 1, v_u_510, function(p514)
		-- upvalues: (ref) v_u_510
		v_u_510 = p514
	end)
	local v_u_515 = v_u_7.new("Frame", {
		["Name"] = "Results",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v503)
	v_u_7.layout(v_u_515, "v", 4)
	v_u_224[v503] = (v_u_224[v503] or 0) + 1
	v_u_515.LayoutOrder = v_u_224[v503]
	local v_u_516 = {}
	local function v_u_520() -- name: clearRows
		-- upvalues: (ref) v_u_508, (ref) v_u_516, (copy) v_u_515
		if v_u_508 then
			for _, v517 in v_u_516 do
				local v518 = v_u_508.release
				pcall(v518, v517)
			end
		end
		v_u_516 = {}
		for _, v519 in v_u_515:GetChildren() do
			if not v519:IsA("GuiObject") then
				continue
			end
			v519:Destroy()
		end
	end
	local function v_u_549(p521) -- name: search
		-- upvalues: (copy) v_u_520, (copy) v_u_507, (ref) v_u_7, (ref) v_u_9, (copy) v_u_515, (ref) v_u_508, (ref) v_u_516, (copy) p_u_47, (ref) v_u_510, (ref) v_u_11, (copy) v_u_232
		v_u_520()
		local v522 = string.lower(p521 or "")
		if v_u_507 and v_u_507.all then
			local v523 = {}
			for _, v524 in v_u_507.all() do
				local v525 = string.lower
				local v526 = v524.name or ""
				local v527 = v525((tostring(v526)))
				local v528 = string.lower
				local v529 = v524.id
				local v530 = v528((tostring(v529)))
				if v522 ~= "" and not (string.find(v527, v522, 1, true) or string.find(v530, v522, 1, true)) then
					continue
				end
				table.insert(v523, v524)
			end
			table.sort(v523, function(p531, p532)
				local v533 = p531.name
				local v534 = tostring(v533)
				local v535 = p532.name
				return v534 < tostring(v535)
			end)
			local v536 = #v523
			for v537 = 1, math.min(v536, 30) do
				local v_u_538 = v523[v537]
				local v539 = v_u_7.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Item_" .. v_u_538.id,
					["BackgroundColor3"] = v_u_9.raised,
					["Size"] = UDim2.new(1, 0, 0, 48),
					["LayoutOrder"] = v537
				}, v_u_515)
				v_u_7.stroke(v539, v_u_9.line)
				if v_u_508 then
					local v540 = v_u_508.get
					local v541 = v_u_538.id
					local v542 = {
						["parent"] = v539,
						["size"] = UDim2.fromOffset(44, 44),
						["position"] = UDim2.fromOffset(2, 2)
					}
					local v543, v544 = pcall(v540, v541, false, v542)
					if v543 and v544 then
						local v545 = v_u_516
						table.insert(v545, v544)
					end
				end
				local v546 = v_u_7.label
				local v547 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v539
				}
				local v548 = v_u_538.name
				v547.text = tostring(v548)
				v547.position = UDim2.fromOffset(54, 4)
				v547.size = UDim2.new(1, -236, 0, 20)
				v546(v547).TextTruncate = Enum.TextTruncate.AtEnd
				v_u_7.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v539,
					["text"] = v_u_538.id,
					["color"] = v_u_9.muted,
					["position"] = UDim2.fromOffset(54, 24),
					["size"] = UDim2.new(1, -236, 0, 18)
				}).TextTruncate = Enum.TextTruncate.AtEnd
				v_u_7.button({
					["parent"] = nil,
					["text"] = "Drop",
					["kind"] = "secondary",
					["height"] = 30,
					["width"] = 84,
					["maxTextWidth"] = 70,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v539,
					["position"] = UDim2.new(1, -176, 0.5, -15),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_47, (copy) v_u_538, (ref) v_u_510
						p_u_47.call("loot.drop", {
							["id"] = v_u_538.id,
							["n"] = v_u_510
						})
					end
				})
				v_u_7.button({
					["parent"] = nil,
					["text"] = "Give",
					["kind"] = "primary",
					["height"] = 30,
					["width"] = 84,
					["maxTextWidth"] = 70,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v539,
					["position"] = UDim2.new(1, -88, 0.5, -15),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_47, (ref) v_u_11, (copy) v_u_538, (ref) v_u_510
						p_u_47.call(v_u_11:GetAttribute("Place") == "Raid" and "loot.give" or "stash.give", {
							["id"] = v_u_538.id,
							["n"] = v_u_510
						})
					end
				})
			end
			if #v523 > 30 then
				v_u_232(v_u_515, string.format("%d more. Refine the search.", #v523 - 30)).LayoutOrder = 1000
			end
		end
	end
	local function v_u_551(p550)
		-- upvalues: (copy) v_u_549
		v_u_549(p550)
	end
	local v_u_552 = 0
	local v_u_553 = 0.25
	local function v_u_556(p_u_554)
		-- upvalues: (ref) v_u_552, (copy) v_u_553, (copy) v_u_551
		v_u_552 = v_u_552 + 1
		local v_u_555 = v_u_552
		task.delay(v_u_553, function()
			-- upvalues: (copy) v_u_555, (ref) v_u_552, (ref) v_u_551, (copy) p_u_554
			if v_u_555 == v_u_552 then
				v_u_551(p_u_554)
			end
		end)
	end
	v_u_513:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_556, (copy) v_u_513
		v_u_556(v_u_513.Text)
	end)
	function v_u_50.searchLoot(p557)
		-- upvalues: (copy) v_u_513, (copy) v_u_549
		v_u_513.Text = p557
		v_u_549(p557)
	end
	v_u_549("")
	local v558 = v_u_150.world
	v228(v558, "Time")
	local v559 = v_u_236(v558, 32)
	local v560 = (v_u_15 - 12) / 3
	local v561 = math.floor(v560)
	for _, v_u_562 in { "Day", "Dusk", "Night" } do
		local v564, _ = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v559,
			["text"] = v_u_562,
			["width"] = v561,
			["onClick"] = function()
				-- upvalues: (copy) p_u_47, (copy) v_u_562
				local v563 = {
					["value"] = v_u_562
				}
				p_u_47.call("world.time", v563)
			end,
			["maxTextWidth"] = (v561 or 140) - 12
		})
		v_u_224[v559] = (v_u_224[v559] or 0) + 1
		v564.LayoutOrder = v_u_224[v559]
	end
	local function v_u_566(p565)
		-- upvalues: (copy) p_u_47
		p_u_47.call("world.time", {
			["value"] = p565
		})
	end
	local v_u_567 = 0
	local v_u_568 = 0.4
	local function v_u_571(p_u_569)
		-- upvalues: (ref) v_u_567, (copy) v_u_568, (copy) v_u_566
		v_u_567 = v_u_567 + 1
		local v_u_570 = v_u_567
		task.delay(v_u_568, function()
			-- upvalues: (copy) v_u_570, (ref) v_u_567, (ref) v_u_566, (copy) p_u_569
			if v_u_570 == v_u_567 then
				v_u_566(p_u_569)
			end
		end)
	end
	v256(v558, "Hour", 0, 24, 0.25, 14, function(p572)
		-- upvalues: (copy) v_u_571
		v_u_571(p572)
	end, function(p573)
		local v574 = string.format
		local v575 = math.floor(p573) % 24
		local v576 = p573 % 1 * 60 + 0.5
		return v574("%02d:%02d", v575, (math.floor(v576)))
	end)
	v228(v558, "Weather")
	local v578 = {
		["parent"] = nil,
		["label"] = "Weather",
		["options"] = nil,
		["value"] = "clear",
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v558,
		["options"] = {
			{
				["id"] = "clear",
				["text"] = "Clear"
			},
			{
				["id"] = "rain",
				["text"] = "Rain"
			},
			{
				["id"] = "storm",
				["text"] = "Storm"
			},
			{
				["id"] = "fog",
				["text"] = "Fog"
			}
		},
		["width"] = v_u_15,
		["onChange"] = function(p577)
			-- upvalues: (copy) p_u_47
			p_u_47.call("world.weather", {
				["value"] = p577
			})
		end
	}
	local v579, _ = v_u_7.dropdown(v578)
	v_u_224[v558] = (v_u_224[v558] or 0) + 1
	v579.LayoutOrder = v_u_224[v558]
	v228(v558, "Events")
	local v580 = v_u_236(v558, 32)
	local v581 = (v_u_15 - 24) / 5
	local v582 = math.floor(v581)
	for _, v_u_583 in {
		{ "airdrop", "Airdrop" },
		{ "heli", "Heli" },
		{ "horde", "Horde" },
		{ "ring", "Ring" },
		{ "flare", "Flare" }
	} do
		local v584 = v_u_583[2]
		local v585, _ = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v580,
			["text"] = v584,
			["width"] = v582,
			["onClick"] = function()
				-- upvalues: (copy) p_u_47, (copy) v_u_583
				p_u_47.call("event.fire", {
					["kind"] = v_u_583[1]
				})
			end,
			["maxTextWidth"] = (v582 or 140) - 12
		})
		v_u_224[v580] = (v_u_224[v580] or 0) + 1
		v585.LayoutOrder = v_u_224[v580]
	end
	local v586 = v_u_236(v558, 32)
	local v587 = (v_u_15 - 6) / 2
	local v588 = math.floor(v587)
	for _, v_u_589 in {
		{ "evac", "Evac heli" },
		{ "school", "School horde" }
	} do
		local v590 = v_u_589[2]
		local v591, _ = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v586,
			["text"] = v590,
			["width"] = v588,
			["onClick"] = function()
				-- upvalues: (copy) p_u_47, (copy) v_u_589
				p_u_47.call("event.fire", {
					["kind"] = v_u_589[1]
				})
			end,
			["maxTextWidth"] = (v588 or 140) - 12
		})
		v_u_224[v586] = (v_u_224[v586] or 0) + 1
		v591.LayoutOrder = v_u_224[v586]
	end
	v228(v558, "Player")
	local v593 = {
		["parent"] = nil,
		["label"] = "God mode",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v558,
		["width"] = v_u_15,
		["onChange"] = function(p592)
			-- upvalues: (copy) p_u_47
			p_u_47.call("player.god", {
				["on"] = p592
			})
		end
	}
	local v594, _ = v_u_7.toggle(v593)
	v_u_224[v558] = (v_u_224[v558] or 0) + 1
	v594.LayoutOrder = v_u_224[v558]
	local v595 = v_u_236(v558, 32)
	local v596, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Heal",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v595,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47
			p_u_47.call("player.heal", {})
		end
	})
	v_u_224[v595] = (v_u_224[v595] or 0) + 1
	v596.LayoutOrder = v_u_224[v595]
	local v598 = {
		["parent"] = nil,
		["label"] = "Hide own character (local)",
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v558,
		["value"] = p_u_47.charHidden(),
		["width"] = v_u_15,
		["onChange"] = function(p597)
			-- upvalues: (copy) p_u_47
			p_u_47.setCharHidden(p597)
		end
	}
	local v599, v600 = v_u_7.toggle(v598)
	v_u_224[v558] = (v_u_224[v558] or 0) + 1
	v599.LayoutOrder = v_u_224[v558]
	local v_u_601 = v600
	table.insert(v_u_51, function()
		-- upvalues: (copy) v_u_601, (copy) p_u_47
		v_u_601.set(p_u_47.charHidden())
	end)
	v228(v558, "Teleport")
	local v_u_602 = v_u_7.new("Frame", {
		["Name"] = "Tp",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v558)
	v_u_7.layout(v_u_602, "v", 6)
	v_u_224[v558] = (v_u_224[v558] or 0) + 1
	v_u_602.LayoutOrder = v_u_224[v558]
	local v_u_603 = nil
	local function v_u_621(p604) -- name: buildTp
		-- upvalues: (copy) v_u_602, (copy) v_u_224, (copy) v_u_232, (ref) v_u_603, (ref) v_u_7, (ref) v_u_15, (copy) v_u_236, (copy) p_u_47, (copy) v_u_50
		for _, v605 in v_u_602:GetChildren() do
			if not v605:IsA("GuiObject") then
				continue
			end
			v605:Destroy()
		end
		v_u_224[v_u_602] = 0
		local v606 = {}
		for _, v607 in p604 do
			table.insert(v606, {
				["id"] = v607,
				["text"] = v607
			})
		end
		if #v606 == 0 then
			v_u_232(v_u_602, "No landmarks (press Refresh inside a raid).")
		else
			v_u_603 = v606[1].id
			local v608 = v_u_602
			local v610 = {
				["parent"] = nil,
				["label"] = "Landmark",
				["options"] = nil,
				["value"] = nil,
				["width"] = nil,
				["onChange"] = nil,
				["parent"] = v608,
				["options"] = v606,
				["value"] = v_u_603,
				["width"] = v_u_15,
				["onChange"] = function(p609)
					-- upvalues: (ref) v_u_603
					v_u_603 = p609
				end
			}
			local v611, _ = v_u_7.dropdown(v610)
			v_u_224[v608] = (v_u_224[v608] or 0) + 1
			v611.LayoutOrder = v_u_224[v608]
		end
		local v612 = v_u_236(v_u_602, 32)
		local v614 = {
			["parent"] = nil,
			["text"] = "Teleport",
			["kind"] = "primary",
			["height"] = 32,
			["width"] = 130,
			["onClick"] = nil,
			["maxTextWidth"] = 118,
			["parent"] = v612,
			["onClick"] = function()
				-- upvalues: (ref) v_u_603, (ref) p_u_47
				if v_u_603 then
					local v613 = {
						["landmark"] = v_u_603
					}
					p_u_47.call("player.tp", v613)
				end
			end
		}
		local v615, _ = v_u_7.button(v614)
		v_u_224[v612] = (v_u_224[v612] or 0) + 1
		v615.LayoutOrder = v_u_224[v612]
		local v617 = {
			["parent"] = nil,
			["text"] = "To point",
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = 110,
			["onClick"] = nil,
			["maxTextWidth"] = 98,
			["parent"] = v612,
			["onClick"] = function()
				-- upvalues: (ref) p_u_47, (ref) v_u_50
				local v616 = p_u_47.point()
				if v616 then
					p_u_47.call("player.tp", {
						["pos"] = v616
					})
				else
					v_u_50.status("Pick a point first.", "danger")
				end
			end
		}
		local v618, _ = v_u_7.button(v617)
		v_u_224[v612] = (v_u_224[v612] or 0) + 1
		v618.LayoutOrder = v_u_224[v612]
		local v619 = {
			["parent"] = nil,
			["text"] = "Refresh",
			["kind"] = "ghost",
			["height"] = 32,
			["width"] = 100,
			["onClick"] = nil,
			["maxTextWidth"] = 88,
			["parent"] = v612,
			["onClick"] = function()
				-- upvalues: (ref) v_u_50
				v_u_50.refreshLandmarks()
			end
		}
		local v620, _ = v_u_7.button(v619)
		v_u_224[v612] = (v_u_224[v612] or 0) + 1
		v620.LayoutOrder = v_u_224[v612]
	end
	function v_u_50.refreshLandmarks() -- name: refreshLandmarks
		-- upvalues: (copy) p_u_47, (copy) v_u_621
		p_u_47.call("player.landmarks", {}, function(p622)
			-- upvalues: (ref) v_u_621
			if p622 and p622.ok then
				local v623 = p622.data
				if type(v623) == "table" then
					local v624 = {}
					for _, v625 in p622.data do
						local v626
						if type(v625) == "table" then
							local v627 = v625.name or v625.id
							v626 = tostring(v627)
						else
							v626 = tostring(v625)
						end
						table.insert(v624, v626)
					end
					v_u_621(v624)
				end
			end
		end)
	end
	v_u_621({})
	local v_u_628 = v_u_150.raid
	local v_u_629 = true
	local v_u_630 = nil
	local v_u_631 = {}
	local v_u_632 = true
	v_u_48.Destroying:Connect(function()
		-- upvalues: (ref) v_u_632
		v_u_632 = false
	end)
	local function v_u_637(p633) -- name: mss
		local v634 = p633 + 0.5
		local v635 = math.floor(v634)
		local v636 = math.max(0, v635)
		return string.format("%d:%02d", v636 // 60, v636 % 60)
	end
	local function v_u_643(p638) -- name: parseTime
		local v639 = string.gsub(p638 or "", "%s", "")
		local v640, v641 = string.match(v639, "^(%d+):(%d%d?)$")
		if v640 and v641 then
			return tonumber(v640) * 60 + tonumber(v641)
		else
			local v642 = tonumber(v639)
			if v642 and (v642 >= 0 and v642 == v642) then
				return v642
			else
				return nil
			end
		end
	end
	local function v_u_647() -- name: timeLeft
		-- upvalues: (ref) v_u_5, (ref) v_u_1
		local v644 = v_u_5:FindFirstChild("HushRuntime")
		if v644 then
			v644 = v644:FindFirstChild("Raid")
		end
		if not v644 or v644:GetAttribute("Phase") ~= "Running" then
			return nil
		end
		local v645 = v644:GetAttribute("EndsAt")
		if type(v645) ~= "number" then
			return nil
		end
		local v646 = v645 - v_u_1.now()
		return math.max(0, v646)
	end
	local v648, v649 = pcall(function()
		return require((script.Parent:WaitForChild("FilmHuntSw", 5)))
	end)
	if v648 and v649 then
		local v650 = v649.mount
		local v651 = v_u_150.server
		local v652 = p_u_47.call
		local v653 = v_u_8
		local v655 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v654 = v_u_150.server
				v_u_224[v654] = (v_u_224[v654] or 0) + 1
				return v_u_224[v654]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v656, v657 = pcall(v650, v651, v652, v653, v655)
		if not v656 then
			warn("[FilmPanel] hunt switch section failed:", v657)
		end
	end
	local v658, v659 = pcall(function()
		return require((script.Parent:WaitForChild("FilmTreeSw", 5)))
	end)
	if v658 and v659 then
		local v660 = v659.mount
		local v661 = v_u_150.server
		local v662 = p_u_47.call
		local v663 = v_u_8
		local v665 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v664 = v_u_150.server
				v_u_224[v664] = (v_u_224[v664] or 0) + 1
				return v_u_224[v664]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v666, v667 = pcall(v660, v661, v662, v663, v665)
		if not v666 then
			warn("[FilmPanel] skill tree section failed:", v667)
		end
	end
	local v668, v669 = pcall(function()
		return require((script.Parent:WaitForChild("FilmVehSw", 5)))
	end)
	if v668 and v669 then
		local v670 = v669.mount
		local v671 = v_u_150.server
		local v672 = p_u_47.call
		local v673 = v_u_8
		local v675 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v674 = v_u_150.server
				v_u_224[v674] = (v_u_224[v674] or 0) + 1
				return v_u_224[v674]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v676, v677 = pcall(v670, v671, v672, v673, v675)
		if not v676 then
			warn("[FilmPanel] vehicle switch section failed:", v677)
		end
	end
	local v678, v679 = pcall(function()
		return require((script.Parent:WaitForChild("FilmSeasonWin", 5)))
	end)
	if v678 and v679 then
		local v680 = v679.mount
		local v681 = v_u_150.server
		local v682 = p_u_47.call
		local v683 = v_u_8
		local v685 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v684 = v_u_150.server
				v_u_224[v684] = (v_u_224[v684] or 0) + 1
				return v_u_224[v684]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v686, v687 = pcall(v680, v681, v682, v683, v685)
		if not v686 then
			warn("[FilmPanel] season window section failed:", v687)
		end
	end
	local v_u_688 = v_u_150.server
	local v_u_689 = v_u_5:FindFirstChild("Config")
	local v_u_690 = nil
	local function v_u_705(p691) -- name: parseReopen
		local v692 = string.gsub(p691 or "", "%s", "")
		if v692 == "" then
			return nil
		end
		local v693, v694 = string.match(v692, "^(%d%d?)[:%.](%d%d)$")
		local v695 = tonumber(v693)
		local v696 = tonumber(v694)
		if not v695 or (not v696 or (v695 > 23 or v696 > 59)) then
			return false
		end
		local v697 = os.time()
		local v698 = os.date("*t", v697)
		local v699 = v698.hour
		local v700 = (tonumber(v699) or 0) * 3600
		local v701 = v698.min
		local v702 = v700 + (tonumber(v701) or 0) * 60
		local v703 = v698.sec
		local v704 = v697 - (v702 + (tonumber(v703) or 0)) + v695 * 3600 + v696 * 60
		if v704 <= v697 + 30 then
			v704 = v704 + 86400
		end
		return v704
	end
	local function v_u_717(p706) -- name: parseDur
		local v707 = string.lower((string.gsub(p706 or "", "%s", "")))
		if v707 == "" then
			return nil
		else
			local v708, v709 = string.match(v707, "^(%d+):(%d%d)$")
			if v708 and v709 then
				local v710 = tonumber(v709)
				if v710 < 60 then
					return tonumber(v708) * 3600 + v710 * 60
				else
					return false
				end
			else
				local v711, v712 = string.match(v707, "^(%d+)h(%d*)m?$")
				if v711 then
					local v713 = v712 == "" and 0 or tonumber(v712)
					if v713 < 60 then
						return tonumber(v711) * 3600 + v713 * 60
					else
						return false
					end
				else
					local v714 = string.match(v707, "^(%d+)min$") or string.match(v707, "^(%d+)m$")
					if v714 then
						return tonumber(v714) * 60
					end
					local v715 = tonumber(v707)
					if not v715 or (v715 ~= v715 or v715 < 0) then
						return false
					end
					local v716 = v715 * 3600 + 0.5
					return math.floor(v716)
				end
			end
		end
	end
	local function v_u_722(p718) -- name: durText
		local v719 = p718 + 0.5
		local v720 = math.floor(v719)
		local v721 = math.max(0, v720)
		return ("%d:%02d"):format(v721 // 3600, v721 % 3600 // 60)
	end
	v228(v_u_688, "Deployments  \194\183  all lobby servers")
	local v723 = v_u_236(v_u_688, 30)
	local v_u_724 = v_u_7.label({
		["parent"] = nil,
		["name"] = "DeployState",
		["text"] = "...",
		["style"] = "monoL",
		["size"] = nil,
		["parent"] = v723,
		["size"] = UDim2.fromOffset(150, 30)
	})
	v_u_724.LayoutOrder = 1
	local v_u_725 = v_u_7.label({
		["parent"] = nil,
		["name"] = "DeployCount",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["parent"] = v723,
		["color"] = v_u_9.text2,
		["size"] = UDim2.fromOffset(v_u_15 - 156, 30)
	})
	v_u_725.LayoutOrder = 2
	v_u_725.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_726 = v_u_232(v_u_688, "")
	v_u_726.Name = "DeployWho"
	local v727, v_u_728 = v_u_7.input({
		["parent"] = nil,
		["name"] = "DeployMsg",
		["size"] = nil,
		["placeholder"] = "Banner text (optional, empty = standard text)",
		["maxLength"] = 120,
		["parent"] = v_u_688,
		["size"] = UDim2.new(1, 0, 0, 36)
	})
	v_u_224[v_u_688] = (v_u_224[v_u_688] or 0) + 1
	v727.LayoutOrder = v_u_224[v_u_688]
	local v729 = v_u_236(v_u_688, 36)
	local v730, v_u_731 = v_u_7.input({
		["parent"] = nil,
		["name"] = "DeployReopen",
		["width"] = 96,
		["placeholder"] = "hh:mm",
		["parent"] = v729
	})
	v_u_224[v729] = (v_u_224[v729] or 0) + 1
	v730.LayoutOrder = v_u_224[v729]
	local v732 = (v_u_15 - 96 - 24) / 4
	local v733 = math.floor(v732)
	local v_u_734 = nil
	local v738, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "None",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v729,
		["width"] = v733,
		["onClick"] = function()
			-- upvalues: (copy) v_u_731, (copy) v_u_734
			local v735 = v_u_731
			local v736
			if v_u_734 then
				local v737 = os.time() + v_u_734 * 60
				v736 = os.date("%H:%M", v737)
			else
				v736 = ""
			end
			v735.Text = v736
		end,
		["maxTextWidth"] = (v733 or 140) - 12
	})
	v_u_224[v729] = (v_u_224[v729] or 0) + 1
	v738.LayoutOrder = v_u_224[v729]
	local v_u_739 = 30
	local v743, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "+30 min",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v729,
		["width"] = v733,
		["onClick"] = function()
			-- upvalues: (copy) v_u_731, (copy) v_u_739
			local v740 = v_u_731
			local v741
			if v_u_739 then
				local v742 = os.time() + v_u_739 * 60
				v741 = os.date("%H:%M", v742)
			else
				v741 = ""
			end
			v740.Text = v741
		end,
		["maxTextWidth"] = (v733 or 140) - 12
	})
	v_u_224[v729] = (v_u_224[v729] or 0) + 1
	v743.LayoutOrder = v_u_224[v729]
	local v_u_744 = 60
	local v748, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "+1 h",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v729,
		["width"] = v733,
		["onClick"] = function()
			-- upvalues: (copy) v_u_731, (copy) v_u_744
			local v745 = v_u_731
			local v746
			if v_u_744 then
				local v747 = os.time() + v_u_744 * 60
				v746 = os.date("%H:%M", v747)
			else
				v746 = ""
			end
			v745.Text = v746
		end,
		["maxTextWidth"] = (v733 or 140) - 12
	})
	v_u_224[v729] = (v_u_224[v729] or 0) + 1
	v748.LayoutOrder = v_u_224[v729]
	local v_u_749 = 120
	local v753, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "+2 h",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v729,
		["width"] = v733,
		["onClick"] = function()
			-- upvalues: (copy) v_u_731, (copy) v_u_749
			local v750 = v_u_731
			local v751
			if v_u_749 then
				local v752 = os.time() + v_u_749 * 60
				v751 = os.date("%H:%M", v752)
			else
				v751 = ""
			end
			v750.Text = v751
		end,
		["maxTextWidth"] = (v733 or 140) - 12
	})
	v_u_224[v729] = (v_u_224[v729] or 0) + 1
	v753.LayoutOrder = v_u_224[v729]
	local v_u_754 = nil
	local function v_u_781() -- name: paintDeploy
		-- upvalues: (copy) v_u_689, (copy) v_u_724, (ref) v_u_9, (ref) v_u_690, (copy) v_u_726, (copy) v_u_725, (ref) v_u_11, (ref) v_u_754
		local v755
		if v_u_689 == nil then
			v755 = false
		else
			v755 = v_u_689:GetAttribute("DeployClosed") == true
		end
		v_u_724.Text = v755 and "CLOSED" or "OPEN"
		local v756 = v_u_724
		local v757
		if v755 then
			v757 = v_u_9.danger
		else
			v757 = v_u_9.success
		end
		v756.TextColor3 = v757
		local v758 = v_u_690
		if v758 then
			v758 = v_u_690.state
		end
		local v759
		if v_u_689 then
			local v760 = v_u_689:GetAttribute("DeployBy")
			local v761 = v_u_689
			local v762 = tonumber(v761:GetAttribute("DeployAt")) or 0
			local v763 = v_u_689
			local v764 = tonumber(v763:GetAttribute("DeployReopenAt")) or 0
			if v762 > 0 then
				local v765 = v760 == "" and "?" or v760
				v759 = ("%s by %s at %s"):format(v755 and "Closed" or "Opened", tostring(v765), (os.date("%H:%M", v762)))
			else
				v759 = "Never switched (open)."
			end
			if v755 and v764 > 0 then
				local v766 = v764 - os.time()
				local v767 = math.max(0, v766)
				v759 = v759 .. ("  \194\183  reopens %s (in %d:%02d)"):format(os.date("%H:%M", v764), v767 // 3600, v767 % 3600 // 60)
			elseif not v755 and (v758 and (v758.stored == true and v758.reopenAt)) then
				local v768 = v758.reopenAt
				v759 = v759 .. ("  \194\183  reopened automatically at %s"):format((os.date("%H:%M", v768)))
			end
		else
			v759 = ""
		end
		v_u_726.Text = v759
		if v_u_690 then
			local v769 = v_u_725
			local v770 = v_u_690.confirmed
			local v771 = tonumber(v770) or 0
			local v772 = v_u_690.servers
			local v773 = tonumber(v772) or 0
			local v774 = v_u_690.searching
			v769.Text = ("Lobbies %d / %d confirmed  \194\183  searching %d"):format(v771, v773, tonumber(v774) or 0)
			local v775 = v_u_11
			local v776 = v_u_690.confirmed
			local v777 = tonumber(v776) or 0
			local v778 = v_u_690.servers
			local v779 = tonumber(v778) or 0
			local v780 = v_u_690.searching
			v775:SetAttribute("FilmDeploy", ("%s|%d/%d|%d"):format(v755 and "CLOSED" or "OPEN", v777, v779, tonumber(v780) or 0))
		else
			v_u_725.Text = "Lobbies ..."
		end
		if v_u_754 then
			v_u_754.setText(v755 and "Open deployments" or "Close deployments")
			v_u_754.setKind(v755 and "primary" or "danger")
		end
	end
	local function v_u_784() -- name: fetchStatus
		-- upvalues: (copy) p_u_47, (ref) v_u_690, (ref) v_u_781
		p_u_47.callQuiet("server.status", {}, function(p782)
			-- upvalues: (ref) v_u_690, (ref) v_u_781
			if p782 and p782.ok then
				local v783 = p782.data
				if type(v783) == "table" then
					v_u_690 = p782.data
				end
			end
			v_u_781()
		end)
	end
	local v785 = v_u_15
	local function v792()
		-- upvalues: (copy) v_u_689, (copy) v_u_728, (copy) v_u_705, (copy) v_u_731, (copy) v_u_50, (copy) p_u_47, (ref) v_u_690, (ref) v_u_781, (copy) v_u_784
		local v786
		if v_u_689 == nil then
			v786 = false
		else
			v786 = v_u_689:GetAttribute("DeployClosed") == true
		end
		local v787 = not v786
		local v788 = {
			["closed"] = v787
		}
		if v787 then
			v788.msg = v_u_728.Text
			local v789 = v_u_705(v_u_731.Text)
			if v789 == false then
				v_u_50.status("Reopen time: hh:mm (your local time) or empty.", "danger")
				return
			end
			v788.reopenAt = v789
		end
		p_u_47.call("server.deploy", v788, function(p790)
			-- upvalues: (ref) v_u_690, (ref) v_u_781, (ref) v_u_784
			if p790 and p790.ok then
				local v791 = p790.data
				if type(v791) == "table" then
					v_u_690 = p790.data
				end
			end
			v_u_781()
			task.delay(2, v_u_784)
		end)
	end
	local v793, v794 = v_u_7.button({
		["parent"] = nil,
		["text"] = "Close deployments",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v_u_688,
		["width"] = v785,
		["onClick"] = v792,
		["maxTextWidth"] = (v785 or 140) - 12
	})
	v_u_224[v_u_688] = (v_u_224[v_u_688] or 0) + 1
	v793.LayoutOrder = v_u_224[v_u_688]
	v_u_754 = v794
	v793.Name = "DeployToggle"
	v_u_232(v_u_688, "Closed: no new raids on any lobby server (squads, solo, tutorial), running searches are cancelled, everything else in the squad menu keeps working. Raids in progress finish normally.")
	v228(v_u_688, "Planned closure  \194\183  all lobby servers")
	local v_u_795 = v_u_232(v_u_688, "No closure planned.")
	v_u_795.Name = "DeployPlan"
	local function v800(p796, p797, p798) -- name: rowLabel
		-- upvalues: (ref) v_u_7, (ref) v_u_9, (copy) v_u_224
		local v799 = v_u_7.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p796,
			["text"] = p797,
			["color"] = v_u_9.text2,
			["size"] = UDim2.fromOffset(p798, 36)
		})
		v799.TextYAlignment = Enum.TextYAlignment.Center
		v799.TextTruncate = Enum.TextTruncate.AtEnd
		v_u_224[p796] = (v_u_224[p796] or 0) + 1
		v799.LayoutOrder = v_u_224[p796]
		return v799
	end
	local v801 = v_u_236(v_u_688, 36)
	v801.Name = "PlanWhen"
	v800(v801, "Close in", 70)
	local v802, v_u_803 = v_u_7.input({
		["parent"] = nil,
		["name"] = "PlanIn",
		["width"] = 84,
		["placeholder"] = "h:mm",
		["parent"] = v801
	})
	v_u_224[v801] = (v_u_224[v801] or 0) + 1
	v802.LayoutOrder = v_u_224[v801]
	v800(v801, "or at", 40)
	local v804, v_u_805 = v_u_7.input({
		["parent"] = nil,
		["name"] = "PlanAt",
		["width"] = 84,
		["placeholder"] = "hh:mm",
		["parent"] = v801
	})
	v_u_224[v801] = (v_u_224[v801] or 0) + 1
	v804.LayoutOrder = v_u_224[v801]
	local v806 = (v_u_15 - 70 - 84 - 40 - 84 - 30) / 2
	local v807 = math.floor(v806)
	for _, v_u_808 in { 1, 2 } do
		local v809 = ("+%d h"):format(v_u_808)
		local v810, _ = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "ghost",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v801,
			["text"] = v809,
			["width"] = v807,
			["onClick"] = function()
				-- upvalues: (copy) v_u_803, (copy) v_u_808, (copy) v_u_805
				v_u_803.Text = ("%d:00"):format(v_u_808)
				v_u_805.Text = ""
			end,
			["maxTextWidth"] = (v807 or 140) - 12
		})
		v_u_224[v801] = (v_u_224[v801] or 0) + 1
		v810.LayoutOrder = v_u_224[v801]
	end
	v_u_803:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_803, (copy) v_u_805
		if v_u_803.Text ~= "" and (v_u_805.Text ~= "" and v_u_803:IsFocused()) then
			v_u_805.Text = ""
		end
	end)
	v_u_805:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_805, (copy) v_u_803
		if v_u_805.Text ~= "" and (v_u_803.Text ~= "" and v_u_805:IsFocused()) then
			v_u_803.Text = ""
		end
	end)
	local v811 = v_u_236(v_u_688, 36)
	v811.Name = "PlanDuration"
	v800(v811, "Closed for", 70)
	local v812, v_u_813 = v_u_7.input({
		["parent"] = nil,
		["name"] = "PlanFor",
		["width"] = 84,
		["placeholder"] = "h:mm",
		["parent"] = v811
	})
	v_u_224[v811] = (v_u_224[v811] or 0) + 1
	v812.LayoutOrder = v_u_224[v811]
	v800(v811, "empty = until opened by hand", v_u_15 - 70 - 84 - 12)
	local function v_u_821() -- name: planNow
		-- upvalues: (copy) v_u_689, (ref) v_u_690
		local v814
		if v_u_689 then
			local v815 = v_u_689
			v814 = tonumber(v815:GetAttribute("DeployCloseAt")) or 0
		else
			v814 = 0
		end
		local v816
		if v_u_689 then
			local v817 = v_u_689
			v816 = tonumber(v817:GetAttribute("DeployPlanReopenAt")) or 0
		else
			v816 = 0
		end
		local v818 = v_u_690
		if v818 then
			v818 = v_u_690.state
		end
		if (v814 or 0) <= 0 and (type(v818) == "table" and v818.planned == true) then
			local v819 = v818.closeAt
			v814 = tonumber(v819) or 0
			local v820 = v818.reopenAt
			v816 = tonumber(v820) or 0
		end
		return v814 or 0, v816 or 0
	end
	local function v_u_840() -- name: paintPlan
		-- upvalues: (copy) v_u_821, (copy) v_u_795, (ref) v_u_9, (ref) v_u_11, (copy) v_u_722, (copy) v_u_689, (copy) v_u_726, (ref) v_u_690
		local v822, v823 = v_u_821()
		if v822 <= 0 or v822 <= os.time() - 2 then
			v_u_795.Text = "No closure planned."
			v_u_795.TextColor3 = v_u_9.text2
			v_u_11:SetAttribute("FilmDeployPlan", "")
		else
			v_u_795.Text = ("Plan: closes %s (in %s)"):format(os.date("%H:%M", v822), v_u_722(v822 - os.time())) .. (v823 <= 0 and ", stays closed until opened by hand" or (", reopens %s"):format((os.date("%H:%M", v823))))
			v_u_795.TextColor3 = v_u_9.accent
			v_u_11:SetAttribute("FilmDeployPlan", ("%d|%d"):format(v822, v823))
			local v824 = v_u_689
			if v824 then
				v824 = v_u_689:GetAttribute("DeployBy")
			end
			local v825
			if v_u_689 then
				local v826 = v_u_689
				v825 = tonumber(v826:GetAttribute("DeployAt")) or 0
			else
				v825 = 0
			end
			local v827
			if v_u_689 == nil then
				v827 = false
			else
				v827 = v_u_689:GetAttribute("DeployClosed") == true
			end
			if not v827 and (v825 and v825 > 0) then
				local v828 = v_u_726
				local v829 = (not v824 or v824 == "") and "?" or v824
				v828.Text = ("Open  \194\183  closure planned by %s at %s"):format(tostring(v829), (os.date("%H:%M", v825)))
			end
		end
		local v830 = v_u_690
		if v830 then
			v830 = v_u_690.state
		end
		local v831
		if v_u_689 == nil then
			v831 = false
		else
			v831 = v_u_689:GetAttribute("DeployClosed") == true
		end
		if v831 and (type(v830) == "table" and v830.stored == false) then
			local v832 = v830.closeAt
			if tonumber(v832) then
				local v833 = v830.reopenAt
				local v834 = tonumber(v833) or 0
				local v835 = v_u_726
				local v836 = v830.byName or "?"
				local v837 = tostring(v836)
				local v838 = v830.closeAt
				local v839 = tonumber(v838)
				v835.Text = ("Closed by the plan of %s at %s"):format(v837, (os.date("%H:%M", v839))) .. (v834 <= 0 and "  \194\183  until opened by hand" or ("  \194\183  reopens %s (in %s)"):format(os.date("%H:%M", v834), v_u_722(v834 - os.time())))
			end
		end
	end
	local v841 = v_u_236(v_u_688, 32)
	v841.Name = "PlanButtons"
	local v842 = (v_u_15 - 6) / 2
	local v843 = math.floor(v842)
	local v851, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Schedule closure",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v841,
		["width"] = v843,
		["onClick"] = function()
			-- upvalues: (copy) v_u_717, (copy) v_u_803, (copy) v_u_705, (copy) v_u_805, (copy) v_u_50, (copy) v_u_728, (copy) v_u_813, (copy) p_u_47, (ref) v_u_690, (ref) v_u_781, (copy) v_u_784
			local v844 = nil
			local v845 = v_u_717(v_u_803.Text)
			local v846 = v_u_705(v_u_805.Text)
			if v845 == false then
				v_u_50.status("Close in: h:mm, 2h, 45m or empty.", "danger")
				return
			elseif v846 == false then
				v_u_50.status("Close at: hh:mm (your local time) or empty.", "danger")
				return
			else
				if type(v845) == "number" then
					v846 = os.time() + v845
				elseif type(v846) ~= "number" then
					v846 = v844
				end
				if v846 then
					local v847 = {
						["closeAt"] = v846,
						["msg"] = v_u_728.Text
					}
					local v848 = v_u_717(v_u_813.Text)
					if v848 == false then
						v_u_50.status("Closed for: h:mm, 2h, 45m or empty.", "danger")
					else
						if type(v848) == "number" and v848 > 0 then
							v847.reopenAt = v846 + v848
						end
						p_u_47.call("server.plan", v847, function(p849)
							-- upvalues: (ref) v_u_690, (ref) v_u_781, (ref) v_u_784
							if p849 and p849.ok then
								local v850 = p849.data
								if type(v850) == "table" then
									v_u_690 = p849.data
								end
							end
							v_u_781()
							task.delay(2, v_u_784)
						end)
					end
				else
					v_u_50.status("Enter when to close: Close in (h:mm) or a clock time.", "danger")
					return
				end
			end
		end,
		["maxTextWidth"] = (v843 or 140) - 12
	})
	v_u_224[v841] = (v_u_224[v841] or 0) + 1
	v851.LayoutOrder = v_u_224[v841]
	v851.Name = "PlanSchedule"
	local v854, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Cancel plan",
		["kind"] = "ghost",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v841,
		["width"] = v843,
		["onClick"] = function()
			-- upvalues: (copy) p_u_47, (ref) v_u_690, (ref) v_u_781
			p_u_47.call("server.plan", {
				["cancel"] = true
			}, function(p852)
				-- upvalues: (ref) v_u_690, (ref) v_u_781
				if p852 and p852.ok then
					local v853 = p852.data
					if type(v853) == "table" then
						v_u_690 = p852.data
					end
				end
				v_u_781()
			end)
		end,
		["maxTextWidth"] = (v843 or 140) - 12
	})
	v_u_224[v841] = (v_u_224[v841] or 0) + 1
	v854.LayoutOrder = v_u_224[v841]
	v854.Name = "PlanCancel"
	v_u_232(v_u_688, "Close in counts from now; or give a clock time (your local time). Stored for every lobby server: it runs on time even when you leave or every lobby restarts. Players see the planned closure in the menu. The banner text above is used for it too.")
	v_u_781 = function()
		-- upvalues: (copy) v_u_781, (copy) v_u_840
		v_u_781()
		v_u_840()
	end
	if v_u_689 then
		for _, v855 in {
			"DeployClosed",
			"DeployAt",
			"DeployBy",
			"DeployReopenAt",
			"DeployCloseAt",
			"DeployPlanReopenAt"
		} do
			local v_u_856 = v_u_689:GetAttributeChangedSignal(v855):Connect(v_u_781)
			v_u_48.Destroying:Connect(function()
				-- upvalues: (copy) v_u_856
				v_u_856:Disconnect()
			end)
		end
	end
	local v857 = v_u_781
	table.insert(v_u_51, v857)
	task.spawn(function()
		-- upvalues: (ref) v_u_632, (copy) v_u_48, (copy) v_u_688, (copy) p_u_47, (ref) v_u_690, (ref) v_u_781
		local v858 = false
		local v859 = 0
		while v_u_632 do
			local v860 = v_u_48.Enabled
			if v860 then
				v860 = v_u_688.Visible
			end
			if v860 and (not v858 or os.clock() - v859 >= 2) then
				v859 = os.clock()
				p_u_47.callQuiet("server.status", {}, function(p861)
					-- upvalues: (ref) v_u_690, (ref) v_u_781
					if p861 and p861.ok then
						local v862 = p861.data
						if type(v862) == "table" then
							v_u_690 = p861.data
						end
					end
					v_u_781()
				end)
			end
			task.wait(0.25)
			v858 = v860
		end
	end)
	v_u_781()
	local v_u_863 = v_u_150.server
	local v_u_864 = v_u_5:FindFirstChild("Config")
	local v_u_865 = "Maps"
	local function v866()
		-- upvalues: (ref) v_u_6, (copy) v_u_865
		return require((v_u_6:WaitForChild(v_u_865, 5)))
	end
	local v867, v868 = pcall(v866)
	if not v867 then
		v868 = nil
	end
	local v869 = {}
	for _, v870 in v868 and v868.LIST or {} do
		local v871 = v870.gate
		if type(v871) ~= "string" then
			continue
		end
		table.insert(v869, v870)
	end
	if #v869 > 0 then
		v228(v_u_863, "Maps  \194\183  all servers")
		local v872 = nil
		local v_u_873 = v872
		local function v_u_874() end
		local function v_u_875() end
		local v_u_876 = {}
		local function v_u_880(p877) -- name: ago
			local v878 = os.time() - p877
			local v879 = math.max(0, v878)
			if v879 < 60 then
				return ("%d s ago"):format(v879)
			elseif v879 < 3600 then
				return ("%d min ago"):format(v879 // 60)
			else
				return ("%d h ago"):format(v879 // 3600)
			end
		end
		for _, v_u_881 in v869 do
			local v_u_882 = v_u_881.gate
			local v883 = v_u_236(v_u_863, 30)
			v883.Name = "Gate_" .. v_u_882
			v_u_7.label({
				["parent"] = nil,
				["name"] = "MapName",
				["text"] = nil,
				["style"] = "monoL",
				["size"] = nil,
				["parent"] = v883,
				["text"] = string.upper(v_u_881.name),
				["size"] = UDim2.fromOffset(150, 30)
			}).LayoutOrder = 1
			local v884 = v_u_7.label({
				["parent"] = nil,
				["name"] = "GateState",
				["text"] = "...",
				["style"] = "bodyStrong",
				["align"] = "right",
				["size"] = nil,
				["parent"] = v883,
				["size"] = UDim2.fromOffset(v_u_15 - 156, 30)
			})
			v884.LayoutOrder = 2
			v884.TextTruncate = Enum.TextTruncate.AtEnd
			local v885 = v_u_232(v_u_863, "")
			v885.Name = "GateWho_" .. v_u_882
			local v886 = v_u_232(v_u_863, "")
			v886.Name = "GateConfirmations_" .. v_u_882
			v886.TextColor3 = v_u_9.muted
			local v_u_887 = v_u_7.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Visible"] = false,
				["Name"] = "GateConfirm_" .. v_u_882,
				["BackgroundColor3"] = v_u_9.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v_u_863)
			local function v897() -- name: pressMain
				-- upvalues: (copy) v_u_882, (ref) v_u_873, (copy) v_u_864, (copy) v_u_887, (copy) p_u_47, (ref) v_u_874, (ref) v_u_875, (copy) v_u_50, (copy) v_u_881, (copy) v_u_863
				local v888 = v_u_882
				local v889 = v_u_873
				if v889 then
					local v890 = v_u_873.gates
					if type(v890) == "table" then
						v889 = v_u_873.gates[v888]
					else
						v889 = false
					end
				end
				local v891
				if type(v889) == "table" and v889.open ~= nil then
					v891 = v889.open == true
				elseif v_u_864 == nil then
					v891 = false
				else
					v891 = v_u_864:GetAttribute("MapGate_" .. v888) == true
				end
				if v891 then
					v_u_887.Visible = false
					local v892 = {
						["gate"] = nil,
						["open"] = false,
						["gate"] = v_u_882
					}
					p_u_47.call("server.mapgate", v892, function(p893)
						-- upvalues: (ref) v_u_873, (ref) v_u_874, (ref) v_u_875
						if p893 and p893.ok then
							local v894 = p893.data
							if type(v894) == "table" then
								v_u_873 = p893.data
							end
						end
						v_u_874()
						task.delay(2, v_u_875)
					end)
				else
					v_u_887.Visible = true
					v_u_50.status(("Confirm below: open %s for everyone?"):format(v_u_881.name), "danger")
					task.delay(0.05, function()
						-- upvalues: (ref) v_u_863, (ref) v_u_887
						if v_u_863:IsA("ScrollingFrame") and v_u_887.Visible then
							local v895 = v_u_887.AbsolutePosition.Y + v_u_887.AbsoluteSize.Y - (v_u_863.AbsolutePosition.Y + v_u_863.AbsoluteWindowSize.Y)
							if v895 > 0 then
								local v896 = v_u_863
								v896.CanvasPosition = v896.CanvasPosition + Vector2.new(0, v895 + 8)
							end
						end
					end)
				end
			end
			local v898 = v_u_15
			local v899, v900 = v_u_7.button({
				["parent"] = nil,
				["text"] = "Open for everyone",
				["kind"] = "primary",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v_u_863,
				["width"] = v898,
				["onClick"] = v897,
				["maxTextWidth"] = (v898 or 140) - 12
			})
			v_u_224[v_u_863] = (v_u_224[v_u_863] or 0) + 1
			v899.LayoutOrder = v_u_224[v_u_863]
			v899.Name = "GateToggle_" .. v_u_882
			v_u_224[v_u_863] = (v_u_224[v_u_863] or 0) + 1
			v_u_887.LayoutOrder = v_u_224[v_u_863]
			v_u_7.stroke(v_u_887, v_u_9.danger)
			v_u_7.pad(v_u_887, {
				10,
				10,
				8,
				8
			})
			v_u_7.layout(v_u_887, "v", 6)
			v_u_7.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_887,
				["text"] = ("Every player can deploy to %s on every server. Lock it again here."):format(v_u_881.name),
				["color"] = v_u_9.text,
				["size"] = UDim2.new(1, 0, 0, 0)
			}).LayoutOrder = 1
			local v901 = v_u_7.new("Frame", {
				["Name"] = "Row",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, 32)
			}, v_u_887)
			v_u_7.layout(v901, "h", 6)
			local v902 = (v_u_15 - 20 - 6) / 2
			local v903 = math.floor(v902)
			local function v904() -- name: cancelOpen
				-- upvalues: (copy) v_u_887, (copy) v_u_50, (copy) v_u_881
				v_u_887.Visible = false
				v_u_50.status(("%s stays locked."):format(v_u_881.name))
			end
			local function v908() -- name: confirmOpen
				-- upvalues: (copy) v_u_887, (copy) p_u_47, (copy) v_u_882, (ref) v_u_873, (ref) v_u_874, (ref) v_u_875
				if v_u_887.Visible then
					v_u_887.Visible = false
					local v905 = {
						["gate"] = nil,
						["open"] = true,
						["gate"] = v_u_882
					}
					p_u_47.call("server.mapgate", v905, function(p906)
						-- upvalues: (ref) v_u_873, (ref) v_u_874, (ref) v_u_875
						if p906 and p906.ok then
							local v907 = p906.data
							if type(v907) == "table" then
								v_u_873 = p906.data
							end
						end
						v_u_874()
						task.delay(2, v_u_875)
					end)
				end
			end
			local v909, _ = v_u_7.button({
				["parent"] = nil,
				["text"] = "Cancel",
				["kind"] = "secondary",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v901,
				["width"] = v903,
				["onClick"] = v904,
				["maxTextWidth"] = (v903 or 140) - 12
			})
			v_u_224[v901] = (v_u_224[v901] or 0) + 1
			v909.LayoutOrder = v_u_224[v901]
			v909.Name = "GateCancel_" .. v_u_882
			local v910, _ = v_u_7.button({
				["parent"] = nil,
				["text"] = "Open it now",
				["kind"] = "danger",
				["height"] = 32,
				["width"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = nil,
				["parent"] = v901,
				["width"] = v903,
				["onClick"] = v908,
				["maxTextWidth"] = (v903 or 140) - 12
			})
			v_u_224[v901] = (v_u_224[v901] or 0) + 1
			v910.LayoutOrder = v_u_224[v901]
			v910.Name = "GateConfirmOpen_" .. v_u_882
			v_u_876[v_u_882] = {
				["def"] = v_u_881,
				["st"] = v884,
				["who"] = v885,
				["conf"] = v886,
				["box"] = v_u_887,
				["api"] = v900,
				["press"] = v897,
				["confirm"] = v908,
				["cancel"] = v904
			}
		end
		v_u_232(v_u_863, "Locked: only the testers (you) and Studio can deploy there; everybody else sees LOCKED in the menu and is refused by the server. Stored in a DataStore: every server follows within seconds (at the latest 2 minutes), also after restarts.")
		local function v_u_943()
			-- upvalues: (copy) v_u_876, (ref) v_u_873, (copy) v_u_864, (ref) v_u_9, (copy) v_u_880, (ref) v_u_11
			local v911 = {}
			for v912, v913 in v_u_876 do
				local v914 = v_u_873
				if v914 then
					local v915 = v_u_873.gates
					if type(v915) == "table" then
						v914 = v_u_873.gates[v912]
					else
						v914 = false
					end
				end
				local v916
				if type(v914) == "table" and v914.open ~= nil then
					v916 = v914.open == true
				elseif v_u_864 == nil then
					v916 = false
				else
					v916 = v_u_864:GetAttribute("MapGate_" .. v912) == true
				end
				v913.st.Text = v916 and "OPEN TO EVERYONE" or "LOCKED"
				local v917 = v913.st
				local v918
				if v916 then
					v918 = v_u_9.success
				else
					v918 = v_u_9.danger
				end
				v917.TextColor3 = v918
				local v919
				if v_u_873 then
					local v920 = v_u_873.gates
					if type(v920) == "table" then
						v919 = v_u_873.gates[v912] or nil
					else
						v919 = nil
					end
				else
					v919 = nil
				end
				local v921
				if type(v919) == "table" then
					local v922 = v919.at
					v921 = tonumber(v922) or nil
				else
					v921 = nil
				end
				if v921 and v921 > 0 then
					local v923 = v913.who
					local v924 = v919.byName or "?"
					v923.Text = ("%s by %s at %s."):format(v916 and "Opened" or "Locked", tostring(v924), (os.date("%H:%M", v921)))
				else
					v913.who.Text = v916 and "Open." or "Never opened: testers only."
				end
				if v_u_873 then
					local v925 = v_u_873.lastRead
					local v926 = tonumber(v925) or 0
					local v927 = v_u_873.v
					local v928 = tonumber(v927) or 0
					local v929 = v926 <= 0 and "never" or v_u_880(v926)
					local v930 = v_u_873.backend or "?"
					local v931 = ("Stored v%d  \194\183  this server read it %s  \194\183  %s store"):format(v928, v929, (tostring(v930)))
					if v_u_873.good ~= true then
						v931 = v931 .. "  \194\183  NO GOOD READ YET (closed for safety)"
					end
					if v_u_873.test then
						local v932 = v_u_873.test
						v931 = v931 .. "  \194\183  test mode " .. tostring(v932)
					end
					v913.conf.Text = v931
					local v933 = v913.conf
					local v934
					if v_u_873.good == true then
						v934 = v_u_9.muted
					else
						v934 = v_u_9.danger
					end
					v933.TextColor3 = v934
				else
					v913.conf.Text = "Reading the switch ..."
				end
				v913.api.setText(v916 and "Lock again" or "Open for everyone")
				v913.api.setKind(v916 and "danger" or "primary")
				if v916 then
					v913.box.Visible = false
				end
				local v935 = "%s=%s|v%d|%s|%s"
				local v936 = v916 and "OPEN" or "LOCKED"
				local v937 = v_u_873
				if v937 then
					v937 = v_u_873.v
				end
				local v938 = tonumber(v937) or 0
				local v939 = v_u_873
				if v939 then
					v939 = v_u_873.backend
				end
				local v940 = tostring(v939)
				local v941 = v_u_873
				if v941 then
					v941 = v_u_873.good
				end
				local v942 = tostring(v941)
				table.insert(v911, v935:format(v912, v936, v938, v940, v942))
			end
			v_u_11:SetAttribute("FilmMaps", table.concat(v911, ";"))
		end
		local function v_u_946()
			-- upvalues: (copy) p_u_47, (ref) v_u_873, (ref) v_u_943
			p_u_47.callQuiet("server.maps", {}, function(p944)
				-- upvalues: (ref) v_u_873, (ref) v_u_943
				if p944 and p944.ok then
					local v945 = p944.data
					if type(v945) == "table" then
						v_u_873 = p944.data
					end
				end
				v_u_943()
			end)
		end
		if v_u_864 then
			local v_u_948 = v_u_864.AttributeChanged:Connect(function(p947)
				-- upvalues: (ref) v_u_943
				if string.sub(p947, 1, 8) == "MapGate_" then
					v_u_943()
				end
			end)
			v_u_48.Destroying:Connect(function()
				-- upvalues: (copy) v_u_948
				v_u_948:Disconnect()
			end)
		end
		if game:GetService("RunService"):IsStudio() then
			local v_u_952 = v_u_11:GetAttributeChangedSignal("FilmMapsCmd"):Connect(function()
				-- upvalues: (ref) v_u_11, (copy) v_u_876
				local v949 = v_u_11:GetAttribute("FilmMapsCmd")
				if type(v949) == "string" and v949 ~= "" then
					v_u_11:SetAttribute("FilmMapsCmd", nil)
					local v950, v951 = string.match(v949, "^(%a+)%s+(%S+)$")
					if v951 then
						v951 = v_u_876[v951]
					end
					if v951 and v951[v950] then
						v951[v950]()
					end
				end
			end)
			v_u_48.Destroying:Connect(function()
				-- upvalues: (copy) v_u_952
				v_u_952:Disconnect()
			end)
		end
		table.insert(v_u_51, v_u_943)
		task.spawn(function()
			-- upvalues: (ref) v_u_632, (copy) v_u_48, (copy) v_u_863, (ref) v_u_946
			local v953 = false
			local v954 = 0
			while v_u_632 do
				local v955 = v_u_48.Enabled
				if v955 then
					v955 = v_u_863.Visible
				end
				if v955 and (not v953 or os.clock() - v954 >= 5) then
					v954 = os.clock()
					v_u_946()
				end
				task.wait(0.25)
				v953 = v955
			end
		end)
		v_u_943()
	end
	local v_u_956 = v_u_150.server
	v228(v_u_956, "API budget  \194\183  this server")
	local v_u_957 = v_u_7.new("Frame", {
		["Name"] = "ApiStats",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_956)
	v_u_7.layout(v_u_957, "v", 2)
	v_u_224[v_u_956] = (v_u_224[v_u_956] or 0) + 1
	v_u_957.LayoutOrder = v_u_224[v_u_956]
	v_u_232(v_u_956, "Per service: units in the last minute against this server\'s budget, then calls, throttled answers from Roblox, errors and calls the budget refused or postponed. Amber from 60 %, red from 80 %.")
	v228(v_u_956, "Sounds blocked by Roblox")
	local v_u_958 = v_u_7.label({
		["parent"] = nil,
		["name"] = "SoundAuditState",
		["text"] = "...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_956,
		["color"] = v_u_9.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_224[v_u_956] = (v_u_224[v_u_956] or 0) + 1
	v_u_958.LayoutOrder = v_u_224[v_u_956]
	local v_u_959 = v_u_7.new("Frame", {
		["Name"] = "SoundBlocked",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_956)
	v_u_7.layout(v_u_959, "v", 2)
	v_u_224[v_u_956] = (v_u_224[v_u_956] or 0) + 1
	v_u_959.LayoutOrder = v_u_224[v_u_956]
	local v_u_960 = Color3.fromRGB(232, 163, 61)
	local function v_u_963(p961) -- name: clearList
		for _, v962 in p961:GetChildren() do
			if not v962:IsA("GuiObject") then
				continue
			end
			v962:Destroy()
		end
	end
	local function v_u_971(p964, p965, p966, p967, p968, p969) -- name: line
		-- upvalues: (ref) v_u_7
		local v970 = v_u_7.label({
			["parent"] = p964,
			["name"] = p965,
			["text"] = p966,
			["style"] = p969 or "small",
			["color"] = p967,
			["size"] = UDim2.new(1, 0, 0, 18)
		})
		v970.TextTruncate = Enum.TextTruncate.AtEnd
		v970.LayoutOrder = p968
		return v970
	end
	local function v_u_1034(p972) -- name: paintApi
		-- upvalues: (copy) v_u_963, (copy) v_u_957, (copy) v_u_959, (ref) v_u_7, (ref) v_u_9, (copy) v_u_960, (copy) v_u_971, (copy) v_u_958, (ref) v_u_11
		v_u_963(v_u_957)
		v_u_963(v_u_959)
		local v973
		if type(p972) == "table" then
			local v974 = p972.api
			v973 = type(v974) == "table" and (p972.api or {}) or {}
		else
			v973 = {}
		end
		local v975 = 0
		local v976 = 0
		for v977, v978 in v973 do
			if type(v978) == "table" and v978.counter == true then
				local v979 = v_u_7.label
				local v980 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_957
				}
				local v981 = string.gsub
				local v982 = v978.service
				v980.name = "Ctr_" .. v981(tostring(v982), "[^%w]", "")
				local v983 = string.upper
				local v984 = v978.service
				local v985 = v983((tostring(v984)))
				local v986 = v978.text
				v980.text = ("%s   %s"):format(v985, (tostring(v986)))
				v980.color = v_u_9.text2
				v980.size = UDim2.new(1, 0, 0, 0)
				v979(v980).LayoutOrder = v977 * 2 - 1
			else
				if type(v978) ~= "table" then
					continue
				end
				v975 = v975 + 1
				local v987 = v978.throttled
				v976 = v976 + (tonumber(v987) or 0)
				local v988 = v978.pressure
				local v989 = tonumber(v988) or 0
				local v990
				if v989 >= 80 then
					v990 = v_u_9.danger
				elseif v989 >= 60 then
					v990 = v_u_960
				else
					v990 = v_u_9.text
				end
				local v991
				if v978.cap then
					local v992 = v978.cap
					local v993 = math.floor(v992)
					v991 = tostring(v993)
				else
					v991 = "engine"
				end
				local v994 = v_u_971
				local v995 = v_u_957
				local v996 = v978.service
				local v997 = "Svc_" .. tostring(v996)
				local v998 = string.upper
				local v999 = v978.service
				local v1000 = v998((tostring(v999)))
				local v1001 = v978.perMin
				local v1002 = tonumber(v1001) or 0
				local v1003 = v978.cooldown
				v994(v995, v997, ("%s   %d / %s per min   %d %%%s"):format(v1000, v1002, v991, v989, (tonumber(v1003) or 0) <= 0 and "" or ("   cooldown %.0f s"):format(v978.cooldown)), v990, v977 * 2 - 1, "body")
				local v1004 = v_u_971
				local v1005 = v_u_957
				local v1006 = v978.service
				v1004(v1005, "Sub_" .. tostring(v1006), ("calls %d \194\183 throttled %d \194\183 errors %d \194\183 refused %d \194\183 skipped %d \194\183 deferred %d \194\183 dropped %d"):format(v978.calls or 0, v978.throttled or 0, v978.errors or 0, v978.denied or 0, v978.skipped or 0, v978.deferred or 0, v978.dropped or 0), v_u_9.text2, v977 * 2)
			end
		end
		if v975 == 0 then
			v_u_971(v_u_957, "Empty", "No API calls on this server yet.", v_u_9.muted, 1)
		end
		local v1007
		if type(p972) == "table" then
			local v1008 = p972.blocked
			v1007 = type(v1008) == "table" and (p972.blocked or {}) or {}
		else
			v1007 = {}
		end
		local v1009
		if type(p972) == "table" then
			local v1010 = p972.audit
			v1009 = type(v1010) == "table" and (p972.audit or {}) or {}
		else
			v1009 = {}
		end
		local v1011 = v_u_958
		local v1012 = v1009.day or "-"
		local v1013 = tostring(v1012)
		local v1014 = v1009.checked or 0
		local v1015 = tostring(v1014)
		local v1016 = v1009.errors or 0
		local v1017 = tostring(v1016)
		local v1018 = v1009.running == true
		local v1019 = tostring(v1018)
		local v1020 = p972 and p972.suspects or 0
		v1011.Text = ("Daily audit: %s \194\183 checked %s \194\183 errors %s \194\183 running %s \194\183 suspects %s"):format(v1013, v1015, v1017, v1019, (tostring(v1020)))
		for v1021, v1022 in v1007 do
			if v1021 > 20 then
				v_u_971(v_u_959, "More", ("and %d more (HushCmd audio.blocked)"):format(#v1007 - 20), v_u_9.muted, 99)
				break
			end
			local v1023 = v_u_971
			local v1024 = v_u_959
			local v1025 = v1022.id
			local v1026 = "Blocked_" .. tostring(v1025)
			local v1027 = v1022.id
			local v1028 = tostring(v1027)
			local v1029 = v1022.defs
			local v1030 = tostring(v1029)
			local v1031 = v1022.reason
			local v1032 = tostring(v1031)
			local v1033 = v1022.src
			v1023(v1024, v1026, ("%s  %s  \194\183  %s (%s)"):format(v1028, v1030, v1032, (tostring(v1033))), v_u_9.danger, v1021)
		end
		if #v1007 == 0 then
			v_u_971(v_u_959, "None", "No sound is blocked.", v_u_9.success, 1)
		end
		v_u_11:SetAttribute("FilmApi", ("%d|%d|%d"):format(v975, #v1007, v976))
	end
	local v_u_1035 = true
	v_u_48.Destroying:Connect(function()
		-- upvalues: (ref) v_u_1035
		v_u_1035 = false
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_1035, (copy) v_u_48, (copy) v_u_956, (copy) p_u_47, (copy) v_u_1034
		local v1036 = false
		local v1037 = 0
		while v_u_1035 do
			local v1038 = v_u_48.Enabled
			if v1038 then
				v1038 = v_u_956.Visible
			end
			if v1038 and (not v1036 or os.clock() - v1037 >= 2) then
				v1037 = os.clock()
				p_u_47.call("server.api", {}, function(p1039)
					-- upvalues: (ref) v_u_1034
					if p1039 and p1039.ok then
						v_u_1034(p1039.data)
					end
				end)
			end
			task.wait(0.25)
			v1036 = v1038
		end
	end)
	local v1040, v1041 = pcall(function()
		return require((script.Parent:WaitForChild("FilmEco", 5)))
	end)
	if v1040 and v1041 then
		local v1042 = v1041.build
		local v1044 = {
			["body"] = v_u_150.server,
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1043 = v_u_150.server
				v_u_224[v1043] = (v_u_224[v1043] or 0) + 1
				return v_u_224[v1043]
			end,
			["api"] = p_u_47,
			["inner"] = v_u_15,
			["gui"] = v_u_48
		}
		local v1045, v1046 = pcall(v1042, v1044)
		if not v1045 then
			warn("[FilmPanel] economy section failed:", v1046)
		end
	end
	local v1047, v1048 = pcall(function()
		return require((script.Parent:WaitForChild("FilmSale", 5)))
	end)
	if v1047 and v1048 then
		local v1049 = v1048.build
		local v1051 = {
			["body"] = v_u_150.server,
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1050 = v_u_150.server
				v_u_224[v1050] = (v_u_224[v1050] or 0) + 1
				return v_u_224[v1050]
			end,
			["api"] = p_u_47,
			["inner"] = v_u_15,
			["gui"] = v_u_48
		}
		local v1052, v1053 = pcall(v1049, v1051)
		if not v1052 then
			warn("[FilmPanel] store sale section failed:", v1053)
		end
	end
	local v1054, v1055 = pcall(function()
		return require((script.Parent:WaitForChild("FilmBm", 5)))
	end)
	if v1054 and v1055 then
		local v1056 = v1055.mount
		local v1057 = v_u_150.server
		local v1058 = p_u_47.call
		local v1059 = v_u_8
		local v1061 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1060 = v_u_150.server
				v_u_224[v1060] = (v_u_224[v1060] or 0) + 1
				return v_u_224[v1060]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1062, v1063 = pcall(v1056, v1057, v1058, v1059, v1061)
		if not v1062 then
			warn("[FilmPanel] blackmarket section failed:", v1063)
		end
	end
	local v1064, v1065 = pcall(function()
		return require((script.Parent:WaitForChild("FilmMailSw", 5)))
	end)
	if v1064 and v1065 then
		local v1066 = v1065.mount
		local v1067 = v_u_150.server
		local v1068 = p_u_47.call
		local v1069 = v_u_8
		local v1071 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1070 = v_u_150.server
				v_u_224[v1070] = (v_u_224[v1070] or 0) + 1
				return v_u_224[v1070]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1072, v1073 = pcall(v1066, v1067, v1068, v1069, v1071)
		if not v1072 then
			warn("[FilmPanel] mail switch section failed:", v1073)
		end
	end
	local v1074, v1075 = pcall(function()
		return require((script.Parent:WaitForChild("FilmReconn", 5)))
	end)
	if v1074 and v1075 then
		local v1076 = v1075.mount
		local v1077 = v_u_150.server
		local v1078 = p_u_47.call
		local v1079 = v_u_8
		local v1081 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1080 = v_u_150.server
				v_u_224[v1080] = (v_u_224[v1080] or 0) + 1
				return v_u_224[v1080]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1082, v1083 = pcall(v1076, v1077, v1078, v1079, v1081)
		if not v1082 then
			warn("[FilmPanel] reconnect section failed:", v1083)
		end
	end
	local v1084, v1085 = pcall(function()
		return require((script.Parent:WaitForChild("FilmAC", 5)))
	end)
	if v1084 and v1085 then
		local v1086 = v1085.mount
		local v1087 = v_u_150.server
		local v1088 = p_u_47.call
		local v1089 = v_u_8
		local v1091 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1090 = v_u_150.server
				v_u_224[v1090] = (v_u_224[v1090] or 0) + 1
				return v_u_224[v1090]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1092, v1093 = pcall(v1086, v1087, v1088, v1089, v1091)
		if not v1092 then
			warn("[FilmPanel] anti cheat section failed:", v1093)
		end
	end
	local v1094, v1095 = pcall(function()
		return require((script.Parent:WaitForChild("FilmReviewers", 5)))
	end)
	if v1094 and v1095 then
		local v1096 = v1095.mount
		local v1097 = v_u_150.server
		local v1098 = p_u_47.call
		local v1099 = v_u_8
		local v1101 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1100 = v_u_150.server
				v_u_224[v1100] = (v_u_224[v1100] or 0) + 1
				return v_u_224[v1100]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48
		}
		local v1102, v1103 = pcall(v1096, v1097, v1098, v1099, v1101)
		if not v1102 then
			warn("[FilmPanel] overwatch section failed:", v1103)
		end
	end
	local v1104, v1105 = pcall(function()
		return require((script.Parent:WaitForChild("FilmPvpPause", 5)))
	end)
	if v1104 and v1105 then
		local v1106 = v1105.mount
		local v1107 = v_u_150.server
		local v1108 = p_u_47.call
		local v1109 = v_u_8
		local v1111 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1110 = v_u_150.server
				v_u_224[v1110] = (v_u_224[v1110] or 0) + 1
				return v_u_224[v1110]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1112, v1113 = pcall(v1106, v1107, v1108, v1109, v1111)
		if not v1112 then
			warn("[FilmPanel] pvp pause section failed:", v1113)
		end
	end
	local v1114, v1115 = pcall(function()
		return require((script.Parent:WaitForChild("FilmPvpMap", 5)))
	end)
	if v1114 and v1115 then
		local v1116 = v1115.mount
		local v1117 = v_u_150.server
		local v1118 = p_u_47.call
		local v1119 = v_u_8
		local v1121 = {
			["order"] = function() -- name: order
				-- upvalues: (copy) v_u_150, (copy) v_u_224
				local v1120 = v_u_150.server
				v_u_224[v1120] = (v_u_224[v1120] or 0) + 1
				return v_u_224[v1120]
			end,
			["inner"] = v_u_15,
			["gui"] = v_u_48,
			["sendQuiet"] = p_u_47.callQuiet
		}
		local v1122, v1123 = pcall(v1116, v1117, v1118, v1119, v1121)
		if not v1122 then
			warn("[FilmPanel] pvp map section failed:", v1123)
		end
	end
	local v1124 = v_u_10.pvpRefundShown
	local v_u_1125 = "GameMode"
	local function v1126()
		-- upvalues: (ref) v_u_6, (copy) v_u_1125
		return require((v_u_6:WaitForChild(v_u_1125, 5)))
	end
	local v1127, v1128 = pcall(v1126)
	if not v1127 then
		v1128 = nil
	end
	if v1124(v1128) then
		local v1129, v1130 = pcall(function()
			return require((script.Parent:WaitForChild("FilmPvpRefund", 5)))
		end)
		if v1129 and v1130 then
			local v1131 = v1130.mount
			local v1132 = v_u_150.server
			local v1133 = p_u_47.call
			local v1134 = v_u_8
			local v1136 = {
				["order"] = function() -- name: order
					-- upvalues: (copy) v_u_150, (copy) v_u_224
					local v1135 = v_u_150.server
					v_u_224[v1135] = (v_u_224[v1135] or 0) + 1
					return v_u_224[v1135]
				end,
				["inner"] = v_u_15,
				["gui"] = v_u_48
			}
			local v1137, v1138 = pcall(v1131, v1132, v1133, v1134, v1136)
			if not v1137 then
				warn("[FilmPanel] pvp refund section failed:", v1138)
			end
		end
		local v1139, v1140 = pcall(function()
			return require((script.Parent:WaitForChild("FilmStashWipe", 5)))
		end)
		if v1139 and v1140 then
			local v1141 = v1140.mount
			local v1142 = v_u_150.server
			local v1143 = p_u_47.call
			local v1144 = v_u_8
			local v1146 = {
				["order"] = function() -- name: order
					-- upvalues: (copy) v_u_150, (copy) v_u_224
					local v1145 = v_u_150.server
					v_u_224[v1145] = (v_u_224[v1145] or 0) + 1
					return v_u_224[v1145]
				end,
				["inner"] = v_u_15,
				["gui"] = v_u_48
			}
			local v1147, v1148 = pcall(v1141, v1142, v1143, v1144, v1146)
			if not v1147 then
				warn("[FilmPanel] stash wipe section failed:", v1148)
			end
		end
		local v1149, v1150 = pcall(function()
			return require((script.Parent:WaitForChild("FilmPvpveStatus", 5)))
		end)
		if v1149 and v1150 then
			local v1151 = v1150.mount
			local v1152 = v_u_150.server
			local v1153 = v_u_8
			local v1155, v1156 = pcall(v1151, v1152, v1153, {
				["order"] = function() -- name: order
					-- upvalues: (copy) v_u_150, (copy) v_u_224
					local v1154 = v_u_150.server
					v_u_224[v1154] = (v_u_224[v1154] or 0) + 1
					return v_u_224[v1154]
				end,
				["gui"] = v_u_48
			})
			if not v1155 then
				warn("[FilmPanel] pvpve status section failed:", v1156)
			end
		end
	end
	v228(v_u_628, "Protection")
	local v1158 = {
		["parent"] = nil,
		["label"] = "Protect affected players",
		["value"] = true,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_628,
		["width"] = v_u_15,
		["onChange"] = function(p1157)
			-- upvalues: (ref) v_u_629, (ref) v_u_11
			v_u_629 = p1157
			v_u_11:SetAttribute("FilmProtect", p1157)
		end
	}
	local v1159, _ = v_u_7.toggle(v1158)
	v_u_224[v_u_628] = (v_u_224[v_u_628] or 0) + 1
	v1159.LayoutOrder = v_u_224[v_u_628]
	v_u_11:SetAttribute("FilmProtect", true)
	v_u_232(v_u_628, "On: nothing is saved for the other players you infect, cure or put on a new raid clock (no loss, no gain). Off: they keep real consequences. Your own raid is never saved in film mode.")
	v228(v_u_628, "Players in this raid")
	local v_u_1160 = v_u_7.new("Frame", {
		["Name"] = "Players",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_628)
	v_u_7.layout(v_u_1160, "v", 4)
	v_u_224[v_u_628] = (v_u_224[v_u_628] or 0) + 1
	v_u_1160.LayoutOrder = v_u_224[v_u_628]
	local v_u_1161 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Empty",
		["text"] = "Only in a raid.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_1160,
		["color"] = v_u_9.muted,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_1161.LayoutOrder = 0
	local function v_u_1172(p1162, p1163, p1164) -- name: makeChip
		-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
		local v_u_1165 = v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["LayoutOrder"] = nil,
			["Name"] = p1163,
			["BackgroundColor3"] = v_u_9.bg,
			["Size"] = UDim2.fromOffset(0, 18),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["LayoutOrder"] = p1164
		}, p1162)
		local v_u_1166 = v_u_7.stroke(v_u_1165, v_u_9.info, 1, 0.35)
		v_u_7.pad(v_u_1165, {
			6,
			6,
			0,
			0
		})
		local v_u_1167 = v_u_7.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "micro",
			["autoX"] = true,
			["size"] = nil,
			["parent"] = v_u_1165,
			["size"] = UDim2.fromOffset(0, 18)
		})
		local v_u_1168 = ""
		return function(p1169, p1170)
			-- upvalues: (copy) v_u_1165, (ref) v_u_1168, (ref) v_u_7, (copy) v_u_1167, (ref) v_u_8, (copy) v_u_1166
			v_u_1165.Visible = p1169 ~= nil
			if p1169 and p1169 ~= v_u_1168 then
				v_u_1168 = p1169
				v_u_7.setText(v_u_1167, p1169)
			end
			local v1171 = v_u_8.kindColor(p1170)
			v_u_1166.Color = v1171
			v_u_1167.TextColor3 = v1171
		end
	end
	local function v_u_1180() -- name: paintRows
		-- upvalues: (copy) v_u_631, (ref) v_u_630, (ref) v_u_9
		for v1173, v1174 in v_u_631 do
			local v1175 = v1173 == v_u_630
			local v1176 = v1174.btn
			local v1177
			if v1175 then
				v1177 = v_u_9.accentDeep
			else
				v1177 = v_u_9.raised
			end
			v1176.BackgroundColor3 = v1177
			local v1178 = v1174.stroke
			local v1179
			if v1175 then
				v1179 = v_u_9.accent
			else
				v1179 = v_u_9.line
			end
			v1178.Color = v1179
		end
	end
	local function v_u_1185(p_u_1181) -- name: makeRow
		-- upvalues: (ref) v_u_7, (ref) v_u_9, (copy) v_u_1160, (copy) v_u_1172, (ref) v_u_8, (ref) v_u_630, (copy) v_u_1180
		local v1182 = v_u_7.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Name"] = "Player_" .. p_u_1181,
			["BackgroundColor3"] = v_u_9.raised,
			["Size"] = UDim2.new(1, 0, 0, 40)
		}, v_u_1160)
		local v1183 = {
			["btn"] = v1182,
			["stroke"] = v_u_7.stroke(v1182, v_u_9.line),
			["name"] = v_u_7.label({
				["parent"] = nil,
				["text"] = "",
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1182,
				["position"] = UDim2.fromOffset(10, 2),
				["size"] = UDim2.new(1, -214, 0, 20)
			})
		}
		v1183.name.TextTruncate = Enum.TextTruncate.AtEnd
		v1183.sub = v_u_7.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v1182,
			["color"] = v_u_9.muted,
			["position"] = UDim2.fromOffset(10, 21),
			["size"] = UDim2.new(1, -214, 0, 16)
		})
		v1183.sub.TextTruncate = Enum.TextTruncate.AtEnd
		local v1184 = v_u_7.new("Frame", {
			["Name"] = "Chips",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -8, 0.5, 0),
			["Size"] = UDim2.fromOffset(200, 18)
		}, v1182)
		v_u_7.layout(v1184, "h", 4, "right")
		v1183.chipGod = v_u_1172(v1184, "God", 1)
		v1183.chipSaved = v_u_1172(v1184, "NotSaved", 2)
		v1183.chipState = v_u_1172(v1184, "State", 3)
		v1183.chipInf = v_u_1172(v1184, "Infected", 4)
		v1182.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_8
			v_u_7.sound(v_u_8.sounds.hover)
		end)
		v1182.Activated:Connect(function()
			-- upvalues: (ref) v_u_630, (copy) p_u_1181, (ref) v_u_7, (ref) v_u_8, (ref) v_u_1180
			v_u_630 = p_u_1181
			v_u_7.sound(v_u_8.sounds.click)
			v_u_1180()
		end)
		return v1183
	end
	local function v_u_1197(p1186) -- name: paintRow
		-- upvalues: (ref) v_u_1
		local v1187 = p1186.data
		if type(v1187) == "table" then
			p1186.chipGod(v1187.god and "God" or nil, "info")
			p1186.chipSaved(v1187.tainted and "Not saved" or nil, "muted")
			if v1187.alive then
				if v1187.downed then
					p1186.chipState("Downed", "warn")
				else
					p1186.chipState(nil)
				end
			else
				p1186.chipState("Dead", "muted")
			end
			if v1187.infected then
				local v1188 = v1187.endsAt
				local v1189
				if type(v1188) == "number" then
					v1189 = v1187.endsAt - v_u_1.now()
				else
					local v1190 = v1187.secondsLeft
					v1189 = tonumber(v1190)
				end
				local v1191 = p1186.chipInf
				local v1192 = "Infected "
				local v1193
				if v1189 then
					local v1194 = v1189 + 0.5
					local v1195 = math.floor(v1194)
					local v1196 = math.max(0, v1195)
					v1193 = string.format("%d:%02d", v1196 // 60, v1196 % 60)
				else
					v1193 = ""
				end
				v1191(v1192 .. v1193, "infection")
			else
				p1186.chipInf(nil)
			end
		else
			return
		end
	end
	local function v_u_1215(p1198, p1199) -- name: applyPlayers
		-- upvalues: (copy) v_u_631, (copy) v_u_1185, (ref) v_u_11, (copy) v_u_1197, (ref) v_u_630, (copy) v_u_1161, (copy) v_u_1180
		local v1200 = {}
		for v1201, v1202 in p1198 do
			local v1203 = v1202.userId
			local v1204 = tonumber(v1203)
			if not v1204 then
				continue
			end
			v1200[v1204] = true
			local v1205 = v_u_631[v1204]
			if not v1205 then
				v1205 = v_u_1185(v1204)
				v_u_631[v1204] = v1205
			end
			v1205.btn.LayoutOrder = v1201
			v1205.data = v1202
			local v1206 = v1204 == v_u_11.UserId
			local v1207 = v1205.name
			local v1208 = v1202.displayName or v1202.name
			v1207.Text = tostring(v1208) .. (v1206 and "  (you)" or "")
			local v1209 = v1205.sub
			local v1210 = v1202.name
			v1209.Text = "@" .. tostring(v1210)
			v_u_1197(v1205)
		end
		local v1211 = {}
		for v1212 in v_u_631 do
			if v1200[v1212] then
				continue
			end
			table.insert(v1211, v1212)
		end
		for _, v1213 in v1211 do
			v_u_631[v1213].btn:Destroy()
			v_u_631[v1213] = nil
		end
		if v_u_630 and not v_u_631[v_u_630] then
			v_u_630 = nil
		end
		if not v_u_630 then
			if v_u_631[v_u_11.UserId] then
				v_u_630 = v_u_11.UserId
			elseif p1198[1] then
				local v1214 = p1198[1].userId
				v_u_630 = tonumber(v1214)
			end
		end
		v_u_1161.Visible = next(v_u_631) == nil
		v_u_1161.Text = p1199 or "Nobody in the raid."
		v_u_1180()
	end
	local v_u_1216 = false
	local function v_u_1221() -- name: refreshPlayers
		-- upvalues: (ref) v_u_1216, (ref) v_u_11, (copy) v_u_1215, (copy) p_u_47
		if v_u_1216 then
			return
		elseif v_u_11:GetAttribute("Place") == "Raid" then
			v_u_1216 = true
			p_u_47.callQuiet("raid.players", {}, function(p1217)
				-- upvalues: (ref) v_u_1216, (ref) v_u_1215
				v_u_1216 = false
				if p1217 and p1217.ok then
					local v1218 = p1217.data
					if type(v1218) == "table" then
						v_u_1215(p1217.data)
						return
					end
				end
				if p1217 then
					local v1219 = v_u_1215
					local v1220 = p1217.msg or "No answer."
					v1219({}, (tostring(v1220)))
				end
			end)
		else
			v_u_1215({}, "Only in a raid.")
		end
	end
	v_u_50.refreshRaid = v_u_1221
	v228(v_u_628, "Infection")
	local v_u_1222 = v_u_232(v_u_628, "Selected: nobody")
	local v1223 = v_u_236(v_u_628, 38)
	local v1224, v_u_1225 = v_u_7.input({
		["parent"] = nil,
		["name"] = "InfectTime",
		["width"] = 96,
		["text"] = "1:00",
		["placeholder"] = "m:ss",
		["parent"] = v1223
	})
	v_u_224[v1223] = (v_u_224[v1223] or 0) + 1
	v1224.LayoutOrder = v_u_224[v1223]
	local v1226 = (v_u_15 - 96 - 24) / 4
	local v1227 = math.floor(v1226)
	for _, v_u_1228 in {
		"0:30",
		"1:00",
		"3:00",
		"6:00"
	} do
		local v1229, _ = v_u_7.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "ghost",
			["height"] = 32,
			["width"] = nil,
			["onClick"] = nil,
			["maxTextWidth"] = nil,
			["parent"] = v1223,
			["text"] = v_u_1228,
			["width"] = v1227,
			["onClick"] = function()
				-- upvalues: (copy) v_u_1225, (copy) v_u_1228
				v_u_1225.Text = v_u_1228
			end,
			["maxTextWidth"] = (v1227 or 140) - 12
		})
		v_u_224[v1223] = (v_u_224[v1223] or 0) + 1
		v1229.LayoutOrder = v_u_224[v1223]
	end
	local v1230 = v_u_236(v_u_628, 32)
	local v1231 = (v_u_15 - 6) / 2
	local v1232 = math.floor(v1231)
	local v1238, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Infect",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1230,
		["width"] = v1232,
		["onClick"] = function()
			-- upvalues: (ref) v_u_630, (copy) v_u_50, (copy) v_u_643, (copy) v_u_1225, (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
			local v1233 = v_u_630
			if v1233 then
				local v1234 = v_u_643(v_u_1225.Text)
				if v1234 and (v1234 >= 5 and v1234 <= 1800) then
					local v1235 = p_u_47.call
					local v1236 = {
						["userId"] = v1233
					}
					local v1237 = v1234 + 0.5
					v1236.seconds = math.floor(v1237)
					v1236.protect = v_u_629
					v1235("player.infect", v1236, function()
						-- upvalues: (ref) v_u_1221
						v_u_1221()
					end)
				else
					v_u_50.status("Infection time: 0:05 to 30:00 (seconds or m:ss).", "danger")
				end
			else
				v_u_50.status("Pick a player first.", "danger")
				return
			end
		end,
		["maxTextWidth"] = (v1232 or 140) - 12
	})
	v_u_224[v1230] = (v_u_224[v1230] or 0) + 1
	v1238.LayoutOrder = v_u_224[v1230]
	local v1241, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Cure",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1230,
		["width"] = v1232,
		["onClick"] = function()
			-- upvalues: (ref) v_u_630, (copy) v_u_50, (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
			local v1239 = v_u_630
			if v1239 then
				local v1240 = {
					["userId"] = v1239,
					["protect"] = v_u_629
				}
				p_u_47.call("player.cure", v1240, function()
					-- upvalues: (ref) v_u_1221
					v_u_1221()
				end)
			else
				v_u_50.status("Pick a player first.", "danger")
			end
		end,
		["maxTextWidth"] = (v1232 or 140) - 12
	})
	v_u_224[v1230] = (v_u_224[v1230] or 0) + 1
	v1241.LayoutOrder = v_u_224[v1230]
	v_u_232(v_u_628, "The time runs until the infection turns the player (seconds or m:ss, 0:05 to 30:00). Infecting someone who is already infected only moves the end time. God mode cures at once. Turn it off for that player first.")
	v228(v_u_628, "Raid clock")
	local v_u_1242 = v_u_7.label({
		["parent"] = nil,
		["name"] = "ClockLeft",
		["text"] = "No raid running.",
		["style"] = "monoL",
		["size"] = nil,
		["parent"] = v_u_628,
		["size"] = UDim2.new(1, 0, 0, 30)
	})
	v_u_224[v_u_628] = (v_u_224[v_u_628] or 0) + 1
	v_u_1242.LayoutOrder = v_u_224[v_u_628]
	local v_u_1243 = v_u_232(v_u_628, "")
	local v_u_1244 = v_u_232(v_u_628, "Bosses: no raid running.")
	v_u_1244.Name = "BossStatus"
	local v_u_1245 = false
	local function v_u_1248() -- name: refreshBosses
		-- upvalues: (ref) v_u_1245, (ref) v_u_11, (copy) v_u_1244, (copy) p_u_47
		if v_u_1245 then
			return
		elseif v_u_11:GetAttribute("Place") == "Raid" then
			v_u_1245 = true
			p_u_47.callQuiet("raid.bosses", {}, function(p1246)
				-- upvalues: (ref) v_u_1245, (ref) v_u_1244
				v_u_1245 = false
				if p1246 and p1246.ok then
					local v1247 = p1246.msg
					if type(v1247) == "string" then
						v_u_1244.Text = p1246.msg
					end
				end
			end)
		else
			v_u_1244.Text = "Bosses: no raid running."
		end
	end
	local v_u_1249 = nil
	local v_u_1250 = nil
	local function v_u_1256(p1251) -- name: setLeft
		-- upvalues: (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
		local v1252 = p_u_47.call
		local v1253 = {}
		local v1254 = p1251 + 0.5
		local v1255 = math.floor(v1254)
		v1253.left = math.max(0, v1255)
		v1253.protect = v_u_629
		v1252("raid.clock", v1253, function()
			-- upvalues: (ref) v_u_1221
			v_u_1221()
		end)
	end
	local function v_u_1260(p1257) -- name: requestLeft
		-- upvalues: (copy) v_u_647, (copy) v_u_50, (ref) v_u_1250, (ref) v_u_1249, (copy) v_u_628, (copy) v_u_1256
		if v_u_647() then
			if p1257 <= 0.5 then
				v_u_1250 = 0
				v_u_1249.Visible = true
				v_u_50.status("Confirm: end the raid now?", "danger")
				task.delay(0.05, function()
					-- upvalues: (ref) v_u_628, (ref) v_u_1249
					if v_u_628:IsA("ScrollingFrame") and v_u_1249.Visible then
						local v1258 = v_u_1249.AbsolutePosition.Y + v_u_1249.AbsoluteSize.Y - (v_u_628.AbsolutePosition.Y + v_u_628.AbsoluteWindowSize.Y)
						if v1258 > 0 then
							local v1259 = v_u_628
							v1259.CanvasPosition = v1259.CanvasPosition + Vector2.new(0, v1258 + 8)
						end
					end
				end)
			else
				v_u_1249.Visible = false
				v_u_1256(p1257)
			end
		else
			v_u_50.status("No raid running.", "danger")
			return
		end
	end
	local v1261 = v_u_236(v_u_628, 38)
	local v1262, v_u_1263 = v_u_7.input({
		["parent"] = nil,
		["name"] = "ClockTime",
		["width"] = 120,
		["placeholder"] = "m:ss left",
		["parent"] = v1261
	})
	v_u_224[v1261] = (v_u_224[v1261] or 0) + 1
	v1262.LayoutOrder = v_u_224[v1261]
	local v1264 = v_u_15 - 126
	local v1266, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Set time left",
		["kind"] = "primary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1261,
		["width"] = v1264,
		["onClick"] = function()
			-- upvalues: (copy) v_u_643, (copy) v_u_1263, (copy) v_u_50, (copy) v_u_1260
			local v1265 = v_u_643(v_u_1263.Text)
			if v1265 then
				v_u_1260(v1265)
			else
				v_u_50.status("Time left: seconds or m:ss.", "danger")
			end
		end,
		["maxTextWidth"] = (v1264 or 140) - 12
	})
	v_u_224[v1261] = (v_u_224[v1261] or 0) + 1
	v1266.LayoutOrder = v_u_224[v1261]
	local v1267 = v_u_236(v_u_628, 32)
	local v1268 = (v_u_15 - 18) / 4
	local v1269 = math.floor(v1268)
	local v1271, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "-1 min",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1267,
		["width"] = v1269,
		["onClick"] = function()
			-- upvalues: (copy) v_u_647, (copy) v_u_1260, (copy) v_u_50
			local v1270 = v_u_647()
			if v1270 then
				v_u_1260(v1270 - 60)
			else
				v_u_50.status("No raid running.", "danger")
			end
		end,
		["maxTextWidth"] = (v1269 or 140) - 12
	})
	v_u_224[v1267] = (v_u_224[v1267] or 0) + 1
	v1271.LayoutOrder = v_u_224[v1267]
	local v1273, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "-5 min",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1267,
		["width"] = v1269,
		["onClick"] = function()
			-- upvalues: (copy) v_u_647, (copy) v_u_1260, (copy) v_u_50
			local v1272 = v_u_647()
			if v1272 then
				v_u_1260(v1272 - 300)
			else
				v_u_50.status("No raid running.", "danger")
			end
		end,
		["maxTextWidth"] = (v1269 or 140) - 12
	})
	v_u_224[v1267] = (v_u_224[v1267] or 0) + 1
	v1273.LayoutOrder = v_u_224[v1267]
	local function v1275()
		-- upvalues: (copy) v_u_647, (copy) v_u_50, (ref) v_u_1249, (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
		if v_u_647() then
			v_u_1249.Visible = false
			local v1274 = {
				["left"] = 60,
				["protect"] = nil,
				["protect"] = v_u_629
			}
			p_u_47.call("raid.clock", v1274, function()
				-- upvalues: (ref) v_u_1221
				v_u_1221()
			end)
		else
			v_u_50.status("No raid running.", "danger")
		end
	end
	local v1276, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "1:00 left",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1267,
		["width"] = v1269,
		["onClick"] = v1275,
		["maxTextWidth"] = (v1269 or 140) - 12
	})
	v_u_224[v1267] = (v_u_224[v1267] or 0) + 1
	v1276.LayoutOrder = v_u_224[v1267]
	local function v1278()
		-- upvalues: (copy) v_u_647, (copy) v_u_50, (ref) v_u_1249, (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
		if v_u_647() then
			v_u_1249.Visible = false
			local v1277 = {
				["left"] = 10,
				["protect"] = nil,
				["protect"] = v_u_629
			}
			p_u_47.call("raid.clock", v1277, function()
				-- upvalues: (ref) v_u_1221
				v_u_1221()
			end)
		else
			v_u_50.status("No raid running.", "danger")
		end
	end
	local v1279, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "0:10 left",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1267,
		["width"] = v1269,
		["onClick"] = v1278,
		["maxTextWidth"] = (v1269 or 140) - 12
	})
	v_u_224[v1267] = (v_u_224[v1267] or 0) + 1
	v1279.LayoutOrder = v_u_224[v1267]
	local v1280 = v_u_236(v_u_628, 32)
	local v1281 = v_u_15
	local v1282, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "0:00 (end now)",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1280,
		["width"] = v1281,
		["onClick"] = function()
			-- upvalues: (copy) v_u_1260
			v_u_1260(0)
		end,
		["maxTextWidth"] = (v1281 or 140) - 12
	})
	v_u_224[v1280] = (v_u_224[v1280] or 0) + 1
	v1282.LayoutOrder = v_u_224[v1280]
	v_u_1249 = v_u_7.new("Frame", {
		["Name"] = "ConfirmEnd",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_9.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_628)
	v_u_224[v_u_628] = (v_u_224[v_u_628] or 0) + 1
	v_u_1249.LayoutOrder = v_u_224[v_u_628]
	v_u_7.stroke(v_u_1249, v_u_9.danger)
	v_u_7.pad(v_u_1249, {
		10,
		10,
		8,
		8
	})
	v_u_7.layout(v_u_1249, "v", 6)
	v_u_7.label({
		["parent"] = nil,
		["text"] = "End the raid now? Everyone still inside goes missing in action, like a normal timeout. Protected players keep everything.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_1249,
		["color"] = v_u_9.text,
		["size"] = UDim2.new(1, 0, 0, 0)
	}).LayoutOrder = 1
	local v1283 = v_u_7.new("Frame", {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Size"] = UDim2.new(1, 0, 0, 32)
	}, v_u_1249)
	v_u_7.layout(v1283, "h", 6)
	local v1284 = (v_u_15 - 20 - 6) / 2
	local v1285 = math.floor(v1284)
	local function v1286()
		-- upvalues: (ref) v_u_1250, (ref) v_u_1249, (copy) v_u_50
		v_u_1250 = nil
		v_u_1249.Visible = false
		v_u_50.status("Raid clock unchanged.")
	end
	local v1287, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "Cancel",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1283,
		["width"] = v1285,
		["onClick"] = v1286,
		["maxTextWidth"] = (v1285 or 140) - 12
	})
	v_u_224[v1283] = (v_u_224[v1283] or 0) + 1
	v1287.LayoutOrder = v_u_224[v1283]
	local function v1289()
		-- upvalues: (ref) v_u_1249, (ref) v_u_1250, (copy) p_u_47, (ref) v_u_629, (copy) v_u_1221
		v_u_1249.Visible = false
		if v_u_1250 ~= nil then
			v_u_1250 = nil
			local v1288 = {
				["left"] = 0,
				["protect"] = nil,
				["protect"] = v_u_629
			}
			p_u_47.call("raid.clock", v1288, function()
				-- upvalues: (ref) v_u_1221
				v_u_1221()
			end)
		end
	end
	local v1290, _ = v_u_7.button({
		["parent"] = nil,
		["text"] = "End raid",
		["kind"] = "danger",
		["height"] = 32,
		["width"] = nil,
		["onClick"] = nil,
		["maxTextWidth"] = nil,
		["parent"] = v1283,
		["width"] = v1285,
		["onClick"] = v1289,
		["maxTextWidth"] = (v1285 or 140) - 12
	})
	v_u_224[v1283] = (v_u_224[v1283] or 0) + 1
	v1290.LayoutOrder = v_u_224[v1283]
	v_u_232(v_u_628, "Presets apply at once; the field + SET takes any time left. Moving the clock keeps the siren and the last-minute warning right; 0:00 ends the raid exactly like the timeout.")
	local function v1311()
		-- upvalues: (copy) v_u_647, (copy) v_u_1242, (ref) v_u_9, (ref) v_u_5, (ref) v_u_1, (copy) v_u_637, (copy) v_u_1243, (ref) v_u_630, (copy) v_u_631, (copy) v_u_1222, (copy) v_u_1197
		local v1291 = v_u_647()
		if v1291 then
			local v1292 = v_u_1242
			local v1293 = v1291 + 0.5
			local v1294 = math.floor(v1293)
			local v1295 = math.max(0, v1294)
			v1292.Text = string.format("%d:%02d", v1295 // 60, v1295 % 60) .. " left"
			local v1296 = v_u_1242
			local v1297
			if v1291 <= 60 then
				v1297 = v_u_9.danger
			else
				v1297 = v_u_9.text
			end
			v1296.TextColor3 = v1297
			local v1298 = v_u_5:FindFirstChild("HushRuntime")
			if v1298 then
				v1298 = v1298:FindFirstChild("Raid")
			end
			if v1298 then
				v1298 = v1298:GetAttribute("SirenAt")
			end
			local v1299
			if type(v1298) == "number" then
				local v1300 = v1298 - v_u_1.now()
				if v1300 > 0 then
					local v1301 = v1300 + 0.5
					local v1302 = math.floor(v1301)
					local v1303 = math.max(0, v1302)
					v1299 = ("Siren in %s (at %s left)"):format(string.format("%d:%02d", v1303 // 60, v1303 % 60), v_u_637(v1291 - v1300))
				else
					v1299 = "Siren sounded"
				end
				if v1291 <= 60 then
					v1299 = v1299 .. ", last minute"
				end
			else
				v1299 = ""
			end
			v_u_1243.Text = v1299
		else
			v_u_1242.Text = "No raid running."
			v_u_1242.TextColor3 = v_u_9.muted
			v_u_1243.Text = ""
		end
		local v1304 = v_u_630
		if v1304 then
			v1304 = v_u_631[v_u_630]
		end
		local v1305 = v_u_1222
		local v1306
		if v1304 and v1304.data then
			local v1307 = v1304.data.displayName
			local v1308 = tostring(v1307)
			local v1309 = v1304.data.name
			v1306 = ("Selected: %s (@%s)"):format(v1308, (tostring(v1309)))
		else
			v1306 = "Selected: nobody"
		end
		v1305.Text = v1306
		for _, v1310 in v_u_631 do
			v_u_1197(v1310)
		end
	end
	table.insert(v_u_51, v1311)
	task.spawn(function()
		-- upvalues: (ref) v_u_632, (copy) v_u_48, (copy) v_u_628, (copy) v_u_1221, (copy) v_u_1248
		local v1312 = false
		local v1313 = 0
		while v_u_632 do
			local v1314 = v_u_48.Enabled
			if v1314 then
				v1314 = v_u_628.Visible
			end
			if v1314 and (not v1312 or os.clock() - v1313 >= 1) then
				v1313 = os.clock()
				v_u_1221()
				v_u_1248()
			end
			task.wait(0.2)
			v1312 = v1314
		end
	end)
	function v_u_50.setVisible(p1315) -- name: setVisible
		-- upvalues: (copy) v_u_48, (copy) v_u_50
		v_u_48.Enabled = p1315
		if p1315 then
			v_u_50.sync()
		end
	end
	function v_u_50.isVisible() -- name: isVisible
		-- upvalues: (copy) v_u_48
		return v_u_48.Enabled
	end
	function v_u_50.sync() -- name: sync
		-- upvalues: (copy) v_u_51
		for _, v1316 in v_u_51 do
			pcall(v1316)
		end
	end
	function v_u_50.select(p1317) -- name: select
		-- upvalues: (copy) v_u_155
		v_u_155.select(p1317)
	end
	function v_u_50.destroy() -- name: destroy
		-- upvalues: (copy) v_u_48
		v_u_48:Destroy()
	end
	return v_u_50
end
return v_u_10