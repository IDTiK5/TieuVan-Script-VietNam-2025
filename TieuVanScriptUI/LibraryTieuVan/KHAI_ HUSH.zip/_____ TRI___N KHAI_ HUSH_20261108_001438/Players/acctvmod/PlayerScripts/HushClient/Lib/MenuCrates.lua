-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCrates

local v_u_1 = {}
local v2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v2:WaitForChild("Skins"))
local v_u_4 = require(v2:WaitForChild("CaseOdds"))
local v5 = require(v2:WaitForChild("SkinRules"))
local v_u_6 = {
	"COMMON",
	"UNCOMMON",
	"RARE",
	"EPIC",
	"LEGENDARY",
	"MYTHIC",
	"SIGNATURE"
}
v_u_1.TEXT = {
	["title"] = "SKINS",
	["getKeys"] = "GET KEYS",
	["open"] = "OPEN",
	["odds"] = "ODDS",
	["loading"] = "Loading your cases...",
	["error"] = "Cases could not be loaded. Try again in a moment.",
	["disabled"] = "Cases are not open right now.",
	["empty"] = "No cases yet. Get one on the Market or find it in raids: safes, lockers, duffel bags.",
	["howTitle"] = "HOW IT WORKS",
	["step1"] = "GET A CASE",
	["step1Body"] = "Buy one on the MARKET or find it in raids (safes, lockers, duffel bags).",
	["step1Raids"] = "Cases turn up in raids (safes, lockers, duffel bags).",
	["step2"] = "HAVE A KEY",
	["step2Body"] = "Keys come from the store (GET KEYS).",
	["step2Cash"] = "OR PAY CASH",
	["step2CashBody"] = "Some cases open for cash instead of a key (OPEN WITH on the card).",
	["step3"] = "OPEN IT",
	["step3Body"] = "Case plus key, or cash where the case allows it.",
	["needCase"] = "NEED A CASE",
	["needKey"] = "NEED A KEY",
	["findMarket"] = "FIND ON THE MARKET",
	["orRaids"] = "or find it in raids: safes, lockers, duffel bags",
	["needCaseFirst"] = "You need the case first",
	["keysOnly"] = "Keys are sold here. Cases are not sold on their own: get them on the Market or find them in raids.",
	["restricted"] = v5.TEXT.restrictedTab,
	["pending"] = v5.TEXT.notNow,
	["contents"] = "CONTENTS",
	["recent"] = "RECENT",
	["fine"] = "Chances are exact. Skins are cosmetic and change no stats. Cases come from the Market or from raids.",
	["noRecent"] = "Nothing opened yet.",
	["opened"] = "Opened.",
	["openCash"] = "OPEN WITH",
	["cashTitle"] = "OPEN WITH CASH",
	["cancel"] = "Cancel"
}
function v_u_1.money(p7) -- name: money
	local v8 = tonumber(p7) or 0
	local v9 = math.floor(v8)
	local v10 = math.abs(v9)
	local v11 = tostring(v10)
	local v12 = ""
	while #v11 > 3 do
		v12 = "," .. string.sub(v11, -3) .. v12
		local v13 = #v11 - 3
		v11 = string.sub(v11, 1, v13)
	end
	return (v9 < 0 and "-$" or "$") .. v11 .. v12
end
function v_u_1.cashButtonText(p14) -- name: cashButtonText
	-- upvalues: (copy) v_u_1
	return ("%s %s"):format(v_u_1.TEXT.openCash, v_u_1.money(p14.cashPrice))
end
function v_u_1.cashConfirmText(p15, p16) -- name: cashConfirmText
	-- upvalues: (copy) v_u_1
	local v17 = v_u_1.money(p15.cashPrice)
	local v18 = p15.name or "CASE"
	return ("Pay %s cash to open one %s. The chances are the same as with a key, see ODDS. Each further opening costs %s again. You have %s."):format(v17, tostring(v18), v_u_1.money(p15.cashPrice), v_u_1.money(p16))
end
function v_u_1.cashExtra(p19, p20) -- name: cashExtra
	if type(p19) ~= "table" or p19.cashOpen ~= true then
		return 0
	end
	local v21 = p20 + 8
	local v22
	if p19.canCash == true then
		v22 = 0
	else
		local v23 = p19.whyCash
		v22 = type(v23) == "string" and p19.whyCash ~= "" and 22 or 0
	end
	return v21 + v22
end
function v_u_1.cardState(p24, p25) -- name: cardState
	if type(p24) ~= "table" then
		return "blocked"
	end
	if type(p25) ~= "table" or (p25.enabled ~= true or (p25.resolved == false or p25.restricted == true)) then
		return "blocked"
	end
	if p24.canOpen == true then
		return "ready"
	end
	local v26 = p24.count
	local v27 = tonumber(v26) or 0
	if math.floor(v27) < 1 then
		return "nocase"
	end
	local v28 = p24.keys
	local v29 = tonumber(v28) or 0
	return math.floor(v29) < 1 and "nokey" or "blocked"
end
function v_u_1.openMarket(p_u_30, p_u_31) -- name: openMarket
	return pcall(function()
		-- upvalues: (copy) p_u_31
		p_u_31.controllers.Menu.openMarket("crates")
	end) and true or pcall(function()
		-- upvalues: (copy) p_u_30
		p_u_30.setTab("market")
	end)
end
function v_u_1.openLabel(p32) -- name: openLabel
	-- upvalues: (copy) v_u_1
	if p32 == "nocase" then
		return v_u_1.TEXT.needCase
	elseif p32 == "nokey" then
		return v_u_1.TEXT.needKey
	else
		return v_u_1.TEXT.open
	end
end
function v_u_1.howSteps(p33) -- name: howSteps
	-- upvalues: (copy) v_u_1
	local v34 = v_u_1.TEXT
	local v35 = v_u_1.showGetKeys(p33)
	local v36
	if type(p33) == "table" then
		v36 = p33.restricted == true
	else
		v36 = false
	end
	local v37 = {}
	local v38 = {
		["n"] = 1,
		["head"] = nil,
		["body"] = nil,
		["head"] = v34.step1
	}
	local v39
	if v36 then
		v39 = v34.step1Raids
	else
		v39 = v34.step1Body
	end
	v38.body = v39
	local v40
	if v35 then
		v40 = {
			["n"] = 2,
			["head"] = nil,
			["body"] = nil,
			["head"] = v34.step2,
			["body"] = v34.step2Body
		}
	else
		v40 = {
			["n"] = 2,
			["head"] = nil,
			["body"] = nil,
			["head"] = v34.step2Cash,
			["body"] = v34.step2CashBody
		}
	end
	__set_list(v37, 1, {v38, v40, {
	["n"] = 3,
	["head"] = nil,
	["body"] = nil,
	["head"] = v34.step3,
	["body"] = v34.step3Body
}})
	return v37
end
function v_u_1.ctaExtra(p41, p42, p43, p44) -- name: ctaExtra
	if p41 == "nocase" then
		return (p44 == false and 0 or p43 + 8) + 4 + 18 + 8
	else
		return (p41 ~= "nokey" or not p42) and 0 or p43 + 8
	end
end
function v_u_1.state(p45) -- name: state
	if type(p45) ~= "table" then
		return "loading"
	end
	if p45.enabled ~= true then
		return "disabled"
	end
	if p45.resolved == false then
		return "pending"
	end
	if p45.restricted == true then
		return "restricted"
	end
	local v46 = 0
	for _, v47 in p45.crates or {} do
		local v48 = v47.count
		local v49 = tonumber(v48) or 0
		local v50 = v47.held
		v46 = v46 + (v49 + (tonumber(v50) or 0))
	end
	return v46 == 0 and "empty" or "ready"
end
function v_u_1.notice(p51) -- name: notice
	-- upvalues: (copy) v_u_1
	local v52 = v_u_1.state(p51)
	if v52 == "disabled" then
		return v_u_1.TEXT.disabled
	elseif v52 == "pending" then
		if type(p51) == "table" then
			local v53 = p51.pendingText
			if type(v53) == "string" and p51.pendingText ~= "" then
				return p51.pendingText
			end
		end
		return v_u_1.TEXT.pending
	elseif v52 == "restricted" then
		if type(p51) == "table" then
			local v54 = p51.restrictedText
			if type(v54) == "string" and p51.restrictedText ~= "" then
				return p51.restrictedText
			end
		end
		return v_u_1.TEXT.restricted
	elseif v52 == "empty" then
		return v_u_1.TEXT.empty
	else
		return nil
	end
end
function v_u_1.showGetKeys(p55) -- name: showGetKeys
	local v56
	if type(p55) == "table" and (p55.enabled == true and p55.resolved ~= false) then
		v56 = p55.restricted ~= true
	else
		v56 = false
	end
	return v56
end
function v_u_1.showTab(p57, p58) -- name: showTab
	return p57 == true and true or p58 == true
end
function v_u_1.keyLine(p59) -- name: keyLine
	local v60 = p59.keyName or "KEY"
	local v61 = tostring(v60)
	local v62 = string.gsub(v61, " KEY$", "")
	local v63 = p59.keys
	local v64 = tonumber(v63) or 0
	return ("Key: %s  (you have %d)"):format(v62, (math.floor(v64)))
end
function v_u_1.stashLine(p65) -- name: stashLine
	local v66 = p65.count
	local v67 = tonumber(v66) or 0
	local v68 = ("In your stash: %d"):format((math.floor(v67)))
	local v69 = p65.held
	local v70 = tonumber(v69) or 0
	local v71 = math.floor(v70)
	if v71 > 0 then
		v68 = v68 .. ("  (%d waiting for room)"):format(v71)
	end
	local v72 = p65.mail
	local v73 = tonumber(v72) or 0
	local v74 = math.floor(v73)
	if v74 > 0 then
		v68 = v68 .. ("  (%d in your MAIL)"):format(v74)
	end
	return v68
end
function v_u_1.groupChips(p75) -- name: groupChips
	-- upvalues: (copy) v_u_6
	local v76 = {}
	for _, v77 in p75.groups or {} do
		local v78 = {
			["rarity"] = v77.rarity,
			["name"] = v_u_6[v77.rarity] or "?",
			["pct"] = v77.pct
		}
		table.insert(v76, v78)
	end
	return v76
end
function v_u_1.poolRows(p79, p80) -- name: poolRows
	-- upvalues: (copy) v_u_3
	local v81 = {}
	for _, v82 in p79.pool or {} do
		local v83 = v_u_3.get(v82.skin)
		local v84 = {
			["skin"] = v82.skin
		}
		local v85 = v_u_3.weaponName(v82.weapon)
		if not v85 then
			local v86 = v82.weapon
			v85 = tostring(v86)
		end
		v84.weaponName = v85
		local v87
		if v83 then
			v87 = v83.name
		else
			local v88 = v82.name
			v87 = tostring(v88)
		end
		v84.name = v87
		v84.rarity = v82.rarity
		v84.w = v82.w
		v84.pct = v82.pct
		v84.swatch = v82.swatch
		local v89
		if type(p80) == "table" then
			v89 = p80[v82.skin] == true
		else
			v89 = false
		end
		v84.owned = v89
		table.insert(v81, v84)
	end
	table.sort(v81, function(p90, p91)
		if p90.rarity == p91.rarity then
			if p90.w == p91.w then
				return p90.skin < p91.skin
			else
				return p90.w < p91.w
			end
		else
			return p90.rarity > p91.rarity
		end
	end)
	return v81
end
function v_u_1.recentLine(p92) -- name: recentLine
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v93 = v_u_3.get(p92.s)
	local v94 = p92.t
	local v95 = (type(v94) ~= "number" or p92.t <= 0) and "00:00" or os.date("!%H:%M", p92.t)
	local v96
	if v93 then
		v96 = v_u_3.displayName(v93)
	else
		local v97 = p92.s or "?"
		v96 = tostring(v97)
	end
	if p92.c == "salvage" or p92.k == "salvage" then
		return ("%s  Finish added  %s"):format(v95, v96)
	end
	local v98 = v_u_4.get(p92.c)
	local v99 = v93 and (v_u_3.RARITY_NAMES[v93.rarity] or "") or ""
	local v100 = ("%s  %s  %s  (%s)"):format(v95, not v98 and "CASE" or v98.name, v96, v99)
	if p92.d == true then
		v100 = v100 .. "  DUPLICATE"
	end
	return v100
end
function v_u_1.new(p_u_101, p_u_102) -- name: new
	-- upvalues: (copy) v_u_1
	local v_u_103 = p_u_101.ui
	local v104 = p_u_101.theme
	local v_u_105 = v104.color
	local v_u_106 = p_u_101.kit
	local v_u_107 = p_u_101.cctx
	local v_u_108 = p_u_101.compact()
	local v_u_109 = v104.isPhone()
	local v_u_110 = {
		["api"] = {}
	}
	local v_u_111 = true
	local v_u_112 = false
	local v_u_113 = nil
	local v_u_114 = false
	local v_u_115 = nil
	local v_u_116 = nil
	local v_u_117 = 0
	local v118 = v104.touch(34)
	local _, v119 = v_u_103.panel({
		["parent"] = nil,
		["name"] = "Skins",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 16,
		["parent"] = p_u_102,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v120 = v_u_103.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v118)
	}, v119)
	v_u_103.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h2",
		["size"] = nil,
		["name"] = "Title",
		["parent"] = v120,
		["text"] = v_u_1.TEXT.title,
		["size"] = UDim2.new(0, 160, 1, 0)
	})
	local v_u_121 = v_u_103.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v118 + 12),
		["Size"] = UDim2.new(1, 0, 1, -(v118 + 12))
	}, v119)
	local function v_u_125() -- name: busy
		-- upvalues: (copy) v_u_107
		local function v122()
			-- upvalues: (ref) v_u_107
			return v_u_107.lib.CrateWindow
		end
		local v123, v124 = pcall(v122)
		if v123 then
			if v124 == nil then
				v123 = false
			else
				v123 = v124.opening() == true
			end
		end
		return v123
	end
	local function v_u_138() -- name: ensureSkins
		-- upvalues: (ref) v_u_115, (copy) v_u_107, (copy) p_u_101, (copy) v_u_109, (copy) v_u_108, (ref) v_u_113, (copy) v_u_125, (ref) v_u_116, (copy) v_u_121
		if v_u_115 then
			return
		else
			local function v126()
				-- upvalues: (ref) v_u_107
				return v_u_107.lib.MenuCratesSkins
			end
			local v127, v128 = pcall(v126)
			if v127 and v128 then
				local v129 = v128.new
				local v130 = p_u_101
				local v135 = {
					["phone"] = v_u_109,
					["compact"] = v_u_108,
					["view"] = function() -- name: view
						-- upvalues: (ref) v_u_113
						return v_u_113
					end,
					["busy"] = v_u_125,
					["equip"] = function(p131, p132) -- name: equip
						-- upvalues: (ref) v_u_113, (ref) p_u_101, (ref) v_u_115
						if v_u_113 then
							v_u_113.equipped[p131] = p132
						end
						p_u_101.op({
							["op"] = "skinEquip",
							["weapon"] = nil,
							["skin"] = nil,
							["weapon"] = p131,
							["skin"] = p132
						})
						if v_u_115 then
							v_u_115.draw()
						end
					end,
					["unequip"] = function(p133) -- name: unequip
						-- upvalues: (ref) v_u_113, (ref) p_u_101, (ref) v_u_115
						if v_u_113 then
							v_u_113.equipped[p133] = nil
						end
						p_u_101.op({
							["op"] = "skinUnequip",
							["weapon"] = nil,
							["weapon"] = p133
						})
						if v_u_115 then
							v_u_115.draw()
						end
					end,
					["scrapCopy"] = function(p134) -- name: scrapCopy
						-- upvalues: (ref) v_u_116, (ref) p_u_101
						v_u_116 = p134
						p_u_101.op({
							["op"] = "skinScrapCopy",
							["skin"] = nil,
							["skin"] = p134
						})
					end
				}
				local v136, v137 = pcall(v129, v130, v135)
				if v136 then
					v_u_115 = v137
					v_u_115.frame.Parent = v_u_121
				else
					warn("[MenuCrates] the skins view failed: " .. tostring(v137))
				end
			else
				return
			end
		end
	end
	function v_u_110.draw() -- name: draw
		-- upvalues: (ref) v_u_111, (copy) p_u_102, (copy) v_u_121, (ref) v_u_115, (ref) v_u_113, (ref) v_u_114, (copy) v_u_106, (copy) p_u_101, (ref) v_u_1, (copy) v_u_103, (copy) v_u_105, (copy) v_u_138
		if v_u_111 and p_u_102.Parent then
			for _, v139 in v_u_121:GetChildren() do
				local v140 = v_u_115
				if v140 then
					v140 = v_u_115.frame
				end
				if v139 == v140 then
					continue
				end
				v139:Destroy()
			end
			if v_u_113 == nil then
				if v_u_115 then
					v_u_115.frame.Visible = false
				end
				if v_u_114 then
					v_u_106.empty(v_u_121, p_u_101.failText("crates", v_u_1.TEXT.error))
				else
					v_u_103.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["parent"] = v_u_121,
						["text"] = v_u_1.TEXT.loading,
						["color"] = v_u_105.muted
					})
				end
			else
				v_u_138()
				if v_u_115 then
					v_u_115.frame.Visible = true
					v_u_115.draw()
				end
				return
			end
		else
			return
		end
	end
	function v_u_110.api.showSkins(p141)
		-- upvalues: (ref) v_u_115
		if type(p141) == "string" and v_u_115 then
			v_u_115.pick(p141)
		end
	end
	function v_u_110.api.state()
		-- upvalues: (ref) v_u_115, (ref) v_u_1, (ref) v_u_113
		return {
			["skins"] = v_u_115 ~= nil,
			["state"] = v_u_1.state(v_u_113),
			["crates"] = v_u_113 and #v_u_113.crates or 0
		}
	end
	function v_u_110.api.skins()
		-- upvalues: (ref) v_u_115
		return v_u_115
	end
	function v_u_110.api.view()
		-- upvalues: (ref) v_u_113
		return v_u_113
	end
	function v_u_110.show() -- name: show
		-- upvalues: (ref) v_u_112, (copy) v_u_110, (ref) v_u_117, (copy) p_u_101, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (copy) p_u_102
		v_u_112 = true
		v_u_110.draw()
		v_u_117 = v_u_117 + 1
		local v_u_142 = v_u_117
		local v_u_143 = 5
		task.spawn(function()
			-- upvalues: (ref) p_u_101, (copy) v_u_143, (copy) v_u_142, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
			local v144 = p_u_101.fetch("crates", nil, v_u_143 or 0)
			if v_u_142 == v_u_117 and v_u_111 then
				if type(v144) == "table" then
					v_u_113 = v144
					v_u_114 = false
				else
					v_u_114 = v_u_113 == nil
				end
				if v_u_112 and p_u_102.Parent then
					v_u_110.draw()
				end
			end
		end)
	end
	function v_u_110.hide() -- name: hide
		-- upvalues: (ref) v_u_112
		v_u_112 = false
	end
	function v_u_110.refresh(p145, _) -- name: refresh
		-- upvalues: (ref) v_u_112, (ref) v_u_117, (copy) p_u_101, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (copy) p_u_102, (copy) v_u_110
		if p145 == "profile" and v_u_112 then
			v_u_117 = v_u_117 + 1
			local v_u_146 = v_u_117
			local v_u_147 = 5
			task.spawn(function()
				-- upvalues: (ref) p_u_101, (copy) v_u_147, (copy) v_u_146, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
				local v148 = p_u_101.fetch("crates", nil, v_u_147 or 0)
				if v_u_146 == v_u_117 and v_u_111 then
					if type(v148) == "table" then
						v_u_113 = v148
						v_u_114 = false
					else
						v_u_114 = v_u_113 == nil
					end
					if v_u_112 and p_u_102.Parent then
						v_u_110.draw()
					end
				end
			end)
		end
	end
	local v_u_149
	if p_u_101.changed and p_u_101.changed.Connect then
		v_u_149 = p_u_101.changed:Connect(function(p150, p151)
			-- upvalues: (ref) v_u_116, (ref) v_u_115, (copy) v_u_107, (copy) p_u_101, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (copy) p_u_102, (copy) v_u_110
			if p150 == "result" and type(p151) == "table" then
				if p151.op == "skinEquip" or (p151.op == "skinUnequip" or (p151.op == "skinScrapCopy" or p151.op == "storeGrant")) then
					if p151.op == "skinScrapCopy" and p151.ok == false then
						local v152 = p151.data
						if type(v152) == "table" and (p151.data.code == "PICK" and (v_u_116 and (v_u_115 and v_u_115.openCopies))) then
							local v153 = v_u_115.openCopies
							local v154 = v_u_116
							pcall(v153, v154)
						end
					end
					local function v155()
						-- upvalues: (ref) v_u_107
						return v_u_107.lib.CrateWindow
					end
					local v156, v157 = pcall(v155)
					if v156 then
						if v157 == nil then
							v156 = false
						else
							v156 = v157.opening() == true
						end
					end
					if not v156 then
						p_u_101.invalidate("crates")
						v_u_117 = v_u_117 + 1
						local v_u_158 = v_u_117
						local v_u_159 = 0
						task.spawn(function()
							-- upvalues: (ref) p_u_101, (copy) v_u_159, (copy) v_u_158, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
							local v160 = p_u_101.fetch("crates", nil, v_u_159 or 0)
							if v_u_158 == v_u_117 and v_u_111 then
								if type(v160) == "table" then
									v_u_113 = v160
									v_u_114 = false
								else
									v_u_114 = v_u_113 == nil
								end
								if v_u_112 and p_u_102.Parent then
									v_u_110.draw()
								end
							end
						end)
					end
				end
			end
		end)
	else
		v_u_149 = nil
	end
	function v_u_110.destroy() -- name: destroy
		-- upvalues: (ref) v_u_111, (ref) v_u_117, (ref) v_u_149, (ref) v_u_115
		v_u_111 = false
		v_u_117 = v_u_117 + 1
		if v_u_149 then
			local function v161()
				-- upvalues: (ref) v_u_149
				v_u_149:Disconnect()
			end
			pcall(v161)
		end
		if v_u_115 then
			local v162 = v_u_115.destroy
			pcall(v162)
			v_u_115 = nil
		end
	end
	if v_u_107.command and not p_u_101._crateCmds then
		p_u_101._crateCmds = true
		v_u_107.command("crates.skin", function(p163)
			-- upvalues: (copy) p_u_101
			local v164 = p_u_101._crateTab
			local v165
			if v164 then
				v165 = v164.api.skins()
			else
				v165 = nil
			end
			if not v165 then
				return "no skins page (open it first: menu.openskins)"
			end
			v165.pick(p163[1], p163[2])
			local v166 = v165.state()
			local v167 = v166.weapon
			local v168 = tostring(v167)
			local v169 = v166.skin
			return ("weapon=%s skin=%s"):format(v168, (tostring(v169)))
		end)
	end
	p_u_101._crateTab = v_u_110
	task.spawn(function()
		-- upvalues: (copy) v_u_107, (ref) v_u_111, (copy) p_u_101, (ref) v_u_117, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (copy) p_u_102, (copy) v_u_110
		local v170 = v_u_107.config.watchFlag
		local function v174()
			-- upvalues: (ref) v_u_111, (ref) p_u_101, (ref) v_u_117, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
			if v_u_111 then
				p_u_101.invalidate("crates")
				v_u_117 = v_u_117 + 1
				local v_u_171 = v_u_117
				local v_u_172 = 0
				task.spawn(function()
					-- upvalues: (ref) p_u_101, (copy) v_u_172, (copy) v_u_171, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
					local v173 = p_u_101.fetch("crates", nil, v_u_172 or 0)
					if v_u_171 == v_u_117 and v_u_111 then
						if type(v173) == "table" then
							v_u_113 = v173
							v_u_114 = false
						else
							v_u_114 = v_u_113 == nil
						end
						if v_u_112 and p_u_102.Parent then
							v_u_110.draw()
						end
					end
				end)
			end
		end
		pcall(v170, "SkinCrates", v174)
	end)
	task.defer(function()
		-- upvalues: (ref) v_u_111, (ref) v_u_117, (copy) p_u_101, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (copy) p_u_102, (copy) v_u_110
		if v_u_111 then
			v_u_117 = v_u_117 + 1
			local v_u_175 = v_u_117
			local v_u_176 = 20
			task.spawn(function()
				-- upvalues: (ref) p_u_101, (copy) v_u_176, (copy) v_u_175, (ref) v_u_117, (ref) v_u_111, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112, (ref) p_u_102, (ref) v_u_110
				local v177 = p_u_101.fetch("crates", nil, v_u_176 or 0)
				if v_u_175 == v_u_117 and v_u_111 then
					if type(v177) == "table" then
						v_u_113 = v177
						v_u_114 = false
					else
						v_u_114 = v_u_113 == nil
					end
					if v_u_112 and p_u_102.Parent then
						v_u_110.draw()
					end
				end
			end)
		end
	end)
	return v_u_110
end
return v_u_1