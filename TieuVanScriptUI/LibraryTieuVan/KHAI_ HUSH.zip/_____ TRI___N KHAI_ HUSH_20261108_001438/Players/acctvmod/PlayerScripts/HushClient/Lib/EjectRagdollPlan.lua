-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EjectRagdollPlan

local v_u_1 = {
	["VERSION"] = 1,
	["TUNE"] = {
		["EARLY_S"] = 0.3,
		["PULL_S"] = 0.2,
		["STEP_S"] = 0.05,
		["FOLLOW_GAIN"] = 16,
		["SNAP_DIST"] = 7,
		["MAX_SPEED"] = 160,
		["LIE_LIFT"] = 0.6,
		["FADE_S"] = 0.15,
		["MAX_PUPPETS"] = 6,
		["MAX_SIM"] = 4,
		["MAX_POINTS"] = 400,
		["DUR_MIN"] = 0.2,
		["DUR_MAX"] = 4.5,
		["MAX_AGE"] = 10,
		["COORD_MAX"] = 100000,
		["GRAVITY"] = 196.2,
		["PEAK_MAX"] = 2.5,
		["LYING_PITCH"] = 90,
		["GROUP_EARLY"] = "HushEjectEarly",
		["GROUP_LATE"] = "HushEject",
		["GROUP_FALLBACK"] = nil,
		["GROUP_FALLBACK"] = { "HushSurvivor", "HuntRagdoll" }
	}
}
local v_u_2 = v_u_1.TUNE
local function v_u_20(p3, p4, p5, p6) -- name: vec
	-- upvalues: (copy) v_u_2
	if type(p3) ~= "table" then
		return nil
	end
	local v7 = p3.x
	if type(v7) == "number" then
		local v8 = p3.y
		if type(v8) == "number" then
			local v9 = p3.z
			if type(v9) == "number" and (p3.x == p3.x and (p3.y == p3.y and p3.z == p3.z)) then
				local v10 = {}
				local v11 = p3.x
				if type(v11) == "number" and (v11 == v11 and (v11 ~= (1 / 0) and v11 ~= (-1 / 0))) then
					p4 = v11
				end
				local v12 = -v_u_2.COORD_MAX
				local v13 = v_u_2.COORD_MAX
				if p4 < v12 then
					p4 = v12
				elseif v13 < p4 then
					p4 = v13
				end
				v10.x = p4
				local v14 = p3.y
				if type(v14) == "number" and (v14 == v14 and (v14 ~= (1 / 0) and v14 ~= (-1 / 0))) then
					p5 = v14
				end
				local v15 = -v_u_2.COORD_MAX
				local v16 = v_u_2.COORD_MAX
				if p5 < v15 then
					p5 = v15
				elseif v16 < p5 then
					p5 = v16
				end
				v10.y = p5
				local v17 = p3.z
				if type(v17) == "number" and (v17 == v17 and (v17 ~= (1 / 0) and v17 ~= (-1 / 0))) then
					p6 = v17
				end
				local v18 = -v_u_2.COORD_MAX
				local v19 = v_u_2.COORD_MAX
				if p6 < v18 then
					p6 = v18
				elseif v19 < p6 then
					p6 = v19
				end
				v10.z = p6
				return v10
			end
		end
	end
	return nil
end
local function v_u_29(p21, p22) -- name: at
	local v23 = #p21
	if p22 <= p21[1].t then
		return {
			["x"] = p21[1].x,
			["y"] = p21[1].y,
			["z"] = p21[1].z
		}
	end
	if p21[v23].t <= p22 then
		return {
			["x"] = p21[v23].x,
			["y"] = p21[v23].y,
			["z"] = p21[v23].z
		}
	end
	for v24 = 2, v23 do
		local v25 = p21[v24 - 1]
		local v26 = p21[v24]
		if p22 > v26.t then
			continue
		end
		local v27 = v26.t - v25.t
		local v28 = v27 <= 1e-9 and 1 or (p22 - v25.t) / v27
		return {
			["x"] = v25.x + (v26.x - v25.x) * v28,
			["y"] = v25.y + (v26.y - v25.y) * v28,
			["z"] = v25.z + (v26.z - v25.z) * v28
		}
	end
	return {
		["x"] = p21[v23].x,
		["y"] = p21[v23].y,
		["z"] = p21[v23].z
	}
end
local function v_u_48(p30) -- name: synth
	-- upvalues: (copy) v_u_20, (copy) v_u_2
	local v31 = v_u_20(p30.from, 0, 0, 0)
	local v32 = v_u_20(p30.to, 0, 0, 0)
	if v31 == nil or v32 == nil then
		return nil
	end
	local v33 = p30.dur
	local v34 = (type(v33) ~= "number" or (v33 ~= v33 or (v33 == (1 / 0) or v33 == (-1 / 0)))) and 0.8 or v33
	local v35 = v_u_2.DUR_MIN
	local v36 = v_u_2.DUR_MAX
	if v34 < v35 then
		v34 = v35
	elseif v36 < v34 then
		v34 = v36
	end
	local v37 = p30.vy
	local v38 = (type(v37) ~= "number" or (v37 ~= v37 or (v37 == (1 / 0) or v37 == (-1 / 0)))) and 14 or v37
	local v39 = v38 * v38 / (2 * v_u_2.GRAVITY)
	local v40 = v_u_2.PEAK_MAX
	if v39 < 0 then
		v39 = 0
	elseif v40 < v39 then
		v39 = v40
	end
	local v41 = v34 / v_u_2.STEP_S
	local v42 = math.ceil(v41)
	local v43 = math.max(2, v42)
	local v44 = {}
	for v45 = 0, v43 do
		local v46 = v45 / v43
		local v47 = {
			["x"] = v31.x + (v32.x - v31.x) * v46,
			["y"] = v31.y + (v32.y - v31.y) * v46 + v39 * 4 * v46 * (1 - v46),
			["z"] = v31.z + (v32.z - v31.z) * v46,
			["t"] = v34 * v46
		}
		table.insert(v44, v47)
	end
	return {
		["points"] = v44,
		["dur"] = v34,
		["to"] = v32
	}
end
function v_u_1.clean(p49) -- name: clean
	-- upvalues: (copy) v_u_2, (copy) v_u_20, (copy) v_u_48, (copy) v_u_29
	if type(p49) ~= "table" then
		return nil
	end
	local v50 = p49.plan
	local v51
	if type(v50) == "table" then
		v51 = p49.plan
	else
		v51 = p49
	end
	local v52 = {}
	local v53 = v51.points
	local v54, v55
	if type(v53) == "table" and #v51.points >= 2 then
		local v56 = v51.points
		local v57 = #v56
		local v58 = v_u_2.MAX_POINTS
		local v59 = math.min(v57, v58)
		local v60 = -1000000000
		for v61 = 1, v59 do
			local v62
			if v59 == v57 then
				v62 = v61
			else
				local v63 = (v61 - 1) * (v57 - 1)
				local v64 = v59 - 1
				local v65 = v63 / math.max(1, v64) + 0.5
				v62 = math.floor(v65) + 1
			end
			local v66 = v_u_20(v56[v62], 0, 0, 0)
			if v66 == nil then
				return nil
			end
			local v67 = v56[v62].t
			local v68 = v60 + v_u_2.STEP_S
			if type(v67) == "number" and (v67 == v67 and (v67 ~= (1 / 0) and v67 ~= (-1 / 0))) then
				v68 = v67
			end
			if v68 >= v60 then
				v60 = v68
			end
			v66.t = v60
			table.insert(v52, v66)
		end
		local v69 = v52[1].t
		if v69 ~= 0 then
			for _, v70 in v52 do
				v70.t = v70.t - v69
			end
		end
		local v71 = v51.dur
		v54 = v52[#v52].t
		if type(v71) == "number" and (v71 == v71 and (v71 ~= (1 / 0) and v71 ~= (-1 / 0))) then
			v54 = v71
		end
		local v72 = v_u_2.DUR_MIN
		local v73 = v_u_2.DUR_MAX
		if v54 < v72 then
			v54 = v72
		elseif v73 < v54 then
			v54 = v73
		end
		v55 = v_u_20(v51.to, 0, 0, 0) or {
			["x"] = v52[#v52].x,
			["y"] = v52[#v52].y,
			["z"] = v52[#v52].z
		}
	else
		local v74 = v_u_48(v51)
		if v74 == nil then
			return nil
		end
		v52 = v74.points
		v54 = v74.dur
		v55 = v74.to
	end
	local v75 = v52[#v52]
	if v75.t < v54 - 1e-9 then
		local v76 = {
			["x"] = v75.x,
			["y"] = v75.y,
			["z"] = v75.z,
			["t"] = v54
		}
		table.insert(v52, v76)
	end
	local v77 = v52[1]
	local v78 = v55.x - v77.x
	local v79 = v55.z - v77.z
	for v80 = #v52 - 1, 1, -1 do
		local v81 = v52[#v52].x - v52[v80].x
		local v82 = v52[#v52].z - v52[v80].z
		if v81 * v81 + v82 * v82 <= 0.25 then
			continue
		end
		v79 = v82
		v78 = v81
	end
	local v83 = -v78
	local v84 = -v79
	local v85 = math.atan2(v83, v84)
	local v86 = math.deg(v85)
	local v87 = v51.handoff
	local v88 = type(v87) ~= "table" and {} or v51.handoff
	local v89 = {
		["x"] = nil,
		["y"] = nil,
		["z"] = nil,
		["yaw"] = nil,
		["pose"] = "lying"
	}
	local v90 = v88.x
	local v91 = v55.x
	if type(v90) ~= "number" or (v90 ~= v90 or (v90 == (1 / 0) or v90 == (-1 / 0))) then
		v90 = v91
	end
	local v92 = -v_u_2.COORD_MAX
	local v93 = v_u_2.COORD_MAX
	if v90 < v92 then
		v90 = v92
	elseif v93 < v90 then
		v90 = v93
	end
	v89.x = v90
	local v94 = v88.y
	local v95 = v55.y
	if type(v94) == "number" and (v94 == v94 and (v94 ~= (1 / 0) and v94 ~= (-1 / 0))) then
		v95 = v94
	end
	local v96 = -v_u_2.COORD_MAX
	local v97 = v_u_2.COORD_MAX
	if v95 < v96 then
		v95 = v96
	elseif v97 < v95 then
		v95 = v97
	end
	v89.y = v95
	local v98 = v88.z
	local v99 = v55.z
	if type(v98) == "number" and (v98 == v98 and (v98 ~= (1 / 0) and v98 ~= (-1 / 0))) then
		v99 = v98
	end
	local v100 = -v_u_2.COORD_MAX
	local v101 = v_u_2.COORD_MAX
	if v99 < v100 then
		v99 = v100
	elseif v101 < v99 then
		v99 = v101
	end
	v89.z = v99
	local v102 = v88.yaw
	if type(v102) == "number" and (v102 == v102 and (v102 ~= (1 / 0) and v102 ~= (-1 / 0))) then
		v86 = v102
	end
	v89.yaw = v86
	local v103 = v51.pullAt
	local v104 = v54 - v_u_2.PULL_S
	if type(v103) == "number" and (v103 == v103 and (v103 ~= (1 / 0) and v103 ~= (-1 / 0))) then
		v104 = v103
	end
	if v104 < 0 then
		v104 = 0
	elseif v54 < v104 then
		v104 = v54
	end
	local v105
	if p49.at == nil then
		v105 = v51.at
	else
		v105 = p49.at
	end
	local v106 = nil
	if type(v105) == "number" and (v105 == v105 and v105 > 0) then
		if v105 >= 1000000000000 then
			v105 = v106
		end
	else
		v105 = v106
	end
	local v107 = v_u_29
	local v108 = v_u_2.STEP_S
	local v109 = v107(v52, (math.min(v108, v54)))
	local v110 = v_u_2.STEP_S
	local v111 = math.min(v110, v54)
	local v112 = math.max(1e-6, v111)
	return {
		["points"] = v52,
		["dur"] = v54,
		["to"] = v55,
		["pullAt"] = v104,
		["handoff"] = v89,
		["launch"] = {
			["x"] = (v109.x - v77.x) / v112,
			["y"] = (v109.y - v77.y) / v112,
			["z"] = (v109.z - v77.z) / v112
		},
		["at"] = v105
	}
end
function v_u_1.startAge(p113, p114) -- name: startAge
	if type(p113) == "table" then
		local v115 = p113.at
		if type(v115) == "number" then
			local v116 = p113.dur
			if type(v116) == "number" then
				if type(p114) == "number" and (p114 == p114 and (p114 ~= (1 / 0) and p114 ~= (-1 / 0))) then
					local v117 = p114 - p113.at
					local v118 = p113.dur
					if v117 < 0 then
						return 0
					elseif v118 < v117 then
						return v118
					else
						return v117
					end
				else
					return 0
				end
			end
		end
	end
	return 0
end
function v_u_1.sample(p119, p120) -- name: sample
	-- upvalues: (copy) v_u_29
	local v121 = v_u_29
	local v122 = p119.points
	local v123 = (type(p120) ~= "number" or (p120 ~= p120 or (p120 == (1 / 0) or p120 == (-1 / 0)))) and 0 or p120
	local v124 = p119.dur
	if v123 < 0 then
		v123 = 0
	elseif v124 < v123 then
		v123 = v124
	end
	return v121(v122, v123)
end
function v_u_1.velocityAt(p125, p126) -- name: velocityAt
	-- upvalues: (copy) v_u_2, (copy) v_u_29
	local v127 = (type(p126) ~= "number" or (p126 ~= p126 or (p126 == (1 / 0) or p126 == (-1 / 0)))) and 0 or p126
	local v128 = p125.dur
	if v127 < 0 then
		v127 = 0
	elseif v128 < v127 then
		v127 = v128
	end
	local v129 = v127 - v_u_2.STEP_S
	local v130 = math.max(0, v129)
	local v131 = p125.dur
	local v132 = v127 + v_u_2.STEP_S
	local v133 = math.min(v131, v132)
	local v134 = v133 - v130
	if v134 < 1e-6 then
		return {
			["x"] = 0,
			["y"] = 0,
			["z"] = 0
		}
	end
	local v135 = v_u_29(p125.points, v130)
	local v136 = v_u_29(p125.points, v133)
	return {
		["x"] = (v136.x - v135.x) / v134,
		["y"] = (v136.y - v135.y) / v134,
		["z"] = (v136.z - v135.z) / v134
	}
end
function v_u_1.pullWeight(p137, p138) -- name: pullWeight
	local v139 = p137.dur - p137.pullAt
	if v139 < 1e-6 then
		return ((type(p138) ~= "number" or (p138 ~= p138 or (p138 == (1 / 0) or p138 == (-1 / 0)))) and 0 or p138) >= p137.dur and 1 or 0
	end
	local v140 = (((type(p138) ~= "number" or (p138 ~= p138 or (p138 == (1 / 0) or p138 == (-1 / 0)))) and 0 or p138) - p137.pullAt) / v139
	local v141 = v140 < 0 and 0 or (v140 > 1 and 1 or v140)
	return v141 * v141 * (3 - v141 * 2)
end
function v_u_1.target(p142, p143) -- name: target
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v144 = v_u_1.sample(p142, p143)
	local v145 = v_u_1.pullWeight(p142, p143)
	return {
		["x"] = v144.x,
		["y"] = v144.y + v_u_2.LIE_LIFT * v145,
		["z"] = v144.z
	}
end
function v_u_1.follow(p146, _, p147, p148, p149, p150) -- name: follow
	-- upvalues: (copy) v_u_2
	local v151 = (type(p149) ~= "number" or (p149 ~= p149 or (p149 == (1 / 0) or p149 == (-1 / 0)))) and 0.016666666666666666 or p149
	local v152 = v151 < 0.001 and 0.001 or (v151 > 0.5 and 0.5 or v151)
	local v153 = v_u_2.FOLLOW_GAIN
	local v154 = (type(p150) ~= "number" or (p150 ~= p150 or (p150 == (1 / 0) or p150 == (-1 / 0)))) and 0 or p150
	local v155 = v153 * ((v154 < 0 and 0 or (v154 > 1 and 1 or v154)) + 1)
	local v156 = 0.9 / v152
	local v157 = math.min(v155, v156)
	local v158 = p147.x - p146.x
	local v159 = p147.y - p146.y
	local v160 = p147.z - p146.z
	local v161 = v158 * v158 + v159 * v159 + v160 * v160
	local v162 = math.sqrt(v161)
	local v163 = p148.x
	local v164 = ((type(v163) ~= "number" or (v163 ~= v163 or (v163 == (1 / 0) or v163 == (-1 / 0)))) and 0 or v163) + v158 * v157
	local v165 = p148.y
	local v166 = ((type(v165) ~= "number" or (v165 ~= v165 or (v165 == (1 / 0) or v165 == (-1 / 0)))) and 0 or v165) + v159 * v157
	local v167 = p148.z
	local v168 = ((type(v167) ~= "number" or (v167 ~= v167 or (v167 == (1 / 0) or v167 == (-1 / 0)))) and 0 or v167) + v160 * v157
	local v169 = v164 * v164 + v166 * v166 + v168 * v168
	local v170 = math.sqrt(v169)
	if v_u_2.MAX_SPEED < v170 then
		local v171 = v_u_2.MAX_SPEED / v170
		v164 = v164 * v171
		v166 = v166 * v171
		v168 = v168 * v171
	end
	return {
		["x"] = v164,
		["y"] = v166,
		["z"] = v168
	}, v_u_2.SNAP_DIST < v162
end
function v_u_1.phaseAt(p172, p173) -- name: phaseAt
	-- upvalues: (copy) v_u_2
	local v174 = (type(p173) ~= "number" or (p173 ~= p173 or (p173 == (1 / 0) or p173 == (-1 / 0)))) and 0 or p173
	return v174 < p172.dur and "flight" or (v174 < p172.dur + v_u_2.FADE_S and "fade" or "done")
end
function v_u_1.fadeAlpha(p175, p176) -- name: fadeAlpha
	-- upvalues: (copy) v_u_2
	local v177 = (((type(p176) ~= "number" or (p176 ~= p176 or (p176 == (1 / 0) or p176 == (-1 / 0)))) and 0 or p176) - p175.dur) / v_u_2.FADE_S
	return v177 < 0 and 0 or (v177 > 1 and 1 or v177)
end
function v_u_1.groupName(p178, p179) -- name: groupName
	-- upvalues: (copy) v_u_2
	local v180 = ((type(p178) ~= "number" or (p178 ~= p178 or (p178 == (1 / 0) or p178 == (-1 / 0)))) and 0 or p178) < v_u_2.EARLY_S
	local v181
	if v180 then
		v181 = v_u_2.GROUP_EARLY
	else
		v181 = v_u_2.GROUP_LATE
	end
	if p179 == nil then
		return nil
	end
	if p179(v181) then
		return v181
	end
	if not v180 and p179(v_u_2.GROUP_EARLY) then
		return v_u_2.GROUP_EARLY
	end
	for _, v182 in v_u_2.GROUP_FALLBACK do
		if not p179(v182) then
			continue
		end
		return v182
	end
	return nil
end
function v_u_1.lyingPose(p183) -- name: lyingPose
	-- upvalues: (copy) v_u_2
	local v184 = {}
	local v185 = p183.x
	v184.x = (type(v185) ~= "number" or (v185 ~= v185 or (v185 == (1 / 0) or v185 == (-1 / 0)))) and 0 or v185
	local v186 = p183.y
	v184.y = ((type(v186) ~= "number" or (v186 ~= v186 or (v186 == (1 / 0) or v186 == (-1 / 0)))) and 0 or v186) + v_u_2.LIE_LIFT
	local v187 = p183.z
	v184.z = (type(v187) ~= "number" or (v187 ~= v187 or (v187 == (1 / 0) or v187 == (-1 / 0)))) and 0 or v187
	local v188 = p183.yaw
	v184.yawDeg = (type(v188) ~= "number" or (v188 ~= v188 or (v188 == (1 / 0) or v188 == (-1 / 0)))) and 0 or v188
	v184.pitchDeg = v_u_2.LYING_PITCH
	return v184
end
function v_u_1.tumble(p189, p190) -- name: tumble
	-- upvalues: (copy) v_u_2
	local v191 = (type(p190) ~= "number" or (p190 ~= p190 or (p190 == (1 / 0) or p190 == (-1 / 0)))) and 0 or p190
	local v192 = p189.dur
	local v193 = v191 / math.max(v192, 1e-6)
	local v194 = v193 < 0 and 0 or (v193 > 1 and 1 or v193)
	local v195 = 1 - (1 - v194) * (1 - v194)
	return (v_u_2.LYING_PITCH - 360) * v195
end
function v_u_1.mode(p196, p197) -- name: mode
	return ((type(p196) ~= "number" or (p196 ~= p196 or (p196 == (1 / 0) or p196 == (-1 / 0)))) and 3 or p196) >= 3 and ((type(p197) ~= "number" or (p197 ~= p197 or (p197 == (1 / 0) or p197 == (-1 / 0)))) and 0 or p197) >= 4 and "joints" or "path"
end
return v_u_1