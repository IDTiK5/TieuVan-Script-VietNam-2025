-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AimPull

local v_u_177 = {
	["CONE_END"] = 12,
	["RANGE_FULL"] = 30,
	["RANGE_END"] = 40,
	["MIN_DIST"] = 1.5,
	["MAX_RATE"] = 90,
	["CLOSE_GAIN"] = 0.25,
	["CLOSE_DEG"] = 1,
	["FAR_GAIN"] = 2,
	["FAR_DEG"] = 4,
	["CORE"] = 0.5,
	["FOLLOW"] = 0.5,
	["JUMP_RATE"] = 360,
	["RAMP_IN"] = 0.3,
	["RAMP_OUT"] = 0.15,
	["LOOK_STOP"] = 3,
	["SWITCH_SHARE"] = 0.6,
	["SWITCH_MIN"] = 1.5,
	["MAX_DT"] = 0.1,
	["MIN_COS"] = 0.17,
	["new"] = function() -- name: new
		return {
			["id"] = nil,
			["w"] = 0,
			["lastYaw"] = nil,
			["lastPitch"] = nil,
			["pulls"] = 0,
			["lastDeg"] = 0,
			["lastErr"] = -1
		}
	end,
	["reset"] = function(p1) -- name: reset
		p1.id = nil
		p1.w = 0
		p1.lastYaw = nil
		p1.lastPitch = nil
		p1.lastDeg = 0
		p1.lastErr = -1
	end,
	["wrap"] = function(p2) -- name: wrap
		return (p2 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	end,
	["dirAngles"] = function(p3, p4, p5) -- name: dirAngles
		local v6 = -p3
		local v7 = -p5
		local v8 = math.atan2(v6, v7)
		local v9 = p3 * p3 + p5 * p5
		local v10 = math.sqrt(v9)
		return v8, math.atan2(p4, v10)
	end,
	["viewDir"] = function(p11, p12) -- name: viewDir
		local v13 = math.cos(p12)
		return -math.sin(p11) * v13, math.sin(p12), -math.cos(p11) * v13
	end,
	["angleDeg"] = function(p14, p15, p16, p17) -- name: angleDeg
		-- upvalues: (copy) v_u_177
		local v18, v19, v20 = v_u_177.viewDir(p14, p15)
		local v21, v22, v23 = v_u_177.viewDir(p16, p17)
		local v24 = v19 * v23 - v20 * v22
		local v25 = v20 * v21 - v18 * v23
		local v26 = v18 * v22 - v19 * v21
		local v27 = v24 * v24 + v25 * v25 + v26 * v26
		local v28 = math.sqrt(v27)
		local v29 = v18 * v21 + v19 * v22 + v20 * v23
		local v30 = math.atan2(v28, v29)
		return math.deg(v30)
	end,
	["coneWeight"] = function(p31, p32) -- name: coneWeight
		local v33
		if type(p31) == "number" and (p31 == p31 and p31 > (-1 / 0)) then
			v33 = p31 < (1 / 0)
		else
			v33 = false
		end
		if v33 then
			local v34
			if type(p32) == "number" and (p32 == p32 and p32 > (-1 / 0)) then
				v34 = p32 < (1 / 0)
			else
				v34 = false
			end
			if v34 and (p32 > 0 and p32 > p31) then
				local v35 = p32 * 0.5
				return p31 <= v35 and 1 or (p32 - p31) / (p32 - v35)
			end
		end
		return 0
	end,
	["rangeWeight"] = function(p36) -- name: rangeWeight
		-- upvalues: (copy) v_u_177
		local v37
		if type(p36) == "number" and (p36 == p36 and p36 > (-1 / 0)) then
			v37 = p36 < (1 / 0)
		else
			v37 = false
		end
		return (not v37 or (v_u_177.RANGE_END <= p36 or p36 < v_u_177.MIN_DIST)) and 0 or (p36 <= v_u_177.RANGE_FULL and 1 or (v_u_177.RANGE_END - p36) / (v_u_177.RANGE_END - v_u_177.RANGE_FULL))
	end,
	["gain"] = function(p38) -- name: gain
		-- upvalues: (copy) v_u_177
		local v39
		if type(p38) == "number" and (p38 == p38 and p38 > (-1 / 0)) then
			v39 = p38 < (1 / 0)
		else
			v39 = false
		end
		if not v39 or p38 <= v_u_177.CLOSE_DEG then
			return v_u_177.CLOSE_GAIN
		end
		if v_u_177.FAR_DEG <= p38 then
			return v_u_177.FAR_GAIN
		end
		local v40 = (p38 - v_u_177.CLOSE_DEG) / (v_u_177.FAR_DEG - v_u_177.CLOSE_DEG)
		local v41 = v40 * v40 * (3 - 2 * v40)
		return v_u_177.CLOSE_GAIN + (v_u_177.FAR_GAIN - v_u_177.CLOSE_GAIN) * v41
	end,
	["axisPoint"] = function(p42, p43, p44, p45, p46, p47, p48, p49, p50, p51) -- name: axisPoint
		local v52
		if type(p51) == "number" and (p51 == p51 and p51 > (-1 / 0)) then
			v52 = p51 < (1 / 0)
		else
			v52 = false
		end
		local v53 = (not v52 or p51 <= 0) and 0 or p51
		if v53 == 0 then
			return p48, p49, p50
		end
		local v54 = p42 - p48
		local v55 = p43 - p49
		local v56 = p44 - p50
		local v57 = 1 - p46 * p46
		local v58 = v57 <= 1e-6 and 0 or (v55 - p46 * (p45 * v54 + p46 * v55 + p47 * v56)) / v57
		local v59 = v58 ~= v58 and 0 or v58
		local v60 = -v53
		return p48, p49 + math.clamp(v59, v60, v53), p50
	end,
	["sightLines"] = function(p61, p62, p_u_63, p_u_64, p65, p66, p_u_67) -- name: sightLines
		local v_u_68 = 0
		local v_u_69 = 0
		local function v74(p70) -- name: cast
			-- upvalues: (ref) v_u_68, (copy) p_u_67, (copy) p_u_63, (ref) v_u_69, (copy) p_u_64
			v_u_68 = v_u_68 + 1
			local v71 = p_u_67
			local v72, v73 = pcall(v71, p70)
			if v72 then
				v72 = v73 == true
			end
			p70.los = v72
			if p_u_63[p70.id] == nil then
				v_u_69 = v_u_69 + 1
			end
			p_u_63[p70.id] = {
				["t"] = p_u_64,
				["ok"] = p70.los
			}
		end
		local v75
		if p62 == nil then
			v75 = v_u_69
		else
			v75 = v_u_69
			for _, v76 in p61 do
				if v76.id ~= p62 then
					continue
				end
				v74(v76)
			end
		end
		local v77 = v_u_68 + p66
		for _, v78 in p61 do
			if p62 ~= nil and v78.id == p62 then
				continue
			end
			local v79 = p_u_63[v78.id]
			if v79 == nil or p_u_64 - v79.t >= p65 then
				if v_u_68 < v77 then
					v74(v78)
				else
					v78.los = false
				end
			else
				v78.los = v79.ok
			end
		end
		return v_u_68, v75
	end,
	["step"] = function(p80, p81) -- name: step
		-- upvalues: (copy) v_u_177
		if type(p80) ~= "table" or type(p81) ~= "table" then
			return 0, 0
		end
		local v82 = p81.dt
		local v83 = p81.yaw
		local v84 = p81.pitch
		local v85 = p81.camX
		local v86 = p81.camY
		local v87 = p81.camZ
		local v88
		if type(v82) == "number" and (v82 == v82 and v82 > (-1 / 0)) then
			v88 = v82 < (1 / 0)
		else
			v88 = false
		end
		if v88 and v82 > 0 then
			local v89
			if type(v83) == "number" and (v83 == v83 and v83 > (-1 / 0)) then
				v89 = v83 < (1 / 0)
			else
				v89 = false
			end
			if v89 then
				local v90
				if type(v84) == "number" and (v84 == v84 and v84 > (-1 / 0)) then
					v90 = v84 < (1 / 0)
				else
					v90 = false
				end
				if v90 then
					local v91
					if type(v85) == "number" and (v85 == v85 and v85 > (-1 / 0)) then
						v91 = v85 < (1 / 0)
					else
						v91 = false
					end
					if v91 then
						local v92
						if type(v86) == "number" and (v86 == v86 and v86 > (-1 / 0)) then
							v92 = v86 < (1 / 0)
						else
							v92 = false
						end
						if v92 then
							local v93
							if type(v87) == "number" and (v87 == v87 and v87 > (-1 / 0)) then
								v93 = v87 < (1 / 0)
							else
								v93 = false
							end
							if v93 then
								local v94 = v_u_177.MAX_DT
								local v95 = math.min(v82, v94)
								local v96 = p81.lookYaw
								local v97
								if type(v96) == "number" and (v96 == v96 and v96 > (-1 / 0)) then
									v97 = v96 < (1 / 0)
								else
									v97 = false
								end
								local v98 = not v97 and 0 or p81.lookYaw
								local v99 = p81.lookPitch
								local v100
								if type(v99) == "number" and (v99 == v99 and v99 > (-1 / 0)) then
									v100 = v99 < (1 / 0)
								else
									v100 = false
								end
								local v101 = not v100 and 0 or p81.lookPitch
								local v102 = v98 * v98 + v101 * v101
								local v103 = math.sqrt(v102) / v95 > v_u_177.LOOK_STOP
								local v104 = p81.aiming == true and true or p81.firing == true
								if not v104 and p80.id == nil then
									return 0, 0
								end
								local v105 = not v104 and 0 or v_u_177.CONE_END
								local v106, v107, v108 = v_u_177.viewDir(v83, v84)
								local v109 = nil
								local v110 = (1 / 0)
								local v111 = nil
								local v112 = (1 / 0)
								local v113 = p81.targets
								if type(v113) == "table" then
									for _, v114 in v113 do
										if type(v114) ~= "table" or (v114.alive == false or v114.los ~= true) then
											continue
										end
										local v115 = v114.x
										local v116 = v114.y
										local v117 = v114.z
										local v118
										if type(v115) == "number" and (v115 == v115 and v115 > (-1 / 0)) then
											v118 = v115 < (1 / 0)
										else
											v118 = false
										end
										if not v118 then
											continue
										end
										local v119
										if type(v116) == "number" and (v116 == v116 and v116 > (-1 / 0)) then
											v119 = v116 < (1 / 0)
										else
											v119 = false
										end
										if not v119 then
											continue
										end
										local v120
										if type(v117) == "number" and (v117 == v117 and v117 > (-1 / 0)) then
											v120 = v117 < (1 / 0)
										else
											v120 = false
										end
										if not v120 then
											continue
										end
										local v121 = (v115 - v85) ^ 2 + (v116 - v86) ^ 2 + (v117 - v87) ^ 2
										local v122 = math.sqrt(v121)
										if v122 < v_u_177.MIN_DIST or v_u_177.RANGE_END < v122 then
											continue
										end
										local v123, v124, v125 = v_u_177.axisPoint(v85, v86, v87, v106, v107, v108, v115, v116, v117, v114.h)
										local v126, v127 = v_u_177.dirAngles(v123 - v85, v124 - v86, v125 - v87)
										local v128 = v_u_177.angleDeg(v83, v84, v126, v127)
										if v_u_177.CONE_END <= v128 then
											continue
										end
										if p80.id ~= nil then
											if v114.id == p80.id then
												v112 = v128
												v111 = v114
											end
										end
										if v128 >= v105 or v128 >= v110 then
											continue
										end
										v109 = v114
										v110 = v128
									end
								end
								if v111 ~= nil then
									if v109 == nil or (v109 == v111 or v110 >= v112 * v_u_177.SWITCH_SHARE) then
										v109 = v111
										v110 = v112
									elseif v112 - v110 < v_u_177.SWITCH_MIN then
										v109 = v111
										v110 = v112
									end
								end
								if v109 == nil then
									v_u_177.reset(p80)
									return 0, 0
								end
								if v109.id ~= p80.id or p80.id == nil then
									p80.id = v109.id
									p80.w = 0
									p80.lastYaw = nil
									p80.lastPitch = nil
								end
								p80.lastErr = v110
								local v129 = v109.x
								local v130 = v109.y
								local v131 = v109.z
								local v132 = (v129 - v85) ^ 2 + (v130 - v86) ^ 2 + (v131 - v87) ^ 2
								local v133 = math.sqrt(v132)
								local v134, v135 = v_u_177.dirAngles(v129 - v85, v130 - v86, v131 - v87)
								local v136 = 0
								local v137 = 0
								if p80.lastYaw ~= nil and p80.lastPitch ~= nil then
									local v138 = v_u_177.wrap(v134 - p80.lastYaw)
									local v139 = math.deg(v138) * math.cos(v135) / v95
									local v140 = v135 - p80.lastPitch
									local v141 = math.deg(v140) / v95
									local v142 = v139 * v139 + v141 * v141
									if math.sqrt(v142) <= v_u_177.JUMP_RATE then
										v136 = v139 * v_u_177.FOLLOW
										v137 = v141 * v_u_177.FOLLOW
									end
								end
								p80.lastYaw = v134
								p80.lastPitch = v135
								if v103 then
									p80.w = 0
									p80.lastDeg = 0
									return 0, 0
								end
								local v143 = v_u_177.coneWeight(v110, v105) * v_u_177.rangeWeight(v133)
								if p80.w < v143 then
									local v144 = p80.w + v95 / v_u_177.RAMP_IN
									p80.w = math.min(v143, v144)
								else
									local v145 = p80.w - v95 / v_u_177.RAMP_OUT
									p80.w = math.max(v143, v145)
								end
								if p80.w <= 0 then
									if not v104 then
										v_u_177.reset(p80)
									end
									p80.lastDeg = 0
									return 0, 0
								end
								local v146 = 0
								local v147 = 0
								local v148, v149, v150 = v_u_177.axisPoint(v85, v86, v87, v106, v107, v108, v129, v130, v131, v109.h)
								local v151, v152 = v_u_177.dirAngles(v148 - v85, v149 - v86, v150 - v87)
								local v153 = v109.r
								local v154
								if type(v153) == "number" and (v153 == v153 and v153 > (-1 / 0)) then
									v154 = v153 < (1 / 0)
								else
									v154 = false
								end
								local v155 = ((not v154 or v109.r <= 0) and 0 or v109.r) * v_u_177.CORE
								local v156 = math.max(v133, 0.001)
								local v157 = math.atan2(v155, v156)
								local v158 = v110 - math.deg(v157)
								local v159 = math.max(0, v158)
								if v159 > 0 then
									local v160 = v_u_177.wrap(v151 - v83)
									local v161 = math.deg(v160) * math.cos(v84)
									local v162 = v152 - v84
									local v163 = math.deg(v162)
									local v164 = v161 * v161 + v163 * v163
									local v165 = math.sqrt(v164)
									if v165 > 1e-9 then
										local v166 = v_u_177.gain(v110) * v159
										v146 = v161 / v165 * v166
										v147 = v163 / v165 * v166
									end
								end
								local v167 = (v146 + v136) * p80.w
								local v168 = (v147 + v137) * p80.w
								local v169 = v167 * v167 + v168 * v168
								local v170 = math.sqrt(v169)
								if v_u_177.MAX_RATE < v170 then
									v167 = v167 * v_u_177.MAX_RATE / v170
									v168 = v168 * v_u_177.MAX_RATE / v170
									v170 = v_u_177.MAX_RATE
								end
								if v170 < 1e-6 then
									p80.lastDeg = 0
									return 0, 0
								end
								p80.pulls = p80.pulls + 1
								p80.lastDeg = v170 * v95
								local v171 = v167 * v95
								local v172 = math.rad(v171)
								local v173 = math.cos(v84)
								local v174 = v_u_177.MIN_COS
								local v175 = v172 / math.max(v173, v174)
								local v176 = v168 * v95
								return v175, math.rad(v176)
							end
						end
					end
				end
			end
		end
		return 0, 0
	end
}
return v_u_177