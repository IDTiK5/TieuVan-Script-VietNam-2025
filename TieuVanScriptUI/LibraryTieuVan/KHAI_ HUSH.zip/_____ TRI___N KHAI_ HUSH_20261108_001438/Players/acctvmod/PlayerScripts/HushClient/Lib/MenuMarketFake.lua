-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketFake

local v_u_1 = {
	{
		["id"] = "weapons",
		["label"] = "WEAPONS"
	},
	{
		["id"] = "gold",
		["label"] = "GOLD"
	},
	{
		["id"] = "attachments",
		["label"] = "ATTACHMENTS"
	},
	{
		["id"] = "parts",
		["label"] = "PARTS"
	},
	{
		["id"] = "materials",
		["label"] = "MATERIALS"
	},
	{
		["id"] = "ammo",
		["label"] = "AMMO"
	},
	{
		["id"] = "armor",
		["label"] = "ARMOR"
	},
	{
		["id"] = "gear",
		["label"] = "GEAR"
	},
	{
		["id"] = "bags",
		["label"] = "BAGS"
	},
	{
		["id"] = "medical",
		["label"] = "MEDICAL"
	},
	{
		["id"] = "food",
		["label"] = "FOOD"
	},
	{
		["id"] = "throwables",
		["label"] = "THROWABLES"
	},
	{
		["id"] = "keys",
		["label"] = "KEYS"
	},
	{
		["id"] = "valuables",
		["label"] = "VALUABLES"
	}
}
local v_u_2 = {}
local v_u_3 = {}
for v4, v5 in v_u_1 do
	v_u_2[v5.id] = v4
end
local v_u_6 = {
	["secure"] = true,
	["quest"] = true
}
local v_u_7 = {
	"quest_",
	"doc_",
	"tape_",
	"vhs_",
	"secure_"
}
local v_u_8 = {
	["quest"] = true,
	["tape"] = true,
	["vhs"] = true
}
local function v_u_13(p9, p10) -- name: anyPaid
	-- upvalues: (copy) v_u_13
	if type(p9) ~= "table" then
		return false
	end
	if p9.paid == true or p9.ammoPaid == true then
		return true
	end
	if (p10 or 0) > 4 then
		return false
	end
	for _, v11 in { p9.items, p9.mods } do
		if type(v11) ~= "table" then
			continue
		end
		for _, v12 in v11 do
			if not v_u_13(v12, (p10 or 0) + 1) then
				continue
			end
			return true
		end
	end
	return false
end
function v_u_3.eligibility(p_u_14) -- name: eligibility
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_13
	local v_u_15 = p_u_14.cctx.shared.Items
	local v_u_16 = nil
	local function v17()
		-- upvalues: (ref) v_u_16, (copy) p_u_14
		v_u_16 = p_u_14.cctx.shared.WeaponParts
	end
	pcall(v17)
	local v_u_35 = {
		["CATEGORIES"] = nil,
		["stand"] = true,
		["CATEGORIES"] = v_u_1,
		["DENY"] = {
			["categories"] = v_u_6,
			["groups"] = v_u_8,
			["prefixes"] = v_u_7,
			["ids"] = {}
		},
		["categoryOf"] = function(p18) -- name: categoryOf
			-- upvalues: (ref) v_u_16
			local v19 = p18.category
			local v20 = p18.id
			if p18.gold ~= true then
				local v21 = p18.tags
				local v22
				if type(v21) == "table" then
					v22 = table.find(p18.tags, "gold") ~= nil
				else
					v22 = false
				end
				if not v22 then
					if v19 == "firearm" or v19 == "melee" then
						return "weapons"
					end
					if v19 == "attachment" then
						return "attachments"
					end
					if v19 == "material" then
						if v_u_16 then
							local v23 = v_u_16.isPart
							if type(v23) == "function" and v_u_16.isPart(v20) then
								return "parts"
							end
						end
						return "materials"
					end
					if v19 == "ammo" then
						return "ammo"
					end
					if v19 ~= "bag" then
						local v24 = p18.tags
						local v25
						if type(v24) == "table" then
							v25 = table.find(p18.tags, "rig") ~= nil
						else
							v25 = false
						end
						if not v25 then
							return (p18.equip == "ears" or (p18.equip == "boots" or p18.equip == "legs")) and "gear" or ((v19 == "armor" or v19 == "helmet") and "armor" or (v19 == "medical" and "medical" or (v19 == "food" and "food" or (v19 == "throwable" and "throwables" or (v19 == "key" and "keys" or (v19 == "valuable" and "valuables" or "materials"))))))
						end
					end
					return "bags"
				end
			end
			return "gold"
		end,
		["listableDef"] = function(p26) -- name: listableDef
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) p_u_14, (ref) v_u_8
			if type(p26) == "table" then
				local v27 = p26.id
				if type(v27) == "string" then
					if v_u_6[p26.category] then
						return false, "NO_TRADE_CLASS"
					end
					for _, v28 in v_u_7 do
						local v29 = p26.id
						local v30 = #v28
						if string.sub(v29, 1, v30) ~= v28 then
							continue
						end
						return false, "NO_TRADE_CLASS"
					end
					local function v31()
						-- upvalues: (ref) p_u_14
						return p_u_14.cctx.shared.Traders
					end
					local v32, v33 = pcall(v31)
					if v32 and type(v33) == "table" then
						local v34 = v33.groupOf
						if type(v34) == "function" and v_u_8[v33.groupOf(p26.id)] then
							return false, "NO_TRADE_CLASS"
						end
					end
					return true, nil
				end
			end
			return false, "UNKNOWN_ITEM"
		end
	}
	local v_u_36 = nil
	function v_u_35.catalog() -- name: catalog
		-- upvalues: (ref) v_u_36, (copy) v_u_15, (copy) v_u_35, (ref) v_u_2
		if v_u_36 then
			return v_u_36
		end
		local v37 = {}
		for _, v38 in v_u_15.all() do
			if not v_u_35.listableDef(v38) then
				continue
			end
			local v39 = {
				["id"] = v38.id,
				["name"] = v38.name,
				["short"] = v38.short,
				["cat"] = v_u_35.categoryOf(v38),
				["rarity"] = v_u_15.shownRarity(v38),
				["tags"] = v38.tags or {},
				["stack"] = v38.stack or 1
			}
			local v40
			if v38.category == "firearm" or (v38.category == "melee" or (v38.category == "armor" or (v38.category == "helmet" or v38.category == "bag"))) then
				v40 = true
			else
				local v41 = v38.uses
				v40 = type(v41) == "number"
			end
			v39.dur = v40
			table.insert(v37, v39)
		end
		table.sort(v37, function(p42, p43)
			-- upvalues: (ref) v_u_2
			if p42.cat == p43.cat then
				return string.lower(p42.name) < string.lower(p43.name)
			else
				return (v_u_2[p42.cat] or 99) < (v_u_2[p43.cat] or 99)
			end
		end)
		v_u_36 = v37
		return v37
	end
	function v_u_35.stripPlan(p44) -- name: stripPlan
		local v45 = 0
		local v46 = p44.mods
		if type(v46) == "table" then
			for _ in p44.mods do
				v45 = v45 + 1
			end
		end
		local v47 = p44.ammo
		local v48 = type(v47) ~= "number" and 0 or p44.ammo
		return {
			["mods"] = v45,
			["loaded"] = v48 > 0,
			["rounds"] = v48
		}
	end
	function v_u_35.checkInst(p49, p50) -- name: checkInst
		-- upvalues: (copy) v_u_15, (copy) v_u_35, (ref) v_u_13
		local v51 = p50 or {}
		if v51.topLevel == false then
			return false, "NOT_STASH", nil
		else
			local v52
			if type(p49) == "table" then
				v52 = v_u_15.get(p49.id)
			else
				v52 = nil
			end
			if v52 then
				local v53, v54 = v_u_35.listableDef(v52)
				if v53 then
					if v51.denyPaid == true and v_u_13(p49) then
						return false, "PAID_ITEM", nil
					elseif v51.restricted == true and v_u_13(p49) then
						return false, "PAID_BLOCKED", nil
					elseif v51.insured == true then
						return false, "INSURED", nil
					else
						local v55 = p49.items
						if type(v55) == "table" and #p49.items > 0 then
							return false, "EMPTY_FIRST", nil
						else
							local v56 = v_u_35.stripPlan(p49)
							if v56.mods > 0 then
								return false, "STRIP_FIRST", {
									["mods"] = v56.mods
								}
							elseif v56.loaded then
								return true, nil, {
									["unload"] = true,
									["rounds"] = nil,
									["rounds"] = v56.rounds
								}
							else
								return true, nil, nil
							end
						end
					end
				else
					return false, v54, nil
				end
			else
				return false, "UNKNOWN_ITEM", nil
			end
		end
	end
	return v_u_35
end
function v_u_3.new(p_u_57) -- name: new
	-- upvalues: (copy) v_u_3
	local v_u_58 = p_u_57.mc
	local v_u_59 = p_u_57.data
	local v_u_60 = p_u_57.statics
	local v_u_61 = {}
	local v_u_62 = v_u_3.eligibility(v_u_58)
	local v_u_63 = v_u_58.cctx.shared.Items
	local v_u_64 = Random.new(p_u_57.seed or 1971)
	local v_u_65 = os.clock()
	local v_u_66 = 0
	local v_u_67 = true
	local v_u_68 = 0
	v_u_61.elig = v_u_62
	function v_u_61.clock() -- name: clock
		-- upvalues: (ref) v_u_66
		return os.clock() + v_u_66
	end
	function v_u_61.now() -- name: now
		-- upvalues: (copy) v_u_61, (copy) v_u_65
		local v69 = v_u_61.clock() - v_u_65
		return math.floor(v69) + 1760000000
	end
	local v_u_70 = {}
	local function v_u_78() -- name: runTimers
		-- upvalues: (copy) v_u_61, (copy) v_u_65, (copy) v_u_70
		local v71 = 1760000000 + (v_u_61.clock() - v_u_65)
		local v72 = {}
		for v73 = #v_u_70, 1, -1 do
			if v_u_70[v73].at > v71 then
				continue
			end
			local v74 = table.remove
			local v75 = v_u_70
			table.insert(v72, 1, v74(v75, v73))
		end
		for _, v76 in v72 do
			local v77 = v76.fn
			pcall(v77)
		end
	end
	function v_u_61.advance(_, p79) -- name: advance
		-- upvalues: (ref) v_u_66, (copy) v_u_78
		v_u_66 = v_u_66 + p79
		v_u_78()
	end
	local v_u_80 = nil
	v_u_61.K = {}
	local v_u_81 = v_u_61.K
	local function v_u_83() -- name: resetKnobs
		-- upvalues: (ref) v_u_80, (copy) v_u_81
		v_u_80 = nil
		for v82 in v_u_81 do
			v_u_81[v82] = nil
		end
		v_u_81.latency = 0.05
		v_u_81.hold = false
		v_u_81.fail = false
		v_u_81.sw = {
			["list"] = true,
			["buy"] = true,
			["freeze"] = false,
			["good"] = true,
			["scope"] = true,
			["best"] = true,
			["book"] = true,
			["drain"] = false
		}
		v_u_81.book = "normal"
		v_u_81.bookState = "ok"
		v_u_81.busyBook = 0
		v_u_81.orderRefuse = false
		v_u_81.orderRefuseExtra = nil
		v_u_81.orderMode = "now"
		v_u_81.sellMode = "now"
		v_u_81.mailFull = false
		v_u_81.orderLimit = 50
		v_u_81.appear = false
		v_u_81.escrowDelay = 0
		v_u_81.ds = "ok"
		v_u_81.restricted = false
		v_u_81.restrictedMode = "hide"
		v_u_81.policyReady = true
		v_u_81.opMode = "now"
		v_u_81.raceLots = 1
		v_u_81.nextFactor = 1.04
		v_u_81.stalePrices = 0
		v_u_81.busyItem = 0
		v_u_81.tier = "base"
		v_u_81.limit = 3
		v_u_81.used = 0
		v_u_81.listRules = nil
		v_u_81.lastBuy = -1000000000
		v_u_81.cannedStash = false
		v_u_81.noRaids = false
		v_u_81.crate = nil
	end
	v_u_83()
	local v_u_84 = {}
	local v_u_85 = {}
	local v_u_86 = {
		["live"] = {},
		["sold"] = {},
		["back"] = {},
		["tx"] = {},
		["rc"] = {}
	}
	local v_u_87 = {}
	v_u_61.cashAdj = 0
	local function v_u_125() -- name: seedListings
		-- upvalues: (ref) v_u_84, (ref) v_u_85, (copy) v_u_62, (copy) v_u_63, (copy) v_u_64, (ref) v_u_68
		v_u_84 = {}
		v_u_85 = {}
		local v88 = 0
		for _, v89 in v_u_62.catalog() do
			local v90 = v89.id
			local v91 = 5381
			for v92 = 1, #v90 do
				v91 = (v91 * 33 + string.byte(v90, v92)) % 2147483647
			end
			if v91 % 5 ~= 0 or v88 >= 70 then
				break
			end
			v88 = v88 + 1
			local v93 = v_u_63.get(v89.id)
			local v94
			if v93 then
				local v95 = v93.value
				if type(v95) == "number" then
					local v96 = v93.value
					v94 = math.max(20, v96)
				else
					v94 = 100
				end
			else
				v94 = 100
			end
			local v97 = v94 * (v91 % 60 / 100 + 0.45)
			local v98 = {}
			for v99 = 1, v91 // 7 % 14 + 1 do
				local v100
				if v89.stack > 1 then
					local v101 = v_u_64
					local v102 = v89.stack
					v100 = 1 + v101:NextInteger(0, math.min(v102, 40) - 1)
				else
					v100 = 1
				end
				local v103 = v97 * (0.8 + v_u_64:NextNumber() * 0.7)
				local v104
				if v103 < 100 then
					local v105 = v103 * 100 + 0.5
					v104 = math.floor(v105) / 100
				else
					local v106 = v103 + 0.5
					v104 = math.floor(v106)
				end
				local v107 = v104 * v100 + 0.5
				local v108 = math.floor(v107)
				local v109 = math.max(v100, v108)
				local v110 = {
					["lid"] = nil,
					["n"] = nil,
					["p"] = nil,
					["d"] = nil,
					["e"] = nil,
					["t"] = nil,
					["own"] = false,
					["seller"] = nil,
					["pd"] = nil
				}
				v_u_68 = v_u_68 + 1
				v110.lid = ("l%016x"):format(v_u_68 + 2703024128)
				v110.n = v100
				v110.p = v109
				local v111
				if v89.dur then
					v111 = v_u_64:NextInteger(8, 100)
				else
					v111 = nil
				end
				v110.d = v111
				local v112 = v_u_64:NextNumber() * 7 * 86400
				v110.e = math.floor(v112) + 1760000000 + 3600
				v110.t = 1760000000 - v_u_64:NextInteger(60, 432000)
				local v113 = v_u_64
				v110.seller = "s" .. tostring(v113:NextInteger(1, 9))
				v110.pd = (v91 + v99) % 11 == 0 and 1 or nil
				table.insert(v98, v110)
			end
			v_u_84[v89.id] = v98
			local v114 = {}
			for _ = 1, v91 // 3 % 13 do
				local v115 = v_u_64:NextInteger(600, 1209000)
				local v116
				if v89.stack > 1 then
					local v117 = v_u_64
					local v118 = v89.stack
					v116 = 1 + v117:NextInteger(0, math.min(v118, 40) - 1)
				else
					v116 = 1
				end
				local v119 = v97 * (0.85 + v_u_64:NextNumber() * 0.4)
				local v120 = {
					["t"] = 1760000000 - v115
				}
				local v121 = v119 * 100 + 0.5
				v120.u = math.floor(v121) / 100
				v120.n = v116
				local v122
				if v89.dur then
					v122 = v_u_64:NextInteger(70, 100)
				else
					v122 = nil
				end
				v120.d = v122
				table.insert(v114, v120)
			end
			table.sort(v114, function(p123, p124)
				return p123.t > p124.t
			end)
			v_u_85[v89.id] = v114
		end
	end
	local v_u_126 = {
		"skin_crate_field",
		"skin_crate_tacet",
		"skin_crate_vault",
		"skin_crate_halloween",
		"skin_crate_tokyo"
	}
	local function v128()
		-- upvalues: (copy) v_u_58, (ref) v_u_126
		local v127 = v_u_58.cctx.shared.CaseOdds.ORDER
		if type(v127) == "table" and #v127 > 0 then
			v_u_126 = v127
		end
	end
	pcall(v128)
	local function v_u_142() -- name: seedCrates
		-- upvalues: (ref) v_u_126, (ref) v_u_68, (ref) v_u_84, (ref) v_u_85
		local v129 = {
			["skin_crate_field"] = {
				["base"] = 410000,
				["lots"] = nil,
				["sales"] = 6,
				["lots"] = {
					1,
					2,
					1,
					5
				}
			},
			["skin_crate_tacet"] = {
				["base"] = 520000,
				["lots"] = nil,
				["sales"] = 4,
				["lots"] = { 1, 3 }
			},
			["skin_crate_vault"] = {
				["base"] = 880000,
				["lots"] = nil,
				["sales"] = 1,
				["lots"] = {}
			},
			["skin_crate_tokyo"] = {
				["base"] = 640000,
				["lots"] = nil,
				["sales"] = 2,
				["lots"] = { 1 }
			},
			["skin_crate_halloween"] = {
				["base"] = 1150000,
				["lots"] = nil,
				["sales"] = 2,
				["lots"] = { 1 }
			}
		}
		for _, v130 in v_u_126 do
			local v131 = v129[v130]
			if not v131 then
				v131 = {
					["base"] = 400000,
					["lots"] = nil,
					["sales"] = 3,
					["lots"] = { 1 }
				}
			end
			local v132 = {}
			for v133, v134 in v131.lots do
				local v135 = {
					["lid"] = nil,
					["n"] = nil,
					["p"] = nil,
					["d"] = nil,
					["e"] = nil,
					["t"] = nil,
					["own"] = false,
					["seller"] = nil
				}
				v_u_68 = v_u_68 + 1
				v135.lid = ("l%016x"):format(v_u_68 + 2703024128)
				v135.n = v134
				local v136 = v131.base * v134 * (1 + (v133 - 1) * 0.04)
				v135.p = math.floor(v136)
				v135.e = 1760000000 + (3 + v133) * 86400 + 3600
				v135.t = 1760000000 - v133 * 900
				local v137 = v133 % 9 + 1
				v135.seller = "s" .. tostring(v137)
				table.insert(v132, v135)
			end
			v_u_84[v130] = v132
			local v138 = {}
			for v139 = 1, v131.sales do
				local v140 = {
					["t"] = nil,
					["u"] = nil,
					["n"] = 1,
					["d"] = nil,
					["t"] = 1760000000 - v139 * 6 * 3600
				}
				local v141 = v131.base * (v139 % 3 * 0.02 + 0.97)
				v140.u = math.floor(v141)
				table.insert(v138, v140)
			end
			v_u_85[v130] = v138
		end
	end
	local v_u_143 = nil
	local function v144()
		-- upvalues: (ref) v_u_143, (copy) v_u_58
		v_u_143 = v_u_58.cctx.shared.CrateMarket
	end
	pcall(v144)
	local v_u_145 = {
		["allowed"] = {
			["restricted"] = false,
			["resolved"] = true,
			["randomOk"] = true,
			["randomResolved"] = true,
			["crates"] = true
		},
		["restricted"] = {
			["restricted"] = false,
			["resolved"] = true,
			["randomOk"] = false,
			["randomResolved"] = true,
			["crates"] = true
		},
		["korea"] = {
			["restricted"] = true,
			["resolved"] = true,
			["randomOk"] = false,
			["randomResolved"] = true,
			["crates"] = true
		},
		["wait"] = {
			["restricted"] = true,
			["resolved"] = false,
			["randomOk"] = false,
			["randomResolved"] = false,
			["crates"] = true
		},
		["fail"] = {
			["restricted"] = true,
			["resolved"] = true,
			["tradeFailed"] = true,
			["randomOk"] = false,
			["randomResolved"] = true,
			["randomFailed"] = true,
			["crates"] = true
		},
		["off"] = {
			["restricted"] = false,
			["resolved"] = true,
			["randomOk"] = true,
			["randomResolved"] = true,
			["crates"] = false
		}
	}
	local v_u_146 = {
		["allowed"] = {
			["tab"] = true,
			["buy"] = true,
			["sell"] = true,
			["order"] = true
		},
		["restricted"] = {
			["tab"] = true,
			["buy"] = false,
			["sell"] = true,
			["order"] = false,
			["why"] = "CRATE_BUY"
		},
		["korea"] = {
			["tab"] = false,
			["buy"] = false,
			["sell"] = false,
			["order"] = false,
			["why"] = "CRATE_TRADE"
		},
		["wait"] = {
			["tab"] = true,
			["buy"] = false,
			["sell"] = false,
			["order"] = false,
			["why"] = "POLICY_WAIT"
		},
		["fail"] = {
			["tab"] = true,
			["buy"] = false,
			["sell"] = false,
			["order"] = false,
			["why"] = "POLICY_FAIL"
		},
		["off"] = {
			["tab"] = true,
			["buy"] = false,
			["sell"] = false,
			["order"] = false,
			["why"] = "OFF_CRATES"
		}
	}
	local function v_u_152() -- name: crateStateBody
		-- upvalues: (copy) v_u_81, (ref) v_u_143, (copy) v_u_145, (copy) v_u_146, (copy) v_u_60, (copy) v_u_59
		local v147 = v_u_81.crate
		if v_u_143 ~= nil then
			local v148 = v_u_143.stateFor
			if type(v148) == "function" then
				return v_u_143.stateFor(v_u_145[v147] or v_u_145.allowed)
			end
		end
		local v149 = {}
		for v150, v151 in v_u_146[v147] or v_u_146.allowed do
			v149[v150] = v151
		end
		if v149.why then
			v149.text = v_u_60.text(v_u_59.rules, v149.why)
		end
		return v149
	end
	local function v_u_164(p153, p154) -- name: crateVerdict
		-- upvalues: (copy) v_u_81, (ref) v_u_126, (ref) v_u_143, (copy) v_u_145, (copy) v_u_146
		if v_u_81.crate == nil or type(p153) ~= "string" then
			return nil
		else
			local v155 = false
			for _, v156 in v_u_126 do
				if v156 ~= p153 then
					continue
				end
				v155 = true
			end
			if v155 then
				if v_u_143 ~= nil then
					local v157 = v_u_143.canBuy
					if type(v157) == "function" then
						local v158 = v_u_143.canSell
						if type(v158) == "function" then
							local v159
							if p154 then
								v159 = v_u_143.canBuy
							else
								v159 = v_u_143.canSell
							end
							local v160, v161 = v159(v_u_145[v_u_81.crate] or v_u_145.allowed, p153)
							if v160 then
								return nil
							else
								return v161
							end
						end
					end
				end
				local v162 = v_u_146[v_u_81.crate] or v_u_146.allowed
				local v163
				if p154 then
					v163 = v162.buy
				else
					v163 = v162.sell
				end
				if v163 == true then
					return nil
				else
					return v162.why
				end
			else
				return nil
			end
		end
	end
	v_u_61.crateVerdict = v_u_164
	local function v_u_173(p165, p166) -- name: sortedFor
		-- upvalues: (ref) v_u_84, (copy) v_u_81, (copy) v_u_61, (copy) v_u_65
		local v167 = {}
		for _, v168 in v_u_84[p165] or {} do
			if v_u_81.restricted and v168.pd or v168.e <= 1760000000 + (v_u_61.clock() - v_u_65) - 120 or p166 and (v168.d ~= nil and v168.d < 70) then
				continue
			end
			table.insert(v167, v168)
		end
		table.sort(v167, function(p169, p170)
			local v171 = p169.p * p170.n
			local v172 = p170.p * p169.n
			if v171 == v172 then
				return p169.t < p170.t
			else
				return v171 < v172
			end
		end)
		return v167
	end
	local function v_u_193(p174) -- name: statsOf
		-- upvalues: (copy) v_u_173, (copy) v_u_61, (copy) v_u_65, (ref) v_u_85
		local v175 = v_u_173(p174, false)
		local v176 = v_u_173(p174, true)
		local v177
		if v175[1] then
			local v178 = v175[1]
			v177 = v178.p / v178.n
		else
			v177 = nil
		end
		local v179 = 1760000000 + (v_u_61.clock() - v_u_65)
		local v180 = 0
		local v181 = 0
		local v182 = 0
		for _, v183 in v_u_85[p174] or {} do
			if v179 - v183.t > 604800 or v183.d ~= nil and v183.d < 70 then
				continue
			end
			v180 = v180 + v183.n
			v181 = v181 + v183.u * v183.n
			v182 = v182 + 1
		end
		local v184 = (v_u_85[p174] or {})[1]
		local v185
		if v182 >= 3 and v180 > 0 then
			local v186 = v181 / v180 * 100 + 0.5
			v185 = math.floor(v186) / 100
		else
			v185 = nil
		end
		local v187 = {}
		if v177 then
			local v188 = v177 * 100 + 0.5
			v177 = math.floor(v188) / 100
		end
		v187.min = v177
		local v189
		if v176[1] then
			local v190 = v176[1]
			v189 = v190.p / v190.n
		else
			v189 = nil
		end
		v187.good = v189
		v187.count = #v175
		v187.avg7 = v185
		v187.sold7 = v180
		local v191
		if v184 then
			v191 = v184.u
		else
			v191 = nil
		end
		v187.last = v191
		local v192
		if v184 then
			v192 = v184.t
		else
			v192 = nil
		end
		v187.lastAt = v192
		return v187
	end
	local function v_u_198(p194) -- name: priceEntry
		-- upvalues: (copy) v_u_193
		local v195 = v_u_193(p194)
		if v195.count == 0 then
			return nil
		end
		local v196 = {
			["m"] = v195.min,
			["c"] = v195.count
		}
		if v195.good then
			local v197 = v195.good * 100 + 0.5
			v196.g = math.floor(v197) / 100
		end
		if v195.avg7 then
			v196.a = v195.avg7
		end
		if v195.sold7 > 0 then
			v196.w = v195.sold7
		end
		if v195.last then
			v196.l = v195.last
		end
		return v196
	end
	local v_u_199 = nil
	local function v_u_233() -- name: cannedStash
		-- upvalues: (ref) v_u_199, (copy) v_u_63, (ref) v_u_87
		if v_u_199 then
			return v_u_199
		end
		local v_u_200 = {}
		local v_u_201 = 0
		local function v209(p202, p203) -- name: add
			-- upvalues: (ref) v_u_63, (ref) v_u_87, (ref) v_u_201, (copy) v_u_200
			for _, v204 in v_u_63.all() do
				if not p202(v204) or v_u_87["c" .. v204.id] then
					continue
				end
				v_u_201 = v_u_201 + 1
				local v205 = {
					["uid"] = nil,
					["id"] = nil,
					["x"] = 0,
					["y"] = 0,
					["r"] = false,
					["n"] = 1,
					["uid"] = ("fk%03d"):format(v_u_201),
					["id"] = v204.id
				}
				if p203 then
					for v206, v207 in p203 do
						v205[v206] = v207
					end
				end
				local v208 = v_u_200
				table.insert(v208, v205)
				return
			end
		end
		v209(function(p210)
			local v211
			if p210.category == "firearm" and p210.rarity == 2 then
				v211 = not p210.gold
			else
				v211 = false
			end
			return v211
		end, {
			["dur"] = 0.82
		})
		v209(function(p212)
			local v213
			if p212.category == "firearm" and p212.rarity >= 3 then
				v213 = not p212.gold
			else
				v213 = false
			end
			return v213
		end, {
			["dur"] = 0.47,
			["mods"] = nil,
			["ammo"] = 12,
			["mods"] = {
				{
					["uid"] = "fkm1",
					["id"] = "x"
				}
			}
		})
		v209(function(p214)
			local v215
			if p214.category == "ammo" then
				v215 = p214.stack >= 30
			else
				v215 = false
			end
			return v215
		end, {
			["n"] = 60
		})
		v209(function(p216)
			return p216.category == "medical"
		end, {
			["n"] = 3
		})
		v209(function(p217)
			return p217.category == "bag"
		end, {
			["items"] = {
				{
					["uid"] = "fkb1",
					["id"] = "x",
					["n"] = 1
				}
			}
		})
		v209(function(p218)
			local v219
			if p218.category == "bag" then
				v219 = p218.rarity == 1
			else
				v219 = false
			end
			return v219
		end)
		v209(function(p220)
			local v221
			if p220.category == "key" then
				local v222 = p220.uses
				v221 = type(v222) == "number"
			else
				v221 = false
			end
			return v221
		end, {
			["dur"] = 0.66
		})
		v209(function(p223)
			return p223.id == "val_gold_bar"
		end)
		v209(function(p224)
			local v225
			if p224.category == "armor" and p224.equip == "armor" then
				local v226 = p224.tags
				local v227
				if type(v226) == "table" then
					v227 = table.find(p224.tags, "rig") ~= nil
				else
					v227 = false
				end
				v225 = not v227
			else
				v225 = false
			end
			return v225
		end, {
			["dur"] = 0.9,
			["paid"] = true,
			["buyer"] = 1
		})
		v209(function(p228)
			return p228.category == "quest"
		end)
		v209(function(p229)
			return p229.category == "material"
		end, {
			["n"] = 4
		})
		v209(function(p230)
			return p230.category == "food"
		end, {
			["n"] = 2
		})
		v209(function(p231)
			return p231.category == "attachment"
		end)
		v209(function(p232)
			return p232.category == "throwable"
		end, {
			["n"] = 2
		})
		v_u_199 = v_u_200
		return v_u_200
	end
	function v_u_61.stash(_) -- name: stash
		-- upvalues: (copy) v_u_58, (copy) v_u_81, (copy) v_u_233, (ref) v_u_87
		local v234 = v_u_58.profile
		local v235
		if type(v234) == "table" then
			v235 = v234.inv
		else
			v235 = nil
		end
		local v236
		if type(v235) == "table" then
			v236 = v235.containers
		else
			v236 = nil
		end
		local v237
		if type(v236) == "table" then
			v237 = v236.stash
		else
			v237 = nil
		end
		local v238
		if type(v237) == "table" then
			local v239 = v237.items
			if type(v239) == "table" then
				v238 = v237.items
			else
				v238 = nil
			end
		else
			v238 = nil
		end
		if v_u_81.cannedStash or (v238 == nil or #v238 == 0) then
			v238 = v_u_233()
		end
		local v240 = {}
		for _, v241 in v238 do
			if v_u_87[v241.uid] then
				continue
			end
			table.insert(v240, v241)
		end
		if v_u_81.crate ~= nil then
			for _, v242 in {
				{ "fkc1", "skin_crate_field", 2 },
				{ "fkc2", "skin_crate_tacet", 1 }
			} do
				if v_u_87[v242[1]] then
					continue
				end
				local v243 = {
					["uid"] = nil,
					["id"] = nil,
					["x"] = 0,
					["y"] = 0,
					["r"] = false,
					["n"] = nil,
					["uid"] = v242[1],
					["id"] = v242[2],
					["n"] = v242[3]
				}
				table.insert(v240, v243)
			end
		end
		return v240
	end
	local function v_u_258(p244, p245) -- name: note
		-- upvalues: (copy) v_u_63, (copy) v_u_60, (ref) v_u_67, (copy) v_u_58, (copy) v_u_59
		local v_u_246 = {
			["k"] = p244
		}
		if p245 then
			for v247, v248 in p245 do
				v_u_246[v247] = v248
			end
		end
		if not v_u_246.msg then
			local v249 = not v_u_246.id and "" or (v_u_63.get(v_u_246.id) and v_u_63.get(v_u_246.id).name or v_u_246.id)
			local v250 = {
				["listed"] = nil,
				["bought"] = nil,
				["sold"] = nil,
				["back"] = nil,
				["refund"] = nil,
				["aborted"] = nil,
				["paused"] = "The Blackmarket is paused. Your items and Cash are safe.",
				["closed"] = "The Blackmarket is closed right now.",
				["working"] = "Working on it. Your Cash is held safely.",
				["review"] = "A transaction needs a check. Your items and Cash are safe."
			}
			local v251 = v_u_246.n
			v250.listed = ("Listed: %s x %s for %s."):format(tostring(v251), v249, "$" .. v_u_60.commas(v_u_246.p or 0))
			local v252 = v_u_246.n
			v250.bought = ("Bought: %s x %s for %s. It is in your stash."):format(tostring(v252), v249, "$" .. v_u_60.commas(v_u_246.p or 0))
			local v253 = v_u_246.n
			v250.sold = ("Sold: %s x %s. %s added to your Cash."):format(tostring(v253), v249, "$" .. v_u_60.commas(v_u_246.net or 0))
			v250.back = ("Your listing ended. %s is back in your stash."):format(v249)
			v250.refund = ("The listing was gone. %s is back in your Cash."):format("$" .. v_u_60.commas(v_u_246.p or 0))
			v250.aborted = ("The listing could not be made. %s is back in your stash."):format(v249)
			v_u_246.msg = v250[p244] or p244
		end
		task.defer(function()
			-- upvalues: (ref) v_u_67, (ref) v_u_58, (copy) v_u_246, (ref) v_u_59
			if v_u_67 then
				local v_u_254 = false
				local function v257()
					-- upvalues: (ref) v_u_58, (ref) v_u_246, (ref) v_u_254
					local v255 = v_u_58.cctx.controllers.BmNotes
					if v255 then
						local v256 = v255.inject
						if type(v256) == "function" then
							v255.inject(v_u_246)
							v_u_254 = true
						end
					end
				end
				pcall(v257)
				if not v_u_254 then
					v_u_59:feed(v_u_246)
				end
			end
		end)
	end
	local function v_u_266(p259, p260, p261, p262, p263) -- name: receipt
		-- upvalues: (ref) v_u_86, (copy) v_u_61
		local v264 = v_u_86.rc
		local v265 = {
			["t"] = v_u_61.now(),
			["k"] = p259,
			["id"] = p260,
			["n"] = p261,
			["p"] = p262,
			["ref"] = p263
		}
		table.insert(v264, 1, v265)
		while #v_u_86.rc > 60 do
			table.remove(v_u_86.rc)
		end
	end
	local v_u_267 = {}
	local v_u_268 = {}
	local v_u_269 = 0
	local function v_u_285() -- name: seedBids
		-- upvalues: (ref) v_u_267, (ref) v_u_84, (copy) v_u_193, (copy) v_u_64
		v_u_267 = {}
		for v270 in v_u_84 do
			local v271 = v_u_193(v270)
			local v272 = 5381
			for v273 = 1, #v270 do
				v272 = (v272 * 33 + string.byte(v270, v273)) % 2147483647
			end
			if not v271.min or (v271.min < 4 or v272 % 4 == 0) then
				break
			end
			local v274 = v271.min * 0.97
			local v275 = math.floor(v274)
			local v276 = {}
			local v277 = {}
			for v278 = 1, v272 % 6 + 3 do
				local v279 = v275 * (1 - (v278 - 1) * 0.018 - v272 % 7 * 0.001)
				local v280 = math.floor(v279)
				local v281 = math.max(1, v280)
				local v282 = 1 + v_u_64:NextInteger(0, 119)
				local v283 = v276[v281]
				if v283 then
					v283.q = v283.q + v282
					v283.c = v283.c + 1
				else
					local v284 = {
						["u"] = v281,
						["q"] = v282,
						["c"] = 1 + v_u_64:NextInteger(0, 2)
					}
					v276[v281] = v284
					table.insert(v277, v284)
				end
			end
			v_u_267[v270] = v277
		end
	end
	local function v_u_301(p286) -- name: bidLevelsOf
		-- upvalues: (ref) v_u_267, (ref) v_u_268
		local v_u_287 = {}
		local v_u_288 = {}
		local function v296(p289, p290, p291, p292) -- name: add
			-- upvalues: (copy) v_u_287, (copy) v_u_288
			local v293 = v_u_287[p289]
			if v293 then
				v293.q = v293.q + p290
				v293.c = v293.c + p291
				v293.own = v293.own or p292
			else
				local v294 = {
					["u"] = p289,
					["q"] = p290,
					["c"] = p291,
					["own"] = p292
				}
				v_u_287[p289] = v294
				local v295 = v_u_288
				table.insert(v295, v294)
			end
		end
		for _, v297 in v_u_267[p286] or {} do
			v296(v297.u, v297.q, v297.c, false)
		end
		for _, v298 in v_u_268 do
			if v298.id ~= p286 or (v298.st ~= 1 or v298.rem <= 0) then
				continue
			end
			v296(v298.u, v298.rem, 1, true)
		end
		table.sort(v_u_288, function(p299, p300)
			return p299.u > p300.u
		end)
		return v_u_288
	end
	local function v_u_309(p302) -- name: askLevelsOf
		-- upvalues: (copy) v_u_173
		local v303 = {}
		for _, v304 in v_u_173(p302, false) do
			local v305 = v304.p / v304.n * 100 + 0.5
			local v306 = math.floor(v305) / 100
			local v307 = v303[#v303]
			if v307 and v307.u == v306 then
				v307.q = v307.q + v304.n
				v307.c = v307.c + 1
				v307.own = v307.own or v304.own == true
			else
				local v308 = {
					["u"] = nil,
					["q"] = nil,
					["c"] = 1,
					["own"] = nil,
					["u"] = v306,
					["q"] = v304.n,
					["own"] = v304.own == true
				}
				table.insert(v303, v308)
			end
		end
		return v303
	end
	local function v_u_320(p310) -- name: bandOf
		-- upvalues: (copy) v_u_193, (copy) v_u_63
		local v311 = v_u_193(p310)
		local v312 = v_u_63.get(p310)
		local v313 = v311.avg7
		if not v313 then
			if v312 then
				local v314 = v312.value
				v313 = type(v314) ~= "number" and 100 or v312.value
			else
				v313 = 100
			end
		end
		local v315 = v313 / 10
		local v316 = math.floor(v315)
		local v317 = math.max(1, v316)
		local v318 = v313 * 3
		local v319 = math.ceil(v318)
		return v317, math.max(1, v319)
	end
	local function v_u_355(p321, p322) -- name: bookBody
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_309, (copy) v_u_301, (copy) v_u_320
		if v_u_81.bookState == "down" or v_u_81.ds == "down" then
			return {
				["ok"] = false,
				["code"] = "STORE",
				["text"] = nil,
				["ds"] = "down",
				["text"] = v_u_60.text(v_u_59.rules, "STORE")
			}
		end
		if v_u_81.bookState == "drain" then
			return {
				["ok"] = false,
				["code"] = "DRAIN",
				["text"] = nil,
				["text"] = v_u_60.text(v_u_59.rules, "DRAIN")
			}
		end
		if v_u_81.bookState == "off" then
			return {
				["ok"] = false,
				["code"] = "OFF_BOOK",
				["text"] = nil,
				["text"] = v_u_60.text(v_u_59.rules, "OFF_BOOK")
			}
		end
		if v_u_81.busyBook > 0 then
			local v323 = v_u_81
			v323.busyBook = v323.busyBook - 1
			return {
				["ok"] = false,
				["code"] = "BOOK_BUSY",
				["text"] = nil,
				["retryIn"] = 2,
				["text"] = v_u_60.text(v_u_59.rules, "BOOK_BUSY")
			}
		end
		local v324 = v_u_81.book == "empty" and {} or v_u_309(p321)
		local v325 = #v324
		local v326 = {}
		for v327 = 1, math.min(6, v325) do
			local v328 = v324[v327]
			local v329 = {
				["u"] = v328.u,
				["q"] = v328.q,
				["c"] = v328.c
			}
			if v328.own == true then
				v329.own = true
			end
			table.insert(v326, v329)
		end
		local v330 = (v_u_81.book == "empty" or v_u_81.book == "bidsbusy") and {} or v_u_301(p321)
		if v_u_81.book == "many" and #v330 < 20 then
			local v331 = not v330[1] and 100 or v330[1].u
			local v332 = {}
			for _, v333 in v330 do
				v332[v333.u] = true
			end
			local v334 = 0
			while v334 < 24 and v331 > 1 do
				v331 = v331 - 1
				if v332[v331] then
					continue
				end
				v332[v331] = true
				v334 = v334 + 1
				local v335 = {
					["u"] = nil,
					["q"] = nil,
					["c"] = 1,
					["own"] = false,
					["u"] = v331,
					["q"] = v334 + 3
				}
				table.insert(v330, v335)
			end
			table.sort(v330, function(p336, p337)
				return p336.u > p337.u
			end)
		end
		if v_u_81.book == "crossed" and v324[1] then
			local v338 = {
				["u"] = nil,
				["q"] = 5,
				["c"] = 1,
				["own"] = false
			}
			local v339 = v324[1].u
			local v340 = math.ceil(v339)
			v338.u = math.max(1, v340)
			table.insert(v330, 1, v338)
		end
		local v341 = {}
		for _, v342 in v330 do
			if p322 ~= nil and v342.u >= p322 then
				continue
			end
			table.insert(v341, v342)
		end
		local v343 = #v341
		local v344 = {}
		for v345 = 1, math.min(6, v343) do
			local v346 = v341[v345]
			local v347 = {
				["u"] = v346.u,
				["q"] = v346.q,
				["c"] = v346.c
			}
			if v346.own == true then
				v347.own = true
			end
			table.insert(v344, v347)
		end
		local v348, v349 = v_u_320(p321)
		local v350 = {}
		local v351
		if v326[1] then
			v351 = v326[1].u
		else
			v351 = nil
		end
		v350.ask = v351
		local v352
		if v344[1] then
			v352 = v344[1].u
		else
			v352 = nil
		end
		v350.bid = v352
		local v353 = {
			["ok"] = true,
			["id"] = nil,
			["ds"] = nil,
			["asks"] = nil,
			["bids"] = nil,
			["best"] = nil,
			["fee"] = 5,
			["band"] = nil,
			["more"] = nil,
			["cut"] = nil,
			["age"] = 3,
			["stale"] = nil,
			["id"] = p321,
			["ds"] = v_u_81.ds,
			["asks"] = v326,
			["bids"] = v344,
			["best"] = v350,
			["band"] = {
				["lo"] = v348,
				["hi"] = v349
			},
			["more"] = #v341 > 6,
			["cut"] = #v324 > 6 and true or #v341 > 6,
			["stale"] = v_u_81.ds == "busy"
		}
		if v350.ask ~= nil and v350.bid ~= nil then
			if v350.ask > v350.bid then
				local v354 = (v350.ask - v350.bid) * 100 + 0.5
				v353.spread = math.floor(v354) / 100
			else
				v353.crossed = true
			end
		end
		if v_u_81.book == "bidsbusy" then
			v353.bidsBusy = true
		end
		return v353
	end
	local function v_u_358(p356) -- name: bestBidOf
		-- upvalues: (copy) v_u_81, (copy) v_u_301
		if v_u_81.book == "empty" or v_u_81.book == "bidsbusy" then
			return nil
		end
		for _, v357 in v_u_301(p356) do
			if v357.own then
				continue
			end
			return {
				["u"] = v357.u,
				["q"] = v357.q
			}
		end
		return nil
	end
	local function v_u_366() -- name: ordersMine
		-- upvalues: (ref) v_u_268, (copy) v_u_61, (copy) v_u_81
		local v359 = {}
		for _, v360 in v_u_268 do
			local v361 = v360.t + 1209600
			local v362 = {
				["oid"] = v360.oid,
				["id"] = v360.id,
				["q"] = v360.q,
				["rem"] = v360.rem,
				["u"] = v360.u,
				["h"] = v360.st ~= 1 and 0 or v360.rem * v360.u,
				["t"] = v360.t,
				["st"] = v360.st,
				["shown"] = v360.shown ~= false,
				["e"] = v361
			}
			local v363 = v361 - v_u_61.now()
			v362.left = math.max(0, v363)
			if v360.mc then
				v362.mc = v360.mc
			end
			if v360.st == 3 and v360.rt ~= 1 then
				v362.back = true
			end
			if v360.st == 2 or v360.rt == 1 then
				v362.ended = true
			end
			if v360.paused then
				v362.paused = true
			end
			if (v360.pend or 0) > 0 then
				v362.wait = v360.pend
				v362.mail = v_u_81.mailFull and "full" or "wait"
			end
			table.insert(v359, v362)
		end
		table.sort(v359, function(p364, p365)
			return p364.t > p365.t
		end)
		return v359
	end
	function v_u_61.fillOrder(_, p367, p368) -- name: fillOrder
		-- upvalues: (ref) v_u_268, (copy) v_u_258, (copy) v_u_63, (copy) v_u_60
		for _, v369 in v_u_268 do
			if v369.oid ~= p367 or (v369.st ~= 1 or v369.rem <= 0) then
				continue
			end
			local v370 = v369.rem
			local v371 = math.min(p368, v370)
			v369.rem = v369.rem - v371
			v369.pend = (v369.pend or 0) + v371
			if v369.rem == 0 then
				v369.st = 2
			end
			v_u_258("orderFilled", {
				["id"] = v369.id,
				["n"] = v371,
				["u"] = v369.u,
				["msg"] = ("Your order was filled: %d x %s at $%s each. It is waiting in your mail."):format(v371, v_u_63.get(v369.id) and v_u_63.get(v369.id).name or v369.id, v_u_60.commas(v369.u))
			})
			return true
		end
		return false
	end
	function v_u_61.orders(_) -- name: orders
		-- upvalues: (ref) v_u_268
		return v_u_268
	end
	function v_u_61.ordersState() -- name: ordersState
		-- upvalues: (ref) v_u_268, (copy) v_u_81, (copy) v_u_60, (copy) v_u_59
		local v372 = 0
		for _, v373 in v_u_268 do
			if v373.st ~= 1 then
				continue
			end
			v372 = v372 + 1
		end
		local v374 = v_u_81.orderLimit or 50
		local v375 = v_u_81.sw.freeze and "FREEZE" or ((v_u_81.sw.drain or v_u_81.bookState == "drain") and "DRAIN" or ((v_u_81.sw.book == false or v_u_81.bookState == "off") and "OFF_BOOK" or (v_u_81.orderRefuse == "REVIEW" and "REVIEW" or nil)))
		local v376 = {
			["can"] = nil,
			["open"] = nil,
			["max"] = nil,
			["days"] = 14,
			["qtyMax"] = 255,
			["stackQty"] = 20,
			["held"] = nil,
			["can"] = v375 == nil,
			["open"] = v372,
			["max"] = v374
		}
		local v377 = 0
		for _, v378 in v_u_268 do
			if v378.st ~= 1 then
				continue
			end
			v377 = v377 + v378.rem * v378.u
		end
		v376.held = v377
		if not v375 then
			if v374 <= v372 then
				v376.full = true
			end
			return v376
		end
		v376.why = v375
		v376.text = v_u_60.text(v_u_59.rules, v375)
		return v376
	end
	local v_u_379 = {
		{
			["id"] = "ammo_9mm_1",
			["u"] = 16,
			["s"] = 5000,
			["q1"] = 10,
			["q2"] = 200,
			["c"] = 200,
			["w"] = 3600,
			["k"] = 8,
			["a"] = 0
		},
		{
			["id"] = "ammo_12ga_1",
			["u"] = 45,
			["s"] = 800,
			["q1"] = 5,
			["q2"] = 100,
			["c"] = 100,
			["w"] = 3600,
			["k"] = 4,
			["a"] = 0
		},
		{
			["id"] = "med_bandage",
			["u"] = 140,
			["s"] = 300,
			["q1"] = 1,
			["q2"] = 5,
			["c"] = 10,
			["w"] = 86400,
			["k"] = 2,
			["a"] = 0
		},
		{
			["id"] = "food_cola",
			["u"] = 380,
			["s"] = 60,
			["q1"] = 1,
			["q2"] = 3,
			["c"] = 6,
			["w"] = 86400,
			["k"] = 1,
			["a"] = 0
		}
	}
	local function v_u_390(p380, p381) -- name: rsBuild
		-- upvalues: (copy) v_u_61, (copy) v_u_379
		local v382 = v_u_61.now()
		local v383 = {}
		for _, v384 in v_u_379 do
			local v385 = table.clone(v384)
			v385.tg = 0
			table.insert(v383, v385)
		end
		local v386 = {
			["r"] = "r0fa4e5e1",
			["n"] = "MARKET RESTOCK",
			["st"] = "p",
			["t0"] = nil,
			["t1"] = nil,
			["tw"] = nil,
			["al"] = 24,
			["wd"] = 4,
			["rv"] = 2,
			["mr"] = 3,
			["ma"] = 7,
			["mc"] = 3,
			["mx"] = 1,
			["ho"] = false,
			["ra"] = nil,
			["gen"] = 1,
			["ix"] = nil,
			["lk"] = 0,
			["t0"] = v382 + p380,
			["t1"] = v382 + p380 + p381,
			["tw"] = v382 + p380,
			["ix"] = v383
		}
		local v387 = {}
		for v388, v389 in v383 do
			v387[v388] = v389.s
		end
		return {
			["plan"] = nil,
			["stock"] = nil,
			["rec"] = nil,
			["held"] = nil,
			["on"] = true,
			["mailFull"] = false,
			["raids"] = 20,
			["saving"] = false,
			["refuse"] = nil,
			["plan"] = v386,
			["stock"] = v387,
			["rec"] = {},
			["held"] = {}
		}
	end
	local function v_u_397(p391) -- name: rsLanes
		-- upvalues: (ref) v_u_80, (copy) v_u_61, (copy) v_u_65
		local v392 = v_u_80.stock[p391] or 0
		local v393 = v_u_80.plan.ix[p391]
		if v392 <= 0 then
			return {
				["st"] = "out"
			}
		end
		local v394 = v_u_80.held[p391]
		if v394 == nil or 1760000000 + (v_u_61.clock() - v_u_65) >= v394 then
			return (v393 == nil or v392 >= v393.s * 0.1) and {
				["st"] = "ok"
			} or {
				["st"] = "low"
			}
		end
		local v395 = {
			["st"] = "held",
			["retryIn"] = nil
		}
		local v396 = v394 - (1760000000 + (v_u_61.clock() - v_u_65))
		v395.retryIn = math.ceil(v396)
		return v395
	end
	local function v_u_403() -- name: rsRkFull
		-- upvalues: (copy) v_u_58, (ref) v_u_80, (copy) v_u_61, (copy) v_u_397
		local v_u_398 = nil
		local function v399()
			-- upvalues: (ref) v_u_398, (ref) v_u_58
			v_u_398 = v_u_58.cctx.shared.BmRs
		end
		pcall(v399)
		local v400 = v_u_398
		local v401
		if type(v400) == "table" then
			local v402 = v_u_398.viewPlan
			if type(v402) == "function" then
				v401 = v_u_398
			else
				v401 = nil
			end
		else
			v401 = nil
		end
		if v401 == nil or (v_u_80 == nil or not v_u_80.on) then
			return nil
		else
			return v401.viewPlan(v_u_80.plan, {
				["now"] = nil,
				["profile"] = nil,
				["viewer"] = nil,
				["lanes"] = nil,
				["flag"] = true,
				["rsOn"] = nil,
				["planAge"] = 3,
				["now"] = v_u_61.now(),
				["profile"] = {
					["i"] = v_u_80.rec
				},
				["viewer"] = {
					["tutorialDone"] = true,
					["finishedRaids"] = nil,
					["accountAge"] = 400,
					["hushAge"] = 30,
					["extracts"] = 5,
					["scopeOk"] = true,
					["mailFull"] = nil,
					["stashFull"] = false,
					["finishedRaids"] = v_u_80.raids,
					["mailFull"] = v_u_80.mailFull
				},
				["lanes"] = v_u_397,
				["rsOn"] = v_u_80.on
			})
		end
	end
	local function v_u_415(p404) -- name: rsScenario
		-- upvalues: (copy) v_u_58, (copy) v_u_61, (ref) v_u_80, (copy) v_u_390, (copy) v_u_65, (copy) v_u_379
		local v_u_405 = nil
		local function v406()
			-- upvalues: (ref) v_u_405, (ref) v_u_58
			v_u_405 = v_u_58.cctx.shared.BmRs
		end
		pcall(v406)
		local v407 = v_u_405
		local v408
		if type(v407) == "table" then
			local v409 = v_u_405.viewPlan
			if type(v409) == "function" then
				v408 = v_u_405
			else
				v408 = nil
			end
		else
			v408 = nil
		end
		if v408 == nil then
			return false
		end
		local v410 = v_u_61.now()
		if p404 == "rssoon" then
			v_u_80 = v_u_390(11564, 21600)
		elseif p404 == "rsdraw" then
			v_u_80 = v_u_390(-1, 21600)
		elseif p404 == "rslive" then
			v_u_80 = v_u_390(-600, 21600)
		elseif p404 == "rsheld" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.held[1] = 1760000000 + (v_u_61.clock() - v_u_65) + 10
		elseif p404 == "rssoldout" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.stock[1] = 0
		elseif p404 == "rscap" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.rec.ammo_9mm_1 = {
				["f"] = 3600,
				["w"] = 0,
				["n"] = 200,
				["a"] = nil,
				["a"] = v410
			}
		elseif p404 == "rspaused" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.plan.ho = true
		elseif p404 == "rsoff" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.on = false
		elseif p404 == "rsresume" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.plan.ra = v410 + 30
		elseif p404 == "rsdrop" then
			v_u_80 = v_u_390(-600, 21600)
			local v411 = {}
			for v412 = 1, 3 do
				local v413 = table.clone(v_u_379[1])
				v413.a = (v412 - 1) * 3600
				local v414
				if v412 < 3 then
					v414 = v412 * 3600
				else
					v414 = nil
				end
				v413.b = v414
				v413.s = 1000
				v413.dr = {
					["i"] = nil,
					["n"] = 3,
					["i"] = v412
				}
				v413.tg = 0
				table.insert(v411, v413)
			end
			v_u_80.plan.ix = v411
			v_u_80.stock = { 1000, 1000, 1000 }
		elseif p404 == "rsmailfull" then
			v_u_80 = v_u_390(300, 21600)
			v_u_80.mailFull = true
		elseif p404 == "rsrv0" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.plan.rv = 0
		elseif p404 == "rsrv1" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.plan.rv = 1
		elseif p404 == "rsgate" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.raids = 1
		elseif p404 == "rsless" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.stock[1] = 30
		elseif p404 == "rsbusy" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.refuse = {
				["code"] = "STOCK_BUSY",
				["extra"] = nil,
				["extra"] = {
					["retryIn"] = 6
				}
			}
		elseif p404 == "rsheldbuy" then
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.refuse = {
				["code"] = "HELD",
				["extra"] = nil,
				["extra"] = {
					["retryIn"] = 12
				}
			}
		else
			if p404 ~= "rssaving" then
				return false
			end
			v_u_80 = v_u_390(-600, 21600)
			v_u_80.saving = true
		end
		return true
	end
	function v_u_61.rsWorld(_) -- name: rsWorld
		-- upvalues: (ref) v_u_80
		return v_u_80
	end
	local function v_u_451(p416) -- name: seedMine
		-- upvalues: (copy) v_u_62, (ref) v_u_84, (ref) v_u_86, (ref) v_u_68, (copy) v_u_61, (copy) v_u_63
		local v_u_417 = v_u_62.catalog()
		local function v422(p418) -- name: pick
			-- upvalues: (ref) v_u_84, (copy) v_u_417
			local v419 = {}
			for v420 in v_u_84 do
				table.insert(v419, v420)
			end
			table.sort(v419)
			local v421 = #v419
			return v419[p418 % math.max(1, v421) + 1] or v_u_417[1] and v_u_417[1].id or "med_bandage"
		end
		if p416 == "away" then
			local v423 = v422(2)
			local v424 = v422(5)
			local v425 = v422(9)
			local v426 = v_u_86.sold
			local v427 = {
				["lid"] = nil,
				["id"] = nil,
				["n"] = 1,
				["p"] = 12400,
				["net"] = 11780,
				["sa"] = nil
			}
			v_u_68 = v_u_68 + 1
			v427.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v427.id = v423
			v427.sa = v_u_61.now() - 10800
			table.insert(v426, v427)
			local v428 = v_u_86.sold
			local v429 = {
				["lid"] = nil,
				["id"] = nil,
				["n"] = 12,
				["p"] = 1800,
				["net"] = 1710,
				["sa"] = nil
			}
			v_u_68 = v_u_68 + 1
			v429.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v429.id = v424
			v429.sa = v_u_61.now() - 600
			table.insert(v428, v429)
			local v430 = v_u_86.back
			local v431 = {
				["lid"] = nil,
				["id"] = nil,
				["n"] = 1,
				["rs"] = 2
			}
			v_u_68 = v_u_68 + 1
			v431.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v431.id = v425
			table.insert(v430, v431)
			local v432 = v_u_86.sold
			local v433 = {
				["lid"] = nil,
				["id"] = nil,
				["n"] = 3,
				["p"] = 900,
				["net"] = 855,
				["sa"] = nil,
				["done"] = true
			}
			v_u_68 = v_u_68 + 1
			v433.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v433.id = v422(7)
			v433.sa = v_u_61.now() - 86400
			table.insert(v432, v433)
			local v434 = v_u_86.back
			local v435 = {
				["lid"] = nil,
				["id"] = nil,
				["n"] = 1,
				["rs"] = 1,
				["done"] = true
			}
			v_u_68 = v_u_68 + 1
			v435.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v435.id = v422(11)
			table.insert(v434, v435)
			return
		elseif p416 == "quarantine" then
			local v436 = v_u_86.tx
			local v437 = {
				["k"] = "B",
				["st"] = 9,
				["tx"] = "b0000000000000001",
				["id"] = nil,
				["n"] = 2,
				["p"] = 960,
				["age"] = 5400,
				["review"] = true,
				["id"] = v422(3)
			}
			table.insert(v436, v437)
			return
		elseif p416 == "inflight" then
			local v438 = v_u_86.tx
			local v439 = {
				["k"] = "L",
				["st"] = 1,
				["lid"] = nil,
				["id"] = nil,
				["n"] = 30,
				["p"] = 1200,
				["age"] = 40
			}
			v_u_68 = v_u_68 + 1
			v439.lid = ("l%016x"):format(v_u_68 + 2703024128)
			v439.id = v422(4)
			table.insert(v438, v439)
			local v440 = v_u_86.tx
			local v441 = {
				["k"] = "B",
				["st"] = 1,
				["tx"] = "b0000000000000002",
				["id"] = nil,
				["n"] = 1,
				["p"] = 5400,
				["age"] = 12,
				["id"] = v422(6)
			}
			table.insert(v440, v441)
		elseif p416 == "live" then
			for v442 = 1, 3 do
				local v443 = v422(v442 + 10)
				v_u_68 = v_u_68 + 1
				local v444 = ("l%016x"):format(v_u_68 + 2703024128)
				local v445 = v_u_63.get(v443)
				local v446 = v445 and (v445.stack or 1) > 1 and 10 or 1
				local v447 = v_u_86.live
				local v448 = {
					["lid"] = nil,
					["id"] = nil,
					["n"] = nil,
					["p"] = nil,
					["fp"] = 5,
					["t"] = nil,
					["e"] = nil,
					["ix"] = "x",
					["lid"] = v444,
					["id"] = v443,
					["n"] = v446,
					["p"] = v442 * 400 * v446,
					["t"] = v_u_61.now() - v442 * 3600,
					["e"] = v_u_61.now() + (7 - v442) * 86400
				}
				table.insert(v447, v448)
				v_u_84[v443] = v_u_84[v443] or {}
				local v449 = v_u_84[v443]
				local v450 = {
					["lid"] = nil,
					["n"] = nil,
					["p"] = nil,
					["e"] = nil,
					["t"] = nil,
					["own"] = true,
					["seller"] = "me",
					["lid"] = v444,
					["n"] = v446,
					["p"] = v442 * 400 * v446,
					["e"] = v_u_61.now() + (7 - v442) * 86400,
					["t"] = v_u_61.now() - v442 * 3600
				}
				table.insert(v449, v450)
			end
		end
	end
	local function v_u_458() -- name: fill
		-- upvalues: (ref) v_u_87, (ref) v_u_86, (copy) v_u_125, (copy) v_u_81, (copy) v_u_142, (copy) v_u_451, (ref) v_u_268, (copy) v_u_285, (ref) v_u_84, (copy) v_u_61
		v_u_87 = {}
		v_u_86 = {
			["live"] = {},
			["sold"] = {},
			["back"] = {},
			["tx"] = {},
			["rc"] = {}
		}
		v_u_125()
		if v_u_81.crate ~= nil then
			v_u_142()
		end
		v_u_451("live")
		v_u_268 = {}
		v_u_285()
		for v452, v453 in {
			{
				["k"] = "s",
				["n"] = 1,
				["p"] = 8200
			},
			{
				["k"] = "b",
				["n"] = 3,
				["p"] = 1400
			},
			{
				["k"] = "l",
				["n"] = 10,
				["p"] = 900
			},
			{
				["k"] = "c",
				["n"] = 1,
				["p"] = 0
			},
			{
				["k"] = "r",
				["n"] = 1,
				["p"] = 2100
			}
		} do
			local v454 = {}
			for v455 in v_u_84 do
				table.insert(v454, v455)
			end
			table.sort(v454)
			local v456 = v_u_86.rc
			local v457 = {
				["t"] = v_u_61.now() - v452 * 5400,
				["k"] = v453.k,
				["id"] = v454[v452 * 3] or "x",
				["n"] = v453.n,
				["p"] = v453.p,
				["ref"] = ("l%016x"):format(12513024 + v452)
			}
			table.insert(v456, v457)
		end
	end
	v_u_458()
	function v_u_61.scenario(_, p459) -- name: scenario
		-- upvalues: (copy) v_u_83, (copy) v_u_458, (ref) v_u_84, (ref) v_u_85, (ref) v_u_267, (ref) v_u_268, (ref) v_u_86, (copy) v_u_81, (copy) v_u_61, (copy) v_u_451, (copy) v_u_62, (copy) v_u_146, (copy) v_u_415, (ref) v_u_68, (ref) v_u_269
		local v460 = string.lower((tostring(p459)))
		if v460 == "normal" or v460 == "success" then
			v_u_83()
			v_u_458()
		elseif v460 == "empty" then
			v_u_84 = {}
			v_u_85 = {}
			v_u_267 = {}
			v_u_268 = {}
			v_u_86 = {
				["live"] = {},
				["sold"] = {},
				["back"] = {},
				["tx"] = {},
				["rc"] = {}
			}
		elseif v460 == "loading" then
			v_u_81.latency = 3
		elseif v460 == "error" then
			v_u_81.fail = true
		elseif v460 == "closed" then
			local v461 = v_u_81.sw
			local v462 = v_u_81.sw
			v461.list = false
			v462.buy = false
		elseif v460 == "paused" then
			v_u_81.sw.freeze = true
		elseif v460 == "listrules" then
			v_u_81.listRules = true
		elseif v460 == "listrulesoff" then
			v_u_81.listRules = false
		elseif v460 == "scope" then
			v_u_81.sw.scope = false
		elseif v460 == "cooldown" then
			v_u_81.lastBuy = v_u_61.now() - 13
		elseif v460 == "processing" then
			v_u_81.opMode = "processing"
		elseif v460 == "refund" then
			v_u_81.opMode = "refund"
		elseif v460 == "race" then
			v_u_81.opMode = "race"
			v_u_81.raceLots = 1
		elseif v460 == "racerose" then
			v_u_81.opMode = "race"
			v_u_81.raceLots = 1
			v_u_81.nextFactor = 1.35
		elseif v460 == "raceescrow" then
			v_u_81.opMode = "race"
			v_u_81.raceLots = 1
			v_u_81.escrowDelay = 2
		elseif v460 == "newlot" then
			v_u_81.appear = {
				["n"] = 30,
				["factor"] = 0.9
			}
		elseif v460 == "newlotonly" then
			v_u_81.appear = {
				["n"] = 3,
				["factor"] = 0.5,
				["only"] = true
			}
		elseif v460 == "newlotsmall" then
			v_u_81.appear = {
				["n"] = 2,
				["factor"] = 0.9
			}
		elseif v460 == "bestoff" then
			v_u_81.sw.best = false
		elseif v460 == "raceall" then
			v_u_81.opMode = "race"
			v_u_81.raceLots = 99
		elseif v460 == "race2" then
			v_u_81.opMode = "race"
			v_u_81.raceLots = 2
		elseif v460 == "away" then
			v_u_451("away")
		elseif v460 == "quarantine" then
			local v_u_463 = v_u_62.catalog()
			local function v468(p464) -- name: pick
				-- upvalues: (ref) v_u_84, (copy) v_u_463
				local v465 = {}
				for v466 in v_u_84 do
					table.insert(v465, v466)
				end
				table.sort(v465)
				local v467 = #v465
				return v465[p464 % math.max(1, v467) + 1] or v_u_463[1] and v_u_463[1].id or "med_bandage"
			end
			local v469 = v_u_86.tx
			local v470 = {
				["k"] = "B",
				["st"] = 9,
				["tx"] = "b0000000000000001",
				["id"] = nil,
				["n"] = 2,
				["p"] = 960,
				["age"] = 5400,
				["review"] = true,
				["id"] = v468(3)
			}
			table.insert(v469, v470)
			v_u_451("inflight")
		elseif v460 == "hidden" then
			if v_u_86.live[1] then
				v_u_86.live[1].hidden = true
				v_u_86.live[1].ix = "full"
			end
		elseif v460 == "stale" then
			v_u_81.stalePrices = 1
		elseif v460 == "dsbusy" then
			v_u_81.ds = "busy"
			v_u_81.busyItem = 2
		elseif v460 == "dsdown" then
			v_u_81.ds = "down"
		elseif string.sub(v460, 1, 6) == "crates" and v_u_146[string.sub(v460, 7)] ~= nil then
			v_u_83()
			v_u_81.crate = string.sub(v460, 7)
			v_u_458()
		elseif string.sub(v460, 1, 2) == "rs" and v_u_415(v460) then
			v_u_81.rsScenario = v460
		elseif v460 == "restricted" then
			v_u_81.restricted = true
			v_u_81.restrictedMode = "hide"
		elseif v460 == "blocked" then
			v_u_81.restricted = true
			v_u_81.restrictedMode = "block"
		elseif v460 == "many" then
			local v471 = {}
			for v472 in v_u_84 do
				table.insert(v471, v472)
			end
			table.sort(v471)
			local v473 = v471[3] or v471[1]
			if v473 then
				v_u_61.manyId = v473
				for v474 = 1, 60 do
					local v475 = v_u_84[v473]
					local v476 = {
						["lid"] = nil,
						["n"] = 1,
						["p"] = nil,
						["e"] = nil,
						["t"] = nil,
						["own"] = false,
						["seller"] = nil
					}
					v_u_68 = v_u_68 + 1
					v476.lid = ("l%016x"):format(v_u_68 + 2703024128)
					v476.p = v474 * 7 + 100
					v476.e = v474 * 600 + 1760259200
					v476.t = 1760000000 - v474 * 60
					local v477 = v474 % 9 + 1
					v476.seller = "s" .. tostring(v477)
					table.insert(v475, v476)
				end
			end
		elseif v460 == "canned" then
			v_u_81.cannedStash = true
		elseif v460 == "limit" then
			v_u_81.used = v_u_81.limit
		elseif v460 == "fixer" then
			local v478 = v_u_81
			v_u_81.tier = "fixer"
			v478.limit = 20
		elseif v460 == "bookempty" then
			v_u_81.book = "empty"
		elseif v460 == "nobids" then
			v_u_267 = {}
			for v479 = #v_u_268, 1, -1 do
				table.remove(v_u_268, v479)
			end
		elseif v460 == "bidsbusy" then
			v_u_81.book = "bidsbusy"
		elseif v460 == "bookcrossed" then
			v_u_81.book = "crossed"
		elseif v460 == "bookmany" then
			v_u_81.book = "many"
		elseif v460 == "bookbusy" then
			v_u_81.busyBook = 2
		elseif v460 == "bookdown" then
			v_u_81.bookState = "down"
		elseif v460 == "bookdrain" then
			v_u_81.bookState = "drain"
		elseif v460 == "bookoff" then
			v_u_81.bookState = "off"
		elseif v460 == "orderprocessing" then
			v_u_81.orderMode = "processing"
		elseif v460 == "sellpending" then
			v_u_81.sellMode = "pending"
		elseif v460 == "mailfull" then
			v_u_81.mailFull = true
		elseif v460 == "ordersfull" then
			v_u_81.orderLimit = 0
		elseif v460 == "orderfilled" then
			local v480 = {}
			for v481 in v_u_267 do
				table.insert(v480, v481)
			end
			table.sort(v480)
			local v482 = #v480
			for v483 = 1, math.min(2, v482) do
				local v484 = v480[v483]
				local v485 = v_u_267[v484][1]
				local v486 = {
					["oid"] = nil,
					["id"] = nil,
					["q"] = 50,
					["rem"] = 38,
					["u"] = nil,
					["t"] = nil,
					["st"] = 1,
					["shown"] = true,
					["pend"] = nil
				}
				v_u_269 = v_u_269 + 1
				v486.oid = ("o%016x"):format(v_u_269 + 2953576448)
				v486.id = v484
				v486.u = v485.u
				v486.t = v_u_61.now() - v483 * 7200
				v486.pend = v483 == 1 and 12 or 0
				local v487 = v_u_268
				table.insert(v487, v486)
				local v488 = v_u_61
				v488.cashAdj = v488.cashAdj - 50 * v485.u
			end
		else
			if string.sub(v460, 1, 7) ~= "refuse_" then
				return false
			end
			local v489 = v_u_81
			local v490 = string.upper
			local v491 = tostring(p459)
			v489.orderRefuse = v490((string.sub(v491, 8)))
			v_u_81.orderRefuseExtra = ({
				["BAND_HIGH"] = {
					["max"] = 1200
				},
				["BAND_LOW"] = {
					["min"] = 5
				},
				["CROSSES"] = {
					["ask"] = "41.50"
				},
				["CROSSES_BID"] = {
					["bid"] = 42
				},
				["CASH"] = {
					["need"] = 500
				}
			})[v_u_81.orderRefuse]
		end
		return true
	end
	function v_u_61.release(_) -- name: release
		-- upvalues: (copy) v_u_81
		v_u_81.hold = false
	end
	local function v_u_497() -- name: allow
		-- upvalues: (copy) v_u_81
		local v492 = v_u_81.limit - v_u_81.used
		local v493 = math.max(0, v492)
		local v494 = {
			["limit"] = nil,
			["used"] = nil,
			["left"] = nil,
			["resetIn"] = 18720,
			["tier"] = nil,
			["refunds"] = nil,
			["limit"] = v_u_81.limit,
			["used"] = v_u_81.used,
			["left"] = v493,
			["tier"] = v_u_81.tier
		}
		local v495 = {
			["used"] = 0,
			["max"] = nil
		}
		local v496 = v_u_81.limit / 2
		v495.max = math.ceil(v496)
		v494.refunds = v495
		return v494
	end
	local function v_u_510() -- name: canWhy
		-- upvalues: (copy) v_u_81, (copy) v_u_497, (copy) v_u_60, (copy) v_u_61, (copy) v_u_65, (copy) v_u_59
		local v498 = v_u_81.sw.freeze and "FREEZE" or (not v_u_81.sw.scope and "SCOPE" or (v_u_81.restricted and not v_u_81.policyReady and "POLICY_WAIT" or (v_u_81.restricted and v_u_81.restrictedMode == "block" and "PAID_BLOCKED" or nil)))
		local v499 = nil
		local v500 = nil
		if v_u_81.sw.list then
			if v_u_497().left <= 0 then
				v500 = {
					["resetIn"] = v_u_60.duration(v_u_497().resetIn)
				}
				v499 = "LIMIT"
			end
		else
			v499 = "OFF_LIST"
		end
		local v501 = nil
		local v502 = nil
		if v_u_81.sw.buy then
			local v503 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
			if math.max(0, v503) > 0 then
				v502 = {}
				local v504 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
				local v505 = math.max(0, v504)
				v502.wait = math.ceil(v505)
				v501 = "COOLDOWN"
			end
		else
			v501 = "OFF_BUY"
		end
		local v506 = v498 or (v499 or v501)
		if v498 then
			v502 = nil
		elseif v499 then
			v502 = v500
		end
		local v507
		if v506 then
			v507 = v_u_60.text(v_u_59.rules, v506, v502)
		else
			v507 = nil
		end
		local v508
		if v498 == nil then
			v508 = v499 == nil
		else
			v508 = false
		end
		local v509
		if v498 == nil then
			v509 = v501 == nil
		else
			v509 = false
		end
		return v508, v509, v506, v507
	end
	local function v_u_527() -- name: stateBody
		-- upvalues: (copy) v_u_510, (ref) v_u_86, (copy) v_u_81, (copy) v_u_61, (copy) v_u_497, (copy) v_u_65, (copy) v_u_152, (copy) v_u_58, (ref) v_u_80
		local v511, v512, v513, v514 = v_u_510()
		local v515 = #v_u_86.tx
		local v516 = v_u_81.sw
		local v517 = {
			["ok"] = true,
			["now"] = nil,
			["on"] = nil,
			["orders"] = nil,
			["allow"] = nil,
			["buyIn"] = nil,
			["restricted"] = nil,
			["policyReady"] = nil,
			["restrictedMode"] = nil,
			["can"] = nil,
			["pending"] = nil,
			["escrow"] = 0,
			["ds"] = nil,
			["tune"] = nil,
			["now"] = v_u_61.now()
		}
		local v518 = {
			["list"] = v516.list,
			["buy"] = v516.buy,
			["freeze"] = v516.freeze,
			["good"] = v516.good,
			["scope"] = v516.scope
		}
		local v519
		if v516.book == false then
			v519 = false
		else
			v519 = v_u_81.bookState ~= "off"
		end
		v518.book = v519
		v518.drain = v516.drain == true and true or v_u_81.bookState == "drain"
		v517.on = v518
		v517.orders = v_u_61.ordersState()
		v517.allow = v_u_497()
		local v520 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
		v517.buyIn = math.max(0, v520)
		v517.restricted = v_u_81.restricted
		v517.policyReady = v_u_81.policyReady
		v517.restrictedMode = v_u_81.restrictedMode
		v517.can = {
			["list"] = v511,
			["buy"] = v512,
			["why"] = v513,
			["text"] = v514
		}
		v517.pending = v515
		v517.ds = v_u_81.ds
		v517.tune = {
			["maxPrice"] = 99999999,
			["feePct"] = 5,
			["listingDays"] = 3,
			["cooldown"] = 30,
			["minPrice"] = 1,
			["minRaids"] = 3,
			["goodCondition"] = 70
		}
		if v_u_81.listRules ~= nil then
			v517.list = {
				["on"] = nil,
				["feePct"] = 1,
				["feeMin"] = 50,
				["feeMax"] = 25000,
				["capMul"] = 10,
				["capFlat"] = 1000,
				["minSales"] = 3,
				["days"] = 7,
				["on"] = v_u_81.listRules == true
			}
		end
		if v_u_81.crate ~= nil then
			v517.crate = v_u_152()
			v517.on.crates = v_u_81.crate ~= "off"
		end
		local v_u_521 = nil
		local function v522()
			-- upvalues: (ref) v_u_521, (ref) v_u_58
			v_u_521 = v_u_58.cctx.shared.BmRs
		end
		pcall(v522)
		local v523 = v_u_521
		local v524
		if type(v523) == "table" then
			local v525 = v_u_521.viewPlan
			if type(v525) == "function" then
				v524 = v_u_521
			else
				v524 = nil
			end
		else
			v524 = nil
		end
		local v526
		if v524 == nil or (v_u_80 == nil or not v_u_80.on) then
			v526 = nil
		else
			v526 = v524.viewState(v_u_80.plan, v_u_61.now(), nil)
		end
		if v526 ~= nil then
			v517.rk = v526
		end
		return v517
	end
	local function v_u_599(p528) -- name: handleGet
		-- upvalues: (copy) v_u_78, (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_527, (ref) v_u_84, (copy) v_u_164, (copy) v_u_198, (copy) v_u_173, (copy) v_u_61, (copy) v_u_193, (ref) v_u_85, (copy) v_u_358, (copy) v_u_58, (ref) v_u_80, (copy) v_u_355, (copy) v_u_403, (ref) v_u_86, (copy) v_u_366, (ref) v_u_268
		v_u_78()
		local v529 = p528.what
		if v_u_81.restricted and (v_u_81.restrictedMode == "block" and v529 ~= "bmState") then
			return {
				["ok"] = false,
				["code"] = "PAID_BLOCKED",
				["text"] = nil,
				["text"] = v_u_60.text(v_u_59.rules, "PAID_BLOCKED", nil)
			}
		end
		if v529 == "bmState" then
			return v_u_527()
		end
		if v529 == "bmPrices" then
			local v530 = {
				["ok"] = true,
				["age"] = 2,
				["stale"] = false,
				["prices"] = nil,
				["prices"] = {}
			}
			if v_u_81.stalePrices > 0 then
				local v531 = v_u_81
				v531.stalePrices = v531.stalePrices - 1
				v530.stale = true
				v530.retryIn = 1.5
			end
			if p528.listed == true then
				local v532 = 0
				for v533 in v_u_84 do
					local v534
					if v_u_81.crate == "korea" and type(v533) == "string" then
						v534 = v_u_164(v533, false) ~= nil
					else
						v534 = false
					end
					local v535
					if v534 then
						v535 = nil
					else
						v535 = v_u_198(v533)
					end
					v532 = v532 + 1
					if not v535 or v530.stale and v532 % 2 == 0 then
						continue
					end
					v530.prices[v533] = {
						["m"] = v535.m,
						["c"] = v535.c,
						["g"] = v535.g
					}
				end
				return v530
			end
			local v536 = p528.ids
			if type(v536) ~= "table" or #p528.ids > 40 then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
			for _, v537 in p528.ids do
				local v538
				if v_u_81.crate == "korea" and type(v537) == "string" then
					v538 = v_u_164(v537, false) ~= nil
				else
					v538 = false
				end
				local v539
				if v538 then
					v539 = nil
				else
					v539 = v_u_198(v537)
				end
				if not v539 then
					continue
				end
				v530.prices[v537] = v539
			end
			v530.stale = false
			return v530
		end
		if v529 == "bmItem" then
			local v540 = p528.id
			if type(v540) ~= "string" then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
			local v541
			if v_u_81.crate == "korea" and type(v540) == "string" then
				v541 = v_u_164(v540, false) ~= nil
			else
				v541 = false
			end
			if v541 then
				return {
					["ok"] = false,
					["code"] = "CRATE_TRADE",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "CRATE_TRADE", nil)
				}
			end
			if v_u_81.ds == "down" then
				return {
					["ok"] = false,
					["code"] = "STORE",
					["text"] = nil,
					["ds"] = "down",
					["text"] = v_u_60.text(v_u_59.rules, "STORE")
				}
			end
			if v_u_81.busyItem > 0 then
				local v542 = v_u_81
				v542.busyItem = v542.busyItem - 1
				return {
					["ok"] = false,
					["code"] = "BUSY",
					["text"] = nil,
					["retryIn"] = 2,
					["ds"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BUSY"),
					["ds"] = v_u_81.ds
				}
			end
			local v543 = v_u_173(v540, p528.good == true)
			local v544 = p528.offset
			local v545 = tonumber(v544) or 0
			local v546 = math.max(0, v545)
			local v547 = v546 + 1
			local v548 = #v543
			local v549 = v546 + 25
			local v550 = {}
			for v551 = v547, math.min(v548, v549) do
				local v552 = v543[v551]
				local v553 = {
					["lid"] = v552.lid,
					["n"] = v552.n,
					["p"] = v552.p,
					["u"] = v552.p / v552.n,
					["d"] = v552.d
				}
				local v554 = v552.e - v_u_61.now()
				v553.left = math.max(0, v554)
				v553.own = v552.own == true
				v553.pk = v552.pd and 1 or nil
				table.insert(v550, v553)
			end
			local v555 = v_u_193(v540)
			local v556 = {}
			for v557, v558 in v_u_85[v540] or {} do
				if v557 > 20 then
					break
				end
				if v_u_81.restricted and v558.pd then
					continue
				end
				local v559 = {
					["t"] = v558.t,
					["u"] = v558.u,
					["n"] = v558.n,
					["d"] = v558.d
				}
				table.insert(v556, v559)
			end
			local v560 = v_u_61.now() / 86400
			local v561 = math.floor(v560)
			local v562 = {}
			for v563 = v561 - 13, v561 do
				local v564 = 0
				local v565 = 0
				for _, v566 in v_u_85[v540] or {} do
					local v567 = v566.t / 86400
					if math.floor(v567) ~= v563 or v566.d ~= nil and v566.d < 70 then
						continue
					end
					v564 = v564 + v566.u * v566.n
					v565 = v565 + v566.n
				end
				if v565 <= 0 then
					break
				end
				local v568 = {
					["day"] = v563
				}
				local v569 = v564 / v565 * 100 + 0.5
				v568.avg = math.floor(v569) / 100
				v568.units = v565
				table.insert(v562, v568)
			end
			return {
				["ok"] = true,
				["id"] = nil,
				["age"] = 3,
				["stale"] = nil,
				["ds"] = nil,
				["stats"] = nil,
				["listings"] = nil,
				["total"] = nil,
				["more"] = nil,
				["hist"] = nil,
				["daily"] = nil,
				["id"] = v540,
				["stale"] = v_u_81.ds == "busy",
				["ds"] = v_u_81.ds,
				["stats"] = {
					["min"] = v555.min,
					["count"] = v555.count,
					["avg7"] = v555.avg7,
					["sold7"] = v555.sold7,
					["last"] = v555.last,
					["lastAt"] = v555.lastAt
				},
				["listings"] = v550,
				["total"] = #v543,
				["more"] = v546 + 25 < #v543,
				["hist"] = v556,
				["daily"] = v562
			}
		end
		if v529 == "bmQuote" then
			local v570 = p528.id
			if type(v570) ~= "string" then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
			local v571
			if v_u_81.crate == "korea" and type(v570) == "string" then
				v571 = v_u_164(v570, false) ~= nil
			else
				v571 = false
			end
			if v571 then
				return {
					["ok"] = false,
					["code"] = "CRATE_TRADE",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "CRATE_TRADE", nil)
				}
			end
			local v572 = v_u_193(v570)
			local v573 = {
				["ok"] = true,
				["min"] = nil,
				["count"] = nil,
				["avg7"] = nil,
				["sold7"] = nil,
				["last"] = nil,
				["lastAt"] = nil,
				["bid"] = nil,
				["rk"] = nil,
				["min"] = v572.min,
				["count"] = v572.count,
				["avg7"] = v572.avg7,
				["sold7"] = v572.sold7,
				["last"] = v572.last,
				["lastAt"] = v572.lastAt,
				["bid"] = v_u_358(v570)
			}
			local v_u_574 = nil
			local function v575()
				-- upvalues: (ref) v_u_574, (ref) v_u_58
				v_u_574 = v_u_58.cctx.shared.BmRs
			end
			pcall(v575)
			local v576 = v_u_574
			local v577
			if type(v576) == "table" then
				local v578 = v_u_574.viewPlan
				if type(v578) == "function" then
					v577 = v_u_574
				else
					v577 = nil
				end
			else
				v577 = nil
			end
			local v579
			if v577 == nil or (v_u_80 == nil or not v_u_80.on) then
				v579 = nil
			else
				v579 = v577.viewBook(v_u_80.plan, v570, v_u_61.now())
			end
			v573.rk = v579
			return v573
		end
		if v529 ~= "bmBook" then
			if v529 == "bmRestock" then
				return {
					["ok"] = true,
					["now"] = nil,
					["rk"] = nil,
					["now"] = v_u_61.now(),
					["rk"] = v_u_403()
				}
			end
			if v529 ~= "bmMine" then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
			local v580 = {}
			for _, v581 in v_u_86.live do
				table.insert(v580, v581)
			end
			local v582 = {
				["ok"] = true,
				["now"] = nil,
				["syncedAt"] = nil,
				["live"] = nil,
				["sold"] = nil,
				["back"] = nil,
				["tx"] = nil,
				["rc"] = nil,
				["orders"] = nil,
				["held"] = nil,
				["now"] = v_u_61.now(),
				["syncedAt"] = v_u_61.now() - 20,
				["live"] = v580,
				["sold"] = v_u_86.sold,
				["back"] = v_u_86.back,
				["tx"] = v_u_86.tx,
				["rc"] = v_u_86.rc,
				["orders"] = v_u_366()
			}
			local v583 = 0
			for _, v584 in v_u_268 do
				if v584.st ~= 1 then
					continue
				end
				v583 = v583 + v584.rem * v584.u
			end
			v582.held = v583
			return v582
		end
		local v585 = p528.id
		if type(v585) ~= "string" then
			return {
				["ok"] = false,
				["code"] = "BAD",
				["text"] = nil,
				["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
			}
		end
		if p528.below ~= nil then
			local v586 = p528.below
			if type(v586) ~= "number" then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
			local v587 = p528.below
			local v588 = p528.below
			if v587 ~= math.floor(v588) or p528.below < 1 then
				return {
					["ok"] = false,
					["code"] = "BAD",
					["text"] = nil,
					["text"] = v_u_60.text(v_u_59.rules, "BAD", nil)
				}
			end
		end
		local v589 = p528.id
		local v590
		if v_u_81.crate == "korea" and type(v589) == "string" then
			v590 = v_u_164(v589, false) ~= nil
		else
			v590 = false
		end
		if v590 then
			return {
				["ok"] = false,
				["code"] = "CRATE_TRADE",
				["text"] = nil,
				["text"] = v_u_60.text(v_u_59.rules, "CRATE_TRADE", nil)
			}
		end
		local v591 = v_u_355(p528.id, p528.below)
		if type(v591) == "table" and v591.ok ~= false then
			local v592 = p528.id
			local v_u_593 = nil
			local function v594()
				-- upvalues: (ref) v_u_593, (ref) v_u_58
				v_u_593 = v_u_58.cctx.shared.BmRs
			end
			pcall(v594)
			local v595 = v_u_593
			local v596
			if type(v595) == "table" then
				local v597 = v_u_593.viewPlan
				if type(v597) == "function" then
					v596 = v_u_593
				else
					v596 = nil
				end
			else
				v596 = nil
			end
			local v598
			if v596 == nil or (v_u_80 == nil or not v_u_80.on) then
				v598 = nil
			else
				v598 = v596.viewBook(v_u_80.plan, v592, v_u_61.now())
			end
			v591.rk = v598
		end
		return v591
	end
	function v_u_61.get(_, p600) -- name: get
		-- upvalues: (copy) v_u_81, (ref) v_u_67, (copy) v_u_599
		if v_u_81.hold or v_u_81.latency > 0 then
			if v_u_81.hold then
				while v_u_81.hold and v_u_67 do
					task.wait(0.1)
				end
			end
			if v_u_81.latency > 0 then
				task.wait(v_u_81.latency)
			end
		end
		if v_u_67 and not v_u_81.fail then
			return v_u_599(p600)
		else
			return nil
		end
	end
	local function v_u_607(p601, p602, p603) -- name: deny
		-- upvalues: (copy) v_u_60, (copy) v_u_59
		local v604 = {
			["code"] = p602
		}
		if p603 then
			for v605, v606 in p603 do
				v604[v605] = v606
			end
		end
		return {
			["op"] = nil,
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["op"] = p601,
			["msg"] = v_u_60.text(v_u_59.rules, p602, p603),
			["data"] = v604
		}
	end
	local function v_u_622(p608, p609, p610, p611) -- name: finishList
		-- upvalues: (ref) v_u_87, (copy) v_u_81, (copy) v_u_61, (ref) v_u_86, (ref) v_u_84, (copy) v_u_266, (copy) v_u_258
		v_u_87[p608.uid] = true
		local v612 = v_u_81
		v612.used = v612.used + 1
		local v613 = v_u_61.now() + 259200
		local v614 = p608.paid == true and 1 or nil
		local v615 = v_u_86.live
		local v616 = {
			["lid"] = nil,
			["id"] = nil,
			["n"] = nil,
			["p"] = nil,
			["fp"] = 5,
			["t"] = nil,
			["e"] = nil,
			["ix"] = "x",
			["uid"] = nil,
			["pk"] = nil,
			["lid"] = p609,
			["id"] = p608.id,
			["n"] = p611,
			["p"] = p610,
			["t"] = v_u_61.now(),
			["e"] = v613,
			["uid"] = p608.uid,
			["pk"] = v614
		}
		table.insert(v615, v616)
		v_u_84[p608.id] = v_u_84[p608.id] or {}
		local v617 = v_u_84[p608.id]
		local v618 = {
			["lid"] = nil,
			["n"] = nil,
			["p"] = nil,
			["d"] = nil,
			["e"] = nil,
			["t"] = nil,
			["own"] = true,
			["seller"] = "me",
			["pd"] = nil,
			["lid"] = p609,
			["n"] = p611,
			["p"] = p610
		}
		local v619 = p608.dur
		local v620
		if type(v619) == "number" then
			local v621 = p608.dur * 100 + 0.5
			v620 = math.floor(v621)
		else
			v620 = nil
		end
		v618.d = v620
		v618.e = v613
		v618.t = v_u_61.now()
		v618.pd = v614
		table.insert(v617, v618)
		v_u_266("l", p608.id, p611, p610, p609)
		v_u_258("listed", {
			["id"] = p608.id,
			["n"] = p611,
			["p"] = p610
		})
	end
	local function v_u_655(p623) -- name: opList
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_61, (copy) v_u_164, (copy) v_u_62, (copy) v_u_607, (copy) v_u_63, (copy) v_u_193, (copy) p_u_57, (ref) v_u_68, (ref) v_u_86, (ref) v_u_87, (copy) v_u_70, (copy) v_u_65, (copy) v_u_622
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmList",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		if not v_u_81.sw.scope then
			return {
				["op"] = "bmList",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "SCOPE", nil),
				["data"] = {
					["code"] = "SCOPE"
				}
			}
		end
		if not v_u_81.sw.list then
			return {
				["op"] = "bmList",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "OFF_LIST", nil),
				["data"] = {
					["code"] = "OFF_LIST"
				}
			}
		end
		if v_u_81.restricted and v_u_81.restrictedMode == "block" then
			return {
				["op"] = "bmList",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "PAID_BLOCKED", nil),
				["data"] = {
					["code"] = "PAID_BLOCKED"
				}
			}
		end
		if v_u_81.ds == "down" then
			return {
				["op"] = "bmList",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "STORE", nil),
				["data"] = {
					["code"] = "STORE"
				}
			}
		end
		local v624 = p623.uid
		if type(v624) == "string" then
			local v625 = p623.n
			if type(v625) == "number" then
				local v626 = p623.price
				if type(v626) == "number" then
					local v627 = p623.uid
					for _, v_u_629 in v_u_61:stash() or {} do
						if v_u_629.uid ~= v627 then
							continue
						end
					end
					local v_u_629 = nil
					if not v_u_629 then
						return {
							["op"] = "bmList",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "NOT_STASH", nil),
							["data"] = {
								["code"] = "NOT_STASH"
							}
						}
					end
					local v630 = v_u_164(v_u_629.id, false)
					if v630 then
						return {
							["op"] = "bmList",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, v630, nil),
							["data"] = {
								["code"] = v630
							}
						}
					end
					local v631 = p623.n
					local v_u_632 = math.floor(v631)
					if v_u_632 < 1 or (v_u_629.n or 1) < v_u_632 then
						return {
							["op"] = "bmList",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "QTY", nil),
							["data"] = {
								["code"] = "QTY"
							}
						}
					end
					local v633 = p623.price
					local v_u_634 = math.floor(v633)
					if v_u_634 < v_u_632 or v_u_634 > 99999999 then
						return {
							["op"] = "bmList",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "PRICE_RANGE", nil),
							["data"] = {
								["code"] = "PRICE_RANGE"
							}
						}
					end
					local v635, v636 = v_u_62.checkInst(v_u_629, {
						["restricted"] = nil,
						["insured"] = false,
						["topLevel"] = true,
						["crates"] = true,
						["resolved"] = true,
						["tradeFailed"] = false,
						["restricted"] = v_u_81.restricted
					})
					if not v635 and (v636 ~= "STRIP_FIRST" or p623.strip ~= true) then
						local v637 = v636 or "BAD"
						return {
							["op"] = "bmList",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, v637, nil),
							["data"] = {
								["code"] = v637
							}
						}
					end
					if v_u_81.used >= v_u_81.limit then
						return v_u_607("bmList", "LIMIT", {
							["resetIn"] = v_u_60.duration(18720)
						})
					end
					if v_u_81.listRules == true then
						local v638 = {
							["on"] = nil,
							["feePct"] = 1,
							["feeMin"] = 50,
							["feeMax"] = 25000,
							["capMul"] = 10,
							["capFlat"] = 1000,
							["minSales"] = 3,
							["days"] = 7,
							["on"] = v_u_81.listRules == true
						}
						local v639 = v_u_63.get(v_u_629.id)
						local v640
						if v_u_193(v_u_629.id).avg7 == nil then
							v640 = v_u_60.listCap(v_u_632, v_u_60.listUnitValue(v_u_629.id, v639), v638)
						else
							v640 = nil
						end
						if v640 ~= nil and v640 < v_u_634 then
							return v_u_607("bmList", "PRICE_CAP", {
								["max"] = v640
							})
						end
						local v641 = v_u_60.listFee(v_u_634, v638)
						local v642 = p_u_57.getCash() + v_u_61.cashAdj
						if v642 < v641 then
							return v_u_607("bmList", "LIST_FEE_CASH", {
								["fee"] = v641,
								["need"] = v641 - v642
							})
						end
						local v643 = v_u_61
						v643.cashAdj = v643.cashAdj - v641
					end
					v_u_68 = v_u_68 + 1
					local v_u_644 = ("l%016x"):format(v_u_68 + 2703024128)
					if v_u_81.opMode ~= "processing" then
						v_u_622(v_u_629, v_u_644, v_u_634, v_u_632)
						local v645 = v_u_60.TEXT.listed
						local v646 = {
							["state"] = "listed",
							["lid"] = nil,
							["left"] = nil,
							["lid"] = v_u_644
						}
						local v647 = v_u_81.limit - v_u_81.used
						v646.left = math.max(0, v647)
						return {
							["op"] = "bmList",
							["ok"] = true,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v645,
							["data"] = v646
						}
					end
					local v648 = v_u_81
					v648.used = v648.used + 0
					local v649 = v_u_86.tx
					local v650 = {
						["k"] = "L",
						["st"] = 1,
						["lid"] = nil,
						["id"] = nil,
						["n"] = nil,
						["p"] = nil,
						["age"] = 0,
						["lid"] = v_u_644,
						["id"] = v_u_629.id,
						["n"] = v_u_632,
						["p"] = v_u_634
					}
					table.insert(v649, v650)
					v_u_87[v_u_629.uid] = true
					local v651 = v_u_70
					local v654 = {
						["at"] = 1760000000 + (v_u_61.clock() - v_u_65) + 8,
						["fn"] = function() -- name: fn
							-- upvalues: (ref) v_u_86, (copy) v_u_644, (ref) v_u_87, (copy) v_u_629, (ref) v_u_622, (copy) v_u_634, (copy) v_u_632
							for v652, v653 in v_u_86.tx do
								if v653.lid ~= v_u_644 then
									continue
								end
								table.remove(v_u_86.tx, v652)
							end
							v_u_87[v_u_629.uid] = nil
							v_u_622(v_u_629, v_u_644, v_u_634, v_u_632)
						end
					}
					table.insert(v651, v654)
					return {
						["op"] = "bmList",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = v_u_60.TEXT.workingList,
						["data"] = {
							["state"] = "processing"
						}
					}
				end
			end
		end
		return {
			["op"] = "bmList",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
			["data"] = {
				["code"] = "BAD"
			}
		}
	end
	local function v_u_668(p656, p657) -- name: nextBody
		-- upvalues: (copy) v_u_173, (copy) v_u_61
		local v658 = v_u_173(p656, p657 == true)
		local v659 = #v658
		local v660 = {}
		for v661 = 1, math.min(v659, 25) do
			local v662 = v658[v661]
			local v663 = {
				["lid"] = v662.lid,
				["n"] = v662.n,
				["p"] = v662.p,
				["u"] = v662.p / v662.n,
				["d"] = v662.d
			}
			local v664 = v662.e - v_u_61.now()
			v663.left = math.max(0, v664)
			v663.own = v662.own == true
			v663.pk = v662.pd and 1 or nil
			table.insert(v660, v663)
		end
		local v665 = nil
		for _, v666 in v658 do
			if v666.own then
				continue
			end
			local v667 = v666.p / v666.n * 100 + 0.5
			v665 = math.floor(v667) / 100
		end
		return {
			["listings"] = v660,
			["total"] = #v658,
			["more"] = #v658 > 25,
			["min"] = v665
		}
	end
	function v_u_61.addLot(_, p669, p670, p671, p672) -- name: addLot
		-- upvalues: (ref) v_u_68, (ref) v_u_84, (copy) v_u_61
		v_u_68 = v_u_68 + 1
		local v673 = ("l%016x"):format(v_u_68 + 2703024128)
		v_u_84[p669] = v_u_84[p669] or {}
		local v674 = v_u_84[p669]
		local v675 = {
			["lid"] = nil,
			["n"] = nil,
			["p"] = nil,
			["d"] = nil,
			["e"] = nil,
			["t"] = nil,
			["own"] = nil,
			["seller"] = nil,
			["lid"] = v673,
			["n"] = p670
		}
		local v676 = p671 * p670 + 0.5
		local v677 = math.floor(v676)
		v675.p = math.max(p670, v677)
		v675.e = v_u_61.now() + 259200
		v675.t = v_u_61.now()
		v675.own = p672 == true
		v675.seller = p672 == true and "me" or "s7"
		table.insert(v674, v675)
		return v673
	end
	local function v_u_684(p678, p679) -- name: takeAway
		-- upvalues: (ref) v_u_84
		for _, v680 in v_u_84[p678] or {} do
			if v680.lid ~= p679 then
				continue
			end
			v681 = v_u_84[p678]
		end
		local v681 = nil
		if v681 then
			for v682, v683 in v681 do
				if v683.lid ~= p679 then
					continue
				end
				table.remove(v681, v682)
				return
			end
		end
	end
	local function v_u_756(p685) -- name: opBuyBest
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_164, (copy) v_u_61, (copy) v_u_65, (copy) v_u_607, (copy) v_u_173, (copy) v_u_684, (copy) v_u_668, (copy) p_u_57, (copy) v_u_266, (copy) v_u_258, (copy) v_u_63
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		if not v_u_81.sw.scope then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "SCOPE", nil),
				["data"] = {
					["code"] = "SCOPE"
				}
			}
		end
		if not v_u_81.sw.buy or v_u_81.sw.best == false then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "OFF_BUY", nil),
				["data"] = {
					["code"] = "OFF_BUY"
				}
			}
		end
		if v_u_81.restricted and v_u_81.restrictedMode == "block" then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "PAID_BLOCKED", nil),
				["data"] = {
					["code"] = "PAID_BLOCKED"
				}
			}
		end
		if v_u_81.ds == "down" then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "STORE", nil),
				["data"] = {
					["code"] = "STORE"
				}
			}
		end
		local v686 = p685.id
		if type(v686) ~= "string" then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v687 = p685.maxUnit
		if type(v687) ~= "number" or p685.maxUnit < 1 then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v688 = p685.maxUnit
		local v689 = p685.maxUnit
		if v688 ~= math.floor(v689) then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v690 = v_u_164(p685.id, true)
		if v690 then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, v690, nil),
				["data"] = {
					["code"] = v690
				}
			}
		end
		local v691, v692, v693, v694, v695, v696, v697, v698, v699, v700, v701, v702, v703, v704, v705, v706, v707, v708, v709, v710, v711, v712, v713, v714, v715, v716
		if p685.maxTotal == nil then
			v734 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
			v735 = math.max(0, v734)
			if v735 > 0 then
				return v_u_607("bmBuyBest", "COOLDOWN", {
					["wait"] = math.ceil(v735)
				})
			end
			if v_u_81.appear then
				v691 = nil
				for v736, v737 in v_u_173(p685.id, false) do
					if v737.own then
						continue
					end
					v691 = v737
				end
				v692 = v_u_81.appear
				v_u_81.appear = false
				if v691 then
					v693 = v691.p / v691.n * v692.factor
					v694 = math.max(1, v693)
					if v692.only then
						for v738, v739 in v_u_173(p685.id, false) do
							if v739.own then
								continue
							end
							v_u_684(p685.id, v739.lid)
						end
					end
					v_u_61:addLot(p685.id, v692.n, v694)
				end
			end
			v740 = p685.good == true
			v741 = {}
			for v742, v743 in v_u_173(p685.id, v740) do
				if v743.own then
					continue
				end
				table.insert(v741, v743)
			end
			if #v741 == 0 then
				v695 = {
					["op"] = "bmBuyBest",
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v_u_60.text(v_u_59.rules, "NOBODY", nil),
					["data"] = {
						["code"] = "NOBODY"
					}
				}
				v695.data.next = v_u_668(p685.id, v740)
				return v695
			end
			v744 = {}
			for v745, v746 in v741 do
				if v746.p > p685.maxUnit * v746.n then
					continue
				end
				table.insert(v744, v746)
			end
			if #v744 == 0 then
				v696 = v741[1]
				v697 = v696.p / v696.n * 100 + 0.5
				v698 = math.floor(v697) / 100
				v699 = v_u_607("bmBuyBest", "NO_RANGE", {
					["price"] = v_u_60.unitText(v741[1].p, v741[1].n),
					["unit"] = v698
				})
				v699.data.next = v_u_668(p685.id, v740)
				return v699
			end
			if p685.maxTotal == nil then
				v700 = v744
			else
				v700 = {}
				for v747, v748 in v744 do
					if v748.p > p685.maxTotal then
						continue
					end
					table.insert(v700, v748)
				end
				if #v700 == 0 then
					v701 = {
						["op"] = "bmBuyBest",
						["ok"] = false,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = v_u_60.text(v_u_59.rules, "TOTAL_MOVED", nil),
						["data"] = {
							["code"] = "TOTAL_MOVED"
						}
					}
					v701.data.next = v_u_668(p685.id, v740)
					v701.data.firstTotal = v744[1].p
					return v701
				end
			end
			v749 = 0
			v750 = 0
			for v751, v752 in v700 do
				if v749 >= 3 then
					break
				end
				v702 = p_u_57.getCash() + v_u_61.cashAdj
				if v702 < v752.p then
					return v_u_607("bmBuyBest", "CASH", {
						["need"] = v752.p - v702
					})
				end
				v749 = v749 + 1
				if v_u_81.opMode ~= "race" or v750 >= v_u_81.raceLots then
					v_u_684(p685.id, v752.lid)
					v_u_81.lastBuy = 1760000000 + (v_u_61.clock() - v_u_65)
					v703 = v_u_61
					v703.cashAdj = v703.cashAdj - v752.p
					v704 = v_u_266
					v705 = p685.id
					v706 = v752.n
					v707 = v752.p
					v708 = v752.lid
					v704("b", v705, v706, v707, "b" .. string.sub(v708, 2))
					v_u_258("bought", {
						["id"] = p685.id,
						["n"] = v752.n,
						["p"] = v752.p
					})
					v709 = v_u_63.get(p685.id) and v_u_63.get(p685.id).name or p685.id
					v710 = ("Bought %s x %s for $%s each. It is in your stash."):format(v_u_60.commas(v752.n), v709, v_u_60.unitText(v752.p, v752.n))
					v711 = {
						["state"] = "done",
						["tx"] = nil,
						["lid"] = nil,
						["n"] = nil,
						["p"] = nil,
						["d"] = nil,
						["unit"] = nil,
						["tried"] = nil
					}
					v712 = v752.lid
					v711.tx = "b" .. string.sub(v712, 2)
					v711.lid = v752.lid
					v711.n = v752.n
					v711.p = v752.p
					v711.d = v752.d
					v711.unit = v752.p / v752.n
					v711.tried = v749
					return {
						["op"] = "bmBuyBest",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = v710,
						["data"] = v711
					}
				end
				v750 = v750 + 1
				v_u_684(p685.id, v752.lid)
			end
			v753 = nil
			for v754, v755 in v_u_173(p685.id, v740) do
				if v755.own then
					continue
				end
				v753 = v755
			end
			if v753 then
				v713 = v_u_607
				v714 = {
					["price"] = v_u_60.unitText(v753.p, v753.n)
				}
				v715 = v753.p / v753.n * 100 + 0.5
				v714.unit = math.floor(v715) / 100
				v714.tried = v749
				v716 = v713("bmBuyBest", "RANGE_TAKEN", v714)
			else
				v716 = v_u_607("bmBuyBest", "NOBODY", {
					["tried"] = v749
				})
			end
			v716.data.next = v_u_668(p685.id, v740)
			return v716
		end
		local v731 = p685.maxTotal
		if type(v731) ~= "number" or (p685.maxTotal ~= p685.maxTotal or (p685.maxTotal < 1 or p685.maxTotal > 99999999)) then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v732 = p685.maxTotal
		local v733 = p685.maxTotal
		if v732 ~= math.floor(v733) then
			return {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v734 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
		local v735 = math.max(0, v734)
		if v735 > 0 then
			return v_u_607("bmBuyBest", "COOLDOWN", {
				["wait"] = math.ceil(v735)
			})
		end
		if v_u_81.appear then
			v691 = nil
			for v736, v737 in v_u_173(p685.id, false) do
				if v737.own then
					continue
				end
				v691 = v737
			end
			v692 = v_u_81.appear
			v_u_81.appear = false
			if v691 then
				v693 = v691.p / v691.n * v692.factor
				v694 = math.max(1, v693)
				if v692.only then
					for v738, v739 in v_u_173(p685.id, false) do
						if v739.own then
							continue
						end
						v_u_684(p685.id, v739.lid)
					end
				end
				v_u_61:addLot(p685.id, v692.n, v694)
			end
		end
		local v740 = p685.good == true
		local v741 = {}
		for v742, v743 in v_u_173(p685.id, v740) do
			if v743.own then
				continue
			end
			table.insert(v741, v743)
		end
		if #v741 == 0 then
			v695 = {
				["op"] = "bmBuyBest",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "NOBODY", nil),
				["data"] = {
					["code"] = "NOBODY"
				}
			}
			v695.data.next = v_u_668(p685.id, v740)
			return v695
		end
		local v744 = {}
		for v745, v746 in v741 do
			if v746.p > p685.maxUnit * v746.n then
				continue
			end
			table.insert(v744, v746)
		end
		if #v744 == 0 then
			v696 = v741[1]
			v697 = v696.p / v696.n * 100 + 0.5
			v698 = math.floor(v697) / 100
			v699 = v_u_607("bmBuyBest", "NO_RANGE", {
				["price"] = v_u_60.unitText(v741[1].p, v741[1].n),
				["unit"] = v698
			})
			v699.data.next = v_u_668(p685.id, v740)
			return v699
		end
		if p685.maxTotal == nil then
			v700 = v744
		else
			v700 = {}
			for v747, v748 in v744 do
				if v748.p > p685.maxTotal then
					continue
				end
				table.insert(v700, v748)
			end
			if #v700 == 0 then
				v701 = {
					["op"] = "bmBuyBest",
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v_u_60.text(v_u_59.rules, "TOTAL_MOVED", nil),
					["data"] = {
						["code"] = "TOTAL_MOVED"
					}
				}
				v701.data.next = v_u_668(p685.id, v740)
				v701.data.firstTotal = v744[1].p
				return v701
			end
		end
		local v749 = 0
		local v750 = 0
		for v751, v752 in v700 do
			if v749 >= 3 then
				break
			end
			v702 = p_u_57.getCash() + v_u_61.cashAdj
			if v702 < v752.p then
				return v_u_607("bmBuyBest", "CASH", {
					["need"] = v752.p - v702
				})
			end
			v749 = v749 + 1
			if v_u_81.opMode ~= "race" or v750 >= v_u_81.raceLots then
				v_u_684(p685.id, v752.lid)
				v_u_81.lastBuy = 1760000000 + (v_u_61.clock() - v_u_65)
				v703 = v_u_61
				v703.cashAdj = v703.cashAdj - v752.p
				v704 = v_u_266
				v705 = p685.id
				v706 = v752.n
				v707 = v752.p
				v708 = v752.lid
				v704("b", v705, v706, v707, "b" .. string.sub(v708, 2))
				v_u_258("bought", {
					["id"] = p685.id,
					["n"] = v752.n,
					["p"] = v752.p
				})
				v709 = v_u_63.get(p685.id) and v_u_63.get(p685.id).name or p685.id
				v710 = ("Bought %s x %s for $%s each. It is in your stash."):format(v_u_60.commas(v752.n), v709, v_u_60.unitText(v752.p, v752.n))
				v711 = {
					["state"] = "done",
					["tx"] = nil,
					["lid"] = nil,
					["n"] = nil,
					["p"] = nil,
					["d"] = nil,
					["unit"] = nil,
					["tried"] = nil
				}
				v712 = v752.lid
				v711.tx = "b" .. string.sub(v712, 2)
				v711.lid = v752.lid
				v711.n = v752.n
				v711.p = v752.p
				v711.d = v752.d
				v711.unit = v752.p / v752.n
				v711.tried = v749
				return {
					["op"] = "bmBuyBest",
					["ok"] = true,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v710,
					["data"] = v711
				}
			end
			v750 = v750 + 1
			v_u_684(p685.id, v752.lid)
		end
		local v753 = nil
		for v754, v755 in v_u_173(p685.id, v740) do
			if v755.own then
				continue
			end
			v753 = v755
		end
		if v753 then
			v713 = v_u_607
			v714 = {
				["price"] = v_u_60.unitText(v753.p, v753.n)
			}
			v715 = v753.p / v753.n * 100 + 0.5
			v714.unit = math.floor(v715) / 100
			v714.tried = v749
			v716 = v713("bmBuyBest", "RANGE_TAKEN", v714)
		else
			v716 = v_u_607("bmBuyBest", "NOBODY", {
				["tried"] = v749
			})
		end
		v716.data.next = v_u_668(p685.id, v740)
		return v716
	end
	local function v_u_804(p_u_757) -- name: opBuy
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_164, (copy) v_u_61, (copy) v_u_65, (copy) v_u_607, (ref) v_u_84, (copy) v_u_684, (copy) v_u_173, (copy) v_u_668, (copy) p_u_57, (ref) v_u_86, (copy) v_u_70, (copy) v_u_266, (copy) v_u_258
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		if not v_u_81.sw.scope then
			return {
				["op"] = "bmBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "SCOPE", nil),
				["data"] = {
					["code"] = "SCOPE"
				}
			}
		end
		if not v_u_81.sw.buy then
			return {
				["op"] = "bmBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "OFF_BUY", nil),
				["data"] = {
					["code"] = "OFF_BUY"
				}
			}
		end
		if v_u_81.restricted and v_u_81.restrictedMode == "block" then
			return {
				["op"] = "bmBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "PAID_BLOCKED", nil),
				["data"] = {
					["code"] = "PAID_BLOCKED"
				}
			}
		end
		if v_u_81.ds == "down" then
			return {
				["op"] = "bmBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "STORE", nil),
				["data"] = {
					["code"] = "STORE"
				}
			}
		end
		local v758 = p_u_757.id
		if type(v758) == "string" then
			local v759 = p_u_757.lid
			if type(v759) == "string" then
				local v760 = p_u_757.price
				if type(v760) == "number" then
					local v761 = v_u_164(p_u_757.id, true)
					if v761 then
						return {
							["op"] = "bmBuy",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, v761, nil),
							["data"] = {
								["code"] = v761
							}
						}
					end
					local v762 = v_u_81.lastBuy + 30 - (1760000000 + (v_u_61.clock() - v_u_65))
					local v763 = math.max(0, v762)
					if v763 > 0 then
						return v_u_607("bmBuy", "COOLDOWN", {
							["wait"] = math.ceil(v763)
						})
					end
					local v764 = p_u_757.id
					local v765 = p_u_757.lid
					for _, v767 in v_u_84[v764] or {} do
						if v767.lid ~= v765 then
							continue
						end
						local _ = v_u_84[v764]
					end
					local v767 = nil
					if v767 and v_u_81.opMode == "race" then
						v_u_684(p_u_757.id, p_u_757.lid)
						if v_u_81.escrowDelay > 0 then
							local v_u_768 = v767.p
							local v769 = v_u_61
							v769.cashAdj = v769.cashAdj - v_u_768
							task.delay(v_u_81.escrowDelay, function()
								-- upvalues: (ref) v_u_61, (copy) v_u_768
								local v770 = v_u_61
								v770.cashAdj = v770.cashAdj + v_u_768
							end)
						end
						if v_u_81.nextFactor then
							local v771 = v_u_173(p_u_757.id, false)
							if v771[1] and not v771[1].own then
								local v772 = v771[1]
								local v773 = v771[1].n
								local v774 = v767.p / v767.n * v771[1].n * v_u_81.nextFactor
								local v775 = math.floor(v774)
								v772.p = math.max(v773, v775)
							end
						end
						v_u_81.opMode = "now"
						local v776 = {
							["op"] = "bmBuy",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "GONE", nil),
							["data"] = {
								["code"] = "GONE"
							}
						}
						v776.data.next = v_u_668(p_u_757.id)
						v776.data.free = true
						return v776
					end
					if not v767 or v_u_81.restricted and v767.pd then
						local v777 = {
							["op"] = "bmBuy",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "GONE", nil),
							["data"] = {
								["code"] = "GONE"
							}
						}
						v777.data.next = v_u_668(p_u_757.id)
						return v777
					end
					if v767.own then
						return {
							["op"] = "bmBuy",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "OWN", nil),
							["data"] = {
								["code"] = "OWN"
							}
						}
					end
					if v767.p ~= p_u_757.price then
						return v_u_607("bmBuy", "PRICE", {
							["price"] = v767.p
						})
					end
					local v778 = p_u_57.getCash() + v_u_61.cashAdj
					if v778 < v767.p then
						return v_u_607("bmBuy", "CASH", {
							["need"] = v767.p - v778
						})
					end
					local function v_u_785() -- name: remove
						-- upvalues: (copy) p_u_757, (ref) v_u_84
						local v779 = p_u_757.id
						local v780 = p_u_757.lid
						for _, v781 in v_u_84[v779] or {} do
							if v781.lid ~= v780 then
								continue
							end
							v782 = v_u_84[v779]
						end
						local v782 = nil
						if v782 then
							for v783, v784 in v782 do
								if v784.lid ~= p_u_757.lid then
									continue
								end
								table.remove(v782, v783)
								return
							end
						end
					end
					v_u_81.lastBuy = 1760000000 + (v_u_61.clock() - v_u_65)
					local v786 = v_u_61
					v786.cashAdj = v786.cashAdj - v767.p
					if v_u_81.opMode == "refund" or v_u_81.opMode == "processing" then
						local v787 = v_u_86.tx
						local v788 = {
							["k"] = "B",
							["st"] = 1,
							["tx"] = "b0000000000000003",
							["id"] = nil,
							["n"] = nil,
							["p"] = nil,
							["age"] = 0,
							["id"] = p_u_757.id,
							["n"] = v767.n,
							["p"] = v767.p
						}
						table.insert(v787, v788)
						local v_u_789 = v767.p
						local v_u_790 = v767.n
						local v791 = v_u_70
						local v795 = {
							["at"] = 1760000000 + (v_u_61.clock() - v_u_65) + 6,
							["fn"] = function() -- name: fn
								-- upvalues: (ref) v_u_86, (ref) v_u_81, (ref) v_u_61, (copy) v_u_789, (copy) v_u_785, (ref) v_u_266, (copy) p_u_757, (copy) v_u_790, (ref) v_u_258
								for v792, v793 in v_u_86.tx do
									if v793.tx ~= "b0000000000000003" then
										continue
									end
									table.remove(v_u_86.tx, v792)
								end
								if v_u_81.opMode == "refund" then
									local v794 = v_u_61
									v794.cashAdj = v794.cashAdj + v_u_789
									v_u_81.lastBuy = -1000000000
									v_u_785()
									v_u_266("r", p_u_757.id, v_u_790, v_u_789, "b0000000000000003")
									v_u_258("refund", {
										["id"] = p_u_757.id,
										["n"] = v_u_790,
										["p"] = v_u_789
									})
								else
									v_u_785()
									v_u_266("b", p_u_757.id, v_u_790, v_u_789, "b0000000000000003")
									v_u_258("bought", {
										["id"] = p_u_757.id,
										["n"] = v_u_790,
										["p"] = v_u_789
									})
								end
							end
						}
						table.insert(v791, v795)
						return {
							["op"] = "bmBuy",
							["ok"] = true,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.TEXT.working,
							["data"] = {
								["state"] = "processing",
								["tx"] = "b0000000000000003"
							}
						}
					end
					v_u_785()
					local v796 = v_u_266
					local v797 = p_u_757.id
					local v798 = v767.n
					local v799 = v767.p
					local v800 = p_u_757.lid
					v796("b", v797, v798, v799, "b" .. string.sub(v800, 2))
					v_u_258("bought", {
						["id"] = p_u_757.id,
						["n"] = v767.n,
						["p"] = v767.p
					})
					local v801 = v_u_60.TEXT.bought
					local v802 = {
						["state"] = "done",
						["tx"] = nil
					}
					local v803 = p_u_757.lid
					v802.tx = "b" .. string.sub(v803, 2)
					return {
						["op"] = "bmBuy",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = v801,
						["data"] = v802
					}
				end
			end
		end
		return {
			["op"] = "bmBuy",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
			["data"] = {
				["code"] = "BAD"
			}
		}
	end
	local function v_u_815(p805) -- name: opCancel
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (ref) v_u_86, (ref) v_u_84, (ref) v_u_87, (copy) v_u_266, (copy) v_u_258
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmCancel",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		local v806 = p805.lid
		if type(v806) ~= "string" then
			return {
				["op"] = "bmCancel",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		for v807, v808 in v_u_86.live do
			if v808.lid ~= p805.lid then
				continue
			end
			table.remove(v_u_86.live, v807)
			local v809 = v808.id
			local v810 = v808.lid
			for _, v811 in v_u_84[v809] or {} do
				if v811.lid ~= v810 then
					continue
				end
				v812 = v_u_84[v809]
			end
			local v812 = nil
			if v812 then
				for v813, v814 in v812 do
					if v814.lid ~= v808.lid then
						continue
					end
					table.remove(v812, v813)
				end
			end
			if v808.uid then
				v_u_87[v808.uid] = nil
			end
			v_u_266("c", v808.id, v808.n, v808.p, v808.lid)
			v_u_258("back", {
				["id"] = v808.id,
				["n"] = v808.n
			})
			return {
				["op"] = "bmCancel",
				["ok"] = true,
				["msg"] = "",
				["data"] = nil,
				["data"] = {
					["state"] = "returned",
					["lid"] = nil,
					["lid"] = v808.lid
				}
			}
		end
		return {
			["op"] = "bmCancel",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v_u_60.text(v_u_59.rules, "NOT_MINE", nil),
			["data"] = {
				["code"] = "NOT_MINE"
			}
		}
	end
	local function v_u_826(p816) -- name: opClaim
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (ref) v_u_86, (copy) v_u_266, (copy) v_u_61
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmClaim",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		local v817 = 0
		local v818 = 0
		local v819 = {}
		local v820 = 0
		local v821 = {}
		for _, v822 in v_u_86.sold do
			if v822.done == true then
				table.insert(v819, v822)
			elseif p816.lid == nil or p816.lid == v822.lid then
				v817 = v817 + v822.net
				v818 = v818 + 1
				v_u_266("s", v822.id, v822.n, v822.net, v822.lid)
			else
				table.insert(v819, v822)
			end
		end
		for _, v823 in v_u_86.back do
			if v823.done == true then
				table.insert(v821, v823)
			elseif p816.lid == nil or p816.lid == v823.lid then
				v820 = v820 + v823.n
				v_u_266("e", v823.id, v823.n, 0, v823.lid)
			else
				table.insert(v821, v823)
			end
		end
		if v818 == 0 and v820 == 0 then
			return {
				["op"] = "bmClaim",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "NOTHING", nil),
				["data"] = {
					["code"] = "NOTHING"
				}
			}
		end
		local v824 = v_u_86
		v_u_86.sold = v819
		v824.back = v821
		local v825 = v_u_61
		v825.cashAdj = v825.cashAdj + v817
		return {
			["op"] = "bmClaim",
			["ok"] = true,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = ("Claimed %s."):format(v_u_60.money(v817)),
			["data"] = {
				["cash"] = v817,
				["sales"] = v818,
				["items"] = v820
			}
		}
	end
	local function v_u_828(p827) -- name: orderGate
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (copy) v_u_607
		if v_u_81.sw.freeze then
			return {
				["op"] = nil,
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["op"] = p827,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		elseif v_u_81.sw.scope then
			if v_u_81.bookState == "drain" or v_u_81.sw.drain then
				return {
					["op"] = nil,
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["op"] = p827,
					["msg"] = v_u_60.text(v_u_59.rules, "DRAIN", nil),
					["data"] = {
						["code"] = "DRAIN"
					}
				}
			elseif v_u_81.bookState == "off" or v_u_81.sw.book == false then
				return {
					["op"] = nil,
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["op"] = p827,
					["msg"] = v_u_60.text(v_u_59.rules, "OFF_BOOK", nil),
					["data"] = {
						["code"] = "OFF_BOOK"
					}
				}
			elseif v_u_81.restricted and v_u_81.restrictedMode == "block" then
				return {
					["op"] = nil,
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["op"] = p827,
					["msg"] = v_u_60.text(v_u_59.rules, "PAID_BLOCKED", nil),
					["data"] = {
						["code"] = "PAID_BLOCKED"
					}
				}
			elseif v_u_81.ds == "down" then
				return {
					["op"] = nil,
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["op"] = p827,
					["msg"] = v_u_60.text(v_u_59.rules, "STORE", nil),
					["data"] = {
						["code"] = "STORE"
					}
				}
			elseif v_u_81.orderRefuse then
				return v_u_607(p827, v_u_81.orderRefuse, v_u_81.orderRefuseExtra)
			else
				return nil
			end
		else
			return {
				["op"] = nil,
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["op"] = p827,
				["msg"] = v_u_60.text(v_u_59.rules, "SCOPE", nil),
				["data"] = {
					["code"] = "SCOPE"
				}
			}
		end
	end
	local function v_u_869(p829) -- name: opOrder
		-- upvalues: (copy) v_u_828, (copy) v_u_60, (copy) v_u_59, (copy) v_u_164, (copy) v_u_63, (copy) v_u_62, (ref) v_u_268, (copy) v_u_81, (copy) v_u_320, (copy) v_u_607, (copy) v_u_309, (copy) p_u_57, (copy) v_u_61, (ref) v_u_269, (ref) v_u_86, (copy) v_u_70, (copy) v_u_65, (copy) v_u_266, (copy) v_u_258
		local v830 = v_u_828("bmOrder")
		if v830 then
			return v830
		end
		local v_u_831 = p829.id
		local v_u_832 = p829.n
		local v_u_833 = p829.price
		if type(v_u_831) == "string" then
			local v834
			if type(v_u_832) == "number" and (v_u_832 == v_u_832 and (v_u_832 == math.floor(v_u_832) and v_u_832 >= 1)) then
				v834 = v_u_832 <= 255
			else
				v834 = false
			end
			if v834 then
				local v835
				if type(v_u_833) == "number" and (v_u_833 == v_u_833 and (v_u_833 == math.floor(v_u_833) and v_u_833 >= 1)) then
					v835 = v_u_833 <= 99999999
				else
					v835 = false
				end
				if v835 then
					local v836 = v_u_164(v_u_831, true)
					if v836 then
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, v836, nil),
							["data"] = {
								["code"] = v836
							}
						}
					end
					local v837 = v_u_63.get(v_u_831)
					if not v837 then
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "UNKNOWN_ITEM", nil),
							["data"] = {
								["code"] = "UNKNOWN_ITEM"
							}
						}
					end
					local v838, v839 = v_u_62.listableDef(v837)
					if not v838 then
						local v840 = v839 or "NO_TRADE_CLASS"
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, v840, nil),
							["data"] = {
								["code"] = v840
							}
						}
					end
					if (v837.stack or 1) <= 1 and v_u_832 > 20 then
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "QTY_STACK", nil),
							["data"] = {
								["code"] = "QTY_STACK"
							}
						}
					end
					local v841 = 0
					for _, v842 in v_u_268 do
						if v842.st ~= 1 then
							continue
						end
						v841 = v841 + 1
					end
					if (v_u_81.orderLimit or 50) <= v841 then
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "ORDERS_FULL", nil),
							["data"] = {
								["code"] = "ORDERS_FULL"
							}
						}
					end
					if v_u_60.bk ~= nil then
						local v843 = v_u_60.bk.step
						if type(v843) == "function" then
							v_u_833 = v_u_60.bk.step(v_u_833) or v_u_833
						end
					end
					local v_u_844 = v_u_833 * v_u_832
					if v_u_844 > 99999999 then
						return {
							["op"] = "bmOrder",
							["ok"] = false,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.text(v_u_59.rules, "PRICE_RANGE", nil),
							["data"] = {
								["code"] = "PRICE_RANGE"
							}
						}
					end
					local v845, v846 = v_u_320(v_u_831)
					if v846 < v_u_833 then
						return v_u_607("bmOrder", "BAND_HIGH", {
							["max"] = v846
						})
					end
					if v_u_833 < v845 then
						return v_u_607("bmOrder", "BAND_LOW", {
							["min"] = v845
						})
					end
					local v847 = nil
					for _, v848 in v_u_309(v_u_831) do
						if v848.own then
							continue
						end
						v847 = v848
					end
					if v847 and v847.u <= v_u_833 then
						return v_u_607("bmOrder", "CROSSES", {
							["ask"] = v_u_60.unitText(v847.u, 1)
						})
					end
					local v849 = p_u_57.getCash() + v_u_61.cashAdj
					if v849 < v_u_844 then
						return v_u_607("bmOrder", "CASH", {
							["need"] = v_u_844 - v849
						})
					end
					local v850 = v_u_61
					v850.cashAdj = v850.cashAdj - v_u_844
					local v_u_851 = {
						["oid"] = nil,
						["id"] = nil,
						["q"] = nil,
						["rem"] = nil,
						["u"] = nil,
						["t"] = nil,
						["st"] = 1,
						["shown"] = true,
						["pend"] = 0
					}
					v_u_269 = v_u_269 + 1
					v_u_851.oid = ("o%016x"):format(v_u_269 + 2953576448)
					v_u_851.id = v_u_831
					v_u_851.q = v_u_832
					v_u_851.rem = v_u_832
					v_u_851.u = v_u_833
					v_u_851.t = v_u_61.now()
					if v837.dur ~= nil or (v837.category == "firearm" or v837.category == "armor") then
						v_u_851.mc = 70
					end
					if v_u_81.orderMode == "processing" then
						v_u_851.shown = false
						local v852 = v_u_86.tx
						local v853 = {
							["k"] = "O",
							["st"] = 1,
							["oid"] = nil,
							["id"] = nil,
							["n"] = nil,
							["p"] = nil,
							["age"] = 0,
							["oid"] = v_u_851.oid,
							["id"] = v_u_831,
							["n"] = v_u_832,
							["p"] = v_u_844
						}
						table.insert(v852, v853)
						local v854 = v_u_70
						local v865 = {
							["at"] = 1760000000 + (v_u_61.clock() - v_u_65) + 6,
							["fn"] = function() -- name: fn
								-- upvalues: (ref) v_u_86, (copy) v_u_851, (ref) v_u_268, (ref) v_u_266, (copy) v_u_831, (copy) v_u_832, (ref) v_u_833, (ref) v_u_258, (copy) v_u_844, (ref) v_u_63, (ref) v_u_60, (ref) v_u_59
								for v855, v856 in v_u_86.tx do
									if v856.oid ~= v_u_851.oid then
										continue
									end
									table.remove(v_u_86.tx, v855)
								end
								v_u_851.shown = true
								local v857 = v_u_268
								local v858 = v_u_851
								table.insert(v857, v858)
								v_u_266("o", v_u_831, v_u_832, v_u_833, v_u_851.oid)
								local v859 = v_u_258
								local v860 = "ordered"
								local v861 = {
									["id"] = v_u_831,
									["n"] = v_u_832,
									["u"] = v_u_833,
									["p"] = v_u_844
								}
								local v862 = {
									["n"] = v_u_832
								}
								local v863 = v_u_831
								local v864 = v_u_63.get(v863)
								if v864 then
									v863 = v864.name or v863
								end
								v862.name = v863
								v862.u = v_u_833
								v862.p = v_u_844
								v861.msg = v_u_60.bookNote(v_u_59.rules, "ordered", v862)
								v859(v860, v861)
							end
						}
						table.insert(v854, v865)
						return {
							["op"] = "bmOrder",
							["ok"] = true,
							["msg"] = nil,
							["data"] = nil,
							["msg"] = v_u_60.TEXT.working,
							["data"] = {
								["code"] = "WORKING",
								["state"] = "processing",
								["oid"] = nil,
								["oid"] = v_u_851.oid
							}
						}
					end
					local v866 = v_u_268
					table.insert(v866, v_u_851)
					v_u_266("o", v_u_831, v_u_832, v_u_833, v_u_851.oid)
					local v867 = {
						["n"] = v_u_832
					}
					local v868 = v_u_63.get(v_u_831)
					if v868 then
						v_u_831 = v868.name or v_u_831
					end
					v867.name = v_u_831
					v867.u = v_u_833
					v867.p = v_u_844
					return {
						["op"] = "bmOrder",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = v_u_60.bookNote(v_u_59.rules, "ordered", v867),
						["data"] = {
							["state"] = "placed",
							["oid"] = nil,
							["rem"] = nil,
							["oid"] = v_u_851.oid,
							["rem"] = v_u_832
						}
					}
				end
			end
		end
		return {
			["op"] = "bmOrder",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
			["data"] = {
				["code"] = "BAD"
			}
		}
	end
	local function v_u_881(p870) -- name: opOrderCancel
		-- upvalues: (copy) v_u_81, (copy) v_u_60, (copy) v_u_59, (ref) v_u_268, (copy) v_u_607, (copy) v_u_63, (copy) v_u_61, (copy) v_u_266
		if v_u_81.sw.freeze then
			return {
				["op"] = "bmOrderCancel",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "FREEZE", nil),
				["data"] = {
					["code"] = "FREEZE"
				}
			}
		end
		if v_u_81.ds == "down" then
			return {
				["op"] = "bmOrderCancel",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "STORE", nil),
				["data"] = {
					["code"] = "STORE"
				}
			}
		end
		local v871 = p870.oid
		if type(v871) ~= "string" or #p870.oid ~= 17 then
			return {
				["op"] = "bmOrderCancel",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		for _, v872 in v_u_268 do
			if v872.oid ~= p870.oid then
				continue
			end
			if v872.st == 2 then
				return v_u_607("bmOrderCancel", "FILLED", {
					["oid"] = v872.oid
				})
			end
			if v872.st == 3 then
				local v873 = {
					["name"] = nil,
					["p"] = 0
				}
				local v874 = v872.id
				local v875 = v_u_63.get(v874)
				if v875 then
					v874 = v875.name or v874
				end
				v873.name = v874
				return {
					["op"] = "bmOrderCancel",
					["ok"] = true,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v_u_60.bookNote(v_u_59.rules, "orderEnded", v873),
					["data"] = {
						["state"] = "returned",
						["oid"] = nil,
						["oid"] = v872.oid
					}
				}
			end
			local v876 = v872.rem * v872.u
			v872.st = 3
			v872.rt = 1
			local v877 = v_u_61
			v877.cashAdj = v877.cashAdj + v876
			v_u_266("n", v872.id, v872.q, v872.u, v872.oid)
			local v878 = {}
			local v879 = v872.id
			local v880 = v_u_63.get(v879)
			if v880 then
				v879 = v880.name or v879
			end
			v878.name = v879
			v878.p = v876
			return {
				["op"] = "bmOrderCancel",
				["ok"] = true,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.bookNote(v_u_59.rules, "orderEnded", v878),
				["data"] = {
					["state"] = "returned",
					["oid"] = nil,
					["back"] = nil,
					["oid"] = v872.oid,
					["back"] = v876
				}
			}
		end
		return {
			["op"] = "bmOrderCancel",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
			["data"] = {
				["code"] = "BAD"
			}
		}
	end
	local function v_u_928(p882) -- name: opSellNow
		-- upvalues: (copy) v_u_828, (copy) v_u_60, (copy) v_u_59, (copy) v_u_61, (copy) v_u_164, (copy) v_u_62, (copy) v_u_81, (copy) v_u_301, (ref) v_u_267, (ref) v_u_87, (copy) v_u_266, (ref) v_u_269, (copy) v_u_63, (copy) v_u_258
		local v883 = v_u_828("bmSellNow")
		if v883 then
			return v883
		end
		local v884 = p882.uid
		if type(v884) ~= "string" then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v885 = p882.n
		if type(v885) ~= "number" then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		local v886 = p882.n
		local v887 = p882.n
		if v886 ~= math.floor(v887) or p882.n < 1 then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
				["data"] = {
					["code"] = "BAD"
				}
			}
		end
		if p882.minPrice ~= nil then
			local v888 = p882.minPrice
			if type(v888) ~= "number" then
				return {
					["op"] = "bmSellNow",
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
					["data"] = {
						["code"] = "BAD"
					}
				}
			end
			local v889 = p882.minPrice
			local v890 = p882.minPrice
			if v889 ~= math.floor(v890) or p882.minPrice < 1 then
				return {
					["op"] = "bmSellNow",
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
					["data"] = {
						["code"] = "BAD"
					}
				}
			end
		end
		local v891 = p882.uid
		for _, v893 in v_u_61:stash() or {} do
			if v893.uid ~= v891 then
				continue
			end
		end
		local v893 = nil
		if not v893 then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "NOT_STASH", nil),
				["data"] = {
					["code"] = "NOT_STASH"
				}
			}
		end
		local v894 = v_u_164(v893.id, false)
		if v894 then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, v894, nil),
				["data"] = {
					["code"] = v894
				}
			}
		end
		if p882.n > (v893.n or 1) then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "QTY", nil),
				["data"] = {
					["code"] = "QTY"
				}
			}
		end
		local v895, v896 = v_u_62.checkInst(v893, {
			["restricted"] = nil,
			["insured"] = false,
			["topLevel"] = true,
			["crates"] = true,
			["resolved"] = true,
			["tradeFailed"] = false,
			["restricted"] = v_u_81.restricted
		})
		if not v895 and (v896 ~= "STRIP_FIRST" or p882.strip ~= true) then
			local v897 = v896 or "BAD"
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, v897, nil),
				["data"] = {
					["code"] = v897
				}
			}
		end
		local v898 = v893.dur
		if type(v898) == "number" and v893.dur < 0.7 then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "COND", nil),
				["data"] = {
					["code"] = "COND"
				}
			}
		end
		local v899 = {}
		for _, v900 in v_u_301(v893.id) do
			if v900.own or p882.minPrice ~= nil and v900.u < p882.minPrice then
				continue
			end
			table.insert(v899, v900)
		end
		if v_u_81.book == "empty" or (v_u_81.book == "bidsbusy" or #v899 == 0) then
			return {
				["op"] = "bmSellNow",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "NO_BIDS", nil),
				["data"] = {
					["code"] = "NO_BIDS"
				}
			}
		end
		if v_u_81.sellMode == "pending" then
			return {
				["op"] = "bmSellNow",
				["ok"] = true,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v_u_60.text(v_u_59.rules, "PENDING"),
				["data"] = {
					["code"] = "PENDING",
					["state"] = "processing"
				}
			}
		end
		local v901 = p882.n
		local v902 = 0
		local v903 = 0
		local v904 = 0
		local v905 = 0
		for _, v906 in v899 do
			if v901 <= 0 or v902 >= 3 then
				break
			end
			local v907 = v906.q
			local v908 = math.min(v901, v907)
			local v909 = v908 * v906.u
			local v910
			if v909 >= 2 then
				local v911 = v909 * 5 / 100
				local v912 = math.floor(v911)
				v910 = math.max(1, v912)
			else
				v910 = 0
			end
			v903 = v903 + v908
			v904 = v904 + v909
			v905 = v905 + (v909 - v910)
			v901 = v901 - v908
			v902 = v902 + 1
			local v913 = v_u_267[v893.id] or {}
			for v914 = #v913, 1, -1 do
				if v913[v914].u ~= v906.u then
					continue
				end
				local v915 = v913[v914]
				v915.q = v915.q - v908
				if v913[v914].q > 0 then
					continue
				end
				table.remove(v913, v914)
			end
		end
		local v916 = v_u_61
		v916.cashAdj = v916.cashAdj + v905
		if (v893.n or 1) <= v903 then
			v_u_87[v893.uid] = true
		else
			v893.n = (v893.n or 1) - v903
		end
		local v917 = v899[1]
		local v918 = v_u_266
		local v919 = v893.id
		local v920 = v917.u
		v_u_269 = v_u_269 + 1
		local v921 = ("o%016x"):format(v_u_269 + 2953576448)
		v918("f", v919, v903, v920, "f" .. string.sub(v921, 2))
		local v922 = v903 < p882.n
		local v923 = v922 and "hitBidPart" or "hitBid"
		local v924 = {
			["n"] = p882.n,
			["taken"] = v903
		}
		local v925 = v893.id
		local v926 = v_u_63.get(v925)
		if v926 then
			v925 = v926.name or v925
		end
		v924.name = v925
		v924.u = v917.u
		v924.net = v905
		local v927 = v_u_60.bookNote(v_u_59.rules, v923, v924)
		v_u_258(v922 and "hitBidPart" or "hitBid", {
			["id"] = v893.id,
			["n"] = v903,
			["u"] = v917.u,
			["net"] = v905,
			["msg"] = v927
		})
		return {
			["op"] = "bmSellNow",
			["ok"] = true,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v927,
			["data"] = {
				["state"] = "sold",
				["sold"] = nil,
				["requested"] = nil,
				["net"] = nil,
				["gross"] = nil,
				["pending"] = 0,
				["sold"] = v903,
				["requested"] = p882.n,
				["net"] = v905,
				["gross"] = v904
			}
		}
	end
	local function v_u_939(p929, p930) -- name: rsDeny
		-- upvalues: (copy) v_u_58
		local v_u_931 = nil
		local function v932()
			-- upvalues: (ref) v_u_931, (ref) v_u_58
			v_u_931 = v_u_58.cctx.shared.BmRs
		end
		pcall(v932)
		local v933 = v_u_931
		local v934
		if type(v933) == "table" then
			local v935 = v_u_931.viewPlan
			if type(v935) == "function" then
				v934 = v_u_931
			else
				v934 = nil
			end
		else
			v934 = nil
		end
		local v936 = {
			["code"] = p929
		}
		if p930 then
			for v937, v938 in p930 do
				v936[v937] = v938
			end
		end
		if v934 ~= nil then
			p929 = v934.text(p929, p930)
		end
		return {
			["op"] = "bmRsBuy",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = p929,
			["data"] = v936
		}
	end
	local function v_u_1024(p940) -- name: opRsBuy
		-- upvalues: (copy) v_u_58, (ref) v_u_80, (copy) v_u_61, (copy) v_u_939, (copy) v_u_65, (copy) v_u_81, (copy) v_u_397, (copy) p_u_57, (copy) v_u_63
		local v_u_941 = nil
		local function v942()
			-- upvalues: (ref) v_u_941, (ref) v_u_58
			v_u_941 = v_u_58.cctx.shared.BmRs
		end
		pcall(v942)
		local v943 = v_u_941
		local v_u_944
		if type(v943) == "table" then
			local v945 = v_u_941.viewPlan
			if type(v945) == "function" then
				v_u_944 = v_u_941
			else
				v_u_944 = nil
			end
		else
			v_u_944 = nil
		end
		if v_u_944 == nil or v_u_80 == nil then
			local v_u_946 = nil
			local function v947()
				-- upvalues: (ref) v_u_946, (ref) v_u_58
				v_u_946 = v_u_58.cctx.shared.BmRs
			end
			pcall(v947)
			local v948 = v_u_946
			local v949
			if type(v948) == "table" then
				local v950 = v_u_946.viewPlan
				if type(v950) == "function" then
					v949 = v_u_946
				else
					v949 = nil
				end
			else
				v949 = nil
			end
			return {
				["op"] = "bmRsBuy",
				["ok"] = false,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v949 == nil and "OVER" or v949.text("OVER", nil),
				["data"] = {
					["code"] = "OVER"
				}
			}
		end
		if type(p940) == "table" then
			local v951 = p940.i
			if type(v951) == "number" then
				local v952 = p940.n
				if type(v952) == "number" then
					local v953 = p940.u
					if type(v953) == "number" then
						local v954 = p940.n
						local v955 = p940.n
						if v954 == math.floor(v955) and p940.n >= 1 then
							local v956 = p940.u
							local v957 = p940.u
							if v956 == math.floor(v957) then
								if p940.r ~= v_u_80.plan.r then
									local v_u_958 = nil
									local function v959()
										-- upvalues: (ref) v_u_958, (ref) v_u_58
										v_u_958 = v_u_58.cctx.shared.BmRs
									end
									pcall(v959)
									local v960 = v_u_958
									local v961
									if type(v960) == "table" then
										local v962 = v_u_958.viewPlan
										if type(v962) == "function" then
											v961 = v_u_958
										else
											v961 = nil
										end
									else
										v961 = nil
									end
									return {
										["op"] = "bmRsBuy",
										["ok"] = false,
										["msg"] = nil,
										["data"] = nil,
										["msg"] = v961 == nil and "OVER" or v961.text("OVER", nil),
										["data"] = {
											["code"] = "OVER"
										}
									}
								end
								local v_u_963 = v_u_80.plan
								local v_u_964 = v_u_963.ix[p940.i]
								if v_u_964 == nil then
									local v_u_965 = nil
									local function v966()
										-- upvalues: (ref) v_u_965, (ref) v_u_58
										v_u_965 = v_u_58.cctx.shared.BmRs
									end
									pcall(v966)
									local v967 = v_u_965
									local v968
									if type(v967) == "table" then
										local v969 = v_u_965.viewPlan
										if type(v969) == "function" then
											v968 = v_u_965
										else
											v968 = nil
										end
									else
										v968 = nil
									end
									return {
										["op"] = "bmRsBuy",
										["ok"] = false,
										["msg"] = nil,
										["data"] = nil,
										["msg"] = v968 == nil and "GONE" or v968.text("GONE", nil),
										["data"] = {
											["code"] = "GONE"
										}
									}
								end
								local function v978() -- name: gates
									-- upvalues: (ref) v_u_80, (copy) v_u_944, (copy) v_u_963, (copy) v_u_964, (ref) v_u_61
									if v_u_80.on then
										local v970 = v_u_944.canSell
										local v971 = v_u_963
										local v972 = v_u_964
										local v973 = v_u_61.now()
										local v974 = {
											["flag"] = true,
											["rsOn"] = nil,
											["planAge"] = 3,
											["viewer"] = nil,
											["rsOn"] = v_u_80.on,
											["viewer"] = {
												["tutorialDone"] = true,
												["finishedRaids"] = nil,
												["accountAge"] = 400,
												["hushAge"] = 30,
												["extracts"] = 5,
												["scopeOk"] = true,
												["mailFull"] = nil,
												["stashFull"] = false,
												["finishedRaids"] = v_u_80.raids,
												["mailFull"] = v_u_80.mailFull
											}
										}
										local v975, v976, v977 = v970(v971, v972, v973, v974)
										if v975 then
											if v_u_80.mailFull then
												return false, "MAIL_FULL", {
													["max"] = v_u_944.RS.rsMailMax
												}
											else
												return true, v976, nil
											end
										else
											return false, v976, v977
										end
									else
										return false, "OFF_RS", nil
									end
								end
								local v979, v980, v981 = v978()
								if not v979 then
									return v_u_939(v980, v981)
								end
								if v980 == "draw" then
									local v982 = v_u_944.rowOpen(v_u_963, v_u_964) + v_u_963.wd - (1760000000 + (v_u_61.clock() - v_u_65))
									local v983 = math.max(0, v982)
									if v_u_81.latency > 0 then
										task.wait((math.min(v983, 6)))
									else
										v_u_61:advance(v983 + 0.01)
									end
									local v984, v985, v986 = v978()
									local v987 = v985
									if not v984 then
										return v_u_939(v987, v986)
									end
								end
								if v_u_80.refuse ~= nil then
									local v988 = v_u_80.refuse
									v_u_80.refuse = nil
									return v_u_939(v988.code, v988.extra)
								end
								if p940.u ~= v_u_964.u then
									return v_u_939("PRICE", {
										["price"] = v_u_964.u
									})
								end
								local v989, v990, v991 = v_u_944.checkQty(v_u_963, v_u_964, v_u_80.rec[v_u_964.id], v_u_61.now(), p940.n)
								if not v989 then
									return v_u_939(v990, v991)
								end
								local v992 = v_u_397(p940.i)
								if v992.st == "out" then
									local v_u_993 = nil
									local function v994()
										-- upvalues: (ref) v_u_993, (ref) v_u_58
										v_u_993 = v_u_58.cctx.shared.BmRs
									end
									pcall(v994)
									local v995 = v_u_993
									local v996
									if type(v995) == "table" then
										local v997 = v_u_993.viewPlan
										if type(v997) == "function" then
											v996 = v_u_993
										else
											v996 = nil
										end
									else
										v996 = nil
									end
									return {
										["op"] = "bmRsBuy",
										["ok"] = false,
										["msg"] = nil,
										["data"] = nil,
										["msg"] = v996 == nil and "SOLD_OUT" or v996.text("SOLD_OUT", nil),
										["data"] = {
											["code"] = "SOLD_OUT"
										}
									}
								end
								if v992.st == "held" then
									return v_u_939("HELD", {
										["retryIn"] = v992.retryIn
									})
								end
								local v998 = v_u_80.stock[p940.i] or 0
								if v998 < p940.n then
									if v_u_964.q1 <= v998 then
										return v_u_939("LESS_LEFT", {
											["avail"] = v998
										})
									end
									local v_u_999 = nil
									local function v1000()
										-- upvalues: (ref) v_u_999, (ref) v_u_58
										v_u_999 = v_u_58.cctx.shared.BmRs
									end
									pcall(v1000)
									local v1001 = v_u_999
									local v1002
									if type(v1001) == "table" then
										local v1003 = v_u_999.viewPlan
										if type(v1003) == "function" then
											v1002 = v_u_999
										else
											v1002 = nil
										end
									else
										v1002 = nil
									end
									return {
										["op"] = "bmRsBuy",
										["ok"] = false,
										["msg"] = nil,
										["data"] = nil,
										["msg"] = v1002 == nil and "SOLD_OUT" or v1002.text("SOLD_OUT", nil),
										["data"] = {
											["code"] = "SOLD_OUT"
										}
									}
								end
								local v1004 = v_u_964.u * p940.n
								local v1005 = (p_u_57.getCash() or 0) + v_u_61.cashAdj
								if v1005 < v1004 then
									return v_u_939("CASH", {
										["need"] = v1004 - v1005
									})
								end
								local v1006 = v_u_61
								v1006.cashAdj = v1006.cashAdj - v1004
								v_u_80.stock[p940.i] = v998 - p940.n
								local v1007 = v_u_944.capWindow(v_u_963, v_u_964, v_u_61.now())
								local v1008 = v_u_80.rec[v_u_964.id]
								local v1009 = (type(v1008) ~= "table" or (v1008.f ~= v_u_964.w or v1008.w ~= v1007)) and {
									["f"] = nil,
									["w"] = nil,
									["n"] = 0,
									["a"] = nil,
									["f"] = v_u_964.w,
									["w"] = v1007,
									["a"] = v_u_61.now()
								} or v1008
								v1009.n = v1009.n + p940.n
								v_u_80.rec[v_u_964.id] = v1009
								local v1010, v1011 = v_u_944.capLeft(v_u_963, v_u_964, v1009, v_u_61.now())
								local v1012 = v_u_63.get(v_u_964.id)
								local v1013 = v_u_944.text
								local v1014 = "BOUGHT"
								local v1015 = {
									["n"] = p940.n
								}
								local v1016
								if v1012 then
									v1016 = v1012.name
								else
									v1016 = v_u_964.id
								end
								v1015.name = v1016
								v1015.p = v1004
								local v1017 = v1013(v1014, v1015)
								local v1018 = {
									["code"] = "OK",
									["n"] = nil,
									["p"] = nil,
									["left"] = nil,
									["reset"] = nil,
									["n"] = p940.n,
									["p"] = v1004
								}
								if v1010 == (1 / 0) then
									v1010 = nil
								end
								v1018.left = v1010
								v1018.reset = v1011
								if v_u_80.saving then
									v1017 = v1017 .. " " .. v_u_944.TEXT.SAVING
									v1018.saving = true
								end
								return {
									["op"] = "bmRsBuy",
									["ok"] = true,
									["msg"] = nil,
									["data"] = nil,
									["msg"] = v1017,
									["data"] = v1018
								}
							end
						end
					end
				end
			end
		end
		local v_u_1019 = nil
		local function v1020()
			-- upvalues: (ref) v_u_1019, (ref) v_u_58
			v_u_1019 = v_u_58.cctx.shared.BmRs
		end
		pcall(v1020)
		local v1021 = v_u_1019
		local v1022
		if type(v1021) == "table" then
			local v1023 = v_u_1019.viewPlan
			if type(v1023) == "function" then
				v1022 = v_u_1019
			else
				v1022 = nil
			end
		else
			v1022 = nil
		end
		return {
			["op"] = "bmRsBuy",
			["ok"] = false,
			["msg"] = nil,
			["data"] = nil,
			["msg"] = v1022 == nil and "BAD" or v1022.text("BAD", nil),
			["data"] = {
				["code"] = "BAD"
			}
		}
	end
	function v_u_61.op(_, p1025, p1026) -- name: op
		-- upvalues: (copy) v_u_81, (copy) v_u_78, (copy) v_u_61, (ref) v_u_67, (copy) v_u_655, (copy) v_u_804, (copy) v_u_756, (copy) v_u_815, (copy) v_u_826, (copy) v_u_869, (copy) v_u_881, (copy) v_u_928, (copy) v_u_1024, (copy) v_u_60, (copy) v_u_59
		if v_u_81.latency > 0 then
			task.wait(v_u_81.latency)
		end
		v_u_78()
		v_u_61.lastOp = {
			["name"] = p1025,
			["t"] = p1026
		}
		if v_u_67 and not v_u_81.fail then
			if p1025 == "bmList" then
				return v_u_655(p1026)
			elseif p1025 == "bmBuy" then
				return v_u_804(p1026)
			elseif p1025 == "bmBuyBest" then
				return v_u_756(p1026)
			elseif p1025 == "bmCancel" then
				return v_u_815(p1026)
			elseif p1025 == "bmClaim" then
				return v_u_826(p1026)
			elseif p1025 == "bmOrder" then
				return v_u_869(p1026)
			elseif p1025 == "bmOrderCancel" then
				return v_u_881(p1026)
			elseif p1025 == "bmSellNow" then
				return v_u_928(p1026)
			else
				return p1025 ~= "bmRsBuy" and {
					["op"] = nil,
					["ok"] = false,
					["msg"] = nil,
					["data"] = nil,
					["op"] = p1025,
					["msg"] = v_u_60.text(v_u_59.rules, "BAD", nil),
					["data"] = {
						["code"] = "BAD"
					}
				} or v_u_1024(p1026)
			end
		else
			return nil
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_67, (ref) v_u_86
		while v_u_67 do
			task.wait(1)
			for _, v1027 in v_u_86.tx do
				v1027.age = (v1027.age or 0) + 1
			end
		end
	end)
	function v_u_61.destroy(_) -- name: destroy
		-- upvalues: (ref) v_u_67, (copy) v_u_81
		v_u_67 = false
		v_u_81.hold = false
	end
	return v_u_61
end
return v_u_3