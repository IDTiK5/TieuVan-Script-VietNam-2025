-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmHuntSw

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.lines(p6) -- name: lines
	local v7 = {}
	if type(p6) ~= "table" then
		table.insert(v7, {
			["name"] = "State",
			["text"] = "Reading the switches ...",
			["kind"] = "muted"
		})
		return v7
	end
	local v8 = p6.soon == true
	local v9 = {
		["name"] = "Soon",
		["text"] = nil,
		["kind"] = nil
	}
	local v10 = p6.soonLive
	v9.text = ("Hunt tile: %s%s"):format(v8 and "SOON, nobody can queue" or "OPEN", type(v10) == "boolean" and "  \194\183  set by the switch" or "  \194\183  from the build constant")
	v9.kind = v8 and "warn" or "ok"
	table.insert(v7, v9)
	local v11 = {
		["name"] = "Queue",
		["text"] = nil,
		["kind"] = "text"
	}
	local v12 = p6.regions == true and "PER REGION (six queues)" or "ONE WORLD QUEUE"
	local v13 = p6.regionsLive
	v11.text = ("Hunt queue: %s%s"):format(v12, type(v13) == "boolean" and "  \194\183  set by the switch" or "  \194\183  default")
	table.insert(v7, v11)
	local v14 = p6.raidMin
	local v15 = type(v14) ~= "number" and 60 or p6.raidMin
	local v16 = {
		["name"] = "RaidTime",
		["text"] = nil,
		["kind"] = nil
	}
	local v17 = v15 == 0 and "OFF, no lock" or tostring(v15) .. " MIN of raids needed"
	local v18 = p6.raidMinLive
	v16.text = ("Hunt raid time: %s%s"):format(v17, type(v18) == "number" and "  \194\183  set by the switch" or "  \194\183  default")
	v16.kind = v15 == 0 and "warn" or "text"
	table.insert(v7, v16)
	local v19 = p6.accDays
	local v20 = type(v19) ~= "number" and 30 or p6.accDays
	local v21 = {
		["name"] = "AccountAge",
		["text"] = nil,
		["kind"] = nil
	}
	local v22 = v20 == 0 and "OFF, no lock" or tostring(v20) .. " DAYS old needed"
	local v23 = p6.accDaysLive
	v21.text = ("Hunt account age: %s%s"):format(v22, type(v23) == "number" and "  \194\183  set by the switch" or "  \194\183  default")
	v21.kind = v20 == 0 and "warn" or "text"
	table.insert(v7, v21)
	if p6.good ~= true and not p6.studio then
		table.insert(v7, {
			["name"] = "Good",
			["text"] = "This server has no good read of the switches yet: it follows the build defaults until it reads them.",
			["kind"] = "warn"
		})
	end
	local v24 = p6.byName
	local v25 = (type(v24) ~= "string" or p6.byName == "") and "" or " by " .. p6.byName
	local v26 = {
		["name"] = "Version",
		["text"] = nil,
		["kind"] = "muted"
	}
	local v27 = p6.v
	v26.text = ("Version %d%s"):format(tonumber(v27) or 0, v25)
	table.insert(v7, v26)
	return v7
end
function v_u_4.mount(p_u_28, p_u_29, p30, p31) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_32 = type(p31) ~= "table" and {} or p31
	if type(p30) == "table" then
		local v33 = p30.color
		if type(v33) ~= "table" then
			p30 = v_u_3.Theme
		end
	else
		p30 = v_u_3.Theme
	end
	local v_u_34 = p30.color
	local v35 = v_u_32.inner
	local v36 = type(v35) ~= "number" and 438 or v_u_32.inner
	local v_u_37 = v_u_32.gui
	local v_u_38 = 0
	local v_u_39 = true
	if v_u_37 then
		v_u_37.Destroying:Connect(function()
			-- upvalues: (ref) v_u_39
			v_u_39 = false
		end)
	end
	local v40 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Hollow Hunt  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_28,
		["color"] = v_u_34.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v41 = v_u_32.order
	local v42
	if type(v41) == "function" then
		v42 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v42 = v_u_38
	end
	v40.LayoutOrder = v42
	local v_u_43 = v_u_3.new("Frame", {
		["Name"] = "HuntSwList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_28)
	v_u_3.layout(v_u_43, "v", 2)
	local v44 = v_u_32.order
	local v45
	if type(v44) == "function" then
		v45 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v45 = v_u_38
	end
	v_u_43.LayoutOrder = v45
	local function v52(p46, p47, p48) -- name: small
		-- upvalues: (ref) v_u_3, (copy) p_u_28, (copy) v_u_34, (copy) v_u_32, (ref) v_u_38
		local v49 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_28,
			["name"] = p46,
			["text"] = p47,
			["color"] = p48 or v_u_34.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v50 = v_u_32.order
		local v51
		if type(v50) == "function" then
			v51 = v_u_32.order()
		else
			v_u_38 = v_u_38 + 1
			v51 = v_u_38
		end
		v49.LayoutOrder = v51
		return v49
	end
	local v_u_53 = nil
	local v_u_54 = false
	local v_u_55 = (-1 / 0)
	local v_u_56 = nil
	local v_u_57 = nil
	local function v71() -- name: refresh
		-- upvalues: (ref) v_u_54, (copy) p_u_29, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_57, (copy) v_u_32
		local v58 = {
			["cmd"] = "status"
		}
		if not v_u_54 then
			local v59 = p_u_29
			if type(v59) ~= "function" then
				return
			end
			v_u_54 = true
			local v_u_60 = true
			local function v68(p61) -- name: done
				-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_60, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
				v_u_54 = false
				if v_u_39 then
					v_u_55 = os.clock()
					if type(p61) == "table" then
						local v62 = p61.data
						if type(v62) == "table" then
							v_u_53 = p61.data
						end
						if not v_u_60 then
							local v63 = p61.msg or (p61.ok and "Done." or "Refused.")
							local v64 = tostring(v63)
							local v65 = p61.ok ~= true
							v_u_3.setText(v_u_56, v64)
							local v66 = v_u_56
							local v67
							if v65 then
								v67 = v_u_34.danger
							else
								v67 = v_u_34.text2
							end
							v66.TextColor3 = v67
						end
					elseif not v_u_60 then
						v_u_3.setText(v_u_56, "The server did not answer.")
						v_u_56.TextColor3 = v_u_34.danger
					end
					v_u_57(v_u_53)
				end
			end
			local v69 = v_u_32.sendQuiet
			local v70
			if type(v69) == "function" then
				v70 = v_u_32.sendQuiet
			else
				v70 = p_u_29
			end
			v70("server.hunt", v58, v68)
		end
	end
	local v83 = {
		["parent"] = nil,
		["name"] = "HuntSwSoon",
		["label"] = "Hunt SOON (tile shows SOON, no queue)",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = p_u_28,
		["width"] = v36,
		["onChange"] = function(p72) -- name: onChange
			-- upvalues: (ref) v_u_54, (copy) p_u_29, (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_57
			local v73 = {
				["cmd"] = "set",
				["soon"] = nil,
				["soon"] = p72
			}
			if not v_u_54 then
				local v74 = p_u_29
				if type(v74) ~= "function" then
					return
				end
				v_u_54 = true
				v_u_3.setText(v_u_56, "Working ...")
				v_u_56.TextColor3 = v_u_34.text2
				local v_u_75 = nil
				p_u_29("server.hunt", v73, function(p76) -- name: done
					-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_75, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
					v_u_54 = false
					if v_u_39 then
						v_u_55 = os.clock()
						if type(p76) == "table" then
							local v77 = p76.data
							if type(v77) == "table" then
								v_u_53 = p76.data
							end
							if not v_u_75 then
								local v78 = p76.msg or (p76.ok and "Done." or "Refused.")
								local v79 = tostring(v78)
								local v80 = p76.ok ~= true
								v_u_3.setText(v_u_56, v79)
								local v81 = v_u_56
								local v82
								if v80 then
									v82 = v_u_34.danger
								else
									v82 = v_u_34.text2
								end
								v81.TextColor3 = v82
							end
						elseif not v_u_75 then
							v_u_3.setText(v_u_56, "The server did not answer.")
							v_u_56.TextColor3 = v_u_34.danger
						end
						v_u_57(v_u_53)
					end
				end)
			end
		end
	}
	local v84, v85 = v_u_3.toggle(v83)
	local v86 = v_u_32.order
	local v87
	if type(v86) == "function" then
		v87 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v87 = v_u_38
	end
	v84.LayoutOrder = v87
	local v_u_88 = v85
	local v100 = {
		["parent"] = nil,
		["name"] = "HuntSwRegions",
		["label"] = "Hunt queue per region only",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = p_u_28,
		["width"] = v36,
		["onChange"] = function(p89) -- name: onChange
			-- upvalues: (ref) v_u_54, (copy) p_u_29, (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_57
			local v90 = {
				["cmd"] = "set",
				["regions"] = nil,
				["regions"] = p89
			}
			if not v_u_54 then
				local v91 = p_u_29
				if type(v91) ~= "function" then
					return
				end
				v_u_54 = true
				v_u_3.setText(v_u_56, "Working ...")
				v_u_56.TextColor3 = v_u_34.text2
				local v_u_92 = nil
				p_u_29("server.hunt", v90, function(p93) -- name: done
					-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_92, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
					v_u_54 = false
					if v_u_39 then
						v_u_55 = os.clock()
						if type(p93) == "table" then
							local v94 = p93.data
							if type(v94) == "table" then
								v_u_53 = p93.data
							end
							if not v_u_92 then
								local v95 = p93.msg or (p93.ok and "Done." or "Refused.")
								local v96 = tostring(v95)
								local v97 = p93.ok ~= true
								v_u_3.setText(v_u_56, v96)
								local v98 = v_u_56
								local v99
								if v97 then
									v99 = v_u_34.danger
								else
									v99 = v_u_34.text2
								end
								v98.TextColor3 = v99
							end
						elseif not v_u_92 then
							v_u_3.setText(v_u_56, "The server did not answer.")
							v_u_56.TextColor3 = v_u_34.danger
						end
						v_u_57(v_u_53)
					end
				end)
			end
		end
	}
	local v101, v102 = v_u_3.toggle(v100)
	local v103 = v_u_32.order
	local v104
	if type(v103) == "function" then
		v104 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v104 = v_u_38
	end
	v101.LayoutOrder = v104
	local v_u_105 = v102
	local function v_u_118(p106) -- name: setRaid
		-- upvalues: (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_54, (copy) p_u_29, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_57
		local v107 = tonumber(p106)
		if v107 == nil or (v107 ~= math.floor(v107) or (v107 < 0 or v107 > 1440)) then
			v_u_3.setText(v_u_56, "Raid minutes must be a whole number from 0 to 1440 (0 = no lock).")
			v_u_56.TextColor3 = v_u_34.danger
		else
			local v108 = {
				["cmd"] = "set",
				["raidMin"] = nil,
				["raidMin"] = v107
			}
			if not v_u_54 then
				local v109 = p_u_29
				if type(v109) ~= "function" then
					return
				end
				v_u_54 = true
				v_u_3.setText(v_u_56, "Working ...")
				v_u_56.TextColor3 = v_u_34.text2
				local v_u_110 = nil
				p_u_29("server.hunt", v108, function(p111) -- name: done
					-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_110, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
					v_u_54 = false
					if v_u_39 then
						v_u_55 = os.clock()
						if type(p111) == "table" then
							local v112 = p111.data
							if type(v112) == "table" then
								v_u_53 = p111.data
							end
							if not v_u_110 then
								local v113 = p111.msg or (p111.ok and "Done." or "Refused.")
								local v114 = tostring(v113)
								local v115 = p111.ok ~= true
								v_u_3.setText(v_u_56, v114)
								local v116 = v_u_56
								local v117
								if v115 then
									v117 = v_u_34.danger
								else
									v117 = v_u_34.text2
								end
								v116.TextColor3 = v117
							end
						elseif not v_u_110 then
							v_u_3.setText(v_u_56, "The server did not answer.")
							v_u_56.TextColor3 = v_u_34.danger
						end
						v_u_57(v_u_53)
					end
				end)
			end
		end
	end
	local v119 = v_u_3.label({
		["parent"] = nil,
		["name"] = "HuntSwRaidCaption",
		["text"] = "Raid minutes needed for the hunt (0 = no lock)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_28,
		["color"] = v_u_34.text2,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v120 = v_u_32.order
	local v121
	if type(v120) == "function" then
		v121 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v121 = v_u_38
	end
	v119.LayoutOrder = v121
	local v122 = v_u_3.new("Frame", {
		["Name"] = "HuntSwRaidRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 38)
	}, p_u_28)
	v_u_3.layout(v122, "h", 6)
	local v123 = v_u_32.order
	local v124
	if type(v123) == "function" then
		v124 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v124 = v_u_38
	end
	v122.LayoutOrder = v124
	local v125, v_u_126 = v_u_3.input({
		["parent"] = nil,
		["name"] = "HuntSwRaidInput",
		["placeholder"] = "60",
		["width"] = 120,
		["text"] = "",
		["parent"] = v122
	})
	v125.LayoutOrder = 1
	local v_u_127 = v_u_126
	v_u_126.FocusLost:Connect(function(p128)
		-- upvalues: (copy) v_u_118, (copy) v_u_126
		if p128 then
			v_u_118(v_u_126.Text)
		end
	end)
	local v129 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Set",
		["kind"] = "secondary",
		["height"] = 34,
		["width"] = 90,
		["maxTextWidth"] = 78,
		["onClick"] = nil,
		["parent"] = v122,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_118, (copy) v_u_126
			v_u_118(v_u_126.Text)
		end
	})
	v129.Name = "HuntSwRaidSet"
	v129.LayoutOrder = 2
	local function v_u_142(p130) -- name: setAcc
		-- upvalues: (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_54, (copy) p_u_29, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_57
		local v131 = tonumber(p130)
		if v131 == nil or (v131 ~= math.floor(v131) or (v131 < 0 or v131 > 3650)) then
			v_u_3.setText(v_u_56, "Account age days must be a whole number from 0 to 3650 (0 = no lock).")
			v_u_56.TextColor3 = v_u_34.danger
		else
			local v132 = {
				["cmd"] = "set",
				["accDays"] = nil,
				["accDays"] = v131
			}
			if not v_u_54 then
				local v133 = p_u_29
				if type(v133) ~= "function" then
					return
				end
				v_u_54 = true
				v_u_3.setText(v_u_56, "Working ...")
				v_u_56.TextColor3 = v_u_34.text2
				local v_u_134 = nil
				p_u_29("server.hunt", v132, function(p135) -- name: done
					-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_134, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
					v_u_54 = false
					if v_u_39 then
						v_u_55 = os.clock()
						if type(p135) == "table" then
							local v136 = p135.data
							if type(v136) == "table" then
								v_u_53 = p135.data
							end
							if not v_u_134 then
								local v137 = p135.msg or (p135.ok and "Done." or "Refused.")
								local v138 = tostring(v137)
								local v139 = p135.ok ~= true
								v_u_3.setText(v_u_56, v138)
								local v140 = v_u_56
								local v141
								if v139 then
									v141 = v_u_34.danger
								else
									v141 = v_u_34.text2
								end
								v140.TextColor3 = v141
							end
						elseif not v_u_134 then
							v_u_3.setText(v_u_56, "The server did not answer.")
							v_u_56.TextColor3 = v_u_34.danger
						end
						v_u_57(v_u_53)
					end
				end)
			end
		end
	end
	local v143 = v_u_3.label({
		["parent"] = nil,
		["name"] = "HuntSwAccCaption",
		["text"] = "Account age in days needed for the hunt (0 = no lock)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_28,
		["color"] = v_u_34.text2,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v144 = v_u_32.order
	local v145
	if type(v144) == "function" then
		v145 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v145 = v_u_38
	end
	v143.LayoutOrder = v145
	local v146 = v_u_3.new("Frame", {
		["Name"] = "HuntSwAccRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 38)
	}, p_u_28)
	v_u_3.layout(v146, "h", 6)
	local v147 = v_u_32.order
	local v148
	if type(v147) == "function" then
		v148 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v148 = v_u_38
	end
	v146.LayoutOrder = v148
	local v149, v_u_150 = v_u_3.input({
		["parent"] = nil,
		["name"] = "HuntSwAccInput",
		["placeholder"] = "30",
		["width"] = 120,
		["text"] = "",
		["parent"] = v146
	})
	v149.LayoutOrder = 1
	local v_u_151 = v_u_150
	v_u_150.FocusLost:Connect(function(p152)
		-- upvalues: (copy) v_u_142, (copy) v_u_150
		if p152 then
			v_u_142(v_u_150.Text)
		end
	end)
	local v153 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Set",
		["kind"] = "secondary",
		["height"] = 34,
		["width"] = 90,
		["maxTextWidth"] = 78,
		["onClick"] = nil,
		["parent"] = v146,
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_142, (copy) v_u_150
			v_u_142(v_u_150.Text)
		end
	})
	v153.Name = "HuntSwAccSet"
	v153.LayoutOrder = 2
	v_u_56 = v_u_3.label({
		["parent"] = nil,
		["name"] = "HuntSwStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_28,
		["color"] = v_u_34.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v154 = v_u_32.order
	local v155
	if type(v154) == "function" then
		v155 = v_u_32.order()
	else
		v_u_38 = v_u_38 + 1
		v155 = v_u_38
	end
	v_u_56.LayoutOrder = v155
	v52("HuntSwNote", "All reach every menu server within a minute. Raid time: a player needs this many minutes spent in raids (hunt, lobby and tutorial do not count) before JOIN HUNT works; 0 lifts the lock for everybody. Account age: the Roblox account must be this many days old (Player.AccountAge, a missing age counts as 0); 0 lifts the lock for everybody. SOON on: no new JOIN and no new round, players who already wait give up by themselves. Per region on: new joins use the six region queues, players who already wait keep their queue. Off is the default: one world queue.", v_u_34.muted)
	v_u_57 = function(p156)
		-- upvalues: (copy) v_u_43, (ref) v_u_4, (copy) v_u_34, (ref) v_u_3, (ref) v_u_88, (ref) v_u_105, (ref) v_u_127, (ref) v_u_151, (ref) v_u_5
		for _, v157 in v_u_43:GetChildren() do
			if not v157:IsA("GuiObject") then
				continue
			end
			v157:Destroy()
		end
		for v158, v159 in v_u_4.lines(p156) do
			local v160
			if v159.kind == "ok" then
				v160 = v_u_34.success
			elseif v159.kind == "warn" then
				v160 = v_u_34.danger
			elseif v159.kind == "muted" then
				v160 = v_u_34.muted
			else
				v160 = v_u_34.text2
			end
			local v161 = v_u_3.label
			local v162 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_43
			}
			local v163 = v159.name
			v162.name = "HuntSwLine_" .. tostring(v163)
			local v164 = v159.text
			v162.text = tostring(v164)
			v162.color = v160
			v162.size = UDim2.new(1, 0, 0, 0)
			v161(v162).LayoutOrder = v158
		end
		local v165 = type(p156) ~= "table" and {} or p156
		if v_u_88 then
			local v166 = v_u_88.set
			if type(v166) == "function" then
				v_u_88.set(v165.soon == true)
			end
		end
		if v_u_105 then
			local v167 = v_u_105.set
			if type(v167) == "function" then
				v_u_105.set(v165.regions == true)
			end
		end
		if v_u_127 ~= nil then
			local v168 = v165.raidMin
			if type(v168) == "number" and not v_u_127:IsFocused() then
				local v169 = v_u_127
				local v170 = v165.raidMin
				v169.Text = tostring(v170)
			end
		end
		if v_u_151 ~= nil then
			local v171 = v165.accDays
			if type(v171) == "number" and not v_u_151:IsFocused() then
				local v172 = v_u_151
				local v173 = v165.accDays
				v172.Text = tostring(v173)
			end
		end
		if v_u_5 then
			local v174 = v_u_5
			local v175 = "FilmHuntSw"
			local v176 = "soon=%d|regions=%d|live=%d|v=%s|raid=%s"
			local v177 = v165.soon == true and 1 or 0
			local v178 = v165.regions == true and 1 or 0
			local v179 = v165.soonLive
			local v180
			if type(v179) == "boolean" then
				v180 = 1
			else
				local v181 = v165.regionsLive
				if type(v181) == "boolean" then
					v180 = 1
				else
					local v182 = v165.raidMinLive
					if type(v182) == "number" then
						v180 = 1
					else
						local v183 = v165.accDaysLive
						v180 = type(v183) == "number" and 1 or 0
					end
				end
			end
			local v184 = v165.v or "?"
			local v185 = tostring(v184)
			local v186 = v165.raidMin or "?"
			local v187 = v176:format(v177, v178, v180, v185, (tostring(v186)))
			local v188 = v165.accDays or "?"
			v174:SetAttribute(v175, v187 .. "|acc=" .. tostring(v188))
		end
	end
	v_u_57(nil)
	if v_u_2:IsStudio() and v_u_5 then
		local v_u_225 = v_u_5:GetAttributeChangedSignal("FilmHuntCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_54, (copy) p_u_29, (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (ref) v_u_57, (copy) v_u_118, (copy) v_u_142, (copy) v_u_32
			local v189 = v_u_5:GetAttribute("FilmHuntCmd")
			if type(v189) == "string" and v189 ~= "" then
				v_u_5:SetAttribute("FilmHuntCmd", nil)
				local v190, v191 = string.match(v189, "^(%a+)%s*(%S*)$")
				if v190 == "soon" and (v191 == "on" or v191 == "off") then
					local v192 = {
						["cmd"] = "set",
						["soon"] = nil,
						["soon"] = v191 == "on"
					}
					if not v_u_54 then
						local v193 = p_u_29
						if type(v193) == "function" then
							v_u_54 = true
							v_u_3.setText(v_u_56, "Working ...")
							v_u_56.TextColor3 = v_u_34.text2
							local v_u_194 = nil
							p_u_29("server.hunt", v192, function(p195) -- name: done
								-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_194, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
								v_u_54 = false
								if v_u_39 then
									v_u_55 = os.clock()
									if type(p195) == "table" then
										local v196 = p195.data
										if type(v196) == "table" then
											v_u_53 = p195.data
										end
										if not v_u_194 then
											local v197 = p195.msg or (p195.ok and "Done." or "Refused.")
											local v198 = tostring(v197)
											local v199 = p195.ok ~= true
											v_u_3.setText(v_u_56, v198)
											local v200 = v_u_56
											local v201
											if v199 then
												v201 = v_u_34.danger
											else
												v201 = v_u_34.text2
											end
											v200.TextColor3 = v201
										end
									elseif not v_u_194 then
										v_u_3.setText(v_u_56, "The server did not answer.")
										v_u_56.TextColor3 = v_u_34.danger
									end
									v_u_57(v_u_53)
								end
							end)
						end
					end
				elseif v190 == "regions" and (v191 == "on" or v191 == "off") then
					local v202 = {
						["cmd"] = "set",
						["regions"] = nil,
						["regions"] = v191 == "on"
					}
					if not v_u_54 then
						local v203 = p_u_29
						if type(v203) == "function" then
							v_u_54 = true
							v_u_3.setText(v_u_56, "Working ...")
							v_u_56.TextColor3 = v_u_34.text2
							local v_u_204 = nil
							p_u_29("server.hunt", v202, function(p205) -- name: done
								-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_204, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
								v_u_54 = false
								if v_u_39 then
									v_u_55 = os.clock()
									if type(p205) == "table" then
										local v206 = p205.data
										if type(v206) == "table" then
											v_u_53 = p205.data
										end
										if not v_u_204 then
											local v207 = p205.msg or (p205.ok and "Done." or "Refused.")
											local v208 = tostring(v207)
											local v209 = p205.ok ~= true
											v_u_3.setText(v_u_56, v208)
											local v210 = v_u_56
											local v211
											if v209 then
												v211 = v_u_34.danger
											else
												v211 = v_u_34.text2
											end
											v210.TextColor3 = v211
										end
									elseif not v_u_204 then
										v_u_3.setText(v_u_56, "The server did not answer.")
										v_u_56.TextColor3 = v_u_34.danger
									end
									v_u_57(v_u_53)
								end
							end)
						end
					end
				else
					if v190 == "raid" and tonumber(v191) ~= nil then
						v_u_118(v191)
						return
					end
					if v190 == "acc" and tonumber(v191) ~= nil then
						v_u_142(v191)
						return
					end
					if v190 == "refresh" then
						local v212 = {
							["cmd"] = "status"
						}
						if not v_u_54 then
							local v213 = p_u_29
							if type(v213) ~= "function" then
								return
							end
							v_u_54 = true
							local v_u_214 = true
							local function v222(p215) -- name: done
								-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_214, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
								v_u_54 = false
								if v_u_39 then
									v_u_55 = os.clock()
									if type(p215) == "table" then
										local v216 = p215.data
										if type(v216) == "table" then
											v_u_53 = p215.data
										end
										if not v_u_214 then
											local v217 = p215.msg or (p215.ok and "Done." or "Refused.")
											local v218 = tostring(v217)
											local v219 = p215.ok ~= true
											v_u_3.setText(v_u_56, v218)
											local v220 = v_u_56
											local v221
											if v219 then
												v221 = v_u_34.danger
											else
												v221 = v_u_34.text2
											end
											v220.TextColor3 = v221
										end
									elseif not v_u_214 then
										v_u_3.setText(v_u_56, "The server did not answer.")
										v_u_56.TextColor3 = v_u_34.danger
									end
									v_u_57(v_u_53)
								end
							end
							local v223 = v_u_32.sendQuiet
							local v224
							if type(v223) == "function" then
								v224 = v_u_32.sendQuiet
							else
								v224 = p_u_29
							end
							v224("server.hunt", v212, v222)
						end
					end
				end
			end
		end)
		if v_u_37 then
			v_u_37.Destroying:Connect(function()
				-- upvalues: (copy) v_u_225
				v_u_225:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_39, (copy) v_u_37, (copy) p_u_28, (ref) v_u_54, (ref) v_u_55, (copy) p_u_29, (ref) v_u_53, (ref) v_u_3, (ref) v_u_56, (copy) v_u_34, (ref) v_u_57, (copy) v_u_32
		local v226 = false
		while v_u_39 do
			local v227 = v_u_37 == nil or v_u_37.Enabled
			if v227 then
				v227 = p_u_28.Visible
			end
			if v227 and (not v_u_54 and (not v226 or os.clock() - v_u_55 >= 5)) then
				v_u_55 = os.clock()
				local v228 = {
					["cmd"] = "status"
				}
				if not v_u_54 then
					local v229 = p_u_29
					if type(v229) == "function" then
						v_u_54 = true
						local v_u_230 = true
						local function v238(p231) -- name: done
							-- upvalues: (ref) v_u_54, (ref) v_u_39, (ref) v_u_55, (ref) v_u_53, (copy) v_u_230, (ref) v_u_3, (ref) v_u_56, (ref) v_u_34, (ref) v_u_57
							v_u_54 = false
							if v_u_39 then
								v_u_55 = os.clock()
								if type(p231) == "table" then
									local v232 = p231.data
									if type(v232) == "table" then
										v_u_53 = p231.data
									end
									if not v_u_230 then
										local v233 = p231.msg or (p231.ok and "Done." or "Refused.")
										local v234 = tostring(v233)
										local v235 = p231.ok ~= true
										v_u_3.setText(v_u_56, v234)
										local v236 = v_u_56
										local v237
										if v235 then
											v237 = v_u_34.danger
										else
											v237 = v_u_34.text2
										end
										v236.TextColor3 = v237
									end
								elseif not v_u_230 then
									v_u_3.setText(v_u_56, "The server did not answer.")
									v_u_56.TextColor3 = v_u_34.danger
								end
								v_u_57(v_u_53)
							end
						end
						local v239 = v_u_32.sendQuiet
						local v240
						if type(v239) == "function" then
							v240 = v_u_32.sendQuiet
						else
							v240 = p_u_29
						end
						v240("server.hunt", v228, v238)
					end
				end
			end
			task.wait(0.5)
			v226 = v227
		end
	end)
	return {
		["refresh"] = v71,
		["paint"] = function(p241) -- name: paint
			-- upvalues: (ref) v_u_53, (ref) v_u_57
			v_u_53 = p241
			v_u_57(p241)
		end
	}
end
return v_u_4