-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideUiRules

local v_u_1 = {
	["ACTION"] = "hideUi",
	["ATTR_HIDDEN"] = "UiHidden",
	["ATTR_OUTLINES"] = "ObjectOutlines",
	["HOLDER"] = "ui",
	["LOADING_ORDER"] = 999,
	["GROUP_ORDER"] = {
		"critical",
		"loading",
		"window",
		"aim",
		"controls",
		"effect",
		"scene",
		"film",
		"staff",
		"carrier"
	},
	["KEEP"] = {
		["critical"] = {
			"HushModal",
			"ReconnectGate",
			"HushRaid",
			"HushStuckHelp",
			"ClubFlashWarn"
		},
		["loading"] = {
			"HushLoading",
			"HushIntro",
			"HushTransit",
			"HushMenuFade",
			"HushLiveCopy"
		},
		["window"] = {
			"HushInventory",
			"HushInventoryOverlay",
			"HushHideoutStash",
			"HushHideoutTerminal",
			"CrateStageUi",
			"HushMap",
			"HushRaidSettings",
			"HushMenu",
			"HushGlobe",
			"HushTooltip",
			"HushPopup",
			"HushCommsWheel",
			"HushHotwire",
			"HushVhs",
			"HushHuntHowTo",
			"HushLiftSendUp",
			"HushHudEdit",
			"HushTutorialPick"
		},
		["aim"] = { "HushReticle" },
		["controls"] = { "HushTouch", "HushTouchTray" },
		["effect"] = {
			"HushNvgMask",
			"HushScope",
			"HushGrenadeFlash",
			"AshHumVignette",
			"KnockerMark",
			"HushHuntBlind",
			"HushHuntFx",
			"DjFog",
			"DjHear"
		},
		["scene"] = { "HushEntry", "HushEndCine" },
		["film"] = { "HushFilm", "HushFilmGuides", "HushFilmVignette" },
		["staff"] = { "ReviewTools", "ReviewDesk", "ReviewFollowBar" },
		["carrier"] = {
			"HushViewportProbe",
			"HushSafeProbe",
			"HushSafeProbeFirst",
			"HushSafeProbeIntro",
			"HushHotspotIntel",
			"GlobeBenchRef",
			"GlobeProbe",
			"GlobeDotsProbe"
		}
	},
	["HIDDEN"] = {
		"HushHUD",
		"HushHUDFx",
		"HushPrompts",
		"HushPromptMarker",
		"HushPings",
		"HushSquadEdge",
		"HushSquadChat",
		"HushHideout",
		"HushHuntHud",
		"HushHuntKill",
		"HushPvpKill",
		"HushAvatarHint",
		"HushBadge",
		"HushEventCard",
		"HushDeployBanner",
		"HushRadioLine",
		"HushPerfHud",
		"HushTestTag",
		"HushTutorial",
		"HushTutorialBanner",
		"HushVehicleHud",
		"HushVehicleLights",
		"MajorVoice",
		"HushToast",
		"HushTradeStrip",
		"TakedownHint",
		"DjCard",
		"DjLed",
		"DjBarGui",
		"HushActTitle",
		"UnlockChainDemo"
	},
	["HOSTS"] = {
		["HushHideout"] = "HideoutPanel"
	},
	["PREFIXES"] = {
		{ "HushInventoryLayer_", "window" }
	}
}
local v_u_2 = {}
for v3, v4 in v_u_1.KEEP do
	for _, v5 in v4 do
		v_u_2[v5] = v3
	end
end
for _, v6 in v_u_1.HIDDEN do
	v_u_2[v6] = "ui"
end
function v_u_1.groupOf(p7) -- name: groupOf
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v8 = v_u_2[p7]
	if v8 ~= nil then
		return v8
	end
	for _, v9 in v_u_1.PREFIXES do
		local v10 = #v9[1]
		if string.sub(p7, 1, v10) ~= v9[1] then
			continue
		end
		return v9[2]
	end
	return nil
end
function v_u_1.verdict(p11, p12) -- name: verdict
	-- upvalues: (copy) v_u_1
	local v13 = v_u_1.groupOf(p11)
	if v13 == "ui" then
		return true, "ui"
	elseif v13 == nil then
		local v14 = type(p12) ~= "number" and 0 or p12
		if v14 < 0 then
			return false, "carrier"
		elseif v_u_1.LOADING_ORDER <= v14 then
			return false, "loading"
		else
			return true, "unknown"
		end
	else
		return false, v13
	end
end
function v_u_1.hostOpen(p15, p16) -- name: hostOpen
	-- upvalues: (copy) v_u_1
	local v17
	if v_u_1.HOSTS[p15] == nil or type(p16) ~= "string" then
		v17 = false
	else
		v17 = p16 ~= ""
	end
	return v17
end
function v_u_1.hides(p18, p19) -- name: hides
	-- upvalues: (copy) v_u_1
	return v_u_1.verdict(p18, p19)
end
function v_u_1.outlinesOn(p20, p21) -- name: outlinesOn
	local v22
	if p20 == false then
		v22 = false
	else
		v22 = p21 ~= true
	end
	return v22
end
function v_u_1.reticleExtras(p23) -- name: reticleExtras
	return p23 ~= true
end
function v_u_1.resetOnPlace(p24, p25, p26) -- name: resetOnPlace
	if p24 and (p25 ~= nil and p25 ~= p26) then
		return false
	else
		return p24
	end
end
function v_u_1.hideLine(p27, p28) -- name: hideLine
	return p28 == "Touch" and "Hides the HUD, markers, hints and prompt cards in a raid and in the hideout, for recordings. Windows you open stay visible. The touch controls stay. Open this page from the gear to show everything again." or ((type(p27) ~= "string" or p27 == "") and "Hides the HUD, markers, hints and prompt cards in a raid and in the hideout, for recordings. Windows you open stay visible. Bind a key in CONTROLS to hide or show it any time." or "Hides the HUD, markers, hints and prompt cards in a raid and in the hideout, for recordings. Windows you open stay visible." .. " " .. p27 .. " hides or shows it any time.")
end
v_u_1.OUTLINE_LINE = "Soft outlines around lootable containers and hideout stations. Off: they never show, interaction prompts work as before. Only on your screen."
return v_u_1