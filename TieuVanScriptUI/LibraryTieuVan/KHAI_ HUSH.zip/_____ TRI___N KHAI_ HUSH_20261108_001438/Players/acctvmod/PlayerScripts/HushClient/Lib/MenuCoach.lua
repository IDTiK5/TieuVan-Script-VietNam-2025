-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCoach

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_74 = {
	["STEPS"] = {
		{
			["tab"] = "play",
			["title"] = "Play",
			["body"] = "Your raid at a glance. Open RAID SETUP to change map, difficulty and kit, then DEPLOY. New here? Start with the tutorial at the top."
		},
		{
			["tab"] = "character",
			["title"] = "Character",
			["body"] = "Your stash and your loadout. Whatever you take into a raid can be lost; the secure case always comes home."
		},
		{
			["tab"] = "traders",
			["title"] = "Traders",
			["body"] = "Doc, Gunner and Rook buy, sell and give jobs. Reputation from their tasks and from trading unlocks better offers."
		},
		{
			["tab"] = "tasks",
			["title"] = "Tasks",
			["body"] = "Jobs from the traders: cash, items, reputation and the story of Stillwater. Doc\'s first job is waiting here."
		},
		{
			["tab"] = "hideout",
			["title"] = "Hideout",
			["body"] = "Your basement under the gas station. Build a workbench, med station, radio and more with what you bring back."
		}
	},
	["new"] = function(p4, p_u_5, p_u_6) -- name: new
		-- upvalues: (copy) v_u_74, (copy) v_u_3, (copy) v_u_1, (copy) v_u_2
		local v_u_7 = p4.ui
		local v_u_8 = p4.theme
		local v9 = v_u_8.color
		local v10 = p4.compact()
		local v_u_11 = {}
		local v12 = p_u_6.step
		local v13 = tonumber(v12) or 1
		local v14 = #v_u_74.STEPS
		local v_u_15 = math.clamp(v13, 1, v14)
		local v_u_16 = v_u_7.new("Frame", {
			["Name"] = "Coach",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 60,
			["Active"] = false,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_5)
		local v_u_17 = v_u_7.new("Frame", {
			["Name"] = "Ring",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 61,
			["Visible"] = false
		}, v_u_16)
		local v_u_18 = v_u_7.stroke(v_u_17, v9.accent)
		v_u_18.Thickness = 2
		local v_u_19 = v10 and 300 or 360
		local v_u_20 = v_u_7.new("Frame", {
			["Name"] = "Callout",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.04,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 62,
			["Active"] = true,
			["Visible"] = false,
			["BackgroundColor3"] = v9.bg,
			["Size"] = UDim2.fromOffset(v_u_19, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_16)
		v_u_7.stroke(v_u_20, v9.accent)
		v_u_7.pad(v_u_20, {
			16,
			16,
			12,
			12
		})
		v_u_7.layout(v_u_20, "v", 6)
		local v_u_21 = v_u_7.new("Frame", {
			["Name"] = "Arrow",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["ZIndex"] = 61,
			["Visible"] = false,
			["BackgroundColor3"] = v9.accent,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(10, 10)
		}, v_u_16)
		local v22 = v_u_7.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 18)
		}, v_u_20)
		v_u_7.label({
			["parent"] = nil,
			["text"] = "Menu tour",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v22,
			["color"] = v9.accent,
			["size"] = UDim2.new(0.7, 0, 1, 0)
		})
		local v_u_23 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Step",
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v22,
			["color"] = v9.text2,
			["position"] = UDim2.fromScale(0.7, 0),
			["size"] = UDim2.new(0.3, 0, 1, 0)
		})
		local v_u_24 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = "h3",
			["order"] = 2,
			["size"] = nil,
			["parent"] = v_u_20,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v_u_25 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Body",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v_u_20,
			["color"] = v9.text
		})
		local v26 = v_u_7.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 4,
			["Size"] = UDim2.new(1, 0, 0, v_u_8.touch(40))
		}, v_u_20)
		local v_u_27, v_u_28 = v_u_7.button({
			["parent"] = nil,
			["name"] = "Skip",
			["text"] = "Skip tour",
			["kind"] = "ghost",
			["height"] = 40,
			["width"] = 120,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v26,
			["position"] = UDim2.fromScale(0, 0.5),
			["anchor"] = Vector2.new(0, 0.5),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_11
				v_u_11.skip()
			end
		})
		local v_u_29, v_u_30 = v_u_7.button({
			["parent"] = nil,
			["name"] = "Next",
			["text"] = "Next",
			["kind"] = "primary",
			["height"] = 40,
			["width"] = 120,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v26,
			["position"] = UDim2.fromScale(1, 0.5),
			["anchor"] = Vector2.new(1, 0.5),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_11
				v_u_11.next()
			end
		})
		local v_u_31 = true
		local v_u_32 = {}
		for _, v33 in v_u_20:GetDescendants() do
			if not v33:IsA("GuiObject") then
				continue
			end
			local v34 = v33.ZIndex
			v33.ZIndex = math.max(v34, 63)
		end
		local function v_u_60() -- name: place
			-- upvalues: (ref) v_u_31, (ref) v_u_74, (ref) v_u_15, (copy) p_u_6, (copy) v_u_17, (copy) v_u_21, (copy) v_u_20, (copy) p_u_5, (copy) v_u_8, (copy) v_u_19
			if v_u_31 then
				local v35 = v_u_74.STEPS[v_u_15]
				local v36 = p_u_6.target
				local v37 = v35.tab
				local v38, v39 = pcall(v36, v37)
				if v38 and (typeof(v39) == "Instance" and (v39:IsA("GuiObject") and v39.Parent)) then
					local v40 = p_u_5:FindFirstChildOfClass("UIScale")
					local v41
					if v40 then
						v41 = v40.Scale
					else
						v41 = v_u_8.uiScale()
					end
					local v42 = math.max(v41, 0.01)
					local v43 = (v39.AbsolutePosition - p_u_5.AbsolutePosition) / v42
					local v44 = v39.AbsoluteSize / v42
					local v45 = p_u_5.AbsoluteSize.X / v42
					v_u_17.Visible = true
					v_u_17.Position = UDim2.fromOffset(v43.X - 2, v43.Y + 8)
					local v46 = v_u_17
					local v47 = UDim2.fromOffset
					local v48 = v44.X + 4
					local v49 = v44.Y - 16
					v46.Size = v47(v48, (math.max(v49, 24)))
					local v50 = v43.X + v44.X / 2
					local v51 = v43.Y + v44.Y + 6
					local v52 = v50 - 56
					local v53 = v45 - v_u_19 - 12
					local v54 = math.max(12, v53)
					local v55 = math.clamp(v52, 12, v54)
					v_u_20.Visible = true
					v_u_20.Position = UDim2.fromOffset(v55, v51 + 4)
					v_u_21.Visible = true
					local v56 = v_u_21
					local v57 = UDim2.fromOffset
					local v58 = v55 + 14
					local v59 = v55 + v_u_19 - 14
					v56.Position = v57(math.clamp(v50, v58, v59), v51 + 4)
				else
					v_u_17.Visible = false
					v_u_21.Visible = false
					v_u_20.Visible = true
					v_u_20.Position = UDim2.fromOffset(24, 80)
				end
			else
				return
			end
		end
		local function v_u_68() -- name: paint
			-- upvalues: (ref) v_u_74, (ref) v_u_15, (copy) v_u_7, (copy) v_u_23, (copy) v_u_24, (copy) v_u_25, (copy) v_u_30, (copy) v_u_27, (copy) v_u_28, (copy) p_u_6, (copy) v_u_60, (ref) v_u_3, (ref) v_u_1, (copy) v_u_29
			local v61 = v_u_74.STEPS[v_u_15]
			v_u_7.setText(v_u_23, ("%d / %d"):format(v_u_15, #v_u_74.STEPS))
			v_u_7.setText(v_u_24, v61.title)
			v_u_25.Text = v61.body
			local v62 = v_u_15 >= #v_u_74.STEPS
			v_u_30.setText(v62 and "Got it" or "Next")
			v_u_27.Visible = not v62
			v_u_28.setEnabled(not v62)
			if p_u_6.reveal then
				local v63 = p_u_6.reveal
				local v64 = v61.tab
				pcall(v63, v64)
			end
			v_u_60()
			if p_u_6.onStep then
				local v65 = p_u_6.onStep
				local v66 = v_u_15
				pcall(v65, v66)
			end
			if v_u_3.GamepadEnabled or require(script.Parent:WaitForChild("VirtualPad")).active then
				local function v67()
					-- upvalues: (ref) v_u_1, (ref) v_u_29
					v_u_1.SelectedObject = v_u_29
				end
				pcall(v67)
			end
		end
		function v_u_11.next() -- name: next
			-- upvalues: (ref) v_u_31, (copy) v_u_7, (copy) v_u_8, (ref) v_u_15, (ref) v_u_74, (copy) v_u_11, (copy) p_u_6, (copy) v_u_68
			if v_u_31 then
				v_u_7.sound(v_u_8.sounds.click)
				if v_u_15 >= #v_u_74.STEPS then
					if v_u_31 then
						v_u_11.destroy()
						if p_u_6.onDone then
							task.spawn(p_u_6.onDone, false)
						end
					end
				else
					v_u_15 = v_u_15 + 1
					v_u_68()
					return
				end
			else
				return
			end
		end
		function v_u_11.skip() -- name: skip
			-- upvalues: (copy) v_u_7, (copy) v_u_8, (ref) v_u_31, (copy) v_u_11, (copy) p_u_6
			v_u_7.sound(v_u_8.sounds.click)
			if v_u_31 then
				v_u_11.destroy()
				if p_u_6.onDone then
					task.spawn(p_u_6.onDone, true)
				end
			end
		end
		function v_u_11.step() -- name: step
			-- upvalues: (ref) v_u_15
			return v_u_15
		end
		function v_u_11.alive() -- name: alive
			-- upvalues: (ref) v_u_31
			return v_u_31
		end
		function v_u_11.frame() -- name: frame
			-- upvalues: (copy) v_u_20
			return v_u_20
		end
		function v_u_11.destroy() -- name: destroy
			-- upvalues: (ref) v_u_31, (copy) v_u_32, (ref) v_u_1, (copy) v_u_16
			if v_u_31 then
				v_u_31 = false
				for _, v69 in v_u_32 do
					v69:Disconnect()
				end
				table.clear(v_u_32)
				if v_u_1.SelectedObject and v_u_1.SelectedObject:IsDescendantOf(v_u_16) then
					v_u_1.SelectedObject = nil
				end
				v_u_16:Destroy()
			end
		end
		local v_u_70 = os.clock()
		local v71 = v_u_2.Heartbeat
		table.insert(v_u_32, v71:Connect(function()
			-- upvalues: (ref) v_u_31, (copy) v_u_16, (copy) v_u_60, (copy) v_u_18, (copy) v_u_70
			if v_u_31 and v_u_16.Parent then
				v_u_60()
				local v72 = v_u_18
				local v73 = (os.clock() - v_u_70) * 4
				v72.Transparency = (math.sin(v73) * 0.5 + 0.5) * 0.35 + 0.15
			end
		end))
		v_u_68()
		v_u_7.fade(v_u_20, 0, "slow", {
			["from"] = 1
		})
		return v_u_11
	end
}
return v_u_74