-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadChat

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v2:WaitForChild("SquadChatRules"))
local v_u_4 = {}
local v_u_5 = nil
v_u_4.LINE_H = 18
v_u_4.RESERVE = 50
function v_u_4.place(p6) -- name: place
	local v7 = p6.refW
	local v8 = p6.refH
	local v9 = p6.tf
	if p6.touch and type(v9) == "table" then
		local v10 = v9.promptRight
		if type(v10) == "number" then
			local v11 = v9.promptMaxW
			if type(v11) == "number" then
				local v12 = v9.promptRight - v9.promptMaxW + 8
				local v13 = v9.promptMaxW - 8
				local v14 = math.clamp(v13, 170, 300)
				local v15 = p6.colX0
				if type(v15) == "number" then
					local v16 = p6.colX0 - 8 - math.max(v12, 8)
					v14 = math.clamp(v16, 170, v14)
				end
				local v17 = v8 - v9.promptBottom - 60 - 8
				local v18 = v9.listBottom
				local v19
				if type(v18) == "number" then
					v19 = v9.listBottom + 6
				else
					v19 = v17 - 134
				end
				local v20 = (v17 - v19 - 8) / 18
				local v21 = math.floor(v20)
				local v22 = math.clamp(v21, 2, 7)
				local v23 = v9.left or 16
				local v24 = v7 - math.max(v23, 16) * 2
				local v25 = math.clamp(v24, 240, 460)
				local v26 = {
					["x"] = nil,
					["bottom"] = nil,
					["w"] = nil,
					["lines"] = nil,
					["inputOnTop"] = true,
					["inputX"] = nil,
					["inputY"] = nil,
					["inputW"] = nil,
					["x"] = math.max(v12, 8),
					["bottom"] = v17,
					["w"] = v14,
					["lines"] = v22
				}
				local v27 = (v7 - v25) / 2
				v26.inputX = math.floor(v27)
				local v28 = v9.top or 12
				v26.inputY = math.max(v28, 6)
				v26.inputW = v25
				return v26
			end
		end
	end
	local v29 = v8 - 124 - 40
	local v30 = (v29 - 50 - 200 - 8) / 18
	local v31 = math.floor(v30)
	return {
		["x"] = 40,
		["bottom"] = nil,
		["w"] = 340,
		["lines"] = nil,
		["inputOnTop"] = false,
		["inputX"] = 40,
		["inputY"] = nil,
		["inputW"] = 340,
		["bottom"] = v29,
		["lines"] = math.clamp(v31, 3, 7),
		["inputY"] = v29 - 50 + 4
	}
end
local function v_u_33(p32) -- name: esc
	-- upvalues: (copy) v_u_3
	return v_u_3.escape(p32)
end
local function v_u_35(p34) -- name: richText
	-- upvalues: (copy) v_u_33, (copy) v_u_3
	return v_u_33(v_u_3.unescape(p34))
end
v_u_4.richText = v_u_35
function v_u_4.new(p_u_36) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_35, (ref) v_u_5, (copy) v_u_4
	local v_u_37 = p_u_36.lib.HushUI
	local v_u_38 = p_u_36.shared.Theme
	local v_u_39 = v_u_38.color
	local v_u_40 = v_u_1.LocalPlayer
	local v_u_41 = {}
	local v_u_42, v43 = v_u_37.screen("HushSquadChat", v_u_38.layer.hud + 1, {
		["insets"] = "Device"
	})
	v_u_42.Name = "HushSquadChat"
	v_u_41.gui = v_u_42
	v_u_41.root = v43
	local v_u_44 = v_u_37.new("Frame", {
		["Name"] = "Chat",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Size"] = UDim2.fromOffset(340, 160)
	}, v43)
	local v_u_45 = v_u_37.new("CanvasGroup", {
		["Name"] = "Fade",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["GroupTransparency"] = 0,
		["Size"] = UDim2.new(1, 0, 1, -50)
	}, v_u_44)
	local v46 = v_u_37.new("Frame", {
		["Name"] = "Plate",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_39.bgDeep,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_45)
	v_u_37.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.35), NumberSequenceKeypoint.new(1, 1) })
	}, v46)
	v_u_37.new("Frame", {
		["Name"] = "Tick",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_39.accent,
		["Size"] = UDim2.new(0, 2, 1, 0)
	}, v_u_45)
	local v_u_47 = v_u_37.new("ScrollingFrame", {
		["Name"] = "Log",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 0,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollingEnabled"] = false,
		["Active"] = false,
		["Selectable"] = false,
		["ElasticBehavior"] = nil,
		["Position"] = UDim2.fromOffset(8, 4),
		["Size"] = UDim2.new(1, -14, 1, -8),
		["CanvasSize"] = UDim2.fromOffset(0, 0),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarImageColor3"] = v_u_39.lineStrong,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ElasticBehavior"] = Enum.ElasticBehavior.Never
	}, v_u_45)
	local v_u_48 = v_u_37.new("UIListLayout", {
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 2)
	}, v_u_47)
	local v_u_49 = v_u_37.new("Frame", {
		["Name"] = "Spacer",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 0,
		["Size"] = UDim2.new(1, 0, 0, 0)
	}, v_u_47)
	local function v56() -- name: fitSpacer
		-- upvalues: (copy) v_u_38, (copy) v_u_48, (copy) v_u_49, (copy) v_u_47
		local v50 = v_u_38.uiScale
		local v51 = math.max(0.01, v50())
		local v52 = v_u_48.AbsoluteContentSize.Y - v_u_49.AbsoluteSize.Y
		local v53 = (v_u_47.AbsoluteWindowSize.Y - v52) / v51
		local v54 = math.floor(v53)
		local v55 = math.max(0, v54)
		if v_u_49.Size.Y.Offset ~= v55 then
			v_u_49.Size = UDim2.new(1, 0, 0, v55)
		end
	end
	v_u_48:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(v56)
	v_u_47:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v56)
	local v_u_57 = v_u_37.new("Frame", {
		["Name"] = "Unread",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Position"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_39.accent,
		["Size"] = UDim2.fromOffset(18, 18),
		["Position"] = UDim2.fromOffset(-6, -6)
	}, v_u_44)
	v_u_37.new("UICorner", {
		["CornerRadius"] = UDim.new(1, 0)
	}, v_u_57)
	local v_u_58 = v_u_37.label({
		["parent"] = nil,
		["text"] = "1",
		["style"] = "caps",
		["textSize"] = 11,
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_57,
		["color"] = v_u_39.ink,
		["size"] = UDim2.fromScale(1, 1)
	})
	v_u_58.Name = "Count"
	local v_u_59 = v_u_37.new("Frame", {
		["Name"] = "Input",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["BackgroundColor3"] = v_u_39.raised,
		["Size"] = UDim2.fromOffset(340, 30)
	}, v43)
	v_u_37.stroke(v_u_59, v_u_39.accent, 1, 0.1)
	local v_u_60 = v_u_37.new("TextBox", {
		["Name"] = "Box",
		["BackgroundTransparency"] = 1,
		["ClearTextOnFocus"] = false,
		["MultiLine"] = false,
		["TextWrapped"] = false,
		["Selectable"] = false,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["PlaceholderText"] = "Message your squad",
		["PlaceholderColor3"] = nil,
		["Text"] = "",
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5,
		["FontFace"] = v_u_38.font.body,
		["TextSize"] = v_u_38.phoneText(14, "text"),
		["TextColor3"] = v_u_39.text,
		["PlaceholderColor3"] = v_u_39.muted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(10, 0),
		["Size"] = UDim2.new(1, -20, 1, 0)
	}, v_u_59)
	local v_u_61 = v_u_37.label({
		["parent"] = nil,
		["text"] = "Only your squad sees this",
		["style"] = "micro",
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["track"] = false,
		["parent"] = v_u_59,
		["color"] = v_u_39.muted,
		["size"] = UDim2.new(1, -4, 0, 14),
		["position"] = UDim2.new(0, 2, 1, 4)
	})
	v_u_61.Name = "Hint"
	v_u_61.ZIndex = 5
	local v_u_62 = nil
	local v_u_63 = {}
	local v_u_64 = {}
	local v_u_65 = {}
	local v_u_66 = {}
	local v_u_67 = {}
	local v_u_68 = false
	local v_u_69 = 0
	local v_u_70 = -10
	local v_u_71 = os.clock()
	local v_u_72 = 0
	local v_u_73 = true
	local v_u_74 = true
	local v_u_75 = v_u_3.newLimiter(v_u_3.MIN_GAP)
	local v_u_76 = 1
	local v_u_77 = nil
	local v_u_78 = 0
	local v_u_79 = false
	local v_u_80 = 0
	local v_u_81 = 0
	local function v_u_82() -- name: members
		-- upvalues: (ref) v_u_3, (copy) v_u_40
		return v_u_3.parseMembers(v_u_40:GetAttribute("SquadChatMembers"))
	end
	local function v_u_86() -- name: scrollToEnd
		-- upvalues: (ref) v_u_79, (copy) v_u_47
		v_u_79 = false
		if v_u_47.Parent then
			local v83 = v_u_47
			local v84 = Vector2.new
			local v85 = v_u_47.AbsoluteCanvasSize.Y - v_u_47.AbsoluteWindowSize.Y
			v83.CanvasPosition = v84(0, (math.max(0, v85)))
		end
	end
	local function v_u_112(p_u_87, p88, p89, p90, p91, p92, p93) -- name: addRow
		-- upvalues: (ref) v_u_78, (ref) v_u_3, (copy) p_u_36, (copy) v_u_82, (copy) v_u_39, (ref) v_u_35, (copy) v_u_37, (copy) v_u_47, (copy) v_u_65, (copy) v_u_44, (ref) v_u_74, (ref) v_u_79, (copy) v_u_86
		v_u_78 = v_u_78 + 1
		local v94
		if p90 then
			v94 = v_u_3.escape(p89)
		else
			if not p91 then
				if p_u_87 then
					local function v95()
						-- upvalues: (ref) p_u_36, (copy) p_u_87, (ref) v_u_82
						return p_u_36.lib.HUDSquad.colorFor(p_u_87, v_u_82())
					end
					local v96
					v96, p91 = pcall(v95)
					if not v96 or typeof(p91) ~= "Color3" then
						p91 = v_u_39.info
					end
				else
					p91 = v_u_39.info
				end
			end
			local v97 = string.format
			local v98 = string.format
			local v99 = p91.R * 255 + 0.5
			local v100 = math.floor(v99)
			local v101 = p91.G * 255 + 0.5
			local v102 = math.floor(v101)
			local v103 = p91.B * 255 + 0.5
			v94 = v97("<b><font color=\"%s\">%s</font></b>: %s", v98("#%02X%02X%02X", v100, v102, (math.floor(v103))), v_u_3.escape(p88), v_u_35(p89))
			if p92 ~= nil and p92 ~= "" then
				v94 = p92 .. v94
			end
		end
		local v104 = v_u_37.label
		local v105 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["textSize"] = 14,
			["color"] = nil,
			["rich"] = true,
			["wrap"] = true,
			["autoY"] = true,
			["size"] = nil,
			["order"] = nil,
			["track"] = false,
			["parent"] = v_u_47,
			["text"] = v94
		}
		local v106
		if p90 then
			v106 = v_u_39.muted
		else
			v106 = v_u_39.text
		end
		v105.color = v106
		v105.size = UDim2.new(1, -4, 0, 18)
		v105.order = v_u_78
		local v107 = v104(v105)
		v107.Name = "Line"
		v107.TextYAlignment = Enum.TextYAlignment.Top
		v107.TextStrokeTransparency = p93 == nil and 0.8 or p93
		local v108 = v_u_65
		table.insert(v108, {
			["label"] = v107,
			["userId"] = p_u_87,
			["text"] = p89,
			["sys"] = p90
		})
		while #v_u_65 > v_u_3.MAX_LINES do
			local v109 = table.remove(v_u_65, 1)
			if not v109 then
				continue
			end
			v109.label:Destroy()
		end
		local v110 = v_u_44
		local v111 = v_u_74
		if v111 then
			v111 = #v_u_65 > 0
		end
		v110.Visible = v111
		if not v_u_79 then
			v_u_79 = true
			task.defer(v_u_86)
			task.delay(0.1, v_u_86)
		end
	end
	function v_u_41.addSystem(p113) -- name: addSystem
		-- upvalues: (copy) v_u_112, (ref) v_u_71
		v_u_112(nil, "", p113, true)
		v_u_71 = os.clock()
	end
	function v_u_41.addLine(p114, p115, p116, p117, p118, p119) -- name: addLine
		-- upvalues: (copy) v_u_112, (ref) v_u_81, (copy) v_u_40, (ref) v_u_76, (ref) v_u_68, (ref) v_u_72, (ref) v_u_71
		v_u_112(p114, p115, p116, false, p117, p118, p119)
		v_u_81 = v_u_81 + 1
		if p114 ~= v_u_40.UserId and (v_u_76 < 0.5 and not v_u_68) then
			v_u_72 = v_u_72 + 1
		end
		v_u_71 = os.clock()
	end
	local function v_u_141(p120) -- name: onMessage
		-- upvalues: (copy) v_u_66, (copy) v_u_67, (copy) v_u_40, (copy) v_u_41, (ref) v_u_3, (ref) v_u_1, (ref) v_u_5
		local v121 = p120.MessageId
		if type(v121) == "string" and v121 ~= "" then
			if v_u_66[v121] then
				return
			end
			v_u_66[v121] = true
			local v122 = v_u_67
			table.insert(v122, v121)
			if #v_u_67 > 200 then
				v_u_66[table.remove(v_u_67, 1)] = nil
			end
		end
		local v123 = p120.TextSource
		local v124 = p120.Status
		if v124 == nil or (v124 == Enum.TextChatMessageStatus.Success or v124 == Enum.TextChatMessageStatus.Unknown) then
			if v123 == nil then
				local v125 = p120.Text
				if type(v125) == "string" and p120.Text ~= "" then
					v_u_41.addSystem(v_u_3.unescape(p120.Text))
				end
			else
				local v126 = v123.UserId
				local v127 = v_u_1:GetPlayerByUserId(v126)
				local v128
				if v127 then
					v128 = v127.DisplayName
				else
					local v129 = v123.Name or "?"
					v128 = tostring(v129)
				end
				if v_u_5 == nil then
					local v130, v131 = pcall(function()
						return require((script.Parent:WaitForChild("ClanTagText", 5)))
					end)
					if not v130 or type(v131) ~= "table" then
						v131 = false
					end
					v_u_5 = v131
				end
				local v132
				if v_u_5 then
					v132 = v_u_5
				else
					v132 = nil
				end
				local v133 = nil
				local v134 = nil
				if v127 and v132 then
					local v135 = v132.tagOf(v127)
					if v135 ~= nil then
						local v136
						if v132.styleOf then
							v136 = v132.styleOf(v127)
						else
							v136 = nil
						end
						if v132.richFor then
							v133 = v132.richFor(v135, v136, nil)
						else
							v133 = v132.prefixRich(v135, nil, nil)
						end
						if v132.chatStroke then
							v134 = v132.chatStroke(v136)
						else
							v134 = nil
						end
					end
				end
				local v137 = v_u_41.addLine
				local v138 = p120.Text or ""
				v137(v126, v128, tostring(v138), nil, v133, v134)
			end
		else
			if v123 and v123.UserId == v_u_40.UserId then
				local v139, v140 = pcall(function()
					return require((script.Parent:WaitForChild("SquadsWhy", 5)))
				end)
				if not v139 or type(v140) ~= "table" then
					v140 = nil
				end
				v_u_41.addSystem(not v140 and "Your message was not sent." or v140.chatStatusText(v124.Name))
			end
			return
		end
	end
	function v_u_41.bind(p142) -- name: bind
		-- upvalues: (copy) v_u_63, (ref) v_u_62, (copy) v_u_141
		for _, v143 in v_u_63 do
			v143:Disconnect()
		end
		table.clear(v_u_63)
		v_u_62 = p142
		if p142 then
			local v144 = v_u_63
			local v145 = p142.MessageReceived
			local v146 = v_u_141
			table.insert(v144, v145:Connect(v146))
		end
	end
	function v_u_41.say(p147) -- name: say
		-- upvalues: (ref) v_u_3, (ref) v_u_62, (ref) v_u_73, (copy) v_u_75, (ref) v_u_80, (copy) v_u_41, (ref) v_u_71
		local v_u_148 = v_u_3.clean(p147)
		if not v_u_148 then
			return false, "empty"
		end
		local v_u_149 = v_u_62
		if not (v_u_149 and v_u_149.Parent) then
			return false, "no channel"
		end
		if not v_u_73 then
			return false, "cannot chat"
		end
		local v150, v151 = v_u_75.try(os.clock())
		if not v150 then
			return false, string.format("wait %.1f", v151)
		end
		v_u_80 = v_u_80 + 1
		task.spawn(function()
			-- upvalues: (copy) v_u_149, (copy) v_u_148, (ref) v_u_41
			local function v152()
				-- upvalues: (ref) v_u_149, (ref) v_u_148
				return v_u_149:SendAsync(v_u_148)
			end
			local v153, v154 = pcall(v152)
			if not v153 then
				warn("[SquadChat] SendAsync failed:", v154)
				local v155, v156 = pcall(function()
					return require((script.Parent:WaitForChild("SquadsWhy", 5)))
				end)
				if not v155 or type(v156) ~= "table" then
					v156 = nil
				end
				v_u_41.addSystem(not v156 and "Your message was not sent." or v156.SEND_FAILED)
			end
		end)
		v_u_71 = os.clock()
		return true, v_u_148
	end
	function v_u_41.setCanSend(p157) -- name: setCanSend
		-- upvalues: (ref) v_u_73, (copy) v_u_60
		if v_u_73 ~= p157 then
			v_u_73 = p157
			v_u_60.PlaceholderText = p157 and "Message your squad" or "Chat is off for your account"
		end
	end
	function v_u_41.open() -- name: open
		-- upvalues: (ref) v_u_68, (ref) v_u_73, (copy) v_u_41, (ref) v_u_69, (ref) v_u_72, (ref) v_u_71, (copy) v_u_59, (copy) v_u_47, (copy) v_u_60
		if v_u_68 then
			return true
		end
		if not v_u_73 then
			v_u_41.addSystem("Chat is off for your account.")
			return false
		end
		v_u_68 = true
		v_u_69 = os.clock()
		v_u_72 = 0
		v_u_71 = os.clock()
		v_u_59.Visible = true
		v_u_47.ScrollingEnabled = true
		v_u_47.Active = true
		v_u_47.ScrollBarThickness = 3
		task.defer(function()
			-- upvalues: (ref) v_u_68, (ref) v_u_60
			if v_u_68 then
				v_u_60.Text = ""
				v_u_60:CaptureFocus()
			end
		end)
		return true
	end
	function v_u_41.close(p158) -- name: close
		-- upvalues: (ref) v_u_68, (ref) v_u_70, (copy) v_u_60, (copy) v_u_59, (copy) v_u_47, (ref) v_u_71, (ref) v_u_79, (copy) v_u_86, (copy) v_u_41
		if v_u_68 then
			v_u_68 = false
			v_u_70 = os.clock()
			local v_u_159 = v_u_60.Text
			if v_u_60:IsFocused() then
				v_u_60:ReleaseFocus()
			end
			v_u_60.Text = ""
			v_u_59.Visible = false
			v_u_47.ScrollingEnabled = false
			v_u_47.Active = false
			v_u_47.ScrollBarThickness = 0
			v_u_71 = os.clock()
			if not v_u_79 then
				v_u_79 = true
				task.defer(v_u_86)
				task.delay(0.1, v_u_86)
			end
			if p158 then
				local v160, v161 = v_u_41.say(v_u_159)
				if not v160 and (v161 ~= "empty" and string.sub(v161, 1, 4) == "wait") then
					task.defer(function()
						-- upvalues: (ref) v_u_41, (ref) v_u_68, (ref) v_u_60, (copy) v_u_159
						if v_u_41.open() then
							task.delay(0.05, function()
								-- upvalues: (ref) v_u_68, (ref) v_u_60, (ref) v_u_159
								if v_u_68 then
									v_u_60.Text = v_u_159
								end
							end)
						end
					end)
				end
			end
		end
	end
	local v162 = v_u_60.FocusLost
	local function v164(p163)
		-- upvalues: (ref) v_u_68, (ref) v_u_69, (copy) v_u_60, (copy) v_u_41
		if v_u_68 then
			if p163 and (os.clock() - v_u_69 < 0.1 and v_u_60.Text == "") then
				task.defer(function()
					-- upvalues: (ref) v_u_68, (ref) v_u_60
					if v_u_68 then
						v_u_60:CaptureFocus()
					end
				end)
			else
				v_u_41.close(p163)
			end
		else
			return
		end
	end
	table.insert(v_u_64, v162:Connect(v164))
	local v165 = v_u_60:GetPropertyChangedSignal("Text")
	local function v170()
		-- upvalues: (copy) v_u_60, (ref) v_u_3
		local v166 = v_u_60.Text
		local v167 = utf8.len(v166)
		if v167 ~= nil then
			if v_u_3.MAX_CHARS < v167 then
				local v168 = v_u_60
				local v169 = (utf8.offset(v166, v_u_3.MAX_CHARS + 1) or #v166 + 1) - 1
				v168.Text = string.sub(v166, 1, v169)
			end
		end
	end
	table.insert(v_u_64, v165:Connect(v170))
	function v_u_41.layout(p171) -- name: layout
		-- upvalues: (ref) v_u_4, (ref) v_u_77, (copy) v_u_44, (copy) v_u_45, (copy) v_u_59, (copy) v_u_61, (ref) v_u_79, (copy) v_u_86
		local v172 = v_u_4.place(p171)
		v_u_77 = v172
		local v173 = v172.lines * 18 + 8
		local v174 = v172.inputOnTop and 0 or 50
		v_u_44.Size = UDim2.fromOffset(v172.w, v173 + v174)
		v_u_45.Size = UDim2.new(1, 0, 1, -v174)
		v_u_44.Position = UDim2.fromOffset(v172.x, v172.bottom)
		v_u_59.Position = UDim2.fromOffset(v172.inputX, v172.inputY)
		v_u_59.Size = UDim2.fromOffset(v172.inputW, 30)
		v_u_61.Position = UDim2.new(0, 2, 1, 4)
		if not v_u_79 then
			v_u_79 = true
			task.defer(v_u_86)
			task.delay(0.1, v_u_86)
		end
	end
	function v_u_41.update(_) -- name: update
		-- upvalues: (ref) v_u_71, (ref) v_u_68, (ref) v_u_3, (ref) v_u_76, (copy) v_u_45, (ref) v_u_72, (copy) v_u_44, (copy) v_u_57, (copy) v_u_58
		local v175 = os.clock() - v_u_71
		local v176 = v_u_68 and 1 or v_u_3.fadeLevel(v175)
		v_u_76 = v176
		local v177 = (1 - v176) * 0.74
		local v178 = v_u_45.GroupTransparency - v177
		if math.abs(v178) > 0.005 then
			v_u_45.GroupTransparency = v177
		end
		local v179 = v_u_72 > 0 and v176 < 0.5 and not v_u_68
		if v179 then
			v179 = v_u_44.Visible
		end
		if v_u_57.Visible ~= v179 then
			v_u_57.Visible = v179
		end
		if v179 then
			local v180
			if v_u_72 > 9 then
				v180 = "9+"
			else
				local v181 = v_u_72
				v180 = tostring(v181)
			end
			if v_u_58.Text ~= v180 then
				v_u_58.Text = v180
			end
		end
		if v176 >= 0.5 and (v_u_72 > 0 and (not v_u_68 and v_u_3.FADE_AFTER + 30 < v175)) then
			v_u_72 = 0
		end
	end
	function v_u_41.setVisible(p182) -- name: setVisible
		-- upvalues: (ref) v_u_74, (copy) v_u_42, (copy) v_u_44, (copy) v_u_65
		if v_u_74 ~= p182 or v_u_42.Enabled ~= p182 then
			v_u_74 = p182
			v_u_42.Enabled = p182
			local v183 = v_u_44
			local v184 = v_u_74
			if v184 then
				v184 = #v_u_65 > 0
			end
			v183.Visible = v184
		end
	end
	function v_u_41.isOpen() -- name: isOpen
		-- upvalues: (ref) v_u_68
		return v_u_68
	end
	function v_u_41.justClosed() -- name: justClosed
		-- upvalues: (ref) v_u_70
		return os.clock() - v_u_70 < 0.3
	end
	function v_u_41.state() -- name: state
		-- upvalues: (ref) v_u_77, (copy) v_u_65, (ref) v_u_68, (copy) v_u_60, (ref) v_u_76, (ref) v_u_72, (ref) v_u_73, (ref) v_u_80, (ref) v_u_81, (copy) v_u_44
		local v185 = v_u_77
		local v186 = string.format
		local v187 = "lines=%d open=%s focused=%s fade=%.2f unread=%d canSend=%s sent=%d received=%d visible=%s block=%s at %s place=%s"
		local v188 = #v_u_65
		local v189 = v_u_68
		local v190 = tostring(v189)
		local v191 = v_u_60
		local v192 = tostring(v191:IsFocused())
		local v193 = v_u_76
		local v194 = v_u_72
		local v195 = v_u_73
		local v196 = tostring(v195)
		local v197 = v_u_80
		local v198 = v_u_81
		local v199 = v_u_44.Visible
		local v200 = tostring(v199)
		local v201 = v_u_44.AbsoluteSize
		local v202 = tostring(v201)
		local v203 = v_u_44.AbsolutePosition
		local v204 = tostring(v203)
		local v205
		if v185 then
			local v206 = string.format
			local v207 = v185.x
			local v208 = v185.bottom
			local v209 = v185.w
			local v210 = v185.lines
			local v211 = v185.inputOnTop
			v205 = v206("x%d b%d w%d l%d top=%s", v207, v208, v209, v210, (tostring(v211)))
		else
			v205 = "-"
		end
		return v186(v187, v188, v190, v192, v193, v194, v196, v197, v198, v200, v202, v204, v205)
	end
	function v_u_41.snapshot() -- name: snapshot
		-- upvalues: (copy) v_u_65, (ref) v_u_68, (ref) v_u_76, (ref) v_u_72, (copy) v_u_42, (copy) v_u_44, (copy) v_u_47, (copy) v_u_59, (copy) v_u_60, (copy) v_u_45, (copy) v_u_57, (ref) v_u_77
		local v212 = {}
		for _, v213 in v_u_65 do
			local v214 = v213.label.Text
			table.insert(v212, v214)
		end
		return {
			["rows"] = v212,
			["open"] = v_u_68,
			["fade"] = v_u_76,
			["unread"] = v_u_72,
			["gui"] = v_u_42,
			["block"] = v_u_44,
			["log"] = v_u_47,
			["input"] = v_u_59,
			["box"] = v_u_60,
			["group"] = v_u_45,
			["dot"] = v_u_57,
			["place"] = v_u_77
		}
	end
	function v_u_41.channel() -- name: channel
		-- upvalues: (ref) v_u_62
		return v_u_62
	end
	function v_u_41.destroy() -- name: destroy
		-- upvalues: (copy) v_u_63, (copy) v_u_64, (ref) v_u_62, (ref) v_u_68, (copy) v_u_60, (copy) v_u_42
		for _, v215 in v_u_63 do
			v215:Disconnect()
		end
		table.clear(v_u_63)
		for _, v216 in v_u_64 do
			v216:Disconnect()
		end
		table.clear(v_u_64)
		v_u_62 = nil
		v_u_68 = false
		if v_u_60:IsFocused() then
			v_u_60:ReleaseFocus()
		end
		v_u_42:Destroy()
	end
	return v_u_41
end
return v_u_4