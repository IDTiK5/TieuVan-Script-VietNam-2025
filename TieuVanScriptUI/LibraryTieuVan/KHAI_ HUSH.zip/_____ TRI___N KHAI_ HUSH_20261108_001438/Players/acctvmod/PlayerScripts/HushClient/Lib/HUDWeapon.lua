-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDWeapon

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v2 = {}
local v_u_3 = { "FMJ", "HP", "AP" }
local v_u_4 = {
	["semi"] = "SEMI",
	["auto"] = "AUTO",
	["pump"] = "PUMP",
	["bolt"] = "BOLT",
	["burst"] = "BURST"
}
function v2.new(p_u_5) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_1
	local v_u_6 = p_u_5.UI
	local v_u_7 = p_u_5.Theme
	local v_u_8 = v_u_7.color
	local v9 = {}
	local v_u_10 = nil
	local v_u_11 = nil
	local function v12()
		-- upvalues: (ref) v_u_11, (copy) p_u_5
		v_u_11 = p_u_5.cctx.shared.FlareAmmo
	end
	pcall(v12)
	local v_u_13 = p_u_5.cctx.shared.HudWhy
	local v_u_14 = 0
	local v_u_15 = v_u_6.new("Frame", {
		["Name"] = "Weapon",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -40, 1, -40),
		["Size"] = UDim2.fromOffset(296, 76)
	}, p_u_5.root)
	local v_u_16 = v_u_6.new("UIScale", {
		["Name"] = "Fit",
		["Scale"] = 1
	}, v_u_15)
	local v_u_17 = v_u_6.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 20)
	}, v_u_15)
	v_u_6.layout(v_u_17, "h", 8, "right")
	local v_u_18 = v_u_6.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "h3",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 10,
		["maxSize"] = nil,
		["parent"] = v_u_17,
		["color"] = v_u_8.text,
		["size"] = UDim2.fromOffset(0, 20),
		["maxSize"] = Vector2.new(220, 20)
	})
	local function v23(p19, p20, p21) -- name: tag
		-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_17
		local v22 = v_u_6.new("Frame", {
			["Name"] = "Tag",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_8.bg,
			["Size"] = UDim2.fromOffset(0, 18),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["LayoutOrder"] = p21
		}, v_u_17)
		v_u_6.stroke(v22, p20, 1, 0.5)
		v_u_6.pad(v22, {
			6,
			6,
			0,
			0
		})
		return v22, v_u_6.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["parent"] = v22,
			["text"] = p19,
			["color"] = p20,
			["size"] = UDim2.fromOffset(0, 18)
		})
	end
	local v_u_24, v_u_25 = v23("SEMI", v_u_8.text2, 3)
	v_u_6.layout(v_u_24, "h", 5)
	v_u_25.LayoutOrder = 1
	local v_u_26 = v_u_6.keyHint("fireMode", {
		["parent"] = nil,
		["size"] = 14,
		["order"] = 2,
		["parent"] = v_u_24
	})
	v_u_26:SetAttribute("ForceHidden", true)
	v_u_26.Visible = false
	local v_u_27 = v_u_6.new("TextButton", {
		["Name"] = "ModeTap",
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(64, 44)
	}, v_u_15)
	v_u_27.Activated:Connect(function()
		-- upvalues: (copy) p_u_5
		local v28 = p_u_5.cctx.controllers.WeaponClient
		if v28 then
			local v29 = v28.cycleFireMode
			if type(v29) == "function" then
				local v30 = v28.cycleFireMode
				pcall(v30)
			end
		end
	end)
	local v_u_31 = false
	local v_u_32, v_u_33 = v23("SUPPRESSED", v_u_8.info, 2)
	local v_u_34, v_u_35 = v23("", v_u_8.text2, 1)
	local v_u_36, v_u_37 = v23("PUNCH", v_u_8.text2, 4)
	v_u_6.layout(v_u_36, "h", 5)
	v_u_37.LayoutOrder = 1
	local v_u_38 = v_u_6.keyHint("melee", {
		["parent"] = nil,
		["size"] = 14,
		["order"] = 2,
		["parent"] = v_u_36
	})
	local v_u_39 = v_u_6.new("Frame", {
		["Name"] = "Ammo",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, 24),
		["Size"] = UDim2.new(1, 0, 0, 40)
	}, v_u_15)
	v_u_6.layout(v_u_39, "h", 6, "right").VerticalAlignment = Enum.VerticalAlignment.Bottom
	local v_u_40 = 40
	local v_u_41 = v_u_6.label({
		["parent"] = nil,
		["text"] = "0",
		["style"] = "monoL",
		["textSize"] = 40,
		["align"] = "right",
		["autoX"] = true,
		["size"] = nil,
		["order"] = 1,
		["valign"] = "bottom",
		["parent"] = v_u_39,
		["size"] = UDim2.fromOffset(0, 44)
	})
	local v_u_42 = v_u_6.label({
		["parent"] = nil,
		["text"] = "/",
		["style"] = "mono",
		["textSize"] = 18,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 2,
		["valign"] = "bottom",
		["parent"] = v_u_39,
		["color"] = v_u_8.muted,
		["size"] = UDim2.fromOffset(0, 30)
	})
	local v_u_43 = v_u_6.label({
		["parent"] = nil,
		["text"] = "0",
		["style"] = "mono",
		["textSize"] = 18,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 3,
		["valign"] = "bottom",
		["parent"] = v_u_39,
		["color"] = v_u_8.text2,
		["size"] = UDim2.fromOffset(0, 30)
	})
	local v_u_44 = v_u_6.icon("ammo", {
		["parent"] = nil,
		["size"] = 14,
		["color"] = nil,
		["parent"] = v_u_39,
		["color"] = v_u_8.text2
	})
	v_u_44.LayoutOrder = 0
	v_u_44.Visible = false
	local v_u_45 = v_u_6.new("Frame", {
		["Name"] = "AmmoTypeWrap",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = -1,
		["Visible"] = false,
		["Size"] = UDim2.fromOffset(0, 23),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v_u_39)
	local v_u_46 = v_u_6.new("Frame", {
		["Name"] = "AmmoType",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_8.bg,
		["Size"] = UDim2.fromOffset(0, 18),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v_u_45)
	local v_u_47 = v_u_6.stroke(v_u_46, v_u_8.text2, 1, 0.5)
	v_u_6.pad(v_u_46, {
		6,
		6,
		0,
		0
	})
	local v_u_48 = v_u_6.label({
		["parent"] = nil,
		["text"] = "FMJ",
		["style"] = "micro",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["parent"] = v_u_46,
		["color"] = v_u_8.text2,
		["size"] = UDim2.fromOffset(0, 18)
	})
	local v_u_49 = v_u_6.new("TextButton", {
		["Name"] = "AmmoTypeTap",
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(64, 44)
	}, v_u_15)
	local v_u_50 = 0
	local v_u_51 = ""
	local v_u_52 = -10
	local v_u_53 = nil
	local v_u_54 = 0
	local v_u_55 = ""
	local function v66() -- name: tapAmmo
		-- upvalues: (copy) p_u_5, (ref) v_u_10, (copy) v_u_6, (ref) v_u_52, (ref) v_u_14
		local v56 = p_u_5.cctx.controllers.InventoryUI
		local v57 = v_u_10
		if v57 then
			v57 = v_u_10:GetAttribute("WeaponUid")
		end
		if v56 then
			local v58 = v56.nextAmmo
			if type(v58) == "function" then
				local v59 = v56.loadAmmo
				if type(v59) == "function" and type(v57) == "string" then
					local v60 = v56.nextAmmo
					local v61, v62 = pcall(v60, v57)
					if not v61 or type(v62) ~= "string" then
						v_u_52 = v_u_14 - 0.6
						return "no other type"
					end
					local v63 = v56.loadAmmo
					local v64, v65 = pcall(v63, v57, v62)
					v_u_6.sound("click")
					return tostring(v62) .. " " .. tostring(v64 and v65)
				end
			end
		end
		return "no weapon"
	end
	v_u_49.Activated:Connect(v66)
	local v67 = p_u_5.cctx.command
	if type(v67) == "function" then
		p_u_5.cctx.command("hud.ammotap", v66)
	end
	local v_u_68 = v_u_6.new("Frame", {
		["Name"] = "Pips",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Position"] = UDim2.fromOffset(0, 72),
		["Size"] = UDim2.new(1, 0, 0, 4)
	}, v_u_15)
	local v_u_69 = {}
	local v_u_70 = v_u_6.progress({
		["parent"] = nil,
		["size"] = nil,
		["position"] = nil,
		["value"] = 0,
		["color"] = nil,
		["parent"] = v_u_15,
		["size"] = UDim2.new(1, 0, 0, 4),
		["position"] = UDim2.fromOffset(0, 72),
		["color"] = v_u_8.accent
	})
	v_u_70.frame.Visible = false
	local v_u_71 = v_u_6.new("Frame", {
		["Name"] = "Warn",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, 0, 0, -8),
		["Size"] = UDim2.fromOffset(0, 24),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v_u_15)
	v_u_6.layout(v_u_71, "h", 8, "right")
	local v_u_72 = v_u_6.label({
		["parent"] = nil,
		["text"] = "RELOAD",
		["style"] = "caps",
		["textSize"] = 14,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 1,
		["parent"] = v_u_71,
		["color"] = v_u_8.danger,
		["size"] = UDim2.fromOffset(0, 24)
	})
	local v_u_73 = v_u_6.keyHint("reload", {
		["parent"] = nil,
		["size"] = 20,
		["order"] = 2,
		["parent"] = v_u_71
	})
	local v_u_74 = v_u_6.label({
		["parent"] = nil,
		["text"] = "CANCEL",
		["style"] = "caps",
		["textSize"] = 12,
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 3,
		["parent"] = v_u_71,
		["color"] = v_u_8.text2,
		["size"] = UDim2.fromOffset(0, 24)
	})
	v_u_74.Visible = false
	local v_u_75 = v_u_70.frame:FindFirstChild("Fill")
	local v_u_76 = ""
	local v_u_77 = ""
	local v_u_78 = -1
	local v_u_79 = 0
	local v_u_80 = false
	local function v_u_85(p81) -- name: buildPips
		-- upvalues: (copy) v_u_69, (copy) v_u_6, (copy) v_u_8, (copy) v_u_68
		for _, v82 in v_u_69 do
			v82:Destroy()
		end
		table.clear(v_u_69)
		if p81 > 0 and p81 <= 60 then
			local v83 = p81 > 30 and 1 or 2
			for v84 = 1, p81 do
				v_u_69[v84] = v_u_6.new("Frame", {
					["Name"] = "P",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_8.text,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1 - (v84 - 1) / p81, v84 == 1 and 0 or -v83 / 2, 0, 0),
					["Size"] = UDim2.new(1 / p81, -v83, 1, 0)
				}, v_u_68)
			end
		end
	end
	function v9.setCharacter(p86) -- name: setCharacter
		-- upvalues: (ref) v_u_10, (ref) v_u_76, (ref) v_u_77, (ref) v_u_78
		v_u_10 = p86
		v_u_76 = ""
		v_u_77 = ""
		v_u_78 = -1
	end
	local v_u_87 = {}
	local function v_u_92() -- name: fitHead
		-- upvalues: (ref) v_u_31, (copy) v_u_7, (copy) v_u_17, (copy) v_u_18, (copy) v_u_34, (copy) v_u_32, (copy) v_u_24, (copy) v_u_87
		if v_u_31 and v_u_7.isPhone() then
			local v88 = v_u_17.AbsoluteSize.X
			if v88 >= 10 then
				local v89 = v_u_18.AbsoluteSize.X
				for _, v90 in { v_u_34, v_u_32, v_u_24 } do
					if not v90.Visible then
						continue
					end
					if v90.AbsoluteSize.X > 0 then
						v_u_87[v90] = v90.AbsoluteSize.X
					end
					v89 = v89 + ((v_u_87[v90] or 0) + 8)
				end
				for _, v91 in { v_u_34, v_u_32 } do
					if v88 - 1 >= v89 or not v91.Visible then
						continue
					end
					v89 = v89 - ((v_u_87[v91] or 0) + 8)
					v91.Visible = false
				end
			end
		else
			return
		end
	end
	local v_u_93 = false
	local function v_u_95(p94) -- name: applyDensity
		-- upvalues: (ref) v_u_93, (ref) v_u_40, (copy) v_u_41, (copy) v_u_43, (copy) v_u_7, (copy) v_u_42, (copy) v_u_39, (copy) v_u_68, (copy) v_u_70, (copy) v_u_72
		v_u_93 = p94
		v_u_40 = p94 and 32 or 40
		v_u_41.TextSize = v_u_40
		v_u_41.Size = UDim2.fromOffset(0, p94 and 34 or 44)
		v_u_43.TextSize = not p94 and 18 or v_u_7.phoneText(16, "text")
		v_u_42.TextSize = not p94 and 18 or v_u_7.phoneText(16, "text")
		v_u_39.Position = UDim2.fromOffset(0, p94 and 20 or 24)
		v_u_39.Size = UDim2.new(1, 0, 0, p94 and 32 or 40)
		v_u_68.Position = UDim2.fromOffset(0, p94 and 52 or 72)
		v_u_70.frame.Position = UDim2.fromOffset(0, p94 and 52 or 72)
		v_u_72.TextSize = not p94 and 14 or v_u_7.phoneText(12, "caption")
	end
	function v9.layout(p96) -- name: layout
		-- upvalues: (ref) v_u_31, (copy) p_u_5, (copy) v_u_95, (copy) v_u_15, (copy) v_u_16, (copy) v_u_71, (copy) v_u_7
		v_u_31 = p96
		local v97
		if p96 and p_u_5.touchFrame then
			v97 = p_u_5.touchFrame()
		else
			v97 = nil
		end
		local v98 = v_u_95
		local v99
		if v97 == nil then
			v99 = false
		else
			v99 = v97.corner ~= nil
		end
		v98(v99)
		if v97 and v97.corner then
			local v100 = p_u_5.cctx.lib.HudLayout
			v_u_15.AnchorPoint = Vector2.new(1, 0)
			v_u_16.Scale = v97.weaponScale
			v_u_15.Position = v100.position("Weapon", UDim2.new(1, -v97.right, 0, v97.weaponY))
			v_u_15.Size = UDim2.fromOffset(v100.K.WEAPON_W, v100.K.WEAPON_H)
			v_u_71.AnchorPoint = Vector2.new(0, 0.5)
			v_u_71.Position = UDim2.fromOffset(0, 36)
			return
		elseif v97 then
			v_u_15.AnchorPoint = Vector2.new(1, 0)
			local v101 = v97.weaponScale
			local v102 = type(v101) ~= "number" and 1 or v97.weaponScale
			v_u_16.Scale = v102
			local v103 = v_u_15
			local v104 = UDim2.new
			local v105 = 1
			local v106 = -v97.right
			local v107 = 0
			local v108 = v97.weaponY
			local v109
			if type(v108) == "number" then
				v109 = v97.weaponY
			else
				v109 = v97.top + 44
			end
			v103.Position = v104(v105, v106, v107, v109)
			local v110 = v_u_15
			local v111 = UDim2.fromOffset
			local v112 = v97.weaponW / v102
			v110.Size = v111(math.min(296, v112), 76)
			if v_u_7.isPhone() then
				v_u_71.AnchorPoint = Vector2.new(1, 0)
				v_u_71.Position = UDim2.new(1, 0, 0, 100)
			else
				v_u_71.AnchorPoint = Vector2.new(1, 0.5)
				v_u_71.Position = UDim2.new(0, -12, 0, 44)
			end
		else
			v_u_16.Scale = 1
			v_u_15.AnchorPoint = Vector2.new(1, 1)
			v_u_15.Position = UDim2.new(1, -40, 1, -40)
			v_u_15.Size = UDim2.fromOffset(296, 76)
			v_u_71.AnchorPoint = Vector2.new(1, 1)
			v_u_71.Position = UDim2.new(1, 0, 0, -8)
			return
		end
	end
	function v9.update(p113) -- name: update
		-- upvalues: (ref) v_u_14, (ref) v_u_10, (copy) v_u_15, (copy) p_u_5, (copy) v_u_34, (copy) v_u_35, (ref) v_u_76, (copy) v_u_6, (copy) v_u_18, (copy) v_u_69, (copy) v_u_39, (copy) v_u_68, (copy) v_u_70, (copy) v_u_71, (copy) v_u_24, (copy) v_u_27, (copy) v_u_32, (copy) v_u_36, (ref) v_u_31, (copy) v_u_37, (copy) v_u_38, (copy) v_u_85, (ref) v_u_77, (ref) v_u_78, (copy) v_u_33, (copy) v_u_8, (copy) v_u_26, (copy) v_u_25, (copy) v_u_92, (copy) v_u_45, (copy) v_u_49, (ref) v_u_4, (copy) v_u_7, (ref) v_u_50, (ref) v_u_51, (ref) v_u_52, (ref) v_u_54, (ref) v_u_3, (ref) v_u_11, (ref) v_u_53, (copy) v_u_48, (copy) v_u_46, (copy) v_u_47, (ref) v_u_55, (ref) v_u_40, (copy) v_u_41, (copy) v_u_43, (copy) v_u_42, (copy) v_u_44, (ref) v_u_80, (ref) v_u_79, (ref) v_u_1, (copy) v_u_75, (copy) v_u_72, (copy) v_u_13, (ref) v_u_93, (copy) v_u_73, (copy) v_u_74
		v_u_14 = v_u_14 + p113
		local v114 = v_u_10
		if v114 and (v114.Parent and (v114:GetAttribute("Dead") ~= true and v114:GetAttribute("Downed") ~= true)) then
			local v115 = p_u_5.trayOverlaps
			local v116
			if type(v115) == "function" then
				v116 = p_u_5.trayOverlaps(v_u_15, 12)
			else
				v116 = false
			end
			local v117 = v114:GetAttribute("Weapon")
			local v118 = v114:GetAttribute("Throwable")
			if type(v118) == "string" and v118 ~= "" then
				v_u_34.Visible = true
				local v119 = v114:GetAttribute("Throwables")
				v_u_35.Text = string.upper((v118:gsub("^throw_", ""))) .. (type(v119) ~= "number" and "" or " x" .. v119)
			else
				v_u_34.Visible = false
			end
			if type(v117) == "string" and v117 ~= "" then
				v_u_36.Visible = false
				v_u_15.Visible = not v116
				local v120 = p_u_5.cctx.controllers.WeaponClient
				local v121
				if v120 then
					local v122 = v120.hudState
					if type(v122) == "function" then
						local v123 = v120.hudState
						local v124
						v124, v121 = pcall(v123)
						if not v124 or type(v121) ~= "table" then
							v121 = nil
						end
					else
						v121 = nil
					end
				else
					v121 = nil
				end
				local v125 = v114:GetAttribute("WeaponName")
				if type(v125) == "string" and v125 ~= "" then
					v117 = v125
				end
				local v126
				if v121 then
					v126 = v121.magSize
				else
					v126 = v121
				end
				local v127 = v114:GetAttribute("MagSize")
				local v128 = type(v127) ~= "number" and 0 or v127
				if type(v126) ~= "number" then
					v126 = v128
				end
				local v129 = math.floor(v126)
				local v130
				if v121 then
					v130 = v121.ammo
				else
					v130 = v121
				end
				local v131 = v114:GetAttribute("Ammo")
				local v132 = type(v131) ~= "number" and 0 or v131
				if type(v130) ~= "number" then
					v130 = v132
				end
				local v133 = math.floor(v130)
				local v134
				if v121 == nil then
					v134 = false
				else
					v134 = v121.twin == true
				end
				local v135
				if v134 then
					local v136 = v121.ammo2
					local v137 = v114:GetAttribute("Ammo2")
					local v138 = type(v137) ~= "number" and 0 or v137
					if type(v136) ~= "number" then
						v136 = v138
					end
					v135 = math.floor(v136)
				else
					v135 = 0
				end
				local v139
				if v134 then
					local v140 = v121.magSize2
					if type(v140) ~= "number" then
						v140 = v129
					end
					v139 = v129 + math.floor(v140)
				else
					v139 = v129
				end
				local v141 = v133 + v135
				local v142
				if v121 then
					v142 = v121.reserve
				else
					v142 = v121
				end
				local v143 = v114:GetAttribute("AmmoReserve")
				local v144 = type(v143) ~= "number" and 0 or v143
				if type(v142) ~= "number" then
					v142 = v144
				end
				local v145 = math.floor(v142)
				local v146 = v121 and v121.mode or v114:GetAttribute("FireMode")
				local v147
				if v121 and v121.reloading ~= nil then
					v147 = v121.reloading == true
				else
					v147 = v114:GetAttribute("Reloading") == true
				end
				local v148 = v114:GetAttribute("Jammed") == true
				local v149 = (v129 <= 0 or v114:GetAttribute("HoldType") == "melee1h") and true or v114:GetAttribute("HoldType") == "melee2h"
				local v150 = v117 .. "|" .. v129
				if v150 ~= v_u_76 then
					v_u_76 = v150
					v_u_6.setText(v_u_18, v117)
					v_u_85(v149 and 0 or v129)
					v_u_77 = ""
					v_u_78 = -1
				end
				v_u_39.Visible = not v149
				local v151 = v_u_68
				local v152 = not v149
				if v152 then
					v152 = not v147
				end
				v151.Visible = v152
				local v153 = v114:GetAttribute("Suppressed") == true
				local v154 = v114:GetAttribute("SuppDur")
				local v155 = not (v153 or v149)
				if v155 then
					if type(v154) == "number" and v154 >= 0 then
						v155 = v154 < 0.001
					else
						v155 = false
					end
				end
				v_u_32.Visible = v153 or v155
				local v156 = v153 and "SUPPRESSED" or "CAN WORN"
				if v_u_33.Text ~= v156 then
					v_u_6.setText(v_u_33, v156)
					local v157
					if v153 then
						v157 = v_u_8.info
					else
						v157 = v_u_8.accent
					end
					v_u_33.TextColor3 = v157
					local v158 = v_u_32:FindFirstChildOfClass("UIStroke")
					if v158 then
						v158.Color = v157
					end
				end
				local v159 = v114:GetAttribute("FireModes")
				local v160 = not v149
				if v160 then
					if type(v159) == "string" then
						v160 = string.find(v159, ",", 1, true) ~= nil
					else
						v160 = false
					end
				end
				if v_u_26:GetAttribute("ForceHidden") == v160 then
					v_u_26:SetAttribute("ForceHidden", not v160)
				end
				local v161
				if v160 then
					v161 = v_u_6.hint("fireMode") ~= ""
				else
					v161 = v160
				end
				if v_u_26.Visible ~= v161 then
					v_u_26.Visible = v161
				end
				if v149 then
					v_u_24.Visible = true
					v_u_25.Text = "MELEE"
					v_u_92()
					v_u_27.Visible = false
					v_u_45.Visible = false
					v_u_49.Visible = false
					v_u_71.Visible = false
					v_u_70.frame.Visible = false
				else
					local v162 = v_u_24
					local v163
					if type(v146) == "string" then
						v163 = v146 ~= ""
					else
						v163 = false
					end
					v162.Visible = v163
					if v_u_24.Visible then
						v_u_25.Text = v_u_4[v146] or string.upper(v146)
					end
					v_u_92()
					local v164 = v_u_31
					if v164 then
						if v160 then
							v160 = v_u_24.Visible
						end
					else
						v160 = v164
					end
					if v160 then
						local v165 = v_u_15.AbsoluteSize.X
						local v166 = (v165 <= 0 or v_u_15.Size.X.Offset <= 0) and 1 or v165 / v_u_15.Size.X.Offset
						local v167 = (v_u_24.AbsolutePosition - v_u_15.AbsolutePosition + v_u_24.AbsoluteSize / 2) / v166
						local v168 = v_u_27
						local v169 = UDim2.fromOffset
						local v170 = v167.X + 0.5
						local v171 = math.floor(v170)
						local v172 = v167.Y + 0.5
						v168.Position = v169(v171, (math.floor(v172)))
						local v173 = v_u_7.touchMin
						local v174 = tonumber(v173) or 44
						local v175
						if v166 > 0 then
							local v176 = v174 / v166
							local v177 = math.ceil(v176)
							v175 = math.max(44, v177)
						else
							v175 = 44
						end
						local v178 = v_u_24.AbsoluteSize.X / v166
						local v179 = math.floor(v178) + 20
						local v180 = math.max(56, v179, v175)
						if v_u_27.Size.X.Offset ~= v180 or v_u_27.Size.Y.Offset ~= v175 then
							v_u_27.Size = UDim2.fromOffset(v180, v175)
						end
					end
					if v_u_27.Visible ~= v160 then
						v_u_27.Visible = v160
					end
					local v181 = v114:GetAttribute("AmmoTier")
					local v182 = type(v181) ~= "number" and 0 or v181
					local v183 = math.floor(v182)
					local v184 = v114:GetAttribute("WeaponUid")
					if type(v184) == "string" then
						v117 = v184
					end
					if v183 ~= v_u_50 or v117 ~= v_u_51 then
						if v117 == v_u_51 and (v_u_50 > 0 and v183 > 0) then
							v_u_52 = v_u_14
						end
						v_u_50 = v183
						v_u_51 = v117
						v_u_54 = 0
					end
					local v185 = v_u_3[v183]
					local v186
					if v_u_11 then
						v186 = v_u_11.chip(v114:GetAttribute("Weapon"), v183)
					else
						v186 = nil
					end
					if v186 then
						v185 = v186.text
					end
					v_u_45.Visible = v185 ~= nil
					if v185 then
						local v187
						if v186 then
							v187 = v186.color
						elseif v183 == 2 then
							v187 = v_u_8.success or v_u_8.text2
						elseif v183 == 3 then
							v187 = v_u_8.info or v_u_8.text2
						else
							v187 = v_u_8.text2
						end
						if v_u_31 and v_u_54 <= v_u_14 then
							v_u_54 = v_u_14 + 0.5
							local v188 = p_u_5.cctx.controllers.InventoryUI
							v_u_53 = nil
							if v188 then
								local v189 = v188.nextAmmo
								if type(v189) == "function" and type(v184) == "string" then
									local v190 = v188.nextAmmo
									local v191, v192 = pcall(v190, v184)
									if not v191 or type(v192) ~= "string" then
										v192 = nil
									end
									v_u_53 = v192
								end
							end
						elseif not v_u_31 then
							v_u_53 = nil
						end
						local v193
						if v_u_53 then
							v193 = v185 .. " \226\128\186"
						else
							v193 = v185
						end
						if v_u_48.Text ~= v193 then
							v_u_48.Text = v193
						end
						local v194 = 1 - (v_u_14 - v_u_52) / 1.2
						local v195 = math.clamp(v194, 0, 1)
						if v195 > 0 then
							local v196 = (v_u_14 - v_u_52) * 14
							local v197 = v195 * (math.cos(v196) * 0.25 + 0.75)
							v_u_46.BackgroundColor3 = v_u_8.bg:Lerp(v187, v197)
							v_u_46.BackgroundTransparency = (1 - v195) * 0.3
							v_u_48.TextColor3 = v187:Lerp(v_u_8.ink or v_u_8.bg, v197)
							v_u_47.Transparency = (1 - v195) * 0.5
						elseif v_u_46.BackgroundColor3 ~= v_u_8.bg or v_u_48.TextColor3 ~= v187 then
							v_u_46.BackgroundColor3 = v_u_8.bg
							v_u_46.BackgroundTransparency = 0.3
							v_u_48.TextColor3 = v187
							v_u_47.Transparency = 0.5
						end
						if v_u_47.Color ~= v187 then
							v_u_47.Color = v187
						end
					end
					local v198 = v_u_31
					if v198 then
						if v185 == nil then
							v198 = false
						else
							v198 = v_u_53 ~= nil
						end
					end
					if v198 then
						local v199 = v_u_15.AbsoluteSize.X
						local v200 = (v199 <= 0 or v_u_15.Size.X.Offset <= 0) and 1 or v199 / v_u_15.Size.X.Offset
						local v201 = (v_u_46.AbsolutePosition - v_u_15.AbsolutePosition + v_u_46.AbsoluteSize / 2) / v200
						local v202 = v_u_49
						local v203 = UDim2.fromOffset
						local v204 = v201.X + 0.5
						local v205 = math.floor(v204)
						local v206 = v201.Y + 0.5
						v202.Position = v203(v205, (math.floor(v206)))
						local v207 = v_u_7.touchMin
						local v208 = tonumber(v207) or 44
						local v209
						if v200 > 0 then
							local v210 = v208 / v200
							local v211 = math.ceil(v210)
							v209 = math.max(44, v211)
						else
							v209 = 44
						end
						local v212 = v_u_46.AbsoluteSize.X / v200
						local v213 = math.floor(v212) + 20
						local v214 = math.max(56, v213, v209)
						if v_u_49.Size.X.Offset ~= v214 or v_u_49.Size.Y.Offset ~= v209 then
							v_u_49.Size = UDim2.fromOffset(v214, v209)
						end
					end
					if v_u_49.Visible ~= v198 then
						v_u_49.Visible = v198
					end
					if v160 and v198 then
						local v215 = v_u_27.Position
						local v216 = v_u_49.Position
						local v217 = v_u_27.Size.Y.Offset
						local v218 = v_u_49.Size.Y.Offset
						local v219 = v215.X.Offset - v216.X.Offset
						if math.abs(v219) < (v_u_27.Size.X.Offset + v_u_49.Size.X.Offset) / 2 and v216.Y.Offset - v215.Y.Offset < (v217 + v218) / 2 then
							local v220 = (v215.Y.Offset + v216.Y.Offset) / 2
							local v221 = math.floor(v220)
							local v222 = v_u_27
							local v223 = UDim2.fromOffset
							local v224 = v215.X.Offset
							local v225 = v217 / 2
							v222.Position = v223(v224, v221 - math.ceil(v225))
							local v226 = v_u_49
							local v227 = UDim2.fromOffset
							local v228 = v216.X.Offset
							local v229 = v218 / 2
							v226.Position = v227(v228, v221 + math.ceil(v229))
						end
					end
					local v230 = (v185 or "") .. (v198 and " tap" or "") .. (v_u_14 - v_u_52 < 1.2 and " flash" or "")
					if v230 ~= v_u_55 then
						v_u_55 = v230
						v114:SetAttribute("HudAmmoType", v230)
					end
					local v231 = v139 <= 0 and 0 or v141 / v139
					local v232
					if v141 <= 0 then
						v232 = v_u_8.danger
					elseif v231 <= 0.25 or v134 and (v133 <= 0 or v135 <= 0) then
						v232 = v_u_8.accent
					else
						v232 = v_u_8.text
					end
					local v233 = v133 .. "|" .. v145 .. "|" .. #v_u_69 .. "|" .. (not v134 and -1 or v135)
					if v233 ~= v_u_77 then
						local v234
						if v134 then
							v234 = v_u_40 - 12
						else
							v234 = v_u_40
						end
						if v141 < v_u_78 and v_u_78 >= 0 then
							v_u_41.TextSize = v234 + 3
							v_u_6.tween(v_u_41, {
								["TextSize"] = v234
							}, 0.12)
						else
							v_u_41.TextSize = v234
						end
						v_u_77 = v233
						v_u_78 = v141
						local v235 = v_u_41
						local v236
						if v134 then
							v236 = tostring(v133) .. " | " .. tostring(v135)
						else
							v236 = tostring(v133)
						end
						v235.Text = v236
						v_u_43.Text = tostring(v145)
						v_u_41.TextColor3 = v232
						v_u_42.TextColor3 = v_u_8.muted
						local v237 = v_u_43
						local v238
						if v145 <= 0 then
							v238 = v_u_8.danger
						else
							v238 = v_u_8.text2
						end
						v237.TextColor3 = v238
						local v239 = v_u_6.setIconColor
						local v240 = v_u_44
						local v241
						if v141 <= 0 then
							v241 = v_u_8.danger
						else
							v241 = v_u_8.text2
						end
						v239(v240, v241)
						if v134 and v139 > 0 then
							local v242 = v141 * v129 / v139
							v133 = math.ceil(v242)
						end
						for v243, v244 in v_u_69 do
							v244.BackgroundColor3 = v232
							v244.BackgroundTransparency = v243 <= v133 and 0.05 or 0.8
						end
					end
					local v245
					if v147 then
						if v121 and v121.reloadSlow ~= nil then
							v245 = v121.reloadSlow == true
						else
							v245 = v114:GetAttribute("ReloadSlow") == true
						end
					else
						v245 = v147
					end
					local v246
					if v147 then
						v246 = (not v121 or v121.reloadCancel == nil) and true or v121.reloadCancel == true
					else
						v246 = v147
					end
					if v147 then
						if not v_u_80 then
							v_u_79 = v_u_1.now()
						end
						local v247 = v114:GetAttribute("ReloadEndsAt")
						local v248 = type(v247) ~= "number" and 0 or v247
						if v121 then
							v121 = v121.reloadProgress
						end
						local v249 = type(v121) ~= "number" and -1 or v121
						if v249 < 0 and v_u_79 < v248 then
							local v250 = (v_u_1.now() - v_u_79) / (v248 - v_u_79)
							v249 = math.clamp(v250, 0, 1)
						end
						v_u_70.frame.Visible = true
						v_u_70.set(math.max(0, v249), true)
						if v_u_75 then
							local v251 = v_u_75
							local v252
							if v245 then
								v252 = v_u_8.danger
							else
								v252 = v_u_8.accent
							end
							v251.BackgroundColor3 = v252
						end
					else
						v_u_70.frame.Visible = false
					end
					v_u_80 = v147
					if v148 then
						v_u_71.Visible = true
						v_u_72.Text = v_u_13.jammedText(v_u_93)
						v_u_72.TextColor3 = v_u_8.danger
					elseif v147 then
						v_u_71.Visible = not v_u_93
						v_u_72.Text = v245 and "RELOADING  SLOW" or "RELOADING"
						local v253 = v_u_72
						local v254
						if v245 then
							v254 = v_u_8.danger
						else
							v254 = v_u_8.accent
						end
						v253.TextColor3 = v254
					elseif v141 <= 0 then
						v_u_71.Visible = true
						v_u_72.Text = v145 > 0 and "RELOAD" or (v_u_93 and "EMPTY" or "NO AMMO")
						local v255 = v_u_14 * 6
						local v256 = math.sin(v255) * 0.5 + 0.5
						v_u_72.TextColor3 = v_u_8.danger:Lerp(v_u_8.text, v256 * 0.3)
					elseif v231 <= 0.25 and v145 > 0 then
						v_u_71.Visible = true
						v_u_72.Text = v_u_93 and "LOW" or "LOW AMMO"
						v_u_72.TextColor3 = v_u_8.accent
					else
						v_u_71.Visible = false
					end
					local v257 = v_u_73
					local v258 = v_u_13.hintShown(v_u_71.Visible, v147, v246, v148, v145)
					if v258 then
						if v_u_73:GetAttribute("ForceHidden") == true or v_u_6.hint("reload") == "" then
							v258 = false
						else
							v258 = not v_u_93
						end
					end
					v257.Visible = v258
					local v259 = v_u_74
					local v260 = v_u_73.Visible
					if v260 then
						if v147 then
							v147 = not v148
						end
					else
						v147 = v260
					end
					v259.Visible = v147
				end
			else
				v_u_15.Visible = not v116
				if v_u_76 ~= "|fists" then
					v_u_76 = "|fists"
					v_u_6.setText(v_u_18, "FISTS")
					for _, v261 in v_u_69 do
						v261:Destroy()
					end
					table.clear(v_u_69)
				end
				v_u_39.Visible = false
				v_u_68.Visible = false
				v_u_70.frame.Visible = false
				v_u_71.Visible = false
				v_u_24.Visible = false
				v_u_27.Visible = false
				v_u_32.Visible = false
				v_u_36.Visible = true
				local v262 = v_u_31 and "PUNCH  MORE \226\128\186 MELEE" or "PUNCH"
				if v_u_37.Text ~= v262 then
					v_u_37.Text = v262
				end
				local v263 = not v_u_31
				if v263 then
					v263 = v_u_6.hint("melee") ~= ""
				end
				if v_u_38:GetAttribute("ForceHidden") == v263 then
					v_u_38:SetAttribute("ForceHidden", not v263)
				end
				if v_u_38.Visible ~= v263 then
					v_u_38.Visible = v263
				end
				return
			end
		else
			v_u_15.Visible = false
			return
		end
	end
	function v9.destroy() -- name: destroy
		-- upvalues: (copy) v_u_15
		v_u_15:Destroy()
	end
	local v264, v_u_265 = pcall(function()
		-- upvalues: (copy) p_u_5, (copy) v_u_15
		return p_u_5.cctx.lib.HUDTally.new(p_u_5, v_u_15)
	end)
	if v264 and type(v_u_265) == "table" then
		local v_u_266 = v9.update
		local v_u_267 = v9.layout
		local v_u_268 = v9.destroy
		function v9.update(p269) -- name: update
			-- upvalues: (copy) v_u_266, (copy) v_u_265, (ref) v_u_10, (copy) v_u_15
			v_u_266(p269)
			local v270 = v_u_265.update
			local v271 = v_u_10
			local v272 = v_u_15.Visible
			pcall(v270, p269, v271, v272)
		end
		function v9.layout(p273) -- name: layout
			-- upvalues: (copy) v_u_267, (copy) v_u_265, (copy) v_u_7
			v_u_267(p273)
			local v274 = v_u_265.layout
			local v275
			if p273 then
				v275 = v_u_7.isPhone()
			else
				v275 = p273
			end
			pcall(v274, p273, v275)
		end
		function v9.destroy() -- name: destroy
			-- upvalues: (copy) v_u_265, (copy) v_u_268
			local v276 = v_u_265.destroy
			pcall(v276)
			v_u_268()
		end
		v9.tally = v_u_265
	elseif not v264 then
		v_u_71("[HUDWeapon] the TALLY chip did not start: " .. tostring(v_u_265))
	end
	return v9
end
return v2