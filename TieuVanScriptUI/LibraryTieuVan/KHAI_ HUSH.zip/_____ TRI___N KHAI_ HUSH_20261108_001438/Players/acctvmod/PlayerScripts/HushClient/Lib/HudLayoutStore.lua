-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HudLayoutStore

local v_u_1 = {
	["ELEMENTS"] = {
		{
			["name"] = "aim",
			["root"] = "pad",
			["kind"] = "stick",
			["label"] = "AIM STICK"
		},
		{
			["name"] = "move",
			["root"] = "pad",
			["kind"] = "stick",
			["label"] = "MOVE STICK"
		},
		{
			["name"] = "fire",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "FIRE"
		},
		{
			["name"] = "reload",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "RELOAD"
		},
		{
			["name"] = "swap",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "SWAP"
		},
		{
			["name"] = "interact",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "USE"
		},
		{
			["name"] = "throwCancel",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "CANCEL"
		},
		{
			["name"] = "inventory",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "BAG"
		},
		{
			["name"] = "map",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "MAP"
		},
		{
			["name"] = "menu",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "MENU"
		},
		{
			["name"] = "sneak",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "SNEAK"
		},
		{
			["name"] = "more",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "MORE"
		},
		{
			["name"] = "flashlight",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "LIGHT",
			["tray"] = nil,
			["tray"] = { 0, 0 }
		},
		{
			["name"] = "ping",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "PING",
			["tray"] = nil,
			["tray"] = { 1, 0 }
		},
		{
			["name"] = "melee",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "MELEE",
			["tray"] = nil,
			["tray"] = { 2, 0 }
		},
		{
			["name"] = "throw",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "THROW",
			["tray"] = nil,
			["tray"] = { 3, 0 }
		},
		{
			["name"] = "extracts",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "EXITS",
			["tray"] = nil,
			["tray"] = { 4, 0 }
		},
		{
			["name"] = "chat",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "CHAT",
			["tray"] = nil,
			["tray"] = { 5, 0 }
		},
		{
			["name"] = "quick1",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "1",
			["tray"] = nil,
			["tray"] = { 0, 1 }
		},
		{
			["name"] = "quick2",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "2",
			["tray"] = nil,
			["tray"] = { 1, 1 }
		},
		{
			["name"] = "quick3",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "3",
			["tray"] = nil,
			["tray"] = { 2, 1 }
		},
		{
			["name"] = "quick4",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "4",
			["tray"] = nil,
			["tray"] = { 3, 1 }
		},
		{
			["name"] = "camLeft",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "<",
			["tray"] = nil,
			["tray"] = { 4, 1 }
		},
		{
			["name"] = "camRight",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = ">",
			["tray"] = nil,
			["tray"] = { 5, 1 }
		},
		{
			["name"] = "ads",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "ADS"
		},
		{
			["name"] = "viewToggle",
			["root"] = "pad",
			["kind"] = "button",
			["label"] = "VIEW"
		},
		{
			["name"] = "Clock",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "CLOCK",
			["phoneOnly"] = true
		},
		{
			["name"] = "Weapon",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "WEAPON",
			["phoneOnly"] = true
		},
		{
			["name"] = "Squad",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "SQUAD"
		},
		{
			["name"] = "Noise",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "NOISE",
			["phoneOnly"] = true
		},
		{
			["name"] = "Tasks",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "TASKS",
			["phoneOnly"] = true
		},
		{
			["name"] = "Extracts",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "EXITS LIST",
			["phoneOnly"] = true
		},
		{
			["name"] = "Notices",
			["root"] = "hud",
			["kind"] = "block",
			["label"] = "NOTICES",
			["phoneOnly"] = true
		}
	},
	["BY_NAME"] = {}
}
for v2, v3 in v_u_1.ELEMENTS do
	v3.index = v2
	v_u_1.BY_NAME[v3.name] = v3
end
v_u_1.SZ_MUL = { 0.8, 1, 1.25 }
v_u_1.MAX_LEN = 900
v_u_1.KEY = {
	["P"] = "hudLayoutP",
	["T"] = "hudLayoutT"
}
local v_u_4 = {}
for _, v5 in v_u_1.ELEMENTS do
	if v5.root ~= "hud" then
		continue
	end
	local v6 = v5.name
	table.insert(v_u_4, v6)
end
function v_u_1.classFor(p7) -- name: classFor
	local v8 = p7.X
	local v9 = p7.Y
	return math.min(v8, v9) < 600 and "P" or "T"
end
function v_u_1.clean(p10, p11, p12, p13) -- name: clean
	-- upvalues: (copy) v_u_1
	local v14
	if type(p10) == "string" then
		v14 = v_u_1.BY_NAME[p10]
	else
		v14 = nil
	end
	if not v14 then
		return nil
	end
	if type(p11) ~= "number" or (type(p12) ~= "number" or (p11 ~= p11 or (p12 ~= p12 or (p11 == (1 / 0) or (p11 == (-1 / 0) or (p12 == (1 / 0) or p12 == (-1 / 0))))))) then
		return nil
	end
	local v15
	if v14.kind == "block" or (type(p13) ~= "number" or p13 ~= p13) then
		v15 = 2
	else
		local v16 = p13 + 0.5
		local v17 = math.floor(v16)
		v15 = math.clamp(v17, 1, 3)
	end
	local v18 = {}
	local v19 = math.clamp(p11, 0, 1) * 1000 + 0.5
	v18.fx = math.floor(v19) / 1000
	local v20 = math.clamp(p12, 0, 1) * 1000 + 0.5
	v18.fy = math.floor(v20) / 1000
	v18.sz = v15
	return v18
end
function v_u_1.encode(p21) -- name: encode
	-- upvalues: (copy) v_u_1
	if type(p21) ~= "table" then
		return ""
	end
	local v22 = {}
	for _, v23 in v_u_1.ELEMENTS do
		local v24 = p21[v23.name]
		if type(v24) ~= "table" then
			continue
		end
		local v25 = v_u_1.clean(v23.name, v24.fx, v24.fy, v24.sz)
		if not v25 then
			continue
		end
		local v26 = v23.name
		local v27 = v25.fx * 1000
		local v28 = string.format
		local v29 = v27 + 0.5
		local v30 = math.floor(v29)
		local v31 = v28("%04d", (math.clamp(v30, 0, 1000)))
		local v32 = v25.fy * 1000
		local v33 = string.format
		local v34 = v32 + 0.5
		local v35 = math.floor(v34)
		local v36 = v33("%04d", (math.clamp(v35, 0, 1000)))
		local v37 = v25.sz
		local v38 = v26 .. "_" .. v31 .. "_" .. v36 .. "_" .. tostring(v37)
		table.insert(v22, v38)
	end
	local v39 = table.concat(v22, ",")
	if #v39 > v_u_1.MAX_LEN then
		local v40 = v_u_1.MAX_LEN
		local v41 = string.sub(v39, 1, v40)
		v39 = string.match(v41, "^(.*),") or ""
	end
	return v39
end
function v_u_1.decode(p42) -- name: decode
	-- upvalues: (copy) v_u_1
	local v43 = {}
	if type(p42) ~= "string" or (p42 == "" or #p42 > v_u_1.MAX_LEN) then
		return v43
	end
	local v44 = 0
	for v45 in string.gmatch(p42, "[^,]+") do
		v44 = v44 + 1
		if v44 > 40 then
			break
		end
		local v46, v47, v48, v49 = string.match(v45, "^(%a%w*)_(%d%d%d%d)_(%d%d%d%d)_(%d)$")
		if not v46 then
			continue
		end
		local v50 = tonumber(v47)
		local v51 = tonumber(v48)
		if v50 > 1000 or v51 > 1000 then
			continue
		end
		local v52 = v_u_1.clean(v46, v50 / 1000, v51 / 1000, (tonumber(v49)))
		if not v52 then
			continue
		end
		v43[v46] = v52
	end
	return v43
end
local v_u_53 = {
	["P"] = {},
	["T"] = {}
}
local v_u_54 = "P"
local v_u_55 = true
local v_u_56 = {}
local v_u_57 = 0
local v_u_58 = nil
local function v_u_63(p59) -- name: copyMap
	local v60 = {}
	for v61, v62 in p59 do
		v60[v61] = {
			["fx"] = v62.fx,
			["fy"] = v62.fy,
			["sz"] = v62.sz
		}
	end
	return v60
end
local function v_u_70() -- name: syncBridge
	-- upvalues: (ref) v_u_58, (ref) v_u_54, (copy) v_u_53, (copy) v_u_4, (ref) v_u_55
	local v64 = v_u_58
	if v64 then
		local v65
		if v_u_54 == "T" then
			v65 = v_u_53.T
		else
			v65 = v_u_53.P
		end
		for _, v66 in v_u_4 do
			local v67
			if v_u_55 then
				v67 = v65[v66]
			else
				v67 = nil
			end
			local v68 = v64.setOverride
			local v69 = v67 and {
				["fx"] = v67.fx,
				["fy"] = v67.fy
			} or nil
			pcall(v68, v66, v69)
		end
	end
end
function v_u_1.onChanged(p71) -- name: onChanged
	-- upvalues: (ref) v_u_57, (copy) v_u_56
	v_u_57 = v_u_57 + 1
	local v_u_72 = v_u_57
	v_u_56[v_u_72] = p71
	return function()
		-- upvalues: (ref) v_u_56, (copy) v_u_72
		v_u_56[v_u_72] = nil
	end
end
local v_u_73 = false
function v_u_1.watch(p_u_74) -- name: watch
	-- upvalues: (ref) v_u_73, (copy) v_u_1
	if not v_u_73 and type(p_u_74) == "table" then
		local v75 = p_u_74.watchFlag
		if type(v75) == "function" then
			v_u_73 = true
			task.spawn(function()
				-- upvalues: (copy) p_u_74, (ref) v_u_1
				local v76 = p_u_74.watchFlag
				local function v78(p77)
					-- upvalues: (ref) v_u_1
					v_u_1.setEnabled(p77 ~= false)
				end
				pcall(v76, "TouchLayoutEdit", v78)
			end)
			return
		end
	end
end
function v_u_1.attach(p79) -- name: attach
	-- upvalues: (ref) v_u_58, (copy) v_u_70
	if type(p79) == "table" then
		local v80 = p79.setOverride
		if type(v80) == "function" and p79 ~= v_u_58 then
			v_u_58 = p79
			v_u_70()
		end
	end
end
function v_u_1.activeClass() -- name: activeClass
	-- upvalues: (ref) v_u_54
	return v_u_54
end
function v_u_1.setClass(p81) -- name: setClass
	-- upvalues: (ref) v_u_54, (copy) v_u_70, (copy) v_u_56
	local v82 = p81 == "T" and "T" or "P"
	if v82 ~= v_u_54 then
		v_u_54 = v82
		v_u_70()
		for _, v83 in table.clone(v_u_56) do
			pcall(v83)
		end
	end
end
function v_u_1.enabled() -- name: enabled
	-- upvalues: (ref) v_u_55
	return v_u_55
end
function v_u_1.setEnabled(p84) -- name: setEnabled
	-- upvalues: (ref) v_u_55, (copy) v_u_70, (copy) v_u_56
	local v85 = p84 ~= false
	if v85 ~= v_u_55 then
		v_u_55 = v85
		v_u_70()
		for _, v86 in table.clone(v_u_56) do
			pcall(v86)
		end
	end
end
function v_u_1.load(p87, p88) -- name: load
	-- upvalues: (copy) v_u_53, (copy) v_u_1, (copy) v_u_70, (copy) v_u_56
	if p87 == "T" then
		v_u_53.T = v_u_1.decode(p88)
	else
		v_u_53.P = v_u_1.decode(p88)
	end
	v_u_70()
	for _, v89 in table.clone(v_u_56) do
		pcall(v89)
	end
end
function v_u_1.map(p90) -- name: map
	-- upvalues: (ref) v_u_54, (copy) v_u_63, (copy) v_u_53
	local v91 = v_u_63
	local v92
	if (p90 or v_u_54) == "T" then
		v92 = v_u_53.T
	else
		v92 = v_u_53.P
	end
	return v91(v92)
end
function v_u_1.active() -- name: active
	-- upvalues: (ref) v_u_55, (copy) v_u_63, (ref) v_u_54, (copy) v_u_53
	if not v_u_55 then
		return {}
	end
	local v93 = v_u_63
	local v94
	if v_u_54 == "T" then
		v94 = v_u_53.T
	else
		v94 = v_u_53.P
	end
	return v93(v94)
end
function v_u_1.get(p95) -- name: get
	-- upvalues: (ref) v_u_55, (ref) v_u_54, (copy) v_u_53
	if not v_u_55 then
		return nil
	end
	local v96
	if v_u_54 == "T" then
		v96 = v_u_53.T
	else
		v96 = v_u_53.P
	end
	local v97 = v96[p95]
	return v97 and {
		["fx"] = v97.fx,
		["fy"] = v97.fy,
		["sz"] = v97.sz
	} or nil
end
function v_u_1.raw(p98) -- name: raw
	-- upvalues: (ref) v_u_54, (copy) v_u_53
	local v99
	if v_u_54 == "T" then
		v99 = v_u_53.T
	else
		v99 = v_u_53.P
	end
	local v100 = v99[p98]
	return v100 and {
		["fx"] = v100.fx,
		["fy"] = v100.fy,
		["sz"] = v100.sz
	} or nil
end
function v_u_1.set(p101, p102, p103, p104) -- name: set
	-- upvalues: (copy) v_u_1, (ref) v_u_54, (copy) v_u_53, (copy) v_u_70, (copy) v_u_56
	local v105 = v_u_1.clean(p101, p102, p103, p104)
	if not v105 then
		return false
	end
	local v106
	if v_u_54 == "T" then
		v106 = v_u_53.T
	else
		v106 = v_u_53.P
	end
	local v107 = v106[p101]
	if v107 and (v107.fx == v105.fx and (v107.fy == v105.fy and v107.sz == v105.sz)) then
		return true
	end
	v106[p101] = v105
	v_u_70()
	for _, v108 in table.clone(v_u_56) do
		pcall(v108)
	end
	return true
end
function v_u_1.reset(p109) -- name: reset
	-- upvalues: (ref) v_u_54, (copy) v_u_53, (copy) v_u_70, (copy) v_u_56
	local v110
	if v_u_54 == "T" then
		v110 = v_u_53.T
	else
		v110 = v_u_53.P
	end
	if v110[p109] ~= nil then
		v110[p109] = nil
		v_u_70()
		for _, v111 in table.clone(v_u_56) do
			pcall(v111)
		end
	end
end
function v_u_1.resetAll() -- name: resetAll
	-- upvalues: (ref) v_u_54, (copy) v_u_53, (copy) v_u_70, (copy) v_u_56
	local v112
	if v_u_54 == "T" then
		v112 = v_u_53.T
	else
		v112 = v_u_53.P
	end
	if next(v112) ~= nil then
		table.clear(v112)
		v_u_70()
		for _, v113 in table.clone(v_u_56) do
			pcall(v113)
		end
	end
end
function v_u_1.snapshot() -- name: snapshot
	-- upvalues: (copy) v_u_63, (copy) v_u_53
	return {
		["P"] = v_u_63(v_u_53.P),
		["T"] = v_u_63(v_u_53.T)
	}
end
function v_u_1.restore(p114) -- name: restore
	-- upvalues: (copy) v_u_53, (copy) v_u_63, (copy) v_u_70, (copy) v_u_56
	if type(p114) == "table" then
		local v115 = v_u_53
		local v116 = v_u_63
		local v117 = p114.P
		v115.P = v116(type(v117) ~= "table" and {} or p114.P)
		local v118 = v_u_53
		local v119 = v_u_63
		local v120 = p114.T
		v118.T = v119(type(v120) ~= "table" and {} or p114.T)
		v_u_70()
		for _, v121 in table.clone(v_u_56) do
			pcall(v121)
		end
	end
end
function v_u_1.textOf(p122) -- name: textOf
	-- upvalues: (copy) v_u_1, (copy) v_u_53
	local v123 = v_u_1.encode
	local v124
	if p122 == "T" then
		v124 = v_u_53.T
	else
		v124 = v_u_53.P
	end
	return v123(v124)
end
function v_u_1.pinned(p125) -- name: pinned
	-- upvalues: (copy) v_u_1
	local v126 = v_u_1.BY_NAME[p125]
	local v127
	if v126 == nil or v126.tray == nil then
		v127 = false
	else
		v127 = v_u_1.get(p125) ~= nil
	end
	return v127
end
return v_u_1