-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / LobbyNeon

local v_u_1 = {}
v_u_1.__index = v_u_1
v_u_1.POLL = 0.5
v_u_1.MAX_TICKS = 3
local function v_u_17(p2, p3) -- name: collect
	local v4 = {}
	for v5 = 1, #p3.GROUPS do
		v4[v5] = {}
	end
	local v6 = 0
	for _, v7 in p2:GetDescendants() do
		if v7:IsA("PointLight") then
			local v8 = v7.Parent
			if v8 then
				v8 = v7.Parent:GetAttribute("Group")
			end
			if v8 == nil then
				continue
			end
			local v9 = p3.indexOf(v8)
			if v9 then
				local v10 = v4[v9]
				local v11 = {
					["inst"] = nil,
					["base"] = nil,
					["kind"] = "light",
					["inst"] = v7,
					["base"] = v7.Brightness
				}
				table.insert(v10, v11)
			else
				v6 = v6 + 1
			end
		else
			if not v7:IsA("BasePart") then
				continue
			end
			local v12 = v7:GetAttribute("Group")
			if v12 == nil then
				continue
			end
			local v13 = p3.indexOf(v12)
			local v14 = v7:FindFirstChildOfClass("SurfaceAppearance")
			if v13 and v14 then
				local v15 = v4[v13]
				local v16 = {
					["inst"] = nil,
					["base"] = nil,
					["kind"] = "glow",
					["inst"] = v14,
					["base"] = v14.EmissiveStrength
				}
				table.insert(v15, v16)
			else
				if v13 then
					continue
				end
				v6 = v6 + 1
			end
		end
	end
	return v4, v6
end
function v_u_1.new(p18, p19) -- name: new
	-- upvalues: (copy) v_u_17, (copy) v_u_1
	local v20 = p19.plan
	local v21, v22 = v_u_17(p18, v20)
	local v23 = v_u_1
	local v24 = setmetatable({}, v23)
	v24.P = v20
	v24.deps = p19
	v24.groups = v21
	v24.unknown = v22
	v24.plan = v20.new()
	v24.guard = v20.guardNew()
	v24.levels = {}
	v24.last = {}
	v24.every = p19.every == 2 and 2 or 1
	v24.acc = 0
	v24.tick = 0
	v24.mix = 0
	v24.reduced = false
	v24.flicker = true
	v24.pollAt = 0
	v24.writes = 0
	v24.alive = true
	return v24
end
function v_u_1._poll(p25) -- name: _poll
	local v26 = p25.deps
	local v27 = v26.flashingOff
	local v28, v29 = pcall(v27)
	if v28 then
		v28 = v29 == true
	end
	p25.reduced = v28
	local v30 = v26.flickerOn
	local v31, v32 = pcall(v30)
	p25.flicker = not v31 or v32 ~= false
end
function v_u_1._tick(p33) -- name: _tick
	local v34 = p33.P
	p33.mix = v34.mixStep(p33.mix, p33.reduced, v34.STEP * p33.every)
	local v35 = v34.frame(p33.plan, p33.tick, p33.mix, p33.levels)
	if not p33.flicker then
		for v36 = 1, #v34.GROUPS do
			v35[v36] = 1
		end
	end
	v34.guardStep(p33.guard, p33.tick, v35)
	for v37 = 1, #v34.GROUPS do
		local v38 = v35[v37]
		if not v34.needsWrite(p33.last[v37], v38) then
			continue
		end
		p33.last[v37] = v38
		for _, v39 in p33.groups[v37] do
			if v39.kind == "glow" then
				v39.inst.EmissiveStrength = v39.base * v38
			else
				v39.inst.Brightness = v39.base * v38
			end
			p33.writes = p33.writes + 1
		end
	end
end
function v_u_1.step(p40, p41) -- name: step
	-- upvalues: (copy) v_u_1
	if p40.alive then
		p40.pollAt = p40.pollAt - p41
		if p40.pollAt <= 0 then
			p40.pollAt = v_u_1.POLL
			p40:_poll()
		end
		p40.acc = p40.acc + p41
		local v42 = p40.P
		local v43 = 0
		while p40.acc >= v42.STEP and v43 < v_u_1.MAX_TICKS do
			p40.acc = p40.acc - v42.STEP
			p40.tick = p40.tick + 1
			v43 = v43 + 1
			if p40.tick % p40.every ~= 0 then
				continue
			end
			p40:_tick()
		end
		if p40.acc >= v42.STEP then
			p40.acc = 0
		end
	end
end
function v_u_1.state(p44) -- name: state
	local v45 = 0
	for _, v46 in p44.groups do
		v45 = v45 + #v46
	end
	return {
		["groups"] = #p44.groups,
		["members"] = v45,
		["unknown"] = p44.unknown,
		["writes"] = p44.writes,
		["tick"] = p44.tick,
		["reduced"] = p44.reduced,
		["mix"] = p44.mix,
		["enabled"] = p44.flicker,
		["alive"] = p44.alive,
		["every"] = p44.every
	}
end
function v_u_1.destroy(p47) -- name: destroy
	if p47.alive then
		p47.alive = false
		for _, v48 in p47.groups do
			for _, v_u_49 in v48 do
				pcall(function()
					-- upvalues: (copy) v_u_49
					if v_u_49.kind == "glow" then
						v_u_49.inst.EmissiveStrength = v_u_49.base
					else
						v_u_49.inst.Brightness = v_u_49.base
					end
				end)
			end
		end
		p47.groups = {}
	end
end
return v_u_1