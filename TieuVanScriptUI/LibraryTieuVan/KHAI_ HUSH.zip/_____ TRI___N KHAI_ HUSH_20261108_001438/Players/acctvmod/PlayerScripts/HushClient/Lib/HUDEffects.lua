-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDEffects

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_5 = {
	["timeLeft"] = function(p2, p3) -- name: timeLeft
		if type(p2) ~= "number" or (p2 ~= p2 or p2 <= 0) then
			return 0
		end
		local v4 = p2 - p3
		return math.max(0, v4)
	end
}
local v_u_6 = {
	["Bandage"] = "Bandaging",
	["Revive"] = "Helping up",
	["Search"] = "Searching",
	["Use"] = "Using",
	["Extract"] = "Extracting",
	["Heal"] = "Healing",
	["Splint"] = "Applying splint",
	["Inject"] = "Taking",
	["Vault"] = "Vaulting",
	["Roll"] = "Rolling up...",
	["Unroll"] = "Unrolling...",
	["VehEnter"] = "Getting in...",
	["VehExit"] = "Getting out...",
	["VehExitFast"] = "Bailing out...",
	["VehAbort"] = "Backing out...",
	["Eject"] = "Thrown out"
}
function v_u_5.new(p_u_7) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_6
	local v_u_8 = p_u_7.UI
	local v_u_9 = p_u_7.cctx.shared.HudWhy
	local v_u_10 = v_u_9.infectionSub(v_u_9.infectionDelay(p_u_7.cctx.shared.Items))
	local v_u_11 = p_u_7.Theme
	local v_u_12 = v_u_11.color
	local v13 = {}
	local v_u_14 = nil
	local v_u_15 = p_u_7.fx
	local v_u_16 = nil
	local function v_u_23() -- name: viewOffset
		-- upvalues: (ref) v_u_16, (copy) p_u_7
		if v_u_16 == nil then
			local function v17()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.lib.ViewportSpace
			end
			local v18, v19 = pcall(v17)
			if not v18 or type(v19) ~= "table" then
				v19 = false
			end
			v_u_16 = v19
		end
		if v_u_16 then
			local v20 = v_u_16.offset
			local v21, v22 = pcall(v20)
			if v21 and typeof(v22) == "Vector2" then
				return v22
			end
		end
		return Vector2.zero
	end
	local function v_u_37(p24) -- name: project
		-- upvalues: (copy) v_u_8, (copy) v_u_23, (copy) v_u_11
		local v25, v26, v27 = v_u_8.worldToScreen(p24)
		local v28 = v_u_23()
		if v28.X ~= 0 or v28.Y ~= 0 then
			local v29 = Vector2.new
			local v30 = v25.X
			local v31 = v28.X
			local v32 = v_u_11.uiScale()
			local v33 = v30 + v31 / math.max(v32, 0.01)
			local v34 = v25.Y
			local v35 = v28.Y
			local v36 = v_u_11.uiScale()
			v25 = v29(v33, v34 + v35 / math.max(v36, 0.01))
		end
		return v25, v26, v27
	end
	v13._project = v_u_37
	local function v46(p38, p39, p40) -- name: makeEdges
		-- upvalues: (copy) v_u_8, (copy) v_u_15
		local v41 = v_u_8.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 1,
			["Name"] = p38,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_15)
		local v42 = {}
		for v43, v44 in {
			{ UDim2.fromScale(0, 0), UDim2.fromScale(1, p40), 90 },
			{ UDim2.fromScale(0, 1 - p40), UDim2.fromScale(1, p40), -90 },
			{ UDim2.fromScale(0, 0), UDim2.fromScale(p40 * 0.7, 1), 0 },
			{ UDim2.fromScale(1 - p40 * 0.7, 0), UDim2.fromScale(p40 * 0.7, 1), 180 }
		} do
			local v45 = v_u_8.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 1,
				["Name"] = "E" .. v43,
				["BackgroundColor3"] = p39,
				["Position"] = v44[1],
				["Size"] = v44[2]
			}, v41)
			v_u_8.new("UIGradient", {
				["Rotation"] = v44[3],
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.45, 0.72), NumberSequenceKeypoint.new(1, 1) })
			}, v45)
			v42[v43] = v45
		end
		return {
			["frames"] = nil,
			["color"] = nil,
			["last"] = 1,
			["frames"] = v42,
			["color"] = p39
		}
	end
	local v_u_47 = v46("LowHp", Color3.fromHex("#6E0F0A"), 0.22)
	local v_u_48 = v46("Infection", Color3.fromHex("#4E7A1E"), 0.18)
	local v_u_49 = v46("HitFlash", Color3.fromHex("#8A1A12"), 0.14)
	local v_u_50 = 0
	local v_u_51 = v_u_8.new("Frame", {
		["Name"] = "NoiseRing",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(10, 10)
	}, v_u_15)
	v_u_8.new("UICorner", {
		["CornerRadius"] = UDim.new(1, 0)
	}, v_u_51)
	local v_u_52 = v_u_8.stroke(v_u_51, v_u_12.text, 1.5, 1)
	local v_u_53 = v_u_8.new("Frame", {
		["Name"] = "NoiseEcho",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(10, 10)
	}, v_u_15)
	v_u_8.new("UICorner", {
		["CornerRadius"] = UDim.new(1, 0)
	}, v_u_53)
	local v_u_54 = v_u_8.stroke(v_u_53, v_u_12.text, 1, 1)
	local v_u_55 = 99
	local v_u_56 = 0
	local v_u_57 = false
	local v_u_58 = 0
	local v_u_59 = 0
	local function v_u_72() -- name: hearScale
		-- upvalues: (copy) p_u_7
		local v60 = p_u_7.raid
		local v61
		if v60 then
			v61 = v60:GetAttribute("Difficulty")
		else
			v61 = v60
		end
		local v62
		if v60 then
			v62 = v60:GetAttribute("Weather")
		else
			v62 = v60
		end
		local function v63()
			-- upvalues: (ref) p_u_7
			return p_u_7.cctx.shared.Difficulty
		end
		local v64, v65 = pcall(v63)
		if not (v64 and v65) then
			return 1
		end
		if v60 then
			v60 = v60:GetAttribute("Map")
		end
		local v66 = v65.stepRadius
		local v67 = type(v61) ~= "string" and "Normal" or v61
		local v68 = "sprint"
		if type(v62) ~= "string" then
			v62 = nil
		end
		local v69 = 1
		if type(v60) ~= "string" then
			v60 = nil
		end
		local v70, v71 = pcall(v66, v67, v68, v62, v69, v60)
		return (not v70 or (type(v71) ~= "number" or v71 <= 0)) and 1 or v71 / 18
	end
	local v_u_73 = v_u_8.new("Frame", {
		["Name"] = "HearCues",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_15)
	local v_u_74 = {}
	local v_u_75 = 0
	local function v_u_94(p76, p77) -- name: cueAt
		-- upvalues: (copy) v_u_74, (copy) v_u_15, (copy) v_u_11, (copy) v_u_37, (copy) v_u_8, (copy) v_u_12, (copy) v_u_73
		if #v_u_74 >= 4 then
			return
		else
			local v78 = v_u_15.AbsoluteSize
			local v79 = v_u_11.uiScale()
			local v80 = v78 / math.max(v79, 0.01)
			if v80.X < 50 or v80.Y < 50 then
				return
			else
				local v81, _, v82 = v_u_37(p76)
				local v83, v84, v85 = v_u_8.edgeClamp(v81, v82, 14, 14, v80.X - 14, v80.Y - 14)
				if not v85 then
					local v86 = v_u_8.new
					local v87 = {
						["Name"] = "Cue",
						["AnchorPoint"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["Rotation"] = nil,
						["ZIndex"] = 1,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["BackgroundColor3"] = v_u_12.infection or Color3.fromHex("#8FD14F"),
						["Position"] = UDim2.fromOffset(v83.X, v83.Y),
						["Size"] = UDim2.fromOffset(240, 34)
					}
					local v88 = v84.X
					local v89 = -v84.Y
					local v90 = math.atan2(v88, v89)
					v87.Rotation = math.deg(v90)
					local v91 = v86("Frame", v87, v_u_73)
					v_u_8.new("UIGradient", {
						["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.35), NumberSequenceKeypoint.new(1, 1) })
					}, v91)
					local v92 = v_u_74
					local v93 = {
						["f"] = nil,
						["t"] = 0,
						["a"] = nil,
						["f"] = v91,
						["a"] = math.clamp(p77, 0, 1) * 0.3 + 0.32
					}
					table.insert(v92, v93)
				end
			end
		end
	end
	local function v_u_109(p95, p96) -- name: stepCues
		-- upvalues: (copy) p_u_7, (ref) v_u_75, (copy) v_u_94, (copy) v_u_74
		local v97 = p_u_7.cctx and p_u_7.cctx.controllers
		if v97 then
			v97 = p_u_7.cctx.controllers.Audio
		end
		if p96 and (v97 and v97.hearCues) then
			local v98 = v97.hearCues
			local v99 = v_u_75
			local v100, v101, v102 = pcall(v98, v99)
			if v100 and type(v101) == "table" then
				for _, v103 in v101 do
					local v104 = v103.p
					if type(v104) ~= "number" or v103.p < 0.25 then
						continue
					end
					local v105 = v103.pos
					if typeof(v105) ~= "Vector3" then
						continue
					end
					v_u_94(v103.pos, v103.p)
				end
				if type(v102) ~= "number" then
					v102 = v_u_75
				end
				v_u_75 = v102
			end
		end
		for v106 = #v_u_74, 1, -1 do
			local v107 = v_u_74[v106]
			v107.t = v107.t + p95
			if v107.t >= 1.4 or not p96 then
				v107.f:Destroy()
				table.remove(v_u_74, v106)
			else
				local v108
				if v107.t < 0.15 then
					v108 = v107.t / 0.15
				else
					v108 = 1 - (v107.t - 0.15) / 1.25
				end
				v107.f.BackgroundTransparency = 1 - v107.a * math.clamp(v108, 0, 1)
			end
		end
	end
	function v13._cues()
		-- upvalues: (copy) v_u_74
		return #v_u_74
	end
	local v_u_110 = {}
	local function v_u_134(p111, p112) -- name: hitMarker
		-- upvalues: (copy) v_u_37, (copy) v_u_8, (copy) p_u_7, (copy) v_u_12, (copy) v_u_15, (copy) v_u_110
		local v113
		if p112 then
			local v114
			v113, v114 = v_u_37(p112)
			if not v114 then
				v113 = v_u_8.toDesign(game:GetService("UserInputService"):GetMouseLocation())
			end
		else
			local v115 = p_u_7.cctx.controllers.Input
			local v116 = v115 and v115.aimPoint
			if v116 then
				local v117 = select
				local v118 = v115.aimPoint
				v116 = v117(2, pcall(v118))
			end
			if typeof(v116) == "Vector3" then
				v113 = v_u_37(v116)
			else
				v113 = v_u_8.toDesign(game:GetService("UserInputService"):GetMouseLocation())
			end
		end
		local v119 = p111 == "kill"
		local v120 = p111 == "head"
		local v121
		if v119 then
			v121 = v_u_12.danger
		elseif v120 then
			v121 = v_u_12.accent
		else
			v121 = v_u_12.text
		end
		local v122 = v119 and 30 or 22
		local v123 = v_u_8.new("Frame", {
			["Name"] = "Hit",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["ZIndex"] = 5,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v113.X, v113.Y),
			["Size"] = UDim2.fromOffset(v122, v122)
		}, v_u_15)
		local v124 = v119 and 3 or 2
		for v125 = 0, 3 do
			local v126 = v125 % 2 == 0
			local v127 = v125 < 2 and -1 or 1
			local v128 = v_u_8.new
			local v129 = "Frame"
			local v130 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["BackgroundColor3"] = v121,
				["AnchorPoint"] = Vector2.new(0.5, 0.5)
			}
			local v131
			if v126 then
				v131 = UDim2.fromScale(v127 * 0.33 + 0.5, 0.5)
			else
				v131 = UDim2.fromScale(0.5, v127 * 0.33 + 0.5)
			end
			v130.Position = v131
			local v132
			if v126 then
				v132 = UDim2.new(0.32, 0, 0, v124)
			else
				v132 = UDim2.new(0, v124, 0.32, 0)
			end
			v130.Size = v132
			v128(v129, v130, v123)
		end
		local v133 = v_u_110
		table.insert(v133, {
			["f"] = nil,
			["t"] = 0,
			["life"] = nil,
			["f"] = v123,
			["life"] = v119 and 0.45 or 0.28
		})
		v_u_8.sound(v119 and "kill" or (v120 and "hitHead" or "hit"), "tick")
	end
	local v_u_135 = {}
	local v_u_136 = (-1 / 0)
	local function v_u_150(p137) -- name: damageArrow
		-- upvalues: (ref) v_u_50, (ref) v_u_14, (copy) v_u_135, (copy) v_u_8, (copy) v_u_15, (copy) v_u_12
		v_u_50 = 0.55
		if p137 and v_u_14 then
			local v138 = v_u_14:FindFirstChild("HumanoidRootPart")
			if v138 then
				local v139 = v138.Position
				local v140 = p137.X - v139.X
				local v141 = p137.Z - v139.Z
				local v142 = Vector3.new(v140, 0, v141)
				if v142.Magnitude < 0.3 then
					return
				end
				for _, v143 in v_u_135 do
					local v144 = v143.dir.X - v139.X
					local v145 = v143.dir.Z - v139.Z
					local v146 = Vector3.new(v144, 0, v145)
					if v146.Magnitude <= 0.3 or v146.Unit:Dot(v142.Unit) <= 0.9 then
						continue
					end
					v143.t = 0
					v143.dir = p137
					return
				end
			end
			local v147 = #v_u_135 >= 4 and table.remove(v_u_135, 1)
			if v147 then
				v147.f:Destroy()
			end
			local v148 = v_u_8.new("Frame", {
				["Name"] = "DamageArrow",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["ZIndex"] = 4,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(46, 46)
			}, v_u_15)
			v_u_8.icon("chevronUp", {
				["parent"] = nil,
				["size"] = 46,
				["color"] = nil,
				["thickness"] = 4,
				["parent"] = v148,
				["color"] = v_u_12.danger
			})
			local v149 = v_u_135
			table.insert(v149, {
				["f"] = nil,
				["t"] = 0,
				["dir"] = nil,
				["f"] = v148,
				["dir"] = p137
			})
		end
	end
	local function v_u_166(p151) -- name: nearestZombie
		-- upvalues: (copy) p_u_7
		local v152 = p_u_7.cctx.controllers.ZombieRender
		if v152 then
			local v153 = v152.nearest
			if type(v153) == "function" then
				local v154 = v152.nearest
				local v155, v156 = pcall(v154, p151, 14)
				if v155 and typeof(v156) == "Vector3" then
					return v156
				end
				if v155 and type(v156) == "table" then
					local v157 = v156.pos
					if typeof(v157) == "Vector3" then
						return v156.pos
					end
				end
			end
		end
		local v158 = workspace:FindFirstChild("HushLocal")
		if v158 then
			v158 = v158:FindFirstChild("Zombies")
		end
		if not v158 then
			return nil
		end
		local v159 = 14
		local v160 = nil
		for _, v161 in v158:GetChildren() do
			if not v161:IsA("Model") or v161:GetAttribute("Dead") == true then
				continue
			end
			local v162 = v161.GetPivot
			local v163, v164 = pcall(v162, v161)
			if not v163 then
				continue
			end
			local v165 = (v164.Position - p151).Magnitude
			if v165 >= v159 then
				continue
			end
			v160 = v164.Position
			v159 = v165
		end
		return v160
	end
	local v_u_167 = v_u_8.new("Frame", {
		["Name"] = "Action",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -220),
		["Size"] = UDim2.fromOffset(260, 34)
	}, v_u_15)
	local v_u_168 = v_u_8.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_167,
		["color"] = v_u_12.text,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_169 = v_u_8.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_167,
		["color"] = v_u_12.text2,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_170 = v_u_8.progress({
		["parent"] = nil,
		["size"] = nil,
		["position"] = nil,
		["value"] = 0,
		["color"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_167,
		["size"] = UDim2.new(1, 0, 0, 3),
		["position"] = UDim2.fromOffset(0, 26),
		["color"] = v_u_12.accent
	})
	local v_u_171 = ""
	local v_u_172 = 0
	local v173, v_u_174 = pcall(function()
		-- upvalues: (copy) p_u_7, (copy) v_u_167
		return p_u_7.cctx.lib.HUDUseCancel.new(p_u_7, v_u_167)
	end)
	if not v173 then
		warn("[HUDEffects] HUDUseCancel failed:", v_u_174)
		v_u_174 = nil
	end
	local v_u_175 = {
		["shownAt"] = -1,
		["notice"] = nil,
		["timeLbl"] = nil,
		["noticeUntil"] = 0,
		["warned"] = -1,
		["beat"] = nil,
		["beatUntil"] = 0,
		["freshUntil"] = 0,
		["minAt"] = -1,
		["minMark"] = nil,
		["minuteBeats"] = 0
	}
	local function v_u_193(p176, p177) -- name: beatStart
		-- upvalues: (copy) v_u_175, (copy) p_u_7
		local v178 = v_u_175
		local v179 = v_u_175.beatUntil
		local v180 = os.clock() + p177
		v178.beatUntil = math.max(v179, v180)
		local v181 = p_u_7.cctx and p_u_7.cctx.controllers
		if v181 then
			v181 = p_u_7.cctx.controllers.Audio
		end
		if v181 and v181.heartbeatBoost then
			local v182 = v181.heartbeatBoost
			local v183 = v_u_175.beatUntil - os.clock()
			pcall(v182, p176, v183)
			v_u_175.beat = true
		else
			local v184 = v_u_175.beat
			if v184 then
				local v185 = v184.alive
				local v186, v187 = pcall(v185, v184)
				if v186 and v187 then
					return
				end
			end
			local v188 = p_u_7.cctx and p_u_7.cctx.controllers
			if v188 then
				v188 = p_u_7.cctx.controllers.Audio
			end
			if v188 and v188.play then
				local v189 = v188.play
				local v190, v191 = pcall(v189, "ev_heartbeat", {
					["volume"] = nil,
					["fadeIn"] = 0.4,
					["volume"] = p176
				})
				local v192 = v_u_175
				if not v190 then
					v191 = nil
				end
				v192.beat = v191
			end
		end
	end
	local function v_u_196(p194) -- name: hideNotice
		-- upvalues: (copy) v_u_175, (copy) v_u_8
		local v_u_195 = v_u_175.notice
		v_u_175.notice = nil
		v_u_175.timeLbl = nil
		if v_u_195 and v_u_195.Parent then
			if p194 then
				v_u_195:Destroy()
				return
			end
			v_u_8.fade(v_u_195, 1, 0.8, {
				["onDone"] = function() -- name: onDone
					-- upvalues: (copy) v_u_195
					v_u_195:Destroy()
				end
			})
		end
	end
	local function v_u_201(p197) -- name: showNotice
		-- upvalues: (copy) v_u_175, (copy) v_u_8, (copy) p_u_7, (copy) v_u_12, (copy) v_u_9, (copy) v_u_10
		local v198 = v_u_175.notice
		v_u_175.notice = nil
		v_u_175.timeLbl = nil
		if v198 and v198.Parent then
			v198:Destroy()
		end
		local v199 = v_u_8.new("Frame", {
			["Name"] = "InfectNotice",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.3),
			["Size"] = UDim2.fromOffset(560, 136)
		}, p_u_7.root)
		local v200 = v_u_8.new("Frame", {
			["Name"] = "Band",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v_u_12.bg,
			["Size"] = UDim2.fromScale(1, 1)
		}, v199)
		v_u_8.new("UIGradient", {
			["Transparency"] = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.22, 0),
				NumberSequenceKeypoint.new(0.78, 0),
				NumberSequenceKeypoint.new(1, 1)
			})
		}, v200)
		v_u_8.new("Frame", {
			["Name"] = "Rule",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["BackgroundColor3"] = v_u_12.infection,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0),
			["Size"] = UDim2.new(0.5, 0, 0, 2)
		}, v199)
		v_u_8.label({
			["parent"] = nil,
			["text"] = "INFECTED",
			["style"] = "h1",
			["textSize"] = 52,
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["zindex"] = 6,
			["parent"] = v199,
			["color"] = v_u_12.infection,
			["position"] = UDim2.fromOffset(0, 10),
			["size"] = UDim2.new(1, 0, 0, 58)
		})
		v_u_175.timeLbl = v_u_8.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "monoL",
			["textSize"] = 24,
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["zindex"] = 6,
			["parent"] = v199,
			["text"] = v_u_9.infectionUntil(p197),
			["color"] = v_u_12.text,
			["position"] = UDim2.fromOffset(0, 70),
			["size"] = UDim2.new(1, 0, 0, 28)
		})
		v_u_8.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["zindex"] = 6,
			["parent"] = v199,
			["text"] = v_u_10,
			["color"] = v_u_12.text2,
			["position"] = UDim2.fromOffset(0, 104),
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		v_u_8.fade(v199, 0, 0.35, {
			["from"] = 1
		})
		v_u_175.notice = v199
		v_u_175.noticeUntil = os.clock() + 6
	end
	local function v_u_223(p202, _) -- name: infectionTick
		-- upvalues: (copy) v_u_175, (copy) v_u_196, (ref) v_u_1, (ref) v_u_5, (copy) v_u_201, (copy) v_u_193, (copy) v_u_9, (copy) p_u_7, (copy) v_u_8, (copy) v_u_10
		if not p202 or p202:GetAttribute("Infected") ~= true then
			if v_u_175.notice then
				v_u_196(false)
			end
			if v_u_175.beat then
				local v203 = v_u_175.beat
				v_u_175.beat = nil
				v_u_175.beatUntil = 0
				if v203 ~= true and v203 then
					local v204 = v203.stop
					pcall(v204, v203, 1.2)
				end
			end
			v_u_175.freshUntil = 0
			return -1
		end
		local v205 = v_u_1.now()
		local v206 = p202:GetAttribute("InfectionEndsAt")
		local v207 = type(v206) ~= "number" and 0 or v206
		local v208 = v_u_5.timeLeft(v207, v205)
		local v209 = p202:GetAttribute("InfectedAt")
		local v210 = type(v209) ~= "number" and 0 or v209
		local v211 = os.clock()
		local v212 = p202:GetAttribute("Hp")
		local v213 = (type(v212) ~= "number" and 100 or v212) < 30 and true or p202:GetAttribute("Downed") == true
		if v210 ~= v_u_175.shownAt then
			v_u_175.shownAt = v210
			if v210 > 0 and (v205 - v210 < 10 and v207 > 0) then
				v_u_201(v208)
				v_u_175.freshUntil = v211 + 6
				if v208 <= 60 then
					v_u_175.warned = v210
				end
				if not v213 then
					v_u_193(0.8, 5)
				end
			end
		end
		if v_u_175.notice then
			if v_u_175.noticeUntil < v211 then
				v_u_196(false)
			elseif v_u_175.timeLbl then
				local v214 = v_u_9.infectionUntil(v208)
				if v_u_175.timeLbl.Text ~= v214 then
					v_u_175.timeLbl.Text = v214
				end
			end
		end
		if v207 > 0 and v210 > 0 then
			local v215 = v208 / 60
			local v216 = math.floor(v215)
			if v_u_175.minAt == v210 then
				if v216 < (v_u_175.minMark or v216) then
					v_u_175.minMark = v216
					if v208 > 90 and not v213 then
						v_u_193(0.3, 3)
						v_u_175.minuteBeats = (v_u_175.minuteBeats or 0) + 1
						local v217 = p_u_7.cctx
						if v217 then
							v217 = p_u_7.cctx.player
						end
						if v217 then
							v217:SetAttribute("InfectMinuteBeats", v_u_175.minuteBeats)
						end
					end
				end
			else
				v_u_175.minAt = v210
				v_u_175.minMark = v216
			end
		end
		if v207 > 0 and (v208 <= 60 and v208 > 0) then
			if v_u_175.warned ~= v210 and v208 > 45 then
				v_u_175.warned = v210
				local v218 = v_u_8.toast
				local v219 = v_u_10
				pcall(v218, "1 minute until you turn", "warn", v219)
			end
			if not v213 then
				v_u_193(0.55, 1)
			end
		end
		if v_u_175.beat and (v213 or v_u_175.beatUntil < v211) then
			local v220 = v213 and 0.3 or 1.2
			local v221 = v_u_175.beat
			v_u_175.beat = nil
			v_u_175.beatUntil = 0
			if v221 == true then
				return v208
			end
			if v221 then
				local v222 = v221.stop
				pcall(v222, v221, v220)
			end
		end
		return v208
	end
	local v_u_224 = {}
	local v_u_225 = -1
	function v13.setCharacter(p_u_226) -- name: setCharacter
		-- upvalues: (copy) v_u_224, (ref) v_u_14, (ref) v_u_225, (ref) v_u_58, (ref) v_u_136, (ref) v_u_1, (copy) v_u_150, (ref) v_u_50, (copy) v_u_166, (copy) p_u_7, (copy) v_u_175, (copy) v_u_8, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57
		for _, v227 in v_u_224 do
			v227:Disconnect()
		end
		table.clear(v_u_224)
		v_u_14 = p_u_226
		v_u_225 = -1
		if p_u_226 then
			local v228 = p_u_226:GetAttribute("Hp")
			v_u_225 = type(v228) ~= "number" and 100 or v228
			local v229 = p_u_226:GetAttribute("LastShotAt")
			v_u_58 = type(v229) ~= "number" and 0 or v229
			local function v233() -- name: sourced
				-- upvalues: (copy) p_u_226, (ref) v_u_14, (ref) v_u_136, (ref) v_u_1, (ref) v_u_150
				if p_u_226 == v_u_14 and os.clock() - v_u_136 >= 0.05 then
					local v230 = p_u_226
					local v231 = v230:GetAttribute("LastHitFrom")
					if typeof(v231) == "Vector3" then
						local v232 = v230:GetAttribute("LastHitAt")
						if type(v232) == "number" and v_u_1.now() - v232 > 1 then
							v231 = nil
						end
					else
						v231 = nil
					end
					if v231 then
						v_u_136 = os.clock()
						v_u_150(v231)
					end
				end
			end
			local v234 = v_u_224
			local v235 = p_u_226:GetAttributeChangedSignal("LastHitFrom")
			table.insert(v234, v235:Connect(v233))
			local v236 = v_u_224
			local v237 = p_u_226:GetAttributeChangedSignal("LastHitAt")
			table.insert(v236, v237:Connect(v233))
			local v238 = v_u_224
			local v239 = p_u_226:GetAttributeChangedSignal("Hp")
			local function v253()
				-- upvalues: (copy) p_u_226, (ref) v_u_225, (ref) v_u_14, (ref) v_u_136, (ref) v_u_50, (ref) v_u_150, (ref) v_u_1, (ref) v_u_166, (ref) p_u_7
				local v240 = p_u_226:GetAttribute("Hp")
				local v241 = type(v240) ~= "number" and 100 or v240
				if v_u_225 >= 0 and v241 < v_u_225 - 0.5 then
					task.defer(function()
						-- upvalues: (ref) p_u_226, (ref) v_u_14, (ref) v_u_136, (ref) v_u_50, (ref) v_u_150, (ref) v_u_1, (ref) v_u_166
						if p_u_226 == v_u_14 then
							if os.clock() - v_u_136 < 0.3 then
								v_u_50 = 0.55
							else
								local v242 = p_u_226:FindFirstChild("HumanoidRootPart")
								local v243 = v_u_150
								local v244
								if v242 then
									local v245 = p_u_226
									local v246 = v242.Position
									v244 = v245:GetAttribute("LastHitFrom")
									if typeof(v244) == "Vector3" then
										local v247 = v245:GetAttribute("LastHitAt")
										if type(v247) == "number" and v_u_1.now() - v247 > 1 then
											v244 = nil
										end
									else
										v244 = nil
									end
									if not v244 then
										local v248 = v245:GetAttribute("LastHitAt")
										if type(v248) == "number" and v_u_1.now() - v248 > 1 then
											v244 = nil
										else
											v244 = v_u_166(v246)
										end
									end
								else
									v244 = nil
								end
								v243(v244)
							end
						else
							return
						end
					end)
					local v249 = p_u_7.cctx.controllers.Camera
					if v249 and v249.shake then
						local v250 = v249.shake
						local v251 = (v_u_225 - v241) / 40
						local v252 = math.clamp(v251, 0.15, 0.8)
						pcall(v250, v252, 0.25)
					end
				end
				v_u_225 = v241
			end
			table.insert(v238, v239:Connect(v253))
			local v254 = v_u_175
			local v255 = p_u_226:GetAttribute("SuppDur")
			v254.suppDur = type(v255) ~= "number" and -1 or v255
			local v256 = v_u_224
			local v257 = p_u_226:GetAttributeChangedSignal("SuppDur")
			local function v261()
				-- upvalues: (copy) p_u_226, (ref) v_u_175, (ref) v_u_8
				local v258 = p_u_226:GetAttribute("SuppDur")
				local v259 = type(v258) ~= "number" and -1 or v258
				if v_u_175.suppDur > 0 and v259 == 0 then
					local v260 = v_u_8.toast
					pcall(v260, "Suppressor worn out", "warn", "Your shots are loud again. A workbench can repair it.")
				end
				v_u_175.suppDur = v259
			end
			table.insert(v256, v257:Connect(v261))
			local v262 = v_u_224
			local v263 = p_u_226:GetAttributeChangedSignal("LastShotAt")
			local function v273()
				-- upvalues: (copy) p_u_226, (ref) v_u_58, (ref) p_u_7, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57
				local v264 = p_u_226:GetAttribute("LastShotAt")
				local v265 = type(v264) ~= "number" and 0 or v264
				if v265 > v_u_58 then
					v_u_58 = v265
					local v266 = 60
					local v267 = p_u_7.weapons
					local v268 = v267 and v267.get
					if v268 then
						v268 = v267.get(p_u_226:GetAttribute("Weapon"))
					end
					local v269 = p_u_226:GetAttribute("ShotNoise")
					if type(v269) == "number" and v269 > 0 then
						v266 = v269
					elseif v268 then
						if p_u_226:GetAttribute("Suppressed") == true then
							v266 = v268.suppressedNoise
							local v270 = v268.noise
							local v271 = (type(v270) ~= "number" and 60 or v270) * 0.35
							if type(v266) ~= "number" then
								v266 = v271
							end
						else
							local v272 = v268.noise
							v266 = type(v272) ~= "number" and 60 or v272
						end
					end
					v_u_55 = 0
					v_u_56 = v266
					v_u_57 = true
				end
			end
			table.insert(v262, v263:Connect(v273))
		end
	end
	function v13.onHit(p274) -- name: onHit
		-- upvalues: (copy) v_u_134
		local v275
		if type(p274) == "table" then
			local v276 = p274.kind or "zombie"
			v275 = tostring(v276)
		else
			v275 = tostring(p274 or "zombie")
		end
		local v277
		if type(p274) == "table" then
			local v278 = p274.pos
			if typeof(v278) == "Vector3" then
				v277 = p274.pos
			else
				v277 = nil
			end
		else
			v277 = nil
		end
		v_u_134(v275, v277)
	end
	local v_u_279 = UDim.new(0.5, 0)
	local v_u_280 = 220
	local v_u_281 = 0
	local v_u_282 = -1
	local function v_u_287() -- name: placeAction
		-- upvalues: (ref) v_u_280, (ref) v_u_281, (copy) p_u_7, (ref) v_u_282, (copy) v_u_167, (ref) v_u_279
		local v283 = v_u_280
		if v_u_281 > 0 then
			local v284 = p_u_7.cctx and (p_u_7.cctx.player and p_u_7.cctx.player:GetAttribute("PromptTopY")) or 0
			if type(v284) == "number" and v284 > 0 then
				local v285 = v_u_280
				local v286 = v284 + 14 + v_u_281
				v283 = math.max(v285, v286)
			end
		end
		if v283 ~= v_u_282 then
			v_u_282 = v283
			v_u_167.Position = UDim2.new(v_u_279.Scale, v_u_279.Offset, 1, -v283)
		end
	end
	function v13.layout(p288) -- name: layout
		-- upvalues: (copy) p_u_7, (ref) v_u_279, (copy) v_u_11, (ref) v_u_280, (ref) v_u_281, (ref) v_u_282, (copy) v_u_287
		local v289
		if p288 and p_u_7.touchFrame then
			v289 = p_u_7.touchFrame()
		else
			v289 = nil
		end
		if v289 then
			v_u_279 = UDim.new(0, v289.promptX)
			if v_u_11.isPhone() then
				local v290 = v289.promptMaxW
				if type(v290) == "number" then
					local v291 = UDim.new
					local v292 = v289.promptX
					local v293 = v289.promptRight - v289.promptMaxW + 8 + 130
					v_u_279 = v291(0, (math.max(v292, v293)))
				end
			end
			v_u_280 = v289.promptBottom + 76
			v_u_281 = v_u_11.touch(40) + 8
		else
			v_u_279 = UDim.new(0.5, 0)
			v_u_280 = 220
			v_u_281 = 0
		end
		v_u_282 = -1
		v_u_287()
	end
	local v_u_294 = 0
	function v13.update(p295) -- name: update
		-- upvalues: (ref) v_u_294, (ref) v_u_14, (copy) v_u_47, (copy) v_u_223, (copy) v_u_175, (copy) v_u_48, (ref) v_u_50, (copy) v_u_49, (copy) v_u_110, (copy) v_u_8, (copy) v_u_37, (copy) v_u_135, (ref) v_u_59, (ref) v_u_55, (ref) v_u_57, (copy) v_u_72, (ref) v_u_56, (copy) v_u_51, (copy) v_u_52, (copy) v_u_12, (copy) v_u_53, (copy) v_u_54, (copy) v_u_109, (copy) v_u_287, (ref) v_u_1, (ref) v_u_171, (ref) v_u_172, (copy) v_u_168, (ref) v_u_6, (copy) v_u_167, (copy) v_u_170, (copy) v_u_169, (ref) v_u_5, (ref) v_u_174
		v_u_294 = v_u_294 + p295
		local v296 = v_u_14
		local v297
		if v296 == nil or v296.Parent == nil then
			v297 = false
		else
			v297 = v296:GetAttribute("Dead") ~= true
		end
		local v298
		if v297 and v296 then
			local v299 = v296:GetAttribute("Hp")
			local v300 = type(v299) ~= "number" and 100 or v299
			local v301 = v296:GetAttribute("MaxHp")
			local v302 = type(v301) ~= "number" and 100 or v301
			local v303 = v300 / math.max(1, v302)
			v298 = math.clamp(v303, 0, 1)
		else
			v298 = 1
		end
		local v304
		if v297 then
			if v296 == nil then
				v304 = false
			else
				v304 = v296:GetAttribute("Downed") == true
			end
		else
			v304 = v297
		end
		local v305
		if v304 then
			v305 = 0
		else
			local v306 = (0.4 - v298) / 0.4
			v305 = math.clamp(v306, 0, 1)
		end
		if v305 > 0 then
			local v307 = (1 - v298) * 1.2 + 1.1
			local v308 = v_u_294 * 3.141592653589793 * 2 * v307
			local v309 = math.sin(v308)
			local v310 = v_u_47
			local v311 = v305 * (math.max(0, v309) ^ 6 * 0.4 + 0.45)
			local v312 = 1 - math.clamp(v311, 0, 1)
			if v312 ~= v310.last then
				local v313 = v312 - v310.last
				if math.abs(v313) >= 0.004 or (v312 <= 0 or v312 >= 1) then
					v310.last = v312
					for _, v314 in v310.frames do
						v314.BackgroundTransparency = v312
					end
				end
			end
		else
			local v315 = v_u_47
			if v315.last ~= 1 then
				local v316 = 1 - v315.last
				local _ = math.abs(v316) < 0.004
				v315.last = 1
				for _, v317 in v315.frames do
					v317.BackgroundTransparency = 1
				end
			end
		end
		local v318 = v_u_223
		local v319
		if v297 then
			v319 = v296
		else
			v319 = nil
		end
		local v320 = v318(v319, v_u_294)
		if v297 and (v296 and v320 >= 0) then
			local v321 = v296:GetAttribute("InfectionEndsAt")
			local v322 = type(v321) ~= "number" and 0 or v321
			local v323 = v296:GetAttribute("InfectedAt")
			local v324 = v322 - (type(v323) ~= "number" and 0 or v323)
			local v325 = 1 - v320 / (v324 <= 30 and 360 or v324)
			local v326 = math.clamp(v325, 0, 1)
			local v327 = v326 * 3 + 1.2
			local v328 = v_u_294 * 3.141592653589793 * v327
			local v329 = math.sin(v328) * 0.5 + 0.5
			local v330 = (v326 * 0.3 + 0.26) * (v329 * 0.65 + 0.35)
			if os.clock() < v_u_175.freshUntil then
				local v331 = v_u_294 * 3.141592653589793 * 2 * 1.3
				local v332 = math.sin(v331)
				local v333 = math.max(0, v332) ^ 4 * 0.33 + 0.22
				v330 = math.max(v330, v333)
			end
			local v334 = v_u_48
			local v335 = 1 - math.clamp(v330, 0, 1)
			if v335 ~= v334.last then
				local v336 = v335 - v334.last
				if math.abs(v336) >= 0.004 or (v335 <= 0 or v335 >= 1) then
					v334.last = v335
					for _, v337 in v334.frames do
						v337.BackgroundTransparency = v335
					end
				end
			end
		else
			local v338 = v_u_48
			if v338.last ~= 1 then
				local v339 = 1 - v338.last
				local _ = math.abs(v339) < 0.004
				v338.last = 1
				for _, v340 in v338.frames do
					v340.BackgroundTransparency = 1
				end
			end
		end
		if v_u_50 > 0 then
			local v341 = v_u_50 - p295 * 2.2
			v_u_50 = math.max(0, v341)
		end
		local v342 = v_u_49
		local v343 = v_u_50
		local v344 = 1 - math.clamp(v343, 0, 1)
		if v344 ~= v342.last then
			local v345 = v344 - v342.last
			if math.abs(v345) >= 0.004 or (v344 <= 0 or v344 >= 1) then
				v342.last = v344
				for _, v346 in v342.frames do
					v346.BackgroundTransparency = v344
				end
			end
		end
		for v347 = #v_u_110, 1, -1 do
			local v348 = v_u_110[v347]
			v348.t = v348.t + p295
			local v349 = v348.t / v348.life
			if v349 >= 1 then
				v348.f:Destroy()
				table.remove(v_u_110, v347)
			else
				local v350 = v349 * 0.35 + 1
				for _, v351 in v348.f:GetChildren() do
					if not v351:IsA("Frame") then
						continue
					end
					v351.BackgroundTransparency = v349 ^ 2
				end
				(v348.f:FindFirstChildOfClass("UIScale") or v_u_8.new("UIScale", {}, v348.f)).Scale = v350
			end
		end
		local v352
		if v297 and v296 then
			v352 = v296:FindFirstChild("HumanoidRootPart")
		else
			v352 = nil
		end
		local v353 = nil
		local v354 = 0
		local v355
		if v352 then
			local v356 = v352.Position - Vector3.new(0, 2.6, 0)
			local v357
			v355, v357 = v_u_37(v356)
			if v357 then
				local v358 = workspace.CurrentCamera
				if v358 then
					v354 = (v_u_37(v356 + v358.CFrame.RightVector * 10) - v355).Magnitude / 10
				end
			else
				v355 = v353
			end
		else
			v355 = v353
		end
		for v359 = #v_u_135, 1, -1 do
			local v360 = v_u_135[v359]
			v360.t = v360.t + p295
			if v360.t > 1.4 or not (v355 and v352) then
				v360.f:Destroy()
				table.remove(v_u_135, v359)
			else
				local v361 = v352.Position
				local v362 = v_u_8.worldToScreen(v361)
				local v363 = v360.dir.X - v361.X
				local v364 = v360.dir.Z - v361.Z
				local v365 = Vector3.new(v363, 0, v364)
				local v366 = Vector2.zero
				if v365.Magnitude > 0.05 then
					v366 = v_u_8.worldToScreen(v361 + v365.Unit * 6) - v362
				end
				if v366.Magnitude > 0.01 then
					local v367 = v366.Unit
					local v368 = v355 - Vector2.new(0, 40) + v367 * 120
					v360.f.Position = UDim2.fromOffset(v368.X, v368.Y)
					local v369 = v360.f
					local v370 = v367.X
					local v371 = -v367.Y
					local v372 = math.atan2(v370, v371)
					v369.Rotation = math.deg(v372)
				end
				local v373 = (v360.t - 0.6) / 0.8
				local v374 = math.clamp(v373, 0, 1)
				for _, v375 in v360.f:GetDescendants() do
					if not v375:IsA("Frame") or v375.Name ~= "g" then
						continue
					end
					v375.BackgroundTransparency = v374
				end
			end
		end
		if v297 and (v296 and v296:GetAttribute("Sprinting") == true) then
			v_u_59 = v_u_59 + p295
			if v_u_59 > 0.5 then
				v_u_59 = 0
				if v_u_55 > 0.45 or not v_u_57 then
					local v376 = v_u_72() * 18
					v_u_55 = 0
					v_u_56 = v376
					v_u_57 = false
				end
			end
		else
			v_u_59 = 0
		end
		v_u_55 = v_u_55 + p295
		if v355 and (v354 > 0 and v_u_55 < 1.6) then
			local v377 = v_u_55 / 0.35
			local v378 = 1 - (1 - math.clamp(v377, 0, 1)) ^ 3
			local v379 = v_u_56 * v354 * v378 * 2
			local v380 = (v_u_55 - 0.25) / 1.3
			local v381 = math.clamp(v380, 0, 1)
			local v382 = v_u_57 and 0.25 or 0.7
			v_u_51.Visible = true
			v_u_51.Position = UDim2.fromOffset(v355.X, v355.Y)
			v_u_51.Size = UDim2.fromOffset(v379, v379 * 0.62)
			v_u_52.Transparency = v382 + (1 - v382) * v381
			local v383 = v_u_52
			local v384
			if v_u_57 then
				v384 = v_u_12.accent
			else
				v384 = v_u_12.text
			end
			v383.Color = v384
			v_u_53.Visible = v_u_57
			if v_u_57 then
				local v385 = v_u_55 / 0.6
				local v386 = v379 * math.clamp(v385, 0, 1)
				v_u_53.Position = v_u_51.Position
				v_u_53.Size = UDim2.fromOffset(v386, v386 * 0.62)
				v_u_54.Transparency = v381 * 0.4 + 0.6
			end
		else
			v_u_51.Visible = false
			v_u_53.Visible = false
		end
		v_u_109(p295, v297)
		v_u_287()
		local v387
		if v297 and v296 then
			v387 = v296:GetAttribute("Action")
		else
			v387 = nil
		end
		if type(v387) == "string" and (v387 ~= "" and (v387 ~= "Extract" and v296)) then
			local v388 = v296:GetAttribute("ActionEndsAt")
			local v389 = type(v388) ~= "number" and 0 or v388
			local v390 = v_u_1.now()
			if v387 ~= v_u_171 then
				v_u_171 = v387
				v_u_172 = v390
				v_u_8.setText(v_u_168, v_u_6[v387] or v387)
				v_u_167.Visible = true
			end
			if v_u_172 < v389 then
				local v391 = v_u_170.set
				local v392 = (v390 - v_u_172) / (v389 - v_u_172)
				v391(math.clamp(v392, 0, 1), true)
				v_u_169.Text = string.format("%.1f", v_u_5.timeLeft(v389, v390))
			else
				v_u_169.Text = ""
			end
		elseif v_u_171 ~= "" then
			v_u_171 = ""
			v_u_167.Visible = false
		end
		if v_u_174 then
			local v393 = v_u_174.update
			local v394
			if v_u_167.Visible then
				v394 = v_u_171
			else
				v394 = nil
			end
			v393(v394)
		end
	end
	function v13.destroy() -- name: destroy
		-- upvalues: (copy) v_u_224, (ref) v_u_174, (copy) v_u_175, (copy) v_u_15, (copy) v_u_110, (copy) v_u_135
		for _, v395 in v_u_224 do
			v395:Disconnect()
		end
		table.clear(v_u_224)
		if v_u_174 then
			local v396 = v_u_174.destroy
			pcall(v396)
			v_u_174 = nil
		end
		local v397 = v_u_175.notice
		v_u_175.notice = nil
		v_u_175.timeLbl = nil
		if v397 and v397.Parent then
			v397:Destroy()
		end
		local v398 = v_u_175.beat
		v_u_175.beat = nil
		v_u_175.beatUntil = 0
		if v398 ~= true and v398 then
			local v399 = v398.stop
			pcall(v399, v398, 0.5)
		end
		for _, v400 in {
			"LowHp",
			"Infection",
			"HitFlash",
			"NoiseRing",
			"NoiseEcho",
			"Action",
			"HearCues"
		} do
			local v401 = v_u_15:FindFirstChild(v400)
			if not v401 then
				continue
			end
			v401:Destroy()
		end
		for _, v402 in v_u_110 do
			v402.f:Destroy()
		end
		for _, v403 in v_u_135 do
			v403.f:Destroy()
		end
		table.clear(v_u_110)
		table.clear(v_u_135)
	end
	return v13
end
return v_u_5