-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ClubAudio

local v_u_1 = {}
local v_u_2 = {}
v_u_2.__index = v_u_2
v_u_1.TUNE = {
	["blend"] = 0.8,
	["fadeIn"] = 0.25,
	["fadeOut"] = 0.4,
	["firstCheck"] = 1,
	["check"] = 10,
	["tol"] = 0.1,
	["wrapCheck"] = 0.3,
	["loadTimeout"] = 12,
	["idleAfter"] = 2,
	["staleStep"] = 2,
	["status"] = 1
}
v_u_1.OFF_WET = -80
v_u_1.WET_ON = -60
v_u_1.HEAD_DY = 1.5
v_u_1.EMITTER_DY = 6
v_u_1.ROLL = {
	["min"] = 20,
	["max"] = 140
}
v_u_1.RANGE = {
	["eq"] = { -80, 10 },
	["decay"] = { 0.1, 20 },
	["density"] = { 0, 1 },
	["diffusion"] = { 0, 1 },
	["dry"] = { -80, 20 },
	["wet"] = { -80, 10 }
}
local function v_u_4(p3, ...) -- name: callFn
	if type(p3) == "function" then
		return p3(...)
	else
		return nil
	end
end
function v_u_1.approach(p5, p6, p7, p8) -- name: approach
	local v9
	if type(p5) == "number" and (p5 == p5 and p5 > -1000000000000000) then
		v9 = p5 < 1000000000000000
	else
		v9 = false
	end
	if v9 then
		local v10
		if type(p6) == "number" and (p6 == p6 and p6 > -1000000000000000) then
			v10 = p6 < 1000000000000000
		else
			v10 = false
		end
		if v10 then
			if p7 > 0 and p8 > 0 then
				local v11 = p7 * -4.6 / p8
				local v12 = 1 - math.exp(v11)
				return p5 + (p6 - p5) * v12
			elseif p7 > 0 then
				return p6
			else
				return p5
			end
		end
	end
	local v13
	if type(p6) == "number" and (p6 == p6 and p6 > -1000000000000000) then
		v13 = p6 < 1000000000000000
	else
		v13 = false
	end
	return not v13 and 0 or p6
end
function v_u_1.ramp(p14, p15, p16, p17) -- name: ramp
	if p16 > 0 then
		local v18 = p17 <= 0 and 1 or p16 / p17
		if p14 < p15 then
			local v19 = p14 + v18
			return math.min(p15, v19)
		else
			local v20 = p14 - v18
			return math.max(p15, v20)
		end
	else
		return p14
	end
end
function v_u_1.parseBlocked(p21) -- name: parseBlocked
	local v22 = {}
	if type(p21) == "string" then
		for v23 in string.gmatch(p21, "%d+") do
			local v24 = tonumber(v23)
			if not v24 then
				continue
			end
			v22[v24] = true
		end
	end
	return v22
end
function v_u_1.targetOf(p25) -- name: targetOf
	-- upvalues: (copy) v_u_1
	if type(p25) ~= "table" then
		return {
			["outer"] = 0,
			["inner"] = 0,
			["low"] = 0,
			["mid"] = 0,
			["high"] = 0,
			["wet"] = nil,
			["inClub"] = false,
			["zone"] = "-",
			["key"] = "none",
			["wet"] = v_u_1.OFF_WET
		}
	end
	local v26 = p25.reverb
	local v27 = {
		["outer"] = p25.outer or 0,
		["inner"] = p25.inner or 0,
		["low"] = p25.low or 0,
		["mid"] = p25.mid or 0,
		["high"] = p25.high or 0
	}
	local v28
	if v26 then
		v28 = v26.decay
	else
		v28 = nil
	end
	v27.decay = v28
	local v29
	if v26 then
		v29 = v26.density
	else
		v29 = nil
	end
	v27.density = v29
	local v30
	if v26 then
		v30 = v26.diffusion
	else
		v30 = nil
	end
	v27.diffusion = v30
	local v31
	if v26 then
		v31 = v26.dry
	else
		v31 = nil
	end
	v27.dry = v31
	local v32
	if v26 then
		v32 = v26.wet
	else
		v32 = v_u_1.OFF_WET
	end
	v27.wet = v32
	v27.inClub = p25.zone ~= "outside"
	v27.zone = p25.zone
	v27.key = p25.key
	v27.t = p25.t
	v27.dist = p25.dist
	return v27
end
local v_u_33 = {
	"outer",
	"inner",
	"low",
	"mid",
	"high",
	"decay",
	"density",
	"diffusion",
	"dry",
	"wet"
}
local v_u_34 = {
	["outer"] = 0,
	["inner"] = 0,
	["low"] = 0,
	["mid"] = 0,
	["high"] = 0,
	["decay"] = 1,
	["density"] = 0.5,
	["diffusion"] = 0.5,
	["dry"] = 0,
	["wet"] = -80
}
function v_u_1.blendMix(p35, p36, p37, p38) -- name: blendMix
	-- upvalues: (copy) v_u_33, (copy) v_u_34, (copy) v_u_1
	local v39 = p35 == nil
	local v40 = p35 or {}
	for _, v41 in v_u_33 do
		local v42 = p36[v41]
		if v39 then
			if v42 == nil then
				v42 = v_u_34[v41]
			end
			v40[v41] = v42
		else
			if v42 == nil then
				continue
			end
			v40[v41] = v_u_1.approach(v40[v41], v42, p37, p38)
		end
	end
	return v40
end
function v_u_1.effectValues(p43) -- name: effectValues
	-- upvalues: (copy) v_u_1
	local v44 = v_u_1.RANGE
	local v45 = {}
	local v46 = p43.low
	local v47 = v44.eq[1]
	local v48 = v44.eq[2]
	local v49 = math.min(v48, v46)
	v45.low = math.max(v47, v49)
	local v50 = p43.mid
	local v51 = v44.eq[1]
	local v52 = v44.eq[2]
	local v53 = math.min(v52, v50)
	v45.mid = math.max(v51, v53)
	local v54 = p43.high
	local v55 = v44.eq[1]
	local v56 = v44.eq[2]
	local v57 = math.min(v56, v54)
	v45.high = math.max(v55, v57)
	local v58 = p43.decay
	local v59 = v44.decay[1]
	local v60 = v44.decay[2]
	local v61 = math.min(v60, v58)
	v45.decay = math.max(v59, v61)
	local v62 = p43.density
	local v63 = v44.density[1]
	local v64 = v44.density[2]
	local v65 = math.min(v64, v62)
	v45.density = math.max(v63, v65)
	local v66 = p43.diffusion
	local v67 = v44.diffusion[1]
	local v68 = v44.diffusion[2]
	local v69 = math.min(v68, v66)
	v45.diffusion = math.max(v67, v69)
	local v70 = p43.dry
	local v71 = v44.dry[1]
	local v72 = v44.dry[2]
	local v73 = math.min(v72, v70)
	v45.dry = math.max(v71, v73)
	local v74 = p43.wet
	local v75 = v44.wet[1]
	local v76 = v44.wet[2]
	local v77 = math.min(v76, v74)
	v45.wet = math.max(v75, v77)
	v45.on = p43.wet > v_u_1.WET_ON
	return v45
end
function v_u_1.new(p78, p79, p80) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v81 = v_u_2
	local v82 = setmetatable({}, v81)
	v82.api = p78
	v82.R = p79.Rules
	v82.T = p79.Tracks
	v82.tune = table.clone(v_u_1.TUNE)
	if p80 then
		for v83, v84 in p80 do
			v82.tune[v83] = v84
		end
	end
	v82.mix = nil
	v82.target = v_u_1.targetOf(nil)
	v82.gate = 0
	v82.cur = nil
	v82.voices = nil
	v82.speed = 1
	v82.idleFor = 0
	v82.lastStepAt = nil
	v82.lastAudible = false
	v82.roomOn = false
	v82.preloaded = false
	v82.reason = "idle"
	v82.stats = {
		["steps"] = 0,
		["starts"] = 0,
		["resyncs"] = 0,
		["checks"] = 0,
		["lastDrift"] = 0,
		["maxDrift"] = 0,
		["loadFails"] = 0,
		["lenMismatch"] = false
	}
	return v82
end
function v_u_2.log(p85, p86) -- name: log
	-- upvalues: (copy) v_u_4
	v_u_4(p85.api.log, p86)
end
function v_u_2.resolve(p87, p88) -- name: resolve
	if type(p88) ~= "table" or p88.active ~= true then
		return nil, "inactive", false
	end
	local v89 = p87.T.get(p88.track)
	if v89 == nil then
		return nil, "no track", false
	end
	local v90 = p87.T.soundId(v89)
	if v90 == nil then
		return nil, "placeholder", false
	end
	if not p87.R.trackOk(v89) then
		return nil, "bad track", false
	end
	local v91 = p87.T.numericId(v89.id)
	if v91 ~= nil then
		local v92 = p88.blocked
		if type(v92) == "table" and p88.blocked[v91] == true then
			return nil, "blocked", false
		end
	end
	local v93 = p88.start
	local v94
	if type(v93) == "number" and (v93 == v93 and v93 > -1000000000000000) then
		v94 = v93 < 1000000000000000
	else
		v94 = false
	end
	if not v94 then
		return nil, "no start", false
	end
	local v95 = 1
	local v96 = p88.rate
	local v97
	if type(v96) == "number" and (v96 == v96 and v96 > -1000000000000000) then
		v97 = v96 < 1000000000000000
	else
		v97 = false
	end
	if v97 then
		local v98 = p88.rate
		local v99 = p87.R.RATE_MIN
		local v100 = p87.R.RATE_MAX
		local v101 = math.min(v100, v98)
		v95 = math.max(v99, v101)
	end
	return {
		["index"] = p88.track,
		["track"] = v89,
		["soundId"] = v90,
		["nid"] = v91,
		["len"] = v89.length,
		["start"] = p88.start,
		["rate"] = v95
	}, "ok", p88.music == true
end
function v_u_2.expected(p102, p103, p104) -- name: expected
	return p104 < p103.start and 0 or p102.R.clockPos({
		["start"] = p103.start,
		["rate"] = p103.rate,
		["len"] = p103.len
	}, p104)
end
function v_u_2.ensureVoices(p105) -- name: ensureVoices
	if p105.voices == nil then
		local v106 = p105.api.newVoice("outer")
		local v107 = p105.api.newVoice("inner")
		p105.voices = {
			["inner"] = v107,
			["outer"] = v106,
			["list"] = { v107, v106 }
		}
		p105.speed = 1
	end
end
function v_u_2.destroyVoices(p108) -- name: destroyVoices
	local v109 = p108.voices
	if v109 then
		p108.voices = nil
		for _, v_u_110 in v109.list do
			pcall(function()
				-- upvalues: (copy) v_u_110
				v_u_110:pause()
				v_u_110:setVolume(0)
				v_u_110:destroy()
			end)
		end
	end
end
function v_u_2.pauseAll(p111) -- name: pauseAll
	local v112 = p111.voices
	if v112 then
		for _, v113 in v112.list do
			v113:pause()
		end
	end
	if p111.cur then
		p111.cur.playing = false
	end
end
function v_u_2.assign(p114, p115, p116) -- name: assign
	-- upvalues: (copy) v_u_4
	p114:ensureVoices()
	local v117 = p114.voices
	v117.inner:setId(p115.soundId)
	v117.outer:setId(p115.soundId)
	v117.inner:setSpeed(p115.rate)
	v117.outer:setSpeed(p115.rate)
	p114.speed = p115.rate
	p114.cur = {
		["index"] = nil,
		["soundId"] = nil,
		["nid"] = nil,
		["len"] = nil,
		["playing"] = false,
		["ending"] = false,
		["since"] = nil,
		["nextCheck"] = 0,
		["failed"] = false,
		["prevPos"] = nil,
		["name"] = nil,
		["index"] = p115.index,
		["soundId"] = p115.soundId,
		["nid"] = p115.nid,
		["len"] = p115.len,
		["since"] = p116,
		["name"] = p115.track.key
	}
	if not p114.preloaded and p114.api.preload ~= nil then
		p114.preloaded = true
		local v118 = {}
		for _, v119 in p114.T.assetIds() do
			local v120 = string.format
			table.insert(v118, v120("rbxassetid://%d", v119))
		end
		v_u_4(p114.api.preload, v118)
	end
end
function v_u_2.start(p121, p122, p123, p124) -- name: start
	local v125 = p121.voices
	local v126 = p121:expected(p122, p123)
	local v127 = v125.inner:timeLength()
	local v128
	if type(v127) == "number" and (v127 == v127 and v127 > -1000000000000000) then
		v128 = v127 < 1000000000000000
	else
		v128 = false
	end
	if v128 and v127 > 0 then
		local v129 = v127 - p122.len
		if math.abs(v129) > 0.5 then
			p121.stats.lenMismatch = true
		end
		local v130 = v127 - 0.05
		local v131 = math.max(0, v130)
		v126 = math.min(v126, v131)
	end
	for _, v132 in v125.list do
		v132:setPos(v126)
		v132:play()
	end
	p121.cur.playing = true
	p121.cur.nextCheck = p124 + p121.tune.firstCheck
	p121.cur.prevPos = v126
	local v133 = p121.stats
	v133.starts = v133.starts + 1
end
function v_u_2.check(p134, p135, p136) -- name: check
	local v137 = p134.voices
	local v138 = p134:expected(p135, p136)
	local v139 = p134.stats
	v139.checks = v139.checks + 1
	local v140 = 0
	for _, v141 in v137.list do
		if not v141:isLoaded() then
			continue
		end
		local v142 = v141:timeLength()
		local v143
		if type(v142) == "number" and (v142 == v142 and v142 > -1000000000000000) then
			v143 = v142 < 1000000000000000
		else
			v143 = false
		end
		local v144
		if v143 and v142 > 0 then
			local v145 = v142 - 0.05
			local v146 = math.max(0, v145)
			v144 = math.min(v138, v146)
		else
			v144 = v138
		end
		local v147, v148 = p134.R.driftOk(v141:getPos(), v144, p135.len, p134.tune.tol)
		if v140 < math.abs(v148) then
			v140 = math.abs(v148)
		end
		if v147 then
			continue
		end
		v141:setPos(v144)
		local v149 = p134.stats
		v149.resyncs = v149.resyncs + 1
	end
	p134.stats.lastDrift = v140
	if p134.stats.maxDrift < v140 then
		p134.stats.maxDrift = v140
	end
end
function v_u_2.step(p150, p151, p152, p153, p154, p155) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v156 = p150.api
	local v157 = p150.tune
	local v158
	if type(p151) == "number" and (p151 == p151 and p151 > -1000000000000000) then
		v158 = p151 < 1000000000000000
	else
		v158 = false
	end
	local v159 = math.min(0.25, not v158 and 0 or p151)
	local v160 = math.max(0, v159)
	local v161 = v156.clock()
	p150.lastStepAt = v161
	local v162 = p150.stats
	v162.steps = v162.steps + 1
	if p155 == true and (p150.cur == nil and (p150.voices == nil and (not p150.roomOn and p150.gate <= 0.002))) then
		p150.lastAudible = false
		p150.reason = "inactive"
		p150.mix = nil
		return
	else
		local v163 = v156.now()
		local v164 = v156.read()
		if p155 == true and type(v164) == "table" then
			v164.active = false
		end
		local v165, v166, v167 = p150:resolve(v164)
		local v168
		if v167 then
			v168 = v165 ~= nil
		else
			v168 = v167
		end
		p150.lastAudible = v168
		local v169 = nil
		if type(v164) == "table" and v164.active == true then
			local v170
			if type(p152) == "number" and (p152 == p152 and p152 > -1000000000000000) then
				v170 = p152 < 1000000000000000
			else
				v170 = false
			end
			if v170 then
				local v171
				if type(p153) == "number" and (p153 == p153 and p153 > -1000000000000000) then
					v171 = p153 < 1000000000000000
				else
					v171 = false
				end
				if v171 then
					local v172
					if type(p154) == "number" and (p154 == p154 and p154 > -1000000000000000) then
						v172 = p154 < 1000000000000000
					else
						v172 = false
					end
					if v172 then
						v169 = p150.R.audioAt(p152, p153, p154)
					end
				end
			end
		end
		p150.target = v_u_1.targetOf(v169)
		p150.mix = v_u_1.blendMix(p150.mix, p150.target, v160, v157.blend)
		local v173 = p150.mix
		if p150.target.outer + p150.target.inner + v173.outer + v173.inner > 0.001 then
			p150.idleFor = 0
		else
			p150.idleFor = p150.idleFor + v160
		end
		local v174 = p150.cur
		if v174 ~= nil then
			local v175
			if v165 == nil or v165.index ~= v174.index then
				v175 = false
			else
				v175 = v165.soundId == v174.soundId
			end
			v174.ending = not v175
		end
		if v174 == nil and v165 ~= nil then
			p150:assign(v165, v161)
			v174 = p150.cur
		end
		local v176 = v167 and (v165 ~= nil and v174 ~= nil and not v174.ending)
		if v176 then
			v176 = p150.idleFor < v157.idleAfter
		end
		if v165 == nil then
			p150.reason = v166
		elseif v174 == nil or not v174.ending then
			if v167 then
				if p150.idleFor >= v157.idleAfter then
					p150.reason = "far away"
				elseif v174 == nil or not v174.playing then
					p150.reason = "loading"
				else
					p150.reason = "playing"
				end
			else
				p150.reason = "music off"
			end
		else
			p150.reason = "switching"
		end
		if v174 ~= nil and (v165 ~= nil and not v174.ending) then
			if p150.voices then
				local v177 = v165.rate - p150.speed
				if math.abs(v177) > 0.001 then
					p150.speed = v165.rate
					p150.voices.inner:setSpeed(v165.rate)
					p150.voices.outer:setSpeed(v165.rate)
					local v178 = v174.nextCheck
					local v179 = v161 + 0.5
					v174.nextCheck = math.min(v178, v179)
				end
			end
			if v176 and not v174.playing then
				local v180 = p150.voices
				if v180 and v180.inner:isLoaded() then
					v174.failed = false
					p150:start(v165, v163, v161)
				elseif v180 and (not v174.failed and v161 - v174.since >= v157.loadTimeout) then
					v174.failed = true
					local v181 = p150.stats
					v181.loadFails = v181.loadFails + 1
					p150.reason = "load failed"
					if v165.nid then
						v_u_4(v156.reportFail, v165.nid, "timeout")
					end
					local v182 = v174.name
					local v183 = tostring(v182)
					local v184 = v157.loadTimeout
					p150:log("ClubAudio: " .. v183 .. " did not load in " .. tostring(v184) .. " s")
				end
			elseif v174.playing then
				local v185 = p150:expected(v165, v163)
				if v174.prevPos ~= nil and v185 < v174.prevPos - v165.len / 2 then
					local v186 = v174.nextCheck
					local v187 = v161 + v157.wrapCheck
					v174.nextCheck = math.min(v186, v187)
				end
				v174.prevPos = v185
				if v176 and v174.nextCheck <= v161 then
					v174.nextCheck = v161 + v157.check
					p150:check(v165, v163)
				end
			end
		end
		local v188 = v176 and (v174 ~= nil and v174.playing) and 1 or 0
		local v189 = v_u_1.ramp
		local v190 = p150.gate
		local v191
		if p150.gate < v188 then
			v191 = v157.fadeIn
		else
			v191 = v157.fadeOut
		end
		p150.gate = v189(v190, v188, v160, v191)
		if p150.gate <= 0.002 and (v174 ~= nil and (v174.playing and not v176)) then
			p150:pauseAll()
		end
		if v174 ~= nil and (v174.ending and p150.gate <= 0.002) then
			p150:pauseAll()
			p150.cur = nil
		end
		if p150.cur == nil and (v165 == nil and p150.gate <= 0.002) then
			p150:destroyVoices()
		end
		local v192 = p150.voices
		if v192 ~= nil then
			local v193 = p150.cur == nil and 1 or p150.T.gain(p150.T.get(p150.cur.index))
			local v194 = v_u_1.effectValues(v173)
			local v195 = p150.gate <= 0.002 and 0 or p150.gate
			v192.outer:setVolume(v173.outer * v195 * v193)
			v192.inner:setVolume(v173.inner * v195 * v193)
			for _, v196 in v192.list do
				v196:setEq(v194.low, v194.mid, v194.high)
				v196:setReverb(v194.decay, v194.density, v194.diffusion, v194.dry, v194.wet, v194.on)
			end
		end
		local v197
		if p155 == true then
			v197 = nil
		else
			v197 = p150:roomOf()
		end
		if v197 == nil then
			if p150.roomOn then
				v_u_4(v156.setRoomOverride, nil)
				p150.roomOn = false
			end
		else
			v_u_4(v156.setRoomOverride, v197)
			p150.roomOn = true
		end
	end
end
function v_u_2.roomOf(p198) -- name: roomOf
	-- upvalues: (copy) v_u_1
	local v199 = p198.mix
	return v199 ~= nil and v199.wet > v_u_1.WET_ON and {
		["decay"] = v199.decay,
		["density"] = v199.density,
		["diffusion"] = v199.diffusion,
		["dry"] = v199.dry,
		["wet"] = v199.wet
	} or nil
end
function v_u_2.isPlaying(p200) -- name: isPlaying
	local v201
	if p200.cur == nil then
		v201 = false
	else
		v201 = p200.cur.playing == true
	end
	return v201
end
function v_u_2.wantsMusic(p202) -- name: wantsMusic
	local v203 = p202.lastStepAt
	if v203 == nil or p202.api.clock() - v203 > p202.tune.staleStep then
		return false
	else
		return p202.lastAudible == true
	end
end
function v_u_2.silence(p204) -- name: silence
	-- upvalues: (copy) v_u_4
	p204:pauseAll()
	p204.cur = nil
	p204.gate = 0
	p204:destroyVoices()
	if p204.roomOn then
		v_u_4(p204.api.setRoomOverride, nil)
	end
	p204.roomOn = false
end
function v_u_2.destroy(p205) -- name: destroy
	p205:silence()
end
function v_u_2.status(p206) -- name: status
	local v207 = p206.mix
	local v208 = p206.cur
	local v209 = {
		["reason"] = p206.reason,
		["zone"] = p206.target.zone,
		["key"] = p206.target.key,
		["outer"] = not v207 and 0 or v207.outer,
		["inner"] = not v207 and 0 or v207.inner,
		["gate"] = p206.gate
	}
	local v210
	if v208 then
		v210 = v208.name
	else
		v210 = nil
	end
	v209.track = v210
	local v211
	if v208 == nil then
		v211 = false
	else
		v211 = v208.playing == true
	end
	v209.playing = v211
	v209.resyncs = p206.stats.resyncs
	v209.starts = p206.stats.starts
	v209.checks = p206.stats.checks
	v209.lastDrift = p206.stats.lastDrift
	v209.maxDrift = p206.stats.maxDrift
	v209.loadFails = p206.stats.loadFails
	v209.lenMismatch = p206.stats.lenMismatch
	v209.room = p206.roomOn
	return v209
end
function v_u_2.statusLine(p212) -- name: statusLine
	local v213 = p212:status()
	local v214 = string.format
	local v215 = v213.reason
	local v216 = tostring(v215)
	local v217 = v213.zone
	local v218 = tostring(v217)
	local v219 = v213.key
	local v220 = tostring(v219)
	local v221 = v213.outer
	local v222 = v213.inner
	local v223 = v213.gate
	local v224 = v213.track
	return v214("%s | zone %s/%s | outer %.2f inner %.2f gate %.2f | track %s %s | starts %d checks %d resyncs %d drift %.3f (max %.3f) | loadFails %d%s%s", v216, v218, v220, v221, v222, v223, tostring(v224), v213.playing and "playing" or "paused", v213.starts, v213.checks, v213.resyncs, v213.lastDrift, v213.maxDrift, v213.loadFails, v213.lenMismatch and " | LENGTH MISMATCH (file vs ClubTracks)" or "", v213.room and " | room reverb on" or "")
end
function v_u_1.realApi(p_u_225, p_u_226) -- name: realApi
	-- upvalues: (copy) v_u_1
	local v227 = {}
	local v_u_228 = game:GetService("ReplicatedStorage")
	local v_u_229 = game:GetService("SoundService")
	local v_u_230 = game:GetService("ContentProvider")
	local v_u_231 = game:GetService("Players")
	local v_u_232 = p_u_225.shared.ClubRules
	local v233, v_u_234 = pcall(function()
		-- upvalues: (copy) p_u_225
		return p_u_225.lib.ServerClock
	end)
	if not v233 or type(v_u_234) ~= "table" then
		v_u_234 = nil
	end
	v227.clock = os.clock
	function v227.now()
		-- upvalues: (ref) v_u_234
		if v_u_234 then
			return v_u_234.now()
		else
			return workspace:GetServerTimeNow()
		end
	end
	local v_u_235 = nil
	local v_u_236 = {}
	function v227.read()
		-- upvalues: (copy) v_u_228, (copy) v_u_232, (ref) v_u_235, (ref) v_u_236, (ref) v_u_1
		local v237 = v_u_228:FindFirstChild("HushRuntime")
		if v237 == nil or v237:GetAttribute("MapId") ~= v_u_232.MAP then
			return {
				["active"] = false
			}
		end
		local v238 = v237:FindFirstChild("Raid")
		if v238 == nil then
			return {
				["active"] = false
			}
		end
		local v239 = v237:GetAttribute("SoundBlocked")
		if v239 ~= v_u_235 then
			v_u_235 = v239
			v_u_236 = v_u_1.parseBlocked(v239)
		end
		return {
			["active"] = true,
			["music"] = nil,
			["track"] = nil,
			["start"] = nil,
			["rate"] = nil,
			["blocked"] = nil,
			["music"] = v238:GetAttribute("ClubMusic"),
			["track"] = v238:GetAttribute("ClubTrack"),
			["start"] = v238:GetAttribute("ClubStart"),
			["rate"] = v238:GetAttribute("ClubRate"),
			["blocked"] = v_u_236
		}
	end
	local v_u_240 = nil
	local function v_u_244() -- name: clubGroup
		-- upvalues: (copy) v_u_229
		local v241 = v_u_229:FindFirstChild("HushMaster")
		local v242 = v241 and v241:FindFirstChild("Ambience") or v_u_229
		local v243 = v242:FindFirstChild("ClubWorld")
		if v243 == nil then
			v243 = Instance.new("SoundGroup")
			v243.Name = "ClubWorld"
			v243.Volume = 1
			v243.Parent = v242
		end
		return v243
	end
	function v227.newVoice(p245)
		-- upvalues: (copy) v_u_244, (ref) v_u_1, (copy) v_u_232, (ref) v_u_240, (copy) v_u_229
		local v_u_246 = Instance.new("Sound")
		v_u_246.Name = "ClubMusic_" .. p245
		v_u_246.Looped = true
		v_u_246.Volume = 0
		v_u_246.PlaybackSpeed = 1
		v_u_246.SoundGroup = v_u_244()
		local v_u_247 = Instance.new("EqualizerSoundEffect")
		v_u_247.Name = "ClubEq"
		v_u_247.Parent = v_u_246
		local v_u_248 = Instance.new("ReverbSoundEffect")
		v_u_248.Name = "ClubReverb"
		v_u_248.Enabled = false
		v_u_248.Parent = v_u_246
		local v_u_249 = nil
		if p245 == "outer" then
			v_u_246.RollOffMode = Enum.RollOffMode.InverseTapered
			v_u_246.RollOffMinDistance = v_u_1.ROLL.min
			v_u_246.RollOffMaxDistance = v_u_1.ROLL.max
			v_u_249 = Instance.new("Attachment")
			v_u_249.Name = "ClubMusicEmitter"
			v_u_249.Parent = workspace.Terrain
			local v250 = v_u_232.ENTRANCE
			local v251 = v250.x
			local v252 = v250.y + v_u_1.EMITTER_DY
			local v253 = v250.z
			v_u_249.WorldPosition = Vector3.new(v251, v252, v253)
			v_u_246.Parent = v_u_249
		else
			if v_u_240 == nil or v_u_240.Parent == nil then
				v_u_240 = v_u_229:FindFirstChild("HushClubAudio")
				if v_u_240 == nil then
					v_u_240 = Instance.new("Folder")
					v_u_240.Name = "HushClubAudio"
					v_u_240.Parent = v_u_229
				end
			end
			v_u_246.Parent = v_u_240
		end
		local v_u_254 = {}
		return {
			["setId"] = function(_, p255) -- name: setId
				-- upvalues: (copy) v_u_246
				if v_u_246.SoundId ~= p255 then
					v_u_246.SoundId = p255
				end
			end,
			["isLoaded"] = function(_) -- name: isLoaded
				-- upvalues: (copy) v_u_246
				return v_u_246.IsLoaded
			end,
			["timeLength"] = function(_) -- name: timeLength
				-- upvalues: (copy) v_u_246
				return v_u_246.TimeLength
			end,
			["getPos"] = function(_) -- name: getPos
				-- upvalues: (copy) v_u_246
				return v_u_246.TimePosition
			end,
			["setPos"] = function(_, p256) -- name: setPos
				-- upvalues: (copy) v_u_246
				v_u_246.TimePosition = p256
			end,
			["play"] = function(_) -- name: play
				-- upvalues: (copy) v_u_246
				v_u_246:Play()
			end,
			["pause"] = function(_) -- name: pause
				-- upvalues: (copy) v_u_246
				v_u_246:Pause()
			end,
			["isPlaying"] = function(_) -- name: isPlaying
				-- upvalues: (copy) v_u_246
				return v_u_246.IsPlaying
			end,
			["setVolume"] = function(_, p257) -- name: setVolume
				-- upvalues: (copy) v_u_246, (copy) v_u_254
				local v258 = v_u_246
				local v259 = v_u_254.vol
				if v259 == nil then
					v_u_254.vol = p257
					v258.Volume = p257
					return
				else
					local v260 = v259 - p257
					if math.abs(v260) >= 0.002 then
						v_u_254.vol = p257
						v258.Volume = p257
					end
				end
			end,
			["setSpeed"] = function(_, p261) -- name: setSpeed
				-- upvalues: (copy) v_u_246
				v_u_246.PlaybackSpeed = p261
			end,
			["setEq"] = function(_, p262, p263, p264) -- name: setEq
				-- upvalues: (copy) v_u_247, (copy) v_u_254
				-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
				local v265, v266, v267, v268, v269, v270, v271, v272, v273
				local v274 = 7
				while true do
					if v274 == 1 then
						v_u_254.low = p262
						v273.LowGain = p262
						v266 = v_u_247
						v267 = v_u_254.mid
						if v267 == nil then
							v274 = 10
						else
							v274 = 4
						end
					elseif v274 == 2 then
						v268 = v265 - p262
						if math.abs(v268) >= 0.05 then
							v274 = 1
						else
							v274 = 8
						end
					elseif v274 == 3 then
						v_u_254.low = p262
						v273.LowGain = p262
						v266 = v_u_247
						v267 = v_u_254.mid
						if v267 == nil then
							v274 = 5
						else
							v274 = 4
						end
					elseif v274 == 4 then
						v269 = v267 - p263
						if math.abs(v269) >= 0.05 then
							v_u_254.mid = p263
							v266.MidGain = p263
							v270 = v_u_247
							v271 = v_u_254.high
							if v271 == nil then
								v_u_254.high = p264
								v270.HighGain = p264
								return
							end
						else
							v270 = v_u_247
							v271 = v_u_254.high
							if v271 == nil then
								v_u_254.high = p264
								v270.HighGain = p264
								return
							end
						end
						v274 = 6
					elseif v274 == 5 then
						v_u_254.mid = p263
						v266.MidGain = p263
						v270 = v_u_247
						v271 = v_u_254.high
						if v271 == nil then
							v_u_254.high = p264
							v270.HighGain = p264
							return
						end
						v274 = 6
					elseif v274 == 6 then
						v272 = v271 - p264
						if math.abs(v272) >= 0.05 then
							v_u_254.high = p264
							v270.HighGain = p264
						end
						break
					elseif v274 == 7 then
						v273 = v_u_247
						v265 = v_u_254.low
						if v265 == nil then
							v274 = 3
						else
							v274 = 2
						end
					elseif v274 == 8 then
						v266 = v_u_247
						v267 = v_u_254.mid
						if v267 == nil then
							v274 = 9
						else
							v274 = 4
						end
					elseif v274 == 9 then
						v_u_254.mid = p263
						v266.MidGain = p263
						v270 = v_u_247
						v271 = v_u_254.high
						if v271 == nil then
							v_u_254.high = p264
							v270.HighGain = p264
							return
						end
						v274 = 6
					else
						v_u_254.mid = p263
						v266.MidGain = p263
						v270 = v_u_247
						v271 = v_u_254.high
						if v271 == nil then
							v_u_254.high = p264
							v270.HighGain = p264
							return
						end
						v274 = 6
					end
				end
			end,
			["setReverb"] = function(_, p275, p276, p277, p278, p279, p280) -- name: setReverb
				-- upvalues: (copy) v_u_248, (copy) v_u_254
				-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
				local v281, v282, v283, v284, v285, v286, v287, v288, v289, v290, v291, v292, v293, v294, v295
				local v296 = 12
				while true do
					if v296 == 1 then
						v294 = v287 - p275
						if math.abs(v294) >= 0.01 then
							v296 = 11
						else
							v296 = 10
						end
					elseif v296 == 2 then
						v_u_254.decay = p275
						v293.DecayTime = p275
						v295 = v_u_248
						v281 = v_u_254.density
						if v281 == nil then
							v296 = 4
						else
							v296 = 3
						end
					elseif v296 == 3 then
						v282 = v281 - p276
						if math.abs(v282) >= 0.005 then
							v296 = 15
						else
							v296 = 16
						end
					elseif v296 == 4 then
						v_u_254.density = p276
						v295.Density = p276
						v283 = v_u_248
						v284 = v_u_254.diffusion
						if v284 == nil then
							v296 = 6
						else
							v296 = 5
						end
					elseif v296 == 5 then
						v285 = v284 - p277
						if math.abs(v285) >= 0.005 then
							v296 = 21
						else
							v296 = 22
						end
					elseif v296 == 6 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 8
						else
							v296 = 7
						end
					elseif v296 == 7 then
						v289 = v288 - p278
						if math.abs(v289) >= 0.05 then
							v_u_254.dry = p278
							v286.DryLevel = p278
							v290 = v_u_248
							v291 = v_u_254.wet
							if v291 == nil then
								v_u_254.wet = p279
								v290.WetLevel = p279
								if v_u_248.Enabled ~= p280 then
									v_u_248.Enabled = p280
								end
								return
							end
						else
							v290 = v_u_248
							v291 = v_u_254.wet
							if v291 == nil then
								v_u_254.wet = p279
								v290.WetLevel = p279
								if v_u_248.Enabled ~= p280 then
									v_u_248.Enabled = p280
								end
								return
							end
						end
						v296 = 9
					elseif v296 == 8 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					elseif v296 == 9 then
						v292 = v291 - p279
						if math.abs(v292) >= 0.05 then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
						elseif v_u_248.Enabled ~= p280 then
							v_u_248.Enabled = p280
						end
						break
					elseif v296 == 10 then
						v295 = v_u_248
						v281 = v_u_254.density
						if v281 == nil then
							v296 = 13
						else
							v296 = 3
						end
					elseif v296 == 11 then
						v_u_254.decay = p275
						v293.DecayTime = p275
						v295 = v_u_248
						v281 = v_u_254.density
						if v281 == nil then
							v296 = 14
						else
							v296 = 3
						end
					elseif v296 == 12 then
						v293 = v_u_248
						v287 = v_u_254.decay
						if v287 == nil then
							v296 = 2
						else
							v296 = 1
						end
					elseif v296 == 13 then
						v_u_254.density = p276
						v295.Density = p276
						v283 = v_u_248
						v284 = v_u_254.diffusion
						if v284 == nil then
							v296 = 18
						else
							v296 = 5
						end
					elseif v296 == 14 then
						v_u_254.density = p276
						v295.Density = p276
						v283 = v_u_248
						v284 = v_u_254.diffusion
						if v284 == nil then
							v296 = 19
						else
							v296 = 5
						end
					elseif v296 == 15 then
						v_u_254.density = p276
						v295.Density = p276
						v283 = v_u_248
						v284 = v_u_254.diffusion
						if v284 == nil then
							v296 = 20
						else
							v296 = 5
						end
					elseif v296 == 16 then
						v283 = v_u_248
						v284 = v_u_254.diffusion
						if v284 == nil then
							v296 = 17
						else
							v296 = 5
						end
					elseif v296 == 17 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 24
						else
							v296 = 7
						end
					elseif v296 == 18 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 25
						else
							v296 = 7
						end
					elseif v296 == 19 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 26
						else
							v296 = 7
						end
					elseif v296 == 20 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 27
						else
							v296 = 7
						end
					elseif v296 == 21 then
						v_u_254.diffusion = p277
						v283.Diffusion = p277
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 28
						else
							v296 = 7
						end
					elseif v296 == 22 then
						v286 = v_u_248
						v288 = v_u_254.dry
						if v288 == nil then
							v296 = 23
						else
							v296 = 7
						end
					elseif v296 == 23 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					elseif v296 == 24 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					elseif v296 == 25 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					elseif v296 == 26 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					elseif v296 == 27 then
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					else
						v_u_254.dry = p278
						v286.DryLevel = p278
						v290 = v_u_248
						v291 = v_u_254.wet
						if v291 == nil then
							v_u_254.wet = p279
							v290.WetLevel = p279
							if v_u_248.Enabled ~= p280 then
								v_u_248.Enabled = p280
							end
							return
						end
						v296 = 9
					end
				end
			end,
			["destroy"] = function(_) -- name: destroy
				-- upvalues: (copy) v_u_246, (ref) v_u_249
				v_u_246:Destroy()
				if v_u_249 then
					v_u_249:Destroy()
				end
			end
		}
	end
	local v_u_297 = {}
	function v227.preload(p_u_298)
		-- upvalues: (ref) v_u_240, (copy) v_u_229, (copy) v_u_297, (copy) v_u_230, (copy) p_u_226
		task.spawn(function()
			-- upvalues: (copy) p_u_298, (ref) v_u_240, (ref) v_u_229, (ref) v_u_297, (ref) v_u_230, (ref) p_u_226
			local v_u_299 = {}
			for _, v300 in p_u_298 do
				local v301 = Instance.new("Sound")
				v301.Name = "ClubWarm"
				v301.SoundId = v300
				v301.Volume = 0
				if v_u_240 == nil or v_u_240.Parent == nil then
					v_u_240 = v_u_229:FindFirstChild("HushClubAudio")
					if v_u_240 == nil then
						v_u_240 = Instance.new("Folder")
						v_u_240.Name = "HushClubAudio"
						v_u_240.Parent = v_u_229
					end
				end
				v301.Parent = v_u_240
				table.insert(v_u_299, v301)
				local v302 = v_u_297
				table.insert(v302, v301)
			end
			local function v308()
				-- upvalues: (ref) v_u_230, (copy) v_u_299, (ref) p_u_226
				v_u_230:PreloadAsync(v_u_299, function(p303, p304)
					-- upvalues: (ref) p_u_226
					local v305 = p_u_226
					if v305 then
						v305 = p_u_226.health
					end
					if v305 then
						local v306 = v305.onPreload
						if type(v306) == "function" then
							local v307 = v305.onPreload
							pcall(v307, p303, p304)
						end
					end
				end)
			end
			pcall(v308)
		end)
	end
	function v227.reportFail(p309, p310)
		-- upvalues: (copy) p_u_226
		local v311 = p_u_226
		if v311 then
			v311 = p_u_226.health
		end
		if v311 then
			local v312 = v311.report
			if type(v312) == "function" then
				local v313 = v311.report
				pcall(v313, p309, p310)
			end
		end
	end
	function v227.setRoomOverride(p314)
		-- upvalues: (copy) p_u_226
		local v315 = p_u_226
		if v315 then
			v315 = p_u_226.audio
		end
		if v315 then
			local v316 = v315.setRoomOverride
			if type(v316) == "function" then
				local v317 = v315.setRoomOverride
				pcall(v317, p314)
			end
		end
	end
	function v227.log(p318)
		warn("[HUSH:ClubAudio] " .. p318)
	end
	function v227.publish(p319)
		-- upvalues: (copy) v_u_231
		local v320 = v_u_231.LocalPlayer
		if v320 then
			v320:SetAttribute("ClubAudio", p319)
		end
	end
	function v227.dispose()
		-- upvalues: (copy) v_u_297
		for _, v_u_321 in v_u_297 do
			pcall(function()
				-- upvalues: (copy) v_u_321
				v_u_321:Destroy()
			end)
		end
		table.clear(v_u_297)
	end
	return v227
end
local v_u_322 = nil
local v_u_323 = 0
function v_u_1.instance() -- name: instance
	-- upvalues: (ref) v_u_322
	return v_u_322
end
function v_u_1._use(p324) -- name: _use
	-- upvalues: (ref) v_u_322
	v_u_322 = p324
end
function v_u_1.init(p_u_325, p326) -- name: init
	-- upvalues: (ref) v_u_322, (copy) v_u_1, (copy) v_u_4
	if v_u_322 ~= nil then
		return v_u_322
	end
	local v327 = p326 or {}
	local v328, v329 = pcall(function()
		-- upvalues: (copy) p_u_325
		return {
			["Rules"] = p_u_325.shared.ClubRules,
			["Tracks"] = p_u_325.shared.ClubTracks
		}
	end)
	if v328 then
		local v330 = v329.Rules
		if type(v330) == "table" then
			local v331 = v329.Tracks
			if type(v331) == "table" then
				local v332 = v329.Rules.audioAt
				if type(v332) == "function" then
					local v333 = v329.Tracks.get
					if type(v333) == "function" then
						local v334 = v_u_1.realApi(p_u_325, v327)
						v_u_322 = v_u_1.new(v334, v329)
						local v335 = v327.guard
						if v335 ~= nil then
							local v338 = {
								["world"] = true,
								["playing"] = nil,
								["wanted"] = nil,
								["stop"] = nil,
								["playing"] = function() -- name: playing
									-- upvalues: (ref) v_u_322
									local v336
									if v_u_322 == nil then
										v336 = false
									else
										v336 = v_u_322:isPlaying()
									end
									return v336
								end,
								["wanted"] = function() -- name: wanted
									-- upvalues: (ref) v_u_322
									local v337
									if v_u_322 == nil then
										v337 = false
									else
										v337 = v_u_322:wantsMusic()
									end
									return v337
								end,
								["stop"] = function(_) -- name: stop
									-- upvalues: (ref) v_u_322
									if v_u_322 then
										v_u_322:silence()
									end
								end
							}
							v_u_4(v335.register, "club_music", v338)
						end
						v_u_4(p_u_325.command, "club.audio", function(p339)
							-- upvalues: (ref) v_u_322
							if v_u_322 == nil then
								return "ClubAudio is not running"
							end
							if p339[1] ~= "at" then
								if p339[1] ~= "tracks" then
									return v_u_322:statusLine()
								end
								local v340 = v_u_322.T.TRACKS
								local v341 = {}
								for v342 = 1, #v340 do
									local v343 = v340[v342]
									local v344
									if v_u_322.T.playable(v343) then
										local v345 = v_u_322.T.numericId
										local v346 = v343.id
										v344 = tostring(v345(v346))
									else
										v344 = "-"
									end
									local v347 = v343.measured and "measured" or "NOT measured"
									local v348 = v_u_322.T.SIDE_B == v342 and " (Side B)" or ""
									local v349 = string.format
									local v350 = v343.key
									local v351 = tostring(v350)
									local v352 = v343.bpm
									local v353 = v343.offset
									local v354 = v343.length
									table.insert(v341, v349("%d %s id %s bpm %.2f off %.2f len %.1f %s%s", v342, v351, v344, v352, v353, v354, v347, v348))
								end
								return table.concat(v341, "\n")
							end
							local v355 = p339[2]
							local v356 = tonumber(v355)
							local v357 = p339[3]
							local v358 = tonumber(v357)
							local v359 = p339[4]
							local v360 = tonumber(v359)
							if not (v356 and (v358 and v360)) then
								return "usage: club.audio at <x> <y> <z>"
							end
							local v361 = v_u_322.R.audioAt(v356, v358, v360)
							local v362 = v361.reverb
							local v363 = string.format
							local v364 = v361.zone
							local v365 = tostring(v364)
							local v366 = v361.key
							return v363("zone %s key %s outer %.2f inner %.2f eq %.1f/%.1f/%.1f reverb %s%s", v365, tostring(v366), v361.outer, v361.inner, v361.low, v361.mid, v361.high, not v362 and "off" or string.format("%.1f/%.2f/%.2f/%.0f/%.0f", v362.decay, v362.density, v362.diffusion, v362.dry, v362.wet), not v361.t and "" or string.format(" stair t %.3f", v361.t))
						end)
						return v_u_322
					end
				end
			end
		end
	end
	warn("[HUSH:ClubAudio] shared/ClubRules or shared/ClubTracks is missing: no club music (sync the two files)")
	return nil
end
function v_u_1.step(p_u_367, p368, p_u_369, p370) -- name: step
	-- upvalues: (ref) v_u_322, (copy) v_u_1, (ref) v_u_323
	local v_u_371 = v_u_322
	if v_u_371 ~= nil then
		local v_u_372, v_u_373, v_u_374
		if p368 == nil then
			v_u_372 = nil
			v_u_373 = nil
			v_u_374 = nil
		else
			v_u_372 = p368.X
			v_u_373 = p368.Y
			v_u_374 = p368.Z
			if p370 == true and type(v_u_373) == "number" then
				v_u_373 = v_u_373 - v_u_1.HEAD_DY
			end
		end
		local function v381()
			-- upvalues: (copy) v_u_371, (copy) p_u_367, (ref) v_u_372, (ref) v_u_373, (ref) v_u_374, (copy) p_u_369
			local v375 = v_u_371
			local v376 = p_u_367
			local v377 = v_u_372
			local v378 = v_u_373
			local v379 = v_u_374
			local v380
			if p_u_369 == nil then
				v380 = false
			else
				v380 = p_u_369 ~= "Raid"
			end
			v375:step(v376, v377, v378, v379, v380)
		end
		local v382, v383 = pcall(v381)
		if not v382 then
			local v384 = v_u_371.api.clock()
			if v_u_371.errorLogAt == nil or v384 - v_u_371.errorLogAt > 5 then
				v_u_371.errorLogAt = v384
				v_u_371:log("step failed: " .. tostring(v383))
			end
			pcall(function()
				-- upvalues: (copy) v_u_371
				v_u_371:silence()
			end)
		end
		local v385 = v_u_371.api.clock()
		if v_u_323 <= v385 then
			local v386 = v_u_371.api.publish
			if type(v386) == "function" then
				v_u_323 = v385 + v_u_371.tune.status
				local v387 = v_u_371.api.publish
				pcall(v387, v_u_371:statusLine())
			end
		end
	end
end
function v_u_1.status() -- name: status
	-- upvalues: (ref) v_u_322
	if v_u_322 then
		return v_u_322:status()
	else
		return nil
	end
end
function v_u_1.destroy() -- name: destroy
	-- upvalues: (ref) v_u_322
	if v_u_322 then
		local v388 = v_u_322.api
		v_u_322:destroy()
		local v389 = v388.dispose
		if type(v389) == "function" then
			v388.dispose()
		end
		v_u_322 = nil
	end
end
return v_u_1