-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuReport

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("Players")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = {}
local v_u_6 = v3.LocalPlayer
local v_u_7 = nil
local function v_u_11(p8) -- name: cfgFlag
	-- upvalues: (copy) v_u_1
	if type(p8) == "table" then
		v10 = p8.config
	else
		v10 = nil
	end
	if type(v10) ~= "table" then
		v10 = require((v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Config")))
		return v10.flag("AntiCheat")
	end
	local v9 = v10.flag
	if type(v9) == "function" then
		return v10.flag("AntiCheat")
	end
	local v10 = require((v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Config")))
	return v10.flag("AntiCheat")
end
function v_u_5.available(p12) -- name: available
	-- upvalues: (copy) v_u_11
	local v13 = v_u_11
	local v14
	if type(p12) == "table" then
		v14 = p12.cctx
	else
		v14 = nil
	end
	local v15, v16 = pcall(v13, v14)
	return not v15 or v16 ~= "off"
end
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = false
function v_u_5.open(p20, p21) -- name: open
	-- upvalues: (copy) v_u_5, (ref) v_u_18, (ref) v_u_17, (ref) v_u_7, (copy) v_u_1, (copy) v_u_4, (copy) v_u_2
	local v_u_22 = type(p21) ~= "table" and {} or p21
	local v_u_23
	if type(p20) == "table" then
		local v24 = p20.cctx
		if type(v24) == "table" then
			v_u_23 = p20.cctx
		else
			v_u_23 = v_u_22.cctx
		end
	else
		v_u_23 = v_u_22.cctx
	end
	if type(v_u_23) ~= "table" or not v_u_5.available(p20) then
		return nil
	end
	v_u_18 = v_u_23
	if v_u_17 then
		local v25 = v_u_17.close
		pcall(v25)
	end
	local v_u_26
	if v_u_7 then
		v_u_26 = v_u_7
	else
		v_u_7 = require((v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReportRules")))
		v_u_26 = v_u_7
	end
	local v_u_27 = v_u_4.Theme
	local v_u_28 = v_u_27.color
	local v_u_29 = v_u_27.space
	local v30
	if v_u_22.hunt == true then
		local v31 = v_u_22.userId
		v30 = type(v31) == "number"
	else
		v30 = false
	end
	local v_u_32 = v_u_26.HUNT_TEXTS
	local function v37() -- name: huntLine
		-- upvalues: (copy) v_u_22, (copy) v_u_32
		local v33 = v_u_22.display
		local v34 = type(v33) ~= "string" and "" or v_u_22.display
		local v35 = v_u_22.name
		local v36 = type(v35) ~= "string" and "" or v_u_22.name
		if v34 == "" or (v36 == "" or v34 == v36) then
			if v36 == "" then
				if v34 == "" then
					return v_u_32.unknownPlayer
				else
					return v34
				end
			else
				return "@" .. v36
			end
		else
			return ("%s (@%s)"):format(v34, v36)
		end
	end
	local v_u_38 = {
		["target"] = nil,
		["targetName"] = nil,
		["cat"] = nil,
		["text"] = "",
		["busy"] = false,
		["sent"] = false,
		["list"] = nil,
		["loading"] = nil,
		["code"] = nil,
		["resultText"] = "",
		["resultKind"] = "info",
		["preset"] = nil,
		["off"] = false,
		["collapsed"] = false,
		["hunt"] = nil,
		["picked"] = nil
	}
	local v39 = v_u_22.userId
	local v40
	if type(v39) == "number" then
		v40 = v_u_22.userId
	else
		v40 = nil
	end
	v_u_38.target = v40
	local v41
	if v30 then
		v41 = v37()
	else
		local v42 = v_u_22.name
		v41 = type(v42) ~= "string" and "" or v_u_22.name
	end
	v_u_38.targetName = v41
	v_u_38.list = {}
	v_u_38.loading = not v30
	local v43 = v_u_22.userId
	v_u_38.preset = type(v43) == "number"
	v_u_38.hunt = v30
	v_u_38.picked = {}
	local v_u_44 = true
	local v_u_45 = {}
	local v_u_46 = nil
	local v_u_47 = nil
	local v_u_48 = nil
	local v_u_49 = nil
	local v_u_50 = nil
	local v_u_51 = {}
	local v_u_52 = {}
	local v_u_53 = {}
	local v_u_54 = nil
	local v_u_55 = nil
	local v_u_56 = nil
	local v_u_57 = nil
	local function v_u_63(p58, p59) -- name: setResult
		-- upvalues: (copy) v_u_38, (copy) v_u_26, (ref) v_u_49, (copy) v_u_27, (ref) v_u_44, (ref) v_u_46
		v_u_38.code = p58
		if p58 ~= nil then
			local v60, v61 = v_u_26.result(p58)
			local v62 = v_u_38
			if type(p59) == "string" and p59 ~= "" then
				v60 = p59
			end
			v62.resultText = v60
			v_u_38.resultKind = v61
			if v_u_49 then
				v_u_49.Text = v_u_38.resultText
				v_u_49.TextColor3 = v_u_27.kindColor(v_u_38.resultKind)
			end
			task.defer(function()
				-- upvalues: (ref) v_u_44, (ref) v_u_46
				if v_u_44 and (v_u_46 and v_u_46.body) then
					v_u_46.body.CanvasPosition = Vector2.new(0, 100000)
				end
			end)
		end
	end
	local function v_u_67() -- name: pickedList
		-- upvalues: (copy) v_u_26, (copy) v_u_38
		local v64 = {}
		for _, v65 in v_u_26.HUNT_REASONS do
			if v_u_38.picked[v65.id] ~= true then
				continue
			end
			local v66 = v65.id
			table.insert(v64, v66)
		end
		return v64
	end
	local function v_u_79() -- name: refresh
		-- upvalues: (ref) v_u_44, (copy) v_u_52, (copy) v_u_38, (copy) v_u_53, (copy) v_u_51, (copy) v_u_26, (ref) v_u_55, (ref) v_u_48, (copy) v_u_28, (ref) v_u_49
		if v_u_44 then
			for v68, v69 in v_u_52 do
				v69.api.setKind(v_u_38.cat == v68 and "primary" or "secondary")
			end
			for v70, v71 in v_u_53 do
				v71.api.setKind(v_u_38.target == v70 and "primary" or "secondary")
			end
			for v72, v73 in v_u_51 do
				local v74 = v_u_38.picked[v72] == true
				v73.api.setKind(v74 and "primary" or "secondary")
				v73.api.setSelected(v74)
			end
			local v75, v76 = v_u_26.sendState(v_u_38)
			if v_u_38.hunt then
				v75, v76 = v_u_26.huntSendState(v_u_38)
			end
			if v_u_55 then
				v_u_55.setEnabled(v75)
				v_u_55.setText(v_u_38.busy and "Sending" or (v_u_38.sent and "Sent" or "Send"))
			end
			if v_u_48 then
				v_u_48.Text = v_u_26.counter(v_u_26.length(v_u_38.text))
				local v77 = v_u_48
				local v78
				if v_u_26.length(v_u_38.text) > v_u_26.TEXT_MAX then
					v78 = v_u_28.danger
				else
					v78 = v_u_28.muted
				end
				v77.TextColor3 = v78
			end
			if v_u_49 and v_u_38.code == nil then
				if v_u_38.loading then
					v_u_49.Text = v_u_26.TEXTS.loading
					v_u_49.TextColor3 = v_u_28.text2
					return
				end
				v_u_49.Text = v76
				v_u_49.TextColor3 = v_u_28.text2
			end
		end
	end
	local v_u_80 = nil
	local function v_u_90(p81) -- name: pickTarget
		-- upvalues: (copy) v_u_38, (copy) v_u_27, (ref) v_u_4, (ref) v_u_80, (ref) v_u_46, (ref) v_u_44, (copy) v_u_79
		if not (v_u_38.busy or v_u_38.sent) then
			v_u_38.target = p81
			if p81 then
				for _, v82 in v_u_38.list do
					if v82.userId ~= p81 then
						continue
					end
					v_u_38.targetName = v82.display ~= "" and v82.display or v82.name
				end
				local v83 = v_u_38
				local v84 = v_u_27.isPhone()
				if v84 then
					if v_u_4.device() == "Gamepad" then
						v84 = false
					else
						v84 = #v_u_38.list > 1
					end
				end
				v83.collapsed = v84
				v_u_80()
				if v_u_27.isPhone() then
					local v_u_85 = "CatHead"
					task.defer(function()
						-- upvalues: (ref) v_u_46, (copy) v_u_85, (ref) v_u_44
						local v86
						if v_u_46 then
							v86 = v_u_46.body
						else
							v86 = nil
						end
						local v87
						if v_u_46 then
							v87 = v_u_46.frame:FindFirstChild(v_u_85, true)
						else
							v87 = nil
						end
						if v_u_44 and (v86 and (v86.Parent and v87)) then
							local v88 = Vector2.new
							local v89 = v87.AbsolutePosition.Y - v86.AbsolutePosition.Y + v86.CanvasPosition.Y - 4
							v86.CanvasPosition = v88(0, (math.max(0, v89)))
						end
					end)
				end
			end
			if v_u_38.code ~= nil and v_u_38.code ~= "ok" then
				v_u_38.code = nil
			end
			v_u_79()
		end
	end
	v_u_80 = function() -- name: rebuildWho
		-- upvalues: (ref) v_u_50, (ref) v_u_44, (copy) v_u_53, (copy) v_u_38, (ref) v_u_4, (copy) v_u_26, (copy) v_u_28, (copy) v_u_29, (ref) v_u_80, (copy) v_u_79, (copy) v_u_90
		local v91 = v_u_50
		if v91 and v_u_44 then
			for _, v92 in v91:GetChildren() do
				if v92:IsA("UIListLayout") then
					continue
				end
				v92:Destroy()
			end
			table.clear(v_u_53)
			if v_u_38.preset then
				local v93
				if v_u_38.targetName == "" then
					local v94 = v_u_38.target
					v93 = "Player " .. tostring(v94)
				else
					v93 = v_u_38.targetName
				end
				v_u_4.label({
					["parent"] = nil,
					["name"] = "ReportTarget",
					["text"] = nil,
					["style"] = "bodyStrong",
					["autoY"] = true,
					["wrap"] = true,
					["order"] = 1,
					["parent"] = v91,
					["text"] = v93
				})
				return
			elseif v_u_38.loading then
				v_u_4.label({
					["parent"] = nil,
					["name"] = "ReportLoading",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["autoY"] = true,
					["wrap"] = true,
					["order"] = 1,
					["parent"] = v91,
					["text"] = v_u_26.TEXTS.loading,
					["color"] = v_u_28.text2
				})
				return
			elseif #v_u_38.list == 0 then
				local v95 = v_u_4.label
				local v96 = {
					["parent"] = nil,
					["name"] = "ReportNone",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["autoY"] = true,
					["wrap"] = true,
					["order"] = 1,
					["parent"] = v91
				}
				local v97
				if v_u_38.off then
					v97 = v_u_26.TEXTS.off
				else
					v97 = v_u_26.TEXTS.none
				end
				v96.text = v97
				v96.color = v_u_28.text2
				v95(v96)
				return
			elseif v_u_38.collapsed and v_u_38.target ~= nil then
				local v98 = v_u_4.new("Frame", {
					["Name"] = "ReportTargetRow",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v91)
				v_u_4.layout(v98, "h", v_u_29.m)
				local v99 = v_u_4.label
				local v100 = {
					["parent"] = nil,
					["name"] = "ReportTarget",
					["text"] = nil,
					["style"] = "bodyStrong",
					["autoX"] = true,
					["maxSize"] = nil,
					["order"] = 1,
					["parent"] = v98
				}
				local v101
				if v_u_38.targetName == "" then
					local v102 = v_u_38.target
					v101 = "Player " .. tostring(v102)
				else
					v101 = v_u_38.targetName
				end
				v100.text = v101
				v100.maxSize = Vector2.new(300, 60)
				v99(v100)
				local v103 = {
					["parent"] = nil,
					["name"] = "ReportChange",
					["text"] = "Change",
					["kind"] = "secondary",
					["height"] = 40,
					["order"] = 2,
					["onClick"] = nil,
					["parent"] = v98,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_38, (ref) v_u_80, (ref) v_u_79
						v_u_38.collapsed = false
						v_u_80()
						v_u_79()
					end
				}
				v_u_4.button(v103)
			else
				local v104 = v_u_4.new("Frame", {
					["Name"] = "ReportPlayers",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v91)
				v_u_4.new("UIListLayout", {
					["FillDirection"] = nil,
					["Wraps"] = true,
					["SortOrder"] = nil,
					["Padding"] = nil,
					["VerticalAlignment"] = nil,
					["FillDirection"] = Enum.FillDirection.Horizontal,
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Padding"] = UDim.new(0, v_u_29.s),
					["VerticalAlignment"] = Enum.VerticalAlignment.Top
				}, v104)
				for v105, v_u_106 in v_u_38.list do
					local v107
					if v_u_106.display == "" or v_u_106.display == v_u_106.name then
						if v_u_106.name == "" then
							local v108 = v_u_106.userId
							v107 = "Player " .. tostring(v108)
						else
							v107 = v_u_106.name
						end
					else
						v107 = ("%s (%s)"):format(v_u_106.display, v_u_106.name)
					end
					local v109 = v_u_4.button
					local v110 = {
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["kind"] = "secondary",
						["height"] = 40,
						["order"] = nil,
						["maxTextWidth"] = 240,
						["onClick"] = nil,
						["parent"] = v104
					}
					local v111 = v_u_106.userId
					v110.name = "Player_" .. tostring(v111)
					v110.text = v107
					v110.order = v105
					function v110.onClick() -- name: onClick
						-- upvalues: (ref) v_u_90, (copy) v_u_106
						v_u_90(v_u_106.userId)
					end
					local v112, v113 = v109(v110)
					v_u_53[v_u_106.userId] = {
						["btn"] = v112,
						["api"] = v113
					}
				end
			end
		else
			return
		end
	end
	local function v_u_115(p114) -- name: tickReason
		-- upvalues: (copy) v_u_38, (copy) v_u_26, (copy) v_u_79
		if not v_u_38.busy and (not v_u_38.sent and v_u_26.huntReasonById(p114) ~= nil) then
			v_u_38.picked[p114] = v_u_38.picked[p114] ~= true and true or nil
			if v_u_38.code ~= nil and v_u_38.code ~= "ok" then
				v_u_38.code = nil
			end
			v_u_79()
		end
	end
	local function v_u_122(p116) -- name: buildHunt
		-- upvalues: (ref) v_u_4, (copy) v_u_32, (copy) v_u_28, (ref) v_u_50, (copy) v_u_29, (copy) v_u_26, (copy) v_u_115, (copy) v_u_51, (ref) v_u_49
		v_u_4.label({
			["parent"] = nil,
			["name"] = "WhoHead",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["parent"] = p116,
			["text"] = v_u_32.playerHead,
			["color"] = v_u_28.text2
		})
		v_u_50 = v_u_4.new("Frame", {
			["Name"] = "Who",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p116)
		v_u_4.layout(v_u_50, "v", v_u_29.s)
		v_u_4.label({
			["parent"] = nil,
			["name"] = "CatHead",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["order"] = 3,
			["parent"] = p116,
			["text"] = v_u_32.reasonHead,
			["color"] = v_u_28.text2
		})
		local v117 = v_u_4.new("Frame", {
			["Name"] = "ReportReasons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 4,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p116)
		v_u_4.new("UIListLayout", {
			["FillDirection"] = nil,
			["Wraps"] = true,
			["SortOrder"] = nil,
			["Padding"] = nil,
			["VerticalAlignment"] = nil,
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, v_u_29.s),
			["VerticalAlignment"] = Enum.VerticalAlignment.Top
		}, v117)
		for v118, v_u_119 in v_u_26.HUNT_REASONS do
			local v120, v121 = v_u_4.button({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = 44,
				["order"] = nil,
				["maxTextWidth"] = 260,
				["onClick"] = nil,
				["parent"] = v117,
				["name"] = "Reason_" .. v_u_119.id,
				["text"] = v_u_119.label,
				["order"] = v118,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_115, (copy) v_u_119
					v_u_115(v_u_119.id)
				end
			})
			v_u_51[v_u_119.id] = {
				["btn"] = v120,
				["api"] = v121
			}
		end
		v_u_49 = v_u_4.label({
			["parent"] = nil,
			["name"] = "ReportResult",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 8,
			["track"] = false,
			["parent"] = p116,
			["color"] = v_u_28.text2
		})
	end
	local function v138(p123) -- name: build
		-- upvalues: (copy) v_u_38, (copy) v_u_122, (ref) v_u_4, (copy) v_u_28, (ref) v_u_50, (copy) v_u_29, (copy) v_u_26, (copy) v_u_27, (ref) v_u_46, (ref) v_u_44, (copy) v_u_79, (copy) v_u_52, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49
		if v_u_38.hunt then
			v_u_122(p123)
		else
			v_u_4.label({
				["parent"] = nil,
				["name"] = "WhoHead",
				["text"] = "Player",
				["style"] = "caps",
				["color"] = nil,
				["order"] = 1,
				["parent"] = p123,
				["color"] = v_u_28.text2
			})
			v_u_50 = v_u_4.new("Frame", {
				["Name"] = "Who",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, p123)
			v_u_4.layout(v_u_50, "v", v_u_29.s)
			v_u_4.label({
				["parent"] = nil,
				["name"] = "CatHead",
				["text"] = "What happened",
				["style"] = "caps",
				["color"] = nil,
				["order"] = 3,
				["parent"] = p123,
				["color"] = v_u_28.text2
			})
			local v124 = v_u_4.new("Frame", {
				["Name"] = "ReportCategories",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 4,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, p123)
			v_u_4.new("UIListLayout", {
				["FillDirection"] = nil,
				["Wraps"] = true,
				["SortOrder"] = nil,
				["Padding"] = nil,
				["VerticalAlignment"] = nil,
				["FillDirection"] = Enum.FillDirection.Horizontal,
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Padding"] = UDim.new(0, v_u_29.s),
				["VerticalAlignment"] = Enum.VerticalAlignment.Top
			}, v124)
			for v125, v_u_126 in v_u_26.catList() do
				local v133, v134 = v_u_4.button({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["kind"] = "secondary",
					["height"] = 40,
					["order"] = nil,
					["maxTextWidth"] = 240,
					["onClick"] = nil,
					["parent"] = v124,
					["name"] = "Cat_" .. v_u_126.id,
					["text"] = v_u_126.label,
					["order"] = v125,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_126, (ref) v_u_38, (ref) v_u_27, (ref) v_u_46, (ref) v_u_44, (ref) v_u_79
						local v127 = v_u_126.id
						if not v_u_38.busy then
							if v_u_38.sent then
								return
							end
							v_u_38.cat = v127
							if v_u_27.isPhone() then
								local v_u_128 = "TextHead"
								task.defer(function()
									-- upvalues: (ref) v_u_46, (copy) v_u_128, (ref) v_u_44
									local v129
									if v_u_46 then
										v129 = v_u_46.body
									else
										v129 = nil
									end
									local v130
									if v_u_46 then
										v130 = v_u_46.frame:FindFirstChild(v_u_128, true)
									else
										v130 = nil
									end
									if v_u_44 and (v129 and (v129.Parent and v130)) then
										local v131 = Vector2.new
										local v132 = v130.AbsolutePosition.Y - v129.AbsolutePosition.Y + v129.CanvasPosition.Y - 4
										v129.CanvasPosition = v131(0, (math.max(0, v132)))
									end
								end)
							end
							if v_u_38.code ~= nil and v_u_38.code ~= "ok" then
								v_u_38.code = nil
							end
							v_u_79()
						end
					end
				})
				v_u_52[v_u_126.id] = {
					["btn"] = v133,
					["api"] = v134
				}
			end
			v_u_4.label({
				["parent"] = nil,
				["name"] = "TextHead",
				["text"] = "In your own words",
				["style"] = "caps",
				["color"] = nil,
				["order"] = 5,
				["parent"] = p123,
				["color"] = v_u_28.text2
			})
			local v135, v_u_136 = v_u_4.input({
				["parent"] = nil,
				["name"] = "ReportText",
				["size"] = nil,
				["placeholder"] = "Tell us what happened",
				["parent"] = p123,
				["size"] = UDim2.new(1, 0, 0, v_u_27.touch(96))
			})
			v135.LayoutOrder = 6
			v_u_136.MultiLine = true
			v_u_136.TextWrapped = true
			v_u_136.TextTruncate = Enum.TextTruncate.None
			v_u_136.TextYAlignment = Enum.TextYAlignment.Top
			v_u_136.Position = UDim2.fromOffset(12, 8)
			v_u_136.Size = UDim2.new(1, -24, 1, -16)
			v_u_47 = v_u_136
			v_u_48 = v_u_4.label({
				["parent"] = nil,
				["name"] = "ReportCounter",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "right",
				["size"] = nil,
				["track"] = false,
				["order"] = 7,
				["parent"] = p123,
				["text"] = v_u_26.counter(0),
				["color"] = v_u_28.muted,
				["size"] = UDim2.new(1, 0, 0, 14)
			})
			v_u_136:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_44, (copy) v_u_136, (ref) v_u_26, (ref) v_u_38, (ref) v_u_79
				if v_u_44 then
					local v137 = v_u_136.Text
					if v_u_26.length(v137) > v_u_26.TEXT_MAX then
						v_u_136.Text = v_u_26.clip(v137, v_u_26.TEXT_MAX)
					else
						v_u_38.text = v137
						if v_u_38.code ~= nil and v_u_38.code ~= "ok" then
							v_u_38.code = nil
						end
						v_u_79()
					end
				else
					return
				end
			end)
			v_u_49 = v_u_4.label({
				["parent"] = nil,
				["name"] = "ReportResult",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 8,
				["track"] = false,
				["parent"] = p123,
				["color"] = v_u_28.text2
			})
		end
	end
	local function v146() -- name: footerButtons
		-- upvalues: (ref) v_u_46, (ref) v_u_4, (copy) v_u_45, (ref) v_u_56, (ref) v_u_54, (ref) v_u_55
		local v139
		if v_u_46 then
			v139 = v_u_46.frame:FindFirstChild("Buttons", true)
		else
			v139 = nil
		end
		if v139 then
			for _, v140 in v139:GetChildren() do
				if not v140:IsA("GuiButton") then
					continue
				end
				v140:Destroy()
			end
			local v141 = {
				["parent"] = nil,
				["name"] = "ReportCancel",
				["text"] = "Cancel",
				["kind"] = "secondary",
				["order"] = 1,
				["onClick"] = nil,
				["parent"] = v139,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_45
					v_u_45.cancel()
				end
			}
			local _, v142 = v_u_4.button(v141)
			v_u_56 = v142
			local v143 = {
				["parent"] = nil,
				["name"] = "ReportSend",
				["text"] = "Send",
				["kind"] = "primary",
				["order"] = 2,
				["onClick"] = nil,
				["parent"] = v139,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_45
					v_u_45.send()
				end
			}
			local v144, v145 = v_u_4.button(v143)
			v_u_54 = v144
			v_u_55 = v145
		end
	end
	function v_u_45.close() -- name: close
		-- upvalues: (ref) v_u_44, (ref) v_u_17, (copy) v_u_45, (ref) v_u_57, (ref) v_u_46
		if v_u_44 then
			v_u_44 = false
			if v_u_17 == v_u_45 then
				v_u_17 = nil
			end
			if v_u_57 then
				local function v147()
					-- upvalues: (ref) v_u_57
					v_u_57:Disconnect()
				end
				pcall(v147)
				v_u_57 = nil
			end
			if v_u_46 then
				local v148 = v_u_46.close
				pcall(v148)
			end
		end
	end
	function v_u_45.cancel() -- name: cancel
		-- upvalues: (copy) v_u_45
		v_u_45.close()
	end
	function v_u_45.pick(p149) -- name: pick
		-- upvalues: (copy) v_u_90
		v_u_90(p149)
	end
	function v_u_45.cat(p150) -- name: cat
		-- upvalues: (copy) v_u_38, (copy) v_u_27, (ref) v_u_46, (ref) v_u_44, (copy) v_u_79
		if not v_u_38.busy then
			if v_u_38.sent then
				return
			end
			v_u_38.cat = p150
			if v_u_27.isPhone() then
				local v_u_151 = "TextHead"
				task.defer(function()
					-- upvalues: (ref) v_u_46, (copy) v_u_151, (ref) v_u_44
					local v152
					if v_u_46 then
						v152 = v_u_46.body
					else
						v152 = nil
					end
					local v153
					if v_u_46 then
						v153 = v_u_46.frame:FindFirstChild(v_u_151, true)
					else
						v153 = nil
					end
					if v_u_44 and (v152 and (v152.Parent and v153)) then
						local v154 = Vector2.new
						local v155 = v153.AbsolutePosition.Y - v152.AbsolutePosition.Y + v152.CanvasPosition.Y - 4
						v152.CanvasPosition = v154(0, (math.max(0, v155)))
					end
				end)
			end
			if v_u_38.code ~= nil and v_u_38.code ~= "ok" then
				v_u_38.code = nil
			end
			v_u_79()
		end
	end
	function v_u_45.type(p156) -- name: type
		-- upvalues: (ref) v_u_47
		if v_u_47 then
			v_u_47.Text = p156
		end
	end
	function v_u_45.tick(p157) -- name: tick
		-- upvalues: (copy) v_u_115
		v_u_115(p157)
	end
	function v_u_45.send() -- name: send
		-- upvalues: (ref) v_u_44, (copy) v_u_38, (copy) v_u_26, (copy) v_u_63, (copy) v_u_79, (copy) v_u_23, (copy) v_u_67, (copy) v_u_22, (ref) v_u_56, (copy) v_u_45
		if v_u_44 and not (v_u_38.busy or v_u_38.sent) then
			local v158, v159 = v_u_26.sendState(v_u_38)
			if v_u_38.hunt then
				v158, v159 = v_u_26.huntSendState(v_u_38)
			end
			if v158 then
				v_u_38.busy = true
				v_u_63("busy")
				v_u_79()
				task.spawn(function()
					-- upvalues: (ref) v_u_38, (ref) v_u_23, (ref) v_u_26, (ref) v_u_67, (ref) v_u_22, (ref) v_u_44, (ref) v_u_63, (ref) v_u_56, (ref) v_u_45, (ref) v_u_79
					local v160
					if v_u_38.hunt then
						local v161 = v_u_23
						local v162 = {
							["userId"] = v_u_38.target,
							["reasons"] = v_u_26.huntClean((v_u_67()))
						}
						local v163
						if type(v161) == "table" then
							v163 = v161.net
						else
							v163 = nil
						end
						if type(v163) == "table" then
							local v164 = v163.invoke
							if type(v164) == "function" then
								local v165 = v163.invoke
								local v166
								v166, v160 = pcall(v165, "report.hunt", v162)
								if not v166 or type(v160) ~= "table" then
									v160 = nil
								end
							else
								v160 = nil
							end
						else
							v160 = nil
						end
					else
						local v167 = v_u_23
						local v168 = {
							["userId"] = v_u_38.target,
							["cat"] = v_u_38.cat,
							["text"] = v_u_38.text,
							["raidId"] = v_u_22.raidId
						}
						local v169
						if type(v167) == "table" then
							v169 = v167.net
						else
							v169 = nil
						end
						if type(v169) == "table" then
							local v170 = v169.invoke
							if type(v170) == "function" then
								local v171 = v169.invoke
								local v172
								v172, v160 = pcall(v171, "report.send", v168)
								if not v172 or type(v160) ~= "table" then
									v160 = nil
								end
							else
								v160 = nil
							end
						else
							v160 = nil
						end
					end
					v_u_38.busy = false
					if v_u_44 then
						if v160 == nil then
							v_u_63("err")
						elseif v160.ok == true then
							v_u_38.sent = true
							v_u_63("ok", v160.text)
							if v_u_56 then
								v_u_56.setText("Close")
							end
							task.delay(2.6, function()
								-- upvalues: (ref) v_u_44, (ref) v_u_38, (ref) v_u_45
								if v_u_44 and v_u_38.sent then
									v_u_45.close()
								end
							end)
						else
							local v173 = v_u_63
							local v174 = v160.code
							v173(type(v174) ~= "string" and "err" or v160.code, v160.text)
						end
						v_u_79()
					end
				end)
			else
				v_u_63(v_u_38.hunt and "reasons" or "bad", v159)
			end
		else
			return
		end
	end
	function v_u_45.state() -- name: state
		-- upvalues: (copy) v_u_26, (copy) v_u_38, (copy) v_u_51, (copy) v_u_67, (ref) v_u_47, (ref) v_u_46, (ref) v_u_48, (ref) v_u_54
		local v175, v176 = v_u_26.sendState(v_u_38)
		if v_u_38.hunt then
			v175, v176 = v_u_26.huntSendState(v_u_38)
		end
		local v177 = 0
		for _ in v_u_51 do
			v177 = v177 + 1
		end
		local v178 = {
			["hunt"] = v_u_38.hunt,
			["picked"] = v_u_67(),
			["reasonButtons"] = v177
		}
		local v179
		if v_u_47 == nil then
			if v_u_46 == nil then
				v179 = false
			else
				v179 = v_u_46.frame:FindFirstChildWhichIsA("TextBox", true) ~= nil
			end
		else
			v179 = true
		end
		v178.hasTextBox = v179
		v178.target = v_u_38.target
		v178.targetName = v_u_38.targetName
		v178.cat = v_u_38.cat
		v178.textLen = v_u_26.length(v_u_38.text)
		v178.sendEnabled = v175
		v178.hint = v176
		v178.busy = v_u_38.busy
		v178.sent = v_u_38.sent
		v178.loading = v_u_38.loading
		v178.players = #v_u_38.list
		v178.code = v_u_38.code
		v178.result = v_u_38.resultText
		v178.counter = not v_u_48 and "" or v_u_48.Text
		v178.preset = v_u_38.preset
		v178.off = v_u_38.off
		v178.windowW = not v_u_46 and 0 or v_u_46.frame.AbsoluteSize.X
		v178.windowH = not v_u_46 and 0 or v_u_46.frame.AbsoluteSize.Y
		v178.sendH = not v_u_54 and 0 or v_u_54.AbsoluteSize.Y
		return v178
	end
	v_u_46 = v_u_4.modal({
		["title"] = nil,
		["body"] = nil,
		["width"] = 540,
		["dismissable"] = false,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["title"] = not v_u_38.hunt and "Report a player" or v_u_32.windowTitle,
		["body"] = not v_u_38.hunt and "Tell us what happened. Only the game team reads your report, other players never see it." or v_u_32.windowBody,
		["build"] = v138,
		["buttons"] = {
			{
				["text"] = "Cancel",
				["kind"] = "secondary"
			},
			{
				["text"] = "Send",
				["kind"] = "primary"
			}
		},
		["onClose"] = function() -- name: onClose
			-- upvalues: (ref) v_u_44, (ref) v_u_17, (copy) v_u_45, (ref) v_u_57, (copy) v_u_22, (copy) v_u_38
			v_u_44 = false
			if v_u_17 == v_u_45 then
				v_u_17 = nil
			end
			if v_u_57 then
				local function v180()
					-- upvalues: (ref) v_u_57
					v_u_57:Disconnect()
				end
				pcall(v180)
				v_u_57 = nil
			end
			local v181 = v_u_22.onClose
			if type(v181) == "function" then
				task.spawn(v_u_22.onClose, v_u_38.sent)
			end
		end
	})
	v_u_17 = v_u_45
	v_u_45.modal = v_u_46
	v146()
	local function v183()
		-- upvalues: (ref) v_u_57, (ref) v_u_44, (ref) v_u_47, (copy) v_u_45
		v_u_57 = require(script.Parent:WaitForChild("VirtualPad")).InputBegan:Connect(function(p182)
			-- upvalues: (ref) v_u_44, (ref) v_u_47, (ref) v_u_45
			if p182.KeyCode == Enum.KeyCode.ButtonB and (v_u_44 and not (v_u_47 and v_u_47:IsFocused())) then
				v_u_45.cancel()
			end
		end)
	end
	pcall(v183)
	local function v189() -- name: padStart
		-- upvalues: (ref) v_u_44, (ref) v_u_4, (copy) v_u_38, (copy) v_u_26, (copy) v_u_51, (copy) v_u_52, (ref) v_u_2, (ref) v_u_46
		if v_u_44 and v_u_4.device() == "Gamepad" then
			local v184
			if v_u_38.hunt then
				v184 = v_u_26.HUNT_REASONS[1]
			else
				v184 = v_u_26.catList()[1]
			end
			local v185
			if v_u_38.hunt then
				v185 = v_u_51
			else
				v185 = v_u_52
			end
			local v_u_186
			if v184 and v185[v184.id] then
				v_u_186 = v185[v184.id].btn
			else
				v_u_186 = nil
			end
			local v187 = v_u_2.SelectedObject
			if v_u_186 and (v187 == nil or not v187:IsDescendantOf(v_u_46.frame)) then
				v_u_186:SetAttribute("PadDefault", true)
				local function v188()
					-- upvalues: (ref) v_u_2, (copy) v_u_186
					v_u_2.SelectedObject = v_u_186
				end
				pcall(v188)
			end
		end
	end
	task.defer(v189)
	task.delay(0.4, v189)
	task.delay(1.2, v189)
	v_u_80()
	v_u_79()
	task.spawn(function()
		-- upvalues: (copy) v_u_38, (copy) v_u_22, (copy) v_u_23, (ref) v_u_44, (copy) v_u_63, (ref) v_u_80, (copy) v_u_79
		if v_u_38.hunt then
			return
		else
			local v190 = {}
			local v191 = v_u_22.raidId
			if type(v191) == "string" and v_u_22.raidId ~= "" then
				v190.raidId = v_u_22.raidId
			end
			if v_u_38.preset then
				v190.userId = v_u_38.target
			end
			local v192 = v_u_23
			local v193
			if type(v192) == "table" then
				v193 = v192.net
			else
				v193 = nil
			end
			local v194
			if type(v193) == "table" then
				local v195 = v193.invoke
				if type(v195) == "function" then
					local v196 = v193.invoke
					local v197
					v197, v194 = pcall(v196, "report.roster", v190)
					if not v197 or type(v194) ~= "table" then
						v194 = nil
					end
				else
					v194 = nil
				end
			else
				v194 = nil
			end
			if v_u_44 then
				v_u_38.loading = false
				if v194 == nil then
					v_u_63("err")
				else
					v_u_38.off = v194.off == true
					local v198 = v194.list
					if type(v198) == "table" then
						for _, v199 in v194.list do
							if type(v199) ~= "table" then
								continue
							end
							local v200 = v199.userId
							if type(v200) ~= "number" then
								continue
							end
							local v201 = v_u_38.list
							local v202 = {
								["userId"] = v199.userId
							}
							local v203 = v199.name or ""
							v202.name = tostring(v203)
							local v204 = v199.display or ""
							v202.display = tostring(v204)
							table.insert(v201, v202)
						end
					end
					if v194.ok == true or v194.code == "none" then
						if v_u_38.preset and #v_u_38.list > 0 then
							local v205 = v_u_38.list[1]
							local v206 = v_u_38
							local v207
							if v205.display == "" then
								if v205.name == "" then
									v207 = v_u_38.targetName
								else
									v207 = v205.name
								end
							else
								v207 = v205.display
							end
							v206.targetName = v207
						elseif not v_u_38.preset and #v_u_38.list == 1 then
							v_u_38.target = v_u_38.list[1].userId
							local v208 = v_u_38
							local v209
							if v_u_38.list[1].display == "" then
								v209 = v_u_38.list[1].name
							else
								v209 = v_u_38.list[1].display
							end
							v208.targetName = v209
						end
					else
						local v210 = v_u_63
						local v211 = v194.code
						v210(type(v211) ~= "string" and "err" or v194.code, v194.text)
						if v_u_38.preset then
							v_u_38.target = nil
						end
					end
				end
				v_u_80()
				v_u_79()
			end
		end
	end)
	v_u_5._registerCommands(v_u_23)
	return v_u_45
end
function v_u_5.state() -- name: state
	-- upvalues: (ref) v_u_17
	if v_u_17 then
		return v_u_17.state()
	else
		return nil
	end
end
function v_u_5.openHunt(p212, p213) -- name: openHunt
	-- upvalues: (copy) v_u_5
	if type(p213) == "table" then
		local v214 = p213.userId
		if type(v214) == "number" then
			local v215 = table.clone(p213)
			v215.hunt = true
			local v216 = v_u_5.open(p212, v215)
			if v216 then
				v216.isHunt = true
			end
			return v216
		end
	end
	return nil
end
function v_u_5.closeHunt() -- name: closeHunt
	-- upvalues: (ref) v_u_17
	local v217 = v_u_17
	if v217 and v217.isHunt == true then
		local v218 = v217.close
		pcall(v218)
	end
end
function v_u_5.attachDebrief(p_u_219, p_u_220, p221, p_u_222) -- name: attachDebrief
	-- upvalues: (copy) v_u_5, (ref) v_u_18, (copy) v_u_4
	if v_u_5.available(p_u_219) and type(p_u_219) == "table" then
		local v223 = p_u_219.cctx
		if type(v223) == "table" then
			local v_u_224 = p_u_219.cctx
			v_u_18 = v_u_224
			v_u_5._registerCommands(v_u_224)
			local v_u_225
			if type(p221) == "table" then
				local v226 = p221.raidId
				if type(v226) == "string" and p221.raidId ~= "" then
					v_u_225 = p221.raidId
				else
					v_u_225 = nil
				end
			else
				v_u_225 = nil
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_224, (copy) v_u_225, (copy) p_u_220, (ref) v_u_4, (copy) p_u_219, (copy) p_u_222, (ref) v_u_5
				local v227 = v_u_224
				local v228 = v_u_225 and {
					["raidId"] = v_u_225
				} or {}
				local v229
				if type(v227) == "table" then
					v229 = v227.net
				else
					v229 = nil
				end
				local v230
				if type(v229) == "table" then
					local v231 = v229.invoke
					if type(v231) == "function" then
						local v232 = v229.invoke
						local v233
						v233, v230 = pcall(v232, "report.roster", v228)
						if not v233 or type(v230) ~= "table" then
							v230 = nil
						end
					else
						v230 = nil
					end
				else
					v230 = nil
				end
				if type(v230) == "table" and v230.ok == true then
					local v234 = v230.list
					if type(v234) == "table" and #v230.list ~= 0 then
						if p_u_220.Parent then
							local v235 = v_u_4.Theme
							local v236 = v235.color
							local function v237()
								-- upvalues: (ref) p_u_219, (ref) p_u_220, (ref) p_u_222
								p_u_219.kit.section(p_u_220, "Report a player", p_u_222)
							end
							pcall(v237)
							local v238 = v_u_4.new("Frame", {
								["Name"] = "ReportRow",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.new(1, 0, 0, 0),
								["AutomaticSize"] = Enum.AutomaticSize.Y,
								["LayoutOrder"] = p_u_222 + 1
							}, p_u_220)
							v_u_4.layout(v238, "v", v235.space.s)
							v_u_4.label({
								["parent"] = nil,
								["name"] = "ReportHelp",
								["text"] = "Did someone break the rules in this raid? Tell us what happened. Only the game team reads it.",
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 1,
								["parent"] = v238,
								["color"] = v236.text2
							})
							local v240 = {
								["parent"] = nil,
								["name"] = "ReportPlayer",
								["text"] = "Report a player",
								["kind"] = "secondary",
								["height"] = 44,
								["order"] = 2,
								["onClick"] = nil,
								["parent"] = v238,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_5, (ref) p_u_219, (ref) v_u_225
									local v239 = {
										["raidId"] = v_u_225
									}
									v_u_5.open(p_u_219, v239)
								end
							}
							v_u_4.button(v240)
						end
					end
				end
			end)
			return
		end
	end
end
function v_u_5.partyButton(p_u_241, p_u_242) -- name: partyButton
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	if v_u_5.available(p_u_241) and (type(p_u_242) == "table" and p_u_242.fake ~= true) then
		local v243 = p_u_242.userId
		if type(v243) == "number" and p_u_242.userId ~= v_u_6.UserId then
			if type(p_u_241) == "table" then
				local v244 = p_u_241.cctx
				if type(v244) == "table" then
					v_u_5._registerCommands(p_u_241.cctx)
				end
			end
			return {
				["text"] = "Report",
				["kind"] = "secondary",
				["onClick"] = nil,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_5, (copy) p_u_241, (copy) p_u_242
					local v245 = v_u_5.open
					local v246 = p_u_241
					local v247 = {
						["userId"] = p_u_242.userId
					}
					local v248 = p_u_242.displayName or (p_u_242.name or "")
					v247.name = tostring(v248)
					v245(v246, v247)
				end
			}
		end
	end
	return nil
end
function v_u_5._registerCommands(p_u_249) -- name: _registerCommands
	-- upvalues: (ref) v_u_19, (copy) v_u_5, (ref) v_u_18, (ref) v_u_17
	if not v_u_19 and type(p_u_249) == "table" then
		local v250 = p_u_249.command
		if type(v250) == "function" then
			v_u_19 = true
			local function v301()
				-- upvalues: (copy) p_u_249, (ref) v_u_5, (ref) v_u_18, (ref) v_u_17
				p_u_249.command("report.ui", function(p251)
					-- upvalues: (ref) v_u_5, (ref) v_u_18, (ref) p_u_249, (ref) v_u_17
					local v252 = p251[1] or "state"
					if v252 == "open" then
						local v253 = p251[2]
						local v254 = tonumber(v253)
						local v255 = v_u_5.open
						local v256 = {
							["cctx"] = v_u_18 or p_u_249
						}
						local v257 = {
							["userId"] = v254
						}
						local v258
						if v254 then
							v258 = table.concat(p251, " ", 3)
						else
							v258 = nil
						end
						v257.name = v258
						return v255(v256, v257) and "opened" or "not available (switch off?)"
					end
					if v252 == "hunt" then
						local v259 = p251[2]
						local v260 = tonumber(v259)
						local v261 = {
							["cctx"] = v_u_18 or p_u_249
						}
						return v_u_5.openHunt(v261, {
							["userId"] = v260,
							["name"] = p251[3],
							["display"] = p251[4]
						}) and "hunt window opened" or "not available (switch off? killer id?)"
					end
					local v262 = v_u_17
					if not v262 then
						return "no report window"
					end
					if v252 == "pick" then
						local v263 = v262.pick
						local v264 = p251[2]
						v263(tonumber(v264) or 0)
						return "picked"
					end
					if v252 == "cat" then
						v262.cat(p251[2] or "")
						return "category set"
					end
					if v252 == "tick" then
						v262.tick(p251[2] or "")
						return "reason toggled"
					end
					if v252 == "type" then
						v262.type(table.concat(p251, " ", 2))
						return "typed"
					end
					if v252 == "send" then
						v262.send()
						return "send pressed"
					end
					if v252 == "cancel" or v252 == "close" then
						v262.cancel()
						return "closed"
					end
					local v265 = v262.state()
					local v266 = v265.target
					local v267 = tostring(v266)
					local v268 = v265.targetName
					local v269 = tostring(v268)
					local v270 = v265.cat
					local v271 = tostring(v270)
					local v272 = v265.textLen
					local v273 = v265.sendEnabled
					local v274 = tostring(v273)
					local v275 = v265.hint
					local v276 = tostring(v275)
					local v277 = v265.busy
					local v278 = tostring(v277)
					local v279 = v265.sent
					local v280 = tostring(v279)
					local v281 = v265.loading
					local v282 = tostring(v281)
					local v283 = v265.players
					local v284 = v265.code
					local v285 = tostring(v284)
					local v286 = v265.result
					local v287 = tostring(v286)
					local v288 = v265.counter
					local v289 = tostring(v288)
					local v290 = v265.preset
					local v291 = tostring(v290)
					local v292 = v265.off
					local v293 = tostring(v292)
					local v294 = v265.windowW
					local v295 = v265.windowH
					local v296 = v265.sendH
					local v297 = v265.hunt
					local v298 = tostring(v297)
					local v299 = table.concat(v265.picked, ",")
					local v300 = v265.hasTextBox
					return ("target=%s name=[%s] cat=%s textLen=%d sendEnabled=%s hint=[%s] busy=%s sent=%s loading=%s players=%d code=%s result=[%s] counter=[%s] preset=%s off=%s window=%dx%d sendH=%d hunt=%s picked=[%s] textBox=%s"):format(v267, v269, v271, v272, v274, v276, v278, v280, v282, v283, v285, v287, v289, v291, v293, v294, v295, v296, v298, v299, (tostring(v300)))
				end)
			end
			pcall(v301)
			return
		end
	end
end
return v_u_5