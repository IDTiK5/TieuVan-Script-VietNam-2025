-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketData

local v_u_691 = {
	["CODES"] = {
		["OFF_LIST"] = "The Blackmarket is not taking new listings right now.",
		["OFF_BUY"] = "Buying is switched off right now.",
		["FREEZE"] = "The Blackmarket is paused. Your items and Cash are safe.",
		["SCOPE"] = "The Blackmarket is not open for you yet.",
		["DISABLED"] = "The Blackmarket is not available.",
		["BUSY"] = "Another market action is still running. Try again in a moment.",
		["RATE"] = "Slow down a little.",
		["MUTED"] = "Too many requests. The market is paused for you for a minute.",
		["BAD"] = "That request is not valid.",
		["COOLDOWN"] = "You can buy again in {wait} s.",
		["LIMIT"] = "No listings left today. They come back in {resetIn}.",
		["CASH"] = "Not enough Cash. You need ${need} more.",
		["STASH_FULL"] = "Your stash is full. Make room first.",
		["GONE"] = "This listing is gone. Someone was faster, or it was cancelled.",
		["PRICE"] = "The price changed to ${price}. Check it and try again.",
		["OWN"] = "That is your own listing.",
		["PAID_BLOCKED"] = "Paid item. Trading is not available for your account.",
		["PAID_ITEM"] = "This item cannot be traded.",
		["GIFT"] = "Gift items can\'t be sold or traded.",
		["POLICY_WAIT"] = "Your account is still being checked. Try again in a moment.",
		["RAIDS"] = "Finish a raid first.",
		["TUTORIAL"] = "Finish the tutorial first.",
		["PROFILE"] = "Your profile is still loading.",
		["TEMP"] = "Your profile is not saved right now. Try again later.",
		["RAID"] = "Not available during a raid.",
		["STORE"] = "The market could not be reached. Nothing was lost. Try again.",
		["NOT_STASH"] = "Only items in your stash can be listed.",
		["UNKNOWN_ITEM"] = "This item cannot be traded.",
		["NO_TRADE_CLASS"] = "This kind of item cannot be traded.",
		["STRIP_FIRST"] = "Remove the attachments first.",
		["SPLIT_FIRST"] = "Split the pair first.",
		["EMPTY_FIRST"] = "Empty it first. Only empty bags, rigs and crates can be listed.",
		["INSURED"] = "Insured items cannot be listed.",
		["QTY"] = "Wrong amount.",
		["PRICE_RANGE"] = "The price must be at least $1 per unit and at most $99,999,999.",
		["RECORDS_FULL"] = "You have too many open listings. Cancel or claim some first.",
		["MARKET_FULL"] = "Too many cheaper listings of this item. Lower your price.",
		["SOLD"] = "Already sold. Claim your Cash.",
		["NOT_MINE"] = "That is not one of your listings.",
		["NOTHING"] = "Nothing to claim right now.",
		["REVIEW"] = "A transaction is being checked. Your items and Cash are safe.",
		["RANGE_TAKEN"] = "All lots within your limit were taken. The cheapest now costs ${price} each.",
		["NO_RANGE"] = "No lot costs that little. The cheapest costs ${price} each.",
		["NOBODY"] = "Nobody is selling this right now.",
		["RANGE_RACE"] = "Other buyers were faster. Try again to take the next lot.",
		["RANGE_GONE"] = "All lots within your limit were taken. Nobody else is selling this right now.",
		["TOTAL_MOVED"] = "Prices changed. Check the new total."
	},
	["TEXT"] = {
		["closed"] = "The Blackmarket is closed right now.",
		["working"] = "Working on it. Your Cash is held safely.",
		["workingList"] = "Working on it. Your item is held safely.",
		["scopeClosed"] = "The Blackmarket is not open for you yet.",
		["blockedAccount"] = "The Blackmarket is not available for your account.",
		["pricesDown"] = "Prices are not available right now.",
		["storeDown"] = "The market is not reachable right now. Your listings and Cash are safe.",
		["storeBusy"] = "The market is busy. Prices may be a little old.",
		["inReview"] = "In review. Your items and Cash are safe.",
		["notShown"] = "Not shown yet: cheaper listings come first.",
		["nobody"] = "Nobody is selling anything right now. Be the first.",
		["noSales"] = "No sales yet",
		["notEnoughSales"] = "Not enough sales yet",
		["noSalesWeek"] = "No sales this week",
		["salesLoading"] = "Loading the sales list",
		["salesMissing"] = "The sales list is not available right now.",
		["noListings"] = "No listings",
		["noMine"] = "You have no listings. Open SELL to list something.",
		["bought"] = "Bought. It is in your stash.",
		["boughtStash"] = "Bought. It is in your stash.",
		["boughtMail"] = "Bought. It is waiting in your mail.",
		["listed"] = "Listed. It is on the market now.",
		["settingAside"] = "Setting your Cash aside",
		["buying"] = "Buying",
		["cashSetAside"] = "The Cash is set aside until the sale is done.",
		["intro"] = "List items for Cash. Other players buy them. Listings last 3 days.",
		["listFeeLine"] = "Listing fee {fee}: paid now, never paid back.",
		["listFeeConfirm"] = "Listing fee {fee}. You pay it now. It is not paid back if you cancel or the listing runs out.",
		["capLine"] = "No sales history yet: the most you can ask for this lot is {max}.",
		["capConfirm"] = "No sales history yet, so this lot can cost at most {max}.",
		["capUnknown"] = "If this item has no sales history, the most you can ask for this lot is {max}.",
		["cancelFeeNote"] = "A listing fee you paid is not paid back.",
		["bestButton"] = "Buy cheapest",
		["bestSub"] = "with a price limit",
		["bestTitle"] = "Buy the cheapest",
		["bestLimit"] = "Highest price per unit you accept",
		["bestPays"] = "You pay the real price of the lot you get, never more than your limit per unit. There is no change to give back.",
		["bestPaysShort"] = "You pay the real price of the lot you get, never more than your limit per unit.",
		["bestTries"] = "If a lot is taken first, the next lot within your limit is tried, up to 3 times.",
		["bestNow"] = "The cheapest lot costs {unit} each right now.",
		["bestWithin"] = "{n} lots are within your limit.",
		["bestWithinOne"] = "1 lot is within your limit.",
		["bestNone"] = "No lot is within your limit. Raise it.",
		["bestFirst"] = "First choice: {desc} for {unit} each, {total} in all.",
		["bestFirstOne"] = "First choice: {desc} for {total}.",
		["bestMost"] = "If a lot is taken first, the most you could pay for one lot is {total}.",
		["bestMostShort"] = "At most {total} for one lot.",
		["bestPaid"] = "You paid {total}.",
		["bestGoodOnly"] = "Only lots in good condition.",
		["bestWithinGood"] = "{n} lots in good condition are within your limit.",
		["bestWithinGoodOne"] = "1 lot in good condition is within your limit.",
		["bestNoneGood"] = "No lot in good condition is within your limit. Raise it.",
		["bestTriesShort"] = "If a lot is taken first, the next one is tried.",
		["bestMoved"] = "Prices changed. Check the new total.",
		["bestAge"] = "The list is {age} old.",
		["bestLooking"] = "Looking for the cheapest lot",
		["bestBuy"] = "Buy cheapest",
		["bestChange"] = "Change limit",
		["lostClose"] = "Someone was faster. This is the next cheapest lot.",
		["lostRose"] = "Someone was faster. The next lot costs more: {unit} each instead of {was} each (up {pct} percent). Check it before you buy.",
		["priceMoved"] = "The price changed. This is the current offer.",
		["nobodyLeft"] = "Someone was faster. Nobody else is selling this right now."
	},
	["commas"] = function(p1) -- name: commas
		local v2 = math.abs(p1) + 0.5
		local v3 = math.floor(v2)
		local v4 = tostring(v3)
		local v5 = string.reverse((string.gsub(string.reverse(v4), "(%d%d%d)", "%1,")))
		if string.sub(v5, 1, 1) == "," then
			v5 = string.sub(v5, 2)
		end
		return (p1 < 0 and "-" or "") .. v5
	end,
	["money"] = function(p6) -- name: money
		-- upvalues: (copy) v_u_691
		return "$" .. v_u_691.commas(p6 or 0)
	end,
	["fill"] = function(p7, p_u_8) -- name: fill
		-- upvalues: (copy) v_u_691
		if type(p_u_8) == "table" then
			return string.gsub(p7, "{(%w+)}", function(p9)
				-- upvalues: (copy) p_u_8, (ref) v_u_691
				local v10 = p_u_8[p9]
				if v10 == nil then
					return nil
				end
				if type(v10) ~= "number" then
					return tostring(v10)
				end
				if p9 ~= "wait" then
					return v_u_691.commas(v10)
				end
				local v11 = math.ceil(v10)
				return tostring(v11)
			end)
		else
			return p7
		end
	end,
	["rulesOf"] = function(p_u_12) -- name: rulesOf
		-- upvalues: (copy) v_u_691
		local v_u_13 = nil
		local function v14()
			-- upvalues: (ref) v_u_13, (copy) p_u_12
			v_u_13 = p_u_12.cctx.shared.BmRules
		end
		pcall(v14)
		local v15 = v_u_13
		if type(v15) == "table" then
			local v16 = v_u_13.text
			if type(v16) == "function" then
				return v_u_13
			end
		end
		return {
			["stand"] = true,
			["CODES"] = nil,
			["TUNE"] = nil,
			["text"] = nil,
			["CODES"] = v_u_691.CODES,
			["TUNE"] = {
				["maxPrice"] = 99999999,
				["minPrice"] = 1,
				["feePct"] = 5,
				["listingDays"] = 3,
				["buyCooldown"] = 30,
				["minRaids"] = 3,
				["goodCondition"] = 70,
				["detailPage"] = 25
			},
			["text"] = function(p17, p18) -- name: text
				-- upvalues: (ref) v_u_691
				local v19 = v_u_691.CODES[p17] or v_u_691.MORE[p17]
				if v19 then
					return v_u_691.fill(v19, p18)
				else
					return tostring(p17)
				end
			end
		}
	end,
	["MORE"] = {
		["MAIL_FULL"] = "Your mail already holds 10 Blackmarket deliveries. Move them to your stash first.",
		["LIST_FEE_CASH"] = "Not enough Cash for the listing fee of ${fee}. You need ${need} more.",
		["PRICE_CAP"] = "This item has no sales history yet, so this lot can cost at most ${max}."
	},
	["BOOK"] = {
		["ORDERS_FULL"] = "You have too many open buy orders. Cancel some first.",
		["BAND_HIGH"] = "That price is too high. The most you can offer is ${max} each.",
		["BAND_LOW"] = "That price is too low. The least you can offer is ${min} each.",
		["CROSSES"] = "A listing for ${ask} each is already cheaper. Buy it now instead.",
		["CROSSES_BID"] = "A buy order of ${bid} each is waiting. Sell now at that price.",
		["NO_BIDS"] = "Nobody wants this right now.",
		["ORDER_GONE"] = "That order was filled first. Try the next one.",
		["COND"] = "Buy orders for weapons and armor only take items in good condition.",
		["BOOK_BUSY"] = "The order book is busy. Try again in a moment.",
		["FILL_DAY_CAP"] = "You reached today\'s limit for selling into buy orders.",
		["NONE_FILLABLE"] = "Orders exist but none could be filled. Try again.",
		["PENDING"] = "Your sale is still being completed. It will finish by itself.",
		["CLOCK"] = "The server clock looks wrong. Try again later.",
		["QTY_STACK"] = "You can order at most 20 of an item that does not stack.",
		["MAKE_ROOM"] = "Your mail is full. Collect some deliveries first (TO STASH). The items wait in the order.",
		["REVIEW"] = "Buy orders are paused for your account while we check something. The rest of the market still works.",
		["DRAIN"] = "Buy orders are closed. Your open orders end and the money comes back to your Cash.",
		["OFF_BOOK"] = "Buy orders are switched off right now. Your open orders stay as they are."
	},
	["CRATE"] = {
		["CRATE_BUY"] = "Buying cases is not available for your account because of Roblox rules for random items. You can still sell cases.",
		["CRATE_TRADE"] = "Cases cannot be traded on your account.",
		["CRATE_PAID"] = "This case cannot be traded.",
		["CRATE_SCANNED"] = "A scanned case cannot be traded.",
		["OFF_CRATES"] = "Trading cases is switched off right now.",
		["POLICY_FAIL"] = "We could not check your account. Rejoin to try again.",
		["RESTOCK_CRATE"] = "That case is not part of a restock."
	},
	["CRATE_SHORT"] = {
		["CRATE_BUY"] = "Not for your account",
		["CRATE_TRADE"] = "Cannot be traded",
		["CRATE_PAID"] = "Cannot be traded",
		["CRATE_SCANNED"] = "Cannot be traded",
		["OFF_CRATES"] = "Switched off",
		["POLICY_WAIT"] = "Checking your account",
		["POLICY_FAIL"] = "Account check failed",
		["RESTOCK_CRATE"] = "Not part of it"
	},
	["cm"] = nil,
	["text"] = function(p20, p21, p22) -- name: text
		-- upvalues: (copy) v_u_691
		if type(p21) == "string" then
			if v_u_691.CRATE[p21] == nil then
				if v_u_691.BOOK[p21] == nil then
					local v23 = p20.text
					local v24, v25 = pcall(v23, p21, p22)
					if v24 and (type(v25) == "string" and v25 ~= "") then
						return v25
					else
						return v_u_691.fill(v_u_691.CODES[p21] or (v_u_691.MORE[p21] or p21), p22)
					end
				else
					local v26 = p20.bookText
					if type(v26) == "function" then
						local v27 = p20.bookText
						local v28, v29 = pcall(v27, p21, p22)
						if v28 and (type(v29) == "string" and v29 ~= "") then
							return v29
						end
					end
					return v_u_691.fill(v_u_691.BOOK[p21], p22)
				end
			else
				local v30
				if v_u_691.cm == nil then
					v30 = nil
				else
					local v31 = v_u_691.cm.TEXT
					if type(v31) == "table" then
						v30 = v_u_691.cm.TEXT[p21]
					else
						v30 = nil
					end
				end
				local v32 = v_u_691.fill
				if type(v30) ~= "string" or v30 == "" then
					v30 = v_u_691.CRATE[p21]
				end
				return v32(v30, p22)
			end
		else
			return v_u_691.CODES.STORE
		end
	end,
	["BOOK_NOTES"] = {
		["ordered"] = "Order placed: {n} x {name} at ${u} each. ${p} is set aside.",
		["hitBid"] = "Sold: {n} x {name} at ${u} each. ${net} added to your Cash.",
		["hitBidPart"] = "Sold {taken} of {n} x {name} at ${u} each. ${net} added to your Cash.",
		["orderFilled"] = "Your order was filled: {n} x {name} at ${u} each. It is waiting in your mail.",
		["orderFilledMail"] = "Your order was filled: {n} x {name} at ${u} each. It is waiting in your mail.",
		["orderFilledFull"] = "Your order was filled: {n} x {name}. Your mail is full, so it waits in the order until you collect some deliveries.",
		["orderEnded"] = "Your order for {name} ended. ${p} is back in your Cash."
	},
	["bookNote"] = function(p33, p34, p35) -- name: bookNote
		-- upvalues: (copy) v_u_691
		if type(p33) == "table" then
			local v36 = p33.bookNoteText
			if type(v36) == "function" then
				local v37 = p33.bookNoteText
				local v38, v39 = pcall(v37, p34, p35)
				if v38 and (type(v39) == "string" and v39 ~= "") then
					return v39
				end
			end
		end
		local v40 = v_u_691.BOOK_NOTES[p34]
		if v40 == nil then
			return ""
		end
		local v_u_41 = type(p35) ~= "table" and {} or p35
		return string.gsub(v40, "{(%w+)}", function(p42)
			-- upvalues: (copy) v_u_41, (ref) v_u_691
			local v43 = v_u_41[p42]
			if v43 == nil then
				return "?"
			elseif type(v43) == "number" and p42 ~= "name" then
				return v_u_691.commas(v43)
			else
				return tostring(v43)
			end
		end)
	end,
	["unitMoney"] = function(p44) -- name: unitMoney
		-- upvalues: (copy) v_u_691
		if type(p44) ~= "number" or p44 ~= p44 then
			return "$0"
		end
		if p44 < 100 then
			local v45 = p44 + 0.5
			local v46 = p44 - math.floor(v45)
			if math.abs(v46) >= 0.005 then
				return "$" .. string.format("%.2f", p44)
			end
		end
		local v47 = v_u_691.money
		local v48 = p44 + 0.5
		return v47((math.floor(v48)))
	end,
	["duration"] = function(p49) -- name: duration
		local v50 = (p49 or 0) + 0.5
		local v51 = math.floor(v50)
		local v52 = math.max(0, v51)
		if v52 >= 172800 then
			return ("%d d"):format(v52 // 86400)
		elseif v52 >= 86400 then
			local v53 = v52 % 86400 // 3600
			return v53 <= 0 and "1 d" or ("1 d %d h"):format(v53)
		elseif v52 >= 3600 then
			local v54 = v52 % 3600 // 60
			if v54 > 0 then
				return ("%d h %d min"):format(v52 // 3600, v54)
			else
				return ("%d h"):format(v52 // 3600)
			end
		elseif v52 >= 60 then
			return ("%d min"):format(v52 // 60)
		else
			return ("%d s"):format(v52)
		end
	end,
	["ago"] = function(p55) -- name: ago
		local v56 = (p55 or 0) + 0.5
		local v57 = math.floor(v56)
		local v58 = math.max(0, v57)
		if v58 < 45 then
			return "just now"
		elseif v58 < 3600 then
			local v59 = v58 // 60
			return ("%d min ago"):format((math.max(1, v59)))
		elseif v58 < 86400 then
			return ("%d h ago"):format(v58 // 3600)
		else
			return ("%d d ago"):format(v58 // 86400)
		end
	end,
	["columnsFor"] = function(p60, p61) -- name: columnsFor
		return p61 and 2 or (p60 >= 1700 and 6 or (p60 >= 1200 and 4 or (p60 >= 900 and 3 or 2)))
	end,
	["chip"] = function(p62, p63) -- name: chip
		-- upvalues: (copy) v_u_691
		if type(p62) ~= "table" then
			return {
				["kind"] = "loading",
				["text"] = "..."
			}
		end
		if p62.ok == false then
			local v64 = {
				["kind"] = "closed",
				["text"] = "CLOSED",
				["reason"] = nil
			}
			local v65 = p62.text
			local v66
			if type(v65) == "string" and p62.text ~= "" then
				v66 = p62.text
			else
				v66 = v_u_691.text(p63, p62.code or "STORE")
			end
			v64.reason = v66
			return v64
		end
		local v67 = p62.on
		local v68 = type(v67) ~= "table" and {} or p62.on
		local v69 = p62.can
		local v70 = type(v69) ~= "table" and {} or p62.can
		local v71 = v70.text
		local v72
		if type(v71) == "string" and v70.text ~= "" then
			v72 = v70.text
		elseif v70.why then
			v72 = v_u_691.text(p63, v70.why)
		else
			v72 = nil
		end
		if v68.freeze == true then
			return {
				["kind"] = "paused",
				["text"] = "PAUSED",
				["reason"] = nil,
				["reason"] = v_u_691.text(p63, "FREEZE")
			}
		end
		if p62.restrictedMode == "block" and p62.restricted == true then
			return {
				["kind"] = "closed",
				["text"] = "CLOSED",
				["reason"] = nil,
				["blocked"] = true,
				["reason"] = v_u_691.TEXT.blockedAccount
			}
		end
		if v68.scope == false then
			return {
				["kind"] = "closed",
				["text"] = "CLOSED",
				["reason"] = nil,
				["reason"] = v_u_691.text(p63, "SCOPE")
			}
		end
		local v73 = v70.list ~= false
		local v74 = v70.buy ~= false
		local v75
		if v68.buy == nil then
			v75 = v74
		else
			v75 = v68.buy ~= false
		end
		if v70.why == "COOLDOWN" then
			v72 = nil
			v75 = true
		elseif v70.why == "LIMIT" then
			v72 = nil
			v73 = true
		elseif v70.why ~= "OFF_LIST" then
			v75 = v74
		end
		if v70.why == "TUTORIAL" or v70.why == "RAIDS" then
			return {
				["kind"] = "closed",
				["text"] = "LOCKED",
				["reason"] = nil,
				["reason"] = v72 or v_u_691.text(p63, v70.why)
			}
		end
		if v73 or v75 then
			return v73 and v75 and {
				["kind"] = "open",
				["text"] = "OPEN"
			} or {
				["kind"] = "limited",
				["text"] = nil,
				["reason"] = nil,
				["text"] = v75 and "BUY ONLY" or "SELL ONLY",
				["reason"] = v72 or v_u_691.text(p63, v75 and "OFF_LIST" or "OFF_BUY")
			}
		end
		local v76 = {
			["kind"] = "closed",
			["text"] = "CLOSED",
			["reason"] = nil
		}
		local v77
		if (v70.why == nil or (v70.why == "OFF_LIST" or (v70.why == "OFF_BUY" or (v70.why == "DISABLED" or v70.why == "COOLDOWN")))) and true or v70.why == "LIMIT" then
			v77 = v_u_691.TEXT.closed
		else
			v77 = v72 or v_u_691.TEXT.closed
		end
		v76.reason = v77
		return v76
	end,
	["banner"] = function(p78) -- name: banner
		-- upvalues: (copy) v_u_691
		if type(p78) == "table" then
			return p78.ds == "down" and {
				["kind"] = "down",
				["text"] = nil,
				["text"] = v_u_691.TEXT.storeDown
			} or (p78.ds == "busy" and {
				["kind"] = "busy",
				["text"] = nil,
				["text"] = v_u_691.TEXT.storeBusy
			} or nil)
		else
			return nil
		end
	end,
	["serverNow"] = function(p79, p80) -- name: serverNow
		if type(p79) == "table" then
			local v81 = p79.now
			if type(v81) == "number" then
				local v82 = p79.now
				local v83 = 0
				local v84 = p79._at
				local v85
				if type(v84) == "number" then
					v85 = p79._at
				else
					v85 = p80
				end
				local v86 = p80 - v85
				return v82 + math.max(v83, v86)
			end
		end
		return nil
	end,
	["left"] = function(p87, p88, p89) -- name: left
		if type(p87) == "table" then
			local v90 = p87[p88]
			if type(v90) == "number" then
				local v91 = p87._at
				local v92
				if type(v91) == "number" then
					v92 = p87._at
				else
					v92 = p89
				end
				local v93 = p87[p88]
				local v94 = p89 - v92
				local v95 = v93 - math.max(0, v94)
				return math.max(0, v95)
			end
		end
		return 0
	end,
	["isCrateItem"] = function(p96) -- name: isCrateItem
		-- upvalues: (copy) v_u_691
		if type(p96) == "table" then
			p96 = p96.id
		end
		if type(p96) ~= "string" then
			return false
		end
		local v97 = v_u_691.cm
		if v97 ~= nil then
			local v98 = v97.isCrate
			if type(v98) == "function" then
				local v99 = v97.isCrate
				local v100, v101 = pcall(v99, p96)
				if v100 then
					v100 = v101 == true
				end
				return v100
			end
		end
		return string.sub(p96, 1, 11) == "skin_crate_"
	end,
	["crateGate"] = function(p102, p103, p_u_104) -- name: crateGate
		-- upvalues: (copy) v_u_691
		local v_u_105
		if type(p102) == "table" then
			local v106 = p102.crate
			if type(v106) == "table" then
				v_u_105 = p102.crate
			else
				v_u_105 = nil
			end
		else
			v_u_105 = nil
		end
		local function v112(p107) -- name: refuse
			-- upvalues: (copy) v_u_105, (ref) v_u_691, (copy) p_u_104
			local v108
			if v_u_105 == nil or p107 ~= v_u_105.why then
				v108 = nil
			else
				local v109 = v_u_105.text
				if type(v109) == "string" and v_u_105.text ~= "" then
					v108 = v_u_105.text
				else
					v108 = nil
				end
			end
			local v110
			if v_u_105 == nil or p107 ~= v_u_105.why then
				v110 = nil
			else
				local v111 = v_u_105.short
				if type(v111) == "string" and v_u_105.short ~= "" then
					v110 = v_u_105.short
				else
					v110 = nil
				end
			end
			return {
				["why"] = p107,
				["text"] = v108 or v_u_691.text(p_u_104, p107),
				["short"] = v110 or (v_u_691.CRATE_SHORT[p107] or "Unavailable")
			}
		end
		if v_u_105 == nil then
			return v112("POLICY_WAIT")
		end
		if v_u_105[p103] == true and v_u_105.tab ~= false then
			return nil
		end
		local v113 = v_u_105.why
		return v112((type(v113) ~= "string" or v113 == "") and (v_u_105.tab == false and "CRATE_TRADE" or "POLICY_WAIT") or v113)
	end,
	["buyButton"] = function(p114, p115, p116, p117, p118, p119) -- name: buyButton
		-- upvalues: (copy) v_u_691
		if type(p115) == "table" and p115.own == true then
			return {
				["show"] = false,
				["enabled"] = false,
				["why"] = "OWN"
			}
		elseif type(p114) == "table" and p114.ok ~= false then
			if p114.ds == "down" then
				return {
					["show"] = true,
					["enabled"] = false,
					["reason"] = nil,
					["short"] = "Unavailable",
					["why"] = "STORE",
					["reason"] = v_u_691.text(p118, "STORE")
				}
			else
				local v120 = v_u_691.chip(p114, p118)
				if v120.kind == "paused" then
					return {
						["show"] = true,
						["enabled"] = false,
						["reason"] = nil,
						["short"] = "Paused",
						["why"] = "FREEZE",
						["reason"] = v120.reason
					}
				else
					local v121 = p114.can
					local v122 = type(v121) ~= "table" and {} or p114.can
					if v120.blocked then
						return {
							["show"] = true,
							["enabled"] = false,
							["reason"] = nil,
							["short"] = "Not available",
							["why"] = "PAID_BLOCKED",
							["reason"] = v120.reason
						}
					else
						if v_u_691.isCrateItem(p119) then
							local v123 = v_u_691.crateGate(p114, "buy", p118)
							if v123 ~= nil then
								return {
									["show"] = true,
									["enabled"] = false,
									["reason"] = nil,
									["short"] = nil,
									["why"] = nil,
									["reason"] = v123.text,
									["short"] = v123.short,
									["why"] = v123.why
								}
							end
						end
						local v124 = p114.on
						local v125 = type(v124) ~= "table" and {} or p114.on
						local v126 = (v122.why == "COOLDOWN" or v122.why == "LIMIT") and true or v122.why == "OFF_LIST"
						local v127
						if v122.why == "COOLDOWN" then
							v127 = false
						elseif v126 then
							v127 = v125.buy == false
						else
							v127 = v122.buy == false
						end
						if v127 or v125.scope == false then
							local v128 = v126 and "OFF_BUY" or (v122.why or (v125.scope == false and "SCOPE" or "OFF_BUY"))
							local v129
							if v126 then
								if v120.kind == "closed" then
									v129 = v_u_691.TEXT.closed
								else
									v129 = v_u_691.text(p118, "OFF_BUY")
								end
							else
								local v130 = v122.text
								if type(v130) == "string" and v122.text ~= "" then
									v129 = v122.text
								elseif v128 == "SCOPE" then
									v129 = v_u_691.TEXT.scopeClosed
								elseif v120.kind == "closed" then
									v129 = v_u_691.TEXT.closed
								else
									v129 = v_u_691.text(p118, v128)
								end
							end
							return {
								["show"] = true,
								["enabled"] = false,
								["reason"] = nil,
								["short"] = nil,
								["why"] = nil,
								["reason"] = v129,
								["short"] = v128 == "SCOPE" and "Not open yet" or (v120.kind == "closed" and (v128 == "OFF_BUY" or v128 == "DISABLED") and "Closed" or (v128 == "OFF_BUY" and "Buying is off" or ((v120.kind == "closed" or v128 == "DISABLED") and "Closed" or "Unavailable"))),
								["why"] = v128
							}
						else
							if p117 > 0.05 then
								return {
									["show"] = true,
									["enabled"] = false,
									["reason"] = nil,
									["why"] = "WAIT",
									["reason"] = ("Wait %d s"):format((math.ceil(p117)))
								}
							end
							local v131
							if type(p115) == "table" then
								local v132 = p115.p
								v131 = type(v132) ~= "number" and 0 or p115.p
							else
								v131 = 0
							end
							return p116 < v131 and {
								["show"] = true,
								["enabled"] = false,
								["reason"] = nil,
								["why"] = "CASH",
								["reason"] = ("Need %s more"):format(v_u_691.money(v131 - p116))
							} or {
								["show"] = true,
								["enabled"] = true,
								["why"] = "OK"
							}
						end
					end
				end
			end
		else
			return {
				["show"] = true,
				["enabled"] = false,
				["reason"] = nil,
				["short"] = "Unavailable",
				["why"] = "STORE",
				["reason"] = v_u_691.text(p118, "STORE")
			}
		end
	end,
	["orderGate"] = function(p133, p134) -- name: orderGate
		-- upvalues: (copy) v_u_691
		if type(p133) == "table" then
			if p133.ok == false then
				local v135 = false
				local v136 = p133.text
				if type(v136) == "string" and p133.text ~= "" then
					return v135, p133.text
				else
					return v135, v_u_691.text(p134, p133.code or "STORE")
				end
			else
				local v137 = p133.on
				if type(v137) == "table" then
					if v137.freeze == true then
						return false, v_u_691.text(p134, "FREEZE")
					end
					if v137.scope == false then
						return false, v_u_691.text(p134, "SCOPE")
					end
					if v137.drain == true then
						return false, v_u_691.text(p134, "DRAIN")
					end
					if v137.book == false then
						return false, v_u_691.text(p134, "OFF_BOOK")
					end
				end
				local v138 = p133.can
				if type(v138) == "table" and (v138.why == "PAID_BLOCKED" or (v138.why == "POLICY_WAIT" or (v138.why == "FREEZE" or v138.why == "SCOPE"))) then
					local v139 = false
					local v140 = v138.text
					if type(v140) == "string" and v138.text ~= "" then
						return v139, v138.text
					else
						return v139, v_u_691.text(p134, v138.why)
					end
				else
					local v141 = p133.orders
					if type(v141) == "table" then
						if v141.can == false then
							local v142 = false
							local v143 = v141.text
							if type(v143) == "string" and v141.text ~= "" then
								return v142, v141.text
							else
								return v142, v_u_691.text(p134, v141.why or "OFF_BOOK")
							end
						end
						if v141.full == true then
							return false, v_u_691.text(p134, "ORDERS_FULL")
						end
					end
					return true, nil
				end
			end
		else
			return true, nil
		end
	end,
	["orderButton"] = function(p144, p145, p146, p147, p148) -- name: orderButton
		-- upvalues: (copy) v_u_691
		local v149 = v_u_691.isCrateItem(p145)
		local v150, v151 = v_u_691.orderGate(p144, p147)
		if not v150 then
			return {
				["show"] = true,
				["enabled"] = false,
				["why"] = "GATE",
				["reason"] = nil,
				["short"] = nil,
				["form"] = nil,
				["odds"] = nil,
				["reason"] = v151,
				["form"] = not v149 ~= false,
				["odds"] = v149
			}
		end
		if v149 then
			local v152 = v_u_691.crateGate(p144, "order", p147)
			if v152 ~= nil then
				return {
					["show"] = true,
					["enabled"] = false,
					["why"] = nil,
					["reason"] = nil,
					["short"] = nil,
					["form"] = false,
					["odds"] = nil,
					["why"] = v152.why,
					["reason"] = v152.text,
					["short"] = v152.short,
					["odds"] = v149
				}
			end
		end
		return type(p148) == "number" and (type(p146) == "number" and p146 < p148) and {
			["show"] = true,
			["enabled"] = false,
			["why"] = "CASH",
			["reason"] = nil,
			["short"] = nil,
			["form"] = true,
			["odds"] = nil,
			["reason"] = ("Need %s more"):format(v_u_691.money(p148 - p146)),
			["odds"] = v149
		} or {
			["show"] = true,
			["enabled"] = true,
			["why"] = "OK",
			["reason"] = nil,
			["short"] = nil,
			["form"] = true,
			["odds"] = nil,
			["odds"] = v149
		}
	end,
	["sellNowButton"] = function(p153, p154, p155) -- name: sellNowButton
		-- upvalues: (copy) v_u_691
		if type(p153) ~= "table" or (p153.ok == false or p153.ds == "down") then
			return {
				["show"] = true,
				["enabled"] = false,
				["reason"] = nil,
				["short"] = "Unavailable",
				["why"] = "STORE",
				["reason"] = v_u_691.text(p155, "STORE")
			}
		end
		local v156 = p153.on
		local v157 = type(v156) ~= "table" and {} or p153.on
		if v157.freeze == true then
			return {
				["show"] = true,
				["enabled"] = false,
				["reason"] = nil,
				["short"] = "Paused",
				["why"] = "FREEZE",
				["reason"] = v_u_691.text(p155, "FREEZE")
			}
		end
		if v157.scope == false then
			return {
				["show"] = true,
				["enabled"] = false,
				["reason"] = nil,
				["short"] = "Not open yet",
				["why"] = "SCOPE",
				["reason"] = v_u_691.TEXT.scopeClosed
			}
		end
		if v157.book == false or v157.drain == true then
			return {
				["show"] = true,
				["enabled"] = false,
				["reason"] = nil,
				["short"] = "Unavailable",
				["why"] = nil,
				["reason"] = v_u_691.text(p155, v157.drain == true and "DRAIN" or "OFF_BOOK"),
				["why"] = v157.drain == true and "DRAIN" or "OFF_BOOK"
			}
		end
		if v_u_691.isCrateItem(p154) then
			local v158 = v_u_691.crateGate(p153, "sell", p155)
			if v158 ~= nil then
				return {
					["show"] = true,
					["enabled"] = false,
					["reason"] = nil,
					["short"] = nil,
					["why"] = nil,
					["reason"] = v158.text,
					["short"] = v158.short,
					["why"] = v158.why
				}
			end
		end
		return {
			["show"] = true,
			["enabled"] = true,
			["why"] = "OK"
		}
	end,
	["crateTab"] = function(p159) -- name: crateTab
		if type(p159) == "table" then
			local v160 = p159.crate
			if type(v160) == "table" then
				return p159.crate.tab ~= false
			end
		end
		return true
	end,
	["crateEnv"] = function(p161) -- name: crateEnv
		local v162
		if type(p161) == "table" then
			local v163 = p161.crate
			if type(v163) == "table" then
				v162 = p161.crate
			else
				v162 = nil
			end
		else
			v162 = nil
		end
		return v162 == nil and {
			["crates"] = true,
			["resolved"] = false,
			["tradeFailed"] = false
		} or (v162.why == "OFF_CRATES" and {
			["crates"] = false,
			["resolved"] = true,
			["tradeFailed"] = false
		} or (v162.why == "POLICY_WAIT" and {
			["crates"] = true,
			["resolved"] = false,
			["tradeFailed"] = false
		} or (v162.why == "POLICY_FAIL" and {
			["crates"] = true,
			["resolved"] = true,
			["tradeFailed"] = true
		} or (v162.tab == false and {
			["crates"] = true,
			["resolved"] = true,
			["tradeFailed"] = false,
			["restricted"] = true
		} or {
			["crates"] = true,
			["resolved"] = true,
			["tradeFailed"] = false
		}))))
	end,
	["crateBanner"] = function(p164) -- name: crateBanner
		-- upvalues: (copy) v_u_691
		local v165 = v_u_691.cm
		if type(p164) == "table" then
			local v166 = p164.crate
			if type(v166) == "table" then
				local v167 = p164.crate
				if v167.tab == false then
					return nil
				end
				if v167.why == "CRATE_BUY" then
					local v168 = {
						["kind"] = "restricted",
						["text"] = nil
					}
					local v169
					if v165 == nil then
						v169 = nil
					else
						local v170 = v165.TEXT
						if type(v170) == "table" then
							v169 = v165.TEXT.bannerBuy
						else
							v169 = nil
						end
					end
					v168.text = (type(v169) ~= "string" or v169 == "") and "Buying cases is not available for your account because of Roblox rules for random items. You can still sell cases and see every price." or v169
					return v168
				end
				if v167.why == "POLICY_WAIT" then
					local v171 = {
						["kind"] = "wait",
						["text"] = nil
					}
					local v172
					if v165 == nil then
						v172 = nil
					else
						local v173 = v165.TEXT
						if type(v173) == "table" then
							v172 = v165.TEXT.bannerWait
						else
							v172 = nil
						end
					end
					v171.text = (type(v172) ~= "string" or v172 == "") and "Your account is still being checked. Prices are shown, trading opens in a moment." or v172
					return v171
				end
				if v167.why == "POLICY_FAIL" then
					local v174 = {
						["kind"] = "fail",
						["text"] = nil
					}
					local v175
					if v165 == nil then
						v175 = nil
					else
						local v176 = v165.TEXT
						if type(v176) == "table" then
							v175 = v165.TEXT.bannerFail
						else
							v175 = nil
						end
					end
					v174.text = (type(v175) ~= "string" or v175 == "") and "We could not check your account. Rejoin to try again. Prices are still shown." or v175
					return v174
				end
				if v167.why ~= "OFF_CRATES" then
					return nil
				end
				local v177 = {
					["kind"] = "off",
					["text"] = nil
				}
				local v178
				if v165 == nil then
					v178 = nil
				else
					local v179 = v165.TEXT
					if type(v179) == "table" then
						v178 = v165.TEXT.bannerOff
					else
						v178 = nil
					end
				end
				v177.text = (type(v178) ~= "string" or v178 == "") and "Trading cases is switched off right now." or v178
				return v177
			end
		end
		return nil
	end,
	["crateName"] = function(p180) -- name: crateName
		-- upvalues: (copy) v_u_691
		local v181 = v_u_691.cm
		if v181 ~= nil then
			local v182 = v181.info
			if type(v182) == "function" then
				local v183 = v181.info(p180)
				if type(v183) == "table" then
					local v184 = v183.name
					if type(v184) == "string" then
						local v185 = v183.name
						return string.gsub(string.lower(v185), "(%a)(%w*)", function(p186, p187)
							return string.upper(p186) .. p187
						end)
					end
				end
				return nil
			end
		end
		return nil
	end,
	["crateBlock"] = function(p188) -- name: crateBlock
		-- upvalues: (copy) v_u_691
		local v189 = v_u_691.cm
		if v189 ~= nil then
			local v190 = v189.info
			if type(v190) == "function" and v_u_691.isCrateItem(p188) then
				local v191 = v189.info(p188)
				if type(v191) ~= "table" then
					return nil
				end
				local v192 = {
					["crateId"] = p188
				}
				local v193 = v189.sealedLine
				local v194
				if type(v193) == "function" then
					v194 = v189.sealedLine(p188)
				else
					v194 = v191.openLine
				end
				v192.sealed = v194
				local v195 = v_u_691.cm
				local v196
				if v195 == nil then
					v196 = nil
				else
					local v197 = v195.TEXT
					if type(v197) == "table" then
						v196 = v195.TEXT.chances
					else
						v196 = nil
					end
				end
				v192.chancesLabel = (type(v196) ~= "string" or v196 == "") and "Chances for one opening:" or v196
				v192.chanceLine = v191.chanceLine
				v192.tallyLine = v191.tallyLine
				v192.groups = v191.groups
				local v198 = v_u_691.cm
				local v199
				if v198 == nil then
					v199 = nil
				else
					local v200 = v198.TEXT
					if type(v200) == "table" then
						v199 = v198.TEXT.finishNote
					else
						v199 = nil
					end
				end
				v192.finishNote = (type(v199) ~= "string" or v199 == "") and "Finishes are cosmetic, stay on your account and cannot be traded." or v199
				local v201 = {}
				local v202 = v_u_691.cm
				local v203
				if v202 == nil then
					v203 = nil
				else
					local v204 = v202.TEXT
					if type(v204) == "table" then
						v203 = v202.TEXT.odds
					else
						v203 = nil
					end
				end
				v201.text = (type(v203) ~= "string" or v203 == "") and "ODDS" or v203
				v201.crateId = p188
				v192.odds = v201
				return v192
			end
		end
		return nil
	end,
	["crateConfirm"] = function(p205, p206, p207, p208, p209, p210) -- name: crateConfirm
		-- upvalues: (copy) v_u_691
		local v211 = v_u_691.crateBlock(p205)
		if v211 == nil then
			return nil
		end
		local v212 = type(p210) ~= "table" and {} or p210
		local v213 = v_u_691.crateName(p205) or "Case"
		local v214 = (type(p206) ~= "number" or p206 < 1) and 1 or math.floor(p206)
		local v215 = (type(p207) ~= "number" or p207 ~= p207) and 0 or p207
		local v216 = ((type(p208) ~= "number" or p208 ~= p208) and 0 or p208) - v215
		local v217 = {}
		local v218
		if (p209 or "buy") == "buy" then
			if v214 > 1 then
				v218 = ("Buy %d x %s for %s?"):format(v214, v213, v_u_691.money(v215))
			else
				v218 = ("Buy %s for %s?"):format(v213, v_u_691.money(v215))
			end
			table.insert(v217, {
				["kind"] = "title",
				["text"] = nil,
				["text"] = v218
			})
		else
			v218 = nil
		end
		table.insert(v217, {
			["kind"] = "block",
			["block"] = nil,
			["block"] = v211
		})
		local v219 = {
			["kind"] = "price",
			["label"] = "Price",
			["text"] = nil
		}
		local v220
		if v214 > 1 then
			v220 = ("%s (%s each)"):format(v_u_691.money(v215), v_u_691.unitMoney(v215 / v214))
		else
			v220 = v_u_691.money(v215)
		end
		v219.text = v220
		table.insert(v217, v219)
		local v221 = {
			["kind"] = "cash",
			["label"] = "Your Cash after",
			["text"] = nil,
			["danger"] = nil,
			["text"] = v_u_691.money(v216),
			["danger"] = v216 < 0
		}
		table.insert(v217, v221)
		if v212.mail == true then
			table.insert(v217, {
				["kind"] = "delivery",
				["text"] = "It is delivered to your mail."
			})
		end
		local v222 = {
			["kind"] = "note",
			["text"] = nil,
			["text"] = v_u_691.TEXT.cashSetAside
		}
		table.insert(v217, v222)
		return {
			["elements"] = v217,
			["title"] = v218,
			["block"] = v211,
			["after"] = v216
		}
	end,
	["crateOwned"] = function(p223, p224) -- name: crateOwned
		local v225 = 0
		if type(p223) ~= "table" then
			return 0
		end
		for _, v226 in p223 do
			if type(v226) ~= "table" or v226.id ~= p224 then
				continue
			end
			local v227 = v226.n
			if type(v227) ~= "number" or v226.n < 1 then
				continue
			end
			local v228 = v226.n
			v225 = v225 + math.floor(v228)
		end
		return v225
	end,
	["crateCard"] = function(p229, p230, p231, p232, p233) -- name: crateCard
		-- upvalues: (copy) v_u_691
		local v234 = v_u_691.cm
		if v234 ~= nil then
			local v235 = v234.info
			if type(v235) == "function" and v_u_691.isCrateItem(p230) then
				local v236 = v234.info(p230)
				if type(v236) ~= "table" then
					return nil
				end
				local v237 = p233 and p233.rules or {
					["text"] = function() -- name: text
						return ""
					end
				}
				local v238 = type(p231) ~= "table" and {} or p231
				local v239 = v238.c
				local v240
				if type(v239) == "number" and v238.c >= 0 then
					local v241 = v238.c
					v240 = math.floor(v241)
				else
					v240 = 0
				end
				local v242 = v238.m
				local v243
				if type(v242) == "number" and (v238.m == v238.m and v238.m > 0) then
					v243 = v240 > 0
				else
					v243 = false
				end
				local v244 = v_u_691.crateOwned(p232, p230)
				local v245 = v_u_691.crateGate(p229, "sell", v237)
				local v246
				if type(p229) == "table" then
					local v247 = p229.crate
					if type(v247) == "table" then
						v246 = p229.crate.why == "CRATE_BUY"
					else
						v246 = false
					end
				else
					v246 = false
				end
				local v248
				if v246 or not v236.cashOpen then
					v248 = ("Opens with a %s."):format(v236.keyName)
				else
					v248 = v236.openLine
				end
				local v249
				if v243 then
					local v250 = v_u_691.cm
					local v251
					if v250 == nil then
						v251 = nil
					else
						local v252 = v250.TEXT
						if type(v252) == "table" then
							v251 = v250.TEXT.priceFrom
						else
							v251 = nil
						end
					end
					v249 = ((type(v251) ~= "string" or v251 == "") and "From %s each" or v251):format(v_u_691.unitMoney(v238.m))
				else
					local v253 = v_u_691.cm
					local v254
					if v253 == nil then
						v254 = nil
					else
						local v255 = v253.TEXT
						if type(v255) == "table" then
							v254 = v253.TEXT.noListings
						else
							v254 = nil
						end
					end
					v249 = (type(v254) ~= "string" or v254 == "") and "No listings" or v254
				end
				local v256
				if v240 > 0 then
					local v257 = v_u_691.cm
					local v258
					if v257 == nil then
						v258 = nil
					else
						local v259 = v257.TEXT
						if type(v259) == "table" then
							v258 = v257.TEXT.listed
						else
							v258 = nil
						end
					end
					v256 = ((type(v258) ~= "string" or v258 == "") and "%d listed" or v258):format(v240)
				else
					local v260 = v_u_691.cm
					local v261
					if v260 == nil then
						v261 = nil
					else
						local v262 = v260.TEXT
						if type(v262) == "table" then
							v261 = v260.TEXT.noListings
						else
							v261 = nil
						end
					end
					v256 = (type(v261) ~= "string" or v261 == "") and "No listings" or v261
				end
				local v263 = v238.a
				local v264
				if type(v263) == "number" and (v238.a == v238.a and v238.a > 0) then
					v264 = ("7 day average %s"):format(v_u_691.unitMoney(v238.a))
				else
					v264 = v_u_691.TEXT.notEnoughSales
				end
				local v265
				if v244 > 0 then
					local v266 = v_u_691.cm
					local v267
					if v266 == nil then
						v267 = nil
					else
						local v268 = v266.TEXT
						if type(v268) == "table" then
							v267 = v266.TEXT.own
						else
							v267 = nil
						end
					end
					v265 = ((type(v267) ~= "string" or v267 == "") and "You own %d" or v267):format(v244)
				else
					local v269 = v_u_691.cm
					local v270
					if v269 == nil then
						v270 = nil
					else
						local v271 = v269.TEXT
						if type(v271) == "table" then
							v270 = v269.TEXT.ownNone
						else
							v270 = nil
						end
					end
					v265 = (type(v270) ~= "string" or v270 == "") and "You have none" or v270
				end
				local v272
				if v244 <= 0 then
					v272 = {
						["enabled"] = false,
						["why"] = "NONE",
						["short"] = nil,
						["text"] = nil
					}
					local v273 = v_u_691.cm
					local v274
					if v273 == nil then
						v274 = nil
					else
						local v275 = v273.TEXT
						if type(v275) == "table" then
							v274 = v273.TEXT.ownNone
						else
							v274 = nil
						end
					end
					v272.short = (type(v274) ~= "string" or v274 == "") and "You have none" or v274
					local v276 = v_u_691.cm
					local v277
					if v276 == nil then
						v277 = nil
					else
						local v278 = v276.TEXT
						if type(v278) == "table" then
							v277 = v276.TEXT.sell
						else
							v277 = nil
						end
					end
					v272.text = (type(v277) ~= "string" or v277 == "") and "SELL" or v277
				elseif v245 == nil then
					v272 = {
						["enabled"] = true,
						["why"] = "OK",
						["text"] = nil
					}
					local v279 = v_u_691.cm
					local v280
					if v279 == nil then
						v280 = nil
					else
						local v281 = v279.TEXT
						if type(v281) == "table" then
							v280 = v279.TEXT.sell
						else
							v280 = nil
						end
					end
					v272.text = (type(v280) ~= "string" or v280 == "") and "SELL" or v280
				else
					v272 = {
						["enabled"] = false,
						["why"] = nil,
						["short"] = nil,
						["reason"] = nil,
						["text"] = nil,
						["why"] = v245.why,
						["short"] = v245.short,
						["reason"] = v245.text
					}
					local v282 = v_u_691.cm
					local v283
					if v282 == nil then
						v283 = nil
					else
						local v284 = v282.TEXT
						if type(v284) == "table" then
							v283 = v282.TEXT.sell
						else
							v283 = nil
						end
					end
					v272.text = (type(v283) ~= "string" or v283 == "") and "SELL" or v283
				end
				local v285 = {
					["id"] = p230,
					["name"] = v236.name
				}
				local v286 = v236.name
				v285.itemName = string.gsub(string.lower(v286), "(%a)(%w*)", function(p287, p288)
					return string.upper(p287) .. p288
				end)
				v285.openLine = v248
				v285.chanceLine = v236.chanceLine
				v285.tallyLine = v236.tallyLine
				v285.groups = v236.groups
				v285.fromText = v249
				v285.listedText = v256
				v285.avgText = v264
				v285.ownText = v265
				v285.own = v244
				v285.count = v240
				local v289
				if v243 then
					v289 = v238.m
				else
					v289 = nil
				end
				v285.min = v289
				v285.compact = {
					["title"] = v236.name,
					["price"] = v249,
					["counts"] = ("%s, %s"):format(v256, string.lower((string.sub(v265, 1, 1))) .. string.sub(v265, 2)),
					["chances"] = v236.chanceLine
				}
				local v290 = {
					["listings"] = {
						["enabled"] = true,
						["text"] = "LISTINGS"
					},
					["sell"] = v272
				}
				local v291 = {
					["enabled"] = true,
					["text"] = nil,
					["crateId"] = nil
				}
				local v292 = v_u_691.cm
				local v293
				if v292 == nil then
					v293 = nil
				else
					local v294 = v292.TEXT
					if type(v294) == "table" then
						v293 = v292.TEXT.odds
					else
						v293 = nil
					end
				end
				v291.text = (type(v293) ~= "string" or v293 == "") and "ODDS" or v293
				v291.crateId = p230
				v290.odds = v291
				v285.buttons = v290
				return v285
			end
		end
		return nil
	end,
	["crateCards"] = function(p295, p296, p297, p298, p299) -- name: crateCards
		-- upvalues: (copy) v_u_691
		local v300 = type(p297) ~= "table" and {} or p297
		local v301 = {}
		for _, v302 in p296 do
			local v303 = v_u_691.crateCard(p295, v302, v300[v302], p298, p299)
			if v303 == nil then
				continue
			end
			table.insert(v301, v303)
		end
		return v301
	end,
	["crateSellModel"] = function(p304, p305) -- name: crateSellModel
		-- upvalues: (copy) v_u_691
		local v306 = v_u_691.cm
		if v306 ~= nil then
			local v307 = v306.info
			if type(v307) == "function" and v_u_691.isCrateItem(p304) then
				local v308 = v306.info(p304)
				if type(v308) ~= "table" then
					return nil
				end
				local v309 = type(p305) ~= "table" and {} or p305
				local v310 = v309.a
				local v311
				if type(v310) == "number" and v309.a > 0 then
					v311 = v309.a
				else
					v311 = nil
				end
				local v312 = v309.m
				local v313
				if type(v312) == "number" and (v309.m > 0 and (v309.c or 0) > 0) then
					v313 = v309.m
				else
					v313 = nil
				end
				local v314 = v311 or (v313 or v308.refValue)
				local v315 = v311 and "avg" or (v313 and "cheapest" or "open")
				local v316 = {
					["label"] = nil,
					["cashToOpen"] = nil,
					["oddsNote"] = nil,
					["odds"] = nil,
					["prefill"] = nil,
					["hint"] = nil,
					["warnRef"] = nil,
					["warnSource"] = nil,
					["traderLines"] = false
				}
				local v317 = v_u_691.cm
				local v318
				if v317 == nil then
					v318 = nil
				else
					local v319 = v317.TEXT
					if type(v319) == "table" then
						v318 = v317.TEXT.cashToOpen
					else
						v318 = nil
					end
				end
				v316.label = (type(v318) ~= "string" or v318 == "") and "CASH TO OPEN" or v318
				v316.cashToOpen = v_u_691.money(v308.refValue)
				local v320 = v_u_691.cm
				local v321
				if v320 == nil then
					v321 = nil
				else
					local v322 = v320.TEXT
					if type(v322) == "table" then
						v321 = v320.TEXT.sellNote
					else
						v321 = nil
					end
				end
				v316.oddsNote = (type(v321) ~= "string" or v321 == "") and "Buyers see the chances before they buy." or v321
				local v323 = {}
				local v324 = v_u_691.cm
				local v325
				if v324 == nil then
					v325 = nil
				else
					local v326 = v324.TEXT
					if type(v326) == "table" then
						v325 = v324.TEXT.odds
					else
						v325 = nil
					end
				end
				v323.text = (type(v325) ~= "string" or v325 == "") and "ODDS" or v325
				v323.crateId = p304
				v316.odds = v323
				v316.prefill = v311 or v313
				local v327
				if v311 == nil and v313 == nil then
					local v328 = v_u_691.cm
					local v329
					if v328 == nil then
						v329 = nil
					else
						local v330 = v328.TEXT
						if type(v330) == "table" then
							v329 = v328.TEXT.setPrice
						else
							v329 = nil
						end
					end
					v327 = (type(v329) ~= "string" or v329 == "") and "Set your price" or v329
				else
					v327 = nil
				end
				v316.hint = v327
				v316.warnRef = v314
				v316.warnSource = v315
				return v316
			end
		end
		return nil
	end,
	["crateSearchHint"] = function(p331, p332) -- name: crateSearchHint
		-- upvalues: (copy) v_u_691
		if type(p331) ~= "string" then
			return nil
		end
		local v333 = string.lower(p331)
		local v334 = string.gsub(v333, "^%s+", "")
		local v335 = string.gsub(v334, "%s+$", "")
		if #v335 < 2 then
			return nil
		end
		local v336 = { "case", "crate" }
		local v337 = v_u_691.cm
		if v337 ~= nil then
			local v338 = v337.info
			if type(v338) == "function" and p332 ~= nil then
				for _, v339 in p332 do
					local v340 = v337.info(v339)
					if type(v340) ~= "table" then
						continue
					end
					local v341 = v340.short
					if type(v341) ~= "string" then
						continue
					end
					local v342 = string.lower
					local v343 = v340.short
					table.insert(v336, v342(v343))
				end
			end
		end
		local v344 = false
		for _, v345 in v336 do
			if string.find(v335, v345, 1, true) == nil then
				if #v335 < 3 then
					continue
				end
				local v346 = #v335
				if string.sub(v345, 1, v346) ~= v335 then
					continue
				end
			end
			v344 = true
		end
		if not v344 then
			return nil
		end
		local v347 = v_u_691.cm
		local v348
		if v347 == nil then
			v348 = nil
		else
			local v349 = v347.TEXT
			if type(v349) == "table" then
				v348 = v347.TEXT.browseHint
			else
				v348 = nil
			end
		end
		return (type(v348) ~= "string" or v348 == "") and "Cases are traded under CRATES here in the MARKET." or v348
	end,
	["condition"] = function(p350, p351, p352, p353) -- name: condition
		if type(p352) ~= "number" then
			return nil
		end
		local v354 = p352 + 0.5
		local v355 = math.floor(v354)
		local v356 = math.clamp(v355, 0, 100)
		local v357 = {
			["pct"] = v356,
			["kind"] = (p353 or 70) <= v356 and "good" or (v356 >= 40 and "worn" or "bad")
		}
		if type(p350) == "table" then
			local v358 = p350.usesLeft
			if type(v358) == "function" then
				local v359 = p350.usesLeft
				local v360 = {
					["id"] = p351,
					["dur"] = v356 / 100
				}
				local v361, v362, v363 = pcall(v359, v360)
				if v361 and (type(v362) == "number" and type(v363) == "number") then
					v357.uses = {
						["left"] = v362,
						["total"] = v363
					}
				end
			end
		end
		return v357
	end,
	["numbers"] = function(p364, p365) -- name: numbers
		-- upvalues: (copy) v_u_691
		local v366 = type(p364) ~= "table" and {} or p364
		local v367 = {}
		local v368 = {
			["id"] = "min",
			["label"] = "CHEAPEST",
			["value"] = nil,
			["sub"] = nil,
			["empty"] = nil
		}
		local v369 = v366.min
		v368.value = type(v369) ~= "number" and "No listings" or v_u_691.unitMoney(v366.min)
		local v370 = v366.min
		v368.sub = type(v370) == "number" and "each" or nil
		local v371 = v366.min
		v368.empty = type(v371) ~= "number"
		table.insert(v367, v368)
		local v372 = v366.avg7
		local v373 = type(v372) == "number"
		local v374 = {
			["id"] = "avg7",
			["label"] = "7 DAY AVERAGE",
			["value"] = nil,
			["sub"] = nil,
			["empty"] = nil
		}
		local v375
		if v373 then
			v375 = v_u_691.unitMoney(v366.avg7)
		elseif (v366.sold7 or 0) > 0 then
			v375 = v_u_691.TEXT.notEnoughSales
		else
			local v376 = v366.last
			if type(v376) == "number" then
				v375 = v_u_691.TEXT.noSalesWeek
			else
				v375 = v_u_691.TEXT.noSales
			end
		end
		v374.value = v375
		local v377
		if v373 then
			v377 = ("%s sold"):format(v_u_691.commas(v366.sold7 or 0))
		else
			v377 = nil
		end
		v374.sub = v377
		v374.empty = not v373
		table.insert(v367, v374)
		local v378 = v366.last
		local v379 = type(v378) == "number"
		local v380 = {
			["id"] = "last",
			["label"] = "LAST SALE",
			["value"] = nil,
			["sub"] = nil,
			["empty"] = nil
		}
		local v381
		if v379 then
			v381 = v_u_691.unitMoney(v366.last)
		else
			v381 = v_u_691.TEXT.noSales
		end
		v380.value = v381
		local v382
		if v379 and type(p365) == "number" then
			v382 = v_u_691.ago(p365)
		else
			v382 = nil
		end
		v380.sub = v382
		v380.empty = not v379
		table.insert(v367, v380)
		local v383 = {
			["id"] = "count",
			["label"] = "LISTED",
			["value"] = nil,
			["empty"] = nil,
			["value"] = v_u_691.commas(v366.count or 0),
			["empty"] = (v366.count or 0) == 0
		}
		table.insert(v367, v383)
		return v367
	end,
	["historyNote"] = function(p384, p385) -- name: historyNote
		-- upvalues: (copy) v_u_691
		local v386 = type(p384) ~= "table" and {} or p384
		local v387 = v386.hist
		local v388 = type(v387) ~= "table" and {} or v386.hist
		local v389 = v386.daily
		local v390 = type(v389) ~= "table" and {} or v386.daily
		if #v388 > 0 or #v390 >= 2 then
			return nil
		else
			local v391 = v386.stats
			local v392 = type(v391) ~= "table" and {} or v386.stats
			local v393 = v392.sold7
			local v394
			if type(v393) == "number" and v392.sold7 > 0 then
				v394 = true
			else
				local v395 = v392.last
				if type(v395) == "number" then
					v394 = true
				else
					local v396 = v392.avg7
					v394 = type(v396) == "number"
				end
			end
			if v386.histPending == true then
				if p385 == true then
					return v_u_691.TEXT.salesMissing
				else
					return v_u_691.TEXT.salesLoading
				end
			elseif v394 then
				return v_u_691.TEXT.salesMissing
			else
				return v_u_691.TEXT.noSales
			end
		end
	end,
	["historyRetry"] = function(p397, p398) -- name: historyRetry
		if type(p397) ~= "table" or p397.histPending ~= true then
			return nil
		end
		local v399 = type(p398) ~= "number" and 0 or p398
		if v399 >= 4 then
			return nil
		end
		local v400 = p397.retryIn
		local v401 = (type(v400) ~= "number" or p397.retryIn ~= p397.retryIn) and 3 or p397.retryIn
		return math.clamp(v401, 1, 30) + v399
	end,
	["buy"] = nil,
	["bk"] = nil,
	["comfort"] = nil,
	["goodCondition"] = 70,
	["parseLimit"] = function(p402, p403) -- name: parseLimit
		local v404
		if type(p403) == "number" and (p403 == p403 and p403 ~= (1 / 0)) then
			v404 = p403 ~= (-1 / 0)
		else
			v404 = false
		end
		local v405 = (not v404 or p403 < 1) and 99999999 or math.floor(p403)
		local v406 = tostring(p402 or "")
		if string.find(v406, "-", 1, true) then
			return nil
		end
		local v407 = string.match(v406, "^([^%.]*)") or ""
		local v408 = string.gsub(v407, "[^%d,]", "")
		if string.find(v408, ",", 1, true) then
			local v409 = string.match(v408, "^%d%d?%d?") or ""
			local v410 = #v409 + 1
			local v411 = string.sub(v408, v410)
			if v409 == "" or (v411 == "" or string.gsub(v411, ",%d%d%d", "") ~= "") then
				v408 = string.match(v408, "^([^,]*)") or ""
			else
				v408 = string.gsub(v408, ",", "")
			end
		end
		if v408 == "" then
			return nil
		end
		local v412 = string.gsub(v408, "^0+", "")
		if v412 == "" then
			return 1
		end
		if #v412 > 12 then
			return v405
		end
		local v413 = tonumber(v412)
		return math.clamp(v413, 1, v405)
	end,
	["unitText"] = function(p414, p415) -- name: unitText
		-- upvalues: (copy) v_u_691
		local v416 = p414 / math.max(1, p415)
		if v416 < 100 then
			local v417 = v416 + 0.5
			local v418 = v416 - math.floor(v417)
			if math.abs(v418) >= 0.005 then
				return string.format("%.2f", v416)
			end
		end
		local v419 = v_u_691.commas
		local v420 = v416 + 0.5
		return v419((math.floor(v420)))
	end,
	["cheapestRow"] = function(p421) -- name: cheapestRow
		for _, v422 in p421 or {} do
			if type(v422) ~= "table" or v422.own == true then
				continue
			end
			local v423 = v422.p
			if type(v423) ~= "number" then
				continue
			end
			local v424 = v422.n
			if type(v424) ~= "number" or v422.n <= 0 then
				continue
			end
			return v422
		end
		return nil
	end,
	["limitQuick"] = function(p425) -- name: limitQuick
		-- upvalues: (copy) v_u_691
		if v_u_691.buy == nil then
			error("MenuMarketData.buy (BmBuy) is not set")
		end
		local v426 = v_u_691.buy
		local v427 = {}
		if v_u_691.comfort == nil then
			error("MenuMarketData.comfort (BmRules.COMFORT) is not set")
		end
		for _, v428 in v_u_691.comfort.bestQuick do
			local v429 = {
				["pct"] = v428,
				["value"] = v426.limitFor(p425, v428)
			}
			table.insert(v427, v429)
		end
		return {
			["default"] = v426.defaultLimit(p425),
			["quick"] = v427
		}
	end,
	["bestPreview"] = function(p430, p431, p432) -- name: bestPreview
		-- upvalues: (copy) v_u_691
		if v_u_691.buy == nil then
			error("MenuMarketData.buy (BmBuy) is not set")
		end
		local v433 = v_u_691.buy
		local v434 = {
			["within"] = 0
		}
		local v435
		if p432 == true then
			v435 = v_u_691.goodCondition
		else
			v435 = nil
		end
		for _, v436 in p430 or {} do
			if type(v436) ~= "table" or v436.own == true then
				continue
			end
			local v437 = v436.p
			local v438
			if type(v437) == "number" and (v437 == v437 and v437 ~= (1 / 0)) then
				v438 = v437 ~= (-1 / 0)
			else
				v438 = false
			end
			if not v438 then
				continue
			end
			local v439 = v436.n
			local v440
			if type(v439) == "number" and (v439 == v439 and v439 ~= (1 / 0)) then
				v440 = v439 ~= (-1 / 0)
			else
				v440 = false
			end
			if not v440 or (v436.n <= 0 or v436.p <= 0) then
				continue
			end
			if v435 ~= nil then
				local v441 = v436.d
				local v442
				if type(v441) == "number" and (v441 == v441 and v441 ~= (1 / 0)) then
					v442 = v441 ~= (-1 / 0)
				else
					v442 = false
				end
				if v442 and v436.d < v435 then
					continue
				end
			end
			local v443 = v436.p / v436.n
			if v434.cheapest == nil then
				v434.cheapest = v443
			end
			local v444
			if type(p431) == "number" and (p431 == p431 and p431 ~= (1 / 0)) then
				v444 = p431 ~= (-1 / 0)
			else
				v444 = false
			end
			if not (v444 and v433.withinLimit(v436.p, v436.n, p431)) then
				continue
			end
			v434.within = v434.within + 1
			v434.first = v434.first or v436
			local v445 = v434.dearest or 0
			v434.dearest = math.max(v445, v443)
		end
		if v434.first then
			v434.firstTotal = v434.first.p
			v434.most = v433.maxTotal(p430, p431, p432)
		end
		return v434
	end,
	["lotText"] = function(p446, p447, p448, p449, p450) -- name: lotText
		-- upvalues: (copy) v_u_691
		if p449 > 1 then
			p448 = ("%d x %s"):format(p449, p448)
		end
		local v451 = v_u_691.condition(p446, p447, p450, 70)
		if v451 == nil then
			return p448
		end
		local v452 = "%s (%s)"
		local v453
		if v451.uses then
			v453 = ("%d of %d uses"):format(v451.uses.left, v451.uses.total)
		else
			v453 = ("%d%%"):format(v451.pct)
		end
		return v452:format(p448, v453)
	end,
	["NEXT_ROWS_MAX"] = 50,
	["applyNext"] = function(p454, p455, p456) -- name: applyNext
		-- upvalues: (copy) v_u_691
		if type(p454) == "table" then
			local v457 = p454.listings
			if type(v457) == "table" then
				local v458 = p456 or v_u_691.goodCondition
				local v459 = {}
				for _, v460 in p454.listings do
					if #v459 >= v_u_691.NEXT_ROWS_MAX then
						break
					end
					if type(v460) ~= "table" then
						continue
					end
					local v461 = v460.lid
					if type(v461) ~= "string" then
						continue
					end
					local v462 = v460.n
					local v463
					if type(v462) == "number" and (v462 == v462 and v462 ~= (1 / 0)) then
						v463 = v462 ~= (-1 / 0)
					else
						v463 = false
					end
					if not v463 or v460.n <= 0 then
						continue
					end
					local v464 = v460.p
					local v465
					if type(v464) == "number" and (v464 == v464 and v464 ~= (1 / 0)) then
						v465 = v464 ~= (-1 / 0)
					else
						v465 = false
					end
					if not v465 or v460.p <= 0 then
						continue
					end
					local v466 = v460.d
					local v467
					if type(v466) == "number" and (v466 == v466 and v466 ~= (1 / 0)) then
						v467 = v466 ~= (-1 / 0)
					else
						v467 = false
					end
					local v468
					if v467 then
						v468 = v460.d
					else
						v468 = nil
					end
					if p455 == true and (v468 ~= nil and v458 > v468) then
						continue
					end
					local v469 = {
						["lid"] = v460.lid,
						["n"] = v460.n,
						["p"] = v460.p
					}
					local v470 = v460.u
					local v471
					if type(v470) == "number" and (v470 == v470 and v470 ~= (1 / 0)) then
						v471 = v470 ~= (-1 / 0)
					else
						v471 = false
					end
					local v472
					if v471 and v460.u > 0 then
						v472 = v460.u
					else
						v472 = v460.p / v460.n
					end
					v469.u = v472
					local v473 = v460.left
					local v474
					if type(v473) == "number" and (v473 == v473 and v473 ~= (1 / 0)) then
						v474 = v473 ~= (-1 / 0)
					else
						v474 = false
					end
					local v475
					if v474 then
						local v476 = v460.left
						v475 = math.max(0, v476)
					else
						v475 = 0
					end
					v469.left = v475
					v469.own = v460.own == true
					v469.d = v468
					v469.pk = (v460.pk == 1 or v460.pk == true) and 1 or nil
					table.insert(v459, v469)
				end
				local v477
				if p455 == true then
					v477 = #v459
				else
					local v478 = p454.total
					local v479
					if type(v478) == "number" and (v478 == v478 and v478 ~= (1 / 0)) then
						v479 = v478 ~= (-1 / 0)
					else
						v479 = false
					end
					if v479 then
						v477 = p454.total
					else
						v477 = #v459
					end
				end
				local v480 = {
					["listings"] = v459,
					["total"] = v477
				}
				local v481
				if p455 == true then
					v481 = false
				else
					v481 = p454.more == true
				end
				v480.more = v481
				local v482 = p454.min
				local v483
				if type(v482) == "number" and (v482 == v482 and v482 ~= (1 / 0)) then
					v483 = v482 ~= (-1 / 0)
				else
					v483 = false
				end
				local v484
				if v483 then
					v484 = p454.min
				else
					v484 = nil
				end
				v480.min = v484
				local v485 = p454.total
				local v486
				if type(v485) == "number" and (v485 == v485 and v485 ~= (1 / 0)) then
					v486 = v485 ~= (-1 / 0)
				else
					v486 = false
				end
				local v487
				if v486 then
					v487 = p454.total
				else
					v487 = nil
				end
				v480.all = v487
				return v480
			end
		end
		return nil
	end,
	["nextOffer"] = function(p488, p489, p490, p491) -- name: nextOffer
		-- upvalues: (copy) v_u_691
		local v492
		if type(p488) == "table" then
			local v493 = p488.data
			if type(v493) == "table" then
				v492 = p488.data
			else
				v492 = nil
			end
		else
			v492 = nil
		end
		if v492 == nil or v492.code ~= "GONE" and (v492.code ~= "PRICE" and (p488.code ~= "GONE" and p488.code ~= "PRICE")) then
			return nil
		end
		local v494 = v_u_691.applyNext(v492.next, p490)
		if v494 == nil then
			return nil
		end
		if v_u_691.buy == nil then
			error("MenuMarketData.buy (BmBuy) is not set")
		end
		local v495, v496, v497 = v_u_691.buy.nextLot(v494.listings, p489, p491)
		if v495 == nil then
			return nil
		end
		local v498 = {
			["row"] = v495,
			["close"] = v496,
			["rose"] = v497
		}
		local v499 = p489.p or 0
		local v500 = p489.n or 1
		v498.wantedUnit = v499 / math.max(1, v500)
		v498.page = v494
		return v498
	end,
	["lostNotice"] = function(p501, p502) -- name: lostNotice
		-- upvalues: (copy) v_u_691
		if p502 == "PRICE" and p501.rose == 0 then
			return v_u_691.TEXT.priceMoved, "info"
		end
		if p501.close then
			return v_u_691.TEXT.lostClose, "info"
		end
		local v503 = p501.row.u
		if not v503 then
			local v504 = p501.row.p
			local v505 = p501.row.n
			v503 = v504 / math.max(1, v505)
		end
		return v_u_691.fill(v_u_691.TEXT.lostRose, {
			["unit"] = v_u_691.unitMoney(v503),
			["was"] = v_u_691.unitMoney(p501.wantedUnit),
			["pct"] = p501.rose
		}), "warn"
	end,
	["matchQuery"] = function(p506, p507) -- name: matchQuery
		local v508 = string.lower(p507 or "")
		local v509 = string.gsub(v508, "^%s+", "")
		local v510 = string.gsub(v509, "%s+$", "")
		if v510 == "" then
			return true
		end
		local v511 = string.lower
		local v512 = table.concat
		local v513 = {}
		local v514 = p506.name or ""
		local v515 = tostring(v514)
		local v516 = p506.short or ""
		local v517 = tostring(v516)
		local v518 = p506.id or ""
		__set_list(v513, 1, {v515, v517, tostring(v518), table.concat(p506.tags or {}, " ")})
		local v519 = v511(v512(v513, " "))
		for v520 in string.gmatch(v510, "%S+") do
			if string.find(v519, v520, 1, true) then
				continue
			end
			return false
		end
		return true
	end,
	["SORTS"] = {
		{
			["id"] = "cat",
			["text"] = "Category"
		},
		{
			["id"] = "az",
			["text"] = "A to Z"
		},
		{
			["id"] = "low",
			["text"] = "Price low"
		},
		{
			["id"] = "high",
			["text"] = "Price high"
		},
		{
			["id"] = "most",
			["text"] = "Most listed"
		}
	},
	["arrange"] = function(p521, p522) -- name: arrange
		-- upvalues: (copy) v_u_691
		local v523 = p522.listed
		local v524 = type(v523) ~= "table" and {} or p522.listed
		local v525 = p522.query or ""
		local v526 = string.match(v525, "%S") ~= nil
		local v527 = p522.showAll == true and true or v526
		local v528 = p522.chip or "all"
		local v529 = {}
		for v530, v531 in p521 do
			if v528 ~= "all" and v531.cat ~= v528 or not v_u_691.matchQuery(v531, v525) then
				continue
			end
			local v532 = v524[v531.id]
			local v533 = type(v532) == "table" and (v532.c or 0) or 0
			if not v527 and v533 <= 0 then
				continue
			end
			local v534 = {
				["e"] = v531,
				["i"] = v530,
				["c"] = v533
			}
			local v535
			if type(v532) == "table" then
				v535 = v532.g or v532.m
			else
				v535 = nil
			end
			v534.m = v535
			table.insert(v529, v534)
		end
		local v536 = p522.sort or "cat"
		local function v539(p537, p538) -- name: byIndex
			return p537.i < p538.i
		end
		if v536 == "az" then
			table.sort(v529, function(p540, p541)
				local v542 = string.lower(p540.e.name)
				local v543 = string.lower(p541.e.name)
				if v542 == v543 then
					return p540.i < p541.i
				else
					return v542 < v543
				end
			end)
		elseif v536 == "low" or v536 == "high" then
			local v_u_544 = v536 == "low"
			table.sort(v529, function(p545, p546)
				-- upvalues: (copy) v_u_544
				if p545.m ~= nil == (p546.m ~= nil) then
					if p545.m == nil or (p546.m == nil or p545.m == p546.m) then
						return p545.i < p546.i
					elseif v_u_544 then
						return p545.m < p546.m
					else
						return p545.m > p546.m
					end
				else
					return p545.m ~= nil
				end
			end)
		elseif v536 == "most" then
			table.sort(v529, function(p547, p548)
				if p547.c == p548.c then
					return p547.i < p548.i
				else
					return p547.c > p548.c
				end
			end)
		else
			table.sort(v529, v539)
		end
		local v549 = {}
		for _, v550 in v529 do
			local v551 = v550.e
			table.insert(v549, v551)
		end
		return v549
	end,
	["slotText"] = function(p552, p553) -- name: slotText
		-- upvalues: (copy) v_u_691
		if not p553 then
			return nil, nil, "skeleton"
		end
		local v554 = type(p552) == "table" and (p552.c or 0) or 0
		if v554 <= 0 then
			return v_u_691.TEXT.noListings, nil, "none"
		end
		local v555 = p552.g
		local v556
		if type(v555) == "number" then
			v556 = p552.g
		else
			local v557 = p552.m
			if type(v557) == "number" then
				v556 = p552.m
			else
				v556 = nil
			end
		end
		local v558
		if v556 then
			v558 = "from " .. v_u_691.unitMoney(v556)
		else
			v558 = v_u_691.TEXT.noListings
		end
		return v558, ("%s listed"):format(v_u_691.commas(v554)), "price"
	end,
	["refundMax"] = function(p559) -- name: refundMax
		local v560
		if type(p559) == "table" then
			local v561 = p559.refunds
			if type(v561) == "table" then
				v560 = p559.refunds.max
			else
				v560 = nil
			end
		else
			v560 = nil
		end
		if type(v560) == "number" and (v560 == v560 and v560 >= 0) then
			return math.floor(v560)
		end
		local v562
		if type(p559) == "table" then
			local v563 = p559.limit
			v562 = (type(v563) ~= "number" or p559.limit ~= p559.limit) and 6 or p559.limit
		else
			v562 = 6
		end
		local v564 = math.max(0, v562) / 2
		return math.ceil(v564)
	end,
	["refundUsed"] = function(p565) -- name: refundUsed
		local v566
		if type(p565) == "table" then
			local v567 = p565.refunds
			if type(v567) == "table" then
				v566 = p565.refunds.used
			else
				v566 = nil
			end
		else
			v566 = nil
		end
		return (type(v566) ~= "number" or (v566 ~= v566 or v566 < 0)) and 0 or math.floor(v566)
	end,
	["refundFloor"] = function(p568) -- name: refundFloor
		if type(p568) ~= "number" or (p568 ~= p568 or (p568 <= 0 or p568 > 100)) then
			return nil
		end
		local v569 = 100 / p568 - 1e-9
		return math.ceil(v569)
	end,
	["sellAllowLine"] = function(p570, p571, p572, p573) -- name: sellAllowLine
		-- upvalues: (copy) v_u_691
		local v574 = v_u_691.refundMax(p572)
		local v575
		if v574 <= 0 then
			v575 = ("LISTINGS TODAY %d / %d. Cancelling does not give a listing back."):format(p570, p571)
		elseif v574 <= v_u_691.refundUsed(p572) then
			v575 = ("LISTINGS TODAY %d / %d. Sold listings give a slot back (up to %d a day, all used today)."):format(p570, p571, v574)
		else
			v575 = ("LISTINGS TODAY %d / %d. Sold listings give a slot back (up to %d a day)."):format(p570, p571, v574)
		end
		if p573 and p573 ~= "" then
			v575 = v575 .. " The count resets in " .. p573 .. "."
		end
		return v575
	end,
	["confirmSlotLine"] = function(p576, p577, p578) -- name: confirmSlotLine
		-- upvalues: (copy) v_u_691
		local v579 = v_u_691.refundFloor(p577)
		local v580
		if type(p577) == "number" and p577 == p577 then
			local v581 = p576 * p577 / 100
			v580 = math.floor(v581)
		else
			v580 = 0
		end
		if v579 == nil or v580 < 1 then
			return v579 == nil and "This uses one of your daily listings. Cancelling does not give it back." or ("%s A sale below $%s does not give the slot back. Cancelling never does."):format("This uses one of your daily listings.", v_u_691.commas(v579))
		end
		local v582 = v_u_691.refundMax(p578)
		return (v582 <= 0 or v582 <= v_u_691.refundUsed(p578)) and "This uses one of your daily listings. Today\'s slot refunds are used up. Cancelling never gives it back." or "This uses one of your daily listings. If it sells, the slot comes back. Cancelling does not give it back."
	end,
	["infoAllowLine"] = function(p583, p584) -- name: infoAllowLine
		-- upvalues: (copy) v_u_691
		local v585
		if type(p583) == "table" then
			local v586 = p583.limit
			v585 = type(v586) ~= "number" and 6 or p583.limit
		else
			v585 = 6
		end
		local v587 = v_u_691.refundMax(p583)
		local v588 = v_u_691.refundFloor(p584)
		local v589 = ("You can list %d items a day (VIP 10, FIXER 25; the highest tier counts)."):format(v585)
		if v587 > 0 and v588 ~= nil then
			return v589 .. (" When a listing sells for $%s or more, its slot comes back, up to %d times a day. Cancelling or letting a listing run out does not give the slot back."):format(v_u_691.commas(v588), v587)
		else
			return v589 .. " Cancelling or letting a listing run out does not give the daily listing back."
		end
	end,
	["listOn"] = function(p590) -- name: listOn
		local v591
		if type(p590) == "table" then
			v591 = p590.on == true
		else
			v591 = false
		end
		return v591
	end,
	["listFee"] = function(p592, p593) -- name: listFee
		-- upvalues: (copy) v_u_691
		if not v_u_691.listOn(p593) then
			return 0
		end
		local v594 = (type(p592) ~= "number" or (p592 ~= p592 or p592 <= 0)) and 0 or math.floor(p592)
		local v595 = p593.feePct
		local v596 = (type(v595) ~= "number" or (v595 ~= v595 or (v595 == (1 / 0) or v595 == (-1 / 0)))) and 0 or v595
		local v597 = math.max(0, v596)
		local v598 = p593.feeMin
		local v599 = (type(v598) ~= "number" or (v598 ~= v598 or (v598 == (1 / 0) or v598 == (-1 / 0)))) and 0 or v598
		local v600 = math.floor(v599)
		local v601 = math.max(0, v600)
		local v602 = p593.feeMax
		if type(v602) ~= "number" or (v602 ~= v602 or (v602 == (1 / 0) or v602 == (-1 / 0))) then
			v602 = v601
		end
		local v603 = math.floor(v602)
		local v604 = math.max(v601, v603)
		local v605 = v594 * v597 / 100
		local v606 = math.floor(v605)
		return math.clamp(v606, v601, v604)
	end,
	["listCap"] = function(p607, p608, p609) -- name: listCap
		-- upvalues: (copy) v_u_691
		if not v_u_691.listOn(p609) then
			return nil
		end
		local v610 = p609.capMul
		local v611 = (type(v610) ~= "number" or (v610 ~= v610 or (v610 == (1 / 0) or v610 == (-1 / 0)))) and 0 or v610
		if v611 <= 0 then
			return nil
		end
		local v612 = (type(p607) ~= "number" or p607 < 1) and 1 or math.floor(p607)
		local v613
		if type(p608) == "number" and (p608 == p608 and p608 > 0) then
			local v614 = v611 * p608 * v612 + 1e-9
			v613 = math.floor(v614)
		else
			local v615 = p609.capFlat
			local v616 = (type(v615) ~= "number" or (v615 ~= v615 or (v615 == (1 / 0) or v615 == (-1 / 0)))) and 0 or v615
			v613 = math.floor(v616) * v612
		end
		local v617 = math.max(v613, v612)
		return math.min(v617, 99999999)
	end,
	["listUnitValue"] = function(p618, p619) -- name: listUnitValue
		-- upvalues: (copy) v_u_691
		local v_u_620
		if type(p619) == "table" then
			local v621 = p619.value
			v_u_620 = type(v621) ~= "number" and 0 or p619.value
		else
			v_u_620 = 0
		end
		local v622 = v_u_691.cm
		if type(p618) == "string" and v622 ~= nil then
			local v623 = v622.refValue
			if type(v623) == "function" then
				local v624 = v622.refValue
				local v625, v626 = pcall(v624, p618, function()
					-- upvalues: (copy) v_u_620
					return v_u_620
				end)
				if v625 and (type(v626) == "number" and v626 == v626) then
					return v626
				end
			end
		end
		return v_u_620
	end,
	["listVerdict"] = function(p627, p628, p629, p630, p631, p632) -- name: listVerdict
		-- upvalues: (copy) v_u_691
		local v633 = {
			["on"] = nil,
			["fee"] = 0,
			["cap"] = nil,
			["hist"] = nil,
			["capHit"] = false,
			["short"] = 0,
			["on"] = v_u_691.listOn(p632)
		}
		if not v633.on then
			return v633
		end
		v633.fee = v_u_691.listFee(p627, p632)
		v633.cap = v_u_691.listCap(p628, p629, p632)
		if type(p630) == "table" then
			local v634 = p630.avg7
			v633.hist = type(v634) == "number"
		end
		if v633.cap ~= nil and (v633.hist == false and (type(p627) == "number" and v633.cap < p627)) then
			v633.capHit = true
		end
		local v635 = (type(p631) ~= "number" or (p631 ~= p631 or (p631 == (1 / 0) or p631 == (-1 / 0)))) and 0 or p631
		if v635 < v633.fee then
			v633.short = v633.fee - v635
		end
		return v633
	end,
	["listFeeLine"] = function(p636, p637) -- name: listFeeLine
		-- upvalues: (copy) v_u_691
		if v_u_691.listOn(p637) then
			return v_u_691.fill(v_u_691.TEXT.listFeeLine, {
				["fee"] = v_u_691.money(p636)
			})
		else
			return nil
		end
	end,
	["listCapLine"] = function(p638) -- name: listCapLine
		-- upvalues: (copy) v_u_691
		if type(p638) ~= "table" or (not p638.on or (p638.cap == nil or p638.hist == true)) then
			return nil
		end
		local v639 = v_u_691.fill
		local v640
		if p638.hist == nil then
			v640 = v_u_691.TEXT.capUnknown
		else
			v640 = v_u_691.TEXT.capLine
		end
		return v639(v640, {
			["max"] = v_u_691.money(p638.cap)
		})
	end,
	["listConfirmLines"] = function(p641) -- name: listConfirmLines
		-- upvalues: (copy) v_u_691
		local v642 = {}
		if type(p641) ~= "table" or not p641.on then
			return v642
		end
		local v643 = v_u_691.fill
		local v644 = v_u_691.TEXT.listFeeConfirm
		local v645 = {
			["fee"] = v_u_691.money(p641.fee)
		}
		table.insert(v642, v643(v644, v645))
		if p641.cap ~= nil and p641.hist ~= true then
			local v646 = v_u_691.fill
			local v647
			if p641.hist == nil then
				v647 = v_u_691.TEXT.capUnknown
			else
				v647 = v_u_691.TEXT.capConfirm
			end
			local v648 = {
				["max"] = v_u_691.money(p641.cap)
			}
			table.insert(v642, v646(v647, v648))
		end
		return v642
	end,
	["infoListLine"] = function(p649) -- name: infoListLine
		-- upvalues: (copy) v_u_691
		if not v_u_691.listOn(p649) then
			return nil
		end
		local v650 = p649.feeMin
		local v651 = (type(v650) ~= "number" or (v650 ~= v650 or (v650 == (1 / 0) or v650 == (-1 / 0)))) and 0 or v650
		local v652 = math.floor(v651)
		local v653 = p649.feeMax
		local v654 = (type(v653) ~= "number" or (v653 ~= v653 or (v653 == (1 / 0) or v653 == (-1 / 0)))) and 0 or v653
		local v655 = math.floor(v654)
		local v656 = p649.feePct
		local v657 = (type(v656) ~= "number" or (v656 ~= v656 or (v656 == (1 / 0) or v656 == (-1 / 0)))) and 0 or v656
		local v658 = ("Listing costs a fee of %s percent of the price, at least %s and at most %s. You pay it when you list. It is not paid back if you cancel or the listing runs out."):format(tostring(v657), v_u_691.money(v652), v_u_691.money(v655))
		local v659 = p649.capMul
		local v660 = (type(v659) ~= "number" or (v659 ~= v659 or (v659 == (1 / 0) or v659 == (-1 / 0)))) and 0 or v659
		if v660 > 0 then
			local v661 = p649.minSales
			local v662 = (type(v661) ~= "number" or (v661 ~= v661 or (v661 == (1 / 0) or v661 == (-1 / 0)))) and 3 or v661
			local v663 = math.floor(v662)
			local v664 = p649.days
			local v665 = (type(v664) ~= "number" or (v664 ~= v664 or (v664 == (1 / 0) or v664 == (-1 / 0)))) and 7 or v664
			v658 = v658 .. (" An item that has not sold %d times in %d days can be listed for at most %s times its trader value."):format(v663, math.floor(v665), (tostring(v660)))
		end
		return v658
	end,
	["pump"] = function(p_u_666, p_u_667, p_u_668, p_u_669) -- name: pump
		local v_u_670 = {}
		local v_u_671 = 0
		local v_u_672 = (-1 / 0)
		local v_u_673 = false
		return {
			["push"] = function(p674) -- name: push
				-- upvalues: (copy) v_u_670, (ref) v_u_673, (ref) v_u_671, (copy) p_u_667, (copy) p_u_668, (ref) v_u_672, (copy) p_u_666, (copy) p_u_669
				local v675 = v_u_670
				table.insert(v675, p674)
				if not v_u_673 then
					v_u_673 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_670, (ref) v_u_671, (ref) p_u_667, (ref) p_u_668, (ref) v_u_672, (ref) p_u_666, (ref) p_u_669, (ref) v_u_673
						while #v_u_670 > 0 do
							if v_u_671 < p_u_667 and p_u_666 <= p_u_668() - v_u_672 then
								local v_u_676 = table.remove(v_u_670, 1)
								v_u_671 = v_u_671 + 1
								v_u_672 = p_u_668()
								task.spawn(function()
									-- upvalues: (copy) v_u_676, (ref) v_u_671
									local v677 = v_u_676
									pcall(v677)
									v_u_671 = v_u_671 - 1
								end)
							else
								p_u_669(0.05)
							end
						end
						v_u_673 = false
					end)
				end
			end,
			["clear"] = function() -- name: clear
				-- upvalues: (copy) v_u_670
				table.clear(v_u_670)
			end,
			["size"] = function() -- name: size
				-- upvalues: (copy) v_u_670
				return #v_u_670
			end,
			["running"] = function() -- name: running
				-- upvalues: (ref) v_u_671
				return v_u_671
			end
		}
	end,
	["RETRY_MAX"] = 6,
	["retryDelay"] = function(p678, p679, p680) -- name: retryDelay
		local v681 = math.max(p678 or 1.5, 0.5)
		local v682 = p679 - 1
		local v683 = v681 * 2 ^ math.max(0, v682)
		return math.min(30, v683) * (p680 or 1)
	end,
	["RS"] = nil,
	["RS_NAME"] = "MARKET RESTOCK",
	["RS_WORD"] = "RESTOCK",
	["RS_TEXT"] = {
		["NOT_YET"] = "Opens in {wait}.",
		["OVER"] = "This restock has ended.",
		["PAUSED"] = "The restock is paused for a moment. Your Cash is safe.",
		["OFF_RS"] = "The restock is switched off right now.",
		["DISABLED"] = "The restock is not available right now.",
		["GONE"] = "That item is no longer part of the restock.",
		["REPLACED"] = "The restock was updated. Check the new prices.",
		["PRICE"] = "The price changed to ${price}. Check it and try again.",
		["QTY_MIN"] = "You need to buy at least {min}.",
		["QTY_MAX"] = "You can buy at most {max} at a time.",
		["CAP"] = "You reached your limit of {cap} per {window}. You can buy again in {resetIn}.",
		["CAP_ALL"] = "You reached your limit of {cap} for this restock.",
		["CAP_LESS"] = "Your limit leaves room for {avail} more. Buy {avail} instead.",
		["CASH"] = "Not enough Cash. You need ${need} more.",
		["MAIL_FULL"] = "Your mail already holds {max} restock deliveries. Move them to your stash first.",
		["STASH_FULL"] = "Your stash is full. Make room first.",
		["SOLD_OUT"] = "Sold out. Everything was bought.",
		["HELD"] = "Sold out for the moment. Some stock may come back. Try again in {retryIn} s.",
		["LESS_LEFT"] = "Only {avail} left right now. Buy {avail} instead.",
		["STOCK_BUSY"] = "Lots of buyers right now. Nothing was taken from you. Try again in {retryIn} s.",
		["DOWN"] = "The market cannot reach its storage right now. Nothing was taken from you.",
		["RAIDS"] = "Finish {need} more raids to buy from a restock.",
		["AGE"] = "Your account needs to be {days} days old to buy from a restock.",
		["HUSH_AGE"] = "Play {days} more days to buy from a restock.",
		["EXTRACTS"] = "Extract once to buy from a restock.",
		["TUTORIAL"] = "Finish the tutorial first.",
		["RS_LOCK"] = "Restock goods can be sold again in {t}.",
		["RESTOCK_CRATE"] = "That case is not part of a restock.",
		["NOT_RESTOCKABLE"] = "That item is not part of a restock.",
		["BAD"] = "That request is not valid.",
		["BUSY"] = "Another market action is still running. Try again in a moment.",
		["RATE"] = "Slow down a little.",
		["OPENING"] = "Opening now. The draw closes in {n} s.",
		["MAIL_WARN"] = "Your mail is full. Make room before the restock opens.",
		["BOUGHT"] = "Bought: {n} x {name} for ${p}. It is waiting in your mail.",
		["SAVING"] = "Saving."
	},
	["RS_EXTRA"] = {
		["CAP_GENERIC"] = "You reached your limit for now.",
		["GETTING"] = "Getting your share...",
		["TRY_AGAIN"] = "Try again in {retryIn} s",
		["TOTAL"] = "Total {total}",
		["NEXT_DROP"] = "Next drop in {t}",
		["DROP"] = "Drop {i} of {n}",
		["LIVE_AT"] = "RESTOCK live at {u} each",
		["CHEAPER"] = "Restock is cheaper: {u}. Cancel?"
	},
	["RS_SHORT"] = {
		["OVER"] = "Ended",
		["PAUSED"] = "Paused",
		["OFF_RS"] = "Switched off",
		["DISABLED"] = "Not available",
		["GONE"] = "Removed",
		["SOLD_OUT"] = "Sold out",
		["HELD"] = "Try again soon",
		["STOCK_BUSY"] = "Busy",
		["CAP"] = "Limit reached",
		["CAP_ALL"] = "Limit reached",
		["NOT_YET"] = "Opens soon",
		["DOWN"] = "Unavailable",
		["RAIDS"] = "Finish raids",
		["AGE"] = "Account too new",
		["HUSH_AGE"] = "Play more days",
		["EXTRACTS"] = "Extract once",
		["TUTORIAL"] = "Finish the tutorial",
		["SCOPE"] = "Not open yet",
		["MAIL_FULL"] = "Mail is full",
		["STASH_FULL"] = "Stash is full",
		["FREEZE"] = "Paused",
		["RS_LOCK"] = "Locked",
		["RESTOCK_CRATE"] = "Not part of it",
		["NOT_RESTOCKABLE"] = "Not part of it",
		["PRICE"] = "Price changed",
		["CASH"] = "Need more Cash"
	},
	["RS_CHIP"] = {
		["ok"] = {
			["kind"] = "ok",
			["text"] = "IN STOCK"
		},
		["low"] = {
			["kind"] = "low",
			["text"] = "LOW STOCK"
		},
		["held"] = {
			["kind"] = "held",
			["text"] = "SOLD OUT FOR NOW"
		},
		["out"] = {
			["kind"] = "out",
			["text"] = "SOLD OUT"
		},
		["paused"] = {
			["kind"] = "paused",
			["text"] = "PAUSED"
		},
		["soon"] = {
			["kind"] = "soon",
			["text"] = "OPENS SOON"
		},
		["draw"] = {
			["kind"] = "opening",
			["text"] = "OPENING"
		},
		["over"] = {
			["kind"] = "out",
			["text"] = "ENDED"
		}
	},
	["RS_TIME"] = {
		["confirmGuard"] = 0.4,
		["sendGap"] = 1.1,
		["confirmLife"] = 6,
		["answerWait"] = 6,
		["pollOpen"] = 5,
		["pollIdle"] = 15,
		["jitter"] = 1.5,
		["pulseLen"] = 30,
		["heldDefault"] = 10
	},
	["rsClock"] = function(p684) -- name: rsClock
		local v685
		if type(p684) == "number" and (p684 == p684 and p684 > (-1 / 0)) then
			v685 = p684 < (1 / 0)
		else
			v685 = false
		end
		local v686
		if v685 then
			local v687 = math.floor(p684)
			v686 = math.max(0, v687)
		else
			v686 = 0
		end
		local v688 = v686 // 3600
		local v689 = (v686 - v688 * 3600) // 60
		local v690 = v686 - v688 * 3600 - v689 * 60
		if v688 > 0 then
			return string.format("%02d:%02d:%02d", v688, v689, v690)
		else
			return string.format("%d:%02d", v689, v690)
		end
	end
}
local v_u_692 = {
	[900] = "15 minutes",
	[3600] = "hour",
	[21600] = "6 hours",
	[86400] = "day",
	[0] = "restock"
}
function v_u_691.rsWindowName(p693) -- name: rsWindowName
	-- upvalues: (copy) v_u_692
	return v_u_692[p693] or "hour"
end
local v_u_694 = {
	["wait"] = true,
	["resetIn"] = true,
	["t"] = true
}
function v_u_691.rsText(p695, p696, p_u_697) -- name: rsText
	-- upvalues: (copy) v_u_691, (copy) v_u_694
	if type(p696) ~= "string" or v_u_691.RS_TEXT[p696] == nil then
		return v_u_691.text(p695 or v_u_691.RS_RULES, p696, p_u_697)
	end
	local v698 = v_u_691.RS
	if v698 ~= nil then
		local v699 = v698.text
		if type(v699) == "function" then
			local v700 = v698.TEXT
			if type(v700) == "table" and v698.TEXT[p696] ~= nil then
				local v701 = v698.text
				local v702, v703 = pcall(v701, p696, p_u_697)
				if v702 and (type(v703) == "string" and v703 ~= "") then
					return v703
				end
			end
		end
	end
	local v704 = v_u_691.RS_TEXT[p696]
	if (p696 == "CAP" or p696 == "CAP_ALL") and type(p_u_697) == "table" then
		p_u_697 = table.clone(p_u_697)
		p_u_697.window = v_u_691.rsWindowName(p_u_697.w)
		if p696 == "CAP" and p_u_697.w == 0 then
			v704 = v_u_691.RS_TEXT.CAP_ALL
		end
	end
	return string.gsub(v704, "{(%w+)}", function(p705)
		-- upvalues: (copy) p_u_697, (ref) v_u_694, (ref) v_u_691
		local v706 = p_u_697
		local v707
		if type(v706) == "table" then
			v707 = p_u_697[p705]
		else
			v707 = nil
		end
		if v707 == nil then
			return "{" .. p705 .. "}"
		end
		if type(v707) ~= "number" then
			return tostring(v707)
		end
		if v_u_694[p705] then
			return v_u_691.rsClock(v707)
		end
		if p705 ~= "retryIn" then
			return v_u_691.commas(v707)
		end
		local v708 = math.ceil(v707)
		local v709 = math.max(0, v708)
		return tostring(v709)
	end)
end
v_u_691.RS_RULES = {
	["text"] = function(p710, p711) -- name: text
		-- upvalues: (copy) v_u_691
		local v712 = v_u_691.CODES[p710] or v_u_691.MORE[p710]
		if v712 then
			return v_u_691.fill(v712, p711)
		else
			return tostring(p710)
		end
	end
}
function v_u_691.rsPhase(p713, p714) -- name: rsPhase
	if type(p713) ~= "table" then
		return nil
	end
	local v715
	if type(p714) == "number" and (p714 == p714 and p714 > (-1 / 0)) then
		v715 = p714 < (1 / 0)
	else
		v715 = false
	end
	if not v715 then
		local v716 = p713.now
		local v717
		if type(v716) == "number" and (v716 == v716 and v716 > (-1 / 0)) then
			v717 = v716 < (1 / 0)
		else
			v717 = false
		end
		p714 = not v717 and 0 or p713.now
	end
	local v718 = p713.t1
	local v719
	if type(v718) == "number" and (v718 == v718 and v718 > (-1 / 0)) then
		v719 = v718 < (1 / 0)
	else
		v719 = false
	end
	if v719 and p713.t1 <= p714 then
		return "over"
	end
	if p713.ho == true then
		return "paused"
	end
	local v720 = p713.ra
	local v721
	if type(v720) == "number" and (v720 == v720 and v720 > (-1 / 0)) then
		v721 = v720 < (1 / 0)
	else
		v721 = false
	end
	if v721 and p714 < p713.ra then
		return "resume"
	end
	local v722 = p713.t0
	local v723
	if type(v722) == "number" and (v722 == v722 and v722 > (-1 / 0)) then
		v723 = v722 < (1 / 0)
	else
		v723 = false
	end
	return v723 and (p714 < p713.t0 and "soon" or "live") or (p713.ph == "live" and "live" or "soon")
end
local function v_u_735(p724, p725, p726) -- name: rsOpenOf
	local v727 = p725.open
	local v728
	if type(v727) == "number" and (v727 == v727 and v727 > (-1 / 0)) then
		v728 = v727 < (1 / 0)
	else
		v728 = false
	end
	if v728 then
		return p725.open
	end
	local v729
	if type(p726) == "number" and (p726 == p726 and p726 > (-1 / 0)) then
		v729 = p726 < (1 / 0)
	else
		v729 = false
	end
	if v729 then
		return p726
	end
	local v730 = p724.t0
	local v731
	if type(v730) == "number" and (v730 == v730 and v730 > (-1 / 0)) then
		v731 = v730 < (1 / 0)
	else
		v731 = false
	end
	local v732
	if v731 then
		v732 = p724.t0
	else
		v732 = nil
	end
	if v732 ~= nil then
		local v733 = p724.ra
		local v734
		if type(v733) == "number" and (v733 == v733 and v733 > (-1 / 0)) then
			v734 = v733 < (1 / 0)
		else
			v734 = false
		end
		if v734 and v732 < p724.ra then
			v732 = p724.ra
		end
	end
	return v732
end
function v_u_691.rsStage(p736, p737, p738, p739) -- name: rsStage
	-- upvalues: (copy) v_u_735
	if type(p736) ~= "table" or type(p737) ~= "table" then
		return "soon"
	end
	local v740 = v_u_735(p736, p737, p739)
	local v741 = p736.wd
	local v742
	if type(v741) == "number" and (v741 == v741 and v741 > (-1 / 0)) then
		v742 = v741 < (1 / 0)
	else
		v742 = false
	end
	local v743 = not v742 and 0 or p736.wd
	return (p737.st == "wait" or p737.ph == "soon") and ((v740 == nil or p738 < v740) and "soon" or (v743 > 0 and p738 < v740 + v743 and "draw" or "live")) or ((p737.st == "draw" or p737.ph == "draw") and ((v740 == nil or v740 + v743 > p738) and "draw" or "live") or "live")
end
function v_u_691.rsDrawLeft(p744, p745, p746, p747) -- name: rsDrawLeft
	-- upvalues: (copy) v_u_691, (copy) v_u_735
	if v_u_691.rsStage(p744, p745, p746, p747) ~= "draw" then
		return nil
	end
	local v748 = v_u_735(p744, p745, p747)
	if v748 == nil then
		return nil
	end
	local v749 = 0
	local v750 = p744.wd
	local v751
	if type(v750) == "number" and (v750 == v750 and v750 > (-1 / 0)) then
		v751 = v750 < (1 / 0)
	else
		v751 = false
	end
	local v752 = v748 + (not v751 and 0 or p744.wd) - p746
	return math.max(v749, v752)
end
function v_u_691.rsMarkValid(p753, p754) -- name: rsMarkValid
	local v755
	if type(p753) == "table" then
		local v756 = p753.at
		if type(v756) == "number" and (v756 == v756 and v756 > (-1 / 0)) then
			v755 = v756 < (1 / 0)
		else
			v755 = false
		end
		if v755 then
			local v757
			if type(p754) == "number" and (p754 == p754 and p754 > (-1 / 0)) then
				v757 = p754 < (1 / 0)
			else
				v757 = false
			end
			v755 = not v757 or p754 < p753.at
		end
	else
		v755 = false
	end
	return v755
end
function v_u_691.rsChip(p758, p759, p760, p761, p762) -- name: rsChip
	-- upvalues: (copy) v_u_691
	local v763 = v_u_691.rsPhase(p758, p760)
	if v763 == "over" then
		local v764 = v_u_691.RS_CHIP.over
		return {
			["kind"] = nil,
			["text"] = nil,
			["st"] = "over",
			["kind"] = v764.kind,
			["text"] = v764.text
		}
	elseif v763 == "paused" or v763 == "resume" then
		local v765 = v_u_691.RS_CHIP.paused
		return {
			["kind"] = nil,
			["text"] = nil,
			["st"] = "paused",
			["kind"] = v765.kind,
			["text"] = v765.text
		}
	else
		local v766 = v_u_691.rsStage(p758, p759, p760, p762)
		if v766 == "soon" then
			local v767 = v_u_691.RS_CHIP.soon
			return {
				["kind"] = nil,
				["text"] = nil,
				["st"] = "soon",
				["kind"] = v767.kind,
				["text"] = v767.text
			}
		elseif v766 == "draw" then
			local v768 = v_u_691.RS_CHIP.draw
			return {
				["kind"] = nil,
				["text"] = nil,
				["st"] = "draw",
				["kind"] = v768.kind,
				["text"] = v768.text
			}
		else
			local v769 = p759.st
			local v770 = type(p761) == "table" and p761.st == "out" and "out" or v769
			if v770 == "low" or (v770 == "held" or v770 == "out") then
				local v771 = v_u_691.RS_CHIP[v770]
				return {
					["kind"] = v771.kind,
					["text"] = v771.text,
					["st"] = v770
				}
			else
				local v772 = v_u_691.RS_CHIP.ok
				return {
					["kind"] = nil,
					["text"] = nil,
					["st"] = "ok",
					["kind"] = v772.kind,
					["text"] = v772.text
				}
			end
		end
	end
end
function v_u_691.rsLimitLine(p773) -- name: rsLimitLine
	-- upvalues: (copy) v_u_691
	if type(p773) == "table" then
		local v774 = p773.c
		local v775
		if type(v774) == "number" and (v774 == v774 and v774 > (-1 / 0)) then
			v775 = v774 < (1 / 0)
		else
			v775 = false
		end
		if v775 and p773.c > 0 then
			return ("Limit %s per %s"):format(v_u_691.commas(p773.c), v_u_691.rsWindowName(p773.w or 0))
		end
	end
	return nil
end
function v_u_691.rsLeftLine(p776, p777, p778) -- name: rsLeftLine
	-- upvalues: (copy) v_u_691
	local v779 = p776 or v_u_691.RS_RULES
	if type(p777) == "table" then
		local v780 = p777.left
		local v781
		if type(v780) == "number" and (v780 == v780 and v780 > (-1 / 0)) then
			v781 = v780 < (1 / 0)
		else
			v781 = false
		end
		if v781 then
			local v782 = p777.reset
			local v783
			if type(v782) == "number" and (v782 == v782 and v782 > (-1 / 0)) then
				v783 = v782 < (1 / 0)
			else
				v783 = false
			end
			local v784
			if v783 then
				local v785 = p777.reset - (p778 or 0)
				v784 = math.max(0, v785)
			else
				v784 = nil
			end
			local v786 = p777.w or 0
			if p777.left < (p777.q1 or 1) and (v784 == nil or v784 > 0) then
				return v_u_691.rsText(v779, v786 == 0 and "CAP_ALL" or "CAP", {
					["cap"] = p777.c,
					["w"] = v786,
					["resetIn"] = v784
				})
			end
			local v787 = ("You can still buy %s."):format(v_u_691.commas(p777.left))
			if v784 ~= nil and v786 ~= 0 then
				v787 = v787 .. " Resets in " .. v_u_691.rsClock(v784)
			end
			return v787
		end
	end
	return nil
end
function v_u_691.rsMaxQty(p788, p789) -- name: rsMaxQty
	local v790 = p788.q2
	local v791 = p788.left
	local v792
	if type(v791) == "number" and (v791 == v791 and v791 > (-1 / 0)) then
		v792 = v791 < (1 / 0)
	else
		v792 = false
	end
	if v792 then
		local v793 = p788.left
		v790 = math.min(v790, v793)
	end
	local v794
	if type(p789) == "number" and (p789 == p789 and p789 > (-1 / 0)) then
		v794 = p789 < (1 / 0)
	else
		v794 = false
	end
	if v794 then
		local v795 = p788.u
		local v796
		if type(v795) == "number" and (v795 == v795 and v795 > (-1 / 0)) then
			v796 = v795 < (1 / 0)
		else
			v796 = false
		end
		if v796 and p788.u > 0 then
			local v797 = p789 / p788.u
			local v798 = math.floor(v797)
			v790 = math.min(v790, v798)
		end
	end
	return v790
end
function v_u_691.rsClampQty(p799, p800, p801) -- name: rsClampQty
	-- upvalues: (copy) v_u_691
	local v802 = p799.q1
	local v803 = v_u_691.rsMaxQty
	local v804 = math.max(v802, v803(p799, p801))
	local v805
	if type(p800) == "number" and (p800 == p800 and p800 > (-1 / 0)) then
		v805 = p800 < (1 / 0)
	else
		v805 = false
	end
	local v806
	if v805 then
		v806 = math.floor(p800)
	else
		v806 = v802
	end
	local v807 = math.min(v806, v804)
	return math.max(v802, v807)
end
function v_u_691.rsStepQty(p808, p809, p810, p811) -- name: rsStepQty
	-- upvalues: (copy) v_u_691
	local v812 = p808.q1
	local v813
	if type(p809) == "number" and (p809 == p809 and p809 > (-1 / 0)) then
		v813 = p809 < (1 / 0)
	else
		v813 = false
	end
	local v814
	if v813 then
		v814 = math.floor(p809)
	else
		v814 = v812
	end
	if p810 == "up" then
		v814 = v814 + v812
	elseif p810 == "down" then
		v814 = v814 - v812
	elseif p810 == "tenUp" then
		v814 = v814 + v812 * 10
	elseif p810 == "tenDown" then
		v814 = v814 - v812 * 10
	elseif p810 == "min" then
		v814 = v812
	elseif p810 == "max" then
		v814 = v_u_691.rsMaxQty(p808, p811)
	end
	return v_u_691.rsClampQty(p808, v814, p811)
end
function v_u_691.rsConfirm(p815, p816) -- name: rsConfirm
	-- upvalues: (copy) v_u_691
	local v817
	if type(p815) == "number" and (p815 == p815 and p815 > (-1 / 0)) then
		v817 = p815 < (1 / 0)
	else
		v817 = false
	end
	if not v817 then
		return {
			["armed"] = false,
			["accepts"] = false,
			["expired"] = false,
			["left"] = 0
		}
	end
	local v818 = p816 - p815
	local v819 = v_u_691.RS
	local v820, v821, v822, v823, v824, v825
	if v819 == nil then
		v820 = v_u_691.RS_TIME.confirmLife
		v821 = {
			["armed"] = v818 <= v820
		}
		v822 = false
		v823 = v_u_691.RS
		if v823 == nil then
			v824 = v_u_691.RS_TIME.confirmGuard
			if v824 <= v818 then
				v822 = v818 <= v820
			end
			v821.accepts = v822
			v821.expired = v820 < v818
			v825 = v820 - v818
			v821.left = math.max(0, v825)
			return v821
		end
	else
		local v826 = v819.RS
		if type(v826) == "table" then
			local v827 = v819.RS.confirmLife
			if type(v827) == "number" then
				v820 = v819.RS.confirmLife
				v821 = {
					["armed"] = v818 <= v820
				}
				v822 = false
				v823 = v_u_691.RS
				if v823 == nil then
					v824 = v_u_691.RS_TIME.confirmGuard
					if v824 <= v818 then
						v822 = v818 <= v820
					end
					v821.accepts = v822
					v821.expired = v820 < v818
					v825 = v820 - v818
					v821.left = math.max(0, v825)
					return v821
				end
			else
				v820 = v_u_691.RS_TIME.confirmLife
				v821 = {
					["armed"] = v818 <= v820
				}
				v822 = false
				v823 = v_u_691.RS
				if v823 == nil then
					v824 = v_u_691.RS_TIME.confirmGuard
					if v824 <= v818 then
						v822 = v818 <= v820
					end
					v821.accepts = v822
					v821.expired = v820 < v818
					v825 = v820 - v818
					v821.left = math.max(0, v825)
					return v821
				end
			end
		else
			v820 = v_u_691.RS_TIME.confirmLife
			v821 = {
				["armed"] = v818 <= v820
			}
			v822 = false
			v823 = v_u_691.RS
			if v823 == nil then
				v824 = v_u_691.RS_TIME.confirmGuard
				if v824 <= v818 then
					v822 = v818 <= v820
				end
				v821.accepts = v822
				v821.expired = v820 < v818
				v825 = v820 - v818
				v821.left = math.max(0, v825)
				return v821
			end
		end
	end
	local v828 = v823.RS
	if type(v828) == "table" then
		local v829 = v823.RS.confirmGuard
		if type(v829) == "number" then
			v824 = v823.RS.confirmGuard
			if v824 <= v818 then
				v822 = v818 <= v820
			end
			v821.accepts = v822
			v821.expired = v820 < v818
			v825 = v820 - v818
			v821.left = math.max(0, v825)
			return v821
		else
			v824 = v_u_691.RS_TIME.confirmGuard
			if v824 <= v818 then
				v822 = v818 <= v820
			end
			v821.accepts = v822
			v821.expired = v820 < v818
			v825 = v820 - v818
			v821.left = math.max(0, v825)
			return v821
		end
	else
		v824 = v_u_691.RS_TIME.confirmGuard
		if v824 <= v818 then
			v822 = v818 <= v820
		end
		v821.accepts = v822
		v821.expired = v820 < v818
		v825 = v820 - v818
		v821.left = math.max(0, v825)
		return v821
	end
end
function v_u_691.rsConfirmLabel(p830) -- name: rsConfirmLabel
	-- upvalues: (copy) v_u_691
	return "CONFIRM " .. v_u_691.money(p830)
end
function v_u_691.rsCanSend(p831, p832) -- name: rsCanSend
	-- upvalues: (copy) v_u_691
	local v833
	if type(p831) == "number" and (p831 == p831 and p831 > (-1 / 0)) then
		v833 = p831 < (1 / 0)
	else
		v833 = false
	end
	local v834 = not v833
	if v834 then
		return v834
	end
	local v835 = p832 - p831
	local v836 = v_u_691.RS
	local v837
	if v836 == nil then
		v837 = v_u_691.RS_TIME.sendGap
		v834 = v837 <= v835
	else
		local v838 = v836.RS
		if type(v838) == "table" then
			local v839 = v836.RS.sendGap
			if type(v839) == "number" then
				v837 = v836.RS.sendGap
				v834 = v837 <= v835
			else
				v837 = v_u_691.RS_TIME.sendGap
				v834 = v837 <= v835
			end
		else
			v837 = v_u_691.RS_TIME.sendGap
			v834 = v837 <= v835
		end
	end
	return v834
end
function v_u_691.rsButton(p840, p841, p842) -- name: rsButton
	-- upvalues: (copy) v_u_691, (copy) v_u_735, (copy) v_u_694
	local v843 = type(p842) ~= "table" and {} or p842
	local v844 = v843.rules or v_u_691.RS_RULES
	local function v853(p845, p846, p847, p848) -- name: off
		-- upvalues: (ref) v_u_691
		local v849 = {
			["show"] = true,
			["enabled"] = false,
			["why"] = nil,
			["reason"] = nil,
			["short"] = nil,
			["label"] = "BUY",
			["why"] = p845,
			["reason"] = p846
		}
		if not p847 then
			local v850
			if type(p845) == "string" then
				v850 = v_u_691.RS_SHORT[p845]
			else
				v850 = nil
			end
			p847 = v850 or "Unavailable"
		end
		v849.short = p847
		if p848 then
			for v851, v852 in p848 do
				v849[v851] = v852
			end
		end
		return v849
	end
	if type(p840) ~= "table" or type(p841) ~= "table" then
		return {
			["show"] = false,
			["enabled"] = false,
			["why"] = "NONE",
			["label"] = "BUY"
		}
	end
	local v854 = v843.now
	local v855
	if type(v854) == "number" and (v854 == v854 and v854 > (-1 / 0)) then
		v855 = v854 < (1 / 0)
	else
		v855 = false
	end
	local v856
	if v855 then
		v856 = v843.now
	else
		local v857 = p840.now
		local v858
		if type(v857) == "number" and (v857 == v857 and v857 > (-1 / 0)) then
			v858 = v857 < (1 / 0)
		else
			v858 = false
		end
		v856 = not v858 and 0 or p840.now
	end
	local v859 = v843.age
	local v860
	if type(v859) == "number" and (v859 == v859 and v859 > (-1 / 0)) then
		v860 = v859 < (1 / 0)
	else
		v860 = false
	end
	local v861
	if v860 then
		local v862 = v843.age
		v861 = math.max(0, v862)
	else
		v861 = 0
	end
	local v863 = v_u_691.rsPhase(p840, v856)
	if v863 == "over" then
		return v853("OVER", v_u_691.rsText(v844, "OVER"))
	end
	local v864 = v843.st
	if type(v864) == "table" then
		local v865 = v864.on
		if type(v865) == "table" then
			if v864.on.freeze == true then
				return v853("FREEZE", v_u_691.text(v844, "FREEZE"))
			end
			if v864.on.scope == false then
				return v853("SCOPE", v_u_691.text(v844, "SCOPE"))
			end
		end
	end
	local v866 = p840.gate
	if type(v866) == "table" then
		local v867 = v866.code
		if type(v867) == "string" then
			local v868 = v866.code
			local v869 = v866.text
			local v870
			if type(v869) == "string" and v866.text ~= "" then
				v870 = v866.text
			else
				v870 = v_u_691.rsText(v844, v866.code, {
					["max"] = 24,
					["need"] = 1,
					["days"] = 1
				})
			end
			local v871 = {
				["show"] = true,
				["enabled"] = false,
				["why"] = nil,
				["reason"] = nil,
				["short"] = nil,
				["label"] = "BUY",
				["why"] = v868,
				["reason"] = v870
			}
			local v872
			if type(v868) == "string" then
				v872 = v_u_691.RS_SHORT[v868]
			else
				v872 = nil
			end
			v871.short = v872 or "Unavailable"
			return v871
		end
	end
	if v863 == "paused" or v863 == "resume" then
		return v853("PAUSED", v_u_691.rsText(v844, "PAUSED"))
	end
	local v873 = v_u_691.rsStage(p840, p841, v856, v843.openHint)
	if v873 == "soon" then
		local v874 = v_u_735(p840, p841, v843.openHint)
		local v875
		if v874 == nil then
			v875 = 0
		else
			local v876 = v874 - v856
			local v877 = math.ceil(v876)
			v875 = math.max(0, v877)
		end
		return v853("NOT_YET", v_u_691.rsText(v844, "NOT_YET", {
			["wait"] = v875
		}), nil, {
			["wait"] = v875
		})
	end
	if p841.can == false then
		local v878 = p841.why
		if type(v878) == "string" then
			local v879 = p841.why
			if v879 ~= "NOT_YET" and (v879 ~= "SOLD_OUT" and (v879 ~= "HELD" and (v879 ~= "CAP" and (v879 ~= "CAP_ALL" and (v879 ~= "PAUSED" and v879 ~= "OVER"))))) then
				return v853(v879, v_u_691.rsText(v844, v879, {
					["max"] = 24,
					["need"] = 1,
					["days"] = 1,
					["t"] = 0
				}))
			end
		end
	end
	local v880 = p841.st
	local v881 = v_u_691.rsMarkValid(v843.mark, v843.bodyAt) and v843.mark.st == "out" and "out" or v880
	if v881 == "out" then
		return v853("SOLD_OUT", v_u_691.rsText(v844, "SOLD_OUT"))
	end
	local v882 = v843.last
	if type(v882) == "table" and (v882.code == "HELD" or v882.code == "STOCK_BUSY") then
		local v883 = v882.retryAt
		local v884
		if type(v883) == "number" and (v883 == v883 and v883 > (-1 / 0)) then
			v884 = v883 < (1 / 0)
		else
			v884 = false
		end
		if v884 then
			local v885 = v843.clock
			local v886
			if type(v885) == "number" and (v885 == v885 and v885 > (-1 / 0)) then
				v886 = v885 < (1 / 0)
			else
				v886 = false
			end
			if v886 and v843.clock < v882.retryAt then
				local v887 = v882.retryAt - v843.clock
				local v888 = math.ceil(v887)
				local v889 = math.max(1, v888)
				local v890 = v882.code
				local v891 = v_u_691.rsText(v844, v882.code, {
					["retryIn"] = v889
				})
				local v892 = v_u_691.RS_EXTRA.TRY_AGAIN
				local v_u_893 = {
					["retryIn"] = v889
				}
				return v853(v890, v891, string.gsub(v892, "{(%w+)}", function(p894)
					-- upvalues: (copy) v_u_893, (ref) v_u_694, (ref) v_u_691
					local v895 = v_u_893
					local v896
					if type(v895) == "table" then
						v896 = v_u_893[p894]
					else
						v896 = nil
					end
					if v896 == nil then
						return "{" .. p894 .. "}"
					end
					if type(v896) ~= "number" then
						return tostring(v896)
					end
					if v_u_694[p894] then
						return v_u_691.rsClock(v896)
					end
					if p894 ~= "retryIn" then
						return v_u_691.commas(v896)
					end
					local v897 = math.ceil(v896)
					local v898 = math.max(0, v897)
					return tostring(v898)
				end), {
					["retry"] = v889
				})
			end
		end
	end
	if v881 == "held" then
		local v899 = p841.retryIn
		local v900
		if type(v899) == "number" and (v899 == v899 and v899 > (-1 / 0)) then
			v900 = v899 < (1 / 0)
		else
			v900 = false
		end
		local v901
		if v900 then
			v901 = p841.retryIn
		else
			local v902 = v_u_691.RS
			if v902 == nil then
				v901 = v_u_691.RS_TIME.heldDefault
			else
				local v903 = v902.RS
				if type(v903) == "table" then
					local v904 = v902.RS.heldDefault
					if type(v904) == "number" then
						v901 = v902.RS.heldDefault
					else
						v901 = v_u_691.RS_TIME.heldDefault
					end
				else
					v901 = v_u_691.RS_TIME.heldDefault
				end
			end
		end
		local v905 = v901 - v861
		local v906 = math.ceil(v905)
		if v906 > 0 then
			local v907 = v_u_691.rsText(v844, "HELD", {
				["retryIn"] = v906
			})
			local v908 = v_u_691.RS_EXTRA.TRY_AGAIN
			local v_u_909 = {
				["retryIn"] = v906
			}
			return v853("HELD", v907, string.gsub(v908, "{(%w+)}", function(p910)
				-- upvalues: (copy) v_u_909, (ref) v_u_694, (ref) v_u_691
				local v911 = v_u_909
				local v912
				if type(v911) == "table" then
					v912 = v_u_909[p910]
				else
					v912 = nil
				end
				if v912 == nil then
					return "{" .. p910 .. "}"
				end
				if type(v912) ~= "number" then
					return tostring(v912)
				end
				if v_u_694[p910] then
					return v_u_691.rsClock(v912)
				end
				if p910 ~= "retryIn" then
					return v_u_691.commas(v912)
				end
				local v913 = math.ceil(v912)
				local v914 = math.max(0, v913)
				return tostring(v914)
			end), {
				["retry"] = v906
			})
		end
	end
	local v915 = p841.q1
	local v916 = p841.left
	local v917
	if type(v916) == "number" and (v916 == v916 and v916 > (-1 / 0)) then
		v917 = v916 < (1 / 0)
	else
		v917 = false
	end
	local v918
	if v917 then
		v918 = p841.left
	else
		v918 = nil
	end
	local v919 = p841.reset
	local v920
	if type(v919) == "number" and (v919 == v919 and v919 > (-1 / 0)) then
		v920 = v919 < (1 / 0)
	else
		v920 = false
	end
	local v921
	if v920 then
		v921 = p841.reset - v861
	else
		v921 = nil
	end
	local v922
	if v921 == nil then
		v922 = false
	else
		v922 = v921 <= 0
	end
	if v918 ~= nil and (v918 < v915 and not v922) then
		local v923 = p841.w or 0
		local v924 = v923 == 0 and "CAP_ALL" or "CAP"
		return v853(v924, v_u_691.rsText(v844, v924, {
			["cap"] = p841.c,
			["w"] = v923,
			["resetIn"] = v921
		}), nil, {
			["resetIn"] = v921
		})
	end
	if v918 == nil and (p841.can == false and (p841.why == "CAP" or p841.why == "CAP_ALL")) then
		local v925 = p841.why
		local v926 = {
			["show"] = true,
			["enabled"] = false,
			["why"] = nil,
			["reason"] = nil,
			["short"] = nil,
			["label"] = "BUY",
			["why"] = v925,
			["reason"] = v_u_691.RS_EXTRA.CAP_GENERIC
		}
		local v927
		if type(v925) == "string" then
			v927 = v_u_691.RS_SHORT[v925]
		else
			v927 = nil
		end
		v926.short = v927 or "Unavailable"
		return v926
	end
	local v928 = v843.qty
	local v929
	if type(v928) == "number" and (v928 == v928 and v928 > (-1 / 0)) then
		v929 = v928 < (1 / 0)
	else
		v929 = false
	end
	local v930
	if v929 then
		v930 = v843.qty
	else
		v930 = v915
	end
	local v931 = nil
	local v932, v933, v934
	if type(v882) == "table" and (v882.code == "CAP_LESS" or v882.code == "LESS_LEFT") then
		local v935 = v882.avail
		local v936
		if type(v935) == "number" and (v935 == v935 and v935 > (-1 / 0)) then
			v936 = v935 < (1 / 0)
		else
			v936 = false
		end
		if v936 and (v915 <= v882.avail and v882.avail < v930) then
			v918 = v882.avail
			if v918 ~= nil then
				return {
					["show"] = true,
					["enabled"] = true,
					["why"] = "LESS",
					["label"] = nil,
					["less"] = nil,
					["setQty"] = nil,
					["total"] = nil,
					["label"] = "BUY " .. v_u_691.commas(v918),
					["less"] = v918,
					["setQty"] = v918,
					["total"] = p841.u * v918
				}
			end
			v932 = v843.sinceSend
			if type(v932) == "number" and (v932 == v932 and v932 > (-1 / 0)) then
				v933 = v932 < (1 / 0)
			else
				v933 = false
			end
			if not v933 then
				if v930 < v915 or p841.q2 < v930 then
					return {
						["show"] = true,
						["enabled"] = false,
						["why"] = "QTY",
						["reason"] = nil,
						["short"] = "Wrong amount",
						["label"] = "BUY",
						["reason"] = v_u_691.rsText(v844, v930 < v915 and "QTY_MIN" or "QTY_MAX", {
							["min"] = v915,
							["max"] = p841.q2
						})
					}
				end
				v948 = p841.u * v930
				v949 = v843.cash
				if type(v949) == "number" and (v949 == v949 and v949 > (-1 / 0)) then
					v934 = v949 < (1 / 0)
				else
					v934 = false
				end
				if not v934 or v843.cash >= v948 then
					return {
						["show"] = true,
						["enabled"] = true,
						["why"] = "OK",
						["label"] = "BUY",
						["total"] = nil,
						["draw"] = nil,
						["total"] = v948,
						["draw"] = v873 == "draw"
					}
				end
				v950 = {
					["total"] = v948
				}
				v951 = {
					["show"] = true,
					["enabled"] = false,
					["why"] = "CASH",
					["reason"] = nil,
					["short"] = nil,
					["label"] = "BUY",
					["reason"] = v_u_691.rsText(v844, "CASH", {
						["need"] = v948 - v843.cash
					}),
					["short"] = ("Need %s more"):format(v_u_691.money(v948 - v843.cash)) or (v_u_691.RS_SHORT.CASH or "Unavailable")
				}
				if v950 then
					for v952, v953 in v950 do
						v951[v952] = v953
					end
				end
				return v951
			end
		else
			if v918 == nil or (v922 or v915 > v918) then
				v918 = v931
			elseif v918 >= v930 then
				v918 = v931
			end
			if v918 ~= nil then
				return {
					["show"] = true,
					["enabled"] = true,
					["why"] = "LESS",
					["label"] = nil,
					["less"] = nil,
					["setQty"] = nil,
					["total"] = nil,
					["label"] = "BUY " .. v_u_691.commas(v918),
					["less"] = v918,
					["setQty"] = v918,
					["total"] = p841.u * v918
				}
			end
			v932 = v843.sinceSend
			if type(v932) == "number" and (v932 == v932 and v932 > (-1 / 0)) then
				v933 = v932 < (1 / 0)
			else
				v933 = false
			end
			if not v933 then
				if v930 < v915 or p841.q2 < v930 then
					return {
						["show"] = true,
						["enabled"] = false,
						["why"] = "QTY",
						["reason"] = nil,
						["short"] = "Wrong amount",
						["label"] = "BUY",
						["reason"] = v_u_691.rsText(v844, v930 < v915 and "QTY_MIN" or "QTY_MAX", {
							["min"] = v915,
							["max"] = p841.q2
						})
					}
				end
				v948 = p841.u * v930
				v949 = v843.cash
				if type(v949) == "number" and (v949 == v949 and v949 > (-1 / 0)) then
					v934 = v949 < (1 / 0)
				else
					v934 = false
				end
				if not v934 or v843.cash >= v948 then
					return {
						["show"] = true,
						["enabled"] = true,
						["why"] = "OK",
						["label"] = "BUY",
						["total"] = nil,
						["draw"] = nil,
						["total"] = v948,
						["draw"] = v873 == "draw"
					}
				end
				v950 = {
					["total"] = v948
				}
				v951 = {
					["show"] = true,
					["enabled"] = false,
					["why"] = "CASH",
					["reason"] = nil,
					["short"] = nil,
					["label"] = "BUY",
					["reason"] = v_u_691.rsText(v844, "CASH", {
						["need"] = v948 - v843.cash
					}),
					["short"] = ("Need %s more"):format(v_u_691.money(v948 - v843.cash)) or (v_u_691.RS_SHORT.CASH or "Unavailable")
				}
				if v950 then
					for v952, v953 in v950 do
						v951[v952] = v953
					end
				end
				return v951
			end
		end
	else
		if v918 == nil or (v922 or v915 > v918) then
			v918 = v931
		elseif v918 >= v930 then
			v918 = v931
		end
		if v918 ~= nil then
			return {
				["show"] = true,
				["enabled"] = true,
				["why"] = "LESS",
				["label"] = nil,
				["less"] = nil,
				["setQty"] = nil,
				["total"] = nil,
				["label"] = "BUY " .. v_u_691.commas(v918),
				["less"] = v918,
				["setQty"] = v918,
				["total"] = p841.u * v918
			}
		end
		v932 = v843.sinceSend
		if type(v932) == "number" and (v932 == v932 and v932 > (-1 / 0)) then
			v933 = v932 < (1 / 0)
		else
			v933 = false
		end
		if not v933 then
			if v930 < v915 or p841.q2 < v930 then
				return {
					["show"] = true,
					["enabled"] = false,
					["why"] = "QTY",
					["reason"] = nil,
					["short"] = "Wrong amount",
					["label"] = "BUY",
					["reason"] = v_u_691.rsText(v844, v930 < v915 and "QTY_MIN" or "QTY_MAX", {
						["min"] = v915,
						["max"] = p841.q2
					})
				}
			end
			v948 = p841.u * v930
			v949 = v843.cash
			if type(v949) == "number" and (v949 == v949 and v949 > (-1 / 0)) then
				v934 = v949 < (1 / 0)
			else
				v934 = false
			end
			if not v934 or v843.cash >= v948 then
				return {
					["show"] = true,
					["enabled"] = true,
					["why"] = "OK",
					["label"] = "BUY",
					["total"] = nil,
					["draw"] = nil,
					["total"] = v948,
					["draw"] = v873 == "draw"
				}
			end
			v950 = {
				["total"] = v948
			}
			v951 = {
				["show"] = true,
				["enabled"] = false,
				["why"] = "CASH",
				["reason"] = nil,
				["short"] = nil,
				["label"] = "BUY",
				["reason"] = v_u_691.rsText(v844, "CASH", {
					["need"] = v948 - v843.cash
				}),
				["short"] = ("Need %s more"):format(v_u_691.money(v948 - v843.cash)) or (v_u_691.RS_SHORT.CASH or "Unavailable")
			}
			if v950 then
				for v952, v953 in v950 do
					v951[v952] = v953
				end
			end
			return v951
		end
	end
	local v943 = v843.sinceSend
	local v944 = v_u_691.RS
	local v945
	if v944 == nil then
		v945 = v_u_691.RS_TIME.sendGap
		if v943 < v945 then
			return v853("GAP", nil, nil, {
				["brief"] = true
			})
		end
	else
		local v946 = v944.RS
		if type(v946) == "table" then
			local v947 = v944.RS.sendGap
			if type(v947) == "number" then
				v945 = v944.RS.sendGap
				if v943 < v945 then
					return v853("GAP", nil, nil, {
						["brief"] = true
					})
				end
			else
				v945 = v_u_691.RS_TIME.sendGap
				if v943 < v945 then
					return v853("GAP", nil, nil, {
						["brief"] = true
					})
				end
			end
		else
			v945 = v_u_691.RS_TIME.sendGap
			if v943 < v945 then
				return v853("GAP", nil, nil, {
					["brief"] = true
				})
			end
		end
	end
	if v930 < v915 or p841.q2 < v930 then
		return {
			["show"] = true,
			["enabled"] = false,
			["why"] = "QTY",
			["reason"] = nil,
			["short"] = "Wrong amount",
			["label"] = "BUY",
			["reason"] = v_u_691.rsText(v844, v930 < v915 and "QTY_MIN" or "QTY_MAX", {
				["min"] = v915,
				["max"] = p841.q2
			})
		}
	end
	local v948 = p841.u * v930
	local v949 = v843.cash
	if type(v949) == "number" and (v949 == v949 and v949 > (-1 / 0)) then
		v934 = v949 < (1 / 0)
	else
		v934 = false
	end
	if not v934 or v843.cash >= v948 then
		return {
			["show"] = true,
			["enabled"] = true,
			["why"] = "OK",
			["label"] = "BUY",
			["total"] = nil,
			["draw"] = nil,
			["total"] = v948,
			["draw"] = v873 == "draw"
		}
	end
	local v950 = {
		["total"] = v948
	}
	local v951 = {
		["show"] = true,
		["enabled"] = false,
		["why"] = "CASH",
		["reason"] = nil,
		["short"] = nil,
		["label"] = "BUY",
		["reason"] = v_u_691.rsText(v844, "CASH", {
			["need"] = v948 - v843.cash
		}),
		["short"] = ("Need %s more"):format(v_u_691.money(v948 - v843.cash)) or (v_u_691.RS_SHORT.CASH or "Unavailable")
	}
	if v950 then
		for v952, v953 in v950 do
			v951[v952] = v953
		end
	end
	return v951
end
function v_u_691.rsCard(p954, p955, p956) -- name: rsCard
	-- upvalues: (copy) v_u_691, (copy) v_u_694, (copy) v_u_735
	local v957 = type(p956) ~= "table" and {} or p956
	local v958 = v957.rules or v_u_691.RS_RULES
	local v959 = v957.now
	local v960
	if type(v959) == "number" and (v959 == v959 and v959 > (-1 / 0)) then
		v960 = v959 < (1 / 0)
	else
		v960 = false
	end
	local v961
	if v960 then
		v961 = v957.now
	else
		local v962 = p954.now
		local v963
		if type(v962) == "number" and (v962 == v962 and v962 > (-1 / 0)) then
			v963 = v962 < (1 / 0)
		else
			v963 = false
		end
		v961 = not v963 and 0 or p954.now
	end
	local v964 = v957.age
	local v965
	if type(v964) == "number" and (v964 == v964 and v964 > (-1 / 0)) then
		v965 = v964 < (1 / 0)
	else
		v965 = false
	end
	local v966
	if v965 then
		local v967 = v957.age
		v966 = math.max(0, v967)
	else
		v966 = 0
	end
	local v968 = p955.id
	local v969 = v957.nameOf
	local v970
	if type(v969) == "function" then
		local v971 = v957.nameOf
		local v972 = p955.id
		local v973
		v973, v970 = pcall(v971, v972)
		if v973 and type(v970) == "string" then
			if v970 == "" then
				v970 = v968
			end
		else
			v970 = v968
		end
	else
		v970 = v968
	end
	local v974 = v_u_691.rsClampQty(p955, v957.qty, v957.cash)
	local v975 = table.clone(v957)
	v975.qty = v974
	local v976 = v_u_691.rsButton(p954, p955, v975)
	local v977 = v_u_691.rsStage(p954, p955, v961, v957.openHint)
	local v978
	if v_u_691.rsMarkValid(v957.mark, v957.bodyAt) then
		v978 = v957.mark
	else
		v978 = nil
	end
	local v979 = {
		["ix"] = p955.i,
		["id"] = p955.id,
		["name"] = v970,
		["word"] = v_u_691.RS_WORD,
		["u"] = p955.u,
		["unit"] = v_u_691.unitMoney(p955.u) .. " each",
		["chip"] = v_u_691.rsChip(p954, p955, v961, v978, v957.openHint),
		["stage"] = v977,
		["qty"] = v974,
		["q1"] = p955.q1,
		["q2"] = p955.q2
	}
	local v980 = p955.q1
	local v981 = v_u_691.rsMaxQty
	local v982 = v957.cash
	v979.max = math.max(v980, v981(p955, v982))
	v979.step = p955.q1
	v979.total = p955.u * v974
	v979.button = v976
	local v983 = v_u_691.RS_EXTRA.TOTAL
	local v_u_984 = {
		["total"] = v_u_691.money(v979.total)
	}
	v979.totalText = string.gsub(v983, "{(%w+)}", function(p985)
		-- upvalues: (copy) v_u_984, (ref) v_u_694, (ref) v_u_691
		local v986 = v_u_984
		local v987
		if type(v986) == "table" then
			v987 = v_u_984[p985]
		else
			v987 = nil
		end
		if v987 == nil then
			return "{" .. p985 .. "}"
		end
		if type(v987) ~= "number" then
			return tostring(v987)
		end
		if v_u_694[p985] then
			return v_u_691.rsClock(v987)
		end
		if p985 ~= "retryIn" then
			return v_u_691.commas(v987)
		end
		local v988 = math.ceil(v987)
		local v989 = math.max(0, v988)
		return tostring(v989)
	end)
	v979.limit = v_u_691.rsLimitLine(p955)
	v979.left = v_u_691.rsLeftLine(v958, p955, v966)
	local v990 = p955.dr
	if type(v990) == "table" then
		local v991 = p955.dr.i
		local v992
		if type(v991) == "number" and (v991 == v991 and v991 > (-1 / 0)) then
			v992 = v991 < (1 / 0)
		else
			v992 = false
		end
		if v992 then
			local v993 = p955.dr.n
			local v994
			if type(v993) == "number" and (v993 == v993 and v993 > (-1 / 0)) then
				v994 = v993 < (1 / 0)
			else
				v994 = false
			end
			if v994 and p954.rv == 2 then
				local v995 = v_u_691.RS_EXTRA.DROP
				local v_u_996 = {
					["i"] = p955.dr.i,
					["n"] = p955.dr.n
				}
				v979.drop = string.gsub(v995, "{(%w+)}", function(p997)
					-- upvalues: (copy) v_u_996, (ref) v_u_694, (ref) v_u_691
					local v998 = v_u_996
					local v999
					if type(v998) == "table" then
						v999 = v_u_996[p997]
					else
						v999 = nil
					end
					if v999 == nil then
						return "{" .. p997 .. "}"
					end
					if type(v999) ~= "number" then
						return tostring(v999)
					end
					if v_u_694[p997] then
						return v_u_691.rsClock(v999)
					end
					if p997 ~= "retryIn" then
						return v_u_691.commas(v999)
					end
					local v1000 = math.ceil(v999)
					local v1001 = math.max(0, v1000)
					return tostring(v1001)
				end)
			end
		end
	end
	if v977 ~= "draw" then
		if v977 == "soon" then
			local v1002 = v_u_735(p954, p955, v957.openHint)
			local v1003 = v_u_691.rsText
			local v1004 = "NOT_YET"
			local v1005 = {}
			local v1006
			if v1002 == nil then
				v1006 = 0
			else
				local v1007 = v1002 - v961
				local v1008 = math.ceil(v1007)
				v1006 = math.max(0, v1008)
			end
			v1005.wait = v1006
			v979.opens = v1003(v958, v1004, v1005)
		end
		return v979
	end
	local v1009 = v_u_691.rsDrawLeft(p954, p955, v961, v957.openHint)
	v979.opening = v_u_691.rsText(v958, "OPENING", {
		["n"] = math.ceil(v1009 or 0)
	})
	return v979
end
function v_u_691.rsCards(p1010, p1011) -- name: rsCards
	-- upvalues: (copy) v_u_691
	local v1012 = {}
	if type(p1010) == "table" then
		local v1013 = p1010.items
		if type(v1013) == "table" then
			local v1014 = type(p1011) ~= "table" and {} or p1011
			for _, v1015 in p1010.items do
				local v1016 = v1014.per
				local v1017
				if type(v1016) == "function" then
					v1017 = v1014.per(v1015.i)
				else
					v1017 = nil
				end
				local v1018 = table.clone(v1014)
				v1018.per = nil
				if type(v1017) == "table" then
					for v1019, v1020 in v1017 do
						v1018[v1019] = v1020
					end
				end
				local v1021 = v_u_691.rsCard
				table.insert(v1012, v1021(p1010, v1015, v1018))
			end
			return v1012
		end
	end
	return v1012
end
function v_u_691.rsStrip(p1022, p1023, p1024) -- name: rsStrip
	-- upvalues: (copy) v_u_691, (copy) v_u_694
	local v1025 = type(p1024) ~= "table" and {} or p1024
	local v1026 = v_u_691.rsPhase(p1022, p1023)
	if v1026 == nil or v1026 == "over" then
		return nil
	end
	local v1027
	if v1026 == "paused" then
		v1027 = "paused"
	elseif v1026 == "resume" then
		v1027 = "resumes in " .. v_u_691.rsClock(p1022.ra - p1023)
	elseif v1026 == "live" then
		v1027 = "ends in " .. v_u_691.rsClock(p1022.t1 - p1023)
	else
		v1027 = "opens in " .. v_u_691.rsClock(p1022.t0 - p1023)
	end
	local v1028 = v_u_691.RS_NAME .. (v1026 == "live" and " LIVE  " or "  ") .. v1027
	local v1029 = {}
	local v1030 = {}
	local v1031 = {}
	local v1032 = 0
	local v1033 = v1025.items
	if type(v1033) == "table" then
		for _, v1034 in v1025.items do
			if type(v1034) ~= "table" then
				continue
			end
			local v1035 = v1034.id
			if type(v1035) ~= "string" or v1031[v1034.id] then
				continue
			end
			v1031[v1034.id] = true
			v1032 = v1032 + 1
			if #v1029 >= 4 then
				continue
			end
			local v1036 = v1034.id
			table.insert(v1029, v1036)
			local v1037 = {
				["id"] = v1034.id,
				["chip"] = v_u_691.rsChip(p1022, v1034, p1023, nil, nil)
			}
			table.insert(v1030, v1037)
		end
	end
	local v1038 = nil
	if v1026 == "live" then
		local v1039 = p1022.nx
		local v1040
		if type(v1039) == "number" and (v1039 == v1039 and v1039 > (-1 / 0)) then
			v1040 = v1039 < (1 / 0)
		else
			v1040 = false
		end
		if v1040 and p1023 < p1022.nx then
			local v1041 = v_u_691.RS_EXTRA.NEXT_DROP
			local v_u_1042 = {
				["t"] = v_u_691.rsClock(p1022.nx - p1023)
			}
			v1038 = string.gsub(v1041, "{(%w+)}", function(p1043)
				-- upvalues: (copy) v_u_1042, (ref) v_u_694, (ref) v_u_691
				local v1044 = v_u_1042
				local v1045
				if type(v1044) == "table" then
					v1045 = v_u_1042[p1043]
				else
					v1045 = nil
				end
				if v1045 == nil then
					return "{" .. p1043 .. "}"
				end
				if type(v1045) ~= "number" then
					return tostring(v1045)
				end
				if v_u_694[p1043] then
					return v_u_691.rsClock(v1045)
				end
				if p1043 ~= "retryIn" then
					return v_u_691.commas(v1045)
				end
				local v1046 = math.ceil(v1045)
				local v1047 = math.max(0, v1046)
				return tostring(v1047)
			end)
		end
	end
	local v1048 = {
		["show"] = true,
		["phase"] = nil,
		["kind"] = nil,
		["title"] = nil,
		["word"] = nil,
		["text"] = nil,
		["status"] = nil,
		["drop"] = nil,
		["short"] = nil,
		["icons"] = nil,
		["more"] = nil,
		["chips"] = nil,
		["button"] = "VIEW RESTOCK",
		["arrow"] = nil,
		["live"] = nil,
		["warn"] = nil,
		["pulse"] = nil,
		["phase"] = v1026,
		["kind"] = v1026,
		["title"] = v_u_691.RS_NAME,
		["word"] = v_u_691.RS_WORD,
		["text"] = v1028,
		["status"] = v1027,
		["drop"] = v1038,
		["short"] = v_u_691.RS_WORD .. " " .. v1027,
		["icons"] = v1029
	}
	local v1049 = v1032 - #v1029
	v1048.more = math.max(0, v1049)
	v1048.chips = v1026 ~= "live" and {} or v1030
	v1048.arrow = v1025.phone == true
	v1048.live = v1026 == "live"
	v1048.warn = v1025.warn
	local v1050 = v1026 == "live" and v1025.reduced ~= true
	if not v1050 then
		v1048.pulse = v1050
		return v1048
	end
	local v1051 = p1022.t0
	if type(v1051) == "number" and (v1051 == v1051 and v1051 > (-1 / 0)) then
		v1050 = v1051 < (1 / 0)
	else
		v1050 = false
	end
	if not v1050 then
		v1048.pulse = v1050
		return v1048
	end
	local v1052 = p1023 - p1022.t0
	local v1053 = v_u_691.RS
	local v1054
	if v1053 == nil then
		v1054 = v_u_691.RS_TIME.pulseLen
		v1050 = v1052 < v1054
	else
		local v1055 = v1053.RS
		if type(v1055) == "table" then
			local v1056 = v1053.RS.pulseLen
			if type(v1056) == "number" then
				v1054 = v1053.RS.pulseLen
				v1050 = v1052 < v1054
			else
				v1054 = v_u_691.RS_TIME.pulseLen
				v1050 = v1052 < v1054
			end
		else
			v1054 = v_u_691.RS_TIME.pulseLen
			v1050 = v1052 < v1054
		end
	end
	v1048.pulse = v1050
	return v1048
end
function v_u_691.rsStripOf(p1057, p1058, p1059) -- name: rsStripOf
	-- upvalues: (copy) v_u_691
	if type(p1057) == "table" then
		local v1060 = p1057.rk
		if type(v1060) == "table" then
			local v1061 = v_u_691.serverNow(p1057, p1058)
			if v1061 == nil then
				return nil
			end
			local v1062 = type(p1059) ~= "table" and {} or table.clone(p1059)
			if v1062.items == nil then
				local v1063 = p1057.rk.items
				if type(v1063) == "table" then
					v1062.items = p1057.rk.items
				end
			end
			if v1062.warn == nil then
				v1062.warn = v_u_691.rsMailWarn(p1057.rk, v1061)
			end
			return v_u_691.rsStrip(p1057.rk, v1061, v1062)
		end
	end
	return nil
end
function v_u_691.rsLiveDot(p1064, p1065) -- name: rsLiveDot
	-- upvalues: (copy) v_u_691
	return v_u_691.rsPhase(p1064, p1065) == "live"
end
function v_u_691.rsDot(p1066, p1067) -- name: rsDot
	-- upvalues: (copy) v_u_691
	if type(p1066) == "table" then
		local v1068 = p1066.t0
		local v1069
		if type(v1068) == "number" and (v1068 == v1068 and v1068 > (-1 / 0)) then
			v1069 = v1068 < (1 / 0)
		else
			v1069 = false
		end
		if v1069 or (p1066.ph == "soon" or p1066.ph == "live") then
			local v1070 = v_u_691.rsPhase(p1066, p1067)
			local v1071
			if v1070 == nil then
				v1071 = false
			else
				v1071 = v1070 ~= "over"
			end
			return v1071
		end
	end
	return false
end
function v_u_691.rsMailWarn(p1072, p1073) -- name: rsMailWarn
	-- upvalues: (copy) v_u_691
	if type(p1072) == "table" then
		local v1074 = p1072.gate
		if type(v1074) == "table" and v_u_691.rsPhase(p1072, p1073) == "soon" then
			local v1075 = p1072.gate.code
			return v1075 == "MAIL_FULL" and {
				["code"] = nil,
				["text"] = nil,
				["button"] = "OPEN MAIL",
				["code"] = v1075,
				["text"] = v_u_691.rsText(nil, "MAIL_WARN")
			} or (v1075 == "STASH_FULL" and {
				["code"] = v1075,
				["text"] = v_u_691.rsText(nil, "STASH_FULL")
			} or nil)
		end
	end
	return nil
end
function v_u_691.rsPollEvery(p1076) -- name: rsPollEvery
	-- upvalues: (copy) v_u_691
	if p1076 then
		local v1077 = v_u_691.RS
		if v1077 ~= nil then
			local v1078 = v1077.RS
			if type(v1078) == "table" then
				local v1079 = v1077.RS.pollOpen
				if type(v1079) == "number" then
					return v1077.RS.pollOpen
				end
			end
		end
		return v_u_691.RS_TIME.pollOpen
	else
		local v1080 = v_u_691.RS
		if v1080 ~= nil then
			local v1081 = v1080.RS
			if type(v1081) == "table" then
				local v1082 = v1080.RS.pollIdle
				if type(v1082) == "number" then
					return v1080.RS.pollIdle
				end
			end
		end
		return v_u_691.RS_TIME.pollIdle
	end
end
function v_u_691.rsBoundaries(p1083, p1084, p1085) -- name: rsBoundaries
	local v1086 = {}
	if type(p1083) ~= "table" then
		return v1086
	end
	local v1087 = p1083.t0
	local v1088
	if type(v1087) == "number" and (v1087 == v1087 and v1087 > (-1 / 0)) then
		v1088 = v1087 < (1 / 0)
	else
		v1088 = false
	end
	if v1088 and p1085 < v1087 then
		table.insert(v1086, v1087)
	end
	local v1089 = p1083.ra
	local v1090
	if type(v1089) == "number" and (v1089 == v1089 and v1089 > (-1 / 0)) then
		v1090 = v1089 < (1 / 0)
	else
		v1090 = false
	end
	if v1090 and p1085 < v1089 then
		table.insert(v1086, v1089)
	end
	local v1091 = p1083.nx
	local v1092
	if type(v1091) == "number" and (v1091 == v1091 and v1091 > (-1 / 0)) then
		v1092 = v1091 < (1 / 0)
	else
		v1092 = false
	end
	if v1092 and p1085 < v1091 then
		table.insert(v1086, v1091)
	end
	local v1093 = p1083.t1
	local v1094
	if type(v1093) == "number" and (v1093 == v1093 and v1093 > (-1 / 0)) then
		v1094 = v1093 < (1 / 0)
	else
		v1094 = false
	end
	if v1094 and p1085 < v1093 then
		table.insert(v1086, v1093)
	end
	if type(p1084) == "table" then
		for _, v1095 in p1084 do
			if type(v1095) ~= "table" then
				continue
			end
			local v1096 = v1095.open
			local v1097
			if type(v1096) == "number" and (v1096 == v1096 and v1096 > (-1 / 0)) then
				v1097 = v1096 < (1 / 0)
			else
				v1097 = false
			end
			if not v1097 or p1085 >= v1096 then
				continue
			end
			table.insert(v1086, v1096)
		end
	end
	table.sort(v1086)
	local v1098 = {}
	for _, v1099 in v1086 do
		if v1098[#v1098] == v1099 then
			continue
		end
		table.insert(v1098, v1099)
	end
	return v1098
end
v_u_691.RS_TOAST = {
	["rsSoon"] = "MARKET RESTOCK starts in 1 minute.",
	["rsLive"] = "MARKET RESTOCK is live in the MARKET."
}
v_u_691.RS_TOAST_LEAD = 60
v_u_691.RS_TOAST_LATE = 20
function v_u_691.rsToastDue(p1100, p1101, p1102) -- name: rsToastDue
	-- upvalues: (copy) v_u_691
	if type(p1100) == "table" then
		local v1103 = p1100.t0
		local v1104
		if type(v1103) == "number" and (v1103 == v1103 and v1103 > (-1 / 0)) then
			v1104 = v1103 < (1 / 0)
		else
			v1104 = false
		end
		if v1104 then
			local v1105
			if type(p1101) == "number" and (p1101 == p1101 and p1101 > (-1 / 0)) then
				v1105 = p1101 < (1 / 0)
			else
				v1105 = false
			end
			if v1105 then
				local v1106 = v_u_691.rsPhase(p1100, p1101)
				local v1107 = v1106 == "soon" and p1100.t0 - p1101 <= v_u_691.RS_TOAST_LEAD and "rsSoon" or (v1106 == "live" and p1101 - p1100.t0 < v_u_691.RS_TOAST_LATE and "rsLive" or nil)
				if v1107 == nil then
					return nil, nil
				else
					local v1108 = p1100.r
					local v1109 = tostring(v1108) .. "|" .. v1107
					if type(p1102) == "table" and p1102[v1109] == true then
						return nil, nil
					else
						return v1107, v1109
					end
				end
			end
		end
	end
	return nil, nil
end
function v_u_691.rsFetchDelay(p1110, p1111, p1112, p1113, p1114, p1115, p1116) -- name: rsFetchDelay
	-- upvalues: (copy) v_u_691
	local v1117
	if type(p1110) == "table" then
		local v1118 = p1110.t0
		local v1119
		if type(v1118) == "number" and (v1118 == v1118 and v1118 > (-1 / 0)) then
			v1119 = v1118 < (1 / 0)
		else
			v1119 = false
		end
		if v1119 then
			if p1112 < v1118 then
				v1119 = v1118 <= p1113
			else
				v1119 = false
			end
		end
		if not v1119 then
			local v1120 = p1110.ra
			if type(v1120) == "number" and (v1120 == v1120 and v1120 > (-1 / 0)) then
				v1119 = v1120 < (1 / 0)
			else
				v1119 = false
			end
			if v1119 then
				if p1112 < v1120 then
					v1119 = v1120 <= p1113
				else
					v1119 = false
				end
			end
			if not v1119 then
				local v1121 = p1110.nx
				if type(v1121) == "number" and (v1121 == v1121 and v1121 > (-1 / 0)) then
					v1119 = v1121 < (1 / 0)
				else
					v1119 = false
				end
				if v1119 then
					if p1112 < v1121 then
						v1119 = v1121 <= p1113
					else
						v1119 = false
					end
				end
				if not v1119 then
					local v1122 = p1110.t1
					if type(v1122) == "number" and (v1122 == v1122 and v1122 > (-1 / 0)) then
						v1119 = v1122 < (1 / 0)
					else
						v1119 = false
					end
					if v1119 then
						if p1112 < v1122 then
							v1119 = v1122 <= p1113
						else
							v1119 = false
						end
					end
				end
			end
		end
		if not v1119 and type(p1111) == "table" then
			for _, v1123 in p1111 do
				if type(v1123) ~= "table" then
					continue
				end
				local v1124 = v1123.open
				local v1125
				if type(v1124) == "number" and (v1124 == v1124 and v1124 > (-1 / 0)) then
					v1125 = v1124 < (1 / 0)
				else
					v1125 = false
				end
				if v1125 then
					if p1112 < v1124 then
						v1125 = v1124 <= p1113
					else
						v1125 = false
					end
				end
				if not v1125 then
					continue
				end
				v1119 = true
			end
		end
		if v1119 then
			local v1126 = math.min(1, p1116 or 0)
			local v1127 = math.max(0, v1126)
			local v1128 = v_u_691.RS
			local v1129
			if v1128 == nil then
				v1129 = v_u_691.RS_TIME.jitter
				return v1127 * v1129, "start"
			else
				local v1130 = v1128.RS
				if type(v1130) == "table" then
					local v1131 = v1128.RS.jitter
					if type(v1131) == "number" then
						v1129 = v1128.RS.jitter
						return v1127 * v1129, "start"
					else
						v1129 = v_u_691.RS_TIME.jitter
						return v1127 * v1129, "start"
					end
				else
					v1129 = v_u_691.RS_TIME.jitter
					return v1127 * v1129, "start"
				end
			end
		else
			v1117 = v_u_691.rsPollEvery(p1115) - p1114
			return math.max(0, v1117), "poll"
		end
	else
		v1117 = v_u_691.rsPollEvery(p1115) - p1114
		return math.max(0, v1117), "poll"
	end
end
function v_u_691.rsResultLine(p1132) -- name: rsResultLine
	-- upvalues: (copy) v_u_691
	if type(p1132) ~= "table" then
		return {
			["kind"] = "error",
			["text"] = nil,
			["code"] = "STORE",
			["text"] = v_u_691.CODES.STORE
		}
	end
	local v1133 = p1132.data
	local v1134 = type(v1133) ~= "table" and {} or p1132.data
	local v1135 = p1132.code or v1134.code
	if p1132.ok == true then
		return {
			["kind"] = "success",
			["text"] = nil,
			["code"] = "OK",
			["saving"] = nil,
			["n"] = nil,
			["p"] = nil,
			["text"] = p1132.text or "",
			["saving"] = v1134.saving == true,
			["n"] = v1134.n,
			["p"] = v1134.p
		}
	end
	local v1136 = {
		["kind"] = type(v1135) == "string" and ({
			["CAP"] = true,
			["CAP_ALL"] = true,
			["CAP_LESS"] = true,
			["HELD"] = true,
			["LESS_LEFT"] = true,
			["STOCK_BUSY"] = true,
			["SOLD_OUT"] = true,
			["PRICE"] = true,
			["CASH"] = true,
			["NOT_YET"] = true,
			["QTY_MIN"] = true,
			["QTY_MAX"] = true,
			["BUSY"] = true,
			["RATE"] = true
		})[v1135] and "warn" or "error",
		["text"] = p1132.text or "",
		["code"] = v1135 or "STORE"
	}
	local v1137 = v1134.retryIn
	local v1138
	if type(v1137) == "number" and (v1137 == v1137 and v1137 > (-1 / 0)) then
		v1138 = v1137 < (1 / 0)
	else
		v1138 = false
	end
	local v1139
	if v1138 then
		v1139 = v1134.retryIn
	else
		v1139 = nil
	end
	v1136.retryIn = v1139
	local v1140 = v1134.avail
	local v1141
	if type(v1140) == "number" and (v1140 == v1140 and v1140 > (-1 / 0)) then
		v1141 = v1140 < (1 / 0)
	else
		v1141 = false
	end
	local v1142
	if v1141 then
		v1142 = v1134.avail
	else
		v1142 = nil
	end
	v1136.avail = v1142
	return v1136
end
function v_u_691.rsTile(p1143, p1144, p1145, p1146) -- name: rsTile
	-- upvalues: (copy) v_u_691
	if type(p1143) == "table" then
		local v1147 = p1143.items
		if type(v1147) == "table" then
			local v1148 = v_u_691.rsPhase(p1143, p1145)
			if v1148 == nil or v1148 == "over" then
				return nil
			end
			local v1149 = nil
			local v1150 = false
			local v1151 = false
			local v1152 = false
			for _, v1153 in p1143.items do
				if type(v1153) ~= "table" or v1153.id ~= p1144 then
					continue
				end
				v1150 = true
				local v1154 = v_u_691.rsStage(p1143, v1153, p1145, nil)
				local v1155
				if type(p1146) == "table" then
					v1155 = p1146[v1153.i]
				else
					v1155 = nil
				end
				local v1156
				if v1153.st == "out" then
					v1156 = true
				elseif type(v1155) == "table" then
					v1156 = v1155.st == "out"
				else
					v1156 = false
				end
				v1152 = v1154 == "soon" and true or v1152
				if v1148 ~= "live" or (v1154 == "soon" or v1156) then
					continue
				end
				v1151 = true
				if v1149 ~= nil and v1153.u >= v1149 then
					continue
				end
				v1149 = v1153.u
			end
			if not v1150 then
				return nil
			end
			local v1157 = v1151 and "LIVE" or ((v1148 == "paused" or v1148 == "resume") and "PAUSED" or ((v1152 or v1148 == "soon") and "OPENS SOON" or "SOLD OUT"))
			return {
				["band"] = v_u_691.RS_WORD,
				["from"] = v1149,
				["live"] = v1151,
				["word"] = v1157
			}
		end
	end
	return nil
end
function v_u_691.rsTiles(p1158, p1159, p1160) -- name: rsTiles
	-- upvalues: (copy) v_u_691
	local v1161 = {}
	if type(p1158) == "table" then
		local v1162 = p1158.items
		if type(v1162) == "table" then
			for _, v1163 in p1158.items do
				if type(v1163) ~= "table" then
					continue
				end
				local v1164 = v1163.id
				if type(v1164) ~= "string" or v1161[v1163.id] ~= nil then
					continue
				end
				v1161[v1163.id] = v_u_691.rsTile(p1158, v1163.id, p1159, p1160)
			end
		end
	end
	return v1161
end
function v_u_691.rsFilterIds(p1165, p1166) -- name: rsFilterIds
	-- upvalues: (copy) v_u_691
	local v1167 = {}
	for v1168, v1169 in v_u_691.rsTiles(p1165, p1166) do
		if v1169 == nil then
			continue
		end
		table.insert(v1167, v1168)
	end
	table.sort(v1167)
	return v1167
end
function v_u_691.rsForItem(p1170, p1171) -- name: rsForItem
	local v1172 = {}
	if type(p1170) == "table" then
		local v1173 = p1170.items
		if type(v1173) == "table" then
			for _, v1174 in p1170.items do
				if type(v1174) ~= "table" or v1174.id ~= p1171 then
					continue
				end
				table.insert(v1172, v1174)
			end
		end
	end
	return v1172
end
function v_u_691.rsBookLine(p1175) -- name: rsBookLine
	-- upvalues: (copy) v_u_691, (copy) v_u_694
	if type(p1175) == "table" and p1175.ph == "live" then
		local v1176 = p1175.u
		local v1177
		if type(v1176) == "number" and (v1176 == v1176 and v1176 > (-1 / 0)) then
			v1177 = v1176 < (1 / 0)
		else
			v1177 = false
		end
		if v1177 then
			local v1178 = v_u_691.RS_EXTRA.LIVE_AT
			local v_u_1179 = {
				["u"] = v_u_691.money(p1175.u)
			}
			return string.gsub(v1178, "{(%w+)}", function(p1180)
				-- upvalues: (copy) v_u_1179, (ref) v_u_694, (ref) v_u_691
				local v1181 = v_u_1179
				local v1182
				if type(v1181) == "table" then
					v1182 = v_u_1179[p1180]
				else
					v1182 = nil
				end
				if v1182 == nil then
					return "{" .. p1180 .. "}"
				end
				if type(v1182) ~= "number" then
					return tostring(v1182)
				end
				if v_u_694[p1180] then
					return v_u_691.rsClock(v1182)
				end
				if p1180 ~= "retryIn" then
					return v_u_691.commas(v1182)
				end
				local v1183 = math.ceil(v1182)
				local v1184 = math.max(0, v1183)
				return tostring(v1184)
			end)
		end
	end
	return nil
end
function v_u_691.rsOrderCheaper(p1185, p1186) -- name: rsOrderCheaper
	-- upvalues: (copy) v_u_691, (copy) v_u_694
	if type(p1186) == "table" and p1186.ph == "live" then
		local v1187 = p1186.u
		local v1188
		if type(v1187) == "number" and (v1187 == v1187 and v1187 > (-1 / 0)) then
			v1188 = v1187 < (1 / 0)
		else
			v1188 = false
		end
		if v1188 then
			local v1189
			if type(p1185) == "number" and (p1185 == p1185 and p1185 > (-1 / 0)) then
				v1189 = p1185 < (1 / 0)
			else
				v1189 = false
			end
			if v1189 and p1185 > p1186.u then
				local v1190 = v_u_691.RS_EXTRA.CHEAPER
				local v_u_1191 = {
					["u"] = v_u_691.money(p1186.u)
				}
				return string.gsub(v1190, "{(%w+)}", function(p1192)
					-- upvalues: (copy) v_u_1191, (ref) v_u_694, (ref) v_u_691
					local v1193 = v_u_1191
					local v1194
					if type(v1193) == "table" then
						v1194 = v_u_1191[p1192]
					else
						v1194 = nil
					end
					if v1194 == nil then
						return "{" .. p1192 .. "}"
					end
					if type(v1194) ~= "number" then
						return tostring(v1194)
					end
					if v_u_694[p1192] then
						return v_u_691.rsClock(v1194)
					end
					if p1192 ~= "retryIn" then
						return v_u_691.commas(v1194)
					end
					local v1195 = math.ceil(v1194)
					local v1196 = math.max(0, v1195)
					return tostring(v1196)
				end)
			end
		end
	end
	return nil
end
function v_u_691.traderPay(p_u_1197, p_u_1198, p1199, p_u_1200) -- name: traderPay
	local v_u_1201 = math.max(1, p1199 or 1)
	local v1208, v1209 = pcall(function()
		-- upvalues: (copy) p_u_1197, (copy) p_u_1198, (copy) v_u_1201, (copy) p_u_1200
		local v1202 = p_u_1197.cctx.lib.InvUITile
		local v1203 = {
			["uid"] = "",
			["id"] = nil,
			["n"] = nil,
			["id"] = p_u_1198,
			["n"] = v_u_1201
		}
		local v1204 = p_u_1200
		if type(v1204) == "table" then
			local v1205 = p_u_1200.dur
			if type(v1205) == "number" then
				v1203.dur = p_u_1200.dur
			end
		end
		local v1206 = v1202.sellQuote(v1203, nil)
		if type(v1206) == "table" then
			local v1207 = v1206.price
			if type(v1207) == "number" and v1206.price > 0 then
				return v1206.price / v_u_1201
			end
		end
		return nil
	end)
	if v1208 then
		return v1209
	else
		return nil
	end
end
function v_u_691.traderSells(p_u_1210, p_u_1211) -- name: traderSells
	local v1227, v1228 = pcall(function()
		-- upvalues: (copy) p_u_1210, (copy) p_u_1211
		local v1212 = p_u_1210.cctx.shared.Traders
		local v_u_1213 = p_u_1210.cctx.shared.Items
		local function v1217(p1214) -- name: valueOf
			-- upvalues: (copy) v_u_1213
			local v1215 = v_u_1213.get(p1214)
			if v1215 then
				local v1216 = v1215.value
				if type(v1216) == "number" then
					return v1215.value
				end
			end
			return 0
		end
		local v1218 = nil
		for _, v1219 in v1212.ORDER do
			local v1220 = v1212.allOffers
			local v1221, v1222 = pcall(v1220, v1219)
			if not v1221 or type(v1222) ~= "table" then
				continue
			end
			for _, v1223 in v1222 do
				if v1223.id ~= p_u_1211 or (v1223.items ~= nil or v1223.price ~= nil) then
					continue
				end
				local v1224 = v1212.buyPrice(v1223, v1217)
				local v1225 = v1223.n or 1
				local v1226 = v1224 / math.max(1, v1225)
				if v1218 ~= nil and v1226 >= v1218 then
					continue
				end
				v1218 = v1226
			end
		end
		return v1218
	end)
	if v1227 then
		return v1228
	else
		return nil
	end
end
function v_u_691.new(p_u_1229, p1230) -- name: new
	-- upvalues: (copy) v_u_691
	local v_u_1231 = p1230 or {}
	local v_u_1232 = {
		["mc"] = p_u_1229,
		["fake"] = v_u_1231.fake == true
	}
	local v_u_1233 = v_u_691.rulesOf(p_u_1229)
	v_u_1232.rules = v_u_1233
	if v_u_691.buy == nil then
		local function v1234()
			-- upvalues: (ref) v_u_691, (copy) p_u_1229
			v_u_691.buy = p_u_1229.cctx.shared.BmBuy
		end
		pcall(v1234)
	end
	if v_u_691.comfort == nil then
		local function v1235()
			-- upvalues: (ref) v_u_691, (copy) p_u_1229
			v_u_691.comfort = p_u_1229.cctx.shared.BmRules.COMFORT
		end
		pcall(v1235)
	end
	if v_u_691.bk == nil then
		local function v1236()
			-- upvalues: (ref) v_u_691, (copy) p_u_1229
			v_u_691.bk = p_u_1229.cctx.shared.BmBook
		end
		pcall(v1236)
	end
	if v_u_691.cm == nil then
		local function v1237()
			-- upvalues: (ref) v_u_691, (copy) p_u_1229
			v_u_691.cm = p_u_1229.cctx.shared.CrateMarket
		end
		pcall(v1237)
	end
	if v_u_691.RS == nil then
		local function v1238()
			-- upvalues: (ref) v_u_691, (copy) p_u_1229
			v_u_691.RS = p_u_1229.cctx.shared.BmRs
		end
		pcall(v1238)
	end
	local function v1241()
		-- upvalues: (copy) v_u_1233, (ref) v_u_691
		local v1239 = v_u_1233.TUNE.goodCondition
		local v1240
		if type(v1239) == "number" and (v1239 == v1239 and v1239 ~= (1 / 0)) then
			v1240 = v1239 ~= (-1 / 0)
		else
			v1240 = false
		end
		if v1240 then
			v_u_691.goodCondition = v1239
		end
	end
	pcall(v1241)
	local v_u_1242 = nil
	if v_u_1232.fake then
		local v1243, v1244 = pcall(function()
			-- upvalues: (copy) v_u_1231, (copy) p_u_1229
			return v_u_1231.fakeModule or p_u_1229.cctx.lib.MenuMarketFake
		end)
		if v1243 and type(v1244) == "table" then
			local v1245 = v1244.new
			if type(v1245) == "function" then
				v_u_1242 = v1244.new({
					["mc"] = p_u_1229,
					["rules"] = v_u_1233,
					["data"] = v_u_1232,
					["statics"] = v_u_691,
					["seed"] = v_u_1231.seed,
					["getCash"] = function() -- name: getCash
						-- upvalues: (copy) p_u_1229
						local v1246 = p_u_1229.profile
						if type(v1246) == "table" then
							local v1247 = v1246.cash
							if type(v1247) == "number" then
								return v1246.cash
							end
						end
						return 0
					end
				})
			else
				v_u_1232.fake = false
			end
		else
			v_u_1232.fake = false
		end
	end
	v_u_1232.fakeSrv = v_u_1242
	v_u_1232.cache = {}
	v_u_1232.flight = {}
	v_u_1232.busy = {}
	v_u_1232.waits = {}
	v_u_1232.noteSubs = {}
	v_u_1232.changeSubs = {}
	v_u_1232.subId = 0
	v_u_1232.st = nil
	v_u_1232.mineAt = (-1 / 0)
	v_u_1232.refreshAt = (-1 / 0)
	v_u_1232.alive = true
	function v_u_1232.clock(_) -- name: clock
		-- upvalues: (ref) v_u_1242
		if v_u_1242 then
			return v_u_1242.clock()
		else
			return os.clock()
		end
	end
	local function v_u_1259(p_u_1248) -- name: rawGet
		-- upvalues: (ref) v_u_1242, (copy) v_u_1233, (ref) v_u_691, (copy) v_u_1232
		local v1249 = nil
		local v1250
		if v_u_1242 then
			v1250 = v_u_1242:get(p_u_1248)
		else
			local v_u_1251 = nil
			local function v1254()
				-- upvalues: (ref) v_u_1251
				local v1252 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
				local v1253
				if v1252 then
					v1253 = v1252:FindFirstChild("menu.get")
				else
					v1253 = v1252
				end
				v_u_1251 = v1253
				if not v_u_1251 and v1252 then
					v_u_1251 = v1252:WaitForChild("menu.get", 5)
				end
			end
			pcall(v1254)
			if v_u_1251 and v_u_1251:IsA("RemoteFunction") then
				local function v1255()
					-- upvalues: (ref) v_u_1251, (copy) p_u_1248
					return v_u_1251:InvokeServer(p_u_1248)
				end
				local v1256
				v1256, v1250 = pcall(v1255)
				if v1256 then
					if type(v1250) ~= "table" then
						v1250 = v1249
					end
				else
					v1250 = v1249
				end
			else
				v1250 = v1249
			end
		end
		if type(v1250) == "table" then
			if v1250.ok == nil and v1250.error ~= nil then
				local v1257 = v_u_1233
				v1250 = {
					["ok"] = false,
					["code"] = "STORE",
					["text"] = nil,
					["offline"] = true,
					["text"] = v_u_691.text(v1257, "STORE", nil)
				}
			end
		else
			local v1258 = v_u_1233
			v1250 = {
				["ok"] = false,
				["code"] = "STORE",
				["text"] = nil,
				["offline"] = true,
				["text"] = v_u_691.text(v1258, "STORE", nil)
			}
		end
		v1250._at = v_u_1232:clock()
		return v1250
	end
	v_u_1232._rawGet = v_u_1259
	local function v_u_1270(p1260, p1261, p1262, p1263) -- name: cached
		-- upvalues: (copy) v_u_1232, (copy) v_u_1259
		local v1264 = v_u_1232.cache[p1260]
		if v1264 and (p1261 > 0 and v_u_1232:clock() - v1264.at < p1261) then
			return v1264.body, false
		end
		local v1265 = v_u_1232.flight[p1260]
		if v1265 then
			local v1266 = coroutine.running
			table.insert(v1265, v1266())
			return coroutine.yield(), false
		end
		v_u_1232.flight[p1260] = {}
		local v1267 = v_u_1259(p1262)
		local v1268 = v_u_1232.flight[p1260]
		v_u_1232.flight[p1260] = nil
		if v1267.ok ~= false or p1263 == true then
			v_u_1232.cache[p1260] = {
				["body"] = v1267,
				["at"] = v_u_1232:clock()
			}
		end
		for _, v1269 in v1268 do
			task.spawn(v1269, v1267)
		end
		return v1267, true
	end
	function v_u_1232.state(_, p1271) -- name: state
		-- upvalues: (copy) v_u_1270, (copy) v_u_1232
		local v1272, v1273 = v_u_1270("state", p1271 or 2, {
			["what"] = "bmState"
		}, true)
		v_u_1232.st = v1272
		if v1273 then
			for _, v1274 in v_u_1232.changeSubs do
				pcall(v1274, "state", v1272)
			end
		end
		return v1272
	end
	function v_u_1232.lastState(_) -- name: lastState
		-- upvalues: (copy) v_u_1232
		return v_u_1232.st
	end
	function v_u_1232.invalidate(_, p1275) -- name: invalidate
		-- upvalues: (copy) v_u_1232
		if p1275 then
			for v1276 in v_u_1232.cache do
				if v1276 ~= p1275 then
					local v1277 = #p1275 + 1
					if string.sub(v1276, 1, v1277) ~= p1275 .. "/" then
						continue
					end
				end
				v_u_1232.cache[v1276] = nil
			end
		else
			table.clear(v_u_1232.cache)
		end
	end
	function v_u_1232.prices(_, p1278) -- name: prices
		-- upvalues: (copy) v_u_1259
		local v1279 = {}
		for v1280, v1281 in p1278 do
			if v1280 > 40 then
				break
			end
			table.insert(v1279, v1281)
		end
		return v_u_1259({
			["what"] = "bmPrices",
			["ids"] = nil,
			["ids"] = v1279
		})
	end
	function v_u_1232.listed(_, p1282) -- name: listed
		-- upvalues: (copy) v_u_1270
		return v_u_1270("listed", p1282 or 10, {
			["what"] = "bmPrices",
			["listed"] = true
		})
	end
	function v_u_1232.item(_, p1283, p1284, p1285) -- name: item
		-- upvalues: (copy) v_u_1270
		local v1286 = math.floor(p1284 or 0)
		local v1287 = math.max(0, v1286)
		return v_u_1270(("item/%s/%d/%s"):format(p1283, v1287, p1285 and "g" or "a"), 4, {
			["what"] = "bmItem",
			["id"] = nil,
			["offset"] = nil,
			["good"] = nil,
			["id"] = p1283,
			["offset"] = v1287,
			["good"] = p1285 and true or nil
		}, true)
	end
	function v_u_1232.quote(_, p1288) -- name: quote
		-- upvalues: (copy) v_u_1270
		return v_u_1270("quote/" .. p1288, 10, {
			["what"] = "bmQuote",
			["id"] = nil,
			["id"] = p1288
		})
	end
	function v_u_1232.book(_, p1289, p1290) -- name: book
		-- upvalues: (copy) v_u_1270
		local v1291 = "book/%s/%s"
		local v1292
		if p1290 then
			local v1293 = math.floor(p1290)
			v1292 = tostring(v1293)
		else
			v1292 = "0"
		end
		local v1294 = v1291:format(p1289, v1292)
		local v1295 = {
			["what"] = "bmBook",
			["id"] = nil,
			["id"] = p1289
		}
		if p1290 ~= nil then
			v1295.below = math.floor(p1290)
		end
		return v_u_1270(v1294, 20, v1295)
	end
	v_u_1232.rk = nil
	v_u_1232.rsLast = {}
	v_u_1232.rsMarks = {}
	v_u_1232.rsOpens = {}
	v_u_1232.rsSentAt = nil
	function v_u_1232.restock(_, p1296) -- name: restock
		-- upvalues: (copy) v_u_1270, (ref) v_u_691, (copy) v_u_1232
		local v1297, v1298 = v_u_1270("restock", p1296 or v_u_691.rsPollEvery(true), {
			["what"] = "bmRestock"
		})
		v_u_1232.rk = v1297
		if v1298 and type(v1297) == "table" then
			local v1299 = v1297.rk
			if type(v1299) == "table" then
				local v1300 = v1299.items
				if type(v1300) == "table" then
					for _, v1301 in v1299.items do
						if type(v1301) ~= "table" then
							continue
						end
						local v1302 = v1301.i
						if type(v1302) ~= "number" then
							continue
						end
						local v1303 = v1301.open
						if type(v1303) ~= "number" then
							continue
						end
						v_u_1232.rsOpens[v1301.i] = v1301.open
					end
				end
			end
			local v1304 = v1297._at
			for v1305, v1306 in v_u_1232.rsMarks do
				if type(v1304) ~= "number" then
					continue
				end
				local v1307 = v1306.at
				if type(v1307) ~= "number" or v1306.at > v1304 then
					continue
				end
				v_u_1232.rsMarks[v1305] = nil
			end
			for _, v1308 in v_u_1232.changeSubs do
				pcall(v1308, "restock", v1297)
			end
		end
		return v1297
	end
	function v_u_1232.lastRestock(_) -- name: lastRestock
		-- upvalues: (copy) v_u_1232
		return v_u_1232.rk
	end
	function v_u_1232.rsCtx(_, p1309) -- name: rsCtx
		-- upvalues: (copy) v_u_1232, (copy) p_u_1229, (ref) v_u_691, (copy) v_u_1233
		local v_u_1310 = type(p1309) ~= "table" and {} or p1309
		local v1311 = v_u_1232.rk
		local v_u_1312 = v_u_1232:clock()
		local v1313
		if type(v1311) == "table" then
			v1313 = v1311._at
		else
			v1313 = nil
		end
		local v_u_1314 = nil
		local function v1315()
			-- upvalues: (ref) v_u_1314, (ref) p_u_1229
			v_u_1314 = p_u_1229.cctx.shared.Items
		end
		pcall(v1315)
		local v1316 = {}
		local v1317
		if type(v1311) == "table" then
			v1317 = v_u_691.serverNow(v1311, v_u_1312)
		else
			v1317 = nil
		end
		v1316.now = v1317
		local v1318
		if type(v1313) == "number" then
			local v1319 = v_u_1312 - v1313
			v1318 = math.max(0, v1319)
		else
			v1318 = 0
		end
		v1316.age = v1318
		v1316.cash = v_u_1232:cash()
		v1316.rules = v_u_1233
		v1316.st = v_u_1232.st
		v1316.clock = v_u_1312
		v1316.bodyAt = v1313
		function v1316.nameOf(p_u_1320) -- name: nameOf
			-- upvalues: (ref) v_u_1314
			local function v1321()
				-- upvalues: (ref) v_u_1314, (copy) p_u_1320
				return v_u_1314.get(p_u_1320)
			end
			local v1322, v1323 = pcall(v1321)
			if v1322 and type(v1323) == "table" then
				local v1324 = v1323.name
				if type(v1324) == "string" then
					return v1323.name
				end
			end
			return p_u_1320
		end
		function v1316.per(p1325) -- name: per
			-- upvalues: (copy) v_u_1310, (ref) v_u_1232, (copy) v_u_1312
			local v1326 = {}
			local v1327 = v_u_1310.qty
			local v1328
			if type(v1327) == "table" then
				v1328 = v_u_1310.qty[p1325]
			else
				v1328 = nil
			end
			v1326.qty = v1328
			v1326.last = v_u_1232.rsLast[p1325]
			v1326.mark = v_u_1232.rsMarks[p1325]
			v1326.openHint = v_u_1232.rsOpens[p1325]
			local v1329
			if v_u_1232.rsSentAt == nil then
				v1329 = nil
			else
				v1329 = v_u_1312 - v_u_1232.rsSentAt
			end
			v1326.sinceSend = v1329
			return v1326
		end
		return v1316
	end
	function v_u_1232.rsClearLast(_, p1330) -- name: rsClearLast
		-- upvalues: (copy) v_u_1232
		v_u_1232.rsLast[p1330] = nil
	end
	function v_u_1232.mine(_, p1331) -- name: mine
		-- upvalues: (copy) v_u_1232, (copy) v_u_1270
		local v1332
		if p1331 == true then
			v1332 = v_u_1232:clock() - v_u_1232.refreshAt >= 20
		else
			v1332 = false
		end
		if v1332 then
			v_u_1232.refreshAt = v_u_1232:clock()
			v_u_1232.cache.mine = nil
		end
		local v1333, v1334 = v_u_1270("mine", 3, {
			["what"] = "bmMine",
			["refresh"] = nil,
			["refresh"] = v1332 and true or nil
		})
		if v1334 then
			for _, v1335 in v_u_1232.changeSubs do
				pcall(v1335, "mine", v1333)
			end
		end
		return v1333
	end
	function v_u_1232.remaining(_, p1336, p1337) -- name: remaining
		-- upvalues: (ref) v_u_691, (copy) v_u_1232
		return v_u_691.left(p1336, p1337, v_u_1232:clock())
	end
	local function v_u_1346(p1338) -- name: normalize
		-- upvalues: (ref) v_u_691, (copy) v_u_1233
		if type(p1338) ~= "table" or p1338.timeout == true then
			return {
				["ok"] = true,
				["state"] = "processing",
				["timeout"] = true,
				["data"] = nil,
				["text"] = nil,
				["data"] = {},
				["text"] = v_u_691.TEXT.working
			}
		end
		local v1339 = p1338.data
		local v1340 = type(v1339) ~= "table" and {} or p1338.data
		local v1341 = v1340.code
		local v1342 = p1338.ok == true
		local v1343 = p1338.msg
		local v1344
		if type(v1343) == "string" and p1338.msg ~= "" then
			v1344 = p1338.msg
		elseif v1341 then
			v1344 = v_u_691.text(v_u_1233, v1341, v1340)
		else
			v1344 = v1342 and "" or v_u_691.text(v_u_1233, "STORE")
		end
		local v1345 = {
			["ok"] = v1342,
			["code"] = not v1342 and v1341 == nil and "STORE" or v1341,
			["text"] = v1344,
			["data"] = v1340,
			["state"] = v1340.state
		}
		if v1342 then
			v1342 = v1340.toMail == true and true or p1338.toMail == true
		end
		v1345.toMail = v1342
		return v1345
	end
	local function v_u_1358(p1347, p1348) -- name: run
		-- upvalues: (copy) v_u_1232, (ref) v_u_691, (copy) v_u_1233, (ref) v_u_1242, (copy) v_u_1346, (copy) p_u_1229, (copy) v_u_1231
		local v1349 = (p1347 == "bmBuyBest" or p1347 == "bmRsBuy") and "bmBuy" or p1347
		if v_u_1232.busy[v1349] then
			return {
				["ok"] = false,
				["code"] = "BUSY",
				["text"] = nil,
				["data"] = nil,
				["text"] = v_u_691.text(v_u_1233, "BUSY"),
				["data"] = {}
			}
		end
		v_u_1232.busy[v1349] = true
		local v1350
		if v_u_1242 then
			v1350 = v_u_1346(v_u_1242:op(p1347, p1348))
		else
			p1348.op = p1347
			local v_u_1351 = coroutine.running()
			local v_u_1352 = p_u_1229.op(p1348)
			local v_u_1353 = {
				["co"] = v_u_1351
			}
			v_u_1232.waits[v_u_1352] = v_u_1353
			task.delay(v_u_1231.timeout or 20, function()
				-- upvalues: (ref) v_u_1232, (copy) v_u_1352, (copy) v_u_1353, (copy) v_u_1351
				if v_u_1232.waits[v_u_1352] == v_u_1353 then
					v_u_1232.waits[v_u_1352] = nil
					task.spawn(v_u_1351, {
						["timeout"] = true
					})
				end
			end)
			v1350 = v_u_1346(coroutine.yield())
		end
		v_u_1232.busy[v1349] = false
		if p1347 == "bmOrder" or (p1347 == "bmOrderCancel" or (p1347 == "bmSellNow" or (p1347 == "bmBuy" or p1347 == "bmBuyBest"))) then
			v_u_1232:invalidate("book")
			v_u_1232:invalidate("quote")
		end
		if p1347 == "bmBuy" or p1347 == "bmBuyBest" then
			local v1354 = v_u_691.TEXT
			local v1355
			if v1350.toMail == true then
				v1355 = v_u_691.TEXT.boughtMail
			else
				v1355 = v_u_691.TEXT.boughtStash
			end
			v1354.bought = v1355
		end
		v_u_1232:invalidate("state")
		if p1347 ~= "bmRsBuy" then
			v_u_1232:invalidate("mine")
		end
		local v1356 = {
			["op"] = p1347,
			["result"] = v1350
		}
		for _, v1357 in v_u_1232.changeSubs do
			pcall(v1357, "result", v1356)
		end
		return v1350
	end
	function v_u_1232.list(_, p1359) -- name: list
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmList", {
			["uid"] = p1359.uid,
			["n"] = p1359.n,
			["price"] = p1359.price,
			["strip"] = p1359.strip and true or nil
		})
	end
	function v_u_1232.buy(_, p1360) -- name: buy
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmBuy", {
			["id"] = p1360.id,
			["lid"] = p1360.lid,
			["price"] = p1360.price
		})
	end
	function v_u_1232.buyBest(_, p1361) -- name: buyBest
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmBuyBest", {
			["id"] = p1361.id,
			["maxUnit"] = p1361.maxUnit,
			["maxTotal"] = p1361.maxTotal,
			["good"] = p1361.good == true and true or nil
		})
	end
	function v_u_1232.rsBuy(_, p1362) -- name: rsBuy
		-- upvalues: (copy) v_u_1232, (ref) v_u_691, (copy) v_u_1233, (copy) v_u_1358
		local v1363 = v_u_1232:clock()
		if not v_u_691.rsCanSend(v_u_1232.rsSentAt, v1363) then
			return {
				["ok"] = false,
				["code"] = "RATE",
				["text"] = nil,
				["data"] = nil,
				["blocked"] = true,
				["text"] = v_u_691.text(v_u_1233, "RATE"),
				["data"] = {}
			}
		end
		v_u_1232.rsSentAt = v1363
		local v1364 = v_u_1358("bmRsBuy", {
			["r"] = p1362.r,
			["i"] = p1362.i,
			["n"] = p1362.n,
			["u"] = p1362.u
		})
		local v1365 = v1364.data
		local v1366 = type(v1365) ~= "table" and {} or v1364.data
		local v1367 = v1364.code or v1366.code
		if v1364.ok == true then
			v_u_1232.rsLast[p1362.i] = nil
			local v1368 = v1364.text
			local v1369
			if type(v1368) == "string" then
				v1369 = string.find(v1364.text, "waiting in your mail", 1, true) ~= nil
			else
				v1369 = false
			end
			v1364.toMail = v1369
		else
			local v1370 = v_u_1232.rsLast
			local v1371 = p1362.i
			local v1372 = {
				["code"] = v1367,
				["avail"] = v1366.avail
			}
			local v1373 = v1366.retryIn
			local v1374
			if type(v1373) == "number" then
				v1374 = v_u_1232:clock() + v1366.retryIn
			else
				v1374 = nil
			end
			v1372.retryAt = v1374
			v1372.at = v_u_1232:clock()
			v1370[v1371] = v1372
			if v1367 == "SOLD_OUT" then
				v_u_1232.rsMarks[p1362.i] = {
					["st"] = "out",
					["at"] = nil,
					["at"] = v_u_1232:clock()
				}
			end
		end
		v_u_1232:invalidate("restock")
		return v1364
	end
	function v_u_1232.cancel(_, p1375) -- name: cancel
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmCancel", {
			["lid"] = p1375.lid
		})
	end
	function v_u_1232.claim(_, p1376) -- name: claim
		-- upvalues: (copy) v_u_1358
		local v1377 = v_u_1358
		local v1378 = "bmClaim"
		local v1379 = {}
		local v1380
		if p1376 then
			v1380 = p1376.lid
		else
			v1380 = nil
		end
		v1379.lid = v1380
		return v1377(v1378, v1379)
	end
	function v_u_1232.order(_, p1381) -- name: order
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmOrder", {
			["id"] = p1381.id,
			["n"] = p1381.n,
			["price"] = p1381.price
		})
	end
	function v_u_1232.orderCancel(_, p1382) -- name: orderCancel
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmOrderCancel", {
			["oid"] = p1382.oid
		})
	end
	function v_u_1232.sellNow(_, p1383) -- name: sellNow
		-- upvalues: (copy) v_u_1358
		return v_u_1358("bmSellNow", {
			["uid"] = p1383.uid,
			["n"] = p1383.n,
			["minPrice"] = p1383.minPrice,
			["strip"] = p1383.strip and true or nil
		})
	end
	function v_u_1232.isBusy(_, p1384) -- name: isBusy
		-- upvalues: (copy) v_u_1232
		if p1384 then
			return v_u_1232.busy[p1384] == true
		end
		local v1385
		if next(v_u_1232.busy) == nil then
			v1385 = false
		else
			v1385 = (v_u_1232.busy.bmList or (v_u_1232.busy.bmBuy or v_u_1232.busy.bmCancel) or (v_u_1232.busy.bmClaim or v_u_1232.busy.bmOrder or (v_u_1232.busy.bmOrderCancel or v_u_1232.busy.bmSellNow))) == true
		end
		return v1385
	end
	function v_u_1232.onNote(_, p1386) -- name: onNote
		-- upvalues: (copy) v_u_1232
		local v1387 = v_u_1232
		v1387.subId = v1387.subId + 1
		local v_u_1388 = v_u_1232.subId
		v_u_1232.noteSubs[v_u_1388] = p1386
		return function()
			-- upvalues: (ref) v_u_1232, (copy) v_u_1388
			v_u_1232.noteSubs[v_u_1388] = nil
		end
	end
	function v_u_1232.onChange(_, p1389) -- name: onChange
		-- upvalues: (copy) v_u_1232
		local v1390 = v_u_1232
		v1390.subId = v1390.subId + 1
		local v_u_1391 = v_u_1232.subId
		v_u_1232.changeSubs[v_u_1391] = p1389
		return function()
			-- upvalues: (ref) v_u_1232, (copy) v_u_1391
			v_u_1232.changeSubs[v_u_1391] = nil
		end
	end
	function v_u_1232.feed(_, p1392) -- name: feed
		-- upvalues: (copy) v_u_1232
		v_u_1232:invalidate("state")
		v_u_1232:invalidate("mine")
		for _, v1393 in v_u_1232.noteSubs do
			pcall(v1393, p1392)
		end
		for _, v1394 in v_u_1232.changeSubs do
			pcall(v1394, "note", p1392)
		end
	end
	local v_u_1395 = nil
	if not v_u_1242 then
		local v1396 = p_u_1229.changed
		if type(v1396) == "table" then
			local v1397 = p_u_1229.changed.Connect
			if type(v1397) == "function" then
				v_u_1395 = p_u_1229.changed:Connect(function(p1398, p1399)
					-- upvalues: (copy) v_u_1232
					if p1398 == "result" and type(p1399) == "table" then
						local v1400 = p1399.req
						local v1401 = type(v1400) == "number" and v_u_1232.waits[p1399.req]
						if v1401 then
							v_u_1232.waits[p1399.req] = nil
							task.spawn(v1401.co, p1399)
						end
					end
				end)
			end
		end
	end
	local v_u_1402 = nil
	local function v1406()
		-- upvalues: (copy) p_u_1229, (ref) v_u_1402, (copy) v_u_1232
		local v1403 = p_u_1229.cctx.controllers.BmNotes
		if v1403 then
			local v1404 = v1403.subscribe
			if type(v1404) == "function" then
				v_u_1402 = v1403.subscribe(function(p1405)
					-- upvalues: (ref) v_u_1232
					v_u_1232:feed(p1405)
				end)
			end
		end
	end
	pcall(v1406)
	function v_u_1232.eligibility(_) -- name: eligibility
		-- upvalues: (copy) v_u_1232, (copy) p_u_1229, (copy) v_u_1231
		if v_u_1232._elig then
			return v_u_1232._elig
		end
		local v_u_1407 = nil
		local function v1408()
			-- upvalues: (ref) v_u_1407, (ref) p_u_1229
			v_u_1407 = p_u_1229.cctx.shared.BmEligibility
		end
		pcall(v1408)
		local v1409 = v_u_1407
		if type(v1409) == "table" then
			local v1410 = v_u_1407.catalog
			if type(v1410) == "function" then
				v_u_1232._elig = v_u_1407
				return v_u_1232._elig
			end
		end
		local function v1411()
			-- upvalues: (ref) v_u_1231, (ref) p_u_1229
			return v_u_1231.fakeModule or p_u_1229.cctx.lib.MenuMarketFake
		end
		local v1412, v1413 = pcall(v1411)
		if v1412 and type(v1413) == "table" then
			local v1414 = v1413.eligibility
			if type(v1414) == "function" then
				v_u_1232._elig = v1413.eligibility(p_u_1229)
				return v_u_1232._elig
			end
		end
		v_u_1232._elig = {
			["CATEGORIES"] = {},
			["catalog"] = function() -- name: catalog
				return {}
			end,
			["categoryOf"] = function() -- name: categoryOf
				return "materials"
			end,
			["checkInst"] = function() -- name: checkInst
				return false, "UNKNOWN_ITEM"
			end,
			["stripPlan"] = function() -- name: stripPlan
				return {
					["mods"] = 0,
					["loaded"] = false,
					["rounds"] = 0
				}
			end
		}
		return v_u_1232._elig
	end
	function v_u_1232.catalog(_) -- name: catalog
		-- upvalues: (copy) v_u_1232
		if not v_u_1232._catalog then
			local function v1415()
				-- upvalues: (ref) v_u_1232
				return v_u_1232:eligibility().catalog()
			end
			local v1416, v1417 = pcall(v1415)
			v_u_1232._catalog = (not v1416 or type(v1417) ~= "table") and {} or v1417
		end
		return v_u_1232._catalog
	end
	function v_u_1232.stash(_) -- name: stash
		-- upvalues: (ref) v_u_1242, (copy) p_u_1229
		local v1418 = v_u_1242 and (v_u_1242.stash and v_u_1242:stash())
		if v1418 then
			return v1418
		end
		local v1419 = p_u_1229.profile
		local v1420
		if type(v1419) == "table" then
			v1420 = v1419.inv
		else
			v1420 = nil
		end
		local v1421
		if type(v1420) == "table" then
			v1421 = v1420.containers
		else
			v1421 = nil
		end
		local v1422
		if type(v1421) == "table" then
			v1422 = v1421.stash
		else
			v1422 = nil
		end
		if type(v1422) == "table" then
			local v1423 = v1422.items
			if type(v1423) == "table" then
				return v1422.items
			end
		end
		return {}
	end
	function v_u_1232.insured(_, p1424) -- name: insured
		-- upvalues: (copy) p_u_1229
		local v1425 = p_u_1229.profile
		local v1426
		if type(v1425) == "table" then
			v1426 = v1425.insurance
		else
			v1426 = nil
		end
		local v1427
		if type(v1426) == "table" then
			v1427 = v1426.policies
		else
			v1427 = nil
		end
		if type(v1427) == "table" then
			for _, v1428 in v1427 do
				if type(v1428) ~= "table" or v1428.uid ~= p1424 then
					continue
				end
				local v1429 = v1428.raidsLeft
				if (tonumber(v1429) or 0) <= 0 then
					continue
				end
				return true
			end
		end
		return false
	end
	function v_u_1232.cash(_) -- name: cash
		-- upvalues: (copy) p_u_1229, (ref) v_u_1242
		local v1430 = p_u_1229.profile
		local v1431
		if type(v1430) == "table" then
			local v1432 = v1430.cash
			v1431 = type(v1432) ~= "number" and 0 or v1430.cash
		else
			v1431 = 0
		end
		local v1433
		if v_u_1242 then
			local v1434 = v_u_1242.cashAdj
			v1433 = type(v1434) ~= "number" and 0 or v_u_1242.cashAdj
		else
			v1433 = 0
		end
		return v1431 + v1433
	end
	function v_u_1232.destroy(_) -- name: destroy
		-- upvalues: (copy) v_u_1232, (ref) v_u_1395, (ref) v_u_1402, (ref) v_u_1242
		v_u_1232.alive = false
		if v_u_1395 then
			v_u_1395:Disconnect()
			v_u_1395 = nil
		end
		if v_u_1402 then
			v_u_1402()
			v_u_1402 = nil
		end
		table.clear(v_u_1232.noteSubs)
		table.clear(v_u_1232.changeSubs)
		for v1435, v1436 in v_u_1232.waits do
			v_u_1232.waits[v1435] = nil
			task.spawn(v1436.co, {
				["timeout"] = true
			})
		end
		if v_u_1242 and v_u_1242.destroy then
			v_u_1242:destroy()
		end
	end
	return v_u_1232
end
return v_u_691