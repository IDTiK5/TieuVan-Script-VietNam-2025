-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryMath

local v_u_59 = {
	["finite"] = function(p1) -- name: finite
		local v2
		if type(p1) == "number" and (p1 == p1 and p1 > -1000000000000) then
			v2 = p1 < 1000000000000
		else
			v2 = false
		end
		return v2
	end,
	["clamp"] = function(p3, p4, p5) -- name: clamp
		if p3 < p4 then
			return p4
		elseif p5 < p3 then
			return p5
		else
			return p3
		end
	end,
	["lerp"] = function(p6, p7, p8) -- name: lerp
		return p6 + (p7 - p6) * p8
	end,
	["unlerp"] = function(p9, p10, p11) -- name: unlerp
		-- upvalues: (copy) v_u_59
		return p10 == p9 and 1 or v_u_59.clamp((p11 - p9) / (p10 - p9), 0, 1)
	end,
	["smooth"] = function(p12) -- name: smooth
		-- upvalues: (copy) v_u_59
		local v13 = v_u_59.clamp(p12, 0, 1)
		return v13 * v13 * (3 - v13 * 2)
	end,
	["easeOut"] = function(p14) -- name: easeOut
		-- upvalues: (copy) v_u_59
		local v15 = 1 - v_u_59.clamp(p14, 0, 1)
		return 1 - v15 * v15 * v15
	end,
	["easeIn"] = function(p16) -- name: easeIn
		-- upvalues: (copy) v_u_59
		local v17 = v_u_59.clamp(p16, 0, 1)
		return v17 * v17 * v17
	end,
	["easeInOut"] = function(p18) -- name: easeInOut
		-- upvalues: (copy) v_u_59
		local v19 = v_u_59.clamp(p18, 0, 1)
		if v19 < 0.5 then
			return v19 * 4 * v19 * v19
		end
		local v20 = v19 * -2 + 2
		return 1 - v20 * v20 * v20 / 2
	end,
	["v"] = function(p21, p22, p23) -- name: v
		return {
			["x"] = p21,
			["y"] = p22,
			["z"] = p23
		}
	end,
	["add"] = function(p24, p25) -- name: add
		return {
			["x"] = p24.x + p25.x,
			["y"] = p24.y + p25.y,
			["z"] = p24.z + p25.z
		}
	end,
	["sub"] = function(p26, p27) -- name: sub
		return {
			["x"] = p26.x - p27.x,
			["y"] = p26.y - p27.y,
			["z"] = p26.z - p27.z
		}
	end,
	["scale"] = function(p28, p29) -- name: scale
		return {
			["x"] = p28.x * p29,
			["y"] = p28.y * p29,
			["z"] = p28.z * p29
		}
	end,
	["mix"] = function(p30, p31, p32) -- name: mix
		return {
			["x"] = p30.x + (p31.x - p30.x) * p32,
			["y"] = p30.y + (p31.y - p30.y) * p32,
			["z"] = p30.z + (p31.z - p30.z) * p32
		}
	end,
	["len"] = function(p33) -- name: len
		local v34 = p33.x * p33.x + p33.y * p33.y + p33.z * p33.z
		return math.sqrt(v34)
	end,
	["dist"] = function(p35, p36) -- name: dist
		local v37 = p35.x - p36.x
		local v38 = p35.y - p36.y
		local v39 = p35.z - p36.z
		local v40 = v37 * v37 + v38 * v38 + v39 * v39
		return math.sqrt(v40)
	end,
	["flat"] = function(p41) -- name: flat
		return {
			["x"] = nil,
			["y"] = 0,
			["z"] = nil,
			["x"] = p41.x,
			["z"] = p41.z
		}
	end,
	["axes"] = function(p42) -- name: axes
		local v43 = math.sin(p42)
		local v44 = math.cos(p42)
		return {
			["x"] = nil,
			["y"] = 0,
			["z"] = nil,
			["x"] = -v43,
			["z"] = -v44
		}, {
			["x"] = nil,
			["y"] = 0,
			["z"] = nil,
			["x"] = v44,
			["z"] = -v43
		}
	end,
	["yawOfDir"] = function(p45, p46) -- name: yawOfDir
		if math.abs(p45) + math.abs(p46) < 1e-6 then
			return 0
		end
		local v47 = -p45
		local v48 = -p46
		return math.atan2(v47, v48)
	end,
	["lerpYaw"] = function(p49, p50, p51) -- name: lerpYaw
		local v52 = (p50 - p49) % 6.283185307179586
		if v52 > 3.141592653589793 then
			v52 = v52 - 6.283185307179586
		end
		return p49 + v52 * p51
	end,
	["centroid"] = function(p53) -- name: centroid
		local v54 = #p53
		if v54 == 0 then
			return {
				["x"] = 0,
				["y"] = 0,
				["z"] = 0
			}
		end
		local v55 = 0
		local v56 = 0
		local v57 = 0
		for _, v58 in p53 do
			v55 = v55 + v58.x
			v56 = v56 + v58.y
			v57 = v57 + v58.z
		end
		return {
			["x"] = v55 / v54,
			["y"] = v56 / v54,
			["z"] = v57 / v54
		}
	end
}
return v_u_59