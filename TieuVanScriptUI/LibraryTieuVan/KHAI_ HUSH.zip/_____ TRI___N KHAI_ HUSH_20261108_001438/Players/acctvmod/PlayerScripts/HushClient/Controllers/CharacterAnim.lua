-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / CharacterAnim

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = {
	["name"] = "CharacterAnim",
	["order"] = 20
}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = v_u_3.LocalPlayer
local v_u_14 = true
local v_u_15 = -10
local v_u_16 = true
local v_u_17 = -10
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = Color3.fromRGB(176, 152, 96)
local function v_u_36(p22, p23) -- name: keyProp
	-- upvalues: (copy) v_u_20, (copy) v_u_21, (ref) v_u_7
	local v24 = p22.model
	local v25 = v_u_20[v24]
	if p23 then
		local v26 = v24:FindFirstChild(p22.keyHand .. "Hand") or v24:FindFirstChild(p22.keyHand .. " Arm")
		if v26 then
			if not (v25 and v25.Parent) then
				local v27 = workspace:FindFirstChild("HushLocal")
				if not v27 then
					v27 = Instance.new("Folder")
					v27.Name = "HushLocal"
					v27.Parent = workspace
				end
				v25 = Instance.new("Model")
				v25.Name = "HushKeyProp"
				for v28, v29 in {
					{ "Bow", Vector3.new(0.05, 0.26, 0.26) },
					{ "Blade", Vector3.new(0.07, 0.42, 0.04) }
				} do
					local v30 = Instance.new("Part")
					v30.Name = v29[1]
					v30.Size = v29[2]
					local v31
					if v28 == 1 then
						v31 = Enum.PartType.Cylinder
					else
						v31 = Enum.PartType.Block
					end
					v30.Shape = v31
					v30.Anchored = true
					v30.CanCollide = false
					v30.CanQuery = false
					v30.CanTouch = false
					v30.CastShadow = false
					v30.Material = Enum.Material.Metal
					v30.Color = v_u_21
					v30.Parent = v25
				end
				v25.Parent = v27
				v_u_20[v24] = v25
			end
			local v32 = v_u_7.keyTurn(p22.actionT)
			local v33 = v26.CFrame * CFrame.new(0, -v26.Size.Y * 0.5, 0) * CFrame.Angles(0, v32, 0)
			local v34 = v25:FindFirstChild("Bow")
			local v35 = v25:FindFirstChild("Blade")
			if v34 then
				v34.CFrame = v33 * CFrame.new(0, 0.02, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
			end
			if v35 then
				v35.CFrame = v33 * CFrame.new(0, -0.22, 0)
			end
		end
	else
		if v25 then
			v_u_20[v24] = nil
			v25:Destroy()
		end
		return
	end
end
local v_u_37 = {}
local v_u_38 = true
local v_u_39 = RaycastParams.new()
v_u_39.FilterType = Enum.RaycastFilterType.Exclude
v_u_39.IgnoreWater = true
local function v_u_56(p40) -- name: findWeapon
	local v41 = p40.model:FindFirstChild("HeldWeapon")
	if not v41 then
		return nil
	end
	if p40.weapon and (p40.weapon.model == v41 and (p40.weapon.handle == nil or p40.weapon.handle.Parent)) then
		return p40.weapon
	end
	local v42 = v41:FindFirstChild("Handle", true)
	if not (v42 and v42:IsA("BasePart")) then
		return {
			["model"] = nil,
			["handle"] = nil,
			["gripInv"] = nil,
			["support"] = nil,
			["relInv"] = nil,
			["model"] = v41,
			["gripInv"] = CFrame.identity
		}
	end
	local v43 = v42:FindFirstChild("Grip") or v41:FindFirstChild("Grip", true)
	local v44
	if v43 and v43:IsA("Attachment") then
		v44 = v42.CFrame:ToObjectSpace(v43.WorldCFrame)
	else
		v44 = CFrame.identity
	end
	local v45 = v42:FindFirstChild("SupportGrip") or v41:FindFirstChild("SupportGrip", true)
	local v46
	if v45 and v45:IsA("Attachment") then
		v46 = v42.CFrame:ToObjectSpace(v45.WorldCFrame)
	else
		v46 = nil
	end
	local v47 = p40.model:FindFirstChild("RightHand")
	local v48 = nil
	local v49 = p40.model:FindFirstChild("WeaponGrip", true)
	local v50
	if v49 == nil then
		v50 = false
	else
		v50 = v49:GetAttribute("Wrapped") == true
	end
	if v49 and (v49:IsA("Motor6D") or v49:IsA("Weld")) and v47 then
		local v51 = v49:GetAttribute("TossBaseC0")
		if typeof(v51) ~= "CFrame" then
			v51 = v49.C0
		end
		if v49.Part0 == v47 and v49.Part1 then
			local v52 = v49.Part1
			v48 = v51 * v49.C1:Inverse() * v52.CFrame:ToObjectSpace(v42.CFrame)
		elseif v49.Part1 == v47 and v49.Part0 then
			local v53 = v49.Part0
			v48 = (v51 * v49.C1:Inverse()):Inverse() * v53.CFrame:ToObjectSpace(v42.CFrame)
		end
	end
	if not v48 and v47 then
		v48 = v47.CFrame:ToObjectSpace(v42.CFrame)
	end
	local v54 = {
		["model"] = v41,
		["handle"] = v42,
		["gripInv"] = v44:Inverse(),
		["support"] = v46
	}
	local v55
	if v48 then
		v55 = v48:Inverse()
	else
		v55 = nil
	end
	v54.relInv = v55
	v54.wrapped = v50
	if v49 == nil or not v49:IsA("Motor6D") then
		v49 = nil
	end
	v54.motor = v49
	return v54
end
local function v_u_64() -- name: rebuildExclude
	-- upvalues: (ref) v_u_38, (copy) v_u_37, (copy) v_u_18, (copy) v_u_3, (copy) v_u_39
	v_u_38 = false
	table.clear(v_u_37)
	for v57 in v_u_18 do
		local v58 = v_u_37
		table.insert(v58, v57)
	end
	for _, v59 in v_u_3:GetPlayers() do
		if not v59.Character or v_u_18[v59.Character] then
			continue
		end
		local v60 = v_u_37
		local v61 = v59.Character
		table.insert(v60, v61)
	end
	local v62 = workspace:FindFirstChild("HushLocal")
	if v62 then
		local v63 = v_u_37
		table.insert(v63, v62)
	end
	v_u_39.FilterDescendantsInstances = v_u_37
end
local function v_u_159(p_u_65, p66) -- name: track
	-- upvalues: (ref) v_u_6, (copy) v_u_19, (copy) v_u_13, (copy) v_u_18, (ref) v_u_38, (copy) v_u_4, (ref) v_u_5, (copy) v_u_2
	local v67 = v_u_6.new(p_u_65)
	if v67 then
		local v68 = v67.root
		local v69 = p_u_65:FindFirstChildOfClass("Humanoid")
		local v70 = -((not v69 and 2 or v69.HipHeight) + v68.Size.Y / 2)
		local v71 = v67:bindPivot("LeftAnkle").Position
		local v72 = v67:bindPivot("RightAnkle").Position
		if not v67.joints.LeftAnkle then
			local v73 = v67:bindPivot("LeftKnee").Position
			local v74 = v67.bone.LeftKnee or 1.2
			v71 = v73 - Vector3.new(0, v74, 0)
			local v75 = v67:bindPivot("RightKnee").Position
			local v76 = v67.bone.RightKnee or 1.2
			v72 = v75 - Vector3.new(0, v76, 0)
		end
		local v77 = (v67.bone.LeftHip or 1.35) + (v67.bone.LeftKnee or 1.25)
		local v78 = p_u_65:FindFirstChild("RightGripAttachment", true)
		local v79 = p_u_65:FindFirstChild("LeftGripAttachment", true)
		local v80 = CFrame.new(0, -0.15, 0) * CFrame.Angles(-1.5707963267948966, 0, 0)
		local v_u_81 = {
			["model"] = p_u_65,
			["player"] = p66,
			["isLocal"] = p66 == v_u_13,
			["hum"] = v69,
			["root"] = v68,
			["rig"] = v67
		}
		local v82
		if p66 then
			v82 = p66.UserId % 1000
		else
			v82 = math.random(1, 1000)
		end
		v_u_81.seed = v82
		v_u_81.groundY = v70
		v_u_81.scale = v77 / 2.6
		v_u_81.ankleL = v71
		v_u_81.ankleR = v72
		v_u_81.legLen = v77
		v_u_81.shR = v67:bindPivot("RightShoulder").Position
		v_u_81.shL = v67:bindPivot("LeftShoulder").Position
		v_u_81.rootPivotY = v67:bindPivot("Root").Position.Y
		local v83
		if v78 and v78:IsA("Attachment") then
			v83 = v78.CFrame
		else
			v83 = v80
		end
		v_u_81.rgaInv = v83:Inverse()
		if v79 and v79:IsA("Attachment") then
			v80 = v79.CFrame
		end
		v_u_81.lgaInv = v80:Inverse()
		v_u_81.vel = Vector3.new(0, 0, 0)
		v_u_81.prevVel = Vector3.new(0, 0, 0)
		v_u_81.accel = Vector3.new(0, 0, 0)
		v_u_81.speed = 0
		v_u_81.mdir = Vector3.new(0, 0, -1)
		v_u_81.gw = 0
		v_u_81.phase = 0
		v_u_81.hipYaw = 0
		v_u_81.crouch = 0
		v_u_81.drop = 0
		v_u_81.lead = 0
		v_u_81.aimPitch = 0
		v_u_81.yawRate = 0
		v_u_81.prevYaw = 0
		v_u_81.wAim = 0
		v_u_81.wSneak = 0
		v_u_81.wSprint = 0
		v_u_81.wFall = 0
		v_u_81.kick = 0
		v_u_81.kickScale = 1
		v_u_81.kickN = 0
		v_u_81.lastLocalKick = -10
		local v84 = p_u_65:GetAttribute("LastShotAt")
		v_u_81.lastShotAt = (type(v84) ~= "number" or v84 ~= v84) and 0 or v84
		v_u_81.swingStart = -10
		v_u_81.swingDur = 0.6
		v_u_81.swingWindup = 0.3
		v_u_81.swingToss = false
		v_u_81.swingVariant = nil
		v_u_81.katana = nil
		v_u_81.lastWid = false
		v_u_81.tossGap = 0
		v_u_81.bashStart = -10
		v_u_81.punchN = 0
		v_u_81.guardUntil = -10
		v_u_81.keyAction = false
		v_u_81.keyHand = "Right"
		v_u_81.reach = 0
		v_u_81.lastLocalSwing = -10
		local v85 = p_u_65:GetAttribute("LastMeleeAt")
		v_u_81.lastMeleeAt = (type(v85) ~= "number" or v85 ~= v85) and 0 or v85
		v_u_81.reloadStart = -10
		v_u_81.reloadDur = 2
		v_u_81.reloadSingle = 0
		v_u_81.reloading = false
		v_u_81.reloadMute = nil
		v_u_81.reloadMuteT = 0
		v_u_81.reloadMuteOff = false
		v_u_81.flinch = 0
		v_u_81.flinchYaw = 0
		v_u_81.stance = 0
		local v86 = p_u_65:GetAttribute("Hp")
		v_u_81.hpPrev = (type(v86) ~= "number" or v86 ~= v86) and 100 or v86
		v_u_81.downedAt = -10
		v_u_81.deadAt = -10
		v_u_81.deadDone = false
		v_u_81.crawl = 0
		v_u_81.breath = math.random() * 10
		v_u_81.feet = {
			["L"] = {
				["plant"] = nil,
				["stepping"] = false,
				["stepT"] = 0,
				["stepFrom"] = nil,
				["stepTo"] = nil,
				["inStance"] = true,
				["target"] = nil,
				["stepFrom"] = v71,
				["stepTo"] = v71,
				["target"] = v71
			},
			["R"] = {
				["plant"] = nil,
				["stepping"] = false,
				["stepT"] = 0,
				["stepFrom"] = nil,
				["stepTo"] = nil,
				["inStance"] = true,
				["target"] = nil,
				["stepFrom"] = v72,
				["stepTo"] = v72,
				["target"] = v72
			}
		}
		v_u_81.idleStepCooldown = 0
		v_u_81.weapon = nil
		v_u_81.weaponCheck = 0
		v_u_81.lastT = os.clock()
		v_u_81.lodAcc = 0
		v_u_81.actionT = 0
		v_u_81.stamina = 100
		v_u_81.conns = {}
		v_u_18[p_u_65] = v_u_81
		v_u_38 = true
		local v87 = v_u_81.conns
		local v88 = p_u_65:GetAttributeChangedSignal("LastShotAt")
		local function v92()
			-- upvalues: (copy) p_u_65, (copy) v_u_81, (ref) v_u_4
			local v89 = p_u_65:GetAttribute("LastShotAt")
			local v90 = (type(v89) ~= "number" or v89 ~= v89) and 0 or v89
			if v_u_81.lastShotAt < v90 then
				v_u_81.lastShotAt = v90
				local v91 = p_u_65:GetAttribute("HoldType")
				if v91 == "melee1h" or v91 == "melee2h" then
					if os.clock() - v_u_81.lastLocalSwing > 0.5 then
						v_u_4.swing(p_u_65)
						return
					end
				elseif not v_u_81.isLocal or os.clock() - v_u_81.lastLocalKick > 0.35 then
					v_u_4.recoil(nil, p_u_65)
				end
			end
		end
		table.insert(v87, v88:Connect(v92))
		local v93 = v_u_81.conns
		local v94 = p_u_65:GetAttributeChangedSignal("LastMeleeAt")
		local function v97()
			-- upvalues: (copy) p_u_65, (copy) v_u_81, (ref) v_u_4
			local v95 = p_u_65:GetAttribute("LastMeleeAt")
			local v96 = (type(v95) ~= "number" or v95 ~= v95) and 0 or v95
			if v_u_81.lastMeleeAt < v96 then
				v_u_81.lastMeleeAt = v96
				if os.clock() - v_u_81.lastLocalSwing > 0.5 then
					v_u_4.swing(p_u_65)
				end
			end
		end
		table.insert(v93, v94:Connect(v97))
		local v98 = v_u_81.conns
		local v99 = p_u_65:GetAttributeChangedSignal("Weapon")
		local function v115()
			-- upvalues: (copy) v_u_81, (copy) p_u_65, (ref) v_u_5
			if v_u_81.reloadMute ~= nil and p_u_65:GetAttribute("Weapon") ~= v_u_81.reloadMute then
				v_u_81.reloadMute = nil
				local v100 = p_u_65:GetAttribute("Reloading") == true
				if v100 and not v_u_81.reloading then
					local v101 = p_u_65:GetAttribute("Weapon")
					local v102
					if type(v101) == "string" and v101 ~= "" then
						local v_u_103 = "Weapons"
						local function v104()
							-- upvalues: (ref) v_u_5, (copy) v_u_103
							return v_u_5.shared[v_u_103]
						end
						local v105, v106 = pcall(v104)
						if not v105 then
							v106 = nil
						end
						if v106 and v106.get then
							local v107 = v106.get
							local v108
							v108, v102 = pcall(v107, v101)
							if not v108 then
								v102 = nil
							end
						else
							v102 = nil
						end
					else
						v102 = nil
					end
					v_u_81.reloadStart = os.clock()
					local v109 = v_u_81
					local v110
					if v102 then
						local v111 = v102.reloadTime
						v110 = (type(v111) ~= "number" or v111 ~= v111) and 2 or v111
					else
						v110 = 2
					end
					v109.reloadDur = v110
					local v112 = v_u_81
					local v113
					if v102 and v102.reloadKind == "single" then
						local v114 = v102.reloadPerRound
						v113 = (type(v114) ~= "number" or v114 ~= v114) and 0.5 or v114
					else
						v113 = 0
					end
					v112.reloadSingle = v113
				end
				v_u_81.reloading = v100
			end
		end
		table.insert(v98, v99:Connect(v115))
		local v116 = v_u_81.conns
		local v117 = p_u_65:GetAttributeChangedSignal("Reloading")
		local function v134()
			-- upvalues: (copy) p_u_65, (copy) v_u_81, (ref) v_u_5
			local v118 = p_u_65:GetAttribute("Reloading") == true
			if not v118 and v_u_81.reloadMuteOff then
				v_u_81.reloadMute = nil
				v_u_81.reloadMuteOff = false
			end
			if v118 then
				local v119
				if v_u_81.reloadMute == nil or p_u_65:GetAttribute("Weapon") ~= v_u_81.reloadMute then
					v119 = false
				else
					v119 = os.clock() - v_u_81.reloadMuteT < 2
				end
				if v119 then
					return
				end
			end
			if v118 and not v_u_81.reloading then
				local v120 = p_u_65:GetAttribute("Weapon")
				local v121
				if type(v120) == "string" and v120 ~= "" then
					local v_u_122 = "Weapons"
					local function v123()
						-- upvalues: (ref) v_u_5, (copy) v_u_122
						return v_u_5.shared[v_u_122]
					end
					local v124, v125 = pcall(v123)
					if not v124 then
						v125 = nil
					end
					if v125 and v125.get then
						local v126 = v125.get
						local v127
						v127, v121 = pcall(v126, v120)
						if not v127 then
							v121 = nil
						end
					else
						v121 = nil
					end
				else
					v121 = nil
				end
				v_u_81.reloadStart = os.clock()
				local v128 = v_u_81
				local v129
				if v121 then
					local v130 = v121.reloadTime
					v129 = (type(v130) ~= "number" or v130 ~= v130) and 2 or v130
				else
					v129 = 2
				end
				v128.reloadDur = v129
				local v131 = v_u_81
				local v132
				if v121 and v121.reloadKind == "single" then
					local v133 = v121.reloadPerRound
					v132 = (type(v133) ~= "number" or v133 ~= v133) and 0.5 or v133
				else
					v132 = 0
				end
				v131.reloadSingle = v132
			end
			v_u_81.reloading = v118
		end
		table.insert(v116, v117:Connect(v134))
		local v135 = v_u_81.conns
		local v136 = p_u_65:GetAttributeChangedSignal("ReloadEndsAt")
		local function v146()
			-- upvalues: (copy) p_u_65, (copy) v_u_81, (ref) v_u_2
			local v137 = p_u_65:GetAttribute("ReloadEndsAt")
			local v138 = (type(v137) ~= "number" or v137 ~= v137) and 0 or v137
			if v_u_81.reloading and (v_u_81.reloadSingle <= 0 and v138 > 0) then
				local v139
				if v_u_81.reloadMute == nil or p_u_65:GetAttribute("Weapon") ~= v_u_81.reloadMute then
					v139 = false
				else
					v139 = os.clock() - v_u_81.reloadMuteT < 2
				end
				if not v139 then
					local v140 = v138 - v_u_2.now()
					local v141 = os.clock()
					local v142 = v141 - v_u_81.reloadStart
					local v143 = v_u_81.reloadDur
					local v144 = v142 / math.max(v143, 0.2)
					local v145 = math.clamp(v144, 0, 1)
					if v140 > 0.05 and (v140 < 12 and v145 < 0.97) then
						v_u_81.reloadDur = v140 / (1 - v145)
						v_u_81.reloadStart = v141 - v145 * v_u_81.reloadDur
					end
					return
				end
			end
		end
		table.insert(v135, v136:Connect(v146))
		local v147 = v_u_81.conns
		local v148 = p_u_65:GetAttributeChangedSignal("Hp")
		local function v158()
			-- upvalues: (copy) p_u_65, (copy) v_u_81, (ref) v_u_5
			local v149 = p_u_65:GetAttribute("Hp")
			local v150 = (type(v149) ~= "number" or v149 ~= v149) and 100 or v149
			if v150 < v_u_81.hpPrev - 0.5 then
				local v151 = v_u_81.hpPrev - v150
				local v152 = v_u_81
				local v153 = v_u_81.flinch + v151 / 22 + 0.25
				v152.flinch = math.min(1, v153)
				v_u_81.flinchYaw = (math.random() - 0.5) * 2
				if v_u_81.isLocal and v151 >= 3 then
					local v154 = v_u_5.controllers.Camera
					if v154 and v154.shake then
						local v155 = v154.shake
						local v156 = v151 / 40
						local v157 = math.clamp(v156, 0.12, 0.6)
						pcall(v155, v157, 0.25)
					end
				end
			end
			v_u_81.hpPrev = v150
		end
		table.insert(v147, v148:Connect(v158))
		v_u_81.reloading = p_u_65:GetAttribute("Reloading") == true
	else
		v_u_19[p_u_65] = os.clock()
	end
end
local function v_u_165(p160) -- name: untrack
	-- upvalues: (copy) v_u_18, (ref) v_u_9, (copy) v_u_20, (ref) v_u_38
	local v161 = v_u_18[p160]
	v_u_18[p160] = nil
	if v161 and v_u_9 then
		local v162 = v_u_9.release
		pcall(v162, v161)
	end
	local v163 = v_u_20[p160]
	if v163 then
		v_u_20[p160] = nil
		v163:Destroy()
	end
	v_u_38 = true
	if v161 then
		for _, v164 in v161.conns do
			v164:Disconnect()
		end
		table.clear(v161.conns)
	end
end
local function v_u_175(p166, p167, p168) -- name: footstep
	-- upvalues: (ref) v_u_5, (ref) v_u_38, (copy) v_u_64, (copy) v_u_39
	local v169 = v_u_5
	if v169 then
		v169 = v_u_5.controllers.Audio
	end
	local v170 = p166.root.CFrame:PointToWorldSpace(p167)
	if v_u_38 then
		v_u_64()
	end
	local v171 = workspace:Raycast(v170 + Vector3.new(0, 1.2, 0), Vector3.new(0, -3.5, 0), v_u_39)
	local v172
	if v171 then
		v172 = v171.Material
	elseif p166.hum then
		v172 = p166.hum.FloorMaterial
	else
		v172 = Enum.Material.Concrete
	end
	if v169 and v169.footstep then
		local v173 = v169.footstep
		local v174 = p166.model
		pcall(v173, v174, v172, p168)
	end
	v_u_5.emit("character.footstep", p166.model, v172, v170, p168)
end
local function v_u_204(p176, p177, p178, p179, p180, p181) -- name: armsToGrip
	-- upvalues: (ref) v_u_7
	local v182 = p176.rig
	local v183 = p176.weapon
	local v184 = nil
	local v185
	if v183 and (v183.handle and v183.relInv) then
		v184 = p177 * v183.gripInv
		v185 = v184 * v183.relInv
	else
		v185 = p177 * p176.rgaInv
	end
	local v186 = v182.joints.RightWrist
	local v187
	if v186 then
		v187 = (v185 * v186.c1).Position
	else
		v187 = v185.Position
	end
	local v188 = p176.scale
	local v189 = p181 + 0.55
	v182:solve2("RightShoulder", "RightElbow", "RightWrist", v187, Vector3.new(v189, -1, 0.45), Vector3.new(0, 0, 1))
	if v186 then
		v182:orientEnd("RightWrist", v185)
	end
	if p180 then
		local v190 = v182.joints.LeftWrist
		local v191 = CFrame.new(p180) * p177.Rotation * p176.lgaInv
		local v192
		if v190 then
			v192 = (v191 * v190.c1).Position
		else
			v192 = v191.Position
		end
		v182:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v192, Vector3.new(-0.6, -1, 0.3), Vector3.new(0, 0, 1))
	elseif p179 then
		local v193
		if v183 and (v183.support and v184) then
			v193 = v184 * v183.support
		else
			local v194 = v_u_7.support(p178) or CFrame.new(-0.2, 0, 0.1)
			v193 = p177 * CFrame.new(v194.Position * v188)
		end
		local v195 = CFrame.new(v193.Position) * p177.Rotation * v_u_7.leftRoll(p178) * p176.lgaInv
		if v183 and v183.wrapped then
			local v196 = p177.LookVector
			local v197 = v182:pivot("LeftShoulder").Position - v193.Position
			local v198 = v197 - v196 * v197:Dot(v196)
			if v198.Magnitude > 0.001 then
				local v199 = v198.Unit
				local v200 = -v196
				v195 = CFrame.new(v193.Position) * CFrame.fromMatrix(Vector3.new(0, 0, 0), v199:Cross(v200), v199, v200) * CFrame.new(-p176.lgaInv:Inverse().Position)
			end
		end
		local v201 = v182.joints.LeftWrist
		local v202
		if v201 then
			v202 = (v195 * v201.c1).Position
		else
			v202 = v195.Position
		end
		local v203 = -0.55 - p181 * 0.5
		v182:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v202, Vector3.new(v203, -1, 0.35), Vector3.new(0, 0, 1))
		if v201 then
			v182:orientEnd("LeftWrist", v195)
		end
	end
end
local function v_u_212(p205, p206, p207, p208, p209) -- name: freeArm
	local v210 = p205.rig
	local v211 = p206 == "Right" and 1 or -1
	v210:setT(p206 .. "Shoulder", CFrame.Angles(p207, 0, v211 * p209))
	v210:setT(p206 .. "Elbow", CFrame.Angles(p208, 0, 0))
	if v210.joints[p206 .. "Wrist"] then
		v210:setT(p206 .. "Wrist", CFrame.Angles(-0.08, 0, 0))
	end
end
local function v_u_224(p213, p214) -- name: poseDead
	-- upvalues: (copy) v_u_212
	local v215 = p213.rig
	local v216 = (p214 - p213.deadAt) / 0.85
	local v217 = math.clamp(v216, 0, 1)
	local v218 = v217 * v217
	local v219 = p213.seed % 3
	local v220 = p213.rootPivotY - (p213.groundY + p213.scale * 0.42)
	local v221 = v217 * 1.3
	local v222 = 3.141592653589793 * math.min(1, v221)
	local v223 = math.sin(v222)
	if v219 == 0 then
		v215:setT("Root", CFrame.new(0, -v220 * v218, p213.scale * 0.9 * v218) * CFrame.Angles(v218 * 1.52, 0, v218 * 0.18))
		v215:setT("Waist", CFrame.Angles(v223 * -0.12, v218 * 0.1, 0))
		v215:setT("Neck", CFrame.Angles(v218 * -0.25, v218 * 0.6, 0))
		v_u_212(p213, "Right", v218 * 0.4, v218 * 0.5, v218 * 1.2)
		v_u_212(p213, "Left", v218 * -0.2, v218 * 0.3, v218 * 0.9)
		v215:setT("RightHip", CFrame.Angles(v223 * 0.5 + v218 * 0.35, 0, v218 * 0.1))
		v215:setT("RightKnee", CFrame.Angles(v223 * -0.9 - v218 * 0.6, 0, 0))
		v215:setT("LeftHip", CFrame.Angles(v223 * 0.4, 0, v218 * -0.15))
		v215:setT("LeftKnee", CFrame.Angles(v223 * -0.7 - v218 * 0.1, 0, 0))
	elseif v219 == 1 then
		v215:setT("Root", CFrame.new(0, -v220 * v218, p213.scale * -0.9 * v218) * CFrame.Angles(v218 * -1.5, v218 * 0.2, v218 * -0.1))
		v215:setT("Waist", CFrame.Angles(v223 * 0.1, v218 * -0.15, 0))
		v215:setT("Neck", CFrame.Angles(v218 * 0.35, v218 * -1, 0))
		v_u_212(p213, "Right", v218 * 1.9, v218 * 0.8, v218 * 0.5)
		v_u_212(p213, "Left", v218 * 0.3, v218 * 0.4, v218 * 0.4)
		v215:setT("RightHip", CFrame.Angles(v223 * 0.6, 0, v218 * 0.12))
		v215:setT("RightKnee", CFrame.Angles(v223 * -1 - v218 * 0.3, 0, 0))
		v215:setT("LeftHip", CFrame.Angles(v223 * 0.5 - v218 * 0.1, 0, v218 * -0.1))
		v215:setT("LeftKnee", CFrame.Angles(v223 * -0.8, 0, 0))
	else
		v215:setT("Root", CFrame.new(p213.scale * 0.5 * v218, -v220 * v218, 0) * CFrame.Angles(v218 * 0.2, v218 * 0.3, v218 * -1.5))
		v215:setT("Waist", CFrame.Angles(v218 * 0.35, v218 * 0.2, v223 * 0.1))
		v215:setT("Neck", CFrame.Angles(v218 * 0.2, v218 * 0.3, v218 * -0.4))
		v_u_212(p213, "Right", v218 * 0.9, v218 * 1.1, v218 * 0.2)
		v_u_212(p213, "Left", v218 * 0.6, v218 * 0.7, v218 * 0.6)
		v215:setT("RightHip", CFrame.Angles(v218 * 0.9, 0, 0))
		v215:setT("RightKnee", CFrame.Angles(v218 * -1.3, 0, 0))
		v215:setT("LeftHip", CFrame.Angles(v218 * 0.5, 0, 0))
		v215:setT("LeftKnee", CFrame.Angles(v218 * -0.7, 0, 0))
	end
	if v217 >= 1 and p214 - p213.deadAt > 1.2 then
		p213.deadDone = true
	end
end
local function v_u_263(p225, p226, p227) -- name: poseDowned
	-- upvalues: (ref) v_u_8, (copy) v_u_212
	local v228 = p225.rig
	local v229 = v_u_8.easeOut((p227 - p225.downedAt) / 0.6)
	local v230 = p225.model:GetAttribute("RevivingBy")
	local v231 = ((type(v230) ~= "number" or v230 ~= v230) and 0 or v230) ~= 0
	p225.crawl = (p225.crawl + p225.speed * p226 / (p225.scale * 2.4)) % 1
	local v232 = p225.crawl * 2 * 3.141592653589793
	local v233 = v_u_8.remap(p225.speed, 0.3, 1.5)
	local v234 = p225.rootPivotY - (p225.groundY + (v231 and 0.9 or 0.44) * p225.scale)
	local v235 = math.sin(v232) * 0.12 * v233
	v228:setT("Root", CFrame.new(0, -v234 * v229, 0.2 * v229) * CFrame.Angles((v231 and -1.05 or -1.47) * v229, v235, v235 * 0.6))
	local v236 = p227 * 7.5
	local v237 = math.sin(v236) * 0.03
	local v238 = CFrame.Angles
	local v239 = -v235 * 1.2
	local v240 = v232 + 0.8
	v228:setT("Waist", v238(v237, v239, math.sin(v240) * 0.08 * v233))
	local v241 = CFrame.Angles
	local v242 = 0.8 * v229
	local v243 = p227 * 0.7
	v228:setT("Neck", v241(v242, math.sin(v243) * 0.15, 0))
	local v244 = 2.35 + math.sin(v232) * 0.45 * v233
	local v245 = v232 + 3.141592653589793
	local v246 = 2.35 + math.sin(v245) * 0.45 * v233
	if v231 then
		v244 = 1.2
		v246 = 1.1
	end
	local v247 = v_u_212
	local v248 = v244 * v229
	local v249 = -math.sin(v232)
	v247(p225, "Right", v248, (0.35 + math.max(0, v249) * 0.6 * v233) * v229, 0.35 * v229)
	local v250 = v_u_212
	local v251 = v246 * v229
	local v252 = math.sin(v232)
	v250(p225, "Left", v251, (0.35 + math.max(0, v252) * 0.6 * v233) * v229, 0.35 * v229)
	local v253 = CFrame.Angles
	local v254 = v232 + 3.141592653589793
	local v255 = math.sin(v254)
	v228:setT("RightHip", v253((0.1 + math.max(0, v255) * 0.45 * v233) * v229, 0, 0.12 * v229))
	local v256 = CFrame.Angles
	local v257 = v232 + 3.141592653589793
	local v258 = math.sin(v257)
	v228:setT("RightKnee", v256((-0.2 - math.max(0, v258) * 0.7 * v233) * v229, 0, 0))
	local v259 = CFrame.Angles
	local v260 = math.sin(v232)
	v228:setT("LeftHip", v259((0.05 + math.max(0, v260) * 0.45 * v233) * v229, 0, -0.12 * v229))
	local v261 = CFrame.Angles
	local v262 = math.sin(v232)
	v228:setT("LeftKnee", v261((-0.2 - math.max(0, v262) * 0.7 * v233) * v229, 0, 0))
	if v228.joints.LeftAnkle then
		v228:setT("LeftAnkle", CFrame.Angles(-0.6 * v229, 0, 0))
		v228:setT("RightAnkle", CFrame.Angles(-0.6 * v229, 0, 0))
	end
end
local function v_u_274(p264, p265, p266) -- name: gaitParams
	-- upvalues: (ref) v_u_8
	local v267 = p264.scale
	local v268
	if p265 <= 5.5 then
		v268 = 0.62
	elseif p265 <= 11 then
		v268 = v_u_8.lerp(0.62, 0.45, (p265 - 5.5) / 5.5)
	else
		local v269 = v_u_8.lerp
		local v270 = (p265 - 11) / 7
		v268 = v269(0.45, 0.34, (math.clamp(v270, 0, 1)))
	end
	local v271 = (p266 and 2.3 or 3) * v267
	local v272 = p265 * v268 / v271
	local v273 = math.max(p266 and 0.7 or 0.85, v272)
	return v268, v273, p265 * v268 / v273, (p266 and 0.22 or 0.26 + 0.5 * v_u_8.remap(p265, 4, 18)) * v267
end
local function v_u_287(p275, p276, p277, p278) -- name: footCycle
	-- upvalues: (ref) v_u_8
	if p275 < p276 then
		local v279 = p275 / p276
		local v280 = -v_u_8.remap(v279, 0.72, 1) * 0.35
		return p277 * 0.5 - v279 * p277, 0, v280, true
	end
	local v281 = (p275 - p276) / (1 - p276)
	local v282 = -p277 * 0.5 + v_u_8.smooth(v281) * p277
	local v283 = v281 * 1.08
	local v284 = 3.141592653589793 * math.min(1, v283)
	local v285 = p278 * math.sin(v284) ^ 0.85
	local v286
	if v281 < 0.35 then
		v286 = (1 - v281 / 0.35) * -0.45
	else
		v286 = 0.25 * v_u_8.remap(v281, 0.6, 1)
	end
	return v282, v285, v286, false
end
local function v_u_310(p288, p289) -- name: startKatanaVariant
	-- upvalues: (ref) v_u_10, (ref) v_u_5
	if v_u_10 == nil then
		return false
	end
	local v290 = p288.model:GetAttribute("Weapon")
	local v291
	if type(v290) == "string" and v290 ~= "" then
		local v_u_292 = "Weapons"
		local function v293()
			-- upvalues: (ref) v_u_5, (copy) v_u_292
			return v_u_5.shared[v_u_292]
		end
		local v294, v295 = pcall(v293)
		if not v294 then
			v295 = nil
		end
		if v295 and v295.get then
			local v296 = v295.get
			local v297
			v297, v291 = pcall(v296, v290)
			if not v297 then
				v291 = nil
			end
		else
			v291 = nil
		end
	else
		v291 = nil
	end
	local v298 = p288.model:FindFirstChild("HeldWeapon")
	local v299
	if v298 then
		v299 = v298:GetAttribute("MeleeStyle")
	else
		v299 = nil
	end
	local v300 = v299 or p288.model:GetAttribute("MeleeStyle")
	local v301 = v_u_10.styleOf
	if type(v290) ~= "string" then
		v290 = nil
	end
	if type(v300) ~= "string" then
		v300 = nil
	end
	local v302, v303 = pcall(v301, v290, v291, v300)
	if not v302 or (type(v303) ~= "string" or not v_u_10.hasVariant(v303, p289)) then
		return false
	end
	local v304
	if v291 and v291.meleeWindup then
		local v305 = v291.meleeWindup
		v304 = (type(v305) ~= "number" or v305 ~= v305) and 0.18 or v305
	else
		v304 = 0.18
	end
	local v306
	if v291 then
		local v307 = v291.meleeTime
		v306 = (type(v307) ~= "number" or v307 ~= v307) and 0.6 or v307
	else
		v306 = 0.6
	end
	local v308, v309 = v_u_10.variantTiming(v303, p289, v304, v306)
	p288.swingStart = os.clock()
	p288.swingDur = math.max(0.2, v309)
	p288.swingWindup = v308 / p288.swingDur
	p288.swingToss = false
	p288.swingVariant = p289
	return true
end
local function v_u_697(p311, p312, p313) -- name: poseStanding
	-- upvalues: (ref) v_u_5, (copy) v_u_13, (ref) v_u_12, (ref) v_u_8, (copy) v_u_274, (ref) v_u_15, (ref) v_u_14, (ref) v_u_9, (copy) v_u_287, (copy) v_u_175, (ref) v_u_17, (ref) v_u_16, (ref) v_u_10, (copy) v_u_310, (ref) v_u_7, (copy) v_u_56, (copy) v_u_204, (copy) v_u_212
	local v314 = p311.rig
	local v315 = p311.model
	local v316 = p311.scale
	local v317 = p311.isLocal and v_u_5.controllers.Input or nil
	local v318 = v315:GetAttribute("HoldType") or "none"
	local v319 = v315:GetAttribute("Weapon")
	if v318 == "none" or v318 == "" then
		local v320
		if type(v319) == "string" and v319 ~= "" then
			local v_u_321 = "Weapons"
			local function v322()
				-- upvalues: (ref) v_u_5, (copy) v_u_321
				return v_u_5.shared[v_u_321]
			end
			local v323, v324 = pcall(v322)
			if not v323 then
				v324 = nil
			end
			if v324 and v324.get then
				local v325 = v324.get
				local v326
				v326, v320 = pcall(v325, v319)
				if not v326 then
					v320 = nil
				end
			else
				v320 = nil
			end
		else
			v320 = nil
		end
		if v320 and (v320.holdType and v315:FindFirstChild("HeldWeapon")) then
			v318 = v320.holdType
		end
	end
	local v327 = v315:GetAttribute("Aiming") == true
	local v328 = v315:GetAttribute("Sneaking") == true
	if v317 then
		local v329 = v317.isAiming
		local v330, v331 = pcall(v329)
		local v332 = v317.isSneaking
		local v333, v334 = pcall(v332)
		if v330 then
			v327 = v331 == true
		end
		if v333 then
			if v334 == true then
				v328 = true
			else
				v328 = false
			end
		end
	end
	local v335 = v315:GetAttribute("Action") or ""
	local v336
	if p311.isLocal then
		v336 = v_u_13:GetAttribute("PredAction")
		local v337 = v_u_13:GetAttribute("PredActionEnds")
		if type(v336) == "string" and type(v337) == "number" then
			if os.clock() >= v337 then
				v336 = v335
			end
		else
			v336 = v335
		end
	else
		v336 = v335
	end
	local v338 = v315:GetAttribute("Fracture") == true
	local v339 = v315:GetAttribute("Stamina")
	p311.stamina = (type(v339) ~= "number" or v339 ~= v339) and 100 or v339
	local v340 = p311.root
	local v341 = v315:GetAttribute("AnimVelocity")
	if typeof(v341) ~= "Vector3" and v_u_12 ~= nil then
		v341 = v_u_12.vel(v315)
	end
	if typeof(v341) ~= "Vector3" then
		v341 = v340.AssemblyLinearVelocity
	end
	local v342 = v340.CFrame:VectorToObjectSpace(v341)
	local v343 = v342.X
	local v344 = v342.Z
	local v345 = Vector3.new(v343, 0, v344)
	p311.vel = v_u_8.dampV(p311.vel, v345, p311.isLocal and 18 or 10, p312)
	local v346 = (p311.vel - p311.prevVel) / math.max(p312, 0.004166666666666667)
	p311.prevVel = p311.vel
	p311.accel = v_u_8.dampV(p311.accel, v346, 6, p312)
	local v347 = p311.vel.Magnitude
	p311.speed = v347
	if v347 > 0.35 then
		p311.mdir = p311.vel.Unit
	end
	local v348
	if v347 > 13.5 then
		v348 = true
	elseif v315:GetAttribute("Sprinting") == true then
		v348 = v347 > 8
	else
		v348 = false
	end
	local v349 = v347 > 0.7
	p311.gw = v_u_8.damp(p311.gw, v349 and 1 or 0, v349 and 9 or 7, p312)
	p311.wAim = v_u_8.damp(p311.wAim, v327 and not v348 and 1 or 0, 14, p312)
	p311.wSprint = v_u_8.damp(p311.wSprint, v348 and not v327 and 1 or 0, 8, p312)
	p311.wSneak = v_u_8.damp(p311.wSneak, (v328 or v315:GetAttribute("Laser") == true) and (not v348 and (v318 == "pistol" or (v318 == "rifle" or v318 == "shotgun"))) and 1 or 0, 10, p312)
	p311.wFall = v_u_8.damp(p311.wFall, v342.Y < -12 and 1 or 0, 8, p312)
	local v350 = v340.CFrame.LookVector
	local v351 = -v350.X
	local v352 = -v350.Z
	local v353 = math.atan2(v351, v352)
	local v354 = v_u_8.angleWrap(v353 - p311.prevYaw) / math.max(p312, 0.004166666666666667)
	p311.prevYaw = v353
	p311.yawRate = v_u_8.damp(p311.yawRate, math.clamp(v354, -12, 12), 10, p312)
	local v355 = v315:GetAttribute("AimYaw")
	if type(v355) ~= "number" or v355 ~= v355 then
		v355 = v353
	end
	local v356
	if v317 then
		local v357 = v317.aimYaw
		local v358
		v358, v356 = pcall(v357)
		if v358 then
			if type(v356) ~= "number" then
				v356 = v355
			end
		else
			v356 = v355
		end
	else
		v356 = v355
	end
	local v359 = v_u_8.damp
	local v360 = p311.lead
	local v361 = v_u_8.angleWrap(v356 - v353)
	p311.lead = v359(v360, math.clamp(v361, -0.75, 0.75), 16, p312)
	local v362 = 0
	local v363 = v315:GetAttribute("AimPitch")
	if type(v363) == "number" then
		if v363 ~= v363 then
			v363 = v362
		end
	else
		v363 = v362
	end
	local v364
	if v317 and (v_u_13 and v_u_13:GetAttribute("ViewMode") == "fptp") then
		local v365 = v317.aimPitch
		local v366
		v366, v364 = pcall(v365)
		if v366 and type(v364) == "number" then
			if v364 ~= v364 then
				v364 = v363
			end
		else
			v364 = v363
		end
	else
		v364 = v363
	end
	if v364 == 0 then
		local v367 = p311.aimPitch
		if math.abs(v367) < 0.0001 then
			p311.aimPitch = 0
		elseif v364 ~= 0 or p311.aimPitch ~= 0 then
			p311.aimPitch = v_u_8.damp(p311.aimPitch, math.clamp(v364, -1.45, 1.45), 14, p312)
		end
	elseif v364 ~= 0 or p311.aimPitch ~= 0 then
		p311.aimPitch = v_u_8.damp(p311.aimPitch, math.clamp(v364, -1.45, 1.45), 14, p312)
	end
	local v368, v369, v370, v371 = v_u_274(p311, v347, v328)
	if v338 then
		v369 = v369 * 0.85
		v371 = v371 * 0.6
	end
	local v372 = p311.phase
	local v373 = v369 * p312
	local v374 = p311.gw * 1.5
	p311.phase = (v372 + v373 * math.clamp(v374, 0, 1)) % 1
	local v375 = p311.mdir
	local v376 = -v375.X
	local v377 = -v375.Z
	local v378 = math.atan2(v376, v377)
	local v379
	if math.abs(v378) <= 1.75 then
		v379 = v378 * 0.5
	else
		v379 = v_u_8.angleWrap(v378 - 3.141592653589793) * 0.5
	end
	local v380 = math.clamp(v379, -0.75, 0.75) * p311.gw
	local v381 = v318 == "rifle" and true or v318 == "shotgun"
	local v382 = os.clock()
	if v382 - v_u_15 > 1 then
		v_u_15 = v382
		local v383 = v_u_5.config.flag
		local v384, v385 = pcall(v383, "NewAnims")
		v_u_14 = not v384 or v385 ~= false
	end
	local v386 = v_u_14
	if v386 then
		v386 = v_u_9 ~= nil
	end
	local v387, v388
	if v386 and v381 then
		local v389 = v_u_9.stance
		local v390
		if type(v319) == "string" then
			v390 = v319
		else
			v390 = nil
		end
		local v391
		if type(v319) == "string" and v319 ~= "" then
			local v_u_392 = "Weapons"
			local function v393()
				-- upvalues: (ref) v_u_5, (copy) v_u_392
				return v_u_5.shared[v_u_392]
			end
			local v394, v395 = pcall(v393)
			if not v394 then
				v395 = nil
			end
			if v395 and v395.get then
				local v396 = v395.get
				local v397
				v397, v391 = pcall(v396, v319)
				if not v397 then
					v391 = nil
				end
			else
				v391 = nil
			end
		else
			v391 = nil
		end
		v387, v388 = v389(v390, v391)
	else
		v388 = -0.18
		v387 = -0.42
	end
	local v398
	if v386 then
		local v399 = p311.wAim
		local v400 = p311.wSneak
		v398 = math.max(v399, v400)
	else
		v398 = p311.wAim
	end
	local v401 = not v381 and 0 or v387 * v398 + v388 * (1 - v398) * (1 - p311.wSprint)
	p311.stance = v_u_8.damp(p311.stance, v401, 10, p312)
	p311.hipYaw = v_u_8.damp(p311.hipYaw, v380, 8, p312)
	local v402 = p311.stance * 0.5 * (1 - p311.gw * 0.6)
	local v403 = v402 + p311.stance * 0.5
	local v404 = p311.hipYaw + v402
	local v405 = v336 == "Search" and 1 or (v336 == "Revive" and 1.45 or (v328 and 0.55 or ((v336 == "Bandage" or v336 == "Use") and 0.12 or ((v336 == "Climb" or v336 == "Vault") and 0.4 or (v336 == "Unlock" and 0.08 or (p311.wAim > 0.5 and (v318 == "rifle" or v318 == "shotgun") and 0.12 or 0))))))
	p311.crouch = v_u_8.damp(p311.crouch, v405 * v316, 7, p312)
	if v336 == "" then
		p311.actionT = 0
	else
		p311.actionT = p311.actionT + p312
	end
	local v406 = CFrame.Angles(0, v404, 0)
	local v407 = p311.mdir
	local v408 = 0
	local v409 = {}
	for _, v410 in { "L", "R" } do
		local v411 = p311.feet[v410]
		local v412
		if v410 == "L" then
			v412 = p311.ankleL
		else
			v412 = p311.ankleR
		end
		local _ = v410 == "L"
		local v413 = (p311.wAim <= 0 or v318 ~= "rifle" and v318 ~= "shotgun") and 0 or (v410 == "L" and -0.45 or 0.3) * p311.wAim * v316
		local v414 = 1 + 0.25 * v_u_8.remap(p311.crouch, 0, 1.4)
		local v415 = v412.X * v414
		local v416 = v412.Y
		local v417 = v412.Z + v413
		local v418 = v406 * Vector3.new(v415, v416, v417)
		if v336 == "Revive" then
			local v419 = v412.X * 1.1
			local v420 = v412.Y
			local v421 = v412.Z + (v410 == "L" and -0.8 or 0.55) * v316
			v418 = Vector3.new(v419, v420, v421)
		end
		local v422
		if v410 == "L" then
			v422 = p311.phase
		else
			v422 = (p311.phase + 0.5) % 1
		end
		local v423, v424, v425, v426 = v_u_287(v422, v368, v370, v371)
		local v427 = v418 + v407 * v423 + Vector3.new(0, v424, 0)
		local v428
		if p311.gw < 0.5 then
			if not v411.plant then
				local v429 = v340.CFrame
				local v430 = v411.target.X
				local v431 = v412.Y
				local v432 = v411.target.Z
				v411.plant = v429:PointToWorldSpace((Vector3.new(v430, v431, v432)))
			end
			local v433 = v340.CFrame:PointToObjectSpace(v411.plant)
			local v434 = v433.X
			local v435 = v412.Y
			local v436 = v433.Z
			v428 = Vector3.new(v434, v435, v436)
			if v411.stepping then
				v411.stepT = v411.stepT + p312 / 0.24
				local v437 = v411.stepT
				local v438 = math.clamp(v437, 0, 1)
				local v439 = v_u_8.smooth(v438)
				local v440 = v411.stepFrom:Lerp(v411.stepTo, v439)
				local v441 = v316 * 0.3
				local v442 = 3.141592653589793 * v438
				local v443 = v441 * math.sin(v442)
				v428 = v440 + Vector3.new(0, v443, 0)
				if v438 >= 1 then
					v411.stepping = false
					v411.plant = v340.CFrame:PointToWorldSpace(v411.stepTo)
					v_u_175(p311, v411.stepTo, 0.25)
				end
			elseif (v428 - v418).Magnitude > v316 * 0.62 and p311.idleStepCooldown <= 0 and not p311.feet[v410 == "L" and "R" or "L"].stepping then
				v411.stepping = true
				v411.stepT = 0
				v411.stepFrom = v428
				v411.stepTo = v418
				p311.idleStepCooldown = 0.12
			end
		else
			v411.plant = nil
			v411.stepping = false
			v428 = v427
		end
		local v444 = v428:Lerp(v427, p311.gw)
		v411.target = v444
		if v426 and (not v411.inStance and (p311.gw > 0.45 and v347 > 1.2)) then
			v_u_175(p311, v444, v_u_8.remap(v347, 2, 18) * (v328 and 0.35 or 1))
		end
		v411.inStance = v426
		local v445 = v314:bindPivot(v410 == "L" and "LeftHip" or "RightHip").Position
		local v446 = v444.X - v445.X
		local v447 = v444.Z - v445.Z
		local v448 = Vector3.new(v446, 0, v447).Magnitude
		local v449 = v445.Y - v412.Y
		if v448 < v449 then
			local v450 = v449 * v449 - v448 * v448
			local v451 = v449 - math.sqrt(v450)
			if v426 or p311.gw < 0.5 then
				local v452 = v451 * 0.92
				v408 = math.max(v408, v452)
			end
		end
		v409[v410] = {
			["target"] = v444,
			["toe"] = v425 * p311.gw,
			["stance"] = v426
		}
	end
	local v453 = p311.idleStepCooldown - p312
	p311.idleStepCooldown = math.max(0, v453)
	local v454 = v316 * 0.07 * v_u_8.remap(v347, 4, 18)
	local v455 = 12.566370614359172 * p311.phase
	local v456 = v454 * (math.cos(v455) * 0.5 + 0.5) * p311.gw
	local v457 = p311.breath
	local v458 = math.sin(v457) * 0.012 * v316
	p311.drop = v_u_8.damp(p311.drop, v408, 20, p312)
	local v459 = 6.283185307179586 * p311.phase
	local v460 = math.sin(v459) * 0.07 * v316 * p311.gw * (1 - p311.wSprint * 0.5)
	local v461 = p311.wFall * 0.25 * v316
	local v462 = -(p311.drop + p311.crouch + v456 + v461) + v458 * 0.3
	local v463 = 6.283185307179586 * p311.phase
	local v464 = -math.sin(v463) * 0.05 * p311.gw
	if v338 and (p311.phase + 0.5) % 1 < v368 then
		v462 = v462 - v316 * 0.12 * p311.gw
		v464 = v464 + p311.gw * 0.08
	end
	v314:setT("Root", CFrame.new(v460, v462, 0) * CFrame.Angles(0, v404, v464))
	for _, v465 in { "L", "R" } do
		local v466 = v409[v465]
		local v467 = v465 == "L" and "Left" or "Right"
		local v468 = v465 == "L" and -0.12 or 0.12
		local v469 = v468 + (p311.crouch <= 0.3 and 0 or v468 * 1.5)
		local v470 = v406 * Vector3.new(v469, 0, -1)
		if not v314.joints[v467 .. "Ankle"] then
			continue
		end
		v314:solve2(v467 .. "Hip", v467 .. "Knee", v467 .. "Ankle", v466.target, v470, Vector3.new(0, 0, -1))
		local v471 = v466.toe
		local v472 = v336 == "Revive" and v465 == "R" and 0.9 or v471
		v314:orientEnd(v467 .. "Ankle", CFrame.Angles(0, v404, 0) * CFrame.Angles(v472, 0, 0) * v314.bind[v314.joints[v467 .. "Ankle"].child].Rotation)
	end
	p311.breath = p311.breath + p312 * ((1 - p311.stamina / 100) * 3.2 + 1.6 + p311.gw * 1.2)
	local v473 = (1 - p311.stamina / 100) * 0.03 + 0.012
	local v474 = (0.07 * v_u_8.remap(v347, 2, 11) + p311.wSprint * 0.14) * (1 - p311.wAim * 0.7) + (0.22 * v_u_8.remap(p311.crouch, 0, v316 * 0.6) + (v336 == "Search" and 0.35 or (v336 == "Revive" and 0.25 or 0)))
	local v475 = -p311.accel.Z * 0.006
	local v476 = math.clamp(v475, -0.12, 0.14)
	local v477 = -p311.yawRate * 0.02 * v_u_8.remap(v347, 2, 12)
	local v478 = math.clamp(v477, -0.12, 0.12)
	local v479 = p311.accel.X * 0.004
	local v480 = math.clamp(v479, -0.08, 0.08)
	local v481 = 6.283185307179586 * p311.phase
	local v482 = math.sin(v481) * 0.07 * p311.gw * (1 - p311.wAim)
	p311.kick = v_u_8.damp(p311.kick, 0, 9, p312)
	p311.flinch = v_u_8.damp(p311.flinch, 0, 6, p312)
	local v483 = type(v319) ~= "string" and "" or v319
	if p311.lastWid ~= v483 then
		local v484 = p311.lastWid
		p311.lastWid = v483
		local v_u_485 = "KatanaAnimRules"
		local function v486()
			-- upvalues: (ref) v_u_5, (copy) v_u_485
			return v_u_5.shared[v_u_485]
		end
		local v487, v488 = pcall(v486)
		if not v487 then
			v488 = nil
		end
		if v488 ~= nil and (v488.carries(v483) and (v318 == "melee1h" or v318 == "melee2h")) then
			if p311.katana ~= nil then
				v488.reset(p311.katana)
			end
			if v484 ~= false then
				local v489 = os.clock()
				if v489 - v_u_17 > 1 then
					v_u_17 = v489
					local v490 = v_u_5.config.flag
					local v491, v492 = pcall(v490, "KatanaAnim")
					v_u_16 = not v491 or v492 ~= false
				end
				local v493 = v_u_16
				if v493 then
					v493 = v_u_10 ~= nil
				end
				if v493 then
					v_u_310(p311, "draw")
				end
			end
		end
	end
	local v494 = (os.clock() - p311.swingStart) / p311.swingDur
	local v495
	if v494 >= 0 and v494 < 1 then
		v495 = v318 == "melee1h" and true or v318 == "melee2h"
	else
		v495 = false
	end
	local v496 = (os.clock() - p311.bashStart) / v_u_7.STRIKE_DUR
	local v497
	if v496 >= 0 then
		v497 = v496 < 1
	else
		v497 = false
	end
	local v498 = 0
	local v499 = 0
	local v500 = nil
	local v501 = nil
	if v495 and v386 then
		local v502
		if type(v319) == "string" and v319 ~= "" then
			local v_u_503 = "Weapons"
			local function v504()
				-- upvalues: (ref) v_u_5, (copy) v_u_503
				return v_u_5.shared[v_u_503]
			end
			local v505, v506 = pcall(v504)
			if not v505 then
				v506 = nil
			end
			if v506 and v506.get then
				local v507 = v506.get
				local v508
				v508, v502 = pcall(v507, v319)
				if not v508 then
					v502 = nil
				end
			else
				v502 = nil
			end
		else
			v502 = nil
		end
		local v509 = v315:FindFirstChild("HeldWeapon")
		local v510
		if v509 then
			v510 = v509:GetAttribute("MeleeStyle")
		else
			v510 = nil
		end
		local v511 = v510 or v315:GetAttribute("MeleeStyle")
		local v512 = v_u_10.styleOf
		local v513
		if type(v319) == "string" then
			v513 = v319
		else
			v513 = nil
		end
		if type(v511) ~= "string" then
			v511 = nil
		end
		local v514 = v512(v513, v502, v511)
		local v515 = ((v314.bone.RightShoulder or 0.92) + (v314.bone.RightElbow or 0.8)) / 1.727
		v501 = v_u_10.sample(v514, os.clock() - p311.swingStart, p311.swingWindup * p311.swingDur, p311.swingDur, v515, {
			["toss"] = p311.swingToss,
			["variant"] = p311.swingVariant
		})
		v498 = v501.torsoYaw
		v499 = v501.torsoPitch
	elseif v495 then
		v500, v498 = v_u_7.swing(v318, v494, p311.swingWindup, p311.shR)
	end
	local v516
	if v501 == nil then
		v516 = nil
	else
		v516 = v501.flash
	end
	local v517
	if type(v516) == "number" then
		v517 = v516 > 0.001
	else
		v517 = false
	end
	if v517 or p311.flashOn == true then
		local function v518()
			-- upvalues: (ref) v_u_5
			return v_u_5.lib.KatanaFlash
		end
		local v519, v520 = pcall(v518)
		local v521 = v315:FindFirstChild("HeldWeapon")
		if v519 and (type(v520) == "table" and v521 ~= nil) then
			v520.set(v521, not v517 and 0 or v516)
		end
		p311.flashOn = v517
	end
	if v_u_9 and v_u_9.tossGuard then
		v_u_9.tossGuard(p311, v501)
	end
	local v522 = (v318 == "pistol" or v318 == "rifle") and true or v318 == "shotgun"
	local v523 = not v522
	if v523 then
		if v318 == "melee1h" then
			v523 = false
		else
			v523 = v318 ~= "melee2h"
		end
	end
	local v524 = p311.punchN % 2 == 1 and 1 or -1
	if p311.reach <= 0 and (v314.joints.RightWrist and v314.joints.RightShoulder) then
		p311.reach = (v314:bindPivot("RightShoulder").Position - v314:bindPivot("RightWrist").Position).Magnitude
	end
	local v525
	if p311.reach > 0 then
		v525 = p311.reach
	else
		v525 = v316 * 1.6
	end
	local v526 = nil
	local v527 = nil
	if v497 and v523 then
		local v528
		if v524 > 0 then
			v528 = p311.shR
		else
			v528 = p311.shL
		end
		local v529
		if v524 > 0 then
			v529 = p311.shL
		else
			v529 = p311.shR
		end
		local v530
		v526, v527, v530 = v_u_7.punch(v496, v528, v529, v525, v316, v524)
		v498 = v498 + v530
	elseif v497 and v522 then
		if v386 then
			local v531 = v_u_10.bashSample
			local v532 = v496 * v_u_10.BASH_DUR
			local v533 = 1
			local v_u_534 = "Weapons"
			local function v535()
				-- upvalues: (ref) v_u_5, (copy) v_u_534
				return v_u_5.shared[v_u_534]
			end
			local v536, v537 = pcall(v535)
			if not v536 then
				v537 = nil
			end
			local v538 = v531(v318, v532, v533, v537)
			v498 = v498 + v538.torsoYaw
			v499 = v499 + v538.torsoPitch
		else
			local _, v539 = v_u_7.bash(v496, p311.shR, CFrame.identity, v318)
			v498 = v498 + v539
		end
	end
	local v540 = not (v386 and (v_u_9 and v_u_9.heavy)) and 0 or v_u_9.heavy(p311)
	local v541 = 6.283185307179586 * (p311.phase - 0.25)
	local v542 = v540 * math.sin(v541) * 0.05 * p311.gw
	local v543 = v540 * p311.gw
	local v544 = 12.566370614359172 * p311.phase
	local v545 = v543 * (math.sin(v544) * 0.015 + 0.03)
	local v546 = -(v474 + v476) - v499
	local v547 = p311.breath
	local v548 = v546 + math.sin(v547) * v473 + p311.kick * 0.06 * p311.kickScale + p311.flinch * 0.22 - v545
	local v549
	if p311.aimPitch == 0 or not (v_u_9 and v_u_9.pitchSplit) then
		v549 = 0
	else
		local v550 = v_u_9.pitchSplit
		local v551 = p311.aimPitch
		local v552
		if v522 then
			local v553 = p311.wAim
			local v554 = p311.wSneak
			v552 = math.max(v553, v554)
		else
			v552 = 0
		end
		local v555, v556 = v550(v551, v552)
		v548 = v548 + v555
		v549 = v556 + 0.55 * v555
	end
	local v557 = -(v404 - v402) * 0.85 + p311.stance * 0.5 + p311.lead * 0.75 + v482 + v498 + p311.flinch * p311.flinchYaw * 0.2
	local v558 = v478 + v480 + v464 * -0.6 + v542
	v314:setT("Waist", CFrame.Angles(v548, v557, v558))
	local v559 = (v336 == "Bandage" or v336 == "Use") and 0.45 or ((v336 == "Search" or v336 == "Revive") and 0.35 or ((v336 == "Unlock" or (v336 == "Climb" or v336 == "Vault")) and 0.25 or 0))
	local v560 = CFrame.Angles
	local v561 = -v548 * 0.55 - v559 + v549
	local v562 = p313 * 0.37 + p311.seed
	local v563 = v561 + math.sin(v562) * 0.02
	local v564 = p311.lead * 0.25 - v498 * 0.4
	local v565 = p313 * 0.23 + p311.seed
	v314:setT("Neck", v560(v563, v564 + math.sin(v565) * 0.05 * (1 - p311.gw), -v558 * 0.5))
	local v566 = v314.joints.Waist and (v314.joints.Waist.child or "UpperTorso") or "UpperTorso"
	local v567 = v314.part[v566] * v314.bind[v566]:Inverse()
	local v568
	if v318 == "none" or v318 == "" then
		v568 = false
	else
		v568 = (v318 == "pistol" or (v318 == "rifle" or (v318 == "shotgun" or v318 == "melee1h"))) and true or v318 == "melee2h"
	end
	p311.keyAction = v336 == "Unlock"
	p311.keyHand = v568 and "Left" or "Right"
	local v569 = (v336 == "Bandage" or (v336 == "Use" or (v336 == "Search" or (v336 == "Revive" or (v336 == "Unlock" or v336 == "Climb"))))) and true or v336 == "Vault"
	local v570
	if v569 then
		local v571 = p311.actionT
		if v336 == "Vault" then
			v570 = v_u_7.doorHands("Climb", v567, p311.shR, v316, v571 * 1.25, v568)
		elseif v336 == "Unlock" or v336 == "Climb" then
			v570 = v_u_7.doorHands(v336, v567, p311.shR, v316, v571, v568)
		elseif v336 == "Bandage" or v336 == "Use" then
			local v572 = p311.shR.Y - v316 * 1.45
			local v573 = v316 * -0.75
			local v574 = Vector3.new(0, v572, v573)
			local v575 = v571 * 9
			local v576 = math.cos(v575) * 0.12
			local v577 = v571 * 9
			local v578 = math.sin(v577) * 0.07
			local v579 = Vector3.new(v576, v578, 0) * v316
			v570 = {}
			local v580 = v316 * 0.12
			local v581 = v567 * (v574 + Vector3.new(v580, 0, 0) + v579)
			local v582 = v316 * -0.12
			__set_list(v570, 1, {v581, v567 * (v574 + Vector3.new(v582, 0, 0) - v579)})
		elseif v336 == "Search" then
			local v583 = p311.groundY + 1.35 * v316
			v570 = {}
			local v584 = v316 * 0.35
			local v585 = v571 * 6
			local v586 = v583 + math.sin(v585) * 0.15
			local v587 = -1.25 * v316
			local v588 = v571 * 6
			local v589 = v587 + math.cos(v588) * 0.2
			local v590 = Vector3.new(v584, v586, v589)
			local v591 = -0.35 * v316
			local v592 = v571 * 6 + 2
			local v593 = v583 + math.sin(v592) * 0.15
			local v594 = -1.25 * v316
			local v595 = v571 * 6 + 2
			local v596 = v594 + math.cos(v595) * 0.2
			__set_list(v570, 1, {v590, (Vector3.new(v591, v593, v596))})
		else
			local v597 = p311.groundY + 1.05 * v316
			local v598 = v571 * 5
			local v599 = math.sin(v598) * 0.12 * v316
			v570 = {}
			local v600 = v316 * 0.3
			local v601 = v316 * -1.45 + v599
			local v602 = Vector3.new(v600, v597, v601)
			local v603 = -0.3 * v316
			local v604 = v316 * -1.45 + v599
			__set_list(v570, 1, {v602, (Vector3.new(v603, v597, v604))})
		end
	else
		v570 = nil
	end
	local v605 = v315:FindFirstChild("HeldWeapon")
	if v605 ~= nil and (p311.weapon == nil or p311.weapon.model ~= v605) then
		p311.weaponCheck = 0
	end
	if p311.weaponCheck <= 0 then
		p311.weaponCheck = 0.3
		p311.weapon = v_u_56(p311)
	else
		p311.weaponCheck = p311.weaponCheck - p312
	end
	local v606 = nil
	if v568 and (v386 and (v318 == "melee1h" and not (v495 or v497))) then
		local v_u_607 = "KatanaAnimRules"
		local function v608()
			-- upvalues: (ref) v_u_5, (copy) v_u_607
			return v_u_5.shared[v_u_607]
		end
		local v609, v610 = pcall(v608)
		if not v609 then
			v610 = nil
		end
		if v610 ~= nil and v610.carries(v319) then
			local v611 = os.clock()
			if v611 - v_u_17 > 1 then
				v_u_17 = v611
				local v612 = v_u_5.config.flag
				local v613, v614 = pcall(v612, "KatanaAnim")
				v_u_16 = not v613 or v614 ~= false
			end
			local v615 = v_u_16
			if v615 then
				v615 = v_u_10 ~= nil
			end
			if v615 and v_u_10.idle ~= nil then
				v606 = v_u_10.idle("katana", os.clock(), v347)
			end
		end
	end
	if v568 and v386 then
		local v616 = v_u_9.armed
		local v617 = {
			["sway"] = v606,
			["st"] = p311,
			["holdType"] = v318
		}
		local v618
		if type(v319) == "string" and v319 ~= "" then
			local v_u_619 = "Weapons"
			local function v620()
				-- upvalues: (ref) v_u_5, (copy) v_u_619
				return v_u_5.shared[v_u_619]
			end
			local v621, v622 = pcall(v620)
			if not v621 then
				v622 = nil
			end
			if v622 and v622.get then
				local v623 = v622.get
				local v624
				v624, v618 = pcall(v623, v319)
				if not v624 then
					v618 = nil
				end
			else
				v618 = nil
			end
		else
			v618 = nil
		end
		v617.def = v618
		if type(v319) ~= "string" then
			v319 = nil
		end
		v617.wid = v319
		v617.chest = v567
		v617.stanceChest = v403
		local v625 = -v456 * 0.4
		local v626 = 12.566370614359172 * p311.phase
		v617.bobY = v625 + math.sin(v626) * 0.03 * v316 * p311.gw
		v617.busyAction = v569
		v617.handsAction = v570
		v617.swing = v501
		v617.swingDur = p311.swingDur
		v617.bashing = v497 and v522
		v617.bashU = v496
		v617.gunHold = v522
		v617.now = os.clock()
		v617.aimPitch = p311.aimPitch
		v616(v617)
	elseif v568 then
		local v627 = p311.wAim > 0.5 and "aim" or (p311.wSprint > 0.5 and "sprint" or "ready")
		local v628 = v_u_7.grip(v318, "ready", p311.shR)
		if p311.wSneak > 0.001 and v_u_7.hasPose(v318, "sneak") then
			v628 = v628:Lerp(v_u_7.grip(v318, "sneak", p311.shR), p311.wSneak)
		end
		local v629 = v628:Lerp(v_u_7.grip(v318, "aim", p311.shR), p311.wAim):Lerp(v_u_7.grip(v318, "sprint", p311.shR), p311.wSprint)
		if v569 then
			v629 = v628 * CFrame.new(0, -0.1, 0.1) * CFrame.Angles(-0.35, 0, 0)
		end
		if v500 then
			v629 = v500
		elseif v497 then
			v629 = v_u_7.bash(v496, p311.shR, v629, v318)
		end
		local v630 = v316 - 1
		if math.abs(v630) > 0.02 then
			v629 = CFrame.new(p311.shR + (v629.Position - p311.shR) * v316) * v629.Rotation
		end
		local v631 = -v456 * 0.4
		local v632 = 12.566370614359172 * p311.phase
		local v633 = v631 + math.sin(v632) * 0.03 * v316 * p311.gw
		local v634 = CFrame.Angles(0, -v403, 0) * v567 * CFrame.new(0, v633, 0) * v629
		local v635
		if v522 then
			local v636 = p311.wAim
			local v637 = p311.wSneak
			v635 = math.max(v636, v637)
		else
			v635 = 0
		end
		if v635 > 0 and not v500 then
			local v638 = v634.LookVector
			local v639 = v638.X
			local v640 = v638.Z
			local v641 = Vector3.new(v639, 0, v640)
			if v641.Magnitude > 0.2 then
				v634 = v634:Lerp(CFrame.lookAt(v634.Position, v634.Position + v641.Unit), v635 * 0.85)
			end
		end
		if p311.kick > 0.001 then
			local v642 = p311.kick * p311.kickScale
			v634 = v634 * CFrame.new(v642 * 0.02, v642 * 0.05, 0.26 * v642) * CFrame.Angles(0.19198621771937624 * v642, 0.03490658503988659 * v642, 0)
		end
		if p311.aimPitch ~= 0 and (v522 and (not v500 and (v_u_9 and v_u_9.pitchSplit))) then
			local _, _, v643 = v_u_9.pitchSplit(p311.aimPitch, v635)
			v634 = v_u_9.pitchGrip(v634, CFrame.Angles(0, -v403, 0) * v567 * CFrame.new(0, v633, 0) * p311.shR, v643)
		end
		local v644 = (v318 == "pistol" or v318 == "rifle") and true or v318 == "shotgun"
		local v645
		if p311.reloading and (v644 and not v569) then
			local v646 = os.clock() - p311.reloadStart
			local v647
			if p311.reloadSingle > 0 then
				v647 = v646 % p311.reloadSingle / p311.reloadSingle
			else
				local v648 = p311.reloadDur
				local v649 = v646 / math.max(v648, 0.2)
				v647 = math.clamp(v649, 0, 1)
			end
			local v650
			if p311.reloadSingle > 0 then
				v650 = 0.8
			else
				local v651 = v647 * 1.15
				local v652 = 3.141592653589793 * math.clamp(v651, 0, 1)
				v650 = math.sin(v652)
			end
			v634 = v634 * CFrame.new(0, v650 * -0.18 * v316, 0.2 * v650 * v316) * CFrame.Angles(-0.28 * v650, v650 * 0.25, v650 * 0.55)
			local v653 = CFrame.new
			local v654 = 0
			local v655 = -0.5 * v316
			local v656
			if v318 == "pistol" then
				v656 = 0.1 * v316
			else
				v656 = -0.35 * v316
			end
			v645 = (v634 * v653(v654, v655, v656)).Position
			local v657 = -0.5 * v316
			local v658 = p311.rootPivotY + 0.2 * v316
			local v659 = -0.5 * v316
			local v660 = v567 * Vector3.new(v657, v658, v659)
			if p311.reloadSingle > 0 then
				local v661 = (v634 * CFrame.new(-0.15 * v316, 0.05, -0.55 * v316)).Position
				if v647 < 0.5 then
					v645 = v660:Lerp(v661, v_u_8.smooth(v647 * 2))
				else
					v645 = v661:Lerp(v660, v_u_8.smooth((v647 - 0.5) * 2))
				end
			else
				local v662 = v_u_7.support(v318) or CFrame.new()
				local v663 = (v634 * CFrame.new(v662.Position * v316)).Position
				if v647 < 0.2 then
					v645 = v663:Lerp(v645, v_u_8.smooth(v647 / 0.2))
				elseif v647 < 0.45 then
					v645 = v645:Lerp(v660, v_u_8.smooth((v647 - 0.2) / 0.25))
				elseif v647 < 0.7 then
					v645 = v660:Lerp(v645, v_u_8.smooth((v647 - 0.45) / 0.25))
				elseif v647 >= 0.85 then
					v645 = v645:Lerp(v663, v_u_8.smooth((v647 - 0.85) / 0.15))
				end
			end
		else
			v645 = nil
		end
		if v569 and v570 then
			v645 = v570[2]
		end
		local v664 = v_u_7.twoHanded(v318, v627) and not v500 or v318 == "melee2h"
		v_u_204(p311, v634, v318, v664, v645, p311.wAim > 0.5 and v318 ~= "pistol" and 0.35 or 0)
		if not (v664 or v645) then
			local v665 = 6.283185307179586 * ((p311.phase + 0.5) % 1)
			local v666 = math.sin(v665) * (p311.wSprint * 0.6 + 0.3) * p311.gw
			v_u_212(p311, "Left", v666 + 0.1, p311.wSprint * 1 + 0.25 + 0.2 * math.max(0, v666), 0.12)
			return
		end
	else
		if v570 then
			local v667 = v570[1]
			p311.rig:solve2("RightShoulder", "RightElbow", "RightWrist", v667, Vector3.new(0.6, -1, 0.3), Vector3.new(0, 0, 1))
			local v668 = v570[2]
			p311.rig:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v668, Vector3.new(-0.6, -1, 0.3), Vector3.new(0, 0, 1))
			return
		end
		if v523 and (v526 or os.clock() < p311.guardUntil + 0.35) and (v314.joints.RightWrist and v314.joints.LeftWrist) then
			local v669
			if v526 and v527 then
				if v524 > 0 then
					v669 = v526
				else
					v669 = v527
				end
				if v524 > 0 then
					v526 = v527
				end
			else
				local v670 = (p311.guardUntil + 0.35 - os.clock()) / 0.35
				local v671 = math.clamp(v670, 0, 1)
				local v672 = v671 * v671 * (3 - v671 * 2)
				local v673 = p311.shR
				local v674 = v316 * 0.05
				local v675 = -v525 * 0.96
				local v676 = 0.1 * v316
				local v677 = v673 + Vector3.new(v674, v675, v676)
				local v678 = p311.shL
				local v679 = -0.05 * v316
				local v680 = -v525 * 0.96
				local v681 = 0.1 * v316
				local v682 = v678 + Vector3.new(v679, v680, v681)
				v669 = v677:Lerp(v_u_7.guard(p311.shR, 1, v316), v672)
				v526 = v682:Lerp(v_u_7.guard(p311.shL, -1, v316), v672)
			end
			local v683 = v567 * v669
			p311.rig:solve2("RightShoulder", "RightElbow", "RightWrist", v683, Vector3.new(0.55, -1, 0.25), Vector3.new(0, 0, 1))
			local v684 = v567 * v526
			p311.rig:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v684, Vector3.new(-0.55, -1, 0.25), Vector3.new(0, 0, 1))
			return
		end
		local v685 = (0.28 + p311.wSprint * 0.75 - 0.12 * v_u_8.remap(p311.crouch, 0, 0.6)) * p311.gw
		local v686 = 6.283185307179586 * p311.phase
		local v687 = math.sin(v686) * v685
		local v688 = -v687
		local v689 = 0.16 + 1.15 * p311.wSprint + 0.3 * v_u_8.remap(p311.crouch, 0, 0.6)
		local v690 = p311.wFall * 0.6
		local v691 = v_u_212
		local v692 = v687 + 0.03 + v690 * 0.3
		local v693 = p311.breath
		v691(p311, "Right", v692 + math.sin(v693) * 0.02, v689 + math.max(0, v687) * 0.35, 0.1 + v690)
		local v694 = v_u_212
		local v695 = v688 + 0.03 + v690 * 0.3
		local v696 = p311.breath
		v694(p311, "Left", v695 + math.sin(v696) * 0.02, v689 + math.max(0, v688) * 0.35, 0.1 + v690)
	end
end
local v_u_698 = {
	"RightShoulder",
	"RightElbow",
	"RightWrist",
	"LeftShoulder",
	"LeftElbow",
	"LeftWrist",
	"RightHip",
	"RightKnee",
	"RightAnkle"
}
local function v_u_746(p699) -- name: takedownPass
	-- upvalues: (ref) v_u_5, (ref) v_u_17, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11, (copy) v_u_698
	local v700 = p699.model
	local v701 = v700:GetAttribute("TakedownAt")
	if type(v701) == "number" then
		local v702 = nil
		local v703 = v700:GetAttribute("TakedownWeapon")
		if type(v703) ~= "string" then
			v703 = v700:GetAttribute("Weapon")
		end
		local v_u_704 = "KatanaAnimRules"
		local function v705()
			-- upvalues: (ref) v_u_5, (copy) v_u_704
			return v_u_5.shared[v_u_704]
		end
		local v706, v707 = pcall(v705)
		if not v706 then
			v707 = nil
		end
		if v707 ~= nil and v707.carries(v703) then
			local v708 = os.clock()
			if v708 - v_u_17 > 1 then
				v_u_17 = v708
				local v709 = v_u_5.config.flag
				local v710, v711 = pcall(v709, "KatanaAnim")
				v_u_16 = not v710 or v711 ~= false
			end
			local v712 = v_u_16
			if v712 then
				v712 = v_u_10 ~= nil
			end
			v702 = v712 and "katana" or v702
		end
		local v713 = v_u_11.sample(workspace:GetServerTimeNow() - v701, v702)
		if v713 ~= nil then
			local v714 = p699.rig
			local v715 = p699.scale
			local v716 = {}
			for _, v717 in v_u_698 do
				v716[v717] = v714.T[v717]
			end
			v714:setT("Waist", v714.T.Waist * CFrame.Angles(v713.waist, 0, 0))
			v714:setT("Neck", v714.T.Neck * CFrame.Angles(v713.neck, 0, 0))
			if v713.footW > 0.001 and v714.joints.RightAnkle then
				local v718 = v714:pivot("RightAnkle").Position
				local v719 = v713.foot.x
				local v720 = v713.foot.y
				local v721 = v713.foot.z
				v714:solve2("RightHip", "RightKnee", "RightAnkle", v718 + Vector3.new(v719, v720, v721) * v715, Vector3.new(0.1, 0.15, -1), Vector3.new(0, 0, -1))
				v714:orientEnd("RightAnkle", CFrame.Angles(0, p699.hipYaw, 0) * CFrame.Angles(0.45 * v713.footW, 0, 0) * v714.bind[v714.joints.RightAnkle.child].Rotation)
			end
			if v713.gripW > 0.001 and v714.joints.RightWrist then
				local v722 = v714:pivot("RightShoulder").Position
				local v723 = v713.grip.x
				local v724 = v713.grip.y
				local v725 = v713.grip.z
				local v726 = v722 + Vector3.new(v723, v724, v725) * v715
				local v727 = v713.look.x
				local v728 = v713.look.y
				local v729 = v713.look.z
				local v730 = Vector3.new(v727, v728, v729)
				local v731 = CFrame.lookAt(v726, v726 + v730)
				local v732 = p699.rig
				local v733 = p699.weapon
				local v734
				if v733 and (v733.handle and v733.relInv) then
					v734 = v731 * v733.gripInv * v733.relInv
				else
					v734 = v731 * p699.rgaInv
				end
				local v735 = v732.joints.RightWrist
				local v736
				if v735 then
					v736 = (v734 * v735.c1).Position
				else
					v736 = v734.Position
				end
				local _ = p699.scale
				v732:solve2("RightShoulder", "RightElbow", "RightWrist", v736, Vector3.new(0.55, -1, 0.45), Vector3.new(0, 0, 1))
				if v735 then
					v732:orientEnd("RightWrist", v734)
				end
			end
			if v713.leftW > 0.001 and v714.joints.LeftWrist then
				local v737 = v714:pivot("LeftShoulder").Position
				local v738 = v713.left.x
				local v739 = v713.left.y
				local v740 = v713.left.z
				local v741 = v737 + Vector3.new(v738, v739, v740) * v715
				p699.rig:solve2("LeftShoulder", "LeftElbow", "LeftWrist", v741, Vector3.new(-0.6, -1, 0.3), Vector3.new(0, 0, 1))
			end
			for _, v742 in {
				{
					v713.gripW,
					{ "RightShoulder", "RightElbow", "RightWrist" }
				},
				{
					v713.leftW,
					{ "LeftShoulder", "LeftElbow", "LeftWrist" }
				},
				{
					v713.footW,
					{ "RightHip", "RightKnee", "RightAnkle" }
				}
			} do
				local v743 = v742[1]
				local v744 = math.clamp(v743, 0, 1)
				for _, v745 in v742[2] do
					if not v714.joints[v745] then
						continue
					end
					v714:setT(v745, v716[v745]:Lerp(v714.T[v745], v744))
				end
			end
		end
	else
		return
	end
end
local function v_u_768(p747, p748) -- name: animate
	-- upvalues: (ref) v_u_9, (copy) v_u_20, (copy) v_u_224, (ref) v_u_12, (ref) v_u_8, (copy) v_u_263, (copy) v_u_697, (ref) v_u_11, (copy) v_u_746, (copy) v_u_4, (copy) v_u_36
	local v749 = p747.model
	local v750 = p747.rig
	local v751 = os.clock()
	local v752 = v749:GetAttribute("Dead") == true
	local v753 = v749:GetAttribute("Downed") == true
	if v752 then
		if v_u_9 and v_u_9.tossReset then
			v_u_9.tossReset(p747)
		end
		if v_u_20[v749] then
			local v754 = p747.model
			local v755 = v_u_20[v754]
			if v755 then
				v_u_20[v754] = nil
				v755:Destroy()
			end
		end
		if p747.deadAt < 0 or v751 < p747.deadAt then
			p747.deadAt = v751
		end
		if not p747.deadDone then
			v750:reset()
			v_u_224(p747, v751)
			v750:apply()
		end
	else
		p747.deadAt = -10
		p747.deadDone = false
		v750:reset()
		if v753 or (v_u_12 == nil or not v_u_12.pose(p747, v750, v751)) then
			if v753 then
				if v_u_9 and v_u_9.tossReset then
					v_u_9.tossReset(p747)
				end
				if p747.downedAt < 0 then
					p747.downedAt = v751
				end
				local v756 = p747.root.AssemblyLinearVelocity
				local v757 = v_u_8.damp
				local v758 = p747.speed
				local v759 = v756.X
				local v760 = v756.Z
				p747.speed = v757(v758, Vector3.new(v759, 0, v760).Magnitude, 8, p748)
				v_u_263(p747, p748, v751)
			else
				p747.downedAt = -10
				v_u_697(p747, p748, v751)
				if v_u_11 ~= nil and v749:GetAttribute("TakedownAt") ~= nil then
					local v761 = v_u_746
					local v762, v763 = pcall(v761, p747)
					if not v762 then
						v_u_11 = nil
						warn("[CharacterAnim] takedown pass failed, switched off:", v763)
					end
				end
				if v_u_4._stun ~= nil and v749:GetAttribute("StunUntil") ~= nil then
					v_u_4._stun.pass(p747, v750, v751)
				end
			end
			v750:apply()
			local v764 = v_u_36
			local v765 = not v753
			if v765 then
				v765 = p747.keyAction
			end
			v764(p747, v765)
		else
			local v766 = p747.model
			local v767 = v_u_20[v766]
			if v767 then
				v_u_20[v766] = nil
				v767:Destroy()
			end
		end
	end
end
function v_u_4.recoil(p769, p770) -- name: recoil
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (ref) v_u_5
	local v771 = p770 or v_u_13.Character
	local v772
	if v771 then
		v772 = v_u_18[v771]
	else
		v772 = nil
	end
	if v772 then
		local v773 = v772.model:GetAttribute("Weapon")
		local v774
		if type(v773) == "string" and v773 ~= "" then
			local v_u_775 = "Weapons"
			local function v776()
				-- upvalues: (ref) v_u_5, (copy) v_u_775
				return v_u_5.shared[v_u_775]
			end
			local v777, v778 = pcall(v776)
			if not v777 then
				v778 = nil
			end
			if v778 and v778.get then
				local v779 = v778.get
				local v780
				v780, v774 = pcall(v779, v773)
				if not v780 then
					v774 = nil
				end
			else
				v774 = nil
			end
		else
			v774 = nil
		end
		if not p769 then
			if v774 then
				local v781 = v774.recoil
				p769 = ((type(v781) ~= "number" or v781 ~= v781) and 1 or v781) * 0.28 + 0.45
			else
				p769 = 0.7
			end
		end
		local v782 = v772.kick + 1
		v772.kick = math.min(1.4, v782)
		v772.kickScale = p769
		v772.kickN = v772.kickN + 1
		if v772.isLocal and p770 == nil then
			v772.lastLocalKick = os.clock()
		end
	end
end
function v_u_4.swing(p783) -- name: swing
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (ref) v_u_7, (ref) v_u_5, (ref) v_u_17, (ref) v_u_16, (ref) v_u_10, (copy) v_u_310
	local v784 = p783 or v_u_13.Character
	local v785
	if v784 then
		v785 = v_u_18[v784]
	else
		v785 = nil
	end
	if v785 then
		local v786 = v785.model:GetAttribute("HoldType")
		if v786 == "melee1h" or v786 == "melee2h" then
			local v787 = v785.model:GetAttribute("Weapon")
			local v788
			if type(v787) == "string" and v787 ~= "" then
				local v_u_789 = "Weapons"
				local function v790()
					-- upvalues: (ref) v_u_5, (copy) v_u_789
					return v_u_5.shared[v_u_789]
				end
				local v791, v792 = pcall(v790)
				if not v791 then
					v792 = nil
				end
				if v792 and v792.get then
					local v793 = v792.get
					local v794
					v794, v788 = pcall(v793, v787)
					if not v794 then
						v788 = nil
					end
				else
					v788 = nil
				end
			else
				v788 = nil
			end
			local v795
			if v788 then
				local v796 = v788.meleeTime
				v795 = (type(v796) ~= "number" or v796 ~= v796) and 0.6 or v796
			else
				v795 = 0.6
			end
			local v797 = (os.clock() - v785.swingStart) / v785.swingDur
			if v797 < 0 or v797 >= 0.85 then
				v785.swingStart = os.clock()
				v785.swingDur = math.max(0.35, v795)
				local v798
				if v788 and v788.meleeWindup then
					local v799 = v788.meleeWindup
					v798 = ((type(v799) ~= "number" or v799 ~= v799) and 0.18 or v799) / v785.swingDur
				else
					v798 = 0.3
				end
				v785.swingWindup = v798
				v785.swingVariant = nil
				local v_u_800 = "KatanaAnimRules"
				local function v801()
					-- upvalues: (ref) v_u_5, (copy) v_u_800
					return v_u_5.shared[v_u_800]
				end
				local v802, v803 = pcall(v801)
				if not v802 then
					v803 = nil
				end
				if v803 ~= nil and v803.carries(v785.model:GetAttribute("Weapon")) then
					local v804 = os.clock()
					if v804 - v_u_17 > 1 then
						v_u_17 = v804
						local v805 = v_u_5.config.flag
						local v806, v807 = pcall(v805, "KatanaAnim")
						v_u_16 = not v806 or v807 ~= false
					end
					local v808 = v_u_16
					if v808 then
						v808 = v_u_10 ~= nil
					end
					if v808 then
						if v785.katana == nil then
							v785.katana = v803.new()
						end
						local v_u_809 = "KatanaRules"
						local function v810()
							-- upvalues: (ref) v_u_5, (copy) v_u_809
							return v_u_5.shared[v_u_809]
						end
						local v811, v812 = pcall(v810)
						if not v811 then
							v812 = nil
						end
						local v813
						if v812 == nil then
							v813 = nil
						else
							v813 = v812.CHAIN
						end
						local v814 = v803.pick
						local v815 = v785.katana
						local v816 = os.clock()
						local v817 = {
							["chain"] = nil,
							["hits"] = nil,
							["window"] = nil,
							["enabled"] = true,
							["chain"] = v785.model:GetAttribute("KatanaChain")
						}
						local v818
						if v813 == nil then
							v818 = nil
						else
							v818 = v813.hits
						end
						v817.hits = v818
						local v819
						if v813 == nil then
							v819 = nil
						else
							v819 = v813.window
						end
						v817.window = v819
						local v820, v821 = pcall(v814, v815, v816, v817)
						if v820 and type(v821) == "string" then
							v_u_310(v785, v821)
						end
					end
				end
				v785.swingToss = false
				if v_u_10 ~= nil and v_u_10.rollToss ~= nil then
					local v822 = v785.model:GetAttribute("Weapon")
					local v823 = v785.model:FindFirstChild("HeldWeapon")
					local v824
					if v823 then
						v824 = v823:GetAttribute("MeleeStyle")
					else
						v824 = nil
					end
					local v825 = v824 or v785.model:GetAttribute("MeleeStyle")
					local v826 = v_u_10.styleOf
					if type(v822) ~= "string" then
						v822 = nil
					end
					if type(v825) ~= "string" then
						v825 = nil
					end
					local v827, v828 = pcall(v826, v822, v788, v825)
					if v827 and type(v828) == "string" then
						local v829, v830 = v_u_10.rollToss(v828, v785.tossGap)
						v785.swingToss = v829
						v785.tossGap = v830
					end
				end
				if v785.isLocal and p783 == nil then
					v785.lastLocalSwing = os.clock()
				end
			end
		else
			local v831 = os.clock()
			local v832 = (v831 - v785.bashStart) / v_u_7.STRIKE_DUR
			if v832 < 0 or v832 >= 0.85 then
				v785.bashStart = v831
				v785.punchN = v785.punchN + 1
				v785.guardUntil = v831 + v_u_7.STRIKE_DUR + 1.4
				if v785.isLocal and p783 == nil then
					v785.lastLocalSwing = v831
				end
			end
		end
	else
		return
	end
end
function v_u_4.inspect(p833) -- name: inspect
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (ref) v_u_5, (ref) v_u_17, (ref) v_u_16, (ref) v_u_10, (copy) v_u_310
	local v834 = p833 or v_u_13.Character
	local v835
	if v834 then
		v835 = v_u_18[v834]
	else
		v835 = nil
	end
	if not v835 then
		return false
	end
	local v_u_836 = "KatanaAnimRules"
	local function v837()
		-- upvalues: (ref) v_u_5, (copy) v_u_836
		return v_u_5.shared[v_u_836]
	end
	local v838, v839 = pcall(v837)
	if not v838 then
		v839 = nil
	end
	if v839 ~= nil and v839.carries(v835.model:GetAttribute("Weapon")) then
		local v840 = os.clock()
		if v840 - v_u_17 > 1 then
			v_u_17 = v840
			local v841 = v_u_5.config.flag
			local v842, v843 = pcall(v841, "KatanaAnim")
			v_u_16 = not v842 or v843 ~= false
		end
		local v844 = v_u_16
		if v844 then
			v844 = v_u_10 ~= nil
		end
		if v844 and v835.model:GetAttribute("HoldType") == "melee1h" then
			local v845 = (os.clock() - v835.swingStart) / v835.swingDur
			if v845 >= 0 and v845 < 1 then
				return false
			else
				return v_u_310(v835, "inspect")
			end
		end
	end
	return false
end
function v_u_4.reload(p846, p847) -- name: reload
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (ref) v_u_5
	local v848 = p847 or v_u_13.Character
	local v_u_849
	if v848 then
		v_u_849 = v_u_18[v848]
	else
		v_u_849 = nil
	end
	if v_u_849 then
		if v_u_849.reloadMute == nil or (v_u_849.model:GetAttribute("Weapon") ~= v_u_849.reloadMute or os.clock() - v_u_849.reloadMuteT >= 2) then
			local v850 = v_u_849.model:GetAttribute("Weapon")
			local v851
			if type(v850) == "string" and v850 ~= "" then
				local v_u_852 = "Weapons"
				local function v853()
					-- upvalues: (ref) v_u_5, (copy) v_u_852
					return v_u_5.shared[v_u_852]
				end
				local v854, v855 = pcall(v853)
				if not v854 then
					v855 = nil
				end
				if v855 and v855.get then
					local v856 = v855.get
					local v857
					v857, v851 = pcall(v856, v850)
					if not v857 then
						v851 = nil
					end
				else
					v851 = nil
				end
			else
				v851 = nil
			end
			v_u_849.reloadStart = os.clock()
			if not p846 then
				if v851 then
					local v858 = v851.reloadTime
					p846 = (type(v858) ~= "number" or v858 ~= v858) and 2 or v858
				else
					p846 = 2
				end
			end
			v_u_849.reloadDur = p846
			local v859
			if v851 and v851.reloadKind == "single" then
				local v860 = v851.reloadPerRound
				v859 = (type(v860) ~= "number" or v860 ~= v860) and 0.5 or v860
			else
				v859 = 0
			end
			v_u_849.reloadSingle = v859
			v_u_849.reloading = true
			task.delay(v_u_849.reloadDur + 0.05, function()
				-- upvalues: (copy) v_u_849
				if v_u_849.model:GetAttribute("Reloading") ~= true and os.clock() - v_u_849.reloadStart >= v_u_849.reloadDur then
					v_u_849.reloading = false
				end
			end)
		end
	else
		return
	end
end
function v_u_4.cancelReload(p861, p862) -- name: cancelReload
	-- upvalues: (copy) v_u_13, (copy) v_u_18
	local v863 = p861 or v_u_13.Character
	local v864
	if v863 then
		v864 = v_u_18[v863]
	else
		v864 = nil
	end
	if v864 then
		v864.reloading = false
		local v865 = v864.model:GetAttribute("Weapon")
		if type(v865) ~= "string" or v865 == "" then
			v865 = nil
		end
		v864.reloadMute = v865
		v864.reloadMuteT = os.clock()
		v864.reloadMuteOff = p862 == true
	end
end
function v_u_4.reloadState(p866) -- name: reloadState
	-- upvalues: (copy) v_u_13, (copy) v_u_18
	local v867 = p866 or v_u_13.Character
	local v868
	if v867 then
		v868 = v_u_18[v867]
	else
		v868 = nil
	end
	if v868 then
		return v868.reloading
	else
		return nil
	end
end
function v_u_4.flinch(p869, p870) -- name: flinch
	-- upvalues: (copy) v_u_13, (copy) v_u_18
	local v871 = p869 or v_u_13.Character
	local v872
	if v871 then
		v872 = v_u_18[v871]
	else
		v872 = nil
	end
	if v872 then
		local v873 = v872.flinch + (p870 or 0.6)
		v872.flinch = math.min(1, v873)
		v872.flinchYaw = (math.random() - 0.5) * 2
	end
end
local v_u_874 = {}
function v_u_4.attach(p875) -- name: attach
	-- upvalues: (copy) v_u_18, (copy) v_u_874, (copy) v_u_159
	if v_u_18[p875] then
		v_u_874[p875] = true
		return true
	end
	v_u_159(p875, nil)
	if not v_u_18[p875] then
		return false
	end
	v_u_874[p875] = true
	return true
end
function v_u_4.detach(p876) -- name: detach
	-- upvalues: (copy) v_u_874, (copy) v_u_165
	v_u_874[p876] = nil
	v_u_165(p876)
end
function v_u_4.debugState(p877) -- name: debugState
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (ref) v_u_9
	local v878 = p877 or v_u_13.Character
	local v879
	if v878 then
		v879 = v_u_18[v878]
	else
		v879 = nil
	end
	if not v879 then
		return nil
	end
	local v880 = {
		["speed"] = v879.speed,
		["phase"] = v879.phase,
		["gw"] = v879.gw,
		["hipYaw"] = v879.hipYaw,
		["drop"] = v879.drop,
		["crouch"] = v879.crouch,
		["wAim"] = v879.wAim,
		["wSprint"] = v879.wSprint,
		["weapon"] = v879.weapon ~= nil,
		["lead"] = v879.lead
	}
	local v881
	if v_u_9 then
		v881 = v_u_9.lastFit(v879)
	else
		v881 = nil
	end
	v880.fit = v881
	return v880
end
function v_u_4.init(p_u_882) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (copy) v_u_4, (copy) v_u_56, (copy) v_u_13, (copy) v_u_18
	v_u_5 = p_u_882
	v_u_6 = p_u_882.lib.AnimRig
	v_u_7 = p_u_882.lib.AnimPoses
	v_u_8 = v_u_6.math
	local function v886()
		-- upvalues: (copy) p_u_882, (ref) v_u_8, (ref) v_u_10
		local v883 = p_u_882.lib.AnimArms
		v883.init(p_u_882, v_u_8)
		v_u_10 = p_u_882.lib.AnimMelee
		local v884 = v_u_10.install
		local v885 = p_u_882.lib
		pcall(v884, v885)
		return v883
	end
	local v887, v888 = pcall(v886)
	local v889
	if v887 then
		v889 = v888
	else
		v889 = nil
	end
	v_u_9 = v889
	if not v887 then
		warn("[CharacterAnim] AnimArms failed to load, the 0.8.1 arms stay:", v888)
	end
	local v890, v891 = pcall(function()
		-- upvalues: (copy) p_u_882
		return p_u_882.lib.TakedownAnim
	end)
	if not v890 or type(v891) ~= "table" then
		v891 = nil
	end
	v_u_11 = v891
	local v892, v893 = pcall(function()
		-- upvalues: (copy) p_u_882
		return p_u_882.lib.RidePose
	end)
	if not v892 or type(v893) ~= "table" then
		v893 = nil
	end
	v_u_12 = v893
	local v894, v895 = pcall(function()
		-- upvalues: (copy) p_u_882
		return p_u_882.lib.AnimStun
	end)
	local v896 = v_u_4
	if not v894 or (type(v895) ~= "table" or not v895.init(p_u_882)) then
		v895 = nil
	end
	v896._stun = v895
	if v_u_12 and v_u_12.init then
		local v897 = v_u_12.init
		local v898 = v_u_56
		pcall(v897, p_u_882, v898)
	end
	p_u_882.command("anim.state", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_18
		local v899 = v_u_13.Character
		local v900
		if v899 then
			v900 = v_u_18[v899]
		else
			v900 = nil
		end
		if not v900 then
			return "no local character tracked"
		end
		local v901 = v900.rig
		local v902 = {}
		for _, v903 in {
			"Root",
			"Waist",
			"LeftHip",
			"LeftKnee",
			"RightShoulder",
			"RightElbow"
		} do
			local v904 = v901.joints[v903]
			if not v904 then
				continue
			end
			local v905, v906, v907 = v904.m.Transform:ToEulerAnglesXYZ()
			local v908 = string.format
			table.insert(v902, v908("%s=(%.2f,%.2f,%.2f)", v903, v905, v906, v907))
		end
		local v909 = 0
		for _ in v_u_18 do
			v909 = v909 + 1
		end
		local v910 = string.format
		local v911 = v900.speed
		local v912 = v900.phase
		local v913 = v900.gw
		local v914 = v900.drop
		local v915 = v900.weapon ~= nil
		return v910("tracked=%d speed=%.2f phase=%.2f gw=%.2f drop=%.2f weapon=%s %s", v909, v911, v912, v913, v914, tostring(v915), table.concat(v902, " "))
	end)
	p_u_882.command("anim.meleepose", function(p916)
		-- upvalues: (ref) v_u_7
		if p916[1] == "old" or p916[1] == "new" then
			v_u_7.legacyMelee = p916[1] == "old"
		end
		local v917 = v_u_7.legacyMelee
		return "legacyMelee=" .. tostring(v917)
	end)
	p_u_882.command("anim.poseset", function(p918)
		-- upvalues: (ref) v_u_7
		local v919 = {}
		for v920 = 3, 8 do
			local v921 = p918[v920]
			local v922 = tonumber(v921) or 0
			table.insert(v919, v922)
		end
		local v923 = v_u_7.setPose(p918[1] or "", p918[2] or "", v919)
		return not v923 and "unknown pose" or "was " .. table.concat(v923, " ")
	end)
	p_u_882.command("anim.recoil", function()
		-- upvalues: (ref) v_u_4
		v_u_4.recoil(nil, nil)
		return "kick"
	end)
	p_u_882.command("anim.swing", function()
		-- upvalues: (ref) v_u_4
		v_u_4.swing(nil)
		return "swing"
	end)
	p_u_882.command("anim.reload", function(p924)
		-- upvalues: (ref) v_u_4
		local v925 = v_u_4.reload
		local v926 = p924[1]
		v925(tonumber(v926), nil)
		return "reload"
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_5, (copy) v_u_4, (copy) v_u_3, (ref) v_u_38
	v_u_5.on("weapon.fired", function(p927)
		-- upvalues: (ref) v_u_4
		local v928 = v_u_4.recoil
		if type(p927) ~= "number" then
			p927 = nil
		end
		v928(p927, nil)
	end)
	v_u_5.on("weapon.reload", function(p929)
		-- upvalues: (ref) v_u_4
		local v930 = v_u_4.reload
		if type(p929) ~= "number" then
			p929 = nil
		end
		v930(p929, nil)
	end)
	v_u_5.on("weapon.melee", function()
		-- upvalues: (ref) v_u_4
		v_u_4.swing(nil)
	end)
	v_u_3.PlayerRemoving:Connect(function()
		-- upvalues: (ref) v_u_38
		v_u_38 = true
	end)
end
local v_u_931 = 0
function v_u_4.step(p932) -- name: step
	-- upvalues: (ref) v_u_931, (copy) v_u_3, (copy) v_u_18, (copy) v_u_19, (copy) v_u_159, (copy) v_u_13, (copy) v_u_874, (copy) v_u_165, (copy) v_u_768
	v_u_931 = v_u_931 + 1
	for _, v933 in v_u_3:GetPlayers() do
		local v934 = v933.Character
		if not v934 or (not v934.Parent or v_u_18[v934]) then
			continue
		end
		local v935 = v_u_19[v934]
		if v935 and os.clock() - v935 <= 1 then
			continue
		end
		v_u_19[v934] = nil
		v_u_159(v934, v933)
	end
	local v936 = workspace.CurrentCamera
	local v937 = not v936 and Vector3.new(0, 0, 0) or v936.CFrame.Position
	local v938 = not v936 and Vector3.new(0, 0, 0) or v936.Focus.Position
	local v939 = v_u_13.Character
	local v940
	if v939 then
		v940 = v939:FindFirstChild("HumanoidRootPart")
	else
		v940 = nil
	end
	for v941, v942 in v_u_18 do
		if (v941.Parent or v_u_874[v941]) and ((v942.root.Parent or v_u_874[v941]) and (not v942.player or v942.player.Character == v941)) then
			local v943 = (v942.root.Position - v938).Magnitude
			local v944 = (v942.root.Position - v937).Magnitude
			local v945 = math.min(v943, v944)
			if v940 then
				local v946 = (v942.root.Position - v940.Position).Magnitude
				v945 = math.min(v945, v946)
			end
			v942.lodAcc = v942.lodAcc + p932
			local v947 = (v942.isLocal or v945 < 140) and 0 or (v945 < 260 and 0.05 or 0.125)
			if v945 > 700 and not v942.isLocal or v942.lodAcc < v947 then
				continue
			end
			local v948 = v942.lodAcc
			local v949 = math.min(v948, 0.1)
			v942.lodAcc = 0
			local v950 = v_u_768
			local v951, v952 = pcall(v950, v942, v949)
			if v951 then
				continue
			end
			warn("[CharacterAnim]", v941.Name, v952)
			v_u_13:SetAttribute("ClientError", "CharacterAnim: " .. tostring(v952))
		else
			v_u_165(v941)
		end
	end
	for v953 in v_u_19 do
		if v953.Parent then
			continue
		end
		v_u_19[v953] = nil
	end
	if v_u_931 % 30 == 0 then
		local v954 = v_u_13.Character
		local v955
		if v954 then
			v955 = v_u_18[v954]
		else
			v955 = nil
		end
		if v955 then
			local v956 = v_u_13
			local v957 = v955.speed * 10
			v956:SetAttribute("AnimSpeed", math.floor(v957) / 10)
			local v958 = v_u_13
			local v959 = v955.phase * 100
			v958:SetAttribute("AnimPhase", math.floor(v959) / 100)
		end
	end
end
return v_u_4