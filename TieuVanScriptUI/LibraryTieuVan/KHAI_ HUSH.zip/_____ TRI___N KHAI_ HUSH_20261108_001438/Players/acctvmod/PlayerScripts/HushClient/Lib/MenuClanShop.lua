-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanShop

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {}
local v_u_4 = {
	Color3.fromRGB(150, 160, 170),
	Color3.fromRGB(110, 200, 120),
	Color3.fromRGB(90, 160, 240),
	Color3.fromRGB(190, 120, 240),
	Color3.fromRGB(240, 190, 70)
}
local function v_u_14(p_u_5) -- name: bindModel
	local v6 = p_u_5.lib("MenuClanShopModel")
	if v6 == nil then
		return nil
	end
	local v_u_7 = nil
	local v_u_8 = nil
	local function v9()
		-- upvalues: (ref) v_u_7, (copy) p_u_5, (ref) v_u_8
		v_u_7 = p_u_5.cctx.shared.ClanShopCatalog
		v_u_8 = p_u_5.cctx.shared.ClanStyle
	end
	pcall(v9)
	if v_u_7 == nil then
		return nil
	end
	local v10 = v6.bind
	local v11 = v_u_7
	local v12 = v_u_8
	local v13 = p_u_5.M
	if v13 then
		v13 = p_u_5.M.timeText
	end
	v10(v11, v12, v13)
	return v6
end
local function v_u_22(p15, p16) -- name: devData
	-- upvalues: (copy) v_u_1
	if p15._shopDev == nil then
		local v_u_17 = nil
		local v_u_18 = "DevClanShop"
		local function v19()
			-- upvalues: (ref) v_u_1, (copy) v_u_18
			return v_u_1.LocalPlayer:GetAttribute(v_u_18)
		end
		local v20, v_u_21 = pcall(v19)
		if not v20 then
			v_u_21 = nil
		end
		if type(v_u_21) == "string" and v_u_21 ~= "" then
			pcall(function()
				-- upvalues: (ref) v_u_17, (copy) v_u_21
				v_u_17 = game:GetService("HttpService"):JSONDecode(v_u_21)
			end)
		end
		if type(v_u_17) ~= "table" then
			v_u_17 = p16.fake(p15.clan())
		end
		p15._shopDev = p16.norm(v_u_17)
	end
	return p15._shopDev
end
function v_u_3.fetch(p23, p24) -- name: fetch
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (copy) v_u_22
	local v25 = v_u_14(p23)
	if v25 == nil then
		return nil
	else
		local v26
		if v_u_2:IsStudio() then
			local v_u_27 = "DevClanState"
			local function v28()
				-- upvalues: (ref) v_u_1, (copy) v_u_27
				return v_u_1.LocalPlayer:GetAttribute(v_u_27)
			end
			local v29, v30 = pcall(v28)
			if not v29 then
				v30 = nil
			end
			local v_u_31 = "DevClanShop"
			local function v32()
				-- upvalues: (ref) v_u_1, (copy) v_u_31
				return v_u_1.LocalPlayer:GetAttribute(v_u_31)
			end
			local v33, v34 = pcall(v32)
			if not v33 then
				v34 = nil
			end
			if type(v30) == "string" and v30 ~= "" then
				v26 = true
			elseif type(v34) == "string" then
				v26 = v34 ~= ""
			else
				v26 = false
			end
		else
			v26 = false
		end
		if v26 then
			return v_u_22(p23, v25)
		else
			local v35 = p23.fetch("clanShop", nil, p24 or 20)
			if type(v35) == "table" and v35.error == nil then
				return v25.norm(v35)
			else
				return nil
			end
		end
	end
end
function v_u_3.mount(p_u_36, p37) -- name: mount
	-- upvalues: (copy) v_u_14, (copy) v_u_1, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
	local v_u_38 = p_u_36.UI
	local _ = p_u_36.Theme
	local v_u_39 = p_u_36.C
	local v_u_40 = p_u_36.Kit
	local v_u_41 = p_u_36.U
	local v_u_42 = p_u_36.M
	local v_u_43 = p_u_36.m
	local v_u_44 = v_u_14(p_u_36)
	local v_u_45 = p_u_36.lib("MenuClanShopPlan")
	local v_u_46 = {}
	local v_u_47 = true
	local v_u_48 = false
	if v_u_44 == nil or v_u_45 == nil then
		v_u_40.empty(p37, "This screen failed to load. Please reopen the menu.")
		function v_u_46.show() -- name: show end
		function v_u_46.hide() -- name: hide end
		function v_u_46.refresh() -- name: refresh end
		function v_u_46.tick() -- name: tick end
		function v_u_46.destroy() -- name: destroy end
		return v_u_46
	end
	local v_u_49 = nil
	local v_u_50 = "loading"
	local v_u_51 = 0
	local v_u_52 = false
	local v_u_53 = -1000
	local v_u_54 = "all"
	local v_u_55 = nil
	local v_u_56 = {}
	local v_u_57 = {}
	local v_u_58 = 0
	local v_u_59 = false
	local v_u_60 = nil
	local v_u_61 = nil
	local v_u_62 = nil
	local v_u_63 = v_u_43.inner - 14
	local v_u_64 = v_u_43.touch
	local v_u_65 = v_u_45.top(v_u_63, v_u_43.kind, v_u_64)
	local v_u_66 = v_u_41.frame(p37, "Top", UDim2.new(1, 0, 0, v_u_65.fixedH))
	local v_u_67 = v_u_38.list({
		["parent"] = nil,
		["name"] = "List",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 0,
		["padding"] = nil,
		["parent"] = p37,
		["position"] = UDim2.fromOffset(0, v_u_65.fixedH),
		["size"] = UDim2.new(1, 0, 1, -v_u_65.fixedH),
		["padding"] = {
			0,
			4,
			0,
			12
		}
	})
	local v_u_68 = v_u_38.label({
		["parent"] = nil,
		["name"] = "Loading",
		["text"] = "",
		["style"] = "body",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["visible"] = false,
		["parent"] = p37,
		["color"] = v_u_39.text2,
		["position"] = UDim2.fromOffset(0, 24),
		["size"] = UDim2.new(1, 0, 0, 28)
	})
	local function v_u_83() -- name: paintPreview
		-- upvalues: (ref) v_u_61, (ref) v_u_49, (copy) p_u_36, (copy) v_u_44, (ref) v_u_55, (ref) v_u_1
		if v_u_61 ~= nil and v_u_49 ~= nil then
			local v69 = p_u_36.clan()
			local v70
			if v69 then
				local v71 = v69.tag
				v70 = type(v71) ~= "string" and "????" or v69.tag
			else
				v70 = "????"
			end
			local v72 = v_u_44.styleOf(v_u_49, v_u_55)
			local v73
			if v_u_44.style then
				local v74 = v_u_44.style.rich
				local v75, v76 = pcall(v74, v70, v72, nil)
				v73 = (not v75 or type(v76) ~= "string") and "" or v76
			else
				v73 = ""
			end
			local function v77()
				-- upvalues: (ref) v_u_1
				return v_u_1.LocalPlayer.DisplayName
			end
			local v78, v79 = pcall(v77)
			local v80 = (not v78 or (type(v79) ~= "string" or v79 == "")) and "Player" or v79
			local v81 = string.gsub(string.gsub(string.gsub(v80, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
			for _, v82 in v_u_61 do
				v82.RichText = true
				v82.Text = v73 .. v81
			end
		end
	end
	local function v_u_128() -- name: drawTop
		-- upvalues: (copy) v_u_40, (copy) v_u_66, (ref) v_u_61, (ref) v_u_49, (copy) v_u_44, (copy) v_u_43, (copy) v_u_65, (copy) v_u_41, (copy) v_u_39, (copy) v_u_38, (ref) v_u_54, (copy) v_u_46, (copy) v_u_83
		v_u_40.clear(v_u_66)
		v_u_61 = nil
		if v_u_49 ~= nil then
			local v84 = v_u_44.head(v_u_49)
			local v85 = v_u_43.kind == "phone"
			local v86 = {
				["coins"] = { "COINS", v84.coins },
				["pts"] = { "CLAN POINTS", v84.pts },
				["payout"] = { "PAYOUT IN", v84.payout },
				["last"] = { "LAST PAYOUT", v84.last or "none yet" }
			}
			for v87, v88 in v_u_65.chips do
				local v89 = v86[v87]
				local v90 = v88.box
				if v85 then
					local v91 = v_u_41.text
					local v92 = v_u_66
					local v93 = "Chip_" .. v87
					local v94 = v89[1] .. "  " .. v89[2]
					local v95 = {
						["x"] = v90.x + v88.parts.value.x,
						["y"] = v90.y + v88.parts.value.y,
						["w"] = v88.parts.value.w,
						["h"] = v88.parts.value.h
					}
					local v96 = {
						["style"] = "monoS",
						["color"] = nil
					}
					local v97
					if v87 == "coins" then
						v97 = v_u_39.accent
					else
						v97 = v_u_39.text
					end
					v96.color = v97
					v91(v92, v93, v94, v95, v96).TextTruncate = Enum.TextTruncate.AtEnd
				else
					local v98 = v_u_41.card(v_u_66, "Chip_" .. v87, v90)
					v_u_41.text(v98, "Label", v89[1], v88.parts.label, {
						["style"] = "micro",
						["color"] = nil,
						["color"] = v_u_39.text2
					})
					local v99 = v_u_41.text
					local v100 = "Value"
					local v101 = v89[2]
					local v102 = v88.parts.value
					local v103 = {
						["style"] = "monoL",
						["color"] = nil
					}
					local v104
					if v87 == "coins" then
						v104 = v_u_39.accent
					else
						v104 = v_u_39.text
					end
					v103.color = v104
					v99(v98, v100, v101, v102, v103)
				end
				if v87 ~= "pts" or not v88.parts.bar then
					continue
				end
				local v105
				if v85 then
					v105 = v_u_66
				else
					v105 = v_u_66:FindFirstChild("Chip_pts")
				end
				local v106 = v88.parts.bar
				local v107 = not v85 and 0 or v90.x
				local v108 = not v85 and 0 or v90.y
				local v109 = v_u_38.new("Frame", {
					["Name"] = "BarTrack",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_39.bg,
					["Position"] = UDim2.fromOffset(v107 + v106.x, v108 + v106.y),
					["Size"] = UDim2.fromOffset(v106.w, v106.h)
				}, v105)
				local v110 = v_u_38.new
				local v111 = {
					["Name"] = "BarFill",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_39.accent
				}
				local v112 = UDim2.new
				local v113 = v84.bar
				v111.Size = v112(math.clamp(v113, 0, 1), 0, 1, 0)
				v110("Frame", v111, v109)
			end
			if v_u_65.cats then
				local v114 = v_u_65.cats
				local v115 = v_u_41.frame(v_u_66, "Cats", UDim2.fromOffset(v114.w, v114.h), UDim2.fromOffset(v114.x, v114.y))
				v_u_38.tabs({
					["parent"] = nil,
					["name"] = "CatTabs",
					["tabs"] = nil,
					["selected"] = nil,
					["size"] = nil,
					["onChange"] = nil,
					["parent"] = v115,
					["tabs"] = v_u_44.categories(),
					["selected"] = v_u_54,
					["size"] = UDim2.fromScale(1, 1),
					["onChange"] = function(p116) -- name: onChange
						-- upvalues: (ref) v_u_54, (ref) v_u_46
						v_u_54 = p116
						v_u_46.drawSheet()
					end
				})
			end
			local v_u_117 = v_u_65.preview
			local v_u_118 = v_u_41.card(v_u_66, "Preview", v_u_117.box, {
				["fill"] = nil,
				["transparency"] = 0.4,
				["fill"] = v_u_39.bg
			})
			if v_u_117.parts.label then
				v_u_41.text(v_u_118, "Label", v_u_44.UI.PREVIEW, v_u_117.parts.label, {
					["style"] = "micro",
					["color"] = nil,
					["color"] = v_u_39.text2
				})
			end
			v_u_61 = {}
			local function v127(p119, p120, p121, p122) -- name: field
				-- upvalues: (copy) v_u_117, (ref) v_u_38, (copy) v_u_118, (ref) v_u_44, (ref) v_u_61
				local v123 = v_u_117.parts[p119]
				local v124 = v_u_38.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ClipsDescendants"] = true,
					["Name"] = "Field_" .. p119,
					["BackgroundColor3"] = p120,
					["Position"] = UDim2.fromOffset(v123.x, v123.y),
					["Size"] = UDim2.fromOffset(v123.w, v123.h)
				}, v_u_118)
				v_u_38.corner(v124, 4)
				local v125 = v_u_38.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = "",
					["style"] = "bodyStrong",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v124,
					["color"] = p121,
					["size"] = UDim2.new(1, -12, 1, 0),
					["position"] = UDim2.fromOffset(6, 0)
				})
				if p122 and v_u_44.style then
					v125.TextStrokeColor3 = Color3.new(0, 0, 0)
					v125.TextStrokeTransparency = v_u_44.style.OUTLINE.transparency
				end
				local v126 = v_u_61
				table.insert(v126, v125)
			end
			v127("dark", Color3.fromRGB(14, 17, 22), v_u_39.text, false)
			v127("light", Color3.fromRGB(204, 210, 216), Color3.fromRGB(20, 24, 30), true)
			v_u_83()
		end
	end
	local function v_u_132(p129) -- name: applyData
		-- upvalues: (ref) v_u_49, (ref) v_u_53, (ref) v_u_57
		if p129 ~= nil then
			v_u_49 = p129
			v_u_53 = os.clock()
			for v130, v131 in v_u_57 do
				if v130 == "expand" then
					if v_u_49.xt <= (v131.xt or 0) then
						continue
					end
					v_u_57[v130] = nil
				else
					if v_u_49.own[v130] ~= 1 then
						continue
					end
					v_u_57[v130] = nil
				end
			end
		end
	end
	local v_u_133 = nil
	local function v_u_152(p134, p135, p_u_136) -- name: send
		-- upvalues: (ref) v_u_2, (ref) v_u_1, (copy) v_u_44, (ref) v_u_49, (copy) p_u_36
		local v137
		if v_u_2:IsStudio() then
			local v_u_138 = "DevClanState"
			local function v139()
				-- upvalues: (ref) v_u_1, (copy) v_u_138
				return v_u_1.LocalPlayer:GetAttribute(v_u_138)
			end
			local v140, v141 = pcall(v139)
			if not v140 then
				v141 = nil
			end
			local v_u_142 = "DevClanShop"
			local function v143()
				-- upvalues: (ref) v_u_1, (copy) v_u_142
				return v_u_1.LocalPlayer:GetAttribute(v_u_142)
			end
			local v144, v145 = pcall(v143)
			if not v144 then
				v145 = nil
			end
			if type(v141) == "string" and v141 ~= "" then
				v137 = true
			elseif type(v145) == "string" then
				v137 = v145 ~= ""
			else
				v137 = false
			end
		else
			v137 = false
		end
		if v137 then
			local v_u_146, v_u_147, v_u_148 = v_u_44.simulate(v_u_49, p134, p135)
			task.defer(function()
				-- upvalues: (copy) v_u_146, (ref) p_u_36, (copy) v_u_148, (copy) p_u_136, (copy) v_u_147
				if v_u_146 then
					p_u_36._shopDev = v_u_148
				end
				local v149 = p_u_136
				local v150 = v_u_146
				local v151
				if v_u_146 then
					v151 = nil
				else
					v151 = v_u_147
				end
				v149(v150, v151, {
					["code"] = v_u_147
				}, {
					["ok"] = v_u_146,
					["data"] = {
						["code"] = v_u_147
					}
				})
			end)
		else
			p_u_36.send(p134, p135, p_u_136, 30)
		end
	end
	local function v_u_223(p_u_153, _, p_u_154, p_u_155) -- name: buy
		-- upvalues: (copy) p_u_36, (copy) v_u_44, (ref) v_u_49, (copy) v_u_41, (ref) v_u_59, (copy) v_u_152, (ref) v_u_47, (copy) v_u_42, (ref) v_u_133, (ref) v_u_57
		local v156 = p_u_36.clan()
		local v157
		if v156 then
			local v158 = v156.tag
			v157 = type(v158) ~= "string" and "????" or v156.tag
		else
			v157 = "????"
		end
		local v159 = v_u_44.confirm(p_u_154, v_u_49, p_u_153, v157)
		local v_u_160 = p_u_153.row
		v_u_41.confirm({
			["title"] = nil,
			["body"] = nil,
			["yes"] = nil,
			["no"] = "CANCEL",
			["onYes"] = nil,
			["title"] = v159.title,
			["body"] = v159.body,
			["yes"] = v159.yes,
			["onYes"] = function() -- name: onYes
				-- upvalues: (copy) p_u_153, (copy) p_u_154, (copy) p_u_155, (ref) v_u_59, (ref) v_u_152, (ref) v_u_47, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133, (copy) v_u_160, (ref) v_u_57, (ref) v_u_49
				local v161 = p_u_153.id == "expand"
				if p_u_154 == "coins" then
					if v161 then
						local v162 = {
							["pay"] = "coins"
						}
						local v_u_163 = p_u_155
						if not v_u_59 then
							v_u_59 = true
							if v_u_163 then
								v_u_163.busy(true, "...")
							end
							local v_u_164 = nil
							local v_u_165 = "Your clan was expanded."
							v_u_152("clanExpand", v162, function(p166, p167, p168, p169)
								-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) v_u_163, (copy) v_u_164, (copy) v_u_165, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
								v_u_59 = false
								if v_u_47 then
									if v_u_163 then
										local v170 = v_u_163.busy
										pcall(v170, false)
									end
									if p166 then
										if v_u_164 then
											v_u_164()
										end
										if v_u_165 then
											p_u_36.notice(v_u_165, "success", 8)
										end
									else
										local v171 = p_u_36.notice
										local v172 = v_u_44.reason
										if not p169 then
											p169 = {
												["msg"] = p167,
												["data"] = p168
											}
										end
										v171(v172(p169, function(p173)
											-- upvalues: (ref) v_u_42
											return v_u_42.reasonFor(p173)
										end), "warn", 10)
									end
									v_u_133(true)
								end
							end)
						end
					else
						local v174 = {
							["item"] = v_u_160.id
						}
						local v_u_175 = p_u_155
						if not v_u_59 then
							v_u_59 = true
							if v_u_175 then
								v_u_175.busy(true, "...")
							end
							local v_u_176 = nil
							local v_u_177 = "Added to your clan."
							v_u_152("clanShopBuy", v174, function(p178, p179, p180, p181)
								-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) v_u_175, (copy) v_u_176, (copy) v_u_177, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
								v_u_59 = false
								if v_u_47 then
									if v_u_175 then
										local v182 = v_u_175.busy
										pcall(v182, false)
									end
									if p178 then
										if v_u_176 then
											v_u_176()
										end
										if v_u_177 then
											p_u_36.notice(v_u_177, "success", 8)
										end
									else
										local v183 = p_u_36.notice
										local v184 = v_u_44.reason
										if not p181 then
											p181 = {
												["msg"] = p179,
												["data"] = p180
											}
										end
										v183(v184(p181, function(p185)
											-- upvalues: (ref) v_u_42
											return v_u_42.reasonFor(p185)
										end), "warn", 10)
									end
									v_u_133(true)
								end
							end)
						end
					end
				elseif p_u_154 == "robux" then
					local v_u_186 = v161 and "expand" or v_u_160.id
					if v161 then
						local v187 = {}
						local v_u_188 = p_u_155
						local function v_u_189()
							-- upvalues: (ref) v_u_57, (ref) v_u_49
							v_u_57.expand = {
								["at"] = os.clock(),
								["xt"] = v_u_49.xt
							}
						end
						if not v_u_59 then
							v_u_59 = true
							if v_u_188 then
								v_u_188.busy(true, "...")
							end
							local v_u_190 = nil
							v_u_152("clanExpandRobux", v187, function(p191, p192, p193, p194)
								-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) v_u_188, (copy) v_u_189, (copy) v_u_190, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
								v_u_59 = false
								if v_u_47 then
									if v_u_188 then
										local v195 = v_u_188.busy
										pcall(v195, false)
									end
									if p191 then
										if v_u_189 then
											v_u_189()
										end
										if v_u_190 then
											p_u_36.notice(v_u_190, "success", 8)
										end
									else
										local v196 = p_u_36.notice
										local v197 = v_u_44.reason
										if not p194 then
											p194 = {
												["msg"] = p192,
												["data"] = p193
											}
										end
										v196(v197(p194, function(p198)
											-- upvalues: (ref) v_u_42
											return v_u_42.reasonFor(p198)
										end), "warn", 10)
									end
									v_u_133(true)
								end
							end)
						end
					else
						local v199 = {
							["item"] = v_u_160.id
						}
						local v_u_200 = p_u_155
						local function v_u_201()
							-- upvalues: (ref) v_u_57, (copy) v_u_186
							v_u_57[v_u_186] = {
								["at"] = os.clock()
							}
						end
						if not v_u_59 then
							v_u_59 = true
							if v_u_200 then
								v_u_200.busy(true, "...")
							end
							local v_u_202 = nil
							v_u_152("clanShopRobux", v199, function(p203, p204, p205, p206)
								-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) v_u_200, (copy) v_u_201, (copy) v_u_202, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
								v_u_59 = false
								if v_u_47 then
									if v_u_200 then
										local v207 = v_u_200.busy
										pcall(v207, false)
									end
									if p203 then
										if v_u_201 then
											v_u_201()
										end
										if v_u_202 then
											p_u_36.notice(v_u_202, "success", 8)
										end
									else
										local v208 = p_u_36.notice
										local v209 = v_u_44.reason
										if not p206 then
											p206 = {
												["msg"] = p204,
												["data"] = p205
											}
										end
										v208(v209(p206, function(p210)
											-- upvalues: (ref) v_u_42
											return v_u_42.reasonFor(p210)
										end), "warn", 10)
									end
									v_u_133(true)
								end
							end)
						end
					end
				else
					local v211 = {
						["item"] = v_u_160.id
					}
					local v_u_212 = p_u_155
					if not v_u_59 then
						v_u_59 = true
						if v_u_212 then
							v_u_212.busy(true, "...")
						end
						local v_u_213 = nil
						local v_u_214 = "Added to your clan."
						v_u_152("clanShopRedeem", v211, function(p215, p216, p217, p218)
							-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) v_u_212, (copy) v_u_213, (copy) v_u_214, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
							v_u_59 = false
							if v_u_47 then
								if v_u_212 then
									local v219 = v_u_212.busy
									pcall(v219, false)
								end
								if p215 then
									if v_u_213 then
										v_u_213()
									end
									if v_u_214 then
										p_u_36.notice(v_u_214, "success", 8)
									end
								else
									local v220 = p_u_36.notice
									local v221 = v_u_44.reason
									if not p218 then
										p218 = {
											["msg"] = p216,
											["data"] = p217
										}
									end
									v220(v221(p218, function(p222)
										-- upvalues: (ref) v_u_42
										return v_u_42.reasonFor(p222)
									end), "warn", 10)
								end
								v_u_133(true)
							end
						end)
					end
				end
			end
		})
	end
	local function v_u_246(p224, p225, p226) -- name: swatchLook
		-- upvalues: (copy) v_u_44, (copy) p_u_36, (copy) v_u_39, (copy) v_u_38
		local v227 = v_u_44.swatch(p225, p226.variant)
		local v228 = p_u_36.clan()
		local v229
		if v228 then
			local v230 = v228.tag
			v229 = type(v230) ~= "string" and "????" or v228.tag
		else
			v229 = "????"
		end
		p224.BackgroundColor3 = v_u_39.bg
		local v231 = v227.word
		local v232 = v_u_39.text2
		if p225.slot == "tc" or p225.slot == "ts" then
			v231 = v227.brackets[1] .. v229 .. v227.brackets[2]
			v232 = v_u_39.text
		end
		local v233 = v_u_38.label({
			["parent"] = nil,
			["name"] = "Word",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["position"] = nil,
			["track"] = false,
			["parent"] = p224,
			["text"] = v231,
			["color"] = v232,
			["size"] = UDim2.new(1, -6, 1, 0),
			["position"] = UDim2.fromOffset(3, 0)
		})
		v233.TextTruncate = Enum.TextTruncate.AtEnd
		if v227.colors and #v227.colors > 0 then
			if #v227.colors == 1 then
				local v234 = v227.colors[1]
				local v235 = Color3.fromHex
				local v236, v237 = pcall(v235, v234)
				if not v236 then
					v237 = Color3.new(1, 1, 1)
				end
				v233.TextColor3 = v237
				return
			end
			v233.TextColor3 = Color3.new(1, 1, 1)
			local v238 = {}
			for v239, v240 in v227.colors do
				local v241 = ColorSequenceKeypoint.new
				local v242 = (v239 - 1) / (#v227.colors - 1)
				local v243 = Color3.fromHex
				local v244, v245 = pcall(v243, v240)
				if not v244 then
					v245 = Color3.new(1, 1, 1)
				end
				table.insert(v238, v241(v242, v245))
			end
			v_u_38.new("UIGradient", {
				["Color"] = ColorSequence.new(v238)
			}, v233)
		end
	end
	local function v_u_316(p247, p_u_248, p_u_249, p250, p_u_251, _) -- name: buildCard
		-- upvalues: (copy) v_u_41, (copy) v_u_39, (copy) v_u_38, (copy) v_u_246, (copy) v_u_44, (ref) v_u_55, (copy) v_u_83, (ref) v_u_4, (copy) v_u_45, (copy) v_u_56, (copy) v_u_46, (ref) v_u_49, (ref) v_u_59, (copy) v_u_152, (ref) v_u_47, (copy) p_u_36, (copy) v_u_42, (ref) v_u_133, (copy) v_u_223
		local v252 = v_u_41.card
		local v253 = "Card_" .. p_u_248.id
		local v254 = {}
		local v255
		if p_u_249.equipped then
			v255 = v_u_39.accent
		else
			v255 = nil
		end
		v254.stroke = v255
		v254.strokeTransparency = p_u_249.equipped and 0.2 or nil
		local v_u_256 = v252(p247, v253, p250, v254)
		local v_u_257 = p_u_248.row
		local v258 = not v_u_257 and 4 or v_u_257.rarity
		local v259 = not v_u_257 and "Clan Expansion" or v_u_257.name
		local v260 = not v_u_257 and "Your clan has reached the largest size." or v_u_257.desc
		local v261 = p_u_251.swatch
		local v262 = v_u_38.new("TextButton", {
			["Name"] = "Swatch",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["BackgroundColor3"] = v_u_39.bg,
			["Position"] = UDim2.fromOffset(v261.x, v261.y),
			["Size"] = UDim2.fromOffset(v261.w, v261.h)
		}, v_u_256)
		v_u_38.corner(v262, 6)
		v_u_38.stroke(v262, v_u_39.line, 1, 0.2)
		if v_u_257 then
			v_u_246(v262, v_u_257, p_u_249)
			v_u_41.press(v262, function()
				-- upvalues: (copy) v_u_257, (copy) p_u_249, (ref) v_u_44, (ref) v_u_55, (ref) v_u_83
				local v263 = v_u_257
				local v264 = p_u_249.variant
				if v263 and v_u_44.equippable(v263) then
					v_u_55 = {
						["item"] = v263.id,
						["variant"] = v264
					}
					v_u_83()
				end
			end)
			v262.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_257, (copy) p_u_249, (ref) v_u_44, (ref) v_u_55, (ref) v_u_83
				local v265 = v_u_257
				local v266 = p_u_249.variant
				if v265 and v_u_44.equippable(v265) then
					v_u_55 = {
						["item"] = v265.id,
						["variant"] = v266
					}
					v_u_83()
				end
			end)
		else
			v_u_38.label({
				["parent"] = nil,
				["name"] = "Word",
				["text"] = "MAX",
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v262,
				["color"] = v_u_39.success,
				["size"] = UDim2.fromScale(1, 1)
			})
		end
		v_u_41.text(v_u_256, "Name", v259, p_u_251.name, {
			["style"] = "bodyStrong"
		})
		local v267 = not (v_u_257 and v_u_44.catalog.RARITY_NAMES[v258]) and "MAX" or string.upper(v_u_44.catalog.RARITY_NAMES[v258])
		v_u_41.pill(v_u_256, "Rarity", v267, v_u_4[v258] or v_u_39.text2, p_u_251.pill)
		v_u_41.text(v_u_256, "Desc", v260, p_u_251.desc, {
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["color"] = v_u_39.text2
		}).TextTruncate = Enum.TextTruncate.AtEnd
		if p_u_251.bar then
			v_u_41.text(v_u_256, "BarText", p_u_249.bar.text, p_u_251.barText, {
				["style"] = "micro",
				["color"] = nil,
				["color"] = v_u_39.text
			})
			local v268 = v_u_38.new("Frame", {
				["Name"] = "BarTrack",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_39.bg,
				["Position"] = UDim2.fromOffset(p_u_251.bar.x, p_u_251.bar.y),
				["Size"] = UDim2.fromOffset(p_u_251.bar.w, p_u_251.bar.h)
			}, v_u_256)
			v_u_38.corner(v268, 4)
			local v269 = v_u_38.new
			local v270 = {
				["Name"] = "BarFill",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_39.accent
			}
			local v271 = UDim2.new
			local v272 = p_u_249.bar.value
			v270.Size = v271(math.clamp(v272, 0, 1), 0, 1, 0)
			v269("Frame", v270, v268)
			v_u_41.text(v_u_256, "Conseq", p_u_249.conseq or "", p_u_251.conseq, {
				["style"] = "small",
				["color"] = nil,
				["color"] = v_u_39.text
			})
		end
		if p_u_251.note then
			local v273 = v_u_41.text
			local v274 = "Note"
			local v275 = p_u_249.note
			local v276 = p_u_251.note
			local v277 = {
				["style"] = "small",
				["color"] = nil
			}
			local v278 = p_u_249.noteKind
			local v279
			if v278 == "warn" then
				v279 = v_u_39.accent
			elseif v278 == "success" then
				v279 = v_u_39.success
			else
				v279 = v_u_39.text2
			end
			v277.color = v279
			v273(v_u_256, v274, v275, v276, v277)
		end
		if p_u_251.stepper then
			local v280 = p_u_251.stepper
			local v281 = v_u_41.frame(v_u_256, "Stepper", UDim2.fromOffset(v280.w, v280.h), UDim2.fromOffset(v280.x, v280.y))
			local v282 = v_u_45.stepper(v280.w, v280.h)
			v_u_41.btn({
				["parent"] = nil,
				["text"] = "<",
				["kind"] = "secondary",
				["width"] = nil,
				["maxTextWidth"] = nil,
				["name"] = "Prev",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v281,
				["width"] = v282.prev.w,
				["maxTextWidth"] = v282.prev.w - 20,
				["position"] = UDim2.fromOffset(v282.prev.x, v282.prev.y),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_249, (copy) v_u_257, (ref) v_u_56, (ref) v_u_44, (ref) v_u_55, (ref) v_u_83, (ref) v_u_46
					local v283 = p_u_249.variant + -1
					local v284
					if v283 < 1 then
						v284 = v_u_257.variants
					else
						v284 = v_u_257.variants < v283 and 1 or v283
					end
					v_u_56[v_u_257.id] = v284
					local v285 = v_u_257
					if v285 and v_u_44.equippable(v285) then
						v_u_55 = {
							["item"] = v285.id,
							["variant"] = v284
						}
						v_u_83()
					end
					v_u_46.drawSheet()
				end
			})
			v_u_41.text(v281, "Variant", ("%s  %d/%d"):format(p_u_249.varName or "", p_u_249.variant, v_u_257.variants), v282.label, {
				["style"] = "small",
				["align"] = "center"
			})
			v_u_41.btn({
				["parent"] = nil,
				["text"] = ">",
				["kind"] = "secondary",
				["width"] = nil,
				["maxTextWidth"] = nil,
				["name"] = "Next",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v281,
				["width"] = v282.next.w,
				["maxTextWidth"] = v282.next.w - 20,
				["position"] = UDim2.fromOffset(v282.next.x, v282.next.y),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_249, (copy) v_u_257, (ref) v_u_56, (ref) v_u_44, (ref) v_u_55, (ref) v_u_83, (ref) v_u_46
					local v286 = p_u_249.variant + 1
					local v287
					if v286 < 1 then
						v287 = v_u_257.variants
					else
						v287 = v_u_257.variants < v286 and 1 or v286
					end
					v_u_56[v_u_257.id] = v287
					local v288 = v_u_257
					if v288 and v_u_44.equippable(v288) then
						v_u_55 = {
							["item"] = v288.id,
							["variant"] = v287
						}
						v_u_83()
					end
					v_u_46.drawSheet()
				end
			})
		end
		local function v296(p289, p290, p291, p_u_292) -- name: button
			-- upvalues: (copy) p_u_251, (ref) v_u_41, (copy) v_u_256
			local v293 = p_u_251[p289]
			local v_u_294 = nil
			local _, v295 = v_u_41.btn({
				["parent"] = v_u_256,
				["text"] = p290.text,
				["kind"] = p291,
				["width"] = v293.w,
				["maxTextWidth"] = v293.w - 56,
				["name"] = "Btn_" .. p289,
				["position"] = UDim2.fromOffset(v293.x, v293.y),
				["disabled"] = p290.enabled ~= true,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_292, (ref) v_u_294
					p_u_292(v_u_294)
				end
			})
			local _ = v295
		end
		local v297 = 0
		local v298
		if p_u_249.pending then
			v297 = v297 + 1
			v296("b" .. v297, p_u_249.pending, "secondary", function() end)
			v298 = v297
		else
			v298 = v297
		end
		if p_u_249.equip then
			v297 = v298 + 1
			v296("b" .. v297, p_u_249.equip, p_u_249.equip.off and "secondary" or "primary", function(p_u_299)
				-- upvalues: (copy) v_u_257, (copy) p_u_249, (ref) v_u_44, (ref) v_u_49, (ref) v_u_59, (ref) v_u_152, (ref) v_u_47, (ref) p_u_36, (ref) v_u_42, (ref) v_u_133
				local v300 = v_u_257
				local v301 = p_u_249
				local v302 = {
					["set"] = v_u_44.equipSet(v_u_49, v300, v301.variant, v301.equip.off)
				}
				if not v_u_59 then
					v_u_59 = true
					if p_u_299 then
						p_u_299.busy(true, "...")
					end
					local v_u_303 = nil
					local v_u_304 = nil
					v_u_152("clanShopEquip", v302, function(p305, p306, p307, p308)
						-- upvalues: (ref) v_u_59, (ref) v_u_47, (copy) p_u_299, (copy) v_u_303, (copy) v_u_304, (ref) p_u_36, (ref) v_u_44, (ref) v_u_42, (ref) v_u_133
						v_u_59 = false
						if v_u_47 then
							if p_u_299 then
								local v309 = p_u_299.busy
								pcall(v309, false)
							end
							if p305 then
								if v_u_303 then
									v_u_303()
								end
								if v_u_304 then
									p_u_36.notice(v_u_304, "success", 8)
								end
							else
								local v310 = p_u_36.notice
								local v311 = v_u_44.reason
								if not p308 then
									p308 = {
										["msg"] = p306,
										["data"] = p307
									}
								end
								v310(v311(p308, function(p312)
									-- upvalues: (ref) v_u_42
									return v_u_42.reasonFor(p312)
								end), "warn", 10)
							end
							v_u_133(true)
						end
					end)
				end
			end)
			v298 = v297
		end
		if p_u_249.coin then
			v297 = v298 + 1
			v296("b" .. v297, p_u_249.coin, "primary", function(p313)
				-- upvalues: (ref) v_u_223, (copy) p_u_248, (copy) p_u_249
				v_u_223(p_u_248, p_u_249, "coins", p313)
			end)
			v298 = v297
		end
		if p_u_249.credit then
			v297 = v298 + 1
			v296("b" .. v297, p_u_249.credit, "primary", function(p314)
				-- upvalues: (ref) v_u_223, (copy) p_u_248, (copy) p_u_249
				v_u_223(p_u_248, p_u_249, "credit", p314)
			end)
		elseif p_u_249.robux then
			v297 = v298 + 1
			v296("b" .. v297, p_u_249.robux, "secondary", function(p315)
				-- upvalues: (ref) v_u_223, (copy) p_u_248, (copy) p_u_249
				v_u_223(p_u_248, p_u_249, "robux", p315)
			end)
		end
	end
	function v_u_46.drawSheet() -- name: drawSheet
		-- upvalues: (ref) v_u_47, (copy) v_u_38, (copy) v_u_67, (copy) v_u_40, (ref) v_u_49, (copy) v_u_44, (ref) v_u_54, (copy) p_u_36, (copy) v_u_56, (ref) v_u_57, (copy) v_u_45, (copy) v_u_63, (copy) v_u_43, (copy) v_u_64, (copy) v_u_41, (copy) v_u_46, (copy) v_u_316, (copy) v_u_39
		if v_u_47 then
			v_u_38.keepScroll(v_u_67, function()
				-- upvalues: (ref) v_u_40, (ref) v_u_67, (ref) v_u_49, (ref) v_u_44, (ref) v_u_54, (ref) p_u_36, (ref) v_u_56, (ref) v_u_57, (ref) v_u_45, (ref) v_u_63, (ref) v_u_43, (ref) v_u_64, (ref) v_u_41, (ref) v_u_38, (ref) v_u_46, (ref) v_u_316, (ref) v_u_39
				v_u_40.clear(v_u_67)
				local v317 = v_u_49
				if v317 ~= nil then
					local v318 = v_u_44.visible(v317, v_u_54)
					local v319 = {
						["terminal"] = p_u_36.mc.terminal == true,
						["awaiting"] = {},
						["variants"] = v_u_56
					}
					for v320 in v_u_57 do
						v319.awaiting[v320] = true
					end
					local v321 = {}
					local v322 = {}
					local v323 = false
					for v324, v325 in v318 do
						local v326 = v_u_44.cardState(v325, v317, v319)
						v321[v324] = v326
						v323 = v326.terminal and true or v323
						local v327 = v325.row
						local v328 = {}
						if v326.pending then
							local v329 = v326.pending.text
							table.insert(v328, v329)
						end
						if v326.equip then
							local v330 = v326.equip.text
							table.insert(v328, v330)
						end
						if v326.coin then
							local v331 = v326.coin.text
							table.insert(v328, v331)
						end
						if v326.credit then
							local v332 = v326.credit.text
							table.insert(v328, v332)
						elseif v326.robux then
							local v333 = v326.robux.text
							table.insert(v328, v333)
						end
						local v334 = not (v327 and v_u_44.catalog.RARITY_NAMES[v327.rarity]) and "MAX" or string.upper(v_u_44.catalog.RARITY_NAMES[v327.rarity])
						local v335 = {
							["desc"] = not v327 and "Your clan has reached the largest size." or v327.desc,
							["rarity"] = v334,
							["bar"] = v326.bar ~= nil,
							["conseq"] = v326.conseq,
							["note"] = (v326.note ~= "" or v326.kind == "item") and true or v326.kind == "medal"
						}
						local v336
						if v327 == nil or (v326.kind ~= "item" or v327.variants <= 1) then
							v336 = false
						else
							v336 = v_u_44.equippable(v327)
						end
						v335.stepper = v336
						v335.buttons = v328
						v335.full = v326.kind == "expand" and true or v326.kind == "max"
						v322[v324] = v335
					end
					local v337 = v_u_44.UI.FOOTER
					if p_u_36.mc.terminal == true or v323 then
						v337 = v337 .. " " .. v_u_44.UI.TERMINAL_ROBUX
					end
					if v317.pending > 0 then
						v337 = v337 .. (" %d purchase%s on the way to your clan."):format(v317.pending, v317.pending == 1 and " is" or "s are")
					end
					local v338 = v_u_45.sheet(v_u_63, v_u_43.kind, v_u_64, v322, v337)
					local v339 = v_u_41.frame(v_u_67, "Sheet", UDim2.new(1, -8, 0, v338.height), nil, 1)
					if v338.cats then
						local v340 = v_u_41.frame(v339, "Cats", UDim2.fromOffset(v338.cats.w, v338.cats.h), UDim2.fromOffset(v338.cats.x, v338.cats.y))
						v_u_38.tabs({
							["parent"] = nil,
							["name"] = "CatTabs",
							["tabs"] = nil,
							["selected"] = nil,
							["size"] = nil,
							["onChange"] = nil,
							["parent"] = v340,
							["tabs"] = v_u_44.categories(),
							["selected"] = v_u_54,
							["size"] = UDim2.fromScale(1, 1),
							["onChange"] = function(p341) -- name: onChange
								-- upvalues: (ref) v_u_54, (ref) v_u_46
								v_u_54 = p341
								v_u_46.drawSheet()
							end
						})
					end
					if #v318 == 0 then
						v_u_40.empty(v_u_67, v_u_44.UI.EMPTY_CAT, 2)
					end
					for v342, v343 in v318 do
						local v344 = v338.cards[v342]
						v_u_316(v339, v343, v321[v342], v344.box, v344.parts, v317)
					end
					local v345 = v_u_41.card(v339, "Footer", v338.footer, {
						["fill"] = nil,
						["transparency"] = 0.5,
						["strokeTransparency"] = 0.5,
						["fill"] = v_u_39.bg
					})
					v_u_41.text(v345, "Text", v337, v338.footerText, {
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["valign"] = "top",
						["color"] = v_u_39.text2
					})
				end
			end)
		end
	end
	function v_u_46.draw() -- name: draw
		-- upvalues: (ref) v_u_47, (copy) p_u_36, (copy) v_u_40, (copy) v_u_66, (copy) v_u_67, (copy) v_u_68, (copy) v_u_44, (ref) v_u_49, (ref) v_u_50, (ref) v_u_62, (copy) v_u_128, (copy) v_u_46
		if v_u_47 then
			if p_u_36.clan() == nil then
				v_u_40.clear(v_u_66)
				v_u_40.clear(v_u_67)
				v_u_68.Visible = true
				v_u_68.Text = v_u_44.UI.NO_CLAN
			else
				local v346 = v_u_49 == nil
				v_u_68.Visible = v346
				v_u_66.Visible = not v346
				v_u_67.Visible = not v346
				if v346 then
					local v347 = v_u_68
					local v348
					if v_u_50 == "retry" then
						v348 = v_u_44.UI.LOAD_RETRY
					elseif v_u_50 == "gave_up" then
						v348 = v_u_44.UI.LOAD_FAIL
					else
						v348 = v_u_44.UI.LOADING
					end
					v347.Text = v348
				end
				if v_u_62 then
					local v349 = v_u_62
					if v346 then
						v346 = v_u_50 == "gave_up"
					end
					v349.Visible = v346
				end
				if v_u_49 ~= nil then
					v_u_128()
					v_u_46.drawSheet()
				end
			end
		else
			return
		end
	end
	v_u_133 = function(p_u_350) -- name: load
		-- upvalues: (ref) v_u_52, (ref) v_u_47, (copy) p_u_36, (ref) v_u_3, (ref) v_u_51, (ref) v_u_49, (ref) v_u_50, (copy) v_u_68, (copy) v_u_66, (copy) v_u_67, (copy) v_u_44, (ref) v_u_62, (ref) v_u_48, (ref) v_u_133, (copy) v_u_132, (copy) v_u_46
		if not v_u_52 and (v_u_47 and p_u_36.clan() ~= nil) then
			v_u_52 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_3, (ref) p_u_36, (copy) p_u_350, (ref) v_u_52, (ref) v_u_47, (ref) v_u_51, (ref) v_u_49, (ref) v_u_50, (ref) v_u_68, (ref) v_u_66, (ref) v_u_67, (ref) v_u_44, (ref) v_u_62, (ref) v_u_48, (ref) v_u_133, (ref) v_u_132, (ref) v_u_46
				local v351 = v_u_3.fetch(p_u_36, p_u_350 and 0 or 20)
				v_u_52 = false
				if v_u_47 then
					if v351 == nil then
						v_u_51 = v_u_51 + 1
						if v_u_49 == nil then
							v_u_50 = v_u_51 >= 5 and "gave_up" or "retry"
							local v352 = v_u_49 == nil
							v_u_68.Visible = v352
							v_u_66.Visible = not v352
							v_u_67.Visible = not v352
							if v352 then
								local v353 = v_u_68
								local v354
								if v_u_50 == "retry" then
									v354 = v_u_44.UI.LOAD_RETRY
								elseif v_u_50 == "gave_up" then
									v354 = v_u_44.UI.LOAD_FAIL
								else
									v354 = v_u_44.UI.LOADING
								end
								v353.Text = v354
							end
							if v_u_62 then
								local v355 = v_u_62
								if v352 then
									v352 = v_u_50 == "gave_up"
								end
								v355.Visible = v352
							end
							if v_u_51 < 5 then
								task.delay(2 ^ (v_u_51 - 1) * 3, function()
									-- upvalues: (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_133
									if v_u_47 and (v_u_48 and v_u_49 == nil) then
										v_u_133(true)
									end
								end)
							end
						end
					else
						v_u_51 = 0
						v_u_50 = "ok"
						v_u_132(v351)
						v_u_46.draw()
					end
				else
					return
				end
			end)
		end
	end
	local v360 = v_u_41.btn({
		["parent"] = nil,
		["text"] = "RETRY",
		["kind"] = "secondary",
		["width"] = 140,
		["name"] = "ShopRetry",
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = p37,
		["position"] = UDim2.new(0.5, -70, 0, 70),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_51, (ref) v_u_50, (ref) v_u_49, (copy) v_u_68, (copy) v_u_66, (copy) v_u_67, (copy) v_u_44, (ref) v_u_62, (ref) v_u_133
			v_u_51 = 0
			v_u_50 = "loading"
			local v356 = v_u_49 == nil
			v_u_68.Visible = v356
			v_u_66.Visible = not v356
			v_u_67.Visible = not v356
			if v356 then
				local v357 = v_u_68
				local v358
				if v_u_50 == "retry" then
					v358 = v_u_44.UI.LOAD_RETRY
				elseif v_u_50 == "gave_up" then
					v358 = v_u_44.UI.LOAD_FAIL
				else
					v358 = v_u_44.UI.LOADING
				end
				v357.Text = v358
			end
			if v_u_62 then
				local v359 = v_u_62
				if v356 then
					v356 = v_u_50 == "gave_up"
				end
				v359.Visible = v356
			end
			v_u_133(true)
		end
	})
	v360.Visible = false
	v_u_62 = v360
	function v_u_46.show() -- name: show
		-- upvalues: (ref) v_u_48, (copy) p_u_36, (ref) v_u_54, (copy) v_u_46, (ref) v_u_133
		v_u_48 = true
		if p_u_36.shopCat ~= nil then
			v_u_54 = p_u_36.shopCat
			p_u_36.shopCat = nil
		end
		v_u_46.draw()
		v_u_133(true)
	end
	function v_u_46.hide() -- name: hide
		-- upvalues: (ref) v_u_48
		v_u_48 = false
	end
	function v_u_46.refresh(p361) -- name: refresh
		-- upvalues: (copy) v_u_46
		if p361 == "state" then
			v_u_46.draw()
		end
	end
	function v_u_46.tick() -- name: tick
		-- upvalues: (ref) v_u_57, (ref) v_u_48, (ref) v_u_58, (ref) v_u_133, (ref) v_u_49, (ref) v_u_53
		local v362 = os.clock()
		for v363, v364 in v_u_57 do
			if v362 - (v364.at or 0) <= 180 then
				continue
			end
			v_u_57[v363] = nil
		end
		if v_u_48 and (next(v_u_57) ~= nil and v362 - v_u_58 > 4) then
			v_u_58 = v362
			v_u_133(true)
		elseif v_u_48 and (v_u_49 ~= nil and v362 - v_u_53 > 45) then
			v_u_53 = v362
			v_u_133(false)
		end
	end
	function v_u_46.destroy() -- name: destroy
		-- upvalues: (ref) v_u_47, (ref) v_u_60
		v_u_47 = false
		if v_u_60 ~= nil then
			local function v365()
				-- upvalues: (ref) v_u_60
				v_u_60:Disconnect()
			end
			pcall(v365)
			v_u_60 = nil
		end
	end
	task.spawn(function()
		-- upvalues: (copy) p_u_36, (ref) v_u_47, (copy) v_u_38, (ref) v_u_57, (ref) v_u_133, (ref) v_u_60
		local function v369()
			-- upvalues: (ref) p_u_36, (ref) v_u_47, (ref) v_u_38, (ref) v_u_57, (ref) v_u_133
			return p_u_36.cctx.net.listen("clan.note", function(p366)
				-- upvalues: (ref) v_u_47, (ref) v_u_38, (ref) v_u_57, (ref) v_u_133
				if v_u_47 and (type(p366) == "table" and (p366.k == "shop" or p366.k == "expand")) then
					local v367 = v_u_38.toast
					local v368 = p366.k == "expand" and "Your clan was expanded." or "Added to your clan."
					pcall(v367, v368, "success")
					v_u_57 = {}
					v_u_133(true)
				end
			end)
		end
		local v370, v_u_371 = pcall(v369)
		if v370 and v_u_371 ~= nil then
			if v_u_47 then
				v_u_60 = v_u_371
				return
			end
			pcall(function()
				-- upvalues: (copy) v_u_371
				v_u_371:Disconnect()
			end)
		end
	end)
	v_u_46.draw()
	return v_u_46
end
return v_u_3