-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FenceVault

local v1 = game:GetService("Players")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = 0
local v_u_10 = 0
local v_u_11 = nil
local v_u_12 = 0
local v_u_13 = {
	["started"] = 0,
	["landed"] = 0,
	["denied"] = 0,
	["aborted"] = 0,
	["lastMs"] = 0,
	["minMs"] = (1 / 0),
	["maxMs"] = 0
}
local v_u_14 = RaycastParams.new()
v_u_14.FilterType = Enum.RaycastFilterType.Exclude
v_u_14.IgnoreWater = true
v_u_14.RespectCanCollide = true
local v_u_15 = {
	["Bandage"] = true,
	["Use"] = true,
	["Search"] = true,
	["Revive"] = true,
	["Unlock"] = true,
	["Climb"] = true,
	["Vault"] = true,
	["Extract"] = true
}
local function v_u_22(p16, p17) -- name: rootHeight
	-- upvalues: (copy) v_u_14
	v_u_14.FilterDescendantsInstances = { p17, (workspace:FindFirstChild("HushLocal")) }
	local v18 = workspace:Raycast(p16.Position, Vector3.new(0, -12, 0), v_u_14)
	local v19 = p17:FindFirstChildOfClass("Humanoid")
	local v20 = (not v19 and 2 or v19.HipHeight) + p16.Size.Y / 2
	if not v18 then
		return v20
	end
	local v21 = p16.Position.Y - v18.Position.Y
	return math.clamp(v21, 1.5, 5)
end
local function v_u_29() -- name: able
	-- upvalues: (copy) v_u_4, (ref) v_u_11, (ref) v_u_10, (copy) v_u_15, (ref) v_u_3
	if v_u_4:GetAttribute("Place") == "Raid" then
		local v23 = v_u_4.Character
		local v24 = v_u_4.Character
		if v24 then
			v24 = v24:FindFirstChild("HumanoidRootPart")
		end
		if v23 and v24 then
			if v23:GetAttribute("Dead") == true or v23:GetAttribute("Downed") == true then
				return false, "downed"
			elseif v_u_11 or os.clock() < v_u_10 then
				return false, "busy"
			else
				local v25 = v23:GetAttribute("Action")
				local v26 = v_u_4:GetAttribute("PredAction")
				local v27 = v_u_4:GetAttribute("PredActionEnds")
				if type(v25) == "string" and v_u_15[v25] or type(v26) == "string" and (v_u_15[v26] and (type(v27) == "number" and os.clock() < v27)) then
					return false, "action"
				else
					local v28 = v_u_3
					if v28 then
						v28 = v_u_3.lib.DoorClient
					end
					if v28 and (v28.climbing and v28.climbing()) then
						return false, "climbing"
					else
						return true, nil
					end
				end
			end
		else
			return false, "nochar"
		end
	else
		return false, "place"
	end
end
local function v_u_33() -- name: ensureHolder
	-- upvalues: (ref) v_u_6, (ref) v_u_7
	if v_u_6 and (v_u_6.Parent and (v_u_7 and v_u_7.Parent == v_u_6)) then
		return v_u_6, v_u_7
	end
	local v30 = workspace:FindFirstChild("HushLocal")
	if not v30 then
		v30 = Instance.new("Folder")
		v30.Name = "HushLocal"
		v30.Parent = workspace
	end
	local v31 = Instance.new("Part")
	v31.Name = "VaultPromptHolder"
	v31.Anchored = true
	v31.CanCollide = false
	v31.CanQuery = false
	v31.CanTouch = false
	v31.Transparency = 1
	v31.Size = Vector3.new(0.2, 0.2, 0.2)
	v31.CFrame = CFrame.new(0, -500, 0)
	local v32 = Instance.new("ProximityPrompt")
	v32.Name = "VaultPrompt"
	v32.Style = Enum.ProximityPromptStyle.Custom
	v32.ActionText = "Vault over"
	v32.ObjectText = "Low fence"
	v32.HoldDuration = 0
	v32.MaxActivationDistance = 7
	v32.RequiresLineOfSight = false
	v32.Enabled = false
	v32:SetAttribute("Kind", "vault")
	v32:SetAttribute("Priority", -2)
	v32.Parent = v31
	v31.Parent = v30
	v_u_6 = v31
	v_u_7 = v32
	return v31, v32
end
local v_u_34 = 0
local function v_u_45(p35) -- name: offer
	-- upvalues: (ref) v_u_8, (copy) v_u_33, (copy) v_u_4
	v_u_8 = p35
	local v36, v37 = v_u_33()
	if v36 and v37 then
		if p35 and p35.high then
			if v37.ActionText ~= "High fence" then
				v37.ActionText = "High fence"
				v37.ObjectText = "Too high to climb"
			end
			v37:SetAttribute("VaultKind", "high")
			v36.CFrame = CFrame.new(p35.pos)
			v37.Enabled = true
			local v38 = string.format("high %.1f", p35.dist)
			if v_u_4:GetAttribute("VaultOffer") ~= v38 then
				v_u_4:SetAttribute("VaultOffer", v38)
			end
			return
		else
			if v37.ActionText ~= "Vault over" then
				v37.ActionText = "Vault over"
				v37.ObjectText = "Low fence"
			end
			v37:SetAttribute("VaultKind", "low")
			if p35 then
				local v39 = string.format("low %.1f", p35.dist)
				if v_u_4:GetAttribute("VaultOffer") ~= v39 then
					v_u_4:SetAttribute("VaultOffer", v39)
				end
				local v40 = v_u_4.Character
				if v40 then
					v40 = v40:FindFirstChild("HumanoidRootPart")
				end
				local v41
				if v40 then
					local v42 = v40.Position.X - p35.over.X
					local v43 = v40.Position.Z - p35.over.Z
					v41 = Vector3.new(v42, 0, v43)
				else
					v41 = Vector3.new(0, 0, 0)
				end
				local v44
				if v41.Magnitude > 0.05 then
					v44 = p35.over + v41.Unit * 0.45
				else
					v44 = p35.over
				end
				v36.CFrame = CFrame.new(v44.X, p35.over.Y - 0.6, v44.Z)
				v37.Enabled = true
			else
				v37.Enabled = false
				v36.CFrame = CFrame.new(0, -500, 0)
				if v_u_4:GetAttribute("VaultOffer") ~= "" then
					v_u_4:SetAttribute("VaultOffer", "")
				end
			end
		end
	else
		return
	end
end
local function v_u_71() -- name: scan
	-- upvalues: (copy) v_u_29, (copy) v_u_4, (ref) v_u_8, (copy) v_u_33, (ref) v_u_3, (ref) v_u_5, (copy) v_u_22, (copy) v_u_45
	local v46 = v_u_29()
	local v47 = v_u_4.Character
	if v47 then
		v47 = v47:FindFirstChild("HumanoidRootPart")
	end
	local v48 = v_u_4.Character
	if v46 and (v47 and v48) then
		local v49 = nil
		local v50 = v_u_3
		if v50 then
			v50 = v_u_3.controllers.Input
		end
		local v51
		if v50 and v50.aimDir then
			local v52 = v50.aimDir
			local v53
			v53, v51 = pcall(v52)
			if v53 then
				if typeof(v51) ~= "Vector3" then
					v51 = v49
				end
			else
				v51 = v49
			end
		else
			v51 = v49
		end
		local v54 = v_u_5.nearest
		local v55 = v47.Position
		local v56 = v_u_22(v47, v48)
		local v57 = v_u_5.SHOW
		local v58, v59 = pcall(v54, v55, v56, v57, v51)
		if v58 and v59 then
			v_u_45(v59)
			return
		else
			local v60 = v_u_5.nearestHigh
			local v61 = v47.Position
			local v62 = v_u_5.HIGH_SHOW
			local v63, v64, v65, v66 = pcall(v60, v61, v62, v51)
			if v63 and (v64 and v65) then
				v_u_45({
					["high"] = true,
					["board"] = nil,
					["pos"] = nil,
					["dist"] = nil,
					["board"] = v64.board,
					["pos"] = v65,
					["dist"] = v66 or 0
				})
			else
				v_u_8 = nil
				local v67, v68 = v_u_33()
				if v67 then
					if not v68 then
						return
					end
					if v68.ActionText ~= "Vault over" then
						v68.ActionText = "Vault over"
						v68.ObjectText = "Low fence"
					end
					v68:SetAttribute("VaultKind", "low")
					v68.Enabled = false
					v67.CFrame = CFrame.new(0, -500, 0)
					if v_u_4:GetAttribute("VaultOffer") ~= "" then
						v_u_4:SetAttribute("VaultOffer", "")
					end
				end
			end
		end
	else
		if v_u_8 then
			v_u_8 = nil
			local v69, v70 = v_u_33()
			if v69 then
				if not v70 then
					return
				end
				if v70.ActionText ~= "Vault over" then
					v70.ActionText = "Vault over"
					v70.ObjectText = "Low fence"
				end
				v70:SetAttribute("VaultKind", "low")
				v70.Enabled = false
				v69.CFrame = CFrame.new(0, -500, 0)
				if v_u_4:GetAttribute("VaultOffer") ~= "" then
					v_u_4:SetAttribute("VaultOffer", "")
				end
			end
		end
		return
	end
end
function v_u_2.prompt() -- name: prompt
	-- upvalues: (ref) v_u_8, (ref) v_u_7
	if v_u_8 and (v_u_7 and v_u_7.Enabled) then
		return v_u_7
	else
		return nil
	end
end
function v_u_2.isPrompt(p72) -- name: isPrompt
	-- upvalues: (ref) v_u_7
	local v73
	if p72 == nil then
		v73 = false
	else
		v73 = p72 == v_u_7
	end
	return v73
end
function v_u_2.vaulting() -- name: vaulting
	-- upvalues: (ref) v_u_11
	return v_u_11 ~= nil
end
function v_u_2.trigger() -- name: trigger
	-- upvalues: (copy) v_u_29, (copy) v_u_4, (ref) v_u_8, (ref) v_u_34, (ref) v_u_3, (copy) v_u_22, (ref) v_u_5, (ref) v_u_12, (ref) v_u_11, (copy) v_u_13, (copy) v_u_33
	local v74, v75 = v_u_29()
	if not v74 then
		v_u_4:SetAttribute("VaultLast", "refused " .. tostring(v75))
		return false, v75
	end
	local v_u_76 = v_u_4.Character
	if v_u_76 then
		v_u_76 = v_u_76:FindFirstChild("HumanoidRootPart")
	end
	local v77 = v_u_4.Character
	if not (v_u_76 and v77) then
		return false, "nochar"
	end
	if v_u_8 and v_u_8.high then
		v_u_4:SetAttribute("VaultLast", "refused high")
		if os.clock() - v_u_34 > 2 then
			v_u_34 = os.clock()
			local v78 = v_u_3
			if v78 then
				v78 = v_u_3.lib.HushUI
			end
			if v78 and v78.toast then
				local v79 = v78.toast
				pcall(v79, "High fence", "info", "Too high to climb. Find a gap or a low fence.")
			end
		end
		return false, "high"
	end
	local v80 = v_u_8
	if v80 then
		v80 = v_u_8.board
	end
	local v81 = v_u_22(v_u_76, v77)
	local v_u_82, v83
	if v80 and v80.Parent then
		v_u_82, v83 = v_u_5.plan(v80, v_u_76.Position, v81, v_u_5.SHOW + 0.4)
	else
		v_u_82 = nil
		v83 = nil
	end
	if not v_u_82 then
		v_u_82, v83 = v_u_5.nearest(v_u_76.Position, v81, v_u_5.SHOW + 0.4, nil)
	end
	if not v_u_82 then
		v_u_4:SetAttribute("VaultLast", "refused " .. tostring(v83 or "nofence"))
		return false, v83 or "nofence"
	end
	local v84 = v_u_82.p2.X - v_u_76.Position.X
	local v85 = v_u_82.p2.Z - v_u_76.Position.Z
	local v86 = Vector3.new(v84, 0, v85)
	if v86.Magnitude < 0.1 then
		return false, "here"
	end
	v_u_12 = v_u_12 + 1
	local function v87()
		-- upvalues: (ref) v_u_3, (ref) v_u_82, (copy) v_u_76, (ref) v_u_12
		v_u_3.net.fire("char.vault", {
			["board"] = v_u_82.board,
			["from"] = v_u_76.Position,
			["seq"] = v_u_12
		})
	end
	pcall(v87)
	v_u_11 = {
		["t0"] = os.clock(),
		["p0"] = v_u_76.Position,
		["p1"] = v_u_82.p1,
		["p2"] = v_u_82.p2,
		["look"] = v86.Unit,
		["root"] = v_u_76,
		["board"] = v_u_82.board,
		["seq"] = v_u_12
	}
	local v88 = v_u_13
	v88.started = v88.started + 1
	v_u_4:SetAttribute("PredAction", "Vault")
	v_u_4:SetAttribute("PredActionEnds", os.clock() + v_u_5.TIME + 0.1)
	v_u_8 = nil
	local v89, v90 = v_u_33()
	if v89 and v90 then
		if v90.ActionText ~= "Vault over" then
			v90.ActionText = "Vault over"
			v90.ObjectText = "Low fence"
		end
		v90:SetAttribute("VaultKind", "low")
		v90.Enabled = false
		v89.CFrame = CFrame.new(0, -500, 0)
		if v_u_4:GetAttribute("VaultOffer") ~= "" then
			v_u_4:SetAttribute("VaultOffer", "")
		end
	end
	local v91 = v_u_76.Position
	local v92 = {
		["volume"] = 0.6
	}
	local v93 = v_u_3
	if v93 then
		v93 = v_u_3.controllers.Audio
	end
	if v93 and v93.play3D then
		local v94 = v93.play3D
		pcall(v94, "cloth", v91, v92)
	end
	local v95 = v_u_82.over
	local v96 = {
		["volume"] = 0.45,
		["delay"] = 0.3
	}
	local v97 = v_u_3
	if v97 then
		v97 = v_u_3.controllers.Audio
	end
	if v97 and v97.play3D then
		local v98 = v97.play3D
		pcall(v98, "step_wood", v95, v96)
	end
	v_u_4:SetAttribute("VaultLast", string.format("started #%d dist %.2f", v_u_12, v_u_82.dist))
	return true, nil
end
local function v_u_119(p99) -- name: finish
	-- upvalues: (ref) v_u_11, (copy) v_u_4, (ref) v_u_3, (ref) v_u_10, (copy) v_u_13
	local v100 = v_u_11
	v_u_11 = nil
	if v_u_4:GetAttribute("PredAction") == "Vault" then
		v_u_4:SetAttribute("PredAction", nil)
		v_u_4:SetAttribute("PredActionEnds", nil)
	end
	local v101 = v_u_3 and v_u_3.shared
	if v101 then
		v101 = v_u_3.shared.Skills
	end
	local v102
	if v101 and v101.perkOf then
		v102 = v101.perkOf(v_u_4)
	else
		v102 = nil
	end
	local v103
	if type(v102) == "table" then
		local v104 = v102.vaultLockMul
		if type(v104) == "number" then
			local v105 = v102.vaultLockMul
			v103 = math.clamp(v105, 0.3, 1)
		else
			v103 = 1
		end
	else
		v103 = 1
	end
	v_u_10 = os.clock() + v103 * 0.25
	if v100 and p99 then
		local v106 = v_u_13
		v106.landed = v106.landed + 1
		local v107 = v_u_13
		local v108 = (os.clock() - v100.t0) * 1000 + 0.5
		v107.lastMs = math.floor(v108)
		local v109 = v_u_13
		local v110 = v_u_13.minMs
		local v111 = v_u_13.lastMs
		v109.minMs = math.min(v110, v111)
		local v112 = v_u_13
		local v113 = v_u_13.maxMs
		local v114 = v_u_13.lastMs
		v112.maxMs = math.max(v113, v114)
		local v115 = v100.p2
		local v116 = {
			["volume"] = 0.5
		}
		local v117 = v_u_3
		if v117 then
			v117 = v_u_3.controllers.Audio
		end
		if v117 and v117.play3D then
			local v118 = v117.play3D
			pcall(v118, "step_wood", v115, v116)
		end
	end
end
local function v_u_127() -- name: stepRun
	-- upvalues: (ref) v_u_11, (copy) v_u_4, (copy) v_u_13, (copy) v_u_119, (ref) v_u_5
	local v120 = v_u_11
	if v120 then
		local v121 = v_u_4.Character
		if v120.root.Parent and (v121 and (v121:GetAttribute("Dead") ~= true and v121:GetAttribute("Downed") ~= true)) then
			local v122 = (os.clock() - v120.t0) / v_u_5.TIME
			local v123 = math.clamp(v122, 0, 1)
			local v124 = v123 * v123 * (3 - v123 * 2)
			local v125 = v120.p0:Lerp(v120.p1, v124):Lerp(v120.p1:Lerp(v120.p2, v124), v124)
			v120.root.CFrame = CFrame.lookAt(v125, v125 + v120.look)
			v120.root.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			if v123 >= 1 then
				v_u_119(true)
			end
		else
			local v126 = v_u_13
			v126.aborted = v126.aborted + 1
			v_u_119(false)
		end
	else
		return
	end
end
local function v_u_136(p128) -- name: onDeny
	-- upvalues: (copy) v_u_13, (copy) v_u_4, (ref) v_u_11, (copy) v_u_119
	if type(p128) == "table" then
		local v129 = v_u_13
		v129.denied = v129.denied + 1
		local v130 = v_u_4
		local v131 = p128.why
		local v132 = tostring(v131)
		local v133 = p128.seq
		v130:SetAttribute("VaultLast", "deny " .. v132 .. " #" .. tostring(v133))
		local v134 = v_u_11
		if v134 and (p128.seq == nil or p128.seq == v134.seq) then
			if v134.root.Parent then
				v134.root.CFrame = CFrame.lookAt(v134.p0, v134.p0 + v134.look)
				v134.root.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			end
			local v135 = v_u_13
			v135.aborted = v135.aborted + 1
			v_u_119(false)
		end
	end
end
function v_u_2.init(p137) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_4, (copy) v_u_29, (ref) v_u_8, (ref) v_u_11, (copy) v_u_13, (copy) v_u_71, (copy) v_u_2
	v_u_3 = p137
	v_u_5 = p137.shared.FenceGeo
	p137.command("vault.state", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_29, (ref) v_u_8, (ref) v_u_11, (ref) v_u_13
		local v138 = v_u_4.Character
		if v138 then
			v138 = v138:FindFirstChild("HumanoidRootPart")
		end
		local v139, v140 = v_u_29()
		local v141 = v_u_8
		local v142 = string.format
		local v143 = tostring(v139)
		local v144 = tostring(v140)
		local v145 = v141 ~= nil
		local v146 = tostring(v145)
		local v147 = not v141 and "-" or v141.board:GetFullName()
		local v148 = not v141 and "-" or string.format("%.2f", v141.dist)
		local v149 = v_u_11 ~= nil
		local v150 = v_u_4
		return v142("able=%s(%s) offer=%s board=%s dist=%s vaulting=%s started=%d landed=%d denied=%d aborted=%d ms=%d (min %d max %d) last=%s root=%s", v143, v144, v146, v147, v148, tostring(v149), v_u_13.started, v_u_13.landed, v_u_13.denied, v_u_13.aborted, v_u_13.lastMs, v_u_13.minMs == (1 / 0) and 0 or v_u_13.minMs, v_u_13.maxMs, tostring(v150:GetAttribute("VaultLast")), not v138 and "-" or string.format("%.1f,%.1f,%.1f", v138.Position.X, v138.Position.Y, v138.Position.Z))
	end)
	p137.command("vault.go", function()
		-- upvalues: (ref) v_u_71, (ref) v_u_2
		v_u_71()
		local v151, v152 = v_u_2.trigger()
		return "vault " .. tostring(v151) .. " " .. tostring(v152)
	end)
end
function v_u_2.start() -- name: start
	-- upvalues: (ref) v_u_3, (copy) v_u_136, (copy) v_u_4, (ref) v_u_11, (ref) v_u_8, (copy) v_u_33
	local v_u_153 = v_u_3
	if v_u_153 then
		v_u_153 = v_u_3.net
	end
	if v_u_153 and v_u_153.listen then
		task.spawn(function()
			-- upvalues: (copy) v_u_153, (ref) v_u_136
			local v154 = v_u_153.listen
			local v155 = v_u_136
			pcall(v154, "char.vaultDeny", v155)
		end)
	end
	v_u_4.CharacterRemoving:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_33
		v_u_11 = nil
		if v_u_4:GetAttribute("PredAction") == "Vault" then
			v_u_4:SetAttribute("PredAction", nil)
			v_u_4:SetAttribute("PredActionEnds", nil)
		end
		v_u_8 = nil
		local v156, v157 = v_u_33()
		if v156 then
			if not v157 then
				return
			end
			if v157.ActionText ~= "Vault over" then
				v157.ActionText = "Vault over"
				v157.ObjectText = "Low fence"
			end
			v157:SetAttribute("VaultKind", "low")
			v157.Enabled = false
			v156.CFrame = CFrame.new(0, -500, 0)
			if v_u_4:GetAttribute("VaultOffer") ~= "" then
				v_u_4:SetAttribute("VaultOffer", "")
			end
		end
	end)
end
function v_u_2.step(_) -- name: step
	-- upvalues: (copy) v_u_127, (ref) v_u_9, (copy) v_u_71, (copy) v_u_4
	v_u_127()
	local v158 = os.clock()
	if v_u_9 <= v158 then
		v_u_9 = v158 + 0.15
		local v159 = v_u_71
		local v160, v161 = pcall(v159)
		if not v160 then
			v_u_4:SetAttribute("ClientError", "FenceVault.scan: " .. tostring(v161))
		end
	end
end
return v_u_2