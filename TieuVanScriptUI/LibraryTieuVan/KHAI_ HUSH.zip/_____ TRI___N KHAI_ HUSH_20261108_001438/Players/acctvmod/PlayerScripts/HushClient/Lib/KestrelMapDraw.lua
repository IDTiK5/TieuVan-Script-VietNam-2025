-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KestrelMapDraw

local v_u_1 = game:GetService("TextService")
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v3, v_u_4 = pcall(function()
	return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapTagPlace", 5)))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v_u_5 = {}
local v6, v_u_7 = pcall(function()
	return require((script.Parent:WaitForChild("KestrelMapData", 5)))
end)
if not v6 or type(v_u_7) ~= "table" then
	v_u_7 = nil
end
local v8, v9 = pcall(function()
	return require((script.Parent:WaitForChild("MapDraw", 5)))
end)
local v10 = nil
if v8 and type(v9) == "table" then
	local v11 = v9.INK
	if type(v11) == "table" then
		v10 = v9.INK
	end
end
local v_u_12 = {
	["paper"] = Color3.fromHex("D8CDB2"),
	["paperLight"] = Color3.fromHex("E6DCC4"),
	["paperEdge"] = Color3.fromHex("A99C7E"),
	["crease"] = Color3.fromHex("BDB091"),
	["grid"] = Color3.fromHex("C3B697"),
	["ink"] = Color3.fromHex("372F26"),
	["inkSoft"] = Color3.fromHex("6A5E4C"),
	["field"] = Color3.fromHex("CFC598"),
	["park"] = Color3.fromHex("B9BE92"),
	["forest"] = Color3.fromHex("B4B98F"),
	["tree"] = Color3.fromHex("7C8758"),
	["water"] = Color3.fromHex("8DA4AE"),
	["waterInk"] = Color3.fromHex("44606E"),
	["bank"] = Color3.fromHex("BDC0A6"),
	["lot"] = Color3.fromHex("C6BCA5"),
	["road"] = Color3.fromHex("F0E8D4"),
	["roadCase"] = Color3.fromHex("5D5345"),
	["highway"] = Color3.fromHex("F2DFA9"),
	["build"] = Color3.fromHex("8C806D"),
	["buildEdge"] = Color3.fromHex("4A4136"),
	["landmark"] = Color3.fromHex("9C4B39"),
	["landmarkEdge"] = Color3.fromHex("5E2A1F"),
	["red"] = Color3.fromHex("B0322A"),
	["redDeep"] = Color3.fromHex("7E2019"),
	["green"] = Color3.fromHex("3E6E4A")
}
if v10 then
	for v13, v14 in v10 do
		v_u_12[v13] = v14
	end
end
v_u_12.tarmac = Color3.fromHex("A0967F")
v_u_12.taxi = Color3.fromHex("C3B9A0")
v_u_12.apron = Color3.fromHex("D0C6AD")
v_u_12.padConcrete = Color3.fromHex("C8BEA7")
v_u_12.padAsphalt = Color3.fromHex("BBB19A")
v_u_12.padGravel = Color3.fromHex("CDC0A0")
v_u_12.padDirt = Color3.fromHex("C4AE88")
v_u_12.tent = Color3.fromHex("DDD3B9")
v_u_5.INK = v_u_12
v_u_5.KEY = {
	{ "landmark", "Landmark" },
	{ "build", "Building" },
	{ "forest", "Woods" },
	{ "tarmac", "Runway" },
	{ "road", "Road" }
}
function v_u_5.available() -- name: available
	-- upvalues: (ref) v_u_7
	local v15
	if v_u_7 == nil then
		v15 = false
	else
		local v16 = v_u_7.LOTS
		if type(v16) == "table" and #v_u_7.LOTS > 0 then
			local v17 = v_u_7.HALF
			v15 = type(v17) == "number"
		else
			v15 = false
		end
	end
	return v15
end
function v_u_5.data() -- name: data
	-- upvalues: (ref) v_u_7
	return v_u_7
end
function v_u_5.placeOf(p18) -- name: placeOf
	-- upvalues: (ref) v_u_7
	if v_u_7 then
		local v19 = v_u_7.PLACES
		if type(v19) == "table" and type(p18) == "string" then
			local v20 = v_u_7.PLACES[string.lower(p18)]
			if type(v20) == "table" then
				return v20[1], v20[2], v20[3]
			else
				return nil, nil, nil
			end
		end
	end
	return nil, nil, nil
end
local function v_u_33(p21, p22, p23, p24, p25, p26, p27) -- name: text
	-- upvalues: (ref) v_u_12
	local v28 = Instance.new("TextLabel")
	v28.Name = "Txt"
	v28.BackgroundTransparency = 1
	v28.AnchorPoint = Vector2.new(0.5, 0.5)
	v28.Position = UDim2.fromOffset(p23.X, p23.Y)
	local v29 = UDim2.fromOffset
	local v30 = (utf8.len(p22) or #p22) * p24 * 0.62 + 8
	v28.Size = v29(math.max(20, v30), p24 + 4)
	v28.FontFace = p25
	v28.TextSize = p24
	v28.TextColor3 = p26
	v28.TextStrokeColor3 = v_u_12.paper
	v28.TextStrokeTransparency = 0.25
	v28.Text = p22
	v28.TextTruncate = Enum.TextTruncate.AtEnd
	if p27 then
		for v31, v32 in p27 do
			v28[v31] = v32
		end
	end
	v28.Parent = p21
	return v28
end
local function v_u_39(p34) -- name: spaced
	local v35 = utf8.char(8202)
	local v36 = {}
	for _, v37 in utf8.codes(string.upper(p34)) do
		local v38 = utf8.char
		table.insert(v36, v38(v37))
	end
	return table.concat(v36, v35)
end
local v_u_40 = {
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G"
}
function v_u_5.gridRef(p41, p42) -- name: gridRef
	-- upvalues: (ref) v_u_7, (copy) v_u_40
	local v43 = not v_u_7 and 700 or v_u_7.HALF
	local v44 = v43 * 2 / 200 + 0.5
	local v45 = math.floor(v44)
	local v46 = (p41 + v43) / 200
	local v47 = math.floor(v46) + 1
	local v48 = math.clamp(v47, 1, v45)
	local v49 = (p42 + v43) / 200
	local v50 = math.floor(v49) + 1
	local v51 = math.clamp(v50, 1, v45)
	return (v_u_40[v48] or "?") .. tostring(v51)
end
function v_u_5.build(p52, p53, p54, p55, p_u_56) -- name: build
	-- upvalues: (ref) v_u_7, (copy) v_u_33, (copy) v_u_2, (ref) v_u_12, (ref) v_u_4, (copy) v_u_39, (copy) v_u_40, (copy) v_u_1, (copy) v_u_5
	local v57 = v_u_7
	assert(v57, "KestrelMapData missing")
	local v_u_58 = v_u_33
	local v59
	if p_u_56 then
		v59 = p_u_56.phone
	else
		v59 = v_u_2.isPhone()
	end
	local v_u_60 = v_u_7.HALF
	local v_u_61 = v_u_7.FENCE_HALF
	local v62 = p53 * 0.035
	local v63 = math.floor(v62)
	local v_u_64 = p53 - v63 * 2
	local v_u_65 = v_u_64 / (v_u_60 * 2)
	local v_u_66 = p53 / 880
	local v67 = p55 and p55.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
	local v68 = p55 and p55.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v69 = p55 and p55.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v70 = p55 and p55.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v71 = {
		["Name"] = "Sheet",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_12.paper,
		["Size"] = UDim2.fromOffset(p53, p53)
	}
	local v72 = Instance.new("Frame")
	v72.BorderSizePixel = 0
	local v_u_73 = 0
	local v_u_74 = 0
	for v75, v76 in v71 do
		v72[v75] = v76
	end
	v72.Parent = p52
	local v77 = v_u_12.paperEdge
	local v78 = Instance.new("UIStroke")
	v78.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v78.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v78.Color = v77
	v78.Thickness = 2
	v78.Transparency = 0
	v78.Parent = v72
	local v79 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v_u_12.paperLight,
		["Position"] = UDim2.fromOffset(v63, v63),
		["Size"] = UDim2.fromOffset(v_u_64, v_u_64)
	}
	local v80 = Instance.new("Frame")
	v80.BorderSizePixel = 0
	for v81, v82 in v79 do
		v80[v81] = v82
	end
	v80.Parent = v72
	local v83 = v_u_12.ink
	local v84 = Instance.new("UIStroke")
	v84.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v84.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v84.Color = v83
	v84.Thickness = 1
	v84.Transparency = 0
	v84.Parent = v80
	local function v_u_99(p85, p86, p87, p88, p89, p90) -- name: seg
		-- upvalues: (ref) v_u_73
		local v91 = p87 - p86
		v_u_73 = v_u_73 + 1
		local v92 = {
			["Name"] = "Seg",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = p89,
			["BackgroundTransparency"] = p90 or 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset((p86.X + p87.X) / 2, (p86.Y + p87.Y) / 2),
			["Size"] = UDim2.fromOffset(v91.Magnitude + p88 * 0.5, p88)
		}
		local v93 = v91.Y
		local v94 = v91.X
		local v95 = math.atan2(v93, v94)
		v92.Rotation = math.deg(v95)
		local v96 = Instance.new("Frame")
		v96.BorderSizePixel = 0
		for v97, v98 in v92 do
			v96[v97] = v98
		end
		v96.Parent = p85
		return v96
	end
	local v100 = {
		["Name"] = "Ground",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v101 = Instance.new("Frame")
	v101.BorderSizePixel = 0
	local function v129(p102, p103, p104, p105, p106, p107, p108) -- name: rect
		-- upvalues: (copy) v_u_60, (copy) v_u_65, (ref) v_u_73
		local v109 = math.min(p103, p105)
		local v110 = math.min(p104, p106)
		local v111 = Vector2.new((v109 + v_u_60) * v_u_65, (v110 + v_u_60) * v_u_65)
		local v112 = math.max(p103, p105)
		local v113 = math.max(p104, p106)
		local v114 = Vector2.new((v112 + v_u_60) * v_u_65, (v113 + v_u_60) * v_u_65)
		v_u_73 = v_u_73 + 1
		local v115 = {
			["BackgroundColor3"] = p107,
			["BackgroundTransparency"] = p108 or 0
		}
		local v116 = UDim2.fromOffset
		local v117 = v111.X
		local v118 = math.floor(v117)
		local v119 = v111.Y
		v115.Position = v116(v118, (math.floor(v119)))
		local v120 = UDim2.fromOffset
		local v121 = v114.X - v111.X
		local v122 = math.ceil(v121)
		local v123 = math.max(1, v122)
		local v124 = v114.Y - v111.Y
		local v125 = math.ceil(v124)
		v115.Size = v120(v123, (math.max(1, v125)))
		local v126 = Instance.new("Frame")
		v126.BorderSizePixel = 0
		for v127, v128 in v115 do
			v126[v127] = v128
		end
		v126.Parent = p102
		return v126
	end
	local function v_u_144(p130, p131, p132, p133, p134, p135, p136, p137) -- name: dashed
		-- upvalues: (copy) v_u_99
		local v138 = p132 - p131
		local v139 = v138.Magnitude
		if v139 >= 1 then
			local v140 = v138 / v139
			local v141 = 0
			while v141 < v139 do
				local v142 = v141 + p133
				local v143 = math.min(v139, v142)
				if v143 - v141 > 1 then
					v_u_99(p130, p131 + v140 * v141, p131 + v140 * v143, p135, p136, p137)
				end
				v141 = v143 + p134
			end
		end
	end
	local function v167(p145, p146, p147, p148, p149, p150, p151, p152) -- name: box
		-- upvalues: (copy) v_u_60, (copy) v_u_65, (ref) v_u_73
		local v153 = Vector2.new((p146 + v_u_60) * v_u_65, (p147 + v_u_60) * v_u_65)
		local v154 = p150 % 180
		local v155 = -p150
		local v156 = v154 - 90
		if math.abs(v156) < 1 then
			local v157 = p149
			p149 = p148
			p148 = v157
			v155 = 0
		elseif v154 < 1 or v154 > 179 then
			v155 = 0
		end
		local v158 = p152 or 2
		v_u_73 = v_u_73 + 1
		local v159 = {
			["BackgroundColor3"] = p151,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v153.X, v153.Y)
		}
		local v160 = UDim2.fromOffset
		local v161 = p148 * v_u_65
		local v162 = math.max(v158, v161)
		local v163 = p149 * v_u_65
		v159.Size = v160(v162, (math.max(v158, v163)))
		v159.Rotation = v155
		local v164 = Instance.new("Frame")
		v164.BorderSizePixel = 0
		for v165, v166 in v159 do
			v164[v165] = v166
		end
		v164.Parent = p145
		return v164
	end
	local function v170(p168, p169) -- name: toPx
		-- upvalues: (copy) v_u_60, (copy) v_u_65
		return Vector2.new((p168 + v_u_60) * v_u_65, (p169 + v_u_60) * v_u_65)
	end
	for v171, v172 in v100 do
		v101[v171] = v172
	end
	v101.Parent = v80
	v129(v101, -v_u_61, -v_u_61, v_u_61, v_u_61, v_u_12.field, 0.55).Name = "Field"
	for _, v173 in v_u_7.WOODS do
		v129(v101, v173[1], v173[2], v173[3], v173[4], v_u_12.forest, 0.1).Name = "Forest"
	end
	local v174 = v_u_60 * 2 / 200 + 0.5
	local v175 = math.floor(v174)
	for v176 = 1, v175 - 1 do
		local v177 = v176 / v175
		v657 = v_u_73 + 2
		local v178 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.grid,
			["Position"] = UDim2.new(v177, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v179 = Instance.new("Frame")
		v179.BorderSizePixel = 0
		v_u_73 = v657
		for v180, v181 in v178 do
			v179[v180] = v181
		end
		v179.Parent = v101
		local v182 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.grid,
			["Position"] = UDim2.new(0, 0, v177, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v183 = Instance.new("Frame")
		v183.BorderSizePixel = 0
		for v184, v185 in v182 do
			v183[v184] = v185
		end
		v183.Parent = v101
	end
	for _, v186 in v_u_7.TREES do
		local v187 = v186[1]
		local v188 = v186[2]
		local v189 = Vector2.new((v187 + v_u_60) * v_u_65, (v188 + v_u_60) * v_u_65)
		local v190 = v186[3] * v_u_65
		local v191 = math.max(3, v190)
		v657 = v_u_73 + 1
		local v192 = {
			["Name"] = "T",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.18,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.tree,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v189.X, v189.Y),
			["Size"] = UDim2.fromOffset(v191, v191)
		}
		local v193 = Instance.new("Frame")
		v193.BorderSizePixel = 0
		v_u_73 = v657
		for v194, v195 in v192 do
			v193[v194] = v195
		end
		v193.Parent = v101
		local v196 = UDim.new(0.5, 0)
		local v197 = Instance.new("UICorner")
		v197.CornerRadius = v196
		v197.Parent = v193
	end
	local v198 = {
		["Name"] = "Pads",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v199 = Instance.new("Frame")
	v199.BorderSizePixel = 0
	for v200, v201 in v198 do
		v199[v200] = v201
	end
	v199.Parent = v80
	local v202 = table.clone(v_u_7.PADS)
	table.sort(v202, function(p203, p204)
		return (p203[3] - p203[1]) * (p203[4] - p203[2]) > (p204[3] - p204[1]) * (p204[4] - p204[2])
	end)
	local v205 = {
		["concrete"] = v_u_12.padConcrete,
		["asphalt"] = v_u_12.padAsphalt,
		["gravel"] = v_u_12.padGravel,
		["dirt"] = v_u_12.padDirt,
		["grass"] = v_u_12.park
	}
	for _, v206 in v202 do
		v129(v199, v206[1], v206[2], v206[3], v206[4], v205[v206[5]] or v_u_12.lot, 0).Name = "Pad"
	end
	local v207 = {
		["Name"] = "RoadCase",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v208 = Instance.new("Frame")
	v208.BorderSizePixel = 0
	for v209, v210 in v207 do
		v208[v209] = v210
	end
	v208.Parent = v80
	local v211 = {
		["Name"] = "RoadFill",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v212 = Instance.new("Frame")
	v212.BorderSizePixel = 0
	for v213, v214 in v211 do
		v212[v213] = v214
	end
	v212.Parent = v80
	local v215 = v_u_66 * 1.6 + 0.5
	local v216 = math.floor(v215)
	local v217 = math.max(1, v216)
	for _, v218 in v_u_7.ROADS do
		local v219 = v218[1]
		local v220 = v218[2]
		local v221 = Vector2.new((v219 + v_u_60) * v_u_65, (v220 + v_u_60) * v_u_65)
		local v222 = v218[3]
		local v223 = v218[4]
		local v224 = Vector2.new((v222 + v_u_60) * v_u_65, (v223 + v_u_60) * v_u_65)
		local v225 = v218[6] == "service" and 0 or v217
		v657 = v_u_73 + 2
		local v226 = {
			["Name"] = "Case",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.roadCase
		}
		local v227 = UDim2.fromOffset
		local v228 = v221.X
		local v229 = math.floor(v228) - v217
		local v230 = v221.Y
		v226.Position = v227(v229, math.floor(v230) - v217)
		local v231 = UDim2.fromOffset
		local v232 = v224.X - v221.X
		local v233 = math.ceil(v232) + v217 * 2
		local v234 = v224.Y - v221.Y
		v226.Size = v231(v233, math.ceil(v234) + v217 * 2)
		local v235 = Instance.new("Frame")
		v235.BorderSizePixel = 0
		v_u_73 = v657
		for v236, v237 in v226 do
			v235[v236] = v237
		end
		v235.Parent = v208
		v235:SetAttribute("Road", v218[5])
		if v225 == 0 then
			v235.BackgroundTransparency = 0.35
		end
		local v238 = {
			["Name"] = "Road",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil
		}
		local v239
		if v218[6] == "main" then
			v239 = v_u_12.highway
		else
			v239 = v_u_12.road
		end
		v238.BackgroundColor3 = v239
		local v240 = UDim2.fromOffset
		local v241 = v221.X
		local v242 = math.floor(v241)
		local v243 = v221.Y
		v238.Position = v240(v242, (math.floor(v243)))
		local v244 = UDim2.fromOffset
		local v245 = v224.X - v221.X
		local v246 = math.ceil(v245)
		local v247 = math.max(1, v246)
		local v248 = v224.Y - v221.Y
		local v249 = math.ceil(v248)
		v238.Size = v244(v247, (math.max(1, v249)))
		local v250 = Instance.new("Frame")
		v250.BorderSizePixel = 0
		for v251, v252 in v238 do
			v250[v251] = v252
		end
		v250.Parent = v212
		v250:SetAttribute("Road", v218[5])
	end
	local v253 = {
		["Name"] = "Pavement",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v254 = Instance.new("Frame")
	v254.BorderSizePixel = 0
	for v255, v256 in v253 do
		v254[v255] = v256
	end
	v254.Parent = v80
	local v257 = v_u_7.RUNWAY
	for _, v258 in v_u_7.APRONS do
		local v259 = v129(v254, v258[1], v258[2], v258[3], v258[4], v_u_12.apron, 0)
		v259.Name = "Apron"
		local v260 = v_u_12.inkSoft
		local v261 = Instance.new("UIStroke")
		v261.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v261.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v261.Color = v260
		v261.Thickness = 1
		v261.Transparency = 0.55
		v261.Parent = v259
	end
	for _, v262 in v_u_7.TAXIWAYS do
		v129(v254, v262[1], v262[2], v262[3], v262[4], v_u_12.taxi, 0).Name = "Taxiway"
		if v262[5] ~= "x" then
			continue
		end
		local v263 = (v262[2] + v262[4]) / 2
		local v264 = v262[1] + 8
		local v265 = Vector2.new((v264 + v_u_60) * v_u_65, (v263 + v_u_60) * v_u_65)
		local v266 = v262[3] - 8
		local v267 = Vector2.new((v266 + v_u_60) * v_u_65, (v263 + v_u_60) * v_u_65)
		local v268 = v_u_65 * 18
		local v269 = math.max(4, v268)
		local v270 = v_u_65 * 14
		v_u_144(v254, v265, v267, v269, math.max(3, v270), 1, v_u_12.roadCase, 0.55)
	end
	v129(v254, v257.x0 - v257.overrun, v257.cz - v257.width / 2, v257.x1 + v257.overrun, v257.cz + v257.width / 2, v_u_12.taxi, 0).Name = "Overrun"
	local v271 = v129(v254, v257.x0, v257.cz - v257.width / 2, v257.x1, v257.cz + v257.width / 2, v_u_12.tarmac, 0)
	v271.Name = "Runway"
	local v272 = v_u_12.roadCase
	local v273 = Instance.new("UIStroke")
	v273.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v273.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v273.Color = v272
	v273.Thickness = 1
	v273.Transparency = 0.3
	v273.Parent = v271
	local v274 = v257.x0 + 30
	local v275 = v257.cz
	local v276 = Vector2.new((v274 + v_u_60) * v_u_65, (v275 + v_u_60) * v_u_65)
	local v277 = v257.x1 - 30
	local v278 = v257.cz
	local v279 = Vector2.new((v277 + v_u_60) * v_u_65, (v278 + v_u_60) * v_u_65)
	local v280 = v_u_65 * 30
	local v281 = math.max(5, v280)
	local v282 = v_u_65 * 22
	local v283 = math.max(4, v282)
	local v284 = v_u_66 * 1.4 + 0.5
	local v285 = math.floor(v284)
	v_u_144(v254, v276, v279, v281, v283, math.max(1, v285), v_u_12.paperLight, 0.05)
	for _, v286 in { -1, 1 } do
		local v287
		if v286 < 0 then
			v287 = v257.x0 + 9
		else
			v287 = v257.x1 - 9
		end
		local v288 = v257.cz - v257.width / 2 + 5
		local v289 = Vector2.new((v287 + v_u_60) * v_u_65, (v288 + v_u_60) * v_u_65)
		local v290 = v257.cz + v257.width / 2 - 5
		local v291 = Vector2.new((v287 + v_u_60) * v_u_65, (v290 + v_u_60) * v_u_65)
		local v292 = v_u_66 * 3 + 0.5
		local v293 = math.floor(v292)
		v_u_99(v254, v289, v291, math.max(2, v293), v_u_12.paperLight, 0.05)
	end
	local v294 = {
		["Name"] = "Buildings",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v295 = Instance.new("Frame")
	v295.BorderSizePixel = 0
	for v296, v297 in v294 do
		v295[v296] = v297
	end
	v295.Parent = v80
	local v298 = {
		["Name"] = "Props",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_299 = Instance.new("Frame")
	v_u_299.BorderSizePixel = 0
	for v300, v301 in v298 do
		v_u_299[v300] = v301
	end
	v_u_299.Parent = v80
	local v302 = {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_303 = Instance.new("Frame")
	v_u_303.BorderSizePixel = 0
	for v304, v305 in v302 do
		v_u_303[v304] = v305
	end
	v_u_303.Parent = v80
	local v_u_306 = {}
	local v_u_307 = {}
	local v_u_308 = {}
	local v_u_309 = false
	local v_u_310 = {}
	local function v_u_317(p311, p312, p313, p314, p315) -- name: overlaps
		for _, v316 in p315 do
			if p311 >= v316[3] or (v316[1] >= p313 or (p312 >= v316[4] or v316[2] >= p314)) then
				continue
			end
			return true
		end
		return false
	end
	local function v_u_323(p318, p319, p320, p321, p322) -- name: free
		-- upvalues: (copy) v_u_64, (copy) v_u_317, (copy) v_u_306, (copy) v_u_310
		if p318 < 3 or (p319 < 3 or (v_u_64 - 3 < p320 or v_u_64 - 3 < p321)) then
			return false
		end
		if v_u_317(p318, p319, p320, p321, v_u_306) then
			return false
		end
		if p322 then
			p322 = v_u_317(p318, p319, p320, p321, v_u_310)
		end
		return not p322
	end
	local function v353(p324, p325, p326, p327, p328, p329, p330, p331) -- name: label
		-- upvalues: (ref) v_u_2, (copy) p_u_56, (copy) v_u_323, (copy) v_u_306, (copy) v_u_307, (ref) v_u_74, (ref) v_u_73, (copy) v_u_303, (copy) v_u_58, (ref) v_u_309, (copy) v_u_308
		local v332 = v_u_2.phoneText
		local v333 = "caption"
		local v334
		if p_u_56 then
			v334 = p_u_56.scale
		else
			v334 = nil
		end
		local v335
		if p_u_56 then
			v335 = p_u_56.phone
		else
			v335 = nil
		end
		local v336 = v332(p326, v333, v334, v335)
		local v337 = (utf8.len(p324) or #p324) * v336 * 0.56 + 6
		local v338 = v336 + 2
		local v339
		if p329 then
			v339 = p329.Rotation
		else
			v339 = p329
		end
		if v339 then
			if math.abs(v339) ~= 90 then
				local v340 = v337
				v337 = v338
				v338 = v340
			end
		else
			local v341 = v337
			v337 = v338
			v338 = v341
		end
		if not (p330 or v_u_323(p325.X - v338 / 2, p325.Y - v337 / 2, p325.X + v338 / 2, p325.Y + v337 / 2, p331)) then
			return nil
		end
		local v342 = {
			p325.X - v338 / 2,
			p325.Y - v337 / 2,
			p325.X + v338 / 2,
			p325.Y + v337 / 2
		}
		local v343 = v_u_306
		table.insert(v343, v342)
		v_u_307[v342] = true
		v_u_74 = v_u_74 + 1
		v_u_73 = v_u_73 + 1
		local v344 = v_u_303
		local v345 = v_u_58
		local v346 = v_u_2.phoneText
		local v347 = "caption"
		local v348
		if p_u_56 then
			v348 = p_u_56.scale
		else
			v348 = nil
		end
		local v349
		if p_u_56 then
			v349 = p_u_56.phone
		else
			v349 = nil
		end
		local v350 = v345(v344, p324, p325, v346(v336, v347, v348, v349), p327, p328, p329)
		if v_u_309 then
			local v351 = v_u_308
			local v352 = {
				["id"] = "",
				["kind"] = "name",
				["rect"] = nil,
				["obj"] = nil,
				["rect"] = v_u_306[#v_u_306],
				["obj"] = v350
			}
			table.insert(v351, v352)
		end
		return v350
	end
	local v354 = {}
	if p54 then
		local v355 = p54.buildings
		if type(v355) == "table" and #p54.buildings >= 8 then
			for _, v356 in p54.buildings do
				local v357 = v356.cf
				if typeof(v357) ~= "CFrame" then
					continue
				end
				local v358 = v356.size
				if typeof(v358) ~= "Vector3" then
					continue
				end
				local _, v359, _ = v356.cf:ToOrientation()
				local v360 = {
					["kind"] = v356.kind
				}
				local v361 = string.lower
				local v362 = v356.id
				v360.id = v361((tostring(v362)))
				v360.x = v356.cf.X
				v360.z = v356.cf.Z
				v360.w = v356.size.X
				v360.d = v356.size.Z
				v360.yaw = math.deg(v359)
				v360.name = v356.name
				table.insert(v354, v360)
			end
		end
	end
	if #v354 == 0 then
		for _, v363 in v_u_7.LOTS do
			local v364 = {
				["kind"] = nil,
				["id"] = nil,
				["x"] = nil,
				["z"] = nil,
				["w"] = nil,
				["d"] = nil,
				["yaw"] = 0,
				["name"] = nil,
				["kind"] = v363[2],
				["id"] = v363[1],
				["x"] = v363[4],
				["z"] = v363[5],
				["w"] = v363[6],
				["d"] = v363[7],
				["name"] = v363[9]
			}
			table.insert(v354, v364)
		end
	end
	local v365 = {}
	local v_u_366 = {}
	for _, v367 in v354 do
		local v368 = v_u_7.LANDMARKS[v367.id]
		local v369 = v_u_7.LANDMARK_KINDS[v367.kind]
		local v370
		if v368 == nil then
			if v369 == nil then
				v370 = false
			else
				v370 = v_u_7.NAMES[v367.id] == nil
			end
		else
			v370 = true
		end
		local v371 = v367.x
		local v372 = v367.z
		local v373 = v367.w
		local v374 = v367.d
		local v375 = v367.yaw
		local v376
		if v370 then
			v376 = v_u_12.landmark
		else
			v376 = v_u_12.build
		end
		local v377 = v167(v295, v371, v372, v373, v374, v375, v376)
		local v378 = v367.id
		v377.Name = "B_" .. tostring(v378)
		local v379
		if v370 then
			v379 = v_u_12.landmarkEdge
		else
			v379 = v_u_12.buildEdge
		end
		local v380 = Instance.new("UIStroke")
		v380.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v380.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v380.Color = v379
		v380.Thickness = 1
		v380.Transparency = 0.1
		v380.Parent = v377
		local v381 = v367.id
		local v382 = {}
		local v383 = v367.x
		local v384 = v367.z
		local v385 = v368 or v_u_7.NAMES[v367.id]
		if not v385 then
			if v369 then
				v385 = v369
			else
				local v386 = v367.name or v367.id
				v385 = tostring(v386)
			end
		end
		__set_list(v382, 1, {v383, v384, v385})
		v_u_366[v381] = v382
		local v387 = v367.x
		local v388 = v367.z
		local v389 = Vector2.new((v387 + v_u_60) * v_u_65, (v388 + v_u_60) * v_u_65)
		local v390 = v367.yaw % 180
		local v391 = v367.w
		local v392 = v367.d
		local v393 = v390 - 90
		if math.abs(v393) >= 45 then
			local v394 = v391
			v391 = v392
			v392 = v394
		end
		local v395 = {
			v389.X - v392 * v_u_65 / 2 - 1,
			v389.Y - v391 * v_u_65 / 2 - 1,
			v389.X + v392 * v_u_65 / 2 + 1,
			v389.Y + v391 * v_u_65 / 2 + 1
		}
		table.insert(v_u_310, v395)
		if not v370 then
			continue
		end
		local v396 = {
			["text"] = v368 or v369,
			["b"] = v367,
			["px"] = v389,
			["wpx"] = v392 * v_u_65,
			["hpx"] = v391 * v_u_65
		}
		table.insert(v365, v396)
	end
	local v397 = v_u_65 * 12
	local v_u_398 = math.max(4, v397)
	local v399 = v_u_65 * 9
	local v_u_400 = math.max(3, v399)
	local v401 = {
		["N"] = {},
		["S"] = {},
		["E"] = {},
		["W"] = {}
	}
	for _, v402 in v_u_7.RING_GAPS do
		local v403 = v401[v402[1]]
		if not v403 then
			continue
		end
		local v404 = { v402[2] - v402[3] / 2, v402[2] + v402[3] / 2, v402[4] }
		table.insert(v403, v404)
	end
	for v_u_405, v406 in v401 do
		table.sort(v406, function(p407, p408)
			return p407[1] < p408[1]
		end)
		local v409 = -v_u_61
		local function v428(p410, p411) -- name: run
			-- upvalues: (copy) v_u_405, (copy) v_u_61, (copy) v_u_60, (copy) v_u_65, (copy) v_u_144, (copy) v_u_299, (copy) v_u_398, (copy) v_u_400, (copy) v_u_66, (ref) v_u_12
			if p411 - p410 >= 2 then
				local v412, v413
				if v_u_405 == "N" then
					local v414 = -v_u_61
					v412 = Vector2.new((p410 + v_u_60) * v_u_65, (v414 + v_u_60) * v_u_65)
					local v415 = -v_u_61
					v413 = Vector2.new((p411 + v_u_60) * v_u_65, (v415 + v_u_60) * v_u_65)
				elseif v_u_405 == "S" then
					local v416 = v_u_61
					v412 = Vector2.new((p410 + v_u_60) * v_u_65, (v416 + v_u_60) * v_u_65)
					local v417 = v_u_61
					v413 = Vector2.new((p411 + v_u_60) * v_u_65, (v417 + v_u_60) * v_u_65)
				elseif v_u_405 == "E" then
					local v418 = v_u_61
					v412 = Vector2.new((v418 + v_u_60) * v_u_65, (p410 + v_u_60) * v_u_65)
					local v419 = v_u_61
					v413 = Vector2.new((v419 + v_u_60) * v_u_65, (p411 + v_u_60) * v_u_65)
				else
					local v420 = -v_u_61
					v412 = Vector2.new((v420 + v_u_60) * v_u_65, (p410 + v_u_60) * v_u_65)
					local v421 = -v_u_61
					v413 = Vector2.new((v421 + v_u_60) * v_u_65, (p411 + v_u_60) * v_u_65)
				end
				local v422 = v_u_144
				local v423 = v_u_299
				local v424 = v_u_398
				local v425 = v_u_400
				local v426 = v_u_66 * 1.5 + 0.5
				local v427 = math.floor(v426)
				v422(v423, v412, v413, v424, v425, math.max(1, v427), v_u_12.ink, 0.1)
			end
		end
		for _, v429 in v406 do
			v428(v409, v429[1])
			v409 = v429[2]
			local v430 = v429[3]
			for _, v431 in { v429[1], v429[2] } do
				local v432
				if v_u_405 == "N" then
					local v433 = -v_u_61
					v432 = Vector2.new((v431 + v_u_60) * v_u_65, (v433 + v_u_60) * v_u_65)
				elseif v_u_405 == "S" then
					v432 = Vector2.new((v431 + v_u_60) * v_u_65, (v_u_61 + v_u_60) * v_u_65)
				elseif v_u_405 == "E" then
					v432 = Vector2.new((v_u_61 + v_u_60) * v_u_65, (v431 + v_u_60) * v_u_65)
				else
					local v434 = -v_u_61
					v432 = Vector2.new((v434 + v_u_60) * v_u_65, (v431 + v_u_60) * v_u_65)
				end
				if v430 == "cut" then
					continue
				end
				local v435 = v_u_66 * 4 + 0.5
				local v436 = math.floor(v435)
				local v437 = math.max(3, v436)
				v657 = v_u_73 + 1
				local v438 = {
					["Name"] = "Post",
					["BackgroundColor3"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_12.ink,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v432.X, v432.Y),
					["Size"] = UDim2.fromOffset(v437, v437)
				}
				local v439 = Instance.new("Frame")
				v439.BorderSizePixel = 0
				v_u_73 = v657
				for v440, v441 in v438 do
					v439[v440] = v441
				end
				v439.Parent = v_u_299
			end
			if v430 ~= "locked" then
				break
			end
			local v442
			if v_u_405 == "N" then
				local v443 = v429[1]
				local v444 = -v_u_61
				v442 = Vector2.new((v443 + v_u_60) * v_u_65, (v444 + v_u_60) * v_u_65)
			elseif v_u_405 == "S" then
				local v445 = v429[1]
				v442 = Vector2.new((v445 + v_u_60) * v_u_65, (v_u_61 + v_u_60) * v_u_65)
			elseif v_u_405 == "E" then
				local v446 = v429[1]
				v442 = Vector2.new((v_u_61 + v_u_60) * v_u_65, (v446 + v_u_60) * v_u_65)
			else
				local v447 = -v_u_61
				local v448 = v429[1]
				v442 = Vector2.new((v447 + v_u_60) * v_u_65, (v448 + v_u_60) * v_u_65)
			end
			local v449
			if v_u_405 == "N" then
				local v450 = v429[2]
				local v451 = -v_u_61
				v449 = Vector2.new((v450 + v_u_60) * v_u_65, (v451 + v_u_60) * v_u_65)
			elseif v_u_405 == "S" then
				local v452 = v429[2]
				v449 = Vector2.new((v452 + v_u_60) * v_u_65, (v_u_61 + v_u_60) * v_u_65)
			elseif v_u_405 == "E" then
				local v453 = v429[2]
				v449 = Vector2.new((v_u_61 + v_u_60) * v_u_65, (v453 + v_u_60) * v_u_65)
			else
				local v454 = -v_u_61
				local v455 = v429[2]
				v449 = Vector2.new((v454 + v_u_60) * v_u_65, (v455 + v_u_60) * v_u_65)
			end
			local v456 = v_u_66 * 2.5 + 0.5
			local v457 = math.floor(v456)
			v_u_99(v_u_299, v442, v449, math.max(2, v457), v_u_12.redDeep, 0.1)
		end
		v428(v409, v_u_61)
	end
	for _, v458 in v_u_7.FENCES do
		local v459 = v458[1]
		local v460 = v458[2]
		local v461 = #v458
		local v462 = 3
		local v463 = {}
		while v462 + 1 <= v461 do
			local v464 = v458[v462]
			local v465 = v458[v462 + 1]
			table.insert(v463, v170(v464, v465))
			v462 = v462 + 2
		end
		if v460 and #v463 >= 3 then
			local v466 = v463[1]
			table.insert(v463, v466)
		end
		local v467 = v459 == "hesco" and true or v459 == "sandbag"
		for v468 = 1, #v463 - 1 do
			if v467 then
				local v469 = v463[v468]
				local v470 = v463[v468 + 1]
				local v471 = v_u_66 * 2.5 + 0.5
				local v472 = math.floor(v471)
				v_u_99(v_u_299, v469, v470, math.max(2, v472), v_u_12.buildEdge, 0.1)
			else
				v_u_99(v_u_299, v463[v468], v463[v468 + 1], 1, v_u_12.inkSoft, 0.2)
			end
		end
	end
	for _, v473 in v_u_7.STRUCTURES do
		local v474 = v167(v_u_299, v473[1], v473[2], v473[3], v473[4], v473[5], v_u_12.build)
		v474.BackgroundTransparency = 0.15
		v474.Name = "S"
		local v475 = v_u_12.buildEdge
		local v476 = Instance.new("UIStroke")
		v476.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v476.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v476.Color = v475
		v476.Thickness = 1
		v476.Transparency = 0.3
		v476.Parent = v474
	end
	for _, v477 in v_u_7.TENTS do
		local v478 = v167(v_u_299, v477[1], v477[2], v477[3], v477[4], v477[5], v_u_12.tent, 3)
		v478.Name = v477[6] and "TentLarge" or "Tent"
		local v479 = v_u_12.buildEdge
		local v480 = Instance.new("UIStroke")
		v480.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v480.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v480.Color = v479
		v480.Thickness = 1
		v480.Transparency = 0.15
		v480.Parent = v478
	end
	for _, v481 in v_u_7.PLANES do
		local v482 = v481[1]
		local v483 = v481[2]
		local v484 = v481[3]
		local v485 = v481[4]
		local v486 = v481[5]
		local v487 = v481[6]
		local v488 = Vector2.new((v483 + v_u_60) * v_u_65, (v484 + v_u_60) * v_u_65)
		local v489 = v485 * v_u_65
		local v490 = math.max(3, v489)
		local v491 = v486 * v_u_65
		local v492 = math.max(3, v491)
		v657 = v_u_73 + 1
		local v493 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["Name"] = "Plane_" .. v482,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v488.X, v488.Y),
			["Size"] = UDim2.fromOffset(v490, v492),
			["Rotation"] = -v487
		}
		local v494 = Instance.new("Frame")
		v494.BorderSizePixel = 0
		v_u_73 = v657
		for v495, v496 in v493 do
			v494[v495] = v496
		end
		v494.Parent = v_u_299
		if v482 == "small" or v482 == "twin" then
			local v497 = v490 * 0.15
			local v498 = math.max(2, v497)
			v657 = v_u_73 + 3
			local v499 = {
				["Name"] = "Fuselage",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.08,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_12.ink,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(0, v498, 0.96, 0)
			}
			local v500 = Instance.new("Frame")
			v500.BorderSizePixel = 0
			v_u_73 = v657
			for v501, v502 in v499 do
				v500[v501] = v502
			end
			v500.Parent = v494
			local v503 = {
				["Name"] = "Wing",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.08,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_12.ink,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.38)
			}
			local v504 = UDim2.new
			local v505 = v492 * 0.2
			v503.Size = v504(1, 0, 0, (math.max(2, v505)))
			local v506 = Instance.new("Frame")
			v506.BorderSizePixel = 0
			for v507, v508 in v503 do
				v506[v507] = v508
			end
			v506.Parent = v494
			local v509 = {
				["Name"] = "Tail",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.08,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_12.ink,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.9)
			}
			local v510 = UDim2.new
			local v511 = v492 * 0.1
			v509.Size = v510(0.4, 0, 0, (math.max(2, v511)))
			local v512 = Instance.new("Frame")
			v512.BorderSizePixel = 0
			for v513, v514 in v509 do
				v512[v513] = v514
			end
			v512.Parent = v494
		else
			v494.BackgroundTransparency = 0.2
			v494.BackgroundColor3 = v_u_12.landmark
			local v515 = v_u_12.landmarkEdge
			local v516 = Instance.new("UIStroke")
			v516.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v516.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v516.Color = v515
			v516.Thickness = 1
			v516.Transparency = 0.1
			v516.Parent = v494
		end
	end
	for _, v517 in v_u_7.CIRCLES do
		local v518 = v517[1]
		local v519 = v517[2]
		local v520 = v517[3]
		local v521 = v517[4]
		local v522 = Vector2.new((v519 + v_u_60) * v_u_65, (v520 + v_u_60) * v_u_65)
		local v523 = v521 * 2 * v_u_65
		local v524 = math.max(4, v523)
		v657 = v_u_73 + 1
		local v525 = {
			["Name"] = "Round_" .. v518
		}
		local v526
		if v518 == "dome" then
			v526 = v_u_12.paperLight
		else
			v526 = v_u_12.lot
		end
		v525.BackgroundColor3 = v526
		v525.AnchorPoint = Vector2.new(0.5, 0.5)
		v525.Position = UDim2.fromOffset(v522.X, v522.Y)
		v525.Size = UDim2.fromOffset(v524, v524)
		local v527 = Instance.new("Frame")
		v527.BorderSizePixel = 0
		v_u_73 = v657
		for v528, v529 in v525 do
			v527[v528] = v529
		end
		v527.Parent = v_u_299
		local v530 = UDim.new(0.5, 0)
		local v531 = Instance.new("UICorner")
		v531.CornerRadius = v530
		v531.Parent = v527
		local v532 = v_u_12.buildEdge
		local v533 = v518 == "tank" and 1 or 2
		local v534 = Instance.new("UIStroke")
		v534.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v534.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v534.Color = v532
		v534.Thickness = v533
		v534.Transparency = 0
		v534.Parent = v527
		if v518 ~= "dish" and v518 ~= "dome" then
			break
		end
		v657 = v_u_73 + 2
		v_u_73 = v657
		for _, v535 in { 0, 90 } do
			local v536 = {
				["Name"] = "Cross",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["BackgroundColor3"] = v_u_12.buildEdge,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(0.8, 0, 0, 1),
				["Rotation"] = v535
			}
			local v537 = Instance.new("Frame")
			v537.BorderSizePixel = 0
			for v538, v539 in v536 do
				v537[v538] = v539
			end
			v537.Parent = v527
		end
	end
	for _, v540 in v_u_7.TOWERS do
		local v541 = v540[1]
		local v542 = v540[2]
		local v543 = Vector2.new((v541 + v_u_60) * v_u_65, (v542 + v_u_60) * v_u_65)
		local v544 = v_u_66 * 5 + 0.5
		local v545 = math.floor(v544)
		local v546 = math.max(4, v545)
		v657 = v_u_73 + 1
		local v547 = {
			["Name"] = "Watchtower",
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.paperLight,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v543.X, v543.Y),
			["Size"] = UDim2.fromOffset(v546, v546)
		}
		local v548 = Instance.new("Frame")
		v548.BorderSizePixel = 0
		v_u_73 = v657
		for v549, v550 in v547 do
			v548[v549] = v550
		end
		v548.Parent = v_u_299
		local v551 = v_u_12.ink
		local v552 = Instance.new("UIStroke")
		v552.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v552.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v552.Color = v551
		v552.Thickness = 1.5
		v552.Transparency = 0
		v552.Parent = v548
	end
	for _, v553 in v_u_7.HELIPADS do
		local v554 = v553[1]
		local v555 = v553[2]
		local v556 = Vector2.new((v554 + v_u_60) * v_u_65, (v555 + v_u_60) * v_u_65)
		local v557 = v553[3] * 2 * v_u_65
		local v558 = math.max(12, v557)
		v657 = v_u_73 + 1
		local v559 = {
			["Name"] = "Helipad",
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_12.padConcrete,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v556.X, v556.Y),
			["Size"] = UDim2.fromOffset(v558, v558)
		}
		local v560 = Instance.new("Frame")
		v560.BorderSizePixel = 0
		local v561 = v657
		for v562, v563 in v559 do
			v560[v562] = v563
		end
		v560.Parent = v_u_299
		local v564 = UDim.new(0.5, 0)
		local v565 = Instance.new("UICorner")
		v565.CornerRadius = v564
		v565.Parent = v560
		local v566 = v_u_12.inkSoft
		local v567 = Instance.new("UIStroke")
		v567.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v567.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v567.Color = v566
		v567.Thickness = 1.5
		v567.Transparency = 0
		v567.Parent = v560
		local v568 = Vector2.new(v558 / 2, v558 / 2)
		local v569 = v558 * 0.6
		local v570 = math.floor(v569)
		local v571 = math.max(9, v570)
		local v572 = v_u_12.inkSoft
		local v573 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v558, v558)
		}
		local v574 = "H"
		local v575 = v_u_2.phoneText
		local v576 = "caption"
		local v577
		if p_u_56 then
			v577 = p_u_56.scale
		else
			v577 = nil
		end
		local v578
		if p_u_56 then
			v578 = p_u_56.phone
		else
			v578 = nil
		end
		v_u_58(v560, v574, v568, v575(v571, v576, v577, v578), v68, v572, v573).Name = "H"
		v657 = v561 + 1
		v_u_73 = v657
	end
	local v579 = 13 * v_u_66 + 0.5
	local v580 = math.floor(v579)
	local v581 = math.max(10, v580)
	local v582 = v_u_2.phoneText
	local v583 = "text"
	local v584
	if p_u_56 then
		v584 = p_u_56.scale
	else
		v584 = nil
	end
	local v585
	if p_u_56 then
		v585 = p_u_56.phone
	else
		v585 = nil
	end
	local v586 = v582(v581, v583, v584, v585)
	table.sort(v365, function(p587, p588)
		return p587.b.w * p587.b.d > p588.b.w * p588.b.d
	end)
	for v589, v590 in v365 do
		local v591 = string.upper(v590.text)
		local v592 = (utf8.len(v591) or #v591) * v586 * 0.56 + 6
		local v593 = v586 + 2
		local v594 = v590.px
		local v595 = false
		for _, v596 in {
			Vector2.new(v594.X, v594.Y + v590.hpx / 2 + v593 / 2 + 3),
			Vector2.new(v594.X, v594.Y - v590.hpx / 2 - v593 / 2 - 3),
			Vector2.new(v594.X + v590.wpx / 2 + v592 / 2 + 3, v594.Y),
			Vector2.new(v594.X - v590.wpx / 2 - v592 / 2 - 3, v594.Y)
		} do
			if not v353(v591, v596, v586, v68, v_u_12.redDeep) then
				continue
			end
			v595 = true
		end
		if v595 or v589 > 14 then
			break
		end
		v353(v591, v594, v586, v68, v_u_12.redDeep, nil, true)
	end
	local v597 = 13 * v_u_66 + 0.5
	local v598 = math.floor(v597)
	local v599 = math.max(10, v598)
	local v600 = v_u_2.phoneText
	local v601 = "caption"
	local v602
	if p_u_56 then
		v602 = p_u_56.scale
	else
		v602 = nil
	end
	local v603
	if p_u_56 then
		v603 = p_u_56.phone
	else
		v603 = nil
	end
	local v604 = v600(v599, v601, v602, v603)
	for _, v605 in v_u_7.AREAS do
		if v605[1] ~= "crash" then
			continue
		end
		local v606 = v605[5]
		local v607 = (v606[1] + v606[3]) / 2
		local v608 = v606[2] + 14
		local v609 = Vector2.new((v607 + v_u_60) * v_u_65, (v608 + v_u_60) * v_u_65)
		v353(string.upper(v605[2]), v609, v586, v68, v_u_12.redDeep, nil, true)
	end
	local v610 = #v_u_306
	local v611
	if v_u_4 == nil then
		v611 = false
	else
		v611 = v_u_4.clean()
	end
	v_u_309 = v611
	local v612 = {
		{ 0.5, 0.5 },
		{ 0.5, 0.1 },
		{ 0.5, 0.9 },
		{ 0.25, 0.5 },
		{ 0.75, 0.5 },
		{ 0.25, 0.14 },
		{ 0.75, 0.14 },
		{ 0.25, 0.86 },
		{ 0.75, 0.86 }
	}
	for _, v613 in v_u_7.AREAS do
		if v613[1] == "crash" then
			continue
		end
		local v614 = v613[5]
		local v615 = v_u_39(v613[2])
		for _, v616 in v612 do
			local v617 = v614[1] + (v614[3] - v614[1]) * v616[1]
			local v618 = v614[2] + (v614[4] - v614[2]) * v616[2]
			if not v353(v615, Vector2.new((v617 + v_u_60) * v_u_65, (v618 + v_u_60) * v_u_65), v604, v67, v_u_12.inkSoft, {
				["TextStrokeTransparency"] = 0.45
			}, false, true) then
				continue
			end
			break
			break
		end
	end
	local v619 = 11 * v_u_66 + 0.5
	local v620 = math.floor(v619)
	local v621 = math.max(9, v620)
	local v622 = v_u_2.phoneText
	local v623 = "caption"
	local v624
	if p_u_56 then
		v624 = p_u_56.scale
	else
		v624 = nil
	end
	local v625
	if p_u_56 then
		v625 = p_u_56.phone
	else
		v625 = nil
	end
	local v626 = v622(v621, v623, v624, v625)
	local v627 = v257.x0 + (v257.x1 - v257.x0) * 0.23
	local v628 = v257.cz
	v353("RUNWAY 09 / 27", Vector2.new((v627 + v_u_60) * v_u_65, (v628 + v_u_60) * v_u_65), v626, v70, v_u_12.paperLight, {
		["TextStrokeColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["TextStrokeColor3"] = v_u_12.tarmac
	}, true)
	local v629 = v257.x0 + 22
	local v630 = v257.cz
	local v631 = Vector2.new((v629 + v_u_60) * v_u_65, (v630 + v_u_60) * v_u_65)
	local v632 = v_u_66 * 12 + 0.5
	local v633 = math.floor(v632)
	local v634 = math.max(9, v633)
	local v635 = v_u_12.paperLight
	local v636 = {
		["Rotation"] = 90,
		["TextStrokeColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["TextStrokeColor3"] = v_u_12.tarmac
	}
	local v637 = "09"
	local v638 = v_u_2.phoneText
	local v639 = "caption"
	local v640
	if p_u_56 then
		v640 = p_u_56.scale
	else
		v640 = nil
	end
	local v641
	if p_u_56 then
		v641 = p_u_56.phone
	else
		v641 = nil
	end
	local v642 = v_u_58(v_u_303, v637, v631, v638(v634, v639, v640, v641), v68, v635, v636)
	local v643 = v257.x1 - 22
	local v644 = v257.cz
	local v645 = Vector2.new((v643 + v_u_60) * v_u_65, (v644 + v_u_60) * v_u_65)
	local v646 = v_u_66 * 12 + 0.5
	local v647 = math.floor(v646)
	local v648 = math.max(9, v647)
	local v649 = v_u_12.paperLight
	local v650 = {
		["Rotation"] = -90,
		["TextStrokeColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["TextStrokeColor3"] = v_u_12.tarmac
	}
	local v651 = "27"
	local v652 = v_u_2.phoneText
	local v653 = "caption"
	local v654
	if p_u_56 then
		v654 = p_u_56.scale
	else
		v654 = nil
	end
	local v655
	if p_u_56 then
		v655 = p_u_56.phone
	else
		v655 = nil
	end
	local v656 = v_u_58(v_u_303, v651, v645, v652(v648, v653, v654, v655), v68, v649, v650)
	v642.Name = "Num09"
	v656.Name = "Num27"
	local v657 = v_u_73 + 2
	local v658
	if v59 then
		local v659 = v_u_66 * 12 + 0.5
		local v660 = math.floor(v659)
		local v661 = math.max(9, v660)
		local v662 = v_u_2.phoneText
		local v663 = "caption"
		local v664
		if p_u_56 then
			v664 = p_u_56.scale
		else
			v664 = nil
		end
		local v665
		if p_u_56 then
			v665 = p_u_56.phone
		else
			v665 = nil
		end
		local v666 = v662(v661, v663, v664, v665)
		local v667 = v666 + 2
		local v668 = v666 * 2 * 0.56 + 6
		local v669 = {}
		local v670 = v257.x0 + 22
		local v671 = v257.cz
		__set_list(v669, 1, {Vector2.new((v670 + v_u_60) * v_u_65, (v671 + v_u_60) * v_u_65), v170(v257.x1 - 22, v257.cz)})
		v658 = v657
		for _, v672 in v669 do
			local v673 = {
				v672.X - v667 / 2,
				v672.Y - v668 / 2,
				v672.X + v667 / 2,
				v672.Y + v668 / 2
			}
			table.insert(v_u_306, v673)
		end
	else
		v658 = v657
	end
	for _, v674 in v_u_7.TAXIWAYS do
		if v674[5] ~= "x" then
			continue
		end
		local v675 = (v674[2] + v674[4]) / 2
		for _, v676 in { 0.18, 0.82, 0.5 } do
			local v677 = string.upper(v674[7])
			local v678 = v674[1] + (v674[3] - v674[1]) * v676
			local v679 = Vector2.new((v678 + v_u_60) * v_u_65, (v675 + v_u_60) * v_u_65)
			local v680 = 10 * v_u_66 + 0.5
			local v681 = math.floor(v680)
			if not v353(v677, v679, math.max(9, v681), v70, v_u_12.inkSoft, {
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.2,
				["TextStrokeColor3"] = v_u_12.taxi
			}) then
				continue
			end
			break
			break
		end
	end
	local v682 = 11 * v_u_66 + 0.5
	local v683 = math.floor(v682)
	local v684 = math.max(9, v683)
	local v685 = v_u_2.phoneText
	local v686 = "caption"
	local v687
	if p_u_56 then
		v687 = p_u_56.scale
	else
		v687 = nil
	end
	local v688
	if p_u_56 then
		v688 = p_u_56.phone
	else
		v688 = nil
	end
	local v689 = v685(v684, v686, v687, v688)
	local v690 = {}
	for _, v691 in v_u_7.ROADS do
		local v692 = v691[5]
		local v693 = v691[3] - v691[1] > v691[4] - v691[2]
		local v694
		if v693 then
			v694 = v691[3] - v691[1]
		else
			v694 = v691[4] - v691[2]
		end
		local v695 = v690[v692] or 0
		if v692 == "" or v695 >= 1 or v694 * v_u_65 <= (utf8.len(v692) or #v692) * v689 * 0.5 then
			continue
		end
		for _, v696 in {
			0.5,
			0.3,
			0.7,
			0.15,
			0.85
		} do
			local v697
			if v693 then
				v697 = v691[1] + (v691[3] - v691[1]) * v696
			else
				v697 = (v691[1] + v691[3]) / 2
			end
			local v698
			if v693 then
				v698 = (v691[2] + v691[4]) / 2
			else
				v698 = v691[2] + (v691[4] - v691[2]) * v696
			end
			if not v353(string.upper(v692), Vector2.new((v697 + v_u_60) * v_u_65, (v698 + v_u_60) * v_u_65), v689, v70, v_u_12.inkSoft, {
				["Rotation"] = nil,
				["TextStrokeColor3"] = nil,
				["TextStrokeTransparency"] = 0.1,
				["Rotation"] = v693 and 0 or 90,
				["TextStrokeColor3"] = v_u_12.road
			}) then
				continue
			end
			v690[v692] = v695 + 1
		end
	end
	for _, v699 in { 0.3333333333333333, 0.6666666666666666 } do
		local v700 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_12.paperLight,
			["Position"] = UDim2.new(v699, 0, 0, 0),
			["Size"] = UDim2.new(0, 2, 1, 0)
		}
		local v701 = Instance.new("Frame")
		v701.BorderSizePixel = 0
		for v702, v703 in v700 do
			v701[v702] = v703
		end
		v701.Parent = v72
		local v704 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_12.crease,
			["Position"] = UDim2.new(v699, 2, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v705 = Instance.new("Frame")
		v705.BorderSizePixel = 0
		for v706, v707 in v704 do
			v705[v706] = v707
		end
		v705.Parent = v72
	end
	local v708 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_12.paperLight,
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v709 = Instance.new("Frame")
	v709.BorderSizePixel = 0
	for v710, v711 in v708 do
		v709[v710] = v711
	end
	v709.Parent = v72
	local v712 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_12.crease,
		["Position"] = UDim2.new(0, 0, 0.5, 2),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v713 = Instance.new("Frame")
	v713.BorderSizePixel = 0
	for v714, v715 in v712 do
		v713[v714] = v715
	end
	v713.Parent = v72
	local v716 = v_u_66 * 12 + 0.5
	local v717 = math.floor(v716)
	local v718 = math.max(9, v717)
	local v719 = v_u_2.phoneText
	local v720 = "caption"
	local v721
	if p_u_56 then
		v721 = p_u_56.scale
	else
		v721 = nil
	end
	local v722
	if p_u_56 then
		v722 = p_u_56.phone
	else
		v722 = nil
	end
	local v723 = v719(v718, v720, v721, v722)
	for v724 = 1, v175 do
		local v725 = v63 + v_u_64 * (v724 - 0.5) / v175
		for _, v726 in { v63 / 2, p53 - v63 / 2 } do
			local v727 = v_u_40[v724] or "?"
			local v728 = Vector2.new(v725, v726)
			local v729 = v_u_12.inkSoft
			local v730 = v_u_2.phoneText
			local v731 = "caption"
			local v732
			if p_u_56 then
				v732 = p_u_56.scale
			else
				v732 = nil
			end
			local v733
			if p_u_56 then
				v733 = p_u_56.phone
			else
				v733 = nil
			end
			local v734 = v_u_58(v72, v727, v728, v730(v723, v731, v732, v733), v67, v729, nil)
			v734.ZIndex = 21
			v734.TextStrokeTransparency = 1
		end
		for _, v735 in { v63 / 2, p53 - v63 / 2 } do
			local v736 = tostring(v724)
			local v737 = Vector2.new(v735, v725)
			local v738 = v_u_12.inkSoft
			local v739 = v_u_2.phoneText
			local v740 = "caption"
			local v741
			if p_u_56 then
				v741 = p_u_56.scale
			else
				v741 = nil
			end
			local v742
			if p_u_56 then
				v742 = p_u_56.phone
			else
				v742 = nil
			end
			local v743 = v_u_58(v72, v736, v737, v739(v723, v740, v741, v742), v67, v738, nil)
			v743.ZIndex = 21
			v743.TextStrokeTransparency = 1
		end
	end
	local v744 = 196 * v_u_66
	local v745 = math.floor(v744)
	local v746 = 52 * v_u_66
	local v747 = math.floor(v746)
	local v_u_748 = v_u_39("Kestrel Field")
	local v749 = 19 * v_u_66
	local v750 = math.floor(v749)
	local v751 = math.max(13, v750)
	local v752 = v_u_2.phoneText
	local v753 = "text"
	local v754
	if p_u_56 then
		v754 = p_u_56.scale
	else
		v754 = nil
	end
	local v755
	if p_u_56 then
		v755 = p_u_56.phone
	else
		v755 = nil
	end
	local v_u_756 = v752(v751, v753, v754, v755)
	if v59 then
		local function v757()
			-- upvalues: (ref) v_u_1, (copy) v_u_748, (copy) v_u_756
			return v_u_1:GetTextSize(v_u_748, v_u_756, Enum.Font.GothamBold, Vector2.new(1000, 100))
		end
		local v758, v759 = pcall(v757)
		local v760
		if v758 then
			v760 = v759.X
		else
			v760 = #v_u_748 * v_u_756 * 0.7
		end
		local v761 = v760 + 14
		local v762 = math.ceil(v761)
		v745 = math.max(v745, v762)
		local v763 = 34 * v_u_66
		local v764 = math.floor(v763)
		local v765 = v_u_756 + 10
		v747 = math.max(v764, v765)
	end
	local v766 = {
		["Name"] = "Cartouche",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.paperLight
	}
	local v767 = UDim2.fromOffset
	local v768 = 10 * v_u_66
	local v769 = math.floor(v768)
	local v770 = 10 * v_u_66
	v766.Position = v767(v769, (math.floor(v770)))
	v766.Size = UDim2.fromOffset(v745, v747)
	local v771 = Instance.new("Frame")
	v771.BorderSizePixel = 0
	for v772, v773 in v766 do
		v771[v772] = v773
	end
	v771.Parent = v80
	local v774 = v_u_12.ink
	local v775 = Instance.new("UIStroke")
	v775.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v775.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v775.Color = v774
	v775.Thickness = 1
	v775.Transparency = 0
	v775.Parent = v771
	local v776 = Vector2.new
	local v777
	if v59 then
		v777 = v745 / 2
	else
		v777 = 98 * v_u_66
	end
	local v778
	if v59 then
		v778 = v747 / 2
	else
		v778 = 19 * v_u_66
	end
	local v779 = v776(v777, v778)
	local v780 = v_u_12.ink
	local v781 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil
	}
	local v782 = UDim2.fromOffset
	local v783
	if v59 then
		v783 = v745 - 4
	else
		v783 = 190 * v_u_66
	end
	local v784
	if v59 then
		v784 = v747 - 4
	else
		v784 = 24 * v_u_66
	end
	v781.Size = v782(v783, v784)
	local v785 = v_u_2.phoneText
	local v786 = "caption"
	local v787
	if p_u_56 then
		v787 = p_u_56.scale
	else
		v787 = nil
	end
	local v788
	if p_u_56 then
		v788 = p_u_56.phone
	else
		v788 = nil
	end
	v_u_58(v771, v_u_748, v779, v785(v_u_756, v786, v787, v788), v68, v780, v781).ZIndex = 11
	if not v59 then
		local v789 = Vector2.new(98 * v_u_66, 39 * v_u_66)
		local v790 = 11 * v_u_66
		local v791 = math.floor(v790)
		local v792 = math.max(9, v791)
		local v793 = v_u_12.inkSoft
		local v794 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(190 * v_u_66, v_u_66 * 14)
		}
		local v795 = "Airfield map, Marlow County"
		local v796 = v_u_2.phoneText
		local v797 = "caption"
		local v798
		if p_u_56 then
			v798 = p_u_56.scale
		else
			v798 = nil
		end
		local v799
		if p_u_56 then
			v799 = p_u_56.phone
		else
			v799 = nil
		end
		v_u_58(v771, v795, v789, v796(v792, v797, v798, v799), v69, v793, v794).ZIndex = 11
	end
	local v800
	if v_u_4 == nil then
		v800 = false
	else
		v800 = v_u_4.clean()
	end
	local v801 = {}
	local v802 = 15 * v_u_66
	local v803 = math.floor(v802)
	local v804 = math.max(11, v803)
	local v805 = v_u_64 - 34 * v_u_66
	local v806 = 40 * v_u_66
	if v800 then
		local v807 = 17 * v_u_66 + v804 + 4
		v806 = math.max(v806, v807)
		local v808 = {
			v805 - 17 * v_u_66 - 2,
			v806 - 17 * v_u_66 - v804 - 4,
			v805 + 17 * v_u_66 + 2,
			v806 + 17 * v_u_66 + 2
		}
		table.insert(v801, v808)
		local v809 = {}
		local v810 = 10 * v_u_66
		local v811 = math.floor(v810)
		local v812 = 10 * v_u_66
		local v813 = math.floor(v812)
		local v814 = 10 * v_u_66
		local v815 = math.floor(v814) + v745
		local v816 = 10 * v_u_66
		__set_list(v809, 1, {v811, v813, v815, math.floor(v816) + v747})
		table.insert(v801, v809)
	end
	local v817 = Vector2.new
	local v818
	if v800 then
		v818 = 17 * v_u_66 + v804 * 0.5 + 3
	else
		v818 = v_u_66 * 22
	end
	local v819 = v817(v805, v806 - v818)
	local v820 = v_u_12.ink
	local v821 = {
		["TextStrokeTransparency"] = 1
	}
	local v822 = "N"
	local v823 = v_u_2.phoneText
	local v824 = "caption"
	local v825
	if p_u_56 then
		v825 = p_u_56.scale
	else
		v825 = nil
	end
	local v826
	if p_u_56 then
		v826 = p_u_56.phone
	else
		v826 = nil
	end
	v_u_58(v80, v822, v819, v823(v804, v824, v825, v826), v68, v820, v821).ZIndex = 10
	local v827 = {
		["Name"] = "Needle",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v805, v806),
		["Size"] = UDim2.fromOffset(2, 28 * v_u_66)
	}
	local v828 = Instance.new("Frame")
	v828.BorderSizePixel = 0
	for v829, v830 in v827 do
		v828[v829] = v830
	end
	v828.Parent = v80
	local v831 = {
		["Name"] = "NeedleTip",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.red,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v805, v806 - v_u_66 * 9),
		["Size"] = UDim2.fromOffset(v_u_66 * 7, v_u_66 * 7)
	}
	local v832 = Instance.new("Frame")
	v832.BorderSizePixel = 0
	for v833, v834 in v831 do
		v832[v833] = v834
	end
	v832.Parent = v80
	local v835 = {
		["Name"] = "Cross",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_12.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v805, v806),
		["Size"] = UDim2.fromOffset(16 * v_u_66, 1)
	}
	local v836 = Instance.new("Frame")
	v836.BorderSizePixel = 0
	for v837, v838 in v835 do
		v836[v837] = v838
	end
	v836.Parent = v80
	local v839 = {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v805, v806),
		["Size"] = UDim2.fromOffset(34 * v_u_66, 34 * v_u_66)
	}
	local v840 = Instance.new("Frame")
	v840.BorderSizePixel = 0
	for v841, v842 in v839 do
		v840[v841] = v842
	end
	v840.Parent = v80
	local v843 = UDim.new(0.5, 0)
	local v844 = Instance.new("UICorner")
	v844.CornerRadius = v843
	v844.Parent = v840
	local v845 = v_u_12.ink
	local v846 = Instance.new("UIStroke")
	v846.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v846.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v846.Color = v845
	v846.Thickness = 1
	v846.Transparency = 0.3
	v846.Parent = v840
	local v847 = 100 / v_u_7.STUDS_TO_M * v_u_65
	local v848 = v_u_66 * 14
	local v849 = v_u_64 - 26 * v_u_66
	for v850 = 0, 3 do
		local v851 = {
			["Name"] = "Scale",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 10
		}
		local v852
		if v850 % 2 == 0 then
			v852 = v_u_12.ink
		else
			v852 = v_u_12.paperLight
		end
		v851.BackgroundColor3 = v852
		v851.Position = UDim2.fromOffset(v848 + v850 * v847 / 4, v849)
		local v853 = UDim2.fromOffset
		local v854 = v847 / 4
		local v855 = v_u_66 * 5
		v851.Size = v853(v854, (math.max(3, v855)))
		local v856 = Instance.new("Frame")
		v856.BorderSizePixel = 0
		for v857, v858 in v851 do
			v856[v857] = v858
		end
		v856.Parent = v80
		local v859 = v_u_12.ink
		local v860 = Instance.new("UIStroke")
		v860.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v860.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v860.Color = v859
		v860.Thickness = 1
		v860.Transparency = 0
		v860.Parent = v856
	end
	local v861
	if v800 then
		v861 = v_u_66 * 9 + 3
	else
		v861 = v_u_66 * 9
	end
	local v862 = Vector2.new(v848, v849 - v861)
	local v863 = 11 * v_u_66
	local v864 = math.floor(v863)
	local v865 = math.max(9, v864)
	local v866 = v_u_12.ink
	local v867 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v868 = "0"
	local v869 = v_u_2.phoneText
	local v870 = "caption"
	local v871
	if p_u_56 then
		v871 = p_u_56.scale
	else
		v871 = nil
	end
	local v872
	if p_u_56 then
		v872 = p_u_56.phone
	else
		v872 = nil
	end
	v_u_58(v80, v868, v862, v869(v865, v870, v871, v872), v70, v866, v867).ZIndex = 10
	local v873 = Vector2.new(v848 + v847, v849 - v861)
	local v874 = 11 * v_u_66
	local v875 = math.floor(v874)
	local v876 = math.max(9, v875)
	local v877 = v_u_12.ink
	local v878 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v879 = "100 m"
	local v880 = v_u_2.phoneText
	local v881 = "caption"
	local v882
	if p_u_56 then
		v882 = p_u_56.scale
	else
		v882 = nil
	end
	local v883
	if p_u_56 then
		v883 = p_u_56.phone
	else
		v883 = nil
	end
	v_u_58(v80, v879, v873, v880(v876, v881, v882, v883), v70, v877, v878).ZIndex = 10
	if v800 then
		local v884 = {}
		local v885 = v848 - 8
		local v886 = v849 - v861 - 9
		local v887 = v848 + v847 + 34
		local v888 = v_u_66 * 5
		__set_list(v884, 1, {v885, v886, v887, v849 + math.max(3, v888) + 3})
		table.insert(v801, v884)
	end
	local v889 = {}
	for _, v890 in v_u_7.AREAS do
		local v891 = {
			["id"] = v890[1],
			["name"] = v890[2],
			["ref"] = v_u_5.gridRef(v890[3], v890[4])
		}
		table.insert(v889, v891)
	end
	local function v895(p892) -- name: placeOf
		-- upvalues: (copy) v_u_366, (ref) v_u_5
		local v893 = string.lower(p892)
		local v894 = v_u_366[v893]
		if v894 then
			return v894[1], v894[2], v894[3]
		else
			return v_u_5.placeOf(v893)
		end
	end
	local v896 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v897 = Instance.new("Frame")
	v897.BorderSizePixel = 0
	for v898, v899 in v896 do
		v897[v898] = v899
	end
	v897.Parent = v80
	v72:SetAttribute("Frames", v658)
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["labelLayer"] = nil,
		["nameRects"] = nil,
		["removable"] = nil,
		["reserved"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["field"] = true,
		["positions"] = true,
		["placeOf"] = nil,
		["places"] = nil,
		["stats"] = nil,
		["frame"] = v72,
		["area"] = v80,
		["marks"] = v897,
		["toPx"] = v170,
		["toWorld"] = function(p900, p901) -- name: toWorld
			-- upvalues: (copy) v_u_65, (copy) v_u_60
			return Vector2.new(p900 / v_u_65 - v_u_60, p901 / v_u_65 - v_u_60)
		end,
		["inside"] = function(p902, p903) -- name: inside
			-- upvalues: (copy) v_u_60
			local v904
			if math.abs(p902) <= v_u_60 then
				v904 = math.abs(p903) <= v_u_60
			else
				v904 = false
			end
			return v904
		end,
		["placed"] = v_u_306,
		["labelLayer"] = v_u_303,
		["nameRects"] = v_u_307,
		["removable"] = v_u_308,
		["reserved"] = v801,
		["nLandmarks"] = v610,
		["scale"] = v_u_65,
		["k"] = v_u_66,
		["ink"] = v_u_12,
		["inner"] = v_u_64,
		["innerW"] = v_u_64,
		["innerH"] = v_u_64,
		["placeOf"] = v895,
		["places"] = v889,
		["stats"] = {
			["frames"] = v658,
			["labels"] = v_u_74,
			["lots"] = #v354,
			["trees"] = #v_u_7.TREES
		}
	}
end
return v_u_5