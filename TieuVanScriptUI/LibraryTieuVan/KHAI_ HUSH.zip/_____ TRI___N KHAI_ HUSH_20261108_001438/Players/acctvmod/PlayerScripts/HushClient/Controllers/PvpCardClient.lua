-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / PvpCardClient

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v3 = {
	["name"] = "PvpCardClient",
	["order"] = 62
}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = false
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = {}
local v_u_12 = {
	["received"] = 0,
	["rejected"] = 0,
	["shown"] = 0,
	["reports"] = 0,
	["buildFail"] = 0,
	["showFail"] = 0,
	["closed"] = nil,
	["lastClose"] = "",
	["closed"] = {}
}
local function v_u_21(p13, p14) -- name: known
	-- upvalues: (ref) v_u_11, (ref) v_u_5
	local v15 = false
	if p13 == "anim" then
		v15 = v_u_11.Anim.has(p14)
	elseif p13 == "bg" then
		v15 = v_u_11.Look.BACKGROUNDS[p14] ~= nil
	elseif p13 == "frame" then
		v15 = v_u_11.Look.FRAMES[p14] ~= nil
	end
	if not v15 then
		return false
	end
	local v16 = v_u_5.shared.KillCardCosmetics
	if v16 ~= nil then
		local v17 = v16.byId
		if type(v17) == "function" then
			local v18 = v16.byId
			local v19, v20 = pcall(v18, p14)
			if v19 then
				v19 = v20 ~= nil
			end
			return v19
		end
	end
	return true
end
local v_u_22 = {
	["shove"] = "Shove"
}
local function v_u_28() -- name: modelEnv
	-- upvalues: (copy) v_u_21, (ref) v_u_5, (copy) v_u_22
	return {
		["known"] = v_u_21,
		["titleName"] = function(p23) -- name: titleName
			-- upvalues: (ref) v_u_5
			local v24 = v_u_5.shared.Tasks
			if v24 then
				v24 = v24.titles
			end
			if v24 then
				v24 = v24[p23]
			end
			if type(v24) == "string" then
				return v24
			else
				return nil
			end
		end,
		["weaponName"] = function(p25) -- name: weaponName
			-- upvalues: (ref) v_u_22, (ref) v_u_5
			if v_u_22[p25] then
				return v_u_22[p25]
			end
			local v26 = v_u_5.shared.Items
			if v26 then
				v26 = v26.get(p25)
			end
			if v26 then
				local v27 = v26.name
				if type(v27) == "string" then
					return v26.name
				end
			end
			return nil
		end
	}
end
local function v_u_40(p29) -- name: reportKiller
	-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) v_u_12
	local v30 = v_u_5.lib.MenuReport
	if v30 == nil then
		return false
	end
	local v31 = v30.openHunt
	local v32 = {
		["cctx"] = v_u_5
	}
	local v36 = {
		["userId"] = p29.uid,
		["name"] = p29.name,
		["display"] = p29.display,
		["onClose"] = function(p33) -- name: onClose
			-- upvalues: (ref) v_u_9
			if v_u_9 ~= nil then
				local v34 = v_u_9.reportClosed
				local v35 = p33 == true
				pcall(v34, v35)
			end
		end
	}
	local v37, v38 = pcall(v31, v32, v36)
	if v37 and v38 ~= nil then
		local v39 = v_u_12
		v39.reports = v39.reports + 1
	end
	if v37 then
		v37 = v38 ~= nil
	end
	return v37
end
local function v_u_46() -- name: canReport
	-- upvalues: (ref) v_u_5
	local v41 = v_u_5.lib.MenuReport
	if v41 == nil then
		return false
	end
	local v42 = v41.available
	local v43 = {
		["cctx"] = v_u_5
	}
	local v44, v45 = pcall(v42, v43)
	if v44 then
		v44 = v45 == true
	end
	return v44
end
local function v_u_57() -- name: buildCard
	-- upvalues: (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (copy) v_u_40, (copy) v_u_46, (ref) v_u_4, (copy) v_u_12
	if v_u_9 == nil then
		local v47, v48 = v_u_6.screen("HushPvpKill", v_u_7.layer.hud + 4, {
			["insets"] = "Device",
			["enabled"] = false
		})
		v_u_10 = v47
		v_u_9 = v_u_11.PvpKillCard.new({
			["UI"] = v_u_6,
			["Theme"] = v_u_7,
			["root"] = v48,
			["M"] = v_u_11.M,
			["L"] = v_u_11.L,
			["Look"] = v_u_11.Look,
			["Fx"] = v_u_11.Fx,
			["Rig"] = v_u_11.Rig,
			["AnimRig"] = v_u_5.lib.AnimRig,
			["Poses"] = v_u_5.lib.FilmPhotoPoses,
			["Anim"] = v_u_11.Anim,
			["deps"] = v_u_11.Rig.depsOf(v_u_5),
			["onReport"] = v_u_40,
			["canReport"] = v_u_46,
			["shouldClose"] = function(p49) -- name: shouldClose
				-- upvalues: (ref) v_u_5, (ref) v_u_4
				if p49 < 3 then
					return false
				end
				local v50 = v_u_5.session.place
				local v51 = v_u_4
				local v52, v53 = pcall(v50, v51)
				if v52 and v53 ~= "Raid" then
					return true
				end
				local v54
				if v_u_4 == nil then
					v54 = false
				else
					v54 = v_u_4:GetAttribute("RaidStatus") == "Alive"
				end
				return v54
			end,
			["onClosed"] = function(p55) -- name: onClosed
				-- upvalues: (ref) v_u_12, (ref) v_u_10
				local v56 = tostring(p55 or "closed")
				v_u_12.closed[v56] = (v_u_12.closed[v56] or 0) + 1
				v_u_12.lastClose = v56
				if v_u_10 then
					v_u_10.Enabled = false
				end
			end
		})
	end
end
local function v_u_77(p58) -- name: onCard
	-- upvalues: (ref) v_u_8, (copy) v_u_12, (ref) v_u_11, (ref) v_u_4, (copy) v_u_28, (copy) v_u_57, (ref) v_u_9, (ref) v_u_10, (ref) v_u_6, (copy) v_u_2
	if not v_u_8 then
		return
	end
	local v59 = v_u_12
	v59.received = v59.received + 1
	local v60 = v_u_11.M.model(p58, not v_u_4 and 0 or v_u_4.UserId, (v_u_28()))
	if v60 ~= nil then
		local v61 = v_u_57
		local v62, v63 = pcall(v61)
		if v62 and v_u_9 ~= nil then
			if v_u_10 then
				v_u_10.Enabled = true
			end
			local v64 = v_u_12
			v64.shown = v64.shown + 1
			local v65 = v_u_9.show
			local v66, v67 = pcall(v65, v60)
			if not v66 then
				local v68 = v_u_12
				v68.showFail = v68.showFail + 1
				warn("[PvpCardClient] show failed:", v67)
			end
			local function v70()
				-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_2
				if v_u_6.device and v_u_6.device() == "Gamepad" then
					local v69 = v_u_9.focusTargets()
					if v69[1] then
						v_u_2.SelectedObject = v69[1]
					end
				end
			end
			pcall(v70)
		else
			local v71 = v_u_12
			v71.buildFail = v71.buildFail + 1
			warn("[PvpCardClient] card failed:", v63)
		end
	end
	local v72 = v_u_12
	v72.rejected = v72.rejected + 1
	local v73 = warn
	local v74 = "[PvpCardClient] kill card message rejected (no usable killer id):"
	local v75
	if type(p58) == "table" then
		local v76 = p58.u
		v75 = tostring(v76)
		if v75 then
			v73(v74, v75)
		else
			v75 = type(p58)
			v73(v74, v75)
		end
	else
		v75 = type(p58)
		v73(v74, v75)
		return
	end
end
local function v_u_82() -- name: rebuild
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) v_u_57
	if v_u_9 ~= nil then
		local v78 = v_u_9.snapshot()
		local v79 = v_u_9.destroy
		pcall(v79)
		v_u_9 = nil
		if v_u_10 then
			v_u_10:Destroy()
			v_u_10 = nil
		end
		if v78 ~= nil then
			local v80 = v_u_57
			if pcall(v80) and v_u_9 ~= nil then
				if v_u_10 then
					v_u_10.Enabled = true
				end
				local v81 = v_u_9.restore
				pcall(v81, v78)
			end
		end
	end
end
function v3.init(p_u_83) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_11, (copy) v_u_82, (copy) v_u_77, (ref) v_u_9, (copy) v_u_12
	v_u_5 = p_u_83
	local v84, v85 = pcall(function()
		-- upvalues: (copy) p_u_83
		return p_u_83.shared.GameMode.rule("killCardCosmetics")
	end)
	if v84 and v85 == true then
		v_u_8 = true
		v_u_6 = p_u_83.lib.HushUI
		local v86 = v_u_6.bind
		pcall(v86, p_u_83)
		v_u_7 = p_u_83.shared.Theme
		v_u_11 = {
			["M"] = p_u_83.shared.PvpCardModel,
			["L"] = p_u_83.shared.PvpCardLayout,
			["Look"] = p_u_83.shared.KillCardLook,
			["Anim"] = p_u_83.shared.KillCardAnim,
			["Poses"] = p_u_83.shared.KillCardPoses,
			["Fx"] = p_u_83.lib.KillCardFx,
			["Rig"] = p_u_83.lib.KillCardRig,
			["PvpKillCard"] = p_u_83.lib.PvpKillCard
		}
		local v87 = p_u_83.on
		if type(v87) == "function" then
			p_u_83.on("ui.rebuild", v_u_82)
		end
		task.spawn(function()
			-- upvalues: (copy) p_u_83, (ref) v_u_77
			local v88 = p_u_83.net.listen
			local v89 = v_u_77
			pcall(v88, "kill.card", v89)
		end)
		p_u_83.command("pvpcard.show", function(p90)
			-- upvalues: (ref) v_u_77, (ref) v_u_9
			local v91 = type(p90) ~= "table" and {} or p90
			local v92 = v91[1]
			local v93 = tonumber(v92) or 9100000001
			local v94 = {
				["u"] = nil,
				["n"] = "SimKiller",
				["d"] = "Sim Killer",
				["tag"] = nil,
				["k"] = 12,
				["x"] = 3,
				["c"] = nil,
				["w"] = "ak74",
				["dist"] = 42,
				["head"] = true,
				["f"] = nil,
				["u"] = v93
			}
			local v95 = v91[5] or "TEST"
			v94.tag = tostring(v95)
			local v96 = {}
			local v97 = v91[2] or "ka_tornado_kick"
			v96.anim = tostring(v97)
			local v98 = v91[3] or "kb_aurora"
			v96.bg = tostring(v98)
			local v99 = v91[4] or "kf_absolute_zero"
			v96.frame = tostring(v99)
			local v100 = v91[6] or "op1_icewalker"
			v96.title = tostring(v100)
			v94.c = v96
			v94.f = v93 >= 9100000000
			v_u_77(v94)
			if v_u_9 == nil then
				return "no card"
			end
			local v101 = v_u_9.state()
			local v102 = v101.open
			local v103 = tostring(v102)
			local v104 = v101.mode
			local v105 = tostring(v104)
			local v106 = v101.anim
			local v107 = tostring(v106)
			local v108 = v101.bg
			local v109 = tostring(v108)
			local v110 = v101.frameId
			return ("open=%s mode=%s anim=%s bg=%s frame=%s name=[%s] figure=%s"):format(v103, v105, v107, v109, tostring(v110), v101.name, not v101.figure and "-" or v101.figure.kind)
		end)
		p_u_83.command("pvpcard.close", function()
			-- upvalues: (ref) v_u_9
			if v_u_9 ~= nil then
				v_u_9.close("command")
			end
			return "closed"
		end)
		p_u_83.command("pvpcard.state", function()
			-- upvalues: (ref) v_u_9
			if v_u_9 == nil then
				return "no card yet (pvpcard.show first)"
			end
			local v111 = v_u_9.state()
			local v112 = v111.figure
			local v113 = "open=%s hidden=%s visible=%s mode=%s uid=%s name=[%s] title=[%s] stats=[%s] weapon=[%s] anim=%s bg=%s frame=%s left=%.1f layers=%d figure=%s held=%s writes=%s instances=%s closedBy=%s shown=%d"
			local v114 = v111.open
			local v115 = tostring(v114)
			local v116 = v111.hidden
			local v117 = tostring(v116)
			local v118 = v111.visible
			local v119 = tostring(v118)
			local v120 = v111.mode
			local v121 = tostring(v120)
			local v122 = v111.uid
			local v123 = tostring(v122)
			local v124 = v111.name
			local v125 = v111.title
			local v126 = v111.stats
			local v127 = v111.weapon
			local v128 = v111.anim
			local v129 = tostring(v128)
			local v130 = v111.bg
			local v131 = tostring(v130)
			local v132 = v111.frameId
			local v133 = tostring(v132)
			local v134 = v111.left
			local v135 = v111.layers
			local v136 = not v112 and "-" or v112.kind
			local v137
			if v112 then
				local v138 = v112.held
				v137 = tostring(v138)
			else
				v137 = "-"
			end
			local v139
			if v112 then
				local v140 = v112.writes
				v139 = tostring(v140)
			else
				v139 = "-"
			end
			local v141
			if v112 then
				local v142 = v112.instances
				v141 = tostring(v142)
			else
				v141 = "-"
			end
			return v113:format(v115, v117, v119, v121, v123, v124, v125, v126, v127, v129, v131, v133, v134, v135, v136, v137, v139, v141, v111.closedBy, v111.shown)
		end)
		p_u_83.command("pvpcard.anims", function()
			-- upvalues: (ref) v_u_11
			return table.concat(v_u_11.Anim.ids(), " ")
		end)
		p_u_83.command("pvpcard.stats", function()
			-- upvalues: (ref) v_u_12
			local v143 = {}
			for v144, v145 in v_u_12.closed do
				local v146 = v144 .. "=" .. tostring(v145)
				table.insert(v143, v146)
			end
			table.sort(v143)
			return ("received=%d rejected=%d shown=%d reports=%d buildFail=%d showFail=%d lastClose=%s closed[%s]"):format(v_u_12.received, v_u_12.rejected, v_u_12.shown, v_u_12.reports, v_u_12.buildFail, v_u_12.showFail, v_u_12.lastClose, table.concat(v143, " "))
		end)
	end
end
function v3.start() -- name: start end
function v3.step(_) -- name: step
	-- upvalues: (ref) v_u_9
	if v_u_9 ~= nil and v_u_9.isOpen() then
		v_u_9.step(os.clock())
	end
end
function v3.enabled() -- name: enabled
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v3.card() -- name: card
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v3.stats() -- name: stats
	-- upvalues: (copy) v_u_12
	return v_u_12
end
function v3._onCard(p147) -- name: _onCard
	-- upvalues: (copy) v_u_77
	v_u_77(p147)
end
function v3._setPlayer(p148) -- name: _setPlayer
	-- upvalues: (ref) v_u_4
	v_u_4 = p148
end
return v3