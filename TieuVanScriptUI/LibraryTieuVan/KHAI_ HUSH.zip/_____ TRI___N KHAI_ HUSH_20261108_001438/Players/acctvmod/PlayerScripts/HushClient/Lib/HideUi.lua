-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideUi

local v_u_1 = game:GetService("Players")
local v_u_59 = {
	["new"] = function(p_u_2) -- name: new
		local v_u_3 = p_u_2.player
		local v_u_4 = p_u_2.clean
		local v_u_5 = p_u_2.rules
		local v_u_6 = p_u_2.world
		local v_u_7 = v_u_5.HOLDER
		local v_u_9 = p_u_2.spawn or function(p8)
			task.spawn(p8)
		end
		local v_u_10 = p_u_2.yield or function()
			task.wait()
		end
		local v_u_11 = {}
		local v_u_12 = false
		local v_u_13 = 0
		local v_u_14 = setmetatable({}, {
			["__mode"] = "k"
		})
		local v_u_15 = setmetatable({}, {
			["__mode"] = "k"
		})
		local v_u_16 = setmetatable({}, {
			["__mode"] = "k"
		})
		local v_u_17 = {}
		local function v_u_22(p_u_18) -- name: evalScreen
			-- upvalues: (ref) v_u_12, (copy) v_u_5, (copy) v_u_16, (copy) v_u_3, (copy) v_u_14, (copy) v_u_4, (copy) v_u_7, (copy) v_u_15, (copy) v_u_22
			local v19 = v_u_12
			if v19 then
				v19 = v_u_5.hides(p_u_18.Name, p_u_18.DisplayOrder)
			end
			local v20 = v_u_5.HOSTS[p_u_18.Name]
			if v20 ~= nil then
				v_u_16[p_u_18] = v20
				if v19 and v_u_5.hostOpen(p_u_18.Name, v_u_3:GetAttribute(v20)) then
					v19 = false
				end
			end
			local v21 = v_u_14[p_u_18] ~= nil
			if v19 and not v21 then
				v_u_14[p_u_18] = "screen"
				v_u_4.force(p_u_18, "Enabled", false, v_u_7)
			elseif not v19 and v21 then
				v_u_14[p_u_18] = nil
				v_u_4.release(p_u_18, "Enabled", v_u_7)
			end
			if v_u_12 and v_u_15[p_u_18] == nil then
				v_u_15[p_u_18] = { p_u_18:GetPropertyChangedSignal("Name"):Connect(function()
						-- upvalues: (ref) v_u_22, (copy) p_u_18
						v_u_22(p_u_18)
					end), p_u_18:GetPropertyChangedSignal("DisplayOrder"):Connect(function()
						-- upvalues: (ref) v_u_22, (copy) p_u_18
						v_u_22(p_u_18)
					end) }
			end
		end
		local function v_u_25(p23) -- name: evalChild
			-- upvalues: (copy) v_u_22, (ref) v_u_12, (copy) v_u_14, (copy) v_u_4, (copy) v_u_7
			local v24 = p23.ClassName
			if v24 == "ScreenGui" then
				v_u_22(p23)
			elseif v24 == "BillboardGui" and (v_u_12 and v_u_14[p23] == nil) then
				v_u_14[p23] = "billboard"
				v_u_4.force(p23, "Enabled", false, v_u_7)
			end
		end
		local function v_u_48() -- name: startLayer
			-- upvalues: (ref) v_u_13, (copy) p_u_2, (copy) v_u_17, (copy) v_u_25, (copy) v_u_22, (ref) v_u_12, (copy) v_u_14, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_16, (copy) v_u_6, (copy) v_u_9, (copy) v_u_10
			v_u_13 = v_u_13 + 1
			local v_u_26 = v_u_13
			local v27 = p_u_2.gui()
			if v27 then
				local v28 = v_u_17
				local v29 = v27.ChildAdded
				local v30 = v_u_25
				table.insert(v28, v29:Connect(v30))
				for _, v31 in v27:GetChildren() do
					local v32 = v31.ClassName
					if v32 == "ScreenGui" then
						v_u_22(v31)
					else
						if v32 ~= "BillboardGui" or (not v_u_12 or v_u_14[v31] ~= nil) then
							continue
						end
						v_u_14[v31] = "billboard"
						v_u_4.force(v31, "Enabled", false, v_u_7)
					end
				end
			end
			local v33 = {}
			for _, v_u_34 in v_u_5.HOSTS do
				if v33[v_u_34] then
					continue
				end
				v33[v_u_34] = true
				local v35 = v_u_17
				local v36 = v_u_3:GetAttributeChangedSignal(v_u_34)
				local function v39()
					-- upvalues: (ref) v_u_16, (copy) v_u_34, (ref) v_u_22
					for v37, v38 in v_u_16 do
						if v38 ~= v_u_34 then
							continue
						end
						v_u_22(v37)
					end
				end
				table.insert(v35, v36:Connect(v39))
			end
			local v40 = v_u_17
			local v41 = v_u_6.DescendantAdded
			local function v43(p42)
				-- upvalues: (ref) v_u_12, (ref) v_u_14, (ref) v_u_4, (ref) v_u_7
				if p42.ClassName == "BillboardGui" and (v_u_12 and v_u_14[p42] == nil) then
					v_u_14[p42] = "billboard"
					v_u_4.force(p42, "Enabled", false, v_u_7)
				end
			end
			table.insert(v40, v41:Connect(v43))
			v_u_9(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_12, (ref) v_u_14, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (copy) v_u_26
				local v44 = v_u_6:GetDescendants()
				local v45 = 0
				for v46 = 1, #v44 do
					local v47 = v44[v46]
					if v47.ClassName == "BillboardGui" and (v_u_12 and v_u_14[v47] == nil) then
						v_u_14[v47] = "billboard"
						v_u_4.force(v47, "Enabled", false, v_u_7)
					end
					v45 = v45 + 1
					if v45 < 3000 then
						continue
					end
					v_u_10()
					if v_u_13 ~= v_u_26 or not v_u_12 then
						return
					end
					v45 = 0
				end
			end)
		end
		local function v_u_53() -- name: stopLayer
			-- upvalues: (ref) v_u_13, (copy) v_u_17, (copy) v_u_15, (copy) v_u_14, (copy) v_u_4, (copy) v_u_7
			v_u_13 = v_u_13 + 1
			for _, v49 in v_u_17 do
				v49:Disconnect()
			end
			table.clear(v_u_17)
			for _, v50 in v_u_15 do
				for _, v51 in v50 do
					v51:Disconnect()
				end
			end
			table.clear(v_u_15)
			for v52 in v_u_14 do
				v_u_4.release(v52, "Enabled", v_u_7)
				v_u_14[v52] = nil
			end
		end
		function v_u_11.set(p54) -- name: set
			-- upvalues: (ref) v_u_12, (copy) v_u_3, (copy) v_u_5, (copy) v_u_48, (copy) v_u_53
			local v55 = p54 == true
			if v55 == v_u_12 then
				return
			else
				v_u_12 = v55
				v_u_3:SetAttribute(v_u_5.ATTR_HIDDEN, v55)
				if v55 then
					v_u_48()
				else
					v_u_53()
				end
			end
		end
		function v_u_11.toggle() -- name: toggle
			-- upvalues: (copy) v_u_11, (ref) v_u_12
			v_u_11.set(not v_u_12)
		end
		function v_u_11.isHidden() -- name: isHidden
			-- upvalues: (ref) v_u_12
			return v_u_12
		end
		function v_u_11.stats() -- name: stats
			-- upvalues: (copy) v_u_14, (ref) v_u_12
			local v56 = 0
			local v57 = 0
			for _, v58 in v_u_14 do
				if v58 == "screen" then
					v57 = v57 + 1
				else
					v56 = v56 + 1
				end
			end
			return {
				["hidden"] = v_u_12,
				["screens"] = v57,
				["billboards"] = v56
			}
		end
		function v_u_11.destroy() -- name: destroy
			-- upvalues: (ref) v_u_12, (copy) v_u_11
			if v_u_12 then
				v_u_11.set(false)
			end
		end
		return v_u_11
	end
}
local v_u_60 = nil
function v_u_59.start(p61) -- name: start
	-- upvalues: (ref) v_u_60, (copy) v_u_1, (copy) v_u_59
	if v_u_60 ~= nil then
		return v_u_60
	end
	local v_u_62 = v_u_1.LocalPlayer
	local v63 = require(script.Parent:WaitForChild("FilmClean"))
	local v_u_64 = require(script.Parent:WaitForChild("HideUiRules"))
	local v_u_65 = v_u_59.new({
		["player"] = v_u_62,
		["gui"] = function() -- name: gui
			-- upvalues: (copy) v_u_62
			return v_u_62:FindFirstChildOfClass("PlayerGui")
		end,
		["world"] = workspace,
		["clean"] = v63,
		["rules"] = v_u_64
	})
	v_u_60 = v_u_65
	v_u_62:SetAttribute(v_u_64.ATTR_HIDDEN, false)
	local v66 = p61.controllers.Input
	if v66 then
		local v67 = v66.bind
		if type(v67) == "function" then
			v66.bind(v_u_64.ACTION, function()
				-- upvalues: (copy) v_u_65
				v_u_65.toggle()
			end)
		end
	end
	local v_u_68 = v_u_62:GetAttribute("Place")
	v_u_62:GetAttributeChangedSignal("Place"):Connect(function()
		-- upvalues: (copy) v_u_62, (copy) v_u_64, (copy) v_u_65, (ref) v_u_68
		local v69 = v_u_62:GetAttribute("Place")
		if not v_u_64.resetOnPlace(v_u_65.isHidden(), v_u_68, v69) then
			v_u_65.set(false)
		end
		v_u_68 = v69
	end)
	p61.command("hideui", function(p70)
		-- upvalues: (copy) v_u_65, (copy) v_u_62, (copy) v_u_64
		local v71 = string.lower
		local v72 = p70[1] or "state"
		local v73 = v71((tostring(v72)))
		if v73 == "on" then
			v_u_65.set(true)
		elseif v73 == "off" then
			v_u_65.set(false)
		elseif v73 == "toggle" then
			v_u_65.toggle()
		elseif v73 == "list" then
			local v74 = v_u_62:FindFirstChildOfClass("PlayerGui")
			local v75 = {}
			if v74 then
				for _, v76 in v74:GetChildren() do
					if not v76:IsA("ScreenGui") then
						continue
					end
					local v77, v78 = v_u_64.verdict(v76.Name, v76.DisplayOrder)
					local v79 = string.format
					local v80 = v76.Name
					local v81 = v76.DisplayOrder
					table.insert(v75, v79("%s[%d]=%s%s", v80, v81, v78, v77 and "(hidden)" or ""))
				end
			end
			table.sort(v75)
			return "hideui list: " .. table.concat(v75, " ")
		end
		local v82 = v_u_65.stats()
		local v83 = string.format
		local v84 = v82.hidden
		return v83("hideui hidden=%s screens=%d billboards=%d", tostring(v84), v82.screens, v82.billboards)
	end)
	return v_u_65
end
function v_u_59.set(p85) -- name: set
	-- upvalues: (ref) v_u_60
	if v_u_60 ~= nil then
		v_u_60.set(p85)
	end
end
function v_u_59.toggle() -- name: toggle
	-- upvalues: (ref) v_u_60
	if v_u_60 ~= nil then
		v_u_60.toggle()
	end
end
function v_u_59.isHidden() -- name: isHidden
	-- upvalues: (ref) v_u_60
	local v86
	if v_u_60 == nil then
		v86 = false
	else
		v86 = v_u_60.isHidden() == true
	end
	return v86
end
return v_u_59