-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / SelfStatusGlow

local v1 = game:GetService("Players")
local v_u_2 = {
	["name"] = "SelfStatusGlow",
	["order"] = 76
}
local v_u_3 = Color3.fromRGB(230, 40, 36)
local v_u_4 = Color3.fromRGB(255, 148, 20)
function v_u_2.bleedLevel(p5) -- name: bleedLevel
	if type(p5) ~= "number" or p5 ~= p5 then
		return 0
	end
	local v6 = math.floor(p5)
	return math.clamp(v6, 0, 3)
end
function v_u_2.state(p7) -- name: state
	-- upvalues: (copy) v_u_2
	if p7.enabled == false or (p7.inRaid ~= true or (p7.dead == true or p7.downed == true)) then
		return "none"
	end
	local v8 = p7.status
	if v8 ~= nil and v8 ~= "Alive" then
		return "none"
	end
	local v9 = v_u_2.bleedLevel(p7.bleeding) > 0
	local v10 = p7.fracture == true
	return v9 and v10 and "both" or (v9 and "bleed" or (v10 and "fracture" or "none"))
end
function v_u_2.pulseHz(p11, p12) -- name: pulseHz
	return p11 ~= "bleed" and p11 ~= "both" and 1.6 or (math.clamp(p12, 1, 3) - 1) * 0.4 + 1.6
end
function v_u_2.brightest(p13, p14) -- name: brightest
	return p13 ~= "bleed" and p13 ~= "both" and 0.15 or 0.2 - (math.clamp(p14, 1, 3) - 1) * 0.05
end
function v_u_2.look(p15, p16, p17) -- name: look
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	if p15 == "bleed" or (p15 == "fracture" or p15 == "both") then
		local v18 = (p17 ~= p17 or math.abs(p17) > 1000000000) and 0 or p17
		local v19 = v_u_2.brightest(p15, p16)
		local v20 = 0.85 - v19
		local v21 = 6.283185307179586 * v18
		local v22 = v19 + v20 * (math.cos(v21) * 0.5 + 0.5)
		if p15 == "bleed" then
			return v_u_3, v22
		elseif p15 == "fracture" then
			return v_u_4, v22
		elseif math.floor(v18) % 2 == 0 then
			return v_u_3, v22
		else
			return v_u_4, v22
		end
	else
		return nil, nil
	end
end
v_u_2.RED = v_u_3
v_u_2.ORANGE = v_u_4
local v_u_23 = v1.LocalPlayer
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = {}
local v_u_28 = 0
local v_u_29 = nil
local v_u_30 = ""
local v_u_31 = nil
local v_u_32 = 0
local v_u_33 = false
local v_u_34 = false
local function v_u_37() -- name: folder
	-- upvalues: (ref) v_u_31
	if v_u_31 and v_u_31.Parent then
		return v_u_31
	end
	local v35 = workspace:FindFirstChild("HushLocal")
	if not v35 then
		v35 = Instance.new("Folder")
		v35.Name = "HushLocal"
		v35.Parent = workspace
	end
	local v36 = v35:FindFirstChild("StatusGlow")
	if not v36 then
		v36 = Instance.new("Folder")
		v36.Name = "StatusGlow"
		v36.Parent = v35
	end
	v_u_31 = v36
	return v_u_31
end
local function v_u_41() -- name: destroyGlow
	-- upvalues: (copy) v_u_27, (ref) v_u_25, (ref) v_u_26, (ref) v_u_29
	for _, v38 in v_u_27 do
		v38:Disconnect()
	end
	table.clear(v_u_27)
	local v39 = v_u_25
	v_u_25 = nil
	v_u_26 = nil
	v_u_29 = nil
	if v39 then
		local v40 = v39.Destroy
		pcall(v40, v39)
	end
end
local function v_u_55(p_u_42) -- name: ensure
	-- upvalues: (ref) v_u_25, (ref) v_u_26, (copy) v_u_41, (copy) v_u_37, (copy) v_u_27
	local v43 = v_u_25
	if v43 and (v43.Parent ~= nil and (v_u_26 == p_u_42 and v43.Adornee == p_u_42)) then
		return v43
	end
	v_u_41()
	local v_u_44 = v_u_37()
	if not v_u_44 then
		return nil
	end
	local v46, v47 = pcall(function()
		-- upvalues: (copy) p_u_42, (copy) v_u_44
		local v45 = Instance.new("Highlight")
		v45.Name = "SelfStatusGlow"
		v45.FillTransparency = 1
		v45.OutlineTransparency = 0.85
		v45.DepthMode = Enum.HighlightDepthMode.Occluded
		v45.Adornee = p_u_42
		v45.Parent = v_u_44
		return v45
	end)
	if not v46 or typeof(v47) ~= "Instance" then
		return nil
	end
	v_u_25 = v47
	v_u_26 = p_u_42
	local v48 = v_u_27
	local v49 = p_u_42.Destroying
	local v50 = v_u_41
	table.insert(v48, v49:Connect(v50))
	local v51 = v_u_27
	local v52 = p_u_42.AncestryChanged
	local function v54(_, p53)
		-- upvalues: (ref) v_u_41
		if p53 == nil then
			v_u_41()
		end
	end
	table.insert(v51, v52:Connect(v54))
	return v_u_25
end
local function v_u_62() -- name: audit
	-- upvalues: (ref) v_u_31, (ref) v_u_25, (copy) v_u_23, (ref) v_u_34
	local v56 = v_u_31
	if v56 and v56.Parent then
		for _, v57 in v56:GetChildren() do
			if v57 == v_u_25 then
				continue
			end
			v57:Destroy()
		end
	end
	if v_u_25 then
		local v58 = 0
		local v59 = workspace:FindFirstChild("HushLocal")
		if v59 then
			for _, v60 in v59:GetChildren() do
				if v60 == v56 then
					continue
				end
				for _, v61 in v60:GetChildren() do
					if not v61:IsA("Highlight") then
						continue
					end
					v58 = v58 + 1
				end
			end
		end
		if v_u_23:GetAttribute("StatusGlowOthers") ~= v58 then
			v_u_23:SetAttribute("StatusGlowOthers", v58)
		end
		if v58 >= 30 and not v_u_34 then
			v_u_34 = true
			warn("[SelfStatusGlow] " .. v58 .. " other Highlights: the client renders 31")
		end
	end
end
local function v_u_69(p63) -- name: readInput
	-- upvalues: (copy) v_u_23
	local v64 = {
		["enabled"] = v_u_23:GetAttribute("StatusOutline") ~= false,
		["inRaid"] = v_u_23:GetAttribute("Place") == "Raid",
		["status"] = v_u_23:GetAttribute("RaidStatus")
	}
	local v65
	if p63 == nil then
		v65 = false
	else
		v65 = p63:GetAttribute("Dead") == true
	end
	v64.dead = v65
	local v66
	if p63 == nil then
		v66 = false
	else
		v66 = p63:GetAttribute("Downed") == true
	end
	v64.downed = v66
	local v67
	if p63 then
		v67 = p63:GetAttribute("Bleeding")
	else
		v67 = nil
	end
	v64.bleeding = v67
	local v68
	if p63 then
		v68 = p63:GetAttribute("Fracture")
	else
		v68 = nil
	end
	v64.fracture = v68
	return v64
end
local function v_u_84(p70) -- name: tick
	-- upvalues: (copy) v_u_23, (copy) v_u_69, (ref) v_u_33, (ref) v_u_24, (copy) v_u_2, (copy) v_u_41, (ref) v_u_30, (ref) v_u_32, (copy) v_u_62, (copy) v_u_55, (ref) v_u_28, (ref) v_u_29
	local v71 = v_u_23.Character
	local v72 = v_u_69(v71)
	if v72.inRaid and (not v_u_33 and (v_u_23:GetAttribute("StatusOutline") == nil and (v_u_24 and v_u_24.net))) then
		v_u_33 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_24, (ref) v_u_23
			local v73 = v_u_24.net.invoke
			local v74, v75 = pcall(v73, "menu.get", {
				["what"] = "settings"
			})
			if v74 and type(v75) == "table" then
				local v76 = v75.statusOutline
				if type(v76) == "boolean" and v_u_23:GetAttribute("StatusOutline") == nil then
					v_u_23:SetAttribute("StatusOutline", v75.statusOutline)
				end
			end
		end)
	end
	local v77 = v_u_2.state(v72)
	if v77 == "none" or (v71 == nil or v71.Parent == nil) then
		v_u_41()
		if v_u_30 ~= "none" then
			v_u_30 = "none"
			v_u_23:SetAttribute("StatusGlow", "none")
		end
		local v78 = os.clock()
		if v_u_32 <= v78 then
			v_u_32 = v78 + 1
			v_u_62()
		end
		return
	else
		local v79 = v_u_2.bleedLevel(v72.bleeding)
		local v80 = v_u_55(v71)
		if v80 then
			if v77 ~= v_u_30 then
				v_u_30 = v77
				v_u_23:SetAttribute("StatusGlow", v77)
			end
			v_u_28 = v_u_28 + p70 * v_u_2.pulseHz(v77, v79)
			if v_u_28 > 1000 then
				v_u_28 = v_u_28 - 1000
			end
			local v81, v82 = v_u_2.look(v77, v79, v_u_28)
			if v81 and v82 then
				v80.OutlineTransparency = v82
				if v81 ~= v_u_29 then
					v80.OutlineColor = v81
					v_u_29 = v81
				end
			end
			local v83 = os.clock()
			if v_u_32 <= v83 then
				v_u_32 = v83 + 1
				v_u_62()
			end
		end
	end
end
function v_u_2.init(p85) -- name: init
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_30, (copy) v_u_23, (ref) v_u_31
	v_u_24 = p85
	p85.command("statusglow.state", function()
		-- upvalues: (ref) v_u_25, (ref) v_u_30, (ref) v_u_23, (ref) v_u_31
		local v86 = v_u_25
		local v87 = "kind=%s glow=%s adornee=%s fill=%s outline=%.2f color=%s depth=%s others=%s count=%d"
		local v88 = v_u_30
		local v89
		if v86 == nil then
			v89 = false
		else
			v89 = v86.Parent ~= nil
		end
		local v90 = tostring(v89)
		local v91
		if v86 == nil then
			v91 = false
		else
			v91 = v86.Adornee == v_u_23.Character
		end
		local v92 = v_u_23
		return v87:format(v88, v90, tostring(v91), not v86 and "-" or ("%.2f"):format(v86.FillTransparency), not v86 and -1 or v86.OutlineTransparency, not v86 and "-" or v86.OutlineColor:ToHex(), not v86 and "-" or v86.DepthMode.Name, tostring(v92:GetAttribute("StatusGlowOthers")), v_u_31 and #v_u_31:GetChildren() or 0)
	end)
end
function v_u_2.start() -- name: start
	-- upvalues: (copy) v_u_37
	local v93 = v_u_37()
	if v93 then
		v93:ClearAllChildren()
	end
end
function v_u_2.step(p94) -- name: step
	-- upvalues: (copy) v_u_84, (copy) v_u_41, (ref) v_u_30, (copy) v_u_23, (ref) v_u_34
	local v95 = v_u_84
	local v96, v97 = pcall(v95, p94)
	if not v96 then
		v_u_41()
		if v_u_30 ~= "none" then
			v_u_30 = "none"
			v_u_23:SetAttribute("StatusGlow", "none")
		end
		if not v_u_34 then
			v_u_34 = true
			warn("[SelfStatusGlow] step failed:", v97)
		end
	end
end
return v_u_2