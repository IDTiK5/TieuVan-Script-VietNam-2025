-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDExtractCoach

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {
	["current"] = nil,
	["TIPS"] = {
		["quickmove"] = {
			["phone"] = "Tap an item to move it across",
			["pc"] = "Right click an item for its options. Quick move (Take on the ground) sends it to the other side at once.",
			["touch"] = "Tap an item to move it to the other side at once.",
			["pad"] = "Select an item and open its options (the hints at the top show how). Quick move (Take on the ground) sends it to the other side at once."
		},
		["map"] = {
			["phone"] = "Tap {map} to see the exits",
			["pc"] = "Press {map} to open the map. It marks the exits and shows you and your squad.",
			["touch"] = "Tap the {map} button at the top right to open the map. It marks the exits and shows you and your squad.",
			["pad"] = "{map} to open the map. It marks the exits and shows you and your squad."
		},
		["rotate"] = {
			["phone"] = "Tap {rotateItem} to turn an item",
			["pc"] = "Long items fit better turned. Press {rotateItem} while you drag an item to rotate it.",
			["touch"] = "Long items fit better turned. With an item picked up, tap {rotateItem} in the button strip next to it.",
			["pad"] = "Long items fit better turned. While you carry an item, press {rotateItem} to rotate it."
		},
		["containers"] = {
			["phone"] = "Drag the list to see them all",
			["pc"] = "Every container within reach opens in the Nearby column. Scroll it with the mouse wheel to see them all.",
			["touch"] = "Every container within reach opens in the Nearby column. Drag it up or down to see them all.",
			["pad"] = "Every container within reach opens in the Nearby column. The shoulder buttons jump to the next one."
		},
		["twist"] = {
			["phone"] = "Twist two fingers to turn the view",
			["pc"] = "Press {camLeft} or {camRight} to turn the view.",
			["touch"] = "Twist two fingers to turn the view. The < > buttons in the MORE tray turn it too.",
			["pad"] = "Turn the view with {camLeft} or {camRight}."
		},
		["sprint"] = {
			["phone"] = "Push the stick to its rim to sprint",
			["pc"] = "Hold {sprint} to sprint.",
			["touch"] = "Push the left stick all the way to its rim to sprint. Pull back to walk.",
			["pad"] = "Press {sprint} to sprint."
		}
	},
	["TITLES"] = {
		["quickmove"] = "Tip: quick move",
		["map"] = "Tip: the map",
		["rotate"] = "Tip: rotate items",
		["containers"] = "Tip: several containers",
		["twist"] = "Tip: turn the view",
		["sprint"] = "Tip: sprint"
	},
	["HINT_FALLBACK"] = {
		["map"] = "the map key",
		["rotateItem"] = "the rotate key",
		["camLeft"] = "the turn left key",
		["camRight"] = "the turn right key",
		["sprint"] = "the sprint key"
	}
}
local v_u_5 = {}
local v_u_6 = {
	["mapKnown"] = false,
	["turned"] = false,
	["turnHooked"] = false
}
function v_u_4.tipText(p7, p8, p_u_9) -- name: tipText
	-- upvalues: (copy) v_u_4
	local v10 = v_u_4.TIPS[p7]
	if v10 then
		local v11 = v10[p8 == "phone" and "phone" or ((p8 == "Touch" or p8 == "touch") and "touch" or ((p8 == "Gamepad" or p8 == "pad") and "pad" or "pc"))]
		if type(v11) == "string" then
			return string.gsub(v11, "{(%w+)}", function(p12)
				-- upvalues: (copy) p_u_9, (ref) v_u_4
				local v13 = ""
				local v14
				if p_u_9 then
					local v15 = p_u_9
					local v16
					v16, v14 = pcall(v15, p12)
					if v16 then
						if type(v14) ~= "string" then
							v14 = v13
						end
					else
						v14 = v13
					end
				else
					v14 = v13
				end
				if v14 == "" then
					v14 = v_u_4.HINT_FALLBACK[p12] or p12
				end
				return v14
			end)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_4.lootWindows(p17, p18) -- name: lootWindows
	if type(p17) == "table" then
		local v19 = p17.open
		if type(v19) == "table" then
			local v20 = p17.containers
			if type(v20) == "table" then
				local v21 = 0
				for _, v22 in p17.open do
					local v23 = p17.containers[v22]
					if type(v23) ~= "table" or (v23.world ~= true or (v23.sub == true or v23.ground == true and p18 ~= true)) then
						continue
					end
					v21 = v21 + 1
				end
				return v21
			end
		end
	end
	return 0
end
function v_u_4.tipDur(p24) -- name: tipDur
	return p24 == true and 7 or 9
end
function v_u_4.lootShown(p25, p26, p27) -- name: lootShown
	local v28
	if p25 == true and p27 >= 1 then
		v28 = p26 ~= "gear"
	else
		v28 = false
	end
	return v28
end
function v_u_4.nextTip(p29) -- name: nextTip
	-- upvalues: (copy) v_u_4
	if type(p29) ~= "table" or p29.calm == false then
		return nil
	end
	local v30 = p29.seen or {}
	if p29.invOpen == true then
		if not v30.rotate then
			local v31 = p29.dragSecs
			if (tonumber(v31) or 0) >= 0.4 then
				return "rotate"
			end
		end
		if not v30.containers then
			local v32 = p29.windows
			if (tonumber(v32) or 0) >= 2 then
				local v33 = p29.windowsSecs
				if (tonumber(v33) or 0) >= 0.4 then
					return "containers"
				end
			end
		end
		if not v30.quickmove then
			local v34 = v_u_4.lootShown
			local v35 = p29.section
			local v36 = p29.loot
			if v34(true, v35, tonumber(v36) or 0) then
				return "quickmove"
			end
		end
	elseif not v30.map and (p29.mapOpen ~= true and p29.mapKnown ~= true) then
		local v37 = p29.secs
		if (tonumber(v37) or 0) >= 60 then
			return "map"
		end
	end
	return nil
end
function v_u_4.twistDue(p38) -- name: twistDue
	if type(p38) ~= "table" or (p38.device ~= "Touch" or (p38.calm == false or (p38.turned == true or (p38.invOpen == true or p38.mapOpen == true)))) then
		return false
	end
	local v39 = not (p38.seen or {}).twist
	if v39 then
		local v40 = p38.secs
		v39 = (tonumber(v40) or 0) >= 30
	end
	return v39
end
function v_u_4.sprintDue(p41) -- name: sprintDue
	if type(p41) ~= "table" or (p41.device ~= "Touch" or (p41.calm == false or (p41.invOpen == true or p41.mapOpen == true))) then
		return false
	end
	local v42 = not (p41.seen or {}).sprint
	if v42 then
		local v43 = p41.secs
		v42 = (tonumber(v43) or 0) >= 15
	end
	return v42
end
function v_u_4.cards(p44, p45) -- name: cards
	local v46 = p45.map or "Map"
	local v47 = tostring(v46)
	local v48 = p45.exits or "Exits"
	local v49 = tostring(v48)
	local v50 = {}
	local v51 = p45.compass == true and " The green EXIT marker points to the nearest one." or ""
	if p44 == 2 then
		v50.arrive = {
			["text"] = "Get out alive",
			["sub"] = nil,
			["sub"] = ("Same as in the tutorial: reach an open exit and stay in its zone until the ring is full. Map (%s), exit list (%s).%s"):format(v47, v49, v51)
		}
	else
		v50.arrive = {
			["text"] = "Your goal: get out alive",
			["sub"] = nil,
			["sub"] = ("What you find is only yours once you extract. The map (%s) marks the open exits; the exit list (%s) shows distance and direction. Get out before the clock at the top runs out.%s"):format(v47, v49, v51)
		}
	end
	local v52 = p45.condition or ""
	local v53 = tostring(v52)
	local v54 = (v53 == "" or string.lower(v53) == "always open") and "" or (" This one needs: %s."):format(v53)
	local v55 = p45.mapId == "hollow"
	local v56 = ""
	if v55 or p45.kind == "Heli" then
		if p45.state == "inbound" then
			v56 = p45.kind == "Heli" and " The helicopter is on its way: be in the zone when it lands." or " The cage is on its way down: wait in the zone."
		else
			v56 = p45.state == "boarding" and " It is waiting now: get in before it leaves." or (p45.state == "running" and " The engine is running: get in before it leaves." or v56)
		end
	end
	local v57 = p45.kind == "Heli" and (p45.state ~= "inbound" and p45.state ~= "boarding") and " Stand on the pad and use Light flare (you need a Signal Flare). The helicopter lands about a minute later and waits for you." or ""
	local v58 = {}
	local v59 = p45.name or "extract"
	v58.text = ("Exit: %s"):format((tostring(v59)))
	v58.sub = "Step into the marked zone and stay inside until the ring is full. Leaving the zone or taking a hit stops it." .. v54 .. v56 .. v57
	v50.zone = v58
	v50.stopped = {
		["text"] = "Extraction stopped",
		["sub"] = "You left the zone before the ring was full. Step back in and stay put until it fills."
	}
	v50.half = {
		["text"] = "Half the raid is over",
		["sub"] = "Loot only counts once you are out. Head for an exit when your bag is full or you are hurt."
	}
	local v60 = p45.melee or "Melee"
	local v61 = tostring(v60)
	local v62 = p45.throw or "a quick slot"
	v50.fight = {
		["text"] = "Close calls",
		["sub"] = nil,
		["sub"] = ("Gun in hand: melee (%s) shoves them back. Hit one on the ground to finish it. Throw (%s) a bottle or flare to lure them; a Demo Charge ends a crowd."):format(v61, (tostring(v62)))
	}
	local v63 = p45.minutes
	local v64 = tonumber(v63) or 5
	local v65 = {}
	local v66
	if v64 <= 1 then
		if v55 then
			v66 = "Last minute in the Hollow"
		else
			local v67 = p45.noun
			v66 = type(v67) ~= "string" and "Last minute in town" or "Last minute on the " .. p45.noun
		end
	else
		v66 = ("%d minutes left"):format(v64)
	end
	v65.text = v66
	local v68 = "At 0:00 "
	local v69
	if v55 then
		v69 = "the Hollow"
	else
		local v70 = p45.noun
		v69 = type(v70) ~= "string" and "the town" or "the " .. p45.noun
	end
	v65.sub = (v68 .. v69 .. " is sealed.") .. " Anyone still inside goes missing in action and loses everything except the secure case."
	v50.siren = v65
	v50.arrive.phoneText = "Get out alive"
	v50.arrive.phoneSub = "Reach an open exit, fill the ring"
	v50.zone.phoneSub = "Stay inside until the ring is full"
	v50.stopped.phoneSub = "Step back in and stay put"
	v50.half.phoneSub = "Loot counts only once you are out"
	v50.fight.phoneSub = "Shove them, finish them, or lure"
	v50.siren.phoneSub = "Get to an exit before it seals"
	return v50
end
function v_u_4.new(p_u_71, p_u_72) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_5, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4
	local v_u_73 = p_u_71.cctx
	local v_u_74 = v_u_2.LocalPlayer
	local v_u_75 = {}
	local v_u_76 = true
	local v_u_77 = 0
	local v_u_78 = nil
	local v_u_79 = nil
	local v_u_80 = nil
	local v_u_81 = -100
	local v_u_82 = {
		["invOpen"] = false,
		["dragSince"] = nil,
		["windows"] = 0,
		["loot"] = 0,
		["winSince"] = nil
	}
	local v_u_83 = {}
	local function v_u_90() -- name: shown
		-- upvalues: (copy) p_u_71, (copy) v_u_73, (ref) v_u_5
		local v84 = p_u_71.raid
		local v85 = not (v84 and v84.Parent) and v_u_73.runtime
		if v85 then
			v85 = v85:FindFirstChild("Raid")
		end
		local v86
		if v85 then
			local v87 = v85:GetAttribute("RaidId") or v85:GetAttribute("StartedAt") or ""
			v86 = tostring(v87) or ""
		else
			v86 = ""
		end
		local v88 = v86 == "" and "?" or v86
		local v89 = v_u_5[v88]
		if not v89 then
			v89 = {}
			v_u_5[v88] = v89
		end
		return v89
	end
	local function v_u_106() -- name: exits
		-- upvalues: (copy) p_u_71, (copy) v_u_73, (copy) v_u_74
		local v91 = {}
		local v92 = p_u_71.raid
		local v93 = not (v92 and v92.Parent) and v_u_73.runtime
		if v93 then
			v93 = v93:FindFirstChild("Raid")
		end
		if v93 then
			v93 = v93:FindFirstChild("Extracts")
		end
		local v94 = v_u_74.Character
		if v94 then
			v94 = v94:FindFirstChild("HumanoidRootPart")
		end
		local v95
		if v94 then
			v95 = v94.Position
		else
			v95 = nil
		end
		if not v93 then
			return v91
		end
		for _, v96 in v93:GetChildren() do
			if not v96:IsA("BasePart") or (v96:GetAttribute("Open") ~= true or v96:GetAttribute("Personal") == true) then
				continue
			end
			local v97, v98
			if v95 then
				local v99 = v96.CFrame:PointToObjectSpace(v95)
				local v100 = v96.Position.X - v95.X
				local v101 = v96.Position.Z - v95.Z
				v97 = Vector3.new(v100, 0, v101).Magnitude
				local v102 = v99.X
				if math.abs(v102) <= v96.Size.X / 2 + 12 then
					local v103 = v99.Z
					v98 = math.abs(v103) <= v96.Size.Z / 2 + 12
				else
					v98 = false
				end
			else
				v97 = (1 / 0)
				v98 = false
			end
			table.insert(v91, {
				["part"] = v96,
				["dist"] = v97,
				["near"] = v98
			})
		end
		table.sort(v91, function(p104, p105)
			return p104.dist < p105.dist
		end)
		return v91
	end
	local v_u_107 = {
		["loaded"] = false,
		["fetching"] = false,
		["seen"] = nil,
		["showing"] = false,
		["seen"] = {}
	}
	local function v_u_114(p108) -- name: markTip
		-- upvalues: (copy) v_u_107, (copy) v_u_73, (copy) v_u_74
		v_u_107.seen[p108] = true
		local v_u_109 = {}
		for v110 in v_u_107.seen do
			table.insert(v_u_109, v110)
		end
		table.sort(v_u_109)
		if v_u_73.net then
			local v111 = v_u_73.net.fire
			if type(v111) == "function" then
				task.spawn(function()
					-- upvalues: (ref) v_u_73, (copy) v_u_109
					local v112 = v_u_73.net.fire
					local v113 = {
						["op"] = "setting",
						["key"] = "tipsSeen",
						["value"] = nil,
						["value"] = table.concat(v_u_109, ",")
					}
					pcall(v112, "menu.op", v113)
				end)
			end
		end
		v_u_74:SetAttribute("TipsSeen", table.concat(v_u_109, ","))
	end
	local function v_u_130(p115) -- name: tipText
		-- upvalues: (copy) v_u_73, (ref) v_u_3, (ref) v_u_4
		local v116 = nil
		local v117 = v_u_73.controllers
		if v117 then
			v117 = v_u_73.controllers.Input
		end
		local v118
		if v117 then
			local v119 = v117.device
			if type(v119) == "function" then
				local v120 = v117.device
				local v121
				v121, v118 = pcall(v120)
				if v121 then
					if type(v118) ~= "string" then
						v118 = v116
					end
				else
					v118 = v116
				end
			else
				v118 = v116
			end
		else
			v118 = v116
		end
		if not v118 then
			local v122 = v_u_3:GetLastInputType()
			v118 = v122 == Enum.UserInputType.Touch and "Touch" or (string.find(tostring(v122), "Gamepad", 1, true) and "Gamepad" or "Keyboard")
		end
		return v_u_4.tipText(p115, v118, function(p123)
			-- upvalues: (ref) v_u_73
			local v124 = v_u_73
			local v125 = v124 and v124.controllers
			if v125 then
				v125 = v124.controllers.Input
			end
			if v125 then
				local v126 = v125.hint
				if type(v126) == "function" then
					local v127 = v125.hint
					local v128, v129 = pcall(v127, p123)
					if v128 and (type(v129) == "string" and v129 ~= "") then
						return v129
					end
				end
			end
			return ""
		end)
	end
	local function v_u_138() -- name: cardBusy
		-- upvalues: (ref) v_u_81, (copy) p_u_71
		if os.clock() - v_u_81 < 11 then
			return true
		end
		local v131 = p_u_71.mods
		if v131 then
			v131 = p_u_71.mods.HUDEvents
		end
		if v131 then
			local v132 = v131.state
			if type(v132) == "function" then
				local v133 = v131.state
				local v134, v135 = pcall(v133)
				if v134 and type(v135) == "string" then
					local v136, v137 = string.match(v135, "^card=(.-) queue=(%d+)")
					if v136 then
						return v136 ~= "-" and true or (tonumber(v137) or 0) > 0
					end
				end
			end
		end
		return false
	end
	local function v_u_150() -- name: watchInv
		-- upvalues: (copy) v_u_74, (copy) v_u_73, (copy) v_u_82, (ref) v_u_4, (copy) p_u_71
		local v139 = os.clock()
		local v140 = v_u_74:GetAttribute("InvUIOpen") == true
		local v141 = false
		if v140 then
			local v142 = v_u_73.controllers
			if v142 then
				v142 = v_u_73.controllers.InventoryUI
			end
			if v142 then
				local v143 = v142.isDragging
				if type(v143) == "function" then
					local v144 = v142.isDragging
					local v145
					v141, v145 = pcall(v144)
					if v141 then
						v141 = v145 == true
					end
				end
			end
		end
		v_u_82.invOpen = v140
		local v146 = v_u_82
		local v147
		if v141 then
			v147 = v_u_82.dragSince or v139
		else
			v147 = nil
		end
		v146.dragSince = v147
		v_u_82.windows = not v140 and 0 or v_u_4.lootWindows(p_u_71.inv)
		v_u_82.loot = not v140 and 0 or v_u_4.lootWindows(p_u_71.inv, true)
		local v148 = v_u_82
		local v149
		if v_u_82.windows >= 2 then
			v149 = v_u_82.winSince or v139
		else
			v149 = nil
		end
		v148.winSince = v149
	end
	local function v_u_165(p151, p152) -- name: showTip
		-- upvalues: (copy) v_u_130, (ref) v_u_4, (copy) v_u_114, (copy) v_u_107, (ref) v_u_81, (copy) v_u_73, (copy) p_u_72, (copy) v_u_82
		local v153 = v_u_130(p151)
		local v154 = v_u_4.TITLES[p151]
		if not (v153 and v154) then
			return false
		end
		if not p152 then
			v_u_114(p151)
			v_u_107.showing = true
			task.delay(4, function()
				-- upvalues: (ref) v_u_107
				v_u_107.showing = false
			end)
		end
		v_u_81 = os.clock()
		local v162 = v_u_4.tipText(p151, "phone", function(p155)
			-- upvalues: (ref) v_u_73
			local v156 = v_u_73
			local v157 = v156 and v156.controllers
			if v157 then
				v157 = v156.controllers.Input
			end
			if v157 then
				local v158 = v157.hint
				if type(v158) == "function" then
					local v159 = v157.hint
					local v160, v161 = pcall(v159, p155)
					if v160 and (type(v161) == "string" and v161 ~= "") then
						return v161
					end
				end
			end
			return ""
		end)
		local v163 = p_u_72
		local v164 = {
			["event"] = nil,
			["text"] = nil,
			["sub"] = nil,
			["phoneSub"] = nil,
			["kind"] = "info",
			["icon"] = "info",
			["category"] = "Tip",
			["dur"] = nil,
			["sting"] = "land",
			["event"] = "tip_" .. p151,
			["text"] = v154,
			["sub"] = v153,
			["phoneSub"] = v162,
			["dur"] = v_u_4.tipDur(v_u_82.invOpen)
		}
		pcall(v163, v164)
		return true
	end
	local function v_u_179() -- name: checkTips
		-- upvalues: (copy) v_u_150, (copy) v_u_107, (ref) v_u_6, (copy) v_u_74, (ref) v_u_80, (copy) v_u_138, (ref) v_u_4, (copy) v_u_82, (ref) v_u_78, (copy) v_u_73, (copy) v_u_165
		v_u_150()
		if v_u_107.loaded then
			if not v_u_107.showing then
				local v166 = v_u_74.Character
				if (v166 == nil or v166:GetAttribute("Action") ~= "Extract") and (v_u_80 ~= "progress" and v_u_80 ~= "interrupted") and not v_u_138() then
					local v167 = os.clock()
					local v168 = v_u_74:GetAttribute("RaidStatus")
					local v169 = v_u_4.nextTip({
						["seen"] = v_u_107.seen,
						["calm"] = v168 == nil and true or v168 == "Alive",
						["invOpen"] = v_u_82.invOpen,
						["mapOpen"] = v_u_74:GetAttribute("MapOpen") == true,
						["mapKnown"] = v_u_6.mapKnown,
						["secs"] = not v_u_78 and 0 or v167 - v_u_78,
						["dragSecs"] = not v_u_82.dragSince and 0 or v167 - v_u_82.dragSince,
						["windows"] = v_u_82.windows,
						["windowsSecs"] = not v_u_82.winSince and 0 or v167 - v_u_82.winSince,
						["loot"] = v_u_82.loot,
						["section"] = v_u_74:GetAttribute("InvUISection")
					})
					if not v169 then
						local function v170()
							-- upvalues: (ref) v_u_73
							return v_u_73.controllers.Input.device()
						end
						local v171, v172 = pcall(v170)
						local v173 = {
							["seen"] = v_u_107.seen,
							["calm"] = v168 == nil and true or v168 == "Alive"
						}
						if not v171 then
							v172 = nil
						end
						v173.device = v172
						v173.secs = not v_u_78 and 0 or v167 - v_u_78
						v173.turned = v_u_6.turned
						v173.invOpen = v_u_82.invOpen
						v173.mapOpen = v_u_74:GetAttribute("MapOpen") == true
						v169 = v_u_4.sprintDue(v173) and "sprint" or (v_u_4.twistDue(v173) and "twist" or v169)
					end
					if v169 then
						v_u_165(v169)
					end
					return
				end
			end
		elseif not v_u_107.loaded then
			if v_u_107.fetching then
				return
			end
			v_u_107.fetching = true
			task.spawn(function()
				-- upvalues: (ref) v_u_107, (ref) v_u_6
				local v_u_174 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
				if v_u_174 then
					v_u_174 = v_u_174:FindFirstChild("menu.get")
				end
				if v_u_174 and v_u_174:IsA("RemoteFunction") then
					local v175, v176 = pcall(function()
						-- upvalues: (copy) v_u_174
						return v_u_174:InvokeServer({
							["what"] = "settings"
						})
					end)
					if v175 and (type(v176) == "table" and v176.error == nil) then
						local v177 = v176.tipsSeen
						if type(v177) == "string" then
							for v178 in string.gmatch(v176.tipsSeen, "[^,]+") do
								v_u_107.seen[v178] = true
							end
						end
						if v176.mapHintSeen == true then
							v_u_6.mapKnown = true
						end
						v_u_107.loaded = true
					end
				end
				v_u_107.fetching = false
			end)
		end
	end
	local function v_u_243(p180, p181) -- name: payload
		-- upvalues: (copy) v_u_74, (copy) p_u_71, (copy) v_u_73, (ref) v_u_1, (copy) v_u_106, (ref) v_u_4
		local v182
		if v_u_74:GetAttribute("TutorialStep") == nil and v_u_74:GetAttribute("Tutorial") ~= true then
			local v183 = v_u_74
			local v184 = tonumber(v183:GetAttribute("ExtractCoach")) or 0
			v182 = v184 ~= 1 and v184 ~= 2 and 0 or v184
		else
			v182 = 0
		end
		local v185 = p_u_71.raid
		local v_u_186 = not (v185 and v185.Parent) and v_u_73.runtime
		if v_u_186 then
			v_u_186 = v_u_186:FindFirstChild("Raid")
		end
		local v187 = 5
		local v188
		if v_u_186 then
			v188 = tonumber(v_u_186:GetAttribute("EndsAt"))
		else
			v188 = v_u_186
		end
		if v188 then
			local v189 = (v188 - v_u_1.now()) / 60 + 0.5
			local v190 = math.floor(v189)
			v187 = math.max(1, v190)
		end
		local v191 = v_u_106()[1]
		if type(p181) == "table" and p181.part then
			v191 = p181.part
		elseif v191 then
			v191 = v191.part
		end
		local v192 = v_u_4.cards
		local v193 = v182 == 0 and 1 or v182
		local v194 = {}
		local v195 = v_u_73
		local v196 = v195 and v195.controllers
		if v196 then
			v196 = v195.controllers.Input
		end
		local v197
		if v196 then
			local v198 = v196.hint
			if type(v198) == "function" then
				local v199 = v196.hint
				local v200, v201 = pcall(v199, "map")
				v197 = (not v200 or (type(v201) ~= "string" or v201 == "")) and "Map" or v201
			else
				v197 = "Map"
			end
		else
			v197 = "Map"
		end
		v194.map = v197
		local v202 = v_u_73
		local v203 = v202 and v202.controllers
		if v203 then
			v203 = v202.controllers.Input
		end
		local v204
		if v203 then
			local v205 = v203.hint
			if type(v205) == "function" then
				local v206 = v203.hint
				local v207, v208 = pcall(v206, "extracts")
				v204 = (not v207 or (type(v208) ~= "string" or v208 == "")) and "Exits" or v208
			else
				v204 = "Exits"
			end
		else
			v204 = "Exits"
		end
		v194.exits = v204
		local v209
		if v191 then
			v209 = v191:GetAttribute("Name") or nil
		else
			v209 = nil
		end
		v194.name = v209
		local v210
		if v191 then
			v210 = v191:GetAttribute("Condition") or nil
		else
			v210 = nil
		end
		v194.condition = v210
		v194.minutes = v187
		local v211 = v_u_73.controllers
		if v211 then
			v211 = v_u_73.controllers.SquadMarkers
		end
		local v212
		if v211 then
			local v213 = v211.exitCompass
			if type(v213) == "function" then
				local v214 = v211.exitCompass
				local v215
				v212, v215 = pcall(v214)
				if v212 then
					v212 = v215 == true
				end
			else
				v212 = false
			end
		else
			v212 = false
		end
		v194.compass = v212
		local v216 = v_u_73
		local v217 = v216 and v216.controllers
		if v217 then
			v217 = v216.controllers.Input
		end
		local v218
		if v217 then
			local v219 = v217.hint
			if type(v219) == "function" then
				local v220 = v217.hint
				local v221, v222 = pcall(v220, "melee")
				v218 = (not v221 or (type(v222) ~= "string" or v222 == "")) and "Melee" or v222
			else
				v218 = "Melee"
			end
		else
			v218 = "Melee"
		end
		v194.melee = v218
		local v223 = v_u_73
		local v224 = v223 and v223.controllers
		if v224 then
			v224 = v223.controllers.Input
		end
		local v225
		if v224 then
			local v226 = v224.hint
			if type(v226) == "function" then
				local v227 = v224.hint
				local v228, v229 = pcall(v227, "throw")
				v225 = (not v228 or (type(v229) ~= "string" or v229 == "")) and "a quick slot" or v229
			else
				v225 = "a quick slot"
			end
		else
			v225 = "a quick slot"
		end
		v194.throw = v225
		local v230
		if v_u_186 then
			v230 = v_u_186:GetAttribute("MapId") or nil
		else
			v230 = nil
		end
		v194.mapId = v230
		local function v233()
			-- upvalues: (ref) v_u_73, (copy) v_u_186
			local v231 = v_u_73.shared.Maps.get
			local v232 = v_u_186
			if v232 then
				v232 = v_u_186:GetAttribute("MapId")
			end
			return v231(v232)
		end
		local v234, v235 = pcall(v233)
		local v236
		if v234 and v235 then
			local v237 = v235.noun
			if type(v237) == "string" then
				v236 = v235.noun
			else
				v236 = nil
			end
		else
			v236 = nil
		end
		v194.noun = v236
		local v238
		if v191 then
			v238 = v191:GetAttribute("State") or nil
		else
			v238 = nil
		end
		v194.state = v238
		local v239
		if v191 then
			v239 = v191:GetAttribute("Kind") or nil
		else
			v239 = nil
		end
		v194.kind = v239
		local v240 = v192(v193, v194)[p180]
		if not v240 then
			return nil
		end
		local v241 = {
			["event"] = nil,
			["text"] = nil,
			["sub"] = nil,
			["phoneText"] = nil,
			["phoneSub"] = nil,
			["kind"] = nil,
			["icon"] = nil,
			["category"] = "First raids",
			["dur"] = 11,
			["sting"] = "land",
			["pos"] = nil,
			["event"] = "coach_" .. p180,
			["text"] = v240.text,
			["sub"] = v240.sub,
			["phoneText"] = v240.phoneText,
			["phoneSub"] = v240.phoneSub,
			["kind"] = p180 == "siren" and "warn" or "info",
			["icon"] = p180 == "fight" and "info" or "extract"
		}
		local v242
		if p180 == "zone" or (p180 == "stopped" or (p180 == "fight" or not v191)) then
			v242 = nil
		else
			v242 = v191.Position
		end
		v241.pos = v242
		return v241
	end
	local function v_u_252() -- name: publish
		-- upvalues: (copy) v_u_90, (copy) v_u_74
		local v244 = {}
		for v245 in v_u_90() do
			table.insert(v244, v245)
		end
		table.sort(v244)
		local v246 = v_u_74
		local v247 = "ExtractCoachState"
		local v248 = "lvl=%d shown=%s"
		local v249
		if v_u_74:GetAttribute("TutorialStep") == nil and v_u_74:GetAttribute("Tutorial") ~= true then
			local v250 = v_u_74
			local v251 = tonumber(v250:GetAttribute("ExtractCoach")) or 0
			v249 = v251 ~= 1 and v251 ~= 2 and 0 or v251
		else
			v249 = 0
		end
		v246:SetAttribute(v247, v248:format(v249, table.concat(v244, ",")))
	end
	local function v_u_260(p253, p254) -- name: show
		-- upvalues: (copy) v_u_243, (copy) v_u_90, (ref) v_u_81, (copy) p_u_72, (copy) v_u_252, (copy) p_u_71
		local v255 = v_u_243(p253, p254)
		if not v255 then
			return false
		end
		v_u_90()[p253] = true
		v_u_81 = os.clock()
		local v256 = p_u_72
		pcall(v256, v255)
		v_u_252()
		if p253 == "arrive" then
			local v257 = p_u_71.mods
			if v257 then
				v257 = p_u_71.mods.HUDClock
			end
			if v257 then
				local v258 = v257.reveal
				if type(v258) == "function" then
					local v259 = v257.reveal
					pcall(v259, 12)
				end
			end
		end
		return true
	end
	if v_u_74:GetAttribute("MapOpen") == true then
		v_u_6.mapKnown = true
	end
	if (tonumber(v_u_74:GetAttribute("CamStep")) or 0) ~= 0 then
		v_u_6.turned = true
	end
	if not v_u_6.turnHooked then
		local v261 = v_u_73.on
		if type(v261) == "function" then
			v_u_6.turnHooked = true
			local v262 = v_u_73.on
			local function v263()
				-- upvalues: (ref) v_u_6
				v_u_6.turned = true
			end
			pcall(v262, "camera.rotate", v263)
		end
	end
	local v264 = v_u_74:GetAttributeChangedSignal("MapOpen")
	local function v265()
		-- upvalues: (copy) v_u_74, (ref) v_u_6
		if v_u_74:GetAttribute("MapOpen") == true then
			v_u_6.mapKnown = true
		end
	end
	table.insert(v_u_83, v264:Connect(v265))
	local function v278()
		-- upvalues: (copy) v_u_83, (copy) v_u_73, (ref) v_u_76, (ref) v_u_80, (copy) v_u_74, (copy) v_u_90, (copy) v_u_243, (ref) v_u_81, (copy) p_u_72, (copy) v_u_252
		local v266 = v_u_83
		local v267 = v_u_73.net.listen
		local function v277(p268)
			-- upvalues: (ref) v_u_76, (ref) v_u_80, (ref) v_u_74, (ref) v_u_90, (ref) v_u_243, (ref) v_u_81, (ref) p_u_72, (ref) v_u_252
			if type(p268) == "table" and v_u_76 then
				local v269 = v_u_80
				local v270 = p268.state
				v_u_80 = tostring(v270)
				if p268.state == "none" and (v269 == "progress" or v269 == "interrupted") then
					local v271
					if v_u_74:GetAttribute("TutorialStep") == nil and v_u_74:GetAttribute("Tutorial") ~= true then
						local v272 = v_u_74
						local v273 = tonumber(v272:GetAttribute("ExtractCoach")) or 0
						v271 = v273 ~= 1 and v273 ~= 2 and 0 or v273
					else
						v271 = 0
					end
					if v271 == 1 then
						local v274 = v_u_74:GetAttribute("RaidStatus")
						if ((v274 == nil or v274 == "Alive") and true or v274 == "Downed") and not v_u_90().stopped then
							local v275 = v_u_243("stopped", nil)
							if not v275 then
								return
							end
							v_u_90().stopped = true
							v_u_81 = os.clock()
							local v276 = p_u_72
							pcall(v276, v275)
							v_u_252()
						end
					end
				end
			end
		end
		table.insert(v266, v267("raid.extractProgress", v277))
	end
	pcall(v278)
	function v_u_75.update(p279) -- name: update
		-- upvalues: (ref) v_u_76, (ref) v_u_77, (copy) v_u_74, (ref) v_u_78, (copy) v_u_179, (copy) v_u_90, (copy) v_u_260, (ref) v_u_79, (copy) p_u_71, (copy) v_u_73, (ref) v_u_1, (ref) v_u_80, (copy) v_u_243, (ref) v_u_81, (copy) p_u_72, (copy) v_u_252, (copy) v_u_106
		if v_u_76 then
			v_u_77 = v_u_77 + p279
			if v_u_77 < 0.5 then
				return
			else
				v_u_77 = 0
				local v280
				if v_u_74:GetAttribute("TutorialStep") == nil and v_u_74:GetAttribute("Tutorial") ~= true then
					local v281 = v_u_74
					local v282 = tonumber(v281:GetAttribute("ExtractCoach")) or 0
					v280 = v282 ~= 1 and v282 ~= 2 and 0 or v282
				else
					v280 = 0
				end
				if v280 == 0 then
					return
				elseif v_u_74:GetAttribute("LoadingVisible") == true then
					v_u_78 = nil
					return
				else
					v_u_78 = v_u_78 or os.clock()
					local v283 = v_u_74:GetAttribute("RaidStatus")
					if (v283 == nil or v283 == "Alive") and true or v283 == "Downed" then
						v_u_179()
						local v284 = v_u_90()
						if v284.arrive then
							v_u_79 = v_u_79 or os.clock()
							local v285 = p_u_71.raid
							local v286 = not (v285 and v285.Parent) and v_u_73.runtime
							if v286 then
								v286 = v286:FindFirstChild("Raid")
							end
							local v287 = v_u_1.now()
							local v288
							if v286 then
								v288 = tonumber(v286:GetAttribute("EndsAt"))
							else
								v288 = v286
							end
							local v289
							if v286 then
								v289 = tonumber(v286:GetAttribute("StartedAt"))
							else
								v289 = v286
							end
							if v286 then
								v286 = tonumber(v286:GetAttribute("SirenAt"))
							end
							local v290 = v_u_74.Character
							if (v290 == nil or v290:GetAttribute("Action") ~= "Extract") and v_u_80 ~= "progress" and v_u_80 ~= "interrupted" then
								if v286 and (not v284.siren and (v286 + 6 <= v287 and (not v288 or v287 < v288))) then
									local v291 = v_u_243("siren", nil)
									if v291 then
										v_u_90().siren = true
										v_u_81 = os.clock()
										local v292 = p_u_72
										pcall(v292, v291)
										v_u_252()
									end
								end
								if v280 == 1 and (not v284.half and (v288 and (v289 and (v289 < v288 and ((v289 + v288) / 2 <= v287 and (not v286 or v287 < v286)))))) then
									local v293 = v_u_243("half", nil)
									if v293 then
										v_u_90().half = true
										v_u_81 = os.clock()
										local v294 = p_u_72
										pcall(v294, v293)
										v_u_252()
									end
								end
								if v280 == 1 and not v284.zone then
									for _, v295 in v_u_106() do
										if not v295.near then
											continue
										end
										local v296 = v_u_243("zone", v295)
										if v296 then
											v_u_90().zone = true
											v_u_81 = os.clock()
											local v297 = p_u_72
											pcall(v297, v296)
											v_u_252()
											v298 = true
										else
											v298 = false
										end
									end
									local v298 = false
									if v298 then
										return
									end
								end
								if v280 == 1 and (not v284.fight and (v_u_79 and os.clock() - v_u_79 >= 40)) then
									local v299 = v_u_243("fight", nil)
									if not v299 then
										return
									end
									v_u_90().fight = true
									v_u_81 = os.clock()
									local v300 = p_u_72
									pcall(v300, v299)
									v_u_252()
								end
							end
						elseif os.clock() - v_u_78 >= 7 then
							v_u_260("arrive")
							v_u_79 = os.clock()
							return
						end
					end
				end
			end
		else
			return
		end
	end
	function v_u_75.force(p301) -- name: force
		-- upvalues: (copy) v_u_165, (copy) v_u_106, (copy) v_u_243, (copy) v_u_90, (ref) v_u_81, (copy) p_u_72, (copy) v_u_252, (copy) v_u_260
		local v302 = string.match(p301, "^tip_(%w+)$")
		if v302 then
			return v_u_165(v302, true)
		end
		if p301 ~= "zone" then
			return v_u_260(p301)
		end
		local v303 = v_u_243("zone", v_u_106()[1])
		if not v303 then
			return false
		end
		v_u_90().zone = true
		v_u_81 = os.clock()
		local v304 = p_u_72
		pcall(v304, v303)
		v_u_252()
		return true
	end
	function v_u_75.state() -- name: state
		-- upvalues: (copy) v_u_90, (copy) v_u_106, (copy) v_u_107, (copy) v_u_74, (ref) v_u_78, (ref) v_u_6, (copy) v_u_82, (copy) v_u_138
		local v305 = {}
		for v306 in v_u_90() do
			table.insert(v305, v306)
		end
		table.sort(v305)
		local v307 = v_u_106()[1]
		local v308 = {}
		for v309 in v_u_107.seen do
			table.insert(v308, v309)
		end
		table.sort(v308)
		local v310 = os.clock()
		local v311 = "lvl=%d shown=%s loaded=%s nearest=%s"
		local v312
		if v_u_74:GetAttribute("TutorialStep") == nil and v_u_74:GetAttribute("Tutorial") ~= true then
			local v313 = v_u_74
			local v314 = tonumber(v313:GetAttribute("ExtractCoach")) or 0
			v312 = v314 ~= 1 and v314 ~= 2 and 0 or v314
		else
			v312 = 0
		end
		local v315 = table.concat(v305, ",")
		local v316 = v_u_78 ~= nil
		local v317 = tostring(v316)
		local v318
		if v307 then
			local v319 = v307.part
			v318 = ("%s %.0fm%s"):format(tostring(v319:GetAttribute("Name")), v307.dist * 0.28, v307.near and " near" or "")
		else
			v318 = "-"
		end
		local v320 = v311:format(v312, v315, v317, v318)
		local v321 = #v308 <= 0 and "-" or table.concat(v308, ",")
		local v322 = v_u_107.loaded
		local v323 = tostring(v322)
		local v324 = v_u_6.mapKnown
		local v325 = tostring(v324)
		local v326 = v_u_82.invOpen
		local v327 = tostring(v326)
		local v328 = not v_u_82.dragSince and 0 or v310 - v_u_82.dragSince
		local v329 = v_u_82.windows
		local v330 = v_u_82.loot
		local v331 = not v_u_78 and 0 or v310 - v_u_78
		local v332 = v_u_138()
		return v320 .. (" tips=%s tipsLoaded=%s mapKnown=%s inv=%s drag=%.1f windows=%d loot=%d secs=%.0f busy=%s"):format(v321, v323, v325, v327, v328, v329, v330, v331, (tostring(v332)))
	end
	function v_u_75.destroy() -- name: destroy
		-- upvalues: (ref) v_u_76, (copy) v_u_83, (ref) v_u_4, (copy) v_u_75, (copy) v_u_74
		v_u_76 = false
		for _, v333 in v_u_83 do
			v333:Disconnect()
		end
		table.clear(v_u_83)
		if v_u_4.current == v_u_75 then
			v_u_4.current = nil
		end
		v_u_74:SetAttribute("ExtractCoachState", nil)
	end
	v_u_4.current = v_u_75
	v_u_252()
	return v_u_75
end
return v_u_4