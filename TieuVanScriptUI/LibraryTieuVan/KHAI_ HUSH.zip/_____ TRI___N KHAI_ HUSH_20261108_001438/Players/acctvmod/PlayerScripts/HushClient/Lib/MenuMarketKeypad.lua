-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketKeypad

local v_u_86 = {
	["MAX_PRICE"] = 99999999,
	["MAX_DIGITS"] = 8,
	["KEYS"] = {
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"000",
		"0",
		"back"
	},
	["LABEL"] = {
		["back"] = "DEL",
		["clear"] = "CLEAR",
		["less"] = "10% LESS",
		["more"] = "10% MORE",
		["cheapest"] = "CHEAPEST",
		["done"] = "DONE"
	},
	["LOW"] = 0.25,
	["HIGH"] = 4,
	["TRADER_MUL"] = 1.25,
	["press"] = function(p1, p2, p3) -- name: press
		-- upvalues: (copy) v_u_86
		local v4 = p1 or ""
		if p2 == "clear" then
			return ""
		elseif p2 == "back" then
			return string.sub(v4, 1, -2)
		elseif p2 == "000" or string.match(p2, "^%d$") then
			local v5 = string.gsub(v4 .. p2, "^0+", "")
			if #v5 > v_u_86.MAX_DIGITS then
				return v4
			elseif (tonumber(v5) or 0) > (p3 or v_u_86.MAX_PRICE) then
				return v4
			else
				return v5
			end
		else
			return v4
		end
	end,
	["value"] = function(p6) -- name: value
		return tonumber(p6 or "") or 0
	end,
	["fromNumber"] = function(p7) -- name: fromNumber
		-- upvalues: (copy) v_u_86
		if type(p7) ~= "number" or (p7 ~= p7 or p7 < 1) then
			return ""
		end
		local v8 = string.format
		local v9 = p7 + 0.5
		local v10 = math.floor(v9)
		local v11 = v_u_86.MAX_PRICE
		return v8("%d", (math.min(v10, v11)))
	end,
	["group"] = function(p12) -- name: group
		-- upvalues: (copy) v_u_86
		local v13
		if type(p12) == "number" then
			v13 = v_u_86.fromNumber(p12)
		else
			v13 = tostring(p12 or "")
		end
		local v14 = string.gsub(v13, "[^%d]", "")
		local v15 = string.gsub(v14, "^0+", "")
		local v16 = string.reverse((string.gsub(string.reverse(v15), "(%d%d%d)", "%1,")))
		if string.sub(v16, 1, 1) == "," then
			v16 = string.sub(v16, 2)
		end
		return v16
	end,
	["money"] = function(p17) -- name: money
		-- upvalues: (copy) v_u_86
		local v18 = v_u_86.group
		local v19 = (p17 or 0) + 0.5
		local v20 = math.floor(v19)
		local v21 = v18((math.max(0, v20)))
		return "$" .. (v21 == "" and "0" or v21)
	end,
	["less"] = function(p22, p23) -- name: less
		-- upvalues: (copy) v_u_86
		local v24 = math.floor(p23 or 1)
		local v25 = math.max(1, v24)
		local v26 = math.floor(p22)
		local v27 = v26 * 0.9 + 1e-6
		local v28 = math.floor(v27)
		if v26 <= v28 then
			v28 = v26 - 1
		end
		local v29 = v_u_86.MAX_PRICE
		local v30 = math.max(1, v25)
		local v31 = math.min(v29, v28)
		return math.max(v30, v31)
	end,
	["more"] = function(p32, p33, p34) -- name: more
		-- upvalues: (copy) v_u_86
		local v35 = math.floor(p33 or 1)
		local v36 = math.max(1, v35)
		local v37 = p34 or v_u_86.MAX_PRICE
		local v38 = math.floor(p32)
		local v39 = v38 * 1.1 - 1e-6
		local v40 = math.ceil(v39)
		if v40 <= v38 then
			v40 = v38 + 1
		end
		local v41 = math.max(1, v36)
		local v42 = math.min(v37, v40)
		return math.max(v41, v42)
	end,
	["cheapest"] = function(p43, p44) -- name: cheapest
		-- upvalues: (copy) v_u_86
		if type(p43) ~= "number" or (p43 ~= p43 or p43 <= 0) then
			return nil
		end
		local v45 = math.floor(p44 or 1)
		local v46 = math.max(1, v45)
		local v47 = p43 * v46 + 1e-6
		local v48 = math.floor(v47)
		local v49 = v_u_86.MAX_PRICE
		local v50 = math.max(1, v46)
		local v51 = math.min(v49, v48)
		return math.max(v50, v51)
	end,
	["reference"] = function(p52) -- name: reference
		if type(p52) == "table" then
			local v53 = p52.avg7
			if type(v53) == "number" and p52.avg7 > 0 then
				return p52.avg7, "avg7"
			else
				local v54 = p52.min
				if type(v54) == "number" and p52.min > 0 then
					return p52.min, "min"
				else
					local v55 = p52.pay
					if type(v55) == "number" and p52.pay > 0 then
						return p52.pay, "pay"
					else
						return nil, nil
					end
				end
			end
		else
			return nil, nil
		end
	end,
	["suggest"] = function(p56, p57) -- name: suggest
		-- upvalues: (copy) v_u_86
		local v58 = math.floor(p57 or 1)
		local v59 = math.max(1, v58)
		local v60, v61 = v_u_86.reference(p56)
		if v60 == nil then
			return nil, nil
		end
		local v62
		if v61 == "pay" then
			v62 = v60 * v_u_86.TRADER_MUL * v59
		elseif v61 == "min" then
			local v63 = v60 * v59 + 1e-6
			v62 = math.floor(v63)
		else
			v62 = v60 * v59
		end
		local v64 = v62 + 0.5
		local v65 = math.floor(v64)
		local v66 = v_u_86.MAX_PRICE
		local v67 = math.max(1, v59)
		local v68 = math.min(v66, v65)
		return math.max(v67, v68), v61
	end,
	["warn"] = function(p69, p70, p71) -- name: warn
		-- upvalues: (copy) v_u_86
		if type(p69) ~= "number" or (p69 < 1 or (type(p71) ~= "number" or p71 <= 0)) then
			return nil
		end
		local v72 = p69 / math.max(1, p70 or 1)
		return v72 < p71 * v_u_86.LOW and "low" or (p71 * v_u_86.HIGH < v72 and "high" or nil)
	end,
	["fee"] = function(p73, p74) -- name: fee
		local v75 = p73 * math.clamp(p74 or 0, 0, 100) / 100
		local v76 = math.floor(v75)
		return v76, p73 - v76
	end,
	["unitText"] = function(p77, p78) -- name: unitText
		-- upvalues: (copy) v_u_86
		local v79 = math.floor(p78 or 1)
		local v80 = math.max(1, v79)
		if v80 <= 1 or p77 < 1 then
			return nil
		end
		local v81 = p77 / v80
		if v81 < 100 then
			local v82 = v81 + 0.5
			local v83 = v81 - math.floor(v82)
			if math.abs(v83) >= 1e-9 then
				return string.format("%.2f", v81)
			end
		end
		local v84 = v_u_86.group
		local v85 = v81 + 0.5
		return v84((math.floor(v85)))
	end
}
local function v_u_132(p_u_87, p_u_88, p89, p90, p91, p_u_92, p93) -- name: keyButton
	local v_u_94 = p_u_88.color
	local v_u_95 = p_u_87.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Selectable"] = true,
		["Name"] = "Key_" .. p90,
		["BackgroundColor3"] = v_u_94.raised,
		["LayoutOrder"] = p91
	}, p89)
	v_u_95.SelectionImageObject = p_u_87.selectionImage()
	local v_u_96 = p_u_87.stroke(v_u_95, v_u_94.line)
	local v_u_97 = p_u_87.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = nil,
		["textSize"] = nil,
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["track"] = false,
		["fit"] = true,
		["parent"] = v_u_95,
		["text"] = p90,
		["style"] = p93 and "caps" or "monoL",
		["textSize"] = p93 and 13 or 22,
		["color"] = v_u_94.text,
		["size"] = UDim2.fromScale(1, 1)
	})
	local v_u_98 = true
	local v_u_99 = false
	v_u_95.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_99, (copy) v_u_95, (ref) v_u_98, (copy) v_u_94, (copy) v_u_96, (copy) v_u_97
		v_u_99 = true
		local v100 = v_u_95
		local v101
		if v_u_99 and v_u_98 then
			v101 = v_u_94.raised2
		else
			v101 = v_u_94.raised
		end
		v100.BackgroundColor3 = v101
		local v102 = v_u_96
		local v103
		if v_u_99 and v_u_98 then
			v103 = v_u_94.lineStrong
		else
			v103 = v_u_94.line
		end
		v102.Color = v103
		local v104 = v_u_97
		local v105
		if v_u_98 then
			v105 = v_u_94.text
		else
			v105 = v_u_94.muted
		end
		v104.TextColor3 = v105
	end)
	v_u_95.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_99, (copy) v_u_95, (ref) v_u_98, (copy) v_u_94, (copy) v_u_96, (copy) v_u_97
		v_u_99 = false
		local v106 = v_u_95
		local v107
		if v_u_99 and v_u_98 then
			v107 = v_u_94.raised2
		else
			v107 = v_u_94.raised
		end
		v106.BackgroundColor3 = v107
		local v108 = v_u_96
		local v109
		if v_u_99 and v_u_98 then
			v109 = v_u_94.lineStrong
		else
			v109 = v_u_94.line
		end
		v108.Color = v109
		local v110 = v_u_97
		local v111
		if v_u_98 then
			v111 = v_u_94.text
		else
			v111 = v_u_94.muted
		end
		v110.TextColor3 = v111
	end)
	v_u_95.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_99, (copy) v_u_95, (ref) v_u_98, (copy) v_u_94, (copy) v_u_96, (copy) v_u_97
		v_u_99 = true
		local v112 = v_u_95
		local v113
		if v_u_99 and v_u_98 then
			v113 = v_u_94.raised2
		else
			v113 = v_u_94.raised
		end
		v112.BackgroundColor3 = v113
		local v114 = v_u_96
		local v115
		if v_u_99 and v_u_98 then
			v115 = v_u_94.lineStrong
		else
			v115 = v_u_94.line
		end
		v114.Color = v115
		local v116 = v_u_97
		local v117
		if v_u_98 then
			v117 = v_u_94.text
		else
			v117 = v_u_94.muted
		end
		v116.TextColor3 = v117
	end)
	v_u_95.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_99, (copy) v_u_95, (ref) v_u_98, (copy) v_u_94, (copy) v_u_96, (copy) v_u_97
		v_u_99 = false
		local v118 = v_u_95
		local v119
		if v_u_99 and v_u_98 then
			v119 = v_u_94.raised2
		else
			v119 = v_u_94.raised
		end
		v118.BackgroundColor3 = v119
		local v120 = v_u_96
		local v121
		if v_u_99 and v_u_98 then
			v121 = v_u_94.lineStrong
		else
			v121 = v_u_94.line
		end
		v120.Color = v121
		local v122 = v_u_97
		local v123
		if v_u_98 then
			v123 = v_u_94.text
		else
			v123 = v_u_94.muted
		end
		v122.TextColor3 = v123
	end)
	v_u_95.Activated:Connect(function()
		-- upvalues: (ref) v_u_98, (copy) p_u_87, (copy) p_u_88, (copy) p_u_92
		if v_u_98 then
			p_u_87.sound(p_u_88.sounds.click)
			p_u_92()
		else
			p_u_87.sound(p_u_88.sounds.error)
		end
	end)
	return {
		["btn"] = v_u_95,
		["label"] = v_u_97,
		["setText"] = function(p124) -- name: setText
			-- upvalues: (copy) v_u_97
			v_u_97.Text = p124
		end,
		["setEnabled"] = function(p125) -- name: setEnabled
			-- upvalues: (ref) v_u_98, (copy) v_u_95, (ref) v_u_99, (copy) v_u_94, (copy) v_u_96, (copy) v_u_97
			v_u_98 = p125
			v_u_95:SetAttribute("Disabled", not p125)
			local v126 = v_u_95
			local v127
			if v_u_99 and v_u_98 then
				v127 = v_u_94.raised2
			else
				v127 = v_u_94.raised
			end
			v126.BackgroundColor3 = v127
			local v128 = v_u_96
			local v129
			if v_u_99 and v_u_98 then
				v129 = v_u_94.lineStrong
			else
				v129 = v_u_94.line
			end
			v128.Color = v129
			local v130 = v_u_97
			local v131
			if v_u_98 then
				v131 = v_u_94.text
			else
				v131 = v_u_94.muted
			end
			v130.TextColor3 = v131
		end
	}
end
function v_u_86.mount(p133, p_u_134) -- name: mount
	-- upvalues: (copy) v_u_86, (copy) v_u_132
	local v_u_135 = p_u_134.ui
	local v_u_136 = p_u_134.theme
	local v_u_137 = p_u_134.max or v_u_86.MAX_PRICE
	local v138 = p_u_134.n or 1
	local v_u_139 = math.max(1, v138)
	local v140 = p_u_134.price or 0
	local v141 = math.floor(v140)
	local v_u_142 = math.max(0, v141)
	local v_u_143 = p_u_134.cheapestUnit
	local v144 = p_u_134.keyH or v_u_136.touch(44)
	local v145 = p_u_134.keys ~= false
	local v146 = p_u_134.quick ~= false
	local v147 = p_u_134.keyCols or 6
	local v148 = #v_u_86.KEYS / v147
	local v149 = math.ceil(v148)
	local v150 = v149 * v144 + (v149 - 1) * 6
	local v151 = (not v145 and 0 or v150) + (v145 and v146 and 6 or 0) + (not v146 and 0 or v144)
	local v152 = v_u_135.new("Frame", {
		["Name"] = "Keypad",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v151)
	}, p133)
	local v153 = {
		["frame"] = v152
	}
	local v_u_154 = {}
	local v_u_155 = {}
	local v_u_156 = true
	local function v_u_163() -- name: refreshQuick
		-- upvalues: (copy) v_u_155, (ref) v_u_156, (ref) v_u_86, (ref) v_u_143, (ref) v_u_139, (ref) v_u_142
		if v_u_155.cheapest then
			local v157 = v_u_155.cheapest.setEnabled
			local v158 = v_u_156
			if v158 then
				v158 = v_u_86.cheapest(v_u_143, v_u_139) ~= nil
			end
			v157(v158)
		end
		if v_u_155.less then
			local v159 = v_u_155.less.setEnabled
			local v160 = v_u_156
			if v160 then
				v160 = v_u_142 > 0
			end
			v159(v160)
		end
		if v_u_155.more then
			v_u_155.more.setEnabled(v_u_156)
		end
		if v_u_155.clear then
			local v161 = v_u_155.clear.setEnabled
			local v162 = v_u_156
			if v162 then
				v162 = v_u_142 > 0
			end
			v161(v162)
		end
	end
	local v_u_164
	if v145 then
		local v165 = v_u_135.new("Frame", {
			["Name"] = "Keys",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v150)
		}, v152)
		v_u_135.new("UIGridLayout", {
			["CellSize"] = UDim2.new(1 / v147, -((v147 - 1) * 6) / v147 - 1, 0, v144),
			["CellPadding"] = UDim2.fromOffset(6, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["FillDirection"] = Enum.FillDirection.Horizontal
		}, v165)
		v_u_164 = v_u_156
		for v166, v_u_167 in v_u_86.KEYS do
			local v168 = v_u_132
			local v169
			if v_u_167 == "back" then
				v169 = v_u_86.LABEL.back
			else
				v169 = v_u_167
			end
			local v174 = v168(v_u_135, v_u_136, v165, v169, v166, function()
				-- upvalues: (ref) v_u_86, (ref) v_u_142, (copy) v_u_167, (copy) v_u_137, (copy) v_u_135, (copy) v_u_136, (copy) p_u_134, (copy) v_u_163
				local v170 = v_u_86.fromNumber(v_u_142)
				local v171 = v_u_86.press(v170, v_u_167, v_u_137)
				if v171 == v170 and (v_u_167 ~= "back" and v_u_167 ~= "clear") then
					v_u_135.sound(v_u_136.sounds.error)
				else
					local v172 = v_u_86.value(v171)
					local v173 = math.floor(v172)
					v_u_142 = math.max(0, v173)
					if p_u_134.onChange then
						p_u_134.onChange(v_u_142)
					end
					v_u_163()
				end
			end, v_u_167 == "back")
			table.insert(v_u_154, v174)
		end
	else
		v_u_164 = v_u_156
	end
	if v146 then
		local v175 = v_u_135.new("Frame", {
			["Name"] = "Quick",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, not v145 and 0 or v150 + 6),
			["Size"] = UDim2.new(1, 0, 0, v144)
		}, v152)
		v_u_135.new("UIGridLayout", {
			["CellSize"] = UDim2.new(0.25, -5.5, 0, v144),
			["CellPadding"] = UDim2.fromOffset(6, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["FillDirection"] = Enum.FillDirection.Horizontal
		}, v175)
		v_u_155.clear = v_u_132(v_u_135, v_u_136, v175, v_u_86.LABEL.clear, 1, function()
			-- upvalues: (ref) v_u_142, (copy) p_u_134, (copy) v_u_163
			v_u_142 = 0
			if p_u_134.onChange then
				p_u_134.onChange(v_u_142)
			end
			v_u_163()
		end, true)
		local function v180()
			-- upvalues: (ref) v_u_86, (ref) v_u_142, (ref) v_u_139, (copy) p_u_134, (copy) v_u_163
			local v176 = v_u_142
			local v177 = v_u_139
			local v178 = v_u_86.less(math.max(v176, v177), v_u_139)
			local v179 = math.floor(v178)
			v_u_142 = math.max(0, v179)
			if p_u_134.onChange then
				p_u_134.onChange(v_u_142)
			end
			v_u_163()
		end
		v_u_155.less = v_u_132(v_u_135, v_u_136, v175, v_u_86.LABEL.less, 2, v180, true)
		local function v183()
			-- upvalues: (ref) v_u_86, (ref) v_u_143, (ref) v_u_139, (ref) v_u_142, (copy) p_u_134, (copy) v_u_163
			local v181 = v_u_86.cheapest(v_u_143, v_u_139)
			if v181 then
				local v182 = math.floor(v181)
				v_u_142 = math.max(0, v182)
				if p_u_134.onChange then
					p_u_134.onChange(v_u_142)
				end
				v_u_163()
			end
		end
		v_u_155.cheapest = v_u_132(v_u_135, v_u_136, v175, v_u_86.LABEL.cheapest, 3, v183, true)
		local function v187()
			-- upvalues: (ref) v_u_86, (ref) v_u_142, (ref) v_u_139, (copy) v_u_137, (copy) p_u_134, (copy) v_u_163
			local v184 = v_u_142
			local v185 = v_u_86.more(math.max(v184, 0), v_u_139, v_u_137)
			local v186 = math.floor(v185)
			v_u_142 = math.max(0, v186)
			if p_u_134.onChange then
				p_u_134.onChange(v_u_142)
			end
			v_u_163()
		end
		v_u_155.more = v_u_132(v_u_135, v_u_136, v175, v_u_86.LABEL.more, 4, v187, true)
	end
	function v153.set(p188) -- name: set
		-- upvalues: (ref) v_u_142, (copy) v_u_163
		local v189 = math.floor(p188)
		v_u_142 = math.max(0, v189)
		v_u_163()
	end
	function v153.get() -- name: get
		-- upvalues: (ref) v_u_142
		return v_u_142
	end
	function v153.setN(p190) -- name: setN
		-- upvalues: (ref) v_u_139, (copy) v_u_163
		local v191 = math.floor(p190)
		v_u_139 = math.max(1, v191)
		v_u_163()
	end
	function v153.setCheapest(p192) -- name: setCheapest
		-- upvalues: (ref) v_u_143, (copy) v_u_163
		v_u_143 = p192
		v_u_163()
	end
	function v153.setEnabled(p193) -- name: setEnabled
		-- upvalues: (ref) v_u_164, (copy) v_u_154, (copy) v_u_163
		v_u_164 = p193
		for _, v194 in v_u_154 do
			v194.setEnabled(p193)
		end
		v_u_163()
	end
	v153.keys = v_u_154
	v153.quick = v_u_155
	v153.height = v151
	v_u_163()
	return v153
end
return v_u_86