-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIXLayout

local v_u_1 = {
	["eqFold"] = false
}
local v_u_2 = nil
local v3, v_u_4 = pcall(function()
	return require((script.Parent:WaitForChild("InvUITouch", 3)))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v_u_5 = require((script.Parent:WaitForChild("InvUIGridPlan", 5)))
local v7, v8 = pcall(function()
	local v6 = script.Parent
	return { require((v6:WaitForChild("InvUIZoomLayout", 3))), require((v6:WaitForChild("InvUIZoomMath", 3))) }
end)
local v_u_9, v_u_10
if v7 and type(v8) == "table" then
	v_u_9 = v8[1]
	v_u_10 = v8[2]
else
	v_u_9 = nil
	v_u_10 = nil
end
function v_u_1.bind(p_u_11) -- name: bind
	-- upvalues: (ref) v_u_2, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (copy) v_u_1, (copy) v_u_5
	local v_u_12 = p_u_11.C
	local v_u_13 = p_u_11.Ext
	local v_u_14 = p_u_11.HushUI
	local v_u_15 = p_u_11.ItemIcons
	local v_u_16 = p_u_11.Theme
	local v_u_17 = p_u_11.Tile
	local v_u_18 = p_u_11.RIGHT_CHROME
	local v_u_19 = p_u_11.SLOT_DEFS
	local v_u_20 = p_u_11.player
	local v_u_21 = p_u_11.buildRail
	local v_u_22 = p_u_11.buildSectionTabs
	local v_u_23 = p_u_11.columnPanel
	local v_u_24 = p_u_11.designSizeOf
	local v_u_25 = p_u_11.device
	local v_u_26 = p_u_11.gearNeedOf
	local v_u_27 = p_u_11.label
	local v_u_28 = p_u_11.layoutKeyOf
	local v_u_29 = p_u_11.makeQuickBox
	local v_u_30 = p_u_11.makeScroller
	local v_u_31 = p_u_11.makeSlotBox
	local v_u_32 = p_u_11.mountAlive
	local v_u_33 = p_u_11.new
	local v_u_34 = p_u_11.renderMount
	local v_u_35 = p_u_11.rightKeyOf
	local v_u_36 = p_u_11.rightNeedOf
	local v_u_37 = p_u_11.sound
	local v_u_38 = p_u_11.stroke
	local v_u_39 = p_u_11.watchScrollers
	local function v_u_49(p40) -- name: ownGridsOf
		-- upvalues: (copy) p_u_11
		local v41 = {}
		local v42 = p40.work
		if type(v42) == "table" then
			local v43 = v42.containers
			if type(v43) == "table" then
				for _, v44 in p_u_11.gridIds(p40) do
					local v45 = v42.containers[v44]
					if type(v45) == "table" then
						local v46 = {}
						local v47 = v45.w
						v46.w = tonumber(v47) or 0
						local v48 = v45.h
						v46.h = tonumber(v48) or 0
						table.insert(v41, v46)
					elseif string.find(v44, "vest$") then
						table.insert(v41, {
							["ph"] = "vest"
						})
					else
						if not string.find(v44, "bag$") then
							continue
						end
						table.insert(v41, {
							["ph"] = "bag"
						})
					end
				end
			end
		end
		return v41
	end
	v_u_2 = function(p_u_50)
		-- upvalues: (copy) v_u_32, (copy) v_u_15, (copy) v_u_24, (copy) v_u_35, (copy) v_u_28, (copy) v_u_13, (ref) v_u_9, (ref) v_u_10, (copy) v_u_16, (ref) v_u_4, (copy) v_u_36, (copy) v_u_26, (ref) v_u_1, (copy) v_u_18, (copy) v_u_49, (ref) v_u_5, (copy) v_u_33, (copy) v_u_12, (copy) v_u_38, (copy) v_u_20, (copy) v_u_27, (copy) v_u_14, (copy) v_u_37, (copy) p_u_11, (copy) v_u_25, (copy) v_u_23, (copy) v_u_31, (copy) v_u_17, (copy) v_u_19, (copy) v_u_29, (copy) v_u_21, (ref) v_u_2, (copy) v_u_30, (copy) v_u_22, (copy) v_u_39, (copy) v_u_34
		if v_u_32(p_u_50) then
			for _, v51 in p_u_50.tiles do
				v51.destroy()
			end
			p_u_50.tiles = {}
			for _, v52 in p_u_50.slots do
				if not v52.tile then
					continue
				end
				v52.tile.destroy()
			end
			for _, v53 in p_u_50.quick do
				if not v53.icon then
					continue
				end
				v_u_15.release(v53.icon)
				v53.icon = nil
				v53.iconId = nil
			end
			if p_u_50.body then
				p_u_50.body:Destroy()
			end
			p_u_50.grids = {}
			p_u_50.slots = {}
			p_u_50.quick = {}
			p_u_50.sections = {}
			local v54 = v_u_24(p_u_50.root)
			local v55 = v54.X
			local v56 = v54.Y
			p_u_50.dw = v55
			p_u_50.dh = v56
			local v57 = v_u_35(p_u_50)
			p_u_50.builtRightKey = v_u_28(p_u_50)
			local v58 = v_u_13.Zoom
			local v59
			if v58 == nil or (v_u_9 == nil or v_u_10 == nil) then
				v59 = false
			else
				v59 = v58.on(p_u_50) == true
			end
			local v60 = v_u_16.isTouch()
			local v_u_61 = {
				["dw"] = v55,
				["dh"] = v56,
				["mode"] = p_u_50.mode,
				["standalone"] = p_u_50.standalone == true,
				["touch"] = v60,
				["scale"] = v_u_16.uiScale(),
				["t24"] = v_u_16.touch(24),
				["t36"] = v_u_16.touch(36),
				["t40"] = v_u_16.touch(40)
			}
			local v62
			if v_u_4 then
				v62 = v_u_4.minCell
			else
				v62 = nil
			end
			v_u_61.minCellFn = v62
			v_u_61.rk = v57
			v_u_61.rightNeed = v_u_36(p_u_50)
			v_u_61.gearNeed = v_u_26(p_u_50)
			v_u_61.eqFold = v_u_1.eqFold
			v_u_61.rightChrome = v_u_18
			local v63
			if v_u_10 then
				v63 = v_u_10.limits
			else
				v63 = nil
			end
			v_u_61.limits = v63
			local v64 = string.match
			v_u_61.widestOpen = tonumber(v64(v57, "^w(%d+)$")) or 0
			v_u_61.ownGrids = v_u_49(p_u_50)
			local v65
			if v59 and not p_u_50.standalone then
				local v66 = v_u_9.headNeed
				local v67 = v_u_16.touch(28)
				local v68
				if v55 < 1300 or v56 < 640 then
					v68 = v60 or v56 < 560
				else
					v68 = false
				end
				v65 = v66(v67, v68)
			else
				v65 = 0
			end
			v_u_61.headTop = v65
			local function v70(p69) -- name: planAt
				-- upvalues: (copy) v_u_61, (ref) v_u_5
				v_u_61.zoom = p69
				return v_u_5.decide(v_u_61)
			end
			v_u_61.zoom = not v58 and 1 or v58.factorFor(p_u_50, v70)
			local v71 = v_u_5.decide(v_u_61)
			p_u_50.touchSplitCandidate = v71.splitCandidate or p_u_50.zoomFit == true
			local v72 = v71.compact
			local v73 = v71.headerH
			local v74 = v71.pad
			local v75 = v71.gap
			local v76 = v71.eqW
			local v77 = v71.gearCells
			local v78 = v71.rightCells
			local v79 = v71.cell
			local v80 = v71.narrow
			local v81 = v71.split
			local v_u_82 = v71.rail
			local v83 = v71.railW
			p_u_50.eqFoldable = v71.foldable
			p_u_50.split = v81
			p_u_50.touch = v60
			p_u_50.narrow = v80
			p_u_50.cell = v79
			p_u_50.compact = v72
			local v84 = v_u_33("Frame", {
				["Name"] = "Body",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.fromScale(1, 1)
			}, p_u_50.root)
			p_u_50.body = v84
			if p_u_50.standalone then
				local v85 = v_u_33("Frame", {
					["Name"] = "Header",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.05,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_12.bg,
					["Position"] = UDim2.fromOffset(v74, v74),
					["Size"] = UDim2.new(1, -2 * v74, 0, v73 - 8)
				}, v84)
				v_u_38(v85, v_u_12.line)
				v_u_33("Frame", {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_12.accent,
					["Size"] = UDim2.new(0, 3, 1, 0)
				}, v85)
				local v86
				if p_u_50.mode == "raid" then
					v86 = v_u_20:GetAttribute("FreeRaid") == true
				else
					v86 = false
				end
				local v87 = v_u_27(v85, p_u_50.mode == "raid" and (v86 and "Random kit" or "Inventory") or "Stash", v72 and "h3" or "h2", {
					["position"] = UDim2.fromOffset(16, 0),
					["size"] = UDim2.new(0, 220, 1, 0)
				})
				if v86 then
					v87.TextColor3 = v_u_12.accent
				end
				v87.TextYAlignment = Enum.TextYAlignment.Center
				local v88 = v_u_27(v85, "", "monoS", {
					["position"] = UDim2.fromOffset(v72 and 150 or 190, 0),
					["size"] = UDim2.new(0, 420, 1, 0)
				})
				v88.TextYAlignment = Enum.TextYAlignment.Center
				p_u_50.headerStats = v88
				local v89 = v_u_16.touch(v72 and 36 or 40)
				local v90 = v_u_33
				local v91 = {
					["Name"] = "Close",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["BackgroundColor3"] = v_u_12.raised,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -6, 0.5, 0)
				}
				local v92 = UDim2.fromOffset
				local v93 = v73 - 14
				v91.Size = v92(v89, (math.min(v89, v93)))
				local v_u_94 = v90("TextButton", v91, v85)
				v_u_38(v_u_94, v_u_12.line)
				local v95 = v_u_14.icon
				local v96 = {
					["parent"] = v_u_94,
					["size"] = UDim2.fromOffset(14, 14),
					["position"] = UDim2.fromScale(0.5, 0.5),
					["anchor"] = Vector2.new(0.5, 0.5),
					["color"] = v_u_12.text2
				}
				pcall(v95, "close", v96)
				v_u_94.MouseEnter:Connect(function()
					-- upvalues: (copy) v_u_94, (ref) v_u_12, (ref) v_u_37
					v_u_94.BackgroundColor3 = v_u_12.raised2
					v_u_37("hover")
				end)
				v_u_94.MouseLeave:Connect(function()
					-- upvalues: (copy) v_u_94, (ref) v_u_12
					v_u_94.BackgroundColor3 = v_u_12.raised
				end)
				v_u_94.Activated:Connect(function()
					-- upvalues: (copy) p_u_50
					p_u_50.close()
				end)
				local v97
				if p_u_50.mode == "raid" then
					local v98 = v_u_13.Map.button
					local v99 = p_u_11.cctx()
					local v100 = v89 + 14
					local v101 = v73 - 14
					v97 = v98(v99, v85, v100, math.min(v89, v101), v72) + 12
				else
					v97 = 0
				end
				local v_u_102 = v_u_33("Frame", {
					["Name"] = "Hints",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -v89 - 24 - v97, 0, 0),
					["Size"] = UDim2.new(0, 640, 1, 0)
				}, v85)
				v_u_33("UIListLayout", {
					["FillDirection"] = Enum.FillDirection.Horizontal,
					["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
					["VerticalAlignment"] = Enum.VerticalAlignment.Center,
					["Padding"] = UDim.new(0, 24),
					["SortOrder"] = Enum.SortOrder.LayoutOrder
				}, v_u_102)
				p_u_50.hintsFrame = v_u_102
				local v_u_103 = {}
				local function v112(p104, p105, p106) -- name: addHint
					-- upvalues: (copy) v_u_103, (ref) v_u_33, (copy) v_u_102, (ref) v_u_14, (ref) v_u_27
					local v107 = v_u_103
					local v108 = {
						["text"] = p105,
						["chip"] = p104 ~= nil
					}
					table.insert(v107, v108)
					local v109 = v_u_33("Frame", {
						["BackgroundTransparency"] = 1,
						["AutomaticSize"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["AutomaticSize"] = Enum.AutomaticSize.X,
						["Size"] = UDim2.fromOffset(0, 22),
						["LayoutOrder"] = p106
					}, v_u_102)
					v_u_33("UIListLayout", {
						["FillDirection"] = Enum.FillDirection.Horizontal,
						["VerticalAlignment"] = Enum.VerticalAlignment.Center,
						["Padding"] = UDim.new(0, 6),
						["SortOrder"] = Enum.SortOrder.LayoutOrder
					}, v109)
					if p104 then
						local v110 = v_u_14.keyHint
						pcall(v110, p104, {
							["parent"] = nil,
							["size"] = 20,
							["parent"] = v109
						})
					end
					local v111 = v_u_27(v109, p105, "micro", {
						["autoX"] = true,
						["size"] = nil,
						["size"] = UDim2.fromOffset(0, 22)
					})
					v111.AutomaticSize = Enum.AutomaticSize.X
					v111.TextTruncate = Enum.TextTruncate.None
					v111.TextYAlignment = Enum.TextYAlignment.Center
					v111.LayoutOrder = 2
				end
				local v113 = v_u_25()
				if v113 == "Gamepad" then
					v112(nil, "A: move  \194\183  X: options  \194\183  Y: equip / use", 1)
					if p_u_50.mode == "raid" then
						v112("map", "Map", 2)
						if not v72 then
							v112("inventory", "Close", 3)
						end
					end
				elseif v72 or v113 == "Touch" then
					if v113 == "Touch" then
						v112(nil, "Tap: move  \194\183  Hold: pick up", 1)
					end
				else
					v112("rotateItem", "Rotate while dragging", 1)
					v112(nil, "Right click: options", 2)
					v112(nil, "Ctrl+click: move  \194\183  Double click: equip / use / open", 3)
					if p_u_50.mode == "raid" then
						v112("inventory", "Close", 4)
					end
				end
				if v59 then
					local v114 = 0.6 * v_u_16.phoneText(v_u_16.textSize("micro"), "caption")
					local v115 = v_u_9.header
					local v116 = {
						["w"] = nil,
						["h"] = nil,
						["closeW"] = nil,
						["mapBtnW"] = nil,
						["statsX"] = nil,
						["titleX"] = 16,
						["hintsW"] = nil,
						["touchPx"] = nil,
						["labelW"] = nil,
						["w"] = v55 - 2 * v74,
						["h"] = v73 - 8,
						["closeW"] = v89
					}
					local v117 = v97 - 12
					v116.mapBtnW = math.max(0, v117)
					v116.statsX = v72 and 150 or 190
					v116.hintsW = v_u_9.hintsWidth(v_u_103, v114, 20)
					v116.touchPx = v_u_16.touch(28)
					v116.labelW = v_u_9.labelW(v60)
					local v118 = v115(v116)
					v58.header(p_u_50, v85, v118)
					if p_u_50.zoomHide ~= true then
						v87.Size = UDim2.new(0, v118.titleW, 1, 0)
						v88.Position = UDim2.fromOffset(v118.statsX, 0)
						v88.Size = UDim2.new(0, v118.statsW, 1, 0)
						v88.TextTruncate = Enum.TextTruncate.AtEnd
						v88.Visible = v118.statsW > 0
						v_u_102.Position = UDim2.new(1, v118.hintsRight - (v55 - 2 * v74), 0, 0)
						v_u_102.Visible = v118.hintsVisible
					end
				end
			end
			local v119 = v73 + v74
			local v120 = v56 - v119 - v74
			local v121 = v_u_33("Frame", {
				["Name"] = "Columns",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(v74, v119),
				["Size"] = UDim2.new(1, -2 * v74, 0, v120)
			}, v84)
			p_u_50.columns = v121
			local v122
			if v72 then
				v122 = v60 or v56 < 560
			else
				v122 = v72
			end
			local v123, v124, v125 = v_u_23(v121, "Equipment", 0, v76, v120, "Equipment", "On your body", v122)
			p_u_50.eqSub = v125
			local v126 = v_u_33("ScrollingFrame", {
				["Name"] = "Scroll",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ScrollBarThickness"] = nil,
				["ScrollBarImageColor3"] = nil,
				["ScrollingDirection"] = nil,
				["ElasticBehavior"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["ScrollBarThickness"] = v_u_16.scrollBar,
				["ScrollBarImageColor3"] = v_u_12.lineStrong,
				["ScrollingDirection"] = Enum.ScrollingDirection.Y,
				["ElasticBehavior"] = Enum.ElasticBehavior.Never
			}, v124)
			p_u_50.eqScroll = v126
			local v127 = v76 - (v122 and 20 or 24) - 14
			local v128 = (v127 - 8) / 2
			local v129 = math.floor(v128)
			local v130 = v129 * (v72 and 0.72 or 0.8)
			local v131 = (v127 - 18) / 4
			local v132 = math.floor(v131)
			local v133
			if v_u_4 then
				v133 = v_u_4.quickLayout(v127, 6, v_u_16.touch(44), v60)
			else
				v133 = nil
			end
			if v133 then
				v132 = v133.size
			end
			local v134 = v120 - (v122 and 46 or 64)
			local v135 = 94
			local v136
			if v133 then
				v136 = v133.height
			else
				v136 = v132
			end
			local v137 = v135 + v136 + 8 + 38
			local v138 = v130 * 4 + 160
			local v139 = v138 <= v134 - v137 - 140 - 8
			local v140
			if v139 then
				local v141 = (v134 - v137 - 140 - 8) / v138
				v140 = math.clamp(v141, 1, 1.3)
			else
				local v142 = (v134 - v137) / v138
				v140 = math.clamp(v142, v72 and 0.78 or 0.9, 1)
			end
			local v143 = 0
			p_u_50.weightLabel = v_u_27(v126, "Weight", "micro", {
				["position"] = UDim2.fromOffset(0, v143),
				["size"] = UDim2.fromOffset(v127 * 0.4, 14)
			})
			local v144 = v_u_27(v126, "", "monoS", {
				["position"] = UDim2.fromOffset(v127 * 0.4, v143 - 1),
				["size"] = UDim2.fromOffset(v127 * 0.6, 14)
			})
			v144.TextXAlignment = Enum.TextXAlignment.Right
			p_u_50.weightText = v144
			local v_u_145, v_u_146 = pcall(function()
				return require(game:GetService("ReplicatedStorage").Hush.Shared.Skills)
			end)
			local v147 = v_u_33("Frame", {
				["Name"] = "WeightTip",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["Position"] = UDim2.fromOffset(0, 0),
				["Size"] = UDim2.fromOffset(v127, 24)
			}, v126)
			local v148 = v_u_14.tooltip
			local function v151()
				-- upvalues: (ref) v_u_13, (copy) v_u_145, (copy) v_u_146
				local v149 = v_u_13.Why.weightTip
				local v150
				if v_u_145 then
					v150 = v_u_146.MOVE
				else
					v150 = nil
				end
				return v149(v150)
			end
			pcall(v148, v147, v151)
			local v152 = v_u_14.progress
			local v153 = {
				["parent"] = nil,
				["size"] = nil,
				["position"] = nil,
				["value"] = 0,
				["color"] = nil,
				["parent"] = v126,
				["size"] = UDim2.fromOffset(v127, 4),
				["position"] = UDim2.fromOffset(0, v143 + 18),
				["color"] = v_u_12.success
			}
			local v154, v155 = pcall(v152, v153)
			if not v154 then
				v155 = nil
			end
			p_u_50.weightBar = v155
			p_u_50.weightPrimed = false
			local v156 = v143 + 32
			local v157 = 92 * v140
			local v158 = math.floor(v157)
			local v159 = 68 * v140
			local v160 = math.floor(v159)
			local v161 = v130 * v140
			local v162 = math.floor(v161)
			local v163, v164, v165 = v_u_17.slotHeights(v158, v160, v162)
			local v166 = v_u_19[1]
			local v167 = v_u_31(p_u_50, v126, v166, UDim2.fromOffset(0, v156), UDim2.fromOffset(v127, v163))
			p_u_50.slots[v166.id] = v167
			v156 = v156 + (v163 + 8)
			local v168 = v_u_19[2]
			local v169 = v_u_31(p_u_50, v126, v168, UDim2.fromOffset(0, v156), UDim2.fromOffset(v127, v164))
			p_u_50.slots[v168.id] = v169
			v156 = v156 + (v164 + 8)
			local v170 = v_u_19[3]
			local v171 = v_u_31(p_u_50, v126, v170, UDim2.fromOffset(0, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v170.id] = v171
			local v172 = v_u_19[4]
			local v173 = v129 + 8
			local v174 = v_u_31(p_u_50, v126, v172, UDim2.fromOffset(v173, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v172.id] = v174
			v156 = v156 + (v165 + 8)
			local v175 = v_u_19[5]
			local v176 = v_u_31(p_u_50, v126, v175, UDim2.fromOffset(0, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v175.id] = v176
			local v177 = v_u_19[6]
			local v178 = v129 + 8
			local v179 = v_u_31(p_u_50, v126, v177, UDim2.fromOffset(v178, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v177.id] = v179
			v156 = v156 + (v165 + 8)
			local v180 = v_u_19[8]
			local v181 = v_u_31(p_u_50, v126, v180, UDim2.fromOffset(0, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v180.id] = v181
			local v182 = v_u_19[9]
			local v183 = v129 + 8
			local v184 = v_u_31(p_u_50, v126, v182, UDim2.fromOffset(v183, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v182.id] = v184
			v156 = v156 + (v165 + 8)
			local v185 = v_u_19[7]
			local v186 = v_u_31(p_u_50, v126, v185, UDim2.fromOffset(0, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v185.id] = v186
			local v187 = v_u_19[10]
			local v188 = v129 + 8
			local v189 = v_u_31(p_u_50, v126, v187, UDim2.fromOffset(v188, v156), UDim2.fromOffset(v129, v165))
			p_u_50.slots[v187.id] = v189
			v156 = v156 + (v165 + 8)
			local v190 = v_u_33("Frame", {
				["Name"] = "ValueBlock",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(0, v156),
				["Size"] = UDim2.fromOffset(v127, 30)
			}, v126)
			v_u_27(v190, v_u_13.Why.kitLabel(p_u_50.mode), "micro", {
				["position"] = UDim2.fromOffset(4, 8),
				["size"] = UDim2.new(0.4, -4, 0, 14)
			})
			local v191 = v_u_14.tooltip
			local function v192()
				-- upvalues: (ref) v_u_13, (copy) p_u_50
				return v_u_13.Why.kitTip(p_u_50.mode)
			end
			pcall(v191, v190, v192)
			local v193 = v_u_27(v190, "$0", "monoL", {
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["position"] = UDim2.new(0.4, 0, 0, 2),
				["size"] = UDim2.new(0.6, -4, 0, 26)
			})
			v193.TextColor3 = v_u_12.accent
			v193.TextXAlignment = Enum.TextXAlignment.Right
			p_u_50.valueText = v193
			v156 = v156 + 42
			v_u_27(v126, "Quick slots", "micro", {
				["position"] = UDim2.fromOffset(0, v156),
				["size"] = UDim2.fromOffset(v127, 14)
			})
			v156 = v156 + 18
			local v194 = v156
			for v195 = 1, 4 do
				local v196 = (v195 - 1) * (v132 + 6)
				local v197
				if v133 then
					v196, v197 = v133.pos(v195)
				else
					v197 = 0
				end
				p_u_50.quick[v195] = v_u_29(p_u_50, v126, v195, UDim2.fromOffset(v196, v194 + v197), UDim2.fromOffset(v132, v132))
			end
			if v133 then
				v132 = v133.height
			end
			v156 = v194 + (v132 + 8)
			p_u_50.summary = nil
			if v139 then
				v156 = v156 + 8
				local v198 = v_u_33("Frame", {
					["Name"] = "Summary",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(0, v156),
					["Size"] = UDim2.fromOffset(v127, 140)
				}, v126)
				v_u_27(v198, "Loadout", "micro", {
					["position"] = UDim2.fromOffset(0, 0),
					["size"] = UDim2.new(1, 0, 0, 14)
				})
				v_u_33("Frame", {
					["Name"] = "Line",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_12.line,
					["Position"] = UDim2.fromOffset(0, 20),
					["Size"] = UDim2.new(1, 0, 0, 1)
				}, v198)
				local v199 = v156
				local v200 = {}
				for v201, v202 in {
					"Armor",
					"Bite block",
					"Free cells",
					"Ammo",
					"Medical"
				} do
					local v203 = 26 + (v201 - 1) * 22
					v_u_27(v198, v202, "small", {
						["position"] = UDim2.fromOffset(0, v203),
						["size"] = UDim2.new(0.5, 0, 0, 20),
						["color"] = v_u_12.text2
					}).TextYAlignment = Enum.TextYAlignment.Center
					local v204 = v_u_27(v198, "-", "monoS", {
						["position"] = UDim2.new(0.5, 0, 0, v203),
						["size"] = UDim2.new(0.5, 0, 0, 20)
					})
					v204.TextXAlignment = Enum.TextXAlignment.Right
					v204.TextYAlignment = Enum.TextYAlignment.Center
					v200[v202] = v204
				end
				p_u_50.summary = v200
				v156 = v199 + 140
			end
			v126.CanvasSize = UDim2.fromOffset(0, v156)
			p_u_50.rail = nil
			if v_u_82 then
				v_u_21(p_u_50, v121, v123, v83, v120, v76)
			else
				v83 = v76
			end
			if p_u_50.eqFoldable then
				local v205 = v_u_33("TextButton", {
					["Name"] = nil,
					["AutoButtonColor"] = false,
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["ZIndex"] = 20,
					["Name"] = v_u_82 and "EquipDock" or "EquipFold",
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -2, 0, 0),
					["Size"] = UDim2.fromOffset(v_u_16.touch(28), v_u_16.touch(28))
				}, v123)
				local v206 = v_u_33("Frame", {
					["Name"] = "Box",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 20,
					["BackgroundColor3"] = v_u_12.raised,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.new(0.5, 0, 0, 18),
					["Size"] = UDim2.fromOffset(v_u_82 and 44 or 28, 28)
				}, v205)
				v_u_38(v206, v_u_12.lineStrong)
				if v_u_82 then
					v_u_33("TextLabel", {
						["Name"] = "Dock",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 11,
						["TextColor3"] = nil,
						["Text"] = "DOCK",
						["ZIndex"] = 21,
						["Size"] = UDim2.fromScale(1, 1),
						["FontFace"] = v_u_16.font.heading,
						["TextColor3"] = v_u_12.accent
					}, v206)
				else
					local v207 = v_u_14.icon
					local v208 = {
						["parent"] = nil,
						["size"] = 14,
						["position"] = nil,
						["anchor"] = nil,
						["color"] = nil,
						["zindex"] = 21,
						["parent"] = v206,
						["position"] = UDim2.fromScale(0.5, 0.5),
						["anchor"] = Vector2.new(0.5, 0.5),
						["color"] = v_u_12.accent
					}
					pcall(v207, "chevronLeft", v208)
				end
				v205.Activated:Connect(function()
					-- upvalues: (ref) v_u_1, (copy) v_u_82, (ref) v_u_37, (ref) v_u_2, (copy) p_u_50
					v_u_1.eqFold = not v_u_82
					v_u_37(v_u_1.eqFold and "close" or "open")
					task.defer(v_u_2, p_u_50)
				end)
			end
			local v209 = v71.gearW
			local v210, v211, v212, v213 = v_u_23(v121, "Gear", v83 + v75, v209, v120, v80 and p_u_50.mode ~= "raid" and "Gear & stash" or (v80 and v57 ~= "" and "Loot & gear" or "Gear"), p_u_50.mode == "raid" and "Pockets \194\183 rig \194\183 backpack \194\183 secure" or "Loadout for the next raid", v122)
			p_u_50.gearSub = v212
			p_u_50.gearScroll = v_u_30(v211, "Scroll", UDim2.fromScale(1, 1))
			local v214 = not v80
			if v214 then
				v214 = v120 >= 640
			end
			p_u_50.tallPlaceholders = v214
			p_u_50.secTabs = nil
			if v80 then
				p_u_50.gearScroll.ScrollingDirection = Enum.ScrollingDirection.XY
				p_u_50.gearScroll.AutomaticCanvasSize = Enum.AutomaticSize.XY
				p_u_50.rightScroll = p_u_50.gearScroll
				p_u_50.rightW = v209 - 34
				p_u_50.gearW = v209 - 34
				if p_u_50.mode ~= "raid" then
					local v215 = math.max(v77, v78) * v79
					if v215 <= v209 - 34 then
						p_u_50.rightW = v215
						p_u_50.gearW = v215
						local v216 = p_u_50.gearScroll:FindFirstChildOfClass("UIListLayout")
						if v216 and v209 - 34 > v215 + 16 then
							v216.HorizontalAlignment = Enum.HorizontalAlignment.Center
						end
					end
				end
				p_u_50.scrollers = { p_u_50.gearScroll, v126 }
				if v57 ~= "" or not v60 then
					v_u_22(p_u_50, v210, v211, v213, v212, v122)
				end
				if v59 and not p_u_50.standalone then
					local v217 = v_u_16.touch(28)
					local v218 = v122 and 12 or 16
					local v219
					if p_u_50.secTabFrame == nil then
						v219 = false
					else
						v219 = p_u_50.secTabs ~= nil
					end
					local v220 = v_u_9.columnHead({
						["panelW"] = nil,
						["inset"] = nil,
						["tight"] = nil,
						["touchPx"] = nil,
						["labelW"] = nil,
						["labelMin"] = nil,
						["titleMin"] = 64,
						["tabs"] = nil,
						["tabsMin"] = nil,
						["panelW"] = v209,
						["inset"] = v218,
						["tight"] = v122,
						["touchPx"] = v217,
						["labelW"] = v_u_9.labelW(v60),
						["labelMin"] = v_u_9.labelMinFor(v_u_16.phoneText(13, "text")),
						["tabs"] = v219,
						["tabsMin"] = v_u_9.TABS_MIN
					})
					if v219 then
						v58.tabsHead(p_u_50, v210, v211, p_u_50.secTabFrame, v220, v122)
					else
						v58.columnHead(p_u_50, v210, v211, v213, v212, v220, v122)
					end
				end
				v_u_39(p_u_50)
				v_u_34(p_u_50)
			else
				local v221 = v71.rx
				local v222 = v71.rw
				local v223 = v71.rwFit
				local v224, v225, v226, v227 = v_u_23(v121, "Loot", v221, v222, v120, p_u_50.mode == "raid" and "Nearby" or "Stash", p_u_50.mode == "raid" and "Containers in reach \194\183 ground" or "Everything you own", v122)
				p_u_50.rightSub = v226
				if v59 and not p_u_50.standalone then
					local v228 = v_u_9.columnHead({
						["panelW"] = nil,
						["inset"] = nil,
						["tight"] = nil,
						["touchPx"] = nil,
						["labelW"] = nil,
						["labelMin"] = nil,
						["titleMin"] = 64,
						["tabs"] = false,
						["panelW"] = v222,
						["inset"] = v122 and 12 or 16,
						["tight"] = v122,
						["touchPx"] = v_u_16.touch(28),
						["labelW"] = v_u_9.labelW(v60),
						["labelMin"] = v_u_9.labelMinFor(v_u_16.phoneText(13, "text"))
					})
					v58.columnHead(p_u_50, v224, v225, v227, v226, v228, v122)
					v58.shiftContent(v211, v122, v_u_9.alignTop(v228.top, v_u_16.touch(28), v122))
				end
				p_u_50.rightScroll = v_u_30(v225, "Scroll", UDim2.fromScale(1, 1))
				p_u_50.rightScroll.ScrollingDirection = Enum.ScrollingDirection.XY
				p_u_50.rightScroll.AutomaticCanvasSize = Enum.AutomaticSize.XY
				p_u_50.rightW = v222 - v_u_18
				if v223 then
					p_u_50.rightW = v78 * v79
					local v229 = p_u_50.rightScroll:FindFirstChildOfClass("UIListLayout")
					if v229 and v222 - v_u_18 > p_u_50.rightW + 8 then
						v229.HorizontalAlignment = Enum.HorizontalAlignment.Center
					end
				end
				p_u_50.gearW = v209 - 34
				p_u_50.scrollers = { p_u_50.gearScroll, p_u_50.rightScroll, v126 }
				v_u_39(p_u_50)
				v_u_34(p_u_50)
			end
		else
			return
		end
	end
end
function v_u_1.build(p230) -- name: build
	-- upvalues: (ref) v_u_2
	v_u_2(p230)
end
return v_u_1