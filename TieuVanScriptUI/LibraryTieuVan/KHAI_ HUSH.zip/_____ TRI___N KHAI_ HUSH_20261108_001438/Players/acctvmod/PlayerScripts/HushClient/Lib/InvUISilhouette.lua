-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUISilhouette

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v2 = require(v1:WaitForChild("Theme"))
local v_u_3 = require(script.Parent:WaitForChild("InvUISlotHint"))
local v_u_4 = v2.color
local v_u_5 = {}
local v_u_6 = {
	["rifle"] = {
		["aspect"] = 3.4,
		["parts"] = nil,
		["parts"] = {
			{
				0,
				0.34,
				0.17,
				0.66,
				0,
				0.12
			},
			{
				0.15,
				0.4,
				0.22,
				0.56
			},
			{
				0.21,
				0.3,
				0.58,
				0.54
			},
			{
				0.3,
				0.2,
				0.5,
				0.28
			},
			{
				0.36,
				0.13,
				0.44,
				0.22
			},
			{
				0.57,
				0.34,
				0.84,
				0.5
			},
			{
				0.83,
				0.39,
				1,
				0.45
			},
			{
				0.93,
				0.27,
				0.95,
				0.4
			},
			{
				0.42,
				0.5,
				0.5,
				0.92,
				-8
			},
			{
				0.27,
				0.5,
				0.33,
				0.8,
				18
			},
			{
				0.33,
				0.54,
				0.41,
				0.64,
				0,
				0.5,
				true
			}
		}
	},
	["pistol"] = {
		["aspect"] = 1.45,
		["parts"] = nil,
		["parts"] = {
			{
				0.08,
				0.16,
				0.97,
				0.4,
				0,
				0.08
			},
			{
				0.13,
				0.38,
				0.8,
				0.52
			},
			{
				0.12,
				0.46,
				0.36,
				0.95,
				0,
				0.1
			},
			{
				0.33,
				0.5,
				0.53,
				0.66,
				0,
				0.5
			},
			{
				0.38,
				0.52,
				0.48,
				0.62,
				0,
				0.5,
				true
			},
			{
				0.88,
				0.1,
				0.93,
				0.17
			}
		}
	},
	["knife"] = {
		["aspect"] = 2.3,
		["parts"] = nil,
		["parts"] = {
			{
				0.02,
				0.36,
				0.33,
				0.64,
				0,
				0.4
			},
			{
				0.08,
				0.44,
				0.1,
				0.56,
				0,
				0,
				true
			},
			{
				0.32,
				0.18,
				0.38,
				0.82,
				0,
				0.3
			},
			{
				0.38,
				0.32,
				0.88,
				0.64
			},
			{
				0.8,
				0.36,
				0.98,
				0.6,
				0,
				0.5
			},
			{
				0.42,
				0.4,
				0.8,
				0.43,
				0,
				0,
				true
			}
		}
	},
	["helmet"] = {
		["aspect"] = 1.35,
		["parts"] = nil,
		["parts"] = {
			{
				0.1,
				0.12,
				0.9,
				1.3,
				0,
				0.5,
				false,
				0.74
			},
			{
				0.02,
				0.7,
				0.98,
				0.8,
				0,
				0.3
			},
			{
				0.16,
				0.56,
				0.84,
				0.61,
				0,
				0,
				true
			}
		}
	},
	["vest"] = {
		["aspect"] = 0.86,
		["parts"] = nil,
		["parts"] = {
			{
				0.14,
				0.04,
				0.34,
				0.34,
				0,
				0.2
			},
			{
				0.66,
				0.04,
				0.86,
				0.34,
				0,
				0.2
			},
			{
				0.1,
				0.28,
				0.9,
				0.96,
				0,
				0.08
			},
			{
				0.36,
				0.28,
				0.64,
				0.38,
				0,
				0.5,
				true
			},
			{
				0.16,
				0.6,
				0.36,
				0.86,
				0,
				0.1,
				true
			},
			{
				0.4,
				0.6,
				0.6,
				0.86,
				0,
				0.1,
				true
			},
			{
				0.64,
				0.6,
				0.84,
				0.86,
				0,
				0.1,
				true
			},
			{
				0.18,
				0.64,
				0.34,
				0.84,
				0,
				0.1
			},
			{
				0.42,
				0.64,
				0.58,
				0.84,
				0,
				0.1
			},
			{
				0.66,
				0.64,
				0.82,
				0.84,
				0,
				0.1
			}
		}
	},
	["backpack"] = {
		["aspect"] = 0.82,
		["parts"] = nil,
		["parts"] = {
			{
				0.36,
				0,
				0.64,
				0.16,
				0,
				0.5
			},
			{
				0.42,
				0.04,
				0.58,
				0.12,
				0,
				0.5,
				true
			},
			{
				0.1,
				0.1,
				0.9,
				0.97,
				0,
				0.22
			},
			{
				0.22,
				0.52,
				0.78,
				0.9,
				0,
				0.16,
				true
			},
			{
				0.25,
				0.55,
				0.75,
				0.87,
				0,
				0.14
			},
			{
				0.25,
				0.62,
				0.75,
				0.65,
				0,
				0,
				true
			}
		}
	},
	["boots"] = {
		["aspect"] = 1.1,
		["parts"] = nil,
		["parts"] = {
			{
				0.4,
				0.02,
				0.86,
				0.66,
				0,
				0.12
			},
			{
				0.06,
				0.48,
				0.86,
				0.86,
				0,
				0.35
			},
			{
				0.04,
				0.84,
				0.9,
				0.98,
				0,
				0.3
			},
			{
				0.46,
				0.14,
				0.54,
				0.56,
				0,
				0,
				true
			},
			{
				0.4,
				0.82,
				0.88,
				0.85,
				0,
				0,
				true
			}
		}
	},
	["legs"] = {
		["aspect"] = 0.7,
		["parts"] = nil,
		["parts"] = {
			{
				0.08,
				0,
				0.92,
				0.12,
				0,
				0.1
			},
			{
				0.08,
				0.08,
				0.47,
				0.98,
				2,
				0.12
			},
			{
				0.53,
				0.08,
				0.92,
				0.98,
				-2,
				0.12
			},
			{
				0.13,
				0.46,
				0.42,
				0.62,
				2,
				0.3,
				true
			},
			{
				0.58,
				0.46,
				0.87,
				0.62,
				-2,
				0.3,
				true
			},
			{
				0.16,
				0.48,
				0.39,
				0.6,
				2,
				0.3
			},
			{
				0.61,
				0.48,
				0.84,
				0.6,
				-2,
				0.3
			}
		}
	},
	["headset"] = {
		["aspect"] = 1,
		["parts"] = nil,
		["parts"] = {
			{
				0.2,
				0.04,
				0.8,
				0.14,
				0,
				0.5
			},
			{
				0.1,
				0.1,
				0.22,
				0.52,
				0,
				0.3
			},
			{
				0.78,
				0.1,
				0.9,
				0.52,
				0,
				0.3
			},
			{
				0.03,
				0.46,
				0.3,
				0.94,
				0,
				0.3
			},
			{
				0.7,
				0.46,
				0.97,
				0.94,
				0,
				0.3
			},
			{
				0.1,
				0.54,
				0.23,
				0.86,
				0,
				0.3,
				true
			},
			{
				0.77,
				0.54,
				0.9,
				0.86,
				0,
				0.3,
				true
			}
		}
	},
	["case"] = {
		["aspect"] = 1.3,
		["parts"] = nil,
		["parts"] = {
			{
				0.34,
				0.06,
				0.66,
				0.26,
				0,
				0.3
			},
			{
				0.4,
				0.11,
				0.6,
				0.26,
				0,
				0,
				true
			},
			{
				0.04,
				0.24,
				0.96,
				0.94,
				0,
				0.08
			},
			{
				0.04,
				0.44,
				0.96,
				0.47,
				0,
				0,
				true
			},
			{
				0.2,
				0.4,
				0.3,
				0.52,
				0,
				0.1,
				true
			},
			{
				0.7,
				0.4,
				0.8,
				0.52,
				0,
				0.1,
				true
			}
		}
	}
}
function v_u_5.draw(p7, p8, p9) -- name: draw
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4
	local v10 = p9 or {}
	if p7 == "pistol" and v10.slot == "secondary" then
		return v_u_5.drawSecondary(p8, v10, v_u_3.unlocks())
	end
	local v11 = v_u_6[p7] or v_u_6.case
	local v12 = v10.color or v_u_4.bgDeep:Lerp(v_u_4.muted, 0.42)
	local v13 = v10.transparency == nil and 0 or v10.transparency
	local v14 = v10.cutColor or v_u_4.bgDeep
	local v15 = v10.zindex or 2
	local v16 = v10.fill or 0.72
	local v17 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Name"] = "Silhouette_" .. p7,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(v16, v16),
		["ZIndex"] = v15
	}
	local v18 = Instance.new("Frame")
	v18.BorderSizePixel = 0
	for v19, v20 in v17 do
		v18[v19] = v20
	end
	v18.Parent = p8
	local v21 = Instance.new("UIAspectRatioConstraint")
	v21.AspectRatio = v11.aspect
	v21.AspectType = Enum.AspectType.FitWithinMaxSize
	v21.DominantAxis = Enum.DominantAxis.Width
	v21.Parent = v18
	for v22, v23 in v11.parts do
		local v24 = v23[1]
		local v25 = v23[2]
		local v26 = v23[3]
		local v27 = v23[4]
		local v28 = v23[5] or 0
		local v29 = v23[6] or 0
		local v30 = v23[7] == true
		local v31 = v23[8]
		if v31 then
			local v32 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["ClipsDescendants"] = true,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["Name"] = "Clip" .. v22,
				["Position"] = UDim2.fromScale(v24, v25),
				["Size"] = UDim2.fromScale(v26 - v24, v31 - v25),
				["ZIndex"] = v15
			}
			local v33 = Instance.new("Frame")
			v33.BorderSizePixel = 0
			for v34, v35 in v32 do
				v33[v34] = v35
			end
			v33.Parent = v18
			local v36 = {
				["Name"] = "P" .. v22,
				["BackgroundColor3"] = v12,
				["BackgroundTransparency"] = v13,
				["Size"] = UDim2.fromScale(1, (v27 - v25) / (v31 - v25)),
				["ZIndex"] = v15
			}
			local v37 = Instance.new("Frame")
			v37.BorderSizePixel = 0
			for v38, v39 in v36 do
				v37[v38] = v39
			end
			v37.Parent = v33
			if v29 <= 0 then
				break
			end
			local v40 = Instance.new("UICorner")
			v40.CornerRadius = UDim.new(v29, 0)
			v40.Parent = v37
		else
			local v41 = {
				["Name"] = "P" .. v22
			}
			local v42
			if v30 then
				v42 = v14
			else
				v42 = v12
			end
			v41.BackgroundColor3 = v42
			v41.BackgroundTransparency = v30 and 0 or v13
			v41.AnchorPoint = Vector2.new(0.5, 0.5)
			v41.Position = UDim2.fromScale((v24 + v26) * 0.5, (v25 + v27) * 0.5)
			v41.Size = UDim2.fromScale(v26 - v24, v27 - v25)
			v41.Rotation = v28
			v41.ZIndex = v15 + v22
			local v43 = Instance.new("Frame")
			v43.BorderSizePixel = 0
			local v44 = v18
			for v45, v46 in v41 do
				v43[v45] = v46
			end
			v43.Parent = v18
			if v29 > 0 then
				local v47 = Instance.new("UICorner")
				v47.CornerRadius = UDim.new(v29, 0)
				v47.Parent = v43
				v18 = v44
			else
				v18 = v44
			end
		end
	end
	return v18
end
function v_u_5.drawSecondary(p48, p49, p50) -- name: drawSecondary
	-- upvalues: (copy) v_u_5
	local v51 = {}
	for v52, v53 in p49 or {} do
		v51[v52] = v53
	end
	v51.slot = nil
	if type(p50) ~= "table" or p50.long ~= true then
		return v_u_5.draw("pistol", p48, v51)
	end
	local v54 = table.clone(v51)
	v54.transparency = 0.55
	v_u_5.draw("rifle", p48, v54)
	local v55 = table.clone(v51)
	v55.fill = (v51.fill or 0.72) * 0.55
	local v56 = v_u_5.draw("pistol", p48, v55)
	v56.AnchorPoint = Vector2.new(1, 1)
	v56.Position = UDim2.fromScale(1, 1)
	return v56
end
v_u_5.kinds = {
	"rifle",
	"pistol",
	"knife",
	"helmet",
	"vest",
	"backpack",
	"case",
	"boots",
	"legs",
	"headset"
}
return v_u_5