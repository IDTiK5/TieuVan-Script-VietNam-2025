-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Badges

local v1 = game:GetService("Players")
local v2 = {
	["name"] = "Badges",
	["order"] = 92
}
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = 0
local v_u_7 = v1.LocalPlayer
function v2.init(p_u_8) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_7, (ref) v_u_5
	v_u_3 = p_u_8
	p_u_8.lib.HushUI.bind(p_u_8)
	p_u_8.command("badges.banner", function(p9)
		-- upvalues: (ref) v_u_4, (copy) p_u_8
		if not v_u_4 then
			return "not ready"
		end
		local v10 = p_u_8.shared.Badges
		if p9[1] == "summary" or p9[1] == nil then
			v_u_4.banner({
				"first_extract",
				"first_zombie",
				"first_death",
				"beta_tester"
			})
		else
			if not v10.get(p9[1]) then
				local v11 = p9[1]
				return "unknown badge " .. tostring(v11)
			end
			v_u_4.banner({ p9[1] })
		end
		return "queued \194\183 " .. v_u_4.state()
	end)
	p_u_8.command("badges.feedtest", function(p12)
		-- upvalues: (ref) v_u_4, (ref) v_u_7
		if not v_u_4 then
			return "not ready"
		end
		v_u_4.feed({
			["name"] = v_u_7.DisplayName,
			["id"] = p12[1] or "first_extract"
		})
		return "ok \194\183 " .. v_u_4.state()
	end)
	p_u_8.command("badges.state", function()
		-- upvalues: (ref) v_u_4
		return not v_u_4 and "not ready" or v_u_4.state()
	end)
	p_u_8.command("wave.test", function(p13)
		-- upvalues: (ref) v_u_5
		if not v_u_5 then
			return "not ready"
		end
		local v14 = v_u_5.test
		local v15 = p13[1]
		v14(tonumber(v15) or 12)
		return "ok \194\183 " .. v_u_5.state()
	end)
	p_u_8.command("wave.state", function()
		-- upvalues: (ref) v_u_5
		return not v_u_5 and "not ready" or v_u_5.state()
	end)
	p_u_8.command("wave.raw", function(p16)
		-- upvalues: (ref) v_u_5
		if not v_u_5 then
			return "not ready"
		end
		local v17 = v_u_5._raw
		local v18 = table.concat
		return tostring(v17(v18(p16, " ")))
	end)
end
function v2.start() -- name: start
	-- upvalues: (ref) v_u_3, (copy) v_u_7, (ref) v_u_4, (ref) v_u_5
	local function v19()
		-- upvalues: (ref) v_u_3
		return v_u_3.lib.HUDBadge.new(v_u_3)
	end
	local v20, v_u_21 = pcall(v19)
	if v20 then
		v_u_4 = v_u_21
		local function v22()
			-- upvalues: (ref) v_u_3, (copy) v_u_21
			return v_u_3.lib.HUDWave.new(v_u_3, v_u_21)
		end
		local v23, v24 = pcall(v22)
		if v23 then
			v_u_5 = v24
		else
			warn("[Badges] ban wave lines failed:", v24)
			v_u_7:SetAttribute("ClientError", "banwave: " .. tostring(v24))
		end
		v_u_7:GetAttributeChangedSignal("BanWaveTest"):Connect(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			local v25 = v_u_7:GetAttribute("BanWaveTest")
			if v25 ~= nil then
				v_u_7:SetAttribute("BanWaveTest", nil)
				if v_u_5 and type(v25) == "number" then
					v_u_5.test(v25)
				end
			end
		end)
		v_u_3.on("ui.rebuild", function()
			-- upvalues: (ref) v_u_4
			if v_u_4 then
				local v26 = v_u_4.rebuild
				pcall(v26)
			end
		end)
		v_u_7:GetAttributeChangedSignal("Place"):Connect(function()
			-- upvalues: (ref) v_u_4
			if v_u_4 then
				local v27 = v_u_4.rebuild
				pcall(v27)
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_7
			v_u_3.net.listen("badge.unlocked", function(p28)
				-- upvalues: (ref) v_u_4, (ref) v_u_7
				if v_u_4 and type(p28) == "table" then
					v_u_4.banner(p28.ids)
					local v29 = v_u_7
					v_u_7:SetAttribute("BadgeBanner", (tonumber(v29:GetAttribute("BadgeBanner")) or 0) + 1)
				end
			end)
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_4
			v_u_3.net.listen("badge.feed", function(p30)
				-- upvalues: (ref) v_u_4
				if v_u_4 then
					v_u_4.feed(p30)
				end
			end)
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_5
			v_u_3.net.listen("wave.feed", function(p31)
				-- upvalues: (ref) v_u_5
				if v_u_5 then
					local v32 = v_u_5.push
					pcall(v32, p31)
				end
			end)
		end)
	else
		warn("[Badges] banner failed:", v_u_21)
		v_u_7:SetAttribute("ClientError", "badges: " .. tostring(v_u_21))
	end
end
function v2.step(p33) -- name: step
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_6
	if v_u_4 then
		v_u_4.update(p33)
	end
	if v_u_5 then
		local v34 = v_u_5.update
		local v35, v36 = pcall(v34, p33)
		if not v35 then
			v_u_6 = v_u_6 + 1
			if v_u_6 <= 3 then
				warn("[Badges] ban wave update:", v36)
			end
			if v_u_6 >= 30 then
				v_u_5 = nil
			end
		end
	end
end
return v2