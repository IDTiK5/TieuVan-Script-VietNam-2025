-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntHowTo

local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {
	["SEEN_KEY"] = "menuTipsSeen",
	["SEEN_ID"] = "huntht",
	["SEEN_LIMIT"] = 200,
	["TEXT_SIZE"] = 19,
	["EXTRA_SIZE"] = 15,
	["SWIPE_PX"] = 60
}
local v_u_5 = {
	["cyan"] = Color3.fromRGB(64, 224, 208),
	["yellow"] = Color3.fromRGB(255, 214, 10),
	["magenta"] = Color3.fromRGB(255, 64, 200),
	["green"] = Color3.fromRGB(96, 220, 110),
	["red"] = Color3.fromRGB(220, 50, 40),
	["orange"] = Color3.fromRGB(255, 124, 28),
	["pale"] = Color3.fromRGB(236, 232, 214),
	["dim"] = Color3.fromRGB(110, 100, 124),
	["night"] = Color3.fromRGB(18, 10, 28)
}
v_u_4.PALETTE = v_u_5
function v_u_4.pageCount(p6) -- name: pageCount
	local v7
	if type(p6) == "table" then
		v7 = p6.HOWTO
	else
		v7 = nil
	end
	local v8
	if type(v7) == "table" then
		v8 = v7.pages
	else
		v8 = nil
	end
	return type(v8) == "table" and #v8 or 0
end
function v_u_4.clampPage(p9, p10) -- name: clampPage
	local v11 = (type(p9) ~= "number" or p9 ~= p9) and 1 or math.floor(p9)
	local v12 = math.max(p10, 1)
	return math.clamp(v11, 1, v12)
end
function v_u_4.step(p13, p14, p15) -- name: step
	-- upvalues: (copy) v_u_4
	return v_u_4.clampPage(p13 + (p14 >= 0 and 1 or -1), p15)
end
local function v_u_19(p16) -- name: clockText
	local v17 = math.floor(p16)
	local v18 = math.max(0, v17)
	return ("%d:%02d"):format(v18 // 60, v18 % 60)
end
function v_u_4.textOf(p20, p21, p22) -- name: textOf
	-- upvalues: (copy) v_u_19
	local v23 = p20.HOWTO.pages[p22]
	if type(v23) ~= "table" then
		return ""
	end
	local v24 = v23.text
	local v25 = type(p21) ~= "table" and {} or p21
	if v23.id == "flow" then
		local v26 = p20.format
		local v27 = v25.HEAD_START
		return v26(v24, type(v27) ~= "number" and 20 or v25.HEAD_START)
	end
	if v23.id ~= "payback" then
		return v24
	end
	local v28 = p20.format
	local v29 = v_u_19
	local v30 = v25.HUNT_SEC
	return v28(v24, v29(type(v30) ~= "number" and 180 or v25.HUNT_SEC))
end
function v_u_4.extraOf(p31, p32, p33) -- name: extraOf
	-- upvalues: (copy) v_u_4
	local v34 = p31.HOWTO.pages[p33]
	return (type(v34) ~= "table" or v34.id ~= "rewards") and "" or v_u_4.ladderLine(p31, p32)
end
function v_u_4.ladderLine(p35, p36) -- name: ladderLine
	local v37
	if type(p36) == "table" then
		v37 = p36.LADDER
	else
		v37 = nil
	end
	if type(v37) ~= "table" then
		return ""
	end
	local v38 = {}
	for _, v39 in v37 do
		local v40 = p35.HOWTO.ladder[v39.id]
		if type(v40) ~= "string" then
			continue
		end
		local v41 = v39.at
		if type(v41) ~= "number" then
			continue
		end
		local v42 = p35.format
		local v43 = p35.HOWTO.ladderItem
		local v44 = v39.at
		table.insert(v38, v42(v43, v44, v40))
	end
	return #v38 == 0 and "" or p35.format(p35.HOWTO.ladderLine, table.concat(v38, ", "))
end
function v_u_4.artId(p45, p46, p47) -- name: artId
	local v48 = p45.HOWTO.pages[p46]
	local v49 = p45.ART
	if type(v48) == "table" and type(v49) == "table" then
		local v50 = v48.art
		if type(v50) == "string" then
			local v51 = ""
			local v52
			if p47 then
				v52 = v49[v48.art .. "p"]
				if type(v52) == "string" then
					if v52 == "" then
						v52 = v51
					end
				else
					v52 = v51
				end
			else
				v52 = v51
			end
			local v53
			if v52 == "" then
				v53 = v49[v48.art]
				if type(v53) ~= "string" then
					v53 = v52
				end
			else
				v53 = v52
			end
			return (v53 == "" or (v53 == "rbxassetid://0" or string.sub(v53, 1, 13) ~= "rbxassetid://")) and "" or v53
		end
	end
	return ""
end
function v_u_4.rect(p54, p55, p56, p57) -- name: rect
	return {
		["x0"] = p54,
		["y0"] = p55,
		["x1"] = p54 + p56,
		["y1"] = p55 + p57
	}
end
function v_u_4.layout(p58, p59, p60, p61) -- name: layout
	local v62 = type(p60) == "table" and (p60.l or 0) or 0
	local v63 = type(p60) == "table" and (p60.r or 0) or 0
	local v64 = type(p60) == "table" and (p60.t or 0) or 0
	local v65 = type(p60) == "table" and (p60.b or 0) or 0
	local v66 = p58.X - v62 - v63 - 24
	local v67 = p58.Y - v64 - v65 - 24
	local v68 = math.max(p61, 40)
	local v69 = p59 and 14 or 20
	local v70 = p59 and 8 or 10
	local v71 = {}
	local v72 = v67 >= 560 and v66 >= 640 and "stack" or "side"
	if v72 == "stack" then
		local v73 = math.min(v66, 1040)
		local v74 = v73 - v69 * 2
		local v75 = math.max(v68, 44)
		local v76 = v69 + v75 + v70 + v70 + 36 + 4 + 60 + 4 + 26 + v70 + v68 + v69
		local v77 = v74 * 9 / 16
		local v78 = math.floor(v77)
		local v79
		if v67 - v76 < v78 then
			local v80 = v67 - v76
			v78 = math.max(160, v80)
			local v81 = v78 * 16 / 9
			v79 = math.floor(v81)
		else
			v79 = v74
		end
		local v82 = v76 + v78
		v71.card = {
			["x0"] = 0,
			["y0"] = 0,
			["x1"] = nil,
			["y1"] = nil,
			["x1"] = v73 + 0,
			["y1"] = v82 + 0
		}
		local v83 = v73 - v69 - v75
		v71.close = {
			["x0"] = v83,
			["y0"] = v69,
			["x1"] = v83 + v75,
			["y1"] = v69 + v75
		}
		local v84 = v71.close.x0 - v70 - 90
		v71.count = {
			["x0"] = v84,
			["y0"] = v69,
			["x1"] = v84 + 90,
			["y1"] = v69 + v75
		}
		v71.head = {
			["x0"] = v69,
			["y0"] = v69,
			["x1"] = v69 + (v71.count.x0 - v70 - v69),
			["y1"] = v69 + v75
		}
		local v85 = (v74 - v79) / 2
		local v86 = v69 + math.floor(v85)
		local v87 = v69 + v75 + v70
		v71.image = {
			["x0"] = v86,
			["y0"] = v87,
			["x1"] = v86 + v79,
			["y1"] = v87 + v78
		}
		local v88 = v71.image.y1 + v70
		v71.title = {
			["x0"] = v69,
			["y0"] = v88,
			["x1"] = v69 + v74,
			["y1"] = v88 + 36
		}
		local v89 = v71.title.y1 + 4
		v71.text = {
			["x0"] = v69,
			["y0"] = v89,
			["x1"] = v69 + v74,
			["y1"] = v89 + 60
		}
		local v90 = v71.text.y1 + 4
		v71.extra = {
			["x0"] = v69,
			["y0"] = v90,
			["x1"] = v69 + v74,
			["y1"] = v90 + 26
		}
		local v91 = v82 - v69 - v68
		local v92 = p59 and 130 or 160
		v71.prev = {
			["x0"] = v69,
			["y0"] = v91,
			["x1"] = v69 + v92,
			["y1"] = v91 + v68
		}
		local v93 = v73 - v69 - v92
		v71.next = {
			["x0"] = v93,
			["y0"] = v91,
			["x1"] = v93 + v92,
			["y1"] = v91 + v68
		}
		local v94 = v71.prev.x1 + v70
		v71.dots = {
			["x0"] = v94,
			["y0"] = v91,
			["x1"] = v94 + (v71.next.x0 - v70 - (v71.prev.x1 + v70)),
			["y1"] = v91 + v68
		}
		return v71, v72
	end
	local v95 = math.min(v66, 960)
	local v96 = math.min(v67, 460)
	local v97 = v95 - v69 * 2
	local v98 = v96 - v69 * 2
	local v99 = v97 * 0.5
	local v100 = math.floor(v99)
	local v101 = v100 * 3 / 4
	local v102 = math.floor(v101)
	if v98 < v102 then
		local v103 = v98 * 4 / 3
		v100 = math.floor(v103)
		v102 = v98
	end
	v71.card = {
		["x0"] = 0,
		["y0"] = 0,
		["x1"] = nil,
		["y1"] = nil,
		["x1"] = v95 + 0,
		["y1"] = v96 + 0
	}
	local v104 = (v98 - v102) / 2
	local v105 = v69 + math.floor(v104)
	v71.image = {
		["x0"] = v69,
		["y0"] = v105,
		["x1"] = v69 + v100,
		["y1"] = v105 + v102
	}
	local v106 = v71.image.x1 + 16
	local v107 = v95 - v69 - v106
	local v108 = math.max(v68, 40)
	local v109 = v95 - v69 - v108
	v71.close = {
		["x0"] = v109,
		["y0"] = v69,
		["x1"] = v109 + v108,
		["y1"] = v69 + v108
	}
	local v110 = v71.close.x0 - v70 - 60
	v71.count = {
		["x0"] = v110,
		["y0"] = v69,
		["x1"] = v110 + 60,
		["y1"] = v69 + v108
	}
	v71.head = {
		["x0"] = v106,
		["y0"] = v69,
		["x1"] = v106 + (v71.count.x0 - v70 - v106),
		["y1"] = v69 + v108
	}
	local v111 = v96 - v69 - v68
	local v112 = (v107 - v70) / 2
	local v113 = math.floor(v112)
	v71.prev = {
		["x0"] = v106,
		["y0"] = v111,
		["x1"] = v106 + v113,
		["y1"] = v111 + v68
	}
	local v114 = v106 + v113 + v70
	v71.next = {
		["x0"] = v114,
		["y0"] = v111,
		["x1"] = v114 + (v107 - v113 - v70),
		["y1"] = v111 + v68
	}
	local v115 = v111 - v70 - 14
	v71.dots = {
		["x0"] = v106,
		["y0"] = v115,
		["x1"] = v106 + v107,
		["y1"] = v115 + 14
	}
	local v116 = v71.head.y1 + 2
	v71.title = {
		["x0"] = v106,
		["y0"] = v116,
		["x1"] = v106 + v107,
		["y1"] = v116 + 34
	}
	local v117 = v71.title.y1 + 4
	local v118 = v71.dots.y0 - v70 - v117
	local v119 = v118 * 0.25
	local v120 = math.floor(v119)
	local v121 = math.min(40, v120)
	local v122 = v118 - v121 - 4
	v71.text = {
		["x0"] = v106,
		["y0"] = v117,
		["x1"] = v106 + v107,
		["y1"] = v117 + v122
	}
	local v123 = v71.text.y1 + 4
	v71.extra = {
		["x0"] = v106,
		["y0"] = v123,
		["x1"] = v106 + v107,
		["y1"] = v123 + v121
	}
	return v71, v72
end
v_u_4.PICTO = {
	["sides"] = {
		{
			"r",
			0.495,
			0.12,
			0.01,
			0.76,
			"dim",
			0.4
		},
		{
			"c",
			0.14,
			0.3,
			0.075,
			"cyan"
		},
		{
			"c",
			0.28,
			0.5,
			0.075,
			"yellow"
		},
		{
			"c",
			0.14,
			0.7,
			0.075,
			"magenta"
		},
		{
			"c",
			0.34,
			0.28,
			0.075,
			"green"
		},
		{
			"r",
			0.53,
			0.44,
			0.22,
			0.12,
			"pale",
			0.75
		},
		{
			"c",
			0.8,
			0.5,
			0.17,
			"red"
		}
	},
	["flow"] = {
		{
			"r",
			0.08,
			0.46,
			0.14,
			0.1,
			"cyan"
		},
		{
			"r",
			0.24,
			0.46,
			0.46,
			0.1,
			"orange"
		},
		{
			"r",
			0.72,
			0.46,
			0.2,
			0.1,
			"red"
		},
		{
			"c",
			0.15,
			0.28,
			0.07,
			"cyan"
		},
		{
			"c",
			0.36,
			0.28,
			0.06,
			"orange"
		},
		{
			"c",
			0.48,
			0.28,
			0.06,
			"orange"
		},
		{
			"c",
			0.6,
			0.28,
			0.06,
			"orange"
		},
		{
			"c",
			0.82,
			0.72,
			0.08,
			"red"
		}
	},
	["stalker"] = {
		{
			"c",
			0.1,
			0.64,
			0.035,
			"cyan"
		},
		{
			"c",
			0.19,
			0.54,
			0.035,
			"cyan"
		},
		{
			"c",
			0.28,
			0.64,
			0.035,
			"cyan"
		},
		{
			"c",
			0.37,
			0.54,
			0.035,
			"yellow"
		},
		{
			"c",
			0.46,
			0.64,
			0.035,
			"yellow"
		},
		{
			"c",
			0.55,
			0.54,
			0.035,
			"yellow"
		},
		{
			"r",
			0.6,
			0.7,
			0.12,
			0.1,
			"orange"
		},
		{
			"c",
			0.7,
			0.26,
			0.04,
			"yellow"
		},
		{
			"c",
			0.84,
			0.46,
			0.15,
			"red"
		}
	},
	["payback"] = {
		{
			"r",
			0.22,
			0.265,
			0.34,
			0.03,
			"pale",
			0.35
		},
		{
			"r",
			0.22,
			0.485,
			0.34,
			0.03,
			"pale",
			0.35
		},
		{
			"r",
			0.22,
			0.705,
			0.34,
			0.03,
			"pale",
			0.35
		},
		{
			"c",
			0.14,
			0.28,
			0.07,
			"cyan"
		},
		{
			"c",
			0.14,
			0.5,
			0.07,
			"yellow"
		},
		{
			"c",
			0.14,
			0.72,
			0.07,
			"magenta"
		},
		{
			"c",
			0.78,
			0.5,
			0.17,
			"red"
		},
		{
			"r",
			0.77,
			0.15,
			0.02,
			0.7,
			"pale",
			0.6
		}
	},
	["win"] = {
		{
			"r",
			0.04,
			0.1,
			0.44,
			0.8,
			"green",
			0.7
		},
		{
			"r",
			0.52,
			0.1,
			0.44,
			0.8,
			"red",
			0.7
		},
		{
			"c",
			0.12,
			0.28,
			0.06,
			"cyan"
		},
		{
			"c",
			0.24,
			0.28,
			0.06,
			"yellow"
		},
		{
			"c",
			0.36,
			0.28,
			0.06,
			"magenta"
		},
		{
			"r",
			0.14,
			0.72,
			0.22,
			0.07,
			"red"
		},
		{
			"c",
			0.74,
			0.38,
			0.13,
			"red"
		},
		{
			"c",
			0.62,
			0.76,
			0.04,
			"dim"
		},
		{
			"c",
			0.74,
			0.76,
			0.04,
			"dim"
		},
		{
			"c",
			0.86,
			0.76,
			0.04,
			"dim"
		}
	},
	["rewards"] = {
		{
			"r",
			0.1,
			0.62,
			0.12,
			0.2,
			"dim"
		},
		{
			"r",
			0.26,
			0.52,
			0.12,
			0.3,
			"dim"
		},
		{
			"r",
			0.42,
			0.42,
			0.12,
			0.4,
			"orange",
			0.3
		},
		{
			"r",
			0.58,
			0.32,
			0.12,
			0.5,
			"orange",
			0.15
		},
		{
			"r",
			0.74,
			0.2,
			0.12,
			0.62,
			"orange"
		},
		{
			"c",
			0.16,
			0.54,
			0.05,
			"orange"
		},
		{
			"c",
			0.32,
			0.44,
			0.05,
			"orange"
		},
		{
			"c",
			0.48,
			0.34,
			0.05,
			"orange"
		},
		{
			"c",
			0.64,
			0.24,
			0.05,
			"orange"
		},
		{
			"c",
			0.8,
			0.12,
			0.05,
			"yellow"
		}
	}
}
function v_u_4.pictoOf(p124) -- name: pictoOf
	-- upvalues: (copy) v_u_4
	local v125 = v_u_4.PICTO[tostring(p124)]
	return v125 == nil and {} or v125
end
function v_u_4.parseSeen(p126) -- name: parseSeen
	local v127 = {}
	if type(p126) ~= "string" then
		return v127
	end
	local v128 = {}
	for v129 in string.gmatch(p126, "[^,]+") do
		if string.find(v129, "[^%w_]") or v128[v129] then
			continue
		end
		v128[v129] = true
		table.insert(v127, v129)
	end
	return v127
end
function v_u_4.seenIn(p130) -- name: seenIn
	-- upvalues: (copy) v_u_4
	return table.find(v_u_4.parseSeen(p130), v_u_4.SEEN_ID) ~= nil
end
function v_u_4.seenValue(p131) -- name: seenValue
	-- upvalues: (copy) v_u_4
	local v132 = v_u_4.parseSeen(p131)
	if table.find(v132, v_u_4.SEEN_ID) == nil then
		local v133 = v_u_4.SEEN_ID
		table.insert(v132, v133)
	end
	local v134 = table.concat(v132, ",")
	if #v134 > v_u_4.SEEN_LIMIT then
		return nil
	else
		return v134
	end
end
function v_u_4.autoInHunt(p135) -- name: autoInHunt
	local v136
	if type(p135) == "table" and (p135.seen == false and (p135.shown ~= true and (p135.phase == "wait" and (p135.out ~= true and p135.result ~= true)))) then
		v136 = p135.home ~= true
	else
		v136 = false
	end
	return v136
end
function v_u_4.autoInLobby(p137) -- name: autoInLobby
	local v138
	if type(p137) == "table" and (p137.seen == false and p137.shown ~= true) then
		v138 = p137.state == "searching" and true or p137.state == "found"
	else
		v138 = false
	end
	return v138
end
function v_u_4.swipeDir(p139) -- name: swipeDir
	-- upvalues: (copy) v_u_4
	return type(p139) == "number" and p139 == p139 and (p139 <= -v_u_4.SWIPE_PX and 1 or (v_u_4.SWIPE_PX <= p139 and -1 or 0)) or 0
end
local v_u_140 = nil
function v_u_4.active() -- name: active
	-- upvalues: (ref) v_u_140
	if v_u_140 == nil or not v_u_140.isOpen() then
		return nil
	else
		return v_u_140
	end
end
function v_u_4.padSource(p141) -- name: padSource
	-- upvalues: (copy) v_u_1
	if type(p141) == "table" and p141.pad ~= nil then
		return p141.pad
	else
		local v143, v144 = pcall(function()
			local v142 = script.Parent
			if v142 then
				v142 = script.Parent:FindFirstChild("VirtualPad")
			end
			if v142 then
				return require(v142)
			else
				return nil
			end
		end)
		if v143 and (v144 ~= nil and v144.InputBegan ~= nil) then
			return v144
		else
			return v_u_1
		end
	end
end
function v_u_4.padFocus(p145, p146) -- name: padFocus
	-- upvalues: (copy) v_u_2
	local v147 = p145.UI
	if type(v147) == "table" then
		local v148 = p145.UI.device
		if type(v148) == "function" then
			local v149 = p145.UI.device
			local v150, v151 = pcall(v149)
			if not v150 or v151 ~= "Gamepad" then
				return false
			end
			local v152 = v_u_2.SelectedObject
			return v152 == nil and true or not v152:IsDescendantOf(p146)
		end
	end
	return false
end
function v_u_4.open(p_u_153) -- name: open
	-- upvalues: (ref) v_u_140, (copy) v_u_4, (copy) v_u_5, (copy) v_u_3, (copy) v_u_2
	if v_u_140 ~= nil then
		v_u_140.close()
	end
	local v_u_154 = p_u_153.UI
	local v_u_155 = p_u_153.Theme
	local v_u_156 = p_u_153.Names
	local v_u_157 = v_u_155.color
	local v_u_158 = p_u_153.Rules
	local v_u_159 = p_u_153.Rewards
	local v_u_160 = v_u_4.pageCount(v_u_156)
	local v_u_161 = {}
	local v_u_162 = true
	local v_u_163 = v_u_4.clampPage(p_u_153.page or 1, v_u_160)
	local v_u_164 = {}
	local v_u_165 = {}
	local v_u_166 = "stack"
	local v_u_167 = false
	local v_u_168, v169 = v_u_154.screen("HushHuntHowTo", v_u_155.layer.modal + 1, {
		["insets"] = "Device"
	})
	pcall(function()
		-- upvalues: (copy) v_u_168
		v_u_168:SetAttribute("PadFocusInGame", true)
	end)
	local v_u_170 = v_u_154.new("TextButton", {
		["Name"] = "Catcher",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Modal"] = true,
		["Selectable"] = false,
		["ZIndex"] = 1,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1)
	}, v169)
	local v_u_171 = v_u_154.new("Frame", {
		["Name"] = "Card",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.02,
		["BorderSizePixel"] = 0,
		["Active"] = true,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(600, 400),
		["BackgroundColor3"] = v_u_157.bg
	}, v169)
	v_u_154.stroke(v_u_171, v_u_157.lineStrong)
	v_u_154.new("Frame", {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 6,
		["BackgroundColor3"] = v_u_157.accent,
		["Size"] = UDim2.new(1, 0, 0, 2)
	}, v_u_171)
	local v_u_172 = v_u_154.new("Frame", {
		["Name"] = "Picture",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["Active"] = true,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_5.night
	}, v_u_171)
	v_u_154.stroke(v_u_172, v_u_157.line)
	local v_u_173 = v_u_154.new("ImageLabel", {
		["Name"] = "Back",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ScaleType"] = nil,
		["Image"] = "",
		["ImageTransparency"] = 0.55,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1),
		["ScaleType"] = Enum.ScaleType.Crop
	}, v_u_172)
	local v174 = v_u_156.ART
	local v175
	if type(v174) == "table" then
		local v176 = v_u_156.ART.tile
		v175 = type(v176) ~= "string" and "" or v_u_156.ART.tile
	else
		v175 = ""
	end
	v_u_173.Image = v175
	local v_u_177 = v_u_154.new("Frame", {
		["Name"] = "Sign",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_172)
	local v_u_178 = v_u_154.new("ImageLabel", {
		["Name"] = "Photo",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ScaleType"] = nil,
		["Image"] = "",
		["ImageTransparency"] = 0.98,
		["Visible"] = false,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1),
		["ScaleType"] = Enum.ScaleType.Crop
	}, v_u_172)
	local v_u_179 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Head",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["zindex"] = 6,
		["parent"] = v_u_171,
		["text"] = v_u_156.HOWTO.header,
		["color"] = v_u_157.accent
	})
	local v_u_180 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = "",
		["style"] = "monoL",
		["align"] = "right",
		["color"] = nil,
		["zindex"] = 6,
		["parent"] = v_u_171,
		["color"] = v_u_157.text2
	})
	local v_u_181 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "",
		["style"] = "h2",
		["fit"] = true,
		["zindex"] = 6,
		["parent"] = v_u_171
	})
	local v182 = not v_u_155.isPhone()
	local v183 = v_u_154.label
	local v184 = {
		["parent"] = nil,
		["name"] = "Sentence",
		["text"] = "",
		["style"] = "body",
		["wrap"] = true,
		["valign"] = "top",
		["color"] = nil,
		["textSize"] = nil,
		["zindex"] = 6,
		["parent"] = v_u_171,
		["color"] = v_u_157.text
	}
	local v185
	if v182 then
		v185 = v_u_4.TEXT_SIZE
	else
		v185 = nil
	end
	v184.textSize = v185
	local v_u_186 = v183(v184)
	local v187 = v_u_154.label
	local v188 = {
		["parent"] = nil,
		["name"] = "Extra",
		["text"] = "",
		["style"] = "small",
		["wrap"] = true,
		["valign"] = "top",
		["color"] = nil,
		["textSize"] = nil,
		["zindex"] = 6,
		["parent"] = v_u_171,
		["color"] = v_u_157.accent
	}
	local v189
	if v182 then
		v189 = v_u_4.EXTRA_SIZE
	else
		v189 = nil
	end
	v188.textSize = v189
	local v_u_190 = v187(v188)
	local v_u_191 = v_u_154.new("Frame", {
		["Name"] = "Dots",
		["BackgroundTransparency"] = 1,
		["ZIndex"] = 6
	}, v_u_171)
	local v_u_192 = {}
	for v193 = 1, v_u_160 do
		v_u_192[v193] = v_u_154.new("Frame", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 7,
			["Name"] = "Dot" .. v193,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(10, 10),
			["BackgroundColor3"] = v_u_157.line
		}, v_u_191)
	end
	local function v_u_198() -- name: close
		-- upvalues: (ref) v_u_162, (copy) v_u_164, (ref) v_u_167, (copy) v_u_154, (copy) v_u_168, (ref) v_u_140, (copy) v_u_161, (copy) p_u_153
		if v_u_162 then
			v_u_162 = false
			for _, v194 in v_u_164 do
				v194:Disconnect()
			end
			table.clear(v_u_164)
			if v_u_167 then
				v_u_167 = false
				local v195 = v_u_154.blur
				pcall(v195, false)
			end
			v_u_168:Destroy()
			if v_u_140 == v_u_161 then
				v_u_140 = nil
			end
			local v196 = p_u_153.onClose
			if type(v196) == "function" then
				local v197 = p_u_153.onClose
				pcall(v197)
			end
		end
	end
	local v_u_199 = nil
	local function v205(p200) -- name: goto
		-- upvalues: (ref) v_u_162, (ref) v_u_4, (copy) v_u_160, (ref) v_u_163, (ref) v_u_199, (copy) p_u_153
		if v_u_162 then
			local v201 = v_u_4.clampPage(p200, v_u_160)
			if v201 ~= v_u_163 then
				v_u_163 = v201
				v_u_199()
				local v202 = p_u_153.onPage
				if type(v202) == "function" then
					local v203 = p_u_153.onPage
					local v204 = v_u_163
					pcall(v203, v204)
				end
			end
		else
			return
		end
	end
	local function v212(p206) -- name: flip
		-- upvalues: (ref) v_u_162, (ref) v_u_163, (copy) v_u_160, (copy) v_u_198, (ref) v_u_4, (ref) v_u_199, (copy) p_u_153
		if v_u_162 then
			if p206 >= 0 and v_u_160 <= v_u_163 then
				v_u_198()
				return
			else
				local v207 = v_u_4.step(v_u_163, p206, v_u_160)
				if v_u_162 then
					local v208 = v_u_4.clampPage(v207, v_u_160)
					if v208 ~= v_u_163 then
						v_u_163 = v208
						v_u_199()
						local v209 = p_u_153.onPage
						if type(v209) == "function" then
							local v210 = p_u_153.onPage
							local v211 = v_u_163
							pcall(v210, v211)
						end
					end
				else
					return
				end
			end
		else
			return
		end
	end
	local v_u_218, v_u_219 = v_u_154.button({
		["parent"] = nil,
		["name"] = "Prev",
		["text"] = nil,
		["kind"] = "secondary",
		["size"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_171,
		["text"] = v_u_156.HOWTO.prev,
		["size"] = UDim2.fromOffset(120, 44),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_162, (ref) v_u_4, (ref) v_u_163, (copy) v_u_160, (ref) v_u_199, (copy) p_u_153
			if v_u_162 then
				local v213 = v_u_4.step(v_u_163, -1, v_u_160)
				if v_u_162 then
					local v214 = v_u_4.clampPage(v213, v_u_160)
					if v214 ~= v_u_163 then
						v_u_163 = v214
						v_u_199()
						local v215 = p_u_153.onPage
						if type(v215) == "function" then
							local v216 = p_u_153.onPage
							local v217 = v_u_163
							pcall(v216, v217)
						end
					end
				else
					return
				end
			else
				return
			end
		end
	})
	v_u_218.ZIndex = 6
	local v_u_225, v_u_226 = v_u_154.button({
		["parent"] = nil,
		["name"] = "Next",
		["text"] = nil,
		["kind"] = "primary",
		["size"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_171,
		["text"] = v_u_156.HOWTO.next,
		["size"] = UDim2.fromOffset(120, 44),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_162, (ref) v_u_163, (copy) v_u_160, (copy) v_u_198, (ref) v_u_4, (ref) v_u_199, (copy) p_u_153
			if v_u_162 then
				if v_u_160 <= v_u_163 then
					v_u_198()
					return
				else
					local v220 = v_u_4.step(v_u_163, 1, v_u_160)
					if v_u_162 then
						local v221 = v_u_4.clampPage(v220, v_u_160)
						if v221 ~= v_u_163 then
							v_u_163 = v221
							v_u_199()
							local v222 = p_u_153.onPage
							if type(v222) == "function" then
								local v223 = p_u_153.onPage
								local v224 = v_u_163
								pcall(v223, v224)
							end
						end
					else
						return
					end
				end
			else
				return
			end
		end
	})
	v_u_225.ZIndex = 6
	v_u_225.NextSelectionLeft = v_u_225
	v_u_225.NextSelectionRight = v_u_225
	v_u_218.NextSelectionLeft = v_u_218
	local v_u_227 = v_u_154.closeIcon({
		["parent"] = nil,
		["name"] = "Close",
		["size"] = 44,
		["onClick"] = nil,
		["parent"] = v_u_171,
		["onClick"] = v_u_198
	})
	v_u_227.ZIndex = 8
	v_u_227.NextSelectionLeft = v_u_227
	v_u_227.NextSelectionRight = v_u_227
	local function v_u_258() -- name: relayout
		-- upvalues: (copy) v_u_155, (copy) v_u_154, (ref) v_u_165, (ref) v_u_166, (ref) v_u_4, (copy) v_u_171, (copy) v_u_172, (copy) v_u_179, (copy) v_u_180, (copy) v_u_181, (copy) v_u_186, (copy) v_u_190, (copy) v_u_191, (copy) v_u_218, (copy) v_u_225, (copy) v_u_227, (copy) v_u_160, (copy) v_u_192
		local v228 = v_u_155.refSize()
		local v229 = v_u_154.safeInsets()
		local v230, v231 = v_u_4.layout(v228, v_u_155.isPhone(), v229, v_u_155.touch(40))
		v_u_165 = v230
		v_u_166 = v231
		v_u_171.Size = UDim2.fromOffset(v_u_165.card.x1, v_u_165.card.y1)
		local v232 = v_u_172
		local v233 = v_u_165.image
		v232.Position = UDim2.fromOffset(v233.x0, v233.y0)
		v232.Size = UDim2.fromOffset(v233.x1 - v233.x0, v233.y1 - v233.y0)
		local v234 = v_u_179
		local v235 = v_u_165.head
		v234.Position = UDim2.fromOffset(v235.x0, v235.y0)
		v234.Size = UDim2.fromOffset(v235.x1 - v235.x0, v235.y1 - v235.y0)
		local v236 = v_u_180
		local v237 = v_u_165.count
		v236.Position = UDim2.fromOffset(v237.x0, v237.y0)
		v236.Size = UDim2.fromOffset(v237.x1 - v237.x0, v237.y1 - v237.y0)
		local v238 = v_u_181
		local v239 = v_u_165.title
		v238.Position = UDim2.fromOffset(v239.x0, v239.y0)
		v238.Size = UDim2.fromOffset(v239.x1 - v239.x0, v239.y1 - v239.y0)
		local v240 = v_u_186
		local v241 = v_u_165.text
		v240.Position = UDim2.fromOffset(v241.x0, v241.y0)
		v240.Size = UDim2.fromOffset(v241.x1 - v241.x0, v241.y1 - v241.y0)
		local v242 = v_u_190
		local v243 = v_u_165.extra
		v242.Position = UDim2.fromOffset(v243.x0, v243.y0)
		v242.Size = UDim2.fromOffset(v243.x1 - v243.x0, v243.y1 - v243.y0)
		local v244 = v_u_191
		local v245 = v_u_165.dots
		v244.Position = UDim2.fromOffset(v245.x0, v245.y0)
		v244.Size = UDim2.fromOffset(v245.x1 - v245.x0, v245.y1 - v245.y0)
		local v246 = v_u_218
		local v247 = v_u_165.prev
		v246.Position = UDim2.fromOffset(v247.x0, v247.y0)
		v246.Size = UDim2.fromOffset(v247.x1 - v247.x0, v247.y1 - v247.y0)
		local v248 = v_u_225
		local v249 = v_u_165.next
		v248.Position = UDim2.fromOffset(v249.x0, v249.y0)
		v248.Size = UDim2.fromOffset(v249.x1 - v249.x0, v249.y1 - v249.y0)
		local v250 = v_u_227
		local v251 = v_u_165.close
		v250.Position = UDim2.fromOffset(v251.x0, v251.y0)
		v250.Size = UDim2.fromOffset(v251.x1 - v251.x0, v251.y1 - v251.y0)
		local v252 = v_u_165.dots.x1 - v_u_165.dots.x0
		local v253 = v_u_160
		local v254 = v252 / math.max(v253, 1)
		local v255 = math.min(26, v254)
		for v256, v257 in v_u_192 do
			v257.Position = UDim2.fromOffset(v252 / 2 + (v256 - (v_u_160 + 1) / 2) * v255, (v_u_165.dots.y1 - v_u_165.dots.y0) / 2)
		end
	end
	v_u_258()
	function v_u_161.relayout()
		-- upvalues: (ref) v_u_162, (copy) v_u_258, (ref) v_u_199
		if v_u_162 then
			v_u_258()
			v_u_199()
		end
	end
	local v_u_259 = ""
	v_u_199 = function() -- name: paint
		-- upvalues: (copy) v_u_156, (ref) v_u_163, (copy) v_u_154, (copy) v_u_181, (copy) v_u_186, (ref) v_u_4, (copy) v_u_158, (copy) v_u_190, (copy) v_u_159, (copy) v_u_180, (copy) v_u_160, (copy) v_u_192, (copy) v_u_157, (copy) v_u_219, (copy) v_u_226, (ref) v_u_259, (copy) v_u_155, (copy) v_u_178, (copy) v_u_177, (copy) v_u_173
		local v260 = v_u_156.HOWTO.pages[v_u_163]
		if type(v260) == "table" then
			v_u_154.setText(v_u_181, v260.title)
			v_u_186.Text = v_u_4.textOf(v_u_156, v_u_158, v_u_163)
			v_u_190.Text = v_u_4.extraOf(v_u_156, v_u_159, v_u_163)
			v_u_190.Visible = v_u_190.Text ~= ""
			v_u_180.Text = v_u_156.format(v_u_156.HOWTO.page, v_u_163, v_u_160)
			for v261, v262 in v_u_192 do
				local v263
				if v261 == v_u_163 then
					v263 = v_u_157.accent
				else
					v263 = v_u_157.line
				end
				v262.BackgroundColor3 = v263
				local v264
				if v261 == v_u_163 then
					v264 = UDim2.fromOffset(12, 12)
				else
					v264 = UDim2.fromOffset(9, 9)
				end
				v262.Size = v264
			end
			v_u_219.setEnabled(v_u_163 > 1)
			local v265 = v_u_226.setText
			local v266
			if v_u_160 <= v_u_163 then
				v266 = v_u_156.HOWTO.done
			else
				v266 = v_u_156.HOWTO.next
			end
			v265(v266)
			v_u_259 = v260.id
			local v267 = v_u_4.artId(v_u_156, v_u_163, v_u_155.isPhone())
			if v_u_178.Image ~= v267 then
				v_u_178.Image = v267
				v_u_178.ImageTransparency = (v267 == "" or not v_u_178.IsLoaded) and 0.98 or 0
			end
			v_u_178.Visible = v267 ~= ""
			v_u_177.Visible = false
			local v268 = v_u_173
			local v269 = v_u_178.Visible
			if v269 then
				v269 = v_u_178.ImageTransparency == 0
			end
			v268.Visible = not v269
		end
	end
	v_u_199()
	local v_u_270 = 0
	local v271 = v_u_3.Heartbeat
	local function v275(p272)
		-- upvalues: (copy) v_u_178, (copy) v_u_173, (ref) v_u_270, (ref) v_u_4, (copy) p_u_153, (copy) v_u_171, (ref) v_u_2, (copy) v_u_225, (copy) v_u_177
		if v_u_178.Visible and (v_u_178.ImageTransparency > 0 and v_u_178.IsLoaded) then
			v_u_178.ImageTransparency = 0
			v_u_173.Visible = false
		end
		v_u_270 = v_u_270 + p272
		if v_u_270 >= 0.2 then
			v_u_270 = 0
			if v_u_4.padFocus(p_u_153, v_u_171) then
				local function v273()
					-- upvalues: (ref) v_u_2, (ref) v_u_225
					v_u_2.SelectedObject = v_u_225
				end
				pcall(v273)
			end
			local v274 = v_u_178.Visible
			if v274 then
				v274 = v_u_178.ImageTransparency == 0
			end
			v_u_177.Visible = false
			v_u_173.Visible = not v274
		end
	end
	table.insert(v_u_164, v271:Connect(v275))
	task.spawn(function()
		-- upvalues: (copy) v_u_160, (ref) v_u_4, (copy) v_u_156, (copy) v_u_155
		local v_u_276 = {}
		for v277 = 1, v_u_160 do
			local v278 = v_u_4.artId(v_u_156, v277, v_u_155.isPhone())
			if v278 == "" then
				continue
			end
			table.insert(v_u_276, v278)
		end
		if #v_u_276 > 0 then
			pcall(function()
				-- upvalues: (copy) v_u_276
				game:GetService("ContentProvider"):PreloadAsync(v_u_276)
			end)
		end
	end)
	local v279 = v_u_4.padSource(p_u_153).InputBegan
	local function v294(p280, _)
		-- upvalues: (ref) v_u_162, (ref) v_u_4, (ref) v_u_163, (copy) v_u_160, (ref) v_u_199, (copy) p_u_153, (copy) v_u_198, (copy) v_u_154
		local v281 = p280.KeyCode
		if v281 == Enum.KeyCode.Left or v281 == Enum.KeyCode.DPadLeft then
			if not v_u_162 then
				return
			end
			local v282 = v_u_4.step(v_u_163, -1, v_u_160)
			if not v_u_162 then
				return
			end
			local v283 = v_u_4.clampPage(v282, v_u_160)
			if v283 == v_u_163 then
				return
			end
			v_u_163 = v283
			v_u_199()
			local v284 = p_u_153.onPage
			if type(v284) == "function" then
				local v285 = p_u_153.onPage
				local v286 = v_u_163
				pcall(v285, v286)
				return
			end
		elseif v281 == Enum.KeyCode.Right or v281 == Enum.KeyCode.DPadRight then
			if not v_u_162 then
				return
			end
			if v_u_160 <= v_u_163 then
				v_u_198()
				return
			end
			local v287 = v_u_4.step(v_u_163, 1, v_u_160)
			if not v_u_162 then
				return
			end
			local v288 = v_u_4.clampPage(v287, v_u_160)
			if v288 == v_u_163 then
				return
			end
			v_u_163 = v288
			v_u_199()
			local v289 = p_u_153.onPage
			if type(v289) == "function" then
				local v290 = p_u_153.onPage
				local v291 = v_u_163
				pcall(v290, v291)
				return
			end
		elseif v281 == Enum.KeyCode.ButtonB then
			local v292 = v_u_154.takeBack
			if type(v292) == "function" then
				local v293 = v_u_154.takeBack
				pcall(v293)
			end
			v_u_198()
		end
	end
	table.insert(v_u_164, v279:Connect(v294))
	local v_u_295 = nil
	local v296 = v_u_172.InputBegan
	local function v298(p297)
		-- upvalues: (ref) v_u_295
		if p297.UserInputType == Enum.UserInputType.Touch then
			v_u_295 = p297.Position.X
		end
	end
	table.insert(v_u_164, v296:Connect(v298))
	local v299 = v_u_172.InputEnded
	local function v307(p300)
		-- upvalues: (ref) v_u_295, (ref) v_u_4, (ref) v_u_162, (ref) v_u_163, (copy) v_u_160, (copy) v_u_198, (ref) v_u_199, (copy) p_u_153
		if p300.UserInputType == Enum.UserInputType.Touch and v_u_295 ~= nil then
			local v301 = v_u_4.swipeDir(p300.Position.X - v_u_295)
			v_u_295 = nil
			if v301 ~= 0 then
				if not v_u_162 then
					return
				end
				if v301 >= 0 and v_u_160 <= v_u_163 then
					v_u_198()
					return
				end
				local v302 = v_u_4.step(v_u_163, v301, v_u_160)
				if not v_u_162 then
					return
				end
				local v303 = v_u_4.clampPage(v302, v_u_160)
				if v303 == v_u_163 then
					return
				end
				v_u_163 = v303
				v_u_199()
				local v304 = p_u_153.onPage
				if type(v304) == "function" then
					local v305 = p_u_153.onPage
					local v306 = v_u_163
					pcall(v305, v306)
				end
			end
		end
	end
	table.insert(v_u_164, v299:Connect(v307))
	local v308 = v_u_170.Activated
	table.insert(v_u_164, v308:Connect(v_u_198))
	local v309 = v_u_155.scaleChanged
	table.insert(v_u_164, v309:Connect(function()
		-- upvalues: (copy) v_u_161
		task.defer(function()
			-- upvalues: (ref) v_u_161
			v_u_161.relayout()
		end)
	end))
	if p_u_153.blur == true then
		local _ = true
		local v310 = v_u_154.blur
		pcall(v310, true)
	end
	local v311 = v_u_154.device
	if type(v311) == "function" and v_u_154.device() == "Gamepad" then
		local function v312()
			-- upvalues: (ref) v_u_2, (copy) v_u_225
			v_u_2.SelectedObject = v_u_225
		end
		pcall(v312)
	end
	v_u_161.close = v_u_198
	function v_u_161.isOpen()
		-- upvalues: (ref) v_u_162
		return v_u_162
	end
	function v_u_161.page()
		-- upvalues: (ref) v_u_163
		return v_u_163
	end
	v_u_161.goto = v205
	v_u_161.flip = v212
	function v_u_161.rects()
		-- upvalues: (ref) v_u_165
		return v_u_165
	end
	function v_u_161.mode()
		-- upvalues: (ref) v_u_166
		return v_u_166
	end
	v_u_161.gui = v_u_168
	function v_u_161.buttons()
		-- upvalues: (copy) v_u_218, (copy) v_u_225, (copy) v_u_227, (copy) v_u_170
		return {
			["prev"] = v_u_218,
			["next"] = v_u_225,
			["close"] = v_u_227,
			["catcher"] = v_u_170
		}
	end
	function v_u_161.info()
		-- upvalues: (ref) v_u_163, (copy) v_u_160, (copy) v_u_181, (copy) v_u_186, (copy) v_u_190, (copy) v_u_178, (copy) v_u_177, (ref) v_u_166
		local v313 = {
			["page"] = v_u_163,
			["count"] = v_u_160,
			["title"] = v_u_181.Text,
			["text"] = v_u_186.Text,
			["extra"] = v_u_190.Text,
			["photo"] = v_u_178.Image
		}
		local v314 = v_u_178.Visible
		if v314 then
			v314 = v_u_178.ImageTransparency == 0
		end
		v313.photoShown = v314
		v313.signShapes = #v_u_177:GetChildren()
		v313.mode = v_u_166
		return v313
	end
	v_u_140 = v_u_161
	return v_u_161
end
return v_u_4