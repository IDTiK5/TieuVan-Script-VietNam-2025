-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuInputQueue

local v_u_1 = {
	["PAD"] = 12,
	["GAP"] = 8,
	["TITLE_H"] = 20,
	["LABEL"] = 15,
	["LABEL_LINE"] = 20,
	["NOTE"] = 12,
	["NOTE_LINE"] = 16,
	["SWITCH_W"] = 64,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74
}
local v_u_2 = game:GetService("ReplicatedStorage")
function v_u_1.textW(p3, p4, p5) -- name: textW
	-- upvalues: (copy) v_u_1
	local v6 = (utf8.len(p3) or #p3) * p4
	local v7
	if p5 == true then
		v7 = v_u_1.CHAR_CAPS
	else
		v7 = v_u_1.CHAR
	end
	local v8 = v6 * v7 + 2
	return math.ceil(v8)
end
function v_u_1.lines(p9, p10, p11) -- name: lines
	local v12 = (utf8.len(p9) or #p9) * p10 * 0.6
	local v13 = p11 * 0.92
	local v14 = v12 / math.max(40, v13)
	local v15 = math.ceil(v14)
	return math.max(1, v15)
end
function v_u_1.layout(p16, p17) -- name: layout
	-- upvalues: (copy) v_u_1
	local v_u_18 = v_u_1
	local v19 = p17.T
	local v_u_20 = v_u_18.PAD
	local v_u_21 = v_u_18.GAP
	local v_u_22 = p16 - 2 * v_u_20
	local v23 = p17.touchH
	local v_u_24 = type(v23) ~= "number" and 40 or p17.touchH
	local v25 = v_u_20
	local v26 = {
		["w"] = p16,
		["touchH"] = v_u_24,
		["title"] = {
			["x"] = v_u_20,
			["y"] = v25,
			["w"] = v_u_22,
			["h"] = v_u_18.TITLE_H
		}
	}
	local v27 = v25 + (v_u_18.TITLE_H + v_u_21)
	v26.chip = {
		["x"] = v_u_20,
		["y"] = v27,
		["w"] = v_u_22,
		["h"] = v_u_18.LABEL_LINE
	}
	local v28 = v27 + (v_u_18.LABEL_LINE + 2)
	local v29 = p17.line
	if type(v29) == "string" and p17.line ~= "" then
		local v30 = p17.line
		local v31 = v_u_18.NOTE
		local v32 = (utf8.len(v30) or #v30) * v31 * 0.6
		local v33 = v_u_22 * 0.92
		local v34 = v32 / math.max(40, v33)
		local v35 = math.ceil(v34)
		v26.line = {
			["x"] = v_u_20,
			["y"] = v28,
			["w"] = v_u_22,
			["h"] = math.max(1, v35) * v_u_18.NOTE_LINE
		}
		v28 = v28 + v26.line.h
	end
	local v_u_36 = v28 + v_u_21
	if p17.settings then
		local v_u_37 = v_u_22 - v_u_18.SWITCH_W - v_u_21
		local function v61(p38, p39, p40) -- name: row
			-- upvalues: (copy) v_u_18, (copy) v_u_37, (copy) v_u_24, (copy) v_u_20, (ref) v_u_36, (copy) v_u_22, (copy) v_u_21
			local v41 = v_u_18.LABEL
			local v42 = v_u_37
			local v43 = (utf8.len(p38) or #p38) * v41 * 0.6
			local v44 = v42 * 0.92
			local v45 = v43 / math.max(40, v44)
			local v46 = math.ceil(v45)
			local v47 = math.max(1, v46)
			local v48 = v_u_24
			local v49 = v47 * v_u_18.LABEL_LINE + 8
			local v50 = math.max(v48, v49)
			local v51 = {
				["label"] = {
					["x"] = v_u_20,
					["y"] = v_u_36,
					["w"] = v_u_37,
					["h"] = v50
				},
				["switch"] = {
					["x"] = v_u_20 + v_u_22 - v_u_18.SWITCH_W,
					["y"] = v_u_36,
					["w"] = v_u_18.SWITCH_W,
					["h"] = v50
				},
				["rowH"] = v50,
				["labelLines"] = v47
			}
			v_u_36 = v_u_36 + (v50 + 2)
			local v52 = v_u_20
			local v53 = v_u_36
			local v54 = v_u_22
			local v55 = v_u_18.NOTE
			local v56 = v_u_22
			local v57 = (utf8.len(p39) or #p39) * v55 * 0.6
			local v58 = v56 * 0.92
			local v59 = v57 / math.max(40, v58)
			local v60 = math.ceil(v59)
			v51.note = {
				["x"] = v52,
				["y"] = v53,
				["w"] = v54,
				["h"] = math.max(1, v60) * v_u_18.NOTE_LINE
			}
			v_u_36 = v_u_36 + v51.note.h
			if p40 then
				v_u_36 = v_u_36 + 2
				v51.mates = {
					["x"] = v_u_20,
					["y"] = v_u_36,
					["w"] = v_u_22,
					["h"] = v_u_18.NOTE_LINE
				}
				v_u_36 = v_u_36 + v_u_18.NOTE_LINE
			end
			v_u_36 = v_u_36 + v_u_21
			return v51
		end
		v26.allow = v61(v19.ALLOW, v19.ALLOW_NOTE, p17.mates == true)
		v26.direct = v61(v19.DIRECT, v19.DIRECT_NOTE, false)
	end
	if p17.sort then
		local v62 = v19.SORT_NOTE
		local v63 = v_u_18.NOTE
		local v64 = (utf8.len(v62) or #v62) * v63 * 0.6
		local v65 = v_u_22 * 0.92
		local v66 = v64 / math.max(40, v65)
		local v67 = math.ceil(v66)
		v26.sort = {
			["x"] = v_u_20,
			["y"] = v_u_36,
			["w"] = v_u_22,
			["h"] = math.max(1, v67) * v_u_18.NOTE_LINE
		}
		v_u_36 = v_u_36 + (v26.sort.h + v_u_21)
	end
	v_u_36 = v_u_36 + (v_u_20 - v_u_21)
	v26.h = v_u_36
	return v26
end
function v_u_1.squadLine(p68, p69) -- name: squadLine
	-- upvalues: (copy) v_u_2
	if type(p68) == "table" and p68.warn == true then
		local v70 = nil
		local function v71()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("InputQueueRules", 5)))
		end
		local v72, v73 = pcall(v71)
		if v72 then
			if type(v73) ~= "table" then
				v73 = v70
			end
		else
			v73 = v70
		end
		if v73 == nil then
			return p68.line
		elseif p69 == true then
			return v73.TEXT.MIXED_SHORT
		else
			return v73.TEXT.MIXED_WARN
		end
	else
		return nil
	end
end
function v_u_1.chipText(p74, p75, p76) -- name: chipText
	if type(p75) == "table" and (p75.pool == "kb" or p75.pool == "nonkb") then
		return p74 .. " (" .. (p75.pool == "nonkb" and (p76 == true and "TOUCH + PAD" or "TOUCH AND PAD") or "KB") .. ")"
	else
		return p74
	end
end
function v_u_1.showSettings(p77) -- name: showSettings
	local v78
	if type(p77) == "table" then
		v78 = p77.own == "nonkb"
	else
		v78 = false
	end
	return v78
end
local function v_u_85(p_u_79) -- name: rulesMod
	-- upvalues: (copy) v_u_2
	local v80, v81 = pcall(function()
		-- upvalues: (copy) p_u_79
		return p_u_79.cctx.shared.InputQueueRules
	end)
	if v80 and type(v81) == "table" then
		return v81
	else
		local function v82()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("InputQueueRules", 5)))
		end
		local v83, v84 = pcall(v82)
		if v83 and type(v84) == "table" then
			return v84
		else
			return nil
		end
	end
end
local function v_u_91(p_u_86) -- name: storeMod
	local v87, v88 = pcall(function()
		-- upvalues: (copy) p_u_86
		return p_u_86.cctx.lib.QueueOptionsStore
	end)
	if v87 and type(v88) == "table" then
		return v88
	else
		local v89, v90 = pcall(function()
			return require((script.Parent:WaitForChild("QueueOptionsStore", 5)))
		end)
		if v89 and type(v90) == "table" then
			return v90
		else
			return nil
		end
	end
end
function v_u_1.build(p_u_92, p93, p94) -- name: build
	-- upvalues: (copy) v_u_85, (copy) v_u_91, (copy) v_u_1
	local v_u_95 = p_u_92.ui
	local v_u_96 = p_u_92.theme
	local v_u_97 = v_u_96.color
	local v_u_98 = v_u_85(p_u_92)
	local v_u_99 = v_u_91(p_u_92)
	local v_u_100 = not v_u_98 and {} or v_u_98.TEXT
	local v_u_101
	if type(p94) == "table" then
		local v102 = p94.width
		v_u_101 = type(v102) ~= "number" and 360 or p94.width
	else
		v_u_101 = 360
	end
	local v_u_103
	if type(p94) == "table" then
		local v104 = p94.send
		v_u_103 = type(v104) ~= "function" and function(p106)
			-- upvalues: (copy) p_u_92
			p_u_92.partyOp(p106)
		end or p94.send
	else
		v_u_103 = function(p106)
			-- upvalues: (copy) p_u_92
			p_u_92.partyOp(p106)
		end
	end
	local v_u_107 = v_u_95.new("Frame", {
		["Name"] = "InputQueueOptions",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_97.raised,
		["Size"] = UDim2.fromOffset(v_u_101, 10),
		["LayoutOrder"] = (type(p94) ~= "table" or not p94.order) and 0 or p94.order
	}, p93)
	pcall(function()
		-- upvalues: (copy) v_u_95, (copy) v_u_107, (copy) v_u_97
		v_u_95.corner(v_u_107, 8)
		v_u_95.stroke(v_u_107, v_u_97.line)
	end)
	local v_u_108 = {}
	if v_u_99 == nil then
		warn("[MenuInputQueue] QueueOptionsStore is missing: the input queue panel stays hidden")
		function v_u_108.set() -- name: set end
		function v_u_108.lock() -- name: lock end
		function v_u_108.height() -- name: height
			return 0
		end
		function v_u_108.destroy() -- name: destroy
			-- upvalues: (copy) v_u_107
			v_u_107:Destroy()
		end
		return v_u_107, v_u_108
	end
	local v_u_109
	if type(p94) == "table" and p94.store ~= nil then
		v_u_109 = p94.store
	else
		v_u_109 = v_u_99.new()
	end
	v_u_108.store = v_u_109
	v_u_108.send = v_u_103
	local v_u_110 = ""
	local v_u_111 = 10
	local v_u_112 = nil
	local function v_u_173(p113) -- name: paint
		-- upvalues: (copy) v_u_107, (copy) v_u_98, (ref) v_u_111, (ref) v_u_1, (copy) v_u_101, (copy) v_u_100, (copy) v_u_96, (copy) v_u_95, (copy) v_u_97, (copy) v_u_109, (copy) v_u_103, (copy) v_u_108, (ref) v_u_112
		for _, v114 in v_u_107:GetChildren() do
			if v114:IsA("UICorner") or v114:IsA("UIStroke") then
				continue
			end
			v114:Destroy()
		end
		if p113 == nil or v_u_98 == nil then
			v_u_107.Visible = false
			v_u_111 = 0
		else
			local v115 = v_u_1.showSettings(p113)
			local v116 = v_u_1.layout
			local v117 = v_u_101
			local v118 = {
				["T"] = nil,
				["line"] = nil,
				["settings"] = nil,
				["mates"] = nil,
				["sort"] = true,
				["touchH"] = nil,
				["T"] = v_u_100,
				["line"] = p113.line,
				["settings"] = v115
			}
			if v115 then
				local v119 = p113.of
				v115 = (tonumber(v119) or 0) > 1
			end
			v118.mates = v115
			v118.touchH = v_u_96.touch(40)
			local v_u_120 = v116(v117, v118)
			local v121 = v_u_95.label
			local v122 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_107,
				["text"] = v_u_100.TITLE,
				["color"] = v_u_97.muted
			}
			local v123 = v_u_120.title
			v122.position = UDim2.fromOffset(v123.x, v123.y)
			local v124 = v_u_120.title
			v122.size = UDim2.fromOffset(v124.w, v124.h)
			v121(v122)
			local v125 = v_u_95.label
			local v126 = {
				["parent"] = nil,
				["name"] = "Chip",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_107,
				["text"] = v_u_98.chipOf(p113.pool)
			}
			local v127
			if p113.pool == "kb" then
				v127 = v_u_97.text
			else
				v127 = v_u_97.info
			end
			v126.color = v127
			local v128 = v_u_120.chip
			v126.position = UDim2.fromOffset(v128.x, v128.y)
			local v129 = v_u_120.chip
			v126.size = UDim2.fromOffset(v129.w, v129.h)
			v125(v126)
			if v_u_120.line then
				local v130 = v_u_95.label
				local v131 = {
					["parent"] = nil,
					["name"] = "Line",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_107,
					["text"] = p113.line
				}
				local v132
				if p113.warn then
					v132 = v_u_97.warn or v_u_97.text
				else
					v132 = v_u_97.text2
				end
				v131.color = v132
				local v133 = v_u_120.line
				v131.position = UDim2.fromOffset(v133.x, v133.y)
				local v134 = v_u_120.line
				v131.size = UDim2.fromOffset(v134.w, v134.h)
				v130(v131)
			end
			local function v159(p135, p136, p137, p138, p139, p_u_140) -- name: switchRow
				-- upvalues: (ref) v_u_95, (ref) v_u_107, (ref) v_u_97, (copy) v_u_120, (ref) v_u_109, (ref) v_u_100, (ref) v_u_103, (ref) v_u_108, (ref) v_u_112
				local v141 = v_u_95.label
				local v142 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_107,
					["name"] = p135 .. "Label",
					["text"] = p137,
					["color"] = v_u_97.text
				}
				local v143 = p136.label
				v142.position = UDim2.fromOffset(v143.x, v143.y)
				local v144 = p136.label
				v142.size = UDim2.fromOffset(v144.w, v144.h)
				v141(v142)
				local v145 = v_u_95.toggle
				local v146 = {
					["parent"] = nil,
					["name"] = nil,
					["label"] = "",
					["value"] = nil,
					["width"] = nil,
					["position"] = nil,
					["onChange"] = nil,
					["parent"] = v_u_107,
					["name"] = p135,
					["value"] = p139,
					["width"] = p136.switch.w
				}
				local v147 = UDim2.fromOffset
				local v148 = p136.switch.x
				local v149 = p136.switch.y
				local v150 = (p136.rowH - v_u_120.touchH) / 2
				v146.position = v147(v148, v149 + math.floor(v150))
				function v146.onChange(p151) -- name: onChange
					-- upvalues: (copy) p_u_140, (ref) v_u_109, (ref) v_u_95, (ref) v_u_100, (ref) v_u_103, (ref) v_u_108, (ref) v_u_112
					local v152 = {
						[p_u_140] = p151
					}
					local v153
					if v_u_109.locked() then
						v_u_95.toast(v_u_100.SEARCHING or "Locked while your squad is searching.", "warn")
						v153 = false
					else
						v152.op = "queuePrefs"
						v_u_103(v152)
						v153 = true
					end
					if v153 then
						local v154 = {
							[p_u_140] = p151
						}
						v_u_109.patchInput(v154, os.clock(), v_u_108)
					else
						v_u_112(true)
					end
				end
				v145(v146)
				local v155 = v_u_95.label
				local v156 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_107,
					["name"] = p135 .. "Note",
					["text"] = p138,
					["color"] = v_u_97.text2
				}
				local v157 = p136.note
				v156.position = UDim2.fromOffset(v157.x, v157.y)
				local v158 = p136.note
				v156.size = UDim2.fromOffset(v158.w, v158.h)
				v155(v156)
			end
			if v_u_120.allow then
				v159("Allow", v_u_120.allow, v_u_100.ALLOW, v_u_100.ALLOW_NOTE, p113.allowKb ~= false, "allowKb")
				if v_u_120.allow.mates then
					local v160 = v_u_95.label
					local v161 = {
						["parent"] = nil,
						["name"] = "AllowMates",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v_u_107
					}
					local v162 = string.format
					local v163 = v_u_100.MATES
					local v164 = p113.agree
					local v165 = tonumber(v164) or 0
					local v166 = p113.of
					v161.text = v162(v163, v165, tonumber(v166) or 0)
					v161.color = v_u_97.info
					local v167 = v_u_120.allow.mates
					v161.position = UDim2.fromOffset(v167.x, v167.y)
					local v168 = v_u_120.allow.mates
					v161.size = UDim2.fromOffset(v168.w, v168.h)
					v160(v161)
				end
			end
			if v_u_120.direct then
				v159("Direct", v_u_120.direct, v_u_100.DIRECT, v_u_100.DIRECT_NOTE, p113.kbDirect == true, "kbDirect")
			end
			if v_u_120.sort then
				local v169 = v_u_95.label
				local v170 = {
					["parent"] = nil,
					["name"] = "SortNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_107,
					["text"] = v_u_100.SORT_NOTE,
					["color"] = v_u_97.muted
				}
				local v171 = v_u_120.sort
				v170.position = UDim2.fromOffset(v171.x, v171.y)
				local v172 = v_u_120.sort
				v170.size = UDim2.fromOffset(v172.w, v172.h)
				v169(v170)
			end
			v_u_111 = v_u_120.h
			v_u_107.Size = UDim2.fromOffset(v_u_101, v_u_120.h)
			v_u_107.Visible = true
		end
	end
	local v_u_174
	if type(p94) == "table" then
		v_u_174 = p94.keepFocus == true
	else
		v_u_174 = false
	end
	v_u_112 = function(p175) -- name: render
		-- upvalues: (copy) v_u_109, (copy) v_u_98, (copy) v_u_99, (ref) v_u_110, (copy) v_u_174, (copy) v_u_95, (copy) v_u_107, (copy) v_u_173
		local v176 = v_u_109.input()
		if type(v176) ~= "table" or (v_u_98 == nil or v176.pool ~= "kb" and v176.pool ~= "nonkb") then
			v176 = nil
		end
		local v177
		if v176 == nil then
			v177 = "hidden"
		else
			local v178 = v_u_99.inputSig(v176)
			local v179 = v_u_109.locked
			v177 = v178 .. "|" .. tostring(v179())
		end
		if p175 == true or v177 ~= v_u_110 then
			v_u_110 = v177
			local v_u_180 = v_u_109.input()
			if type(v_u_180) ~= "table" or (v_u_98 == nil or v_u_180.pool ~= "kb" and v_u_180.pool ~= "nonkb") then
				v_u_180 = nil
			end
			local v_u_181 = false
			if v_u_174 then
				local v182 = v_u_95.keepScroll
				if type(v182) == "function" then
					local v183 = v_u_95.keepScroll
					local v184 = v_u_107
					local function v185()
						-- upvalues: (ref) v_u_181, (ref) v_u_173, (copy) v_u_180
						v_u_181 = true
						v_u_173(v_u_180)
					end
					local v186, v187 = pcall(v183, v184, v185)
					if not v186 and v_u_181 then
						warn("[MenuInputQueue] redraw failed:", v187)
					end
				end
			end
			if not v_u_181 then
				v_u_173(v_u_180)
			end
		end
	end
	local v_u_188 = nil
	v_u_188 = v_u_109.subscribe(function(_, p189)
		-- upvalues: (copy) v_u_107, (ref) v_u_188, (copy) v_u_108, (ref) v_u_110, (copy) v_u_109, (copy) v_u_98, (copy) v_u_99, (ref) v_u_112
		if v_u_107.Parent == nil then
			v_u_188()
			return
		elseif p189 == v_u_108 then
			local v190 = v_u_109.input()
			if type(v190) ~= "table" or (v_u_98 == nil or v190.pool ~= "kb" and v190.pool ~= "nonkb") then
				v190 = nil
			end
			local v191
			if v190 == nil then
				v191 = "hidden"
			else
				local v192 = v_u_99.inputSig(v190)
				local v193 = v_u_109.locked
				v191 = v192 .. "|" .. tostring(v193())
			end
			v_u_110 = v191
		else
			v_u_112(false)
		end
	end)
	function v_u_108.set(p194) -- name: set
		-- upvalues: (copy) v_u_109, (ref) v_u_112
		v_u_109.setInput(p194, os.clock())
		v_u_112(false)
	end
	function v_u_108.lock(p195) -- name: lock
		-- upvalues: (copy) v_u_109, (ref) v_u_112
		v_u_109.setLocked(p195 == true)
		v_u_112(false)
	end
	function v_u_108.height() -- name: height
		-- upvalues: (ref) v_u_111
		return v_u_111
	end
	function v_u_108.destroy() -- name: destroy
		-- upvalues: (ref) v_u_188, (copy) v_u_107
		v_u_188()
		v_u_107:Destroy()
	end
	v_u_112(false)
	return v_u_107, v_u_108
end
return v_u_1