-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanManage

local v_u_1 = game:GetService("Players")
local v_u_425 = {
	["sections"] = function(p2, p3) -- name: sections
		local v4 = {}
		if p2.can(p3, "handleRequests") then
			table.insert(v4, {
				["id"] = "requests",
				["text"] = "Requests"
			})
		end
		if p2.can(p3, "invite") then
			table.insert(v4, {
				["id"] = "invite",
				["text"] = "Invite"
			})
		end
		if p2.can(p3, "editSettings") then
			table.insert(v4, {
				["id"] = "settings",
				["text"] = "Settings"
			})
		end
		if type(p3) == "table" and p3.rank == "owner" then
			table.insert(v4, {
				["id"] = "ranks",
				["text"] = "Ranks"
			})
			table.insert(v4, {
				["id"] = "leader",
				["text"] = "Leadership"
			})
			table.insert(v4, {
				["id"] = "disband",
				["text"] = "Disband"
			})
		end
		return v4
	end,
	["mount"] = function(p_u_5, p6) -- name: mount
		-- upvalues: (copy) v_u_1, (copy) v_u_425
		local v_u_7 = p_u_5.UI
		local v_u_8 = p_u_5.Theme
		local v_u_9 = p_u_5.C
		local v_u_10 = p_u_5.Kit
		local v_u_11 = p_u_5.U
		local v_u_12 = p_u_5.M
		local v_u_13 = p_u_5.m
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = nil
		local v_u_17 = v_u_11.frame(p6, "SecTabsHolder", UDim2.new(1, 0, 0, v_u_8.touch(40)))
		local v_u_18 = nil
		local v_u_19 = ""
		local v_u_20 = v_u_11.status(p6, {
			["name"] = "Msg",
			["text"] = "",
			["style"] = "small",
			["size"] = nil,
			["position"] = nil,
			["visible"] = false,
			["size"] = UDim2.new(1, 0, 0, 20),
			["position"] = UDim2.fromOffset(0, v_u_8.touch(40) + 4)
		})
		local v21 = v_u_8.touch(40) + 28
		local v_u_22 = v_u_11.frame(p6, "SecBody", UDim2.new(1, 0, 1, -v21), UDim2.fromOffset(0, v21))
		local v_u_23 = p_u_5.lib("MenuClanForm")
		local function v_u_32(p24, p25, p26, p27, p28) -- name: resultText
			-- upvalues: (copy) v_u_12
			local v29
			if type(p26) == "table" then
				v29 = p26.results
			else
				v29 = nil
			end
			if type(v29) == "table" then
				for _, v30 in v29 do
					if type(v30) ~= "table" or v30.ok == true then
						continue
					end
					local v31 = v30.code
					if type(v31) ~= "string" then
						continue
					end
					if p28 == "requests" then
						return v_u_12.answerText(v30.code)
					else
						return v_u_12.text(v30.code)
					end
				end
			end
			if p24 then
				return nil
			else
				return v_u_12.reasonFor(p27 or {
					["msg"] = p25,
					["data"] = p26
				})
			end
		end
		local v_u_33 = nil
		local v_u_408 = {
			["requests"] = function() -- name: drawRequests
				-- upvalues: (copy) v_u_7, (copy) v_u_22, (copy) v_u_20, (copy) p_u_5, (ref) v_u_15, (copy) v_u_32, (copy) v_u_14, (copy) v_u_10, (copy) v_u_11, (copy) v_u_13, (copy) v_u_12, (copy) v_u_8, (ref) v_u_33, (copy) v_u_9, (ref) v_u_16
				local v_u_34 = v_u_7.list({
					["parent"] = nil,
					["name"] = "List",
					["size"] = nil,
					["gap"] = 2,
					["padding"] = nil,
					["parent"] = v_u_22,
					["size"] = UDim2.fromScale(1, 1),
					["padding"] = {
						0,
						6,
						0,
						8
					}
				})
				local v_u_35 = {}
				local v_u_36 = {}
				local v_u_37 = false
				local function v_u_48(p38, p_u_39) -- name: answerOp
					-- upvalues: (ref) v_u_37, (ref) v_u_20, (ref) p_u_5, (ref) v_u_15, (ref) v_u_32, (ref) v_u_14
					if not v_u_37 and #p38 ~= 0 then
						v_u_37 = true
						for _, v40 in p_u_39 do
							v40.busy(true, "...")
						end
						v_u_20.set("", nil)
						p_u_5.send("clanAnswer", {
							["answers"] = p38
						}, function(p41, p42, p43, p44)
							-- upvalues: (ref) v_u_37, (ref) v_u_15, (copy) p_u_39, (ref) v_u_32, (ref) v_u_20, (ref) v_u_14
							v_u_37 = false
							if v_u_15 then
								for _, v45 in p_u_39 do
									local v46 = v45.busy
									pcall(v46, false)
								end
								local v47 = v_u_32(p41, p42, p43, p44, "requests")
								if v47 then
									v_u_20.set(v47, p41 and "warn" or "danger")
								end
								v_u_14.loadRequests()
							end
						end, 25)
					end
				end
				function v_u_14.loadRequests() -- name: loadRequests
					-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) v_u_34, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (copy) v_u_48, (ref) v_u_36, (ref) v_u_33, (ref) p_u_5, (ref) v_u_9
					if v_u_15 and v_u_16 == "requests" then
						if v_u_15 and v_u_34.Parent then
							local v_u_49 = "loading"
							v_u_7.keepScroll(v_u_34, function()
								-- upvalues: (ref) v_u_10, (ref) v_u_34, (copy) v_u_49, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (ref) v_u_48, (ref) v_u_36, (ref) v_u_33, (ref) p_u_5, (ref) v_u_7, (ref) v_u_9
								v_u_10.clear(v_u_34)
								if v_u_49 == "loading" then
									v_u_11.skeleton(v_u_34, 3, v_u_13.rowH)
									return
								elseif v_u_49 == "failed" then
									v_u_10.empty(v_u_34, v_u_12.UI.LOAD_FAIL, 1)
									local v50 = {
										["parent"] = nil,
										["text"] = "RETRY",
										["kind"] = "secondary",
										["width"] = 140,
										["order"] = 2,
										["name"] = "Retry",
										["onClick"] = nil,
										["parent"] = v_u_34,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) v_u_14
											v_u_14.loadRequests()
										end
									}
									v_u_11.btn(v50)
									return
								elseif #v_u_35 == 0 then
									v_u_10.empty(v_u_34, v_u_12.UI.NO_REQUESTS, 1)
								else
									local v_u_51 = {}
									for _, v52 in v_u_35 do
										if v52.fits == false or #v_u_51 >= 10 then
											continue
										end
										local v53 = {
											["uid"] = nil,
											["accept"] = true
										}
										local v54 = v52.uid
										v53.uid = tostring(v54)
										table.insert(v_u_51, v53)
									end
									local v_u_55 = nil
									local v56 = v_u_11.frame(v_u_34, "AllHolder", UDim2.new(1, -6, 0, v_u_8.touch(44)), nil, 0)
									local _, v57 = v_u_11.btn({
										["parent"] = nil,
										["text"] = nil,
										["kind"] = "primary",
										["width"] = 240,
										["name"] = "AcceptFitting",
										["disabled"] = nil,
										["onClick"] = nil,
										["parent"] = v56,
										["text"] = ("ACCEPT FITTING (%d)"):format(#v_u_51),
										["disabled"] = #v_u_51 == 0,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) v_u_48, (copy) v_u_51, (ref) v_u_55
											v_u_48(v_u_51, { v_u_55 })
										end
									})
									local _ = v57
									if v_u_36.slots then
										if v_u_33 == nil then
											v_u_33 = p_u_5.lib("MenuClanLayout")
										end
										local v58 = v_u_33.invRow(v_u_13)
										v_u_7.label({
											["parent"] = nil,
											["name"] = "Slots",
											["text"] = nil,
											["style"] = "bodyStrong",
											["position"] = nil,
											["size"] = nil,
											["track"] = false,
											["parent"] = v56,
											["text"] = v_u_36.slots,
											["position"] = UDim2.fromOffset(v58.slotsX, 2),
											["size"] = UDim2.fromOffset(v58.slotsW, 20)
										})
										if v_u_36.okHead then
											v_u_7.label({
												["parent"] = nil,
												["name"] = "OkHead",
												["text"] = nil,
												["style"] = "micro",
												["color"] = nil,
												["position"] = nil,
												["size"] = nil,
												["track"] = false,
												["parent"] = v56,
												["text"] = v_u_36.okHead,
												["color"] = v_u_9.text2,
												["position"] = UDim2.fromOffset(v58.slotsX, 24),
												["size"] = UDim2.fromOffset(v58.slotsW, 16)
											})
										end
									end
									for v59, v60 in v_u_35 do
										local v61 = v_u_11.row(v_u_34, v59, v_u_13.rowH, false)
										local v62 = v_u_13.kind == "phone" and 96 or 110
										local v63 = v_u_13.inner - 6 - 12 - v62 * 2 - 20
										local v64 = v_u_7.label
										local v65 = {
											["parent"] = nil,
											["name"] = "Name",
											["text"] = nil,
											["style"] = "bodyStrong",
											["position"] = nil,
											["size"] = nil,
											["parent"] = v61
										}
										local v66 = v60.name or "?"
										v65.text = tostring(v66)
										v65.position = UDim2.fromOffset(12, 3)
										v65.size = UDim2.fromOffset(math.max(60, v63), 22)
										v64(v65)
										local v67 = v60.raids
										local v68 = tonumber(v67) or 0
										local v69 = v60.pct
										local v70 = ("%d raids, %d%%"):format(v68, tonumber(v69) or 0)
										local v71 = v_u_7.label
										local v72 = {
											["parent"] = nil,
											["name"] = "Sub",
											["text"] = nil,
											["style"] = "micro",
											["color"] = nil,
											["position"] = nil,
											["size"] = nil,
											["track"] = false,
											["parent"] = v61,
											["text"] = v70 .. (v60.fits == false and "  below the requirements" or "")
										}
										local v73
										if v60.fits == false then
											v73 = v_u_9.danger
										else
											v73 = v_u_9.text2
										end
										v72.color = v73
										v72.position = UDim2.fromOffset(12, 25)
										v72.size = UDim2.fromOffset(math.max(60, v63), 16)
										v71(v72)
										local v_u_74 = {}
										local v75 = v60.uid
										local v_u_76 = tostring(v75)
										local _, v77 = v_u_11.btn({
											["parent"] = nil,
											["text"] = "ACCEPT",
											["kind"] = "primary",
											["width"] = nil,
											["height"] = nil,
											["name"] = "Accept",
											["position"] = nil,
											["onClick"] = nil,
											["parent"] = v61,
											["width"] = v62,
											["height"] = v_u_13.rowH,
											["position"] = UDim2.new(1, -(v62 * 2 + 12), 0, 0),
											["onClick"] = function() -- name: onClick
												-- upvalues: (ref) v_u_48, (copy) v_u_76, (copy) v_u_74
												v_u_48({
													{
														["uid"] = nil,
														["accept"] = true,
														["uid"] = v_u_76
													}
												}, v_u_74)
											end
										})
										local _, v78 = v_u_11.btn({
											["parent"] = nil,
											["text"] = "DECLINE",
											["kind"] = "secondary",
											["width"] = nil,
											["height"] = nil,
											["name"] = "Decline",
											["position"] = nil,
											["onClick"] = nil,
											["parent"] = v61,
											["width"] = v62,
											["height"] = v_u_13.rowH,
											["position"] = UDim2.new(1, -(v62 + 6), 0, 0),
											["onClick"] = function() -- name: onClick
												-- upvalues: (ref) v_u_48, (copy) v_u_76, (copy) v_u_74
												v_u_48({
													{
														["uid"] = nil,
														["accept"] = false,
														["uid"] = v_u_76
													}
												}, v_u_74)
											end
										})
										v_u_74[1] = v77
										v_u_74[2] = v78
									end
								end
							end)
						end
						task.spawn(function()
							-- upvalues: (ref) p_u_5, (ref) v_u_15, (ref) v_u_16, (ref) v_u_34, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (ref) v_u_48, (ref) v_u_36, (ref) v_u_33, (ref) v_u_9
							local v79 = p_u_5.fetch("clanRequests", nil, 0)
							if v_u_15 and v_u_16 == "requests" then
								if v79 ~= nil then
									local v80 = v79.rows
									if type(v80) == "table" then
										v_u_35 = {}
										for _, v81 in v79.rows do
											if type(v81) ~= "table" or v81.uid == nil then
												continue
											end
											local v82 = v_u_35
											table.insert(v82, v81)
										end
										v_u_36 = v_u_12.invSummary(v79)
										if v_u_15 then
											if not v_u_34.Parent then
												return
											end
											local v_u_83 = nil
											v_u_7.keepScroll(v_u_34, function()
												-- upvalues: (ref) v_u_10, (ref) v_u_34, (copy) v_u_83, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (ref) v_u_48, (ref) v_u_36, (ref) v_u_33, (ref) p_u_5, (ref) v_u_7, (ref) v_u_9
												v_u_10.clear(v_u_34)
												if v_u_83 == "loading" then
													v_u_11.skeleton(v_u_34, 3, v_u_13.rowH)
													return
												elseif v_u_83 == "failed" then
													v_u_10.empty(v_u_34, v_u_12.UI.LOAD_FAIL, 1)
													local v84 = {
														["parent"] = nil,
														["text"] = "RETRY",
														["kind"] = "secondary",
														["width"] = 140,
														["order"] = 2,
														["name"] = "Retry",
														["onClick"] = nil,
														["parent"] = v_u_34,
														["onClick"] = function() -- name: onClick
															-- upvalues: (ref) v_u_14
															v_u_14.loadRequests()
														end
													}
													v_u_11.btn(v84)
													return
												elseif #v_u_35 == 0 then
													v_u_10.empty(v_u_34, v_u_12.UI.NO_REQUESTS, 1)
												else
													local v_u_85 = {}
													for _, v86 in v_u_35 do
														if v86.fits == false or #v_u_85 >= 10 then
															continue
														end
														local v87 = {
															["uid"] = nil,
															["accept"] = true
														}
														local v88 = v86.uid
														v87.uid = tostring(v88)
														table.insert(v_u_85, v87)
													end
													local v_u_89 = nil
													local v90 = v_u_11.frame(v_u_34, "AllHolder", UDim2.new(1, -6, 0, v_u_8.touch(44)), nil, 0)
													local _, v91 = v_u_11.btn({
														["parent"] = nil,
														["text"] = nil,
														["kind"] = "primary",
														["width"] = 240,
														["name"] = "AcceptFitting",
														["disabled"] = nil,
														["onClick"] = nil,
														["parent"] = v90,
														["text"] = ("ACCEPT FITTING (%d)"):format(#v_u_85),
														["disabled"] = #v_u_85 == 0,
														["onClick"] = function() -- name: onClick
															-- upvalues: (ref) v_u_48, (copy) v_u_85, (ref) v_u_89
															v_u_48(v_u_85, { v_u_89 })
														end
													})
													local _ = v91
													if v_u_36.slots then
														if v_u_33 == nil then
															v_u_33 = p_u_5.lib("MenuClanLayout")
														end
														local v92 = v_u_33.invRow(v_u_13)
														v_u_7.label({
															["parent"] = nil,
															["name"] = "Slots",
															["text"] = nil,
															["style"] = "bodyStrong",
															["position"] = nil,
															["size"] = nil,
															["track"] = false,
															["parent"] = v90,
															["text"] = v_u_36.slots,
															["position"] = UDim2.fromOffset(v92.slotsX, 2),
															["size"] = UDim2.fromOffset(v92.slotsW, 20)
														})
														if v_u_36.okHead then
															v_u_7.label({
																["parent"] = nil,
																["name"] = "OkHead",
																["text"] = nil,
																["style"] = "micro",
																["color"] = nil,
																["position"] = nil,
																["size"] = nil,
																["track"] = false,
																["parent"] = v90,
																["text"] = v_u_36.okHead,
																["color"] = v_u_9.text2,
																["position"] = UDim2.fromOffset(v92.slotsX, 24),
																["size"] = UDim2.fromOffset(v92.slotsW, 16)
															})
														end
													end
													for v93, v94 in v_u_35 do
														local v95 = v_u_11.row(v_u_34, v93, v_u_13.rowH, false)
														local v96 = v_u_13.kind == "phone" and 96 or 110
														local v97 = v_u_13.inner - 6 - 12 - v96 * 2 - 20
														local v98 = v_u_7.label
														local v99 = {
															["parent"] = nil,
															["name"] = "Name",
															["text"] = nil,
															["style"] = "bodyStrong",
															["position"] = nil,
															["size"] = nil,
															["parent"] = v95
														}
														local v100 = v94.name or "?"
														v99.text = tostring(v100)
														v99.position = UDim2.fromOffset(12, 3)
														v99.size = UDim2.fromOffset(math.max(60, v97), 22)
														v98(v99)
														local v101 = v94.raids
														local v102 = tonumber(v101) or 0
														local v103 = v94.pct
														local v104 = ("%d raids, %d%%"):format(v102, tonumber(v103) or 0)
														local v105 = v_u_7.label
														local v106 = {
															["parent"] = nil,
															["name"] = "Sub",
															["text"] = nil,
															["style"] = "micro",
															["color"] = nil,
															["position"] = nil,
															["size"] = nil,
															["track"] = false,
															["parent"] = v95,
															["text"] = v104 .. (v94.fits == false and "  below the requirements" or "")
														}
														local v107
														if v94.fits == false then
															v107 = v_u_9.danger
														else
															v107 = v_u_9.text2
														end
														v106.color = v107
														v106.position = UDim2.fromOffset(12, 25)
														v106.size = UDim2.fromOffset(math.max(60, v97), 16)
														v105(v106)
														local v_u_108 = {}
														local v109 = v94.uid
														local v_u_110 = tostring(v109)
														local _, v111 = v_u_11.btn({
															["parent"] = nil,
															["text"] = "ACCEPT",
															["kind"] = "primary",
															["width"] = nil,
															["height"] = nil,
															["name"] = "Accept",
															["position"] = nil,
															["onClick"] = nil,
															["parent"] = v95,
															["width"] = v96,
															["height"] = v_u_13.rowH,
															["position"] = UDim2.new(1, -(v96 * 2 + 12), 0, 0),
															["onClick"] = function() -- name: onClick
																-- upvalues: (ref) v_u_48, (copy) v_u_110, (copy) v_u_108
																v_u_48({
																	{
																		["uid"] = nil,
																		["accept"] = true,
																		["uid"] = v_u_110
																	}
																}, v_u_108)
															end
														})
														local _, v112 = v_u_11.btn({
															["parent"] = nil,
															["text"] = "DECLINE",
															["kind"] = "secondary",
															["width"] = nil,
															["height"] = nil,
															["name"] = "Decline",
															["position"] = nil,
															["onClick"] = nil,
															["parent"] = v95,
															["width"] = v96,
															["height"] = v_u_13.rowH,
															["position"] = UDim2.new(1, -(v96 + 6), 0, 0),
															["onClick"] = function() -- name: onClick
																-- upvalues: (ref) v_u_48, (copy) v_u_110, (copy) v_u_108
																v_u_48({
																	{
																		["uid"] = nil,
																		["accept"] = false,
																		["uid"] = v_u_110
																	}
																}, v_u_108)
															end
														})
														v_u_108[1] = v111
														v_u_108[2] = v112
													end
												end
											end)
										end
										return
									end
								end
								if v_u_15 then
									if not v_u_34.Parent then
										return
									end
									local v_u_113 = "failed"
									v_u_7.keepScroll(v_u_34, function()
										-- upvalues: (ref) v_u_10, (ref) v_u_34, (copy) v_u_113, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (ref) v_u_48, (ref) v_u_36, (ref) v_u_33, (ref) p_u_5, (ref) v_u_7, (ref) v_u_9
										v_u_10.clear(v_u_34)
										if v_u_113 == "loading" then
											v_u_11.skeleton(v_u_34, 3, v_u_13.rowH)
											return
										elseif v_u_113 == "failed" then
											v_u_10.empty(v_u_34, v_u_12.UI.LOAD_FAIL, 1)
											local v114 = {
												["parent"] = nil,
												["text"] = "RETRY",
												["kind"] = "secondary",
												["width"] = 140,
												["order"] = 2,
												["name"] = "Retry",
												["onClick"] = nil,
												["parent"] = v_u_34,
												["onClick"] = function() -- name: onClick
													-- upvalues: (ref) v_u_14
													v_u_14.loadRequests()
												end
											}
											v_u_11.btn(v114)
											return
										elseif #v_u_35 == 0 then
											v_u_10.empty(v_u_34, v_u_12.UI.NO_REQUESTS, 1)
										else
											local v_u_115 = {}
											for _, v116 in v_u_35 do
												if v116.fits == false or #v_u_115 >= 10 then
													continue
												end
												local v117 = {
													["uid"] = nil,
													["accept"] = true
												}
												local v118 = v116.uid
												v117.uid = tostring(v118)
												table.insert(v_u_115, v117)
											end
											local v_u_119 = nil
											local v120 = v_u_11.frame(v_u_34, "AllHolder", UDim2.new(1, -6, 0, v_u_8.touch(44)), nil, 0)
											local _, v121 = v_u_11.btn({
												["parent"] = nil,
												["text"] = nil,
												["kind"] = "primary",
												["width"] = 240,
												["name"] = "AcceptFitting",
												["disabled"] = nil,
												["onClick"] = nil,
												["parent"] = v120,
												["text"] = ("ACCEPT FITTING (%d)"):format(#v_u_115),
												["disabled"] = #v_u_115 == 0,
												["onClick"] = function() -- name: onClick
													-- upvalues: (ref) v_u_48, (copy) v_u_115, (ref) v_u_119
													v_u_48(v_u_115, { v_u_119 })
												end
											})
											local _ = v121
											if v_u_36.slots then
												if v_u_33 == nil then
													v_u_33 = p_u_5.lib("MenuClanLayout")
												end
												local v122 = v_u_33.invRow(v_u_13)
												v_u_7.label({
													["parent"] = nil,
													["name"] = "Slots",
													["text"] = nil,
													["style"] = "bodyStrong",
													["position"] = nil,
													["size"] = nil,
													["track"] = false,
													["parent"] = v120,
													["text"] = v_u_36.slots,
													["position"] = UDim2.fromOffset(v122.slotsX, 2),
													["size"] = UDim2.fromOffset(v122.slotsW, 20)
												})
												if v_u_36.okHead then
													v_u_7.label({
														["parent"] = nil,
														["name"] = "OkHead",
														["text"] = nil,
														["style"] = "micro",
														["color"] = nil,
														["position"] = nil,
														["size"] = nil,
														["track"] = false,
														["parent"] = v120,
														["text"] = v_u_36.okHead,
														["color"] = v_u_9.text2,
														["position"] = UDim2.fromOffset(v122.slotsX, 24),
														["size"] = UDim2.fromOffset(v122.slotsW, 16)
													})
												end
											end
											for v123, v124 in v_u_35 do
												local v125 = v_u_11.row(v_u_34, v123, v_u_13.rowH, false)
												local v126 = v_u_13.kind == "phone" and 96 or 110
												local v127 = v_u_13.inner - 6 - 12 - v126 * 2 - 20
												local v128 = v_u_7.label
												local v129 = {
													["parent"] = nil,
													["name"] = "Name",
													["text"] = nil,
													["style"] = "bodyStrong",
													["position"] = nil,
													["size"] = nil,
													["parent"] = v125
												}
												local v130 = v124.name or "?"
												v129.text = tostring(v130)
												v129.position = UDim2.fromOffset(12, 3)
												v129.size = UDim2.fromOffset(math.max(60, v127), 22)
												v128(v129)
												local v131 = v124.raids
												local v132 = tonumber(v131) or 0
												local v133 = v124.pct
												local v134 = ("%d raids, %d%%"):format(v132, tonumber(v133) or 0)
												local v135 = v_u_7.label
												local v136 = {
													["parent"] = nil,
													["name"] = "Sub",
													["text"] = nil,
													["style"] = "micro",
													["color"] = nil,
													["position"] = nil,
													["size"] = nil,
													["track"] = false,
													["parent"] = v125,
													["text"] = v134 .. (v124.fits == false and "  below the requirements" or "")
												}
												local v137
												if v124.fits == false then
													v137 = v_u_9.danger
												else
													v137 = v_u_9.text2
												end
												v136.color = v137
												v136.position = UDim2.fromOffset(12, 25)
												v136.size = UDim2.fromOffset(math.max(60, v127), 16)
												v135(v136)
												local v_u_138 = {}
												local v139 = v124.uid
												local v_u_140 = tostring(v139)
												local _, v141 = v_u_11.btn({
													["parent"] = nil,
													["text"] = "ACCEPT",
													["kind"] = "primary",
													["width"] = nil,
													["height"] = nil,
													["name"] = "Accept",
													["position"] = nil,
													["onClick"] = nil,
													["parent"] = v125,
													["width"] = v126,
													["height"] = v_u_13.rowH,
													["position"] = UDim2.new(1, -(v126 * 2 + 12), 0, 0),
													["onClick"] = function() -- name: onClick
														-- upvalues: (ref) v_u_48, (copy) v_u_140, (copy) v_u_138
														v_u_48({
															{
																["uid"] = nil,
																["accept"] = true,
																["uid"] = v_u_140
															}
														}, v_u_138)
													end
												})
												local _, v142 = v_u_11.btn({
													["parent"] = nil,
													["text"] = "DECLINE",
													["kind"] = "secondary",
													["width"] = nil,
													["height"] = nil,
													["name"] = "Decline",
													["position"] = nil,
													["onClick"] = nil,
													["parent"] = v125,
													["width"] = v126,
													["height"] = v_u_13.rowH,
													["position"] = UDim2.new(1, -(v126 + 6), 0, 0),
													["onClick"] = function() -- name: onClick
														-- upvalues: (ref) v_u_48, (copy) v_u_140, (copy) v_u_138
														v_u_48({
															{
																["uid"] = nil,
																["accept"] = false,
																["uid"] = v_u_140
															}
														}, v_u_138)
													end
												})
												v_u_138[1] = v141
												v_u_138[2] = v142
											end
										end
									end)
								end
							end
						end)
					end
				end
				v_u_14.loadRequests()
			end,
			["invite"] = function() -- name: drawInvite
				-- upvalues: (copy) v_u_7, (copy) v_u_22, (copy) v_u_20, (copy) p_u_5, (ref) v_u_15, (copy) v_u_32, (copy) v_u_12, (ref) v_u_33, (copy) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_10, (ref) v_u_16, (copy) v_u_8, (ref) v_u_1
				local v_u_143 = v_u_7.list({
					["parent"] = nil,
					["name"] = "List",
					["size"] = nil,
					["gap"] = 6,
					["padding"] = nil,
					["parent"] = v_u_22,
					["size"] = UDim2.fromScale(1, 1),
					["padding"] = {
						0,
						6,
						0,
						8
					}
				})
				local v_u_144 = false
				local v_u_145 = {}
				local v_u_146 = nil
				local function v_u_155(p147, p_u_148) -- name: invite
					-- upvalues: (ref) v_u_144, (ref) v_u_20, (ref) p_u_5, (ref) v_u_15, (ref) v_u_32, (ref) v_u_146
					if not v_u_144 then
						v_u_144 = true
						if p_u_148 then
							p_u_148.busy(true, "...")
						end
						v_u_20.set("", nil)
						p_u_5.send("clanInvite", {
							["targets"] = { p147 }
						}, function(p149, p150, p151, p152)
							-- upvalues: (ref) v_u_144, (ref) v_u_15, (copy) p_u_148, (ref) v_u_32, (ref) v_u_20, (ref) v_u_146
							v_u_144 = false
							if v_u_15 then
								if p_u_148 then
									local v153 = p_u_148.busy
									pcall(v153, false)
								end
								local v154 = v_u_32(p149, p150, p151, p152)
								if v154 then
									v_u_20.set(v154, "danger")
								else
									v_u_20.set("Invitation sent.", "success")
								end
								v_u_146()
							end
						end, 25)
					end
				end
				local function v_u_167(p156, p_u_157) -- name: cancelOp
					-- upvalues: (ref) v_u_144, (ref) v_u_20, (ref) p_u_5, (ref) v_u_15, (ref) v_u_32, (ref) v_u_12, (ref) v_u_146
					if not v_u_144 and #p156 ~= 0 then
						v_u_144 = true
						for _, v158 in p_u_157 do
							v158.busy(true, "...")
						end
						v_u_20.set("", nil)
						p_u_5.send("clanInvite", {
							["cancel"] = p156
						}, function(p159, p160, p161, p162)
							-- upvalues: (ref) v_u_144, (ref) v_u_15, (copy) p_u_157, (ref) v_u_32, (ref) v_u_12, (ref) v_u_20, (ref) v_u_146
							v_u_144 = false
							if v_u_15 then
								for _, v163 in p_u_157 do
									local v164 = v163.busy
									pcall(v164, false)
								end
								local v165
								if type(p161) == "table" then
									v165 = p161.code
								else
									v165 = nil
								end
								if not p159 and v165 ~= "BAD_ARGS" then
									local v166 = v_u_32(p159, p160, p161, p162) or v_u_12.TEXT.BAD_ARGS
									v_u_20.set(v166, "danger")
								end
								v_u_146()
							end
						end, 25)
					end
				end
				local function v_u_204(p168) -- name: drawDyn
					-- upvalues: (ref) v_u_145, (ref) v_u_15, (copy) v_u_143, (ref) v_u_12, (ref) v_u_33, (ref) p_u_5, (ref) v_u_13, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (copy) v_u_167, (ref) v_u_10
					for _, v_u_169 in v_u_145 do
						pcall(function()
							-- upvalues: (copy) v_u_169
							v_u_169:Destroy()
						end)
					end
					v_u_145 = {}
					if v_u_15 and v_u_143.Parent then
						local v170 = v_u_12.invSummary(p168)
						if v170.invHead == nil then
							return
						else
							if v_u_33 == nil then
								v_u_33 = p_u_5.lib("MenuClanLayout")
							end
							local v171 = v_u_33.invRow(v_u_13)
							local v172 = v_u_12.invRows(p168, v_u_11.now())
							local v_u_173 = v_u_12.oldestCancel(v172, v_u_12.CANCEL_MAX)
							local v174 = v_u_11.frame(v_u_143, "InvHead", UDim2.new(1, -6, 0, v171.headH), nil, 0)
							local v175 = v_u_145
							table.insert(v175, v174)
							local v176
							if (v170.open or 0) >= (v170.max or 0) then
								v176 = (v170.max or 0) > 0
							else
								v176 = false
							end
							local v177 = v_u_7.label
							local v178 = {
								["parent"] = nil,
								["name"] = "InvCount",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v174,
								["text"] = v170.invHead
							}
							local v179
							if v176 then
								v179 = v_u_9.danger
							else
								v179 = nil
							end
							v178.color = v179
							v178.position = UDim2.fromOffset(v171.left, 0)
							v178.size = UDim2.new(1, -(v171.cancelAllW + v171.left + 8), 1, 0)
							v177(v178)
							local v_u_180 = nil
							local _, v181 = v_u_11.btn({
								["parent"] = nil,
								["text"] = nil,
								["kind"] = "secondary",
								["width"] = nil,
								["height"] = nil,
								["name"] = "CancelOldest",
								["position"] = nil,
								["disabled"] = nil,
								["onClick"] = nil,
								["parent"] = v174,
								["text"] = v_u_12.cancelOldestText(#v_u_173),
								["width"] = v171.cancelAllW,
								["height"] = v171.rowH,
								["position"] = UDim2.new(1, -v171.cancelAllW, 0, 0),
								["disabled"] = #v_u_173 == 0,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_167, (copy) v_u_173, (ref) v_u_180
									v_u_167(v_u_173, { v_u_180 })
								end
							})
							local _ = v181
							local v182 = v_u_145
							local v183 = v_u_11.section
							local v184 = v_u_143
							local v185 = v_u_12.UI.INV_LIST
							table.insert(v182, v183(v184, v185, 199))
							if #v172 == 0 then
								local v186 = v_u_145
								local v187 = v_u_10.empty
								local v188 = v_u_143
								local v189 = v_u_12.UI.NO_OPEN_INV
								table.insert(v186, v187(v188, v189, 200))
							else
								for v190, v_u_191 in v172 do
									local v192 = v_u_11.row(v_u_143, 200 + v190, v171.rowH, false)
									v192.Name = "Inv_" .. v_u_191.uid
									local v193 = v_u_145
									table.insert(v193, v192)
									local v194 = v_u_7.label
									local v195 = {
										["parent"] = nil,
										["name"] = "InvName",
										["text"] = nil,
										["style"] = "bodyStrong",
										["position"] = nil,
										["size"] = nil,
										["parent"] = v192,
										["text"] = v_u_191.name,
										["position"] = UDim2.fromOffset(v171.left, 3)
									}
									local v196 = UDim2.fromOffset
									local v197 = v171.textW
									v195.size = v196(math.max(60, v197), 22)
									v194(v195)
									local v198 = v_u_7.label
									local v199 = {
										["parent"] = nil,
										["name"] = "InvSub",
										["text"] = nil,
										["style"] = "micro",
										["color"] = nil,
										["position"] = nil,
										["size"] = nil,
										["track"] = false,
										["parent"] = v192,
										["text"] = v_u_191.sub,
										["color"] = v_u_9.text2,
										["position"] = UDim2.fromOffset(v171.left, 25)
									}
									local v200 = UDim2.fromOffset
									local v201 = v171.textW
									v199.size = v200(math.max(60, v201), 16)
									v198(v199)
									local v_u_202 = nil
									local _, v203 = v_u_11.btn({
										["parent"] = nil,
										["text"] = nil,
										["kind"] = "secondary",
										["width"] = nil,
										["height"] = nil,
										["name"] = "CancelInv",
										["position"] = nil,
										["onClick"] = nil,
										["parent"] = v192,
										["text"] = v_u_12.UI.CANCEL,
										["width"] = v171.btnW,
										["height"] = v171.rowH,
										["position"] = UDim2.new(1, -(v171.btnW + v171.right), 0, 0),
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) v_u_167, (copy) v_u_191, (ref) v_u_202
											v_u_167({ v_u_191.uid }, { v_u_202 })
										end
									})
									v_u_202 = v203
								end
							end
						end
					else
						return
					end
				end
				v_u_146 = function(p_u_205) -- name: loadInv
					-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) p_u_5, (copy) v_u_143, (ref) v_u_145, (ref) v_u_146, (copy) v_u_204
					if v_u_15 and v_u_16 == "invite" then
						task.spawn(function()
							-- upvalues: (ref) p_u_5, (ref) v_u_15, (ref) v_u_16, (ref) v_u_143, (copy) p_u_205, (ref) v_u_145, (ref) v_u_146, (ref) v_u_204
							local v206 = p_u_5.fetch("clanRequests", nil, 0)
							if v_u_15 and (v_u_16 == "invite" and v_u_143.Parent) then
								if type(v206) == "table" then
									local v207 = v206.inv
									if type(v207) == "table" then
										v_u_204(v206)
										return
									end
								end
								local v208
								if v206 == nil then
									v208 = true
								elseif type(v206) == "table" and v206.error ~= nil then
									v208 = v206.code ~= "DENIED"
								else
									v208 = false
								end
								if v208 and (not p_u_205 and #v_u_145 == 0) then
									task.delay(1.2, function()
										-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_143, (ref) v_u_145, (ref) v_u_146
										if v_u_15 and (v_u_16 == "invite" and (v_u_143.Parent and #v_u_145 == 0)) then
											v_u_146(true)
										end
									end)
								end
							end
						end)
					end
				end
				v_u_11.section(v_u_143, "INVITE BY NAME", 1)
				local v209 = v_u_11.frame(v_u_143, "NameLine", UDim2.new(1, -6, 0, v_u_8.touch(44)), nil, 2)
				local _, v_u_210 = v_u_7.input({
					["parent"] = nil,
					["name"] = "Name",
					["placeholder"] = "Roblox username",
					["maxLength"] = 20,
					["size"] = nil,
					["parent"] = v209,
					["size"] = UDim2.new(1, -138, 1, 0)
				})
				local v_u_211 = nil
				local _, v214 = v_u_11.btn({
					["parent"] = nil,
					["text"] = "INVITE",
					["kind"] = "primary",
					["width"] = 130,
					["name"] = "Invite",
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v209,
					["position"] = UDim2.new(1, -130, 0, 0),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_210, (ref) v_u_12, (ref) v_u_20, (copy) v_u_155, (ref) v_u_211
						local v212 = string.gsub(v_u_210.Text, "[^%w_]", "")
						if #v212 < 3 then
							local v213 = v_u_12.TEXT.BAD_ARGS
							v_u_20.set(v213, "danger")
						else
							v_u_155({
								["name"] = v212
							}, v_u_211)
						end
					end
				})
				v_u_211 = v214
				v_u_11.section(v_u_143, "ON THIS SERVER", 3)
				local v215 = v_u_146
				local v216 = 0
				for _, v_u_217 in v_u_1:GetPlayers() do
					if v_u_217 == v_u_1.LocalPlayer then
						continue
					end
					local v218 = v_u_217:GetAttribute("ClanTag")
					if type(v218) == "string" and v218 ~= "" then
						continue
					end
					v216 = v216 + 1
					local v219 = v_u_11.row(v_u_143, v216, v_u_13.rowH, false)
					v219.LayoutOrder = v216 + 10
					v_u_7.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v219,
						["text"] = v_u_217.DisplayName,
						["position"] = UDim2.fromOffset(12, 0),
						["size"] = UDim2.new(1, -160, 1, 0)
					})
					local v_u_220 = nil
					local _, v224 = v_u_11.btn({
						["parent"] = nil,
						["text"] = "INVITE",
						["kind"] = "secondary",
						["width"] = 130,
						["height"] = nil,
						["name"] = "Invite",
						["position"] = nil,
						["onClick"] = nil,
						["parent"] = v219,
						["height"] = v_u_13.rowH,
						["position"] = UDim2.new(1, -136, 0, 0),
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_155, (copy) v_u_217, (ref) v_u_220
							local v221 = v_u_155
							local v222 = {}
							local v223 = v_u_217.UserId
							v222.uid = tostring(v223)
							v221(v222, v_u_220)
						end
					})
					v_u_220 = v224
				end
				if v216 == 0 then
					v_u_10.empty(v_u_143, "Nobody without a clan is on this server.", 4)
				end
				v215()
			end,
			["settings"] = function() -- name: drawSettings
				-- upvalues: (copy) p_u_5, (copy) v_u_7, (copy) v_u_22, (copy) v_u_13, (copy) v_u_11, (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_23, (copy) v_u_20, (ref) v_u_15
				local v_u_225 = p_u_5.clan()
				if v_u_225 then
					local v226 = v_u_7.list
					local v227 = {
						["parent"] = nil,
						["name"] = "List",
						["size"] = nil,
						["gap"] = 6,
						["padding"] = nil,
						["parent"] = v_u_22
					}
					local v228 = UDim2.new
					local v229 = v_u_13.fieldW
					local v230 = v_u_13.inner
					v227.size = v228(0, math.min(v229, v230) + 14, 1, 0)
					v227.padding = {
						0,
						6,
						0,
						12
					}
					local v231 = v226(v227)
					local v232 = v_u_13.fieldW
					local v233 = v_u_13.inner
					local v234 = math.min(v232, v233) - 14
					local v235 = v_u_225.mode or "request"
					local v_u_236 = tostring(v235)
					local v237 = v_u_225.crit
					if v237 then
						v237 = v_u_225.crit.raids
					end
					local v_u_238 = tonumber(v237) or 0
					local v239 = v_u_225.crit
					if v239 then
						v239 = v_u_225.crit.pct
					end
					local v_u_240 = tonumber(v239) or 0
					local v241 = v_u_225.desc or ""
					local v_u_242 = tostring(v241)
					local v243 = 18 + v_u_8.touch(44) + 38
					local v244 = v_u_11.frame(v231, "B" .. 1, UDim2.new(1, -14, 0, v243), nil, 1)
					v_u_7.label({
						["parent"] = nil,
						["text"] = "WHO CAN JOIN",
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["parent"] = v244,
						["color"] = v_u_9.text2,
						["size"] = UDim2.new(1, 0, 0, 16)
					})
					local v_u_245 = nil
					v_u_7.tabs({
						["parent"] = nil,
						["name"] = "Mode",
						["position"] = nil,
						["size"] = nil,
						["selected"] = nil,
						["tabs"] = nil,
						["onChange"] = nil,
						["parent"] = v244,
						["position"] = UDim2.fromOffset(0, 18),
						["size"] = UDim2.new(1, 0, 0, v_u_8.touch(44)),
						["selected"] = v_u_236,
						["tabs"] = {
							{
								["id"] = "open",
								["text"] = "Open"
							},
							{
								["id"] = "request",
								["text"] = "On request"
							},
							{
								["id"] = "private",
								["text"] = "Private"
							}
						},
						["onChange"] = function(p246) -- name: onChange
							-- upvalues: (ref) v_u_236, (ref) v_u_245, (ref) v_u_12
							v_u_236 = p246
							if v_u_245 then
								v_u_245.Text = v_u_12.MODE_HELP[p246] or ""
							end
						end
					})
					v_u_245 = v_u_7.label({
						["parent"] = nil,
						["name"] = "Help",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["valign"] = "top",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v244,
						["text"] = v_u_12.MODE_HELP[v_u_236] or "",
						["color"] = v_u_9.text2,
						["position"] = UDim2.fromOffset(0, 18 + v_u_8.touch(44) + 4),
						["size"] = UDim2.new(1, 0, 0, 32)
					})
					local v247 = 18 + v_u_8.touch(44) + 4
					local v248 = v_u_11.frame(v231, "B" .. 2, UDim2.new(1, -14, 0, v247), nil, 2)
					local v249 = (v234 - v_u_13.gap) / 2
					local v250 = math.floor(v249)
					local v251 = v_u_23.field(p_u_5, v248, "MIN RAIDS", 0, 0, v250)
					v_u_23.numberInput(p_u_5, {
						["parent"] = nil,
						["name"] = "Raids",
						["min"] = 0,
						["max"] = 9999,
						["value"] = nil,
						["size"] = nil,
						["onChange"] = nil,
						["parent"] = v251,
						["value"] = v_u_238,
						["size"] = UDim2.fromScale(1, 1),
						["onChange"] = function(p252) -- name: onChange
							-- upvalues: (ref) v_u_238
							v_u_238 = p252
						end
					})
					local v253 = v_u_23.field(p_u_5, v248, "MIN EXTRACTION %", v250 + v_u_13.gap, 0, v250)
					v_u_23.numberInput(p_u_5, {
						["parent"] = nil,
						["name"] = "Pct",
						["min"] = 0,
						["max"] = 100,
						["value"] = nil,
						["size"] = nil,
						["onChange"] = nil,
						["parent"] = v253,
						["value"] = v_u_240,
						["size"] = UDim2.fromScale(1, 1),
						["onChange"] = function(p254) -- name: onChange
							-- upvalues: (ref) v_u_240
							v_u_240 = p254
						end
					})
					local v255 = 18 + v_u_8.touch(44) + 4
					local v256 = v_u_11.frame(v231, "B" .. 3, UDim2.new(1, -14, 0, v255), nil, 3)
					local v257 = v_u_23.field(p_u_5, v256, "DESCRIPTION", 0, 0, v234)
					local _, v_u_258 = v_u_7.input({
						["parent"] = nil,
						["name"] = "Desc",
						["placeholder"] = "A short line about your clan",
						["maxLength"] = nil,
						["text"] = nil,
						["size"] = nil,
						["parent"] = v257,
						["maxLength"] = v_u_12.DESC_MAX,
						["text"] = v_u_242,
						["size"] = UDim2.fromScale(1, 1)
					})
					v_u_258:GetPropertyChangedSignal("Text"):Connect(function()
						-- upvalues: (ref) v_u_242, (copy) v_u_258
						v_u_242 = v_u_258.Text
					end)
					local v259 = v_u_8.touch(44) + 4
					local v260 = v_u_11.frame(v231, "B" .. 4, UDim2.new(1, -14, 0, v259), nil, 4)
					local v_u_261 = nil
					local v280 = {
						["parent"] = nil,
						["text"] = "SAVE",
						["kind"] = "primary",
						["width"] = 160,
						["name"] = "Save",
						["onClick"] = nil,
						["parent"] = v260,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_261, (ref) v_u_12, (ref) v_u_20, (ref) v_u_15, (ref) p_u_5, (ref) v_u_238, (ref) v_u_240, (ref) v_u_242, (ref) v_u_236, (copy) v_u_225
							v_u_261.busy(true, v_u_12.UI.SAVING)
							v_u_20.set("", nil)
							local function v_u_269() -- name: criteria
								-- upvalues: (ref) p_u_5, (ref) v_u_238, (ref) v_u_240, (ref) v_u_12, (ref) v_u_242, (ref) v_u_15, (ref) v_u_261, (ref) v_u_20
								p_u_5.send("clanSetCriteria", {
									["raids"] = v_u_238,
									["pct"] = v_u_240,
									["desc"] = v_u_12.cleanDesc(v_u_242)
								}, function(p262, p263, p264, p265)
									-- upvalues: (ref) v_u_12, (ref) v_u_15, (ref) v_u_261, (ref) v_u_20
									local v266
									if p262 then
										v266 = nil
									else
										v266 = v_u_12.reasonFor(p265 or {
											["msg"] = p263,
											["data"] = p264
										})
									end
									if v_u_15 then
										local v267 = v_u_261.busy
										pcall(v267, false)
										if p262 then
											v_u_20.set("Saved.", "success")
										else
											local v268 = v266 or v_u_12.TEXT.BAD_ARGS
											v_u_20.set(v268, "danger")
										end
									else
										return
									end
								end, 30)
							end
							local v270 = v_u_236
							local v271 = v_u_225.mode
							if v270 == tostring(v271) then
								v_u_269()
							else
								local v272 = {
									["mode"] = v_u_236
								}
								p_u_5.send("clanSetMode", v272, function(p273, p274, p275, p276)
									-- upvalues: (copy) v_u_269, (ref) v_u_12, (ref) v_u_15, (ref) v_u_261, (ref) v_u_20
									if p273 then
										v_u_269()
										return
									else
										local v277 = v_u_12.reasonFor(p276 or {
											["msg"] = p274,
											["data"] = p275
										})
										if v_u_15 then
											local v278 = v_u_261.busy
											pcall(v278, false)
											local v279 = v277 or v_u_12.TEXT.BAD_ARGS
											v_u_20.set(v279, "danger")
										end
									end
								end, 20)
							end
						end
					}
					local _, v281 = v_u_11.btn(v280)
					v_u_261 = v281
				end
			end,
			["ranks"] = function() -- name: drawRanks
				-- upvalues: (copy) p_u_5, (copy) v_u_7, (copy) v_u_22, (copy) v_u_8, (copy) v_u_12, (copy) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_23, (copy) v_u_20, (ref) v_u_15
				local v282 = p_u_5.clan()
				if v282 then
					local v283 = p_u_5.lib("MenuClanPlan")
					local v284 = p_u_5.lib("MenuClanLook")
					local v285 = v_u_7.list({
						["parent"] = nil,
						["name"] = "List",
						["size"] = nil,
						["gap"] = 12,
						["padding"] = nil,
						["parent"] = v_u_22,
						["size"] = UDim2.fromScale(1, 1),
						["padding"] = {
							0,
							6,
							0,
							12
						}
					})
					local v286 = {}
					local v_u_287 = {}
					for _, v288 in v282.ranks or {} do
						if type(v288) ~= "table" or v288.id == "owner" then
							continue
						end
						table.insert(v286, v288)
					end
					local v289 = v_u_8.touch(44)
					local v290 = {}
					for _, v291 in v_u_12.PERMS do
						if v291 == "useShop" and p_u_5.shopOn ~= true then
							continue
						end
						table.insert(v290, v291)
					end
					local v292 = v_u_13.inner - 18
					local v293 = v283.ranksGrid(v292, #v286, 0)
					local v294 = v283.rankCard(v293.cardW, #v290, v289)
					local v295 = v283.ranksGrid(v292, #v286, v294.height)
					local v296 = v_u_11.frame(v285, "Grid", UDim2.new(1, -8, 0, v295.height), nil, 1)
					for v297, v298 in v286 do
						local v299 = v298.id
						local v_u_300 = {
							["name"] = nil,
							["perm"] = nil,
							["wpd"] = nil,
							["changed"] = false
						}
						local v301 = v298.name or ""
						v_u_300.name = tostring(v301)
						v_u_300.perm = {}
						local v302 = v298.withdrawPerDay
						v_u_300.wpd = tonumber(v302) or 0
						for _, v303 in v_u_12.PERMS do
							local v304 = v_u_300.perm
							local v305 = v298.perm
							local v306
							if type(v305) == "table" then
								v306 = v298.perm[v303] == true
							else
								v306 = false
							end
							v304[v303] = v306
						end
						v_u_287[v299] = v_u_300
						local v307 = v295.rects[v297]
						local v308 = v307.w
						local v309 = v283.rankCard(v308, #v290, v289)
						local v310 = v284.rankColor(v299)
						local v311 = v_u_11.card(v296, "Rank_" .. v299, v307, {
							["stroke"] = nil,
							["strokeTransparency"] = 0.1,
							["stroke"] = v_u_9.line
						})
						v_u_7.new("Frame", {
							["Name"] = "RankBar",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["BackgroundColor3"] = v310,
							["Size"] = UDim2.new(1, 0, 0, 3)
						}, v311)
						v_u_7.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v311,
							["text"] = string.upper(v299),
							["color"] = v310,
							["position"] = UDim2.fromOffset(v309.head.x, v309.head.y + 2),
							["size"] = UDim2.fromOffset(v309.head.w, v309.head.h)
						})
						local _, v_u_312 = v_u_7.input({
							["parent"] = nil,
							["name"] = "RankName",
							["maxLength"] = nil,
							["text"] = nil,
							["size"] = nil,
							["position"] = nil,
							["parent"] = v311,
							["maxLength"] = v_u_12.RANK_NAME_MAX,
							["text"] = v_u_300.name,
							["size"] = UDim2.fromOffset(v309.name.w, v309.name.h),
							["position"] = UDim2.fromOffset(v309.name.x, v309.name.y)
						})
						v_u_312:GetPropertyChangedSignal("Text"):Connect(function()
							-- upvalues: (copy) v_u_300, (copy) v_u_312
							v_u_300.name = v_u_312.Text
							v_u_300.changed = true
						end)
						local v_u_313 = nil
						for v314, v_u_315 in v290 do
							local v316 = v309.toggles[v314]
							local _, _ = v_u_7.toggle({
								["parent"] = v311,
								["name"] = "Perm_" .. v_u_315,
								["label"] = v_u_12.PERM_TEXT[v_u_315],
								["value"] = v_u_300.perm[v_u_315],
								["width"] = v316.w,
								["size"] = UDim2.new(0, v316.w, 0, v316.h),
								["position"] = UDim2.fromOffset(v316.x, v316.y),
								["onChange"] = function(p317) -- name: onChange
									-- upvalues: (copy) v_u_300, (copy) v_u_315, (ref) v_u_313
									v_u_300.perm[v_u_315] = p317
									v_u_300.changed = true
									if v_u_315 == "withdraw" and v_u_313 then
										v_u_313.Visible = p317
									end
								end
							})
						end
						local v318 = v_u_11.frame(v311, "Wpd", UDim2.fromOffset(v309.wpd.w, v309.wpd.h), UDim2.fromOffset(v309.wpd.x, v309.wpd.y))
						v_u_7.label({
							["parent"] = nil,
							["text"] = "Stacks per day (0 = unlimited)",
							["style"] = "small",
							["wrap"] = true,
							["valign"] = "center",
							["size"] = nil,
							["parent"] = v318,
							["size"] = UDim2.new(1, -130, 1, 0)
						})
						v_u_23.numberInput(p_u_5, {
							["parent"] = nil,
							["name"] = "Wpd",
							["min"] = 0,
							["max"] = 200,
							["value"] = nil,
							["size"] = nil,
							["position"] = nil,
							["onChange"] = nil,
							["parent"] = v318,
							["value"] = v_u_300.wpd,
							["size"] = UDim2.new(0, 120, 1, 0),
							["position"] = UDim2.new(1, -120, 0, 0),
							["onChange"] = function(p319) -- name: onChange
								-- upvalues: (copy) v_u_300
								v_u_300.wpd = p319
								v_u_300.changed = true
							end
						})
						v318.Visible = v_u_300.perm.withdraw == true
					end
					local v320 = v_u_11.frame(v285, "SaveHolder", UDim2.new(1, -8, 0, v_u_8.touch(44)), nil, 100)
					local v_u_321 = nil
					local v337 = {
						["parent"] = nil,
						["text"] = "SAVE RANKS",
						["kind"] = "primary",
						["width"] = 200,
						["name"] = "Save",
						["onClick"] = nil,
						["parent"] = v320,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_287, (ref) v_u_12, (ref) v_u_20, (ref) v_u_321, (ref) p_u_5, (ref) v_u_15
							local v322 = {}
							for v323, v324 in v_u_287 do
								if not v324.changed then
									continue
								end
								local v325 = string.gsub(v324.name, "[^%w ]", "")
								local v326 = string.gsub(v325, "^%s+", "")
								local v327 = v_u_12.RANK_NAME_MAX
								local v328 = {
									["rank"] = v323,
									["name"] = string.sub(v326, 1, v327),
									["perm"] = table.clone(v324.perm),
									["withdrawPerDay"] = v324.wpd
								}
								table.insert(v322, v328)
							end
							if #v322 == 0 then
								v_u_20.set("Nothing changed.", "info")
							else
								v_u_321.busy(true, v_u_12.UI.SAVING)
								v_u_20.set("", nil)
								p_u_5.send("clanSetRankDef", {
									["defs"] = v322
								}, function(p329, p330, p331, p332)
									-- upvalues: (ref) v_u_15, (ref) v_u_321, (ref) v_u_287, (ref) v_u_20, (ref) v_u_12
									if v_u_15 then
										local v333 = v_u_321.busy
										pcall(v333, false)
										if p329 then
											for _, v334 in v_u_287 do
												v334.changed = false
											end
											v_u_20.set("Saved.", "success")
										else
											local v335 = v_u_12.reasonFor
											if not p332 then
												p332 = {
													["msg"] = p330,
													["data"] = p331
												}
											end
											local v336 = v335(p332)
											v_u_20.set(v336, "danger")
										end
									else
										return
									end
								end, 30)
							end
						end
					}
					local _, v338 = v_u_11.btn(v337)
					v_u_321 = v338
				end
			end,
			["leader"] = function() -- name: drawLeader
				-- upvalues: (copy) p_u_5, (copy) v_u_7, (copy) v_u_22, (copy) v_u_11, (copy) v_u_9, (copy) v_u_12, (ref) v_u_15, (copy) v_u_20, (copy) v_u_10, (copy) v_u_13
				local v339 = p_u_5.clan()
				if v339 then
					local v340 = v_u_7.list({
						["parent"] = nil,
						["name"] = "List",
						["size"] = nil,
						["gap"] = 2,
						["padding"] = nil,
						["parent"] = v_u_22,
						["size"] = UDim2.fromScale(1, 1),
						["padding"] = {
							0,
							6,
							0,
							8
						}
					})
					local v_u_341 = v339.offer
					local v342 = 0
					if type(v_u_341) == "table" then
						v342 = v342 + 1
						local v343 = v_u_11.frame(v340, "Pending", UDim2.new(1, -6, 0, 72), nil, v342)
						v343.BackgroundColor3 = v_u_9.accentDeep
						v343.BackgroundTransparency = 0.2
						v_u_7.stroke(v343, v_u_9.accent)
						local v344 = v_u_7.label
						local v345 = {
							["parent"] = nil,
							["name"] = "T",
							["text"] = nil,
							["style"] = "body",
							["wrap"] = true,
							["valign"] = "top",
							["position"] = nil,
							["size"] = nil,
							["parent"] = v343
						}
						local v346 = v_u_341.toName or "a member"
						v345.text = ("Offer to %s is open. It runs out in %s."):format(tostring(v346), v_u_12.timeText(v_u_11.left(v_u_341.ex)))
						v345.position = UDim2.fromOffset(12, 6)
						v345.size = UDim2.new(1, -24, 0, 24)
						v344(v345)
						local v_u_347 = nil
						local _, v358 = v_u_11.btn({
							["parent"] = nil,
							["text"] = "WITHDRAW OFFER",
							["kind"] = "secondary",
							["width"] = 200,
							["name"] = "Withdraw",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v343,
							["position"] = UDim2.fromOffset(12, 28),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_347, (ref) p_u_5, (copy) v_u_341, (ref) v_u_15, (ref) v_u_12, (ref) v_u_20
								v_u_347.busy(true, "...")
								local v348 = p_u_5.send
								local v349 = {
									["uid"] = nil,
									["cancel"] = true
								}
								local v350 = v_u_341.to
								v349.uid = tostring(v350)
								v348("clanTransfer", v349, function(p351, p352, p353, p354)
									-- upvalues: (ref) v_u_15, (ref) v_u_347, (ref) v_u_12, (ref) v_u_20
									if v_u_15 then
										local v355 = v_u_347.busy
										pcall(v355, false)
										if not p351 then
											local v356 = v_u_12.reasonFor
											if not p354 then
												p354 = {
													["msg"] = p352,
													["data"] = p353
												}
											end
											local v357 = v356(p354)
											v_u_20.set(v357, "danger")
										end
									end
								end, 25)
							end
						})
						v_u_347 = v358
					end
					local v359 = v342 + 1
					v_u_10.section(v340, "OFFER LEADERSHIP", v359)
					for v360, v_u_361 in v_u_12.sortMembers(v339.members) do
						local v362 = v_u_361.uid
						if tostring(v362) == p_u_5.selfUid then
							continue
						end
						local v363 = v_u_11.row(v340, v359 + v360, v_u_13.rowH, false)
						v363.LayoutOrder = v359 + v360
						local v364 = v_u_7.label
						local v365 = {
							["parent"] = nil,
							["name"] = "Name",
							["text"] = nil,
							["style"] = "bodyStrong",
							["position"] = nil,
							["size"] = nil,
							["parent"] = v363
						}
						local v366 = v_u_361.name or "?"
						v365.text = tostring(v366)
						v365.position = UDim2.fromOffset(12, 0)
						v365.size = UDim2.new(1, -310, 1, 0)
						v364(v365)
						local v367 = v_u_7.label
						local v368 = {
							["parent"] = nil,
							["name"] = "Rank",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v363
						}
						local v369 = v_u_361.rankName or v_u_12.rankName(v339, v_u_361.rank)
						v368.text = tostring(v369)
						v368.color = v_u_9.text2
						v368.position = UDim2.new(1, -300, 0, 0)
						v368.size = UDim2.fromOffset(120, v_u_13.rowH)
						v367(v368)
						local v_u_370 = nil
						local _, v385 = v_u_11.btn({
							["parent"] = nil,
							["text"] = "OFFER LEADERSHIP",
							["kind"] = "secondary",
							["width"] = 170,
							["height"] = nil,
							["name"] = "Offer",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v363,
							["height"] = v_u_13.rowH,
							["position"] = UDim2.new(1, -176, 0, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_361, (ref) v_u_370, (ref) v_u_20, (ref) p_u_5, (ref) v_u_15
								local v371 = v_u_11.confirm
								local v372 = {
									["title"] = "OFFER LEADERSHIP",
									["body"] = nil,
									["yes"] = "OFFER",
									["no"] = "CANCEL",
									["onYes"] = nil
								}
								local v373 = v_u_12.CONFIRM.offer
								local v374 = v_u_361.name or "?"
								v372.body = v373((tostring(v374)))
								function v372.onYes() -- name: onYes
									-- upvalues: (ref) v_u_370, (ref) v_u_20, (ref) p_u_5, (ref) v_u_361, (ref) v_u_15, (ref) v_u_12
									v_u_370.busy(true, "...")
									v_u_20.set("", nil)
									local v375 = p_u_5.send
									local v376 = {}
									local v377 = v_u_361.uid
									v376.uid = tostring(v377)
									v375("clanTransfer", v376, function(p378, p379, p380, p381)
										-- upvalues: (ref) v_u_15, (ref) v_u_370, (ref) v_u_12, (ref) v_u_20
										if v_u_15 then
											local v382 = v_u_370.busy
											pcall(v382, false)
											if p378 then
												v_u_20.set("Offer sent. They have to accept it.", "success")
											else
												local v383 = v_u_12.reasonFor
												if not p381 then
													p381 = {
														["msg"] = p379,
														["data"] = p380
													}
												end
												local v384 = v383(p381)
												v_u_20.set(v384, "danger")
											end
										else
											return
										end
									end, 25)
								end
								v371(v372)
							end
						})
						v_u_370 = v385
					end
				end
			end,
			["disband"] = function() -- name: drawDisband
				-- upvalues: (copy) p_u_5, (copy) v_u_7, (copy) v_u_22, (copy) v_u_9, (copy) v_u_11, (copy) v_u_8, (copy) v_u_12, (copy) v_u_20, (ref) v_u_15
				local v_u_386 = p_u_5.clan()
				if v_u_386 then
					local v387 = v_u_7.list({
						["parent"] = nil,
						["name"] = "List",
						["size"] = nil,
						["gap"] = 8,
						["padding"] = nil,
						["parent"] = v_u_22,
						["size"] = UDim2.fromScale(1, 1),
						["padding"] = {
							0,
							6,
							0,
							8
						}
					})
					local v388 = p_u_5.shopOn == true and "Disbanding closes the clan for good. Everything in the clan stash returns to you. Clan coins and shop items are lost for good. The tag and the name become free again, and your pass can found a new clan." or "Disbanding closes the clan for good. Everything in the clan stash returns to you. The tag and the name become free again, and your pass can found a new clan."
					v_u_7.label({
						["parent"] = nil,
						["name"] = "Warn",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["size"] = nil,
						["order"] = 1,
						["parent"] = v387,
						["text"] = v388,
						["color"] = v_u_9.text2,
						["size"] = UDim2.new(1, -6, 0, 0)
					})
					local v389 = v_u_11.frame(v387, "Holder", UDim2.new(1, -6, 0, v_u_8.touch(44)), nil, 2)
					local v_u_390 = nil
					local v406 = {
						["parent"] = nil,
						["text"] = "DISBAND",
						["kind"] = "danger",
						["width"] = 200,
						["name"] = "Disband",
						["onClick"] = nil,
						["parent"] = v389,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_386, (ref) p_u_5, (ref) v_u_390, (ref) v_u_20, (ref) v_u_15
							local v391 = v_u_11.typeConfirm
							local v392 = {
								["title"] = "DISBAND CLAN",
								["body"] = nil,
								["expect"] = nil,
								["yes"] = "DISBAND",
								["no"] = "CANCEL",
								["onYes"] = nil
							}
							local v393 = v_u_12.CONFIRM.disband
							local v394 = v_u_386.tag
							v392.body = v393(tostring(v394), p_u_5.shopOn ~= true)
							local v395 = v_u_386.tag
							v392.expect = tostring(v395)
							function v392.onYes() -- name: onYes
								-- upvalues: (ref) v_u_390, (ref) v_u_12, (ref) v_u_20, (ref) p_u_5, (ref) v_u_386, (ref) v_u_15
								v_u_390.busy(true, v_u_12.UI.DISBANDING)
								v_u_20.set("", nil)
								local v396 = p_u_5.send
								local v397 = {}
								local v398 = v_u_386.tag
								v397.confirm = tostring(v398)
								v396("clanDisband", v397, function(p399, p400, p401, p402)
									-- upvalues: (ref) v_u_15, (ref) v_u_390, (ref) v_u_12, (ref) v_u_20
									if v_u_15 then
										local v403 = v_u_390.busy
										pcall(v403, false)
										if not p399 then
											local v404 = v_u_12.reasonFor
											if not p402 then
												p402 = {
													["msg"] = p400,
													["data"] = p401
												}
											end
											local v405 = v404(p402)
											v_u_20.set(v405, "danger")
										end
									end
								end, 40)
							end
							v391(v392)
						end
					}
					local _, v407 = v_u_11.btn(v406)
					v_u_390 = v407
				end
			end
		}
		local function v_u_412(p409, p410) -- name: drawSection
			-- upvalues: (ref) v_u_16, (copy) v_u_10, (copy) v_u_22, (copy) v_u_20, (copy) v_u_408
			v_u_16 = p409
			v_u_10.clear(v_u_22)
			if not p410 then
				v_u_20.set("", nil)
			end
			local v411 = v_u_408[p409]
			if v411 then
				v411()
			end
		end
		local function v_u_422() -- name: buildTabs
			-- upvalues: (copy) p_u_5, (ref) v_u_425, (copy) v_u_12, (ref) v_u_19, (copy) v_u_17, (ref) v_u_16, (copy) v_u_10, (copy) v_u_22, (copy) v_u_7, (ref) v_u_412, (ref) v_u_18
			local v413 = p_u_5.clan()
			local v414 = v_u_425.sections(v_u_12, v413)
			local v415 = ""
			for _, v416 in v414 do
				v415 = v415 .. v416.id .. ","
			end
			if v415 == v_u_19 then
				return
			else
				v_u_19 = v415
				if v_u_17:FindFirstChild("SecTabs") then
					v_u_17.SecTabs:Destroy()
				end
				if #v414 == 0 then
					v_u_16 = nil
					v_u_10.clear(v_u_22)
					v_u_10.empty(v_u_22, "Your rank has no management rights.", 1)
				else
					local v417 = v_u_16
					local v418 = false
					for _, v419 in v414 do
						if v419.id ~= v417 then
							continue
						end
						v418 = true
					end
					if not v418 then
						v417 = v414[1].id
					end
					local _, v421 = v_u_7.tabs({
						["parent"] = nil,
						["name"] = "SecTabs",
						["tabs"] = nil,
						["selected"] = nil,
						["size"] = nil,
						["onChange"] = nil,
						["parent"] = v_u_17,
						["tabs"] = v414,
						["selected"] = v417,
						["size"] = UDim2.fromScale(1, 1),
						["onChange"] = function(p420) -- name: onChange
							-- upvalues: (ref) v_u_412
							v_u_412(p420)
						end
					})
					v_u_18 = v421
					v_u_412(v417)
				end
			end
		end
		function v_u_14.show() -- name: show
			-- upvalues: (copy) v_u_422
			v_u_422()
		end
		function v_u_14.hide() -- name: hide end
		function v_u_14.refresh(p423) -- name: refresh
			-- upvalues: (ref) v_u_19, (copy) v_u_422, (ref) v_u_16, (ref) v_u_412
			if p423 == "state" then
				local v424 = v_u_19
				v_u_422()
				if v_u_19 == v424 and v_u_16 == "leader" then
					v_u_412("leader", true)
				end
			end
		end
		function v_u_14.tick() -- name: tick end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15
			v_u_15 = false
		end
		v_u_422()
		return v_u_14
	end
}
return v_u_425