-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RideLeanPlan

local v_u_1 = {
	["VERSION"] = 1,
	["TUNE"] = {
		["DEBOUNCE"] = 0.06,
		["MIN_HOLD"] = 0.5,
		["OMEGA_LOCAL"] = 40,
		["OMEGA_REMOTE"] = 14,
		["FOLLOW_OMEGA"] = 10,
		["FOLLOW_RATE"] = 300,
		["JOINT_RATE"] = 700,
		["AIM_RATE"] = 600,
		["IN_DUR"] = 0.3,
		["OUT_DUR"] = 0.25,
		["SWITCH_DUR"] = 0.45,
		["FIRE_FROM"] = 0.8,
		["FIRE_FROM_VIA"] = 0.65,
		["SETTLE_RATE_K"] = 1.5,
		["FIRE_OFF"] = 4,
		["NECK_MAX"] = 50,
		["ENTER_BAND"] = 7,
		["BRIDGE_MAX"] = 30,
		["BRIDGE_OVERLAP"] = 4,
		["SETTLE_EPS"] = 0.3,
		["LEGACY_HALF"] = 50,
		["WAIST_PITCH"] = 0.35,
		["NECK_PITCH"] = 0.4,
		["WAIST_PITCH_MAX"] = 12
	}
}
local v_u_2 = v_u_1.TUNE
v_u_1.CAPS = {
	["long"] = 30,
	["pistol"] = 45,
	["twin"] = 20
}
v_u_1.MOTION = {
	["roll"] = 9,
	["pitch"] = 7,
	["kRoll"] = 0.3,
	["kPitch"] = 0.18,
	["omega"] = 9,
	["zeta"] = 0.55,
	["lift"] = 0.1,
	["kLift"] = 0.003,
	["liftOmega"] = 14,
	["liftZeta"] = 0.4,
	["neckRoll"] = 0.6,
	["neckPitch"] = 0.5,
	["tau"] = 0.08,
	["accMax"] = 120
}
v_u_1.BREATH = {
	["amp"] = 1,
	["hz"] = 0.26
}
v_u_1.WIND = {
	["neck"] = 3,
	["vFrom"] = 15,
	["vTo"] = 60,
	["jitter"] = 0.6,
	["hz"] = nil,
	["hz"] = { 2.3, 3.7 }
}
v_u_1.HIT = {
	["pitch"] = 10,
	["yaw"] = 8,
	["neck"] = 6,
	["rate"] = 6
}
v_u_1.RECOIL = {
	["pistol"] = {
		["waist"] = 2.5,
		["shoulder"] = 0.06,
		["head"] = 1.5,
		["dur"] = 0.16
	},
	["revolver"] = {
		["waist"] = 4,
		["shoulder"] = 0.1,
		["head"] = 2.5,
		["dur"] = 0.2
	},
	["smg"] = {
		["waist"] = 1.6,
		["shoulder"] = 0.05,
		["head"] = 1,
		["dur"] = 0.11
	},
	["rifle"] = {
		["waist"] = 3.5,
		["shoulder"] = 0.09,
		["head"] = 2,
		["dur"] = 0.22
	},
	["bullpup"] = {
		["waist"] = 3.5,
		["shoulder"] = 0.09,
		["head"] = 2,
		["dur"] = 0.22
	},
	["sniper"] = {
		["waist"] = 6,
		["shoulder"] = 0.14,
		["head"] = 3.5,
		["dur"] = 0.34
	},
	["shotgun"] = {
		["waist"] = 7,
		["shoulder"] = 0.16,
		["head"] = 4,
		["dur"] = 0.3
	},
	["launcher"] = {
		["waist"] = 8,
		["shoulder"] = 0.18,
		["head"] = 4,
		["dur"] = 0.4
	}
}
v_u_1.MUZZLE = {
	["pistol"] = 1.4,
	["revolver"] = 2.2,
	["smg"] = 0.9,
	["rifle"] = 1.7,
	["bullpup"] = 1.7,
	["sniper"] = 2.6,
	["shotgun"] = 3,
	["launcher"] = 3
}
v_u_1.MUZZLE_MAX = 3
v_u_1.IN_NAME = {
	["WIN"] = "LEAN_IN_WIN",
	["SILL"] = "SILL_IN",
	["KNEEL"] = "KNEEL_IN"
}
v_u_1.OUT_NAME = {
	["WIN"] = "LEAN_OUT_WIN",
	["SILL"] = "SILL_OUT",
	["KNEEL"] = "KNEEL_OUT"
}
v_u_1.LEGACY_NEUTRAL = {
	["Seat_P2"] = 270,
	["Seat_P3"] = 90
}
local v_u_3 = nil
function v_u_1.useArc(p4) -- name: useArc
	-- upvalues: (ref) v_u_3
	if type(p4) == "table" then
		local v5 = p4.soft
		if type(v5) ~= "function" then
			p4 = nil
		end
	else
		p4 = nil
	end
	v_u_3 = p4
end
local v_u_6 = math.rad
local v_u_7 = math.deg
function v_u_1.wrap(p8) -- name: wrap
	local v9 = (p8 + 180) / 360
	return p8 - math.floor(v9) * 360
end
function v_u_1.spring(p10, p11, p12, p13, p14, p15) -- name: spring
	local v16 = (type(p15) ~= "number" or (p15 ~= p15 or (p15 == (1 / 0) or p15 == (-1 / 0)))) and 0 or p15
	local v17 = v16 < 0 and 0 or (v16 > 0.1 and 0.1 or v16)
	if v17 <= 0 then
		return p10, p11
	end
	local v18 = v17 * 120
	local v19 = math.ceil(v18)
	local v20 = math.max(1, v19)
	local v21 = v17 / v20
	for _ = 1, v20 do
		p11 = p11 + (p13 * p13 * (p12 - p10) - p14 * 2 * p13 * p11) * v21
		p10 = p10 + p11 * v21
	end
	return p10, p11
end
function v_u_1.ease(p22, p23) -- name: ease
	local v24 = (type(p23) ~= "number" or (p23 ~= p23 or (p23 == (1 / 0) or p23 == (-1 / 0)))) and 0 or p23
	local v25 = v24 < 0 and 0 or (v24 > 1 and 1 or v24)
	if p22 == "inOutSine" then
		local v26 = 3.141592653589793 * v25
		return -(math.cos(v26) - 1) / 2
	elseif p22 == "outQuad" then
		return 1 - (1 - v25) * (1 - v25)
	elseif p22 == "outCubic" then
		return 1 - (1 - v25) ^ 3
	elseif p22 == "inOutCubic" then
		if v25 < 0.5 then
			return v25 * 4 * v25 * v25
		else
			return 1 - (v25 * -2 + 2) ^ 3 / 2
		end
	elseif p22 == "outBack" then
		return (v25 - 1) ^ 3 * 2.2 + 1 + (v25 - 1) ^ 2 * 1.2
	else
		return v25
	end
end
local function v_u_29(p27, p28) -- name: qmul
	return {
		p27[1] * p28[1] - p27[2] * p28[2] - p27[3] * p28[3] - p27[4] * p28[4],
		p27[1] * p28[2] + p27[2] * p28[1] + p27[3] * p28[4] - p27[4] * p28[3],
		p27[1] * p28[3] - p27[2] * p28[4] + p27[3] * p28[1] + p27[4] * p28[2],
		p27[1] * p28[4] + p27[2] * p28[3] - p27[3] * p28[2] + p27[4] * p28[1]
	}
end
function v_u_1.eulerToQuat(p30, p31, p32) -- name: eulerToQuat
	-- upvalues: (copy) v_u_6, (copy) v_u_29
	local v33 = v_u_6(p30) * 0.5
	local v34 = v_u_6(p31) * 0.5
	local v35 = v_u_6(p32) * 0.5
	local v36 = {
		math.cos(v34),
		0,
		math.sin(v34),
		0
	}
	local v37 = {
		math.cos(v33),
		math.sin(v33),
		0,
		0
	}
	local v38 = {
		math.cos(v35),
		0,
		0,
		(math.sin(v35))
	}
	return v_u_29(v_u_29(v36, v37), v38)
end
function v_u_1.quatToEuler(p39) -- name: quatToEuler
	-- upvalues: (copy) v_u_7
	local v40 = p39[1]
	local v41 = p39[2]
	local v42 = p39[3]
	local v43 = p39[4]
	local v44 = v40 * v40 + v41 * v41 + v42 * v42 + v43 * v43
	local v45 = math.sqrt(v44)
	if v45 < 1e-12 then
		return 0, 0, 0
	end
	local v46 = v40 / v45
	local v47 = v41 / v45
	local v48 = v42 / v45
	local v49 = v43 / v45
	local v50 = 2 * (v47 * v49 + v48 * v46)
	local v51 = 1 - 2 * (v47 * v47 + v48 * v48)
	local v52 = 2 * (v48 * v49 - v47 * v46)
	local v53 = 2 * (v47 * v48 + v49 * v46)
	local v54 = 1 - 2 * (v47 * v47 + v49 * v49)
	local v55 = -v52
	local v56 = v55 < -1 and -1 or (v55 > 1 and 1 or v55)
	local v57 = 1 - v56 * v56
	local v58 = math.max(0, v57)
	local v59 = math.sqrt(v58)
	local v60 = math.atan2(v56, v59)
	local v61, v62
	if math.abs(v52) < 0.999999 then
		v61 = math.atan2(v50, v51)
		v62 = math.atan2(v53, v54)
	else
		local v63 = 2 * (v47 * v49 - v48 * v46)
		local v64 = 1 - 2 * (v48 * v48 + v49 * v49)
		local v65 = -v63
		v61 = math.atan2(v65, v64)
		v62 = 0
	end
	return v_u_7(v60), v_u_7(v61), v_u_7(v62)
end
function v_u_1.slerp(p66, p67, p68) -- name: slerp
	local v69 = p66[1] * p67[1] + p66[2] * p67[2] + p66[3] * p67[3] + p66[4] * p67[4]
	local v70 = p67[1]
	local v71 = p67[2]
	local v72 = p67[3]
	local v73 = p67[4]
	if v69 < 0 then
		v69 = -v69
		v70 = -v70
		v71 = -v71
		v72 = -v72
		v73 = -v73
	end
	local v74
	if v69 > 0.9995 then
		v74 = 1 - p68
	else
		local v75 = 1 - v69 * v69
		local v76 = math.max(0, v75)
		local v77 = math.sqrt(v76)
		local v78 = math.atan2(v77, v69)
		local v79 = math.sin(v78)
		local v80 = (1 - p68) * v78
		v74 = math.sin(v80) / v79
		local v81 = p68 * v78
		p68 = math.sin(v81) / v79
	end
	local v82 = {
		v74 * p66[1] + p68 * v70,
		v74 * p66[2] + p68 * v71,
		v74 * p66[3] + p68 * v72,
		v74 * p66[4] + p68 * v73
	}
	local v83 = v82[1] * v82[1] + v82[2] * v82[2] + v82[3] * v82[3] + v82[4] * v82[4]
	local v84 = math.sqrt(v83)
	return {
		v82[1] / v84,
		v82[2] / v84,
		v82[3] / v84,
		v82[4] / v84
	}
end
local function v_u_94(p85, p86) -- name: jointOf
	local v87
	if type(p85) == "table" then
		local v88 = p85.j
		if type(v88) == "table" then
			v87 = p85.j[p86]
		else
			v87 = nil
		end
	else
		v87 = nil
	end
	if type(v87) == "table" then
		local v89 = v87[1]
		local v90 = (type(v89) ~= "number" or (v89 ~= v89 or (v89 == (1 / 0) or v89 == (-1 / 0)))) and 0 or v89
		local v91 = v87[2]
		local v92 = (type(v91) ~= "number" or (v91 ~= v91 or (v91 == (1 / 0) or v91 == (-1 / 0)))) and 0 or v91
		local v93 = v87[3]
		if type(v93) == "number" and (v93 == v93 and (v93 ~= (1 / 0) and v93 ~= (-1 / 0))) then
			return v90, v92, v93
		else
			return v90, v92, 0
		end
	else
		return 0, 0, 0
	end
end
local function v_u_102(p95) -- name: rootTOf
	local v96
	if type(p95) == "table" then
		v96 = p95.rootT
	else
		v96 = nil
	end
	if type(v96) == "table" then
		local v97 = v96[1]
		local v98 = (type(v97) ~= "number" or (v97 ~= v97 or (v97 == (1 / 0) or v97 == (-1 / 0)))) and 0 or v97
		local v99 = v96[2]
		local v100 = (type(v99) ~= "number" or (v99 ~= v99 or (v99 == (1 / 0) or v99 == (-1 / 0)))) and 0 or v99
		local v101 = v96[3]
		if type(v101) == "number" and (v101 == v101 and (v101 ~= (1 / 0) and v101 ~= (-1 / 0))) then
			return v98, v100, v101
		else
			return v98, v100, 0
		end
	else
		return 0, 0, 0
	end
end
local function v_u_136(p103, p104, p105) -- name: pathYaw
	local v106 = p104
	local v107 = 1e18
	local v108 = false
	local v109
	if p105 == "front" or p105 == "back" then
		v109 = v106
		for v110 = -2, 2 do
			local v111 = p104 + v110 * 360
			local v112 = math.min(p103, v111)
			local v113 = math.max(p103, v111)
			local v114 = false
			local v115
			if p105 == "front" then
				if v112 <= 0 then
					v115 = v113 >= 0
				else
					v115 = false
				end
			else
				local v116 = v112 <= -540 and v113 >= -540 and true or v114
				local v117 = v112 <= -180 and v113 >= -180 and true or v116
				local v118 = v112 <= 180 and v113 >= 180 and true or v117
				v115 = v112 <= 540 and v113 >= 540 and true or v118
			end
			if not v115 then
				continue
			end
			v108 = true
			local v119 = v111 - p103
			local v120 = math.abs(v119)
			if v120 >= v107 then
				continue
			end
			v106 = v111
			v107 = v120
			v109 = v106
		end
	else
		v109 = v106
	end
	if not v108 then
		local v121 = p104 + -720
		local v122 = v121 - p103
		local v123 = math.abs(v122)
		if v123 < v107 then
			v106 = v121
			v107 = v123
			v109 = v106
		end
		local v124 = p104 + -360
		local v125 = v124 - p103
		local v126 = math.abs(v125)
		if v126 < v107 then
			v106 = v124
			v107 = v126
			v109 = v106
		end
		local v127 = p104 + 0
		local v128 = v127 - p103
		local v129 = math.abs(v128)
		if v129 < v107 then
			v106 = v127
			v107 = v129
			v109 = v106
		end
		local v130 = p104 + 360
		local v131 = v130 - p103
		local v132 = math.abs(v131)
		if v132 < v107 then
			v106 = v130
			v107 = v132
			v109 = v106
		end
		local v133 = p104 + 720
		local v134 = v133 - p103
		local v135 = math.abs(v134)
		if v135 < v107 then
			v106 = v133
			v107 = v135
			v109 = v106
		end
	end
	return v109
end
function v_u_1.blendPose(p137, p138, p139, p140) -- name: blendPose
	-- upvalues: (copy) v_u_94, (copy) v_u_136, (copy) v_u_1
	local v141 = {
		["rootT"] = {},
		["j"] = {}
	}
	local v142
	if type(p137) == "table" then
		v142 = p137.rootT
	else
		v142 = nil
	end
	local v143, v144, v145
	if type(v142) == "table" then
		local v146 = v142[1]
		v143 = (type(v146) ~= "number" or (v146 ~= v146 or (v146 == (1 / 0) or v146 == (-1 / 0)))) and 0 or v146
		local v147 = v142[2]
		v144 = (type(v147) ~= "number" or (v147 ~= v147 or (v147 == (1 / 0) or v147 == (-1 / 0)))) and 0 or v147
		v145 = v142[3]
		if type(v145) ~= "number" or (v145 ~= v145 or (v145 == (1 / 0) or v145 == (-1 / 0))) then
			v145 = 0
		end
	else
		v143 = 0
		v144 = 0
		v145 = 0
	end
	local v148
	if type(p138) == "table" then
		v148 = p138.rootT
	else
		v148 = nil
	end
	local v149, v150, v151
	if type(v148) == "table" then
		local v152 = v148[1]
		v149 = (type(v152) ~= "number" or (v152 ~= v152 or (v152 == (1 / 0) or v152 == (-1 / 0)))) and 0 or v152
		local v153 = v148[2]
		v150 = (type(v153) ~= "number" or (v153 ~= v153 or (v153 == (1 / 0) or v153 == (-1 / 0)))) and 0 or v153
		v151 = v148[3]
		if type(v151) ~= "number" or (v151 ~= v151 or (v151 == (1 / 0) or v151 == (-1 / 0))) then
			v151 = 0
		end
	else
		v149 = 0
		v150 = 0
		v151 = 0
	end
	v141.rootT = { v143 + (v149 - v143) * p139, v144 + (v150 - v144) * p139, v145 + (v151 - v145) * p139 }
	local v154 = {}
	for _, v155 in { p137, p138 } do
		if type(v155) ~= "table" then
			continue
		end
		local v156 = v155.j
		if type(v156) ~= "table" then
			continue
		end
		for v157 in v155.j do
			v154[v157] = true
		end
	end
	for v158 in v154 do
		local v159, v160, v161 = v_u_94(p137, v158)
		local v162, v163, v164 = v_u_94(p138, v158)
		if v158 == "Root" then
			local v165 = v_u_136(v160, v163, p140)
			local v166 = v_u_1.slerp(v_u_1.eulerToQuat(v159, 0, v161), v_u_1.eulerToQuat(v162, 0, v164), p139)
			local v167, _, v168 = v_u_1.quatToEuler(v166)
			v141.j[v158] = { v167, v160 + (v165 - v160) * p139, v168 }
		else
			local v169 = v_u_1.slerp(v_u_1.eulerToQuat(v159, v160, v161), v_u_1.eulerToQuat(v162, v163, v164), p139)
			local v170, v171, v172 = v_u_1.quatToEuler(v169)
			v141.j[v158] = { v170, v171, v172 }
		end
	end
	return v141
end
local function v_u_202(p173, p174) -- name: addOffset
	-- upvalues: (copy) v_u_29, (copy) v_u_1
	if type(p174) == "table" then
		local v175 = p174.rootT
		if type(v175) == "table" then
			local v176 = {}
			local v177 = p173.rootT[1]
			local v178 = p174.rootT[1]
			local v179 = v177 + ((type(v178) ~= "number" or (v178 ~= v178 or (v178 == (1 / 0) or v178 == (-1 / 0)))) and 0 or v178)
			local v180 = p173.rootT[2]
			local v181 = p174.rootT[2]
			local v182 = v180 + ((type(v181) ~= "number" or (v181 ~= v181 or (v181 == (1 / 0) or v181 == (-1 / 0)))) and 0 or v181)
			local v183 = p173.rootT[3]
			local v184 = p174.rootT[3]
			__set_list(v176, 1, {v179, v182, v183 + ((type(v184) ~= "number" or (v184 ~= v184 or (v184 == math.huge or v184 == -math.huge))) and 0 or v184)})
			p173.rootT = v176
		end
		local v185 = p174.j
		if type(v185) == "table" then
			for v186, v187 in p174.j do
				local v188 = p173.j[v186] or { 0, 0, 0 }
				local v189 = v_u_29
				local v190 = v_u_1.eulerToQuat(v188[1], v188[2], v188[3])
				local v191 = v_u_1.eulerToQuat
				local v192 = v187[1]
				local v193 = (type(v192) ~= "number" or (v192 ~= v192 or (v192 == (1 / 0) or v192 == (-1 / 0)))) and 0 or v192
				local v194 = v187[2]
				local v195 = (type(v194) ~= "number" or (v194 ~= v194 or (v194 == (1 / 0) or v194 == (-1 / 0)))) and 0 or v194
				local v196 = v187[3]
				local v197 = v189(v190, v191(v193, v195, (type(v196) ~= "number" or (v196 ~= v196 or (v196 == (1 / 0) or v196 == (-1 / 0)))) and 0 or v196))
				local v198, v199, v200 = v_u_1.quatToEuler(v197)
				if v186 == "Root" then
					local v201 = (v188[2] - v199) / 360 + 0.5
					v199 = v199 + math.floor(v201) * 360
				end
				p173.j[v186] = { v198, v199, v200 }
			end
		end
	end
end
local function v_u_215(p203) -- name: copyPose
	-- upvalues: (copy) v_u_102
	local v204 = {
		["rootT"] = { v_u_102(p203) },
		["j"] = {}
	}
	if type(p203) == "table" then
		local v205 = p203.j
		if type(v205) == "table" then
			for v206, v207 in p203.j do
				local v208 = v204.j
				local v209 = {}
				local v210 = v207[1]
				local v211 = (type(v210) ~= "number" or (v210 ~= v210 or (v210 == (1 / 0) or v210 == (-1 / 0)))) and 0 or v210
				local v212 = v207[2]
				local v213 = (type(v212) ~= "number" or (v212 ~= v212 or (v212 == (1 / 0) or v212 == (-1 / 0)))) and 0 or v212
				local v214 = v207[3]
				__set_list(v209, 1, {v211, v213, (type(v214) ~= "number" or (v214 ~= v214 or (v214 == math.huge or v214 == -math.huge))) and 0 or v214})
				v208[v206] = v209
			end
		end
	end
	return v204
end
v_u_1.copyPose = v_u_215
local function v_u_222(p216, p217) -- name: bracket
	local v218 = #p216
	if v218 == 1 or p217 <= p216[1] then
		return 1, 1, 0
	end
	if p216[v218] <= p217 then
		return v218, v218, 0
	end
	for v219 = 1, v218 - 1 do
		if p217 > p216[v219 + 1] then
			continue
		end
		local v220 = p216[v219 + 1] - p216[v219]
		local v221 = v219 + 1
		if v220 > 0 then
			return v219, v221, (p217 - p216[v219]) / v220
		else
			return v219, v221, 0
		end
	end
	return v218, v218, 0
end
function v_u_1.gridPose(p_u_223, p224, p225) -- name: gridPose
	-- upvalues: (copy) v_u_222, (copy) v_u_1, (copy) v_u_215
	local v226, v227, v228 = v_u_222(p_u_223.u, p224)
	local v_u_229, v_u_230, v_u_231 = v_u_222(p_u_223.p, p225)
	local function v236(p232) -- name: row
		-- upvalues: (copy) v_u_229, (copy) v_u_230, (copy) p_u_223, (ref) v_u_1, (copy) v_u_231
		if v_u_229 == v_u_230 then
			local v233 = v_u_229
			return p_u_223.poses[p232][v233]
		end
		local v234 = v_u_229
		local v235 = v_u_230
		return v_u_1.blendPose(p_u_223.poses[p232][v234], p_u_223.poses[p232][v235], v_u_231)
	end
	if v226 == v227 then
		return v_u_215(v236(v226))
	end
	local v237 = v_u_1.blendPose
	local v238
	if v_u_229 == v_u_230 then
		v238 = p_u_223.poses[v226][v_u_229]
	else
		v238 = v_u_1.blendPose(p_u_223.poses[v226][v_u_229], p_u_223.poses[v226][v_u_230], v_u_231)
	end
	local v239
	if v_u_229 == v_u_230 then
		v239 = p_u_223.poses[v227][v_u_229]
	else
		v239 = v_u_1.blendPose(p_u_223.poses[v227][v_u_229], p_u_223.poses[v227][v_u_230], v_u_231)
	end
	return v237(v238, v239, v228)
end
local function v_u_258(p240) -- name: lhOf
	local v241 = p240.lh
	if type(v241) == "table" then
		if v241[4] == nil then
			local v242 = {}
			local v243 = v241.x
			local v244 = (type(v243) ~= "number" or (v243 ~= v243 or (v243 == (1 / 0) or v243 == (-1 / 0)))) and 0 or v243
			local v245 = v241.y
			local v246 = (type(v245) ~= "number" or (v245 ~= v245 or (v245 == (1 / 0) or v245 == (-1 / 0)))) and 0 or v245
			local v247 = v241.z
			local v248 = (type(v247) ~= "number" or (v247 ~= v247 or (v247 == (1 / 0) or v247 == (-1 / 0)))) and 0 or v247
			local v249 = v241.w
			__set_list(v242, 1, {v244, v246, v248, (type(v249) ~= "number" or (v249 ~= v249 or (v249 == math.huge or v249 == -math.huge))) and 0 or v249})
			return v242
		else
			local v250 = {}
			local v251 = v241[1]
			local v252 = (type(v251) ~= "number" or (v251 ~= v251 or (v251 == (1 / 0) or v251 == (-1 / 0)))) and 0 or v251
			local v253 = v241[2]
			local v254 = (type(v253) ~= "number" or (v253 ~= v253 or (v253 == (1 / 0) or v253 == (-1 / 0)))) and 0 or v253
			local v255 = v241[3]
			local v256 = (type(v255) ~= "number" or (v255 ~= v255 or (v255 == (1 / 0) or v255 == (-1 / 0)))) and 0 or v255
			local v257 = v241[4]
			__set_list(v250, 1, {v252, v254, v256, (type(v257) ~= "number" or (v257 ~= v257 or (v257 == math.huge or v257 == -math.huge))) and 0 or v257})
			return v250
		end
	else
		return nil
	end
end
function v_u_1.sampleClip(p259, p260, p261) -- name: sampleClip
	-- upvalues: (copy) v_u_1, (copy) v_u_202, (copy) v_u_258
	if p259.parts ~= nil then
		local v262 = p259.dur
		local v263 = (type(v262) ~= "number" or (v262 ~= v262 or (v262 == (1 / 0) or v262 == (-1 / 0)))) and 0.3 or v262
		local v264 = math.max(v263, 0.001)
		if p260 < 0 then
			p260 = 0
		elseif v264 < p260 then
			p260 = v264
		end
		local v265, v266
		if p260 < p259.cut then
			v265, v266 = v_u_1.sampleClip(p259.parts[1], p260, p261)
		else
			v265, v266 = v_u_1.sampleClip(p259.parts[2], p260 - p259.cut, p261)
		end
		local v267 = p259.dur
		local v268 = (type(v267) ~= "number" or (v267 ~= v267 or (v267 == (1 / 0) or v267 == (-1 / 0)))) and 0.3 or v267
		v266.u = p260 / math.max(v268, 0.001)
		return v265, v266
	end
	local v269 = p259.keys
	local v270 = p259.dur
	local v271 = (type(v270) ~= "number" or (v270 ~= v270 or (v270 == (1 / 0) or v270 == (-1 / 0)))) and 0.3 or v270
	local v272 = math.max(v271, 0.001)
	if p260 < 0 then
		p260 = 0
	elseif v272 < p260 then
		p260 = v272
	end
	local v273 = 1
	for v274 = 1, #v269 - 1 do
		if v269[v274].t > p260 then
			continue
		end
		v273 = v274
	end
	local v275 = v269[v273]
	local v276 = v273 + 1
	local v277 = #v269
	local v278 = v269[math.min(v276, v277)]
	local v279 = v278.t - v275.t
	local v280
	if v279 > 1e-9 then
		local v281 = (p260 - v275.t) / v279
		v280 = v281 < 0 and 0 or (v281 > 1 and 1 or v281)
	else
		v280 = 1
	end
	local v282 = v278 == v275 and 0 or v280
	local v283 = v275.mix
	local v284 = (type(v283) ~= "number" or (v283 ~= v283 or (v283 == (1 / 0) or v283 == (-1 / 0)))) and 0 or v283
	local v285 = v278.mix
	local v286 = (type(v285) ~= "number" or (v285 ~= v285 or (v285 == (1 / 0) or v285 == (-1 / 0)))) and 1 or v285
	local v287 = v278 == v275 and 1 or v_u_1.ease(v278.ease or v275.ease, v280)
	local v288 = v284 + (v286 - v284) * v287
	local v289 = v_u_1.blendPose(p261(p259.from), p261(p259.to), v288, p259.rootYawPath)
	if v275.add ~= nil or v278.add ~= nil then
		local function v292(p290) -- name: comp
			local v291 = p290.add or {}
			return v291.rootT or { 0, 0, 0 }, v291.j or {}
		end
		local v293, v294 = v292(v275)
		local v295, v296 = v292(v278)
		local v297 = {
			["rootT"] = {},
			["j"] = {}
		}
		for v298 = 1, 3 do
			local v299 = v297.rootT
			local v300 = v293[v298]
			local v301 = (type(v300) ~= "number" or (v300 ~= v300 or (v300 == (1 / 0) or v300 == (-1 / 0)))) and 0 or v300
			local v302 = v295[v298]
			v299[v298] = v301 + (((type(v302) ~= "number" or (v302 ~= v302 or (v302 == (1 / 0) or v302 == (-1 / 0)))) and 0 or v302) - v301) * v282
		end
		local v303 = {}
		for v304 in v294 do
			v303[v304] = true
		end
		for v305 in v296 do
			v303[v305] = true
		end
		for v306 in v303 do
			local v307 = v294[v306] or { 0, 0, 0 }
			local v308 = v296[v306] or { 0, 0, 0 }
			local v309 = v297.j
			local v310 = {}
			local v311 = v307[1]
			local v312 = (type(v311) ~= "number" or (v311 ~= v311 or (v311 == (1 / 0) or v311 == (-1 / 0)))) and 0 or v311
			local v313 = v308[1]
			local v314 = v312 + (((type(v313) ~= "number" or (v313 ~= v313 or (v313 == (1 / 0) or v313 == (-1 / 0)))) and 0 or v313) - v312) * v282
			local v315 = v307[2]
			local v316 = (type(v315) ~= "number" or (v315 ~= v315 or (v315 == (1 / 0) or v315 == (-1 / 0)))) and 0 or v315
			local v317 = v308[2]
			local v318 = v316 + (((type(v317) ~= "number" or (v317 ~= v317 or (v317 == (1 / 0) or v317 == (-1 / 0)))) and 0 or v317) - v316) * v282
			local v319 = v307[3]
			local v320 = (type(v319) ~= "number" or (v319 ~= v319 or (v319 == (1 / 0) or v319 == (-1 / 0)))) and 0 or v319
			local v321 = v308[3]
			__set_list(v310, 1, {v314, v318, v320 + (((type(v321) ~= "number" or (v321 ~= v321 or (v321 == math.huge or v321 == -math.huge))) and 0 or v321) - v320) * v282})
			v309[v306] = v310
		end
		v_u_202(v289, v297)
	end
	local v322 = v275.aimW
	local v323 = (type(v322) ~= "number" or (v322 ~= v322 or (v322 == (1 / 0) or v322 == (-1 / 0)))) and 0 or v322
	local v324 = v278.aimW
	local v325 = v323 + (((type(v324) ~= "number" or (v324 ~= v324 or (v324 == (1 / 0) or v324 == (-1 / 0)))) and 0 or v324) - v323) * v282
	local v326 = nil
	local v327 = v_u_258(v275)
	local v328 = v_u_258(v278)
	if v327 ~= nil or v328 ~= nil then
		local v329 = v327 or v328
		local v330 = v327 or {
			v329[1],
			v329[2],
			v329[3],
			0
		}
		local v331 = v328 or {
			v329[1],
			v329[2],
			v329[3],
			0
		}
		local v332 = v330[4]
		local v333 = v332 + (v331[4] - v332) * v282
		if v333 > 0.001 then
			v326 = {}
			local v334 = v330[1]
			v326.x = v334 + (v331[1] - v334) * v282
			local v335 = v330[2]
			v326.y = v335 + (v331[2] - v335) * v282
			local v336 = v330[3]
			v326.z = v336 + (v331[3] - v336) * v282
			v326.w = v333
		end
	end
	return v289, {
		["aimW"] = v325 < 0 and 0 or (v325 > 1 and 1 or v325),
		["oneHand"] = v275.oneHand == true,
		["lh"] = v326,
		["mix"] = v288,
		["u"] = p260 / v272
	}
end
function v_u_1.viaClip(p337, p338, p339, p340) -- name: viaClip
	-- upvalues: (copy) v_u_2
	local v341 = p337.dur
	local v342 = v_u_2.OUT_DUR
	if type(v341) == "number" and (v341 == v341 and (v341 ~= (1 / 0) and v341 ~= (-1 / 0))) then
		v342 = v341
	end
	local v343 = {
		["dur"] = nil,
		["cut"] = nil,
		["from"] = nil,
		["to"] = nil,
		["via"] = true,
		["parts"] = nil,
		["keys"] = nil
	}
	local v344 = p338.dur
	local v345 = v_u_2.IN_DUR
	if type(v344) == "number" and (v344 == v344 and (v344 ~= (1 / 0) and v344 ~= (-1 / 0))) then
		v345 = v344
	end
	v343.dur = v342 + v345
	v343.cut = v342
	v343.from = p339
	v343.to = p340
	v343.parts = { p337, p338 }
	v343.keys = {}
	return v343
end
function v_u_1.viaProgress(p346, p347) -- name: viaProgress
	local v348 = p346.clip
	if p346.mode ~= "switch" or (v348 == nil or v348.parts == nil) then
		return nil
	end
	local v349 = p347 - p346.clipT0
	local v350 = v348.cut
	local v351 = v349 - ((type(v350) ~= "number" or (v350 ~= v350 or (v350 == (1 / 0) or v350 == (-1 / 0)))) and 0 or v350)
	local v352 = v348.dur
	local v353 = (type(v352) ~= "number" or (v352 ~= v352 or (v352 == (1 / 0) or v352 == (-1 / 0)))) and 0.3 or v352
	local v354 = v348.cut
	local v355 = v353 - ((type(v354) ~= "number" or (v354 ~= v354 or (v354 == (1 / 0) or v354 == (-1 / 0)))) and 0 or v354)
	local v356 = v351 / math.max(v355, 0.001)
	return v356 < 0 and 0 or (v356 > 1 and 1 or v356)
end
function v_u_1.defaultClip(p357, p358, p359, p360, p361, p362) -- name: defaultClip
	local v363 = {
		["dur"] = nil,
		["from"] = nil,
		["to"] = nil,
		["rootYawPath"] = nil,
		["default"] = true,
		["keys"] = nil,
		["dur"] = p359,
		["from"] = p357,
		["to"] = p358,
		["rootYawPath"] = p362 or "short",
		["keys"] = {
			{
				["t"] = 0,
				["mix"] = 0,
				["aimW"] = nil,
				["aimW"] = p360
			},
			{
				["t"] = nil,
				["mix"] = 1,
				["ease"] = "inOutCubic",
				["aimW"] = nil,
				["t"] = p359,
				["aimW"] = p361
			}
		}
	}
	return v363
end
function v_u_1.inRange(p364, p365) -- name: inRange
	local v366 = p364.lo
	local v367 = (type(v366) ~= "number" or (v366 ~= v366 or (v366 == (1 / 0) or v366 == (-1 / 0)))) and 0 or v366
	local v368 = p364.hi
	local v369 = (type(v368) ~= "number" or (v368 ~= v368 or (v368 == (1 / 0) or v368 == (-1 / 0)))) and 0 or v368
	return v369 - v367 >= 360 and true or v367 + (p365 - v367) % 360 <= v369
end
local v_u_370 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_420(p371) -- name: bridged
	-- upvalues: (copy) v_u_370, (copy) v_u_2
	local v372 = v_u_370[p371]
	if v372 == nil then
		local v373 = {}
		for v374, v375 in p371 do
			if type(v375) ~= "table" then
				continue
			end
			local v376 = v375.sector
			if type(v376) ~= "table" then
				continue
			end
			local v377 = v375.sector.lo
			local v378 = (type(v377) ~= "number" or (v377 ~= v377 or (v377 == (1 / 0) or v377 == (-1 / 0)))) and 0 or v377
			local v379 = v375.sector.hi
			local v380 = (type(v379) ~= "number" or (v379 ~= v379 or (v379 == (1 / 0) or v379 == (-1 / 0)))) and 0 or v379
			if v380 - v378 >= 359.999999999 then
				continue
			end
			table.insert(v373, {
				["name"] = v374,
				["lo"] = v378,
				["hi"] = v380
			})
		end
		local v381 = {}
		local v382 = {}
		if #v373 >= 2 then
			for _, v383 in v373 do
				local v384 = (1 / 0)
				local v385 = nil
				for _, v386 in v373 do
					if v386 == v383 then
						continue
					end
					local v387 = p371[v386.name].sector
					local v388 = v383.hi
					local v389 = v387.lo
					local v390 = (type(v389) ~= "number" or (v389 ~= v389 or (v389 == (1 / 0) or v389 == (-1 / 0)))) and 0 or v389
					local v391 = v387.hi
					local v392 = (type(v391) ~= "number" or (v391 ~= v391 or (v391 == (1 / 0) or v391 == (-1 / 0)))) and 0 or v391
					if v392 - v390 >= 360 and true or v390 + (v388 - v390) % 360 <= v392 then
						continue
					end
					local v393 = (v386.lo - v383.hi) % 360
					if v393 >= v384 then
						continue
					end
					v385 = v386
					v384 = v393
				end
				if v385 == nil or (v384 <= 1e-9 or v384 > v_u_2.BRIDGE_MAX) then
					break
				end
				local v394 = v384 / 2 + v_u_2.BRIDGE_OVERLAP
				local v395 = v383.name
				local v396 = v382[v383.name] or 0
				v382[v395] = math.max(v396, v394)
				local v397 = v385.name
				local v398 = v381[v385.name] or 0
				v381[v397] = math.max(v398, v394)
			end
		end
		if next(v381) == nil and next(v382) == nil then
			v_u_370[p371] = false
			return p371
		end
		local v399 = {}
		for v400, v401 in p371 do
			local v402 = v381[v400] or 0
			local v403 = v382[v400] or 0
			if v402 > 0 or v403 > 0 then
				local v404 = v401.sector.lo
				local v405 = (type(v404) ~= "number" or (v404 ~= v404 or (v404 == (1 / 0) or v404 == (-1 / 0)))) and 0 or v404
				local v406 = v401.sector.hi
				local v407 = (type(v406) ~= "number" or (v406 ~= v406 or (v406 == (1 / 0) or v406 == (-1 / 0)))) and 0 or v406
				local v408 = v401.enter
				local v409
				if type(v408) == "table" then
					v409 = v401.enter
				else
					local v410 = v401.sector.lo
					local v411 = (type(v410) ~= "number" or (v410 ~= v410 or (v410 == (1 / 0) or v410 == (-1 / 0)))) and 0 or v410
					local v412 = v401.sector.hi
					local v413 = (type(v412) ~= "number" or (v412 ~= v412 or (v412 == (1 / 0) or v412 == (-1 / 0)))) and 0 or v412
					v409 = {
						["lo"] = v411 + v_u_2.ENTER_BAND,
						["hi"] = v413 - v_u_2.ENTER_BAND
					}
				end
				local v414 = table.clone(v401)
				v414.sector = {
					["lo"] = v405 - v402,
					["hi"] = v407 + v403
				}
				local v415 = {}
				local v416 = v409.lo
				local v417 = v405 + v_u_2.ENTER_BAND
				if type(v416) == "number" and (v416 == v416 and (v416 ~= (1 / 0) and v416 ~= (-1 / 0))) then
					v417 = v416
				end
				v415.lo = v417 - v402
				local v418 = v409.hi
				local v419 = v407 - v_u_2.ENTER_BAND
				if type(v418) == "number" and (v418 == v418 and (v418 ~= (1 / 0) and v418 ~= (-1 / 0))) then
					v419 = v418
				end
				v415.hi = v419 + v403
				v414.enter = v415
				v414.bridge = {
					["lo"] = v402,
					["hi"] = v403
				}
				v399[v400] = v414
			else
				v399[v400] = v401
			end
		end
		v_u_370[p371] = v399
		return v399
	elseif v372 == false then
		return p371
	else
		return v372
	end
end
v_u_1.bridged = v_u_420
function v_u_1.stancesOf(p421, p422, p423) -- name: stancesOf
	-- upvalues: (copy) v_u_420, (copy) v_u_1, (copy) v_u_2
	if type(p421) == "table" then
		local v424 = p421.stances
		if type(v424) == "table" and next(p421.stances) ~= nil then
			return v_u_420(p421.stances), false
		end
	end
	local v425 = v_u_1.LEGACY_NEUTRAL[p423]
	if not v425 then
		if p422 then
			p422 = p422.yaw
		end
		v425 = (type(p422) ~= "number" or (p422 ~= p422 or (p422 == (1 / 0) or p422 == (-1 / 0)))) and 90 or p422
	end
	local v426 = v_u_2.LEGACY_HALF
	local v427 = {
		["WIN"] = {
			["legacy"] = true,
			["neutral"] = nil,
			["sector"] = nil,
			["enter"] = nil,
			["pitch"] = nil,
			["root"] = nil,
			["waist"] = nil,
			["resid"] = nil,
			["stanceMul"] = 0.5,
			["neutral"] = v425,
			["sector"] = {
				["lo"] = v425 - v426,
				["hi"] = v425 + v426
			},
			["enter"] = {
				["lo"] = v425 - v426 + v_u_2.ENTER_BAND,
				["hi"] = v425 + v426 - v_u_2.ENTER_BAND
			},
			["pitch"] = {
				["lo"] = -30,
				["hi"] = 30
			},
			["root"] = {
				["share"] = 0.2,
				["min"] = -13,
				["max"] = 13
			},
			["waist"] = {
				["share"] = 0.55,
				["min"] = -36,
				["max"] = 36
			},
			["resid"] = {
				["long"] = 30,
				["pistol"] = 45,
				["twin"] = 20
			}
		}
	}
	return v427, true
end
function v_u_1.stanceArc(p428, p429) -- name: stanceArc
	-- upvalues: (ref) v_u_3
	local v430 = p429.sector.lo
	local v431 = (type(v430) ~= "number" or (v430 ~= v430 or (v430 == (1 / 0) or v430 == (-1 / 0)))) and 0 or v430
	local v432 = p429.sector.hi
	local v433 = (type(v432) ~= "number" or (v432 ~= v432 or (v432 == (1 / 0) or v432 == (-1 / 0)))) and 0 or v432
	local v434 = v_u_3.narrow
	local v435 = (v431 + v433) * 0.5
	local v436 = (v433 - v431) * 0.5
	local v437 = v434(p428, v435, (math.min(180, v436)))
	if v433 - v431 >= 359.999999999 then
		v437.half = 180
	end
	local v438 = p429.pitch
	if type(v438) == "table" then
		local v439 = p428.up
		local v440 = (type(v439) ~= "number" or (v439 ~= v439 or (v439 == (1 / 0) or v439 == (-1 / 0)))) and 45 or v439
		local v441 = p429.pitch.hi
		local v442 = (type(v441) ~= "number" or (v441 ~= v441 or (v441 == (1 / 0) or v441 == (-1 / 0)))) and 45 or v441
		v437.up = math.min(v440, v442)
		local v443 = p428.down
		local v444 = (type(v443) ~= "number" or (v443 ~= v443 or (v443 == (1 / 0) or v443 == (-1 / 0)))) and 35 or v443
		local v445 = p429.pitch.lo
		local v446 = -((type(v445) ~= "number" or (v445 ~= v445 or (v445 == (1 / 0) or v445 == (-1 / 0)))) and -35 or v445)
		v437.down = math.min(v444, v446)
		local v447 = p429.pitch.downAt
		if type(v447) == "table" then
			v437.downAt = p429.pitch.downAt
		end
	end
	return v437
end
function v_u_1.circleUnion(p448) -- name: circleUnion
	local v449 = {}
	for _, v450 in p448 do
		if v450[2] - v450[1] >= 359.999999 then
			return nil, nil
		end
		local v451 = v450[1] % 360
		local v452 = { v451, v451 + (v450[2] - v450[1]) }
		table.insert(v449, v452)
		local v453 = { v451 + 360, v451 + 360 + (v450[2] - v450[1]) }
		table.insert(v449, v453)
	end
	table.sort(v449, function(p454, p455)
		return p454[1] < p455[1]
	end)
	local v456 = v449[1][2]
	local v457 = 0
	local v458 = nil
	for v459 = 2, #v449 do
		local v460 = v449[v459]
		local v461
		if v460[1] > v456 + 1e-6 then
			v461 = v460[1] - v456
			if v457 + 1e-9 < v461 then
				v458 = v460[1]
			else
				v461 = v457
			end
		else
			v461 = v457
		end
		local v462 = v460[2]
		v456 = math.max(v456, v462)
		v457 = v461
	end
	if v458 == nil then
		return nil, nil
	end
	local v463 = v458 % 360
	return v463, v463 + 360 - v457
end
function v_u_1.hull(p464, p465, p466) -- name: hull
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	if type(p464) ~= "table" or v_u_3 == nil then
		return p464
	end
	local v467 = {}
	local v468 = 0
	local v469 = 0
	for _, v470 in v_u_1.stancesOf(p465, p464, p466) do
		local v471 = v470.sector.lo
		local v472 = (type(v471) ~= "number" or (v471 ~= v471 or (v471 == (1 / 0) or v471 == (-1 / 0)))) and 0 or v471
		local v473 = v470.sector.hi
		local v474 = (type(v473) ~= "number" or (v473 ~= v473 or (v473 == (1 / 0) or v473 == (-1 / 0)))) and 0 or v473
		table.insert(v467, { v472, v474 })
		local v475 = v470.pitch
		if v475 then
			v475 = v470.pitch.hi
		end
		local v476 = (type(v475) ~= "number" or (v475 ~= v475 or (v475 == (1 / 0) or v475 == (-1 / 0)))) and 45 or v475
		v468 = math.max(v468, v476)
		local v477 = v470.pitch
		if v477 then
			v477 = v470.pitch.lo
		end
		local v478 = -((type(v477) ~= "number" or (v477 ~= v477 or (v477 == (1 / 0) or v477 == (-1 / 0)))) and -35 or v477)
		v469 = math.max(v469, v478)
	end
	local v479, v480 = v_u_1.circleUnion(v467)
	if v479 == nil or v480 == nil then
		v480 = 360
		v479 = 0
	end
	local v481
	if v480 - v479 >= 359.999999 then
		v481 = table.clone(p464)
		v481.half = 180
	else
		v481 = v_u_3.narrow(p464, (v479 + v480) * 0.5, (v480 - v479) * 0.5)
		if not v_u_3.full(p464) then
			local v482 = p464.yaw
			local v483 = (type(v482) ~= "number" or (v482 ~= v482 or (v482 == (1 / 0) or v482 == (-1 / 0)))) and 0 or v482
			local v484 = p464.half
			local v485 = (type(v484) ~= "number" or (v484 ~= v484 or (v484 == (1 / 0) or v484 == (-1 / 0)))) and 180 or v484
			local v486 = (v479 + v480) * 0.5
			local v487 = (v480 - v479) * 0.5
			local v488 = v486 - v483
			local v489 = (v488 + 180) / 360
			local v490 = v488 - math.floor(v489) * 360
			if v485 < math.abs(v490) + v487 then
				local v491 = v490 - v487
				local v492 = -v485
				local v493 = math.max(v491, v492)
				local v494 = v490 + v487
				local v495 = math.min(v494, v485)
				local v496 = v_u_3.narrow
				local v497 = v483 + (v493 + v495) * 0.5
				local v498 = (v495 - v493) * 0.5
				v481 = v496(p464, v497, (math.max(v498, 1)))
			end
		end
	end
	local v499 = p464.up
	local v500 = (type(v499) ~= "number" or (v499 ~= v499 or (v499 == (1 / 0) or v499 == (-1 / 0)))) and 45 or v499
	v481.up = math.min(v500, v468)
	local v501 = p464.down
	local v502 = (type(v501) ~= "number" or (v501 ~= v501 or (v501 == (1 / 0) or v501 == (-1 / 0)))) and 35 or v501
	v481.down = math.min(v502, v469)
	v481.downAt = p464.downAt
	return v481
end
function v_u_1.poseStep(p503, p504) -- name: poseStep
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	local v505 = 0
	for v506, v507 in p503.j do
		local v508 = p504.j[v506]
		if v508 == nil then
			continue
		end
		local v509 = v_u_1.eulerToQuat
		local v510 = v507[1]
		local v511 = (type(v510) ~= "number" or (v510 ~= v510 or (v510 == (1 / 0) or v510 == (-1 / 0)))) and 0 or v510
		local v512 = v507[2]
		local v513 = (type(v512) ~= "number" or (v512 ~= v512 or (v512 == (1 / 0) or v512 == (-1 / 0)))) and 0 or v512
		local v514 = v507[3]
		local v515 = v509(v511, v513, (type(v514) ~= "number" or (v514 ~= v514 or (v514 == (1 / 0) or v514 == (-1 / 0)))) and 0 or v514)
		local v516 = v_u_1.eulerToQuat
		local v517 = v508[1]
		local v518 = (type(v517) ~= "number" or (v517 ~= v517 or (v517 == (1 / 0) or v517 == (-1 / 0)))) and 0 or v517
		local v519 = v508[2]
		local v520 = (type(v519) ~= "number" or (v519 ~= v519 or (v519 == (1 / 0) or v519 == (-1 / 0)))) and 0 or v519
		local v521 = v508[3]
		local v522 = v516(v518, v520, (type(v521) ~= "number" or (v521 ~= v521 or (v521 == (1 / 0) or v521 == (-1 / 0)))) and 0 or v521)
		local v523 = v515[1] * v522[1] + v515[2] * v522[2] + v515[3] * v522[3] + v515[4] * v522[4]
		local v524 = math.abs(v523)
		local v525 = 1 - v524 * v524
		local v526 = math.max(0, v525)
		local v527 = math.sqrt(v526)
		local v528 = v_u_7((math.atan2(v527, v524))) * 2
		v505 = math.max(v505, v528)
	end
	return v505
end
function v_u_1.capFor(p529, p530, p531) -- name: capFor
	-- upvalues: (copy) v_u_1
	if type(p529) ~= "table" then
		p529 = v_u_1.CAPS
	end
	if p531 == true then
		local v532 = p529.twin
		local v533 = v_u_1.CAPS.twin
		if type(v532) == "number" and (v532 == v532 and (v532 ~= (1 / 0) and v532 ~= (-1 / 0))) then
			return v532
		else
			return v533
		end
	elseif p530 == "pistol" or p530 == "revolver" then
		local v534 = p529.pistol
		local v535 = v_u_1.CAPS.pistol
		if type(v534) == "number" and (v534 == v534 and (v534 ~= (1 / 0) and v534 ~= (-1 / 0))) then
			return v534
		else
			return v535
		end
	else
		local v536 = p529.long
		local v537 = v_u_1.CAPS.long
		if type(v536) == "number" and (v536 == v536 and (v536 ~= (1 / 0) and v536 ~= (-1 / 0))) then
			return v536
		else
			return v537
		end
	end
end
function v_u_1.recoilFor(p538, p539) -- name: recoilFor
	-- upvalues: (copy) v_u_1
	local v540
	if type(p538) == "table" then
		local v541 = p538.recoil
		if type(v541) == "table" then
			v540 = p538.recoil
		else
			v540 = nil
		end
	else
		v540 = nil
	end
	local v542 = type(p539) ~= "string" and "rifle" or p539
	return v540 and v540[v542] or (v_u_1.RECOIL[v542] or v_u_1.RECOIL.rifle)
end
function v_u_1.newState() -- name: newState
	return {
		["mode"] = "sit",
		["stance"] = nil,
		["stanceT0"] = -1000000000,
		["want"] = nil,
		["wantT0"] = 0,
		["clip"] = nil,
		["clipName"] = nil,
		["clipT0"] = 0,
		["clipTo"] = nil,
		["clipFrom"] = nil,
		["clipPath"] = nil,
		["cutPose"] = nil,
		["rawPhi"] = nil,
		["rawTheta"] = 0,
		["holdHull"] = 1,
		["holdStance"] = 1,
		["bodyDelta"] = nil,
		["bodyStance"] = nil,
		["fromPhi"] = nil,
		["fromTheta"] = 0,
		["follow"] = 0,
		["followV"] = 0,
		["motion"] = {
			["roll"] = 0,
			["rollV"] = 0,
			["pitch"] = 0,
			["pitchV"] = 0,
			["lift"] = 0,
			["liftV"] = 0,
			["ax"] = 0,
			["ay"] = 0,
			["az"] = 0
		},
		["recoil"] = {
			["x"] = 0,
			["v"] = 0,
			["head"] = 0,
			["headV"] = 0
		},
		["kickSeen"] = nil,
		["flinch"] = 0,
		["feedback"] = 0,
		["shots"] = {},
		["still"] = 0,
		["idleAimPhi"] = nil,
		["idleAimTheta"] = nil,
		["lastOut"] = nil,
		["tuck"] = 0,
		["t"] = 0
	}
end
local function v_u_554(p543, p544) -- name: deltaOf
	local v545 = p543.sector.lo
	local v546 = (type(v545) ~= "number" or (v545 ~= v545 or (v545 == (1 / 0) or v545 == (-1 / 0)))) and 0 or v545
	local v547 = p543.sector.hi
	local v548 = (type(v547) ~= "number" or (v547 ~= v547 or (v547 == (1 / 0) or v547 == (-1 / 0)))) and 0 or v547
	if v548 - v546 >= 359.999999999 then
		local v549 = p543.neutral
		local v550 = p544 - ((type(v549) ~= "number" or (v549 ~= v549 or (v549 == (1 / 0) or v549 == (-1 / 0)))) and 0 or v549)
		local v551 = (v550 + 180) / 360
		return v550 - math.floor(v551) * 360
	else
		local v552 = v546 + (p544 - v546) % 360
		if v548 < v552 then
			if v552 - v548 > v546 + 360 - v552 then
				v548 = v546
			end
		else
			v548 = v552
		end
		local v553 = p543.neutral
		return v548 - ((type(v553) ~= "number" or (v553 ~= v553 or (v553 == (1 / 0) or v553 == (-1 / 0)))) and 0 or v553)
	end
end
v_u_1.deltaOf = v_u_554
local function v_u_579(p555, p556, p557, p558) -- name: shares
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v559 = p556.root or {}
	local v560 = v559.follow
	if type(v560) == "table" then
		if p558 ~= nil then
			local v561 = v_u_1.spring
			local v562 = p555.follow
			local v563 = p555.followV
			local v564 = v559.follow.omega
			local v565 = v_u_2.FOLLOW_OMEGA
			if type(v564) == "number" and (v564 == v564 and (v564 ~= (1 / 0) and v564 ~= (-1 / 0))) then
				v565 = v564
			end
			local v566, v567 = v561(v562, v563, p557, v565, 1, p558)
			local v568 = v559.follow.rate
			local v569 = v_u_2.FOLLOW_RATE
			if type(v568) == "number" and (v568 == v568 and (v568 ~= (1 / 0) and v568 ~= (-1 / 0))) then
				v569 = v568
			end
			local v570 = v569 * p558
			local v571 = p555.follow - v570
			local v572 = p555.follow + v570
			if v566 < v571 then
				v566 = v571
			elseif v572 < v566 then
				v566 = v572
			end
			p555.follow = v566
			p555.followV = v567
		end
		return p555.follow, p557 - p555.follow
	end
	if p556.grid ~= nil then
		return 0, p557
	end
	local v573 = v559.share
	local v574 = p557 * ((type(v573) ~= "number" or (v573 ~= v573 or (v573 == (1 / 0) or v573 == (-1 / 0)))) and 0.2 or v573)
	local v575 = v559.min
	local v576 = (type(v575) ~= "number" or (v575 ~= v575 or (v575 == (1 / 0) or v575 == (-1 / 0)))) and -13 or v575
	local v577 = v559.max
	local v578 = (type(v577) ~= "number" or (v577 ~= v577 or (v577 == (1 / 0) or v577 == (-1 / 0)))) and 13 or v577
	if v574 < v576 then
		v574 = v576
	elseif v578 < v574 then
		v574 = v578
	end
	return v574, p557
end
function v_u_1.stancePose(p580, _, p581, p582, p583, p584, p585, p586) -- name: stancePose
	-- upvalues: (copy) v_u_554, (copy) v_u_579, (copy) v_u_1, (copy) v_u_215, (copy) v_u_2, (copy) v_u_94
	local v587 = p581[p582]
	local v588 = v_u_554(v587, p583)
	local v589, v590 = v_u_579(p580, v587, v588, p586)
	local v591 = {
		["Waist"] = 0,
		["Neck"] = 0
	}
	local v592 = {}
	local v593 = v587.root or {}
	local v594
	if v587.grid == nil then
		v594 = v589
	else
		local v595 = v593.follow
		if type(v595) == "table" then
			v594 = v589
		else
			local v596 = v593.share
			v594 = v588 * ((type(v596) ~= "number" or (v596 ~= v596 or (v596 == (1 / 0) or v596 == (-1 / 0)))) and 0 or v596)
			local v597 = v593.min
			local v598 = (type(v597) ~= "number" or (v597 ~= v597 or (v597 == (1 / 0) or v597 == (-1 / 0)))) and -60 or v597
			local v599 = v593.max
			local v600 = (type(v599) ~= "number" or (v599 ~= v599 or (v599 == (1 / 0) or v599 == (-1 / 0)))) and 60 or v599
			if v594 < v598 then
				v594 = v598
			elseif v600 < v594 then
				v594 = v600
			end
		end
	end
	local v601
	if v587.grid == nil then
		v601 = v_u_215(p585.legacyPose or p585.sit)
		local v602 = v587.waist
		if v602 then
			v602 = v587.waist.share
		end
		local v603 = v588 * ((type(v602) ~= "number" or (v602 ~= v602 or (v602 == (1 / 0) or v602 == (-1 / 0)))) and 0.55 or v602)
		local v604 = v587.waist
		if v604 then
			v604 = v587.waist.min
		end
		local v605 = (type(v604) ~= "number" or (v604 ~= v604 or (v604 == (1 / 0) or v604 == (-1 / 0)))) and -36 or v604
		local v606 = v587.waist
		if v606 then
			v606 = v587.waist.max
		end
		local v607 = (type(v606) ~= "number" or (v606 ~= v606 or (v606 == (1 / 0) or v606 == (-1 / 0)))) and 36 or v606
		if v603 < v605 then
			v603 = v605
		elseif v607 < v603 then
			v603 = v607
		end
		local v608 = v588 - v589 - v603
		v591.Waist = -v603
		local v609 = -v_u_2.NECK_MAX
		local v610 = v_u_2.NECK_MAX
		if v608 < v609 then
			v608 = v609
		elseif v610 < v608 then
			v608 = v610
		end
		v591.Neck = -v608
		local v611 = v_u_2.WAIST_PITCH * p584
		local v612 = -v_u_2.WAIST_PITCH_MAX
		local v613 = v_u_2.WAIST_PITCH_MAX
		if v611 < v612 then
			v611 = v612
		elseif v613 < v611 then
			v611 = v613
		end
		v592.Waist = { v611, 0, 0 }
		v592.Neck = { v_u_2.NECK_PITCH * p584, 0, 0 }
	else
		v601 = v_u_1.gridPose(v587.grid, v590, p584)
	end
	local v614, v615, v616 = v_u_94(v601, "Root")
	v601.j.Root = { v614, v615 - v589, v616 }
	return v601, {
		["twist"] = v591,
		["add"] = v592,
		["pelvis"] = v594,
		["delta"] = v588,
		["u"] = v590
	}
end
function v_u_1.info(p617) -- name: info
	local v618 = {}
	local v619
	if p617.active then
		v619 = p617.arc
	else
		v619 = nil
	end
	v618.arc = v619
	v618.canFire = p617.canFire
	v618.busy = p617.busy
	v618.off = p617.off
	v618.mode = p617.mode
	v618.stance = p617.stance
	v618.t = p617.t
	v618.phi = p617.phi
	v618.theta = p617.theta
	v618.phiTarget = p617.phiTarget
	v618.side = p617.side
	v618.armPhi = p617.armPhi
	v618.weaponPhi = p617.weaponPhi
	v618.lag = p617.lag
	v618.hull = p617.hull
	return v618
end
local function v_u_645(p620, p621) -- name: chestHeading
	-- upvalues: (copy) v_u_94, (copy) v_u_29, (copy) v_u_1
	if p620.legacy == true or (type(p621) ~= "table" or (p620.pose == nil or p620.phiTarget == nil)) then
		return nil
	end
	local v622 = p620.pose
	local v623 = p620.motion or {
		["rx"] = 0,
		["rz"] = 0
	}
	local v624 = p620.add or {}
	local v625 = p620.twist
	if v625 then
		v625 = p620.twist.Waist
	end
	local v626 = (type(v625) ~= "number" or (v625 ~= v625 or (v625 == (1 / 0) or v625 == (-1 / 0)))) and 0 or v625
	local v627, v628, v629 = v_u_94(v622, "Root")
	local v630 = v_u_29
	local v631 = v_u_1.eulerToQuat
	local v632 = v623.rx
	local v633 = (type(v632) ~= "number" or (v632 ~= v632 or (v632 == (1 / 0) or v632 == (-1 / 0)))) and 0 or v632
	local v634 = v623.rz
	local v635 = v630(v631(v633, 0, (type(v634) ~= "number" or (v634 ~= v634 or (v634 == (1 / 0) or v634 == (-1 / 0)))) and 0 or v634), v_u_1.eulerToQuat(v627, v628, v629))
	local v636, v637, v638 = v_u_94(v622, "Waist")
	local v639 = v624.Waist
	if type(v639) == "table" then
		local v640 = v639[1]
		v636 = v636 + ((type(v640) ~= "number" or (v640 ~= v640 or (v640 == (1 / 0) or v640 == (-1 / 0)))) and 0 or v640)
		local v641 = v639[2]
		v637 = v637 + ((type(v641) ~= "number" or (v641 ~= v641 or (v641 == (1 / 0) or v641 == (-1 / 0)))) and 0 or v641)
		local v642 = v639[3]
		v638 = v638 + ((type(v642) ~= "number" or (v642 ~= v642 or (v642 == (1 / 0) or v642 == (-1 / 0)))) and 0 or v642)
	end
	local v643 = v_u_29(v_u_29(v635, v_u_1.eulerToQuat(v636, v637, v638)), v_u_1.eulerToQuat(0, v626, 0))
	local _, v644 = v_u_1.quatToEuler(v643)
	return v644 - v626
end
function v_u_1.chestRho(p646, p647) -- name: chestRho
	-- upvalues: (copy) v_u_645
	local v648 = v_u_645(p646, p647)
	if v648 == nil then
		return nil
	end
	local v649 = -p646.phiTarget
	local v650 = p647.seatYaw
	local v651 = v649 - ((type(v650) ~= "number" or (v650 ~= v650 or (v650 == (1 / 0) or v650 == (-1 / 0)))) and 0 or v650)
	local v652 = (v651 + 180) / 360
	local v653 = v651 - math.floor(v652) * 360 - v648
	local v654 = (v653 + 180) / 360
	return v653 - math.floor(v654) * 360
end
function v_u_1.weaponPhi(p655, p656) -- name: weaponPhi
	-- upvalues: (copy) v_u_645, (copy) v_u_1
	local v657 = v_u_645(p655, p656)
	if v657 == nil then
		return nil
	end
	local v658 = p656.seatYaw
	local v659 = (type(v658) ~= "number" or (v658 ~= v658 or (v658 == (1 / 0) or v658 == (-1 / 0)))) and 0 or v658
	local v660 = p655.armPhi or p655.phiTarget
	local v661 = p655.rhoCap
	local v662 = v_u_1.CAPS.long
	if type(v661) ~= "number" or (v661 ~= v661 or (v661 == (1 / 0) or v661 == (-1 / 0))) then
		v661 = v662
	end
	local v663 = -v660 - v659
	local v664 = (v663 + 180) / 360
	local v665 = v663 - math.floor(v664) * 360 - v657
	local v666 = (v665 + 180) / 360
	local v667 = v665 - math.floor(v666) * 360
	local v668 = -v661
	if v667 < v668 then
		v667 = v668
	elseif v661 < v667 then
		v667 = v661
	end
	local v669 = -(v657 + v667) - v659
	local v670 = (v669 + 180) / 360
	return v669 - math.floor(v670) * 360
end
local function v_u_676(p671) -- name: winOf
	if type(p671) == "table" then
		local v672 = p671.window
		if type(v672) == "table" then
			local v673 = p671.window.lo
			if type(v673) == "number" then
				local v674 = p671.window.hi
				if type(v674) == "number" then
					return p671.window.lo, p671.window.hi
				end
			end
		end
		local v675 = p671.span
		if type(v675) == "number" then
			return -p671.span, p671.span
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
v_u_1.winOf = v_u_676
v_u_1.QUICK = "_Q"
local function v_u_691(p677, p678, p679) -- name: pickName
	-- upvalues: (copy) v_u_1, (copy) v_u_676
	if type(p678) == "string" then
		local v680
		if type(p677) == "table" then
			local v681 = p677.clips
			v680 = type(v681) ~= "table" and {} or p677.clips
		else
			v680 = {}
		end
		local v682 = 1000000000
		local v683 = nil
		for _, v684 in { p678, p678 .. v_u_1.QUICK } do
			local v685 = v680[v684]
			if type(v685) ~= "table" or (v685.from == nil or v685.keys == nil) then
				continue
			end
			local v686, v687 = v_u_676(v685)
			local v688
			if v686 == nil or v687 == nil then
				v688 = 0
			else
				local v689 = v686 - p679
				local v690 = p679 - v687
				v688 = math.max(v689, v690, 0)
			end
			if v688 >= v682 - 1e-6 then
				continue
			end
			v683 = v684
			v682 = v688
		end
		if v683 == nil then
			return v683, 0
		else
			return v683, v682
		end
	else
		return nil, 0
	end
end
v_u_1.pickName = v_u_691
local function v_u_701(p692, p693, p694, p695, p696, p697) -- name: jointLimited
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v698 = v_u_2.JOINT_RATE * (p697 or 1) * p696
	local v699 = v_u_1.gridPose(p692, p693, p695)
	for _ = 1, 5 do
		local v700 = v_u_1.poseStep(v699, v_u_1.gridPose(p692, p693 + p694, p695))
		if v700 <= v698 then
			break
		end
		p694 = p694 * v698 / v700 * 0.95
	end
	return p694
end
function v_u_1.recoilVal(p702, p703) -- name: recoilVal
	if p703 <= 0 then
		return 0
	end
	local v704 = p702.rise
	local v705 = (type(v704) ~= "number" or (v704 ~= v704 or (v704 == (1 / 0) or v704 == (-1 / 0)))) and 0.03 or v704
	local v706 = p702.zeta
	local v707 = (type(v706) ~= "number" or (v706 ~= v706 or (v706 == (1 / 0) or v706 == (-1 / 0)))) and 0.5 or v706
	local v708 = v707 < 0.05 and 0.05 or (v707 > 0.95 and 0.95 or v707)
	local v709 = p702.omega
	local v710 = p702.dur
	local v711 = ((type(v710) ~= "number" or (v710 ~= v710 or (v710 == (1 / 0) or v710 == (-1 / 0)))) and 0.2 or v710) * 1.2
	local v712 = 6.283185307179586 / math.max(v711, 0.05)
	if type(v709) ~= "number" or (v709 ~= v709 or (v709 == (1 / 0) or v709 == (-1 / 0))) then
		v709 = v712
	end
	if p703 < v705 then
		return p703 / v705
	end
	local v713 = p703 - v705
	local v714 = 1 - v708 * v708
	local v715 = v709 * math.sqrt(v714)
	local v716 = -v708 * v709 * v713
	local v717 = math.exp(v716)
	local v718 = v715 * v713
	local v719 = math.cos(v718)
	local v720 = v708 * v709 / v715
	local v721 = v715 * v713
	return v717 * (v719 + v720 * math.sin(v721))
end
local function v_u_931(p722, p723, p724, p725, p726, p727) -- name: layers
	-- upvalues: (copy) v_u_1
	local v728 = v_u_1.MOTION
	local v729
	if type(p725) == "table" then
		local v730 = p725.motion
		v729 = type(v730) ~= "table" and {} or p725.motion
	else
		v729 = {}
	end
	local v731 = type(p726) ~= "table" and {} or p726
	local v732 = p722.motion
	local v733 = p724.accel or {}
	local v734 = -(p723 < 0 and 0 or (p723 > 0.1 and 0.1 or p723))
	local v735 = v729.tau
	local v736 = v728.tau
	if type(v735) == "number" and (v735 == v735 and (v735 ~= (1 / 0) and v735 ~= (-1 / 0))) then
		v736 = v735
	end
	local v737 = v734 / v736
	local v738 = 1 - math.exp(v737)
	local v739 = v732.ax
	local v740 = v733.lat
	v732.ax = v739 + (((type(v740) ~= "number" or (v740 ~= v740 or (v740 == (1 / 0) or v740 == (-1 / 0)))) and 0 or v740) - v732.ax) * v738
	local v741 = v732.ay
	local v742 = v733.vert
	v732.ay = v741 + (((type(v742) ~= "number" or (v742 ~= v742 or (v742 == (1 / 0) or v742 == (-1 / 0)))) and 0 or v742) - v732.ay) * v738
	local v743 = v732.az
	local v744 = v733.long
	v732.az = v743 + (((type(v744) ~= "number" or (v744 ~= v744 or (v744 == (1 / 0) or v744 == (-1 / 0)))) and 0 or v744) - v732.az) * v738
	local v745 = v729.accMax
	local v746 = v728.accMax
	if type(v745) == "number" and (v745 == v745 and (v745 ~= (1 / 0) and v745 ~= (-1 / 0))) then
		v746 = v745
	end
	local v747 = v732.ax
	local v748 = -v746
	if v747 < v748 then
		v747 = v748
	elseif v746 < v747 then
		v747 = v746
	end
	local v749 = v732.ay
	local v750 = -v746
	if v749 < v750 then
		v749 = v750
	elseif v746 < v749 then
		v749 = v746
	end
	local v751 = v732.az
	local v752 = -v746
	if v751 < v752 then
		v751 = v752
	elseif v746 < v751 then
		v751 = v746
	end
	local v753 = v729.kRoll
	local v754 = v728.kRoll
	if type(v753) == "number" and (v753 == v753 and (v753 ~= (1 / 0) and v753 ~= (-1 / 0))) then
		v754 = v753
	end
	local v755 = v754 * v747
	local v756 = v729.roll
	local v757 = v728.roll
	if type(v756) == "number" and (v756 == v756 and (v756 ~= (1 / 0) and v756 ~= (-1 / 0))) then
		v757 = v756
	end
	local v758 = -v757
	local v759 = v729.roll
	local v760 = v728.roll
	if type(v759) == "number" and (v759 == v759 and (v759 ~= (1 / 0) and v759 ~= (-1 / 0))) then
		v760 = v759
	end
	if v755 < v758 then
		v755 = v758
	elseif v760 < v755 then
		v755 = v760
	end
	local v761 = v729.kPitch
	local v762 = v728.kPitch
	if type(v761) == "number" and (v761 == v761 and (v761 ~= (1 / 0) and v761 ~= (-1 / 0))) then
		v762 = v761
	end
	local v763 = v762 * v751
	local v764 = v729.pitch
	local v765 = v728.pitch
	if type(v764) == "number" and (v764 == v764 and (v764 ~= (1 / 0) and v764 ~= (-1 / 0))) then
		v765 = v764
	end
	local v766 = -v765
	local v767 = v729.pitch
	local v768 = v728.pitch
	if type(v767) == "number" and (v767 == v767 and (v767 ~= (1 / 0) and v767 ~= (-1 / 0))) then
		v768 = v767
	end
	if v763 < v766 then
		v763 = v766
	elseif v768 < v763 then
		v763 = v768
	end
	local v769 = v729.kLift
	local v770 = v728.kLift
	if type(v769) == "number" and (v769 == v769 and (v769 ~= (1 / 0) and v769 ~= (-1 / 0))) then
		v770 = v769
	end
	local v771 = -v770 * v749
	local v772 = v729.lift
	local v773 = v728.lift
	if type(v772) == "number" and (v772 == v772 and (v772 ~= (1 / 0) and v772 ~= (-1 / 0))) then
		v773 = v772
	end
	local v774 = -v773
	local v775 = v729.lift
	local v776 = v728.lift
	if type(v775) == "number" and (v775 == v775 and (v775 ~= (1 / 0) and v775 ~= (-1 / 0))) then
		v776 = v775
	end
	if v771 < v774 then
		v771 = v774
	elseif v776 < v771 then
		v771 = v776
	end
	if not p727 then
		v755 = v755 * 0.35
		v763 = v763 * 0.35
		v771 = v771 * 0.35
	end
	local v777 = v_u_1.spring
	local v778 = v732.roll
	local v779 = v732.rollV
	local v780 = v729.omega
	local v781 = v728.omega
	if type(v780) == "number" and (v780 == v780 and (v780 ~= (1 / 0) and v780 ~= (-1 / 0))) then
		v781 = v780
	end
	local v782 = v729.zeta
	local v783 = v728.zeta
	if type(v782) == "number" and (v782 == v782 and (v782 ~= (1 / 0) and v782 ~= (-1 / 0))) then
		v783 = v782
	end
	local v784, v785 = v777(v778, v779, v755, v781, v783, p723)
	v732.roll = v784
	v732.rollV = v785
	local v786 = v_u_1.spring
	local v787 = v732.pitch
	local v788 = v732.pitchV
	local v789 = v729.omega
	local v790 = v728.omega
	if type(v789) == "number" and (v789 == v789 and (v789 ~= (1 / 0) and v789 ~= (-1 / 0))) then
		v790 = v789
	end
	local v791 = v729.zeta
	local v792 = v728.zeta
	if type(v791) == "number" and (v791 == v791 and (v791 ~= (1 / 0) and v791 ~= (-1 / 0))) then
		v792 = v791
	end
	local v793, v794 = v786(v787, v788, v763, v790, v792, p723)
	v732.pitch = v793
	v732.pitchV = v794
	local v795 = v_u_1.spring
	local v796 = v732.lift
	local v797 = v732.liftV
	local v798 = v729.liftOmega
	local v799 = v728.liftOmega
	if type(v798) == "number" and (v798 == v798 and (v798 ~= (1 / 0) and v798 ~= (-1 / 0))) then
		v799 = v798
	end
	local v800 = v729.liftZeta
	local v801 = v728.liftZeta
	if type(v800) == "number" and (v800 == v800 and (v800 ~= (1 / 0) and v800 ~= (-1 / 0))) then
		v801 = v800
	end
	local v802, v803 = v795(v796, v797, v771, v799, v801, p723)
	v732.lift = v802
	v732.liftV = v803
	local v804 = {
		["rx"] = v732.pitch,
		["rz"] = v732.roll,
		["ly"] = v732.lift
	}
	local v805 = v729.neckPitch
	local v806 = v728.neckPitch
	if type(v805) == "number" and (v805 == v805 and (v805 ~= (1 / 0) and v805 ~= (-1 / 0))) then
		v806 = v805
	end
	v804.neckPitch = v806
	local v807 = v729.neckRoll
	local v808 = v728.neckRoll
	if type(v807) == "number" and (v807 == v807 and (v807 ~= (1 / 0) and v807 ~= (-1 / 0))) then
		v808 = v807
	end
	v804.neckRoll = v808
	local v809 = v729.gripShare
	local v810 = v728.gripShare
	if type(v809) == "number" and (v809 == v809 and (v809 ~= (1 / 0) and v809 ~= (-1 / 0))) then
		v810 = v809
	end
	v804.gripShare = v810
	local v811 = p724.now
	local v812 = (type(v811) ~= "number" or (v811 ~= v811 or (v811 == (1 / 0) or v811 == (-1 / 0)))) and 0 or v811
	local v813 = v_u_1.recoilFor(p726, p724.class)
	local v814 = p724.kickN
	local v815 = (type(v814) ~= "number" or (v814 ~= v814 or (v814 == (1 / 0) or v814 == (-1 / 0)))) and 0 or v814
	if p722.kickSeen == nil then
		p722.kickSeen = v815
	end
	local v816 = v815 - p722.kickSeen
	p722.kickSeen = v815
	local v817 = v816 <= 0 and 0 or math.min(v816, 3)
	if v817 > 0 and p727 then
		local v818 = p724.kickScale
		local v819 = (type(v818) ~= "number" or (v818 ~= v818 or (v818 == (1 / 0) or v818 == (-1 / 0)))) and 1 or v818
		local v820 = (v819 < 0.3 and 0.3 or (v819 > 2.5 and 2.5 or v819)) ^ 0.5
		local v821 = math.min(v820, 1.6)
		for _ = 1, v817 do
			local v822 = p722.shots
			table.insert(v822, { v812, v821 })
		end
	end
	local v823 = 0
	local v824 = 0
	local v825 = {}
	for _, v826 in p722.shots do
		local v827 = v812 - v826[1]
		local v828 = v813.dur
		if v827 >= ((type(v828) ~= "number" or (v828 ~= v828 or (v828 == (1 / 0) or v828 == (-1 / 0)))) and 0.3 or v828) + 0.8 then
			continue
		end
		table.insert(v825, v826)
		v823 = v823 + v826[2] * v_u_1.recoilVal(v813, v827)
		v824 = v824 + v826[2] * v_u_1.recoilVal(v813, v827 - 0.025)
	end
	p722.shots = v825
	local v829 = v823 < -1.5 and -1.5 or (v823 > 1.5 and 1.5 or v823)
	local v830 = v824 < -1.5 and -1.5 or (v824 > 1.5 and 1.5 or v824)
	local v831 = v731.hit
	local v832
	if type(v831) == "table" then
		v832 = v731.hit
	else
		v832 = v_u_1.HIT
	end
	local v833 = p724.flinch
	local v834 = (type(v833) ~= "number" or (v833 ~= v833 or (v833 == (1 / 0) or v833 == (-1 / 0)))) and 0 or v833
	local v835 = v834 < 0 and 0 or (v834 > 1 and 1 or v834)
	local v836 = v731.breath
	local v837
	if type(v836) == "table" then
		v837 = v731.breath
	else
		v837 = v_u_1.BREATH
	end
	local v838 = p724.seed
	local v839 = (type(v838) ~= "number" or (v838 ~= v838 or (v838 == (1 / 0) or v838 == (-1 / 0)))) and 0 or v838
	local v840 = v837.amp
	local v841 = v_u_1.BREATH.amp
	if type(v840) ~= "number" or (v840 ~= v840 or (v840 == (1 / 0) or v840 == (-1 / 0))) then
		v840 = v841
	end
	local v842 = 6.283185307179586
	local v843 = v837.hz
	local v844 = v_u_1.BREATH.hz
	if type(v843) == "number" and (v843 == v843 and (v843 ~= (1 / 0) and v843 ~= (-1 / 0))) then
		v844 = v843
	end
	local v845 = v842 * v844 * v812 + v839
	local v846 = v840 * math.sin(v845)
	local v847 = v731.wind
	local v848
	if type(v847) == "table" then
		v848 = v731.wind
	else
		v848 = v_u_1.WIND
	end
	local v849 = p724.speed
	local v850 = (type(v849) ~= "number" or (v849 ~= v849 or (v849 == (1 / 0) or v849 == (-1 / 0)))) and 0 or v849
	local v851 = v848.vFrom
	local v852 = v_u_1.WIND.vFrom
	if type(v851) ~= "number" or (v851 ~= v851 or (v851 == (1 / 0) or v851 == (-1 / 0))) then
		v851 = v852
	end
	local v853 = v850 - v851
	local v854 = v848.vTo
	local v855 = v_u_1.WIND.vTo
	if type(v854) == "number" and (v854 == v854 and (v854 ~= (1 / 0) and v854 ~= (-1 / 0))) then
		v855 = v854
	end
	local v856 = v848.vFrom
	local v857 = v_u_1.WIND.vFrom
	if type(v856) == "number" and (v856 == v856 and (v856 ~= (1 / 0) and v856 ~= (-1 / 0))) then
		v857 = v856
	end
	local v858 = v855 - v857
	local v859 = v853 / math.max(v858, 1)
	local v860 = v859 < 0 and 0 or (v859 > 1 and 1 or v859)
	local v861 = v848.hz or v_u_1.WIND.hz
	local v862 = v848.jitter
	local v863 = v_u_1.WIND.jitter
	if type(v862) ~= "number" or (v862 ~= v862 or (v862 == (1 / 0) or v862 == (-1 / 0))) then
		v862 = v863
	end
	local v864 = v862 * v860 * v860
	local v865 = v861[1]
	local v866 = 6.283185307179586 * ((type(v865) ~= "number" or (v865 ~= v865 or (v865 == (1 / 0) or v865 == (-1 / 0)))) and 2.3 or v865) * v812 + v839 * 1.7
	local v867 = math.sin(v866) * v864
	local v868 = v861[2]
	local v869 = 6.283185307179586 * ((type(v868) ~= "number" or (v868 ~= v868 or (v868 == (1 / 0) or v868 == (-1 / 0)))) and 3.7 or v868) * v812 + v839 * 0.6
	local v870 = math.sin(v869) * v864
	local v871 = {}
	local v872 = {}
	local v873 = v813.waist
	local v874 = v829 * ((type(v873) ~= "number" or (v873 ~= v873 or (v873 == (1 / 0) or v873 == (-1 / 0)))) and 3 or v873) + v846
	local v875 = v832.pitch
	local v876 = v_u_1.HIT.pitch
	if type(v875) == "number" and (v875 == v875 and (v875 ~= (1 / 0) and v875 ~= (-1 / 0))) then
		v876 = v875
	end
	local v877 = v874 + v876 * v835
	local v878 = v832.yaw
	local v879 = v_u_1.HIT.yaw
	if type(v878) == "number" and (v878 == v878 and (v878 ~= (1 / 0) and v878 ~= (-1 / 0))) then
		v879 = v878
	end
	local v880 = v879 * v835
	local v881 = p724.flinchYaw
	__set_list(v872, 1, {v877, v880 * ((type(v881) ~= "number" or (v881 ~= v881 or (v881 == math.huge or v881 == -math.huge))) and 0 or v881) + v867 * 0.5, v870 * 0.5})
	v871.Waist = v872
	local v882 = {}
	local v883 = v848.neck
	local v884 = v_u_1.WIND.neck
	if type(v883) ~= "number" or (v883 ~= v883 or (v883 == (1 / 0) or v883 == (-1 / 0))) then
		v883 = v884
	end
	local v885 = -v883 * v860
	local v886 = v813.head
	local v887 = v885 + ((type(v886) ~= "number" or (v886 ~= v886 or (v886 == (1 / 0) or v886 == (-1 / 0)))) and 2 or v886) * v830
	local v888 = v832.neck
	local v889 = v_u_1.HIT.neck
	if type(v888) ~= "number" or (v888 ~= v888 or (v888 == (1 / 0) or v888 == (-1 / 0))) then
		v888 = v889
	end
	__set_list(v882, 1, {v887 + v888 * v835, v870 * 0.4, v867 * 0.4})
	v871.Neck = v882
	local v890 = v731.idle
	local v891 = type(v890) ~= "table" and {
		["delay"] = 1.2,
		["deg"] = 0.4,
		["hz"] = 0.3
	} or v731.idle
	local v892 = p724.aimPhi
	local v893 = (type(v892) ~= "number" or (v892 ~= v892 or (v892 == (1 / 0) or v892 == (-1 / 0)))) and 0 or v892
	local v894 = p722.idleAimPhi
	local v895 = p724.aimPhi
	local v896 = (type(v895) ~= "number" or (v895 ~= v895 or (v895 == (1 / 0) or v895 == (-1 / 0)))) and 0 or v895
	if type(v894) == "number" and (v894 == v894 and (v894 ~= (1 / 0) and v894 ~= (-1 / 0))) then
		v896 = v894
	end
	local v897 = v893 + -v896
	local v898 = math.abs(v897)
	local v899 = p724.aimTheta
	local v900 = (type(v899) ~= "number" or (v899 ~= v899 or (v899 == (1 / 0) or v899 == (-1 / 0)))) and 0 or v899
	local v901 = p722.idleAimTheta
	local v902 = p724.aimTheta
	local v903 = (type(v902) ~= "number" or (v902 ~= v902 or (v902 == (1 / 0) or v902 == (-1 / 0)))) and 0 or v902
	if type(v901) ~= "number" or (v901 ~= v901 or (v901 == (1 / 0) or v901 == (-1 / 0))) then
		v901 = v903
	end
	local v904 = v900 + -v901
	local v905 = v898 + math.abs(v904)
	local v906 = p724.aimPhi
	local v907 = p724.aimTheta
	p722.idleAimPhi = v906
	p722.idleAimTheta = v907
	if v905 > 0.5 or not p727 then
		p722.still = 0
	else
		p722.still = p722.still + p723
	end
	local v908 = p722.still
	local v909 = v891.delay
	local v910 = (v908 - ((type(v909) ~= "number" or (v909 ~= v909 or (v909 == (1 / 0) or v909 == (-1 / 0)))) and 1.2 or v909)) / 0.6
	local v911 = v910 < 0 and 0 or (v910 > 1 and 1 or v910)
	local v912 = v911 * v911 * (3 - v911 * 2)
	local v913 = v891.deg
	local v914 = ((type(v913) ~= "number" or (v913 ~= v913 or (v913 == (1 / 0) or v913 == (-1 / 0)))) and 0.4 or v913) * v912
	local v915 = v891.hz
	local v916 = 6.283185307179586 * ((type(v915) ~= "number" or (v915 ~= v915 or (v915 == (1 / 0) or v915 == (-1 / 0)))) and 0.3 or v915) * v812 + v839
	local v917 = v914 * math.sin(v916)
	local v918 = v914 * 0.6
	local v919 = v891.hz
	local v920 = 6.283185307179586 * ((type(v919) ~= "number" or (v919 ~= v919 or (v919 == (1 / 0) or v919 == (-1 / 0)))) and 0.3 or v919) * 1.3 * v812 + v839 * 0.5
	local v921 = v918 * math.sin(v920)
	local v922 = v813.muzzle
	local v923 = v_u_1.MUZZLE
	local v924 = p724.class
	local v925 = v923[type(v924) ~= "string" and "rifle" or p724.class] or v_u_1.MUZZLE.rifle
	if type(v922) ~= "number" or (v922 ~= v922 or (v922 == (1 / 0) or v922 == (-1 / 0))) then
		v922 = v925
	end
	local v926 = v829 * v922
	local v927 = -v_u_1.MUZZLE_MAX
	local v928 = v_u_1.MUZZLE_MAX
	if v926 < v927 then
		v926 = v927
	elseif v928 < v926 then
		v926 = v928
	end
	local v929 = {}
	local v930 = v813.shoulder
	v929.shoulder = v829 * ((type(v930) ~= "number" or (v930 ~= v930 or (v930 == (1 / 0) or v930 == (-1 / 0)))) and 0.08 or v930)
	v929.back = v829
	v929.idleYaw = v917
	v929.idlePitch = v921
	v929.muzzle = v926
	return v804, v871, v929
end
local function v_u_948(p932, p933) -- name: mergeAdd
	local v934 = {}
	for _, v935 in { p932, p933 } do
		for v936, v937 in v935 do
			local v938 = v934[v936] or { 0, 0, 0 }
			local v939 = {}
			local v940 = v938[1]
			local v941 = v937[1]
			local v942 = v940 + ((type(v941) ~= "number" or (v941 ~= v941 or (v941 == (1 / 0) or v941 == (-1 / 0)))) and 0 or v941)
			local v943 = v938[2]
			local v944 = v937[2]
			local v945 = v943 + ((type(v944) ~= "number" or (v944 ~= v944 or (v944 == (1 / 0) or v944 == (-1 / 0)))) and 0 or v944)
			local v946 = v938[3]
			local v947 = v937[3]
			__set_list(v939, 1, {v942, v945, v946 + ((type(v947) ~= "number" or (v947 ~= v947 or (v947 == math.huge or v947 == -math.huge))) and 0 or v947)})
			v934[v936] = v939
		end
	end
	return v934
end
local function v_u_967(p949, p950) -- name: edgeDistance
	local v951 = p949.lo
	local v952 = (type(v951) ~= "number" or (v951 ~= v951 or (v951 == (1 / 0) or v951 == (-1 / 0)))) and 0 or v951
	local v953 = p949.hi
	local v954 = (type(v953) ~= "number" or (v953 ~= v953 or (v953 == (1 / 0) or v953 == (-1 / 0)))) and 0 or v953
	if v954 - v952 >= 360 and true or v952 + (p950 - v952) % 360 <= v954 then
		return 0
	end
	local v955 = p949.lo
	local v956 = (type(v955) ~= "number" or (v955 ~= v955 or (v955 == (1 / 0) or v955 == (-1 / 0)))) and 0 or v955
	local v957 = p949.hi
	local v958 = (type(v957) ~= "number" or (v957 ~= v957 or (v957 == (1 / 0) or v957 == (-1 / 0)))) and 0 or v957
	local v959 = p950 - v956
	local v960 = (v959 + 180) / 360
	local v961 = v959 - math.floor(v960) * 360
	local v962 = math.abs(v961)
	local v963 = p950 - v958
	local v964 = (v963 + 180) / 360
	local v965 = v963 - math.floor(v964) * 360
	local v966 = math.abs(v965)
	return math.min(v962, v966)
end
v_u_1.edgeDistance = v_u_967
local function v_u_1033(p968, p969, p970) -- name: wantStance
	-- upvalues: (copy) v_u_2, (copy) v_u_967
	if p969 ~= nil and p968[p969] ~= nil then
		local v971 = p968[p969].sector
		local v972 = v971.lo
		local v973 = (type(v972) ~= "number" or (v972 ~= v972 or (v972 == (1 / 0) or v972 == (-1 / 0)))) and 0 or v972
		local v974 = v971.hi
		local v975 = (type(v974) ~= "number" or (v974 ~= v974 or (v974 == (1 / 0) or v974 == (-1 / 0)))) and 0 or v974
		if v975 - v973 >= 360 and true or v973 + (p970 - v973) % 360 <= v975 then
			return p969
		end
	end
	local v976 = 1000000000
	local v977 = nil
	for v978, v979 in p968 do
		if v978 == p969 then
			continue
		end
		local v980 = v979.enter
		local v981
		if type(v980) == "table" then
			v981 = v979.enter
		else
			local v982 = v979.sector.lo
			local v983 = (type(v982) ~= "number" or (v982 ~= v982 or (v982 == (1 / 0) or v982 == (-1 / 0)))) and 0 or v982
			local v984 = v979.sector.hi
			local v985 = (type(v984) ~= "number" or (v984 ~= v984 or (v984 == (1 / 0) or v984 == (-1 / 0)))) and 0 or v984
			v981 = {
				["lo"] = v983 + v_u_2.ENTER_BAND,
				["hi"] = v985 - v_u_2.ENTER_BAND
			}
		end
		local v986 = v981.lo
		local v987 = (type(v986) ~= "number" or (v986 ~= v986 or (v986 == (1 / 0) or v986 == (-1 / 0)))) and 0 or v986
		local v988 = v981.hi
		local v989 = (type(v988) ~= "number" or (v988 ~= v988 or (v988 == (1 / 0) or v988 == (-1 / 0)))) and 0 or v988
		if v989 - v987 < 360 and v987 + (p970 - v987) % 360 > v989 then
			continue
		end
		local v990 = v979.sector.lo
		local v991 = (type(v990) ~= "number" or (v990 ~= v990 or (v990 == (1 / 0) or v990 == (-1 / 0)))) and 0 or v990
		local v992 = v979.sector.hi
		local v993 = p970 - (v991 + ((type(v992) ~= "number" or (v992 ~= v992 or (v992 == (1 / 0) or v992 == (-1 / 0)))) and 0 or v992)) * 0.5
		local v994 = (v993 + 180) / 360
		local v995 = v993 - math.floor(v994) * 360
		local v996 = math.abs(v995)
		if v996 >= v976 then
			continue
		end
		v977 = v978
		v976 = v996
	end
	if v977 ~= nil then
		return v977
	end
	if p969 ~= nil and p968[p969] ~= nil then
		if v_u_967(p968[p969].sector, p970) > v_u_2.ENTER_BAND then
			for v997, v998 in p968 do
				if v997 == p969 then
					continue
				end
				local v999 = v998.sector
				local v1000 = v999.lo
				local v1001 = (type(v1000) ~= "number" or (v1000 ~= v1000 or (v1000 == (1 / 0) or v1000 == (-1 / 0)))) and 0 or v1000
				local v1002 = v999.hi
				local v1003 = (type(v1002) ~= "number" or (v1002 ~= v1002 or (v1002 == (1 / 0) or v1002 == (-1 / 0)))) and 0 or v1002
				if v1003 - v1001 < 360 and v1001 + (p970 - v1001) % 360 > v1003 then
					continue
				end
				local v1004 = v998.sector.lo
				local v1005 = (type(v1004) ~= "number" or (v1004 ~= v1004 or (v1004 == (1 / 0) or v1004 == (-1 / 0)))) and 0 or v1004
				local v1006 = v998.sector.hi
				local v1007 = p970 - (v1005 + ((type(v1006) ~= "number" or (v1006 ~= v1006 or (v1006 == (1 / 0) or v1006 == (-1 / 0)))) and 0 or v1006)) * 0.5
				local v1008 = (v1007 + 180) / 360
				local v1009 = v1007 - math.floor(v1008) * 360
				local v1010 = math.abs(v1009)
				if v1010 >= v976 then
					continue
				end
				v977 = v997
				v976 = v1010
			end
			if v977 ~= nil then
				return v977
			end
		end
		return p969
	end
	for v1011, v1012 in p968 do
		local v1013 = v1012.sector
		local v1014 = v1013.lo
		local v1015 = (type(v1014) ~= "number" or (v1014 ~= v1014 or (v1014 == (1 / 0) or v1014 == (-1 / 0)))) and 0 or v1014
		local v1016 = v1013.hi
		local v1017 = (type(v1016) ~= "number" or (v1016 ~= v1016 or (v1016 == (1 / 0) or v1016 == (-1 / 0)))) and 0 or v1016
		if v1017 - v1015 < 360 and v1015 + (p970 - v1015) % 360 > v1017 then
			continue
		end
		if v977 ~= nil then
			local v1018 = v1012.neutral
			local v1019 = p970 - ((type(v1018) ~= "number" or (v1018 ~= v1018 or (v1018 == (1 / 0) or v1018 == (-1 / 0)))) and 0 or v1018)
			local v1020 = (v1019 + 180) / 360
			local v1021 = v1019 - math.floor(v1020) * 360
			if math.abs(v1021) >= v976 then
				continue
			end
		end
		local v1022 = v1012.neutral
		local v1023 = p970 - ((type(v1022) ~= "number" or (v1022 ~= v1022 or (v1022 == (1 / 0) or v1022 == (-1 / 0)))) and 0 or v1022)
		local v1024 = (v1023 + 180) / 360
		local v1025 = v1023 - math.floor(v1024) * 360
		v976 = math.abs(v1025)
		v977 = v1011
	end
	if v977 ~= nil then
		return v977
	end
	for v1026, v1027 in p968 do
		local v1028 = v1027.neutral
		local v1029 = p970 - ((type(v1028) ~= "number" or (v1028 ~= v1028 or (v1028 == (1 / 0) or v1028 == (-1 / 0)))) and 0 or v1028)
		local v1030 = (v1029 + 180) / 360
		local v1031 = v1029 - math.floor(v1030) * 360
		local v1032 = math.abs(v1031)
		if v1032 >= v976 then
			continue
		end
		v977 = v1026
		v976 = v1032
	end
	return v977
end
v_u_1.wantStance = v_u_1033
function v_u_1.step(p_u_1034, p1035, p_u_1036, p_u_1037, p1038) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (ref) v_u_3, (copy) v_u_691, (copy) v_u_676, (copy) v_u_1033, (copy) v_u_554, (copy) v_u_215, (copy) v_u_701, (copy) v_u_94, (copy) v_u_931, (copy) v_u_948
	local v1039 = (type(p1035) ~= "number" or (p1035 ~= p1035 or (p1035 == (1 / 0) or p1035 == (-1 / 0)))) and 0.016666666666666666 or p1035
	local v_u_1040 = v1039 < 0.0020833333333333333 and 0.0020833333333333333 or (v1039 > 0.1 and 0.1 or v1039)
	local v1041 = p_u_1036.now
	local v1042 = (type(v1041) ~= "number" or (v1041 ~= v1041 or (v1041 == (1 / 0) or v1041 == (-1 / 0)))) and 0 or v1041
	local v1043 = p_u_1036.arc
	local v1044 = p_u_1034.cache
	if v1044 == nil or (v1044.D ~= p_u_1037 or (v1044.arc ~= v1043 or v1044.seat ~= p_u_1036.seatName)) then
		local v1045, v1046 = v_u_1.stancesOf(p_u_1037, v1043, p_u_1036.seatName)
		v1044 = {
			["D"] = p_u_1037,
			["arc"] = v1043,
			["seat"] = p_u_1036.seatName,
			["stances"] = v1045,
			["legacy"] = v1046,
			["hull"] = v_u_1.hull(v1043, p_u_1037, p_u_1036.seatName),
			["arcs"] = {}
		}
		p_u_1034.cache = v1044
	end
	local v_u_1047 = v1044.stances
	local v1048 = v1044.legacy
	local v1049 = v1044.hull
	local v1050 = {
		["viewUp"] = p_u_1036.viewUp,
		["viewDown"] = p_u_1036.viewDown
	}
	local v1051 = p_u_1036.aimPhi
	local v1052
	if type(v1051) == "number" and p_u_1036.aimPhi == p_u_1036.aimPhi then
		v1052 = p_u_1036.aimPhi
	else
		v1052 = nil
	end
	local v1053 = p_u_1036.aimTheta
	local v1054 = (type(v1053) ~= "number" or p_u_1036.aimTheta ~= p_u_1036.aimTheta) and 0 or p_u_1036.aimTheta
	if p_u_1034.rawPhi == nil then
		local v1055
		if v1052 == nil then
			local v1056
			if v1049 then
				v1056 = v1049.yaw
			else
				v1056 = v1049
			end
			v1055 = (type(v1056) ~= "number" or (v1056 ~= v1056 or (v1056 == (1 / 0) or v1056 == (-1 / 0)))) and 90 or v1056
		else
			local v1057 = (v1052 + 180) / 360
			v1055 = v1052 - math.floor(v1057) * 360
		end
		p_u_1034.rawPhi = v1055
		p_u_1034.rawTheta = v1054
	elseif v1052 ~= nil then
		local v1058
		if p_u_1036.isLocal then
			v1058 = v_u_2.OMEGA_LOCAL
		else
			v1058 = v_u_2.OMEGA_REMOTE
		end
		local v1059 = -v1058 * v_u_1040
		local v1060 = 1 - math.exp(v1059)
		local v1061 = p_u_1034.rawPhi
		local v1062 = v1052 - p_u_1034.rawPhi
		local v1063 = (v1062 + 180) / 360
		local v1064 = v1061 + (v1062 - math.floor(v1063) * 360) * v1060
		local v1065 = (v1064 + 180) / 360
		p_u_1034.rawPhi = v1064 - math.floor(v1065) * 360
		p_u_1034.rawTheta = p_u_1034.rawTheta + (v1054 - p_u_1034.rawTheta) * v1060
	end
	local v_u_1066, v_u_1067, v1068, v1069 = v_u_3.soft(v1049, p_u_1034.rawPhi, p_u_1034.rawTheta, {
		["viewUp"] = v1050.viewUp,
		["viewDown"] = v1050.viewDown,
		["hold"] = p_u_1034.holdHull
	})
	p_u_1034.holdHull = v1069.side or p_u_1034.holdHull
	local v1070 = p_u_1036.leanOn == true
	local v1071 = p_u_1034.mode
	local v1072 = nil
	local v1073 = nil
	local v1074, v1075
	if p_u_1034.mode == "hold" and (not v1048 and (p_u_1034.stance ~= nil and (p_u_1034.bodyStance == p_u_1034.stance and p_u_1034.bodyDelta ~= nil))) then
		v1074 = nil
		v1075 = nil
		if v1070 then
			if p_u_1036.reloading == true and (v_u_1047[p_u_1034.stance] ~= nil and v_u_1047[p_u_1034.stance].tuck ~= nil) then
				local v1076 = "TUCK_IN_" .. p_u_1034.stance
				local v1077
				if type(v1076) == "string" then
					local v1078
					if type(p_u_1037) == "table" then
						local v1079 = p_u_1037.clips
						v1078 = type(v1079) ~= "table" and {} or p_u_1037.clips
					else
						v1078 = {}
					end
					v1077 = v1078[v1076]
				else
					v1077 = nil
				end
				v1074, v1075 = v_u_676(v1077)
			end
		else
			local v1080 = v_u_691(p_u_1037, v_u_1.OUT_NAME[p_u_1034.stance], p_u_1034.bodyDelta)
			local v1081
			if type(v1080) == "string" then
				local v1082
				if type(p_u_1037) == "table" then
					local v1083 = p_u_1037.clips
					v1082 = type(v1083) ~= "table" and {} or p_u_1037.clips
				else
					v1082 = {}
				end
				v1081 = v1082[v1080]
			else
				v1081 = nil
			end
			v1074, v1075 = v_u_676(v1081)
		end
		if v1074 == nil or v1075 == nil then
			v1075 = v1073
			v1074 = v1072
		else
			local v1084 = p_u_1034.bodyDelta
			local v1085 = v1074 - v1084
			local v1086 = v1084 - v1075
			if math.max(v1085, v1086, 0) <= v_u_2.SETTLE_EPS then
				v1075 = v1073
				v1074 = v1072
			end
		end
	else
		v1075 = v1073
		v1074 = v1072
	end
	if p_u_1034.mode == "sit" then
		if v1070 then
			local v1087 = v_u_1033(v_u_1047, nil, v_u_1066)
			p_u_1034.stance = v1087
			p_u_1034.stanceT0 = v1042
			p_u_1034.want = nil
			p_u_1034.mode = "in"
			p_u_1034.follow = 0
			p_u_1034.followV = 0
			p_u_1034.bodyDelta = nil
			p_u_1034.bodyStance = nil
			local v1088
			if v1048 or v_u_1047[v1087] == nil then
				v1088 = nil
			else
				v1088 = v_u_691(p_u_1037, v_u_1.IN_NAME[v1087], (v_u_554(v_u_1047[v1087], v_u_1066)))
			end
			p_u_1034.clipName = v1048 and "LEGACY_IN" or (v1088 or v_u_1.IN_NAME[v1087]) or "IN_" .. tostring(v1087)
			local v1089
			if type(p_u_1037) == "table" then
				local v1090 = p_u_1037.clips
				v1089 = type(v1090) ~= "table" and {} or p_u_1037.clips
			else
				v1089 = {}
			end
			local v1091 = v1089[p_u_1034.clipName]
			if v1091 == nil or (v1091.from == nil or v1091.keys == nil) then
				v1091 = v_u_1.defaultClip("SIT", v1087, v_u_2.IN_DUR, 0, 1)
			end
			p_u_1034.clip = v1091
			p_u_1034.clipT0 = v1042
		end
	elseif p_u_1034.mode ~= "out" and (not v1070 and v1074 == nil) then
		local v1092
		if p_u_1034.mode == "hold" then
			v1092 = false
		else
			v1092 = p_u_1034.lastOut ~= nil
		end
		local v1093
		if p_u_1034.mode == "switch" then
			v1093 = p_u_1034.clipTo
		else
			v1093 = p_u_1034.stance
		end
		p_u_1034.stance = v1093
		p_u_1034.mode = "out"
		local v1094
		if v1048 or v_u_1047[v1093] == nil then
			v1094 = nil
		else
			local v1095 = v_u_691
			local v1096 = v_u_1.OUT_NAME[v1093]
			local v1097
			if p_u_1034.bodyStance == v1093 and p_u_1034.bodyDelta ~= nil then
				v1097 = p_u_1034.bodyDelta
			else
				v1097 = v_u_554(v_u_1047[v1093], v_u_1066)
			end
			v1094 = v1095(p_u_1037, v1096, v1097)
		end
		p_u_1034.clipName = v1048 and "LEGACY_OUT" or (v1094 or v_u_1.OUT_NAME[v1093]) or "OUT_" .. tostring(v1093)
		local v1098
		if type(p_u_1037) == "table" then
			local v1099 = p_u_1037.clips
			v1098 = type(v1099) ~= "table" and {} or p_u_1037.clips
		else
			v1098 = {}
		end
		local v1100 = v1098[p_u_1034.clipName]
		if v1100 == nil or (v1100.from == nil or v1100.keys == nil) then
			v1100 = v_u_1.defaultClip(v1093, "SIT", v_u_2.OUT_DUR, 1, 0)
		end
		if v1092 then
			v1100 = table.clone(v1100)
			v1100.from = "CUR"
			p_u_1034.cutPose = v_u_215(p_u_1034.lastOut.pose)
		end
		p_u_1034.clip = v1100
		p_u_1034.clipT0 = v1042
		p_u_1034.want = nil
	end
	local v1101 = p_u_1034.stance
	local v1102
	if p_u_1034.clip == nil then
		v1102 = 0
	else
		local v1103 = v1042 - p_u_1034.clipT0
		local v1104 = p_u_1034.clip.dur
		local v1105 = (type(v1104) ~= "number" or (v1104 ~= v1104 or (v1104 == (1 / 0) or v1104 == (-1 / 0)))) and 0.3 or v1104
		v1102 = v1103 / math.max(v1105, 0.001)
		if v1102 >= 1 then
			if p_u_1034.mode == "in" or p_u_1034.mode == "tuckout" then
				p_u_1034.mode = "hold"
			elseif p_u_1034.mode == "switch" then
				p_u_1034.mode = "hold"
				p_u_1034.stance = p_u_1034.clipTo
				v1101 = p_u_1034.stance
				p_u_1034.stanceT0 = v1042
			elseif p_u_1034.mode == "out" then
				p_u_1034.mode = "sit"
				p_u_1034.stance = nil
				v1101 = nil
			elseif p_u_1034.mode == "tuckin" then
				p_u_1034.mode = "tuck"
			end
			p_u_1034.clip = nil
			p_u_1034.clipName = nil
			if p_u_1034.mode == "hold" or p_u_1034.mode == "tuck" then
				v1102 = 1
			end
		end
	end
	if v1101 ~= nil and (v_u_1047[v1101] ~= nil and v_u_1047[v1101].tuck ~= nil) then
		if p_u_1034.mode == "hold" and (p_u_1036.reloading == true and (v1070 and v1074 == nil)) then
			local v1106 = "TUCK_IN_" .. v1101
			p_u_1034.mode = "tuckin"
			p_u_1034.clipName = v1106
			p_u_1034.clipT0 = v1042
			local v1107
			if type(p_u_1037) == "table" then
				local v1108 = p_u_1037.clips
				v1107 = type(v1108) ~= "table" and {} or p_u_1037.clips
			else
				v1107 = {}
			end
			local v1109 = v1107["TUCK_IN_" .. v1101]
			if not v1109 then
				local v1110
				if type(p_u_1037) == "table" then
					local v1111 = p_u_1037.clips
					v1110 = type(v1111) ~= "table" and {} or p_u_1037.clips
				else
					v1110 = {}
				end
				v1109 = v1110.TUCK_IN
			end
			if v1109 == nil or (v1109.from == nil or v1109.keys == nil) then
				v1109 = v_u_1.defaultClip(v1101, "TUCK", 0.2, 1, 0.3)
			end
			p_u_1034.clip = v1109
			p_u_1034.want = nil
			v1102 = 0
		elseif p_u_1034.mode == "tuck" and p_u_1036.reloading ~= true then
			local v1112 = "TUCK_OUT_" .. v1101
			p_u_1034.mode = "tuckout"
			p_u_1034.clipName = v1112
			p_u_1034.clipT0 = v1042
			local v1113
			if type(p_u_1037) == "table" then
				local v1114 = p_u_1037.clips
				v1113 = type(v1114) ~= "table" and {} or p_u_1037.clips
			else
				v1113 = {}
			end
			local v1115 = v1113["TUCK_OUT_" .. v1101]
			if not v1115 then
				local v1116
				if type(p_u_1037) == "table" then
					local v1117 = p_u_1037.clips
					v1116 = type(v1117) ~= "table" and {} or p_u_1037.clips
				else
					v1116 = {}
				end
				v1115 = v1116.TUCK_OUT
			end
			if v1115 == nil or (v1115.from == nil or v1115.keys == nil) then
				v1115 = v_u_1.defaultClip("TUCK", v1101, 0.25, 0.3, 1)
			end
			p_u_1034.clip = v1115
			v1102 = 0
		end
	end
	if p_u_1034.mode == "hold" and v1101 ~= nil then
		local v1118 = v_u_1033(v_u_1047, v1101, v_u_1066)
		if v1118 == v1101 then
			p_u_1034.want = nil
		else
			if p_u_1034.want ~= v1118 then
				p_u_1034.want = v1118
				p_u_1034.wantT0 = v1042
			end
			if v1042 - p_u_1034.wantT0 >= v_u_2.DEBOUNCE and v1042 - p_u_1034.stanceT0 >= v_u_2.MIN_HOLD then
				local v1119 = (v_u_1066 + 180) / 360
				local v1120 = v_u_1066 - math.floor(v1119) * 360
				local v1121 = math.abs(v1120) <= 90 and "front" or "back"
				local v1122 = v1101 .. "_TO_" .. v1118 .. "_" .. (v1121 == "back" and "B" or "F")
				local v1123
				if type(p_u_1037) == "table" then
					local v1124 = p_u_1037.clips
					v1123 = type(v1124) ~= "table" and {} or p_u_1037.clips
				else
					v1123 = {}
				end
				local v1125 = v1123[v1122]
				if v1125 == nil then
					local v1126 = v_u_691
					local v1127 = v_u_1.OUT_NAME[v1101]
					local v1128
					if p_u_1034.bodyStance == v1101 and p_u_1034.bodyDelta ~= nil then
						v1128 = p_u_1034.bodyDelta
					else
						v1128 = v_u_554(v_u_1047[v1101], v_u_1066)
					end
					local v1129 = v1126(p_u_1037, v1127, v1128)
					local v1130 = v_u_691(p_u_1037, v_u_1.IN_NAME[v1118], (v_u_554(v_u_1047[v1118], v_u_1066)))
					local v1131
					if type(p_u_1037) == "table" then
						local v1132 = p_u_1037.clips
						v1131 = type(v1132) ~= "table" and {} or p_u_1037.clips
					else
						v1131 = {}
					end
					local v1133 = v1131[v1129 or ""]
					local v1134
					if type(p_u_1037) == "table" then
						local v1135 = p_u_1037.clips
						v1134 = type(v1135) ~= "table" and {} or p_u_1037.clips
					else
						v1134 = {}
					end
					local v1136 = v1134[v1130 or ""]
					if v1133 ~= nil and (v1136 ~= nil and (v1133.keys ~= nil and v1136.keys ~= nil)) then
						v1125 = v_u_1.viaClip(v1133, v1136, v1101, v1118)
						v1122 = v1101 .. "_TO_" .. v1118 .. "_VIA"
					end
				end
				if v1125 == nil then
					v1125 = v_u_1.defaultClip(v1101, v1118, v_u_2.SWITCH_DUR, 1, 1, v1121)
				end
				local v1137
				if v1125.parts == nil then
					v1137 = v1125
				else
					v1137 = v1125.parts[1]
				end
				local v1138, v1139 = v_u_676(v1137)
				local v1140, v1141
				if v1048 or (v1138 == nil or (v1139 == nil or (p_u_1034.bodyStance ~= v1101 or p_u_1034.bodyDelta == nil))) then
					p_u_1034.mode = "switch"
					p_u_1034.clip = v1125
					p_u_1034.clipName = v1122
					p_u_1034.clipT0 = v1042
					p_u_1034.clipTo = v1118
					p_u_1034.clipFrom = v1101
					p_u_1034.clipPath = v1121
					p_u_1034.want = nil
					v1102 = 0
					if p_u_1034.lastOut == nil then
						v1140 = v_u_1066
					else
						v1140 = p_u_1034.lastOut.phi
					end
					p_u_1034.fromPhi = v1140
					if p_u_1034.lastOut == nil then
						v1141 = v_u_1067
					else
						v1141 = p_u_1034.lastOut.theta
					end
					p_u_1034.fromTheta = v1141
				else
					local v1142 = p_u_1034.bodyDelta
					local v1143 = v1138 - v1142
					local v1144 = v1142 - v1139
					if math.max(v1143, v1144, 0) > v_u_2.SETTLE_EPS then
						v1075 = v1139
						v1074 = v1138
					else
						p_u_1034.mode = "switch"
						p_u_1034.clip = v1125
						p_u_1034.clipName = v1122
						p_u_1034.clipT0 = v1042
						p_u_1034.clipTo = v1118
						p_u_1034.clipFrom = v1101
						p_u_1034.clipPath = v1121
						p_u_1034.want = nil
						v1102 = 0
						if p_u_1034.lastOut == nil then
							v1140 = v_u_1066
						else
							v1140 = p_u_1034.lastOut.phi
						end
						p_u_1034.fromPhi = v1140
						if p_u_1034.lastOut == nil then
							v1141 = v_u_1067
						else
							v1141 = p_u_1034.lastOut.theta
						end
						p_u_1034.fromTheta = v1141
					end
				end
			end
		end
	end
	local v_u_1145
	if p_u_1034.mode == "switch" then
		v_u_1145 = p_u_1034.clipTo
	else
		v_u_1145 = p_u_1034.stance
	end
	local v1146 = {
		["active"] = p_u_1034.mode ~= "sit",
		["stance"] = p_u_1034.stance,
		["mode"] = p_u_1034.mode,
		["clip"] = p_u_1034.clipName,
		["clipU"] = v1102,
		["legacy"] = v1048
	}
	local v1147, v1148
	if v_u_1145 == nil then
		v1147 = v1049
		v1148 = 0
	else
		local v1149 = v_u_1047[v_u_1145]
		v1147 = v1044.arcs[v_u_1145]
		if v1147 == nil then
			v1147 = v_u_1.stanceArc(v1049, v1149)
			v1044.arcs[v_u_1145] = v1147
		end
		local v1150, v1151
		v1150, v_u_1067, v1148, v1151 = v_u_3.soft(v1147, p_u_1034.rawPhi, p_u_1034.rawTheta, {
			["viewUp"] = v1050.viewUp,
			["viewDown"] = v1050.viewDown,
			["hold"] = p_u_1034.holdStance
		})
		p_u_1034.holdStance = v1151.side or p_u_1034.holdStance
		v1146.phiTarget = v1150
		local v1152 = v_u_554(v1149, v1150)
		local v1153, v1154
		if p_u_1034.mode == "in" or (p_u_1034.mode == "out" or (p_u_1034.mode == "switch" or (p_u_1034.mode == "tuckin" or p_u_1034.mode == "tuckout"))) then
			local v1155 = p_u_1034.clip
			if v1155 == nil then
				v1153 = nil
				v1154 = nil
			elseif v1155.parts == nil then
				v1153, v1154 = v_u_676(v1155)
			else
				v1153, v1154 = v_u_676(v1155.parts[2])
			end
		else
			v1154 = nil
			v1153 = nil
		end
		if v1153 == nil and v1074 ~= nil then
			v1153 = v1074
			v1154 = v1075
		elseif v1153 == nil and (p_u_1034.mode == "tuck" and not v1048) then
			local v1156 = p_u_1034.stance
			local v1157 = "TUCK_OUT_" .. tostring(v1156)
			local v1158
			if type(v1157) == "string" then
				local v1159
				if type(p_u_1037) == "table" then
					local v1160 = p_u_1037.clips
					v1159 = type(v1160) ~= "table" and {} or p_u_1037.clips
				else
					v1159 = {}
				end
				v1158 = v1159[v1157]
			else
				v1158 = nil
			end
			v1153, v1154 = v_u_676(v1158)
		end
		if v1153 == nil or v1154 == nil then
			v1154 = v1152
		elseif v1152 < v1153 then
			v1154 = v1153
		elseif v1154 >= v1152 then
			v1154 = v1152
		end
		if p_u_1034.bodyStance == v_u_1145 and p_u_1034.bodyDelta ~= nil then
			local v1161 = v1074 == nil and 1 or v_u_2.SETTLE_RATE_K
			local v1162 = v_u_2.AIM_RATE * v1161 * v_u_1040
			local v1163 = v1154 - p_u_1034.bodyDelta
			local v1164 = -v1162
			if v1163 < v1164 then
				v1163 = v1164
			elseif v1162 < v1163 then
				v1163 = v1162
			end
			if math.abs(v1163) > 1e-6 and v1149.grid ~= nil then
				local v1165 = v1149.root
				if v1165 then
					v1165 = v1149.root.follow
				end
				local v_u_1166
				if type(v1165) == "table" then
					v_u_1166 = v1149.root.follow
				else
					v_u_1166 = nil
				end
				local function v1181(p1167) -- name: colAt
					-- upvalues: (copy) v_u_1166, (copy) p_u_1034, (ref) v_u_1, (ref) v_u_2, (copy) v_u_1040
					if v_u_1166 == nil then
						return p_u_1034.bodyDelta + p1167
					end
					local v1168 = v_u_1.spring
					local v1169 = p_u_1034.follow
					local v1170 = p_u_1034.followV
					local v1171 = p_u_1034.bodyDelta + p1167
					local v1172 = v_u_1166.omega
					local v1173 = v_u_2.FOLLOW_OMEGA
					if type(v1172) == "number" and (v1172 == v1172 and (v1172 ~= (1 / 0) and v1172 ~= (-1 / 0))) then
						v1173 = v1172
					end
					local v1174 = v1168(v1169, v1170, v1171, v1173, 1, v_u_1040)
					local v1175 = v_u_1166.rate
					local v1176 = v_u_2.FOLLOW_RATE
					if type(v1175) == "number" and (v1175 == v1175 and (v1175 ~= (1 / 0) and v1175 ~= (-1 / 0))) then
						v1176 = v1175
					end
					local v1177 = v1176 * v_u_1040
					local v1178 = p_u_1034.bodyDelta + p1167
					local v1179 = p_u_1034.follow - v1177
					local v1180 = p_u_1034.follow + v1177
					if v1174 < v1179 then
						v1174 = v1179
					elseif v1180 < v1174 then
						v1174 = v1180
					end
					return v1178 - v1174
				end
				local v1182 = v_u_2.JOINT_RATE * v1161 * v_u_1040
				local v1183 = v_u_1.gridPose(v1149.grid, p_u_1034.bodyDelta - (v_u_1166 == nil and 0 or p_u_1034.follow), v_u_1067)
				for _ = 1, 5 do
					local v1184 = v_u_1.poseStep(v1183, v_u_1.gridPose(v1149.grid, v1181(v1163), v_u_1067))
					if v1184 <= v1182 then
						break
					end
					v1163 = v1163 * v1182 / v1184 * 0.95
				end
			end
			p_u_1034.bodyDelta = p_u_1034.bodyDelta + v1163
		else
			p_u_1034.bodyStance = v_u_1145
			p_u_1034.bodyDelta = v1154
		end
		local v1185 = v1149.neutral
		v_u_1066 = ((type(v1185) ~= "number" or (v1185 ~= v1185 or (v1185 == (1 / 0) or v1185 == (-1 / 0)))) and 0 or v1185) + p_u_1034.bodyDelta
		local v1186 = p_u_1034.bodyDelta - v1152
		v1146.lag = math.abs(v1186)
	end
	if p_u_1034.mode == "switch" then
		if p_u_1034.fromPhi ~= nil and (p_u_1034.clipFrom ~= nil and v_u_1047[p_u_1034.clipFrom] ~= nil) then
			local v1187 = p_u_1034.clip
			local v1188, v1189
			if v1187 == nil then
				v1188 = nil
				v1189 = nil
			elseif v1187.parts == nil then
				v1188, v1189 = v_u_676(v1187)
			else
				v1188, v1189 = v_u_676(v1187.parts[1])
			end
			local v1190 = v_u_1047[p_u_1034.clipFrom]
			if v1188 ~= nil and (v1189 ~= nil and v1190.grid ~= nil) then
				local v1191 = v_u_554(v1190, p_u_1034.fromPhi)
				if v1191 < v1188 then
					v1189 = v1188
				elseif v1189 >= v1191 then
					v1189 = v1191
				end
				local v1192 = v1189 - v1191
				local v1193 = -v_u_2.AIM_RATE * v_u_2.SETTLE_RATE_K * v_u_1040
				local v1194 = v_u_2.AIM_RATE * v_u_2.SETTLE_RATE_K * v_u_1040
				if v1192 < v1193 then
					v1192 = v1193
				elseif v1194 < v1192 then
					v1192 = v1194
				end
				p_u_1034.fromPhi = p_u_1034.fromPhi + v_u_701(v1190.grid, v1191, v1192, p_u_1034.fromTheta, v_u_1040, v_u_2.SETTLE_RATE_K)
			end
		end
	else
		p_u_1034.fromPhi = nil
	end
	local v1195 = false
	for v1196, v1197 in v_u_1047 do
		if v1196 == v_u_1145 then
			continue
		end
		local v1198 = v1197.enter
		local v1199
		if type(v1198) == "table" then
			v1199 = v1197.enter
		else
			local v1200 = v1197.sector.lo
			local v1201 = (type(v1200) ~= "number" or (v1200 ~= v1200 or (v1200 == (1 / 0) or v1200 == (-1 / 0)))) and 0 or v1200
			local v1202 = v1197.sector.hi
			local v1203 = (type(v1202) ~= "number" or (v1202 ~= v1202 or (v1202 == (1 / 0) or v1202 == (-1 / 0)))) and 0 or v1202
			v1199 = {
				["lo"] = v1201 + v_u_2.ENTER_BAND,
				["hi"] = v1203 - v_u_2.ENTER_BAND
			}
		end
		local v1204 = p_u_1034.rawPhi
		local v1205 = v1199.lo
		local v1206 = (type(v1205) ~= "number" or (v1205 ~= v1205 or (v1205 == (1 / 0) or v1205 == (-1 / 0)))) and 0 or v1205
		local v1207 = v1199.hi
		local v1208 = (type(v1207) ~= "number" or (v1207 ~= v1207 or (v1207 == (1 / 0) or v1207 == (-1 / 0)))) and 0 or v1207
		if v1208 - v1206 < 360 and v1206 + (v1204 - v1206) % 360 > v1208 then
			continue
		end
		v1195 = true
	end
	if not v1195 or v1068 >= 0.5 then
		v1068 = math.max(v1148, v1068)
	end
	v1146.t = v1068
	local v1209 = p_u_1034.rawPhi
	local v1210 = p_u_1034.rawTheta
	v1146.phi = v_u_1066
	v1146.theta = v_u_1067
	v1146.rawPhi = v1209
	v1146.rawTheta = v1210
	v1146.arc = v1147
	v1146.hull = v1049
	local v_u_1211 = nil
	local v_u_1212 = {}
	local function v_u_1227(p1213) -- name: stanceAt
		-- upvalues: (copy) v_u_1145, (copy) v_u_1212, (ref) v_u_1, (copy) p_u_1034, (copy) p_u_1037, (copy) v_u_1047, (ref) v_u_1066, (ref) v_u_1067, (copy) p_u_1036, (copy) v_u_1040, (ref) v_u_1211, (ref) v_u_215
		local v1214 = p1213 == v_u_1145
		local v1215 = v_u_1212[p1213]
		if v1215 == nil then
			local v1216 = v_u_1.stancePose
			local v1217 = p_u_1034
			local v1218 = p_u_1037
			local v1219 = v_u_1047
			local v1220
			if v1214 then
				v1220 = v_u_1066
			else
				local v1221 = p_u_1034.fromPhi
				v1220 = v_u_1066
				if type(v1221) == "number" and (v1221 == v1221 and (v1221 ~= (1 / 0) and v1221 ~= (-1 / 0))) then
					v1220 = v1221
				end
			end
			local v1222
			if v1214 then
				v1222 = v_u_1067
			else
				v1222 = p_u_1034.fromTheta
			end
			local v1223 = p_u_1036
			local v1224
			if v1214 then
				v1224 = v_u_1040
			else
				v1224 = nil
			end
			local v1225, v1226 = v1216(v1217, v1218, v1219, p1213, v1220, v1222, v1223, v1224)
			v1215 = {
				["pose"] = v1225,
				["info"] = v1226
			}
			v_u_1212[p1213] = v1215
		end
		if v1214 then
			v_u_1211 = v1215.info
		end
		return v_u_215(v1215.pose)
	end
	local function v_u_1238(p1228) -- name: tuckOf
		-- upvalues: (copy) v_u_1047, (copy) v_u_1227, (copy) v_u_1212, (ref) v_u_215, (ref) v_u_94
		local v1229 = v_u_1047[p1228]
		v_u_1227(p1228)
		local v1230 = v_u_1212[p1228]
		local v1231 = v_u_215(v1229.tuck)
		local v1232, v1233, v1234 = v_u_94(v1231, "Root")
		local v1235 = v1231.j
		local v1236 = {}
		local v1237 = v1230 and v1230.info
		if v1237 then
			v1237 = v1230.info.pelvis
		end
		__set_list(v1236, 1, {v1232, v1233 - ((type(v1237) ~= "number" or (v1237 ~= v1237 or (v1237 == math.huge or v1237 == -math.huge))) and 0 or v1237), v1234})
		v1235.Root = v1236
		return v1231
	end
	if p_u_1034.mode == "sit" then
		v1146.pose = v_u_215(p_u_1036.sit)
		v1146.add = {}
		v1146.twist = {
			["Waist"] = 0,
			["Neck"] = 0
		}
		v1146.aimW = 0
		v1146.armW = 0
		v1146.oneHand = false
		v1146.canFire = false
	else
		local v1239 = {
			["Waist"] = 0,
			["Neck"] = 0
		}
		local v1240 = {}
		local v1241 = {
			["aimW"] = 1,
			["oneHand"] = false
		}
		if p_u_1034.mode == "hold" or p_u_1034.mode == "tuck" then
			local v1242 = v_u_1227(p_u_1034.stance)
			if p_u_1034.mode == "tuck" and v_u_1047[p_u_1034.stance].tuck ~= nil then
				v1242 = v_u_1238(p_u_1034.stance)
				v1241.aimW = 0.3
			end
			v1146.pose = v1242
		else
			local v1243 = p_u_1034.clip
			local function v1246(p1244)
				-- upvalues: (ref) v_u_215, (copy) p_u_1036, (copy) p_u_1034, (copy) v_u_1047, (copy) v_u_1238, (copy) v_u_1227
				if p1244 == "SIT" then
					return v_u_215(p_u_1036.sit)
				elseif p1244 == "CUR" then
					return v_u_215(p_u_1034.cutPose or p_u_1036.sit)
				elseif p1244 == "TUCK" then
					local v1245 = v_u_1047[p_u_1034.stance]
					if v1245 == nil or v1245.tuck == nil then
						return v_u_1227(p_u_1034.stance)
					else
						return v_u_1238(p_u_1034.stance)
					end
				elseif v_u_1047[p1244] == nil then
					return v_u_215(p_u_1036.sit)
				else
					return v_u_1227(p1244)
				end
			end
			local v1247
			v1247, v1241 = v_u_1.sampleClip(v1243, v1042 - p_u_1034.clipT0, v1246)
			if v_u_1145 ~= nil and v_u_1211 == nil then
				v_u_1227(v_u_1145)
			end
			v1146.pose = v1247
		end
		if v_u_1211 ~= nil then
			v1239 = v_u_1211.twist
			v1240 = v_u_1211.add
			local v1248 = v_u_1211.delta
			local v1249 = v_u_1211.u
			local v1250 = v_u_1211.pelvis
			v1146.delta = v1248
			v1146.u = v1249
			v1146.pelvis = v1250
		end
		local v1251 = 1
		if p_u_1034.mode == "in" then
			local v1252 = v1241.mix
			local v1253 = (type(v1252) ~= "number" or (v1252 ~= v1252 or (v1252 == (1 / 0) or v1252 == (-1 / 0)))) and 1 or v1252
			v1251 = v1253 < 0 and 0 or (v1253 > 1 and 1 or v1253)
		elseif p_u_1034.mode == "out" then
			local v1254 = v1241.mix
			local v1255 = 1 - ((type(v1254) ~= "number" or (v1254 ~= v1254 or (v1254 == (1 / 0) or v1254 == (-1 / 0)))) and 0 or v1254)
			v1251 = v1255 < 0 and 0 or (v1255 > 1 and 1 or v1255)
		end
		local v1256 = {}
		local v1257 = v1239.Waist * v1251
		local v1258 = p_u_1036.bladed
		v1256.Waist = v1257 + ((type(v1258) ~= "number" or (v1258 ~= v1258 or (v1258 == (1 / 0) or v1258 == (-1 / 0)))) and 0 or v1258) * (v1241.aimW or 1)
		v1256.Neck = v1239.Neck * v1251
		for _, v1259 in v1240 do
			local v1260 = v1259[1] * v1251
			local v1261 = v1259[2] * v1251
			local v1262 = v1259[3] * v1251
			v1259[1] = v1260
			v1259[2] = v1261
			v1259[3] = v1262
		end
		v1146.twist = v1256
		v1146.add = v1240
		v1146.aimW = v1241.aimW
		local v1263
		if p_u_1034.mode == "in" then
			local v1264 = v1102 / 0.45
			local v1265 = v1264 < 0 and 0 or (v1264 > 1 and 1 or v1264)
			v1263 = v1265 * v1265 * (3 - v1265 * 2)
		elseif p_u_1034.mode == "out" then
			local v1266 = (v1102 - 0.4) / 0.6
			local v1267 = v1266 < 0 and 0 or (v1266 > 1 and 1 or v1266)
			v1263 = 1 - v1267 * v1267 * (3 - v1267 * 2)
		else
			v1263 = 1
		end
		v1146.armW = v1263
		v1146.oneHand = v1241.oneHand == true
		v1146.lh = v1241.lh
		local v1268 = v_u_1.viaProgress(p_u_1034, v1042)
		local v1269
		if p_u_1034.mode == "hold" or p_u_1034.mode == "in" and v_u_2.FIRE_FROM <= v1102 then
			v1269 = true
		elseif p_u_1034.mode == "switch" and v1268 ~= nil then
			v1269 = v_u_2.FIRE_FROM_VIA <= v1268
		else
			v1269 = false
		end
		if v1269 then
			v1269 = v1101 ~= nil
		end
		v1146.canFire = v1269
	end
	local v1270
	if v_u_1145 == nil then
		v1270 = nil
	else
		v1270 = v_u_1047[v_u_1145]
	end
	local v1271 = v_u_1.capFor
	local v1272
	if v1270 then
		v1272 = v1270.resid
	else
		v1272 = v1270
	end
	v1146.rhoCap = v1271(v1272, p_u_1036.class, p_u_1036.twin)
	local v1273
	if v1270 then
		v1273 = v1270.neckYawMax
	else
		v1273 = v1270
	end
	local v1274 = v_u_2.NECK_MAX
	if type(v1273) == "number" and (v1273 == v1273 and (v1273 ~= (1 / 0) and v1273 ~= (-1 / 0))) then
		v1274 = v1273
	end
	v1146.neckMax = v1274
	local v1275
	if v1270 then
		v1275 = v1270.stanceMul
	else
		v1275 = v1270
	end
	v1146.stanceMul = (type(v1275) ~= "number" or (v1275 ~= v1275 or (v1275 == (1 / 0) or v1275 == (-1 / 0)))) and 0.5 or v1275
	local v1276
	if v1270 then
		v1276 = v1270.boxes
	else
		v1276 = v1270
	end
	v1146.boxes = v1276
	if v1270 then
		v1270 = v1270.tuck
	end
	v1146.tuckPose = v1270
	local v1277, v1278, v1279 = v_u_931(p_u_1034, v_u_1040, p_u_1036, p_u_1037, p1038, v1146.active)
	v1146.motion = v1277
	v1146.add = v_u_948(v1146.add or {}, v1278)
	v1146.shoulder = v1279.shoulder
	v1146.recoilBack = v1279.back
	local v1280 = v1279.idleYaw
	local v1281 = v1279.idlePitch
	v1146.idleYaw = v1280
	v1146.idlePitch = v1281
	v1146.muzzle = v1279.muzzle
	v1146.prevMode = v1071
	v1146.rho = v_u_1.chestRho(v1146, p_u_1037)
	local v1282
	if v1146.rho == nil then
		v1282 = 0
	else
		local v1283 = v1146.rho
		local v1284 = math.abs(v1283) - v1146.rhoCap
		v1282 = math.max(0, v1284)
	end
	v1146.off = v1282
	local v1285, v1286, v1287, v1288, v1289, v1290
	if not v1146.canFire then
		v1292 = v1146.active
		if v1292 then
			v1292 = not v1146.canFire
		end
		v1146.busy = v1292
		v1146.armPhi = v1146.phiTarget
		if p_u_1034.mode == "switch" and (p_u_1034.fromPhi ~= nil and (v1146.phiTarget ~= nil and v1146.clip ~= nil)) then
			if v1146.clipU == nil then
				v1285 = 1
			else
				v1286 = v1146.clipU
				v1285 = v1286 < 0 and 0 or (v1286 > 1 and 1 or v1286)
			end
			v1287 = v_u_1.viaProgress(p_u_1034, v1042)
			if v1287 ~= nil then
				v1285 = 1 - (1 - v1287) ^ 3
			end
			v1288 = p_u_1034.fromPhi
			v1289 = v1146.phiTarget - p_u_1034.fromPhi
			v1290 = (v1289 + 180) / 360
			v1146.armPhi = v1288 + (v1289 - math.floor(v1290) * 360) * v1285
		end
		v1146.side = p_u_1034.holdStance
		v1146.weaponPhi = v_u_1.weaponPhi(v1146, p_u_1037)
		p_u_1034.lastOut = v1146
		return v1146
	end
	if v1074 == nil and v1146.off <= v_u_2.FIRE_OFF then
		local v1291 = v1146.lag
		if ((type(v1291) ~= "number" or (v1291 ~= v1291 or (v1291 == (1 / 0) or v1291 == (-1 / 0)))) and 0 or v1291) <= v_u_2.FIRE_OFF then
			v1292 = v1146.active
			if v1292 then
				v1292 = not v1146.canFire
			end
			v1146.busy = v1292
			v1146.armPhi = v1146.phiTarget
			if p_u_1034.mode == "switch" and (p_u_1034.fromPhi ~= nil and (v1146.phiTarget ~= nil and v1146.clip ~= nil)) then
				if v1146.clipU == nil then
					v1285 = 1
				else
					v1286 = v1146.clipU
					v1285 = v1286 < 0 and 0 or (v1286 > 1 and 1 or v1286)
				end
				v1287 = v_u_1.viaProgress(p_u_1034, v1042)
				if v1287 ~= nil then
					v1285 = 1 - (1 - v1287) ^ 3
				end
				v1288 = p_u_1034.fromPhi
				v1289 = v1146.phiTarget - p_u_1034.fromPhi
				v1290 = (v1289 + 180) / 360
				v1146.armPhi = v1288 + (v1289 - math.floor(v1290) * 360) * v1285
			end
			v1146.side = p_u_1034.holdStance
			v1146.weaponPhi = v_u_1.weaponPhi(v1146, p_u_1037)
			p_u_1034.lastOut = v1146
			return v1146
		end
		v1146.canFire = false
	else
		v1146.canFire = false
	end
	local v1292 = v1146.active
	if v1292 then
		v1292 = not v1146.canFire
	end
	v1146.busy = v1292
	v1146.armPhi = v1146.phiTarget
	if p_u_1034.mode == "switch" and (p_u_1034.fromPhi ~= nil and (v1146.phiTarget ~= nil and v1146.clip ~= nil)) then
		if v1146.clipU == nil then
			v1285 = 1
		else
			v1286 = v1146.clipU
			v1285 = v1286 < 0 and 0 or (v1286 > 1 and 1 or v1286)
		end
		v1287 = v_u_1.viaProgress(p_u_1034, v1042)
		if v1287 ~= nil then
			v1285 = 1 - (1 - v1287) ^ 3
		end
		v1288 = p_u_1034.fromPhi
		v1289 = v1146.phiTarget - p_u_1034.fromPhi
		v1290 = (v1289 + 180) / 360
		v1146.armPhi = v1288 + (v1289 - math.floor(v1290) * 360) * v1285
	end
	v1146.side = p_u_1034.holdStance
	v1146.weaponPhi = v_u_1.weaponPhi(v1146, p_u_1037)
	p_u_1034.lastOut = v1146
	return v1146
end
return v_u_1