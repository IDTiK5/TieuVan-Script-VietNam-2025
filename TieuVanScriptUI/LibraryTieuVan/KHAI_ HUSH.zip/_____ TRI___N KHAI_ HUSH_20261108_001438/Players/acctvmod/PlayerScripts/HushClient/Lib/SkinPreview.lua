-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SkinPreview

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
v_u_3.TURN_PER_SECOND = 0.25
v_u_3.REST_AFTER_DRAG = 2
v_u_3.DRAG_RAD_PER_PX = 0.012
v_u_3.REFRESH_EVERY = 30
v_u_3.WEAR_FOV = 28
local v_u_5 = Color3.fromRGB(122, 130, 144)
local v_u_6 = Color3.fromRGB(176, 182, 192)
function v_u_3.wearFrame(p7) -- name: wearFrame
	return p7 == "head" and "head" or (p7 == "vest" and "torso" or "body")
end
function v_u_3.mannequin() -- name: mannequin
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_5
	local function v8()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("BlockRigSpec", 5))
	end
	local v9, v10 = pcall(v8)
	if not v9 or type(v10) ~= "table" then
		return nil
	end
	local v11 = Instance.new("Model")
	v11.Name = "Mannequin"
	for _, v12 in v10.PART_NAMES do
		local v13 = v10.DIMS[v12]
		local v14 = v10.CENTERS[v12]
		if v12 == "HumanoidRootPart" or not (v13 and v14) then
			continue
		end
		local v15 = Instance.new("Part")
		v15.Name = v12
		local v16 = v13[1]
		local v17 = v13[2]
		local v18 = v13[3]
		v15.Size = Vector3.new(v16, v17, v18)
		v15.CFrame = CFrame.new(v14[1], v14[2], v14[3])
		v15.Anchored = true
		v15.CanCollide = false
		v15.CanQuery = false
		v15.CanTouch = false
		v15.Material = Enum.Material.SmoothPlastic
		local v19
		if v12 == "Head" or string.find(v12, "Hand", 1, true) then
			v19 = v_u_6
		else
			v19 = v_u_5
		end
		v15.Color = v19
		v15.TopSurface = Enum.SurfaceType.Smooth
		v15.BottomSurface = Enum.SurfaceType.Smooth
		v15.CastShadow = false
		if v12 == "Head" then
			local v20 = Instance.new("SpecialMesh")
			v20.MeshType = Enum.MeshType.Sphere
			v20.Parent = v15
		end
		v15.Parent = v11
	end
	return v11
end
local function v_u_52(p21) -- name: boundsOf
	local v22 = Vector3.new(inf, inf, inf)
	local v23 = Vector3.new(-inf, -inf, -inf)
	for _, v24 in p21 do
		local v25 = v24.Size / 2
		for _, v26 in { -1, 1 } do
			for _, v27 in { -1, 1 } do
				for _, v28 in { -1, 1 } do
					local v29 = v24.CFrame
					local v30 = v25.X * v26
					local v31 = v25.Y * v27
					local v32 = v25.Z * v28
					local v33 = v29:PointToWorldSpace((Vector3.new(v30, v31, v32)))
					local v34 = v22.X
					local v35 = v33.X
					local v36 = math.min(v34, v35)
					local v37 = v22.Y
					local v38 = v33.Y
					local v39 = math.min(v37, v38)
					local v40 = v22.Z
					local v41 = v33.Z
					local v42 = math.min(v40, v41)
					v22 = Vector3.new(v36, v39, v42)
					local v43 = v23.X
					local v44 = v33.X
					local v45 = math.max(v43, v44)
					local v46 = v23.Y
					local v47 = v33.Y
					local v48 = math.max(v46, v47)
					local v49 = v23.Z
					local v50 = v33.Z
					local v51 = math.max(v49, v50)
					v23 = Vector3.new(v45, v48, v51)
				end
			end
		end
	end
	return v22, v23
end
function v_u_3.wearView(p53, p54, p55) -- name: wearView
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_52
	local v56 = p55 or {}
	local function v57()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("WearSkins", 5))
	end
	local v58, v59 = pcall(v57)
	local function v60()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("WornArmor", 5))
	end
	local v61, v62 = pcall(v60)
	local function v63()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("Items", 5))
	end
	local v64, v65 = pcall(v63)
	local v66
	if v58 then
		v66 = v59.get(p54)
	else
		v66 = nil
	end
	if v66 == nil or not v61 then
		return nil
	end
	local v_u_67 = v_u_3.mannequin()
	if v_u_67 == nil then
		return nil
	end
	local v68 = {
		[v66.slot] = v66.id
	}
	local v69
	if v66.slot == "vest" then
		v69 = v66.fits[1]
	else
		v69 = nil
	end
	local v70 = v62.dress
	local v71 = nil
	local v72 = nil
	if not v64 then
		v65 = nil
	end
	local v73, v_u_74 = pcall(v70, v_u_67, v69, v71, v72, v65, v68)
	if not v73 or typeof(v_u_74) ~= "Instance" then
		v_u_74 = nil
	end
	local v75 = v_u_74 and v_u_74:GetAttribute("WearHide") == "head" and v_u_67:FindFirstChild("Head")
	if v75 then
		v75.Transparency = 1
	end
	local v76 = v_u_3.wearFrame(v66.slot)
	local v77 = {}
	if v_u_74 then
		for _, v78 in v_u_74:GetChildren() do
			if not v78:IsA("BasePart") then
				continue
			end
			table.insert(v77, v78)
		end
	end
	if v76 == "head" then
		local v79 = v_u_67:FindFirstChild("Head")
		if v79 and v79:IsA("BasePart") then
			table.insert(v77, v79)
		end
	elseif v76 == "torso" then
		local v80 = v_u_67:FindFirstChild("UpperTorso")
		if v80 and v80:IsA("BasePart") then
			table.insert(v77, v80)
		end
		local v81 = v_u_67:FindFirstChild("LowerTorso")
		if v81 and v81:IsA("BasePart") then
			table.insert(v77, v81)
		end
	else
		for _, v82 in v_u_67:GetChildren() do
			if not v82:IsA("BasePart") or v82.Transparency >= 1 then
				continue
			end
			table.insert(v77, v82)
		end
	end
	local v_u_83 = Instance.new("ViewportFrame")
	v_u_83.Name = v56.name or "WearView"
	v_u_83.BackgroundTransparency = 1
	v_u_83.BorderSizePixel = 0
	v_u_83.Size = v56.size or UDim2.fromScale(1, 1)
	v_u_83.Position = v56.position or UDim2.new()
	v_u_83.AnchorPoint = v56.anchor or Vector2.zero
	v_u_83.ZIndex = v56.zindex or 2
	local v84 = v56.ambient
	local v85
	if typeof(v84) == "Color3" then
		v85 = v56.ambient
	else
		v85 = Color3.fromRGB(150, 150, 160)
	end
	v_u_83.Ambient = v85
	local v86 = v56.lightColor
	local v87
	if typeof(v86) == "Color3" then
		v87 = v56.lightColor
	else
		v87 = Color3.fromRGB(255, 240, 220)
	end
	v_u_83.LightColor = v87
	v_u_83.LightDirection = Vector3.new(-0.4, -0.7, -0.6)
	v_u_67.WorldPivot = CFrame.new(0, 0, 0)
	v_u_67.Parent = v_u_83
	local v_u_88, v_u_89 = v_u_52(v77)
	local v_u_90 = (v_u_88 + v_u_89) / 2
	local v_u_91 = v56.fov or v_u_3.WEAR_FOV
	local v_u_92 = Instance.new("Camera")
	v_u_92.FieldOfView = v_u_91
	v_u_92.Parent = v_u_83
	v_u_83.CurrentCamera = v_u_92
	local function v110() -- name: reframe
		-- upvalues: (copy) v_u_83, (copy) v_u_89, (copy) v_u_88, (copy) v_u_91, (copy) v_u_92, (copy) v_u_90
		local v93 = v_u_83.AbsoluteSize
		local v94 = (v93.X <= 4 or v93.Y <= 4) and 1 or v93.X / v93.Y
		local v95 = v_u_89.Y - v_u_88.Y
		local v96 = v_u_89.X - v_u_88.X
		local v97 = v_u_89.Z - v_u_88.Z
		local v98 = math.max(v96, v97)
		local v99 = v_u_91
		local v100 = math.rad(v99) / 2
		local v101 = math.tan(v100)
		local v102 = v95 * 0.5 / v101
		local v103 = v98 * 0.5 / (v101 * v94)
		local v104 = math.max(v102, v103) * 1.12 + v98 * 0.5
		local v105 = v_u_92
		local v106 = CFrame.lookAt
		local v107 = v_u_90.X
		local v108 = v_u_90.Y + v95 * 0.02
		local v109 = v_u_90.Z - v104
		v105.CFrame = v106(Vector3.new(v107, v108, v109), v_u_90)
	end
	v110()
	v_u_83:GetPropertyChangedSignal("AbsoluteSize"):Connect(v110)
	local v114 = {
		["frame"] = v_u_83,
		["model"] = v_u_67,
		["worn"] = v_u_74,
		["turn"] = function(p111) -- name: turn
			-- upvalues: (copy) v_u_67
			if v_u_67.Parent then
				v_u_67:PivotTo(CFrame.Angles(0, p111, 0))
			end
		end,
		["parts"] = function() -- name: parts
			-- upvalues: (copy) v_u_74
			return v_u_74 and #v_u_74:GetChildren() or 0
		end,
		["reframe"] = v110,
		["source"] = function() -- name: source
			-- upvalues: (copy) v_u_74
			if v_u_74 then
				return v_u_74:GetAttribute("WearSource")
			else
				return nil
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) v_u_83
			local v112 = v_u_83.Destroy
			local v113 = v_u_83
			pcall(v112, v113)
		end
	}
	if p53 then
		v_u_83.Parent = p53
	end
	return v114
end
function v_u_3.new(p115, p116) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_1
	local v117 = p116 or {}
	local v118, v_u_119 = pcall(function()
		return require(script.Parent:WaitForChild("ItemIcons", 5))
	end)
	if not v118 then
		v_u_119 = nil
	end
	local function v120()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("SkinApply", 5))
	end
	local v121, v_u_122 = pcall(v120)
	if not v121 then
		v_u_122 = nil
	end
	local function v123()
		-- upvalues: (ref) v_u_4
		return require(v_u_4:WaitForChild("SkinTex", 5))
	end
	local v124, v_u_125 = pcall(v123)
	if not v124 then
		v_u_125 = nil
	end
	local v_u_126 = Instance.new("Frame")
	v_u_126.Name = v117.name or "SkinPreview"
	v_u_126.BackgroundTransparency = 1
	v_u_126.BorderSizePixel = 0
	v_u_126.ClipsDescendants = true
	v_u_126.Size = v117.size or UDim2.fromScale(1, 1)
	v_u_126.Position = v117.position or UDim2.new()
	v_u_126.AnchorPoint = v117.anchor or Vector2.zero
	v_u_126.LayoutOrder = v117.order or 0
	local v127 = Instance.new("Frame")
	v127.Name = "Shadow"
	v127.BackgroundColor3 = Color3.new(0, 0, 0)
	v127.BackgroundTransparency = 0.72
	v127.BorderSizePixel = 0
	v127.AnchorPoint = Vector2.new(0.5, 1)
	v127.Position = UDim2.new(0.5, 0, 1, -6)
	v127.Size = UDim2.new(0.62, 0, 0, 14)
	v127.Parent = v_u_126
	local v128 = Instance.new("UICorner")
	v128.CornerRadius = UDim.new(0.5, 0)
	v128.Parent = v127
	local v129 = Instance.new("TextButton")
	v129.Name = "Drag"
	v129.Text = ""
	v129.AutoButtonColor = false
	v129.BackgroundTransparency = 1
	v129.Size = UDim2.fromScale(1, 1)
	v129.ZIndex = 5
	v129.Selectable = false
	v129.Parent = v_u_126
	if p115 then
		v_u_126.Parent = p115
	end
	local v_u_130 = {
		["frame"] = v_u_126
	}
	local v_u_131 = nil
	local v_u_132 = nil
	local v_u_133 = 0.6
	local v_u_134 = false
	local v_u_135 = 0
	local v_u_136 = 0
	local v_u_137 = 0
	local v_u_138 = true
	local v_u_139 = nil
	local v_u_140 = nil
	local v_u_141 = 0
	local v_u_142 = nil
	local function v_u_152() -- name: clearSymbol
		-- upvalues: (ref) v_u_139, (ref) v_u_132, (ref) v_u_131, (ref) v_u_125, (ref) v_u_119
		if v_u_139 then
			local v143 = v_u_139.destroy
			pcall(v143)
			v_u_139 = nil
		end
		if v_u_132 then
			local v144 = v_u_132
			pcall(v144)
			v_u_132 = nil
		end
		local v145 = v_u_131 and (v_u_125 and v_u_131:FindFirstChildWhichIsA("Model"))
		if v145 then
			local v146 = v_u_125.revert
			pcall(v146, v145)
		end
		if v_u_131 and v_u_119 then
			local v147 = v_u_131:FindFirstChildWhichIsA("Model")
			if v147 and v147:GetAttribute("SkinTexDirty") == true then
				local v148 = v_u_131.Destroy
				local v149 = v_u_131
				pcall(v148, v149)
			else
				local v150 = v_u_119.release
				local v151 = v_u_131
				pcall(v150, v151)
			end
		end
		v_u_131 = nil
	end
	local function v_u_159() -- name: startAnim
		-- upvalues: (ref) v_u_132, (ref) v_u_142, (ref) v_u_131, (ref) v_u_122
		if v_u_132 then
			local v153 = v_u_132
			pcall(v153)
			v_u_132 = nil
		end
		local v154 = v_u_142 and (v_u_131 and (v_u_122 and (v_u_122.animate and v_u_131:FindFirstChildWhichIsA("Model"))))
		if v154 then
			local v155 = v_u_122.animate
			local v156 = v_u_142
			local v157, v158 = pcall(v155, v154, v156)
			if v157 and type(v158) == "function" then
				v_u_132 = v158
			end
		end
	end
	function v_u_130.show(p160, p_u_161) -- name: show
		-- upvalues: (ref) v_u_138, (copy) v_u_152, (ref) v_u_140, (ref) v_u_141, (ref) v_u_142, (ref) v_u_119, (copy) v_u_126, (ref) v_u_131, (ref) v_u_133, (ref) v_u_125, (ref) v_u_3, (ref) v_u_159
		if v_u_138 then
			v_u_152()
			v_u_140 = nil
			v_u_141 = 0
			v_u_142 = nil
			if v_u_119 and type(p160) == "string" then
				local v162 = v_u_119.get
				local v163 = {
					["parent"] = nil,
					["size"] = nil,
					["name"] = "Weapon",
					["skin"] = nil,
					["zindex"] = 2,
					["parent"] = v_u_126,
					["size"] = UDim2.fromScale(1, 1),
					["skin"] = p_u_161
				}
				local v164, v165 = pcall(v162, p160, false, v163)
				if v164 and typeof(v165) == "Instance" then
					v_u_131 = v165
					local v166 = v_u_119.turn
					local v167 = v_u_131
					local v168 = v_u_133
					pcall(v166, v167, v168)
					local v169 = p_u_161 and v_u_125 and v_u_131:FindFirstChildWhichIsA("Model")
					if v169 then
						local v170 = v_u_125.upgrade
						local v171, v172, v173 = pcall(v170, v169, p_u_161, {
							["own"] = true,
							["preview"] = true
						})
						local v174 = v_u_125.status
						local v175, v176 = pcall(v174, p_u_161)
						if v175 and v176 == true then
							v_u_140 = v_u_125.watchNew(p_u_161, {
								["opts"] = {
									["own"] = true,
									["preview"] = true
								},
								["refreshEvery"] = v_u_3.REFRESH_EVERY
							})
						end
						if v171 and (v172 ~= true and (v173 ~= "not a texture skin" and v173 ~= "server")) then
							v_u_131:SetAttribute("SkinTexWhy", (tostring(v173)))
							local v_u_177 = v_u_131
							task.spawn(function()
								-- upvalues: (ref) v_u_138, (ref) v_u_131, (copy) v_u_177, (ref) v_u_125, (copy) p_u_161, (ref) v_u_159
								for _, v178 in {
									0.25,
									0.6,
									1.2,
									2.5
								} do
									task.wait(v178)
									if not v_u_138 or (v_u_131 ~= v_u_177 or v_u_177.Parent == nil) then
										return
									end
									local v179 = v_u_177:FindFirstChildWhichIsA("Model")
									if v179 == nil then
										return
									end
									local v180 = v_u_125.upgrade
									local v181 = p_u_161
									local v182, v183, v184 = pcall(v180, v179, v181, {
										["own"] = true,
										["preview"] = true
									})
									if v182 and v183 == true then
										v_u_177:SetAttribute("SkinTexWhy", nil)
										v_u_159()
										return
									end
									if not v182 then
										continue
									end
									v_u_177:SetAttribute("SkinTexWhy", (tostring(v184)))
								end
							end)
						end
					end
					v_u_142 = p_u_161
					v_u_159()
				end
			else
				return
			end
		else
			return
		end
	end
	function v_u_130.showWear(p185) -- name: showWear
		-- upvalues: (ref) v_u_138, (copy) v_u_152, (ref) v_u_140, (ref) v_u_141, (ref) v_u_142, (ref) v_u_3, (copy) v_u_126, (ref) v_u_139, (ref) v_u_133
		if v_u_138 then
			v_u_152()
			v_u_140 = nil
			v_u_141 = 0
			v_u_142 = nil
			local v186 = v_u_3.wearView
			local v187 = v_u_126
			local v188 = {
				["size"] = nil,
				["name"] = "Wear",
				["zindex"] = 2,
				["size"] = UDim2.fromScale(1, 1)
			}
			local v189, v190 = pcall(v186, v187, p185, v188)
			if v189 and type(v190) == "table" then
				v_u_139 = v190
				local v191 = v_u_139.turn
				local v192 = v_u_133
				pcall(v191, v192)
			end
		end
	end
	function v_u_130.wear() -- name: wear
		-- upvalues: (ref) v_u_139
		return v_u_139
	end
	function v_u_130.yaw() -- name: yaw
		-- upvalues: (ref) v_u_133
		return v_u_133
	end
	function v_u_130.watchStats() -- name: watchStats
		-- upvalues: (ref) v_u_140
		local v193 = not v_u_140 and 0 or v_u_140.restores + v_u_140.refreshes
		if v_u_140 then
			return v193, v_u_140.skin
		else
			return v193, nil
		end
	end
	function v_u_130.watchState() -- name: watchState
		-- upvalues: (ref) v_u_140
		return v_u_140
	end
	function v_u_130.watchTick(p194) -- name: watchTick
		-- upvalues: (ref) v_u_138, (ref) v_u_140, (ref) v_u_131, (ref) v_u_125, (ref) v_u_159
		if not (v_u_138 and (v_u_140 and v_u_131)) then
			return nil
		end
		local v195 = v_u_131:FindFirstChildWhichIsA("Model")
		local v196 = v_u_125.watchStep(v_u_140, v195, p194)
		if v196 == "restored" or v196 == "refreshed" then
			v_u_159()
		end
		return v196
	end
	v129.InputBegan:Connect(function(p197)
		-- upvalues: (ref) v_u_134, (ref) v_u_135
		if p197.UserInputType == Enum.UserInputType.MouseButton1 or p197.UserInputType == Enum.UserInputType.Touch then
			v_u_134 = true
			v_u_135 = p197.Position.X
		end
	end)
	local v_u_198 = {}
	local v199 = v_u_2.InputChanged
	local function v202(p200)
		-- upvalues: (ref) v_u_137, (ref) v_u_134, (ref) v_u_133, (ref) v_u_135, (ref) v_u_3, (ref) v_u_136
		if p200.UserInputType == Enum.UserInputType.Gamepad1 and p200.KeyCode == Enum.KeyCode.Thumbstick2 then
			v_u_137 = p200.Position.X
			return
		elseif v_u_134 then
			if p200.UserInputType == Enum.UserInputType.MouseMovement or p200.UserInputType == Enum.UserInputType.Touch then
				local v201 = p200.Position.X
				v_u_133 = v_u_133 + (v201 - v_u_135) * v_u_3.DRAG_RAD_PER_PX
				v_u_135 = v201
				v_u_136 = os.clock() + v_u_3.REST_AFTER_DRAG
			end
		end
	end
	table.insert(v_u_198, v199:Connect(v202))
	local v203 = v_u_2.InputEnded
	local function v205(p204)
		-- upvalues: (ref) v_u_134
		if p204.UserInputType == Enum.UserInputType.MouseButton1 or p204.UserInputType == Enum.UserInputType.Touch then
			v_u_134 = false
		end
	end
	table.insert(v_u_198, v203:Connect(v205))
	local v206 = v_u_1.Heartbeat
	local function v214(p207)
		-- upvalues: (ref) v_u_138, (copy) v_u_126, (ref) v_u_131, (ref) v_u_139, (ref) v_u_137, (ref) v_u_133, (ref) v_u_136, (ref) v_u_3, (ref) v_u_134, (ref) v_u_119, (ref) v_u_141, (ref) v_u_140, (ref) v_u_125, (copy) v_u_130
		if v_u_138 and (v_u_126.Parent and (v_u_131 or v_u_139)) then
			local v208 = v_u_137
			if math.abs(v208) > 0.15 then
				v_u_133 = v_u_133 + v_u_137 * p207 * 3
				v_u_136 = os.clock() + v_u_3.REST_AFTER_DRAG
			elseif not v_u_134 and v_u_136 <= os.clock() then
				v_u_133 = v_u_133 + p207 * v_u_3.TURN_PER_SECOND * 3.141592653589793 * 2
			end
			if v_u_139 then
				local v209 = v_u_139.turn
				local v210 = v_u_133
				pcall(v209, v210)
			else
				local v211 = v_u_119.turn
				local v212 = v_u_131
				local v213 = v_u_133
				pcall(v211, v212, v213)
			end
			v_u_141 = v_u_141 + p207
			if v_u_141 >= 1 then
				v_u_141 = 0
				if v_u_140 and v_u_125 then
					v_u_130.watchTick(os.clock())
				end
			end
		end
	end
	table.insert(v_u_198, v206:Connect(v214))
	function v_u_130.destroy() -- name: destroy
		-- upvalues: (ref) v_u_138, (ref) v_u_140, (copy) v_u_198, (copy) v_u_152, (copy) v_u_126
		v_u_138 = false
		v_u_140 = nil
		for _, v215 in v_u_198 do
			v215:Disconnect()
		end
		table.clear(v_u_198)
		v_u_152()
		v_u_126:Destroy()
	end
	return v_u_130
end
return v_u_3