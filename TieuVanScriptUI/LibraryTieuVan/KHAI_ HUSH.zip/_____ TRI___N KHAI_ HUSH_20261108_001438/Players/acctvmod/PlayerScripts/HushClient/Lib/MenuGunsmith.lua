-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuGunsmith

local v_u_1 = game:GetService("GuiService")
local v_u_2 = {
	["ID"] = "gunsmith",
	["TRADE_LABEL"] = "Crafting",
	["FILTERS"] = {
		"all",
		"pistol",
		"smg",
		"rifle",
		"mg",
		"shotgun",
		"sniper"
	},
	["CLASS_TEXT"] = {
		["all"] = "All",
		["pistol"] = "Pistol",
		["smg"] = "SMG",
		["rifle"] = "Rifle",
		["mg"] = "MG",
		["shotgun"] = "Shotgun",
		["sniper"] = "Sniper"
	},
	["MAX_PAY"] = 16,
	["TRUST_JOBS"] = { "gs_01", "gs_02", "gs_03" }
}
local v_u_3 = {
	["filter"] = "all",
	["svc"] = "swap",
	["payOpen"] = false
}
v_u_2.MEMORY = v_u_3
function v_u_2.fmtPts(p4) -- name: fmtPts
	local v5 = ((tonumber(p4) or 0) + 1e-6) * 1000
	local v6 = math.floor(v5) / 10
	if v6 ~= math.floor(v6) then
		return ("%.1f"):format(v6)
	end
	local v7 = math.floor(v6)
	return tostring(v7)
end
function v_u_2.repText(p8) -- name: repText
	-- upvalues: (copy) v_u_2
	return "+" .. v_u_2.fmtPts(p8) .. " REP"
end
function v_u_2.classCounts(p9) -- name: classCounts
	local v10 = {
		["all"] = 0
	}
	for _, v11 in p9 or {} do
		v10.all = v10.all + 1
		v10[v11.class] = (v10[v11.class] or 0) + 1
	end
	return v10
end
function v_u_2.filterRows(p12, p13) -- name: filterRows
	local v14 = {}
	for _, v15 in p12 or {} do
		if p13 ~= nil and (p13 ~= "all" and v15.class ~= p13) then
			continue
		end
		table.insert(v14, v15)
	end
	return v14
end
function v_u_2.lineStats(p16) -- name: lineStats
	local v17 = 0
	local v18 = 0
	local v19 = 0
	for _, v20 in { p16.parts or {}, p16.general or {} } do
		for _, v21 in v20 do
			v17 = v17 + 1
			local v22 = v21.need
			local v23 = tonumber(v22) or 1
			local v24 = v21.have
			local v25 = tonumber(v24) or 0
			if v23 <= v25 then
				v18 = v18 + 1
			else
				v19 = v19 + (v23 - v25)
			end
		end
	end
	return v17, v18, v19
end
function v_u_2.checkPay(p26, p27, p28) -- name: checkPay
	-- upvalues: (copy) v_u_2
	local v29 = {}
	for _, v30 in p27 or {} do
		local v31 = v30.n
		if (tonumber(v31) or 0) <= 0 then
			continue
		end
		table.insert(v29, v30)
	end
	if #v29 > (p28 or v_u_2.MAX_PAY) then
		return false, "Too many payment items", {
			["points"] = 0,
			["lost"] = 0,
			["entries"] = nil,
			["entries"] = #v29
		}
	else
		local v32 = 0
		local v33 = (1 / 0)
		for _, v34 in v29 do
			v32 = v32 + v34.pts * v34.n
			if v34.pts >= v33 then
				continue
			end
			v33 = v34.pts
		end
		if v32 < p26 then
			return false, ("Not enough gold: %d of %d points"):format(v32, p26), {
				["points"] = nil,
				["lost"] = 0,
				["entries"] = nil,
				["points"] = v32,
				["entries"] = #v29
			}
		elseif p26 <= v32 - v33 then
			return false, "Too much gold: take an item out of the payment", {
				["points"] = v32,
				["lost"] = v32 - p26,
				["entries"] = #v29
			}
		else
			return true, nil, {
				["points"] = v32,
				["lost"] = v32 - p26,
				["entries"] = #v29
			}
		end
	end
end
function v_u_2.payList(p35, p36) -- name: payList
	local v37 = {}
	local v38 = {}
	for _, v39 in p36 or {} do
		local v40 = (p35 or {})[v39.uid]
		local v41 = tonumber(v40) or 0
		local v42 = math.floor(v41)
		local v43 = v39.n
		local v44 = tonumber(v43) or 1
		local v45 = math.min(v42, v44)
		if v45 <= 0 then
			continue
		end
		local v46 = {
			["uid"] = v39.uid,
			["n"] = v45
		}
		table.insert(v37, v46)
		local v47 = {
			["uid"] = v39.uid,
			["id"] = v39.id
		}
		local v48 = v39.points
		v47.pts = tonumber(v48) or 0
		v47.n = v45
		table.insert(v38, v47)
	end
	return v37, v38
end
function v_u_2.pts(p49) -- name: pts
	return ("%d %s"):format(p49, p49 == 1 and "point" or "points")
end
function v_u_2.payWith(p50, p51) -- name: payWith
	local v52 = {}
	local v53 = {}
	for _, v54 in p50 or {} do
		if not v52[v54.id] then
			v52[v54.id] = 0
			local v55 = v54.id
			table.insert(v53, v55)
		end
		local v56 = v54.id
		v52[v56] = v52[v56] + v54.n
	end
	if #v53 == 0 then
		return "Nothing picked yet"
	end
	local v57 = {}
	for _, v58 in v53 do
		local v59 = p51(v58)
		local v60 = v52[v58]
		table.insert(v57, ("%s x%d"):format(v59, v60))
	end
	return table.concat(v57, ", ")
end
function v_u_2.goldPts(p61) -- name: goldPts
	return ("%d gold %s"):format(p61, p61 == 1 and "point" or "points")
end
function v_u_2.paySummary(p62, p63, p64) -- name: paySummary
	-- upvalues: (copy) v_u_2
	if p63 <= 0 then
		return ("Fee: %s. Pick what you pay with."):format(v_u_2.goldPts(p62))
	elseif p63 < p62 then
		return ("Paying %d of %s"):format(p63, v_u_2.pts(p62))
	elseif p64 > 0 then
		return ("Paying %s. %d %s lost, no change is given back."):format(v_u_2.pts(p63), p64, p64 == 1 and "point is" or "points are")
	else
		return ("Paying %s. Nothing is wasted."):format(v_u_2.pts(p63))
	end
end
function v_u_2.consumedGroups(p65, p66, p_u_67) -- name: consumedGroups
	local v_u_68 = {}
	local function v77(p69, p70, _) -- name: add
		-- upvalues: (copy) p_u_67, (copy) v_u_68
		local v71 = {}
		for _, v72 in p70 or {} do
			local v73 = v72.item or v72.id
			local v74 = {
				["name"] = v72.name or p_u_67(v73)
			}
			local v75 = v72.need or v72.n
			v74.n = tonumber(v75) or 1
			v74.id = v73
			table.insert(v71, v74)
		end
		if #v71 > 0 then
			local v76 = v_u_68
			table.insert(v76, {
				["title"] = p69,
				["lines"] = v71
			})
		end
	end
	v77("Parts", p65.parts)
	v77("Hardware", p65.general)
	local v78 = {}
	local v79 = {}
	for _, v80 in p66 or {} do
		if not v78[v80.id] then
			v78[v80.id] = 0
			local v81 = v80.id
			table.insert(v79, v81)
		end
		local v82 = v80.id
		v78[v82] = v78[v82] + v80.n
	end
	local v83 = {}
	for _, v84 in v79 do
		local v85 = {
			["name"] = p_u_67(v84),
			["n"] = v78[v84],
			["id"] = v84
		}
		table.insert(v83, v85)
	end
	if #v83 > 0 then
		table.insert(v_u_68, {
			["title"] = "Gold",
			["lines"] = nil,
			["lines"] = v83
		})
	end
	return v_u_68
end
function v_u_2.groupTotal(p86) -- name: groupTotal
	local v87 = 0
	for _, v88 in p86 do
		for _, v89 in v88.lines do
			v87 = v87 + v89.n
		end
	end
	return v87
end
function v_u_2.craftState(p90, p91, p92, p93) -- name: craftState
	-- upvalues: (copy) v_u_2
	if p93 then
		return false, "Working..."
	elseif p90.locked then
		local v94 = false
		local v95 = p90.reason
		if not v95 then
			local v96 = p90.locked
			v95 = "Needs PINS " .. tostring(v96)
		end
		return v94, v95
	else
		local _, _, v97 = v_u_2.lineStats(p90)
		if v97 > 0 then
			return false, p90.reason or ("Missing %d item%s"):format(v97, v97 == 1 and "" or "s")
		elseif p90.noRoom then
			return false, p90.reason
		elseif p91 then
			return true, nil
		else
			return false, p92 or "Check the payment"
		end
	end
end
function v_u_2.swapState(p98, p99, p100, p101, p102, p103) -- name: swapState
	if p103 then
		return false, "Working..."
	elseif p98 and p98.open ~= false then
		if p99 < 3 then
			local v104 = 3 - p99
			return false, ("Pick %d more part%s of this tier"):format(v104, v104 == 1 and "" or "s")
		elseif p100 then
			if p101 then
				return true, nil
			else
				return false, p102 or "Check the payment"
			end
		else
			return false, "Choose the part you want"
		end
	else
		local v105 = p98 and p98.lock or "a higher level"
		return false, "Needs PINS " .. tostring(v105)
	end
end
function v_u_2.repParts(p106, p107, p108, p109, p110) -- name: repParts
	-- upvalues: (copy) v_u_2
	local v111 = (tonumber(p107) or 0) * 100 + 0.5
	local v112 = math.floor(v111)
	local v113
	if p106 > 0 then
		v113 = ("%d open%s"):format(p106, p107 <= 0 and "" or (", up to +%d"):format(v112))
	else
		v113 = p107 <= 0 and "all done" or ("+%d, more unlock with levels"):format(v112)
	end
	local v114 = (1 / 0)
	local v115 = 0
	for _, v116 in p108 or { 0.015, 0.025, 0.04 } do
		local v117 = tonumber(v116) or 0
		if v117 <= 0 then
			continue
		end
		v114 = math.min(v114, v117)
		v115 = math.max(v115, v117)
	end
	if v114 == (1 / 0) then
		v114 = 0.015
		v115 = 0.04
	end
	return v113, ("+%s to +%s per gun (%d / %d)"):format(v_u_2.fmtPts(v114), v_u_2.fmtPts(v115), p109, p110)
end
function v_u_2.gainRepBody(p118, p119, p120) -- name: gainRepBody
	-- upvalues: (copy) v_u_2
	local v121 = (1 / 0)
	local v122 = 0
	for _, v123 in p119 or { 0.015, 0.025, 0.04 } do
		local v124 = tonumber(v123) or 0
		if v124 <= 0 then
			continue
		end
		v121 = math.min(v121, v124)
		v122 = math.max(v122, v124)
	end
	if v121 == (1 / 0) then
		v121 = 0.015
		v122 = 0.04
	end
	return ("Finish the jobs for %s, and build guns at her bench. %s does not trade for cash: every gun gives +%s to +%s rep, up to %d rep from the bench in total."):format(p118, p118, v_u_2.fmtPts(v121), v_u_2.fmtPts(v122), p120)
end
function v_u_2.stageTabs(p125) -- name: stageTabs
	local v126
	if type(p125) == "table" then
		local v127 = p125.stage
		v126 = tonumber(v127) or 0
	else
		v126 = 0
	end
	if v126 < 1 then
		return {}
	end
	if v126 == 1 then
		return {
			{
				["id"] = "tasks",
				["text"] = "Tasks"
			}
		}
	end
	local v128 = {
		{
			["id"] = "craft",
			["text"] = "Craft"
		}
	}
	if type(p125) == "table" and p125.services ~= false then
		table.insert(v128, {
			["id"] = "services",
			["text"] = "Services"
		})
	end
	table.insert(v128, {
		["id"] = "tasks",
		["text"] = "Tasks"
	})
	return v128
end
function v_u_2.defaultSub(p129) -- name: defaultSub
	-- upvalues: (copy) v_u_2
	local v130 = v_u_2.stageTabs(p129)
	return not v130[1] and "locked" or v130[1].id
end
function v_u_2.validSub(p131, p132) -- name: validSub
	-- upvalues: (copy) v_u_2
	local v133 = v_u_2.stageTabs(p131)
	if #v133 == 0 then
		return "locked"
	end
	for _, v134 in v133 do
		if v134.id ~= p132 then
			continue
		end
		return p132
	end
	return v133[1].id
end
function v_u_2.tierText(p135) -- name: tierText
	return ("Tier %d  \194\183  fee %d"):format(p135.tier, p135.fee)
end
function v_u_2.payStateFrom(p136, p137) -- name: payStateFrom
	local v138 = {}
	for _, v139 in p137 or {} do
		local v140 = v139.uid
		local v141 = v139.n
		v138[v140] = tonumber(v141) or 1
	end
	local v142 = {}
	for _, v143 in p136 or {} do
		if not v138[v143.uid] then
			continue
		end
		local v144 = v143.uid
		local v145 = v143.n
		local v146 = tonumber(v145) or 1
		local v147 = v138[v143.uid]
		v142[v144] = math.min(v146, v147)
	end
	return v142
end
function v_u_2.payStateClamp(p148, p149) -- name: payStateClamp
	local v150 = {}
	for _, v151 in p149 or {} do
		local v152 = v151.uid
		local v153 = v151.n
		v150[v152] = tonumber(v153) or 1
	end
	local v154 = {}
	for v155, v156 in p148 or {} do
		if not v150[v155] or v156 <= 0 then
			continue
		end
		local v157 = v150[v155]
		v154[v155] = math.min(v156, v157)
	end
	return v154
end
function v_u_2.trustSteps(p158, p159) -- name: trustSteps
	-- upvalues: (copy) v_u_2
	local v160 = "Finish QUIET WORK for Gunner"
	if p159 then
		local v161 = p159.get
		if type(v161) == "function" then
			local v162 = p159.get
			local v163, v164 = pcall(v162, "gun_02")
			if v163 and type(v164) == "table" then
				local v165 = {}
				local v166 = v164.minLevel
				if (tonumber(v166) or 1) > 1 then
					local v167 = v164.minLevel
					table.insert(v165, ("Gunner at level %d"):format(v167))
				end
				local v168 = v164.requires
				local v169
				if type(v168) == "table" then
					v169 = v164.requires[1] or nil
				else
					v169 = nil
				end
				local v170 = p159.get
				local v171, v172 = pcall(v170, v169)
				if v169 and (v171 and type(v172) == "table") then
					local v173 = v172.title
					if type(v173) == "string" then
						local v174 = v172.title
						table.insert(v165, ("%s done first"):format(v174))
					end
				end
				if #v165 > 0 then
					v160 = ("%s (it needs %s)"):format(v160, table.concat(v165, " and "))
				end
			end
		end
	end
	local v175 = 0
	for _, v176 in v_u_2.TRUST_JOBS do
		if p158(v176) ~= "done" then
			continue
		end
		v175 = v175 + 1
	end
	return {
		{
			["text"] = v160,
			["done"] = p158("gun_02") == "done"
		},
		{
			["text"] = ("Finish her three trust jobs (%d of 3)"):format(v175),
			["done"] = v175 >= 3
		},
		{
			["text"] = "The bench opens",
			["done"] = false
		}
	}, v175
end
v_u_2.TWIN_FEE = 8
v_u_2.TWIN_TEXT = {
	["none"] = "You have no pistols in your stash that can be paired. Four models can: the P17, the SP-9, the M1911 and the Snub.",
	["noPairs"] = "You have no pairs. Couple two like pistols to make one.",
	["pickTwo"] = "Pick two like pistols.",
	["pickOne"] = "Pick the second pistol."
}
function v_u_2.twinLists(p177, p178, p179) -- name: twinLists
	local v180 = {}
	local v181 = {}
	if type(p177) ~= "table" or p179 == nil then
		return v180, v181
	end
	local v182 = {}
	for _, v183 in p177 do
		if type(v183) ~= "table" or v183.tw ~= true then
			continue
		end
		local v184 = p179.second(v183)
		if not v184 or v184.uid == nil then
			continue
		end
		v182[v184.uid] = true
	end
	for _, v185 in p177 do
		if type(v185) ~= "table" then
			continue
		end
		local v186 = v185.id
		if type(v186) ~= "string" or v182[v185.uid] then
			continue
		end
		local v187 = p178(v185.id)
		if type(v187) ~= "table" or v187.category ~= "firearm" then
			continue
		end
		local v188 = v187.weaponId
		if type(v188) ~= "string" or p179.TWIN_IDS[v187.weaponId] ~= true then
			continue
		end
		local v189 = {
			["inst"] = v185,
			["id"] = v185.id,
			["uid"] = v185.uid,
			["name"] = v187.name or v185.id
		}
		local v190 = v185.ammo
		v189.ammo = tonumber(v190)
		local v191 = v185.dur
		v189.dur = tonumber(v191)
		v189.gold = v187.gold == true
		if v185.tw == true then
			table.insert(v181, v189)
		else
			local v192 = v185.items
			if type(v192) == "table" and next(v185.items) ~= nil then
				continue
			end
			table.insert(v180, v189)
		end
	end
	return v180, v181
end
function v_u_2.twinDry(p193, p194, p195, p196) -- name: twinDry
	if p196 == nil then
		return {
			["ok"] = false,
			["why"] = "Not available.",
			["lines"] = nil,
			["lines"] = {}
		}
	end
	local v197, v198 = p196.canCouple(p193, p194, p195)
	if not v197 then
		return {
			["ok"] = false,
			["why"] = nil,
			["lines"] = nil,
			["why"] = v198,
			["lines"] = {}
		}
	end
	local v199 = p196.couple(p193, p194)
	local v200, v201 = p196.valid(v199, p195)
	if not v200 then
		return {
			["ok"] = false,
			["why"] = nil,
			["lines"] = nil,
			["why"] = v201,
			["lines"] = {}
		}
	end
	local v202, v203 = p196.split(v199)
	if v202 == nil or (v203 == nil or (v202.uid ~= p193.uid or v203.uid ~= p194.uid)) then
		return {
			["ok"] = false,
			["why"] = "The pair is incomplete.",
			["lines"] = nil,
			["lines"] = {}
		}
	end
	local v204 = p195(p193.id)
	local v205 = {}
	local v206 = "Pair of %s"
	local v207
	if v204 and v204.name then
		v207 = v204.name
	else
		local v208 = p193.id
		v207 = tostring(v208)
	end
	local v209 = v206:format(v207)
	local v210 = "Magazines stay: %s + %s rounds"
	local v211
	if p193 then
		v211 = p193.ammo
	else
		v211 = p193
	end
	local v212
	if tonumber(v211) then
		local v213 = p193.ammo
		local v214 = tonumber(v213)
		local v215 = math.floor(v214)
		v212 = tostring(v215)
	else
		v212 = "?"
	end
	local v216
	if p194 then
		v216 = p194.ammo
	else
		v216 = p194
	end
	local v217
	if tonumber(v216) then
		local v218 = p194.ammo
		local v219 = tonumber(v218)
		local v220 = math.floor(v219)
		v217 = tostring(v220)
	else
		v217 = "?"
	end
	__set_list(v205, 1, {v209, v210:format(v212, v217), "Attachments, wear and tags stay with their gun", "Fires in turn, reloads both at once. Split it any time, free."})
	return {
		["ok"] = true,
		["lines"] = nil,
		["pair"] = nil,
		["lines"] = v205,
		["pair"] = v199
	}
end
function v_u_2.new(p_u_221, p_u_222) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_1
	local v_u_223 = p_u_221.ui
	local v_u_224 = p_u_221.theme
	local v_u_225 = v_u_224.color
	local v_u_226 = p_u_221.kit
	local v_u_227 = p_u_222.phone == true
	local v_u_228 = p_u_222.compact == true
	local v_u_229 = {}
	local v_u_230 = nil
	local function v231()
		-- upvalues: (ref) v_u_230, (copy) p_u_221
		v_u_230 = p_u_221.cctx.shared.Gunsmith
	end
	pcall(v231)
	local v_u_232 = nil
	local function v233()
		-- upvalues: (ref) v_u_232, (copy) p_u_221
		v_u_232 = p_u_221.cctx.shared.WeaponParts
	end
	pcall(v233)
	local v_u_234 = nil
	local function v235()
		-- upvalues: (ref) v_u_234, (copy) p_u_221
		v_u_234 = p_u_221.cctx.shared.Tasks
	end
	pcall(v235)
	local v_u_236 = {
		["view"] = nil,
		["sel"] = nil,
		["payN"] = nil,
		["custom"] = false,
		["busy"] = false,
		["busyAt"] = 0,
		["flash"] = nil,
		["page"] = false,
		["lastSub"] = "",
		["swap"] = nil,
		["twin"] = nil,
		["confirm"] = nil,
		["ui"] = nil,
		["payN"] = {},
		["swap"] = {
			["tier"] = 3,
			["give"] = nil,
			["want"] = nil,
			["payN"] = nil,
			["custom"] = false,
			["give"] = {},
			["payN"] = {}
		},
		["twin"] = {
			["a"] = nil,
			["b"] = nil,
			["payN"] = nil,
			["custom"] = false,
			["payN"] = {}
		},
		["ui"] = {}
	}
	v_u_229.state = v_u_236
	local function v_u_238(p237) -- name: nameOf
		-- upvalues: (copy) v_u_226
		return v_u_226.itemName(p237)
	end
	local function v_u_251(p239) -- name: stashCount
		-- upvalues: (copy) p_u_221, (ref) v_u_230
		local v240 = p_u_221.profile
		local v241
		if type(v240) == "table" then
			local v242 = v240.inv
			if type(v242) == "table" then
				local v243 = v240.inv.containers
				if type(v243) == "table" then
					v241 = v240.inv.containers.stash or nil
				else
					v241 = nil
				end
			else
				v241 = nil
			end
		else
			v241 = nil
		end
		local v244 = 0
		if type(v241) == "table" then
			local v245 = v241.items
			if type(v245) == "table" then
				local v246
				if v_u_230 and (v_u_230.flatten and v_u_230.nestedDepth) then
					v246 = v_u_230.flatten(v241.items, v_u_230.nestedDepth())
				else
					v246 = v241.items
				end
				for _, v247 in v246 do
					if type(v247) ~= "table" or v247.id ~= p239 then
						continue
					end
					local v248 = v247.n
					local v249 = tonumber(v248) or 1
					local v250 = math.floor(v249)
					v244 = v244 + math.max(1, v250)
				end
			end
		end
		return v244
	end
	local function v_u_255(p252) -- name: rowOf
		-- upvalues: (copy) v_u_236
		local v253 = v_u_236.view
		if not (v253 and p252) then
			return nil
		end
		for _, v254 in v253.recipes or {} do
			if v254.id ~= p252 then
				continue
			end
			return v254
		end
		return nil
	end
	local function v_u_274(p256, p257, p258, p259, p260) -- name: chip
		-- upvalues: (copy) v_u_223, (copy) v_u_225
		local v261 = p260 or {}
		local v262 = v_u_223.new
		local v263 = "Frame"
		local v264 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["ZIndex"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = v261.name or "Chip"
		}
		local v265
		if p259 then
			v265 = p258
		else
			v265 = v_u_225.bgDeep
		end
		v264.BackgroundColor3 = v265
		v264.BackgroundTransparency = p259 and 0 or 0.25
		v264.AutomaticSize = Enum.AutomaticSize.X
		v264.Size = UDim2.fromOffset(0, v261.h or 18)
		v264.Position = v261.position or UDim2.new()
		v264.AnchorPoint = v261.anchor or Vector2.zero
		v264.ZIndex = v261.zindex or 3
		v264.LayoutOrder = v261.order or 0
		local v266 = v262(v263, v264, p256)
		if not p259 then
			v_u_223.stroke(v266, p258, 1, 0.3)
		end
		v_u_223.pad(v266, {
			v261.icon and 4 or 6,
			6,
			0,
			0
		})
		v_u_223.layout(v266, "h", 3)
		if v261.icon then
			local v267 = v_u_223.icon
			local v268 = v261.icon
			local v269 = {
				["size"] = 10,
				["color"] = nil
			}
			local v270
			if p259 then
				v270 = v_u_225.bgDeep
			else
				v270 = p258
			end
			v269.color = v270
			local v271 = v267(v268, v269)
			v271.LayoutOrder = 1
			v271.ZIndex = (v261.zindex or 3) + 1
			v271.Parent = v266
		end
		local v272 = v_u_223.label
		local v273 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["track"] = false,
			["zindex"] = nil,
			["parent"] = v266,
			["text"] = p257
		}
		if p259 then
			p258 = v_u_225.bgDeep
		end
		v273.color = p258
		v273.size = UDim2.fromOffset(0, v261.h or 18)
		v273.zindex = (v261.zindex or 3) + 1
		v272(v273)
		return v266
	end
	local function v_u_276(p275) -- name: flashOverlay
		-- upvalues: (copy) v_u_223, (copy) v_u_225
		return v_u_223.new("Frame", {
			["Name"] = "FlashOverlay",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 20,
			["Active"] = false,
			["BackgroundColor3"] = v_u_225.white,
			["Size"] = UDim2.fromScale(1, 1)
		}, p275)
	end
	local function v_u_282(p277, p278, p279, p280) -- name: checkIcon
		-- upvalues: (copy) v_u_223, (copy) v_u_225
		local v281 = v_u_223.new("Frame", {
			["Name"] = "Check",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Position"] = nil,
			["Size"] = UDim2.fromOffset(p279, p279),
			["Position"] = p280 or UDim2.new()
		}, p277)
		if p278 then
			v_u_223.icon("check", {
				["parent"] = nil,
				["size"] = nil,
				["color"] = nil,
				["thickness"] = 2,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v281,
				["size"] = p279 - 2,
				["color"] = v_u_225.success,
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			}).Name = "Mark"
			return v281
		else
			v_u_223.icon("close", {
				["parent"] = nil,
				["size"] = nil,
				["color"] = nil,
				["thickness"] = 2,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v281,
				["size"] = p279 - 4,
				["color"] = v_u_225.danger,
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			}).Name = "Mark"
			return v281
		end
	end
	local function v_u_303(p_u_283) -- name: confirmDialog
		-- upvalues: (copy) v_u_236, (copy) v_u_223, (copy) v_u_227, (copy) v_u_225
		if v_u_236.confirm then
			local v284 = v_u_236.confirm.close
			pcall(v284)
			v_u_236.confirm = nil
		end
		local v_u_285 = nil
		local v_u_299 = v_u_223.modal({
			["title"] = p_u_283.title,
			["width"] = v_u_227 and 600 or 540,
			["buttons"] = {
				{
					["text"] = "Cancel",
					["kind"] = "ghost"
				},
				{
					["text"] = nil,
					["kind"] = "primary",
					["onClick"] = nil,
					["text"] = p_u_283.action,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_236, (copy) p_u_283
						v_u_236.confirm = nil
						p_u_283.onYes()
					end
				}
			},
			["onClose"] = function() -- name: onClose
				-- upvalues: (ref) v_u_236, (ref) v_u_285
				if v_u_236.confirm == v_u_285 then
					v_u_236.confirm = nil
				end
			end,
			["build"] = function(p286) -- name: build
				-- upvalues: (copy) p_u_283, (ref) v_u_223, (ref) v_u_225
				local v287 = 0
				for _, v288 in p_u_283.outro or {} do
					v287 = v287 + 1
					v_u_223.label({
						["parent"] = nil,
						["name"] = "Summary",
						["text"] = nil,
						["style"] = nil,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = p286,
						["text"] = v288.text,
						["style"] = v288.style or "small",
						["color"] = v288.color or v_u_225.text2,
						["order"] = v287
					})
				end
				if p_u_283.intro then
					local v289 = v287 + 1
					v_u_223.label({
						["parent"] = nil,
						["name"] = "Intro",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["order"] = nil,
						["size"] = nil,
						["parent"] = p286,
						["text"] = p_u_283.intro,
						["color"] = v_u_225.text2,
						["order"] = v289,
						["size"] = UDim2.new(1, 0, 0, 18)
					})
				end
				for v290, v291 in p_u_283.groups do
					v_u_223.label({
						["parent"] = nil,
						["name"] = "GroupTitle",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["order"] = nil,
						["size"] = nil,
						["parent"] = p286,
						["text"] = v291.title,
						["color"] = v_u_225.muted,
						["order"] = 100 + v290 * 2,
						["size"] = UDim2.new(1, 0, 0, 18)
					})
					local v292 = v_u_223.new("Frame", {
						["Name"] = nil,
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "Group_" .. v291.title,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["LayoutOrder"] = 100 + v290 * 2 + 1
					}, p286)
					v_u_223.new("UIGridLayout", {
						["CellSize"] = UDim2.new(0.5, -4, 0, 22),
						["CellPadding"] = UDim2.fromOffset(8, 2),
						["SortOrder"] = Enum.SortOrder.LayoutOrder
					}, v292)
					for v293, v294 in v291.lines do
						local v295 = v_u_223.new("Frame", {
							["Name"] = "Line",
							["BackgroundTransparency"] = 1,
							["LayoutOrder"] = nil,
							["LayoutOrder"] = v293
						}, v292)
						v_u_223.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v295,
							["text"] = v294.name,
							["color"] = v_u_225.text,
							["size"] = UDim2.new(1, -34, 1, 0)
						})
						local v296 = v_u_223.label
						local v297 = {
							["parent"] = nil,
							["name"] = "Count",
							["text"] = nil,
							["style"] = "monoS",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v295
						}
						local v298 = v294.n
						v297.text = "x" .. tostring(v298)
						v297.color = v_u_225.accent
						v297.position = UDim2.new(1, -32, 0, 0)
						v297.size = UDim2.fromOffset(32, 22)
						v296(v297)
					end
				end
			end
		})
		v_u_236.confirm = v_u_299
		v_u_236.confirmOnYes = p_u_283.onYes
		local function v302()
			-- upvalues: (ref) v_u_299
			local v300 = {}
			for _, v301 in v_u_299.frame:FindFirstChild("Buttons", true):GetChildren() do
				if not v301:IsA("TextButton") then
					continue
				end
				table.insert(v300, v301)
			end
			if v300[1] then
				v300[1].Name = "CancelButton"
			end
			if v300[2] then
				v300[2].Name = "ConfirmButton"
			end
		end
		pcall(v302)
		return v_u_299
	end
	local function v_u_400(p304, p305, p_u_306, p_u_307, p_u_308, p_u_309) -- name: buildPay
		-- upvalues: (copy) v_u_236, (copy) v_u_226, (ref) v_u_2, (copy) v_u_223, (copy) v_u_225, (ref) v_u_3, (copy) v_u_224, (copy) v_u_238
		local v310 = v_u_236.view
		local v_u_311
		if v310 then
			local v312 = v310.goldInStash
			v_u_311 = type(v312) ~= "table" and {} or v310.goldInStash
		else
			v_u_311 = {}
		end
		local v_u_313 = {
			["rows"] = {},
			["order"] = p305
		}
		v_u_226.section(p304, "Fee", p305, v_u_2.goldPts(p_u_306))
		local v_u_314 = v_u_223.label({
			["parent"] = nil,
			["name"] = "PaySummary",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = p304,
			["color"] = v_u_225.text2,
			["order"] = p305 + 1
		})
		local v_u_315 = v_u_223.label({
			["parent"] = nil,
			["name"] = "PayWith",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = p304,
			["color"] = v_u_225.text,
			["order"] = p305 + 2
		})
		local v_u_316 = nil
		local v_u_317 = v_u_224.touch(40)
		local v_u_318 = v_u_224.touch(36)
		local function v_u_344() -- name: repaint
			-- upvalues: (ref) v_u_2, (copy) p_u_307, (copy) v_u_311, (copy) p_u_306, (ref) v_u_236, (copy) v_u_314, (copy) v_u_315, (ref) v_u_238, (ref) v_u_225, (copy) v_u_313, (ref) v_u_3
			local _, v319 = v_u_2.payList(p_u_307.payN, v_u_311)
			local v320, v321, v322 = v_u_2.checkPay(p_u_306, v319, v_u_236.view and v_u_236.view.maxPay or v_u_2.MAX_PAY)
			v_u_314.Text = v_u_2.paySummary(p_u_306, v322.points, v322.lost)
			v_u_315.Text = "Paying with: " .. v_u_2.payWith(v319, v_u_238)
			local v323 = v_u_314
			local v324
			if v320 or v322.points <= 0 then
				if v320 and v322.lost > 0 then
					v324 = v_u_225.accent
				else
					v324 = v_u_225.text2
				end
			else
				v324 = v_u_225.danger
			end
			v323.TextColor3 = v324
			for _, v325 in v_u_313.rows do
				local v326 = p_u_307.payN[v325.g.uid]
				local v327 = tonumber(v326) or 0
				local v328 = math.floor(v327)
				local v329 = v328 > 0
				local v330 = v325.toggle
				local v331
				if v329 then
					v331 = v_u_225.accentDeep
				else
					v331 = v_u_225.raised
				end
				v330.BackgroundColor3 = v331
				v325.toggle.BackgroundTransparency = v329 and 0.05 or 0.25
				local v332 = v325.stroke
				local v333
				if v329 then
					v333 = v_u_225.accent
				else
					v333 = v_u_225.line
				end
				v332.Color = v333
				local v334 = v325.box
				local v335
				if v329 then
					v335 = v_u_225.accent
				else
					v335 = v_u_225.bgDeep
				end
				v334.BackgroundColor3 = v335
				v325.mark.Visible = v329
				local v336 = v325.count
				local v337
				if v325.g.n > 1 then
					v337 = ("%d / %d  \194\183  %d %s each"):format(v328, v325.g.n, v325.g.points, v325.g.points == 1 and "pt" or "pts")
				else
					v337 = ("%d %s"):format(v325.g.points, v325.g.points == 1 and "point" or "points")
				end
				v336.Text = v337
				local v338 = v325.count
				local v339
				if v329 then
					v339 = v_u_225.accent
				else
					v339 = v_u_225.text2
				end
				v338.TextColor3 = v339
				v325.toggle:SetAttribute("Picked", v328)
				if not v325.minus then
					continue
				end
				v325.minus.Active = v328 > 0
				v325.minus.TextTransparency = v328 > 0 and 0 or 0.6
				v325.plus.Active = v328 < v325.g.n
				v325.plus.TextTransparency = v328 < v325.g.n and 0 or 0.6
			end
			if v_u_313.cheap then
				local v340 = v_u_313.cheap
				local v341
				if v_u_3.payOpen == true then
					v341 = p_u_307.custom == true
				else
					v341 = false
				end
				v340.Visible = v341
			end
			local v342 = v_u_313
			local v343 = v_u_313
			v_u_313.ok = v320
			v342.why = v321
			v343.info = v322
			return v320, v321, v322
		end
		v_u_313.repaint = v_u_344
		local v345
		if #v_u_311 == 0 then
			v_u_226.empty(p304, "You have no gold stuff in your stash. Gold chains, watches, bars and coin collections pay the fee.", p305 + 3).TextColor3 = v_u_225.danger
			v345 = v_u_316
		else
			local v346 = v_u_223.new("Frame", {
				["Name"] = "PayToggleRow",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, v_u_224.touch(36)),
				["LayoutOrder"] = p305 + 3
			}, p304)
			local _, v351 = v_u_223.button({
				["parent"] = nil,
				["name"] = "PayToggle",
				["text"] = "Change payment",
				["kind"] = "secondary",
				["size"] = nil,
				["onClick"] = nil,
				["parent"] = v346,
				["size"] = UDim2.new(1, 0, 1, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_3, (copy) v_u_313, (copy) p_u_307, (ref) v_u_316
					v_u_3.payOpen = v_u_3.payOpen ~= true
					local v347 = v_u_3.payOpen == true
					for _, v348 in v_u_313.rows do
						v348.frame.Visible = v347
					end
					if v_u_313.cheap then
						local v349 = v_u_313.cheap
						local v350
						if v347 then
							v350 = p_u_307.custom == true
						else
							v350 = v347
						end
						v349.Visible = v350
					end
					if v_u_316 then
						v_u_316.setText(v347 and "Hide payment" or "Change payment")
					end
				end
			})
			v_u_316 = v351
			v345 = v_u_316
		end
		for v352, v_u_353 in v_u_311 do
			local v_u_354 = v_u_223.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "PayRow_" .. v_u_353.uid,
				["Size"] = UDim2.new(1, 0, 0, v_u_317),
				["LayoutOrder"] = p305 + 3 + v352
			}, p304)
			local v355 = v_u_353.n
			local v356 = (tonumber(v355) or 1) > 1
			local v357 = not v356 and 0 or v_u_318 * 2 + 8
			local v358 = v_u_223.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Name"] = "Pay_" .. v_u_353.uid,
				["BackgroundColor3"] = v_u_225.raised,
				["Size"] = UDim2.new(1, -v357, 1, 0)
			}, v_u_354)
			local v359 = v_u_223.stroke(v358, v_u_225.line)
			local v360 = v_u_223.new("Frame", {
				["Name"] = "Box",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_225.bgDeep,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 8, 0.5, 0),
				["Size"] = UDim2.fromOffset(20, 20)
			}, v358)
			v_u_223.stroke(v360, v_u_225.lineStrong)
			local v361 = v_u_223.icon("check", {
				["parent"] = nil,
				["size"] = 14,
				["color"] = nil,
				["thickness"] = 2,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v360,
				["color"] = v_u_225.ink,
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5)
			})
			v361.Visible = false
			local v362 = v_u_226.itemDef(v_u_353.id)
			local v363
			if v362 then
				v363 = v_u_224.rarityColor(v362.shown or v362.rarity)
			else
				v363 = v_u_225.text
			end
			local v364 = v_u_223.label
			local v365 = {
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 13,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v358
			}
			local v366 = v_u_353.id
			v365.text = v_u_226.itemName(v366)
			v365.color = v363:Lerp(v_u_225.text, 0.6)
			v365.position = UDim2.fromOffset(36, 3)
			v365.size = UDim2.new(1, -44, 0.5, 0)
			v364(v365)
			local v367 = {
				["g"] = v_u_353,
				["toggle"] = v358,
				["stroke"] = v359,
				["box"] = v360,
				["mark"] = v361,
				["count"] = v_u_223.label({
					["parent"] = nil,
					["name"] = "Count",
					["text"] = "",
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v358,
					["color"] = v_u_225.text2,
					["position"] = UDim2.new(0, 36, 0.5, 0),
					["size"] = UDim2.new(1, -44, 0.5, -3)
				}),
				["frame"] = v_u_354
			}
			if v356 then
				local function v382(p368, p369, p_u_370) -- name: stepBtn
					-- upvalues: (ref) v_u_223, (copy) v_u_353, (ref) v_u_224, (ref) v_u_225, (copy) v_u_318, (copy) v_u_317, (copy) v_u_354, (copy) p_u_307, (copy) v_u_344, (copy) p_u_308
					local v371 = v_u_223.new
					local v372 = "TextButton"
					local v373 = {
						["Name"] = nil,
						["Text"] = nil,
						["AutoButtonColor"] = false,
						["FontFace"] = nil,
						["TextSize"] = 18,
						["TextColor3"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.25,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil
					}
					local v374
					if p_u_370 < 0 then
						v374 = "Minus_" .. v_u_353.uid
					else
						v374 = "Plus_" .. v_u_353.uid
					end
					v373.Name = v374
					v373.Text = p368
					v373.FontFace = v_u_224.font.monoBold
					v373.TextColor3 = v_u_225.text
					v373.BackgroundColor3 = v_u_225.raised
					v373.AnchorPoint = Vector2.new(1, 0)
					v373.Position = UDim2.new(1, p369, 0, 0)
					v373.Size = UDim2.fromOffset(v_u_318, v_u_317)
					local v_u_375 = v371(v372, v373, v_u_354)
					v_u_223.stroke(v_u_375, v_u_225.line)
					local function v_u_381()
						-- upvalues: (copy) v_u_375, (ref) v_u_223, (ref) v_u_224, (ref) p_u_307, (ref) v_u_353, (copy) p_u_370, (ref) v_u_344, (ref) p_u_308
						if v_u_375.Active then
							p_u_307.custom = true
							local v376 = p_u_307.payN
							local v377 = v_u_353.uid
							local v378 = p_u_307.payN[v_u_353.uid]
							local v379 = (tonumber(v378) or 0) + p_u_370
							local v380 = v_u_353.n
							v376[v377] = math.clamp(v379, 0, v380)
							v_u_344()
							p_u_308()
						else
							v_u_223.sound(v_u_224.sounds.error)
						end
					end
					v_u_375.Selectable = true
					v_u_375.SelectionImageObject = v_u_223.selectionImage()
					v_u_375.Activated:Connect(function()
						-- upvalues: (ref) v_u_223, (ref) v_u_224, (copy) v_u_381
						v_u_223.sound(v_u_224.sounds.click)
						v_u_381()
					end)
					return v_u_375
				end
				v367.minus = v382("-", -(v_u_318 + 4), -1)
				v367.plus = v382("+", 0, 1)
			end
			local function v_u_393()
				-- upvalues: (copy) p_u_307, (copy) v_u_353, (copy) v_u_311, (copy) p_u_306, (copy) v_u_344, (copy) p_u_308
				p_u_307.custom = true
				local v383 = p_u_307.payN[v_u_353.uid]
				if (tonumber(v383) or 0) > 0 then
					p_u_307.payN[v_u_353.uid] = 0
				else
					local v384 = 0
					for _, v385 in v_u_311 do
						if v385.uid == v_u_353.uid then
							continue
						end
						local v386 = p_u_307.payN[v385.uid]
						v384 = v384 + (tonumber(v386) or 0) * v385.points
					end
					local v387 = p_u_307.payN
					local v388 = v_u_353.uid
					local v389 = p_u_306 - v384
					local v390 = math.max(v389, 1) / v_u_353.points
					local v391 = math.ceil(v390)
					local v392 = v_u_353.n
					v387[v388] = math.clamp(v391, 1, v392)
				end
				v_u_344()
				p_u_308()
			end
			v358.Selectable = true
			v358.SelectionImageObject = v_u_223.selectionImage()
			v358.Activated:Connect(function()
				-- upvalues: (ref) v_u_223, (ref) v_u_224, (copy) v_u_393
				v_u_223.sound(v_u_224.sounds.click)
				v_u_393()
			end)
			local v394 = v_u_313.rows
			table.insert(v394, v367)
		end
		local v395 = v_u_223.new("Frame", {
			["Name"] = "CheapRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = false,
			["Size"] = UDim2.new(1, 0, 0, v_u_224.touch(36)),
			["LayoutOrder"] = p305 + 4 + #v_u_311
		}, p304)
		local _, _ = v_u_223.button({
			["parent"] = nil,
			["text"] = "Use the cheapest payment",
			["kind"] = "ghost",
			["size"] = nil,
			["height"] = 36,
			["onClick"] = nil,
			["parent"] = v395,
			["size"] = UDim2.new(1, 0, 1, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_309
				p_u_309()
			end
		})
		v_u_313.cheap = v395
		local v396 = v_u_3.payOpen == true
		for _, v397 in v_u_313.rows do
			v397.frame.Visible = v396
		end
		if v_u_313.cheap then
			local v398 = v_u_313.cheap
			local v399
			if v396 then
				v399 = p_u_307.custom == true
			else
				v399 = v396
			end
			v398.Visible = v399
		end
		if v345 then
			v345.setText(v396 and "Hide payment" or "Change payment")
		end
		v_u_344()
		return v_u_313
	end
	function v_u_229.setView(p401) -- name: setView
		-- upvalues: (copy) v_u_236, (copy) v_u_255, (ref) v_u_2
		local v402 = v_u_236
		if type(p401) ~= "table" then
			p401 = nil
		end
		v402.view = p401
		if v_u_236.view then
			if not v_u_255(v_u_236.sel) then
				v_u_236.sel = nil
			end
			if v_u_236.custom then
				local v403 = v_u_236
				local v404 = v_u_2.payStateClamp
				local v405 = v_u_236.payN
				local v406 = v_u_236.view
				local v407
				if v406 then
					local v408 = v406.goldInStash
					v407 = type(v408) ~= "table" and {} or v406.goldInStash
				else
					v407 = {}
				end
				v403.payN = v404(v405, v407)
			else
				local v409 = v_u_255(v_u_236.sel)
				local v410 = v_u_236
				local v411 = v_u_2.payStateFrom
				if v409 then
					v409 = v409.pay
				end
				local v412 = v_u_236.view
				local v413
				if v412 then
					local v414 = v412.goldInStash
					v413 = type(v414) ~= "table" and {} or v412.goldInStash
				else
					v413 = {}
				end
				v410.payN = v411(v409, v413)
				v_u_236.custom = false
			end
			local v415 = v_u_236.swap
			if v415.custom then
				local v416 = v_u_2.payStateClamp
				local v417 = v415.payN
				local v418 = v_u_236.view
				local v419
				if v418 then
					local v420 = v418.goldInStash
					v419 = type(v420) ~= "table" and {} or v418.goldInStash
				else
					v419 = {}
				end
				v415.payN = v416(v417, v419)
			else
				v415.payN = {}
			end
			local v421 = {}
			if v_u_236.view.swap then
				local v422 = v_u_236.view.swap.parts
				if type(v422) == "table" then
					for _, v423 in v_u_236.view.swap.parts do
						v421[v423.uid] = true
					end
				end
			end
			for v424 in v415.give do
				if v421[v424] then
					continue
				end
				v415.give[v424] = nil
			end
		end
	end
	function v_u_229.cardVisible() -- name: cardVisible
		-- upvalues: (copy) v_u_236
		local v425 = v_u_236.view
		local v426
		if type(v425) == "table" then
			v426 = v425.enabled ~= false
		else
			v426 = false
		end
		return v426
	end
	function v_u_229.stage() -- name: stage
		-- upvalues: (copy) v_u_236
		local v427 = v_u_236.view
		if type(v427) ~= "table" or v427.enabled == false then
			return 0
		end
		local v428 = v427.stage
		return tonumber(v428) or 0
	end
	function v_u_229.traderView() -- name: traderView
		-- upvalues: (copy) v_u_236
		local v429 = v_u_236.view
		if type(v429) == "table" and v429.enabled ~= false then
			local v430 = v429.stage
			if (tonumber(v430) or 0) >= 1 then
				return {
					["lvl"] = v429.lvl,
					["maxLevel"] = v429.maxLevel,
					["rep"] = v429.rep,
					["frac"] = v429.frac,
					["next"] = v429.next,
					["tradeRep"] = v429.tradeRep,
					["points"] = v429.points,
					["extracts"] = v429.extracts
				}
			end
		end
		return nil
	end
	function v_u_229.header() -- name: header
		-- upvalues: (copy) v_u_236, (copy) v_u_229
		local v431 = v_u_236.view
		local v432 = v_u_229.stage() == 0
		local v433
		if type(v431) == "table" then
			local v434 = v431.locked
			if type(v434) == "table" then
				v433 = v431.locked
			else
				v433 = nil
			end
		else
			v433 = nil
		end
		return v432 and {
			["locked"] = true,
			["name"] = nil,
			["title"] = nil,
			["quote"] = nil,
			["location"] = "",
			["name"] = v433 and (v433.name or "GUNSMITH") or "GUNSMITH",
			["title"] = v433 and (v433.title or "LOCKED") or "LOCKED",
			["quote"] = v433 and v433.line or ""
		} or {
			["locked"] = false,
			["name"] = nil,
			["title"] = nil,
			["quote"] = nil,
			["name"] = v431 and (v431.name or "PINS") or "PINS",
			["title"] = v431 and v431.title or ""
		}
	end
	function v_u_229.lockPortrait(p435, p436) -- name: lockPortrait
		-- upvalues: (copy) v_u_223, (copy) v_u_225, (copy) v_u_224
		if p435 then
			local v437 = p435:FindFirstChild("LockedVeil")
			if p436 then
				if not v437 then
					local v438 = v_u_223.new("Frame", {
						["Name"] = "LockedVeil",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.25,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["ZIndex"] = 9,
						["BackgroundColor3"] = v_u_225.bgDeep,
						["Size"] = UDim2.fromScale(1, 1)
					}, p435)
					local v439 = v_u_223.label
					local v440 = {
						["parent"] = nil,
						["text"] = "?",
						["style"] = "h1",
						["color"] = nil,
						["align"] = "center",
						["valign"] = "center",
						["size"] = nil,
						["zindex"] = 10,
						["track"] = false,
						["textSize"] = nil,
						["parent"] = v438,
						["color"] = v_u_225.text2,
						["size"] = UDim2.fromScale(1, 1)
					}
					local v441 = p435.AbsoluteSize.Y * 0.5
					local v442 = v_u_224.uiScale()
					local v443 = v441 / math.max(v442, 0.5)
					local v444 = math.floor(v443)
					v440.textSize = math.max(24, v444)
					v439(v440)
				end
			else
				if v437 then
					v437:Destroy()
				end
				return
			end
		else
			return
		end
	end
	function v_u_229.paintCard(p445) -- name: paintCard
		-- upvalues: (copy) v_u_229, (copy) v_u_223, (copy) v_u_228, (ref) v_u_230, (copy) v_u_225
		local v446 = v_u_229.cardVisible()
		p445.btn.Visible = v446
		p445.btn.Selectable = v446
		if v446 then
			local v447 = v_u_229.stage() == 0
			local v448 = v_u_229.header()
			if p445.name then
				v_u_223.setText(p445.name, v448.name)
			end
			v_u_229.lockPortrait(p445.por, v447)
			local v449 = p445.tasks
			if p445.tasksSize0 == nil then
				local v450 = v449.Size
				local v451 = p445.btn.Size
				local v452 = v449.TextWrapped
				p445.tasksSize0 = v450
				p445.btnSize0 = v451
				p445.tasksWrap0 = v452
			end
			local v453
			if v447 then
				v453 = v_u_228
			else
				v453 = v447
			end
			v449.TextWrapped = v453 and true or p445.tasksWrap0
			local v454
			if v453 then
				v454 = UDim2.new(p445.tasksSize0.X.Scale, p445.tasksSize0.X.Offset, 0, 28)
			else
				v454 = p445.tasksSize0
			end
			v449.Size = v454
			local v455 = p445.btn
			local v456
			if v453 then
				v456 = UDim2.new(p445.btnSize0.X.Scale, p445.btnSize0.X.Offset, 0, p445.btnSize0.Y.Offset + 16)
			else
				v456 = p445.btnSize0
			end
			v455.Size = v456
			if v447 then
				p445.lvl.Text = "LOCKED"
				p445.tasks.Text = v_u_230 and v_u_230.WAY or "Do QUIET WORK for Gunner"
				p445.tasks.TextColor3 = v_u_225.accent
				p445.rep.set(0)
			elseif v_u_229.stage() == 1 then
				p445.lvl.Text = v_u_228 and "LV 1 \194\183 TRUST" or "LV 1  \194\183  TRUST JOBS"
			end
			p445.btn:SetAttribute("Stage", v_u_229.stage())
		end
	end
	function v_u_229.syncTabs(p457, p458, p459) -- name: syncTabs
		-- upvalues: (ref) v_u_2, (copy) v_u_236, (copy) v_u_226, (copy) v_u_223
		local v460 = v_u_2.stageTabs(v_u_236.view)
		local v461 = v_u_2.validSub(v_u_236.view, p458)
		local v462 = ""
		for _, v463 in v460 do
			v462 = v462 .. v463.id .. ","
		end
		if v_u_236.tabSig == v462 and (v_u_236.tabsFrame and v_u_236.tabsFrame.Parent == p457) then
			if v_u_236.tabsApi then
				local v464 = v_u_236.tabsApi.select
				pcall(v464, v461, true)
			end
		else
			v_u_226.clear(p457)
			local v465 = v_u_236
			v_u_236.tabsFrame = nil
			v465.tabsApi = nil
			v_u_236.tabSig = v462
			if #v460 > 0 then
				local v466, v467 = v_u_223.tabs({
					["parent"] = p457,
					["size"] = UDim2.fromScale(1, 1),
					["tabs"] = v460,
					["selected"] = v461,
					["onChange"] = p459
				})
				local v468 = v_u_236
				v_u_236.tabsFrame = v466
				v468.tabsApi = v467
			end
		end
		p457.Visible = #v460 > 0
		p457:SetAttribute("Tabs", v462)
		return v461
	end
	function v_u_229.validSub(p469) -- name: validSub
		-- upvalues: (ref) v_u_2, (copy) v_u_236
		return v_u_2.validSub(v_u_236.view, p469)
	end
	function v_u_229.repParts(p470, p471) -- name: repParts
		-- upvalues: (copy) v_u_236, (ref) v_u_2
		local v472 = v_u_236.view or {}
		local v473 = v472.tradeMax
		local v474 = (tonumber(v473) or 0.3) * 100 + 0.5
		local v475 = math.floor(v474)
		local v476 = v472.tradeRep
		local v477 = (tonumber(v476) or 0) * 100 + 0.0001
		local v478 = math.floor(v477)
		return v_u_2.repParts(p470, p471, v472.repPerCraft, v478, v475)
	end
	function v_u_229.gainRepBody(p479) -- name: gainRepBody
		-- upvalues: (copy) v_u_236, (ref) v_u_2
		local v480 = v_u_236.view or {}
		local v481 = v480.tradeMax
		local v482 = (tonumber(v481) or 0.3) * 100 + 0.5
		local v483 = math.floor(v482)
		return v_u_2.gainRepBody(p479, v480.repPerCraft, v483)
	end
	local function v_u_488(p484) -- name: stateOf
		-- upvalues: (copy) p_u_222
		local v485 = p_u_222.taskState
		local v486, v487 = pcall(v485, p484)
		return (not v486 or type(v487) ~= "string") and "locked" or v487
	end
	local function v_u_502(p489, p490) -- name: stepsList
		-- upvalues: (ref) v_u_2, (copy) v_u_488, (ref) v_u_234, (copy) v_u_223, (copy) v_u_225
		for v491, v492 in v_u_2.trustSteps(v_u_488, v_u_234) do
			local v493 = v_u_223.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Step" .. v491,
				["Size"] = UDim2.new(1, 0, 0, 26),
				["LayoutOrder"] = p490 + v491
			}, p489)
			local v494 = v_u_223.new
			local v495 = "Frame"
			local v496 = {
				["Name"] = "Num",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil
			}
			local v497
			if v492.done then
				v497 = v_u_225.success
			else
				v497 = v_u_225.bgDeep
			end
			v496.BackgroundColor3 = v497
			v496.AnchorPoint = Vector2.new(0, 0.5)
			v496.Position = UDim2.new(0, 0, 0.5, 0)
			v496.Size = UDim2.fromOffset(20, 20)
			local v498 = v494(v495, v496, v493)
			if not v492.done then
				v_u_223.stroke(v498, v_u_225.lineStrong)
			end
			v_u_223.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v498,
				["text"] = v492.done and "" or tostring(v491),
				["color"] = v_u_225.text2,
				["size"] = UDim2.fromScale(1, 1)
			})
			if v492.done then
				v_u_223.icon("check", {
					["parent"] = nil,
					["size"] = 13,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v498,
					["color"] = v_u_225.ink,
					["position"] = UDim2.fromScale(0.5, 0.5),
					["anchor"] = Vector2.new(0.5, 0.5)
				})
			end
			local v499 = v_u_223.label
			local v500 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v493,
				["text"] = v492.text
			}
			local v501
			if v492.done then
				v501 = v_u_225.text2
			else
				v501 = v_u_225.text
			end
			v500.color = v501
			v500.position = UDim2.fromOffset(30, 0)
			v500.size = UDim2.new(1, -30, 1, 0)
			v499(v500)
		end
	end
	function v_u_229.drawLocked(p503) -- name: drawLocked
		-- upvalues: (copy) v_u_236, (ref) v_u_230, (copy) v_u_223, (copy) v_u_228, (copy) v_u_225, (copy) v_u_226, (copy) v_u_502, (copy) v_u_224, (copy) p_u_222
		v_u_236.lastSub = "locked"
		local v504 = v_u_236.view or {}
		local v505 = v504.locked
		local v506
		if type(v505) == "table" then
			v506 = v504.locked
		else
			v506 = v_u_230 and v_u_230.LOCKED or {
				["line"] = "",
				["hint"] = ""
			}
		end
		local v507 = v_u_223.list({
			["parent"] = nil,
			["name"] = "Locked",
			["gap"] = 8,
			["padding"] = nil,
			["parent"] = p503,
			["padding"] = {
				2,
				8,
				2,
				8
			}
		})
		v_u_223.label({
			["parent"] = nil,
			["name"] = "Line",
			["text"] = "The Gunsmith is locked.",
			["style"] = "h3",
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v507
		})
		local v508 = v_u_223.label
		local v509 = {
			["parent"] = nil,
			["name"] = "What",
			["text"] = nil,
			["style"] = "body",
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v507
		}
		local v510 = v506.what or (v504.stageLine or "She does not deal with strangers yet.")
		v509.text = tostring(v510)
		v508(v509)
		if v_u_228 then
			local v511 = v_u_223.label
			local v512 = {
				["parent"] = nil,
				["name"] = "Story",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["parent"] = v507
			}
			local v513 = v506.line or ""
			v512.text = tostring(v513)
			v512.color = v_u_225.text2
			v511(v512)
		end
		v_u_226.section(v507, "How she opens up", 4)
		v_u_502(v507, 4)
		local v514 = v_u_223.label
		local v515 = {
			["parent"] = nil,
			["name"] = "Hint",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 10,
			["parent"] = v507
		}
		local v516 = v506.hint or ""
		v515.text = tostring(v516)
		v515.color = v_u_225.text2
		v514(v515)
		local v517 = {
			["parent"] = nil,
			["text"] = "Open Gunner\'s jobs",
			["kind"] = "primary",
			["width"] = 240,
			["height"] = 44,
			["onClick"] = nil,
			["parent"] = v_u_223.new("Frame", {
				["Name"] = "GoRow",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 11,
				["Size"] = UDim2.new(1, 0, 0, v_u_224.touch(44))
			}, v507),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) p_u_222
				p_u_222.goto("gunner", "tasks")
			end
		}
		v_u_223.button(v517).Name = "GoGunner"
	end
	function v_u_229.trustBanner(p518) -- name: trustBanner
		-- upvalues: (copy) v_u_229, (ref) v_u_2, (copy) v_u_488, (ref) v_u_234, (copy) v_u_227, (copy) v_u_223, (copy) v_u_225
		if v_u_229.stage() ~= 1 then
			return 0
		end
		local _, v519 = v_u_2.trustSteps(v_u_488, v_u_234)
		local v520 = v_u_227 and 30 or 40
		local v521 = v_u_223.new("Frame", {
			["Name"] = "TrustBanner",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_225.raised,
			["Size"] = UDim2.new(1, 0, 0, v520)
		}, p518)
		v_u_223.new("Frame", {
			["Name"] = "Tick",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_225.info,
			["Size"] = UDim2.new(0, 2, 1, 0)
		}, v521)
		v_u_223.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v521,
			["text"] = ("The bench is closed. Finish her three trust jobs to open it (%d of 3 done)."):format(v519),
			["color"] = v_u_225.text2,
			["position"] = UDim2.fromOffset(12, 0),
			["size"] = UDim2.new(1, -20, 1, 0)
		})
		return v520 + 8
	end
	function v_u_229.drawCraft(p522) -- name: drawCraft
		-- upvalues: (copy) v_u_236, (copy) v_u_226, (copy) v_u_223, (copy) p_u_222, (copy) v_u_228, (copy) v_u_227, (ref) v_u_2, (copy) v_u_224, (copy) v_u_225, (ref) v_u_3, (copy) v_u_229, (copy) v_u_255, (copy) v_u_251, (copy) v_u_274, (copy) v_u_276, (ref) v_u_1, (ref) v_u_230, (copy) v_u_282, (copy) v_u_400
		v_u_236.lastSub = "craft"
		table.clear(v_u_236.ui)
		local v523 = v_u_236.view
		if type(v523) == "table" then
			local v524 = v523.recipes
			if type(v524) == "table" then
				local v525 = v523.recipes
				local v526 = p_u_222.bodyWidth()
				local v527 = v_u_228 and 300 or 340
				if v526 < 820 then
					local v528 = v526 * 0.34
					local v529 = math.floor(v528)
					v527 = math.max(260, v529)
				end
				local v530 = v_u_227 and 0 or v527 + 14
				local v_u_531 = v_u_2.classCounts(v525)
				local v532 = v_u_224.touch(32)
				local v_u_533 = v_u_223.new("Frame", {
					["Name"] = "FilterBox",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, -v530, 0, v532 + 6)
				}, p522)
				local v534 = v_u_223.list({
					["parent"] = nil,
					["name"] = "Filters",
					["horizontal"] = true,
					["gap"] = 6,
					["size"] = nil,
					["parent"] = v_u_533,
					["size"] = UDim2.new(1, 0, 0, v532 + 6)
				})
				local v535 = v_u_223.label({
					["parent"] = nil,
					["name"] = "PadPrev",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 0,
					["track"] = false,
					["parent"] = v534,
					["text"] = v_u_223.device() ~= "Gamepad" and "" or v_u_223.hint("aim"),
					["color"] = v_u_225.text2,
					["size"] = UDim2.new(0, 0, 0, v532)
				})
				local v536 = v_u_223.label({
					["parent"] = nil,
					["name"] = "PadNext",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 100,
					["track"] = false,
					["parent"] = v534,
					["text"] = v_u_223.device() ~= "Gamepad" and "" or v_u_223.hint("fire"),
					["color"] = v_u_225.text2,
					["size"] = UDim2.new(0, 0, 0, v532)
				})
				local v537 = v535.Text ~= ""
				local v538 = v536.Text ~= ""
				v535.Visible = v537
				v536.Visible = v538
				if v_u_3.filter ~= "all" and (v_u_531[v_u_3.filter] or 0) == 0 then
					v_u_3.filter = "all"
				end
				v_u_236.ui.chips = {}
				for v539, v_u_540 in v_u_2.FILTERS do
					local v541 = v_u_531[v_u_540] or 0
					local v542 = v_u_3.filter == v_u_540
					local v_u_543 = v542 or v541 > 0
					local v544 = v_u_223.new
					local v545 = "TextButton"
					local v546 = {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["AutomaticSize"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Selectable"] = nil,
						["Name"] = "F_" .. v_u_540
					}
					local v547
					if v542 then
						v547 = v_u_225.accentDeep
					else
						v547 = v_u_225.raised
					end
					v546.BackgroundColor3 = v547
					v546.BackgroundTransparency = v542 and 0.05 or (v_u_543 and 0.3 or 0.6)
					v546.AutomaticSize = Enum.AutomaticSize.X
					v546.Size = UDim2.fromOffset(v_u_224.touch(24), v532)
					v546.LayoutOrder = v539
					v546.Selectable = v_u_543
					local v548 = v544(v545, v546, v534)
					v548.SelectionImageObject = v_u_223.selectionImage()
					local v549 = v_u_223.stroke
					local v550
					if v542 then
						v550 = v_u_225.accent
					else
						v550 = v_u_225.line
					end
					v549(v548, v550)
					v_u_223.pad(v548, {
						10,
						10,
						0,
						0
					})
					v_u_223.layout(v548, "h", 6)
					local v551 = v_u_223.label
					local v552 = {
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["autoX"] = true,
						["size"] = nil,
						["order"] = 1,
						["parent"] = v548,
						["text"] = v_u_2.CLASS_TEXT[v_u_540] or string.upper((string.sub(v_u_540, 1, 1))) .. string.sub(v_u_540, 2)
					}
					local v553
					if v542 then
						v553 = v_u_225.text
					elseif v_u_543 then
						v553 = v_u_225.text2
					else
						v553 = v_u_225.muted
					end
					v552.color = v553
					v552.size = UDim2.new(0, 0, 1, 0)
					v551(v552)
					local v554 = v_u_223.label
					local v555 = {
						["parent"] = nil,
						["name"] = "Count",
						["text"] = nil,
						["style"] = "monoS",
						["color"] = nil,
						["autoX"] = true,
						["size"] = nil,
						["order"] = 2,
						["track"] = false,
						["parent"] = v548,
						["text"] = tostring(v541)
					}
					local v556
					if v542 then
						v556 = v_u_225.accent
					else
						v556 = v_u_225.muted
					end
					v555.color = v556
					v555.size = UDim2.new(0, 0, 1, 0)
					v554(v555)
					v548:SetAttribute("Count", v541)
					v548:SetAttribute("On", v542)
					v548.Activated:Connect(function()
						-- upvalues: (copy) v_u_543, (ref) v_u_223, (ref) v_u_224, (ref) v_u_229, (copy) v_u_540
						if v_u_543 then
							v_u_229.setFilter(v_u_540)
						else
							v_u_223.sound(v_u_224.sounds.error)
						end
					end)
					v_u_236.ui.chips[v_u_540] = v548
				end
				v534:SetAttribute("Counts", (function()
					-- upvalues: (ref) v_u_2, (copy) v_u_531
					local v557 = {}
					for _, v558 in v_u_2.FILTERS do
						local v559 = v_u_531[v558] or 0
						table.insert(v557, ("%s=%d"):format(v558, v559))
					end
					return table.concat(v557, " ")
				end)())
				local v560 = v_u_2.filterRows(v525, v_u_3.filter)
				local v561 = v_u_255(v_u_236.sel)
				local v562 = false
				for _, v563 in v560 do
					if not v561 or v563.id ~= v561.id then
						continue
					end
					v562 = true
				end
				if not (v561 and v562) then
					local v564 = nil
					for _, v565 in v560 do
						if not v565.can or v564 then
							continue
						end
						v564 = v565
					end
					local v566 = v564 or v560[1]
					if v566 and not (v561 and v562) then
						v_u_236.sel = v566.id
						v_u_236.custom = false
						local v567 = v_u_255(v_u_236.sel)
						local v568 = v_u_236
						local v569 = v_u_2.payStateFrom
						if v567 then
							v567 = v567.pay
						end
						local v570 = v_u_236.view
						local v571
						if v570 then
							local v572 = v570.goldInStash
							v571 = type(v572) ~= "table" and {} or v570.goldInStash
						else
							v571 = {}
						end
						v568.payN = v569(v567, v571)
						v_u_236.custom = false
					end
				end
				local v573 = v_u_227 and 52 or (v_u_228 and 72 or 84)
				local v574 = v_u_227 and 32 or 18
				local v575 = v573 + 10 + 4 + v574 + 4 + 22 + 10
				local v576 = v532 + 10
				local v_u_577 = p_u_222.gridList(p522, "Recipes", UDim2.fromOffset(0, v576), UDim2.new(1, -v530, 1, -v576), v_u_227 and 124 or (v_u_228 and 138 or 150), v575, 8, v526 - v530)
				v_u_236.ui.grid = v_u_577
				v_u_236.ui.tiles = {}
				local v578 = v_u_223.new
				local v579 = "Frame"
				local v580 = {
					["Name"] = "Detail",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = nil
				}
				local v581
				if v_u_227 then
					v581 = Vector2.zero
				else
					v581 = Vector2.new(1, 0)
				end
				v580.AnchorPoint = v581
				local v582
				if v_u_227 then
					v582 = UDim2.new()
				else
					v582 = UDim2.fromScale(1, 0)
				end
				v580.Position = v582
				local v583
				if v_u_227 then
					v583 = UDim2.fromScale(1, 1)
				else
					v583 = UDim2.new(0, v527, 1, 0)
				end
				v580.Size = v583
				v580.Visible = not v_u_227 or v_u_236.page
				local v_u_584 = v578(v579, v580, p522)
				local v585 = v_u_224.touch(40)
				local v_u_586
				if v_u_227 then
					v_u_223.iconButton({
						["parent"] = nil,
						["name"] = "Back",
						["icon"] = "chevronLeft",
						["kind"] = "secondary",
						["size"] = nil,
						["position"] = nil,
						["onClick"] = nil,
						["tooltip"] = "Back to the list",
						["parent"] = v_u_584,
						["size"] = v585,
						["position"] = UDim2.fromOffset(0, 0),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_236, (copy) v_u_584, (copy) v_u_577, (copy) v_u_533
							v_u_236.page = false
							v_u_584.Visible = false
							v_u_577.Visible = true
							v_u_533.Visible = true
						end
					})
					local v587
					v587, v_u_586 = v_u_223.panel({
						["parent"] = nil,
						["name"] = "Panel",
						["raised"] = true,
						["position"] = nil,
						["size"] = nil,
						["padding"] = 10,
						["parent"] = v_u_584,
						["position"] = UDim2.fromOffset(v585 + 8, 0),
						["size"] = UDim2.new(1, -(v585 + 8), 1, 0)
					})
					v_u_577.Visible = not v_u_236.page
					v_u_533.Visible = not v_u_236.page
				else
					local v588
					v588, v_u_586 = v_u_223.panel({
						["parent"] = nil,
						["name"] = "Panel",
						["raised"] = true,
						["size"] = nil,
						["padding"] = 14,
						["parent"] = v_u_584,
						["size"] = UDim2.fromScale(1, 1)
					})
				end
				v_u_236.ui.detail = v_u_584
				v_u_236.ui.dpanel = v_u_586
				local v_u_589 = {}
				local function v_u_590() end
				local function v591() -- name: openPage
					-- upvalues: (ref) v_u_227, (ref) v_u_236, (copy) v_u_584, (copy) v_u_577, (copy) v_u_533
					if v_u_227 then
						v_u_236.page = true
						v_u_584.Visible = true
						v_u_577.Visible = false
						v_u_533.Visible = false
					end
				end
				v_u_236.ui.openPage = v591
				function v_u_229.select(p592) -- name: select
					-- upvalues: (ref) v_u_236, (ref) v_u_255, (ref) v_u_2, (copy) v_u_589, (ref) v_u_590
					if v_u_236.sel ~= p592 then
						v_u_236.sel = p592
						v_u_236.custom = false
						local v593 = v_u_255(v_u_236.sel)
						local v594 = v_u_236
						local v595 = v_u_2.payStateFrom
						if v593 then
							v593 = v593.pay
						end
						local v596 = v_u_236.view
						local v597
						if v596 then
							local v598 = v596.goldInStash
							v597 = type(v598) ~= "table" and {} or v596.goldInStash
						else
							v597 = {}
						end
						v594.payN = v595(v593, v597)
						v_u_236.custom = false
						if v_u_236.flash and v_u_236.flash.weapon ~= p592 then
							v_u_236.flash = nil
						end
						for _, v599 in v_u_589 do
							v599()
						end
						v_u_590((v_u_255(p592)))
					end
				end
				local v600 = v_u_236.flash and (os.clock() - v_u_236.flash.at < 12 and v_u_236.flash) or nil
				for v601, v_u_602 in v560 do
					local v_u_603 = v_u_602.id
					local v604 = v_u_251(v_u_603)
					local v_u_605 = v_u_223.new("TextButton", {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["LayoutOrder"] = nil,
						["Selectable"] = true,
						["ClipsDescendants"] = true,
						["Name"] = v_u_603,
						["BackgroundColor3"] = v_u_225.raised,
						["LayoutOrder"] = v601
					}, v_u_577)
					v_u_605.SelectionImageObject = v_u_223.selectionImage()
					local v_u_606 = v_u_223.stroke(v_u_605, v_u_225.line)
					local v607 = v_u_226.itemCell(v_u_605, v_u_603, {
						["size"] = nil,
						["wish"] = false,
						["dim"] = false,
						["size"] = v573
					})
					v607.AnchorPoint = Vector2.new(0.5, 0)
					v607.Position = UDim2.new(0.5, 0, 0, 10)
					local v608 = v_u_223.label
					local v609 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["textSize"] = 14,
						["color"] = nil,
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["wrap"] = nil,
						["fitWrap"] = false,
						["valign"] = nil,
						["parent"] = v_u_605,
						["text"] = v_u_602.name
					}
					local v610
					if v_u_602.locked then
						v610 = v_u_225.text2
					else
						v610 = v_u_225.text
					end
					v609.color = v610
					v609.position = UDim2.fromOffset(8, v573 + 10 + 4)
					v609.size = UDim2.new(1, -16, 0, v574)
					v609.wrap = v_u_227
					v609.valign = v_u_227 and "top" or nil
					local v611 = v608(v609)
					if v_u_227 then
						v611.TextTruncate = Enum.TextTruncate.AtEnd
					end
					local v612 = v_u_223.new("Frame", {
						["Name"] = "Foot",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(0, 8, 1, -8),
						["Size"] = UDim2.new(1, -16, 0, 22)
					}, v_u_605)
					local v613 = v_u_274
					local v614 = string.upper
					local v615 = v_u_602.class
					v613(v612, v614(v_u_2.CLASS_TEXT[v615] or string.upper((string.sub(v615, 1, 1))) .. string.sub(v615, 2)), v_u_225.text2, false, {
						["name"] = "Class",
						["anchor"] = nil,
						["position"] = nil,
						["anchor"] = Vector2.new(0, 0.5),
						["position"] = UDim2.new(0, 0, 0.5, 0)
					})
					local v616, v617 = v_u_2.lineStats(v_u_602)
					if v_u_602.locked then
						local v618 = v_u_274
						local v619 = v_u_602.locked
						v618(v612, tostring(v619), v_u_225.danger, false, {
							["name"] = "Lock",
							["icon"] = "lock",
							["anchor"] = nil,
							["position"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					elseif v_u_602.can then
						v_u_274(v612, "READY", v_u_225.success, true, {
							["name"] = "Ready",
							["anchor"] = nil,
							["position"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					else
						v_u_274(v612, ("%d / %d"):format(v617, v616), v_u_225.text2, false, {
							["name"] = "Have",
							["anchor"] = nil,
							["position"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					end
					if v604 > 0 then
						v_u_274(v_u_605, ("IN STASH %d"):format(v604), v_u_225.info, true, {
							["name"] = "InStash",
							["anchor"] = nil,
							["position"] = nil,
							["h"] = 16,
							["zindex"] = 6,
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.new(1, -6, 0, 6)
						})
					end
					v_u_605:SetAttribute("Owned", v604)
					v_u_605:SetAttribute("Can", v_u_602.can == true)
					local v_u_620 = false
					v_u_589[v_u_603] = function() -- name: paint
						-- upvalues: (ref) v_u_236, (copy) v_u_603, (copy) v_u_605, (ref) v_u_225, (ref) v_u_620, (copy) v_u_602, (copy) v_u_606
						local v621 = v_u_236.sel == v_u_603
						local v622 = v_u_605
						local v623
						if v621 then
							v623 = v_u_225.accentDeep
						elseif v_u_620 then
							v623 = v_u_225.raised2
						else
							v623 = v_u_225.raised
						end
						v622.BackgroundColor3 = v623
						v_u_605.BackgroundTransparency = v621 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
						local v624 = v_u_606
						local v625
						if v621 then
							v625 = v_u_225.accent
						elseif v_u_620 then
							v625 = v_u_225.lineStrong
						else
							v625 = v_u_225.line
						end
						v624.Color = v625
					end
					local v626 = v_u_236.sel == v_u_603
					local v627
					if v626 then
						v627 = v_u_225.accentDeep
					elseif v_u_620 then
						v627 = v_u_225.raised2
					else
						v627 = v_u_225.raised
					end
					v_u_605.BackgroundColor3 = v627
					v_u_605.BackgroundTransparency = v626 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
					local v628
					if v626 then
						v628 = v_u_225.accent
					elseif v_u_620 then
						v628 = v_u_225.lineStrong
					else
						v628 = v_u_225.line
					end
					v_u_606.Color = v628
					if v600 and v600.weapon == v_u_603 then
						v600.tileT0 = v600.tileT0 or os.clock()
						if os.clock() < v600.tileT0 + 1.5 then
							local v_u_629 = v_u_276(v_u_605)
							local v_u_630 = v600.tileT0 + 1.5
							v_u_605:SetAttribute("Flash", true)
							task.spawn(function()
								-- upvalues: (copy) v_u_630, (copy) v_u_629, (ref) v_u_223, (copy) v_u_605
								while os.clock() < v_u_630 do
									if not v_u_629.Parent then
										return
									end
									v_u_223.tween(v_u_629, {
										["BackgroundTransparency"] = 0.5
									}, 0.14)
									task.wait(0.18)
									if not v_u_629.Parent then
										return
									end
									v_u_223.tween(v_u_629, {
										["BackgroundTransparency"] = 1
									}, 0.26)
									task.wait(0.3)
								end
								if v_u_605.Parent then
									v_u_605:SetAttribute("Flash", false)
								end
							end)
						end
					end
					v_u_605.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_620, (ref) v_u_223, (ref) v_u_224, (ref) v_u_236, (copy) v_u_603, (copy) v_u_605, (ref) v_u_225, (copy) v_u_602, (copy) v_u_606
						v_u_620 = true
						v_u_223.sound(v_u_224.sounds.hover)
						local v631 = v_u_236.sel == v_u_603
						local v632 = v_u_605
						local v633
						if v631 then
							v633 = v_u_225.accentDeep
						elseif v_u_620 then
							v633 = v_u_225.raised2
						else
							v633 = v_u_225.raised
						end
						v632.BackgroundColor3 = v633
						v_u_605.BackgroundTransparency = v631 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
						local v634 = v_u_606
						local v635
						if v631 then
							v635 = v_u_225.accent
						elseif v_u_620 then
							v635 = v_u_225.lineStrong
						else
							v635 = v_u_225.line
						end
						v634.Color = v635
					end)
					v_u_605.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_620, (ref) v_u_236, (copy) v_u_603, (copy) v_u_605, (ref) v_u_225, (copy) v_u_602, (copy) v_u_606
						v_u_620 = false
						local v636 = v_u_236.sel == v_u_603
						local v637 = v_u_605
						local v638
						if v636 then
							v638 = v_u_225.accentDeep
						elseif v_u_620 then
							v638 = v_u_225.raised2
						else
							v638 = v_u_225.raised
						end
						v637.BackgroundColor3 = v638
						v_u_605.BackgroundTransparency = v636 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
						local v639 = v_u_606
						local v640
						if v636 then
							v640 = v_u_225.accent
						elseif v_u_620 then
							v640 = v_u_225.lineStrong
						else
							v640 = v_u_225.line
						end
						v639.Color = v640
					end)
					v_u_605.SelectionGained:Connect(function()
						-- upvalues: (ref) v_u_620, (ref) v_u_229, (copy) v_u_603, (ref) v_u_236, (copy) v_u_605, (ref) v_u_225, (copy) v_u_602, (copy) v_u_606
						v_u_620 = true
						v_u_229.select(v_u_603)
						local v641 = v_u_236.sel == v_u_603
						local v642 = v_u_605
						local v643
						if v641 then
							v643 = v_u_225.accentDeep
						elseif v_u_620 then
							v643 = v_u_225.raised2
						else
							v643 = v_u_225.raised
						end
						v642.BackgroundColor3 = v643
						v_u_605.BackgroundTransparency = v641 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
						local v644 = v_u_606
						local v645
						if v641 then
							v645 = v_u_225.accent
						elseif v_u_620 then
							v645 = v_u_225.lineStrong
						else
							v645 = v_u_225.line
						end
						v644.Color = v645
					end)
					v_u_605.SelectionLost:Connect(function()
						-- upvalues: (ref) v_u_620, (ref) v_u_236, (copy) v_u_603, (copy) v_u_605, (ref) v_u_225, (copy) v_u_602, (copy) v_u_606
						v_u_620 = false
						local v646 = v_u_236.sel == v_u_603
						local v647 = v_u_605
						local v648
						if v646 then
							v648 = v_u_225.accentDeep
						elseif v_u_620 then
							v648 = v_u_225.raised2
						else
							v648 = v_u_225.raised
						end
						v647.BackgroundColor3 = v648
						v_u_605.BackgroundTransparency = v646 and 0.05 or (v_u_602.locked and 0.5 or 0.2)
						local v649 = v_u_606
						local v650
						if v646 then
							v650 = v_u_225.accent
						elseif v_u_620 then
							v650 = v_u_225.lineStrong
						else
							v650 = v_u_225.line
						end
						v649.Color = v650
					end)
					v_u_605.Activated:Connect(function()
						-- upvalues: (ref) v_u_223, (ref) v_u_224, (ref) v_u_229, (copy) v_u_603, (ref) v_u_227, (ref) v_u_236, (copy) v_u_584, (copy) v_u_577, (copy) v_u_533, (ref) v_u_1
						v_u_223.sound(v_u_224.sounds.click)
						v_u_229.select(v_u_603)
						if v_u_227 then
							v_u_236.page = true
							v_u_584.Visible = true
							v_u_577.Visible = false
							v_u_533.Visible = false
						end
						if v_u_223.device() == "Gamepad" and (v_u_236.ui.craftBtn and v_u_236.ui.craftBtn.Parent) then
							v_u_1.SelectedObject = v_u_236.ui.craftBtn
						end
					end)
					v_u_236.ui.tiles[v_u_603] = v_u_605
				end
				if #v560 == 0 then
					v_u_226.empty(v_u_577, "No recipes in this class.")
				end
				v_u_577:SetAttribute("Shown", #v560)
				v_u_590 = function(p_u_651)
					-- upvalues: (ref) v_u_226, (ref) v_u_586, (ref) v_u_236, (ref) v_u_227, (ref) v_u_228, (ref) v_u_224, (ref) v_u_223, (ref) v_u_274, (ref) v_u_2, (ref) v_u_225, (ref) v_u_230, (ref) v_u_276, (ref) v_u_282, (ref) v_u_229, (ref) p_u_222, (ref) v_u_400, (ref) v_u_255, (ref) v_u_590
					v_u_226.clear(v_u_586)
					local v652 = v_u_236.ui
					local v653 = v_u_236.ui
					local v654 = v_u_236.ui
					v652.craftBtn = nil
					v653.craftApi = nil
					v654.reasonL = nil
					if p_u_651 then
						v_u_226.itemDef(p_u_651.id)
						local v655 = v_u_227 and 56 or (v_u_228 and 72 or 84)
						local v656
						if v_u_227 then
							v656 = v_u_224.touch(44) + 6
						else
							v656 = v_u_224.touch(44) + 8 + 34
						end
						local v657 = v_u_586
						local v658
						if v_u_227 then
							local v659 = v_u_224.safeRefSize().X - 576
							local v660 = math.clamp(v659, 250, 320)
							v657 = v_u_223.new("Frame", {
								["Name"] = "NeedsCol",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["Size"] = UDim2.new(1, -(v660 + 12), 1, 0)
							}, v_u_586)
							v658 = v_u_223.new("Frame", {
								["Name"] = "PayCol",
								["BackgroundTransparency"] = 1,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["AnchorPoint"] = Vector2.new(1, 0),
								["Position"] = UDim2.fromScale(1, 0),
								["Size"] = UDim2.new(0, v660, 1, 0)
							}, v_u_586)
						else
							v658 = nil
						end
						local v661 = v_u_223.new("Frame", {
							["Name"] = "Top",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, 0, 0, v655)
						}, v657)
						v_u_226.itemCell(v661, p_u_651.id, {
							["size"] = nil,
							["wish"] = false,
							["size"] = v655
						})
						v_u_223.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = nil,
							["style"] = "h3",
							["wrap"] = true,
							["fit"] = true,
							["position"] = nil,
							["size"] = nil,
							["valign"] = "top",
							["parent"] = v661,
							["text"] = p_u_651.name,
							["position"] = UDim2.fromOffset(v655 + 12, 0),
							["size"] = UDim2.new(1, -v655 - 12, 0, v_u_227 and 32 or 44)
						})
						local v662 = v_u_223.new("Frame", {
							["Name"] = "Chips",
							["BackgroundTransparency"] = 1,
							["Position"] = nil,
							["Size"] = nil,
							["Position"] = UDim2.fromOffset(v655 + 12, v_u_227 and 34 or 48),
							["Size"] = UDim2.new(1, -v655 - 12, 0, 20)
						}, v661)
						v_u_223.layout(v662, "h", 6)
						local v663 = v_u_274
						local v664 = string.upper
						local v665 = p_u_651.class
						v663(v662, v664(v_u_2.CLASS_TEXT[v665] or string.upper((string.sub(v665, 1, 1))) .. string.sub(v665, 2)), v_u_225.text2, false, {
							["name"] = "Class",
							["order"] = 1
						})
						local v666 = v_u_274
						local v667 = p_u_651.level
						local v668 = "LV " .. tostring(v667)
						local v669
						if p_u_651.locked then
							v669 = v_u_225.danger
						else
							v669 = v_u_225.text2
						end
						v666(v662, v668, v669, false, {
							["name"] = "Level",
							["order"] = 2,
							["icon"] = nil,
							["icon"] = p_u_651.locked and "lock" or nil
						})
						local v670 = v_u_274
						local v671 = string.upper
						local v672 = v_u_224.rarityName
						local v673 = p_u_651.rarity
						local v674 = tonumber(v673) or 1
						v670(v662, v671(v672[math.clamp(v674, 1, 6)]), v_u_224.rarityColor(p_u_651.rarity), false, {
							["name"] = "Rarity",
							["order"] = 3
						})
						local v_u_675, v676
						if v_u_227 then
							v_u_675 = v_u_223.list({
								["parent"] = nil,
								["name"] = "Needs",
								["position"] = nil,
								["size"] = nil,
								["gap"] = 3,
								["parent"] = v657,
								["position"] = UDim2.fromOffset(0, v655 + 8),
								["size"] = UDim2.new(1, 0, 1, -(v655 + 8))
							})
							v676 = v_u_223.list({
								["parent"] = nil,
								["name"] = "Pay",
								["position"] = nil,
								["size"] = nil,
								["gap"] = 4,
								["parent"] = v658,
								["position"] = UDim2.fromOffset(0, 0),
								["size"] = UDim2.new(1, 0, 1, -v656)
							})
						else
							v_u_675 = v_u_223.list({
								["parent"] = nil,
								["name"] = "Scroll",
								["position"] = nil,
								["size"] = nil,
								["gap"] = 3,
								["parent"] = v657,
								["position"] = UDim2.fromOffset(0, v655 + 8),
								["size"] = UDim2.new(1, 0, 1, -(v655 + 8) - v656)
							})
							v676 = v_u_675
						end
						local v677 = 1
						local v678
						if v_u_230 and v_u_230.recipeChip then
							v678 = v_u_230.recipeChip(p_u_651.id)
						else
							v678 = nil
						end
						if v678 then
							v_u_223.label({
								["parent"] = nil,
								["name"] = "SourceChip",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["order"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v_u_675,
								["text"] = v678,
								["color"] = v_u_225.accent,
								["order"] = v677,
								["size"] = UDim2.new(1, 0, 0, 18)
							})
							v677 = v677 + 1
						end
						local v679 = v_u_236.flash
						if v679 and (v679.weapon == p_u_651.id and os.clock() - v679.at < 600) then
							local v680 = v_u_223.new("Frame", {
								["Name"] = "Built",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.82,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["BackgroundColor3"] = v_u_225.success,
								["Size"] = UDim2.new(1, 0, 0, v_u_227 and 44 or 52),
								["LayoutOrder"] = v677
							}, v_u_675)
							v_u_223.stroke(v680, v_u_225.success, 1, 0.3)
							local v681 = {
								["size"] = nil,
								["wish"] = false,
								["size"] = v_u_227 and 36 or 44
							}
							local v_u_682 = v_u_226.itemCell(v680, p_u_651.id, v681)
							v_u_682.Name = "StashTile"
							v_u_682.AnchorPoint = Vector2.new(0, 0.5)
							v_u_682.Position = UDim2.new(0, 6, 0.5, 0)
							v_u_223.label({
								["parent"] = nil,
								["name"] = "Text",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["position"] = nil,
								["size"] = nil,
								["parent"] = v680,
								["text"] = ("Built %s. It is in your stash."):format(v679.name or p_u_651.name),
								["color"] = v_u_225.text,
								["position"] = UDim2.fromOffset((v_u_227 and 36 or 44) + 14, 0),
								["size"] = UDim2.new(1, -((v_u_227 and 36 or 44) + 20), 1, 0)
							})
							v679.bannerT0 = v679.bannerT0 or os.clock()
							if os.clock() < v679.bannerT0 + 1.5 then
								local v_u_683 = v_u_276(v_u_682)
								local v_u_684 = v679.bannerT0 + 1.5
								v_u_682:SetAttribute("Flash", true)
								task.spawn(function()
									-- upvalues: (copy) v_u_684, (copy) v_u_683, (ref) v_u_223, (copy) v_u_682
									while os.clock() < v_u_684 do
										if not v_u_683.Parent then
											return
										end
										v_u_223.tween(v_u_683, {
											["BackgroundTransparency"] = 0.5
										}, 0.14)
										task.wait(0.18)
										if not v_u_683.Parent then
											return
										end
										v_u_223.tween(v_u_683, {
											["BackgroundTransparency"] = 1
										}, 0.26)
										task.wait(0.3)
									end
									if v_u_682.Parent then
										v_u_682:SetAttribute("Flash", false)
									end
								end)
							end
							v677 = v677 + 1
						end
						local function v713(p685, p686, p687) -- name: needRows
							-- upvalues: (ref) v_u_226, (ref) v_u_675, (ref) v_u_223, (ref) v_u_282, (ref) v_u_225, (ref) v_u_230
							if not p686 or #p686 == 0 then
								return p687
							end
							v_u_226.section(v_u_675, p685, p687, nil)
							local v688 = p687 + 1
							for _, v_u_689 in p686 do
								local v690 = v_u_689.need
								local v691 = tonumber(v690) or 1
								local v692 = v_u_689.have
								local v693 = tonumber(v692) or 0
								local v694 = v691 <= v693
								local v695 = v_u_223.new
								local v696 = {
									["Name"] = nil,
									["BackgroundTransparency"] = 1,
									["Size"] = nil,
									["LayoutOrder"] = nil
								}
								local v697 = v_u_689.item
								v696.Name = "Need_" .. tostring(v697)
								v696.Size = UDim2.new(1, 0, 0, 24)
								v696.LayoutOrder = v688
								local v698 = v695("Frame", v696, v_u_675)
								v_u_282(v698, v694, 18, UDim2.fromOffset(0, 3))
								local v699 = v_u_223.label
								local v700 = {
									["parent"] = nil,
									["name"] = "Name",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["parent"] = v698
								}
								local v701 = v_u_689.name
								if not v701 then
									local v702 = v_u_689.item
									v701 = v_u_226.itemName(v702)
								end
								v700.text = v701
								local v703
								if v694 then
									v703 = v_u_225.text
								else
									v703 = v_u_225.text2
								end
								v700.color = v703
								v700.position = UDim2.fromOffset(26, 0)
								v700.size = UDim2.new(1, -76, 1, 0)
								v699(v700)
								local v704 = v_u_223.label
								local v705 = {
									["parent"] = nil,
									["name"] = "Count",
									["text"] = nil,
									["style"] = "monoS",
									["color"] = nil,
									["align"] = "right",
									["position"] = nil,
									["size"] = nil,
									["track"] = false,
									["parent"] = v698,
									["text"] = ("%d / %d"):format(math.min(v693, 999), v691)
								}
								local v706
								if v694 then
									v706 = v_u_225.success
								else
									v706 = v_u_225.danger
								end
								v705.color = v706
								v705.position = UDim2.new(1, -48, 0, 0)
								v705.size = UDim2.fromOffset(48, 24)
								v704(v705)
								v698:SetAttribute("Ok", v694)
								v_u_223.tooltip(v698, function()
									-- upvalues: (ref) v_u_226, (copy) v_u_689, (ref) v_u_230
									local v707 = v_u_226.itemDef(v_u_689.item)
									local v708
									if v_u_230 and v_u_230.whereValue then
										v708 = {
											{
												["label"] = "Where",
												["value"] = nil,
												["value"] = v_u_230.whereValue(v_u_689.item)
											}
										}
										local v709
										if v_u_230.soldBy then
											v709 = v_u_230.soldBy(v_u_689.item)
										else
											v709 = nil
										end
										if v709 then
											table.insert(v708, {
												["label"] = "Sold by",
												["value"] = nil,
												["wide"] = true,
												["value"] = v709
											})
										end
									else
										v708 = nil
									end
									local v710 = {}
									local v711 = v_u_689.name
									if not v711 then
										local v712 = v_u_689.item
										v711 = v_u_226.itemName(v712)
									end
									v710.title = v711
									v710.body = v707 and v707.desc or nil
									v710.lines = v708
									return v710
								end)
								v688 = v688 + 1
							end
							return v688
						end
						local v714 = v713("Parts", p_u_651.parts, v677)
						local v715 = v713("Hardware", p_u_651.general, v714)
						if not v_u_227 then
							v658 = v_u_586
						end
						local v716 = v_u_223.new("Frame", {
							["Name"] = "Foot",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(0, 1),
							["Position"] = UDim2.fromScale(0, 1),
							["Size"] = UDim2.new(1, 0, 0, v656)
						}, v658)
						local v717 = v_u_223.label
						local v718 = {
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["size"] = nil,
							["valign"] = nil,
							["parent"] = v716,
							["color"] = v_u_225.text2
						}
						local v719
						if v_u_227 then
							v719 = UDim2.new(0.5, -6, 1, 0)
						else
							v719 = UDim2.new(1, 0, 0, 34)
						end
						v718.size = v719
						v718.valign = v_u_227 and "center" or "bottom"
						local v_u_720 = v717(v718)
						local v721 = v_u_223.button
						local v722 = {
							["parent"] = nil,
							["name"] = "Craft",
							["text"] = "Craft",
							["kind"] = "primary",
							["size"] = nil,
							["anchor"] = nil,
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v716
						}
						local v723
						if v_u_227 then
							v723 = UDim2.new(0.5, 0, 0, v_u_224.touch(44))
						else
							v723 = UDim2.new(1, 0, 0, v_u_224.touch(44))
						end
						v722.size = v723
						local v724
						if v_u_227 then
							v724 = Vector2.new(1, 1)
						else
							v724 = nil
						end
						v722.anchor = v724
						local v725
						if v_u_227 then
							v725 = UDim2.fromScale(1, 1)
						else
							v725 = UDim2.new(0, 0, 1, -v_u_224.touch(44))
						end
						v722.position = v725
						function v722.onClick() -- name: onClick
							-- upvalues: (ref) v_u_229
							v_u_229.pressCraft()
						end
						local v_u_726, v_u_727 = v721(v722)
						local v728 = v_u_236.ui
						local v729 = v_u_236.ui
						local v730 = v_u_236.ui
						v728.craftBtn = v_u_726
						v729.craftApi = v_u_727
						v730.reasonL = v_u_720
						local function v742() -- name: paintFoot
							-- upvalues: (ref) v_u_236, (ref) v_u_2, (copy) p_u_651, (copy) v_u_727, (copy) v_u_720, (ref) v_u_225, (copy) v_u_726, (ref) p_u_222
							local v731 = v_u_236.ui.pay
							local v732 = v_u_2.craftState
							local v733 = p_u_651
							local v734 = v731 == nil and true or v731.ok == true
							if v731 then
								v731 = v731.why
							end
							local v735, v736 = v732(v733, v734, v731, v_u_236.busy)
							v_u_727.setEnabled(v735)
							v_u_727.setText(v_u_236.busy and "Working..." or "Craft")
							if v735 then
								v_u_720.Text = ("%s with PINS"):format(v_u_2.repText(p_u_651.rep))
								v_u_720.TextColor3 = v_u_225.success
							else
								v_u_720.Text = tostring(v736 or "")
								local v737 = v_u_720
								local v738
								if v_u_236.busy then
									v738 = v_u_225.text2
								else
									v738 = v_u_225.danger
								end
								v737.TextColor3 = v738
							end
							v_u_726:SetAttribute("Can", v735)
							local v_u_739 = ("%s can=%s %s"):format(p_u_651.id, tostring(v735), (tostring(v736 or "")))
							local v_u_740 = "GsCraft"
							local function v741()
								-- upvalues: (ref) p_u_222, (copy) v_u_740, (copy) v_u_739
								p_u_222.page:SetAttribute(v_u_740, v_u_739)
							end
							pcall(v741)
						end
						v_u_236.ui.paintFoot = v742
						local v749 = v_u_400(v676, v715, p_u_651.fee.points, v_u_236, v742, function()
							-- upvalues: (ref) v_u_236, (ref) v_u_255, (ref) v_u_2, (ref) v_u_590, (copy) p_u_651
							v_u_236.custom = false
							local v743 = v_u_255(v_u_236.sel)
							local v744 = v_u_236
							local v745 = v_u_2.payStateFrom
							if v743 then
								v743 = v743.pay
							end
							local v746 = v_u_236.view
							local v747
							if v746 then
								local v748 = v746.goldInStash
								v747 = type(v748) ~= "table" and {} or v746.goldInStash
							else
								v747 = {}
							end
							v744.payN = v745(v743, v747)
							v_u_236.custom = false
							v_u_590(p_u_651)
						end)
						v_u_236.ui.pay = v749
						v742()
						v749.repaint()
					else
						v_u_226.empty(v_u_586, "Pick a gun on the left.")
					end
				end
				v_u_590((v_u_255(v_u_236.sel)))
				function v_u_236.ui.redrawDetail()
					-- upvalues: (ref) v_u_590, (ref) v_u_255, (ref) v_u_236
					v_u_590((v_u_255(v_u_236.sel)))
				end
				if v_u_227 and (v_u_236.page and not v_u_255(v_u_236.sel)) then
					v_u_236.page = false
					v_u_584.Visible = false
					v_u_577.Visible = true
					v_u_533.Visible = true
				end
				local v750 = v_u_229.stage()
				local v751 = v_u_236.sel
				local v_u_752 = ("stage=%d sub=craft sel=%s filter=%s shown=%d"):format(v750, tostring(v751), v_u_3.filter, #v560)
				local v_u_753 = "GsState"
				local function v754()
					-- upvalues: (ref) p_u_222, (copy) v_u_753, (copy) v_u_752
					p_u_222.page:SetAttribute(v_u_753, v_u_752)
				end
				pcall(v754)
				return
			end
		end
		v_u_226.empty(v_u_223.list({
			["parent"] = nil,
			["gap"] = 4,
			["parent"] = p522
		}), "Loading recipes...")
	end
	function v_u_229.setFilter(p_u_755) -- name: setFilter
		-- upvalues: (ref) v_u_3, (copy) v_u_223, (copy) v_u_224, (copy) v_u_236, (copy) p_u_222, (ref) v_u_1
		if v_u_3.filter ~= p_u_755 then
			v_u_3.filter = p_u_755
			v_u_223.sound(v_u_224.sounds.tab)
			v_u_236.page = false
			p_u_222.redraw(true)
			if v_u_223.device() == "Gamepad" then
				task.defer(function()
					-- upvalues: (ref) v_u_236, (copy) p_u_755, (ref) v_u_1
					local v756 = v_u_236.ui.chips
					if v756 then
						v756 = v_u_236.ui.chips[p_u_755]
					end
					if v756 and v756.Parent then
						v_u_1.SelectedObject = v756
					end
				end)
			end
		end
	end
	local function v_u_763(p757) -- name: cycleFilter
		-- upvalues: (copy) v_u_236, (ref) v_u_2, (ref) v_u_3, (copy) v_u_229
		local v758 = v_u_236.view
		if type(v758) == "table" then
			local v759 = v_u_2.classCounts(v758.recipes)
			local v760 = {}
			for _, v761 in v_u_2.FILTERS do
				if v761 ~= "all" and (v761 ~= v_u_3.filter and (v759[v761] or 0) <= 0) then
					continue
				end
				table.insert(v760, v761)
			end
			local v762 = v760[((table.find(v760, v_u_3.filter) or 1) - 1 + p757) % #v760 + 1]
			if v762 and v762 ~= v_u_3.filter then
				v_u_229.setFilter(v762)
			end
		end
	end
	v_u_229.cycleFilter = v_u_763
	local v_u_764 = nil
	local function v766()
		-- upvalues: (copy) p_u_221, (ref) v_u_764, (copy) v_u_236, (copy) p_u_222, (copy) v_u_223, (copy) v_u_763
		v_u_764 = p_u_221.cctx.lib.VirtualPad.InputBegan:Connect(function(p765)
			-- upvalues: (ref) v_u_236, (ref) p_u_222, (ref) v_u_223, (ref) v_u_763
			if (p765.KeyCode == Enum.KeyCode.ButtonL2 or p765.KeyCode == Enum.KeyCode.ButtonR2) and (v_u_236.lastSub == "craft" and (p_u_222.isActive() and v_u_223.modalCount() == 0)) then
				v_u_763(p765.KeyCode == Enum.KeyCode.ButtonR2 and 1 or -1)
			end
		end)
	end
	pcall(v766)
	function v_u_229.pressCraft() -- name: pressCraft
		-- upvalues: (copy) v_u_255, (copy) v_u_236, (ref) v_u_2, (copy) v_u_223, (copy) v_u_224, (copy) p_u_222, (copy) v_u_238, (copy) v_u_225, (copy) v_u_303, (copy) p_u_221
		local v767 = v_u_255(v_u_236.sel)
		if v767 and not v_u_236.busy then
			local v768 = v_u_236.ui.pay
			local v769 = v_u_2.craftState
			local v770 = v768 == nil and true or v768.ok == true
			local v771
			if v768 then
				v771 = v768.why
			else
				v771 = v768
			end
			local v772, v773 = v769(v767, v770, v771, v_u_236.busy)
			if v772 then
				local v774 = v_u_2.payList
				local v775 = v_u_236.payN
				local v776 = v_u_236.view
				local v777
				if v776 then
					local v778 = v776.goldInStash
					v777 = type(v778) ~= "table" and {} or v776.goldInStash
				else
					v777 = {}
				end
				local v_u_779, v780 = v774(v775, v777)
				local v781 = v_u_2.consumedGroups(v767, v780, v_u_238)
				local v782 = v768 and v768.info or {
					["points"] = 0,
					["lost"] = 0
				}
				local v783 = {}
				local v784 = {
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["text"] = ("You get: %s  \194\183  %s with PINS"):format(v767.name, v_u_2.repText(v767.rep)),
					["color"] = v_u_225.success
				}
				table.insert(v783, v784)
				local v785 = {
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["text"] = ("Fee: %s. You pay %s with %s."):format(v_u_2.goldPts(v767.fee.points), v_u_2.pts(v782.points), v_u_2.payWith(v780, v_u_238)),
					["color"] = v_u_225.text2
				}
				table.insert(v783, v785)
				if v782.lost > 0 then
					local v786 = {
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["text"] = ("%d gold %s lost: no change is given back."):format(v782.lost, v782.lost == 1 and "point is" or "points are"),
						["color"] = v_u_225.accent
					}
					table.insert(v783, v786)
				end
				local v_u_787 = v767.id
				v_u_236.confirmInfo = {
					["kind"] = "craft",
					["weapon"] = nil,
					["lines"] = nil,
					["lost"] = nil,
					["weapon"] = v_u_787,
					["lines"] = v_u_2.groupTotal(v781),
					["lost"] = v782.lost
				}
				v_u_303({
					["title"] = nil,
					["intro"] = "These items are used up:",
					["groups"] = nil,
					["outro"] = nil,
					["action"] = "Craft",
					["onYes"] = nil,
					["title"] = ("Build %s?"):format(v767.name),
					["groups"] = v781,
					["outro"] = v783,
					["onYes"] = function() -- name: onYes
						-- upvalues: (ref) v_u_236, (ref) p_u_221, (copy) v_u_787, (copy) v_u_779, (ref) p_u_222
						if not v_u_236.busy then
							v_u_236.busy = true
							v_u_236.busyAt = os.clock()
							local v_u_788 = v_u_236.busyAt
							if v_u_236.ui.paintFoot then
								local v789 = v_u_236.ui.paintFoot
								pcall(v789)
							end
							local v790 = {
								["op"] = "gsCraft",
								["recipe"] = nil,
								["pay"] = nil,
								["recipe"] = v_u_787,
								["pay"] = v_u_779
							}
							p_u_221.op(v790)
							task.delay(6, function()
								-- upvalues: (ref) v_u_236, (copy) v_u_788, (ref) p_u_222
								if v_u_236.busy and v_u_236.busyAt == v_u_788 then
									v_u_236.busy = false
									local v791 = p_u_222.redraw
									pcall(v791)
								end
							end)
						end
					end
				})
			else
				v_u_223.sound(v_u_224.sounds.error)
				local v_u_792 = ("%s refused %s"):format(v767.id, (tostring(v773)))
				local v_u_793 = "GsCraft"
				local function v794()
					-- upvalues: (ref) p_u_222, (copy) v_u_793, (copy) v_u_792
					p_u_222.page:SetAttribute(v_u_793, v_u_792)
				end
				pcall(v794)
			end
		else
			return
		end
	end
	local function v_u_814(p795, p796, p797, p_u_798, p_u_799, p_u_800) -- name: flowGrid
		-- upvalues: (copy) v_u_223, (copy) p_u_222
		local v_u_801 = v_u_223.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = p796,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p797
		}, p795)
		local v_u_802 = v_u_223.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(p_u_798, p_u_799),
			["CellPadding"] = UDim2.fromOffset(p_u_800, p_u_800),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v_u_801)
		local function v813() -- name: fit
			-- upvalues: (ref) p_u_222, (copy) v_u_801, (copy) p_u_800, (copy) p_u_798, (copy) v_u_802, (copy) p_u_799
			local v803 = p_u_222.designWidth(v_u_801)
			local v804 = (not v803 or v803 < 40) and 360 or v803
			local v805 = (v804 + p_u_800) / (p_u_798 + p_u_800)
			local v806 = math.floor(v805)
			local v807 = math.max(1, v806)
			local v808 = (v804 - (v807 - 1) * p_u_800) / v807
			local v809 = math.floor(v808)
			local v810 = v_u_802
			local v811 = UDim2.fromOffset
			local v812 = p_u_798 - 20
			v810.CellSize = v811(math.max(v812, v809), p_u_799)
			v_u_801:SetAttribute("Cols", v807)
		end
		v813()
		v_u_801:GetPropertyChangedSignal("AbsoluteSize"):Connect(v813)
		return v_u_801
	end
	local function v_u_830(p815, p816, p817, p818, p819, p820, p821, p_u_822) -- name: textTile
		-- upvalues: (copy) v_u_223, (copy) v_u_225, (copy) v_u_224
		local v823 = v_u_223.new
		local v824 = "TextButton"
		local v825 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true,
			["Name"] = p816
		}
		local v826
		if p820 then
			v826 = v_u_225.accentDeep
		else
			v826 = v_u_225.raised
		end
		v825.BackgroundColor3 = v826
		v825.BackgroundTransparency = p820 and 0.05 or 0.25
		v825.LayoutOrder = p817
		local v827 = v823(v824, v825, p815)
		v827.SelectionImageObject = v_u_223.selectionImage()
		local v828 = v_u_223.stroke
		local v829
		if p820 then
			v829 = v_u_225.accent
		else
			v829 = (p821 or v_u_225.line):Lerp(v_u_225.line, 0.5)
		end
		v828(v827, v829)
		v_u_223.label({
			["parent"] = nil,
			["name"] = "L1",
			["text"] = nil,
			["style"] = "bodyStrong",
			["textSize"] = 13,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v827,
			["text"] = p818,
			["color"] = v_u_225.text,
			["position"] = UDim2.fromOffset(8, 4),
			["size"] = UDim2.new(1, -(p820 and 34 or 16), 0, 20)
		})
		v_u_223.label({
			["parent"] = nil,
			["name"] = "L2",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["track"] = false,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v827,
			["text"] = p819,
			["color"] = v_u_225.text2,
			["position"] = UDim2.fromOffset(8, 26),
			["size"] = UDim2.new(1, -16, 0, 16)
		})
		if p820 then
			v_u_223.icon("check", {
				["parent"] = nil,
				["size"] = 14,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v827,
				["color"] = v_u_225.accent,
				["position"] = UDim2.new(1, -8, 0, 6),
				["anchor"] = Vector2.new(1, 0)
			})
		end
		v827.Activated:Connect(function()
			-- upvalues: (ref) v_u_223, (ref) v_u_224, (copy) p_u_822
			v_u_223.sound(v_u_224.sounds.click)
			p_u_822()
		end)
		return v827
	end
	local function v_u_842(p831) -- name: suggestSwap
		-- upvalues: (ref) v_u_230, (copy) v_u_236, (ref) v_u_2
		if v_u_230 and v_u_230.suggestPay then
			local v832 = v_u_230.suggestPay
			local v833 = v_u_236.view
			local v834
			if v833 then
				local v835 = v833.goldInStash
				v834 = type(v835) ~= "table" and {} or v833.goldInStash
			else
				v834 = {}
			end
			local v836, v837 = pcall(v832, p831, v834)
			if v836 and v837 then
				local v838 = v_u_2.payStateFrom
				local v839 = v_u_236.view
				local v840
				if v839 then
					local v841 = v839.goldInStash
					v840 = type(v841) ~= "table" and {} or v839.goldInStash
				else
					v840 = {}
				end
				return v838(v837, v840)
			end
		end
		return {}
	end
	function v_u_229.drawServices(p843) -- name: drawServices
		-- upvalues: (copy) v_u_236, (copy) v_u_226, (copy) v_u_223, (copy) v_u_224, (copy) v_u_229, (ref) v_u_3, (copy) v_u_225, (copy) p_u_222
		v_u_236.lastSub = "services"
		table.clear(v_u_236.ui)
		local v844 = v_u_236.view
		if type(v844) == "table" then
			if v844.services == false then
				v_u_226.empty(v_u_223.list({
					["parent"] = nil,
					["gap"] = 4,
					["parent"] = p843
				}), "The services are closed for now.")
			else
				local v845 = v_u_224.touch(36)
				local v846 = v_u_223.list({
					["parent"] = nil,
					["name"] = "Services",
					["horizontal"] = true,
					["gap"] = 6,
					["size"] = nil,
					["parent"] = p843,
					["size"] = UDim2.new(1, 0, 0, v845 + 6)
				})
				v_u_236.ui.seg = v846
				v_u_236.ui.svcBtns = {}
				local v847 = {
					{ "swap", "Swap parts" },
					{ "strip", "Strip a gun" }
				}
				if v_u_229.twinReady() then
					table.insert(v847, { "couple", "Couple pistols" })
					table.insert(v847, { "split", "Split a pair" })
				end
				for v848, v_u_849 in v847 do
					local v850 = v_u_3.svc == v_u_849[1]
					local v851 = v_u_223.new
					local v852 = "TextButton"
					local v853 = {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["AutomaticSize"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "Svc_" .. v_u_849[1]
					}
					local v854
					if v850 then
						v854 = v_u_225.accentDeep
					else
						v854 = v_u_225.raised
					end
					v853.BackgroundColor3 = v854
					v853.BackgroundTransparency = v850 and 0.05 or 0.3
					v853.AutomaticSize = Enum.AutomaticSize.X
					v853.Size = UDim2.fromOffset(v_u_224.touch(24), v845)
					v853.LayoutOrder = v848
					local v855 = v851(v852, v853, v846)
					v855.SelectionImageObject = v_u_223.selectionImage()
					local v856 = v_u_223.stroke
					local v857
					if v850 then
						v857 = v_u_225.accent
					else
						v857 = v_u_225.line
					end
					v856(v855, v857)
					v_u_223.pad(v855, {
						12,
						12,
						0,
						0
					})
					local v858 = v_u_223.label
					local v859 = {
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["autoX"] = true,
						["size"] = nil,
						["parent"] = v855,
						["text"] = v_u_849[2]
					}
					local v860
					if v850 then
						v860 = v_u_225.text
					else
						v860 = v_u_225.text2
					end
					v859.color = v860
					v859.size = UDim2.new(0, 0, 1, 0)
					v858(v859)
					v855:SetAttribute("On", v850)
					v855.Activated:Connect(function()
						-- upvalues: (ref) v_u_3, (copy) v_u_849, (ref) v_u_223, (ref) v_u_224, (ref) p_u_222
						if v_u_3.svc ~= v_u_849[1] then
							v_u_3.svc = v_u_849[1]
							v_u_223.sound(v_u_224.sounds.tab)
							p_u_222.redraw()
						end
					end)
					v_u_236.ui.svcBtns[v_u_849[1]] = v855
				end
				local v861 = v_u_223.new("Frame", {
					["Name"] = "Area",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(0, v845 + 10),
					["Size"] = UDim2.new(1, 0, 1, -(v845 + 10))
				}, p843)
				if v_u_3.svc == "strip" then
					v_u_229.drawStrip(v861)
				elseif (v_u_3.svc == "couple" or v_u_3.svc == "split") and v_u_229.twinReady() then
					v_u_229.drawTwin(v861, v_u_3.svc)
				else
					v_u_229.drawSwap(v861)
				end
				local v_u_862 = ("stage=%d sub=services svc=%s"):format(v_u_229.stage(), v_u_3.svc)
				local v_u_863 = "GsState"
				local function v864()
					-- upvalues: (ref) p_u_222, (copy) v_u_863, (copy) v_u_862
					p_u_222.page:SetAttribute(v_u_863, v_u_862)
				end
				pcall(v864)
			end
		else
			v_u_226.empty(v_u_223.list({
				["parent"] = nil,
				["gap"] = 4,
				["parent"] = p843
			}), "Loading...")
			return
		end
	end
	function v_u_229.drawStrip(p865) -- name: drawStrip
		-- upvalues: (copy) v_u_236, (copy) v_u_223, (copy) v_u_226, (copy) v_u_225, (copy) v_u_227, (ref) v_u_232, (copy) v_u_224, (copy) v_u_229
		local v866 = v_u_236.view
		local v867 = v_u_223.list({
			["parent"] = nil,
			["name"] = "StripList",
			["gap"] = 6,
			["parent"] = p865
		})
		v_u_226.section(v867, "Guns she can take apart", 0, nil)
		v_u_223.label({
			["parent"] = nil,
			["name"] = "Note",
			["text"] = "A plain gun becomes its parts, minus one random part. Take the attachments off and unload it first. No fee.",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v867,
			["color"] = v_u_225.text2
		})
		local v868 = v866.strip or {}
		local v869 = v_u_227 and 76 or 64
		v_u_236.ui.stripBtns = {}
		for v870, v_u_871 in v868 do
			local v872 = v_u_223.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Strip_" .. v_u_871.uid,
				["BackgroundColor3"] = v_u_225.raised,
				["Size"] = UDim2.new(1, 0, 0, v869),
				["LayoutOrder"] = 10 + v870
			}, v867)
			v_u_223.stroke(v872, v_u_225.line)
			v_u_223.new("UISizeConstraint", {
				["MaxSize"] = Vector2.new(820, (1 / 0))
			}, v872)
			local v873 = v_u_227 and 110 or 130
			v_u_223.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v872,
				["text"] = v_u_871.name,
				["color"] = v_u_225.text,
				["position"] = UDim2.fromOffset(10, 6),
				["size"] = UDim2.new(1, -v873 - 24, 0, 20)
			})
			local v874 = {}
			for _, v875 in v_u_871.parts or {} do
				local v876 = v875.role
				local v877
				if v_u_232 and (v_u_232.ROLE_NAME and v876) then
					v877 = v_u_232.ROLE_NAME[v876]
				else
					v877 = nil
				end
				local v878 = v877 or tostring(v876 or "")
				table.insert(v874, v878)
			end
			local v879
			if v_u_871.can then
				v879 = ("Gives: %s. One random part is lost."):format(table.concat(v874, ", "))
			else
				local v880 = v_u_871.reason or "Not now"
				v879 = tostring(v880)
			end
			local v881 = v_u_223.label
			local v882 = {
				["parent"] = nil,
				["name"] = "Info",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "top",
				["parent"] = v872,
				["text"] = v879
			}
			local v883
			if v_u_871.can then
				v883 = v_u_225.text2
			else
				v883 = v_u_225.danger
			end
			v882.color = v883
			v882.position = UDim2.fromOffset(10, 28)
			v882.size = UDim2.new(1, -v873 - 24, 1, -32)
			v881(v882)
			local v884, v885 = v_u_223.button({
				["parent"] = nil,
				["name"] = "Strip",
				["text"] = "Strip",
				["kind"] = "secondary",
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v872,
				["size"] = UDim2.fromOffset(v873, v_u_224.touch(44)),
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -8, 0.5, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_229, (copy) v_u_871
					v_u_229.pressStrip(v_u_871)
				end
			})
			v885.setEnabled(v_u_871.can == true)
			v_u_236.ui.stripBtns[v_u_871.uid] = v884
		end
		if #v868 == 0 then
			v_u_226.empty(v867, "No guns she can strip. Guns she builds show up here when they are in your stash.", 20)
		end
	end
	function v_u_229.pressStrip(p_u_886) -- name: pressStrip
		-- upvalues: (copy) v_u_236, (copy) v_u_223, (copy) v_u_224, (copy) v_u_226, (copy) v_u_303, (copy) v_u_225, (copy) p_u_221
		if v_u_236.busy then
			return
		elseif p_u_886.can then
			local v887 = {}
			for _, v888 in p_u_886.parts or {} do
				local v889 = {
					["name"] = nil,
					["n"] = 1,
					["id"] = nil
				}
				local v890 = v888.name
				if not v890 then
					local v891 = v888.item
					v890 = v_u_226.itemName(v891)
				end
				v889.name = v890
				v889.id = v888.item
				table.insert(v887, v889)
			end
			v_u_303({
				["title"] = nil,
				["groups"] = nil,
				["outro"] = nil,
				["action"] = "Strip",
				["onYes"] = nil,
				["title"] = ("Strip the %s?"):format(p_u_886.name),
				["groups"] = {
					{
						["title"] = "Parts it can give",
						["lines"] = nil,
						["lines"] = v887
					}
				},
				["outro"] = {
					{
						["text"] = "The gun is used up. You get all of these parts except one random part.",
						["style"] = "small",
						["color"] = nil,
						["color"] = v_u_225.text2
					},
					{
						["text"] = "She keeps one part for the work.",
						["style"] = "small",
						["color"] = nil,
						["color"] = v_u_225.accent
					}
				},
				["onYes"] = function() -- name: onYes
					-- upvalues: (ref) v_u_236, (ref) p_u_221, (copy) p_u_886
					if not v_u_236.busy then
						v_u_236.busy = true
						v_u_236.busyAt = os.clock()
						local v_u_892 = v_u_236.busyAt
						p_u_221.op({
							["op"] = "gsStrip",
							["uid"] = nil,
							["uid"] = p_u_886.uid
						})
						task.delay(6, function()
							-- upvalues: (ref) v_u_236, (copy) v_u_892
							if v_u_236.busy and v_u_236.busyAt == v_u_892 then
								v_u_236.busy = false
							end
						end)
					end
				end
			})
		else
			v_u_223.sound(v_u_224.sounds.error)
		end
	end
	function v_u_229.drawSwap(p893) -- name: drawSwap
		-- upvalues: (copy) v_u_236, (copy) v_u_226, (copy) v_u_223, (copy) p_u_222, (copy) v_u_227, (copy) v_u_228, (copy) v_u_224, (copy) v_u_225, (ref) v_u_2, (copy) v_u_814, (copy) v_u_830, (ref) v_u_232, (ref) v_u_230, (copy) v_u_842, (copy) v_u_229, (copy) v_u_400
		local v_u_894 = v_u_236.view
		local v_u_895 = v_u_236.swap
		local v896 = v_u_894.swap
		if type(v896) == "table" then
			local v897 = p_u_222.bodyWidth()
			local v898 = v_u_227 and 280 or (v_u_228 and 290 or 330)
			if v897 < 820 and not v_u_227 then
				local v899 = v897 * 0.34
				local v900 = math.floor(v899)
				v898 = math.max(250, v900)
			end
			local v901 = v896.tiers or {}
			local v902 = v_u_895.tier
			for _, v904 in v901 do
				if v904.tier ~= v902 then
					continue
				end
			end
			local v904 = nil
			if not v904 then
				v_u_895.tier = 3
			end
			local v905 = v_u_895.tier
			for _, v_u_907 in v901 do
				if v_u_907.tier ~= v905 then
					continue
				end
			end
			local v_u_907 = nil
			local v908 = v_u_223.list({
				["parent"] = nil,
				["name"] = "SwapLeft",
				["size"] = nil,
				["gap"] = 6,
				["parent"] = p893,
				["size"] = UDim2.new(1, -(v898 + 12), 1, 0)
			})
			local v909 = v_u_223.new("Frame", {
				["Name"] = "SwapRight",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.fromScale(1, 0),
				["Size"] = UDim2.new(0, v898, 1, 0)
			}, p893)
			local _, v910 = v_u_223.panel({
				["parent"] = nil,
				["name"] = "Panel",
				["raised"] = true,
				["size"] = nil,
				["padding"] = nil,
				["parent"] = v909,
				["size"] = UDim2.fromScale(1, 1),
				["padding"] = v_u_227 and 10 or 12
			})
			local v911
			if v_u_227 and v_u_236.ui.seg then
				v911 = v_u_236.ui.seg
			else
				v911 = v_u_223.new("Frame", {
					["Name"] = "Tiers",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, v_u_224.touch(40))
				}, v908)
				v_u_223.layout(v911, "h", 6)
			end
			v_u_236.ui.tierBtns = {}
			for v912, v_u_913 in v901 do
				local v914 = v_u_895.tier == v_u_913.tier
				local v915 = v_u_223.new
				local v916 = "TextButton"
				local v917 = {
					["Name"] = nil,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["AutomaticSize"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Tier_" .. v_u_913.tier
				}
				local v918
				if v914 then
					v918 = v_u_225.accentDeep
				else
					v918 = v_u_225.raised
				end
				v917.BackgroundColor3 = v918
				v917.BackgroundTransparency = v914 and 0.05 or 0.3
				v917.AutomaticSize = Enum.AutomaticSize.X
				local v919 = UDim2.fromOffset
				local v920 = v_u_224.touch(24)
				local v921
				if v_u_227 and v_u_236.ui.seg then
					v921 = v_u_224.touch(36)
				else
					v921 = v_u_224.touch(40)
				end
				v917.Size = v919(v920, v921)
				v917.LayoutOrder = (v_u_227 and v_u_236.ui.seg and 10 or 0) + v912
				local v922 = v915(v916, v917, v911)
				v922.SelectionImageObject = v_u_223.selectionImage()
				local v923 = v_u_223.stroke
				local v924
				if v914 then
					v924 = v_u_225.accent
				elseif v_u_913.open then
					v924 = v_u_225.line
				else
					v924 = v_u_225.danger
				end
				v923(v922, v924, 1, v_u_913.open and 0 or 0.4)
				v_u_223.pad(v922, {
					10,
					10,
					0,
					0
				})
				v_u_223.layout(v922, "h", 5)
				if not v_u_913.open then
					v_u_223.icon("lock", {
						["size"] = 11,
						["color"] = nil,
						["color"] = v_u_225.danger
					}).Parent = v922
				end
				local v925 = v_u_223.label
				local v926 = {
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 2,
					["parent"] = v922
				}
				local v927
				if v_u_913.open then
					v927 = v_u_2.tierText(v_u_913)
				else
					local v928 = v_u_913.tier
					local v929 = v_u_913.lock
					v927 = ("Tier %d  \194\183  %s"):format(v928, (tostring(v929)))
				end
				v926.text = v927
				local v930
				if v914 then
					v930 = v_u_225.text
				elseif v_u_913.open then
					v930 = v_u_225.text2
				else
					v930 = v_u_225.danger
				end
				v926.color = v930
				v926.size = UDim2.new(0, 0, 1, 0)
				v925(v926)
				v922:SetAttribute("Open", v_u_913.open == true)
				v922.Activated:Connect(function()
					-- upvalues: (ref) v_u_223, (ref) v_u_224, (copy) v_u_895, (copy) v_u_913, (ref) p_u_222
					v_u_223.sound(v_u_224.sounds.click)
					if v_u_895.tier ~= v_u_913.tier then
						v_u_895.tier = v_u_913.tier
						local v931 = v_u_895
						local v932 = v_u_895
						local v933 = v_u_895
						v_u_895.give = {}
						v931.want = nil
						v932.payN = {}
						v933.custom = false
						p_u_222.redraw()
					end
				end)
				v_u_236.ui.tierBtns[v_u_913.tier] = v922
			end
			local v934 = {}
			for _, v935 in v896.parts or {} do
				if v935.tier ~= v_u_895.tier then
					continue
				end
				table.insert(v934, v935)
			end
			local v_u_936 = 0
			for _, v937 in v934 do
				if not v_u_895.give[v937.uid] then
					continue
				end
				v_u_936 = v_u_936 + 1
			end
			v_u_226.section(v908, ("You give  \194\183  3 parts of tier %d"):format(v_u_895.tier), 2, ("%d / 3"):format(v_u_936))
			local v938 = v_u_224.touch(46)
			local v939 = v_u_814(v908, "Give", 3, v_u_227 and 150 or 170, v938, 6)
			v_u_236.ui.giveTiles = {}
			for v940, v_u_941 in v934 do
				local v942 = v_u_895.give[v_u_941.uid] == true
				local v943 = v_u_830
				local v944 = "Give_" .. v_u_941.uid
				local v945 = v_u_941.name
				local v946 = "%s  \194\183  %s"
				local v947 = v_u_941.weapon
				local v948 = v_u_226.itemName(v947)
				local v949 = v_u_941.role
				local v950
				if v_u_232 and (v_u_232.ROLE_NAME and v949) then
					v950 = v_u_232.ROLE_NAME[v949]
				else
					v950 = nil
				end
				local v952 = v943(v939, v944, v940, v945, v946:format(v948, v950 or tostring(v949 or "")), v942, nil, function()
					-- upvalues: (copy) v_u_895, (copy) v_u_941, (ref) v_u_223, (ref) v_u_224, (ref) p_u_222
					if v_u_895.give[v_u_941.uid] then
						v_u_895.give[v_u_941.uid] = nil
					else
						local v951 = 0
						for _ in v_u_895.give do
							v951 = v951 + 1
						end
						if v951 >= 3 then
							v_u_223.sound(v_u_224.sounds.error)
							return
						end
						v_u_895.give[v_u_941.uid] = true
					end
					v_u_895.custom = false
					p_u_222.redraw()
				end)
				v_u_236.ui.giveTiles[v_u_941.uid] = v952
			end
			if #v934 == 0 then
				v_u_226.empty(v939.Parent, ("You have no tier %d gun parts in your stash. Loose parts from raids and from stripped guns show up here."):format(v_u_895.tier), 3)
			end
			local v953 = v896.wants
			local v954
			if type(v953) == "table" then
				local v955 = v896.wants
				local v956 = v_u_895.tier
				v954 = v955[tostring(v956)] or {}
			else
				v954 = {}
			end
			local v957 = table.clone(v954)
			local v_u_958 = {}
			if v_u_232 and v_u_232.RECIPE_ORDER then
				for v959, v960 in v_u_232.RECIPE_ORDER do
					v_u_958[v960] = v959
				end
			end
			table.sort(v957, function(p961, p962)
				-- upvalues: (ref) v_u_232, (copy) v_u_958
				local v963 = v_u_232
				if v963 then
					v963 = v_u_232.part(p961)
				end
				local v964 = v_u_232
				if v964 then
					v964 = v_u_232.part(p962)
				end
				local v965 = v_u_958[v963 and v963.weapon or ""] or 99
				local v966 = v_u_958[v964 and v964.weapon or ""] or 99
				if v965 == v966 then
					return p961 < p962
				else
					return v965 < v966
				end
			end)
			v_u_226.section(v908, ("You get  \194\183  1 part of tier %d"):format(v_u_895.tier), 4, nil)
			local v967 = v_u_814(v908, "Want", 5, v_u_227 and 150 or 170, v938, 6)
			v_u_236.ui.wantTiles = {}
			for v968, v_u_969 in v957 do
				local v970 = v_u_232
				if v970 then
					v970 = v_u_232.part(v_u_969)
				end
				local v971 = v_u_895.want == v_u_969
				local v972 = v_u_830
				local v973 = "Want_" .. v_u_969
				local v974 = v_u_226.itemName(v_u_969)
				local v975
				if v970 then
					local v976 = "%s  \194\183  %s"
					local v977 = v970.weapon
					local v978 = v_u_226.itemName(v977)
					local v979 = v970.role
					local v980
					if v_u_232 and (v_u_232.ROLE_NAME and v979) then
						v980 = v_u_232.ROLE_NAME[v979]
					else
						v980 = nil
					end
					v975 = v976:format(v978, v980 or tostring(v979 or ""))
				else
					v975 = ""
				end
				local v983 = v972(v967, v973, v968, v974, v975, v971, nil, function()
					-- upvalues: (copy) v_u_895, (copy) v_u_969, (ref) p_u_222
					local v981 = v_u_895
					local v982
					if v_u_895.want == v_u_969 then
						v982 = nil
					else
						v982 = v_u_969
					end
					v981.want = v982
					p_u_222.redraw()
				end)
				v_u_236.ui.wantTiles[v_u_969] = v983
			end
			local v984 = not (v_u_230 and v_u_230.swapNote) and "" or v_u_230.swapNote(v896, v_u_895.tier)
			if #v957 == 0 then
				local v985 = v_u_226.empty
				local v986 = v967.Parent
				local v987
				if v_u_230 and v_u_230.swapEmpty then
					local v988 = v_u_230.swapEmpty
					local v989 = v_u_895.tier
					local v990
					if v_u_907 then
						v990 = not v_u_907.open
					else
						v990 = v_u_907
					end
					local v991 = not v990
					local v992
					if v_u_907 then
						v992 = v_u_907.lock
					else
						v992 = v_u_907
					end
					v987 = v988(v896, v989, v991, v992)
				elseif v_u_907 and not v_u_907.open then
					local v993 = v_u_895.tier
					local v994 = v_u_907.lock
					v987 = ("She swaps tier %d parts from %s."):format(v993, (tostring(v994)))
				else
					v987 = "There is nothing to swap for at this tier yet."
				end
				v985(v986, v987, 5)
			end
			if v984 ~= "" and (v_u_907 == nil or v_u_907.open) then
				v_u_223.label({
					["parent"] = nil,
					["name"] = "WantNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["order"] = 6,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v967.Parent,
					["text"] = v984,
					["color"] = v_u_225.text2,
					["size"] = UDim2.new(1, 0, 0, 18)
				})
			end
			local v995 = v_u_223.list
			local v996 = {
				["parent"] = nil,
				["name"] = "SwapSummary",
				["size"] = nil,
				["gap"] = 4,
				["parent"] = v910
			}
			local v997 = UDim2.new
			local v998 = 1
			local v999 = 0
			local v1000 = 1
			local v1001
			if v_u_227 then
				v1001 = v_u_224.touch(44) + 6
			else
				v1001 = v_u_224.touch(44) + 8 + 34
			end
			v996.size = v997(v998, v999, v1000, -v1001)
			local v1002 = v995(v996)
			v_u_226.section(v1002, "Swap", 1, nil)
			for v1003 = 1, 3 do
				local v1004 = 0
				local v1005 = "Pick a part"
				for _, v1006 in v934 do
					if not v_u_895.give[v1006.uid] then
						continue
					end
					v1004 = v1004 + 1
					if v1004 ~= v1003 then
						continue
					end
					v1005 = v1006.name
				end
				local v1007 = v_u_223.label
				local v1008 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["order"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v1002,
					["name"] = "GiveLine" .. v1003,
					["text"] = ("Give: %s"):format(v1005)
				}
				local v1009
				if v1005 == "Pick a part" then
					v1009 = v_u_225.muted
				else
					v1009 = v_u_225.text
				end
				v1008.color = v1009
				v1008.order = v1003 + 1
				v1008.size = UDim2.new(1, 0, 0, 18)
				v1007(v1008)
			end
			local v1010 = v_u_223.label
			local v1011 = {
				["parent"] = nil,
				["name"] = "GetLine",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["order"] = 5,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v1002
			}
			local v1012 = "Get: %s"
			local v1013
			if v_u_895.want then
				local v1014 = v_u_895.want
				v1013 = v_u_226.itemName(v1014)
			else
				v1013 = "choose a part"
			end
			v1011.text = v1012:format(v1013)
			local v1015
			if v_u_895.want then
				v1015 = v_u_225.success
			else
				v1015 = v_u_225.muted
			end
			v1011.color = v1015
			v1011.size = UDim2.new(1, 0, 0, 18)
			v1010(v1011)
			local v1016
			if v_u_907 then
				local v1017 = v_u_907.fee
				v1016 = tonumber(v1017) or 1
			else
				v1016 = 1
			end
			local v_u_1018 = {
				["payN"] = v_u_895.payN,
				["custom"] = v_u_895.custom
			}
			if not v_u_895.custom then
				v_u_1018.payN = v_u_842(v1016)
				v_u_895.payN = v_u_1018.payN
			end
			local v1019
			if v_u_227 then
				v1019 = v_u_224.touch(44) + 6
			else
				v1019 = v_u_224.touch(44) + 8 + 34
			end
			local v1020 = v_u_223.new("Frame", {
				["Name"] = "Foot",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, v1019)
			}, v910)
			local v1021 = v_u_223.label
			local v1022 = {
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["size"] = nil,
				["valign"] = nil,
				["parent"] = v1020,
				["color"] = v_u_225.text2
			}
			local v1023
			if v_u_227 then
				v1023 = UDim2.new(0.5, -6, 1, 0)
			else
				v1023 = UDim2.new(1, 0, 0, 34)
			end
			v1022.size = v1023
			v1022.valign = v_u_227 and "center" or "bottom"
			local v_u_1024 = v1021(v1022)
			local v_u_1025 = nil
			local v_u_1026 = nil
			local v_u_1027 = nil
			local function v_u_1046() -- name: paintFoot
				-- upvalues: (ref) v_u_2, (copy) v_u_907, (ref) v_u_936, (copy) v_u_895, (ref) v_u_1027, (ref) v_u_236, (ref) v_u_1025, (copy) v_u_1024, (copy) v_u_894, (ref) v_u_225, (ref) v_u_1026, (ref) p_u_222
				local v1028 = v_u_2.swapState
				local v1029 = v_u_907
				local v1030 = v_u_936
				local v1031 = v_u_895.want
				local v1032 = v_u_1027 == nil and true or v_u_1027.ok == true
				local v1033 = v_u_1027
				if v1033 then
					v1033 = v_u_1027.why
				end
				local v1034, v1035 = v1028(v1029, v1030, v1031, v1032, v1033, v_u_236.busy)
				v_u_1025.setEnabled(v1034)
				local v1036 = v_u_1024
				local v1037
				if v1034 then
					v1037 = ("%s with PINS"):format(v_u_2.repText(v_u_894.swapRep or 0.005))
				else
					v1037 = tostring(v1035 or "")
				end
				v1036.Text = v1037
				local v1038 = v_u_1024
				local v1039
				if v1034 then
					v1039 = v_u_225.success
				else
					v1039 = v_u_225.danger
				end
				v1038.TextColor3 = v1039
				v_u_1026:SetAttribute("Can", v1034)
				local v1040 = v_u_895.tier
				local v1041 = v_u_936
				local v1042 = v_u_895.want
				local v_u_1043 = ("tier=%d give=%d want=%s can=%s %s"):format(v1040, v1041, tostring(v1042), tostring(v1034), (tostring(v1035 or "")))
				local v_u_1044 = "GsSwap"
				local function v1045()
					-- upvalues: (ref) p_u_222, (copy) v_u_1044, (copy) v_u_1043
					p_u_222.page:SetAttribute(v_u_1044, v_u_1043)
				end
				pcall(v1045)
			end
			local v1047 = v_u_223.button
			local v1048 = {
				["parent"] = nil,
				["name"] = "Swap",
				["text"] = "Swap",
				["kind"] = "primary",
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v1020
			}
			local v1049
			if v_u_227 then
				v1049 = UDim2.new(0.5, 0, 0, v_u_224.touch(44))
			else
				v1049 = UDim2.new(1, 0, 0, v_u_224.touch(44))
			end
			v1048.size = v1049
			local v1050
			if v_u_227 then
				v1050 = Vector2.new(1, 1)
			else
				v1050 = nil
			end
			v1048.anchor = v1050
			local v1051
			if v_u_227 then
				v1051 = UDim2.fromScale(1, 1)
			else
				v1051 = UDim2.new(0, 0, 1, -v_u_224.touch(44))
			end
			v1048.position = v1051
			function v1048.onClick() -- name: onClick
				-- upvalues: (ref) v_u_229
				v_u_229.pressSwap()
			end
			local v1052, v1053 = v1047(v1048)
			v_u_1026 = v1052
			v_u_1025 = v1053
			v_u_236.ui.swapBtn = v_u_1026
			v_u_1027 = v_u_400(v1002, 10, v1016, v_u_1018, function()
				-- upvalues: (copy) v_u_895, (copy) v_u_1018, (copy) v_u_1046
				v_u_895.custom = v_u_1018.custom
				v_u_895.payN = v_u_1018.payN
				v_u_1046()
			end, function()
				-- upvalues: (copy) v_u_895, (ref) p_u_222
				v_u_895.custom = false
				v_u_895.payN = {}
				p_u_222.redraw()
			end)
			v_u_236.ui.swapPay = v_u_1027
			v_u_236.ui.swapPayState = v_u_1018
			v_u_236.ui.swapMine = v934
			v_u_236.ui.swapFee = v1016
			v_u_1046()
		else
			v_u_226.empty(v_u_223.list({
				["parent"] = nil,
				["gap"] = 4,
				["parent"] = p893
			}), "Swapping is not open.")
		end
	end
	function v_u_229.pressSwap() -- name: pressSwap
		-- upvalues: (copy) v_u_236, (ref) v_u_2, (copy) v_u_223, (copy) v_u_224, (copy) v_u_238, (copy) v_u_225, (copy) v_u_303, (copy) p_u_221
		local v1054 = v_u_236.view
		local v1055 = v_u_236.swap
		local v1056 = v_u_236.ui.swapPay
		local v1057 = nil
		for _, v1058 in v1054.swap and v1054.swap.tiers or {} do
			if v1058.tier ~= v1055.tier then
				continue
			end
			v1057 = v1058
		end
		local v_u_1059 = {}
		local v1060 = {}
		for _, v1061 in v_u_236.ui.swapMine or {} do
			if not v1055.give[v1061.uid] then
				continue
			end
			local v1062 = {
				["uid"] = v1061.uid
			}
			table.insert(v_u_1059, v1062)
			local v1063 = {
				["name"] = nil,
				["n"] = 1,
				["id"] = nil,
				["name"] = v1061.name,
				["id"] = v1061.id
			}
			table.insert(v1060, v1063)
		end
		local v1064 = v_u_2.swapState
		local v1065 = #v_u_1059
		local v1066 = v1055.want
		local v1067 = v1056 == nil and true or v1056.ok == true
		local v1068
		if v1056 then
			v1068 = v1056.why
		else
			v1068 = v1056
		end
		if v1064(v1057, v1065, v1066, v1067, v1068, v_u_236.busy) then
			local v1069 = v_u_2.payList
			local v1070 = v_u_236.ui.swapPayState.payN
			local v1071 = v_u_236.view
			local v1072
			if v1071 then
				local v1073 = v1071.goldInStash
				v1072 = type(v1073) ~= "table" and {} or v1071.goldInStash
			else
				v1072 = {}
			end
			local v_u_1074, v1075 = v1069(v1070, v1072)
			local v1076 = {
				{
					["title"] = "Parts",
					["lines"] = nil,
					["lines"] = v1060
				}
			}
			for _, v1077 in v_u_2.consumedGroups({
				["parts"] = {},
				["general"] = {}
			}, v1075, v_u_238) do
				table.insert(v1076, v1077)
			end
			local v1078 = v1056.info or {
				["points"] = 0,
				["lost"] = 0
			}
			local v_u_1079 = v1055.want
			local v1080 = {
				{
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["text"] = ("You get: %s"):format(v_u_238(v_u_1079)),
					["color"] = v_u_225.success
				},
				{
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["text"] = ("Fee: %s. You pay %s with %s."):format(v_u_2.goldPts(v_u_236.ui.swapFee), v_u_2.pts(v1078.points), v_u_2.payWith(v1075, v_u_238)),
					["color"] = v_u_225.text2
				}
			}
			if v1078.lost > 0 then
				local v1081 = {
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["text"] = ("%d gold %s lost: no change is given back."):format(v1078.lost, v1078.lost == 1 and "point is" or "points are"),
					["color"] = v_u_225.accent
				}
				table.insert(v1080, v1081)
			end
			v_u_303({
				["title"] = "Swap these parts?",
				["intro"] = "These items are used up:",
				["groups"] = nil,
				["outro"] = nil,
				["action"] = "Swap",
				["onYes"] = nil,
				["groups"] = v1076,
				["outro"] = v1080,
				["onYes"] = function() -- name: onYes
					-- upvalues: (ref) v_u_236, (ref) p_u_221, (copy) v_u_1059, (copy) v_u_1079, (copy) v_u_1074
					if not v_u_236.busy then
						v_u_236.busy = true
						v_u_236.busyAt = os.clock()
						local v_u_1082 = v_u_236.busyAt
						local v1083 = {
							["op"] = "gsSwap",
							["give"] = nil,
							["want"] = nil,
							["pay"] = nil,
							["give"] = v_u_1059,
							["want"] = v_u_1079,
							["pay"] = v_u_1074
						}
						p_u_221.op(v1083)
						task.delay(6, function()
							-- upvalues: (ref) v_u_236, (copy) v_u_1082
							if v_u_236.busy and v_u_236.busyAt == v_u_1082 then
								v_u_236.busy = false
							end
						end)
					end
				end
			})
		else
			v_u_223.sound(v_u_224.sounds.error)
		end
	end
	function v_u_229.twinLocked() -- name: twinLocked
		-- upvalues: (copy) v_u_236
		local v1084 = v_u_236.view
		if v1084 then
			v1084 = v_u_236.view.twin
		end
		if type(v1084) ~= "table" or v1084.on ~= false then
			return false, nil
		end
		local v1085 = v1084.line or "Coupling is not available."
		return true, tostring(v1085)
	end
	function v_u_229.twinReady() -- name: twinReady
		-- upvalues: (copy) v_u_236, (copy) p_u_221
		local v1086 = v_u_236.view
		local v_u_1087 = nil
		local function v1088()
			-- upvalues: (ref) v_u_1087, (ref) p_u_221
			v_u_1087 = p_u_221.cctx.shared.TwinRules
		end
		pcall(v1088)
		local v1089
		if v_u_1087 == nil or type(v1086) ~= "table" then
			v1089 = false
		else
			v1089 = v1086.twin ~= false
		end
		return v1089
	end
	local function v_u_1100() -- name: twinStash
		-- upvalues: (copy) p_u_221, (ref) v_u_230, (ref) v_u_2
		local v_u_1090 = nil
		local v_u_1091 = nil
		local function v1092()
			-- upvalues: (ref) v_u_1090, (ref) p_u_221, (ref) v_u_1091
			v_u_1090 = p_u_221.cctx.shared.TwinRules
			v_u_1091 = p_u_221.cctx.shared.Items
		end
		pcall(v1092)
		local v1093 = p_u_221.profile
		local v1094
		if type(v1093) == "table" then
			local v1095 = v1093.inv
			if type(v1095) == "table" then
				local v1096 = v1093.inv.containers
				if type(v1096) == "table" then
					v1094 = v1093.inv.containers.stash or nil
				else
					v1094 = nil
				end
			else
				v1094 = nil
			end
		else
			v1094 = nil
		end
		if type(v1094) == "table" then
			local v1097 = v1094.items
			if type(v1097) == "table" and (v_u_1090 ~= nil and v_u_1091 ~= nil) then
				local v1098
				if v_u_230 and (v_u_230.flatten and v_u_230.nestedDepth) then
					v1098 = v_u_230.flatten(v1094.items, v_u_230.nestedDepth())
				else
					v1098 = v1094.items
				end
				return v_u_2.twinLists(v1098, function(p1099)
					-- upvalues: (ref) v_u_1091
					return v_u_1091.get(p1099)
				end, v_u_1090)
			end
		end
		return {}, {}
	end
	function v_u_229.drawTwin(p1101, p1102) -- name: drawTwin
		-- upvalues: (copy) p_u_221, (copy) v_u_1100, (copy) v_u_236, (ref) v_u_2, (copy) v_u_223, (copy) v_u_226, (copy) v_u_225, (copy) v_u_227, (copy) v_u_224, (copy) v_u_229, (copy) p_u_222, (copy) v_u_228, (copy) v_u_814, (copy) v_u_830, (copy) v_u_842, (copy) v_u_400
		local v1103 = p_u_221.cctx.shared.TwinRules
		local v_u_1104 = p_u_221.cctx.shared.Items
		local v1105, v1106 = v_u_1100()
		local v_u_1107 = v_u_236.twin
		local v1108 = v_u_236.view and v_u_236.view.twin
		if v1108 then
			v1108 = v_u_236.view.twin.fee
		end
		local v_u_1109 = tonumber(v1108) or (v1103.FEE_GOLD or v_u_2.TWIN_FEE)
		local function v1111(p1110) -- name: defOf
			-- upvalues: (copy) v_u_1104
			return v_u_1104.get(p1110)
		end
		if p1102 == "split" then
			local v1112 = v_u_223.list({
				["parent"] = nil,
				["name"] = "SplitList",
				["gap"] = 6,
				["parent"] = p1101
			})
			v_u_226.section(v1112, "Pairs", 0, nil)
			v_u_223.label({
				["parent"] = nil,
				["name"] = "Note",
				["text"] = "A pair becomes two pistols again. Free. Both keep their magazine, attachments and wear.",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 1,
				["parent"] = v1112,
				["color"] = v_u_225.text2
			})
			v_u_236.ui.splitBtns = {}
			for v1113, v_u_1114 in v1106 do
				local v1115 = v_u_223.new
				local v1116 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.25,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil
				}
				local v1117 = v_u_1114.uid
				v1116.Name = "Pair_" .. tostring(v1117)
				v1116.BackgroundColor3 = v_u_225.raised
				v1116.Size = UDim2.new(1, 0, 0, v_u_227 and 64 or 56)
				v1116.LayoutOrder = 10 + v1113
				local v1118 = v1115("Frame", v1116, v1112)
				v_u_223.stroke(v1118, v_u_225.line)
				v_u_223.new("UISizeConstraint", {
					["MaxSize"] = Vector2.new(820, (1 / 0))
				}, v1118)
				local v1119 = v1103.second(v_u_1114.inst)
				v_u_223.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v1118,
					["text"] = "Pair of " .. v_u_1114.name,
					["color"] = v_u_225.text,
					["position"] = UDim2.fromOffset(10, 6),
					["size"] = UDim2.new(1, -150, 0, 20)
				})
				local v1120 = v_u_223.label
				local v1121 = {
					["parent"] = nil,
					["name"] = "Info",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v1118
				}
				local v1122 = "Magazines: %s + %s rounds"
				local v1123 = v_u_1114.inst
				local v1124
				if v1123 then
					v1124 = v1123.ammo
				else
					v1124 = v1123
				end
				local v1125
				if tonumber(v1124) then
					local v1126 = v1123.ammo
					local v1127 = tonumber(v1126)
					local v1128 = math.floor(v1127)
					v1125 = tostring(v1128)
				else
					v1125 = "?"
				end
				v1119 = v1119
				local v1129
				if v1119 then
					v1129 = v1119.ammo
				else
					v1129 = v1119
				end
				local v1130
				if tonumber(v1129) then
					local v1131 = v1119.ammo
					local v1132 = tonumber(v1131)
					local v1133 = math.floor(v1132)
					v1130 = tostring(v1133)
				else
					v1130 = "?"
				end
				v1121.text = v1122:format(v1125, v1130)
				v1121.color = v_u_225.text2
				v1121.position = UDim2.fromOffset(10, 28)
				v1121.size = UDim2.new(1, -150, 0, 18)
				v1120(v1121)
				local v1134 = v_u_223.button({
					["parent"] = nil,
					["name"] = "Split",
					["text"] = "Split",
					["kind"] = "secondary",
					["size"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["onClick"] = nil,
					["parent"] = v1118,
					["size"] = UDim2.fromOffset(110, v_u_224.touch(44)),
					["anchor"] = Vector2.new(1, 0.5),
					["position"] = UDim2.new(1, -8, 0.5, 0),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_229, (copy) v_u_1114
						v_u_229.pressSplit(v_u_1114)
					end
				})
				v_u_236.ui.splitBtns[v_u_1114.uid] = v1134
			end
			if #v1106 == 0 then
				v_u_226.empty(v1112, v_u_2.TWIN_TEXT.noPairs, 20)
			end
			local v_u_1135 = ("split pairs=%d"):format(#v1106)
			local v_u_1136 = "GsTwin"
			local function v1137()
				-- upvalues: (ref) p_u_222, (copy) v_u_1136, (copy) v_u_1135
				p_u_222.page:SetAttribute(v_u_1136, v_u_1135)
			end
			pcall(v1137)
		else
			local v1138 = p_u_222.bodyWidth()
			local v1139 = v_u_227 and 280 or (v_u_228 and 290 or 330)
			if v1138 < 820 and not v_u_227 then
				local v1140 = v1138 * 0.34
				local v1141 = math.floor(v1140)
				v1139 = math.max(250, v1141)
			end
			local v1142 = {}
			for _, v1143 in v1105 do
				v1142[v1143.uid] = v1143
			end
			if v_u_1107.a ~= nil and v1142[v_u_1107.a] == nil then
				v_u_1107.a = nil
			end
			if v_u_1107.b ~= nil and v1142[v_u_1107.b] == nil then
				v_u_1107.b = nil
			end
			local v1144 = v_u_223.list({
				["parent"] = nil,
				["name"] = "TwinLeft",
				["size"] = nil,
				["gap"] = 6,
				["parent"] = p1101,
				["size"] = UDim2.new(1, -(v1139 + 12), 1, 0)
			})
			local v1145 = v_u_223.new("Frame", {
				["Name"] = "TwinRight",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.fromScale(1, 0),
				["Size"] = UDim2.new(0, v1139, 1, 0)
			}, p1101)
			local _, v1146 = v_u_223.panel({
				["parent"] = nil,
				["name"] = "Panel",
				["raised"] = true,
				["size"] = nil,
				["padding"] = nil,
				["parent"] = v1145,
				["size"] = UDim2.fromScale(1, 1),
				["padding"] = v_u_227 and 10 or 12
			})
			v_u_226.section(v1144, "Your pistols", 0, nil)
			local v1147 = v_u_814(v1144, "Twin", 1, v_u_227 and 150 or 170, v_u_224.touch(46), 6)
			v_u_236.ui.twinTiles = {}
			for v1148, v_u_1149 in v1105 do
				local v1150 = v_u_1107.a == v_u_1149.uid and true or v_u_1107.b == v_u_1149.uid
				local v1151 = "%s rounds  \194\183  %s"
				local v1152 = v_u_1149.inst
				local v1153
				if v1152 then
					v1153 = v1152.ammo
				else
					v1153 = v1152
				end
				local v1154
				if tonumber(v1153) then
					local v1155 = v1152.ammo
					local v1156 = tonumber(v1155)
					local v1157 = math.floor(v1156)
					v1154 = tostring(v1157)
				else
					v1154 = "?"
				end
				local v1158
				if v_u_1149.dur then
					local v1159 = v_u_1149.dur * (v_u_1149.dur <= 1 and 100 or 1) + 0.5
					v1158 = ("%d%%"):format((math.floor(v1159)))
				else
					v1158 = "wear ?"
				end
				local v1160 = v1151:format(v1154, v1158)
				local v1161 = v_u_236.ui.twinTiles
				local v1162 = v_u_1149.uid
				local v1163 = v_u_830
				local v1164 = v_u_1149.uid
				v1161[v1162] = v1163(v1147, "Twin_" .. tostring(v1164), v1148, v_u_1149.name, v1160, v1150, nil, function()
					-- upvalues: (copy) v_u_1107, (copy) v_u_1149, (ref) p_u_222
					if v_u_1107.a == v_u_1149.uid then
						local v1165 = v_u_1107
						v_u_1107.a = v_u_1107.b
						v1165.b = nil
					elseif v_u_1107.b == v_u_1149.uid then
						v_u_1107.b = nil
					elseif v_u_1107.a == nil then
						v_u_1107.a = v_u_1149.uid
					elseif v_u_1107.b == nil then
						v_u_1107.b = v_u_1149.uid
					else
						local v1166 = v_u_1107
						local v1167 = v_u_1107
						local v1168 = v_u_1107.b
						local v1169 = v_u_1149.uid
						v1166.a = v1168
						v1167.b = v1169
					end
					v_u_1107.custom = false
					p_u_222.redraw()
				end)
			end
			if #v1105 == 0 then
				v_u_226.empty(v1147.Parent, v_u_2.TWIN_TEXT.none, 3)
			end
			local v_u_1170 = v1142[v_u_1107.a]
			local v_u_1171 = v1142[v_u_1107.b]
			local v_u_1172
			if v_u_1170 and v_u_1171 then
				v_u_1172 = v_u_2.twinDry(v_u_1170.inst, v_u_1171.inst, v1111, v1103)
			else
				v_u_1172 = nil
			end
			local v1173 = v_u_223.list
			local v1174 = {
				["parent"] = nil,
				["name"] = "TwinSummary",
				["size"] = nil,
				["gap"] = 4,
				["parent"] = v1146
			}
			local v1175 = UDim2.new
			local v1176 = 1
			local v1177 = 0
			local v1178 = 1
			local v1179
			if v_u_227 then
				v1179 = v_u_224.touch(44) + 6
			else
				v1179 = v_u_224.touch(44) + 8 + 34
			end
			v1174.size = v1175(v1176, v1177, v1178, -v1179)
			local v1180 = v1173(v1174)
			v_u_226.section(v1180, "Couple", 1, nil)
			local v1181 = v_u_223.label
			local v1182 = {
				["parent"] = nil,
				["name"] = "Gun1",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["order"] = 2,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v1180,
				["text"] = ("Gun 1: %s"):format(not v_u_1170 and "pick a pistol" or v_u_1170.name)
			}
			local v1183
			if v_u_1170 then
				v1183 = v_u_225.text
			else
				v1183 = v_u_225.muted
			end
			v1182.color = v1183
			v1182.size = UDim2.new(1, 0, 0, 18)
			v1181(v1182)
			local v1184 = v_u_223.label
			local v1185 = {
				["parent"] = nil,
				["name"] = "Gun2",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["order"] = 3,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v1180
			}
			local v1186 = "Gun 2: %s"
			local v1187
			if v_u_1171 then
				v1187 = v_u_1171.name
			elseif v_u_1170 then
				v1187 = v_u_2.TWIN_TEXT.pickOne
			else
				v1187 = v_u_2.TWIN_TEXT.pickTwo
			end
			v1185.text = v1186:format(v1187)
			local v1188
			if v_u_1171 then
				v1188 = v_u_225.text
			else
				v1188 = v_u_225.muted
			end
			v1185.color = v1188
			v1185.size = UDim2.new(1, 0, 0, 18)
			v1184(v1185)
			if v_u_1172 then
				if v_u_1172.ok then
					for v1189, v1190 in v_u_1172.lines do
						local v1191 = v_u_223.label
						local v1192 = {
							["parent"] = nil,
							["name"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v1180,
							["name"] = "Dry" .. v1189,
							["text"] = v1190
						}
						local v1193
						if v1189 == 1 then
							v1193 = v_u_225.success
						else
							v1193 = v_u_225.text2
						end
						v1192.color = v1193
						v1192.order = 3 + v1189
						v1191(v1192)
					end
				else
					local v1194 = v_u_223.label
					local v1195 = {
						["parent"] = nil,
						["name"] = "DryWhy",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 4,
						["parent"] = v1180
					}
					local v1196 = v_u_1172.why
					v1195.text = tostring(v1196)
					v1195.color = v_u_225.danger
					v1194(v1195)
				end
			end
			local v_u_1197 = {
				["payN"] = v_u_1107.payN,
				["custom"] = v_u_1107.custom
			}
			if not v_u_1107.custom then
				v_u_1197.payN = v_u_842(v_u_1109)
				v_u_1107.payN = v_u_1197.payN
			end
			local v1198
			if v_u_227 then
				v1198 = v_u_224.touch(44) + 6
			else
				v1198 = v_u_224.touch(44) + 8 + 34
			end
			local v1199 = v_u_223.new("Frame", {
				["Name"] = "Foot",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, v1198)
			}, v1146)
			local v1200 = v_u_223.label
			local v1201 = {
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["size"] = nil,
				["valign"] = nil,
				["parent"] = v1199,
				["color"] = v_u_225.text2
			}
			local v1202
			if v_u_227 then
				v1202 = UDim2.new(0.5, -6, 1, 0)
			else
				v1202 = UDim2.new(1, 0, 0, 34)
			end
			v1201.size = v1202
			v1201.valign = v_u_227 and "center" or "bottom"
			local v_u_1203 = v1200(v1201)
			local v_u_1204 = nil
			local v_u_1205 = nil
			local v_u_1206 = nil
			local function v_u_1220() -- name: paintFoot
				-- upvalues: (ref) v_u_229, (copy) v_u_1172, (ref) v_u_1204, (ref) v_u_236, (ref) v_u_2, (ref) v_u_1205, (copy) v_u_1203, (copy) v_u_1109, (ref) v_u_225, (ref) v_u_1206, (copy) v_u_1107, (ref) p_u_222
				local v1207, v1208 = v_u_229.twinLocked()
				local v1209 = not v1207
				if v1209 then
					if v_u_1172 == nil or (v_u_1172.ok ~= true or v_u_1204 ~= nil and v_u_1204.ok ~= true) then
						v1209 = false
					else
						v1209 = not v_u_236.busy
					end
				end
				if not v1207 then
					if v_u_1172 == nil then
						v1208 = v_u_2.TWIN_TEXT.pickTwo
					elseif v_u_1172.ok then
						if v_u_1204 and not v_u_1204.ok then
							v1208 = v_u_1204.why
						else
							v1208 = nil
						end
					else
						v1208 = v_u_1172.why
					end
				end
				v_u_1205.setEnabled(v1209)
				local v1210 = v_u_1203
				local v1211
				if v1209 then
					v1211 = ("Fee: %s"):format(v_u_2.goldPts(v_u_1109))
				else
					v1211 = tostring(v1208 or "")
				end
				v1210.Text = v1211
				local v1212 = v_u_1203
				local v1213
				if v1209 then
					v1213 = v_u_225.success
				else
					v1213 = v_u_225.danger
				end
				v1212.TextColor3 = v1213
				v_u_1206:SetAttribute("Can", v1209)
				local v1214 = v_u_1107.a
				local v1215 = tostring(v1214)
				local v1216 = v_u_1107.b
				local v_u_1217 = ("couple a=%s b=%s can=%s %s"):format(v1215, tostring(v1216), tostring(v1209), (tostring(v1208 or "")))
				local v_u_1218 = "GsTwin"
				local function v1219()
					-- upvalues: (ref) p_u_222, (copy) v_u_1218, (copy) v_u_1217
					p_u_222.page:SetAttribute(v_u_1218, v_u_1217)
				end
				pcall(v1219)
			end
			local v1221 = v_u_223.button
			local v1222 = {
				["parent"] = nil,
				["name"] = "Couple",
				["text"] = "Couple",
				["kind"] = "primary",
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v1199
			}
			local v1223
			if v_u_227 then
				v1223 = UDim2.new(0.5, 0, 0, v_u_224.touch(44))
			else
				v1223 = UDim2.new(1, 0, 0, v_u_224.touch(44))
			end
			v1222.size = v1223
			local v1224
			if v_u_227 then
				v1224 = Vector2.new(1, 1)
			else
				v1224 = nil
			end
			v1222.anchor = v1224
			local v1225
			if v_u_227 then
				v1225 = UDim2.fromScale(1, 1)
			else
				v1225 = UDim2.fromScale(0, 1)
			end
			v1222.position = v1225
			function v1222.onClick() -- name: onClick
				-- upvalues: (ref) v_u_229, (copy) v_u_1170, (copy) v_u_1171, (copy) v_u_1172, (copy) v_u_1109
				v_u_229.pressCouple(v_u_1170, v_u_1171, v_u_1172, v_u_1109)
			end
			local v1226, v1227 = v1221(v1222)
			v_u_1206 = v1226
			v_u_1205 = v1227
			v_u_236.ui.coupleBtn = v_u_1206
			v_u_1204 = v_u_400(v1180, 10, v_u_1109, v_u_1197, function()
				-- upvalues: (copy) v_u_1107, (copy) v_u_1197, (copy) v_u_1220
				v_u_1107.custom = v_u_1197.custom
				v_u_1107.payN = v_u_1197.payN
				v_u_1220()
			end, function()
				-- upvalues: (copy) v_u_1107, (ref) p_u_222
				v_u_1107.custom = false
				v_u_1107.payN = {}
				p_u_222.redraw()
			end)
			v_u_236.ui.twinPay = v_u_1204
			v_u_236.ui.twinPayState = v_u_1197
			v_u_1220()
		end
	end
	function v_u_229.pressCouple(p_u_1228, p_u_1229, p1230, p1231) -- name: pressCouple
		-- upvalues: (copy) v_u_236, (copy) v_u_229, (copy) v_u_223, (copy) v_u_224, (ref) v_u_2, (copy) v_u_238, (copy) v_u_225, (copy) v_u_303, (copy) p_u_221
		local v1232 = v_u_236.ui.twinPay
		if v_u_236.busy or (v_u_229.twinLocked() or (not p_u_1228 or (not p_u_1229 or (not p1230 or (not p1230.ok or v1232 and not v1232.ok))))) then
			v_u_223.sound(v_u_224.sounds.error)
		else
			local v1233 = v_u_2.payList
			local v1234 = v_u_236.ui.twinPayState.payN
			local v1235 = v_u_236.view
			local v1236
			if v1235 then
				local v1237 = v1235.goldInStash
				v1236 = type(v1237) ~= "table" and {} or v1235.goldInStash
			else
				v1236 = {}
			end
			local v_u_1238, v1239 = v1233(v1234, v1236)
			local v1240 = {
				{
					["title"] = "Pistols",
					["lines"] = nil,
					["lines"] = {
						{
							["name"] = nil,
							["n"] = 1,
							["id"] = nil,
							["name"] = p_u_1228.name,
							["id"] = p_u_1228.id
						},
						{
							["name"] = nil,
							["n"] = 1,
							["id"] = nil,
							["name"] = p_u_1229.name,
							["id"] = p_u_1229.id
						}
					}
				}
			}
			for _, v1241 in v_u_2.consumedGroups({
				["parts"] = {},
				["general"] = {}
			}, v1239, v_u_238) do
				table.insert(v1240, v1241)
			end
			local v1242 = v1232 and v1232.info or {
				["points"] = 0,
				["lost"] = 0
			}
			local v1243 = {
				{
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["text"] = p1230.lines[1],
					["color"] = v_u_225.success
				},
				{
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["text"] = ("Fee: %s. You pay %s with %s."):format(v_u_2.goldPts(p1231), v_u_2.pts(v1242.points), v_u_2.payWith(v1239, v_u_238)),
					["color"] = v_u_225.text2
				}
			}
			if v1242.lost > 0 then
				local v1244 = {
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["text"] = ("%d gold %s lost: no change is given back."):format(v1242.lost, v1242.lost == 1 and "point is" or "points are"),
					["color"] = v_u_225.accent
				}
				table.insert(v1243, v1244)
			end
			v_u_303({
				["title"] = "Couple these pistols?",
				["intro"] = "These two become one pair:",
				["groups"] = nil,
				["outro"] = nil,
				["action"] = "Couple",
				["onYes"] = nil,
				["groups"] = v1240,
				["outro"] = v1243,
				["onYes"] = function() -- name: onYes
					-- upvalues: (ref) v_u_236, (ref) p_u_221, (copy) p_u_1228, (copy) p_u_1229, (copy) v_u_1238
					if not v_u_236.busy then
						v_u_236.busy = true
						v_u_236.busyAt = os.clock()
						local v_u_1245 = v_u_236.busyAt
						p_u_221.op({
							["op"] = "twinCouple",
							["a"] = nil,
							["b"] = nil,
							["pay"] = nil,
							["a"] = p_u_1228.uid,
							["b"] = p_u_1229.uid,
							["pay"] = v_u_1238
						})
						local v1246 = v_u_236.twin
						local v1247 = v_u_236.twin
						local v1248 = v_u_236.twin
						local v1249 = v_u_236.twin
						v1246.a = nil
						v1247.b = nil
						v1248.payN = {}
						v1249.custom = false
						task.delay(6, function()
							-- upvalues: (ref) v_u_236, (copy) v_u_1245
							if v_u_236.busy and v_u_236.busyAt == v_u_1245 then
								v_u_236.busy = false
							end
						end)
					end
				end
			})
		end
	end
	function v_u_229.pressSplit(p_u_1250) -- name: pressSplit
		-- upvalues: (copy) v_u_236, (copy) v_u_303, (copy) v_u_225, (copy) p_u_221
		if not v_u_236.busy then
			local v1251 = v_u_303
			local v1252 = {
				["title"] = "Split the pair?",
				["groups"] = nil,
				["outro"] = nil,
				["action"] = "Split",
				["onYes"] = nil
			}
			local v1253 = {}
			local v1254 = {
				["title"] = "You get",
				["lines"] = nil,
				["lines"] = {
					{
						["name"] = nil,
						["n"] = 1,
						["id"] = nil,
						["name"] = p_u_1250.name,
						["id"] = p_u_1250.id
					},
					{
						["name"] = nil,
						["n"] = 1,
						["id"] = nil,
						["name"] = p_u_1250.name,
						["id"] = p_u_1250.id
					}
				}
			}
			__set_list(v1253, 1, {v1254})
			v1252.groups = v1253
			v1252.outro = {
				{
					["text"] = "Two single pistols again. Free. Magazines, attachments and wear stay with their gun.",
					["style"] = "small",
					["color"] = nil,
					["color"] = v_u_225.text2
				}
			}
			function v1252.onYes() -- name: onYes
				-- upvalues: (ref) v_u_236, (ref) p_u_221, (copy) p_u_1250
				if not v_u_236.busy then
					v_u_236.busy = true
					v_u_236.busyAt = os.clock()
					local v_u_1255 = v_u_236.busyAt
					p_u_221.op({
						["op"] = "twinSplit",
						["uid"] = nil,
						["uid"] = p_u_1250.uid
					})
					task.delay(6, function()
						-- upvalues: (ref) v_u_236, (copy) v_u_1255
						if v_u_236.busy and v_u_236.busyAt == v_u_1255 then
							v_u_236.busy = false
						end
					end)
				end
			end
			v1251(v1252)
		end
	end
	function v_u_229.onResult(p1256) -- name: onResult
		-- upvalues: (copy) v_u_236, (copy) p_u_222
		if type(p1256) == "table" then
			local v1257 = p1256.op
			if type(v1257) == "string" then
				local v1258 = p1256.op
				if string.sub(v1258, 1, 2) ~= "gs" then
					local v1259 = p1256.op
					if string.sub(v1259, 1, 4) ~= "twin" then
						return
					end
				end
				v_u_236.busy = false
				local v1260 = p1256.data
				local v1261
				if type(v1260) == "table" then
					v1261 = p1256.data
				else
					v1261 = nil
				end
				if p1256.ok and (p1256.op == "gsCraft" and v1261) then
					v_u_236.flash = {
						["weapon"] = v1261.weapon,
						["uid"] = v1261.uid,
						["name"] = v1261.name,
						["at"] = os.clock()
					}
					v_u_236.custom = false
					local v1262 = v1261.weapon
					local v1263 = tostring(v1262)
					local v1264 = v1261.lost
					local v_u_1265 = ("craft ok %s lost=%s"):format(v1263, (tostring(v1264)))
					local v_u_1266 = "GsLast"
					local function v1267()
						-- upvalues: (ref) p_u_222, (copy) v_u_1266, (copy) v_u_1265
						p_u_222.page:SetAttribute(v_u_1266, v_u_1265)
					end
					pcall(v1267)
					return
				elseif p1256.ok and p1256.op == "gsSwap" then
					local v1268 = v_u_236.swap
					local v1269 = v_u_236.swap
					local v1270 = v_u_236.swap
					local v1271 = v_u_236.swap
					v1268.give = {}
					v1269.want = nil
					v1270.payN = {}
					v1271.custom = false
					local v1272 = "swap ok "
					if v1261 then
						v1261 = v1261.part
					end
					local v_u_1273 = v1272 .. tostring(v1261)
					local v_u_1274 = "GsLast"
					local function v1275()
						-- upvalues: (ref) p_u_222, (copy) v_u_1274, (copy) v_u_1273
						p_u_222.page:SetAttribute(v_u_1274, v_u_1273)
					end
					pcall(v1275)
					return
				elseif p1256.ok and p1256.op == "gsStrip" then
					local v1276 = "strip ok "
					if v1261 then
						v1261 = v1261.weapon
					end
					local v_u_1277 = v1276 .. tostring(v1261)
					local v_u_1278 = "GsLast"
					local function v1279()
						-- upvalues: (ref) p_u_222, (copy) v_u_1278, (copy) v_u_1277
						p_u_222.page:SetAttribute(v_u_1278, v_u_1277)
					end
					pcall(v1279)
					return
				elseif p1256.ok and (p1256.op == "twinCouple" or p1256.op == "twinSplit") then
					local v_u_1280 = p1256.op .. " ok"
					local v_u_1281 = "GsLast"
					local function v1282()
						-- upvalues: (ref) p_u_222, (copy) v_u_1281, (copy) v_u_1280
						p_u_222.page:SetAttribute(v_u_1281, v_u_1280)
					end
					pcall(v1282)
				else
					local v1283 = p1256.op
					local v1284 = p1256.msg
					local v_u_1285 = ("%s refused %s"):format(v1283, (tostring(v1284)))
					local v_u_1286 = "GsLast"
					local function v1287()
						-- upvalues: (ref) p_u_222, (copy) v_u_1286, (copy) v_u_1285
						p_u_222.page:SetAttribute(v_u_1286, v_u_1285)
					end
					pcall(v1287)
				end
			else
				return
			end
		else
			return
		end
	end
	function v_u_229.devAct(p1288) -- name: devAct
		-- upvalues: (copy) v_u_236, (copy) v_u_229, (copy) p_u_222, (ref) v_u_3, (copy) v_u_255, (ref) v_u_2
		if string.sub(p1288, 1, 3) ~= "gs:" then
			return false
		end
		local v1289, v1290, v1291 = string.match(p1288, "^gs:(%w+):?([^:]*):?(.*)$")
		if v1289 == "pick" then
			if v_u_236.ui.tiles and v_u_236.ui.tiles[v1290] then
				v_u_229.select(v1290)
				if v_u_236.ui.openPage then
					v_u_236.ui.openPage()
				end
			else
				v_u_236.sel = v1290
				p_u_222.redraw()
			end
		elseif v1289 == "filter" then
			v_u_3.filter = v1290
			p_u_222.redraw()
		elseif v1289 == "pay" then
			v_u_236.custom = true
			v_u_236.payN[v1290] = tonumber(v1291) or 0
			if v_u_236.ui.pay then
				v_u_236.ui.pay.repaint()
			end
			if v_u_236.ui.paintFoot then
				v_u_236.ui.paintFoot()
			end
		elseif v1289 == "payopen" then
			v_u_3.payOpen = v1290 == "1"
			if v_u_236.ui.redrawDetail then
				v_u_236.ui.redrawDetail()
			elseif v_u_236.ui.swapPay then
				p_u_222.redraw()
			end
		elseif v1289 == "paycheap" then
			v_u_236.custom = false
			local v1292 = v_u_255(v_u_236.sel)
			local v1293 = v_u_236
			local v1294 = v_u_2.payStateFrom
			if v1292 then
				v1292 = v1292.pay
			end
			local v1295 = v_u_236.view
			local v1296
			if v1295 then
				local v1297 = v1295.goldInStash
				v1296 = type(v1297) ~= "table" and {} or v1295.goldInStash
			else
				v1296 = {}
			end
			v1293.payN = v1294(v1292, v1296)
			v_u_236.custom = false
			if v_u_236.ui.redrawDetail then
				v_u_236.ui.redrawDetail()
			end
		elseif v1289 == "craft" then
			v_u_229.pressCraft()
		elseif v1289 == "confirm" or v1289 == "close" then
			local v1298 = v_u_236.confirm
			if v1298 then
				local v1299 = v_u_236.confirmOnYes
				local v1300 = v1298.close
				pcall(v1300)
				v_u_236.confirm = nil
				if v1289 == "confirm" and v1299 then
					v1299()
				end
			end
		elseif v1289 == "svc" then
			v_u_3.svc = v1290
			p_u_222.redraw()
		elseif v1289 == "tier" then
			v_u_236.swap.tier = tonumber(v1290) or 3
			local v1301 = v_u_236.swap
			local v1302 = v_u_236.swap
			local v1303 = v_u_236.swap
			local v1304 = v_u_236.swap
			v1301.give = {}
			v1302.want = nil
			v1303.payN = {}
			v1304.custom = false
			p_u_222.redraw()
		elseif v1289 == "give" then
			v_u_236.swap.give[v1290] = not v_u_236.swap.give[v1290] and true or nil
			p_u_222.redraw()
		elseif v1289 == "want" then
			v_u_236.swap.want = v1290
			p_u_222.redraw()
		elseif v1289 == "swap" then
			v_u_229.pressSwap()
		elseif v1289 == "strip" then
			for _, v1305 in v_u_236.view and v_u_236.view.strip or {} do
				if v1305.uid ~= v1290 then
					continue
				end
				v_u_229.pressStrip(v1305)
			end
		elseif v1289 == "dump" then
			v_u_229.dump()
		end
		return true
	end
	function v_u_229.dump() -- name: dump
		-- upvalues: (copy) v_u_229, (copy) v_u_236, (ref) v_u_3, (ref) v_u_2, (copy) p_u_222
		local v1306 = {}
		local v1307 = v_u_229.stage()
		local v1308 = v_u_236.sel
		local v1309 = tostring(v1308)
		local v1310 = v_u_236.busy
		local v1311 = tostring(v1310)
		local v1312 = v_u_3.filter
		local v1313 = v_u_236.page
		local v1314 = ("stage=%d sel=%s busy=%s filter=%s page=%s"):format(v1307, v1309, v1311, v1312, (tostring(v1313)))
		table.insert(v1306, v1314)
		if v_u_236.ui.craftBtn then
			local v1315 = "craft can=%s text=%s"
			local v1316 = v_u_236.ui.craftBtn
			local v1317 = tostring(v1316:GetAttribute("Can"))
			local v1318 = v_u_236.ui.reasonL
			if v1318 then
				v1318 = v_u_236.ui.reasonL.Text
			end
			local v1319 = v1315:format(v1317, (tostring(v1318)))
			table.insert(v1306, v1319)
		end
		local v1320 = v_u_2.payList
		local v1321 = v_u_236.payN
		local v1322 = v_u_236.view
		local v1323
		if v1322 then
			local v1324 = v1322.goldInStash
			v1323 = type(v1324) ~= "table" and {} or v1322.goldInStash
		else
			v1323 = {}
		end
		local v1325 = {}
		for _, v1326 in v1320(v1321, v1323) do
			local v1327 = v1326.uid .. "x" .. v1326.n
			table.insert(v1325, v1327)
		end
		local v1328 = "pay=" .. table.concat(v1325, ",")
		table.insert(v1306, v1328)
		local v_u_1329 = table.concat(v1306, " | ")
		local v_u_1330 = "GsDump"
		local function v1331()
			-- upvalues: (ref) p_u_222, (copy) v_u_1330, (copy) v_u_1329
			p_u_222.page:SetAttribute(v_u_1330, v_u_1329)
		end
		pcall(v1331)
	end
	function v_u_229.leave() -- name: leave
		-- upvalues: (copy) v_u_236
		v_u_236.page = false
		v_u_236.lastSub = ""
	end
	function v_u_229.destroy() -- name: destroy
		-- upvalues: (ref) v_u_764, (copy) v_u_236
		if v_u_764 then
			local function v1332()
				-- upvalues: (ref) v_u_764
				v_u_764:Disconnect()
			end
			pcall(v1332)
			v_u_764 = nil
		end
		if v_u_236.confirm then
			local v1333 = v_u_236.confirm.close
			pcall(v1333)
			v_u_236.confirm = nil
		end
	end
	return v_u_229
end
return v_u_2