-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / MRProxyBoot

local v1 = game:GetService("Players")
local v_u_2 = {
	["name"] = "MRProxyBoot",
	["order"] = 3
}
local v_u_3 = nil
local v_u_4 = v1.LocalPlayer
local v_u_5 = 0
local v_u_6 = ""
local function v_u_17() -- name: statsLine
	-- upvalues: (ref) v_u_3
	local v7 = v_u_3.stats()
	local v8 = string.format
	local v9 = v7.proxies
	local v10 = v7.ltm
	local v11 = v7.light
	local v12 = v7.reasserted
	local v13 = v7.scanned
	local v14 = v7.swept
	local v15 = v7.queued
	local v16 = v7.enabled
	return v8("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v9, v10, v11, v12, v13, v14, v15, (tostring(v16)))
end
local function v_u_18() -- name: applyShowAttr
	-- upvalues: (ref) v_u_3, (copy) v_u_4
	v_u_3.setEnabled(v_u_4:GetAttribute("MRProxyShow") ~= true)
end
function v_u_2.init(p_u_19) -- name: init
	-- upvalues: (ref) v_u_3, (copy) v_u_2, (copy) v_u_17
	local function v20()
		-- upvalues: (ref) v_u_3, (copy) p_u_19
		v_u_3 = p_u_19.lib.MRProxyView
	end
	local v21, v22 = pcall(v20)
	if v21 then
		p_u_19.command("mrproxy.stats", function(_)
			-- upvalues: (ref) v_u_17
			return v_u_17()
		end)
		p_u_19.command("mrproxy.show", function(p23)
			-- upvalues: (ref) v_u_3
			local v24 = p23[1]
			if v24 == "on" then
				v_u_3.setEnabled(false)
				local v25 = v_u_3.stats()
				local v26 = string.format
				local v27 = v25.proxies
				local v28 = v25.ltm
				local v29 = v25.light
				local v30 = v25.reasserted
				local v31 = v25.scanned
				local v32 = v25.swept
				local v33 = v25.queued
				local v34 = v25.enabled
				return "proxies visible. " .. v26("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v27, v28, v29, v30, v31, v32, v33, (tostring(v34)))
			end
			if v24 ~= "off" then
				local v35 = v_u_3.stats()
				local v36 = string.format
				local v37 = v35.proxies
				local v38 = v35.ltm
				local v39 = v35.light
				local v40 = v35.reasserted
				local v41 = v35.scanned
				local v42 = v35.swept
				local v43 = v35.queued
				local v44 = v35.enabled
				return "usage: mrproxy.show on|off. " .. v36("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v37, v38, v39, v40, v41, v42, v43, (tostring(v44)))
			end
			v_u_3.setEnabled(true)
			local v45 = v_u_3.stats()
			local v46 = string.format
			local v47 = v45.proxies
			local v48 = v45.ltm
			local v49 = v45.light
			local v50 = v45.reasserted
			local v51 = v45.scanned
			local v52 = v45.swept
			local v53 = v45.queued
			local v54 = v45.enabled
			return "proxies hidden. " .. v46("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v47, v48, v49, v50, v51, v52, v53, (tostring(v54)))
		end)
	else
		warn("[MRProxyBoot] the proxy view failed to load:", v22)
		p_u_19.player:SetAttribute("ClientError", "mrproxy: " .. tostring(v22))
		v_u_2._broken = true
	end
end
function v_u_2.start() -- name: start
	-- upvalues: (ref) v_u_3, (copy) v_u_4, (copy) v_u_18, (ref) v_u_6
	if v_u_3 ~= nil then
		v_u_3.start()
		v_u_3.setEnabled(v_u_4:GetAttribute("MRProxyShow") ~= true)
		v_u_4:GetAttributeChangedSignal("MRProxyShow"):Connect(v_u_18)
		local v55 = v_u_3.stats()
		local v56 = string.format
		local v57 = v55.proxies
		local v58 = v55.ltm
		local v59 = v55.light
		local v60 = v55.reasserted
		local v61 = v55.scanned
		local v62 = v55.swept
		local v63 = v55.queued
		local v64 = v55.enabled
		local v65 = v56("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v57, v58, v59, v60, v61, v62, v63, (tostring(v64)))
		if v65 ~= v_u_6 then
			v_u_6 = v65
			v_u_4:SetAttribute("MRProxyStats", v65)
		end
	end
end
function v_u_2.step(p66) -- name: step
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_6, (copy) v_u_4
	if v_u_3 ~= nil then
		v_u_3.step(p66)
		v_u_5 = v_u_5 + p66
		if v_u_5 >= 2 then
			v_u_5 = 0
			local v67 = v_u_3.stats()
			local v68 = string.format
			local v69 = v67.proxies
			local v70 = v67.ltm
			local v71 = v67.light
			local v72 = v67.reasserted
			local v73 = v67.scanned
			local v74 = v67.swept
			local v75 = v67.queued
			local v76 = v67.enabled
			local v77 = v68("proxies=%d ltm=%d light=%d reasserted=%d scanned=%d swept=%d queued=%d enabled=%s", v69, v70, v71, v72, v73, v74, v75, (tostring(v76)))
			if v77 ~= v_u_6 then
				v_u_6 = v77
				v_u_4:SetAttribute("MRProxyStats", v77)
			end
		end
	end
end
return v_u_2