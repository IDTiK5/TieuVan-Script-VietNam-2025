-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIName

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_2 = script.Parent
local v_u_3 = require(v1:WaitForChild("Items"))
local v_u_4 = require(v1:WaitForChild("Theme"))
local v_u_5 = require(v1:WaitForChild("StashCase"))
local v_u_6 = require(v_u_2:WaitForChild("HushUI"))
local v_u_7 = {}
local v_u_8 = v_u_4.color
local v_u_9 = 0
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = false
local v_u_13 = {
	{ 768, 879 },
	{ 1155, 1161 },
	{ 1425, 1469 },
	{ 1471, 1471 },
	{ 1473, 1474 },
	{ 1476, 1477 },
	{ 1479, 1479 },
	{ 1552, 1562 },
	{ 1611, 1631 },
	{ 1648, 1648 },
	{ 1750, 1756 },
	{ 1759, 1764 },
	{ 1767, 1768 },
	{ 1770, 1773 },
	{ 1809, 1809 },
	{ 1840, 1866 },
	{ 2304, 2306 },
	{ 2364, 2364 },
	{ 2369, 2376 },
	{ 2381, 2381 },
	{ 3633, 3633 },
	{ 3636, 3642 },
	{ 3655, 3662 },
	{ 3761, 3761 },
	{ 3764, 3772 },
	{ 3784, 3789 },
	{ 6832, 6911 },
	{ 7616, 7679 },
	{ 8400, 8447 },
	{ 11744, 11775 },
	{ 12330, 12335 },
	{ 12441, 12442 },
	{ 42607, 42610 },
	{ 42612, 42621 },
	{ 42654, 42655 },
	{ 65024, 65039 },
	{ 65056, 65071 }
}
function v_u_7.filterDetail(p14) -- name: filterDetail
	-- upvalues: (copy) v_u_13, (copy) v_u_5
	if type(p14) ~= "string" or not utf8.len(p14) then
		return "", false
	end
	local v15 = 0
	local v16 = {}
	local v17 = false
	for _, v18 in utf8.codes(p14) do
		local v19 = utf8.char(v18)
		for _, v20 in v_u_13 do
			if v20[1] > v18 or v18 > v20[2] then
				continue
			end
			v21 = true
		end
		local v21 = false
		if v21 or v19 ~= " " and v_u_5.cleanName(v19) == nil then
			v17 = true
		else
			v15 = v15 + 1
			if v_u_5.NAME_MAX < v15 then
				break
			end
			table.insert(v16, v19)
		end
	end
	return table.concat(v16), v17
end
function v_u_7.filterText(p22) -- name: filterText
	-- upvalues: (copy) v_u_7
	return v_u_7.filterDetail(p22)
end
function v_u_7.hintFor(p23) -- name: hintFor
	-- upvalues: (copy) v_u_2
	if not p23 then
		return nil
	end
	local function v24()
		-- upvalues: (ref) v_u_2
		return require((v_u_2:WaitForChild("InvUIWhy", 3)))
	end
	local v25, v26 = pcall(v24)
	if v25 and type(v26) == "table" then
		local v27 = v26.NAME_HINT
		if type(v27) == "string" then
			return v26.NAME_HINT
		end
	end
	return "Letters, digits, spaces and . , \' ! ? & + ( ) # / _ : * and hyphen only."
end
function v_u_7.errorFor(p28) -- name: errorFor
	-- upvalues: (copy) v_u_5
	local v29 = type(p28) ~= "string" and "" or p28
	if v_u_5.cleanName(v29) == nil then
		local v30 = string.gsub(string.gsub(v29, "^%s+", ""), "%s+$", "")
		if v30 == "" or (utf8.len(v30) or 0) > v_u_5.NAME_MAX then
			return v_u_5.REASON.nameLen
		else
			return v_u_5.REASON.nameChars
		end
	else
		return nil
	end
end
function v_u_7.open(_, p31, p_u_32) -- name: open
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (ref) v_u_12, (ref) v_u_10, (ref) v_u_11, (ref) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8
	local v_u_33 = v_u_3.get(p31.id)
	if v_u_33 and v_u_5.renamable(v_u_33) then
		if not v_u_12 then
			local v34 = p_u_32.net
			if v34 then
				v34 = p_u_32.net()
			end
			if v34 then
				v_u_12 = true
				local v35 = v34.listen
				local function v42(p36)
					-- upvalues: (ref) v_u_10, (ref) v_u_11
					if type(p36) == "table" and p36.op == "rename" then
						local v37
						if v_u_10 and p36.req == v_u_10.req then
							v37 = v_u_10
							v_u_10 = nil
						else
							if not v_u_11 or p36.req ~= v_u_11.req then
								return
							end
							v37 = v_u_11
							v_u_11 = nil
						end
						local v38 = v37.done
						local v39 = p36.ok ~= false
						local v40 = p36.msg
						local v41
						if type(v40) == "string" then
							v41 = p36.msg
						else
							v41 = nil
						end
						v38(v39, v41)
					end
				end
				pcall(v35, "menu.result", v42)
			end
		end
		local v_u_43 = p31.uid
		local v_u_44 = nil
		local v_u_45 = nil
		local v_u_46 = nil
		local v_u_47 = nil
		local v_u_48 = nil
		local v_u_49 = 0
		local v_u_50 = false
		local v_u_51 = nil
		local function v_u_54(p52) -- name: setBusy
			-- upvalues: (ref) v_u_49, (ref) v_u_48, (ref) v_u_10, (ref) v_u_11, (copy) v_u_54, (ref) v_u_46
			v_u_49 = v_u_49 + 1
			if v_u_48 then
				v_u_48.setEnabled(not p52)
				v_u_48.setText(p52 and "Checking name..." or "Save")
			end
			if p52 then
				local v_u_53 = v_u_49
				task.delay(6, function()
					-- upvalues: (ref) v_u_49, (copy) v_u_53, (ref) v_u_10, (ref) v_u_11, (ref) v_u_54, (ref) v_u_46
					if v_u_49 == v_u_53 and v_u_10 then
						v_u_11 = v_u_10
						v_u_10 = nil
						v_u_54(false)
						if v_u_46 then
							v_u_46.Text = "The server is slow. If the name was saved it shows on the item in a moment."
							v_u_46.Visible = true
						end
					end
				end)
			end
		end
		local function v_u_69(p55) -- name: submit
			-- upvalues: (ref) v_u_9, (copy) p_u_32, (ref) v_u_5, (ref) v_u_46, (ref) v_u_49, (ref) v_u_48, (ref) v_u_10, (ref) v_u_11, (copy) v_u_54, (ref) v_u_44, (copy) v_u_43
			v_u_9 = v_u_9 + 1
			local v56 = "name_" .. v_u_9
			local v57 = p_u_32.net
			if v57 then
				v57 = p_u_32.net()
			end
			if v57 then
				if v_u_46 then
					v_u_46.Text = ""
					v_u_46.Visible = false
				end
				v_u_49 = v_u_49 + 1
				if v_u_48 then
					v_u_48.setEnabled(false)
					v_u_48.setText("Checking name...")
				end
				local v_u_58 = v_u_49
				task.delay(6, function()
					-- upvalues: (ref) v_u_49, (copy) v_u_58, (ref) v_u_10, (ref) v_u_11, (ref) v_u_54, (ref) v_u_46
					if v_u_49 == v_u_58 and v_u_10 then
						v_u_11 = v_u_10
						v_u_10 = nil
						v_u_54(false)
						if v_u_46 then
							v_u_46.Text = "The server is slow. If the name was saved it shows on the item in a moment."
							v_u_46.Visible = true
						end
					end
				end)
				v_u_10 = {
					["req"] = v56,
					["done"] = function(p59, p60) -- name: done
						-- upvalues: (ref) v_u_49, (ref) v_u_48, (ref) v_u_44, (ref) v_u_5, (ref) v_u_46
						v_u_49 = v_u_49 + 1
						if v_u_48 then
							v_u_48.setEnabled(true)
							v_u_48.setText("Save")
						end
						if p59 then
							if v_u_44 then
								v_u_44.close()
								return
							end
						else
							local v61 = p60 or v_u_5.REASON.nameBusy
							if v_u_46 then
								v_u_46.Text = v61 or ""
								local v62 = v_u_46
								local v63
								if v61 == nil then
									v63 = false
								else
									v63 = v61 ~= ""
								end
								v62.Visible = v63
							end
						end
					end
				}
				local v64 = v57.fire
				local v65 = {
					["op"] = "rename",
					["uid"] = nil,
					["name"] = nil,
					["req"] = nil,
					["uid"] = v_u_43,
					["name"] = p55,
					["req"] = v56
				}
				pcall(v64, "menu.op", v65)
			else
				local v66 = v_u_5.REASON.nameBusy
				if v_u_46 then
					v_u_46.Text = v66 or ""
					local v67 = v_u_46
					local v68
					if v66 == nil then
						v68 = false
					else
						v68 = v66 ~= ""
					end
					v67.Visible = v68
				end
			end
		end
		local function v_u_74() -- name: onSave
			-- upvalues: (ref) v_u_10, (ref) v_u_45, (ref) v_u_7, (ref) v_u_46, (copy) v_u_69, (ref) v_u_5
			if v_u_10 then
				return
			else
				local v70 = not v_u_45 and "" or v_u_45.Text
				local v71 = v_u_7.errorFor(v70)
				if v71 then
					if v_u_46 then
						v_u_46.Text = v71 or ""
						local v72 = v_u_46
						local v73
						if v71 == nil then
							v73 = false
						else
							v73 = v71 ~= ""
						end
						v72.Visible = v73
					end
				else
					v_u_69((v_u_5.cleanName(v70)))
				end
			end
		end
		local v75 = p31.cname
		local v_u_76 = type(v75) ~= "string" and "" or p31.cname
		v_u_44 = v_u_6.modal({
			["title"] = nil,
			["width"] = 360,
			["onClose"] = nil,
			["build"] = nil,
			["title"] = "Rename " .. string.lower(v_u_33.name),
			["onClose"] = function() -- name: onClose
				-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_49
				v_u_10 = nil
				v_u_11 = nil
				v_u_49 = v_u_49 + 1
			end,
			["build"] = function(p77) -- name: build
				-- upvalues: (ref) v_u_6, (copy) v_u_33, (copy) v_u_76, (ref) v_u_4, (ref) v_u_45, (ref) v_u_47, (ref) v_u_5, (ref) v_u_8, (ref) v_u_46, (ref) v_u_50, (ref) v_u_7, (ref) v_u_51, (ref) v_u_10, (copy) v_u_69, (ref) v_u_44, (copy) v_u_74, (ref) v_u_48
				local v78, v_u_79 = v_u_6.input({
					["parent"] = nil,
					["placeholder"] = nil,
					["text"] = nil,
					["size"] = nil,
					["name"] = "NameInput",
					["parent"] = p77,
					["placeholder"] = v_u_33.name,
					["text"] = v_u_76,
					["size"] = UDim2.new(1, 0, 0, v_u_4.touch(38))
				})
				v78.LayoutOrder = 1
				v_u_45 = v_u_79
				v_u_47 = v_u_6.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["order"] = 2,
					["size"] = nil,
					["parent"] = p77,
					["text"] = ("%d / %d"):format(utf8.len(v_u_76) or 0, v_u_5.NAME_MAX),
					["color"] = v_u_8.muted,
					["size"] = UDim2.new(1, 0, 0, 14)
				})
				v_u_46 = v_u_6.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["order"] = 3,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = p77,
					["color"] = v_u_8.danger
				})
				v_u_46.Visible = false
				v_u_79:GetPropertyChangedSignal("Text"):Connect(function()
					-- upvalues: (ref) v_u_50, (ref) v_u_7, (copy) v_u_79, (ref) v_u_51, (ref) v_u_47, (ref) v_u_5, (ref) v_u_46
					if v_u_50 then
						return
					else
						local v80, v81 = v_u_7.filterDetail(v_u_79.Text)
						if v_u_51 == nil or (v_u_79.Text ~= v_u_51 or v81) then
							v_u_51 = nil
							if v80 ~= v_u_79.Text then
								v_u_50 = true
								v_u_79.Text = v80
								v_u_50 = false
								v_u_51 = v80
							end
							v_u_47.Text = ("%d / %d"):format(utf8.len(v80) or 0, v_u_5.NAME_MAX)
							local v82 = v_u_7.hintFor(v81)
							if v_u_46 then
								v_u_46.Text = v82 or ""
								local v83 = v_u_46
								local v84
								if v82 == nil then
									v84 = false
								else
									v84 = v82 ~= ""
								end
								v83.Visible = v84
							end
						else
							v_u_51 = nil
						end
					end
				end)
				v_u_79.FocusLost:Connect(function(p85)
					-- upvalues: (ref) v_u_10, (ref) v_u_45, (ref) v_u_7, (ref) v_u_46, (ref) v_u_69, (ref) v_u_5
					if p85 then
						if v_u_10 then
							return
						end
						local v86 = not v_u_45 and "" or v_u_45.Text
						local v87 = v_u_7.errorFor(v86)
						if v87 then
							if v_u_46 then
								v_u_46.Text = v87 or ""
								local v88 = v_u_46
								local v89
								if v87 == nil then
									v89 = false
								else
									v89 = v87 ~= ""
								end
								v88.Visible = v89
								return
							end
						else
							v_u_69((v_u_5.cleanName(v86)))
						end
					end
				end)
				local v90 = Instance.new("Frame")
				v90.Name = "Buttons"
				v90.BackgroundTransparency = 1
				v90.Size = UDim2.new(1, 0, 0, v_u_4.touch(v_u_4.control))
				v90.LayoutOrder = 4
				v90.Parent = p77
				v_u_6.layout(v90, "h", v_u_4.space.s, "right")
				local v91 = {
					["parent"] = nil,
					["text"] = "Cancel",
					["kind"] = "ghost",
					["order"] = 1,
					["onClick"] = nil,
					["parent"] = v90,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_44
						v_u_44.close()
					end
				}
				v_u_6.button(v91)
				if v_u_76 ~= "" then
					local v92 = {
						["parent"] = nil,
						["text"] = "Clear name",
						["kind"] = "secondary",
						["order"] = 2,
						["onClick"] = nil,
						["parent"] = v90,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_10, (ref) v_u_69
							if not v_u_10 then
								v_u_69("")
							end
						end
					}
					v_u_6.button(v92)
				end
				local v93 = {
					["parent"] = nil,
					["text"] = "Save",
					["kind"] = "primary",
					["order"] = 3,
					["onClick"] = nil,
					["parent"] = v90,
					["onClick"] = v_u_74
				}
				local v94, v95 = v_u_6.button(v93)
				v_u_48 = v95
				v94:SetAttribute("PadDefault", true)
			end
		})
		if v_u_44 and (v_u_44.frame and v_u_4.isTouch()) then
			task.delay(0.5, function()
				-- upvalues: (ref) v_u_44
				local v96 = v_u_44.frame
				if v96 and v96.Parent then
					v96.AnchorPoint = Vector2.new(0.5, 0)
					v96.Position = UDim2.new(0.5, 0, 0.08, 0)
				end
			end)
		end
		if v_u_45 and v_u_6.device() ~= "Gamepad" then
			task.delay(0.35, function()
				-- upvalues: (ref) v_u_45
				if v_u_45 and v_u_45.Parent then
					local function v97()
						-- upvalues: (ref) v_u_45
						v_u_45:CaptureFocus()
					end
					pcall(v97)
				end
			end)
		end
	end
end
return v_u_7