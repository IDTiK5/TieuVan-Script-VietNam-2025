-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryPickupFx

local v_u_132 = {
	["ON_LO"] = 0.3,
	["ON_HI"] = 0.55,
	["BEAM_RANGE"] = 50,
	["BEAM_ANGLE"] = 55,
	["BEAM_BRIGHTNESS"] = 2.2,
	["MAX_STEER"] = 0.5,
	["AXLE_FRONT"] = 0.36,
	["AXLE_REAR"] = 0.25,
	["WARM"] = { 255, 238, 200 },
	["darkness"] = function(p1, p2) -- name: darkness
		local v3
		if type(p1) == "number" and (p1 == p1 and p1 > -1000000000) then
			v3 = p1 < 1000000000
		else
			v3 = false
		end
		if v3 then
			local v4 = p1 % 24
			if v4 < 12 then
				local v5 = (7 - v4) / 2
				local v6 = v5 < 0 and 0 or (v5 > 1 and 1 or v5)
				return v6 * v6 * (3 - v6 * 2)
			else
				local v7 = (v4 - 16.5) / 2.5
				local v8 = v7 < 0 and 0 or (v7 > 1 and 1 or v7)
				return v8 * v8 * (3 - v8 * 2)
			end
		else
			return p2 == "Night" and 1 or (p2 == "Dusk" and 0.5 or 0)
		end
	end,
	["level"] = function(p9, p10) -- name: level
		-- upvalues: (copy) v_u_132
		local v11 = (p9 - v_u_132.ON_LO) / (v_u_132.ON_HI - v_u_132.ON_LO)
		local v12 = v11 < 0 and 0 or (v11 > 1 and 1 or v11)
		return v12 * v12 * (3 - v12 * 2) * (p10 < 0 and 0 or (p10 > 1 and 1 or p10))
	end,
	["lampState"] = function(p13, p14) -- name: lampState
		-- upvalues: (copy) v_u_132
		local v15 = p13 < 0 and 0 or (p13 > 1 and 1 or p13)
		local v16 = p14 and 1 or 0
		return {
			["on"] = v15 > 0.02,
			["headTransparency"] = 1 - v15,
			["tailTransparency"] = 1 - v15 * (v16 * 0.28 + 0.72),
			["tailR"] = v16 * 85 + 170,
			["tailG"] = v16 * 52 + 18,
			["tailB"] = v16 * 44 + 16,
			["beam"] = v_u_132.BEAM_BRIGHTNESS * v15
		}
	end,
	["wheelAngle"] = function(p17, p18) -- name: wheelAngle
		local v19
		if type(p17) == "number" and (p17 == p17 and p17 > -1000000000) then
			v19 = p17 < 1000000000
		else
			v19 = false
		end
		if v19 then
			local v20
			if type(p18) == "number" and (p18 == p18 and p18 > -1000000000) then
				v20 = p18 < 1000000000
			else
				v20 = false
			end
			if v20 and p18 >= 0.05 then
				return -p17 / p18
			end
		end
		return 0
	end,
	["wrapPi"] = function(p21) -- name: wrapPi
		return (p21 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	end,
	["steerAngle"] = function(p22, p23, p24) -- name: steerAngle
		-- upvalues: (copy) v_u_132
		local v25
		if type(p22) == "number" and (p22 == p22 and p22 > -1000000000) then
			v25 = p22 < 1000000000
		else
			v25 = false
		end
		if v25 then
			local v26
			if type(p23) == "number" and (p23 == p23 and p23 > -1000000000) then
				v26 = p23 < 1000000000
			else
				v26 = false
			end
			if v26 and math.abs(p23) >= 0.02 then
				local v27 = p24 * (((p22 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) / p23)
				local v28 = math.atan(v27)
				local v29 = -v_u_132.MAX_STEER
				local v30 = v_u_132.MAX_STEER
				if v28 < v29 then
					return v29
				elseif v30 < v28 then
					return v30
				else
					return v28
				end
			end
		end
		return 0
	end,
	["wheelShape"] = function(p31, p32, p33, p34) -- name: wheelShape
		local v35 = p31.y
		local v36 = p31.z
		local v37 = math.max(v35, v36)
		if v37 < (p34 and 0.8 or 1.6) or v37 > 4.4 then
			return nil
		else
			local v38 = p31.y
			local v39 = p31.z
			if math.min(v38, v39) < v37 * 0.75 then
				return nil
			elseif p31.x > v37 * 0.8 then
				return nil
			elseif p34 or p31.x >= v37 * 0.2 then
				if p32.y - v37 / 2 > p33.minY + 1 then
					return nil
				else
					local v40 = p32.x
					if math.abs(v40) < 1.2 then
						return nil
					else
						return v37 / 2
					end
				end
			else
				return nil
			end
		end
	end,
	["pickWheels"] = function(p41) -- name: pickWheels
		if #p41 < 4 then
			return nil
		end
		local v42 = 0
		local v43 = (1 / 0)
		local v44 = (-1 / 0)
		local v45 = 0
		for _, v46 in p41 do
			if v46.x < 0 then
				v42 = v42 + 1
			else
				v45 = v45 + 1
			end
			local v47 = v46.z
			v43 = math.min(v43, v47)
			local v48 = v46.z
			v44 = math.max(v44, v48)
		end
		if v42 < 2 or (v45 < 2 or v44 - v43 < 2) then
			return nil
		end
		local v49 = (v43 + v44) / 2
		local v50 = {}
		for _, v51 in p41 do
			local v52 = v51.r
			for _, v53 in p41 do
				if v53.x < 0 ~= (v51.x < 0) then
					continue
				end
				local v54 = v53.z - v51.z
				if math.abs(v54) >= 2 or v52 >= v53.r then
					continue
				end
				v52 = v53.r
			end
			local v55 = {
				["key"] = v51.key,
				["r"] = v52,
				["front"] = v51.z < v49
			}
			table.insert(v50, v55)
		end
		return v50
	end,
	["fallbackWheels"] = function(p56) -- name: fallbackWheels
		-- upvalues: (copy) v_u_132
		local v57 = p56.maxX - p56.minX
		local v58 = p56.maxZ - p56.minZ
		local v59 = (p56.minX + p56.maxX) / 2
		local v60 = (p56.minZ + p56.maxZ) / 2
		local v61 = 0.066 * v58
		local v62 = v61 < 1 and 1 or (v61 > 2 and 2 or v61)
		local v63 = 0.4 * (p56.maxY - p56.minY)
		local v64 = 0.15 * v58
		local v65 = math.min(v62, v63, v64)
		local v66 = v65 * 0.55
		local v67 = v66 < 0.6 and 0.6 or (v66 > 1.1 and 1.1 or v66)
		local v68 = 0.5 * v57 - v67 / 2 - 0.35
		local v69 = {}
		for _, v70 in { -1, 1 } do
			for _, v71 in { -1, 1 } do
				local v72 = {
					["x"] = v59 + v71 * v68,
					["y"] = p56.minY + v65 + 0.1
				}
				local v73
				if v70 < 0 then
					v73 = v_u_132.AXLE_FRONT
				else
					v73 = v_u_132.AXLE_REAR
				end
				local v74 = v73 * v58
				local v75 = v58 / 2 - v65
				v72.z = v60 + v70 * math.min(v74, v75)
				v72.radius = v65
				v72.width = v67
				v72.front = v70 < 0
				v72.side = v71
				table.insert(v69, v72)
			end
		end
		return v69
	end,
	["wheelBlock"] = function(p76, p77, p78, p79) -- name: wheelBlock
		if not p79 then
			return nil
		end
		local v80 = p76.y
		if v80 < 1.6 or v80 > 4.4 then
			return nil
		end
		local v81 = p78.maxX - p78.minX
		local v82 = p78.maxZ - p78.minZ
		if p76.x < 0.6 * v81 or (p76.z < 0.5 * v82 or p76.z < v80 * 2.5) then
			return nil
		end
		local v83 = p77.x
		if math.abs(v83) > 0.15 * v81 or p77.y - v80 / 2 > p78.minY + 1 then
			return nil
		end
		local v84 = v80 / 2
		local v85 = v84 * 0.55
		local v86 = v85 < 0.6 and 0.6 or (v85 > 1.1 and 1.1 or v85)
		local v87 = p76.x / 2 - v86 / 2
		local v88 = {}
		for _, v89 in { -1, 1 } do
			for _, v90 in { -1, 1 } do
				local v91 = {
					["x"] = p77.x + v90 * v87,
					["y"] = p77.y
				}
				local v92
				if v89 < 0 then
					v92 = p77.z - p76.z / 2 + v84
				else
					v92 = p77.z + p76.z / 2 - v84
				end
				v91.z = v92
				v91.radius = v84
				v91.width = v86
				v91.front = v89 < 0
				v91.side = v90
				table.insert(v88, v91)
			end
		end
		return v88
	end,
	["SURFACE_BAND"] = 0.4,
	["LENS_OFFSET"] = 0.08,
	["surfaceZ"] = function(p93, p94) -- name: surfaceZ
		-- upvalues: (copy) v_u_132
		local v95 = nil
		for _, v96 in p93 do
			if v95 ~= nil then
				local v97
				if p94 < 0 then
					v97 = v96 < v95
				else
					v97 = v95 < v96
				end
				if not v97 then
					continue
				end
			end
			v95 = v96
		end
		if v95 == nil then
			return nil
		end
		local v98 = 0
		local v99 = 0
		for _, v100 in p93 do
			local v101 = v100 - v95
			if math.abs(v101) > v_u_132.SURFACE_BAND then
				continue
			end
			v98 = v98 + v100
			v99 = v99 + 1
		end
		return v98 / v99
	end,
	["lensCenterZ"] = function(p102, p103, p104, p105) -- name: lensCenterZ
		-- upvalues: (copy) v_u_132
		local v106 = p105 or v_u_132.LENS_OFFSET
		return p102 + p103 * ((v106 < 0.04 and 0.04 or (v106 > 0.1 and 0.1 or v106)) - p104 / 2)
	end,
	["MAX_SLOPE"] = 0.7,
	["fitSurface"] = function(p107, p108, p109, p110, p111) -- name: fitSurface
		-- upvalues: (copy) v_u_132
		local v112 = {}
		for _, v113 in { p107, p108, p109 } do
			if not v113 then
				continue
			end
			table.insert(v112, v113)
		end
		if #v112 == 0 then
			return nil, 0
		end
		if p107 and (p109 and p110 > 0) then
			local v114 = (p109 - p107) / (p110 * 2)
			if math.abs(v114) <= v_u_132.MAX_SLOPE then
				local v115
				if p108 then
					v115 = (p107 + p108 + p109) / 3
				else
					v115 = (p107 + p109) / 2
				end
				return v115, v114
			end
		end
		local v116 = v112[1]
		for _, v117 in v112 do
			local v118
			if p111 < 0 then
				v118 = v117 < v116
			else
				v118 = v116 < v117
			end
			if not v118 then
				continue
			end
			v116 = v117
		end
		return v116, 0
	end,
	["lensPose"] = function(p119, p120, p121, p122) -- name: lensPose
		-- upvalues: (copy) v_u_132
		local v123 = p122 or v_u_132.LENS_OFFSET
		local v124 = v123 < 0.04 and 0.04 or (v123 > 0.1 and 0.1 or v123)
		local v125 = -math.atan(p119)
		local v126 = v124 - p121 / 2
		return v125, p120 * math.sin(v125) * v126, p120 * math.cos(v125) * v126
	end,
	["spokes"] = function(p127) -- name: spokes
		local v128 = {}
		for v129 = 0, 2 do
			local v130 = {
				["angle"] = v129 * 3.141592653589793 / 3,
				["length"] = p127 * 1.5
			}
			local v131 = p127 * 0.16
			v130.width = math.max(v131, 0.22)
			table.insert(v128, v130)
		end
		return v128
	end
}
local v_u_133 = {
	"wheel",
	"tire",
	"tyre",
	"rim",
	"hub",
	"felge",
	"reifen"
}
local function v_u_141(p134, p135) -- name: hinted
	-- upvalues: (copy) v_u_133
	local v136 = { string.lower(p134.Name) }
	if p134.Parent and p134.Parent ~= p135 then
		local v137 = string.lower
		local v138 = p134.Parent.Name
		table.insert(v136, v137(v138))
	end
	for _, v139 in v136 do
		for _, v140 in v_u_133 do
			if not string.find(v139, v140, 1, true) then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_153(p142, p143) -- name: localExtent
	local _, _, _, v144, v145, v146, v147, v148, v149, v150, v151, v152 = p142:GetComponents()
	return {
		["x"] = math.abs(v144) * p143.X + math.abs(v145) * p143.Y + math.abs(v146) * p143.Z,
		["y"] = math.abs(v147) * p143.X + math.abs(v148) * p143.Y + math.abs(v149) * p143.Z,
		["z"] = math.abs(v150) * p143.X + math.abs(v151) * p143.Y + math.abs(v152) * p143.Z
	}
end
local function v_u_176(p154, p155) -- name: measure
	-- upvalues: (copy) v_u_153
	local v156 = {}
	local v157 = nil
	for _, v158 in p154:GetDescendants() do
		if not v158:IsA("BasePart") then
			continue
		end
		local v159 = p155:ToObjectSpace(v158.CFrame)
		local v160 = {
			["part"] = v158,
			["rel"] = v159,
			["ext"] = v_u_153(v159, v158.Size)
		}
		table.insert(v156, v160)
	end
	for v161 = 1, 2 do
		for _, v162 in v156 do
			if v161 ~= 2 and v162.part.Transparency >= 1 then
				continue
			end
			local v163 = v162.rel.Position
			v157 = v157 or {
				["minX"] = (1 / 0),
				["maxX"] = (-1 / 0),
				["minY"] = (1 / 0),
				["maxY"] = (-1 / 0),
				["minZ"] = (1 / 0),
				["maxZ"] = (-1 / 0)
			}
			local v164 = v157.minX
			local v165 = v163.X - v162.ext.x / 2
			v157.minX = math.min(v164, v165)
			local v166 = v157.maxX
			local v167 = v163.X + v162.ext.x / 2
			v157.maxX = math.max(v166, v167)
			local v168 = v157.minY
			local v169 = v163.Y - v162.ext.y / 2
			v157.minY = math.min(v168, v169)
			local v170 = v157.maxY
			local v171 = v163.Y + v162.ext.y / 2
			v157.maxY = math.max(v170, v171)
			local v172 = v157.minZ
			local v173 = v163.Z - v162.ext.z / 2
			v157.minZ = math.min(v172, v173)
			local v174 = v157.maxZ
			local v175 = v163.Z + v162.ext.z / 2
			v157.maxZ = math.max(v174, v175)
		end
		if not v157 then
			break
		end
	end
	return v157 or {
		["minX"] = -3,
		["maxX"] = 3,
		["minY"] = 0,
		["maxY"] = 6,
		["minZ"] = -9,
		["maxZ"] = 9
	}, v156
end
local function v_u_209(p177, p178) -- name: buildFallback
	-- upvalues: (copy) v_u_132
	local v179 = p177.folder
	local v180 = Color3.fromRGB(24, 24, 26)
	local v181 = Color3.fromRGB(190, 190, 184)
	for _, v182 in p178 do
		local v183 = v182.x
		local v184 = v182.y
		local v185 = v182.z
		local v186 = Vector3.new(v183, v184, v185)
		local v187 = p177.pivot * CFrame.new(v186)
		local v188 = v182.width
		local v189 = v182.radius * 2
		local v190 = v182.radius * 2
		local v191 = Vector3.new(v188, v189, v190)
		local v192 = Enum.Material.Rubber
		local v193 = Instance.new("Part")
		v193.Name = "FxTire"
		v193.Size = v191
		v193.CFrame = v187
		v193.Color = v180
		v193.Material = v192
		v193.Anchored = true
		v193.CanCollide = false
		v193.CanQuery = false
		v193.CanTouch = false
		v193.CastShadow = false
		v193.Massless = true
		v193.Parent = v179
		v193.Shape = Enum.PartType.Cylinder
		local v194 = CFrame.identity
		local v195 = v182.radius
		local v196 = v182.front
		local v197 = p177.movers
		table.insert(v197, {
			["part"] = v193,
			["c"] = v186,
			["sub"] = v194,
			["r"] = v195,
			["front"] = v196
		})
		for _, v198 in v_u_132.spokes(v182.radius) do
			local v199 = CFrame.new(v182.side * (v182.width / 2 + 0.03), 0, 0) * CFrame.Angles(v198.angle, 0, 0)
			local v200 = v198.length
			local v201 = v198.width
			local v202 = Vector3.new(0.08, v200, v201)
			local v203 = v187 * v199
			local v204 = Enum.Material.Metal
			local v205 = Instance.new("Part")
			v205.Name = "FxSpoke"
			v205.Size = v202
			v205.CFrame = v203
			v205.Color = v181
			v205.Material = v204
			v205.Anchored = true
			v205.CanCollide = false
			v205.CanQuery = false
			v205.CanTouch = false
			v205.CastShadow = false
			v205.Massless = true
			v205.Parent = v179
			local v206 = v182.radius
			local v207 = v182.front
			local v208 = p177.movers
			table.insert(v208, {
				["part"] = v205,
				["c"] = v186,
				["sub"] = v199,
				["r"] = v206,
				["front"] = v207
			})
		end
		p177.wheelCount = p177.wheelCount + 1
	end
	p177.mode = "fallback"
end
local function v_u_219(p210, p211, p212, p213) -- name: findBlock
	-- upvalues: (copy) v_u_141, (copy) v_u_132
	for _, v214 in p211 do
		if v214.part.Transparency >= 1 or not v_u_141(v214.part, p213) then
			continue
		end
		local v215 = v214.rel.Position
		local v216 = v_u_132.wheelBlock(v214.ext, {
			["x"] = v215.X,
			["y"] = v215.Y,
			["z"] = v215.Z
		}, p212, true)
		if not v216 then
			continue
		end
		local v217 = p210.hidden
		local v218 = {
			["part"] = v214.part,
			["transparency"] = v214.part.Transparency
		}
		table.insert(v217, v218)
		v214.part.Transparency = 1
		return v216
	end
	return nil
end
local function v_u_230(_, p220, p221) -- name: findLamps
	local v222 = {}
	for _, v223 in p220 do
		local v224 = string.lower(v223.part.Name)
		local v225
		if p221 == "head" then
			v225 = string.find(v224, "headlight", 1, true) or string.find(v224, "headlamp", 1, true)
		else
			v225 = string.find(v224, "taillight", 1, true) or (string.find(v224, "brakelight", 1, true) or string.find(v224, "tail_light", 1, true))
		end
		if not v225 then
			continue
		end
		local v226 = v223.ext.x
		local v227 = v223.ext.y
		local v228 = v223.ext.z
		if math.max(v226, v227, v228) >= 3.5 or v223.part.Transparency >= 1 then
			continue
		end
		local v229 = {
			["part"] = nil,
			["found"] = true,
			["color"] = nil,
			["material"] = nil,
			["transparency"] = nil,
			["part"] = v223.part,
			["color"] = v223.part.Color,
			["material"] = v223.part.Material,
			["transparency"] = v223.part.Transparency
		}
		table.insert(v222, v229)
	end
	return v222
end
local function v_u_266(p_u_231, p232, p_u_233, p_u_234) -- name: measureSurfaces
	-- upvalues: (copy) v_u_132
	local v_u_235 = {}
	local v_u_236 = {}
	local v_u_237 = {}
	for _, v238 in p232 do
		if v238.part.Transparency >= 0.2 then
			continue
		end
		local v239 = v238.part
		table.insert(v_u_235, v239)
	end
	if #v_u_235 == 0 then
		return v_u_237
	end
	local function v264()
		-- upvalues: (copy) v_u_235, (copy) v_u_236, (copy) p_u_233, (copy) p_u_234, (copy) p_u_231, (ref) v_u_132, (copy) v_u_237
		for _, v240 in v_u_235 do
			local v241 = v_u_236
			local v242 = { v240, v240.CanQuery }
			table.insert(v241, v242)
			v240.CanQuery = true
		end
		local v243 = RaycastParams.new()
		v243.FilterType = Enum.RaycastFilterType.Include
		v243.FilterDescendantsInstances = v_u_235
		local v244 = p_u_233.maxZ - p_u_233.minZ
		for v245, v246 in p_u_234 do
			local v247 = {}
			for v248, v249 in { -1, 0, 1 } do
				local v250 = {}
				for _, v251 in { -1, 0, 1 } do
					local v252
					if v246.dir < 0 then
						v252 = p_u_233.minZ - 4
					else
						v252 = p_u_233.maxZ + 4
					end
					local v253 = p_u_231
					local v254 = v246.x + v249 * v246.hw
					local v255 = v246.y + v251 * v246.hh
					local v256 = v253:PointToWorldSpace((Vector3.new(v254, v255, v252)))
					local v257 = p_u_231
					local v258 = -v246.dir * (v244 + 8)
					local v259 = v257:VectorToWorldSpace((Vector3.new(0, 0, v258)))
					local v260 = workspace:Raycast(v256, v259, v243)
					if not v260 then
						continue
					end
					local v261 = p_u_231:PointToObjectSpace(v260.Position).Z
					table.insert(v250, v261)
				end
				v247[v248] = v_u_132.surfaceZ(v250, v246.dir)
			end
			local v262, v263 = v_u_132.fitSurface(v247[1], v247[2], v247[3], v246.hw, v246.dir)
			v_u_237[v245] = v262 and {
				["z"] = v262,
				["k"] = v263
			} or false
		end
	end
	pcall(v264)
	for _, v_u_265 in v_u_236 do
		pcall(function()
			-- upvalues: (copy) v_u_265
			v_u_265[1].CanQuery = v_u_265[2]
		end)
	end
	return v_u_237
end
local function v_u_322(p267, p268, p269, p270) -- name: buildLamps
	-- upvalues: (copy) v_u_230, (copy) v_u_266, (copy) v_u_132
	local v271 = p267.folder
	local v272 = p268.maxX - p268.minX
	local v273 = p268.maxY - p268.minY
	local v274 = (p268.minX + p268.maxX) / 2
	p267.head = v_u_230(p270, p269, "head")
	p267.tail = v_u_230(p270, p269, "tail")
	local v275 = p268.minY + 0.54 * v273
	local v276 = p268.minY + 0.585 * v273
	local v277 = 0.34 * v272
	local v278 = 0.39 * v272
	local v279 = {}
	if #p267.head == 0 then
		for _, v280 in { -1, 1 } do
			local v281 = {
				["x"] = nil,
				["y"] = nil,
				["hw"] = 0.5,
				["hh"] = 0.2750000059604645,
				["dir"] = -1,
				["x"] = v274 + v280 * v277,
				["y"] = v275
			}
			table.insert(v279, v281)
		end
	end
	if #p267.tail == 0 then
		for _, v282 in { -1, 1 } do
			local v283 = {
				["x"] = nil,
				["y"] = nil,
				["hw"] = 0.25,
				["hh"] = 0.550000011920929,
				["dir"] = 1,
				["x"] = v274 + v282 * v278,
				["y"] = v276
			}
			table.insert(v279, v283)
		end
	end
	local v284 = #v279 <= 0 and {} or v_u_266(p267.pivot, p269, p268, v279)
	local v285 = 0
	p267.lensZ = {
		["head"] = nil,
		["tail"] = nil,
		["measured"] = 0,
		["head"] = {},
		["tail"] = {}
	}
	if #p267.head == 0 then
		for v286, v287 in { -1, 1 } do
			v285 = v285 + 1
			local v288 = v284[v285]
			local v289
			if v288 then
				v289 = v288.z
			else
				v289 = nil
			end
			local v290, v291, v292
			if v288 then
				v290, v291, v292 = v_u_132.lensPose(v288.k, -1, 0.25, nil)
			else
				v292 = 0
				v290 = 0
				v291 = 0
			end
			local v293
			if v289 then
				v293 = v289 + v292
			else
				v293 = p268.minZ + 0.45
			end
			p267.lensZ.head[v286] = v289
			if v289 then
				local v294 = p267.lensZ
				v294.measured = v294.measured + 1
			end
			local v295 = p267.pivot * CFrame.new(v274 + v287 * v277 + v291, v275, v293) * CFrame.Angles(0, v290, 0)
			local v296 = Color3.fromRGB(v_u_132.WARM[1], v_u_132.WARM[2], v_u_132.WARM[3])
			local v297 = Enum.Material.Neon
			local v298 = Instance.new("Part")
			v298.Name = "FxHeadLens"
			v298.Size = Vector3.new(1, 0.55, 0.25)
			v298.CFrame = v295
			v298.Color = v296
			v298.Material = v297
			v298.Anchored = true
			v298.CanCollide = false
			v298.CanQuery = false
			v298.CanTouch = false
			v298.CastShadow = false
			v298.Massless = true
			v298.Parent = v271
			v298.Transparency = 1
			local v299 = p267.head
			table.insert(v299, {
				["part"] = nil,
				["found"] = false,
				["part"] = v298
			})
		end
	end
	if #p267.tail == 0 then
		for v300, v301 in { -1, 1 } do
			v285 = v285 + 1
			local v302 = v284[v285]
			local v303
			if v302 then
				v303 = v302.z
			else
				v303 = nil
			end
			local v304, v305, v306
			if v302 then
				v304, v305, v306 = v_u_132.lensPose(v302.k, 1, 0.20000000298023224, nil)
			else
				v306 = 0
				v304 = 0
				v305 = 0
			end
			local v307
			if v303 then
				v307 = v303 + v306
			else
				v307 = p268.maxZ - 1.19
			end
			p267.lensZ.tail[v300] = v303
			if v303 then
				local v308 = p267.lensZ
				v308.measured = v308.measured + 1
			end
			local v309 = p267.pivot * CFrame.new(v274 + v301 * v278 + v305, v276, v307) * CFrame.Angles(0, v304, 0)
			local v310 = Color3.fromRGB(170, 18, 16)
			local v311 = Enum.Material.Neon
			local v312 = Instance.new("Part")
			v312.Name = "FxTailLens"
			v312.Size = Vector3.new(0.5, 1.1, 0.2)
			v312.CFrame = v309
			v312.Color = v310
			v312.Material = v311
			v312.Anchored = true
			v312.CanCollide = false
			v312.CanQuery = false
			v312.CanTouch = false
			v312.CastShadow = false
			v312.Massless = true
			v312.Parent = v271
			v312.Transparency = 1
			local v313 = p267.tail
			table.insert(v313, {
				["part"] = nil,
				["found"] = false,
				["part"] = v312
			})
		end
	end
	for _, v314 in { -1, 1 } do
		local v315 = p267.lensZ and p267.lensZ.head[v314 < 0 and 1 or 2] or p268.minZ
		local v316 = p267.pivot * CFrame.new(v274 + v314 * v277, v275, v315 - 0.2)
		local v317 = Color3.new(0, 0, 0)
		local v318 = Enum.Material.SmoothPlastic
		local v319 = Instance.new("Part")
		v319.Name = "FxBeamAnchor"
		v319.Size = Vector3.new(0.2, 0.2, 0.2)
		v319.CFrame = v316
		v319.Color = v317
		v319.Material = v318
		v319.Anchored = true
		v319.CanCollide = false
		v319.CanQuery = false
		v319.CanTouch = false
		v319.CastShadow = false
		v319.Massless = true
		v319.Parent = v271
		v319.Transparency = 1
		local v320 = Instance.new("SpotLight")
		v320.Name = "FxBeam"
		v320.Face = Enum.NormalId.Front
		v320.Range = v_u_132.BEAM_RANGE
		v320.Angle = v_u_132.BEAM_ANGLE
		v320.Brightness = 0
		v320.Shadows = false
		v320.Enabled = false
		v320.Color = Color3.fromRGB(v_u_132.WARM[1], v_u_132.WARM[2], v_u_132.WARM[3])
		v320.Parent = v319
		local v321 = p267.beams
		table.insert(v321, v320)
	end
end
function v_u_132.attach(p323) -- name: attach
	-- upvalues: (copy) v_u_176, (copy) v_u_132, (copy) v_u_141, (copy) v_u_219, (copy) v_u_209, (copy) v_u_322
	local v324 = p323:GetPivot()
	local v325 = Instance.new("Folder")
	v325.Name = "PickupFx"
	local v326 = {
		["model"] = nil,
		["pivot"] = nil,
		["folder"] = nil,
		["movers"] = nil,
		["hidden"] = nil,
		["wheelCount"] = 0,
		["mode"] = "none",
		["head"] = nil,
		["tail"] = nil,
		["beams"] = nil,
		["steer"] = 0,
		["lastYaw"] = nil,
		["lastDist"] = nil,
		["wheelbase"] = 11,
		["applied"] = "",
		["model"] = p323,
		["pivot"] = v324,
		["folder"] = v325,
		["movers"] = {},
		["hidden"] = {},
		["head"] = {},
		["tail"] = {},
		["beams"] = {}
	}
	local v327, v328 = v_u_176(p323, v324)
	v326.box = v327
	local v329 = {}
	local v330 = {}
	for v331, v332 in v328 do
		local v333 = v_u_132.wheelShape(v332.ext, {
			["x"] = v332.rel.Position.X,
			["y"] = v332.rel.Position.Y,
			["z"] = v332.rel.Position.Z
		}, v327, (v_u_141(v332.part, p323)))
		if not v333 then
			continue
		end
		local v334 = {
			["key"] = v331,
			["r"] = v333,
			["x"] = v332.rel.Position.X,
			["y"] = v332.rel.Position.Y,
			["z"] = v332.rel.Position.Z
		}
		table.insert(v329, v334)
		v330[v331] = v332
	end
	local v335 = v_u_132.pickWheels(v329)
	v325.Parent = p323
	if v335 then
		local v336 = (1 / 0)
		local v337 = (-1 / 0)
		for _, v338 in v335 do
			local v339 = v330[v338.key]
			local v340 = v339.part
			local v341 = v339.rel.Position
			local v342 = v339.rel.Rotation
			local v343 = v338.r
			local v344 = v338.front
			local v345 = v326.movers
			table.insert(v345, {
				["part"] = v340,
				["c"] = v341,
				["sub"] = v342,
				["r"] = v343,
				["front"] = v344
			})
			v326.wheelCount = v326.wheelCount + 1
			local v346 = v339.rel.Position.Z
			v336 = math.min(v336, v346)
			local v347 = v339.rel.Position.Z
			v337 = math.max(v337, v347)
		end
		local v348 = v337 - v336
		v326.wheelbase = math.max(v348, 4)
		v326.mode = "real"
	else
		local v349 = v_u_219(v326, v328, v327, p323)
		if v349 then
			v_u_209(v326, v349)
			v326.mode = "block"
			v326.wheelbase = v349[#v349].z - v349[1].z
		else
			v_u_209(v326, v_u_132.fallbackWheels(v327))
			v326.wheelbase = (v327.maxZ - v327.minZ) * 0.61
		end
	end
	v_u_322(v326, v327, v328, p323)
	return v326
end
local function v_u_371(p350, p351) -- name: setLamps
	-- upvalues: (copy) v_u_132
	local v352 = string.format
	local v353 = p351.on and 1 or 0
	local v354 = p351.headTransparency
	local v355 = p351.tailTransparency
	local v356 = p351.tailR
	local v357 = v352("%d/%.2f/%.2f/%d", v353, v354, v355, (math.floor(v356)))
	if v357 ~= p350.applied then
		p350.applied = v357
		local v358 = Color3.fromRGB(p351.tailR, p351.tailG, p351.tailB)
		local v359 = Color3.fromRGB(v_u_132.WARM[1], v_u_132.WARM[2], v_u_132.WARM[3])
		for _, v360 in p350.head do
			if v360.found then
				local v361 = v360.part
				local v362
				if p351.on then
					v362 = Enum.Material.Neon
				else
					v362 = v360.material
				end
				v361.Material = v362
				local v363 = v360.part
				local v364
				if p351.on then
					v364 = v359
				else
					v364 = v360.color
				end
				v363.Color = v364
				v360.part.Transparency = v360.transparency
			else
				v360.part.Transparency = p351.headTransparency
			end
		end
		for _, v365 in p350.tail do
			if v365.found then
				local v366 = v365.part
				local v367
				if p351.on then
					v367 = Enum.Material.Neon
				else
					v367 = v365.material
				end
				v366.Material = v367
				local v368 = v365.part
				local v369
				if p351.on then
					v369 = v358
				else
					v369 = v365.color
				end
				v368.Color = v369
				v365.part.Transparency = v365.transparency
			else
				v365.part.Transparency = p351.tailTransparency
				v365.part.Color = v358
			end
		end
		for _, v370 in p350.beams do
			v370.Enabled = p351.on
			v370.Brightness = p351.beam
		end
	end
end
function v_u_132.update(p372, p373, p374, p375, p376) -- name: update
	-- upvalues: (copy) v_u_371, (copy) v_u_132
	if p372 and p372.folder then
		local v_u_377 = nil
		local v_u_378 = nil
		if p376 then
			v_u_377 = p376.clock
			v_u_378 = p376.timeName
		else
			pcall(function()
				-- upvalues: (ref) v_u_377
				v_u_377 = game:GetService("Lighting").ClockTime
			end)
			if v_u_377 == nil then
				pcall(function()
					-- upvalues: (ref) v_u_378
					local v379 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
					if v379 then
						v379 = v379:FindFirstChild("Raid")
					end
					if v379 then
						v379 = v379:GetAttribute("TimeOfDay")
					end
					v_u_378 = v379
				end)
			end
		end
		v_u_371(p372, v_u_132.lampState(v_u_132.level(v_u_132.darkness(v_u_377, v_u_378), p374.lit or 0), p374.brake == true))
		local v380 = p374.dist or 0
		local v381 = p374.yaw or 0
		if p372.lastDist ~= nil and p375 > 0 then
			local v382 = v_u_132.steerAngle((v381 - p372.lastYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793, v380 - p372.lastDist, p372.wheelbase)
			local v383 = p372.steer
			local v384 = v382 - p372.steer
			local v385 = p375 * 10
			p372.steer = v383 + v384 * math.min(1, v385)
		end
		p372.lastDist = v380
		p372.lastYaw = v381
		for _, v386 in p372.movers do
			local v387 = not v386.front and 0 or p372.steer
			v386.part.CFrame = p373 * CFrame.new(v386.c) * CFrame.Angles(0, v387, 0) * CFrame.Angles(v_u_132.wheelAngle(v380, v386.r), 0, 0) * v386.sub
		end
	end
end
function v_u_132.destroy(p_u_388) -- name: destroy
	-- upvalues: (copy) v_u_371, (copy) v_u_132
	if p_u_388 then
		if p_u_388.folder then
			p_u_388.applied = ""
			local v389 = v_u_371
			local v390 = v_u_132.lampState
			pcall(v389, p_u_388, v390(0, false))
			for _, v_u_391 in p_u_388.hidden do
				pcall(function()
					-- upvalues: (copy) v_u_391
					v_u_391.part.Transparency = v_u_391.transparency
				end)
			end
			p_u_388.hidden = {}
			pcall(function()
				-- upvalues: (copy) p_u_388
				p_u_388.folder:Destroy()
			end)
			p_u_388.folder = nil
		end
		p_u_388.movers = {}
		p_u_388.head = {}
		p_u_388.tail = {}
		p_u_388.beams = {}
	end
end
return v_u_132