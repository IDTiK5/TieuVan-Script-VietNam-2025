-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutTrophy

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = {}
local v_u_4 = {
	"JAN",
	"FEB",
	"MAR",
	"APR",
	"MAY",
	"JUN",
	"JUL",
	"AUG",
	"SEP",
	"OCT",
	"NOV",
	"DEC"
}
local v_u_5 = Color3.fromHex("9C7A3C")
local v_u_6 = Color3.fromHex("6E5527")
local v_u_7 = Color3.fromHex("1E1709")
local v_u_8 = Color3.fromRGB(8, 9, 11)
local v_u_9 = {
	["val_watch_gold"] = "A rare valuable. Best odds in safes and high-end stashes.",
	["val_jewelry"] = "Valuables: homes, safes and jewellery cases.",
	["val_gpu"] = "Very rare. Safes, desks and high-end valuables.",
	["quest_mayorkey_safe"] = "Offices: desks, lockers and cabinets.",
	["keycard_military"] = "The Surgeon always carries one.",
	["tape_08"] = "Both bosses carry the last disc.",
	["rifle_hunting"] = "Civilian gun loot, e.g. the gun store.",
	["vest_military"] = "Military armor loot. Sergeant Hale wears one.",
	["helmet_military"] = "Military armor loot.",
	["val_camera"] = "Valuables and electronics."
}
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local function v_u_18(p14) -- name: fmtDate
	-- upvalues: (copy) v_u_4
	if type(p14) ~= "number" or p14 <= 0 then
		return ""
	end
	local v15 = os.date
	local v16, v17 = pcall(v15, "*t", p14)
	return (not v16 or type(v17) ~= "table") and "" or ("%02d %s %d"):format(v17.day, v_u_4[v17.month] or "?", v17.year)
end
function v_u_3.info(p19, p20) -- name: info
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_10, (copy) v_u_9
	local v21 = p20 or {}
	if v21.kind ~= "stash" then
		if v21.kind == "plate" or string.sub(p19, 1, 6) == "plate_" then
			local v22 = v_u_11
			if not v22 then
				local v_u_23 = "Items"
				local function v24()
					-- upvalues: (ref) v_u_2, (copy) v_u_23
					return require((v_u_2:WaitForChild(v_u_23, 5)))
				end
				local v25
				v25, v22 = pcall(v24)
				if not v25 then
					v22 = nil
				end
			end
			v_u_11 = v22
			local v26 = v_u_12
			if not v26 then
				local v_u_27 = "HideoutModules"
				local function v28()
					-- upvalues: (ref) v_u_2, (copy) v_u_27
					return require((v_u_2:WaitForChild(v_u_27, 5)))
				end
				local v29
				v29, v26 = pcall(v28)
				if not v29 then
					v26 = nil
				end
			end
			v_u_12 = v26
			local v30 = v_u_13
			if not v30 then
				local v_u_31 = "Factions"
				local function v32()
					-- upvalues: (ref) v_u_2, (copy) v_u_31
					return require((v_u_2:WaitForChild(v_u_31, 5)))
				end
				local v33
				v33, v30 = pcall(v32)
				if not v33 then
					v30 = nil
				end
			end
			v_u_13 = v30
			local v34 = v21.faction or (string.match(p19, "^plate_%d+_(.+)$") or "")
			local v35
			if v_u_13 and (v_u_13.get and v_u_13.get(v34)) then
				v35 = v_u_13.get(v34).name
			else
				v35 = string.upper(v34)
			end
			local v36
			if v21.week and (v_u_13 and v_u_13.displayWeek) then
				v36 = v_u_13.displayWeek(v21.week) or nil
			else
				v36 = nil
			end
			return {
				["kind"] = "plate",
				["name"] = nil,
				["short"] = nil,
				["week"] = nil,
				["faction"] = nil,
				["desc"] = "Champion plate of a weekly faction competition. Your faction had the best average haul that week.",
				["hint"] = "Win a faction week (FACTIONS in the menu) to earn a plate.",
				["rarity"] = 5,
				["name"] = v21.text or ("%s Champions"):format(v35),
				["short"] = v35,
				["week"] = v36,
				["faction"] = v34
			}
		end
		if string.sub(p19, 1, 7) == "zombie_" then
			local v37 = string.sub(p19, 8)
			local v38 = v_u_10.MenuBestiary
			local v39
			if v38 == nil then
				local v_u_40 = "MenuBestiary"
				local v41
				v41, v39 = pcall(function()
					-- upvalues: (copy) v_u_40
					local v42 = script.Parent
					if v42 then
						v42 = script.Parent:FindFirstChild(v_u_40)
					end
					if v42 and v42:IsA("ModuleScript") then
						return require(v42)
					else
						return nil
					end
				end)
				v_u_10.MenuBestiary = v41 and v39 and v39 or false
				if not v41 then
					v39 = nil
				end
			else
				v39 = v38 or nil
			end
			local v43
			if v39 and v39.info then
				v43 = v39.info(v37)
			else
				v43 = nil
			end
			local v44 = {
				["kind"] = "boss",
				["name"] = nil,
				["short"] = nil,
				["desc"] = nil,
				["hint"] = nil,
				["rarity"] = 5
			}
			local v45
			if v43 and (v43.name and v43.name ~= v37) then
				v45 = v43.name
			else
				v45 = string.upper((string.gsub(v37, "_", " ")))
			end
			v44.name = v45
			local v46
			if v43 and v43.short then
				v46 = v43.short
			else
				v46 = string.upper(v37)
			end
			v44.short = v46
			v44.desc = (not v43 or (not v43.desc or v43.desc == "")) and "A boss trophy." or v43.desc
			v44.hint = (not v43 or (not v43.where or v43.where == "")) and "Hunt it down in a raid." or v43.where
			return v44
		end
		local v47 = v_u_11
		if not v47 then
			local v_u_48 = "Items"
			local function v49()
				-- upvalues: (ref) v_u_2, (copy) v_u_48
				return require((v_u_2:WaitForChild(v_u_48, 5)))
			end
			local v50
			v50, v47 = pcall(v49)
			if not v50 then
				v47 = nil
			end
		end
		v_u_11 = v47
		local v51 = v_u_12
		if not v51 then
			local v_u_52 = "HideoutModules"
			local function v53()
				-- upvalues: (ref) v_u_2, (copy) v_u_52
				return require((v_u_2:WaitForChild(v_u_52, 5)))
			end
			local v54
			v54, v51 = pcall(v53)
			if not v54 then
				v51 = nil
			end
		end
		v_u_12 = v51
		local v55 = v_u_13
		if not v55 then
			local v_u_56 = "Factions"
			local function v57()
				-- upvalues: (ref) v_u_2, (copy) v_u_56
				return require((v_u_2:WaitForChild(v_u_56, 5)))
			end
			local v58
			v58, v55 = pcall(v57)
			if not v58 then
				v55 = nil
			end
		end
		v_u_13 = v55
		local v59
		if v_u_11 then
			local v60 = v_u_11.get
			if type(v60) == "function" then
				local v61 = v_u_11.get
				local v62
				v62, v59 = pcall(v61, p19)
				if not v62 then
					v59 = nil
				end
			else
				v59 = nil
			end
		else
			v59 = nil
		end
		local v63 = {
			["kind"] = "find",
			["name"] = nil,
			["short"] = nil,
			["desc"] = nil,
			["hint"] = nil,
			["rarity"] = nil
		}
		local v64
		if v59 and v59.name then
			v64 = v59.name
		else
			v64 = p19
		end
		v63.name = v64
		local v65
		if v59 and v59.short then
			v65 = v59.short
		else
			v65 = string.upper(p19)
		end
		v63.short = v65
		v63.desc = not (v59 and v59.desc) and "" or v59.desc
		v63.hint = v_u_9[p19] or "Find it in a raid."
		v63.rarity = not v59 or v59.shown or (v59.rarity or 1)
		return v63
	end
	local v66 = v21.id
	local v67 = tostring(v66)
	local v68 = v_u_11
	if not v68 then
		local v_u_69 = "Items"
		local function v70()
			-- upvalues: (ref) v_u_2, (copy) v_u_69
			return require((v_u_2:WaitForChild(v_u_69, 5)))
		end
		local v71
		v71, v68 = pcall(v70)
		if not v71 then
			v68 = nil
		end
	end
	v_u_11 = v68
	local v72 = v_u_12
	if not v72 then
		local v_u_73 = "HideoutModules"
		local function v74()
			-- upvalues: (ref) v_u_2, (copy) v_u_73
			return require((v_u_2:WaitForChild(v_u_73, 5)))
		end
		local v75
		v75, v72 = pcall(v74)
		if not v75 then
			v72 = nil
		end
	end
	v_u_12 = v72
	local v76 = v_u_13
	if not v76 then
		local v_u_77 = "Factions"
		local function v78()
			-- upvalues: (ref) v_u_2, (copy) v_u_77
			return require((v_u_2:WaitForChild(v_u_77, 5)))
		end
		local v79
		v79, v76 = pcall(v78)
		if not v79 then
			v76 = nil
		end
	end
	v_u_13 = v76
	local v80
	if v_u_11 then
		local v81 = v_u_11.get
		if type(v81) == "function" then
			local v82 = v_u_11.get
			local v83
			v83, v80 = pcall(v82, v67)
			if not v83 then
				v80 = nil
			end
		else
			v80 = nil
		end
	else
		v80 = nil
	end
	local v84 = v21.name
	if v84 then
		p19 = v84
	elseif v80 then
		p19 = v80.name or p19
	end
	local v85 = tostring(p19)
	local v86 = {
		["kind"] = "stash",
		["id"] = nil,
		["uid"] = nil,
		["name"] = nil,
		["short"] = nil,
		["desc"] = nil,
		["hint"] = "",
		["rarity"] = nil,
		["value"] = nil,
		["fir"] = nil,
		["id"] = v21.id,
		["uid"] = v21.uid,
		["name"] = v85
	}
	local v87
	if v80 and v80.short then
		v87 = v80.short
	else
		v87 = string.upper(v85)
	end
	v86.short = v87
	v86.desc = not (v80 and v80.desc) and "" or v80.desc
	v86.rarity = not v80 or v80.shown or (v80.rarity or 1)
	v86.value = v21.value
	v86.fir = v21.fir == true
	return v86
end
function v_u_3.data(p88) -- name: data
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13
	local v89 = p88 or {}
	local v90 = 0
	local v91 = v89.effects
	if v91 then
		v91 = v89.effects.trophySlots
	end
	local v92 = tonumber(v91) or 0
	local v93 = math.floor(v92)
	local v94 = math.max(v90, v93)
	local v95 = v89.trophyWall
	local v96 = {}
	local v97 = {}
	local v98 = {}
	local v99 = {}
	local v100 = {}
	local v101 = false
	if type(v95) == "table" then
		local v102 = v95.earned
		if type(v102) == "table" then
			local v103 = v95.slots
			local v104 = tonumber(v103) or v94
			local v105 = math.floor(v104)
			v94 = math.max(0, v105)
			for _, v106 in v95.earned do
				if type(v106) ~= "table" then
					continue
				end
				local v107 = v106.key
				if type(v107) ~= "string" then
					continue
				end
				table.insert(v97, v106)
				v98[v106.key] = v106
			end
			local v108 = v95.items
			if type(v108) == "table" then
				for v109, v110 in v95.items do
					if type(v109) ~= "string" or type(v110) ~= "table" then
						continue
					end
					local v111 = v110.id
					if type(v111) ~= "string" then
						continue
					end
					local v112 = v110.uid
					if type(v112) ~= "string" then
						continue
					end
					v98[v109] = {
						["key"] = nil,
						["kind"] = "stash",
						["id"] = nil,
						["uid"] = nil,
						["name"] = nil,
						["value"] = nil,
						["fir"] = nil,
						["key"] = v109,
						["id"] = v110.id,
						["uid"] = v110.uid,
						["name"] = v110.name,
						["value"] = v110.value,
						["fir"] = v110.fir == true
					}
				end
			end
			local v113 = v95.pick
			for _, v114 in type(v113) ~= "table" and {} or v95.pick do
				if type(v114) ~= "table" then
					continue
				end
				local v115 = v114.uid
				if type(v115) ~= "string" then
					continue
				end
				local v116 = v114.id
				if type(v116) ~= "string" then
					continue
				end
				table.insert(v99, v114)
			end
			local v117 = v95.waiting
			for _, v118 in type(v117) ~= "table" and {} or v95.waiting do
				if type(v118) ~= "table" then
					continue
				end
				local v119 = v118.uid
				if type(v119) ~= "string" then
					continue
				end
				local v120 = v118.id
				if type(v120) ~= "string" then
					continue
				end
				table.insert(v100, v118)
			end
			v101 = v95.hang == true
			for v121 = 1, v94 do
				local v122 = v95.placed
				local v123 = type(v122) == "table" and (v95.placed[v121] or "") or ""
				v96[v121] = (type(v123) ~= "string" or not v98[v123]) and "" or v123
			end
			return {
				["slots"] = v94,
				["placed"] = v96,
				["earned"] = v97,
				["byKey"] = v98,
				["legacy"] = type(v95) ~= "table",
				["pick"] = v99,
				["waiting"] = v100,
				["hang"] = v101
			}
		end
	end
	local v124 = v89.trophies
	local v125 = 0
	for _, v145 in type(v124) ~= "table" and {} or v89.trophies do
		if type(v145) ~= "string" then
			continue
		end
		local v127 = v_u_11
		if not v127 then
			local v_u_128 = "Items"
			local function v129()
				-- upvalues: (ref) v_u_2, (copy) v_u_128
				return require((v_u_2:WaitForChild(v_u_128, 5)))
			end
			local v130
			v130, v127 = pcall(v129)
			if not v130 then
				v127 = nil
			end
		end
		v_u_11 = v127
		local v131 = v_u_12
		if not v131 then
			local v_u_132 = "HideoutModules"
			local function v133()
				-- upvalues: (ref) v_u_2, (copy) v_u_132
				return require((v_u_2:WaitForChild(v_u_132, 5)))
			end
			local v134
			v134, v131 = pcall(v133)
			if not v134 then
				v131 = nil
			end
		end
		v_u_12 = v131
		local v135 = v_u_13
		if not v135 then
			local v_u_136 = "Factions"
			local function v137()
				-- upvalues: (ref) v_u_2, (copy) v_u_136
				return require((v_u_2:WaitForChild(v_u_136, 5)))
			end
			local v138
			v138, v135 = pcall(v137)
			if not v138 then
				v135 = nil
			end
		end
		v_u_13 = v135
		local v139
		if v_u_11 then
			local v140 = v_u_11.get
			if type(v140) == "function" then
				local v141 = v_u_11.get
				local v142
				v142, v139 = pcall(v141, v145)
				if not v142 then
					v139 = nil
				end
			else
				v139 = nil
			end
		else
			v139 = nil
		end
		local v143
		if v139 or string.sub(v145, 1, 7) == "zombie_" then
			v143 = {
				["key"] = v145,
				["kind"] = string.sub(v145, 1, 7) == "zombie_" and "boss" or "find"
			}
		else
			local v144 = "plate_old_" .. v145
			local v145 = v144
			v143 = {
				["key"] = nil,
				["kind"] = "plate",
				["text"] = nil,
				["key"] = v144,
				["text"] = v145
			}
		end
		table.insert(v97, v143)
		v98[v145] = v143
		v125 = v125 + 1
		if v125 > v94 then
			continue
		end
		v96[v125] = v145
	end
	for v146 = 1, v94 do
		v96[v146] = v96[v146] or ""
	end
	return {
		["slots"] = v94,
		["placed"] = v96,
		["earned"] = v97,
		["byKey"] = v98,
		["legacy"] = type(v95) ~= "table",
		["pick"] = v99,
		["waiting"] = v100,
		["hang"] = v101
	}
end
local v_u_147 = nil
local v_u_148 = 0
local v_u_149 = false
local v_u_150 = nil
local function v_u_156(p151) -- name: placedNow
	-- upvalues: (ref) v_u_147
	local v152 = v_u_147
	if v152 then
		local v153 = #v152.placed == #p151.placed
		if v153 then
			for v154, v155 in p151.placed do
				if v152.placed[v154] == v155 then
					continue
				end
				v153 = false
			end
		end
		if not v153 and os.clock() - v152.t <= 4 then
			return v152.placed
		end
		v_u_147 = nil
	end
	return p151.placed
end
function v_u_3.render(p157, p158, p159, p_u_160) -- name: render
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_10, (copy) v_u_1, (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_156, (ref) v_u_147, (ref) v_u_148, (ref) v_u_149, (ref) v_u_150, (copy) v_u_18
	local v161 = v_u_11
	if not v161 then
		local v_u_162 = "Items"
		local function v163()
			-- upvalues: (ref) v_u_2, (copy) v_u_162
			return require((v_u_2:WaitForChild(v_u_162, 5)))
		end
		local v164
		v164, v161 = pcall(v163)
		if not v164 then
			v161 = nil
		end
	end
	v_u_11 = v161
	local v165 = v_u_12
	if not v165 then
		local v_u_166 = "HideoutModules"
		local function v167()
			-- upvalues: (ref) v_u_2, (copy) v_u_166
			return require((v_u_2:WaitForChild(v_u_166, 5)))
		end
		local v168
		v168, v165 = pcall(v167)
		if not v168 then
			v165 = nil
		end
	end
	v_u_12 = v165
	local v169 = v_u_13
	if not v169 then
		local v_u_170 = "Factions"
		local function v171()
			-- upvalues: (ref) v_u_2, (copy) v_u_170
			return require((v_u_2:WaitForChild(v_u_170, 5)))
		end
		local v172
		v172, v169 = pcall(v171)
		if not v172 then
			v169 = nil
		end
	end
	v_u_13 = v169
	local v_u_173 = p_u_160.HushUI
	if not v_u_173 then
		local v174 = v_u_10.HushUI
		if v174 == nil then
			local v_u_175 = "HushUI"
			local v176
			v176, v_u_173 = pcall(function()
				-- upvalues: (copy) v_u_175
				local v177 = script.Parent
				if v177 then
					v177 = script.Parent:FindFirstChild(v_u_175)
				end
				if v177 and v177:IsA("ModuleScript") then
					return require(v177)
				else
					return nil
				end
			end)
			v_u_10.HushUI = v176 and v_u_173 and v_u_173 or false
			if not v176 then
				v_u_173 = nil
			end
		else
			v_u_173 = v174 or nil
		end
	end
	local v_u_178 = p_u_160.Theme
	if not v_u_178 then
		local v_u_179 = "Theme"
		local function v180()
			-- upvalues: (ref) v_u_2, (copy) v_u_179
			return require((v_u_2:WaitForChild(v_u_179, 5)))
		end
		local v181
		v181, v_u_178 = pcall(v180)
		if not v181 then
			v_u_178 = nil
		end
	end
	local v_u_182 = v_u_178.color
	local v183 = v_u_10.ItemIcons
	local v_u_184
	if v183 == nil then
		local v_u_185 = "ItemIcons"
		local v186
		v186, v_u_184 = pcall(function()
			-- upvalues: (copy) v_u_185
			local v187 = script.Parent
			if v187 then
				v187 = script.Parent:FindFirstChild(v_u_185)
			end
			if v187 and v187:IsA("ModuleScript") then
				return require(v187)
			else
				return nil
			end
		end)
		v_u_10.ItemIcons = v186 and v_u_184 and v_u_184 or false
		if not v186 then
			v_u_184 = nil
		end
	else
		v_u_184 = v183 or nil
	end
	local v_u_188 = v_u_1.LocalPlayer
	local v_u_189 = p_u_160.split == true
	local v_u_190 = Instance.new("Frame")
	v_u_190.Name = "TrophyBlock"
	v_u_190.BackgroundTransparency = 1
	v_u_190.Size = UDim2.new(1, -8, 0, 0)
	v_u_190.AutomaticSize = Enum.AutomaticSize.Y
	v_u_190.LayoutOrder = p158
	if not v_u_189 then
		v_u_173.layout(v_u_190, "v", 12)
	end
	v_u_190.Parent = p157
	local function v_u_195() -- name: fitHeight
		-- upvalues: (copy) v_u_190, (copy) v_u_178
		local v191 = v_u_190.Parent
		if v191 and v191:IsA("GuiObject") then
			local v192 = v_u_178.uiScale
			local v193 = type(v192) ~= "function" and 1 or v_u_178.uiScale()
			local v194 = v191.AbsoluteSize.Y / math.max(v193, 0.05)
			if v194 > 240 then
				return math.floor(v194) - 4
			end
		end
		return 520
	end
	local v_u_196 = not v_u_189 and 0 or v_u_195()
	if v_u_189 then
		v_u_190.AutomaticSize = Enum.AutomaticSize.None
		v_u_190.Size = UDim2.new(1, -8, 0, v_u_196)
	end
	local v_u_197 = v_u_3.data(p159)
	local v_u_198 = v_u_197.slots > 0
	local v_u_199 = v_u_189 and "on the right" or "below"
	local function v_u_228(p200, p201, p202, p203, p204) -- name: icon
		-- upvalues: (copy) v_u_184, (ref) v_u_11, (ref) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_182
		if v_u_184 then
			local v205 = v_u_11
			if not v205 then
				local v_u_206 = "Items"
				local function v207()
					-- upvalues: (ref) v_u_2, (copy) v_u_206
					return require((v_u_2:WaitForChild(v_u_206, 5)))
				end
				local v208
				v208, v205 = pcall(v207)
				if not v208 then
					v205 = nil
				end
			end
			v_u_11 = v205
			local v209 = v_u_12
			if not v209 then
				local v_u_210 = "HideoutModules"
				local function v211()
					-- upvalues: (ref) v_u_2, (copy) v_u_210
					return require((v_u_2:WaitForChild(v_u_210, 5)))
				end
				local v212
				v212, v209 = pcall(v211)
				if not v212 then
					v209 = nil
				end
			end
			v_u_12 = v209
			local v213 = v_u_13
			if not v213 then
				local v_u_214 = "Factions"
				local function v215()
					-- upvalues: (ref) v_u_2, (copy) v_u_214
					return require((v_u_2:WaitForChild(v_u_214, 5)))
				end
				local v216
				v216, v213 = pcall(v215)
				if not v216 then
					v213 = nil
				end
			end
			v_u_13 = v213
			local v217
			if v_u_11 then
				local v218 = v_u_11.get
				if type(v218) == "function" then
					local v219 = v_u_11.get
					local v220
					v220, v217 = pcall(v219, p201)
					if not v220 then
						v217 = nil
					end
				else
					v217 = nil
				end
			else
				v217 = nil
			end
			if v217 then
				local v221 = v_u_184.get
				local v222 = {
					["parent"] = nil,
					["size"] = nil,
					["position"] = nil,
					["zindex"] = 2,
					["parent"] = p200,
					["size"] = UDim2.new(1, -12, 0, p204),
					["position"] = UDim2.fromOffset(6, p203)
				}
				local v223, v_u_224 = pcall(v221, p201, false, v222)
				if not v223 or typeof(v_u_224) ~= "Instance" then
					return false
				end
				if p202 then
					v_u_224.ImageColor3 = v_u_182.muted
					v_u_224.ImageTransparency = 0.35
				end
				p200.Destroying:Connect(function()
					-- upvalues: (copy) v_u_224, (ref) v_u_184
					local function v225()
						-- upvalues: (ref) v_u_224
						v_u_224.ImageColor3 = Color3.new(1, 1, 1)
						v_u_224.ImageTransparency = 0
					end
					pcall(v225)
					local v226 = v_u_184.release
					local v227 = v_u_224
					pcall(v226, v227)
				end)
				return true
			end
		end
		return false
	end
	local function v_u_265(p229, p230, p231, p232, p233, p234) -- name: face
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_182, (copy) v_u_173, (ref) v_u_6, (ref) v_u_13, (ref) v_u_7, (ref) v_u_8, (copy) v_u_228
		local v235 = v_u_3.info(p230, p231)
		if v235.kind == "plate" then
			local v236 = math.min(46, p234)
			local v237 = Instance.new("Frame")
			v237.Name = "Plate"
			v237.BorderSizePixel = 0
			local v238
			if p232 then
				v238 = v_u_5
			else
				v238 = v_u_182.raised2
			end
			v237.BackgroundColor3 = v238
			v237.AnchorPoint = Vector2.new(0.5, 0)
			local v239 = UDim2.new
			local v240 = (p234 - v236) / 2
			v237.Position = v239(0.5, 0, 0, p233 + math.floor(v240))
			v237.Size = UDim2.new(1, -16, 0, v236)
			v237.ZIndex = 2
			local v241 = v_u_173.stroke
			local v242
			if p232 then
				v242 = v_u_6
			else
				v242 = v_u_182.line
			end
			v241(v237, v242)
			local v243 = Instance.new("Frame")
			v243.Name = "Stripe"
			v243.BorderSizePixel = 0
			local v244 = v_u_13 and v_u_13.get
			if v244 then
				v244 = v_u_13.get(v235.faction or "")
			end
			local v245
			if p232 and v244 then
				v245 = v244.color
			else
				v245 = v_u_182.line
			end
			v243.BackgroundColor3 = v245
			v243.Size = UDim2.new(1, 0, 0, 3)
			v243.ZIndex = 3
			v243.Parent = v237
			local v246
			if p232 then
				v246 = v_u_7
			else
				v246 = v_u_182.muted
			end
			v_u_173.label({
				["parent"] = nil,
				["name"] = "Week",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v237,
				["text"] = not (p232 and v235.week) and "WEEKLY" or ("WK %d"):format(v235.week),
				["color"] = v246,
				["size"] = UDim2.new(1, -10, 0, 12),
				["position"] = UDim2.fromOffset(5, 6)
			})
			v_u_173.label({
				["parent"] = nil,
				["name"] = "Faction",
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["position"] = nil,
				["zindex"] = 3,
				["parent"] = v237,
				["text"] = not p232 and "???" or v235.short,
				["color"] = v246,
				["size"] = UDim2.new(1, -8, 0, 18),
				["position"] = UDim2.fromOffset(4, 22)
			})
			v237.Parent = p229
			return
		elseif v235.kind == "boss" then
			local v247 = Instance.new("Frame")
			v247.Name = "Shield"
			v247.BorderSizePixel = 0
			local v248
			if p232 then
				v248 = v_u_182.dangerDeep
			else
				v248 = v_u_182.raised2
			end
			v247.BackgroundColor3 = v248
			v247.AnchorPoint = Vector2.new(0.5, 0)
			local v249 = p234 - 4
			local v250 = math.min(v249, 68)
			local v251 = UDim2.new
			local v252 = (p234 - v250) / 2
			v247.Position = v251(0.5, 0, 0, p233 + math.floor(v252))
			v247.Size = UDim2.fromOffset(math.min(52, p234), v250)
			v247.ZIndex = 2
			local v253 = v_u_173.stroke
			local v254
			if p232 then
				v254 = v_u_182.danger:Lerp(v_u_182.line, 0.4)
			else
				v254 = v_u_182.line
			end
			v253(v247, v254)
			local v255 = v_u_173.icon
			local v256 = "skull"
			local v257 = {
				["parent"] = nil,
				["size"] = 30,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 3,
				["parent"] = v247
			}
			local v258
			if p232 then
				v258 = v_u_182.text
			else
				v258 = v_u_8:Lerp(v_u_182.line, 0.5)
			end
			v257.color = v258
			v257.position = UDim2.fromScale(0.5, 0.5)
			v257.anchor = Vector2.new(0.5, 0.5)
			v255(v256, v257).Name = "Skull"
			v247.Parent = p229
		else
			local v259 = v_u_228
			if v235.kind == "stash" then
				local v260 = v235.id
				p230 = tostring(v260)
			end
			if not v259(p229, p230, not p232, p233, p234) then
				local v261 = v_u_173.icon
				local v262 = "loot"
				local v263 = {
					["parent"] = nil,
					["size"] = 28,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["zindex"] = 2,
					["parent"] = p229
				}
				local v264
				if p232 then
					v264 = v_u_182.text2
				else
					v264 = v_u_182.muted
				end
				v263.color = v264
				v263.position = UDim2.new(0.5, 0, 0, p233 + p234 / 2)
				v263.anchor = Vector2.new(0.5, 0.5)
				v261(v262, v263).Name = "Glyph"
			end
		end
	end
	local v_u_266 = {}
	local function v_u_267() end
	local function v_u_277(p268, p269) -- name: hangIn
		-- upvalues: (ref) v_u_156, (copy) v_u_197, (ref) v_u_147, (copy) p_u_160, (copy) v_u_173, (copy) v_u_190, (ref) v_u_267
		local v270 = v_u_156(v_u_197)
		local v271 = table.clone(v270)
		for v272, v273 in v271 do
			if v273 ~= p269 or p269 == "" then
				continue
			end
			v271[v272] = v271[p268] or ""
		end
		v271[p268] = p269
		v_u_147 = {
			["placed"] = v271,
			["t"] = os.clock()
		}
		local v274 = {
			["slot"] = p268,
			["key"] = p269
		}
		if p_u_160.act then
			p_u_160.act("trophySet", v274)
		end
		local v275 = v_u_173.sound
		local v276 = p269 == "" and "click" or "confirm"
		pcall(v275, v276)
		v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
	end
	local function v_u_283(p278, p279, p280, p281) -- name: tileButton
		-- upvalues: (copy) v_u_182, (copy) v_u_173
		local v282 = Instance.new("TextButton")
		v282.Name = p279
		v282.Text = ""
		v282.AutoButtonColor = false
		v282.BorderSizePixel = 0
		v282.BackgroundColor3 = v_u_182.raised
		v282.BackgroundTransparency = 0.15
		v282.Size = UDim2.fromOffset(80, p280)
		v282.LayoutOrder = p281
		v282.ClipsDescendants = true
		v282.Selectable = true
		v282.SelectionImageObject = v_u_173.selectionImage()
		v282.Parent = p278
		return v282
	end
	local function v_u_295(p284, p285, p286, p287, p288, p289) -- name: grid
		local v290 = Instance.new("Frame")
		v290.Name = p285
		v290.BackgroundTransparency = 1
		v290.Size = UDim2.new(1, 0, 0, 0)
		v290.AutomaticSize = Enum.AutomaticSize.Y
		v290.LayoutOrder = p287
		local v291 = Instance.new("UIGridLayout")
		local v292 = UDim2.new
		local v293 = 1 / p289
		local v294 = (p289 - 1) * 8 / p289
		v291.CellSize = v292(v293, -math.ceil(v294), 0, p286)
		v291.CellPadding = UDim2.fromOffset(8, p288)
		v291.SortOrder = Enum.SortOrder.LayoutOrder
		v291.FillDirection = Enum.FillDirection.Horizontal
		v291.Parent = v290
		v290.Parent = p284
		return v290
	end
	local function v_u_303(p296, p297, p298, p299, p300) -- name: header
		-- upvalues: (copy) v_u_173, (copy) v_u_182
		local v301 = p300 or 0.5
		local v302 = Instance.new("Frame")
		v302.Name = "Head_" .. p299
		v302.BackgroundTransparency = 1
		v302.Size = UDim2.new(1, 0, 0, 20)
		v302.LayoutOrder = p299
		v_u_173.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v302,
			["text"] = p297,
			["color"] = v_u_182.text2,
			["size"] = UDim2.new(v301, 0, 1, 0)
		})
		v_u_173.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["align"] = "right",
			["track"] = false,
			["parent"] = v302,
			["text"] = p298,
			["color"] = v_u_182.text2,
			["size"] = UDim2.new(1 - v301, 0, 1, 0),
			["position"] = UDim2.fromScale(v301, 0)
		})
		v302.Parent = p296
		v_u_173.divider({
			["parent"] = p296,
			["order"] = p299 + 1
		})
		return v302
	end
	local function v_u_309(p304) -- name: money
		local v305 = tonumber(p304) or 0
		local v306 = math.floor(v305)
		local v307 = tostring(v306)
		repeat
			local v308
			v307, v308 = string.gsub(v307, "^(-?%d+)(%d%d%d)", "%1,%2")
		until v308 == 0
		return "$" .. v307
	end
	local function v_u_344(p310, p_u_311) -- name: drawPicker
		-- upvalues: (ref) v_u_149, (ref) v_u_150, (copy) v_u_173, (copy) v_u_190, (ref) v_u_267, (copy) v_u_197, (copy) v_u_189, (copy) v_u_303, (copy) v_u_182, (copy) v_u_178, (copy) v_u_309, (copy) p_u_160, (copy) v_u_295, (ref) v_u_3, (copy) v_u_283, (copy) v_u_265
		local function v313() -- name: closePicker
			-- upvalues: (ref) v_u_149, (ref) v_u_150, (ref) v_u_173, (ref) v_u_190, (ref) v_u_267
			v_u_149 = false
			v_u_150 = nil
			local v312 = v_u_173.sound
			pcall(v312, "click")
			v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
		end
		local v314 = nil
		if v_u_150 then
			for _, v315 in v_u_197.pick do
				if v315.uid ~= v_u_150 then
					continue
				end
				v314 = v315
			end
			if not v314 then
				v_u_150 = nil
			end
		end
		if v_u_189 then
			v_u_303(p310, "FROM YOUR STASH", ("%d PIECES"):format(#v_u_197.pick), 5, 0.5).Position = UDim2.fromOffset(0, 0)
			local v316 = p310:FindFirstChild("Divider")
			if v316 and v316:IsA("GuiObject") then
				v316.Position = UDim2.fromOffset(0, 28)
			end
			p310 = v_u_173.list({
				["parent"] = nil,
				["name"] = "PickScroll",
				["size"] = nil,
				["position"] = nil,
				["gap"] = 8,
				["parent"] = p310,
				["size"] = UDim2.new(1, 0, 1, -36),
				["position"] = UDim2.fromOffset(0, 36)
			})
		else
			v_u_303(p310, "FROM YOUR STASH", ("%d PIECES"):format(#v_u_197.pick), 5)
		end
		local v317 = v_u_189 and 1 or 7
		v_u_173.label({
			["parent"] = nil,
			["name"] = "PickNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["size"] = nil,
			["order"] = nil,
			["track"] = false,
			["parent"] = p310,
			["text"] = ("Slot %d. A piece you hang leaves your stash and stays locked until you take it down."):format(p_u_311),
			["color"] = v_u_182.muted,
			["size"] = UDim2.new(1, -2, 0, 0),
			["order"] = v317
		})
		v_u_173.button({
			["parent"] = nil,
			["name"] = "PickBack",
			["text"] = "BACK TO TROPHY CASE",
			["kind"] = "secondary",
			["size"] = nil,
			["order"] = nil,
			["onClick"] = nil,
			["parent"] = p310,
			["size"] = UDim2.new(1, -2, 0, v_u_178.touch(44)),
			["order"] = v317 + 1,
			["onClick"] = v313
		}).Name = "PickBack"
		if v314 then
			local v318 = Instance.new("Frame")
			v318.Name = "PickQuestion"
			v318.BorderSizePixel = 0
			v318.BackgroundColor3 = v_u_182.raised
			v318.BackgroundTransparency = 0.15
			v318.Size = UDim2.new(1, -2, 0, 0)
			v318.AutomaticSize = Enum.AutomaticSize.Y
			v318.LayoutOrder = v317 + 2
			v_u_173.stroke(v318, v_u_182.accent)
			v_u_173.pad(v318, {
				12,
				12,
				12,
				12
			})
			v_u_173.layout(v318, "v", 10)
			v318.Parent = p310
			v_u_173.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["size"] = nil,
				["order"] = 1,
				["track"] = false,
				["parent"] = v318,
				["text"] = ("HANG IN SLOT %d?"):format(p_u_311),
				["color"] = v_u_182.accent,
				["size"] = UDim2.new(1, 0, 0, 16)
			})
			local v319 = v_u_173.label
			local v320 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["size"] = nil,
				["order"] = 2,
				["track"] = false,
				["parent"] = v318
			}
			local v321 = string.upper
			local v322 = v314.name
			v320.text = v321((tostring(v322)))
			v320.color = v_u_182.text
			v320.size = UDim2.new(1, 0, 0, 0)
			v319(v320)
			v_u_173.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["order"] = 3,
				["track"] = false,
				["parent"] = v318,
				["text"] = ("Value %s"):format((v_u_309(v314.value))) .. (v314.fir and "  /  found in raid" or ""),
				["color"] = v_u_182.text2,
				["size"] = UDim2.new(1, 0, 0, 16)
			})
			v_u_173.label({
				["parent"] = nil,
				["text"] = "It stays on the wall until you take it down. Until then it cannot be sold, traded, insured or used.",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["size"] = nil,
				["order"] = 4,
				["track"] = false,
				["parent"] = v318,
				["color"] = v_u_182.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			local v323 = Instance.new("Frame")
			v323.Name = "Answer"
			v323.BackgroundTransparency = 1
			v323.Size = UDim2.new(1, 0, 0, v_u_178.touch(44))
			v323.LayoutOrder = 5
			v_u_173.layout(v323, "h", 10)
			v323.Parent = v318
			v_u_173.button({
				["parent"] = nil,
				["name"] = "PickHang",
				["text"] = "HANG IT",
				["kind"] = "primary",
				["size"] = nil,
				["order"] = 1,
				["onClick"] = nil,
				["parent"] = v323,
				["size"] = UDim2.new(0.5, -5, 1, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_150, (ref) v_u_149, (ref) v_u_173, (copy) p_u_311, (ref) p_u_160, (ref) v_u_190, (ref) v_u_267
					local v324 = v_u_150
					v_u_149 = false
					v_u_150 = nil
					local v325 = v_u_173.sound
					pcall(v325, "confirm")
					if v324 then
						local v326 = {
							["uid"] = v324,
							["slot"] = p_u_311
						}
						if p_u_160.act then
							p_u_160.act("wallHang", v326)
						end
					end
					v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
				end
			}).Name = "PickHang"
			v_u_173.button({
				["parent"] = nil,
				["name"] = "PickCancel",
				["text"] = "CANCEL",
				["kind"] = "secondary",
				["size"] = nil,
				["order"] = 2,
				["onClick"] = nil,
				["parent"] = v323,
				["size"] = UDim2.new(0.5, -5, 1, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_150, (ref) v_u_173, (ref) v_u_190, (ref) v_u_267
					v_u_150 = nil
					local v327 = v_u_173.sound
					pcall(v327, "click")
					v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
				end
			}).Name = "PickCancel"
		else
			local v328 = v_u_295(p310, "Pick", 108, v317 + 2, 8, v_u_189 and 3 or 6)
			v328.Size = UDim2.new(1, -2, 0, 0)
			for v329, v_u_330 in v_u_197.pick do
				local v331 = {
					["key"] = nil,
					["kind"] = "stash",
					["id"] = nil,
					["uid"] = nil,
					["name"] = nil,
					["value"] = nil,
					["fir"] = nil,
					["key"] = "w:" .. v_u_330.uid,
					["id"] = v_u_330.id,
					["uid"] = v_u_330.uid,
					["name"] = v_u_330.name,
					["value"] = v_u_330.value,
					["fir"] = v_u_330.fir == true
				}
				local v332 = v_u_3.info(v331.key, v331)
				local v333 = v_u_283(v328, "Pick_" .. v329, 108, v329)
				local v334 = Instance.new("Frame")
				v334.Name = "Tint"
				v334.BorderSizePixel = 0
				v334.Size = UDim2.fromScale(1, 1)
				v334.BackgroundColor3 = v_u_178.rarityColor(v332.rarity)
				v334.BackgroundTransparency = v_u_178.alpha.rarity
				v334.Parent = v333
				local v_u_335 = v_u_178.rarityColor(v332.rarity):Lerp(v_u_182.line, 0.55)
				local v_u_336 = v_u_173.stroke(v333, v_u_335)
				v_u_265(v333, v331.key, v331, true, 6, 52)
				local v337 = v_u_173.label
				local v338 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["zindex"] = 3,
					["parent"] = v333
				}
				local v339
				if v332.kind == "plate" then
					v339 = not v332.week and "CHAMPIONS" or ("WEEK %d CHAMPIONS"):format(v332.week)
				else
					v339 = v332.short
				end
				v338.text = v339
				v338.color = v_u_182.text
				v338.size = UDim2.new(1, -8, 0, 16)
				v338.position = UDim2.fromOffset(4, 60)
				v337(v338)
				v_u_173.label({
					["parent"] = nil,
					["name"] = "Value",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["zindex"] = 3,
					["parent"] = v333,
					["text"] = v_u_309(v_u_330.value),
					["color"] = v_u_182.text2,
					["size"] = UDim2.new(1, -8, 0, 14),
					["position"] = UDim2.fromOffset(4, 78)
				})
				if v_u_330.fir then
					v_u_173.badge("FIR", "success", {
						["name"] = "Fir",
						["parent"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["height"] = 14,
						["parent"] = v333,
						["position"] = UDim2.new(1, -4, 0, 3),
						["anchor"] = Vector2.new(1, 0)
					}).ZIndex = 4
				end
				v333.MouseEnter:Connect(function()
					-- upvalues: (copy) v_u_336, (ref) v_u_182
					v_u_336.Color = v_u_182.accent
				end)
				v333.MouseLeave:Connect(function()
					-- upvalues: (copy) v_u_336, (copy) v_u_335
					v_u_336.Color = v_u_335
				end)
				v333.SelectionGained:Connect(function()
					-- upvalues: (copy) v_u_336, (ref) v_u_182
					v_u_336.Color = v_u_182.accent
				end)
				v333.SelectionLost:Connect(function()
					-- upvalues: (copy) v_u_336, (copy) v_u_335
					v_u_336.Color = v_u_335
				end)
				v333.Activated:Connect(function()
					-- upvalues: (ref) v_u_150, (copy) v_u_330, (ref) v_u_173, (ref) v_u_190, (ref) v_u_267
					v_u_150 = v_u_330.uid
					local v340 = v_u_173.sound
					pcall(v340, "click")
					v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
				end)
				v_u_173.tooltip(v333, function()
					-- upvalues: (copy) v_u_330, (copy) p_u_311, (ref) v_u_309
					local v341 = {}
					local v342 = string.upper
					local v343 = v_u_330.name
					v341.title = v342((tostring(v343)))
					v341.body = "Choose it to hang it in slot " .. p_u_311 .. ". It leaves your stash and stays locked until you take it down."
					v341.lines = {
						{
							["label"] = "Value",
							["value"] = nil,
							["value"] = v_u_309(v_u_330.value)
						}
					}
					return v341
				end)
			end
			if #v_u_197.pick == 0 then
				v_u_173.label({
					["parent"] = nil,
					["text"] = "Nothing in your stash can be hung: single pieces only, nothing inside, no quest items or keys.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = nil,
					["track"] = false,
					["parent"] = p310,
					["color"] = v_u_182.muted,
					["size"] = UDim2.new(1, -2, 0, 0),
					["order"] = v317 + 3
				})
			end
		end
	end
	v_u_267 = function()
		-- upvalues: (copy) v_u_190, (copy) v_u_266, (ref) v_u_156, (copy) v_u_197, (copy) v_u_198, (ref) v_u_148, (copy) v_u_188, (copy) v_u_189, (copy) v_u_173, (ref) v_u_196, (copy) v_u_303, (copy) v_u_182, (copy) v_u_295, (ref) v_u_3, (copy) v_u_283, (ref) v_u_5, (copy) v_u_178, (copy) v_u_265, (ref) v_u_6, (ref) v_u_149, (ref) v_u_150, (ref) v_u_267, (copy) v_u_199, (ref) v_u_18, (ref) v_u_12, (copy) p_u_160, (copy) v_u_277, (copy) v_u_344
		for _, v345 in v_u_190:GetChildren() do
			if v345:IsA("UIListLayout") then
				continue
			end
			v345:Destroy()
		end
		table.clear(v_u_266)
		local v_u_346 = v_u_156(v_u_197)
		local v347 = 0
		for _, v348 in v_u_346 do
			if v348 == "" then
				continue
			end
			v347 = v347 + 1
		end
		if v_u_198 then
			if v_u_148 < 1 or v_u_148 > v_u_197.slots then
				v_u_148 = 1
				for v349 = 1, v_u_197.slots do
					if v_u_346[v349] ~= "" then
						continue
					end
					v_u_148 = v349
				end
			end
		else
			v_u_148 = 0
		end
		v_u_188:SetAttribute("TrophySlot", v_u_148)
		local v350 = v_u_190
		local v351 = v_u_190
		local v352 = v_u_189 and 4 or 6
		local v353
		if v_u_189 then
			v350 = Instance.new("Frame")
			v350.Name = "Left"
			v350.BackgroundTransparency = 1
			v350.Size = UDim2.new(0.6, -10, 1, 0)
			v_u_173.layout(v350, "v", 12)
			v350.Parent = v_u_190
			v_u_173.divider({
				["parent"] = nil,
				["vertical"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_190,
				["position"] = UDim2.new(0.6, 0, 0, 0),
				["size"] = UDim2.new(0, 1, 1, 0)
			})
			v351 = Instance.new("Frame")
			v351.Name = "Right"
			v351.BackgroundTransparency = 1
			v351.Position = UDim2.new(0.6, 11, 0, 0)
			v351.Size = UDim2.new(0.4, -11, 1, 0)
			v351.Parent = v_u_190
			local v354 = (v_u_196 - 20 - 1 - 76 - 36 - 24 - 20) / 3
			local v355 = math.floor(v354)
			v353 = math.clamp(v355, 84, 172)
		else
			v353 = 112
		end
		v_u_303(v350, "ON DISPLAY", not v_u_198 and "WALL NOT BUILT" or ("%d / %d SLOTS"):format(v347, v_u_197.slots), 1)
		local v356 = Instance.new("Frame")
		v356.Name = "Board"
		v356.BorderSizePixel = 0
		v356.BackgroundColor3 = v_u_182.accentDeep:Lerp(v_u_182.raised, 0.55)
		v356.BackgroundTransparency = 0.1
		v356.Size = UDim2.new(1, 0, 0, 0)
		v356.AutomaticSize = Enum.AutomaticSize.Y
		v356.LayoutOrder = 3
		v_u_173.stroke(v356, v_u_182.line)
		v_u_173.pad(v356, {
			12,
			12,
			12,
			12
		})
		v356.Parent = v350
		local v357 = v353 - 18 - 26
		local v358 = v_u_295(v356, "Slots", v353, 1, 10, v352)
		for v_u_359 = 1, not v_u_198 and 12 or v_u_197.slots do
			local v360 = v_u_198 and (v_u_346[v_u_359] or "") or ""
			local v_u_361
			if v360 == "" then
				v_u_361 = nil
			else
				v_u_361 = v_u_197.byKey[v360]
			end
			local v_u_362
			if v360 == "" then
				v_u_362 = nil
			else
				v_u_362 = v_u_3.info(v360, v_u_361)
			end
			local v363 = v_u_283(v358, ("Slot_%02d"):format(v_u_359), v353, v_u_359)
			local v_u_364 = v_u_173.stroke(v363, v_u_182.line)
			local v365 = Instance.new("Frame")
			v365.Name = "Peg"
			v365.BorderSizePixel = 0
			v365.BackgroundColor3 = v_u_182.lineStrong
			v365.AnchorPoint = Vector2.new(0.5, 0)
			v365.Position = UDim2.new(0.5, 0, 0, 0)
			v365.Size = UDim2.fromOffset(10, 3)
			v365.Parent = v363
			v_u_173.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v363,
				["text"] = ("%02d"):format(v_u_359),
				["color"] = v_u_182.muted,
				["size"] = UDim2.fromOffset(22, 14),
				["position"] = UDim2.fromOffset(4, 3)
			})
			local v_u_366 = nil
			local v367 = v353 - 24
			if v_u_362 then
				local v368 = Instance.new("Frame")
				v368.Name = "Tint"
				v368.BorderSizePixel = 0
				v368.Size = UDim2.fromScale(1, 1)
				local v369
				if v_u_362.kind == "boss" then
					v369 = v_u_182.danger
				elseif v_u_362.kind == "plate" then
					v369 = v_u_5
				else
					v369 = v_u_178.rarityColor(v_u_362.rarity)
				end
				v368.BackgroundColor3 = v369
				v368.BackgroundTransparency = v_u_178.alpha.rarity
				v368.Parent = v363
				v_u_366 = v368
				v_u_265(v363, v360, v_u_361, true, 18, v357)
				if v_u_362.kind == "stash" then
					v_u_173.badge("STASH", "info", {
						["name"] = "StashSeal",
						["parent"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["height"] = 14,
						["parent"] = v363,
						["position"] = UDim2.new(1, -4, 0, 3),
						["anchor"] = Vector2.new(1, 0)
					}).ZIndex = 4
				end
				local v370 = v_u_173.label
				local v371 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["zindex"] = 3,
					["parent"] = v363
				}
				local v372
				if v_u_362.kind == "plate" then
					v372 = not v_u_362.week and "CHAMPIONS" or ("WEEK %d CHAMPIONS"):format(v_u_362.week)
				else
					v372 = v_u_362.short
				end
				v371.text = v372
				v371.color = v_u_182.text
				v371.size = UDim2.new(1, -8, 0, 16)
				v371.position = UDim2.fromOffset(4, v367)
				v370(v371)
			elseif v_u_198 then
				v363.BackgroundTransparency = 0.75
				v_u_173.icon("plus", {
					["parent"] = nil,
					["size"] = 18,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v363,
					["color"] = v_u_182.muted,
					["position"] = UDim2.new(0.5, 0, 0, v357 / 2 + 18),
					["anchor"] = Vector2.new(0.5, 0.5)
				})
				v_u_173.label({
					["parent"] = nil,
					["text"] = "EMPTY",
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v363,
					["color"] = v_u_182.muted,
					["size"] = UDim2.new(1, -8, 0, 16),
					["position"] = UDim2.fromOffset(4, v367)
				})
			else
				v363.BackgroundTransparency = 0.8
				v_u_173.icon("lock", {
					["parent"] = nil,
					["size"] = 16,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v363,
					["color"] = v_u_182.muted,
					["position"] = UDim2.new(0.5, 0, 0, v357 / 2 + 18),
					["anchor"] = Vector2.new(0.5, 0.5)
				})
				v_u_173.label({
					["parent"] = nil,
					["text"] = "LOCKED",
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v363,
					["color"] = v_u_182.muted,
					["size"] = UDim2.new(1, -8, 0, 16),
					["position"] = UDim2.fromOffset(4, v367)
				})
			end
			local v_u_373 = Instance.new("Frame")
			v_u_373.Name = "SelBar"
			v_u_373.BorderSizePixel = 0
			v_u_373.BackgroundColor3 = v_u_182.accent
			v_u_373.AnchorPoint = Vector2.new(0, 1)
			v_u_373.Position = UDim2.fromScale(0, 1)
			v_u_373.Size = UDim2.new(1, 0, 0, 2)
			v_u_373.ZIndex = 4
			v_u_373.Parent = v363
			local v_u_374 = false
			local function v_u_378() -- name: paint
				-- upvalues: (ref) v_u_198, (ref) v_u_148, (copy) v_u_359, (copy) v_u_373, (copy) v_u_364, (ref) v_u_182, (ref) v_u_374, (copy) v_u_362, (ref) v_u_6, (ref) v_u_178, (ref) v_u_366
				local v375 = v_u_198
				if v375 then
					v375 = v_u_148 == v_u_359
				end
				v_u_373.Visible = v375
				local v376 = v_u_364
				local v377
				if v375 then
					v377 = v_u_182.accent
				elseif v_u_374 then
					v377 = v_u_182.lineStrong
				elseif v_u_362 then
					if v_u_362.kind == "boss" then
						v377 = v_u_182.danger:Lerp(v_u_182.line, 0.55)
					elseif v_u_362.kind == "plate" then
						v377 = v_u_6
					else
						v377 = v_u_178.rarityColor(v_u_362.rarity):Lerp(v_u_182.line, 0.55)
					end
				else
					v377 = v_u_182.line
				end
				v376.Color = v377
				if v_u_366 then
					v_u_366.BackgroundTransparency = v375 and 0.72 or v_u_178.alpha.rarity
				end
			end
			v_u_266[v_u_359] = v_u_378
			v363.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_374, (copy) v_u_378
				v_u_374 = true
				v_u_378()
			end)
			v363.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_374, (copy) v_u_378
				v_u_374 = false
				v_u_378()
			end)
			v363.SelectionGained:Connect(function()
				-- upvalues: (ref) v_u_374, (copy) v_u_378
				v_u_374 = true
				v_u_378()
			end)
			v363.SelectionLost:Connect(function()
				-- upvalues: (ref) v_u_374, (copy) v_u_378
				v_u_374 = false
				v_u_378()
			end)
			v363.Activated:Connect(function()
				-- upvalues: (ref) v_u_198, (copy) v_u_359, (ref) v_u_148, (ref) v_u_149, (ref) v_u_150, (ref) v_u_188, (ref) v_u_173, (ref) v_u_190, (ref) v_u_267
				if v_u_198 then
					local v379 = v_u_359
					if v_u_148 ~= v379 then
						v_u_148 = v379
						v_u_149 = false
						v_u_150 = nil
						v_u_188:SetAttribute("TrophySlot", v379)
						local v380 = v_u_173.sound
						pcall(v380, "click")
						v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
					end
				else
					local v381 = v_u_173.sound
					pcall(v381, "error")
					return
				end
			end)
			v_u_173.tooltip(v363, function()
				-- upvalues: (ref) v_u_198, (copy) v_u_362, (copy) v_u_359, (ref) v_u_199, (ref) v_u_18, (copy) v_u_361
				if not v_u_198 then
					return {
						["title"] = "LOCKED",
						["body"] = "Build the trophy wall to hang your finds here."
					}
				end
				if not v_u_362 then
					return {
						["title"] = ("SLOT %d  /  EMPTY"):format(v_u_359),
						["body"] = ("Select it, then pick a trophy from the TROPHY CASE %s."):format(v_u_199)
					}
				end
				local v382 = {}
				local v383 = v_u_18
				local v384 = v_u_361
				if v384 then
					v384 = v_u_361.at
				end
				local v385 = v383(v384)
				if v385 ~= "" then
					table.insert(v382, {
						["label"] = "Mounted",
						["value"] = nil,
						["value"] = v385
					})
				end
				local v386 = {
					["label"] = "Slot",
					["value"] = nil
				}
				local v387 = v_u_359
				v386.value = tostring(v387)
				table.insert(v382, v386)
				if v_u_362.kind ~= "stash" then
					return {
						["title"] = string.upper(v_u_362.name),
						["body"] = v_u_362.desc,
						["lines"] = v382
					}
				end
				table.insert(v382, {
					["label"] = "From",
					["value"] = "Your stash"
				})
				return {
					["title"] = string.upper(v_u_362.name),
					["body"] = (v_u_362.desc == "" and "" or v_u_362.desc .. "\n\n") .. "Locked on the wall: it cannot be sold, traded or used until you take it down.",
					["lines"] = v382
				}
			end)
			v_u_378()
		end
		local v388 = Instance.new("Frame")
		v388.Name = "Detail"
		v388.BorderSizePixel = 0
		v388.BackgroundColor3 = v_u_182.raised
		v388.BackgroundTransparency = 0.15
		v388.LayoutOrder = 4
		if v_u_189 then
			v388.Size = UDim2.new(1, 0, 0, 76)
		else
			v388.Size = UDim2.new(1, 0, 0, 0)
			v388.AutomaticSize = Enum.AutomaticSize.Y
			local v389 = Instance.new("UISizeConstraint")
			v389.MinSize = Vector2.new(0, v_u_178.touch(44) + 20)
			v389.Parent = v388
		end
		v_u_173.stroke(v388, v_u_182.line)
		v_u_173.pad(v388, {
			12,
			12,
			10,
			10
		})
		local v390 = Instance.new("Frame")
		v390.Name = "Info"
		v390.BackgroundTransparency = 1
		v390.Size = UDim2.new(1, -188, 0, 0)
		v390.AutomaticSize = Enum.AutomaticSize.Y
		if v_u_189 then
			v390.AnchorPoint = Vector2.new(0, 0.5)
			v390.Position = UDim2.fromScale(0, 0.5)
		end
		v_u_173.layout(v390, "v", 2)
		v390.Parent = v388
		local v391 = v_u_198 and v_u_148 > 0 and (v_u_346[v_u_148] or "") or ""
		if v_u_198 then
			if v391 == "" then
				v_u_173.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["order"] = 1,
					["track"] = false,
					["parent"] = v390,
					["text"] = ("SLOT %d  /  EMPTY"):format(v_u_148),
					["color"] = v_u_182.accent
				})
				local v392 = v_u_197.hang
				if v392 then
					v392 = #v_u_197.pick > 0
				end
				local v393 = v_u_173.label
				local v394 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = 2,
					["track"] = false,
					["parent"] = v390
				}
				local v395
				if v392 then
					v395 = ("Pick a trophy from the case %s, or hang a piece from your stash."):format(v_u_199)
				else
					v395 = ("Pick a trophy from the case %s to hang it here."):format(v_u_199)
				end
				v394.text = v395
				v394.color = v_u_182.text2
				v394.size = UDim2.new(1, 0, 0, 0)
				v393(v394)
				if v392 then
					v_u_173.button({
						["parent"] = nil,
						["name"] = "HangFromStash",
						["text"] = "HANG FROM STASH",
						["kind"] = "secondary",
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["onClick"] = nil,
						["parent"] = v388,
						["size"] = UDim2.fromOffset(176, v_u_178.touch(44)),
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_149, (ref) v_u_150, (ref) v_u_173, (ref) v_u_190, (ref) v_u_267
							v_u_149 = true
							v_u_150 = nil
							local v396 = v_u_173.sound
							pcall(v396, "click")
							v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
						end
					}).Name = "HangFromStash"
				end
			else
				local v397 = v_u_197.byKey[v391]
				local v_u_398 = v_u_3.info(v391, v397)
				local v399 = v_u_18
				if v397 then
					v397 = v397.at
				end
				local v400 = v399(v397)
				local v_u_401 = v_u_398.kind == "stash"
				local v402 = v_u_173.label
				local v403 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["order"] = 1,
					["track"] = false,
					["parent"] = v390
				}
				local v404
				if v_u_401 then
					v404 = ("SLOT %d  /  FROM YOUR STASH"):format(v_u_148)
				else
					v404 = (v400 == "" and "SLOT %d" or "SLOT %d  \194\183  MOUNTED %s"):format(v_u_148, v400)
				end
				v403.text = v404
				v403.color = v_u_182.accent
				v402(v403)
				v_u_173.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["size"] = nil,
					["order"] = 2,
					["track"] = false,
					["parent"] = v390,
					["text"] = string.upper(v_u_398.name),
					["color"] = v_u_182.text,
					["size"] = UDim2.new(1, 0, 0, 22)
				})
				v_u_173.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = nil,
					["autoY"] = nil,
					["size"] = nil,
					["order"] = 3,
					["track"] = false,
					["parent"] = v390,
					["text"] = v_u_401 and "Locked: it cannot be sold, traded or used until you take it down." or ("Pick another trophy %s to swap it."):format(v_u_199),
					["color"] = v_u_182.text2,
					["wrap"] = v_u_401,
					["autoY"] = v_u_401,
					["size"] = UDim2.new(1, 0, 0, v_u_401 and 0 or 16)
				})
				v_u_173.button({
					["parent"] = nil,
					["name"] = "TakeDown",
					["text"] = "TAKE DOWN",
					["kind"] = "secondary",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = v388,
					["size"] = UDim2.fromOffset(176, v_u_178.touch(44)),
					["position"] = UDim2.new(1, 0, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_401, (copy) v_u_398, (ref) p_u_160, (ref) v_u_173, (ref) v_u_277, (ref) v_u_148
						if v_u_401 then
							local v405 = {
								["uid"] = v_u_398.uid
							}
							if p_u_160.act then
								p_u_160.act("wallTake", v405)
							end
							local v406 = v_u_173.sound
							pcall(v406, "confirm")
						else
							v_u_277(v_u_148, "")
						end
					end
				}).Name = "TakeDown"
			end
		else
			v_u_173.label({
				["parent"] = nil,
				["text"] = "WALL NOT BUILT",
				["style"] = "caps",
				["color"] = nil,
				["order"] = 1,
				["track"] = false,
				["parent"] = v390,
				["color"] = v_u_182.accent
			})
			local v407
			if v_u_12 == nil then
				v407 = false
			else
				local v408 = v_u_12.maxLevel
				if type(v408) == "function" then
					v407 = v_u_12.maxLevel("trophy_wall") >= 2
				else
					v407 = false
				end
			end
			v_u_173.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["size"] = nil,
				["order"] = 2,
				["track"] = false,
				["parent"] = v390,
				["text"] = ("Build it to display up to 12 trophies%s. What you have found so far is in the case %s."):format(v407 and ", 24 after the second level" or "", v_u_199),
				["color"] = v_u_182.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
		end
		v388.Parent = v350
		if v_u_149 and (v_u_198 and (v_u_197.hang and (v_u_148 > 0 and v_u_346[v_u_148] == ""))) then
			v_u_344(v351, v_u_148)
		else
			v_u_149 = false
			v_u_150 = nil
			local v409 = 0
			for _, v410 in v_u_12 and v_u_12.TROPHIES or {} do
				if not v_u_197.byKey[v410] then
					continue
				end
				v409 = v409 + 1
			end
			local v411 = {}
			for _, v412 in v_u_197.earned do
				if v412.kind ~= "plate" then
					continue
				end
				table.insert(v411, v412)
			end
			local v413 = ("FOUND %d / %d  \194\183  PLATES %d"):format(v409, #(v_u_12 and v_u_12.TROPHIES or {}), #v411)
			local v414
			if v_u_189 then
				v_u_303(v351, "TROPHY CASE", v413, 5, 0.38).Position = UDim2.fromOffset(0, 0)
				local v415 = v351:FindFirstChild("Divider")
				if v415 and v415:IsA("GuiObject") then
					v415.Position = UDim2.fromOffset(0, 28)
				end
				v_u_173.label({
					["parent"] = nil,
					["name"] = "Note",
					["text"] = "Nothing here is taken from your stash.",
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v351,
					["color"] = v_u_182.muted,
					["size"] = UDim2.new(1, 0, 0, 16),
					["position"] = UDim2.fromOffset(0, 36)
				})
				v414 = v_u_295(v_u_173.list({
					["parent"] = nil,
					["name"] = "CaseScroll",
					["size"] = nil,
					["position"] = nil,
					["gap"] = 0,
					["parent"] = v351,
					["size"] = UDim2.new(1, 0, 1, -62),
					["position"] = UDim2.fromOffset(0, 62)
				}), "Case", 108, 1, 8, 3)
				v414.Size = UDim2.new(1, -2, 0, 0)
			else
				v_u_303(v351, "TROPHY CASE", v413, 5)
				v_u_173.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = 7,
					["track"] = false,
					["parent"] = v351,
					["text"] = v_u_198 and "Rare finds, boss kills and champion plates you have earned. Nothing is taken from your stash." or "Rare finds, boss kills and champion plates you have earned so far.",
					["color"] = v_u_182.muted,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
				v414 = v_u_295(v351, "Case", 108, 8, 8, 6)
			end
			local v416 = {}
			for v417, v418 in v_u_346 do
				if v418 == "" then
					continue
				end
				v416[v418] = v417
			end
			local v419 = {}
			for _, v420 in v_u_12 and v_u_12.TROPHIES or {} do
				local v421 = {
					["key"] = v420,
					["e"] = v_u_197.byKey[v420],
					["earned"] = v_u_197.byKey[v420] ~= nil
				}
				table.insert(v419, v421)
			end
			for _, v422 in v411 do
				local v423 = {
					["key"] = nil,
					["e"] = nil,
					["earned"] = true,
					["key"] = v422.key,
					["e"] = v422
				}
				table.insert(v419, v423)
			end
			if #v411 == 0 then
				table.insert(v419, {
					["key"] = "plate_0_none",
					["e"] = nil,
					["earned"] = false,
					["e"] = {
						["kind"] = "plate"
					}
				})
			end
			for v424, v_u_425 in v419 do
				local v_u_426 = v_u_425.key
				local v_u_427 = v_u_3.info(v_u_426, v_u_425.e)
				local v428 = v_u_283(v414, "Case_" .. v_u_426, 108, v424)
				local v_u_429 = not v_u_425.earned
				if v_u_429 then
					v_u_429 = v_u_427.kind == "boss" and true or v_u_427.kind == "plate"
				end
				if v_u_425.earned then
					local v430 = Instance.new("Frame")
					v430.Name = "Tint"
					v430.BorderSizePixel = 0
					v430.Size = UDim2.fromScale(1, 1)
					local v431
					if v_u_427.kind == "boss" then
						v431 = v_u_182.danger
					elseif v_u_427.kind == "plate" then
						v431 = v_u_5
					else
						v431 = v_u_178.rarityColor(v_u_427.rarity)
					end
					v430.BackgroundColor3 = v431
					v430.BackgroundTransparency = v_u_178.alpha.rarity
					v430.Parent = v428
				else
					v428.BackgroundColor3 = v_u_182.raised2
				end
				local v_u_432
				if v_u_425.earned then
					if v_u_427.kind == "boss" then
						v_u_432 = v_u_182.danger:Lerp(v_u_182.line, 0.55)
					elseif v_u_427.kind == "plate" then
						v_u_432 = v_u_6
					else
						v_u_432 = v_u_178.rarityColor(v_u_427.rarity):Lerp(v_u_182.line, 0.55)
					end
				else
					v_u_432 = v_u_182.line
				end
				local v_u_433 = v_u_173.stroke(v428, v_u_432)
				v_u_265(v428, v_u_426, v_u_425.e, v_u_425.earned, 6, 62)
				local v434 = v_u_173.label
				local v435 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["zindex"] = 3,
					["parent"] = v428
				}
				local v436
				if v_u_429 then
					v436 = "???"
				elseif v_u_427.kind == "plate" then
					v436 = not v_u_427.week and "CHAMPIONS" or ("WEEK %d CHAMPIONS"):format(v_u_427.week)
				else
					v436 = v_u_427.short
				end
				v435.text = v436
				local v437
				if v_u_425.earned then
					v437 = v_u_182.text
				else
					v437 = v_u_182.muted
				end
				v435.color = v437
				v435.size = UDim2.new(1, -8, 0, 16)
				v435.position = UDim2.fromOffset(4, 71)
				v434(v435)
				local v_u_438 = v416[v_u_426]
				if v_u_438 then
					v_u_173.badge(("ON WALL %d"):format(v_u_438), "warn", {
						["parent"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["height"] = 14,
						["parent"] = v428,
						["position"] = UDim2.new(0.5, 0, 1, -5),
						["anchor"] = Vector2.new(0.5, 1)
					}).ZIndex = 4
				elseif v_u_425.earned then
					if v_u_198 then
						v_u_173.label({
							["parent"] = nil,
							["text"] = "HANG",
							["style"] = "micro",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["position"] = nil,
							["track"] = false,
							["zindex"] = 3,
							["parent"] = v428,
							["color"] = v_u_182.text2,
							["size"] = UDim2.new(1, -6, 0, 12),
							["position"] = UDim2.new(0, 3, 1, -16)
						})
					end
				else
					v_u_173.icon("lock", {
						["parent"] = nil,
						["size"] = 12,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["zindex"] = 4,
						["parent"] = v428,
						["color"] = v_u_182.muted,
						["position"] = UDim2.new(1, -5, 1, -5),
						["anchor"] = Vector2.new(1, 1)
					})
				end
				local v_u_439 = false
				v428.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_439, (copy) v_u_433, (ref) v_u_182, (copy) v_u_432
					v_u_439 = true
					local v440 = v_u_433
					local v441
					if v_u_439 then
						v441 = v_u_182.accent
					else
						v441 = v_u_432
					end
					v440.Color = v441
				end)
				v428.MouseLeave:Connect(function()
					-- upvalues: (ref) v_u_439, (copy) v_u_433, (ref) v_u_182, (copy) v_u_432
					v_u_439 = false
					local v442 = v_u_433
					local v443
					if v_u_439 then
						v443 = v_u_182.accent
					else
						v443 = v_u_432
					end
					v442.Color = v443
				end)
				v428.SelectionGained:Connect(function()
					-- upvalues: (ref) v_u_439, (copy) v_u_433, (ref) v_u_182, (copy) v_u_432
					v_u_439 = true
					local v444 = v_u_433
					local v445
					if v_u_439 then
						v445 = v_u_182.accent
					else
						v445 = v_u_432
					end
					v444.Color = v445
				end)
				v428.SelectionLost:Connect(function()
					-- upvalues: (ref) v_u_439, (copy) v_u_433, (ref) v_u_182, (copy) v_u_432
					v_u_439 = false
					local v446 = v_u_433
					local v447
					if v_u_439 then
						v447 = v_u_182.accent
					else
						v447 = v_u_432
					end
					v446.Color = v447
				end)
				v428.Activated:Connect(function()
					-- upvalues: (copy) v_u_425, (ref) v_u_198, (ref) v_u_173, (ref) v_u_148, (copy) v_u_346, (copy) v_u_426, (ref) v_u_277
					if v_u_425.earned and v_u_198 then
						if v_u_148 < 1 then
							return
						elseif v_u_346[v_u_148] == v_u_426 then
							local v448 = v_u_173.sound
							pcall(v448, "click")
						else
							v_u_277(v_u_148, v_u_426)
						end
					else
						local v449 = v_u_173.sound
						pcall(v449, "error")
						return
					end
				end)
				v_u_173.tooltip(v428, function()
					-- upvalues: (copy) v_u_425, (copy) v_u_429, (copy) v_u_427, (ref) v_u_18, (copy) v_u_438, (ref) v_u_182, (ref) v_u_198, (ref) v_u_148
					if not v_u_425.earned then
						return {
							["title"] = v_u_429 and "UNKNOWN" or string.upper(v_u_427.name),
							["body"] = "Not found yet. " .. v_u_427.hint
						}
					end
					local v450 = {}
					local v451 = v_u_18
					local v452 = v_u_425.e
					if v452 then
						v452 = v_u_425.e.at
					end
					local v453 = v451(v452)
					if v453 ~= "" then
						table.insert(v450, {
							["label"] = "Mounted",
							["value"] = nil,
							["value"] = v453
						})
					end
					local v454 = {
						["label"] = "On the wall",
						["value"] = nil,
						["color"] = nil,
						["value"] = not v_u_438 and "No" or ("Slot %d"):format(v_u_438)
					}
					local v455
					if v_u_438 then
						v455 = v_u_182.accent
					else
						v455 = nil
					end
					v454.color = v455
					table.insert(v450, v454)
					local v456 = v_u_427.desc
					if v_u_198 then
						v456 = (v456 == "" and "" or v456 .. "\n\n") .. (v_u_438 == v_u_148 and "Hanging in the selected slot." or ("Hang it in slot %d."):format(v_u_148))
					end
					return {
						["title"] = string.upper(v_u_427.name),
						["body"] = v456,
						["lines"] = v450
					}
				end)
				if v_u_439 then
					v_u_432 = v_u_182.accent
				end
				v_u_433.Color = v_u_432
			end
			local v457 = #v_u_197.waiting > 0 and v414.Parent
			if v457 then
				v_u_303(v457, "WAITING FOR A FREE SLOT", ("%d PIECES"):format(#v_u_197.waiting), 30)
				local v458 = v_u_295(v457, "Waiting", 108, 32, 8, v_u_189 and 3 or 6)
				if v_u_189 then
					v458.Size = UDim2.new(1, -2, 0, 0)
				end
				for v459, v_u_460 in v_u_197.waiting do
					local v461 = {
						["key"] = nil,
						["kind"] = "stash",
						["id"] = nil,
						["uid"] = nil,
						["name"] = nil,
						["value"] = nil,
						["fir"] = nil,
						["key"] = "w:" .. v_u_460.uid,
						["id"] = v_u_460.id,
						["uid"] = v_u_460.uid,
						["name"] = v_u_460.name,
						["value"] = v_u_460.value,
						["fir"] = v_u_460.fir == true
					}
					local v462 = v_u_3.info(v461.key, v461)
					local v463 = v_u_283(v458, "Waiting_" .. v459, 108, v459)
					local v_u_464 = v_u_173.stroke(v463, v_u_182.line)
					v_u_265(v463, v461.key, v461, true, 6, 62)
					local v465 = v_u_173.label
					local v466 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["track"] = false,
						["zindex"] = 3,
						["parent"] = v463
					}
					local v467
					if v462.kind == "plate" then
						v467 = not v462.week and "CHAMPIONS" or ("WEEK %d CHAMPIONS"):format(v462.week)
					else
						v467 = v462.short
					end
					v466.text = v467
					v466.color = v_u_182.text
					v466.size = UDim2.new(1, -8, 0, 16)
					v466.position = UDim2.fromOffset(4, 71)
					v465(v466)
					v_u_173.label({
						["parent"] = nil,
						["text"] = "TAKE DOWN",
						["style"] = "micro",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["track"] = false,
						["zindex"] = 3,
						["parent"] = v463,
						["color"] = v_u_182.text2,
						["size"] = UDim2.new(1, -6, 0, 12),
						["position"] = UDim2.new(0, 3, 1, -16)
					})
					v463.SelectionGained:Connect(function()
						-- upvalues: (copy) v_u_464, (ref) v_u_182
						v_u_464.Color = v_u_182.accent
					end)
					v463.SelectionLost:Connect(function()
						-- upvalues: (copy) v_u_464, (ref) v_u_182
						v_u_464.Color = v_u_182.line
					end)
					v463.Activated:Connect(function()
						-- upvalues: (copy) v_u_460, (ref) p_u_160, (ref) v_u_173
						local v468 = {
							["uid"] = v_u_460.uid
						}
						if p_u_160.act then
							p_u_160.act("wallTake", v468)
						end
						local v469 = v_u_173.sound
						pcall(v469, "confirm")
					end)
				end
			end
		end
	end
	v_u_267()
	if v_u_189 then
		local v470 = v_u_190.Parent
		if v470 and v470:IsA("GuiObject") then
			local v_u_473 = v470:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
				-- upvalues: (copy) v_u_195, (ref) v_u_196, (copy) v_u_190, (copy) v_u_173, (ref) v_u_267
				local v471 = v_u_195()
				local v472 = v471 - v_u_196
				if math.abs(v472) > 4 and v_u_190.Parent then
					v_u_196 = v471
					v_u_190.Size = UDim2.new(1, -8, 0, v_u_196)
					v_u_173.keepScroll(v_u_190.Parent or v_u_190, v_u_267)
				end
			end)
			v_u_190.Destroying:Connect(function()
				-- upvalues: (copy) v_u_473
				v_u_473:Disconnect()
			end)
		end
	end
	return v_u_190
end
local function v_u_485(p474, p475, p476, p477) -- name: engrave
	local v478 = Instance.new("SurfaceGui")
	v478.Name = "Engraving"
	v478.Face = Enum.NormalId.Front
	v478.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	v478.PixelsPerStud = 160
	v478.LightInfluence = 1
	v478.ClipsDescendants = true
	v478.Adornee = p474
	local v479 = Instance.new("Frame")
	v479.BackgroundTransparency = 1
	v479.Size = UDim2.fromScale(1, 1)
	v479.Parent = v478
	local v480 = #p475
	for v481, v482 in p475 do
		local v483 = Instance.new("TextLabel")
		v483.Name = "Line" .. v481
		v483.BackgroundTransparency = 1
		v483.Size = UDim2.new(0.92, 0, 1 / v480, -2)
		v483.Position = UDim2.new(0.04, 0, (v481 - 1) / v480, 1)
		v483.FontFace = p477 or Font.fromName("Oswald", Enum.FontWeight.Bold)
		v483.TextScaled = true
		v483.TextColor3 = p476
		v483.Text = v482
		local v484 = Instance.new("UITextSizeConstraint")
		v484.MaxTextSize = 64
		v484.Parent = v483
		v483.Parent = v479
	end
	v478.Parent = p474
end
local function v_u_488(p486) -- name: sealModel
	for _, v487 in p486:GetDescendants() do
		if v487:IsA("BasePart") then
			v487.Anchored = true
			v487.CanCollide = false
			v487.CanQuery = false
			v487.CanTouch = false
		else
			if not (v487:IsA("Script") or (v487:IsA("LocalScript") or (v487:IsA("ProximityPrompt") or v487:IsA("BillboardGui")))) then
				continue
			end
			v487:Destroy()
		end
	end
end
local function v_u_594(p489, p490, p491) -- name: hangFind
	-- upvalues: (copy) v_u_2, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_488
	local v_u_492 = "Assets"
	local function v493()
		-- upvalues: (ref) v_u_2, (copy) v_u_492
		return require((v_u_2:WaitForChild(v_u_492, 5)))
	end
	local v494, v495 = pcall(v493)
	if not v494 then
		v495 = nil
	end
	if v495 then
		local v496 = v_u_11
		if not v496 then
			local v_u_497 = "Items"
			local function v498()
				-- upvalues: (ref) v_u_2, (copy) v_u_497
				return require((v_u_2:WaitForChild(v_u_497, 5)))
			end
			local v499
			v499, v496 = pcall(v498)
			if not v499 then
				v496 = nil
			end
		end
		v_u_11 = v496
		local v500 = v_u_12
		if not v500 then
			local v_u_501 = "HideoutModules"
			local function v502()
				-- upvalues: (ref) v_u_2, (copy) v_u_501
				return require((v_u_2:WaitForChild(v_u_501, 5)))
			end
			local v503
			v503, v500 = pcall(v502)
			if not v503 then
				v500 = nil
			end
		end
		v_u_12 = v500
		local v504 = v_u_13
		if not v504 then
			local v_u_505 = "Factions"
			local function v506()
				-- upvalues: (ref) v_u_2, (copy) v_u_505
				return require((v_u_2:WaitForChild(v_u_505, 5)))
			end
			local v507
			v507, v504 = pcall(v506)
			if not v507 then
				v504 = nil
			end
		end
		v_u_13 = v504
		local v508
		if v_u_11 then
			local v509 = v_u_11.get
			if type(v509) == "function" then
				local v510 = v_u_11.get
				local v511
				v511, v508 = pcall(v510, p490)
				if not v511 then
					v508 = nil
				end
			else
				v508 = nil
			end
		else
			v508 = nil
		end
		if v508 then
			local v512 = v_u_11
			if not v512 then
				local v_u_513 = "Items"
				local function v514()
					-- upvalues: (ref) v_u_2, (copy) v_u_513
					return require((v_u_2:WaitForChild(v_u_513, 5)))
				end
				local v515
				v515, v512 = pcall(v514)
				if not v515 then
					v512 = nil
				end
			end
			v_u_11 = v512
			local v516 = v_u_12
			if not v516 then
				local v_u_517 = "HideoutModules"
				local function v518()
					-- upvalues: (ref) v_u_2, (copy) v_u_517
					return require((v_u_2:WaitForChild(v_u_517, 5)))
				end
				local v519
				v519, v516 = pcall(v518)
				if not v519 then
					v516 = nil
				end
			end
			v_u_12 = v516
			local v520 = v_u_13
			if not v520 then
				local v_u_521 = "Factions"
				local function v522()
					-- upvalues: (ref) v_u_2, (copy) v_u_521
					return require((v_u_2:WaitForChild(v_u_521, 5)))
				end
				local v523
				v523, v520 = pcall(v522)
				if not v523 then
					v520 = nil
				end
			end
			v_u_13 = v520
			local v524
			if v_u_11 then
				local v525 = v_u_11.get
				if type(v525) == "function" then
					local v526 = v_u_11.get
					local v527
					v527, v524 = pcall(v526, p490)
					if not v527 then
						v524 = nil
					end
				else
					v524 = nil
				end
			else
				v524 = nil
			end
			local v528 = v495.get
			local v529 = "Item"
			local v530
			if v524 then
				v530 = v524.model or p490
			else
				v530 = p490
			end
			local v531, v_u_532 = pcall(v528, v529, v530)
			if not v531 or (typeof(v_u_532) ~= "Instance" or not v_u_532:IsA("Model")) then
				return false
			end
			v_u_532.Name = "Trophy_" .. p490
			v_u_488(v_u_532)
			v_u_532:PivotTo(CFrame.new())
			local v533 = v_u_532.GetBoundingBox
			local v534, v535, v536 = pcall(v533, v_u_532)
			if not v534 then
				v_u_532:Destroy()
				return false
			end
			local v537
			if v536.Z > v536.X then
				v537 = CFrame.Angles(0, 1.5707963267948966, 0)
			else
				v537 = CFrame.identity
			end
			local v538 = v536.X
			local v539 = v536.Z
			local v540 = math.max(v538, v539)
			local v541 = v536.X
			local v542 = v536.Z
			local v543 = math.min(v541, v542)
			local v544 = v536.Y < v540 * 0.5
			local v545
			if v544 then
				v545 = v543 * 0.8660254037844386 + v536.Y * 0.5000000000000001
			else
				v545 = v536.Y
			end
			local v546 = 1 / math.max(v540, 0.05)
			local v547 = 0.95 / math.max(v545, 0.05)
			local v_u_548 = math.min(v546, v547, 3)
			pcall(function()
				-- upvalues: (copy) v_u_532, (copy) v_u_548
				v_u_532:ScaleTo(v_u_532:GetScale() * v_u_548)
			end)
			v_u_532:PivotTo(CFrame.new())
			local v549 = v_u_532.GetBoundingBox
			local _, v550, v551 = pcall(v549, v_u_532)
			local v552
			if typeof(v550) == "CFrame" then
				v552 = v550.Position
			else
				v552 = v535.Position * v_u_548
			end
			if typeof(v551) ~= "Vector3" then
				v551 = v536 * v_u_548
			end
			local v553 = p491 * CFrame.new(0, -0.43, -0.22)
			local v554 = Color3.fromHex("5A4330")
			local v555 = Enum.Material.Wood
			local v556 = Instance.new("Part")
			v556.Name = "TrophyShelf"
			v556.Anchored = true
			v556.CanCollide = false
			v556.CanQuery = false
			v556.CanTouch = false
			v556.CastShadow = false
			v556.Size = Vector3.new(1.06, 0.06, 0.42)
			v556.CFrame = v553
			v556.Color = v554
			v556.Material = v555
			v556.TopSurface = Enum.SurfaceType.Smooth
			v556.BottomSurface = Enum.SurfaceType.Smooth
			v556.Parent = p489
			if not v544 then
				local v557 = -0.4 + v551.Y / 2
				v_u_532:PivotTo(p491 * CFrame.new(0, v557, -0.24) * v537 * CFrame.new(-v552))
				v_u_532.Parent = p489
				return true
			end
			local v558 = v551.X
			local v559 = v551.Z
			local v560 = math.max(v558, v559)
			local v561 = v551.X
			local v562 = v551.Z
			local v563 = math.min(v561, v562)
			local v564 = v551.Y
			local v565 = CFrame.Angles(-1.0471975511965976, 0, 0)
			local v566 = -(v564 / 2 + 0.05)
			local v567 = -(v563 + 0.08) / 2
			local v568 = v566 * 0.5000000000000001 + v567 * 0.8660254037844386
			local _ = -v566 * 0.8660254037844386 + v567 * 0.5000000000000001
			local v569 = -(v564 / 2 + 0.05)
			local v570 = (v563 + 0.08) / 2
			local _ = v569 * 0.5000000000000001 + v570 * 0.8660254037844386
			local v571 = -v569 * 0.8660254037844386 + v570 * 0.5000000000000001
			local v572 = -0.4 - v568
			local v573 = 0.06 - v571
			local v574 = math.min(-0.24, v573)
			local v575 = p491 * CFrame.new(0, v572, v574) * v565
			local v576 = v560 + 0.08
			local v577 = math.min(v576, 1.06)
			local v578 = v563 + 0.08
			local v579 = Vector3.new(v577, 0.05, v578)
			local v580 = v575 * CFrame.new(0, -(v564 / 2 + 0.025), 0)
			local v581 = Color3.fromHex("4A3626")
			local v582 = Enum.Material.Wood
			local v583 = Instance.new("Part")
			v583.Name = "TrophyStand"
			v583.Anchored = true
			v583.CanCollide = false
			v583.CanQuery = false
			v583.CanTouch = false
			v583.CastShadow = false
			v583.Size = v579
			v583.CFrame = v580
			v583.Color = v581
			v583.Material = v582
			v583.TopSurface = Enum.SurfaceType.Smooth
			v583.BottomSurface = Enum.SurfaceType.Smooth
			v583.Parent = p489
			local v584 = v564 * 0.6
			local v585 = math.max(0.08, v584)
			local v586 = Vector3.new(v577, v585, 0.04)
			local v587 = CFrame.new
			local v588 = -v564 / 2
			local v589 = v564 * 0.6
			local v590 = v575 * v587(0, v588 + math.max(0.08, v589) / 2 - 0.025, -(v563 + 0.08) / 2 + 0.02)
			local v591 = Color3.fromHex("3A2A1C")
			local v592 = Enum.Material.Wood
			local v593 = Instance.new("Part")
			v593.Name = "TrophyStandLip"
			v593.Anchored = true
			v593.CanCollide = false
			v593.CanQuery = false
			v593.CanTouch = false
			v593.CastShadow = false
			v593.Size = v586
			v593.CFrame = v590
			v593.Color = v591
			v593.Material = v592
			v593.TopSurface = Enum.SurfaceType.Smooth
			v593.BottomSurface = Enum.SurfaceType.Smooth
			v593.Parent = p489
			v_u_532:PivotTo(v575 * v537 * CFrame.new(-v552))
			v_u_532.Parent = p489
			return true
		end
	end
	return false
end
local function v_u_641(p595, p596, p597) -- name: hangBoss
	local v598 = Color3.fromHex("4A3626")
	local v599 = Color3.fromHex("CFC6AE")
	local v600 = p597 * CFrame.new(0, 0.05, -0.04)
	local v601 = Enum.Material.Wood
	local v602 = Instance.new("Part")
	v602.Name = "BossShield"
	v602.Anchored = true
	v602.CanCollide = false
	v602.CanQuery = false
	v602.CanTouch = false
	v602.CastShadow = false
	v602.Size = Vector3.new(0.92, 1.12, 0.08)
	v602.CFrame = v600
	v602.Color = v598
	v602.Material = v601
	v602.TopSurface = Enum.SurfaceType.Smooth
	v602.BottomSurface = Enum.SurfaceType.Smooth
	v602.Parent = p595
	local v603 = p597 * CFrame.new(0, 0.62, -0.04)
	local v604 = Color3.fromHex("2E2219")
	local v605 = Enum.Material.Wood
	local v606 = Instance.new("Part")
	v606.Name = "BossShieldRim"
	v606.Anchored = true
	v606.CanCollide = false
	v606.CanQuery = false
	v606.CanTouch = false
	v606.CastShadow = false
	v606.Size = Vector3.new(0.98, 0.06, 0.1)
	v606.CFrame = v603
	v606.Color = v604
	v606.Material = v605
	v606.TopSurface = Enum.SurfaceType.Smooth
	v606.BottomSurface = Enum.SurfaceType.Smooth
	v606.Parent = p595
	local v607 = p597 * CFrame.new(0, 0.14, -0.3)
	local v608 = Enum.Material.SmoothPlastic
	local v609 = Enum.PartType.Ball
	local v610 = Instance.new("Part")
	v610.Name = "Skull"
	v610.Anchored = true
	v610.CanCollide = false
	v610.CanQuery = false
	v610.CanTouch = false
	v610.CastShadow = false
	if v609 then
		v610.Shape = v609
	end
	v610.Size = Vector3.new(0.5, 0.5, 0.5)
	v610.CFrame = v607
	v610.Color = v599
	v610.Material = v608
	v610.TopSurface = Enum.SurfaceType.Smooth
	v610.BottomSurface = Enum.SurfaceType.Smooth
	v610.Parent = p595
	local v611 = v607 * CFrame.new(0, -0.24, -0.06)
	local v612 = Enum.Material.SmoothPlastic
	local v613 = Instance.new("Part")
	v613.Name = "Jaw"
	v613.Anchored = true
	v613.CanCollide = false
	v613.CanQuery = false
	v613.CanTouch = false
	v613.CastShadow = false
	v613.Size = Vector3.new(0.3, 0.16, 0.26)
	v613.CFrame = v611
	v613.Color = v599
	v613.Material = v612
	v613.TopSurface = Enum.SurfaceType.Smooth
	v613.BottomSurface = Enum.SurfaceType.Smooth
	v613.Parent = p595
	for _, v614 in { -1, 1 } do
		local v615 = v607 * CFrame.new(v614 * 0.11, 0.02, -0.23)
		local v616 = Color3.fromHex("141414")
		local v617 = Enum.Material.SmoothPlastic
		local v618 = Enum.PartType.Ball
		local v619 = Instance.new("Part")
		v619.Name = "Eye"
		v619.Anchored = true
		v619.CanCollide = false
		v619.CanQuery = false
		v619.CanTouch = false
		v619.CastShadow = false
		if v618 then
			v619.Shape = v618
		end
		v619.Size = Vector3.new(0.13, 0.13, 0.06)
		v619.CFrame = v615
		v619.Color = v616
		v619.Material = v617
		v619.TopSurface = Enum.SurfaceType.Smooth
		v619.BottomSurface = Enum.SurfaceType.Smooth
		v619.Parent = p595
	end
	if p596 == "zombie_boss_surgeon" then
		local v620 = v607 * CFrame.new(0, 0.2, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
		local v621 = Color3.fromHex("6F9C9A")
		local v622 = Enum.Material.Fabric
		local v623 = Enum.PartType.Cylinder
		local v624 = Instance.new("Part")
		v624.Name = "Cap"
		v624.Anchored = true
		v624.CanCollide = false
		v624.CanQuery = false
		v624.CanTouch = false
		v624.CastShadow = false
		if v623 then
			v624.Shape = v623
		end
		v624.Size = Vector3.new(0.12, 0.54, 0.54)
		v624.CFrame = v620
		v624.Color = v621
		v624.Material = v622
		v624.TopSurface = Enum.SurfaceType.Smooth
		v624.BottomSurface = Enum.SurfaceType.Smooth
		v624.Parent = p595
		local v625 = v607 * CFrame.new(0, -0.15, -0.24)
		local v626 = Color3.fromHex("8FB3B0")
		local v627 = Enum.Material.Fabric
		local v628 = Instance.new("Part")
		v628.Name = "Mask"
		v628.Anchored = true
		v628.CanCollide = false
		v628.CanQuery = false
		v628.CanTouch = false
		v628.CastShadow = false
		v628.Size = Vector3.new(0.34, 0.16, 0.05)
		v628.CFrame = v625
		v628.Color = v626
		v628.Material = v627
		v628.TopSurface = Enum.SurfaceType.Smooth
		v628.BottomSurface = Enum.SurfaceType.Smooth
		v628.Parent = p595
	elseif p596 == "zombie_boss_hale" then
		local v629 = v607 * CFrame.new(0, 0.16, 0)
		local v630 = Color3.fromHex("4B5234")
		local v631 = Enum.Material.Metal
		local v632 = Instance.new("Part")
		v632.Name = "Helmet"
		v632.Anchored = true
		v632.CanCollide = false
		v632.CanQuery = false
		v632.CanTouch = false
		v632.CastShadow = false
		v632.Size = Vector3.new(0.58, 0.36, 0.58)
		v632.CFrame = v629
		v632.Color = v630
		v632.Material = v631
		v632.TopSurface = Enum.SurfaceType.Smooth
		v632.BottomSurface = Enum.SurfaceType.Smooth
		v632.Parent = p595
		local v633 = v607 * CFrame.new(0, 0, 0)
		local v634 = Color3.fromHex("363B26")
		local v635 = Enum.Material.Metal
		local v636 = Instance.new("Part")
		v636.Name = "Brim"
		v636.Anchored = true
		v636.CanCollide = false
		v636.CanQuery = false
		v636.CanTouch = false
		v636.CastShadow = false
		v636.Size = Vector3.new(0.66, 0.05, 0.66)
		v636.CFrame = v633
		v636.Color = v634
		v636.Material = v635
		v636.TopSurface = Enum.SurfaceType.Smooth
		v636.BottomSurface = Enum.SurfaceType.Smooth
		v636.Parent = p595
	end
	local v637 = p597 * CFrame.new(0, -0.38, -0.1)
	local v638 = Color3.fromHex("A33A32")
	local v639 = Enum.Material.Plastic
	local v640 = Instance.new("Part")
	v640.Name = "BossTag"
	v640.Anchored = true
	v640.CanCollide = false
	v640.CanQuery = false
	v640.CanTouch = false
	v640.CastShadow = false
	v640.Size = Vector3.new(0.5, 0.08, 0.03)
	v640.CFrame = v637
	v640.Color = v638
	v640.Material = v639
	v640.TopSurface = Enum.SurfaceType.Smooth
	v640.BottomSurface = Enum.SurfaceType.Smooth
	v640.Parent = p595
end
local function v_u_672(p642, p643, p644, p645) -- name: hangPlate
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_485, (copy) v_u_7
	local v646 = v_u_11
	if not v646 then
		local v_u_647 = "Items"
		local function v648()
			-- upvalues: (ref) v_u_2, (copy) v_u_647
			return require((v_u_2:WaitForChild(v_u_647, 5)))
		end
		local v649
		v649, v646 = pcall(v648)
		if not v649 then
			v646 = nil
		end
	end
	v_u_11 = v646
	local v650 = v_u_12
	if not v650 then
		local v_u_651 = "HideoutModules"
		local function v652()
			-- upvalues: (ref) v_u_2, (copy) v_u_651
			return require((v_u_2:WaitForChild(v_u_651, 5)))
		end
		local v653
		v653, v650 = pcall(v652)
		if not v653 then
			v650 = nil
		end
	end
	v_u_12 = v650
	local v654 = v_u_13
	if not v654 then
		local v_u_655 = "Factions"
		local function v656()
			-- upvalues: (ref) v_u_2, (copy) v_u_655
			return require((v_u_2:WaitForChild(v_u_655, 5)))
		end
		local v657
		v657, v654 = pcall(v656)
		if not v657 then
			v654 = nil
		end
	end
	v_u_13 = v654
	local v658 = v_u_3.info(p643, p644)
	local v659 = p645 * CFrame.new(0, 0.05, -0.03)
	local v660 = Color3.fromHex("3A2A1C")
	local v661 = Enum.Material.Wood
	local v662 = Instance.new("Part")
	v662.Name = "PlateBack"
	v662.Anchored = true
	v662.CanCollide = false
	v662.CanQuery = false
	v662.CanTouch = false
	v662.CastShadow = false
	v662.Size = Vector3.new(1.14, 0.86, 0.05)
	v662.CFrame = v659
	v662.Color = v660
	v662.Material = v661
	v662.TopSurface = Enum.SurfaceType.Smooth
	v662.BottomSurface = Enum.SurfaceType.Smooth
	v662.Parent = p642
	local v663 = p645 * CFrame.new(0, 0.05, -0.07)
	local v664 = v_u_5
	local v665 = Enum.Material.Metal
	local v666 = Instance.new("Part")
	v666.Name = "Plate"
	v666.Anchored = true
	v666.CanCollide = false
	v666.CanQuery = false
	v666.CanTouch = false
	v666.CastShadow = false
	v666.Size = Vector3.new(1, 0.72, 0.03)
	v666.CFrame = v663
	v666.Color = v664
	v666.Material = v665
	v666.TopSurface = Enum.SurfaceType.Smooth
	v666.BottomSurface = Enum.SurfaceType.Smooth
	v666.Parent = p642
	local v667 = v_u_13 and v_u_13.get
	if v667 then
		v667 = v_u_13.get(v658.faction or "")
	end
	local v668 = p645 * CFrame.new(0, 0.38, -0.075)
	local v669
	if v667 then
		v669 = v667.color
	else
		v669 = v_u_6
	end
	local v670 = Enum.Material.Metal
	local v671 = Instance.new("Part")
	v671.Name = "PlateStripe"
	v671.Anchored = true
	v671.CanCollide = false
	v671.CanQuery = false
	v671.CanTouch = false
	v671.CastShadow = false
	v671.Size = Vector3.new(1, 0.07, 0.035)
	v671.CFrame = v668
	v671.Color = v669
	v671.Material = v670
	v671.TopSurface = Enum.SurfaceType.Smooth
	v671.BottomSurface = Enum.SurfaceType.Smooth
	v671.Parent = p642
	v_u_485(v666, { not v658.week and "WEEKLY" or ("WEEK %d"):format(v658.week), v658.short }, v_u_7)
end
local function v_u_708(p673, p674) -- name: extendBoard
	local v675 = p673:FindFirstChild("WallExt")
	if v675 then
		v675:Destroy()
	end
	if p674 > 12 and not p673:FindFirstChild("Slot_13", true) then
		local v676 = p673:GetPivot()
		local v677 = Instance.new("Model")
		v677.Name = "WallExt"
		local v678 = Color3.fromHex("8C7A5E")
		local v679 = Color3.fromHex("5A4330")
		local v680 = Color3.fromHex("5A5F66")
		local v681 = Enum.Material.Wood
		local v682 = v676 * CFrame.new(Vector3.new(-8.4, 5.5, 0.4))
		local v683 = Instance.new("Part")
		v683.Name = "Pegboard"
		v683.Anchored = true
		v683.CanCollide = false
		v683.CanQuery = false
		v683.CanTouch = false
		v683.CastShadow = false
		v683.Size = Vector3.new(8, 4.4, 0.2)
		v683.CFrame = v682
		v683.Color = v678
		v683.Material = v681
		v683.TopSurface = Enum.SurfaceType.Smooth
		v683.BottomSurface = Enum.SurfaceType.Smooth
		v683.Parent = v677
		local v684 = Enum.Material.Wood
		local v685 = v676 * CFrame.new(Vector3.new(-12.5, 5.5, 0.36))
		local v686 = Instance.new("Part")
		v686.Name = "Post"
		v686.Anchored = true
		v686.CanCollide = false
		v686.CanQuery = false
		v686.CanTouch = false
		v686.CastShadow = false
		v686.Size = Vector3.new(0.25, 4.6, 0.32)
		v686.CFrame = v685
		v686.Color = v679
		v686.Material = v684
		v686.TopSurface = Enum.SurfaceType.Smooth
		v686.BottomSurface = Enum.SurfaceType.Smooth
		v686.Parent = v677
		local v687 = Enum.Material.Wood
		local v688 = v676 * CFrame.new(Vector3.new(-8.4, 7.8, 0.36))
		local v689 = Instance.new("Part")
		v689.Name = "Rail"
		v689.Anchored = true
		v689.CanCollide = false
		v689.CanQuery = false
		v689.CanTouch = false
		v689.CastShadow = false
		v689.Size = Vector3.new(8.4, 0.25, 0.32)
		v689.CFrame = v688
		v689.Color = v679
		v689.Material = v687
		v689.TopSurface = Enum.SurfaceType.Smooth
		v689.BottomSurface = Enum.SurfaceType.Smooth
		v689.Parent = v677
		local v690 = Enum.Material.Wood
		local v691 = v676 * CFrame.new(Vector3.new(-8.4, 3.2, 0))
		local v692 = Instance.new("Part")
		v692.Name = "Shelf"
		v692.Anchored = true
		v692.CanCollide = false
		v692.CanQuery = false
		v692.CanTouch = false
		v692.CastShadow = false
		v692.Size = Vector3.new(8.2, 0.2, 1)
		v692.CFrame = v691
		v692.Color = v679
		v692.Material = v690
		v692.TopSurface = Enum.SurfaceType.Smooth
		v692.BottomSurface = Enum.SurfaceType.Smooth
		v692.Parent = v677
		for v693 = 0, math.min(p674, 24) - 13 do
			local v694 = v693 % 6
			local v695 = v693 / 6
			local v696 = math.floor(v695)
			local v697 = v694 * 1.24 + -11.5
			local v698 = 6.3 - v696 * 1.8
			local v699 = Vector3.new(v697, v698, 0.2)
			local v700 = v699 + Vector3.new(0, 0.5, 0)
			local v701 = Enum.Material.Metal
			local v702 = v676 * CFrame.new(v700)
			local v703 = Instance.new("Part")
			v703.Name = "Hook"
			v703.Anchored = true
			v703.CanCollide = false
			v703.CanQuery = false
			v703.CanTouch = false
			v703.CastShadow = false
			v703.Size = Vector3.new(0.08, 0.08, 0.3)
			v703.CFrame = v702
			v703.Color = v680
			v703.Material = v701
			v703.TopSurface = Enum.SurfaceType.Smooth
			v703.BottomSurface = Enum.SurfaceType.Smooth
			v703.Parent = v677
			local v704 = Enum.Material.Metal
			local v705 = v676 * CFrame.new(v699)
			local v706 = Instance.new("Part")
			v706.Name = "SlotAnchor"
			v706.Anchored = true
			v706.CanCollide = false
			v706.CanQuery = false
			v706.CanTouch = false
			v706.CastShadow = false
			v706.Size = Vector3.new(0.1, 0.1, 0.1)
			v706.CFrame = v705
			v706.Color = v680
			v706.Material = v704
			v706.TopSurface = Enum.SurfaceType.Smooth
			v706.BottomSurface = Enum.SurfaceType.Smooth
			v706.Parent = v677
			v706.Transparency = 1
			local v707 = Instance.new("Attachment")
			v707.Name = "Slot_" .. v693 + 13
			v707.Parent = v706
		end
		v677.Parent = p673
	end
end
function v_u_3.hang(p709, p710) -- name: hang
	-- upvalues: (ref) v_u_11, (copy) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_3, (copy) v_u_708, (copy) v_u_485, (copy) v_u_7, (copy) v_u_672, (copy) v_u_641, (copy) v_u_594, (copy) v_u_5
	local v711 = v_u_11
	if not v711 then
		local v_u_712 = "Items"
		local function v713()
			-- upvalues: (ref) v_u_2, (copy) v_u_712
			return require((v_u_2:WaitForChild(v_u_712, 5)))
		end
		local v714
		v714, v711 = pcall(v713)
		if not v714 then
			v711 = nil
		end
	end
	v_u_11 = v711
	local v715 = v_u_12
	if not v715 then
		local v_u_716 = "HideoutModules"
		local function v717()
			-- upvalues: (ref) v_u_2, (copy) v_u_716
			return require((v_u_2:WaitForChild(v_u_716, 5)))
		end
		local v718
		v718, v715 = pcall(v717)
		if not v718 then
			v715 = nil
		end
	end
	v_u_12 = v715
	local v719 = v_u_13
	if not v719 then
		local v_u_720 = "Factions"
		local function v721()
			-- upvalues: (ref) v_u_2, (copy) v_u_720
			return require((v_u_2:WaitForChild(v_u_720, 5)))
		end
		local v722
		v722, v719 = pcall(v721)
		if not v722 then
			v719 = nil
		end
	end
	v_u_13 = v719
	local v723 = v_u_3.data(p710)
	if v723.slots > 0 then
		local v724 = p709:FindFirstChild("Trophies")
		if v724 then
			v724:Destroy()
		end
		v_u_708(p709, v723.slots)
		local v725 = Instance.new("Model")
		v725.Name = "Trophies"
		local v726 = false
		local v727 = p709:FindFirstChild("Plaque", true)
		if v727 and (v727:IsA("BasePart") and not v727:FindFirstChildOfClass("SurfaceGui")) then
			v_u_485(v727, { "TROPHY WALL" }, v_u_7)
		end
		local v728 = p709.GetBoundingBox
		local v_u_729, v_u_730, v_u_731 = pcall(v728, p709)
		local v_u_732 = p709:GetPivot()
		local function v740(p733) -- name: slotBase
			-- upvalues: (copy) v_u_729, (copy) v_u_730, (copy) v_u_731, (copy) v_u_732
			local v734 = p733.WorldCFrame
			if v_u_729 then
				local v735 = v_u_730:PointToObjectSpace(v734.Position)
				local v736 = v_u_731 / 2 + Vector3.new(0.3, 0.3, 0.3)
				local v737 = v735.X
				if math.abs(v737) > v736.X then
					return v_u_732 * CFrame.new(p733.Position)
				else
					local v738 = v735.Y
					if math.abs(v738) > v736.Y then
						return v_u_732 * CFrame.new(p733.Position)
					else
						local v739 = v735.Z
						if math.abs(v739) > v736.Z then
							return v_u_732 * CFrame.new(p733.Position)
						else
							return CFrame.new(v734.Position) * v_u_732.Rotation
						end
					end
				end
			else
				return CFrame.new(v734.Position) * v_u_732.Rotation
			end
		end
		for v741 = 1, v723.slots do
			local v742 = v723.placed[v741]
			local v743 = p709:FindFirstChild("Slot_" .. v741, true)
			if v742 == nil or (v742 == "" or not (v743 and v743:IsA("Attachment"))) then
				continue
			end
			local v744 = v740(v743)
			local v745 = v723.byKey[v742]
			local v746 = v_u_3.info(v742, v745)
			if v746.kind == "plate" then
				v_u_672(v725, v742, v745, v744)
			elseif v746.kind == "boss" then
				v_u_641(v725, v742, v744)
			else
				local v747 = v_u_594
				local v748
				if v746.kind == "stash" then
					local v749 = v746.id
					v748 = tostring(v749)
				else
					v748 = v742
				end
				if not v747(v725, v748, v744) then
					v_u_672(v725, v742, {
						["kind"] = "plate",
						["text"] = nil,
						["text"] = v746.name
					}, v744)
				end
			end
			local v750 = v744 * CFrame.new(0, -0.66, -0.05)
			local v751 = v_u_5
			local v752 = Enum.Material.Metal
			local v753 = Instance.new("Part")
			v753.Name = "NameStrip"
			v753.Anchored = true
			v753.CanCollide = false
			v753.CanQuery = false
			v753.CanTouch = false
			v753.CastShadow = false
			v753.Size = Vector3.new(1, 0.17, 0.03)
			v753.CFrame = v750
			v753.Color = v751
			v753.Material = v752
			v753.TopSurface = Enum.SurfaceType.Smooth
			v753.BottomSurface = Enum.SurfaceType.Smooth
			v753.Parent = v725
			v_u_485(v753, { v746.kind == "plate" and "CHAMPIONS" or string.upper(v746.short) }, v_u_7)
			v726 = true
		end
		if v726 then
			local v754 = p709:FindFirstChild("Slot_1", true)
			if v754 and v754:IsA("Attachment") then
				local v755 = p709:GetPivot()
				for v756, v757 in v723.slots > 12 and { 0, -8.4 } or { 0 } do
					local v758 = v755 * CFrame.new(v757, 8.25, -0.25)
					local v759 = v756 == 1 and "PictureLamp" or "PictureLamp" .. v756
					local v760 = Color3.fromHex("3B3F45")
					local v761 = Enum.Material.Metal
					local v762 = Instance.new("Part")
					v762.Name = v759
					v762.Anchored = true
					v762.CanCollide = false
					v762.CanQuery = false
					v762.CanTouch = false
					v762.CastShadow = false
					v762.Size = Vector3.new(3.4, 0.14, 0.22)
					v762.CFrame = v758
					v762.Color = v760
					v762.Material = v761
					v762.TopSurface = Enum.SurfaceType.Smooth
					v762.BottomSurface = Enum.SurfaceType.Smooth
					v762.Parent = v725
					local v763 = v756 == 1 and "PictureLampGlow" or "PictureLampGlow" .. v756
					local v764 = v758 * CFrame.new(0, -0.08, 0)
					local v765 = Color3.fromHex("FFE3B0")
					local v766 = Enum.Material.Neon
					local v767 = Instance.new("Part")
					v767.Name = v763
					v767.Anchored = true
					v767.CanCollide = false
					v767.CanQuery = false
					v767.CanTouch = false
					v767.CastShadow = false
					v767.Size = Vector3.new(3.2, 0.04, 0.12)
					v767.CFrame = v764
					v767.Color = v765
					v767.Material = v766
					v767.TopSurface = Enum.SurfaceType.Smooth
					v767.BottomSurface = Enum.SurfaceType.Smooth
					v767.Parent = v725
					v767.Transparency = 0.2
					local v768 = Instance.new("SpotLight")
					v768.Face = Enum.NormalId.Bottom
					v768.Angle = 100
					v768.Range = 9
					v768.Brightness = 1.3
					v768.Color = Color3.fromHex("FFD9A0")
					v768.Shadows = false
					v768.Parent = v762
				end
			end
		end
		v725.Parent = p709
	end
end
return v_u_3