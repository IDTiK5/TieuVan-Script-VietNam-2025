-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPhotoHide

local v_u_1 = require(script.Parent:WaitForChild("MRProxyView"))
local v2 = {}
local v_u_3 = {
	"Light",
	"SurfaceGui",
	"BillboardGui",
	"Beam",
	"ParticleEmitter",
	"Trail",
	"Fire",
	"Smoke",
	"Sparkles"
}
local v_u_4 = {
	["parts"] = nil,
	["partSeen"] = nil,
	["off"] = nil,
	["offSeen"] = nil,
	["parked"] = nil,
	["parkSeen"] = nil,
	["conns"] = nil,
	["rainForced"] = nil,
	["rainSeen"] = nil,
	["rainWant"] = nil,
	["rainConns"] = nil,
	["rainToken"] = 0,
	["parts"] = {},
	["partSeen"] = {},
	["off"] = {},
	["offSeen"] = {},
	["parked"] = {},
	["parkSeen"] = {},
	["conns"] = {},
	["rainForced"] = {},
	["rainSeen"] = {},
	["rainWant"] = {},
	["rainConns"] = {}
}
local function v_u_13(p_u_5, p6) -- name: hideOne
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	if p_u_5:IsA("BasePart") then
		if not v_u_4.partSeen[p_u_5] then
			v_u_4.partSeen[p_u_5] = true
			local v7 = v_u_4.parts
			table.insert(v7, p_u_5)
		end
		p_u_5.LocalTransparencyModifier = 1
	elseif not p6 then
		for _, v8 in v_u_3 do
			if not p_u_5:IsA(v8) then
				continue
			end
			v9 = true
		end
		local v9 = false
		if v9 and not v_u_4.offSeen[p_u_5] then
			local v10, v11 = pcall(function()
				-- upvalues: (copy) p_u_5
				return p_u_5.Enabled
			end)
			if v10 and v11 == true then
				v_u_4.offSeen[p_u_5] = true
				local v12 = v_u_4.off
				table.insert(v12, p_u_5)
				pcall(function()
					-- upvalues: (copy) p_u_5
					p_u_5.Enabled = false
				end)
			end
		end
	end
end
function v2.tree(p14, p15) -- name: tree
	-- upvalues: (copy) v_u_13
	v_u_13(p14, p15)
	for _, v16 in p14:GetDescendants() do
		v_u_13(v16, p15)
	end
end
local function v_u_25(p17, p18, p19) -- name: park
	-- upvalues: (copy) v_u_4
	if not v_u_4.parkSeen[p17] then
		local v20 = p17.Name
		if string.sub(v20, 1, 8) == "Extract_" then
			local v21 = p17:FindFirstChild("Base")
			local v22
			if v21 and v21:IsA("BasePart") then
				v22 = v21.Position
			elseif p17:IsA("Model") then
				v22 = p17:GetPivot().Position
			else
				v22 = nil
			end
			if v22 and p19 >= Vector2.new(v22.X - p18.X, v22.Z - p18.Z).Magnitude then
				v_u_4.parkSeen[p17] = true
				local v23 = v_u_4.parked
				local v24 = {
					["model"] = p17,
					["parent"] = p17.Parent
				}
				table.insert(v23, v24)
				p17.Parent = nil
			end
		end
	end
end
function v2.extracts(p_u_26, p_u_27) -- name: extracts
	-- upvalues: (copy) v_u_25, (copy) v_u_4
	local v_u_28 = workspace:FindFirstChild("HushLocal")
	if v_u_28 then
		v_u_28 = v_u_28:FindFirstChild("RaidFx")
	end
	if v_u_28 then
		for _, v29 in v_u_28:GetChildren() do
			v_u_25(v29, p_u_26, p_u_27)
		end
		if not v_u_4.parkSeen[v_u_28] then
			v_u_4.parkSeen[v_u_28] = true
			local v30 = v_u_4.conns
			local v31 = v_u_28.ChildAdded
			local function v33(p_u_32)
				-- upvalues: (copy) v_u_28, (ref) v_u_25, (copy) p_u_26, (copy) p_u_27
				task.defer(function()
					-- upvalues: (copy) p_u_32, (ref) v_u_28, (ref) v_u_25, (ref) p_u_26, (ref) p_u_27
					if p_u_32.Parent == v_u_28 then
						v_u_25(p_u_32, p_u_26, p_u_27)
					end
				end)
			end
			table.insert(v30, v31:Connect(v33))
		end
	end
end
local function v_u_39(p_u_34) -- name: holdRain
	-- upvalues: (copy) v_u_4
	if p_u_34:IsA("ParticleEmitter") and not v_u_4.rainSeen[p_u_34] then
		v_u_4.rainSeen[p_u_34] = true
		local v35 = v_u_4.rainForced
		table.insert(v35, p_u_34)
		v_u_4.rainWant[p_u_34] = p_u_34.Enabled
		p_u_34.Enabled = false
		p_u_34:Clear()
		local v36 = v_u_4.rainConns
		local v37 = p_u_34:GetPropertyChangedSignal("Enabled")
		local function v38()
			-- upvalues: (copy) p_u_34, (ref) v_u_4
			if p_u_34.Enabled then
				v_u_4.rainWant[p_u_34] = true
				p_u_34.Enabled = false
			end
		end
		table.insert(v36, v37:Connect(v38))
	end
end
local function v_u_46() -- name: releaseRain
	-- upvalues: (copy) v_u_4
	local v40 = v_u_4
	v40.rainToken = v40.rainToken + 1
	for _, v41 in v_u_4.rainConns do
		v41:Disconnect()
	end
	v_u_4.rainConns = {}
	local v42 = game:GetService("Players").LocalPlayer:GetAttribute("AtmoWeather")
	local v43 = v42 == "Rain" and true or v42 == "Storm"
	for _, v44 in v_u_4.rainForced do
		if not v44.Parent then
			continue
		end
		local v45
		if v43 then
			v45 = v_u_4.rainWant[v44] == true
		else
			v45 = v43
		end
		v44.Enabled = v45
	end
	v_u_4.rainForced = {}
	v_u_4.rainSeen = {}
	v_u_4.rainWant = {}
end
function v2.rain(p47) -- name: rain
	-- upvalues: (copy) v_u_46, (copy) v_u_39, (copy) v_u_4
	v_u_46()
	local v48 = workspace:FindFirstChild("HushLocal")
	if v48 then
		v48 = v48:FindFirstChild("Atmosphere")
	end
	if v48 then
		v48 = v48:FindFirstChild("Rain")
	end
	if v48 then
		for _, v49 in v48:GetDescendants() do
			v_u_39(v49)
		end
		local v50 = v_u_4.rainConns
		local v51 = v48.DescendantAdded
		local v52 = v_u_39
		table.insert(v50, v51:Connect(v52))
		local v_u_53 = v_u_4.rainToken
		task.delay(p47, function()
			-- upvalues: (copy) v_u_53, (ref) v_u_4, (ref) v_u_46
			if v_u_53 == v_u_4.rainToken then
				v_u_46()
			end
		end)
	end
end
function v2.restore() -- name: restore
	-- upvalues: (copy) v_u_4, (copy) v_u_46, (copy) v_u_1
	for _, v54 in v_u_4.conns do
		v54:Disconnect()
	end
	v_u_4.conns = {}
	v_u_46()
	for _, v55 in v_u_4.parts do
		v55.LocalTransparencyModifier = v_u_1.clampLtm(v55, 0)
	end
	for _, v_u_56 in v_u_4.off do
		pcall(function()
			-- upvalues: (copy) v_u_56
			v_u_56.Enabled = true
		end)
	end
	for _, v57 in v_u_4.parked do
		local v_u_58 = v57.model
		local v_u_59 = v57.parent
		if v_u_59 and v_u_59:IsDescendantOf(workspace) then
			pcall(function()
				-- upvalues: (copy) v_u_58, (copy) v_u_59
				v_u_58.Parent = v_u_59
			end)
		else
			pcall(function()
				-- upvalues: (copy) v_u_58
				v_u_58:Destroy()
			end)
		end
	end
	local v60 = v_u_4
	local v61 = v_u_4
	local v62 = v_u_4
	local v63 = v_u_4
	local v64 = v_u_4
	v_u_4.parts = {}
	v60.partSeen = {}
	v61.off = {}
	v62.offSeen = {}
	v63.parked = {}
	v64.parkSeen = {}
end
function v2.stats() -- name: stats
	-- upvalues: (copy) v_u_4
	return {
		["parts"] = #v_u_4.parts,
		["off"] = #v_u_4.off,
		["parked"] = #v_u_4.parked,
		["rain"] = #v_u_4.rainForced
	}
end
return v2