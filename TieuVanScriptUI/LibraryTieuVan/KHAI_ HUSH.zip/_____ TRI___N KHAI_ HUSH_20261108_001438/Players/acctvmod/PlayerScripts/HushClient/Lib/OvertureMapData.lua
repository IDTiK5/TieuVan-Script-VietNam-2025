-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / OvertureMapData

local v_u_15 = {
	["ID"] = "overture",
	["HALF"] = 560,
	["RING"] = 520,
	["SHORE"] = 500,
	["CELL"] = 160,
	["STUDS_TO_M"] = 0.28,
	["FIELD"] = {
		-520,
		-520,
		520,
		500
	},
	["WATER"] = {
		-560,
		500,
		560,
		560
	},
	["BEACH"] = {
		-560,
		480,
		560,
		500
	},
	["PIERS"] = {
		{
			"marina",
			"Marina Dock",
			-30,
			496,
			10,
			522
		},
		{
			"pier3",
			"Pier 3",
			268,
			496,
			316,
			524
		},
		{
			"mole",
			"Lighthouse Mole",
			480,
			496,
			496,
			524
		}
	},
	["ROADS"] = {
		{
			-520,
			328,
			520,
			352,
			"Harbor Street",
			"main",
			"x",
			24
		},
		{
			-500,
			438,
			500,
			458,
			"Lakeshore Drive",
			"street",
			"x",
			20
		},
		{
			-480,
			248,
			480,
			264,
			"Bluff Road",
			"street",
			"x",
			16
		},
		{
			-480,
			-498,
			300,
			-478,
			"Loading Road",
			"service",
			"x",
			20
		},
		{
			-348,
			-488,
			-332,
			448,
			"Vesper Lane",
			"street",
			"z",
			16
		},
		{
			416,
			-440,
			432,
			448,
			"Dock Lane",
			"street",
			"z",
			16
		},
		{
			-332,
			-308,
			-124,
			-292,
			"Vesper Row",
			"street",
			"x",
			16
		}
	},
	["RAIL"] = {
		{
			452,
			-330,
			460,
			480,
			"Freight Line",
			"z"
		},
		{
			332,
			476,
			456,
			484,
			"Pier Spur",
			"x"
		}
	},
	["PLAZA"] = {
		-160,
		-60,
		160,
		222
	},
	["FOUNTAIN"] = { 0, 80, 16 },
	["STAGE"] = {
		-100,
		10,
		44,
		26
	},
	["WALL"] = {
		-520,
		222,
		520,
		232
	},
	["WALL_GAPS"] = {
		{ "vesper_lane", -340, 16 },
		{ "bluff_stairs", -130, 20 },
		{ "service_ramp", 130, 20 },
		{ "dock_lane", 424, 16 },
		{ "rail_cut", 456, 8 }
	},
	["RING_GAPS"] = {
		{
			"N",
			-300,
			14,
			"cut"
		},
		{
			"N",
			200,
			14,
			"cut"
		},
		{
			"N",
			380,
			18,
			"gate"
		},
		{
			"W",
			-420,
			10,
			"cut"
		},
		{
			"W",
			-200,
			12,
			"cut"
		},
		{
			"W",
			80,
			12,
			"cut"
		},
		{
			"W",
			340,
			24,
			"locked"
		},
		{
			"W",
			440,
			10,
			"cut"
		},
		{
			"E",
			-120,
			12,
			"cut"
		},
		{
			"E",
			100,
			28,
			"gate"
		},
		{
			"E",
			330,
			14,
			"cut"
		},
		{
			"E",
			460,
			12,
			"cut"
		}
	},
	["LOTS"] = {
		{
			"s_boathouse",
			"Boathouse",
			"waterfront",
			-380,
			480,
			36,
			28,
			0,
			"Tacet Boathouse",
			"S"
		},
		{
			"s_harbormaster",
			"Checkpoint",
			"waterfront",
			-260,
			480,
			44,
			32,
			0,
			"Harbormaster",
			"S"
		},
		{
			"s_marina_club",
			"Office",
			"waterfront",
			-140,
			480,
			48,
			28,
			0,
			"Vesper Marina Club",
			"S"
		},
		{
			"s_marina_gas",
			"GasStation",
			"waterfront",
			-60,
			476,
			28,
			24,
			0,
			"Marina Fuel",
			"S"
		},
		{
			"s_pier_shed",
			"Warehouse",
			"waterfront",
			296,
			480,
			64,
			32,
			0,
			"Tacet Marine Pier 3",
			"S"
		},
		{
			"s_lighthouse",
			"Lighthouse",
			"waterfront",
			488,
			484,
			16,
			16,
			0,
			"Vesper Light",
			"S"
		},
		{
			"n_ferry",
			"Office",
			"waterfront",
			-420,
			414,
			44,
			32,
			2,
			"Vesper Ferry Office",
			"S"
		},
		{
			"n_fish",
			"Shop",
			"waterfront",
			-301,
			414,
			30,
			28,
			2,
			"Fish Market",
			"S"
		},
		{
			"n_yacht",
			"Office",
			"waterfront",
			-160,
			414,
			56,
			32,
			2,
			"Yacht Club",
			"S"
		},
		{
			"n_motel",
			"Motel",
			"waterfront",
			-19,
			413,
			62,
			22,
			2,
			"Lakeview Motel",
			"S"
		},
		{
			"h1_hardware",
			"Hardware",
			"harbor",
			-430,
			374,
			36,
			32,
			0,
			"Hallam Hardware",
			"S"
		},
		{
			"h1_barber",
			"Shop",
			"harbor",
			-385,
			372,
			30,
			28,
			0,
			"Barber",
			"S"
		},
		{
			"h1_diner",
			"Diner",
			"harbor",
			-296,
			373,
			40,
			30,
			0,
			"Vesper Diner",
			"S"
		},
		{
			"h1_bank",
			"Office",
			"harbor",
			-230,
			374,
			44,
			32,
			0,
			"Port Vesper Savings",
			"S"
		},
		{
			"h1_books",
			"Shop",
			"harbor",
			-171,
			372,
			30,
			28,
			0,
			"Books",
			"S"
		},
		{
			"h1_store",
			"Shop",
			"harbor",
			-100,
			374,
			44,
			32,
			0,
			"Tacet Employee Store",
			"S"
		},
		{
			"h2_pharmacy",
			"Pharmacy",
			"harbor",
			-430,
			302,
			40,
			36,
			2,
			"Vesper Pharmacy",
			"S"
		},
		{
			"h2_post",
			"Office",
			"harbor",
			-380,
			302,
			44,
			32,
			2,
			"Post Office",
			"S"
		},
		{
			"h2_hotel",
			"Motel",
			"harbor",
			-231,
			301,
			62,
			22,
			2,
			"Hotel Vesper",
			"S"
		},
		{
			"h2_laundry",
			"Shop",
			"harbor",
			-121,
			300,
			30,
			28,
			2,
			"Laundromat",
			"S"
		},
		{
			"h1_electronics",
			"Shop",
			"harbor",
			-41,
			372,
			30,
			28,
			0,
			"Electronics",
			"S"
		},
		{
			"h1_garage",
			"Garage",
			"harbor",
			20,
			373,
			36,
			30,
			0,
			"Vesper Auto",
			"S"
		},
		{
			"h1_pub",
			"Diner",
			"harbor",
			90,
			373,
			40,
			30,
			0,
			"Pier Pub",
			"S"
		},
		{
			"h2_market",
			"Supermarket",
			"harbor",
			100,
			295,
			64,
			50,
			2,
			"Vesper Market",
			"S"
		},
		{
			"h2_church",
			"Church",
			"harbor",
			190,
			297,
			32,
			46,
			2,
			"St Brendan",
			"S"
		},
		{
			"h2_credit",
			"Office",
			"harbor",
			280,
			302,
			44,
			32,
			2,
			"Tacet Credit Union",
			"S"
		},
		{
			"n_cannery",
			"Warehouse",
			"waterfront",
			100,
			414,
			64,
			32,
			2,
			"Vesper Cannery",
			"S"
		},
		{
			"n_customs",
			"Checkpoint",
			"waterfront",
			220,
			414,
			36,
			28,
			2,
			"Customs House",
			"S"
		},
		{
			"s_boatyard",
			"Warehouse",
			"waterfront",
			100,
			480,
			56,
			32,
			0,
			"Vesper Boatyard",
			"S"
		},
		{
			"army_w",
			"Checkpoint",
			"lakegate",
			-486,
			372,
			28,
			20,
			0,
			"Lakeshore Post",
			"S"
		},
		{
			"army_hq",
			"Checkpoint",
			"lakegate",
			-440,
			110,
			32,
			48,
			3,
			"Lakeshore Det HQ",
			"S"
		},
		{
			"army_e",
			"Checkpoint",
			"lakegate",
			486,
			372,
			28,
			20,
			0,
			"Lakeshore Post",
			"S"
		},
		{
			"v_pavilion",
			"Pavilion",
			"pavilion",
			0,
			188,
			96,
			48,
			0,
			"Tacet Experience",
			"S"
		},
		{
			"nw_lobby",
			"Office",
			"lobby",
			0,
			-122,
			160,
			64,
			2,
			"North Wing",
			"P"
		},
		{
			"core_u1",
			"Stair",
			"lobby",
			-48,
			-170,
			16,
			16,
			2,
			"Stairs down",
			"P>U1"
		},
		{
			"nw_legal",
			"Office",
			"legal",
			-48,
			-214,
			80,
			56,
			2,
			"Legal and Liaison",
			"U1"
		},
		{
			"core_u2",
			"Stair",
			"stacks",
			-48,
			-258,
			16,
			16,
			2,
			"Stairs down",
			"U1>U2"
		},
		{
			"nw_stacks",
			"Records",
			"stacks",
			-48,
			-310,
			112,
			72,
			2,
			"The Stacks",
			"U2"
		},
		{
			"core_t",
			"Stair",
			"lobby",
			64,
			-170,
			16,
			16,
			2,
			"Stairs up",
			"P>T"
		},
		{
			"nw_founders",
			"Office",
			"topfloor",
			96,
			-222,
			112,
			72,
			2,
			"Founders\' Floor",
			"T"
		},
		{
			"core_roof",
			"Stair",
			"topfloor",
			96,
			-274,
			16,
			16,
			2,
			"Roof access",
			"T>R"
		},
		{
			"nw_roof",
			"Roof",
			"topfloor",
			96,
			-318,
			72,
			56,
			2,
			"Air Pad",
			"R"
		},
		{
			"nw_garage",
			"Garage",
			"garage",
			248,
			-230,
			56,
			128,
			1,
			"Tacet Service Garage",
			"G"
		},
		{
			"core_p",
			"Stair",
			"topfloor",
			168,
			-222,
			16,
			16,
			1,
			"Private stair",
			"G>T"
		},
		{
			"svc_tunnel",
			"Tunnel",
			"tunnel",
			252,
			-121,
			16,
			74,
			0,
			"Service Tunnel",
			"G>F"
		},
		{
			"r_a1",
			"House",
			"homes",
			-306,
			-333,
			36,
			34,
			2,
			"Staff Home",
			"S"
		},
		{
			"r_b1",
			"House",
			"homes",
			-251,
			-329,
			30,
			26,
			2,
			"Staff Home",
			"S"
		},
		{
			"r_c1",
			"House",
			"homes",
			-198,
			-332,
			40,
			32,
			2,
			"Staff Home",
			"S"
		},
		{
			"r_d1",
			"House",
			"homes",
			-143,
			-328,
			26,
			24,
			2,
			"Staff Home",
			"S"
		},
		{
			"r_a2",
			"House",
			"homes",
			-306,
			-267,
			36,
			34,
			0,
			"Staff Home",
			"S"
		},
		{
			"r_b2",
			"House",
			"homes",
			-251,
			-271,
			30,
			26,
			0,
			"Staff Home",
			"S"
		},
		{
			"r_c2",
			"House",
			"homes",
			-198,
			-268,
			40,
			32,
			0,
			"Staff Home",
			"S"
		},
		{
			"r_d2",
			"House",
			"homes",
			-143,
			-272,
			26,
			24,
			0,
			"Staff Home",
			"S"
		},
		{
			"y_clinic",
			"Clinic",
			"northband",
			-200,
			-440,
			56,
			40,
			2,
			"Occupational Health",
			"S"
		},
		{
			"y_fleet",
			"Garage",
			"northband",
			-40,
			-440,
			80,
			44,
			2,
			"Tacet Fleet",
			"S"
		},
		{
			"y_canteen",
			"Mess",
			"northband",
			120,
			-440,
			80,
			52,
			2,
			"Staff Canteen",
			"S"
		},
		{
			"a_studios",
			"Annex",
			"annex",
			-276,
			-10,
			72,
			112,
			3,
			"Acoustics Annex",
			"S"
		},
		{
			"core_a",
			"Stair",
			"annex",
			-276,
			62,
			16,
			16,
			3,
			"Stairs down",
			"S>V"
		},
		{
			"a_vault",
			"Vault",
			"annex",
			-272,
			110,
			96,
			64,
			0,
			"Reel Vault",
			"V"
		},
		{
			"hall_foyer",
			"Hall",
			"hall",
			200,
			-20,
			44,
			72,
			1,
			"Founders\' Foyer",
			"S"
		},
		{
			"hall_main",
			"Hall",
			"hall",
			286,
			-20,
			112,
			112,
			1,
			"Founders\' Hall",
			"S"
		},
		{
			"d_dock3",
			"Dock",
			"depot",
			360,
			-280,
			52,
			96,
			3,
			"Dock 3",
			"S"
		},
		{
			"d_depot",
			"Depot",
			"depot",
			360,
			-384,
			48,
			88,
			3,
			"Field Services Depot",
			"S"
		},
		{
			"d_cold",
			"ColdStore",
			"depot",
			360,
			-466,
			40,
			56,
			3,
			"Cold Store",
			"S"
		},
		{
			"d_gen",
			"Utility",
			"depot",
			380,
			-190,
			28,
			32,
			3,
			"Generator House",
			"S"
		},
		{
			"p3_garage",
			"Garage",
			"garage",
			280,
			136,
			120,
			80,
			2,
			"Parking",
			"S"
		},
		{
			"p3_guard",
			"Checkpoint",
			"garage",
			372,
			152,
			20,
			16,
			2,
			"Attendant",
			"S"
		}
	},
	["LANDMARKS"] = {
		["v_pavilion"] = "Tacet Experience",
		["nw_lobby"] = "North Wing",
		["hall_main"] = "Founders\' Hall",
		["a_studios"] = "Acoustics Annex",
		["d_dock3"] = "Dock 3",
		["p3_garage"] = "Parking",
		["army_hq"] = "Lakeshore Det HQ",
		["s_lighthouse"] = "Vesper Light"
	},
	["NAMES"] = {
		["s_boathouse"] = "Tacet Boathouse",
		["s_harbormaster"] = "Harbormaster",
		["s_marina_club"] = "Vesper Marina Club",
		["s_marina_gas"] = "Marina Fuel",
		["s_pier_shed"] = "Tacet Marine Pier 3",
		["n_ferry"] = "Vesper Ferry Office",
		["n_fish"] = "Fish Market",
		["n_yacht"] = "Yacht Club",
		["n_motel"] = "Lakeview Motel",
		["h1_hardware"] = "Hallam Hardware",
		["h1_barber"] = "Barber",
		["h1_diner"] = "Vesper Diner",
		["h1_bank"] = "Port Vesper Savings",
		["h1_books"] = "Books",
		["h1_store"] = "Tacet Employee Store",
		["h2_pharmacy"] = "Vesper Pharmacy",
		["h2_post"] = "Post Office",
		["h2_hotel"] = "Hotel Vesper",
		["h2_laundry"] = "Laundromat",
		["h1_electronics"] = "Electronics",
		["h1_garage"] = "Vesper Auto",
		["h1_pub"] = "Pier Pub",
		["h2_market"] = "Vesper Market",
		["h2_church"] = "St Brendan",
		["h2_credit"] = "Tacet Credit Union",
		["n_cannery"] = "Vesper Cannery",
		["n_customs"] = "Customs House",
		["s_boatyard"] = "Vesper Boatyard",
		["army_w"] = "Lakeshore Post",
		["army_e"] = "Lakeshore Post",
		["core_u1"] = "Stairs down",
		["nw_legal"] = "Legal and Liaison",
		["core_u2"] = "Stairs down",
		["nw_stacks"] = "The Stacks",
		["core_t"] = "Stairs up",
		["nw_founders"] = "Founders\' Floor",
		["core_roof"] = "Roof access",
		["nw_roof"] = "Air Pad",
		["nw_garage"] = "Tacet Service Garage",
		["core_p"] = "Private stair",
		["svc_tunnel"] = "Service Tunnel",
		["r_a1"] = "Staff Home",
		["r_b1"] = "Staff Home",
		["r_c1"] = "Staff Home",
		["r_d1"] = "Staff Home",
		["r_a2"] = "Staff Home",
		["r_b2"] = "Staff Home",
		["r_c2"] = "Staff Home",
		["r_d2"] = "Staff Home",
		["y_clinic"] = "Occupational Health",
		["y_fleet"] = "Tacet Fleet",
		["y_canteen"] = "Staff Canteen",
		["core_a"] = "Stairs down",
		["a_vault"] = "Reel Vault",
		["hall_foyer"] = "Founders\' Foyer",
		["d_depot"] = "Field Services Depot",
		["d_cold"] = "Cold Store",
		["d_gen"] = "Generator House",
		["p3_guard"] = "Attendant"
	},
	["LANDMARK_KINDS"] = {},
	["PLATES"] = {
		{ "nw_lobby", "P" },
		{ "nw_legal", "U1" },
		{ "nw_stacks", "U2" },
		{ "nw_founders", "T" },
		{ "nw_roof", "R" },
		{ "nw_garage", "G" },
		{ "a_vault", "V" }
	},
	["PLATE_LINKS"] = {
		{
			"core_u1",
			"nw_lobby",
			"nw_legal",
			"down"
		},
		{
			"core_u2",
			"nw_legal",
			"nw_stacks",
			"down"
		},
		{
			"core_t",
			"nw_lobby",
			"nw_founders",
			"up"
		},
		{
			"core_roof",
			"nw_founders",
			"nw_roof",
			"up"
		},
		{
			"core_p",
			"nw_garage",
			"nw_founders",
			"up"
		},
		{
			"core_a",
			"a_studios",
			"a_vault",
			"down"
		},
		{
			"svc_tunnel",
			"nw_garage",
			"hall_main",
			"down"
		}
	},
	["WOODS"] = {
		{
			-560,
			-560,
			-520,
			500
		},
		{
			520,
			-560,
			560,
			500
		},
		{
			-520,
			-560,
			520,
			-520
		}
	},
	["TREES"] = {
		{ -548, -554, 12 },
		{ -552, -531, 10 },
		{ -551, -503, 12 },
		{ -547, -483, 12 },
		{ -553, -447, 8 },
		{ -556, -421, 10 },
		{ -551, -394, 8 },
		{ -551, -352, 12 },
		{ -555, -334, 10 },
		{ -556, -312, 12 },
		{ -553, -291, 10 },
		{ -556, -271, 10 },
		{ -548, -249, 12 },
		{ -552, -226, 10 },
		{ -548, -153, 8 },
		{ -552, -130, 12 },
		{ -557, -116, 12 },
		{ -547, -88, 8 },
		{ -555, -74, 8 },
		{ -553, -53, 10 },
		{ -554, -3, 12 },
		{ -548, 19, 8 },
		{ -557, 43, 12 },
		{ -553, 134, 8 },
		{ -548, 168, 12 },
		{ -552, 200, 12 },
		{ -555, 240, 12 },
		{ -549, 261, 10 },
		{ -554, 282, 8 },
		{ -556, 306, 10 },
		{ -553, 332, 10 },
		{ -555, 354, 10 },
		{ -557, 391, 10 },
		{ -555, 409, 8 },
		{ -554, 475, 12 },
		{ -539, -555, 10 },
		{ -531, -535, 10 },
		{ -525, -510, 10 },
		{ -537, -487, 12 },
		{ -529, -471, 8 },
		{ -532, -384, 10 },
		{ -530, -352, 12 },
		{ -531, -337, 8 },
		{ -537, -314, 12 },
		{ -531, -296, 12 },
		{ -525, -273, 10 },
		{ -526, -247, 10 },
		{ -535, -157, 12 },
		{ -530, -133, 10 },
		{ -533, -116, 12 },
		{ -527, -96, 12 },
		{ -536, -64, 10 },
		{ -525, -48, 12 },
		{ -531, -31, 12 },
		{ -525, 1, 8 },
		{ -529, 25, 10 },
		{ -529, 41, 10 },
		{ -530, 113, 12 },
		{ -537, 129, 10 },
		{ -529, 145, 8 },
		{ -535, 174, 12 },
		{ -529, 190, 12 },
		{ -530, 210, 8 },
		{ -534, 242, 8 },
		{ -535, 267, 12 },
		{ -539, 280, 10 },
		{ -534, 299, 10 },
		{ -530, 370, 10 },
		{ -534, 398, 8 },
		{ -537, 411, 10 },
		{ -529, 477, 10 },
		{ -510, -554, 12 },
		{ -506, -526, 10 },
		{ -490, -554, 8 },
		{ -492, -533, 12 },
		{ -463, -548, 8 },
		{ -463, -527, 10 },
		{ -447, -556, 12 },
		{ -438, -531, 12 },
		{ -424, -550, 12 },
		{ -429, -537, 8 },
		{ -399, -556, 10 },
		{ -397, -535, 12 },
		{ -372, -550, 8 },
		{ -374, -529, 8 },
		{ -357, -534, 12 },
		{ -334, -549, 10 },
		{ -332, -533, 8 },
		{ -272, -552, 10 },
		{ -271, -537, 12 },
		{ -240, -553, 10 },
		{ -249, -528, 12 },
		{ -227, -537, 8 },
		{ -203, -550, 8 },
		{ -207, -527, 10 },
		{ -177, -550, 10 },
		{ -175, -538, 10 },
		{ -153, -525, 12 },
		{ -132, -535, 10 },
		{ -119, -539, 8 },
		{ -97, -537, 8 },
		{ -70, -552, 8 },
		{ -68, -532, 8 },
		{ -51, -530, 12 },
		{ -27, -526, 8 },
		{ 0, -555, 12 },
		{ -1, -535, 10 },
		{ 12, -550, 10 },
		{ 15, -527, 8 },
		{ 42, -548, 12 },
		{ 44, -529, 8 },
		{ 66, -553, 8 },
		{ 69, -536, 12 },
		{ 79, -556, 10 },
		{ 78, -535, 12 },
		{ 108, -557, 8 },
		{ 102, -538, 10 },
		{ 124, -556, 8 },
		{ 127, -527, 12 },
		{ 151, -535, 10 },
		{ 238, -553, 10 },
		{ 237, -530, 8 },
		{ 267, -534, 10 },
		{ 282, -554, 12 },
		{ 276, -529, 12 },
		{ 310, -551, 12 },
		{ 299, -536, 12 },
		{ 327, -525, 8 },
		{ 348, -552, 12 },
		{ 345, -537, 10 },
		{ 391, -548, 10 },
		{ 418, -531, 12 },
		{ 441, -548, 12 },
		{ 432, -536, 10 },
		{ 453, -555, 10 },
		{ 464, -536, 10 },
		{ 486, -557, 8 },
		{ 486, -533, 12 },
		{ 508, -552, 12 },
		{ 504, -532, 12 },
		{ 521, -548, 8 },
		{ 518, -530, 8 },
		{ 526, -511, 8 },
		{ 526, -468, 12 },
		{ 526, -349, 10 },
		{ 529, -339, 12 },
		{ 525, -311, 12 },
		{ 531, -294, 12 },
		{ 530, -270, 12 },
		{ 530, -231, 12 },
		{ 528, -185, 10 },
		{ 526, -158, 10 },
		{ 527, -93, 8 },
		{ 530, -68, 10 },
		{ 527, -10, 12 },
		{ 530, 12, 12 },
		{ 530, 197, 12 },
		{ 529, 215, 12 },
		{ 527, 236, 12 },
		{ 531, 256, 12 },
		{ 526, 299, 10 },
		{ 528, 370, 8 },
		{ 525, 395, 10 },
		{ 540, -530, 8 },
		{ 548, -507, 8 },
		{ 542, -490, 12 },
		{ 542, -460, 10 },
		{ 550, -446, 12 },
		{ 542, -428, 12 },
		{ 551, -400, 10 },
		{ 547, -374, 8 },
		{ 551, -359, 8 },
		{ 551, -330, 8 },
		{ 545, -307, 10 },
		{ 549, -287, 10 },
		{ 550, -270, 10 },
		{ 543, -242, 8 },
		{ 552, -229, 12 },
		{ 550, -202, 8 },
		{ 541, -183, 10 },
		{ 546, -151, 12 },
		{ 540, -76, 12 },
		{ 543, -45, 8 },
		{ 540, -23, 10 },
		{ 541, 2, 10 },
		{ 543, 15, 8 },
		{ 546, 47, 12 },
		{ 543, 69, 8 },
		{ 541, 134, 8 },
		{ 550, 147, 8 },
		{ 551, 167, 10 },
		{ 552, 189, 10 },
		{ 551, 215, 12 },
		{ 552, 243, 10 },
		{ 553, 262, 12 },
		{ 541, 282, 8 },
		{ 549, 370, 8 },
		{ 550, 388, 8 },
		{ 546, 413, 8 },
		{ 543, 433, 8 },
		{ 552, 451, 8 },
		{ 549, 476, 12 }
	},
	["AREAS"] = {
		{
			"lakegate",
			"Lakeshore Detachment",
			-438,
			68,
			{
				-520,
				-140,
				-356,
				276
			},
			true
		},
		{
			"topfloor",
			"Founders\' Floor",
			114,
			-265,
			{
				36,
				-352,
				192,
				-178
			},
			false
		},
		{
			"stacks",
			"The Stacks",
			-50,
			-309,
			{
				-112,
				-372,
				12,
				-246
			},
			false
		},
		{
			"legal",
			"Legal and Liaison",
			-52,
			-215,
			{
				-100,
				-246,
				-4,
				-184
			},
			false
		},
		{
			"lobby",
			"North Wing Lobby",
			0,
			-140,
			{
				-100,
				-200,
				100,
				-80
			},
			false
		},
		{
			"tunnel",
			"Service Tunnel",
			252,
			-120,
			{
				236,
				-160,
				268,
				-80
			},
			false
		},
		{
			"garage",
			"Parking",
			312,
			138,
			{
				212,
				88,
				412,
				188
			},
			false
		},
		{
			"hall",
			"Founders\' Hall",
			260,
			-23,
			{
				170,
				-90,
				350,
				44
			},
			true
		},
		{
			"annex",
			"Acoustics Annex",
			-266,
			35,
			{
				-332,
				-80,
				-200,
				150
			},
			true
		},
		{
			"homes",
			"Vesper Row",
			-223,
			-305,
			{
				-336,
				-380,
				-110,
				-230
			},
			true
		},
		{
			"northband",
			"North Yard",
			-3,
			-444,
			{
				-336,
				-500,
				330,
				-388
			},
			true
		},
		{
			"pavilion",
			"Visitor Pavilion",
			0,
			187,
			{
				-60,
				152,
				60,
				222
			},
			true
		},
		{
			"bluff",
			"Bluff Stairs",
			-130,
			243,
			{
				-190,
				214,
				-70,
				272
			},
			false
		},
		{
			"plaza",
			"Overture Plaza",
			0,
			76,
			{
				-170,
				-70,
				170,
				222
			},
			true
		},
		{
			"depot",
			"Dock 3 and Depot",
			367,
			-334,
			{
				322,
				-500,
				412,
				-168
			},
			true
		},
		{
			"harbor",
			"Harbor Street",
			-40,
			323,
			{
				-520,
				250,
				440,
				396
			},
			true
		},
		{
			"waterfront",
			"Waterfront",
			0,
			468,
			{
				-520,
				396,
				520,
				540
			},
			true
		},
		{
			"rail",
			"Freight Line",
			480,
			80,
			{
				440,
				-340,
				520,
				500
			},
			false
		}
	},
	["PLACES"] = {
		["a_studios"] = { -276, -10, "Acoustics Annex" },
		["a_vault"] = { -272, 110, "Reel Vault" },
		["annex"] = { -266, 35, "Acoustics Annex" },
		["army_e"] = { 486, 372, "Lakeshore Post" },
		["army_hq"] = { -440, 110, "Lakeshore Det HQ" },
		["army_w"] = { -486, 372, "Lakeshore Post" },
		["bluff"] = { -130, 243, "Bluff Stairs" },
		["choir_1"] = { -100, 10, "Festival Stage" },
		["choir_2"] = { 70, 40, "Bandstand" },
		["core_a"] = { -276, 62, "Stairs down" },
		["core_p"] = { 168, -222, "Private stair" },
		["core_roof"] = { 96, -274, "Roof access" },
		["core_t"] = { 64, -170, "Stairs up" },
		["core_u1"] = { -48, -170, "Stairs down" },
		["core_u2"] = { -48, -258, "Stairs down" },
		["d_cold"] = { 360, -466, "Cold Store" },
		["d_depot"] = { 360, -384, "Field Services Depot" },
		["d_dock3"] = { 360, -280, "Dock 3" },
		["d_gen"] = { 380, -190, "Generator House" },
		["depot"] = { 367, -334, "Dock 3 and Depot" },
		["fountain"] = { 0, 80, "The Rest" },
		["garage"] = { 312, 138, "Parking" },
		["h1_bank"] = { -230, 374, "Port Vesper Savings" },
		["h1_barber"] = { -385, 372, "Barber" },
		["h1_books"] = { -171, 372, "Books" },
		["h1_diner"] = { -296, 373, "Vesper Diner" },
		["h1_electronics"] = { -41, 372, "Electronics" },
		["h1_garage"] = { 20, 373, "Vesper Auto" },
		["h1_hardware"] = { -430, 374, "Hallam Hardware" },
		["h1_pub"] = { 90, 373, "Pier Pub" },
		["h1_store"] = { -100, 374, "Tacet Employee Store" },
		["h2_church"] = { 190, 297, "St Brendan" },
		["h2_credit"] = { 280, 302, "Tacet Credit Union" },
		["h2_hotel"] = { -231, 301, "Hotel Vesper" },
		["h2_laundry"] = { -121, 300, "Laundromat" },
		["h2_market"] = { 100, 295, "Vesper Market" },
		["h2_pharmacy"] = { -430, 302, "Vesper Pharmacy" },
		["h2_post"] = { -380, 302, "Post Office" },
		["hall"] = { 260, -23, "Founders\' Hall" },
		["hall_foyer"] = { 200, -20, "Founders\' Foyer" },
		["hall_main"] = { 286, -20, "Founders\' Hall" },
		["harbor"] = { -40, 323, "Harbor Street" },
		["homes"] = { -223, -305, "Vesper Row" },
		["lakegate"] = { -438, 68, "Lakeshore Detachment" },
		["legal"] = { -52, -215, "Legal and Liaison" },
		["lobby"] = { 0, -140, "North Wing Lobby" },
		["n_cannery"] = { 100, 414, "Vesper Cannery" },
		["n_customs"] = { 220, 414, "Customs House" },
		["n_ferry"] = { -420, 414, "Vesper Ferry Office" },
		["n_fish"] = { -301, 414, "Fish Market" },
		["n_motel"] = { -19, 413, "Lakeview Motel" },
		["n_yacht"] = { -160, 414, "Yacht Club" },
		["northband"] = { -3, -444, "North Yard" },
		["nw_founders"] = { 96, -222, "Founders\' Floor" },
		["nw_garage"] = { 248, -230, "Tacet Service Garage" },
		["nw_legal"] = { -48, -214, "Legal and Liaison" },
		["nw_lobby"] = { 0, -122, "North Wing" },
		["nw_roof"] = { 96, -318, "Air Pad" },
		["nw_stacks"] = { -48, -310, "The Stacks" },
		["p3_garage"] = { 280, 136, "Parking" },
		["p3_guard"] = { 372, 152, "Attendant" },
		["pavilion"] = { 0, 187, "Visitor Pavilion" },
		["plaza"] = { 0, 76, "Overture Plaza" },
		["r_a1"] = { -306, -333, "Staff Home" },
		["r_a2"] = { -306, -267, "Staff Home" },
		["r_b1"] = { -251, -329, "Staff Home" },
		["r_b2"] = { -251, -271, "Staff Home" },
		["r_c1"] = { -198, -332, "Staff Home" },
		["r_c2"] = { -198, -268, "Staff Home" },
		["r_d1"] = { -143, -328, "Staff Home" },
		["r_d2"] = { -143, -272, "Staff Home" },
		["rail"] = { 480, 80, "Freight Line" },
		["s_boathouse"] = { -380, 480, "Tacet Boathouse" },
		["s_boatyard"] = { 100, 480, "Vesper Boatyard" },
		["s_harbormaster"] = { -260, 480, "Harbormaster" },
		["s_lighthouse"] = { 488, 484, "Vesper Light" },
		["s_marina_club"] = { -140, 480, "Vesper Marina Club" },
		["s_marina_gas"] = { -60, 476, "Marina Fuel" },
		["s_pier_shed"] = { 296, 480, "Tacet Marine Pier 3" },
		["stacks"] = { -50, -309, "The Stacks" },
		["stage"] = { -100, 10, "Festival Stage" },
		["svc_tunnel"] = { 252, -121, "Service Tunnel" },
		["topfloor"] = { 114, -265, "Founders\' Floor" },
		["tunnel"] = { 252, -120, "Service Tunnel" },
		["v_pavilion"] = { 0, 188, "Tacet Experience" },
		["waterfront"] = { 0, 468, "Waterfront" },
		["y_canteen"] = { 120, -440, "Staff Canteen" },
		["y_clinic"] = { -200, -440, "Occupational Health" },
		["y_fleet"] = { -40, -440, "Tacet Fleet" }
	},
	["EXTRACTS"] = {
		{
			"o_garage",
			"Garage Ramp",
			500,
			100,
			30,
			26,
			"Road"
		},
		{
			"o_harbor_road",
			"Harbor Road Barrier",
			-504,
			340,
			24,
			30,
			"Gate"
		},
		{
			"o_skiff",
			"Marina Skiff",
			-10,
			508,
			30,
			22,
			"Boat"
		},
		{
			"o_airpad",
			"Air Pad",
			96,
			-318,
			34,
			34,
			"Heli"
		},
		{
			"o_lake_tunnel",
			"Lake Tunnel",
			488,
			466,
			18,
			18,
			"Sewer"
		},
		{
			"o_freight",
			"Freight Locomotive",
			456,
			-250,
			24,
			44,
			"Vehicle"
		},
		{
			"o_curtain",
			"Stage Door",
			376,
			-20,
			22,
			26,
			"Gate"
		}
	},
	["nearestLandmark"] = function(p1, p2) -- name: nearestLandmark
		-- upvalues: (copy) v_u_15
		local v3 = (1 / 0)
		local v4 = "area"
		local v5 = "the plaza"
		for v6, v7 in v_u_15.PLACES do
			local v8 = v_u_15.LANDMARKS[v6] ~= nil
			local v9 = v8 or v_u_15.NAMES[v6] ~= nil
			local v10 = p1 - v7[1]
			local v11 = p2 - v7[2]
			local v12 = v10 * v10 + v11 * v11
			local v13 = math.sqrt(v12)
			if not v8 then
				v13 = v13 * 1.5 + 25
			end
			if v13 >= v3 then
				continue
			end
			v5 = v7[3]
			if v9 then
				v3 = v13
				v4 = "landmark"
			else
				v3 = v13
				v4 = "area"
			end
		end
		if v4 == "area" then
			local v14 = (v3 - 25) / 1.5
			v3 = math.max(0, v14)
		end
		return "the " .. v5, v3, v4
	end
}
return v_u_15