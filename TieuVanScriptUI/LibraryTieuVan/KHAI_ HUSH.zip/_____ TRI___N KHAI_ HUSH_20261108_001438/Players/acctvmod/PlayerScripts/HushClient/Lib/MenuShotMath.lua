-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuShotMath

local v_u_1 = math.rad
local v_u_2 = {
	["TUNE"] = {
		["glideMin"] = 0.85,
		["glideMax"] = 2.4,
		["glidePerStud"] = 0.0011111111111111111,
		["liftPerStud"] = 0.25,
		["liftMax"] = 120,
		["fadeOut"] = 0.16,
		["fadeIn"] = 0.24,
		["streamWaitMax"] = 0.6,
		["uiInAt"] = 0.6,
		["uiFade"] = 0.18,
		["reducedFade"] = 0.15,
		["vistaHold"] = 24,
		["vistaFly"] = 6,
		["orbitSpeed"] = 0.035,
		["orbitMin"] = 160,
		["orbitMax"] = 260,
		["orbitHeight"] = 110,
		["orbitFov"] = 50,
		["orbitDrift"] = 0.6
	},
	["SLOT_SPACING"] = 400
}
local v_u_3 = v_u_2.TUNE
function v_u_2.frame(p4, p5) -- name: frame
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1(p4.fov / 2)
	local v7 = math.tan(v6)
	local v8 = v7 * p5
	local v9 = CFrame.lookAt(p4.pos, p4.subject)
	local v10 = (0.5 - p4.sx) * 2 * v8
	local v11 = -math.atan(v10)
	local v12 = (p4.sy - 0.5) * 2 * v7
	local v13 = math.atan(v12)
	local v14 = v9 * CFrame.Angles(0, v11, 0) * CFrame.Angles(v13, 0, 0)
	if p4.roll ~= nil and p4.roll ~= 0 then
		v14 = v14 * CFrame.Angles(0, 0, (v_u_1(p4.roll)))
	end
	return v14
end
function v_u_2.ease(p15, p16) -- name: ease
	local v17 = math.clamp(p16, 0, 1)
	if p15 == "sineInOut" then
		local v18 = 3.141592653589793 * v17
		return -(math.cos(v18) - 1) / 2
	elseif p15 == "cubicInOut" then
		if v17 < 0.5 then
			return v17 * 4 * v17 * v17
		end
		local v19 = v17 * -2 + 2
		return 1 - v19 * v19 * v19 / 2
	elseif p15 == "quadIn" then
		return v17 * v17
	elseif p15 == "quadOut" then
		return 1 - (1 - v17) * (1 - v17)
	elseif p15 == "expoOut" then
		return v17 >= 1 and 1 or 1 - 2 ^ (v17 * -10)
	else
		return v17
	end
end
function v_u_2._glideSeconds(p20) -- name: _glideSeconds
	-- upvalues: (copy) v_u_3
	local v21 = v_u_3.glideMin + p20 * v_u_3.glidePerStud
	local v22 = v_u_3.glideMin
	local v23 = v_u_3.glideMax
	return math.clamp(v21, v22, v23)
end
function v_u_2._liftFor(p24) -- name: _liftFor
	-- upvalues: (copy) v_u_3
	local v25 = p24 * v_u_3.liftPerStud
	local v26 = v_u_3.liftMax
	return math.min(v25, v26)
end
function v_u_2._bezier(p27, p28, p29, p30) -- name: _bezier
	local v31 = 1 - p30
	return v31 * v31 * p27 + v31 * 2 * p30 * p28 + p30 * p30 * p29
end
function v_u_2.glideTime(p32, p33, p34) -- name: glideTime
	-- upvalues: (copy) v_u_2
	return p34 and 0 or v_u_2._glideSeconds((p32.pos - p33.pos).Magnitude)
end
function v_u_2.lift(p35, p36) -- name: lift
	-- upvalues: (copy) v_u_2
	return v_u_2._liftFor((p35.pos - p36.pos).Magnitude)
end
function v_u_2.arc(p37, p38, p39, p40) -- name: arc
	local v41 = (p37 + p38) / 2
	local v42 = p39 * 2
	local v43 = v41 + Vector3.new(0, v42, 0)
	local v44 = 1 - p40
	return p37 * (v44 * v44) + v43 * (v44 * 2 * p40) + p38 * (p40 * p40)
end
function v_u_2.blend(p45, p46, p47, p48, p49) -- name: blend
	-- upvalues: (copy) v_u_2
	local v50 = v_u_2.ease(p48, p47)
	local v51
	if p45.roll == nil and p46.roll == nil then
		v51 = nil
	else
		local v52 = p45.roll or 0
		v51 = v52 + ((p46.roll or 0) - v52) * v50
	end
	local v53 = {
		["pos"] = v_u_2.arc(p45.pos, p46.pos, p49, v50),
		["subject"] = p45.subject:Lerp(p46.subject, v50)
	}
	local v54 = p45.sx
	v53.sx = v54 + (p46.sx - v54) * v50
	local v55 = p45.sy
	v53.sy = v55 + (p46.sy - v55) * v50
	local v56 = p45.fov
	v53.fov = v56 + (p46.fov - v56) * v50
	local v57 = p45.drift
	v53.drift = v57 + (p46.drift - v57) * v50
	v53.roll = v51
	return v53
end
function v_u_2.orbit(p58, p59, p60) -- name: orbit
	local v61 = p59.phase + p59.speed * p60
	local v62 = {
		["pos"] = nil,
		["subject"] = nil,
		["sx"] = 0.5,
		["sy"] = 0.5,
		["fov"] = nil,
		["drift"] = nil
	}
	local v63 = math.cos(v61) * p59.radius
	local v64 = p59.height
	local v65 = math.sin(v61) * p59.radius
	v62.pos = p58 + Vector3.new(v63, v64, v65)
	v62.subject = p58
	v62.fov = p59.fov
	v62.drift = p59.drift
	return v62
end
function v_u_2.drift(p66, p67) -- name: drift
	-- upvalues: (copy) v_u_1
	local v68 = CFrame.new
	local v69 = p66 * 0.13
	local v70 = math.sin(v69) * 0.7 * p67
	local v71 = p66 * 0.087 + 1.3
	local v72 = math.sin(v71) * 0.28 * p67
	local v73 = p66 * 0.11
	local v74 = v68(v70, v72, math.cos(v73) * 0.45 * p67)
	local v75 = CFrame.Angles
	local v76 = p66 * 0.21
	local v77 = v_u_1(math.sin(v76) * 0.35 * p67)
	local v78 = p66 * 0.17 + 0.5
	local v79 = v_u_1(math.sin(v78) * 0.5 * p67)
	local v80 = p66 * 0.09
	return v74 * v75(v77, v79, (v_u_1(math.sin(v80) * 0.4 * p67)))
end
function v_u_2.slotOrigin(p81, p82) -- name: slotOrigin
	-- upvalues: (copy) v_u_2
	local v83 = p82 * v_u_2.SLOT_SPACING
	return p81 + Vector3.new(v83, 0, 0)
end
return v_u_2