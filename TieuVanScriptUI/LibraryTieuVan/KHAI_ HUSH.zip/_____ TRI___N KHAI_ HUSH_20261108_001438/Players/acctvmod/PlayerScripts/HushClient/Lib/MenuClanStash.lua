-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanStash

local v_u_1 = game:GetService("GuiService")
local v_u_2 = {}
local v_u_3 = {
	["loading"] = true,
	["syncing"] = true,
	["completing"] = true
}
local v_u_4 = {
	"word",
	"act",
	"canStep",
	"label",
	"qty",
	"key",
	"have",
	"limitBlock",
	"left"
}
local function v_u_14(p5, p6) -- name: stripDots
	if p6 ~= nil then
		local v7 = p6.strip
		if type(v7) == "function" then
			local v8 = p6.strip
			local v9, v10 = pcall(v8, p5)
			if v9 and type(v10) == "string" then
				return v10
			end
		end
	end
	local v11 = type(p5) ~= "string" and "" or p5
	for _ = 1, 4 do
		local v12 = string.gsub(v11, "[%s%.]+$", "")
		if string.sub(v12, -3) == "\226\128\166" then
			local v13 = #v12 - 3
			v12 = string.sub(v12, 1, v13)
		end
		if v12 == v11 then
			v11 = v12
			break
		end
		v11 = v12
	end
	return v11
end
function v_u_2.statusBusy(p15) -- name: statusBusy
	-- upvalues: (copy) v_u_3
	local v16
	if type(p15) == "table" then
		local v17 = p15.id
		if type(v17) == "string" then
			v16 = v_u_3[p15.id] == true
		else
			v16 = false
		end
	else
		v16 = false
	end
	return v16
end
function v_u_2.busyWord(p18, p19, p20) -- name: busyWord
	-- upvalues: (copy) v_u_14
	if type(p18) == "table" and p18.lock == true then
		local v21 = p18.id
		if type(v21) == "string" and type(p19) == "table" then
			local v22 = p19.UI
			if type(v22) == "table" then
				local v23 = nil
				if p18.id == "syncing" then
					v23 = p19.UI.VALIDATING
				elseif p18.id == "completing" then
					v23 = p19.UI.MOVING
				elseif p18.id == "loading" then
					v23 = v_u_14(p19.UI.LOADING, p20)
				end
				if type(v23) == "string" then
					return v23
				else
					return nil
				end
			end
		end
	end
	return nil
end
function v_u_2.footKey(p24) -- name: footKey
	-- upvalues: (copy) v_u_4
	local v25 = type(p24) ~= "table" and {} or p24
	local v26 = {}
	for v27, v28 in v_u_4 do
		local v29 = v25[v28]
		v26[v27] = type(v29) .. "=" .. tostring(v29)
	end
	return table.concat(v26, "\31")
end
function v_u_2.layout(p30) -- name: layout
	return {
		["statusH"] = 26,
		["switchH"] = nil,
		["headH"] = 28,
		["footH"] = nil,
		["colW"] = nil,
		["tile"] = nil,
		["cols"] = nil,
		["switchH"] = p30.switch and 40 or 0,
		["footH"] = p30.barH,
		["colW"] = p30.gridW,
		["tile"] = p30.tile,
		["cols"] = p30.stashCols
	}
end
function v_u_2.mount(p_u_31, p_u_32) -- name: mount
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v_u_33 = p_u_31.UI
	local v_u_34 = p_u_31.Theme
	local v_u_35 = p_u_31.C
	local v_u_36 = p_u_31.Kit
	local v_u_37 = p_u_31.U
	local v_u_38 = p_u_31.M
	local v_u_39 = p_u_31.m
	local v_u_40 = v_u_37.frame(p_u_32, "Stage", UDim2.fromScale(1, 1))
	local v_u_41 = 0
	local v_u_42 = {}
	local v_u_43 = true
	local v_u_44 = false
	local v_u_45 = v_u_2.layout(v_u_39)
	local v_u_46 = v_u_39.kind == "phone"
	local v_u_47 = p_u_31.lib("MenuClanLayout")
	local v_u_48 = v_u_34.touch(44)
	local v49 = p_u_32.AbsoluteSize.Y
	local v50 = v_u_34.uiScale
	local v51
	if type(v50) == "function" then
		local v52 = v_u_34.uiScale
		v51 = math.max(0.01, v52())
	else
		v51 = 1
	end
	local v53 = v49 / v51
	local v_u_54
	if v_u_39.phoneRow and (v_u_47 and v_u_47.stashPhone) then
		if v53 < 100 then
			v53 = not v_u_47.bodyH and 280 or v_u_47.bodyH(v_u_39, v_u_34.touch(v_u_39.subTabH), false, 0)
		end
		v_u_54 = v_u_47.stashPhone(v_u_39.inner, v53, v_u_48, v_u_39.tile, v_u_39.tileGap)
	else
		v_u_54 = nil
	end
	local v_u_55 = nil
	local function v56()
		-- upvalues: (ref) v_u_55, (copy) p_u_31
		v_u_55 = p_u_31.lib("TextFitting")
	end
	pcall(v56)
	local v_u_57 = nil
	local v_u_58 = v_u_37.busyDots
	local v_u_59 = {}
	local v_u_60 = {}
	local v_u_61 = false
	local v_u_62 = nil
	local v_u_63 = nil
	local v_u_64 = false
	local v_u_65 = 0
	local v_u_66 = 0
	local v_u_67 = false
	local v_u_68 = ""
	local v_u_69 = "info"
	local v_u_70 = 0
	local v_u_71 = "mine"
	local v_u_72 = {
		["mine"] = v_u_38.newSel(),
		["clan"] = v_u_38.newSel()
	}
	local v_u_73 = {
		["mine"] = nil,
		["clan"] = nil
	}
	local v_u_74 = {
		["mine"] = {},
		["clan"] = {}
	}
	local v_u_75 = 0
	local v_u_76 = nil
	local v_u_190 = nil
	local v_u_78 = {
		["TRY_AGAIN"] = true,
		["UNAVAILABLE"] = true,
		["STASH_SYNC"] = true,
		["STASH_BUSY"] = true
	}
	local v_u_79 = nil
	local v_u_80 = nil
	local v_u_81 = nil
	local function v_u_90() -- name: profileStashItems
		-- upvalues: (ref) v_u_79, (copy) p_u_31
		local v82 = v_u_79 or p_u_31.profile()
		local v83 = v82.inv
		local v84
		if type(v83) == "table" then
			v84 = v82.inv
		else
			v84 = nil
		end
		local v85
		if v84 then
			local v86 = v84.containers
			if type(v86) == "table" then
				v85 = v84.containers
			else
				v85 = nil
			end
		else
			v85 = nil
		end
		local v87
		if v85 then
			local v88 = v85.stash
			if type(v88) == "table" then
				v87 = v85.stash
			else
				v87 = nil
			end
		else
			v87 = nil
		end
		if v87 then
			local v89 = v87.items
			if type(v89) == "table" then
				return v87.items
			end
		end
		return {}
	end
	local function v_u_97() -- name: insuredSet
		-- upvalues: (ref) v_u_79, (copy) p_u_31
		local v91 = {}
		local v92 = v_u_79 or p_u_31.profile()
		local v93 = v92.insurance
		local v94
		if type(v93) == "table" then
			v94 = v92.insurance
		else
			v94 = nil
		end
		for _, v95 in v94 and v94.policies or {} do
			if type(v95) ~= "table" or not v95.uid then
				continue
			end
			local v96 = v95.raidsLeft
			if (tonumber(v96) or 0) <= 0 then
				continue
			end
			v91[v95.uid] = true
		end
		return v91
	end
	local v_u_98 = nil
	local v_u_99 = nil
	local function v100()
		-- upvalues: (ref) v_u_98, (copy) p_u_31
		v_u_98 = p_u_31.cctx.shared.TradeRules
	end
	pcall(v100)
	local function v101()
		-- upvalues: (ref) v_u_99, (copy) p_u_31
		v_u_99 = p_u_31.cctx.shared.ClanStashCore
	end
	pcall(v101)
	local function v_u_118(p102, p103) -- name: eligible
		-- upvalues: (ref) v_u_98, (ref) v_u_99, (copy) v_u_38
		if v_u_98 then
			local v104 = v_u_98.checkLine
			if type(v104) == "function" then
				local v105 = v_u_98.checkLine
				local v106 = {
					["topLevel"] = true,
					["insured"] = nil,
					["giver"] = nil,
					["insured"] = p103[p102.uid] == true,
					["giver"] = {
						["restricted"] = true,
						["crates"] = false,
						["resolved"] = true,
						["tradeFailed"] = false
					}
				}
				local v107, v108, v109 = pcall(v105, p102, v106)
				if v107 and v108 == false then
					if v_u_99 then
						local v110 = v_u_99.reasonText
						if type(v110) == "function" then
							return false, v_u_99.reasonText(v109)
						end
					end
					return false, v_u_38.TEXT.ITEM_NOT_ALLOWED
				end
			end
		end
		if v_u_99 then
			local v111 = v_u_99.rowOk
			if type(v111) == "function" then
				local v112 = v_u_99.rowOk
				local v113, v114, v115 = pcall(v112, p102)
				if v113 and v114 == false then
					local v116 = v_u_99.reasonText
					local v117
					if type(v116) == "function" then
						v117 = v_u_99.reasonText(v115)
					else
						v117 = nil
					end
					return false, v117 or v_u_38.TEXT.ITEM_NOT_ALLOWED
				end
			end
		end
		return true, nil
	end
	local function v_u_124(p119) -- name: memberName
		-- upvalues: (copy) p_u_31
		local v120 = p_u_31.clan()
		for _, v121 in v120 and v120.members or {} do
			local v122 = v121.uid
			if tostring(v122) ~= tostring(p119) then
				continue
			end
			local v123 = v121.name or ""
			return tostring(v123)
		end
		return nil
	end
	local v125 = v_u_37.frame
	local v126 = "StatusRow"
	local v127
	if v_u_54 then
		v127 = UDim2.new(1, -v_u_54.status.x, 0, v_u_48)
	else
		v127 = UDim2.new(1, 0, 0, v_u_45.statusH)
	end
	local v128
	if v_u_54 then
		v128 = UDim2.fromOffset(v_u_54.status.x, 0)
	else
		v128 = nil
	end
	local v_u_129 = v125(v_u_40, v126, v127, v128)
	local v_u_130 = v_u_37.status(v_u_129, {
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["size"] = nil,
		["kind"] = "info",
		["size"] = UDim2.new(0.62, 0, 1, 0)
	})
	local v_u_131 = v_u_33.label({
		["parent"] = nil,
		["name"] = "Limit",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_129,
		["position"] = UDim2.fromScale(0.62, 0),
		["size"] = UDim2.new(0.38, 0, 1, 0)
	})
	local v_u_132, v_u_133 = v_u_37.btn({
		["parent"] = nil,
		["text"] = "RETRY",
		["kind"] = "secondary",
		["width"] = 110,
		["maxTextWidth"] = 98,
		["name"] = "Retry",
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_129,
		["position"] = UDim2.new(1, -110, 0, 0),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_42
			v_u_42.retry()
		end
	})
	v_u_132.Visible = false
	local v_u_134
	if v_u_54 then
		v_u_134 = v_u_48 + 6
	else
		v_u_134 = v_u_45.statusH
	end
	local v_u_135, v_u_136
	if v_u_39.switch then
		local v137 = v_u_33.tabs
		local v138 = {
			["parent"] = nil,
			["name"] = "Switch",
			["tabs"] = nil,
			["selected"] = nil,
			["position"] = nil,
			["size"] = nil,
			["onChange"] = nil,
			["parent"] = v_u_40,
			["tabs"] = {
				{
					["id"] = "mine",
					["text"] = "Mine"
				},
				{
					["id"] = "clan",
					["text"] = "Clan"
				}
			},
			["selected"] = v_u_71,
			["position"] = UDim2.fromOffset(0, v_u_54 and 0 or v_u_134)
		}
		local v139
		if v_u_54 then
			v139 = UDim2.fromOffset(v_u_54.switch.w, v_u_54.switch.h)
		else
			v139 = UDim2.new(1, 0, 0, v_u_34.touch(v_u_45.switchH))
		end
		v138.size = v139
		function v138.onChange(p140) -- name: onChange
			-- upvalues: (ref) v_u_71, (copy) v_u_42
			v_u_71 = p140
			v_u_42.layoutSides()
		end
		local v141, v142 = v137(v138)
		v_u_135 = v142
		v_u_136 = v141
		if not v_u_54 then
			v_u_134 = v_u_134 + (v_u_34.touch(v_u_45.switchH) + 2)
		end
	else
		v_u_135 = nil
		v_u_136 = nil
	end
	local v_u_143 = {}
	local function v154(p144, p145, p146) -- name: makeCol
		-- upvalues: (ref) v_u_54, (copy) v_u_37, (copy) v_u_40, (copy) v_u_134, (copy) v_u_33, (copy) v_u_39, (copy) v_u_45, (copy) v_u_35
		local v147 = {
			["x"] = p146
		}
		if v_u_54 then
			local v148 = v_u_54.side.w
			v147.frame = v_u_37.frame(v_u_40, "Col_" .. p144, UDim2.new(1, 0, 1, -v_u_134), UDim2.fromOffset(0, v_u_134))
			local v149 = v_u_37.frame(v147.frame, "Side", UDim2.new(0, v148, 1, 0), UDim2.new(1, -v148, 0, 0))
			v147.title = v_u_33.label({
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "caps",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v149,
				["text"] = p145,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(0.5, 0, 0, v_u_54.sideHead.h)
			})
			v147.count = v_u_33.label({
				["parent"] = nil,
				["name"] = "Count",
				["text"] = "",
				["style"] = "monoS",
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v149,
				["position"] = UDim2.fromScale(0.5, 0),
				["size"] = UDim2.new(0.5, 0, 0, v_u_54.sideHead.h)
			})
			v147.grid = v_u_33.list({
				["parent"] = nil,
				["name"] = "Grid",
				["position"] = nil,
				["size"] = nil,
				["gap"] = nil,
				["padding"] = nil,
				["parent"] = v147.frame,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(1, -(v148 + 10), 1, 0),
				["gap"] = v_u_39.tileGap,
				["padding"] = {
					2,
					8,
					2,
					8
				}
			})
			v147.sideF = v149
		else
			v147.frame = v_u_37.frame(v_u_40, "Col_" .. p144, UDim2.new(0, v_u_45.colW, 1, -v_u_134), UDim2.fromOffset(p146, v_u_134))
			v147.title = v_u_33.label({
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "caps",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v147.frame,
				["text"] = p145,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(0.4, 0, 0, v_u_45.headH)
			})
			v147.count = v_u_33.label({
				["parent"] = nil,
				["name"] = "Count",
				["text"] = "",
				["style"] = "monoS",
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v147.frame,
				["position"] = UDim2.fromScale(0.4, 0),
				["size"] = UDim2.new(0.6, 0, 0, v_u_45.headH)
			})
			v147.grid = v_u_33.list({
				["parent"] = nil,
				["name"] = "Grid",
				["position"] = nil,
				["size"] = nil,
				["gap"] = nil,
				["padding"] = nil,
				["parent"] = v147.frame,
				["position"] = UDim2.fromOffset(0, v_u_45.headH),
				["size"] = UDim2.new(1, 0, 1, -(v_u_45.headH + v_u_45.footH + 6)),
				["gap"] = v_u_39.tileGap,
				["padding"] = {
					2,
					8,
					2,
					8
				}
			})
		end
		local v150 = v147.grid:FindFirstChildOfClass("UIListLayout")
		if v150 then
			v150:Destroy()
		end
		v_u_33.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(v_u_39.tile, v_u_39.tile),
			["CellPadding"] = UDim2.fromOffset(v_u_39.tileGap, v_u_39.tileGap),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v147.grid)
		local v151 = v_u_33.label
		local v152 = {
			["parent"] = nil,
			["name"] = "Empty",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["visible"] = false,
			["parent"] = v147.frame,
			["color"] = v_u_35.text2,
			["position"] = UDim2.fromOffset(12, v_u_54 and 24 or v_u_45.headH + 24)
		}
		local v153
		if v_u_54 then
			v153 = UDim2.new(1, -(v_u_54.side.w + 10 + 24), 0, 60)
		else
			v153 = UDim2.new(1, -24, 0, 60)
		end
		v152.size = v153
		v147.empty = v151(v152)
		if v_u_54 then
			v147.foot = v_u_37.frame(v147.sideF, "Foot", UDim2.new(1, 0, 1, -v_u_54.foot.y), UDim2.fromOffset(0, v_u_54.foot.y))
			return v147
		else
			v147.foot = v_u_37.frame(v147.frame, "Foot", UDim2.new(1, 0, 0, v_u_45.footH), UDim2.new(0, 0, 1, -v_u_45.footH))
			return v147
		end
	end
	v_u_143.mine = v154("mine", "MY STASH", 0)
	v_u_143.clan = v154("clan", "CLAN STASH", v_u_39.switch and 0 or v_u_45.colW + v_u_39.colGap)
	v_u_33.tooltip(v_u_143.mine.title, function()
		-- upvalues: (copy) v_u_38
		return {
			["title"] = "MY STASH",
			["body"] = nil,
			["body"] = v_u_38.UI.STASH_FIR
		}
	end)
	function v_u_42.layoutSides() -- name: layoutSides
		-- upvalues: (copy) v_u_39, (copy) v_u_143, (ref) v_u_71
		if v_u_39.switch then
			v_u_143.mine.frame.Visible = v_u_71 == "mine"
			v_u_143.clan.frame.Visible = v_u_71 == "clan"
		else
			v_u_143.mine.frame.Visible = true
			v_u_143.clan.frame.Visible = true
		end
	end
	local function v_u_155() -- name: info
		-- upvalues: (copy) v_u_38, (ref) v_u_62, (ref) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) p_u_31
		return v_u_38.stashStatus({
			["view"] = v_u_62,
			["failed"] = v_u_63,
			["sending"] = v_u_64,
			["pollSec"] = not v_u_64 and 0 or os.clock() - v_u_65,
			["stateTx"] = p_u_31.state().tx
		})
	end
	local function v_u_161() -- name: place
		-- upvalues: (copy) v_u_132, (ref) v_u_190, (ref) v_u_54, (copy) v_u_45, (copy) v_u_34, (copy) v_u_129, (ref) v_u_136, (copy) v_u_143
		v_u_132.Visible = v_u_190 ~= nil
		if not v_u_54 then
			local v156
			if v_u_190 then
				local v157 = v_u_45.statusH
				local v158 = v_u_34.touch
				v156 = math.max(v157, v158(44))
			else
				v156 = v_u_45.statusH
			end
			v_u_129.Size = UDim2.new(1, 0, 0, v156)
			if v_u_136 then
				v_u_136.Position = UDim2.fromOffset(0, v156)
				v156 = v156 + (v_u_34.touch(v_u_45.switchH) + 2)
			end
			for _, v159 in { "mine", "clan" } do
				local v160 = v_u_143[v159]
				v160.frame.Position = UDim2.fromOffset(v160.x, v156)
				v160.frame.Size = UDim2.new(0, v_u_45.colW, 1, -v156)
			end
		end
	end
	local function v_u_200() -- name: drawStatus
		-- upvalues: (copy) v_u_155, (ref) v_u_63, (ref) v_u_76, (copy) v_u_78, (ref) v_u_70, (ref) v_u_190, (copy) v_u_161, (ref) v_u_68, (ref) v_u_69, (ref) v_u_62, (copy) p_u_31, (copy) v_u_38, (ref) v_u_61, (ref) v_u_2, (copy) v_u_130, (copy) v_u_131, (copy) v_u_143
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v180, v181, v182, v183, v184, v185, v186, v187, v188, v189, v191, v192, v193, v194, v195, v196, v197, v198
		local v180, v181, v182, v183, v184, v185, v186, v187, v188, v189, v_u_190, v191, v192, v193, v194, v195, v196, v197, v198
		local v199 = 19
		while true do
			if v199 == 1 then
				if v193 == v188.text and (not v_u_61 and v_u_2.statusBusy(v188)) then
					v_u_130.setBusy(v193, v194)
				else
					v_u_130.set(v193, v194)
				end
				v197 = v_u_131
				if v_u_62 and not v_u_190 then
					v198 = v_u_38.limitText
					if v_u_62 then
						v180 = v_u_62.me
						v181 = type(v180) ~= "table" and {} or v_u_62.me
					else
						v181 = {}
					end
					v182 = v198(v181)
				else
					v182 = ""
				end
				v197.Text = v182
				v183 = v_u_143.clan.count
				if v_u_62 then
					v184 = v_u_62.count
					v185 = tonumber(v184) or #(v_u_62.rows or {})
					v191 = v_u_62.cap
					v192 = ("%d / %d"):format(v185, tonumber(v191) or 400)
				else
					v192 = ""
				end
				v183.Text = v192
				return
			elseif v199 == 2 then
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 3 then
				if (v188.id == "ok" or v188.id == "empty") and v_u_62 then
					v199 = 10
				else
					v199 = 13
				end
			elseif v199 == 4 then
				if (v188.id == "ok" or v188.id == "empty") and v_u_62 then
					v199 = 10
				else
					v199 = 14
				end
			elseif v199 == 5 then
				if (v188.id == "ok" or v188.id == "empty") and v_u_62 then
					v199 = 10
				else
					v199 = 18
				end
			elseif v199 == 6 then
				if v_u_69 ~= "info" then
					v193 = v_u_68
					v194 = v_u_69
					if v193 == v188.text and (not v_u_61 and v_u_2.statusBusy(v188)) then
						v_u_130.setBusy(v193, v194)
					else
						v_u_130.set(v193, v194)
					end
					v197 = v_u_131
					if v_u_62 and not v_u_190 then
						v198 = v_u_38.limitText
						if v_u_62 then
							v180 = v_u_62.me
							v181 = type(v180) ~= "table" and {} or v_u_62.me
						else
							v181 = {}
						end
						v182 = v198(v181)
					else
						v182 = ""
					end
					v197.Text = v182
					v183 = v_u_143.clan.count
					if v_u_62 then
						v184 = v_u_62.count
						v185 = tonumber(v184) or #(v_u_62.rows or {})
						v191 = v_u_62.cap
						v192 = ("%d / %d"):format(v185, tonumber(v191) or 400)
					else
						v192 = ""
					end
					v183.Text = v192
					return
				end
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 7
				else
					v199 = 3
				end
			elseif v199 == 7 then
				v195 = v_u_62
				if v195 then
					v195 = v_u_62.review
				end
				if (tonumber(v195) or 0) == 0 then
					v199 = 8
				else
					v199 = 4
				end
			elseif v199 == 8 then
				v196 = p_u_31.state().review
				if (tonumber(v196) or 0) == 0 then
					v193 = v_u_68
					v194 = v_u_69
					if v193 == v188.text and (not v_u_61 and v_u_2.statusBusy(v188)) then
						v_u_130.setBusy(v193, v194)
					else
						v_u_130.set(v193, v194)
					end
					v197 = v_u_131
					if v_u_62 and not v_u_190 then
						v198 = v_u_38.limitText
						if v_u_62 then
							v180 = v_u_62.me
							v181 = type(v180) ~= "table" and {} or v_u_62.me
						else
							v181 = {}
						end
						v182 = v198(v181)
					else
						v182 = ""
					end
					v197.Text = v182
					v183 = v_u_143.clan.count
					if v_u_62 then
						v184 = v_u_62.count
						v185 = tonumber(v184) or #(v_u_62.rows or {})
						v191 = v_u_62.cap
						v192 = ("%d / %d"):format(v185, tonumber(v191) or 400)
					else
						v192 = ""
					end
					v183.Text = v192
					return
				end
				if (v188.id == "ok" or v188.id == "empty") and v_u_62 then
					v199 = 10
				else
					v199 = 9
				end
			elseif v199 == 9 then
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 11
				else
					v199 = 16
				end
			elseif v199 == 10 then
				v186 = v_u_62.review
				if (tonumber(v186) or 0) > 0 then
					v193 = v_u_38.UI.STASH_REVIEW
					v194 = "info"
					if v193 == v188.text and (not v_u_61 and v_u_2.statusBusy(v188)) then
						v_u_130.setBusy(v193, v194)
					else
						v_u_130.set(v193, v194)
					end
					v197 = v_u_131
					if v_u_62 and not v_u_190 then
						v198 = v_u_38.limitText
						if v_u_62 then
							v180 = v_u_62.me
							v181 = type(v180) ~= "table" and {} or v_u_62.me
						else
							v181 = {}
						end
						v182 = v198(v181)
					else
						v182 = ""
					end
					v197.Text = v182
					v183 = v_u_143.clan.count
					if v_u_62 then
						v184 = v_u_62.count
						v185 = tonumber(v184) or #(v_u_62.rows or {})
						v191 = v_u_62.cap
						v192 = ("%d / %d"):format(v185, tonumber(v191) or 400)
					else
						v192 = ""
					end
					v183.Text = v192
					return
				end
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 11
				else
					v199 = 12
				end
			elseif v199 == 11 then
				v187 = p_u_31.state().review
				if (tonumber(v187) or 0) > 0 then
					v193 = v_u_38.UI.STASH_REVIEW
					v194 = "info"
					if v193 == v188.text and (not v_u_61 and v_u_2.statusBusy(v188)) then
						v_u_130.setBusy(v193, v194)
					else
						v_u_130.set(v193, v194)
					end
					v197 = v_u_131
					if v_u_62 and not v_u_190 then
						v198 = v_u_38.limitText
						if v_u_62 then
							v180 = v_u_62.me
							v181 = type(v180) ~= "table" and {} or v_u_62.me
						else
							v181 = {}
						end
						v182 = v198(v181)
					else
						v182 = ""
					end
					v197.Text = v182
					v183 = v_u_143.clan.count
					if v_u_62 then
						v184 = v_u_62.count
						v185 = tonumber(v184) or #(v_u_62.rows or {})
						v191 = v_u_62.cap
						v192 = ("%d / %d"):format(v185, tonumber(v191) or 400)
					else
						v192 = ""
					end
					v183.Text = v192
					return
				end
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 12 then
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 13 then
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 11
				else
					v199 = 2
				end
			elseif v199 == 14 then
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 11
				else
					v199 = 17
				end
			elseif v199 == 15 then
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 16 then
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 17 then
				if v188.id == "empty" then
					v193 = ""
					v194 = "info"
				end
				v199 = 1
			elseif v199 == 18 then
				if v188.id == "ok" or v188.id == "empty" then
					v199 = 11
				else
					v199 = 15
				end
			else
				v188 = v_u_155()
				v189 = v188.id == "error" and v_u_63 == "gave_up" and "load" or (v188.id == "completing_long" and "recover" or (v_u_76 and (v_u_78[v_u_76] and os.clock() < v_u_70) and "recover" or nil))
				if v189 ~= v_u_190 then
					v_u_190 = v189
					v_u_161()
				end
				v193 = v188.text
				v194 = v188.kind
				if v_u_68 == "" or os.clock() >= v_u_70 then
					v199 = 5
				else
					v199 = 6
				end
			end
		end
	end
	local function v_u_257(p_u_201) -- name: drawFoot
		-- upvalues: (copy) v_u_143, (copy) v_u_72, (copy) v_u_155, (ref) v_u_62, (copy) v_u_59, (copy) v_u_60, (copy) v_u_36, (copy) v_u_33, (copy) v_u_38, (copy) v_u_35, (copy) v_u_73, (copy) v_u_74, (copy) v_u_46, (ref) v_u_54, (copy) v_u_47, (copy) v_u_45, (copy) v_u_48, (ref) v_u_61, (ref) v_u_2, (copy) v_u_58, (ref) v_u_64, (ref) v_u_1, (copy) v_u_37, (copy) v_u_42, (copy) v_u_257
		local v_u_202 = v_u_143[p_u_201]
		local v_u_203 = v_u_72[p_u_201]
		local v204 = v_u_155()
		local v_u_205
		if v_u_62 then
			local v206 = v_u_62.me
			v_u_205 = type(v206) ~= "table" and {} or v_u_62.me
		else
			v_u_205 = {}
		end
		local v207 = p_u_201 == "mine"
		local v208
		if v207 then
			v208 = v_u_205.canDeposit ~= false
		else
			v208 = v_u_205.canWithdraw ~= false
		end
		if v208 then
			local v_u_209 = v_u_73[p_u_201]
			local v_u_210 = 0
			local v211
			if v_u_209 and v_u_203:has(v_u_209) then
				local v212 = nil
				for _, v213 in v_u_74[p_u_201] do
					if v213.key ~= v_u_209 then
						continue
					end
					v212 = v213
				end
				v_u_210 = not v212 and 0 or v212.have
				v211 = ("%s %d of %d"):format(not v212 and "Item" or v212.name, v_u_203:get(v_u_209), v_u_210)
				if v_u_203:count() > 1 then
					v211 = v211 .. (" (+%d more)"):format(v_u_203:count() - 1)
				end
			elseif v_u_203:count() > 0 then
				v211 = ("%d items picked"):format(v_u_203:count())
			elseif v207 then
				v211 = "Pick items to add"
			else
				v211 = "Pick items to take"
			end
			local v214 = v_u_46 and 140 or 130
			local v215
			if v_u_54 then
				v215 = v_u_54.footParts
			elseif v_u_47 and v_u_47.footParts then
				v215 = v_u_47.footParts(v_u_45.colW, v_u_45.footH, v_u_48, false, v214)
			else
				v215 = nil
			end
			if v215 == nil then
				if v_u_59[p_u_201] ~= "nofoot" then
					v_u_59[p_u_201] = "nofoot"
					local v216 = v_u_60[p_u_201]
					v_u_60[p_u_201] = nil
					if v216 then
						local v217 = v216.busy
						pcall(v217, false)
					end
					v_u_36.clear(v_u_143[p_u_201].foot)
				end
				return
			else
				local v_u_218 = not v204.lock
				if v_u_218 then
					if v_u_209 == nil then
						v_u_218 = false
					else
						v_u_218 = v_u_203:has(v_u_209)
					end
				end
				local v219
				if v_u_61 then
					v219 = nil
				else
					v219 = v_u_2.busyWord(v204, v_u_38, v_u_58)
				end
				local v220 = not v207
				if v220 then
					local v221 = v_u_205.perDay
					if (tonumber(v221) or 0) > 0 then
						local v222 = v_u_203:count()
						local v223 = v_u_205.left
						v220 = (tonumber(v223) or 0) < v222
					else
						v220 = false
					end
				end
				local v224 = v219 == nil and not (v204.lock or v_u_64)
				if v224 then
					if v_u_203:count() > 0 then
						v224 = not v220
					else
						v224 = false
					end
				end
				local v225 = not (v_u_209 and v_u_203:has(v_u_209)) and "0" or tostring(v_u_203:get(v_u_209))
				local v226 = v_u_2.footKey
				local v227 = {
					["word"] = v219,
					["act"] = v224,
					["canStep"] = v_u_218,
					["label"] = v211,
					["qty"] = v225,
					["key"] = v_u_209,
					["have"] = v_u_210,
					["limitBlock"] = v220
				}
				local v228 = v_u_205.left
				v227.left = tonumber(v228) or 0
				local v229 = v226(v227)
				if v229 ~= v_u_59[p_u_201] then
					v_u_59[p_u_201] = v229
					local v_u_230 = nil
					local function v232()
						-- upvalues: (ref) v_u_1, (copy) v_u_202, (ref) v_u_230
						local v231 = v_u_1.SelectedObject
						if v231 ~= nil and v231:IsDescendantOf(v_u_202.foot) then
							v_u_230 = v231.Name
						end
					end
					pcall(v232)
					local v233 = v_u_60[p_u_201]
					v_u_60[p_u_201] = nil
					if v233 then
						local v234 = v233.busy
						pcall(v234, false)
					end
					v_u_36.clear(v_u_143[p_u_201].foot)
					local function v240(p235, p236, p237, p238) -- name: stepBtn
						-- upvalues: (ref) v_u_37, (copy) v_u_202, (copy) v_u_218
						local _, v239 = v_u_37.btn({
							["parent"] = nil,
							["text"] = nil,
							["kind"] = "secondary",
							["width"] = nil,
							["height"] = nil,
							["name"] = nil,
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v_u_202.foot,
							["text"] = p235,
							["width"] = p236.w,
							["height"] = p236.h,
							["name"] = p237,
							["position"] = UDim2.fromOffset(p236.x, p236.y),
							["onClick"] = p238
						})
						v239.enable(v_u_218)
					end
					v240("-", v215.minus, "Minus", function()
						-- upvalues: (copy) v_u_209, (copy) v_u_203, (ref) v_u_210, (ref) v_u_73, (copy) p_u_201, (ref) v_u_42, (ref) v_u_257
						if v_u_209 then
							v_u_203:step(v_u_209, -1, v_u_210)
							if not v_u_203:has(v_u_209) then
								v_u_73[p_u_201] = nil
							end
							v_u_42.paintSel(p_u_201)
							v_u_257(p_u_201)
						end
					end)
					v_u_33.label({
						["parent"] = nil,
						["name"] = "Qty",
						["text"] = nil,
						["style"] = "monoL",
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v_u_202.foot,
						["text"] = v225,
						["position"] = UDim2.fromOffset(v215.qty.x, v215.qty.y),
						["size"] = UDim2.fromOffset(v215.qty.w, v215.qty.h)
					})
					v240("+", v215.plus, "Plus", function()
						-- upvalues: (copy) v_u_209, (copy) v_u_203, (ref) v_u_210, (ref) v_u_42, (copy) p_u_201, (ref) v_u_257
						if v_u_209 then
							v_u_203:step(v_u_209, 1, v_u_210)
							v_u_42.paintSel(p_u_201)
							v_u_257(p_u_201)
						end
					end)
					v240("ALL", v215.all, "All", function()
						-- upvalues: (copy) v_u_209, (copy) v_u_203, (ref) v_u_210, (ref) v_u_42, (copy) p_u_201, (ref) v_u_257
						if v_u_209 then
							v_u_203:all(v_u_209, v_u_210)
							v_u_42.paintSel(p_u_201)
							v_u_257(p_u_201)
						end
					end)
					if v215.picked.w >= 24 then
						v_u_33.label({
							["parent"] = nil,
							["name"] = "Picked",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v_u_202.foot,
							["text"] = v211,
							["color"] = v_u_35.text2,
							["wrap"] = v_u_46,
							["position"] = UDim2.fromOffset(v215.picked.x, v215.picked.y),
							["size"] = UDim2.fromOffset(v215.picked.w, v215.picked.h)
						})
					end
					local v241 = v_u_37.btn
					local v242 = {
						["parent"] = nil,
						["text"] = nil,
						["kind"] = "primary",
						["width"] = nil,
						["maxTextWidth"] = nil,
						["height"] = nil,
						["name"] = "Act",
						["position"] = nil,
						["onClick"] = nil,
						["parent"] = v_u_202.foot,
						["text"] = v207 and "TO CLAN" or "TAKE",
						["width"] = v215.act.w,
						["maxTextWidth"] = v215.act.w - 12,
						["height"] = v215.act.h
					}
					local v243
					if v_u_54 then
						v243 = UDim2.new(0, v215.act.x, 1, -v215.act.h)
					else
						v243 = UDim2.new(1, -v215.act.w, 0, v215.act.y)
					end
					v242.position = v243
					function v242.onClick() -- name: onClick
						-- upvalues: (ref) v_u_42, (copy) p_u_201
						v_u_42.submit(p_u_201)
					end
					local v244, v245 = v241(v242)
					v_u_60[p_u_201] = v245
					if v219 == nil then
						v245.enable(v224)
					else
						v245.busy(true, v219)
					end
					if v220 then
						v_u_33.tooltip(v244, function()
							-- upvalues: (ref) v_u_38, (copy) v_u_205
							local v246 = {
								["title"] = "TAKE",
								["body"] = nil
							}
							local v247 = v_u_38.text
							local v248 = {}
							local v249 = v_u_205.left
							v248.left = tonumber(v249) or 0
							v246.body = v247("LIMIT", v248)
							return v246
						end)
					end
					if v_u_230 ~= nil then
						local function v251()
							-- upvalues: (copy) v_u_202, (ref) v_u_230, (ref) v_u_1
							local v250 = v_u_202.foot:FindFirstChild(v_u_230, true)
							if v250 ~= nil then
								v_u_1.SelectedObject = v250
							end
						end
						pcall(v251)
					end
				end
			end
		else
			if v_u_59[p_u_201] ~= "noright" then
				v_u_59[p_u_201] = "noright"
				local v252 = v_u_60[p_u_201]
				v_u_60[p_u_201] = nil
				if v252 then
					local v253 = v252.busy
					pcall(v253, false)
				end
				v_u_36.clear(v_u_143[p_u_201].foot)
				local v254 = v_u_33.label
				local v255 = {
					["parent"] = nil,
					["name"] = "NoRight",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_202.foot
				}
				local v256
				if v207 then
					v256 = v_u_38.UI.STASH_NO_PUT
				else
					v256 = v_u_38.UI.STASH_NO_TAKE
				end
				v255.text = v256
				v255.color = v_u_35.accent
				v255.size = UDim2.new(1, 0, 1, 0)
				v254(v255)
			end
			return
		end
	end
	local v258 = v_u_143.mine
	local v259 = v_u_143.clan
	v258.side = "mine"
	v259.side = "clan"
	local v_u_260 = v_u_55
	local v_u_261 = v_u_79
	local function v_u_272(p262) -- name: cull
		-- upvalues: (copy) v_u_74, (copy) v_u_36
		local v263 = p262.grid
		local v264 = v263.AbsoluteWindowSize.Y
		local v265 = v263.AbsolutePosition.Y
		for _, v_u_266 in v_u_74[p262.side] do
			local v267, v268 = pcall(function()
				-- upvalues: (copy) v_u_266
				return v_u_266.cell.AbsolutePosition.Y
			end)
			if not v267 then
				continue
			end
			local v269
			if v265 - 200 < v268 then
				v269 = v268 < v265 + v264 + 200
			else
				v269 = false
			end
			local v270 = v_u_36.cellRender
			local v271 = v_u_266.cell
			pcall(v270, v271, v269)
		end
	end
	local function v_u_276(p273) -- name: dropFoot
		-- upvalues: (copy) v_u_60, (copy) v_u_36, (copy) v_u_143
		local v274 = v_u_60[p273]
		v_u_60[p273] = nil
		if v274 then
			local v275 = v274.busy
			pcall(v275, false)
		end
		v_u_36.clear(v_u_143[p273].foot)
	end
	for _, v_u_277 in { "mine", "clan" } do
		v_u_143[v_u_277].grid:GetPropertyChangedSignal("CanvasPosition"):Connect(function()
			-- upvalues: (copy) v_u_272, (copy) v_u_143, (copy) v_u_277
			v_u_272(v_u_143[v_u_277])
		end)
	end
	function v_u_42.paintSel(p278) -- name: paintSel
		-- upvalues: (copy) v_u_72, (copy) v_u_74
		local v279 = v_u_72[p278]
		for _, v280 in v_u_74[p278] do
			local v281 = v279:get(v280.key)
			v280.ring.Visible = v281 > 0
			v280.qty.Visible = v281 > 0
			v280.qty.Text = tostring(v281)
		end
	end
	local function v_u_316(p_u_282, p283, p284, p_u_285, p_u_286, p_u_287, p_u_288, p_u_289, p_u_290) -- name: tileFor
		-- upvalues: (copy) v_u_72, (copy) v_u_36, (copy) v_u_39, (copy) v_u_38, (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (copy) v_u_200, (copy) v_u_73, (copy) v_u_42, (copy) v_u_257, (copy) v_u_35, (copy) v_u_33, (ref) v_u_260, (copy) v_u_74
		local v_u_291 = v_u_72[p_u_282]
		local v292 = v_u_291:get(p_u_285)
		local v308 = v_u_36.itemCell(p283.grid, p_u_286, {
			["size"] = nil,
			["count"] = nil,
			["dim"] = nil,
			["model"] = true,
			["wish"] = false,
			["lazy"] = true,
			["order"] = nil,
			["onClick"] = nil,
			["tooltip"] = nil,
			["size"] = v_u_39.tile,
			["count"] = p_u_287,
			["dim"] = p_u_288,
			["order"] = p284,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_288, (copy) p_u_289, (ref) v_u_38, (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_200, (copy) v_u_291, (copy) p_u_285, (copy) p_u_287, (ref) v_u_73, (copy) p_u_282, (ref) v_u_42, (ref) v_u_257
				if p_u_288 then
					local v293 = p_u_289 or v_u_38.TEXT.ITEM_NOT_ALLOWED
					local v294 = os.clock() + 6
					v_u_68 = v293
					v_u_69 = "warn"
					v_u_70 = v294
					v_u_200()
				else
					if not v_u_291:toggle(p_u_285, p_u_287) and (v_u_291:has(p_u_285) == false and v_u_291:count() >= v_u_291.max) then
						local v295 = os.clock() + 5
						v_u_68 = "You can pick up to 16 items at once."
						v_u_69 = "warn"
						v_u_70 = v295
					end
					local v296 = v_u_73
					local v297 = p_u_282
					local v298
					if v_u_291:has(p_u_285) then
						v298 = p_u_285
					else
						v298 = v_u_73[p_u_282]
					end
					v296[v297] = v298
					if v_u_73[p_u_282] and not v_u_291:has(v_u_73[p_u_282]) then
						v_u_73[p_u_282] = nil
					end
					v_u_42.paintSel(p_u_282)
					v_u_257(p_u_282)
					v_u_200()
				end
			end,
			["tooltip"] = function() -- name: tooltip
				-- upvalues: (copy) p_u_290, (copy) p_u_288, (ref) v_u_35, (ref) v_u_36, (copy) p_u_286, (copy) p_u_289
				local v299 = {}
				if p_u_290 and p_u_290.by then
					local v300 = {
						["label"] = "Added by",
						["value"] = nil,
						["value"] = p_u_290.by
					}
					table.insert(v299, v300)
				end
				if p_u_290 and p_u_290.dur then
					local v301 = {
						["label"] = "Condition",
						["value"] = nil
					}
					local v302 = p_u_290.dur * 100 + 0.5
					v301.value = ("%d%%"):format((math.floor(v302)))
					table.insert(v299, v301)
				end
				if p_u_288 then
					local v303 = {
						["label"] = "Cannot be added",
						["value"] = "",
						["color"] = nil,
						["color"] = v_u_35.danger
					}
					table.insert(v299, v303)
				end
				local v304 = v_u_36.itemName(p_u_286)
				if p_u_290 and p_u_290.cname then
					local v305 = p_u_290.cname
					v304 = tostring(v305)
				end
				local v306 = {
					["title"] = v304
				}
				local v307
				if p_u_288 then
					v307 = p_u_289
				else
					v307 = nil
				end
				v306.body = v307
				v306.lines = v299
				return v306
			end
		})
		v308.SelectionImageObject = v_u_33.selectionImage()
		local v309 = v308:FindFirstChild("Short")
		if v_u_260 and (v309 and v309:IsA("TextLabel")) then
			local v310 = v_u_260.fit
			local v311 = v_u_39.tile + v309.Size.X.Offset
			pcall(v310, v309, v311, 9)
		end
		v308.Name = (p_u_282 == "mine" and "Mine_" or "Clan_") .. p_u_285
		v308:SetAttribute("Key", p_u_285)
		v308:SetAttribute("Dim", p_u_288)
		local v312 = v_u_33.new("Frame", {
			["Name"] = "SelRing",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 8,
			["Visible"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Visible"] = v292 > 0
		}, v308)
		v_u_33.stroke(v312, v_u_35.accent, 2, 0)
		local v313 = v_u_33.label({
			["parent"] = nil,
			["name"] = "SelN",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["zindex"] = 9,
			["visible"] = nil,
			["align"] = "right",
			["track"] = false,
			["parent"] = v308,
			["text"] = tostring(v292),
			["color"] = v_u_35.accent,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.new(1, -3, 0, 2),
			["size"] = UDim2.fromOffset(30, 14),
			["visible"] = v292 > 0
		})
		local v314 = v_u_74[p_u_282]
		local v315 = {
			["cell"] = v308,
			["key"] = p_u_285,
			["have"] = p_u_287,
			["name"] = v_u_36.itemName(p_u_286),
			["ring"] = v312,
			["qty"] = v313
		}
		table.insert(v314, v315)
	end
	function v_u_42.draw() -- name: draw
		-- upvalues: (ref) v_u_43, (copy) v_u_200, (copy) v_u_143, (copy) v_u_33, (copy) v_u_36, (copy) v_u_74, (copy) v_u_90, (copy) v_u_97, (copy) v_u_118, (copy) v_u_72, (copy) v_u_73, (copy) v_u_316, (copy) v_u_38, (copy) v_u_272, (ref) v_u_62, (copy) v_u_124, (copy) v_u_155, (copy) v_u_35, (copy) v_u_257, (copy) v_u_42
		if v_u_43 then
			v_u_200()
			local v_u_317 = v_u_143.mine
			v_u_33.keepScroll(v_u_317.grid, function()
				-- upvalues: (ref) v_u_36, (copy) v_u_317, (ref) v_u_74, (ref) v_u_90, (ref) v_u_97, (ref) v_u_118, (ref) v_u_72, (ref) v_u_73, (ref) v_u_316, (ref) v_u_38
				v_u_36.clear(v_u_317.grid)
				v_u_74.mine = {}
				local v318 = v_u_90()
				local v319 = v_u_97()
				local v320 = {}
				for _, v321 in v318 do
					if type(v321) ~= "table" then
						continue
					end
					local v322 = v321.id
					if type(v322) ~= "string" then
						continue
					end
					local v323 = v321.uid
					if type(v323) ~= "string" then
						continue
					end
					local v324, v325 = v_u_118(v321, v319)
					local v326 = {
						["inst"] = v321,
						["ok"] = v324,
						["why"] = v325,
						["name"] = v_u_36.itemName(v321.id)
					}
					table.insert(v320, v326)
				end
				table.sort(v320, function(p327, p328)
					if p327.ok == p328.ok then
						if p327.name == p328.name then
							return p327.inst.uid < p328.inst.uid
						else
							return p327.name < p328.name
						end
					else
						return p327.ok
					end
				end)
				local v_u_329 = {}
				for _, v330 in v320 do
					local v331 = v330.inst.uid
					local v332 = v330.inst.n
					local v333 = tonumber(v332) or 1
					local v334 = math.floor(v333)
					v_u_329[v331] = math.max(1, v334)
				end
				v_u_72.mine:prune(function(p335)
					-- upvalues: (copy) v_u_329
					return v_u_329[p335] or 0
				end)
				if v_u_73.mine and not v_u_72.mine:has(v_u_73.mine) then
					v_u_73.mine = nil
				end
				for v336, v337 in v320 do
					v_u_316("mine", v_u_317, v336, v337.inst.uid, v337.inst.id, v_u_329[v337.inst.uid], not v337.ok, v337.why, nil)
				end
				v_u_317.empty.Visible = #v320 == 0
				v_u_317.empty.Text = v_u_38.UI.MY_EMPTY
				v_u_317.count.Text = ("%d items"):format(#v320)
			end)
			task.defer(v_u_272, v_u_317)
			local v_u_338 = v_u_143.clan
			v_u_33.keepScroll(v_u_338.grid, function()
				-- upvalues: (ref) v_u_36, (copy) v_u_338, (ref) v_u_74, (ref) v_u_62, (ref) v_u_316, (ref) v_u_124, (ref) v_u_72, (ref) v_u_73, (ref) v_u_155, (ref) v_u_33, (ref) v_u_35, (ref) v_u_38
				v_u_36.clear(v_u_338.grid)
				v_u_74.clan = {}
				local v339
				if v_u_62 then
					local v340 = v_u_62.rows
					v339 = type(v340) ~= "table" and {} or v_u_62.rows
				else
					v339 = {}
				end
				local v_u_341 = {}
				for v342, v343 in v339 do
					if type(v343) ~= "table" then
						continue
					end
					local v344 = v343.r
					if type(v344) ~= "string" then
						continue
					end
					local v345 = v343.id
					if type(v345) ~= "string" then
						continue
					end
					local v346 = v343.n
					local v347 = tonumber(v346) or 1
					local v348 = math.floor(v347)
					local v349 = math.max(1, v348)
					v_u_341[v343.r] = v349
					local v350 = v_u_316
					local v351 = v_u_338
					local v352 = v343.r
					local v353 = v343.id
					local v354 = {
						["by"] = v_u_124(v343.by)
					}
					local v355 = v343.dur
					v354.dur = tonumber(v355)
					v354.cname = v343.cname
					v350("clan", v351, v342, v352, v353, v349, false, nil, v354)
				end
				v_u_72.clan:prune(function(p356)
					-- upvalues: (copy) v_u_341
					return v_u_341[p356] or 0
				end)
				if v_u_73.clan and not v_u_72.clan:has(v_u_73.clan) then
					v_u_73.clan = nil
				end
				local v357 = v_u_155()
				if v357.id == "loading" then
					for v358 = 1, 12 do
						v_u_33.new("Frame", {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.6,
							["BorderSizePixel"] = 0,
							["LayoutOrder"] = nil,
							["Name"] = "Skeleton" .. v358,
							["BackgroundColor3"] = v_u_35.raised,
							["LayoutOrder"] = v358
						}, v_u_338.grid)
					end
				end
				if v357.id == "loading" or v357.id == "error" then
					v_u_338.empty.Visible = true
					v_u_338.empty.Text = v357.text
				else
					v_u_338.empty.Visible = #v339 == 0
					v_u_338.empty.Text = v_u_38.stashEmptyText(v_u_62)
				end
			end)
			task.defer(v_u_272, v_u_338)
			v_u_257("mine")
			v_u_257("clan")
			v_u_42.layoutSides()
		end
	end
	local function v_u_367(p359) -- name: showLast
		-- upvalues: (ref) v_u_80, (ref) v_u_81, (ref) v_u_76, (copy) v_u_38, (ref) v_u_68, (ref) v_u_69, (ref) v_u_70
		local v360
		if type(p359) == "table" then
			v360 = p359.last
		else
			v360 = nil
		end
		if type(v360) == "table" and (v_u_80 ~= nil and v360.opId == v_u_80) then
			if v360.code == nil or v360.code == "OK" then
				v_u_76 = nil
				local v361 = v_u_38.UI.STASH_DONE
				local v362 = os.clock() + 5
				v_u_68 = v361
				v_u_69 = "info"
				v_u_70 = v362
			else
				v_u_81 = nil
				local v363 = v360.code
				local v364
				if type(v363) == "string" then
					v364 = v360.code
				else
					v364 = nil
				end
				v_u_76 = v364
				local v365 = v_u_38.text(v360.code, v360)
				local v366 = os.clock() + 10
				v_u_68 = v365
				v_u_69 = "danger"
				v_u_70 = v366
			end
			v_u_80 = nil
		end
	end
	local function v_u_372(p368, p369) -- name: take
		-- upvalues: (ref) v_u_62, (ref) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_367, (copy) v_u_42, (ref) v_u_81
		v_u_62 = p368
		v_u_63 = nil
		if v_u_64 and (p368.tx == nil and (not p369 or os.clock() - v_u_65 > 1)) then
			v_u_367(p368)
			v_u_42.completed()
			if v_u_81 then
				v_u_81.at = os.clock()
			end
		end
		local v370 = v_u_81
		if not v370 or p368.tx == nil and not v_u_64 then
			if v370 then
				local v371 = p368.rev
				if (tonumber(v371) or 0) > v370.rev or os.clock() - v370.at > 30 then
					v_u_81 = nil
				end
			end
		end
	end
	function v_u_42.load(_) -- name: load
		-- upvalues: (ref) v_u_75, (ref) v_u_62, (ref) v_u_63, (copy) v_u_42, (ref) v_u_43, (copy) p_u_31, (copy) v_u_372
		v_u_75 = v_u_75 + 1
		local v_u_373 = v_u_75
		if v_u_62 == nil then
			v_u_63 = nil
			v_u_42.draw()
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_43, (copy) v_u_373, (ref) v_u_75, (ref) p_u_31, (ref) v_u_62, (ref) v_u_63, (ref) v_u_42, (ref) v_u_372
			local v374 = nil
			for v375 = 0, 3 do
				if v375 > 0 then
					task.wait(2 ^ (v375 - 1) * 3)
					if not v_u_43 or v_u_373 ~= v_u_75 then
						return
					end
				end
				v374 = p_u_31.fetch("clanStash", nil, 0)
				if v374 ~= nil then
					break
				end
				if v_u_62 ~= nil then
					continue
				end
				v_u_63 = v375 < 3 and "retry" or "gave_up"
				v_u_42.draw()
			end
			if v_u_43 and v_u_373 == v_u_75 then
				if v374 ~= nil then
					local v376 = v374.rows
					if type(v376) == "table" then
						v_u_372(v374, true)
					end
				end
				v_u_42.draw()
			end
		end)
	end
	function v_u_42.retry() -- name: retry
		-- upvalues: (ref) v_u_190, (ref) v_u_63, (copy) v_u_42, (copy) v_u_133, (copy) p_u_31, (ref) v_u_43, (ref) v_u_76, (ref) v_u_68, (copy) v_u_38, (ref) v_u_69, (ref) v_u_70
		if v_u_190 == "load" then
			v_u_63 = nil
			v_u_42.load()
		elseif v_u_190 == "recover" then
			v_u_133.busy(true, "...")
			p_u_31.send("clanRecover", {}, function(p377, p378, p379, p380)
				-- upvalues: (ref) v_u_43, (ref) v_u_133, (ref) v_u_76, (ref) v_u_68, (ref) v_u_38, (ref) v_u_69, (ref) v_u_70, (ref) v_u_42
				if v_u_43 then
					local v381 = v_u_133.busy
					pcall(v381, false)
					v_u_76 = nil
					v_u_68 = ""
					if not p377 then
						local v382 = v_u_38.reasonFor
						if not p380 then
							p380 = {
								["msg"] = p378,
								["data"] = p379
							}
						end
						local v383 = v382(p380)
						local v384 = os.clock() + 8
						v_u_68 = v383
						v_u_69 = "warn"
						v_u_70 = v384
					end
					v_u_42.load()
				end
			end, 20)
		end
	end
	function v_u_42.refreshBag() -- name: refreshBag
		-- upvalues: (copy) p_u_31, (ref) v_u_261, (ref) v_u_43, (copy) v_u_42
		task.spawn(function()
			-- upvalues: (ref) p_u_31, (ref) v_u_261, (ref) v_u_43, (ref) v_u_42
			local v385 = p_u_31.mc.invalidate
			pcall(v385, "profile")
			local v386 = p_u_31.fetch("profile", nil, 0)
			if type(v386) == "table" then
				v_u_261 = v386
			end
			if v_u_43 then
				v_u_42.draw()
			end
		end)
	end
	function v_u_42.completed() -- name: completed
		-- upvalues: (ref) v_u_64, (copy) v_u_72, (copy) v_u_73, (copy) v_u_42
		v_u_64 = false
		v_u_72.mine:clear()
		v_u_72.clan:clear()
		local v387 = v_u_73
		v_u_73.mine = nil
		v387.clan = nil
		v_u_42.refreshBag()
	end
	function v_u_42.submit(p388) -- name: submit
		-- upvalues: (copy) v_u_72, (ref) v_u_64, (ref) v_u_62, (ref) v_u_65, (ref) v_u_66, (ref) v_u_68, (ref) v_u_76, (ref) v_u_80, (copy) v_u_42, (copy) p_u_31, (ref) v_u_43, (copy) v_u_38, (ref) v_u_69, (ref) v_u_70, (ref) v_u_81
		local v389 = v_u_72[p388]
		if not v_u_64 and v389:count() ~= 0 then
			local v390 = p388 == "mine" and "clanDeposit" or "clanWithdraw"
			local v391 = v389:lines(p388 == "mine" and "uid" or "r")
			local v392 = v_u_62
			if v392 then
				v392 = v_u_62.rev
			end
			local v_u_393 = tonumber(v392) or 0
			v_u_64 = true
			v_u_65 = os.clock()
			v_u_66 = os.clock()
			v_u_68 = ""
			v_u_76 = nil
			v_u_80 = nil
			v_u_42.draw()
			p_u_31.send(v390, {
				["lines"] = v391
			}, function(p394, p395, p396, p397)
				-- upvalues: (ref) v_u_43, (ref) v_u_64, (ref) v_u_76, (ref) v_u_38, (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_42, (ref) v_u_80, (ref) v_u_81, (copy) v_u_393
				if v_u_43 then
					if p394 then
						local v398
						if type(p396) == "table" then
							v398 = p396.state
						else
							v398 = nil
						end
						local v399
						if type(p396) == "table" then
							local v400 = p396.opId
							if type(v400) == "string" then
								v399 = p396.opId
							else
								v399 = nil
							end
						else
							v399 = nil
						end
						v_u_80 = v399
						v_u_81 = {
							["rev"] = v_u_393,
							["at"] = os.clock()
						}
						if v398 ~= "completing" then
							v_u_42.completed()
						end
						v_u_42.load()
					else
						v_u_64 = false
						local v401
						if type(p396) == "table" then
							local v402 = p396.code
							if type(v402) == "string" then
								v401 = p396.code
							else
								v401 = nil
							end
						else
							v401 = nil
						end
						v_u_76 = v401
						local v403 = v_u_38.reasonFor(p397 or {
							["msg"] = p395,
							["data"] = p396
						})
						local v404 = os.clock() + 10
						v_u_68 = v403
						v_u_69 = "danger"
						v_u_70 = v404
						v_u_42.draw()
						v_u_42.load()
						v_u_42.refreshBag()
					end
				else
					return
				end
			end, 30)
		end
	end
	function v_u_42.show() -- name: show
		-- upvalues: (ref) v_u_44, (ref) v_u_61, (ref) v_u_64, (ref) v_u_65, (copy) v_u_38, (copy) v_u_42, (copy) p_u_31, (ref) v_u_54, (copy) v_u_39, (ref) v_u_57, (copy) p_u_32, (ref) v_u_136, (copy) v_u_143, (ref) v_u_43
		v_u_44 = true
		v_u_61 = false
		if v_u_64 and os.clock() - v_u_65 > v_u_38.POLL_MAX_SEC then
			v_u_64 = false
		end
		v_u_42.draw()
		v_u_42.load()
		local function v411()
			-- upvalues: (ref) p_u_31, (ref) v_u_54, (ref) v_u_39, (ref) v_u_57, (ref) p_u_32, (ref) v_u_136, (ref) v_u_143, (ref) v_u_43, (ref) v_u_44, (ref) v_u_42
			local v405 = p_u_31.lib("MenuTipOnce")
			if v405 and (v405.TIPS and v405.TIPS.clan) then
				local v406
				if v_u_54 then
					local v407 = v_u_39.inner - v_u_54.switch.w - 40
					local v408 = math.floor(v407)
					local v409 = math.min(440, v408)
					v406 = math.max(200, v409)
				else
					v406 = nil
				end
				v_u_57 = v405.show(p_u_31.mc, "clan", {
					["host"] = p_u_32,
					["sides"] = v_u_54 and { "right" } or { "above", "right" },
					["width"] = v406,
					["slim"] = v_u_54 ~= nil,
					["target"] = function() -- name: target
						-- upvalues: (ref) v_u_54, (ref) v_u_136, (ref) v_u_143
						if v_u_54 and v_u_136 then
							return v_u_136
						else
							return v_u_143.mine.title
						end
					end,
					["active"] = function() -- name: active
						-- upvalues: (ref) v_u_43, (ref) v_u_44
						local v410 = v_u_43
						if v410 then
							v410 = v_u_44
						end
						return v410
					end
				})
				if not v_u_54 then
					v_u_42.watchTip()
				end
			end
		end
		pcall(v411)
	end
	function v_u_42.hide() -- name: hide
		-- upvalues: (ref) v_u_44, (ref) v_u_61, (copy) v_u_59, (copy) v_u_276, (copy) v_u_130
		v_u_44 = false
		v_u_61 = true
		for _, v412 in { "mine", "clan" } do
			v_u_59[v412] = nil
			local v413 = v_u_276
			pcall(v413, v412)
		end
		local v414 = v_u_130.set
		pcall(v414, "", "info")
	end
	local v_u_415 = nil
	local function v_u_423(p416) -- name: setBand
		-- upvalues: (ref) v_u_41, (copy) v_u_47, (ref) v_u_415, (ref) v_u_43, (copy) v_u_40
		local v417 = math.ceil(p416)
		local v_u_418 = math.max(0, v417)
		if v_u_418 ~= v_u_41 then
			local v_u_419
			if v_u_47 and v_u_47.bandMove then
				v_u_419 = v_u_47.bandMove(v_u_41, v_u_418)
			else
				v_u_419 = nil
			end
			v_u_41 = v_u_418
			if v_u_415 then
				v_u_415:Cancel()
				v_u_415 = nil
			end
			local v420
			if v_u_419 and (v_u_43 and v_u_40.Parent ~= nil) then
				local function v422()
					-- upvalues: (ref) v_u_40, (copy) v_u_419, (ref) v_u_418, (ref) v_u_415
					local v421 = game:GetService("TweenService"):Create(v_u_40, TweenInfo.new(v_u_419.time, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = UDim2.fromOffset(0, v_u_418),
						["Size"] = UDim2.new(1, 0, 1, -v_u_418)
					})
					v_u_415 = v421
					v421:Play()
				end
				v420 = pcall(v422)
			else
				v420 = false
			end
			if not v420 then
				v_u_40.Position = UDim2.fromOffset(0, v_u_418)
				v_u_40.Size = UDim2.new(1, 0, 1, -v_u_418)
			end
		end
	end
	function v_u_42.watchTip() -- name: watchTip
		-- upvalues: (ref) v_u_43, (ref) v_u_57, (ref) v_u_54, (copy) v_u_134, (copy) v_u_47, (copy) v_u_34, (copy) v_u_423
		task.spawn(function()
			-- upvalues: (ref) v_u_43, (ref) v_u_57, (ref) v_u_54, (ref) v_u_134, (ref) v_u_47, (ref) v_u_34, (ref) v_u_423
			local v424 = os.clock()
			while v_u_43 and (v_u_57 ~= nil and os.clock() - v424 < 140) do
				local v425 = v_u_57
				if v425.shown() then
					local v426 = v425.card()
					local v427
					if v426 then
						local v428 = v_u_54 and 0 or v_u_134
						if v_u_47 and v_u_47.tipBand then
							local v429 = v_u_47.tipBand
							local v430 = v426.AbsoluteSize.Y
							local v431 = v_u_34.uiScale
							local v432
							if type(v431) == "function" then
								local v433 = v_u_34.uiScale
								v432 = math.max(0.01, v433())
							else
								v432 = 1
							end
							v427 = v429(v430, v432, v428)
						else
							local v434 = 0
							local v435 = v426.AbsoluteSize.Y
							local v436 = v_u_34.uiScale
							local v437
							if type(v436) == "function" then
								local v438 = v_u_34.uiScale
								v437 = math.max(0.01, v438())
							else
								v437 = 1
							end
							local v439 = v435 / v437 + 24 - v428
							v427 = math.max(v434, v439)
						end
					else
						v427 = 0
					end
					v_u_423(v427)
				elseif not v425.alive() then
					break
				end
				task.wait(0.1)
			end
			v_u_423(0)
		end)
	end
	function v_u_42.refresh(p440, _) -- name: refresh
		-- upvalues: (ref) v_u_261, (copy) v_u_42
		if p440 == "profile" then
			v_u_261 = nil
		end
		if p440 == "state" or p440 == "profile" then
			v_u_42.draw()
		end
	end
	function v_u_42.tick() -- name: tick
		-- upvalues: (ref) v_u_43, (ref) v_u_44, (copy) v_u_155, (ref) v_u_81, (ref) v_u_64, (copy) v_u_38, (ref) v_u_68, (ref) v_u_70, (copy) v_u_200, (ref) v_u_62, (ref) v_u_66, (ref) v_u_65, (ref) v_u_67, (copy) p_u_31, (copy) v_u_372, (copy) v_u_42, (copy) v_u_257
		if not (v_u_43 and v_u_44) then
			return
		end
		local v441 = v_u_155()
		if v_u_81 and (not v_u_64 and os.clock() - v_u_81.at > 30 + v_u_38.POLL_SEC) then
			v_u_81 = nil
		end
		if v_u_68 ~= "" and v_u_70 <= os.clock() then
			v_u_68 = ""
			v_u_200()
		end
		local v442 = v_u_64
		if not v442 then
			if v_u_62 == nil then
				if v441.id == "syncing" then
					v442 = true
				elseif v_u_81 == nil then
					v442 = false
				else
					v442 = os.clock() - v_u_81.at <= 30 + v_u_38.POLL_SEC
				end
			else
				local v443 = v_u_62.tx
				if type(v443) == "table" then
					v442 = true
				elseif v441.id == "syncing" then
					v442 = true
				elseif v_u_81 == nil then
					v442 = false
				else
					v442 = os.clock() - v_u_81.at <= 30 + v_u_38.POLL_SEC
				end
			end
		end
		if v442 and (os.clock() - v_u_66 >= v_u_38.POLL_SEC and (not v_u_64 or os.clock() - v_u_65 < v_u_38.POLL_MAX_SEC + v_u_38.POLL_SEC)) and (not v_u_67 and v_u_43) then
			v_u_67 = true
			v_u_66 = os.clock()
			task.spawn(function()
				-- upvalues: (ref) p_u_31, (ref) v_u_67, (ref) v_u_43, (ref) v_u_372, (ref) v_u_42
				local v444 = p_u_31.fetch("clanStash", nil, 0)
				v_u_67 = false
				if v_u_43 then
					if v444 ~= nil then
						local v445 = v444.rows
						if type(v445) == "table" then
							v_u_372(v444, false)
							v_u_42.draw()
						end
					end
				end
			end)
		end
		if v_u_64 and os.clock() - v_u_65 >= v_u_38.POLL_MAX_SEC then
			v_u_200()
			v_u_257("mine")
			v_u_257("clan")
		end
	end
	local v_u_446 = nil
	local function v459()
		-- upvalues: (copy) p_u_31, (ref) v_u_446, (ref) v_u_43, (ref) v_u_44, (ref) v_u_1, (copy) v_u_143, (copy) v_u_74, (copy) v_u_72, (copy) v_u_73, (copy) v_u_42, (copy) v_u_257, (copy) v_u_39, (ref) v_u_71, (ref) v_u_135
		local v447 = p_u_31.lib("VirtualPad")
		if v447 and v447.InputBegan then
			v_u_446 = v447.InputBegan:Connect(function(p448)
				-- upvalues: (ref) v_u_43, (ref) v_u_44, (ref) v_u_1, (ref) v_u_143, (ref) v_u_74, (ref) v_u_72, (ref) v_u_73, (ref) v_u_42, (ref) v_u_257, (ref) v_u_39, (ref) v_u_71, (ref) v_u_135
				if v_u_43 and v_u_44 then
					local v449 = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
					if v449 then
						v449 = v449:FindFirstChild("HushModal")
					end
					if not (v449 and v449:FindFirstChild("Modal", true)) then
						local v450 = v_u_1.SelectedObject
						local v451 = nil
						for _, v452 in { "mine", "clan" } do
							if not (v450 and v450:IsDescendantOf(v_u_143[v452].grid)) then
								continue
							end
							v451 = v452
						end
						if p448.KeyCode == Enum.KeyCode.ButtonX or p448.KeyCode == Enum.KeyCode.ButtonY then
							if v451 and v450 then
								local v453 = v450:GetAttribute("Key")
								local v454 = nil
								for _, v455 in v_u_74[v451] do
									if v455.key ~= v453 then
										continue
									end
									v454 = v455
								end
								if v454 and v450:GetAttribute("Dim") ~= true then
									v_u_72[v451]:step(v453, p448.KeyCode == Enum.KeyCode.ButtonX and 1 or -1, v454.have)
									local v456 = v_u_73
									if not v_u_72[v451]:has(v453) then
										v453 = v_u_73[v451]
									end
									v456[v451] = v453
									v_u_42.paintSel(v451)
									v_u_257(v451)
									return
								end
							end
						elseif p448.KeyCode == Enum.KeyCode.ButtonR1 then
							local v457 = v451 == "mine" and "clan" or "mine"
							if v_u_39.switch then
								v_u_71 = v457
								if v_u_135 then
									v_u_135.select(v457, true)
								end
								v_u_42.layoutSides()
							end
							local v458 = v_u_143[v457].grid:FindFirstChildWhichIsA("GuiButton")
							if v458 then
								v_u_1.SelectedObject = v458
							end
						end
					end
				else
					return
				end
			end)
		end
	end
	pcall(v459)
	function v_u_42.destroy() -- name: destroy
		-- upvalues: (ref) v_u_43, (ref) v_u_75, (copy) v_u_59, (copy) v_u_276, (copy) v_u_130, (ref) v_u_446
		v_u_43 = false
		v_u_75 = v_u_75 + 1
		for _, v460 in { "mine", "clan" } do
			v_u_59[v460] = nil
			local v461 = v_u_276
			pcall(v461, v460)
		end
		local v462 = v_u_130.set
		pcall(v462, "", "info")
		if v_u_446 then
			local function v463()
				-- upvalues: (ref) v_u_446
				v_u_446:Disconnect()
			end
			pcall(v463)
		end
	end
	v_u_42.layoutSides()
	v_u_42.draw()
	return v_u_42
end
return v_u_2