-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ScopeView

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {}
local v_u_5 = require(script.Parent:WaitForChild("ScopeLayout"))
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = false
local v_u_9 = 0
local v_u_10 = false
local v_u_11 = 0
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = 0
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = ""
local v_u_18 = ""
local v_u_19 = 0
local v_u_20 = true
local v_u_21 = -1
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = ""
local v_u_25 = 0
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = {}
local v_u_29 = {}
local v_u_30 = nil
local v_u_31 = 0.6
local v_u_32 = nil
local v_u_33 = {}
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = Color3.new(0, 0, 0)
local v_u_37 = Color3.fromRGB(10, 10, 10)
local function v_u_45() -- name: assetId
	-- upvalues: (copy) v_u_6, (copy) v_u_2
	local v38 = v_u_6.Config
	if v38 == nil then
		local v_u_39 = "Config"
		local function v40()
			-- upvalues: (ref) v_u_2, (copy) v_u_39
			return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_39))
		end
		local v41
		v41, v38 = pcall(v40)
		if not v41 or type(v38) ~= "table" then
			v38 = false
		end
		v_u_6.Config = v38
	end
	local v42 = v38 or nil
	local v43
	if v42 == nil then
		v43 = nil
	else
		v43 = v42.SCOPE_VIGNETTE_ASSET
	end
	if type(v43) == "number" then
		local v44 = math.floor(v43)
		v43 = tostring(v44)
	end
	if type(v43) == "string" and v43 ~= "" then
		if string.match(v43, "^%d+$") then
			return "rbxassetid://" .. v43
		else
			return v43
		end
	else
		return ""
	end
end
local function v_u_56() -- name: viewportSize
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_3
	local v46 = v_u_6.Theme
	if v46 == nil then
		local v_u_47 = "Theme"
		local function v48()
			-- upvalues: (ref) v_u_2, (copy) v_u_47
			return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_47))
		end
		local v49
		v49, v46 = pcall(v48)
		if not v49 or type(v46) ~= "table" then
			v46 = false
		end
		v_u_6.Theme = v46
	end
	local v50 = v46 or nil
	if v50 ~= nil then
		local v51 = v50.viewport
		if type(v51) == "function" then
			local v52 = v50.viewport
			local v53, v54 = pcall(v52)
			if v53 and (typeof(v54) == "Vector2" and (v54.X > 8 and v54.Y > 8)) then
				return v54.X, v54.Y
			end
		end
	end
	local v55 = v_u_3.CurrentCamera
	if v55 == nil or v55.ViewportSize.X <= 8 then
		return 1920, 1080
	else
		return v55.ViewportSize.X, v55.ViewportSize.Y
	end
end
local function v_u_64(p57, p58, p59, p60, p61, p62) -- name: newFrame
	-- upvalues: (copy) v_u_36
	local v63 = Instance.new("Frame")
	v63.Name = p58
	v63.BackgroundColor3 = v_u_36
	v63.BackgroundTransparency = 1
	v63.BorderSizePixel = 0
	v63.Position = UDim2.fromOffset(p59, p60)
	v63.Size = UDim2.fromOffset(p61, p62)
	v63.Active = false
	v63.Parent = p57
	return v63
end
local function v_u_65() -- name: destroyContent
	-- upvalues: (ref) v_u_13, (copy) v_u_28, (copy) v_u_29, (copy) v_u_33, (ref) v_u_30, (ref) v_u_32, (ref) v_u_34, (ref) v_u_18, (ref) v_u_21
	if v_u_13 ~= nil then
		v_u_13:ClearAllChildren()
	end
	table.clear(v_u_28)
	table.clear(v_u_29)
	table.clear(v_u_33)
	v_u_30 = nil
	v_u_32 = nil
	v_u_34 = nil
	v_u_18 = ""
	v_u_21 = -1
end
local function v_u_71(p66, p67, p_u_68) -- name: strokeOf
	-- upvalues: (copy) v_u_36
	local v_u_69 = Instance.new("UIStroke")
	v_u_69.Color = v_u_36
	v_u_69.Thickness = p67
	v_u_69.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v_u_69.Transparency = 1
	local v70 = pcall(function()
		-- upvalues: (copy) v_u_69, (copy) p_u_68
		v_u_69.BorderStrokePosition = Enum.BorderStrokePosition[p_u_68]
	end)
	v_u_69.Parent = p66
	return v_u_69, v70
end
local function v_u_82(p72, p73, p74, p75, p76) -- name: buildReticle
	-- upvalues: (ref) v_u_13, (ref) v_u_34, (copy) v_u_33, (ref) v_u_18, (copy) v_u_5, (copy) v_u_37, (ref) v_u_21
	if v_u_13 == nil then
		return
	else
		if v_u_34 ~= nil then
			v_u_34:Destroy()
			v_u_34 = nil
		end
		table.clear(v_u_33)
		v_u_18 = p72
		local v77 = v_u_5.reticle(p72, p75, p76)
		if #v77 ~= 0 then
			local v78 = Instance.new("Frame")
			v78.Name = "Reticle"
			v78.BackgroundTransparency = 1
			v78.BorderSizePixel = 0
			v78.AnchorPoint = Vector2.new(0.5, 0.5)
			v78.Position = UDim2.fromOffset(p73, p74)
			v78.Size = UDim2.fromOffset(0, 0)
			v78.Active = false
			v78.ZIndex = 5
			v78.Parent = v_u_13
			v_u_34 = v78
			for _, v79 in v77 do
				local v80 = Instance.new("Frame")
				v80.Name = v79.tag
				v80.BackgroundColor3 = v_u_37
				v80.BackgroundTransparency = 1
				v80.BorderSizePixel = 0
				v80.AnchorPoint = Vector2.new(0.5, 0.5)
				v80.Position = UDim2.fromOffset(v79.x, v79.y)
				v80.Size = UDim2.fromOffset(v79.w, v79.h)
				v80.Rotation = v79.rot
				v80.Active = false
				v80.ZIndex = 5
				v80.Parent = v78
				local v81 = v_u_33
				table.insert(v81, v80)
			end
			v_u_21 = -1
		end
	end
end
local function v_u_111(p83, p84, p85, p86) -- name: build
	-- upvalues: (copy) v_u_65, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (copy) v_u_5, (copy) v_u_36, (ref) v_u_32, (copy) v_u_28, (copy) v_u_64, (copy) v_u_71, (copy) v_u_29, (ref) v_u_31, (ref) v_u_30, (ref) v_u_21
	v_u_65()
	if v_u_12 ~= nil and v_u_13 ~= nil then
		v_u_14 = p83
		v_u_15 = p84
		v_u_16 = p85
		v_u_17 = p86
		if p86 == "" then
			local v87 = v_u_5.bars(p83, p84, nil, p85)
			local v88 = Instance.new("Folder")
			v88.Name = "Bars"
			v88.Parent = v_u_13
			for v89, v90 in v87.rows do
				if v90.lw > 0 then
					local v91 = v_u_28
					local v92 = v_u_64(v88, "L" .. v89, 0, v90.y, v90.lw, v90.h)
					table.insert(v91, v92)
				end
				if v90.rw <= 0 then
					continue
				end
				local v93 = v_u_28
				local v94 = v_u_64(v88, "R" .. v89, v90.rx, v90.y, v90.rw, v90.h)
				table.insert(v93, v94)
			end
			local v95 = v87.circle
			local v96 = Instance.new("Frame")
			v96.Name = "Ring"
			v96.BackgroundTransparency = 1
			v96.BorderSizePixel = 0
			v96.AnchorPoint = Vector2.new(0.5, 0.5)
			v96.Position = UDim2.fromOffset(v95.cx, v95.cy)
			v96.Size = UDim2.fromOffset(v95.d, v95.d)
			v96.Active = false
			local v97 = Instance.new("UICorner")
			v97.CornerRadius = UDim.new(0.5, 0)
			v97.Parent = v96
			local v98, v99 = v_u_71(v96, v87.ring.thickness, "Outer")
			local v100 = v_u_29
			table.insert(v100, v98)
			v96.Parent = v_u_13
			local v101 = Instance.new("Frame")
			v101.Name = "Soft"
			v101.BackgroundTransparency = 1
			v101.BorderSizePixel = 0
			v101.AnchorPoint = Vector2.new(0.5, 0.5)
			v101.Position = UDim2.fromOffset(v95.cx, v95.cy)
			v101.Size = UDim2.fromOffset(v95.d, v95.d)
			v101.Active = false
			local v102 = Instance.new("UICorner")
			v102.CornerRadius = UDim.new(0.5, 0)
			v102.Parent = v101
			local v103, v104 = v_u_71(v101, v87.ring.soft, "Inner")
			v_u_31 = v87.ring.softTransparency
			if v104 and v99 then
				v_u_30 = v103
				v101.Parent = v_u_13
			else
				v103:Destroy()
				v101:Destroy()
			end
		else
			local v105 = v_u_5.imageLayout(p83, p84)
			local v106 = Instance.new("ImageLabel")
			v106.Name = "Vignette"
			v106.BackgroundTransparency = 1
			v106.BorderSizePixel = 0
			v106.Image = p86
			v106.ImageColor3 = v_u_36
			v106.ImageTransparency = 1
			v106.ScaleType = Enum.ScaleType.Stretch
			v106.Position = UDim2.fromOffset(v105.square.x, v105.square.y)
			v106.Size = UDim2.fromOffset(v105.square.size, v105.square.size)
			v106.Active = false
			v106.Parent = v_u_13
			v_u_32 = v106
			for v107, v108 in v105.fill do
				local v109 = v_u_28
				local v110 = v_u_64(v_u_13, "Fill" .. v107, v108.x, v108.y, v108.w, v108.h)
				table.insert(v109, v110)
			end
		end
		v_u_21 = -1
	end
end
local function v_u_116() -- name: ensureGui
	-- upvalues: (ref) v_u_12, (copy) v_u_1, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_20
	if v_u_12 ~= nil and v_u_12.Parent ~= nil then
		return true
	end
	local v112 = v_u_1.LocalPlayer
	local v113
	if v112 then
		v113 = v112:FindFirstChildOfClass("PlayerGui")
	else
		v113 = nil
	end
	if v113 == nil then
		return false
	end
	local v_u_114 = Instance.new("ScreenGui")
	v_u_114.Name = "HushScope"
	v_u_114.ResetOnSpawn = false
	v_u_114.IgnoreGuiInset = true
	v_u_114.DisplayOrder = 3
	v_u_114.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_114.Enabled = false
	pcall(function()
		-- upvalues: (copy) v_u_114
		v_u_114.ScreenInsets = Enum.ScreenInsets.None
	end)
	local v115 = Instance.new("Frame")
	v115.Name = "Root"
	v115.BackgroundTransparency = 1
	v115.BorderSizePixel = 0
	v115.Size = UDim2.fromScale(1, 1)
	v115.Active = false
	v115.Parent = v_u_114
	v_u_114.Parent = v113
	v_u_12 = v_u_114
	v_u_13 = v115
	v_u_14 = 0
	v_u_15 = 0
	v_u_20 = true
	return true
end
local function v_u_134(p117) -- name: refresh
	-- upvalues: (copy) v_u_116, (copy) v_u_56, (copy) v_u_6, (copy) v_u_2, (copy) v_u_45, (ref) v_u_20, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (copy) v_u_111, (ref) v_u_11, (ref) v_u_18
	if v_u_116() then
		local v118, v119 = v_u_56()
		local v120 = v_u_6.Theme
		if v120 == nil then
			local v_u_121 = "Theme"
			local function v122()
				-- upvalues: (ref) v_u_2, (copy) v_u_121
				return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_121))
			end
			local v123
			v123, v120 = pcall(v122)
			if not v123 or type(v120) ~= "table" then
				v120 = false
			end
			v_u_6.Theme = v120
		end
		local v124 = v120 or nil
		local v125
		if v124 == nil then
			v125 = 1
		else
			local v126 = v124.uiScale
			if type(v126) == "function" then
				local v127 = v124.uiScale
				local v128, v129 = pcall(v127)
				v125 = (not v128 or (type(v129) ~= "number" or v129 <= 0)) and 1 or v129
			else
				v125 = 1
			end
		end
		local v130 = v_u_45()
		if p117 or (v_u_20 or (v118 ~= v_u_14 or (v119 ~= v_u_15 or (v125 ~= v_u_16 or v130 ~= v_u_17)))) then
			v_u_20 = false
			local v131 = v_u_111
			local v132, v133 = pcall(v131, v118, v119, v125, v130)
			if not v132 then
				v_u_11 = v_u_11 + 1
				if v_u_11 <= 3 then
					warn("[ScopeView] " .. "build" .. ": " .. tostring(v133))
				end
			end
			v_u_18 = ""
		end
	end
end
local function v_u_155(p135) -- name: setKind
	-- upvalues: (ref) v_u_18, (ref) v_u_14, (ref) v_u_15, (copy) v_u_56, (copy) v_u_5, (copy) v_u_82, (copy) v_u_6, (copy) v_u_2, (ref) v_u_11
	if p135 ~= v_u_18 then
		local v136 = v_u_14
		local v137 = v_u_15
		if v136 < 8 then
			v136, v137 = v_u_56()
		end
		local v138 = v_u_5.circle(v136, v137)
		local v139 = v_u_82
		local v140 = v138.cx
		local v141 = v138.cy
		local v142 = v138.r
		local v143 = v_u_6.Theme
		if v143 == nil then
			local v_u_144 = "Theme"
			local function v145()
				-- upvalues: (ref) v_u_2, (copy) v_u_144
				return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_144))
			end
			local v146
			v146, v143 = pcall(v145)
			if not v146 or type(v143) ~= "table" then
				v143 = false
			end
			v_u_6.Theme = v143
		end
		local v147 = v143 or nil
		local v148
		if v147 == nil then
			v148 = 1
		else
			local v149 = v147.uiScale
			if type(v149) == "function" then
				local v150 = v147.uiScale
				local v151, v152 = pcall(v150)
				v148 = (not v151 or (type(v152) ~= "number" or v152 <= 0)) and 1 or v152
			else
				v148 = 1
			end
		end
		local v153, v154 = pcall(v139, p135, v140, v141, v142, v148)
		if not v153 then
			v_u_11 = v_u_11 + 1
			if v_u_11 <= 3 then
				warn("[ScopeView] " .. "reticle" .. ": " .. tostring(v154))
			end
		end
		v_u_18 = p135
	end
end
local function v_u_163(p156) -- name: applyAlpha
	-- upvalues: (ref) v_u_21, (copy) v_u_5, (copy) v_u_28, (copy) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (copy) v_u_33
	if p156 ~= v_u_21 then
		local v157 = p156 - v_u_21
		if math.abs(v157) >= 0.004 or (p156 == 0 or p156 == 1) then
			v_u_21 = p156
			local v158 = v_u_5.transparencyOf(p156)
			for _, v159 in v_u_28 do
				v159.BackgroundTransparency = v158
			end
			for _, v160 in v_u_29 do
				v160.Transparency = v158
			end
			if v_u_30 ~= nil then
				v_u_30.Transparency = v_u_31 + (1 - v_u_31) * v158
			end
			if v_u_32 ~= nil then
				v_u_32.ImageTransparency = v158
			end
			local v161 = 0.04 + 0.96 * v158
			for _, v162 in v_u_33 do
				v162.BackgroundTransparency = v161
			end
			return
		end
	end
end
local function v_u_178(p164) -- name: applySway
	-- upvalues: (copy) v_u_3, (ref) v_u_22, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5
	local v165 = v_u_3.CurrentCamera
	if v165 == nil or p164 <= 0 then
		v_u_22 = nil
		return
	else
		local v166 = v165.CFrame
		if v_u_22 == nil or v166 ~= v_u_22 then
			local v167 = v_u_6.Theme
			if v167 == nil then
				local v_u_168 = "Theme"
				local function v169()
					-- upvalues: (ref) v_u_2, (copy) v_u_168
					return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_168))
				end
				local v170
				v170, v167 = pcall(v169)
				if not v170 or type(v167) ~= "table" then
					v167 = false
				end
				v_u_6.Theme = v167
			end
			local v171 = v167 or nil
			local v172
			if v171 == nil then
				v172 = false
			else
				local v173 = v171.reduced
				if type(v173) == "function" then
					local v174 = v171.reduced
					local v175
					v172, v175 = pcall(v174)
					if v172 then
						v172 = v175 == true
					end
				else
					v172 = false
				end
			end
			if v172 then
				v_u_22 = nil
			else
				local v176, v177 = v_u_5.sway(os.clock(), p164)
				v165.CFrame = v166 * CFrame.Angles(math.rad(v177), math.rad(v176), 0)
				v_u_22 = v165.CFrame
			end
		else
			return
		end
	end
end
local function v_u_200() -- name: cameraReady
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	local v179 = v_u_7.FpCam
	if v179 == nil then
		local v_u_180 = "FpCam"
		local v181
		v181, v179 = pcall(function()
			-- upvalues: (copy) v_u_180
			local v182 = script.Parent
			local v183
			if v182 then
				v183 = v182:FindFirstChild(v_u_180)
			else
				v183 = nil
			end
			if v183 and v183:IsA("ModuleScript") then
				return require(v183)
			else
				return nil
			end
		end)
		if not v181 or type(v179) ~= "table" then
			v179 = false
		end
		v_u_7.FpCam = v179
	end
	local v184 = v179 or nil
	if v184 ~= nil then
		local v185 = v184.effectiveSide
		if type(v185) == "function" then
			local v186 = v184.effectiveSide
			local v187, v188 = pcall(v186)
			if not v187 then
				return true
			end
			local v189 = "fp"
			local v190 = 1
			local v191 = 0
			local v192 = v184.side
			local v193
			if type(v192) == "function" then
				local v194 = v184.side
				local v195
				v195, v193 = pcall(v194)
				if not v195 then
					v193 = v189
				end
			else
				v193 = v189
			end
			local v196 = v184.facts
			if type(v196) == "function" then
				local v197 = v184.facts
				local v198, v199 = pcall(v197)
				if v198 and type(v199) == "table" then
					v190 = v199.tpAds or 1
					v191 = v199.toggle or 0
				end
			end
			return v_u_5.cameraReady(v193, v188, v190, v191)
		end
	end
	return true
end
function v_u_4.render(p201) -- name: render
	-- upvalues: (ref) v_u_8, (copy) v_u_7, (ref) v_u_25, (ref) v_u_24, (copy) v_u_5, (ref) v_u_10, (copy) v_u_200, (ref) v_u_9, (ref) v_u_12, (ref) v_u_22, (ref) v_u_23, (ref) v_u_20, (ref) v_u_19, (copy) v_u_56, (ref) v_u_14, (ref) v_u_15, (copy) v_u_6, (copy) v_u_2, (ref) v_u_16, (copy) v_u_45, (ref) v_u_17, (copy) v_u_116, (copy) v_u_111, (ref) v_u_11, (ref) v_u_18, (copy) v_u_155, (copy) v_u_163, (copy) v_u_178
	if v_u_8 then
		local v202 = v_u_7.Viewmodel
		if v202 == nil then
			local v_u_203 = "Viewmodel"
			local v204
			v204, v202 = pcall(function()
				-- upvalues: (copy) v_u_203
				local v205 = script.Parent
				local v206
				if v205 then
					v206 = v205:FindFirstChild(v_u_203)
				else
					v206 = nil
				end
				if v206 and v206:IsA("ModuleScript") then
					return require(v206)
				else
					return nil
				end
			end)
			if not v204 or type(v202) ~= "table" then
				v202 = false
			end
			v_u_7.Viewmodel = v202
		end
		local v207 = v202 or nil
		local v208
		if v207 == nil then
			v208 = nil
		else
			local v209 = v207.adsState
			if type(v209) == "function" then
				local v210 = v207.adsState
				local v211
				v211, v208 = pcall(v210)
				if not v211 or type(v208) ~= "table" then
					v208 = nil
				end
			else
				v208 = nil
			end
		end
		local v212
		if v208 == nil then
			v212 = false
		else
			v212 = v208.overlay == true
		end
		local v213
		if v208 == nil then
			v213 = 0
		else
			local v214 = v208.blend
			v213 = type(v214) ~= "number" and 0 or v208.blend
		end
		local v215
		if v208 == nil then
			v215 = "iron"
		else
			local v216 = v208.sight
			v215 = type(v216) ~= "string" and "iron" or v208.sight
		end
		v_u_25 = v213
		v_u_24 = v215
		local v217 = v_u_5.wants(v212, v213, v_u_10)
		if v217 and not v_u_200() then
			v217 = false
		end
		v_u_10 = v217
		v_u_9 = v_u_5.alphaStep(v_u_9, v217, p201)
		if v_u_9 <= 0 and not v217 then
			if v_u_12 ~= nil and v_u_12.Enabled then
				v_u_12.Enabled = false
			end
			v_u_22 = nil
			v_u_23 = nil
			return
		else
			local v218 = os.clock()
			local v219 = v_u_20 or (v_u_12 == nil and true or v_u_12.Parent == nil)
			if not v219 and v218 - v_u_19 > 0.25 then
				v_u_19 = v218
				local v220, v221 = v_u_56()
				if v220 == v_u_14 and v221 == v_u_15 then
					v219 = true
					local v222 = v_u_6.Theme
					if v222 == nil then
						local v_u_223 = "Theme"
						local function v224()
							-- upvalues: (ref) v_u_2, (copy) v_u_223
							return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_223))
						end
						local v225
						v225, v222 = pcall(v224)
						if not v225 or type(v222) ~= "table" then
							v222 = false
						end
						v_u_6.Theme = v222
					end
					local v226 = v222 or nil
					local v227
					if v226 == nil then
						v227 = 1
					else
						local v228 = v226.uiScale
						if type(v228) == "function" then
							local v229 = v226.uiScale
							local v230, v231 = pcall(v229)
							v227 = (not v230 or (type(v231) ~= "number" or v231 <= 0)) and 1 or v231
						else
							v227 = 1
						end
					end
					if v227 == v_u_16 then
						v219 = v_u_45() ~= v_u_17
					end
				else
					v219 = true
				end
			end
			if v219 and v_u_116() then
				local v232, v233 = v_u_56()
				local v234 = v_u_6.Theme
				if v234 == nil then
					local v_u_235 = "Theme"
					local function v236()
						-- upvalues: (ref) v_u_2, (copy) v_u_235
						return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_235))
					end
					local v237
					v237, v234 = pcall(v236)
					if not v237 or type(v234) ~= "table" then
						v234 = false
					end
					v_u_6.Theme = v234
				end
				local v238 = v234 or nil
				local v239
				if v238 == nil then
					v239 = 1
				else
					local v240 = v238.uiScale
					if type(v240) == "function" then
						local v241 = v238.uiScale
						local v242, v243 = pcall(v241)
						v239 = (not v242 or (type(v243) ~= "number" or v243 <= 0)) and 1 or v243
					else
						v239 = 1
					end
				end
				local v244 = v_u_45()
				v_u_20 = false
				local v245 = v_u_111
				local v246, v247 = pcall(v245, v232, v233, v239, v244)
				if not v246 then
					v_u_11 = v_u_11 + 1
					if v_u_11 <= 3 then
						warn("[ScopeView] " .. "build" .. ": " .. tostring(v247))
					end
				end
				v_u_18 = ""
			end
			if v_u_12 ~= nil then
				local v248 = v_u_6.Sights
				if v248 == nil then
					local v_u_249 = "Sights"
					local function v250()
						-- upvalues: (ref) v_u_2, (copy) v_u_249
						return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_249))
					end
					local v251
					v251, v248 = pcall(v250)
					if not v251 or type(v248) ~= "table" then
						v248 = false
					end
					v_u_6.Sights = v248
				end
				local v252 = v248 or nil
				local v253
				if v252 == nil then
					v253 = nil
				else
					v253 = v252.get(v215)
				end
				v_u_155(v253 == nil and "none" or v253.reticle)
				v_u_163(v_u_9)
				if not v_u_12.Enabled then
					v_u_12.Enabled = true
				end
				local v254 = v_u_7.FpCam
				if v254 == nil then
					local v_u_255 = "FpCam"
					local v256
					v256, v254 = pcall(function()
						-- upvalues: (copy) v_u_255
						local v257 = script.Parent
						local v258
						if v257 then
							v258 = v257:FindFirstChild(v_u_255)
						else
							v258 = nil
						end
						if v258 and v258:IsA("ModuleScript") then
							return require(v258)
						else
							return nil
						end
					end)
					if not v256 or type(v254) ~= "table" then
						v254 = false
					end
					v_u_7.FpCam = v254
				end
				local v259 = v254 or nil
				if v259 ~= nil then
					local v260 = v259.setAds
					if type(v260) == "function" and v252 ~= nil then
						if v217 then
							local v261 = v259.baseFov
							local v262
							if type(v261) == "function" then
								v262 = v259.baseFov()
							else
								v262 = nil
							end
							local v263
							if type(v262) == "number" then
								v263 = v252.fov(v262, v215)
							else
								v263 = nil
							end
							v_u_23 = v263
						end
						if v_u_23 ~= nil then
							v259.setAds(v_u_5.blendOut(v213, v_u_9), v_u_23)
						end
					end
				end
				v_u_178(v_u_9)
			end
		end
	else
		return
	end
end
local function v_u_266() -- name: disconnectAll
	-- upvalues: (copy) v_u_26, (copy) v_u_27
	for _, v264 in v_u_26 do
		pcall(v264)
	end
	table.clear(v_u_26)
	for _, v_u_265 in v_u_27 do
		pcall(function()
			-- upvalues: (copy) v_u_265
			v_u_265:Disconnect()
		end)
	end
	table.clear(v_u_27)
end
local function v_u_267() -- name: destroyGui
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) v_u_28, (copy) v_u_29, (copy) v_u_33, (ref) v_u_30, (ref) v_u_32, (ref) v_u_34, (ref) v_u_14, (ref) v_u_15, (ref) v_u_18, (ref) v_u_21
	if v_u_12 ~= nil then
		v_u_12:Destroy()
	end
	v_u_12 = nil
	v_u_13 = nil
	table.clear(v_u_28)
	table.clear(v_u_29)
	table.clear(v_u_33)
	v_u_30 = nil
	v_u_32 = nil
	v_u_34 = nil
	v_u_14 = 0
	v_u_15 = 0
	v_u_18 = ""
	v_u_21 = -1
end
function v_u_4.facts() -- name: facts
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_24, (ref) v_u_25, (ref) v_u_12, (ref) v_u_14, (ref) v_u_15, (copy) v_u_28, (ref) v_u_18, (copy) v_u_33, (ref) v_u_17, (ref) v_u_11
	local v268 = {
		["active"] = v_u_8,
		["alpha"] = v_u_9,
		["on"] = v_u_10,
		["sight"] = v_u_24,
		["blend"] = v_u_25
	}
	local v269
	if v_u_12 == nil then
		v269 = false
	else
		v269 = v_u_12.Parent ~= nil
	end
	v268.gui = v269
	local v270
	if v_u_12 == nil then
		v270 = false
	else
		v270 = v_u_12.Enabled
	end
	v268.enabled = v270
	v268.w = v_u_14
	v268.h = v_u_15
	v268.bars = #v_u_28
	v268.reticle = v_u_18
	v268.reticleParts = #v_u_33
	v268.image = v_u_17
	v268.errors = v_u_11
	return v268
end
function v_u_4.setActive(p271, p272) -- name: setActive
	-- upvalues: (ref) v_u_8, (copy) v_u_266, (ref) v_u_9, (ref) v_u_10, (ref) v_u_22, (ref) v_u_23, (copy) v_u_267, (ref) v_u_35, (ref) v_u_20, (copy) v_u_6, (copy) v_u_2, (copy) v_u_27, (copy) v_u_26, (copy) v_u_4, (copy) v_u_134, (ref) v_u_11
	local v273 = p271 == true
	if v273 == v_u_8 then
		return
	else
		v_u_8 = v273
		v_u_266()
		v_u_9 = 0
		v_u_10 = false
		v_u_22 = nil
		v_u_23 = nil
		if v273 then
			v_u_35 = p272 or v_u_35
			v_u_20 = true
			local v274 = v_u_6.Theme
			if v274 == nil then
				local v_u_275 = "Theme"
				local function v276()
					-- upvalues: (ref) v_u_2, (copy) v_u_275
					return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_275))
				end
				local v277
				v277, v274 = pcall(v276)
				if not v277 or type(v274) ~= "table" then
					v274 = false
				end
				v_u_6.Theme = v274
			end
			local v278 = v274 or nil
			if v278 ~= nil then
				for _, v_u_279 in { v278.scaleChanged, v278.devViewportChanged } do
					if v_u_279 == nil then
						continue
					end
					local v280 = v_u_279.Connect
					if type(v280) ~= "function" then
						continue
					end
					local function v281()
						-- upvalues: (copy) v_u_279, (ref) v_u_20
						return v_u_279:Connect(function()
							-- upvalues: (ref) v_u_20
							v_u_20 = true
						end)
					end
					local v282, v283 = pcall(v281)
					if not v282 then
						continue
					end
					local v284 = v_u_27
					table.insert(v284, v283)
				end
			end
			local v285 = v_u_35
			if v285 ~= nil then
				local v286 = v285.on
				if type(v286) == "function" then
					local v287 = v285.on
					local function v288()
						-- upvalues: (ref) v_u_20
						v_u_20 = true
					end
					local v289, v290 = pcall(v287, "ui.rebuild", v288)
					if v289 and type(v290) == "function" then
						local v291 = v_u_26
						table.insert(v291, v290)
					end
					local v292 = v285.command
					if type(v292) == "function" then
						local v293 = v285.command
						local function v297()
							-- upvalues: (ref) v_u_4
							local function v294()
								-- upvalues: (ref) v_u_4
								return game:GetService("HttpService"):JSONEncode(v_u_4.facts())
							end
							local v295, v296 = pcall(v294)
							return not v295 and "scope.state failed" or v296
						end
						pcall(v293, "scope.state", v297)
					end
				end
			end
			local v298 = v_u_134
			local v299, v300 = pcall(v298, true)
			if not v299 then
				v_u_11 = v_u_11 + 1
				if v_u_11 <= 3 then
					warn("[ScopeView] " .. "setActive" .. ": " .. tostring(v300))
				end
			end
		else
			v_u_267()
		end
	end
end
function v_u_4.isScoped() -- name: isScoped
	-- upvalues: (ref) v_u_8, (ref) v_u_9
	local v301 = v_u_8
	if v301 then
		v301 = v_u_9 >= 0.5
	end
	return v301
end
function v_u_4.isActive() -- name: isActive
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v_u_4.alpha() -- name: alpha
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_4.errors() -- name: errors
	-- upvalues: (ref) v_u_11
	return v_u_11
end
return v_u_4