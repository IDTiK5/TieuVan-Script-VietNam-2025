-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / CrateStage

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("ContentProvider")
local v_u_6 = game:GetService("ReplicatedStorage")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = game:GetService("GuiService")
local v_u_9 = {}
local v_u_10 = math.max
local v_u_11 = math.min
local v_u_12 = math.floor
local _ = math.abs
local v_u_13 = math.sin
local _ = math.cos
local v_u_14 = math.rad
local v_u_15 = v1.LocalPlayer
local v_u_16 = v_u_6:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_17 = require(v_u_16:WaitForChild("CrateTimeline"))
local v_u_18 = require(v_u_16:WaitForChild("Skins"))
local v_u_19 = require(v_u_16:WaitForChild("SkinRules"))
local v_u_20 = require(v_u_16:WaitForChild("CaseOdds"))
local v_u_21 = require(v_u_16:WaitForChild("Sounds"))
local v_u_22 = require(v_u_16:WaitForChild("Theme"))
local v23, v24 = pcall(function()
	-- upvalues: (copy) v_u_16
	return require(v_u_16:WaitForChild("Config"))
end)
local v_u_25 = not v23 and {} or v24
local v_u_26 = require(script.Parent:WaitForChild("CrateStageFx"))
local v_u_27 = require(script.Parent:WaitForChild("StageLight"))
local v_u_28 = require(script.Parent:WaitForChild("CrateStageUi"))
local v_u_29 = nil
local function v31()
	-- upvalues: (ref) v_u_29
	local v30 = script.Parent:FindFirstChild("CrateStageTally")
	if v30 then
		v_u_29 = require(v30)
	end
end
pcall(v31)
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = 0
local v_u_35 = {
	["speed"] = 1,
	["hold"] = nil,
	["loop"] = nil,
	["phone"] = nil,
	["skipAt"] = nil,
	["quality"] = nil,
	["reduced"] = nil,
	["dump"] = nil,
	["shot"] = nil,
	["reelDelay"] = nil,
	["texDelay"] = nil
}
v_u_9.dbg = v_u_35
local v_u_36 = {
	["folder"] = nil,
	["voices"] = nil,
	["preloaded"] = false,
	["loading"] = false,
	["token"] = nil,
	["voices"] = {},
	["token"] = {}
}
local v_u_37 = {
	["crate_latch"] = 2,
	["crate_pulse"] = 2,
	["crate_tick"] = 4,
	["crate_keyturn"] = 2,
	["crate_reveal_chime"] = 4,
	["crate_glitter"] = 2
}
local function v_u_47() -- name: ensureAudio
	-- upvalues: (copy) v_u_36, (copy) v_u_4, (copy) v_u_21, (copy) v_u_37
	if not (v_u_36.folder and v_u_36.folder.Parent) then
		local v38 = Instance.new("Folder")
		v38.Name = "CrateStageAudio"
		v38.Parent = v_u_4
		v_u_36.folder = v38
		table.clear(v_u_36.voices)
		for v39, v40 in v_u_21.defs do
			if string.sub(v39, 1, 6) ~= "crate_" or not (v40.v and v40.v[1]) then
				continue
			end
			local v41 = {}
			for v42 = 1, v_u_37[v39] or 1 do
				local v43 = Instance.new("Sound")
				v43.Name = v39 .. v42
				v43.Volume = 0
				local v44 = v40.v[1].id
				v43.SoundId = "rbxassetid://" .. tostring(v44)
				v43.RollOffMode = Enum.RollOffMode.InverseTapered
				local v45 = v40.group or "SFX"
				local v46 = v_u_4:FindFirstChild("HushMaster")
				if v46 then
					v46 = v46:FindFirstChild(v45)
				end
				if not (v46 and v46:IsA("SoundGroup")) then
					v46 = nil
				end
				v43.SoundGroup = v46
				v43.Parent = v38
				v41[v42] = v43
			end
			v_u_36.voices[v39] = {
				["sounds"] = nil,
				["idx"] = 0,
				["def"] = nil,
				["sounds"] = v41,
				["def"] = v40
			}
		end
	end
end
local v_u_48 = false
function v_u_9.preload() -- name: preload
	-- upvalues: (ref) v_u_48, (copy) v_u_6, (copy) v_u_5, (copy) v_u_36, (copy) v_u_47
	if not v_u_48 then
		v_u_48 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_6, (ref) v_u_5
			local v49 = v_u_6:FindFirstChild("HushAssets")
			if v49 then
				v49 = v49:FindFirstChild("CrateKit")
			end
			if v49 ~= nil then
				local v50 = {}
				for _, v51 in v49:GetDescendants() do
					if not (v51:IsA("MeshPart") or (v51:IsA("SurfaceAppearance") or (v51:IsA("Texture") or v51:IsA("Decal")))) then
						continue
					end
					table.insert(v50, v51)
				end
				local v52 = 1
				while v52 <= #v50 do
					local v53 = table.move
					local v54 = v52 + 7
					local v55 = #v50
					local v_u_56 = v53(v50, v52, math.min(v54, v55), 1, {})
					local function v57()
						-- upvalues: (ref) v_u_5, (copy) v_u_56
						v_u_5:PreloadAsync(v_u_56)
					end
					pcall(v57)
					v52 = v52 + 8
					task.wait()
				end
			end
		end)
	end
	if not (v_u_36.loading or v_u_36.preloaded) then
		v_u_36.loading = true
		v_u_47()
		task.spawn(function()
			-- upvalues: (ref) v_u_36, (ref) v_u_5
			local v_u_58 = {}
			for _, v59 in v_u_36.voices do
				for _, v60 in v59.sounds do
					table.insert(v_u_58, v60)
				end
			end
			local function v61()
				-- upvalues: (ref) v_u_5, (copy) v_u_58
				v_u_5:PreloadAsync(v_u_58)
			end
			pcall(v61)
			v_u_36.preloaded = true
			v_u_36.loading = false
		end)
	end
end
function v_u_9.soundReport() -- name: soundReport
	-- upvalues: (copy) v_u_47, (copy) v_u_36
	v_u_47()
	local v62 = 0
	local v63 = {}
	for v64, v65 in v_u_36.voices do
		local v66 = v65.sounds[1]
		local v67 = string.match(v66.SoundId, "%d+") or "?"
		local v68 = v66.IsLoaded
		local v69 = ("%s id=%s loaded=%s len=%.2f"):format(v64, v67, tostring(v68), v66.TimeLength)
		if not v66.IsLoaded or v66.TimeLength <= 0 then
			v62 = v62 + 1
		end
		table.insert(v63, v69)
	end
	table.sort(v63)
	return ("sounds %d bad %d\n%s"):format(#v63, v62, table.concat(v63, "\n"))
end
local function v_u_92(p70, p71, p72, p73) -- name: playCue
	-- upvalues: (copy) v_u_36, (copy) v_u_21, (copy) v_u_10
	local v74 = v_u_36.voices[p70]
	if not v74 then
		return nil
	end
	local v75 = v_u_21.defs[p70] or v74.def
	local v76 = v75.v
	if v76 then
		v76 = v75.v[1]
	end
	if not v76 then
		return nil
	end
	v74.idx = v74.idx % #v74.sounds + 1
	local v_u_77 = v74.sounds[v74.idx]
	local v78 = v76.id
	local v79 = "rbxassetid://" .. tostring(v78)
	if v_u_77.SoundId ~= v79 then
		v_u_77.SoundId = v79
	end
	if not v_u_77.IsLoaded then
		return nil
	end
	local v80 = (v76.p or 1) * (p72 or 1)
	v_u_77.PlaybackSpeed = v80
	local v81 = 10
	local v82 = (v75.gain or 0.5) * (v76.g or 1)
	local v83 = v76.id
	local v84 = v_u_21.loudness
	if v84 then
		v84 = v_u_21.loudness[v83]
	end
	local v85
	if v84 and v84 > 0 then
		local v86 = (v_u_21.REF_LOUDNESS or 300) / v84
		v85 = math.clamp(v86, 0.25, 6)
	else
		v85 = 1
	end
	local v87 = v82 * v85 * (p71 or 1)
	v_u_77.Volume = math.min(v81, v87)
	v_u_77.TimePosition = v76.t0 or 0
	v_u_77:Play()
	local v88 = p73 or v76.len
	if not v88 then
		v_u_36.token[v_u_77] = (v_u_36.token[v_u_77] or 0) + 1
		return v_u_77
	end
	local v_u_89 = (v_u_36.token[v_u_77] or 0) + 1
	v_u_36.token[v_u_77] = v_u_89
	task.delay(v_u_10(0.05, v88 / v_u_10(0.1, v80) - 0.05), function()
		-- upvalues: (ref) v_u_36, (copy) v_u_77, (copy) v_u_89
		if v_u_36.token[v_u_77] == v_u_89 then
			local function v90()
				-- upvalues: (ref) v_u_77
				v_u_77.Volume = v_u_77.Volume * 0.35
			end
			pcall(v90)
			task.delay(0.05, function()
				-- upvalues: (ref) v_u_36, (ref) v_u_77, (ref) v_u_89
				if v_u_36.token[v_u_77] == v_u_89 then
					local v_u_91 = v_u_77
					pcall(function()
						-- upvalues: (copy) v_u_91
						v_u_91:Stop()
						v_u_91.Volume = 0
					end)
				end
			end)
		end
	end)
	return v_u_77
end
local function v_u_95() -- name: stopAllAudio
	-- upvalues: (copy) v_u_36
	if v_u_36.folder then
		for _, v93 in v_u_36.voices do
			for _, v_u_94 in v93.sounds do
				v_u_36.token[v_u_94] = (v_u_36.token[v_u_94] or 0) + 1
				pcall(function()
					-- upvalues: (copy) v_u_94
					v_u_94:Stop()
					v_u_94.Volume = 0
				end)
			end
		end
	end
end
local function v_u_97() -- name: destroyAudio
	-- upvalues: (copy) v_u_95, (copy) v_u_36
	v_u_95()
	if v_u_36.folder then
		local function v96()
			-- upvalues: (ref) v_u_36
			v_u_36.folder:Destroy()
		end
		pcall(v96)
	end
	v_u_36.folder = nil
	table.clear(v_u_36.voices)
	v_u_36.preloaded = false
	v_u_36.loading = false
end
local v_u_98 = {
	"TextLabel",
	"TextButton",
	"TextBox",
	"ImageLabel",
	"ImageButton",
	"SurfaceAppearance",
	"MeshPart",
	"Decal",
	"Texture",
	"Sound",
	"ViewportFrame"
}
local function v_u_103(p99) -- name: contentOf
	-- upvalues: (copy) v_u_98
	local v100 = {}
	if p99 then
		for _, v101 in p99:GetDescendants() do
			for _, v102 in v_u_98 do
				if not v101:IsA(v102) then
					continue
				end
				table.insert(v100, v101)
			end
		end
	end
	return v100
end
v_u_9._contentOf = v_u_103
local function v_u_111(p104) -- name: pickQuality
	-- upvalues: (copy) v_u_22
	if p104 == "high" or p104 == "low" then
		return p104
	end
	local v_u_105 = false
	local function v106()
		-- upvalues: (ref) v_u_22, (ref) v_u_105
		if v_u_22.isPhone() then
			v_u_105 = true
		end
	end
	pcall(v106)
	local function v108()
		-- upvalues: (ref) v_u_105
		local v107 = settings().Rendering.QualityLevel.Value
		if v107 >= 1 and v107 <= 5 then
			v_u_105 = true
		end
	end
	pcall(v108)
	local function v110()
		-- upvalues: (ref) v_u_105
		local v109 = UserSettings():GetService("UserGameSettings").SavedQualityLevel.Value
		if v109 >= 1 and v109 <= 4 then
			v_u_105 = true
		end
	end
	pcall(v110)
	return v_u_105 and "low" or "high"
end
local function v_u_117(p112) -- name: baseEvents
	-- upvalues: (copy) v_u_17
	local v113 = {}
	for v114, v115 in v_u_17.latchTimes(p112) do
		table.insert(v113, {
			["u"] = nil,
			["kind"] = "latch",
			["a"] = nil,
			["u"] = v115,
			["a"] = v114
		})
	end
	local v116 = {
		["u"] = nil,
		["kind"] = "burst",
		["u"] = v_u_17.PHASES[p112 and "quick" or "normal"][1][4].t0
	}
	table.insert(v113, v116)
	return v113
end
local function v_u_140(p118, p119, p120) -- name: tierEvents
	-- upvalues: (copy) v_u_17, (copy) v_u_26, (copy) v_u_12
	local v121 = v_u_17.PHASES[p119 and "quick" or "normal"][p118]
	local v122 = v_u_17.TIERS[p118]
	local v123 = v121[7].t0 + v122.silence
	local v124 = p119 and 0.55 or 1
	local v125 = {}
	for v126 = 1, v122.rings do
		local v127 = {
			["u"] = nil,
			["kind"] = "ring",
			["a"] = nil,
			["color"] = nil,
			["u"] = v123 + (v126 - 1) * 0.28 * v124,
			["a"] = v126,
			["color"] = p120
		}
		table.insert(v125, v127)
	end
	if p118 >= 6 then
		for v128 = 1, 3 do
			local v129
			if p118 == 7 and v128 % 2 == 0 then
				v129 = v_u_26.SIG_B
			else
				v129 = p120
			end
			local v130 = {
				["u"] = nil,
				["kind"] = "confetti",
				["a"] = nil,
				["color"] = nil,
				["extra"] = nil,
				["u"] = v123 + (v128 - 1) * 0.4 * v124,
				["a"] = v_u_12(v122.confetti / 3),
				["color"] = v129,
				["extra"] = v128 >= 2
			}
			table.insert(v125, v130)
		end
		if p118 == 7 then
			local v131 = {
				["u"] = nil,
				["kind"] = "confetti",
				["a"] = nil,
				["color"] = nil,
				["extra"] = true,
				["u"] = v123 + v124 * 1.2,
				["a"] = v_u_12(v122.confetti / 3),
				["color"] = v_u_26.SIG_B
			}
			table.insert(v125, v131)
			local v132 = {
				["u"] = nil,
				["kind"] = "confetti",
				["a"] = nil,
				["color"] = nil,
				["extra"] = true,
				["u"] = v123 + v124 * 1.8,
				["a"] = v_u_12(v122.confetti / 4),
				["color"] = p120
			}
			table.insert(v125, v132)
		end
	else
		local v133 = {
			["u"] = nil,
			["kind"] = "confetti",
			["a"] = nil,
			["color"] = nil,
			["u"] = v123,
			["a"] = v122.confetti,
			["color"] = p120
		}
		table.insert(v125, v133)
	end
	local v134 = v121[9].t0
	if p118 >= 4 then
		local v135 = {
			["u"] = nil,
			["kind"] = "confetti",
			["a"] = nil,
			["color"] = nil,
			["u"] = v134,
			["a"] = v_u_12(v122.confetti * 0.4),
			["color"] = p120
		}
		table.insert(v125, v135)
	end
	if p118 >= 5 then
		table.insert(v125, {
			["u"] = nil,
			["kind"] = "ring",
			["a"] = 2,
			["color"] = nil,
			["u"] = v134,
			["color"] = p120
		})
	end
	if p118 >= 3 then
		local v136 = {
			["u"] = nil,
			["kind"] = "glitter",
			["u"] = v134 + 0.1
		}
		table.insert(v125, v136)
	end
	if p118 >= 6 then
		local v137 = {
			["u"] = nil,
			["kind"] = "ring",
			["a"] = 3,
			["color"] = nil,
			["u"] = v134 + v124 * 2.3
		}
		if p118 == 7 then
			p120 = v_u_26.SIG_B
		end
		v137.color = p120
		table.insert(v125, v137)
	end
	table.sort(v125, function(p138, p139)
		return p138.u < p139.u
	end)
	return v125
end
local v_u_141 = {}
v_u_141.__index = v_u_141
function v_u_9.begin(p142, p143) -- name: begin
	-- upvalues: (ref) v_u_33, (copy) v_u_141, (copy) v_u_20, (copy) v_u_111, (copy) v_u_35, (copy) v_u_15, (ref) v_u_34
	local v144 = p143 or {}
	if v_u_33 and v_u_33:isPlaying() then
		return v_u_33
	end
	local v145 = v_u_141
	local v146 = setmetatable({}, v145)
	v146.opts = v144
	v146.crateId = type(p142) ~= "string" and "skin_crate_field" or p142
	v146.look = v_u_20.get(v146.crateId) and (string.gsub(v146.crateId, "^skin_crate_", "") or "field") or "field"
	v146.quality = v_u_111(v_u_35.quality or v144.quality)
	v146.reduced = v144.reduced == true and true or v_u_35.reduced == true
	local v147 = v144.cameraShake
	if v147 == nil then
		local v_u_148 = "CameraShake"
		local function v149()
			-- upvalues: (ref) v_u_15, (copy) v_u_148
			return v_u_15:GetAttribute(v_u_148)
		end
		local v150
		v150, v147 = pcall(v149)
		if not v150 or v147 == nil then
			v147 = nil
		end
	end
	v146.shakeAmt = type(v147) ~= "number" and 1 or math.clamp(v147, 0, 1)
	if v146.shakeAmt < 0.25 then
		v146.reduced = true
	end
	if v144.quick == nil then
		local v151
		if v_u_34 > 0 and os.clock() - v_u_34 < 60 then
			v151 = true
		else
			local v_u_152 = "CrateQuick"
			local function v153()
				-- upvalues: (ref) v_u_15, (copy) v_u_152
				return v_u_15:GetAttribute(v_u_152)
			end
			local v154, v155 = pcall(v153)
			if not v154 or v155 == nil then
				v155 = false
			end
			v151 = v155 == true
		end
		v146.quick = v151
	else
		v146.quick = v144.quick == true
	end
	v146.done = false
	v146.doneCallbacks = {}
	v146.opened = 0
	v146.t0 = os.clock()
	v146.beginAt = v146.t0
	v146.cleanup = {}
	v146.errors = 0
	v146.frames = 0
	v146.frameSum = 0
	v146.frameMax = 0
	v146.state_ = "key"
	v146:_newRun(v146.crateId, v146.quick)
	v146:_enter()
	v_u_33 = v146
	return v146
end
function v_u_141._snapshot(_) -- name: _snapshot
	-- upvalues: (copy) v_u_27, (copy) v_u_7, (copy) v_u_4, (copy) v_u_15
	local v156 = v_u_27.capture()
	local v157 = v_u_7.CurrentCamera
	if v157 then
		v156["Cam.Type"] = v157.CameraType
		v156["Cam.CFrame"] = v157.CFrame
		v156["Cam.FOV"] = v157.FieldOfView
		v156["Cam.Subject"] = v157.CameraSubject
		v156["Cam.Focus"] = v157.Focus
	end
	local v158 = v_u_4:FindFirstChild("HushMaster")
	if v158 then
		v158 = v158:FindFirstChild("Music")
	end
	v156["Music.Volume"] = not (v158 and v158:IsA("SoundGroup")) and -1 or v158.Volume
	local function v160()
		-- upvalues: (ref) v_u_15
		local v159 = v_u_15
		if v159 then
			v159 = v_u_15:FindFirstChild("PlayerGui")
		end
		if v159 then
			v159 = v159:FindFirstChild("HushMenu")
		end
		return not v159 and "none" or v159.Enabled
	end
	local v161, v162 = pcall(v160)
	v156["Menu.Enabled"] = not v161 and "?" or v162
	return v156
end
function v_u_141._enter(p_u_163) -- name: _enter
	-- upvalues: (copy) v_u_47, (copy) v_u_9, (copy) v_u_7, (copy) v_u_15, (ref) v_u_34
	v_u_47()
	v_u_9.preload()
	p_u_163.before = p_u_163:_snapshot()
	local v164 = v_u_7.CurrentCamera
	p_u_163.camSave = v164 and {
		["cam"] = v164,
		["type"] = v164.CameraType,
		["cf"] = v164.CFrame,
		["fov"] = v164.FieldOfView,
		["subject"] = v164.CameraSubject,
		["focus"] = v164.Focus
	} or nil
	p_u_163.cam = v_u_7.CurrentCamera
	task.spawn(function()
		-- upvalues: (copy) p_u_163
		while not p_u_163.done do
			task.wait(2)
			if p_u_163.done or os.clock() - (p_u_163.lastTick or os.clock()) <= 4 then
				continue
			end
			warn("[CrateStage] the frame loop stalled: ending the stage")
			p_u_163:_finish("stalled")
		end
	end)
	local v165 = p_u_163._enterStage
	local v166, v_u_167 = pcall(v165, p_u_163)
	if not v166 then
		warn("[CrateStage] the stage could not start:", v_u_167)
		local function v171()
			-- upvalues: (ref) v_u_15, (copy) v_u_167
			local v168 = v_u_15
			local v169 = v_u_167
			local v170 = tostring(v169)
			v168:SetAttribute("ClientError", "CrateStage enter: " .. string.sub(v170, 1, 160))
		end
		pcall(v171)
		local v172 = v_u_34
		p_u_163.doneCallbacks = {}
		p_u_163.opts = table.clone(p_u_163.opts)
		p_u_163.opts.onDone = nil
		p_u_163:_finish("enter_error")
		v_u_34 = v172
		error(v_u_167, 0)
	end
end
function v_u_141._enterStage(p_u_173) -- name: _enterStage
	-- upvalues: (copy) v_u_15, (copy) v_u_27, (copy) v_u_26, (ref) v_u_25, (copy) v_u_7, (copy) v_u_28, (ref) v_u_32, (copy) v_u_35, (copy) v_u_22, (copy) v_u_5, (copy) v_u_103, (copy) v_u_4, (copy) v_u_3, (copy) v_u_12, (copy) v_u_2
	local function v174()
		-- upvalues: (ref) v_u_15
		v_u_15:SetAttribute("CrateStageOn", true)
	end
	pcall(v174)
	p_u_173.light = v_u_27.new(p_u_173.quality)
	p_u_173.light:enter()
	local function v178()
		-- upvalues: (ref) v_u_15, (copy) p_u_173
		local v175 = v_u_15:FindFirstChild("PlayerGui")
		for _, v176 in { "HushMenu" } do
			local v177
			if v175 then
				v177 = v175:FindFirstChild(v176)
			else
				v177 = v175
			end
			if not v177 then
				continue
			end
			p_u_173.light:hideGui(v177)
		end
	end
	pcall(v178)
	local v179 = os.clock()
	local v180 = v_u_26.build
	local v181 = v_u_25.CRATE_STAGE_ORIGIN
	p_u_173.world = v180(typeof(v181) ~= "Vector3" and Vector3.new(-9000, 0, 0) or v181, p_u_173.look, p_u_173.quality, {})
	local v182 = p_u_173.world
	local v183 = v_u_7:FindFirstChild("HushLocal")
	if not v183 then
		v183 = Instance.new("Folder")
		v183.Name = "HushLocal"
		v183.Parent = v_u_7
	end
	v182:parent(v183)
	p_u_173.buildMs = (os.clock() - v179) * 1000
	local v184 = v_u_25.CRATE_STAGE_ORIGIN
	p_u_173.centre = (typeof(v184) ~= "Vector3" and Vector3.new(-9000, 0, 0) or v184) + Vector3.new(0, 1.6, 0)
	p_u_173.run.keyTarget = p_u_173.world:keyTarget()
	local v185 = v_u_28.new
	local v186 = {
		["cctx"] = v_u_32
	}
	local v187
	if v_u_35.phone == true then
		v187 = true
	elseif p_u_173.quality == "low" then
		local v188 = v_u_22.isPhone
		if pcall(v188) then
			v187 = v_u_22.isPhone() or false
		else
			v187 = false
		end
	else
		v187 = false
	end
	v186.phone = v187
	v186.reduced = p_u_173.reduced
	function v186.onSkip(p189) -- name: onSkip
		-- upvalues: (copy) p_u_173
		p_u_173:skip(p189)
	end
	function v186.onDrag(p190) -- name: onDrag
		-- upvalues: (copy) p_u_173
		local v191 = p_u_173.run
		if v191 and (v191.buttonsShown and not p_u_173.done) then
			v191.dragDelta = (v191.dragDelta or 0) + p190 * 0.45
		end
	end
	function v186.onEquip() -- name: onEquip
		-- upvalues: (copy) p_u_173
		p_u_173:_equip()
	end
	function v186.onNext() -- name: onNext
		-- upvalues: (copy) p_u_173
		p_u_173:_next()
	end
	function v186.onDone() -- name: onDone
		-- upvalues: (copy) p_u_173
		p_u_173:stop("done")
	end
	local v192, v_u_193 = pcall(v185, v186)
	if v192 then
		p_u_173.ui = v_u_193
		v_u_193:setFade(1)
		v_u_193:setLetterbox(0)
		task.spawn(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_103, (copy) v_u_193
			local function v194()
				-- upvalues: (ref) v_u_5, (ref) v_u_103, (ref) v_u_193
				v_u_5:PreloadAsync((v_u_103(v_u_193.gui)))
			end
			pcall(v194)
		end)
	else
		warn("[CrateStage] ui failed:", v_u_193)
	end
	local v195 = v_u_4:FindFirstChild("HushMaster")
	if v195 then
		v195 = v195:FindFirstChild("Music")
	end
	if not (v195 and v195:IsA("SoundGroup")) then
		v195 = nil
	end
	p_u_173.musicGroup = v195
	if p_u_173.musicGroup then
		p_u_173.musicBase = p_u_173.musicGroup.Volume
	end
	p_u_173.conns = {}
	local v196 = p_u_173.conns
	local v197 = v_u_3.InputBegan
	table.insert(v196, v197:Connect(function(p198, p199)
		-- upvalues: (copy) p_u_173
		p_u_173:_input(p198, p199)
	end))
	local v200 = v_u_12(os.clock() * 1000) % 100000
	p_u_173.renderName = "CrateStageCam" .. tostring(v200)
	p_u_173.lastRender = 0
	local function v202()
		-- upvalues: (ref) v_u_2, (copy) p_u_173
		v_u_2:BindToRenderStep(p_u_173.renderName, Enum.RenderPriority.Last.Value + 10, function(p201)
			-- upvalues: (ref) p_u_173
			p_u_173.lastRender = os.clock()
			p_u_173:_tick(p201)
		end)
	end
	p_u_173.renderBound = pcall(v202)
	local v203 = p_u_173.conns
	local v204 = v_u_2.Heartbeat
	table.insert(v203, v204:Connect(function(p205)
		-- upvalues: (copy) p_u_173
		if os.clock() - p_u_173.lastRender > 0.12 then
			p_u_173:_tick(p205)
		end
	end))
	p_u_173:_tick(0)
end
function v_u_141._newRun(p206, p207, p208) -- name: _newRun
	-- upvalues: (copy) v_u_17, (copy) v_u_117
	local v209 = {
		["crateId"] = nil,
		["quick"] = nil,
		["t0"] = nil,
		["clock"] = nil,
		["rarity"] = 1,
		["result"] = nil,
		["failed"] = nil,
		["stall"] = 0,
		["stallStart"] = nil,
		["events"] = nil,
		["eventIdx"] = 1,
		["cues"] = nil,
		["cueIdx"] = 1,
		["lastU"] = nil,
		["pending"] = nil,
		["skinUsed"] = false,
		["spin"] = 0,
		["drag"] = 0,
		["buttonsShown"] = false,
		["equipped"] = false,
		["crateId"] = p207,
		["quick"] = p208,
		["t0"] = os.clock(),
		["clock"] = v_u_17.newClock(1, p208),
		["events"] = v_u_117(p208),
		["cues"] = {}
	}
	local v210 = v_u_17.PHASES[p208 and "quick" or "normal"][1][7].t0
	for _, v211 in v_u_17.cues(1, p208) do
		if v211.u >= v210 then
			continue
		end
		local v212 = v209.cues
		table.insert(v212, v211)
	end
	v209.colorU = v210
	local v213
	if p206.run then
		v213 = p206.run.keyTarget or nil
	else
		v213 = nil
	end
	v209.keyTarget = v213
	p206.run = v209
	p206.state_ = "key"
	return v209
end
function v_u_141.resolve(p_u_214, p_u_215) -- name: resolve
	-- upvalues: (copy) v_u_18, (copy) v_u_12, (copy) v_u_26, (copy) v_u_17, (copy) v_u_35, (copy) v_u_140, (copy) v_u_16, (copy) v_u_103, (copy) v_u_5
	local v_u_216 = p_u_214.run
	if p_u_214.done or (not v_u_216 or v_u_216.result) then
		return false
	end
	if type(p_u_215) ~= "table" then
		return p_u_214:fail("Not available right now.")
	end
	local v217 = v_u_18.get(p_u_215.skin)
	local v_u_218 = v217
	local v219
	if v217 then
		v219 = v217.rarity
	else
		v219 = nil
	end
	local v220 = p_u_215.rarity
	local v221 = v_u_12(tonumber(v220) or (v219 or 1))
	local v_u_222 = math.clamp(v221, 1, 7)
	v_u_216.result = p_u_215
	v_u_216.rarity = v_u_222
	v_u_216.skin = v_u_218
	v_u_216.clock.rarity = v_u_222
	v_u_216.color = v_u_26.GLOW[v_u_222]
	local v223 = p_u_215.seed
	local v224 = tonumber(v223) or v_u_12(os.clock() * 1000) % 2147483646 + 1
	v_u_216.strip = v_u_17.strip(v224, v_u_216.crateId, p_u_215.skin, p_u_214.quality == "low" and (p_u_214.ui and p_u_214.ui.phone) and "phone" or "high", v_u_216.quick)
	if p_u_214.reduced and not v_u_216.quick then
		v_u_216.strip.T = v_u_17.STRIP.Treduced
	end
	if p_u_214.ui then
		local v225 = p_u_214.ui.buildStrip
		local v226 = p_u_214.ui
		local v227 = v_u_216.strip
		local v228 = v_u_216.crateId
		local v229 = v_u_35.reelBuildPerFrame or 4
		pcall(v225, v226, v227, v228, v229)
	end
	p_u_214:_preloadReel(v_u_216)
	local v230 = v_u_216.colorU
	for v231 = #v_u_216.events, 1, -1 do
		if v230 > v_u_216.events[v231].u then
			continue
		end
		table.remove(v_u_216.events, v231)
	end
	for _, v232 in v_u_140(v_u_222, v_u_216.quick, v_u_216.color) do
		local v233 = v_u_216.events
		table.insert(v233, v232)
	end
	table.sort(v_u_216.events, function(p234, p235)
		return p234.u < p235.u
	end)
	for v236 = #v_u_216.cues, 1, -1 do
		if v230 > v_u_216.cues[v236].u then
			continue
		end
		table.remove(v_u_216.cues, v236)
	end
	for _, v237 in v_u_17.cues(v_u_222, v_u_216.quick) do
		if v230 > v237.u then
			continue
		end
		local v238 = v_u_216.cues
		table.insert(v238, v237)
	end
	local v239 = v_u_17.PHASES[v_u_216.quick and "quick" or "normal"][v_u_222][5].t0
	local v240 = v_u_17.ticks(v_u_216.strip)
	if p_u_214.reduced then
		local v241 = v_u_17.shuffle(v_u_216.strip, 0)
		local v242 = 0.02
		v240 = {}
		while v242 < v_u_216.strip.T do
			local v243 = v_u_17.shuffle(v_u_216.strip, v242)
			if v243 == v241 then
				v243 = v241
			else
				table.insert(v240, v242)
			end
			v242 = v242 + 0.02
			v241 = v243
		end
	end
	local v244 = v_u_17.stripV
	local v245 = v_u_216.strip
	local v246 = math.max(1, v244(v245, 0))
	for _, v247 in v240 do
		local v248
		if p_u_214.reduced then
			v248 = (1 - v247 / v_u_216.strip.T) ^ 0.5
		else
			local v249 = v_u_17.stripV(v_u_216.strip, v247) / v246
			v248 = (v249 < 0 and 0 or (v249 > 1 and 1 or v249)) ^ 0.5
		end
		local v250 = v_u_216.cues
		local v251 = {
			["u"] = nil,
			["name"] = "crate_tick",
			["vol"] = nil,
			["pitch"] = nil,
			["tick"] = true,
			["u"] = v239 + v247,
			["vol"] = 0.55 + 0.45 * (1 - v248),
			["pitch"] = 0.8 + 0.7 * v248
		}
		table.insert(v250, v251)
	end
	table.sort(v_u_216.cues, function(p252, p253)
		if p252.u == p253.u then
			return p252.name < p253.name
		else
			return p252.u < p253.u
		end
	end)
	v_u_216.cueIdx = 1
	task.spawn(function()
		-- upvalues: (ref) v_u_16, (copy) v_u_218, (copy) p_u_215, (copy) p_u_214, (copy) v_u_216, (ref) v_u_222, (ref) v_u_35, (ref) v_u_103, (ref) v_u_5
		local v_u_254 = nil
		local function v255()
			-- upvalues: (ref) v_u_254, (ref) v_u_16
			v_u_254 = require(v_u_16:WaitForChild("WeaponDress"))
		end
		pcall(v255)
		local v256 = nil
		local v257
		if v_u_254 and v_u_218 then
			local v258 = v_u_254.build
			local v259 = v_u_218.weapon
			local v260 = p_u_215.skin
			local v261 = {
				["fx"] = nil,
				["tex"] = true,
				["own"] = true,
				["preview"] = true,
				["fx"] = p_u_214.quality == "high"
			}
			local v262
			v262, v257 = pcall(v258, v259, nil, false, v260, v261)
			if v262 then
				if typeof(v257) ~= "Instance" then
					v257 = v256
				end
			else
				v257 = v256
			end
		else
			v257 = v256
		end
		if p_u_214.done or p_u_214.run ~= v_u_216 then
			if v257 then
				v257:Destroy()
			end
		else
			if not v257 then
				v_u_216.texReady = true
			end
			p_u_214.world:setWinner(v257, v_u_216.color, v_u_222)
			v_u_216.winnerBuilt = true
			v_u_216.modelReady = true
			v_u_216.winStat = {
				["assets"] = 0,
				["capped"] = false,
				["ms"] = 0
			}
			local v263 = os.clock()
			if v_u_35.texDelay then
				task.wait(v_u_35.texDelay)
			end
			local v_u_264 = v_u_103(v257)
			v_u_216.winStat.assets = #v_u_264
			local function v265()
				-- upvalues: (ref) v_u_5, (copy) v_u_264
				v_u_5:PreloadAsync(v_u_264)
			end
			pcall(v265)
			v_u_216.winStat.ms = (os.clock() - v263) * 1000
			v_u_216.texReady = true
			v_u_216.animStop = nil
		end
	end)
	return true
end
function v_u_141._preloadReel(p_u_266, p_u_267) -- name: _preloadReel
	-- upvalues: (copy) v_u_35, (copy) v_u_2, (copy) v_u_5, (copy) v_u_103
	local v_u_268 = p_u_266.ui
	p_u_267.reelReady = false
	p_u_267.reelStat = {
		["tiles"] = 0,
		["warmed"] = 0,
		["assets"] = 0,
		["capped"] = false,
		["ms"] = 0,
		["unloaded"] = -1,
		["failed"] = 0,
		["status"] = nil,
		["status"] = {}
	}
	local v_u_269 = os.clock()
	local v_u_270 = false
	local function v_u_276(p271) -- name: finish
		-- upvalues: (copy) p_u_267, (ref) v_u_270, (copy) v_u_268, (copy) v_u_269
		if not p_u_267.reelReady then
			if v_u_270 then
				v_u_270 = false
				local function v272()
					-- upvalues: (ref) v_u_268
					v_u_268:warm(false)
				end
				pcall(v272)
			end
			p_u_267.reelReady = true
			p_u_267.reelStat.capped = p271
			p_u_267.reelStat.ms = (os.clock() - v_u_269) * 1000
			if p271 then
				local v273 = print
				local v274 = p_u_267.reelStat.ms
				local v275 = v_u_268 and v_u_268:reelUnloaded() or "?"
				v273(("[CrateStage] reel gate capped after %.0f ms (unloaded %s)"):format(v274, (tostring(v275))))
			end
		end
	end
	if v_u_268 and (v_u_268.tiles and (#v_u_268.tiles ~= 0 or v_u_268.building)) then
		task.delay(3, function()
			-- upvalues: (copy) v_u_276
			v_u_276(true)
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_35, (copy) v_u_268, (copy) p_u_266, (copy) p_u_267, (ref) v_u_2, (ref) v_u_5, (ref) v_u_103, (ref) v_u_270, (copy) v_u_269
			if v_u_35.reelDelay then
				task.wait(v_u_35.reelDelay)
			end
			while v_u_268.building and (not p_u_266.done and p_u_266.run == p_u_267) do
				v_u_2.Heartbeat:Wait()
			end
			local v_u_277 = v_u_103(v_u_268.gui)
			p_u_267.reelStat.assets = #v_u_277
			local function v280()
				-- upvalues: (ref) v_u_5, (copy) v_u_277, (ref) p_u_267
				v_u_5:PreloadAsync(v_u_277, function(_, p278)
					-- upvalues: (ref) p_u_267
					if p278 == Enum.AssetFetchStatus.Failure then
						local v279 = p_u_267.reelStat
						v279.failed = v279.failed + 1
					end
				end)
			end
			pcall(v280)
			if p_u_266.done or p_u_266.run ~= p_u_267 then
				return
			else
				local v_u_281 = v_u_103(v_u_268.gui)
				if #v_u_281 > #v_u_277 then
					p_u_267.reelStat.assets = #v_u_281
					local function v284()
						-- upvalues: (ref) v_u_5, (copy) v_u_281, (ref) p_u_267
						v_u_5:PreloadAsync(v_u_281, function(_, p282)
							-- upvalues: (ref) p_u_267
							if p282 == Enum.AssetFetchStatus.Failure then
								local v283 = p_u_267.reelStat
								v283.failed = v283.failed + 1
							end
						end)
					end
					pcall(v284)
					if p_u_266.done or p_u_266.run ~= p_u_267 then
						return
					end
				end
				if not p_u_267.reelReady then
					v_u_270 = true
					v_u_268:warm(true)
					v_u_2.Heartbeat:Wait()
					v_u_2.Heartbeat:Wait()
					v_u_2.Heartbeat:Wait()
				end
				while not p_u_267.reelReady and (not p_u_266.done and (p_u_266.run == p_u_267 and v_u_268:reelUnloaded() > 0)) do
					task.wait(0.1)
				end
				if v_u_270 then
					v_u_270 = false
					local function v285()
						-- upvalues: (ref) v_u_268
						v_u_268:warm(false)
					end
					pcall(v285)
				end
				p_u_267.reelStat.tiles = #v_u_268.tiles
				p_u_267.reelStat.warmed = v_u_268:warmedCount()
				p_u_267.reelStat.unloaded = v_u_268:reelUnloaded()
				if not p_u_267.reelReady then
					if v_u_270 then
						v_u_270 = false
						local function v286()
							-- upvalues: (ref) v_u_268
							v_u_268:warm(false)
						end
						pcall(v286)
					end
					p_u_267.reelReady = true
					p_u_267.reelStat.capped = false
					p_u_267.reelStat.ms = (os.clock() - v_u_269) * 1000
				end
			end
		end)
	elseif not p_u_267.reelReady then
		if v_u_270 then
			v_u_270 = false
			pcall(function()
				-- upvalues: (copy) v_u_268
				v_u_268:warm(false)
			end)
		end
		p_u_267.reelReady = true
		p_u_267.reelStat.capped = false
		p_u_267.reelStat.ms = (os.clock() - v_u_269) * 1000
	end
end
function v_u_141.fail(p287, p288) -- name: fail
	if p287.done then
		return false
	end
	p287.run.failed = p288 or "Not available right now."
	return true
end
function v_u_141.onDone(p289, p290) -- name: onDone
	if p289.done then
		task.defer(p290, p289.info)
	else
		local v291 = p289.doneCallbacks
		table.insert(v291, p290)
	end
end
function v_u_141.isPlaying(p292) -- name: isPlaying
	return not p292.done
end
function v_u_141.state(p293) -- name: state
	return p293.state_
end
function v_u_141.u(p294) -- name: u
	-- upvalues: (copy) v_u_17
	local v295 = p294.lastU
	if not v295 then
		local v296 = v_u_17.pressU
		local v297 = p294.run
		if v297 then
			v297 = p294.run.quick
		end
		v295 = v296(v297)
	end
	return v295
end
function v_u_141.skip(p298, _) -- name: skip
	-- upvalues: (copy) v_u_35, (copy) v_u_17, (copy) v_u_10, (copy) v_u_95
	local v299 = p298.run
	if p298.done or not v299 then
		return false
	end
	local v300 = (os.clock() - v299.t0) * v_u_35.speed - v299.stall
	if not v_u_17.skipAllowed(v300 + 0, v299.result ~= nil) then
		return false
	end
	if v299.strip and not v299.clock.skipT then
		local v301 = v_u_17.PHASES[v299.quick and "quick" or "normal"][v299.rarity]
		local v302 = v299.clock:u(v300) - v301[5].t0
		v299.xAtSkip = v_u_17.stripX(v299.strip, (v_u_10(0, v302)))
	end
	local v303 = v299.clock:skip(v300)
	if v303 then
		v299.skipRealT = os.clock()
		v_u_95()
		v299.skipped = true
	end
	return v303
end
function v_u_141._equip(p304) -- name: _equip
	-- upvalues: (copy) v_u_92
	local v305 = p304.run
	if v305 and v305.skin then
		local v306
		if p304.opts.onEquip then
			local v307 = p304.opts.onEquip
			local v308 = v305.skin.weapon
			local v309 = v305.result.skin
			local v310 = v305.result.uid
			local v311
			v306, v311 = pcall(v307, v308, v309, v310)
			if v306 then
				v306 = v311 ~= false
			end
		else
			v306 = true
		end
		if v306 then
			v305.equipped = true
			if p304.ui then
				p304.ui:buttonText("equip", "EQUIPPED")
				local v_u_312 = p304.ui.btn.equip
				if v_u_312 then
					pcall(function()
						-- upvalues: (copy) v_u_312
						v_u_312.Active = false
						v_u_312.AutoButtonColor = false
					end)
				end
			end
			v_u_92("crate_equip", 1, 1)
		end
	end
end
function v_u_141.stop(p313, p314) -- name: stop
	p313:_finish(type(p314) ~= "string" and "done" or p314)
end
function v_u_141._next(p315) -- name: _next
	-- upvalues: (copy) v_u_19
	local v_u_316 = p315.run
	if p315.done or (not v_u_316 or (not v_u_316.result or v_u_316.nextAt)) then
		return
	else
		local v317 = p315.opts
		if v317.demo then
			v_u_316.nextAt = os.clock()
			v_u_316.nextCrate = v_u_316.crateId
			v_u_316.nextDemo = v_u_316.rarity % 6 + 1
			return
		elseif v317.requestNext then
			if v_u_19.nextNeedsConfirm(v_u_316.result) then
				local v318 = os.clock()
				if p315.nextArmed == nil or v318 - p315.nextArmed > v_u_19.NEXT_CONFIRM_SECONDS then
					p315.nextArmed = v318
					if p315.ui then
						p315.ui:buttonText("next", v_u_19.nextConfirmLabel(v_u_316.result))
						p315.ui:message(v_u_19.NEXT_CONFIRM_TEXT)
					end
					return
				end
				p315.nextArmed = nil
				if p315.ui then
					p315.ui:message(nil)
				end
			end
			v_u_316.nextAt = os.clock()
			v_u_316.nextCrate = v_u_316.crateId
			local v_u_319 = false
			local v320 = v317.requestNext
			local v321 = v_u_316.crateId
			local function v324(p322, p323)
				-- upvalues: (ref) v_u_319, (copy) v_u_316
				v_u_319 = true
				v_u_316.nextResult = p322
				v_u_316.nextErr = p323
				v_u_316.nextAnswered = true
			end
			local v325, v326 = pcall(v320, v321, v324)
			if not v325 then
				v_u_316.nextErr = tostring(v326)
				v_u_316.nextAnswered = true
			end
		end
	end
end
function v_u_141._input(p327, p328, p329) -- name: _input
	-- upvalues: (copy) v_u_3
	if p327.done then
		return
	else
		local v330 = p328.UserInputType
		if v330 == Enum.UserInputType.Keyboard then
			local v331 = p328.KeyCode
			if v331 == Enum.KeyCode.Escape then
				p327:_finish("escape")
				return
			elseif v331 == Enum.KeyCode.Tab or (v331 == Enum.KeyCode.LeftShift or (v331 == Enum.KeyCode.RightShift or (v331 == Enum.KeyCode.LeftControl or (v331 == Enum.KeyCode.RightControl or (v331 == Enum.KeyCode.LeftAlt or v331 == Enum.KeyCode.RightAlt))))) then
				return
			elseif not (p329 and (p327.ui and v_u_3:GetFocusedTextBox())) then
				p327:skip("key")
			end
		else
			if v330 == Enum.UserInputType.Gamepad1 then
				local v332 = p328.KeyCode
				if v332 == Enum.KeyCode.ButtonB and (p327.run and p327.run.buttonsShown) then
					p327:_finish("done")
					return
				end
				if v332 == Enum.KeyCode.Thumbstick1 or (v332 == Enum.KeyCode.Thumbstick2 or (v332 == Enum.KeyCode.ButtonL3 or v332 == Enum.KeyCode.ButtonR3)) then
					return
				end
				p327:skip("pad")
			end
			return
		end
	end
end
function v_u_141._tick(p333, _) -- name: _tick
	-- upvalues: (copy) v_u_10
	if p333.done then
		return
	else
		local v334 = os.clock()
		if not p333.lastTick or v334 - p333.lastTick >= 0.004 then
			local v335 = p333.lastTick or v334
			p333.lastTick = v334
			local v336 = os.clock()
			local v337 = p333._update
			local v338 = v334 - v335
			local v339, v340 = pcall(v337, p333, v334, v338)
			local v341 = (os.clock() - v336) * 1000
			p333.frames = p333.frames + 1
			p333.frameSum = p333.frameSum + v341
			p333.frameMax = v_u_10(p333.frameMax, v341)
			if not v339 then
				p333.errors = p333.errors + 1
				if p333.errors <= 3 then
					warn("[CrateStage] frame error:", v340)
				end
				if p333.errors >= 6 then
					p333:_finish("error")
				end
			end
			if p333.opts.alive and not p333.done then
				local v342 = p333.opts.alive
				local v343, v344 = pcall(v342)
				if v343 and v344 == false then
					p333:_finish("left")
				end
			end
		end
	end
end
function v_u_141._fireEvent(p345, p346) -- name: _fireEvent
	local v347 = p345.world
	if p346.kind == "latch" then
		v347:fire("latch", p346.a)
		return
	elseif p346.kind == "burst" then
		v347:fire("burst")
		return
	elseif p346.kind == "ring" then
		v347:fire("ring", p346.a, p346.color)
		return
	elseif p346.kind == "confetti" then
		v347:fire("confetti", p346.a, {
			["color"] = p346.color,
			["extra"] = p346.extra
		})
	elseif p346.kind == "glitter" then
		v347:fire("glitter")
	end
end
function v_u_141._update(p_u_348, p349, p350) -- name: _update
	-- upvalues: (copy) v_u_17, (copy) v_u_36, (copy) v_u_35, (copy) v_u_9, (copy) v_u_13, (copy) v_u_11, (copy) v_u_92, (copy) v_u_21, (copy) v_u_14, (copy) v_u_12, (copy) v_u_10, (copy) v_u_3, (copy) v_u_16
	local v_u_351 = p_u_348.run
	local v_u_352 = p_u_348.world
	local v353 = v_u_351.quick
	local v354 = v_u_17.PHASES[v353 and "quick" or "normal"][v_u_351.rarity]
	if not v_u_36.preloaded and p349 - p_u_348.beginAt < 0.7 then
		v_u_351.t0 = p349
	end
	local v355 = (p349 - v_u_351.t0) * v_u_35.speed
	local v356 = v_u_17.pressU(v353)
	local v357 = v354[5].t0
	local v358
	if v353 then
		v358 = v_u_17.STRIP.leadQuick
	else
		v358 = v_u_17.STRIP.lead
	end
	local v359 = v357 - v358 - 0.05
	if v_u_351.nextAt and not v_u_351.nextStarted then
		local v360 = p349 - v_u_351.nextAt
		p_u_348:_updateClosing(v360, p349)
		local v361 = v_u_351.nextAnswered or p_u_348.opts.demo
		if v360 >= 0.45 and v361 then
			if v_u_351.nextErr then
				p_u_348.ui:message(v_u_351.nextErr)
				p_u_348:_finish("error")
				return
			else
				local v362 = v_u_351.nextResult
				local v363 = v_u_351.nextDemo
				local v364 = v_u_351.nextCrate
				local v365 = {
					["opened"] = p_u_348.opened
				}
				local v366 = v_u_351.result
				if v366 then
					v366 = v_u_351.result.left
				end
				v365.left = v366
				if p_u_348.world.winner then
					p_u_348.world:clearWinner()
				end
				p_u_348:_newRun(v364, true).t0 = p349
				if p_u_348.opts.demo then
					p_u_348:resolve(v_u_9._demoResult(v363 or 1, v364))
				elseif v362 then
					p_u_348:resolve(v362)
				end
			end
		else
			return
		end
	else
		if v_u_351.failed then
			if not v_u_351.failedAt then
				v_u_351.failedAt = p349
				if p_u_348.ui then
					p_u_348.ui:message(v_u_351.failed)
					p_u_348.ui:skipHint(false)
				end
			end
			if p349 - v_u_351.failedAt > 2.2 then
				p_u_348:_finish("error")
				return
			end
		end
		local v367 = v_u_351.clock:u(v355 - v_u_351.stall)
		if v_u_351.result then
			v_u_351.stallStart = nil
			if v_u_351.reelReady and v_u_351.modelReady or v359 >= v367 then
				v359 = v367
			else
				v_u_351.stall = v_u_351.stall + (v367 - v359)
				v_u_351.loadStart = v_u_351.loadStart or p349
				if p349 - v_u_351.loadStart > 3.5 then
					v_u_351.reelReady = true
					v_u_351.modelReady = true
				end
			end
			v367 = v354[9].t0 - 0.02
			if v_u_351.texReady or v367 >= v359 then
				v367 = v359
			else
				v_u_351.stall = v_u_351.stall + (v359 - v367)
				v_u_351.revealStart = v_u_351.revealStart or p349
				if p349 - v_u_351.revealStart > 2 then
					v_u_351.texReady = true
					if v_u_351.winStat then
						v_u_351.winStat.capped = true
					end
				end
			end
		elseif v359 < v367 then
			v_u_351.stall = v_u_351.stall + (v367 - v359)
			v_u_351.stallStart = v_u_351.stallStart or p349
			if p349 - v_u_351.stallStart > 6 then
				if p_u_348.ui then
					p_u_348.ui:message(v_u_351.failed or "Not available right now.")
				end
				p_u_348:_finish("error")
				return
			end
			v367 = v359
		end
		if v_u_35.hold then
			v367 = v_u_35.hold
		end
		if v_u_35.loop and (not v_u_35.hold and v_u_351.result) then
			local v368 = v_u_35.loop[1]
			local v369 = v_u_35.loop[2]
			v367 = v368 + (v355 - v_u_351.stall) % (v369 - v368)
			if v_u_351.lastU == nil or (v367 < v_u_351.lastU - 0.001 or v_u_351.lastU < v368) then
				v_u_351.eventIdx = 1
				while v_u_351.eventIdx <= #v_u_351.events and v_u_351.events[v_u_351.eventIdx].u <= v367 do
					v_u_351.eventIdx = v_u_351.eventIdx + 1
				end
				v_u_351.cueIdx = 1
				while v_u_351.cueIdx <= #v_u_351.cues and v_u_351.cues[v_u_351.cueIdx].u <= v367 do
					v_u_351.cueIdx = v_u_351.cueIdx + 1
				end
			end
		end
		p_u_348.lastU = v367
		local v370 = v_u_17.warp(v367, v_u_351.rarity, v353)
		local v371 = v_u_351.rarity
		local v372 = v_u_17.TIERS[v371]
		local v373
		if v_u_351.result then
			local v374 = (v367 - (v354[7].t0 + v372.silence)) / 0.25
			local v375 = v374 < 0 and 0 or (v374 > 1 and 1 or v374)
			v373 = v375 * v375 * (3 - v375 * 2)
		else
			v373 = 0
		end
		local v_u_376 = {}
		for _, v377 in {
			"seam",
			"wall",
			"column",
			"colw",
			"lid",
			"lidfade",
			"core",
			"mouth",
			"ring",
			"flash",
			"hum",
			"music",
			"strip",
			"glow",
			"charge"
		} do
			v_u_376[v377] = v_u_17.env(v377, v367, v371, v353)
		end
		if p_u_348.reduced then
			v_u_376.flash = 0
		end
		if v_u_351.stallStart or v_u_351.loadStart and not (v_u_351.reelReady and v_u_351.modelReady) then
			local v378 = p349 - (v_u_351.stallStart or v_u_351.loadStart)
			v_u_376.seam = v_u_11(1, v_u_376.seam + (v_u_13(v378 * 5) * 0.5 + 0.5) * 0.06)
		end
		local v379 = v_u_17.phaseAt(v367, v371, v353)
		p_u_348.state_ = string.lower(v379)
		if v_u_351.strip and (not v_u_351.showSeen and (v_u_376.strip > 0.001 and p_u_348.ui)) then
			v_u_351.showSeen = true
			v_u_351.showU = v367
			v_u_351.unloadedAtShow = p_u_348.ui:reelUnloaded()
			v_u_351.tilesAtShow = p_u_348.ui.tileGen
			local v380
			if v_u_351.reelStat then
				v380 = v_u_351.reelStat.capped or false
			else
				v380 = false
			end
			v_u_351.reelCappedAtShow = v380
		end
		if v_u_351.strip and (not v_u_351.rollSeen and (v354[5].t0 <= v367 and p_u_348.ui)) then
			v_u_351.rollSeen = true
			v_u_351.unloadedAtRoll = p_u_348.ui:reelUnloaded()
			local v381
			if v_u_351.reelStat then
				v381 = v_u_351.reelStat.capped or false
			else
				v381 = false
			end
			v_u_351.reelCappedAtRoll = v381
			local v382
			if v_u_351.tilesAtShow == nil then
				v382 = false
			else
				v382 = v_u_351.tilesAtShow ~= p_u_348.ui.tileGen
			end
			v_u_351.rebuiltAfterShow = v382
		end
		if not v_u_351.lastU then
			local _ = v356 - 0.001
		end
		if v_u_35.hold then
			v_u_351.eventIdx = 1
			while v_u_351.eventIdx <= #v_u_351.events and v_u_351.events[v_u_351.eventIdx].u <= v367 do
				v_u_351.eventIdx = v_u_351.eventIdx + 1
			end
			v_u_351.cueIdx = 1
			while v_u_351.cueIdx <= #v_u_351.cues and v_u_351.cues[v_u_351.cueIdx].u <= v367 do
				v_u_351.cueIdx = v_u_351.cueIdx + 1
			end
		else
			while v_u_351.eventIdx <= #v_u_351.events and v_u_351.events[v_u_351.eventIdx].u <= v367 do
				local v383 = v_u_351.events[v_u_351.eventIdx]
				v_u_351.eventIdx = v_u_351.eventIdx + 1
				if v367 - v383.u >= 0.3 and (not v_u_351.skipped or (v383.u < v354[7].t0 or v383.u > v354[9].t0 + 0.2)) then
					continue
				end
				p_u_348:_fireEvent(v383)
			end
			local v384 = v_u_351.revealPlayed
			while v_u_351.cueIdx <= #v_u_351.cues and v_u_351.cues[v_u_351.cueIdx].u <= v367 do
				local v385 = v_u_351.cues[v_u_351.cueIdx]
				v_u_351.cueIdx = v_u_351.cueIdx + 1
				local v386 = v367 - v385.u < 0.3
				if v_u_351.skipped then
					local v387 = v385.name
					local v388 = string.sub(v387, 1, 12) == "crate_reveal"
					v386 = v388 and (not v384 and v385.u >= v354[7].t0) and true or v385.u >= v354[9].t0
					if v388 and v386 then
						v_u_351.revealPlayed = true
						v384 = true
					end
				end
				if not v386 then
					continue
				end
				if v385.name == "crate_hum" then
					v_u_351.hum = v_u_92("crate_hum", 0, 0.7)
				else
					if v385.tick and v_u_351.rarity < 1 then
						continue
					end
					v_u_92(v385.name, v385.vol, v385.pitch, v385.len)
				end
			end
		end
		v_u_351.lastU = v367
		if v_u_351.hum then
			local v389 = v_u_21.defs.crate_hum
			local v_u_390
			if v389 then
				v_u_390 = v389.v[1]
			else
				v_u_390 = v389
			end
			if v_u_390 then
				local v391 = (v389.gain or 0.6) * (v_u_390.g or 1)
				local v392 = v_u_390.id
				local v393 = v_u_21.loudness
				if v393 then
					v393 = v_u_21.loudness[v392]
				end
				local v394
				if v393 and v393 > 0 then
					local v395 = (v_u_21.REF_LOUDNESS or 300) / v393
					v394 = math.clamp(v395, 0.25, 6)
				else
					v394 = 1
				end
				local v_u_396 = v391 * v394 * v_u_376.hum * 0.9
				pcall(function()
					-- upvalues: (copy) v_u_351, (copy) v_u_396, (copy) v_u_390, (copy) v_u_376
					local v397 = v_u_396
					v_u_351.hum.Volume = math.min(10, v397)
					local v398 = v_u_351.hum
					local v399 = v_u_390.p or 1
					local v400 = v_u_376.charge
					v398.PlaybackSpeed = v399 * ((v400 < 0 and 0 or (v400 > 1 and 1 or v400)) * 0.30000000000000004 + 0.7)
				end)
				if v_u_376.hum <= 0 and v354[4].t0 < v367 then
					local v_u_401 = v_u_351.hum
					pcall(function()
						-- upvalues: (copy) v_u_401
						v_u_401:Stop()
						v_u_401.Volume = 0
					end)
					v_u_351.hum = nil
				end
			end
		end
		if p_u_348.musicGroup then
			local v_u_402 = p_u_348.musicBase or 1
			pcall(function()
				-- upvalues: (copy) p_u_348, (copy) v_u_402, (copy) v_u_376
				p_u_348.musicGroup.Volume = v_u_402 * v_u_376.music
			end)
		end
		local v403 = v_u_351.rarity
		local v404 = v_u_17.camAt(v370, v403, p_u_348.quality, v_u_351.quick)
		local v405 = p_u_348.centre
		local v406 = v405 + v404.pos
		local v407 = v405 + v404.look
		if not p_u_348.reduced then
			v406 = v406 + v_u_17.shake(v370, v403, v_u_351.quick, p_u_348.shakeAmt)
		end
		if p_u_348.cam then
			local v408 = CFrame.lookAt(v406, v407)
			if v404.roll ~= 0 and not p_u_348.reduced then
				v408 = v408 * CFrame.Angles(0, 0, (v_u_14(v404.roll)))
			end
			p_u_348.cam.CameraType = Enum.CameraType.Scriptable
			p_u_348.cam.CFrame = v408
			p_u_348.cam.FieldOfView = v404.fov
			p_u_348.cam.Focus = CFrame.new(v407)
		end
		local v409 = v_u_17.rig(v367, v371, v353)
		local v410 = {
			["show"] = v356 - 0.02 < v367,
			["fade"] = v_u_376.lidfade or 0
		}
		local v411
		if v379 == "CHARGE" and not p_u_348.reduced then
			local v412 = 0.035 * v_u_376.charge
			local v413 = v_u_12(v367 * 34)
			local v414 = v_u_17._hash(v413) * v412
			local v415 = v_u_17._hash(v413 + 7.7) * v412 * 0.6
			v411 = Vector3.new(v414, v415, 0)
		else
			v411 = nil
		end
		local v416 = {
			["u"] = v367,
			["uWarp"] = v370,
			["rarity"] = v371,
			["quick"] = v353,
			["env"] = v_u_376,
			["tier"] = v372
		}
		local v417
		if v_u_351.result then
			v417 = v_u_351.color
		else
			v417 = nil
		end
		v416.glowColor = v417
		v416.flood = v373
		v416.godray = v373
		v416.latchTimes = v_u_17.latchTimes(v353)
		v416.burstU = v354[4].t0
		v416.key = v410
		v416.rig = v409
		v416.jitter = v411
		v_u_352:update(v416)
		if v_u_352.winner then
			local v418 = v354[8].t0
			local v419 = v354[9].t0
			local _ = v354[10].t0
			v_u_10(0, v370 - v419)
			local v_u_420 = 0
			if v_u_351.buttonsShown then
				local function v423()
					-- upvalues: (ref) v_u_3, (ref) v_u_420
					for _, v421 in v_u_3:GetGamepadState(Enum.UserInputType.Gamepad1) do
						if v421.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						local v422 = v421.Position.X
						if math.abs(v422) <= 0.15 then
							continue
						end
						v_u_420 = v421.Position.X
					end
				end
				pcall(v423)
			end
			v_u_351.spin = (v_u_351.spin or 0) + (v418 > v367 and 0 or p350 * 22 * v_u_35.speed) + (v_u_351.dragDelta or 0) + v_u_420 * 140 * p350
			v_u_351.dragDelta = 0
			local v424 = {}
			local v425
			if v418 <= v367 then
				v425 = v367 < 1000000000
			else
				v425 = false
			end
			v424.show = v425
			local v426 = (v367 - v418) / (v419 - v418)
			v424.rise = v426 < 0 and 0 or (v426 > 1 and 1 or v426)
			local v427 = (v367 - v419) / 0.25
			local v428 = v427 < 0 and 0 or (v427 > 1 and 1 or v427)
			v424.reveal = v428 * v428 * (3 - v428 * 2)
			local v429 = (v367 - v418) / 0.6
			v424.light = v429 < 0 and 0 or (v429 > 1 and 1 or v429)
			v424.t = v_u_10(0, v370 - v418)
			v424.spin = v_u_351.spin
			v_u_352:winnerUpdate(v424)
			if v419 <= v367 and (not v_u_351.animStop and v_u_351.skin) then
				v_u_351.animStop = true
				local function v430()
					-- upvalues: (ref) v_u_16, (copy) v_u_351, (copy) v_u_352
					v_u_351.animFn = require(v_u_16:WaitForChild("SkinApply")).animate(v_u_352.winner.model, v_u_351.result.skin)
				end
				pcall(v430)
			end
		end
		local v431 = p_u_348.light
		if v431 then
			v431:step()
			v431:set("bloom", 0.3 + 0.22 * v_u_376.glow + 0.7 * v_u_376.flash + v373 * 0.1)
			v431:set("brightness", 0.5 * v_u_376.flash)
			v431:set("grade", (Color3.new(1, 1, 1):Lerp((v_u_351.color or Color3.new(1, 1, 1)):Lerp(Color3.new(1, 1, 1), 0.55), v373 * 0.18)))
			local v432 = v_u_351.color or Color3.new(1, 1, 1)
			v431:set("atmoColor", Color3.fromRGB(22, 24, 30):Lerp(Color3.new(v432.R * 0.5, v432.G * 0.5, v432.B * 0.5), v373 * 0.45))
			v431:set("atmoDensity", v373 * 0.07 + 0.32 + 0.03 * v_u_376.column)
			v431:set("atmoHaze", v373 * 0.5 + 0.6)
		end
		p_u_348:_updateUi(p349, v367, v370, v_u_376, v354, v_u_351, v355)
		return
	end
end
function v_u_141._updateClosing(p433, p434, _) -- name: _updateClosing
	-- upvalues: (copy) v_u_14, (ref) v_u_29
	local v435 = p433.run
	local v_u_436 = p433.world
	local v437 = p434 / 0.4
	local v_u_438 = v437 < 0 and 0 or (v437 > 1 and 1 or v437)
	if v_u_436.hinge and v_u_436.hingeC0 then
		local v439 = v_u_436.hinge
		local v440 = v_u_436.hingeC0
		local v441 = CFrame.Angles
		local v442 = v_u_438 < 0 and 0 or (v_u_438 > 1 and 1 or v_u_438)
		v439.C0 = v440 * v441(v_u_14((1 - v442 * v442 * (3 - v442 * 2)) * 115), 0, 0)
	end
	if v_u_436.winner then
		v_u_436:winnerUpdate({
			["show"] = nil,
			["rise"] = 1,
			["reveal"] = 1,
			["light"] = nil,
			["t"] = 5,
			["spin"] = nil,
			["show"] = v_u_438 < 0.9,
			["light"] = 1 - v_u_438,
			["spin"] = v435.spin or 0
		})
		if v_u_436.winner.model.Parent then
			pcall(function()
				-- upvalues: (copy) v_u_436, (copy) v_u_438
				local v443 = v_u_436.winner.model:GetPivot()
				local v444 = v_u_436.winner.model
				local v445 = v_u_438 * 0.5 * 6
				v444:PivotTo(v443 + Vector3.new(0, v445, 0))
			end)
		end
	end
	if p433.ui then
		p433.ui:buttons(false)
		p433.ui:plate(nil, 0)
		p433.ui:stamp(1, 0)
		if v_u_29 then
			local v446 = v_u_29.hide
			local v447 = p433.ui
			pcall(v446, v447)
		end
		p433.ui:holdHintText(nil)
	end
end
function v_u_141._updateUi(p448, p449, p450, _, p451, p452, p453, p454) -- name: _updateUi
	-- upvalues: (copy) v_u_17, (ref) v_u_32, (copy) v_u_10, (copy) v_u_20, (copy) v_u_26, (ref) v_u_29, (copy) v_u_19, (copy) v_u_18, (copy) v_u_3, (copy) v_u_8
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v455, v456, v457, v458, v459, v460, v461, v462, v463, v464, v465, v466, v467, v468, v469, v470, v471, v472, v473, v474, v475, v476, v477, v478, v479, v480, v481, v482, v483, v484, v485, v486, v_u_487, v488, v489, v490, v_u_491, v492, v493, v494, v495, v496, v497, v498, v499, v500, v501, v502, v503, v504, v505, v506, v_u_507, v508, v509, v510, v511, v512, v513
	local v514 = 12
	while true do
		if v514 == 1 then
			if v471 <= p450 and not p453.counted then
				p453.counted = true
				p448.opened = p448.opened + 1
			end
			v514 = 2
		elseif v514 == 2 then
			return
		elseif v514 == 3 then
			v468 = ""
			v_u_487:counter(v501:format(v502, v468))
			v514 = 1
		elseif v514 == 4 then
			if v476.keys then
				v469 = v476.keys
				v468 = "   KEYS " .. tostring(v469)
			else
				v468 = ""
			end
			v514 = 8
		elseif v514 == 5 then
			v476 = p453.result.left or {}
			v501 = "%d OPENED%s"
			v502 = v_u_10(v505, 1)
			if p448.opts.demo then
				v514 = 3
			else
				v514 = 7
			end
		elseif v514 == 6 then
			if v471 <= p450 and not p453.counted then
				p453.counted = true
				p448.opened = p448.opened + 1
			end
			v514 = 2
		elseif v514 == 7 then
			if p453.result.paid == "cash" then
				v514 = 9
			else
				v514 = 10
			end
		elseif v514 == 8 then
			v_u_487:counter(v501:format(v502, v468))
			v514 = 1
		elseif v514 == 9 then
			v477 = v476.cash
			if tonumber(v477) then
				v514 = 11
			else
				v514 = 4
			end
		elseif v514 == 10 then
			if v476.keys then
				v469 = v476.keys
				v468 = "   KEYS " .. tostring(v469)
			else
				v468 = ""
			end
			v514 = 8
		elseif v514 == 11 then
			v478 = v476.cash
			v495 = tonumber(v478) or 0
			v459 = math.floor(v495)
			v468 = "   CASH $" .. tostring(v459)
			v_u_487:counter(v501:format(v502, v468))
			v514 = 1
		else
			v_u_487 = p448.ui
			if not v_u_487 then
				return
			end
			v488 = p453.rarity
			v460 = p453.quick
			v466 = p454 - p453.stall
			v467 = v466 / 0.45
			v496 = v467 < 0 and 0 or (v467 > 1 and 1 or v467)
			v_u_487:setFade(1 - v496 * v496 * (3 - v496 * 2))
			v503 = v466 / 0.5
			v482 = v503 < 0 and 0 or (v503 > 1 and 1 or v503)
			v_u_487:setLetterbox(v482 * v482 * (3 - v482 * 2))
			v483 = v_u_17.skipAllowed(v466, p453.result ~= nil) and not p453.clock.skipT
			if v483 then
				v483 = p450 < p452[9].t0
			end
			v_u_507 = "Keyboard"
			v508 = function()
				-- upvalues: (ref) v_u_32, (ref) v_u_507
				local v515 = v_u_32 and v_u_32.lib
				if v515 then
					v515 = v_u_32.lib.HushUI
				end
				if v515 and v515.device then
					v_u_507 = v515.device()
				end
			end
			pcall(v508)
			v_u_487:skipHint(v483, v_u_507 == "Touch" and "Tap anywhere to skip" or (v_u_507 == "Gamepad" and "Press any button to skip" or "Click anywhere to skip"))
			v456 = p453.strip
			if v456 then
				v457 = p452[5].t0
				v486 = p452[6].t0
				v458 = p450 - v457
				v506 = p451.strip
				v479 = v_u_17.stripX(v456, (v_u_10(0, v458)))
				if p453.xAtSkip and p453.skipRealT then
					v480 = (p449 - p453.skipRealT) / 0.15
					v481 = v480 < 0 and 0 or (v480 > 1 and 1 or v480)
					v492 = v481 * v481 * (3 - v481 * 2)
					v493 = p453.xAtSkip
					v479 = v493 + (v456.D - v493) * v492
					v458 = v456.T
				end
				v470 = v_u_17.stripV(v456, v458) / v456.tileW
				v494 = (p450 - v486) / 0.2
				v484 = v494 < 0 and 0 or (v494 > 1 and 1 or v494)
				v485 = v484 * v484 * (3 - v484 * 2)
				if p453.skipped then
					v470 = 0
					v485 = 1
				end
				if p448.reduced then
					v_u_487:shuffleShow(v456, v_u_17.shuffle(v456, (v_u_10(0, v458))), v506)
				else
					v_u_487:stripUpdate(v479, v506, v470, v485, v456.winner)
					if v486 <= p450 and p450 < v486 + 0.14 then
						v_u_487:winnerPunch(v456.winner, (p450 - v486) / 0.12)
					elseif v486 + 0.14 <= p450 then
						v_u_487:winnerPunch(v456.winner, 0)
					end
				end
			end
			if not p453.result then
				return
			end
			v509 = p452[7].t0 + v_u_17.TIERS[v488].silence
			v510 = p453.crateId
			v511 = v_u_20.get(v510)
			v_u_487:stampSubText(not (v511 and v511.name) and "CASE" or v511.name)
			v512 = (p450 - v509) / 0.55
			v_u_487:stamp(v488, v512 < 0 and 0 or (v512 > 1 and 1 or v512), v_u_26.GLOW[v488])
			if v_u_29 then
				v513 = v_u_29.play
				v455 = {
					["quick"] = v460,
					["reduced"] = p448.reduced,
					["skipped"] = p453.skipped == true
				}
				pcall(v513, v_u_487, p453, p450, v509, v455)
			end
			v471 = p452[9].t0
			v472 = (p450 - v471) / 0.4
			v498 = v472 < 0 and 0 or (v472 > 1 and 1 or v472)
			v499 = p453.skin
			if v499 and v498 > 0 then
				v473 = v_u_19.resultLine(p453.result) .. (not v_u_29 and "" or v_u_29.lineSuffix(p453.result))
				v_u_487:plate({
					["weapon"] = string.upper(v_u_18.weaponName(v499.weapon) or ""),
					["name"] = v499.name,
					["rarity"] = v488,
					["line"] = v473,
					["glow"] = v_u_26.GLOW[v488]
				}, v498)
			else
				v_u_487:plate(nil, 0)
			end
			v500 = p452[10].t0
			if v471 + 1 <= p450 and not p453.nextAt then
				if p453.buttonsShown then
					if p448.nextArmed and os.clock() - p448.nextArmed > v_u_19.NEXT_CONFIRM_SECONDS then
						p448.nextArmed = nil
						v_u_487:buttonText("next", v_u_19.nextLabel(p453.result))
						v_u_487:message(nil)
					end
				else
					p453.buttonsShown = true
					p448.nextArmed = nil
					v474 = {}
					v475 = p448.opts
					v461 = p453.result
					if not v475.demo and (not p453.equipped and (v461.dup ~= true or v461.tally == true)) and (not v461.autoEquipped and v475.onEquip) then
						table.insert(v474, {
							["id"] = "equip",
							["text"] = "EQUIP",
							["kind"] = "primary"
						})
					end
					v462 = v461.left or {}
					v463 = not v475.demo and v475.requestNext
					if v463 then
						v489 = v462.crates
						if (tonumber(v489) or 0) > 0 then
							v490 = v462.keys
							v463 = ((tonumber(v490) or 0) > 0 or v475.keysFree == true) and true or v462.cashMore == true
						else
							v463 = false
						end
					end
					if v463 then
						v464 = {
							["id"] = "next",
							["text"] = nil,
							["width"] = nil,
							["kind"] = nil,
							["text"] = v_u_19.nextLabel(v461),
							["width"] = v_u_19.nextNeedsConfirm(v461) and 250 or nil,
							["kind"] = #v474 == 0 and "primary" or "secondary"
						}
						table.insert(v474, v464)
					end
					v465 = {
						["id"] = "done",
						["text"] = "DONE",
						["kind"] = nil,
						["kind"] = #v474 == 0 and "primary" or "ghost"
					}
					table.insert(v474, v465)
					v_u_487.btnBuilt = nil
					for _, v516 in v_u_487.btn do
						v516:Destroy()
					end
					table.clear(v_u_487.btn)
					v_u_487:buttons(true, v474)
					v_u_491 = "Keyboard"
					v504 = function()
						-- upvalues: (ref) v_u_32, (ref) v_u_491
						local v517 = v_u_32 and v_u_32.lib
						if v517 then
							v517 = v_u_32.lib.HushUI
						end
						if v517 and v517.device then
							v_u_491 = v517.device()
						end
					end
					pcall(v504)
					v_u_487:holdHintText(v_u_491 == "Touch" and "Drag to turn the weapon" or (v_u_491 == "Gamepad" and "Use the right stick to turn the weapon" or "Drag to turn the weapon"))
					v497 = function()
						-- upvalues: (copy) v_u_487, (ref) v_u_3, (ref) v_u_8
						local v518 = v_u_487.btn.equip or (v_u_487.btn.next or v_u_487.btn.done)
						if v518 and v_u_3.GamepadEnabled then
							v_u_8.SelectedObject = v518
						end
					end
					pcall(v497)
				end
			else
				v_u_487:buttons(false)
				v_u_487:holdHintText(nil)
				p453.buttonsShown = false
			end
			v505 = p448.opened
			if v505 >= 1 or p453.counted then
				v514 = 5
			else
				v514 = 6
			end
		end
	end
end
function v_u_141._finish(p_u_519, p520) -- name: _finish
	-- upvalues: (ref) v_u_33, (ref) v_u_34, (copy) v_u_2, (copy) v_u_95, (copy) v_u_97, (ref) v_u_32, (copy) v_u_15, (copy) v_u_8
	if not p_u_519.done then
		p_u_519.done = true
		p_u_519.state_ = "done"
		v_u_33 = p_u_519
		v_u_34 = os.clock()
		local v_u_521 = p_u_519.run
		local v522 = {
			["reason"] = p520,
			["opened"] = p_u_519.opened
		}
		local v523 = v_u_521 and v_u_521.result
		if v523 then
			v523 = v_u_521.result.skin
		end
		v522.skin = v523
		v522.crate = p_u_519.crateId
		v522.frames = p_u_519.frames
		v522.frameAvg = p_u_519.frames <= 0 and 0 or p_u_519.frameSum / p_u_519.frames
		v522.frameMax = p_u_519.frameMax
		v522.buildMs = p_u_519.buildMs
		p_u_519.info = v522
		local function v524()
			-- upvalues: (copy) p_u_519, (ref) v_u_2
			if p_u_519.renderBound then
				v_u_2:UnbindFromRenderStep(p_u_519.renderName)
			end
		end
		local v525, v526 = pcall(v524)
		if not v525 then
			warn("[CrateStage] cleanup:", v526)
		end
		local v528, v529 = pcall(function()
			-- upvalues: (copy) p_u_519
			for _, v527 in p_u_519.conns or {} do
				v527:Disconnect()
			end
		end)
		if not v528 then
			warn("[CrateStage] cleanup:", v529)
		end
		local v530, v531 = pcall(function()
			-- upvalues: (copy) v_u_521
			if v_u_521 and v_u_521.animFn then
				v_u_521.animFn()
			end
		end)
		if not v530 then
			warn("[CrateStage] cleanup:", v531)
		end
		local function v532()
			-- upvalues: (ref) v_u_95, (ref) v_u_97
			v_u_95()
			v_u_97()
		end
		local v533, v534 = pcall(v532)
		if not v533 then
			warn("[CrateStage] cleanup:", v534)
		end
		local function v541()
			-- upvalues: (copy) p_u_519, (ref) v_u_32
			if p_u_519.musicGroup then
				local v535 = p_u_519.musicBase or 1
				local function v537()
					-- upvalues: (ref) v_u_32
					local v536 = v_u_32 and (v_u_32.controllers and v_u_32.controllers.Audio)
					if v536 then
						v536 = v_u_32.controllers.Audio.getVolume("Music")
					end
					return v536
				end
				local v538, v539 = pcall(v537)
				local v540 = p_u_519.musicGroup
				if v538 then
					if type(v539) ~= "number" then
						v539 = v535
					end
				else
					v539 = v535
				end
				v540.Volume = v539
			end
		end
		local v542, v543 = pcall(v541)
		if not v542 then
			warn("[CrateStage] cleanup:", v543)
		end
		local v544, v545 = pcall(function()
			-- upvalues: (copy) p_u_519
			if p_u_519.ui then
				p_u_519.ui:destroy()
			end
		end)
		if not v544 then
			warn("[CrateStage] cleanup:", v545)
		end
		local v546, v547 = pcall(function()
			-- upvalues: (copy) p_u_519
			if p_u_519.world then
				p_u_519.world:destroy()
			end
		end)
		if not v546 then
			warn("[CrateStage] cleanup:", v547)
		end
		local v548, v549 = pcall(function()
			-- upvalues: (copy) p_u_519
			if p_u_519.light then
				p_u_519.light:leave()
			end
		end)
		if not v548 then
			warn("[CrateStage] cleanup:", v549)
		end
		local v552, v553 = pcall(function()
			-- upvalues: (copy) p_u_519
			local v_u_550 = p_u_519.camSave
			if v_u_550 then
				if not v_u_550.cam then
					return
				end
				local v_u_551 = v_u_550.cam
				pcall(function()
					-- upvalues: (copy) v_u_551, (copy) v_u_550
					v_u_551.CameraType = v_u_550.type
					v_u_551.CFrame = v_u_550.cf
					v_u_551.FieldOfView = v_u_550.fov
					v_u_551.CameraSubject = v_u_550.subject
					v_u_551.Focus = v_u_550.focus
				end)
			end
		end)
		if not v552 then
			warn("[CrateStage] cleanup:", v553)
		end
		local function v554()
			-- upvalues: (ref) v_u_15
			v_u_15:SetAttribute("CrateStageOn", false)
		end
		local v555, v556 = pcall(v554)
		if not v555 then
			warn("[CrateStage] cleanup:", v556)
		end
		local function v557()
			-- upvalues: (ref) v_u_8
			if v_u_8.SelectedObject and not v_u_8.SelectedObject:IsDescendantOf(game) then
				v_u_8.SelectedObject = nil
			end
		end
		local v558, v559 = pcall(v557)
		if not v558 then
			warn("[CrateStage] cleanup:", v559)
		end
		local v560, v561 = pcall(function()
			-- upvalues: (copy) p_u_519
			p_u_519.after = p_u_519:_snapshot()
		end)
		if not v560 then
			warn("[CrateStage] cleanup:", v561)
		end
		if v_u_33 == p_u_519 then
			v_u_33 = nil
		end
		for _, v562 in p_u_519.doneCallbacks do
			task.defer(v562, v522)
		end
		if p_u_519.opts.onDone then
			task.defer(p_u_519.opts.onDone, v522)
		end
	end
end
function v_u_141.dump(p563) -- name: dump
	local v564 = p563.world and (p563.world:counts() or {
		["parts"] = 0,
		["lights"] = 0,
		["emitters"] = 0,
		["highlights"] = 0,
		["descendants"] = 0,
		["particles"] = 0
	}) or {
		["parts"] = 0,
		["lights"] = 0,
		["emitters"] = 0,
		["highlights"] = 0,
		["descendants"] = 0,
		["particles"] = 0
	}
	local v565 = p563.ui and (p563.ui:count() or 0) or 0
	local v566 = p563.run
	if v566 then
		v566 = p563.run.reelStat
	end
	local v567 = p563.run
	if v567 then
		v567 = p563.run.winStat
	end
	local v568 = "quality=%s parts=%d lights=%d emitters=%d highlights=%d particles=%d ui=%d buildMs=%.1f frames=%d avgMs=%.3f maxMs=%.3f state=%s u=%.2f reel=%s unloadedAtRoll=%s weapon=%s"
	local v569 = p563.quality
	local v570 = v564.parts
	local v571 = v564.lights
	local v572 = v564.emitters
	local v573 = v564.highlights
	local v574 = v564.particles
	local v575 = p563.buildMs or 0
	local v576 = p563.frames
	local v577 = p563.frames <= 0 and 0 or p563.frameSum / p563.frames
	local v578 = p563.frameMax
	local v579 = p563.state_
	local v580 = p563.lastU or 0
	local v581
	if v566 then
		local v582 = v566.warmed
		local v583 = v566.tiles
		local v584 = v566.assets
		local v585 = v566.capped
		v581 = ("%d/%d warmed assets %d capped %s %.0fms"):format(v582, v583, v584, tostring(v585), v566.ms)
	else
		v581 = "none"
	end
	local v586 = p563.run
	if v586 then
		v586 = p563.run.unloadedAtRoll
	end
	local v587 = tostring(v586)
	local v588
	if v567 then
		local v589 = v567.assets
		local v590 = v567.capped
		v588 = ("assets %d capped %s %.0fms"):format(v589, tostring(v590), v567.ms)
	else
		v588 = "none"
	end
	return v568:format(v569, v570, v571, v572, v573, v574, v565, v575, v576, v577, v578, v579, v580, v581, v587, v588)
end
function v_u_9.active() -- name: active
	-- upvalues: (ref) v_u_33
	return v_u_33
end
function v_u_9.abort(p591) -- name: abort
	-- upvalues: (ref) v_u_33
	if v_u_33 then
		v_u_33:stop(type(p591) ~= "string" and "abort" or p591)
	end
end
function v_u_9.play(p592, p593) -- name: play
	-- upvalues: (copy) v_u_9
	local v594 = v_u_9.begin
	local v595
	if p592 then
		v595 = p592.crate
	else
		v595 = p592
	end
	local v596 = v594(v595, p593)
	v596:resolve(p592)
	return v596
end
function v_u_9._demoResult(p597, _) -- name: _demoResult
	-- upvalues: (copy) v_u_18, (copy) v_u_12
	local v598 = nil
	local v599 = nil
	for _, v600 in v_u_18.LIST do
		if v600.rarity ~= p597 then
			continue
		end
		v599 = v600.crates[1]
		v598 = v600
	end
	local v601 = v598 or v_u_18.LIST[1]
	return {
		["crate"] = nil,
		["skin"] = nil,
		["rarity"] = nil,
		["dup"] = false,
		["seed"] = nil,
		["left"] = nil,
		["demo"] = true,
		["crate"] = v599 or "skin_crate_field",
		["skin"] = v601.id,
		["rarity"] = v601.rarity,
		["seed"] = v_u_12(os.clock() * 1000) % 100000 + 1,
		["left"] = {
			["crates"] = 1,
			["keys"] = 1
		}
	}
end
function v_u_9.demo(p602, p603, p604) -- name: demo
	-- upvalues: (copy) v_u_12, (copy) v_u_9
	local v605 = v_u_12(tonumber(p602) or 1)
	local v606 = math.clamp(v605, 1, 7)
	local v_u_607 = v_u_9._demoResult(v606)
	local v608 = table.clone(p604 or {})
	local v609 = v608.extra
	if type(v609) == "table" then
		for v610, v611 in v608.extra do
			v_u_607[v610] = v611
		end
	end
	v608.demo = true
	v608.quick = p603 == "quick"
	if p603 == "reduced" then
		v608.reduced = true
	end
	if v608.quick == false and (p603 ~= "normal" and p603 ~= nil) then
		v608.quick = nil
	end
	local v_u_612 = v_u_9.begin(v_u_607.crate, v608)
	task.delay(0.35, function()
		-- upvalues: (copy) v_u_612, (copy) v_u_607
		if v_u_612:isPlaying() then
			v_u_612:resolve(v_u_607)
		end
	end)
	return v_u_612
end
function v_u_9.init(p613) -- name: init
	-- upvalues: (ref) v_u_32, (ref) v_u_25, (copy) v_u_9, (copy) v_u_35, (ref) v_u_33
	v_u_32 = p613
	if p613 and p613.command then
		p613.command("crate.demo", function(p614)
			-- upvalues: (ref) v_u_25, (ref) v_u_9
			local function v615()
				-- upvalues: (ref) v_u_25
				return game:GetService("RunService"):IsStudio() or v_u_25.IS_TEST == true
			end
			local v616, v617 = pcall(v615)
			if v616 then
				v616 = v617 == true
			end
			if not v616 then
				return "not available"
			end
			local v618 = p614[3] == "tally" and {
				["tally"] = true,
				["uid"] = "S1-aaaaaaaaaaaaaaaa"
			} or (p614[3] == "tallydup" and {
				["tally"] = true,
				["uid"] = "S1-aaaaaaaaaaaaaaaa",
				["dup"] = true,
				["kept"] = true,
				["copies"] = 2,
				["total"] = 3
			} or nil)
			local v619 = v_u_9.demo
			local v620 = p614[1]
			return "demo started " .. v619(tonumber(v620) or 1, p614[2] or "normal", {
				["extra"] = v618
			}).crateId .. (v618 and " tally" or "")
		end)
		p613.command("crate.hold", function(p621)
			-- upvalues: (ref) v_u_35
			local v622 = v_u_35
			local v623 = p621[1]
			v622.hold = tonumber(v623)
			local v624 = v_u_35.hold
			return "hold " .. tostring(v624)
		end)
		p613.command("crate.loop", function(p625)
			-- upvalues: (ref) v_u_35
			local v626 = p625[1]
			local v627 = tonumber(v626)
			local v628 = p625[2]
			local v629 = tonumber(v628)
			v_u_35.loop = v627 and (v629 and v627 < v629) and { v627, v629 } or nil
			local v630 = "loop "
			local v631 = v_u_35.loop
			if v631 then
				v631 = v627 .. " " .. v629
			end
			return v630 .. tostring(v631)
		end)
		p613.command("crate.speed", function(p632)
			-- upvalues: (ref) v_u_35
			local v633 = v_u_35
			local v634 = p632[1]
			local v635 = tonumber(v634) or 1
			v633.speed = math.clamp(v635, 0.25, 4)
			return "speed " .. v_u_35.speed
		end)
		p613.command("crate.quality", function(p636)
			-- upvalues: (ref) v_u_35
			local v637 = v_u_35
			local v638
			if p636[1] == "high" or p636[1] == "low" then
				v638 = p636[1]
			else
				v638 = nil
			end
			v637.quality = v638
			local v639 = v_u_35.quality
			return "quality " .. tostring(v639)
		end)
		p613.command("crate.phone", function(p640)
			-- upvalues: (ref) v_u_35
			v_u_35.phone = p640[1] == "on"
			local v641 = v_u_35.phone
			return "phone " .. tostring(v641)
		end)
		p613.command("crate.reduced", function(p642)
			-- upvalues: (ref) v_u_35
			v_u_35.reduced = p642[1] == "on"
			local v643 = v_u_35.reduced
			return "reduced " .. tostring(v643)
		end)
		p613.command("crate.dump", function()
			-- upvalues: (ref) v_u_33
			return not v_u_33 and "no stage" or v_u_33:dump()
		end)
		p613.command("crate.sounds", function()
			-- upvalues: (ref) v_u_9
			return v_u_9.soundReport()
		end)
		p613.command("crate.skip", function()
			-- upvalues: (ref) v_u_33
			local v644 = v_u_33
			if v644 then
				v644 = v_u_33:skip("cmd")
			end
			return tostring(v644)
		end)
		p613.command("crate.stop", function()
			-- upvalues: (ref) v_u_9
			v_u_9.abort("cmd")
			return "stopped"
		end)
	end
end
return v_u_9