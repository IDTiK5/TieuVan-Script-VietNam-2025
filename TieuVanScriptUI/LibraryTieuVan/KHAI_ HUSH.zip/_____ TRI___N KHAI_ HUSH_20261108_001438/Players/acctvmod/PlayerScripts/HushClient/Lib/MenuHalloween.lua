-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuHalloween

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
v_u_4.__index = v_u_4
v_u_4.FLAG = "HalloweenLobby"
v_u_4.MAX_PARTS = 300
v_u_4.MODEL_PARTS = 100
v_u_4.BASE_PARTS = 271
v_u_4.PUMPKIN_PARTS = 12
v_u_4.GRAVE_PARTS = 2
v_u_4.MAX_LIGHTS = 12
v_u_4.FOLDER = "Halloween"
v_u_4.TINT = "HalloweenTint"
local v_u_5 = math.rad
local v_u_6 = nil
local v_u_7 = {
	["pumpkin"] = Color3.fromHex("#D4662A"),
	["rib"] = Color3.fromHex("#BB5521"),
	["stem"] = Color3.fromHex("#4B4A2A"),
	["glow"] = Color3.fromHex("#FFA445"),
	["orange"] = Color3.fromHex("#FF8A2B"),
	["violet"] = Color3.fromHex("#9A7BE6"),
	["wire"] = Color3.fromHex("#17181B"),
	["web"] = Color3.fromHex("#D8D5E2"),
	["bat"] = Color3.fromHex("#0B0B0F"),
	["wax"] = Color3.fromHex("#CFC7B0"),
	["hay"] = Color3.fromHex("#8E7640"),
	["strap"] = Color3.fromHex("#4A3A22"),
	["ghost"] = Color3.fromHex("#CFC4F2"),
	["stone"] = Color3.fromHex("#5E6166"),
	["eye"] = Color3.fromHex("#15131C"),
	["leaf"] = {
		Color3.fromHex("#A5521E"),
		Color3.fromHex("#8A3F17"),
		Color3.fromHex("#C2742B"),
		Color3.fromHex("#6F4A1A"),
		Color3.fromHex("#7E5A22")
	},
	["tint"] = Color3.fromRGB(255, 238, 250)
}
v_u_4.SLOTS = {
	Vector3.new(0, 0, 0),
	Vector3.new(3.8, 0, -0.9),
	Vector3.new(-2.9, 0, -2.3),
	Vector3.new(7.5, 0, -1.7)
}
v_u_4.KEEP_OUT = 4.4
v_u_4.LEAF_FREE = {
	["x0"] = -8.5,
	["x1"] = 12.5,
	["z0"] = -4.5,
	["z1"] = 12
}
v_u_4.PUMPKINS = {
	{
		["id"] = "hayTop",
		["x"] = -9.8,
		["z"] = 0.2,
		["y"] = 1.7,
		["r"] = 0.6,
		["lowKeep"] = false
	},
	{
		["id"] = "curb",
		["x"] = -7.8,
		["z"] = -2.4,
		["y"] = 0.55,
		["r"] = 0.85,
		["lowKeep"] = true
	},
	{
		["id"] = "hayFront",
		["x"] = -7.6,
		["z"] = 1.7,
		["y"] = 0.5,
		["r"] = 0.7,
		["lowKeep"] = false
	},
	{
		["id"] = "walk",
		["x"] = -2.9,
		["z"] = 3.7,
		["y"] = 0.5,
		["r"] = 0.65,
		["lowKeep"] = true
	},
	{
		["id"] = "taxi",
		["x"] = 15.6,
		["z"] = -0.3,
		["y"] = 0.5,
		["r"] = 0.8,
		["lowKeep"] = true
	},
	{
		["id"] = "jersey",
		["x"] = 24,
		["z"] = -12,
		["y"] = 3.2,
		["r"] = 0.7,
		["on"] = "JerseyBarrier",
		["lowKeep"] = false
	}
}
v_u_4.HAY = Vector3.new(-9.6, 0.5, 0.2)
v_u_4.CANDLES = Vector3.new(-8.9, 0.5, 2.5)
v_u_4.GARLANDS = {
	{
		["a"] = Vector3.new(-4.4, 17.4, -3.6),
		["b"] = Vector3.new(-30, 17, -28.9),
		["sag"] = 1.6,
		["n"] = 14,
		["light"] = 0.3
	},
	{
		["a"] = Vector3.new(19.4, 8.6, 0.7),
		["b"] = Vector3.new(24, 3.3, -7.9),
		["sag"] = 0.9,
		["n"] = 8,
		["light"] = nil
	}
}
v_u_4.BATS = {
	{
		["cx"] = -26,
		["cy"] = 58,
		["cz"] = -96,
		["rx"] = 17,
		["rz"] = 8,
		["w"] = 0.36,
		["ph"] = 0,
		["bob"] = 1.6,
		["flap"] = 2.6
	},
	{
		["cx"] = -8,
		["cy"] = 60,
		["cz"] = -120,
		["rx"] = 13,
		["rz"] = 6,
		["w"] = -0.42,
		["ph"] = 2.1,
		["bob"] = 1.2,
		["flap"] = 3
	},
	{
		["cx"] = 14,
		["cy"] = 64,
		["cz"] = -140,
		["rx"] = 20,
		["rz"] = 9,
		["w"] = 0.3,
		["ph"] = 4,
		["bob"] = 2,
		["flap"] = 2.4
	},
	{
		["cx"] = -44,
		["cy"] = 50,
		["cz"] = -84,
		["rx"] = 9,
		["rz"] = 5,
		["w"] = -0.5,
		["ph"] = 1,
		["bob"] = 1,
		["flap"] = 3.2
	},
	{
		["cx"] = 34,
		["cy"] = 58,
		["cz"] = -110,
		["rx"] = 12,
		["rz"] = 6,
		["w"] = 0.4,
		["ph"] = 5.2,
		["bob"] = 1.4,
		["flap"] = 2.8
	}
}
v_u_4.GHOST = Vector3.new(-42, 33, -47)
v_u_4.FLAG2 = "LobbyHalloween2"
v_u_4.POLE_Z = -38
v_u_4.POLE_TOP = 25
v_u_4.GARLANDS2 = {
	{
		["id"] = "lampToPole",
		["a"] = Vector3.new(-4.4, 17.4, -3.6),
		["b"] = Vector3.new(-2, 24.5, -37.4),
		["bPole"] = -2,
		["sag"] = 3,
		["n"] = 18,
		["light"] = 0.5
	},
	{
		["id"] = "poleToPole",
		["a"] = Vector3.new(-2, 24.5, -38),
		["b"] = Vector3.new(44, 24.5, -38),
		["aPole"] = -2,
		["bPole"] = 44,
		["sag"] = 5.5,
		["n"] = 22,
		["light"] = 0.5
	}
}
v_u_4.GHOST_FIRST = { 30, 90 }
v_u_4.GHOST_EVERY = { 120, 240 }
v_u_4.GHOST_TIME = { 3, 6 }
v_u_4.GHOST_FLY = {
	["depth"] = 30,
	["height"] = 11,
	["scale"] = 1.6,
	["range"] = 26,
	["fade"] = 0.2,
	["bob"] = 0.5,
	["bobHz"] = 0.9,
	["lean"] = 16,
	["yaw"] = 25,
	["trail"] = 0.5,
	["half"] = 2.6
}
v_u_4.GHOST_ON = false
v_u_4.PUMPKIN_ASSET = {
	["S"] = "Pumpkin_S",
	["M"] = "Pumpkin_M",
	["L"] = "Pumpkin_L"
}
v_u_4.BARRICADE_ASSET = "Barricade_Police"
v_u_4.BARRICADE_SCALE = 0.8
v_u_4.PROP_SLOTS = {
	{
		["id"] = "grave1",
		["asset"] = "Gravestone_Cross",
		["at"] = Vector3.new(-17.2, 0.5, -33.6),
		["yaw"] = 12,
		["grave"] = nil,
		["grave"] = { 1.5, 2.1 }
	},
	{
		["id"] = "grave2",
		["asset"] = "Gravestone_Round",
		["at"] = Vector3.new(-19.6, 0.5, -34.6),
		["yaw"] = -9,
		["grave"] = nil,
		["grave"] = { 1.3, 1.7 }
	},
	{
		["id"] = "grave3",
		["asset"] = "Gravestone_Slab",
		["at"] = Vector3.new(-14.8, 0.5, -34.8),
		["yaw"] = 20,
		["grave"] = nil,
		["grave"] = { 1.7, 1.4 }
	},
	{
		["id"] = "scarecrow",
		["asset"] = "Scarecrow",
		["at"] = Vector3.new(-24.6, 0.5, -33.8),
		["yaw"] = 15
	},
	{
		["id"] = "cauldron",
		["asset"] = "Cauldron",
		["at"] = Vector3.new(18.5, 0.5, 4.2),
		["yaw"] = -20
	},
	{
		["id"] = "candles",
		["asset"] = "CandleCluster",
		["at"] = Vector3.new(14.6, 0.5, 3.4),
		["yaw"] = 0
	},
	{
		["id"] = "sign",
		["asset"] = "Sign_Beware",
		["at"] = Vector3.new(-18, 0.4, -3),
		["yaw"] = 25
	},
	{
		["id"] = "deadtree",
		["asset"] = "DeadTree",
		["at"] = Vector3.new(9.8, 0.5, -33.8),
		["yaw"] = 30,
		["scale"] = 1.7,
		["low"] = true
	},
	{
		["id"] = "hay2",
		["asset"] = "HayBale_Square",
		["at"] = Vector3.new(-28, 0.5, -34),
		["yaw"] = -10,
		["low"] = true,
		["pumpkin"] = nil,
		["pumpkin"] = {
			["r"] = 0.7,
			["dx"] = 0.2,
			["dz"] = 0
		}
	},
	{
		["id"] = "skulls",
		["asset"] = "SkullPile",
		["at"] = Vector3.new(-21.8, 0.5, -33),
		["yaw"] = 15,
		["low"] = true
	},
	{
		["id"] = "coffin",
		["asset"] = "Coffin",
		["at"] = Vector3.new(-12.5, 0.5, -34.5),
		["yaw"] = 80,
		["low"] = true
	}
}
local function v_u_15(p8, p9) -- name: poleTopY
	-- upvalues: (copy) v_u_4
	local v10 = p8.origin
	local v11 = p8.root
	if v11 then
		v11 = p8.root:FindFirstChild("Town")
	end
	if v11 then
		for _, v12 in v11:GetChildren() do
			if v12.Name ~= "WireAnchor" or not v12:IsA("BasePart") then
				continue
			end
			local v13 = v12.Position.X - (v10.X + p9)
			if math.abs(v13) >= 2 then
				continue
			end
			local v14 = v12.Position.Z - (v10.Z + v_u_4.POLE_Z)
			if math.abs(v14) >= 4 then
				continue
			end
			return v12.Position.Y - v10.Y
		end
	end
	return v_u_4.POLE_TOP
end
local function v_u_26(p16, p17) -- name: resolveGarland
	-- upvalues: (copy) v_u_15
	local v18 = p17.a
	local v19 = p17.b
	if p17.aPole then
		local v20 = p17.aPole
		local v21 = v_u_15(p16, p17.aPole) - 0.5
		local v22 = v18.Z
		v18 = Vector3.new(v20, v21, v22)
	end
	if p17.bPole then
		local v23 = p17.bPole
		local v24 = v_u_15(p16, p17.bPole) - 0.5
		local v25 = v19.Z
		v19 = Vector3.new(v23, v24, v25)
	end
	return {
		["id"] = nil,
		["a"] = nil,
		["b"] = nil,
		["sag"] = nil,
		["n"] = nil,
		["light"] = nil,
		["one"] = true,
		["id"] = p17.id,
		["a"] = v18,
		["b"] = v19,
		["sag"] = p17.sag,
		["n"] = p17.n,
		["light"] = p17.light
	}
end
local function v_u_35(p27, p28, p29) -- name: fitsBudget
	-- upvalues: (copy) v_u_4
	local v30 = 0
	for _, v31 in p28:GetDescendants() do
		if not v31:IsA("BasePart") then
			continue
		end
		v30 = v30 + 1
	end
	local v32 = p27.modelN or 0
	local v33 = p27.net or v_u_4.BASE_PARTS
	local v34 = v30 - (p29 or 0)
	if v32 + v30 > v_u_4.MODEL_PARTS or v33 + v34 > v_u_4.MAX_PARTS then
		p28:Destroy()
		return false
	end
	p27.modelN = v32 + v30
	p27.net = v33 + v34
	return true
end
local function v_u_44(p_u_36, p_u_37) -- name: importedProp
	local v39, v40 = pcall(function()
		-- upvalues: (copy) p_u_36, (copy) p_u_37
		local v38 = p_u_36.cctx.shared.Assets
		if v38.hasImported("Prop", p_u_37) then
			return v38.get("Prop", p_u_37)
		else
			return nil
		end
	end)
	if not v39 or (typeof(v40) ~= "Instance" or not v40:IsA("Model")) then
		return nil
	end
	local v41 = v40:FindFirstChild("Collision")
	if v41 and (v41:IsA("BasePart") and v41.Transparency >= 1) then
		local v42 = v40:GetPivot()
		v41:Destroy()
		v40.PrimaryPart = nil
		v40.WorldPivot = v42
	end
	for _, v43 in v40:GetDescendants() do
		if v43:IsA("BasePart") then
			v43.Anchored = true
			v43.CanCollide = false
			v43.CanTouch = false
			v43.CanQuery = false
			v43.CastShadow = false
		else
			if not (v43:IsA("Script") or (v43:IsA("LocalScript") or v43:IsA("ProximityPrompt"))) then
				continue
			end
			v43:Destroy()
		end
	end
	return v40
end
local function v_u_54(p45, p46, p47, p48, p49, p50, p51, p52) -- name: newPart
	local v53 = Instance.new("Part")
	v53.Name = p47
	v53.Anchored = true
	v53.CanCollide = false
	v53.CanTouch = false
	v53.CanQuery = false
	v53.CastShadow = false
	v53.TopSurface = Enum.SurfaceType.Smooth
	v53.BottomSurface = Enum.SurfaceType.Smooth
	v53.Size = p48
	v53.CFrame = p49
	v53.Color = p50
	v53.Material = p51
	if p52 then
		v53.Transparency = p52
	end
	v53.Parent = p46
	p45.n = p45.n + 1
	return v53
end
local function v_u_64(p55, p56, p57, p58, p59, p60, p61, p62) -- name: wedge
	local v63 = Instance.new("WedgePart")
	v63.Name = p57
	v63.Anchored = true
	v63.CanCollide = false
	v63.CanTouch = false
	v63.CanQuery = false
	v63.CastShadow = false
	v63.TopSurface = Enum.SurfaceType.Smooth
	v63.BottomSurface = Enum.SurfaceType.Smooth
	v63.Size = p58
	v63.CFrame = p59
	v63.Color = p60
	v63.Material = p61
	if p62 then
		v63.Transparency = p62
	end
	v63.Parent = p56
	p55.n = p55.n + 1
	return v63
end
local function v_u_75(p65, p66, p67, p68, p69, p70, p71) -- name: addLight
	if p65.low and not p70 then
		return nil
	end
	local v72 = Instance.new("PointLight")
	v72.Name = "HalloweenLight"
	v72.Color = p67
	v72.Brightness = p68
	v72.Range = p69
	v72.Shadows = false
	v72.Parent = p66
	local v73 = p65.lights
	local v74 = {
		["light"] = v72,
		["base"] = p68,
		["phase"] = #p65.lights * 1.37,
		["speed"] = p71
	}
	table.insert(v73, v74)
	return v72
end
local function v_u_92(p76, p_u_77, p_u_78, p_u_79, p80) -- name: probeY
	-- upvalues: (copy) v_u_3
	if p76 and v_u_3:IsRunning() then
		local v81 = {}
		local v82 = {}
		for _, v83 in p76:GetDescendants() do
			if not v83:IsA("BasePart") or v83.Transparency >= 0.9 then
				continue
			end
			table.insert(v81, v83)
			v82[v83] = v83.CanQuery
			v83.CanQuery = true
		end
		local v_u_84 = RaycastParams.new()
		v_u_84.FilterType = Enum.RaycastFilterType.Include
		v_u_84.FilterDescendantsInstances = v81
		local v88, v89 = pcall(function()
			-- upvalues: (copy) p_u_77, (copy) p_u_79, (copy) p_u_78, (copy) v_u_84
			local v85 = p_u_77
			local v86 = p_u_79
			local v87 = p_u_78
			return workspace:Raycast(Vector3.new(v85, v86, v87), Vector3.new(0, -20, 0), v_u_84)
		end)
		for v90, v91 in v82 do
			v90.CanQuery = v91
		end
		if v88 and v89 then
			return v89.Position.Y
		else
			return p80
		end
	else
		return p80
	end
end
local function v_u_101(p93, p94, p95) -- name: findModel
	local v96 = p93.origin
	local v97 = (1 / 0)
	local v98 = nil
	for _, v99 in p93.root:GetChildren() do
		if not v99:IsA("Model") or v99.Name ~= p94 then
			continue
		end
		local v100 = not p95 and 0 or (v99:GetPivot().Position - (v96 + p95)).Magnitude
		if v100 >= v97 then
			continue
		end
		v98 = v99
		v97 = v100
	end
	return v98
end
local function v_u_186(p102, p103, p104, p105) -- name: pumpkin
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_75
	local v106 = Instance.new("Model")
	v106.Name = "Pumpkin_" .. p104.id
	local v107 = p104.r
	local v108 = p104.r * 0.8
	local v109 = v108 - 0.04
	local v110 = p105 + Vector3.new(0, v109, 0)
	local v111 = 10 - (p105.X - p102.origin.X)
	local v112 = 34 - (p105.Z - p102.origin.Z)
	local v113 = Vector3.new(v111, 0, v112)
	local v114 = CFrame.lookAt(v110, v110 + v113)
	local v115 = v107 * 2
	local v116 = v108 * 2
	local v117 = v107 * 2
	local v118 = Vector3.new(v115, v116, v117)
	local v119 = v_u_7.pumpkin
	local v120 = Enum.Material.Plastic
	local v121 = Instance.new("Part")
	v121.Name = "Body"
	v121.Anchored = true
	v121.CanCollide = false
	v121.CanTouch = false
	v121.CanQuery = false
	v121.CastShadow = false
	v121.TopSurface = Enum.SurfaceType.Smooth
	v121.BottomSurface = Enum.SurfaceType.Smooth
	v121.Size = v118
	v121.CFrame = v114
	v121.Color = v119
	v121.Material = v120
	v121.Parent = v106
	p102.n = p102.n + 1
	local v122 = Instance.new("SpecialMesh")
	v122.MeshType = Enum.MeshType.Sphere
	v122.Parent = v121
	for v123, v124 in { 58, -58 } do
		local v125 = v107 * 2 * 0.97
		local v126 = v108 * 2 * 0.97
		local v127 = v107 * 2 * 0.62
		local v128 = Vector3.new(v125, v126, v127)
		local v129 = v114 * CFrame.Angles(0, v_u_5(v124), 0)
		local v130 = v_u_7.rib
		local v131 = Enum.Material.Plastic
		local v132 = Instance.new("Part")
		v132.Name = "Rib"
		v132.Anchored = true
		v132.CanCollide = false
		v132.CanTouch = false
		v132.CanQuery = false
		v132.CastShadow = false
		v132.TopSurface = Enum.SurfaceType.Smooth
		v132.BottomSurface = Enum.SurfaceType.Smooth
		v132.Size = v128
		v132.CFrame = v129
		v132.Color = v130
		v132.Material = v131
		v132.Parent = v106
		p102.n = p102.n + 1
		local v133 = Instance.new("SpecialMesh")
		v133.MeshType = Enum.MeshType.Sphere
		v133.Parent = v132
		v132.Name = "Rib" .. v123
	end
	local v134 = v107 * 0.34
	local v135 = v107 * 0.24
	local v136 = v107 * 0.24
	local v137 = Vector3.new(v134, v135, v136)
	local v138 = v114 * CFrame.new(0, v108 * 0.98, v107 * 0.04) * CFrame.Angles(0.12217304763960307, 0, 1.710422666954443)
	local v139 = v_u_7.stem
	local v140 = Enum.Material.Wood
	local v141 = Instance.new("Part")
	v141.Name = "Stem"
	v141.Anchored = true
	v141.CanCollide = false
	v141.CanTouch = false
	v141.CanQuery = false
	v141.CastShadow = false
	v141.TopSurface = Enum.SurfaceType.Smooth
	v141.BottomSurface = Enum.SurfaceType.Smooth
	v141.Size = v137
	v141.CFrame = v138
	v141.Color = v139
	v141.Material = v140
	v141.Parent = v106
	p102.n = p102.n + 1
	v141.Shape = Enum.PartType.Cylinder
	for _, v142 in { -1, 1 } do
		local v143 = v142 * 0.36 * v107
		local v144 = v108 * 0.2
		local v145 = v107 * 0.1
		local v146 = v108 * 0.3
		local v147 = v107 * 0.3
		local v148 = Vector3.new(v145, v146, v147)
		local v149 = CFrame.new
		local v150 = 1 - (v143 / v107) ^ 2 - (v144 / v108) ^ 2
		local v151 = -v107
		local v152 = math.max(0.04, v150)
		local v153 = v114 * v149(v143, v144, v151 * math.sqrt(v152) + 0.03) * CFrame.Angles(0, v_u_5(-90 * v142), 0)
		local v154 = v_u_7.glow
		local v155 = Enum.Material.Neon
		local v156 = Instance.new("WedgePart")
		v156.Name = "Eye"
		v156.Anchored = true
		v156.CanCollide = false
		v156.CanTouch = false
		v156.CanQuery = false
		v156.CastShadow = false
		v156.TopSurface = Enum.SurfaceType.Smooth
		v156.BottomSurface = Enum.SurfaceType.Smooth
		v156.Size = v148
		v156.CFrame = v153
		v156.Color = v154
		v156.Material = v155
		v156.Parent = v106
		p102.n = p102.n + 1
	end
	local v157 = v107 * 0.17
	local v158 = v107 * 0.17
	local v159 = v107 * 0.1
	local v160 = Vector3.new(v157, v158, v159)
	local v161 = CFrame.new
	local v162 = v108 * -0.04
	local v163 = v108 * -0.04
	local v164 = 1 - (0 / v107) ^ 2 - (v163 / v108) ^ 2
	local v165 = -v107
	local v166 = math.max(0.04, v164)
	local v167 = v114 * v161(0, v162, v165 * math.sqrt(v166) + 0.03) * CFrame.Angles(0, 0, 0.7853981633974483)
	local v168 = v_u_7.glow
	local v169 = Enum.Material.Neon
	local v170 = Instance.new("Part")
	v170.Name = "Nose"
	v170.Anchored = true
	v170.CanCollide = false
	v170.CanTouch = false
	v170.CanQuery = false
	v170.CastShadow = false
	v170.TopSurface = Enum.SurfaceType.Smooth
	v170.BottomSurface = Enum.SurfaceType.Smooth
	v170.Size = v160
	v170.CFrame = v167
	v170.Color = v168
	v170.Material = v169
	v170.Parent = v106
	p102.n = p102.n + 1
	for v171 = -2, 2 do
		local v172 = v171 * 0.2 * v107
		local v173 = v108 * -0.28 - v108 * 0.12 * (1 - (v171 / 2) ^ 2)
		local v174 = v107 * 0.15
		local v175 = v108 * 0.17
		local v176 = v107 * 0.1
		local v177 = Vector3.new(v174, v175, v176)
		local v178 = CFrame.new
		local v179 = 1 - (v172 / v107) ^ 2 - (v173 / v108) ^ 2
		local v180 = -v107
		local v181 = math.max(0.04, v179)
		local v182 = v114 * v178(v172, v173, v180 * math.sqrt(v181) + 0.03) * CFrame.Angles(0, 0, (v_u_5(v171 * 9)))
		local v183 = v_u_7.glow
		local v184 = Enum.Material.Neon
		local v185 = Instance.new("Part")
		v185.Name = "Tooth"
		v185.Anchored = true
		v185.CanCollide = false
		v185.CanTouch = false
		v185.CanQuery = false
		v185.CastShadow = false
		v185.TopSurface = Enum.SurfaceType.Smooth
		v185.BottomSurface = Enum.SurfaceType.Smooth
		v185.Size = v177
		v185.CFrame = v182
		v185.Color = v183
		v185.Material = v184
		v185.Parent = v106
		p102.n = p102.n + 1
	end
	v_u_75(p102, v170, v_u_7.glow, 0.85, 8, p104.lowKeep, #p102.lights % 3 * 0.7 + 2.3)
	v106.Parent = p103
end
local function v_u_216(p187, p188, p189, p190, p191) -- name: garland
	-- upvalues: (copy) v_u_7, (copy) v_u_75
	local v192 = Instance.new("Model")
	v192.Name = "StringLights" .. p190
	local v193 = p187.origin
	local v194 = p189.a:Lerp(p189.b, 0)
	local v195 = p189.sag * 4 * 0 * 1
	local v196 = v193 + (v194 - Vector3.new(0, v195, 0))
	for v197 = 1, p189.n + 1 do
		local v198 = v197 / (p189.n + 1)
		local v199 = p189.a:Lerp(p189.b, v198)
		local v200 = p189.sag * 4 * v198 * (1 - v198)
		local v201 = v193 + (v199 - Vector3.new(0, v200, 0))
		local v202 = v_u_7.wire
		local v203 = Enum.Material.Metal
		local v204 = (v201 - v196).Magnitude
		local v205 = math.max(0.02, v204)
		local v206 = Vector3.new(0.07, 0.07, v205)
		local v207 = CFrame.lookAt((v196 + v201) / 2, v201)
		local v208 = Instance.new("Part")
		v208.Name = "Wire"
		v208.Anchored = true
		v208.CanCollide = false
		v208.CanTouch = false
		v208.CanQuery = false
		v208.CastShadow = false
		v208.TopSurface = Enum.SurfaceType.Smooth
		v208.BottomSurface = Enum.SurfaceType.Smooth
		v208.Size = v206
		v208.CFrame = v207
		v208.Color = v202
		v208.Material = v203
		v208.Parent = v192
		p187.n = p187.n + 1
		if v197 <= p189.n then
			local v209
			if v197 % 2 == 1 then
				v209 = v_u_7.orange
			else
				v209 = v_u_7.violet
			end
			local v210 = CFrame.new(v201 - Vector3.new(0, 0.24, 0))
			local v211 = Enum.Material.Neon
			local v212 = Instance.new("Part")
			v212.Name = "Bulb"
			v212.Anchored = true
			v212.CanCollide = false
			v212.CanTouch = false
			v212.CanQuery = false
			v212.CastShadow = false
			v212.TopSurface = Enum.SurfaceType.Smooth
			v212.BottomSurface = Enum.SurfaceType.Smooth
			v212.Size = Vector3.new(0.42, 0.42, 0.42)
			v212.CFrame = v210
			v212.Color = v209
			v212.Material = v211
			v212.Parent = v192
			p187.n = p187.n + 1
			v212.Shape = Enum.PartType.Ball
			local v213 = {
				["part"] = v212,
				["phase"] = v197 * 0.9 + p190
			}
			table.insert(p191, v213)
			local v214
			if p189.light then
				local v215 = (p189.n + 1) * 0.35
				if v197 == math.floor(v215) then
					v_u_75(p187, v212, v_u_7.orange, 0.4, 11, true, 1.1)
					v196 = v201
				elseif p189.light and not p189.one then
					v214 = (p189.n + 1) * 0.7
					if v197 == math.floor(v214) then
						v_u_75(p187, v212, v_u_7.violet, 0.35, 11, false, 1.3)
						v196 = v201
					else
						v196 = v201
					end
				else
					v196 = v201
				end
			elseif p189.light and not p189.one then
				v214 = (p189.n + 1) * 0.7
				if v197 == math.floor(v214) then
					v_u_75(p187, v212, v_u_7.violet, 0.35, 11, false, 1.3)
					v196 = v201
				else
					v196 = v201
				end
			else
				v196 = v201
			end
		else
			v196 = v201
		end
	end
	v192.Parent = p188
end
local function v_u_247(p217, p218, p219, p220, p221, p222, p223) -- name: web
	-- upvalues: (copy) v_u_64, (copy) v_u_7, (copy) v_u_54
	local v224 = Instance.new("Model")
	v224.Name = p219
	local v225 = p221:Cross(p222)
	local v226 = CFrame.fromMatrix(p220 + p222 * (p223 / 2) + p221 * (p223 / 2), v225, p222, -p221)
	v_u_64(p217, v224, "Sheet", Vector3.new(0.03, p223, p223), v226, v_u_7.web, Enum.Material.SmoothPlastic, 0.8)
	local v227 = (p221 + p222).Unit
	for v228, v229 in { p221, v227, p222 } do
		local v230 = "Strand" .. v228
		local v231 = p220 + v229 * p223 * (v229 == v227 and 0.9 or 1)
		local v232 = v_u_7.web
		local v233 = Enum.Material.SmoothPlastic
		local v234 = (v231 - p220).Magnitude
		local v235 = v_u_54
		local v236 = math.max(0.02, v234)
		v235(p217, v224, v230, Vector3.new(0.05, 0.05, v236), CFrame.lookAt((p220 + v231) / 2, v231), v232, v233, 0.35)
	end
	for v237, v238 in { 0.5, 0.8 } do
		local v239 = "Chord" .. v237
		local v240 = p220 + p221 * p223 * v238
		local v241 = p220 + p222 * p223 * v238
		local v242 = v_u_7.web
		local v243 = Enum.Material.SmoothPlastic
		local v244 = (v241 - v240).Magnitude
		local v245 = v_u_54
		local v246 = math.max(0.02, v244)
		v245(p217, v224, v239, Vector3.new(0.04, 0.04, v246), CFrame.lookAt((v240 + v241) / 2, v241), v242, v243, 0.45)
	end
	v224.Parent = p218
end
local function v_u_272(p248, p249, p250, p251) -- name: candles
	-- upvalues: (copy) v_u_7, (copy) v_u_75
	local v252 = Instance.new("Model")
	v252.Name = "Candles"
	for v253, v254 in {
		{ 0, 0, 0.9 },
		{ 0.55, 0.3, 0.65 },
		{ -0.45, 0.4, 0.5 }
	} do
		local v255 = v254[1]
		local v256 = v254[2]
		local v257 = p250 + Vector3.new(v255, 0, v256)
		local v258 = v254[3]
		local v259 = Vector3.new(v258, 0.3, 0.3)
		local v260 = CFrame.new
		local v261 = v258 / 2
		local v262 = v260(v257 + Vector3.new(0, v261, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
		local v263 = v_u_7.wax
		local v264 = Enum.Material.Plastic
		local v265 = Instance.new("Part")
		v265.Name = "Wax"
		v265.Anchored = true
		v265.CanCollide = false
		v265.CanTouch = false
		v265.CanQuery = false
		v265.CastShadow = false
		v265.TopSurface = Enum.SurfaceType.Smooth
		v265.BottomSurface = Enum.SurfaceType.Smooth
		v265.Size = v259
		v265.CFrame = v262
		v265.Color = v263
		v265.Material = v264
		v265.Parent = v252
		p248.n = p248.n + 1
		v265.Shape = Enum.PartType.Cylinder
		local v266 = CFrame.new
		local v267 = v258 + 0.1
		local v268 = v266(v257 + Vector3.new(0, v267, 0))
		local v269 = v_u_7.glow
		local v270 = Enum.Material.Neon
		local v271 = Instance.new("Part")
		v271.Name = "Flame"
		v271.Anchored = true
		v271.CanCollide = false
		v271.CanTouch = false
		v271.CanQuery = false
		v271.CastShadow = false
		v271.TopSurface = Enum.SurfaceType.Smooth
		v271.BottomSurface = Enum.SurfaceType.Smooth
		v271.Size = Vector3.new(0.15, 0.22, 0.15)
		v271.CFrame = v268
		v271.Color = v269
		v271.Material = v270
		v271.Parent = v252
		p248.n = p248.n + 1
		v271.Shape = Enum.PartType.Ball
		if v253 ~= 1 then
			continue
		end
		v_u_75(p248, v271, v_u_7.glow, 0.6, 7, p251, 3.1)
	end
	v252.Parent = p249
end
local function v_u_287(p273, p274, p275, p276) -- name: hay
	-- upvalues: (copy) v_u_7
	local v277 = Instance.new("Model")
	v277.Name = "HayBale"
	local v278 = CFrame.new(p275 + Vector3.new(0, 0.6, 0)) * CFrame.Angles(0, p276, 0)
	local v279 = v_u_7.hay
	local v280 = Enum.Material.Fabric
	local v281 = Instance.new("Part")
	v281.Name = "Bale"
	v281.Anchored = true
	v281.CanCollide = false
	v281.CanTouch = false
	v281.CanQuery = false
	v281.CastShadow = false
	v281.TopSurface = Enum.SurfaceType.Smooth
	v281.BottomSurface = Enum.SurfaceType.Smooth
	v281.Size = Vector3.new(2.4, 1.2, 1.2)
	v281.CFrame = v278
	v281.Color = v279
	v281.Material = v280
	v281.Parent = v277
	p273.n = p273.n + 1
	for _, v282 in { -0.6, 0.6 } do
		local v283 = v278 * CFrame.new(v282, 0, 0)
		local v284 = v_u_7.strap
		local v285 = Enum.Material.Fabric
		local v286 = Instance.new("Part")
		v286.Name = "Strap"
		v286.Anchored = true
		v286.CanCollide = false
		v286.CanTouch = false
		v286.CanQuery = false
		v286.CastShadow = false
		v286.TopSurface = Enum.SurfaceType.Smooth
		v286.BottomSurface = Enum.SurfaceType.Smooth
		v286.Size = Vector3.new(0.12, 1.24, 1.24)
		v286.CFrame = v283
		v286.Color = v284
		v286.Material = v285
		v286.Parent = v277
		p273.n = p273.n + 1
	end
	v277.Parent = p274
end
local function v_u_325(p288, p289, p290, p291) -- name: ghost
	-- upvalues: (copy) v_u_54, (copy) v_u_5, (copy) v_u_7, (copy) v_u_75
	local v292 = Instance.new("Model")
	v292.Name = "Ghost"
	if not p291 then
		for v293, v294 in {
			{ 0, 2.6, 0.8 },
			{ 0.8, 2.2, 0.8 },
			{ 1.6, 1.8, 0.8 },
			{ 2.4, 1.4, 0.8 }
		} do
			local v295 = v_u_54
			local v296 = "Body" .. v293
			local v297 = v294[3]
			local v298 = v294[2]
			local v299 = v294[2]
			local v300 = Vector3.new(v297, v298, v299)
			local v301 = CFrame.new
			local v302 = v294[1] + 0.4
			v295(p288, v292, v296, v300, v301(p290 + Vector3.new(0, v302, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_7.ghost, Enum.Material.Neon, 0.55).Shape = Enum.PartType.Cylinder
		end
		local v303 = v_u_54(p288, v292, "Head", Vector3.new(1.5, 1.5, 1.5), CFrame.new(p290 + Vector3.new(0, 3.5, 0)), v_u_7.ghost, Enum.Material.Neon, 0.5)
		v303.Shape = Enum.PartType.Ball
		for _, v304 in { -1, 1 } do
			local v305 = v_u_54
			local v306 = CFrame.new
			local v307 = v304 * 0.3
			v305(p288, v292, "Eye", Vector3.new(0.28, 0.4, 0.14), v306(p290 + Vector3.new(v307, 3.6, 0.68)), v_u_7.eye, Enum.Material.SmoothPlastic, 0.1).Shape = Enum.PartType.Ball
		end
		v_u_54(p288, v292, "Mouth", Vector3.new(0.3, 0.38, 0.14), CFrame.new(p290 + Vector3.new(0, 3.1, 0.66)), v_u_7.eye, Enum.Material.SmoothPlastic, 0.1).Shape = Enum.PartType.Ball
		v_u_75(p288, v303, v_u_7.violet, 0.7, p291 or 42, false, 0.4)
		v292.Parent = p289
		return v292
	end
	local v308 = Color3.fromHex("#E6EEFF")
	v_u_54(p288, v292, "Body", Vector3.new(2.6, 2.2, 2.2), CFrame.new(p290 + Vector3.new(0, 1.5, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v308, Enum.Material.Neon, 0.55).Shape = Enum.PartType.Cylinder
	for v309 = 0, 7 do
		local v310 = v309 / 8 * 3.141592653589793 * 2
		local v311 = v_u_54
		local v312 = CFrame.new
		local v313 = math.cos(v310) * 1
		local v314 = v309 % 2 * 0.2 + 0.3
		local v315 = math.sin(v310) * 1
		v311(p288, v292, "Hem", Vector3.new(0.95, 0.95, 0.95), v312(p290 + Vector3.new(v313, v314, v315)), v308, Enum.Material.Neon, 0.55).Shape = Enum.PartType.Ball
	end
	for _, v316 in { -1, 1 } do
		local v317 = v_u_54
		local v318 = CFrame.new
		local v319 = v316 * 1.3
		v317(p288, v292, "Arm", Vector3.new(0.5, 1.5, 0.5), v318(p290 + Vector3.new(v319, 1.9, 0.2)) * CFrame.Angles(0, 0, (v_u_5(v316 * -18))), v308, Enum.Material.Neon, 0.6)
	end
	local v320 = v_u_54(p288, v292, "Head", Vector3.new(2.2, 2.2, 2.2), CFrame.new(p290 + Vector3.new(0, 2.8, 0)), v308, Enum.Material.Neon, 0.5)
	v320.Shape = Enum.PartType.Ball
	for _, v321 in { -1, 1 } do
		local v322 = v_u_54
		local v323 = CFrame.new
		local v324 = v321 * 0.42
		v322(p288, v292, "Eye", Vector3.new(0.38, 0.55, 0.2), v323(p290 + Vector3.new(v324, 3.15, 0.98)), v_u_7.eye, Enum.Material.SmoothPlastic, 0.1).Shape = Enum.PartType.Ball
	end
	v_u_54(p288, v292, "Mouth", Vector3.new(0.45, 0.6, 0.2), CFrame.new(p290 + Vector3.new(0, 2.45, 1.08)), v_u_7.eye, Enum.Material.SmoothPlastic, 0.1).Shape = Enum.PartType.Ball
	v_u_75(p288, v320, v_u_7.violet, 0.7, p291, false, 0.4)
	v292.Parent = p289
	return v292
end
local function v_u_344(p326, p327, p328) -- name: grave
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v329 = Instance.new("Model")
	v329.Name = "Grave_" .. p328.id
	local v330 = p328.grave[1]
	local v331 = p328.grave[2]
	local v332 = p326.origin + p328.at
	local v333 = CFrame.new(v332) * CFrame.Angles(0, v_u_5(p328.yaw), 0)
	local v334 = v_u_7.stone
	local v335 = v331 - v330 / 2
	local v336 = Vector3.new(v330, v335, 0.4)
	local v337 = v333 * CFrame.new(0, (v331 - v330 / 2) / 2 - 0.05, 0)
	local v338 = Enum.Material.Slate
	local v339 = Instance.new("Part")
	v339.Name = "Slab"
	v339.Anchored = true
	v339.CanCollide = false
	v339.CanTouch = false
	v339.CanQuery = false
	v339.CastShadow = false
	v339.TopSurface = Enum.SurfaceType.Smooth
	v339.BottomSurface = Enum.SurfaceType.Smooth
	v339.Size = v336
	v339.CFrame = v337
	v339.Color = v334
	v339.Material = v338
	v339.Parent = v329
	p326.n = p326.n + 1
	local v340 = Vector3.new(0.4, v330, v330)
	local v341 = v333 * CFrame.new(0, v331 - v330 / 2 - 0.05, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v342 = Enum.Material.Slate
	local v343 = Instance.new("Part")
	v343.Name = "Cap"
	v343.Anchored = true
	v343.CanCollide = false
	v343.CanTouch = false
	v343.CanQuery = false
	v343.CastShadow = false
	v343.TopSurface = Enum.SurfaceType.Smooth
	v343.BottomSurface = Enum.SurfaceType.Smooth
	v343.Size = v340
	v343.CFrame = v341
	v343.Color = v334
	v343.Material = v342
	v343.Parent = v329
	p326.n = p326.n + 1
	v343.Shape = Enum.PartType.Cylinder
	v329.Parent = p327
end
local function v_u_361(p345, p346, p347) -- name: bat
	-- upvalues: (copy) v_u_7
	local v348 = Instance.new("Model")
	v348.Name = p347
	local v349 = CFrame.new()
	local v350 = v_u_7.bat
	local v351 = Enum.Material.Slate
	local v352 = Instance.new("Part")
	v352.Name = "Body"
	v352.Anchored = true
	v352.CanCollide = false
	v352.CanTouch = false
	v352.CanQuery = false
	v352.CastShadow = false
	v352.TopSurface = Enum.SurfaceType.Smooth
	v352.BottomSurface = Enum.SurfaceType.Smooth
	v352.Size = Vector3.new(1, 1, 1)
	v352.CFrame = v349
	v352.Color = v350
	v352.Material = v351
	v352.Parent = v348
	p345.n = p345.n + 1
	v352.Shape = Enum.PartType.Ball
	local v353 = CFrame.new()
	local v354 = v_u_7.bat
	local v355 = Enum.Material.Slate
	local v356 = Instance.new("WedgePart")
	v356.Name = "WingL"
	v356.Anchored = true
	v356.CanCollide = false
	v356.CanTouch = false
	v356.CanQuery = false
	v356.CastShadow = false
	v356.TopSurface = Enum.SurfaceType.Smooth
	v356.BottomSurface = Enum.SurfaceType.Smooth
	v356.Size = Vector3.new(0.05, 3.4, 1.9)
	v356.CFrame = v353
	v356.Color = v354
	v356.Material = v355
	v356.Parent = v348
	p345.n = p345.n + 1
	local v357 = CFrame.new()
	local v358 = v_u_7.bat
	local v359 = Enum.Material.Slate
	local v360 = Instance.new("WedgePart")
	v360.Name = "WingR"
	v360.Anchored = true
	v360.CanCollide = false
	v360.CanTouch = false
	v360.CanQuery = false
	v360.CastShadow = false
	v360.TopSurface = Enum.SurfaceType.Smooth
	v360.BottomSurface = Enum.SurfaceType.Smooth
	v360.Size = Vector3.new(0.05, 3.4, 1.9)
	v360.CFrame = v357
	v360.Color = v358
	v360.Material = v359
	v360.Parent = v348
	p345.n = p345.n + 1
	v348.Parent = p346
	return {
		["body"] = v352,
		["wl"] = v356,
		["wr"] = v360
	}
end
function v_u_4._build(p362) -- name: _build
	-- upvalues: (copy) v_u_4, (copy) v_u_287, (copy) v_u_272, (copy) v_u_101, (copy) v_u_92, (copy) v_u_186, (copy) v_u_216, (copy) v_u_26, (copy) v_u_247, (copy) v_u_325, (copy) v_u_7, (copy) v_u_361
	local v_u_363 = p362.scene
	local v365, v366 = pcall(function()
		-- upvalues: (copy) v_u_363
		local v364 = v_u_363.cctx.controllers.Atmosphere
		if v364 and v364.quality then
			return v364.quality()
		else
			return nil
		end
	end)
	if v365 then
		if type(v366) == "number" then
			v365 = v366 <= 2
		else
			v365 = false
		end
	end
	local v367 = v_u_363.origin
	local v368 = Instance.new("Folder")
	v368.Name = v_u_4.FOLDER
	local v369 = {
		["folder"] = nil,
		["origin"] = nil,
		["n"] = 0,
		["lights"] = nil,
		["low"] = nil,
		["folder"] = v368,
		["origin"] = v367,
		["lights"] = {},
		["low"] = v365
	}
	p362.low = v365
	local function v370()
		-- upvalues: (copy) v_u_363, (ref) v_u_4
		return v_u_363.cctx.config.flag(v_u_4.FLAG2)
	end
	local v371, v372 = pcall(v370)
	if v371 then
		v371 = v372 == true
	end
	p362.v2 = v371
	v_u_287(v369, v368, v367 + v_u_4.HAY, 0.13962634015954636)
	v_u_272(v369, v368, v367 + v_u_4.CANDLES, true)
	for _, v373 in v_u_4.PUMPKINS do
		local v374 = v373.y
		if v373.on then
			local v375 = v_u_101
			local v376 = v373.on
			local v377 = v373.x
			local v378 = v373.y
			local v379 = v373.z
			v374 = v_u_92(v375(v_u_363, v376, (Vector3.new(v377, v378, v379))), v367.X + v373.x, v367.Z + v373.z, v367.Y + v373.y + 8, v367.Y + v373.y) - v367.Y
		end
		local v380 = v373.x
		local v381 = v373.z
		local v382 = v367 + Vector3.new(v380, v374, v381)
		local v383
		if v371 then
			v383 = p362:_assetPumpkin(v369, v368, v373, v382)
		else
			v383 = false
		end
		if v383 then
			continue
		end
		v_u_186(v369, v368, v373, v382)
	end
	p362.bulbs = {}
	for v384, v385 in v_u_4.GARLANDS do
		v_u_216(v369, v368, v385, v384, p362.bulbs)
	end
	if v371 then
		for v386, v387 in v_u_4.GARLANDS2 do
			v_u_216(v369, v368, v_u_26(v_u_363, v387), 2 + v386, p362.bulbs)
		end
	end
	v_u_247(v369, v368, "WebLamp", v367 + Vector3.new(-3.6, 17.85, 1.2), Vector3.new(0, 0, -1), (Vector3.new(0.45, -0.89, 0)).Unit, 1.9)
	v_u_247(v369, v368, "WebBarricadeL", v367 + Vector3.new(-15.36, 3.15, -5), Vector3.new(0.951, 0, -0.309), Vector3.new(0, -1, 0), 1.5)
	p362.ghostTrail = nil
	if v371 and not v_u_4.GHOST_ON then
		p362.ghostModel = nil
		p362.ghostFly = false
		p362.ghostAt = nil
	elseif v371 then
		local v388 = v_u_4.GHOST_FLY
		p362.ghostModel = v_u_325(v369, v368, v367, v388.range)
		if not v365 then
			local v389 = p362.ghostModel:FindFirstChild("Head")
			local v390 = p362.ghostModel:FindFirstChild("Hem")
			if v389 and v390 then
				local v391 = Instance.new("Attachment")
				local v392 = Instance.new("Attachment")
				v391.Name = "WakeTop"
				v392.Name = "WakeLow"
				v391.Position = Vector3.new(0, 0.5, 0)
				v392.Position = Vector3.new(0, -0.2, 0)
				v391.Parent = v389
				v392.Parent = v390
				local v393 = Instance.new("Trail")
				v393.Name = "Wake"
				v393.Attachment0 = v391
				v393.Attachment1 = v392
				v393.Lifetime = v388.trail
				v393.MinLength = 0.1
				v393.FaceCamera = true
				v393.LightEmission = 0.8
				v393.Color = ColorSequence.new(v_u_7.ghost)
				v393.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.72), NumberSequenceKeypoint.new(1, 1) })
				v393.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.25) })
				v393.Parent = v389
				p362.ghostTrail = v393
			end
		end
		p362.ghostModel.WorldPivot = CFrame.new(p362.ghostModel:GetBoundingBox().Position)
		p362.ghostModel:ScaleTo(v388.scale)
		for _, v394 in p362.ghostModel:GetDescendants() do
			if not v394:IsA("BasePart") or v394.Material ~= Enum.Material.Neon then
				continue
			end
			local v395 = v394.Transparency + v388.fade
			v394.Transparency = math.min(0.85, v395)
		end
		p362.ghostModel.Parent = nil
		p362.ghostFly = true
		if not p362.ghostAt or p362.ghostAt <= p362.t then
			p362.ghostAt = p362.t + p362.rng:NextNumber(v_u_4.GHOST_FIRST[1], v_u_4.GHOST_FIRST[2])
		end
	else
		p362.ghostModel = v_u_325(v369, v368, v367 + v_u_4.GHOST)
		p362.ghostFly = false
		p362.ghostBase = p362.ghostModel:GetPivot()
	end
	p362.bats = {}
	if not v365 then
		for v396, v397 in v_u_4.BATS do
			local v398 = v_u_361(v369, v368, "Bat" .. v396)
			local v399 = p362.bats
			table.insert(v399, {
				["parts"] = v398,
				["spec"] = v397
			})
		end
	end
	local v400 = Random.new(1031)
	local v401 = Instance.new("Model")
	v401.Name = "Leaves"
	local v402 = 0
	local v403 = 0
	while v402 < 14 and v403 < 200 do
		v403 = v403 + 1
		local v404 = v400:NextNumber(-18, 20)
		local v405 = v400:NextNumber(-12, 8)
		local v406 = Vector3.new(v404, 0, v405)
		local v407 = (v406 - Vector3.new(-3.6, 0, 1.6)).Magnitude > 2
		local v408 = v_u_4.LEAF_FREE
		if v408.x0 < v404 and (v404 < v408.x1 and (v408.z0 < v405 and v405 < v408.z1)) then
			v407 = false
		end
		for _, v409 in v_u_4.SLOTS do
			if (v406 - v409).Magnitude >= v_u_4.KEEP_OUT then
				continue
			end
			v407 = false
		end
		if not v407 then
			break
		end
		v402 = v402 + 1
		local v410 = v_u_7.leaf[v400:NextInteger(1, #v_u_7.leaf)]
		local v411 = v400:NextNumber(0.4, 0.7)
		local v412 = Vector3.new(v411, 0.03, v400:NextNumber(0.3, 0.5))
		local v413 = CFrame.new
		local v414 = (v405 > -2 and 0.5 or 0) + 0.03
		local v415 = v413(v367 + Vector3.new(v404, v414, v405)) * CFrame.Angles(0, v400:NextNumber(0, 6.28), 0)
		local v416 = Enum.Material.Fabric
		local v417 = Instance.new("Part")
		v417.Name = "Leaf"
		v417.Anchored = true
		v417.CanCollide = false
		v417.CanTouch = false
		v417.CanQuery = false
		v417.CastShadow = false
		v417.TopSurface = Enum.SurfaceType.Smooth
		v417.BottomSurface = Enum.SurfaceType.Smooth
		v417.Size = v412
		v417.CFrame = v415
		v417.Color = v410
		v417.Material = v416
		v417.Parent = v401
		v369.n = v369.n + 1
	end
	v401.Parent = v368
	if v371 then
		p362:_dressV2(v369, v368)
	end
	p362.lightList = v369.lights
	p362.nParts = v369.n
	p362.nLights = #v369.lights
	p362.root = v368
	p362:_sky()
	v368.Parent = v_u_363.root
end
function v_u_4._assetPumpkin(p418, p419, p420, p421, p422) -- name: _assetPumpkin
	-- upvalues: (copy) v_u_44, (copy) v_u_4, (copy) v_u_35, (copy) v_u_75, (copy) v_u_7
	local v423 = p421.r < 0.65 and "S" or (p421.r < 0.8 and "M" or "L")
	local v424 = v_u_44(p418.scene, v_u_4.PUMPKIN_ASSET[v423])
	if not (v424 and v_u_35(p419, v424, p421.noLight and 0 or v_u_4.PUMPKIN_PARTS)) then
		return false
	end
	v424.Name = "Pumpkin_" .. p421.id
	local v425 = 10 - (p422.X - p419.origin.X)
	local v426 = 34 - (p422.Z - p419.origin.Z)
	local v427 = Vector3.new(v425, 0, v426)
	v424:PivotTo(CFrame.lookAt(p422, p422 + v427))
	local _, v428 = v424:GetBoundingBox()
	if v428.X > 0.01 then
		local v429 = v424:GetScale() * (p421.r * 2)
		local v430 = v428.X
		local v431 = v428.Z
		v424:ScaleTo(v429 / math.max(v430, v431))
	end
	local v432, v433 = v424:GetBoundingBox()
	local v434 = v424:GetPivot()
	local v435 = p422.Y - (v432.Position.Y - v433.Y / 2)
	v424:PivotTo(v434 + Vector3.new(0, v435, 0))
	local v436 = v424:FindFirstChild("Body") or (v424.PrimaryPart or v424:FindFirstChildWhichIsA("BasePart", true))
	for _, v437 in v424:GetDescendants() do
		if not v437:IsA("BasePart") then
			continue
		end
		p419.n = p419.n + 1
	end
	if v436 and (v436:IsA("BasePart") and not p421.noLight) then
		local v438 = Instance.new("Attachment")
		v438.Name = "CandleAt"
		local v439 = -(v436.Size.Z * 0.5 + 0.25)
		v438.Position = Vector3.new(0, 0, v439)
		v438.Parent = v436
		v_u_75(p419, v438, v_u_7.glow, 0.85, 8, p421.lowKeep, #p419.lights % 3 * 0.7 + 2.3)
	end
	v424.Parent = p420
	return true
end
function v_u_4._dressV2(p440, p441, p442) -- name: _dressV2
	-- upvalues: (copy) v_u_101, (copy) v_u_44, (copy) v_u_4, (copy) v_u_35, (copy) v_u_5, (copy) v_u_344
	local v443 = p440.scene
	local v444 = v_u_101(v443, "Barricade", Vector3.new(-13, 0, -6))
	local v445
	if v444 then
		v445 = v_u_44(v443, v_u_4.BARRICADE_ASSET)
	else
		v445 = nil
	end
	if v445 and not v_u_35(p441, v445, 0) then
		v445 = nil
	end
	if v444 and v445 then
		local v446, v447 = v444:GetBoundingBox()
		v445:ScaleTo(v445:GetScale() * v_u_4.BARRICADE_SCALE)
		v445:PivotTo(v444:GetPivot() * CFrame.Angles(0, 3.141592653589793, 0))
		local v448, v449 = v445:GetBoundingBox()
		local v450 = v445:GetPivot()
		local v451 = v446.Position.Y - v447.Y / 2 - (v448.Position.Y - v449.Y / 2)
		v445:PivotTo(v450 + Vector3.new(0, v451, 0))
		v445.Name = "PoliceBarricade"
		for _, v452 in v445:GetDescendants() do
			if not v452:IsA("BasePart") then
				continue
			end
			p441.n = p441.n + 1
		end
		v445.Parent = p442
		local v453 = p440.swapped
		local v454 = {
			["old"] = v444,
			["parent"] = v444.Parent
		}
		table.insert(v453, v454)
		v444.Parent = nil
		local v455 = {}
		for _, v456 in v445:GetDescendants() do
			if not v456:IsA("BasePart") or v456.Name ~= "Lens" then
				continue
			end
			table.insert(v455, v456)
		end
		if #v455 > 0 then
			local v457 = v443.beacons
			if type(v457) == "table" then
				local v458 = {
					["cores"] = nil,
					["light"] = nil,
					["period"] = 1,
					["phase"] = 0,
					["duty"] = 0.35,
					["on"] = 0.9,
					["cores"] = v455,
					["light"] = Instance.new("PointLight")
				}
				local v459 = v443.beacons
				table.insert(v459, v458)
				local v460 = p440.beaconRows
				table.insert(v460, v458)
			end
		end
	end
	for _, v461 in v_u_4.PROP_SLOTS do
		local v462
		if v461.low and p441.low then
			v462 = nil
		else
			v462 = v_u_44(v443, v461.asset)
		end
		if v462 then
			if not v_u_35(p441, v462, not v461.grave and 0 or v_u_4.GRAVE_PARTS) then
				v462 = nil
			end
		end
		if v462 then
			v462.Name = "Prop_" .. v461.id
			if v461.scale then
				v462:ScaleTo(v462:GetScale() * v461.scale)
			end
			v462:PivotTo(CFrame.new(p441.origin + v461.at) * CFrame.Angles(0, v_u_5(v461.yaw) + 3.141592653589793, 0))
			local v463, v464 = v462:GetBoundingBox()
			local v465 = v462:GetPivot()
			local v466 = p441.origin.Y + v461.at.Y - (v463.Position.Y - v464.Y / 2)
			v462:PivotTo(v465 + Vector3.new(0, v466, 0))
			for _, v467 in v462:GetDescendants() do
				if not v467:IsA("BasePart") then
					continue
				end
				p441.n = p441.n + 1
			end
			v462.Parent = p442
			if not v461.pumpkin then
				break
			end
			local v468 = p441.origin.Y + v461.at.Y + v464.Y
			local v469 = p441.origin.X + v461.at.X + (v461.pumpkin.dx or 0)
			local v470 = p441.origin.Z + v461.at.Z + (v461.pumpkin.dz or 0)
			local v471 = Vector3.new(v469, v468, v470)
			p440:_assetPumpkin(p441, p442, {
				["id"] = nil,
				["x"] = 0,
				["z"] = 0,
				["y"] = 0,
				["r"] = nil,
				["on"] = nil,
				["lowKeep"] = false,
				["noLight"] = true,
				["id"] = v461.id .. "Top",
				["r"] = v461.pumpkin.r
			}, v471)
		else
			if not v461.grave then
				continue
			end
			v_u_344(p441, p442, v461)
		end
	end
	for _, v472 in v443.root:GetChildren() do
		if v472.Name ~= "TapeAnchor" then
			continue
		end
		for _, v473 in v472:GetChildren() do
			if not (v473:IsA("Beam") and v473.Enabled) then
				continue
			end
			v473.Enabled = false
			local v474 = p440.tapeBeams
			table.insert(v474, v473)
		end
	end
end
function v_u_4._restoreV2(p475) -- name: _restoreV2
	for _, v476 in p475.tapeBeams do
		if not v476.Parent then
			continue
		end
		v476.Enabled = true
	end
	p475.tapeBeams = {}
	for _, v477 in p475.swapped do
		if not (v477.old and (v477.parent and v477.parent.Parent)) then
			continue
		end
		v477.old.Parent = v477.parent
	end
	p475.swapped = {}
	local v478 = p475.scene
	if v478 then
		v478 = p475.scene.beacons
	end
	for _, v479 in p475.beaconRows do
		local v480
		if type(v478) == "table" then
			v480 = table.find(v478, v479)
		else
			v480 = nil
		end
		if not v480 then
			continue
		end
		table.remove(v478, v480)
	end
	p475.beaconRows = {}
end
function v_u_4._tint(p481, p482) -- name: _tint
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_1
	local v483 = p481.tint
	if p482 and not (v483 and v483.Parent) then
		local v484 = Instance.new("ColorCorrectionEffect")
		v484.Name = v_u_4.TINT
		v484.TintColor = v_u_7.tint
		v484.Saturation = 0.04
		v484.Contrast = 0
		v484.Brightness = 0
		v484.Parent = v_u_1
		p481.tint = v484
	elseif not p482 and v483 then
		v483:Destroy()
		p481.tint = nil
	end
end
function v_u_4._unbuild(p485) -- name: _unbuild
	p485:_restoreV2()
	if p485.root then
		p485.root:Destroy()
		p485.root = nil
	end
	p485:_tint(false)
	p485.lightList = {}
	p485.bulbs = {}
	p485.bats = {}
	if p485.ghostModel then
		p485.ghostModel:Destroy()
	end
	p485.ghostModel = nil
	p485.ghostTrail = nil
	p485.ghostFly = false
	p485.pass = nil
	p485.nParts = 0
	p485.nLights = 0
end
function v_u_4._sync(p486) -- name: _sync
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v_u_487 = p486.scene
	if not (v_u_487.root and v_u_487.root.Parent) then
		return
	end
	local function v488()
		-- upvalues: (copy) v_u_487, (ref) v_u_4
		return v_u_487.cctx.config.flag(v_u_4.FLAG)
	end
	local v489, v490 = pcall(v488)
	if v489 then
		v489 = v490 == true
	end
	if not v489 then
		if p486.root then
			p486:_unbuild()
		end
		return
	end
	local v491, v492, v493
	if p486.root then
		local v495, v496 = pcall(function()
			-- upvalues: (copy) v_u_487
			local v494 = v_u_487.cctx.controllers.Atmosphere
			if v494 and v494.quality then
				return v494.quality()
			else
				return nil
			end
		end)
		if v495 then
			if type(v496) == "number" then
				v495 = v496 <= 2
			else
				v495 = false
			end
		end
		if v495 == p486.low then
			local function v497()
				-- upvalues: (copy) v_u_487, (ref) v_u_4
				return v_u_487.cctx.config.flag(v_u_4.FLAG2)
			end
			local v498, v499 = pcall(v497)
			if v498 then
				v498 = v499 == true
			end
			if v498 == p486.v2 then
				v491 = v_u_2.LocalPlayer
				if v491 then
					v492 = v491:GetAttribute("IntroState")
				else
					v492 = nil
				end
				if type(v492) == "string" and v492 ~= "off" then
					v493 = v492 ~= "done"
				else
					v493 = false
				end
				p486:_tint(not v493)
				return
			end
			p486:_unbuild()
			p486:_build()
		else
			p486:_unbuild()
			p486:_build()
		end
		v491 = v_u_2.LocalPlayer
		if v491 then
			v492 = v491:GetAttribute("IntroState")
		else
			v492 = nil
		end
		if type(v492) == "string" and v492 ~= "off" then
			v493 = v492 ~= "done"
		else
			v493 = false
		end
		p486:_tint(not v493)
	else
		p486:_build()
		v491 = v_u_2.LocalPlayer
		if v491 then
			v492 = v491:GetAttribute("IntroState")
		else
			v492 = nil
		end
		if type(v492) == "string" and v492 ~= "off" then
			v493 = v492 ~= "done"
		else
			v493 = false
		end
		p486:_tint(not v493)
	end
end
function v_u_4._flicker(p500) -- name: _flicker
	local v501 = p500.t
	for _, v502 in p500.lightList do
		local v503 = v501 * v502.speed * 3 + v502.phase
		local v504 = math.sin(v503) * 0.5
		local v505 = v501 * v502.speed * 1.7 + v502.phase * 2.3
		local v506 = (v504 * math.sin(v505) + 0.5) * 0.12 + 0.88
		v502.light.Brightness = v502.base * v506
	end
end
function v_u_4._bulbs(p507) -- name: _bulbs
	local v508 = p507.t
	for _, v509 in p507.bulbs do
		local v510 = v509.part
		local v511 = v508 * 2.4 + v509.phase
		v510.Transparency = (math.sin(v511) * 0.5 + 0.5) * 0.22
	end
end
function v_u_4._sky(p512) -- name: _sky
	local v513 = p512.t
	local v514 = p512.scene.origin
	for _, v515 in p512.bats do
		local v516 = v515.spec
		local v517 = v516.ph + v513 * v516.w
		local v518 = v516.cx + math.cos(v517) * v516.rx
		local v519 = v516.cy
		local v520 = v513 * 0.9 + v516.ph
		local v521 = v519 + math.sin(v520) * v516.bob
		local v522 = v516.cz + math.sin(v517) * v516.rz
		local v523 = v514 + Vector3.new(v518, v521, v522)
		local v524 = -math.sin(v517) * v516.rx
		local v525 = math.cos(v517) * v516.rz
		local v526 = Vector3.new(v524, 0, v525) * (v516.w < 0 and -1 or 1)
		local v527 = CFrame.lookAt(v523, v523 + v526)
		local v528 = v513 * 3.141592653589793 * 2 * v516.flap + v516.ph
		local v529 = math.sin(v528) * 0.5934119456780721 + 0.35
		local v530 = v527 * CFrame.Angles(0, 0, (v516.w < 0 and -1 or 1) * -0.13962634015954636)
		v515.parts.body.CFrame = v530
		v515.parts.wl.CFrame = v530 * CFrame.Angles(0, 0, -v529) * CFrame.new(-1.9, 0, 0.1) * CFrame.Angles(0, 0, 1.5707963267948966)
		v515.parts.wr.CFrame = v530 * CFrame.Angles(0, 0, v529) * CFrame.new(1.9, 0, 0.1) * CFrame.Angles(0, 0, -1.5707963267948966)
	end
	if p512.ghostModel and not p512.ghostFly then
		local v531 = p512.ghostBase
		local v532 = p512.ghostModel
		local v533 = CFrame.new
		local v534 = v513 * 0.5
		local v535 = math.sin(v534) * 0.6
		local v536 = v513 * 0.8
		local v537 = v531 * v533(v535, math.sin(v536) * 0.5, 0)
		local v538 = CFrame.Angles
		local v539 = v513 * 0.35
		v532:PivotTo(v537 * v538(0, math.sin(v539) * 0.18, 0))
	end
end
function v_u_4.flyby(p540, p541) -- name: flyby
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v542 = p540.ghostModel
	if not (v542 and (p540.ghostFly and p540.root)) then
		return false, "no fly by ghost (flag LobbyHalloween2 off or no decoration)"
	end
	if p540.pass then
		return false, "a pass is running"
	end
	local v543 = workspace.CurrentCamera
	if not v543 then
		return false, "no camera"
	end
	local v544 = v_u_4.GHOST_FLY
	local v545 = v543.CFrame
	local v546 = v545.LookVector
	local v547 = v546.X
	local v548 = v546.Z
	local v549 = Vector3.new(v547, 0, v548)
	if v549.Magnitude < 0.3 then
		return false, "camera looks straight up or down"
	end
	local v550 = v549.Unit
	local v551 = v545.Position.X + v550.X * v544.depth
	local v552 = p540.scene.origin.Y + v544.height
	local v553 = v545.Position.Z + v550.Z * v544.depth
	local v554 = v545:PointToObjectSpace((Vector3.new(v551, v552, v553)))
	if v554.Z > -2 then
		return false, "anchor behind the camera"
	end
	local v555
	if p541 then
		v555 = math.clamp(p541, 0.5, 60)
	else
		v555 = p540.rng:NextNumber(v_u_4.GHOST_TIME[1], v_u_4.GHOST_TIME[2])
	end
	local v556 = v544.half * v544.scale
	local v557 = (v544.half + 0.4) * v544.scale
	local v558 = -v554.Z
	local v559 = v543.ViewportSize
	local v560 = (v559.X <= 2 or v559.Y <= 2) and 1.7777777777777777 or v559.X / v559.Y
	local v561 = v_u_5(v543.FieldOfView / 2)
	local v562 = v558 * math.tan(v561) * v560
	p540.lastT = v555
	p540.pass = {
		["t0"] = p540.t,
		["T"] = v555,
		["dur"] = v555 * (v562 + v557) / (v562 + v556),
		["ay"] = v554.Y,
		["az"] = v554.Z,
		["ph"] = p540.rng:NextNumber(0, 6.28),
		["w1"] = v557
	}
	p540:_ghostFly()
	if not p540.pass then
		return false, "camera busy (join intro or crate stage)"
	end
	p540.passes = p540.passes + 1
	v542.Parent = p540.root
	return true, ("pass %.1f s"):format(v555)
end
function v_u_4._ghostFly(p563) -- name: _ghostFly
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5
	local v564 = p563.pass
	local v565 = p563.ghostModel
	local v566 = workspace.CurrentCamera
	if v564 and v565 then
		local v567 = (p563.t - v564.t0) / v564.dur
		if v567 < 1 and v566 then
			local v568 = v_u_2.LocalPlayer
			local v569 = v_u_2.LocalPlayer
			local v570
			if v569 then
				v570 = v569:GetAttribute("IntroState")
			else
				v570 = nil
			end
			local v571
			if type(v570) == "string" and v570 ~= "off" then
				v571 = v570 ~= "done"
			else
				v571 = false
			end
			if not v571 then
				if v568 == nil then
					v571 = false
				else
					v571 = v568:GetAttribute("CrateStageOn") == true
				end
			end
			if not v571 then
				local v572 = v_u_4.GHOST_FLY
				local v573 = v566.CFrame
				local v574 = v573.LookVector
				local v575 = v574.X
				local v576 = v574.Z
				local v577 = Vector3.new(v575, 0, v576)
				if v577.Magnitude < 0.05 then
					p563:_ghostEnd()
				else
					local v578 = v577.Unit
					local v579 = -v564.az
					local v580 = v566.ViewportSize
					local v581 = (v580.X <= 2 or v580.Y <= 2) and 1.7777777777777777 or v580.X / v580.Y
					local v582 = v_u_5(v566.FieldOfView / 2)
					local v583 = v579 * math.tan(v582) * v581 + v564.w1
					local v584 = p563.t - v564.t0
					local v585 = v_u_4.GHOST_FLY
					local v586 = v584 * v585.bobHz * 3.141592653589793 * 2 + v564.ph
					local v587 = math.sin(v586) * v585.bob * v585.scale
					local v588 = -v583 + v583 * 2 * v567
					local v589 = v564.ay + v587
					local v590 = v564.az
					local v591 = v573:PointToWorldSpace((Vector3.new(v588, v589, v590)))
					local v592 = v584 * 3.1 + v564.ph
					local v593 = math.sin(v592) * 3
					v565:PivotTo(CFrame.lookAt(v591, v591 + v578) * CFrame.Angles(0, v_u_5(v572.yaw), 0) * CFrame.Angles(0, 0, -v_u_5(v572.lean + v593)))
				end
			end
		end
		p563:_ghostEnd()
	end
end
function v_u_4._ghostEnd(p594) -- name: _ghostEnd
	-- upvalues: (copy) v_u_4
	p594.pass = nil
	if p594.ghostModel then
		p594.ghostModel.Parent = nil
	end
	p594.ghostAt = p594.t + p594.rng:NextNumber(v_u_4.GHOST_EVERY[1], v_u_4.GHOST_EVERY[2])
end
function v_u_4._tick(p595, p596) -- name: _tick
	-- upvalues: (copy) v_u_2
	p595.t = p595.t + p596
	p595.pollIn = p595.pollIn - p596
	if p595.pollIn <= 0 then
		p595.pollIn = 0.5
		p595:_sync()
	end
	if p595.root then
		p595.accFlick = p595.accFlick + p596
		if p595.accFlick >= 0.1 then
			p595.accFlick = 0
			p595:_flicker()
		end
		p595.accBulb = p595.accBulb + p596
		if p595.accBulb >= 0.25 then
			p595.accBulb = 0
			p595:_bulbs()
		end
		p595.accSky = p595.accSky + p596
		if p595.accSky >= 0.05 then
			p595.accSky = 0
			p595:_sky()
		end
		if p595.pass then
			p595:_ghostFly()
			return
		end
		if p595.ghostFly and (p595.ghostAt and p595.t >= p595.ghostAt) then
			local v597 = v_u_2.LocalPlayer
			local v598 = v_u_2.LocalPlayer
			local v599
			if v598 then
				v599 = v598:GetAttribute("IntroState")
			else
				v599 = nil
			end
			local v600
			if type(v599) == "string" and v599 ~= "off" then
				v600 = v599 ~= "done"
			else
				v600 = false
			end
			if not v600 then
				if v597 == nil then
					v600 = false
				else
					v600 = v597:GetAttribute("CrateStageOn") == true
				end
			end
			if v600 or not p595:flyby() then
				p595.ghostAt = p595.t + 2
			end
		end
	end
end
function v_u_4.step(p601, p602) -- name: step
	if not p601.dead then
		local v603 = os.clock()
		local v604 = p601._tick
		local v605, v606 = pcall(v604, p601, p602)
		if not v605 then
			warn("[MenuHalloween] step failed, decoration removed:", v606)
			p601.dead = true
			local v607 = p601._unbuild
			pcall(v607, p601)
		end
		p601.costSum = p601.costSum + (os.clock() - v603)
		p601.costN = p601.costN + 1
	end
end
function v_u_4.state(p608) -- name: state
	-- upvalues: (copy) v_u_4
	local v609 = {}
	local v_u_610 = p608.scene
	local function v611()
		-- upvalues: (copy) v_u_610, (ref) v_u_4
		return v_u_610.cctx.config.flag(v_u_4.FLAG)
	end
	local v612, v613 = pcall(v611)
	if v612 then
		v612 = v613 == true
	end
	v609.flag = v612
	local v614
	if p608.root == nil then
		v614 = false
	else
		v614 = p608.root.Parent ~= nil
	end
	v609.built = v614
	v609.parts = p608.nParts
	v609.lights = p608.nLights
	v609.low = p608.low
	v609.bats = #p608.bats
	v609.ghost = p608.ghostModel ~= nil
	v609.ghostFly = p608.ghostFly
	v609.ghostPass = p608.pass ~= nil
	local v615
	if p608.ghostAt then
		v615 = p608.ghostAt - p608.t
	else
		v615 = nil
	end
	v609.ghostIn = v615
	v609.passes = p608.passes
	v609.v2 = p608.v2
	v609.tapeOff = #p608.tapeBeams
	v609.swapped = #p608.swapped
	local v616
	if p608.tint == nil then
		v616 = false
	else
		v616 = p608.tint.Parent ~= nil
	end
	v609.tint = v616
	v609.steps = p608.costN
	v609.avgMs = p608.costN <= 0 and 0 or p608.costSum / p608.costN * 1000
	v609.dead = p608.dead
	return v609
end
function v_u_4.destroy(p617) -- name: destroy
	-- upvalues: (ref) v_u_6
	p617.dead = true
	local v618 = p617._unbuild
	pcall(v618, p617)
	if v_u_6 == p617 then
		v_u_6 = nil
	end
end
function v_u_4.new(p_u_619) -- name: new
	-- upvalues: (copy) v_u_4, (ref) v_u_6
	local v620 = {
		["scene"] = nil,
		["root"] = nil,
		["tint"] = nil,
		["lightList"] = nil,
		["bulbs"] = nil,
		["bats"] = nil,
		["ghostModel"] = nil,
		["ghostBase"] = nil,
		["ghostFly"] = false,
		["ghostTrail"] = nil,
		["ghostAt"] = nil,
		["pass"] = nil,
		["passes"] = 0,
		["lastT"] = 0,
		["rng"] = nil,
		["v2"] = false,
		["tapeBeams"] = nil,
		["swapped"] = nil,
		["beaconRows"] = nil,
		["nParts"] = 0,
		["nLights"] = 0,
		["low"] = false,
		["t"] = 0,
		["pollIn"] = 0,
		["accFlick"] = 0,
		["accBulb"] = 0,
		["accSky"] = 0,
		["costSum"] = 0,
		["costN"] = 0,
		["dead"] = false,
		["scene"] = p_u_619,
		["lightList"] = {},
		["bulbs"] = {},
		["bats"] = {},
		["ghostBase"] = CFrame.identity,
		["rng"] = Random.new(),
		["tapeBeams"] = {},
		["swapped"] = {},
		["beaconRows"] = {}
	}
	local v621 = v_u_4
	local v622 = setmetatable(v620, v621)
	v_u_6 = v622
	local function v649()
		-- upvalues: (copy) p_u_619, (ref) v_u_6
		p_u_619.cctx.command("halloween.state", function()
			-- upvalues: (ref) v_u_6
			local v623 = v_u_6
			if not v623 then
				return "no halloween decoration (no menu scene)"
			end
			local v624 = v623:state()
			local v625 = "flag=%s built=%s parts=%d lights=%d low=%s bats=%d tint=%s steps=%d avgMs=%.4f dead=%s ghost=%s next=%s passes=%d"
			local v626 = v624.flag
			local v627 = tostring(v626)
			local v628 = v624.built
			local v629 = tostring(v628)
			local v630 = v624.parts
			local v631 = v624.lights
			local v632 = v624.low
			local v633 = tostring(v632)
			local v634 = v624.bats
			local v635 = v624.tint
			local v636 = tostring(v635)
			local v637 = v624.steps
			local v638 = v624.avgMs
			local v639 = v624.dead
			local v640 = tostring(v639)
			local v641 = v624.ghostPass and "flying" or (v624.ghostFly and "parked" or (v624.ghost and "hover" or "none"))
			local v642
			if v624.ghostIn then
				local v643 = v624.ghostIn
				v642 = ("%ds"):format((math.floor(v643)))
			else
				v642 = "-"
			end
			return v625:format(v627, v629, v630, v631, v633, v634, v636, v637, v638, v640, v641, v642, v624.passes)
		end)
		p_u_619.cctx.command("halloween.ghost", function(p644)
			-- upvalues: (ref) v_u_6
			local v645 = v_u_6
			if not v645 then
				return "no halloween decoration (no menu scene)"
			end
			local v646 = p644[1]
			local v647, v648 = v645:flyby((tonumber(v646)))
			return (v647 and "ghost: " or "no ghost: ") .. v648
		end)
	end
	pcall(v649)
	local v650 = v622._sync
	local v651, v652 = pcall(v650, v622)
	if not v651 then
		warn("[MenuHalloween] build failed:", v652)
		v622.dead = true
		local v653 = v622._unbuild
		pcall(v653, v622)
	end
	v622.pollIn = 0.5
	return v622
end
return v_u_4