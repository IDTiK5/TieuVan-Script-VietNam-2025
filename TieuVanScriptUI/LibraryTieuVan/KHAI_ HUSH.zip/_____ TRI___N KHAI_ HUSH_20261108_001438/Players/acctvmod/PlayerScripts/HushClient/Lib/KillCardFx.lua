-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardFx

local v1 = {}
local v3, v_u_4 = pcall(function()
	local v2 = script.Parent:FindFirstChild("KillCardBgFx")
	if v2 == nil then
		return nil
	else
		return require(v2)
	end
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v_u_5 = false
local v_u_6 = Vector2.new
local v_u_7 = UDim2.new
local v_u_8 = math.sin
local v_u_9 = math.floor
local function v_u_13(p10) -- name: seeded
	local v_u_11 = 2166136261
	for v12 = 1, #p10 do
		v_u_11 = (v_u_11 * 16777619 + string.byte(p10, v12)) % 4294967296
	end
	return function()
		-- upvalues: (ref) v_u_11
		v_u_11 = (v_u_11 * 1664525 + 1013904223) % 4294967296
		return v_u_11 / 4294967296
	end
end
local function v_u_21(p_u_14) -- name: newLayer
	local v_u_15 = {}
	return {
		["root"] = nil,
		["count"] = 0,
		["root"] = p_u_14,
		["add"] = function(p16) -- name: add
			-- upvalues: (copy) v_u_15
			local v17 = v_u_15
			table.insert(v17, p16)
		end,
		["step"] = function(p18) -- name: step
			-- upvalues: (copy) v_u_15
			for _, v19 in v_u_15 do
				v19(p18)
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) p_u_14, (copy) v_u_15
			local function v20()
				-- upvalues: (ref) p_u_14
				p_u_14:Destroy()
			end
			pcall(v20)
			table.clear(v_u_15)
		end
	}
end
local function v_u_46(p22, p23, p24, p25) -- name: edgeGlow
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v26 = {
		["Name"] = "Edge" .. p23,
		["BackgroundColor3"] = p24,
		["BorderSizePixel"] = 0
	}
	if v26.BackgroundTransparency == nil then
		v26.BackgroundTransparency = 0
	end
	local v27 = Instance.new("Frame")
	for v28, v29 in v26 do
		v27[v28] = v29
	end
	if p22 then
		v27.Parent = p22
	end
	if p23 == "L" then
		v27.Size = v_u_7(p25, 0, 1, 0)
		local v30 = NumberSequence.new(0, 1)
		local v31 = Instance.new("UIGradient")
		for v32, v33 in {
			["Rotation"] = 0
		} do
			v31[v32] = v33
		end
		if v27 then
			v31.Parent = v27
		end
		if v30 then
			v31.Transparency = v30
			return v27
		end
	elseif p23 == "R" then
		v27.AnchorPoint = v_u_6(1, 0)
		v27.Position = v_u_7(1, 0, 0, 0)
		v27.Size = v_u_7(p25, 0, 1, 0)
		local v34 = NumberSequence.new(0, 1)
		local v35 = Instance.new("UIGradient")
		for v36, v37 in {
			["Rotation"] = 180
		} do
			v35[v36] = v37
		end
		if v27 then
			v35.Parent = v27
		end
		if v34 then
			v35.Transparency = v34
			return v27
		end
	elseif p23 == "T" then
		v27.Size = v_u_7(1, 0, p25, 0)
		local v38 = NumberSequence.new(0, 1)
		local v39 = Instance.new("UIGradient")
		for v40, v41 in {
			["Rotation"] = 90
		} do
			v39[v40] = v41
		end
		if v27 then
			v39.Parent = v27
		end
		if v38 then
			v39.Transparency = v38
			return v27
		end
	else
		v27.AnchorPoint = v_u_6(0, 1)
		v27.Position = v_u_7(0, 0, 1, 0)
		v27.Size = v_u_7(1, 0, p25, 0)
		local v42 = NumberSequence.new(0, 1)
		local v43 = Instance.new("UIGradient")
		for v44, v45 in {
			["Rotation"] = 270
		} do
			v43[v44] = v45
		end
		if v27 then
			v43.Parent = v27
		end
		if v42 then
			v43.Transparency = v42
		end
	end
	return v27
end
local v_u_47 = {}
local v_u_48 = {}
local function v_u_68(p49, p50, p51, p_u_52, p53) -- name: snow
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8
	if not p49.noParticles then
		for _ = 1, p50 do
			local v_u_54 = p49.rnd()
			local v_u_55 = p49.rnd()
			local v56 = v_u_9(p49.rnd() * 3) + 2
			local v_u_57 = p51 * (0.6 + p49.rnd() * 0.8)
			local v58 = p49.host
			local v59 = {
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["Size"] = v_u_7(0, v56, 0, v56),
				["AnchorPoint"] = v_u_6(0.5, 0.5),
				["BackgroundColor3"] = p53,
				["BorderSizePixel"] = 0
			}
			if v59.BackgroundTransparency == nil then
				v59.BackgroundTransparency = 0
			end
			local v_u_60 = Instance.new("Frame")
			for v61, v62 in v59 do
				v_u_60[v61] = v62
			end
			if v58 then
				v_u_60.Parent = v58
			end
			local v63 = {
				["CornerRadius"] = UDim.new(1, 0)
			}
			local v64 = Instance.new("UICorner")
			for v65, v66 in v63 do
				v64[v65] = v66
			end
			if v_u_60 then
				v64.Parent = v_u_60
			end
			p49.add(function(p67)
				-- upvalues: (copy) v_u_60, (ref) v_u_7, (copy) v_u_54, (copy) v_u_55, (ref) v_u_8, (copy) p_u_52, (copy) v_u_57
				v_u_60.Position = v_u_7((v_u_54 + v_u_8(p67 * 0.9 + v_u_55 * 6.28) * p_u_52) % 1, 0, (p67 * v_u_57 + v_u_55) % 1, 0)
			end)
		end
	end
end
function v_u_47.snow(p69) -- name: snow
	-- upvalues: (copy) v_u_68
	v_u_68(p69, 18, 0.07, 0.02, Color3.fromRGB(240, 246, 255))
end
function v_u_47.blizzard(p70) -- name: blizzard
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	for _ = 1, p70.noParticles and 0 or 16 do
		local v_u_71 = p70.rnd()
		local v_u_72 = p70.rnd()
		local v_u_73 = 0.5 + p70.rnd() * 0.5
		local v74 = p70.host
		local v75 = {
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Rotation"] = 28,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Size"] = v_u_7(0, 22, 0, 1),
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
			["BorderSizePixel"] = 0
		}
		if v75.BackgroundTransparency == nil then
			v75.BackgroundTransparency = 0
		end
		local v_u_76 = Instance.new("Frame")
		for v77, v78 in v75 do
			v_u_76[v77] = v78
		end
		if v74 then
			v_u_76.Parent = v74
		end
		p70.add(function(p79)
			-- upvalues: (copy) v_u_73, (copy) v_u_72, (copy) v_u_76, (ref) v_u_7, (copy) v_u_71
			local v80 = (p79 * v_u_73 + v_u_72) % 1
			v_u_76.Position = v_u_7((v_u_71 + v80 * 0.5) % 1, 0, v80, 0)
		end)
	end
	local v81 = p70.host
	local v82 = {
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = v_u_7(1, 0, 1, 0),
		["BackgroundColor3"] = Color3.fromRGB(235, 242, 250),
		["BorderSizePixel"] = 0
	}
	if v82.BackgroundTransparency == nil then
		v82.BackgroundTransparency = 0
	end
	local v_u_83 = Instance.new("Frame")
	for v84, v85 in v82 do
		v_u_83[v84] = v85
	end
	if v81 then
		v_u_83.Parent = v81
	end
	p70.add(function(p86)
		-- upvalues: (copy) v_u_83
		local v87 = p86 - 1.2
		local v88 = 1 - math.abs(v87) / 0.6
		v_u_83.BackgroundTransparency = 0.9 - math.max(0, v88) * 0.3
	end)
end
function v_u_47.embers(p89) -- name: embers
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_8
	for _ = 1, p89.noParticles and 0 or 12 do
		local v_u_90 = p89.rnd()
		local v_u_91 = p89.rnd()
		local v_u_92 = 0.05 + p89.rnd() * 0.07
		local v93 = p89.host
		local v94 = {
			["Size"] = v_u_7(0, 3, 0, 3),
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["BackgroundColor3"] = Color3.fromRGB(255, 150, 60),
			["BorderSizePixel"] = 0
		}
		if v94.BackgroundTransparency == nil then
			v94.BackgroundTransparency = 0
		end
		local v_u_95 = Instance.new("Frame")
		for v96, v97 in v94 do
			v_u_95[v96] = v97
		end
		if v93 then
			v_u_95.Parent = v93
		end
		local v98 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v99 = Instance.new("UICorner")
		for v100, v101 in v98 do
			v99[v100] = v101
		end
		if v_u_95 then
			v99.Parent = v_u_95
		end
		p89.add(function(p102)
			-- upvalues: (copy) v_u_92, (copy) v_u_91, (copy) v_u_95, (ref) v_u_7, (copy) v_u_90, (ref) v_u_8
			local v103 = (p102 * v_u_92 + v_u_91) % 1
			v_u_95.Position = v_u_7((v_u_90 + v_u_8(p102 + v_u_91 * 9) * 0.015) % 1, 0, 1 - v103, 0)
			v_u_95.BackgroundTransparency = 0.2 + 0.75 * v103
		end)
	end
	local v104 = p89.host
	local v105 = {
		["AnchorPoint"] = v_u_6(0, 1),
		["Position"] = v_u_7(0, 0, 1, 0),
		["Size"] = v_u_7(1, 0, 0.4, 0),
		["BackgroundColor3"] = Color3.fromRGB(255, 120, 40),
		["BorderSizePixel"] = 0
	}
	if v105.BackgroundTransparency == nil then
		v105.BackgroundTransparency = 0
	end
	local v106 = Instance.new("Frame")
	for v107, v108 in v105 do
		v106[v107] = v108
	end
	if v104 then
		v106.Parent = v104
	end
	local v109 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
	local v110 = Instance.new("UIGradient")
	for v111, v112 in {
		["Rotation"] = 270
	} do
		v110[v111] = v112
	end
	if v106 then
		v110.Parent = v106
	end
	if v109 then
		v110.Transparency = v109
	end
end
function v_u_47.pines(p113) -- name: pines
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_68
	local v114 = p113.stops[2]:Lerp(Color3.new(0, 0, 0), 0.55)
	for v115 = 1, 8 do
		local v116 = (v115 - 0.5) / 8
		local v117 = 0.26 + p113.rnd() * 0.16
		for v118 = 1, 3 do
			local v119 = p113.host
			local v120 = {
				["AnchorPoint"] = v_u_6(0.5, 1),
				["Position"] = v_u_7(v116, 0, 1 - (v118 - 1) * v117 * 0.3, 0),
				["Size"] = v_u_7(0.14 - (v118 - 1) * 0.04, 0, v117 * 0.34, 0),
				["BackgroundColor3"] = v114,
				["BorderSizePixel"] = 0
			}
			if v120.BackgroundTransparency == nil then
				v120.BackgroundTransparency = 0
			end
			local v121 = Instance.new("Frame")
			for v122, v123 in v120 do
				v121[v122] = v123
			end
			if not v119 then
				break
			end
			v121.Parent = v119
		end
	end
	v_u_68(p113, 10, 0.05, 0.015, Color3.fromRGB(230, 238, 250))
end
function v_u_47.drifts(p124) -- name: drifts
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for v125 = 1, 4 do
		local v126 = p124.host
		local v127 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7((v125 - 0.5) / 4 + (p124.rnd() - 0.5) * 0.1, 0, 1, 0),
			["Size"] = v_u_7(0.5, 0, 0.16 + p124.rnd() * 0.08, 0),
			["BackgroundColor3"] = Color3.fromRGB(205, 218, 232),
			["BorderSizePixel"] = 0
		}
		if v127.BackgroundTransparency == nil then
			v127.BackgroundTransparency = 0
		end
		local v128 = Instance.new("Frame")
		for v129, v130 in v127 do
			v128[v129] = v130
		end
		if v126 then
			v128.Parent = v126
		end
		local v131 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v132 = Instance.new("UICorner")
		for v133, v134 in v131 do
			v132[v133] = v134
		end
		if not v128 then
			break
		end
		v132.Parent = v128
	end
end
function v_u_47.windows(p135) -- name: windows
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_68
	local v_u_136 = {}
	for v137 = 1, 3 do
		local v138 = p135.host
		local v139 = {
			["Position"] = v_u_7((v137 - 1) * 0.28 + 0.12, 0, 0.14, 0),
			["Size"] = v_u_7(0.2, 0, 0.17, 0),
			["BackgroundColor3"] = Color3.fromRGB(255, 200, 110),
			["BorderSizePixel"] = 0
		}
		if v139.BackgroundTransparency == nil then
			v139.BackgroundTransparency = 0
		end
		local v140 = Instance.new("Frame")
		for v141, v142 in v139 do
			v140[v141] = v142
		end
		if v138 then
			v140.Parent = v138
		end
		table.insert(v_u_136, v140)
	end
	p135.add(function(p143)
		-- upvalues: (copy) v_u_136, (ref) v_u_8
		for v144, v145 in v_u_136 do
			v145.BackgroundTransparency = (v_u_8(p143 * 1.3 + v144 * 2) * 0.5 + 0.5) * 0.1 + 0.12
		end
	end)
	v_u_68(p135, 16, 0.12, 0.05, Color3.fromRGB(235, 242, 252))
end
function v_u_47.chevron(p146) -- name: chevron
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for v147 = 1, 7 do
		local v148 = p146.host
		local v149 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.93,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(0.5, 0, (v147 - 0.5) / 7 * 0.6 + 0.4, 0),
			["Size"] = v_u_7(1.6, 0, 0, 2),
			["Rotation"] = v147 % 2 == 0 and 12 or -12,
			["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
			["BorderSizePixel"] = 0
		}
		if v149.BackgroundTransparency == nil then
			v149.BackgroundTransparency = 0
		end
		local v150 = Instance.new("Frame")
		for v151, v152 in v149 do
			v150[v151] = v152
		end
		if not v148 then
			break
		end
		v150.Parent = v148
	end
end
function v_u_47.hex(p153) -- name: hex
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v_u_154 = {}
	for v155 = 1, 5 do
		for v156 = 1, 6 do
			local v157 = p153.host
			local v158 = {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = 45,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.85,
				["AnchorPoint"] = v_u_6(0.5, 0.5),
				["Position"] = v_u_7((v155 - 0.5) / 5 + (v156 % 2 == 0 and 0.08 or 0), 0, (v156 - 0.5) / 6, 0),
				["Size"] = v_u_7(0, 9, 0, 9),
				["BackgroundColor3"] = Color3.fromRGB(120, 200, 255),
				["BorderSizePixel"] = 0
			}
			if v158.BackgroundTransparency == nil then
				v158.BackgroundTransparency = 0
			end
			local v159 = Instance.new("Frame")
			for v160, v161 in v158 do
				v159[v160] = v161
			end
			if v157 then
				v159.Parent = v157
			end
			local v162 = { v159, v155 + v156 }
			table.insert(v_u_154, v162)
		end
	end
	p153.add(function(p163)
		-- upvalues: (copy) v_u_154, (ref) v_u_8
		for _, v164 in v_u_154 do
			v164[1].BackgroundTransparency = v_u_8(p163 * 2.2 - v164[2] * 0.9) * 0.18 + 0.78
		end
	end)
end
function v_u_47.rays(p165) -- name: rays
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v_u_166 = {}
	for v167 = 1, 5 do
		local v168 = p165.host
		local v169 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.88,
			["AnchorPoint"] = v_u_6(0.5, 0),
			["Position"] = v_u_7(0.5, 0, -0.05, 0),
			["Size"] = v_u_7(0, 14, 1.5, 0),
			["Rotation"] = (v167 - 3) * 16,
			["BackgroundColor3"] = Color3.fromRGB(255, 240, 200),
			["BorderSizePixel"] = 0
		}
		if v169.BackgroundTransparency == nil then
			v169.BackgroundTransparency = 0
		end
		local v170 = Instance.new("Frame")
		for v171, v172 in v169 do
			v170[v171] = v172
		end
		if v168 then
			v170.Parent = v168
		end
		local v173 = { v170, (v167 - 3) * 16 }
		table.insert(v_u_166, v173)
	end
	p165.add(function(p174)
		-- upvalues: (copy) v_u_166, (ref) v_u_8
		for v175, v176 in v_u_166 do
			v176[1].Rotation = v176[2] + v_u_8(p174 * 0.5 + v175) * 4
		end
	end)
end
function v_u_47.aurora(p177) -- name: aurora
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v178 = { Color3.fromRGB(60, 255, 170), Color3.fromRGB(80, 220, 255) }
	local v_u_179 = {}
	for v180 = 1, 2 do
		local v181 = p177.host
		local v182 = {
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(0.5, 0, 0.3, 0),
			["Size"] = v_u_7(1.4, 0, 0.2, 0),
			["BackgroundColor3"] = v178[v180],
			["BorderSizePixel"] = 0
		}
		if v182.BackgroundTransparency == nil then
			v182.BackgroundTransparency = 0
		end
		local v183 = Instance.new("Frame")
		for v184, v185 in v182 do
			v183[v184] = v185
		end
		if v181 then
			v183.Parent = v181
		end
		local v186 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.5), NumberSequenceKeypoint.new(1, 1) })
		local v187 = Instance.new("UIGradient")
		for v188, v189 in {
			["Rotation"] = 0
		} do
			v187[v188] = v189
		end
		if v183 then
			v187.Parent = v183
		end
		if v186 then
			v187.Transparency = v186
		end
		table.insert(v_u_179, { v183, v180 })
	end
	p177.add(function(p190)
		-- upvalues: (copy) v_u_179, (ref) v_u_7, (ref) v_u_8
		for _, v191 in v_u_179 do
			v191[1].Position = v_u_7(0.5, 0, 0.26 + 0.06 * v191[2] + v_u_8(p190 * 0.5 + v191[2]) * 0.04, 0)
			v191[1].Rotation = v_u_8(p190 * 0.3 + v191[2]) * 4 + -8
		end
	end)
end
function v_u_47.beaconSweep(p192) -- name: beaconSweep
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v193 = p192.host
	local v194 = {
		["AnchorPoint"] = v_u_6(0, 0.5),
		["Position"] = v_u_7(0, 0, 1, 0),
		["Size"] = v_u_7(1.6, 0, 0.1, 0),
		["BackgroundColor3"] = Color3.fromRGB(255, 180, 60),
		["BorderSizePixel"] = 0
	}
	if v194.BackgroundTransparency == nil then
		v194.BackgroundTransparency = 0
	end
	local v_u_195 = Instance.new("Frame")
	for v196, v197 in v194 do
		v_u_195[v196] = v197
	end
	if v193 then
		v_u_195.Parent = v193
	end
	local v198 = NumberSequence.new(0.35, 1)
	local v199 = Instance.new("UIGradient")
	for v200, v201 in {
		["Rotation"] = 0
	} do
		v199[v200] = v201
	end
	if v_u_195 then
		v199.Parent = v_u_195
	end
	if v198 then
		v199.Transparency = v198
	end
	p192.add(function(p202)
		-- upvalues: (copy) v_u_195, (ref) v_u_8
		v_u_195.Rotation = (v_u_8(p202 * 1.1) * 0.5 + 0.5) * 70 + -80
	end)
end
function v_u_47.cloudBands(p203) -- name: cloudBands
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for v_u_204 = 1, 2 do
		local v_u_205 = p203.rnd()
		local v206 = p203.host
		local v207 = {
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.7,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Size"] = v_u_7(0.7, 0, 0.12, 0),
			["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
			["BorderSizePixel"] = 0
		}
		if v207.BackgroundTransparency == nil then
			v207.BackgroundTransparency = 0
		end
		local v_u_208 = Instance.new("Frame")
		for v209, v210 in v207 do
			v_u_208[v209] = v210
		end
		if v206 then
			v_u_208.Parent = v206
		end
		local v211 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v212 = Instance.new("UICorner")
		for v213, v214 in v211 do
			v212[v213] = v214
		end
		if v_u_208 then
			v212.Parent = v_u_208
		end
		p203.add(function(p215)
			-- upvalues: (copy) v_u_208, (ref) v_u_7, (copy) v_u_205, (copy) v_u_204
			v_u_208.Position = v_u_7((p215 * 0.02 + v_u_205) % 1.6 - 0.3, 0, v_u_204 * 0.22 + 0.18, 0)
		end)
	end
end
function v_u_47.horizon(p216) -- name: horizon
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v217 = p216.host
	local v218 = {
		["AnchorPoint"] = v_u_6(0, 1),
		["Position"] = v_u_7(0, 0, 1, 0),
		["Size"] = v_u_7(1, 0, 0.5, 0),
		["BackgroundColor3"] = Color3.fromRGB(255, 170, 90),
		["BorderSizePixel"] = 0
	}
	if v218.BackgroundTransparency == nil then
		v218.BackgroundTransparency = 0
	end
	local v219 = Instance.new("Frame")
	for v220, v221 in v218 do
		v219[v220] = v221
	end
	if v217 then
		v219.Parent = v217
	end
	local v222 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.3) })
	local v223 = Instance.new("UIGradient")
	for v224, v225 in {
		["Rotation"] = 90
	} do
		v223[v224] = v225
	end
	if v219 then
		v223.Parent = v219
	end
	if v222 then
		v223.Transparency = v222
	end
	for v226 = 1, 6 do
		local v227 = p216.host
		local v228 = {
			["AnchorPoint"] = v_u_6(0, 1),
			["Position"] = v_u_7((v226 - 1) / 6, 0, 1, 0),
			["Size"] = v_u_7(0.17666666666666667, 0, 0.05 + p216.rnd() * 0.07, 0),
			["BackgroundColor3"] = Color3.fromRGB(14, 18, 28),
			["BorderSizePixel"] = 0
		}
		if v228.BackgroundTransparency == nil then
			v228.BackgroundTransparency = 0
		end
		local v229 = Instance.new("Frame")
		for v230, v231 in v228 do
			v229[v230] = v231
		end
		if not v227 then
			break
		end
		v229.Parent = v227
	end
end
function v_u_47.caveDrip(p232) -- name: caveDrip
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v_u_233 = {}
	for v234 = 1, 8 do
		local v235 = (v234 - 0.5) / 8
		local v236 = p232.host
		local v237 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["AnchorPoint"] = v_u_6(0.5, 0),
			["Position"] = v_u_7(v235, 0, 0, 0),
			["Size"] = v_u_7(0.05, 0, 0.08 + p232.rnd() * 0.14, 0),
			["BackgroundColor3"] = Color3.fromRGB(170, 215, 240),
			["BorderSizePixel"] = 0
		}
		if v237.BackgroundTransparency == nil then
			v237.BackgroundTransparency = 0
		end
		local v238 = Instance.new("Frame")
		for v239, v240 in v237 do
			v238[v239] = v240
		end
		if v236 then
			v238.Parent = v236
		end
		local v241 = {
			["CornerRadius"] = UDim.new(0.5, 0)
		}
		local v242 = Instance.new("UICorner")
		for v243, v244 in v241 do
			v242[v243] = v244
		end
		if v238 then
			v242.Parent = v238
		end
		table.insert(v_u_233, v235)
	end
	local v245 = p232.host
	local v246 = {
		["AnchorPoint"] = v_u_6(0.5, 0.5),
		["Size"] = v_u_7(0, 3, 0, 12),
		["BackgroundColor3"] = Color3.fromRGB(235, 250, 255),
		["BorderSizePixel"] = 0
	}
	if v246.BackgroundTransparency == nil then
		v246.BackgroundTransparency = 0
	end
	local v_u_247 = Instance.new("Frame")
	for v248, v249 in v246 do
		v_u_247[v248] = v249
	end
	if v245 then
		v_u_247.Parent = v245
	end
	local v250 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v251 = Instance.new("UICorner")
	for v252, v253 in v250 do
		v251[v252] = v253
	end
	if v_u_247 then
		v251.Parent = v_u_247
	end
	p232.add(function(p254)
		-- upvalues: (copy) v_u_247, (ref) v_u_7, (copy) v_u_233
		local v255 = p254 * 0.25 % 1
		v_u_247.Position = v_u_7(v_u_233[3], 0, v255 * 0.5 + 0.04, 0)
		v_u_247.BackgroundTransparency = v255 * 0.8 + 0.1
	end)
end
function v_u_47.iceLayers(p256) -- name: iceLayers
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v257 = {
		Color3.fromRGB(70, 130, 190),
		Color3.fromRGB(110, 175, 225),
		Color3.fromRGB(55, 105, 165),
		Color3.fromRGB(150, 205, 240)
	}
	local v_u_258 = {}
	for v259 = 1, 4 do
		local v260 = p256.host
		local v261 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -12,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(0.5, 0, (v259 - 0.5) / 4, 0),
			["Size"] = v_u_7(1.5, 0, 0.24, 0),
			["BackgroundColor3"] = v257[v259],
			["BorderSizePixel"] = 0
		}
		if v261.BackgroundTransparency == nil then
			v261.BackgroundTransparency = 0
		end
		local v262 = Instance.new("Frame")
		for v263, v264 in v261 do
			v262[v263] = v264
		end
		if v260 then
			v262.Parent = v260
		end
		table.insert(v_u_258, { v262, v259 })
	end
	p256.add(function(p265)
		-- upvalues: (copy) v_u_258, (ref) v_u_8
		for _, v266 in v_u_258 do
			v266[1].BackgroundTransparency = v_u_8(p265 * 0.5 + v266[2] * 1.7) * 0.12 + 0.8
		end
	end)
end
function v_u_48.scanlines(p267) -- name: scanlines
	-- upvalues: (copy) v_u_7
	local v_u_268 = {}
	for _ = 1, 9 do
		local v269 = p267.host
		local v270 = {
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.9,
			["Size"] = v_u_7(1, 0, 0, 1),
			["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
			["BorderSizePixel"] = 0
		}
		if v270.BackgroundTransparency == nil then
			v270.BackgroundTransparency = 0
		end
		local v271 = Instance.new("Frame")
		for v272, v273 in v270 do
			v271[v272] = v273
		end
		if v269 then
			v271.Parent = v269
		end
		table.insert(v_u_268, v271)
	end
	p267.add(function(p274)
		-- upvalues: (copy) v_u_268, (ref) v_u_7
		for v275, v276 in v_u_268 do
			v276.Position = v_u_7(0, 0, ((v275 - 1) / 9 + p274 * 0.04) % 1, 0)
		end
	end)
end
function v_u_48.amberVignette(p277) -- name: amberVignette
	-- upvalues: (copy) v_u_46
	local v278 = Color3.fromRGB(255, 160, 40)
	for _, v279 in {
		"L",
		"R",
		"T",
		"B"
	} do
		v_u_46(p277.host, v279, v278, 0.28).BackgroundTransparency = 0.55
	end
end
function v_u_48.frostEdge(p280) -- name: frostEdge
	-- upvalues: (copy) v_u_46
	local v_u_281 = {}
	for _, v282 in {
		"L",
		"R",
		"T",
		"B"
	} do
		local v283 = v_u_46(p280.host, v282, Color3.fromRGB(225, 240, 255), 0.3)
		table.insert(v_u_281, v283)
	end
	p280.add(function(p284)
		-- upvalues: (copy) v_u_281
		local v285 = p284 / 2.5
		local v286 = math.clamp(v285, 0, 1)
		for _, v287 in v_u_281 do
			v287.BackgroundTransparency = 1 - v286 * 0.7
		end
	end)
end
function v_u_48.stars(p288) -- name: stars
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v_u_289 = {}
	for _ = 1, 22 do
		local v290 = p288.host
		local v291 = {
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p288.rnd(), 0, p288.rnd() * 0.7, 0),
			["Size"] = v_u_7(0, 2, 0, 2),
			["BackgroundColor3"] = Color3.fromRGB(255, 255, 255),
			["BorderSizePixel"] = 0
		}
		if v291.BackgroundTransparency == nil then
			v291.BackgroundTransparency = 0
		end
		local v292 = Instance.new("Frame")
		for v293, v294 in v291 do
			v292[v293] = v294
		end
		if v290 then
			v292.Parent = v290
		end
		local v295 = { v292, p288.rnd() * 6 }
		table.insert(v_u_289, v295)
	end
	p288.add(function(p296)
		-- upvalues: (copy) v_u_289, (ref) v_u_8
		for _, v297 in v_u_289 do
			v297[1].BackgroundTransparency = (v_u_8(p296 * 1.4 + v297[2]) * 0.5 + 0.5) * 0.5 + 0.25
		end
	end)
end
function v_u_48.caustics(p298) -- name: caustics
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for v_u_299 = 1, 3 do
		local v300 = p298.host
		local v301 = {
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Rotation"] = -20,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.9,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Size"] = v_u_7(1.5, 0, 0, v_u_299 * 3 + 8),
			["BackgroundColor3"] = Color3.fromRGB(200, 235, 255),
			["BorderSizePixel"] = 0
		}
		if v301.BackgroundTransparency == nil then
			v301.BackgroundTransparency = 0
		end
		local v_u_302 = Instance.new("Frame")
		for v303, v304 in v301 do
			v_u_302[v303] = v304
		end
		if v300 then
			v_u_302.Parent = v300
		end
		p298.add(function(p305)
			-- upvalues: (copy) v_u_302, (ref) v_u_7, (copy) v_u_299
			v_u_302.Position = v_u_7(0.5, 0, (p305 * 0.03 * v_u_299 + v_u_299 * 0.31) % 1.2 - 0.1, 0)
		end)
	end
end
function v1.bg(p_u_306, p_u_307, p_u_308, p_u_309, p_u_310) -- name: bg
	-- upvalues: (copy) v_u_7, (copy) v_u_21, (ref) v_u_5, (ref) v_u_4, (copy) v_u_13, (copy) v_u_47, (copy) v_u_48
	local function v346()
		-- upvalues: (copy) p_u_308, (copy) p_u_307, (copy) p_u_306, (ref) v_u_7, (ref) v_u_21, (copy) p_u_309, (ref) v_u_5, (ref) v_u_4, (copy) p_u_310, (ref) v_u_13, (ref) v_u_47, (ref) v_u_48
		local v311 = p_u_308.BACKGROUNDS[p_u_307] or p_u_308.BACKGROUNDS[p_u_308.DEFAULT_BG]
		local v312 = {}
		for v313, v314 in v311.stops do
			v312[v313] = Color3.fromRGB(v314[1] or 0, v314[2] or 0, v314[3] or 0)
		end
		local v315 = p_u_306
		local v316 = {
			["Name"] = "KillBg",
			["Size"] = nil,
			["ZIndex"] = 1,
			["ClipsDescendants"] = true,
			["BackgroundColor3"] = nil,
			["Size"] = v_u_7(1, 0, 1, 0),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BorderSizePixel"] = 0
		}
		if v316.BackgroundTransparency == nil then
			v316.BackgroundTransparency = 0
		end
		local v317 = Instance.new("Frame")
		for v318, v319 in v316 do
			v317[v318] = v319
		end
		if v315 then
			v317.Parent = v315
		end
		local v320 = ColorSequence.new(v312[1], v312[2] or v312[1])
		local v321 = Instance.new("UIGradient")
		for v322, v323 in {
			["Rotation"] = 90
		} do
			v321[v322] = v323
		end
		if v317 then
			v321.Parent = v317
		end
		if v320 then
			v321.Color = v320
		end
		local v324 = v_u_21(v317)
		local v325 = p_u_309
		if type(v325) ~= "table" then
			if v_u_5 == false then
				v_u_5 = nil
				local function v329()
					-- upvalues: (ref) v_u_5
					local v326 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					local v327
					if v326 then
						v327 = v326:FindFirstChild("Shared")
					else
						v327 = nil
					end
					local v328
					if v327 then
						v328 = v327:FindFirstChild("KillCardArt")
					else
						v328 = nil
					end
					if v328 ~= nil then
						v_u_5 = require(v328)
					end
				end
				pcall(v329)
			end
			v325 = v_u_5
		end
		local v330
		if v325 == nil then
			v330 = nil
		else
			local v331 = v325.background
			if type(v331) == "function" then
				v330 = v325.background(p_u_307)
			else
				v330 = nil
			end
		end
		if v330 ~= nil and v_u_4 == nil then
			v330 = nil
		end
		local v332
		if v330 == nil then
			v332 = false
		elseif p_u_310 == nil or p_u_310.reduced == nil then
			v332 = v_u_4.reducedMotion()
		else
			v332 = p_u_310.reduced == true
		end
		local v333 = {
			["particles"] = 0,
			["base"] = false,
			["fore"] = false,
			["reduced"] = nil,
			["legacy"] = true,
			["reduced"] = v332
		}
		local v335 = v332 and function(p334)
			p334(1)
		end or v324.add
		local v336 = {
			["host"] = v317,
			["rnd"] = v_u_13(p_u_307),
			["add"] = v335,
			["reduced"] = v332,
			["stops"] = { v312[1], v312[2] or v312[1] }
		}
		local v337
		if v330 == nil then
			v337 = false
		else
			v337 = v332 or v_u_4.particleCount(v330) > 0
		end
		v336.noParticles = v337
		local v338 = #v317:GetDescendants()
		local v339
		if v330 == nil then
			v339 = false
		else
			local v340 = v330.base
			if type(v340) == "string" then
				v339 = v330.base ~= ""
			else
				v339 = false
			end
		end
		if v339 then
			v_u_4.under(v336, v330)
			v333.legacy = false
		end
		if not v339 then
			local v341 = v_u_47[v311.pattern]
			local v342 = v_u_48[v311.overlay]
			if v341 then
				v341(v336)
			end
			if v342 then
				v342(v336)
			end
		end
		if v330 ~= nil then
			v_u_4.over(v336, v330)
		end
		v324.count = #v317:GetDescendants() + 1 - v338
		if v330 ~= nil then
			for _, v343 in v317:GetDescendants() do
				if not string.match(v343.Name, "^P%d+$") then
					continue
				end
				v333.particles = v333.particles + 1
			end
			v333.base = v339
			local v344 = v330.fore
			local v345
			if type(v344) == "string" then
				v345 = v330.fore ~= ""
			else
				v345 = false
			end
			v333.fore = v345
		end
		v324.info = v333
		return v324
	end
	local v347, v348 = pcall(v346)
	if v347 then
		return v348
	end
	warn("[KillCardFx] background failed:", v348)
	return nil
end
local v_u_349 = {}
local function v_u_352(_, p350) -- name: corners
	for _, v351 in {
		{
			0,
			0,
			1,
			1
		},
		{
			1,
			0,
			-1,
			1
		},
		{
			0,
			1,
			1,
			-1
		},
		{
			1,
			1,
			-1,
			-1
		}
	} do
		p350(v351[1], v351[2], v351[3], v351[4])
	end
end
local function v_u_364(p353, p354, p355, p356, p357, p358) -- name: dashes
	-- upvalues: (copy) v_u_7
	for v359 = 1, p357 do
		local v360 = {
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Position"] = v_u_7((v359 - 1) / p357 + 0.5 / p357 * 0.5, 0, p354, p355),
			["Size"] = v_u_7(0.5 / p357, 0, 0, p358),
			["BackgroundColor3"] = p356,
			["BorderSizePixel"] = 0
		}
		if v360.BackgroundTransparency == nil then
			v360.BackgroundTransparency = 0
		end
		local v361 = Instance.new("Frame")
		for v362, v363 in v360 do
			v361[v362] = v363
		end
		if not p353 then
			break
		end
		v361.Parent = p353
	end
end
function v_u_349.crystal(p_u_365) -- name: crystal
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_352(p_u_365.host, function(p366, p367, p368, p369)
		-- upvalues: (copy) p_u_365, (ref) v_u_6, (ref) v_u_7
		local v370 = p_u_365.host
		local v371 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p366, p368 * 3, p367, p369 * 3),
			["Size"] = v_u_7(0, 11, 0, 11),
			["BackgroundColor3"] = p_u_365.color,
			["BorderSizePixel"] = 0
		}
		if v371.BackgroundTransparency == nil then
			v371.BackgroundTransparency = 0
		end
		local v372 = Instance.new("Frame")
		for v373, v374 in v371 do
			v372[v373] = v374
		end
		if v370 then
			v372.Parent = v370
		end
	end)
end
function v_u_349.frostNotch(p_u_375) -- name: frostNotch
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_352(p_u_375.host, function(p376, p377, _, _)
		-- upvalues: (copy) p_u_375, (ref) v_u_6, (ref) v_u_7
		local v378 = p_u_375.host
		local v379 = {
			["AnchorPoint"] = v_u_6(p376, p377),
			["Position"] = v_u_7(p376, 0, p377, 0),
			["Size"] = v_u_7(0, 10, 0, 10),
			["BackgroundColor3"] = p_u_375.color,
			["BorderSizePixel"] = 0
		}
		if v379.BackgroundTransparency == nil then
			v379.BackgroundTransparency = 0
		end
		local v380 = Instance.new("Frame")
		for v381, v382 in v379 do
			v380[v381] = v382
		end
		if v378 then
			v380.Parent = v378
		end
	end)
end
function v_u_349.rime(p_u_383) -- name: rime
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_352(p_u_383.host, function(p384, p385, p386, p387)
		-- upvalues: (copy) p_u_383, (ref) v_u_6, (ref) v_u_7
		for v388 = 1, 3 do
			local v389 = p_u_383.host
			local v390 = {
				["AnchorPoint"] = v_u_6(0.5, 0.5),
				["Position"] = v_u_7(p384, p386 * (v388 * 4 + 4), p385, p387 * ((4 - v388) * 4 + 4)),
				["Size"] = v_u_7(0, 4, 0, 4),
				["BackgroundColor3"] = Color3.fromRGB(240, 248, 255),
				["BorderSizePixel"] = 0
			}
			if v390.BackgroundTransparency == nil then
				v390.BackgroundTransparency = 0
			end
			local v391 = Instance.new("Frame")
			for v392, v393 in v390 do
				v391[v392] = v393
			end
			if v389 then
				v391.Parent = v389
			end
			local v394 = {
				["CornerRadius"] = UDim.new(1, 0)
			}
			local v395 = Instance.new("UICorner")
			for v396, v397 in v394 do
				v395[v396] = v397
			end
			if not v391 then
				break
			end
			v395.Parent = v391
		end
	end)
end
function v_u_349.chamfer(p_u_398) -- name: chamfer
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_352(p_u_398.host, function(p399, p400, p401, p402)
		-- upvalues: (copy) p_u_398, (ref) v_u_6, (ref) v_u_7
		local v403 = p_u_398.host
		local v404 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p399, 0, p400, 0),
			["Size"] = v_u_7(0, 18, 0, 18),
			["BackgroundColor3"] = Color3.fromRGB(14, 17, 22),
			["BorderSizePixel"] = 0
		}
		if v404.BackgroundTransparency == nil then
			v404.BackgroundTransparency = 0
		end
		local v405 = Instance.new("Frame")
		for v406, v407 in v404 do
			v405[v406] = v407
		end
		if v403 then
			v405.Parent = v403
		end
		local v408 = p_u_398.host
		local v409 = {
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p399, p401 * 8, p400, p402 * 8),
			["Size"] = v_u_7(0, 4, 0, 4),
			["BackgroundColor3"] = Color3.fromRGB(210, 218, 228),
			["BorderSizePixel"] = 0
		}
		if v409.BackgroundTransparency == nil then
			v409.BackgroundTransparency = 0
		end
		local v410 = Instance.new("Frame")
		for v411, v412 in v409 do
			v410[v411] = v412
		end
		if v408 then
			v410.Parent = v408
		end
		local v413 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v414 = Instance.new("UICorner")
		for v415, v416 in v413 do
			v414[v415] = v416
		end
		if v410 then
			v414.Parent = v410
		end
	end)
end
function v_u_349.hazardStripe(p417) -- name: hazardStripe
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for _, v418 in { 0, 1 } do
		for v419 = 1, 14 do
			local v420 = p417.host
			local v421 = {
				["AnchorPoint"] = v_u_6(0, v418),
				["Position"] = v_u_7((v419 - 1) / 14, 0, v418, 0),
				["Size"] = v_u_7(0.07142857142857142, 0, 0, 5)
			}
			local v422
			if v419 % 2 == 0 then
				v422 = Color3.fromRGB(255, 180, 30)
			else
				v422 = Color3.fromRGB(20, 20, 20)
			end
			v421.BackgroundColor3 = v422
			v421.BorderSizePixel = 0
			if v421.BackgroundTransparency == nil then
				v421.BackgroundTransparency = 0
			end
			local v423 = Instance.new("Frame")
			for v424, v425 in v421 do
				v423[v424] = v425
			end
			if not v420 then
				break
			end
			v423.Parent = v420
		end
	end
end
function v_u_349.latch(p_u_426) -- name: latch
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9
	local v_u_427 = {}
	v_u_352(p_u_426.host, function(p428, p429, p430, p431)
		-- upvalues: (copy) p_u_426, (ref) v_u_6, (ref) v_u_7, (copy) v_u_427
		local v432 = p_u_426.host
		local v433 = {
			["AnchorPoint"] = v_u_6(p428, p429),
			["Position"] = v_u_7(p428, 0, p429, 0),
			["Size"] = v_u_7(0, 18, 0, 3),
			["BackgroundColor3"] = Color3.fromRGB(150, 160, 172),
			["BorderSizePixel"] = 0
		}
		if v433.BackgroundTransparency == nil then
			v433.BackgroundTransparency = 0
		end
		local v434 = Instance.new("Frame")
		for v435, v436 in v433 do
			v434[v435] = v436
		end
		if v432 then
			v434.Parent = v432
		end
		local v437 = p_u_426.host
		local v438 = {
			["AnchorPoint"] = v_u_6(p428, p429),
			["Position"] = v_u_7(p428, 0, p429, 0),
			["Size"] = v_u_7(0, 3, 0, 18),
			["BackgroundColor3"] = Color3.fromRGB(150, 160, 172),
			["BorderSizePixel"] = 0
		}
		if v438.BackgroundTransparency == nil then
			v438.BackgroundTransparency = 0
		end
		local v439 = Instance.new("Frame")
		for v440, v441 in v438 do
			v439[v440] = v441
		end
		if v437 then
			v439.Parent = v437
		end
		local v442 = p_u_426.host
		local v443 = {
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p428, p430 * 8, p429, p431 * 8),
			["Size"] = v_u_7(0, 5, 0, 5),
			["BackgroundColor3"] = Color3.fromRGB(60, 230, 255),
			["BorderSizePixel"] = 0
		}
		if v443.BackgroundTransparency == nil then
			v443.BackgroundTransparency = 0
		end
		local v444 = Instance.new("Frame")
		for v445, v446 in v443 do
			v444[v445] = v446
		end
		if v442 then
			v444.Parent = v442
		end
		local v447 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v448 = Instance.new("UICorner")
		for v449, v450 in v447 do
			v448[v449] = v450
		end
		if v444 then
			v448.Parent = v444
		end
		local v451 = v_u_427
		table.insert(v451, v444)
	end)
	p_u_426.add(function(p452)
		-- upvalues: (copy) v_u_427, (ref) v_u_9
		for _, v453 in v_u_427 do
			v453.BackgroundTransparency = p452 < 1.2 and v_u_9(p452 * 5) % 2 == 0 and 0 or (p452 < 1.2 and 0.8 or 0.25)
		end
	end)
end
function v_u_349.laurel(p_u_454) -- name: laurel
	-- upvalues: (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_352(p_u_454.host, function(p455, p456, p457, p458)
		-- upvalues: (copy) p_u_454, (ref) v_u_6, (ref) v_u_7
		for v459 = 1, 3 do
			local v460 = p_u_454.host
			local v461 = {
				["AnchorPoint"] = v_u_6(0.5, 0.5),
				["Position"] = v_u_7(p455, p457 * (v459 * 6 + 5), p456, p458 * (16 - v459 * 4)),
				["Size"] = v_u_7(0, 9, 0, 4),
				["Rotation"] = p457 * p458 * (v459 * 18 + 20),
				["BackgroundColor3"] = p_u_454.color,
				["BorderSizePixel"] = 0
			}
			if v461.BackgroundTransparency == nil then
				v461.BackgroundTransparency = 0
			end
			local v462 = Instance.new("Frame")
			for v463, v464 in v461 do
				v462[v463] = v464
			end
			if v460 then
				v462.Parent = v460
			end
			local v465 = {
				["CornerRadius"] = UDim.new(1, 0)
			}
			local v466 = Instance.new("UICorner")
			for v467, v468 in v465 do
				v466[v467] = v468
			end
			if not v462 then
				break
			end
			v466.Parent = v462
		end
	end)
end
function v_u_349.crown(p469) -- name: crown
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for v470 = 1, 5 do
		local v471 = v470 - 3
		local v472 = (3 - math.abs(v471)) * 4 + 8
		local v473 = p469.host
		local v474 = {
			["AnchorPoint"] = v_u_6(0.5, 1),
			["Position"] = v_u_7(0.5, (v470 - 3) * 11, 0, 1),
			["Size"] = v_u_7(0, 6, 0, v472),
			["Rotation"] = (v470 - 3) * 12
		}
		local v475
		if v470 % 2 == 0 then
			v475 = Color3.fromRGB(150, 205, 255)
		else
			v475 = Color3.fromRGB(240, 248, 255)
		end
		v474.BackgroundColor3 = v475
		v474.BorderSizePixel = 0
		if v474.BackgroundTransparency == nil then
			v474.BackgroundTransparency = 0
		end
		local v476 = Instance.new("Frame")
		for v477, v478 in v474 do
			v476[v477] = v478
		end
		if not v473 then
			break
		end
		v476.Parent = v473
	end
end
function v_u_349.stitch(p_u_479) -- name: stitch
	-- upvalues: (copy) v_u_364, (copy) v_u_352, (copy) v_u_6, (copy) v_u_7
	v_u_364(p_u_479.host, 0, 6, p_u_479.color, 16, 2)
	v_u_364(p_u_479.host, 1, -8, p_u_479.color, 16, 2)
	v_u_352(p_u_479.host, function(p480, p481, p482, p483)
		-- upvalues: (copy) p_u_479, (ref) v_u_6, (ref) v_u_7
		local v484 = p_u_479.host
		local v485 = {
			["AnchorPoint"] = v_u_6(0.5, 0.5),
			["Position"] = v_u_7(p480, p482 * 8, p481, p483 * 8),
			["Size"] = v_u_7(0, 5, 0, 5),
			["BackgroundColor3"] = p_u_479.color,
			["BorderSizePixel"] = 0
		}
		if v485.BackgroundTransparency == nil then
			v485.BackgroundTransparency = 0
		end
		local v486 = Instance.new("Frame")
		for v487, v488 in v485 do
			v486[v487] = v488
		end
		if v484 then
			v486.Parent = v484
		end
		local v489 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v490 = Instance.new("UICorner")
		for v491, v492 in v489 do
			v490[v491] = v492
		end
		if v486 then
			v490.Parent = v486
		end
	end)
end
function v_u_349.dashed(p493) -- name: dashed
	-- upvalues: (copy) v_u_364
	v_u_364(p493.host, 0, 6, Color3.fromRGB(240, 244, 250), 14, 2)
	v_u_364(p493.host, 1, -8, Color3.fromRGB(240, 244, 250), 14, 2)
end
function v_u_349.drift(p494) -- name: drift
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	for _, v495 in { 0, 1 } do
		local v496 = p494.host
		local v497 = {
			["AnchorPoint"] = v_u_6(0.5, 1),
			["Position"] = v_u_7(v495, 0, 1, 2),
			["Size"] = v_u_7(0.3, 0, 0, 12),
			["BackgroundColor3"] = Color3.fromRGB(235, 242, 250),
			["BorderSizePixel"] = 0
		}
		if v497.BackgroundTransparency == nil then
			v497.BackgroundTransparency = 0
		end
		local v498 = Instance.new("Frame")
		for v499, v500 in v497 do
			v498[v499] = v500
		end
		if v496 then
			v498.Parent = v496
		end
		local v501 = {
			["CornerRadius"] = UDim.new(1, 0)
		}
		local v502 = Instance.new("UICorner")
		for v503, v504 in v501 do
			v502[v503] = v504
		end
		if not v498 then
			break
		end
		v502.Parent = v498
	end
end
function v_u_349.tag(p505) -- name: tag
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v506 = p505.host
	local v507 = {
		["Position"] = v_u_7(0, 6, 0, -1),
		["Size"] = v_u_7(0, 16, 0, 9),
		["BackgroundColor3"] = p505.color,
		["BorderSizePixel"] = 0
	}
	if v507.BackgroundTransparency == nil then
		v507.BackgroundTransparency = 0
	end
	local v508 = Instance.new("Frame")
	for v509, v510 in v507 do
		v508[v509] = v510
	end
	if v506 then
		v508.Parent = v506
	end
	local v511 = p505.host
	local v512 = {
		["AnchorPoint"] = v_u_6(1, 1),
		["Position"] = v_u_7(1, -6, 1, 1),
		["Size"] = v_u_7(0, 16, 0, 9),
		["BackgroundColor3"] = p505.color,
		["BorderSizePixel"] = 0
	}
	if v512.BackgroundTransparency == nil then
		v512.BackgroundTransparency = 0
	end
	local v513 = Instance.new("Frame")
	for v514, v515 in v512 do
		v513[v514] = v515
	end
	if v511 then
		v513.Parent = v511
	end
end
function v_u_349.doubleLine(p516) -- name: doubleLine
	-- upvalues: (copy) v_u_7
	local v517 = p516.host
	local v518 = {
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Position"] = v_u_7(0, 5, 0, 5),
		["Size"] = v_u_7(1, -10, 1, -10),
		["BorderSizePixel"] = 0
	}
	if v518.BackgroundTransparency == nil then
		v518.BackgroundTransparency = 0
	end
	local v519 = Instance.new("Frame")
	for v520, v521 in v518 do
		v519[v520] = v521
	end
	if v517 then
		v519.Parent = v517
	end
	local v522 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil,
		["Color"] = p516.color:Lerp(Color3.fromRGB(90, 150, 255), 0.6),
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v523 = Instance.new("UIStroke")
	for v524, v525 in v522 do
		v523[v524] = v525
	end
	if v519 then
		v523.Parent = v519
	end
end
local function v_u_538(p526, p527, p528) -- name: proceduralFrame
	-- upvalues: (copy) v_u_349, (ref) v_u_4, (copy) v_u_8
	local v529 = p527.stroke
	local v530 = Color3.fromRGB(v529[1] or 0, v529[2] or 0, v529[3] or 0)
	local v531 = {
		["Color"] = v530,
		["Thickness"] = p527.px,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v_u_532 = Instance.new("UIStroke")
	for v533, v534 in v531 do
		v_u_532[v533] = v534
	end
	if p526 then
		v_u_532.Parent = p526
	end
	pcall(function()
		-- upvalues: (copy) v_u_532
		v_u_532.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	local v535 = v_u_349[p527.corner]
	if v535 then
		v535({
			["host"] = p526,
			["color"] = v530,
			["add"] = p528.add
		})
	end
	if p527.glow then
		local v536
		if v_u_4 == nil then
			v536 = false
		else
			v536 = v_u_4.reducedMotion() == true
		end
		if not v536 then
			p528.add(function(p537)
				-- upvalues: (copy) v_u_532, (ref) v_u_8
				v_u_532.Transparency = (v_u_8(p537 * 1.6) * 0.5 + 0.5) * 0.3 + 0.05
			end)
		end
	end
	return v_u_532
end
local function v_u_571(p539, p540, p_u_541, p542, p_u_543, p544) -- name: imageFrame
	-- upvalues: (copy) v_u_7, (copy) v_u_21, (ref) v_u_4, (copy) v_u_538, (copy) v_u_8
	local v545 = p_u_543.FRAME_SPEC
	local v546
	if p544 == nil then
		v546 = v545.z
	else
		local v547 = p544.z
		if type(v547) == "number" then
			v546 = p544.z
		else
			v546 = v545.z
		end
	end
	local v548 = {
		["Name"] = "KillFrame",
		["Size"] = nil,
		["ZIndex"] = nil,
		["BackgroundTransparency"] = 1,
		["Active"] = false,
		["Size"] = v_u_7(1, 0, 1, 0),
		["ZIndex"] = v546,
		["BorderSizePixel"] = 0
	}
	if v548.BackgroundTransparency == nil then
		v548.BackgroundTransparency = 0
	end
	local v_u_549 = Instance.new("Frame")
	for v550, v551 in v548 do
		v_u_549[v550] = v551
	end
	if p539 then
		v_u_549.Parent = p539
	end
	local v552 = p_u_543.sliceRect()
	local v553 = {
		["Name"] = "Image",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Image"] = nil,
		["ImageTransparency"] = 0,
		["ScaleType"] = nil,
		["SliceCenter"] = nil,
		["Size"] = nil,
		["Image"] = p542.image,
		["ScaleType"] = Enum.ScaleType.Slice,
		["SliceCenter"] = Rect.new(v552[1], v552[2], v552[3], v552[4]),
		["Size"] = v_u_7(1, 0, 1, 0)
	}
	local v_u_554 = Instance.new("ImageLabel")
	for v555, v556 in v553 do
		v_u_554[v555] = v556
	end
	if v_u_549 then
		v_u_554.Parent = v_u_549
	end
	local v_u_557 = v_u_21(v_u_549)
	local v_u_558 = false
	local v_u_559 = false
	task.spawn(function()
		-- upvalues: (copy) v_u_554
		local function v561()
			-- upvalues: (ref) v_u_554
			local v560 = { v_u_554 }
			game:GetService("ContentProvider"):PreloadAsync(v560)
		end
		pcall(v561)
	end)
	function v_u_557.resize(p562, p563) -- name: resize
		-- upvalues: (copy) v_u_554, (copy) p_u_543, (ref) v_u_558
		if p562 > 0 and p563 > 0 then
			v_u_554.SliceScale = p_u_543.sliceScale(p562, p563)
			v_u_558 = true
		end
	end
	if p544 ~= nil then
		local v564 = p544.w
		if type(v564) == "number" then
			local v565 = p544.h
			if type(v565) == "number" then
				v_u_557.resize(p544.w, p544.h)
			end
		end
	end
	local v_u_566
	if p542.glow == true then
		v_u_566 = true
	else
		local v567 = p_u_543.GLOW
		if type(v567) == "table" then
			v_u_566 = p_u_543.GLOW[p540] == true
		else
			v_u_566 = false
		end
	end
	if v_u_566 then
		local v568
		if p544 == nil or p544.reduced == nil then
			if v_u_4 == nil then
				v568 = false
			else
				v568 = v_u_4.reducedMotion() == true
			end
		else
			v568 = p544.reduced == true
		end
		if v568 then
			v_u_566 = false
		end
	end
	function v_u_557.fallbackNow() -- name: fallbackNow
		-- upvalues: (ref) v_u_559, (copy) v_u_554, (ref) v_u_538, (copy) v_u_549, (copy) p_u_541, (copy) v_u_557
		if not v_u_559 then
			v_u_559 = true
			v_u_554.Visible = false
			v_u_538(v_u_549, p_u_541, v_u_557)
			v_u_549.ZIndex = 8
		end
	end
	v_u_557.add(function(p569)
		-- upvalues: (ref) v_u_558, (copy) v_u_549, (copy) v_u_557, (ref) v_u_559, (copy) v_u_554, (ref) v_u_566, (ref) v_u_8
		if not v_u_558 then
			local v570 = v_u_549.AbsoluteSize
			if v570.X > 0 and v570.Y > 0 then
				v_u_557.resize(v570.X, v570.Y)
			end
		end
		if not v_u_559 then
			if p569 >= 8 and not v_u_554.IsLoaded then
				v_u_557.fallbackNow()
				return
			end
			if v_u_566 then
				v_u_554.ImageTransparency = (v_u_8(p569 * 1.6) * 0.5 + 0.5) * 0.12 + 0.02
			end
		end
	end)
	v_u_557.count = 2
	v_u_557.image = v_u_554
	v_u_557.isImage = true
	return v_u_557
end
function v1.frame(p_u_572, p_u_573, p_u_574, p_u_575, p_u_576) -- name: frame
	-- upvalues: (ref) v_u_5, (copy) v_u_571, (copy) v_u_7, (copy) v_u_21, (copy) v_u_538
	local function v591()
		-- upvalues: (copy) p_u_574, (copy) p_u_573, (copy) p_u_575, (ref) v_u_5, (ref) v_u_571, (copy) p_u_572, (copy) p_u_576, (ref) v_u_7, (ref) v_u_21, (ref) v_u_538
		local v577 = p_u_574.FRAMES[p_u_573] or p_u_574.FRAMES[p_u_574.DEFAULT_FRAME]
		local v578 = p_u_575
		if type(v578) ~= "table" then
			if v_u_5 == false then
				v_u_5 = nil
				local function v582()
					-- upvalues: (ref) v_u_5
					local v579 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					local v580
					if v579 then
						v580 = v579:FindFirstChild("Shared")
					else
						v580 = nil
					end
					local v581
					if v580 then
						v581 = v580:FindFirstChild("KillCardArt")
					else
						v581 = nil
					end
					if v581 ~= nil then
						v_u_5 = require(v581)
					end
				end
				pcall(v582)
			end
			v578 = v_u_5
		end
		if v578 ~= nil then
			local v583 = v578.hasFrameImage
			if type(v583) == "function" and v578.hasFrameImage(p_u_573) then
				return v_u_571(p_u_572, p_u_573, v577, v578.frame(p_u_573), v578, p_u_576)
			end
		end
		local v584 = p_u_572
		local v585 = {
			["Name"] = "KillFrame",
			["Size"] = nil,
			["ZIndex"] = 8,
			["BackgroundTransparency"] = 1,
			["Active"] = false,
			["Size"] = v_u_7(1, 0, 1, 0),
			["BorderSizePixel"] = 0
		}
		if v585.BackgroundTransparency == nil then
			v585.BackgroundTransparency = 0
		end
		local v586 = Instance.new("Frame")
		for v587, v588 in v585 do
			v586[v587] = v588
		end
		if v584 then
			v586.Parent = v584
		end
		local v589 = v_u_21(v586)
		local v590 = #v586:GetDescendants()
		v_u_538(v586, v577, v589)
		v589.count = #v586:GetDescendants() + 1 - v590
		function v589.resize(_, _) -- name: resize end
		v589.isImage = false
		return v589
	end
	local v592, v593 = pcall(v591)
	if v592 then
		return v593
	end
	warn("[KillCardFx] frame failed:", v593)
	return nil
end
return v1