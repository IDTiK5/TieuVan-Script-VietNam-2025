-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassWidget

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v_u_1.new(p_u_3, p4, p5, p6) -- name: new
	-- upvalues: (copy) v_u_2
	local v_u_7 = p_u_3.ui
	local v_u_8 = p_u_3.theme
	local v_u_9 = v_u_8.color
	local v_u_10 = true
	local v_u_11 = false
	local v_u_12 = false
	local v_u_13 = false
	local v_u_14 = false
	local v_u_15 = 0
	local v_u_16 = {}
	local v_u_17 = {}
	local v_u_18 = "MenuPassRules"
	local v19, v_u_20 = pcall(function()
		-- upvalues: (copy) p_u_3, (copy) v_u_18
		return p_u_3.cctx.shared[v_u_18]
	end)
	if not v19 or type(v_u_20) ~= "table" then
		v_u_20 = nil
	end
	if v_u_20 == nil then
		return nil
	end
	local v_u_21 = "GameMode"
	local v22, v_u_23 = pcall(function()
		-- upvalues: (copy) p_u_3, (copy) v_u_21
		return p_u_3.cctx.shared[v_u_21]
	end)
	if not v22 or type(v_u_23) ~= "table" then
		v_u_23 = nil
	end
	local v_u_24 = "pve"
	local v_u_25 = false
	local function v27()
		-- upvalues: (copy) v_u_23, (ref) v_u_24, (ref) v_u_25
		if v_u_23 and v_u_23.isPvpve() then
			v_u_24 = "pvpve"
		end
		local v26
		if v_u_23 == nil then
			v26 = false
		else
			v26 = v_u_23.rule("killCardCosmetics") == true
		end
		v_u_25 = v26
		if v_u_23 ~= nil and v_u_23.rule("seasonPass") == false then
			v_u_24 = "off"
		end
	end
	pcall(v27)
	if v_u_24 == "off" then
		return nil
	end
	local v_u_28 = "SeasonRules"
	local v29, v_u_30 = pcall(function()
		-- upvalues: (copy) p_u_3, (copy) v_u_28
		return p_u_3.cctx.shared[v_u_28]
	end)
	if not v29 or type(v_u_30) ~= "table" then
		v_u_30 = nil
	end
	local v_u_31 = {
		["mode"] = v_u_24,
		["killCard"] = v_u_25
	}
	local v_u_32 = "SeasonOp1"
	local v33, v34 = pcall(function()
		-- upvalues: (copy) p_u_3, (copy) v_u_32
		return p_u_3.cctx.shared[v_u_32]
	end)
	if not v33 or type(v34) ~= "table" then
		v34 = nil
	end
	v_u_31.ops = v34
	local v35
	if v_u_30 then
		v35 = v_u_30.TUNE
	else
		v35 = nil
	end
	v_u_31.tune = v35
	local v_u_36 = v_u_20.model(nil, v_u_31)
	local v37 = p_u_3.compact()
	local v38 = p_u_3.playColW
	local v39
	if type(v38) == "function" then
		v39 = p_u_3.playColW()
	else
		v39 = v37 and 440 or 520
	end
	local v40 = v_u_8.touch
	local v41
	if v37 then
		v41 = v_u_20.WIDGET_H.compact
	else
		v41 = v_u_20.WIDGET_H.wide
	end
	local v42 = v40(v41)
	local v43
	if type(p6) == "table" then
		v43 = p6.fill == true
	else
		v43 = false
	end
	local v44 = v_u_20.widgetLayout
	local v45
	if type(p6) == "table" then
		local v46 = p6.w
		if type(v46) == "number" then
			v45 = p6.w
		else
			v45 = v39 - 9
		end
	else
		v45 = v39 - 9
	end
	local v_u_47 = v44(v45, v42)
	local v_u_48 = nil
	local function v49()
		-- upvalues: (ref) v_u_48, (copy) p_u_3
		v_u_48 = p_u_3.cctx.lib.MenuPassAttention
	end
	pcall(v49)
	local v50 = v_u_7.new
	local v51 = "TextButton"
	local v52 = {
		["Name"] = "PassWidget",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Visible"] = false,
		["Selectable"] = true,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_9.raised
	}
	local v53
	if v43 then
		v53 = UDim2.fromScale(1, 1)
	else
		v53 = UDim2.new(1, 0, 0, v_u_47.h)
	end
	v52.Size = v53
	v52.LayoutOrder = p5
	local v_u_54 = v50(v51, v52, p4)
	v_u_54.SelectionImageObject = v_u_7.selectionImage()
	local v_u_55 = v_u_7.stroke(v_u_54, v_u_9.line, 1, 0)
	local v_u_56
	if v_u_48 == nil then
		v_u_56 = nil
	else
		local v57 = v_u_48.attach
		local v58 = v_u_9.accent
		local v59
		v59, v_u_56 = pcall(v57, v_u_54, v58)
		if not v59 then
			v_u_56 = nil
		end
	end
	v_u_7.tooltip(v_u_54, function()
		-- upvalues: (copy) v_u_20, (copy) v_u_9
		return {
			["title"] = v_u_20.TEXT.title,
			["body"] = v_u_20.TEXT.widgetOpen,
			["color"] = v_u_9.accent
		}
	end)
	local v60 = v_u_7.new("Frame", {
		["Name"] = "TierChip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v_u_9.accentDeep
	}, v_u_54)
	local v61 = v_u_47.chip
	v60.Position = UDim2.fromOffset(v61.x, v61.y)
	v60.Size = UDim2.fromOffset(v61.w, v61.h)
	v_u_7.stroke(v60, v_u_9.accent, 1, 0.35)
	v_u_7.label({
		["parent"] = nil,
		["name"] = "Word",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v60,
		["text"] = v_u_20.TEXT.tierWord,
		["color"] = v_u_9.accent,
		["position"] = UDim2.fromOffset(0, 2),
		["size"] = UDim2.new(1, 0, 0, 12)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_62 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Num",
		["text"] = "0",
		["style"] = "h2",
		["align"] = "center",
		["valign"] = "center",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v60,
		["position"] = UDim2.fromOffset(0, 14),
		["size"] = UDim2.new(1, 0, 1, -16)
	})
	v_u_62.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_63 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = "",
		["style"] = "h3",
		["textSize"] = 13,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_54,
		["color"] = v_u_9.text,
		["position"] = UDim2.fromOffset(v_u_47.name.x, v_u_47.name.y),
		["size"] = UDim2.fromOffset(v_u_47.name.w, v_u_47.name.h)
	})
	v_u_63.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_64 = v_u_7.progress({
		["parent"] = nil,
		["value"] = 0,
		["color"] = nil,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_54,
		["color"] = v_u_9.accent,
		["size"] = UDim2.fromOffset(v_u_47.bar.w, v_u_47.bar.h),
		["position"] = UDim2.fromOffset(v_u_47.bar.x, v_u_47.bar.y)
	})
	local v_u_65 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Numbers",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = 11,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_54,
		["color"] = v_u_9.text2,
		["position"] = UDim2.fromOffset(v_u_47.numbers.x, v_u_47.numbers.y),
		["size"] = UDim2.fromOffset(v_u_47.numbers.w, v_u_47.numbers.h)
	})
	v_u_65.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_66 = v_u_7.new("Frame", {
		["Name"] = "ClaimBadge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_9.accent
	}, v_u_54)
	v_u_66.AnchorPoint = Vector2.new(1, 0)
	v_u_66.Position = UDim2.new(1, -8, 0, v_u_47.badge.y)
	v_u_66.Size = UDim2.fromOffset(92, v_u_47.badge.h)
	local v_u_67 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "center",
		["valign"] = "center",
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_66,
		["color"] = v_u_9.bg,
		["size"] = UDim2.fromScale(1, 1)
	})
	v_u_67.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_68 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Time",
		["text"] = "",
		["style"] = "monoS",
		["textSize"] = 11,
		["color"] = nil,
		["align"] = "right",
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_54,
		["color"] = v_u_9.text2,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, -8, 0, v_u_47.time.y),
		["size"] = UDim2.fromOffset(v_u_47.time.w, v_u_47.time.h)
	})
	v_u_68.TextTruncate = Enum.TextTruncate.AtEnd
	v_u_54.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_55, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8
		v_u_55.Color = v_u_9.lineStrong
		v_u_7.sound(v_u_8.sounds.hover)
	end)
	v_u_54.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_55, (copy) v_u_66, (copy) v_u_9
		local v69 = v_u_55
		local v70
		if v_u_66.Visible then
			v70 = v_u_9.accent
		else
			v70 = v_u_9.line
		end
		v69.Color = v70
	end)
	function v_u_17._open() -- name: _open
		-- upvalues: (copy) p_u_3
		local v71 = p_u_3.setTab
		pcall(v71, "pass")
	end
	v_u_54.Activated:Connect(function()
		-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_17
		v_u_7.sound(v_u_8.sounds.click)
		v_u_17._open()
	end)
	function v_u_17.paint() -- name: paint
		-- upvalues: (ref) v_u_10, (copy) v_u_20, (ref) v_u_36, (ref) v_u_15, (ref) v_u_11, (copy) v_u_54, (ref) v_u_12, (copy) v_u_30, (ref) v_u_56, (copy) v_u_8, (ref) v_u_2, (copy) v_u_63, (copy) v_u_62, (copy) v_u_64, (copy) v_u_65, (copy) v_u_68, (copy) v_u_66, (copy) v_u_67, (copy) v_u_55, (copy) v_u_9
		if v_u_10 then
			local v72 = v_u_20.claimPlan(v_u_36)
			local v73 = v_u_20.widget(v_u_36, v72, os.clock() - v_u_15)
			v_u_11 = v73.show == true
			local v74 = v_u_54
			local v75 = v73.show
			if v75 then
				v75 = not v_u_12
			end
			v74.Visible = v75
			local v_u_76
			if v_u_30 == nil then
				v_u_76 = {
					["pulse"] = false,
					["count"] = 0
				}
			else
				local v77 = v_u_30.attention
				v_u_76 = type(v77) ~= "function" and {
					["pulse"] = false,
					["count"] = 0
				} or v_u_30.attention((not v73.show or (type(v72) ~= "table" or v72.ok ~= true)) and 0 or (v72.count or 0) + (v72.milestones or 0), false, false)
			end
			if v_u_56 ~= nil then
				local v78 = v_u_8.reduced
				local v79, v80 = pcall(v78)
				local v81 = v_u_56.set
				local v82
				if v_u_76.pulse == true then
					v82 = v_u_54.Visible
				else
					v82 = false
				end
				if v79 then
					v79 = v80 == true
				end
				v81(v82, v79)
			end
			if v73.show then
				local function v86()
					-- upvalues: (ref) v_u_2, (copy) v_u_76
					local v83 = v_u_2
					local v84 = "PassClaimable"
					local v85
					if v_u_76.count > 0 then
						v85 = v_u_76.count
					else
						v85 = nil
					end
					v83:SetAttribute(v84, v85)
				end
				pcall(v86)
			end
			if v73.show then
				v_u_63.Text = v73.name
				local v87 = v_u_62
				local v88 = v73.tier
				v87.Text = tostring(v88)
				v_u_64.set(v73.frac, true)
				v_u_65.Text = v73.numbers
				v_u_68.Text = v73.time
				v_u_66.Visible = v73.badge ~= nil
				v_u_67.Text = v73.badge or ""
				local v89 = v_u_55
				local v90
				if v73.badge == nil then
					v90 = v_u_9.line
				else
					v90 = v_u_9.accent
				end
				v89.Color = v90
				v_u_55.Thickness = v73.badge == nil and 1 or 2
				v_u_54:SetAttribute("PassWidget", ("%d/%d %s"):format(v73.tier, v73.count, v73.badge or "none"))
			else
				v_u_54:SetAttribute("PassWidget", "hidden")
			end
		else
			return
		end
	end
	function v_u_17.load(p_u_91) -- name: load
		-- upvalues: (ref) v_u_14, (ref) v_u_10, (copy) p_u_3, (copy) v_u_20, (ref) v_u_36, (copy) v_u_31, (ref) v_u_15, (copy) v_u_17
		if not v_u_14 and v_u_10 then
			v_u_14 = true
			task.spawn(function()
				-- upvalues: (copy) p_u_91, (ref) p_u_3, (ref) v_u_20, (ref) v_u_14, (ref) v_u_10, (ref) v_u_36, (ref) v_u_31, (ref) v_u_15, (ref) v_u_17
				local function v92()
					-- upvalues: (ref) p_u_91, (ref) p_u_3, (ref) v_u_20
					if p_u_91 then
						p_u_3.invalidate(v_u_20.GET)
					end
					return p_u_3.fetch(v_u_20.GET, nil, 15)
				end
				local v93, v94 = pcall(v92)
				v_u_14 = false
				if v_u_10 and v93 then
					if type(v94) ~= "table" then
						return
					end
					v_u_36 = v_u_20.model(v94, v_u_31)
					v_u_15 = os.clock()
					v_u_17.paint()
				end
			end)
		end
	end
	function v_u_17.setVisible(p95) -- name: setVisible
		-- upvalues: (ref) v_u_12, (ref) v_u_10, (copy) v_u_17
		v_u_12 = not p95
		if v_u_10 then
			v_u_17.paint()
		end
	end
	function v_u_17.available() -- name: available
		-- upvalues: (ref) v_u_11
		return v_u_11
	end
	function v_u_17.shows() -- name: shows
		-- upvalues: (copy) v_u_54
		return v_u_54.Visible
	end
	function v_u_17.show() -- name: show
		-- upvalues: (ref) v_u_13, (copy) v_u_17
		v_u_13 = true
		v_u_17.paint()
		v_u_17.load(false)
	end
	function v_u_17.hide() -- name: hide
		-- upvalues: (ref) v_u_13
		v_u_13 = false
	end
	function v_u_17.refresh(p96, p97) -- name: refresh
		-- upvalues: (ref) v_u_10, (copy) v_u_20, (copy) v_u_17, (ref) v_u_13
		if v_u_10 then
			if p96 == "result" and type(p97) == "table" then
				local v98 = p97.op
				if v98 == v_u_20.OPS.claim or (v98 == v_u_20.OPS.missions or (v98 == "storeBuy" or v98 == "storeGrant")) then
					v_u_17.load(true)
					return
				end
			elseif p96 == "profile" and v_u_13 then
				v_u_17.load(false)
			end
		end
	end
	function v_u_17.tick() -- name: tick
		-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_36, (copy) v_u_17, (ref) v_u_15
		if v_u_10 and v_u_13 then
			if v_u_36.ok then
				v_u_17.paint()
			end
			if os.clock() - v_u_15 > 60 then
				v_u_17.load(false)
			end
		end
	end
	pcall(function()
		-- upvalues: (copy) v_u_16, (copy) p_u_3, (ref) v_u_10, (copy) v_u_20, (ref) v_u_36, (copy) v_u_31, (ref) v_u_15, (copy) v_u_17
		local v99 = v_u_16
		local v100 = p_u_3.changed
		local function v107(p101)
			-- upvalues: (ref) v_u_10, (ref) p_u_3, (ref) v_u_20, (ref) v_u_36, (ref) v_u_31, (ref) v_u_15, (ref) v_u_17
			if p101 == "pass" and v_u_10 then
				local v102 = p_u_3.cache
				if v102 then
					v102 = p_u_3.cache[v_u_20.GET]
				end
				if type(v102) == "table" then
					local v103 = v102.data
					if type(v103) == "table" then
						local v104 = os.clock() - (v102.at or os.clock())
						local v105 = v102.data
						local v106 = os.clock() - math.max(0, v104)
						if type(v105) ~= "table" then
							return
						end
						v_u_36 = v_u_20.model(v105, v_u_31)
						v_u_15 = v106 or os.clock()
						v_u_17.paint()
					end
				end
			end
		end
		table.insert(v99, v100:Connect(v107))
	end)
	function v_u_17.destroy() -- name: destroy
		-- upvalues: (ref) v_u_10, (ref) v_u_56, (copy) v_u_16, (copy) v_u_54
		v_u_10 = false
		if v_u_56 ~= nil then
			v_u_56.destroy()
		end
		for _, v_u_108 in v_u_16 do
			pcall(function()
				-- upvalues: (copy) v_u_108
				v_u_108:Disconnect()
			end)
		end
		table.clear(v_u_16)
		local function v109()
			-- upvalues: (ref) v_u_54
			v_u_54:Destroy()
		end
		pcall(v109)
	end
	v_u_17.frame = v_u_54
	function v_u_17.model()
		-- upvalues: (ref) v_u_36
		return v_u_36
	end
	function v_u_17._layout()
		-- upvalues: (copy) v_u_47
		return v_u_47
	end
	function v_u_17._feed(p110)
		-- upvalues: (ref) v_u_36, (copy) v_u_20, (copy) v_u_31, (ref) v_u_15, (copy) v_u_17
		if type(p110) == "table" then
			v_u_36 = v_u_20.model(p110, v_u_31)
			v_u_15 = os.clock()
			v_u_17.paint()
		end
	end
	return v_u_17
end
function v_u_1.attach(p111, p112, p113, p114) -- name: attach
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v115 = v_u_1.new
	local v116, v_u_117 = pcall(v115, p111, p112, 0, p114)
	if not v116 then
		warn("[MenuPassWidget] card failed:", v_u_117)
		local function v119()
			-- upvalues: (ref) v_u_2, (copy) v_u_117
			local v118 = v_u_117
			v_u_2:SetAttribute("ClientError", "pass widget: " .. tostring(v118))
		end
		pcall(v119)
		return nil
	end
	if v_u_117 == nil then
		return nil
	end
	local v_u_120 = p113.show
	local v_u_121 = p113.hide
	local v_u_122 = p113.tick
	local v_u_123 = p113.destroy
	local v_u_124 = p113.refresh
	function p113.show(...) -- name: show
		-- upvalues: (copy) v_u_120, (copy) v_u_117
		if v_u_120 then
			v_u_120(...)
		end
		local v125 = v_u_117.show
		pcall(v125)
	end
	function p113.hide(...) -- name: hide
		-- upvalues: (copy) v_u_117, (copy) v_u_121
		local v126 = v_u_117.hide
		pcall(v126)
		if v_u_121 then
			v_u_121(...)
		end
	end
	function p113.tick(...) -- name: tick
		-- upvalues: (copy) v_u_122, (copy) v_u_117
		if v_u_122 then
			v_u_122(...)
		end
		local v127 = v_u_117.tick
		pcall(v127)
	end
	function p113.refresh(...) -- name: refresh
		-- upvalues: (copy) v_u_124, (copy) v_u_117
		if v_u_124 then
			v_u_124(...)
		end
		local v128 = v_u_117.refresh
		pcall(v128, ...)
	end
	function p113.destroy(...) -- name: destroy
		-- upvalues: (copy) v_u_117, (copy) v_u_123
		local v129 = v_u_117.destroy
		pcall(v129)
		if v_u_123 then
			v_u_123(...)
		end
	end
	p113.passWidget = v_u_117
	return v_u_117
end
return v_u_1