-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryCine

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
v_u_3.GUI_ORDER = 997
v_u_3.COVER_FADE = 0.5
v_u_3.SKIP_FADE = 0.25
v_u_3.BANNER_IN = 0.7
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = {
	["on"] = false,
	["fadeStart"] = nil,
	["fadeLen"] = 0.5,
	["alpha"] = 0
}
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = false
local v_u_19 = (1 / 0)
local v_u_20 = ""
local function v_u_86() -- name: buildGui
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (ref) v_u_6, (ref) v_u_7
	local v21 = v_u_4:FindFirstChildOfClass("PlayerGui") or v_u_4:WaitForChild("PlayerGui", 5)
	if not v21 then
		return nil
	end
	local v22 = v21:FindFirstChild("HushEntry")
	if v22 then
		v22:Destroy()
	end
	local v23 = {
		["Name"] = "HushEntry",
		["DisplayOrder"] = nil,
		["IgnoreGuiInset"] = true,
		["ResetOnSpawn"] = false,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = v_u_3.GUI_ORDER,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v_u_24 = Instance.new("ScreenGui")
	for v25, v26 in v23 do
		v_u_24[v25] = v26
	end
	pcall(function()
		-- upvalues: (copy) v_u_24
		v_u_24.ScreenInsets = Enum.ScreenInsets.None
	end)
	local v27 = v_u_6 and v_u_6.font or {}
	local v28 = v_u_6 and v_u_6.color or {}
	local v29 = v28.accent or Color3.fromRGB(232, 163, 61)
	local v30 = v28.text or Color3.fromRGB(230, 232, 235)
	local v31 = v28.text2 or Color3.fromRGB(154, 163, 174)
	local v32 = {
		["Name"] = "Black",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Active"] = false,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v33 = Instance.new("Frame")
	for v34, v35 in v32 do
		v33[v34] = v35
	end
	if v_u_24 then
		v33.Parent = v_u_24
	end
	local v36 = {
		["Name"] = "BarTop",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.new(1, 0, 0, 0)
	}
	local v37 = Instance.new("Frame")
	for v38, v39 in v36 do
		v37[v38] = v39
	end
	if v_u_24 then
		v37.Parent = v_u_24
	end
	local v40 = {
		["Name"] = "BarBottom",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 0)
	}
	local v41 = Instance.new("Frame")
	for v42, v43 in v40 do
		v41[v42] = v43
	end
	if v_u_24 then
		v41.Parent = v_u_24
	end
	local v44 = {
		["Name"] = "Banner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromOffset(520, 120),
		["Position"] = UDim2.fromOffset(40, 60)
	}
	local v45 = Instance.new("Frame")
	for v46, v47 in v44 do
		v45[v46] = v47
	end
	if v_u_24 then
		v45.Parent = v_u_24
	end
	local v48 = {
		["Name"] = "Kicker",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["FontFace"] = nil,
		["Text"] = nil,
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["TextSize"] = 15,
		["TextXAlignment"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.new(1, 0, 0, 20),
		["Position"] = UDim2.fromOffset(0, 0),
		["FontFace"] = v27.bodyBold or Font.fromEnum(Enum.Font.GothamBold)
	}
	local v49 = v_u_7.TEXTS.kicker
	if v_u_6 then
		local v50 = v_u_6.track
		if type(v50) == "function" then
			local v51 = v_u_6.track
			local v52, v53 = pcall(v51, v49, 2)
			if v52 and type(v53) == "string" then
				v49 = v53
			end
		end
	end
	v48.Text = v49
	v48.TextColor3 = v29
	v48.TextXAlignment = Enum.TextXAlignment.Left
	local v54 = Instance.new("TextLabel")
	for v55, v56 in v48 do
		v54[v55] = v56
	end
	if v45 then
		v54.Parent = v45
	end
	local v57 = {
		["Name"] = "Title",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["FontFace"] = nil,
		["Text"] = "",
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["TextSize"] = 34,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.new(1, 0, 0, 44),
		["Position"] = UDim2.fromOffset(0, 22),
		["FontFace"] = v27.headingBold or Font.fromEnum(Enum.Font.GothamBold),
		["TextColor3"] = v30,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}
	local v58 = Instance.new("TextLabel")
	for v59, v60 in v57 do
		v58[v59] = v60
	end
	if v45 then
		v58.Parent = v45
	end
	local v61 = {
		["Name"] = "Rule",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["BackgroundColor3"] = v29,
		["Position"] = UDim2.fromOffset(0, 70),
		["Size"] = UDim2.fromOffset(60, 2)
	}
	local v62 = Instance.new("Frame")
	for v63, v64 in v61 do
		v62[v63] = v64
	end
	if v45 then
		v62.Parent = v45
	end
	local v65 = {
		["Name"] = "Sub",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["FontFace"] = nil,
		["Text"] = "",
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["TextSize"] = 16,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.new(1, 0, 0, 22),
		["Position"] = UDim2.fromOffset(0, 78),
		["FontFace"] = v27.body or Font.fromEnum(Enum.Font.Gotham),
		["TextColor3"] = v31,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}
	local v66 = Instance.new("TextLabel")
	for v67, v68 in v65 do
		v66[v67] = v68
	end
	if v45 then
		v66.Parent = v45
	end
	local v69 = {
		["Name"] = "Skip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["Text"] = nil,
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["TextSize"] = 16,
		["ZIndex"] = 8,
		["BackgroundColor3"] = Color3.fromRGB(7, 9, 12),
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -24, 0, 24),
		["Size"] = UDim2.fromOffset(112, 44),
		["FontFace"] = v27.headingBold or Font.fromEnum(Enum.Font.GothamBold)
	}
	local v70 = v_u_7.TEXTS.skip
	if v_u_6 then
		local v71 = v_u_6.track
		if type(v71) == "function" then
			local v72 = v_u_6.track
			local v73, v74 = pcall(v72, v70, 1)
			if v73 and type(v74) == "string" then
				v70 = v74
			end
		end
	end
	v69.Text = v70 .. "  " .. utf8.char(8250) .. utf8.char(8250)
	v69.TextColor3 = v31
	local v75 = Instance.new("TextLabel")
	for v76, v77 in v69 do
		v75[v76] = v77
	end
	if v_u_24 then
		v75.Parent = v_u_24
	end
	local v78 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v79 = Instance.new("UICorner")
	for v80, v81 in v78 do
		v79[v80] = v81
	end
	if v75 then
		v79.Parent = v75
	end
	local v82 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1,
		["Transparency"] = 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v31
	}
	local v83 = Instance.new("UIStroke")
	for v84, v85 in v82 do
		v83[v84] = v85
	end
	if v75 then
		v83.Parent = v75
	end
	v_u_24.Parent = v21
	return {
		["gui"] = v_u_24,
		["black"] = v33,
		["top"] = v37,
		["bottom"] = v41,
		["banner"] = v45,
		["kicker"] = v54,
		["title"] = v58,
		["rule"] = v62,
		["sub"] = v66,
		["skip"] = v75,
		["stroke"] = v83
	}
end
function v_u_3.barPx(p87, p88, p89) -- name: barPx
	if p89 then
		local v90 = p88 * 0.05 + 0.5
		return math.floor(v90)
	end
	local v91 = (p88 - p87 / 2.39) / 2 + 0.5
	local v92 = math.floor(v91)
	return math.max(v92, 0)
end
function v_u_3.uiScale(p93, p94) -- name: uiScale
	if p94 then
		local v95 = p93 / 1080
		return math.max(v95, 0.5)
	else
		local v96 = p93 / 1080
		return math.clamp(v96, 0.6, 1.4)
	end
end
local function v_u_145(p97, p98, p99, p100) -- name: layoutGui
	-- upvalues: (ref) v_u_16, (ref) v_u_6, (copy) v_u_2, (copy) v_u_3
	if not v_u_16 then
		return
	end
	local v101 = v_u_16.gui.AbsoluteSize
	local v102 = v101.X
	local v103 = v101.Y
	if v102 < 2 or v103 < 2 then
		return
	end
	local v104
	if v_u_6 then
		local v105 = v_u_6.isPhone
		if type(v105) == "function" then
			local v106 = v_u_6.isPhone
			local v107, v108 = pcall(v106)
			if v107 then
				v104 = v108 == true
			else
				v104 = v_u_2.TouchEnabled
				if v104 then
					v104 = not v_u_2.KeyboardEnabled
				end
			end
		else
			v104 = v_u_2.TouchEnabled
			if v104 then
				v104 = not v_u_2.KeyboardEnabled
			end
		end
	else
		v104 = v_u_2.TouchEnabled
		if v104 then
			v104 = not v_u_2.KeyboardEnabled
		end
	end
	local v109 = v_u_3.barPx(v102, v103, v104) * p97
	v_u_16.top.Size = UDim2.new(1, 0, 0, v109)
	v_u_16.bottom.Size = UDim2.new(1, 0, 0, v109)
	v_u_16.black.BackgroundTransparency = 1 - math.clamp(p100, 0, 1)
	local v110 = v_u_3.uiScale(v103, v104)
	local v111 = (v104 and 24 or 56) * math.max(v110, 0.7)
	local v112 = math.floor(v111)
	local v113 = math.max(v110, 0.5)
	local v114 = v113 * 15 + 0.5
	local v115 = math.floor(v114)
	local v116 = math.max(v115, 14)
	local v117 = v113 * 34 + 0.5
	local v118 = math.floor(v117)
	local v119 = math.max(v118, v104 and 26 or 20)
	local v120 = v113 * 16 + 0.5
	local v121 = math.floor(v120)
	local v122 = math.max(v121, 14)
	local v123 = v_u_16.banner
	local v124 = UDim2.fromOffset
	local v125 = v113 * 24
	v123.Position = v124(v112, v109 + math.floor(v125))
	local v126 = v_u_16.banner
	local v127 = UDim2.fromOffset
	local v128 = v102 * 0.58
	v126.Size = v127(math.floor(v128), v119 + v116 + v122 + 28)
	v_u_16.kicker.TextSize = v116
	v_u_16.kicker.Size = UDim2.new(1, 0, 0, v116 + 4)
	v_u_16.title.TextSize = v119
	v_u_16.title.Position = UDim2.fromOffset(0, v116 + 6)
	v_u_16.title.Size = UDim2.new(1, 0, 0, v119 + 6)
	v_u_16.rule.Position = UDim2.fromOffset(0, v116 + v119 + 14)
	v_u_16.sub.TextSize = v122
	v_u_16.sub.Position = UDim2.fromOffset(0, v116 + v119 + 22)
	v_u_16.sub.Size = UDim2.new(1, 0, 0, v122 + 6)
	v_u_16.kicker.TextTransparency = 1 - p98
	v_u_16.title.TextTransparency = 1 - p98
	v_u_16.sub.TextTransparency = 1 - p98 * 0.9
	v_u_16.rule.BackgroundTransparency = 1 - p98
	local v129 = v113 * 44
	local v130 = math.floor(v129)
	local v131 = math.max(44, v130)
	local v132 = v_u_16.skip
	local v133 = UDim2.fromOffset
	local v134 = math.max(v113, 0.9) * 112
	v132.Size = v133(math.floor(v134), v131)
	local v135 = math.max(v113, 0.7) * 20
	local v136 = math.floor(v135)
	local v137 = v_u_16.skip
	local v138 = UDim2.new
	local v139 = -v136
	local v140 = (v109 - v131) / 2
	local v141 = math.floor(v140)
	v137.Position = v138(1, v139, 0, (math.max(v141, 6)))
	local v142 = v_u_16.skip
	local v143 = v113 * 16 + 0.5
	local v144 = math.floor(v143)
	v142.TextSize = math.max(v144, 14)
	v_u_16.skip.TextTransparency = 1 - p99
	v_u_16.skip.BackgroundTransparency = 1 - p99 * 0.55
	v_u_16.stroke.Transparency = 1 - p99 * 0.7
end
local function v_u_149() -- name: sceneFolder
	local v146 = workspace:FindFirstChild("HushLocal")
	if not v146 then
		v146 = Instance.new("Folder")
		v146.Name = "HushLocal"
		v146.Parent = workspace
	end
	local v147 = v146:FindFirstChild("Entry")
	if v147 then
		v147:Destroy()
	end
	local v148 = Instance.new("Folder")
	v148.Name = "Entry"
	v148.Parent = v146
	return v148
end
local function v_u_165(p150) -- name: isoCam
	-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) v_u_4, (ref) v_u_8
	local v151 = v_u_5 and v_u_5.controllers
	if v151 then
		v151 = v_u_5.controllers.Camera
	end
	if not v151 or v151._broken then
		v151 = nil
	end
	local v152 = 0.7853981633974483
	local v153 = 104
	local v154 = 22
	local v155
	if v151 then
		local v156 = v151.targetYaw
		if type(v156) == "function" then
			local v157 = v151.targetYaw
			local v158
			v158, v155 = pcall(v157)
			if v158 then
				if not v_u_9.finite(v155) then
					v155 = v152
				end
			else
				v155 = v152
			end
		else
			v155 = v152
		end
		local v159 = v151.zoomLevel
		local v160
		if type(v159) == "function" then
			v160 = v151.zoomLevel()
		else
			v160 = nil
		end
		local v161
		if v151.ZOOM_LEVELS and v160 then
			v161 = v151.ZOOM_LEVELS[v160]
		else
			v161 = nil
		end
		if v161 and (v_u_9.finite(v161.dist) and v_u_9.finite(v161.fov)) then
			v153 = v161.dist
			v154 = v161.fov
		end
	else
		v155 = v152
	end
	local v162 = p150.isoFocus
	local v163 = v_u_4.Character
	if v163 then
		v163 = v163:FindFirstChild("HumanoidRootPart")
	end
	if v163 and v163:IsA("BasePart") then
		local v164 = v163.Position
		v162 = {
			["x"] = v164.X,
			["y"] = v164.Y - 0.6,
			["z"] = v164.Z
		}
		p150.isoFocus = v162
	end
	return v_u_8.iso(v162, v155, v153, v154)
end
local function v_u_188(p_u_166, p167) -- name: giveBack
	-- upvalues: (ref) v_u_5, (copy) v_u_4, (ref) v_u_12, (ref) v_u_10, (ref) v_u_20
	local function v169()
		-- upvalues: (ref) v_u_5, (copy) p_u_166
		local v168 = v_u_5 and v_u_5.controllers
		if v168 then
			v168 = v_u_5.controllers.Camera
		end
		if not v168 or v168._broken then
			v168 = nil
		end
		if v168 and p_u_166.camOverride then
			v168.setOverride(nil)
		end
	end
	pcall(v169)
	p_u_166.camOverride = false
	if p_u_166.cleanSet then
		pcall(function()
			-- upvalues: (copy) p_u_166
			p_u_166.FilmClean.setClean(false)
		end)
		p_u_166.cleanSet = false
	end
	if p_u_166.exemptSet then
		pcall(function()
			-- upvalues: (copy) p_u_166
			p_u_166.FilmClean.exempt("HushEntry", false)
		end)
		p_u_166.exemptSet = false
	end
	if p_u_166.exemptPanel then
		pcall(function()
			-- upvalues: (copy) p_u_166
			p_u_166.FilmClean.exempt("HushFilm", false)
		end)
		p_u_166.exemptPanel = false
	end
	if p_u_166.inputOff then
		local function v172()
			-- upvalues: (ref) v_u_5
			local v170 = v_u_5 and v_u_5.controllers
			if v170 then
				v170 = v_u_5.controllers.Input
			end
			if not v170 or v170._broken then
				v170 = nil
			end
			if v170 then
				local v171 = v170.setEnabled
				if type(v171) == "function" then
					v170.setEnabled(true)
				end
			end
		end
		pcall(v172)
		p_u_166.inputOff = false
	end
	local v_u_173 = false
	local function v177()
		-- upvalues: (ref) v_u_5, (ref) v_u_173, (ref) v_u_4
		local v174 = v_u_5 and v_u_5.lib
		if v174 then
			v174 = v_u_5.lib.FpCam
		end
		local v175
		if v_u_4:GetAttribute("ViewMode") == "fptp" and v174 ~= nil then
			local v176 = v174.side
			if type(v176) == "function" then
				v175 = v174.side() == "fp"
			else
				v175 = false
			end
		else
			v175 = false
		end
		v_u_173 = v175
	end
	pcall(v177)
	local function v_u_182() -- name: releaseHide
		-- upvalues: (ref) v_u_12, (ref) v_u_5
		local function v178()
			-- upvalues: (ref) v_u_12
			v_u_12.stop()
		end
		pcall(v178)
		local function v181()
			-- upvalues: (ref) v_u_5
			local v179 = v_u_5 and v_u_5.lib
			if v179 then
				v179 = v_u_5.lib.FpBodyHide
			end
			if v179 then
				local v180 = v179.reassert
				if type(v180) == "function" then
					v179.reassert()
				end
			end
		end
		pcall(v181)
	end
	if v_u_173 then
		task.spawn(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_182
			local v183 = os.clock()
			local v184 = v_u_5
			if v184 then
				v184 = v_u_5.lib
				if v184 then
					v184 = v_u_5.lib.FpBodyHide
				end
			end
			while os.clock() - v183 < 0.5 do
				if v184 then
					local v185 = v184.active
					if type(v185) == "function" and v184.active() then
						break
					end
				end
				task.wait()
			end
			v_u_182()
		end)
	else
		v_u_182()
	end
	for _, v186 in p_u_166.puppets do
		local v187 = v_u_10.destroy
		pcall(v187, v186)
	end
	p_u_166.puppets = {}
	v_u_20 = p167
end
local function v_u_206(p189) -- name: finish
	-- upvalues: (ref) v_u_13, (copy) v_u_188, (ref) v_u_5, (ref) v_u_8, (ref) v_u_14, (ref) v_u_11, (copy) v_u_15, (copy) v_u_3, (ref) v_u_16, (copy) v_u_86, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_4
	local v_u_190 = v_u_13
	if v_u_190 then
		v_u_13 = nil
		v_u_188(v_u_190, p189)
		if v_u_190.loadingHeld then
			local function v193()
				-- upvalues: (ref) v_u_5
				local v191 = v_u_5 and v_u_5.controllers
				if v191 then
					v191 = v_u_5.controllers.Loading
				end
				if not v191 or v191._broken then
					v191 = nil
				end
				if v191 then
					local v192 = v191.holdExtra
					if type(v192) == "function" then
						v191.holdExtra("entry", false)
					end
				end
			end
			pcall(v193)
			v_u_190.loadingHeld = false
		end
		local v194
		if p189 == "done" and v_u_8.tail(v_u_190.g) > 0 then
			v194 = v_u_190.props ~= nil
		else
			v194 = false
		end
		if v194 then
			if v_u_14 then
				local v195 = v_u_11.destroy
				local v196 = v_u_14.props
				pcall(v195, v196)
				local function v197()
					-- upvalues: (ref) v_u_14
					v_u_14.folder:Destroy()
				end
				pcall(v197)
				v_u_14 = nil
			end
			v_u_14 = {
				["props"] = v_u_190.props,
				["folder"] = v_u_190.folder,
				["g"] = v_u_190.g,
				["t0"] = v_u_190.t0,
				["endsAt"] = os.clock() + v_u_8.tail(v_u_190.g)
			}
		else
			local v198 = v_u_11.destroy
			local v199 = v_u_190.props
			pcall(v198, v199)
			pcall(function()
				-- upvalues: (copy) v_u_190
				v_u_190.folder:Destroy()
			end)
		end
		if p189 == "done" then
			if v_u_16 then
				local function v200()
					-- upvalues: (ref) v_u_16
					v_u_16.gui:Destroy()
				end
				pcall(v200)
				v_u_16 = nil
			end
			v_u_15.on = false
			v_u_15.fadeStart = nil
		else
			v_u_15.on = false
			v_u_15.fadeStart = os.clock()
			v_u_15.fadeLen = v_u_3.SKIP_FADE
			v_u_15.alpha = 1
			if not (v_u_16 and v_u_16.gui.Parent) then
				v_u_16 = v_u_86()
			end
		end
		if v_u_17 then
			v_u_17:Disconnect()
			v_u_17 = nil
		end
		v_u_18 = false
		v_u_19 = (1 / 0)
		local v201 = v_u_13 ~= nil and true or (v_u_15.on or v_u_15.fadeStart ~= nil)
		if v_u_4:GetAttribute("EntryActive") ~= v201 then
			v_u_4:SetAttribute("EntryActive", v201)
		end
		local v202 = v_u_190.onEnd
		if v202 then
			local v203 = v_u_190.plan.id
			local v204, v205 = pcall(v202, p189, v203)
			if not v204 then
				warn("[EntryCine] onEnd failed:", v205)
			end
		end
	end
end
function v_u_3.stop(p207) -- name: stop
	-- upvalues: (ref) v_u_13, (copy) v_u_206, (copy) v_u_15, (copy) v_u_3
	if v_u_13 then
		v_u_206(p207 or "abort")
	elseif v_u_15.on then
		v_u_3.cover(false)
	end
end
local function v_u_210(p208, p209) -- name: bannerAlpha
	-- upvalues: (ref) v_u_9, (copy) v_u_3
	return v_u_9.smooth(v_u_9.unlerp(v_u_3.BANNER_IN, v_u_3.BANNER_IN + 0.5, p208)) * (1 - v_u_9.smooth(v_u_9.unlerp(p209.dur - p209.hand - 0.3, p209.dur - p209.hand + 0.2, p208)))
end
local function v_u_218(p211, p212, p213) -- name: updateUi
	-- upvalues: (ref) v_u_16, (copy) v_u_86, (ref) v_u_9, (ref) v_u_7, (copy) v_u_145, (copy) v_u_210
	if not (v_u_16 and v_u_16.gui.Parent) then
		v_u_16 = v_u_86()
	end
	local v214 = p211.g
	local v215 = p213.fade
	if p212 < 0 then
		v215 = p211.covered and 1 or v_u_9.smooth(v_u_9.unlerp(-0.55, -0.1, p212))
	end
	local v216
	if p211.hasCam then
		v216 = 1 - v_u_9.smooth(v_u_9.unlerp(v214.dur - v214.hand, v214.dur - 0.05, p212))
		if p212 < 0 then
			v216 = v215
		end
	else
		v216 = 0
	end
	local v217 = (v_u_7.TUNE.SKIP_AFTER > p212 or p211.noSkip) and 0 or v_u_9.smooth(v_u_9.unlerp(v_u_7.TUNE.SKIP_AFTER, v_u_7.TUNE.SKIP_AFTER + 0.4, p212)) * (1 - v_u_9.smooth(v_u_9.unlerp(v214.dur - v214.hand, v214.dur - 0.2, p212)))
	v_u_145(v216, not p211.hasCam and 0 or v_u_210(p212, v214), v217, v215)
end
local function v_u_246(p219, p220) -- name: stepScene
	-- upvalues: (copy) v_u_206, (ref) v_u_7, (ref) v_u_19, (ref) v_u_18, (copy) v_u_165, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_218, (ref) v_u_16, (ref) v_u_6
	local v221 = workspace:GetServerTimeNow() - p219.t0
	p219.t = v221
	p219.lastFrame = os.clock()
	if p219.g.dur <= v221 then
		v_u_206("done")
		return nil, nil
	end
	if v_u_7.TUNE.SKIP_AFTER <= v221 then
		v_u_19 = 0
	end
	if v_u_18 and v_u_7.TUNE.SKIP_AFTER <= v221 then
		v_u_206("skip")
		return nil, nil
	end
	local v222 = v_u_165(p219)
	local v223 = v_u_8.sample(p219.g, v221, v222)
	for v224, v225 in v223.actors do
		local v226 = p219.puppets[v224]
		if not v226 then
			continue
		end
		v_u_10.apply(v226, v225)
	end
	if p219.props then
		v_u_11.update(p219.props, v223.props, p220)
	end
	while p219.cueIdx <= #p219.cues and p219.cues[p219.cueIdx].t <= v221 do
		local v227 = p219.cues[p219.cueIdx]
		p219.cueIdx = p219.cueIdx + 1
		if not p219.props then
			continue
		end
		local v228 = v_u_11.cue
		local v229 = p219.props
		local v230 = v227.name
		pcall(v228, v229, v230)
	end
	p219.hideAcc = p219.hideAcc + p220
	if p219.hideAcc > 0.12 then
		p219.hideAcc = 0
		v_u_12.step()
	end
	v_u_218(p219, v221, v223)
	if v_u_16 and not p219.bannerSet then
		p219.bannerSet = true
		local v231 = v_u_16.title
		local v232 = p219.plan.ti
		if v_u_6 then
			local v233 = v_u_6.track
			if type(v233) == "function" then
				local v234 = v_u_6.track
				local v235, v236 = pcall(v234, v232, 1)
				if v235 and type(v236) == "string" then
					v232 = v236
				end
			end
		end
		v231.Text = v232
		v_u_16.sub.Text = v_u_7.sub(p219.plan.k, p219.g.n)
	end
	if not v223.cam then
		return nil, nil
	end
	local v237 = v223.cam
	local v238 = v237.px
	local v239 = v237.py
	local v240 = v237.pz
	local v241 = Vector3.new(v238, v239, v240)
	local v242 = v237.tx
	local v243 = v237.ty
	local v244 = v237.tz
	local v245 = Vector3.new(v242, v243, v244)
	if (v245 - v241).Magnitude < 0.05 then
		v245 = v241 + Vector3.new(0, -0.05, -1)
	end
	return CFrame.lookAt(v241, v245), v237.fov
end
local function v_u_253(p247, p248) -- name: guardedStep
	-- upvalues: (copy) v_u_246, (ref) v_u_13, (copy) v_u_206
	local v249 = v_u_246
	local v250, v251, v252 = pcall(v249, p247, p248)
	if v250 then
		return v251, v252
	end
	warn("[EntryCine] frame failed:", v251)
	if v_u_13 == p247 then
		v_u_206("error")
	end
	return nil, nil
end
function v_u_3.start(p_u_254, p255) -- name: start
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (copy) v_u_15, (copy) v_u_149, (ref) v_u_16, (copy) v_u_86, (ref) v_u_10, (ref) v_u_12, (copy) v_u_206, (ref) v_u_19, (ref) v_u_18, (ref) v_u_17, (copy) v_u_2, (copy) v_u_253, (copy) v_u_218, (copy) v_u_4
	local v256 = p255 or {}
	if v_u_13 then
		return false
	end
	if v_u_14 then
		local v257 = v_u_11.destroy
		local v258 = v_u_14.props
		pcall(v257, v258)
		local function v259()
			-- upvalues: (ref) v_u_14
			v_u_14.folder:Destroy()
		end
		pcall(v259)
		v_u_14 = nil
	end
	local v_u_260 = v_u_8.geo(p_u_254)
	local v261 = v_u_7.normMode(v256.mode)
	local v262 = v_u_5 and v_u_5.controllers
	if v262 then
		v262 = v_u_5.controllers.Camera
	end
	if not v262 or v262._broken then
		v262 = nil
	end
	local v263 = v_u_15.on or v_u_15.fadeStart ~= nil
	local v_u_264 = {
		["plan"] = nil,
		["g"] = nil,
		["t0"] = nil,
		["t"] = nil,
		["mode"] = nil,
		["onEnd"] = nil,
		["preview"] = nil,
		["noSkip"] = false,
		["puppets"] = nil,
		["props"] = nil,
		["folder"] = nil,
		["cues"] = nil,
		["cueIdx"] = 1,
		["lastFrame"] = nil,
		["hideAcc"] = 0,
		["bannerSet"] = false,
		["hasCam"] = false,
		["camOverride"] = false,
		["cleanSet"] = false,
		["exemptSet"] = false,
		["exemptPanel"] = false,
		["inputOff"] = false,
		["loadingHeld"] = false,
		["covered"] = nil,
		["isoFocus"] = nil,
		["FilmClean"] = nil,
		["plan"] = p_u_254,
		["g"] = v_u_260,
		["t0"] = workspace:GetServerTimeNow() - (v256.offset or 0),
		["t"] = v256.offset or 0,
		["mode"] = v261,
		["onEnd"] = v256.onEnd,
		["preview"] = v256.preview == true,
		["puppets"] = {},
		["cues"] = v_u_8.cues(v_u_260),
		["lastFrame"] = os.clock(),
		["covered"] = v263,
		["isoFocus"] = {
			["x"] = v_u_260.places[1].x,
			["y"] = v_u_260.places[1].y + 2.4,
			["z"] = v_u_260.places[1].z
		}
	}
	if v262 then
		local v265 = v262.hasOverride
		if type(v265) == "function" and v262.hasOverride() then
			if v256.onEnd then
				local v266 = v256.onEnd
				local v267 = p_u_254.id
				pcall(v266, "busy", v267)
			end
			return false
		end
	end
	v_u_264.hasCam = v_u_8.sample(v_u_260, v_u_260.dur * 0.5, nil).cam ~= nil
	v_u_264.folder = v_u_149()
	local function v277()
		-- upvalues: (ref) v_u_16, (ref) v_u_86, (copy) v_u_264, (copy) v_u_260, (ref) v_u_10, (ref) v_u_5, (copy) p_u_254, (ref) v_u_11, (ref) v_u_12
		if not (v_u_16 and v_u_16.gui.Parent) then
			v_u_16 = v_u_86()
		end
		if v_u_264.hasCam then
			local v268 = {}
			for v269 = 1, v_u_260.n do
				local v270 = v_u_10.new(v_u_5, v_u_264.folder, p_u_254, v269)
				v_u_264.puppets[v269] = v270
				if not v270 then
					continue
				end
				local v271 = v_u_260.uids[v269]
				table.insert(v268, v271)
			end
			if #v268 == 0 then
				error("no puppet could be built")
			end
			v_u_264.props = v_u_11.new(v_u_5, v_u_264.folder, v_u_260)
			v_u_12.start(v268)
			local v272 = v_u_5.lib.FilmClean
			v_u_264.FilmClean = v272
			v272.exempt("HushEntry", true)
			v_u_264.exemptSet = true
			if p_u_254.test == true and not v272.isExempt("HushFilm") then
				v272.exempt("HushFilm", true)
				v_u_264.exemptPanel = true
			end
			if not v272.isClean() then
				v272.setClean(true)
				v_u_264.cleanSet = true
			end
			local v273 = v_u_5 and v_u_5.controllers
			if v273 then
				v273 = v_u_5.controllers.Input
			end
			if not v273 or v273._broken then
				v273 = nil
			end
			if v273 then
				local v274 = v273.setEnabled
				if type(v274) == "function" then
					v273.setEnabled(false)
					v_u_264.inputOff = true
				end
			end
		end
		local v275 = v_u_5 and v_u_5.controllers
		if v275 then
			v275 = v_u_5.controllers.Loading
		end
		if not v275 or v275._broken then
			v275 = nil
		end
		if v275 then
			local v276 = v275.holdExtra
			if type(v276) == "function" then
				v275.holdExtra("entry", true, v_u_260.dur + 8)
				v_u_264.loadingHeld = true
			end
		end
	end
	local v278, v279 = pcall(v277)
	if not v278 then
		warn("[EntryCine] could not start:", v279)
		v_u_13 = v_u_264
		v_u_206("error")
		return false
	end
	v_u_13 = v_u_264
	while v_u_264.cueIdx <= #v_u_264.cues and v_u_264.cues[v_u_264.cueIdx].t < (v256.offset or 0) - 0.3 do
		v_u_264.cueIdx = v_u_264.cueIdx + 1
	end
	v_u_15.on = false
	v_u_15.fadeStart = nil
	local v280 = os.clock()
	local v281 = v_u_7.TUNE.SKIP_AFTER - (v256.offset or 0)
	v_u_19 = v280 + math.max(v281, 0)
	v_u_18 = false
	if not v_u_17 then
		v_u_17 = v_u_2.InputBegan:Connect(function(p282)
			-- upvalues: (ref) v_u_19, (ref) v_u_18
			if os.clock() < v_u_19 then
				return
			else
				local v283 = p282.UserInputType
				local v284 = v283.Name
				local v285 = string.sub(v284, 1, 7) == "Gamepad"
				if not v285 or p282.KeyCode ~= Enum.KeyCode.Thumbstick1 and p282.KeyCode ~= Enum.KeyCode.Thumbstick2 then
					if v283 == Enum.UserInputType.Keyboard or (v283 == Enum.UserInputType.MouseButton1 or (v283 == Enum.UserInputType.MouseButton2 or (v283 == Enum.UserInputType.Touch or v285))) then
						v_u_18 = true
					end
				end
			end
		end)
	end
	if v_u_264.hasCam and v262 then
		v_u_264.camOverride = true
		v262.setOverride(function(p286)
			-- upvalues: (ref) v_u_13, (copy) v_u_264, (ref) v_u_253
			if v_u_13 == v_u_264 then
				return v_u_253(v_u_264, p286)
			else
				return nil, nil
			end
		end)
	end
	local v287 = v_u_218
	local v288 = v_u_264.t
	v287(v_u_264, math.min(v288, -0.001), {
		["fade"] = 1
	})
	local v289 = v_u_13 ~= nil or v_u_15.on or v_u_15.fadeStart ~= nil
	if v_u_4:GetAttribute("EntryActive") ~= v289 then
		v_u_4:SetAttribute("EntryActive", v289)
	end
	return true
end
function v_u_3.cover(p290) -- name: cover
	-- upvalues: (ref) v_u_13, (copy) v_u_15, (ref) v_u_16, (copy) v_u_86, (ref) v_u_5, (ref) v_u_7, (copy) v_u_145, (copy) v_u_3, (copy) v_u_4
	if p290 then
		if v_u_13 then
			return
		end
		v_u_15.on = true
		v_u_15.fadeStart = nil
		v_u_15.alpha = 1
		if not (v_u_16 and v_u_16.gui.Parent) then
			v_u_16 = v_u_86()
		end
		local function v293()
			-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_15
			local v291 = v_u_5 and v_u_5.controllers
			if v291 then
				v291 = v_u_5.controllers.Loading
			end
			if not v291 or v291._broken then
				v291 = nil
			end
			if v291 then
				local v292 = v291.holdExtra
				if type(v292) == "function" then
					v291.holdExtra("entry_cover", true, v_u_7.TUNE.ABS_MAX + 4)
					v_u_15.loadingHeld = true
				end
			end
		end
		pcall(v293)
		if v_u_16 then
			v_u_145(0, 0, 0, 1)
		end
	elseif v_u_15.on then
		v_u_15.on = false
		v_u_15.fadeStart = os.clock()
		v_u_15.fadeLen = v_u_3.COVER_FADE
	end
	local v294 = v_u_13 ~= nil or v_u_15.on or v_u_15.fadeStart ~= nil
	if v_u_4:GetAttribute("EntryActive") ~= v294 then
		v_u_4:SetAttribute("EntryActive", v294)
	end
end
function v_u_3.covered() -- name: covered
	-- upvalues: (copy) v_u_15
	return v_u_15.on
end
function v_u_3.tick(p_u_295) -- name: tick
	-- upvalues: (ref) v_u_13, (copy) v_u_246, (copy) v_u_206, (ref) v_u_14, (ref) v_u_8, (ref) v_u_11, (copy) v_u_15, (ref) v_u_5, (ref) v_u_16, (ref) v_u_9, (copy) v_u_145, (copy) v_u_4, (copy) v_u_86
	if v_u_13 then
		if not v_u_13.camOverride or os.clock() - v_u_13.lastFrame > 0.5 then
			local v296 = v_u_13
			local v297 = v_u_246
			local v298, v299, _ = pcall(v297, v296, p_u_295)
			if v298 then
				return
			end
			warn("[EntryCine] frame failed:", v299)
			if v_u_13 == v296 then
				v_u_206("error")
			end
		end
	else
		if v_u_14 then
			local function v302()
				-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_11, (copy) p_u_295
				local v300 = workspace:GetServerTimeNow() - v_u_14.t0
				local v301 = v_u_8.sample(v_u_14.g, v300, nil)
				v_u_11.update(v_u_14.props, v301.props, p_u_295)
			end
			if (not pcall(v302) or (os.clock() >= v_u_14.endsAt or v_u_11.finished(v_u_14.props))) and v_u_14 then
				local v303 = v_u_11.destroy
				local v304 = v_u_14.props
				pcall(v303, v304)
				local function v305()
					-- upvalues: (ref) v_u_14
					v_u_14.folder:Destroy()
				end
				pcall(v305)
				v_u_14 = nil
			end
		end
		if v_u_15.fadeStart then
			local v306 = os.clock() - v_u_15.fadeStart
			local v307 = v_u_15.fadeLen
			local v308 = v306 / math.max(v307, 0.05)
			if v308 >= 1 then
				v_u_15.fadeStart = nil
				v_u_15.alpha = 0
				if v_u_15.loadingHeld then
					v_u_15.loadingHeld = false
					local function v311()
						-- upvalues: (ref) v_u_5
						local v309 = v_u_5 and v_u_5.controllers
						if v309 then
							v309 = v_u_5.controllers.Loading
						end
						if not v309 or v309._broken then
							v309 = nil
						end
						if v309 then
							local v310 = v309.holdExtra
							if type(v310) == "function" then
								v309.holdExtra("entry_cover", false)
							end
						end
					end
					pcall(v311)
				end
				if v_u_16 then
					local function v312()
						-- upvalues: (ref) v_u_16
						v_u_16.gui:Destroy()
					end
					pcall(v312)
					v_u_16 = nil
				end
			else
				v_u_15.alpha = 1 - v_u_9.smooth(v308)
				if v_u_16 then
					v_u_145(0, 0, 0, v_u_15.alpha)
				end
			end
			local v313 = v_u_13 ~= nil or v_u_15.on or v_u_15.fadeStart ~= nil
			if v_u_4:GetAttribute("EntryActive") ~= v313 then
				v_u_4:SetAttribute("EntryActive", v313)
			end
		elseif v_u_15.on then
			if not (v_u_16 and v_u_16.gui.Parent or v_u_16 and v_u_16.gui.Parent) then
				v_u_16 = v_u_86()
			end
			if v_u_16 then
				v_u_145(0, 0, 0, 1)
			end
		end
		if not (v_u_15.on or (v_u_15.fadeStart or v_u_13)) then
			if v_u_15.loadingHeld then
				v_u_15.loadingHeld = false
				local function v316()
					-- upvalues: (ref) v_u_5
					local v314 = v_u_5 and v_u_5.controllers
					if v314 then
						v314 = v_u_5.controllers.Loading
					end
					if not v314 or v314._broken then
						v314 = nil
					end
					if v314 then
						local v315 = v314.holdExtra
						if type(v315) == "function" then
							v314.holdExtra("entry_cover", false)
						end
					end
				end
				pcall(v316)
			end
			local v317 = v_u_13 ~= nil or v_u_15.on or v_u_15.fadeStart ~= nil
			if v_u_4:GetAttribute("EntryActive") ~= v317 then
				v_u_4:SetAttribute("EntryActive", v317)
			end
		end
	end
end
function v_u_3.active() -- name: active
	-- upvalues: (ref) v_u_13
	return v_u_13 ~= nil
end
function v_u_3.activeId() -- name: activeId
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		return v_u_13.plan.id
	else
		return nil
	end
end
function v_u_3.status() -- name: status
	-- upvalues: (ref) v_u_13, (copy) v_u_15, (ref) v_u_14, (ref) v_u_20, (ref) v_u_12
	local v318 = {
		["active"] = v_u_13 ~= nil
	}
	local v319
	if v_u_13 then
		v319 = v_u_13.plan.id
	else
		v319 = nil
	end
	v318.id = v319
	local v320
	if v_u_13 then
		v320 = v_u_13.plan.k
	else
		v320 = nil
	end
	v318.kind = v320
	local v321
	if v_u_13 then
		v321 = v_u_13.t
	else
		v321 = nil
	end
	v318.t = v321
	v318.covered = v_u_15.on
	v318.fading = v_u_15.fadeStart ~= nil
	v318.tail = v_u_14 ~= nil
	v318.last = v_u_20
	v318.puppets = v_u_13 and #v_u_13.puppets or 0
	v318.hidden = v_u_12.count()
	return v318
end
function v_u_3.sample(p322, p323, p324)
	-- upvalues: (ref) v_u_8
	return v_u_8.sample(p322, p323, p324)
end
function v_u_3.geo(p325)
	-- upvalues: (ref) v_u_8
	return v_u_8.geo(p325)
end
function v_u_3.preview(p326, p327) -- name: preview
	-- upvalues: (ref) v_u_13, (ref) v_u_7, (copy) v_u_4, (ref) v_u_9, (ref) v_u_10, (copy) v_u_3
	if v_u_13 then
		return "an entry is already playing"
	end
	if not v_u_7.isKind(p326) then
		local v328 = table.concat
		local v329 = {}
		local v330 = "unknown kind ("
		for _, v331 in v_u_7.KINDS do
			local v332 = v331.id
			table.insert(v329, v332)
		end
		return v330 .. v328(v329, ", ") .. ")"
	end
	local v333 = v_u_4.Character
	if v333 then
		v333 = v333:FindFirstChild("HumanoidRootPart")
	end
	if not (v333 and v333:IsA("BasePart")) then
		return "no character"
	end
	local v334 = math.floor(p327 or 1)
	local v335 = v_u_7.TUNE.MAX_MEMBERS
	local v336 = math.clamp(v334, 1, v335)
	local v337 = v333.CFrame.LookVector
	local v338 = v_u_9.yawOfDir(v337.X, v337.Z)
	local v339 = v333.Position.Y - 3
	local v340 = v_u_10.groundAt(v333.Position.X, v333.Position.Y, v333.Position.Z, 2, 12) or v339
	local v341 = {}
	for v342, v343 in v_u_7.formation(v336, v333.Position.X, v340, v333.Position.Z, v338) do
		v341[v342] = {
			["u"] = v342 ~= 1 and 0 or v_u_4.UserId,
			["x"] = v343.x,
			["y"] = v343.y,
			["z"] = v343.z
		}
	end
	local v344, v345 = v_u_7.plan({
		["raidId"] = "preview",
		["squadId"] = "local",
		["mapId"] = "stillwater",
		["markerId"] = "here",
		["kind"] = nil,
		["seed"] = 1,
		["at"] = nil,
		["yaw"] = nil,
		["side"] = 1,
		["members"] = nil,
		["test"] = true,
		["kind"] = p326,
		["at"] = workspace:GetServerTimeNow() + 0.3,
		["yaw"] = v338,
		["members"] = v341
	})
	if not v344 then
		return "plan refused: " .. tostring(v345)
	end
	local v346 = v_u_7.decode(v344)
	return not v346 and "plan not valid" or (not v_u_3.start(v346, {
		["mode"] = "full",
		["offset"] = -0.3,
		["preview"] = true
	}) and "could not start" or string.format("preview %s n=%d %.1f s", p326, v336, v346.dur))
end
function v_u_3.init(p_u_347) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_3
	v_u_5 = p_u_347
	local v348, v349 = pcall(function()
		-- upvalues: (copy) p_u_347
		return p_u_347.shared.Theme
	end)
	if not v348 then
		v349 = nil
	end
	v_u_6 = v349
	v_u_7 = p_u_347.shared.EntryRules
	v_u_8 = p_u_347.lib.EntryScene
	v_u_9 = p_u_347.lib.EntryMath
	v_u_10 = p_u_347.lib.EntryRig
	v_u_11 = p_u_347.lib.EntryProps
	v_u_12 = p_u_347.lib.EntryHide
	p_u_347.command("entry.preview", function(p350)
		-- upvalues: (ref) v_u_3
		local v351 = v_u_3.preview
		local v352 = p350[1] or "walk_in"
		local v353 = p350[2]
		return v351(v352, tonumber(v353) or 1)
	end)
	p_u_347.command("entry.cine", function(p354)
		-- upvalues: (ref) v_u_3
		if p354[1] == "stop" then
			v_u_3.stop("skip")
			return "stopped"
		end
		local v355 = v_u_3.status()
		local v356 = string.format
		local v357 = v355.active
		local v358 = tostring(v357)
		local v359 = v355.id
		local v360 = tostring(v359)
		local v361 = v355.kind
		local v362 = tostring(v361)
		local v363 = not v355.t and "-" or string.format("%.2f", v355.t)
		local v364 = v355.covered
		local v365 = tostring(v364)
		local v366 = v355.fading
		local v367 = tostring(v366)
		local v368 = v355.tail
		local v369 = tostring(v368)
		local v370 = v355.puppets
		local v371 = v355.hidden
		local v372 = v355.last
		return v356("active=%s id=%s kind=%s t=%s covered=%s fading=%s tail=%s puppets=%d hidden=%d last=%s", v358, v360, v362, v363, v365, v367, v369, v370, v371, (tostring(v372)))
	end)
end
return v_u_3