-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmAC

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.number(p6) -- name: number
	local v7 = tonumber(p6)
	if v7 == nil or (v7 ~= v7 or v7 < 0) then
		return "0"
	end
	local v8 = v7 + 0.5
	local v9 = math.floor(v8)
	local v10 = tostring(v9)
	local v11 = string.gsub(string.reverse(v10), "(%d%d%d)", "%1,")
	local v12 = string.reverse(v11)
	return string.gsub(v12, "^,", "")
end
function v_u_4.ago(p13) -- name: ago
	local v14 = tonumber(p13)
	if v14 == nil or v14 ~= v14 then
		return "never"
	else
		local v15 = v14 < 0 and 0 or v14
		if v15 < 60 then
			return "just now"
		elseif v15 < 3600 then
			local v16 = v15 / 60
			return ("%d min ago"):format((math.floor(v16)))
		elseif v15 < 86400 then
			local v17 = v15 / 3600
			return ("%d h ago"):format((math.floor(v17)))
		else
			local v18 = v15 / 86400
			return ("%d d ago"):format((math.floor(v18)))
		end
	end
end
function v_u_4.flaggedText(p19, p20) -- name: flagText
	-- upvalues: (copy) v_u_4
	local v21 = p19.name or "?"
	local v22 = tostring(v21)
	local v23 = v22 == "" and "?" or v22
	local v24 = "%s  \194\183  %d  \194\183  score %.1f  \194\183  %s  \194\183  %s%s%s"
	local v25 = p19.uid
	local v26 = tonumber(v25)
	local v27
	if v26 == nil or v26 ~= v26 then
		v27 = 0
	else
		local v28 = v26 + 0.5
		v27 = math.floor(v28)
	end
	local v29 = p19.score
	local v30 = tonumber(v29) or 0
	local v31 = p19.top == "" and "none" or (p19.top or "none")
	local v32 = tostring(v31)
	local v33 = v_u_4.ago
	local v34 = p19.last
	local v35 = v33(p20 - (tonumber(v34) or 0))
	local v36 = p19.reviewed and "  \194\183  reviewed" or ""
	local v37 = p19.reports
	local v38
	if (tonumber(v37) or 0) > 0 then
		local v39 = "  \194\183  %d reports"
		local v40 = p19.reports
		local v41 = tonumber(v40)
		local v42
		if v41 == nil or v41 ~= v41 then
			v42 = 0
		else
			local v43 = v41 + 0.5
			v42 = math.floor(v43)
		end
		v38 = v39:format(v42)
	else
		v38 = ""
	end
	return v24:format(v23, v27, v30, v32, v35, v36, v38)
end
function v_u_4.flaggedLines(p44, p45) -- name: flaggedLines
	-- upvalues: (copy) v_u_4
	local v46 = p44.name or "?"
	local v47 = tostring(v46)
	local v48 = v47 == "" and "?" or v47
	local v49 = "%s  \194\183  %d  \194\183  score %.1f"
	local v50 = p44.uid
	local v51 = tonumber(v50)
	local v52
	if v51 == nil or v51 ~= v51 then
		v52 = 0
	else
		local v53 = v51 + 0.5
		v52 = math.floor(v53)
	end
	local v54 = p44.score
	local v55 = v49:format(v48, v52, tonumber(v54) or 0)
	local v56 = "top reason %s  \194\183  last seen %s%s%s"
	local v57 = p44.top == "" and "none" or (p44.top or "none")
	local v58 = tostring(v57)
	local v59 = v_u_4.ago
	local v60 = p44.last
	local v61 = v59(p45 - (tonumber(v60) or 0))
	local v62 = p44.reviewed and "  \194\183  reviewed" or ""
	local v63 = p44.reports
	local v64
	if (tonumber(v63) or 0) > 0 then
		local v65 = "  \194\183  %d reports"
		local v66 = p44.reports
		local v67 = tonumber(v66)
		local v68
		if v67 == nil or v67 ~= v67 then
			v68 = 0
		else
			local v69 = v67 + 0.5
			v68 = math.floor(v69)
		end
		v64 = v65:format(v68)
	else
		v64 = ""
	end
	return v55, v56:format(v58, v61, v62, v64)
end
function v_u_4.headLines(p70) -- name: headLines
	-- upvalues: (copy) v_u_4
	local v71 = {}
	if type(p70) ~= "table" then
		table.insert(v71, {
			["name"] = "State",
			["text"] = "Reading the anti cheat ...",
			["kind"] = "muted"
		})
		return v71
	end
	local v72 = p70.mode or "?"
	local v73 = tostring(v72)
	local v74 = p70.selfOff == true and "warn" or (v73 == "shadow" and "ok" or "muted")
	local v75 = {
		["name"] = "State",
		["text"] = nil,
		["kind"] = nil
	}
	local v76 = "ANTI CHEAT %s  \194\183  build %s  \194\183  document %s v%d (%s)  \194\183  store %s%s"
	local v77 = string.upper(v73)
	local v78 = p70.build
	local v79 = tostring(v78)
	local v80 = p70.doc or "not read"
	local v81 = tostring(v80)
	local v82 = p70.docV
	local v83 = tonumber(v82)
	local v84
	if v83 == nil or v83 ~= v83 then
		v84 = 0
	else
		local v85 = v83 + 0.5
		v84 = math.floor(v85)
	end
	local v86 = p70.docBy == "" and "nobody" or (p70.docBy or "nobody")
	local v87 = tostring(v86)
	local v88 = p70.backend or "?"
	v75.text = v76:format(v77, v79, v81, v84, v87, tostring(v88), p70.selfOff == true and "  \194\183  SWITCHED OFF BY ITS OWN ERRORS" or "")
	v75.kind = v74
	table.insert(v71, v75)
	local v89 = {
		["name"] = "Counts",
		["text"] = nil,
		["kind"] = "text"
	}
	local v90 = "players %d  \194\183  events %d  \194\183  skipped by ping or hitch %d  \194\183  over the cap %d  \194\183  flags raised %d  \194\183  flagged in the list %d  \194\183  watched %d"
	local v91 = p70.players
	local v92 = tonumber(v91)
	local v93
	if v92 == nil or v92 ~= v92 then
		v93 = 0
	else
		local v94 = v92 + 0.5
		v93 = math.floor(v94)
	end
	local v95 = p70.events
	local v96 = tonumber(v95)
	local v97
	if v96 == nil or v96 ~= v96 then
		v97 = 0
	else
		local v98 = v96 + 0.5
		v97 = math.floor(v98)
	end
	local v99 = p70.skipped
	local v100 = tonumber(v99)
	local v101
	if v100 == nil or v100 ~= v100 then
		v101 = 0
	else
		local v102 = v100 + 0.5
		v101 = math.floor(v102)
	end
	local v103 = p70.capped
	local v104 = tonumber(v103)
	local v105
	if v104 == nil or v104 ~= v104 then
		v105 = 0
	else
		local v106 = v104 + 0.5
		v105 = math.floor(v106)
	end
	local v107 = p70.flagsRaised
	local v108 = tonumber(v107)
	local v109
	if v108 == nil or v108 ~= v108 then
		v109 = 0
	else
		local v110 = v108 + 0.5
		v109 = math.floor(v110)
	end
	local v111 = p70.flagged
	local v112 = type(v111) == "table" and (#p70.flagged or 0) or 0
	local v113 = p70.watched
	local v114 = tonumber(v113)
	local v115
	if v114 == nil or v114 ~= v114 then
		v115 = 0
	else
		local v116 = v114 + 0.5
		v115 = math.floor(v116)
	end
	v89.text = v90:format(v93, v97, v101, v105, v109, v112, v115)
	table.insert(v71, v89)
	local v117 = {
		["name"] = "Store",
		["text"] = nil,
		["kind"] = nil
	}
	local v118 = "store writes %d (%d failed, %d waiting, %d dropped)  \194\183  reports %d  \194\183  owner and tester events %d  \194\183  module errors %d  \194\183  hook cost %.3f ms"
	local v119 = p70.writes
	local v120 = tonumber(v119)
	local v121
	if v120 == nil or v120 ~= v120 then
		v121 = 0
	else
		local v122 = v120 + 0.5
		v121 = math.floor(v122)
	end
	local v123 = p70.writeErrors
	local v124 = tonumber(v123)
	local v125
	if v124 == nil or v124 ~= v124 then
		v125 = 0
	else
		local v126 = v124 + 0.5
		v125 = math.floor(v126)
	end
	local v127 = p70.queue
	local v128 = tonumber(v127)
	local v129
	if v128 == nil or v128 ~= v128 then
		v129 = 0
	else
		local v130 = v128 + 0.5
		v129 = math.floor(v130)
	end
	local v131 = p70.dropped
	local v132 = tonumber(v131)
	local v133
	if v132 == nil or v132 ~= v132 then
		v133 = 0
	else
		local v134 = v132 + 0.5
		v133 = math.floor(v134)
	end
	local v135 = p70.reports
	local v136 = tonumber(v135)
	local v137
	if v136 == nil or v136 ~= v136 then
		v137 = 0
	else
		local v138 = v136 + 0.5
		v137 = math.floor(v138)
	end
	local v139 = p70.exemptEvents
	local v140 = tonumber(v139)
	local v141
	if v140 == nil or v140 ~= v140 then
		v141 = 0
	else
		local v142 = v140 + 0.5
		v141 = math.floor(v142)
	end
	local v143 = p70.errors
	local v144 = tonumber(v143)
	local v145
	if v144 == nil or v144 ~= v144 then
		v145 = 0
	else
		local v146 = v144 + 0.5
		v145 = math.floor(v146)
	end
	local v147 = p70.hookMs
	v117.text = v118:format(v121, v125, v129, v133, v137, v141, v145, tonumber(v147) or 0)
	local v148 = p70.errors
	local v149 = tonumber(v148)
	local v150
	if v149 == nil or v149 ~= v149 then
		v150 = 0
	else
		local v151 = v149 + 0.5
		v150 = math.floor(v151)
	end
	v117.kind = v150 > 0 and "warn" or "muted"
	table.insert(v71, v117)
	local v152 = p70.trace
	if type(v152) == "table" then
		local v153 = {
			["name"] = "Trace",
			["text"] = nil,
			["kind"] = nil
		}
		local v154 = "flight recorder %s  \194\183  recording %d players  \194\183  watching %d  \194\183  traces written %d (%d failed, %d dropped, %d waiting)  \194\183  last trace %d bytes  \194\183  sample %.1f us%s"
		local v155 = v152.available == true and (v152.selfOff == true and "SWITCHED OFF BY ITS OWN ERRORS" or (v152.on == true and "ON" or "OFF")) or "NOT IN THIS PLACE"
		local v156 = v152.recording
		local v157 = tonumber(v156)
		local v158
		if v157 == nil or v157 ~= v157 then
			v158 = 0
		else
			local v159 = v157 + 0.5
			v158 = math.floor(v159)
		end
		local v160 = v152.watching
		local v161 = tonumber(v160)
		local v162
		if v161 == nil or v161 ~= v161 then
			v162 = 0
		else
			local v163 = v161 + 0.5
			v162 = math.floor(v163)
		end
		local v164 = v152.writes
		local v165 = tonumber(v164)
		local v166
		if v165 == nil or v165 ~= v165 then
			v166 = 0
		else
			local v167 = v165 + 0.5
			v166 = math.floor(v167)
		end
		local v168 = v152.writeErrors
		local v169 = tonumber(v168)
		local v170
		if v169 == nil or v169 ~= v169 then
			v170 = 0
		else
			local v171 = v169 + 0.5
			v170 = math.floor(v171)
		end
		local v172 = v152.dropped
		local v173 = tonumber(v172)
		local v174
		if v173 == nil or v173 ~= v173 then
			v174 = 0
		else
			local v175 = v173 + 0.5
			v174 = math.floor(v175)
		end
		local v176 = v152.queue
		local v177 = tonumber(v176)
		local v178
		if v177 == nil or v177 ~= v177 then
			v178 = 0
		else
			local v179 = v177 + 0.5
			v178 = math.floor(v179)
		end
		local v180 = v152.bytes
		local v181 = tonumber(v180)
		local v182
		if v181 == nil or v181 ~= v181 then
			v182 = 0
		else
			local v183 = v181 + 0.5
			v182 = math.floor(v183)
		end
		local v184 = v152.tickUs
		local v185 = tonumber(v184) or 0
		local v186 = v152.errors
		local v187 = tonumber(v186)
		local v188
		if v187 == nil or v187 ~= v187 then
			v188 = 0
		else
			local v189 = v187 + 0.5
			v188 = math.floor(v189)
		end
		local v190
		if v188 > 0 then
			local v191 = "  \194\183  "
			local v192 = v152.errors
			local v193 = tonumber(v192)
			local v194
			if v193 == nil or v193 ~= v193 then
				v194 = 0
			else
				local v195 = v193 + 0.5
				v194 = math.floor(v195)
			end
			v190 = v191 .. tostring(v194) .. " errors"
		else
			v190 = ""
		end
		v153.text = v154:format(v155, v158, v162, v166, v170, v174, v178, v182, v185, v190)
		local v196
		if v152.selfOff == true then
			v196 = "warn"
		else
			local v197 = v152.errors
			local v198 = tonumber(v197)
			local v199
			if v198 == nil or v198 ~= v198 then
				v199 = 0
			else
				local v200 = v198 + 0.5
				v199 = math.floor(v200)
			end
			v196 = v199 > 0 and "warn" or "muted"
		end
		v153.kind = v196
		table.insert(v71, v153)
	end
	local v201 = p70.velocity
	if type(v201) == "table" then
		local v202 = {
			["name"] = "Velocity",
			["text"] = nil,
			["kind"] = nil
		}
		local v203 = "velocity guard %s  \194\183  map %s  \194\183  launch snaps %d  \194\183  out of bounds snaps %d  \194\183  no safe target %d  \194\183  players struck %d  \194\183  worst x%.1f  \194\183  cost %.1f us per check%s"
		local v204 = v201.selfOff == true and "SWITCHED OFF BY ITS OWN ERRORS" or (v201.on == true and "ON" or "OFF")
		local v205 = v201.map or "?"
		local v206 = tostring(v205)
		local v207 = v201.snaps
		local v208 = tonumber(v207)
		local v209
		if v208 == nil or v208 ~= v208 then
			v209 = 0
		else
			local v210 = v208 + 0.5
			v209 = math.floor(v210)
		end
		local v211 = v201.oobSnaps
		local v212 = tonumber(v211)
		local v213
		if v212 == nil or v212 ~= v212 then
			v213 = 0
		else
			local v214 = v212 + 0.5
			v213 = math.floor(v214)
		end
		local v215 = v201.noTarget
		local v216 = tonumber(v215)
		local v217
		if v216 == nil or v216 ~= v216 then
			v217 = 0
		else
			local v218 = v216 + 0.5
			v217 = math.floor(v218)
		end
		local v219 = v201.players
		local v220 = tonumber(v219)
		local v221
		if v220 == nil or v220 ~= v220 then
			v221 = 0
		else
			local v222 = v220 + 0.5
			v221 = math.floor(v222)
		end
		local v223 = v201.worst
		local v224 = tonumber(v223) or 0
		local v225 = v201.avgUs
		local v226 = tonumber(v225) or 0
		local v227 = v201.errors
		local v228 = tonumber(v227)
		local v229
		if v228 == nil or v228 ~= v228 then
			v229 = 0
		else
			local v230 = v228 + 0.5
			v229 = math.floor(v230)
		end
		local v231
		if v229 > 0 then
			local v232 = "  \194\183  "
			local v233 = v201.errors
			local v234 = tonumber(v233)
			local v235
			if v234 == nil or v234 ~= v234 then
				v235 = 0
			else
				local v236 = v234 + 0.5
				v235 = math.floor(v236)
			end
			v231 = v232 .. tostring(v235) .. " errors"
		else
			v231 = ""
		end
		v202.text = v203:format(v204, v206, v209, v213, v217, v221, v224, v226, v231)
		local v237
		if v201.selfOff == true then
			v237 = "warn"
		else
			local v238 = v201.errors
			local v239 = tonumber(v238)
			local v240
			if v239 == nil or v239 ~= v239 then
				v240 = 0
			else
				local v241 = v239 + 0.5
				v240 = math.floor(v241)
			end
			if v240 > 0 then
				v237 = "warn"
			else
				local v242 = v201.snaps
				local v243 = tonumber(v242)
				local v244
				if v243 == nil or v243 ~= v243 then
					v244 = 0
				else
					local v245 = v243 + 0.5
					v244 = math.floor(v245)
				end
				local v246 = v201.oobSnaps
				local v247 = tonumber(v246)
				local v248
				if v247 == nil or v247 ~= v247 then
					v248 = 0
				else
					local v249 = v247 + 0.5
					v248 = math.floor(v249)
				end
				v237 = v244 + v248 > 0 and "warn" or "muted"
			end
		end
		v202.kind = v237
		table.insert(v71, v202)
	end
	local v250 = p70.verdict
	if type(v250) == "table" then
		local v251, v252 = v_u_4.bridgeLine(p70.verdict)
		table.insert(v71, {
			["name"] = "Bridge",
			["text"] = nil,
			["kind"] = nil,
			["text"] = v251,
			["kind"] = v252
		})
	end
	local v253 = p70.wouldAct
	if type(v253) == "table" and #v253 > 0 then
		local v254 = v253[1]
		local v255 = {
			["name"] = "Would",
			["text"] = nil,
			["kind"] = "warn"
		}
		local v256 = v254.name
		local v257 = tostring(v256)
		local v258 = ({ "silent correction", "warning kick", "temporary ban" })[v254.rung] or "log"
		local v259 = tostring(v258)
		local v260 = v254.total
		local v261 = tonumber(v260) or 0
		local v262 = v254.top
		v255.text = ("last would act line (shadow, nothing happened): %s  \194\183  %s  \194\183  score %.1f  \194\183  %s"):format(v257, v259, v261, (tostring(v262)))
		table.insert(v71, v255)
	end
	local v263 = p70.errors
	local v264 = tonumber(v263)
	local v265
	if v264 == nil or v264 ~= v264 then
		v265 = 0
	else
		local v266 = v264 + 0.5
		v265 = math.floor(v266)
	end
	if v265 > 0 then
		local v267 = p70.lastError or ""
		if tostring(v267) ~= "" then
			local v268 = {
				["name"] = "Err",
				["text"] = nil,
				["kind"] = "warn"
			}
			local v269 = p70.lastError
			local v270 = tostring(v269)
			v268.text = "last module error: " .. string.sub(v270, 1, 160)
			table.insert(v71, v268)
		end
	end
	return v71
end
function v_u_4.codeLines(p271) -- name: codeLines
	local v272 = {}
	if type(p271) == "table" then
		local v273 = p271.codes
		if type(v273) == "table" then
			for _, v274 in p271.codes do
				local v275 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "text"
				}
				local v276 = v274.code
				v275.name = tostring(v276)
				local v277 = "%s  \194\183  %d in the last hour  \194\183  %d since start  \194\183  %d players  \194\183  %d skipped  \194\183  %d capped"
				local v278 = v274.code
				local v279 = tostring(v278)
				local v280 = v274.hour
				local v281 = tonumber(v280)
				local v282
				if v281 == nil or v281 ~= v281 then
					v282 = 0
				else
					local v283 = v281 + 0.5
					v282 = math.floor(v283)
				end
				local v284 = v274.total
				local v285 = tonumber(v284)
				local v286
				if v285 == nil or v285 ~= v285 then
					v286 = 0
				else
					local v287 = v285 + 0.5
					v286 = math.floor(v287)
				end
				local v288 = v274.players
				local v289 = tonumber(v288)
				local v290
				if v289 == nil or v289 ~= v289 then
					v290 = 0
				else
					local v291 = v289 + 0.5
					v290 = math.floor(v291)
				end
				local v292 = v274.skipped
				local v293 = tonumber(v292)
				local v294
				if v293 == nil or v293 ~= v293 then
					v294 = 0
				else
					local v295 = v293 + 0.5
					v294 = math.floor(v295)
				end
				local v296 = v274.capped
				local v297 = tonumber(v296)
				local v298
				if v297 == nil or v297 ~= v297 then
					v298 = 0
				else
					local v299 = v297 + 0.5
					v298 = math.floor(v299)
				end
				v275.text = v277:format(v279, v282, v286, v290, v294, v298)
				table.insert(v272, v275)
			end
			local v300 = p271.hist
			if type(v300) == "table" then
				for v301, v302 in p271.hist do
					local v303 = {
						["name"] = nil,
						["text"] = nil,
						["kind"] = "muted",
						["name"] = "Hist" .. v301,
						["text"] = tostring(v302)
					}
					table.insert(v272, v303)
				end
			end
			return v272
		end
	end
	return v272
end
function v_u_4.netLines(p304) -- name: netLines
	-- upvalues: (copy) v_u_4
	local v305 = {}
	if type(p304) == "table" then
		local v306
		if p304.selfOff == true then
			v306 = true
		else
			local v307 = p304.errors
			local v308 = tonumber(v307)
			local v309
			if v308 == nil or v308 ~= v308 then
				v309 = 0
			else
				local v310 = v308 + 0.5
				v309 = math.floor(v310)
			end
			v306 = v309 > 0
		end
		local v311 = {
			["name"] = "Net1",
			["text"] = nil,
			["kind"] = nil
		}
		local v312 = "NETWORK HEALTH %s  \194\183  frames %s  \194\183  frame avg %.1f ms  \194\183  last %.1f ms  \194\183  worst gap 10 s %.0f ms  \194\183  worst gap last hour %.0f ms  \194\183  hitches %d%s"
		local v313 = p304.selfOff == true and "SWITCHED OFF BY ITS OWN ERRORS" or (p304.on == true and "ON" or "OFF")
		local v314 = v_u_4.number(p304.frames)
		local v315 = p304.avgMs
		local v316 = tonumber(v315)
		local v317 = (v316 == nil or v316 ~= v316) and 0 or v316
		local v318 = p304.lastMs
		local v319 = tonumber(v318)
		local v320 = (v319 == nil or v319 ~= v319) and 0 or v319
		local v321 = p304.worst10Ms
		local v322 = tonumber(v321)
		local v323 = (v322 == nil or v322 ~= v322) and 0 or v322
		local v324 = p304.worstHourMs
		local v325 = tonumber(v324)
		local v326 = (v325 == nil or v325 ~= v325) and 0 or v325
		local v327 = p304.hitches
		local v328 = tonumber(v327)
		local v329
		if v328 == nil or v328 ~= v328 then
			v329 = 0
		else
			local v330 = v328 + 0.5
			v329 = math.floor(v330)
		end
		local v331 = p304.errors
		local v332 = tonumber(v331)
		local v333
		if v332 == nil or v332 ~= v332 then
			v333 = 0
		else
			local v334 = v332 + 0.5
			v333 = math.floor(v334)
		end
		local v335
		if v333 > 0 then
			local v336 = "  \194\183  "
			local v337 = p304.errors
			local v338 = tonumber(v337)
			local v339
			if v338 == nil or v338 ~= v338 then
				v339 = 0
			else
				local v340 = v338 + 0.5
				v339 = math.floor(v340)
			end
			v335 = v336 .. tostring(v339) .. " errors"
		else
			v335 = ""
		end
		v311.text = v312:format(v313, v314, v317, v320, v323, v326, v329, v335)
		v311.kind = v306 and "warn" or "ok"
		table.insert(v305, v311)
		local v341 = {
			["name"] = "Net2",
			["text"] = nil,
			["kind"] = "text"
		}
		local v342 = "memory %.0f MB  \194\183  Lua heap %s KB  \194\183  instances %s  \194\183  traffic out %.0f in %.0f kbps (peak %.0f / %.0f)  \194\183  server heartbeat %.1f ms, physics %.1f ms  \194\183  ping avg %d max %d ms (peak %d), %d players"
		local v343 = p304.memMb
		local v344 = tonumber(v343)
		local v345 = (v344 == nil or v344 ~= v344) and 0 or v344
		local v346 = v_u_4.number(p304.luaKb)
		local v347 = v_u_4.number(p304.instances)
		local v348 = p304.sendKbps
		local v349 = tonumber(v348)
		local v350 = (v349 == nil or v349 ~= v349) and 0 or v349
		local v351 = p304.recvKbps
		local v352 = tonumber(v351)
		local v353 = (v352 == nil or v352 ~= v352) and 0 or v352
		local v354 = p304.sendPeak
		local v355 = tonumber(v354)
		local v356 = (v355 == nil or v355 ~= v355) and 0 or v355
		local v357 = p304.recvPeak
		local v358 = tonumber(v357)
		local v359 = (v358 == nil or v358 ~= v358) and 0 or v358
		local v360 = p304.hbMs
		local v361 = tonumber(v360)
		local v362 = (v361 == nil or v361 ~= v361) and 0 or v361
		local v363 = p304.physMs
		local v364 = tonumber(v363)
		local v365 = (v364 == nil or v364 ~= v364) and 0 or v364
		local v366 = p304.pingAvg
		local v367 = tonumber(v366)
		local v368
		if v367 == nil or v367 ~= v367 then
			v368 = 0
		else
			local v369 = v367 + 0.5
			v368 = math.floor(v369)
		end
		local v370 = p304.pingMax
		local v371 = tonumber(v370)
		local v372
		if v371 == nil or v371 ~= v371 then
			v372 = 0
		else
			local v373 = v371 + 0.5
			v372 = math.floor(v373)
		end
		local v374 = p304.pingPeak
		local v375 = tonumber(v374)
		local v376
		if v375 == nil or v375 ~= v375 then
			v376 = 0
		else
			local v377 = v375 + 0.5
			v376 = math.floor(v377)
		end
		local v378 = p304.players
		local v379 = tonumber(v378)
		local v380
		if v379 == nil or v379 ~= v379 then
			v380 = 0
		else
			local v381 = v379 + 0.5
			v380 = math.floor(v381)
		end
		v341.text = v342:format(v345, v346, v347, v350, v353, v356, v359, v362, v365, v368, v372, v376, v380)
		table.insert(v305, v341)
		local v382 = {
			["name"] = "Net3",
			["text"] = nil,
			["kind"] = nil
		}
		local v383 = "profile pushes %s  \194\183  biggest %s bytes  \194\183  average %s  \194\183  over the line %d  \194\183  storms %d  \194\183  skipped by the budget %d  \194\183  big moves %d (probed %d, most parts near a destination %s, last %s, slowest probe %.1f ms)"
		local v384 = v_u_4.number(p304.pushes)
		local v385 = v_u_4.number(p304.pushMax)
		local v386 = v_u_4.number(p304.pushAvg)
		local v387 = p304.pushOver
		local v388 = tonumber(v387)
		local v389
		if v388 == nil or v388 ~= v388 then
			v389 = 0
		else
			local v390 = v388 + 0.5
			v389 = math.floor(v390)
		end
		local v391 = p304.pushStorms
		local v392 = tonumber(v391)
		local v393
		if v392 == nil or v392 ~= v392 then
			v393 = 0
		else
			local v394 = v392 + 0.5
			v393 = math.floor(v394)
		end
		local v395 = p304.pushSkipped
		local v396 = tonumber(v395)
		local v397
		if v396 == nil or v396 ~= v396 then
			v397 = 0
		else
			local v398 = v396 + 0.5
			v397 = math.floor(v398)
		end
		local v399 = p304.moves
		local v400 = tonumber(v399)
		local v401
		if v400 == nil or v400 ~= v400 then
			v401 = 0
		else
			local v402 = v400 + 0.5
			v401 = math.floor(v402)
		end
		local v403 = p304.probed
		local v404 = tonumber(v403)
		local v405
		if v404 == nil or v404 ~= v404 then
			v405 = 0
		else
			local v406 = v404 + 0.5
			v405 = math.floor(v406)
		end
		local v407 = v_u_4.number(p304.partsMax)
		local v408 = v_u_4.number(p304.partsLast)
		local v409 = p304.probeMsMax
		local v410 = tonumber(v409)
		v382.text = v383:format(v384, v385, v386, v389, v393, v397, v401, v405, v407, v408, (v410 == nil or v410 ~= v410) and 0 or v410)
		local v411 = p304.pushOver
		local v412 = tonumber(v411)
		local v413
		if v412 == nil or v412 ~= v412 then
			v413 = 0
		else
			local v414 = v412 + 0.5
			v413 = math.floor(v414)
		end
		local v415 = p304.pushStorms
		local v416 = tonumber(v415)
		local v417
		if v416 == nil or v416 ~= v416 then
			v417 = 0
		else
			local v418 = v416 + 0.5
			v417 = math.floor(v418)
		end
		v382.kind = v413 + v417 > 0 and "warn" or "text"
		table.insert(v305, v382)
		local v419 = {
			["name"] = "Net4",
			["text"] = nil,
			["kind"] = nil
		}
		local v420 = "players left %d (%d from the raid)  \194\183  clusters %d unplanned, %d planned returns  \194\183  analytics events %d  \194\183  hook cost %.2f us per frame"
		local v421 = p304.leaves
		local v422 = tonumber(v421)
		local v423
		if v422 == nil or v422 ~= v422 then
			v423 = 0
		else
			local v424 = v422 + 0.5
			v423 = math.floor(v424)
		end
		local v425 = p304.leavesUnplanned
		local v426 = tonumber(v425)
		local v427
		if v426 == nil or v426 ~= v426 then
			v427 = 0
		else
			local v428 = v426 + 0.5
			v427 = math.floor(v428)
		end
		local v429 = p304.clusters
		local v430 = tonumber(v429)
		local v431
		if v430 == nil or v430 ~= v430 then
			v431 = 0
		else
			local v432 = v430 + 0.5
			v431 = math.floor(v432)
		end
		local v433 = p304.clustersPlanned
		local v434 = tonumber(v433)
		local v435
		if v434 == nil or v434 ~= v434 then
			v435 = 0
		else
			local v436 = v434 + 0.5
			v435 = math.floor(v436)
		end
		local v437 = p304.analytics
		local v438 = tonumber(v437)
		local v439
		if v438 == nil or v438 ~= v438 then
			v439 = 0
		else
			local v440 = v438 + 0.5
			v439 = math.floor(v440)
		end
		local v441 = p304.stepUs
		local v442 = tonumber(v441)
		v419.text = v420:format(v423, v427, v431, v435, v439, (v442 == nil or v442 ~= v442) and 0 or v442)
		local v443 = p304.clusters
		local v444 = tonumber(v443)
		local v445
		if v444 == nil or v444 ~= v444 then
			v445 = 0
		else
			local v446 = v444 + 0.5
			v445 = math.floor(v446)
		end
		v419.kind = v445 > 0 and "warn" or "text"
		table.insert(v305, v419)
		local v447 = p304.records
		if type(v447) == "table" and #p304.records > 0 then
			for v448, v449 in p304.records do
				local v450 = tostring(v449)
				local v451 = {
					["name"] = "NetR" .. v448,
					["text"] = v450,
					["kind"] = string.find(v450, "CLUSTER", 1, true) and "warn" or "muted"
				}
				table.insert(v305, v451)
			end
			return v305
		else
			table.insert(v305, {
				["name"] = "NetR0",
				["text"] = "no records yet (a record appears when players leave together, a frame hitches, a push is big or a body is moved far)",
				["kind"] = "muted"
			})
			return v305
		end
	else
		table.insert(v305, {
			["name"] = "Net0",
			["text"] = "Network health: no data from this server (the module is not in this place or the owner op is old).",
			["kind"] = "muted"
		})
		return v305
	end
end
function v_u_4.liveLines(p452) -- name: liveLines
	local v453 = {}
	if type(p452) == "table" then
		local v454 = p452.online
		if type(v454) == "table" then
			for _, v455 in p452.online do
				local v456 = {}
				local v457 = v455.uid
				v456.name = "P" .. tostring(v457)
				local v458 = "%s  \194\183  %d  \194\183  score %.1f (peak %.1f)  \194\183  ping %d ms  \194\183  events %d%s%s%s"
				local v459 = v455.name
				local v460 = tostring(v459)
				local v461 = v455.uid
				local v462 = tonumber(v461)
				local v463
				if v462 == nil or v462 ~= v462 then
					v463 = 0
				else
					local v464 = v462 + 0.5
					v463 = math.floor(v464)
				end
				local v465 = v455.score
				local v466 = tonumber(v465) or 0
				local v467 = v455.peak
				local v468 = tonumber(v467) or 0
				local v469 = v455.ping
				local v470 = tonumber(v469)
				local v471
				if v470 == nil or v470 ~= v470 then
					v471 = 0
				else
					local v472 = v470 + 0.5
					v471 = math.floor(v472)
				end
				local v473 = v455.events
				local v474 = tonumber(v473)
				local v475
				if v474 == nil or v474 ~= v474 then
					v475 = 0
				else
					local v476 = v474 + 0.5
					v475 = math.floor(v476)
				end
				local v477 = v455.vel
				local v478 = tonumber(v477)
				local v479
				if v478 == nil or v478 ~= v478 then
					v479 = 0
				else
					local v480 = v478 + 0.5
					v479 = math.floor(v480)
				end
				local v481
				if v479 > 0 then
					local v482 = "  \194\183  velocity snaps "
					local v483 = v455.vel
					local v484 = tonumber(v483)
					local v485
					if v484 == nil or v484 ~= v484 then
						v485 = 0
					else
						local v486 = v484 + 0.5
						v485 = math.floor(v486)
					end
					v481 = v482 .. tostring(v485)
				else
					v481 = ""
				end
				local v487
				if v455.exempt then
					local v488 = v455.exempt
					v487 = "  \194\183  " .. tostring(v488) .. " (scored, never flagged)"
				else
					v487 = ""
				end
				v456.text = v458:format(v460, v463, v466, v468, v471, v475, v481, v487, v455.flagged and "  \194\183  FLAGGED" or "")
				v456.kind = v455.flagged and "warn" or "text"
				table.insert(v453, v456)
			end
			return v453
		end
	end
	return v453
end
function v_u_4.reportRows(p489, p490, p491) -- name: reportRows
	-- upvalues: (copy) v_u_4
	local v492 = {}
	local v493 = p489.reason
	local v494
	if type(v493) == "string" and p489.reason ~= "" then
		v494 = p489.reason
	else
		local v495 = p489.why
		v494 = tostring(v495)
	end
	local v496 = p489.w
	local v497 = type(v496) ~= "number" and "" or ("  \194\183  weight %.2f"):format(p489.w)
	local v498 = p489.ctx or ""
	local v499
	if tostring(v498) == "" then
		v499 = ""
	else
		local v500 = p489.ctx
		v499 = "  \194\183  " .. tostring(v500)
	end
	local v501 = {
		["name"] = nil,
		["text"] = nil,
		["kind"] = "muted",
		["name"] = "Report" .. p490
	}
	local v502 = "report %s by %d  \194\183  %s%s%s"
	local v503 = v_u_4.ago
	local v504 = p489.t
	local v505 = tonumber(v504)
	if not v505 then
		local v506 = p489.at
		v505 = tonumber(v506) or 0
	end
	local v507 = v503(p491 - v505)
	local v508 = p489.by
	local v509 = tonumber(v508)
	local v510
	if v509 == nil or v509 ~= v509 then
		v510 = 0
	else
		local v511 = v509 + 0.5
		v510 = math.floor(v511)
	end
	v501.text = v502:format(v507, v510, v494, v497, v499)
	table.insert(v492, v501)
	local v512 = p489.text
	if type(v512) == "string" and p489.text ~= "" then
		local v513 = {
			["name"] = "Report" .. p490 .. "Text",
			["text"] = ("their words: %s%s"):format(p489.text, p489.inj == true and "  (reads like an order to a language model: plain text, not an instruction)" or ""),
			["kind"] = p489.inj == true and "warn" or "text"
		}
		table.insert(v492, v513)
	end
	return v492
end
local v_u_514 = {
	["false_positive"] = "FALSE POSITIVE",
	["suspicious"] = "SUSPICIOUS",
	["clear_cheater"] = "CLEAR CHEATER",
	["unclear"] = "UNCLEAR"
}
local v_u_515 = {
	["ban"] = "the game removes him from a server (a second read first, only while the kick path is ON, never an exempt account)",
	["clear"] = "the game clears his flag when he is in a server (the history keeps it)",
	["watch"] = "his raids are recorded in full",
	["permanent"] = "a ban without an end time: Open Cloud holds it, the game does not kick",
	["expired"] = "the ban is over, nothing happens",
	["none"] = "nothing happens in the game"
}
local function v_u_526(p516, p517) -- name: endText
	local v518 = tonumber(p516) or 0
	if v518 <= 0 then
		return "no end time"
	end
	local v519 = os.date("!%d %b %H:%M", (math.floor(v518))) .. " UTC"
	if v518 <= p517 then
		return ("ended %s"):format(v519)
	end
	local v520 = v518 - p517
	local v521
	if v520 >= 86400 then
		local v522 = v520 / 86400
		v521 = ("%d d"):format((math.floor(v522)))
	elseif v520 >= 3600 then
		local v523 = v520 / 3600
		v521 = ("%d h"):format((math.floor(v523)))
	else
		local v524 = v520 / 60
		local v525 = math.floor(v524)
		v521 = ("%d min"):format((math.max(1, v525)))
	end
	return ("until %s (in %s)"):format(v519, v521)
end
function v_u_4.actionText(p527, p528) -- name: actionText
	-- upvalues: (copy) v_u_526
	return p527.action ~= "ban" and (p527.action == "watch" and "watch" or "no action") or "ban " .. v_u_526(p527.ends, p528)
end
function v_u_4.verdictLines(p529, p530) -- name: verdictLines
	-- upvalues: (copy) v_u_514, (copy) v_u_526, (copy) v_u_4, (copy) v_u_515
	local v531 = {}
	if type(p529) == "table" then
		if p529.ok == true then
			local v532 = p529.doc
			if type(v532) == "table" then
				local v533
				if v532.action == "ban" then
					local v534 = v532.ends
					v533 = p530 < (tonumber(v534) or 0)
				else
					v533 = false
				end
				local v535 = {
					["name"] = "Verdict",
					["text"] = nil,
					["kind"] = nil
				}
				local v536 = "moderator verdict %s  \194\183  confidence %.2f  \194\183  %s  \194\183  written %s  \194\183  case %s"
				local v537 = v_u_514
				local v538 = v532.class
				local v539 = v537[tostring(v538)] or "UNKNOWN"
				local v540 = v532.conf
				local v541 = tonumber(v540) or 0
				local v542
				if v532.action == "ban" then
					v542 = "ban " .. v_u_526(v532.ends, p530)
				else
					v542 = v532.action == "watch" and "watch" or "no action"
				end
				local v543 = v_u_4.ago
				local v544 = v532.at
				local v545 = v543(p530 - (tonumber(v544) or 0))
				local v546 = v532.case
				v535.text = v536:format(v539, v541, v542, v545, (tostring(v546)))
				v535.kind = (v533 or v532.class == "clear_cheater") and "warn" or "text"
				table.insert(v531, v535)
				local v547 = v_u_515
				local v548 = p529.verb
				local v549 = v547[tostring(v548)]
				if p529.verb == "invalid" then
					local v550 = p529.note or ""
					v549 = "the game ignores it (" .. tostring(v550) .. ")"
				end
				local v551 = {
					["name"] = "VerdictGame",
					["text"] = nil,
					["kind"] = "muted",
					["text"] = "in the game: " .. tostring(v549 or "nothing happens in the game")
				}
				table.insert(v531, v551)
				local v552 = v532.why or ""
				if tostring(v552) ~= "" then
					local v553 = {
						["name"] = "VerdictWhy",
						["text"] = nil,
						["kind"] = "muted"
					}
					local v554 = v532.why
					v553.text = "the moderator\'s words: " .. tostring(v554)
					table.insert(v531, v553)
				end
				local v555 = v532.evidence
				if type(v555) == "table" and next(v555) ~= nil then
					local v556 = {}
					local v557 = v555.cats
					if type(v557) == "table" and #v555.cats > 0 then
						local v558 = "categories " .. table.concat(v555.cats, ", ")
						table.insert(v556, v558)
					end
					local v559 = v555.blatant
					if type(v559) == "table" and #v555.blatant > 0 then
						local v560 = "blatant " .. table.concat(v555.blatant, ", ")
						table.insert(v556, v560)
					end
					local v561 = v555.raids
					if tonumber(v561) then
						local v562 = "%d raids"
						local v563 = v555.raids
						local v564 = tonumber(v563)
						local v565
						if v564 == nil or v564 ~= v564 then
							v565 = 0
						else
							local v566 = v564 + 0.5
							v565 = math.floor(v566)
						end
						table.insert(v556, v562:format(v565))
					end
					local v567 = v555.reports
					if tonumber(v567) then
						local v568 = "%d reports"
						local v569 = v555.reports
						local v570 = tonumber(v569)
						local v571
						if v570 == nil or v570 ~= v570 then
							v571 = 0
						else
							local v572 = v570 + 0.5
							v571 = math.floor(v572)
						end
						table.insert(v556, v568:format(v571))
					end
					if v555.lag ~= nil then
						local v573 = v555.lag and "LAG SEEN" or "no lag"
						table.insert(v556, v573)
					end
					if v555.lag_unknown == true then
						table.insert(v556, "lag unknown")
					end
					local v574 = v555.gates
					if type(v574) == "table" and #v555.gates > 0 then
						local v575 = "held back by " .. table.concat(v555.gates, ", ")
						table.insert(v556, v575)
					end
					if v555.review == true then
						table.insert(v556, "needs your eyes")
					end
					local v576 = v555.model
					if type(v576) == "string" and v555.model ~= "" then
						local v577 = "model " .. v555.model
						table.insert(v556, v577)
					end
					if #v556 > 0 then
						local v578 = {
							["name"] = "VerdictEv",
							["text"] = nil,
							["kind"] = "muted",
							["text"] = "evidence: " .. table.concat(v556, "  \194\183  ")
						}
						table.insert(v531, v578)
					end
				end
				local v579 = p529.here
				local v580 = p529.kickedHere
				if type(v580) ~= "table" then
					if type(v579) == "table" then
						local v581 = {
							["name"] = "VerdictHere",
							["text"] = nil,
							["kind"] = "muted"
						}
						local v582 = "on this server: the verdict was read %d times, last %s"
						local v583 = v579.reads
						local v584 = tonumber(v583)
						local v585
						if v584 == nil or v584 ~= v584 then
							v585 = 0
						else
							local v586 = v584 + 0.5
							v585 = math.floor(v586)
						end
						local v587 = v_u_4.ago
						local v588 = v579.lastRead
						v581.text = v582:format(v585, v587(p530 - (tonumber(v588) or 0)))
						table.insert(v531, v581)
					end
					return v531
				end
				local v589 = {
					["name"] = "VerdictHere",
					["text"] = nil,
					["kind"] = "warn"
				}
				local v590 = v_u_4.ago
				local v591 = v580.at
				local v592 = v590(p530 - (tonumber(v591) or 0))
				local v593 = v580.case
				v589.text = ("removed by the game %s (case %s)"):format(v592, (tostring(v593)))
				table.insert(v531, v589)
				return v531
			elseif p529.malformed == true then
				table.insert(v531, {
					["name"] = "Verdict",
					["text"] = "moderator verdict: a document is stored but it is no valid verdict (the game ignores it)",
					["kind"] = "warn"
				})
				return v531
			else
				table.insert(v531, {
					["name"] = "Verdict",
					["text"] = "moderator verdict: none",
					["kind"] = "muted"
				})
				return v531
			end
		else
			table.insert(v531, {
				["name"] = "Verdict",
				["text"] = "moderator verdict: the verdict store did not answer",
				["kind"] = "muted"
			})
			return v531
		end
	else
		return v531
	end
end
function v_u_4.bridgeLine(p594) -- name: bridgeLine
	if type(p594) ~= "table" then
		return "verdict bridge: not in this place", "muted"
	end
	local v595 = p594.kick
	local v596 = type(v595) ~= "table" and {} or p594.kick
	local v597
	if v596.known == true then
		if v596.on == true then
			v597 = "kick path ON"
		else
			local v598 = "kick path OFF%s"
			local v599 = v596.byName or ""
			local v600
			if tostring(v599) == "" then
				v600 = ""
			else
				local v601 = v596.byName
				v600 = " by " .. tostring(v601)
			end
			v597 = v598:format(v600)
		end
	else
		v597 = "kick path ON (not read yet)"
	end
	local v602 = p594.selfOff == true and "SWITCHED OFF BY ITS OWN ERRORS" or (p594.on == true and "ON" or "OFF (the anti cheat is off)")
	local v603 = "verdict bridge %s  \194\183  %s  \194\183  %d players read (%d failed)  \194\183  hints %d  \194\183  removed %d (brake %d)  \194\183  flags cleared %d  \194\183  exempt skipped %d  \194\183  errors %d"
	local v604 = p594.reads
	local v605 = tonumber(v604)
	local v606
	if v605 == nil or v605 ~= v605 then
		v606 = 0
	else
		local v607 = v605 + 0.5
		v606 = math.floor(v607)
	end
	local v608 = p594.readErrors
	local v609 = tonumber(v608)
	local v610
	if v609 == nil or v609 ~= v609 then
		v610 = 0
	else
		local v611 = v609 + 0.5
		v610 = math.floor(v611)
	end
	local v612 = p594.hints
	local v613 = tonumber(v612)
	local v614
	if v613 == nil or v613 ~= v613 then
		v614 = 0
	else
		local v615 = v613 + 0.5
		v614 = math.floor(v615)
	end
	local v616 = p594.kicks
	local v617 = tonumber(v616)
	local v618
	if v617 == nil or v617 ~= v617 then
		v618 = 0
	else
		local v619 = v617 + 0.5
		v618 = math.floor(v619)
	end
	local v620 = p594.braked
	local v621 = tonumber(v620)
	local v622
	if v621 == nil or v621 ~= v621 then
		v622 = 0
	else
		local v623 = v621 + 0.5
		v622 = math.floor(v623)
	end
	local v624 = p594.cleared
	local v625 = tonumber(v624)
	local v626
	if v625 == nil or v625 ~= v625 then
		v626 = 0
	else
		local v627 = v625 + 0.5
		v626 = math.floor(v627)
	end
	local v628 = p594.exemptSkipped
	local v629 = tonumber(v628)
	local v630
	if v629 == nil or v629 ~= v629 then
		v630 = 0
	else
		local v631 = v629 + 0.5
		v630 = math.floor(v631)
	end
	local v632 = p594.errors
	local v633 = tonumber(v632)
	local v634
	if v633 == nil or v633 ~= v633 then
		v634 = 0
	else
		local v635 = v633 + 0.5
		v634 = math.floor(v635)
	end
	local v636 = v603:format(v602, v597, v606, v610, v614, v618, v622, v626, v630, v634)
	local v637
	if p594.selfOff == true then
		v637 = "warn"
	else
		local v638 = p594.errors
		local v639 = tonumber(v638)
		local v640
		if v639 == nil or v639 ~= v639 then
			v640 = 0
		else
			local v641 = v639 + 0.5
			v640 = math.floor(v641)
		end
		v637 = v640 > 0 and "warn" or (v596.on == false and "warn" or "muted")
	end
	return v636, v637
end
function v_u_4.verdictCountLines(p642, p643) -- name: verdictCountLines
	-- upvalues: (copy) v_u_4
	local v644 = {}
	if type(p642) ~= "table" then
		table.insert(v644, {
			["name"] = "VCount",
			["text"] = "Verdicts: not read yet. Press REFRESH.",
			["kind"] = "muted"
		})
		return v644
	end
	if p642.failed == true then
		table.insert(v644, {
			["name"] = "VCount",
			["text"] = "Verdicts: the verdict store did not answer.",
			["kind"] = "warn"
		})
		return v644
	end
	local v645 = p642.counts
	local v646 = type(v645) ~= "table" and {} or p642.counts
	local v647 = p642.source
	local v648 = tostring(v647)
	local v649, v650, v651, v652, v653, v654, v655, v656, v657, v658, v659, v660, v661, v662, v663, v664, v665, v666, v667, v668, v669, v670, v671, v672, v673, v674, v675, v676, v677, v678, v679, v680, v681
	if v648 == "index" then
		v649 = "from the moderator\'s index"
		v650 = {
			["name"] = "VCount",
			["text"] = nil,
			["kind"] = "text"
		}
		v651 = "%d verdicts (%s)  \194\183  false positive %d  \194\183  suspicious %d  \194\183  clear cheater %d  \194\183  unclear %d  \194\183  bans active %d  \194\183  watch %d  \194\183  read %s"
		v652 = v646.total
		v653 = tonumber(v652)
		if v653 == nil or v653 ~= v653 then
			v654 = 0
		else
			v655 = v653 + 0.5
			v654 = math.floor(v655)
		end
		v656 = v646.false_positive
		v657 = tonumber(v656)
		if v657 == nil or v657 ~= v657 then
			v658 = 0
		else
			v659 = v657 + 0.5
			v658 = math.floor(v659)
		end
		v660 = v646.suspicious
		v661 = tonumber(v660)
		if v661 == nil or v661 ~= v661 then
			v662 = 0
		else
			v663 = v661 + 0.5
			v662 = math.floor(v663)
		end
		v664 = v646.clear_cheater
		v665 = tonumber(v664)
		if v665 == nil or v665 ~= v665 then
			v666 = 0
		else
			v667 = v665 + 0.5
			v666 = math.floor(v667)
		end
		v668 = v646.unclear
		v669 = tonumber(v668)
		if v669 == nil or v669 ~= v669 then
			v670 = 0
		else
			v671 = v669 + 0.5
			v670 = math.floor(v671)
		end
		v672 = v646.banActive
		v673 = tonumber(v672)
		if v673 == nil or v673 ~= v673 then
			v674 = 0
		else
			v675 = v673 + 0.5
			v674 = math.floor(v675)
		end
		v676 = v646.watch
		v677 = tonumber(v676)
		if v677 == nil or v677 ~= v677 then
			v678 = 0
		else
			v679 = v677 + 0.5
			v678 = math.floor(v679)
		end
		v680 = v_u_4.ago
		v681 = p642.at
		v650.text = v651:format(v654, v649, v658, v662, v666, v670, v674, v678, v680(p643 - (tonumber(v681) or p643)))
		table.insert(v644, v650)
		return v644
	elseif v648 == "scan" then
		local v682, v683, v684, v685, v686, v687, v688, v689, v690
		if p642.capped == true then
			v682 = "a sample: %d of %d documents read"
			v683 = p642.read
			v684 = tonumber(v683)
			if v684 == nil or v684 ~= v684 then
				v685 = 0
			else
				v686 = v684 + 0.5
				v685 = math.floor(v686)
			end
			v687 = p642.listed
			v688 = tonumber(v687)
			if v688 == nil or v688 ~= v688 then
				v689 = 0
			else
				v690 = v688 + 0.5
				v689 = math.floor(v690)
			end
			v649 = v682:format(v685, v689)
		else
			local v691 = p642.read
			local v692 = tonumber(v691)
			local v693
			if v692 == nil or v692 ~= v692 then
				v693 = 0
			else
				local v694 = v692 + 0.5
				v693 = math.floor(v694)
			end
			local v695 = p642.listed
			local v696 = tonumber(v695)
			local v697
			if v696 == nil or v696 ~= v696 then
				v697 = 0
			else
				local v698 = v696 + 0.5
				v697 = math.floor(v698)
			end
			if v693 >= v697 then
				local v699 = "%d documents read"
				local v700 = p642.read
				local v701 = tonumber(v700)
				local v702
				if v701 == nil or v701 ~= v701 then
					v702 = 0
				else
					local v703 = v701 + 0.5
					v702 = math.floor(v703)
				end
				v649 = v699:format(v702)
				v650 = {
					["name"] = "VCount",
					["text"] = nil,
					["kind"] = "text"
				}
				v651 = "%d verdicts (%s)  \194\183  false positive %d  \194\183  suspicious %d  \194\183  clear cheater %d  \194\183  unclear %d  \194\183  bans active %d  \194\183  watch %d  \194\183  read %s"
				v652 = v646.total
				v653 = tonumber(v652)
				if v653 == nil or v653 ~= v653 then
					v654 = 0
				else
					v655 = v653 + 0.5
					v654 = math.floor(v655)
				end
				v656 = v646.false_positive
				v657 = tonumber(v656)
				if v657 == nil or v657 ~= v657 then
					v658 = 0
				else
					v659 = v657 + 0.5
					v658 = math.floor(v659)
				end
				v660 = v646.suspicious
				v661 = tonumber(v660)
				if v661 == nil or v661 ~= v661 then
					v662 = 0
				else
					v663 = v661 + 0.5
					v662 = math.floor(v663)
				end
				v664 = v646.clear_cheater
				v665 = tonumber(v664)
				if v665 == nil or v665 ~= v665 then
					v666 = 0
				else
					v667 = v665 + 0.5
					v666 = math.floor(v667)
				end
				v668 = v646.unclear
				v669 = tonumber(v668)
				if v669 == nil or v669 ~= v669 then
					v670 = 0
				else
					v671 = v669 + 0.5
					v670 = math.floor(v671)
				end
				v672 = v646.banActive
				v673 = tonumber(v672)
				if v673 == nil or v673 ~= v673 then
					v674 = 0
				else
					v675 = v673 + 0.5
					v674 = math.floor(v675)
				end
				v676 = v646.watch
				v677 = tonumber(v676)
				if v677 == nil or v677 ~= v677 then
					v678 = 0
				else
					v679 = v677 + 0.5
					v678 = math.floor(v679)
				end
				v680 = v_u_4.ago
				v681 = p642.at
				v650.text = v651:format(v654, v649, v658, v662, v666, v670, v674, v678, v680(p643 - (tonumber(v681) or p643)))
				table.insert(v644, v650)
				return v644
			end
			v682 = "a sample: %d of %d documents read"
			v683 = p642.read
			v684 = tonumber(v683)
			if v684 == nil or v684 ~= v684 then
				v685 = 0
			else
				v686 = v684 + 0.5
				v685 = math.floor(v686)
			end
			v687 = p642.listed
			v688 = tonumber(v687)
			if v688 == nil or v688 ~= v688 then
				v689 = 0
			else
				v690 = v688 + 0.5
				v689 = math.floor(v690)
			end
			v649 = v682:format(v685, v689)
		end
		v650 = {
			["name"] = "VCount",
			["text"] = nil,
			["kind"] = "text"
		}
		v651 = "%d verdicts (%s)  \194\183  false positive %d  \194\183  suspicious %d  \194\183  clear cheater %d  \194\183  unclear %d  \194\183  bans active %d  \194\183  watch %d  \194\183  read %s"
		v652 = v646.total
		v653 = tonumber(v652)
		if v653 == nil or v653 ~= v653 then
			v654 = 0
		else
			v655 = v653 + 0.5
			v654 = math.floor(v655)
		end
		v656 = v646.false_positive
		v657 = tonumber(v656)
		if v657 == nil or v657 ~= v657 then
			v658 = 0
		else
			v659 = v657 + 0.5
			v658 = math.floor(v659)
		end
		v660 = v646.suspicious
		v661 = tonumber(v660)
		if v661 == nil or v661 ~= v661 then
			v662 = 0
		else
			v663 = v661 + 0.5
			v662 = math.floor(v663)
		end
		v664 = v646.clear_cheater
		v665 = tonumber(v664)
		if v665 == nil or v665 ~= v665 then
			v666 = 0
		else
			v667 = v665 + 0.5
			v666 = math.floor(v667)
		end
		v668 = v646.unclear
		v669 = tonumber(v668)
		if v669 == nil or v669 ~= v669 then
			v670 = 0
		else
			v671 = v669 + 0.5
			v670 = math.floor(v671)
		end
		v672 = v646.banActive
		v673 = tonumber(v672)
		if v673 == nil or v673 ~= v673 then
			v674 = 0
		else
			v675 = v673 + 0.5
			v674 = math.floor(v675)
		end
		v676 = v646.watch
		v677 = tonumber(v676)
		if v677 == nil or v677 ~= v677 then
			v678 = 0
		else
			v679 = v677 + 0.5
			v678 = math.floor(v679)
		end
		v680 = v_u_4.ago
		v681 = p642.at
		v650.text = v651:format(v654, v649, v658, v662, v666, v670, v674, v678, v680(p643 - (tonumber(v681) or p643)))
		table.insert(v644, v650)
		return v644
	else
		v649 = "no verdict documents yet"
		v650 = {
			["name"] = "VCount",
			["text"] = nil,
			["kind"] = "text"
		}
		v651 = "%d verdicts (%s)  \194\183  false positive %d  \194\183  suspicious %d  \194\183  clear cheater %d  \194\183  unclear %d  \194\183  bans active %d  \194\183  watch %d  \194\183  read %s"
		v652 = v646.total
		v653 = tonumber(v652)
		if v653 == nil or v653 ~= v653 then
			v654 = 0
		else
			v655 = v653 + 0.5
			v654 = math.floor(v655)
		end
		v656 = v646.false_positive
		v657 = tonumber(v656)
		if v657 == nil or v657 ~= v657 then
			v658 = 0
		else
			v659 = v657 + 0.5
			v658 = math.floor(v659)
		end
		v660 = v646.suspicious
		v661 = tonumber(v660)
		if v661 == nil or v661 ~= v661 then
			v662 = 0
		else
			v663 = v661 + 0.5
			v662 = math.floor(v663)
		end
		v664 = v646.clear_cheater
		v665 = tonumber(v664)
		if v665 == nil or v665 ~= v665 then
			v666 = 0
		else
			v667 = v665 + 0.5
			v666 = math.floor(v667)
		end
		v668 = v646.unclear
		v669 = tonumber(v668)
		if v669 == nil or v669 ~= v669 then
			v670 = 0
		else
			v671 = v669 + 0.5
			v670 = math.floor(v671)
		end
		v672 = v646.banActive
		v673 = tonumber(v672)
		if v673 == nil or v673 ~= v673 then
			v674 = 0
		else
			v675 = v673 + 0.5
			v674 = math.floor(v675)
		end
		v676 = v646.watch
		v677 = tonumber(v676)
		if v677 == nil or v677 ~= v677 then
			v678 = 0
		else
			v679 = v677 + 0.5
			v678 = math.floor(v679)
		end
		v680 = v_u_4.ago
		v681 = p642.at
		v650.text = v651:format(v654, v649, v658, v662, v666, v670, v674, v678, v680(p643 - (tonumber(v681) or p643)))
		table.insert(v644, v650)
		return v644
	end
end
function v_u_4.verdictRowLines(p704, p705) -- name: verdictRowLines
	-- upvalues: (copy) v_u_514, (copy) v_u_526, (copy) v_u_4
	if type(p704) ~= "table" then
		return "?", ""
	end
	local v706 = "%d  \194\183  %s  \194\183  confidence %.2f  \194\183  %s"
	local v707 = p704.uid
	local v708 = tonumber(v707)
	local v709
	if v708 == nil or v708 ~= v708 then
		v709 = 0
	else
		local v710 = v708 + 0.5
		v709 = math.floor(v710)
	end
	local v711 = v_u_514
	local v712 = p704.class
	local v713 = v711[tostring(v712)] or "UNKNOWN"
	local v714 = p704.conf
	local v715 = tonumber(v714) or 0
	local v716
	if p704.action == "ban" then
		v716 = "ban " .. v_u_526(p704.ends, p705)
	else
		v716 = p704.action == "watch" and "watch" or "no action"
	end
	local v717 = v706:format(v709, v713, v715, v716)
	local v718 = "%s  \194\183  case %s%s"
	local v719 = v_u_4.ago
	local v720 = p704.at
	local v721 = v719(p705 - (tonumber(v720) or 0))
	local v722 = p704.case
	local v723 = tostring(v722)
	local v724 = p704.why or ""
	local v725
	if tostring(v724) == "" then
		v725 = ""
	else
		local v726 = p704.why
		v725 = "  \194\183  " .. tostring(v726)
	end
	return v717, v718:format(v721, v723, v725)
end
local v_u_727 = {
	["shot"] = "shot",
	["hit"] = "hit",
	["kill"] = "kill",
	["loot"] = "loot",
	["door"] = "door",
	["extract"] = "extract",
	["snap"] = "snap",
	["tp"] = "teleport",
	["mv"] = "server move"
}
local v_u_728 = {
	["snap"] = {
		[1] = "wall",
		[2] = "speed",
		[4] = "velocity",
		[5] = "out of bounds"
	},
	["tp"] = {
		[3] = "far hop"
	},
	["loot"] = { "opened", "taken" },
	["door"] = { "used", "unlocked", "window" }
}
local function v_u_734(p729) -- name: clock
	local v730 = tonumber(p729) or 0
	local v731 = math.floor(v730)
	local v732 = math.max(0, v731)
	local v733 = v732 / 60
	return ("%d:%02d"):format(math.floor(v733), v732 % 60)
end
function v_u_4.traceRowLines(p735, p736) -- name: traceRowLines
	-- upvalues: (copy) v_u_4
	if type(p735) ~= "table" then
		return "?", ""
	end
	if p735.missing == true then
		local v737 = p735.key
		return tostring(v737), "the document is not in the store (any more)"
	end
	if p735.error ~= nil then
		local v738 = p735.key
		local v739 = tostring(v738)
		local v740 = p735.error
		return v739, tostring(v740)
	end
	local v741 = "%s  \194\183  %s  \194\183  %s  \194\183  %s  \194\183  %s%s"
	local v742 = v_u_4.ago
	local v743 = p735.start
	local v744 = v742(p736 - (tonumber(v743) or 0))
	local v745 = p735.raid
	local v746 = tostring(v745)
	local v747 = p735.map or ""
	local v748 = tostring(v747) == "" and "?" or p735.map
	local v749 = tostring(v748)
	local v750 = p735.dur
	local v751 = tonumber(v750) or 0
	local v752 = math.floor(v751)
	local v753 = math.max(0, v752)
	local v754
	if v753 < 3600 then
		local v755 = v753 / 60
		v754 = ("%d min"):format((math.floor(v755)))
	else
		local v756 = v753 / 3600
		local v757 = math.floor(v756)
		local v758 = v753 % 3600 / 60
		v754 = ("%d h %d min"):format(v757, (math.floor(v758)))
	end
	local v759 = v741:format(v744, v746, v749, v754, ({
		["flag"] = "FLAG",
		["report"] = "REPORT",
		["watch"] = "WATCH"
	})[p735.why] or "FLAG", p735.expired == true and "  \194\183  expired" or "")
	local v760 = "speed max %.1f  \194\183  %d snaps  \194\183  %d teleports  \194\183  %d shots  \194\183  %d hits  \194\183  ping %d/%d ms  \194\183  %s"
	local v761 = p735.speedMax
	local v762 = tonumber(v761) or 0
	local v763 = p735.snaps
	local v764 = tonumber(v763)
	local v765
	if v764 == nil or v764 ~= v764 then
		v765 = 0
	else
		local v766 = v764 + 0.5
		v765 = math.floor(v766)
	end
	local v767 = p735.tps
	local v768 = tonumber(v767)
	local v769
	if v768 == nil or v768 ~= v768 then
		v769 = 0
	else
		local v770 = v768 + 0.5
		v769 = math.floor(v770)
	end
	local v771 = p735.shots
	local v772 = tonumber(v771)
	local v773
	if v772 == nil or v772 ~= v772 then
		v773 = 0
	else
		local v774 = v772 + 0.5
		v773 = math.floor(v774)
	end
	local v775 = p735.hits
	local v776 = tonumber(v775)
	local v777
	if v776 == nil or v776 ~= v776 then
		v777 = 0
	else
		local v778 = v776 + 0.5
		v777 = math.floor(v778)
	end
	local v779 = p735.pingAvg
	local v780 = tonumber(v779)
	local v781
	if v780 == nil or v780 ~= v780 then
		v781 = 0
	else
		local v782 = v780 + 0.5
		v781 = math.floor(v782)
	end
	local v783 = p735.pingP95
	local v784 = tonumber(v783)
	local v785
	if v784 == nil or v784 ~= v784 then
		v785 = 0
	else
		local v786 = v784 + 0.5
		v785 = math.floor(v786)
	end
	local v787 = p735.dev or "unknown"
	return v759, v760:format(v762, v765, v769, v773, v777, v781, v785, (tostring(v787)))
end
local v_u_788 = {
	"start",
	"raid",
	"map",
	"difficulty",
	"dur",
	"why",
	"dev",
	"exp",
	"flagAt",
	"thin",
	"pingAvg",
	"pingP95",
	"speedP95",
	"speedMax",
	"shots",
	"hits",
	"heads",
	"kills",
	"snaps",
	"tps",
	"stalls",
	"hitches"
}
function v_u_4.mergeTraceRow(p789, p790) -- name: mergeTraceRow
	-- upvalues: (copy) v_u_788
	if type(p789) == "table" and type(p790) == "table" then
		local v791 = p790.hdr
		if type(v791) == "table" then
			local v792 = p790.key or p790.hdr.key
			if type(v792) ~= "string" then
				return 0
			end
			local v793 = 0
			for _, v794 in p789 do
				if type(v794) ~= "table" or v794.key ~= v792 then
					continue
				end
				for _, v795 in v_u_788 do
					if p790.hdr[v795] == nil then
						continue
					end
					v794[v795] = p790.hdr[v795]
				end
				if p790.expired ~= nil then
					v794.expired = p790.expired
				end
				v794.missing = nil
				v794.error = nil
				v793 = v793 + 1
			end
			return v793
		end
	end
	return 0
end
function v_u_4.traceLines(p796, p797) -- name: traceLines
	-- upvalues: (copy) v_u_4, (copy) v_u_734, (copy) v_u_727, (copy) v_u_728
	local v798 = {}
	if type(p796) == "table" then
		local v799 = p796.hdr
		if type(v799) == "table" then
			local v800 = p796.hdr
			local v801 = p796.stats
			local v802 = type(v801) ~= "table" and {} or p796.stats
			local v803 = p796.ping
			local v804 = type(v803) ~= "table" and {} or p796.ping
			local v805 = {
				["name"] = "TrHead",
				["text"] = nil,
				["kind"] = "head"
			}
			local v806 = "%s  \194\183  raid %s  \194\183  %s %s  \194\183  started %s  \194\183  lasted %s  \194\183  %s  \194\183  device %s"
			local v807 = v800.key
			local v808 = tostring(v807)
			local v809 = v800.raid
			local v810 = tostring(v809)
			local v811 = v800.map
			local v812 = tostring(v811)
			local v813 = v800.difficulty
			local v814 = tostring(v813)
			local v815 = v_u_4.ago
			local v816 = v800.start
			local v817 = v815(p797 - (tonumber(v816) or 0))
			local v818 = v800.dur
			local v819 = tonumber(v818) or 0
			local v820 = math.floor(v819)
			local v821 = math.max(0, v820)
			local v822
			if v821 < 3600 then
				local v823 = v821 / 60
				v822 = ("%d min"):format((math.floor(v823)))
			else
				local v824 = v821 / 3600
				local v825 = math.floor(v824)
				local v826 = v821 % 3600 / 60
				v822 = ("%d h %d min"):format(v825, (math.floor(v826)))
			end
			local v827 = ({
				["flag"] = "FLAG",
				["report"] = "REPORT",
				["watch"] = "WATCH"
			})[v800.why] or "FLAG"
			local v828 = v800.dev or "unknown"
			v805.text = v806:format(v808, v810, v812, v814, v817, v822, v827, (tostring(v828)))
			table.insert(v798, v805)
			local v829 = v800.flagAt
			if type(v829) == "number" then
				local v830 = {
					["name"] = "TrFlag",
					["text"] = nil,
					["kind"] = "warn",
					["text"] = ("the flag or the report arrived %s into the recording: the part before it is the buffer of the last 5 minutes, the rest is the full recording"):format(v_u_734(v800.flagAt))
				}
				table.insert(v798, v830)
			end
			local v831 = {
				["name"] = "TrSpeed",
				["text"] = nil,
				["kind"] = "text"
			}
			local v832 = "walk speed p50 %.1f  \194\183  p95 %.1f  \194\183  max %.1f studs per second  \194\183  %d samples  \194\183  %d gaps  \194\183  %d server hitches  \194\183  %d client stalls"
			local v833 = v802.speedP50
			local v834 = tonumber(v833) or 0
			local v835 = v802.speedP95
			local v836 = tonumber(v835) or 0
			local v837 = v802.speedMax
			local v838 = tonumber(v837) or 0
			local v839 = v802.samples
			local v840 = tonumber(v839)
			local v841
			if v840 == nil or v840 ~= v840 then
				v841 = 0
			else
				local v842 = v840 + 0.5
				v841 = math.floor(v842)
			end
			local v843 = v802.gaps
			local v844 = tonumber(v843)
			local v845
			if v844 == nil or v844 ~= v844 then
				v845 = 0
			else
				local v846 = v844 + 0.5
				v845 = math.floor(v846)
			end
			local v847 = v802.hitches
			local v848 = tonumber(v847)
			local v849
			if v848 == nil or v848 ~= v848 then
				v849 = 0
			else
				local v850 = v848 + 0.5
				v849 = math.floor(v850)
			end
			local v851 = v802.stalls
			local v852 = tonumber(v851)
			local v853
			if v852 == nil or v852 ~= v852 then
				v853 = 0
			else
				local v854 = v852 + 0.5
				v853 = math.floor(v854)
			end
			v831.text = v832:format(v834, v836, v838, v841, v845, v849, v853)
			table.insert(v798, v831)
			local v855 = {
				["name"] = "TrCombat",
				["text"] = nil,
				["kind"] = "text"
			}
			local v856 = "shots %d  \194\183  hits %d  \194\183  head hits %d (%d percent)  \194\183  kills %d"
			local v857 = v802.shots
			local v858 = tonumber(v857)
			local v859
			if v858 == nil or v858 ~= v858 then
				v859 = 0
			else
				local v860 = v858 + 0.5
				v859 = math.floor(v860)
			end
			local v861 = v802.hits
			local v862 = tonumber(v861)
			local v863
			if v862 == nil or v862 ~= v862 then
				v863 = 0
			else
				local v864 = v862 + 0.5
				v863 = math.floor(v864)
			end
			local v865 = v802.heads
			local v866 = tonumber(v865)
			local v867
			if v866 == nil or v866 ~= v866 then
				v867 = 0
			else
				local v868 = v866 + 0.5
				v867 = math.floor(v868)
			end
			local v869 = v802.headRatio
			local v870 = (tonumber(v869) or 0) * 100
			local v871 = tonumber(v870)
			local v872
			if v871 == nil or v871 ~= v871 then
				v872 = 0
			else
				local v873 = v871 + 0.5
				v872 = math.floor(v873)
			end
			local v874 = v802.kills
			local v875 = tonumber(v874)
			local v876
			if v875 == nil or v875 ~= v875 then
				v876 = 0
			else
				local v877 = v875 + 0.5
				v876 = math.floor(v877)
			end
			v855.text = v856:format(v859, v863, v867, v872, v876)
			table.insert(v798, v855)
			local v878 = {
				["name"] = "TrSigns",
				["text"] = nil,
				["kind"] = nil
			}
			local v879 = "snaps %d  \194\183  teleports %d  \194\183  server moves %d  (a snap is a wall or speed hop the server undid)"
			local v880 = v802.snaps
			local v881 = tonumber(v880)
			local v882
			if v881 == nil or v881 ~= v881 then
				v882 = 0
			else
				local v883 = v881 + 0.5
				v882 = math.floor(v883)
			end
			local v884 = v802.tps
			local v885 = tonumber(v884)
			local v886
			if v885 == nil or v885 ~= v885 then
				v886 = 0
			else
				local v887 = v885 + 0.5
				v886 = math.floor(v887)
			end
			local v888 = v802.moves
			local v889 = tonumber(v888)
			local v890
			if v889 == nil or v889 ~= v889 then
				v890 = 0
			else
				local v891 = v889 + 0.5
				v890 = math.floor(v891)
			end
			v878.text = v879:format(v882, v886, v890)
			local v892 = v802.snaps
			local v893 = tonumber(v892)
			local v894
			if v893 == nil or v893 ~= v893 then
				v894 = 0
			else
				local v895 = v893 + 0.5
				v894 = math.floor(v895)
			end
			local v896 = v802.tps
			local v897 = tonumber(v896)
			local v898
			if v897 == nil or v897 ~= v897 then
				v898 = 0
			else
				local v899 = v897 + 0.5
				v898 = math.floor(v899)
			end
			v878.kind = v894 + v898 > 0 and "warn" or "text"
			table.insert(v798, v878)
			local v900 = {
				["name"] = "TrPing",
				["text"] = nil,
				["kind"] = "muted"
			}
			local v901 = "ping average %d ms  \194\183  p95 %d ms  \194\183  max %d ms"
			local v902 = v804.avg
			local v903 = tonumber(v902)
			local v904
			if v903 == nil or v903 ~= v903 then
				v904 = 0
			else
				local v905 = v903 + 0.5
				v904 = math.floor(v905)
			end
			local v906 = v804.p95
			local v907 = tonumber(v906)
			local v908
			if v907 == nil or v907 ~= v907 then
				v908 = 0
			else
				local v909 = v907 + 0.5
				v908 = math.floor(v909)
			end
			local v910 = v804.max
			local v911 = tonumber(v910)
			local v912
			if v911 == nil or v911 ~= v911 then
				v912 = 0
			else
				local v913 = v911 + 0.5
				v912 = math.floor(v913)
			end
			v900.text = v901:format(v904, v908, v912)
			table.insert(v798, v900)
			local v914 = v800.thin
			if tonumber(v914) and v800.thin > 1 then
				local v915 = {
					["name"] = "TrThin",
					["text"] = nil,
					["kind"] = "muted"
				}
				local v916 = "the trace is thinned to every %dth sample to fit the size limit (snaps, teleports and kills are never dropped)"
				local v917 = v800.thin
				local v918 = tonumber(v917)
				local v919
				if v918 == nil or v918 ~= v918 then
					v919 = 0
				else
					local v920 = v918 + 0.5
					v919 = math.floor(v920)
				end
				v915.text = v916:format(v919)
				table.insert(v798, v915)
			end
			if p796.expired == true then
				table.insert(v798, {
					["name"] = "TrExp",
					["text"] = "this trace is past its expiry date (30 days): the Spark may delete it",
					["kind"] = "warn"
				})
			else
				local v921 = p796.exp
				if tonumber(v921) and p796.exp > 0 then
					local v922 = {
						["name"] = "TrExp",
						["text"] = nil,
						["kind"] = "muted"
					}
					local v923 = (p796.exp - p797) / 86400
					local v924 = math.floor(v923)
					v922.text = ("expires in %d days"):format((math.max(0, v924)))
					table.insert(v798, v922)
				end
			end
			local v925 = p796.ev
			local v926 = 0
			for _, v927 in type(v925) ~= "table" and {} or p796.ev do
				if v927.k ~= "snap" and (v927.k ~= "tp" and (v927.k ~= "mv" and v927.k ~= "extract")) then
					continue
				end
				v926 = v926 + 1
				if v926 > 14 then
					continue
				end
				local v928 = {
					["name"] = "TrEv" .. v926
				}
				local v929 = "%s  \194\183  %s%s"
				local v930 = v927.t
				local v931 = tonumber(v930) or 0
				local v932 = math.floor(v931)
				local v933 = math.max(0, v932)
				local v934 = v933 / 60
				local v935 = ("%d:%02d"):format(math.floor(v934), v933 % 60)
				local v936 = v_u_727[v927.k]
				if not v936 then
					local v937 = v927.k
					v936 = tostring(v937)
				end
				local v938 = v_u_728
				local v939 = v927.k
				local v940 = v938[tostring(v939)]
				local v941
				if v940 then
					local v942 = v927.c
					local v943 = tonumber(v942)
					local v944
					if v943 == nil or v943 ~= v943 then
						v944 = 0
					else
						local v945 = v943 + 0.5
						v944 = math.floor(v945)
					end
					v941 = v940[v944]
				else
					v941 = nil
				end
				v928.text = v929:format(v935, v936, not v941 and "" or " (" .. v941 .. ")")
				v928.kind = (v927.k == "snap" or v927.k == "tp") and "warn" or "muted"
				table.insert(v798, v928)
			end
			if v926 > 14 then
				local v946 = {
					["name"] = "TrEvMore",
					["text"] = nil,
					["kind"] = "muted",
					["text"] = ("and %d more critical events"):format(v926 - 14)
				}
				table.insert(v798, v946)
			end
			return v798
		end
	end
	return v798
end
local function v_u_951(p947) -- name: niceStuds
	local v948 = {
		10,
		20,
		50,
		100,
		200,
		500,
		1000,
		2000
	}
	local v949 = v948[1]
	for _, v950 in v948 do
		if v950 > p947 then
			continue
		end
		v949 = v950
	end
	return v949
end
function v_u_4.canvasPlan(p952, p953) -- name: canvasPlan
	-- upvalues: (copy) v_u_951
	local v954 = {
		["segs"] = nil,
		["dots"] = nil,
		["side"] = nil,
		["zoomed"] = false,
		["span"] = 0,
		["scale"] = 1,
		["barStuds"] = 0,
		["barPx"] = 0,
		["segs"] = {},
		["dots"] = {},
		["side"] = p953
	}
	if type(p952) == "table" then
		local v955 = p952.x
		if type(v955) == "table" then
			local v956 = p952.z
			if type(v956) == "table" and (#p952.x ~= 0 and #p952.x == #p952.z) then
				local v957 = #p952.x
				local v958 = (1 / 0)
				local v959 = (-1 / 0)
				local v960 = (1 / 0)
				local v961 = (-1 / 0)
				for v962 = 1, v957 do
					local v963 = p952.x[v962]
					local v964 = (tonumber(v963) or 0) / 2
					local v965 = p952.z[v962]
					local v966 = (tonumber(v965) or 0) / 2
					v958 = math.min(v958, v964)
					v959 = math.max(v959, v964)
					v960 = math.min(v960, v966)
					v961 = math.max(v961, v966)
				end
				local v967 = p952.half
				local v968 = tonumber(v967) or 0
				local v969 = v959 - v958
				local v970 = v961 - v960
				local v971 = math.max(v969, v970)
				local v972, v973, v974
				if v968 > 0 and (-v968 <= v958 and (v959 <= v968 and (-v968 <= v960 and (v961 <= v968 and v968 * 2 * 0.35 <= v971)))) then
					v972 = v968 * 2
					v973 = 0
					v974 = 0
				else
					v972 = math.max(v971, 40) * 1.15
					v973 = (v958 + v959) / 2
					v974 = (v960 + v961) / 2
					v954.zoomed = true
				end
				local v975 = p953 / v972
				local v976 = v973 - v972 / 2
				local v977 = v974 - v972 / 2
				local v978 = p952.t
				local v979 = type(v978) ~= "table" and {} or p952.t
				for v980 = 1, v957 - 1 do
					local v981 = p952.x[v980 + 1]
					local v982 = tonumber(v981) or 0
					local v983 = p952.x[v980]
					local v984 = (v982 - (tonumber(v983) or 0)) / 2
					local v985 = p952.z[v980 + 1]
					local v986 = tonumber(v985) or 0
					local v987 = p952.z[v980]
					local v988 = (v986 - (tonumber(v987) or 0)) / 2
					local v989 = v979[v980 + 1]
					local v990 = tonumber(v989) or 0
					local v991 = v979[v980]
					local v992 = v990 - (tonumber(v991) or 0)
					local v993 = math.max(0.25, v992)
					local v994 = v954.segs
					local v995 = {}
					local v996 = p952.x[v980]
					v995.x1 = ((tonumber(v996) or 0) / 2 - v976) * v975
					local v997 = p952.z[v980]
					v995.y1 = ((tonumber(v997) or 0) / 2 - v977) * v975
					local v998 = p952.x[v980 + 1]
					v995.x2 = ((tonumber(v998) or 0) / 2 - v976) * v975
					local v999 = p952.z[v980 + 1]
					v995.y2 = ((tonumber(v999) or 0) / 2 - v977) * v975
					local v1000 = v984 * v984 + v988 * v988
					v995.fast = math.sqrt(v1000) / v993 >= 60
					table.insert(v994, v995)
				end
				local v1001 = p952.ev
				if type(v1001) == "table" then
					for v1002, v1003 in p952.ev do
						if v1002 > 100 then
							break
						end
						local v1004 = v954.dots
						local v1005 = {}
						local v1006 = v1003.x
						v1005.x = ((tonumber(v1006) or 0) / 2 - v976) * v975
						local v1007 = v1003.z
						v1005.y = ((tonumber(v1007) or 0) / 2 - v977) * v975
						local v1008 = v1003.k
						v1005.k = tostring(v1008)
						local v1009 = v1003.t
						v1005.t = tonumber(v1009) or 0
						table.insert(v1004, v1005)
					end
				end
				local v1010 = {}
				local v1011 = p952.x[1]
				v1010.x = ((tonumber(v1011) or 0) / 2 - v976) * v975
				local v1012 = p952.z[1]
				v1010.y = ((tonumber(v1012) or 0) / 2 - v977) * v975
				v954.startPt = v1010
				local v1013 = {}
				local v1014 = p952.x[v957]
				v1013.x = ((tonumber(v1014) or 0) / 2 - v976) * v975
				local v1015 = p952.z[v957]
				v1013.y = ((tonumber(v1015) or 0) / 2 - v977) * v975
				v954.endPt = v1013
				v954.span = v972
				v954.scale = v975
				v954.barStuds = v_u_951(v972 / 4)
				v954.barPx = v954.barStuds * v975
				return v954
			end
		end
	end
	return v954
end
function v_u_4.lookupLines(p1016, p1017) -- name: lookupLines
	-- upvalues: (copy) v_u_4
	local v1018 = {}
	if type(p1016) ~= "table" then
		return v1018
	end
	local v1019 = p1016.record
	local v1020 = p1016.facts
	local v1021 = {
		["name"] = "Who",
		["text"] = nil,
		["kind"] = "head"
	}
	local v1022 = "%s  \194\183  user id %d%s"
	local v1023 = p1016.name == "" and "unknown name" or (p1016.name or "unknown name")
	local v1024 = tostring(v1023)
	local v1025 = p1016.uid
	local v1026 = tonumber(v1025)
	local v1027
	if v1026 == nil or v1026 ~= v1026 then
		v1027 = 0
	else
		local v1028 = v1026 + 0.5
		v1027 = math.floor(v1028)
	end
	local v1029 = p1016.live
	v1021.text = v1022:format(v1024, v1027, type(v1029) == "table" and "  \194\183  on this server" or "")
	table.insert(v1018, v1021)
	for _, v1030 in v_u_4.verdictLines(p1016.verdict, p1017) do
		table.insert(v1018, v1030)
	end
	local v1031, v1032, v1033, v1034, v1035, v1036, v1037, v1038, v1039, v1040, v1041, v1042, v1043, v1044, v1045, v1046, v1047, v1048, v1049, v1050, v1051, v1052, v1053, v1054, v1055, v1056, v1057, v1058, v1059, v1060, v1061, v1062, v1063, v1064, v1065, v1066, v1067, v1068, v1069, v1070, v1071, v1072, v1073, v1074, v1075, v1076, v1077, v1078, v1079, v1080, v1081, v1082, v1083, v1084, v1085, v1086, v1087, v1088, v1089, v1090, v1091, v1092, v1093, v1094, v1095, v1096, v1097, v1098, v1099, v1100, v1101, v1102
	if type(v1019) ~= "table" then
		table.insert(v1018, {
			["name"] = "Flag",
			["text"] = "No flag record for this player.",
			["kind"] = "muted"
		})
		v1203 = p1016.live
		if type(v1203) == "table" then
			v1031 = {
				["name"] = "Live",
				["text"] = nil,
				["kind"] = "text"
			}
			v1032 = "now on this server: score %.1f (peak %.1f)  \194\183  top %s  \194\183  ping %d ms  \194\183  %d events%s"
			v1033 = v1203.score
			v1034 = tonumber(v1033) or 0
			v1035 = v1203.peak
			v1036 = tonumber(v1035) or 0
			v1037 = v1203.top == "" and "none" or (v1203.top or "none")
			v1038 = tostring(v1037)
			v1039 = v1203.ping
			v1040 = tonumber(v1039)
			if v1040 == nil or v1040 ~= v1040 then
				v1041 = 0
			else
				v1042 = v1040 + 0.5
				v1041 = math.floor(v1042)
			end
			v1043 = v1203.events
			v1044 = tonumber(v1043)
			if v1044 == nil or v1044 ~= v1044 then
				v1045 = 0
			else
				v1046 = v1044 + 0.5
				v1045 = math.floor(v1046)
			end
			if v1203.exempt then
				v1047 = v1203.exempt
				v1048 = "  \194\183  " .. tostring(v1047) .. " (never flagged)"
			else
				v1048 = ""
			end
			v1031.text = v1032:format(v1034, v1036, v1038, v1041, v1045, v1048)
			table.insert(v1018, v1031)
			v1049 = v1203.ring
			if type(v1049) == "table" then
				for v1204, v1205 in v1203.ring do
					v1050 = {
						["name"] = nil,
						["text"] = nil,
						["kind"] = "muted",
						["name"] = "Ring" .. v1204
					}
					v1051 = "%d s ago  \194\183  %s  \194\183  %.1f  \194\183  ping %d  \194\183  %s"
					v1052 = v1205.age
					v1053 = tonumber(v1052)
					if v1053 == nil or v1053 ~= v1053 then
						v1054 = 0
					else
						v1055 = v1053 + 0.5
						v1054 = math.floor(v1055)
					end
					v1056 = v1205.code
					v1057 = tostring(v1056)
					v1058 = v1205.w
					v1059 = tonumber(v1058) or 0
					v1060 = v1205.ping
					v1061 = tonumber(v1060)
					if v1061 == nil or v1061 ~= v1061 then
						v1062 = 0
					else
						v1063 = v1061 + 0.5
						v1062 = math.floor(v1063)
					end
					v1064 = v1205.info
					v1050.text = v1051:format(v1054, v1057, v1059, v1062, (tostring(v1064)))
					table.insert(v1018, v1050)
				end
			end
		end
		if type(v1020) == "table" then
			v1065 = {
				["name"] = "Facts",
				["text"] = nil,
				["kind"] = "text"
			}
			v1066 = "profile: %s%splay time %s  \194\183  %s raids  \194\183  %s extractions  \194\183  %s deaths  \194\183  %s kills  \194\183  cash $%s  \194\183  total value $%s"
			v1067 = not v1020.ageDays and "" or "account age " .. v_u_4.number(v1020.ageDays) .. " days  \194\183  "
			v1068 = v1020.created
			v1069 = (tonumber(v1068) or 0) <= 0 and "" or "profile made " .. v_u_4.ago(p1017 - v1020.created) .. "  \194\183  "
			v1070 = v1020.playSec
			v1071 = tonumber(v1070) or 0
			v1072 = math.floor(v1071)
			v1073 = math.max(0, v1072)
			if v1073 < 3600 then
				v1074 = v1073 / 60
				v1075 = ("%d min"):format((math.floor(v1074)))
			else
				v1076 = v1073 / 3600
				v1077 = math.floor(v1076)
				v1078 = v1073 % 3600 / 60
				v1075 = ("%d h %d min"):format(v1077, (math.floor(v1078)))
			end
			v1065.text = v1066:format(v1067, v1069, v1075, v_u_4.number(v1020.raids), v_u_4.number(v1020.extracts), v_u_4.number(v1020.deaths), v_u_4.number(v1020.kills), v_u_4.number(v1020.cash), v_u_4.number(v1020.totalValue))
			table.insert(v1018, v1065)
			v1079 = v1020.lastRaid
			if type(v1079) == "table" then
				v1080 = {
					["name"] = "LastRaid",
					["text"] = nil,
					["kind"] = "muted"
				}
				v1081 = "last raid %s: %s on %s  \194\183  loot $%s  \194\183  %d kills  \194\183  %s%s"
				v1082 = v_u_4.ago
				v1083 = v1079.at
				v1084 = v1082(p1017 - (tonumber(v1083) or 0))
				v1085 = v1079.outcome
				v1086 = tostring(v1085)
				v1087 = v1079.difficulty
				v1088 = tostring(v1087)
				v1089 = v_u_4.number(v1079.value)
				v1090 = v1079.kills
				v1091 = tonumber(v1090)
				if v1091 == nil or v1091 ~= v1091 then
					v1092 = 0
				else
					v1093 = v1091 + 0.5
					v1092 = math.floor(v1093)
				end
				v1094 = v1079.durationSec
				v1095 = tonumber(v1094) or 0
				v1096 = math.floor(v1095)
				v1097 = math.max(0, v1096)
				if v1097 < 3600 then
					v1098 = v1097 / 60
					v1099 = ("%d min"):format((math.floor(v1098)))
				else
					v1100 = v1097 / 3600
					v1101 = math.floor(v1100)
					v1102 = v1097 % 3600 / 60
					v1099 = ("%d h %d min"):format(v1101, (math.floor(v1102)))
				end
				v1080.text = v1081:format(v1084, v1086, v1088, v1089, v1092, v1099, v1079.free and "  \194\183  free raid" or "")
				table.insert(v1018, v1080)
				return v1018
			end
		else
			table.insert(v1018, {
				["name"] = "Facts",
				["text"] = "No profile facts (the player is not on this server and the profile is not read in this place).",
				["kind"] = "muted"
			})
		end
		return v1018
	end
	local v1105 = {
		["name"] = "Flag",
		["text"] = nil,
		["kind"] = nil
	}
	local v1106 = "%s  \194\183  strongest score %.1f  \194\183  top reason %s  \194\183  first seen %s  \194\183  last seen %s%s"
	local v1107
	if v1019.flagged then
		local v1108 = v_u_4.ago
		local v1109 = v1019.flaggedAt
		local v1110 = v1108(p1017 - (tonumber(v1109) or 0))
		local v1111 = v1019.why
		v1107 = "FLAGGED " .. v1110 .. " (" .. tostring(v1111) .. ")"
	else
		v1107 = "not flagged"
	end
	local v1112 = v1019.score
	local v1113 = tonumber(v1112) or 0
	local v1114 = v1019.top == "" and "none" or (v1019.top or "none")
	local v1115 = tostring(v1114)
	local v1116 = v_u_4.ago
	local v1117 = v1019.first
	local v1118 = v1116(p1017 - (tonumber(v1117) or 0))
	local v1119 = v_u_4.ago
	local v1120 = v1019.last
	local v1121 = v1119(p1017 - (tonumber(v1120) or 0))
	local v1122 = v1019.reviewed
	local v1123
	if type(v1122) == "table" then
		local v1124 = v1019.reviewed.byName
		local v1125 = tostring(v1124)
		local v1126 = v_u_4.ago
		local v1127 = v1019.reviewed.at
		v1123 = "  \194\183  reviewed by " .. v1125 .. " " .. v1126(p1017 - (tonumber(v1127) or 0))
	else
		v1123 = ""
	end
	v1105.text = v1106:format(v1107, v1113, v1115, v1118, v1121, v1123)
	v1105.kind = v1019.flagged and "warn" or "text"
	table.insert(v1018, v1105)
	local v1128 = v1019.raid or ""
	if tostring(v1128) ~= "" then
		local v1129 = {
			["name"] = "Place",
			["text"] = nil,
			["kind"] = "muted"
		}
		local v1130 = "last place %d  \194\183  last raid %s"
		local v1131 = v1019.place
		local v1132 = tonumber(v1131)
		local v1133
		if v1132 == nil or v1132 ~= v1132 then
			v1133 = 0
		else
			local v1134 = v1132 + 0.5
			v1133 = math.floor(v1134)
		end
		local v1135 = v1019.raid
		v1129.text = v1130:format(v1133, (tostring(v1135)))
		table.insert(v1018, v1129)
	end
	local v1136 = v1019.reasons
	if type(v1136) == "table" then
		for v1137, v1138 in v1019.reasons do
			local v1139 = {
				["name"] = nil,
				["text"] = nil,
				["kind"] = "text",
				["name"] = "Reason" .. v1137
			}
			local v1140 = "reason %s  \194\183  %d events  \194\183  in %d raids"
			local v1141 = v1138.code
			local v1142 = tostring(v1141)
			local v1143 = v1138.n
			local v1144 = tonumber(v1143)
			local v1145
			if v1144 == nil or v1144 ~= v1144 then
				v1145 = 0
			else
				local v1146 = v1144 + 0.5
				v1145 = math.floor(v1146)
			end
			local v1147 = v1138.raids
			local v1148 = tonumber(v1147)
			local v1149
			if v1148 == nil or v1148 ~= v1148 then
				v1149 = 0
			else
				local v1150 = v1148 + 0.5
				v1149 = math.floor(v1150)
			end
			v1139.text = v1140:format(v1142, v1145, v1149)
			table.insert(v1018, v1139)
		end
	end
	local v1151 = v1019.evidence
	if type(v1151) == "table" then
		for v1152, v1153 in v1019.evidence do
			local v1154 = {
				["name"] = nil,
				["text"] = nil,
				["kind"] = "muted",
				["name"] = "Ev" .. v1152,
				["text"] = "evidence " .. tostring(v1153)
			}
			table.insert(v1018, v1154)
		end
	end
	local v1155 = v1019.history
	if type(v1155) == "table" then
		for v1156, v1157 in v1019.history do
			local v1158 = {
				["name"] = nil,
				["text"] = nil,
				["kind"] = "muted",
				["name"] = "Hist" .. v1156
			}
			local v1159 = "earlier flag %s, cleared %s by %s  \194\183  score %.1f  \194\183  %s  \194\183  %d events"
			local v1160 = v_u_4.ago
			local v1161 = v1157.at
			local v1162 = v1160(p1017 - (tonumber(v1161) or 0))
			local v1163 = v_u_4.ago
			local v1164 = v1157.clearedAt
			local v1165 = v1163(p1017 - (tonumber(v1164) or 0))
			local v1166 = v1157.byName == "" and "?" or (v1157.byName or "?")
			local v1167 = tostring(v1166)
			local v1168 = v1157.score
			local v1169 = tonumber(v1168) or 0
			local v1170 = v1157.top == "" and "none" or (v1157.top or "none")
			local v1171 = tostring(v1170)
			local v1172 = v1157.n
			local v1173 = tonumber(v1172)
			local v1174
			if v1173 == nil or v1173 ~= v1173 then
				v1174 = 0
			else
				local v1175 = v1173 + 0.5
				v1174 = math.floor(v1175)
			end
			v1158.text = v1159:format(v1162, v1165, v1167, v1169, v1171, v1174)
			table.insert(v1018, v1158)
		end
	end
	local v1176 = v1019.reports
	local v1177
	if type(v1176) ~= "table" or #v1019.reports <= 0 then
		v1202 = v1019.traces
		if type(v1202) == "table" and #v1019.traces > 0 then
			v1177 = {
				["name"] = "Traces",
				["text"] = nil,
				["kind"] = "text",
				["text"] = ("flight recorder: %d traces listed below (the newest first)"):format(#v1019.traces)
			}
			table.insert(v1018, v1177)
		end
		v1203 = p1016.live
		if type(v1203) == "table" then
			v1031 = {
				["name"] = "Live",
				["text"] = nil,
				["kind"] = "text"
			}
			v1032 = "now on this server: score %.1f (peak %.1f)  \194\183  top %s  \194\183  ping %d ms  \194\183  %d events%s"
			v1033 = v1203.score
			v1034 = tonumber(v1033) or 0
			v1035 = v1203.peak
			v1036 = tonumber(v1035) or 0
			v1037 = v1203.top == "" and "none" or (v1203.top or "none")
			v1038 = tostring(v1037)
			v1039 = v1203.ping
			v1040 = tonumber(v1039)
			if v1040 == nil or v1040 ~= v1040 then
				v1041 = 0
			else
				v1042 = v1040 + 0.5
				v1041 = math.floor(v1042)
			end
			v1043 = v1203.events
			v1044 = tonumber(v1043)
			if v1044 == nil or v1044 ~= v1044 then
				v1045 = 0
			else
				v1046 = v1044 + 0.5
				v1045 = math.floor(v1046)
			end
			if v1203.exempt then
				v1047 = v1203.exempt
				v1048 = "  \194\183  " .. tostring(v1047) .. " (never flagged)"
			else
				v1048 = ""
			end
			v1031.text = v1032:format(v1034, v1036, v1038, v1041, v1045, v1048)
			table.insert(v1018, v1031)
			v1049 = v1203.ring
			if type(v1049) == "table" then
				for v1204, v1205 in v1203.ring do
					v1050 = {
						["name"] = nil,
						["text"] = nil,
						["kind"] = "muted",
						["name"] = "Ring" .. v1204
					}
					v1051 = "%d s ago  \194\183  %s  \194\183  %.1f  \194\183  ping %d  \194\183  %s"
					v1052 = v1205.age
					v1053 = tonumber(v1052)
					if v1053 == nil or v1053 ~= v1053 then
						v1054 = 0
					else
						v1055 = v1053 + 0.5
						v1054 = math.floor(v1055)
					end
					v1056 = v1205.code
					v1057 = tostring(v1056)
					v1058 = v1205.w
					v1059 = tonumber(v1058) or 0
					v1060 = v1205.ping
					v1061 = tonumber(v1060)
					if v1061 == nil or v1061 ~= v1061 then
						v1062 = 0
					else
						v1063 = v1061 + 0.5
						v1062 = math.floor(v1063)
					end
					v1064 = v1205.info
					v1050.text = v1051:format(v1054, v1057, v1059, v1062, (tostring(v1064)))
					table.insert(v1018, v1050)
				end
			end
		end
		if type(v1020) == "table" then
			v1065 = {
				["name"] = "Facts",
				["text"] = nil,
				["kind"] = "text"
			}
			v1066 = "profile: %s%splay time %s  \194\183  %s raids  \194\183  %s extractions  \194\183  %s deaths  \194\183  %s kills  \194\183  cash $%s  \194\183  total value $%s"
			v1067 = not v1020.ageDays and "" or "account age " .. v_u_4.number(v1020.ageDays) .. " days  \194\183  "
			v1068 = v1020.created
			v1069 = (tonumber(v1068) or 0) <= 0 and "" or "profile made " .. v_u_4.ago(p1017 - v1020.created) .. "  \194\183  "
			v1070 = v1020.playSec
			v1071 = tonumber(v1070) or 0
			v1072 = math.floor(v1071)
			v1073 = math.max(0, v1072)
			if v1073 < 3600 then
				v1074 = v1073 / 60
				v1075 = ("%d min"):format((math.floor(v1074)))
			else
				v1076 = v1073 / 3600
				v1077 = math.floor(v1076)
				v1078 = v1073 % 3600 / 60
				v1075 = ("%d h %d min"):format(v1077, (math.floor(v1078)))
			end
			v1065.text = v1066:format(v1067, v1069, v1075, v_u_4.number(v1020.raids), v_u_4.number(v1020.extracts), v_u_4.number(v1020.deaths), v_u_4.number(v1020.kills), v_u_4.number(v1020.cash), v_u_4.number(v1020.totalValue))
			table.insert(v1018, v1065)
			v1079 = v1020.lastRaid
			if type(v1079) == "table" then
				v1080 = {
					["name"] = "LastRaid",
					["text"] = nil,
					["kind"] = "muted"
				}
				v1081 = "last raid %s: %s on %s  \194\183  loot $%s  \194\183  %d kills  \194\183  %s%s"
				v1082 = v_u_4.ago
				v1083 = v1079.at
				v1084 = v1082(p1017 - (tonumber(v1083) or 0))
				v1085 = v1079.outcome
				v1086 = tostring(v1085)
				v1087 = v1079.difficulty
				v1088 = tostring(v1087)
				v1089 = v_u_4.number(v1079.value)
				v1090 = v1079.kills
				v1091 = tonumber(v1090)
				if v1091 == nil or v1091 ~= v1091 then
					v1092 = 0
				else
					v1093 = v1091 + 0.5
					v1092 = math.floor(v1093)
				end
				v1094 = v1079.durationSec
				v1095 = tonumber(v1094) or 0
				v1096 = math.floor(v1095)
				v1097 = math.max(0, v1096)
				if v1097 < 3600 then
					v1098 = v1097 / 60
					v1099 = ("%d min"):format((math.floor(v1098)))
				else
					v1100 = v1097 / 3600
					v1101 = math.floor(v1100)
					v1102 = v1097 % 3600 / 60
					v1099 = ("%d h %d min"):format(v1101, (math.floor(v1102)))
				end
				v1080.text = v1081:format(v1084, v1086, v1088, v1089, v1092, v1099, v1079.free and "  \194\183  free raid" or "")
				table.insert(v1018, v1080)
				return v1018
			end
		else
			table.insert(v1018, {
				["name"] = "Facts",
				["text"] = "No profile facts (the player is not on this server and the profile is not read in this place).",
				["kind"] = "muted"
			})
		end
		return v1018
	end
	local v1180 = {
		["name"] = "ReportHead",
		["text"] = nil,
		["kind"] = "text"
	}
	local v1181 = "%d reports from players (the newest %d shown)"
	local v1182 = v1019.reportN
	local v1183 = tonumber(v1182)
	local v1184
	if v1183 == nil or v1183 ~= v1183 then
		v1184 = 0
	else
		local v1185 = v1183 + 0.5
		v1184 = math.floor(v1185)
	end
	local v1186
	if v1184 > 0 then
		local v1187 = v1019.reportN
		local v1188 = tonumber(v1187)
		if v1188 == nil or v1188 ~= v1188 then
			v1186 = 0
		else
			local v1189 = v1188 + 0.5
			v1186 = math.floor(v1189)
		end
		if v1186 then
			v1180.text = v1181:format(v1186, #v1019.reports)
			table.insert(v1018, v1180)
			for v1198, v1199 in v1019.reports do
				for v1200, v1201 in v_u_4.reportRows(v1199, v1198, p1017) do
					table.insert(v1018, v1201)
				end
			end
		else
			v1186 = #v1019.reports
			v1180.text = v1181:format(v1186, #v1019.reports)
			table.insert(v1018, v1180)
			for v1198, v1199 in v1019.reports do
				for v1200, v1201 in v_u_4.reportRows(v1199, v1198, p1017) do
					table.insert(v1018, v1201)
				end
			end
		end
	else
		v1186 = #v1019.reports
		v1180.text = v1181:format(v1186, #v1019.reports)
		table.insert(v1018, v1180)
		for v1198, v1199 in v1019.reports do
			for v1200, v1201 in v_u_4.reportRows(v1199, v1198, p1017) do
				table.insert(v1018, v1201)
			end
		end
	end
	local v1202 = v1019.traces
	if type(v1202) == "table" and #v1019.traces > 0 then
		v1177 = {
			["name"] = "Traces",
			["text"] = nil,
			["kind"] = "text",
			["text"] = ("flight recorder: %d traces listed below (the newest first)"):format(#v1019.traces)
		}
		table.insert(v1018, v1177)
	end
	local v1203 = p1016.live
	if type(v1203) == "table" then
		v1031 = {
			["name"] = "Live",
			["text"] = nil,
			["kind"] = "text"
		}
		v1032 = "now on this server: score %.1f (peak %.1f)  \194\183  top %s  \194\183  ping %d ms  \194\183  %d events%s"
		v1033 = v1203.score
		v1034 = tonumber(v1033) or 0
		v1035 = v1203.peak
		v1036 = tonumber(v1035) or 0
		v1037 = v1203.top == "" and "none" or (v1203.top or "none")
		v1038 = tostring(v1037)
		v1039 = v1203.ping
		v1040 = tonumber(v1039)
		if v1040 == nil or v1040 ~= v1040 then
			v1041 = 0
		else
			v1042 = v1040 + 0.5
			v1041 = math.floor(v1042)
		end
		v1043 = v1203.events
		v1044 = tonumber(v1043)
		if v1044 == nil or v1044 ~= v1044 then
			v1045 = 0
		else
			v1046 = v1044 + 0.5
			v1045 = math.floor(v1046)
		end
		if v1203.exempt then
			v1047 = v1203.exempt
			v1048 = "  \194\183  " .. tostring(v1047) .. " (never flagged)"
		else
			v1048 = ""
		end
		v1031.text = v1032:format(v1034, v1036, v1038, v1041, v1045, v1048)
		table.insert(v1018, v1031)
		v1049 = v1203.ring
		if type(v1049) == "table" then
			for v1204, v1205 in v1203.ring do
				v1050 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "muted",
					["name"] = "Ring" .. v1204
				}
				v1051 = "%d s ago  \194\183  %s  \194\183  %.1f  \194\183  ping %d  \194\183  %s"
				v1052 = v1205.age
				v1053 = tonumber(v1052)
				if v1053 == nil or v1053 ~= v1053 then
					v1054 = 0
				else
					v1055 = v1053 + 0.5
					v1054 = math.floor(v1055)
				end
				v1056 = v1205.code
				v1057 = tostring(v1056)
				v1058 = v1205.w
				v1059 = tonumber(v1058) or 0
				v1060 = v1205.ping
				v1061 = tonumber(v1060)
				if v1061 == nil or v1061 ~= v1061 then
					v1062 = 0
				else
					v1063 = v1061 + 0.5
					v1062 = math.floor(v1063)
				end
				v1064 = v1205.info
				v1050.text = v1051:format(v1054, v1057, v1059, v1062, (tostring(v1064)))
				table.insert(v1018, v1050)
			end
		end
	end
	if type(v1020) == "table" then
		v1065 = {
			["name"] = "Facts",
			["text"] = nil,
			["kind"] = "text"
		}
		v1066 = "profile: %s%splay time %s  \194\183  %s raids  \194\183  %s extractions  \194\183  %s deaths  \194\183  %s kills  \194\183  cash $%s  \194\183  total value $%s"
		v1067 = not v1020.ageDays and "" or "account age " .. v_u_4.number(v1020.ageDays) .. " days  \194\183  "
		v1068 = v1020.created
		v1069 = (tonumber(v1068) or 0) <= 0 and "" or "profile made " .. v_u_4.ago(p1017 - v1020.created) .. "  \194\183  "
		v1070 = v1020.playSec
		v1071 = tonumber(v1070) or 0
		v1072 = math.floor(v1071)
		v1073 = math.max(0, v1072)
		if v1073 < 3600 then
			v1074 = v1073 / 60
			v1075 = ("%d min"):format((math.floor(v1074)))
		else
			v1076 = v1073 / 3600
			v1077 = math.floor(v1076)
			v1078 = v1073 % 3600 / 60
			v1075 = ("%d h %d min"):format(v1077, (math.floor(v1078)))
		end
		v1065.text = v1066:format(v1067, v1069, v1075, v_u_4.number(v1020.raids), v_u_4.number(v1020.extracts), v_u_4.number(v1020.deaths), v_u_4.number(v1020.kills), v_u_4.number(v1020.cash), v_u_4.number(v1020.totalValue))
		table.insert(v1018, v1065)
		v1079 = v1020.lastRaid
		if type(v1079) == "table" then
			v1080 = {
				["name"] = "LastRaid",
				["text"] = nil,
				["kind"] = "muted"
			}
			v1081 = "last raid %s: %s on %s  \194\183  loot $%s  \194\183  %d kills  \194\183  %s%s"
			v1082 = v_u_4.ago
			v1083 = v1079.at
			v1084 = v1082(p1017 - (tonumber(v1083) or 0))
			v1085 = v1079.outcome
			v1086 = tostring(v1085)
			v1087 = v1079.difficulty
			v1088 = tostring(v1087)
			v1089 = v_u_4.number(v1079.value)
			v1090 = v1079.kills
			v1091 = tonumber(v1090)
			if v1091 == nil or v1091 ~= v1091 then
				v1092 = 0
			else
				v1093 = v1091 + 0.5
				v1092 = math.floor(v1093)
			end
			v1094 = v1079.durationSec
			v1095 = tonumber(v1094) or 0
			v1096 = math.floor(v1095)
			v1097 = math.max(0, v1096)
			if v1097 < 3600 then
				v1098 = v1097 / 60
				v1099 = ("%d min"):format((math.floor(v1098)))
			else
				v1100 = v1097 / 3600
				v1101 = math.floor(v1100)
				v1102 = v1097 % 3600 / 60
				v1099 = ("%d h %d min"):format(v1101, (math.floor(v1102)))
			end
			v1080.text = v1081:format(v1084, v1086, v1088, v1089, v1092, v1099, v1079.free and "  \194\183  free raid" or "")
			table.insert(v1018, v1080)
			return v1018
		end
	else
		table.insert(v1018, {
			["name"] = "Facts",
			["text"] = "No profile facts (the player is not on this server and the profile is not read in this place).",
			["kind"] = "muted"
		})
	end
	return v1018
end
local v_u_1206 = {
	["move.kick_tp"] = "teleport",
	["move.kick_speed"] = "speed",
	["move.kick_wall"] = "wall passes"
}
function v_u_4.instantLines(p1207, p1208) -- name: instantLines
	-- upvalues: (copy) v_u_4, (copy) v_u_1206
	local v1209 = {}
	if type(p1207) ~= "table" or p1207.available ~= true then
		table.insert(v1209, {
			["name"] = "Status",
			["text"] = "instant kick: not available in this place (or the status was not read yet)",
			["kind"] = "muted"
		})
		return v1209
	end
	local v1210
	if p1207.read == true then
		local v1211 = p1207.doc
		if type(v1211) == "table" then
			local v1212 = "v%d by %s %s"
			local v1213 = v1211.v
			local v1214 = tonumber(v1213)
			local v1215
			if v1214 == nil or v1214 ~= v1214 then
				v1215 = 0
			else
				local v1216 = v1214 + 0.5
				v1215 = math.floor(v1216)
			end
			local v1217 = v1211.byName
			local v1218 = tostring(v1217)
			local v1219 = v_u_4.ago
			local v1220 = v1211.at
			v1210 = v1212:format(v1215, v1218, v1219(p1208 - (tonumber(v1220) or 0)))
		else
			v1210 = "not written (both ON)"
		end
	else
		v1210 = "never read (both OFF)"
	end
	local v1221 = {
		["name"] = "Status",
		["text"] = nil,
		["kind"] = nil,
		["text"] = ("instant kick %s  \194\183  PvP hit check %s  \194\183  build switches %s / %s  \194\183  document %s"):format(p1207.kickOn == true and "ON" or "OFF", p1207.refuseOn == true and "ON" or "OFF", p1207.cfgKick == true and "ON" or "OFF", p1207.cfgRefuse == true and "ON" or "OFF", v1210),
		["kind"] = p1207.kickOn == true and "ok" or "warn"
	}
	table.insert(v1209, v1221)
	local v1222 = p1207.counters
	local v1223 = type(v1222) ~= "table" and {} or p1207.counters
	local v1224 = {
		["name"] = "Counters",
		["text"] = nil,
		["kind"] = "text"
	}
	local v1225 = "kicked %d  \194\183  recorded only (switch off) %d  \194\183  exempt %d  \194\183  Studio %d  \194\183  brake %d  \194\183  events %d  \194\183  gate closed %d"
	local v1226 = v1223.kicked
	local v1227 = tonumber(v1226)
	local v1228
	if v1227 == nil or v1227 ~= v1227 then
		v1228 = 0
	else
		local v1229 = v1227 + 0.5
		v1228 = math.floor(v1229)
	end
	local v1230 = v1223.would
	local v1231 = tonumber(v1230)
	local v1232
	if v1231 == nil or v1231 ~= v1231 then
		v1232 = 0
	else
		local v1233 = v1231 + 0.5
		v1232 = math.floor(v1233)
	end
	local v1234 = v1223.exempt
	local v1235 = tonumber(v1234)
	local v1236
	if v1235 == nil or v1235 ~= v1235 then
		v1236 = 0
	else
		local v1237 = v1235 + 0.5
		v1236 = math.floor(v1237)
	end
	local v1238 = v1223.studio
	local v1239 = tonumber(v1238)
	local v1240
	if v1239 == nil or v1239 ~= v1239 then
		v1240 = 0
	else
		local v1241 = v1239 + 0.5
		v1240 = math.floor(v1241)
	end
	local v1242 = v1223.brake
	local v1243 = tonumber(v1242)
	local v1244
	if v1243 == nil or v1243 ~= v1243 then
		v1244 = 0
	else
		local v1245 = v1243 + 0.5
		v1244 = math.floor(v1245)
	end
	local v1246 = v1223.events
	local v1247 = tonumber(v1246)
	local v1248
	if v1247 == nil or v1247 ~= v1247 then
		v1248 = 0
	else
		local v1249 = v1247 + 0.5
		v1248 = math.floor(v1249)
	end
	local v1250 = v1223.gated
	local v1251 = tonumber(v1250)
	local v1252
	if v1251 == nil or v1251 ~= v1251 then
		v1252 = 0
	else
		local v1253 = v1251 + 0.5
		v1252 = math.floor(v1253)
	end
	v1224.text = v1225:format(v1228, v1232, v1236, v1240, v1244, v1248, v1252)
	table.insert(v1209, v1224)
	local v1254 = p1207.pvp
	if type(v1254) == "table" then
		local v1255 = {
			["name"] = "Pvp",
			["text"] = nil,
			["kind"] = "text"
		}
		local v1256 = "PvP check %s  \194\183  hits %d  \194\183  refused view %d / snap %d / los %d  \194\183  late %d  \194\183  held %d  \194\183  unknown %d  \194\183  tracks %d"
		local v1257 = v1254.armed == true and "armed" or "not armed"
		local v1258 = v1254.hits
		local v1259 = tonumber(v1258)
		local v1260
		if v1259 == nil or v1259 ~= v1259 then
			v1260 = 0
		else
			local v1261 = v1259 + 0.5
			v1260 = math.floor(v1261)
		end
		local v1262 = v1254.refView
		local v1263 = tonumber(v1262)
		local v1264
		if v1263 == nil or v1263 ~= v1263 then
			v1264 = 0
		else
			local v1265 = v1263 + 0.5
			v1264 = math.floor(v1265)
		end
		local v1266 = v1254.refSnap
		local v1267 = tonumber(v1266)
		local v1268
		if v1267 == nil or v1267 ~= v1267 then
			v1268 = 0
		else
			local v1269 = v1267 + 0.5
			v1268 = math.floor(v1269)
		end
		local v1270 = v1254.refLos
		local v1271 = tonumber(v1270)
		local v1272
		if v1271 == nil or v1271 ~= v1271 then
			v1272 = 0
		else
			local v1273 = v1271 + 0.5
			v1272 = math.floor(v1273)
		end
		local v1274 = v1254.late
		local v1275 = tonumber(v1274)
		local v1276
		if v1275 == nil or v1275 ~= v1275 then
			v1276 = 0
		else
			local v1277 = v1275 + 0.5
			v1276 = math.floor(v1277)
		end
		local v1278 = v1254.held
		local v1279 = tonumber(v1278)
		local v1280
		if v1279 == nil or v1279 ~= v1279 then
			v1280 = 0
		else
			local v1281 = v1279 + 0.5
			v1280 = math.floor(v1281)
		end
		local v1282 = v1254.unknown
		local v1283 = tonumber(v1282)
		local v1284
		if v1283 == nil or v1283 ~= v1283 then
			v1284 = 0
		else
			local v1285 = v1283 + 0.5
			v1284 = math.floor(v1285)
		end
		local v1286 = v1254.tracks
		local v1287 = tonumber(v1286)
		local v1288
		if v1287 == nil or v1287 ~= v1287 then
			v1288 = 0
		else
			local v1289 = v1287 + 0.5
			v1288 = math.floor(v1289)
		end
		v1255.text = v1256:format(v1257, v1260, v1264, v1268, v1272, v1276, v1280, v1284, v1288)
		table.insert(v1209, v1255)
	end
	local v1290 = p1207.kicks
	local v1291 = type(v1290) ~= "table" and {} or p1207.kicks
	if #v1291 == 0 then
		table.insert(v1209, {
			["name"] = "None",
			["text"] = "No instant kick on this server yet.",
			["kind"] = "muted"
		})
	end
	for v1292, v1293 in v1291 do
		if v1292 > 20 then
			break
		end
		local v1294 = {
			["name"] = "K" .. tostring(v1292)
		}
		local v1295 = "%s  %s (%s)  %s  \194\183  %s  \194\183  %s"
		local v1296 = os.date
		local v1297 = v1293.t
		local v1298 = tonumber(v1297) or 0
		local v1299 = v1296("!%H:%M:%S", (math.floor(v1298)))
		local v1300 = v1293.name
		local v1301 = tostring(v1300)
		local v1302 = v1293.uid
		local v1303 = tostring(v1302)
		local v1304 = v_u_1206
		local v1305 = v1293.code
		local v1306 = v1304[tostring(v1305)]
		if not v1306 then
			local v1307 = v1293.code
			v1306 = tostring(v1307)
		end
		local v1308 = v1293.info
		local v1309 = tostring(v1308)
		local v1310 = v1293.res
		v1294.text = v1295:format(v1299, v1301, v1303, v1306, v1309, (tostring(v1310)))
		v1294.kind = v1293.res == "kicked" and "warn" or "muted"
		table.insert(v1209, v1294)
	end
	return v1209
end
function v_u_4.mount(p_u_1311, p_u_1312, p_u_1313, p1314) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_1315 = type(p1314) ~= "table" and {} or p1314
	if type(p_u_1313) == "table" then
		local v1316 = p_u_1313.color
		if type(v1316) ~= "table" then
			p_u_1313 = v_u_3.Theme
		end
	else
		p_u_1313 = v_u_3.Theme
	end
	local v_u_1317 = p_u_1313.color
	local v1318 = v_u_1315.inner
	local v1319 = type(v1318) ~= "number" and 438 or v_u_1315.inner
	local v_u_1320 = v_u_1315.gui
	local v_u_1321 = 0
	local v_u_1322 = true
	if v_u_1320 then
		v_u_1320.Destroying:Connect(function()
			-- upvalues: (ref) v_u_1322
			v_u_1322 = false
		end)
	end
	local v1323 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Anti cheat  \194\183  shadow  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v1324 = v_u_1315.order
	local v1325
	if type(v1324) == "function" then
		v1325 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1325 = v_u_1321
	end
	v1323.LayoutOrder = v1325
	local v_u_1326 = v_u_3.new("Frame", {
		["Name"] = "AcHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_1311)
	v_u_3.layout(v_u_1326, "v", 2)
	local v1327 = v_u_1315.order
	local v1328
	if type(v1327) == "function" then
		v1328 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1328 = v_u_1321
	end
	v_u_1326.LayoutOrder = v1328
	local function v1335(p1329, p1330, p1331) -- name: small
		-- upvalues: (ref) v_u_3, (copy) p_u_1311, (copy) v_u_1317, (copy) v_u_1315, (ref) v_u_1321
		local v1332 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_1311,
			["name"] = p1329,
			["text"] = p1330,
			["color"] = p1331 or v_u_1317.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v1333 = v_u_1315.order
		local v1334
		if type(v1333) == "function" then
			v1334 = v_u_1315.order()
		else
			v_u_1321 = v_u_1321 + 1
			v1334 = v_u_1321
		end
		v1332.LayoutOrder = v1334
		return v1332
	end
	local function v1349(p1336, p1337) -- name: row
		-- upvalues: (ref) v_u_3, (copy) p_u_1313, (copy) p_u_1311, (copy) v_u_1315, (ref) v_u_1321
		local v1338 = v_u_3.new
		local v1339 = "Frame"
		local v1340 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = p1337 or "AcRow"
		}
		local v1341 = UDim2.new
		local v1342 = 1
		local v1343 = 0
		local v1344 = 0
		if not p1336 then
			local v1345 = p_u_1313.touch
			p1336 = type(v1345) ~= "function" and 32 or p_u_1313.touch(32)
		end
		v1340.Size = v1341(v1342, v1343, v1344, p1336)
		local v1346 = v1338(v1339, v1340, p_u_1311)
		v_u_3.layout(v1346, "h", 6)
		local v1347 = v_u_1315.order
		local v1348
		if type(v1347) == "function" then
			v1348 = v_u_1315.order()
		else
			v_u_1321 = v_u_1321 + 1
			v1348 = v_u_1321
		end
		v1346.LayoutOrder = v1348
		return v1346
	end
	local function v1354(p1350) -- name: listFrame
		-- upvalues: (ref) v_u_3, (copy) p_u_1311, (copy) v_u_1315, (ref) v_u_1321
		local v1351 = v_u_3.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Name"] = p1350,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p_u_1311)
		v_u_3.layout(v1351, "v", 2)
		local v1352 = v_u_1315.order
		local v1353
		if type(v1352) == "function" then
			v1353 = v_u_1315.order()
		else
			v_u_1321 = v_u_1321 + 1
			v1353 = v_u_1321
		end
		v1351.LayoutOrder = v1353
		return v1351
	end
	local v_u_1355 = nil
	local v_u_1356 = nil
	local v_u_1357 = nil
	local v_u_1358 = false
	local v_u_1359 = (-1 / 0)
	local v_u_1360 = nil
	local v_u_1361 = false
	local v_u_1362 = 0
	local v_u_1363 = {}
	local v_u_1364 = nil
	local v_u_1365 = false
	local v_u_1366 = {}
	local v_u_1367 = {}
	local v_u_1368 = nil
	local v_u_1369 = nil
	local v_u_1370 = nil
	local v_u_1371 = nil
	local function v_u_1372(_) end
	local v_u_1373 = nil
	local v_u_1374 = nil
	local function v_u_1379(p1375, p1376) -- name: setStatus
		-- upvalues: (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317
		v_u_3.setText(v_u_1360, p1375)
		local v1377 = v_u_1360
		local v1378
		if p1376 then
			v1378 = v_u_1317.danger
		else
			v1378 = v_u_1317.text2
		end
		v1377.TextColor3 = v1378
	end
	v_u_1374 = function()
		-- upvalues: (ref) v_u_1358, (copy) p_u_1312, (ref) v_u_1322, (ref) v_u_1359, (ref) v_u_1355, (ref) v_u_1374, (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1373, (copy) v_u_1315
		local v_u_1380 = {
			["cmd"] = "status"
		}
		if not v_u_1358 then
			local v1381 = p_u_1312
			if type(v1381) ~= "function" then
				return
			end
			v_u_1358 = true
			local v_u_1382 = "status"
			local v_u_1383 = nil
			local v_u_1384 = true
			local function v1392(p1385) -- name: done
				-- upvalues: (ref) v_u_1358, (ref) v_u_1322, (ref) v_u_1359, (copy) v_u_1382, (ref) v_u_1355, (copy) v_u_1380, (ref) v_u_1374, (copy) v_u_1383, (copy) v_u_1384, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
				v_u_1358 = false
				if not v_u_1322 then
					return
				end
				v_u_1359 = os.clock()
				if type(p1385) == "table" then
					local v1386, v1387, v1388, v1389, v1390
					if v_u_1382 == "status" and p1385.ok then
						local v1391 = p1385.data
						if type(v1391) == "table" then
							v_u_1355 = p1385.data
							if v_u_1383 then
								v_u_1383(p1385)
							end
							if not v_u_1384 then
								v1386 = p1385.msg or (p1385.ok and "Done." or "Refused.")
								v1387 = tostring(v1386)
								v1388 = p1385.ok ~= true
								v_u_3.setText(v_u_1360, v1387)
								v1389 = v_u_1360
								if v1388 then
									v1390 = v_u_1317.danger
								else
									v1390 = v_u_1317.text2
								end
								v1389.TextColor3 = v1390
							end
							v_u_1373()
						else
							if v_u_1380.cmd == "mode" and p1385.ok then
								task.defer(v_u_1374)
							end
							if v_u_1383 then
								v_u_1383(p1385)
							end
							if not v_u_1384 then
								v1386 = p1385.msg or (p1385.ok and "Done." or "Refused.")
								v1387 = tostring(v1386)
								v1388 = p1385.ok ~= true
								v_u_3.setText(v_u_1360, v1387)
								v1389 = v_u_1360
								if v1388 then
									v1390 = v_u_1317.danger
								else
									v1390 = v_u_1317.text2
								end
								v1389.TextColor3 = v1390
							end
							v_u_1373()
						end
					else
						if v_u_1380.cmd == "mode" and p1385.ok then
							task.defer(v_u_1374)
						end
						if v_u_1383 then
							v_u_1383(p1385)
						end
						if not v_u_1384 then
							v1386 = p1385.msg or (p1385.ok and "Done." or "Refused.")
							v1387 = tostring(v1386)
							v1388 = p1385.ok ~= true
							v_u_3.setText(v_u_1360, v1387)
							v1389 = v_u_1360
							if v1388 then
								v1390 = v_u_1317.danger
							else
								v1390 = v_u_1317.text2
							end
							v1389.TextColor3 = v1390
						end
						v_u_1373()
						return
					end
				else
					if not v_u_1384 then
						v_u_3.setText(v_u_1360, "The server did not answer.")
						v_u_1360.TextColor3 = v_u_1317.danger
					end
					v_u_1373()
					return
				end
			end
			local v1393 = v_u_1315.sendQuiet
			local v1394
			if type(v1393) == "function" then
				v1394 = v_u_1315.sendQuiet
			else
				v1394 = p_u_1312
			end
			v1394("server.ac", v_u_1380, v1392)
		end
	end
	local function v_u_1418(p1395) -- name: doLookup
		-- upvalues: (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1367, (ref) v_u_1368, (ref) v_u_1369, (ref) v_u_1370, (ref) v_u_1356, (ref) v_u_1357, (ref) v_u_1322, (ref) v_u_1372, (ref) v_u_1361, (ref) v_u_1358, (copy) p_u_1312, (ref) v_u_1359, (ref) v_u_1355, (ref) v_u_1374, (ref) v_u_1373
		local v1396 = string.gsub(p1395, "^%s+", "")
		local v1397 = string.gsub(v1396, "%s+$", "")
		if v1397 == "" then
			v_u_3.setText(v_u_1360, "Enter a user id or a name.")
			v_u_1360.TextColor3 = v_u_1317.danger
		else
			local v1398 = tonumber(v1397)
			local v_u_1399
			if v1398 then
				v_u_1399 = {
					["cmd"] = "lookup",
					["userId"] = nil,
					["userId"] = v1398
				}
			else
				v_u_1399 = {
					["cmd"] = "lookup",
					["name"] = nil,
					["name"] = v1397
				}
			end
			local function v_u_1407(p1400)
				-- upvalues: (ref) v_u_1367, (ref) v_u_1368, (ref) v_u_1369, (ref) v_u_1370, (ref) v_u_1356, (ref) v_u_1357, (ref) v_u_1322, (ref) v_u_1372, (ref) v_u_1361
				v_u_1367 = {}
				v_u_1368 = nil
				v_u_1369 = nil
				v_u_1370 = nil
				if not p1400.ok then
					v_u_1356 = nil
					v_u_1357 = nil
					v_u_1361 = false
					return
				end
				local v1401 = p1400.data
				if type(v1401) ~= "table" then
					v_u_1356 = nil
					v_u_1357 = nil
					v_u_1361 = false
					return
				end
				v_u_1356 = p1400.data
				local v1402 = p1400.data.uid
				v_u_1357 = tonumber(v1402)
				v_u_1370 = v_u_1357
				local v1403 = p1400.data.record
				if not v_u_1357 then
					v_u_1361 = false
					return
				end
				local v1404
				if type(v1403) == "table" then
					local v1405 = v1403.traces
					if type(v1405) ~= "table" or #v1403.traces <= 0 then
						v1404 = p1400.data.live
						if type(v1404) ~= "table" then
							v_u_1361 = false
							return
						end
					end
				else
					v1404 = p1400.data.live
					if type(v1404) ~= "table" then
						v_u_1361 = false
						return
					end
				end
				local v_u_1406 = v_u_1357
				task.defer(function()
					-- upvalues: (ref) v_u_1322, (ref) v_u_1370, (copy) v_u_1406, (ref) v_u_1372
					if v_u_1322 and v_u_1370 == v_u_1406 then
						v_u_1372(v_u_1406)
					end
				end)
				v_u_1361 = false
			end
			if not v_u_1358 then
				local v1408 = p_u_1312
				if type(v1408) ~= "function" then
					return
				end
				v_u_1358 = true
				v_u_3.setText(v_u_1360, "Working ...")
				v_u_1360.TextColor3 = v_u_1317.text2
				local v_u_1409 = "lookup"
				local v_u_1410 = false
				p_u_1312("server.ac", v_u_1399, function(p1411) -- name: done
					-- upvalues: (ref) v_u_1358, (ref) v_u_1322, (ref) v_u_1359, (copy) v_u_1409, (ref) v_u_1355, (copy) v_u_1399, (ref) v_u_1374, (copy) v_u_1407, (copy) v_u_1410, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
					v_u_1358 = false
					if not v_u_1322 then
						return
					end
					v_u_1359 = os.clock()
					if type(p1411) == "table" then
						local v1412, v1413, v1414, v1415, v1416
						if v_u_1409 == "status" and p1411.ok then
							local v1417 = p1411.data
							if type(v1417) == "table" then
								v_u_1355 = p1411.data
								if v_u_1407 then
									v_u_1407(p1411)
								end
								if not v_u_1410 then
									v1412 = p1411.msg or (p1411.ok and "Done." or "Refused.")
									v1413 = tostring(v1412)
									v1414 = p1411.ok ~= true
									v_u_3.setText(v_u_1360, v1413)
									v1415 = v_u_1360
									if v1414 then
										v1416 = v_u_1317.danger
									else
										v1416 = v_u_1317.text2
									end
									v1415.TextColor3 = v1416
								end
								v_u_1373()
							else
								if v_u_1399.cmd == "mode" and p1411.ok then
									task.defer(v_u_1374)
								end
								if v_u_1407 then
									v_u_1407(p1411)
								end
								if not v_u_1410 then
									v1412 = p1411.msg or (p1411.ok and "Done." or "Refused.")
									v1413 = tostring(v1412)
									v1414 = p1411.ok ~= true
									v_u_3.setText(v_u_1360, v1413)
									v1415 = v_u_1360
									if v1414 then
										v1416 = v_u_1317.danger
									else
										v1416 = v_u_1317.text2
									end
									v1415.TextColor3 = v1416
								end
								v_u_1373()
							end
						else
							if v_u_1399.cmd == "mode" and p1411.ok then
								task.defer(v_u_1374)
							end
							if v_u_1407 then
								v_u_1407(p1411)
							end
							if not v_u_1410 then
								v1412 = p1411.msg or (p1411.ok and "Done." or "Refused.")
								v1413 = tostring(v1412)
								v1414 = p1411.ok ~= true
								v_u_3.setText(v_u_1360, v1413)
								v1415 = v_u_1360
								if v1414 then
									v1416 = v_u_1317.danger
								else
									v1416 = v_u_1317.text2
								end
								v1415.TextColor3 = v1416
							end
							v_u_1373()
							return
						end
					else
						if not v_u_1410 then
							v_u_3.setText(v_u_1360, "The server did not answer.")
							v_u_1360.TextColor3 = v_u_1317.danger
						end
						v_u_1373()
						return
					end
				end)
			end
		end
	end
	v_u_1372 = function(p1419)
		-- upvalues: (ref) v_u_1370, (ref) v_u_1367, (ref) v_u_1368, (ref) v_u_1358, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1359, (ref) v_u_1355, (ref) v_u_1374, (ref) v_u_1373
		local v_u_1420 = {
			["cmd"] = "trace",
			["sub"] = "list",
			["userId"] = nil,
			["userId"] = p1419
		}
		local function v_u_1425(p1421)
			-- upvalues: (ref) v_u_1370, (ref) v_u_1367, (ref) v_u_1368
			if p1421.ok then
				local v1422 = p1421.data
				if type(v1422) == "table" then
					local v1423 = p1421.data.uid
					if tonumber(v1423) == v_u_1370 then
						local v1424 = p1421.data.rows
						v_u_1367 = type(v1424) ~= "table" and {} or p1421.data.rows
						v_u_1368 = p1421.data.live
						return
					end
				end
			end
			v_u_1367 = {}
			v_u_1368 = nil
		end
		if not v_u_1358 then
			local v1426 = p_u_1312
			if type(v1426) ~= "function" then
				return
			end
			v_u_1358 = true
			v_u_3.setText(v_u_1360, "Working ...")
			v_u_1360.TextColor3 = v_u_1317.text2
			local v_u_1427 = "trace"
			local v_u_1428 = false
			p_u_1312("server.ac", v_u_1420, function(p1429) -- name: done
				-- upvalues: (ref) v_u_1358, (ref) v_u_1322, (ref) v_u_1359, (copy) v_u_1427, (ref) v_u_1355, (copy) v_u_1420, (ref) v_u_1374, (copy) v_u_1425, (copy) v_u_1428, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
				v_u_1358 = false
				if not v_u_1322 then
					return
				end
				v_u_1359 = os.clock()
				if type(p1429) == "table" then
					local v1430, v1431, v1432, v1433, v1434
					if v_u_1427 == "status" and p1429.ok then
						local v1435 = p1429.data
						if type(v1435) == "table" then
							v_u_1355 = p1429.data
							if v_u_1425 then
								v_u_1425(p1429)
							end
							if not v_u_1428 then
								v1430 = p1429.msg or (p1429.ok and "Done." or "Refused.")
								v1431 = tostring(v1430)
								v1432 = p1429.ok ~= true
								v_u_3.setText(v_u_1360, v1431)
								v1433 = v_u_1360
								if v1432 then
									v1434 = v_u_1317.danger
								else
									v1434 = v_u_1317.text2
								end
								v1433.TextColor3 = v1434
							end
							v_u_1373()
						else
							if v_u_1420.cmd == "mode" and p1429.ok then
								task.defer(v_u_1374)
							end
							if v_u_1425 then
								v_u_1425(p1429)
							end
							if not v_u_1428 then
								v1430 = p1429.msg or (p1429.ok and "Done." or "Refused.")
								v1431 = tostring(v1430)
								v1432 = p1429.ok ~= true
								v_u_3.setText(v_u_1360, v1431)
								v1433 = v_u_1360
								if v1432 then
									v1434 = v_u_1317.danger
								else
									v1434 = v_u_1317.text2
								end
								v1433.TextColor3 = v1434
							end
							v_u_1373()
						end
					else
						if v_u_1420.cmd == "mode" and p1429.ok then
							task.defer(v_u_1374)
						end
						if v_u_1425 then
							v_u_1425(p1429)
						end
						if not v_u_1428 then
							v1430 = p1429.msg or (p1429.ok and "Done." or "Refused.")
							v1431 = tostring(v1430)
							v1432 = p1429.ok ~= true
							v_u_3.setText(v_u_1360, v1431)
							v1433 = v_u_1360
							if v1432 then
								v1434 = v_u_1317.danger
							else
								v1434 = v_u_1317.text2
							end
							v1433.TextColor3 = v1434
						end
						v_u_1373()
						return
					end
				else
					if not v_u_1428 then
						v_u_3.setText(v_u_1360, "The server did not answer.")
						v_u_1360.TextColor3 = v_u_1317.danger
					end
					v_u_1373()
					return
				end
			end)
		end
	end
	local function v_u_1451(p1436)
		-- upvalues: (ref) v_u_1370, (ref) v_u_1369, (ref) v_u_4, (ref) v_u_1367, (ref) v_u_1358, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1359, (ref) v_u_1355, (ref) v_u_1374, (ref) v_u_1373
		if v_u_1370 and type(p1436) == "string" then
			local v_u_1437 = {
				["cmd"] = "trace",
				["sub"] = "open",
				["userId"] = nil,
				["key"] = nil,
				["userId"] = v_u_1370,
				["key"] = p1436
			}
			local function v_u_1440(p1438)
				-- upvalues: (ref) v_u_1369, (ref) v_u_4, (ref) v_u_1367
				if p1438.ok then
					local v1439 = p1438.data
					if type(v1439) == "table" then
						v_u_1369 = p1438.data
						v_u_4.mergeTraceRow(v_u_1367, p1438.data)
						return
					end
				end
				v_u_1369 = nil
			end
			if not v_u_1358 then
				local v1441 = p_u_1312
				if type(v1441) ~= "function" then
					return
				end
				v_u_1358 = true
				v_u_3.setText(v_u_1360, "Working ...")
				v_u_1360.TextColor3 = v_u_1317.text2
				local v_u_1442 = "trace"
				local v_u_1443 = false
				p_u_1312("server.ac", v_u_1437, function(p1444) -- name: done
					-- upvalues: (ref) v_u_1358, (ref) v_u_1322, (ref) v_u_1359, (copy) v_u_1442, (ref) v_u_1355, (copy) v_u_1437, (ref) v_u_1374, (copy) v_u_1440, (copy) v_u_1443, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
					v_u_1358 = false
					if not v_u_1322 then
						return
					end
					v_u_1359 = os.clock()
					if type(p1444) == "table" then
						local v1445, v1446, v1447, v1448, v1449
						if v_u_1442 == "status" and p1444.ok then
							local v1450 = p1444.data
							if type(v1450) == "table" then
								v_u_1355 = p1444.data
								if v_u_1440 then
									v_u_1440(p1444)
								end
								if not v_u_1443 then
									v1445 = p1444.msg or (p1444.ok and "Done." or "Refused.")
									v1446 = tostring(v1445)
									v1447 = p1444.ok ~= true
									v_u_3.setText(v_u_1360, v1446)
									v1448 = v_u_1360
									if v1447 then
										v1449 = v_u_1317.danger
									else
										v1449 = v_u_1317.text2
									end
									v1448.TextColor3 = v1449
								end
								v_u_1373()
							else
								if v_u_1437.cmd == "mode" and p1444.ok then
									task.defer(v_u_1374)
								end
								if v_u_1440 then
									v_u_1440(p1444)
								end
								if not v_u_1443 then
									v1445 = p1444.msg or (p1444.ok and "Done." or "Refused.")
									v1446 = tostring(v1445)
									v1447 = p1444.ok ~= true
									v_u_3.setText(v_u_1360, v1446)
									v1448 = v_u_1360
									if v1447 then
										v1449 = v_u_1317.danger
									else
										v1449 = v_u_1317.text2
									end
									v1448.TextColor3 = v1449
								end
								v_u_1373()
							end
						else
							if v_u_1437.cmd == "mode" and p1444.ok then
								task.defer(v_u_1374)
							end
							if v_u_1440 then
								v_u_1440(p1444)
							end
							if not v_u_1443 then
								v1445 = p1444.msg or (p1444.ok and "Done." or "Refused.")
								v1446 = tostring(v1445)
								v1447 = p1444.ok ~= true
								v_u_3.setText(v_u_1360, v1446)
								v1448 = v_u_1360
								if v1447 then
									v1449 = v_u_1317.danger
								else
									v1449 = v_u_1317.text2
								end
								v1448.TextColor3 = v1449
							end
							v_u_1373()
							return
						end
					else
						if not v_u_1443 then
							v_u_3.setText(v_u_1360, "The server did not answer.")
							v_u_1360.TextColor3 = v_u_1317.danger
						end
						v_u_1373()
						return
					end
				end)
			end
		end
	end
	local function v_u_1471(p1452)
		-- upvalues: (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1370, (ref) v_u_1322, (ref) v_u_1372, (ref) v_u_1358, (copy) p_u_1312, (ref) v_u_1359, (ref) v_u_1355, (ref) v_u_1374, (ref) v_u_1373
		local v1453 = string.gsub(p1452, "^%s+", "")
		local v1454 = string.gsub(v1453, "%s+$", "")
		if v1454 == "" then
			v_u_3.setText(v_u_1360, "Enter a name or a user id of a player on this server.")
			v_u_1360.TextColor3 = v_u_1317.danger
		else
			local v1455 = tonumber(v1454)
			local v_u_1456
			if v1455 then
				v_u_1456 = {
					["cmd"] = "trace",
					["sub"] = "watch",
					["userId"] = nil,
					["userId"] = v1455
				}
			else
				v_u_1456 = {
					["cmd"] = "trace",
					["sub"] = "watch",
					["name"] = nil,
					["name"] = v1454
				}
			end
			local function v_u_1460(p1457)
				-- upvalues: (ref) v_u_1370, (ref) v_u_1322, (ref) v_u_1372
				if p1457.ok then
					local v1458 = p1457.data
					if type(v1458) == "table" and v_u_1370 then
						local v1459 = p1457.data.uid
						if tonumber(v1459) == v_u_1370 then
							task.defer(function()
								-- upvalues: (ref) v_u_1322, (ref) v_u_1370, (ref) v_u_1372
								if v_u_1322 and v_u_1370 then
									v_u_1372(v_u_1370)
								end
							end)
						end
					end
				end
			end
			if not v_u_1358 then
				local v1461 = p_u_1312
				if type(v1461) ~= "function" then
					return
				end
				v_u_1358 = true
				v_u_3.setText(v_u_1360, "Working ...")
				v_u_1360.TextColor3 = v_u_1317.text2
				local v_u_1462 = "trace"
				local v_u_1463 = false
				p_u_1312("server.ac", v_u_1456, function(p1464) -- name: done
					-- upvalues: (ref) v_u_1358, (ref) v_u_1322, (ref) v_u_1359, (copy) v_u_1462, (ref) v_u_1355, (copy) v_u_1456, (ref) v_u_1374, (copy) v_u_1460, (copy) v_u_1463, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
					v_u_1358 = false
					if not v_u_1322 then
						return
					end
					v_u_1359 = os.clock()
					if type(p1464) == "table" then
						local v1465, v1466, v1467, v1468, v1469
						if v_u_1462 == "status" and p1464.ok then
							local v1470 = p1464.data
							if type(v1470) == "table" then
								v_u_1355 = p1464.data
								if v_u_1460 then
									v_u_1460(p1464)
								end
								if not v_u_1463 then
									v1465 = p1464.msg or (p1464.ok and "Done." or "Refused.")
									v1466 = tostring(v1465)
									v1467 = p1464.ok ~= true
									v_u_3.setText(v_u_1360, v1466)
									v1468 = v_u_1360
									if v1467 then
										v1469 = v_u_1317.danger
									else
										v1469 = v_u_1317.text2
									end
									v1468.TextColor3 = v1469
								end
								v_u_1373()
							else
								if v_u_1456.cmd == "mode" and p1464.ok then
									task.defer(v_u_1374)
								end
								if v_u_1460 then
									v_u_1460(p1464)
								end
								if not v_u_1463 then
									v1465 = p1464.msg or (p1464.ok and "Done." or "Refused.")
									v1466 = tostring(v1465)
									v1467 = p1464.ok ~= true
									v_u_3.setText(v_u_1360, v1466)
									v1468 = v_u_1360
									if v1467 then
										v1469 = v_u_1317.danger
									else
										v1469 = v_u_1317.text2
									end
									v1468.TextColor3 = v1469
								end
								v_u_1373()
							end
						else
							if v_u_1456.cmd == "mode" and p1464.ok then
								task.defer(v_u_1374)
							end
							if v_u_1460 then
								v_u_1460(p1464)
							end
							if not v_u_1463 then
								v1465 = p1464.msg or (p1464.ok and "Done." or "Refused.")
								v1466 = tostring(v1465)
								v1467 = p1464.ok ~= true
								v_u_3.setText(v_u_1360, v1466)
								v1468 = v_u_1360
								if v1467 then
									v1469 = v_u_1317.danger
								else
									v1469 = v_u_1317.text2
								end
								v1468.TextColor3 = v1469
							end
							v_u_1373()
							return
						end
					else
						if not v_u_1463 then
							v_u_3.setText(v_u_1360, "The server did not answer.")
							v_u_1360.TextColor3 = v_u_1317.danger
						end
						v_u_1373()
						return
					end
				end)
			end
		end
	end
	v1335("AcModeLabel", "Mode (all servers follow within 2 minutes)", v_u_1317.muted)
	local v1472 = p_u_1313.touch
	local v1473 = v1349(type(v1472) ~= "function" and 32 or p_u_1313.touch(32), "AcModeRow")
	local v1474 = (v1319 - 6) / 2
	local v1475 = math.floor(v1474)
	local v_u_1476 = v_u_1370
	local v_u_1477 = v_u_1369
	local v_u_1478 = v_u_1367
	local v_u_1479 = v_u_1356
	local v_u_1480 = v_u_1372
	local v_u_1481 = v_u_1361
	local v_u_1482 = v_u_1368
	local v_u_1483 = v_u_1357
	local v_u_1484 = v_u_1373
	local v_u_1485 = v_u_1374
	local v_u_1486 = v_u_1355
	local v_u_1487 = v_u_1359
	local v_u_1488 = v_u_1360
	local v_u_1489 = v_u_1358
	for _, v1490 in {
		{ "off", "Off" },
		{ "shadow", "Shadow" }
	} do
		local v_u_1491 = v1490[1]
		local v1492 = v_u_3.button
		local v1493 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v1473,
			["text"] = v1490[2]
		}
		local v1494 = p_u_1313.touch
		v1493.height = type(v1494) ~= "function" and 32 or p_u_1313.touch(32)
		v1493.width = v1475
		v1493.maxTextWidth = v1475 - 12
		function v1493.onClick() -- name: onClick
			-- upvalues: (copy) v_u_1491, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484
			local v_u_1495 = {
				["cmd"] = "mode",
				["mode"] = nil,
				["mode"] = v_u_1491
			}
			if not v_u_1489 then
				local v1496 = p_u_1312
				if type(v1496) ~= "function" then
					return
				end
				v_u_1489 = true
				v_u_3.setText(v_u_1488, "Working ...")
				v_u_1488.TextColor3 = v_u_1317.text2
				local v_u_1497 = "mode"
				local v_u_1498 = nil
				local v_u_1499 = nil
				p_u_1312("server.ac", v_u_1495, function(p1500) -- name: done
					-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1497, (ref) v_u_1486, (copy) v_u_1495, (ref) v_u_1485, (copy) v_u_1498, (copy) v_u_1499, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
					v_u_1489 = false
					if not v_u_1322 then
						return
					end
					v_u_1487 = os.clock()
					if type(p1500) == "table" then
						local v1501, v1502, v1503, v1504, v1505
						if v_u_1497 == "status" and p1500.ok then
							local v1506 = p1500.data
							if type(v1506) == "table" then
								v_u_1486 = p1500.data
								if v_u_1498 then
									v_u_1498(p1500)
								end
								if not v_u_1499 then
									v1501 = p1500.msg or (p1500.ok and "Done." or "Refused.")
									v1502 = tostring(v1501)
									v1503 = p1500.ok ~= true
									v_u_3.setText(v_u_1488, v1502)
									v1504 = v_u_1488
									if v1503 then
										v1505 = v_u_1317.danger
									else
										v1505 = v_u_1317.text2
									end
									v1504.TextColor3 = v1505
								end
								v_u_1484()
							else
								if v_u_1495.cmd == "mode" and p1500.ok then
									task.defer(v_u_1485)
								end
								if v_u_1498 then
									v_u_1498(p1500)
								end
								if not v_u_1499 then
									v1501 = p1500.msg or (p1500.ok and "Done." or "Refused.")
									v1502 = tostring(v1501)
									v1503 = p1500.ok ~= true
									v_u_3.setText(v_u_1488, v1502)
									v1504 = v_u_1488
									if v1503 then
										v1505 = v_u_1317.danger
									else
										v1505 = v_u_1317.text2
									end
									v1504.TextColor3 = v1505
								end
								v_u_1484()
							end
						else
							if v_u_1495.cmd == "mode" and p1500.ok then
								task.defer(v_u_1485)
							end
							if v_u_1498 then
								v_u_1498(p1500)
							end
							if not v_u_1499 then
								v1501 = p1500.msg or (p1500.ok and "Done." or "Refused.")
								v1502 = tostring(v1501)
								v1503 = p1500.ok ~= true
								v_u_3.setText(v_u_1488, v1502)
								v1504 = v_u_1488
								if v1503 then
									v1505 = v_u_1317.danger
								else
									v1505 = v_u_1317.text2
								end
								v1504.TextColor3 = v1505
							end
							v_u_1484()
							return
						end
					else
						if not v_u_1499 then
							v_u_3.setText(v_u_1488, "The server did not answer.")
							v_u_1488.TextColor3 = v_u_1317.danger
						end
						v_u_1484()
						return
					end
				end)
			end
		end
		local v1507, v1508 = v1492(v1493)
		v1507.Name = "AcMode_" .. v_u_1491
		v_u_1363[v_u_1491] = {
			["btn"] = v1507,
			["api"] = v1508,
			["press"] = function() -- name: press
				-- upvalues: (copy) v_u_1491, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484
				local v_u_1509 = {
					["cmd"] = "mode",
					["mode"] = nil,
					["mode"] = v_u_1491
				}
				if not v_u_1489 then
					local v1510 = p_u_1312
					if type(v1510) ~= "function" then
						return
					end
					v_u_1489 = true
					v_u_3.setText(v_u_1488, "Working ...")
					v_u_1488.TextColor3 = v_u_1317.text2
					local v_u_1511 = "mode"
					local v_u_1512 = nil
					local v_u_1513 = nil
					p_u_1312("server.ac", v_u_1509, function(p1514) -- name: done
						-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1511, (ref) v_u_1486, (copy) v_u_1509, (ref) v_u_1485, (copy) v_u_1512, (copy) v_u_1513, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
						v_u_1489 = false
						if not v_u_1322 then
							return
						end
						v_u_1487 = os.clock()
						if type(p1514) == "table" then
							local v1515, v1516, v1517, v1518, v1519
							if v_u_1511 == "status" and p1514.ok then
								local v1520 = p1514.data
								if type(v1520) == "table" then
									v_u_1486 = p1514.data
									if v_u_1512 then
										v_u_1512(p1514)
									end
									if not v_u_1513 then
										v1515 = p1514.msg or (p1514.ok and "Done." or "Refused.")
										v1516 = tostring(v1515)
										v1517 = p1514.ok ~= true
										v_u_3.setText(v_u_1488, v1516)
										v1518 = v_u_1488
										if v1517 then
											v1519 = v_u_1317.danger
										else
											v1519 = v_u_1317.text2
										end
										v1518.TextColor3 = v1519
									end
									v_u_1484()
								else
									if v_u_1509.cmd == "mode" and p1514.ok then
										task.defer(v_u_1485)
									end
									if v_u_1512 then
										v_u_1512(p1514)
									end
									if not v_u_1513 then
										v1515 = p1514.msg or (p1514.ok and "Done." or "Refused.")
										v1516 = tostring(v1515)
										v1517 = p1514.ok ~= true
										v_u_3.setText(v_u_1488, v1516)
										v1518 = v_u_1488
										if v1517 then
											v1519 = v_u_1317.danger
										else
											v1519 = v_u_1317.text2
										end
										v1518.TextColor3 = v1519
									end
									v_u_1484()
								end
							else
								if v_u_1509.cmd == "mode" and p1514.ok then
									task.defer(v_u_1485)
								end
								if v_u_1512 then
									v_u_1512(p1514)
								end
								if not v_u_1513 then
									v1515 = p1514.msg or (p1514.ok and "Done." or "Refused.")
									v1516 = tostring(v1515)
									v1517 = p1514.ok ~= true
									v_u_3.setText(v_u_1488, v1516)
									v1518 = v_u_1488
									if v1517 then
										v1519 = v_u_1317.danger
									else
										v1519 = v_u_1317.text2
									end
									v1518.TextColor3 = v1519
								end
								v_u_1484()
								return
							end
						else
							if not v_u_1513 then
								v_u_3.setText(v_u_1488, "The server did not answer.")
								v_u_1488.TextColor3 = v_u_1317.danger
							end
							v_u_1484()
							return
						end
					end)
				end
			end
		}
	end
	v1335("AcModeNote", "SHADOW only logs, scores and flags. Nobody is kicked, banned or blocked. Enforcement is not available yet.", v_u_1317.muted)
	local v1521 = v_u_3.label({
		["parent"] = nil,
		["name"] = "AcFlagLabel",
		["text"] = "Flagged players (tap one to look it up)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.muted,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v1522 = v_u_1315.order
	local v1523
	if type(v1522) == "function" then
		v1523 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1523 = v_u_1321
	end
	v1521.LayoutOrder = v1523
	local v_u_1524 = v1354("AcFlagList")
	local v1525 = v_u_3.label({
		["parent"] = nil,
		["name"] = "AcRepLabel",
		["text"] = "Reported players, most reports first (tap one to look it up)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.muted,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v1526 = v_u_1315.order
	local v1527
	if type(v1526) == "function" then
		v1527 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1527 = v_u_1321
	end
	v1525.LayoutOrder = v1527
	local v_u_1528 = v1354("AcRepList")
	local v1529 = v_u_3.label({
		["parent"] = nil,
		["name"] = "AcVerdLabel",
		["text"] = "Verdicts from the moderator (tap one to look it up)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.muted,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v1530 = v_u_1315.order
	local v1531
	if type(v1530) == "function" then
		v1531 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1531 = v_u_1321
	end
	v1529.LayoutOrder = v1531
	local v_u_1532 = v1354("AcVerdHead")
	local v1533 = p_u_1313.touch
	local v1534 = v1349(type(v1533) ~= "function" and 32 or p_u_1313.touch(32), "AcVerdRow")
	local v1535 = (v1319 - 12) / 3
	local v1536 = math.floor(v1535)
	local v_u_1537 = v1354("AcVerdList")
	local function v_u_1559(p_u_1538)
		-- upvalues: (ref) v_u_1365, (ref) v_u_1364, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484, (copy) v_u_1315
		v_u_1365 = true
		local function v_u_1556()
			-- upvalues: (copy) p_u_1538, (ref) v_u_1364, (ref) v_u_1489, (ref) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484, (ref) v_u_1315
			local v_u_1539 = {
				["cmd"] = "verdicts",
				["force"] = nil,
				["force"] = p_u_1538 == true
			}
			local v_u_1540 = p_u_1538 ~= true
			local function v_u_1543(p1541)
				-- upvalues: (ref) v_u_1364
				if p1541.ok then
					local v1542 = p1541.data
					if type(v1542) == "table" then
						v_u_1364 = p1541.data
					end
				end
			end
			if not v_u_1489 then
				local v1544 = p_u_1312
				if type(v1544) ~= "function" then
					return
				end
				v_u_1489 = true
				if not v_u_1540 then
					v_u_3.setText(v_u_1488, "Working ...")
					v_u_1488.TextColor3 = v_u_1317.text2
				end
				local v_u_1545 = "verdicts"
				local function v1553(p1546) -- name: done
					-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1545, (ref) v_u_1486, (copy) v_u_1539, (ref) v_u_1485, (copy) v_u_1543, (copy) v_u_1540, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
					v_u_1489 = false
					if not v_u_1322 then
						return
					end
					v_u_1487 = os.clock()
					if type(p1546) == "table" then
						local v1547, v1548, v1549, v1550, v1551
						if v_u_1545 == "status" and p1546.ok then
							local v1552 = p1546.data
							if type(v1552) == "table" then
								v_u_1486 = p1546.data
								if v_u_1543 then
									v_u_1543(p1546)
								end
								if not v_u_1540 then
									v1547 = p1546.msg or (p1546.ok and "Done." or "Refused.")
									v1548 = tostring(v1547)
									v1549 = p1546.ok ~= true
									v_u_3.setText(v_u_1488, v1548)
									v1550 = v_u_1488
									if v1549 then
										v1551 = v_u_1317.danger
									else
										v1551 = v_u_1317.text2
									end
									v1550.TextColor3 = v1551
								end
								v_u_1484()
							else
								if v_u_1539.cmd == "mode" and p1546.ok then
									task.defer(v_u_1485)
								end
								if v_u_1543 then
									v_u_1543(p1546)
								end
								if not v_u_1540 then
									v1547 = p1546.msg or (p1546.ok and "Done." or "Refused.")
									v1548 = tostring(v1547)
									v1549 = p1546.ok ~= true
									v_u_3.setText(v_u_1488, v1548)
									v1550 = v_u_1488
									if v1549 then
										v1551 = v_u_1317.danger
									else
										v1551 = v_u_1317.text2
									end
									v1550.TextColor3 = v1551
								end
								v_u_1484()
							end
						else
							if v_u_1539.cmd == "mode" and p1546.ok then
								task.defer(v_u_1485)
							end
							if v_u_1543 then
								v_u_1543(p1546)
							end
							if not v_u_1540 then
								v1547 = p1546.msg or (p1546.ok and "Done." or "Refused.")
								v1548 = tostring(v1547)
								v1549 = p1546.ok ~= true
								v_u_3.setText(v_u_1488, v1548)
								v1550 = v_u_1488
								if v1549 then
									v1551 = v_u_1317.danger
								else
									v1551 = v_u_1317.text2
								end
								v1550.TextColor3 = v1551
							end
							v_u_1484()
							return
						end
					else
						if not v_u_1540 then
							v_u_3.setText(v_u_1488, "The server did not answer.")
							v_u_1488.TextColor3 = v_u_1317.danger
						end
						v_u_1484()
						return
					end
				end
				local v1554
				if v_u_1540 then
					local v1555 = v_u_1315.sendQuiet
					if type(v1555) == "function" then
						v1554 = v_u_1315.sendQuiet
						v1554("server.ac", v_u_1539, v1553)
					else
						v1554 = p_u_1312
						v1554("server.ac", v_u_1539, v1553)
					end
				else
					v1554 = p_u_1312
					v1554("server.ac", v_u_1539, v1553)
				end
			end
		end
		local v_u_1557 = 0
		local function v_u_1558() -- name: go
			-- upvalues: (ref) v_u_1322, (ref) v_u_1489, (ref) v_u_1557, (copy) v_u_1558, (copy) v_u_1556
			if v_u_1322 then
				if v_u_1489 and v_u_1557 < 14 then
					v_u_1557 = v_u_1557 + 1
					task.delay(0.35, v_u_1558)
				else
					v_u_1556()
				end
			else
				return
			end
		end
		if v_u_1322 then
			if v_u_1489 and v_u_1557 < 14 then
				v_u_1557 = v_u_1557 + 1
				task.delay(0.35, v_u_1558)
			else
				v_u_1556()
			end
		end
	end
	local function v_u_1594(p_u_1560)
		-- upvalues: (ref) v_u_1364, (ref) v_u_1485, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1484
		local function v_u_1576()
			-- upvalues: (copy) p_u_1560, (ref) v_u_1364, (ref) v_u_1485, (ref) v_u_1489, (ref) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1484
			local v_u_1561 = {
				["cmd"] = "modkick",
				["on"] = nil,
				["on"] = p_u_1560
			}
			local function v_u_1565(p1562)
				-- upvalues: (ref) v_u_1364, (ref) v_u_1485
				if p1562.ok then
					local v1563 = p1562.data
					if type(v1563) == "table" then
						local v1564 = v_u_1364
						if type(v1564) ~= "table" then
							v_u_1364 = {}
						end
						v_u_1364.kick = p1562.data.kick
						task.defer(v_u_1485)
					end
				end
			end
			if not v_u_1489 then
				local v1566 = p_u_1312
				if type(v1566) ~= "function" then
					return
				end
				v_u_1489 = true
				v_u_3.setText(v_u_1488, "Working ...")
				v_u_1488.TextColor3 = v_u_1317.text2
				local v_u_1567 = "modkick"
				local v_u_1568 = false
				p_u_1312("server.ac", v_u_1561, function(p1569) -- name: done
					-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1567, (ref) v_u_1486, (copy) v_u_1561, (ref) v_u_1485, (copy) v_u_1565, (copy) v_u_1568, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
					v_u_1489 = false
					if not v_u_1322 then
						return
					end
					v_u_1487 = os.clock()
					if type(p1569) == "table" then
						local v1570, v1571, v1572, v1573, v1574
						if v_u_1567 == "status" and p1569.ok then
							local v1575 = p1569.data
							if type(v1575) == "table" then
								v_u_1486 = p1569.data
								if v_u_1565 then
									v_u_1565(p1569)
								end
								if not v_u_1568 then
									v1570 = p1569.msg or (p1569.ok and "Done." or "Refused.")
									v1571 = tostring(v1570)
									v1572 = p1569.ok ~= true
									v_u_3.setText(v_u_1488, v1571)
									v1573 = v_u_1488
									if v1572 then
										v1574 = v_u_1317.danger
									else
										v1574 = v_u_1317.text2
									end
									v1573.TextColor3 = v1574
								end
								v_u_1484()
							else
								if v_u_1561.cmd == "mode" and p1569.ok then
									task.defer(v_u_1485)
								end
								if v_u_1565 then
									v_u_1565(p1569)
								end
								if not v_u_1568 then
									v1570 = p1569.msg or (p1569.ok and "Done." or "Refused.")
									v1571 = tostring(v1570)
									v1572 = p1569.ok ~= true
									v_u_3.setText(v_u_1488, v1571)
									v1573 = v_u_1488
									if v1572 then
										v1574 = v_u_1317.danger
									else
										v1574 = v_u_1317.text2
									end
									v1573.TextColor3 = v1574
								end
								v_u_1484()
							end
						else
							if v_u_1561.cmd == "mode" and p1569.ok then
								task.defer(v_u_1485)
							end
							if v_u_1565 then
								v_u_1565(p1569)
							end
							if not v_u_1568 then
								v1570 = p1569.msg or (p1569.ok and "Done." or "Refused.")
								v1571 = tostring(v1570)
								v1572 = p1569.ok ~= true
								v_u_3.setText(v_u_1488, v1571)
								v1573 = v_u_1488
								if v1572 then
									v1574 = v_u_1317.danger
								else
									v1574 = v_u_1317.text2
								end
								v1573.TextColor3 = v1574
							end
							v_u_1484()
							return
						end
					else
						if not v_u_1568 then
							v_u_3.setText(v_u_1488, "The server did not answer.")
							v_u_1488.TextColor3 = v_u_1317.danger
						end
						v_u_1484()
						return
					end
				end)
			end
		end
		local v_u_1577 = 0
		local function v_u_1578() -- name: go
			-- upvalues: (ref) v_u_1322, (ref) v_u_1489, (ref) v_u_1577, (copy) v_u_1578, (copy) v_u_1576
			if v_u_1322 then
				if v_u_1489 and v_u_1577 < 14 then
					v_u_1577 = v_u_1577 + 1
					task.delay(0.35, v_u_1578)
				else
					v_u_1576()
				end
			else
				return
			end
		end
		if v_u_1322 then
			if v_u_1489 and v_u_1577 < 14 then
				v_u_1577 = v_u_1577 + 1
				task.delay(0.35, v_u_1578)
			else
				local v_u_1579 = {
					["cmd"] = "modkick",
					["on"] = nil,
					["on"] = p_u_1560
				}
				local function v_u_1583(p1580)
					-- upvalues: (ref) v_u_1364, (ref) v_u_1485
					if p1580.ok then
						local v1581 = p1580.data
						if type(v1581) == "table" then
							local v1582 = v_u_1364
							if type(v1582) ~= "table" then
								v_u_1364 = {}
							end
							v_u_1364.kick = p1580.data.kick
							task.defer(v_u_1485)
						end
					end
				end
				if not v_u_1489 then
					local v1584 = p_u_1312
					if type(v1584) == "function" then
						v_u_1489 = true
						v_u_3.setText(v_u_1488, "Working ...")
						v_u_1488.TextColor3 = v_u_1317.text2
						local v_u_1585 = "modkick"
						local v_u_1586 = false
						p_u_1312("server.ac", v_u_1579, function(p1587) -- name: done
							-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1585, (ref) v_u_1486, (copy) v_u_1579, (ref) v_u_1485, (copy) v_u_1583, (copy) v_u_1586, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
							v_u_1489 = false
							if not v_u_1322 then
								return
							end
							v_u_1487 = os.clock()
							if type(p1587) == "table" then
								local v1588, v1589, v1590, v1591, v1592
								if v_u_1585 == "status" and p1587.ok then
									local v1593 = p1587.data
									if type(v1593) == "table" then
										v_u_1486 = p1587.data
										if v_u_1583 then
											v_u_1583(p1587)
										end
										if not v_u_1586 then
											v1588 = p1587.msg or (p1587.ok and "Done." or "Refused.")
											v1589 = tostring(v1588)
											v1590 = p1587.ok ~= true
											v_u_3.setText(v_u_1488, v1589)
											v1591 = v_u_1488
											if v1590 then
												v1592 = v_u_1317.danger
											else
												v1592 = v_u_1317.text2
											end
											v1591.TextColor3 = v1592
										end
										v_u_1484()
									else
										if v_u_1579.cmd == "mode" and p1587.ok then
											task.defer(v_u_1485)
										end
										if v_u_1583 then
											v_u_1583(p1587)
										end
										if not v_u_1586 then
											v1588 = p1587.msg or (p1587.ok and "Done." or "Refused.")
											v1589 = tostring(v1588)
											v1590 = p1587.ok ~= true
											v_u_3.setText(v_u_1488, v1589)
											v1591 = v_u_1488
											if v1590 then
												v1592 = v_u_1317.danger
											else
												v1592 = v_u_1317.text2
											end
											v1591.TextColor3 = v1592
										end
										v_u_1484()
									end
								else
									if v_u_1579.cmd == "mode" and p1587.ok then
										task.defer(v_u_1485)
									end
									if v_u_1583 then
										v_u_1583(p1587)
									end
									if not v_u_1586 then
										v1588 = p1587.msg or (p1587.ok and "Done." or "Refused.")
										v1589 = tostring(v1588)
										v1590 = p1587.ok ~= true
										v_u_3.setText(v_u_1488, v1589)
										v1591 = v_u_1488
										if v1590 then
											v1592 = v_u_1317.danger
										else
											v1592 = v_u_1317.text2
										end
										v1591.TextColor3 = v1592
									end
									v_u_1484()
									return
								end
							else
								if not v_u_1586 then
									v_u_3.setText(v_u_1488, "The server did not answer.")
									v_u_1488.TextColor3 = v_u_1317.danger
								end
								v_u_1484()
								return
							end
						end)
					end
				end
			end
		end
	end
	local v1595 = v_u_3.button
	local v1596 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v1534
	}
	local v1597 = p_u_1313.touch
	v1596.height = type(v1597) ~= "function" and 32 or p_u_1313.touch(32)
	v1596.width = v1536
	v1596.maxTextWidth = v1536 - 12
	function v1596.onClick() -- name: onClick
		-- upvalues: (ref) v_u_1559
		v_u_1559(true)
	end
	local v1598, v1599 = v1595(v1596)
	v1598.Name = "AcVerdRefresh"
	v_u_1366.refresh = {
		["btn"] = v1598,
		["api"] = v1599
	}
	for _, v1600 in {
		{ "on", "Kick path ON" },
		{ "off", "Kick path OFF" }
	} do
		local v_u_1601 = v1600[1]
		local v1602 = v_u_3.button
		local v1603 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v1534,
			["text"] = v1600[2]
		}
		local v1604 = p_u_1313.touch
		v1603.height = type(v1604) ~= "function" and 32 or p_u_1313.touch(32)
		v1603.width = v1536
		v1603.maxTextWidth = v1536 - 12
		function v1603.onClick() -- name: onClick
			-- upvalues: (ref) v_u_1594, (copy) v_u_1601
			v_u_1594(v_u_1601 == "on")
		end
		local v1605, v1606 = v1602(v1603)
		v1605.Name = "AcKick_" .. v_u_1601
		v_u_1366[v_u_1601] = {
			["btn"] = v1605,
			["api"] = v1606,
			["press"] = function() -- name: press
				-- upvalues: (ref) v_u_1594, (copy) v_u_1601
				v_u_1594(v_u_1601 == "on")
			end
		}
	end
	v1335("AcVerdNote", "Kick path OFF: nobody is removed by the game. The ban at Roblox, if there is one, still holds.", v_u_1317.muted)
	local v1607 = v_u_3.label({
		["parent"] = nil,
		["name"] = "AcInstLabel",
		["text"] = "Instant kick and PvP hit check",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.muted,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v1608 = v_u_1315.order
	local v1609
	if type(v1608) == "function" then
		v1609 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1609 = v_u_1321
	end
	v1607.LayoutOrder = v1609
	local v1610 = p_u_1313.touch
	local v1611 = v1349(type(v1610) ~= "function" and 32 or p_u_1313.touch(32), "AcInstRow")
	local v1612 = (v1319 - 18) / 4
	local v1613 = math.floor(v1612)
	local v_u_1614 = {}
	for _, v1615 in {
		{ "kick", true, "Kick ON" },
		{ "kick", false, "Kick OFF" },
		{ "refuse", true, "Check ON" },
		{ "refuse", false, "Check OFF" }
	} do
		local v_u_1616 = v1615[1]
		local v_u_1617 = v1615[2]
		local v1618 = v_u_1616 .. (v_u_1617 and "On" or "Off")
		local v1619 = v_u_3.button
		local v1620 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v1611,
			["text"] = v1615[3]
		}
		local v1621 = p_u_1313.touch
		v1620.height = type(v1621) ~= "function" and 32 or p_u_1313.touch(32)
		v1620.width = v1613
		v1620.maxTextWidth = v1613 - 10
		function v1620.onClick() -- name: onClick
			-- upvalues: (copy) v_u_1616, (copy) v_u_1617, (ref) v_u_1486, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1484, (copy) v_u_1379
			local v_u_1622 = v_u_1616
			local v_u_1623 = v_u_1617
			local function v_u_1640()
				-- upvalues: (copy) v_u_1622, (copy) v_u_1623, (ref) v_u_1486, (ref) v_u_1489, (ref) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1484
				local v_u_1624 = {
					["cmd"] = "acfast",
					[v_u_1622] = v_u_1623
				}
				local function v_u_1629(p1625)
					-- upvalues: (ref) v_u_1486
					if p1625.ok then
						local v1626 = p1625.data
						if type(v1626) == "table" then
							local v1627 = p1625.data.instant
							if type(v1627) == "table" then
								local v1628 = v_u_1486
								if type(v1628) == "table" then
									v_u_1486.instant = p1625.data.instant
								end
							end
						end
					end
				end
				if not v_u_1489 then
					local v1630 = p_u_1312
					if type(v1630) ~= "function" then
						return
					end
					v_u_1489 = true
					v_u_3.setText(v_u_1488, "Working ...")
					v_u_1488.TextColor3 = v_u_1317.text2
					local v_u_1631 = "acfast"
					local v_u_1632 = false
					p_u_1312("server.ac", v_u_1624, function(p1633) -- name: done
						-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1631, (ref) v_u_1486, (copy) v_u_1624, (ref) v_u_1485, (copy) v_u_1629, (copy) v_u_1632, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
						v_u_1489 = false
						if not v_u_1322 then
							return
						end
						v_u_1487 = os.clock()
						if type(p1633) == "table" then
							local v1634, v1635, v1636, v1637, v1638
							if v_u_1631 == "status" and p1633.ok then
								local v1639 = p1633.data
								if type(v1639) == "table" then
									v_u_1486 = p1633.data
									if v_u_1629 then
										v_u_1629(p1633)
									end
									if not v_u_1632 then
										v1634 = p1633.msg or (p1633.ok and "Done." or "Refused.")
										v1635 = tostring(v1634)
										v1636 = p1633.ok ~= true
										v_u_3.setText(v_u_1488, v1635)
										v1637 = v_u_1488
										if v1636 then
											v1638 = v_u_1317.danger
										else
											v1638 = v_u_1317.text2
										end
										v1637.TextColor3 = v1638
									end
									v_u_1484()
								else
									if v_u_1624.cmd == "mode" and p1633.ok then
										task.defer(v_u_1485)
									end
									if v_u_1629 then
										v_u_1629(p1633)
									end
									if not v_u_1632 then
										v1634 = p1633.msg or (p1633.ok and "Done." or "Refused.")
										v1635 = tostring(v1634)
										v1636 = p1633.ok ~= true
										v_u_3.setText(v_u_1488, v1635)
										v1637 = v_u_1488
										if v1636 then
											v1638 = v_u_1317.danger
										else
											v1638 = v_u_1317.text2
										end
										v1637.TextColor3 = v1638
									end
									v_u_1484()
								end
							else
								if v_u_1624.cmd == "mode" and p1633.ok then
									task.defer(v_u_1485)
								end
								if v_u_1629 then
									v_u_1629(p1633)
								end
								if not v_u_1632 then
									v1634 = p1633.msg or (p1633.ok and "Done." or "Refused.")
									v1635 = tostring(v1634)
									v1636 = p1633.ok ~= true
									v_u_3.setText(v_u_1488, v1635)
									v1637 = v_u_1488
									if v1636 then
										v1638 = v_u_1317.danger
									else
										v1638 = v_u_1317.text2
									end
									v1637.TextColor3 = v1638
								end
								v_u_1484()
								return
							end
						else
							if not v_u_1632 then
								v_u_3.setText(v_u_1488, "The server did not answer.")
								v_u_1488.TextColor3 = v_u_1317.danger
							end
							v_u_1484()
							return
						end
					end)
				end
			end
			local v_u_1641 = 0
			local function v_u_1642() -- name: go
				-- upvalues: (ref) v_u_1322, (ref) v_u_1489, (ref) v_u_1641, (copy) v_u_1642, (copy) v_u_1640
				if v_u_1322 then
					if v_u_1489 and v_u_1641 < 14 then
						v_u_1641 = v_u_1641 + 1
						task.delay(0.35, v_u_1642)
					else
						v_u_1640()
					end
				else
					return
				end
			end
			if v_u_1322 then
				if v_u_1489 and v_u_1641 < 14 then
					v_u_1641 = v_u_1641 + 1
					task.delay(0.35, v_u_1642)
				else
					local v_u_1643 = {
						["cmd"] = "acfast",
						[v_u_1622] = v_u_1623
					}
					local function v_u_1648(p1644)
						-- upvalues: (ref) v_u_1486
						if p1644.ok then
							local v1645 = p1644.data
							if type(v1645) == "table" then
								local v1646 = p1644.data.instant
								if type(v1646) == "table" then
									local v1647 = v_u_1486
									if type(v1647) == "table" then
										v_u_1486.instant = p1644.data.instant
									end
								end
							end
						end
					end
					if not v_u_1489 then
						local v1649 = p_u_1312
						if type(v1649) == "function" then
							v_u_1489 = true
							v_u_1379("Working ...")
							local v_u_1650 = "acfast"
							local v_u_1651 = false
							p_u_1312("server.ac", v_u_1643, function(p1652) -- name: done
								-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1650, (ref) v_u_1486, (copy) v_u_1643, (ref) v_u_1485, (copy) v_u_1648, (copy) v_u_1651, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
								v_u_1489 = false
								if not v_u_1322 then
									return
								end
								v_u_1487 = os.clock()
								if type(p1652) == "table" then
									local v1653, v1654, v1655, v1656, v1657
									if v_u_1650 == "status" and p1652.ok then
										local v1658 = p1652.data
										if type(v1658) == "table" then
											v_u_1486 = p1652.data
											if v_u_1648 then
												v_u_1648(p1652)
											end
											if not v_u_1651 then
												v1653 = p1652.msg or (p1652.ok and "Done." or "Refused.")
												v1654 = tostring(v1653)
												v1655 = p1652.ok ~= true
												v_u_3.setText(v_u_1488, v1654)
												v1656 = v_u_1488
												if v1655 then
													v1657 = v_u_1317.danger
												else
													v1657 = v_u_1317.text2
												end
												v1656.TextColor3 = v1657
											end
											v_u_1484()
										else
											if v_u_1643.cmd == "mode" and p1652.ok then
												task.defer(v_u_1485)
											end
											if v_u_1648 then
												v_u_1648(p1652)
											end
											if not v_u_1651 then
												v1653 = p1652.msg or (p1652.ok and "Done." or "Refused.")
												v1654 = tostring(v1653)
												v1655 = p1652.ok ~= true
												v_u_3.setText(v_u_1488, v1654)
												v1656 = v_u_1488
												if v1655 then
													v1657 = v_u_1317.danger
												else
													v1657 = v_u_1317.text2
												end
												v1656.TextColor3 = v1657
											end
											v_u_1484()
										end
									else
										if v_u_1643.cmd == "mode" and p1652.ok then
											task.defer(v_u_1485)
										end
										if v_u_1648 then
											v_u_1648(p1652)
										end
										if not v_u_1651 then
											v1653 = p1652.msg or (p1652.ok and "Done." or "Refused.")
											v1654 = tostring(v1653)
											v1655 = p1652.ok ~= true
											v_u_3.setText(v_u_1488, v1654)
											v1656 = v_u_1488
											if v1655 then
												v1657 = v_u_1317.danger
											else
												v1657 = v_u_1317.text2
											end
											v1656.TextColor3 = v1657
										end
										v_u_1484()
										return
									end
								else
									if not v_u_1651 then
										v_u_3.setText(v_u_1488, "The server did not answer.")
										v_u_1488.TextColor3 = v_u_1317.danger
									end
									v_u_1484()
									return
								end
							end)
						end
					end
				end
			end
		end
		local v1659, v1660 = v1619(v1620)
		v1659.Name = "AcInst_" .. v1618
		v_u_1614[v1618] = {
			["btn"] = v1659,
			["api"] = v1660,
			["press"] = function() -- name: press
				-- upvalues: (copy) v_u_1616, (copy) v_u_1617, (ref) v_u_1486, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1484, (copy) v_u_1379
				local v_u_1661 = v_u_1616
				local v_u_1662 = v_u_1617
				local function v_u_1679()
					-- upvalues: (copy) v_u_1661, (copy) v_u_1662, (ref) v_u_1486, (ref) v_u_1489, (ref) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1484
					local v_u_1663 = {
						["cmd"] = "acfast",
						[v_u_1661] = v_u_1662
					}
					local function v_u_1668(p1664)
						-- upvalues: (ref) v_u_1486
						if p1664.ok then
							local v1665 = p1664.data
							if type(v1665) == "table" then
								local v1666 = p1664.data.instant
								if type(v1666) == "table" then
									local v1667 = v_u_1486
									if type(v1667) == "table" then
										v_u_1486.instant = p1664.data.instant
									end
								end
							end
						end
					end
					if not v_u_1489 then
						local v1669 = p_u_1312
						if type(v1669) ~= "function" then
							return
						end
						v_u_1489 = true
						v_u_3.setText(v_u_1488, "Working ...")
						v_u_1488.TextColor3 = v_u_1317.text2
						local v_u_1670 = "acfast"
						local v_u_1671 = false
						p_u_1312("server.ac", v_u_1663, function(p1672) -- name: done
							-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1670, (ref) v_u_1486, (copy) v_u_1663, (ref) v_u_1485, (copy) v_u_1668, (copy) v_u_1671, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
							v_u_1489 = false
							if not v_u_1322 then
								return
							end
							v_u_1487 = os.clock()
							if type(p1672) == "table" then
								local v1673, v1674, v1675, v1676, v1677
								if v_u_1670 == "status" and p1672.ok then
									local v1678 = p1672.data
									if type(v1678) == "table" then
										v_u_1486 = p1672.data
										if v_u_1668 then
											v_u_1668(p1672)
										end
										if not v_u_1671 then
											v1673 = p1672.msg or (p1672.ok and "Done." or "Refused.")
											v1674 = tostring(v1673)
											v1675 = p1672.ok ~= true
											v_u_3.setText(v_u_1488, v1674)
											v1676 = v_u_1488
											if v1675 then
												v1677 = v_u_1317.danger
											else
												v1677 = v_u_1317.text2
											end
											v1676.TextColor3 = v1677
										end
										v_u_1484()
									else
										if v_u_1663.cmd == "mode" and p1672.ok then
											task.defer(v_u_1485)
										end
										if v_u_1668 then
											v_u_1668(p1672)
										end
										if not v_u_1671 then
											v1673 = p1672.msg or (p1672.ok and "Done." or "Refused.")
											v1674 = tostring(v1673)
											v1675 = p1672.ok ~= true
											v_u_3.setText(v_u_1488, v1674)
											v1676 = v_u_1488
											if v1675 then
												v1677 = v_u_1317.danger
											else
												v1677 = v_u_1317.text2
											end
											v1676.TextColor3 = v1677
										end
										v_u_1484()
									end
								else
									if v_u_1663.cmd == "mode" and p1672.ok then
										task.defer(v_u_1485)
									end
									if v_u_1668 then
										v_u_1668(p1672)
									end
									if not v_u_1671 then
										v1673 = p1672.msg or (p1672.ok and "Done." or "Refused.")
										v1674 = tostring(v1673)
										v1675 = p1672.ok ~= true
										v_u_3.setText(v_u_1488, v1674)
										v1676 = v_u_1488
										if v1675 then
											v1677 = v_u_1317.danger
										else
											v1677 = v_u_1317.text2
										end
										v1676.TextColor3 = v1677
									end
									v_u_1484()
									return
								end
							else
								if not v_u_1671 then
									v_u_3.setText(v_u_1488, "The server did not answer.")
									v_u_1488.TextColor3 = v_u_1317.danger
								end
								v_u_1484()
								return
							end
						end)
					end
				end
				local v_u_1680 = 0
				local function v_u_1681() -- name: go
					-- upvalues: (ref) v_u_1322, (ref) v_u_1489, (ref) v_u_1680, (copy) v_u_1681, (copy) v_u_1679
					if v_u_1322 then
						if v_u_1489 and v_u_1680 < 14 then
							v_u_1680 = v_u_1680 + 1
							task.delay(0.35, v_u_1681)
						else
							v_u_1679()
						end
					else
						return
					end
				end
				if v_u_1322 then
					if v_u_1489 and v_u_1680 < 14 then
						v_u_1680 = v_u_1680 + 1
						task.delay(0.35, v_u_1681)
					else
						local v_u_1682 = {
							["cmd"] = "acfast",
							[v_u_1661] = v_u_1662
						}
						local function v_u_1687(p1683)
							-- upvalues: (ref) v_u_1486
							if p1683.ok then
								local v1684 = p1683.data
								if type(v1684) == "table" then
									local v1685 = p1683.data.instant
									if type(v1685) == "table" then
										local v1686 = v_u_1486
										if type(v1686) == "table" then
											v_u_1486.instant = p1683.data.instant
										end
									end
								end
							end
						end
						if not v_u_1489 then
							local v1688 = p_u_1312
							if type(v1688) == "function" then
								v_u_1489 = true
								v_u_1379("Working ...")
								local v_u_1689 = "acfast"
								local v_u_1690 = false
								p_u_1312("server.ac", v_u_1682, function(p1691) -- name: done
									-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1689, (ref) v_u_1486, (copy) v_u_1682, (ref) v_u_1485, (copy) v_u_1687, (copy) v_u_1690, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
									v_u_1489 = false
									if not v_u_1322 then
										return
									end
									v_u_1487 = os.clock()
									if type(p1691) == "table" then
										local v1692, v1693, v1694, v1695, v1696
										if v_u_1689 == "status" and p1691.ok then
											local v1697 = p1691.data
											if type(v1697) == "table" then
												v_u_1486 = p1691.data
												if v_u_1687 then
													v_u_1687(p1691)
												end
												if not v_u_1690 then
													v1692 = p1691.msg or (p1691.ok and "Done." or "Refused.")
													v1693 = tostring(v1692)
													v1694 = p1691.ok ~= true
													v_u_3.setText(v_u_1488, v1693)
													v1695 = v_u_1488
													if v1694 then
														v1696 = v_u_1317.danger
													else
														v1696 = v_u_1317.text2
													end
													v1695.TextColor3 = v1696
												end
												v_u_1484()
											else
												if v_u_1682.cmd == "mode" and p1691.ok then
													task.defer(v_u_1485)
												end
												if v_u_1687 then
													v_u_1687(p1691)
												end
												if not v_u_1690 then
													v1692 = p1691.msg or (p1691.ok and "Done." or "Refused.")
													v1693 = tostring(v1692)
													v1694 = p1691.ok ~= true
													v_u_3.setText(v_u_1488, v1693)
													v1695 = v_u_1488
													if v1694 then
														v1696 = v_u_1317.danger
													else
														v1696 = v_u_1317.text2
													end
													v1695.TextColor3 = v1696
												end
												v_u_1484()
											end
										else
											if v_u_1682.cmd == "mode" and p1691.ok then
												task.defer(v_u_1485)
											end
											if v_u_1687 then
												v_u_1687(p1691)
											end
											if not v_u_1690 then
												v1692 = p1691.msg or (p1691.ok and "Done." or "Refused.")
												v1693 = tostring(v1692)
												v1694 = p1691.ok ~= true
												v_u_3.setText(v_u_1488, v1693)
												v1695 = v_u_1488
												if v1694 then
													v1696 = v_u_1317.danger
												else
													v1696 = v_u_1317.text2
												end
												v1695.TextColor3 = v1696
											end
											v_u_1484()
											return
										end
									else
										if not v_u_1690 then
											v_u_3.setText(v_u_1488, "The server did not answer.")
											v_u_1488.TextColor3 = v_u_1317.danger
										end
										v_u_1484()
										return
									end
								end)
							end
						end
					end
				end
			end
		}
	end
	v1335("AcInstNote", "Kick OFF: nobody is removed by the instant rules, the evidence is still recorded for the moderator. Check OFF: every shot at a player lands as before.", v_u_1317.muted)
	local v_u_1698 = v1354("AcInstList")
	v1335("AcLookLabel", "Look up a player (user id or name)", v_u_1317.muted)
	local v1699 = p_u_1313.touch
	local v1700 = v1349(type(v1699) ~= "function" and 34 or p_u_1313.touch(34), "AcLookRow")
	local v1701 = v_u_3.input
	local v1702 = {
		["parent"] = nil,
		["name"] = "AcLookInput",
		["placeholder"] = "user id or name",
		["width"] = nil,
		["text"] = "",
		["maxLength"] = 40,
		["parent"] = v1700
	}
	local v1703 = v1319 - 130
	v1702.width = math.max(160, v1703)
	local v1704, v_u_1705 = v1701(v1702)
	v1704.LayoutOrder = 1
	local v_u_1706 = v_u_1705
	v_u_1705.FocusLost:Connect(function(p1707)
		-- upvalues: (copy) v_u_1418, (copy) v_u_1705
		if p1707 then
			v_u_1418(v_u_1705.Text)
		end
	end)
	local v1708 = v_u_3.button
	local v1709 = {
		["parent"] = nil,
		["text"] = "Look up",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 120,
		["maxTextWidth"] = 108,
		["onClick"] = nil,
		["parent"] = v1700
	}
	local v1710 = p_u_1313.touch
	v1709.height = type(v1710) ~= "function" and 34 or p_u_1313.touch(34)
	function v1709.onClick() -- name: onClick
		-- upvalues: (copy) v_u_1418, (copy) v_u_1705
		v_u_1418(v_u_1705.Text)
	end
	local v1711 = v1708(v1709)
	v1711.Name = "AcLookGo"
	v1711.LayoutOrder = 2
	local v_u_1712 = v1354("AcLookList")
	local v1713 = p_u_1313.touch
	local v1714 = v1349(type(v1713) ~= "function" and 32 or p_u_1313.touch(32), "AcActRow")
	local v1715 = (v1319 - 6) / 2
	local v1716 = math.floor(v1715)
	local function v_u_1732() -- name: doReview
		-- upvalues: (ref) v_u_1483, (ref) v_u_1479, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484
		if v_u_1483 then
			local v_u_1717 = {
				["cmd"] = "review",
				["userId"] = nil,
				["userId"] = v_u_1483
			}
			local function v_u_1721(p1718)
				-- upvalues: (ref) v_u_1479
				if p1718.ok then
					local v1719 = p1718.data
					if type(v1719) == "table" then
						local v1720 = p1718.data.record
						if type(v1720) == "table" and v_u_1479 then
							v_u_1479.record = p1718.data.record
						end
					end
				end
			end
			if not v_u_1489 then
				local v1722 = p_u_1312
				if type(v1722) ~= "function" then
					return
				end
				v_u_1489 = true
				v_u_3.setText(v_u_1488, "Working ...")
				v_u_1488.TextColor3 = v_u_1317.text2
				local v_u_1723 = "review"
				local v_u_1724 = false
				p_u_1312("server.ac", v_u_1717, function(p1725) -- name: done
					-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1723, (ref) v_u_1486, (copy) v_u_1717, (ref) v_u_1485, (copy) v_u_1721, (copy) v_u_1724, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
					v_u_1489 = false
					if not v_u_1322 then
						return
					end
					v_u_1487 = os.clock()
					if type(p1725) == "table" then
						local v1726, v1727, v1728, v1729, v1730
						if v_u_1723 == "status" and p1725.ok then
							local v1731 = p1725.data
							if type(v1731) == "table" then
								v_u_1486 = p1725.data
								if v_u_1721 then
									v_u_1721(p1725)
								end
								if not v_u_1724 then
									v1726 = p1725.msg or (p1725.ok and "Done." or "Refused.")
									v1727 = tostring(v1726)
									v1728 = p1725.ok ~= true
									v_u_3.setText(v_u_1488, v1727)
									v1729 = v_u_1488
									if v1728 then
										v1730 = v_u_1317.danger
									else
										v1730 = v_u_1317.text2
									end
									v1729.TextColor3 = v1730
								end
								v_u_1484()
							else
								if v_u_1717.cmd == "mode" and p1725.ok then
									task.defer(v_u_1485)
								end
								if v_u_1721 then
									v_u_1721(p1725)
								end
								if not v_u_1724 then
									v1726 = p1725.msg or (p1725.ok and "Done." or "Refused.")
									v1727 = tostring(v1726)
									v1728 = p1725.ok ~= true
									v_u_3.setText(v_u_1488, v1727)
									v1729 = v_u_1488
									if v1728 then
										v1730 = v_u_1317.danger
									else
										v1730 = v_u_1317.text2
									end
									v1729.TextColor3 = v1730
								end
								v_u_1484()
							end
						else
							if v_u_1717.cmd == "mode" and p1725.ok then
								task.defer(v_u_1485)
							end
							if v_u_1721 then
								v_u_1721(p1725)
							end
							if not v_u_1724 then
								v1726 = p1725.msg or (p1725.ok and "Done." or "Refused.")
								v1727 = tostring(v1726)
								v1728 = p1725.ok ~= true
								v_u_3.setText(v_u_1488, v1727)
								v1729 = v_u_1488
								if v1728 then
									v1730 = v_u_1317.danger
								else
									v1730 = v_u_1317.text2
								end
								v1729.TextColor3 = v1730
							end
							v_u_1484()
							return
						end
					else
						if not v_u_1724 then
							v_u_3.setText(v_u_1488, "The server did not answer.")
							v_u_1488.TextColor3 = v_u_1317.danger
						end
						v_u_1484()
						return
					end
				end)
			end
		end
	end
	local function v_u_1751(p1733) -- name: doClear
		-- upvalues: (ref) v_u_1483, (ref) v_u_1481, (ref) v_u_1362, (ref) v_u_3, (ref) v_u_1488, (copy) v_u_1317, (ref) v_u_1479, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1485, (ref) v_u_1484
		if v_u_1483 then
			local v1734 = os.clock()
			if p1733 or v_u_1481 and v1734 - v_u_1362 <= 6 then
				v_u_1481 = false
				local v_u_1735 = {
					["cmd"] = "clear",
					["userId"] = nil,
					["userId"] = v_u_1483
				}
				local function v_u_1739(p1736)
					-- upvalues: (ref) v_u_1479
					if p1736.ok then
						local v1737 = p1736.data
						if type(v1737) == "table" then
							local v1738 = p1736.data.record
							if type(v1738) == "table" and v_u_1479 then
								v_u_1479.record = p1736.data.record
							end
						end
					end
				end
				if not v_u_1489 then
					local v1740 = p_u_1312
					if type(v1740) ~= "function" then
						return
					end
					v_u_1489 = true
					v_u_3.setText(v_u_1488, "Working ...")
					v_u_1488.TextColor3 = v_u_1317.text2
					local v_u_1741 = "clear"
					local v_u_1742 = false
					p_u_1312("server.ac", v_u_1735, function(p1743) -- name: done
						-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_1741, (ref) v_u_1486, (copy) v_u_1735, (ref) v_u_1485, (copy) v_u_1739, (copy) v_u_1742, (ref) v_u_3, (ref) v_u_1488, (ref) v_u_1317, (ref) v_u_1484
						v_u_1489 = false
						if not v_u_1322 then
							return
						end
						v_u_1487 = os.clock()
						if type(p1743) == "table" then
							local v1744, v1745, v1746, v1747, v1748
							if v_u_1741 == "status" and p1743.ok then
								local v1749 = p1743.data
								if type(v1749) == "table" then
									v_u_1486 = p1743.data
									if v_u_1739 then
										v_u_1739(p1743)
									end
									if not v_u_1742 then
										v1744 = p1743.msg or (p1743.ok and "Done." or "Refused.")
										v1745 = tostring(v1744)
										v1746 = p1743.ok ~= true
										v_u_3.setText(v_u_1488, v1745)
										v1747 = v_u_1488
										if v1746 then
											v1748 = v_u_1317.danger
										else
											v1748 = v_u_1317.text2
										end
										v1747.TextColor3 = v1748
									end
									v_u_1484()
								else
									if v_u_1735.cmd == "mode" and p1743.ok then
										task.defer(v_u_1485)
									end
									if v_u_1739 then
										v_u_1739(p1743)
									end
									if not v_u_1742 then
										v1744 = p1743.msg or (p1743.ok and "Done." or "Refused.")
										v1745 = tostring(v1744)
										v1746 = p1743.ok ~= true
										v_u_3.setText(v_u_1488, v1745)
										v1747 = v_u_1488
										if v1746 then
											v1748 = v_u_1317.danger
										else
											v1748 = v_u_1317.text2
										end
										v1747.TextColor3 = v1748
									end
									v_u_1484()
								end
							else
								if v_u_1735.cmd == "mode" and p1743.ok then
									task.defer(v_u_1485)
								end
								if v_u_1739 then
									v_u_1739(p1743)
								end
								if not v_u_1742 then
									v1744 = p1743.msg or (p1743.ok and "Done." or "Refused.")
									v1745 = tostring(v1744)
									v1746 = p1743.ok ~= true
									v_u_3.setText(v_u_1488, v1745)
									v1747 = v_u_1488
									if v1746 then
										v1748 = v_u_1317.danger
									else
										v1748 = v_u_1317.text2
									end
									v1747.TextColor3 = v1748
								end
								v_u_1484()
								return
							end
						else
							if not v_u_1742 then
								v_u_3.setText(v_u_1488, "The server did not answer.")
								v_u_1488.TextColor3 = v_u_1317.danger
							end
							v_u_1484()
							return
						end
					end)
				end
			else
				v_u_1481 = true
				v_u_1362 = v1734
				local v1750 = ("The flag moves to the history. Press CLEAR FLAG again within %d seconds to confirm."):format(6)
				v_u_3.setText(v_u_1488, v1750)
				v_u_1488.TextColor3 = v_u_1317.danger
			end
		else
			return
		end
	end
	local v1752 = v_u_3.button
	local v1753 = {
		["parent"] = nil,
		["text"] = "Mark reviewed",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v1714
	}
	local v1754 = p_u_1313.touch
	v1753.height = type(v1754) ~= "function" and 32 or p_u_1313.touch(32)
	v1753.width = v1716
	v1753.maxTextWidth = v1716 - 12
	v1753.onClick = v_u_1732
	local v1755, v1756 = v1752(v1753)
	v1755.Name = "AcReview"
	local v_u_1757 = v1756
	local v1758 = v_u_3.button
	local v1759 = {
		["parent"] = nil,
		["text"] = "Clear flag",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v1714
	}
	local v1760 = p_u_1313.touch
	v1759.height = type(v1760) ~= "function" and 32 or p_u_1313.touch(32)
	v1759.width = v1716
	v1759.maxTextWidth = v1716 - 12
	function v1759.onClick() -- name: onClick
		-- upvalues: (copy) v_u_1751
		v_u_1751(false)
	end
	local v1761, v1762 = v1758(v1759)
	v1761.Name = "AcClear"
	local v_u_1763 = v1762
	v1335("AcTraceLabel", "Flight recorder: the traces of the looked up player (tap one to open it)", v_u_1317.muted)
	local v_u_1764 = v1354("AcTraceList")
	local v1765 = math.min(v1319, 400)
	local v_u_1766 = math.max(200, v1765)
	local v1767 = v_u_3.new("Frame", {
		["Name"] = "AcTraceCanvasRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_1766 + 4)
	}, p_u_1311)
	local v1768 = v_u_1315.order
	local v1769
	if type(v1768) == "function" then
		v1769 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1769 = v_u_1321
	end
	v1767.LayoutOrder = v1769
	local v_u_1770 = v_u_3.new("Frame", {
		["Name"] = "AcTraceCanvas",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_1317.raised,
		["Size"] = UDim2.fromOffset(v_u_1766, v_u_1766)
	}, v1767)
	v_u_3.stroke(v_u_1770, v_u_1317.line)
	local v_u_1771 = v1354("AcTraceText")
	v1335("AcWatchLabel", "Watch a player on this server (a full recording of the current raid, up to 20 minutes, written when the raid ends)", v_u_1317.muted)
	local v1772 = p_u_1313.touch
	local v1773 = v1349(type(v1772) ~= "function" and 34 or p_u_1313.touch(34), "AcWatchRow")
	local v1774 = v_u_3.input
	local v1775 = {
		["parent"] = nil,
		["name"] = "AcWatchInput",
		["placeholder"] = "name or user id",
		["width"] = nil,
		["text"] = "",
		["maxLength"] = 40,
		["parent"] = v1773
	}
	local v1776 = v1319 - 130
	v1775.width = math.max(160, v1776)
	local v1777, v_u_1778 = v1774(v1775)
	v1777.LayoutOrder = 1
	v_u_1778.FocusLost:Connect(function(p1779)
		-- upvalues: (ref) v_u_1471, (copy) v_u_1778
		if p1779 then
			v_u_1471(v_u_1778.Text)
		end
	end)
	local v1780 = v_u_3.button
	local v1781 = {
		["parent"] = nil,
		["text"] = "Watch",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 120,
		["maxTextWidth"] = 108,
		["onClick"] = nil,
		["parent"] = v1773
	}
	local v1782 = p_u_1313.touch
	v1781.height = type(v1782) ~= "function" and 34 or p_u_1313.touch(34)
	function v1781.onClick() -- name: onClick
		-- upvalues: (ref) v_u_1471, (copy) v_u_1778
		v_u_1471(v_u_1778.Text)
	end
	local v1783 = v1780(v1781)
	v1783.Name = "AcWatchGo"
	v1783.LayoutOrder = 2
	v1335("AcLiveLabel", "Players on this server (highest score first)", v_u_1317.muted)
	local v_u_1784 = v1354("AcLiveList")
	v1335("AcTuneLabel", "Thresholds (read only)", v_u_1317.muted)
	local v_u_1785 = v1354("AcTuneList")
	v1335("AcCodeLabel", "Counters by detector (this server)", v_u_1317.muted)
	local v_u_1786 = v1354("AcCodeList")
	v1335("AcNetLabel", "Network health of this server (R37, memory only: why players get Error 277 style disconnects)", v_u_1317.muted)
	local v_u_1787 = v1354("AcNetList")
	v_u_1360 = v_u_3.label({
		["parent"] = nil,
		["name"] = "AcStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_1311,
		["color"] = v_u_1317.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v1788 = v_u_1315.order
	local v1789
	if type(v1788) == "function" then
		v1789 = v_u_1315.order()
	else
		v_u_1321 = v_u_1321 + 1
		v1789 = v_u_1321
	end
	v_u_1360.LayoutOrder = v1789
	local function v_u_1801(p1790, p1791, p1792) -- name: fill
		-- upvalues: (copy) v_u_1317, (ref) v_u_3
		for _, v1793 in p1790:GetChildren() do
			if not v1793:IsA("GuiObject") then
				continue
			end
			v1793:Destroy()
		end
		for v1794, v1795 in p1791 do
			local v1796
			if v1795.kind == "ok" then
				v1796 = v_u_1317.success
			elseif v1795.kind == "warn" then
				v1796 = v_u_1317.danger
			elseif v1795.kind == "muted" then
				v1796 = v_u_1317.muted
			elseif v1795.kind == "head" then
				v1796 = v_u_1317.text
			else
				v1796 = v_u_1317.text2
			end
			local v1797 = v_u_3.label
			local v1798 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = p1790
			}
			local v1799 = v1795.name
			v1798.name = p1792 .. tostring(v1799)
			local v1800 = v1795.text
			v1798.text = tostring(v1800)
			v1798.color = v1796
			v1798.size = UDim2.new(1, 0, 0, 0)
			v1797(v1798).LayoutOrder = v1794
		end
	end
	v_u_1373 = function()
		-- upvalues: (copy) v_u_1801, (copy) v_u_1326, (ref) v_u_4, (ref) v_u_1486, (copy) v_u_1363, (copy) v_u_1524, (ref) v_u_3, (copy) v_u_1317, (copy) p_u_1313, (copy) v_u_1418, (ref) v_u_1706, (copy) v_u_1528, (ref) v_u_1364, (copy) v_u_1532, (copy) v_u_1366, (copy) v_u_1537, (copy) v_u_1698, (copy) v_u_1614, (copy) v_u_1712, (ref) v_u_1479, (ref) v_u_1757, (ref) v_u_1763, (copy) v_u_1764, (ref) v_u_1478, (ref) v_u_1482, (ref) v_u_1477, (ref) v_u_1451, (copy) v_u_1770, (ref) v_u_1371, (copy) v_u_1766, (copy) v_u_1771, (copy) v_u_1784, (copy) v_u_1785, (copy) v_u_1786, (copy) v_u_1787, (ref) v_u_5, (ref) v_u_1483
		local v_u_1802 = os.time()
		v_u_1801(v_u_1326, v_u_4.headLines(v_u_1486), "Ac")
		local v1803 = v_u_1486
		local v1804
		if type(v1803) == "table" then
			local v1805 = v_u_1486.mode
			v1804 = tostring(v1805)
		else
			v1804 = "?"
		end
		local v1806 = v_u_1486
		local v1807
		if type(v1806) == "table" then
			local v1808 = v_u_1486.doc
			v1807 = tostring(v1808)
		else
			v1807 = "?"
		end
		for v1809, v1810 in v_u_1363 do
			v1810.api.setKind((v1809 == "off" and v1804 == "off" or v1809 == "shadow" and v1804 == "shadow") and "primary" or "secondary")
		end
		for _, v1811 in v_u_1524:GetChildren() do
			if not v1811:IsA("GuiObject") then
				continue
			end
			v1811:Destroy()
		end
		local v1812 = v_u_1486
		local v1813
		if type(v1812) == "table" then
			local v1814 = v_u_1486.flagged
			v1813 = type(v1814) ~= "table" and {} or v_u_1486.flagged
		else
			v1813 = {}
		end
		if #v1813 == 0 then
			local v1815 = v_u_3.label
			local v1816 = {
				["parent"] = nil,
				["name"] = "AcNoFlags",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v_u_1524
			}
			local v1817 = v_u_1486
			v1816.text = type(v1817) == "table" and v_u_1486.indexRead == false and "The flag list could not be read." or "Nobody is flagged."
			v1816.color = v_u_1317.muted
			v1816.size = UDim2.new(1, 0, 0, 22)
			v1815(v1816).LayoutOrder = 1
		end
		local function v1836(p1818, p1819, p_u_1820, p1821) -- name: addPlayerRow
			-- upvalues: (ref) v_u_4, (copy) v_u_1802, (ref) v_u_3, (ref) v_u_1317, (ref) p_u_1313, (ref) v_u_1418, (ref) v_u_1706
			local v1822, v1823 = v_u_4.flaggedLines(p_u_1820, v_u_1802)
			local v1824 = v_u_3.new
			local v1825 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil
			}
			local v1826 = p_u_1820.uid
			v1825.Name = p1819 .. tostring(v1826)
			v1825.BackgroundColor3 = v_u_1317.raised
			local v1827 = UDim2.new
			local v1828 = p_u_1313.touch
			v1825.Size = v1827(1, 0, 0, type(v1828) ~= "function" and 40 or p_u_1313.touch(40))
			v1825.LayoutOrder = p1821
			local v1829 = v1824("TextButton", v1825, p1818)
			local v1830 = v_u_3.stroke
			local v1831
			if p_u_1820.reviewed then
				v1831 = v_u_1317.line
			else
				v1831 = v_u_1317.accent
			end
			v1830(v1829, v1831)
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1829,
				["text"] = v1822,
				["position"] = UDim2.fromOffset(10, 2),
				["size"] = UDim2.new(1, -20, 0, 20)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1829,
				["text"] = v1823,
				["color"] = v_u_1317.muted,
				["position"] = UDim2.fromOffset(10, 21),
				["size"] = UDim2.new(1, -20, 0, 16)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v1829.Activated:Connect(function()
				-- upvalues: (ref) v_u_1418, (copy) p_u_1820, (ref) v_u_1706
				local v1832 = v_u_1418
				local v1833 = p_u_1820.uid
				v1832((tostring(v1833)))
				if v_u_1706 then
					local v1834 = v_u_1706
					local v1835 = p_u_1820.uid
					v1834.Text = tostring(v1835)
				end
			end)
		end
		for v1837, v1838 in v1813 do
			if v1837 > 30 then
				break
			end
			v1836(v_u_1524, "AcFlag_", v1838, v1837)
		end
		for _, v1839 in v_u_1528:GetChildren() do
			if not v1839:IsA("GuiObject") then
				continue
			end
			v1839:Destroy()
		end
		local v1840 = v_u_1486
		local v1841
		if type(v1840) == "table" then
			local v1842 = v_u_1486.reported
			v1841 = type(v1842) ~= "table" and {} or v_u_1486.reported
		else
			v1841 = {}
		end
		if #v1841 == 0 then
			local v1843 = v_u_3.label
			local v1844 = {
				["parent"] = nil,
				["name"] = "AcNoReports",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v_u_1528
			}
			local v1845 = v_u_1486
			v1844.text = type(v1845) == "table" and v_u_1486.indexRead == false and "The list could not be read." or "Nobody is reported."
			v1844.color = v_u_1317.muted
			v1844.size = UDim2.new(1, 0, 0, 22)
			v1843(v1844).LayoutOrder = 1
		end
		for v1846, v1847 in v1841 do
			if v1846 > 30 then
				break
			end
			v1836(v_u_1528, "AcRep_", v1847, v1846)
		end
		local v1848 = 0
		local v1849 = v_u_1486
		local v1850
		if type(v1849) == "table" then
			v1850 = v_u_1486.verdict
		else
			v1850 = nil
		end
		local v1851 = v_u_1364
		local v1852
		if type(v1851) == "table" then
			v1852 = v_u_1364.list
		else
			v1852 = nil
		end
		local v1853 = {}
		local v1854, v1855 = v_u_4.bridgeLine(v1850)
		table.insert(v1853, {
			["name"] = "Bridge",
			["text"] = nil,
			["kind"] = nil,
			["text"] = v1854,
			["kind"] = v1855
		})
		for _, v1856 in v_u_4.verdictCountLines(v1852, v_u_1802) do
			table.insert(v1853, v1856)
		end
		v_u_1801(v_u_1532, v1853, "Vh")
		local v1857 = v_u_1364
		local v1858, v1859
		if type(v1857) == "table" then
			local v1860 = v_u_1364.kick
			if type(v1860) == "table" then
				v1858 = v_u_1364.kick
			elseif type(v1850) == "table" then
				v1859 = v1850.kick
				if type(v1859) == "table" then
					v1858 = v1850.kick
				else
					v1858 = nil
				end
			else
				v1858 = nil
			end
		elseif type(v1850) == "table" then
			v1859 = v1850.kick
			if type(v1859) == "table" then
				v1858 = v1850.kick
			else
				v1858 = nil
			end
		else
			v1858 = nil
		end
		local v1861 = v1858 == nil and true or v1858.on ~= false
		for v1862, v1863 in v_u_1366 do
			if v1862 == "refresh" then
				continue
			end
			v1863.api.setKind(v1862 == "on" == v1861 and "primary" or "secondary")
		end
		for _, v1864 in v_u_1537:GetChildren() do
			if not v1864:IsA("GuiObject") then
				continue
			end
			v1864:Destroy()
		end
		local v1865
		if type(v1852) == "table" then
			local v1866 = v1852.rows
			v1865 = type(v1866) ~= "table" and {} or v1852.rows
		else
			v1865 = {}
		end
		local v1867
		if type(v1852) == "table" then
			local v1868 = v1852.source
			v1867 = tostring(v1868)
		else
			v1867 = "none"
		end
		if #v1865 == 0 then
			v_u_3.label({
				["parent"] = nil,
				["name"] = "AcNoVerdicts",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v_u_1537,
				["text"] = type(v1852) == "table" and "No verdicts yet." or "Press REFRESH to read the verdicts.",
				["color"] = v_u_1317.muted,
				["size"] = UDim2.new(1, 0, 0, 22)
			}).LayoutOrder = 1
		end
		for v1869, v_u_1870 in v1865 do
			if v1869 > 10 then
				break
			end
			v1848 = v1848 + 1
			local v1871, v1872 = v_u_4.verdictRowLines(v_u_1870, v_u_1802)
			local v1873 = v_u_3.new
			local v1874 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil
			}
			local v1875 = v_u_1870.uid
			v1874.Name = "AcVerd_" .. tostring(v1875)
			v1874.BackgroundColor3 = v_u_1317.raised
			local v1876 = UDim2.new
			local v1877 = p_u_1313.touch
			v1874.Size = v1876(1, 0, 0, type(v1877) ~= "function" and 40 or p_u_1313.touch(40))
			v1874.LayoutOrder = v1869
			local v1878 = v1873("TextButton", v1874, v_u_1537)
			local v1879 = v_u_3.stroke
			local v1880
			if v_u_1870.action == "ban" then
				local v1881 = v_u_1870.ends
				if v_u_1802 < (tonumber(v1881) or 0) then
					v1880 = v_u_1317.danger
				else
					v1880 = v_u_1317.line
				end
			else
				v1880 = v_u_1317.line
			end
			v1879(v1878, v1880)
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1878,
				["text"] = v1871,
				["position"] = UDim2.fromOffset(10, 2),
				["size"] = UDim2.new(1, -20, 0, 20)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1878,
				["text"] = v1872,
				["color"] = v_u_1317.muted,
				["position"] = UDim2.fromOffset(10, 21),
				["size"] = UDim2.new(1, -20, 0, 16)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v1878.Activated:Connect(function()
				-- upvalues: (ref) v_u_1418, (copy) v_u_1870, (ref) v_u_1706
				local v1882 = v_u_1418
				local v1883 = v_u_1870.uid
				v1882((tostring(v1883)))
				if v_u_1706 then
					local v1884 = v_u_1706
					local v1885 = v_u_1870.uid
					v1884.Text = tostring(v1885)
				end
			end)
		end
		local v1886 = v_u_1486
		local v1887
		if type(v1886) == "table" then
			v1887 = v_u_1486.instant
		else
			v1887 = nil
		end
		v_u_1801(v_u_1698, v_u_4.instantLines(v1887, v_u_1802), "In")
		local v1888
		if type(v1887) == "table" then
			local v1889 = v1887.doc
			v1888 = type(v1889) ~= "table" and true or v1887.doc.kick ~= false
		else
			v1888 = true
		end
		local v1890
		if type(v1887) == "table" then
			local v1891 = v1887.doc
			v1890 = type(v1891) ~= "table" and true or v1887.doc.refuse ~= false
		else
			v1890 = true
		end
		v_u_1614.kickOn.api.setKind(v1888 and "primary" or "secondary")
		v_u_1614.kickOff.api.setKind(v1888 and "secondary" or "primary")
		v_u_1614.refuseOn.api.setKind(v1890 and "primary" or "secondary")
		v_u_1614.refuseOff.api.setKind(v1890 and "secondary" or "primary")
		v_u_1801(v_u_1712, v_u_4.lookupLines(v_u_1479, v_u_1802), "Lk")
		local v1892 = v_u_1479
		local v1893
		if type(v1892) == "table" then
			v1893 = v_u_1479.record
		else
			v1893 = nil
		end
		local v1894
		if type(v1893) == "table" then
			v1894 = v1893.flagged == true
		else
			v1894 = false
		end
		if v_u_1757 then
			v_u_1757.setEnabled(v1894)
		end
		if v_u_1763 then
			v_u_1763.setEnabled(v1894)
		end
		for _, v1895 in v_u_1764:GetChildren() do
			if not v1895:IsA("GuiObject") then
				continue
			end
			v1895:Destroy()
		end
		if #v_u_1478 == 0 then
			local v1896 = v_u_1479
			local v1897
			if type(v1896) == "table" then
				local v1898 = v_u_1482
				v1897 = type(v1898) == "table" and "No stored trace yet." or "No traces for this player."
			else
				v1897 = "Look up a player to see his traces."
			end
			v_u_3.label({
				["parent"] = nil,
				["name"] = "AcNoTraces",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v_u_1764,
				["text"] = v1897,
				["color"] = v_u_1317.muted,
				["size"] = UDim2.new(1, 0, 0, 22)
			}).LayoutOrder = 1
		end
		local v1899 = v_u_1482
		if type(v1899) == "table" then
			local v1900 = v_u_3.label
			local v1901 = {
				["parent"] = nil,
				["name"] = "AcTraceLive",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_1764
			}
			local v1902 = "recording now: %d samples  \194\183  %s%s"
			local v1903 = v_u_1482.samples
			local v1904 = tonumber(v1903)
			local v1905
			if v1904 == nil or v1904 ~= v1904 then
				v1905 = 0
			else
				local v1906 = v1904 + 0.5
				v1905 = math.floor(v1906)
			end
			local v1907 = v_u_1482.watching and "watched (full recording)" or "buffer only"
			local v1908 = v_u_1482.why or ""
			local v1909
			if tostring(v1908) == "" then
				v1909 = ""
			else
				local v1910 = v_u_1482.why
				v1909 = "  \194\183  " .. tostring(v1910)
			end
			v1901.text = v1902:format(v1905, v1907, v1909)
			v1901.color = v_u_1317.success
			v1901.size = UDim2.new(1, 0, 0, 0)
			v1900(v1901).LayoutOrder = 0
		end
		for v1911, v_u_1912 in v_u_1478 do
			if v1911 > 5 then
				break
			end
			local v1913, v1914 = v_u_4.traceRowLines(v_u_1912, v_u_1802)
			local v1915 = v_u_3.new
			local v1916 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "AcTrace_" .. tostring(v1911),
				["BackgroundColor3"] = v_u_1317.raised
			}
			local v1917 = UDim2.new
			local v1918 = p_u_1313.touch
			v1916.Size = v1917(1, 0, 0, type(v1918) ~= "function" and 40 or p_u_1313.touch(40))
			v1916.LayoutOrder = v1911
			local v1919 = v1915("TextButton", v1916, v_u_1764)
			local v1920 = v_u_3.stroke
			local v1921 = v_u_1477
			local v1922
			if type(v1921) == "table" and v_u_1477.key == v_u_1912.key then
				v1922 = v_u_1317.accent
			else
				v1922 = v_u_1317.line
			end
			v1920(v1919, v1922)
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1919,
				["text"] = v1913,
				["position"] = UDim2.fromOffset(10, 2),
				["size"] = UDim2.new(1, -20, 0, 20)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v1919,
				["text"] = v1914,
				["color"] = v_u_1317.muted,
				["position"] = UDim2.fromOffset(10, 21),
				["size"] = UDim2.new(1, -20, 0, 16)
			}).TextTruncate = Enum.TextTruncate.AtEnd
			v1919.Activated:Connect(function()
				-- upvalues: (ref) v_u_1451, (copy) v_u_1912
				v_u_1451(v_u_1912.key)
			end)
		end
		for _, v1923 in v_u_1770:GetChildren() do
			if not v1923:IsA("GuiObject") then
				continue
			end
			v1923:Destroy()
		end
		v_u_1371 = nil
		local v1924 = v_u_1477
		if type(v1924) == "table" then
			local v1925 = v_u_4.canvasPlan(v_u_1477, v_u_1766)
			v_u_1371 = v1925
			v_u_1770.Visible = #v1925.segs > 0 and true or #v1925.dots > 0
			for v1926, v1927 in v1925.segs do
				local v1928 = v1927.x2 - v1927.x1
				local v1929 = v1927.y2 - v1927.y1
				local v1930 = v_u_3.new
				local v1931 = "Frame"
				local v1932 = {
					["Name"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Rotation"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 2,
					["Name"] = "Seg" .. tostring(v1926),
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset((v1927.x1 + v1927.x2) / 2, (v1927.y1 + v1927.y2) / 2)
				}
				local v1933 = UDim2.fromOffset
				local v1934 = v1928 * v1928 + v1929 * v1929
				local v1935 = math.sqrt(v1934)
				v1932.Size = v1933(math.max(1, v1935), 2)
				local v1936 = math.atan2(v1929, v1928)
				v1932.Rotation = math.deg(v1936)
				local v1937
				if v1927.fast then
					v1937 = v_u_1317.danger
				else
					v1937 = v_u_1317.text2
				end
				v1932.BackgroundColor3 = v1937
				v1930(v1931, v1932, v_u_1770)
			end
			local v1938 = {
				["snap"] = v_u_1317.danger,
				["tp"] = v_u_1317.danger,
				["mv"] = v_u_1317.muted,
				["kill"] = v_u_1317.success,
				["shot"] = v_u_1317.accent,
				["hit"] = v_u_1317.accent,
				["loot"] = v_u_1317.text,
				["door"] = v_u_1317.text,
				["extract"] = v_u_1317.success
			}
			for v1939, v1940 in v1925.dots do
				local v1941 = (v1940.k == "snap" and true or v1940.k == "tp") and 9 or 5
				v_u_3.new("Frame", {
					["Name"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 3,
					["Name"] = "Dot" .. tostring(v1939) .. "_" .. v1940.k,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v1940.x, v1940.y),
					["Size"] = UDim2.fromOffset(v1941, v1941),
					["BackgroundColor3"] = v1938[v1940.k] or v_u_1317.text2
				}, v_u_1770)
			end
			if v1925.startPt then
				v_u_3.new("Frame", {
					["Name"] = "Start",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 4,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v1925.startPt.x, v1925.startPt.y),
					["Size"] = UDim2.fromOffset(9, 9),
					["BackgroundColor3"] = v_u_1317.success
				}, v_u_1770)
			end
			if v1925.endPt then
				v_u_3.new("Frame", {
					["Name"] = "End",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 4,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v1925.endPt.x, v1925.endPt.y),
					["Size"] = UDim2.fromOffset(9, 9),
					["BackgroundColor3"] = v_u_1317.text
				}, v_u_1770)
			end
			if v1925.barPx > 4 then
				v_u_3.new("Frame", {
					["Name"] = "ScaleBar",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 4,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromOffset(8, v_u_1766 - 8),
					["Size"] = UDim2.fromOffset(v1925.barPx, 2),
					["BackgroundColor3"] = v_u_1317.text
				}, v_u_1770)
				v_u_3.label({
					["parent"] = nil,
					["name"] = "ScaleText",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_1770,
					["text"] = ("%d studs  \194\183  %s  \194\183  north is up"):format(v1925.barStuds, v1925.zoomed and "zoomed to the path" or "the whole map"),
					["color"] = v_u_1317.text2,
					["position"] = UDim2.fromOffset(8, v_u_1766 - 28),
					["size"] = UDim2.fromOffset(v_u_1766 - 16, 16)
				}).ZIndex = 4
			end
		else
			v_u_1770.Visible = false
		end
		v_u_1801(v_u_1771, v_u_4.traceLines(v_u_1477, v_u_1802), "Tr")
		v_u_1801(v_u_1784, v_u_4.liveLines(v_u_1486), "Lv")
		local v1942 = {}
		local v1943 = v_u_1486
		if type(v1943) == "table" then
			local v1944 = v_u_1486.tune
			if type(v1944) == "table" then
				for v1945, v1946 in v_u_1486.tune do
					local v1947 = {
						["name"] = nil,
						["text"] = nil,
						["kind"] = "muted",
						["name"] = "T" .. v1945,
						["text"] = tostring(v1946)
					}
					table.insert(v1942, v1947)
				end
			end
		end
		v_u_1801(v_u_1785, v1942, "Tn")
		v_u_1801(v_u_1786, v_u_4.codeLines(v_u_1486), "Cd")
		local v1948 = v_u_1801
		local v1949 = v_u_1787
		local v1950 = v_u_4.netLines
		local v1951 = v_u_1486
		local v1952
		if type(v1951) == "table" then
			v1952 = v_u_1486.net
		else
			v1952 = nil
		end
		v1948(v1949, v1950(v1952), "Nt")
		if v_u_5 then
			local v1953 = 0
			if v_u_1371 then
				for _, v1954 in v_u_1371.segs do
					if not v1954.fast then
						continue
					end
					v1953 = v1953 + 1
				end
			end
			local v1955 = "default_on"
			local v1956 = v_u_1486
			local v1957
			if type(v1956) == "table" then
				v1957 = v_u_1486.verdict
			else
				v1957 = nil
			end
			local v1958 = v_u_1364
			local v1959, v1960, v1961, v1962, v1963, v1964, v1965, v1966, v1967, v1968, v1969, v1970, v1971, v1972, v1973, v1974, v1975, v1976, v1977, v1978, v1979, v1980, v1981, v1982, v1983, v1984, v1985, v1986, v1987, v1988, v1989, v1990, v1991, v1992, v1993, v1994, v1995, v1996, v1997, v1998, v1999, v2000, v2001
			if type(v1958) == "table" then
				local v2002 = v_u_1364.kick
				if type(v2002) == "table" then
					v1959 = v_u_1364.kick
					v1960 = v1959 ~= nil and (v1959.on == false and "off" or "on") or v1955
					v1961 = v_u_1479
					v1962 = type(v1961) ~= "table" and {} or v_u_4.verdictLines(v_u_1479.verdict, v_u_1802)
					v1963 = "none"
					v1964 = v_u_1479
					if type(v1964) == "table" then
						v1965 = v_u_1479.verdict
						if type(v1965) == "table" then
							v1966 = v_u_1479.verdict.doc
							if type(v1966) == "table" then
								v1967 = v_u_1479.verdict.doc.class
								v1968 = tostring(v1967)
								v1969 = v_u_1479.verdict.doc.action
								v1963 = v1968 .. "/" .. tostring(v1969)
							end
						end
					end
					v1970 = v_u_5
					v1971 = "FilmAc"
					v1972 = "mode=%s|doc=%s|flagged=%d|rows=%d|sel=%s|lines=%d|canact=%d|traces=%d|trace=%s|pts=%d|segs=%d|dots=%d|fast=%d|zoomed=%d|tlines=%d|verdicts=%d|vsrc=%s|vkick=%s|vlook=%d|vclass=%s|ik=%s|ir=%s|ikn=%d"
					v1973 = #v1813
					v1974 = #v1813
					v1975 = v_u_1483
					v1976 = tostring(v1975)
					v1977 = #v_u_4.lookupLines(v_u_1479, v_u_1802)
					v1978 = v1894 and 1 or 0
					v1979 = #v_u_1478
					v1980 = v_u_1477
					if type(v1980) == "table" then
						v1981 = v_u_1477.key
						v1982 = tostring(v1981)
					else
						v1982 = "none"
					end
					v1983 = v_u_1477
					if type(v1983) == "table" then
						v1984 = v_u_1477.x
						v1985 = type(v1984) == "table" and #v_u_1477.x or 0
					else
						v1985 = 0
					end
					v1986 = v_u_1371 and #v_u_1371.segs or 0
					v1987 = v_u_1371 and #v_u_1371.dots or 0
					v1988 = v_u_1371 and v_u_1371.zoomed and 1 or 0
					v1989 = #v_u_4.traceLines(v_u_1477, v_u_1802)
					v1990 = #v1962
					v1991 = v_u_1486
					if type(v1991) == "table" then
						v1992 = v_u_1486.instant
						v1993 = type(v1992) == "table" and (v_u_1486.instant.kickOn == true and "ON" or "OFF") or "?"
					else
						v1993 = "?"
					end
					v1994 = v_u_1486
					if type(v1994) == "table" then
						v1995 = v_u_1486.instant
						v1996 = type(v1995) == "table" and (v_u_1486.instant.refuseOn == true and "ON" or "OFF") or "?"
					else
						v1996 = "?"
					end
					v1997 = v_u_1486
					if type(v1997) == "table" then
						v1998 = v_u_1486.instant
						if type(v1998) == "table" then
							v1999 = v_u_1486.instant.kicks
							v2000 = type(v1999) == "table" and #v_u_1486.instant.kicks or 0
						else
							v2000 = 0
						end
					else
						v2000 = 0
					end
					v1970:SetAttribute(v1971, v1972:format(v1804, v1807, v1973, v1974, v1976, v1977, v1978, v1979, v1982, v1985, v1986, v1987, v1953, v1988, v1989, v1848, v1867, v1960, v1990, v1963, v1993, v1996, v2000))
				else
					if type(v1957) == "table" then
						v2001 = v1957.kick
						if type(v2001) == "table" then
							v1959 = v1957.kick
						else
							v1959 = nil
						end
					else
						v1959 = nil
					end
					v1960 = v1959 ~= nil and (v1959.on == false and "off" or "on") or v1955
					v1961 = v_u_1479
					v1962 = type(v1961) ~= "table" and {} or v_u_4.verdictLines(v_u_1479.verdict, v_u_1802)
					v1963 = "none"
					v1964 = v_u_1479
					if type(v1964) == "table" then
						v1965 = v_u_1479.verdict
						if type(v1965) == "table" then
							v1966 = v_u_1479.verdict.doc
							if type(v1966) == "table" then
								v1967 = v_u_1479.verdict.doc.class
								v1968 = tostring(v1967)
								v1969 = v_u_1479.verdict.doc.action
								v1963 = v1968 .. "/" .. tostring(v1969)
							end
						end
					end
					v1970 = v_u_5
					v1971 = "FilmAc"
					v1972 = "mode=%s|doc=%s|flagged=%d|rows=%d|sel=%s|lines=%d|canact=%d|traces=%d|trace=%s|pts=%d|segs=%d|dots=%d|fast=%d|zoomed=%d|tlines=%d|verdicts=%d|vsrc=%s|vkick=%s|vlook=%d|vclass=%s|ik=%s|ir=%s|ikn=%d"
					v1973 = #v1813
					v1974 = #v1813
					v1975 = v_u_1483
					v1976 = tostring(v1975)
					v1977 = #v_u_4.lookupLines(v_u_1479, v_u_1802)
					v1978 = v1894 and 1 or 0
					v1979 = #v_u_1478
					v1980 = v_u_1477
					if type(v1980) == "table" then
						v1981 = v_u_1477.key
						v1982 = tostring(v1981)
					else
						v1982 = "none"
					end
					v1983 = v_u_1477
					if type(v1983) == "table" then
						v1984 = v_u_1477.x
						v1985 = type(v1984) == "table" and #v_u_1477.x or 0
					else
						v1985 = 0
					end
					v1986 = v_u_1371 and #v_u_1371.segs or 0
					v1987 = v_u_1371 and #v_u_1371.dots or 0
					v1988 = v_u_1371 and v_u_1371.zoomed and 1 or 0
					v1989 = #v_u_4.traceLines(v_u_1477, v_u_1802)
					v1990 = #v1962
					v1991 = v_u_1486
					if type(v1991) == "table" then
						v1992 = v_u_1486.instant
						v1993 = type(v1992) == "table" and (v_u_1486.instant.kickOn == true and "ON" or "OFF") or "?"
					else
						v1993 = "?"
					end
					v1994 = v_u_1486
					if type(v1994) == "table" then
						v1995 = v_u_1486.instant
						v1996 = type(v1995) == "table" and (v_u_1486.instant.refuseOn == true and "ON" or "OFF") or "?"
					else
						v1996 = "?"
					end
					v1997 = v_u_1486
					if type(v1997) == "table" then
						v1998 = v_u_1486.instant
						if type(v1998) == "table" then
							v1999 = v_u_1486.instant.kicks
							v2000 = type(v1999) == "table" and #v_u_1486.instant.kicks or 0
						else
							v2000 = 0
						end
					else
						v2000 = 0
					end
					v1970:SetAttribute(v1971, v1972:format(v1804, v1807, v1973, v1974, v1976, v1977, v1978, v1979, v1982, v1985, v1986, v1987, v1953, v1988, v1989, v1848, v1867, v1960, v1990, v1963, v1993, v1996, v2000))
				end
			else
				if type(v1957) == "table" then
					v2001 = v1957.kick
					if type(v2001) == "table" then
						v1959 = v1957.kick
					else
						v1959 = nil
					end
				else
					v1959 = nil
				end
				v1960 = v1959 ~= nil and (v1959.on == false and "off" or "on") or v1955
				v1961 = v_u_1479
				v1962 = type(v1961) ~= "table" and {} or v_u_4.verdictLines(v_u_1479.verdict, v_u_1802)
				v1963 = "none"
				v1964 = v_u_1479
				if type(v1964) == "table" then
					v1965 = v_u_1479.verdict
					if type(v1965) == "table" then
						v1966 = v_u_1479.verdict.doc
						if type(v1966) == "table" then
							v1967 = v_u_1479.verdict.doc.class
							v1968 = tostring(v1967)
							v1969 = v_u_1479.verdict.doc.action
							v1963 = v1968 .. "/" .. tostring(v1969)
						end
					end
				end
				v1970 = v_u_5
				v1971 = "FilmAc"
				v1972 = "mode=%s|doc=%s|flagged=%d|rows=%d|sel=%s|lines=%d|canact=%d|traces=%d|trace=%s|pts=%d|segs=%d|dots=%d|fast=%d|zoomed=%d|tlines=%d|verdicts=%d|vsrc=%s|vkick=%s|vlook=%d|vclass=%s|ik=%s|ir=%s|ikn=%d"
				v1973 = #v1813
				v1974 = #v1813
				v1975 = v_u_1483
				v1976 = tostring(v1975)
				v1977 = #v_u_4.lookupLines(v_u_1479, v_u_1802)
				v1978 = v1894 and 1 or 0
				v1979 = #v_u_1478
				v1980 = v_u_1477
				if type(v1980) == "table" then
					v1981 = v_u_1477.key
					v1982 = tostring(v1981)
				else
					v1982 = "none"
				end
				v1983 = v_u_1477
				if type(v1983) == "table" then
					v1984 = v_u_1477.x
					v1985 = type(v1984) == "table" and #v_u_1477.x or 0
				else
					v1985 = 0
				end
				v1986 = v_u_1371 and #v_u_1371.segs or 0
				v1987 = v_u_1371 and #v_u_1371.dots or 0
				v1988 = v_u_1371 and v_u_1371.zoomed and 1 or 0
				v1989 = #v_u_4.traceLines(v_u_1477, v_u_1802)
				v1990 = #v1962
				v1991 = v_u_1486
				if type(v1991) == "table" then
					v1992 = v_u_1486.instant
					v1993 = type(v1992) == "table" and (v_u_1486.instant.kickOn == true and "ON" or "OFF") or "?"
				else
					v1993 = "?"
				end
				v1994 = v_u_1486
				if type(v1994) == "table" then
					v1995 = v_u_1486.instant
					v1996 = type(v1995) == "table" and (v_u_1486.instant.refuseOn == true and "ON" or "OFF") or "?"
				else
					v1996 = "?"
				end
				v1997 = v_u_1486
				if type(v1997) == "table" then
					v1998 = v_u_1486.instant
					if type(v1998) == "table" then
						v1999 = v_u_1486.instant.kicks
						v2000 = type(v1999) == "table" and #v_u_1486.instant.kicks or 0
					else
						v2000 = 0
					end
				else
					v2000 = 0
				end
				v1970:SetAttribute(v1971, v1972:format(v1804, v1807, v1973, v1974, v1976, v1977, v1978, v1979, v1982, v1985, v1986, v1987, v1953, v1988, v1989, v1848, v1867, v1960, v1990, v1963, v1993, v1996, v2000))
			end
		end
	end
	v_u_1373()
	local v2003, v2004 = pcall(function()
		return require((script.Parent:WaitForChild("FilmWave", 5)))
	end)
	if v2003 and v2004 then
		local v2005 = v2004.mount
		local v2006, v2007 = pcall(v2005, p_u_1311, p_u_1312, p_u_1313, v_u_1315)
		if not v2006 then
			warn("[FilmAC] ban wave block failed:", v2007)
		end
	end
	if v_u_2:IsStudio() and v_u_5 then
		local v_u_2034 = v_u_5:GetAttributeChangedSignal("FilmAcCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_1485, (copy) v_u_1363, (copy) v_u_1418, (copy) v_u_1732, (copy) v_u_1751, (ref) v_u_1483, (ref) v_u_1481, (ref) v_u_1479, (ref) v_u_1489, (copy) p_u_1312, (ref) v_u_3, (ref) v_u_1360, (copy) v_u_1317, (ref) v_u_1322, (ref) v_u_1487, (ref) v_u_1486, (ref) v_u_1373, (ref) v_u_1476, (ref) v_u_1480, (ref) v_u_1478, (ref) v_u_1451, (ref) v_u_1471, (ref) v_u_1559, (copy) v_u_1366, (copy) v_u_1614, (ref) v_u_1364
			local v2008 = v_u_5:GetAttribute("FilmAcCmd")
			if type(v2008) == "string" and v2008 ~= "" then
				v_u_5:SetAttribute("FilmAcCmd", nil)
				local v2009, v2010 = string.match(v2008, "^(%a+)%s*(.*)$")
				if v2009 == "refresh" then
					v_u_1485()
					return
				elseif v2009 == "mode" and v_u_1363[v2010] then
					v_u_1363[v2010].press()
					return
				elseif v2009 == "lookup" then
					v_u_1418(v2010)
					return
				elseif v2009 == "review" then
					v_u_1732()
					return
				elseif v2009 == "clear" then
					v_u_1751(false)
				elseif v2009 == "confirmclear" then
					if not v_u_1483 then
						return
					end
					os.clock()
					v_u_1481 = false
					local v_u_2011 = {
						["cmd"] = "clear",
						["userId"] = nil,
						["userId"] = v_u_1483
					}
					local function v_u_2015(p2012)
						-- upvalues: (ref) v_u_1479
						if p2012.ok then
							local v2013 = p2012.data
							if type(v2013) == "table" then
								local v2014 = p2012.data.record
								if type(v2014) == "table" and v_u_1479 then
									v_u_1479.record = p2012.data.record
								end
							end
						end
					end
					if not v_u_1489 then
						local v2016 = p_u_1312
						if type(v2016) == "function" then
							v_u_1489 = true
							v_u_3.setText(v_u_1360, "Working ...")
							v_u_1360.TextColor3 = v_u_1317.text2
							local v_u_2017 = "clear"
							local v_u_2018 = false
							p_u_1312("server.ac", v_u_2011, function(p2019) -- name: done
								-- upvalues: (ref) v_u_1489, (ref) v_u_1322, (ref) v_u_1487, (copy) v_u_2017, (ref) v_u_1486, (copy) v_u_2011, (ref) v_u_1485, (copy) v_u_2015, (copy) v_u_2018, (ref) v_u_3, (ref) v_u_1360, (ref) v_u_1317, (ref) v_u_1373
								v_u_1489 = false
								if not v_u_1322 then
									return
								end
								v_u_1487 = os.clock()
								if type(p2019) == "table" then
									local v2020, v2021, v2022, v2023, v2024
									if v_u_2017 == "status" and p2019.ok then
										local v2025 = p2019.data
										if type(v2025) == "table" then
											v_u_1486 = p2019.data
											if v_u_2015 then
												v_u_2015(p2019)
											end
											if not v_u_2018 then
												v2020 = p2019.msg or (p2019.ok and "Done." or "Refused.")
												v2021 = tostring(v2020)
												v2022 = p2019.ok ~= true
												v_u_3.setText(v_u_1360, v2021)
												v2023 = v_u_1360
												if v2022 then
													v2024 = v_u_1317.danger
												else
													v2024 = v_u_1317.text2
												end
												v2023.TextColor3 = v2024
											end
											v_u_1373()
										else
											if v_u_2011.cmd == "mode" and p2019.ok then
												task.defer(v_u_1485)
											end
											if v_u_2015 then
												v_u_2015(p2019)
											end
											if not v_u_2018 then
												v2020 = p2019.msg or (p2019.ok and "Done." or "Refused.")
												v2021 = tostring(v2020)
												v2022 = p2019.ok ~= true
												v_u_3.setText(v_u_1360, v2021)
												v2023 = v_u_1360
												if v2022 then
													v2024 = v_u_1317.danger
												else
													v2024 = v_u_1317.text2
												end
												v2023.TextColor3 = v2024
											end
											v_u_1373()
										end
									else
										if v_u_2011.cmd == "mode" and p2019.ok then
											task.defer(v_u_1485)
										end
										if v_u_2015 then
											v_u_2015(p2019)
										end
										if not v_u_2018 then
											v2020 = p2019.msg or (p2019.ok and "Done." or "Refused.")
											v2021 = tostring(v2020)
											v2022 = p2019.ok ~= true
											v_u_3.setText(v_u_1360, v2021)
											v2023 = v_u_1360
											if v2022 then
												v2024 = v_u_1317.danger
											else
												v2024 = v_u_1317.text2
											end
											v2023.TextColor3 = v2024
										end
										v_u_1373()
										return
									end
								else
									if not v_u_2018 then
										v_u_3.setText(v_u_1360, "The server did not answer.")
										v_u_1360.TextColor3 = v_u_1317.danger
									end
									v_u_1373()
									return
								end
							end)
						end
					end
				elseif v2009 == "traces" then
					if v_u_1476 then
						v_u_1480(v_u_1476)
						return
					end
				else
					if v2009 == "trace" then
						local v2026 = tonumber(v2010)
						if v2026 and v_u_1478[v2026] then
							v2010 = v_u_1478[v2026].key
						end
						v_u_1451(v2010)
						return
					end
					if v2009 == "watch" then
						v_u_1471(v2010)
						return
					end
					if v2009 == "verdicts" then
						v_u_1559(true)
						return
					end
					if v2009 == "modkick" and (v2010 == "on" or v2010 == "off") and v_u_1366[v2010] then
						v_u_1366[v2010].press()
						return
					end
					if v2009 == "instant" then
						local v2027 = string.gsub(v2010, "%s+", "")
						if v_u_1614[v2027] then
							v_u_1614[v2027].press()
							return
						end
					elseif v2009 == "vrow" then
						local v2028 = tonumber(v2010)
						local v2029 = v_u_1364
						local v2030
						if type(v2029) == "table" then
							local v2031 = v_u_1364.list
							if type(v2031) == "table" then
								v2030 = v_u_1364.list.rows
							else
								v2030 = nil
							end
						else
							v2030 = nil
						end
						if v2028 and (type(v2030) == "table" and v2030[v2028]) then
							local v2032 = v_u_1418
							local v2033 = v2030[v2028].uid
							v2032((tostring(v2033)))
						end
					end
				end
			else
				return
			end
		end)
		if v_u_1320 then
			v_u_1320.Destroying:Connect(function()
				-- upvalues: (copy) v_u_2034
				v_u_2034:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_1322, (copy) v_u_1320, (copy) p_u_1311, (ref) v_u_1489, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1365, (ref) v_u_1486, (ref) v_u_1559
		local v2035 = false
		while v_u_1322 do
			local v2036 = v_u_1320 == nil or v_u_1320.Enabled
			if v2036 then
				v2036 = p_u_1311.Visible
			end
			if v2036 and (not v_u_1489 and (not v2035 or os.clock() - v_u_1487 >= 5)) then
				v_u_1487 = os.clock()
				v_u_1485()
			elseif v2036 and (not v_u_1489 and (not v_u_1365 and v_u_1486 ~= nil)) then
				v_u_1559(false)
			end
			task.wait(0.5)
			v2035 = v2036
		end
	end)
	return {
		["refresh"] = v_u_1485,
		["paint"] = function(p2037) -- name: paint
			-- upvalues: (ref) v_u_1486, (ref) v_u_1373
			v_u_1486 = p2037
			v_u_1373()
		end
	}
end
return v_u_4