-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / GearVisibility

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = {
	["name"] = "GearVisibility",
	["order"] = 70
}
local v_u_4 = { "BackWeapon", "BackWeapon2" }
local v_u_5 = v_u_1.LocalPlayer
local v_u_6 = 0
local v_u_12 = {
	["classifyChild"] = function(p7, _, _, _) -- name: classifyChild
		return (p7 == "WornPack" or (p7 == "HushWornGear" or p7 == "HushWornArmor")) and "model" or nil
	end,
	["wantHidden"] = function(p8, p9, p10) -- name: wantHidden
		if not p8 then
			p9 = p10
		end
		return p9 == true
	end,
	["isHideTarget"] = function(p11) -- name: isHideTarget
		return p11:IsA("BasePart") or p11:IsA("Decal")
	end
}
local v_u_13 = false
local v_u_14 = 0
local function v_u_19() -- name: R
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_2, (copy) v_u_12
	if not v_u_13 and v_u_14 <= os.clock() then
		local function v16()
			-- upvalues: (ref) v_u_2
			local v15 = v_u_2:FindFirstChild("Hush")
			if v15 then
				v15 = v15:FindFirstChild("Shared")
			end
			if v15 then
				v15 = v15:FindFirstChild("GearRules")
			end
			if v15 then
				return require(v15)
			else
				return nil
			end
		end
		local v17, v18 = pcall(v16)
		if v17 and type(v18) == "table" then
			v_u_13 = v18
		else
			v_u_14 = os.clock() + 5
		end
	end
	if v_u_13 then
		return v_u_13
	else
		return v_u_12
	end
end
local function v_u_22(p20, p21) -- name: setOne
	if p21 then
		if p20.LocalTransparencyModifier < 1 then
			p20.LocalTransparencyModifier = 1
		end
		if p20:GetAttribute("HushGearHidden") ~= true then
			p20:SetAttribute("HushGearHidden", true)
			return
		end
	elseif p20:GetAttribute("HushGearHidden") == true then
		p20.LocalTransparencyModifier = 0
		p20:SetAttribute("HushGearHidden", nil)
	end
end
local function v_u_27(p23, p24) -- name: setHidden
	-- upvalues: (copy) v_u_19, (copy) v_u_22
	local v25 = v_u_19()
	for _, v26 in p23:GetDescendants() do
		if not v25.isHideTarget(v26) then
			continue
		end
		v_u_22(v26, p24)
	end
end
v3.setHidden = v_u_27
local v_u_28 = nil
local v_u_29 = nil
local function v_u_34(p30) -- name: attachmentNames
	local v31 = {}
	if p30 then
		for _, v32 in p30:GetChildren() do
			if not v32:IsA("Attachment") then
				continue
			end
			local v33 = v32.Name
			table.insert(v31, v33)
		end
	end
	return v31
end
local function v_u_40(p_u_35) -- name: classify
	-- upvalues: (copy) v_u_34, (copy) v_u_19
	local v36 = p_u_35:IsA("Accessory")
	local v37, v38
	if v36 then
		local v39
		v39, v37 = pcall(function()
			-- upvalues: (copy) p_u_35
			return p_u_35.AccessoryType.Name
		end)
		if not v39 then
			v37 = nil
		end
		v38 = v_u_34(p_u_35:FindFirstChild("Handle"))
	else
		v37 = nil
		v38 = {}
	end
	return v_u_19().classifyChild(p_u_35.Name, v36, v37, v38)
end
function v3.syncBack(p41, p42) -- name: syncBack
	-- upvalues: (copy) v_u_40, (copy) v_u_27
	local v43 = 0
	for _, v44 in p41:GetChildren() do
		if not v44:IsA("Accessory") or v_u_40(v44) ~= "backAccessory" then
			continue
		end
		v_u_27(v44, p42)
		v43 = v43 + 1
	end
	return v43
end
local function v_u_58(p45, p46, p47) -- name: seatLane
	-- upvalues: (ref) v_u_29, (copy) v_u_2
	local v48 = p45:FindFirstChild(p46)
	local v49 = v48 and v48:IsA("Model")
	if v49 then
		v49 = v48.PrimaryPart
	end
	if v49 then
		v49 = v49:FindFirstChild("BackWeld")
	end
	if v49 and v49:IsA("Weld") then
		local v50 = v49:GetAttribute("FitBase")
		local v51 = v49:GetAttribute(p47 and "LiftBare" or "LiftFull")
		local v52 = v49:GetAttribute("FitX")
		local v53 = v49:GetAttribute("FitY")
		if typeof(v50) == "CFrame" and (type(v51) == "number" and (type(v52) == "number" and type(v53) == "number")) then
			if v_u_29 == nil then
				local function v54()
					-- upvalues: (ref) v_u_2
					return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("BackFit"))
				end
				local v55, v56 = pcall(v54)
				if not v55 then
					v56 = false
				end
				v_u_29 = v56
			end
			if v_u_29 then
				local v57 = v_u_29.weldC0(v50, v52, v53, v51)
				if (v49.C0.Position - v57.Position).Magnitude > 0.001 then
					v49.C0 = v57
				end
			end
		end
	else
		return
	end
end
local v_u_59 = {}
local v_u_60 = {}
local function v_u_64(p61) -- name: gearRoots
	-- upvalues: (copy) v_u_40
	local v62 = {}
	for _, v63 in p61:GetChildren() do
		if v_u_40(v63) == nil then
			continue
		end
		table.insert(v62, v63)
	end
	return v62
end
local function v_u_69(p65, p66) -- name: onAdded
	-- upvalues: (copy) v_u_19, (copy) v_u_40
	p65.dirty = true
	if p65.hide == true and v_u_19().isHideTarget(p66) then
		local v67 = p66
		while p66.Parent ~= nil and p66.Parent ~= p65.char do
			p66 = p66.Parent
		end
		if p66.Parent == p65.char and v_u_40(p66) ~= nil then
			if v67.LocalTransparencyModifier < 1 then
				v67.LocalTransparencyModifier = 1
			end
			if v67:GetAttribute("HushGearHidden") ~= true then
				v67:SetAttribute("HushGearHidden", true)
			end
			local v68 = p65.list
			table.insert(v68, v67)
		end
	end
end
local function v_u_73(p70) -- name: watch
	-- upvalues: (copy) v_u_69
	local v_u_71 = {
		["char"] = nil,
		["conn"] = nil,
		["dirty"] = true,
		["hide"] = nil,
		["list"] = nil,
		["char"] = p70,
		["list"] = {}
	}
	v_u_71.conn = p70.DescendantAdded:Connect(function(p72)
		-- upvalues: (ref) v_u_69, (copy) v_u_71
		v_u_69(v_u_71, p72)
	end)
	return v_u_71
end
local function v_u_90(p74, p75) -- name: refresh
	-- upvalues: (copy) v_u_19, (copy) v_u_64, (copy) v_u_22, (copy) v_u_4, (copy) v_u_58, (ref) v_u_28, (copy) v_u_2
	local v76 = p74.char
	if not p75 and p74.hide ~= false then
		local v77 = v_u_19()
		for _, v78 in v76:GetDescendants() do
			if v78:GetAttribute("HushGearHidden") ~= true or (not v77.isHideTarget(v78) or v78:GetAttribute("HushGearHidden") ~= true) then
				continue
			end
			v78.LocalTransparencyModifier = 0
			v78:SetAttribute("HushGearHidden", nil)
		end
	end
	local v79 = v_u_19()
	local v80 = {}
	for _, v81 in v_u_64(v76) do
		for _, v82 in v81:GetDescendants() do
			if not v79.isHideTarget(v82) then
				continue
			end
			v_u_22(v82, p75)
			if not p75 then
				continue
			end
			table.insert(v80, v82)
		end
	end
	p74.list = v80
	p74.hide = p75
	p74.dirty = false
	for _, v83 in v_u_4 do
		v_u_58(v76, v83, p75)
	end
	if v_u_28 == nil then
		local function v84()
			-- upvalues: (ref) v_u_2
			return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("WornArmor"))
		end
		local v85, v86 = pcall(v84)
		if not v85 then
			v86 = false
		end
		v_u_28 = v86
	end
	if v_u_28 then
		local v87 = v76:FindFirstChild("HushWornArmor")
		local v88 = v_u_28.syncHeadwear
		local v89
		if v87 == nil or v87:GetAttribute("HidesHeadwear") ~= true then
			v89 = false
		else
			v89 = not p75
		end
		v88(v76, v89)
	end
end
function v3.init(_) -- name: init end
function v3.start() -- name: start end
function v3.step(p91) -- name: step
	-- upvalues: (ref) v_u_6, (copy) v_u_19, (copy) v_u_5, (copy) v_u_1, (copy) v_u_59, (copy) v_u_73, (copy) v_u_90, (copy) v_u_60
	v_u_6 = v_u_6 + p91
	local v92
	if v_u_6 >= 0.5 then
		v_u_6 = 0
		v92 = true
	else
		v92 = false
	end
	local v93 = v_u_19()
	local v94 = v_u_5:GetAttribute("HideMyGear") == true
	local v95 = v_u_5:GetAttribute("HideOthersGear") == true
	local v96 = {}
	for _, v97 in v_u_1:GetPlayers() do
		local v98 = v97.Character
		if not v98 then
			continue
		end
		v96[v97] = true
		local v99 = v_u_59[v97]
		if v99 == nil or v99.char ~= v98 then
			if v99 then
				v99.conn:Disconnect()
			end
			v99 = v_u_73(v98)
			v_u_59[v97] = v99
		end
		local v100 = v93.wantHidden(v97 == v_u_5, v94, v95)
		if v92 or (v99.dirty or v99.hide ~= v100) then
			local v101 = v_u_90
			local v102, v103 = pcall(v101, v99, v100)
			if v102 then
				continue
			end
			v99.dirty = false
			local v104 = tostring(v103)
			if v_u_60[v104] then
				continue
			end
			v_u_60[v104] = true
			warn("[GearVisibility] refresh failed:", v104)
		else
			if not v100 then
				continue
			end
			for _, v105 in v99.list do
				if v105.Parent == nil or v105.LocalTransparencyModifier >= 1 then
					continue
				end
				v105.LocalTransparencyModifier = 1
			end
		end
	end
	for v106, v107 in v_u_59 do
		if v96[v106] then
			continue
		end
		v107.conn:Disconnect()
		v_u_59[v106] = nil
	end
end
return v3