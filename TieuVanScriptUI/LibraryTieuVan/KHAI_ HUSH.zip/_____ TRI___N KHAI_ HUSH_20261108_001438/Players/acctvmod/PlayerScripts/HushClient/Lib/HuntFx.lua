-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntFx

local v_u_1 = game:GetService("Players")
local v_u_89 = {
	["NEAR"] = 12,
	["FAR"] = 90,
	["LAMP_RED"] = Color3.fromRGB(255, 72, 56),
	["MARK_VIS"] = 0.25,
	["closeness"] = function(p2) -- name: closeness
		-- upvalues: (copy) v_u_89
		if p2 ~= p2 then
			return 0
		end
		local v3 = (v_u_89.FAR - p2) / (v_u_89.FAR - v_u_89.NEAR)
		return math.clamp(v3, 0, 1)
	end,
	["heartbeatVolume"] = function(p4) -- name: heartbeatVolume
		return math.clamp(p4, 0, 1) * 0.5 + 0.12
	end,
	["arrowRotation"] = function(p5) -- name: arrowRotation
		local v6 = p5.X
		local v7 = -p5.Y
		local v8 = math.atan2(v6, v7)
		return math.deg(v8)
	end,
	["new"] = function(p_u_9) -- name: new
		-- upvalues: (copy) v_u_1, (copy) v_u_89
		local v_u_10 = p_u_9.UI
		local v_u_11 = p_u_9.Theme
		local v_u_12 = p_u_9.Names
		local v_u_13 = v_u_11.color
		local v_u_14 = {}
		local v_u_15 = nil
		local v_u_16 = 0
		local v_u_17 = 0
		local v_u_18 = {}
		local v_u_19 = {}
		local v_u_20 = 0
		local v_u_21 = 0
		local v_u_22 = v_u_10.new("Frame", {
			["Name"] = "HuntPulse",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(60, 60)
		}, p_u_9.root)
		local v_u_23 = v_u_10.icon("chevronUp", {
			["parent"] = nil,
			["size"] = 60,
			["color"] = nil,
			["thickness"] = 6,
			["parent"] = v_u_22,
			["color"] = v_u_13.danger
		})
		function v_u_14.pulse(p24, p25) -- name: pulse
			-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (copy) p_u_9, (ref) v_u_1, (ref) v_u_89
			if typeof(p24) == "Vector3" then
				local v26 = (type(p25) ~= "number" or p25 ~= p25) and 3 or math.clamp(p25, 0.5, 8)
				v_u_15 = p24
				v_u_17 = os.clock()
				v_u_16 = os.clock() + v26
				local v_u_27 = "Audio"
				local function v28()
					-- upvalues: (ref) p_u_9, (copy) v_u_27
					return p_u_9.cctx.controllers[v_u_27]
				end
				local v29, v30 = pcall(v28)
				if not v29 then
					v30 = nil
				end
				if v30 and v30.play then
					local v31 = v30.play
					pcall(v31, "ev_sting_alert")
				end
				local v32 = v_u_1.LocalPlayer.Character
				if v32 then
					v32 = v32:FindFirstChild("HumanoidRootPart")
				end
				if v32 and (v30 and v30.heartbeatBoost) then
					local v33 = v_u_89.closeness((v32.Position - p24).Magnitude)
					local v34 = v30.heartbeatBoost
					local v35 = v_u_89.heartbeatVolume(v33)
					pcall(v34, v35, v26)
				end
			end
		end
		local function v_u_41(p36, p37) -- name: markFor
			-- upvalues: (copy) v_u_18, (ref) v_u_89, (copy) v_u_12, (ref) v_u_1
			local v38 = v_u_18[p36]
			local v39 = p37:FindFirstChild("Head")
			if not v39 then
				return nil
			end
			if v38 == nil or (v38.Parent == nil or v38.Adornee ~= v39) then
				if v38 then
					v38:Destroy()
				end
				v38 = Instance.new("BillboardGui")
				v38.Name = "HuntStalkerMark"
				v38.Adornee = v39
				v38.AlwaysOnTop = false
				v38.Size = UDim2.fromOffset(86, 20)
				v38.StudsOffset = Vector3.new(0, 2.4, 0)
				v38.MaxDistance = (1 / 0)
				v38.LightInfluence = 0
				v38.ResetOnSpawn = false
				local v40 = Instance.new("TextLabel")
				v40.Name = "Text"
				v40.BackgroundColor3 = Color3.fromRGB(30, 8, 8)
				v40.BackgroundTransparency = 0.25
				v40.BorderSizePixel = 0
				v40.Size = UDim2.fromScale(1, 1)
				v40.Font = Enum.Font.GothamBold
				v40.TextScaled = true
				v40.TextColor3 = v_u_89.LAMP_RED
				v40.Text = v_u_12.HUD.stalkerMark
				v40.Parent = v38
				v38.Parent = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
				v_u_18[p36] = v38
			end
			return v38
		end
		local function v_u_45(p42, p43) -- name: tint
			-- upvalues: (copy) v_u_19, (ref) v_u_89
			for _, v44 in p42:GetDescendants() do
				if not v44:IsA("SpotLight") or v44.Name ~= "HushFlashlight" then
					continue
				end
				if p43 then
					if v_u_19[v44] == nil then
						v_u_19[v44] = v44.Color
					end
					v44.Color = v_u_89.LAMP_RED
				else
					if v_u_19[v44] == nil then
						continue
					end
					v44.Color = v_u_19[v44]
					v_u_19[v44] = nil
				end
			end
		end
		function v_u_14.clear() -- name: clear
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) v_u_22, (copy) v_u_18, (copy) v_u_19
			v_u_15 = nil
			v_u_16 = 0
			v_u_22.Visible = false
			for v46 in v_u_18 do
				local v47 = v_u_18[v46]
				if not v47 then
					continue
				end
				v47:Destroy()
				v_u_18[v46] = nil
			end
			for v48, v49 in v_u_19 do
				if not v48.Parent then
					continue
				end
				v48.Color = v49
			end
			table.clear(v_u_19)
		end
		function v_u_14.marks() -- name: marks
			-- upvalues: (copy) v_u_18
			local v50 = 0
			for _ in v_u_18 do
				v50 = v50 + 1
			end
			return v50
		end
		function v_u_14.arrowShown() -- name: arrowShown
			-- upvalues: (copy) v_u_22
			return v_u_22.Visible
		end
		function v_u_14.step(p51) -- name: step
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) v_u_11, (copy) p_u_9, (copy) v_u_10, (copy) v_u_22, (ref) v_u_89, (ref) v_u_17, (copy) v_u_23, (copy) v_u_13, (ref) v_u_20, (ref) v_u_21, (ref) v_u_1, (copy) v_u_18, (copy) v_u_19, (copy) v_u_45, (copy) v_u_14, (copy) v_u_41
			local v52 = os.clock()
			if v_u_15 == nil or v52 >= v_u_16 then
				if v_u_22.Visible then
					v_u_22.Visible = false
				end
			else
				local v53 = v_u_11.refSize()
				local v54 = not p_u_9.safe and {
					["l"] = 0,
					["t"] = 0,
					["r"] = 0,
					["b"] = 0
				} or p_u_9.safe()
				local v55 = v54.l + 36
				local v56 = v_u_10.topInset() + 90
				local v57 = v53.X - v54.r - 36
				local v58 = v53.Y - v54.b - 120
				local v59, v60 = v_u_10.screenMarker(v_u_15, v55, v56, v57, v58, true)
				v_u_22.Position = UDim2.fromOffset(v59.X, v59.Y)
				v_u_22.Rotation = v_u_89.arrowRotation(v60)
				v_u_22.Visible = true
				local v61 = v52 - v_u_17
				local v62 = v_u_16 - v_u_17
				local v63 = v61 / math.max(0.1, v62)
				local v64 = v_u_10.setIconColor
				local v65 = v_u_23
				local v66 = v_u_13.danger
				local v67 = v_u_13.text
				local v68 = v52 * 9
				v64(v65, v66:Lerp(v67, (math.sin(v68) * 0.5 + 0.5) * 0.5))
				v_u_22.Visible = v63 < 1
			end
			v_u_20 = v_u_20 + p51
			if v_u_20 >= 0.1 then
				v_u_20 = 0
				v_u_21 = v_u_21 + 0.1
				local v69 = v_u_1.LocalPlayer
				local v_u_70 = "Vision"
				local function v71()
					-- upvalues: (ref) p_u_9, (copy) v_u_70
					return p_u_9.cctx.controllers[v_u_70]
				end
				local v72, v73 = pcall(v71)
				if not v72 then
					v73 = nil
				end
				for _, v74 in v_u_1:GetPlayers() do
					local v75 = v74.Character
					local v76 = v74:GetAttribute("HuntTeam") == "K"
					if v75 == nil or not v76 then
						local v77 = v_u_18[v74]
						if v77 then
							v77:Destroy()
							v_u_18[v74] = nil
						end
						if v75 == nil or next(v_u_19) == nil then
							continue
						end
						v_u_45(v75, false)
					else
						if v_u_21 >= 1 then
							v_u_45(v75, true)
						end
						if v74 == v69 and v_u_14.selfMarks ~= true then
							local v78 = v_u_18[v74]
							if not v78 then
								continue
							end
							v78:Destroy()
							v_u_18[v74] = nil
						else
							local v79 = v75:FindFirstChild("HumanoidRootPart")
							local v80 = v_u_41(v74, v75)
							if not (v80 and v79) then
								continue
							end
							local v81 = 1
							local v82
							if v73 and v73.visibility then
								local v83 = v73.visibility
								local v84 = v79.Position
								local v85
								v85, v82 = pcall(v83, v84)
								if v85 then
									if type(v82) ~= "number" then
										v82 = v81
									end
								else
									v82 = v81
								end
							else
								v82 = v81
							end
							local v86
							if v_u_89.MARK_VIS < v82 then
								v86 = v75:GetAttribute("Dead") ~= true
							else
								v86 = false
							end
							v80.Enabled = v86
						end
					end
				end
				for v87 in v_u_18 do
					if v87.Parent == v_u_1 then
						continue
					end
					local v88 = v_u_18[v87]
					if not v88 then
						continue
					end
					v88:Destroy()
					v_u_18[v87] = nil
				end
				if v_u_21 >= 1 then
					v_u_21 = 0
				end
			end
		end
		return v_u_14
	end
}
return v_u_89