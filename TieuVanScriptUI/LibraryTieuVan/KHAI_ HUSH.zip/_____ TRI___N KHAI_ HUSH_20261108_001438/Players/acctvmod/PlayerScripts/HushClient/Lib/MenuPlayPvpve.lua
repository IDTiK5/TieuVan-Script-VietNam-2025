-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayPvpve

local v_u_1 = {
	["HARD_CARD"] = {
		["id"] = "Hard",
		["line"] = "The only difficulty here",
		["sub"] = "The only difficulty here. Fewer infected than a normal Hard raid, because other squads are the real threat.",
		["tags"] = nil,
		["tags"] = {
			"Fewer infected",
			"More runners",
			"Scratches infect",
			"Boss active",
			"More ammo at dusk and night"
		}
	},
	["INFECTED_VALUE"] = "Hard, thinned out",
	["INFECTED_FACT"] = "Fewer infected",
	["SUB_FROM"] = "More of them, and faster.",
	["SUB_TO"] = "The only difficulty here. Fewer infected than a normal Hard raid, because other squads are the real threat.",
	["WAIT_TITLE"] = "Looking for your region",
	["WAIT_LINE"] = "Searching again until other squads are found"
}
local v_u_2 = nil
local function v_u_7(p3) -- name: liveRule
	-- upvalues: (ref) v_u_2
	if v_u_2 == nil then
		local v5, v6 = pcall(function()
			local v4 = game:GetService("ReplicatedStorage")
			return require((v4:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
		end)
		if not v5 or type(v6) ~= "table" then
			v6 = false
		end
		v_u_2 = v6
	end
	if v_u_2 then
		return v_u_2.rule(p3)
	else
		return nil
	end
end
function v_u_1.hardOnly(p8) -- name: hardOnly
	-- upvalues: (copy) v_u_7
	local v9 = p8 or v_u_7
	local v10, v11 = pcall(v9, "hardOnly")
	if v10 then
		v10 = v11 == true
	end
	return v10
end
function v_u_1.publicOnly(p12) -- name: publicOnly
	-- upvalues: (copy) v_u_7
	local v13 = p12 or v_u_7
	local v14, v15 = pcall(v13, "privateRaids")
	if v14 then
		v14 = v15 == false
	end
	return v14
end
function v_u_1.diffs(p16, p17) -- name: diffs
	-- upvalues: (copy) v_u_1
	if not v_u_1.hardOnly(p17) or type(p16) ~= "table" then
		return p16
	end
	local v18 = {}
	for _, v19 in p16 do
		if v19.id ~= "Hard" then
			continue
		end
		local v20 = table.clone(v19)
		v20.line = v_u_1.HARD_CARD.line
		v20.sub = v_u_1.HARD_CARD.sub
		v20.tags = table.clone(v_u_1.HARD_CARD.tags)
		table.insert(v18, v20)
	end
	if #v18 == 0 then
		local v21 = table.clone
		local v22 = v_u_1.HARD_CARD
		table.insert(v18, v21(v22))
	end
	return v18
end
function v_u_1.cardWidth(p23, p24) -- name: cardWidth
	-- upvalues: (copy) v_u_1
	if v_u_1.hardOnly(p24) and p23 == 1 then
		return 1, 0
	else
		return 0.3333333333333333, -5.333333333333333
	end
end
function v_u_1.facts(p25, p26) -- name: facts
	-- upvalues: (copy) v_u_1
	if not v_u_1.hardOnly(p26) or type(p25) ~= "table" then
		return p25
	end
	local v27 = table.clone(p25)
	local v28 = p25.lines
	if type(v28) == "table" then
		local v29 = {}
		for _, v30 in p25.lines do
			if type(v30) == "table" and v30.label == "Infected" then
				local v31 = table.clone(v30)
				v31.value = v_u_1.INFECTED_VALUE
				table.insert(v29, v31)
			else
				table.insert(v29, v30)
			end
		end
		v27.lines = v29
	end
	local v32 = p25.facts
	if type(v32) == "string" then
		v27.facts = string.gsub(p25.facts, "%+%d+%% infected", v_u_1.INFECTED_FACT)
	end
	local v33 = p25.sub
	if type(v33) == "string" then
		local v34, v35 = string.find(p25.sub, v_u_1.SUB_FROM, 1, true)
		if v34 and v35 then
			local v36 = p25.sub
			local v37 = v34 - 1
			local v38 = string.sub(v36, 1, v37)
			local v39 = v_u_1.SUB_TO
			local v40 = p25.sub
			local v41 = v35 + 1
			v27.sub = v38 .. v39 .. string.sub(v40, v41)
		end
	end
	return v27
end
function v_u_1.waitTitle() -- name: waitTitle
	-- upvalues: (copy) v_u_1
	return v_u_1.WAIT_TITLE
end
function v_u_1.waitLine() -- name: waitLine
	-- upvalues: (copy) v_u_1
	return v_u_1.WAIT_LINE
end
function v_u_1.squadFilter(p42, p43) -- name: squadFilter
	-- upvalues: (copy) v_u_1
	return v_u_1.hardOnly(p43) and type(p42) == "table" and { "Any", "Hard" } or p42
end
function v_u_1.leaderTabs(p44, p45) -- name: leaderTabs
	-- upvalues: (copy) v_u_1
	if not v_u_1.hardOnly(p45) or type(p44) ~= "table" then
		return p44
	end
	local v46 = {}
	for _, v47 in p44 do
		if v47.id ~= "All" and v47.id ~= "Hard" then
			continue
		end
		table.insert(v46, v47)
	end
	return v46
end
return v_u_1