-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / FpView

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	["name"] = "FpView",
	["order"] = 13
}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = {}
local v_u_8 = false
local v_u_9 = false
local v_u_10 = nil
local v_u_11 = {
	["viewMode"] = "classic",
	["place"] = "",
	["hasChar"] = false,
	["scripted"] = false,
	["spectating"] = false
}
local v_u_12 = {}
local v_u_13 = false
local v_u_14 = {
	"FpCam",
	"FpAim",
	"FpTouch",
	"Viewmodel",
	"ScopeView",
	"TakedownClient"
}
local v_u_15 = {
	"FpCam",
	"FpTouch",
	"Viewmodel",
	"TakedownClient"
}
local function v_u_20(p_u_16) -- name: lib
	-- upvalues: (copy) v_u_7, (ref) v_u_5
	local v17 = v_u_7[p_u_16]
	if v17 == nil then
		local function v18()
			-- upvalues: (ref) v_u_5, (copy) p_u_16
			return v_u_5.lib[p_u_16]
		end
		local v19
		v19, v17 = pcall(v18)
		if not v19 or type(v17) ~= "table" then
			warn("[FpView] module " .. p_u_16 .. " did not load: " .. tostring(v17))
			v17 = false
		end
		v_u_7[p_u_16] = v17
	end
	return v17 or nil
end
local function v_u_32() -- name: readFacts
	-- upvalues: (copy) v_u_4, (ref) v_u_10, (copy) v_u_11, (ref) v_u_5
	local v21 = v_u_4:GetAttribute("ViewMode")
	v_u_11.viewMode = (v_u_10 == "on" and "fptp" or (v_u_10 == "off" and "classic" or v21)) == "fptp" and "fptp" or "classic"
	local v22 = v_u_4:GetAttribute("Place")
	v_u_11.place = type(v22) ~= "string" and "" or v22
	local v23 = v_u_4.Character
	local v24 = v_u_11
	local v25
	if v23 == nil or v23.Parent == nil then
		v25 = false
	else
		v25 = v23:FindFirstChild("HumanoidRootPart") ~= nil
	end
	v24.hasChar = v25
	local v26 = v_u_5 and v_u_5.controllers
	if v26 then
		v26 = v_u_5.controllers.Camera
	end
	local v27 = false
	local v28 = false
	if v26 then
		local v29 = v26.mode
		if type(v29) == "function" then
			local v30 = v26.mode
			local v31
			v28, v31 = pcall(v30)
			if v28 then
				v27 = v31 == "scripted"
			else
				v27 = v28
			end
			if v28 then
				v28 = v31 == "spectate"
			end
		end
	end
	v_u_11.scripted = v27
	v_u_11.spectating = v28
end
local function v_u_46(p33, p34) -- name: apply
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_14, (copy) v_u_20, (ref) v_u_5, (copy) v_u_12
	v_u_8 = p33
	local v35 = not p33
	if v35 then
		v35 = p34 == true
	end
	v_u_9 = v35
	for _, v36 in v_u_14 do
		local v37 = v_u_20(v36)
		if not v37 then
			continue
		end
		local v38 = v37.setActive
		if type(v38) ~= "function" then
			continue
		end
		local v39 = v37.setActive
		local v40
		if v36 == "FpCam" and not p33 then
			v40 = v_u_9
		else
			v40 = p33
		end
		local v41 = v_u_5
		local v42, v43 = pcall(v39, v40, v41)
		if v42 then
			continue
		end
		local v44 = v36 .. ".setActive"
		local v45 = (v_u_12[v44] or 0) + 1
		v_u_12[v44] = v45
		if v45 > 3 and v45 % 300 ~= 0 then
			continue
		end
		warn("[FpView] " .. v44 .. " failed: " .. tostring(v43))
	end
	if v_u_5 then
		v_u_5.emit("fptp.changed", p33)
	end
end
function v_u_3.refresh() -- name: refresh
	-- upvalues: (ref) v_u_13, (ref) v_u_6, (copy) v_u_32, (copy) v_u_11, (ref) v_u_8, (ref) v_u_9, (copy) v_u_46, (copy) v_u_20, (ref) v_u_5, (copy) v_u_12
	if v_u_13 and v_u_6 ~= nil then
		v_u_32()
		local v47 = v_u_6.localActive(v_u_11)
		local v48 = not v47
		if v48 then
			if v_u_11.viewMode == "fptp" and v_u_11.place == "Raid" then
				if v_u_11.spectating == true then
					v48 = true
				elseif v_u_11.hasChar == false and v_u_11.scripted ~= true then
					v48 = v_u_8 or v_u_9
				else
					v48 = false
				end
			else
				v48 = false
			end
		end
		if v47 == v_u_8 then
			if v48 ~= v_u_9 then
				v_u_9 = v48
				local v49 = v_u_20("FpCam")
				if v49 then
					local v50 = v49.setActive
					if type(v50) == "function" then
						local v51 = v49.setActive
						local v52 = v_u_5
						local v53, v54 = pcall(v51, v48, v52)
						if not v53 then
							local v55 = (v_u_12["FpCam.setActive"] or 0) + 1
							v_u_12["FpCam.setActive"] = v55
							if v55 <= 3 or v55 % 300 == 0 then
								warn("[FpView] " .. "FpCam.setActive" .. " failed: " .. tostring(v54))
							end
						end
					end
				end
			end
		else
			v_u_46(v47, v48)
		end
	else
		return
	end
end
function v_u_3.active() -- name: active
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v_u_3.viewOn() -- name: viewOn
	-- upvalues: (ref) v_u_8, (ref) v_u_9
	return v_u_8 or v_u_9
end
function v_u_3.facts() -- name: facts
	-- upvalues: (copy) v_u_11
	return {
		["viewMode"] = v_u_11.viewMode,
		["place"] = v_u_11.place,
		["hasChar"] = v_u_11.hasChar,
		["scripted"] = v_u_11.scripted
	}
end
function v_u_3.init(p_u_56) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) v_u_20, (copy) v_u_12, (ref) v_u_9, (ref) v_u_8, (copy) v_u_4, (copy) v_u_11, (ref) v_u_10, (copy) v_u_2, (copy) v_u_3
	v_u_5 = p_u_56
	v_u_6 = p_u_56.shared.ViewMode
	p_u_56.command("fptp.state", function()
		-- upvalues: (ref) v_u_20, (copy) p_u_56, (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10
		local v_u_57 = v_u_20("FpCam")
		local v_u_58 = "?"
		local v_u_59 = "?"
		if v_u_57 then
			pcall(function()
				-- upvalues: (ref) v_u_58, (ref) v_u_59, (copy) v_u_57
				local v60 = v_u_57.side()
				local v61 = v_u_57.effectiveSide()
				v_u_58 = v60
				v_u_59 = v61
			end)
		end
		local v_u_62 = p_u_56.controllers.Camera
		local v_u_63 = false
		local v_u_64 = "?"
		if v_u_62 then
			pcall(function()
				-- upvalues: (ref) v_u_63, (copy) v_u_62, (ref) v_u_64
				local v65
				if v_u_62.viewRig == nil then
					v65 = false
				else
					v65 = v_u_62.viewRig() ~= nil
				end
				v_u_63 = v65
				v_u_64 = v_u_62.mode()
			end)
		end
		local v66 = {}
		for v67, v68 in v_u_12 do
			local v69 = v67 .. "=" .. v68
			table.insert(v66, v69)
		end
		table.sort(v66)
		local v_u_70 = ""
		if v_u_57 then
			local v71 = v_u_57.facts
			if type(v71) == "function" then
				local function v89()
					-- upvalues: (copy) v_u_57, (ref) v_u_70, (ref) v_u_9
					local v72 = v_u_57.facts()
					local v73 = string.format
					local v74 = v_u_9
					local v75 = tostring(v74)
					local v76 = v72.yawDeg
					local v77 = v72.pitchDeg
					local v78 = v72.fov
					local v79 = v72.ads
					local v80 = v72.tpAds
					local v81 = v72.toggle
					local v82 = v72.kickP
					local v83 = v72.kickY
					local v84 = v72.mouse
					local v85 = tostring(v84)
					local v86 = v72.body
					local v87 = v72.camDist
					local v88 = v72.dead
					v_u_70 = v73(" spec=%s look=%.1f/%.1f fov=%.1f ads=%.2f tpAds=%.2f toggle=%.2f kick=%.2f/%.2f mouse=%s body=%.1f camDist=%.2f dead=%s", v75, v76, v77, v78, v79, v80, v81, v82, v83, v85, v86, v87, (tostring(v88)))
				end
				pcall(v89)
			end
		end
		local v90 = string.format
		local v91 = v_u_8
		local v92 = tostring(v91)
		local v93 = v_u_4
		local v94 = tostring(v93:GetAttribute("ViewMode"))
		local v95 = v_u_11.viewMode
		local v96 = v_u_11.place
		local v97 = v_u_11.hasChar
		local v98 = tostring(v97)
		local v99 = v_u_11.scripted
		local v100 = v_u_10
		return v90("active=%s attr=%s viewMode=%s place=%s hasChar=%s scripted=%s forced=%s side=%s effective=%s camMode=%s rig=%s errors=%s%s", v92, v94, v95, v96, v98, tostring(v99), tostring(v100), v_u_58, v_u_59, v_u_64, tostring(v_u_63), #v66 <= 0 and "none" or table.concat(v66, ","), v_u_70)
	end)
	p_u_56.command("fptp.force", function(p101)
		-- upvalues: (ref) v_u_2, (ref) v_u_10, (ref) v_u_3, (ref) v_u_8
		if not v_u_2:IsStudio() then
			return "fptp.force works in Studio only"
		end
		local v102 = p101[1]
		if v102 == "on" or v102 == "off" then
			v_u_10 = v102
		else
			if v102 ~= "auto" and v102 ~= nil then
				return "usage: fptp.force on|off|auto"
			end
			v_u_10 = nil
		end
		v_u_3.refresh()
		local v103 = v_u_10
		local v104 = v_u_8
		return "forced=" .. tostring(v103) .. " active=" .. tostring(v104)
	end)
end
function v_u_3.start() -- name: start
	-- upvalues: (ref) v_u_13, (ref) v_u_5, (ref) v_u_6, (copy) v_u_3, (ref) v_u_8, (copy) v_u_20, (copy) v_u_12, (copy) v_u_4
	v_u_13 = true
	local v105 = v_u_5.controllers.Input
	if v105 then
		local v106 = v105.setContext
		if type(v106) == "function" then
			local v107 = v105.setContext
			local v108 = v_u_6.CONTEXT
			local v109 = v_u_3.active
			pcall(v107, v108, v109)
		end
	end
	if v105 then
		local v110 = v105.bind
		if type(v110) == "function" then
			local v111 = v105.bind
			local function v118()
				-- upvalues: (ref) v_u_8, (ref) v_u_20, (ref) v_u_12
				if v_u_8 then
					local v112 = v_u_20("FpCam")
					if v112 then
						local v113 = v112.toggle
						if type(v113) == "function" then
							local v114 = v112.toggle
							local v115, v116 = pcall(v114)
							if not v115 then
								local v117 = (v_u_12["FpCam.toggle"] or 0) + 1
								v_u_12["FpCam.toggle"] = v117
								if v117 <= 3 or v117 % 300 == 0 then
									warn("[FpView] " .. "FpCam.toggle" .. " failed: " .. tostring(v116))
								end
							end
						end
					end
				end
			end
			pcall(v111, "viewToggle", v118)
		end
	end
	v_u_4:GetAttributeChangedSignal(v_u_6.PLAYER_ATTR):Connect(v_u_3.refresh)
	v_u_4:GetAttributeChangedSignal("Place"):Connect(v_u_3.refresh)
	v_u_4.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_3
		task.defer(v_u_3.refresh)
	end)
	v_u_4.CharacterRemoving:Connect(function()
		-- upvalues: (ref) v_u_3
		task.defer(v_u_3.refresh)
	end)
	v_u_3.refresh()
end
function v_u_3.step(p119) -- name: step
	-- upvalues: (copy) v_u_3, (ref) v_u_8, (ref) v_u_9, (copy) v_u_15, (copy) v_u_20, (copy) v_u_12
	v_u_3.refresh()
	if v_u_8 or v_u_9 then
		for _, v120 in v_u_15 do
			if not v_u_8 and v120 ~= "FpCam" then
				continue
			end
			local v121 = v_u_20(v120)
			if not v121 then
				continue
			end
			local v122 = v121.step
			if type(v122) ~= "function" then
				continue
			end
			local v123 = v121.step
			local v124, v125 = pcall(v123, p119)
			if v124 then
				continue
			end
			local v126 = v120 .. ".step"
			local v127 = (v_u_12[v126] or 0) + 1
			v_u_12[v126] = v127
			if v127 > 3 and v127 % 300 ~= 0 then
				continue
			end
			warn("[FpView] " .. v126 .. " failed: " .. tostring(v125))
		end
	end
end
return v_u_3