-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPaidQueue

local v_u_1 = {
	["INTRO_ID"] = "paidintro",
	["TICK"] = 1,
	["GIVE_UP"] = 900
}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
local v_u_4 = {
	["running"] = false,
	["tab"] = nil,
	["page"] = nil,
	["shownAt"] = nil,
	["chipPool"] = nil,
	["opens"] = 0,
	["openedAt"] = nil,
	["win"] = nil
}
local function v_u_12(p_u_5, p_u_6) -- name: sharedMod
	-- upvalues: (copy) v_u_2
	local v7, v8 = pcall(function()
		-- upvalues: (copy) p_u_5, (copy) p_u_6
		return p_u_5.cctx.shared[p_u_6]
	end)
	if v7 and type(v8) == "table" then
		return v8
	else
		local function v9()
			-- upvalues: (ref) v_u_2, (copy) p_u_6
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild(p_u_6, 5)))
		end
		local v10, v11 = pcall(v9)
		if v10 and type(v11) == "table" then
			return v11
		else
			return nil
		end
	end
end
local function v_u_19(p_u_13, p_u_14) -- name: libMod
	local v15, v16 = pcall(function()
		-- upvalues: (copy) p_u_13, (copy) p_u_14
		return p_u_13.cctx.lib[p_u_14]
	end)
	if v15 and type(v16) == "table" then
		return v16
	else
		local v17, v18 = pcall(function()
			-- upvalues: (copy) p_u_14
			return require((script.Parent:WaitForChild(p_u_14, 5)))
		end)
		if v17 and type(v18) == "table" then
			return v18
		else
			return nil
		end
	end
end
function v_u_1.enabled(p20) -- name: enabled
	-- upvalues: (copy) v_u_2
	if p20 == nil then
		local function v21()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
		end
		local v22, v23 = pcall(v21)
		if v22 and type(v23) == "table" then
			local v24 = v23.rule
			if type(v24) == "function" then
				p20 = v23.rule
			end
		end
	end
	if type(p20) ~= "function" then
		return false
	end
	local v25, v26 = pcall(p20, "paidQueue")
	if v25 then
		v25 = v26 == true
	end
	return v25
end
function v_u_1.poolOf(p27) -- name: poolOf
	-- upvalues: (copy) v_u_3
	local v_u_28
	if type(p27) == "table" and p27.player ~= nil then
		v_u_28 = p27.player
	else
		v_u_28 = v_u_3.LocalPlayer
	end
	if v_u_28 ~= nil then
		local v29, v30 = pcall(function()
			-- upvalues: (copy) v_u_28
			return v_u_28:GetAttribute("DevPaidQueue")
		end)
		if v29 and (v30 == "paid" or v30 == "free") then
			return v30
		end
	end
	local v31
	if type(p27) == "table" then
		v31 = p27.party
	else
		v31 = nil
	end
	local v32
	if type(v31) == "table" then
		v32 = v31.party
	else
		v32 = nil
	end
	if type(v32) == "table" and (v32.pool == "paid" or v32.pool == "free") then
		return v32.pool
	end
	if v_u_28 ~= nil then
		local v33, v34 = pcall(function()
			-- upvalues: (copy) v_u_28
			return v_u_28:GetAttribute("PaidQueue")
		end)
		if v33 and (v34 == "paid" or v34 == "free") then
			return v34
		end
	end
	return nil
end
local function v_u_64(p35, p36, p37, p38, p39, p40) -- name: coin
	local v41 = p35.new
	local v42 = "Frame"
	local v43 = {
		["Name"] = "Coin",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = false
	}
	local v44
	if p39 then
		v44 = p36.accent
	else
		v44 = p36.muted
	end
	v43.BackgroundColor3 = v44
	v43.Position = p40
	v43.Size = UDim2.fromOffset(p38, p38)
	local v45 = v41(v42, v43, p37)
	p35.new("UICorner", {
		["CornerRadius"] = UDim.new(0.5, 0)
	}, v45)
	local v46 = p38 * 0.17
	local v47 = math.floor(v46)
	local v48 = math.max(2, v47)
	local v49 = p35.new
	local v50 = "Frame"
	local v51 = {
		["Name"] = "Rim",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = false
	}
	local v52
	if p39 then
		v52 = p36.accentDeep
	else
		v52 = p36.raised
	end
	v51.BackgroundColor3 = v52
	v51.AnchorPoint = Vector2.new(0.5, 0.5)
	v51.Position = UDim2.fromScale(0.5, 0.5)
	v51.Size = UDim2.fromOffset(p38 - v48 * 2, p38 - v48 * 2)
	local v53 = v49(v50, v51, v45)
	p35.new("UICorner", {
		["CornerRadius"] = UDim.new(0.5, 0)
	}, v53)
	local v54 = p35.new
	local v55 = "Frame"
	local v56 = {
		["Name"] = "Mark",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = false
	}
	local v57
	if p39 then
		v57 = p36.accent
	else
		v57 = p36.muted
	end
	v56.BackgroundColor3 = v57
	v56.AnchorPoint = Vector2.new(0.5, 0.5)
	v56.Position = UDim2.fromScale(0.5, 0.5)
	local v58 = UDim2.fromOffset
	local v59 = p38 * 0.24
	local v60 = math.floor(v59)
	local v61 = math.max(2, v60)
	local v62 = p38 * 0.24
	local v63 = math.floor(v62)
	v56.Size = v58(v61, (math.max(2, v63)))
	v54(v55, v56, v53)
	return v45
end
local function v_u_72(p65, p66, p67, p68) -- name: bulletRow
	local v69 = p65.ui
	local v70 = p65.theme.color
	local v71 = v69.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Bullet" .. p68,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p68
	}, p66)
	v69.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Active"] = false,
		["BackgroundColor3"] = v70.accent,
		["Position"] = UDim2.fromOffset(2, 7),
		["Size"] = UDim2.fromOffset(6, 6)
	}, v71)
	return v69.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v71,
		["text"] = p67,
		["color"] = v70.text2,
		["position"] = UDim2.fromOffset(18, 0),
		["size"] = UDim2.new(1, -18, 0, 0)
	})
end
local function v_u_78(p_u_73, p_u_74) -- name: openModal
	-- upvalues: (copy) v_u_72
	return p_u_73.ui.modal({
		["title"] = p_u_74.title,
		["width"] = p_u_74.width,
		["build"] = function(p75) -- name: build
			-- upvalues: (copy) p_u_74, (ref) v_u_72, (copy) p_u_73
			for v76, v77 in p_u_74.bullets do
				v_u_72(p_u_73, p75, v77, v76)
			end
			if p_u_74.after ~= nil then
				p_u_74.after(p75)
			end
		end,
		["buttons"] = p_u_74.buttons,
		["onClose"] = p_u_74.onClose
	})
end
function v_u_1.cardSpec(p_u_79, p80) -- name: cardSpec
	-- upvalues: (copy) v_u_12
	local v81 = v_u_12(p_u_79, "PaidRules").TEXT
	local v82 = p80 == "paid"
	local v83 = {}
	if not v82 then
		table.insert(v83, {
			["text"] = "Store",
			["kind"] = "secondary",
			["onClick"] = nil,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_79
				local function v84()
					-- upvalues: (ref) p_u_79
					p_u_79.openStore()
				end
				pcall(v84)
			end
		})
	end
	local v85 = {
		["text"] = nil,
		["kind"] = "primary",
		["text"] = v81.CARD_BUTTON
	}
	table.insert(v83, v85)
	local v86 = {
		["title"] = nil,
		["width"] = 480,
		["bullets"] = nil,
		["buttons"] = nil
	}
	local v87
	if v82 then
		v87 = v81.CARD_PAID_TITLE
	else
		v87 = v81.CARD_FREE_TITLE
	end
	v86.title = v87
	local v88
	if v82 then
		v88 = v81.CARD_PAID
	else
		v88 = v81.CARD_FREE
	end
	v86.bullets = v88
	v86.buttons = v83
	return v86
end
function v_u_1.windowSpec(p89, p90, p91) -- name: windowSpec
	-- upvalues: (copy) v_u_1, (copy) v_u_19
	local v92 = v_u_1.cardSpec(p89, p90 or v_u_1.poolOf(p89))
	if type(p91) == "table" and (p91.queueApi ~= nil or p91.inputApi ~= nil) then
		local v93 = v_u_19(p89, "MenuQueueWindow")
		if v93 ~= nil then
			v92 = v93.extend(p89, p91, v92)
		end
	end
	return v92
end
function v_u_1.openCard(p_u_94, p_u_95, p_u_96) -- name: openCard
	-- upvalues: (copy) v_u_1, (copy) v_u_78, (copy) v_u_4
	if not v_u_1.enabled() then
		return nil
	end
	local function v101()
		-- upvalues: (ref) v_u_1, (copy) p_u_94, (copy) p_u_95, (copy) p_u_96, (ref) v_u_78, (ref) v_u_4
		local v97 = v_u_1.windowSpec(p_u_94, p_u_95, p_u_96)
		local v98 = v_u_78(p_u_94, v97)
		local v99 = v_u_4
		local v100
		if v97.after == nil then
			v100 = nil
		else
			v100 = v98
		end
		v99.win = v100
		return v98
	end
	local v102, v103 = pcall(v101)
	if v102 then
		return v103
	end
	warn("[MenuPaidQueue] card failed:", v103)
	return nil
end
local function v_u_155(p_u_104, p_u_105, p_u_106) -- name: buildChip
	-- upvalues: (copy) v_u_19, (copy) v_u_1, (copy) v_u_4, (copy) v_u_64, (copy) v_u_3
	local v_u_107 = p_u_104.ui
	local v_u_108 = p_u_104.theme
	local v_u_109 = v_u_108.color
	local v_u_110 = v_u_19(p_u_104, "PaidQueueLayout")
	local v_u_111 = v_u_19(p_u_104, "TextFitting")
	local v_u_112 = v_u_108.touch(p_u_106.compact and 44 or 56)
	local v_u_113 = (p_u_106.colW or 440) - 32
	local v114 = v_u_110.chip(v_u_113, v_u_112, {
		["paid"] = true
	})
	local v_u_115 = {
		["lay"] = v114,
		["conns"] = {}
	}
	local v_u_116 = v_u_107.new("TextButton", {
		["Name"] = "PaidChip",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_109.raised,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.fromScale(1, 1),
		["Size"] = UDim2.fromOffset(v114.chip.w, v114.chip.h)
	}, p_u_106.dep)
	local v_u_117 = v_u_107.stroke(v_u_116, v_u_109.line)
	local v_u_118 = nil
	local v_u_119 = v_u_107.label({
		["parent"] = nil,
		["name"] = "Label",
		["text"] = nil,
		["style"] = "caps",
		["textSize"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_116,
		["text"] = v114.label,
		["textSize"] = v114.size,
		["color"] = v_u_109.text2,
		["position"] = UDim2.fromOffset(v114.text.x - v114.chip.x, 0),
		["size"] = UDim2.fromOffset(v114.text.w, v114.chip.h)
	})
	v_u_119.TextYAlignment = Enum.TextYAlignment.Center
	v_u_119.Active = false
	v_u_115.frame = v_u_116
	v_u_115.label = v_u_119
	local v_u_120 = nil
	function v_u_115.link() -- name: link
		-- upvalues: (copy) p_u_106, (copy) v_u_116
		local function v122()
			-- upvalues: (ref) p_u_106, (ref) v_u_116
			local v121 = p_u_106.deployBtn
			if v121 == nil then
				return
			elseif v_u_116.Visible then
				v121.NextSelectionRight = v_u_116
				v_u_116.NextSelectionLeft = v121
			elseif v121.NextSelectionRight == v_u_116 then
				v121.NextSelectionRight = nil
			end
		end
		pcall(v122)
	end
	function v_u_115.paint() -- name: paint
		-- upvalues: (copy) v_u_116, (ref) v_u_1, (copy) p_u_104, (ref) v_u_4, (copy) p_u_105, (copy) p_u_106, (copy) v_u_112, (ref) v_u_120, (copy) v_u_110, (copy) v_u_113, (copy) v_u_115, (copy) v_u_117, (copy) v_u_109, (copy) v_u_107, (copy) v_u_119, (ref) v_u_118, (ref) v_u_64, (copy) v_u_111
		if v_u_116.Parent then
			local v123 = v_u_1.poolOf(p_u_104)
			local v124 = v123 == "paid"
			v_u_4.chipPool = v123
			if v123 == nil then
				v_u_116.Visible = false
				p_u_105.paidChipW = 0
			else
				local v125 = p_u_106.deployBtn
				local v126 = v125 == nil and 0 or v125.Size.Y.Offset
				if v126 <= 0 then
					v126 = v_u_112
				end
				local v127 = v123 .. ":" .. tostring(v126)
				if v_u_120 ~= v127 then
					v_u_120 = v127
					local v128 = v_u_110.chip(v_u_113, v126, {
						["paid"] = v124
					})
					v_u_115.lay = v128
					v_u_116.Size = UDim2.fromOffset(v128.chip.w, v128.chip.h)
					local v129 = v_u_117
					local v130
					if v124 then
						v130 = v_u_109.accent
					else
						v130 = v_u_109.line
					end
					v129.Color = v130
					local v131 = v_u_116
					local v132
					if v124 then
						v132 = v_u_109.raised2
					else
						v132 = v_u_109.raised
					end
					v131.BackgroundColor3 = v132
					v_u_107.setText(v_u_119, v128.label)
					local v133 = v_u_119
					local v134
					if v124 then
						v134 = v_u_109.accent
					else
						v134 = v_u_109.text2
					end
					v133.TextColor3 = v134
					v_u_119.Position = UDim2.fromOffset(v128.text.x - v128.chip.x, 0)
					v_u_119.Size = UDim2.fromOffset(v128.text.w, v128.chip.h)
					v_u_119.Visible = v128.mode == "full"
					if v_u_118 then
						v_u_118:Destroy()
					end
					v_u_118 = v_u_64(v_u_107, v_u_109, v_u_116, v128.coin.w, v124, UDim2.fromOffset(v128.coin.x - v128.chip.x, v128.coin.y))
					if v_u_111 and v128.mode == "full" then
						local v135 = v_u_111.fit
						local v136 = v_u_119
						local v137 = v128.text.w
						pcall(v135, v136, v137, 9)
					end
				end
				v_u_116.Visible = true
				p_u_105.paidChipW = v_u_115.lay.chip.w + v_u_110.GAP
			end
			local v138 = p_u_106.deployBtn
			if v138 then
				v138.Size = UDim2.new(1, -(p_u_105.paidChipW or 0), v138.Size.Y.Scale, v138.Size.Y.Offset)
			end
			v_u_115.link()
		end
	end
	function v_u_115.tap() -- name: tap
		-- upvalues: (copy) v_u_107, (copy) v_u_108, (ref) v_u_1, (copy) p_u_104, (copy) p_u_105
		local function v139()
			-- upvalues: (ref) v_u_107, (ref) v_u_108
			v_u_107.sound(v_u_108.sounds.click)
		end
		pcall(v139)
		v_u_1.openCard(p_u_104, v_u_1.poolOf(p_u_104), p_u_105)
	end
	local v140 = v_u_115.conns
	local v141 = v_u_116.Activated
	local v142 = v_u_115.tap
	table.insert(v140, v141:Connect(v142))
	p_u_105.paidChip = v_u_115
	local v143
	if type(p_u_104) == "table" and p_u_104.player ~= nil then
		v143 = p_u_104.player
	else
		v143 = v_u_3.LocalPlayer
	end
	if v143 then
		local v144 = v143.GetAttributeChangedSignal
		if type(v144) == "function" then
			local v145 = v_u_115.conns
			local v146 = v143:GetAttributeChangedSignal("PaidQueue")
			local v147 = v_u_115.paint
			table.insert(v145, v146:Connect(v147))
			local v148 = v_u_115.conns
			local v149 = v143:GetAttributeChangedSignal("DevPaidQueue")
			local v150 = v_u_115.paint
			table.insert(v148, v149:Connect(v150))
		end
	end
	if p_u_104.changed and p_u_104.changed.Connect then
		local v151 = v_u_115.conns
		local v152 = p_u_104.changed
		table.insert(v151, v152:Connect(function(p153)
			-- upvalues: (copy) v_u_115
			if p153 == "party" or (p153 == "profile" or p153 == nil) then
				v_u_115.paint()
			end
		end))
	end
	function v_u_115.destroy() -- name: destroy
		-- upvalues: (copy) v_u_115, (copy) p_u_105, (copy) v_u_116
		for _, v_u_154 in v_u_115.conns do
			pcall(function()
				-- upvalues: (copy) v_u_154
				v_u_154:Disconnect()
			end)
		end
		table.clear(v_u_115.conns)
		if p_u_105.paidChipW then
			p_u_105.paidChipW = 0
		end
		if p_u_105.paidChip == v_u_115 then
			p_u_105.paidChip = nil
		end
		if v_u_116.Parent then
			v_u_116:Destroy()
		end
	end
	v_u_115.paint()
	return v_u_115
end
function v_u_1.introSpec(p156) -- name: introSpec
	-- upvalues: (copy) v_u_12
	local v157 = v_u_12(p156, "PaidRules").TEXT
	return {
		["title"] = nil,
		["width"] = 520,
		["bullets"] = nil,
		["hold"] = true,
		["button"] = nil,
		["dismissable"] = false,
		["title"] = v157.INTRO_TITLE,
		["bullets"] = v157.INTRO,
		["button"] = v157.INTRO_BUTTON
	}
end
function v_u_1.deployGate(p158) -- name: deployGate
	-- upvalues: (copy) v_u_19, (copy) v_u_3
	local v159 = v_u_19(p158, "MenuPvpveIntro")
	if v159 ~= nil then
		local v160 = v159.gate
		if type(v160) == "function" then
			local v161 = v159.gate
			local v162
			if type(p158) == "table" and p158.player ~= nil then
				v162 = p158.player
			else
				v162 = v_u_3.LocalPlayer
			end
			local v163 = p158.profile
			local v164, v165, v166 = pcall(v161, v162, v163, nil)
			if v164 then
				return v165 == true, v166
			else
				return true, nil
			end
		end
	end
	return true, nil
end
v_u_1.FALLBACK_SECS = 20
v_u_1.FALLBACK_REOPEN_SECS = 3
v_u_1.REOPEN_GAP = 5
function v_u_1.introReady(p167) -- name: introReady
	-- upvalues: (copy) v_u_1
	if p167.decide ~= "show" or (p167.active ~= true or (p167.tour == true or (p167.modal == true or p167.tip == true))) then
		return false
	end
	if p167.toured == true then
		return true
	end
	local v168 = p167.openFor
	local v169 = tonumber(v168) or 0
	local v170 = p167.opens
	local v171 = tonumber(v170) or 0
	local v172
	if v_u_1.FALLBACK_SECS <= v169 then
		v172 = true
	elseif v171 >= 2 then
		v172 = v_u_1.FALLBACK_REOPEN_SECS <= v169
	else
		v172 = false
	end
	return v172
end
function v_u_1.noteOpen(p173) -- name: noteOpen
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	if v_u_4.openedAt == nil or p173 - v_u_4.openedAt > v_u_1.REOPEN_GAP then
		local v174 = v_u_4
		v174.opens = v174.opens + 1
	end
	v_u_4.openedAt = p173
	return v_u_4.opens
end
function v_u_1.openFacts(p175) -- name: openFacts
	-- upvalues: (copy) v_u_4
	local v176 = v_u_4.opens
	if v_u_4.openedAt == nil then
		return v176, 0
	end
	local v177 = p175 - v_u_4.openedAt
	return v176, math.max(0, v177)
end
local function v_u_206(p_u_178) -- name: introFacts
	-- upvalues: (copy) v_u_19, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1
	local v179 = v_u_19(p_u_178, "MenuPvpveIntro")
	local v180 = "wait"
	local v181
	if type(p_u_178) == "table" and p_u_178.player ~= nil then
		v181 = p_u_178.player
	else
		v181 = v_u_3.LocalPlayer
	end
	if v179 then
		local v182 = v179.needed
		if type(v182) == "function" then
			local v183 = v179.needed
			local v184 = p_u_178.profile
			local v185, v186 = pcall(v183, v181, v184, nil)
			local v187
			if v181 == nil or v181:GetAttribute("PvpIntro") == nil then
				local v188 = p_u_178.profile
				if type(v188) == "table" then
					local v189 = p_u_178.profile.settings
					v187 = type(v189) == "table"
				else
					v187 = false
				end
			else
				v187 = true
			end
			v180 = v185 and (v186 == true and "show" or (v187 and "seen" or "wait")) or "wait"
		end
	end
	local v190
	if v181 == nil then
		v190 = false
	else
		v190 = v181:GetAttribute("MenuTour") ~= nil
	end
	local v_u_191 = 0
	local function v192()
		-- upvalues: (ref) v_u_191, (copy) p_u_178
		v_u_191 = p_u_178.ui.modalCount()
	end
	pcall(v192)
	local v_u_193 = v_u_4.tab
	local v_u_194 = false
	local function v196()
		-- upvalues: (ref) v_u_194, (copy) v_u_193, (ref) v_u_4
		local v195
		if v_u_193 == nil or (v_u_193.shown ~= true or v_u_4.page == nil) then
			v195 = false
		else
			v195 = v_u_4.page.Parent ~= nil
		end
		v_u_194 = v195
	end
	pcall(v196)
	local v_u_197 = false
	local function v200()
		-- upvalues: (copy) v_u_193, (ref) v_u_197
		local v198 = v_u_193
		if v198 then
			v198 = v_u_193.introHandle
		end
		local v199
		if v198 == nil then
			v199 = false
		else
			v199 = v198.alive == nil and true or v198.alive() == true
		end
		v_u_197 = v199
	end
	pcall(v200)
	local v201 = p_u_178.profile
	local v202
	if type(v201) == "table" then
		local v203 = v201.settings
		if type(v203) == "table" then
			v202 = v201.settings.menuTourSeen == true
		else
			v202 = false
		end
	else
		v202 = false
	end
	local v204, v205 = v_u_1.openFacts(os.clock())
	return {
		["decide"] = v180,
		["active"] = v_u_194,
		["tour"] = v190,
		["modal"] = v_u_191 > 0,
		["tip"] = v_u_197,
		["toured"] = v202,
		["opens"] = v204,
		["openFor"] = v205
	}
end
function v_u_1.showIntro(p207) -- name: showIntro
	-- upvalues: (copy) v_u_19, (copy) v_u_4
	local v208 = v_u_19(p207, "MenuPvpveIntro")
	if v208 ~= nil then
		local v209 = v208.showCard
		if type(v209) == "function" then
			local v210 = v208.showCard
			local v211, v212 = pcall(v210, p207)
			if v211 then
				v_u_4.shownAt = os.clock()
				return v212
			else
				warn("[MenuPaidQueue] first visit card failed:", v212)
				return nil
			end
		end
	end
	return nil
end
local function v_u_216(p_u_213) -- name: startFirstJoin
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_206
	if not v_u_4.running then
		v_u_4.running = true
		task.spawn(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_206, (copy) p_u_213, (ref) v_u_4
			local v214 = os.clock()
			if os.clock() - v214 < v_u_1.GIVE_UP then
				task.wait(v_u_1.TICK)
				local v215 = v_u_206(p_u_213)
				if v215.decide ~= "seen" and v215.decide ~= "none" then
					if not v_u_1.introReady(v215) then
						continue
					end
					v_u_1.showIntro(p_u_213)
				end
			end
			v_u_4.running = false
		end)
	end
end
function v_u_1.attach(p217, p_u_218, p219) -- name: attach
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_155, (copy) v_u_216
	if not v_u_1.enabled() then
		return nil
	end
	local v220 = v_u_4
	local v221 = v_u_4
	local v222 = p219.page
	v220.tab = p_u_218
	v221.page = v222
	v_u_1.noteOpen(os.clock())
	local v223 = nil
	local v224 = v_u_155
	local v225, v226 = pcall(v224, p217, p_u_218, p219)
	if v225 then
		local v_u_227 = v226
		local v_u_228 = p_u_218.destroy
		function p_u_218.destroy(...)
			-- upvalues: (ref) v_u_227, (ref) v_u_4, (copy) p_u_218, (copy) v_u_228
			local v229 = v_u_227.destroy
			pcall(v229)
			if v_u_4.win ~= nil then
				local function v230()
					-- upvalues: (ref) v_u_4
					v_u_4.win.close()
				end
				pcall(v230)
				v_u_4.win = nil
			end
			if v_u_4.tab == p_u_218 then
				local v231 = v_u_4
				v_u_4.tab = nil
				v231.page = nil
			end
			if v_u_228 then
				return v_u_228(...)
			else
				return nil
			end
		end
		v223 = v_u_227
	else
		warn("[MenuPaidQueue] chip failed:", v226)
	end
	local v232 = v_u_216
	pcall(v232, p217)
	return v223
end
function v_u_1.attachHint(p_u_233, p_u_234, p_u_235, p_u_236, p_u_237) -- name: attachHint
	-- upvalues: (copy) v_u_1, (copy) v_u_19, (copy) v_u_12
	if not v_u_1.enabled() then
		return nil
	end
	local v_u_238 = p_u_233.ui
	local v_u_239 = p_u_233.theme
	local v240 = v_u_239.color
	local v_u_241 = v_u_19(p_u_233, "PaidQueueLayout")
	local v_u_242 = v_u_12(p_u_233, "PaidRules")
	local v_u_243 = v_u_238.new("Frame", {
		["Name"] = "PaidHint",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["ZIndex"] = 6,
		["Active"] = false,
		["BackgroundColor3"] = v240.bg
	}, p_u_234)
	v_u_238.stroke(v_u_243, v240.accent, 1, 0.45)
	local v_u_244 = v_u_238.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_243,
		["color"] = v240.accent,
		["position"] = UDim2.fromOffset(v_u_241.HINT_PAD, 0),
		["size"] = UDim2.new(1, -2 * v_u_241.HINT_PAD, 1, 0)
	})
	v_u_244.ZIndex = 7
	v_u_244.Active = false
	local v_u_274 = {
		["frame"] = v_u_243,
		["label"] = v_u_244,
		["conns"] = {},
		["paint"] = function() -- name: paint
			-- upvalues: (copy) v_u_243, (copy) p_u_233, (copy) v_u_242, (copy) p_u_237, (copy) v_u_239, (copy) p_u_236, (copy) v_u_241, (copy) p_u_234, (copy) p_u_235, (copy) v_u_244, (copy) v_u_238
			if v_u_243.Parent then
				local v245 = p_u_233.myParty
				local v246
				if type(v245) == "function" then
					v246 = p_u_233.myParty()
				else
					v246 = nil
				end
				local v247
				if type(v246) == "table" then
					local v248 = v246.poolHint
					if type(v248) == "string" and v246.poolHint ~= "" then
						v247 = v246.poolHint
					else
						v247 = nil
					end
				else
					v247 = nil
				end
				local v249 = nil
				if v247 == nil and type(v246) == "table" then
					local function v250()
						-- upvalues: (ref) p_u_233
						return p_u_233.cctx.lib.MenuInputQueueMount
					end
					local v251, v252 = pcall(v250)
					if v251 and type(v252) == "table" then
						local v253 = v252.hintTexts
						local v254 = p_u_233.cctx.lib.MenuInputQueue
						local v255 = v246.input
						local v256
						v256, v249 = pcall(v253, v254, v255)
						if not v256 then
							v249 = nil
						end
					end
				end
				if v247 == nil and v249 == nil then
					v_u_243.Visible = false
				else
					local v257 = v249 or (v247 == v_u_242.TEXT.SQUAD_HINT and { v_u_242.TEXT.SQUAD_HINT, v_u_242.TEXT.SQUAD_HINT_SHORT } or { v247 })
					local v258 = nil
					if p_u_237 ~= true then
						local function v259()
							-- upvalues: (ref) v_u_239
							return v_u_239.safeRefSize().X
						end
						local v260, v261 = pcall(v259)
						if v260 and type(v261) == "number" then
							v258 = v261 - 24 - p_u_236 - v_u_241.HINT_GAP - 24
						end
					end
					local v262
					if p_u_237 == true then
						local v_u_263 = false
						local function v264()
							-- upvalues: (ref) v_u_263, (ref) v_u_239
							v_u_263 = v_u_239.isPhone() == true
						end
						pcall(v264)
						local v_u_265 = v_u_241.railReserve(v_u_263)
						local function v272()
							-- upvalues: (ref) p_u_234, (ref) v_u_239, (ref) v_u_265, (ref) v_u_241
							local v266 = p_u_234:FindFirstAncestorOfClass("ScreenGui")
							local v267
							if v266 then
								v267 = v266:FindFirstChild("Rail", true)
							else
								v267 = nil
							end
							if v267 ~= nil and (v267:IsA("GuiObject") and v267.Visible) then
								local v268 = v_u_239.uiScale()
								local v269 = math.max(v268, 0.01)
								local v270 = v_u_265
								local v271 = v267.AbsoluteSize.X / v269 + v_u_241.HINT_GAP
								v_u_265 = math.max(v270, v271)
							end
						end
						pcall(v272)
						v262 = v_u_265
					else
						v262 = nil
					end
					local v273 = v_u_241.hint(p_u_236, v257, {
						["compact"] = p_u_237 == true,
						["SH"] = p_u_235,
						["room"] = v258,
						["reserve"] = v262
					})
					v_u_243.Position = UDim2.fromOffset(v273.x, v273.y)
					v_u_243.Size = UDim2.fromOffset(v273.w, v273.h)
					v_u_244.TextSize = v273.size
					v_u_238.setText(v_u_244, v273.text)
					v_u_243.Visible = true
				end
			else
				return
			end
		end
	}
	if p_u_233.changed and p_u_233.changed.Connect then
		local v275 = v_u_274.conns
		local v276 = p_u_233.changed
		table.insert(v275, v276:Connect(function(p277)
			-- upvalues: (copy) v_u_274
			if p277 == "party" or p277 == nil then
				v_u_274.paint()
			end
		end))
	end
	v_u_243.Destroying:Connect(function()
		-- upvalues: (copy) v_u_274
		for _, v_u_278 in v_u_274.conns do
			pcall(function()
				-- upvalues: (copy) v_u_278
				v_u_278:Disconnect()
			end)
		end
		table.clear(v_u_274.conns)
	end)
	v_u_274.paint()
	return v_u_274
end
function v_u_1.storeStrip(p279, p280, p281, p282) -- name: storeStrip
	-- upvalues: (copy) v_u_1, (copy) v_u_19, (copy) v_u_12, (copy) v_u_64
	if not v_u_1.enabled() then
		return nil
	end
	local v283 = p279.ui
	local v284 = p279.theme.color
	local v285 = v_u_19(p279, "PaidQueueLayout")
	local v286 = v_u_12(p279, "PaidRules").TEXT.STORE_NOTICE
	local v287 = p281 - 24 - 18 - 8
	local v288 = v285.noteH(v286, v287, 13) + 16
	local v289 = v283.new("Frame", {
		["Name"] = "PaidNotice",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v284.raised,
		["Size"] = UDim2.new(1, 0, 0, v288),
		["LayoutOrder"] = p282
	}, p280)
	v283.stroke(v289, v284.accent, 1, 0.5)
	v_u_64(v283, v284, v289, 18, true, UDim2.fromOffset(12, 9))
	v283.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["position"] = nil,
		["size"] = nil,
		["fitWrap"] = false,
		["parent"] = v289,
		["text"] = v286,
		["color"] = v284.text,
		["position"] = UDim2.fromOffset(38, 8),
		["size"] = UDim2.new(1, -50, 0, v288 - 16)
	}).Active = false
	return v289
end
function v_u_1.detailNote(p290, p291, p292, p293) -- name: detailNote
	-- upvalues: (copy) v_u_1, (copy) v_u_19, (copy) v_u_12
	if not v_u_1.enabled() then
		return 0
	end
	local v294 = p290.ui
	local v295 = p290.theme
	local v296 = v295.color
	local v297 = v_u_19(p290, "PaidQueueLayout")
	local v298 = v_u_12(p290, "PaidRules").TEXT.STORE_NOTICE
	local v299 = p293 or (v295.safeRefSize().X - 48 - 32) * 0.54 - 8
	local v300 = v297.noteH(v298, v299, 13)
	v294.label({
		["parent"] = nil,
		["name"] = "PaidNote",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["position"] = nil,
		["size"] = nil,
		["fitWrap"] = false,
		["track"] = false,
		["parent"] = p291,
		["text"] = v298,
		["color"] = v296.accent,
		["position"] = UDim2.fromOffset(0, p292),
		["size"] = UDim2.new(1, 0, 0, v300)
	}).Active = false
	return v300 + 8
end
function v_u_1.state() -- name: state
	-- upvalues: (copy) v_u_4
	local v301 = v_u_4.chipPool
	local v302 = tostring(v301)
	local v303 = v_u_4.running
	local v304 = tostring(v303)
	local v305 = v_u_4.shownAt
	return ("pool=%s running=%s shownAt=%s"):format(v302, v304, (tostring(v305)))
end
return v_u_1