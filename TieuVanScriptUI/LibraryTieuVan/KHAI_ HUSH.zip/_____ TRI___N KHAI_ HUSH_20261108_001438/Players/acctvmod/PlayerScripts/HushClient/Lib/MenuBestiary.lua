-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuBestiary

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_13 = {
	["ORDER"] = {
		"walker",
		"runner",
		"crawler",
		"brute",
		"screamer",
		"listener",
		"hazmat",
		"ringer",
		"riot",
		"looter",
		"boss_surgeon",
		"boss_hale"
	},
	["ORDER_R18"] = {
		"watchman",
		"sleeper",
		"mimic",
		"fogger",
		"shade"
	},
	["ORDER_R19"] = { "boss_mayor", "boss_chief" },
	["ORDER_R21"] = { "boss_major" },
	["ORDER_R37"] = {
		"marksman",
		"cantor",
		"rattler",
		"stevedore",
		"fueler",
		"patron",
		"boom",
		"porter",
		"courier",
		"swell",
		"sapper",
		"knocker",
		"canary",
		"drift",
		"driller"
	},
	["ORDER_R37_BOSSES"] = {
		"boss_witness",
		"boss_conductor",
		"boss_foreman",
		"boss_colonel"
	},
	["ORDER_T6_BOSSES"] = { "boss_dj" },
	["ORDER_T6"] = {
		"jumper",
		"sumo",
		"vaulter",
		"kacho"
	},
	["order"] = function(_) -- name: order
		-- upvalues: (copy) v_u_13
		local v4 = {}
		for _, v5 in v_u_13.ORDER do
			table.insert(v4, v5)
			if v5 ~= "riot" then
				continue
			end
			for _, v6 in v_u_13.ORDER_R18 do
				table.insert(v4, v6)
			end
		end
		for _, v7 in v_u_13.ORDER_R19 do
			table.insert(v4, v7)
		end
		for _, v8 in v_u_13.ORDER_R21 do
			table.insert(v4, v8)
		end
		for _, v9 in v_u_13.ORDER_R37 do
			table.insert(v4, v9)
		end
		for _, v10 in v_u_13.ORDER_R37_BOSSES do
			table.insert(v4, v10)
		end
		for _, v11 in v_u_13.ORDER_T6 do
			table.insert(v4, v11)
		end
		for _, v12 in v_u_13.ORDER_T6_BOSSES do
			table.insert(v4, v12)
		end
		return v4
	end
}
local v_u_14 = {
	["walker"] = {
		["name"] = "Walker",
		["short"] = "WALKER",
		["desc"] = "Most of Stillwater turned into these. Slow on their own, deadly in a crowd.",
		["special"] = "Moves in groups and comes to every loud noise. The virus lives in its blood and saliva: a bite can infect you.",
		["where"] = "Everywhere in town."
	},
	["runner"] = {
		["name"] = "Runner",
		["short"] = "RUNNER",
		["desc"] = "Freshly turned and still fast. It covers ground quicker than you can walk.",
		["special"] = "Swings while it runs. Break its line of sight or stand and fight: you will not outwalk it.",
		["where"] = "Everywhere, alone or with a group."
	},
	["crawler"] = {
		["name"] = "Crawler",
		["short"] = "CRAWLER",
		["desc"] = "What is left of the legs drags behind. It lies among the dead and waits.",
		["special"] = "Looks like a corpse until you step close. Watch the bodies on the floor.",
		["where"] = "Everywhere. More of them in Stillwater General."
	},
	["brute"] = {
		["name"] = "Brute",
		["short"] = "BRUTE",
		["desc"] = "Police and soldiers who died in their gear. Big, hard to stagger, hits hard.",
		["special"] = "Plate carrier and helmet stop weak rounds. Use armour-piercing ammo or aim for the head. Carries loot.",
		["where"] = "The police station and Checkpoint Echo."
	},
	["screamer"] = {
		["name"] = "Screamer",
		["short"] = "SCREAMER",
		["desc"] = "Thin, quick and loud. It does not need to reach you to get you killed.",
		["special"] = "Its scream calls every infected far around. Put it down before it screams.",
		["where"] = "Anywhere. Rare."
	},
	["listener"] = {
		["name"] = "Listener",
		["short"] = "LISTENER",
		["desc"] = "A trial patient of the MX-11 study. It stopped sleeping, lost its sight and hears everything.",
		["special"] = "Blind: it hunts by sound alone. Sneak or stand still and it loses you. Shoot and it comes.",
		["where"] = "Mostly Stillwater General."
	},
	["hazmat"] = {
		["name"] = "Hazmat",
		["short"] = "HAZMAT",
		["desc"] = "A Tacet Field Services worker, still sealed in the suit with the sprayer tank on the back.",
		["special"] = "Slow and tough. When it dies the tank bursts into a gas cloud that burns the throat. Every cough is a noise.",
		["where"] = "Stillwater General and Checkpoint Echo."
	},
	["ringer"] = {
		["name"] = "Ringer",
		["short"] = "RINGER",
		["desc"] = "Somebody out there still pages this one. The pager on its belt never stopped.",
		["special"] = "Now and then the pager buzzes, then shrills, and the walkers around come to see. Kill it quietly or use it as bait.",
		["where"] = "Main Street and the residential blocks."
	},
	["riot"] = {
		["name"] = "Riot",
		["short"] = "RIOT",
		["desc"] = "The sheriff\'s riot line. Visor down, shield up.",
		["special"] = "The shield stops shots and blows from the front until it breaks. It turns slowly: flank it or aim for the legs.",
		["where"] = "The police station. On harder raids in lines of two or three."
	},
	["looter"] = {
		["name"] = "Armed Infected",
		["short"] = "ARMED",
		["desc"] = "Hale\'s soldiers turned like everyone else, but their hands still remember the rifles. Green skin, glowing eyes, full kit.",
		["special"] = "Spots you from far away and shoots back in short bursts. Break the line of sight, use cover and close in.",
		["where"] = "Checkpoint Echo, in packs."
	},
	["boss_surgeon"] = {
		["name"] = "The Surgeon",
		["short"] = "SURGEON",
		["desc"] = "Something huge in a surgeon\'s gown, still at work in the operating theatre.",
		["special"] = "Armoured and hard to stagger. His scream calls every infected in the building.",
		["where"] = "Stillwater General, surgical wing. Hard and Nightmare."
	},
	["watchman"] = {
		["name"] = "Watchman",
		["short"] = "WATCHMAN",
		["desc"] = "Tacet\'s night shift, still walking the rounds. The lamp on its shoulder never went out.",
		["special"] = "It sees only what its lamp lights, but it sees that well. Stay out of the yellow cone, or face it and shoot the lamp out. Once it spots you, the infected around it come too.",
		["where"] = "The Hollow: the entrance, the security block and the Diamond. One of them still wears a name plate."
	},
	["prentice"] = {
		["name"] = "Watchman",
		["short"] = "WATCHMAN",
		["desc"] = "Tacet\'s night shift, still walking the rounds. This one still wears his name plate.",
		["special"] = "It sees only what its lamp lights, but it sees that well. Stay out of the yellow cone, or face it and shoot the lamp out. Once it spots you, the infected around it come too.",
		["where"] = "The Hollow: the Diamond."
	},
	["sleeper"] = {
		["name"] = "Sleeper",
		["short"] = "SLEEPER",
		["desc"] = "Subjects of the MX-7 sleep study. They still stand where the night nurses left them, fast asleep.",
		["special"] = "Asleep they see nothing. A noise close by wakes one, and its groan wakes the next. Sneak past, go round, or throw something the other way.",
		["where"] = "The Hollow: the sleep ward and the sleep lab."
	},
	["mimic"] = {
		["name"] = "Mimic",
		["short"] = "MIMIC",
		["desc"] = "Subjects of the MX-5 memory study. They were taught to remember everything. Now they remember every sound.",
		["special"] = "Two seconds after a loud noise it plays it back from where it stands, louder. Kill it quietly, or throw a bottle next to it and let it call the others away from you.",
		["where"] = "The Hollow: the research labs and the archive."
	},
	["fogger"] = {
		["name"] = "Fogger",
		["short"] = "FOGGER",
		["desc"] = "Field Services, Crew 2. Sealed in with the site, still carrying the sample tanks. The tanks never stopped leaking, and the mist goes where they go.",
		["special"] = "Inside the mist nobody sees far, survivors or infected. Breathing it makes you cough, and every cough is a noise. With a gas mask the mist is cover. Kill it from a distance and wait for the mist to clear.",
		["where"] = "The Hollow: the old workings by the Mist Grotto."
	},
	["shade"] = {
		["name"] = "Shade",
		["short"] = "SHADE",
		["desc"] = "Night-shift workers from the MX-3 Nightglass trial. Their eyes see everything in the dark and cannot stand the light.",
		["special"] = "In the dark it sees you from far away and runs you down. Keep your flashlight on it: in the light it freezes, covers its eyes and backs off. Its eyes shine green in your beam.",
		["where"] = "The Hollow: the dark old workings. On Normal only where the lights are out."
	},
	["boss_mayor"] = {
		["name"] = "The Mayor",
		["short"] = "MAYOR",
		["desc"] = "Ellen Whitmore, Mayor of Stillwater. She came down to the Diamond to find her son and never left his cell. Her red coat is the only colour down there.",
		["special"] = "She is blind and hears everything. When she hushes, stand still or sneak: whoever makes a noise in her ring is next. The speakers and the PA horns lure her and leave her back open. Caleb\'s disc might quiet her for good.",
		["where"] = "The Hollow: the Quiet Room in the Diamond. Hard and Nightmare."
	},
	["boss_chief"] = {
		["name"] = "The Chief",
		["short"] = "CHIEF",
		["desc"] = "Roy Dunmore, Chief of Site Security. He still runs the HQ: the cameras, the lockdown key and the lights.",
		["special"] = "His cameras tell him where you are, even behind cover. Shoot them out. He can seal the HQ: crank the blast doors or cut the cables. In the dark he sees only what his shoulder lamp lights. Shine your light in his face or shoot the lamp.",
		["where"] = "The Hollow: Security HQ. Hard and Nightmare."
	},
	["boss_major"] = {
		["name"] = "The Major",
		["short"] = "MAJOR",
		["desc"] = "Major Owen Garrow, commander of Kestrel Field. The orders stopped making sense a long time ago. He still gives them.",
		["special"] = "He gives orders: the infected come when he calls over the PA, and a signal flare marks one survivor and lights him up. Break the net: jam the consoles, shoot the PA horns, cut the transmitter. A recorded ceasefire order might stand him down for good.",
		["where"] = "Kestrel Field: the Ops Room of the Field HQ. Hard and Nightmare."
	},
	["boss_hale"] = {
		["name"] = "Sergeant Hale",
		["short"] = "HALE",
		["desc"] = "The sergeant who held Checkpoint Echo. He never let go of his shotgun.",
		["special"] = "Fires a shotgun from range and keeps an armed escort. Head and chest are armoured.",
		["where"] = "Checkpoint Echo, north end of River Rd. Nightmare only."
	},
	["marksman"] = {
		["name"] = "Marksman",
		["short"] = "MARKSMAN",
		["desc"] = "A soldier of the detachment that held the lake road. The scope still catches the light.",
		["special"] = "One telegraphed shot: a flash of the lens, a thin red line, then the round. Break the line of sight before it ends, or fill the air with flare smoke. A headshot ends it.",
		["where"] = "Overture Plaza and Ashgrove: the posts (on Ashgrove the Ridge Gate, the mess, the upper terminal and the valley). Kestrel Field: the North Gate, the Field HQ yard and the Radar Station."
	},
	["cantor"] = {
		["name"] = "Cantor",
		["short"] = "CANTOR",
		["desc"] = "Someone who sang for a living. The choir kept its voice and lost everything else.",
		["special"] = "While it sings, the infected around it run faster, shake off bullets and keep coming. Find the ring on the floor and kill the singer first.",
		["where"] = "Overture Plaza: the stage, the studios and Founders\' Hall. Ashgrove: the Institute and Company Row."
	},
	["rattler"] = {
		["name"] = "Rattler",
		["short"] = "RATTLER",
		["desc"] = "Staff who climbed up when it started and never came down. They know every ceiling in the building.",
		["special"] = "It waits above you. When the metal rattles and a dark circle grows on the floor, step out of it: the drop comes in one second. A beam of light on the ceiling shows it.",
		["where"] = "Overture Plaza: ceilings, vents and the fly loft. Ashgrove: the roof trusses of the boarding houses, the wash house and the hoist house."
	},
	["stevedore"] = {
		["name"] = "Stevedore",
		["short"] = "STEVEDORE",
		["desc"] = "A dockhand from Dock Three. He never put the hook down.",
		["special"] = "He throws the hook where you stand and drags you in. Step aside while he winds up. If it catches you, a friend has to cut the chain.",
		["where"] = "Overture Plaza: the waterfront and the depot. The Hollow: the cold store and the passage. Hard and Nightmare in the Hollow."
	},
	["fueler"] = {
		["name"] = "Fueler",
		["short"] = "FUELER",
		["desc"] = "Marina staff. The fuel in the cans got into everything.",
		["special"] = "When it dies the fuel burns, for about ten seconds, in a ring around it. Kill it from afar, or when it stands in the middle of the others. Low on health it lights itself and runs at you.",
		["where"] = "Overture Plaza: the harbor and the depot. Kestrel Field: the Fuel Farm, the Aircraft Boneyard and the hangars. The Hollow: the security block, the old workings and the cold store."
	},
	["patron"] = {
		["name"] = "Patron",
		["short"] = "PATRON",
		["desc"] = "Guests of the Founders\' Night. They came dressed, and they were told to sit and listen.",
		["special"] = "Seated, they do not move. A noise or a touch wakes the row, and the rows beside it. Walk quietly along the aisle, or do not enter.",
		["where"] = "Overture Plaza: Founders\' Hall and the plaza."
	},
	["boom"] = {
		["name"] = "Boom Operator",
		["short"] = "BOOM",
		["desc"] = "A technician of Tacet\'s studios. The microphone pole is longer than the arm that holds it.",
		["special"] = "Its pole reaches six studs. Close in under two studs and it cannot hit you, or shoot it from outside its reach.",
		["where"] = "Overture Plaza: the studios, the pavilion and the stage."
	},
	["porter"] = {
		["name"] = "Porter",
		["short"] = "PORTER",
		["desc"] = "He carried bags for the guests. The cart is all he has left, and it is heavy.",
		["special"] = "Bullets and blows from the front hit the cart. Go round it: the legs and the back are open. When the wheels squeal, he is about to charge. Let him hit a wall.",
		["where"] = "Overture Plaza: the lobby and the annex. Kestrel Field: the terminal and the supply yard. Hard and Nightmare on Kestrel."
	},
	["courier"] = {
		["name"] = "Courier",
		["short"] = "COURIER",
		["desc"] = "He delivered for Tacet until the roads closed. He still has the bag.",
		["special"] = "It hits and runs away, and comes back from the side. Do not chase it. Wait with your back to a wall and hit it when it returns. The bag is worth taking.",
		["where"] = "Overture Plaza: the streets and the offices. Kestrel Field: the Field HQ, the North Gate, the Garrison and the Reception Center."
	},
	["swell"] = {
		["name"] = "Swell",
		["short"] = "SWELL",
		["desc"] = "A volunteer of the Bellows trial. Their lungs never went back.",
		["special"] = "It walks to you and bursts with a sound that carries across the ward. Shoot it from far away and let the noise pull the infected to it, not to you.",
		["where"] = "Ashgrove: the Mine Infirmary and its wards, the workings. Indoors only. Kestrel Field: the reception camp and the crash site. The Hollow: the research halls and the deep wing. Hard and Nightmare."
	},
	["sapper"] = {
		["name"] = "Sapper",
		["short"] = "SAPPER",
		["desc"] = "An engineer of the ridge. He still carries the charge he was told to place.",
		["special"] = "It lights the fuse and runs at you. Shoot it before it arrives: a headshot defuses it, a body kill leaves the charge burning. The blast hurts the infected too.",
		["where"] = "Ashgrove: the ridge, the pithead, the upper terminal and the tailings. Kestrel Field: the garrison, the radar hill and the gate. Hard and Nightmare on Kestrel."
	},
	["knocker"] = {
		["name"] = "Knocker",
		["short"] = "KNOCKER",
		["desc"] = "Miners tell of the little men who knock in the rock. This one is real, and it is calling.",
		["special"] = "Three knocks and every infected nearby heads for it, and everyone it sees is marked. Get out of its sight before the third knock. It runs from you, so shoot it.",
		["where"] = "Ashgrove: the pithead and the mill, Company Row, the institute and the workings. The Hollow: the old workings and the caves."
	},
	["canary"] = {
		["name"] = "Canary Man",
		["short"] = "CANARY",
		["desc"] = "He carried the bird so the men would know when the air went bad. The air went bad for good.",
		["special"] = "A dark mist follows him. Inside it you cannot sprint and you tire three times as fast. A gas mask with a filter protects you. Shoot him from outside the mist.",
		["where"] = "Ashgrove: the pithead, the tailings, the infirmary and the upper terminal."
	},
	["drift"] = {
		["name"] = "Drift",
		["short"] = "DRIFT",
		["desc"] = "Standing guards of the ridge, frozen at their posts. The snow took their colour.",
		["special"] = "You cannot see it from far away. Watch for the puff of breath and listen for the crunch. A light on it shows it at once.",
		["where"] = "Ashgrove: the valley, Company Row, the upper terminal and the tailings. Outdoors only, in the snow."
	},
	["driller"] = {
		["name"] = "Driller",
		["short"] = "DRILLER",
		["desc"] = "A blaster who never took the drill off. The ear defenders keep him from hearing anything.",
		["special"] = "A cone of drilling in front of him hurts badly. Stay at his side or behind him and shoot the red tank on his back: it stuns him. The drill is loud and calls the infected.",
		["where"] = "Ashgrove: the pithead, the upper terminal, the ridge and the tailings. The Hollow: the old workings, Nightmare only."
	},
	["boss_witness"] = {
		["name"] = "The Witness",
		["short"] = "WITNESS",
		["desc"] = "Dr. Leland Marsh. He wanted to tell everything, and nobody came in time. He still dictates, and he plays back what he hears.",
		["special"] = "He records every noise and replays it from another wall, then charges to the replay. Shoot him there and every shot comes back. Bait him with a bottle. Later the stacks close in. Destroy the recorders, or play him his own tape.",
		["where"] = "Overture Plaza: the Stacks in the North Wing. All difficulties."
	},
	["boss_conductor"] = {
		["name"] = "The Conductor",
		["short"] = "CONDUCTOR",
		["desc"] = "Dr. Margit Lindahl. She led the Founders\' Choir for twelve years and the Sanctuary for ten days. She wants the piece to go on.",
		["special"] = "She fights to a four beat bar: be out of the cone on the second beat, and hit her on the third. Her audience wakes in rows on her cue. Cut the four relays to quieten the choir, pull the master reel to break her held note. A last bar played at the booth ends it without a fight.",
		["where"] = "Overture Plaza: Founders\' Hall. Hard and Nightmare."
	},
	["boss_foreman"] = {
		["name"] = "The Foreman",
		["short"] = "FOREMAN",
		["desc"] = "Gil Pryce. He told thirty eight men to stay quiet, and stayed himself. He has been listening at the pipe ever since.",
		["special"] = "His lamp is the only light in the yard. Every third knock drops the roof along a line through you: move when the dust falls. He breaks the supports one by one; shore them up. Later he calls the dark by hammering the pipe. Answer his knocks with three of your own.",
		["where"] = "Ashgrove: the pithead, at the Singing Pipe. All difficulties."
	},
	["jumper"] = {
		["name"] = "Rooftop Jumper",
		["short"] = "JUMPER",
		["desc"] = "Night shift workers who went up to the roofs when it started and never came down. They watch the street from the edge.",
		["special"] = "It crouches on a roof and waits. When you walk into its view a red circle grows on the street: step out of it before it lands. Staying close to a wall or inside a car keeps you out of its sight.",
		["where"] = "TOKYO: the high roofs of the neon streets, the arcades and the belt. A few per raid, more on Hard and Nightmare."
	},
	["sumo"] = {
		["name"] = "Sumo",
		["short"] = "SUMO",
		["desc"] = "A retired wrestler in a track suit. Slow, huge, and it takes a lot to bring him down.",
		["special"] = "He stamps twice, then charges in a straight line and cannot turn. Sidestep at the last moment. If he hits a wall or a door he is stunned and takes extra damage. Shoot the head, the body is armoured.",
		["where"] = "TOKYO: the quay, the depots, the alleys and the arcades."
	},
	["vaulter"] = {
		["name"] = "Freerunner",
		["short"] = "FREERUNNER",
		["desc"] = "A parkour runner of the neon streets. Light, fast and mean.",
		["special"] = "He ducks, then jumps at you from a distance and clears cars, fences and benches on the way. Do not count on an obstacle to hold him. He has little health, one good burst ends him.",
		["where"] = "TOKYO: the neon streets, the arcades, the station and the alleys."
	},
	["kacho"] = {
		["name"] = "Section Chief",
		["short"] = "CHIEF",
		["desc"] = "A department head in a grey suit with a briefcase. Even now he calls for overtime.",
		["special"] = "He keeps his distance and calls: everyone near him runs faster for a few seconds and the noise wakes sleepers. Break his line of sight or kill him first and the bonus ends at once.",
		["where"] = "TOKYO: the station, the neon streets and the department store."
	},
	["boss_dj"] = {
		["name"] = "The DJ",
		["short"] = "DJ",
		["desc"] = "DJ Nemuri. Resident DJ of the club UNDERTONE. He has not stopped playing since the first night, and the floor follows him.",
		["special"] = "The music is his weapon and his shield. Make a noise at the running deck and he is open for a few seconds. In his second act the music shields him: cut it to break him. When he calls for noise, keep still. When the tape runs out, take it or cut it. Nothing but his life bar defeats him.",
		["where"] = "TOKYO: club UNDERTONE. Hard and Nightmare."
	},
	["boss_colonel"] = {
		["name"] = "The Colonel",
		["short"] = "COLONEL",
		["desc"] = "Colonel Harlan Voss. He wrote every order of this war from a desk on a ridge. The orders go on without him.",
		["special"] = "The teleprinter prints an order and he carries it out: lights out, doors locked, fire on sight. Then he seals the corridors one by one. Defuse the charges while a friend draws his fire. Break the teleprinter. A recorded order stands him down for good.",
		["where"] = "Ashgrove: the Teleprinter Hall of the Ridge Station. Hard and Nightmare."
	}
}
function v_u_13.info(p15) -- name: info
	-- upvalues: (copy) v_u_14
	return v_u_14[p15] or {
		["name"] = nil,
		["short"] = nil,
		["desc"] = "",
		["special"] = "",
		["where"] = "",
		["name"] = p15,
		["short"] = string.upper(p15)
	}
end
local v_u_16 = {
	["boss_surgeon"] = "Hard or Nightmare only.",
	["boss_hale"] = "Nightmare only. Nightmare opens after Doc\'s task PATIENT ZERO.",
	["boss_dj"] = "Lives in TOKYO. Hard and Nightmare only."
}
function v_u_13.gate(p17, p18, p19) -- name: gate
	-- upvalues: (copy) v_u_16, (copy) v_u_13
	local v20 = v_u_16[p17]
	if v20 and (p19 == true and p17 == "boss_hale") then
		return "Nightmare only. Nightmare opens when you defeat a boss on Hard on Stillwater."
	end
	if v20 then
		return v20
	end
	local v21 = v_u_13.info(p17).where
	local v22 = string.find(v21, "Hard and Nightmare", 1, true) ~= nil
	if string.sub(v21, 1, 10) == "The Hollow" then
		local v23 = tonumber(p18) or 15
		local v24 = math.floor(v23)
		return "Lives in The Hollow." .. (v22 and " Hard and Nightmare only." or "") .. (v24 <= 0 and "" or (" The map opens after %d finished raids."):format(v24))
	end
	if string.sub(v21, 1, 13) == "Kestrel Field" then
		return "Lives in Kestrel Field." .. (v22 and " Hard and Nightmare only." or "") .. (p19 == true and "" or " The map opens after the missions MANIFEST and PAGE TWO.")
	end
	local v25 = {}
	for _, v26 in {
		"Stillwater",
		"Overture Plaza",
		"Ashgrove",
		"Kestrel Field",
		"The Hollow"
	} do
		if not string.find(v21, v26, 1, true) then
			continue
		end
		table.insert(v25, v26)
	end
	if #v25 <= 0 or string.sub(v21, 1, 14) ~= "Overture Plaza" and string.sub(v21, 1, 8) ~= "Ashgrove" then
		return nil
	end
	local v27
	if #v25 == 1 then
		v27 = v25[1]
	else
		v27 = table.concat(v25, ", ", 1, #v25 - 1) .. " and " .. v25[#v25]
	end
	return "Found in " .. v27 .. "." .. (string.find(v21, "Hard and Nightmare%.$") and " Hard and Nightmare only." or (string.find(v21, "Nightmare only%.$") and " Nightmare only." or ""))
end
v_u_13.INFECT = {
	["Normal"] = {
		["bite"] = 0.5,
		["tear"] = 0.1,
		["scratch"] = 0
	},
	["Hard"] = {
		["bite"] = 1,
		["tear"] = 0.25,
		["scratch"] = 0.07
	},
	["Nightmare"] = {
		["bite"] = 1,
		["tear"] = 0.25,
		["scratch"] = 0.07
	}
}
v_u_13.POP_MIN = 60
v_u_13.POP_MAX = 720
local v_u_28 = { "Normal", "Hard", "Nightmare" }
local function v_u_31(p29) -- name: chanceWord
	if p29 >= 0.999 then
		return "always"
	end
	if p29 <= 0 then
		return "never"
	end
	local v30 = p29 * 100 + 0.5
	return ("%d %%"):format((math.floor(v30)))
end
function v_u_13.infectionText(p32, p33, p34, p35) -- name: infectionText
	-- upvalues: (copy) v_u_28, (copy) v_u_13, (copy) v_u_31
	local v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v59
	if p34 then
		local v60 = p34.ORDER
		if type(v60) == "table" then
			v36 = p34.ORDER
			v37 = {}
			if p33 and p33.ranged ~= nil or (p32 == "looter" or p32 == "boss_hale") then
				table.insert(v37, "Its bullets never infect, its blows can.")
			end
			v38 = {}
			for v73, v74 in v36 do
				v39 = v_u_13.INFECT[v74]
				if not v39 then
					continue
				end
				v40 = v38[#v38]
				if v40 and (v40.c.bite == v39.bite and (v40.c.tear == v39.tear and v40.c.scratch == v39.scratch)) then
					v41 = v40.names
					table.insert(v41, v74)
				else
					table.insert(v38, {
						["names"] = { v74 },
						["c"] = v39
					})
				end
			end
			for v75, v76 in v38 do
				v42 = table.concat(v76.names, " and ")
				v43 = v76.c.bite
				if v43 >= 0.999 then
					v44 = "every bite infects"
				elseif v43 <= 0 then
					v44 = "bites never infect"
				else
					v45 = v43 - 0.5
					v44 = math.abs(v45) < 0.001 and "half the bites infect" or ("%s of bites infect"):format(v_u_31(v43))
				end
				v46 = "%s: %s, deep cuts %s, scratches %s."
				v47 = v76.c.tear
				if v47 >= 0.999 then
					v48 = "always"
				elseif v47 <= 0 then
					v48 = "never"
				else
					v49 = v47 * 100 + 0.5
					v48 = ("%d %%"):format((math.floor(v49)))
				end
				v50 = v_u_31
				v51 = v76.c.scratch
				table.insert(v37, v46:format(v42, v44, v48, v50(v51)))
			end
			if p35 then
				v52 = {
					["Normal"] = "INFECTION_TIME",
					["Hard"] = "INFECTION_TIME_HARD",
					["Nightmare"] = "INFECTION_TIME_NIGHTMARE"
				}
				v53 = {}
				for v77, v78 in v36 do
					v54 = p35[v52[v78] or ""]
					v55 = tonumber(v54)
					if not v55 then
						continue
					end
					v56 = v55 + 0.5
					v57 = math.floor(v56)
					v58 = ("%d:%02d"):format(v57 // 60, v57 % 60)
					table.insert(v53, ("%s %s"):format(v58, v78))
				end
				if #v53 > 0 then
					v59 = "Then the timer runs: " .. table.concat(v53, ", ") .. ". Antiviral capsules buy time."
					table.insert(v37, v59)
				end
			end
			return table.concat(v37, " ")
		else
			v36 = v_u_28
			v37 = {}
			if p33 and p33.ranged ~= nil or (p32 == "looter" or p32 == "boss_hale") then
				table.insert(v37, "Its bullets never infect, its blows can.")
			end
			v38 = {}
			for v73, v74 in v36 do
				v39 = v_u_13.INFECT[v74]
				if not v39 then
					continue
				end
				v40 = v38[#v38]
				if v40 and (v40.c.bite == v39.bite and (v40.c.tear == v39.tear and v40.c.scratch == v39.scratch)) then
					v41 = v40.names
					table.insert(v41, v74)
				else
					table.insert(v38, {
						["names"] = { v74 },
						["c"] = v39
					})
				end
			end
			for v75, v76 in v38 do
				v42 = table.concat(v76.names, " and ")
				v43 = v76.c.bite
				if v43 >= 0.999 then
					v44 = "every bite infects"
				elseif v43 <= 0 then
					v44 = "bites never infect"
				else
					v45 = v43 - 0.5
					v44 = math.abs(v45) < 0.001 and "half the bites infect" or ("%s of bites infect"):format(v_u_31(v43))
				end
				v46 = "%s: %s, deep cuts %s, scratches %s."
				v47 = v76.c.tear
				if v47 >= 0.999 then
					v48 = "always"
				elseif v47 <= 0 then
					v48 = "never"
				else
					v49 = v47 * 100 + 0.5
					v48 = ("%d %%"):format((math.floor(v49)))
				end
				v50 = v_u_31
				v51 = v76.c.scratch
				table.insert(v37, v46:format(v42, v44, v48, v50(v51)))
			end
			if p35 then
				v52 = {
					["Normal"] = "INFECTION_TIME",
					["Hard"] = "INFECTION_TIME_HARD",
					["Nightmare"] = "INFECTION_TIME_NIGHTMARE"
				}
				v53 = {}
				for v77, v78 in v36 do
					v54 = p35[v52[v78] or ""]
					v55 = tonumber(v54)
					if not v55 then
						continue
					end
					v56 = v55 + 0.5
					v57 = math.floor(v56)
					v58 = ("%d:%02d"):format(v57 // 60, v57 % 60)
					table.insert(v53, ("%s %s"):format(v58, v78))
				end
				if #v53 > 0 then
					v59 = "Then the timer runs: " .. table.concat(v53, ", ") .. ". Antiviral capsules buy time."
					table.insert(v37, v59)
				end
			end
			return table.concat(v37, " ")
		end
	else
		v36 = v_u_28
		v37 = {}
		if p33 and p33.ranged ~= nil or (p32 == "looter" or p32 == "boss_hale") then
			table.insert(v37, "Its bullets never infect, its blows can.")
		end
		v38 = {}
		for v73, v74 in v36 do
			v39 = v_u_13.INFECT[v74]
			if not v39 then
				continue
			end
			v40 = v38[#v38]
			if v40 and (v40.c.bite == v39.bite and (v40.c.tear == v39.tear and v40.c.scratch == v39.scratch)) then
				v41 = v40.names
				table.insert(v41, v74)
			else
				table.insert(v38, {
					["names"] = { v74 },
					["c"] = v39
				})
			end
		end
		for v75, v76 in v38 do
			v42 = table.concat(v76.names, " and ")
			v43 = v76.c.bite
			if v43 >= 0.999 then
				v44 = "every bite infects"
			elseif v43 <= 0 then
				v44 = "bites never infect"
			else
				v45 = v43 - 0.5
				v44 = math.abs(v45) < 0.001 and "half the bites infect" or ("%s of bites infect"):format(v_u_31(v43))
			end
			v46 = "%s: %s, deep cuts %s, scratches %s."
			v47 = v76.c.tear
			if v47 >= 0.999 then
				v48 = "always"
			elseif v47 <= 0 then
				v48 = "never"
			else
				v49 = v47 * 100 + 0.5
				v48 = ("%d %%"):format((math.floor(v49)))
			end
			v50 = v_u_31
			v51 = v76.c.scratch
			table.insert(v37, v46:format(v42, v44, v48, v50(v51)))
		end
		if p35 then
			v52 = {
				["Normal"] = "INFECTION_TIME",
				["Hard"] = "INFECTION_TIME_HARD",
				["Nightmare"] = "INFECTION_TIME_NIGHTMARE"
			}
			v53 = {}
			for v77, v78 in v36 do
				v54 = p35[v52[v78] or ""]
				v55 = tonumber(v54)
				if not v55 then
					continue
				end
				v56 = v55 + 0.5
				v57 = math.floor(v56)
				v58 = ("%d:%02d"):format(v57 // 60, v57 % 60)
				table.insert(v53, ("%s %s"):format(v58, v78))
			end
			if #v53 > 0 then
				v59 = "Then the timer runs: " .. table.concat(v53, ", ") .. ". Antiviral capsules buy time."
				table.insert(v37, v59)
			end
		end
		return table.concat(v37, " ")
	end
end
function v_u_13.population(p79) -- name: population
	-- upvalues: (copy) v_u_28, (copy) v_u_13
	local v80 = {}
	if p79 then
		local v81 = p79.get
		if type(v81) == "function" then
			local v82 = p79.BASE_ZOMBIES
			local v83 = tonumber(v82) or 400
			local v84 = p79.MAX_DENSITY
			local v85 = tonumber(v84) or (1 / 0)
			local v86 = p79.ORDER
			local v87
			if type(v86) == "table" then
				v87 = p79.ORDER
			else
				v87 = v_u_28
			end
			for _, v88 in v87 do
				local v89 = p79.get
				local v90, v91 = pcall(v89, v88)
				local v92
				if v90 and type(v91) == "table" then
					local v93 = v91.density
					v92 = tonumber(v93) or nil
				else
					v92 = nil
				end
				if not v92 then
					continue
				end
				local v94 = v83 * math.min(v92, v85) + 0.5
				local v95 = math.floor(v94)
				local v96 = v_u_13.POP_MIN
				local v97 = v_u_13.POP_MAX
				v80[v88] = math.clamp(v95, v96, v97)
			end
			return v80
		end
	end
	return v80
end
function v_u_13.populationText(p98) -- name: populationText
	-- upvalues: (copy) v_u_13, (copy) v_u_28
	local v99 = v_u_13.population(p98)
	local v100 = {}
	local v101, v102, v103, v104, v105, v106
	if p98 then
		local v107 = p98.ORDER
		if type(v107) == "table" then
			v101 = p98.ORDER
			for v112, v113 in v101 do
				v102 = v99[v113]
				if not v102 then
					continue
				end
				v103 = v102 / 10 + 0.5
				v104 = math.floor(v103) * 10
				if #v100 == 0 then
					v105 = ("%d infected on %s"):format(v104, v113)
				else
					v105 = ("%d on %s"):format(v104, v113)
				end
				table.insert(v100, v105)
			end
			if #v100 == 0 then
				return ""
			end
			if #v100 == 1 then
				v106 = v100[1]
			else
				v106 = table.concat(v100, ", ", 1, #v100 - 1) .. " and " .. v100[#v100]
			end
			return "A solo raid holds about " .. v106 .. ". A squad meets more."
		else
			v101 = v_u_28
			for v112, v113 in v101 do
				v102 = v99[v113]
				if not v102 then
					continue
				end
				v103 = v102 / 10 + 0.5
				v104 = math.floor(v103) * 10
				if #v100 == 0 then
					v105 = ("%d infected on %s"):format(v104, v113)
				else
					v105 = ("%d on %s"):format(v104, v113)
				end
				table.insert(v100, v105)
			end
			if #v100 == 0 then
				return ""
			end
			if #v100 == 1 then
				v106 = v100[1]
			else
				v106 = table.concat(v100, ", ", 1, #v100 - 1) .. " and " .. v100[#v100]
			end
			return "A solo raid holds about " .. v106 .. ". A squad meets more."
		end
	else
		v101 = v_u_28
		for v112, v113 in v101 do
			v102 = v99[v113]
			if not v102 then
				continue
			end
			v103 = v102 / 10 + 0.5
			v104 = math.floor(v103) * 10
			if #v100 == 0 then
				v105 = ("%d infected on %s"):format(v104, v113)
			else
				v105 = ("%d on %s"):format(v104, v113)
			end
			table.insert(v100, v105)
		end
		if #v100 == 0 then
			return ""
		end
		if #v100 == 1 then
			v106 = v100[1]
		else
			v106 = table.concat(v100, ", ", 1, #v100 - 1) .. " and " .. v100[#v100]
		end
		return "A solo raid holds about " .. v106 .. ". A squad meets more."
	end
end
function v_u_13.hpFor(p_u_114, p_u_115, p_u_116) -- name: hpFor
	local v117
	if p_u_114 then
		v117 = p_u_114.hp
	else
		v117 = p_u_114
	end
	local v118 = tonumber(v117) or 0
	if not (p_u_114 and p_u_115) then
		return v118
	end
	local v119 = 1
	local v124, v125 = pcall(function()
		-- upvalues: (copy) p_u_114, (copy) p_u_115, (copy) p_u_116
		if p_u_114.boss then
			local v120 = p_u_115.boss(p_u_116).hpMul
			return tonumber(v120)
		end
		local v121 = p_u_115.get(p_u_116).hpMul
		local v122 = tonumber(v121) or 1
		if p_u_114.ranged and p_u_114.kind == nil then
			local v123 = p_u_115.armed(p_u_116).hpMul
			v122 = v122 * (tonumber(v123) or 1)
		end
		return v122
	end)
	if v124 then
		if type(v125) ~= "number" then
			v125 = v119
		end
	else
		v125 = v119
	end
	local v126 = v118 * v125 + 0.5
	return math.floor(v126)
end
function v_u_13.hpText(p127, p128) -- name: hpText
	-- upvalues: (copy) v_u_28, (copy) v_u_13
	local v129, v130, v131, v132, v133, v134, v135, v136, v137
	if p128 then
		local v138 = p128.ORDER
		if type(v138) == "table" then
			v129 = p128.ORDER
			v130 = {}
			v131 = true
			for v145, v146 in v129 do
				v132 = v_u_13.hpFor(p127, p128, v146)
				table.insert(v130, v132)
				if v132 == v130[1] then
					continue
				end
				v131 = false
			end
			if v131 or #v130 == 0 then
				return nil
			end
			v133 = {}
			for v147 = 1, #v130 do
				v134 = v129[v147]
				v135 = tostring(v134)
				v136 = v130[v147]
				table.insert(v133, ("%s %d"):format(v135, v136))
			end
			if #v133 == 1 then
				v137 = v133[1]
			else
				v137 = table.concat(v133, ", ", 1, #v133 - 1) .. " and " .. v133[#v133]
			end
			return "HP by difficulty: " .. v137 .. "."
		else
			v129 = v_u_28
			v130 = {}
			v131 = true
			for v145, v146 in v129 do
				v132 = v_u_13.hpFor(p127, p128, v146)
				table.insert(v130, v132)
				if v132 == v130[1] then
					continue
				end
				v131 = false
			end
			if v131 or #v130 == 0 then
				return nil
			end
			v133 = {}
			for v147 = 1, #v130 do
				v134 = v129[v147]
				v135 = tostring(v134)
				v136 = v130[v147]
				table.insert(v133, ("%s %d"):format(v135, v136))
			end
			if #v133 == 1 then
				v137 = v133[1]
			else
				v137 = table.concat(v133, ", ", 1, #v133 - 1) .. " and " .. v133[#v133]
			end
			return "HP by difficulty: " .. v137 .. "."
		end
	else
		v129 = v_u_28
		v130 = {}
		v131 = true
		for v145, v146 in v129 do
			v132 = v_u_13.hpFor(p127, p128, v146)
			table.insert(v130, v132)
			if v132 == v130[1] then
				continue
			end
			v131 = false
		end
		if v131 or #v130 == 0 then
			return nil
		end
		v133 = {}
		for v147 = 1, #v130 do
			v134 = v129[v147]
			v135 = tostring(v134)
			v136 = v130[v147]
			table.insert(v133, ("%s %d"):format(v135, v136))
		end
		if #v133 == 1 then
			v137 = v133[1]
		else
			v137 = table.concat(v133, ", ", 1, #v133 - 1) .. " and " .. v133[#v133]
		end
		return "HP by difficulty: " .. v137 .. "."
	end
end
function v_u_13.numbers(p148, p149) -- name: numbers
	-- upvalues: (copy) v_u_13
	local v150 = {}
	if not p148 then
		return v150
	end
	local v151 = p148.speedChase
	local v152 = tonumber(v151) or 6
	local v153 = v152 + 0.5
	local v154 = v152 - math.floor(v153)
	local v155
	if math.abs(v154) < 0.05 then
		local v156 = v152 + 0.5
		v155 = ("%d"):format((math.floor(v156)))
	else
		v155 = ("%.1f"):format(v152)
	end
	v150.Speed = v155 .. " studs/s"
	local v157 = v_u_13.hpFor(p148, p149, "Normal")
	local v158 = v157 + 0.5
	local v159 = v157 - math.floor(v158)
	local v160
	if math.abs(v159) < 0.05 then
		local v161 = v157 + 0.5
		v160 = ("%d"):format((math.floor(v161)))
	else
		v160 = ("%.1f"):format(v157)
	end
	v150.Toughness = v160 .. " HP"
	local v162 = p148.damage
	local v163 = tonumber(v162) or 10
	local v164 = v163 + 0.5
	local v165 = v163 - math.floor(v164)
	local v166
	if math.abs(v165) < 0.05 then
		local v167 = v163 + 0.5
		v166 = ("%d"):format((math.floor(v167)))
	else
		v166 = ("%.1f"):format(v163)
	end
	if p148.ranged then
		local v168 = " / "
		local v169 = p148.ranged.damage
		local v170 = tonumber(v169) or 0
		local v171 = v170 + 0.5
		local v172 = v170 - math.floor(v171)
		local v173
		if math.abs(v172) < 0.05 then
			local v174 = v170 + 0.5
			v173 = ("%d"):format((math.floor(v174)))
		else
			v173 = ("%.1f"):format(v170)
		end
		v166 = v166 .. v168 .. v173 .. " ranged"
	end
	v150.Damage = v166
	if p148.blind then
		v150.Senses = "Blind, hears all"
		return v150
	end
	local v175 = "Sight %s, hearing x%.1f"
	local v176 = p148.sightRange
	local v177 = tonumber(v176) or 25
	local v178 = v177 + 0.5
	local v179 = v177 - math.floor(v178)
	local v180
	if math.abs(v179) < 0.05 then
		local v181 = v177 + 0.5
		v180 = ("%d"):format((math.floor(v181)))
	else
		v180 = ("%.1f"):format(v177)
	end
	local v182 = p148.hearing
	v150.Senses = v175:format(v180, tonumber(v182) or 1)
	return v150
end
local v_u_183 = {
	{ "hollow point", 0.05 },
	{ "FMJ", 0.5 },
	{ "armor piercing", 0.9 }
}
local v_u_184 = {
	{ "torso", "Vest" },
	{ "head", "Helmet" }
}
function v_u_13.armorMuls(p185, p186, p187) -- name: armorMuls
	-- upvalues: (copy) v_u_183
	local v188 = {}
	for _, v189 in v_u_183 do
		local v190 = p186.damageMul(p185, p187, v189[2], false, false)
		table.insert(v188, v190)
	end
	local v191 = p186.damageMul(p185, p187, nil, true, false)
	table.insert(v188, v191)
	return v188
end
function v_u_13.armorLines(p192, p193) -- name: armorLines
	-- upvalues: (copy) v_u_184, (copy) v_u_13
	local v194 = {}
	if p192 and p193 then
		local v195 = p193.damageMul
		if type(v195) == "function" then
			local v196 = p192.armor
			local v197 = tonumber(v196) or 1
			if v197 < 0.999 then
				local v198 = v197 * 100 + 0.5
				local v199 = math.floor(v198)
				table.insert(v194, ("Body: x%.2f. Everything but a headshot does %d percent of its damage."):format(v197, v199))
			else
				table.insert(v194, "Body: x1.00. Nothing is stopped, every hit counts in full.")
			end
			local v200 = 0
			for _, v201 in v_u_184 do
				local v202
				if p192.armorParts then
					v202 = p192.armorParts[v201[1]]
				else
					v202 = nil
				end
				if not v202 then
					continue
				end
				v200 = v200 + 1
				local v203 = v_u_13.armorMuls(p192, p193, v201[1])
				local v204 = v201[2]
				local v205 = v202.cls
				local v206 = tonumber(v205) or 0
				local v207 = v203[1]
				local v208 = v203[2]
				local v209 = v203[3]
				local v210 = v203[4]
				table.insert(v194, ("%s (class %d): hollow point x%.2f, FMJ x%.2f, armor piercing x%.2f, blows x%.2f."):format(v204, v206, v207, v208, v209, v210))
			end
			if v200 == 0 then
				table.insert(v194, "No plates: a headshot takes x1.00 and there is no vest to get through.")
			end
			if p192.shield then
				local v211 = p192.shield.mul
				local v212 = tonumber(v211) or 1
				local v213 = p192.shield.meleeMul
				local v214 = tonumber(v213) or 1
				local v215 = p192.shield.hp
				local v216 = tonumber(v215) or 0
				local v217 = math.floor(v216)
				table.insert(v194, ("Shield in front: shots do x%.2f and blows x%.2f until it breaks (%d points)."):format(v212, v214, v217))
			end
			table.insert(v194, "A multiplier cuts the damage of one hit. Penetration lets a round ignore part of a plate: armor piercing most, hollow point almost none. Blows never drop below x0.6 on a plate. A blow on an infected lying on the ground goes through everything.")
			return v194
		end
	end
	return v194
end
local v_u_218 = Color3.fromRGB(92, 98, 108)
local v_u_219 = Color3.fromRGB(255, 238, 212)
local function v_u_256(p220) -- name: measureRig
	local v221 = (1 / 0)
	local v222 = (-1 / 0)
	local v223 = {}
	for _, v224 in p220.model:GetDescendants() do
		if not v224:IsA("BasePart") or (v224 == p220.root or v224.Transparency >= 0.9) then
			continue
		end
		local v225 = v224.Size / 2
		for _, v226 in { -1, 1 } do
			for _, v227 in { -1, 1 } do
				for _, v228 in { -1, 1 } do
					local v229 = v224.CFrame
					local v230 = v225.X * v226
					local v231 = v225.Y * v227
					local v232 = v225.Z * v228
					local v233 = v229 * Vector3.new(v230, v231, v232)
					local v234 = v233.Y
					v221 = math.min(v221, v234)
					local v235 = v233.Y
					v222 = math.max(v222, v235)
					table.insert(v223, v233)
				end
			end
		end
	end
	if #v223 == 0 then
		p220.focus = Vector3.new(0, 2.8, 0)
		p220.half = 3.2
		p220.radius = 1.5
		return
	else
		local v236 = (1 / 0)
		local v237 = (-1 / 0)
		local v238 = (1 / 0)
		local v239 = (-1 / 0)
		for _, v240 in v223 do
			local v241 = v240.X
			v236 = math.min(v236, v241)
			local v242 = v240.X
			v237 = math.max(v237, v242)
			local v243 = v240.Z
			v238 = math.min(v238, v243)
			local v244 = v240.Z
			v239 = math.max(v239, v244)
		end
		local v245 = (v236 + v237) / 2
		local v246 = (v238 + v239) / 2
		local v247 = 0
		for _, v248 in v223 do
			local v249 = (v248.X - v245) ^ 2 + (v248.Z - v246) ^ 2
			local v250 = math.sqrt(v249)
			v247 = math.max(v247, v250)
		end
		local v251 = (v222 - math.min(v221, 0)) / 2
		p220.radius = v247
		if p220.lying then
			local v252 = math.min(v221, 0) + v251
			p220.focus = Vector3.new(v245, v252, v246)
			local v253 = v247 * 0.92
			p220.half = math.max(v253, v251) * 1.08
		else
			local v254 = math.min(v221, 0) + v251
			p220.focus = Vector3.new(v245, v254, v246)
			local v255 = v247 * 0.85
			p220.half = math.max(v251, v255) * 1.16
		end
	end
end
local function v_u_270(p257, p258, p259, p260) -- name: frameCam
	local v261 = p258.focus
	local v262 = p258.half
	local v263 = p258.lying and 0.5235987755982988 or 0.12217304763960307
	if p260 < 1 then
		v262 = v262 / math.max(p260, 0.5)
	end
	local v264 = v262 / 0.2679491924311227 + (p258.radius or 1) * 0.5
	local v265 = math.sin(p259)
	local v266 = -math.cos(p259)
	local v267 = v261 + Vector3.new(v265, 0, v266) * (v264 * math.cos(v263))
	local v268 = v264 * math.sin(v263)
	local v269 = v267 + Vector3.new(0, v268, 0)
	p257.CFrame = CFrame.lookAt(v269, v261)
end
local function v_u_275(p271, p272) -- name: newInputs
	local v273 = {
		["state"] = nil,
		["speed"] = 0,
		["kind"] = nil,
		["style"] = 1,
		["seed"] = 0.37,
		["t"] = 0,
		["act"] = 0,
		["actDur"] = 1,
		["flinch"] = 0,
		["flinchX"] = 0,
		["flinchZ"] = 0,
		["deathSign"] = 1,
		["wasLying"] = false,
		["legless"] = false,
		["human"] = nil,
		["riseFromLying"] = false,
		["headshot"] = false,
		["limp"] = false,
		["armsHurt"] = false,
		["hitPart"] = 0,
		["hitKick"] = 0,
		["variant"] = nil,
		["notice"] = -1,
		["ring"] = 0,
		["lieVariant"] = nil,
		["climb"] = false,
		["state"] = p271 == "sleeper" and 11 or 0,
		["kind"] = p271
	}
	local v274
	if p272 == nil then
		v274 = false
	else
		v274 = p272.human == true
	end
	v273.human = v274
	return v273
end
function v_u_13.new(p276, p277) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_3, (copy) v_u_275, (copy) v_u_218, (copy) v_u_219, (copy) v_u_270, (copy) v_u_256, (copy) v_u_2
	local v_u_278 = p276.ui
	local v_u_279 = p276.theme
	local v_u_280 = v_u_279.color
	local v_u_281 = p276.kit
	local v_u_282 = p276.cctx
	local v_u_283 = p277 or {}
	local v_u_284 = v_u_1.LocalPlayer
	local v_u_285 = {}
	local v_u_286 = nil
	local function v287()
		-- upvalues: (ref) v_u_286, (copy) v_u_282
		v_u_286 = v_u_282.shared.ZombieTypes
	end
	pcall(v287)
	local v_u_288 = nil
	local function v289()
		-- upvalues: (ref) v_u_288, (copy) v_u_282
		v_u_288 = v_u_282.lib.ZombieAnimPose
	end
	pcall(v289)
	local v_u_290 = nil
	local function v291()
		-- upvalues: (ref) v_u_290, (copy) v_u_282
		v_u_290 = v_u_282.shared.Difficulty
	end
	pcall(v291)
	local function v_u_298(p292) -- name: gateText
		-- upvalues: (copy) v_u_282, (ref) v_u_13
		local v_u_293 = nil
		local function v294()
			-- upvalues: (ref) v_u_293, (ref) v_u_282
			v_u_293 = v_u_282.shared.MapUnlock.need("hollow")
		end
		pcall(v294)
		local v_u_295 = false
		local function v296()
			-- upvalues: (ref) v_u_295, (ref) v_u_282
			v_u_295 = v_u_282.shared.MapLadder.enabled() ~= false
		end
		pcall(v296)
		local v297 = v_u_13.gate(p292, v_u_293, v_u_295)
		return not v297 and "" or " " .. v297
	end
	local v_u_299 = {}
	local v_u_300 = {}
	local v_u_301 = nil
	local v_u_302 = nil
	local v_u_303 = false
	local v_u_304 = nil
	local v_u_305 = nil
	local v_u_306 = nil
	local v_u_307 = false
	local v_u_308 = os.clock()
	local v_u_309 = 0
	local v_u_310 = 0
	local v_u_311 = false
	local v_u_312 = {}
	local function v_u_329(p313) -- name: buildRig
		-- upvalues: (copy) v_u_282, (ref) v_u_286, (ref) v_u_3, (ref) v_u_288, (ref) v_u_275
		local v314 = v_u_282.controllers.ZombieRender
		if v314 then
			local v315 = v314.previewRig
			if type(v315) == "function" then
				local v316
				if v_u_286 and v_u_286.get then
					v316 = v_u_286.get(p313)
				else
					v316 = nil
				end
				local v317
				if v316 and v316.model then
					v317 = v316.model
				else
					v317 = p313
				end
				local v318 = v314.previewRig
				local v319, v_u_320 = pcall(v318, v317)
				if not v319 or type(v_u_320) ~= "table" then
					local v321 = v_u_3:FindFirstChild("HushRuntime")
					if v321 then
						v321 = v321:FindFirstChild("ZombieTemplates")
					end
					if v321 then
						v321 = v321:FindFirstChild("Roblox")
					end
					if v321 and v321:GetAttribute("LobbyR37") == "building" then
						return nil
					end
					for _, v322 in { "walker", "runner", "crawler" } do
						local v323 = v314.previewRig
						v319, v_u_320 = pcall(v323, v322)
						if not v319 or type(v_u_320) ~= "table" then
							continue
						end
					end
				end
				if not v319 or type(v_u_320) ~= "table" then
					return nil
				end
				local v324
				if v316 == nil then
					v324 = false
				else
					v324 = v316.lying == true
				end
				v_u_320.lying = v324
				v_u_320.id = p313
				local v325 = 0
				for _, v326 in v_u_320.model:GetDescendants() do
					if not v326:IsA("BasePart") then
						continue
					end
					v325 = v325 + 1
				end
				v_u_320.parts = v325
				if v_u_288 and v_u_320.pose then
					local v_u_327 = v_u_275(p313, v316)
					local function v328()
						-- upvalues: (ref) v_u_288, (copy) v_u_320, (copy) v_u_327
						v_u_288.update(v_u_320.pose, v_u_327, 0.016666666666666666)
						v_u_288.snap(v_u_320.pose)
						v_u_288.apply(v_u_320.pose, 0)
					end
					pcall(v328)
				end
				return v_u_320
			end
		end
		return nil
	end
	local function v_u_339(p330, p331, p332, p333, p334) -- name: newViewport
		-- upvalues: (copy) v_u_278, (ref) v_u_218, (ref) v_u_219
		local v335 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Position"] = nil,
			["Ambient"] = nil,
			["LightColor"] = nil,
			["LightDirection"] = Vector3.new(-0.55, -1, 0.65),
			["ZIndex"] = nil,
			["Name"] = p331,
			["Size"] = p332,
			["Position"] = p333,
			["Ambient"] = v_u_218,
			["LightColor"] = v_u_219,
			["ZIndex"] = p334
		}
		local v336 = v_u_278.new("ViewportFrame", v335, p330)
		local v337 = Instance.new("Camera")
		v337.FieldOfView = 30
		v337.Parent = v336
		v336.CurrentCamera = v337
		local v338 = Instance.new("WorldModel")
		v338.Name = "World"
		v338.Parent = v336
		return v336
	end
	local function v_u_348(p340, p341) -- name: floor
		local v342 = Instance.new("Part")
		v342.Name = "Floor"
		v342.Shape = Enum.PartType.Cylinder
		v342.Anchored = true
		v342.CanCollide = false
		v342.CanQuery = false
		v342.CanTouch = false
		v342.Material = Enum.Material.Concrete
		v342.Color = Color3.fromRGB(38, 42, 48)
		local v343 = (p341.radius or 1.5) * 1.15
		local v344 = math.clamp(v343, 2.2, 6)
		local v345 = v344 * 2
		local v346 = v344 * 2
		v342.Size = Vector3.new(0.2, v345, v346)
		local v347 = p341.focus or Vector3.new(0, 0, 0)
		v342.CFrame = CFrame.new(v347.X, -0.1, v347.Z) * CFrame.Angles(0, 0, 1.5707963267948966)
		v342.Parent = p340
	end
	local function v_u_355(p349, p350, p351) -- name: place
		-- upvalues: (copy) v_u_348, (ref) v_u_270
		local v352 = p349:FindFirstChild("World")
		if v352 and not v352:FindFirstChild("Floor") then
			v_u_348(v352, p350)
		end
		local v353 = p349.CurrentCamera
		if v353 then
			local v354 = p349.AbsoluteSize
			v_u_270(v353, p350, p351, v354.Y <= 1 and 1 or v354.X / v354.Y)
		end
	end
	local function v_u_361(p_u_356, p_u_357, p_u_358) -- name: mount
		-- upvalues: (copy) v_u_355, (ref) v_u_256, (ref) v_u_2
		local v_u_359 = p_u_356:FindFirstChild("World")
		if v_u_359 then
			p_u_357.model.Parent = v_u_359
			if p_u_357.measured then
				v_u_355(p_u_356, p_u_357, p_u_358)
			else
				v_u_256(p_u_357)
				v_u_355(p_u_356, p_u_357, p_u_358)
				task.spawn(function()
					-- upvalues: (ref) v_u_2, (copy) p_u_357, (copy) v_u_359, (copy) p_u_356, (ref) v_u_256, (ref) v_u_355, (copy) p_u_358
					v_u_2.Heartbeat:Wait()
					if p_u_357.model.Parent == v_u_359 and p_u_356.Parent then
						v_u_256(p_u_357)
						p_u_357.measured = true
						local v360 = v_u_359:FindFirstChild("Floor")
						if v360 then
							v360:Destroy()
						end
						v_u_355(p_u_356, p_u_357, p_u_358)
					end
				end)
			end
		else
			return
		end
	end
	local function v_u_368(p362) -- name: paintCell
		-- upvalues: (ref) v_u_305, (copy) v_u_280
		local v363 = v_u_305 == p362.id
		local v364 = p362.btn
		local v365
		if v363 then
			v365 = v_u_280.accentDeep
		else
			v365 = v_u_280.raised
		end
		v364.BackgroundColor3 = v365
		local v366 = p362.stroke
		local v367
		if v363 or p362.hover then
			v367 = v_u_280.accent
		elseif p362.boss then
			v367 = v_u_280.danger:Lerp(v_u_280.line, 0.45)
		else
			v367 = v_u_280.line
		end
		v366.Color = v367
		p362.stroke.Thickness = v363 and 2 or 1
	end
	local function v_u_372(p369) -- name: tryMount
		-- upvalues: (copy) v_u_299, (copy) v_u_329, (copy) v_u_339, (copy) v_u_361
		if p369.mounted or not p369.btn.Parent then
			return p369.mounted
		end
		local v370 = v_u_299[p369.id]
		if not v370 then
			v370 = v_u_329(p369.id)
			if not v370 then
				return false
			end
			v_u_299[p369.id] = v370
		end
		local v371 = v_u_339(p369.btn, "Preview", UDim2.new(1, -4, 1, -16), UDim2.fromOffset(2, 14), 2)
		if not p369.have then
			v371.ImageColor3 = Color3.new(0, 0, 0)
		end
		v_u_361(v371, v370, p369.have and 0.4886921905584123 or 0)
		p369.vp = v371
		p369.mounted = true
		if p369.glyph then
			p369.glyph:Destroy()
			p369.glyph = nil
		end
		return true
	end
	function v_u_285.cell(p373, p_u_374, p375, p376, p377, p_u_378, p_u_379) -- name: cell
		-- upvalues: (ref) v_u_13, (ref) v_u_286, (copy) v_u_278, (copy) v_u_280, (copy) v_u_279, (copy) v_u_368, (copy) v_u_298, (copy) v_u_300, (copy) v_u_372
		local v_u_380 = p375 == true and true or p375 == "seen"
		local v_u_381 = p375 == "seen"
		local v_u_382 = v_u_13.info(p_u_374)
		local v383
		if v_u_286 and v_u_286.get then
			v383 = v_u_286.get(p_u_374)
		else
			v383 = nil
		end
		local v384
		if v383 == nil then
			v384 = false
		else
			v384 = v383.boss == true
		end
		local v385 = v_u_278.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true,
			["Selectable"] = true,
			["Name"] = "Infected_" .. p_u_374,
			["BackgroundColor3"] = v_u_280.raised,
			["Size"] = UDim2.fromOffset(p376, p376),
			["LayoutOrder"] = p377
		})
		v385.SelectionImageObject = v_u_278.selectionImage()
		local v386 = v_u_278.new
		local v387 = "Frame"
		local v388 = {
			["Name"] = "Glow",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil
		}
		local v389
		if v_u_380 then
			v389 = v_u_280.lineStrong
		else
			v389 = v_u_280.text2
		end
		v388.BackgroundColor3 = v389
		v388.Size = UDim2.fromScale(1, 1)
		local v390 = v386(v387, v388, v385)
		v_u_278.new("UIGradient", {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.95), NumberSequenceKeypoint.new(0.45, v_u_380 and 0.7 or 0.78), NumberSequenceKeypoint.new(1, 0.97) })
		}, v390)
		local v391 = v_u_278.stroke(v385, v_u_280.line)
		local v392 = v_u_278.label
		local v393 = {
			["parent"] = nil,
			["name"] = "Short",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["track"] = false,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["zindex"] = 3,
			["parent"] = v385,
			["text"] = not v_u_380 and "???" or v_u_382.short
		}
		local v394
		if v_u_380 then
			v394 = v_u_280.text
		else
			v394 = v_u_280.muted
		end
		v393.color = v394
		v393.position = UDim2.fromOffset(4, 2)
		v393.size = UDim2.new(1, -8, 0, 14)
		v392(v393)
		local v_u_395 = {
			["id"] = nil,
			["btn"] = nil,
			["have"] = nil,
			["seenOnly"] = nil,
			["boss"] = nil,
			["stroke"] = nil,
			["mounted"] = false,
			["hover"] = false,
			["id"] = p_u_374,
			["btn"] = v385,
			["have"] = v_u_380,
			["seenOnly"] = v_u_381,
			["boss"] = v384,
			["stroke"] = v391
		}
		if not v_u_380 then
			local v396 = v384 and v_u_279.isPhone() and -4 or 0
			v_u_278.label({
				["parent"] = nil,
				["name"] = "Unknown",
				["text"] = "?",
				["style"] = "h1",
				["color"] = nil,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["zindex"] = 4,
				["parent"] = v385,
				["color"] = v_u_280.text2,
				["position"] = UDim2.new(0.5, 0, 0.55, v396),
				["size"] = UDim2.fromScale(0.6, 0.5)
			}).AnchorPoint = Vector2.new(0.5, 0.5)
		end
		if v_u_381 and (not v384 or p376 >= 90) then
			local v397 = v_u_278.badge("SEEN", "muted", {
				["name"] = "SeenTag",
				["parent"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["height"] = 14,
				["parent"] = v385,
				["position"] = UDim2.new(1, -3, 1, -3),
				["anchor"] = Vector2.new(1, 1)
			})
			v397.ZIndex = 5
			for _, v398 in v397:GetDescendants() do
				if not v398:IsA("GuiObject") then
					continue
				end
				v398.ZIndex = 5
			end
		end
		if v384 then
			local v399 = v_u_278.badge("BOSS", "danger", {
				["parent"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["height"] = 14,
				["parent"] = v385,
				["position"] = UDim2.new(0, 3, 1, -3),
				["anchor"] = Vector2.new(0, 1)
			})
			v399.ZIndex = 5
			for _, v400 in v399:GetDescendants() do
				if not v400:IsA("GuiObject") then
					continue
				end
				v400.ZIndex = 5
			end
		end
		v385.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_395, (ref) v_u_368
			v_u_395.hover = true
			v_u_368(v_u_395)
		end)
		v385.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_395, (ref) v_u_368
			v_u_395.hover = false
			v_u_368(v_u_395)
		end)
		v385.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_395, (ref) v_u_368, (copy) p_u_379, (copy) p_u_374
			v_u_395.hover = true
			v_u_368(v_u_395)
			if p_u_379 then
				p_u_379(p_u_374)
			end
		end)
		v385.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_395, (ref) v_u_368
			v_u_395.hover = false
			v_u_368(v_u_395)
		end)
		v385.Activated:Connect(function()
			-- upvalues: (ref) v_u_278, (ref) v_u_279, (copy) p_u_378, (copy) p_u_374
			v_u_278.sound(v_u_279.sounds.click)
			task.spawn(p_u_378, p_u_374)
		end)
		v_u_278.tooltip(v385, function()
			-- upvalues: (copy) v_u_380, (ref) v_u_298, (copy) p_u_374, (copy) v_u_382, (copy) v_u_381
			if not v_u_380 then
				return {
					["title"] = "UNKNOWN",
					["body"] = nil,
					["body"] = "Not seen yet. Spot one in a raid to fill this entry." .. v_u_298(p_u_374)
				}
			end
			local v401 = {
				["title"] = v_u_382.name
			}
			local v402
			if v_u_381 then
				v402 = v_u_382.desc .. " Seen, not killed yet."
			else
				v402 = v_u_382.desc
			end
			v401.body = v402
			return v401
		end)
		v385.Parent = p373
		v_u_300[p_u_374] = v_u_395
		v_u_368(v_u_395)
		if not v_u_372(v_u_395) then
			local v403 = v_u_278.icon
			local v404 = "skull"
			local v405 = {
				["parent"] = v385
			}
			local v406 = p376 * 0.34
			v405.size = math.floor(v406)
			local v407
			if v_u_380 then
				v407 = v_u_280.text2
			else
				v407 = v_u_280.muted
			end
			v405.color = v407
			v405.position = UDim2.fromScale(0.5, 0.5)
			v405.anchor = Vector2.new(0.5, 0.5)
			local v408 = v403(v404, v405)
			v408.Name = "Glyph"
			v_u_395.glyph = v408
		end
		return v385
	end
	function v_u_285.detach() -- name: detach
		-- upvalues: (copy) v_u_299, (copy) v_u_300
		for _, v409 in v_u_299 do
			if not v409.model then
				continue
			end
			v409.model.Parent = nil
		end
		table.clear(v_u_300)
	end
	local function v_u_455(p410) -- name: traits
		-- upvalues: (copy) v_u_280
		if not p410 then
			return {}
		end
		local v411 = p410.speedChase
		local v412 = tonumber(v411) or 6
		local v413 = p410.hp
		local v414 = tonumber(v413) or 100
		local v415 = p410.armor
		local v416 = tonumber(v415) or 1
		local v417 = v414 / math.max(0.3, v416)
		if p410.armorParts and p410.armorParts.torso then
			v417 = v417 * 1.35
		end
		if p410.shield then
			v417 = v417 * 1.3
		end
		local v418 = p410.damage
		local v419 = tonumber(v418) or 10
		if p410.ranged then
			local v420 = p410.ranged.damage
			local v421 = tonumber(v420) or 0
			v419 = math.max(v419, v421)
		end
		local v422 = p410.sightRange
		local v423 = tonumber(v422) or 25
		local v424 = p410.hearing
		local v425 = tonumber(v424) or 1
		local v426 = p410.blind and "Blind, hears all" or (v423 >= 30 and "Keen" or (v423 <= 15 and "Poor sight" or "Normal"))
		local v427 = not p410.blind and v425 >= 1.5 and "Sharp hearing" or v426
		local v428 = v412 / 16
		local v429 = math.clamp(v428, 0.05, 1)
		local v430 = {
			{ 4, "Crawls" },
			{ 6.1, "Slow" },
			{ 8, "Steady" },
			{ 12, "Fast" },
			{ (1 / 0), "Very fast" }
		}
		local v431 = {}
		local v432 = {}
		local v433 = "Speed"
		for _, v434 in v430 do
			if v412 >= v434[1] then
				continue
			end
			v435 = v434[2]
		end
		local v435 = v430[#v430][2]
		__set_list(v432, 1, {v433, v429, v435, v_u_280.accent})
		local v436 = v417 / 40
		local v437 = math.log(v436) / 4.605170185988092
		local v438 = math.clamp(v437, 0.05, 1)
		local v439 = {
			{ 90, "Fragile" },
			{ 135, "Average" },
			{ 260, "Tough" },
			{ 1200, "Very tough" },
			{ (1 / 0), "Boss" }
		}
		local v440 = {}
		local v441 = "Toughness"
		for _, v442 in v439 do
			if v417 >= v442[1] then
				continue
			end
			v443 = v442[2]
		end
		local v443 = v439[#v439][2]
		__set_list(v440, 1, {v441, v438, v443, v_u_280.info})
		local v444 = v419 / 44
		local v445 = math.clamp(v444, 0.05, 1)
		local v446 = {
			{ 10.5, "Light" },
			{ 15, "Moderate" },
			{ 25, "Heavy" },
			{ (1 / 0), "Lethal" }
		}
		local v447 = {}
		local v448 = "Damage"
		for _, v449 in v446 do
			if v419 >= v449[1] then
				continue
			end
			v450 = v449[2]
		end
		local v450 = v446[#v446][2]
		__set_list(v447, 1, {v448, v445, v450, v_u_280.danger})
		local v451 = {}
		local v452 = "Senses"
		local v453
		if p410.blind then
			v453 = 0.85
		else
			local v454 = (v423 / 40 + v425 / 2) / 2
			v453 = math.clamp(v454, 0.05, 1)
		end
		__set_list(v451, 1, {v452, v453, v427, v_u_280.text2})
		__set_list(v431, 1, {v432, v440, v447, v451})
		return v431
	end
	function v_u_285.detail(p456, p457) -- name: detail
		-- upvalues: (copy) v_u_278, (ref) v_u_304
		local v458 = v_u_278.list({
			["parent"] = nil,
			["name"] = "Bestiary",
			["size"] = nil,
			["gap"] = 8,
			["parent"] = p456,
			["size"] = UDim2.fromScale(1, 1)
		})
		v_u_304 = {
			["list"] = v458,
			["w"] = p457 or 360
		}
		return v458
	end
	function v_u_285.select(p459, p460) -- name: select
		-- upvalues: (ref) v_u_304, (ref) v_u_305, (copy) v_u_300, (copy) v_u_368, (ref) v_u_302, (ref) v_u_303, (ref) v_u_301, (copy) v_u_281, (ref) v_u_13, (ref) v_u_286, (copy) v_u_278, (copy) v_u_280, (copy) v_u_339, (copy) v_u_329, (copy) v_u_361, (ref) v_u_312, (ref) v_u_275, (ref) v_u_308, (copy) v_u_298, (ref) v_u_290, (copy) v_u_455, (copy) v_u_282, (copy) v_u_285
		local v461 = p460 == true and true or p460 == "seen"
		if v_u_304 and v_u_304.list.Parent then
			local v462 = v_u_305
			v_u_305 = p459
			for _, v463 in v_u_300 do
				if v463.id ~= p459 and v463.id ~= v462 then
					continue
				end
				v_u_368(v463)
			end
			if v_u_302 ~= p459 or (v_u_303 ~= p460 or not v_u_301) then
				v_u_302 = p459
				v_u_303 = p460
				if v_u_301 and v_u_301.model then
					v_u_301.model:Destroy()
				end
				v_u_301 = nil
				local v_u_464 = v_u_304.list
				v_u_281.clear(v_u_464)
				local v465 = v_u_13.info(p459)
				local v466
				if v_u_286 and v_u_286.get then
					v466 = v_u_286.get(p459)
				else
					v466 = nil
				end
				local v467
				if v466 == nil then
					v467 = false
				else
					v467 = v466.boss == true
				end
				local v468 = v_u_304.w - 14
				local v469 = math.max(200, v468)
				local v470 = v_u_278.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, -6, 0, 30)
				}, v_u_464)
				v_u_278.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "h2",
					["size"] = nil,
					["fit"] = true,
					["parent"] = v470,
					["text"] = not v461 and "Unknown infected" or v465.name,
					["size"] = UDim2.new(1, v467 and -64 or 0, 1, 0)
				})
				if v467 then
					v_u_278.badge("BOSS", "danger", {
						["parent"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["height"] = 20,
						["parent"] = v470,
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5)
					})
				end
				local v471 = v469 * 0.82
				local v472 = math.clamp(v471, 170, 330)
				local v473 = math.floor(v472)
				local v474 = v_u_278.new("Frame", {
					["Name"] = "PreviewBox",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["ClipsDescendants"] = true,
					["BackgroundColor3"] = v_u_280.bgDeep,
					["Size"] = UDim2.new(1, -6, 0, v473)
				}, v_u_464)
				local v475 = v_u_278.stroke
				local v476 = v474
				local v477
				if v467 then
					v477 = v_u_280.danger:Lerp(v_u_280.line, 0.4)
				else
					v477 = v_u_280.line
				end
				v475(v476, v477)
				local v478 = v_u_278.new
				local v479 = "Frame"
				local v480 = {
					["Name"] = "Glow",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil
				}
				local v481
				if v461 then
					v481 = v_u_280.lineStrong
				else
					v481 = v_u_280.text2
				end
				v480.BackgroundColor3 = v481
				v480.Size = UDim2.fromScale(1, 1)
				local v482 = v478(v479, v480, v474)
				v_u_278.new("UIGradient", {
					["Rotation"] = 90,
					["Transparency"] = nil,
					["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.92), NumberSequenceKeypoint.new(0.5, v461 and 0.62 or 0.7), NumberSequenceKeypoint.new(1, 0.95) })
				}, v482)
				local v483 = v_u_339(v474, "Preview", UDim2.fromScale(1, 1), UDim2.new(), 2)
				if not v461 then
					v483.ImageColor3 = Color3.new(0, 0, 0)
					v_u_278.label({
						["parent"] = nil,
						["name"] = "Unknown",
						["text"] = "?",
						["style"] = "display",
						["color"] = nil,
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["zindex"] = 4,
						["parent"] = v474,
						["color"] = v_u_280.text2,
						["position"] = UDim2.fromScale(0.5, 0.5),
						["size"] = UDim2.fromScale(0.5, 0.5)
					}).AnchorPoint = Vector2.new(0.5, 0.5)
				end
				local v484 = v_u_329(p459)
				if v484 then
					v_u_301 = v484
					v484.vp = v483
					v_u_361(v483, v484, 0)
					v_u_312 = v_u_275(p459, v466)
					v_u_308 = os.clock()
				else
					v_u_278.label({
						["parent"] = nil,
						["name"] = "Wait",
						["text"] = "Preview loading...",
						["style"] = "small",
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["zindex"] = 3,
						["parent"] = v474,
						["position"] = UDim2.fromScale(0, 0.5),
						["size"] = UDim2.new(1, 0, 0, 20)
					})
				end
				local v_u_485 = 3
				local function v489(p486, p487, p488) -- name: text
					-- upvalues: (ref) v_u_485, (ref) v_u_278, (copy) v_u_464
					v_u_485 = v_u_485 + 1
					v_u_278.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = nil,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["size"] = nil,
						["parent"] = v_u_464,
						["text"] = p486,
						["style"] = p487 or "small",
						["color"] = p488,
						["order"] = v_u_485,
						["size"] = UDim2.new(1, -6, 0, 0)
					})
				end
				if v461 then
					if p460 == "seen" then
						v_u_278.badge("SEEN, NOT KILLED", "accent", {
							["name"] = "SeenTag",
							["order"] = 3,
							["height"] = 20
						}).Parent = v_u_464
					end
					v489(v465.desc, "body")
					v_u_485 = v_u_485 + 1
					v_u_281.section(v_u_464, "Threat", v_u_485, "BASE VALUES")
					local v490 = p460 == true
					local v491 = not v490 and {} or v_u_13.numbers(v466, v_u_290)
					for _, v492 in v_u_455(v466) do
						v_u_485 = v_u_485 + 1
						local v493 = v492[1]
						if v491[v493] then
							v493 = v493 .. "  " .. v491[v493]
						end
						v_u_281.bar(v_u_464, {
							["label"] = nil,
							["labelStyle"] = "small",
							["right"] = nil,
							["value"] = nil,
							["color"] = nil,
							["order"] = nil,
							["label"] = v493,
							["right"] = string.upper(v492[3]),
							["value"] = v492[2],
							["color"] = v492[4],
							["order"] = v_u_485
						}).frame.Size = UDim2.new(1, -6, 0, 36)
					end
					if v490 then
						local v494 = v_u_13.hpText(v466, v_u_290)
						if v494 then
							v489(v494, "small", v_u_280.text2)
						end
						local v495 = v_u_13.armorLines(v466, v_u_286)
						if #v495 > 0 then
							v_u_485 = v_u_485 + 1
							v_u_281.section(v_u_464, "Armor", v_u_485, "DAMAGE TAKEN")
							for _, v496 in v495 do
								v489(v496)
							end
						end
					else
						v489("Put one down to read its numbers and armor.", "small", v_u_280.text2)
					end
					v_u_485 = v_u_485 + 1
					v_u_281.section(v_u_464, "Behaviour", v_u_485)
					v489(v465.special)
					v_u_485 = v_u_485 + 1
					v_u_281.section(v_u_464, "Where", v_u_485)
					local v497 = v465.where
					if p459 == "walker" then
						local v498 = v_u_13.populationText
						local v499 = v_u_290
						local v500, v501 = pcall(v498, v499)
						if v500 and (type(v501) == "string" and v501 ~= "") then
							v497 = v497 .. " " .. v501
						end
					end
					v489(v497)
					local v502 = v_u_13.infectionText
					local v503 = v_u_290
					local v504 = v_u_282.config
					local v505, v506 = pcall(v502, p459, v466, v503, v504)
					if v505 and (type(v506) == "string" and v506 ~= "") then
						v_u_485 = v_u_485 + 1
						v_u_281.section(v_u_464, "Infection", v_u_485, "BY DIFFICULTY")
						v489(v506)
					end
				else
					v489((v467 and "A boss. Spot it in a raid to fill this entry." or "Not seen yet. Spot one in a raid to fill this entry.") .. v_u_298(p459), "body", v_u_280.text2)
				end
				v_u_285.publish()
			end
		else
			return
		end
	end
	local function v_u_528(p507, p508) -- name: animStep
		-- upvalues: (ref) v_u_301, (ref) v_u_288, (ref) v_u_311, (copy) v_u_283, (ref) v_u_308, (ref) v_u_270, (ref) v_u_309, (ref) v_u_286, (ref) v_u_312
		local v509 = v_u_301
		if v509 and (v509.model.Parent and v_u_288) then
			local v510 = v509.vp
			local v511
			if v510.Parent == nil then
				v511 = false
			else
				v511 = v_u_283.visible == nil and true or v_u_283.visible()
			end
			if v511 then
				local v512 = v510:FindFirstAncestorWhichIsA("ScreenGui")
				if v512 == nil then
					v511 = false
				else
					v511 = v512.Enabled
				end
			end
			v_u_311 = v511
			if v511 then
				local v513 = p507 - v_u_308
				local v514 = v510.CurrentCamera
				if v514 then
					local v515 = v510.AbsoluteSize
					v_u_270(v514, v509, v513 * 0.32, v515.Y <= 1 and 1 or v515.X / v515.Y)
				end
				v_u_309 = v_u_309 + p508
				if v_u_309 >= 0.03333333333333333 then
					local v516 = v_u_309
					v_u_309 = 0
					local v517 = v509.id
					local v518
					if v_u_286 and v_u_286.get then
						v518 = v_u_286.get(v517)
					else
						v518 = nil
					end
					local v519 = v513 % 7
					local v520 = v_u_312
					v520.t = p507
					v520.state = 0
					v520.act = 0
					v520.actDur = 1
					v520.notice = -1
					v520.ring = 0
					if v519 >= 3.2 and (v519 < 3.95 and not v520.human) then
						v520.notice = v519 - 3.2
					end
					if v519 >= 4 then
						local v521 = v519 - 4
						local v522 = v509.id
						if v522 == "screamer" or v522 == "boss_surgeon" then
							if v521 < 1.8 then
								v520.state = 8
								v520.act = v521
								v520.actDur = 1.8
							end
						elseif v522 == "boss_hale" then
							if v521 < 2 then
								v520.state = 9
								v520.act = v521
								v520.actDur = 2
							end
						elseif v522 == "ringer" then
							if v521 < 2.6 then
								v520.ring = v521 < 0.9 and 1 or 2
							end
						else
							local v523
							if v518 then
								local v524 = v518.attackWindup
								v523 = tonumber(v524) or 0.6
							else
								v523 = 0.6
							end
							if v521 < v523 + 0.6 then
								v520.state = 4
								v520.act = v521
								v520.actDur = v523
								local v525 = v513 / 7
								v520.variant = math.floor(v525) % 3
							end
						end
					end
					local v526 = v_u_288.update
					local v527 = v509.pose
					pcall(v526, v527, v520, v516)
				end
			else
				return
			end
		else
			v_u_311 = false
			return
		end
	end
	function v_u_285.publish() -- name: publish
		-- upvalues: (copy) v_u_285, (copy) v_u_284
		local v_u_529 = v_u_285.stats()
		local function v542()
			-- upvalues: (ref) v_u_284, (copy) v_u_529
			local v530 = v_u_284
			local v531 = v_u_529.cells
			local v532 = v_u_529.rigs
			local v533 = v_u_529.parts
			local v534 = v_u_529.detailParts
			local v535 = v_u_529.animating
			local v536 = tostring(v535)
			local v537 = v_u_529.pending
			local v538 = v_u_529.selected
			local v539 = tostring(v538)
			local v540 = v_u_529.seenOnly
			local v541 = v_u_529.detailSeen
			v530:SetAttribute("Bestiary", ("cells=%d rigs=%d parts=%d detailParts=%d animating=%s pending=%d selected=%s seenOnly=%d detailSeen=%s"):format(v531, v532, v533, v534, v536, v537, v539, v540, (tostring(v541))))
		end
		pcall(v542)
	end
	function v_u_285.stats() -- name: stats
		-- upvalues: (copy) v_u_300, (copy) v_u_299, (ref) v_u_301, (ref) v_u_311, (ref) v_u_305, (ref) v_u_303
		local v543 = 0
		local v544 = 0
		local v545 = 0
		local v546 = 0
		local v547 = 0
		for _, v548 in v_u_300 do
			v543 = v543 + 1
			if v548.seenOnly then
				v544 = v544 + 1
			end
			if v548.mounted then
				continue
			end
			v545 = v545 + 1
		end
		for _, v549 in v_u_299 do
			v546 = v546 + 1
			v547 = v547 + (v549.parts or 0)
		end
		local v550 = v_u_301 and (v_u_301.parts or 0) or 0
		if v_u_301 then
			v546 = v546 + 1
		end
		return {
			["cells"] = v543,
			["rigs"] = v546,
			["parts"] = v547 + v550,
			["detailParts"] = v550,
			["animating"] = v_u_311,
			["pending"] = v545,
			["selected"] = v_u_305,
			["seenOnly"] = v544,
			["detailSeen"] = v_u_303 == "seen"
		}
	end
	function v_u_285.start() -- name: start
		-- upvalues: (ref) v_u_307, (ref) v_u_306, (ref) v_u_2, (copy) v_u_528, (ref) v_u_310, (copy) v_u_300, (copy) v_u_372, (ref) v_u_304, (ref) v_u_302, (ref) v_u_301, (ref) v_u_303, (copy) v_u_285
		if not v_u_307 then
			v_u_307 = true
			local v_u_551 = 0
			v_u_306 = v_u_2.Heartbeat:Connect(function(p552)
				-- upvalues: (ref) v_u_528, (ref) v_u_310, (ref) v_u_300, (ref) v_u_372, (ref) v_u_304, (ref) v_u_302, (ref) v_u_301, (ref) v_u_303, (ref) v_u_285, (ref) v_u_551
				v_u_528(os.clock(), p552)
				v_u_310 = v_u_310 + p552
				if v_u_310 >= 0.5 then
					v_u_310 = 0
					for _, v553 in v_u_300 do
						if v553.mounted then
							continue
						end
						v_u_372(v553)
					end
					if v_u_304 and (v_u_302 and (not v_u_301 and v_u_304.list.Parent)) then
						local v554 = v_u_302
						local v555 = v_u_303
						v_u_302 = nil
						v_u_285.select(v554, v555)
					end
				end
				v_u_551 = v_u_551 + p552
				if v_u_551 >= 2 then
					v_u_551 = 0
					v_u_285.publish()
				end
			end)
		end
	end
	function v_u_285.stop() -- name: stop
		-- upvalues: (ref) v_u_307, (ref) v_u_306, (ref) v_u_301, (ref) v_u_302, (copy) v_u_300, (copy) v_u_299, (ref) v_u_311, (copy) v_u_285
		v_u_307 = false
		if v_u_306 then
			v_u_306:Disconnect()
			v_u_306 = nil
		end
		if v_u_301 and v_u_301.model then
			v_u_301.model:Destroy()
		end
		v_u_301 = nil
		v_u_302 = nil
		for _, v556 in v_u_300 do
			if v556.vp then
				v556.vp:Destroy()
			end
			v556.mounted = false
		end
		table.clear(v_u_300)
		for _, v557 in v_u_299 do
			if not v557.model then
				continue
			end
			v557.model:Destroy()
		end
		table.clear(v_u_299)
		v_u_311 = false
		v_u_285.publish()
	end
	return v_u_285
end
return v_u_13