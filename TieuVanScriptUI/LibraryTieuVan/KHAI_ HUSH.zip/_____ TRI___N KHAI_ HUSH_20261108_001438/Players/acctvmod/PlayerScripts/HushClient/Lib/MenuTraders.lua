-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTraders

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = {
	{
		["id"] = "all",
		["text"] = "All"
	},
	{
		["id"] = "weapons",
		["text"] = "Weapons"
	},
	{
		["id"] = "ammo",
		["text"] = "Ammo"
	},
	{
		["id"] = "attachments",
		["text"] = "Attachments"
	},
	{
		["id"] = "medical",
		["text"] = "Medical"
	},
	{
		["id"] = "gear",
		["text"] = "Gear"
	},
	{
		["id"] = "valuables",
		["text"] = "Valuables"
	}
}
local v_u_5 = {
	["firearm"] = "weapons",
	["melee"] = "weapons",
	["throwable"] = "weapons",
	["ammo"] = "ammo",
	["attachment"] = "attachments",
	["medical"] = "medical",
	["food"] = "medical",
	["armor"] = "gear",
	["helmet"] = "gear",
	["bag"] = "gear",
	["secure"] = "gear",
	["key"] = "gear",
	["quest"] = "gear",
	["valuable"] = "valuables",
	["material"] = "valuables"
}
local v_u_6 = {
	["9mm"] = "9mm",
	["45"] = ".45",
	["357"] = ".357",
	["12ga"] = "12ga",
	["556"] = "5.56",
	["762"] = "7.62",
	["308"] = ".308"
}
local v_u_7 = {
	["9mm"] = 1,
	["45"] = 2,
	["357"] = 3,
	["12ga"] = 4,
	["556"] = 5,
	["762"] = 6,
	["308"] = 7
}
local v_u_8 = {}
v_u_3.FILTER_MEMORY = v_u_8
v_u_3.CAT_FILTER = v_u_5
function v_u_3.gainRepBody(p9, p10, p11, p12) -- name: gainRepBody
	local v13 = ("Finish %s\'s tasks, and buy from or sell to %s: every %s traded gives +1 rep, up to %d rep in total."):format(p9, p9, p10, p11)
	if p12 == true then
		v13 = v13 .. " At LV 4 and above, every extract also gives rep: +1 Normal, +2 Hard, +3 Nightmare. It goes to your regular trader (MISSION POINTS panel) first, then to your other LV 4 traders."
	end
	return v13
end
function v_u_3.extractRepOpen(p14, p15, p16) -- name: extractRepOpen
	if p15 ~= true or type(p14) ~= "table" then
		return false
	end
	local v17 = tonumber(p16) or 1.5
	local v18 = p14.lvl
	local v19
	if (tonumber(v18) or 1) >= 4 then
		local v20 = p14.rep
		v19 = (tonumber(v20) or 0) < v17 - 1e-6
	else
		v19 = false
	end
	return v19
end
function v_u_3.discountEnds(p21, p22) -- name: discountEnds
	local v23 = tonumber(p21)
	if v23 == nil or (v23 ~= v23 or v23 <= p22) then
		return ""
	end
	local v24 = v23 - p22
	local v25 = math.floor(v24)
	if v25 >= 86400 then
		return (", ends in %d d %d h"):format(v25 // 86400, v25 % 86400 // 3600)
	end
	if v25 >= 3600 then
		return (", ends in %d h %d min"):format(v25 // 3600, v25 % 3600 // 60)
	end
	local v26 = v25 / 60
	local v27 = math.ceil(v26)
	return (", ends in %d min"):format((math.max(1, v27)))
end
local function v_u_33(p28) -- name: dollars
	local v29 = string.format
	local v30 = math.ceil(p28)
	local v31 = v29("%d", (math.max(0, v30)))
	local v32 = ""
	while #v31 > 3 do
		v32 = "," .. string.sub(v31, -3) .. v32
		v31 = string.sub(v31, 1, -4)
	end
	return "$" .. v31 .. v32
end
function v_u_3.shortText(p34, p35) -- name: shortText
	-- upvalues: (copy) v_u_33
	return ("Not enough cash. You are %s short."):format((v_u_33((tonumber(p34) or 0) - (tonumber(p35) or 0))))
end
function v_u_3.gainRepParts(p36, p37, p38, p39, p40) -- name: gainRepParts
	local v41 = p37 * 100 + 0.5
	local v42 = math.floor(v41)
	local v43
	if p36 > 0 then
		v43 = ("%d open%s"):format(p36, p37 <= 0 and "" or (", up to +%d"):format(v42))
	else
		v43 = p37 <= 0 and "all done" or ("+%d, more unlock with levels"):format(v42)
	end
	return v43, ("+1 per %s (%d / %d)"):format(p38, p39, p40)
end
local function v_u_62(p44, p45) -- name: partnerReadyOf
	local v46 = {
		["ready"] = false,
		["price"] = 0,
		["short"] = 0
	}
	if p45 ~= false and type(p44) == "table" then
		local v47 = p44.partner
		if type(v47) == "table" then
			local v48 = p44.partner
			if v48.owned ~= true then
				local v49 = v48.reqs
				if type(v49) == "table" then
					local v50 = {}
					local v51 = 0
					local v52 = 0
					for _, v53 in v48.reqs do
						if type(v53) ~= "table" then
							continue
						end
						local v54 = v53.id
						if type(v54) ~= "string" then
							continue
						end
						v50[v53.id] = v53.ok == true
						if v53.id ~= "cash" then
							continue
						end
						local v55 = v53.need
						v51 = tonumber(v55) or 0
						local v56 = v53.have
						v52 = tonumber(v56) or 0
					end
					local v57 = v48.price
					local v58 = tonumber(v57) or v51
					if v50.level ~= true or (v50.rep ~= true or v50.ep ~= true) then
						return {
							["ready"] = false,
							["price"] = nil,
							["short"] = 0,
							["price"] = v58
						}
					end
					local v59 = {
						["ready"] = true,
						["price"] = nil,
						["short"] = nil,
						["price"] = v58
					}
					local v60 = v51 - v52 + 0.5
					local v61 = math.floor(v60)
					v59.short = math.max(0, v61)
					return v59
				end
			end
			return v46
		end
	end
	return v46
end
function v_u_3.partnerReady(p63, p64) -- name: partnerReady
	-- upvalues: (copy) v_u_62
	local v65 = v_u_62
	local v66, v67 = pcall(v65, p63, p64)
	return (not v66 or type(v67) ~= "table") and {
		["ready"] = false,
		["price"] = 0,
		["short"] = 0
	} or v67
end
function v_u_3.partnerReadyLine(p68, p69, p70, p71) -- name: partnerReadyLine
	local v72
	if type(p68) == "table" then
		local v73 = p68.price
		v72 = tonumber(v73) or 0
	else
		v72 = 0
	end
	local v74
	if type(p68) == "table" then
		local v75 = p68.short
		v74 = tonumber(v75) or 0
	else
		v74 = 0
	end
	if p69 then
		return ("<font color=\"%s\">READY</font>: open the PARTNER tab (LV 5, %s)"):format(p71, p70(v72))
	elseif v74 > 0 then
		return ("<font color=\"%s\">READY for LV 5</font>: open the PARTNER tab. Buy in %s, you are %s short."):format(p71, p70(v72), p70(v74))
	else
		return ("<font color=\"%s\">READY for LV 5</font>: open the PARTNER tab and pay the buy in of %s."):format(p71, p70(v72))
	end
end
function v_u_3.nextPartnerLine(p76, p77, p78, p79, p80, p81, p82, p83, p84, p85, p86, p87) -- name: nextPartnerLine
	local v88 = "Next LV %d (partner):  rep <font color=\"%s\">%s / %d</font>  \194\183  EP <font color=\"%s\">%d / %d</font>"
	local v89
	if p81 then
		v89 = p77
	else
		v89 = p78
	end
	if p84 then
		p78 = p77
	end
	local v90 = v88:format(p76, v89, p79, p80, p78, p82, p83)
	local v91 = tonumber(p85) or 0
	if p86 then
		return v90 .. "  \194\183  + buy in"
	elseif v91 > 0 then
		return v90 .. "  \194\183  buy in " .. p87(v91)
	else
		return v90 .. "  \194\183  + buy in"
	end
end
function v_u_3.partnerReadyTip(p92, p93, p94) -- name: partnerReadyTip
	local v95
	if type(p93) == "table" then
		local v96 = p93.price
		v95 = tonumber(v96) or 0
	else
		v95 = 0
	end
	return ("%s is ready for LV 5: open the PARTNER tab to become a partner for %s."):format(tostring(p92), p94(v95))
end
function v_u_3.new(p_u_97, p_u_98) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_1
	local v_u_99 = p_u_97.ui
	local v_u_100 = p_u_97.theme
	local v_u_101 = v_u_100.color
	local v_u_102 = p_u_97.kit
	local v_u_103 = p_u_97.compact()
	local v_u_104 = v_u_100.isPhone()
	local v_u_105 = {}
	local v_u_106 = nil
	local function v107()
		-- upvalues: (ref) v_u_106, (copy) p_u_97
		v_u_106 = p_u_97.cctx.shared.Traders
	end
	pcall(v107)
	local v_u_108 = nil
	local function v109()
		-- upvalues: (ref) v_u_108, (copy) p_u_97
		v_u_108 = p_u_97.cctx.shared.TraderSub
	end
	pcall(v109)
	local v_u_110 = nil
	local function v111()
		-- upvalues: (ref) v_u_110, (copy) p_u_97
		v_u_110 = p_u_97.cctx.lib.InvUITile
	end
	pcall(v111)
	local v_u_112 = not (v_u_106 and v_u_106.ORDER) and { "doc", "gunner", "scrapper" } or v_u_106.ORDER
	local v_u_113
	if v_u_106 then
		local v114 = v_u_106.CARDS
		if type(v114) == "table" then
			v_u_113 = v_u_106.CARDS
		else
			v_u_113 = v_u_112
		end
	else
		v_u_113 = v_u_112
	end
	local v_u_115 = nil
	local function v_u_116(_) end
	local v_u_1964 = v_u_112[1]
	local v_u_1993 = "buy"
	local v_u_119 = nil
	local v_u_120 = false
	local v_u_1965 = {}
	local v_u_122 = nil
	local v_u_1966 = nil
	local v_u_124 = {}
	local v_u_125 = {}
	local v_u_1967 = nil
	local v_u_127 = nil
	local v_u_128 = nil
	local v_u_129 = false
	local v_u_1986 = false
	local v_u_131 = {}
	local v_u_132 = {
		["on"] = false,
		["mode"] = true,
		["moved"] = false,
		["start"] = ""
	}
	local v_u_134 = v_u_2.InputEnded:Connect(function(p133)
		-- upvalues: (copy) v_u_132
		if p133.UserInputType == Enum.UserInputType.MouseButton1 or p133.UserInputType == Enum.UserInputType.Touch then
			task.defer(function()
				-- upvalues: (ref) v_u_132
				v_u_132.on = false
			end)
		end
	end)
	local v_u_135 = 1
	local v_u_136 = 1
	local v_u_137 = nil
	local v_u_1977 = false
	local v_u_139 = {
		["label"] = nil,
		["at"] = 0,
		["reloadedFor"] = 0
	}
	local function v_u_145(p140) -- name: repPoints
		local v141 = tonumber(p140) or 0
		local v142 = v141 * 1000 + 0.001
		local v143 = math.floor(v142)
		if v143 > 0 and v141 + 1e-6 < v143 / 1000 then
			v143 = v143 - 1
		elseif v141 + 1e-6 >= (v143 + 1) / 1000 then
			v143 = v143 + 1
		end
		local v144 = v143 / 10
		if v144 == math.floor(v144) then
			return ("%d"):format(v144)
		else
			return ("%.1f"):format(v144)
		end
	end
	local v_u_146 = {
		["medical"] = "Medicine",
		["food"] = "Food",
		["firearm"] = "Guns",
		["ammo"] = "Ammo",
		["attachment"] = "Attachments",
		["melee"] = "Melee",
		["armor"] = "Armor",
		["helmet"] = "Helmets",
		["throwable"] = "Throwables",
		["misc"] = "Other goods",
		["vhs"] = "VHS tapes",
		["tape"] = "Log discs",
		["bag"] = "Bags",
		["valuable"] = "Valuables",
		["material"] = "Materials",
		["key"] = "Keys"
	}
	local function v_u_156() -- name: syncPartners
		-- upvalues: (ref) v_u_106, (copy) p_u_97, (ref) v_u_119
		if v_u_106 then
			local v147 = nil
			local v148 = p_u_97.profile
			local v149 = v_u_119
			local v150
			if type(v149) == "table" and v_u_119.partners ~= nil then
				v150 = v_u_119.partners == true
			else
				local function v151()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v152
				v150, v152 = pcall(v151)
				if v150 then
					v150 = v152 == true
				end
			end
			if v150 and type(v148) == "table" then
				local v153 = v148.traders
				if type(v153) == "table" then
					for v154, v155 in v148.traders do
						if type(v155) ~= "table" or v155.partner ~= true then
							continue
						end
						v147 = v147 or {}
						v147[v154] = true
					end
				end
			end
			v_u_106.viewerPartners = v147
		end
	end
	v_u_156()
	local v_u_157 = nil
	local function v159()
		-- upvalues: (copy) p_u_97, (ref) v_u_157, (copy) v_u_156
		if p_u_97.changed and p_u_97.changed.Connect then
			v_u_157 = p_u_97.changed:Connect(function(p158)
				-- upvalues: (ref) v_u_156
				if p158 == "profile" then
					v_u_156()
				end
			end)
		end
	end
	pcall(v159)
	local v_u_160, v161 = v_u_99.panel({
		["parent"] = nil,
		["name"] = "Traders",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 0,
		["parent"] = p_u_98,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v_u_162 = v_u_103 and 210 or 290
	local v163 = v_u_99.list({
		["parent"] = nil,
		["name"] = "Left",
		["size"] = nil,
		["gap"] = 8,
		["padding"] = nil,
		["parent"] = v161,
		["size"] = UDim2.new(0, v_u_162, 1, 0),
		["padding"] = {
			12,
			12,
			12,
			12
		}
	})
	v_u_99.divider({
		["parent"] = nil,
		["vertical"] = true,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v161,
		["position"] = UDim2.fromOffset(v_u_162, 0),
		["size"] = UDim2.new(0, 1, 1, 0)
	})
	local v164 = v_u_99.new("Frame", {
		["Name"] = "Right",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_162 + 1, 0),
		["Size"] = UDim2.new(1, -v_u_162 - 1, 1, 0)
	}, v161)
	v_u_99.pad(v164, v_u_104 and {
		14,
		10,
		8,
		8
	} or {
		20,
		16,
		14,
		14
	})
	local function v_u_166(p165) -- name: def
		-- upvalues: (ref) v_u_106, (copy) v_u_101
		return v_u_106 and v_u_106.defs and v_u_106.defs[p165] or {
			["id"] = nil,
			["name"] = nil,
			["title"] = "",
			["bio"] = "",
			["quote"] = "",
			["location"] = "",
			["color"] = nil,
			["id"] = p165,
			["name"] = string.upper(p165),
			["color"] = v_u_101.accent
		}
	end
	local v_u_167 = v_u_157
	local v_u_168 = v_u_108
	local v_u_169 = v_u_110
	local v_u_170 = v_u_119
	local v_u_171 = v_u_106
	local v_u_172 = {}
	local function v_u_173() end
	local v_u_174 = nil
	local v_u_175 = false
	local v_u_176 = nil
	for v177, v_u_178 in v_u_113 do
		local v179 = v_u_166(v_u_178)
		local v180 = v_u_99.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["Name"] = v_u_178,
			["BackgroundColor3"] = v_u_101.raised,
			["Size"] = UDim2.new(1, 0, 0, v_u_103 and 76 or 96),
			["LayoutOrder"] = v177
		}, v163)
		v180.SelectionImageObject = v_u_99.selectionImage()
		local v_u_181 = v_u_99.stroke(v180, v_u_101.line)
		local v182 = v_u_103 and 60 or 76
		local v183 = v_u_102.portrait(v180, v_u_178, v179.color or v_u_101.accent, v182)
		v183.Position = UDim2.fromOffset(10, 10)
		local v184 = v_u_99.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v180,
			["text"] = v179.name,
			["position"] = UDim2.fromOffset(v182 + 22, 10),
			["size"] = UDim2.new(1, -v182 - 30, 0, 22)
		})
		local v185 = v_u_99.label({
			["parent"] = nil,
			["name"] = "Level",
			["text"] = "",
			["style"] = "monoS",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v180,
			["position"] = UDim2.fromOffset(v182 + 22, v_u_103 and 31 or 34),
			["size"] = UDim2.new(1, -v182 - 30, 0, 16)
		})
		local v186 = v_u_99.label({
			["parent"] = nil,
			["name"] = "Tasks",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["track"] = false,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v180,
			["color"] = v_u_101.text2,
			["position"] = UDim2.fromOffset(v182 + 22, v_u_103 and 47 or 54),
			["size"] = UDim2.new(1, -v182 - 30, 0, 14)
		})
		v_u_172[v_u_178] = {
			["btn"] = v180,
			["stroke"] = v_u_181,
			["lvl"] = v185,
			["rep"] = v_u_99.progress({
				["parent"] = nil,
				["value"] = 0,
				["size"] = nil,
				["position"] = nil,
				["color"] = nil,
				["parent"] = v180,
				["size"] = UDim2.new(1, -v182 - 36, 0, 3),
				["position"] = UDim2.new(0, v182 + 22, 1, v_u_103 and -11 or -16),
				["color"] = v179.color or v_u_101.accent
			}),
			["tasks"] = v186,
			["name"] = v184,
			["por"] = v183
		}
		if v_u_178 == "gunsmith" then
			v180.Visible = false
		end
		v_u_99.tooltip(v180, function()
			-- upvalues: (copy) v_u_178, (ref) v_u_170, (ref) v_u_3, (copy) p_u_97, (ref) v_u_171, (copy) v_u_102
			local v187 = v_u_178
			local v188 = v_u_170
			local v189
			if type(v188) == "table" then
				local v190 = v_u_170.traders
				if type(v190) == "table" then
					v189 = v_u_170.traders[v187]
				else
					v189 = nil
				end
			else
				v189 = nil
			end
			local v191 = v_u_3.partnerReady
			local v192 = v_u_170
			local v193
			if type(v192) == "table" and v_u_170.partners ~= nil then
				v193 = v_u_170.partners == true
			else
				local function v194()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v195
				v193, v195 = pcall(v194)
				if v193 then
					v193 = v195 == true
				end
			end
			local v196 = v191(v189, v193)
			if v196.ready ~= true then
				return nil
			end
			local v197 = {
				["title"] = "READY FOR LV 5",
				["body"] = nil
			}
			local v198 = v_u_3.partnerReadyTip
			local v199 = v_u_178
			local v200
			if v_u_171 and v_u_171.defs then
				v200 = v_u_171.defs[v199]
			else
				v200 = nil
			end
			local v201
			if type(v200) == "table" then
				local v202 = v200.name
				if type(v202) == "string" then
					v201 = v200.name
					v197.body = v198(v201, v196, v_u_102.money)
					return v197
				else
					v201 = string.upper(v199)
					v197.body = v198(v201, v196, v_u_102.money)
					return v197
				end
			else
				v201 = string.upper(v199)
				v197.body = v198(v201, v196, v_u_102.money)
				return v197
			end
		end)
		v180.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_100, (copy) v_u_181, (copy) v_u_101
			v_u_99.sound(v_u_100.sounds.hover)
			v_u_181.Color = v_u_101.lineStrong
		end)
		v180.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_181, (ref) v_u_1964, (copy) v_u_178, (copy) v_u_101
			local v203 = v_u_181
			local v204
			if v_u_1964 == v_u_178 then
				v204 = v_u_101.accent
			else
				v204 = v_u_101.line
			end
			v203.Color = v204
		end)
		v180.Activated:Connect(function()
			-- upvalues: (ref) v_u_1964, (copy) v_u_178, (ref) v_u_116
			if v_u_1964 ~= v_u_178 then
				v_u_116(v_u_178)
			end
		end)
	end
	local v_u_205 = {}
	function v_u_105.pickRegular(p206) -- name: pickRegular
		-- upvalues: (ref) v_u_170, (copy) p_u_97, (copy) v_u_205, (ref) v_u_173
		local v207 = v_u_170
		local v208
		if type(v207) == "table" and v_u_170.partners ~= nil then
			v208 = v_u_170.partners == true
		else
			local function v209()
				-- upvalues: (ref) p_u_97
				return p_u_97.cctx.config.flag("Partners")
			end
			local v210
			v208, v210 = pcall(v209)
			if v208 then
				v208 = v210 == true
			end
		end
		if v208 then
			local v211 = v_u_170
			if type(v211) == "table" and v_u_205[p206] then
				if v_u_170.stamm ~= p206 or v_u_170.stammDefault ~= nil and v_u_170.stammPicked ~= true then
					v_u_170.stamm = p206
					v_u_170.stammPicked = true
					v_u_173()
					p_u_97.op({
						["op"] = "traderStamm",
						["trader"] = nil,
						["trader"] = p206
					})
				end
				return
			end
		end
	end
	local v212 = v_u_100.touch(32)
	local v213 = 3 * v212 + 8
	local v214 = 88 + v213 + 8
	local v_u_215 = v_u_99.new("Frame", {
		["Name"] = "MissionPoints",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 20,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_101.raised,
		["Size"] = UDim2.new(1, 0, 0, v214)
	}, v163)
	v_u_99.stroke(v_u_215, v_u_101.line)
	v_u_99.pad(v_u_215, {
		8,
		8,
		8,
		8
	})
	v_u_99.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Mission points",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_215,
		["color"] = v_u_101.text2,
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v_u_216 = v_u_99.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = "EP 0 / 100",
		["style"] = "mono",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_215,
		["position"] = UDim2.fromOffset(0, 16),
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	local v_u_217 = v_u_99.progress({
		["parent"] = nil,
		["size"] = nil,
		["position"] = nil,
		["value"] = 0,
		["color"] = nil,
		["parent"] = v_u_215,
		["size"] = UDim2.new(1, 0, 0, 4),
		["position"] = UDim2.fromOffset(0, 48),
		["color"] = v_u_101.accent
	})
	v_u_99.label({
		["parent"] = nil,
		["name"] = "Caption",
		["text"] = "Extract rep goes to (LV 4+)",
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["fit"] = nil,
		["parent"] = v_u_215,
		["color"] = v_u_101.text2,
		["position"] = UDim2.fromOffset(0, 64),
		["size"] = UDim2.new(1, 0, 0, 16),
		["fit"] = v_u_104
	})
	local v218 = v_u_99.new("Frame", {
		["Name"] = "Regular",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, 80),
		["Size"] = UDim2.new(1, 0, 0, v213)
	}, v_u_215)
	v_u_99.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Vertical,
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v218)
	for v219, v_u_220 in v_u_112 do
		local v221 = v_u_99.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["Name"] = "Reg_" .. v_u_220,
			["BackgroundColor3"] = v_u_101.bg,
			["Size"] = UDim2.new(1, 0, 0, v212),
			["LayoutOrder"] = v219
		}, v218)
		v221.SelectionImageObject = v_u_99.selectionImage()
		local v_u_222 = v_u_99.stroke(v221, v_u_101.line)
		local v223 = v_u_99.new("Frame", {
			["Name"] = "Radio",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 8, 0.5, 0),
			["Size"] = UDim2.fromOffset(16, 16)
		}, v221)
		local v224 = v_u_99.stroke(v223, v_u_101.lineStrong)
		local v225 = v_u_99.new("Frame", {
			["Name"] = "Dot",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_101.info,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(8, 8)
		}, v223)
		local v226 = v_u_99.label
		local v227 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v221
		}
		local v228
		if v_u_171 and v_u_171.defs then
			v228 = v_u_171.defs[v_u_220]
		else
			v228 = nil
		end
		local v229
		if type(v228) == "table" then
			local v230 = v228.name
			if type(v230) == "string" then
				v229 = v228.name
			else
				v229 = string.upper(v_u_220)
			end
		else
			v229 = string.upper(v_u_220)
		end
		v227.text = v229
		v227.color = v_u_101.text2
		v227.position = UDim2.fromOffset(32, 0)
		v227.size = UDim2.new(1, -96, 1, 0)
		local v231 = v226(v227)
		v_u_205[v_u_220] = {
			["btn"] = v221,
			["stroke"] = v_u_222,
			["sub"] = v_u_99.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v221,
				["color"] = v_u_101.text2,
				["position"] = UDim2.new(1, -64, 0, 0),
				["size"] = UDim2.new(0, 56, 1, 0)
			}),
			["name"] = v231,
			["radio"] = v224,
			["dot"] = v225
		}
		v221.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_100, (ref) v_u_170, (copy) v_u_220, (copy) v_u_222, (copy) v_u_101
			v_u_99.sound(v_u_100.sounds.hover)
			local v232 = v_u_170
			if type(v232) ~= "table" or v_u_170.stamm ~= v_u_220 then
				v_u_222.Color = v_u_101.lineStrong
			end
		end)
		v221.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_222, (ref) v_u_170, (copy) v_u_220, (copy) v_u_101
			local v233 = v_u_222
			local v234 = v_u_170
			local v235
			if type(v234) == "table" and v_u_170.stamm == v_u_220 then
				v235 = v_u_101.info
			else
				v235 = v_u_101.line
			end
			v233.Color = v235
		end)
		v221.Activated:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_100, (copy) v_u_105, (copy) v_u_220
			v_u_99.sound(v_u_100.sounds.click)
			v_u_105.pickRegular(v_u_220)
		end)
		v_u_99.tooltip(v221, function()
			-- upvalues: (ref) v_u_170, (copy) v_u_220, (ref) v_u_171
			local v236 = v_u_170
			local v237
			if type(v236) == "table" then
				local v238 = v_u_170.traders
				if type(v238) == "table" and v_u_170.traders[v_u_220] then
					local v239 = v_u_170.traders[v_u_220].lvl
					v237 = tonumber(v239) or 1
				else
					v237 = 1
				end
			else
				v237 = 1
			end
			local v240 = v_u_170
			local v241
			if type(v240) == "table" and (v_u_170.stammDefault == v_u_220 and v_u_170.stammPicked ~= true) then
				local v242 = " "
				local v243 = v_u_220
				local v244
				if v_u_171 and v_u_171.defs then
					v244 = v_u_171.defs[v243]
				else
					v244 = nil
				end
				local v245
				if type(v244) == "table" then
					local v246 = v244.name
					if type(v246) == "string" then
						v245 = v244.name
						v241 = v242 .. v245 .. " is your regular trader until you pick another."
					else
						v245 = string.upper(v243)
						v241 = v242 .. v245 .. " is your regular trader until you pick another."
					end
				else
					v245 = string.upper(v243)
					v241 = v242 .. v245 .. " is your regular trader until you pick another."
				end
			else
				v241 = ""
			end
			local v247 = false
			local v248 = v_u_170
			if type(v248) == "table" then
				local v249 = v_u_170.traders
				if type(v249) == "table" then
					for _, v250 in v_u_170.traders do
						if type(v250) ~= "table" then
							continue
						end
						local v251 = v250.lvl
						if (tonumber(v251) or 1) < 4 then
							continue
						end
						local v252 = v250.rep
						local v253 = tonumber(v252) or 0
						local v254
						if v_u_171 then
							local v255 = v_u_171.REP_MAX
							v254 = tonumber(v255) or 1.5
						else
							v254 = 1.5
						end
						if v253 >= v254 - 1e-9 then
							continue
						end
						v247 = true
					end
				end
			end
			local v256
			if v237 >= 4 then
				v256 = "Now at LV " .. v237 .. "."
			elseif v247 then
				v256 = "Now at LV " .. v237 .. ", so for now it goes to the LV 4 trader with the least rep."
			else
				v256 = "Now at LV " .. v237 .. ". No trader is at LV 4 yet, so extracts give no trader rep for now."
			end
			local v257 = {}
			local v258 = "Regular trader: "
			local v259 = v_u_220
			local v260
			if v_u_171 and v_u_171.defs then
				v260 = v_u_171.defs[v259]
			else
				v260 = nil
			end
			local v261
			if type(v260) == "table" then
				local v262 = v260.name
				if type(v262) == "string" then
					v261 = v260.name
					v257.title = v258 .. v261
					v257.body = ("The reputation of your extracts goes here while this trader is at LV 4 or more and below 150 rep. %s%s"):format(v256, v241)
					return v257
				else
					v261 = string.upper(v259)
					v257.title = v258 .. v261
					v257.body = ("The reputation of your extracts goes here while this trader is at LV 4 or more and below 150 rep. %s%s"):format(v256, v241)
					return v257
				end
			else
				v261 = string.upper(v259)
				v257.title = v258 .. v261
				v257.body = ("The reputation of your extracts goes here while this trader is at LV 4 or more and below 150 rep. %s%s"):format(v256, v241)
				return v257
			end
		end)
	end
	v_u_99.tooltip(v_u_215, function()
		-- upvalues: (ref) v_u_171, (ref) v_u_170
		local v263 = v_u_171 and v_u_171.epWeight and { v_u_171.epWeight("Normal"), v_u_171.epWeight("Hard"), v_u_171.epWeight("Nightmare") } or { 1, 2, 3 }
		local v264 = {
			["title"] = "MISSION POINTS",
			["body"] = nil
		}
		local v265 = "Every extract gives mission points (EP): Normal +%d, Hard +%d, Nightmare +%d. Level 5 needs 100 EP, 150 rep and a buy-in. An extract also gives the same number of rep points to your regular trader (at LV 4 or higher).%s"
		local v266 = v263[1]
		local v267 = v263[2]
		local v268 = v263[3]
		local v269 = v_u_170
		local v270
		if type(v269) == "table" then
			local v271 = v_u_170.stammDefault
			if type(v271) == "string" and v_u_170.stammPicked ~= true then
				local v272 = " "
				local v273 = v_u_170.stammDefault
				local v274
				if v_u_171 and v_u_171.defs then
					v274 = v_u_171.defs[v273]
				else
					v274 = nil
				end
				local v275
				if type(v274) == "table" then
					local v276 = v274.name
					if type(v276) == "string" then
						v275 = v274.name
						v270 = v272 .. v275 .. " is your regular trader until you pick another."
						v264.body = v265:format(v266, v267, v268, v270)
						return v264
					else
						v275 = string.upper(v273)
						v270 = v272 .. v275 .. " is your regular trader until you pick another."
						v264.body = v265:format(v266, v267, v268, v270)
						return v264
					end
				else
					v275 = string.upper(v273)
					v270 = v272 .. v275 .. " is your regular trader until you pick another."
					v264.body = v265:format(v266, v267, v268, v270)
					return v264
				end
			else
				v270 = ""
				v264.body = v265:format(v266, v267, v268, v270)
				return v264
			end
		else
			v270 = ""
			v264.body = v265:format(v266, v267, v268, v270)
			return v264
		end
	end)
	local function v316()
		-- upvalues: (ref) v_u_170, (copy) p_u_97, (copy) v_u_215, (copy) v_u_216, (copy) v_u_217, (copy) v_u_205, (copy) v_u_101, (copy) v_u_145
		local v277 = v_u_170
		local v278
		if type(v277) == "table" and v_u_170.partners ~= nil then
			v278 = v_u_170.partners == true
		else
			local function v279()
				-- upvalues: (ref) p_u_97
				return p_u_97.cctx.config.flag("Partners")
			end
			local v280
			v278, v280 = pcall(v279)
			if v278 then
				v278 = v280 == true
			end
		end
		if v278 then
			local v281 = v_u_170
			if type(v281) == "table" then
				local v282 = v_u_170.ep
				v278 = type(v282) == "table"
			else
				v278 = false
			end
		end
		v_u_215.Visible = v278
		if v278 then
			local v283 = v_u_170.ep.have
			local v284 = tonumber(v283) or 0
			local v285 = v_u_170.ep.need
			local v286 = tonumber(v285) or 100
			local v287 = math.max(1, v286)
			local v288 = v_u_216
			local v289 = math.floor(v284)
			local v290 = math.max(0, v289)
			local v291 = math.floor(v287)
			local v292 = math.max(0, v291)
			v288.Text = ("EP %d / %d"):format(math.min(v290, v292), v287)
			local v293 = v_u_217.set
			local v294 = v284 / v287
			v293((math.clamp(v294, 0, 1)))
			v_u_215:SetAttribute("Ep", ("%d/%d"):format(v284, v287))
			local v295 = v_u_215
			local v296 = v_u_170.stamm
			v295:SetAttribute("Regular", (tostring(v296)))
			for v297, v298 in v_u_205 do
				local v299 = v_u_170.stamm == v297
				local v300 = v_u_170.traders
				local v301
				if type(v300) == "table" then
					v301 = v_u_170.traders[v297]
				else
					v301 = nil
				end
				local v302
				if v301 then
					local v303 = v301.lvl
					v302 = tonumber(v303) or 1
				else
					v302 = 1
				end
				local v304 = v298.btn
				local v305
				if v299 then
					v305 = v_u_101.raised2
				else
					v305 = v_u_101.bg
				end
				v304.BackgroundColor3 = v305
				v298.btn.BackgroundTransparency = v299 and 0 or 0.2
				local v306 = v298.stroke
				local v307
				if v299 then
					v307 = v_u_101.info
				else
					v307 = v_u_101.line
				end
				v306.Color = v307
				local v308 = v298.radio
				local v309
				if v299 then
					v309 = v_u_101.info
				else
					v309 = v_u_101.lineStrong
				end
				v308.Color = v309
				v298.dot.Visible = v299
				local v310 = v298.name
				local v311
				if v299 then
					v311 = v_u_101.text
				else
					v311 = v_u_101.text2
				end
				v310.TextColor3 = v311
				local v312 = v298.sub
				local v313
				if v302 >= 4 then
					v313 = ("REP %s"):format(v_u_145(v301.rep))
				else
					v313 = ("LV %d"):format(v302)
				end
				v312.Text = v313
				local v314 = v298.sub
				local v315
				if v302 >= 4 then
					if v299 then
						v315 = v_u_101.text
					else
						v315 = v_u_101.text2
					end
				else
					v315 = v_u_101.muted
				end
				v314.TextColor3 = v315
				v298.btn:SetAttribute("Selected", v299)
			end
		end
	end
	local v_u_317 = v_u_99.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_104 and 54 or (v_u_103 and 84 or 120))
	}, v164)
	local v_u_318 = nil
	local v319 = v_u_104 and 0 or (v_u_103 and 80 or 124)
	local v_u_320 = v_u_99.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "h1",
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_317,
		["textSize"] = v_u_104 and 24 or (v_u_103 and 26 or 34),
		["position"] = UDim2.fromOffset(v319, 0),
		["size"] = UDim2.new(0.5, 0, 0, v_u_104 and 28 or (v_u_103 and 32 or 40))
	})
	local v_u_321 = v_u_99.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_317,
		["color"] = v_u_101.text2,
		["position"] = UDim2.fromOffset(v319, v_u_104 and 28 or (v_u_103 and 34 or 40)),
		["size"] = UDim2.new(0.5, 0, 0, 18)
	})
	local v_u_322 = v_u_99.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["position"] = nil,
		["size"] = nil,
		["visible"] = nil,
		["parent"] = v_u_317,
		["color"] = v_u_101.text2,
		["position"] = UDim2.fromOffset(v319, 60),
		["size"] = UDim2.new(0.55, -60, 0, 44),
		["visible"] = not v_u_103
	})
	v_u_322.TextYAlignment = Enum.TextYAlignment.Top
	local v_u_323 = v_u_99.new("Frame", {
		["Name"] = "LevelBox",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(v_u_104 and 0.5 or 0.38, 0, 1, 0)
	}, v_u_317)
	local v_u_324 = v_u_99.label({
		["parent"] = nil,
		["text"] = "LV 1",
		["style"] = "monoL",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["visible"] = nil,
		["parent"] = v_u_323,
		["color"] = v_u_101.accent,
		["size"] = UDim2.new(1, 0, 0, 28),
		["visible"] = not v_u_104
	})
	local v_u_325 = v_u_102.bar(v_u_323, {
		["label"] = nil,
		["right"] = "0.00",
		["value"] = 0,
		["label"] = v_u_104 and "LV 1" or "Reputation"
	})
	v_u_325.frame.Position = UDim2.fromOffset(0, v_u_104 and 0 or (v_u_103 and 26 or 32))
	local v_u_326 = v_u_99.label({
		["parent"] = nil,
		["name"] = "Next",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["rich"] = true,
		["position"] = nil,
		["size"] = nil,
		["wrap"] = nil,
		["fit"] = nil,
		["track"] = false,
		["parent"] = v_u_323,
		["color"] = v_u_101.text2,
		["position"] = UDim2.fromOffset(0, v_u_104 and 40 or (v_u_103 and 66 or 76)),
		["size"] = UDim2.new(1, 0, 0, (v_u_104 or v_u_103) and 16 or 32),
		["wrap"] = not (v_u_103 or v_u_104),
		["fit"] = v_u_103 or v_u_104
	})
	v_u_326.TextYAlignment = Enum.TextYAlignment.Top
	local v327 = v_u_104 and 0 or (v_u_103 and 28 or 32)
	local v_u_328 = v_u_99.new("Frame", {
		["Name"] = "RepInfo",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = nil,
		["BackgroundColor3"] = v_u_101.raised,
		["Position"] = UDim2.fromOffset(0, v_u_317.Size.Y.Offset + 2),
		["Size"] = UDim2.new(1, 0, 0, v327),
		["Visible"] = not v_u_104
	}, v164)
	v_u_99.new("Frame", {
		["Name"] = "Tick",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_101.info,
		["Size"] = UDim2.new(0, 2, 1, 0)
	}, v_u_328)
	local v_u_329 = v_u_99.label({
		["parent"] = nil,
		["name"] = "How",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["rich"] = true,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v_u_328,
		["color"] = v_u_101.text2,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(1, -20, 1, 0)
	})
	local v_u_330 = v_u_317.Size.Y.Offset + (v_u_104 and 6 or v327 + 2 + 6)
	local v_u_331 = nil
	local v332 = nil
	local v333 = v_u_99.tabs
	local v334 = {
		["parent"] = nil,
		["position"] = nil,
		["size"] = nil,
		["tabs"] = nil,
		["selected"] = "buy",
		["onChange"] = nil,
		["parent"] = v164,
		["position"] = UDim2.fromOffset(0, v_u_330),
		["size"] = UDim2.new(1, 0, 0, v_u_100.touch(40))
	}
	local v_u_335 = {
		{
			["id"] = "buy",
			["text"] = "Buy"
		},
		{
			["id"] = "sell",
			["text"] = "Sell"
		},
		{
			["id"] = "tasks",
			["text"] = "Tasks"
		}
	}
	pcall(function()
		-- upvalues: (copy) p_u_97, (copy) v_u_335
		p_u_97.cctx.lib.MenuContracts.addTab(p_u_97, v_u_335)
	end)
	table.insert(v_u_335, {
		["id"] = "partner",
		["text"] = "Partner"
	})
	v334.tabs = v_u_335
	function v334.onChange(p336) -- name: onChange
		-- upvalues: (ref) v_u_1993, (copy) v_u_105
		v_u_1993 = p336
		v_u_105.drawBody()
	end
	local v337, v338 = v333(v334)
	v332 = v337
	local v_u_339 = v338
	v_u_105.subApi = v_u_339
	local v_u_340 = v332:FindFirstChild("Tab_partner", true)
	local function v_u_358() -- name: paintPartnerTab
		-- upvalues: (ref) v_u_170, (copy) p_u_97, (ref) v_u_340, (ref) v_u_1964, (ref) v_u_3, (ref) v_u_1993, (copy) v_u_99, (copy) v_u_101, (ref) v_u_339
		local v341 = v_u_170
		local v342
		if type(v341) == "table" and v_u_170.partners ~= nil then
			v342 = v_u_170.partners == true
		else
			local function v343()
				-- upvalues: (ref) p_u_97
				return p_u_97.cctx.config.flag("Partners")
			end
			local v344
			v342, v344 = pcall(v343)
			if v342 then
				v342 = v344 == true
			end
		end
		if v_u_340 then
			v_u_340.Visible = v342
			v_u_340.Selectable = v342
			local v345 = v_u_1964
			local v346 = v_u_170
			local v347
			if type(v346) == "table" then
				local v348 = v_u_170.traders
				if type(v348) == "table" then
					v347 = v_u_170.traders[v345]
				else
					v347 = nil
				end
			else
				v347 = nil
			end
			local v349 = v_u_3.partnerReady
			local v350 = v_u_170
			local v351
			if type(v350) == "table" and v_u_170.partners ~= nil then
				v351 = v_u_170.partners == true
			else
				local function v352()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v353
				v351, v353 = pcall(v352)
				if v351 then
					v351 = v353 == true
				end
			end
			local v354 = v349(v347, v351)
			local v355 = v_u_340:FindFirstChild("PartnerReady")
			local v356
			if v342 then
				if v354.ready == true then
					v356 = v_u_1993 ~= "partner"
				else
					v356 = false
				end
			else
				v356 = v342
			end
			if v356 then
				if not v355 then
					v355 = v_u_99.new("Frame", {
						["Name"] = "PartnerReady",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 6,
						["BackgroundColor3"] = v_u_101.success,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = UDim2.new(1, -6, 0, 6),
						["Size"] = UDim2.fromOffset(10, 10)
					}, v_u_340)
					v_u_99.new("UICorner", {
						["CornerRadius"] = UDim.new(0.5, 0)
					}, v355)
				end
				v355.Visible = true
			elseif v355 then
				v355.Visible = false
			end
			v_u_340:SetAttribute("PartnerReady", v356)
		end
		if not v342 and v_u_1993 == "partner" then
			v_u_1993 = "buy"
			local v357 = v_u_339.select
			pcall(v357, "buy", true)
		end
	end
	v_u_358()
	local v_u_359 = v316
	local v_u_360 = v332
	local v_u_361 = v_u_339
	local v_u_362 = {}
	for _, v363 in v332:GetDescendants() do
		local v364
		if v363:IsA("TextButton") then
			v364 = string.match(v363.Name, "^Tab_(.+)$")
		else
			v364 = nil
		end
		if not v364 then
			continue
		end
		table.insert(v_u_362, v364)
	end
	function v_u_105.showSub(p365) -- name: showSub
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_116, (copy) v_u_112, (ref) v_u_1993, (ref) v_u_168, (copy) v_u_362, (ref) v_u_170, (copy) p_u_97, (ref) v_u_361, (copy) v_u_105
		if v_u_115 and v_u_1964 == "gunsmith" then
			v_u_116(v_u_112[1])
		end
		if v_u_168 then
			local v366 = v_u_168.classic
			local v367 = v_u_362
			local v368 = v_u_170
			local v369
			if type(v368) == "table" and v_u_170.partners ~= nil then
				v369 = v_u_170.partners == true
			else
				local function v370()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v371
				v369, v371 = pcall(v370)
				if v369 then
					v369 = v371 == true
				end
			end
			p365 = v366(p365, v367, v369)
		end
		v_u_1993 = p365
		local v372 = v_u_361.select
		local v373 = v_u_1993
		pcall(v372, v373, true)
		v_u_105.draw()
	end
	function v_u_105.gotoCard(p374, p375) -- name: gotoCard
		-- upvalues: (copy) v_u_172, (ref) v_u_115, (ref) v_u_116, (ref) v_u_1993, (ref) v_u_168, (copy) v_u_362, (ref) v_u_170, (copy) p_u_97, (ref) v_u_361, (copy) v_u_105
		if v_u_172[p374] ~= nil and (p374 ~= "gunsmith" or v_u_115 ~= nil and v_u_115.cardVisible()) then
			v_u_116(p374)
			if p375 and p374 ~= "gunsmith" then
				if v_u_168 then
					local v376 = v_u_168.classic
					local v377 = v_u_362
					local v378 = v_u_170
					local v379
					if type(v378) == "table" and v_u_170.partners ~= nil then
						v379 = v_u_170.partners == true
					else
						local function v380()
							-- upvalues: (ref) p_u_97
							return p_u_97.cctx.config.flag("Partners")
						end
						local v381
						v379, v381 = pcall(v380)
						if v379 then
							v379 = v381 == true
						end
					end
					p375 = v376(p375, v377, v379)
				end
				v_u_1993 = p375
				local v382 = v_u_361.select
				local v383 = v_u_1993
				pcall(v382, v383, true)
				v_u_105.draw()
			end
		end
	end
	if v_u_104 then
		local v384 = v_u_360:FindFirstChild("Tab_sell", true)
		if v384 and v384:IsA("GuiObject") then
			v_u_99.tooltip(v384, function()
				return {
					["title"] = "STASH ONLY",
					["body"] = "Only items in your stash are offered. What you wear, carry and keep in your secure container is never sold. Move an item to the stash to sell it."
				}
			end)
		end
	end
	local v385 = v_u_330 + v_u_100.touch(40) + (v_u_104 and 8 or 10)
	local v_u_386 = v_u_99.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v385),
		["Size"] = UDim2.new(1, 0, 1, -v385)
	}, v164)
	if v_u_104 then
		v_u_331 = v_u_99.new("Frame", {
			["Name"] = "Act",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, v_u_330),
			["Size"] = UDim2.new(0, 1, 0, v_u_100.touch(40))
		}, v164)
	end
	local v_u_387 = v_u_99.new("Frame", {
		["Name"] = "GsTabs",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Position"] = UDim2.fromOffset(0, v_u_330),
		["Size"] = UDim2.new(1, 0, 0, v_u_100.touch(40))
	}, v164)
	local function v_u_389(p388) -- name: onGsTab
		-- upvalues: (ref) v_u_1993, (copy) v_u_105
		v_u_1993 = p388
		v_u_105.drawBody()
	end
	local function v_u_403() -- name: paintSubRow
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_360, (copy) v_u_330, (copy) v_u_100, (copy) v_u_104, (copy) v_u_317, (copy) v_u_386, (copy) v_u_387, (ref) v_u_1993, (copy) v_u_389, (ref) v_u_331, (ref) v_u_361, (ref) v_u_168, (copy) v_u_362, (ref) v_u_170, (copy) p_u_97
		local v390
		if v_u_115 == nil then
			v390 = false
		else
			v390 = v_u_1964 == "gunsmith"
		end
		v_u_360.Visible = not v390
		local v391 = v_u_330 + v_u_100.touch(40) + (v_u_104 and 8 or 10)
		if v390 and v_u_115.stage() == 0 then
			v391 = v_u_317.Size.Y.Offset + (v_u_104 and 6 or 10)
		end
		v_u_386.Position = UDim2.fromOffset(0, v391)
		v_u_386.Size = UDim2.new(1, 0, 1, -v391)
		if v390 then
			v_u_387.Size = UDim2.new(1, 0, 0, v_u_100.touch(40))
			v_u_1993 = v_u_115.syncTabs(v_u_387, v_u_1993, v_u_389)
			if v_u_104 then
				local v392 = v_u_331
				if v392 then
					v392.Visible = false
					v392.Size = UDim2.new(0, 1, 0, v_u_100.touch(40))
				end
				v_u_360.Size = UDim2.new(1, -0, 0, v_u_100.touch(40))
			end
		else
			v_u_387.Visible = false
			if v_u_1993 == "craft" or (v_u_1993 == "services" or v_u_1993 == "locked") then
				v_u_1993 = "buy"
				local v393 = v_u_361.select
				pcall(v393, "buy", true)
			end
			local v394 = v_u_1993
			if v_u_168 then
				local v395 = v_u_168.classic
				local v396 = v_u_362
				local v397 = v_u_170
				local v398
				if type(v397) == "table" and v_u_170.partners ~= nil then
					v398 = v_u_170.partners == true
				else
					local function v399()
						-- upvalues: (ref) p_u_97
						return p_u_97.cctx.config.flag("Partners")
					end
					local v400
					v398, v400 = pcall(v399)
					if v398 then
						v398 = v400 == true
					end
				end
				v394 = v395(v394, v396, v398)
			end
			v_u_1993 = v394
			if v_u_168 then
				if v_u_361.get() ~= v_u_1993 then
					local v401 = v_u_361.select
					local v402 = v_u_1993
					pcall(v401, v402, true)
				end
			end
		end
	end
	local function v_u_428(p404)
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_1965, (ref) v_u_1966, (ref) v_u_1967, (ref) v_u_1993, (ref) v_u_168, (copy) v_u_362, (ref) v_u_170, (copy) p_u_97, (ref) v_u_361, (copy) v_u_99, (copy) v_u_100, (copy) v_u_105
		local v405
		if v_u_115 == nil then
			v405 = false
		else
			v405 = v_u_1964 == "gunsmith"
		end
		if v405 then
			v_u_115.leave()
		end
		v_u_1964 = p404
		v_u_1965 = {}
		v_u_1966 = nil
		v_u_1967 = nil
		if v_u_115 and p404 == "gunsmith" then
			local v406
			if v_u_168 then
				local v407 = v_u_168.onSelect
				local v408 = true
				local v409 = v_u_1993
				local v410 = v_u_115.validSub("none")
				local v411 = v_u_362
				local v412 = v_u_170
				local v413
				if type(v412) == "table" and v_u_170.partners ~= nil then
					v413 = v_u_170.partners == true
				else
					local function v414()
						-- upvalues: (ref) p_u_97
						return p_u_97.cctx.config.flag("Partners")
					end
					local v415
					v413, v415 = pcall(v414)
					if v413 then
						v413 = v415 == true
					end
				end
				v406 = v407(v405, v408, v409, v410, v411, v413)
			else
				v406 = v_u_115.validSub("none")
			end
			v_u_1993 = v406
		elseif v_u_168 then
			local v416 = v_u_168.onSelect
			local v417 = false
			local v418 = v_u_1993
			local v419 = nil
			local v420 = v_u_362
			local v421 = v_u_170
			local v422
			if type(v421) == "table" and v_u_170.partners ~= nil then
				v422 = v_u_170.partners == true
			else
				local function v423()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v424
				v422, v424 = pcall(v423)
				if v422 then
					v422 = v424 == true
				end
			end
			v_u_1993 = v416(v405, v417, v418, v419, v420, v422)
			local v425 = v_u_361.select
			local v426 = v_u_1993
			pcall(v425, v426, true)
		elseif v_u_1993 == "craft" or (v_u_1993 == "services" or v_u_1993 == "locked") then
			v_u_1993 = "buy"
			local v427 = v_u_361.select
			pcall(v427, "buy", true)
		end
		v_u_99.sound(v_u_100.sounds.tab)
		v_u_105.draw()
	end
	local function v_u_431(p429) -- name: designWidth
		-- upvalues: (copy) v_u_100
		local v430 = p429:FindFirstAncestorWhichIsA("LayerCollector")
		if v430 then
			v430 = v430:FindFirstChild("Root")
		end
		if v430 and (v430:IsA("GuiObject") and (v430.AbsoluteSize.X > 40 and p429.AbsoluteSize.X > 1)) then
			return p429.AbsoluteSize.X / v430.AbsoluteSize.X * v_u_100.safeRefSize().X
		else
			return nil
		end
	end
	local function v_u_454(p432, p433, p434, p435, p_u_436, p_u_437, p_u_438, p_u_439) -- name: gridList
		-- upvalues: (copy) v_u_99, (copy) v_u_431, (copy) v_u_100
		local v_u_440 = v_u_99.list({
			["parent"] = p432,
			["name"] = p433,
			["position"] = p434,
			["size"] = p435,
			["gap"] = p_u_438,
			["padding"] = {
				2,
				10,
				2,
				6
			}
		})
		local v441 = v_u_440:FindFirstChildOfClass("UIListLayout")
		if v441 then
			v441:Destroy()
		end
		local v_u_442 = v_u_99.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(p_u_436, p_u_437),
			["CellPadding"] = UDim2.fromOffset(p_u_438, p_u_438),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v_u_440)
		local function v453() -- name: fit
			-- upvalues: (ref) v_u_431, (copy) v_u_440, (copy) p_u_439, (ref) v_u_100, (copy) p_u_438, (copy) p_u_436, (copy) v_u_442, (copy) p_u_437
			local v443 = v_u_431(v_u_440) or p_u_439
			if v443 < 40 then
				v443 = p_u_439
			end
			local v444 = v443 - (12 + (v_u_100.scrollBar or 6) + 1)
			local v445 = (v444 + p_u_438) / (p_u_436 + p_u_438)
			local v446 = math.floor(v445)
			local v447 = math.max(2, v446)
			local v448 = (v444 - (v447 - 1) * p_u_438) / v447
			local v449 = math.floor(v448)
			local v450 = v_u_442
			local v451 = UDim2.fromOffset
			local v452 = p_u_436 - 10
			v450.CellSize = v451(math.max(v452, v449), p_u_437)
			v_u_440:SetAttribute("Cols", v447)
		end
		v453()
		v_u_440:GetPropertyChangedSignal("AbsoluteSize"):Connect(v453)
		return v_u_440
	end
	local function v_u_456() -- name: bodyWidth
		-- upvalues: (copy) v_u_431, (copy) v_u_386, (copy) v_u_100, (copy) v_u_162
		local v455 = v_u_431(v_u_386)
		if v455 and v455 >= 200 then
			return v455
		else
			return v_u_100.safeRefSize().X - 48 - v_u_162 - 1 - 36
		end
	end
	local function v_u_465(p457) -- name: silhouette
		-- upvalues: (copy) v_u_101, (copy) v_u_99
		local v458 = p457:FindFirstChild("Tint")
		if v458 and v458:IsA("GuiObject") then
			v458.BackgroundTransparency = 1
		end
		local v459 = p457:FindFirstChildOfClass("UIStroke")
		if v459 then
			v459.Color = Color3.fromRGB(58, 68, 80)
		end
		for _, v_u_460 in p457:GetDescendants() do
			if not v_u_460:IsA("ViewportFrame") then
				continue
			end
			v_u_460.ImageColor3 = v_u_101.muted
			v_u_460.ImageTransparency = 0.35
			p457.Destroying:Connect(function()
				-- upvalues: (copy) v_u_460
				local function v461()
					-- upvalues: (ref) v_u_460
					v_u_460.ImageColor3 = Color3.new(1, 1, 1)
					v_u_460.ImageTransparency = 0
				end
				pcall(v461)
			end)
		end
		local v462 = p457.Size.X.Offset
		local v463 = p457.Size.Y.Offset
		local v464 = math.min(v462, v463)
		v_u_99.icon("lock", {
			["parent"] = nil,
			["size"] = nil,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 4,
			["parent"] = p457,
			["size"] = v464 >= 80 and 14 or 12,
			["color"] = v_u_101.text2,
			["position"] = UDim2.new(0, 5, 1, -5),
			["anchor"] = Vector2.new(0, 1)
		}).Name = "Unseen"
	end
	local function v_u_484(p466, p467, p468, p469, p470) -- name: chip
		-- upvalues: (copy) v_u_99, (copy) v_u_101
		local v471 = p470 or {}
		local v472 = v_u_99.new
		local v473 = "Frame"
		local v474 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["ZIndex"] = nil,
			["Name"] = v471.name or "Chip"
		}
		local v475
		if p469 then
			v475 = p468
		else
			v475 = v_u_101.bgDeep
		end
		v474.BackgroundColor3 = v475
		v474.BackgroundTransparency = p469 and 0 or 0.25
		v474.AutomaticSize = Enum.AutomaticSize.X
		v474.Size = UDim2.fromOffset(0, v471.h or 18)
		v474.Position = v471.position or UDim2.new()
		v474.AnchorPoint = v471.anchor or Vector2.zero
		v474.ZIndex = v471.zindex or 3
		local v476 = v472(v473, v474, p466)
		if not p469 then
			v_u_99.stroke(v476, p468, 1, 0.3)
		end
		v_u_99.pad(v476, {
			v471.icon and 4 or 6,
			6,
			0,
			0
		})
		v_u_99.layout(v476, "h", 3)
		if v471.icon then
			local v477 = v_u_99.icon
			local v478 = v471.icon
			local v479 = {
				["size"] = 10,
				["color"] = nil,
				["order"] = 1
			}
			local v480
			if p469 then
				v480 = v_u_101.bgDeep
			else
				v480 = p468
			end
			v479.color = v480
			local v481 = v477(v478, v479)
			v481.ZIndex = (v471.zindex or 3) + 1
			v481.Parent = v476
		end
		local v482 = v_u_99.label
		local v483 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["track"] = false,
			["zindex"] = nil,
			["parent"] = v476,
			["text"] = p467
		}
		if p469 then
			p468 = v_u_101.bgDeep
		end
		v483.color = p468
		v483.size = UDim2.fromOffset(0, v471.h or 18)
		v483.zindex = (v471.zindex or 3) + 1
		v482(v483)
		return v476
	end
	local v_u_485 = {}
	local v_u_2033 = false
	local v_u_487 = {}
	function v_u_105.filterState() -- name: fstate
		-- upvalues: (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8
		local v488 = v_u_1964 .. "/" .. v_u_1993
		local v489 = v_u_8[v488]
		if not v489 then
			v489 = {
				["cat"] = "all",
				["cal"] = nil
			}
			v_u_8[v488] = v489
		end
		return v489
	end
	local function v_u_500(p490) -- name: tagsOf
		-- upvalues: (copy) v_u_102, (ref) v_u_171, (ref) v_u_5
		local v491 = {
			["cats"] = {},
			["cals"] = {}
		}
		for _, v492 in p490 do
			local v493 = v_u_102.itemDef(v492)
			local v494
			if v493 then
				v494 = v493.category or nil
			else
				v494 = nil
			end
			if not v494 and type(v492) == "string" then
				if string.match(v492, "^water_") or string.match(v492, "^drink_") then
					v494 = "food"
				elseif v_u_171 then
					local v495 = v_u_171.groupOf
					if type(v495) == "function" then
						local v496 = v_u_171.groupOf
						local v497
						v497, v494 = pcall(v496, v492)
						if not v497 or type(v494) ~= "string" then
							v494 = nil
						end
					end
				end
			end
			local v498 = v_u_5[v494 or ""] or "gear"
			v491.cats[v498] = true
			if #p490 ~= 1 or (not v493 or v493.category ~= "ammo") then
				continue
			end
			local v499 = v493.caliber
			if type(v499) ~= "string" then
				continue
			end
			v491.cals[v493.caliber] = true
		end
		return v491
	end
	local function v_u_517() -- name: equippedCals
		-- upvalues: (copy) p_u_97, (copy) v_u_102
		local v501 = {}
		local v502 = p_u_97.profile
		local v_u_503 = nil
		local function v504()
			-- upvalues: (ref) v_u_503, (ref) p_u_97
			v_u_503 = p_u_97.cctx.lib.InvUIAmmo
		end
		pcall(v504)
		if not v_u_503 or type(v502) ~= "table" then
			return v501
		end
		local v505 = v_u_503
		for _, v506 in { "primary", "secondary" } do
			local v507 = v505.slotItem
			local v508 = v502.inv
			local v509, v510 = pcall(v507, v508, v506)
			local v511
			if v509 and type(v510) == "table" then
				v511 = v_u_102.itemDef(v510.id) or nil
			else
				v511 = nil
			end
			if not v511 or v511.category ~= "firearm" then
				continue
			end
			local v512 = v511.caliber
			if type(v512) ~= "string" then
				continue
			end
			local v513 = false
			for _, v514 in v501 do
				v513 = v513 or v514.cal == v511.caliber
			end
			if v513 then
				break
			end
			local v515 = {
				["cal"] = v511.caliber
			}
			local v516 = v511.short or (v511.name or "")
			v515.short = tostring(v516)
			table.insert(v501, v515)
		end
		return v501
	end
	local function v_u_543(p518, p519, p520, p521, p_u_522, p523, p524, p_u_525) -- name: fchip
		-- upvalues: (copy) v_u_99, (copy) v_u_101, (copy) v_u_100
		local v_u_526 = p_u_522 or p521 > 0
		local v527 = v_u_99.new
		local v528 = "TextButton"
		local v529 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = nil,
			["Name"] = "F_" .. p519
		}
		local v530
		if p_u_522 then
			v530 = v_u_101.accentDeep
		else
			v530 = v_u_101.raised
		end
		v529.BackgroundColor3 = v530
		v529.BackgroundTransparency = p_u_522 and 0.05 or (v_u_526 and 0.3 or 0.6)
		v529.AutomaticSize = Enum.AutomaticSize.X
		v529.Size = UDim2.fromOffset(v_u_100.touch(24), p524)
		v529.LayoutOrder = p523
		v529.Selectable = v_u_526
		local v531 = v527(v528, v529, p518)
		v531.SelectionImageObject = v_u_99.selectionImage()
		local v532 = v_u_99.stroke
		local v533
		if p_u_522 then
			v533 = v_u_101.accent
		else
			v533 = v_u_101.line
		end
		local v_u_534 = v532(v531, v533)
		v_u_99.pad(v531, {
			10,
			10,
			0,
			0
		})
		v_u_99.layout(v531, "h", 6)
		local v535 = v_u_99.label
		local v536 = {
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 1,
			["parent"] = v531,
			["text"] = p520
		}
		local v537
		if p_u_522 then
			v537 = v_u_101.text
		elseif v_u_526 then
			v537 = v_u_101.text2
		else
			v537 = v_u_101.muted
		end
		v536.color = v537
		v536.size = UDim2.new(0, 0, 1, 0)
		v535(v536)
		local v538 = v_u_99.label
		local v539 = {
			["parent"] = nil,
			["name"] = "Count",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["track"] = false,
			["parent"] = v531,
			["text"] = tostring(p521)
		}
		local v540
		if p_u_522 then
			v540 = v_u_101.accent
		else
			v540 = v_u_101.muted
		end
		v539.color = v540
		v539.size = UDim2.new(0, 0, 1, 0)
		v538(v539)
		v531:SetAttribute("Count", p521)
		v531:SetAttribute("On", p_u_522)
		v531.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_526, (copy) p_u_522, (ref) v_u_99, (ref) v_u_100, (copy) v_u_534, (ref) v_u_101
			if v_u_526 and not p_u_522 then
				v_u_99.sound(v_u_100.sounds.hover)
				v_u_534.Color = v_u_101.lineStrong
			end
		end)
		v531.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_534, (copy) p_u_522, (ref) v_u_101
			local v541 = v_u_534
			local v542
			if p_u_522 then
				v542 = v_u_101.accent
			else
				v542 = v_u_101.line
			end
			v541.Color = v542
		end)
		v531.Activated:Connect(function()
			-- upvalues: (copy) v_u_526, (ref) v_u_99, (ref) v_u_100, (copy) p_u_525
			if v_u_526 then
				p_u_525()
			else
				v_u_99.sound(v_u_100.sounds.error)
			end
		end)
		return v531
	end
	function v_u_105.setFilter(p544, p545) -- name: setFilter
		-- upvalues: (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (copy) v_u_99, (copy) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (copy) v_u_105
		local v546 = v_u_1964 .. "/" .. v_u_1993
		local v547 = v_u_8[v546]
		if not v547 then
			v547 = {
				["cat"] = "all",
				["cal"] = nil
			}
			v_u_8[v546] = v547
		end
		if v547.cat ~= p544 or v547.cal ~= p545 then
			v547.cat = p544
			if p544 ~= "ammo" then
				p545 = nil
			end
			v547.cal = p545
			v_u_99.sound(v_u_100.sounds.tab)
			v_u_2033 = true
			v_u_1986 = false
			v_u_105.drawBody()
		end
	end
	local function v_u_607(p548, p549, p550, p551) -- name: filterBar
		-- upvalues: (copy) v_u_485, (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (copy) v_u_100, (ref) v_u_4, (copy) v_u_99, (copy) v_u_101, (copy) v_u_487, (copy) v_u_543, (ref) v_u_2033, (ref) v_u_1986, (copy) v_u_105, (copy) v_u_517, (ref) v_u_6, (ref) v_u_7
		table.clear(v_u_485)
		local v552 = v_u_1964 .. "/" .. v_u_1993
		local v553 = v_u_8[v552]
		if not v553 then
			v553 = {
				["cat"] = "all",
				["cal"] = nil
			}
			v_u_8[v552] = v553
		end
		local v554 = v_u_100.touch(32)
		local v555 = {}
		for _, v556 in v_u_4 do
			v555[v556.id] = 0
		end
		for _, v557 in p550 do
			v555.all = v555.all + 1
			for v558 in v557.cats do
				v555[v558] = (v555[v558] or 0) + 1
			end
		end
		local v559 = v_u_99.list({
			["parent"] = nil,
			["name"] = "Filters",
			["horizontal"] = true,
			["gap"] = 6,
			["position"] = nil,
			["size"] = nil,
			["parent"] = p548,
			["position"] = UDim2.fromOffset(0, p549),
			["size"] = UDim2.new(1, 0, 0, v554 + 6)
		})
		local v_u_560 = v_u_99.label({
			["parent"] = nil,
			["name"] = "PadPrev",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 0,
			["track"] = false,
			["parent"] = v559,
			["text"] = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("aim"),
			["color"] = v_u_101.text2,
			["size"] = UDim2.new(0, 0, 0, v554)
		})
		local v_u_561 = v_u_99.label({
			["parent"] = nil,
			["name"] = "PadNext",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 100,
			["track"] = false,
			["parent"] = v559,
			["text"] = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("fire"),
			["color"] = v_u_101.text2,
			["size"] = UDim2.new(0, 0, 0, v554)
		})
		local function v569() -- name: glyphs
			-- upvalues: (ref) v_u_99, (copy) v_u_560, (copy) v_u_561
			local v562 = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("aim")
			local v563 = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("fire")
			local v564 = v_u_561
			v_u_560.Text = v562
			v564.Text = v563
			local v565 = v_u_560
			local v566 = v_u_561
			local v567 = v562 ~= ""
			local v568 = v563 ~= ""
			v565.Visible = v567
			v566.Visible = v568
		end
		local v570 = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("aim")
		local v571 = v_u_99.device() ~= "Gamepad" and "" or v_u_99.hint("fire")
		v_u_560.Text = v570
		v_u_561.Text = v571
		local v572 = v570 ~= ""
		local v573 = v571 ~= ""
		v_u_560.Visible = v572
		v_u_561.Visible = v573
		local v574 = v_u_487
		table.insert(v574, v569)
		local v575 = {}
		for v576, v577 in v_u_4 do
			local v_u_578 = v577.id
			v_u_485[v_u_578] = v_u_543(v559, v_u_578, v577.text, v555[v_u_578] or 0, v553.cat == v_u_578, v576, v554, function()
				-- upvalues: (copy) v_u_578, (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (ref) v_u_99, (ref) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (ref) v_u_105
				local v579 = v_u_578
				local v580 = v_u_1964 .. "/" .. v_u_1993
				local v581 = v_u_8[v580]
				if not v581 then
					v581 = {
						["cat"] = "all",
						["cal"] = nil
					}
					v_u_8[v580] = v581
				end
				if v581.cat ~= v579 or v581.cal ~= nil then
					v581.cat = v579
					local _ = v579 == "ammo"
					local v582 = nil
					v581.cal = v582
					v_u_99.sound(v_u_100.sounds.tab)
					v_u_2033 = true
					v_u_1986 = false
					v_u_105.drawBody()
				end
			end)
			local v583 = v555[v_u_578] or 0
			table.insert(v575, ("%s=%d"):format(v_u_578, v583))
		end
		v559:SetAttribute("Counts", table.concat(v575, " "))
		if p551 then
			p551(v559)
		end
		local v584 = v554 + 6
		if v553.cat == "ammo" then
			local v585 = {}
			for _, v586 in p550 do
				for v587 in v586.cals do
					v585[v587] = (v585[v587] or 0) + 1
				end
			end
			local v588 = {}
			for _, v589 in v_u_517() do
				local v590 = {
					["cal"] = v589.cal,
					["text"] = (v_u_6[v589.cal] or v589.cal) .. "  \194\183  " .. v589.short,
					["n"] = v585[v589.cal] or 0
				}
				table.insert(v588, v590)
				v585[v589.cal] = nil
			end
			local v591 = {}
			for v592 in v585 do
				table.insert(v591, v592)
			end
			table.sort(v591, function(p593, p594)
				-- upvalues: (ref) v_u_7
				return (v_u_7[p593] or 99) < (v_u_7[p594] or 99)
			end)
			for _, v595 in v591 do
				local v596 = {
					["cal"] = v595,
					["text"] = v_u_6[v595] or v595,
					["n"] = v585[v595]
				}
				table.insert(v588, v596)
			end
			local v597 = v_u_100.touch(30)
			local v598 = v_u_99.list({
				["parent"] = nil,
				["name"] = "Calibres",
				["horizontal"] = true,
				["gap"] = 6,
				["position"] = nil,
				["size"] = nil,
				["parent"] = p548,
				["position"] = UDim2.fromOffset(0, p549 + v584 + 2),
				["size"] = UDim2.new(1, 0, 0, v597 + 6)
			})
			v_u_485["cal:"] = v_u_543(v598, "cal_all", "All calibres", v555.ammo or 0, v553.cal == nil, 1, v597, function()
				-- upvalues: (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (ref) v_u_99, (ref) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (ref) v_u_105
				local v599 = v_u_1964 .. "/" .. v_u_1993
				local v600 = v_u_8[v599]
				if not v600 then
					v600 = {
						["cat"] = "all",
						["cal"] = nil
					}
					v_u_8[v599] = v600
				end
				if v600.cat ~= "ammo" or v600.cal ~= nil then
					v600.cat = "ammo"
					v600.cal = nil
					v_u_99.sound(v_u_100.sounds.tab)
					v_u_2033 = true
					v_u_1986 = false
					v_u_105.drawBody()
				end
			end)
			for v601, v602 in v588 do
				local v_u_603 = v602.cal
				v_u_485["cal:" .. v_u_603] = v_u_543(v598, "cal_" .. v_u_603, v602.text, v602.n, v553.cal == v_u_603, v601 + 1, v597, function()
					-- upvalues: (copy) v_u_603, (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (ref) v_u_99, (ref) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (ref) v_u_105
					local v604 = v_u_603
					local v605 = v_u_1964 .. "/" .. v_u_1993
					local v606 = v_u_8[v605]
					if not v606 then
						v606 = {
							["cat"] = "all",
							["cal"] = nil
						}
						v_u_8[v605] = v606
					end
					if v606.cat ~= "ammo" or v606.cal ~= v604 then
						v606.cat = "ammo"
						v606.cal = v604
						v_u_99.sound(v_u_100.sounds.tab)
						v_u_2033 = true
						v_u_1986 = false
						v_u_105.drawBody()
					end
				end)
			end
			v584 = v584 + (2 + v597 + 6)
		end
		return v584
	end
	local function v_u_619(p608) -- name: cycleFilter
		-- upvalues: (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (ref) v_u_4, (copy) v_u_485, (copy) v_u_99, (copy) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (copy) v_u_105
		local v609 = v_u_1964 .. "/" .. v_u_1993
		local v610 = v_u_8[v609]
		if not v610 then
			v610 = {
				["cat"] = "all",
				["cal"] = nil
			}
			v_u_8[v609] = v610
		end
		local v611 = {}
		for _, v612 in v_u_4 do
			local v613 = v_u_485[v612.id]
			if v612.id ~= "all" and (v612.id ~= v610.cat and (not v613 or (tonumber(v613:GetAttribute("Count")) or 0) <= 0)) then
				continue
			end
			local v614 = v612.id
			table.insert(v611, v614)
		end
		local v615 = v611[((table.find(v611, v610.cat) or 1) - 1 + p608) % #v611 + 1]
		if v615 and v615 ~= v610.cat then
			local v616 = v_u_1964 .. "/" .. v_u_1993
			local v617 = v_u_8[v616]
			if not v617 then
				v617 = {
					["cat"] = "all",
					["cal"] = nil
				}
				v_u_8[v616] = v617
			end
			if v617.cat == v615 and v617.cal == nil then
				return
			end
			v617.cat = v615
			local _ = v615 == "ammo"
			local v618 = nil
			v617.cal = v618
			v_u_99.sound(v_u_100.sounds.tab)
			v_u_2033 = true
			v_u_1986 = false
			v_u_105.drawBody()
		end
	end
	v_u_105.cycleFilter = v_u_619
	local function v_u_622() -- name: onScreen
		-- upvalues: (copy) p_u_98, (copy) p_u_97
		local v620 = p_u_98
		while v620 and not v620:IsA("LayerCollector") do
			if v620:IsA("GuiObject") and not v620.Visible then
				return false
			end
			v620 = v620.Parent
		end
		if not v620 or v620:IsA("ScreenGui") and not v620.Enabled then
			return false
		end
		local v621 = p_u_97.cctx
		if v621 then
			v621 = p_u_97.cctx.player
		end
		if v621 then
			v621 = v621:FindFirstChildOfClass("PlayerGui")
		end
		if v621 then
			v621 = v621:FindFirstChild("HushModal")
		end
		if v621 then
			v621 = v621:FindFirstChild("Modal", true)
		end
		return not v621
	end
	local function v_u_627() -- name: focusFilter
		-- upvalues: (copy) v_u_99, (ref) v_u_1, (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_8, (copy) v_u_485
		if v_u_99.device() == "Gamepad" then
			local v623 = v_u_1.SelectedObject
			if not (v623 and v623:IsDescendantOf(game)) then
				local v624 = v_u_1964 .. "/" .. v_u_1993
				local v625 = v_u_8[v624]
				if not v625 then
					v625 = {
						["cat"] = "all",
						["cal"] = nil
					}
					v_u_8[v624] = v625
				end
				local v626 = v625.cat == "ammo" and v_u_485["cal:" .. (v625.cal or "")] or v_u_485[v625.cat]
				if v626 and v626.Parent then
					v_u_1.SelectedObject = v626
				end
			end
		else
			return
		end
	end
	local function v638()
		-- upvalues: (ref) v_u_115, (copy) p_u_97, (copy) v_u_104, (copy) v_u_103, (copy) p_u_98, (copy) v_u_456, (copy) v_u_431, (copy) v_u_454, (ref) v_u_1993, (ref) v_u_1964, (copy) v_u_622, (ref) v_u_428, (ref) v_u_361, (copy) v_u_105, (ref) v_u_122, (ref) v_u_2033
		local v637 = {
			["phone"] = v_u_104,
			["compact"] = v_u_103,
			["page"] = p_u_98,
			["bodyWidth"] = v_u_456,
			["designWidth"] = v_u_431,
			["gridList"] = v_u_454,
			["isActive"] = function() -- name: isActive
				-- upvalues: (ref) v_u_1993, (ref) v_u_1964, (ref) v_u_622
				local v628
				if (v_u_1993 == "craft" or v_u_1993 == "services") and v_u_1964 == "gunsmith" then
					v628 = v_u_622()
				else
					v628 = false
				end
				return v628
			end,
			["goto"] = function(p629, p630) -- name: goto
				-- upvalues: (ref) v_u_428, (ref) v_u_1993, (ref) v_u_361, (ref) v_u_105
				v_u_428(p629)
				v_u_1993 = p630
				local v631 = v_u_361.select
				pcall(v631, p630, true)
				v_u_105.draw()
			end,
			["taskState"] = function(p632) -- name: taskState
				-- upvalues: (ref) v_u_122
				local v633 = v_u_122
				local v634
				if type(v633) == "table" then
					local v635 = v_u_122.tasks
					if type(v635) == "table" then
						v634 = v_u_122.tasks or nil
					else
						v634 = nil
					end
				else
					v634 = nil
				end
				return v634 and ((v634[p632] or {}).state or "locked") or "locked"
			end,
			["redraw"] = function(p636) -- name: redraw
				-- upvalues: (ref) v_u_2033, (ref) v_u_105
				if p636 then
					v_u_2033 = true
				end
				v_u_105.drawBody()
			end
		}
		v_u_115 = p_u_97.cctx.lib.MenuGunsmith.new(p_u_97, v637)
	end
	local v639, v640 = pcall(v638)
	if not v639 then
		v_u_115 = nil
		warn("[MenuTraders] the Gunsmith card is off:", v640)
	end
	local function v_u_646(p641) -- name: lockChip
		local v642 = p641.locked or ""
		local v643 = tostring(v642)
		local v644 = string.match(v643, "Level%s+(%d+)")
		local v645 = string.find(v643, "Task:", 1, true) ~= nil
		if v644 == "5" and not v645 then
			return "PARTNER"
		elseif v644 and v645 then
			return "LV " .. v644 .. " + TASK"
		else
			return not v644 and (v645 and "TASK" or "LOCKED") or "LV " .. v644
		end
	end
	local function v_u_669(p647, p648) -- name: lockText
		-- upvalues: (copy) p_u_97, (copy) v_u_145, (copy) v_u_166, (ref) v_u_1964
		local v649 = p647.locked
		local v650 = tostring(v649)
		local v651 = p647.lvl
		local v652 = tonumber(v651) or 1
		local v653
		if type(p648) == "table" then
			local v654 = p648.lvl
			v653 = tonumber(v654) or 1
		else
			v653 = 1
		end
		if v652 >= 5 and string.find(v650, "Level", 1, true) then
			return "Partners only (level 5).\nOpen the PARTNER tab. It needs LV 4, 150 rep, 100 EP and a one time buy in."
		end
		if not string.find(v650, "Level", 1, true) or v653 >= v652 then
			return v650
		end
		local v655
		if type(p648) == "table" then
			local v656 = p648.next
			if type(v656) == "table" then
				v655 = p648.next
			else
				v655 = nil
			end
		else
			v655 = nil
		end
		if not v655 or v652 ~= v653 + 1 then
			return v650 .. ("\nYou are LV %d. Raise %s one level at a time."):format(v653, v_u_166(v_u_1964).name)
		end
		local v657 = p_u_97.profile
		local v658
		if type(v657) == "table" then
			local v659 = p_u_97.profile.stats
			v658 = type(v659) ~= "table" and {} or p_u_97.profile.stats
		else
			v658 = {}
		end
		local v660 = v_u_145(p648.rep)
		local v661 = v655.rep
		local v662 = (tonumber(v661) or 0) * 100 + 0.5
		local v663 = math.floor(v662)
		local v664 = v658.extracts
		local v665 = tonumber(v664) or 0
		local v666 = math.floor(v665)
		local v667 = v655.extracts
		local v668 = tonumber(v667) or 0
		return v650 .. ("\nYou are LV %d: rep %s / %d, extracts %d / %d."):format(v653, v660, v663, v666, (math.floor(v668)))
	end
	local v_u_670 = {}
	local function v_u_671(_) end
	local v_u_672 = {
		["buy"] = nil,
		["sold"] = nil,
		["sold"] = {}
	}
	function v_u_105.buyNow(p_u_673, p674) -- name: buyNow
		-- upvalues: (copy) v_u_672, (copy) v_u_99, (copy) v_u_100, (copy) p_u_97, (ref) v_u_1964, (ref) v_u_128, (ref) v_u_671, (copy) p_u_98
		if not v_u_672.buy or os.clock() - v_u_672.buy.t >= 4 then
			v_u_672.buy = {
				["key"] = p_u_673.key,
				["t"] = os.clock()
			}
			v_u_99.sound(v_u_100.sounds.click)
			local v675 = tonumber(p674) or 1
			local v676 = math.floor(v675)
			local v677 = math.clamp(v676, 1, 50)
			p_u_97.op({
				["op"] = "buy",
				["trader"] = nil,
				["offer"] = nil,
				["count"] = nil,
				["trader"] = v_u_1964,
				["offer"] = p_u_673.key,
				["count"] = v677
			})
			if v_u_128 == p_u_673 then
				v_u_671(p_u_673)
			end
			task.delay(4.1, function()
				-- upvalues: (ref) v_u_672, (ref) p_u_98, (ref) v_u_128, (copy) p_u_673, (ref) v_u_671
				if v_u_672.buy and (os.clock() - v_u_672.buy.t >= 4 and (p_u_98.Parent and v_u_128 == p_u_673)) then
					v_u_672.buy = nil
					v_u_671(p_u_673)
				end
			end)
		end
	end
	local function v_u_700(p678, p679, p680, p681) -- name: struckPrice
		-- upvalues: (copy) v_u_99, (copy) v_u_102, (copy) v_u_101, (copy) v_u_100
		local v682 = v_u_99.new("Frame", {
			["Name"] = "WasPrice",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = p681.anchor or Vector2.new(0, 0),
			["Position"] = p681.position,
			["Size"] = p681.size
		}, p678)
		local v683 = v_u_99.new
		local v684 = "UIListLayout"
		local v685 = {
			["FillDirection"] = Enum.FillDirection.Horizontal
		}
		local v686
		if p681.right then
			v686 = Enum.HorizontalAlignment.Right
		else
			v686 = Enum.HorizontalAlignment.Left
		end
		v685.HorizontalAlignment = v686
		v685.VerticalAlignment = Enum.VerticalAlignment.Center
		v685.Padding = UDim.new(0, 6)
		v685.SortOrder = Enum.SortOrder.LayoutOrder
		v683(v684, v685, v682)
		local v687 = p681.style or "monoS"
		local v688 = v_u_99.label({
			["parent"] = nil,
			["name"] = "Base",
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 1,
			["parent"] = v682,
			["text"] = v_u_102.money(p679),
			["style"] = v687,
			["color"] = v_u_101.muted,
			["size"] = UDim2.new(0, 0, 1, 0)
		})
		local v689 = v_u_100.uiScale
		local v690, v691 = pcall(v689)
		local v692 = (not v690 or type(v691) ~= "number") and 1 or v691
		local v693 = 1 / math.max(v692, 0.25)
		local v694 = math.ceil(v693)
		local v695 = math.max(1, v694)
		v_u_99.new("Frame", {
			["Name"] = "Strike",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_101.text2,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.fromScale(0, 0.55),
			["Size"] = UDim2.new(1, 0, 0, v695)
		}, v688)
		local v696 = p681.pct
		local v697 = tonumber(v696)
		if not v697 or v697 <= 0 then
			v697 = 1 - p680 / p679
		end
		local v698 = v697 * 100 + 0.5
		local v699 = math.floor(v698)
		if v699 > 0 then
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Off",
				["text"] = nil,
				["style"] = nil,
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v682,
				["text"] = ("-%d%%"):format(v699),
				["style"] = v687,
				["color"] = v_u_101.info,
				["size"] = UDim2.new(0, 0, 1, 0)
			})
		end
		return v682
	end
	local function v_u_739(p701, p702) -- name: stashFit
		-- upvalues: (copy) p_u_97
		local v_u_703 = nil
		local function v704()
			-- upvalues: (ref) v_u_703, (ref) p_u_97
			v_u_703 = p_u_97.cctx.shared.Grid
		end
		pcall(v704)
		local v705 = p_u_97.profile
		local v706
		if type(v705) == "table" then
			local v707 = v705.inv
			if type(v707) == "table" then
				local v708 = v705.inv.containers
				if type(v708) == "table" then
					v706 = v705.inv.containers.stash or nil
				else
					v706 = nil
				end
			else
				v706 = nil
			end
		else
			v706 = nil
		end
		if v_u_703 and type(v706) == "table" then
			local v709 = v706.w
			if tonumber(v709) then
				local v710 = v706.h
				if tonumber(v710) then
					local v711 = v706.items
					if type(v711) == "table" then
						local v712 = {
							["id"] = "stash",
							["w"] = nil,
							["h"] = nil,
							["limit"] = nil,
							["items"] = nil,
							["w"] = v706.w,
							["h"] = v706.h,
							["limit"] = v706.limit,
							["items"] = {}
						}
						local v713 = v_u_703
						for _, v714 in v706.items do
							if type(v714) ~= "table" then
								continue
							end
							local v715 = v712.items
							local v716 = {}
							local v717 = v714.uid
							v716.uid = tostring(v717)
							v716.id = v714.id
							v716.x = v714.x or 0
							v716.y = v714.y or 0
							v716.r = v714.r == true
							v716.n = v714.n
							v716.mods = v714.mods
							v716.items = v714.items
							v716.fir = v714.fir
							table.insert(v715, v716)
						end
						local v718 = p701.items
						local v719
						if type(v718) == "table" then
							v719 = p701.items
						else
							v719 = {
								{
									["id"] = p701.id,
									["n"] = p701.n
								}
							}
						end
						local v720 = 0
						for v721 = 1, p702 do
							for _, v722 in v719 do
								local v723 = v722.n
								local v724 = tonumber(v723) or 1
								local v725 = math.max(1, v724)
								local v726 = v713.stackMax
								local v727 = {
									["uid"] = "",
									["id"] = nil,
									["x"] = 0,
									["y"] = 0,
									["r"] = false,
									["n"] = 1,
									["id"] = v722.id
								}
								local v728, v729 = pcall(v726, v727)
								local v730 = (not v728 or type(v729) ~= "number") and 1 or math.max(1, v729)
								if v730 > 1 then
									for _, v731 in v712.items do
										if v725 <= 0 then
											break
										end
										if v731.id ~= v722.id or (v731.mods ~= nil or (v731.items ~= nil or (v731.fir or (v731.n or 1) >= v730))) then
											continue
										end
										local v732 = v730 - (v731.n or 1)
										local v733 = math.min(v725, v732)
										v731.n = (v731.n or 1) + v733
										v725 = v725 - v733
									end
								end
								while v725 > 0 do
									local v734 = math.min(v725, v730)
									v720 = v720 + 1
									local v735 = v713.autoPlace
									local v736 = {
										["uid"] = nil,
										["id"] = nil,
										["x"] = 0,
										["y"] = 0,
										["r"] = false,
										["n"] = nil,
										["uid"] = "_qty" .. v720,
										["id"] = v722.id,
										["n"] = v734
									}
									local v737, v738 = pcall(v735, v712, v736)
									if not v737 then
										return p702
									end
									if not v738 then
										return v721 - 1
									end
									v725 = v725 - v734
								end
							end
						end
						return p702
					end
				end
			end
		end
		return p702
	end
	v_u_105.stashFit = v_u_739
	local function v_u_742(p740, p741) -- name: emptyOrRetry
		-- upvalues: (ref) v_u_120, (copy) v_u_102, (copy) v_u_99, (copy) v_u_100, (copy) v_u_105
		if v_u_120 then
			v_u_102.empty(p740, "Could not load. Try again.", 1)
			v_u_99.button({
				["parent"] = nil,
				["name"] = "TryAgain",
				["text"] = "Try again",
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = 200,
				["order"] = 2,
				["onClick"] = nil,
				["parent"] = p740,
				["height"] = v_u_100.touch(44),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_105
					v_u_105.reload()
				end
			})
		else
			v_u_102.empty(p740, p741)
		end
	end
	local function v_u_1132() -- name: drawBuy
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (ref) v_u_670, (ref) v_u_127, (ref) v_u_128, (copy) v_u_99, (copy) v_u_386, (copy) v_u_742, (copy) p_u_97, (copy) v_u_103, (copy) v_u_431, (copy) v_u_100, (copy) v_u_162, (copy) v_u_104, (ref) v_u_331, (copy) v_u_102, (ref) v_u_360, (ref) v_u_1993, (ref) v_u_8, (copy) v_u_500, (copy) v_u_607, (copy) v_u_101, (copy) v_u_139, (ref) v_u_171, (copy) v_u_166, (copy) v_u_124, (ref) v_u_1967, (copy) v_u_454, (ref) v_u_1986, (copy) v_u_105, (copy) v_u_125, (ref) v_u_169, (copy) v_u_465, (copy) v_u_700, (copy) v_u_484, (copy) v_u_646, (ref) v_u_135, (ref) v_u_671, (ref) v_u_1, (ref) v_u_1977, (copy) v_u_739, (ref) v_u_136, (ref) v_u_137, (copy) v_u_669, (ref) v_u_3, (copy) v_u_672
		local v_u_743
		if v_u_115 and v_u_1964 == "gunsmith" then
			v_u_743 = v_u_115.traderView()
		else
			local v744 = v_u_170
			if type(v744) == "table" then
				local v745 = v_u_170.traders
				v_u_743 = type(v745) == "table" and v_u_170.traders[v_u_1964] or nil
			else
				v_u_743 = nil
			end
		end
		v_u_670 = {}
		v_u_127 = nil
		v_u_128 = nil
		if v_u_743 then
			local v746 = v_u_743.offers
			if type(v746) == "table" then
				local v747 = p_u_97.profile
				if v747 then
					v747 = p_u_97.profile.cash
				end
				local v748 = tonumber(v747) or 0
				local v749 = v_u_103 and 300 or 340
				local v750 = v_u_431(v_u_386)
				if not v750 or v750 < 200 then
					v750 = v_u_100.safeRefSize().X - 48 - v_u_162 - 1 - 36
				end
				if v750 < 820 then
					local v751 = v750 * 0.34
					local v752 = math.floor(v751)
					v749 = math.max(260, v752)
				end
				local v753 = v_u_104 and 0 or v749 + 14
				local v754 = v_u_104 and 0 or 26
				local v755 = v_u_104 and 0 or v754 + 4
				local v756 = nil
				if v_u_104 then
					if v_u_331 then
						v_u_102.clear(v_u_331)
					end
					if v_u_104 then
						local v757 = v_u_331
						if v757 then
							v757.Visible = false
							v757.Size = UDim2.new(0, 1, 0, v_u_100.touch(40))
						end
						v_u_360.Size = UDim2.new(1, -0, 0, v_u_100.touch(40))
					end
				else
					v756 = v_u_99.new("Frame", {
						["Name"] = "Toolbar",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["Size"] = UDim2.new(1, -v753, 0, v754)
					}, v_u_386)
				end
				local v758 = v_u_1964 .. "/" .. v_u_1993
				local v759 = v_u_8[v758]
				if not v759 then
					v759 = {
						["cat"] = "all",
						["cal"] = nil
					}
					v_u_8[v758] = v759
				end
				local v760 = {}
				local v761 = {}
				for _, v762 in v_u_743.offers do
					local v763 = v762.items
					local v764
					if type(v763) == "table" and #v762.items > 1 then
						v764 = {}
					else
						v764 = {}
						local v765 = v762.id
						if not v765 then
							local v766 = v762.items
							v765 = type(v766) == "table" and v762.items[1] and (v762.items[1].id or "mat_scrap") or "mat_scrap"
						end
						__set_list(v764, 1, {v765})
					end
					local v767 = v762.items
					if type(v767) == "table" and #v762.items > 1 then
						for _, v768 in v762.items do
							local v769 = v768.id
							table.insert(v764, v769)
						end
					end
					local v770 = v_u_500(v764)
					local v771 = v762.key
					v760[tostring(v771)] = v770
					table.insert(v761, v770)
				end
				local v_u_772 = v_u_99.new("Frame", {
					["Name"] = "FilterBox",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(0, v755),
					["Size"] = UDim2.new(1, -v753, 0, 0)
				}, v_u_386)
				local v773 = v_u_607(v_u_772, 0, v761)
				v_u_772.Size = UDim2.new(1, -v753, 0, v773)
				local v774 = 0
				local v775 = 0
				for _, v776 in v_u_743.offers do
					local v777 = v776.key
					local v778 = v760[tostring(v777)]
					local v779
					if v759.cat == "all" or v778.cats[v759.cat] then
						v779 = (v759.cat ~= "ammo" or (not v759.cal or v778.cals[v759.cal])) and true or false
					else
						v779 = false
					end
					if not v779 then
						continue
					end
					v774 = v774 + 1
					if v776.locked then
						continue
					end
					v775 = v775 + 1
				end
				if v756 then
					v_u_99.label({
						["parent"] = nil,
						["name"] = "Count",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v756,
						["text"] = ("%d offers  \194\183  %d locked"):format(v775, v774 - v775),
						["color"] = v_u_101.text2,
						["size"] = UDim2.new(0.6, 0, 1, 0)
					})
				end
				local v780 = v_u_743.restockAt
				local v781 = tonumber(v780)
				if not v781 then
					local v782 = v_u_170.restockAt
					v781 = tonumber(v782)
				end
				if v781 then
					local v783 = v781 - os.time()
					local v784 = math.max(0, v783)
					local v785
					if v_u_104 then
						v785 = v_u_99.new("Frame", {
							["Name"] = "Restock",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.fromScale(1, 1)
						}, v_u_331)
						if v_u_104 then
							local v786 = v_u_331
							if v786 then
								v786.Visible = true
								v786.Size = UDim2.new(0, 150, 0, v_u_100.touch(40))
							end
							v_u_360.Size = UDim2.new(1, -158, 0, v_u_100.touch(40))
						end
					else
						v785 = v_u_99.new("Frame", {
							["Name"] = "Restock",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(1, 0),
							["Position"] = UDim2.fromScale(1, 0),
							["Size"] = UDim2.new(0.4, 0, 1, 0)
						}, v756)
					end
					v_u_139.label = v_u_99.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "monoS",
						["align"] = "right",
						["size"] = nil,
						["fit"] = true,
						["parent"] = v785,
						["text"] = "Restock in " .. v_u_99.clock(v784),
						["size"] = UDim2.fromScale(1, 1)
					})
					v_u_139.at = v781
					v785:SetAttribute("RestockAt", v781)
					v_u_99.tooltip(v785, function()
						-- upvalues: (ref) v_u_171, (copy) v_u_743, (ref) v_u_166, (ref) v_u_1964
						local v787 = {}
						local v788
						if v_u_171 then
							local v789 = v_u_171.RESTOCK_BY_LEVEL
							v788 = type(v789) ~= "table" and {} or v_u_171.RESTOCK_BY_LEVEL
						else
							v788 = {}
						end
						for v790, v791 in v788 do
							local v792 = v_u_743.maxLevel
							if v790 > (tonumber(v792) or 4) then
								continue
							end
							local v793 = v791 / 60
							local v794 = math.floor(v793)
							local v795 = v791 % 60
							local v796 = "LV %d %s%s"
							local v797
							if v795 > 0 then
								v797 = ("%d:%02d"):format(v794, v795)
							else
								v797 = tostring(v794)
							end
							table.insert(v787, v796:format(v790, v797, " min"))
						end
						local v798 = v_u_743.lvl
						local v799 = tonumber(v798) or 1
						return {
							["title"] = "RESTOCK",
							["body"] = nil,
							["body"] = ("Stock limits (2 / 3 on a tile) reset when the clock runs out. %s restocks faster at a higher level: %s. You are at LV %d."):format(v_u_166(v_u_1964).name, table.concat(v787, ", "), v799)
						}
					end)
				end
				if v_u_102.newOffers then
					local v800 = v_u_102.newOffers
					local v801 = v_u_1964
					local v802, v803 = pcall(v800, v801)
					if v802 and type(v803) == "table" then
						for v804 in v803 do
							v_u_124[v804] = true
						end
					end
				end
				local v805 = {}
				for v806, v807 in v_u_743.offers do
					local v808 = v807.key
					local v809 = v760[tostring(v808)]
					local v810
					if v759.cat == "all" or v809.cats[v759.cat] then
						v810 = (v759.cat ~= "ammo" or (not v759.cal or v809.cals[v759.cal])) and true or false
					else
						v810 = false
					end
					if not v810 then
						continue
					end
					table.insert(v805, {
						["o"] = v807,
						["i"] = v806
					})
				end
				table.sort(v805, function(p811, p812)
					if p811.o.locked ~= nil == (p812.o.locked ~= nil) then
						return p811.i < p812.i
					else
						return p811.o.locked == nil
					end
				end)
				local v813 = false
				for _, v814 in v805 do
					local v815 = v814.o.key
					if tostring(v815) ~= v_u_1967 then
						continue
					end
					v813 = true
				end
				if not v813 then
					local v816
					if v805[1] then
						local v817 = v805[1].o.key
						v816 = tostring(v817)
					else
						v816 = nil
					end
					v_u_1967 = v816
				end
				local v818 = v_u_104 and 52 or (v_u_103 and 72 or 84)
				local v819 = false
				for _, v820 in v805 do
					local v821 = v820.o
					local v822 = v821.basePrice
					local v823 = tonumber(v822)
					local v824 = v821.price
					local v825 = tonumber(v824)
					if not v823 or (not v825 or v825 >= v823) then
						v823 = nil
					end
					if not v823 then
						continue
					end
					v819 = true
				end
				local v826 = v819 and 14 or 0
				local v827 = v818 + (v_u_104 and 80 or 74) + v826
				local v828 = v755 + v773 + 4
				local v_u_829 = v_u_454(v_u_386, "Offers", UDim2.fromOffset(0, v828), UDim2.new(1, -v753, 1, -v828), v_u_104 and 124 or (v_u_103 and 138 or 150), v827, 8, v750 - v753)
				local v830 = v_u_99.new
				local v831 = "Frame"
				local v832 = {
					["Name"] = "Detail",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = nil
				}
				local v833
				if v_u_104 then
					v833 = Vector2.zero
				else
					v833 = Vector2.new(1, 0)
				end
				v832.AnchorPoint = v833
				local v834
				if v_u_104 then
					v834 = UDim2.new()
				else
					v834 = UDim2.fromScale(1, 0)
				end
				v832.Position = v834
				local v835
				if v_u_104 then
					v835 = UDim2.fromScale(1, 1)
				else
					v835 = UDim2.new(0, v749, 1, 0)
				end
				v832.Size = v835
				v832.Visible = not v_u_104
				local v_u_836 = v830(v831, v832, v_u_386)
				local v837 = v_u_100.touch(40)
				local v_u_838
				if v_u_104 then
					v_u_838 = function(p839)
						-- upvalues: (ref) v_u_1986, (copy) v_u_836, (copy) v_u_829, (copy) v_u_772
						v_u_1986 = p839
						v_u_836.Visible = p839
						v_u_829.Visible = not p839
						v_u_772.Visible = not p839
					end
					v_u_105.openDetail = v_u_838
				else
					v_u_838 = function(_) end
				end
				table.clear(v_u_125)
				local v840 = {}
				local v841 = 0
				for v842, v843 in v805 do
					local v_u_844 = v843.o
					local v845 = v_u_844.key
					local v_u_846 = tostring(v845)
					v840[v_u_846] = v_u_844
					local v_u_847 = v_u_844.id
					if not v_u_847 then
						local v848 = v_u_844.items
						v_u_847 = type(v848) == "table" and v_u_844.items[1] and (v_u_844.items[1].id or "mat_scrap") or "mat_scrap"
					end
					local v_u_849
					if v_u_124[v_u_846] == true then
						v_u_849 = not v_u_844.locked
					else
						v_u_849 = false
					end
					local v850 = v_u_844.price
					local v851 = tonumber(v850) or 0
					local v852 = not v_u_844.locked
					if v852 then
						local v853 = v_u_844.left
						if tonumber(v853) == nil then
							v852 = false
						else
							local v854 = v_u_844.left
							v852 = (tonumber(v854) or 0) <= 0
						end
					end
					local v_u_855 = v_u_99.new("TextButton", {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["LayoutOrder"] = nil,
						["Selectable"] = true,
						["ClipsDescendants"] = true,
						["Name"] = v_u_846,
						["BackgroundColor3"] = v_u_101.raised,
						["LayoutOrder"] = v842
					}, v_u_829)
					v_u_855.SelectionImageObject = v_u_99.selectionImage()
					local v856 = v_u_99.stroke
					local v857
					if v_u_849 then
						v857 = v_u_101.info
					else
						v857 = v_u_101.line
					end
					local v_u_858 = v856(v_u_855, v857)
					local v859 = v_u_844.items
					local v860
					if type(v859) == "table" then
						v860 = #v_u_844.items > 1
					else
						v860 = false
					end
					local v861 = not v860
					local v866 = v_u_102.itemCell(v_u_855, v_u_847, {
						["size"] = nil,
						["count"] = nil,
						["wish"] = false,
						["tooltip"] = nil,
						["size"] = v818,
						["count"] = v_u_844.n,
						["tooltip"] = v_u_169 and (v_u_169.tooltip and v861) and function()
							-- upvalues: (ref) v_u_169, (copy) v_u_847, (copy) v_u_844
							local v862 = v_u_169.tooltip
							local v863 = {
								["uid"] = "",
								["id"] = nil,
								["x"] = 0,
								["y"] = 0,
								["r"] = false,
								["n"] = nil,
								["id"] = v_u_847
							}
							local v864 = v_u_844.n
							local v865 = tonumber(v864) or 1
							v863.n = math.max(1, v865)
							return v862(v863)
						end or nil
					})
					v866.AnchorPoint = Vector2.new(0.5, 0)
					v866.Position = UDim2.new(0.5, 0, 0, 10)
					if v861 then
						local v867
						if v_u_844.locked then
							local v868 = p_u_97.profile
							local v869
							if type(v868) == "table" then
								v869 = v868.collection
							else
								v869 = false
							end
							if type(v869) == "table" then
								v867 = v869[v_u_847] ~= true
							else
								v867 = false
							end
						else
							v867 = false
						end
						if v867 then
							v_u_465(v866)
						end
					end
					local v870 = v_u_99.label
					local v871 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["textSize"] = 14,
						["color"] = nil,
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["wrap"] = nil,
						["fitWrap"] = false,
						["valign"] = nil,
						["parent"] = v_u_855,
						["text"] = v_u_844.name or v_u_102.itemName(v_u_847)
					}
					local v872
					if v_u_844.locked then
						v872 = v_u_101.text2
					else
						v872 = v_u_101.text
					end
					v871.color = v872
					v871.position = UDim2.fromOffset(8, v818 + (v_u_104 and 14 or 18))
					v871.size = UDim2.new(1, -16, 0, v_u_104 and 32 or 18)
					v871.wrap = v_u_104
					v871.valign = v_u_104 and "top" or nil
					local v873 = v870(v871)
					if v_u_104 then
						v873.TextTruncate = Enum.TextTruncate.AtEnd
					end
					local v874 = v_u_99.new("Frame", {
						["Name"] = "Foot",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(0, 10, 1, -10),
						["Size"] = UDim2.new(1, -20, 0, 20)
					}, v_u_855)
					local v875 = v_u_99.label
					local v876 = {
						["parent"] = nil,
						["name"] = "Price",
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v874,
						["text"] = v_u_102.money(v851)
					}
					local v877
					if v_u_844.locked then
						v877 = v_u_101.text2
					elseif v851 <= v748 then
						v877 = v_u_101.accent
					else
						v877 = v_u_101.danger
					end
					v876.color = v877
					v876.size = UDim2.new(0.55, 0, 1, 0)
					v875(v876)
					local v878 = v_u_844.basePrice
					local v879 = tonumber(v878)
					local v880 = v_u_844.price
					local v881 = tonumber(v880)
					if not v879 or (not v881 or v881 >= v879) then
						v879 = nil
					end
					if v879 then
						v_u_700(v_u_855, v879, v851, {
							["anchor"] = Vector2.new(0, 1),
							["position"] = UDim2.new(0, 10, 1, -31),
							["size"] = UDim2.new(1, -20, 0, v826),
							["pct"] = v_u_743.discount
						})
					end
					if v_u_844.locked then
						v_u_484(v874, v_u_646(v_u_844), v_u_101.danger, false, {
							["name"] = "Lock",
							["icon"] = "lock",
							["anchor"] = nil,
							["position"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					elseif v852 then
						v_u_484(v874, "SOLD OUT", v_u_101.muted, false, {
							["name"] = "Stock",
							["anchor"] = nil,
							["position"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					else
						local v882 = v_u_844.limit
						if tonumber(v882) and v_u_844.limit > 0 then
							local v883 = v_u_484
							local v884
							if v_u_104 then
								local v885 = v_u_844.left
								v884 = ("%d left"):format(tonumber(v885) or 0)
							else
								local v886 = v_u_844.left
								v884 = ("%d / %d left"):format(tonumber(v886) or 0, v_u_844.limit)
							end
							v883(v874, v884, v_u_101.text2, false, {
								["name"] = "Stock",
								["anchor"] = nil,
								["position"] = nil,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, 0, 0.5, 0)
							})
						end
					end
					if v_u_849 then
						v841 = v841 + 1
						v_u_484(v_u_855, "NEW", v_u_101.info, true, {
							["name"] = "New",
							["position"] = nil,
							["h"] = 16,
							["zindex"] = 6,
							["position"] = UDim2.fromOffset(6, 6)
						})
					end
					if not v861 then
						v_u_484(v_u_855, ("%d items"):format(#v_u_844.items), v_u_101.text2, false, {
							["name"] = "Kit",
							["anchor"] = nil,
							["position"] = nil,
							["h"] = 16,
							["zindex"] = 6,
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.new(1, -6, 0, 6)
						})
					end
					if v_u_844.locked then
						local v887 = v_u_844.task
						if type(v887) == "string" then
							local v888 = string.find
							local v889 = v_u_844.locked
							if v888(tostring(v889), "Task:", 1, true) then
								v_u_125[v_u_846] = function()
									-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) p_u_97, (copy) v_u_844
									v_u_99.sound(v_u_100.sounds.click)
									p_u_97.openTask(v_u_844.task)
								end
							end
						end
					end
					local v_u_890 = false
					v_u_670[v_u_846] = function() -- name: paint
						-- upvalues: (ref) v_u_1967, (copy) v_u_846, (copy) v_u_855, (ref) v_u_101, (ref) v_u_890, (copy) v_u_844, (copy) v_u_858, (copy) v_u_849
						local v891 = v_u_1967 == v_u_846
						local v892 = v_u_855
						local v893
						if v891 then
							v893 = v_u_101.accentDeep
						elseif v_u_890 then
							v893 = v_u_101.raised2
						else
							v893 = v_u_101.raised
						end
						v892.BackgroundColor3 = v893
						v_u_855.BackgroundTransparency = v891 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
						local v894 = v_u_858
						local v895
						if v891 then
							v895 = v_u_101.accent
						elseif v_u_890 then
							v895 = v_u_101.lineStrong
						elseif v_u_849 then
							v895 = v_u_101.info
						else
							v895 = v_u_101.line
						end
						v894.Color = v895
					end
					local v896 = v_u_1967 == v_u_846
					local v897
					if v896 then
						v897 = v_u_101.accentDeep
					elseif v_u_890 then
						v897 = v_u_101.raised2
					else
						v897 = v_u_101.raised
					end
					v_u_855.BackgroundColor3 = v897
					v_u_855.BackgroundTransparency = v896 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
					local v898
					if v896 then
						v898 = v_u_101.accent
					elseif v_u_890 then
						v898 = v_u_101.lineStrong
					elseif v_u_849 then
						v898 = v_u_101.info
					else
						v898 = v_u_101.line
					end
					v_u_858.Color = v898
					v_u_855.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_890, (ref) v_u_99, (ref) v_u_100, (ref) v_u_1967, (copy) v_u_846, (copy) v_u_855, (ref) v_u_101, (copy) v_u_844, (copy) v_u_858, (copy) v_u_849
						v_u_890 = true
						v_u_99.sound(v_u_100.sounds.hover)
						local v899 = v_u_1967 == v_u_846
						local v900 = v_u_855
						local v901
						if v899 then
							v901 = v_u_101.accentDeep
						elseif v_u_890 then
							v901 = v_u_101.raised2
						else
							v901 = v_u_101.raised
						end
						v900.BackgroundColor3 = v901
						v_u_855.BackgroundTransparency = v899 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
						local v902 = v_u_858
						local v903
						if v899 then
							v903 = v_u_101.accent
						elseif v_u_890 then
							v903 = v_u_101.lineStrong
						elseif v_u_849 then
							v903 = v_u_101.info
						else
							v903 = v_u_101.line
						end
						v902.Color = v903
					end)
					v_u_855.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_890, (ref) v_u_1967, (copy) v_u_846, (copy) v_u_855, (ref) v_u_101, (copy) v_u_844, (copy) v_u_858, (copy) v_u_849
						v_u_890 = false
						local v904 = v_u_1967 == v_u_846
						local v905 = v_u_855
						local v906
						if v904 then
							v906 = v_u_101.accentDeep
						elseif v_u_890 then
							v906 = v_u_101.raised2
						else
							v906 = v_u_101.raised
						end
						v905.BackgroundColor3 = v906
						v_u_855.BackgroundTransparency = v904 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
						local v907 = v_u_858
						local v908
						if v904 then
							v908 = v_u_101.accent
						elseif v_u_890 then
							v908 = v_u_101.lineStrong
						elseif v_u_849 then
							v908 = v_u_101.info
						else
							v908 = v_u_101.line
						end
						v907.Color = v908
					end)
					v_u_855.SelectionGained:Connect(function()
						-- upvalues: (ref) v_u_890, (ref) v_u_1967, (copy) v_u_846, (ref) v_u_135, (ref) v_u_670, (ref) v_u_671, (copy) v_u_844, (copy) v_u_855, (ref) v_u_101, (copy) v_u_858, (copy) v_u_849
						v_u_890 = true
						if v_u_1967 ~= v_u_846 then
							v_u_1967 = v_u_846
							v_u_135 = 1
							for _, v909 in v_u_670 do
								v909()
							end
							v_u_671(v_u_844)
						end
						local v910 = v_u_1967 == v_u_846
						local v911 = v_u_855
						local v912
						if v910 then
							v912 = v_u_101.accentDeep
						elseif v_u_890 then
							v912 = v_u_101.raised2
						else
							v912 = v_u_101.raised
						end
						v911.BackgroundColor3 = v912
						v_u_855.BackgroundTransparency = v910 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
						local v913 = v_u_858
						local v914
						if v910 then
							v914 = v_u_101.accent
						elseif v_u_890 then
							v914 = v_u_101.lineStrong
						elseif v_u_849 then
							v914 = v_u_101.info
						else
							v914 = v_u_101.line
						end
						v913.Color = v914
					end)
					v_u_855.SelectionLost:Connect(function()
						-- upvalues: (ref) v_u_890, (ref) v_u_1967, (copy) v_u_846, (copy) v_u_855, (ref) v_u_101, (copy) v_u_844, (copy) v_u_858, (copy) v_u_849
						v_u_890 = false
						local v915 = v_u_1967 == v_u_846
						local v916 = v_u_855
						local v917
						if v915 then
							v917 = v_u_101.accentDeep
						elseif v_u_890 then
							v917 = v_u_101.raised2
						else
							v917 = v_u_101.raised
						end
						v916.BackgroundColor3 = v917
						v_u_855.BackgroundTransparency = v915 and 0.05 or (v_u_844.locked and 0.5 or 0.2)
						local v918 = v_u_858
						local v919
						if v915 then
							v919 = v_u_101.accent
						elseif v_u_890 then
							v919 = v_u_101.lineStrong
						elseif v_u_849 then
							v919 = v_u_101.info
						else
							v919 = v_u_101.line
						end
						v918.Color = v919
					end)
					v_u_855.Activated:Connect(function()
						-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) v_u_1967, (copy) v_u_846, (ref) v_u_135, (ref) v_u_670, (ref) v_u_671, (copy) v_u_844, (ref) v_u_104, (ref) v_u_838, (ref) v_u_127, (ref) v_u_1
						v_u_99.sound(v_u_100.sounds.click)
						if v_u_1967 ~= v_u_846 then
							v_u_1967 = v_u_846
							v_u_135 = 1
							for _, v920 in v_u_670 do
								v920()
							end
							v_u_671(v_u_844)
						end
						if v_u_104 then
							v_u_838(true)
						end
						if v_u_99.device() == "Gamepad" and (v_u_127 and v_u_127.Parent) then
							v_u_1.SelectedObject = v_u_127
						end
					end)
				end
				if #v805 == 0 then
					v_u_102.empty(v_u_829, #v_u_743.offers == 0 and "This trader has nothing for sale." or "Nothing in this filter. Pick another one above.")
				end
				v_u_105.buyNew = v841
				v_u_829:SetAttribute("Shown", #v805)
				local v_u_921
				if v_u_104 then
					v_u_99.iconButton({
						["parent"] = nil,
						["name"] = "Back",
						["icon"] = "chevronLeft",
						["kind"] = "secondary",
						["size"] = nil,
						["position"] = nil,
						["onClick"] = nil,
						["tooltip"] = "Back to the list",
						["parent"] = v_u_836,
						["size"] = v837,
						["position"] = UDim2.fromOffset(0, 0),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_838
							v_u_838(false)
						end
					})
					local v922
					v922, v_u_921 = v_u_99.panel({
						["parent"] = nil,
						["name"] = "Panel",
						["raised"] = true,
						["position"] = nil,
						["size"] = nil,
						["padding"] = 10,
						["parent"] = v_u_836,
						["position"] = UDim2.fromOffset(v837 + 8, 0),
						["size"] = UDim2.new(1, -(v837 + 8), 1, 0)
					})
				else
					local v923
					v923, v_u_921 = v_u_99.panel({
						["parent"] = nil,
						["name"] = "Panel",
						["raised"] = true,
						["size"] = nil,
						["padding"] = 14,
						["parent"] = v_u_836,
						["size"] = UDim2.fromScale(1, 1)
					})
				end
				v_u_671 = function(p_u_924)
					-- upvalues: (ref) v_u_102, (ref) v_u_921, (ref) v_u_127, (ref) v_u_128, (ref) p_u_97, (ref) v_u_1977, (ref) v_u_739, (ref) v_u_100, (ref) v_u_136, (ref) v_u_137, (ref) v_u_135, (ref) v_u_104, (ref) v_u_99, (ref) v_u_103, (ref) v_u_169, (ref) v_u_465, (ref) v_u_101, (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (ref) v_u_669, (copy) v_u_743, (ref) v_u_3, (ref) v_u_700, (ref) v_u_105, (ref) v_u_672
					v_u_102.clear(v_u_921)
					v_u_127 = nil
					v_u_128 = p_u_924
					if not p_u_924 then
						v_u_102.empty(v_u_921, "Pick an offer on the left.")
						return
					end
					local v_u_925 = p_u_924.id
					if not v_u_925 then
						local v926 = p_u_924.items
						v_u_925 = type(v926) == "table" and p_u_924.items[1] and (p_u_924.items[1].id or "mat_scrap") or "mat_scrap"
					end
					local v_u_927 = v_u_102.itemDef(v_u_925)
					local v928 = p_u_924.price
					local v_u_929 = tonumber(v928) or 0
					local v930 = p_u_97.profile
					if v930 then
						v930 = p_u_97.profile.cash
					end
					local v_u_931 = tonumber(v930) or 0
					local v932 = p_u_924.items
					local v933
					if type(v932) == "table" then
						v933 = #p_u_924.items > 1
					else
						v933 = false
					end
					local v934 = not v933
					local v935 = not p_u_924.locked
					if v935 then
						local v936 = p_u_924.left
						if tonumber(v936) == nil then
							v935 = false
						else
							local v937 = p_u_924.left
							v935 = (tonumber(v937) or 0) <= 0
						end
					end
					local v938 = not (p_u_924.locked or (v935 or v_u_1977))
					if v938 then
						v938 = v_u_739(p_u_924, 1) < 1
					end
					local v939 = not p_u_924.locked
					if v939 then
						v939 = not v935
						if v939 then
							v939 = not v938
						end
					end
					local v940 = v_u_100.touch(36)
					local v941 = p_u_924.basePrice
					local v942 = tonumber(v941)
					local v943 = p_u_924.price
					local v944 = tonumber(v943)
					if not v942 or (not v944 or v944 >= v942) then
						v942 = nil
					end
					local v945 = (v942 and 122 or 104) + (not v939 and 0 or v940 + 8)
					v_u_136 = 1
					v_u_137 = nil
					if v939 then
						local v946 = 50
						local v947 = p_u_924.limit
						if tonumber(v947) then
							local v948 = p_u_924.limit
							if (tonumber(v948) or 0) > 0 then
								local v949 = p_u_924.left
								local v950 = tonumber(v949) or 0
								v946 = math.min(v946, v950)
							end
						end
						if v_u_929 > 0 then
							local v951 = v_u_931 / v_u_929
							local v952 = math.floor(v951)
							v946 = math.min(v946, v952)
						end
						if v946 > 1 and not v_u_1977 then
							v946 = v_u_739(p_u_924, v946)
						end
						v_u_136 = math.max(1, v946)
					end
					local v953 = v_u_135
					local v954 = v_u_136
					v_u_135 = math.clamp(v953, 1, v954)
					local v955 = v_u_921
					local v956, v957
					if v_u_104 then
						local v958 = v_u_100.safeRefSize().X - 576
						v956 = math.clamp(v958, 260, 330)
						v955 = v_u_99.new("Frame", {
							["Name"] = "Facts",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, -(v956 + 12), 1, 0)
						}, v_u_921)
						v957 = v_u_99.new("Frame", {
							["Name"] = "Buy",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(1, 0),
							["Position"] = UDim2.fromScale(1, 0),
							["Size"] = UDim2.new(0, v956, 1, 0)
						}, v_u_921)
					else
						v957 = nil
						v956 = 330
					end
					local v959 = v_u_104 and 72 or (v_u_103 and 84 or 104)
					local v960 = v_u_99.new("Frame", {
						["Name"] = "Top",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v959)
					}, v955)
					local v961 = (not v_u_104 or (not v_u_927 or string.find(v_u_925, "^zombie_"))) and 0 or v_u_100.touch(40)
					if v961 > 0 then
						v_u_102.wishStar(v960, v_u_925, {
							["size"] = 18,
							["hit"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["zindex"] = 4,
							["hit"] = v961,
							["position"] = UDim2.new(1, 0, 0, -8),
							["anchor"] = Vector2.new(1, 0)
						})
					end
					local v966 = v_u_102.itemCell(v960, v_u_925, {
						["size"] = v959,
						["count"] = p_u_924.n,
						["wish"] = v961 == 0,
						["tooltip"] = v_u_169 and (v_u_169.tooltip and v934) and function()
							-- upvalues: (ref) v_u_169, (copy) v_u_925, (copy) p_u_924
							local v962 = v_u_169.tooltip
							local v963 = {
								["uid"] = "",
								["id"] = nil,
								["x"] = 0,
								["y"] = 0,
								["r"] = false,
								["n"] = nil,
								["id"] = v_u_925
							}
							local v964 = p_u_924.n
							local v965 = tonumber(v964) or 1
							v963.n = math.max(1, v965)
							return v962(v963)
						end or nil
					})
					if v934 then
						local v967
						if p_u_924.locked then
							local v968 = p_u_97.profile
							local v969
							if type(v968) == "table" then
								v969 = v968.collection
							else
								v969 = false
							end
							if type(v969) == "table" then
								v967 = v969[v_u_925] ~= true
							else
								v967 = false
							end
						else
							v967 = false
						end
						if v967 then
							v_u_465(v966)
						end
					end
					v_u_99.label({
						["parent"] = nil,
						["name"] = "Title",
						["text"] = nil,
						["style"] = "h3",
						["wrap"] = true,
						["fit"] = true,
						["position"] = nil,
						["size"] = nil,
						["valign"] = "top",
						["parent"] = v960,
						["text"] = p_u_924.name or v_u_102.itemName(v_u_925),
						["position"] = UDim2.fromOffset(v959 + 12, 0),
						["size"] = UDim2.new(1, -v959 - 12 - v961, 0, 44)
					})
					local v970
					if v_u_927 then
						local function v971()
							-- upvalues: (ref) p_u_97, (copy) v_u_927
							return p_u_97.cctx.shared.Items.displayCategory(v_u_927.category)
						end
						local v972
						v972, v970 = pcall(v971)
						if not v972 or type(v970) ~= "string" then
							local v973 = v_u_927.category or ""
							v970 = tostring(v973)
						end
						local v974 = v_u_100.rarityName
						if v974 then
							local v975 = v_u_100.rarityName
							local v976 = v_u_927.shown or v_u_927.rarity
							local v977 = tonumber(v976) or 1
							v974 = v975[math.clamp(v977, 1, 6)]
						end
						if v974 then
							v970 = v970 .. "  \194\183  " .. v974
						end
					else
						v970 = ""
					end
					if not v934 then
						v970 = ("Bundle of %d items"):format(#p_u_924.items)
					end
					local v978 = v_u_99.label
					local v979 = {
						["parent"] = nil,
						["name"] = "Category",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v960,
						["text"] = v970
					}
					local v980
					if v_u_927 then
						v980 = v_u_100.rarityColor(v_u_927.shown or v_u_927.rarity)
					else
						v980 = v_u_101.text2
					end
					v979.color = v980
					v979.position = UDim2.fromOffset(v959 + 12, 48)
					v979.size = UDim2.new(1, -v959 - 12, 0, 16)
					v978(v979)
					local v981
					if v_u_115 and v_u_1964 == "gunsmith" then
						v981 = v_u_115.traderView()
					else
						local v982 = v_u_170
						if type(v982) == "table" then
							local v983 = v_u_170.traders
							v981 = type(v983) == "table" and v_u_170.traders[v_u_1964] or nil
						else
							v981 = nil
						end
					end
					local v984, v985, v986
					if v981 then
						local v987 = v981.restockAt
						v984 = tonumber(v987)
						if not v984 then
							v985 = v_u_170
							if type(v985) == "table" then
								v986 = v_u_170.restockAt
								v984 = tonumber(v986) or nil
							else
								v984 = nil
							end
						end
					else
						v985 = v_u_170
						if type(v985) == "table" then
							v986 = v_u_170.restockAt
							v984 = tonumber(v986) or nil
						else
							v984 = nil
						end
					end
					local v988
					if p_u_924.locked then
						v988 = ""
					else
						local v989 = p_u_924.limit
						if tonumber(v989) and p_u_924.limit > 0 then
							if v_u_104 then
								local v990 = p_u_924.left
								v988 = ("%d of %d left"):format(tonumber(v990) or 0, p_u_924.limit)
							elseif v984 then
								local v991 = p_u_924.left
								local v992 = tonumber(v991) or 0
								local v993 = p_u_924.limit
								local v994 = v_u_99.clock
								local v995 = v984 - os.time()
								v988 = ("%d of %d left  \194\183  restock in %s"):format(v992, v993, v994((math.max(0, v995))))
							else
								local v996 = p_u_924.left
								v988 = ("%d of %d left until restock"):format(tonumber(v996) or 0, p_u_924.limit)
							end
						else
							v988 = "No stock limit"
						end
					end
					v_u_99.label({
						["parent"] = nil,
						["name"] = "Stock",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v960,
						["text"] = v988,
						["color"] = v_u_101.text2,
						["position"] = UDim2.fromOffset(v959 + 12, 68),
						["size"] = UDim2.new(1, -v959 - 12, 0, 18)
					})
					local v997 = v_u_99.list
					local v998 = {
						["parent"] = nil,
						["name"] = "Info",
						["position"] = nil,
						["size"] = nil,
						["gap"] = 6,
						["parent"] = v955,
						["position"] = UDim2.fromOffset(0, v959 + 12)
					}
					local v999 = UDim2.new
					local v1000 = 1
					local v1001 = 0
					local v1002 = 1
					local v1003
					if v_u_104 then
						v1003 = -v959 - 12
					else
						v1003 = -v959 - 12 - v945 - 8
					end
					v998.size = v999(v1000, v1001, v1002, v1003)
					local v1004 = v997(v998)
					local v1005 = 0
					local v1006
					if p_u_924.locked then
						local v1007 = v_u_99.new
						local v1008 = {
							["Name"] = "LockBox",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.3,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["AutomaticSize"] = nil,
							["LayoutOrder"] = nil,
							["BackgroundColor3"] = v_u_101.dangerDeep,
							["Size"] = UDim2.new(1, -6, 0, 0),
							["AutomaticSize"] = Enum.AutomaticSize.Y
						}
						v1005 = v1005 + 1
						v1008.LayoutOrder = v1005
						local v1009 = v1007("Frame", v1008, v1004)
						v_u_99.stroke(v1009, v_u_101.danger, 1, 0.4)
						v_u_99.pad(v1009, {
							10,
							10,
							8,
							8
						})
						v_u_99.layout(v1009, "v", 4)
						v_u_99.label({
							["parent"] = nil,
							["text"] = "Locked",
							["style"] = "caps",
							["color"] = nil,
							["order"] = 1,
							["parent"] = v1009,
							["color"] = v_u_101.danger
						})
						v_u_99.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["track"] = false,
							["parent"] = v1009,
							["text"] = v_u_669(p_u_924, v_u_743),
							["color"] = v_u_101.text
						})
						v1006 = v1005
					else
						v1006 = v1005
					end
					if v934 and (v_u_169 and v_u_169.ammoSubtitle) then
						local v1010 = v_u_169.ammoSubtitle
						local v1011, v1012 = pcall(v1010, v_u_925)
						if v1011 and (type(v1012) == "string" and v1012 ~= "") then
							local v1013 = v_u_99.label
							local v1014 = {
								["parent"] = nil,
								["name"] = "Ammo",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["track"] = false,
								["parent"] = v1004,
								["text"] = v1012,
								["color"] = v_u_101.info
							}
							v1005 = v1006 + 1
							v1014.order = v1005
							v1013(v1014)
							v1006 = v1005
						end
					end
					if v934 then
						if v_u_927 then
							local v1015 = v_u_927.desc
							if type(v1015) == "string" and v_u_927.desc ~= "" then
								local v1016 = v_u_99.label
								local v1017 = {
									["parent"] = nil,
									["name"] = "Desc",
									["text"] = nil,
									["style"] = "small",
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["track"] = false,
									["parent"] = v1004,
									["text"] = v_u_927.desc
								}
								v1005 = v1006 + 1
								v1017.order = v1005
								v1016(v1017)
								v1006 = v1005
							end
						end
					else
						local v1018 = v_u_102.section
						v1005 = v1006 + 1
						v1018(v1004, "Contains", v1005)
						v1006 = v1005
						for _, v1019 in p_u_924.items do
							local v1020 = v_u_99.new
							local v1021 = {
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.new(1, -6, 0, 20)
							}
							v1005 = v1006 + 1
							v1021.LayoutOrder = v1005
							local v1022 = v1020("Frame", v1021, v1004)
							v_u_99.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["size"] = nil,
								["parent"] = v1022,
								["text"] = v_u_102.itemName(v1019.id),
								["color"] = v_u_101.text,
								["size"] = UDim2.new(1, -50, 1, 0)
							})
							local v1023 = v_u_99.label
							local v1024 = {
								["parent"] = nil,
								["text"] = nil,
								["style"] = "monoS",
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["parent"] = v1022
							}
							local v1025 = v1019.n or 1
							v1024.text = "x" .. tostring(v1025)
							v1024.position = UDim2.new(1, -50, 0, 0)
							v1024.size = UDim2.new(0, 50, 1, 0)
							v1023(v1024)
							v1006 = v1005
						end
					end
					if v934 and (v_u_169 and v_u_169.tooltip) then
						local v1026 = v_u_169.tooltip
						local v1027 = {
							["uid"] = "",
							["id"] = nil,
							["x"] = 0,
							["y"] = 0,
							["r"] = false,
							["n"] = nil,
							["id"] = v_u_925
						}
						local v1028 = p_u_924.n
						local v1029 = tonumber(v1028) or 1
						v1027.n = math.max(1, v1029)
						local v1030, v1031 = pcall(v1026, v1027)
						if v1030 and type(v1031) == "table" then
							local v1032 = v1031.lines
							if type(v1032) == "table" then
								local v1033 = v_u_102.section
								v1005 = v1006 + 1
								v1033(v1004, "Details", v1005)
								local v1034 = v1005
								for v1035, v1036 in v1031.lines do
									if v1035 <= 1 then
										continue
									end
									local v1037 = v_u_99.new
									local v1038 = {
										["BackgroundTransparency"] = 1,
										["Size"] = nil,
										["LayoutOrder"] = nil,
										["Size"] = UDim2.new(1, -6, 0, 20)
									}
									v1005 = v1034 + 1
									v1038.LayoutOrder = v1005
									local v1039 = v1037("Frame", v1038, v1004)
									local v1040 = v_u_99.label
									local v1041 = {
										["parent"] = nil,
										["text"] = nil,
										["style"] = "small",
										["size"] = nil,
										["parent"] = v1039
									}
									local v1042 = v1036[1] or (v1036.label or "")
									v1041.text = tostring(v1042)
									v1041.size = UDim2.new(0.55, 0, 1, 0)
									v1040(v1041)
									local v1043 = v_u_99.label
									local v1044 = {
										["parent"] = nil,
										["text"] = nil,
										["style"] = "monoS",
										["color"] = nil,
										["align"] = "right",
										["position"] = nil,
										["size"] = nil,
										["fit"] = true,
										["parent"] = v1039
									}
									local v1045 = v1036[2] or (v1036.value or "")
									v1044.text = tostring(v1045)
									v1044.color = v1036[3] or (v1036.color or v_u_101.text)
									v1044.position = UDim2.fromScale(0.55, 0)
									v1044.size = UDim2.new(0.45, 0, 1, 0)
									v1043(v1044)
									v1034 = v1005
								end
							end
						end
					end
					local v1046 = v_u_99.new
					local v1047 = "Frame"
					local v1048 = {
						["Name"] = "Foot",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil
					}
					local v1049
					if v957 then
						v1049 = Vector2.zero
					else
						v1049 = Vector2.new(0, 1)
					end
					v1048.AnchorPoint = v1049
					local v1050
					if v957 then
						v1050 = UDim2.new()
					else
						v1050 = UDim2.fromScale(0, 1)
					end
					v1048.Position = v1050
					local v1051
					if v957 then
						v1051 = UDim2.fromScale(1, 1)
					else
						v1051 = UDim2.new(1, 0, 0, v945)
					end
					v1048.Size = v1051
					local v1052 = v1046(v1047, v1048, v957 or v_u_921)
					if not v957 then
						v_u_99.divider({
							["parent"] = v1052,
							["size"] = UDim2.new(1, 0, 0, 1)
						})
					end
					local v_u_1053 = v_u_99.label({
						["parent"] = nil,
						["name"] = "PriceCaption",
						["text"] = "Price",
						["style"] = "caps",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v1052,
						["position"] = UDim2.fromOffset(0, 10),
						["size"] = UDim2.new(0.56, 0, 0, 26)
					})
					local v1054 = v_u_99.label
					local v1055 = {
						["parent"] = nil,
						["name"] = "Price",
						["text"] = nil,
						["style"] = "monoL",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v1052,
						["text"] = v_u_102.money(v_u_929)
					}
					local v1056
					if p_u_924.locked then
						v1056 = v_u_101.text2
					elseif v_u_929 <= v_u_931 then
						v1056 = v_u_101.accent
					else
						v1056 = v_u_101.danger
					end
					v1055.color = v1056
					v1055.position = UDim2.new(0.56, 0, 0, 10)
					v1055.size = UDim2.new(0.44, 0, 0, 26)
					local v_u_1057 = v1054(v1055)
					local v1058 = p_u_924.basePrice
					local v1059 = tonumber(v1058)
					local v1060 = p_u_924.price
					local v1061 = tonumber(v1060)
					if not v1059 or (not v1061 or v1061 >= v1059) then
						v1059 = nil
					end
					if v1059 then
						v_u_99.label({
							["parent"] = nil,
							["name"] = "DiscountNote",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v1052,
							["text"] = "Faction discount" .. v_u_3.discountEnds(v_u_743.discountUntil, os.time()),
							["color"] = v_u_101.info,
							["position"] = UDim2.fromOffset(0, 38),
							["size"] = UDim2.new(0.5, 0, 0, 18)
						})
						v_u_700(v1052, v1059, v_u_929, {
							["right"] = true,
							["position"] = nil,
							["size"] = nil,
							["pct"] = nil,
							["style"] = "mono",
							["position"] = UDim2.new(0.5, 0, 0, 38),
							["size"] = UDim2.new(0.5, 0, 0, 18),
							["pct"] = v_u_743.discount
						})
					end
					local v1062 = not p_u_924.locked
					if v1062 then
						local v1063 = p_u_924.left
						if tonumber(v1063) == nil then
							v1062 = false
						else
							local v1064 = p_u_924.left
							v1062 = (tonumber(v1064) or 0) <= 0
						end
					end
					local v_u_1065 = not p_u_924.locked
					if v_u_1065 then
						if v_u_929 <= v_u_931 then
							v_u_1065 = not v1062
							if v_u_1065 then
								v_u_1065 = not v938
							end
						else
							v_u_1065 = false
						end
					end
					if v938 then
						v_u_99.label({
							["parent"] = nil,
							["name"] = "StashFullNote",
							["text"] = "Make room in your stash first.",
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v1052,
							["color"] = v_u_101.danger,
							["position"] = UDim2.fromOffset(0, v1059 and 58 or 38),
							["size"] = UDim2.new(1, 0, 0, 18)
						})
					end
					if not v938 and (not p_u_924.locked and (not v1062 and v_u_931 < v_u_929)) then
						v_u_99.label({
							["parent"] = nil,
							["name"] = "ShortNote",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v1052,
							["text"] = v_u_3.shortText(v_u_929, v_u_931),
							["color"] = v_u_101.danger,
							["position"] = UDim2.fromOffset(0, v1059 and 58 or 38),
							["size"] = UDim2.new(1, 0, 0, 18)
						})
					end
					local v1066
					if p_u_924.locked == nil then
						v1066 = false
					else
						local v1067 = p_u_924.lvl
						if (tonumber(v1067) or 0) >= 5 then
							local v1068 = string.find
							local v1069 = p_u_924.locked
							if v1068(tostring(v1069), "Task:", 1, true) == nil then
								local v1070 = v_u_170
								if type(v1070) == "table" and v_u_170.partners ~= nil then
									v1066 = v_u_170.partners == true
								else
									local function v1071()
										-- upvalues: (ref) p_u_97
										return p_u_97.cctx.config.flag("Partners")
									end
									local v1072
									v1066, v1072 = pcall(v1071)
									if v1066 then
										v1066 = v1072 == true
									end
								end
							else
								v1066 = false
							end
						else
							v1066 = false
						end
					end
					local v1073
					if p_u_924.locked == nil then
						v1073 = false
					else
						local v1074 = p_u_924.task
						if type(v1074) == "string" then
							local v1075 = string.find
							local v1076 = p_u_924.locked
							v1073 = v1075(tostring(v1076), "Task:", 1, true) ~= nil
						else
							v1073 = false
						end
					end
					local v_u_1077
					if v1073 then
						v_u_1077 = v_u_99.button({
							["parent"] = nil,
							["name"] = "ViewTask",
							["text"] = "View task",
							["kind"] = "secondary",
							["icon"] = "task",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v1052,
							["size"] = UDim2.new(1, 0, 0, v_u_100.touch(44)),
							["position"] = UDim2.fromScale(0, 1),
							["anchor"] = Vector2.new(0, 1),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) p_u_97, (copy) p_u_924
								p_u_97.openTask(p_u_924.task)
							end
						})
					elseif v1066 then
						v_u_1077 = v_u_99.button({
							["parent"] = nil,
							["name"] = "OpenPartner",
							["text"] = "Open PARTNER tab",
							["kind"] = "secondary",
							["icon"] = "trade",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v1052,
							["size"] = UDim2.new(1, 0, 0, v_u_100.touch(44)),
							["position"] = UDim2.fromScale(0, 1),
							["anchor"] = Vector2.new(0, 1),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_105
								v_u_105.showSub("partner")
							end
						})
					else
						local v1078
						if v_u_672.buy == nil or v_u_672.buy.key ~= p_u_924.key then
							v1078 = false
						else
							v1078 = os.clock() - v_u_672.buy.t < 4
						end
						local v1079 = v1078 and "Buying..." or (p_u_924.locked and "Locked" or (v1062 and "Sold out" or (v938 and "Stash is full" or (v_u_931 < v_u_929 and "Not enough cash" or "Buy"))))
						v_u_1077 = v_u_99.button({
							["parent"] = nil,
							["name"] = "BuyButton",
							["text"] = nil,
							["kind"] = nil,
							["disabled"] = nil,
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v1052,
							["text"] = v1079,
							["kind"] = v_u_1065 and "primary" or "secondary",
							["disabled"] = not v_u_1065 or v1078,
							["size"] = UDim2.new(1, 0, 0, v_u_100.touch(44)),
							["position"] = UDim2.fromScale(0, 1),
							["anchor"] = Vector2.new(0, 1),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_105, (copy) p_u_924, (ref) v_u_135
								v_u_105.buyNow(p_u_924, v_u_135)
							end
						})
					end
					v_u_127 = v_u_1077
					if v939 and v_u_1077 then
						local v_u_1080 = v_u_99.new("Frame", {
							["Name"] = "Qty",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(0, 1),
							["Position"] = UDim2.new(0, 0, 1, -(v_u_100.touch(44) + 8)),
							["Size"] = UDim2.new(1, 0, 0, v940)
						}, v1052)
						local v1081 = v940 * 2 + 44 + 76 + 18
						local v1082 = v_u_99.label
						local v1083 = {
							["parent"] = nil,
							["name"] = "Caption",
							["text"] = nil,
							["style"] = "caps",
							["color"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v_u_1080
						}
						local v1084 = v_u_99.device()
						v1083.text = v1084 == "Gamepad" and "Amount  \194\183  D-pad" or (v1084 == "Touch" and "Amount" or "Amount  \194\183  wheel")
						v1083.color = v_u_101.text2
						v1083.size = UDim2.new(1, -v1081 - 6, 1, 0)
						local v1085 = v1082(v1083)
						v1085:SetAttribute("Device", v_u_99.device())
						v1085.Visible = not v_u_104 or v956 - v1081 - 6 >= 60
						local v_u_1086, v_u_1087 = v_u_99.iconButton({
							["parent"] = nil,
							["name"] = "QtyMinus",
							["icon"] = "minus",
							["kind"] = "secondary",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v_u_1080,
							["size"] = v940,
							["position"] = UDim2.new(1, -v1081, 0.5, 0),
							["anchor"] = Vector2.new(0, 0.5),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_137, (ref) v_u_135
								if v_u_137 then
									v_u_137(v_u_135 - 1)
								end
							end
						})
						local v1088 = v_u_99.label
						local v1089 = {
							["parent"] = nil,
							["name"] = "Amount",
							["text"] = nil,
							["style"] = "monoL",
							["color"] = nil,
							["align"] = "center",
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["parent"] = v_u_1080
						}
						local v1090 = v_u_135
						v1089.text = tostring(v1090)
						v1089.color = v_u_101.text
						v1089.position = UDim2.new(1, -v1081 + v940 + 6, 0, 0)
						v1089.size = UDim2.new(0, 44, 1, 0)
						local v_u_1091 = v1088(v1089)
						local v1092, v_u_1093 = v_u_99.iconButton({
							["parent"] = nil,
							["name"] = "QtyPlus",
							["icon"] = "plus",
							["kind"] = "secondary",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v_u_1080,
							["size"] = v940,
							["position"] = UDim2.new(1, -v1081 + v940 + 44 + 12, 0.5, 0),
							["anchor"] = Vector2.new(0, 0.5),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_137, (ref) v_u_135
								if v_u_137 then
									v_u_137(v_u_135 + 1)
								end
							end
						})
						local _, v_u_1094 = v_u_99.button({
							["parent"] = nil,
							["name"] = "QtyMax",
							["text"] = "Max",
							["kind"] = "ghost",
							["width"] = 76,
							["height"] = nil,
							["maxTextWidth"] = 52,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v_u_1080,
							["height"] = v940,
							["position"] = UDim2.new(1, 0, 0.5, 0),
							["anchor"] = Vector2.new(1, 0.5),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_137, (ref) v_u_136
								if v_u_137 then
									v_u_137(v_u_136)
								end
							end
						})
						local v_u_1095 = {}
						local function v1104(p_u_1096, p1097) -- name: sign
							-- upvalues: (ref) v_u_99, (ref) v_u_101, (copy) v_u_1095
							for _, v1098 in p_u_1096:GetDescendants() do
								if not (v1098:IsA("GuiObject") and v1098:GetAttribute("HushIcon")) then
									continue
								end
								v1098.Visible = false
							end
							local function v1103(p1099, p1100) -- name: barF
								-- upvalues: (ref) v_u_99, (ref) v_u_101, (copy) p_u_1096, (ref) v_u_1095
								local v1101 = v_u_99.new("Frame", {
									["Name"] = "Sign",
									["BackgroundColor3"] = nil,
									["BorderSizePixel"] = 0,
									["AnchorPoint"] = nil,
									["Position"] = nil,
									["Size"] = nil,
									["ZIndex"] = nil,
									["BackgroundColor3"] = v_u_101.text,
									["AnchorPoint"] = Vector2.new(0.5, 0.5),
									["Position"] = UDim2.fromScale(0.5, 0.5),
									["Size"] = UDim2.fromOffset(p1099, p1100),
									["ZIndex"] = p_u_1096.ZIndex + 2
								}, p_u_1096)
								local v1102 = v_u_1095
								table.insert(v1102, v1101)
							end
							v1103(14, 3)
							if p1097 then
								v1103(3, 14)
							end
						end
						v1104(v_u_1086, false)
						v1104(v1092, true)
						v_u_1077.NextSelectionLeft = v_u_1077
						v_u_1077.NextSelectionRight = v_u_1077
						local function v_u_1124(p1105) -- name: apply
							-- upvalues: (ref) v_u_136, (ref) v_u_135, (copy) v_u_1091, (copy) v_u_929, (copy) v_u_1053, (copy) v_u_1095, (copy) v_u_1086, (ref) v_u_101, (copy) v_u_1057, (ref) v_u_102, (copy) v_u_931, (copy) v_u_1087, (copy) v_u_1093, (copy) v_u_1094, (ref) v_u_1077, (ref) v_u_672, (copy) p_u_924, (copy) v_u_1065, (ref) v_u_100, (ref) v_u_99, (copy) v_u_1080
							local v1106 = math.floor(p1105)
							local v1107 = v_u_136
							local v1108 = math.clamp(v1106, 1, v1107)
							local v1109 = v1108 ~= v_u_135
							v_u_135 = v1108
							v_u_1091.Text = tostring(v1108)
							local v1110 = v_u_929 * v1108
							v_u_1053.Text = v1108 > 1 and "Total" or "Price"
							for _, v1111 in v_u_1095 do
								local v1112
								if v1111.Parent == v_u_1086 then
									v1112 = v1108 > 1
								else
									v1112 = v1108 < v_u_136
								end
								local v1113
								if v1112 then
									v1113 = v_u_101.text
								else
									v1113 = v_u_101.muted
								end
								v1111.BackgroundColor3 = v1113
							end
							v_u_1057.Text = v_u_102.money(v1110)
							local v1114 = v_u_1057
							local v1115
							if v1110 <= v_u_931 then
								v1115 = v_u_101.accent
							else
								v1115 = v_u_101.danger
							end
							v1114.TextColor3 = v1115
							local v1116 = v_u_1087.setEnabled
							local v1117 = v1108 > 1
							pcall(v1116, v1117)
							local v1118 = v_u_1093.setEnabled
							local v1119 = v1108 < v_u_136
							pcall(v1118, v1119)
							local v1120 = v_u_1094.setEnabled
							local v1121 = v1108 < v_u_136
							pcall(v1120, v1121)
							local v1122 = v_u_1077:FindFirstChild("Text", true)
							local v1123
							if v_u_672.buy == nil or v_u_672.buy.key ~= p_u_924.key then
								v1123 = false
							else
								v1123 = os.clock() - v_u_672.buy.t < 4
							end
							if v1122 and (v1122:IsA("TextLabel") and (v_u_1065 and not v1123)) then
								v1122.Text = v_u_100.track(string.upper(v1108 <= 1 and "Buy" or ("Buy %d"):format(v1108)), 1)
							end
							if v1109 then
								v_u_99.sound(v_u_100.sounds.hover)
							end
							v_u_1080:SetAttribute("Qty", v1108)
							v_u_1080:SetAttribute("QtyMax", v_u_136)
						end
						v_u_137 = v_u_1124
						v_u_1124(v_u_135)
						v_u_1080.InputChanged:Connect(function(p1125)
							-- upvalues: (ref) v_u_137, (copy) v_u_1124, (ref) v_u_135
							if p1125.UserInputType == Enum.UserInputType.MouseWheel and v_u_137 == v_u_1124 then
								v_u_1124(v_u_135 + (p1125.Position.Z > 0 and 1 or -1))
							end
						end)
					end
				end
				local v1126 = v_u_671
				local v1127
				if v_u_1967 then
					v1127 = v840[v_u_1967]
				else
					v1127 = nil
				end
				v1126(v1127)
				if v_u_104 then
					local v1128 = v_u_1986
					if v1128 then
						if v_u_1967 == nil then
							v1128 = false
						else
							v1128 = v840[v_u_1967] ~= nil
						end
					end
					v_u_838(v1128)
				end
				if v_u_102.markOffersSeen and v759.cat == "all" then
					local v1129 = v_u_102.markOffersSeen
					local v1130 = v_u_1964
					pcall(v1129, v1130)
				end
				return
			end
		end
		local v1131 = {
			["parent"] = nil,
			["gap"] = 4,
			["parent"] = v_u_386
		}
		v_u_742(v_u_99.list(v1131), "Loading offers...")
	end
	local function v_u_1178(p1133) -- name: repPreview
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (ref) v_u_171, (copy) v_u_166, (copy) p_u_97
		local v1134
		if v_u_115 and v_u_1964 == "gunsmith" then
			v1134 = v_u_115.traderView()
		else
			local v1135 = v_u_170
			if type(v1135) == "table" then
				local v1136 = v_u_170.traders
				v1134 = type(v1136) == "table" and v_u_170.traders[v_u_1964] or nil
			else
				v1134 = nil
			end
		end
		if v1134 and v_u_171 then
			local v1137 = v_u_171.REP_PER_DOLLAR
			if tonumber(v1137) then
				local v1138 = v_u_166(v_u_1964).name
				local v1139 = v1134.rep
				local v1140 = tonumber(v1139) or 0
				local v1141 = v1134.tradeRep
				local v1142 = tonumber(v1141) or 0
				local v1143 = v1134.tradeMax
				local v1144 = tonumber(v1143)
				if not v1144 then
					local v1145 = v_u_171.REP_TRADE_MAX
					v1144 = tonumber(v1145) or 0.3
				end
				local v1146 = v_u_171.REP_MAX
				local v1147 = tonumber(v1146) or (1 / 0)
				local v1148 = math.max(0, p1133) * v_u_171.REP_PER_DOLLAR
				local v1149 = v1144 - v1142
				local v1150 = v1147 - v1140
				local v1151 = math.min(v1148, v1149, v1150)
				local v1152 = math.max(0, v1151)
				if v1144 - 1e-6 <= v1142 then
					local v1153 = {
						["gain"] = 0,
						["short"] = "trade rep maxed",
						["long"] = nil
					}
					local v1154 = v1144 * 100 + 0.0001
					local v1155 = math.floor(v1154)
					local v1156 = v1144 * 100 + 0.0001
					v1153.long = ("Trade rep with %s is maxed (%d / %d): no rep from this sale."):format(v1138, v1155, (math.floor(v1156)))
					return v1153
				end
				local v1157
				if v1152 * 100 < 0.05 then
					v1157 = "+<0.1 REP"
				elseif v_u_171.gainText then
					v1157 = v_u_171.gainText(v1152)
				else
					local v1158 = v1152 * 100 + 0.0001
					v1157 = ("+%d REP"):format((math.floor(v1158)))
				end
				local v1159 = v1142 * 100 + 0.0001
				local v1160 = math.floor(v1159)
				local v1161 = (v1142 + v1152) * 100 + 0.0001
				local v1162 = math.floor(v1161)
				local v1163 = v1144 * 100 + 0.0001
				local v1164 = ("%s with %s (trade rep %d -> %d / %d)"):format(v1157, v1138, v1160, v1162, (math.floor(v1163)))
				local v1165 = v1134.next
				local v1166
				if type(v1165) == "table" then
					v1166 = v1134.next or nil
				else
					v1166 = nil
				end
				if v1166 then
					local v1167 = v1166.rep
					if tonumber(v1167) and (v1140 + v1152 + 1e-6 >= v1166.rep and v1140 + 1e-6 < v1166.rep) then
						local v1168 = p_u_97.profile
						local v1169
						if type(v1168) == "table" then
							local v1170 = p_u_97.profile.stats
							v1169 = type(v1170) == "table" and (p_u_97.profile.stats or {}) or {}
						else
							v1169 = {}
						end
						local v1171 = v1169.extracts
						local v1172 = tonumber(v1171) or 0
						local v1173 = v1166.extracts
						if (tonumber(v1173) or 0) <= v1172 then
							local v1174 = ", so %s reaches LV %d"
							local v1175 = v1166.lvl
							local v1176 = tonumber(v1175)
							if not v1176 then
								local v1177 = v1134.lvl
								v1176 = (tonumber(v1177) or 1) + 1
							end
							v1164 = v1164 .. v1174:format(v1138, v1176)
						end
					end
				end
				return {
					["gain"] = v1152,
					["short"] = v1157,
					["long"] = v1164 .. "."
				}
			end
		end
		return nil
	end
	v_u_105.repPreview = v_u_1178
	local function v_u_1372() -- name: drawSell
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (copy) p_u_97, (copy) v_u_104, (ref) v_u_331, (copy) v_u_102, (copy) v_u_99, (copy) v_u_386, (copy) v_u_742, (copy) v_u_431, (copy) v_u_100, (copy) v_u_162, (copy) v_u_103, (ref) v_u_360, (copy) v_u_672, (ref) v_u_1965, (copy) v_u_131, (ref) v_u_1993, (ref) v_u_8, (copy) v_u_500, (copy) v_u_105, (copy) v_u_1178, (ref) v_u_169, (copy) v_u_101, (copy) v_u_607, (ref) v_u_160, (copy) v_u_454, (copy) v_u_484, (copy) v_u_166, (copy) v_u_132
		local v_u_1179
		if v_u_115 and v_u_1964 == "gunsmith" then
			v_u_1179 = v_u_115.traderView()
		else
			local v1180 = v_u_170
			if type(v1180) == "table" then
				local v1181 = v_u_170.traders
				v_u_1179 = type(v1181) == "table" and v_u_170.traders[v_u_1964] or nil
			else
				v_u_1179 = nil
			end
		end
		local v1182 = p_u_97.profile
		local v1183
		if type(v1182) == "table" then
			local v1184 = v1182.inv
			if type(v1184) == "table" then
				local v1185 = v1182.inv.containers
				if type(v1185) == "table" then
					v1183 = v1182.inv.containers.stash or nil
				else
					v1183 = nil
				end
			else
				v1183 = nil
			end
		else
			v1183 = nil
		end
		local v1186 = v_u_170
		local v1187
		if type(v1186) == "table" then
			local v1188 = v_u_170.quotes
			v1187 = type(v1188) == "table" and (v_u_170.quotes or {}) or {}
		else
			v1187 = {}
		end
		local v1189 = v_u_170
		if type(v1189) == "table" then
			local v1190 = v_u_170.quotes
			if type(v1190) == "table" then
				local v1191 = v_u_431(v_u_386)
				if not v1191 or v1191 < 200 then
					v1191 = v_u_100.safeRefSize().X - 48 - v_u_162 - 1 - 36
				end
				local v1192 = v_u_103 and 260 or 320
				if v1191 < 820 then
					local v1193 = v1191 * 0.32
					local v1194 = math.floor(v1193)
					v1192 = math.max(240, v1194)
				end
				if v_u_104 then
					v1192 = -14
					if v_u_331 then
						v_u_102.clear(v_u_331)
					end
					if v_u_104 then
						local v1195 = v_u_331
						if v1195 then
							v1195.Visible = true
							v1195.Size = UDim2.new(0, 270, 0, v_u_100.touch(40))
						end
						v_u_360.Size = UDim2.new(1, -278, 0, v_u_100.touch(40))
					end
				end
				local v1196 = v_u_104 and 52 or (v_u_103 and 64 or 76)
				local v1197 = v1196 + (v_u_104 and 62 or 66)
				local v1198
				if type(v1183) == "table" then
					local v1199 = v1183.items
					v1198 = type(v1199) ~= "table" and {} or v1183.items
				else
					v1198 = {}
				end
				local v_u_1200 = {}
				local v_u_1201 = 0
				for _, v1202 in v1198 do
					if type(v1202) ~= "table" or (not v1202.uid or v_u_672.sold[v1202.uid] and os.clock() - v_u_672.sold[v1202.uid] < 5) then
						continue
					end
					local v1203 = v1187[v1202.uid]
					local v1204
					if type(v1203) == "table" then
						local v1205 = v1203.prices
						if type(v1205) == "table" then
							local v1206 = v1203.prices[v_u_1964]
							v1204 = tonumber(v1206) or nil
						else
							v1204 = nil
						end
					else
						v1204 = nil
					end
					local v1207
					if type(v1203) == "table" then
						v1207 = v1203.best or nil
					else
						v1207 = nil
					end
					local v1208
					if v1207 then
						local v1209 = v1203.prices
						if type(v1209) == "table" then
							local v1210 = v1203.prices[v1207]
							v1208 = tonumber(v1210)
						else
							v1208 = nil
						end
					else
						v1208 = nil
					end
					local v1211 = {
						["it"] = v1202,
						["price"] = v1204,
						["best"] = v1207,
						["bestPrice"] = v1208
					}
					local v1212
					if type(v1203) == "table" then
						local v1213 = v1203.why
						if type(v1213) == "string" then
							v1212 = v1203.why or nil
						else
							v1212 = nil
						end
					else
						v1212 = nil
					end
					v1211.why = v1212
					local v1214
					if type(v1203) == "table" then
						local v1215 = v1203.whyShort
						if type(v1215) == "string" then
							v1214 = v1203.whyShort or nil
						else
							v1214 = nil
						end
					else
						v1214 = nil
					end
					v1211.whyShort = v1214
					table.insert(v_u_1200, v1211)
					if v1204 then
						v_u_1201 = v_u_1201 + 1
					else
						v_u_1965[v1202.uid] = nil
					end
				end
				table.sort(v_u_1200, function(p1216, p1217)
					if p1216.price ~= nil ~= (p1217.price ~= nil) then
						return p1216.price ~= nil
					end
					if (p1216.price or 0) ~= (p1217.price or 0) then
						return (p1216.price or 0) > (p1217.price or 0)
					end
					local v1218 = p1216.it.uid
					local v1219 = tostring(v1218)
					local v1220 = p1217.it.uid
					return v1219 < tostring(v1220)
				end)
				local v1221 = {}
				for _, v1222 in v_u_1200 do
					v1221[v1222.it.uid] = true
				end
				for v1223 in table.clone(v_u_1965) do
					if v1221[v1223] then
						continue
					end
					v_u_1965[v1223] = nil
				end
				local v_u_1224 = {}
				table.clear(v_u_131)
				local v_u_1225 = nil
				local v_u_1226 = nil
				local v1227 = v_u_1964 .. "/" .. v_u_1993
				local v1228 = v_u_8[v1227]
				if not v1228 then
					v1228 = {
						["cat"] = "all",
						["cal"] = nil
					}
					v_u_8[v1227] = v1228
				end
				local v1229 = {}
				local v_u_1230 = {}
				local v_u_1231 = 0
				for _, v1232 in v_u_1200 do
					local v1233 = v_u_500({ v1232.it.id })
					table.insert(v1229, v1233)
					local v1234
					if v1228.cat == "all" or v1233.cats[v1228.cat] then
						v1234 = (v1228.cat ~= "ammo" or (not v1228.cal or v1233.cals[v1228.cal])) and true or false
					else
						v1234 = false
					end
					if not v1234 then
						continue
					end
					table.insert(v_u_1230, v1232)
					if not v1232.price then
						continue
					end
					v_u_1231 = v_u_1231 + 1
				end
				local v_u_1235 = nil
				local v_u_1236 = nil
				if v_u_104 then
					local v1237
					v1237, v_u_1236 = v_u_99.button({
						["parent"] = nil,
						["name"] = "SellButton",
						["text"] = "Sell",
						["kind"] = "primary",
						["disabled"] = true,
						["size"] = nil,
						["maxTextWidth"] = 230,
						["onClick"] = nil,
						["parent"] = v_u_331,
						["size"] = UDim2.fromScale(1, 1),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_105
							v_u_105.confirmSell()
						end
					})
				else
					v_u_1235 = v_u_99.new("Frame", {
						["Name"] = "CounterBox",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = UDim2.fromScale(1, 0),
						["Size"] = UDim2.new(0, v1192, 1, 0)
					}, v_u_386)
				end
				local function v_u_1250(p_u_1238, p_u_1239) -- name: paintCounter
					-- upvalues: (ref) v_u_104, (ref) v_u_1236, (ref) v_u_102, (ref) v_u_99, (ref) v_u_1235, (ref) v_u_1178, (ref) v_u_103, (copy) v_u_1200, (ref) v_u_1965, (ref) v_u_169, (ref) v_u_101, (ref) v_u_100, (ref) v_u_105, (copy) v_u_1179
					if v_u_104 then
						if v_u_1236 then
							v_u_1236.setText(p_u_1238 <= 0 and "Sell" or ("Sell %d  \194\183  %s"):format(p_u_1238, v_u_102.money(p_u_1239)))
							v_u_1236.setEnabled(p_u_1238 > 0)
						end
					else
						v_u_99.keepScroll(v_u_1235, function()
							-- upvalues: (ref) v_u_102, (ref) v_u_1235, (copy) p_u_1238, (ref) v_u_1178, (copy) p_u_1239, (ref) v_u_99, (ref) v_u_103, (ref) v_u_1200, (ref) v_u_1965, (ref) v_u_169, (ref) v_u_101, (ref) v_u_100, (ref) v_u_105, (ref) v_u_1179
							v_u_102.clear(v_u_1235)
							local v1240
							if p_u_1238 > 0 then
								v1240 = v_u_1178(p_u_1239)
							else
								v1240 = nil
							end
							local _, v1241 = v_u_99.panel({
								["parent"] = nil,
								["name"] = "Counter",
								["raised"] = true,
								["size"] = nil,
								["title"] = "Counter",
								["subtitle"] = nil,
								["padding"] = 12,
								["parent"] = v_u_1235,
								["size"] = UDim2.fromScale(1, 1),
								["subtitle"] = p_u_1238 <= 0 and "Nothing selected" or ("%d selected"):format(p_u_1238) .. (not v1240 and "" or "  \194\183  " .. v1240.short)
							})
							local v1242 = v_u_103 and 92 or 100
							local v1243 = v_u_99.list({
								["parent"] = nil,
								["size"] = nil,
								["gap"] = 2,
								["parent"] = v1241,
								["size"] = UDim2.new(1, 0, 1, -v1242 - 6)
							})
							for v1244, v1245 in v_u_1200 do
								if not (v_u_1965[v1245.it.uid] and v1245.price) then
									continue
								end
								local v1246 = v_u_99.new("Frame", {
									["BackgroundTransparency"] = 1,
									["Size"] = nil,
									["LayoutOrder"] = nil,
									["Size"] = UDim2.new(1, -6, 0, 22),
									["LayoutOrder"] = v1244
								}, v1243)
								local v1247 = v1245.it.mods
								local v1248 = type(v1247) == "table" and (v_u_169 and v_u_169.modList) and #v_u_169.modList(v1245.it.mods) or 0
								v_u_99.label({
									["parent"] = nil,
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["size"] = nil,
									["fit"] = true,
									["parent"] = v1246,
									["text"] = v_u_102.itemName(v1245.it.id) .. ((v1245.it.n or 1) <= 1 and "" or " x" .. v1245.it.n) .. (v1248 <= 0 and "" or ("  +%d att."):format(v1248)),
									["color"] = v_u_101.text,
									["size"] = UDim2.new(0.64, 0, 1, 0)
								})
								v_u_99.label({
									["parent"] = nil,
									["text"] = nil,
									["style"] = "monoS",
									["align"] = "right",
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["parent"] = v1246,
									["text"] = v_u_102.money(v1245.price),
									["position"] = UDim2.fromScale(0.64, 0),
									["size"] = UDim2.new(0.36, 0, 1, 0)
								})
							end
							if p_u_1238 == 0 then
								v_u_102.empty(v1243, "Tap items on the left to put them on the counter.")
							end
							local v1249 = v_u_99.new("Frame", {
								["BackgroundTransparency"] = 1,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["AnchorPoint"] = Vector2.new(0, 1),
								["Position"] = UDim2.fromScale(0, 1),
								["Size"] = UDim2.new(1, 0, 0, v1242)
							}, v1241)
							v_u_99.label({
								["parent"] = nil,
								["text"] = "Total",
								["style"] = "caps",
								["size"] = nil,
								["parent"] = v1249,
								["size"] = UDim2.new(0.4, 0, 0, 26)
							})
							v_u_99.label({
								["parent"] = nil,
								["name"] = "Total",
								["text"] = nil,
								["style"] = "monoL",
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["parent"] = v1249,
								["text"] = v_u_102.money(p_u_1239),
								["color"] = v_u_101.accent,
								["position"] = UDim2.fromScale(0.4, 0),
								["size"] = UDim2.new(0.6, 0, 0, 26)
							})
							v_u_99.button({
								["parent"] = nil,
								["name"] = "SellButton",
								["text"] = nil,
								["kind"] = "primary",
								["disabled"] = nil,
								["size"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["onClick"] = nil,
								["parent"] = v1249,
								["text"] = p_u_1238 <= 0 and "Sell" or (p_u_1238 == 1 and "Sell 1 item" or ("Sell %d items"):format(p_u_1238)),
								["disabled"] = p_u_1238 == 0,
								["size"] = UDim2.new(1, 0, 0, v_u_100.touch(44)),
								["position"] = UDim2.fromScale(0, 1),
								["anchor"] = Vector2.new(0, 1),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_105
									v_u_105.confirmSell()
								end
							})
							if not v_u_1179 then
								v_u_102.empty(v1241, "Loading prices...")
							end
						end)
					end
				end
				local function v_u_1257() -- name: paintSell
					-- upvalues: (copy) v_u_1200, (ref) v_u_1965, (copy) v_u_1224, (ref) v_u_1225, (copy) v_u_1230, (ref) v_u_1231, (ref) v_u_1226, (copy) v_u_1250, (ref) v_u_105, (ref) v_u_1201
					local v1251 = 0
					local v1252 = 0
					for _, v1253 in v_u_1200 do
						if not (v_u_1965[v1253.it.uid] and v1253.price) then
							continue
						end
						v1251 = v1251 + v1253.price
						v1252 = v1252 + 1
					end
					for _, v1254 in v_u_1224 do
						v1254()
					end
					if v_u_1225 then
						local v1255 = 0
						for _, v1256 in v_u_1230 do
							if not (v_u_1965[v1256.it.uid] and v1256.price) then
								continue
							end
							v1255 = v1255 + 1
						end
						v_u_1225.setEnabled(v_u_1231 ~= 0 and v1255 ~= v_u_1231)
					end
					if v_u_1226 then
						v_u_1226.setEnabled(v1252 > 0)
					end
					v_u_1250(v1252, v1251)
					v_u_105.sellSummary = {
						["n"] = v1252,
						["total"] = v1251,
						["sellable"] = v_u_1201,
						["rows"] = #v_u_1200
					}
				end
				local v1258 = v_u_99.new("Frame", {
					["Name"] = "SellList",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, -v1192 - 14, 1, 0)
				}, v_u_386)
				local v1259 = v_u_104 and 0 or v_u_100.touch(36)
				local function v_u_1261() -- name: selectAll
					-- upvalues: (copy) v_u_1230, (ref) v_u_1965, (copy) v_u_1257
					for _, v1260 in v_u_1230 do
						if not v1260.price then
							continue
						end
						v_u_1965[v1260.it.uid] = true
					end
					v_u_1257()
				end
				local function v_u_1262() -- name: clearAll
					-- upvalues: (ref) v_u_1965, (copy) v_u_1257
					table.clear(v_u_1965)
					v_u_1257()
				end
				local v1263
				if v_u_104 then
					v1263 = v_u_607(v1258, 0, v1229, function(p1264)
						-- upvalues: (ref) v_u_99, (copy) v_u_1261, (ref) v_u_1225, (copy) v_u_1262, (ref) v_u_1226
						local v1265 = {
							["parent"] = nil,
							["name"] = "SelectAll",
							["text"] = "Select all",
							["kind"] = "ghost",
							["height"] = 32,
							["onClick"] = nil,
							["parent"] = p1264,
							["onClick"] = v_u_1261
						}
						local v1266, v1267 = v_u_99.button(v1265)
						v1266.LayoutOrder = -2
						v_u_1225 = v1267
						local v1268 = {
							["parent"] = nil,
							["name"] = "Clear",
							["text"] = "Clear",
							["kind"] = "ghost",
							["height"] = 32,
							["onClick"] = nil,
							["parent"] = p1264,
							["onClick"] = v_u_1262
						}
						local v1269, v1270 = v_u_99.button(v1268)
						v1269.LayoutOrder = -1
						v_u_1226 = v1270
					end)
				else
					local v1271 = v_u_99.new("Frame", {
						["Name"] = "Toolbar",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v1259)
					}, v1258)
					local v1272 = v_u_99.label({
						["parent"] = nil,
						["name"] = "Count",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["size"] = nil,
						["fit"] = true,
						["parent"] = v1271,
						["text"] = ("%d of %d sell here  \194\183  stash only"):format(v_u_1231, #v_u_1230),
						["color"] = v_u_101.text2,
						["size"] = UDim2.new(1, -250, 1, 0)
					})
					v_u_99.tooltip(v1272, function()
						return {
							["title"] = "STASH ONLY",
							["body"] = "Only items in your stash are offered. What you wear, carry and keep in your secure container is never sold. Move an item to the stash to sell it."
						}
					end)
					local v1273 = v_u_103 and 104 or 118
					local v1274, v1275 = v_u_99.button({
						["parent"] = nil,
						["name"] = "SelectAll",
						["text"] = "Select all",
						["kind"] = "ghost",
						["height"] = 36,
						["width"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["onClick"] = nil,
						["parent"] = v1271,
						["width"] = v1273,
						["position"] = UDim2.new(1, -v1273 - 8, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5),
						["onClick"] = v_u_1261
					})
					v_u_160 = v1274
					local _ = v1275
					local v1276, v1277 = v_u_99.button({
						["parent"] = nil,
						["name"] = "Clear",
						["text"] = "Clear",
						["kind"] = "ghost",
						["height"] = 36,
						["width"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["onClick"] = nil,
						["parent"] = v1271,
						["width"] = v1273 - 20,
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5),
						["onClick"] = v_u_1262
					})
					v_u_160 = v1276
					local _ = v1277
					v1263 = v_u_607(v1258, v1259 + 4, v1229)
				end
				local v1278 = (v_u_104 and 0 or v1259 + 4) + v1263 + 4
				local v_u_1279 = v_u_454(v1258, "Rows", UDim2.fromOffset(0, v1278), UDim2.new(1, 0, 1, -v1278), v_u_103 and 124 or 138, v1197, 8, v1191 - v1192 - 14)
				v_u_1279:SetAttribute("Shown", #v_u_1230)
				local v_u_1280
				if game:GetService("RunService"):IsStudio() then
					v_u_1280 = p_u_97.cctx
					if v_u_1280 then
						v_u_1280 = p_u_97.cctx.player
					end
					if v_u_1280 then
						v_u_1280 = v_u_1280:GetAttribute("DevSellModels")
					end
					if type(v_u_1280) ~= "string" then
						v_u_1280 = nil
					end
				else
					v_u_1280 = nil
				end
				local v_u_1281 = {}
				for v1282, v_u_1283 in v_u_1230 do
					local v_u_1284 = v_u_1283.it
					local v_u_1285 = v_u_1283.price ~= nil
					local v1286 = v_u_1284.uid
					local v1287 = "Row_" .. tostring(v1286)
					local v_u_1288 = v_u_99.new("TextButton", {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["LayoutOrder"] = nil,
						["Selectable"] = nil,
						["ClipsDescendants"] = true,
						["Name"] = v1287,
						["BackgroundColor3"] = v_u_101.raised,
						["LayoutOrder"] = v1282,
						["Selectable"] = v_u_1285
					}, v_u_1279)
					v_u_1288.SelectionImageObject = v_u_99.selectionImage()
					local v_u_1289 = v_u_99.stroke(v_u_1288, v_u_101.line)
					local v_u_1290 = v_u_99.new("Frame", {
						["Name"] = "Tick",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 5,
						["BackgroundColor3"] = v_u_101.bgDeep,
						["BackgroundTransparency"] = v_u_1285 and 0 or 0.6,
						["Position"] = UDim2.fromOffset(8, 8),
						["Size"] = UDim2.fromOffset(20, 20)
					}, v_u_1288)
					local v1291 = v_u_99.stroke
					local v1292
					if v_u_1285 then
						v1292 = v_u_101.lineStrong
					else
						v1292 = v_u_101.line
					end
					local v_u_1293 = v1291(v_u_1290, v1292)
					local v_u_1294 = v_u_99.icon("check", {
						["parent"] = nil,
						["size"] = 14,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v_u_1290,
						["color"] = v_u_101.bgDeep,
						["position"] = UDim2.fromScale(0.5, 0.5),
						["anchor"] = Vector2.new(0.5, 0.5)
					})
					local v_u_1295 = {
						["here"] = v_u_1964,
						["quote"] = v1187[v_u_1284.uid]
					}
					local v1296 = v_u_1284.mods
					local v1297
					if type(v1296) == "table" then
						v1297 = next(v_u_1284.mods) ~= nil
					else
						v1297 = false
					end
					local v1298 = v_u_102.itemCell
					local v1299 = v_u_1284.id
					local v1300 = {
						["size"] = nil,
						["count"] = nil,
						["dim"] = nil,
						["model"] = nil,
						["mods"] = nil,
						["lazy"] = nil,
						["wish"] = false,
						["tooltip"] = nil,
						["size"] = v1196,
						["count"] = v_u_1284.n,
						["dim"] = not v_u_1285,
						["model"] = v_u_1280 ~= "can" and true or nil
					}
					local v1301
					if v1297 then
						v1301 = v_u_1284.mods
					else
						v1301 = nil
					end
					v1300.mods = v1301
					local v1302
					if v_u_1280 == "can" then
						v1302 = false
					else
						v1302 = v_u_1280 ~= "all"
					end
					v1300.lazy = v1302
					v1300.tooltip = v_u_169 and v_u_169.tooltip and function()
						-- upvalues: (ref) v_u_169, (copy) v_u_1284, (copy) v_u_1295
						return v_u_169.tooltip(v_u_1284, nil, v_u_1295)
					end or nil
					local v_u_1303 = v1298(v_u_1288, v1299, v1300)
					v_u_1303.AnchorPoint = Vector2.new(0.5, 0)
					v_u_1303.Position = UDim2.new(0.5, 0, 0, 8)
					table.insert(v_u_1281, {
						["tile"] = nil,
						["cell"] = nil,
						["on"] = false,
						["tile"] = v_u_1288,
						["cell"] = v_u_1303
					})
					if v1297 and (v_u_169 and v_u_169.modBadges) then
						local v1304 = v_u_169.modBadges
						local v1305 = v_u_1284.mods
						local v1306 = {
							["parent"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["zindex"] = 5,
							["parent"] = v_u_1303,
							["position"] = UDim2.new(0, 3, 1, -3),
							["anchor"] = Vector2.new(0, 1)
						}
						pcall(v1304, v1305, v1306)
					end
					local v1307 = v_u_1284.dur
					if tonumber(v1307) then
						local v1308 = v_u_1284.dur
						local v1309 = math.clamp(v1308, 0, 1)
						local v1310 = v_u_99.new("Frame", {
							["Name"] = "Condition",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = v_u_101.bgDeep,
							["AnchorPoint"] = Vector2.new(0.5, 0),
							["Position"] = UDim2.new(0.5, 0, 0, v1196 + 8 + 3),
							["Size"] = UDim2.fromOffset(v1196, 3)
						}, v_u_1288)
						local v1311 = v_u_99.new
						local v1312 = "Frame"
						local v1313 = {
							["Name"] = "Fill",
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Size"] = nil
						}
						local v1314
						if v1309 >= 0.6 then
							v1314 = v_u_101.success
						elseif v1309 >= 0.3 then
							v1314 = v_u_101.accent
						else
							v1314 = v_u_101.danger
						end
						v1313.BackgroundColor3 = v1314
						v1313.Size = UDim2.fromScale(v1309, 1)
						v1311(v1312, v1313, v1310)
					end
					if v_u_1284.fir then
						v_u_484(v_u_1288, "FIR", v_u_101.info, false, {
							["name"] = "Fir",
							["anchor"] = nil,
							["position"] = nil,
							["h"] = 16,
							["zindex"] = 5,
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.new(1, -6, 0, 8)
						})
					end
					local v1315 = v_u_99.label
					local v1316 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["textSize"] = 14,
						["color"] = nil,
						["align"] = "center",
						["position"] = nil,
						["size"] = nil,
						["fit"] = nil,
						["parent"] = v_u_1288,
						["text"] = v_u_102.itemName(v_u_1284.id)
					}
					local v1317
					if v_u_1285 then
						v1317 = v_u_101.text
					else
						v1317 = v_u_101.text2
					end
					v1316.color = v1317
					v1316.position = UDim2.fromOffset(8, v1196 + (v_u_104 and 14 or 16))
					v1316.size = UDim2.new(1, -16, 0, 18)
					v1316.fit = v_u_104
					v1315(v1316)
					local v1318 = v_u_99.new("Frame", {
						["Name"] = "Foot",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(0, 10, 1, -8),
						["Size"] = UDim2.new(1, -20, 0, 20)
					}, v_u_1288)
					local v1319 = v_u_99.label
					local v1320 = {
						["parent"] = nil,
						["name"] = "Price",
						["text"] = nil,
						["style"] = nil,
						["color"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v1318
					}
					local v1321
					if v_u_1285 then
						v1321 = v_u_102.money(v_u_1283.price)
					else
						v1321 = v_u_1283.whyShort or "Not bought"
					end
					v1320.text = v1321
					v1320.style = v_u_1285 and "mono" or "micro"
					local v1322
					if v_u_1285 then
						v1322 = v_u_101.accent
					else
						v1322 = v_u_101.muted
					end
					v1320.color = v1322
					v1320.size = UDim2.new(0.62, 0, 1, 0)
					local v_u_1323 = v1319(v1320)
					local v1324 = v_u_1283.best and (v_u_1283.best ~= v_u_1964 and v_u_1283.bestPrice)
					if v1324 then
						v1324 = not v_u_1285 or v_u_1283.bestPrice > (v_u_1283.price or 0)
					end
					if v1324 then
						local v1325 = v_u_484
						local v1326
						if v_u_104 then
							local v1327 = string.upper(v_u_166(v_u_1283.best).name)
							v1326 = string.sub(v1327, 1, 3)
						else
							v1326 = string.upper(v_u_166(v_u_1283.best).name)
						end
						v1325(v1318, v1326, v_u_101.info, false, {
							["name"] = "Better",
							["icon"] = nil,
							["anchor"] = nil,
							["position"] = nil,
							["h"] = 16,
							["icon"] = not v_u_104 and "arrowUp" or nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0)
						})
					end
					local v_u_1328 = false
					local function v_u_1340() -- name: paint
						-- upvalues: (ref) v_u_1965, (copy) v_u_1284, (copy) v_u_1288, (ref) v_u_101, (ref) v_u_1328, (copy) v_u_1285, (copy) v_u_1289, (copy) v_u_1290, (copy) v_u_1293, (copy) v_u_1294, (copy) v_u_1323
						local v1329 = v_u_1965[v_u_1284.uid] == true
						local v1330 = v_u_1288
						local v1331
						if v1329 then
							v1331 = v_u_101.accentDeep
						elseif v_u_1328 and v_u_1285 then
							v1331 = v_u_101.raised2
						else
							v1331 = v_u_101.raised
						end
						v1330.BackgroundColor3 = v1331
						v_u_1288.BackgroundTransparency = v1329 and 0.05 or (v_u_1285 and 0.2 or 0.55)
						local v1332 = v_u_1289
						local v1333
						if v1329 then
							v1333 = v_u_101.accent
						elseif v_u_1328 and v_u_1285 then
							v1333 = v_u_101.lineStrong
						else
							v1333 = v_u_101.line
						end
						v1332.Color = v1333
						local v1334 = v_u_1290
						local v1335
						if v1329 then
							v1335 = v_u_101.accent
						else
							v1335 = v_u_101.bgDeep
						end
						v1334.BackgroundColor3 = v1335
						local v1336 = v_u_1293
						local v1337
						if v1329 then
							v1337 = v_u_101.accent
						elseif v_u_1285 then
							v1337 = v_u_101.lineStrong
						else
							v1337 = v_u_101.line
						end
						v1336.Color = v1337
						v_u_1294.Visible = v1329
						local v1338 = v_u_1323
						local v1339
						if v1329 then
							v1339 = v_u_101.text
						elseif v_u_1285 then
							v1339 = v_u_101.accent
						else
							v1339 = v_u_101.muted
						end
						v1338.TextColor3 = v1339
					end
					table.insert(v_u_1224, v_u_1340)
					v_u_1288.InputBegan:Connect(function(p1341)
						-- upvalues: (copy) v_u_1285, (ref) v_u_132, (copy) v_u_1284, (ref) v_u_1965
						if v_u_1285 and p1341.UserInputType == Enum.UserInputType.MouseButton1 then
							local v1342 = v_u_132
							local v1343 = v_u_132
							local v1344 = v_u_132
							local v1345 = v_u_132
							local v1346 = v_u_1284.uid
							local v1347 = not v_u_1965[v_u_1284.uid]
							v1342.on = true
							v1343.moved = false
							v1344.start = v1346
							v1345.mode = v1347
						end
					end)
					v_u_1288.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_1328, (ref) v_u_132, (copy) v_u_1285, (copy) v_u_1284, (ref) v_u_1965, (ref) v_u_99, (ref) v_u_100, (copy) v_u_1257, (copy) v_u_1340
						v_u_1328 = true
						if v_u_132.on and (v_u_1285 and v_u_132.start ~= v_u_1284.uid) then
							if not v_u_132.moved then
								v_u_132.moved = true
								v_u_1965[v_u_132.start] = v_u_132.mode and true or nil
							end
							if v_u_1965[v_u_1284.uid] == true ~= v_u_132.mode then
								v_u_1965[v_u_1284.uid] = v_u_132.mode and true or nil
								v_u_99.sound(v_u_100.sounds.click)
								v_u_1257()
							end
						elseif v_u_1285 and not v_u_1965[v_u_1284.uid] then
							v_u_99.sound(v_u_100.sounds.hover)
						end
						v_u_1340()
					end)
					v_u_1288.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_1328, (copy) v_u_1340
						v_u_1328 = false
						v_u_1340()
					end)
					v_u_1288.SelectionGained:Connect(function()
						-- upvalues: (ref) v_u_1328, (copy) v_u_1340, (ref) v_u_99, (copy) v_u_1303, (copy) v_u_1288
						v_u_1328 = true
						v_u_1340()
						if v_u_99.device and (v_u_99.device() == "Gamepad" and v_u_99.showTooltip) then
							task.defer(function()
								-- upvalues: (ref) v_u_1303, (ref) v_u_1288, (ref) v_u_99
								if v_u_1303.Parent and game:GetService("GuiService").SelectedObject == v_u_1288 then
									local v1348 = v_u_99.showTooltip
									local v1349 = v_u_1303
									pcall(v1348, v1349)
								end
							end)
						end
					end)
					v_u_1288.SelectionLost:Connect(function()
						-- upvalues: (ref) v_u_1328, (copy) v_u_1340, (ref) v_u_99, (copy) v_u_1303
						v_u_1328 = false
						v_u_1340()
						if v_u_99.tooltipOwner and (v_u_99.hideTooltip and v_u_99.tooltipOwner() == v_u_1303) then
							local v1350 = v_u_99.hideTooltip
							pcall(v1350)
						end
					end)
					local function v_u_1351() -- name: toggle
						-- upvalues: (copy) v_u_1285, (ref) v_u_99, (ref) v_u_100, (copy) v_u_1283, (ref) v_u_166, (ref) v_u_1964, (ref) v_u_1965, (copy) v_u_1284, (copy) v_u_1257
						if v_u_1285 then
							v_u_99.sound(v_u_100.sounds.click)
							v_u_1965[v_u_1284.uid] = not v_u_1965[v_u_1284.uid] and true or nil
							v_u_1257()
							return
						else
							v_u_99.sound(v_u_100.sounds.error)
							if v_u_1283.best then
								v_u_99.toast(v_u_166(v_u_1964).name .. " does not buy this", "warn", "Try " .. v_u_166(v_u_1283.best).name .. ".")
								return
							elseif v_u_1283.why then
								v_u_99.toast(v_u_1283.whyShort or "Can\'t sell this", "warn", v_u_1283.why)
							else
								v_u_99.toast("No trader buys this", "warn")
							end
						end
					end
					local v1352 = v_u_131
					local v1353 = v_u_1284.uid
					v1352[tostring(v1353)] = v_u_1351
					v_u_1288.Activated:Connect(function()
						-- upvalues: (ref) v_u_132, (copy) v_u_1351
						if v_u_132.moved then
							v_u_132.moved = false
						else
							v_u_1351()
						end
					end)
				end
				if #v_u_1281 > 0 then
					local v_u_1354 = true
					v_u_1279.Destroying:Connect(function()
						-- upvalues: (ref) v_u_1354
						v_u_1354 = false
					end)
					v_u_1279:SetAttribute("Tiles", #v_u_1281)
					local function v_u_1366() -- name: cullSell
						-- upvalues: (ref) v_u_1354, (ref) v_u_1280, (copy) v_u_1279, (copy) v_u_1281, (ref) v_u_102
						if v_u_1354 then
							local v1355
							if v_u_1280 == "can" then
								v1355 = false
							else
								v1355 = v_u_1280 ~= "all"
							end
							local v1356 = v_u_1279.AbsolutePosition
							local v1357 = v_u_1279.AbsoluteSize
							local v1358 = v1357.Y > 4
							local v1359 = 0
							for v1360, v1361 in v_u_1281 do
								local v1362 = v1360 <= 12
								if v1358 then
									local v1363 = v1361.tile.AbsolutePosition
									local v1364 = v1361.tile.AbsoluteSize
									if v1364.Y > 0 then
										if v1363.Y + v1364.Y >= v1356.Y - v1364.Y then
											v1362 = v1363.Y <= v1356.Y + v1357.Y + v1364.Y
										else
											v1362 = false
										end
									end
								end
								local v1365 = not v1355 and true or v1362
								if v1365 ~= v1361.on then
									v1361.on = v1365
									if v1355 then
										v_u_102.cellRender(v1361.cell, v1365)
									end
								end
								if not v1365 then
									continue
								end
								v1359 = v1359 + 1
							end
							v_u_1279:SetAttribute("Renders", v1359)
						end
					end
					local v_u_1367 = false
					local function v1368() -- name: mark
						-- upvalues: (ref) v_u_1367, (ref) v_u_1354, (copy) v_u_1366
						if not v_u_1367 and v_u_1354 then
							v_u_1367 = true
							task.defer(function()
								-- upvalues: (ref) v_u_1367, (ref) v_u_1366
								v_u_1367 = false
								v_u_1366()
							end)
						end
					end
					local v_u_1369 = v_u_1354
					for _, v1370 in {
						"CanvasPosition",
						"AbsoluteSize",
						"AbsolutePosition",
						"AbsoluteCanvasSize"
					} do
						v_u_1279:GetPropertyChangedSignal(v1370):Connect(v1368)
					end
					v_u_1366()
					task.spawn(function()
						-- upvalues: (ref) v_u_1369, (copy) v_u_1366
						while v_u_1369 do
							task.wait(0.4)
							v_u_1366()
						end
					end)
				end
				if #v_u_1200 == 0 then
					v_u_102.empty(v_u_1279, "Your stash is empty. Only stash items are sold, not what you carry.")
				elseif #v_u_1230 == 0 then
					v_u_102.empty(v_u_1279, "Nothing in this filter. Pick another one above.")
				end
				v_u_1257()
				return
			end
		end
		if v_u_104 and v_u_331 then
			v_u_102.clear(v_u_331)
		end
		local v1371 = {
			["parent"] = nil,
			["gap"] = 4,
			["parent"] = v_u_386
		}
		v_u_742(v_u_99.list(v1371), "Loading prices...")
	end
	function v_u_105.confirmSell() -- name: confirmSell
		-- upvalues: (ref) v_u_170, (ref) v_u_1965, (ref) v_u_1964, (copy) v_u_166, (copy) v_u_1178, (copy) v_u_105, (copy) p_u_97, (ref) v_u_169, (copy) v_u_672, (ref) v_u_1993, (copy) p_u_98, (copy) v_u_102, (copy) v_u_99
		local v_u_1373 = {}
		local v1374 = 0
		local v1375 = v_u_170
		local v1376
		if type(v1375) == "table" then
			local v1377 = v_u_170.quotes
			v1376 = type(v1377) == "table" and (v_u_170.quotes or {}) or {}
		else
			v1376 = {}
		end
		for v1378 in v_u_1965 do
			local v1379 = v1376[v1378]
			local v1380
			if type(v1379) == "table" then
				local v1381 = v1379.prices
				if type(v1381) == "table" then
					local v1382 = v1379.prices[v_u_1964]
					v1380 = tonumber(v1382) or nil
				else
					v1380 = nil
				end
			else
				v1380 = nil
			end
			if not v1380 then
				continue
			end
			table.insert(v_u_1373, v1378)
			v1374 = v1374 + v1380
		end
		if #v_u_1373 ~= 0 then
			local v1383 = v_u_166(v_u_1964).name
			local v_u_1384 = v_u_1964
			local v1385 = v_u_1178(v1374)
			local v1386 = v_u_105
			local v1387
			if v1385 then
				v1387 = v1385.long
			else
				v1387 = v1385
			end
			v1386.sellPreview = v1387
			local v1388 = 0
			local v1389 = 0
			local v1390 = p_u_97.profile
			local v1391
			if type(v1390) == "table" then
				local v1392 = v1390.inv
				if type(v1392) == "table" then
					local v1393 = v1390.inv.containers
					if type(v1393) == "table" then
						v1391 = v1390.inv.containers.stash or nil
					else
						v1391 = nil
					end
				else
					v1391 = nil
				end
			else
				v1391 = nil
			end
			if type(v1391) == "table" then
				local v1394 = v1391.items
				if type(v1394) == "table" then
					local v1395 = {}
					for _, v1396 in v_u_1373 do
						v1395[v1396] = true
					end
					for _, v1397 in v1391.items do
						if type(v1397) ~= "table" or not v1395[v1397.uid] then
							continue
						end
						local v1398 = v1397.mods
						if type(v1398) ~= "table" then
							continue
						end
						local v1399 = v_u_169 and v_u_169.modList and #v_u_169.modList(v1397.mods) or 0
						if v1399 <= 0 then
							continue
						end
						v1388 = v1388 + 1
						v1389 = v1389 + v1399
					end
				end
			end
			v_u_105.sellAttachments = v1389
			local function v_u_1404(p1400) -- name: doSell
				-- upvalues: (ref) p_u_97, (copy) v_u_1384, (copy) v_u_1373, (ref) v_u_1965, (ref) v_u_105, (ref) v_u_672, (ref) v_u_1993, (ref) p_u_98
				local v1401 = {
					["op"] = "sell",
					["trader"] = nil,
					["uids"] = nil,
					["strip"] = nil,
					["trader"] = v_u_1384,
					["uids"] = v_u_1373,
					["strip"] = p1400 and true or nil
				}
				p_u_97.op(v1401)
				v_u_1965 = {}
				v_u_105.sellModal = nil
				for _, v1402 in v_u_1373 do
					v_u_672.sold[v1402] = os.clock()
				end
				if v_u_1993 == "sell" and p_u_98.Parent then
					task.defer(function()
						-- upvalues: (ref) v_u_105
						local v1403 = v_u_105.drawBody
						pcall(v1403)
					end)
				end
			end
			v_u_105.sellDo = v_u_1404
			local v1405 = v1389 <= 0 and "" or (" Attachments are sold with it (%d on %s). Strip them first to keep them in your stash."):format(v1389, v1388 == 1 and "1 weapon" or ("%d weapons"):format(v1388))
			local v1406 = {
				{
					["text"] = "Cancel",
					["kind"] = "ghost"
				}
			}
			if v1389 > 0 then
				table.insert(v1406, {
					["text"] = "Strip first",
					["kind"] = "secondary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_1404
						v_u_1404(true)
					end
				})
			end
			local v1407 = {
				["text"] = nil,
				["kind"] = "primary",
				["onClick"] = nil,
				["text"] = ("Sell for %s"):format(v_u_102.money(v1374)),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_1404
					v_u_1404(false)
				end
			}
			table.insert(v1406, v1407)
			v_u_105.sellModal = v_u_99.modal({
				["title"] = ("Sell to %s?"):format(v1383),
				["body"] = ("%s for %s.%s Sold items are gone for good.%s"):format(#v_u_1373 == 1 and "1 item" or ("%d items"):format(#v_u_1373), v_u_102.money(v1374), not v1385 and "" or " " .. v1385.long, v1405),
				["width"] = v1389 > 0 and 520 or 460,
				["buttons"] = v1406,
				["onClose"] = function() -- name: onClose
					-- upvalues: (ref) v_u_105
					v_u_105.sellModal = nil
				end
			})
		end
	end
	local function v_u_1428(p1408) -- name: drawTasks
		-- upvalues: (copy) v_u_386, (copy) p_u_97, (copy) v_u_103, (copy) v_u_99, (ref) v_u_122, (copy) v_u_742, (ref) v_u_1964, (copy) v_u_102, (ref) v_u_1966
		local v1409 = p1408 or v_u_386
		local v_u_1410 = nil
		local function v1411()
			-- upvalues: (ref) v_u_1410, (ref) p_u_97
			v_u_1410 = p_u_97.cctx.shared.Tasks
		end
		pcall(v1411)
		local v1412 = v_u_103 and 220 or 300
		local v1413 = v_u_99.list({
			["parent"] = nil,
			["size"] = nil,
			["gap"] = 4,
			["parent"] = v1409,
			["size"] = UDim2.new(0, v1412, 1, 0)
		})
		local v_u_1414 = v_u_99.new("Frame", {
			["Name"] = "Detail",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(v1412 + 16, 0),
			["Size"] = UDim2.new(1, -v1412 - 16, 1, 0)
		}, v1409)
		if v_u_1410 then
			local v1415 = v_u_122
			if type(v1415) == "table" then
				local v1416 = v_u_1410.byGiver(v_u_1964)
				local function v_u_1420() -- name: drawTaskDetail
					-- upvalues: (ref) v_u_102, (copy) v_u_1414, (ref) v_u_1966, (ref) p_u_97, (ref) v_u_122
					v_u_102.clear(v_u_1414)
					if v_u_1966 then
						local function v1417()
							-- upvalues: (ref) p_u_97, (ref) v_u_1414, (ref) v_u_1966, (ref) v_u_122
							p_u_97.cctx.lib.MenuTasks.detail(p_u_97, v_u_1414, v_u_1966, v_u_122)
						end
						local v1418, v1419 = pcall(v1417)
						if not v1418 then
							v_u_102.empty(v_u_1414, (tostring(v1419)))
						end
					end
				end
				local v_u_1421 = {}
				for v1422, v_u_1423 in v1416 do
					local v1424 = (v_u_122.tasks and (v_u_122.tasks[v_u_1423.id] or {}) or {}).state or "locked"
					if not v_u_1966 and (v1424 == "ready" or (v1424 == "active" or v1424 == "available")) then
						v_u_1966 = v_u_1423.id
					end
					local _, v1427 = v_u_99.button({
						["parent"] = nil,
						["text"] = nil,
						["kind"] = nil,
						["icon"] = nil,
						["width"] = nil,
						["height"] = 40,
						["order"] = nil,
						["onClick"] = nil,
						["parent"] = v1413,
						["text"] = v_u_1423.title,
						["kind"] = v_u_1966 == v_u_1423.id and "secondary" or "ghost",
						["icon"] = v1424 == "done" and "check" or (v1424 == "locked" and "lock" or (v1424 == "ready" and "star" or "task")),
						["width"] = v1412 - 8,
						["order"] = v1422,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_1966, (copy) v_u_1423, (copy) v_u_1421, (copy) v_u_1420
							if v_u_1966 ~= v_u_1423.id then
								v_u_1966 = v_u_1423.id
								for v1425, v1426 in v_u_1421 do
									v1426.setKind(v1425 == v_u_1966 and "secondary" or "ghost")
									v1426.setSelected(v1425 == v_u_1966)
								end
								v_u_1420()
							end
						end
					})
					v_u_1421[v_u_1423.id] = v1427
					if v_u_1966 ~= v_u_1423.id then
						continue
					end
					v1427.setSelected(true)
				end
				if #v1416 == 0 then
					v_u_102.empty(v1413, "No tasks from this trader yet.")
				end
				v_u_1420()
				return
			end
		end
		v_u_742(v1413, "Loading tasks...")
	end
	local function v_u_1442(p1429) -- name: taskStats
		-- upvalues: (copy) p_u_97, (ref) v_u_122
		local v1430 = {
			["available"] = 0,
			["active"] = 0,
			["ready"] = 0,
			["open"] = 0,
			["rep"] = 0
		}
		local v_u_1431 = nil
		local function v1432()
			-- upvalues: (ref) v_u_1431, (ref) p_u_97
			v_u_1431 = p_u_97.cctx.shared.Tasks
		end
		pcall(v1432)
		if v_u_1431 then
			local v1433 = v_u_1431.byGiver
			if type(v1433) == "function" then
				local v1434 = v_u_122
				local v1435
				if type(v1434) == "table" then
					local v1436 = v_u_122.tasks
					if type(v1436) == "table" then
						v1435 = v_u_122.tasks or nil
					else
						v1435 = nil
					end
				else
					v1435 = nil
				end
				for _, v1437 in v_u_1431.byGiver(p1429) do
					local v1438 = v1435 and ((v1435[v1437.id] or {}).state or "locked") or "locked"
					if v1438 == "available" or (v1438 == "active" or v1438 == "ready") then
						v1430[v1438] = v1430[v1438] + 1
						v1430.open = v1430.open + 1
					end
					if v1438 == "done" then
						continue
					end
					local v1439 = v1437.rewards
					if type(v1439) ~= "table" then
						continue
					end
					local v1440 = v1430.rep
					local v1441 = v1437.rewards.rep
					v1430.rep = v1440 + (tonumber(v1441) or 0)
				end
				return v1430
			end
		end
		return v1430
	end
	v_u_105.taskStats = v_u_1442
	local function v_u_1445(p1443) -- name: pct
		local v1444 = p1443 * 100 + 0.5
		return ("%d%%"):format((math.floor(v1444)))
	end
	local function v_u_1469(p1446) -- name: sellLines
		-- upvalues: (copy) v_u_166, (copy) v_u_146, (copy) v_u_1445
		local v1447 = v_u_166(p1446)
		local v1448 = {}
		for v1449 in v1447.sellL5 or {} do
			table.insert(v1448, v1449)
		end
		table.sort(v1448)
		local v_u_1450 = {}
		local v1451 = {}
		for _, v1452 in v1448 do
			local v1453 = v1447.sell and (v1447.sell[v1452] or 0) or 0
			local v1454 = v1447.sellL5[v1452]
			local v1455 = ("%g>%g"):format(v1453, v1454)
			local v1456 = v_u_1450[v1455]
			if not v1456 then
				v1456 = {
					["from"] = v1453,
					["to"] = v1454,
					["names"] = {}
				}
				v_u_1450[v1455] = v1456
				table.insert(v1451, v1455)
			end
			local v1457 = v_u_146[v1452] or v1452
			if table.find(v1456.names, v1457) then
				continue
			end
			local v1458 = v1456.names
			table.insert(v1458, v1457)
		end
		table.sort(v1451, function(p1459, p1460)
			-- upvalues: (copy) v_u_1450
			if v_u_1450[p1459].from == v_u_1450[p1460].from then
				return p1459 < p1460
			else
				return v_u_1450[p1459].from > v_u_1450[p1460].from
			end
		end)
		local v1461 = {}
		for _, v1462 in v1451 do
			local v1463 = v_u_1450[v1462]
			local v1464 = #v1463.names > 4 and "Most goods" or table.concat(v1463.names, ", ")
			local v1465 = v1463.from * 100 + 0.5
			local v1466 = ("%d%%"):format((math.floor(v1465)))
			local v1467 = v_u_1445
			local v1468 = v1463.to
			table.insert(v1461, ("%s %s to %s"):format(v1464, v1466, v1467(v1468)))
		end
		return v1461
	end
	local function v_u_1489(p1470) -- name: confirmPartner
		-- upvalues: (ref) v_u_175, (ref) v_u_174, (ref) v_u_1964, (ref) v_u_171, (copy) p_u_97, (copy) v_u_99, (copy) v_u_100, (ref) v_u_1993, (copy) p_u_98, (copy) v_u_105, (copy) v_u_102, (copy) v_u_166
		if v_u_175 or v_u_174 then
			return
		end
		local v_u_1471 = v_u_1964
		local v1472
		if v_u_171 and v_u_171.defs then
			v1472 = v_u_171.defs[v_u_1471]
		else
			v1472 = nil
		end
		local v1473
		if type(v1472) == "table" then
			local v1474 = v1472.name
			if type(v1474) == "string" then
				v1473 = v1472.name
			else
				v1473 = string.upper(v_u_1471)
			end
		else
			v1473 = string.upper(v_u_1471)
		end
		local v1475 = p_u_97.profile
		if v1475 then
			v1475 = p_u_97.profile.cash
		end
		local v1476 = tonumber(v1475) or 0
		local function v1482() -- name: pay
			-- upvalues: (ref) v_u_175, (ref) v_u_174, (ref) v_u_99, (ref) v_u_100, (ref) p_u_97, (copy) v_u_1471, (ref) v_u_1993, (ref) p_u_98, (ref) v_u_105
			v_u_175 = true
			local v1477 = v_u_174
			v_u_174 = nil
			if v1477 then
				local v1478 = v1477.close
				pcall(v1478)
			end
			v_u_99.sound(v_u_100.sounds.click)
			local v1479 = {
				["op"] = "traderPartner",
				["trader"] = nil,
				["trader"] = v_u_1471
			}
			p_u_97.op(v1479)
			task.defer(function()
				-- upvalues: (ref) v_u_1993, (ref) p_u_98, (ref) v_u_105
				if v_u_1993 == "partner" and p_u_98.Parent then
					local v1480 = v_u_105.drawBody
					pcall(v1480)
				end
			end)
			task.delay(6, function()
				-- upvalues: (ref) v_u_175, (ref) v_u_1993, (ref) p_u_98, (ref) v_u_105
				if v_u_175 then
					v_u_175 = false
					if v_u_1993 == "partner" and p_u_98.Parent then
						local v1481 = v_u_105.drawBody
						pcall(v1481)
					end
				end
			end)
		end
		v_u_105.partnerPay = v1482
		local v1483 = v_u_99.modal
		local v1484 = {
			["title"] = nil,
			["body"] = nil,
			["width"] = 480,
			["buttons"] = nil,
			["onClose"] = nil,
			["title"] = ("Become %s\'s partner?"):format(v1473)
		}
		local v1485 = v_u_102.money(p1470)
		local v1486 = v_u_102.money(v1476)
		local v1487 = v_u_102.money
		local v1488 = v1476 - p1470
		v1484.body = ("You pay %s once, for good. Your cash goes from %s to %s. You get level 5 with %s: more offers, a faster restock and better prices when you sell."):format(v1485, v1486, v1487((math.max(0, v1488))), v_u_166(v_u_1471).name)
		v1484.buttons = {
			{
				["text"] = "Cancel",
				["kind"] = "ghost"
			},
			{
				["text"] = nil,
				["kind"] = "primary",
				["onClick"] = nil,
				["text"] = ("Pay %s"):format(v_u_102.money(p1470)),
				["onClick"] = v1482
			}
		}
		function v1484.onClose() -- name: onClose
			-- upvalues: (ref) v_u_174, (ref) v_u_105
			v_u_174 = nil
			v_u_105.partnerPay = nil
		end
		v_u_174 = v1483(v1484)
	end
	local function v_u_1613() -- name: drawPartner
		-- upvalues: (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (ref) v_u_176, (copy) v_u_105, (copy) v_u_99, (copy) v_u_386, (copy) v_u_102, (copy) v_u_166, (ref) v_u_171, (copy) p_u_98, (ref) v_u_175, (copy) v_u_104, (copy) v_u_101, (ref) v_u_3, (copy) v_u_100, (copy) v_u_1489, (copy) v_u_1469, (copy) p_u_97
		local v1490
		if v_u_115 and v_u_1964 == "gunsmith" then
			v1490 = v_u_115.traderView()
		else
			local v1491 = v_u_170
			if type(v1491) == "table" then
				local v1492 = v_u_170.traders
				v1490 = type(v1492) == "table" and v_u_170.traders[v_u_1964] or nil
			else
				v1490 = nil
			end
		end
		local v1493
		if v1490 then
			v1493 = v1490.partner
		else
			v1493 = nil
		end
		v_u_176 = nil
		v_u_105.partnerAsk = nil
		if not v1490 or type(v1493) ~= "table" then
			local v1494 = {
				["parent"] = nil,
				["gap"] = 4,
				["parent"] = v_u_386
			}
			local v1495 = v_u_99.list(v1494)
			v_u_102.empty(v1495, v_u_170 == nil and "Loading..." or "Partnerships are not open yet.")
			return
		end
		local v1496 = v_u_166(v_u_1964)
		local v1497 = v_u_1964
		local v1498
		if v_u_171 and v_u_171.defs then
			v1498 = v_u_171.defs[v1497]
		else
			v1498 = nil
		end
		local v1499
		if type(v1498) == "table" then
			local v1500 = v1498.name
			if type(v1500) == "string" then
				v1499 = v1498.name
			else
				v1499 = string.upper(v1497)
			end
		else
			v1499 = string.upper(v1497)
		end
		local v1501 = v1493.owned == true
		local v1502 = v1493.price
		local v_u_1503 = tonumber(v1502) or 0
		local v1504 = p_u_98
		local v1505 = v_u_1964
		local v1506 = tostring(v1501)
		local v1507 = v1493.can == true
		local v1508 = tostring(v1507)
		local v1509 = v_u_175
		local v1510 = tostring(v1509)
		local v1511 = v1493.reason
		v1504:SetAttribute("PartnerState", ("%s owned=%s can=%s busy=%s price=%d reason=%s"):format(v1505, v1506, v1508, v1510, v_u_1503, (tostring(v1511))))
		local v1512 = v_u_99.new("Frame", {
			["Name"] = "PartnerCols",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_386)
		v_u_99.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 14),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v1512)
		local v1513 = v_u_99.new("Frame", {
			["Name"] = "PartnerLeft",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(v_u_104 and 0.58 or 0.52, -7, 1, 0)
		}, v1512)
		v_u_99.new("UISizeConstraint", {
			["MinSize"] = Vector2.new(v_u_104 and 0 or 400, 0),
			["MaxSize"] = Vector2.new(640, (1 / 0))
		}, v1513)
		local _, v1514 = v_u_99.panel({
			["parent"] = nil,
			["name"] = "Panel",
			["raised"] = true,
			["size"] = nil,
			["padding"] = 14,
			["parent"] = v1513,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v1515 = v_u_99.list({
			["parent"] = nil,
			["name"] = "Scroll",
			["gap"] = 10,
			["parent"] = v1514
		})
		local v1516 = v_u_99.label
		local v1517 = {
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "h3",
			["order"] = 1,
			["size"] = nil,
			["parent"] = v1515
		}
		local v1518
		if v1501 then
			v1518 = v1499 .. "\'s partner"
		else
			v1518 = "Become " .. v1499 .. "\'s partner"
		end
		v1517.text = v1518
		v1517.size = UDim2.new(1, -6, 0, 26)
		v1516(v1517)
		v_u_99.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["order"] = 2,
			["size"] = nil,
			["parent"] = v1515,
			["text"] = ("Trader level 5 with %s"):format(v1496.name),
			["color"] = v_u_101.text2,
			["size"] = UDim2.new(1, -6, 0, 18)
		})
		local v1519 = {
			["level"] = "Trader level",
			["rep"] = "Reputation",
			["ep"] = "Mission points",
			["cash"] = "Buy-in"
		}
		for v1520, v1521 in v1493.reqs do
			local v1522 = v1501 or v1521.ok == true
			local v1523 = v1521.have
			local v1524 = tonumber(v1523) or 0
			local v1525 = v1521.need
			local v1526 = tonumber(v1525) or 0
			if v1521.id == "ep" then
				local v1527 = math.floor(v1524)
				local v1528 = math.max(0, v1527)
				local v1529 = math.floor(v1526)
				local v1530 = math.max(0, v1529)
				v1524 = math.min(v1528, v1530)
			end
			local v1531 = v_u_99.new
			local v1532 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil
			}
			local v1533 = v1521.id
			v1532.Name = "Req_" .. tostring(v1533)
			v1532.Size = UDim2.new(1, -6, 0, v1521.id == "level" and 26 or 38)
			v1532.LayoutOrder = 10 + v1520
			local v1534 = v1531("Frame", v1532, v1515)
			local v1535 = v_u_99.icon
			local v1536 = v1522 and "check" or "close"
			local v1537 = {
				["parent"] = nil,
				["size"] = 14,
				["color"] = nil,
				["position"] = nil,
				["parent"] = v1534
			}
			local v1538
			if v1522 then
				v1538 = v_u_101.success
			else
				v1538 = v_u_101.accent
			end
			v1537.color = v1538
			v1537.position = UDim2.fromOffset(0, 4)
			v1535(v1536, v1537)
			local v1539 = v_u_99.label
			local v1540 = {
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = nil,
				["parent"] = v1534
			}
			local v1541 = "%s %s"
			local v1542 = v1519[v1521.id]
			if not v1542 then
				local v1543 = v1521.id
				v1542 = tostring(v1543)
			end
			local v1544
			if v1521.id == "cash" then
				v1544 = v_u_102.money(v1526)
			else
				v1544 = tostring(v1526)
			end
			v1540.text = v1541:format(v1542, v1544)
			local v1545
			if v1522 then
				v1545 = v_u_101.text
			else
				v1545 = v_u_101.text2
			end
			v1540.color = v1545
			v1540.position = UDim2.fromOffset(24, 0)
			v1540.size = UDim2.new(0.5, -24, 0, 22)
			v1540.fit = v_u_104
			v1539(v1540)
			local v1546
			if v1521.id == "level" then
				v1546 = ("LV %d"):format(v1501 and 5 or v1524)
			elseif v1521.id == "cash" then
				v1546 = ("%s / %s"):format(v_u_102.money(v1524), v_u_102.money(v1526))
			else
				v1546 = ("%d / %d"):format(v1524, v1526)
			end
			local v1547 = v_u_99.label
			local v1548 = {
				["parent"] = nil,
				["name"] = "Value",
				["text"] = nil,
				["style"] = "mono",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = nil,
				["parent"] = v1534,
				["text"] = v1546
			}
			local v1549
			if v1522 then
				v1549 = v_u_101.success
			else
				v1549 = v_u_101.accent
			end
			v1548.color = v1549
			v1548.position = UDim2.fromScale(0.5, 0)
			v1548.size = UDim2.new(0.5, 0, 0, 22)
			v1548.fit = v_u_104
			v1547(v1548)
			if v1521.id == "level" then
				continue
			end
			local v1550 = v_u_99.progress
			local v1551 = {
				["parent"] = v1534,
				["size"] = UDim2.new(1, 0, 0, 4),
				["position"] = UDim2.fromOffset(0, 28)
			}
			local v1552
			if v1501 then
				v1552 = 1
			else
				local v1553 = v1524 / math.max(1, v1526)
				v1552 = math.clamp(v1553, 0, 1)
			end
			v1551.value = v1552
			local v1554
			if v1522 then
				v1554 = v_u_101.success
			else
				v1554 = v_u_101.accent
			end
			v1551.color = v1554
			v1550(v1551)
		end
		if v1501 then
			local v1555 = v_u_99.new("Frame", {
				["Name"] = "Owned",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 30,
				["BackgroundColor3"] = v_u_101.successDeep or v_u_101.raised,
				["Size"] = UDim2.new(1, -6, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v1515)
			v_u_99.stroke(v1555, v_u_101.success, 1, 0.4)
			v_u_99.pad(v1555, {
				10,
				10,
				8,
				8
			})
			v_u_99.layout(v1555, "v", 4)
			v_u_99.label({
				["parent"] = nil,
				["text"] = "Partner",
				["style"] = "caps",
				["color"] = nil,
				["order"] = 1,
				["size"] = nil,
				["parent"] = v1555,
				["color"] = v_u_101.success,
				["size"] = UDim2.new(1, 0, 0, 18)
			})
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v1555,
				["text"] = ("You are %s\'s partner. Level 5 is open: see the BUY tab."):format(v1499),
				["color"] = v_u_101.text
			})
		else
			local v1556 = v1493.reason
			if type(v1556) == "string" and v1493.reason ~= "" then
				local v1557 = v_u_99.new("Frame", {
					["Name"] = "ReasonRow",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 30,
					["Size"] = UDim2.new(1, -6, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v1515)
				v_u_99.icon("lock", {
					["parent"] = nil,
					["size"] = 14,
					["color"] = nil,
					["position"] = nil,
					["parent"] = v1557,
					["color"] = v_u_101.danger,
					["position"] = UDim2.fromOffset(0, 2)
				})
				local v1558 = v1493.reason
				if v1558 == "Not enough cash" then
					local v1559 = v1493.reqs
					if type(v1559) == "table" then
						for _, v1560 in v1493.reqs do
							if type(v1560) ~= "table" or v1560.id ~= "cash" then
								continue
							end
							local v1561 = v1560.need
							if not tonumber(v1561) then
								continue
							end
							local v1562 = v1560.have
							if not tonumber(v1562) then
								continue
							end
							v1558 = v_u_3.shortText(v1560.need, v1560.have)
						end
					end
				end
				v_u_99.label({
					["parent"] = nil,
					["name"] = "Reason",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v1557,
					["text"] = v1558,
					["color"] = v_u_101.text,
					["position"] = UDim2.fromOffset(24, 0),
					["size"] = UDim2.new(1, -24, 0, 0)
				})
			end
			local v1563
			if v1493.can == true then
				v1563 = not v_u_175
			else
				v1563 = false
			end
			local v1564 = v_u_175 and "Paying..." or "Become partner  " .. v_u_102.money(v_u_1503)
			local v1565 = v_u_100.touch(48)
			local v1566
			if v1563 then
				v1566 = v_u_99.button({
					["parent"] = nil,
					["name"] = "PartnerButton",
					["text"] = nil,
					["kind"] = "primary",
					["size"] = nil,
					["order"] = 31,
					["onClick"] = nil,
					["parent"] = v1515,
					["text"] = v1564,
					["size"] = UDim2.new(1, -6, 0, v1565),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_1489, (copy) v_u_1503
						v_u_1489(v_u_1503)
					end
				})
			else
				v1566 = v_u_99.new("TextButton", {
					["Name"] = "PartnerButton",
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.45,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 31,
					["Selectable"] = true,
					["BackgroundColor3"] = v_u_101.raised,
					["Size"] = UDim2.new(1, -6, 0, v1565)
				}, v1515)
				v1566:SetAttribute("Disabled", true)
				v1566.SelectionImageObject = v_u_99.selectionImage()
				v_u_99.stroke(v1566, v_u_101.lineStrong)
				v_u_99.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "h3",
					["textSize"] = 15,
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["parent"] = v1566,
					["text"] = v1564,
					["color"] = v_u_101.text2,
					["size"] = UDim2.fromScale(1, 1)
				})
				v1566.Activated:Connect(function()
					-- upvalues: (ref) v_u_99, (ref) v_u_100
					v_u_99.sound(v_u_100.sounds.error)
				end)
			end
			v_u_99.new("UISizeConstraint", {
				["MaxSize"] = Vector2.new(420, (1 / 0))
			}, v1566)
			v_u_176 = v1566
			v_u_105.partnerAsk = v1563 and function()
				-- upvalues: (ref) v_u_1489, (copy) v_u_1503
				v_u_1489(v_u_1503)
			end or nil
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Note",
				["text"] = "The buy-in is paid once and cannot be undone.",
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 32,
				["track"] = false,
				["parent"] = v1515,
				["color"] = v_u_101.muted
			})
		end
		local v1567 = v_u_99.new("Frame", {
			["Name"] = "PartnerRight",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.new(v_u_104 and 0.42 or 0.48, -7, 1, 0)
		}, v1512)
		v_u_99.new("UISizeConstraint", {
			["MinSize"] = Vector2.new(v_u_104 and 0 or 280, 0),
			["MaxSize"] = Vector2.new(560, (1 / 0))
		}, v1567)
		local _, v1568 = v_u_99.panel({
			["parent"] = nil,
			["name"] = "Panel",
			["raised"] = true,
			["size"] = nil,
			["padding"] = 14,
			["parent"] = v1567,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_1569 = v_u_99.list({
			["parent"] = nil,
			["name"] = "Scroll",
			["gap"] = 8,
			["parent"] = v1568
		})
		v_u_102.section(v_u_1569, "What a partner gets", 1)
		local function v_u_1573(p1570, p1571) -- name: perkBox
			-- upvalues: (ref) v_u_99, (copy) v_u_1569
			local v1572 = v_u_99.new("Frame", {
				["Name"] = "Perk",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, -6, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = p1570
			}, v_u_1569)
			v_u_99.pad(v1572, {
				12,
				0,
				0,
				0
			})
			v_u_99.layout(v1572, "v", 2)
			v_u_99.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["order"] = 1,
				["size"] = nil,
				["parent"] = v1572,
				["text"] = p1571,
				["size"] = UDim2.new(1, 0, 0, 20)
			})
			return v1572
		end
		local function v1578(p1574, p1575, p1576) -- name: perk
			-- upvalues: (copy) v_u_1573, (ref) v_u_99, (ref) v_u_101
			local v1577 = v_u_1573(p1574, p1575)
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v1577,
				["text"] = p1576,
				["color"] = v_u_101.text2
			})
		end
		local v1579 = v_u_1573(2, ("%d new offers"):format(#(v1496.offersL5 or {})))
		v1579.Name = "PerkOffers"
		for v1580, v1581 in v1496.offersL5 or {} do
			local v1582 = v_u_99.new("Frame", {
				["Name"] = "Offer",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 24),
				["LayoutOrder"] = 1 + v1580
			}, v1579)
			v_u_99.new("Frame", {
				["Name"] = "Tick",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_101.accent,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.fromScale(0, 0.5),
				["Size"] = UDim2.fromOffset(4, 4)
			}, v1582)
			local v1583 = v1581.n
			local v1584 = tonumber(v1583) or 1
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v1582,
				["text"] = v1581.name or v_u_102.itemName(v1581.id),
				["color"] = v_u_101.text,
				["position"] = UDim2.fromOffset(12, 0),
				["size"] = UDim2.new(1, -((v1584 > 1 and 56 or 0) + 12), 1, 0)
			})
			if v1584 <= 1 then
				continue
			end
			v_u_99.label({
				["parent"] = nil,
				["name"] = "Pack",
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v1582,
				["text"] = ("x%d"):format(v1584),
				["color"] = v_u_101.text2,
				["position"] = UDim2.new(1, -56, 0, 0),
				["size"] = UDim2.fromOffset(56, 24)
			})
		end
		local v1585
		if v_u_171 then
			local v1586 = v_u_171.RESTOCK_BY_LEVEL
			if type(v1586) == "table" then
				local v1587 = v_u_171.RESTOCK_BY_LEVEL[4]
				v1585 = tonumber(v1587) or 1350
			else
				v1585 = 1350
			end
		else
			v1585 = 1350
		end
		local v1588 = 3
		local v1589 = "Faster restock"
		local v1590 = "Fresh stock every %s, instead of every %s at level 4."
		local v1591 = v1493.restockSec
		local v1592 = tonumber(v1591) or 900
		local v1593 = v1592 / 60
		local v1594 = math.floor(v1593)
		local v1595 = v1592 % 60
		local v1596
		if v1595 > 0 then
			v1596 = ("%d min %d s"):format(v1594, v1595)
		else
			v1596 = ("%d min"):format(v1594)
		end
		local v1597 = v1585 / 60
		local v1598 = math.floor(v1597)
		local v1599 = v1585 % 60
		local v1600
		if v1599 > 0 then
			v1600 = ("%d min %d s"):format(v1598, v1599)
		else
			v1600 = ("%d min"):format(v1598)
		end
		v1578(v1588, v1589, v1590:format(v1596, v1600))
		local v1601 = v_u_1469(v_u_1964)
		if #v1601 > 0 then
			v1578(4, ("%s pays more"):format(v1499), table.concat(v1601, "\n"))
		end
		local v_u_1602 = nil
		local function v1603()
			-- upvalues: (ref) v_u_1602, (ref) p_u_97
			v_u_1602 = p_u_97.cctx.shared.Badges
		end
		pcall(v1603)
		local v1604
		if v_u_1602 and v_u_1602.get then
			v1604 = v_u_1602.get("partner_" .. (v_u_1964 == "scrapper" and "rook" or v_u_1964))
		else
			v1604 = nil
		end
		local v1605
		if v_u_171 and v_u_171.PARTNER_TITLES then
			v1605 = v_u_171.PARTNER_TITLES["partner_" .. v_u_1964]
		else
			v1605 = nil
		end
		local v1606 = 5
		local v1607 = "Title and badge"
		local v1608 = "Title %s%s."
		local v1609 = v1605 or v1499 .. " PARTNER"
		local v1610 = tostring(v1609)
		local v1611
		if v1604 then
			local v1612 = v1604.name
			v1611 = ", badge " .. tostring(v1612)
		else
			v1611 = ""
		end
		v1578(v1606, v1607, v1608:format(v1610, v1611))
	end
	local v_u_1614 = ""
	function v_u_105.drawBody() -- name: drawBody
		-- upvalues: (ref) v_u_1964, (ref) v_u_1993, (copy) v_u_102, (copy) v_u_386, (copy) v_u_487, (copy) v_u_485, (copy) v_u_104, (ref) v_u_331, (copy) v_u_139, (copy) v_u_105, (copy) v_u_100, (ref) v_u_360, (ref) v_u_115, (copy) v_u_99, (copy) v_u_1428, (copy) v_u_1132, (copy) v_u_1372, (copy) v_u_1613, (copy) p_u_97, (ref) v_u_1614, (ref) v_u_2033, (copy) v_u_627, (ref) v_u_1986, (copy) v_u_124, (ref) v_u_8, (copy) p_u_98
		local v1615 = v_u_1964 .. "/" .. v_u_1993
		local function v1619() -- name: rebuild
			-- upvalues: (ref) v_u_102, (ref) v_u_386, (ref) v_u_487, (ref) v_u_485, (ref) v_u_104, (ref) v_u_331, (ref) v_u_139, (ref) v_u_105, (ref) v_u_100, (ref) v_u_360, (ref) v_u_115, (ref) v_u_1964, (ref) v_u_1993, (ref) v_u_99, (ref) v_u_1428, (ref) v_u_1132, (ref) v_u_1372, (ref) v_u_1613, (ref) p_u_97
			v_u_102.clear(v_u_386)
			table.clear(v_u_487)
			table.clear(v_u_485)
			if v_u_104 then
				if v_u_331 then
					v_u_102.clear(v_u_331)
				end
				v_u_139.label = nil
				v_u_105.openDetail = nil
				if v_u_104 then
					local v1616 = v_u_331
					if v1616 then
						v1616.Visible = false
						v1616.Size = UDim2.new(0, 1, 0, v_u_100.touch(40))
					end
					v_u_360.Size = UDim2.new(1, -0, 0, v_u_100.touch(40))
				end
			end
			if v_u_115 and v_u_1964 == "gunsmith" then
				v_u_1993 = v_u_115.validSub(v_u_1993)
				if v_u_1993 == "craft" then
					v_u_115.drawCraft(v_u_386)
					return
				elseif v_u_1993 == "services" then
					v_u_115.drawServices(v_u_386)
					return
				elseif v_u_1993 == "locked" then
					v_u_115.drawLocked(v_u_386)
					return
				else
					local v1617 = v_u_115.trustBanner(v_u_386)
					if v1617 > 0 then
						v_u_1428((v_u_99.new("Frame", {
							["Name"] = "TasksInner",
							["BackgroundTransparency"] = 1,
							["Position"] = nil,
							["Size"] = nil,
							["Position"] = UDim2.fromOffset(0, v1617),
							["Size"] = UDim2.new(1, 0, 1, -v1617)
						}, v_u_386)))
					else
						v_u_1428()
					end
				end
			elseif v_u_1993 == "buy" then
				v_u_1132()
				return
			elseif v_u_1993 == "sell" then
				v_u_1372()
				return
			elseif v_u_1993 == "partner" then
				v_u_1613()
				return
			elseif v_u_1993 == "contracts" then
				local function v1618()
					-- upvalues: (ref) p_u_97, (ref) v_u_386, (ref) v_u_1964, (ref) v_u_105
					p_u_97.cctx.lib.MenuContracts.draw(p_u_97, v_u_386, v_u_1964, v_u_105)
				end
				pcall(v1618)
			else
				v_u_1428()
			end
		end
		if v1615 == v_u_1614 and v_u_2033 then
			v_u_2033 = false
			v1619()
			v_u_627()
		elseif v1615 == v_u_1614 then
			v_u_99.keepScroll(v_u_386, v1619)
		else
			v_u_1614 = v1615
			v_u_2033 = false
			v_u_1986 = false
			table.clear(v_u_124)
			v1619()
		end
		local v1620 = v_u_1964 .. "/" .. v_u_1993
		local v1621 = v_u_8[v1620]
		if not v1621 then
			v1621 = {
				["cat"] = "all",
				["cal"] = nil
			}
			v_u_8[v1620] = v1621
		end
		p_u_98:SetAttribute("TraderFilter", ("%s/%s %s%s"):format(v_u_1964, v_u_1993, v1621.cat, not v1621.cal and "" or ":" .. v1621.cal))
	end
	function v_u_105.draw() -- name: draw
		-- upvalues: (ref) v_u_1964, (ref) v_u_115, (copy) v_u_112, (ref) v_u_1993, (ref) v_u_361, (copy) v_u_166, (copy) v_u_156, (copy) v_u_358, (ref) v_u_359, (copy) v_u_172, (copy) v_u_101, (ref) v_u_170, (copy) v_u_103, (copy) v_u_145, (copy) v_u_102, (copy) v_u_99, (ref) v_u_3, (copy) p_u_97, (ref) v_u_122, (copy) v_u_1442, (ref) v_u_318, (copy) v_u_104, (copy) v_u_317, (copy) v_u_323, (copy) v_u_328, (copy) v_u_320, (copy) v_u_321, (copy) v_u_322, (copy) v_u_324, (copy) v_u_325, (copy) v_u_326, (ref) v_u_171, (copy) v_u_329, (ref) v_u_129, (copy) v_u_403, (copy) v_u_105
		if v_u_1964 == "gunsmith" and not (v_u_115 and v_u_115.cardVisible()) then
			v_u_1964 = v_u_112[1]
			v_u_1993 = "buy"
			local v1622 = v_u_361.select
			pcall(v1622, "buy", true)
		end
		local v_u_1623 = v_u_166(v_u_1964)
		v_u_156()
		v_u_358()
		v_u_359()
		for v1624, v1625 in v_u_172 do
			local v1626 = v1624 == v_u_1964
			local v1627 = v1625.stroke
			local v1628
			if v1626 then
				v1628 = v_u_101.accent
			else
				v1628 = v_u_101.line
			end
			v1627.Color = v1628
			local v1629 = v1625.btn
			local v1630
			if v1626 then
				v1630 = v_u_101.accentDeep
			else
				v1630 = v_u_101.raised
			end
			v1629.BackgroundColor3 = v1630
			local v1631
			if v_u_115 and v1624 == "gunsmith" then
				v1631 = v_u_115.traderView()
			else
				local v1632 = v_u_170
				if type(v1632) == "table" then
					local v1633 = v_u_170.traders
					if type(v1633) == "table" then
						v1631 = v_u_170.traders[v1624] or nil
					else
						v1631 = nil
					end
				else
					v1631 = nil
				end
			end
			if v1631 then
				local v1634 = v1625.lvl
				local v1635 = v_u_103 and "LV %d/%d \194\183 REP %s" or "LV %d / %d  \194\183  REP %s"
				local v1636 = v1631.lvl
				local v1637 = tonumber(v1636) or 1
				local v1638 = v1631.maxLevel
				v1634.Text = v1635:format(v1637, tonumber(v1638) or 4, v_u_145(v1631.rep))
				local v1639 = v1631.next
				local v1640
				if type(v1639) == "table" then
					v1640 = v1631.next or nil
				else
					v1640 = nil
				end
				local v1641 = v1625.rep.set
				local v1642 = v1631.frac
				local v1643
				if tonumber(v1642) then
					v1643 = v1631.frac
				elseif v1640 then
					local v1644 = v1640.rep
					if tonumber(v1644) and v1640.rep > 0 then
						local v1645 = v1631.rep
						local v1646 = (tonumber(v1645) or 0) / v1640.rep
						v1643 = math.clamp(v1646, 0, 1)
					else
						v1643 = 1
					end
				else
					v1643 = 1
				end
				v1641(v1643)
			end
			local v1647
			if v_u_102.newOffers and (v1624 ~= v_u_1964 or v_u_1993 ~= "buy") then
				local v1648 = v_u_102.newOffers
				local v1649, _, v1650 = pcall(v1648, v1624)
				v1647 = v1649 and (tonumber(v1650) or 0) or 0
			else
				v1647 = 0
			end
			local v1651 = v1625.btn:FindFirstChild("NewOffers")
			if v1651 then
				v1651:Destroy()
			end
			if v1647 > 0 then
				local v1652 = v_u_99.new("Frame", {
					["Name"] = "NewOffers",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 6,
					["BackgroundColor3"] = v_u_101.info,
					["Position"] = UDim2.fromOffset(4, 4),
					["Size"] = UDim2.fromOffset(v1647 > 9 and 52 or 46, 16)
				}, v1625.btn)
				v_u_99.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["zindex"] = 7,
					["parent"] = v1652,
					["text"] = ("%d NEW"):format(v1647),
					["color"] = v_u_101.bgDeep,
					["size"] = UDim2.fromScale(1, 1)
				})
			end
			v1625.btn:SetAttribute("NewOffers", v1647)
			local v1653 = v_u_170
			local v1654
			if type(v1653) == "table" then
				local v1655 = v_u_170.traders
				if type(v1655) == "table" then
					v1654 = v_u_170.traders[v1624]
				else
					v1654 = nil
				end
			else
				v1654 = nil
			end
			local v1656 = v_u_3.partnerReady
			local v1657 = v_u_170
			local v1658
			if type(v1657) == "table" and v_u_170.partners ~= nil then
				v1658 = v_u_170.partners == true
			else
				local function v1659()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v1660
				v1658, v1660 = pcall(v1659)
				if v1658 then
					v1658 = v1660 == true
				end
			end
			local v1661 = v1656(v1654, v1658)
			local v1662 = v1625.btn:FindFirstChild("PartnerReady")
			if v1661.ready == true then
				if not v1662 then
					v1662 = v_u_99.new("Frame", {
						["Name"] = "PartnerReady",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 6,
						["BackgroundColor3"] = v_u_101.success,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = UDim2.new(1, -8, 0, 8),
						["Size"] = UDim2.fromOffset(12, 12)
					}, v1625.btn)
					v_u_99.new("UICorner", {
						["CornerRadius"] = UDim.new(0.5, 0)
					}, v1662)
					v_u_99.stroke(v1662, v_u_101.bgDeep, 1, 0)
				end
				v1662.Visible = true
			elseif v1662 then
				v1662.Visible = false
			end
			v1625.btn:SetAttribute("PartnerReady", v1661.ready == true)
			local v1663 = v_u_122
			if type(v1663) == "table" then
				local v1664 = v_u_1442(v1624)
				if v1664.ready > 0 then
					v1625.tasks.Text = ("%d ready to hand in"):format(v1664.ready) .. (v1664.available <= 0 and "" or ("  \194\183  %d new"):format(v1664.available))
					v1625.tasks.TextColor3 = v_u_101.success
				elseif v1664.available > 0 then
					v1625.tasks.Text = v1664.available == 1 and "1 task available" or ("%d tasks available"):format(v1664.available)
					v1625.tasks.TextColor3 = v_u_101.info
				elseif v1664.active > 0 then
					v1625.tasks.Text = v1664.active == 1 and "1 task active" or ("%d tasks active"):format(v1664.active)
					v1625.tasks.TextColor3 = v_u_101.accent
				else
					v1625.tasks.Text = "No open tasks"
					v1625.tasks.TextColor3 = v_u_101.muted
				end
			end
			if v1624 ~= "gunsmith" then
				continue
			end
			if v_u_115 then
				v_u_115.paintCard(v1625)
			else
				v1625.btn.Visible = false
			end
		end
		local v1665
		if v_u_115 and v_u_1964 == "gunsmith" then
			v1665 = v_u_115.header()
		else
			v1665 = nil
		end
		local v1666
		if v1665 == nil then
			v1666 = false
		else
			v1666 = v1665.locked == true
		end
		if v_u_318 then
			v_u_318:Destroy()
			v_u_318 = nil
		end
		if not v_u_104 then
			v_u_318 = v_u_102.portrait(v_u_317, v_u_1964, v_u_1623.color or v_u_101.accent, v_u_103 and 68 or 110)
			if v1666 then
				v_u_115.lockPortrait(v_u_318, true)
			end
		end
		v_u_323.Visible = not v1666
		local v1667 = v_u_328
		local v1668 = not v_u_104
		if v1668 then
			v1668 = not v1666
		end
		v1667.Visible = v1668
		local v1669 = v_u_99.setText
		local v1670 = v_u_320
		local v1671
		if v1665 then
			v1671 = v1665.name
		else
			v1671 = v_u_1623.name
		end
		v1669(v1670, v1671)
		if v1666 then
			v_u_99.setText(v_u_321, v1665.title)
			local v1672 = v_u_322
			local v1673 = v1665.quote or ""
			v1672.Text = tostring(v1673)
		else
			v_u_99.setText(v_u_321, (v_u_1623.title or "") .. ((not v_u_1623.location or v_u_1623.location == "") and "" or "  \194\183  " .. v_u_1623.location))
			local v1674 = v_u_322
			local v1675 = v_u_1623.quote or ""
			v1674.Text = "\"" .. tostring(v1675) .. "\""
		end
		local v1676
		if v_u_115 and v_u_1964 == "gunsmith" then
			v1676 = v_u_115.traderView()
		else
			local v1677 = v_u_170
			if type(v1677) == "table" then
				local v1678 = v_u_170.traders
				v1676 = type(v1678) == "table" and v_u_170.traders[v_u_1964] or nil
			else
				v1676 = nil
			end
		end
		if v1676 then
			local v1679 = v_u_324
			local v1680 = v1676.lvl
			v1679.Text = ("LV %d"):format(tonumber(v1680) or 1)
			if v_u_104 and v_u_325.left then
				v_u_325.left.Text = v_u_324.Text
			end
			local v1681 = v1676.next
			local v1682
			if type(v1681) == "table" then
				v1682 = v1676.next or nil
			else
				v1682 = nil
			end
			local v1683 = v_u_325.setRight
			local v1684 = ("REP %s"):format(v_u_145(v1676.rep))
			local v1685
			if v1682 then
				local v1686 = v1682.rep
				local v1687 = (tonumber(v1686) or 0) * 100 + 0.5
				v1685 = (" / %d"):format((math.floor(v1687)))
			else
				v1685 = ""
			end
			v1683(v1684 .. v1685)
			local v1688 = v_u_325.set
			local v1689 = v1676.frac
			local v1690
			if tonumber(v1689) then
				v1690 = v1676.frac
			elseif v1682 then
				local v1691 = v1682.rep
				if tonumber(v1691) and v1682.rep > 0 then
					local v1692 = v1676.rep
					local v1693 = (tonumber(v1692) or 0) / v1682.rep
					v1690 = math.clamp(v1693, 0, 1)
				else
					v1690 = 1
				end
			else
				v1690 = 1
			end
			v1688(v1690)
			local v1694, v1695, v1696, v1697, v1698, v1699, v1700, v1701, v1702, v1703, v1704, v1705, v1706, v1707, v1708, v1709, v1710, v1711, v1712, v1713, v1714, v1715, v1716, v1717
			if v1682 then
				local v1718 = v1682.ep
				if tonumber(v1718) then
					local v1719 = v1676.rep
					local v1720 = tonumber(v1719) or 0
					local v1721 = v1682.rep
					local v1722 = tonumber(v1721) or 0
					local v1723 = v_u_170
					local v1724
					if type(v1723) == "table" then
						local v1725 = v_u_170.ep
						if type(v1725) == "table" then
							local v1726 = v_u_170.ep.have
							v1724 = tonumber(v1726) or 0
						else
							v1724 = 0
						end
					else
						v1724 = 0
					end
					local v1727 = v1682.ep
					local v1728 = tonumber(v1727) or 100
					local v1729 = "#" .. v_u_101.success:ToHex()
					local _ = "#" .. v_u_101.accent:ToHex()
					local v1730 = v_u_1964
					local v1731 = v_u_170
					local v1732
					if type(v1731) == "table" then
						local v1733 = v_u_170.traders
						if type(v1733) == "table" then
							v1732 = v_u_170.traders[v1730]
						else
							v1732 = nil
						end
					else
						v1732 = nil
					end
					local v1734 = v_u_3.partnerReady
					local v1735 = v_u_170
					local v1736
					if type(v1735) == "table" and v_u_170.partners ~= nil then
						v1736 = v_u_170.partners == true
					else
						local function v1737()
							-- upvalues: (ref) p_u_97
							return p_u_97.cctx.config.flag("Partners")
						end
						local v1738
						v1736, v1738 = pcall(v1737)
						if v1736 then
							v1736 = v1738 == true
						end
					end
					local v1739 = v1734(v1732, v1736)
					if v1739.ready == true then
						v_u_326.Text = v_u_3.partnerReadyLine(v1739, v_u_104 or v_u_103, v_u_102.money, v1729)
					else
						local v1740 = v_u_326
						local v1741 = v_u_3.nextPartnerLine
						local v1742 = v1682.lvl
						local v1743 = tonumber(v1742) or 5
						local v1744 = "#" .. v_u_101.success:ToHex()
						local v1745 = "#" .. v_u_101.accent:ToHex()
						local v1746 = v_u_145(v1720)
						local v1747 = v1722 * 100 + 0.5
						local v1748 = math.floor(v1747)
						local v1749 = v1722 <= v1720 + 1e-6
						local v1750 = math.floor(v1724)
						local v1751 = math.max(0, v1750)
						local v1752 = math.floor(v1728)
						local v1753 = math.max(0, v1752)
						v1740.Text = v1741(v1743, v1744, v1745, v1746, v1748, v1749, math.min(v1751, v1753), v1728, v1728 <= v1724, v1739.price, v_u_104 or v_u_103, v_u_102.money)
					end
				elseif v1682 then
					v1694 = v1676.rep
					v1695 = tonumber(v1694) or 0
					v1696 = v1682.rep
					v1697 = tonumber(v1696) or 0
					v1698 = p_u_97.profile
					if type(v1698) == "table" then
						v1699 = p_u_97.profile.stats
						v1700 = type(v1699) == "table" and (p_u_97.profile.stats or {}) or {}
					else
						v1700 = {}
					end
					v1701 = v1700.extracts
					v1702 = tonumber(v1701) or 0
					v1703 = v1682.extracts
					v1704 = tonumber(v1703) or 0
					v1705 = "#" .. v_u_101.success:ToHex()
					v1706 = "#" .. v_u_101.accent:ToHex()
					v1707 = v_u_326
					v1708 = "Next LV %d:  rep <font color=\"%s\">%s / %d</font>  \194\183  extracts <font color=\"%s\">%d / %d</font>"
					v1709 = v1682.lvl
					v1710 = tonumber(v1709)
					if not v1710 then
						v1711 = v1676.lvl
						v1710 = (tonumber(v1711) or 1) + 1
					end
					if v1697 <= v1695 + 1e-6 then
						v1712 = v1705
					else
						v1712 = v1706
					end
					v1713 = v_u_145(v1695)
					v1714 = v1697 * 100 + 0.5
					v1715 = math.floor(v1714)
					if v1704 <= v1702 then
						v1706 = v1705
					end
					v1707.Text = v1708:format(v1710, v1712, v1713, v1715, v1706, v1702, v1704)
				else
					v1716 = v_u_326
					v1717 = v1676.lvl
					v1716.Text = (tonumber(v1717) or 1) >= 5 and "Partner  \194\183  maximum level" or "Maximum level reached"
				end
			elseif v1682 then
				v1694 = v1676.rep
				v1695 = tonumber(v1694) or 0
				v1696 = v1682.rep
				v1697 = tonumber(v1696) or 0
				v1698 = p_u_97.profile
				if type(v1698) == "table" then
					v1699 = p_u_97.profile.stats
					v1700 = type(v1699) == "table" and (p_u_97.profile.stats or {}) or {}
				else
					v1700 = {}
				end
				v1701 = v1700.extracts
				v1702 = tonumber(v1701) or 0
				v1703 = v1682.extracts
				v1704 = tonumber(v1703) or 0
				v1705 = "#" .. v_u_101.success:ToHex()
				v1706 = "#" .. v_u_101.accent:ToHex()
				v1707 = v_u_326
				v1708 = "Next LV %d:  rep <font color=\"%s\">%s / %d</font>  \194\183  extracts <font color=\"%s\">%d / %d</font>"
				v1709 = v1682.lvl
				v1710 = tonumber(v1709)
				if not v1710 then
					v1711 = v1676.lvl
					v1710 = (tonumber(v1711) or 1) + 1
				end
				if v1697 <= v1695 + 1e-6 then
					v1712 = v1705
				else
					v1712 = v1706
				end
				v1713 = v_u_145(v1695)
				v1714 = v1697 * 100 + 0.5
				v1715 = math.floor(v1714)
				if v1704 <= v1702 then
					v1706 = v1705
				end
				v1707.Text = v1708:format(v1710, v1712, v1713, v1715, v1706, v1702, v1704)
			else
				v1716 = v_u_326
				v1717 = v1676.lvl
				v1716.Text = (tonumber(v1717) or 1) >= 5 and "Partner  \194\183  maximum level" or "Maximum level reached"
			end
		end
		local function v_u_1770() -- name: repNumbers
			-- upvalues: (ref) v_u_171, (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (ref) v_u_1442, (ref) v_u_102, (ref) v_u_3
			local v1754
			if v_u_171 then
				local v1755 = v_u_171.REP_PER_DOLLAR
				if tonumber(v1755) and v_u_171.REP_PER_DOLLAR > 0 then
					local v1756 = 0.01 / v_u_171.REP_PER_DOLLAR + 0.5
					v1754 = math.floor(v1756)
				else
					v1754 = 2000
				end
			else
				v1754 = 2000
			end
			local v1757
			if v_u_171 then
				local v1758 = v_u_171.REP_TRADE_MAX
				if tonumber(v1758) then
					local v1759 = v_u_171.REP_TRADE_MAX * 100 + 0.5
					v1757 = math.floor(v1759)
				else
					v1757 = 30
				end
			else
				v1757 = 30
			end
			local v1760
			if v_u_115 and v_u_1964 == "gunsmith" then
				v1760 = v_u_115.traderView()
			else
				local v1761 = v_u_170
				if type(v1761) == "table" then
					local v1762 = v_u_170.traders
					v1760 = type(v1762) == "table" and v_u_170.traders[v_u_1964] or nil
				else
					v1760 = nil
				end
			end
			local v1763
			if v1760 then
				local v1764 = v1760.tradeRep
				if tonumber(v1764) then
					local v1765 = v1760.tradeRep * 100 + 0.0001
					v1763 = math.floor(v1765)
				else
					v1763 = 0
				end
			else
				v1763 = 0
			end
			local v1766 = v_u_1442(v_u_1964)
			local v1767 = v_u_102.money(v1754)
			local v1768, v1769 = v_u_3.gainRepParts(v1766.open, v1766.rep, v1767, v1763, v1757)
			if v_u_115 and v_u_1964 == "gunsmith" then
				v1768, v1769 = v_u_115.repParts(v1766.open, v1766.rep)
			end
			return v1768, v1769, v1767, v1757
		end
		local v1771, v1772 = v_u_1770()
		local v1773 = v_u_115
		if v1773 then
			v1773 = v_u_1964 == "gunsmith"
		end
		local v1774 = not v1773
		if v1774 then
			local v1775 = v_u_3.extractRepOpen
			local v1776
			if v_u_115 and v_u_1964 == "gunsmith" then
				v1776 = v_u_115.traderView()
			else
				local v1777 = v_u_170
				if type(v1777) == "table" then
					local v1778 = v_u_170.traders
					v1776 = type(v1778) == "table" and v_u_170.traders[v_u_1964] or nil
				else
					v1776 = nil
				end
			end
			local v1779 = v_u_170
			local v1780
			if type(v1779) == "table" and v_u_170.partners ~= nil then
				v1780 = v_u_170.partners == true
			else
				local function v1781()
					-- upvalues: (ref) p_u_97
					return p_u_97.cctx.config.flag("Partners")
				end
				local v1782
				v1780, v1782 = pcall(v1781)
				if v1780 then
					v1780 = v1782 == true
				end
			end
			local v1783
			if v_u_171 then
				v1783 = v_u_171.REP_MAX
			else
				v1783 = nil
			end
			v1774 = v1775(v1776, v1780, v1783)
		end
		v_u_329.Text = ("<font color=\"%s\">GAIN REP</font>   %s   \194\183   %s%s"):format("#" .. v_u_101.info:ToHex(), "Tasks: " .. v1771, (v_u_115 and v_u_1964 == "gunsmith" and "Crafting: " or "Trading: ") .. v1772, v1774 and "   \194\183   Extracts: +1 to +3 per raid" or "")
		local function v_u_1822(p1784) -- name: gainRepTip
			-- upvalues: (copy) v_u_1770, (ref) v_u_115, (ref) v_u_1964, (ref) v_u_3, (ref) v_u_170, (ref) p_u_97, (ref) v_u_171, (ref) v_u_104, (ref) v_u_1442
			local v1785, v1786, v1787, v_u_1788 = v_u_1770()
			local v_u_1789
			if v_u_115 == nil then
				v_u_1789 = false
			else
				v_u_1789 = v_u_1964 == "gunsmith"
			end
			local v_u_1790
			if v_u_1789 then
				local v1791 = v_u_115.gainRepBody
				local v1792 = p1784.name
				v_u_1790 = v1791((tostring(v1792)))
			else
				local v1793 = v_u_3.gainRepBody
				local v1794 = p1784.name
				local v1795 = tostring(v1794)
				local v1796 = v_u_3.extractRepOpen
				local v1797
				if v_u_115 and v_u_1964 == "gunsmith" then
					v1797 = v_u_115.traderView()
				else
					local v1798 = v_u_170
					if type(v1798) == "table" then
						local v1799 = v_u_170.traders
						v1797 = type(v1799) == "table" and v_u_170.traders[v_u_1964] or nil
					else
						v1797 = nil
					end
				end
				local v1800 = v_u_170
				local v1801
				if type(v1800) == "table" and v_u_170.partners ~= nil then
					v1801 = v_u_170.partners == true
				else
					local function v1802()
						-- upvalues: (ref) p_u_97
						return p_u_97.cctx.config.flag("Partners")
					end
					local v1803
					v1801, v1803 = pcall(v1802)
					if v1801 then
						v1801 = v1803 == true
					end
				end
				local v1804
				if v_u_171 then
					v1804 = v_u_171.REP_MAX
				else
					v1804 = nil
				end
				v_u_1790 = v1793(v1795, v1787, v_u_1788, v1796(v1797, v1801, v1804))
			end
			if v_u_104 then
				v_u_1790 = v_u_1790 .. "\n\nTasks: " .. v1785 .. (v_u_1789 and "\nCrafting: " or "\nTrading: ") .. v1786
			end
			local function v1821()
				-- upvalues: (ref) p_u_97, (ref) v_u_115, (ref) v_u_1964, (ref) v_u_170, (copy) v_u_1789, (copy) v_u_1788, (ref) v_u_1442, (ref) v_u_1790
				local v1805 = p_u_97.cctx.shared.TraderHints
				local v1806
				if v_u_115 and v_u_1964 == "gunsmith" then
					v1806 = v_u_115.traderView()
				else
					local v1807 = v_u_170
					if type(v1807) == "table" then
						local v1808 = v_u_170.traders
						v1806 = type(v1808) == "table" and v_u_170.traders[v_u_1964] or nil
					else
						v1806 = nil
					end
				end
				local v1809
				if v1806 then
					local v1810 = v1806.next
					if type(v1810) == "table" then
						v1809 = v1806.next or nil
					else
						v1809 = nil
					end
				else
					v1809 = nil
				end
				if v1805 and v1809 then
					local v1811 = v1809.ep
					if not (tonumber(v1811) or v_u_1789) then
						local v1812 = p_u_97.profile
						local v1813
						if type(v1812) == "table" then
							local v1814 = p_u_97.profile.stats
							v1813 = type(v1814) == "table" and (p_u_97.profile.stats or {}) or {}
						else
							v1813 = {}
						end
						local v1815 = v1806.tradeMax
						local v1816 = tonumber(v1815) or v_u_1788 / 100
						local v1817 = v1806.tradeRep
						local v1818 = (v1816 - (tonumber(v1817) or 0)) * 100
						local v1819 = math.max(0, v1818)
						local v1820 = v1805.missingText(v1806.rep, v1809.rep, v1813.extracts, v1809.extracts, v_u_1442(v_u_1964).open, v1819, v1809.lvl)
						if v1820 ~= "" then
							v_u_1790 = v_u_1790 .. "\n\n" .. v1820
						end
					end
				end
			end
			pcall(v1821)
			return {
				["title"] = "GAIN REP",
				["body"] = nil,
				["body"] = v_u_1790
			}
		end
		if not v_u_129 then
			v_u_129 = true
			if v_u_104 then
				v_u_99.tooltip(v_u_320, function()
					-- upvalues: (ref) v_u_166, (ref) v_u_1964
					local v1823 = v_u_166(v_u_1964)
					return {
						["title"] = v1823.name,
						["body"] = v1823.bio
					}
				end)
				v_u_99.tooltip(v_u_323, function()
					-- upvalues: (copy) v_u_1822, (ref) v_u_166, (ref) v_u_1964
					return v_u_1822((v_u_166(v_u_1964)))
				end)
			else
				v_u_99.tooltip(v_u_328, function()
					-- upvalues: (copy) v_u_1822, (ref) v_u_166, (ref) v_u_1964
					return v_u_1822((v_u_166(v_u_1964)))
				end)
			end
		end
		if not v_u_104 then
			v_u_99.tooltip(v_u_318, function()
				-- upvalues: (copy) v_u_1623
				return {
					["title"] = v_u_1623.name,
					["body"] = v_u_1623.bio
				}
			end)
		end
		v_u_403()
		v_u_105.drawBody()
	end
	local v_u_1824 = {}
	local function v_u_1840() -- name: phoneHoldTips
		-- upvalues: (copy) v_u_104, (copy) p_u_97, (copy) p_u_98, (copy) v_u_1824, (copy) v_u_323, (ref) v_u_1993, (ref) v_u_120, (ref) v_u_360
		if v_u_104 then
			local v_u_1825 = nil
			local function v1826()
				-- upvalues: (ref) v_u_1825, (ref) p_u_97
				v_u_1825 = p_u_97.cctx.lib.MenuTipOnce
			end
			pcall(v1826)
			if v_u_1825 then
				local v1827 = v_u_1825.show
				if type(v1827) == "function" then
					local function v1837(p1828, p1829, p_u_1830) -- name: start
						-- upvalues: (ref) v_u_1825, (ref) p_u_97, (ref) p_u_98, (ref) v_u_1824
						local v1831 = v_u_1825.show
						local v1832 = p_u_97
						local v1834 = {
							["host"] = p_u_98,
							["target"] = p1829,
							["active"] = function() -- name: active
								-- upvalues: (ref) p_u_98, (copy) p_u_1830
								local v1833 = p_u_98.Parent ~= nil and p_u_98.Visible
								if v1833 then
									v1833 = p_u_1830()
								end
								return v1833
							end,
							["sides"] = { "below", "left" }
						}
						local v1835, v1836 = pcall(v1831, v1832, p1828, v1834)
						if v1835 and v1836 then
							v_u_1824[p1828] = v1836
						end
					end
					v1837("trdrep", function()
						-- upvalues: (ref) v_u_323
						return v_u_323
					end, function()
						-- upvalues: (ref) v_u_1993, (ref) v_u_120
						local v1838
						if v_u_1993 == "buy" then
							v1838 = not v_u_120
						else
							v1838 = false
						end
						return v1838
					end)
					v1837("trdsell", function()
						-- upvalues: (ref) v_u_360
						local v1839 = v_u_360:FindFirstChild("Tab_sell", true)
						if v1839 and v1839:IsA("GuiObject") then
							return v1839
						else
							return nil
						end
					end, function()
						-- upvalues: (ref) v_u_1993
						return v_u_1993 == "sell"
					end)
					return
				end
			end
		end
	end
	local function v_u_1845(p1841) -- name: dropHoldTips
		-- upvalues: (copy) v_u_1824
		for v1842, v1843 in v_u_1824 do
			local v1844
			if p1841 then
				v1844 = v1843.detach
			else
				v1844 = v1843.dismiss
			end
			pcall(v1844, "left")
			v_u_1824[v1842] = nil
		end
	end
	function v_u_105.reload() -- name: reload
		-- upvalues: (ref) v_u_120, (ref) v_u_170, (copy) p_u_97, (ref) v_u_122, (ref) v_u_115, (copy) p_u_98, (copy) v_u_105
		v_u_120 = false
		local v_u_1846 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_170, (ref) p_u_97, (copy) v_u_1846, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (ref) p_u_98, (ref) v_u_105
			v_u_170 = p_u_97.fetch("traders", nil, v_u_1846 and 0 or 20)
			v_u_120 = v_u_170 == nil
			v_u_122 = p_u_97.fetch("tasks", nil, 20)
			if v_u_115 then
				v_u_115.setView(p_u_97.fetch("gunsmith", nil, v_u_1846 and 0 or 2))
			end
			if p_u_98.Parent then
				v_u_105.draw()
			end
		end)
		v_u_105.draw()
	end
	function v_u_105.show() -- name: show
		-- upvalues: (ref) v_u_170, (copy) p_u_97, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (copy) p_u_98, (copy) v_u_105, (copy) v_u_1840
		local v_u_1847 = false
		task.spawn(function()
			-- upvalues: (ref) v_u_170, (ref) p_u_97, (copy) v_u_1847, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (ref) p_u_98, (ref) v_u_105
			v_u_170 = p_u_97.fetch("traders", nil, v_u_1847 and 0 or 20)
			v_u_120 = v_u_170 == nil
			v_u_122 = p_u_97.fetch("tasks", nil, 20)
			if v_u_115 then
				v_u_115.setView(p_u_97.fetch("gunsmith", nil, v_u_1847 and 0 or 2))
			end
			if p_u_98.Parent then
				v_u_105.draw()
			end
		end)
		v_u_105.draw()
		v_u_1840()
	end
	function v_u_105.hide() -- name: hide
		-- upvalues: (copy) v_u_124, (copy) v_u_1845
		table.clear(v_u_124)
		v_u_1845(false)
	end
	function v_u_105.refresh(p1848, p1849) -- name: refresh
		-- upvalues: (ref) v_u_115, (copy) v_u_672, (ref) v_u_175, (copy) p_u_97, (ref) v_u_170, (ref) v_u_120, (ref) v_u_122, (copy) p_u_98, (copy) v_u_105
		if p1848 == "result" and (type(p1849) == "table" and (p1849.op == "buy" or (p1849.op == "sell" or (p1849.op == "taskAccept" or (p1849.op == "taskHandIn" or (p1849.op == "traderPartner" or (p1849.op == "traderStamm" or (p1849.op == "gsCraft" or (p1849.op == "gsSwap" or (p1849.op == "gsStrip" or (p1849.op == "twinCouple" or p1849.op == "twinSplit"))))))))))) then
			if v_u_115 then
				v_u_115.onResult(p1849)
			end
			if p1849.op == "buy" then
				v_u_672.buy = nil
			elseif p1849.op == "traderPartner" then
				v_u_175 = false
			elseif p1849.op == "sell" and p1849.ok == false then
				table.clear(v_u_672.sold)
			end
			p_u_97.invalidate("traders")
			p_u_97.invalidate("tasks")
			local v_u_1850 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_170, (ref) p_u_97, (copy) v_u_1850, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (ref) p_u_98, (ref) v_u_105
				v_u_170 = p_u_97.fetch("traders", nil, v_u_1850 and 0 or 20)
				v_u_120 = v_u_170 == nil
				v_u_122 = p_u_97.fetch("tasks", nil, 20)
				if v_u_115 then
					v_u_115.setView(p_u_97.fetch("gunsmith", nil, v_u_1850 and 0 or 2))
				end
				if p_u_98.Parent then
					v_u_105.draw()
				end
			end)
		elseif p1848 == "profile" then
			local v_u_1851 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_170, (ref) p_u_97, (copy) v_u_1851, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (ref) p_u_98, (ref) v_u_105
				v_u_170 = p_u_97.fetch("traders", nil, v_u_1851 and 0 or 20)
				v_u_120 = v_u_170 == nil
				v_u_122 = p_u_97.fetch("tasks", nil, 20)
				if v_u_115 then
					v_u_115.setView(p_u_97.fetch("gunsmith", nil, v_u_1851 and 0 or 2))
				end
				if p_u_98.Parent then
					v_u_105.draw()
				end
			end)
		end
	end
	function v_u_105.state() -- name: state
		-- upvalues: (ref) v_u_1964, (ref) v_u_1993
		return v_u_1964, v_u_1993
	end
	function v_u_105.tick() -- name: tick
		-- upvalues: (copy) v_u_139, (copy) v_u_99, (copy) p_u_97, (ref) v_u_170, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (copy) p_u_98, (copy) v_u_105, (ref) v_u_361, (ref) v_u_1993, (ref) v_u_1964, (ref) v_u_360, (copy) v_u_387, (copy) v_u_125, (copy) v_u_1489, (ref) v_u_174, (copy) v_u_386, (ref) v_u_1967, (ref) v_u_670, (ref) v_u_671, (copy) v_u_104, (ref) v_u_128, (ref) v_u_135, (ref) v_u_137, (ref) v_u_136, (ref) v_u_127, (ref) v_u_1977, (copy) v_u_131, (ref) v_u_1965, (copy) v_u_619, (ref) v_u_8, (copy) v_u_100, (ref) v_u_2033, (ref) v_u_1986, (copy) v_u_113, (ref) v_u_428, (ref) v_u_1966
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v1941, v1942, v1943, v1944, v1945, v1946, v1947, v1948, v1949, v1950, v1951, v1952, v1953, v1954, v1955, v1956, v1957, v1958, v1959, v1960, v1961, v1962, v1963, v1968, v1969, v1970, v1971, v1972, v1973, v1974, v1975, v1976, v1978, v1979, v1980, v1981, v1982, v1983, v1984, v1985, v1987, v1988, v1989, v1990, v1991, v1992, v1994, v1995, v1996, v1997, v1998, v1999, v2000, v2001, v2002, v2003, v2004, v2005, v2006, v2007, v2008, v2009, v2010, v2011, v2012, v2013, v2014, v2015, v2016, v2017, v2018, v2019, v2020, v2021, v2022, v2023, v2024, v2025, v2026, v2027, v2028, v_u_2029, v2030, v2031, v2032, v2034, v2035, v2036, v2037
		local v1941, v1942, v1943, v1944, v1945, v1946, v1947, v1948, v1949, v1950, v1951, v1952, v1953, v1954, v1955, v1956, v1957, v1958, v1959, v1960, v1961, v1962, v1963, v_u_1964, v_u_1965, v_u_1966, v_u_1967, v1968, v1969, v1970, v1971, v1972, v1973, v1974, v1975, v1976, v_u_1977, v1978, v1979, v1980, v1981, v1982, v1983, v1984, v1985, v_u_1986, v1987, v1988, v1989, v1990, v1991, v1992, v_u_1993, v1994, v1995, v1996, v1997, v1998, v1999, v2000, v2001, v2002, v2003, v2004, v2005, v2006, v2007, v2008, v2009, v2010, v2011, v2012, v2013, v2014, v2015, v2016, v2017, v2018, v2019, v2020, v2021, v2022, v2023, v2024, v2025, v2026, v2027, v2028, v_u_2029, v2030, v2031, v2032, v_u_2033, v2034, v2035, v2036, v2037
		local v2038 = 43
		while true do
			if v2038 == 1 then
				return
			elseif v2038 == 2 then
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 3 then
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 4 then
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 5 then
				v2014:SetAttribute("DevTraderAct", nil)
				if v_u_115 == nil then
					v1942 = false
				else
					v1942 = v_u_115.devAct(v2015)
				end
				if v1942 then
					v1994 = nil
				else
					v1994 = string.match(v2015, "^open:(.+)$")
				end
				v2006 = string.match(v2015, "^pick:(.+)$")
				v2007 = string.match(v2015, "^sell:(.+)$")
				v2019 = string.match(v2015, "^stamm:(%w+)$")
				v2020 = string.match(v2015, "^subtab:(%w+)$")
				v1983 = string.match(v2015, "^gstab:(%w+)$")
				if v1942 then
					v2038 = 2
				else
					v2038 = 6
				end
			elseif v2038 == 6 then
				if v2020 then
					v2038 = 7
				else
					v2038 = 8
				end
			elseif v2038 == 7 then
				v2032 = v_u_361.select
				pcall(v2032, v2020)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 8 then
				if v1983 then
					v2038 = 9
				else
					v2038 = 10
				end
			elseif v2038 == 9 then
				v_u_1993 = v1983
				v_u_105.drawBody()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 10 then
				if v2015 == "substate" then
					v2038 = 11
				else
					v2038 = 12
				end
			elseif v2038 == 11 then
				v1984 = v_u_1964
				v1985 = v_u_1993
				v1990 = v_u_361.get
				v1991 = p_u_98
				v2014:SetAttribute("DevTraderSubState", ("%s sub=%s hi=%s rowShown=%d gsShown=%d body=%s"):format(v1984, v1985, tostring(v1990()), v_u_360.Visible and 1 or 0, v_u_387.Visible and 1 or 0, (tostring(v1991:GetAttribute("TraderFilter")))))
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 12 then
				if v1994 and v_u_125[v1994] then
					v2038 = 14
				else
					v2038 = 13
				end
			elseif v2038 == 13 then
				if v2019 then
					v2038 = 15
				else
					v2038 = 16
				end
			elseif v2038 == 14 then
				v_u_125[v1994]()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 15 then
				v_u_105.pickRegular(v2019)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 16 then
				if v2015 == "partner" and v_u_105.partnerAsk then
					v2038 = 18
				else
					v2038 = 17
				end
			elseif v2038 == 17 then
				if v2015 == "partnerconfirm" and v_u_1993 == "partner" then
					v2038 = 20
				else
					v2038 = 19
				end
			elseif v2038 == 18 then
				v_u_105.partnerAsk()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 19 then
				if v2015 == "partnerpay" and v_u_105.partnerPay then
					v2038 = 24
				else
					v2038 = 23
				end
			elseif v2038 == 20 then
				if v_u_115 and v_u_1964 == "gunsmith" then
					v1992 = v_u_115.traderView()
				else
					v2037 = v_u_170
					if type(v2037) == "table" then
						v2030 = v_u_170.traders
						v1992 = type(v2030) == "table" and v_u_170.traders[v_u_1964] or nil
					else
						v1992 = nil
					end
				end
				v1981 = v_u_1489
				v1982 = v1992 and v1992.partner
				if v1982 then
					v1982 = v1992.partner.price
				end
				v2031 = tonumber(v1982) or 0
				v1981((math.floor(v2031)))
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 21 then
				if v2015 == "close" and v_u_105.sellModal then
					v_u_105.sellModal.close()
				elseif string.match(v2015, "^filter:") then
					v1958, v1959 = string.match(v2015, "^filter:(%w+):?(%w*)$")
					if v1958 == "next" or v1958 == "prev" then
						v_u_619(v1958 == "next" and 1 or -1)
					elseif v1958 then
						if v1959 == "" then
							v1959 = nil
						end
						v2008 = v_u_1964 .. "/" .. v_u_1993
						v1960 = v_u_8[v2008]
						if not v1960 then
							v1960 = {
								["cat"] = "all",
								["cal"] = nil
							}
							v_u_8[v2008] = v1960
						end
						if v1960.cat ~= v1958 or v1960.cal ~= v1959 then
							v1960.cat = v1958
							if v1958 ~= "ammo" then
								v1959 = nil
							end
							v1960.cal = v1959
							v_u_99.sound(v_u_100.sounds.tab)
							v_u_2033 = true
							v_u_1986 = false
							v_u_105.drawBody()
						end
					end
				elseif v2015 == "filterdump" then
					v1987 = v_u_386:FindFirstChild("Offers", true) or v_u_386:FindFirstChild("Rows", true)
					v2034 = v_u_386:FindFirstChild("Filters", true)
					v1988 = v_u_386:FindFirstChild("Calibres", true)
					v1989 = {}
					if v_u_115 and v_u_1964 == "gunsmith" then
						v2035 = v_u_115.traderView()
					else
						v2036 = v_u_170
						if type(v2036) == "table" then
							v1961 = v_u_170.traders
							v2035 = type(v1961) == "table" and v_u_170.traders[v_u_1964] or nil
						else
							v2035 = nil
						end
					end
					v2009 = {}
					for v2061, v2062 in v2035 and v2035.offers or {} do
						v2010 = v2062.key
						v2009[tostring(v2010)] = v2062
					end
					v2011 = p_u_97.profile
					if type(v2011) == "table" then
						v2012 = v2011.inv
						if type(v2012) == "table" then
							v1962 = v2011.inv.containers
							if type(v1962) == "table" then
								v1963 = v2011.inv.containers.stash or nil
							else
								v1963 = nil
							end
						else
							v1963 = nil
						end
					else
						v1963 = nil
					end
					v2016 = {}
					if type(v1963) == "table" then
						v1995 = v1963.items
						v1943 = type(v1995) == "table" and (v1963.items or {}) or {}
					else
						v1943 = {}
					end
					for v2063, v2064 in v1943 do
						v1996 = v2064.uid
						v2016[tostring(v1996)] = v2064
					end
					for v2065, v2066 in v1987 and v1987:GetChildren() or {} do
						if not v2066:IsA("TextButton") then
							continue
						end
						v1944 = v2009[v2066.Name]
						v1945 = string.match(v2066.Name, "^Row_(.+)$")
						if v1944 then
							v2005 = v1944.items
							if type(v2005) == "table" and #v1944.items > 1 then
								v1946 = {}
								for v2067, v2068 in v1944.items do
									v1947 = v2068.id
									v1968 = tostring(v1947)
									table.insert(v1946, v1968)
								end
								v2021 = table.concat
								table.insert(v1989, v2021(v1946, "+"))
							else
								v2022 = v1944.id
								if not v2022 then
									v1969 = v1944.items
									v2022 = type(v1969) == "table" and v1944.items[1] and (v1944.items[1].id or "mat_scrap") or "mat_scrap"
								end
								table.insert(v1989, v2022)
							end
						else
							if not (v1945 and v2016[v1945]) then
								continue
							end
							v2023 = v2016[v1945].id
							v1970 = tostring(v2023)
							table.insert(v1989, v1970)
						end
					end
					v1949 = {}
					for v2069, v2070 in v1988 and v1988:GetChildren() or {} do
						if not v2070:IsA("TextButton") then
							continue
						end
						v1971 = v2070.Name
						v1972 = string.sub(v1971, 7)
						v1997 = tostring(v2070:GetAttribute("Count"))
						v1950 = v2070:GetAttribute("On") and "*" or ""
						table.insert(v1949, ("%s=%s%s"):format(v1972, v1997, v1950))
					end
					v1998 = v_u_1964 .. "/" .. v_u_1993
					v1999 = v_u_8[v1998]
					if not v1999 then
						v1999 = {
							["cat"] = "all",
							["cal"] = nil
						}
						v_u_8[v1998] = v1999
					end
					v2000 = v_u_1964
					v1951 = v_u_1993
					v1952 = v1999.cat
					v2001 = not v1999.cal and "" or ":" .. v1999.cal
					v1953 = #v1989
					v1954 = v2034 and v2034:GetAttribute("Counts") or "-"
					v2014:SetAttribute("DevTraderFilterDump", ("%s/%s %s%s shown=%d counts=%s cals=%s ids=%s"):format(v2000, v1951, v1952, v2001, v1953, tostring(v1954), table.concat(v1949, ","), table.concat(v1989, ",")))
				end
				v2038 = 3
			elseif v2038 == 22 then
				if v2015 == "close" and v_u_105.sellModal then
					v_u_105.sellModal.close()
				elseif string.match(v2015, "^filter:") then
					v1958, v1959 = string.match(v2015, "^filter:(%w+):?(%w*)$")
					if v1958 == "next" or v1958 == "prev" then
						v_u_619(v1958 == "next" and 1 or -1)
					elseif v1958 then
						if v1959 == "" then
							v1959 = nil
						end
						v2008 = v_u_1964 .. "/" .. v_u_1993
						v1960 = v_u_8[v2008]
						if not v1960 then
							v1960 = {
								["cat"] = "all",
								["cal"] = nil
							}
							v_u_8[v2008] = v1960
						end
						if v1960.cat ~= v1958 or v1960.cal ~= v1959 then
							v1960.cat = v1958
							if v1958 ~= "ammo" then
								v1959 = nil
							end
							v1960.cal = v1959
							v_u_99.sound(v_u_100.sounds.tab)
							v_u_2033 = true
							v_u_1986 = false
							v_u_105.drawBody()
						end
					end
				elseif v2015 == "filterdump" then
					v1987 = v_u_386:FindFirstChild("Offers", true) or v_u_386:FindFirstChild("Rows", true)
					v2034 = v_u_386:FindFirstChild("Filters", true)
					v1988 = v_u_386:FindFirstChild("Calibres", true)
					v1989 = {}
					if v_u_115 and v_u_1964 == "gunsmith" then
						v2035 = v_u_115.traderView()
					else
						v2036 = v_u_170
						if type(v2036) == "table" then
							v1961 = v_u_170.traders
							v2035 = type(v1961) == "table" and v_u_170.traders[v_u_1964] or nil
						else
							v2035 = nil
						end
					end
					v2009 = {}
					for v2061, v2062 in v2035 and v2035.offers or {} do
						v2010 = v2062.key
						v2009[tostring(v2010)] = v2062
					end
					v2011 = p_u_97.profile
					if type(v2011) == "table" then
						v2012 = v2011.inv
						if type(v2012) == "table" then
							v1962 = v2011.inv.containers
							if type(v1962) == "table" then
								v1963 = v2011.inv.containers.stash or nil
							else
								v1963 = nil
							end
						else
							v1963 = nil
						end
					else
						v1963 = nil
					end
					v2016 = {}
					if type(v1963) == "table" then
						v1995 = v1963.items
						v1943 = type(v1995) == "table" and (v1963.items or {}) or {}
					else
						v1943 = {}
					end
					for v2063, v2064 in v1943 do
						v1996 = v2064.uid
						v2016[tostring(v1996)] = v2064
					end
					for v2065, v2066 in v1987 and v1987:GetChildren() or {} do
						if not v2066:IsA("TextButton") then
							continue
						end
						v1944 = v2009[v2066.Name]
						v1945 = string.match(v2066.Name, "^Row_(.+)$")
						if v1944 then
							v2005 = v1944.items
							if type(v2005) == "table" and #v1944.items > 1 then
								v1946 = {}
								for v2067, v2068 in v1944.items do
									v1947 = v2068.id
									v1968 = tostring(v1947)
									table.insert(v1946, v1968)
								end
								v2021 = table.concat
								table.insert(v1989, v2021(v1946, "+"))
							else
								v2022 = v1944.id
								if not v2022 then
									v1969 = v1944.items
									v2022 = type(v1969) == "table" and v1944.items[1] and (v1944.items[1].id or "mat_scrap") or "mat_scrap"
								end
								table.insert(v1989, v2022)
							end
						else
							if not (v1945 and v2016[v1945]) then
								continue
							end
							v2023 = v2016[v1945].id
							v1970 = tostring(v2023)
							table.insert(v1989, v1970)
						end
					end
					v1949 = {}
					for v2069, v2070 in v1988 and v1988:GetChildren() or {} do
						if not v2070:IsA("TextButton") then
							continue
						end
						v1971 = v2070.Name
						v1972 = string.sub(v1971, 7)
						v1997 = tostring(v2070:GetAttribute("Count"))
						v1950 = v2070:GetAttribute("On") and "*" or ""
						table.insert(v1949, ("%s=%s%s"):format(v1972, v1997, v1950))
					end
					v1998 = v_u_1964 .. "/" .. v_u_1993
					v1999 = v_u_8[v1998]
					if not v1999 then
						v1999 = {
							["cat"] = "all",
							["cal"] = nil
						}
						v_u_8[v1998] = v1999
					end
					v2000 = v_u_1964
					v1951 = v_u_1993
					v1952 = v1999.cat
					v2001 = not v1999.cal and "" or ":" .. v1999.cal
					v1953 = #v1989
					v1954 = v2034 and v2034:GetAttribute("Counts") or "-"
					v2014:SetAttribute("DevTraderFilterDump", ("%s/%s %s%s shown=%d counts=%s cals=%s ids=%s"):format(v2000, v1951, v1952, v2001, v1953, tostring(v1954), table.concat(v1949, ","), table.concat(v1989, ",")))
				end
				v2038 = 3
			elseif v2038 == 23 then
				if v2015 == "partnerclose" and v_u_174 then
					v2038 = 26
				else
					v2038 = 25
				end
			elseif v2038 == 24 then
				v_u_105.partnerPay()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 25 then
				if v2006 and v_u_1993 == "buy" then
					v2038 = 28
				else
					v2038 = 27
				end
			elseif v2038 == 26 then
				v_u_174.close()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 27 then
				if v2015 == "buy" and (v_u_1993 == "buy" and v_u_128) then
					v2038 = 30
				else
					v2038 = 29
				end
			elseif v2038 == 28 then
				if v_u_386:FindFirstChild(v2006, true) then
					v_u_1967 = v2006
					for _, v2059 in v_u_670 do
						v2059()
					end
					if v_u_115 and v_u_1964 == "gunsmith" then
						v2002 = v_u_115.traderView()
					else
						v1955 = v_u_170
						if type(v1955) == "table" then
							v2003 = v_u_170.traders
							v2002 = type(v2003) == "table" and v_u_170.traders[v_u_1964] or nil
						else
							v2002 = nil
						end
					end
					for _, v2060 in v2002 and v2002.offers or {} do
						v2004 = v2060.key
						if tostring(v2004) ~= v2006 then
							continue
						end
						v_u_671(v2060)
					end
				end
				if v_u_104 and (v_u_105.openDetail and v_u_128) then
					v_u_105.openDetail(true)
				end
				v1956 = "DevTraderPicked"
				if v_u_128 then
					v1973 = v_u_128.key
					v1974 = tostring(v1973)
				else
					v1974 = ""
				end
				v2014:SetAttribute(v1956, v1974)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 29 then
				if string.match(v2015, "^qty:") and v_u_1993 == "buy" then
					v2038 = 32
				else
					v2038 = 31
				end
			elseif v2038 == 30 then
				v_u_105.buyNow(v_u_128, v_u_135)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 31 then
				if v2015 == "fit:off" or v2015 == "fit:on" then
					v2038 = 33
				else
					v2038 = 34
				end
			elseif v2038 == 32 then
				v2024 = string.match(v2015, "^qty:(.+)$")
				if v_u_137 then
					v2025 = v_u_137
					if v2024 == "max" then
						v1975 = v_u_136
					else
						v1975 = tonumber(v2024) or v_u_135
					end
					v2025(v1975)
				end
				v2026 = v_u_386:FindFirstChild("Detail")
				if v2026 then
					v2026 = v2026:FindFirstChild("Foot", true)
				end
				if v2026 then
					v1976 = v2026:FindFirstChild("PriceCaption")
				else
					v1976 = v2026
				end
				if v2026 then
					v2026 = v2026:FindFirstChild("Price")
				end
				v2027 = v_u_127
				if v2027 then
					v2027 = v_u_127:FindFirstChild("Text", true)
				end
				v2014:SetAttribute("DevTraderQty", ("%d/%d  %s  %s  %s"):format(v_u_135, v_u_136, not (v1976 and v1976:IsA("TextLabel")) and "?" or v1976.Text, not (v2026 and v2026:IsA("TextLabel")) and "?" or v2026.Text, not (v2027 and v2027:IsA("TextLabel")) and "?" or v2027.Text))
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 33 then
				v_u_1977 = v2015 == "fit:off"
				if v_u_1993 == "buy" and v_u_128 then
					v_u_671(v_u_128)
				end
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 34 then
				if v2015 == "sellstrip" and (v_u_105.sellModal and v_u_105.sellDo) then
					v2038 = 36
				else
					v2038 = 35
				end
			elseif v2038 == 35 then
				if v2007 and (v_u_1993 == "sell" and v_u_131[v2007]) then
					v2038 = 38
				else
					v2038 = 37
				end
			elseif v2038 == 36 then
				v_u_105.sellModal.close()
				v_u_105.sellDo(true)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 37 then
				if v2015 == "sellall" then
					v2038 = 39
				else
					v2038 = 40
				end
			elseif v2038 == 38 then
				v_u_131[v2007]()
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			elseif v2038 == 39 then
				v2028 = v_u_170
				if type(v2028) == "table" then
					v2038 = 41
				else
					v2038 = 21
				end
			elseif v2038 == 40 then
				if v2015 == "close" and v_u_105.sellModal then
					v_u_105.sellModal.close()
				elseif string.match(v2015, "^filter:") then
					v1958, v1959 = string.match(v2015, "^filter:(%w+):?(%w*)$")
					if v1958 == "next" or v1958 == "prev" then
						v_u_619(v1958 == "next" and 1 or -1)
					elseif v1958 then
						if v1959 == "" then
							v1959 = nil
						end
						v2008 = v_u_1964 .. "/" .. v_u_1993
						v1960 = v_u_8[v2008]
						if not v1960 then
							v1960 = {
								["cat"] = "all",
								["cal"] = nil
							}
							v_u_8[v2008] = v1960
						end
						if v1960.cat ~= v1958 or v1960.cal ~= v1959 then
							v1960.cat = v1958
							if v1958 ~= "ammo" then
								v1959 = nil
							end
							v1960.cal = v1959
							v_u_99.sound(v_u_100.sounds.tab)
							v_u_2033 = true
							v_u_1986 = false
							v_u_105.drawBody()
						end
					end
				elseif v2015 == "filterdump" then
					v1987 = v_u_386:FindFirstChild("Offers", true) or v_u_386:FindFirstChild("Rows", true)
					v2034 = v_u_386:FindFirstChild("Filters", true)
					v1988 = v_u_386:FindFirstChild("Calibres", true)
					v1989 = {}
					if v_u_115 and v_u_1964 == "gunsmith" then
						v2035 = v_u_115.traderView()
					else
						v2036 = v_u_170
						if type(v2036) == "table" then
							v1961 = v_u_170.traders
							v2035 = type(v1961) == "table" and v_u_170.traders[v_u_1964] or nil
						else
							v2035 = nil
						end
					end
					v2009 = {}
					for v2061, v2062 in v2035 and v2035.offers or {} do
						v2010 = v2062.key
						v2009[tostring(v2010)] = v2062
					end
					v2011 = p_u_97.profile
					if type(v2011) == "table" then
						v2012 = v2011.inv
						if type(v2012) == "table" then
							v1962 = v2011.inv.containers
							if type(v1962) == "table" then
								v1963 = v2011.inv.containers.stash or nil
							else
								v1963 = nil
							end
						else
							v1963 = nil
						end
					else
						v1963 = nil
					end
					v2016 = {}
					if type(v1963) == "table" then
						v1995 = v1963.items
						v1943 = type(v1995) == "table" and (v1963.items or {}) or {}
					else
						v1943 = {}
					end
					for v2063, v2064 in v1943 do
						v1996 = v2064.uid
						v2016[tostring(v1996)] = v2064
					end
					for v2065, v2066 in v1987 and v1987:GetChildren() or {} do
						if not v2066:IsA("TextButton") then
							continue
						end
						v1944 = v2009[v2066.Name]
						v1945 = string.match(v2066.Name, "^Row_(.+)$")
						if v1944 then
							v2005 = v1944.items
							if type(v2005) == "table" and #v1944.items > 1 then
								v1946 = {}
								for v2067, v2068 in v1944.items do
									v1947 = v2068.id
									v1968 = tostring(v1947)
									table.insert(v1946, v1968)
								end
								v2021 = table.concat
								table.insert(v1989, v2021(v1946, "+"))
							else
								v2022 = v1944.id
								if not v2022 then
									v1969 = v1944.items
									v2022 = type(v1969) == "table" and v1944.items[1] and (v1944.items[1].id or "mat_scrap") or "mat_scrap"
								end
								table.insert(v1989, v2022)
							end
						else
							if not (v1945 and v2016[v1945]) then
								continue
							end
							v2023 = v2016[v1945].id
							v1970 = tostring(v2023)
							table.insert(v1989, v1970)
						end
					end
					v1949 = {}
					for v2069, v2070 in v1988 and v1988:GetChildren() or {} do
						if not v2070:IsA("TextButton") then
							continue
						end
						v1971 = v2070.Name
						v1972 = string.sub(v1971, 7)
						v1997 = tostring(v2070:GetAttribute("Count"))
						v1950 = v2070:GetAttribute("On") and "*" or ""
						table.insert(v1949, ("%s=%s%s"):format(v1972, v1997, v1950))
					end
					v1998 = v_u_1964 .. "/" .. v_u_1993
					v1999 = v_u_8[v1998]
					if not v1999 then
						v1999 = {
							["cat"] = "all",
							["cal"] = nil
						}
						v_u_8[v1998] = v1999
					end
					v2000 = v_u_1964
					v1951 = v_u_1993
					v1952 = v1999.cat
					v2001 = not v1999.cal and "" or ":" .. v1999.cal
					v1953 = #v1989
					v1954 = v2034 and v2034:GetAttribute("Counts") or "-"
					v2014:SetAttribute("DevTraderFilterDump", ("%s/%s %s%s shown=%d counts=%s cals=%s ids=%s"):format(v2000, v1951, v1952, v2001, v1953, tostring(v1954), table.concat(v1949, ","), table.concat(v1989, ",")))
				end
				v2038 = 3
			elseif v2038 == 41 then
				v1978 = v_u_170.quotes
				if type(v1978) == "table" then
					v2038 = 42
				else
					v2038 = 22
				end
			elseif v2038 == 42 then
				for v2071, v2072 in v_u_170.quotes do
					if type(v2072) ~= "table" then
						continue
					end
					v1979 = v2072.prices
					if type(v1979) ~= "table" or not v2072.prices[v_u_1964] then
						continue
					end
					v_u_1965[v2071] = true
				end
				if v_u_1993 == "sell" then
					v_u_105.drawBody()
				end
				v_u_105.confirmSell()
				v2014:SetAttribute("DevTraderSellPreview", v_u_105.sellPreview or "")
				v2014:SetAttribute("DevTraderSellAtt", v_u_105.sellAttachments or 0)
				v1948 = p_u_97.cctx
				if v1948 then
					v1948 = p_u_97.cctx.player
				end
				if v1948 then
					v1957 = v1948:GetAttribute("DevTrader")
				else
					v1957 = v1948
				end
				if type(v1957) == "string" and v1957 ~= "" then
					v1948:SetAttribute("DevTrader", nil)
					v2017, v2018 = string.match(v1957, "^(%w+):?(%w*)$")
					if v2017 and table.find(v_u_113, v2017) then
						if v_u_1964 ~= v2017 then
							v_u_428(v2017)
						end
						v_u_1964 = v2017
						v_u_1965 = {}
						v_u_1966 = nil
						v_u_1967 = nil
						if v2018 and v2018 ~= "" then
							v_u_1993 = v2018
							v1941 = v_u_361.select
							pcall(v1941, v2018, true)
						end
						v_u_105.draw()
					end
				end
				v2038 = 1
			else
				if v_u_139.label and (v_u_139.label.Parent and v_u_139.at > 0) then
					v1980 = v_u_139.at - os.time()
					v2013 = math.max(0, v1980)
					v_u_99.setText(v_u_139.label, "Restock in " .. v_u_99.clock(v2013))
					if v2013 <= 0 and v_u_139.reloadedFor ~= v_u_139.at then
						v_u_139.reloadedFor = v_u_139.at
						p_u_97.invalidate("traders")
						v_u_2029 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_170, (ref) p_u_97, (copy) v_u_2029, (ref) v_u_120, (ref) v_u_122, (ref) v_u_115, (ref) p_u_98, (ref) v_u_105
							v_u_170 = p_u_97.fetch("traders", nil, v_u_2029 and 0 or 20)
							v_u_120 = v_u_170 == nil
							v_u_122 = p_u_97.fetch("tasks", nil, 20)
							if v_u_115 then
								v_u_115.setView(p_u_97.fetch("gunsmith", nil, v_u_2029 and 0 or 2))
							end
							if p_u_98.Parent then
								v_u_105.draw()
							end
						end)
					end
				end
				if not game:GetService("RunService"):IsStudio() then
					return
				end
				v2014 = p_u_97.cctx
				if v2014 then
					v2014 = p_u_97.cctx.player
				end
				if v2014 then
					v2015 = v2014:GetAttribute("DevTraderAct")
				else
					v2015 = v2014
				end
				if type(v2015) == "string" and v2015 ~= "" then
					v2038 = 5
				else
					v2038 = 4
				end
			end
		end
	end
	local v_u_2073 = nil
	local function v2075()
		-- upvalues: (copy) p_u_97, (ref) v_u_2073, (ref) v_u_1993, (copy) v_u_622, (copy) v_u_619, (ref) v_u_137, (ref) v_u_127, (copy) p_u_98, (ref) v_u_1, (ref) v_u_135
		v_u_2073 = p_u_97.cctx.lib.VirtualPad.InputBegan:Connect(function(p2074)
			-- upvalues: (ref) v_u_1993, (ref) v_u_622, (ref) v_u_619, (ref) v_u_137, (ref) v_u_127, (ref) p_u_98, (ref) v_u_1, (ref) v_u_135
			if (p2074.KeyCode == Enum.KeyCode.ButtonL2 or p2074.KeyCode == Enum.KeyCode.ButtonR2) and ((v_u_1993 == "buy" or v_u_1993 == "sell") and v_u_622()) then
				v_u_619(p2074.KeyCode == Enum.KeyCode.ButtonR2 and 1 or -1)
				return
			elseif v_u_1993 == "buy" and (v_u_137 and (v_u_127 and p_u_98.Parent)) then
				if v_u_1.SelectedObject == v_u_127 then
					if p2074.KeyCode == Enum.KeyCode.DPadLeft then
						v_u_137(v_u_135 - 1)
					elseif p2074.KeyCode == Enum.KeyCode.DPadRight then
						v_u_137(v_u_135 + 1)
					end
				else
					return
				end
			else
				return
			end
		end)
	end
	pcall(v2075)
	local v_u_2076 = nil
	local function v2079()
		-- upvalues: (ref) v_u_2076, (copy) v_u_99, (copy) p_u_98, (copy) v_u_487, (ref) v_u_1993, (ref) v_u_128, (ref) v_u_127, (ref) v_u_1, (ref) v_u_671
		v_u_2076 = v_u_99.onDevice(function()
			-- upvalues: (ref) p_u_98, (ref) v_u_487, (ref) v_u_1993, (ref) v_u_128, (ref) v_u_127, (ref) v_u_1, (ref) v_u_671
			if p_u_98.Parent then
				for _, v2077 in v_u_487 do
					pcall(v2077)
				end
				if v_u_1993 == "buy" and (v_u_128 and (v_u_127 and v_u_127.Parent)) then
					local v2078 = v_u_1.SelectedObject == v_u_127
					v_u_671(v_u_128)
					if v2078 and (v_u_127 and v_u_127.Parent) then
						v_u_1.SelectedObject = v_u_127
					end
				end
			end
		end)
	end
	pcall(v2079)
	local function v_u_2086() -- name: dropPad
		-- upvalues: (ref) v_u_115, (copy) v_u_134, (ref) v_u_167, (ref) v_u_174, (ref) v_u_171, (ref) v_u_2073, (ref) v_u_2076
		if v_u_115 then
			local v2080 = v_u_115.destroy
			pcall(v2080)
		end
		local function v2081()
			-- upvalues: (ref) v_u_134
			v_u_134:Disconnect()
		end
		pcall(v2081)
		if v_u_167 then
			local function v2082()
				-- upvalues: (ref) v_u_167
				v_u_167:Disconnect()
			end
			pcall(v2082)
			v_u_167 = nil
		end
		if v_u_174 then
			local function v2083()
				-- upvalues: (ref) v_u_174
				v_u_174.close()
			end
			pcall(v2083)
			v_u_174 = nil
		end
		if v_u_171 then
			v_u_171.viewerPartners = nil
		end
		if v_u_2073 then
			local function v2084()
				-- upvalues: (ref) v_u_2073
				v_u_2073:Disconnect()
			end
			pcall(v2084)
			v_u_2073 = nil
		end
		if v_u_2076 then
			local v2085 = v_u_2076
			pcall(v2085)
			v_u_2076 = nil
		end
	end
	p_u_98.Destroying:Connect(v_u_2086)
	function v_u_105.destroy() -- name: destroy
		-- upvalues: (copy) v_u_2086, (copy) v_u_1845
		v_u_2086()
		v_u_1845(true)
	end
	return v_u_105
end
return v_u_3