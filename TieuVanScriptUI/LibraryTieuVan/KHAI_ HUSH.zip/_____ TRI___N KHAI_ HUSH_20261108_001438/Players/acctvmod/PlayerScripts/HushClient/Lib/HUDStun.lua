-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDStun

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
return {
	["new"] = function(p_u_2) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_3 = p_u_2.UI
		local v4 = p_u_2.Theme.color
		local v5 = {}
		local v_u_6 = nil
		local v7, v_u_8 = pcall(function()
			-- upvalues: (copy) p_u_2
			return p_u_2.cctx.shared.StunRules
		end)
		if not v7 or type(v_u_8) ~= "table" then
			v_u_8 = nil
		end
		local v_u_9 = Color3.fromRGB(46, 18, 78)
		local v_u_10 = v_u_3.new("Frame", {
			["Name"] = "Stun",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 2,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_2.fx)
		local v_u_11 = {}
		local function v21(p12, p13, p14, p15, p16) -- name: strip
			-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11
			local v17 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["ZIndex"] = 2,
				["Name"] = p12,
				["BackgroundColor3"] = v_u_9,
				["Position"] = p13,
				["Size"] = p14,
				["AnchorPoint"] = p15
			}
			local v18 = v_u_3.new("Frame", v17, v_u_10)
			local v19 = Instance.new("UIGradient")
			v19.Rotation = p16
			v19.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
			v19.Parent = v18
			local v20 = v_u_11
			table.insert(v20, v18)
		end
		v21("Top", UDim2.fromScale(0, 0), UDim2.fromScale(1, 0.16), Vector2.new(0, 0), 90)
		v21("Bottom", UDim2.fromScale(0, 1), UDim2.fromScale(1, 0.16), Vector2.new(0, 1), 270)
		v21("Left", UDim2.fromScale(0, 0), UDim2.fromScale(0.096, 1), Vector2.new(0, 0), 0)
		v21("Right", UDim2.fromScale(1, 0), UDim2.fromScale(0.096, 1), Vector2.new(1, 0), 180)
		local v_u_22 = v_u_3.new("Frame", {
			["Name"] = "Chip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v4.bg,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0.2),
			["Size"] = UDim2.fromOffset(188, 40)
		}, v_u_10)
		v_u_3.new("UICorner", {
			["CornerRadius"] = UDim.new(0, 8)
		}, v_u_22)
		v_u_3.icon("star", {
			["parent"] = nil,
			["size"] = 20,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_22,
			["color"] = v4.accent,
			["position"] = UDim2.new(0, 22, 0.5, -2),
			["anchor"] = Vector2.new(0.5, 0.5)
		})
		v_u_3.label({
			["parent"] = nil,
			["text"] = "STUNNED",
			["style"] = "caps",
			["textSize"] = 16,
			["color"] = nil,
			["align"] = "left",
			["position"] = nil,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_22,
			["color"] = v4.text,
			["position"] = UDim2.fromOffset(40, 4),
			["size"] = UDim2.new(1, -48, 0, 22)
		})
		local v_u_23 = v_u_3.progress({
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["value"] = 1,
			["color"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_22,
			["size"] = UDim2.new(1, -24, 0, 4),
			["position"] = UDim2.new(0, 12, 1, -10),
			["color"] = v4.accent
		})
		local v_u_24 = false
		local v_u_25 = 1
		local v_u_26 = 0
		local v_u_27 = -1000000000
		local v_u_28 = true
		local v_u_29 = 0
		function v5.setCharacter(p30) -- name: setCharacter
			-- upvalues: (ref) v_u_6, (ref) v_u_25, (ref) v_u_26, (ref) v_u_24, (copy) v_u_10, (copy) v_u_11
			v_u_6 = p30
			v_u_25 = 1
			v_u_26 = 0
			if not p30 then
				if v_u_24 == false then
					return
				end
				v_u_24 = false
				v_u_10.Visible = false
				for _, v31 in v_u_11 do
					v31.BackgroundTransparency = 1
				end
			end
		end
		function v5.layout(p32) -- name: layout
			-- upvalues: (copy) v_u_22
			local v33 = v_u_22
			local v34
			if p32 then
				v34 = UDim2.fromOffset(160, 36)
			else
				v34 = UDim2.fromOffset(188, 40)
			end
			v33.Size = v34
			v_u_22.Position = UDim2.fromScale(0.5, p32 and 0.26 or 0.2)
		end
		function v5.update(p35) -- name: update
			-- upvalues: (ref) v_u_29, (ref) v_u_6, (ref) v_u_8, (ref) v_u_24, (copy) v_u_10, (copy) v_u_11, (ref) v_u_1, (ref) v_u_27, (copy) p_u_2, (ref) v_u_28, (ref) v_u_26, (ref) v_u_25, (copy) v_u_23
			v_u_29 = v_u_29 + p35
			local v36 = v_u_6
			if v36 and (v36.Parent ~= nil and (v_u_8 ~= nil and v36:GetAttribute("StunUntil") ~= nil)) then
				local v37 = v_u_1.now()
				if v_u_29 - v_u_27 > 2 then
					v_u_27 = v_u_29
					local function v38()
						-- upvalues: (ref) p_u_2
						return p_u_2.cctx.config.flag("DjStun")
					end
					local v39, v40 = pcall(v38)
					if v39 then
						v39 = v40 == false
					end
					v_u_28 = not v39
				end
				local v41 = not (v_u_28 and v_u_8.active(v36, v37)) and 0 or v_u_8.remaining(v36:GetAttribute("StunUntil"), v37)
				if v41 <= 0 then
					if v_u_24 ~= false then
						v_u_24 = false
						v_u_10.Visible = false
						for _, v42 in v_u_11 do
							v42.BackgroundTransparency = 1
						end
					end
				else
					if v_u_26 + 0.05 < v41 or v_u_26 <= 0 then
						v_u_25 = math.max(v41, 0.1)
					end
					v_u_26 = v41
					if v_u_24 ~= true then
						v_u_24 = true
						v_u_10.Visible = true
					end
					local v43 = v_u_23.set
					local v44 = v41 / v_u_25
					v43(math.clamp(v44, 0, 1), true)
					local v45 = v_u_29 * 3.141592653589793 * 2 * 2
					local v46 = ((math.sin(v45) * 0.5 + 0.5) * 0.45 + 0.55) * 0.35
					local v47 = v41 / 0.25
					local v48 = v46 * math.min(1, v47)
					for _, v49 in v_u_11 do
						v49.BackgroundTransparency = 1 - v48
					end
					return
				end
			elseif v_u_24 ~= false then
				v_u_24 = false
				v_u_10.Visible = false
				for _, v50 in v_u_11 do
					v50.BackgroundTransparency = 1
				end
			end
		end
		function v5.destroy() -- name: destroy
			-- upvalues: (copy) v_u_10
			v_u_10:Destroy()
		end
		return v5
	end
}