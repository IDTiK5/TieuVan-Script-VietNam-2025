-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketSell

local v_u_1 = game:GetService("GuiService")
local v_u_519 = {
	["MEM"] = {
		["chip"] = "all"
	},
	["SHORT"] = {
		["STRIP_FIRST"] = "MODS",
		["EMPTY_FIRST"] = "EMPTY IT",
		["INSURED"] = "INSURED",
		["NO_TRADE_CLASS"] = "NO TRADE",
		["UNKNOWN_ITEM"] = "NO TRADE",
		["PAID_ITEM"] = "NO TRADE",
		["GIFT"] = "GIFT",
		["PAID_BLOCKED"] = "PAID",
		["NOT_STASH"] = "NO",
		["CRATE_TRADE"] = "NO TRADE",
		["CRATE_PAID"] = "NO TRADE",
		["CRATE_SCANNED"] = "NO TRADE",
		["OFF_CRATES"] = "OFF",
		["POLICY_WAIT"] = "WAIT",
		["POLICY_FAIL"] = "CHECK"
	},
	["new"] = function(p_u_2, p_u_3) -- name: new
		-- upvalues: (copy) v_u_519, (copy) v_u_1
		local v_u_4 = p_u_2.ui
		local v_u_5 = p_u_2.theme
		local v_u_6 = p_u_2.C
		local v_u_7 = p_u_2.Data
		local v_u_8 = p_u_2.data
		local v_u_9 = p_u_2.h
		local v_u_10 = p_u_2.kit
		local v_u_11 = p_u_2.mc.cctx.lib.MenuMarketKeypad
		local v_u_12 = p_u_2.compact
		local v13 = p_u_2.phone
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = false
		local v_u_17 = v_u_8:eligibility()
		local v_u_18 = v_u_519.MEM
		local v_u_19 = ""
		local v_u_20 = {}
		local v_u_21 = nil
		local function v22()
			-- upvalues: (ref) v_u_21, (copy) p_u_2
			v_u_21 = p_u_2.mc.cctx.shared.Items
		end
		pcall(v22)
		local v_u_23 = nil
		local function v24()
			-- upvalues: (ref) v_u_23, (copy) p_u_2
			v_u_23 = p_u_2.mc.cctx.lib.MenuMarketOrder
		end
		pcall(v24)
		local v_u_25
		if v_u_23 == nil then
			v_u_25 = false
		else
			local v26, v27 = pcall(function()
				-- upvalues: (copy) p_u_2
				return p_u_2.mc.cctx.config.flag("BuyOrders")
			end)
			v_u_25 = not v26 or v27 ~= false
		end
		local v_u_28 = nil
		local function v29()
			-- upvalues: (ref) v_u_28, (copy) p_u_2
			v_u_28 = p_u_2.mc.cctx.lib.MenuMarketCrateKit
		end
		pcall(v29)
		local v_u_30 = nil
		local v_u_31 = nil
		local v_u_32 = nil
		local v_u_33 = nil
		local v_u_34 = nil
		local v_u_35 = 1
		local v_u_36 = 0
		local v_u_37 = false
		local v_u_38 = false
		local v_u_39 = nil
		local v_u_40 = "idle"
		local v_u_41 = nil
		local v_u_42 = nil
		local v_u_43 = nil
		local v_u_44 = nil
		local v_u_45 = false
		local v_u_46 = 0
		local v_u_47 = {}
		local v_u_48 = {}
		local v49 = v_u_12 and 0.4 or 0.42
		local v50 = v_u_4.new("Frame", {
			["Name"] = "Left",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(v49, -6, 1, 0)
		}, p_u_3)
		local v51 = v_u_4.new("Frame", {
			["Name"] = "Right",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.new(v49, 6, 0, 0),
			["Size"] = UDim2.new(1 - v49, -6, 1, 0)
		}, p_u_3)
		local v_u_52 = v_u_5.touch(v_u_12 and 36 or 32)
		local v_u_53 = v13 and 84 or 76
		local v54 = p_u_2.controlFrame("sell")
		local v55 = v_u_12 and 130 or 210
		local v56 = v_u_5.touch(40)
		local v58, v_u_59 = v_u_4.input({
			["parent"] = nil,
			["name"] = "Search",
			["placeholder"] = "Search your stash",
			["size"] = nil,
			["maxLength"] = 40,
			["onChange"] = nil,
			["parent"] = v54,
			["size"] = UDim2.new(1, -(v55 + 8), 0, v56),
			["onChange"] = function(p57) -- name: onChange
				-- upvalues: (ref) v_u_19, (copy) v_u_14
				v_u_19 = p57
				v_u_14.queueStash()
			end
		})
		v58.AnchorPoint = Vector2.new(0, 0.5)
		v58.Position = UDim2.new(0, 0, 0.5, 0)
		local v_u_60 = v_u_4.new("Frame", {
			["Name"] = "AllowChip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_6.raised,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, 0, 0.5, 0),
			["Size"] = UDim2.fromOffset(v55, v56)
		}, v54)
		local v_u_61 = v_u_4.stroke(v_u_60, v_u_6.line)
		local v_u_62 = v_u_4.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["fit"] = true,
			["parent"] = v_u_60,
			["color"] = v_u_6.text,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_63 = v_u_4.list({
			["parent"] = nil,
			["name"] = "Chips",
			["horizontal"] = true,
			["gap"] = 6,
			["position"] = nil,
			["size"] = nil,
			["padding"] = nil,
			["parent"] = v50,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.new(1, 0, 0, v_u_52 + 6),
			["padding"] = {
				0,
				0,
				0,
				4
			}
		})
		local v_u_64 = v_u_4.list({
			["parent"] = nil,
			["name"] = "Stash",
			["position"] = nil,
			["size"] = nil,
			["gap"] = 6,
			["padding"] = nil,
			["parent"] = v50,
			["position"] = UDim2.fromOffset(0, v_u_52 + 8),
			["size"] = UDim2.new(1, 0, 1, -(v_u_52 + 8)),
			["padding"] = {
				2,
				8,
				2,
				8
			}
		})
		local v65 = v_u_64:FindFirstChildOfClass("UIListLayout")
		if v65 then
			v65:Destroy()
		end
		v_u_4.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(v_u_53, v_u_53),
			["CellPadding"] = UDim2.fromOffset(6, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v_u_64)
		local v_u_66 = v_u_4.label({
			["parent"] = nil,
			["name"] = "Empty",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["visible"] = false,
			["parent"] = v50,
			["color"] = v_u_6.text2,
			["position"] = UDim2.new(0.1, 0, 0, v_u_52 + 60),
			["size"] = UDim2.new(0.8, 0, 0, 80)
		})
		local function v_u_75(p67) -- name: envOf
			-- upvalues: (copy) p_u_2, (copy) v_u_8, (copy) v_u_7
			local v68 = p_u_2.state
			local v69
			if type(v68) == "table" then
				local v70 = v68.tune
				v69 = type(v70) ~= "table" and {} or v68.tune
			else
				v69 = {}
			end
			local v71 = {
				["restricted"] = nil,
				["insured"] = nil,
				["topLevel"] = true,
				["denyPaid"] = nil
			}
			local v72
			if type(v68) == "table" then
				v72 = v68.restricted == true
			else
				v72 = false
			end
			v71.restricted = v72
			v71.insured = v_u_8:insured(p67.uid)
			v71.denyPaid = v69.denyPaid == true
			if v_u_7.isCrateItem(p67.id) then
				for v73, v74 in v_u_7.crateEnv(v68) do
					v71[v73] = v74
				end
			end
			return v71
		end
		local function v_u_83() -- name: cull
			-- upvalues: (copy) v_u_64, (copy) v_u_47, (copy) v_u_10
			local v76 = v_u_64.AbsoluteWindowSize.Y
			local v77 = v_u_64.AbsolutePosition.Y
			for _, v78 in v_u_47 do
				local v79 = v78.cell.AbsolutePosition.Y
				local v80
				if v77 - 200 < v79 then
					v80 = v79 < v77 + v76 + 200
				else
					v80 = false
				end
				local v81 = v_u_10.cellRender
				local v82 = v78.cell
				pcall(v81, v82, v80)
			end
		end
		local function v_u_91(p84) -- name: chipList
			-- upvalues: (copy) v_u_10, (copy) v_u_17
			local v85 = {}
			for _, v86 in p84 do
				local v87 = v_u_10.itemDef(v86.id)
				if not v87 then
					continue
				end
				v85[v_u_17.categoryOf(v87)] = true
			end
			local v88 = {
				{
					["id"] = "all",
					["label"] = "ALL"
				}
			}
			for _, v89 in v_u_17.CATEGORIES do
				if not v85[v89.id] then
					continue
				end
				local v90 = {
					["id"] = v89.id,
					["label"] = v89.label
				}
				table.insert(v88, v90)
			end
			return v88
		end
		local v_u_92 = {}
		local function v_u_102() -- name: paintChips
			-- upvalues: (copy) v_u_92, (copy) v_u_18, (copy) v_u_6
			for v93, v94 in v_u_92 do
				local v95 = v_u_18.chip == v93
				local v96 = v94.btn
				local v97
				if v95 then
					v97 = v_u_6.accentDeep
				else
					v97 = v_u_6.raised
				end
				v96.BackgroundColor3 = v97
				v94.btn.BackgroundTransparency = v95 and 0.05 or 0.3
				local v98 = v94.stroke
				local v99
				if v95 then
					v99 = v_u_6.accent
				else
					v99 = v_u_6.line
				end
				v98.Color = v99
				local v100 = v94.lbl
				local v101
				if v95 then
					v101 = v_u_6.text
				else
					v101 = v_u_6.text2
				end
				v100.TextColor3 = v101
			end
		end
		local v_u_103 = nil
		local v_u_104 = nil
		local function v_u_146() -- name: buildStash
			-- upvalues: (copy) v_u_47, (copy) v_u_10, (copy) v_u_8, (copy) v_u_63, (copy) v_u_92, (copy) v_u_91, (copy) v_u_18, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_52, (copy) v_u_102, (copy) v_u_14, (copy) v_u_17, (copy) v_u_7, (ref) v_u_19, (copy) v_u_75, (ref) v_u_21, (ref) v_u_519, (copy) v_u_64, (copy) v_u_53, (ref) v_u_103, (copy) p_u_2, (copy) v_u_66, (ref) v_u_30, (copy) v_u_83
			for _, v105 in v_u_47 do
				local v106 = v_u_10.cellRender
				local v107 = v105.cell
				pcall(v106, v107, false)
				v105.cell:Destroy()
			end
			table.clear(v_u_47)
			local v108 = v_u_8:stash()
			for _, v109 in v_u_63:GetChildren() do
				if not v109:IsA("TextButton") then
					continue
				end
				v109:Destroy()
			end
			table.clear(v_u_92)
			local v110 = v_u_91(v108)
			local v111 = table.find
			local v112 = {}
			for _, v113 in v110 do
				local v114 = v113.id
				table.insert(v112, v114)
			end
			if not v111(v112, v_u_18.chip) then
				v_u_18.chip = "all"
			end
			for v115, v_u_116 in v110 do
				local v117 = v_u_4.new("TextButton", {
					["Name"] = nil,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["AutomaticSize"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Selectable"] = true,
					["Name"] = "Chip_" .. v_u_116.id,
					["BackgroundColor3"] = v_u_6.raised,
					["AutomaticSize"] = Enum.AutomaticSize.X,
					["Size"] = UDim2.fromOffset(v_u_5.touch(24), v_u_52),
					["LayoutOrder"] = v115
				}, v_u_63)
				v117.SelectionImageObject = v_u_4.selectionImage()
				local v118 = v_u_4.stroke(v117, v_u_6.line)
				v_u_4.pad(v117, {
					10,
					10,
					0,
					0
				})
				local v119 = {
					["btn"] = v117,
					["stroke"] = v118,
					["lbl"] = v_u_4.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["autoX"] = true,
						["size"] = nil,
						["parent"] = v117,
						["text"] = v_u_116.label,
						["color"] = v_u_6.text2,
						["size"] = UDim2.new(0, 0, 1, 0)
					})
				}
				v_u_92[v_u_116.id] = v119
				v117.Activated:Connect(function()
					-- upvalues: (ref) v_u_18, (copy) v_u_116, (ref) v_u_4, (ref) v_u_5, (ref) v_u_102, (ref) v_u_14
					if v_u_18.chip ~= v_u_116.id then
						v_u_4.sound(v_u_5.sounds.tab)
						v_u_18.chip = v_u_116.id
						v_u_102()
						v_u_14.queueStash(true)
					end
				end)
			end
			v_u_102()
			local v120 = {}
			for _, v121 in v108 do
				local v122 = v_u_10.itemDef(v121.id)
				if not v122 then
					continue
				end
				local v123 = {
					["inst"] = v121,
					["def"] = v122
				}
				local v124 = v_u_18.chip == "all" and true or v_u_17.categoryOf(v122) == v_u_18.chip
				local v125 = {
					["name"] = v122.name,
					["short"] = v122.short,
					["id"] = v122.id,
					["tags"] = v122.tags or {}
				}
				if not (v124 and v_u_7.matchQuery(v125, v_u_19)) then
					continue
				end
				local v126, v127, v128 = v_u_17.checkInst(v121, (v_u_75(v121)))
				v123.ok = v126 or v127 == "STRIP_FIRST"
				if v126 then
					v127 = nil
				end
				v123.code = v127
				v123.detail = v128
				table.insert(v120, v123)
			end
			table.sort(v120, function(p129, p130)
				-- upvalues: (ref) v_u_21
				if p129.ok == p130.ok then
					if p129.def.category == p130.def.category then
						if p129.def.name == p130.def.name then
							return p129.inst.uid < p130.inst.uid
						else
							return p129.def.name < p130.def.name
						end
					else
						return v_u_21.categoryOrder(p129.def.category) < v_u_21.categoryOrder(p130.def.category)
					end
				else
					return p129.ok
				end
			end)
			for v131, v_u_132 in v120 do
				local v_u_133 = v_u_132.inst
				local v134 = v_u_132.code and (v_u_519.SHORT[v_u_132.code] or "NO") or nil
				local v139 = v_u_10.itemCell(v_u_64, v_u_133.id, {
					["size"] = nil,
					["count"] = nil,
					["dim"] = nil,
					["model"] = true,
					["wish"] = false,
					["lazy"] = true,
					["order"] = nil,
					["badge"] = nil,
					["badgeKind"] = nil,
					["mods"] = nil,
					["onClick"] = nil,
					["tooltip"] = nil,
					["size"] = v_u_53,
					["count"] = v_u_133.n,
					["dim"] = not v_u_132.ok,
					["order"] = v131,
					["badge"] = v134,
					["badgeKind"] = v_u_132.ok and "warn" or "danger",
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_103, (copy) v_u_133
						v_u_103(v_u_133.uid)
					end,
					["tooltip"] = function() -- name: tooltip
						-- upvalues: (copy) v_u_132, (ref) v_u_6, (ref) v_u_10, (copy) v_u_133, (ref) v_u_7, (ref) p_u_2
						local v135 = {}
						if v_u_132.code then
							local v136 = {
								["label"] = "Cannot be listed",
								["value"] = "",
								["color"] = nil,
								["color"] = v_u_6.danger
							}
							table.insert(v135, v136)
						end
						local v137 = {
							["title"] = v_u_10.itemName(v_u_133.id)
						}
						local v138
						if v_u_132.code then
							v138 = v_u_7.text(p_u_2.rules, v_u_132.code)
						else
							v138 = nil
						end
						v137.body = v138
						v137.lines = v135
						return v137
					end
				})
				v139.SelectionImageObject = v_u_4.selectionImage()
				v139.Name = "Stash_" .. v_u_133.uid
				v139:SetAttribute("Uid", v_u_133.uid)
				v139:SetAttribute("Listable", v_u_132.ok)
				v139:SetAttribute("Code", v_u_132.code or "")
				local v140 = v_u_4.new("Frame", {
					["Name"] = "SelRing",
					["BackgroundTransparency"] = 1,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["ZIndex"] = 8,
					["Visible"] = false,
					["Size"] = UDim2.fromScale(1, 1)
				}, v139)
				v_u_4.stroke(v140, v_u_6.accent, 2, 0)
				local v141 = v_u_47
				local v142 = {
					["cell"] = v139,
					["inst"] = v_u_133,
					["ok"] = v_u_132.ok,
					["code"] = v_u_132.code,
					["ring"] = v140
				}
				table.insert(v141, v142)
			end
			v_u_66.Visible = #v120 == 0
			if #v120 == 0 then
				v_u_66.Text = #v108 == 0 and "Your stash is empty. Bring items home from a raid to sell them." or "Nothing here. Try another chip or word."
			end
			for _, v143 in v_u_47 do
				v143.ring.Visible = v143.inst.uid == v_u_30
			end
			task.defer(v_u_83)
			if v_u_30 then
				local v144 = false
				for _, v145 in v108 do
					if v145.uid ~= v_u_30 then
						continue
					end
					v144 = true
				end
				if not v144 then
					v_u_103(nil)
				end
			end
		end
		local v_u_147 = 0
		function v_u_14.queueStash(p148) -- name: queueStash
			-- upvalues: (ref) v_u_147, (copy) v_u_146, (ref) v_u_15
			v_u_147 = v_u_147 + 1
			local v_u_149 = v_u_147
			if p148 then
				v_u_146()
			else
				task.delay(0.15, function()
					-- upvalues: (copy) v_u_149, (ref) v_u_147, (ref) v_u_15, (ref) v_u_146
					if v_u_149 == v_u_147 and v_u_15 then
						v_u_146()
					end
				end)
			end
		end
		v_u_64:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_83)
		v_u_64:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v_u_83)
		local function v_u_153() -- name: caseModel
			-- upvalues: (ref) v_u_39, (copy) v_u_7, (ref) v_u_32
			local v150 = v_u_39
			local v151
			if v150 then
				v151 = {
					["m"] = v150.min
				}
				local v152 = v150.min
				v151.c = type(v152) == "number" and 1 or 0
				v151.a = v150.avg7
			else
				v151 = nil
			end
			return v_u_7.crateSellModel(v_u_32.id, v151)
		end
		local function v_u_159() -- name: refUnit
			-- upvalues: (ref) v_u_32, (copy) v_u_7, (copy) v_u_153, (ref) v_u_39, (ref) v_u_41, (copy) v_u_11
			local v154
			if v_u_32 == nil then
				v154 = false
			else
				v154 = v_u_7.isCrateItem(v_u_32.id)
			end
			if v154 then
				local v155 = v_u_153()
				if v155 then
					return v155.warnRef
				else
					return nil
				end
			else
				local v156 = {}
				local v157 = v_u_39
				if v157 then
					v157 = v_u_39.avg7
				end
				v156.avg7 = v157
				local v158 = v_u_39
				if v158 then
					v158 = v_u_39.min
				end
				v156.min = v158
				v156.pay = v_u_41
				return v_u_11.reference(v156)
			end
		end
		local function v_u_167() -- name: listVerdict
			-- upvalues: (copy) p_u_2, (ref) v_u_32, (copy) v_u_7, (ref) v_u_36, (ref) v_u_35, (ref) v_u_40, (ref) v_u_39, (copy) v_u_8
			local v160 = p_u_2.state
			local v161
			if type(v160) == "table" then
				v161 = v160.list
			else
				v161 = nil
			end
			local v162 = not v_u_32 and 0 or v_u_7.listUnitValue(v_u_32.id, v_u_32)
			local v163 = v_u_7.listVerdict
			local v164 = v_u_36
			local v165 = v_u_35
			local v166
			if v_u_40 == "ok" then
				v166 = v_u_39
			else
				v166 = nil
			end
			return v163(v164, v165, v162, v166, v_u_8:cash(), v161), v161
		end
		local function v_u_175() -- name: evaluate
			-- upvalues: (ref) v_u_31, (ref) v_u_33, (copy) v_u_7, (copy) p_u_2, (copy) v_u_8, (ref) v_u_38, (ref) v_u_36, (ref) v_u_35, (copy) v_u_11, (copy) v_u_167, (ref) v_u_45
			if not v_u_31 then
				return {
					["enabled"] = false
				}
			end
			if v_u_33 and v_u_33 ~= "STRIP_FIRST" then
				return {
					["enabled"] = false,
					["reason"] = nil,
					["code"] = nil,
					["reason"] = v_u_7.text(p_u_2.rules, v_u_33),
					["code"] = v_u_33
				}
			end
			local v168, v169 = p_u_2.canList()
			if not v168 then
				return {
					["enabled"] = false,
					["reason"] = nil,
					["code"] = "CAN",
					["reason"] = v169
				}
			end
			local v170 = p_u_2.state
			local v171
			if type(v170) == "table" then
				local v172 = v170.allow
				if type(v172) == "table" then
					v171 = v170.allow
				else
					v171 = nil
				end
			else
				v171 = nil
			end
			if v171 and (v171.left or (v171.limit or 3) - (v171.used or 0)) <= 0 then
				local v173 = v_u_7.left({
					["resetIn"] = v171.resetIn,
					["_at"] = v170._at
				}, "resetIn", v_u_8:clock())
				return {
					["enabled"] = false,
					["reason"] = nil,
					["code"] = "LIMIT",
					["reason"] = v_u_7.text(p_u_2.rules, "LIMIT", {
						["resetIn"] = v_u_7.duration(v173)
					})
				}
			end
			if v_u_33 == "STRIP_FIRST" and not v_u_38 then
				return {
					["enabled"] = false,
					["reason"] = nil,
					["code"] = "STRIP_FIRST",
					["reason"] = v_u_7.text(p_u_2.rules, "STRIP_FIRST")
				}
			end
			if v_u_36 < 1 then
				return {
					["enabled"] = false,
					["reason"] = "Enter a price.",
					["code"] = "EMPTY"
				}
			end
			if v_u_36 < v_u_35 or v_u_36 > v_u_11.MAX_PRICE then
				return {
					["enabled"] = false,
					["reason"] = nil,
					["code"] = "PRICE_RANGE",
					["reason"] = v_u_7.text(p_u_2.rules, "PRICE_RANGE")
				}
			end
			local v174 = v_u_167()
			return v174.capHit and {
				["enabled"] = false,
				["reason"] = nil,
				["code"] = "PRICE_CAP",
				["reason"] = v_u_7.text(p_u_2.rules, "PRICE_CAP", {
					["max"] = v174.cap
				})
			} or (v174.short > 0 and {
				["enabled"] = false,
				["reason"] = nil,
				["code"] = "LIST_FEE_CASH",
				["reason"] = v_u_7.text(p_u_2.rules, "LIST_FEE_CASH", {
					["fee"] = v174.fee,
					["need"] = v174.short
				})
			} or (v_u_45 and {
				["enabled"] = false,
				["reason"] = nil,
				["code"] = "BUSY"
			} or {
				["enabled"] = true
			}))
		end
		local v176 = v_u_12 and 22 or 40
		local v177 = v_u_5.touch(40) + v176 + 6
		local v178 = not v_u_12 and 0 or v176 + 56 + 6
		local v179 = v_u_4.list
		local v180 = {
			["parent"] = nil,
			["name"] = "Form",
			["position"] = nil,
			["size"] = nil,
			["gap"] = 10,
			["padding"] = nil,
			["parent"] = v51,
			["position"] = UDim2.fromOffset(0, v178)
		}
		local v181
		if v_u_12 then
			v181 = UDim2.new(1, 0, 1, -v178)
		else
			v181 = UDim2.new(1, 0, 1, -(v177 + 4))
		end
		v180.size = v181
		v180.padding = {
			0,
			8,
			0,
			8
		}
		local v_u_182 = v179(v180)
		local v_u_183 = nil
		local v_u_184, v_u_185, v_u_186
		if v_u_12 then
			v_u_183 = v_u_4.new("Frame", {
				["Name"] = "HeadFixed",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 56)
			}, v51)
			v_u_184 = v_u_4.label({
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v51,
				["color"] = v_u_6.accent,
				["position"] = UDim2.fromOffset(0, 58),
				["size"] = UDim2.new(1, 0, 0, v176)
			})
			v_u_185, v_u_186 = v_u_9.button(v_u_183, "List", "primary", function()
				-- upvalues: (copy) v_u_14
				v_u_14.listNow()
			end, {
				["name"] = "List",
				["height"] = 40,
				["width"] = 124,
				["anchor"] = nil,
				["position"] = nil,
				["maxTextWidth"] = 100,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, 0, 0.5, 0)
			})
		else
			local v187 = v_u_4.new("Frame", {
				["Name"] = "Footer",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, v177)
			}, v51)
			v_u_184 = v_u_4.label({
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["valign"] = "bottom",
				["fit"] = true,
				["track"] = false,
				["parent"] = v187,
				["color"] = v_u_6.accent,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(1, 0, 0, v176)
			})
			v_u_185, v_u_186 = v_u_9.button(v187, "List", "primary", function()
				-- upvalues: (copy) v_u_14
				v_u_14.listNow()
			end, {
				["name"] = "List",
				["height"] = 40,
				["width"] = 0,
				["size"] = nil,
				["position"] = nil,
				["maxTextWidth"] = 260,
				["size"] = UDim2.new(1, 0, 0, v_u_5.touch(40)),
				["position"] = UDim2.new(0, 0, 1, -v_u_5.touch(40))
			})
		end
		local function v_u_190() -- name: clearForm
			-- upvalues: (copy) v_u_182, (ref) v_u_183, (ref) v_u_48
			for _, v188 in v_u_182:GetChildren() do
				if v188:IsA("UIListLayout") or v188:IsA("UIPadding") then
					continue
				end
				v188:Destroy()
			end
			local v189 = v_u_183 and v_u_183:FindFirstChild("Head")
			if v189 then
				v189:Destroy()
			end
			v_u_48 = {}
		end
		local v_u_191 = false
		local function v_u_203(p192) -- name: setUnits
			-- upvalues: (ref) v_u_31, (ref) v_u_32, (ref) v_u_35, (ref) v_u_37, (copy) v_u_11, (ref) v_u_39, (ref) v_u_41, (ref) v_u_36, (ref) v_u_104
			local v193 = v_u_31 and (v_u_31.n or 1) or 1
			local v194 = v_u_32 and v_u_32.stack or 1
			local v195 = math.min(v193, v194)
			local v196 = math.max(1, v195)
			local v197 = math.floor(p192)
			v_u_35 = math.clamp(v197, 1, v196)
			if not v_u_37 then
				local v198 = v_u_11.suggest
				local v199 = {}
				local v200 = v_u_39
				if v200 then
					v200 = v_u_39.avg7
				end
				v199.avg7 = v200
				local v201 = v_u_39
				if v201 then
					v201 = v_u_39.min
				end
				v199.min = v201
				v199.pay = v_u_41
				local v202 = v198(v199, v_u_35)
				if v202 then
					v_u_36 = v202
				end
			end
			v_u_104()
		end
		local function v_u_220() -- name: openKeypadPanel
			-- upvalues: (ref) v_u_36, (copy) v_u_11, (ref) v_u_35, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (ref) v_u_39, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104
			local v_u_204 = nil
			local v_u_205 = nil
			local v_u_206 = nil
			local v219 = {
				["title"] = "Price",
				["width"] = 780,
				["build"] = nil,
				["buttons"] = nil,
				["build"] = function(p207) -- name: build
					-- upvalues: (ref) v_u_4, (ref) v_u_205, (ref) v_u_6, (ref) v_u_206, (ref) v_u_204, (ref) v_u_11, (ref) v_u_5, (ref) v_u_36, (ref) v_u_35, (ref) v_u_39, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104
					local v208 = v_u_4.new("Frame", {
						["Name"] = "Display",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 40)
					}, p207)
					v_u_205 = v_u_4.label({
						["parent"] = nil,
						["name"] = "Price",
						["text"] = "",
						["style"] = "monoL",
						["textSize"] = 30,
						["color"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v208,
						["color"] = v_u_6.accent,
						["size"] = UDim2.new(0.5, 0, 1, 0)
					})
					v_u_206 = v_u_4.label({
						["parent"] = nil,
						["name"] = "Each",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v208,
						["color"] = v_u_6.text2,
						["position"] = UDim2.fromScale(0.5, 0),
						["size"] = UDim2.new(0.5, 0, 1, 0)
					})
					local v209 = v_u_11.mount
					local v210 = {
						["ui"] = nil,
						["theme"] = nil,
						["price"] = nil,
						["n"] = nil,
						["cheapestUnit"] = nil,
						["keyCols"] = 6,
						["keyH"] = nil,
						["onChange"] = nil,
						["ui"] = v_u_4,
						["theme"] = v_u_5,
						["price"] = v_u_36,
						["n"] = v_u_35
					}
					local v211 = v_u_39
					if v211 then
						v211 = v_u_39.min
					end
					v210.cheapestUnit = v211
					v210.keyH = v_u_5.touch(44)
					function v210.onChange(p212) -- name: onChange
						-- upvalues: (ref) v_u_36, (ref) v_u_11, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104, (ref) v_u_205, (ref) v_u_206, (ref) v_u_35
						local v213 = math.floor(p212)
						local v214 = v_u_11.MAX_PRICE
						v_u_36 = math.clamp(v213, 0, v214)
						v_u_37 = true
						v_u_43 = nil
						v_u_104()
						if v_u_205 then
							v_u_205.Text = v_u_36 <= 0 and "$0" or v_u_11.money(v_u_36)
						end
						if v_u_206 then
							local v215 = v_u_206
							local v216 = v_u_11.unitText(v_u_36, v_u_35)
							v215.Text = not v216 and "" or ("= $%s each"):format(v216)
						end
					end
					v_u_204 = v209(p207, v210)
					v_u_204.frame.LayoutOrder = 2
					if v_u_205 then
						v_u_205.Text = v_u_36 <= 0 and "$0" or v_u_11.money(v_u_36)
					end
					if v_u_206 then
						local v217 = v_u_206
						local v218 = v_u_11.unitText(v_u_36, v_u_35)
						v217.Text = not v218 and "" or ("= $%s each"):format(v218)
					end
				end,
				["buttons"] = {
					{
						["text"] = "Done",
						["kind"] = "primary"
					}
				}
			}
			v_u_4.modal(v219)
		end
		local function v_u_345()
			-- upvalues: (copy) v_u_190, (ref) v_u_31, (ref) v_u_32, (copy) v_u_4, (copy) v_u_182, (copy) v_u_6, (ref) v_u_186, (ref) v_u_184, (copy) v_u_12, (ref) v_u_183, (copy) v_u_9, (ref) v_u_48, (copy) v_u_7, (ref) v_u_21, (copy) v_u_5, (ref) v_u_33, (copy) p_u_2, (copy) v_u_203, (ref) v_u_35, (ref) v_u_36, (copy) v_u_11, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104, (copy) v_u_220, (ref) v_u_39, (ref) v_u_191, (copy) v_u_10, (ref) v_u_25, (ref) v_u_28, (copy) v_u_153, (copy) v_u_14, (ref) v_u_34, (ref) v_u_38
			v_u_190()
			if v_u_31 and v_u_32 then
				local v221 = v_u_4.device() == "Keyboard"
				local v222 = 0
				local v223 = v_u_12 and 56 or 72
				local v224 = v_u_12 and 48 or 60
				local v225
				if v_u_12 then
					v225 = v_u_4.new("Frame", {
						["Name"] = "Head",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["Size"] = UDim2.new(1, -132, 1, 0)
					}, v_u_183)
				else
					local v226 = v_u_4.new
					local v227 = {
						["Name"] = "Head",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 64)
					}
					v222 = v222 + 1
					v227.LayoutOrder = v222
					v225 = v226("Frame", v227, v_u_182)
				end
				local _, v228 = v_u_9.icon(v225, v_u_32.id, v224)
				v_u_48.release = v228
				v_u_4.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "h3",
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v225,
					["text"] = v_u_32.name,
					["position"] = UDim2.fromOffset(v223, 0),
					["size"] = UDim2.new(1, -v223, 0, 24)
				})
				local v229 = v_u_7.condition
				local v230 = v_u_21
				local v231 = v_u_32.id
				local v232 = v_u_31.dur
				local v233
				if type(v232) == "number" then
					v233 = v_u_31.dur * 100
				else
					v233 = nil
				end
				local v234 = v229(v230, v231, v233, 70)
				local v235 = string.upper
				local v236 = v_u_21.RARITY_NAMES
				local v237 = v_u_21.shownRarity(v_u_32)
				local v238 = ("%s  \194\183  x%d in stash"):format(v235(v236[math.clamp(v237, 1, 6)]), v_u_31.n or 1)
				v_u_4.label({
					["parent"] = nil,
					["name"] = "Meta",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v225,
					["text"] = v238,
					["color"] = v_u_5.rarityColor(v_u_21.shownRarity(v_u_32)),
					["position"] = UDim2.fromOffset(v223, 26),
					["size"] = UDim2.new(1, -v223, 0, 16)
				})
				if v234 then
					v_u_9.condition(v225, v234, v_u_12 and 120 or 170, {
						["h"] = 14
					}).Position = UDim2.fromOffset(v223, v_u_12 and 42 or 46)
				end
				if v_u_33 and v_u_33 ~= "STRIP_FIRST" then
					local v239 = v_u_4.label
					local v240 = {
						["parent"] = nil,
						["name"] = "Why",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_182,
						["text"] = v_u_7.text(p_u_2.rules, v_u_33),
						["color"] = v_u_6.danger
					}
					v222 = v222 + 1
					v240.order = v222
					v239(v240)
					v_u_186.setEnabled(false)
					v_u_48.noForm = true
				else
					if (v_u_32.stack or 1) > 1 and (v_u_31.n or 1) > 1 then
						local v241 = v_u_4.new
						local v242 = {
							["Name"] = "Qty",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(40))
						}
						v222 = v222 + 1
						v242.LayoutOrder = v222
						local v243 = v241("Frame", v242, v_u_182)
						v_u_4.label({
							["parent"] = nil,
							["text"] = "AMOUNT",
							["style"] = "caps",
							["color"] = nil,
							["size"] = nil,
							["parent"] = v243,
							["color"] = v_u_6.text2,
							["size"] = UDim2.fromOffset(86, v_u_5.touch(40))
						})
						local v244 = v_u_5.touch(40)
						local function v245()
							-- upvalues: (ref) v_u_203, (ref) v_u_35
							v_u_203(v_u_35 - 1)
						end
						v_u_4.iconButton({
							["parent"] = nil,
							["icon"] = "minus",
							["size"] = nil,
							["kind"] = "secondary",
							["name"] = "Step_minus",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v243,
							["size"] = v244,
							["position"] = UDim2.fromOffset(90, 0),
							["onClick"] = v245
						})
						v_u_48.qtyLbl = v_u_4.label({
							["parent"] = nil,
							["name"] = "Units",
							["text"] = "",
							["style"] = "monoL",
							["textSize"] = 20,
							["align"] = "center",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["fit"] = true,
							["parent"] = v243,
							["position"] = UDim2.fromOffset(90 + v244 + 4, 0),
							["size"] = UDim2.fromOffset(70, v_u_5.touch(40))
						})
						local v246 = 90 + v244 + 4 + 70 + 4
						local function v247()
							-- upvalues: (ref) v_u_203, (ref) v_u_35
							v_u_203(v_u_35 + 1)
						end
						v_u_4.iconButton({
							["parent"] = nil,
							["icon"] = "plus",
							["size"] = nil,
							["kind"] = "secondary",
							["name"] = "Step_plus",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v243,
							["size"] = v244,
							["position"] = UDim2.fromOffset(v246, 0),
							["onClick"] = v247
						})
						local _, _ = v_u_9.button(v243, "Max", "secondary", function()
							-- upvalues: (ref) v_u_203
							v_u_203((1 / 0))
						end, {
							["name"] = "Step_Max",
							["height"] = 40,
							["width"] = 76,
							["position"] = nil,
							["position"] = UDim2.fromOffset(90 + v244 + 4 + 70 + 4 + v244 + 6, 0)
						})
					end
					local v248 = v_u_4.new
					local v249 = {
						["Name"] = "PriceRow",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(44))
					}
					v222 = v222 + 1
					v249.LayoutOrder = v222
					local v250 = v248("Frame", v249, v_u_182)
					v_u_4.label({
						["parent"] = nil,
						["text"] = "PRICE",
						["style"] = "caps",
						["color"] = nil,
						["size"] = nil,
						["parent"] = v250,
						["color"] = v_u_6.text2,
						["size"] = UDim2.fromOffset(86, v_u_5.touch(44))
					})
					if v221 then
						local _, v_u_251 = v_u_4.input({
							["parent"] = nil,
							["name"] = "PriceInput",
							["placeholder"] = "Price in Cash",
							["size"] = nil,
							["position"] = nil,
							["maxLength"] = 12,
							["parent"] = v250,
							["size"] = UDim2.new(1, -96, 0, v_u_5.touch(40)),
							["position"] = UDim2.fromOffset(90, 0)
						})
						local v_u_252 = false
						v_u_251.Text = v_u_36 <= 0 and "" or v_u_11.group(v_u_36)
						v_u_251:GetPropertyChangedSignal("Text"):Connect(function()
							-- upvalues: (copy) v_u_251, (ref) v_u_11, (ref) v_u_252, (ref) v_u_36, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104
							local v253 = string.gsub(v_u_251.Text, "[^%d]", "")
							local v254 = v_u_11.MAX_DIGITS
							local v255 = string.sub(v253, 1, v254)
							local v256 = tonumber(v255) or 0
							if v_u_11.MAX_PRICE < v256 then
								v256 = v_u_11.MAX_PRICE
							end
							local v257 = v256 <= 0 and "" or v_u_11.group(v256)
							if v_u_251.Text ~= v257 then
								v_u_252 = true
								v_u_251.Text = v257
								v_u_251.CursorPosition = #v_u_251.Text + 1
								v_u_252 = false
							end
							if v256 ~= v_u_36 then
								local v258 = math.floor(v256)
								local v259 = v_u_11.MAX_PRICE
								v_u_36 = math.clamp(v258, 0, v259)
								v_u_37 = true
								v_u_43 = nil
								v_u_104()
							end
						end)
						v_u_48.priceBox = v_u_251
					else
						local v260 = v_u_4.new("TextButton", {
							["Name"] = "PriceDisplay",
							["Text"] = "",
							["AutoButtonColor"] = false,
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["Selectable"] = nil,
							["BackgroundColor3"] = v_u_6.raised,
							["Position"] = UDim2.fromOffset(90, 0),
							["Size"] = UDim2.new(1, -96, 0, v_u_5.touch(44)),
							["Selectable"] = v_u_12
						}, v250)
						v260.SelectionImageObject = v_u_4.selectionImage()
						v_u_4.stroke(v260, v_u_6.lineStrong)
						v_u_48.priceLbl = v_u_4.label({
							["parent"] = nil,
							["name"] = "Value",
							["text"] = "",
							["style"] = "monoL",
							["textSize"] = 24,
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["fit"] = true,
							["parent"] = v260,
							["color"] = v_u_6.accent,
							["position"] = UDim2.fromOffset(12, 0),
							["size"] = UDim2.new(1, -24, 1, 0)
						})
						if v_u_12 then
							v260.Activated:Connect(function()
								-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_220
								v_u_4.sound(v_u_5.sounds.click)
								v_u_220()
							end)
							v_u_4.icon("chevronRight", {
								["parent"] = nil,
								["size"] = 14,
								["color"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["parent"] = v260,
								["color"] = v_u_6.text2,
								["position"] = UDim2.new(1, -12, 0.5, 0),
								["anchor"] = Vector2.new(1, 0.5)
							})
						end
					end
					local v261 = v_u_48
					local v262 = v_u_4.label
					local v263 = {
						["parent"] = nil,
						["name"] = "Each",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = false,
						["size"] = nil,
						["order"] = nil,
						["track"] = false,
						["parent"] = v_u_182,
						["color"] = v_u_6.text2,
						["size"] = UDim2.new(1, 0, 0, 16)
					}
					v222 = v222 + 1
					v263.order = v222
					v261.eachLbl = v262(v263)
					local v264 = v_u_48
					local v265 = v_u_4.label
					local v266 = {
						["parent"] = nil,
						["name"] = "Suggested",
						["text"] = "",
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["order"] = nil,
						["track"] = false,
						["parent"] = v_u_182,
						["color"] = v_u_6.info,
						["size"] = UDim2.new(1, 0, 0, 14)
					}
					v222 = v222 + 1
					v266.order = v222
					v264.sugLbl = v265(v266)
					if v221 or v_u_12 then
						if v221 then
							local v267 = v_u_48
							local v268 = v_u_11.mount
							local v269 = v_u_182
							local v270 = {
								["ui"] = nil,
								["theme"] = nil,
								["price"] = nil,
								["n"] = nil,
								["cheapestUnit"] = nil,
								["keys"] = false,
								["keyH"] = nil,
								["onChange"] = nil,
								["ui"] = v_u_4,
								["theme"] = v_u_5,
								["price"] = v_u_36,
								["n"] = v_u_35
							}
							local v271 = v_u_39
							if v271 then
								v271 = v_u_39.min
							end
							v270.cheapestUnit = v271
							v270.keyH = v_u_5.touch(36)
							function v270.onChange(p272) -- name: onChange
								-- upvalues: (ref) v_u_36, (ref) v_u_11, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104, (ref) v_u_48, (ref) v_u_191
								local v273 = math.floor(p272)
								local v274 = v_u_11.MAX_PRICE
								v_u_36 = math.clamp(v273, 0, v274)
								v_u_37 = true
								v_u_43 = nil
								v_u_104()
								if v_u_48.priceBox then
									local v275 = v_u_48.priceBox
									v_u_191 = true
									v275.Text = p272 <= 0 and "" or v_u_11.group(p272)
									v_u_191 = false
								end
							end
							v267.keypad = v268(v269, v270)
							local v276 = v_u_48.keypad.frame
							v222 = v222 + 1
							v276.LayoutOrder = v222
						end
					else
						local v277 = v_u_48
						local v278 = v_u_11.mount
						local v279 = v_u_182
						local v280 = {
							["ui"] = nil,
							["theme"] = nil,
							["price"] = nil,
							["n"] = nil,
							["cheapestUnit"] = nil,
							["keyCols"] = 6,
							["keyH"] = nil,
							["onChange"] = nil,
							["ui"] = v_u_4,
							["theme"] = v_u_5,
							["price"] = v_u_36,
							["n"] = v_u_35
						}
						local v281 = v_u_39
						if v281 then
							v281 = v_u_39.min
						end
						v280.cheapestUnit = v281
						v280.keyH = v_u_5.touch(44)
						function v280.onChange(p282) -- name: onChange
							-- upvalues: (ref) v_u_36, (ref) v_u_11, (ref) v_u_37, (ref) v_u_43, (ref) v_u_104
							local v283 = math.floor(p282)
							local v284 = v_u_11.MAX_PRICE
							v_u_36 = math.clamp(v283, 0, v284)
							v_u_37 = true
							v_u_43 = nil
							v_u_104()
						end
						v277.keypad = v278(v279, v280)
						local v285 = v_u_48.keypad.frame
						v222 = v222 + 1
						v285.LayoutOrder = v222
					end
					local v286 = v_u_182
					v222 = v222 + 1
					local v287 = v222
					v_u_10.section(v286, "Market", v287)
					local v288 = v_u_4.new
					local v289 = {
						["Name"] = "Market",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}
					v222 = v222 + 1
					v289.LayoutOrder = v222
					local v290 = v288("Frame", v289, v_u_182)
					v_u_48.market = {}
					local v291 = {
						{ "min", "CHEAPEST NOW" },
						{ "avg7", "7 DAY AVERAGE" },
						{ "last", "LAST SALE" },
						{ "pay", "TRADERS PAY" },
						{ "sells", "TRADERS SELL FOR" }
					}
					local v292
					if v_u_32 == nil then
						v292 = false
					else
						v292 = v_u_7.isCrateItem(v_u_32.id)
					end
					local v293 = v292 and {
						{ "min", "CHEAPEST NOW" },
						{ "avg7", "7 DAY AVERAGE" },
						{ "last", "LAST SALE" },
						{ "open", (v_u_7.crateSellModel(v_u_32.id, nil) or {
								["label"] = "CASH TO OPEN"
							}).label }
					} or v291
					if v_u_25 then
						table.insert(v293, { "bid", "BUY ORDERS" })
					end
					v_u_4.new("UIGridLayout", {
						["CellSize"] = UDim2.new(0.5, -4, 0, 48),
						["CellPadding"] = UDim2.fromOffset(8, 6),
						["SortOrder"] = Enum.SortOrder.LayoutOrder
					}, v290)
					for v294, v295 in v293 do
						local v296 = v_u_4.new("Frame", {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.2,
							["BorderSizePixel"] = 0,
							["LayoutOrder"] = nil,
							["Name"] = "M_" .. v295[1],
							["BackgroundColor3"] = v_u_6.raised,
							["LayoutOrder"] = v294
						}, v290)
						v_u_4.stroke(v296, v_u_6.line)
						v_u_4.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["fit"] = true,
							["parent"] = v296,
							["text"] = v295[2],
							["color"] = v_u_6.text2,
							["position"] = UDim2.fromOffset(8, 3),
							["size"] = UDim2.new(1, -16, 0, 16)
						})
						v_u_48.market[v295[1]] = v_u_4.label({
							["parent"] = nil,
							["name"] = "Value",
							["text"] = "",
							["style"] = "mono",
							["textSize"] = 14,
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["fit"] = true,
							["parent"] = v296,
							["color"] = v_u_6.text,
							["position"] = UDim2.fromOffset(8, 22),
							["size"] = UDim2.new(1, -16, 0, 22)
						})
						v_u_48.market[v295[1] .. "_cell"] = v296
					end
					local v297
					if v_u_32 == nil then
						v297 = false
					else
						v297 = v_u_7.isCrateItem(v_u_32.id)
					end
					if v297 and v_u_28 ~= nil then
						local v298 = v_u_153()
						local v299 = v_u_4.label
						local v300 = {
							["parent"] = nil,
							["name"] = "OddsNote",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_182,
							["text"] = not v298 and "" or v298.oddsNote,
							["color"] = v_u_6.text2
						}
						v222 = v222 + 1
						v300.order = v222
						v299(v300)
						local v301 = v_u_28.block
						local v302 = p_u_2
						local v303 = v_u_182
						local v304 = v_u_32.id
						local v305 = {
							["order"] = nil,
							["tight"] = true
						}
						v222 = v222 + 1
						v305.order = v222
						v301(v302, v303, v304, v305)
					end
					local v306 = v_u_48
					local v307 = v_u_4.label
					local v308 = {
						["parent"] = nil,
						["name"] = "MarketNote",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_182,
						["color"] = v_u_6.text2
					}
					v222 = v222 + 1
					v308.order = v222
					v306.marketNote = v307(v308)
					local v309 = v_u_9.paidOfInst(v_u_31, v_u_32)
					if v309.paid then
						local v310 = v_u_4.new
						local v311 = {
							["Name"] = "PaidRow",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["AutomaticSize"] = nil,
							["LayoutOrder"] = nil,
							["Size"] = UDim2.new(1, 0, 0, 0),
							["AutomaticSize"] = Enum.AutomaticSize.Y
						}
						v222 = v222 + 1
						v311.LayoutOrder = v222
						local v312 = v310("Frame", v311, v_u_182)
						v_u_4.layout(v312, "h", 8)
						v_u_9.paidPill(v312, v309, {
							["order"] = 1,
							["h"] = 20
						})
						if v309.line ~= nil then
							v_u_4.label({
								["parent"] = nil,
								["name"] = "PaidLine",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["size"] = nil,
								["order"] = 2,
								["parent"] = v312,
								["text"] = v309.line,
								["color"] = v_u_6.text2,
								["size"] = UDim2.new(1, -90, 0, 0)
							})
						end
						v312:SetAttribute("Insurable", v309.insurable == true)
						v_u_48.paidRow = v312
					end
					if v_u_25 then
						local v313 = v_u_9.button
						local v314 = v_u_182
						local function v315()
							-- upvalues: (ref) v_u_14
							v_u_14.sellNow()
						end
						local v316 = {
							["name"] = "SellNow",
							["order"] = nil,
							["height"] = 44,
							["maxTextWidth"] = 260
						}
						v222 = v222 + 1
						v316.order = v222
						local v317, v318 = v313(v314, "Sell now", "secondary", v315, v316)
						v_u_48.sellNow = {
							["btn"] = v317,
							["api"] = v318
						}
						local v319 = v_u_48
						local v320 = v_u_4.label
						local v321 = {
							["parent"] = nil,
							["name"] = "SellNowNote",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_182,
							["color"] = v_u_6.text2
						}
						v222 = v222 + 1
						v321.order = v222
						v319.sellNowNote = v320(v321)
					end
					if v_u_33 == "STRIP_FIRST" then
						local v322 = v_u_34 and v_u_34.mods or 0
						local v323 = v_u_48
						local v324 = v_u_9.toggleRow
						local v325 = v_u_182
						local v326 = ("Remove attachments first (%d)"):format(v322)
						local v327 = v_u_38
						local function v329(p328)
							-- upvalues: (ref) v_u_38, (ref) v_u_104
							v_u_38 = p328
							v_u_104()
						end
						v222 = v222 + 1
						v323.strip = v324(v325, v326, v327, v329, v222)
					end
					if v_u_31.ammo and v_u_31.ammo > 0 then
						local v330 = v_u_4.label
						local v331 = {
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_182,
							["text"] = ("The magazine (%d rounds) is emptied into your stash."):format(v_u_31.ammo),
							["color"] = v_u_6.text2
						}
						v222 = v222 + 1
						v331.order = v222
						v330(v331)
					end
					local v332 = v_u_48
					local v333 = v_u_4.label
					local v334 = {
						["parent"] = nil,
						["name"] = "Fee",
						["text"] = "",
						["style"] = "bodyStrong",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_182,
						["color"] = v_u_6.text
					}
					v222 = v222 + 1
					v334.order = v222
					v332.feeLbl = v333(v334)
					local v335 = v_u_48
					local v336 = v_u_4.label
					local v337 = {
						["parent"] = nil,
						["name"] = "ListFee",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["visible"] = false,
						["parent"] = v_u_182,
						["color"] = v_u_6.text2
					}
					v222 = v222 + 1
					v337.order = v222
					v335.listFeeLbl = v336(v337)
					local v338 = v_u_48
					local v339 = v_u_4.label
					local v340 = {
						["parent"] = nil,
						["name"] = "PriceCap",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["visible"] = false,
						["parent"] = v_u_182,
						["color"] = v_u_6.text2
					}
					v222 = v222 + 1
					v340.order = v222
					v338.capLbl = v339(v340)
					local v341 = v_u_48
					local v342 = v_u_4.label
					local v343 = {
						["parent"] = nil,
						["name"] = "Allow",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_182,
						["color"] = v_u_6.text2
					}
					v222 = v222 + 1
					v343.order = v222
					v341.allowLbl = v342(v343)
					v_u_14.formBuilt = true
				end
			else
				local v344 = v_u_4.new("Frame", {
					["Name"] = "Hint",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_182)
				v_u_4.layout(v344, "v", 8)
				v_u_4.pad(v344, {
					4,
					4,
					30,
					0
				})
				v_u_4.label({
					["parent"] = nil,
					["text"] = "Pick an item from your stash",
					["style"] = "h3",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 1,
					["parent"] = v344,
					["color"] = v_u_6.text
				})
				v_u_4.label({
					["parent"] = nil,
					["text"] = "It leaves your stash when you list it and comes back if nobody buys it or you cancel. You set the price in Cash.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v344,
					["color"] = v_u_6.text2
				})
				v_u_4.label({
					["parent"] = nil,
					["text"] = "Bright items can be listed. Dim items show why they cannot, select one to read it.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 3,
					["parent"] = v344,
					["color"] = v_u_6.muted
				})
				v_u_186.setEnabled(false)
				v_u_184.Text = ""
				return
			end
		end
		local function v_u_361(p346) -- name: marketText
			-- upvalues: (ref) v_u_39, (ref) v_u_40, (copy) v_u_6, (copy) v_u_7, (copy) p_u_2, (copy) v_u_153, (ref) v_u_41, (ref) v_u_42, (copy) v_u_9
			local v347 = v_u_39
			if v_u_40 == "down" or v_u_40 == "error" then
				return "Prices are not available", v_u_6.muted
			elseif p346 == "bid" then
				if v347 then
					local v348 = v347.bid
					if type(v348) == "table" then
						local v349 = v347.bid.u
						if type(v349) == "number" then
							local v350 = v347.bid.q
							if type(v350) == "number" then
								return ("best %s each, %s wanted"):format(v_u_7.unitMoney(v347.bid.u), v_u_7.commas(v347.bid.q)), v_u_6.text
							end
						end
					end
				end
				return v_u_7.text(p_u_2.rules, "NO_BIDS"), v_u_6.muted
			elseif p346 == "open" then
				local v351 = v_u_153()
				return not v351 and "" or v351.cashToOpen, v_u_6.text
			elseif p346 == "pay" then
				if v_u_41 then
					return v_u_7.unitMoney(v_u_41) .. " each", v_u_6.text
				else
					return "No trader buys it", v_u_6.muted
				end
			elseif p346 == "sells" then
				if v_u_42 then
					return v_u_7.unitMoney(v_u_42) .. " each", v_u_6.info
				else
					return "", v_u_6.muted
				end
			elseif v_u_40 == "ok" and v347 then
				if p346 == "min" then
					local v352 = v347.min
					if type(v352) == "number" then
						return v_u_7.unitMoney(v347.min) .. " each", v_u_6.text
					else
						return v_u_7.TEXT.noListings, v_u_6.muted
					end
				else
					if p346 == "avg7" then
						local v353 = v347.avg7
						if type(v353) == "number" then
							return v_u_7.unitMoney(v347.avg7) .. " each", v_u_6.text
						end
						local v354
						if (v347.sold7 or 0) > 0 then
							v354 = v_u_7.TEXT.notEnoughSales
						else
							v354 = v_u_7.TEXT.noSales
						end
						return v354, v_u_6.muted
					end
					if p346 ~= "last" then
						return "", v_u_6.text
					end
					local v355 = v347.last
					if type(v355) ~= "number" then
						return v_u_7.TEXT.noSales, v_u_6.muted
					end
					local v356 = v_u_9.serverNow()
					local v357
					if v356 then
						local v358 = v347.lastAt
						if type(v358) == "number" then
							local v359 = v_u_7.ago
							local v360 = v356 - v347.lastAt
							v357 = "  " .. v359((math.max(0, v360)))
						else
							v357 = ""
						end
					else
						v357 = ""
					end
					return v_u_7.unitMoney(v347.last) .. v357, v_u_6.text
				end
			else
				return "...", v_u_6.muted
			end
		end
		local function v_u_413()
			-- upvalues: (ref) v_u_44, (copy) p_u_2, (copy) v_u_62, (copy) v_u_12, (copy) v_u_61, (copy) v_u_6, (copy) v_u_60, (ref) v_u_31, (ref) v_u_32, (ref) v_u_48, (ref) v_u_186, (ref) v_u_184, (ref) v_u_35, (ref) v_u_36, (copy) v_u_11, (ref) v_u_191, (ref) v_u_43, (copy) v_u_7, (copy) v_u_153, (ref) v_u_39, (copy) v_u_361, (ref) v_u_42, (ref) v_u_40, (copy) v_u_14, (copy) v_u_167, (copy) v_u_8, (copy) v_u_175, (ref) v_u_45, (copy) v_u_182
			if v_u_44 and os.clock() > v_u_44.untilT then
				v_u_44 = nil
			end
			local v362 = p_u_2.state
			local v363
			if type(v362) == "table" then
				local v364 = v362.tune
				v363 = type(v364) ~= "table" and {} or v362.tune
			else
				v363 = {}
			end
			local v365
			if type(v362) == "table" then
				local v366 = v362.allow
				if type(v366) == "table" then
					v365 = v362.allow
				else
					v365 = nil
				end
			else
				v365 = nil
			end
			if v365 then
				local v367 = v365.used or 0
				local v368 = v365.limit or 3
				local v369 = v_u_62
				local v370
				if v_u_12 then
					v370 = ("LISTINGS %d / %d"):format(v367, v368)
				else
					v370 = ("LISTINGS TODAY %d / %d"):format(v367, v368)
				end
				v369.Text = v370
				local v371 = v365.left or (v365.limit or 3) - (v365.used or 0)
				local v372 = v_u_61
				local v373
				if v371 <= 0 then
					v373 = v_u_6.danger
				else
					v373 = v_u_6.line
				end
				v372.Color = v373
				local v374 = v_u_62
				local v375
				if v371 <= 0 then
					v375 = v_u_6.danger
				else
					v375 = v_u_6.text
				end
				v374.TextColor3 = v375
				v_u_60:SetAttribute("Allow", ("%d/%d"):format(v367, v368))
			else
				v_u_62.Text = "LISTINGS TODAY"
			end
			if v_u_31 and (v_u_32 and not v_u_48.noForm) then
				if v_u_48.qtyLbl then
					local v376 = v_u_35
					v_u_48.qtyLbl.Text = tostring(v376)
				end
				if v_u_48.priceLbl then
					v_u_48.priceLbl.Text = v_u_36 <= 0 and "$0" or v_u_11.money(v_u_36)
					local v377 = v_u_48.priceLbl
					local v378
					if v_u_36 > 0 then
						v378 = v_u_6.accent
					else
						v378 = v_u_6.muted
					end
					v377.TextColor3 = v378
				end
				if v_u_48.priceBox and not v_u_48.priceBox:IsFocused() then
					v_u_191 = true
					v_u_48.priceBox.Text = v_u_36 <= 0 and "" or v_u_11.group(v_u_36)
					v_u_191 = false
				end
				if v_u_48.eachLbl then
					local v379 = v_u_48.eachLbl
					local v380 = v_u_11.unitText(v_u_36, v_u_35)
					v379.Text = not v380 and "" or ("= $%s each"):format(v380)
				end
				if v_u_48.sugLbl then
					local v381 = v_u_43
					local v382 = v_u_48.sugLbl
					local v383
					if v381 == "avg7" then
						v383 = "Suggested: the 7 day average"
					elseif v381 == "min" then
						v383 = "Suggested: the cheapest listing"
					elseif v381 == "pay" then
						v383 = "Suggested: what traders pay, plus a little"
					else
						local v384
						if v_u_32 == nil then
							v384 = false
						else
							v384 = v_u_7.isCrateItem(v_u_32.id)
						end
						v383 = v384 and v_u_36 == 0 and ((v_u_153() or {
							["hint"] = ""
						}).hint or "") or ""
					end
					v382.Text = v383
				end
				if v_u_48.keypad then
					v_u_48.keypad.set(v_u_36)
					v_u_48.keypad.setN(v_u_35)
					local v385 = v_u_48.keypad.setCheapest
					local v386 = v_u_39
					if v386 then
						v386 = v_u_39.min
					end
					v385(v386)
				end
				if v_u_48.market then
					for _, v387 in {
						"min",
						"avg7",
						"last",
						"pay",
						"sells",
						"bid",
						"open"
					} do
						local v388 = v_u_48.market[v387]
						if not v388 then
							continue
						end
						local v389, v390 = v_u_361(v387)
						v388.Text = v389
						v388.TextColor3 = v390
					end
					local v391 = v_u_48.market.sells_cell
					if v391 then
						v391.Visible = v_u_42 ~= nil
					end
				end
				if v_u_48.marketNote then
					v_u_48.marketNote.Text = (v_u_40 == "down" or v_u_40 == "error") and "Prices are not available right now. You can still list, the price is yours to set." or ""
					v_u_48.marketNote.Visible = v_u_48.marketNote.Text ~= ""
				end
				if v_u_48.sellNow then
					local v392, v393 = v_u_14.canSellNow()
					v_u_48.sellNow.api.setEnabled(v392)
					v_u_48.sellNowNote.Text = v393 or ""
					v_u_48.sellNowNote.Visible = (v393 or "") ~= ""
				end
				if v_u_48.feeLbl then
					if v_u_36 >= 1 then
						local v394, v395 = v_u_11.fee(v_u_36, v363.feePct or 5)
						v_u_48.feeLbl.Text = ("Fee %d percent: you receive %s"):format(v363.feePct or 5, v_u_7.money(v395))
						v_u_48.feeLbl:SetAttribute("Fee", v394)
					else
						v_u_48.feeLbl.Text = ("Fee %d percent of the price."):format(v363.feePct or 5)
					end
				end
				if v_u_48.listFeeLbl or v_u_48.capLbl then
					local v396, v397 = v_u_167()
					if v_u_48.listFeeLbl then
						local v398 = v_u_7.listFeeLine(v396.fee, v397)
						v_u_48.listFeeLbl.Text = v398 or ""
						v_u_48.listFeeLbl.Visible = v398 ~= nil
						local v399 = v_u_48.listFeeLbl
						local v400
						if v396.short > 0 then
							v400 = v_u_6.danger
						else
							v400 = v_u_6.text2
						end
						v399.TextColor3 = v400
						v_u_48.listFeeLbl:SetAttribute("ListFee", v396.fee)
					end
					if v_u_48.capLbl then
						local v401 = v_u_7.listCapLine(v396)
						v_u_48.capLbl.Text = v401 or ""
						v_u_48.capLbl.Visible = v401 ~= nil
						local v402 = v_u_48.capLbl
						local v403
						if v396.capHit then
							v403 = v_u_6.danger
						else
							v403 = v_u_6.text2
						end
						v402.TextColor3 = v403
						v_u_48.capLbl:SetAttribute("Cap", v396.cap or 0)
					end
				end
				if v_u_48.allowLbl then
					local v404 = v365 and (v365.used or 0) or 0
					local v405 = v365 and (v365.limit or 3) or 3
					local v406
					if v365 and (v365.left or (v365.limit or 3) - (v365.used or 0)) <= 0 then
						local v407 = v_u_7.left({
							["resetIn"] = v365.resetIn,
							["_at"] = v362._at
						}, "resetIn", v_u_8:clock())
						v406 = v_u_7.duration(v407)
					else
						v406 = ""
					end
					v_u_48.allowLbl.Text = v_u_7.sellAllowLine(v404, v405, v365, v406)
				end
				local v408 = v_u_175()
				v_u_186.setEnabled(v408.enabled == true)
				local v409 = v_u_184
				local v410
				if v_u_44 then
					v410 = v_u_44.text
				else
					v410 = v408.reason or ""
				end
				v409.Text = v410
				local v411 = v_u_184
				local v412
				if v_u_44 then
					v412 = v_u_44.color
				else
					v412 = v_u_6.accent
				end
				v411.TextColor3 = v412
				v_u_186.setText(v_u_45 and "Listing" or "List")
				v_u_182:SetAttribute("Eval", v408.code or (v408.enabled and "OK" or "NONE"))
			else
				if v_u_31 and v_u_48.noForm then
					v_u_186.setEnabled(false)
				end
				v_u_184.Text = ""
				v_u_186.setText("List")
			end
		end
		local function v_u_423() -- name: loadQuote
			-- upvalues: (ref) v_u_32, (ref) v_u_46, (ref) v_u_39, (ref) v_u_40, (ref) v_u_41, (copy) v_u_7, (copy) p_u_2, (ref) v_u_35, (ref) v_u_31, (ref) v_u_42, (ref) v_u_413, (copy) v_u_8, (ref) v_u_15, (ref) v_u_37, (copy) v_u_11, (ref) v_u_36, (ref) v_u_43
			if v_u_32 then
				v_u_46 = v_u_46 + 1
				local v_u_414 = v_u_46
				v_u_39 = nil
				v_u_40 = "loading"
				v_u_41 = v_u_7.traderPay(p_u_2.mc, v_u_32.id, v_u_35, v_u_31)
				v_u_42 = v_u_7.traderSells(p_u_2.mc, v_u_32.id)
				local v415
				if v_u_32 == nil then
					v415 = false
				else
					v415 = v_u_7.isCrateItem(v_u_32.id)
				end
				if v415 then
					v_u_41 = nil
					v_u_42 = nil
				end
				v_u_413()
				task.spawn(function()
					-- upvalues: (ref) v_u_8, (ref) v_u_32, (copy) v_u_414, (ref) v_u_46, (ref) v_u_15, (ref) v_u_39, (ref) v_u_40, (ref) v_u_37, (ref) v_u_11, (ref) v_u_41, (ref) v_u_35, (ref) v_u_36, (ref) v_u_43, (ref) v_u_413
					local v416 = v_u_8:quote(v_u_32.id)
					if v_u_414 == v_u_46 and v_u_15 then
						if v416.ok then
							v_u_39 = v416
							v_u_40 = "ok"
							if not v_u_37 then
								local v417, v418 = v_u_11.suggest({
									["avg7"] = v416.avg7,
									["min"] = v416.min,
									["pay"] = v_u_41
								}, v_u_35)
								if v417 then
									v_u_36 = v417
									v_u_43 = v418
								end
							end
						else
							local v419 = (v416.code == "STORE" or v416.ds == "down") and "down" or "error"
							v_u_39 = nil
							v_u_40 = v419
							if not v_u_37 then
								local v420 = {
									["pay"] = v_u_41
								}
								local v421, v422 = v_u_11.suggest(v420, v_u_35)
								if v421 then
									v_u_36 = v421
									v_u_43 = v422
								end
							end
						end
						v_u_413()
					end
				end)
			end
		end
		v_u_103 = function(p424)
			-- upvalues: (ref) v_u_48, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_43, (ref) v_u_39, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_44, (copy) v_u_8, (copy) v_u_10, (copy) v_u_17, (copy) v_u_75, (copy) v_u_47, (ref) v_u_345, (copy) v_u_423, (ref) v_u_413, (copy) p_u_3
			if v_u_48.release then
				v_u_48.release()
				v_u_48.release = nil
			end
			v_u_30 = nil
			v_u_31 = nil
			v_u_32 = nil
			v_u_33 = nil
			v_u_34 = nil
			v_u_35 = 1
			v_u_36 = 0
			v_u_37 = false
			v_u_38 = false
			v_u_43 = nil
			v_u_39 = nil
			v_u_40 = "idle"
			v_u_41 = nil
			v_u_42 = nil
			v_u_44 = nil
			if p424 then
				for _, v425 in v_u_8:stash() do
					if v425.uid ~= p424 then
						continue
					end
					v_u_31 = v425
				end
				if v_u_31 then
					v_u_30 = p424
					v_u_32 = v_u_10.itemDef(v_u_31.id)
					local v426 = v_u_31
					local v427, v428, v429 = v_u_17.checkInst(v426, (v_u_75(v426)))
					if v427 then
						v428 = nil
					end
					v_u_33 = v428
					v_u_34 = v429
					v_u_35 = 1
					if v_u_32 and (v_u_32.stack or 1) > 1 then
						local v430 = v_u_31.n or 1
						local v431 = v_u_32.stack or 1
						local v432 = math.min(v430, v431)
						v_u_35 = math.max(1, v432)
					end
					local v433 = v_u_31.mods
					if type(v433) == "table" and next(v_u_31.mods) ~= nil then
						v_u_38 = false
					end
				end
			end
			for _, v434 in v_u_47 do
				v434.ring.Visible = v434.inst.uid == v_u_30
			end
			v_u_345()
			if v_u_31 and (v_u_32 and (not v_u_33 or v_u_33 == "STRIP_FIRST")) then
				v_u_423()
			else
				v_u_413()
			end
			p_u_3:SetAttribute("Selected", v_u_30 or "")
		end
		function v_u_14.canSellNow() -- name: canSellNow
			-- upvalues: (ref) v_u_31, (ref) v_u_32, (ref) v_u_25, (ref) v_u_33, (copy) v_u_7, (copy) p_u_2, (ref) v_u_23, (ref) v_u_40, (ref) v_u_39
			if not (v_u_31 and (v_u_32 and v_u_25)) then
				return false, nil
			end
			if v_u_33 and v_u_33 ~= "STRIP_FIRST" then
				return false, v_u_7.text(p_u_2.rules, v_u_33)
			end
			local v435 = true
			local v436 = nil
			if v_u_23 then
				local v437 = v_u_23.gate
				if type(v437) == "function" then
					v435, v436 = v_u_23.gate(p_u_2.state, v_u_7, p_u_2.rules)
				end
			end
			if not v435 then
				return false, v436
			end
			if v_u_40 ~= "ok" then
				return false, nil
			end
			local v438 = v_u_39
			if v438 then
				local v439 = v438.bid
				if type(v439) == "table" then
					local v440 = v438.bid.u
					if type(v440) == "number" then
						return true, nil
					end
				end
			end
			return false, v_u_7.text(p_u_2.rules, "NO_BIDS")
		end
		local function v_u_446(p441) -- name: afterSellNow
			-- upvalues: (ref) v_u_15, (copy) v_u_14, (copy) p_u_2, (ref) v_u_30, (ref) v_u_31, (ref) v_u_103, (copy) v_u_423
			if v_u_15 then
				v_u_14.queueStash(true)
				p_u_2.refreshState(true)
				if p441 and p441.ok then
					local v442 = p441.data
					local v443
					if type(v442) == "table" then
						local v444 = p441.data.sold
						v443 = type(v444) ~= "number" and 0 or p441.data.sold
					else
						v443 = 0
					end
					local v445 = v_u_30
					if v445 and (v_u_31 and v_u_31.n or 1) - v443 <= 0 then
						v_u_103(nil)
						return
					end
					if v445 then
						v_u_423()
					end
				end
			end
		end
		function v_u_14.sellNow() -- name: sellNow
			-- upvalues: (copy) v_u_14, (copy) v_u_4, (copy) v_u_5, (ref) v_u_23, (copy) p_u_2, (ref) v_u_31, (ref) v_u_32, (ref) v_u_39, (ref) v_u_33, (copy) v_u_446
			if v_u_14.canSellNow() then
				local v447 = v_u_14
				local v448 = v_u_23.openSellNow
				local v449 = p_u_2
				local v450 = {
					["inst"] = v_u_31,
					["def"] = v_u_32
				}
				local v451 = v_u_39
				if v451 then
					v451 = v_u_39.bid
				end
				v450.best = v451
				v450.strip = v_u_33 == "STRIP_FIRST"
				v450.onDone = v_u_446
				v447.sellNowApi = v448(v449, v450)
			else
				v_u_4.sound(v_u_5.sounds.error)
			end
		end
		local function v_u_456(p452) -- name: afterList
			-- upvalues: (ref) v_u_45, (ref) v_u_15, (copy) p_u_2, (ref) v_u_44, (copy) v_u_7, (copy) v_u_6, (ref) v_u_32, (ref) v_u_103, (copy) v_u_14, (ref) v_u_413
			v_u_45 = false
			if v_u_15 then
				if p452.ok then
					local v_u_453 = nil
					local function v454()
						-- upvalues: (ref) v_u_453, (ref) p_u_2
						v_u_453 = p_u_2.mc.cctx.controllers.BmNotes
					end
					pcall(v454)
					if p452.state == "processing" then
						v_u_44 = {
							["text"] = p452.text ~= "" and p452.text or v_u_7.TEXT.workingList,
							["color"] = v_u_6.info,
							["untilT"] = os.clock() + 10
						}
					else
						if v_u_453 and (v_u_453.quiet and v_u_32) then
							v_u_453.quiet("listed", v_u_32.id)
						end
						v_u_44 = {
							["text"] = v_u_7.TEXT.listed,
							["color"] = v_u_6.success,
							["untilT"] = os.clock() + 8
						}
					end
					local v455 = v_u_44
					v_u_103(nil)
					v_u_44 = v455
					v_u_14.queueStash(true)
					p_u_2.refreshState(true)
					v_u_413()
				else
					v_u_44 = {
						["text"] = p452.text,
						["color"] = v_u_6.danger,
						["untilT"] = os.clock() + 12
					}
					p_u_2.refreshState(true)
					v_u_413()
				end
			else
				return
			end
		end
		local function v_u_486() -- name: openConfirm
			-- upvalues: (ref) v_u_31, (ref) v_u_32, (ref) v_u_35, (copy) v_u_159, (copy) v_u_11, (ref) v_u_36, (copy) v_u_7, (copy) v_u_6, (ref) v_u_45, (ref) v_u_413, (ref) v_u_38, (ref) v_u_33, (copy) v_u_456, (copy) v_u_8, (copy) v_u_14, (copy) v_u_4, (copy) p_u_2, (copy) v_u_167, (copy) v_u_5
			if v_u_31 and v_u_32 then
				local v457
				if v_u_35 > 1 then
					v457 = ("%d x %s"):format(v_u_35, v_u_32.name)
				else
					v457 = v_u_32.name
				end
				local v458 = v_u_159()
				local v_u_459 = v_u_11.warn(v_u_36, v_u_35, v458)
				local v_u_460 = v_u_459 == nil
				local v_u_461 = nil
				local v_u_462 = nil
				local v_u_463 = ("List %s for %s?"):format(v457, v_u_7.money(v_u_36))
				local v466 = {
					{
						["text"] = "Cancel",
						["kind"] = "secondary"
					},
					{
						["text"] = "List",
						["kind"] = "primary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_460, (ref) v_u_461, (ref) v_u_462, (ref) v_u_6, (ref) v_u_45, (ref) v_u_413, (ref) v_u_31, (ref) v_u_35, (ref) v_u_36, (ref) v_u_38, (ref) v_u_33, (ref) v_u_456, (ref) v_u_8
							if not v_u_460 then
								v_u_460 = true
								if v_u_461 then
									v_u_461.setText("Confirm price")
								end
								if v_u_462 then
									v_u_462.TextColor3 = v_u_6.danger
								end
								return true
							end
							if v_u_45 then
								return false
							end
							v_u_45 = true
							v_u_413()
							local v_u_464 = {
								["uid"] = v_u_31.uid,
								["n"] = v_u_35,
								["price"] = v_u_36
							}
							local v465 = v_u_38
							if v465 then
								v465 = v_u_33 == "STRIP_FIRST"
							end
							v_u_464.strip = v465
							task.spawn(function()
								-- upvalues: (ref) v_u_456, (ref) v_u_8, (copy) v_u_464
								v_u_456(v_u_8:list(v_u_464))
							end)
							return false
						end
					}
				}
				v_u_14.confirmButtons = v466
				local v479 = {
					["title"] = "List item",
					["width"] = 500,
					["build"] = nil,
					["buttons"] = nil,
					["build"] = function(p467) -- name: build
						-- upvalues: (ref) v_u_4, (copy) v_u_463, (ref) v_u_6, (ref) v_u_11, (ref) v_u_36, (ref) v_u_35, (ref) p_u_2, (ref) v_u_38, (ref) v_u_33, (ref) v_u_7, (ref) v_u_167, (copy) v_u_459, (ref) v_u_462
						v_u_4.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 1,
							["parent"] = p467,
							["text"] = v_u_463,
							["color"] = v_u_6.text
						})
						local v468 = v_u_11.unitText(v_u_36, v_u_35)
						if v468 then
							v_u_4.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 2,
								["parent"] = p467,
								["text"] = ("That is $%s each."):format(v468),
								["color"] = v_u_6.text2
							})
						end
						v_u_4.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 3,
							["parent"] = p467,
							["text"] = ("It leaves your stash now and comes back if you cancel or it expires in %d days.%s"):format(p_u_2.state and (p_u_2.state.tune and p_u_2.state.tune.listingDays) or 3, v_u_38 and v_u_33 == "STRIP_FIRST" and " Its attachments go back to your gear." or ""),
							["color"] = v_u_6.text2
						})
						local _, v469 = v_u_11.fee(v_u_36, p_u_2.state and (p_u_2.state.tune and p_u_2.state.tune.feePct) or 5)
						v_u_4.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 4,
							["parent"] = p467,
							["text"] = ("You receive %s after the fee."):format(v_u_7.money(v469)),
							["color"] = v_u_6.text
						})
						local v470 = v_u_167()
						for v471, v472 in v_u_7.listConfirmLines(v470) do
							v_u_4.label({
								["parent"] = nil,
								["name"] = nil,
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = p467,
								["name"] = v471 == 1 and "ListFee" or "PriceCap",
								["text"] = v472,
								["color"] = v_u_6.text,
								["order"] = 4 + v471
							})
						end
						local v473 = v_u_7.confirmSlotLine
						local v474 = v_u_36
						local v475 = p_u_2.state and p_u_2.state.tune
						if v475 then
							v475 = p_u_2.state.tune.feePct
						end
						local v476 = p_u_2.state
						if v476 then
							v476 = p_u_2.state.allow
						end
						local v477 = v473(v474, v475, v476)
						v_u_4.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 7,
							["parent"] = p467,
							["text"] = v477,
							["color"] = v_u_6.text2
						})
						if v_u_459 then
							local v478 = v_u_459 == "low" and "Far below the usual price. Check for a missing digit." or "Far above the usual price. Check for an extra digit."
							v_u_462 = v_u_4.label({
								["parent"] = nil,
								["name"] = "Warning",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 8,
								["parent"] = p467,
								["text"] = v478,
								["color"] = v_u_6.danger
							})
						end
					end,
					["buttons"] = v466
				}
				local v_u_480 = v_u_4.modal(v479)
				v_u_14.confirmApi = v_u_480
				task.defer(function()
					-- upvalues: (ref) v_u_480, (ref) v_u_461, (ref) v_u_5, (copy) v_u_459
					if v_u_480 and v_u_480.frame then
						local v481 = v_u_480.frame:FindFirstChild("Buttons", true)
						local v482 = nil
						if v481 then
							for _, v483 in v481:GetChildren() do
								if not v483:IsA("TextButton") or v482 ~= nil and v483.LayoutOrder <= v482.LayoutOrder then
									continue
								end
								v482 = v483
							end
						end
						local v_u_484
						if v482 then
							v_u_484 = v482:FindFirstChild("Text", true)
						else
							v_u_484 = nil
						end
						if v_u_484 and v_u_484:IsA("TextLabel") then
							v_u_461 = {
								["setText"] = function(p485) -- name: setText
									-- upvalues: (copy) v_u_484, (ref) v_u_5
									v_u_484.Text = v_u_5.track(string.upper(p485), 1)
								end
							}
							if v_u_459 then
								v_u_461.setText("List anyway")
							end
						end
					end
				end)
			end
		end
		function v_u_14.pressConfirm(p487) -- name: pressConfirm
			-- upvalues: (copy) v_u_14
			for _, v_u_488 in v_u_14.confirmButtons or {} do
				if v_u_488.text ~= p487 then
					continue
				end
				task.spawn(function()
					-- upvalues: (copy) v_u_488, (ref) v_u_14
					local v489, v490
					if v_u_488.onClick then
						local v491 = v_u_488.onClick
						v489, v490 = pcall(v491)
					else
						v489 = true
						v490 = nil
					end
					if (not v489 or v490 ~= true) and v_u_14.confirmApi then
						v_u_14.confirmApi.close()
					end
				end)
				return true
			end
			return false
		end
		v_u_14.openKeypad = v_u_220
		function v_u_14.listNow() -- name: listNow
			-- upvalues: (copy) v_u_175, (copy) v_u_4, (copy) v_u_5, (ref) v_u_44, (copy) v_u_6, (ref) v_u_413, (ref) v_u_39, (ref) v_u_25, (ref) v_u_35, (ref) v_u_36, (copy) v_u_14, (copy) v_u_486, (copy) v_u_7
			local v492 = v_u_175()
			if v492.enabled then
				local v_u_493
				if v_u_39 then
					local v494 = v_u_39.bid
					if type(v494) == "table" then
						v_u_493 = v_u_39.bid
					else
						v_u_493 = nil
					end
				else
					v_u_493 = nil
				end
				if v_u_25 and v_u_493 then
					local v495 = v_u_493.u
					if type(v495) == "number" and (v_u_35 >= 1 and (v_u_36 / v_u_35 <= v_u_493.u and v_u_14.canSellNow())) then
						local v496 = {
							{
								["text"] = "Cancel",
								["kind"] = "secondary"
							},
							{
								["text"] = "List anyway",
								["kind"] = "secondary",
								["onClick"] = nil,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_486
									task.defer(v_u_486)
								end
							},
							{
								["text"] = "Sell now",
								["kind"] = "primary",
								["onClick"] = nil,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_14
									task.defer(function()
										-- upvalues: (ref) v_u_14
										v_u_14.sellNow()
									end)
								end
							}
						}
						v_u_14.crossButtons = v496
						local v498 = {
							["title"] = "A buy order is waiting",
							["width"] = 500,
							["build"] = nil,
							["buttons"] = nil,
							["build"] = function(p497) -- name: build
								-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) v_u_493, (ref) v_u_6
								v_u_4.label({
									["parent"] = nil,
									["name"] = "Ask",
									["text"] = nil,
									["style"] = "bodyStrong",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = 1,
									["parent"] = p497,
									["text"] = ("A buy order of %s each is waiting. Sell now at %s each?"):format(v_u_7.unitMoney(v_u_493.u), v_u_7.unitMoney(v_u_493.u)),
									["color"] = v_u_6.text
								})
								v_u_4.label({
									["parent"] = nil,
									["name"] = "Note",
									["text"] = "You get the price of the order, never less than you asked. No listing slot is used.",
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = 2,
									["parent"] = p497,
									["color"] = v_u_6.text2
								})
							end,
							["buttons"] = v496
						}
						v_u_14.crossApi = v_u_4.modal(v498)
						return
					end
				end
				v_u_486()
			else
				v_u_4.sound(v_u_5.sounds.error)
				if v492.reason then
					v_u_44 = {
						["text"] = v492.reason,
						["color"] = v_u_6.accent,
						["untilT"] = os.clock() + 6
					}
					v_u_413()
				end
			end
		end
		local v499 = {
			["Disconnect"] = v_u_4.onDevice(function()
				-- upvalues: (ref) v_u_31, (ref) v_u_15, (ref) v_u_16, (ref) v_u_345, (ref) v_u_413
				if v_u_31 and (v_u_15 and v_u_16) then
					v_u_345()
					v_u_413()
				end
			end)
		}
		table.insert(v_u_20, v499)
		local v500 = {
			["Disconnect"] = p_u_2.onState(function()
				-- upvalues: (ref) v_u_16, (copy) v_u_14, (ref) v_u_413
				if v_u_16 then
					v_u_14.queueStash(true)
					v_u_413()
				end
			end)
		}
		table.insert(v_u_20, v500)
		local v501 = {
			["Disconnect"] = p_u_2.onTick(function()
				-- upvalues: (ref) v_u_16, (ref) v_u_413
				if v_u_16 then
					v_u_413()
				end
			end)
		}
		table.insert(v_u_20, v501)
		function v_u_14.show() -- name: show
			-- upvalues: (ref) v_u_16, (copy) v_u_146, (ref) v_u_345, (ref) v_u_413
			v_u_16 = true
			v_u_146()
			v_u_345()
			v_u_413()
		end
		function v_u_14.hide() -- name: hide
			-- upvalues: (ref) v_u_16
			v_u_16 = false
		end
		function v_u_14.refresh(p502) -- name: refresh
			-- upvalues: (ref) v_u_16, (copy) v_u_14
			if p502 == "profile" and v_u_16 then
				v_u_14.queueStash(false)
			end
		end
		function v_u_14.reload() -- name: reload
			-- upvalues: (ref) v_u_32, (copy) v_u_423, (copy) v_u_14
			if v_u_32 then
				v_u_423()
			end
			v_u_14.queueStash(true)
		end
		function v_u_14.onNote(_) -- name: onNote
			-- upvalues: (ref) v_u_16, (copy) v_u_14
			if v_u_16 then
				v_u_14.queueStash(false)
			end
		end
		function v_u_14.select(p503) -- name: select
			-- upvalues: (copy) v_u_8, (ref) v_u_103
			for _, v504 in v_u_8:stash() do
				if v504.uid ~= p503 and v504.id ~= p503 then
					continue
				end
				v_u_103(v504.uid)
				return
			end
		end
		function v_u_14.setPrice(p505) -- name: setPrice
			-- upvalues: (ref) v_u_36, (copy) v_u_11, (ref) v_u_37, (ref) v_u_43, (ref) v_u_413
			local v506 = math.floor(p505)
			local v507 = v_u_11.MAX_PRICE
			v_u_36 = math.clamp(v506, 0, v507)
			v_u_37 = true
			v_u_43 = nil
			v_u_413()
		end
		function v_u_14.setStrip(p508) -- name: setStrip
			-- upvalues: (ref) v_u_38, (ref) v_u_48, (ref) v_u_413
			local v509 = (p508 == true or p508 == "true") and true or p508 == 1
			v_u_38 = v509
			if v_u_48.strip and v_u_48.strip.set then
				v_u_48.strip.set(v509)
			end
			v_u_413()
		end
		function v_u_14.setQty(p510) -- name: setQty
			-- upvalues: (copy) v_u_203
			v_u_203(p510)
		end
		function v_u_14.state() -- name: state
			-- upvalues: (ref) v_u_30, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_40, (copy) v_u_175, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (copy) v_u_47, (ref) v_u_38, (ref) v_u_44
			return {
				["uid"] = v_u_30,
				["units"] = v_u_35,
				["price"] = v_u_36,
				["touched"] = v_u_37,
				["quote"] = v_u_40,
				["eval"] = v_u_175(),
				["pay"] = v_u_41,
				["sells"] = v_u_42,
				["suggested"] = v_u_43,
				["tiles"] = #v_u_47,
				["strip"] = v_u_38,
				["status"] = v_u_44 and v_u_44.text or nil
			}
		end
		function v_u_14.tiles() -- name: tiles
			-- upvalues: (copy) v_u_47
			local v511 = {}
			for _, v512 in v_u_47 do
				local v513 = {
					["uid"] = v512.inst.uid,
					["id"] = v512.inst.id,
					["ok"] = v512.ok,
					["code"] = v512.code,
					["cell"] = v512.cell
				}
				table.insert(v511, v513)
			end
			return v511
		end
		function v_u_14.form() -- name: form
			-- upvalues: (copy) v_u_182, (ref) v_u_48, (ref) v_u_185, (ref) v_u_186, (ref) v_u_184
			return {
				["scroll"] = v_u_182,
				["w"] = v_u_48,
				["list"] = v_u_185,
				["listApi"] = v_u_186,
				["reason"] = v_u_184
			}
		end
		function v_u_14.setQuery(p514) -- name: setQuery
			-- upvalues: (ref) v_u_19, (copy) v_u_59, (copy) v_u_146
			v_u_19 = p514
			v_u_59.Text = p514
			v_u_146()
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15, (copy) v_u_20, (ref) v_u_48, (copy) v_u_47, (copy) v_u_10
			v_u_15 = false
			for _, v_u_515 in v_u_20 do
				pcall(function()
					-- upvalues: (copy) v_u_515
					v_u_515:Disconnect()
				end)
			end
			if v_u_48.release then
				v_u_48.release()
			end
			for _, v516 in v_u_47 do
				local v517 = v_u_10.cellRender
				local v518 = v516.cell
				pcall(v517, v518, false)
			end
		end
		v_u_14.frame = p_u_3
		task.defer(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_146, (ref) v_u_345, (ref) v_u_413
			if v_u_15 then
				v_u_146()
				v_u_345()
				v_u_413()
			end
		end)
		return v_u_14
	end
}
return v_u_519