-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDNoise

local v_u_1 = {}
local v_u_2 = {
	0.01,
	3,
	6,
	12,
	22
}
local v_u_3 = {
	"Silent",
	"Quiet",
	"Quiet",
	"Audible",
	"Loud",
	"Very loud"
}
function v_u_1.level(p4) -- name: level
	-- upvalues: (copy) v_u_2
	local v5 = 0
	for v6, v7 in v_u_2 do
		if v7 > p4 then
			continue
		end
		v5 = v6
	end
	return v5
end
function v_u_1.state(p8) -- name: state
	if not p8 or (not p8.Parent or p8:GetAttribute("Dead") == true) then
		return "dead"
	end
	local v9 = p8:FindFirstChildOfClass("Humanoid")
	local v10 = v9 and v9.MoveDirection.Magnitude > 0.1 and true or false
	local v11 = p8:FindFirstChild("HumanoidRootPart")
	if v11 and v11:IsA("BasePart") then
		local v12 = v11.AssemblyLinearVelocity
		local v13 = v12.X
		local v14 = v12.Z
		v10 = Vector3.new(v13, 0, v14).Magnitude > 1.5 and true or v10
	end
	return v10 and (p8:GetAttribute("Downed") == true and "crawl" or (p8:GetAttribute("Sprinting") == true and "sprint" or (p8:GetAttribute("Sneaking") == true and "sneak" or "walk"))) or "still"
end
function v_u_1.new(p_u_15) -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v_u_16 = p_u_15.UI
	local v_u_17 = p_u_15.Theme.color
	local v_u_18 = {}
	local v_u_19 = nil
	local v_u_20 = nil
	local function v21()
		-- upvalues: (ref) v_u_20, (copy) p_u_15
		v_u_20 = p_u_15.cctx.shared.Difficulty
	end
	pcall(v21)
	local v_u_22 = v_u_16.new("Frame", {
		["Name"] = "Noise",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 40, 1, -132),
		["Size"] = UDim2.fromOffset(168, 16)
	}, p_u_15.root)
	local v_u_23 = v_u_20
	local v_u_24 = {}
	for v25 = 1, 5 do
		local v26 = (v25 - 1) * 3 + 4
		v_u_24[v25] = v_u_16.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = "Bar" .. v25,
			["BackgroundColor3"] = v_u_17.line,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, (v25 - 1) * 6, 1, 0),
			["Size"] = UDim2.fromOffset(4, v26)
		}, v_u_22)
	end
	local v_u_27 = v_u_16.label({
		["parent"] = nil,
		["text"] = "Silent",
		["style"] = "caps",
		["textSize"] = 12,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_22,
		["color"] = v_u_17.muted,
		["position"] = UDim2.fromOffset(38, 0),
		["size"] = UDim2.new(1, -38, 1, 0)
	})
	v_u_27.Name = "Word"
	v_u_27.TextYAlignment = Enum.TextYAlignment.Center
	v_u_27.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_28 = -1
	local v_u_29 = 0
	local v_u_30 = 0
	local v_u_31 = 0
	local function v_u_38(p32) -- name: paint
		-- upvalues: (ref) v_u_28, (copy) v_u_17, (copy) v_u_24, (copy) v_u_16, (copy) v_u_27, (ref) v_u_3
		if p32 ~= v_u_28 then
			v_u_28 = p32
			local v33
			if p32 >= 4 then
				v33 = v_u_17.danger
			elseif p32 == 3 then
				v33 = v_u_17.accent
			else
				v33 = v_u_17.text2
			end
			for v34, v35 in v_u_24 do
				local v36
				if v34 <= p32 then
					v36 = v33
				else
					v36 = v_u_17.line
				end
				v35.BackgroundColor3 = v36
				v35.BackgroundTransparency = v34 <= p32 and 0 or 0.1
			end
			v_u_16.setText(v_u_27, v_u_3[p32] or "")
			local v37 = v_u_27
			if p32 == 0 then
				v33 = v_u_17.muted
			end
			v37.TextColor3 = v33
		end
	end
	v_u_38(0)
	function v_u_18.setCharacter(p39) -- name: setCharacter
		-- upvalues: (ref) v_u_19, (ref) v_u_29, (ref) v_u_30
		v_u_19 = p39
		v_u_29 = 0
		v_u_30 = 0
	end
	function v_u_18.layout(p40) -- name: layout
		-- upvalues: (copy) p_u_15, (copy) v_u_22
		local v41
		if p40 and p_u_15.touchFrame then
			v41 = p_u_15.touchFrame()
		else
			v41 = nil
		end
		if v41 then
			v_u_22.AnchorPoint = Vector2.new(0, 0)
			local v42 = UDim2.fromOffset
			local v43 = v41.left
			local v44 = math.floor(v43)
			local v45 = v41.top + 78
			local v46 = v42(v44, (math.floor(v45)))
			if v41.corner then
				v46 = p_u_15.cctx.lib.HudLayout.position("Noise", v46)
			end
			v_u_22.Position = v46
			local v47 = v_u_22
			local v48 = UDim2.fromOffset
			local v49 = v41.vitalsW
			local v50 = math.floor(v49)
			v47.Size = v48(math.min(168, v50), 16)
		else
			v_u_22.AnchorPoint = Vector2.new(0, 1)
			v_u_22.Position = UDim2.new(0, 40, 1, -132)
			v_u_22.Size = UDim2.fromOffset(168, 16)
		end
	end
	function v_u_18.radius() -- name: radius
		-- upvalues: (ref) v_u_1, (ref) v_u_19, (ref) v_u_23, (copy) p_u_15
		local v51 = v_u_1.state(v_u_19)
		if v51 == "dead" or (v51 == "still" or not v_u_23) then
			return 0, v51
		end
		local v52 = p_u_15.raid
		local v53
		if v52 then
			v53 = v52:GetAttribute("Difficulty")
		else
			v53 = v52
		end
		local v54
		if v52 then
			v54 = v52:GetAttribute("Weather")
		else
			v54 = v52
		end
		if v52 then
			v52 = v52:GetAttribute("Map")
		end
		local v55 = v_u_23.stepRadius
		local v56 = type(v53) ~= "string" and "Normal" or v53
		if type(v54) ~= "string" then
			v54 = nil
		end
		local v57 = 1
		if type(v52) ~= "string" then
			v52 = nil
		end
		local v58, v59 = pcall(v55, v56, v51, v54, v57, v52)
		local v60 = v_u_19
		if v60 then
			v60 = v_u_19:GetAttribute("StepNoiseMul")
		end
		local v61 = type(v60) ~= "number" and 1 or math.clamp(v60, 0.3, 1)
		local v62 = v_u_19
		if v62 then
			v62 = v_u_19:GetAttribute("StepPerkMul")
		end
		if type(v62) == "number" and v62 == v62 then
			local v63 = v61 * math.clamp(v62, 0, 2.5)
			v61 = math.min(v63, 2.5)
		end
		if v51 == "walk" then
			local v64 = v_u_19
			if v64 then
				v64 = v_u_19:GetAttribute("StepPaceMul")
			end
			if type(v64) == "number" and v64 == v64 then
				v61 = v61 * math.clamp(v64, 0.2, 1)
			end
		end
		return (not v58 or type(v59) ~= "number") and 0 or v59 * v61, v51
	end
	function v_u_18.update(p65) -- name: update
		-- upvalues: (ref) v_u_31, (ref) v_u_19, (copy) v_u_22, (copy) p_u_15, (copy) v_u_18, (ref) v_u_1, (ref) v_u_29, (ref) v_u_30, (copy) v_u_38
		v_u_31 = v_u_31 + p65
		local v66 = v_u_19
		if v66 and (v66.Parent and v66:GetAttribute("Dead") ~= true) then
			local v67 = v_u_22
			local v68
			if p_u_15.vitalsWrapped == true then
				v68 = false
			else
				local v69 = p_u_15.trayOverlaps
				local v70
				if type(v69) == "function" then
					v70 = p_u_15.trayOverlaps(v_u_22, 4)
				else
					v70 = false
				end
				v68 = not v70
			end
			v67.Visible = v68
			local v71, v72 = v_u_18.radius()
			local v73 = v_u_1.level(v71)
			if v_u_29 <= v73 then
				v_u_29 = v73
				v_u_30 = v_u_31 + 0.6
			elseif v_u_30 <= v_u_31 then
				v_u_29 = v73
			end
			v_u_38(v_u_29)
			local v74 = p_u_15.cctx
			if v74 then
				v74 = p_u_15.cctx.player
			end
			if v74 then
				local v75 = string.format("%s %.1f %d", v72, v71, v_u_29)
				if v74:GetAttribute("HudNoise") ~= v75 then
					v74:SetAttribute("HudNoise", v75)
				end
			end
		else
			v_u_22.Visible = false
		end
	end
	function v_u_18.destroy() -- name: destroy
		-- upvalues: (copy) v_u_22
		v_u_22:Destroy()
	end
	return v_u_18
end
return v_u_1