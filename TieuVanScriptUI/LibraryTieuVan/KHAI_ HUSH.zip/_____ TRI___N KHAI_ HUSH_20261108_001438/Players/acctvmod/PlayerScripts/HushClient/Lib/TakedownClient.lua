-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TakedownClient

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v_u_2:WaitForChild("TakedownRules"))
local v_u_4 = require(v_u_2:WaitForChild("ZombieTypes"))
local v_u_5 = require(script.Parent.TakedownHintLayout)
local v_u_6 = require(script.Parent.TakedownZombiePose)
local v_u_7 = {}
local v_u_8 = v_u_1.LocalPlayer
local v_u_9 = v_u_3.REACH + 1
local v_u_10 = v_u_3.REACH + v_u_3.LAG_PAD_MAX + 1
local v_u_11 = false
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = false
local v_u_16 = 0
local v_u_17 = -1000000000
local v_u_18 = -1000000000
local v_u_19 = nil
local v_u_20 = -1000000000
local v_u_21 = {}
local v_u_22 = {}
local v_u_23 = nil
local v_u_24 = 0
local v_u_25 = {}
local v_u_26 = {}
local v_u_27 = nil
local v_u_28 = false
local v_u_29 = false
local v_u_30 = {
	["scans"] = 0,
	["starts"] = 0,
	["denied"] = 0,
	["sent"] = 0,
	["toasts"] = 0,
	["errors"] = 0
}
local function v_u_36(p_u_31) -- name: lib
	-- upvalues: (copy) v_u_25, (copy) v_u_26, (ref) v_u_12
	local v32 = v_u_25[p_u_31]
	if v32 == nil or v32 == false and os.clock() - (v_u_26[p_u_31] or 0) > 3 then
		v_u_26[p_u_31] = os.clock()
		local function v34()
			-- upvalues: (ref) v_u_12, (copy) p_u_31
			if v_u_12 and (v_u_12.lib and v_u_12.lib[p_u_31]) then
				return v_u_12.lib[p_u_31]
			else
				local v33 = script.Parent:FindFirstChild(p_u_31)
				if v33 and v33:IsA("ModuleScript") then
					return require(v33)
				else
					return nil
				end
			end
		end
		local v35
		v35, v32 = pcall(v34)
		if not v35 or type(v32) ~= "table" then
			v32 = false
		end
		v_u_25[p_u_31] = v32
	end
	return v32 or nil
end
local function v_u_43(p_u_37) -- name: ctrl
	-- upvalues: (copy) v_u_25, (copy) v_u_26, (ref) v_u_12
	local v38 = "c:" .. p_u_37
	local v39 = v_u_25[v38]
	if v39 == nil or v39 == false and os.clock() - (v_u_26[v38] or 0) > 3 then
		v_u_26[v38] = os.clock()
		local function v41()
			-- upvalues: (ref) v_u_12, (copy) p_u_37
			if v_u_12 and (v_u_12.controllers and v_u_12.controllers[p_u_37]) then
				return v_u_12.controllers[p_u_37]
			else
				local v40 = script.Parent
				if v40 then
					v40 = v40.Parent
				end
				if v40 then
					v40 = v40:FindFirstChild("Controllers")
				end
				if v40 then
					v40 = v40:FindFirstChild(p_u_37)
				end
				if v40 and v40:IsA("ModuleScript") then
					return require(v40)
				else
					return nil
				end
			end
		end
		local v42
		v42, v39 = pcall(v41)
		if not v42 or type(v39) ~= "table" then
			v39 = false
		end
		v_u_25[v38] = v39
	end
	return v39 or nil
end
local function v_u_44() -- name: serverNow
	return workspace:GetServerTimeNow()
end
local function v_u_57(p45) -- name: viewLook
	-- upvalues: (copy) v_u_36
	local v46 = v_u_36("FpCam")
	if v46 then
		local v47 = v46.look
		if type(v47) == "function" then
			local v48 = v46.look
			local v49, v50, v51 = pcall(v48)
			if v49 and (type(v50) == "number" and v50 == v50) then
				if type(v51) == "number" and v51 == v51 then
					return v50, v51
				else
					return v50, 0
				end
			end
		end
	end
	local v52 = p45.CFrame.LookVector
	local v53 = v52.X
	local v54 = v52.Z
	local v55 = -v53
	local v56 = -v54
	return math.atan2(v55, v56), 0
end
local function v_u_62(p58) -- name: describePart
	local v59 = p58:FindFirstAncestorOfClass("Model")
	while v59 ~= nil do
		if v59:FindFirstChildOfClass("Humanoid") ~= nil then
			return {
				["character"] = true
			}, v59
		end
		v59 = v59:FindFirstAncestorOfClass("Model")
	end
	if game:GetService("CollectionService"):HasTag(p58, "HushWindow") then
		return {
			["window"] = true,
			["broken"] = nil,
			["broken"] = p58:GetAttribute("Broken") == true
		}, p58
	end
	local v60 = {}
	local v61
	if p58.Transparency >= 0.98 then
		v61 = not p58.CanCollide
	else
		v61 = false
	end
	v60.ghost = v61
	return v60, p58
end
local function v_u_68(p63, p64, p65) -- name: realCast
	-- upvalues: (copy) v_u_62
	local v66 = RaycastParams.new()
	v66.FilterType = Enum.RaycastFilterType.Exclude
	v66.IgnoreWater = true
	v66.FilterDescendantsInstances = p65
	local v67 = workspace:Raycast(p63, p64 - p63, v66)
	if v67 == nil then
		return nil, nil
	else
		return v_u_62(v67.Instance)
	end
end
local function v_u_77(p69) -- name: baseSkip
	local v70 = { p69 }
	local v71 = workspace.CurrentCamera
	if v71 then
		table.insert(v70, v71)
	end
	for _, v72 in { "HushCombat", "HushLocal" } do
		local v73 = workspace:FindFirstChild(v72)
		if not v73 then
			continue
		end
		table.insert(v70, v73)
	end
	local v74 = workspace:FindFirstChild("Raid")
	for _, v75 in { "Items", "Extracts", "Spawns" } do
		local v76
		if v74 then
			v76 = v74:FindFirstChild(v75)
		else
			v76 = v74
		end
		if not v76 then
			continue
		end
		table.insert(v70, v76)
	end
	return v70
end
local v_u_78 = v_u_68
function v_u_7._setCast(p79) -- name: _setCast
	-- upvalues: (ref) v_u_78, (copy) v_u_68
	v_u_78 = p79 or v_u_68
end
local function v_u_94(p80, p_u_81, p_u_82) -- name: bodyClear
	-- upvalues: (copy) v_u_77, (copy) v_u_3, (ref) v_u_78
	local v83 = p_u_82.X - p_u_81.X
	local v84 = p_u_82.Y - p_u_81.Y
	local v85 = p_u_82.Z - p_u_81.Z
	if v83 * v83 + v84 * v84 + v85 * v85 < 0.0025 then
		return true
	end
	local v_u_86 = v_u_77(p80)
	local v87 = v_u_3.pathClear
	local function v91()
		-- upvalues: (ref) v_u_78, (copy) p_u_81, (copy) p_u_82, (copy) v_u_86
		local v88, v89 = v_u_78(p_u_81, p_u_82, v_u_86)
		if v88 ~= nil and v89 ~= nil then
			local v90 = v_u_86
			table.insert(v90, v89)
		end
		return v88
	end
	local v92, v93 = pcall(v87, v91)
	if v92 then
		v92 = v93 == true
	end
	return v92
end
local function v_u_101(p95) -- name: baseFacts
	-- upvalues: (copy) v_u_8, (ref) v_u_17
	local v96 = p95:GetAttribute("Stamina")
	local v97 = p95:GetAttribute("Action")
	local v98 = v_u_8:GetAttribute("Perk_silentTakedown")
	local v99 = {}
	local v100
	if v98 == true then
		v100 = true
	elseif type(v98) == "number" then
		v100 = v98 > 0
	else
		v100 = false
	end
	v99.perkSilent = v100
	v99.weaponId = p95:GetAttribute("Weapon")
	v99.stamina = type(v96) ~= "number" and 0 or v96
	v99.exhausted = p95:GetAttribute("Exhausted") == true
	v99.action = type(v97) ~= "string" and "" or v97
	v99.downed = p95:GetAttribute("Downed") == true
	v99.dead = p95:GetAttribute("Dead") == true
	v99.entryHold = p95:GetAttribute("EntryHold")
	v99.now = os.clock()
	v99.lastEndAt = v_u_17
	return v99
end
local function v_u_165() -- name: findCandidate
	-- upvalues: (ref) v_u_15, (copy) v_u_8, (copy) v_u_43, (copy) v_u_9, (copy) v_u_101, (copy) v_u_57, (copy) v_u_4, (copy) v_u_3, (copy) v_u_94
	v_u_15 = false
	local v_u_102 = v_u_8.Character
	if not (v_u_102 and v_u_102.Parent) then
		v_u_102 = nil
	end
	local v103
	if v_u_102 then
		v103 = v_u_102:FindFirstChild("HumanoidRootPart")
	else
		v103 = v_u_102
	end
	if not (v103 and v103:IsA("BasePart")) then
		v103 = nil
	end
	if not (v_u_102 and v103) then
		return nil, nil, nil, nil
	end
	local v104 = v_u_43("ZombieRender")
	if v104 then
		local v105 = v104.targets
		if type(v105) == "function" then
			local v106 = v104.targets
			local v107 = v103.Position
			local v108 = v_u_9
			local v109, v110 = pcall(v106, v107, v108)
			if not v109 or type(v110) ~= "table" then
				return nil, nil, nil, nil
			end
			local v111 = v_u_101(v_u_102)
			local v112 = v_u_57(v103)
			local v113 = -math.sin(v112)
			local v114 = -math.cos(v112)
			local v115 = {}
			for _, v116 in v110 do
				if v116.human == true or v116.visible == false then
					continue
				end
				local v117 = v116.position
				if typeof(v117) ~= "Vector3" then
					continue
				end
				local v118 = v116.position
				local v119 = v118.X - v103.Position.X
				local v120 = v118.Z - v103.Position.Z
				local v121 = v119 * v119 + v120 * v120
				local v122 = math.sqrt(v121)
				if v122 < 0.001 then
					continue
				end
				local v123 = v116.yaw
				local v124 = type(v123) ~= "number" and 0 or v116.yaw
				local v125 = -math.sin(v124)
				local v126 = -math.cos(v124)
				local v127 = {
					["typeId"] = v116.typeId,
					["state"] = v_u_4.STATE_NAME[v116.state],
					["dist"] = v122
				}
				local v128 = v113 * v113 + v114 * v114
				local v129 = math.sqrt(v128)
				local v130 = v119 * v119 + v120 * v120
				local v131 = math.sqrt(v130)
				local v132
				if v129 < 1e-6 or v131 < 1e-6 then
					v132 = 180
				else
					local v133 = (v113 * v119 + v114 * v120) / (v129 * v131)
					local v134 = math.clamp(v133, -1, 1)
					local v135 = math.acos(v134)
					v132 = math.deg(v135)
				end
				v127.angleDeg = v132
				local v136 = -v119
				local v137 = -v120
				local v138 = v125 * v125 + v126 * v126
				local v139 = math.sqrt(v138)
				local v140 = v136 * v136 + v137 * v137
				local v141 = math.sqrt(v140)
				local v142
				if v139 < 1e-6 or v141 < 1e-6 then
					v142 = 180
				else
					local v143 = (v125 * v136 + v126 * v137) / (v139 * v141)
					local v144 = math.clamp(v143, -1, 1)
					local v145 = math.acos(v144)
					v142 = math.deg(v145)
				end
				v127.faceDeg = v142
				v127.dy = v118.Y - v103.Position.Y
				v111.zombie = v127
				local v146, v147 = v_u_3.clientCheck(v111)
				if not v146 then
					continue
				end
				local v148 = {
					["id"] = v116.id,
					["row"] = v116,
					["dist"] = v122,
					["pos"] = v118,
					["silent"] = v147 == "silent"
				}
				table.insert(v115, v148)
			end
			table.sort(v115, function(p149, p150)
				return p149.dist < p150.dist
			end)
			local v151 = v103.Position
			local function v158(p152, p153, p154, p155, p156, p157) -- name: lineClear
				-- upvalues: (ref) v_u_94, (copy) v_u_102
				return v_u_94(v_u_102, Vector3.new(p152, p153, p154), (Vector3.new(p155, p156, p157)))
			end
			local v159 = #v115
			local v160 = false
			local v161 = nil
			local v162 = nil
			for v163 = 1, math.min(v159, 4) do
				local v164 = v115[v163]
				if v164.silent then
					if not v_u_94(v_u_102, v151, v164.pos) then
						continue
					end
					v_u_15 = true
					return v164.id, v164.row, v164.pos.X, v164.pos.Z
				end
				if not v_u_94(v_u_102, v151, v164.pos) then
					continue
				end
				if not v160 then
					v161, v162 = v_u_3.slotFor(v151.X, v151.Y, v151.Z, v112, v158)
					v160 = true
				end
				if v161 == nil or v162 == nil then
					return nil, nil, nil, nil
				end
				if not v_u_3.pullFree(v164.pos.X, v164.pos.Y, v164.pos.Z, v161, v151.Y, v162, v158) then
					continue
				end
				return v164.id, v164.row, v161, v162
			end
			return nil, nil, nil, nil
		end
	end
	return nil, nil, nil, nil
end
function v_u_7.candidate() -- name: candidate
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_7.isActive() -- name: isActive
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_7.running() -- name: running
	-- upvalues: (ref) v_u_19
	return v_u_19 ~= nil
end
local function v_u_182() -- name: buildHint
	-- upvalues: (ref) v_u_27, (copy) v_u_36, (copy) v_u_5, (copy) v_u_30
	if v_u_27 then
		return true
	end
	local v_u_166 = v_u_36("HushUI")
	if not v_u_166 then
		return false
	end
	local function v178()
		-- upvalues: (copy) v_u_166, (ref) v_u_5, (ref) v_u_27
		local v167 = v_u_166.Theme
		local v168, v169 = v_u_166.screen("TakedownHint", v167.layer.hud + 1, {
			["insets"] = "None"
		})
		local v_u_170 = v167.refSize()
		local v_u_171 = v_u_5.compute(v_u_170.X, v_u_170.Y, false)
		local v_u_172 = Instance.new("Frame")
		v_u_172.Name = "Hint"
		v_u_172.BackgroundColor3 = v167.color.bg
		v_u_172.BackgroundTransparency = v167.alpha.glass
		v_u_172.BorderSizePixel = 0
		v_u_172.Position = UDim2.fromOffset(v_u_171.panel.x, v_u_171.panel.y)
		v_u_172.Size = UDim2.fromOffset(v_u_171.panel.w, v_u_171.panel.h)
		v_u_172.Visible = false
		v_u_172.Parent = v169
		local v173 = Instance.new("Frame")
		v173.Name = "Accent"
		v173.BackgroundColor3 = v167.color.accent
		v173.BorderSizePixel = 0
		v173.Size = UDim2.new(1, 0, 0, 2)
		v173.Parent = v_u_172
		local v_u_174
		if v_u_171.chip then
			v_u_174 = v_u_166.keyHint("interact", {
				["parent"] = v_u_172,
				["position"] = UDim2.fromOffset(v_u_171.chip.x - v_u_171.panel.x, v_u_171.chip.y - v_u_171.panel.y),
				["size"] = v_u_171.chip.h
			})
		else
			v_u_174 = nil
		end
		local v_u_175 = v_u_166.label({
			["text"] = "TAKEDOWN",
			["style"] = "caps",
			["color"] = nil,
			["align"] = "left",
			["color"] = v167.color.text
		})
		v_u_175.Position = UDim2.fromOffset(v_u_171.label.x - v_u_171.panel.x, 0)
		v_u_175.Size = UDim2.fromOffset(v_u_171.label.w, v_u_171.label.h)
		v_u_175.Parent = v_u_172
		v_u_27 = {
			["gui"] = v168,
			["panel"] = v_u_172,
			["chip"] = v_u_174,
			["label"] = v_u_175
		}
		if v_u_174 then
			local function v177() -- name: fit
				-- upvalues: (ref) v_u_5, (copy) v_u_171, (ref) v_u_174, (copy) v_u_170, (copy) v_u_172, (copy) v_u_175
				local v176 = v_u_5.fitChip(v_u_171, v_u_174.Size.X.Offset, v_u_170.X)
				v_u_172.Position = UDim2.fromOffset(v176.panel.x, v176.panel.y)
				v_u_172.Size = UDim2.fromOffset(v176.panel.w, v176.panel.h)
				v_u_175.Position = UDim2.fromOffset(v176.label.x - v176.panel.x, 0)
				v_u_175.Size = UDim2.fromOffset(v176.label.w, v176.label.h)
			end
			v177()
			v_u_174:GetPropertyChangedSignal("Size"):Connect(v177)
		end
	end
	local v179, v180 = pcall(v178)
	if v179 then
		return true
	end
	local v181 = v_u_30
	v181.errors = v181.errors + 1
	if v_u_30.errors <= 3 then
		warn("[TakedownClient] " .. "buildHint" .. " failed: " .. tostring(v180))
	end
	v_u_27 = nil
	return false
end
local function v_u_195(p183, p184, p185, p186, p187, p188) -- name: pullStart
	-- upvalues: (copy) v_u_43, (copy) v_u_30
	local v189 = v_u_43("ZombieRender")
	if v189 then
		local v190 = v189.setPull
		if type(v190) == "function" then
			local v191 = v189.setPull
			local v192, v193 = pcall(v191, p183, p184, p185, p186, p187, p188)
			if not v192 then
				local v194 = v_u_30
				v194.errors = v194.errors + 1
				if v_u_30.errors <= 3 then
					warn("[TakedownClient] " .. "setPull" .. " failed: " .. tostring(v193))
				end
			end
		end
	end
end
local function v_u_207(p196) -- name: stopPrediction
	-- upvalues: (ref) v_u_19, (copy) v_u_43, (ref) v_u_17, (copy) v_u_36
	if v_u_19 ~= nil then
		local v197 = v_u_19.zid
		v_u_19 = nil
		local v198 = type(v197) == "number" and v_u_43("ZombieRender")
		if v198 then
			local v199 = v198.clearPull
			if type(v199) == "function" then
				local v200 = v198.clearPull
				pcall(v200, v197)
			end
		end
		v_u_17 = os.clock()
		local v201 = v_u_36("FpCam")
		if v201 then
			local v202 = v201.lockLook
			if type(v202) == "function" then
				local v203 = v201.lockLook
				pcall(v203, nil)
			end
		end
		local v204 = not p196 and v_u_36("Viewmodel")
		if v204 then
			local v205 = v204.cancelTakedown
			if type(v205) == "function" then
				local v206 = v204.cancelTakedown
				pcall(v206)
			end
		end
	end
end
local function v_u_220(p208, p209) -- name: pinnedPosition
	-- upvalues: (copy) v_u_43, (copy) v_u_10
	local v210 = p208:GetAttribute("TakedownZid")
	if type(v210) ~= "number" then
		return nil
	end
	local v211 = v_u_43("ZombieRender")
	if v211 then
		local v212 = v211.targets
		if type(v212) == "function" then
			local v213 = v211.targets
			local v214 = p209.Position
			local v215 = v_u_10
			local v216, v217 = pcall(v213, v214, v215)
			if not v216 or type(v217) ~= "table" then
				return nil
			end
			for _, v218 in v217 do
				if v218.id ~= v210 then
					continue
				end
				local v219 = v218.position
				if typeof(v219) ~= "Vector3" then
					continue
				end
				return v218.position
			end
			return nil
		end
	end
	return nil
end
local function v_u_274(p221, p222, p223, p224, p225, p226, p227) -- name: startPrediction
	-- upvalues: (copy) v_u_3, (copy) v_u_57, (ref) v_u_19, (ref) v_u_20, (copy) v_u_30, (copy) v_u_195, (copy) v_u_8, (copy) v_u_220, (copy) v_u_6, (copy) v_u_36, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29
	local v228 = not p227 and 0 or v_u_3.SILENT_SKIP
	local v229 = workspace:GetServerTimeNow() - v228
	local v230, v231 = v_u_57(p224)
	local v232 = p223:GetAttribute("Weapon")
	local v233 = p222.position.Y
	local v234 = Vector3.new(p225, v233, p226)
	local v235 = p225 - p224.Position.X
	local v236 = p226 - p224.Position.Z
	local v237 = os.clock() - v228
	local v238 = {
		["silent"] = nil,
		["t0"] = nil,
		["clock0"] = nil,
		["zid"] = nil,
		["weaponId"] = nil,
		["dirYaw"] = nil,
		["pitch0"] = nil,
		["slot"] = nil,
		["slotDist"] = nil,
		["steer"] = nil,
		["nextPeek"] = 0,
		["peekBearing"] = nil,
		["kicked"] = nil,
		["stabbed"] = false,
		["row"] = nil,
		["rootX"] = nil,
		["rootY"] = nil,
		["rootZ"] = nil,
		["silent"] = p227,
		["t0"] = v229,
		["clock0"] = v237,
		["zid"] = p221,
		["weaponId"] = type(v232) ~= "string" and "melee_knife" or v232,
		["dirYaw"] = v230,
		["pitch0"] = v231,
		["slot"] = v234
	}
	local v239 = v235 * v235 + v236 * v236
	v238.slotDist = math.sqrt(v239)
	v238.kicked = p227
	v238.row = p222
	v238.rootX = p224.Position.X
	v238.rootY = p224.Position.Y
	v238.rootZ = p224.Position.Z
	v_u_19 = v238
	v_u_20 = v229
	local v240 = v_u_30
	v240.starts = v240.starts + 1
	if not p227 then
		v_u_195(p221, p222.position.X, p222.position.Z, p225, p226, v237)
	end
	local v_u_241 = v_u_19
	local function v260(_)
		-- upvalues: (ref) v_u_19, (copy) v_u_241, (ref) v_u_8, (ref) v_u_3, (ref) v_u_220, (ref) v_u_6
		if v_u_19 ~= v_u_241 then
			return nil, nil
		end
		local v242 = os.clock()
		local v243 = v242 - v_u_241.clock0
		local v244 = v_u_8.Character
		if not (v244 and v244.Parent) then
			v244 = nil
		end
		local v245
		if v244 then
			v245 = v244:FindFirstChild("HumanoidRootPart")
		else
			v245 = v244
		end
		if not (v245 and v245:IsA("BasePart")) then
			v245 = nil
		end
		local v246
		if v245 then
			v246 = v245.Position.Y
		else
			v246 = v_u_241.rootY
		end
		local v247 = v246 + 1.5
		if v_u_241.steer == nil and (v_u_3.PULL + v_u_3.LOOK_HANDOFF <= v243 and (v_u_241.nextPeek <= v242 and (v244 ~= nil and v245 ~= nil))) then
			v_u_241.nextPeek = v242 + 0.1
			local v248 = v_u_220(v244, v245)
			local v249
			if v248 == nil then
				v249 = nil
			else
				local v250 = v248.X - v245.Position.X
				local v251 = v248.Z - v245.Position.Z
				local v252 = -v250
				local v253 = -v251
				local v254 = math.atan2(v252, v253)
				local v255 = v248.X - v_u_241.rootX
				local v256 = v248.Z - v_u_241.rootZ
				local v257 = v_u_3.peekArrived
				local v258 = v255 * v255 + v256 * v256
				local v259
				v259, v249 = v257(math.sqrt(v258), v_u_241.slotDist, v254, v_u_241.peekBearing)
				if v259 then
					v_u_241.steer = v_u_3.lookSteer(v_u_241.dirYaw, v254, v_u_241.steer, v243)
				end
			end
			v_u_241.peekBearing = v249
		end
		return v_u_3.camLook(v243, v_u_241.dirYaw, v_u_241.pitch0, v_u_241.steer, v_u_241.slot.Y, v_u_241.slotDist, v247, v_u_6.headHeight(v_u_3.CONTACT_AT))
	end
	local v261 = v_u_36("Viewmodel")
	local v262 = false
	if v261 then
		local v263 = v261.playTakedown
		if type(v263) == "function" then
			local v264 = v261.playTakedown
			local v265 = v_u_3.KIND
			local v266
			v262, v266 = pcall(v264, v229, v265, v260)
			if v262 then
				v262 = v266 == true
			end
		end
	end
	local v267 = not v262 and v_u_36("FpCam")
	if v267 then
		local v268 = v267.lockLook
		if type(v268) == "function" then
			local v269 = v267.lockLook
			local v270 = v_u_3.DURATION
			pcall(v269, v260, v270)
		end
	end
	if v_u_28 ~= false then
		v_u_28 = false
		if v_u_27 then
			v_u_27.panel.Visible = false
		end
	end
	if v_u_29 ~= false then
		v_u_29 = false
		local v271 = v_u_36("FpTouch")
		if v271 then
			local v272 = v271.setTakedown
			if type(v272) == "function" then
				local v273 = v271.setTakedown
				pcall(v273, false)
			end
		end
	end
end
local function v_u_299() -- name: stepPrediction
	-- upvalues: (ref) v_u_19, (copy) v_u_8, (copy) v_u_207, (copy) v_u_3, (copy) v_u_43, (ref) v_u_17, (copy) v_u_36
	local v275 = v_u_19
	if v275 == nil then
		return
	else
		local v276 = os.clock() - v275.clock0
		local v277 = v_u_8.Character
		if not (v277 and v277.Parent) then
			v277 = nil
		end
		if v277 == nil or (v277:GetAttribute("Dead") == true or v277:GetAttribute("Downed") == true) then
			v_u_207(false)
			return
		elseif v276 >= 1.2 and (not v275.silent and (v277:GetAttribute("Action") ~= "Takedown" and v276 < v_u_3.DURATION - 0.2)) then
			v_u_207(false)
		else
			if not v275.kicked and v_u_3.KICK_AT <= v276 then
				v275.kicked = true
				local v_u_278 = v275.slot + Vector3.new(0, 2.2, 0)
				local v_u_279 = v275.weaponId
				local v_u_280 = v_u_43("Audio")
				if v_u_280 then
					local v_u_281 = "kick"
					pcall(function()
						-- upvalues: (copy) v_u_281, (copy) v_u_280, (copy) v_u_278, (copy) v_u_279
						if v_u_281 == "kick" then
							if v_u_280.play3D then
								v_u_280.play3D("impact_flesh", v_u_278, {
									["volume"] = 1.15,
									["pitch"] = 0.78
								})
								v_u_280.play3D("mel_hit_bone", v_u_278, {
									["volume"] = 0.45
								})
								return
							end
						elseif v_u_280.melee then
							v_u_280.melee(v_u_279 or "melee_knife", v_u_278, "hit")
						end
					end)
				end
				local v282 = v_u_43("Camera")
				if v282 then
					local v283 = v282.shake
					if type(v283) == "function" then
						local v284 = v282.shake
						pcall(v284, 0.05, 0.1)
					end
				end
			end
			if not v275.stabbed and v_u_3.CONTACT_AT <= v276 then
				v275.stabbed = true
				local v_u_285 = v275.slot + Vector3.new(0, 2.6, 0)
				local v_u_286 = v275.weaponId
				local v_u_287 = v_u_43("Audio")
				if v_u_287 then
					local v_u_288 = "stab"
					pcall(function()
						-- upvalues: (copy) v_u_288, (copy) v_u_287, (copy) v_u_285, (copy) v_u_286
						if v_u_288 == "kick" then
							if v_u_287.play3D then
								v_u_287.play3D("impact_flesh", v_u_285, {
									["volume"] = 1.15,
									["pitch"] = 0.78
								})
								v_u_287.play3D("mel_hit_bone", v_u_285, {
									["volume"] = 0.45
								})
								return
							end
						elseif v_u_287.melee then
							v_u_287.melee(v_u_286 or "melee_knife", v_u_285, "hit")
						end
					end)
				end
				local v289 = v_u_43("Camera")
				if v289 then
					local v290 = v289.shake
					if type(v290) == "function" then
						local v291 = v289.shake
						pcall(v291, 0.07, 0.12)
					end
				end
			end
			if v_u_3.DURATION <= v276 then
				if v_u_19 == nil then
					return
				end
				local v292 = v_u_19.zid
				v_u_19 = nil
				local v293 = type(v292) == "number" and v_u_43("ZombieRender")
				if v293 then
					local v294 = v293.clearPull
					if type(v294) == "function" then
						local v295 = v293.clearPull
						pcall(v295, v292)
					end
				end
				v_u_17 = os.clock()
				local v296 = v_u_36("FpCam")
				if v296 then
					local v297 = v296.lockLook
					if type(v297) == "function" then
						local v298 = v296.lockLook
						pcall(v298, nil)
					end
				end
			end
		end
	end
end
function v_u_7.tryStart() -- name: tryStart
	-- upvalues: (ref) v_u_11, (ref) v_u_19, (copy) v_u_8, (copy) v_u_165, (ref) v_u_15, (copy) v_u_57, (copy) v_u_2, (copy) v_u_30, (ref) v_u_13, (copy) v_u_274
	if not v_u_11 then
		return false
	end
	if v_u_19 ~= nil then
		return true
	end
	local v300 = v_u_8.Character
	if not (v300 and v300.Parent) then
		v300 = nil
	end
	local v301
	if v300 then
		v301 = v300:FindFirstChild("HumanoidRootPart")
	else
		v301 = v300
	end
	if not (v301 and v301:IsA("BasePart")) then
		v301 = nil
	end
	if not (v300 and v301) then
		return false
	end
	local v_u_302, v303, v304, v305 = v_u_165()
	local v306 = v_u_15
	if v_u_302 == nil or (v304 == nil or v305 == nil) then
		return false
	end
	local v307 = v_u_57(v301)
	local v308 = -math.sin(v307)
	local v309 = -math.cos(v307)
	local v_u_310 = Vector3.new(v308, 0, v309)
	local function v312()
		-- upvalues: (ref) v_u_2, (copy) v_u_310, (copy) v_u_302
		local v311 = {
			["d"] = v_u_310,
			["tk"] = v_u_302
		}
		require(v_u_2:WaitForChild("Net")).fire("combat.melee", v311)
	end
	local v313, v314 = pcall(v312)
	if not v313 then
		local v315 = v_u_30
		v315.errors = v315.errors + 1
		if v_u_30.errors <= 3 then
			warn("[TakedownClient] " .. "fire" .. " failed: " .. tostring(v314))
		end
		return false
	end
	local v316 = v_u_30
	v316.sent = v316.sent + 1
	v_u_13 = nil
	v_u_274(v_u_302, v303, v300, v301, v304, v305, v306)
	return true
end
local function v_u_323() -- name: toastDeny
	-- upvalues: (copy) v_u_8, (copy) v_u_3, (ref) v_u_18, (copy) v_u_30, (copy) v_u_36
	local v317 = v_u_8:GetAttribute("TakedownDeny")
	if type(v317) == "string" then
		local v318 = v_u_3.REASONS[v317]
		if type(v318) == "string" and os.clock() - v_u_18 >= 0.8 then
			v_u_18 = os.clock()
			local v319 = v_u_30
			v319.toasts = v319.toasts + 1
			local v320 = v_u_36("HushUI")
			if v320 then
				local v321 = v320.toast
				if type(v321) == "function" then
					local v322 = v320.toast
					pcall(v322, v318, "warn")
				end
			end
		end
	else
		return
	end
end
local function v_u_327() -- name: onDeny
	-- upvalues: (copy) v_u_8, (ref) v_u_24, (copy) v_u_30, (ref) v_u_19, (copy) v_u_207, (copy) v_u_323
	local v324 = v_u_8:GetAttribute("TakedownDenyAt")
	if type(v324) == "number" and v324 > v_u_24 then
		v_u_24 = v324
		local v325 = v_u_30
		v325.denied = v325.denied + 1
		local v326 = v_u_19
		if v326 ~= nil and v326.t0 - 0.2 <= v324 then
			v_u_207(false)
		end
		v_u_323()
	end
end
local function v_u_358(p328) -- name: watchOthers
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_8, (ref) v_u_20, (copy) v_u_21, (copy) v_u_22, (copy) v_u_3, (copy) v_u_43
	v_u_6.prune(p328)
	for _, v329 in v_u_1:GetPlayers() do
		local v330 = v329.Character
		local v331
		if v330 then
			v331 = v330:GetAttribute("TakedownZid")
		else
			v331 = v330
		end
		local v332
		if v330 then
			v332 = v330:GetAttribute("TakedownAt")
		else
			v332 = v330
		end
		if not v330 or (type(v331) ~= "number" or type(v332) ~= "number") then
			continue
		end
		v_u_6.note(v331, v332, p328)
		local v333 = v329.UserId
		local v334 = tostring(v333) .. "@" .. tostring(v332)
		local v335
		if v329 == v_u_8 then
			local v336 = v332 - v_u_20
			v335 = math.abs(v336) < 1.2
		else
			v335 = false
		end
		if v_u_21[v334] or v335 then
			continue
		end
		v_u_21[v334] = true
		local v337 = v330:FindFirstChild("HumanoidRootPart")
		local v338 = v330:GetAttribute("TakedownWeapon")
		if not (v337 and v337:IsA("BasePart")) then
			continue
		end
		local v339 = v337.CFrame.LookVector
		local v340 = v_u_22
		local v341 = {
			["kick"] = nil,
			["silent"] = nil,
			["stab"] = false,
			["pos"] = nil,
			["weaponId"] = nil,
			["kick"] = v330:GetAttribute("TakedownSilent") == true,
			["silent"] = v330:GetAttribute("TakedownSilent") == true
		}
		local v342 = v337.Position
		local v343 = v339.X
		local v344 = v339.Z
		v341.pos = v342 + Vector3.new(v343, 0, v344) * v_u_3.SLOT
		v341.weaponId = type(v338) ~= "string" and "melee_knife" or v338
		v340[v334] = v341
	end
	for v345, v346 in v_u_22 do
		local v347 = string.match
		local v348 = tonumber(v347(v345, "@(.+)$"))
		if v348 == nil then
			v_u_22[v345] = nil
		else
			local v349 = p328 - v348
			if not v346.kick and (v_u_3.KICK_AT <= v349 and v349 < v_u_3.KICK_AT + 0.6) then
				v346.kick = true
				local v_u_350 = v346.pos + Vector3.new(0, 2.2, 0)
				local v_u_351 = v346.weaponId
				local v_u_352 = v_u_43("Audio")
				if v_u_352 then
					local v_u_353 = "kick"
					pcall(function()
						-- upvalues: (copy) v_u_353, (copy) v_u_352, (copy) v_u_350, (copy) v_u_351
						if v_u_353 == "kick" then
							if v_u_352.play3D then
								v_u_352.play3D("impact_flesh", v_u_350, {
									["volume"] = 1.15,
									["pitch"] = 0.78
								})
								v_u_352.play3D("mel_hit_bone", v_u_350, {
									["volume"] = 0.45
								})
								return
							end
						elseif v_u_352.melee then
							v_u_352.melee(v_u_351 or "melee_knife", v_u_350, "hit")
						end
					end)
				end
			end
			if not v346.stab and (v_u_3.CONTACT_AT <= v349 and v349 < v_u_3.CONTACT_AT + 0.6) then
				v346.stab = true
				local v_u_354 = v346.pos + Vector3.new(0, 2.6, 0)
				local v_u_355 = v346.weaponId
				local v_u_356 = v_u_43("Audio")
				if v_u_356 then
					local v_u_357 = "stab"
					pcall(function()
						-- upvalues: (copy) v_u_357, (copy) v_u_356, (copy) v_u_354, (copy) v_u_355
						if v_u_357 == "kick" then
							if v_u_356.play3D then
								v_u_356.play3D("impact_flesh", v_u_354, {
									["volume"] = 1.15,
									["pitch"] = 0.78
								})
								v_u_356.play3D("mel_hit_bone", v_u_354, {
									["volume"] = 0.45
								})
								return
							end
						elseif v_u_356.melee then
							v_u_356.melee(v_u_355 or "melee_knife", v_u_354, "hit")
						end
					end)
				end
			end
			if v_u_3.DURATION + 1 >= v349 then
				continue
			end
			v_u_22[v345] = nil
			v_u_21[v345] = nil
		end
	end
end
function v_u_7.setActive(p359, p360) -- name: setActive
	-- upvalues: (ref) v_u_12, (ref) v_u_11, (copy) v_u_43, (copy) v_u_7, (ref) v_u_23, (ref) v_u_24, (copy) v_u_8, (copy) v_u_327, (ref) v_u_16, (copy) v_u_207, (ref) v_u_13, (ref) v_u_14, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (copy) v_u_36, (copy) v_u_21, (copy) v_u_22, (copy) v_u_6
	if p360 ~= nil then
		v_u_12 = p360
	end
	local v361 = p359 == true
	if v361 == v_u_11 then
		return
	else
		v_u_11 = v361
		local v362 = v_u_43("Input")
		if v361 then
			if v362 then
				local v363 = v362.setPressFilter
				if type(v363) == "function" then
					local v364 = v362.setPressFilter
					local v365 = v_u_7.tryStart
					pcall(v364, "interact", v365)
				end
			end
			if v_u_23 == nil then
				local v366 = v_u_8
				v_u_24 = tonumber(v366:GetAttribute("TakedownDenyAt")) or 0
				v_u_23 = v_u_8:GetAttributeChangedSignal("TakedownDenyAt"):Connect(v_u_327)
			end
			v_u_16 = 0.1
		else
			if v362 then
				local v367 = v362.setPressFilter
				if type(v367) == "function" then
					local v368 = v362.setPressFilter
					pcall(v368, "interact", nil)
				end
			end
			if v_u_23 then
				v_u_23:Disconnect()
				v_u_23 = nil
			end
			v_u_207(false)
			v_u_13 = nil
			v_u_14 = nil
			if v_u_28 ~= false then
				v_u_28 = false
				if v_u_27 then
					v_u_27.panel.Visible = false
				end
			end
			if v_u_29 ~= false then
				v_u_29 = false
				local v369 = v_u_36("FpTouch")
				if v369 then
					local v370 = v369.setTakedown
					if type(v370) == "function" then
						local v371 = v369.setTakedown
						pcall(v371, false)
					end
				end
			end
			if v_u_27 then
				local function v372()
					-- upvalues: (ref) v_u_27
					v_u_27.gui:Destroy()
				end
				pcall(v372)
				v_u_27 = nil
			end
			v_u_28 = false
			table.clear(v_u_21)
			table.clear(v_u_22)
			v_u_6.clear()
		end
	end
end
function v_u_7.step(p373) -- name: step
	-- upvalues: (ref) v_u_11, (copy) v_u_299, (ref) v_u_16, (copy) v_u_30, (copy) v_u_358, (copy) v_u_44, (ref) v_u_19, (ref) v_u_13, (ref) v_u_14, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (copy) v_u_36, (copy) v_u_165, (copy) v_u_43, (copy) v_u_182
	if v_u_11 then
		v_u_299()
		v_u_16 = v_u_16 + p373
		if v_u_16 < 0.1 then
			return
		else
			v_u_16 = 0
			local v374 = v_u_30
			v374.scans = v374.scans + 1
			local v375 = v_u_358
			local v376 = v_u_44
			local v377, v378 = pcall(v375, v376())
			if not v377 then
				local v379 = v_u_30
				v379.errors = v379.errors + 1
				if v_u_30.errors <= 3 then
					warn("[TakedownClient] " .. "watch" .. " failed: " .. tostring(v378))
				end
			end
			if v_u_19 == nil then
				local v380 = v_u_165
				local v381, v382, v383 = pcall(v380)
				if v381 then
					v_u_13 = v382
					v_u_14 = v383
				else
					local v384 = v_u_30
					v384.errors = v384.errors + 1
					if v_u_30.errors <= 3 then
						warn("[TakedownClient] " .. "find" .. " failed: " .. tostring(v382))
					end
					v_u_13 = nil
					v_u_14 = nil
				end
				local v385 = v_u_13 ~= nil
				local v386
				if v385 then
					local v387 = v_u_43("Input")
					local v388
					if v387 then
						local v389 = v387.device
						if type(v389) == "function" then
							local v390 = v387.device
							local v391
							v388, v391 = pcall(v390)
							if v388 then
								v388 = v391 == "Touch"
							end
						else
							v388 = false
						end
					else
						v388 = false
					end
					v386 = not v388
				else
					v386 = v385
				end
				if v386 ~= v_u_28 and (not v386 or v_u_182()) then
					v_u_28 = v386
					if v_u_27 then
						v_u_27.panel.Visible = v386
					end
				end
				if v385 ~= v_u_29 then
					v_u_29 = v385
					local v392 = v_u_36("FpTouch")
					if v392 then
						local v393 = v392.setTakedown
						if type(v393) == "function" then
							local v394 = v392.setTakedown
							pcall(v394, v385)
						end
					end
				end
			else
				v_u_13 = nil
				v_u_14 = nil
				if v_u_28 ~= false then
					v_u_28 = false
					if v_u_27 then
						v_u_27.panel.Visible = false
					end
				end
				if v_u_29 ~= false then
					v_u_29 = false
					local v395 = v_u_36("FpTouch")
					if v395 then
						local v396 = v395.setTakedown
						if type(v396) == "function" then
							local v397 = v395.setTakedown
							pcall(v397, false)
						end
					end
				end
			end
		end
	else
		return
	end
end
function v_u_7.debug() -- name: debug
	-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_19, (ref) v_u_29, (ref) v_u_28, (copy) v_u_30, (copy) v_u_6
	local v398 = string.format
	local v399 = v_u_11
	local v400 = tostring(v399)
	local v401 = v_u_13
	local v402 = tostring(v401)
	local v403 = v_u_19 ~= nil
	local v404 = v_u_29
	local v405 = v_u_28
	return v398("active=%s cand=%s running=%s touch=%s hint=%s scans=%d starts=%d sent=%d denied=%d toasts=%d errors=%d zposeN=%d", v400, v402, tostring(v403), tostring(v404), tostring(v405), v_u_30.scans, v_u_30.starts, v_u_30.sent, v_u_30.denied, v_u_30.toasts, v_u_30.errors, v_u_6.n)
end
return v_u_7