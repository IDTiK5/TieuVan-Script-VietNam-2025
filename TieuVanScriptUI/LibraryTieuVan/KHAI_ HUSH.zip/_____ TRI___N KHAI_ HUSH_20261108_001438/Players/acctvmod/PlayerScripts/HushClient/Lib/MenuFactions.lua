-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuFactions

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = {}
local v_u_4 = nil
local v_u_5 = nil
function v_u_1.serverNow() -- name: serverNow
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	return os.time() + (v_u_4 or (v_u_5 or 0))
end
function v_u_1._noteProfile(p6) -- name: _noteProfile
	-- upvalues: (ref) v_u_5
	local v7
	if type(p6) == "table" then
		local v8 = p6.derived
		v7 = type(v8) == "table" and p6.derived.serverTime or nil
	else
		v7 = nil
	end
	local v9 = tonumber(v7)
	local v10
	if v9 and (v9 == v9 and (v9 >= 1000000000 and v9 <= 100000000000)) then
		v10 = math.floor(v9) - os.time()
	else
		v10 = nil
	end
	if v10 then
		v_u_5 = v10
	end
end
local function v_u_14(p11) -- name: countdown
	local v12 = math.floor(p11)
	local v13 = math.max(0, v12)
	return ("%dd %02dh %02dm"):format(v13 // 86400, v13 % 86400 // 3600, v13 % 3600 // 60)
end
local function v_u_19(p15, p16, p17) -- name: plural
	local v18 = "%d %s"
	if p15 ~= 1 then
		p16 = p17
	end
	return v18:format(p15, p16)
end
local function v_u_22(p20) -- name: pct
	local v21 = p20 * 100 + 0.5
	return ("%d %%"):format((math.floor(v21)))
end
function v_u_1.traderLabel(p23, p24, p25) -- name: traderLabel
	local v26
	if type(p24) == "table" and type(p23) == "string" then
		v26 = p24[p23]
	else
		v26 = nil
	end
	local v27
	if type(v26) == "table" then
		local v28 = v26.name
		if type(v28) == "string" and v26.name ~= "" then
			v27 = v26.name
		else
			v27 = nil
		end
	else
		v27 = nil
	end
	if v27 then
		return string.upper((string.sub(v27, 1, 1))) .. string.lower((string.sub(v27, 2)))
	else
		return p25
	end
end
function v_u_1.leaderLine(p29, p30) -- name: leaderLine
	if p29 == "scrapper" then
		return p30 .. ", the scrapper"
	else
		return p30
	end
end
function v_u_1.resultModal(p_u_31, p_u_32, p33) -- name: resultModal
	-- upvalues: (copy) v_u_19, (copy) v_u_1
	local v34, v_u_35 = pcall(function()
		-- upvalues: (copy) p_u_31
		return p_u_31.cctx.shared.Factions
	end)
	if not v34 or type(v_u_35) ~= "table" then
		v_u_35 = nil
	end
	if v_u_35 and type(p_u_32) == "table" then
		local v_u_36 = p_u_31.ui
		local v_u_37 = p_u_31.theme.color
		local v_u_38 = p_u_31.kit
		local v39 = p_u_32.display
		local v40 = tonumber(v39)
		local v41 = (not v40 or (v40 ~= v40 or (v40 == (1 / 0) or v40 == (-1 / 0)))) and 0 or v40
		if v41 <= 0 then
			local v42 = v_u_35.displayWeek
			local v43 = p_u_32.week
			local v44 = tonumber(v43)
			v41 = v42((not v44 or (v44 ~= v44 or (v44 == (1 / 0) or v44 == (-1 / 0)))) and 0 or v44)
		end
		local v45 = v_u_35.get(p_u_32.winner)
		local v_u_46 = v_u_35.get(p_u_32.faction)
		local v47
		if v45 then
			local v48 = p_u_32.standings
			local v49 = 0
			for _, v50 in type(v48) == "table" and (p_u_32.standings or {}) or {} do
				if type(v50) ~= "table" or v50.id ~= p_u_32.winner then
					continue
				end
				local v51 = v50.avg
				v49 = tonumber(v51)
				if v49 and (v49 == v49 and (v49 ~= (1 / 0) and v49 ~= (-1 / 0))) then
					continue
				end
				v49 = 0
			end
			v47 = ("%s won week %d with %s per raider."):format(v_u_35.prettyName(p_u_32.winner), v41, v_u_38.money(v49))
		else
			v47 = ("Nobody extracted in week %d. No faction won."):format(v41)
		end
		v_u_36.modal({
			["title"] = nil,
			["body"] = nil,
			["width"] = 620,
			["onClose"] = nil,
			["build"] = nil,
			["buttons"] = nil,
			["title"] = ("Week %d results"):format(v41),
			["body"] = v47,
			["onClose"] = p33,
			["build"] = function(p52) -- name: build
				-- upvalues: (copy) p_u_32, (copy) v_u_35, (copy) v_u_36, (copy) v_u_37, (copy) v_u_38, (ref) v_u_19, (copy) v_u_46, (copy) p_u_31, (ref) v_u_1
				local v53 = p_u_32.standings
				local v54 = type(v53) == "table" and (p_u_32.standings or {}) or {}
				local v55 = 1
				for _, v56 in v54 do
					if type(v56) ~= "table" then
						continue
					end
					local v57 = v56.avg
					local v58 = tonumber(v57)
					local v59 = (not v58 or (v58 ~= v58 or (v58 == (1 / 0) or v58 == (-1 / 0)))) and 0 or v58
					v55 = math.max(v55, v59)
				end
				for v60, v61 in v54 do
					if type(v61) ~= "table" then
						continue
					end
					local v62 = v_u_35.get(v61.id)
					local v63 = v_u_36.new
					local v64 = {
						["Name"] = nil,
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil
					}
					local v65 = v61.id
					v64.Name = "S_" .. tostring(v65)
					v64.Size = UDim2.new(1, 0, 0, 40)
					v64.LayoutOrder = v60
					local v66 = v63("Frame", v64, p52)
					local v67 = p_u_32.faction == v61.id
					local v68 = v_u_36.label
					local v69 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["size"] = nil,
						["parent"] = v66
					}
					local v70 = v61.rank
					local v71 = tonumber(v70)
					v69.text = ("#%d  %s%s"):format((not v71 or (v71 ~= v71 or (v71 == (1 / 0) or v71 == (-1 / 0)))) and 0 or v71, not v62 and "?" or v62.name, v67 and "  (yours)" or "")
					local v72
					if v67 then
						v72 = v_u_37.accent
					else
						v72 = v_u_37.text
					end
					v69.color = v72
					v69.size = UDim2.new(0.6, 0, 0, 20)
					v68(v69)
					local v73 = v_u_36.label
					local v74 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "monoS",
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["parent"] = v66
					}
					local v75 = v_u_38.money(v61.avg)
					local v76 = v_u_19
					local v77 = v61.active
					local v78 = tonumber(v77)
					v74.text = ("%s avg  \194\183  %s"):format(v75, v76((not v78 or (v78 ~= v78 or (v78 == (1 / 0) or v78 == (-1 / 0)))) and 0 or v78, "raider", "raiders"))
					v74.position = UDim2.fromScale(0.6, 0)
					v74.size = UDim2.new(0.4, 0, 0, 20)
					v73(v74)
					local v79 = v_u_38.bar
					local v80 = {
						["value"] = nil,
						["color"] = nil,
						["thickness"] = 4
					}
					local v81 = v61.avg
					local v82 = tonumber(v81)
					local v83 = ((not v82 or (v82 ~= v82 or (v82 == (1 / 0) or v82 == (-1 / 0)))) and 0 or v82) / v55
					v80.value = math.clamp(v83, 0, 1)
					local v84
					if v62 then
						v84 = v62.color
					else
						v84 = v_u_37.accent
					end
					v80.color = v84
					local v85 = v79(v66, v80)
					v85.frame.Position = UDim2.fromOffset(0, 24)
					v85.frame.Size = UDim2.new(1, 0, 0, 12)
				end
				local v86
				if v_u_46 then
					if p_u_32.active then
						local v87 = "You fought for %s: %s in %s%s."
						local v88 = v_u_35.prettyName(p_u_32.faction)
						local v89 = v_u_38.money
						local v90 = p_u_32.value
						local v91 = tonumber(v90)
						local v92 = v89((not v91 or (v91 ~= v91 or (v91 == (1 / 0) or v91 == (-1 / 0)))) and 0 or v91)
						local v93 = p_u_32.extracts
						local v94 = tonumber(v93)
						local v95 = (not v94 or (v94 ~= v94 or (v94 == (1 / 0) or v94 == (-1 / 0)))) and 0 or v94
						local v96 = ("%d %s"):format(v95, v95 == 1 and "extract" or "extracts")
						local v97
						if p_u_32.top then
							local v98 = p_u_32.top
							local v99 = tonumber(v98)
							v97 = (", #%d of your faction"):format((not v99 or (v99 ~= v99 or (v99 == (1 / 0) or v99 == (-1 / 0)))) and 0 or v99)
						else
							v97 = p_u_32.qualified and ", top 10 percent of your faction" or ""
						end
						v86 = v87:format(v88, v92, v96, v97)
					else
						v86 = ("You fought for %s but did not extract that week, so there is nothing to collect."):format(v_u_35.prettyName(p_u_32.faction))
					end
				else
					v86 = "You did not pick a faction that week."
				end
				v_u_36.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 10,
					["parent"] = p52,
					["text"] = v86,
					["color"] = v_u_37.text2
				})
				local v100 = v_u_36.new("Frame", {
					["Name"] = "Rewards",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 11,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, p52)
				v_u_36.layout(v100, "v", 6)
				local v101 = v_u_36.new("Frame", {
					["Name"] = "Cells",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 64)
				}, v100)
				v_u_36.layout(v101, "h", 8)
				local v102 = p_u_32.materials
				local v103 = false
				for v104, v105 in type(v102) == "table" and (p_u_32.materials or {}) or {} do
					if type(v105) ~= "table" then
						continue
					end
					local v106 = v105.id
					if type(v106) ~= "string" then
						continue
					end
					local v107 = v_u_38.itemCell
					local v108 = v105.id
					local v109 = {
						["size"] = 64,
						["count"] = nil,
						["order"] = nil
					}
					local v110 = v105.n
					local v111 = tonumber(v110)
					v109.count = (not v111 or (v111 ~= v111 or (v111 == (1 / 0) or v111 == (-1 / 0)))) and 0 or v111
					v109.order = v104
					v107(v101, v108, v109)
					v103 = true
				end
				if not v103 then
					v101.Visible = false
				end
				local v112 = {}
				if p_u_32.blueprint then
					local v113 = v_u_35.byBlueprint(p_u_32.blueprint)
					local v114 = "Blueprint: %s (new recipe at the %s)"
					local v115 = v113 and v113.blueprintName
					if not v115 then
						local v116 = p_u_32.blueprint
						v115 = tostring(v116)
					end
					local v117 = v113 and v113.station == "med_station" and "med station" or "workbench"
					table.insert(v112, v114:format(v115, v117))
				end
				local v118 = {}
				if p_u_32.won and p_u_32.title then
					local v119 = v_u_35.TITLES[p_u_32.title] or p_u_32.title
					local v120 = "Title: " .. tostring(v119)
					table.insert(v112, v120)
					local v121 = #v112
					local v_u_122 = p_u_31
					local v_u_123 = p_u_32.title
					local v_u_124 = v_u_37.success
					local v126, v127 = pcall(function()
						-- upvalues: (copy) v_u_122, (copy) v_u_124, (copy) v_u_123
						if v_u_122.cctx.config.flag("TitleRarity") == false then
							return v_u_124
						end
						local v125 = v_u_122.cctx.shared.TitleRarity
						return v125.textColor(v125.rarityOf(v_u_123), v_u_122.theme)
					end)
					if v126 then
						if typeof(v127) ~= "Color3" then
							v127 = v_u_124
						end
					else
						v127 = v_u_124
					end
					v118[v121] = v127
				end
				if p_u_32.top1Title then
					local function v128()
						-- upvalues: (ref) p_u_31, (ref) p_u_32
						return p_u_31.cctx.shared.TitleRarity.NEW_TITLES[p_u_32.top1Title]
					end
					local v129, v130 = pcall(v128)
					local v131 = v129 and v130 and v130 or p_u_32.top1Title
					local v132 = "Title: " .. tostring(v131)
					table.insert(v112, v132)
					local v133 = #v112
					local v_u_134 = p_u_31
					local v_u_135 = p_u_32.top1Title
					local v_u_136 = v_u_37.success
					local v138, v139 = pcall(function()
						-- upvalues: (copy) v_u_134, (copy) v_u_136, (copy) v_u_135
						if v_u_134.cctx.config.flag("TitleRarity") == false then
							return v_u_136
						end
						local v137 = v_u_134.cctx.shared.TitleRarity
						return v137.textColor(v137.rarityOf(v_u_135), v_u_134.theme)
					end)
					if v138 then
						if typeof(v139) ~= "Color3" then
							v139 = v_u_136
						end
					else
						v139 = v_u_136
					end
					v118[v133] = v139
				end
				if p_u_32.won then
					local v140 = p_u_32.discount
					local v141 = tonumber(v140)
					if ((not v141 or (v141 ~= v141 or (v141 == (1 / 0) or v141 == (-1 / 0)))) and 0 or v141) > 0 then
						local v142 = p_u_32.discountUntil
						local v143 = tonumber(v142)
						local v144 = (not v143 or (v143 ~= v143 or (v143 == (1 / 0) or v143 == (-1 / 0)))) and 0 or v143
						local v145 = p_u_32.discount
						local v146 = tonumber(v145)
						local v147 = ((not v146 or (v146 ~= v146 or (v146 == (1 / 0) or v146 == (-1 / 0)))) and 0 or v146) * 100 + 0.5
						local v148 = ("%d %%"):format((math.floor(v147)))
						local v_u_149 = p_u_31
						local v150 = v_u_35
						local v151 = p_u_32.faction
						local v_u_152 = nil
						local function v153()
							-- upvalues: (ref) v_u_152, (copy) v_u_149
							v_u_152 = v_u_149.cctx.shared.Traders.defs
						end
						pcall(v153)
						local v154 = v_u_1.traderLabel(v151, v_u_152, v150.prettyName(v151))
						local v155 = v144 > 0 and " until the next reset" or " (already expired)"
						table.insert(v112, ("%s off at %s%s"):format(v148, v154, v155))
					end
				end
				if p_u_32.trophy then
					local v156 = p_u_32.trophy
					local v157 = tostring(v156)
					table.insert(v112, ("Trophy plate added to your trophy case: %s. Hang it on the Trophy Wall in your hideout."):format(v157))
				end
				if p_u_32.underdog and p_u_32.active then
					table.insert(v112, "Underdog bonus included")
				end
				for v158, v159 in v112 do
					v_u_36.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v100,
						["text"] = v159,
						["color"] = v118[v158] or v_u_37.success,
						["order"] = 1 + v158
					})
					v103 = true
				end
				if not v103 and (v_u_46 and p_u_32.active) then
					local v160 = p_u_32.pct == true and "No reward this time. The top 10 percent of every faction get a blueprint (at least 3 extracts), the winners get the rest." or "No reward this time. The top three of every faction get a blueprint, the winners get the rest."
					v_u_36.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["parent"] = v100,
						["text"] = v160,
						["color"] = v_u_37.muted
					})
				end
			end,
			["buttons"] = {
				{
					["text"] = "Continue"
				}
			}
		})
	end
end
local v_u_161 = false
function v_u_1.attach(p_u_162) -- name: attach
	-- upvalues: (ref) v_u_161, (copy) v_u_2, (copy) v_u_1
	if v_u_161 then
		return
	else
		v_u_161 = true
		local v163, v_u_164 = pcall(function()
			-- upvalues: (copy) p_u_162
			return p_u_162.cctx.shared.Factions
		end)
		if not v163 or type(v_u_164) ~= "table" then
			v_u_164 = nil
		end
		if v_u_164 then
			pcall(function()
				-- upvalues: (copy) p_u_162, (copy) v_u_164
				local v165 = p_u_162.cctx.shared.Tasks
				for v166, v167 in v_u_164.TITLES do
					v165.titles[v166] = v165.titles[v166] or v167
				end
			end)
			local v_u_168 = nil
			local v_u_169 = false
			local function v_u_176() -- name: check
				-- upvalues: (copy) p_u_162, (ref) v_u_168, (ref) v_u_169, (ref) v_u_2, (ref) v_u_1
				local v170 = p_u_162.profile
				local v171 = type(v170) == "table" and v170.factionResult or nil
				if type(v171) == "table" and (v171.seen == false and (v_u_168 ~= v171.week and not v_u_169)) then
					v_u_169 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (ref) p_u_162, (ref) v_u_169, (ref) v_u_168, (ref) v_u_1
						local v172 = os.clock()
						if os.clock() - v172 < 120 then
							task.wait(1.5)
							local v173 = v_u_2:GetAttribute("Place")
							if v173 ~= nil and v173 ~= "Menu" or (p_u_162.ui.modalCount() ~= 0 or v_u_2:GetAttribute("MenuOpen") == false) then
								continue
							end
						end
						v_u_169 = false
						local v174 = p_u_162.profile
						local v_u_175 = type(v174) == "table" and p_u_162.profile.factionResult or nil
						if type(v_u_175) == "table" and (v_u_175.seen == false and v_u_168 ~= v_u_175.week) then
							v_u_168 = v_u_175.week
							v_u_1.resultModal(p_u_162, v_u_175, function()
								-- upvalues: (ref) p_u_162, (copy) v_u_175
								p_u_162.op({
									["op"] = "factionSeen",
									["week"] = nil,
									["week"] = v_u_175.week
								})
							end)
						end
					end)
				end
			end
			if p_u_162.changed then
				p_u_162.changed:Connect(function(p177)
					-- upvalues: (ref) v_u_1, (copy) p_u_162, (copy) v_u_176
					if p177 == "profile" then
						v_u_1._noteProfile(p_u_162.profile)
						v_u_176()
					end
				end)
			end
			v_u_1._noteProfile(p_u_162.profile)
			v_u_176()
			task.spawn(function()
				-- upvalues: (copy) p_u_162, (ref) v_u_2, (copy) v_u_164, (ref) v_u_1
				local v178 = os.clock()
				if os.clock() - v178 < 600 then
					task.wait(6)
					local v179 = p_u_162.profile
					local v180 = v_u_2:GetAttribute("Place")
					if type(v179) ~= "table" or v180 ~= nil and v180 ~= "Menu" or (v_u_2:GetAttribute("MenuOpen") ~= true or p_u_162.ui.modalCount() ~= 0) then
						continue
					end
					local v181 = v_u_164.weekIndex(v_u_1.serverNow())
					local v182 = v179.faction
					local v183 = v179.stats
					local v184
					if type(v183) == "table" then
						local v185 = v179.stats.extracts
						v184 = tonumber(v185) or 0
					else
						v184 = 0
					end
					if (type(v182) ~= "table" or v182.week ~= v181) and (v184 or 0) >= 1 then
						local v186 = p_u_162.ui.toast
						pcall(v186, "Faction war: pick Doc, Gunner or Rook", "info", "Leaderboard, Factions. Your extracts count for the faction you pick.")
					end
				end
			end)
			v_u_2:GetAttributeChangedSignal("DevFactionAct"):Connect(function()
				-- upvalues: (ref) v_u_2, (copy) p_u_162, (ref) v_u_1
				if v_u_2:GetAttribute("DevFactionAct") == "result" then
					v_u_2:SetAttribute("DevFactionAct", nil)
					local v187 = p_u_162.profile
					local v188 = type(v187) == "table" and p_u_162.profile.factionResult or nil
					if type(v188) == "table" then
						v_u_1.resultModal(p_u_162, v188)
					end
				end
			end)
		end
	end
end
function v_u_1.cardShift(p189, p190, p191, p192) -- name: cardShift
	return p189 and (p190 and (p191 and p192 < 1000)) and 22 or 0
end
function v_u_1.nameShare(p193) -- name: nameShare
	return p193 and 0.55 or 0.62
end
function v_u_1.mount(p_u_194, p195) -- name: mount
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_22, (copy) v_u_14, (ref) v_u_4
	local v_u_196 = p_u_194.ui
	local v_u_197 = p_u_194.theme
	local v_u_198 = v_u_197.color
	local v_u_199 = p_u_194.kit
	local v200, v_u_201 = pcall(function()
		-- upvalues: (copy) p_u_194
		return p_u_194.cctx.shared.Factions
	end)
	if not v200 or type(v_u_201) ~= "table" then
		v_u_201 = nil
	end
	local v_u_202 = {}
	local v_u_203 = nil
	local v_u_204 = true
	local v_u_205 = v_u_196.new("Frame", {
		["Name"] = "Factions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, p195)
	v_u_202.frame = v_u_205
	local v_u_206 = v_u_196.new("ScrollingFrame", {
		["Name"] = "Scroll",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarThickness"] = v_u_197.scrollBar,
		["ScrollBarImageColor3"] = v_u_198.lineStrong,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, v_u_205)
	v_u_196.layout(v_u_206, "v", 12)
	v_u_196.pad(v_u_206, {
		0,
		8,
		0,
		6
	})
	local function v_u_220(p_u_207) -- name: confirmJoin
		-- upvalues: (copy) v_u_201, (ref) v_u_203, (ref) v_u_1, (copy) v_u_196, (copy) p_u_194
		if v_u_201 then
			local v208 = v_u_203
			if type(v208) == "table" then
				local v209 = v_u_201.get(p_u_207)
				if v209 then
					local v210 = v_u_203.underdogs
					local v211
					if type(v210) == "table" then
						v211 = v_u_203.underdogs[p_u_207] == true
					else
						v211 = false
					end
					local v212 = v_u_203.endsAt
					local v213 = tonumber(v212)
					local v214 = ((not v213 or (v213 ~= v213 or (v213 == (1 / 0) or v213 == (-1 / 0)))) and 0 or v213) - v_u_1.serverNow()
					local v215 = v_u_196.modal
					local v216 = {
						["title"] = ("Join %s?"):format(v209.name)
					}
					local v217 = math.floor(v214)
					local v218 = math.max(0, v217)
					v216.body = ("Your pick is locked until the weekly reset (in %s). Every extract from now on counts for %s."):format(("%dd %02dh %02dm"):format(v218 // 86400, v218 % 86400 // 3600, v218 % 3600 // 60), v_u_201.prettyName(p_u_207)) .. (v211 and " Underdog: this faction is the smallest right now, your material rewards get +50 %." or "")
					v216.buttons = {
						{
							["text"] = "Cancel"
						},
						{
							["text"] = "Join " .. v209.name,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) p_u_194, (copy) p_u_207
								local v219 = {
									["op"] = "factionJoin",
									["faction"] = nil,
									["faction"] = p_u_207
								}
								p_u_194.op(v219)
							end
						}
					}
					v215(v216)
				end
			end
		end
	end
	local function v_u_316(p221, p_u_222, p223, p224) -- name: card
		-- upvalues: (copy) v_u_201, (ref) v_u_203, (copy) p_u_194, (ref) v_u_1, (copy) v_u_197, (copy) v_u_196, (copy) v_u_198, (copy) v_u_199, (ref) v_u_3, (ref) v_u_2, (copy) v_u_220
		local v225 = v_u_201.get(p_u_222.id)
		if v225 then
			local v226 = v_u_203
			local v227
			if type(v226) == "table" then
				local v228 = v_u_203.rules
				if type(v228) == "table" and v_u_203.rules.pct == true then
					local v_u_229 = p_u_194
					local v230
					v230, v227 = pcall(function()
						-- upvalues: (copy) v_u_229
						return v_u_229.cctx.shared.FactionCut
					end)
					if not v230 or type(v227) ~= "table" then
						v227 = nil
					end
				else
					v227 = nil
				end
			else
				v227 = nil
			end
			local v231 = v_u_203.mine
			local v232
			if type(v231) == "table" then
				v232 = v_u_203.mine.id == p_u_222.id
			else
				v232 = false
			end
			local v233 = v_u_203.underdogs
			local v234
			if type(v233) == "table" then
				v234 = v_u_203.underdogs[p_u_222.id] == true
			else
				v234 = false
			end
			local v235 = v_u_1.cardShift(v_u_197.isPhone(), v232, v234, v_u_197.safeRefSize().X)
			local v236 = v_u_196.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Card_" .. p_u_222.id,
				["BackgroundColor3"] = v_u_198.raised,
				["Size"] = UDim2.new(0.3333333333333333, -8, 0, not v227 and 440 or v227.cardHeight(true, v_u_197.isPhone())),
				["LayoutOrder"] = p224
			}, p221)
			local v237 = v_u_196.stroke
			local v238
			if v232 then
				v238 = v_u_198.accent
			else
				v238 = v_u_198.line
			end
			v237(v236, v238)
			v_u_196.new("Frame", {
				["Name"] = "Accent",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v225.color,
				["Size"] = UDim2.new(1, 0, 0, 3)
			}, v236)
			local v239 = v_u_196.new("Frame", {
				["Name"] = "Inner",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(14, 14),
				["Size"] = UDim2.new(1, -28, 1, -28)
			}, v236)
			v_u_199.portrait(v239, p_u_222.id, v225.color, 64)
			v_u_196.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h2",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = v225.name,
				["position"] = UDim2.fromOffset(76, 0),
				["size"] = UDim2.new(1, -76, 0, 30)
			})
			v_u_196.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = v_u_1.leaderLine(p_u_222.id, v225.leader),
				["color"] = v_u_198.text2,
				["position"] = UDim2.fromOffset(76, 32),
				["size"] = UDim2.new(1, -76, 0, 18)
			})
			local v240 = v_u_196.new
			local v241 = "Frame"
			local v242 = {
				["Name"] = "Chips",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil
			}
			local v243
			if v235 > 0 then
				v243 = UDim2.fromOffset(0, 68)
			else
				v243 = UDim2.fromOffset(76, 50)
			end
			v242.Position = v243
			v242.Size = UDim2.new(1, v235 > 0 and 0 or -76, 0, 18)
			local v244 = v240(v241, v242, v239)
			v_u_196.layout(v244, "h", 6)
			local v245 = v_u_196.badge
			local v246 = p_u_222.rank
			local v247 = tonumber(v246)
			local v248 = ("#%d"):format((not v247 or (v247 ~= v247 or (v247 == (1 / 0) or v247 == (-1 / 0)))) and 0 or v247)
			local v249
			if p_u_222.rank == 1 then
				local v250 = p_u_222.active
				local v251 = tonumber(v250)
				v249 = ((not v251 or (v251 ~= v251 or (v251 == (1 / 0) or v251 == (-1 / 0)))) and 0 or v251) > 0 and "accent" or "muted"
			else
				v249 = "muted"
			end
			v245(v248, v249, {
				["parent"] = nil,
				["order"] = 1,
				["parent"] = v244
			})
			if v232 then
				v_u_196.badge("YOUR FACTION", "success", {
					["parent"] = nil,
					["order"] = 2,
					["parent"] = v244
				})
			end
			if v234 then
				local v252 = v_u_196.badge("UNDERDOG", "info", {
					["parent"] = nil,
					["order"] = 3,
					["parent"] = v244
				})
				v_u_196.tooltip(v252, function()
					return {
						["title"] = "UNDERDOG",
						["body"] = "The smallest faction right now: material rewards +50 %."
					}
				end)
			end
			v_u_196.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = v225.motto,
				["color"] = v_u_198.muted,
				["position"] = UDim2.fromOffset(0, 74 + v235),
				["size"] = UDim2.new(1, 0, 0, 34)
			}).TextYAlignment = Enum.TextYAlignment.Top
			v_u_196.label({
				["parent"] = nil,
				["text"] = "Average per raider",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["color"] = v_u_198.text2,
				["position"] = UDim2.fromOffset(0, 114 + v235),
				["size"] = UDim2.new(1, 0, 0, 14)
			})
			local v253 = v_u_196.label
			local v254 = {
				["parent"] = nil,
				["name"] = "Avg",
				["text"] = nil,
				["style"] = "monoL",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = v_u_199.money(p_u_222.avg)
			}
			local v255
			if v232 then
				v255 = v_u_198.accent
			else
				v255 = v_u_198.text
			end
			v254.color = v255
			v254.position = UDim2.fromOffset(0, 130 + v235)
			v254.size = UDim2.new(1, 0, 0, 30)
			v253(v254)
			local v256 = v_u_199.bar
			local v257 = {
				["value"] = nil,
				["color"] = nil,
				["thickness"] = 6
			}
			local v258 = p_u_222.avg
			local v259 = tonumber(v258)
			local v260 = ((not v259 or (v259 ~= v259 or (v259 == (1 / 0) or v259 == (-1 / 0)))) and 0 or v259) / math.max(1, p223)
			v257.value = math.clamp(v260, 0, 1)
			v257.color = v225.color
			local v261 = v256(v239, v257)
			v261.frame.Position = UDim2.fromOffset(0, 164 + v235)
			v261.frame.Size = UDim2.new(1, 0, 0, 8)
			local v262 = v_u_197.isPhone()
			local v263 = v_u_196.label
			local v264 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["wrap"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239
			}
			local v265 = p_u_222.active
			local v266 = tonumber(v265)
			local v267 = (not v266 or (v266 ~= v266 or (v266 == (1 / 0) or v266 == (-1 / 0)))) and 0 or v266
			local v268 = ("%d %s"):format(v267, v267 == 1 and "raider" or "raiders")
			local v269 = p_u_222.members
			local v270 = tonumber(v269)
			local v271 = (not v270 or (v270 ~= v270 or (v270 == (1 / 0) or v270 == (-1 / 0)))) and 0 or v270
			v264.text = ("%s  \194\183  %s  \194\183  %s total"):format(v268, ("%d %s"):format(v271, v271 == 1 and "member" or "members"), v_u_199.money(p_u_222.sum))
			v264.color = v_u_198.text2
			v264.wrap = v262
			v264.position = UDim2.fromOffset(0, 178 + v235)
			v264.size = UDim2.new(1, 0, 0, v262 and 26 or 18)
			local v272 = v263(v264)
			if v262 then
				v272.TextYAlignment = Enum.TextYAlignment.Top
			end
			v_u_196.tooltip(v272, function()
				return {
					["title"] = "RAIDERS",
					["body"] = "Raiders extracted at least once this week. The average per raider decides the winner."
				}
			end)
			local v273, v274
			if v227 then
				local v275 = v_u_3[p_u_222.id]
				if type(v275) == "table" and v275.week ~= v_u_203.week then
					v275 = nil
				end
				local v276 = v227.board
				local v277 = v_u_203.boards
				local v278
				if type(v277) == "table" then
					v278 = v_u_203.boards[p_u_222.id]
				else
					v278 = nil
				end
				local v279 = v_u_203.leaders
				local v280
				if type(v279) == "table" then
					v280 = v_u_203.leaders[p_u_222.id]
				else
					v280 = nil
				end
				v273 = v276(v278, v280, v275)
				local v281 = v_u_203.rules
				local v282 = v227.texts
				local v283 = {
					["pctOn"] = true,
					["loaded"] = nil,
					["stale"] = nil,
					["cut"] = nil,
					["approx"] = nil,
					["n"] = nil,
					["rank"] = nil,
					["beyond"] = nil,
					["minX"] = nil,
					["pctOf"] = nil,
					["own"] = nil,
					["loaded"] = v273.loaded,
					["stale"] = v273.stale,
					["cut"] = v273.cut,
					["approx"] = v273.approx,
					["n"] = v273.n,
					["rank"] = v273.rank,
					["beyond"] = v273.beyond,
					["minX"] = v281.minExtracts,
					["pctOf"] = v281.pctOf
				}
				local v284
				if v232 then
					v284 = v_u_203.mine
				else
					v284 = nil
				end
				v283.own = v284
				v274 = v282(v283, v_u_199.money)
			else
				v274 = nil
				v273 = nil
			end
			local v285 = v_u_196.label
			local v286 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239
			}
			local v287
			if v274 then
				v287 = v274.head
			else
				local v288 = v_u_201.TOP_N
				v287 = "Blueprint race (top " .. tostring(v288) .. ")"
			end
			v286.text = v287
			v286.color = v_u_198.text2
			v286.position = UDim2.fromOffset(0, 206 + v235)
			v286.size = UDim2.new(1, 0, 0, 14)
			v285(v286)
			local v289
			if v273 then
				v289 = v273.rows
			else
				local v290 = v_u_203.leaders
				if type(v290) == "table" then
					v289 = v_u_203.leaders[p_u_222.id]
				else
					v289 = nil
				end
			end
			local v291 = 224 + v235
			local v292 = 0
			for v293, v294 in type(v289) == "table" and v289 and v289 or {} do
				if type(v294) ~= "table" or v_u_201.TOP_N < v293 then
					continue
				end
				v292 = v292 + 1
				local v295 = v294.userId
				local v296 = tonumber(v295) == v_u_2.UserId
				local v297 = v_u_1.nameShare(v262)
				local v298 = v_u_196.label
				local v299 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v239
				}
				local v300 = v294.name or "?"
				v299.text = ("%d. %s"):format(v293, (tostring(v300)))
				local v301
				if v296 then
					v301 = v_u_198.accent
				else
					v301 = v_u_198.text
				end
				v299.color = v301
				v299.position = UDim2.fromOffset(0, v291)
				v299.size = UDim2.new(v297, 0, 0, 20)
				v298(v299)
				v_u_196.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v239,
					["text"] = v_u_199.money(v294.value),
					["position"] = UDim2.new(v297, 0, 0, v291),
					["size"] = UDim2.new(1 - v297, 0, 0, 20)
				})
				v291 = v291 + 22
			end
			if v292 == 0 then
				local v302 = v273 and (not v273.loaded or v273.stale) and "Standings are updating" or "Nobody yet. Extract to claim a spot."
				v_u_196.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["fit"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v239,
					["text"] = v302,
					["color"] = v_u_198.muted,
					["fit"] = v273 ~= nil and true or nil,
					["position"] = UDim2.fromOffset(0, v291),
					["size"] = UDim2.new(1, 0, 0, 20)
				})
			end
			if v227 and v274 then
				local v303, v304 = v227.lineHeights(v262)
				local v305 = 292 + v235
				if v274.note and v292 > 0 then
					v_u_196.label({
						["parent"] = nil,
						["name"] = "Note",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["fit"] = true,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v239,
						["text"] = v274.note,
						["color"] = v_u_198.muted,
						["position"] = UDim2.fromOffset(0, v305),
						["size"] = UDim2.new(1, 0, 0, 14)
					})
				end
				v_u_196.label({
					["parent"] = nil,
					["name"] = "Line",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v239,
					["text"] = v274.need,
					["color"] = v_u_198.text2,
					["position"] = UDim2.fromOffset(0, v305 + 16),
					["size"] = UDim2.new(1, 0, 0, v303)
				}).TextYAlignment = Enum.TextYAlignment.Top
				if v274.you then
					local v306
					if v273.stale or not v273.loaded then
						v306 = v_u_198.text2
					else
						local v307 = v274.you
						if string.sub(v307, 1, 11) == "You qualify" then
							v306 = v_u_198.success
						else
							v306 = v_u_198.accent
						end
					end
					v_u_196.label({
						["parent"] = nil,
						["name"] = "Standing",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v239,
						["text"] = v274.you,
						["color"] = v306,
						["position"] = UDim2.fromOffset(0, v305 + 18 + v303),
						["size"] = UDim2.new(1, 0, 0, v304)
					}).TextYAlignment = Enum.TextYAlignment.Top
				end
			end
			v_u_196.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = ("Blueprint: %s"):format(v225.blueprintName),
				["color"] = v_u_198.text2,
				["position"] = UDim2.new(0, 0, 1, -100),
				["size"] = UDim2.new(1, 0, 0, 20)
			})
			v_u_196.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v239,
				["text"] = v225.blueprintDesc,
				["color"] = v_u_198.muted,
				["position"] = UDim2.new(0, 0, 1, -80),
				["size"] = UDim2.new(1, 0, 0, 34)
			}).TextYAlignment = Enum.TextYAlignment.Top
			local v308 = v_u_203.mine
			if type(v308) == "table" then
				if v232 then
					local v309 = v_u_203.mine
					local v310 = v_u_199.money(v309.value)
					local v311 = v309.extracts
					local v312 = tonumber(v311)
					local v313 = (not v312 or (v312 ~= v312 or (v312 == (1 / 0) or v312 == (-1 / 0)))) and 0 or v312
					local v314 = ("You: %s in %s%s"):format(v310, ("%d %s"):format(v313, v313 == 1 and "extract" or "extracts"), v309.underdog and "  \194\183  underdog" or "")
					local v315
					if v262 then
						v315 = v_u_196.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["align"] = "center",
							["wrap"] = true,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v239,
							["text"] = v314,
							["color"] = v_u_198.accent,
							["position"] = UDim2.new(0, 0, 1, -42),
							["size"] = UDim2.new(1, 0, 0, 40)
						})
					else
						v315 = v_u_196.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["align"] = "center",
							["position"] = nil,
							["size"] = nil,
							["parent"] = v239,
							["text"] = v314,
							["color"] = v_u_198.accent,
							["position"] = UDim2.new(0, 0, 1, -32),
							["size"] = UDim2.new(1, 0, 0, 28)
						})
					end
					v_u_196.tooltip(v315, function()
						return {
							["title"] = "YOUR WEEK",
							["body"] = "Counts only loot you found yourself. Loot a squad mate found does not add to the faction."
						}
					end)
				end
			else
				v_u_196.button({
					["parent"] = nil,
					["name"] = "Join",
					["text"] = nil,
					["kind"] = nil,
					["height"] = 40,
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = v239,
					["text"] = "Join " .. v225.name,
					["kind"] = v234 and "primary" or "secondary",
					["size"] = UDim2.new(1, 0, 0, v_u_197.touch(40)),
					["position"] = UDim2.fromScale(0, 1),
					["anchor"] = Vector2.new(0, 1),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_220, (copy) p_u_222
						v_u_220(p_u_222.id)
					end
				})
			end
		else
			return
		end
	end
	function v_u_202.draw() -- name: draw
		-- upvalues: (ref) v_u_204, (copy) v_u_199, (copy) v_u_206, (copy) v_u_201, (ref) v_u_203, (copy) v_u_196, (copy) v_u_198, (copy) p_u_194, (copy) v_u_197, (copy) v_u_316, (ref) v_u_22, (ref) v_u_1, (ref) v_u_14, (ref) v_u_2
		if v_u_204 then
			v_u_199.clear(v_u_206)
			if v_u_201 then
				local v317 = v_u_203
				if type(v317) == "table" then
					local v318 = v_u_203.display
					local v319 = tonumber(v318)
					local v320 = (not v319 or (v319 ~= v319 or (v319 == (1 / 0) or v319 == (-1 / 0)))) and 0 or v319
					local v321 = v_u_203.mine
					local v322
					if type(v321) == "table" then
						v322 = ("Week %d. You fight for %s this week; you can pick again after the reset."):format(v320, v_u_201.prettyName(v_u_203.mine.id))
					else
						v322 = ("Week %d. Pick a faction: every extract adds the loot you found yourself. The highest average per raider wins. Your pick is locked until the reset."):format(v320)
					end
					local v323 = v_u_196.label
					local v324 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = v_u_206,
						["text"] = v322
					}
					local v325 = v_u_203.mine
					local v326
					if type(v325) == "table" then
						v326 = v_u_198.text2
					else
						v326 = v_u_198.text
					end
					v324.color = v326
					v323(v324)
					local v327 = v_u_203
					local v328
					if type(v327) == "table" then
						local v329 = v_u_203.rules
						if type(v329) == "table" and v_u_203.rules.pct == true then
							local v_u_330 = p_u_194
							local v331
							v331, v328 = pcall(function()
								-- upvalues: (copy) v_u_330
								return v_u_330.cctx.shared.FactionCut
							end)
							if not v331 or type(v328) ~= "table" then
								v328 = nil
							end
						else
							v328 = nil
						end
					else
						v328 = nil
					end
					local v332 = v_u_196.new("Frame", {
						["Name"] = "Cards",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 2,
						["Size"] = UDim2.new(1, -6, 0, not v328 and 440 or v328.cardHeight(true, v_u_197.isPhone()))
					}, v_u_206)
					v_u_196.layout(v332, "h", 12)
					local v333 = v_u_203.standings
					local v334 = type(v333) == "table" and (v_u_203.standings or {}) or {}
					local v335 = 1
					for _, v336 in v334 do
						local v337
						if type(v336) == "table" then
							v337 = v336.avg
						else
							v337 = false
						end
						local v338 = tonumber(v337)
						local v339 = (not v338 or (v338 ~= v338 or (v338 == (1 / 0) or v338 == (-1 / 0)))) and 0 or v338
						v335 = math.max(v335, v339)
					end
					local v340 = {}
					for _, v341 in v334 do
						if type(v341) ~= "table" then
							continue
						end
						v340[v341.id] = v341
					end
					local v342 = 0
					for v343, v344 in v_u_201.ORDER do
						local v345 = v340[v344]
						if not v345 then
							continue
						end
						v_u_316(v332, v345, v335, v343)
						v342 = v342 + 1
					end
					local v346 = v_u_203.rules
					local v347 = type(v346) == "table" and (v_u_203.rules or {}) or {}
					local _, v_u_348 = v_u_199.card(v_u_206, {
						["order"] = 3,
						["gap"] = 4,
						["padding"] = 12
					})
					v_u_196.label({
						["parent"] = nil,
						["text"] = "Rewards at the weekly reset",
						["style"] = "h3",
						["textSize"] = 16,
						["order"] = 1,
						["size"] = nil,
						["parent"] = v_u_348,
						["size"] = UDim2.new(1, 0, 0, 20)
					})
					local v349 = v_u_196.label
					local v350 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["parent"] = v_u_348
					}
					local v351 = v347.discount
					local v352 = tonumber(v351)
					local v353 = ((not v352 or (v352 ~= v352 or (v352 == (1 / 0) or v352 == (-1 / 0)))) and 0 or v352) * 100 + 0.5
					local v354 = ("%d %%"):format((math.floor(v353)))
					local v355 = v347.winMaterials
					local v356 = tonumber(v355)
					v350.text = ("Winning faction (everyone who extracted): champion title, %s off at their trader for a week, a trophy plate for the hideout wall, %d rare materials."):format(v354, (not v356 or (v356 ~= v356 or (v356 == (1 / 0) or v356 == (-1 / 0)))) and 0 or v356)
					v349(v350)
					local v357
					if v328 then
						local v358 = v347.pctOf
						local v359 = tonumber(v358)
						local v360 = (not v359 or (v359 ~= v359 or (v359 == (1 / 0) or v359 == (-1 / 0)))) and 0 or v359
						local v361 = v347.minExtracts
						local v362 = tonumber(v361)
						local v363 = (not v362 or (v362 ~= v362 or (v362 == (1 / 0) or v362 == (-1 / 0)))) and 0 or v362
						local v364 = v347.topMaterials
						local v365 = tonumber(v364)
						v357 = ("The top %d percent of every faction (at least %d extracts that week): the faction blueprint (a permanent hideout recipe) and %d rare materials. Rare materials never drop in raids; the recipes use them up."):format(v360, v363, (not v365 or (v365 ~= v365 or (v365 == (1 / 0) or v365 == (-1 / 0)))) and 0 or v365)
					else
						local v366 = v347.topN
						local v367 = tonumber(v366)
						local v368 = (not v367 or (v367 ~= v367 or (v367 == (1 / 0) or v367 == (-1 / 0)))) and 0 or v367
						local v369 = v347.topMaterials
						local v370 = tonumber(v369)
						v357 = ("Top %d of every faction: the faction blueprint (a permanent hideout recipe) and %d rare materials. Rare materials never drop in raids; the recipes use them up."):format(v368, (not v370 or (v370 ~= v370 or (v370 == (1 / 0) or v370 == (-1 / 0)))) and 0 or v370)
					end
					v_u_196.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 3,
						["parent"] = v_u_348,
						["text"] = v357
					})
					local function v372()
						-- upvalues: (ref) p_u_194, (ref) v_u_196, (copy) v_u_348
						if p_u_194.cctx.config.flag("RankTitles") ~= false then
							local v371 = p_u_194.cctx.shared.TitleRarity
							v_u_196.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "small",
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 4,
								["parent"] = v_u_348,
								["text"] = ("Number 1 of every faction also gets the title %s (at least %d extracts and $%s of your own that week)."):format(v371.NEW_TITLES.faction_top1, v371.RULES.factionMinExtracts, v_u_196.commas(v371.RULES.factionMinValue))
							})
						end
					end
					pcall(v372)
					local v373 = v_u_196.label
					local v374 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 5,
						["parent"] = v_u_348
					}
					local v375 = v_u_22
					local v376 = v347.underdogDiscount
					local v377 = tonumber(v376)
					v374.text = ("Underdog: pick the smallest faction and your materials get +50 %%, the discount +%s."):format(v375((not v377 or (v377 ~= v377 or (v377 == (1 / 0) or v377 == (-1 / 0)))) and 0 or v377))
					v373(v374)
					local v378 = {}
					local v379 = v_u_203.last
					if type(v379) == "table" then
						local v380 = v_u_203.last.display
						local v381 = tonumber(v380)
						if ((not v381 or (v381 ~= v381 or (v381 == (1 / 0) or v381 == (-1 / 0)))) and 0 or v381) >= 1 then
							local v382 = v_u_201.get(v_u_203.last.winner)
							local v383
							if v382 then
								local v384 = v_u_203.last.display
								local v385 = tonumber(v384)
								v383 = ("Week %d: %s won."):format((not v385 or (v385 ~= v385 or (v385 == (1 / 0) or v385 == (-1 / 0)))) and 0 or v385, v382.name)
							else
								local v386 = v_u_203.last.display
								local v387 = tonumber(v386)
								v383 = ("Week %d: no winner."):format((not v387 or (v387 ~= v387 or (v387 == (1 / 0) or v387 == (-1 / 0)))) and 0 or v387)
							end
							table.insert(v378, v383)
						end
					end
					local v388 = v_u_203.blueprints
					local v389 = {}
					for v390 in type(v388) == "table" and (v_u_203.blueprints or {}) or {} do
						local v391 = v_u_201.byBlueprint(v390)
						if not v391 then
							continue
						end
						local v392 = v391.blueprintName
						table.insert(v389, v392)
					end
					table.sort(v389)
					if #v389 > 0 then
						local v393 = "Your blueprints: " .. table.concat(v389, ", ")
						table.insert(v378, v393)
					end
					local v394 = v_u_203.perk
					if type(v394) == "table" then
						local v395 = v_u_203.perk.untilAt
						local v396 = tonumber(v395)
						if ((not v396 or (v396 ~= v396 or (v396 == (1 / 0) or v396 == (-1 / 0)))) and 0 or v396) > v_u_1.serverNow() then
							local v397 = v_u_203.perk.pct
							local v398 = tonumber(v397)
							local v399 = ((not v398 or (v398 ~= v398 or (v398 == (1 / 0) or v398 == (-1 / 0)))) and 0 or v398) * 100 + 0.5
							local v400 = ("%d %%"):format((math.floor(v399)))
							local v_u_401 = p_u_194
							local v402 = v_u_201
							local v403 = v_u_203.perk.trader
							local v_u_404 = nil
							local function v405()
								-- upvalues: (ref) v_u_404, (copy) v_u_401
								v_u_404 = v_u_401.cctx.shared.Traders.defs
							end
							pcall(v405)
							local v406 = v_u_1.traderLabel(v403, v_u_404, v402.prettyName(v403))
							local v407 = v_u_14
							local v408 = v_u_203.perk.untilAt
							local v409 = tonumber(v408)
							local v410 = ((not v409 or (v409 ~= v409 or (v409 == (1 / 0) or v409 == (-1 / 0)))) and 0 or v409) - v_u_1.serverNow()
							table.insert(v378, ("Champion discount: %s off at %s, %s left."):format(v400, v406, v407(v410)))
						end
					end
					if v_u_203.offline then
						table.insert(v378, "Global standings offline: showing this server only.")
					end
					for v411, v412 in v378 do
						v_u_196.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_206,
							["text"] = v412,
							["color"] = v_u_198.text2,
							["order"] = 10 + v411
						})
					end
					local v413 = v_u_2
					local v414 = "FactionView"
					local v415 = "%s %d"
					local v416 = v_u_203.mine
					local v417
					if type(v416) == "table" then
						local v418 = v_u_203.mine.id
						v417 = tostring(v418)
					else
						v417 = "-"
					end
					v413:SetAttribute(v414, v415:format(v417, v342))
				else
					v_u_199.empty(v_u_206, "Loading the factions...")
				end
			else
				v_u_199.empty(v_u_206, "Factions are not available right now.")
				return
			end
		else
			return
		end
	end
	local v_u_419 = {
		3,
		6,
		12,
		24
	}
	local v_u_420 = 0
	local v_u_421 = 0
	local function v_u_431(p422) -- name: drawNotice
		-- upvalues: (ref) v_u_204, (copy) v_u_205, (copy) v_u_199, (copy) v_u_206, (copy) p_u_194, (copy) v_u_201, (ref) v_u_1, (copy) v_u_196, (copy) v_u_198
		if v_u_204 and v_u_205.Visible then
			v_u_199.clear(v_u_206)
			v_u_199.empty(v_u_206, p422)
			local function v430()
				-- upvalues: (ref) p_u_194, (ref) v_u_201, (ref) v_u_1, (ref) v_u_199, (ref) v_u_196, (ref) v_u_206, (ref) v_u_198
				local v_u_423 = p_u_194
				local v424, v425 = pcall(function()
					-- upvalues: (copy) v_u_423
					return v_u_423.cctx.shared.FactionCut
				end)
				if not v424 or type(v425) ~= "table" then
					v425 = nil
				end
				if v425 and (v_u_201 and p_u_194.cctx.config.flag("FactionTopPct") ~= false) then
					local v426 = p_u_194.profile
					local v427 = v425.ownLine
					local v428
					if type(v426) == "table" then
						v428 = v426.faction
					else
						v428 = nil
					end
					local v429 = v427(v428, v_u_201.weekIndex(v_u_1.serverNow()), v_u_199.money, v_u_201.prettyName)
					if v429 then
						v_u_196.label({
							["parent"] = nil,
							["name"] = "OwnStanding",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 1000,
							["parent"] = v_u_206,
							["text"] = v429,
							["color"] = v_u_198.accent
						})
					end
				end
			end
			pcall(v430)
		end
	end
	local v_u_432 = 0
	local v_u_433 = 0
	local function v_u_448(p434) -- name: afterPayload
		-- upvalues: (ref) v_u_203, (copy) p_u_194, (ref) v_u_432, (ref) v_u_3, (ref) v_u_433, (ref) v_u_204, (copy) v_u_205, (copy) v_u_202
		local v435 = v_u_203
		local v436
		if type(v435) == "table" then
			local v437 = v_u_203.rules
			if type(v437) == "table" and v_u_203.rules.pct == true then
				local v_u_438 = p_u_194
				local v439
				v439, v436 = pcall(function()
					-- upvalues: (copy) v_u_438
					return v_u_438.cctx.shared.FactionCut
				end)
				if not v439 or type(v436) ~= "table" then
					v436 = nil
				end
			else
				v436 = nil
			end
		else
			v436 = nil
		end
		if v436 then
			local v440 = p434.boards
			if type(v440) == "table" then
				local v441 = false
				for v442, v443 in p434.boards do
					if type(v443) ~= "table" then
						continue
					end
					if v443.loaded == true and v443.stale ~= true then
						local v444 = p434.leaders
						local v445
						if type(v444) == "table" then
							v445 = p434.leaders[v442]
						else
							v445 = nil
						end
						v_u_3[v442] = {
							["week"] = p434.week,
							["rows"] = v445,
							["cut"] = v443.cut,
							["approx"] = v443.approx,
							["n"] = v443.n
						}
					else
						v441 = true
					end
				end
				if v441 then
					v_u_432 = v_u_432 + 1
					local v446 = v436.CLIENT_RETRY[v_u_432]
					if v446 then
						v_u_433 = v_u_433 + 1
						local v_u_447 = v_u_433
						task.delay(v446, function()
							-- upvalues: (ref) v_u_204, (ref) v_u_205, (copy) v_u_447, (ref) v_u_433, (ref) v_u_202
							if v_u_204 and (v_u_205.Visible and v_u_447 == v_u_433) then
								v_u_202.load(0)
							end
						end)
					end
				else
					v_u_432 = 0
					return
				end
			end
		end
		v_u_432 = 0
	end
	function v_u_202.load(p_u_449) -- name: load
		-- upvalues: (copy) p_u_194, (ref) v_u_204, (ref) v_u_420, (ref) v_u_203, (ref) v_u_4, (copy) v_u_448, (copy) v_u_205, (copy) v_u_196, (copy) v_u_202, (copy) v_u_419, (copy) v_u_431, (ref) v_u_421
		task.spawn(function()
			-- upvalues: (ref) p_u_194, (copy) p_u_449, (ref) v_u_204, (ref) v_u_420, (ref) v_u_203, (ref) v_u_4, (ref) v_u_448, (ref) v_u_205, (ref) v_u_196, (ref) v_u_202, (ref) v_u_419, (ref) v_u_431, (ref) v_u_421
			local v450 = p_u_194.fetch("factions", nil, p_u_449 or 30)
			if v_u_204 then
				if v450 then
					v_u_420 = 0
					if v450 ~= v_u_203 then
						local v451 = v450.now
						local v452 = tonumber(v451)
						local v453
						if v452 and (v452 == v452 and (v452 >= 1000000000 and v452 <= 100000000000)) then
							v453 = math.floor(v452) - os.time()
						else
							v453 = nil
						end
						v_u_4 = v453 or v_u_4
					end
					local v454 = v_u_203
					local v455 = type(v454) == "table"
					v_u_203 = v450
					local v456 = v_u_448
					pcall(v456, v450)
					if v_u_205.Visible then
						if v455 then
							local v457 = v_u_203
							local v458
							if type(v457) == "table" then
								local v459 = v_u_203.rules
								if type(v459) == "table" and v_u_203.rules.pct == true then
									local v_u_460 = p_u_194
									local v461
									v461, v458 = pcall(function()
										-- upvalues: (copy) v_u_460
										return v_u_460.cctx.shared.FactionCut
									end)
									if not v461 or type(v458) ~= "table" then
										v458 = nil
									end
								else
									v458 = nil
								end
							else
								v458 = nil
							end
							if v458 ~= nil then
								v_u_196.keepScroll(v_u_205, v_u_202.draw)
								return
							end
						end
						v_u_202.draw()
					end
					return
				else
					local v462 = v_u_203
					if type(v462) == "table" or not v_u_205.Visible then
						return
					else
						v_u_420 = v_u_420 + 1
						local v463 = v_u_419[v_u_420]
						if v463 then
							v_u_431("Could not load the factions. Retrying...")
							v_u_421 = v_u_421 + 1
							local v_u_464 = v_u_421
							task.delay(v463, function()
								-- upvalues: (ref) v_u_204, (ref) v_u_205, (copy) v_u_464, (ref) v_u_421, (ref) v_u_203, (ref) v_u_202
								if v_u_204 and (v_u_205.Visible and v_u_464 == v_u_421) then
									local v465 = v_u_203
									if type(v465) ~= "table" then
										v_u_202.load(0)
									end
								end
							end)
						else
							v_u_431("Could not load the factions. Open the tab again to retry.")
						end
					end
				end
			else
				return
			end
		end)
	end
	function v_u_202.show() -- name: show
		-- upvalues: (copy) v_u_205, (ref) v_u_421, (ref) v_u_420, (ref) v_u_432, (ref) v_u_433, (copy) v_u_202
		v_u_205.Visible = true
		v_u_421 = v_u_421 + 1
		v_u_420 = 0
		v_u_432 = 0
		v_u_433 = v_u_433 + 1
		v_u_202.draw()
		v_u_202.load(30)
	end
	function v_u_202.hide() -- name: hide
		-- upvalues: (copy) v_u_205
		v_u_205.Visible = false
	end
	function v_u_202.endsAt() -- name: endsAt
		-- upvalues: (ref) v_u_203, (ref) v_u_1
		local v466 = v_u_203
		local v467
		if type(v466) == "table" then
			local v468 = v_u_203.endsAt
			v467 = tonumber(v468)
		else
			v467 = nil
		end
		if v467 then
			return v467 - (v_u_1.serverNow() - os.time())
		else
			return nil
		end
	end
	function v_u_202.refresh(p469, p470) -- name: refresh
		-- upvalues: (copy) p_u_194, (copy) v_u_202
		if p469 == "result" and (type(p470) == "table" and p470.op == "factionJoin") then
			p_u_194.invalidate("factions")
			if p470.ok then
				v_u_202.load(0)
			end
		end
	end
	function v_u_202.destroy() -- name: destroy
		-- upvalues: (ref) v_u_204, (copy) v_u_205
		v_u_204 = false
		v_u_205:Destroy()
	end
	local v_u_473 = v_u_2:GetAttributeChangedSignal("DevFactionAct"):Connect(function()
		-- upvalues: (ref) v_u_2, (copy) p_u_194, (copy) v_u_202
		local v471 = v_u_2:GetAttribute("DevFactionAct")
		if type(v471) == "string" then
			local v472 = string.match(v471, "^join:(%w+)$")
			if v472 then
				v_u_2:SetAttribute("DevFactionAct", nil)
				p_u_194.op({
					["op"] = "factionJoin",
					["faction"] = nil,
					["faction"] = v472
				})
			elseif v471 == "reload" then
				v_u_2:SetAttribute("DevFactionAct", nil)
				p_u_194.invalidate("factions")
				v_u_202.load(0)
			end
		else
			return
		end
	end)
	v_u_205.Destroying:Connect(function()
		-- upvalues: (copy) v_u_473
		v_u_473:Disconnect()
	end)
	return v_u_202
end
return v_u_1