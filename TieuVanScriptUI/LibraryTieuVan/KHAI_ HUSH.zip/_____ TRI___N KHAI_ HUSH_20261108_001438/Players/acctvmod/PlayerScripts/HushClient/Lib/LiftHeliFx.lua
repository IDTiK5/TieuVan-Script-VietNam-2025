-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / LiftHeliFx

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = {}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = Color3.fromRGB(168, 96, 255)
local v_u_7 = Color3.fromRGB(84, 92, 58)
local v_u_8 = Color3.fromRGB(40, 44, 36)
local v_u_9 = nil
function v_u_3.me() -- name: me
	-- upvalues: (copy) v_u_2, (ref) v_u_4
	local v10 = v_u_2.LocalPlayer
	local v11 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v11 then
		local v12 = require
		local v13, v14 = pcall(v12, v11)
		if v13 then
			v_u_4 = v14
		end
	end
	local v15 = v_u_4
	if not (v10 and v15) then
		return {
			["userId"] = 0,
			["squad"] = ""
		}
	end
	local v16 = v10.Character
	local v17 = {
		["userId"] = v10.UserId
	}
	local v18 = v15.squadOf
	local v19 = v10:GetAttribute("LootSquad")
	local v20 = v10:GetAttribute("SquadId")
	local v21
	if v16 then
		v21 = v16:GetAttribute("SquadId")
	else
		v21 = nil
	end
	v17.squad = v18(v19, v20, v21, v10.UserId)
	return v17
end
local function v_u_30(p22, p23, p24, p25, p26, p27, p28) -- name: part
	local v29 = Instance.new("Part")
	v29.Name = p23
	v29.Anchored = true
	v29.CanCollide = false
	v29.CanQuery = false
	v29.CanTouch = false
	v29.CastShadow = p28 ~= true
	v29.Size = p24
	v29.CFrame = p25
	v29.Color = p26
	if p28 then
		p27 = Enum.Material.Neon
	end
	v29.Material = p27
	v29.TopSurface = Enum.SurfaceType.Smooth
	v29.BottomSurface = Enum.SurfaceType.Smooth
	v29.Parent = p22
	return v29
end
local function v_u_38(p31, p32, ...) -- name: audio
	local v33 = p31 and p31.controllers
	if v33 then
		v33 = p31.controllers.Audio
	end
	if v33 and not v33._broken then
		local v34 = v33[p32]
		if type(v34) == "function" then
			local v35 = v33[p32]
			local v36, v37 = pcall(v35, ...)
			if v36 then
				return v37
			end
		end
	end
	return nil
end
local function v_u_71() -- name: crateModel
	-- upvalues: (ref) v_u_4, (copy) v_u_30, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6
	local v39 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v39 then
		local v40 = require
		local v41, v42 = pcall(v40, v39)
		if v41 then
			v_u_4 = v42
		end
	end
	local v43 = v_u_4
	local v44 = v43 and v43.TUNE.crateSize or {
		["x"] = 4.4,
		["y"] = 2.6,
		["z"] = 3.4
	}
	local v45 = Instance.new("Model")
	v45.Name = "LiftCrate"
	local v46 = v_u_30
	local v47 = v44.x
	local v48 = v44.y
	local v49 = v44.z
	local v50 = v46(v45, "Body", Vector3.new(v47, v48, v49), CFrame.new(0, v44.y * 0.5, 0), v_u_7, Enum.Material.Metal)
	local v51 = v_u_30
	local v52 = v44.x + 0.2
	local v53 = v44.z + 0.2
	v51(v45, "Lid", Vector3.new(v52, 0.2, v53), CFrame.new(0, v44.y + 0.1, 0), v_u_8, Enum.Material.Metal)
	for _, v54 in { -1.4, 1.4 } do
		local v55 = v_u_30
		local v56 = v44.y + 0.04
		local v57 = v44.z + 0.06
		v55(v45, "Band", Vector3.new(0.22, v56, v57), CFrame.new(v54, v44.y * 0.5, 0), v_u_8, Enum.Material.Metal)
	end
	local v58 = v_u_30
	local v59 = v44.x + 0.02
	v58(v45, "Stripe", Vector3.new(v59, 0.35, 0.08), CFrame.new(0, v44.y * 0.5, v44.z * 0.5 + 0.03), v_u_6, Enum.Material.SmoothPlastic)
	local v60 = v44.y + 0.2
	local v61 = v60 + 2.4
	local v62 = Vector3.new(0, v61, 0)
	v_u_30(v45, "HookRing", Vector3.new(0.6, 0.25, 0.6), CFrame.new(v62), v_u_8, Enum.Material.Metal)
	for _, v63 in {
		Vector3.new(-1.9, 0, -1.4),
		Vector3.new(1.9, 0, -1.4),
		Vector3.new(-1.9, 0, 1.4),
		Vector3.new(1.9, 0, 1.4)
	} do
		local v64 = v63.X
		local v65 = v63.Z
		local v66 = Vector3.new(v64, v60, v65)
		local v67 = (v66 + v62) * 0.5
		local v68 = v_u_30
		local v69 = (v62 - v66).Magnitude
		v68(v45, "Sling", Vector3.new(0.12, 0.12, v69), CFrame.lookAt(v67, v62), v_u_8, Enum.Material.Metal)
	end
	local v70 = Instance.new("PointLight")
	v70.Color = v_u_6
	v70.Range = 11
	v70.Brightness = 0.9
	v70.Shadows = false
	v70.Parent = v50
	v45.PrimaryPart = v50
	v50.PivotOffset = v50.CFrame:ToObjectSpace(CFrame.new())
	return v45
end
local function v_u_77(p72, p73) -- name: dustPart
	local v74 = Instance.new("Part")
	v74.Name = "LiftDust"
	v74.Anchored = true
	v74.CanCollide = false
	v74.CanQuery = false
	v74.CanTouch = false
	v74.CastShadow = false
	v74.Transparency = 1
	v74.Size = Vector3.new(6, 0.2, 6)
	v74.CFrame = CFrame.new(p73 + Vector3.new(0, 0.4, 0))
	v74.Parent = p72
	local v75 = Instance.new("ParticleEmitter")
	v75.Name = "Dust"
	v75.Texture = "rbxasset://textures/particles/smoke_main.dds"
	local v76 = Color3.fromRGB(176, 160, 134)
	v75.Color = ColorSequence.new(v76, v76:Lerp(Color3.fromRGB(110, 104, 96), 0.5))
	v75.LightEmission = 0
	v75.LightInfluence = 0.6
	v75.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(0.4, 0.7), NumberSequenceKeypoint.new(1, 1) })
	v75.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 8) })
	v75.Lifetime = NumberRange.new(1.3, 2.2)
	v75.Speed = NumberRange.new(9, 15)
	v75.SpreadAngle = Vector2.new(82, 82)
	v75.Acceleration = Vector3.new(0, -9, 0)
	v75.RotSpeed = NumberRange.new(-40, 40)
	v75.EmissionDirection = Enum.NormalId.Top
	v75.Rate = 0
	v75.Parent = v74
	return v74, v75
end
local function v_u_88(p78, p79) -- name: refresh
	-- upvalues: (ref) v_u_4
	local v80 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v80 then
		local v81 = require
		local v82, v83 = pcall(v81, v80)
		if v82 then
			v_u_4 = v83
		end
	end
	local v84 = v_u_4
	if v84 and p79 - p78.readAt >= 0.15 then
		p78.readAt = p79
		local v_u_85 = p78.folder
		if v_u_85.Parent then
			local v87 = v84.fromGetter(function(p86)
				-- upvalues: (copy) v_u_85
				return v_u_85:GetAttribute(p86)
			end)
			if v87 then
				p78.a = v87
			end
		end
	else
		return
	end
end
local v_u_89 = false
local v_u_90 = {}
function v_u_3.create(p91, p92, p_u_93, p94) -- name: create
	-- upvalues: (ref) v_u_4, (copy) v_u_90, (ref) v_u_89, (copy) v_u_3
	local v95 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v95 then
		local v96 = require
		local v97, v98 = pcall(v96, v95)
		if v97 then
			v_u_4 = v98
		end
	end
	local v99 = v_u_4
	if not v99 then
		return nil
	end
	local v101 = v99.fromGetter(function(p100)
		-- upvalues: (copy) p_u_93
		return p_u_93:GetAttribute(p100)
	end)
	if not v101 then
		return nil
	end
	local v102 = {
		["cctx"] = nil,
		["parent"] = nil,
		["folder"] = nil,
		["a"] = nil,
		["dark"] = nil,
		["readAt"] = -1000000000,
		["rig"] = nil,
		["crate"] = nil,
		["rope"] = nil,
		["dust"] = nil,
		["dustEmitter"] = nil,
		["slam"] = false,
		["lastPhase"] = "",
		["frames"] = 0,
		["cctx"] = p91,
		["parent"] = p92,
		["folder"] = p_u_93,
		["a"] = v101,
		["dark"] = (p94 or {}).dark == true
	}
	v_u_90[p_u_93] = v102
	if not v_u_89 and p91 then
		local v103 = p91.command
		if type(v103) == "function" then
			v_u_89 = true
			local v104 = p91.command
			local function v108()
				-- upvalues: (ref) v_u_90, (ref) v_u_3
				local v105 = {}
				for _, v106 in v_u_90 do
					local v107 = v_u_3.state
					table.insert(v105, v107(v106))
				end
				return #v105 == 0 and "no cargo helicopter" or table.concat(v105, " | ")
			end
			pcall(v104, "lift.fx", v108)
		end
	end
	return v102
end
function v_u_3.destroy(p109) -- name: destroy
	-- upvalues: (copy) v_u_90, (copy) v_u_3, (ref) v_u_9, (ref) v_u_5
	if p109 then
		v_u_90[p109.folder] = nil
		if p109.a and (p109.a.owner ~= 0 and p109.a.owner == v_u_3.me().userId) then
			local v110 = not v_u_9 and script.Parent:FindFirstChild("LiftSendUp")
			if v110 then
				local v111 = require
				local v112, v113 = pcall(v111, v110)
				if v112 then
					v_u_9 = v113
				end
			end
			local v114 = v_u_9
			if v114 then
				local v115 = v114.hide
				pcall(v115)
			end
		end
		if p109.rig then
			local v116 = not v_u_5 and script.Parent:FindFirstChild("HeliRig")
			if v116 then
				local v117 = require
				local v118, v119 = pcall(v117, v116)
				if v118 then
					v_u_5 = v119
				end
			end
			local v120 = v_u_5
			if v120 then
				local v121 = v120.destroy
				local v122 = p109.rig
				pcall(v121, v122)
			end
			p109.rig = nil
		end
		for _, v123 in { "crate", "rope", "dust" } do
			local v_u_124 = p109[v123]
			if not v_u_124 then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_124
				v_u_124:Destroy()
			end)
			p109[v123] = nil
		end
		p109.dustEmitter = nil
	end
end
function v_u_3.update(p125, p126, p127) -- name: update
	-- upvalues: (ref) v_u_4, (copy) v_u_88, (ref) v_u_5, (copy) v_u_71, (copy) v_u_30, (copy) v_u_8, (copy) v_u_77, (copy) v_u_3, (ref) v_u_9, (copy) v_u_38
	local v128 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v128 then
		local v129 = require
		local v130, v131 = pcall(v129, v128)
		if v130 then
			v_u_4 = v131
		end
	end
	local v132 = v_u_4
	if not (v132 and p125) then
		return true
	end
	v_u_88(p125, p127)
	local v133 = p125.a
	local v134 = v132.flight(v133, p127)
	p125.frames = p125.frames + 1
	if not v134.visible then
		if p125.rig then
			local v135 = not v_u_5 and script.Parent:FindFirstChild("HeliRig")
			if v135 then
				local v136 = require
				local v137, v138 = pcall(v136, v135)
				if v137 then
					v_u_5 = v138
				end
			end
			local v139 = v_u_5
			if v139 then
				local v140 = v139.destroy
				local v141 = p125.rig
				pcall(v140, v141)
			end
			p125.rig = nil
		end
		if p125.crate then
			p125.crate:Destroy()
			p125.crate = nil
		end
		if p125.rope then
			p125.rope:Destroy()
			p125.rope = nil
		end
		if p125.dustEmitter then
			p125.dustEmitter.Rate = 0
		end
		return v132.endAt(v133) < p127
	end
	p125.lastPhase = v134.phase
	local v142 = v134.x
	local v143 = v134.y
	local v144 = v134.z
	local v145 = Vector3.new(v142, v143, v144)
	local v146 = v134.face.x
	local v147 = v134.face.z
	local v148 = Vector3.new(v146, 0, v147)
	local v149 = CFrame.lookAt(v145, v145 + v148)
	local v150 = CFrame.Angles
	local v151 = v134.pitchDeg
	local v152 = -math.rad(v151)
	local v153 = v134.bankDeg
	local v154 = v149 * v150(v152, 0, (math.rad(v153)))
	if not p125.rig then
		local v155 = not v_u_5 and script.Parent:FindFirstChild("HeliRig")
		if v155 then
			local v156 = require
			local v157, v158 = pcall(v156, v155)
			if v157 then
				v_u_5 = v158
			end
		end
		local v159 = v_u_5
		if v159 then
			local v160 = v159.create
			local v161 = p125.cctx
			local v162 = p125.parent
			local v163 = {
				["light"] = nil,
				["sound"] = true,
				["soundName"] = "ev_heli_rotor",
				["light"] = p125.dark
			}
			local v164, v165 = pcall(v160, v161, v162, v163)
			if v164 then
				p125.rig = v165
			else
				warn("[LiftHeliFx] helicopter rig:", v165)
			end
		end
	end
	if p125.rig then
		local v166 = not v_u_5 and script.Parent:FindFirstChild("HeliRig")
		if v166 then
			local v167 = require
			local v168, v169 = pcall(v167, v166)
			if v168 then
				v_u_5 = v169
			end
		end
		local v170 = v_u_5.pose
		local v171 = p125.rig
		pcall(v170, v171, v154, p126, p127)
	end
	local v172 = (v154 * CFrame.new(0, v132.TUNE.hook, 0)).Position
	local v173 = v134.crate
	if v173.shown then
		if not p125.crate then
			local v174 = v_u_71
			local v175, v176 = pcall(v174)
			if v175 then
				v176.Parent = p125.parent
				p125.crate = v176
			end
		end
		if p125.crate then
			local v177 = CFrame.lookAt(Vector3.new(0, 0, 0), v148)
			local v178 = CFrame.new(v173.x, v173.bottomY + v132.TUNE.ringH, v173.z) * v177 * CFrame.Angles(v173.swayX, 0, v173.swayZ)
			p125.crate:PivotTo(v178 * CFrame.new(0, -v132.TUNE.ringH, 0))
		end
	elseif p125.crate then
		p125.crate:Destroy()
		p125.crate = nil
	end
	if v134.rope.on then
		local v179 = v173.x
		local v180 = v134.rope.ringY
		local v181 = v173.z
		local v182 = Vector3.new(v179, v180, v181)
		if v173.shown and p125.crate then
			v182 = (p125.crate:GetPivot() * CFrame.new(0, v132.TUNE.ringH, 0)).Position
		end
		local v183 = (v172 - v182).Magnitude
		if v183 > 0.05 then
			if not p125.rope then
				local v184 = v_u_30(p125.parent, "LiftRope", Vector3.new(0.14, 0.14, 1), CFrame.new(v172), v_u_8, Enum.Material.Fabric)
				v184.CastShadow = false
				p125.rope = v184
			end
			local v185 = p125.rope
			v185.Size = Vector3.new(0.14, 0.14, v183)
			v185.CFrame = CFrame.lookAt((v172 + v182) * 0.5, v182)
		end
	elseif p125.rope then
		p125.rope:Destroy()
		p125.rope = nil
	end
	if v134.wash > 0.02 then
		if not p125.dust then
			local v186 = v_u_77
			local v187 = p125.parent
			local v188 = v133.spot.x
			local v189 = v133.levelY
			local v190 = v133.spot.z
			local v191 = Vector3.new(v188, v189, v190)
			local v192, v193, v194 = pcall(v186, v187, v191)
			if v192 then
				p125.dust = v193
				p125.dustEmitter = v194
			end
		end
		if p125.dustEmitter then
			p125.dustEmitter.Rate = 34 * v134.wash
		end
	elseif p125.dustEmitter then
		p125.dustEmitter.Rate = 0
	end
	local v195 = v_u_3.me()
	if v133.owner ~= 0 and v133.owner == v195.userId then
		local v196 = not v_u_9 and script.Parent:FindFirstChild("LiftSendUp")
		if v196 then
			local v197 = require
			local v198, v199 = pcall(v197, v196)
			if v198 then
				v_u_9 = v199
			end
		end
		local v200 = v_u_9
		if v200 then
			local v201 = v200.update
			local v202 = p125.cctx
			local v203 = v132.chipEntry(v133, p127, v195)
			pcall(v201, v202, v203, p126)
		end
	end
	if not p125.slam and (v134.phase == "open" and p127 - v133.openAt < 3) then
		p125.slam = true
		local v204 = v_u_38
		local v205 = p125.cctx
		local v206 = v133.spot.x
		local v207 = v133.levelY + 1.5
		local v208 = v133.spot.z
		v204(v205, "play3D", "ev_drop_land", (Vector3.new(v206, v207, v208)))
	end
	return v132.endAt(v133) < p127
end
function v_u_3.state(p209) -- name: state
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (copy) v_u_2
	if not (p209 and p209.a) then
		return "lift ?"
	end
	local v210 = not v_u_4 and script.Parent:FindFirstChild("LiftClientRules")
	if v210 then
		local v211 = require
		local v212, v213 = pcall(v211, v210)
		if v212 then
			v_u_4 = v213
		end
	end
	local v214 = v_u_4
	local v215 = v_u_1.now()
	local v216
	if v214 then
		v216 = v214.flight(p209.a, v215)
	else
		v216 = nil
	end
	if not v216 then
		return "lift (no rules)"
	end
	local v217 = v_u_2.LocalPlayer
	local v218 = string.format
	local v219 = p209.folder.Name
	local v220 = tostring(v219)
	local v221 = v216.phase
	local v222 = v216.s
	local v223 = v216.x
	local v224 = v216.y
	local v225 = v216.z
	local v226 = v216.crate.mode
	local v227 = v216.crate.ext
	local v228 = v216.rope.on
	local v229 = tostring(v228)
	local v230 = p209.rig ~= nil
	local v231 = tostring(v230)
	local v232 = v216.wash
	local v233 = p209.a.owner == (not v217 and 0 or v217.UserId)
	return v218("lift %s phase=%s s=%.0f pos=(%.0f,%.0f,%.0f) crate=%s ext=%.2f rope=%s rig=%s wash=%.2f owner=%s", v220, v221, v222, v223, v224, v225, v226, v227, v229, v231, v232, (tostring(v233)))
end
return v_u_3