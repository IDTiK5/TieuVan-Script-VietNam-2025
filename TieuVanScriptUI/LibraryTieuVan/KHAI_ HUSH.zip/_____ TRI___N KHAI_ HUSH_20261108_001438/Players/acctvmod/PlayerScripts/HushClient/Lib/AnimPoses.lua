-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimPoses

local v_u_1 = {}
local v_u_2 = math.rad
local function v_u_10(p3, p4, p5, p6, p7, p8, p9) -- name: G
	-- upvalues: (copy) v_u_2
	return CFrame.new(p3 + Vector3.new(p4, p5, p6)) * CFrame.Angles(0, v_u_2(p7), 0) * CFrame.Angles(v_u_2(p8), 0, (v_u_2(p9 or 0)))
end
local v_u_11 = {
	["rifle"] = {
		["aim"] = {
			-0.55,
			-0.42,
			-1.05,
			0,
			0,
			0
		},
		["ready"] = {
			-0.62,
			-0.95,
			-0.85,
			22,
			-30,
			-8
		},
		["sprint"] = {
			-0.78,
			-0.82,
			-0.62,
			52,
			-28,
			-22
		},
		["sneak"] = {
			-0.56,
			-0.68,
			-0.98,
			2,
			-3,
			-3
		}
	},
	["shotgun"] = {
		["aim"] = {
			-0.55,
			-0.42,
			-1.12,
			0,
			0,
			0
		},
		["ready"] = {
			-0.62,
			-0.95,
			-0.9,
			22,
			-30,
			-8
		},
		["sprint"] = {
			-0.78,
			-0.82,
			-0.62,
			52,
			-28,
			-22
		},
		["sneak"] = {
			-0.56,
			-0.68,
			-1.04,
			2,
			-3,
			-3
		}
	},
	["pistol"] = {
		["aim"] = {
			-0.88,
			-0.3,
			-1.85,
			0,
			0,
			0
		},
		["ready"] = {
			-0.8,
			-0.9,
			-1.28,
			4,
			-28,
			0
		},
		["sprint"] = {
			-0.55,
			-1.05,
			-0.62,
			10,
			-62,
			0
		},
		["sneak"] = {
			-0.82,
			-0.62,
			-1.4,
			0,
			-4,
			0
		}
	},
	["melee1h"] = {
		["aim"] = {
			-0.3,
			-0.62,
			-0.95,
			8,
			58,
			0
		},
		["ready"] = {
			-0.12,
			-1.48,
			-0.5,
			-8,
			38,
			0
		},
		["sprint"] = {
			-0.1,
			-1.3,
			-0.35,
			-10,
			62,
			0
		}
	},
	["melee2h"] = {
		["aim"] = {
			-0.45,
			-0.5,
			-0.7,
			22,
			68,
			0
		},
		["ready"] = {
			-0.55,
			-1.2,
			-0.58,
			32,
			48,
			0
		},
		["sprint"] = {
			-0.6,
			-1,
			-0.4,
			40,
			70,
			0
		}
	}
}
local v_u_12 = {
	["melee1h"] = table.clone(v_u_11.melee1h),
	["melee2h"] = table.clone(v_u_11.melee2h)
}
v_u_1.legacyMelee = false
v_u_11.melee2h = table.clone(v_u_11.melee2h)
v_u_11.melee2h.ready = {
	-0.45,
	-1.22,
	-0.68,
	16,
	64,
	0
}
local v_u_13 = {
	["rifle"] = CFrame.new(0, 0.12, -1.22),
	["shotgun"] = CFrame.new(0, 0.1, -1.3),
	["pistol"] = CFrame.new(-0.2, -0.06, 0.1),
	["melee2h"] = CFrame.new(0, 0, 0.55)
}
local v_u_14 = {
	["rifle"] = CFrame.Angles(0, 0, -1.2217304763960306),
	["shotgun"] = CFrame.Angles(0, 0, -1.2217304763960306),
	["pistol"] = CFrame.Angles(0, 0, 0.20943951023931956),
	["melee2h"] = CFrame.Angles(0, 0, 0)
}
function v_u_1.grip(p15, p16, p17) -- name: grip
	-- upvalues: (copy) v_u_1, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10
	local v18 = v_u_1.legacyMelee and v_u_12[p15] or (v_u_11[p15] or v_u_11.pistol)
	local v19 = v18[p16] or v18.ready
	return v_u_10(p17, v19[1], v19[2], v19[3], v19[4], v19[5], v19[6])
end
function v_u_1.setPose(p20, p21, p22) -- name: setPose
	-- upvalues: (copy) v_u_11
	local v23 = v_u_11[p20]
	if not v23 or #p22 < 6 then
		return nil
	end
	local v24 = v23[p21]
	v23[p21] = {
		p22[1],
		p22[2],
		p22[3],
		p22[4],
		p22[5],
		p22[6]
	}
	return v24
end
function v_u_1.hasPose(p25, p26) -- name: hasPose
	-- upvalues: (copy) v_u_11
	local v27 = v_u_11[p25]
	local v28
	if v27 == nil then
		v28 = false
	else
		v28 = v27[p26] ~= nil
	end
	return v28
end
function v_u_1.support(p29) -- name: support
	-- upvalues: (copy) v_u_13
	return v_u_13[p29]
end
function v_u_1.leftRoll(p30) -- name: leftRoll
	-- upvalues: (copy) v_u_14
	return v_u_14[p30] or CFrame.identity
end
function v_u_1.twoHanded(p31, p32) -- name: twoHanded
	if p31 == "rifle" or (p31 == "shotgun" or p31 == "melee2h") then
		return true
	elseif p31 == "pistol" then
		return p32 ~= "sprint"
	else
		return false
	end
end
function v_u_1.swing(p33, p34, p35, p36) -- name: swing
	-- upvalues: (copy) v_u_1
	local v37 = p33 == "melee2h"
	local v38 = v_u_1.grip(p33, "ready", p36)
	local v39
	if v37 then
		v39 = CFrame.new(p36 + Vector3.new(0, 0.55, 0.55)) * CFrame.Angles(0, -1.3962634015954636, 0) * CFrame.Angles(1.2566370614359172, 0, -2.6179938779914944)
	else
		v39 = CFrame.new(p36 + Vector3.new(0.15, 0.45, 0.25)) * CFrame.Angles(0, -0.8726646259971648, 0) * CFrame.Angles(1.6580627893946132, 0, -2.007128639793479)
	end
	local v40
	if v37 then
		v40 = CFrame.new(p36 + Vector3.new(-1.75, -0.7, -1)) * CFrame.Angles(0, 1.7453292519943295, 0) * CFrame.Angles(0.03490658503988659, 0, 0)
	else
		v40 = CFrame.new(p36 + Vector3.new(-1.35, -0.95, -1.15)) * CFrame.Angles(0, 1.3089969389957472, 0) * CFrame.Angles(-0.08726646259971647, 0, 0)
	end
	local v41 = math.clamp(p35, 0.12, 0.5)
	local v42 = v41 + 0.2
	local v43 = math.min(0.92, v42)
	if p34 < v41 then
		local v44 = p34 / v41
		local v45 = math.clamp(v44, 0, 1)
		local v46 = v45 * v45 * (3 - v45 * 2)
		return v38:Lerp(v39, v46), v46 * -0.42
	elseif p34 < v43 then
		local v47 = (p34 - v41) / (v43 - v41)
		local v48 = math.clamp(v47, 0, 1)
		local v49 = v48 * v48
		return v39:Lerp(v40, v49), v49 * 0.95 + -0.42
	else
		local v50 = (p34 - v43) / (1 - v43)
		local v51 = math.clamp(v50, 0, 1)
		local v52 = v51 * v51 * (3 - v51 * 2)
		return v40:Lerp(v38, v52), (1 - v52) * 0.53
	end
end
v_u_1.STRIKE_DUR = 0.5
local function v_u_65(p53, p54, p55, p56) -- name: track
	local v57 = math.clamp(p53, 0, 1)
	local v58, v59
	if v57 < 0.26 then
		local v60 = v57 / 0.26
		local v61 = math.clamp(v60, 0, 1)
		v58 = v61 * v61 * (3 - v61 * 2)
		v59 = 1
	elseif v57 < 0.44 then
		local v62 = (v57 - 0.26) / 0.18
		v58 = v62 * v62
		v59 = 2
	elseif v57 < 0.54 then
		v59 = 3
		v58 = 1
	else
		local v63 = (v57 - 0.54) / 0.45999999999999996
		local v64 = math.clamp(v63, 0, 1)
		v58 = v64 * v64 * (3 - v64 * 2)
		v59 = 4
	end
	if v59 == 1 then
		return p54:Lerp(p55, v58)
	elseif v59 == 2 then
		return p55:Lerp(p56, v58)
	elseif v59 == 3 then
		return p56
	else
		return p56:Lerp(p54, v58)
	end
end
function v_u_1.bash(p66, _, p67, p68) -- name: bash
	-- upvalues: (copy) v_u_65
	if p68 == "pistol" then
		local v69 = v_u_65(p66, p67, p67 * CFrame.new(0.05, 0.45, 0.3) * CFrame.Angles(1.0122909661567112, -0.13962634015954636, -0.20943951023931956), p67 * CFrame.new(-0.2, -0.3, -0.8) * CFrame.Angles(-0.8377580409572782, 0.3141592653589793, 0.20943951023931956))
		local v70 = math.clamp(p66, 0, 1)
		local v71, v72
		if v70 < 0.26 then
			local v73 = v70 / 0.26
			local v74 = math.clamp(v73, 0, 1)
			v71 = v74 * v74 * (3 - v74 * 2)
			v72 = 1
		elseif v70 < 0.44 then
			local v75 = (v70 - 0.26) / 0.18
			v71 = v75 * v75
			v72 = 2
		elseif v70 < 0.54 then
			v72 = 3
			v71 = 1
		else
			local v76 = (v70 - 0.54) / 0.45999999999999996
			local v77 = math.clamp(v76, 0, 1)
			v71 = v77 * v77 * (3 - v77 * 2)
			v72 = 4
		end
		if v72 == 1 then
			return v69, -0.18 * v71
		elseif v72 == 2 then
			return v69, -0.18 + 0.44 * v71
		elseif v72 == 3 then
			return v69, 0.26
		else
			return v69, 0.26 * (1 - v71)
		end
	else
		local v78 = v_u_65(p66, p67, p67 * CFrame.new(0.12, 0.08, 0.4) * CFrame.Angles(0.13962634015954636, -0.4886921905584123, 0.10471975511965978), p67 * CFrame.new(-0.3, 0.18, -0.95) * CFrame.Angles(-0.10471975511965978, 1.1519173063162575, -0.20943951023931956))
		local v79 = math.clamp(p66, 0, 1)
		local v80, v81
		if v79 < 0.26 then
			local v82 = v79 / 0.26
			local v83 = math.clamp(v82, 0, 1)
			v80 = v83 * v83 * (3 - v83 * 2)
			v81 = 1
		elseif v79 < 0.44 then
			local v84 = (v79 - 0.26) / 0.18
			v80 = v84 * v84
			v81 = 2
		elseif v79 < 0.54 then
			v81 = 3
			v80 = 1
		else
			local v85 = (v79 - 0.54) / 0.45999999999999996
			local v86 = math.clamp(v85, 0, 1)
			v80 = v86 * v86 * (3 - v86 * 2)
			v81 = 4
		end
		if v81 == 1 then
			return v78, -0.26 * v80
		elseif v81 == 2 then
			return v78, -0.26 + 0.6799999999999999 * v80
		elseif v81 == 3 then
			return v78, 0.42
		else
			return v78, 0.42 * (1 - v80)
		end
	end
end
function v_u_1.guard(p87, p88, p89) -- name: guard
	local v90 = -p88 * 0.62 * p89
	local v91 = p89 * 0.05
	local v92 = p89 * -0.72
	return p87 + Vector3.new(v90, v91, v92)
end
function v_u_1.punch(p93, p94, p95, p96, p97, p98) -- name: punch
	-- upvalues: (copy) v_u_1
	local v99 = v_u_1.guard(p94, p98, p97)
	local v100 = -p98 * 0.5 * p97
	local v101 = p97 * -0.55
	local v102 = p97 * -0.38
	local v103 = p94 + Vector3.new(v100, v101, v102)
	local v104 = -p98 * 0.3
	local v105 = p94 + Vector3.new(v104, 0.05, -1).Unit * p96 * 0.94
	local v106 = math.clamp(p93, 0, 1)
	local v107, v108
	if v106 < 0.26 then
		local v109 = v106 / 0.26
		local v110 = math.clamp(v109, 0, 1)
		v107 = v110 * v110 * (3 - v110 * 2)
		v108 = 1
	elseif v106 < 0.44 then
		local v111 = (v106 - 0.26) / 0.18
		v107 = v111 * v111
		v108 = 2
	elseif v106 < 0.54 then
		v108 = 3
		v107 = 1
	else
		local v112 = (v106 - 0.54) / 0.45999999999999996
		local v113 = math.clamp(v112, 0, 1)
		v107 = v113 * v113 * (3 - v113 * 2)
		v108 = 4
	end
	if v108 == 1 then
		v105 = v99:Lerp(v103, v107)
	elseif v108 == 2 then
		v105 = v103:Lerp(v105, v107)
	elseif v108 ~= 3 then
		v105 = v105:Lerp(v99, v107)
	end
	if v108 ~= 2 then
		v107 = v108 == 3 and 1 or (v108 ~= 4 and 0 or 1 - v107)
	end
	local v114 = v_u_1.guard(p95, -p98, p97)
	local v115 = p97 * 0.04 * v107
	local v116 = p97 * 0.16 * v107
	local v117 = v114 + Vector3.new(0, v115, v116)
	local v118 = p98 > 0 and 0.42 or 0.24
	local v119 = -v118 * 0.55
	local v120 = math.clamp(p93, 0, 1)
	local v121, v122
	if v120 < 0.26 then
		local v123 = v120 / 0.26
		local v124 = math.clamp(v123, 0, 1)
		v121 = v124 * v124 * (3 - v124 * 2)
		v122 = 1
	elseif v120 < 0.44 then
		local v125 = (v120 - 0.26) / 0.18
		v121 = v125 * v125
		v122 = 2
	elseif v120 < 0.54 then
		v122 = 3
		v121 = 1
	else
		local v126 = (v120 - 0.54) / 0.45999999999999996
		local v127 = math.clamp(v126, 0, 1)
		v121 = v127 * v127 * (3 - v127 * 2)
		v122 = 4
	end
	if v122 == 1 then
		v118 = v119 * v121
	elseif v122 == 2 then
		v118 = v119 + (v118 - v119) * v121
	elseif v122 ~= 3 then
		v118 = v118 * (1 - v121)
	end
	return v105, v117, p98 * v118
end
function v_u_1.doorHands(p128, p129, p130, p131, p132, p133) -- name: doorHands
	if p128 ~= "Unlock" then
		local v134 = p132 / 1
		local v135 = math.clamp(v134, 0, 1)
		local v136 = v135 * v135 * (3 - v135 * 2)
		local v137 = -(0.95 - v136 * 0.85) * p131
		local v138 = p130.Y - (v136 * 0.25 + 1.2) * p131
		local v139 = {}
		local v140 = p131 * 0.42
		local v141 = p129 * Vector3.new(v140, v138, v137)
		local v142 = p131 * -0.42
		__set_list(v139, 1, {v141, p129 * Vector3.new(v142, v138, v137)})
		return v139
	end
	local v143 = p132 / 0.25
	local v144 = math.clamp(v143, 0, 1)
	local v145 = v144 * v144 * (3 - v144 * 2)
	local v146 = p132 * 16
	local v147 = math.sin(v146) * 0.015 * p131 * v145
	local v148 = p131 * 0.12
	local v149 = p130.Y - p131 * 0.85 + v147
	local v150 = -(v145 * 0.75 + 0.6) * p131
	local v151 = Vector3.new(v148, v149, v150)
	local v152 = p131 * -0.08
	local v153 = p130.Y - p131 * 0.85 + v147
	local v154 = -(v145 * 0.75 + 0.6) * p131
	local v155 = Vector3.new(v152, v153, v154)
	if p133 then
		return { p129 * v151, p129 * v155 }
	end
	local v156 = {}
	local v157 = p129 * v151
	local v158 = p131 * -0.38
	local v159 = p130.Y - p131 * 1.55
	local v160 = p131 * -0.25
	__set_list(v156, 1, {v157, p129 * Vector3.new(v158, v159, v160)})
	return v156
end
function v_u_1.keyTurn(p161) -- name: keyTurn
	local v162 = (p161 - 0.3) / 0.4
	local v163 = math.clamp(v162, 0, 1)
	return v163 * v163 * (3 - v163 * 2) * 1.5707963267948966
end
return v_u_1