-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTreeLayout

local v_u_6 = {
	["NODE_H"] = 56,
	["TILE_MIN_W"] = 250,
	["TILE_MIN_H"] = 96,
	["TOUCH"] = 44,
	["GAP"] = 8,
	["SCROLL"] = 8,
	["TIER_H"] = 26,
	["NODE_MIN_W"] = 200,
	["COLS3_AT"] = 844,
	["COLS2_AT"] = 740,
	["HOLD_SEC"] = 0.6,
	["SHEET_ROW_H"] = 30,
	["BACK_W"] = 96,
	["CARD_BTN_W"] = 170,
	["BAR_H"] = 38,
	["BAR_H_ONE"] = 30,
	["COMPACT_H"] = 420,
	["LEGEND_BTN_W"] = 96,
	["MIN_NODES_VISIBLE"] = 2,
	["NOTE_H"] = 20,
	["WHY_H"] = 36,
	["HELP_W_LONG"] = 176,
	["HELP_W_SHORT"] = 92,
	["HELP_LONG_AT"] = 520,
	["NARROW_AT"] = 480,
	["HINT_SIZE"] = 13,
	["HINT_REAL_MIN"] = 11,
	["EM"] = 0.6,
	["CHIP_WEIGHTS"] = {
		1,
		1,
		1.7,
		1.1
	},
	["LEGEND_H"] = 28,
	["TILE_IDS"] = {
		"gun",
		"grit",
		"ghost",
		"life",
		"kit",
		"flaws"
	},
	["newHold"] = function(p1) -- name: newHold
		return {
			["t0"] = nil,
			["fired"] = false,
			["ended"] = false,
			["t0"] = p1
		}
	end,
	["holdStep"] = function(p2, p3, p4) -- name: holdStep
		-- upvalues: (copy) v_u_6
		if p2.fired then
			return false, 1
		end
		if p2.ended then
			return false, 0
		end
		if p4 == true then
			p2.ended = true
			return false, 0
		end
		local v5 = (p3 - p2.t0) / v_u_6.HOLD_SEC
		if v5 < 0.999999999 then
			return false, math.max(0, v5)
		end
		p2.fired = true
		return true, 1
	end
}
local v_u_7 = v_u_6.GAP
function v_u_6.rect(p8, p9, p10, p11) -- name: R
	local v12 = {
		["x"] = math.floor(p8),
		["y"] = math.floor(p9)
	}
	local v13 = math.floor(p10)
	v12.w = math.max(0, v13)
	local v14 = math.floor(p11)
	v12.h = math.max(0, v14)
	return v12
end
function v_u_6.touchH(p15, p16) -- name: touchH
	-- upvalues: (copy) v_u_6
	if type(p16) ~= "table" or p16.touch ~= true then
		return p15
	end
	local v17 = p16.scale
	local v18 = (type(v17) ~= "number" or p16.scale <= 0) and 1 or p16.scale
	local v19 = v_u_6.TOUCH / v18
	local v20 = math.ceil(v19)
	return math.max(p15, v20)
end
function v_u_6.hintSize(p21) -- name: hintSize
	-- upvalues: (copy) v_u_6
	local v22 = (type(p21) ~= "number" or p21 <= 0) and 1 or p21
	local v23 = v_u_6.HINT_SIZE
	local v24 = v_u_6.HINT_REAL_MIN / v22
	local v25 = math.ceil(v24)
	return math.max(v23, v25)
end
function v_u_6.wrapLines(p26, p27, p28) -- name: wrapLines
	-- upvalues: (copy) v_u_6
	local v29 = p26 * p27 * v_u_6.EM / math.max(20, p28)
	local v30 = math.ceil(v29)
	return math.max(1, v30)
end
function v_u_6.lineH(p31) -- name: lineH
	local v32 = p31 * 1.3
	return math.ceil(v32)
end
function v_u_6.nodeCols(p33, p34) -- name: nodeCols
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v35
	if v_u_6.COLS3_AT <= p33 then
		v35 = 3
	elseif v_u_6.COLS2_AT <= p33 then
		v35 = 2
	else
		v35 = 1
	end
	while v35 > 1 and (p34 - (v35 - 1) * v_u_7) / v35 < v_u_6.NODE_MIN_W do
		v35 = v35 - 1
	end
	return v35
end
function v_u_6.ladder(p36, p37, p38, p39) -- name: ladder
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v40 = math.floor(p38)
	local v41 = math.max(1, v40)
	local v42 = (p36 - (v41 - 1) * v_u_7) / v41
	local v43 = math.floor(v42)
	local v44 = tonumber(p39) or 0
	local v45 = math.floor(v44)
	local v46 = math.max(0, v45)
	local v47 = {}
	for v48, v49 in p37 do
		local v50 = v_u_6.TIER_H
		local v51 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v46)
		}
		local v52 = math.floor(p36)
		v51.w = math.max(0, v52)
		local v53 = math.floor(v50)
		v51.h = math.max(0, v53)
		local v54 = v46 + (v_u_6.TIER_H + 4)
		local v55 = {}
		for v56 = 1, v49 do
			local v57 = (v56 - 1) % v41
			local v58 = (v56 - 1) / v41
			local v59 = math.floor(v58)
			local v60 = v57 * (v43 + v_u_7)
			local v61 = v54 + v59 * (v_u_6.NODE_H + v_u_7)
			local v62 = v_u_6.NODE_H
			local v63 = {
				["x"] = math.floor(v60),
				["y"] = math.floor(v61)
			}
			local v64 = math.floor(v43)
			v63.w = math.max(0, v64)
			local v65 = math.floor(v62)
			v63.h = math.max(0, v65)
			table.insert(v55, v63)
		end
		local v66 = v49 / v41
		local v67 = math.ceil(v66)
		local v68 = v_u_6.TIER_H + 4 + (v67 <= 0 and 0 or v67 * (v_u_6.NODE_H + v_u_7) - v_u_7)
		local v69 = {
			["tier"] = v48,
			["y"] = v51.y,
			["h"] = v68,
			["head"] = v51,
			["nodes"] = v55
		}
		table.insert(v47, v69)
		v46 = v54 + ((v67 <= 0 and 0 or v67 * (v_u_6.NODE_H + v_u_7) - v_u_7) + 10)
	end
	local v70 = {
		["tiers"] = v47
	}
	local v71 = v46 - 10
	v70.height = math.max(0, v71)
	v70.nodeW = v43
	v70.cols = v41
	local v72 = tonumber(p39) or 0
	local v73 = math.floor(v72)
	v70.top = math.max(0, v73)
	return v70
end
function v_u_6.chipValue(p74, p75, p76, p77) -- name: chipValue
	-- upvalues: (copy) v_u_6
	local v78 = p74.short or p74.value
	local v79 = tostring(v78)
	local v80 = p74.value
	local v81 = tostring(v80)
	if p75 then
		return v79
	else
		local v82 = 11 / math.max(0.5, p77 or 1)
		local v83 = math.ceil(v82)
		local v84 = utf8.len(v81) or #v81
		if p76 < v84 * v83 * v_u_6.EM and (utf8.len(v79) or #v79) < v84 then
			return v79
		else
			return v81
		end
	end
end
function v_u_6.barChips(p85, p86) -- name: barChips
	-- upvalues: (copy) v_u_6
	local v87 = p86 or v_u_6.BAR_H
	local v88 = 0
	for _, v89 in v_u_6.CHIP_WEIGHTS do
		v88 = v88 + v89
	end
	local v90 = p85 - (#v_u_6.CHIP_WEIGHTS - 1) * 4
	local v91 = 0
	local v92 = 0
	local v93 = {}
	for v94, v95 in v_u_6.CHIP_WEIGHTS do
		v91 = v91 + v95
		local v96
		if v94 == #v_u_6.CHIP_WEIGHTS then
			v96 = p85
		else
			local v97 = v90 * v91 / v88
			v96 = math.floor(v97) + 4 * (v94 - 1)
		end
		local v98 = v96 - v92
		local v99 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v92)
		}
		local v100 = math.floor(v98)
		v99.w = math.max(0, v100)
		local v101 = math.floor(v87)
		v99.h = math.max(0, v101)
		table.insert(v93, v99)
		v92 = v96 + 4
	end
	return v93
end
function v_u_6.tierHeadInner(p102) -- name: tierHeadInner
	-- upvalues: (copy) v_u_6
	local v103 = p102 >= 320 and 64 or 0
	local v104 = p102 - 38 - (v103 <= 0 and 0 or v103 + 16)
	local v105 = {
		["icon"] = {
			["x"] = 8,
			["y"] = 6,
			["w"] = 14,
			["h"] = 14
		}
	}
	local v106 = v_u_6.TIER_H
	local v107 = {
		["x"] = 30,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v108 = math.floor(v104)
	v107.w = math.max(0, v108)
	local v109 = math.floor(v106)
	v107.h = math.max(0, v109)
	v105.text = v107
	local v110
	if v103 > 0 then
		local v111 = p102 - 8 - v103
		v110 = {
			["x"] = nil,
			["y"] = 10,
			["w"] = nil,
			["h"] = 6,
			["x"] = math.floor(v111)
		}
		local v112 = math.floor(v103)
		v110.w = math.max(0, v112)
	else
		v110 = nil
	end
	v105.bar = v110
	return v105
end
v_u_6.FLAW_EFFECT_CHARS = 80
v_u_6.FLAW_DESC_CHARS = 110
v_u_6.FLAW_META_CHARS = 100
function v_u_6.flawCards(p113, p114, p115) -- name: flawCards
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v116 = p113 >= 700 and 2 or 1
	local v117 = v_u_6.touchH(v_u_6.TOUCH, p115)
	local v118 = (p113 - (v116 - 1) * v_u_7) / v116
	local v119 = math.floor(v118)
	local v120 = v119 < 520
	local v121
	if v120 then
		v121 = v119 - 20
	else
		v121 = v119 - 10 - v_u_6.CARD_BTN_W - 8 - 10
	end
	local v122 = v_u_6.hintSize
	local v123
	if type(p115) == "table" then
		v123 = p115.scale
	else
		v123 = nil
	end
	local v124 = v122(v123)
	local v125 = v_u_6.lineH(v124)
	local v126 = math.max(60, v121)
	local v127 = v125 * v_u_6.wrapLines(v_u_6.FLAW_EFFECT_CHARS, v124, v126)
	local v128 = v125 * v_u_6.wrapLines(v_u_6.FLAW_DESC_CHARS, v124, v126)
	local v129 = v125 * v_u_6.wrapLines(v_u_6.FLAW_META_CHARS, v124, v126 - 16)
	local v130 = 22 + v127 + v128 + v125 + v129
	local v131
	if v120 then
		v131 = 6 + v130 + 6 + v117 + 8
	else
		local v132 = 6 + v130 + 8
		local v133 = v117 + 16
		v131 = math.max(v132, v133)
	end
	local v134 = {}
	for v135 = 1, p114 do
		local v136 = (v135 - 1) % v116
		local v137 = (v135 - 1) / v116
		local v138 = math.floor(v137)
		local v139 = v136 * (v119 + v_u_7)
		local v140 = v138 * (v131 + v_u_7)
		local v141 = {
			["x"] = math.floor(v139),
			["y"] = math.floor(v140)
		}
		local v142 = math.floor(v119)
		v141.w = math.max(0, v142)
		local v143 = math.floor(v131)
		v141.h = math.max(0, v143)
		table.insert(v134, v141)
	end
	local v144 = p114 / v116
	local v145 = math.ceil(v144)
	local v146
	if v120 then
		local v147 = v131 - 8 - v117
		local v148 = v119 - 20
		v146 = {
			["x"] = 10,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v147)
		}
		local v149 = math.floor(v148)
		v146.w = math.max(0, v149)
		local v150 = math.floor(v117)
		v146.h = math.max(0, v150)
	else
		local v151 = v119 - 8 - v_u_6.CARD_BTN_W
		local v152 = (v131 - v117) / 2
		local v153 = v_u_6.CARD_BTN_W
		v146 = {
			["x"] = math.floor(v151),
			["y"] = math.floor(v152)
		}
		local v154 = math.floor(v153)
		v146.w = math.max(0, v154)
		local v155 = math.floor(v117)
		v146.h = math.max(0, v155)
	end
	local v156 = {
		["x"] = 10,
		["y"] = 6,
		["w"] = nil,
		["h"] = nil
	}
	local v157 = math.floor(v121)
	v156.w = math.max(0, v157)
	local v158 = math.floor(v130)
	v156.h = math.max(0, v158)
	local v159 = {
		["rects"] = v134,
		["cols"] = v116,
		["cardW"] = v119,
		["cardH"] = v131,
		["stacked"] = v120,
		["size"] = v124,
		["lineH"] = v125,
		["height"] = v145 <= 0 and 0 or v145 * (v131 + v_u_7) - v_u_7,
		["text"] = v156
	}
	local v160 = v156.x
	local v161 = v156.y
	local v162 = {
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 22,
		["x"] = math.floor(v160),
		["y"] = math.floor(v161)
	}
	local v163 = math.floor(v121)
	v162.w = math.max(0, v163)
	v159.name = v162
	local v164 = v156.x
	local v165 = v156.y + 22
	local v166 = {
		["x"] = math.floor(v164),
		["y"] = math.floor(v165)
	}
	local v167 = math.floor(v121)
	v166.w = math.max(0, v167)
	local v168 = math.floor(v127)
	v166.h = math.max(0, v168)
	v159.effect = v166
	local v169 = v156.x
	local v170 = v156.y + 22 + v127
	local v171 = {
		["x"] = math.floor(v169),
		["y"] = math.floor(v170)
	}
	local v172 = math.floor(v121)
	v171.w = math.max(0, v172)
	local v173 = math.floor(v128)
	v171.h = math.max(0, v173)
	v159.desc = v171
	local v174 = v156.x
	local v175 = v156.y + 22 + v127 + v128
	local v176 = {
		["x"] = math.floor(v174),
		["y"] = math.floor(v175)
	}
	local v177 = math.floor(v121)
	v176.w = math.max(0, v177)
	local v178 = math.floor(v125)
	v176.h = math.max(0, v178)
	v159.meta1 = v176
	local v179 = v156.x
	local v180 = v156.y + 22 + v127 + v128 + v125
	local v181 = {
		["x"] = math.floor(v179),
		["y"] = math.floor(v180)
	}
	local v182 = math.floor(v121)
	v181.w = math.max(0, v182)
	local v183 = math.floor(v129)
	v181.h = math.max(0, v183)
	v159.meta2 = v181
	v159.btn = v146
	local v184 = v146.x
	local v185 = v146.y + v146.h - 4
	local v186 = v146.w
	local v187 = {
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 4,
		["x"] = math.floor(v184),
		["y"] = math.floor(v185)
	}
	local v188 = math.floor(v186)
	v187.w = math.max(0, v188)
	v159.bar = v187
	return v159
end
v_u_6.TILE_ICONS = {
	["gun"] = {
		["asset"] = "rbxassetid://131485409364474",
		["source"] = "Hush/art/r47_perk_icons/src/guncraft.png"
	},
	["grit"] = {
		["asset"] = "rbxassetid://120151509024038",
		["source"] = "Hush/art/r47_perk_icons/src/grit.webp"
	},
	["ghost"] = {
		["asset"] = "rbxassetid://95957451512384",
		["source"] = "Hush/art/r47_perk_icons/src/ghost.png"
	},
	["life"] = {
		["asset"] = "rbxassetid://130831485570525",
		["source"] = "Hush/art/r47_perk_icons/src/lifeline.webp"
	},
	["kit"] = {
		["asset"] = "rbxassetid://87846490698441",
		["source"] = "Hush/art/r47_perk_icons/src/kit.webp"
	},
	["flaws"] = {
		["asset"] = "rbxassetid://72250253461682",
		["source"] = "Hush/art/r47_perk_icons/src/flaws.png"
	}
}
v_u_6.ICON_FRAC = 0.6
v_u_6.ICON_MIN_REAL = 36
v_u_6.ICON_GAP = 8
v_u_6.TILE_TEXT_SIZE = 13
v_u_6.TILE_TEXT_EM = 0.6
v_u_6.TILE_FIT_MARGIN = 2
local v_u_189 = nil
function v_u_6.longestTileLine() -- name: longestTileLine
	-- upvalues: (ref) v_u_189, (copy) v_u_6
	if v_u_189 then
		return v_u_189
	end
	local v190 = 0
	local v191 = v190
	for _, v192 in { 0, 9, 99 } do
		for _, v193 in {
			0,
			1,
			16,
			999
		} do
			local v194, v195 = v_u_6.tileText({
				["spent"] = nil,
				["openTier"] = 5,
				["learnable"] = nil,
				["spent"] = v193,
				["learnable"] = v192
			}, {
				["canChange"] = true
			})
			local v196 = 0
			for v197 = 1, #v194 do
				local v198 = string.byte(v194, v197)
				if v198 >= 128 and v198 < 192 then
					continue
				end
				v196 = v196 + 1
			end
			local v199 = 0
			for v200 = 1, #v195 do
				local v201 = string.byte(v195, v200)
				if v201 >= 128 and v201 < 192 then
					continue
				end
				v199 = v199 + 1
			end
			v190 = math.max(v191, v196, v199)
			v191 = v190
		end
	end
	for v202 = 0, 3 do
		for v203 = 0, 3 do
			local v204 = {
				["flawSlots"] = {
					["used"] = nil,
					["max"] = nil,
					["total"] = 3,
					["at"] = nil,
					["used"] = v203,
					["max"] = v202,
					["at"] = { 5, 15, 25 }
				}
			}
			local v205, v206 = v_u_6.flawTileText(v204)
			local v207 = 0
			for v208 = 1, #v205 do
				local v209 = string.byte(v205, v208)
				if v209 >= 128 and v209 < 192 then
					continue
				end
				v207 = v207 + 1
			end
			local v210 = 0
			for v211 = 1, #v206 do
				local v212 = string.byte(v206, v211)
				if v212 >= 128 and v212 < 192 then
					continue
				end
				v210 = v210 + 1
			end
			v190 = math.max(v191, v207, v210)
			v191 = v190
		end
	end
	v_u_189 = v191
	return v191
end
function v_u_6.iconTextNeed(p213) -- name: iconTextNeed
	-- upvalues: (copy) v_u_6
	local v214 = (type(p213) ~= "number" or p213 <= 0) and 1 or p213
	local v215 = v_u_6.TILE_TEXT_SIZE
	local v216 = 11 / math.max(0.5, v214)
	local v217 = math.ceil(v216)
	local v218 = math.min(v215, v217)
	local v219 = v_u_6.longestTileLine() * v218 * v_u_6.TILE_TEXT_EM
	return math.ceil(v219) + v_u_6.TILE_FIT_MARGIN
end
function v_u_6.tileIconTone(p220, p221, p222) -- name: tileIconTone
	return p220 == "flaws" and "danger" or (p222 and p221 > 0 and "accent" or "muted")
end
function v_u_6.tileInner(p223, p224, p225) -- name: tileInner
	-- upvalues: (copy) v_u_6
	local v226 = (type(p225) ~= "number" or p225 <= 0) and 1 or p225
	local v227 = v_u_6.iconTextNeed(v226)
	local v228 = p224 * v_u_6.ICON_FRAC
	local v229 = math.floor(v228)
	local v230 = p223 - 24 - v_u_6.ICON_GAP - v227
	local v231 = math.floor(v230)
	local v232 = math.min(v229, v231)
	local v233 = p223 - 24 - v232 - v_u_6.ICON_GAP
	if v232 * v226 < v_u_6.ICON_MIN_REAL then
		local v234 = {
			["name"] = nil,
			["badge"] = nil,
			["line1"] = nil,
			["line2"] = nil,
			["bar"] = nil,
			["icon"] = nil
		}
		local v235 = p223 - 24 - 34
		local v236 = {
			["x"] = 12,
			["y"] = 8,
			["w"] = nil,
			["h"] = 24
		}
		local v237 = math.floor(v235)
		v236.w = math.max(0, v237)
		v234.name = v236
		local v238 = p223 - 12 - 28
		v234.badge = {
			["x"] = nil,
			["y"] = 8,
			["w"] = 28,
			["h"] = 28,
			["x"] = math.floor(v238)
		}
		local v239 = p223 - 24
		local v240 = {
			["x"] = 12,
			["y"] = 38,
			["w"] = nil,
			["h"] = 20
		}
		local v241 = math.floor(v239)
		v240.w = math.max(0, v241)
		v234.line1 = v240
		local v242 = p223 - 24
		local v243 = {
			["x"] = 12,
			["y"] = 58,
			["w"] = nil,
			["h"] = 18
		}
		local v244 = math.floor(v242)
		v243.w = math.max(0, v244)
		v234.line2 = v243
		local v245 = p224 - 14
		local v246 = p223 - 24
		local v247 = {
			["x"] = 12,
			["y"] = nil,
			["w"] = nil,
			["h"] = 4,
			["y"] = math.floor(v245)
		}
		local v248 = math.floor(v246)
		v247.w = math.max(0, v248)
		v234.bar = v247
		return v234
	end
	local v249 = p223 - 12 - v232
	local v250 = v249 - 8 - 28
	local v251 = {}
	local v252 = v250 - 8 - 12
	local v253 = {
		["x"] = 12,
		["y"] = 8,
		["w"] = nil,
		["h"] = 24
	}
	local v254 = math.floor(v252)
	v253.w = math.max(0, v254)
	v251.name = v253
	v251.badge = {
		["x"] = nil,
		["y"] = 8,
		["w"] = 28,
		["h"] = 28,
		["x"] = math.floor(v250)
	}
	local v255 = {
		["x"] = 12,
		["y"] = 38,
		["w"] = nil,
		["h"] = 20
	}
	local v256 = math.floor(v233)
	v255.w = math.max(0, v256)
	v251.line1 = v255
	local v257 = {
		["x"] = 12,
		["y"] = 58,
		["w"] = nil,
		["h"] = 18
	}
	local v258 = math.floor(v233)
	v257.w = math.max(0, v258)
	v251.line2 = v257
	local v259 = p224 - 14
	local v260 = p223 - 24
	local v261 = {
		["x"] = 12,
		["y"] = nil,
		["w"] = nil,
		["h"] = 4,
		["y"] = math.floor(v259)
	}
	local v262 = math.floor(v260)
	v261.w = math.max(0, v262)
	v251.bar = v261
	local v263 = (p224 - v232) / 2
	local v264 = math.floor(v263)
	local v265 = {
		["x"] = math.floor(v249),
		["y"] = math.floor(v264)
	}
	local v266 = math.floor(v232)
	v265.w = math.max(0, v266)
	local v267 = math.floor(v232)
	v265.h = math.max(0, v267)
	v251.icon = v265
	return v251
end
function v_u_6.nodeInner(p268) -- name: nodeInner
	local v269 = {
		["icon"] = {
			["x"] = 8,
			["y"] = 18,
			["w"] = 20,
			["h"] = 20
		}
	}
	local v270 = p268 - 36 - 8 - 18
	local v271 = {
		["x"] = 36,
		["y"] = 6,
		["w"] = nil,
		["h"] = 22
	}
	local v272 = math.floor(v270)
	v271.w = math.max(0, v272)
	v269.name = v271
	local v273 = p268 - 36 - 8
	local v274 = {
		["x"] = 36,
		["y"] = 30,
		["w"] = nil,
		["h"] = 20
	}
	local v275 = math.floor(v273)
	v274.w = math.max(0, v275)
	v269.line = v274
	local v276 = p268 - 8 - 14
	v269.lock = {
		["x"] = nil,
		["y"] = 8,
		["w"] = 14,
		["h"] = 14,
		["x"] = math.floor(v276)
	}
	return v269
end
function v_u_6.sheetRow(p277) -- name: sheetRow
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v278 = p277 * 0.42
	local v279 = math.floor(v278)
	local v280 = p277 * 0.18
	local v281 = math.floor(v280)
	local v282 = {}
	local v283 = v279 - 8
	local v284 = v_u_6.SHEET_ROW_H
	local v285 = {
		["x"] = 8,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v286 = math.floor(v283)
	v285.w = math.max(0, v286)
	local v287 = math.floor(v284)
	v285.h = math.max(0, v287)
	v282.label = v285
	local v288 = v_u_6.SHEET_ROW_H
	local v289 = {
		["x"] = nil,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["x"] = math.floor(v279)
	}
	local v290 = math.floor(v281)
	v289.w = math.max(0, v290)
	local v291 = math.floor(v288)
	v289.h = math.max(0, v291)
	v282.value = v289
	local v292 = v279 + v281 + v_u_7
	local v293 = p277 - v279 - v281 - v_u_7 - 8
	local v294 = v_u_6.SHEET_ROW_H
	local v295 = {
		["x"] = nil,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["x"] = math.floor(v292)
	}
	local v296 = math.floor(v293)
	v295.w = math.max(0, v296)
	local v297 = math.floor(v294)
	v295.h = math.max(0, v297)
	v282.source = v295
	return v282
end
v_u_6.WHY_CHARS = 96
v_u_6.WHY_CHARS_SIDE = 80
v_u_6.WHY_CHARS_COMPACT = 60
v_u_6.NOTE_CHARS = 72
v_u_6.FLAWNOTE_CHARS = 95
v_u_6.TEXT_CHARS = 96
function v_u_6.whyHeight(p298, p299, p300) -- name: whyHeight
	-- upvalues: (copy) v_u_6
	return v_u_6.wrapLines(p300 or v_u_6.WHY_CHARS, p299, p298) * v_u_6.lineH(p299) + 4
end
function v_u_6.compute(p301, p302, p303) -- name: compute
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v304 = type(p303) ~= "table" and {} or p303
	local v305 = v304.scale
	local v306 = (type(v305) ~= "number" or v304.scale <= 0) and 1 or v304.scale
	local v307 = v304.realW
	local v308
	if type(v307) == "number" then
		v308 = v304.realW
	else
		v308 = p301 * v306
	end
	local v309 = math.floor(p301)
	local v310 = math.max(0, v309)
	local v311 = math.floor(p302)
	local v312 = math.max(0, v311)
	local v313 = v_u_6.touchH(40, v304)
	local v314 = v_u_6.touchH(v_u_6.TOUCH, v304)
	local v315 = v310 * 0.2
	local v316 = math.floor(v315)
	local v317 = math.clamp(v316, 120, 170)
	local v318 = {
		["W"] = v310,
		["H"] = v312,
		["hh"] = v313,
		["btnH"] = v314
	}
	local v319
	if v304.bonus == true then
		v319 = v312 >= 300
	else
		v319 = false
	end
	local v320 = v304.legendH
	local v321
	if type(v320) == "number" then
		local v322 = v304.legendH
		v321 = math.floor(v322)
	else
		v321 = v_u_6.LEGEND_H
	end
	local v323 = v_u_6.hintSize(v306)
	local v324 = v_u_6.lineH(v323)
	local v325 = v310 < v_u_6.NARROW_AT
	local v326
	if v_u_6.HELP_LONG_AT <= v310 then
		v326 = v_u_6.HELP_W_LONG
	else
		v326 = v_u_6.HELP_W_SHORT
	end
	v318.narrow = v325
	v318.hintSize = v323
	v318.lineH = v324
	local v327 = v_u_6.wrapLines(v304.noteChars or v_u_6.NOTE_CHARS, v323, v310 - 22) * v324 + 4
	local v328
	if v325 then
		v328 = v313 * 2 + v_u_7
	else
		v328 = v313
	end
	local v329 = v312 < v_u_6.COMPACT_H
	local v330
	if v329 then
		v330 = v_u_6.BAR_H_ONE
	else
		v330 = v_u_6.BAR_H
	end
	local v331
	if v329 then
		v331 = not v325
	else
		v331 = v329
	end
	local v332
	if v329 then
		v332 = not v325
	else
		v332 = v329
	end
	v318.compact = v329
	v318.chipOne = v329
	v318.barH = v330
	v318.legendToggle = v331
	v318.sheetMode = v332
	local v333 = {}
	local v334 = v310 - v317
	local v335 = {
		["x"] = nil,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["x"] = math.floor(v334)
	}
	local v336 = math.floor(v317)
	v335.w = math.max(0, v336)
	local v337 = math.floor(v313)
	v335.h = math.max(0, v337)
	v333.sheetBtn = v335
	if v325 then
		local v338 = v310 - v317 - v_u_7
		local v339 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil
		}
		local v340 = math.floor(v338)
		v339.w = math.max(0, v340)
		local v341 = math.floor(v313)
		v339.h = math.max(0, v341)
		v333.level = v339
		local v342 = v313 + v_u_7
		local v343 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v342)
		}
		local v344 = math.floor(v310)
		v343.w = math.max(0, v344)
		local v345 = math.floor(v313)
		v343.h = math.max(0, v345)
		v333.help = v343
	else
		local v346 = v333.sheetBtn.x - v_u_7 - v326
		local v347 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v346)
		}
		local v348 = math.floor(v326)
		v347.w = math.max(0, v348)
		local v349 = math.floor(v313)
		v347.h = math.max(0, v349)
		v333.help = v347
		local v350 = v333.help.x - v_u_7
		local v351 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil
		}
		local v352 = math.floor(v350)
		v351.w = math.max(0, v352)
		local v353 = math.floor(v313)
		v351.h = math.max(0, v353)
		v333.level = v351
	end
	v333.helpShort = v333.help.w < v_u_6.HELP_W_LONG
	local v354 = v328 + 2
	local v355 = v354 + 5
	local v356 = v310 * 0.62
	local v357 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 8,
		["y"] = math.floor(v355)
	}
	local v358 = math.floor(v356)
	v357.w = math.max(0, v358)
	v333.bar = v357
	local v359 = v333.bar.w + v_u_7
	local v360 = v310 - v333.bar.w - v_u_7
	local v361 = {
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 18,
		["x"] = math.floor(v359),
		["y"] = math.floor(v354)
	}
	local v362 = math.floor(v360)
	v361.w = math.max(0, v362)
	v333.barText = v361
	local v363 = v354 + 18 + v_u_7
	local v364 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v363)
	}
	local v365 = math.floor(v310)
	v364.w = math.max(0, v365)
	local v366 = math.floor(v330)
	v364.h = math.max(0, v366)
	v333.pbar = v364
	v333.chips = v_u_6.barChips(v310, v330)
	local v367 = v363 + (v330 + 2)
	if v319 then
		local v368 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v367)
		}
		local v369 = math.floor(v310)
		v368.w = math.max(0, v369)
		local v370 = math.floor(v327)
		v368.h = math.max(0, v370)
		v333.note = v368
		v367 = v367 + (v327 + 2)
	end
	local v371 = v367 + (v_u_7 - 2)
	if v304.banner == true then
		local v372 = v314 + 20
		local v373 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v371)
		}
		local v374 = math.floor(v310)
		v373.w = math.max(0, v374)
		local v375 = math.floor(v372)
		v373.h = math.max(0, v375)
		v333.banner = v373
		local v376 = v310 - 12 - 90 - 12 - 12
		local v377 = v314 + 4
		local v378 = {
			["x"] = 12,
			["y"] = 8,
			["w"] = nil,
			["h"] = nil
		}
		local v379 = math.floor(v376)
		v378.w = math.max(0, v379)
		local v380 = math.floor(v377)
		v378.h = math.max(0, v380)
		v333.bannerText = v378
		local v381 = v310 - 90 - 12
		local v382 = {
			["x"] = nil,
			["y"] = 10,
			["w"] = 90,
			["h"] = nil,
			["x"] = math.floor(v381)
		}
		local v383 = math.floor(v314)
		v382.h = math.max(0, v383)
		v333.bannerOk = v382
		v371 = v371 + (v333.banner.h + v_u_7)
	end
	local v384 = v312 - v371
	local v385 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v371)
	}
	local v386 = math.floor(v310)
	v385.w = math.max(0, v386)
	local v387 = math.floor(v384)
	v385.h = math.max(0, v387)
	v333.viewport = v385
	local v388 = v310 - v_u_6.SCROLL
	local v389 = (v388 + v_u_7) / (v_u_6.TILE_MIN_W + v_u_7)
	local v390 = math.floor(v389)
	local v391 = math.clamp(v390, 1, 3)
	local v392 = #v_u_6.TILE_IDS / v391
	local v393 = math.ceil(v392)
	local v394 = (v388 - (v391 - 1) * v_u_7) / v391
	local v395 = math.floor(v394)
	local v396 = (v333.viewport.h - (v393 - 1) * v_u_7) / v393
	local v397 = math.floor(v396)
	local v398
	if v_u_6.TILE_MIN_H <= v397 then
		v398 = math.min(v397, 128)
	else
		v398 = v_u_6.TILE_MIN_H
	end
	v333.tiles = {}
	for v399, v400 in v_u_6.TILE_IDS do
		local v401 = (v399 - 1) % v391
		local v402 = (v399 - 1) / v391
		local v403 = math.floor(v402)
		local v404 = v333.tiles
		local v405 = v401 * (v395 + v_u_7)
		local v406 = v403 * (v398 + v_u_7)
		local v407 = {
			["x"] = math.floor(v405),
			["y"] = math.floor(v406)
		}
		local v408 = math.floor(v395)
		v407.w = math.max(0, v408)
		local v409 = math.floor(v398)
		v407.h = math.max(0, v409)
		v404[v400] = v407
	end
	v333.cols = v391
	v333.tileW = v395
	v333.tileH = v398
	v333.contentW = v388
	local v410 = v393 * v398 + (v393 - 1) * v_u_7
	local v411 = v410 + 14
	local v412 = v304.mastery
	local v413 = type(v412) ~= "number" and 6 or v304.mastery
	local v414 = {
		["head"] = nil,
		["rows"] = nil,
		["firsts"] = nil
	}
	local v415 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 22,
		["y"] = math.floor(v411)
	}
	local v416 = math.floor(v388)
	v415.w = math.max(0, v416)
	v414.head = v415
	v414.rows = {}
	v333.mastery = v414
	for v417 = 1, v413 do
		local v418 = v333.mastery.rows
		local v419 = v411 + 26 + (v417 - 1) * 34
		local v420 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 30,
			["y"] = math.floor(v419)
		}
		local v421 = math.floor(v388)
		v420.w = math.max(0, v421)
		table.insert(v418, v420)
	end
	local v422 = v411 + 26 + v413 * 34
	local v423 = v333.mastery
	local v424 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = 26,
		["y"] = math.floor(v422)
	}
	local v425 = math.floor(v388)
	v424.w = math.max(0, v425)
	v423.firsts = v424
	v333.contentH = v422 + 26
	v333.tilesH = v410
	v333.scroll = v333.contentH > v333.viewport.h
	v318.A = v333
	local v426 = {}
	local v427 = v_u_6.BACK_W
	local v428 = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v429 = math.floor(v427)
	v428.w = math.max(0, v429)
	local v430 = math.floor(v313)
	v428.h = math.max(0, v430)
	v426.back = v428
	if v325 then
		local v431 = v_u_6.BACK_W + v_u_7
		local v432 = v310 - v_u_6.BACK_W - v_u_7
		local v433 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v431)
		}
		local v434 = math.floor(v432)
		v433.w = math.max(0, v434)
		local v435 = math.floor(v313)
		v433.h = math.max(0, v435)
		v426.title = v433
		local v436 = v310 - v317
		local v437 = v313 + v_u_7
		local v438 = {
			["x"] = math.floor(v436),
			["y"] = math.floor(v437)
		}
		local v439 = math.floor(v317)
		v438.w = math.max(0, v439)
		local v440 = math.floor(v313)
		v438.h = math.max(0, v440)
		v426.sheetBtn = v438
		local v441 = v313 + v_u_7
		local v442 = v310 - v317 - v_u_7
		local v443 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v441)
		}
		local v444 = math.floor(v442)
		v443.w = math.max(0, v444)
		local v445 = math.floor(v313)
		v443.h = math.max(0, v445)
		v426.help = v443
	else
		local v446 = v310 - v317
		local v447 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v446)
		}
		local v448 = math.floor(v317)
		v447.w = math.max(0, v448)
		local v449 = math.floor(v313)
		v447.h = math.max(0, v449)
		v426.sheetBtn = v447
		local v450 = v426.sheetBtn.x - v_u_7 - v326
		local v451 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v450)
		}
		local v452 = math.floor(v326)
		v451.w = math.max(0, v452)
		local v453 = math.floor(v313)
		v451.h = math.max(0, v453)
		v426.help = v451
		local v454 = v_u_6.BACK_W + v_u_7
		local v455 = v426.help.x - v_u_7 - (v_u_6.BACK_W + v_u_7)
		local v456 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v454)
		}
		local v457 = math.floor(v455)
		v456.w = math.max(0, v457)
		local v458 = math.floor(v313)
		v456.h = math.max(0, v458)
		v426.title = v456
	end
	v426.helpShort = v426.help.w < v_u_6.HELP_W_LONG
	local v459 = v328 + (v329 and 4 or v_u_7)
	local v460 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v459)
	}
	local v461 = math.floor(v310)
	v460.w = math.max(0, v461)
	local v462 = math.floor(v330)
	v460.h = math.max(0, v462)
	v426.bar = v460
	v426.chips = v_u_6.barChips(v310, v330)
	local v463 = v426.bar.y + v426.bar.h + (v329 and 4 or v_u_7)
	if v331 then
		local v464 = v426.sheetBtn.x - v_u_7 - v_u_6.HELP_W_SHORT
		local v465 = v_u_6.HELP_W_SHORT
		local v466 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v464)
		}
		local v467 = math.floor(v465)
		v466.w = math.max(0, v467)
		local v468 = math.floor(v313)
		v466.h = math.max(0, v468)
		v426.help = v466
		local v469 = v426.help.x - v_u_7 - v_u_6.LEGEND_BTN_W
		local v470 = v_u_6.LEGEND_BTN_W
		local v471 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v469)
		}
		local v472 = math.floor(v470)
		v471.w = math.max(0, v472)
		local v473 = math.floor(v313)
		v471.h = math.max(0, v473)
		v426.legendBtn = v471
		local v474 = v_u_6.BACK_W + v_u_7
		local v475 = v426.legendBtn.x - v_u_7 - (v_u_6.BACK_W + v_u_7)
		local v476 = math.max(0, v475)
		local v477 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v474)
		}
		local v478 = math.floor(v476)
		v477.w = math.max(0, v478)
		local v479 = math.floor(v313)
		v477.h = math.max(0, v479)
		v426.title = v477
		v426.helpShort = true
	end
	if v319 and not v331 then
		local v480 = v426.bar.y + v426.bar.h + 2
		local v481 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v480)
		}
		local v482 = math.floor(v310)
		v481.w = math.max(0, v482)
		local v483 = math.floor(v327)
		v481.h = math.max(0, v483)
		v426.note = v481
		v463 = v426.note.y + v426.note.h + v_u_7
	end
	local v484 = v310 >= 700
	local v485 = v324 + 4
	local v486 = 200
	local v487 = 110
	local v488 = 190
	if v332 then
		if v484 then
			v488 = 120
			v487 = 84
			v486 = 120
		else
			v488 = 104
			v487 = 76
			v486 = 104
		end
	elseif not v484 then
		local v489 = (v310 - 16 - 12) / 3
		v488 = math.floor(v489)
		v486 = v488
		v487 = v486
		local v490 = v486
		v486 = v487
		v490 = v487
	end
	if v325 then
		v486 = v310 - 16
		v487 = v310 - 16
		v488 = v310 - 16
	end
	local v491, v492, v493, v494, v495, v496, v497, v498
	if v332 then
		local v499 = v310 - 8 - v488
		local v500 = v499 - 6 - v487
		local v501 = v500 - 6 - v486
		local v502 = v501 - 16
		local v503 = v_u_6.wrapLines
		local v504 = v304.textChars or v_u_6.TEXT_CHARS
		local v505 = math.min(3, v503(v504, v323, v502))
		local v506 = v_u_6.wrapLines(v304.whyChars or v_u_6.WHY_CHARS_SIDE, v323, v502 - 18) * v324
		local v507 = 6 + v485 + math.min(2, v505) * v324 + 2 + v506 + 6
		local v508 = v314 + 16
		local v509 = v312 - v313 - 4
		local v510 = v312 - v463 - v_u_6.NODE_H - 8
		local v511 = math.min(v509, v510)
		local v512 = math.max(v508, v507, v511)
		local v513 = v314 + 16
		local v514 = v312 - v313 - 4
		local v515 = math.max(v513, v514)
		local v516 = math.min(v512, v515)
		while v505 > 1 and v516 < 6 + v485 + v505 * v324 + 2 + v506 + 6 do
			v505 = v505 - 1
		end
		local v517 = v505 * v324
		local v518 = v314 + 16
		local v519 = 6 + v485 + v517 + 2 + v506 + 6
		local v520 = math.max(v518, v519)
		v491 = math.min(v516, v520)
		local v521 = (v491 - v314) / 2
		local v522 = math.floor(v521)
		v492 = {
			["x"] = math.floor(v499),
			["y"] = math.floor(v522)
		}
		local v523 = math.floor(v488)
		v492.w = math.max(0, v523)
		local v524 = math.floor(v314)
		v492.h = math.max(0, v524)
		v493 = {
			["x"] = math.floor(v500),
			["y"] = math.floor(v522)
		}
		local v525 = math.floor(v487)
		v493.w = math.max(0, v525)
		local v526 = math.floor(v314)
		v493.h = math.max(0, v526)
		v494 = {
			["x"] = math.floor(v501),
			["y"] = math.floor(v522)
		}
		local v527 = math.floor(v486)
		v494.w = math.max(0, v527)
		local v528 = math.floor(v314)
		v494.h = math.max(0, v528)
		v495 = {
			["x"] = 8,
			["y"] = 5,
			["w"] = nil,
			["h"] = nil
		}
		local v529 = math.floor(v502)
		v495.w = math.max(0, v529)
		local v530 = math.floor(v485)
		v495.h = math.max(0, v530)
		local v531 = 5 + v485
		v496 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v531)
		}
		local v532 = math.floor(v502)
		v496.w = math.max(0, v532)
		local v533 = math.floor(v517)
		v496.h = math.max(0, v533)
		local v534 = 5 + v485 + v517 + 2
		local v535 = v491 - (5 + v485 + v517 + 2) - 4
		local v536 = math.min(v506, v535)
		local v537 = math.max(v324, v536)
		v497 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v534)
		}
		local v538 = math.floor(v502)
		v497.w = math.max(0, v538)
		local v539 = math.floor(v537)
		v497.h = math.max(0, v539)
		v498 = v497
	else
		local v540 = v324 * v_u_6.wrapLines(v304.textChars or v_u_6.TEXT_CHARS, v323, v310 - 16)
		local v541 = v324 + 2
		local v542 = v_u_6.whyHeight(v310 - 16 - 18, v323, v304.whyChars)
		local v543
		if v325 then
			v543 = v314 * 3 + 12
		else
			v543 = v314
		end
		v491 = 6 + v485 + v540 + v541 + v542 + 6 + v543 + 8
		local v544 = v491 - 8 - v543
		if v325 then
			v494 = {
				["x"] = 8,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = math.floor(v544)
			}
			local v545 = math.floor(v486)
			v494.w = math.max(0, v545)
			local v546 = math.floor(v314)
			v494.h = math.max(0, v546)
			local v547 = v544 + v314 + 6
			v493 = {
				["x"] = 8,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = math.floor(v547)
			}
			local v548 = math.floor(v487)
			v493.w = math.max(0, v548)
			local v549 = math.floor(v314)
			v493.h = math.max(0, v549)
			local v550 = v544 + 2 * (v314 + 6)
			v492 = {
				["x"] = 8,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = math.floor(v550)
			}
			local v551 = math.floor(v488)
			v492.w = math.max(0, v551)
			local v552 = math.floor(v314)
			v492.h = math.max(0, v552)
		else
			v494 = {
				["x"] = 8,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = math.floor(v544)
			}
			local v553 = math.floor(v486)
			v494.w = math.max(0, v553)
			local v554 = math.floor(v314)
			v494.h = math.max(0, v554)
			local v555 = v494.x + v494.w + 6
			v493 = {
				["x"] = math.floor(v555),
				["y"] = math.floor(v544)
			}
			local v556 = math.floor(v487)
			v493.w = math.max(0, v556)
			local v557 = math.floor(v314)
			v493.h = math.max(0, v557)
			local v558 = v493.x + v493.w + 6
			v492 = {
				["x"] = math.floor(v558),
				["y"] = math.floor(v544)
			}
			local v559 = math.floor(v488)
			v492.w = math.max(0, v559)
			local v560 = math.floor(v314)
			v492.h = math.max(0, v560)
		end
		local v561 = v310 - 16
		v495 = {
			["x"] = 8,
			["y"] = 6,
			["w"] = nil,
			["h"] = nil
		}
		local v562 = math.floor(v561)
		v495.w = math.max(0, v562)
		local v563 = math.floor(v485)
		v495.h = math.max(0, v563)
		local v564 = 6 + v485
		local v565 = v310 - 16
		v496 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v564)
		}
		local v566 = math.floor(v565)
		v496.w = math.max(0, v566)
		local v567 = math.floor(v540)
		v496.h = math.max(0, v567)
		local v568 = 6 + v485 + v540
		local v569 = v310 - 16
		v497 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v568)
		}
		local v570 = math.floor(v569)
		v497.w = math.max(0, v570)
		local v571 = math.floor(v541)
		v497.h = math.max(0, v571)
		local v572 = 6 + v485 + v540 + v541
		local v573 = v310 - 16
		v498 = {
			["x"] = 8,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v572)
		}
		local v574 = math.floor(v573)
		v498.w = math.max(0, v574)
		local v575 = math.floor(v542)
		v498.h = math.max(0, v575)
	end
	local v576 = v312 - v491
	local v577 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v576)
	}
	local v578 = math.floor(v310)
	v577.w = math.max(0, v578)
	local v579 = math.floor(v491)
	v577.h = math.max(0, v579)
	v426.detail = v577
	v426.mode = v332 and "sheet" or "stack"
	v426.narrow = v325
	v426.name = v495
	v426.text = v496
	v426.now = v497
	v426.why = v498
	v426.learn = v494
	v426.undo = v493
	v426.unlearn = v492
	local v580 = v494.x
	local v581 = v494.y + v494.h - 4
	local v582 = v494.w
	local v583 = {
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 4,
		["x"] = math.floor(v580),
		["y"] = math.floor(v581)
	}
	local v584 = math.floor(v582)
	v583.w = math.max(0, v584)
	v426.holdBar = v583
	local v585
	if v332 then
		local v586 = v312 - v463
		local v587 = math.max(0, v586)
		v585 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v463)
		}
		local v588 = math.floor(v310)
		v585.w = math.max(0, v588)
		local v589 = math.floor(v587)
		v585.h = math.max(0, v589)
	else
		local v590 = v312 - v491 - v_u_7 - v463
		local v591 = math.max(0, v590)
		v585 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v463)
		}
		local v592 = math.floor(v310)
		v585.w = math.max(0, v592)
		local v593 = math.floor(v591)
		v585.h = math.max(0, v593)
	end
	v426.ladder = v585
	local v594 = v310 - v_u_6.SCROLL
	v426.contentW = v594
	v426.cols = v_u_6.nodeCols(v308, v594)
	v426.legendOpen = not v331 or v304.legendOpen == true
	local v595 = 0
	if v426.legendOpen then
		local v596 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil
		}
		local v597 = math.floor(v594)
		v596.w = math.max(0, v597)
		local v598 = math.floor(v321)
		v596.h = math.max(0, v598)
		v426.legend = v596
		if v331 and v304.bonus == true then
			local v599 = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = math.floor(v321)
			}
			local v600 = math.floor(v594)
			v599.w = math.max(0, v600)
			local v601 = math.floor(v327)
			v599.h = math.max(0, v601)
			v426.legendNote = v599
			v321 = v321 + v327 + 2
		end
		v595 = v321 + 6
	else
		local v602 = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = 0
		}
		local v603 = math.floor(v594)
		v602.w = math.max(0, v603)
		v426.legend = v602
	end
	local v604 = v_u_6.ladder
	local v605 = v304.tiers
	v426.ladderLayout = v604(v594, type(v605) ~= "table" and {
		3,
		3,
		3,
		2,
		1
	} or v304.tiers, v426.cols, v595)
	v426.sheetPad = not v332 and 0 or v491 + 8
	v318.B = v426
	local v606 = {}
	local v607 = v_u_6.BACK_W
	local v608 = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v609 = math.floor(v607)
	v608.w = math.max(0, v609)
	local v610 = math.floor(v313)
	v608.h = math.max(0, v610)
	v606.back = v608
	if v325 then
		local v611 = v_u_6.BACK_W + v_u_7
		local v612 = v310 - v_u_6.BACK_W - v_u_7
		local v613 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v611)
		}
		local v614 = math.floor(v612)
		v613.w = math.max(0, v614)
		local v615 = math.floor(v313)
		v613.h = math.max(0, v615)
		v606.title = v613
		local v616 = v310 - v_u_6.HELP_W_SHORT
		local v617 = v313 + v_u_7
		local v618 = v_u_6.HELP_W_SHORT
		local v619 = {
			["x"] = math.floor(v616),
			["y"] = math.floor(v617)
		}
		local v620 = math.floor(v618)
		v619.w = math.max(0, v620)
		local v621 = math.floor(v313)
		v619.h = math.max(0, v621)
		v606.help = v619
		local v622 = v313 + v_u_7
		local v623 = v310 - v_u_6.HELP_W_SHORT - v_u_7
		local v624 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = math.floor(v622)
		}
		local v625 = math.floor(v623)
		v624.w = math.max(0, v625)
		local v626 = math.floor(v313)
		v624.h = math.max(0, v626)
		v606.free = v624
	else
		local v627 = v310 - v326
		local v628 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v627)
		}
		local v629 = math.floor(v326)
		v628.w = math.max(0, v629)
		local v630 = math.floor(v313)
		v628.h = math.max(0, v630)
		v606.help = v628
		local v631 = v_u_6.BACK_W + v_u_7
		local v632 = (v606.help.x - v_u_7 - v_u_6.BACK_W - v_u_7) * 0.4
		local v633 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v631)
		}
		local v634 = math.floor(v632)
		v633.w = math.max(0, v634)
		local v635 = math.floor(v313)
		v633.h = math.max(0, v635)
		v606.title = v633
		local v636 = v606.title.x + v606.title.w + v_u_7
		local v637 = v606.help.x - v_u_7 - (v606.title.x + v606.title.w + v_u_7)
		local v638 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = math.floor(v636)
		}
		local v639 = math.floor(v637)
		v638.w = math.max(0, v639)
		local v640 = math.floor(v313)
		v638.h = math.max(0, v640)
		v606.free = v638
	end
	v606.helpShort = v606.help.w < v_u_6.HELP_W_LONG
	local v641 = v328 + v_u_7
	local v642 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v641)
	}
	local v643 = math.floor(v310)
	v642.w = math.max(0, v643)
	local v644 = math.floor(v330)
	v642.h = math.max(0, v644)
	v606.bar = v642
	v606.chips = v_u_6.barChips(v310, v330)
	local v645 = v606.bar.y + v606.bar.h + v_u_7
	local v646 = (v310 - 2 * v_u_7) / 3
	local v647 = math.floor(v646)
	v606.slots = {}
	for v648 = 1, 3 do
		local v649 = v606.slots
		local v650 = (v648 - 1) * (v647 + v_u_7)
		local v651 = {
			["x"] = math.floor(v650),
			["y"] = math.floor(v645)
		}
		local v652 = math.floor(v647)
		v651.w = math.max(0, v652)
		local v653 = math.floor(v314)
		v651.h = math.max(0, v653)
		table.insert(v649, v651)
	end
	local v654 = v645 + v314 + 4
	local v655 = v_u_6.wrapLines(v304.flawNoteChars or v_u_6.FLAWNOTE_CHARS, v323, v310 - 22) * v324 + 4
	local v656 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v654)
	}
	local v657 = math.floor(v310)
	v656.w = math.max(0, v657)
	local v658 = math.floor(v655)
	v656.h = math.max(0, v658)
	v606.note = v656
	local v659 = v606.note.y + v606.note.h + v_u_7
	local v660 = v312 - v659
	local v661 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v659)
	}
	local v662 = math.floor(v310)
	v661.w = math.max(0, v662)
	local v663 = math.floor(v660)
	v661.h = math.max(0, v663)
	v606.list = v661
	v606.contentW = v310 - v_u_6.SCROLL
	local v664 = v_u_6.flawCards
	local v665 = v606.contentW
	local v666 = v304.flaws
	v606.cards = v664(v665, type(v666) ~= "number" and 15 or v304.flaws, v304)
	v318.F = v606
	local v667 = {}
	local v668 = {
		["x"] = 0,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v669 = math.floor(v310)
	v668.w = math.max(0, v669)
	local v670 = math.floor(v312)
	v668.h = math.max(0, v670)
	v667.panel = v668
	local v671 = v310 - 110
	local v672 = {
		["x"] = nil,
		["y"] = 0,
		["w"] = 110,
		["h"] = nil,
		["x"] = math.floor(v671)
	}
	local v673 = math.floor(v313)
	v672.h = math.max(0, v673)
	v667.close = v672
	local v674 = v310 - 110 - 16
	local v675 = {
		["x"] = 8,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil
	}
	local v676 = math.floor(v674)
	v675.w = math.max(0, v676)
	local v677 = math.floor(v313)
	v675.h = math.max(0, v677)
	v667.title = v675
	local v678 = v313 + v_u_7
	local v679 = v312 - v313 - v_u_7
	local v680 = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = math.floor(v678)
	}
	local v681 = math.floor(v310)
	v680.w = math.max(0, v681)
	local v682 = math.floor(v679)
	v680.h = math.max(0, v682)
	v667.list = v680
	v667.row = v_u_6.sheetRow(v310 - v_u_6.SCROLL)
	v318.S = v667
	v318.G = v667
	return v318
end
v_u_6.TEXT = {
	["level"] = "FIELD LEVEL",
	["points"] = "POINTS",
	["sheet"] = "EFFECT SHEET",
	["back"] = "BACK",
	["flaws"] = "FLAWS",
	["learn"] = "HOLD TO LEARN",
	["undo"] = "UNDO",
	["unlearn"] = "UNLEARN",
	["take"] = "HOLD TO TAKE",
	["drop"] = "HOLD TO DROP",
	["maxed"] = "MAX",
	["locked"] = "LOCKED",
	["needsPoints"] = "NEEDS POINTS",
	["lobbyOnly"] = "LOBBY ONLY",
	["notActive"] = "Perks are not active in this game.",
	["unavailable"] = "Perks are not available right now. Try again in a moment.",
	["loading"] = "Reading your perks ...",
	["pickNode"] = "Pick a perk to read what it does.",
	["sheetEmpty"] = "Nothing changes yet. Learn a perk and it shows up here.",
	["sheetTitle"] = "EFFECT SHEET",
	["maxLevel"] = "MAX LEVEL",
	["updated"] = "The perk list was updated. All your points are back, pick your perks again.",
	["flawNote"] = "A flaw lends you bonus points that only work in its branch. Dropping it takes them back.",
	["legend"] = "LEGEND",
	["close"] = "CLOSE",
	["help"] = "HOW POINTS WORK",
	["helpShort"] = "HELP",
	["tokens"] = "TOKENS",
	["slotFree"] = "FREE SLOT",
	["ready"] = "ready",
	["mastery"] = "MASTERY"
}
local function v_u_688(p683) -- name: commas
	local v684 = tonumber(p683) or 0
	local v685 = math.floor(v684)
	local v686 = math.max(0, v685)
	local v687 = tostring(v686):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if string.sub(v687, 1, 1) == "," then
		v687 = string.sub(v687, 2)
	end
	return v687
end
v_u_6.commas = v_u_688
function v_u_6.levelText(p689) -- name: levelText
	-- upvalues: (copy) v_u_6
	local v690 = "%s %d"
	local v691 = v_u_6.TEXT.level
	if p689 then
		p689 = p689.fl
	end
	local v692 = tonumber(p689) or 1
	return v690:format(v691, (math.floor(v692)))
end
function v_u_6.pointsText(p693) -- name: pointsText
	-- upvalues: (copy) v_u_6
	local v694
	if type(p693) == "table" then
		local v695 = p693.points
		v694 = type(v695) ~= "table" and {} or p693.points
	else
		v694 = {}
	end
	local v696 = v_u_6.TEXT.points
	local v697 = v694.free
	local v698 = tonumber(v697) or 0
	return ("%s %d"):format(v696, (math.floor(v698)))
end
function v_u_6.levelProgress(p699) -- name: levelProgress
	-- upvalues: (copy) v_u_6, (copy) v_u_688
	if type(p699) ~= "table" then
		return 0, ""
	end
	local v700 = p699.fl
	local v701 = tonumber(v700) or 1
	local v702 = math.floor(v701)
	local v703 = p699.flMax
	local v704 = tonumber(v703) or 40
	if math.floor(v704) <= v702 then
		return 1, v_u_6.TEXT.maxLevel
	end
	local v705 = p699.flFe
	local v706 = tonumber(v705) or 0
	local v707 = math.floor(v706)
	local v708 = p699.flNeed
	local v709 = tonumber(v708) or 1
	local v710 = math.floor(v709)
	local v711 = math.max(1, v710)
	local v712 = v707 / v711
	return math.clamp(v712, 0, 1), ("%s / %s FE"):format(v_u_688(v707), (v_u_688(v711)))
end
function v_u_6.tileText(p713, p714) -- name: tileText
	-- upvalues: (copy) v_u_6
	local v715
	if p713 then
		v715 = p713.spent
	else
		v715 = p713
	end
	local v716 = tonumber(v715) or 0
	local v717 = math.floor(v716)
	local v718
	if p713 then
		v718 = p713.openTier
	else
		v718 = p713
	end
	local v719 = tonumber(v718) or 1
	local v720 = math.floor(v719)
	if p713 then
		p713 = p713.learnable
	end
	local v721 = tonumber(p713) or 0
	local v722 = math.floor(v721)
	local v723 = ("%d %s spent"):format(v717, v717 == 1 and "point" or "points")
	local v724 = ("Tier %d open"):format((math.max(1, v720)))
	if v722 > 0 and (type(p714) == "table" and p714.canChange ~= false) then
		v724 = ("%s  \194\183  %d %s"):format(v724, v722, v_u_6.TEXT.ready)
	end
	return v723, v724
end
function v_u_6.flawTileText(p725) -- name: flawTileText
	local v726
	if type(p725) == "table" then
		local v727 = p725.flawSlots
		v726 = type(v727) ~= "table" and {} or p725.flawSlots
	else
		v726 = {}
	end
	local v728 = v726.used
	local v729 = tonumber(v728) or 0
	local v730 = math.floor(v729)
	local v731 = v726.max
	local v732 = tonumber(v731) or 0
	local v733 = math.floor(v732)
	local v734 = v726.total
	local v735 = tonumber(v734) or 3
	local v736 = math.floor(v735)
	local v737 = ("%d of %d slots used"):format(v730, (math.max(v733, 0)))
	local v738 = v726.at
	local v739 = type(v738) ~= "table" and { 5, 15, 25 } or v726.at
	if v733 >= v736 then
		return v737, "All slots open"
	end
	local v740 = v739[v733 + 1]
	return v737, ("Next slot at Field Level %d"):format(tonumber(v740) or 5)
end
function v_u_6.statusLine(p741) -- name: statusLine
	if type(p741) == "table" then
		local v742 = p741.rank
		local v743 = tonumber(v742) or 0
		local v744 = math.floor(v743)
		local v745 = p741.ranks
		local v746 = tonumber(v745) or 1
		local v747 = math.floor(v746)
		if v744 > 0 then
			local v748
			if p741.fresh == nil then
				v748 = p741.canUndo == true
			else
				v748 = p741.fresh == true
			end
			local v749 = ("%s  \194\183  %s"):format(p741.state == "max" and "MAX" or ("Rank %d/%d"):format(v744, v747), v748 and "Free undo" or "Locked in")
			if v748 then
				return v749, "fresh"
			else
				return v749, "lockedin"
			end
		elseif p741.state == "open" then
			local v750 = p741.nextCost
			local v751 = tonumber(v750) or 1
			local v752 = math.floor(v751)
			local v753 = ("Costs %d %s"):format(v752, v752 == 1 and "point" or "points")
			if p741.learnable == true then
				return v753, "ready"
			end
			if p741.why then
				local v754 = p741.why or ""
				local v755 = tostring(v754)
				local v756 = string.gsub(v755, " free points", " points")
				v753 = string.gsub(v756, "%.$", "")
			end
			return v753, "open"
		else
			local v757 = p741.trial
			if type(v757) == "table" and (p741.trial.done ~= true and v744 == 0) then
				local v758 = p741.trial.have
				local v759 = tonumber(v758) or 0
				local v760 = math.floor(v759)
				local v761 = p741.trial.need
				local v762 = tonumber(v761) or 0
				local v763 = ("Trial %d of %d"):format(v760, (math.floor(v762)))
				local v764 = p741.why or ""
				local v765 = tostring(v764)
				local v766 = string.gsub(v765, " free points", " points")
				local v767 = string.gsub(v766, "%.$", "")
				if v767 == "" or string.sub(v767, 1, 6) == "Trial:" then
					return v763, "trial"
				else
					local v768, v769, v770 = string.match(v767, "^Needs (%d+) points? in (%u+), you have (%d+)$")
					if v768 then
						v767 = ("Needs %s in %s, have %s"):format(v768, v769, v770)
					end
					local v771 = v767 .. "  \194\183  " .. v763
					if p741.state == "blocked" then
						return v771, "blocked"
					else
						return v771, "locked"
					end
				end
			else
				local v772
				if p741.why then
					local v773 = p741.why or ""
					local v774 = tostring(v773)
					local v775 = string.gsub(v774, " free points", " points")
					v772 = string.gsub(v775, "%.$", "")
				else
					v772 = "Locked"
				end
				if p741.state == "blocked" then
					return v772, "blocked"
				else
					return v772, "locked"
				end
			end
		end
	else
		return "", "muted"
	end
end
function v_u_6.requirements(p776, p777) -- name: requirements
	local v778 = {}
	if type(p776) ~= "table" then
		return v778
	end
	if p776.flMin then
		local v779 = {
			["text"] = ("Field Level %d"):format(p776.flMin)
		}
		local v780
		if p777 then
			v780 = p777.fl
		else
			v780 = p777
		end
		v779.ok = (tonumber(v780) or 1) >= p776.flMin
		table.insert(v778, v779)
	end
	local v781 = string.match
	local v782 = p776.why or ""
	local v783, v784, v785 = v781(tostring(v782), "^Needs (%d+) points? in (%u+), you have (%d+)")
	if v783 and p776.state ~= "open" then
		local v786 = {
			["text"] = nil,
			["ok"] = false,
			["text"] = ("%s points in %s, you have %s"):format(v783, v784, v785)
		}
		table.insert(v778, v786)
	end
	local v787 = p776.requires
	if type(v787) == "table" then
		for _, v793 in p776.requires do
			local v789 = false
			if type(p777) == "table" then
				local v790 = p777.nodes
				if type(v790) == "table" then
					for _, v791 in p777.nodes do
						if v791.id ~= v793 then
							continue
						end
						local v792 = v791.rank
						v789 = (tonumber(v792) or 0) > 0
						local v793 = v791.name or v793
					end
				end
			end
			local v794 = {
				["text"] = tostring(v793),
				["ok"] = v789
			}
			table.insert(v778, v794)
		end
	end
	local v795 = p776.proof
	if type(v795) == "table" then
		local v796 = p776.proof
		local v797
		if v796.kills then
			local v798 = v796.need or 0
			local v799 = v796.class
			v797 = ("%d %s kills"):format(v798, (tostring(v799)))
		else
			v797 = ("mastery %d stars"):format(v796.need or 0)
		end
		local v800 = {}
		local v801 = v796.have
		local v802 = tonumber(v801) or 0
		local v803 = math.floor(v802)
		local v804 = v796.need
		local v805 = tonumber(v804) or 0
		v800.text = ("%s (%d of %d)"):format(v797, v803, (math.floor(v805)))
		v800.ok = v796.ok == true
		table.insert(v778, v800)
	end
	local v806 = p776.trial
	if type(v806) == "table" then
		local v807 = {}
		local v808 = p776.trial.have
		local v809 = tonumber(v808) or 0
		local v810 = math.floor(v809)
		local v811 = p776.trial.need
		local v812 = tonumber(v811) or 0
		v807.text = ("Trial %d of %d"):format(v810, (math.floor(v812)))
		v807.ok = p776.trial.done == true
		table.insert(v778, v807)
	end
	return v778
end
function v_u_6.valueWords(p813) -- name: valueWords
	local v814 = tostring(p813 or "")
	if v814 == "" then
		return v814
	end
	local v815 = {}
	for v816 in string.gmatch(v814 .. " / ", "(.-) / ") do
		local v817 = string.match(v816, "^(.-) on$")
		local v818
		if v817 == nil or v817 == "" then
			v818 = v816 == "on" and "active" or v816
		else
			v818 = v817 .. ": active"
		end
		table.insert(v815, v818)
	end
	return table.concat(v815, " / ")
end
function v_u_6.buttonLook(p819, p820) -- name: buttonLook
	return p819 and {
		["on"] = true,
		["text"] = "text",
		["textA"] = 0,
		["stroke"] = nil,
		["strokeA"] = 0,
		["strokeThick"] = 2,
		["bg"] = "raised",
		["bgA"] = 0.1,
		["lock"] = false,
		["stroke"] = p820 == "undo" and "success" or (p820 == "unlearn" and "danger" or "accent")
	} or {
		["on"] = false,
		["text"] = "text2",
		["textA"] = 0.35,
		["stroke"] = "line",
		["strokeA"] = 0.55,
		["strokeThick"] = 1,
		["bg"] = "bg",
		["bgA"] = 0.35,
		["lock"] = true
	}
end
function v_u_6.detail(p821, p822) -- name: detail
	-- upvalues: (copy) v_u_6
	local v823 = v_u_6.TEXT
	local v824 = {
		["text"] = nil,
		["now"] = "",
		["learnLabel"] = nil,
		["learnOn"] = false,
		["undoOn"] = false,
		["unlearnOn"] = false,
		["unlearnLabel"] = nil,
		["reqs"] = nil,
		["trial"] = nil,
		["text"] = v823.pickNode,
		["learnLabel"] = v823.learn,
		["unlearnLabel"] = v823.unlearn,
		["reqs"] = {}
	}
	if type(p821) ~= "table" then
		return v824
	end
	local v825
	if type(p822) == "table" then
		v825 = p822.canChange == true
	else
		v825 = false
	end
	local v826 = p821.text or ""
	v824.text = tostring(v826)
	local v827 = p821.name or ""
	v824.name = tostring(v827)
	local v828 = v_u_6.valueWords(p821.now)
	local v829 = v_u_6.valueWords(p821.next)
	if p821.state == "max" then
		v824.now = ("Now %s  \194\183  top rank"):format(v828)
	else
		local v830 = p821.rank
		if (tonumber(v830) or 0) > 0 then
			v824.now = ("Now %s  \194\183  next %s"):format(v828, v829)
		else
			v824.now = ("Next %s"):format(v829)
		end
	end
	if p821.state == "max" then
		v824.learnLabel = v823.maxed
	elseif v825 then
		if p821.learnable == true then
			v824.learnLabel = v823.learn
			v824.learnOn = true
		elseif p821.state == "open" then
			v824.learnLabel = v823.needsPoints
		else
			v824.learnLabel = v823.locked
		end
	else
		v824.learnLabel = v823.lobbyOnly
	end
	local v831
	if v825 then
		v831 = p821.canUndo == true
	else
		v831 = v825
	end
	v824.undoOn = v831
	if v825 then
		if p821.canUnlearn == true then
			v825 = p821.canUndo ~= true
		else
			v825 = false
		end
	end
	v824.unlearnOn = v825
	if p821.unlearnCost then
		local v832 = p821.unlearnCost
		local v833 = tonumber(v832) or 0
		local v834 = math.floor(v833)
		v824.unlearnLabel = ("%s: %d %s"):format(v823.unlearn, v834, v834 == 1 and "TOKEN" or "TOKENS")
	end
	v824.reqs = v_u_6.requirements(p821, p822)
	local v835 = p821.trial
	if type(v835) == "table" then
		v824.trial = {
			["have"] = p821.trial.have,
			["need"] = p821.trial.need,
			["done"] = p821.trial.done,
			["text"] = p821.trial.text
		}
	end
	if p821.state ~= "max" and (p821.why and not v824.learnOn) then
		local v836 = p821.why
		v824.why = tostring(v836)
	end
	return v824
end
function v_u_6.masteryText(p837) -- name: masteryText
	if type(p837) ~= "table" then
		return ""
	end
	local v838 = string.upper
	local v839 = p837.class
	local v840 = v838((tostring(v839)))
	local v841 = p837.kills
	local v842 = tonumber(v841) or 0
	local v843 = math.floor(v842)
	local v844 = p837.stars
	local v845 = tonumber(v844) or 0
	local v846 = math.floor(v845)
	local v847 = p837.starsMax
	local v848 = tonumber(v847) or 5
	local v849 = ("%s  %d kills  %d of %d stars"):format(v840, v843, v846, (math.floor(v848)))
	if p837.nextAt then
		local v850 = p837.nextAt
		local v851 = tonumber(v850) or 0
		v849 = v849 .. ("  \194\183  next at %d"):format((math.floor(v851)))
	end
	return v849
end
function v_u_6.tokensText(p852) -- name: tokensText
	-- upvalues: (copy) v_u_6
	local v853 = "%s %d of %d"
	local v854 = v_u_6.TEXT.tokens
	local v855
	if p852 then
		v855 = p852.tokens
	else
		v855 = p852
	end
	local v856 = tonumber(v855) or 0
	local v857 = math.floor(v856)
	if p852 then
		p852 = p852.tokensMax
	end
	local v858 = tonumber(p852) or 9
	return v853:format(v854, v857, (math.floor(v858)))
end
function v_u_6.offText(p859) -- name: offText
	-- upvalues: (copy) v_u_6
	if type(p859) ~= "table" then
		return v_u_6.TEXT.unavailable
	end
	if p859.on ~= false then
		return nil
	end
	local v860 = p859.offText or v_u_6.TEXT.notActive
	return tostring(v860)
end
function v_u_6.debriefText(p861) -- name: debriefText
	-- upvalues: (copy) v_u_6
	if type(p861) == "table" then
		local v862 = p861.fe
		if type(v862) == "number" then
			local v863 = p861.fe
			local v864 = { ("+%d FIELD XP"):format((math.floor(v863))) }
			local v865 = p861.fl
			if type(v865) == "number" then
				local v866 = v_u_6.TEXT.level
				local v867 = p861.fl
				local v868 = math.floor(v867)
				table.insert(v864, ("%s %d"):format(v866, v868))
			end
			local v869 = p861.up
			local v870 = tonumber(v869) or 0
			local v871 = math.floor(v870)
			if v871 > 0 then
				local v872 = v871 == 1 and "POINT" or "POINTS"
				table.insert(v864, ("+%d %s"):format(v871, v872))
			end
			return table.concat(v864, "   ")
		end
	end
	return nil
end
function v_u_6.padHint(p873, p874) -- name: padHint
	return p873 == "Gamepad" and (p874 == "B" and "Hold A: learn   X: undo   Y: effect sheet   LB: how points work   LT / RT: branch   B: back" or (p874 == "F" and "Hold A: take or drop   Y: effect sheet   LB: how points work   B: back" or ((p874 == "S" or p874 == "G") and "B: back" or "A: open   Y: effect sheet   LB: how points work"))) or nil
end
return v_u_6