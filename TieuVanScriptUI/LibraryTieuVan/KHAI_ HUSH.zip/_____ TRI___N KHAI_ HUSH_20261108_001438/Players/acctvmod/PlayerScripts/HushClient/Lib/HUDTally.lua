-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDTally

local v1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Players")
function v1.new(p_u_4, p5) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v_u_6 = p_u_4.UI
	local v_u_7 = p_u_4.Theme
	local v_u_8 = v_u_7.color
	local v9, v_u_10 = pcall(function()
		-- upvalues: (copy) p_u_4
		return p_u_4.cctx.lib.TallyMark
	end)
	if not v9 then
		v_u_10 = nil
	end
	if v_u_10 == nil then
		error("HUDTally: TallyMark is missing")
	end
	local v_u_11 = "WeaponDress"
	local function v12()
		-- upvalues: (ref) v_u_2, (copy) v_u_11
		return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_11, 5))
	end
	local v13, v_u_14 = pcall(v12)
	if not v13 then
		v_u_14 = nil
	end
	local v_u_15 = v_u_3.LocalPlayer
	local v_u_16 = {}
	local v_u_17 = {}
	local v_u_18 = nil
	local v_u_19 = {}
	local v_u_20 = false
	local v_u_21 = ""
	local v_u_22 = -1
	local v_u_23 = false
	local v_u_24 = false
	local v_u_25 = ""
	local v_u_26 = v_u_6.new("Frame", {
		["Name"] = "TallyChip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_8.bg,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(0, -10, 0, 44),
		["Size"] = UDim2.fromOffset(0, 24),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, p5)
	local v_u_27 = v_u_6.stroke(v_u_26, v_u_8.text2, 1, 0.35)
	v_u_6.pad(v_u_26, {
		6,
		8,
		0,
		0
	})
	v_u_6.layout(v_u_26, "h", 6)
	local v28 = v_u_26:FindFirstChildOfClass("UIListLayout")
	if v28 then
		v28.VerticalAlignment = Enum.VerticalAlignment.Center
	end
	local v_u_29 = v_u_6.new("UIScale", {
		["Name"] = "Pop",
		["Scale"] = 1
	}, v_u_26)
	local v_u_30 = v_u_10.new(v_u_26, {
		["size"] = 16,
		["level"] = 0,
		["name"] = "Sign"
	})
	v_u_30.frame.LayoutOrder = 1
	local v_u_31 = v_u_6.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["order"] = 2,
		["textSize"] = 13,
		["parent"] = v_u_26,
		["color"] = v_u_8.text,
		["size"] = UDim2.fromOffset(0, 22)
	})
	v_u_31.Name = "Count"
	v_u_31.TextTruncate = Enum.TextTruncate.None
	local function v_u_37(p32, p33) -- name: applyState
		-- upvalues: (ref) v_u_21, (copy) v_u_31, (ref) v_u_24, (ref) v_u_22, (ref) v_u_10, (copy) v_u_7, (copy) v_u_30, (copy) v_u_27, (copy) v_u_8
		if p32 ~= v_u_21 then
			v_u_21 = p32
			local v34 = v_u_31
			if v_u_24 then
				p32 = string.gsub(p32, "^TALLY ", "")
			end
			v34.Text = p32
		end
		if p33 ~= v_u_22 then
			v_u_22 = p33
			local v35 = v_u_10.colorOf(p33, v_u_7)
			v_u_30:setColor(v35)
			v_u_27.Color = v35
			local v36 = v_u_31
			if p33 <= 0 then
				v35 = v_u_8.text
			end
			v36.TextColor3 = v35
		end
	end
	local function v_u_45(p38) -- name: model
		-- upvalues: (copy) v_u_14, (ref) v_u_10, (ref) v_u_19, (copy) v_u_17
		if p38 == nil then
			return {
				["show"] = false
			}
		end
		local v39 = p38:GetAttribute("Weapon")
		if type(v39) ~= "string" or v39 == "" then
			return {
				["show"] = false
			}
		end
		local v40 = false
		if v_u_14 then
			local v41 = v_u_14.isGold
			if type(v41) == "function" then
				local v42 = v_u_14.isGold
				local v43
				v40, v43 = pcall(v42, v39)
				if v40 then
					v40 = v43 == true
				end
			end
		end
		local v44 = {
			["weapon"] = v39,
			["gold"] = v40,
			["attr"] = v_u_19,
			["live"] = v_u_17
		}
		return v_u_10.chipModel(v44)
	end
	function v_u_16.layout(p46, p47) -- name: layout
		-- upvalues: (ref) v_u_23, (ref) v_u_24, (ref) v_u_21, (copy) v_u_26
		v_u_23 = p46 == true
		local v48
		if p46 == true then
			v48 = p47 == true
		else
			v48 = false
		end
		v_u_24 = v48
		v_u_21 = ""
		if v_u_23 then
			v_u_26.AnchorPoint = Vector2.new(0, 0.5)
			v_u_26.Position = UDim2.new(0, 0, 0, v_u_24 and 36 or 44)
		else
			v_u_26.AnchorPoint = Vector2.new(1, 0.5)
			v_u_26.Position = UDim2.new(0, -10, 0, 44)
		end
	end
	function v_u_16.update(_, p49, p50) -- name: update
		-- upvalues: (copy) v_u_15, (ref) v_u_18, (ref) v_u_19, (ref) v_u_10, (copy) v_u_45, (ref) v_u_25, (ref) v_u_21, (copy) v_u_37, (ref) v_u_20, (copy) v_u_26
		local v51
		if v_u_15 then
			v51 = v_u_15:GetAttribute("SkinsTally")
		else
			v51 = nil
		end
		if v51 ~= v_u_18 then
			v_u_18 = v51
			v_u_19 = v_u_10.parseAttr(v51)
		end
		local v52 = v_u_45(p49)
		local v53
		if v52.show == true then
			v53 = p50 ~= false
		else
			v53 = false
		end
		if v53 then
			local v54 = v52.weaponId
			if v54 ~= v_u_25 then
				v_u_25 = v54
				v_u_21 = ""
			end
			v_u_37(v52.text, v52.level)
		end
		if v53 ~= v_u_20 then
			v_u_20 = v53
			v_u_26.Visible = v53
		end
	end
	local v_u_55 = nil
	local function v61()
		-- upvalues: (ref) v_u_55, (copy) p_u_4, (copy) v_u_17, (copy) v_u_45, (copy) v_u_37, (copy) v_u_26, (ref) v_u_20, (copy) v_u_29, (copy) v_u_6
		v_u_55 = p_u_4.cctx.net.listen("tally.k", function(p56, p57)
			-- upvalues: (ref) v_u_17, (ref) p_u_4, (ref) v_u_45, (ref) v_u_37, (ref) v_u_26, (ref) v_u_20, (ref) v_u_29, (ref) v_u_6
			if type(p56) == "string" and (type(p57) == "number" and p57 == p57) then
				if (v_u_17[p56] or -1) < p57 then
					v_u_17[p56] = p57
				end
				local v58 = p_u_4.cctx.player
				if v58 then
					v58 = p_u_4.cctx.player.Character
				end
				local v59 = v_u_45(v58)
				if v59.show then
					v_u_37(v59.text, v59.level)
					v_u_26.Visible = true
					v_u_20 = true
					v_u_29.Scale = 1.12
					local function v60()
						-- upvalues: (ref) v_u_6, (ref) v_u_29
						v_u_6.tween(v_u_29, {
							["Scale"] = 1
						}, 0.15)
					end
					pcall(v60)
				end
			end
		end)
	end
	pcall(v61)
	function v_u_16.state() -- name: state
		-- upvalues: (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (copy) v_u_17
		return {
			["shown"] = nil,
			["text"] = nil,
			["level"] = nil,
			["k"] = nil,
			["weapon"] = nil,
			["live"] = nil,
			["shown"] = v_u_20,
			["text"] = v_u_21,
			["level"] = v_u_22,
			["weapon"] = v_u_25,
			["live"] = v_u_17
		}
	end
	function v_u_16.rect() -- name: rect
		-- upvalues: (copy) v_u_26
		return {
			["pos"] = v_u_26.AbsolutePosition,
			["size"] = v_u_26.AbsoluteSize,
			["visible"] = v_u_26.Visible
		}
	end
	local v62 = p_u_4.cctx.command
	if type(v62) == "function" then
		pcall(function()
			-- upvalues: (copy) p_u_4, (copy) v_u_16, (copy) v_u_31
			p_u_4.cctx.command("hud.tally", function()
				-- upvalues: (ref) v_u_16, (ref) v_u_31
				local v63 = v_u_16.state()
				local v64 = v_u_16.rect()
				local v65 = v63.shown
				local v66 = tostring(v65)
				local v67 = v_u_31.Text
				local v68 = tostring(v67)
				local v69 = v63.level
				local v70 = tostring(v69)
				local v71 = v63.weapon
				return ("shown=%s text=%s level=%s weapon=%s pos=%d,%d size=%d,%d"):format(v66, v68, v70, tostring(v71), v64.pos.X, v64.pos.Y, v64.size.X, v64.size.Y)
			end)
		end)
	end
	function v_u_16.destroy() -- name: destroy
		-- upvalues: (ref) v_u_55, (copy) v_u_26
		if v_u_55 then
			local function v72()
				-- upvalues: (ref) v_u_55
				v_u_55:Disconnect()
			end
			pcall(v72)
			v_u_55 = nil
		end
		v_u_26:Destroy()
	end
	return v_u_16
end
return v1