-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketBrowse

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("GuiService")
local v_u_470 = {
	["MEM"] = {
		["chip"] = "all",
		["sort"] = "cat",
		["showAll"] = false
	},
	["PRICE_GAP"] = 0.5,
	["PRICE_INFLIGHT"] = 2,
	["CHUNK"] = 40,
	["LISTED_EVERY"] = 30,
	["new"] = function(p_u_3, p_u_4) -- name: new
		-- upvalues: (copy) v_u_470, (copy) v_u_2, (copy) v_u_1
		local v_u_5 = p_u_3.ui
		local v_u_6 = p_u_3.theme
		local v_u_7 = p_u_3.C
		local v_u_8 = p_u_3.Data
		local v_u_9 = p_u_3.data
		local v_u_10 = p_u_3.h
		local v_u_11 = p_u_3.compact
		local v_u_12 = p_u_3.phone
		local v_u_13 = v_u_470.MEM
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = false
		local v_u_17 = {}
		local v18 = v_u_9:eligibility()
		local v_u_19 = v_u_9:catalog()
		local v20 = {}
		if p_u_3.cratesPage == true then
			local v21 = v18.OWN_TAB
			if type(v21) == "table" then
				v20 = v18.OWN_TAB
				v_u_19 = {}
				for _, v22 in v_u_19 do
					if v20[v22.cat] == true then
						continue
					end
					table.insert(v_u_19, v22)
				end
				if v20[v_u_13.chip] then
					v_u_13.chip = "all"
				end
			end
		end
		local v_u_23 = {
			"skin_crate_field",
			"skin_crate_tacet",
			"skin_crate_vault",
			"skin_crate_halloween",
			"skin_crate_tokyo"
		}
		local function v25()
			-- upvalues: (copy) p_u_3, (ref) v_u_23
			local v24 = p_u_3.mc.cctx.shared.CaseOdds.ORDER
			if type(v24) == "table" and #v24 > 0 then
				v_u_23 = v24
			end
		end
		pcall(v25)
		local v_u_26 = ""
		local v_u_27 = {}
		local v_u_28 = "pending"
		local v_u_29 = false
		local v_u_30 = false
		local v_u_31 = 0
		local v_u_32 = {}
		local v_u_33 = {}
		local v_u_34 = {}
		local v_u_35 = {}
		local v_u_36 = false
		local v_u_37
		if p_u_3.state == nil then
			v_u_37 = false
		else
			v_u_37 = v_u_8.chip(p_u_3.state, p_u_3.rules).blocked == true
		end
		local v38 = v_u_6.touch(v_u_11 and 40 or 34)
		local v_u_39 = v_u_11 and 84 or 108
		local v_u_40 = p_u_3.controlFrame("browse")
		local v_u_41 = v_u_6.touch(40)
		local v_u_42 = nil
		local function v_u_43() end
		local v_u_44 = nil
		local v_u_45 = nil
		local function v56(p46, p47, p48, p_u_49) -- name: toggleChip
			-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_41, (copy) v_u_6, (copy) v_u_13
			local v50 = v_u_5.new("TextButton", {
				["Name"] = "ShowAll",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["BackgroundColor3"] = v_u_7.raised,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Size"] = UDim2.fromOffset(p48, v_u_41)
			}, p46)
			v50.SelectionImageObject = v_u_5.selectionImage()
			local v_u_51 = v_u_5.stroke(v50, v_u_7.line)
			local v52 = v_u_5.new("Frame", {
				["Name"] = "Box",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 10, 0.5, 0),
				["Size"] = UDim2.fromOffset(16, 16)
			}, v50)
			v_u_5.stroke(v52, v_u_7.lineStrong)
			v_u_5.new("Frame", {
				["Name"] = "On",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_7.accent,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(8, 8)
			}, v52)
			local v53 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v50,
				["text"] = p47,
				["color"] = v_u_7.text2,
				["position"] = UDim2.fromOffset(34, 0),
				["size"] = UDim2.new(1, -42, 1, 0)
			})
			v50.Activated:Connect(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) p_u_49
				v_u_5.sound(v_u_6.sounds.click)
				p_u_49()
			end)
			v50.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_51, (ref) v_u_7
				v_u_51.Color = v_u_7.lineStrong
			end)
			v50.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_51, (ref) v_u_13, (ref) v_u_7
				local v54 = v_u_51
				local v55
				if v_u_13.showAll then
					v55 = v_u_7.accent
				else
					v55 = v_u_7.line
				end
				v54.Color = v55
			end)
			return v50, v_u_51, v53
		end
		local function v62(p57) -- name: mkInput
			-- upvalues: (copy) v_u_5, (copy) v_u_40, (ref) v_u_26, (copy) v_u_14
			local v59 = {
				["parent"] = nil,
				["name"] = "Search",
				["placeholder"] = "Search items",
				["size"] = nil,
				["maxLength"] = 40,
				["onChange"] = nil,
				["parent"] = v_u_40,
				["size"] = p57,
				["onChange"] = function(p58) -- name: onChange
					-- upvalues: (ref) v_u_26, (ref) v_u_14
					v_u_26 = p58
					v_u_14.queueArrange()
				end
			}
			local v60, v61 = v_u_5.input(v59)
			v60.Position = UDim2.fromOffset(0, 0)
			v60.AnchorPoint = Vector2.new(0, 0.5)
			v60.Position = UDim2.new(0, 0, 0.5, 0)
			return v60, v61
		end
		local v_u_63 = nil
		local v_u_64, v_u_65
		if v_u_11 then
			local v66 = v_u_6.touch(40)
			local v67
			v67, v_u_64 = v62(UDim2.new(1, -(v66 + 8), 0, v_u_41))
			v_u_5.iconButton({
				["parent"] = nil,
				["icon"] = "menu",
				["size"] = nil,
				["kind"] = "secondary",
				["name"] = "Overflow",
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_40,
				["size"] = v66,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_63
					if v_u_63 then
						v_u_63()
					end
				end
			})
			v_u_65 = v_u_23
		else
			local v68
			v68, v_u_64 = v62(UDim2.new(1, -426, 0, v_u_41))
			local v_u_69, v_u_70, v_u_71 = v56(v_u_40, "Show all items", 210, function()
				-- upvalues: (ref) v_u_45, (copy) v_u_13
				v_u_45(not v_u_13.showAll)
			end)
			v_u_69.Position = UDim2.new(1, 0, 0.5, 0)
			v_u_65 = v_u_23
			local v72 = {}
			v_u_43 = function()
				-- upvalues: (copy) v_u_13, (copy) v_u_69, (copy) v_u_70, (copy) v_u_7, (copy) v_u_71
				local v73 = v_u_13.showAll
				local v74 = v_u_69:FindFirstChild("Box")
				if v74 then
					v74 = v_u_69.Box:FindFirstChild("On")
				end
				if v74 then
					v74.Visible = v73
				end
				local v75 = v_u_70
				local v76
				if v73 then
					v76 = v_u_7.accent
				else
					v76 = v_u_7.line
				end
				v75.Color = v76
				local v77 = v_u_71
				local v78
				if v73 then
					v78 = v_u_7.text
				else
					v78 = v_u_7.text2
				end
				v77.TextColor3 = v78
			end
			for _, v79 in v_u_8.SORTS do
				local v80 = {
					["id"] = v79.id,
					["text"] = v79.text
				}
				table.insert(v72, v80)
			end
			local v81
			v81, v_u_42 = v_u_5.dropdown({
				["parent"] = nil,
				["name"] = "Sort",
				["label"] = "",
				["options"] = nil,
				["value"] = nil,
				["width"] = 200,
				["onChange"] = nil,
				["parent"] = v_u_40,
				["options"] = v72,
				["value"] = v_u_13.sort,
				["onChange"] = function(p82) -- name: onChange
					-- upvalues: (ref) v_u_44
					v_u_44(p82)
				end
			})
			v81.AnchorPoint = Vector2.new(1, 0.5)
			v81.Position = UDim2.new(1, -218, 0.5, 0)
			v81.Size = UDim2.fromOffset(200, v_u_41)
			for _, v83 in v81:GetChildren() do
				if v83:IsA("TextLabel") then
					v83.Visible = false
				else
					if v83.Name ~= "Box" or not v83:IsA("GuiObject") then
						continue
					end
					v83.Size = UDim2.new(1, 0, 0, v_u_6.touch(34))
					v83.AnchorPoint = Vector2.new(0, 0.5)
					v83.Position = UDim2.new(0, 0, 0.5, 0)
				end
			end
		end
		local v84 = v_u_5.list({
			["parent"] = nil,
			["name"] = "Chips",
			["horizontal"] = true,
			["gap"] = 6,
			["position"] = nil,
			["size"] = nil,
			["padding"] = nil,
			["parent"] = p_u_4,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.new(1, 0, 0, v38 + 6),
			["padding"] = {
				0,
				0,
				0,
				4
			}
		})
		local v_u_85 = {}
		local v86 = {
			{
				["id"] = "all",
				["label"] = "ALL"
			}
		}
		if p_u_3.rs ~= nil then
			table.insert(v86, {
				["id"] = "restock",
				["label"] = "RESTOCK"
			})
		end
		for _, v87 in v18.CATEGORIES do
			if v20[v87.id] == true then
				continue
			end
			local v88 = {
				["id"] = v87.id,
				["label"] = v87.label
			}
			table.insert(v86, v88)
		end
		for v89, v_u_90 in v86 do
			local v91 = v_u_5.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Selectable"] = true,
				["Name"] = "Chip_" .. v_u_90.id,
				["BackgroundColor3"] = v_u_7.raised,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromOffset(v_u_6.touch(24), v38),
				["LayoutOrder"] = v89
			}, v84)
			v91.SelectionImageObject = v_u_5.selectionImage()
			local v_u_92 = v_u_5.stroke(v91, v_u_7.line)
			v_u_5.pad(v91, {
				12,
				12,
				0,
				0
			})
			local v93 = {
				["btn"] = v91,
				["stroke"] = v_u_92,
				["lbl"] = v_u_5.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["parent"] = v91,
					["text"] = v_u_90.label,
					["color"] = v_u_7.text2,
					["size"] = UDim2.new(0, 0, 1, 0)
				})
			}
			v_u_85[v_u_90.id] = v93
			v91.Activated:Connect(function()
				-- upvalues: (copy) v_u_13, (copy) v_u_90, (copy) v_u_5, (copy) v_u_6, (copy) v_u_14
				if v_u_13.chip ~= v_u_90.id then
					v_u_5.sound(v_u_6.sounds.tab)
					v_u_13.chip = v_u_90.id
					v_u_14.paintChips()
					v_u_14.queueArrange(true)
				end
			end)
			v91.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_13, (copy) v_u_90, (copy) v_u_92, (copy) v_u_7
				if v_u_13.chip ~= v_u_90.id then
					v_u_92.Color = v_u_7.lineStrong
				end
			end)
			v91.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_92, (copy) v_u_13, (copy) v_u_90, (copy) v_u_7
				local v94 = v_u_92
				local v95
				if v_u_13.chip == v_u_90.id then
					v95 = v_u_7.accent
				else
					v95 = v_u_7.line
				end
				v94.Color = v95
			end)
		end
		function v_u_14.paintChips() -- name: paintChips
			-- upvalues: (copy) v_u_85, (copy) v_u_13, (copy) p_u_3, (copy) v_u_7
			for v96, v97 in v_u_85 do
				local v98 = v_u_13.chip == v96
				if v96 == "restock" then
					local v99 = v97.btn
					local v100
					if p_u_3.rs == nil then
						v100 = false
					else
						v100 = #p_u_3.rs.filterIds() > 0
					end
					v99.Visible = v100
				end
				local v101 = v97.btn
				local v102
				if v98 then
					v102 = v_u_7.accentDeep
				else
					v102 = v_u_7.raised
				end
				v101.BackgroundColor3 = v102
				v97.btn.BackgroundTransparency = v98 and 0.05 or 0.3
				local v103 = v97.stroke
				local v104
				if v98 then
					v104 = v_u_7.accent
				else
					v104 = v_u_7.line
				end
				v103.Color = v104
				local v105 = v97.lbl
				local v106
				if v98 then
					v106 = v_u_7.text
				else
					v106 = v_u_7.text2
				end
				v105.TextColor3 = v106
				v97.btn:SetAttribute("On", v98)
			end
		end
		local v_u_107 = v38 + 8
		local v_u_108 = v_u_6.touch(26)
		local v_u_109 = v_u_5.new("Frame", {
			["Name"] = "Notice",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_7.raised,
			["Position"] = UDim2.fromOffset(0, v38 + 8),
			["Size"] = UDim2.new(1, 0, 0, v_u_108)
		}, p_u_4)
		v_u_5.stroke(v_u_109, v_u_7.line)
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v_u_109,
			["text"] = v_u_8.TEXT.pricesDown,
			["color"] = v_u_7.text,
			["position"] = UDim2.fromOffset(10, 0),
			["size"] = UDim2.new(1, -140, 1, 0)
		})
		local v110 = v_u_5.new
		local v111 = {
			["Name"] = "Retry",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["BackgroundColor3"] = v_u_7.accentDeep,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -4, 0.5, 0)
		}
		local v112 = UDim2.fromOffset
		local v113 = v_u_108 - 4
		local v114 = v_u_6.touch
		v111.Size = v112(100, (math.max(v113, v114(22))))
		local v115 = v110("TextButton", v111, v_u_109)
		v115.SelectionImageObject = v_u_5.selectionImage()
		v_u_5.stroke(v115, v_u_7.accent)
		v_u_5.label({
			["parent"] = nil,
			["text"] = "Retry",
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["parent"] = v115,
			["color"] = v_u_7.text,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_116 = v_u_5.new("ScrollingFrame", {
			["Name"] = "Grid",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["ScrollBarImageTransparency"] = 0.2,
			["VerticalScrollBarInset"] = nil,
			["ElasticBehavior"] = nil,
			["TopImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
			["BottomImage"] = "rbxasset://textures/ui/Scroll/scroll-middle.png",
			["Position"] = UDim2.fromOffset(0, v_u_107),
			["Size"] = UDim2.new(1, 0, 1, -v_u_107),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ScrollBarThickness"] = v_u_6.scrollBar,
			["ScrollBarImageColor3"] = v_u_7.lineStrong,
			["VerticalScrollBarInset"] = Enum.ScrollBarInset.ScrollBar,
			["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
		}, p_u_4)
		local v_u_117 = 0
		local v_u_118 = v_u_5.new("Frame", {
			["Name"] = "CrateHint",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_7.raised,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 0, 1, 0),
			["Size"] = UDim2.new(1, -10, 0, v_u_6.touch(44) + 8)
		}, p_u_4)
		v_u_5.stroke(v_u_118, v_u_7.accent)
		local v_u_119 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v_u_118,
			["color"] = v_u_7.text,
			["position"] = UDim2.fromOffset(12, 0),
			["size"] = UDim2.new(1, -174, 1, 0)
		})
		v_u_10.button(v_u_118, "OPEN CRATES", "secondary", function()
			-- upvalues: (copy) p_u_3
			if p_u_3.nav then
				local v120 = p_u_3.nav.sub
				if type(v120) == "function" then
					p_u_3.nav.sub("crates")
				end
			end
		end, {
			["name"] = "OpenCrates",
			["height"] = 44,
			["width"] = 150,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 136,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -8, 0.5, 0)
		})
		local v_u_121 = nil
		local function v_u_124() -- name: updateHint
			-- upvalues: (copy) p_u_3, (copy) v_u_8, (ref) v_u_26, (ref) v_u_65, (ref) v_u_121, (copy) v_u_118, (copy) v_u_119, (ref) v_u_117, (copy) v_u_107, (copy) v_u_109, (copy) v_u_108, (copy) v_u_116, (copy) p_u_4
			local v122
			if p_u_3.cratesPage == true and v_u_8.crateTab(p_u_3.state) then
				v122 = v_u_8.crateSearchHint(v_u_26, v_u_65)
			else
				v122 = nil
			end
			if v122 ~= v_u_121 then
				v_u_121 = v122
				v_u_118.Visible = v122 ~= nil
				v_u_119.Text = v122 or ""
				v_u_117 = v122 == nil and 0 or v_u_118.Size.Y.Offset + 6
				local v123 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
				v_u_116.Position = UDim2.fromOffset(0, v123)
				v_u_116.Size = UDim2.new(1, 0, 1, -(v123 + v_u_117))
				p_u_4:SetAttribute("CrateHint", v122 or "")
			end
		end
		local v_u_125 = v_u_5.new("Frame", {
			["Name"] = "Message",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, v_u_107 + (v_u_11 and 20 or 70)),
			["Size"] = UDim2.new(0.8, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p_u_4)
		v_u_5.layout(v_u_125, "v", 12, "center")
		local v_u_126 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["align"] = "center",
			["order"] = 1,
			["parent"] = v_u_125,
			["color"] = v_u_7.text2
		})
		local v_u_127, _ = v_u_10.button(v_u_125, "Show all items", "secondary", function()
			-- upvalues: (ref) v_u_45
			v_u_45(true)
		end, {
			["order"] = 2,
			["name"] = "ShowAllBtn"
		})
		local v_u_128 = nil
		local function v129()
			-- upvalues: (ref) v_u_128, (copy) p_u_3
			v_u_128 = p_u_3.mc.cctx.lib.ItemIcons
		end
		pcall(v129)
		local v_u_130 = {}
		local v_u_131 = {}
		local v_u_132 = {}
		local v_u_133 = 2
		local v_u_134 = 200
		local v_u_135 = 1
		local v_u_136 = 0
		local v_u_137 = {}
		local v_u_138 = {}
		local v_u_139 = v_u_39 - 16
		local function v_u_166() -- name: makeCard
			-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_116, (copy) v_u_6, (copy) v_u_139, (copy) v_u_11, (ref) v_u_134, (copy) v_u_137, (copy) v_u_10, (copy) p_u_3, (copy) v_u_132
			local v140 = v_u_5.new("TextButton", {
				["Name"] = "Card",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = true,
				["Selectable"] = true,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_7.raised
			}, v_u_116)
			v140.SelectionImageObject = v_u_5.selectionImage()
			local v_u_141 = v_u_5.stroke(v140, v_u_7.line)
			local v142 = v_u_5.new("Frame", {
				["Name"] = "Tint",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_7.line,
				["BackgroundTransparency"] = v_u_6.alpha.rarity,
				["Size"] = UDim2.fromScale(1, 1)
			}, v140)
			v_u_5.new("UIGradient", {
				["Rotation"] = 0,
				["Transparency"] = nil,
				["Transparency"] = NumberSequence.new(0.2, 0.95)
			}, v142)
			local v143 = v_u_5.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v_u_7.line,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v140)
			local v144 = v_u_5.new("Frame", {
				["Name"] = "Icon",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Position"] = UDim2.fromOffset(10, 8),
				["Size"] = UDim2.fromOffset(v_u_139, v_u_139)
			}, v140)
			local v145 = v_u_139 + 10 + 10
			local v146 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = "",
				["style"] = "bodyStrong",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v140,
				["position"] = UDim2.fromOffset(v145, 8),
				["size"] = UDim2.new(1, -(v145 + 8), 0, 20)
			})
			local v147 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Price",
				["text"] = "",
				["style"] = "mono",
				["textSize"] = nil,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v140,
				["textSize"] = v_u_11 and 15 or 16,
				["color"] = v_u_7.accent,
				["position"] = UDim2.fromOffset(v145, 34),
				["size"] = UDim2.new(1, -(v145 + 8), 0, 22)
			})
			local v148 = v_u_5.label({
				["parent"] = nil,
				["name"] = "Count",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 3,
				["parent"] = v140,
				["color"] = v_u_7.text2,
				["position"] = UDim2.fromOffset(v145, 56),
				["size"] = UDim2.new(1, -(v145 + 8), 0, 16)
			})
			local v149 = v_u_5.new
			local v150 = {
				["Name"] = "Skel1",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.6,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_7.lineStrong,
				["Position"] = UDim2.fromOffset(v145, 38)
			}
			local v151 = UDim2.fromOffset
			local v152 = v_u_134 * 0.3
			local v153 = math.floor(v152)
			v150.Size = v151(math.max(40, v153), 14)
			local v154 = v149("Frame", v150, v140)
			local v155 = v_u_5.new
			local v156 = {
				["Name"] = "Skel2",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.7,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_7.lineStrong,
				["Position"] = UDim2.fromOffset(v145, 60)
			}
			local v157 = UDim2.fromOffset
			local v158 = v_u_134 * 0.18
			local v159 = math.floor(v158)
			v156.Size = v157(math.max(30, v159), 10)
			local v160 = v155("Frame", v156, v140)
			local v161 = v_u_137
			table.insert(v161, v154)
			local v162 = v_u_137
			table.insert(v162, v160)
			local v163 = v_u_10.pill(v140, "RESTOCK", Color3.fromHex("#3FD0C9"), {
				["name"] = "RsBand",
				["solid"] = true,
				["anchor"] = nil,
				["position"] = nil,
				["zindex"] = 4,
				["h"] = 18,
				["anchor"] = Vector2.new(1, 1),
				["position"] = UDim2.new(1, -8, 1, -8)
			})
			v163.Visible = false
			local v_u_164 = {
				["btn"] = nil,
				["stroke"] = nil,
				["tint"] = nil,
				["bar"] = nil,
				["iconBox"] = nil,
				["name"] = nil,
				["price"] = nil,
				["count"] = nil,
				["sk1"] = nil,
				["sk2"] = nil,
				["id"] = nil,
				["entry"] = nil,
				["state"] = "",
				["band"] = nil,
				["btn"] = v140,
				["stroke"] = v_u_141,
				["tint"] = v142,
				["bar"] = v143,
				["iconBox"] = v144,
				["name"] = v146,
				["price"] = v147,
				["count"] = v148,
				["sk1"] = v154,
				["sk2"] = v160,
				["band"] = v163
			}
			v140.Activated:Connect(function()
				-- upvalues: (copy) v_u_164, (ref) v_u_5, (ref) v_u_6, (ref) p_u_3
				if v_u_164.id then
					v_u_5.sound(v_u_6.sounds.click)
					p_u_3.nav.openItem(v_u_164.id)
				end
			end)
			v140.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_141, (ref) v_u_7
				v_u_141.Color = v_u_7.accent
			end)
			v140.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_141, (ref) v_u_7
				v_u_141.Color = v_u_7.line
			end)
			v140.SelectionGained:Connect(function()
				-- upvalues: (copy) v_u_141, (ref) v_u_7
				v_u_141.Color = v_u_7.accent
			end)
			v140.SelectionLost:Connect(function()
				-- upvalues: (copy) v_u_141, (ref) v_u_7
				v_u_141.Color = v_u_7.line
			end)
			local v165 = v_u_132
			table.insert(v165, v_u_164)
			return v_u_164
		end
		local function v_u_173(p167) -- name: mountIcon
			-- upvalues: (ref) v_u_128
			if not p167.vp and (p167.id and v_u_128) then
				local v168 = v_u_128.get
				local v169 = p167.id
				local v170 = {
					["parent"] = nil,
					["size"] = nil,
					["position"] = nil,
					["zindex"] = 3,
					["parent"] = p167.iconBox,
					["size"] = UDim2.fromScale(1, 1),
					["position"] = UDim2.fromOffset(0, 0)
				}
				local v171, v172 = pcall(v168, v169, false, v170)
				if v171 and typeof(v172) == "Instance" then
					p167.vp = v172
				end
			end
		end
		local function v_u_200(p174, p175) -- name: paintPrice
			-- upvalues: (ref) v_u_28, (ref) v_u_33, (copy) v_u_8, (ref) v_u_32, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (copy) v_u_7, (copy) v_u_5, (copy) p_u_3
			local v176 = p174.id
			if v176 then
				if v_u_28 == "failed" and not v_u_33[v176] then
					local v177 = p174.price
					local v178 = p174.count
					v177.Text = ""
					v178.Text = ""
					local v179 = p174.sk1
					local v180 = p174.sk2
					v179.Visible = false
					v180.Visible = false
					p174.state = "off"
				else
					local v181 = v_u_8.slotText
					local v182 = v_u_32[v176]
					if not v182 then
						if v_u_28 == "ready" then
							v182 = v_u_27[v176]
						else
							v182 = nil
						end
					end
					local v183 = not v_u_33[v176] and (v_u_28 == "ready" and (v_u_27[v176] == nil and not v_u_29))
					if v183 then
						v183 = not v_u_30
					end
					local v184, v185, v186 = v181(v182, v183)
					local v187 = p174.state
					p174.state = v186
					p174.sk1.Visible = v186 == "skeleton"
					p174.sk2.Visible = v186 == "skeleton"
					p174.price.Text = v184 or ""
					p174.count.Text = v185 or ""
					local v188 = p174.price
					local v189
					if v186 == "price" then
						v189 = v_u_7.accent
					else
						v189 = v_u_7.muted
					end
					v188.TextColor3 = v189
					p174.btn:SetAttribute("Slot", v186)
					if p175 and (v187 == "skeleton" and v186 ~= "skeleton") then
						p174.price.TextTransparency = 1
						p174.count.TextTransparency = 1
						v_u_5.tween(p174.price, {
							["TextTransparency"] = 0
						}, "normal")
						v_u_5.tween(p174.count, {
							["TextTransparency"] = 0
						}, "normal")
					else
						p174.price.TextTransparency = 0
						p174.count.TextTransparency = 0
					end
					local v190
					if p_u_3.rs == nil then
						v190 = nil
					else
						v190 = p_u_3.rs.tile(v176)
					end
					p174.band.Visible = v190 ~= nil
					if v190 == nil then
						p174.btn:SetAttribute("Restock", nil)
					else
						local v191 = p174.band:FindFirstChild("Text")
						local v192
						if v190.live then
							v192 = v_u_8.RS_WORD
						else
							v192 = v_u_8.RS_WORD .. " " .. v190.word
						end
						if v191 ~= nil and v191:GetAttribute("RsText") ~= v192 then
							v191:SetAttribute("RsText", v192)
							local v193 = v_u_5.setText
							pcall(v193, v191, v192)
						end
						p174.btn:SetAttribute("Restock", v190.word)
						if v190.live and v190.from ~= nil then
							local v194 = p174.sk1
							local v195 = p174.sk2
							v194.Visible = false
							v195.Visible = false
							p174.price.Text = "from " .. v_u_8.unitMoney(v190.from)
							p174.price.TextColor3 = Color3.fromHex("#3FD0C9")
							p174.price.TextTransparency = 0
							p174.btn:SetAttribute("Slot", "restock")
							return
						end
					end
				end
			else
				local v196 = p174.price
				local v197 = p174.count
				v196.Text = ""
				v197.Text = ""
				local v198 = p174.sk1
				local v199 = p174.sk2
				v198.Visible = true
				v199.Visible = true
				p174.band.Visible = false
				return
			end
		end
		local function v_u_211(p201, p202, p203) -- name: bindCard
			-- upvalues: (ref) v_u_133, (ref) v_u_134, (copy) v_u_39, (ref) v_u_128, (copy) v_u_6, (copy) v_u_7, (copy) v_u_138, (copy) v_u_200
			local v204 = (p203 - 1) % v_u_133
			local v205 = (p203 - 1) // v_u_133
			p201.btn.Position = UDim2.fromOffset(v204 * (v_u_134 + 8) + 2, v205 * (v_u_39 + 8) + 2)
			p201.btn.Size = UDim2.fromOffset(v_u_134, v_u_39)
			p201.btn.Visible = true
			if p201.vp and v_u_128 then
				local v206 = v_u_128.release
				local v207 = p201.vp
				pcall(v206, v207)
			end
			p201.vp = nil
			if p202 then
				local v208 = p202.id
				p201.entry = p202
				p201.id = v208
				p201.name.Text = p202.name
				local v209 = v_u_6.rarityColor(p202.rarity)
				p201.bar.BackgroundColor3 = v209
				p201.tint.BackgroundColor3 = v209
				p201.stroke.Color = v_u_7.line
				p201.btn.Selectable = true
				p201.btn:SetAttribute("ItemId", p202.id)
				local v210 = v_u_138
				table.insert(v210, p201)
			else
				p201.entry = nil
				p201.id = nil
				p201.name.Text = ""
				p201.bar.BackgroundColor3 = v_u_7.line
				p201.tint.BackgroundColor3 = v_u_7.line
				p201.btn.Selectable = false
				p201.btn:SetAttribute("ItemId", nil)
			end
			p201.state = "skeleton"
			v_u_200(p201, false)
		end
		local v_u_212 = {}
		local v_u_213 = v_u_8.pump(v_u_470.PRICE_GAP, v_u_470.PRICE_INFLIGHT, os.clock, task.wait)
		local v_u_214 = 1
		local v_u_215 = false
		local v_u_216 = nil
		local function v_u_224() -- name: metrics
			-- upvalues: (ref) v_u_214, (copy) v_u_10, (copy) v_u_116, (copy) p_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_12, (ref) v_u_133, (ref) v_u_134
			v_u_214 = v_u_10.scale(v_u_116)
			local v217 = v_u_10.designSize(v_u_116, true).X
			if v217 < 80 then
				v217 = p_u_3.theme.safeRefSize().X - 120
			end
			local v218 = v_u_6.viewport()
			local v219 = v_u_8.columnsFor(v218.X, v_u_12)
			local v220 = (v217 - 2 - 10 - (v219 - 1) * 8) / v219
			local v221 = math.floor(v220)
			local v222 = math.max(v221, 120)
			local v223 = v219 ~= v_u_133 and true or v222 ~= v_u_134
			v_u_133 = v219
			v_u_134 = v222
			return v223
		end
		local function v_u_243() -- name: update
			-- upvalues: (ref) v_u_215, (ref) v_u_15, (copy) v_u_39, (copy) v_u_10, (copy) v_u_116, (ref) v_u_214, (ref) v_u_135, (ref) v_u_133, (ref) v_u_136, (ref) v_u_212, (copy) v_u_131, (ref) v_u_2, (ref) v_u_128, (copy) v_u_130, (copy) v_u_166, (copy) v_u_211, (ref) v_u_216
			v_u_215 = false
			if v_u_15 then
				local v225 = v_u_39 + 8
				local v226 = v_u_10.designSize(v_u_116, true).Y
				local v227 = v_u_116.CanvasPosition.Y / v_u_214
				local v228 = (v227 - 2) / v225
				local v229 = math.floor(v228) - 1
				local v230 = math.max(0, v229)
				local v231 = (v227 + v226 - 2) / v225
				local v232 = math.floor(v231) + 1
				v_u_135 = v230 * v_u_133 + 1
				local v233 = #v_u_212
				local v234 = (v232 + 1) * v_u_133
				v_u_136 = math.min(v233, v234)
				for v235 in v_u_131 do
					if v235 >= v_u_135 and v_u_136 >= v235 then
						continue
					end
					local v236 = v_u_131[v235]
					if v236 and v_u_2.SelectedObject == v236.btn then
						continue
					end
					local v237 = v_u_131[v235]
					if not v237 then
						continue
					end
					v_u_131[v235] = nil
					if v237.vp and v_u_128 then
						local v238 = v_u_128.release
						local v239 = v237.vp
						pcall(v238, v239)
					end
					v237.vp = nil
					v237.btn.Visible = false
					v237.id = nil
					v237.entry = nil
					local v240 = v_u_130
					table.insert(v240, v237)
				end
				for v241 = v_u_135, v_u_136 do
					if v_u_131[v241] then
						continue
					end
					local v242 = table.remove(v_u_130) or v_u_166()
					v_u_131[v241] = v242
					v_u_211(v242, v_u_212[v241] or nil, v241)
				end
				v_u_216()
			end
		end
		local function v244() -- name: schedule
			-- upvalues: (ref) v_u_215, (copy) v_u_243
			if not v_u_215 then
				v_u_215 = true
				task.defer(v_u_243)
			end
		end
		local function v_u_257() -- name: rebuildCards
			-- upvalues: (copy) v_u_224, (copy) v_u_131, (ref) v_u_128, (copy) v_u_130, (copy) v_u_132, (ref) v_u_134, (copy) v_u_39, (ref) v_u_212, (ref) v_u_133, (copy) v_u_116, (copy) v_u_243
			v_u_224()
			for v245 in v_u_131 do
				local v246 = v_u_131[v245]
				if not v246 then
					continue
				end
				v_u_131[v245] = nil
				if v246.vp and v_u_128 then
					local v247 = v_u_128.release
					local v248 = v246.vp
					pcall(v247, v248)
				end
				v246.vp = nil
				v246.btn.Visible = false
				v246.id = nil
				v246.entry = nil
				local v249 = v_u_130
				table.insert(v249, v246)
			end
			for _, v250 in v_u_132 do
				v250.btn.Size = UDim2.fromOffset(v_u_134, v_u_39)
				local v251 = v250.sk1
				local v252 = UDim2.fromOffset
				local v253 = v_u_134 * 0.3
				local v254 = math.floor(v253)
				v251.Size = v252(math.max(40, v254), 14)
			end
			local v255 = #v_u_212 / v_u_133
			local v256 = math.ceil(v255)
			v_u_116.CanvasSize = UDim2.fromOffset(0, v256 * (v_u_39 + 8) + 2 + 6)
			v_u_243()
		end
		local v_u_258 = {}
		local v_u_259 = 0
		local v_u_260 = false
		local function v_u_264(p261) -- name: repaintIds
			-- upvalues: (copy) v_u_131, (copy) v_u_200
			for _, v262 in p261 do
				for _, v263 in v_u_131 do
					if v263.id ~= v262 then
						continue
					end
					v_u_200(v263, true)
				end
			end
		end
		local function v_u_283(p265) -- name: windowIds
			-- upvalues: (ref) v_u_28, (copy) v_u_39, (copy) v_u_10, (copy) v_u_116, (ref) v_u_214, (ref) v_u_133, (ref) v_u_212, (ref) v_u_33, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30
			local v266 = {}
			if v_u_28 == "failed" then
				return v266
			end
			local v267 = v_u_39 + 8
			local v268 = v_u_10.designSize(v_u_116, true).Y
			local v269 = v_u_116.CanvasPosition.Y / v_u_214
			local v270 = (v269 - 2) / v267
			local v271 = math.floor(v270) - p265
			local v272 = math.max(0, v271)
			local v273 = (v269 + v268 - 2) / v267
			local v274 = math.floor(v273) + p265
			local v275 = v272 * v_u_133 + 1
			local v276 = #v_u_212
			local v277 = (v274 + 1) * v_u_133
			for v278 = v275, math.min(v276, v277) do
				local v279 = v_u_212[v278]
				if not v279 or v279 == false then
					continue
				end
				local v280 = v279.id
				local v281 = not v_u_33[v280] and (v_u_28 == "ready" and (v_u_27[v280] == nil and not v_u_29))
				if v281 then
					v281 = not v_u_30
				end
				if v281 then
					continue
				end
				local v282 = v279.id
				table.insert(v266, v282)
			end
			return v266
		end
		local function v_u_300(p284, p285) -- name: runChunk
			-- upvalues: (ref) v_u_15, (copy) v_u_258, (ref) v_u_33, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (copy) v_u_34, (copy) v_u_9, (ref) v_u_32, (copy) v_u_264, (copy) v_u_8, (ref) v_u_216, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117
			if v_u_15 then
				local v_u_286 = {}
				for _, v287 in p284 do
					if not v_u_258[v287] then
						continue
					end
					local v288 = not v_u_33[v287] and (v_u_28 == "ready" and (v_u_27[v287] == nil and not v_u_29))
					if v288 then
						v288 = not v_u_30
					end
					if v288 then
						continue
					end
					table.insert(v_u_286, v287)
				end
				if #v_u_286 == 0 then
					for _, v289 in p284 do
						v_u_34[v289] = nil
					end
					return
				else
					local v290 = v_u_9:prices(v_u_286)
					if v_u_15 then
						if v290.ok then
							local v291 = v290.stale == true
							local v292 = {}
							for _, v293 in v_u_286 do
								local v294 = v290.prices
								local v295
								if type(v294) == "table" then
									v295 = v290.prices[v293]
								else
									v295 = nil
								end
								if v295 == nil then
									if not v291 then
										v_u_32[v293] = nil
										v_u_33[v293] = true
									end
								else
									v_u_32[v293] = v295
									v_u_33[v293] = true
								end
								if not v_u_33[v293] then
									continue
								end
								v_u_34[v293] = nil
								table.insert(v292, v293)
							end
							v_u_264(v292)
							if v291 then
								local v296 = v_u_8.retryDelay(v290.retryIn, p285, 1)
								if p285 < v_u_8.RETRY_MAX then
									task.delay(v296, function()
										-- upvalues: (copy) v_u_286, (ref) v_u_33, (ref) v_u_34, (ref) v_u_15, (ref) v_u_216
										for _, v297 in v_u_286 do
											if v_u_33[v297] then
												continue
											end
											v_u_34[v297] = nil
										end
										if v_u_15 then
											v_u_216()
										end
									end)
									return
								end
							end
						else
							for _, v298 in v_u_286 do
								v_u_34[v298] = nil
							end
							if v290.code == "RATE" or (v290.code == "MUTED" or v290.code == "BUSY") then
								if p285 < v_u_8.RETRY_MAX then
									task.delay(v_u_8.retryDelay(v290.retryIn or 1.2, p285, 1), function()
										-- upvalues: (ref) v_u_15, (ref) v_u_216
										if v_u_15 then
											v_u_216()
										end
									end)
								else
									v_u_260 = true
								end
							end
							v_u_260 = true
							v_u_109.Visible = true
							local v299 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
							v_u_116.Position = UDim2.fromOffset(0, v299)
							v_u_116.Size = UDim2.new(1, 0, 1, -(v299 + v_u_117))
						end
					end
				end
			else
				return
			end
		end
		v_u_216 = function()
			-- upvalues: (ref) v_u_15, (ref) v_u_28, (ref) v_u_36, (copy) v_u_283, (copy) v_u_258, (ref) v_u_259, (copy) v_u_213, (copy) v_u_300, (copy) v_u_34, (ref) v_u_470
			if v_u_15 and (v_u_28 ~= "pending" and not v_u_36) then
				local v301 = v_u_283(1)
				if #v301 ~= 0 then
					table.clear(v_u_258)
					for _, v302 in v_u_283(2) do
						v_u_258[v302] = true
					end
					local v_u_303 = {}
					local function v305() -- name: flush
						-- upvalues: (ref) v_u_303, (ref) v_u_259, (ref) v_u_213, (ref) v_u_300
						if #v_u_303 > 0 then
							local v_u_304 = v_u_303
							v_u_303 = {}
							v_u_259 = v_u_259 + 1
							v_u_213.push(function()
								-- upvalues: (ref) v_u_300, (copy) v_u_304
								v_u_300(v_u_304, 1)
							end)
						end
					end
					local v306 = v_u_303
					for _, v307 in v301 do
						if v_u_34[v307] then
							continue
						end
						v_u_34[v307] = true
						v_u_258[v307] = true
						table.insert(v306, v307)
						if #v306 < v_u_470.CHUNK then
							continue
						end
						v305()
					end
					v305()
				end
			else
				return
			end
		end
		function v_u_14.arrange(p308) -- name: arrange
			-- upvalues: (ref) v_u_15, (ref) v_u_26, (ref) v_u_36, (copy) v_u_13, (copy) p_u_3, (copy) v_u_14, (copy) v_u_124, (ref) v_u_37, (ref) v_u_35, (ref) v_u_212, (copy) v_u_8, (copy) v_u_126, (copy) v_u_125, (copy) v_u_127, (ref) v_u_28, (ref) v_u_133, (ref) v_u_19, (ref) v_u_27, (copy) p_u_4, (copy) v_u_116, (copy) v_u_257
			if v_u_15 then
				local v309 = string.match(v_u_26, "%S") ~= nil
				v_u_36 = false
				if v_u_13.chip == "restock" and (p_u_3.rs == nil or #p_u_3.rs.filterIds() == 0) then
					v_u_13.chip = "all"
					v_u_14.paintChips()
				end
				v_u_124()
				if v_u_37 then
					v_u_35 = {}
					v_u_212 = {}
					local v310 = v_u_8.TEXT.blockedAccount
					if v310 then
						v_u_126.Text = v310
						v_u_125.Visible = true
						v_u_127.Visible = false
						v_u_127.Selectable = false
					else
						v_u_125.Visible = false
					end
				elseif v_u_28 == "pending" and not v309 then
					v_u_36 = true
					v_u_35 = {}
					v_u_212 = {}
					local v311 = v_u_133 * 3
					for v312 = 1, math.max(12, v311) do
						v_u_212[v312] = false
					end
					v_u_125.Visible = false
				else
					local v313 = v_u_28 == "failed"
					local v314 = p_u_3.rs == nil and {} or p_u_3.rs.filterIds()
					if v_u_13.chip == "restock" then
						local v315 = {}
						for _, v316 in v314 do
							v315[v316] = true
						end
						local v317 = {}
						for _, v318 in v_u_19 do
							if not v315[v318.id] then
								continue
							end
							table.insert(v317, v318)
						end
						v_u_35 = v_u_8.arrange(v317, {
							["chip"] = "all",
							["query"] = nil,
							["showAll"] = true,
							["sort"] = nil,
							["listed"] = nil,
							["query"] = v_u_26,
							["sort"] = v_u_13.sort,
							["listed"] = v313 and {} or v_u_27
						})
					else
						local v319 = v_u_27
						if #v314 > 0 and not v313 then
							v319 = table.clone(v_u_27)
							for _, v320 in v314 do
								local v321 = v319[v320]
								if type(v321) == "table" and (v321.c or 0) > 0 then
									continue
								end
								local v322 = {
									["c"] = 1,
									["m"] = nil
								}
								local v323
								if type(v321) == "table" then
									v323 = v321.m
								else
									v323 = nil
								end
								v322.m = v323
								v319[v320] = v322
							end
						end
						v_u_35 = v_u_8.arrange(v_u_19, {
							["chip"] = v_u_13.chip,
							["query"] = v_u_26,
							["showAll"] = v_u_13.showAll or v313,
							["sort"] = v_u_13.sort,
							["listed"] = v313 and {} or v319
						})
					end
					v_u_212 = v_u_35
					if #v_u_35 == 0 then
						if v309 then
							local v324 = ("Nothing found for \'%s\'. Try another word."):format(v_u_26)
							if v324 then
								v_u_126.Text = v324
								v_u_125.Visible = true
								v_u_127.Visible = false
								v_u_127.Selectable = false
							else
								v_u_125.Visible = false
							end
						elseif v_u_28 == "ready" and not v_u_13.showAll then
							local v325 = v_u_8.TEXT.nobody
							if v325 then
								v_u_126.Text = v325
								v_u_125.Visible = true
								v_u_127.Visible = true
								v_u_127.Selectable = true
							else
								v_u_125.Visible = false
							end
						else
							v_u_126.Text = "Nothing to show here."
							v_u_125.Visible = true
							v_u_127.Visible = false
							v_u_127.Selectable = false
						end
					else
						v_u_125.Visible = false
					end
				end
				p_u_4:SetAttribute("Shown", #v_u_212)
				p_u_4:SetAttribute("Cols", v_u_133)
				p_u_4:SetAttribute("ListedState", v_u_28)
				if p308 ~= false then
					v_u_116.CanvasPosition = Vector2.zero
				end
				v_u_257()
			end
		end
		local v328 = {
			["Disconnect"] = p_u_3.onState(function(p326)
				-- upvalues: (copy) v_u_8, (copy) p_u_3, (ref) v_u_37, (copy) v_u_14, (copy) v_u_124
				local v327 = v_u_8.chip(p326, p_u_3.rules).blocked == true
				if v327 ~= v_u_37 then
					v_u_37 = v327
					v_u_14.arrange(false)
				end
				v_u_124()
			end)
		}
		table.insert(v_u_17, v328)
		local v_u_329 = 0
		function v_u_14.queueArrange(p330) -- name: queueArrange
			-- upvalues: (ref) v_u_329, (copy) v_u_14, (ref) v_u_15
			v_u_329 = v_u_329 + 1
			local v_u_331 = v_u_329
			if p330 then
				v_u_14.arrange(true)
			else
				task.delay(0.12, function()
					-- upvalues: (copy) v_u_331, (ref) v_u_329, (ref) v_u_15, (ref) v_u_14
					if v_u_331 == v_u_329 and v_u_15 then
						v_u_14.arrange(true)
					end
				end)
			end
		end
		local function v_u_333(p332)
			-- upvalues: (copy) v_u_13, (copy) v_u_14, (ref) v_u_42
			if v_u_13.sort ~= p332 then
				v_u_13.sort = p332
				v_u_14.queueArrange(true)
			end
			if v_u_42 then
				v_u_42.set(p332)
			end
		end
		local function v_u_335(p334)
			-- upvalues: (copy) v_u_13, (ref) v_u_43, (copy) v_u_14
			if v_u_13.showAll ~= p334 then
				v_u_13.showAll = p334
				v_u_43()
				v_u_14.queueArrange(true)
			end
		end
		local v_u_336 = false
		local function v_u_346(p_u_337) -- name: loadListed
			-- upvalues: (ref) v_u_336, (ref) v_u_15, (copy) v_u_9, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (copy) v_u_14, (copy) v_u_131, (copy) v_u_200, (ref) v_u_31, (copy) v_u_8, (copy) v_u_346
			if not v_u_336 and v_u_15 then
				v_u_336 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (copy) p_u_337, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
					local v338 = v_u_9:listed(p_u_337 and 0 or 8)
					v_u_336 = false
					if v_u_15 then
						if v338.ok then
							local v339 = v_u_28 ~= "ready"
							local v340 = 0
							for _ in v_u_27 do
								v340 = v340 + 1
							end
							local v341 = v338.prices
							v_u_27 = type(v341) ~= "table" and {} or v338.prices
							v_u_29 = v338.stale == true
							v_u_30 = v338.cut == true
							v_u_28 = "ready"
							v_u_260 = false
							v_u_109.Visible = false
							local v342 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
							v_u_116.Position = UDim2.fromOffset(0, v342)
							v_u_116.Size = UDim2.new(1, 0, 1, -(v342 + v_u_117))
							local v343 = 0
							for _ in v_u_27 do
								v343 = v343 + 1
							end
							if v339 or v_u_116.CanvasPosition.Y < 2 and v340 ~= v343 then
								v_u_14.arrange(v339)
							else
								for _, v344 in v_u_131 do
									v_u_200(v344, true)
								end
							end
							if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
								v_u_31 = v_u_31 + 1
								task.delay(v_u_8.retryDelay(v338.retryIn, v_u_31, 1), function()
									-- upvalues: (ref) v_u_15, (ref) v_u_346
									if v_u_15 then
										v_u_346(true)
									end
								end)
							else
								v_u_31 = 0
							end
						else
							if v338.code ~= "RATE" and v338.code ~= "MUTED" then
								if v_u_28 ~= "ready" then
									v_u_28 = "failed"
									v_u_14.arrange(true)
								end
								v_u_109.Visible = true
								local v345 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v345)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v345 + v_u_117))
							end
							return
						end
					else
						return
					end
				end)
			end
		end
		v115.Activated:Connect(function()
			-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (ref) v_u_28, (ref) v_u_31, (ref) v_u_260, (copy) v_u_34, (copy) v_u_14, (ref) v_u_336, (ref) v_u_15, (copy) v_u_9, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (copy) v_u_131, (copy) v_u_200, (copy) v_u_8, (copy) v_u_346
			v_u_5.sound(v_u_6.sounds.click)
			v_u_109.Visible = false
			local v347 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
			v_u_116.Position = UDim2.fromOffset(0, v347)
			v_u_116.Size = UDim2.new(1, 0, 1, -(v347 + v_u_117))
			v_u_28 = v_u_28 == "failed" and "pending" or v_u_28
			v_u_31 = 0
			v_u_260 = false
			table.clear(v_u_34)
			if v_u_28 == "pending" then
				v_u_14.arrange(false)
			end
			if not v_u_336 then
				if not v_u_15 then
					return
				end
				v_u_336 = true
				local v_u_348 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_348, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
					local v349 = v_u_9:listed(v_u_348 and 0 or 8)
					v_u_336 = false
					if v_u_15 then
						if v349.ok then
							local v350 = v_u_28 ~= "ready"
							local v351 = 0
							for _ in v_u_27 do
								v351 = v351 + 1
							end
							local v352 = v349.prices
							v_u_27 = type(v352) ~= "table" and {} or v349.prices
							v_u_29 = v349.stale == true
							v_u_30 = v349.cut == true
							v_u_28 = "ready"
							v_u_260 = false
							v_u_109.Visible = false
							local v353 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
							v_u_116.Position = UDim2.fromOffset(0, v353)
							v_u_116.Size = UDim2.new(1, 0, 1, -(v353 + v_u_117))
							local v354 = 0
							for _ in v_u_27 do
								v354 = v354 + 1
							end
							if v350 or v_u_116.CanvasPosition.Y < 2 and v351 ~= v354 then
								v_u_14.arrange(v350)
							else
								for _, v355 in v_u_131 do
									v_u_200(v355, true)
								end
							end
							if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
								v_u_31 = v_u_31 + 1
								task.delay(v_u_8.retryDelay(v349.retryIn, v_u_31, 1), function()
									-- upvalues: (ref) v_u_15, (ref) v_u_346
									if v_u_15 then
										v_u_346(true)
									end
								end)
							else
								v_u_31 = 0
							end
						else
							if v349.code ~= "RATE" and v349.code ~= "MUTED" then
								if v_u_28 ~= "ready" then
									v_u_28 = "failed"
									v_u_14.arrange(true)
								end
								v_u_109.Visible = true
								local v356 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v356)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v356 + v_u_117))
							end
							return
						end
					else
						return
					end
				end)
			end
		end)
		local function _()
			-- upvalues: (copy) v_u_5, (copy) v_u_13, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6, (ref) v_u_333, (ref) v_u_335
			local v377 = {
				["title"] = "View",
				["width"] = 420,
				["build"] = nil,
				["buttons"] = nil,
				["build"] = function(p357) -- name: build
					-- upvalues: (ref) v_u_13, (ref) v_u_7, (ref) v_u_5, (ref) v_u_8, (ref) v_u_6, (ref) v_u_333, (ref) v_u_335
					local v_u_358 = {}
					local function v_u_363() -- name: paintRows
						-- upvalues: (copy) v_u_358, (ref) v_u_13, (ref) v_u_7
						for v359, v360 in v_u_358 do
							v360.chk.Visible = v359 == v_u_13.sort
							local v361 = v360.lbl
							local v362
							if v359 == v_u_13.sort then
								v362 = v_u_7.text
							else
								v362 = v_u_7.text2
							end
							v361.TextColor3 = v362
						end
					end
					v_u_5.label({
						["parent"] = nil,
						["text"] = "Sort",
						["style"] = "caps",
						["color"] = nil,
						["order"] = 1,
						["parent"] = p357,
						["color"] = v_u_7.text2
					})
					for v364, v_u_365 in v_u_8.SORTS do
						local v366 = v_u_5.new("TextButton", {
							["Name"] = nil,
							["Text"] = "",
							["AutoButtonColor"] = false,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.2,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Selectable"] = true,
							["Name"] = "Sort_" .. v_u_365.id,
							["BackgroundColor3"] = v_u_7.raised,
							["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(36)),
							["LayoutOrder"] = 1 + v364
						}, p357)
						v366.SelectionImageObject = v_u_5.selectionImage()
						v_u_5.stroke(v366, v_u_7.line)
						local v367 = v_u_5.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v366,
							["text"] = v_u_365.text,
							["color"] = v_u_7.text2,
							["position"] = UDim2.fromOffset(12, 0),
							["size"] = UDim2.new(1, -44, 1, 0)
						})
						local v368 = {
							["chk"] = v_u_5.icon("check", {
								["parent"] = nil,
								["size"] = 14,
								["color"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["parent"] = v366,
								["color"] = v_u_7.accent,
								["position"] = UDim2.new(1, -12, 0.5, 0),
								["anchor"] = Vector2.new(1, 0.5)
							}),
							["lbl"] = v367
						}
						v_u_358[v_u_365.id] = v368
						v366.Activated:Connect(function()
							-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_333, (copy) v_u_365, (copy) v_u_363
							v_u_5.sound(v_u_6.sounds.click)
							v_u_333(v_u_365.id)
							v_u_363()
						end)
					end
					local v369 = v_u_5.new("TextButton", {
						["Name"] = "ShowAllRow",
						["Text"] = "",
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = 20,
						["Selectable"] = true,
						["BackgroundColor3"] = v_u_7.raised,
						["Size"] = UDim2.new(1, 0, 0, v_u_6.touch(40))
					}, p357)
					v369.SelectionImageObject = v_u_5.selectionImage()
					local v370 = v_u_5.stroke
					local v371
					if v_u_13.showAll then
						v371 = v_u_7.accent
					else
						v371 = v_u_7.line
					end
					local v_u_372 = v370(v369, v371)
					local v373 = v_u_5.new("Frame", {
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, 12, 0.5, 0),
						["Size"] = UDim2.fromOffset(16, 16)
					}, v369)
					v_u_5.stroke(v373, v_u_7.lineStrong)
					local v_u_374 = v_u_5.new("Frame", {
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Visible"] = nil,
						["BackgroundColor3"] = v_u_7.accent,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Size"] = UDim2.fromOffset(8, 8),
						["Visible"] = v_u_13.showAll
					}, v373)
					v_u_5.label({
						["parent"] = nil,
						["text"] = "Show all items",
						["style"] = "caps",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v369,
						["color"] = v_u_7.text,
						["position"] = UDim2.fromOffset(40, 0),
						["size"] = UDim2.new(1, -52, 1, 0)
					})
					v369.Activated:Connect(function()
						-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_335, (ref) v_u_13, (copy) v_u_374, (copy) v_u_372, (ref) v_u_7
						v_u_5.sound(v_u_6.sounds.click)
						v_u_335(not v_u_13.showAll)
						v_u_374.Visible = v_u_13.showAll
						local v375 = v_u_372
						local v376
						if v_u_13.showAll then
							v376 = v_u_7.accent
						else
							v376 = v_u_7.line
						end
						v375.Color = v376
					end)
					v_u_363()
				end,
				["buttons"] = {
					{
						["text"] = "Done",
						["kind"] = "primary"
					}
				}
			}
			v_u_5.modal(v377)
		end
		local v_u_378 = 0
		local v379 = v_u_1.Heartbeat
		local function v386(p380)
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) v_u_138, (copy) v_u_173, (ref) v_u_378, (copy) v_u_137
			if v_u_15 and v_u_16 then
				local v381 = 0
				while #v_u_138 > 0 and v381 < 3 do
					local v382 = table.remove(v_u_138, 1)
					if not (v382.id and v382.btn.Visible) then
						continue
					end
					v_u_173(v382)
					v381 = v381 + 1
				end
				v_u_378 = v_u_378 + p380
				local v383 = v_u_378 * 4
				local v384 = math.sin(v383) * 0.14 + 0.62
				for _, v385 in v_u_137 do
					if not v385.Visible then
						continue
					end
					v385.BackgroundTransparency = v384
				end
			end
		end
		table.insert(v_u_17, v379:Connect(v386))
		local v387 = v_u_116:GetPropertyChangedSignal("CanvasPosition")
		table.insert(v_u_17, v387:Connect(v244))
		local v388 = v_u_116:GetPropertyChangedSignal("AbsoluteWindowSize")
		local function v389()
			-- upvalues: (copy) v_u_224, (copy) v_u_257, (ref) v_u_215, (copy) v_u_243
			if v_u_224() then
				v_u_257()
				return
			elseif not v_u_215 then
				v_u_215 = true
				task.defer(v_u_243)
			end
		end
		table.insert(v_u_17, v388:Connect(v389))
		local v_u_390 = ""
		local function v_u_405() -- name: rsSync
			-- upvalues: (copy) p_u_3, (ref) v_u_390, (copy) v_u_13, (copy) v_u_14, (ref) v_u_16, (copy) v_u_131, (copy) v_u_200
			if p_u_3.rs == nil then
				return
			else
				local v391 = p_u_3.rs.filterIds()
				local v392 = p_u_3.rs.tiles()
				local v393 = {}
				for _, v394 in v391 do
					local v395 = v392[v394]
					local v396 = "%s:%s:%s"
					local v397
					if v395 then
						v397 = v395.word
					else
						v397 = v395
					end
					local v398 = tostring(v397)
					if v395 then
						v395 = v395.from
					end
					local v399 = tostring(v395)
					table.insert(v393, v396:format(v394, v398, v399))
				end
				local v400 = table.concat(v393, "|")
				if v400 == v_u_390 then
					return
				else
					local v401 = {}
					for v402 in string.gmatch(v_u_390, "([^:|]+):") do
						table.insert(v401, v402)
					end
					local v403 = table.concat(v401, ",") ~= table.concat(v391, ",")
					v_u_390 = v400
					if v_u_13.chip == "restock" and #v391 == 0 then
						v_u_13.chip = "all"
						v403 = true
					end
					v_u_14.paintChips()
					if v403 and v_u_16 then
						v_u_14.arrange(false)
					else
						for _, v404 in v_u_131 do
							v_u_200(v404, false)
						end
					end
				end
			end
		end
		v_u_14.rsSync = v_u_405
		local v406 = p_u_3.onTick
		local v_u_407 = 0
		local v417 = {
			["Disconnect"] = v406(function()
				-- upvalues: (ref) v_u_407, (ref) v_u_470, (ref) v_u_336, (ref) v_u_15, (copy) v_u_9, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (copy) v_u_14, (copy) v_u_131, (copy) v_u_200, (ref) v_u_31, (copy) v_u_8, (copy) v_u_346, (copy) v_u_405
				v_u_407 = v_u_407 + 1
				if v_u_407 % v_u_470.LISTED_EVERY == 0 and (not v_u_336 and v_u_15) then
					v_u_336 = true
					local v_u_408 = false
					task.spawn(function()
						-- upvalues: (ref) v_u_9, (copy) v_u_408, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
						local v409 = v_u_9:listed(v_u_408 and 0 or 8)
						v_u_336 = false
						if v_u_15 then
							if v409.ok then
								local v410 = v_u_28 ~= "ready"
								local v411 = 0
								for _ in v_u_27 do
									v411 = v411 + 1
								end
								local v412 = v409.prices
								v_u_27 = type(v412) ~= "table" and {} or v409.prices
								v_u_29 = v409.stale == true
								v_u_30 = v409.cut == true
								v_u_28 = "ready"
								v_u_260 = false
								v_u_109.Visible = false
								local v413 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v413)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v413 + v_u_117))
								local v414 = 0
								for _ in v_u_27 do
									v414 = v414 + 1
								end
								if v410 or v_u_116.CanvasPosition.Y < 2 and v411 ~= v414 then
									v_u_14.arrange(v410)
								else
									for _, v415 in v_u_131 do
										v_u_200(v415, true)
									end
								end
								if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
									v_u_31 = v_u_31 + 1
									task.delay(v_u_8.retryDelay(v409.retryIn, v_u_31, 1), function()
										-- upvalues: (ref) v_u_15, (ref) v_u_346
										if v_u_15 then
											v_u_346(true)
										end
									end)
								else
									v_u_31 = 0
								end
							else
								if v409.code ~= "RATE" and v409.code ~= "MUTED" then
									if v_u_28 ~= "ready" then
										v_u_28 = "failed"
										v_u_14.arrange(true)
									end
									v_u_109.Visible = true
									local v416 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
									v_u_116.Position = UDim2.fromOffset(0, v416)
									v_u_116.Size = UDim2.new(1, 0, 1, -(v416 + v_u_117))
								end
								return
							end
						else
							return
						end
					end)
				end
				v_u_405()
			end)
		}
		table.insert(v_u_17, v417)
		function v_u_14.show() -- name: show
			-- upvalues: (ref) v_u_16, (copy) v_u_14, (ref) v_u_43, (ref) v_u_28, (ref) v_u_336, (ref) v_u_15, (copy) v_u_9, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (copy) v_u_131, (copy) v_u_200, (ref) v_u_31, (copy) v_u_8, (copy) v_u_346, (ref) v_u_215, (copy) v_u_243
			v_u_16 = true
			v_u_14.paintChips()
			v_u_43()
			if v_u_28 == "pending" or v_u_28 == "failed" then
				if v_u_28 == "failed" then
					v_u_28 = "pending"
				end
				v_u_14.arrange(false)
				if not v_u_336 then
					if v_u_15 then
						v_u_336 = true
						local v_u_418 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_9, (copy) v_u_418, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
							local v419 = v_u_9:listed(v_u_418 and 0 or 8)
							v_u_336 = false
							if v_u_15 then
								if v419.ok then
									local v420 = v_u_28 ~= "ready"
									local v421 = 0
									for _ in v_u_27 do
										v421 = v421 + 1
									end
									local v422 = v419.prices
									v_u_27 = type(v422) ~= "table" and {} or v419.prices
									v_u_29 = v419.stale == true
									v_u_30 = v419.cut == true
									v_u_28 = "ready"
									v_u_260 = false
									v_u_109.Visible = false
									local v423 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
									v_u_116.Position = UDim2.fromOffset(0, v423)
									v_u_116.Size = UDim2.new(1, 0, 1, -(v423 + v_u_117))
									local v424 = 0
									for _ in v_u_27 do
										v424 = v424 + 1
									end
									if v420 or v_u_116.CanvasPosition.Y < 2 and v421 ~= v424 then
										v_u_14.arrange(v420)
									else
										for _, v425 in v_u_131 do
											v_u_200(v425, true)
										end
									end
									if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
										v_u_31 = v_u_31 + 1
										task.delay(v_u_8.retryDelay(v419.retryIn, v_u_31, 1), function()
											-- upvalues: (ref) v_u_15, (ref) v_u_346
											if v_u_15 then
												v_u_346(true)
											end
										end)
									else
										v_u_31 = 0
									end
								else
									if v419.code ~= "RATE" and v419.code ~= "MUTED" then
										if v_u_28 ~= "ready" then
											v_u_28 = "failed"
											v_u_14.arrange(true)
										end
										v_u_109.Visible = true
										local v426 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
										v_u_116.Position = UDim2.fromOffset(0, v426)
										v_u_116.Size = UDim2.new(1, 0, 1, -(v426 + v_u_117))
									end
									return
								end
							else
								return
							end
						end)
					end
				end
			else
				if not v_u_336 and v_u_15 then
					v_u_336 = true
					local v_u_427 = false
					task.spawn(function()
						-- upvalues: (ref) v_u_9, (copy) v_u_427, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
						local v428 = v_u_9:listed(v_u_427 and 0 or 8)
						v_u_336 = false
						if v_u_15 then
							if v428.ok then
								local v429 = v_u_28 ~= "ready"
								local v430 = 0
								for _ in v_u_27 do
									v430 = v430 + 1
								end
								local v431 = v428.prices
								v_u_27 = type(v431) ~= "table" and {} or v428.prices
								v_u_29 = v428.stale == true
								v_u_30 = v428.cut == true
								v_u_28 = "ready"
								v_u_260 = false
								v_u_109.Visible = false
								local v432 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v432)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v432 + v_u_117))
								local v433 = 0
								for _ in v_u_27 do
									v433 = v433 + 1
								end
								if v429 or v_u_116.CanvasPosition.Y < 2 and v430 ~= v433 then
									v_u_14.arrange(v429)
								else
									for _, v434 in v_u_131 do
										v_u_200(v434, true)
									end
								end
								if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
									v_u_31 = v_u_31 + 1
									task.delay(v_u_8.retryDelay(v428.retryIn, v_u_31, 1), function()
										-- upvalues: (ref) v_u_15, (ref) v_u_346
										if v_u_15 then
											v_u_346(true)
										end
									end)
								else
									v_u_31 = 0
								end
							else
								if v428.code ~= "RATE" and v428.code ~= "MUTED" then
									if v_u_28 ~= "ready" then
										v_u_28 = "failed"
										v_u_14.arrange(true)
									end
									v_u_109.Visible = true
									local v435 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
									v_u_116.Position = UDim2.fromOffset(0, v435)
									v_u_116.Size = UDim2.new(1, 0, 1, -(v435 + v_u_117))
								end
								return
							end
						else
							return
						end
					end)
				end
				if v_u_215 then
					return
				end
				v_u_215 = true
				task.defer(v_u_243)
			end
		end
		function v_u_14.hide() -- name: hide
			-- upvalues: (ref) v_u_16, (copy) v_u_213, (copy) v_u_34
			v_u_16 = false
			v_u_213.clear()
			table.clear(v_u_34)
		end
		function v_u_14.refresh(_) -- name: refresh end
		function v_u_14.reload() -- name: reload
			-- upvalues: (ref) v_u_28, (ref) v_u_27, (ref) v_u_32, (ref) v_u_33, (ref) v_u_30, (copy) v_u_34, (copy) v_u_9, (copy) v_u_14, (ref) v_u_336, (ref) v_u_15, (ref) v_u_29, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (copy) v_u_131, (copy) v_u_200, (ref) v_u_31, (copy) v_u_8, (copy) v_u_346
			v_u_28 = "pending"
			v_u_27 = {}
			v_u_32 = {}
			v_u_33 = {}
			v_u_30 = false
			table.clear(v_u_34)
			v_u_9:invalidate("listed")
			v_u_14.arrange(true)
			if not v_u_336 then
				if not v_u_15 then
					return
				end
				v_u_336 = true
				local v_u_436 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_436, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
					local v437 = v_u_9:listed(v_u_436 and 0 or 8)
					v_u_336 = false
					if v_u_15 then
						if v437.ok then
							local v438 = v_u_28 ~= "ready"
							local v439 = 0
							for _ in v_u_27 do
								v439 = v439 + 1
							end
							local v440 = v437.prices
							v_u_27 = type(v440) ~= "table" and {} or v437.prices
							v_u_29 = v437.stale == true
							v_u_30 = v437.cut == true
							v_u_28 = "ready"
							v_u_260 = false
							v_u_109.Visible = false
							local v441 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
							v_u_116.Position = UDim2.fromOffset(0, v441)
							v_u_116.Size = UDim2.new(1, 0, 1, -(v441 + v_u_117))
							local v442 = 0
							for _ in v_u_27 do
								v442 = v442 + 1
							end
							if v438 or v_u_116.CanvasPosition.Y < 2 and v439 ~= v442 then
								v_u_14.arrange(v438)
							else
								for _, v443 in v_u_131 do
									v_u_200(v443, true)
								end
							end
							if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
								v_u_31 = v_u_31 + 1
								task.delay(v_u_8.retryDelay(v437.retryIn, v_u_31, 1), function()
									-- upvalues: (ref) v_u_15, (ref) v_u_346
									if v_u_15 then
										v_u_346(true)
									end
								end)
							else
								v_u_31 = 0
							end
						else
							if v437.code ~= "RATE" and v437.code ~= "MUTED" then
								if v_u_28 ~= "ready" then
									v_u_28 = "failed"
									v_u_14.arrange(true)
								end
								v_u_109.Visible = true
								local v444 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v444)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v444 + v_u_117))
							end
							return
						end
					else
						return
					end
				end)
			end
		end
		function v_u_14.onNote(_) -- name: onNote
			-- upvalues: (ref) v_u_336, (ref) v_u_15, (copy) v_u_9, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (copy) v_u_109, (copy) v_u_107, (copy) v_u_108, (copy) v_u_116, (ref) v_u_117, (copy) v_u_14, (copy) v_u_131, (copy) v_u_200, (ref) v_u_31, (copy) v_u_8, (copy) v_u_346
			if not v_u_336 then
				if not v_u_15 then
					return
				end
				v_u_336 = true
				local v_u_445 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_445, (ref) v_u_336, (ref) v_u_15, (ref) v_u_28, (ref) v_u_27, (ref) v_u_29, (ref) v_u_30, (ref) v_u_260, (ref) v_u_109, (ref) v_u_107, (ref) v_u_108, (ref) v_u_116, (ref) v_u_117, (ref) v_u_14, (ref) v_u_131, (ref) v_u_200, (ref) v_u_31, (ref) v_u_8, (ref) v_u_346
					local v446 = v_u_9:listed(v_u_445 and 0 or 8)
					v_u_336 = false
					if v_u_15 then
						if v446.ok then
							local v447 = v_u_28 ~= "ready"
							local v448 = 0
							for _ in v_u_27 do
								v448 = v448 + 1
							end
							local v449 = v446.prices
							v_u_27 = type(v449) ~= "table" and {} or v446.prices
							v_u_29 = v446.stale == true
							v_u_30 = v446.cut == true
							v_u_28 = "ready"
							v_u_260 = false
							v_u_109.Visible = false
							local v450 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
							v_u_116.Position = UDim2.fromOffset(0, v450)
							v_u_116.Size = UDim2.new(1, 0, 1, -(v450 + v_u_117))
							local v451 = 0
							for _ in v_u_27 do
								v451 = v451 + 1
							end
							if v447 or v_u_116.CanvasPosition.Y < 2 and v448 ~= v451 then
								v_u_14.arrange(v447)
							else
								for _, v452 in v_u_131 do
									v_u_200(v452, true)
								end
							end
							if v_u_29 and v_u_31 < v_u_8.RETRY_MAX then
								v_u_31 = v_u_31 + 1
								task.delay(v_u_8.retryDelay(v446.retryIn, v_u_31, 1), function()
									-- upvalues: (ref) v_u_15, (ref) v_u_346
									if v_u_15 then
										v_u_346(true)
									end
								end)
							else
								v_u_31 = 0
							end
						else
							if v446.code ~= "RATE" and v446.code ~= "MUTED" then
								if v_u_28 ~= "ready" then
									v_u_28 = "failed"
									v_u_14.arrange(true)
								end
								v_u_109.Visible = true
								local v453 = v_u_107 + (not v_u_109.Visible and 0 or v_u_108 + 4)
								v_u_116.Position = UDim2.fromOffset(0, v453)
								v_u_116.Size = UDim2.new(1, 0, 1, -(v453 + v_u_117))
							end
							return
						end
					else
						return
					end
				end)
			end
		end
		function v_u_14.cards() -- name: cards
			-- upvalues: (copy) v_u_131
			local v454 = {}
			for v455, v456 in v_u_131 do
				local v457 = {
					["idx"] = v455,
					["id"] = v456.id,
					["state"] = v456.state,
					["price"] = v456.price.Text,
					["count"] = v456.count.Text,
					["btn"] = v456.btn
				}
				table.insert(v454, v457)
			end
			table.sort(v454, function(p458, p459)
				return p458.idx < p459.idx
			end)
			return v454
		end
		function v_u_14.state() -- name: state
			-- upvalues: (ref) v_u_133, (ref) v_u_134, (copy) v_u_39, (ref) v_u_212, (copy) v_u_131, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (ref) v_u_36, (copy) v_u_116
			local v460 = {
				["cols"] = v_u_133,
				["cw"] = v_u_134,
				["cellH"] = v_u_39,
				["items"] = #v_u_212
			}
			local v461 = 0
			for _ in v_u_131 do
				v461 = v461 + 1
			end
			v460.active = v461
			v460.listed = v_u_28
			v460.stale = v_u_29
			v460.query = v_u_26
			v460.placeholder = v_u_36
			v460.grid = v_u_116
			return v460
		end
		function v_u_14.setQuery(p462) -- name: setQuery
			-- upvalues: (ref) v_u_26, (ref) v_u_64, (copy) v_u_14
			v_u_26 = p462
			v_u_64.Text = p462
			v_u_14.arrange(true)
		end
		function v_u_14.setSort(p463) -- name: setSort
			-- upvalues: (ref) v_u_333
			v_u_333(p463)
		end
		function v_u_14.setShowAll(p464) -- name: setShowAll
			-- upvalues: (ref) v_u_335
			v_u_335(p464)
		end
		function v_u_14.setChip(p465) -- name: setChip
			-- upvalues: (copy) v_u_13, (copy) v_u_14
			v_u_13.chip = p465
			v_u_14.paintChips()
			v_u_14.arrange(true)
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15, (copy) v_u_213, (copy) v_u_17, (copy) v_u_132, (ref) v_u_128
			v_u_15 = false
			v_u_213.clear()
			for _, v_u_466 in v_u_17 do
				pcall(function()
					-- upvalues: (copy) v_u_466
					v_u_466:Disconnect()
				end)
			end
			table.clear(v_u_17)
			for _, v467 in v_u_132 do
				if v467.vp and v_u_128 then
					local v468 = v_u_128.release
					local v469 = v467.vp
					pcall(v468, v469)
				end
				v467.vp = nil
			end
		end
		v_u_14.frame = p_u_4
		v_u_14.paintChips()
		v_u_43()
		task.defer(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_224, (copy) v_u_14
			if v_u_15 then
				v_u_224()
				v_u_14.arrange(false)
			end
		end)
		return v_u_14
	end
}
return v_u_470