-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpAim

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = {
	["SLOPE_MAX"] = 0.93,
	["HEIGHT_DOWN"] = 2.4,
	["HEIGHT_UP"] = 3.4,
	["NEAR"] = 1.5,
	["EYE_ABOVE_ROOT"] = 1.5,
	["SIGHT_COS"] = 0.9975640502598242,
	["ADS_RAY_BLEND"] = 0.85,
	["OVERLAY_BLEND"] = 0.9
}
local v_u_4 = false
local v_u_5 = 0
local v_u_6 = {}
local v_u_7 = -10
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = {}
function v_u_3.clampHeight(p12, p13) -- name: clampHeight
	-- upvalues: (copy) v_u_3
	local v14 = p12 - v_u_3.HEIGHT_DOWN
	local v15 = p12 + v_u_3.HEIGHT_UP
	return math.clamp(p13, v14, v15)
end
function v_u_3.yawOf(p16, p17) -- name: yawOf
	local v18 = -p16
	local v19 = -p17
	return math.atan2(v18, v19)
end
function v_u_3.shotVector(p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30) -- name: shotVector
	-- upvalues: (copy) v_u_3
	local v31 = p29 or v_u_3.NEAR
	local v32 = p30 or v_u_3.SLOPE_MAX
	local v33 = p23 - p20
	local v34 = p24 - p21
	local v35 = p25 - p22
	local v36 = v33 * v33 + v34 * v34 + v35 * v35
	local v37 = math.sqrt(v36)
	local v38, v39, v40
	if v37 == v37 and v37 >= v31 then
		v38 = v33 / v37
		v39 = v34 / v37
		v40 = v35 / v37
	else
		local v41 = p26 * p26 + p27 * p27 + p28 * p28
		local v42 = math.sqrt(v41)
		if v42 == v42 and v42 >= 1e-6 then
			v38 = p26 / v42
			v39 = p27 / v42
			v40 = p28 / v42
		else
			v39 = 0
			v38 = 0
			v40 = -1
		end
	end
	if v32 < math.abs(v39) then
		local v43 = v39 > 0 and 1 or -1
		local v44 = 1 - v32 * v32
		local v45 = math.sqrt(v44)
		local v46 = v38 * v38 + v40 * v40
		local v47 = math.sqrt(v46)
		local v48, v49
		if v47 < 0.0001 then
			local v50 = p26 * p26 + p28 * p28
			local v51 = math.sqrt(v50)
			if v51 < 0.0001 then
				v48 = 0
				v49 = -1
			else
				v48 = p26 / v51
				v49 = p28 / v51
			end
		else
			v48 = v38 / v47
			v49 = v40 / v47
		end
		v38 = v48 * v45
		v39 = v43 * v32
		v40 = v49 * v45
	end
	return v38, v39, v40, v_u_3.yawOf(v38, v40)
end
function v_u_3.spreadPx(p52, p53, p54) -- name: spreadPx
	local v55 = math.clamp(p53, 1, 120)
	local v56 = math.clamp(p52, 0, 60)
	local v57 = math.rad(v56)
	local v58 = math.tan(v57)
	local v59 = math.rad(v55) * 0.5
	return v58 / math.tan(v59) * (p54 * 0.5)
end
function v_u_3.isBlocked(p60, p61) -- name: isBlocked
	local v62 = p61 * 0.02
	return p60 < p61 - math.max(0.4, v62)
end
function v_u_3.sightOk(p63) -- name: sightOk
	-- upvalues: (copy) v_u_3
	return v_u_3.SIGHT_COS <= p63
end
function v_u_3.footOnRay(p64, p65, p66, p67, p68, p69, p70, p71, p72) -- name: footOnRay
	local v73 = (p70 - p64) * p67 + (p71 - p65) * p68 + (p72 - p66) * p69
	local v74 = (v73 ~= v73 or v73 < 0) and 0 or v73
	return p64 + p67 * v74, p65 + p68 * v74, p66 + p69 * v74, v74
end
function v_u_3.shotLine(p75, p76, p77, p78, p79, p80, p81, p82, p83, p84) -- name: shotLine
	-- upvalues: (copy) v_u_3
	local v85 = v_u_3.clampHeight(p81, p76)
	local v86, v87, v88, v89 = v_u_3.shotVector(p75, v85, p77, p82, p83, p84, p78, p79, p80)
	return p75, v85, p77, v86, v87, v88, v89
end
function v_u_3.eyeRayWanted(p90, p91) -- name: eyeRayWanted
	-- upvalues: (copy) v_u_3
	if p90 < v_u_3.ADS_RAY_BLEND then
		return false
	end
	local v92
	if p91 == true then
		v92 = v_u_3.OVERLAY_BLEND <= p90
	else
		v92 = false
	end
	return not v92
end
local function v_u_102() -- name: getParams
	-- upvalues: (ref) v_u_10, (copy) v_u_11
	local v93 = v_u_10
	if not v93 then
		v93 = RaycastParams.new()
		v93.FilterType = Enum.RaycastFilterType.Exclude
		v93.IgnoreWater = true
		v_u_10 = v93
	end
	local v94 = v_u_11.BulletPassClient
	if v94 == nil then
		local v_u_95 = "BulletPassClient"
		local v96
		v96, v94 = pcall(function()
			-- upvalues: (copy) v_u_95
			local v97 = script.Parent
			local v98
			if v97 then
				v98 = v97:FindFirstChild(v_u_95)
			else
				v98 = nil
			end
			if v98 and v98:IsA("ModuleScript") then
				return require(v98)
			else
				return nil
			end
		end)
		if not v96 or type(v94) ~= "table" then
			v94 = false
		end
		v_u_11.BulletPassClient = v94
	end
	local v99 = v94 or nil
	local v100
	if v99 then
		local v101 = v99.group
		if type(v101) == "function" then
			v100 = v99.group()
		else
			v100 = nil
		end
	else
		v100 = nil
	end
	v93.CollisionGroup = v100 or "Default"
	return v93
end
local function v_u_115() -- name: baseIgnore
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_6
	local v103 = os.clock()
	local v104 = v_u_1.LocalPlayer.Character
	local v105 = v_u_2.CurrentCamera
	if v103 - v_u_7 > 0.5 or (v104 ~= v_u_8 or v105 ~= v_u_9) then
		v_u_7 = v103
		v_u_8 = v104
		v_u_9 = v105
		table.clear(v_u_6)
		if v104 then
			local v106 = v_u_6
			table.insert(v106, v104)
		end
		if v105 then
			local v107 = v_u_6
			table.insert(v107, v105)
		end
		for _, v108 in { "HushCombat", "HushLocal" } do
			local v109 = v_u_2:FindFirstChild(v108)
			if not v109 then
				continue
			end
			local v110 = v_u_6
			table.insert(v110, v109)
		end
		local v111 = v_u_2:FindFirstChild("Raid")
		if v111 then
			for _, v112 in { "Items", "Extracts", "Spawns" } do
				local v113 = v111:FindFirstChild(v112)
				if not v113 then
					continue
				end
				local v114 = v_u_6
				table.insert(v114, v113)
			end
		end
	end
	return v_u_6
end
local function v_u_142(p116, p117, p118) -- name: cast
	-- upvalues: (copy) v_u_115, (copy) v_u_102, (copy) v_u_2, (copy) v_u_11
	-- block 35
	if p118 <= 0.05 then
		return nil, nil
	end
	local v119 = v_u_115()
	local v120 = v_u_102()
	local v121, v122, v123
	-- NumForInit
local v121, v122, v123 = 1, 6, 1
-- end NumForInit
	local v124 = 0
	local v125 = nil
	local v126 = nil
	-- NumForNext
v121 = v121 + v123;
if v121 <= v122
-- end NumForNext
	-- block 1
	goto l3
	::l3::
	v120.FilterDescendantsInstances = v119
	local v127 = v_u_2:Raycast(p116, p117 * p118, v120)
	if not v127 then
		for v141 = 1, v124 do
			table.remove(v119)
		end
		return v125, v126
	end
	local v129 = v127.Instance
	local v130 = v129:FindFirstAncestorOfClass("Model")
	local v131
	if v130 == nil then
		v131 = false
	else
		v131 = v130:FindFirstChildOfClass("Humanoid") ~= nil
	end
	local v132 = v_u_11.BulletPassClient
	if v132 == nil then
		local v_u_133 = "BulletPassClient"
		local v134
		v134, v132 = pcall(function()
			-- upvalues: (copy) v_u_133
			local v135 = script.Parent
			local v136
			if v135 then
				v136 = v135:FindFirstChild(v_u_133)
			else
				v136 = nil
			end
			if v136 and v136:IsA("ModuleScript") then
				return require(v136)
			else
				return nil
			end
		end)
		if not v134 or type(v132) ~= "table" then
			v132 = false
		end
		v_u_11.BulletPassClient = v132
	end
	local v137 = v132 or nil
	local v138
	if v131 then
		v138 = v131
		if v138 then
			if v131 then
				v129 = v130
			end
			table.insert(v119, v129)
			v124 = v124 + 1
			p118 = p118 - (v127.Position - p116).Magnitude
			p116 = v127.Position
			if p118 > 0.05 then
				continue
			end
		else
			v125 = v127.Position
			v126 = v129
		end
	else
		if v129.Transparency >= 0.98 and not v129.CanCollide then
			local v139
			if v137 == nil then
				v139 = false
			else
				v139 = v137.isShell(v129)
			end
			v138 = not v139
			if v138 then
				if v138 then
					if v131 then
						v129 = v130
					end
					table.insert(v119, v129)
					v124 = v124 + 1
					p118 = p118 - (v127.Position - p116).Magnitude
					p116 = v127.Position
					if p118 > 0.05 then
						continue
					end
				else
					v125 = v127.Position
					v126 = v129
				end
				goto l1
			end
			if v129.Material == Enum.Material.Glass then
				v138 = v129:GetAttribute("Broken") ~= true
			else
				v138 = false
			end
		elseif v129.Material == Enum.Material.Glass then
			v138 = v129:GetAttribute("Broken") ~= true
		else
			v138 = false
		end
		if v138 then
			if v131 then
				v129 = v130
			end
			table.insert(v119, v129)
			v124 = v124 + 1
			p118 = p118 - (v127.Position - p116).Magnitude
			p116 = v127.Position
			if p118 > 0.05 then
				continue
			end
		else
			v125 = v127.Position
			v126 = v129
		end
	end
	::l1::
	for v141 = 1, v124 do
		table.remove(v119)
	end
	return v125, v126
	::l4::
	for v141 = 1, v124 do
		table.remove(v119)
	end
	return v125, v126
	-- block 16
	goto l4
end
local v_u_143 = {
	["t"] = -1000000000,
	["perk"] = nil,
	["perk"] = {}
}
local v_u_144 = {}
local function v_u_156() -- name: localPerk
	-- upvalues: (copy) v_u_143, (copy) v_u_144, (copy) v_u_1
	local v145 = os.clock()
	if v145 - v_u_143.t >= 1 then
		v_u_143.t = v145
		local v146 = v_u_144.PerkStats
		if v146 == nil then
			local v_u_147 = "PerkStats"
			local v148
			v148, v146 = pcall(function()
				-- upvalues: (copy) v_u_147
				local v149 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
				local v150
				if v149 then
					v150 = v149:FindFirstChild("Shared")
				else
					v150 = nil
				end
				local v151
				if v150 then
					v151 = v150:FindFirstChild(v_u_147)
				else
					v151 = nil
				end
				if v151 then
					return require(v151)
				else
					return nil
				end
			end)
			if not v148 or type(v146) ~= "table" then
				v146 = false
			end
			v_u_144.PerkStats = v146
		end
		local v_u_152 = v146 or nil
		local v_u_153 = v_u_1.LocalPlayer
		local v154, v155 = pcall(function()
			-- upvalues: (copy) v_u_152, (copy) v_u_153
			return not (v_u_152 and v_u_153) and {} or v_u_152.fromPlayer(v_u_153)
		end)
		v_u_143.perk = (not v154 or type(v155) ~= "table") and {} or v155
	end
	return v_u_143.perk
end
function v_u_3.opticMul(p157) -- name: opticMul
	-- upvalues: (copy) v_u_144, (copy) v_u_156
	local v158 = v_u_144.PerkWeapon
	if v158 == nil then
		local v_u_159 = "PerkWeapon"
		local v160
		v160, v158 = pcall(function()
			-- upvalues: (copy) v_u_159
			local v161 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
			local v162
			if v161 then
				v162 = v161:FindFirstChild("Shared")
			else
				v162 = nil
			end
			local v163
			if v162 then
				v163 = v162:FindFirstChild(v_u_159)
			else
				v163 = nil
			end
			if v163 then
				return require(v163)
			else
				return nil
			end
		end)
		if not v160 or type(v158) ~= "table" then
			v158 = false
		end
		v_u_144.PerkWeapon = v158
	end
	local v164 = v158 or nil
	if v164 == nil then
		return 1
	end
	local v165 = v164.opticAdsMul
	local v166 = v_u_156()
	local v167
	if p157 == nil or p157 == "" then
		v167 = false
	else
		v167 = p157 ~= "iron"
	end
	local v168, v169 = pcall(v165, v166, v167)
	return (not v168 or (type(v169) ~= "number" or v169 <= 0)) and 1 or v169
end
function v_u_3.opticBlend(p170, p171) -- name: opticBlend
	if type(p171) ~= "number" or (p171 >= 1 or p171 <= 0) then
		return p170
	end
	local v172 = p170 / p171
	return math.clamp(v172, 0, 1)
end
v_u_3.TWIN_BLEND_MUL = 0.92
v_u_3.ADS_RAY_BLEND_TWIN = v_u_3.ADS_RAY_BLEND / v_u_3.TWIN_BLEND_MUL
function v_u_3.twinBlend(p173, p174) -- name: twinBlend
	-- upvalues: (copy) v_u_3
	if p174 ~= true then
		return p173
	end
	local v175 = p173 * v_u_3.TWIN_BLEND_MUL
	return math.clamp(v175, 0, 1)
end
function v_u_3.opticAdsTime(p176, p177, p178) -- name: opticAdsTime
	-- upvalues: (copy) v_u_144, (copy) v_u_156
	local v179 = v_u_144.PerkWeapon
	if v179 == nil then
		local v_u_180 = "PerkWeapon"
		local v181
		v181, v179 = pcall(function()
			-- upvalues: (copy) v_u_180
			local v182 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
			local v183
			if v182 then
				v183 = v182:FindFirstChild("Shared")
			else
				v183 = nil
			end
			local v184
			if v183 then
				v184 = v183:FindFirstChild(v_u_180)
			else
				v184 = nil
			end
			if v184 then
				return require(v184)
			else
				return nil
			end
		end)
		if not v181 or type(v179) ~= "table" then
			v179 = false
		end
		v_u_144.PerkWeapon = v179
	end
	local v185 = v179 or nil
	if v185 == nil then
		if type(p177) == "number" then
			return p177
		else
			return p176
		end
	else
		local v186 = v185.opticAdsTime
		local v187 = v_u_156()
		local v188, v189 = pcall(v186, p176, p177, v187, p178)
		if v188 and type(v189) == "number" then
			return v189
		elseif type(p177) == "number" then
			return p177
		else
			return p176
		end
	end
end
function v_u_3.adsBlend() -- name: adsBlend
	-- upvalues: (copy) v_u_11, (copy) v_u_3
	local v190 = v_u_11.Viewmodel
	if v190 == nil then
		local v_u_191 = "Viewmodel"
		local v192
		v192, v190 = pcall(function()
			-- upvalues: (copy) v_u_191
			local v193 = script.Parent
			local v194
			if v193 then
				v194 = v193:FindFirstChild(v_u_191)
			else
				v194 = nil
			end
			if v194 and v194:IsA("ModuleScript") then
				return require(v194)
			else
				return nil
			end
		end)
		if not v192 or type(v190) ~= "table" then
			v190 = false
		end
		v_u_11.Viewmodel = v190
	end
	local v195 = v190 or nil
	if v195 then
		local v196 = v195.adsState
		if type(v196) == "function" then
			local v197 = v195.adsState
			local v198, v199 = pcall(v197)
			if v198 and type(v199) == "table" then
				local v200 = v199.blend
				if type(v200) == "number" then
					v199.blend = v_u_3.opticBlend(v199.blend, v_u_3.opticMul(v199.sight))
					local v201 = v199.blend
					return math.clamp(v201, 0, 1)
				end
			end
		end
	end
	return 0
end
local function v_u_218(p202) -- name: bodyOrigin
	-- upvalues: (copy) v_u_3, (copy) v_u_11
	local v203 = p202.Position
	local v204 = v203.Y + v_u_3.EYE_ABOVE_ROOT
	local v205 = v_u_11.FpCam
	if v205 == nil then
		local v_u_206 = "FpCam"
		local v207
		v207, v205 = pcall(function()
			-- upvalues: (copy) v_u_206
			local v208 = script.Parent
			local v209
			if v208 then
				v209 = v208:FindFirstChild(v_u_206)
			else
				v209 = nil
			end
			if v209 and v209:IsA("ModuleScript") then
				return require(v209)
			else
				return nil
			end
		end)
		if not v207 or type(v205) ~= "table" then
			v205 = false
		end
		v_u_11.FpCam = v205
	end
	local v210 = v205 or nil
	if v210 then
		local v211 = v210.eyeCF
		if type(v211) == "function" then
			local v212 = v210.eyeCF
			local v213, v214 = pcall(v212)
			if v213 and typeof(v214) == "CFrame" then
				v204 = v214.Position.Y
			end
		end
	end
	local v215 = v203.X
	local v216 = v_u_3.clampHeight(v203.Y, v204)
	local v217 = v203.Z
	return Vector3.new(v215, v216, v217)
end
function v_u_3.ray() -- name: ray
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_3, (copy) v_u_1, (copy) v_u_218
	local v219 = v_u_2.CurrentCamera
	if not v219 then
		return nil, nil
	end
	local v220 = v219.CFrame
	local v221 = v220.Position
	local v222 = v220.LookVector
	local v223 = v_u_11.Viewmodel
	if v223 == nil then
		local v_u_224 = "Viewmodel"
		local v225
		v225, v223 = pcall(function()
			-- upvalues: (copy) v_u_224
			local v226 = script.Parent
			local v227
			if v226 then
				v227 = v226:FindFirstChild(v_u_224)
			else
				v227 = nil
			end
			if v227 and v227:IsA("ModuleScript") then
				return require(v227)
			else
				return nil
			end
		end)
		if not v225 or type(v223) ~= "table" then
			v223 = false
		end
		v_u_11.Viewmodel = v223
	end
	local v228 = v223 or nil
	if v228 then
		local v229 = v228.adsState
		if type(v229) == "function" then
			local v230 = v228.adsState
			local v231, v232 = pcall(v230)
			if v231 then
				if type(v232) == "table" then
					local v233 = v232.blend
					v231 = type(v233) == "number"
				else
					v231 = false
				end
			end
			if v231 then
				v232.blend = v_u_3.opticBlend(v232.blend, v_u_3.opticMul(v232.sight))
				v232.blend = v_u_3.twinBlend(v232.blend, v232.twin == true)
			end
			if v231 and v_u_3.eyeRayWanted(v232.blend, v232.overlay == true) then
				local v234 = v232.eye
				if typeof(v234) == "Instance" and (v234:IsA("Attachment") and v234.Parent ~= nil) then
					local v235 = v234.WorldCFrame
					if v_u_3.sightOk(v235.LookVector:Dot(v222)) then
						v221 = v235.Position
						v222 = v235.LookVector
						local v236 = v232.ray
						if type(v236) == "table" then
							local v237 = v236.origin
							if typeof(v237) == "Vector3" then
								local v238 = v236.dir
								if typeof(v238) == "Vector3" and v236.dir.Magnitude > 0.5 then
									v221 = v236.origin
									v222 = v236.dir
								end
							end
						end
					end
				end
			end
		end
	end
	local v239 = v222.Unit
	local v240 = v_u_1.LocalPlayer.Character
	local v241
	if v240 then
		v241 = v240:FindFirstChild("HumanoidRootPart")
	else
		v241 = nil
	end
	if not (v241 and v241:IsA("BasePart")) then
		v241 = nil
	end
	if v241 then
		local v242 = v_u_218(v241)
		local v243, v244, v245 = v_u_3.footOnRay(v221.X, v221.Y, v221.Z, v239.X, v239.Y, v239.Z, v242.X, v242.Y, v242.Z)
		v221 = Vector3.new(v243, v244, v245)
	end
	return v221, v239
end
function v_u_3.lineClear(p246, p247) -- name: lineClear
	-- upvalues: (copy) v_u_142
	local v248 = p247 - p246
	local v249 = v248.Magnitude
	return v249 < 0.6 and true or v_u_142(p246, v248 / v249, v249 - 0.5) == nil
end
function v_u_3.setActive(p250) -- name: setActive
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	v_u_4 = p250 == true
	if not v_u_4 then
		v_u_5 = 0
	end
end
function v_u_3.isActive() -- name: isActive
	-- upvalues: (ref) v_u_4
	return v_u_4
end
function v_u_3.setSpread(p251) -- name: setSpread
	-- upvalues: (ref) v_u_5
	v_u_5 = p251 ~= p251 and 0 or math.max(0, p251)
end
function v_u_3.target(p252) -- name: target
	-- upvalues: (ref) v_u_4, (copy) v_u_3, (copy) v_u_142
	if v_u_4 then
		local v253, v254 = v_u_3.ray()
		if v253 and v254 then
			return v_u_142(v253, v254, p252 or 300)
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_3.shot(p255, _, p256, p257) -- name: shot
	-- upvalues: (ref) v_u_4, (copy) v_u_3, (copy) v_u_142
	if not (v_u_4 and p255) then
		return nil, nil, nil
	end
	local v258, v259 = v_u_3.ray()
	if not (v258 and v259) then
		return nil, nil, nil
	end
	local v260 = p256 or 120
	if p257 == nil then
		p257 = v_u_142(v258, v259, v260) or v258 + v259 * v260
	end
	local v261, v262, v263, v264, v265, v266, v267 = v_u_3.shotLine(v258.X, v258.Y, v258.Z, v259.X, v259.Y, v259.Z, p255.Position.Y, p257.X, p257.Y, p257.Z)
	return Vector3.new(v261, v262, v263), Vector3.new(v264, v265, v266), v267
end
function v_u_3.crosshair(p268, p269) -- name: crosshair
	-- upvalues: (ref) v_u_4, (copy) v_u_2, (copy) v_u_3, (ref) v_u_5, (copy) v_u_11, (copy) v_u_1, (copy) v_u_218, (copy) v_u_142
	if not v_u_4 then
		return nil, 0, nil
	end
	local v270 = v_u_2.CurrentCamera
	if not v270 then
		return nil, 0, nil
	end
	local v271 = v270.ViewportSize
	local v272 = Vector2.new(v271.X * 0.5, v271.Y * 0.5)
	local v273 = v_u_3.spreadPx(p268 or v_u_5, v270.FieldOfView, v271.Y)
	local v274 = nil
	if p269 ~= nil then
		local v275 = v_u_11.FpCam
		if v275 == nil then
			local v_u_276 = "FpCam"
			local v277
			v277, v275 = pcall(function()
				-- upvalues: (copy) v_u_276
				local v278 = script.Parent
				local v279
				if v278 then
					v279 = v278:FindFirstChild(v_u_276)
				else
					v279 = nil
				end
				if v279 and v279:IsA("ModuleScript") then
					return require(v279)
				else
					return nil
				end
			end)
			if not v277 or type(v275) ~= "table" then
				v275 = false
			end
			v_u_11.FpCam = v275
		end
		local v280 = v275 or nil
		local v281 = false
		if v280 then
			local v282 = v280.effectiveSide
			if type(v282) == "function" then
				local v283 = v280.effectiveSide
				local v284
				v281, v284 = pcall(v283)
				if v281 then
					v281 = v284 == "tp"
				end
			end
		end
		local v285 = v_u_1.LocalPlayer.Character
		local v286
		if v285 then
			v286 = v285:FindFirstChild("HumanoidRootPart")
		else
			v286 = nil
		end
		if v281 and (v286 and v286:IsA("BasePart")) then
			local v287 = v_u_3.ray()
			local v288
			if v287 then
				local v289 = v287.X
				local v290 = v_u_3.clampHeight(v286.Position.Y, v287.Y)
				local v291 = v287.Z
				v288 = Vector3.new(v289, v290, v291)
			else
				v288 = v_u_218(v286)
			end
			local v292 = v286.Position.X
			local v293 = v288.Y
			local v294 = v286.Position.Z
			local v295 = Vector3.new(v292, v293, v294)
			local v296 = v288 - v295
			if v296.Magnitude > 0.05 then
				local v297 = v_u_142(v295, v296.Unit, v296.Magnitude)
				if v297 then
					v288 = v297 - v296.Unit * 0.1
				end
			end
			local v298 = p269 - v288
			local v299 = v298.Magnitude
			if v_u_3.NEAR < v299 then
				local v300 = v_u_142(v288, v298.Unit, v299)
				if v300 and v_u_3.isBlocked((v300 - v288).Magnitude, v299) then
					local v301, v302 = v270:WorldToViewportPoint(v300)
					if v302 then
						v274 = Vector2.new(v301.X, v301.Y)
					end
				end
			end
		end
	end
	return v272, v273, v274
end
return v_u_3