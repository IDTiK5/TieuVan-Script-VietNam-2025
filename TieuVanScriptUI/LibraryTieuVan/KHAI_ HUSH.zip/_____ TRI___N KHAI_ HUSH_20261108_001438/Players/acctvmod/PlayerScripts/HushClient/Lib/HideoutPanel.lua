-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutPanel

local v_u_1 = game:GetService("GuiService")
local v_u_4 = {
	["compact"] = function(p2) -- name: compact
		local v3 = p2.refSize()
		return p2.isPhone and p2.isPhone() or (v3.X < 900 and true or v3.Y < 640)
	end
}
local function v_u_14(p5) -- name: fmtTime
	local v6 = p5 + 0.5
	local v7 = math.floor(v6)
	local v8 = math.max(0, v7)
	local v9 = v8 / 3600
	local v10 = math.floor(v9)
	local v11 = v8 % 3600 / 60
	local v12 = math.floor(v11)
	local v13 = v8 % 60
	if v10 > 0 then
		return ("%d:%02d:%02d"):format(v10, v12, v13)
	else
		return ("%02d:%02d"):format(v12, v13)
	end
end
local function v_u_18(p15) -- name: fmtDuration
	if p15 >= 3600 then
		local v16 = p15 / 3600
		if v16 == math.floor(v16) then
			return ("%d H"):format(v16)
		else
			return ("%.1f H"):format(v16)
		end
	else
		if p15 < 60 then
			return ("%d S"):format(p15)
		end
		local v17 = p15 / 60 + 0.5
		return ("%d MIN"):format((math.floor(v17)))
	end
end
function v_u_4.new(p_u_19) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_14, (copy) v_u_18, (copy) v_u_1
	local v_u_20 = p_u_19.HushUI
	local v_u_21 = p_u_19.Theme
	local v_u_22 = v_u_21.color
	local v_u_23 = p_u_19.HM
	local v24, v_u_25 = pcall(function()
		-- upvalues: (copy) p_u_19
		return p_u_19.cctx.shared.HideoutWhy
	end)
	if not v24 or type(v_u_25) ~= "table" then
		v_u_25 = require(game:GetService("ReplicatedStorage").Hush.Shared.HideoutWhy)
	end
	local v_u_26 = nil
	local v_u_27 = nil
	local v_u_28 = nil
	local v_u_29 = nil
	local v_u_30 = nil
	local v_u_31 = {}
	local v_u_32 = nil
	local v_u_33 = 0
	local v_u_34 = ""
	local v_u_35 = 0
	local v_u_36 = nil
	local v_u_37 = 940
	local v_u_38 = 640
	local v_u_39 = 272
	local v_u_358 = false
	local v_u_41 = "craft"
	local v_u_42 = nil
	local v_u_43 = p_u_19.Recipe
	if not v_u_43 then
		local v44, v45 = pcall(function()
			-- upvalues: (copy) p_u_19
			return p_u_19.cctx.lib.HideoutRecipe
		end)
		if not v44 or type(v45) ~= "table" then
			local v46 = script.Parent
			if v46 then
				v46 = script.Parent:FindFirstChild("HideoutRecipe")
			end
			if v46 then
				v45 = require(v46)
			else
				v45 = nil
			end
		end
		v_u_43 = v45.new({
			["HushUI"] = v_u_20,
			["Theme"] = v_u_21,
			["cctx"] = p_u_19.cctx,
			["Items"] = p_u_19.Items,
			["act"] = p_u_19.act,
			["view"] = function() -- name: view
				-- upvalues: (ref) v_u_27
				return v_u_27
			end
		})
	end
	local function v_u_52() -- name: chrome
		-- upvalues: (copy) p_u_19
		local v47 = p_u_19.hooks
		local v48
		if type(v47) == "table" then
			v48 = p_u_19.hooks.chrome
		else
			v48 = false
		end
		if type(v48) == "function" then
			local v49, v50 = pcall(v48)
			if v49 and type(v50) == "table" then
				local v51 = v50.right
				if type(v51) == "number" then
					return v50
				end
			end
		end
		return {
			["right"] = 300,
			["headBottom"] = 0,
			["headRight"] = 0
		}
	end
	local function v_u_72() -- name: geometry
		-- upvalues: (copy) v_u_21, (copy) v_u_20, (copy) v_u_52
		local v53 = v_u_21.refSize()
		local v54 = not v_u_20.topInset and 64 or v_u_20.topInset()
		local v55 = v_u_52()
		local v56 = v53.X - v55.right
		local v57 = v56 - 24
		local v58 = math.clamp(v57, 940, 1240)
		local v59 = v53.Y - 260
		local v60 = math.clamp(v59, 640, 860)
		local v61 = v53.X / 2
		if v56 < v61 + v58 / 2 then
			local v62 = v58 / 2 + 16
			local v63 = v56 - v58 / 2
			v61 = math.max(v62, v63)
		end
		local v64 = v61 - v58 / 2
		local v65 = math.floor(v64)
		local v66 = v53.Y / 2 + v54 / 4 - v60 / 2
		local v67 = math.floor(v66)
		local v68 = v55.headRight
		if v65 < (tonumber(v68) or 0) + 12 then
			local v69 = v55.headBottom
			local v70 = (tonumber(v69) or 0) + 12
			v67 = math.max(v67, v70)
		end
		local v71 = v53.Y - v67 - 16
		if v71 < v60 then
			v60 = math.max(520, v71)
		end
		return math.floor(v58), math.floor(v60), v65, v67
	end
	local function v_u_79(p73, p74, p75) -- name: frame
		local v76 = Instance.new("Frame")
		v76.Name = p74
		v76.BackgroundTransparency = 1
		v76.BorderSizePixel = 0
		v76.Size = UDim2.new(1, 0, 0, 0)
		v76.AutomaticSize = Enum.AutomaticSize.Y
		for v77, v78 in p75 or {} do
			v76[v77] = v78
		end
		if p73 then
			v76.Parent = p73
		end
		return v76
	end
	local function v_u_90(p80, p81, p82, p83) -- name: card
		-- upvalues: (copy) v_u_79, (copy) v_u_22, (copy) v_u_20
		local v84 = v_u_79
		local v85 = {}
		local v86
		if p83 then
			v86 = v_u_22.accentDeep
		else
			v86 = v_u_22.raised
		end
		v85.BackgroundColor3 = v86
		v85.BackgroundTransparency = p83 and 0.25 or 0.2
		v85.LayoutOrder = p82
		local v87 = v84(p80, p81, v85)
		local v88 = v_u_20.stroke
		local v89
		if p83 then
			v89 = v_u_22.accentDim
		else
			v89 = v_u_22.line
		end
		v88(v87, v89)
		v_u_20.pad(v87, {
			14,
			14,
			12,
			12
		})
		v_u_20.layout(v87, "v", 10)
		return v87
	end
	local function v_u_97(p91, p92, p93, p94) -- name: flow
		-- upvalues: (copy) v_u_79, (copy) v_u_20
		local v95 = v_u_79(p91, p92, {
			["LayoutOrder"] = p93
		})
		local v96 = v_u_20.layout(v95, "h", p94 or 6)
		v96.Wraps = true
		v96.VerticalAlignment = Enum.VerticalAlignment.Center
		return v95
	end
	local function v_u_102(p98, p99, p100, p101) -- name: caps
		-- upvalues: (copy) v_u_20, (copy) v_u_22
		v_u_20.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["order"] = nil,
			["size"] = nil,
			["parent"] = p98,
			["text"] = p99,
			["color"] = p101 or v_u_22.text2,
			["order"] = p100,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
	end
	local function v_u_112(p103, p104, p105, p106, p107, p108, p109) -- name: row
		-- upvalues: (copy) v_u_20, (copy) v_u_22
		local v110 = Instance.new("Frame")
		v110.BackgroundTransparency = 1
		v110.Size = UDim2.new(1, 0, 0, 22)
		v110.LayoutOrder = p107
		local v111 = p109 or 0
		v_u_20.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["track"] = false,
			["parent"] = v110,
			["text"] = p104,
			["color"] = p108 or v_u_22.text,
			["size"] = UDim2.new(0.66, -v111, 1, 0),
			["position"] = UDim2.fromOffset(v111, 0)
		})
		v_u_20.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["size"] = nil,
			["position"] = nil,
			["align"] = "right",
			["track"] = false,
			["parent"] = v110,
			["text"] = p105,
			["color"] = p106 or v_u_22.text2,
			["size"] = UDim2.new(0.34, 0, 1, 0),
			["position"] = UDim2.fromScale(0.66, 0)
		})
		v110.Parent = p103
		return v110
	end
	local function v_u_124(p113, p114, p115, p116, p117, p118) -- name: timer
		-- upvalues: (copy) v_u_20, (copy) v_u_22, (copy) v_u_31
		local v119 = Instance.new("Frame")
		v119.Name = "Timer"
		v119.BackgroundTransparency = 1
		v119.Size = UDim2.new(1, 0, 0, 30)
		v119.LayoutOrder = p116
		local v120 = v_u_20.label({
			["parent"] = nil,
			["name"] = "Left",
			["text"] = "",
			["style"] = "mono",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v119,
			["color"] = v_u_22.accent,
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		local v121 = v_u_20.progress({
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["color"] = nil,
			["value"] = 0,
			["parent"] = v119,
			["size"] = UDim2.new(1, 0, 0, 4),
			["position"] = UDim2.fromOffset(0, 24),
			["color"] = v_u_22.accent
		})
		v119.Parent = p113
		local v122 = v_u_31
		local v123 = {
			["label"] = v120,
			["bar"] = v121,
			["untilAt"] = p114,
			["total"] = math.max(1, p115),
			["done"] = p117,
			["prefix"] = p118
		}
		table.insert(v122, v123)
	end
	local function v_u_133() -- name: updateTimers
		-- upvalues: (ref) v_u_27, (copy) v_u_31, (copy) v_u_20, (ref) v_u_14, (ref) v_u_32
		local v125 = os.time() + (v_u_27 and v_u_27.offset or 0)
		local v126 = false
		for _, v127 in v_u_31 do
			if not v127.label.Parent then
				continue
			end
			local v128 = v127.untilAt - v125
			if v128 <= 0 then
				v_u_20.setText(v127.label, v127.done or "READY")
				if not v127.fired then
					v127.fired = true
					v126 = true
				end
			else
				v_u_20.setText(v127.label, (v127.prefix or "") .. v_u_14(v128) .. " LEFT")
			end
			if not v127.bar then
				continue
			end
			local v129 = v127.bar.set
			local v130 = 1 - v128 / v127.total
			local v131 = math.clamp(v130, 0, 1)
			pcall(v129, v131)
		end
		if v126 and v_u_27 then
			local v132 = v_u_27.modules
			if type(v132) == "table" and v_u_32 then
				task.defer(v_u_32, v125)
			end
		end
	end
	local function v_u_142(p134, p135, p136) -- name: recipesAt
		-- upvalues: (copy) v_u_23
		local v137 = {}
		local v138 = p135.recipes
		if type(v138) ~= "table" then
			local v139 = v_u_23.get(p134)
			v138 = {}
			for _, v140 in v139 and v139.recipes or {} do
				if v140.blueprint then
					continue
				end
				table.insert(v138, v140)
			end
		end
		for _, v141 in v138 do
			if v141.lvl ~= p136 then
				continue
			end
			table.insert(v137, v141)
		end
		return v137
	end
	local function v_u_232(p143, p144, p145, p146, p147) -- name: drawOverview
		-- upvalues: (copy) v_u_79, (copy) v_u_20, (copy) v_u_22, (copy) v_u_97, (ref) v_u_43, (copy) v_u_25, (copy) v_u_90, (copy) v_u_102, (copy) v_u_142, (ref) v_u_27, (copy) v_u_23
		local v148 = p146.lvl or 0
		local v149 = p146.maxLevel or #p145.levels
		local v150
		if p146.building == nil and p146.next == nil then
			v150 = v148 > 0
		else
			v150 = false
		end
		local v151 = p146.building ~= nil
		local v152
		if v151 then
			v152 = p146.building.target or v148 + 1
		else
			v152 = nil
		end
		local v153 = v_u_79(p143, "LevelHead", {
			["LayoutOrder"] = 1
		})
		v_u_20.layout(v153, "v", 6)
		local v154 = v_u_20.new("Frame", {
			["Name"] = "Top",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 40)
		}, v153)
		local v155 = v_u_20.label
		local v156 = {
			["parent"] = nil,
			["name"] = "Level",
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["size"] = nil,
			["parent"] = v154,
			["text"] = v148 <= 0 and "NOT BUILT" or ("LEVEL %d"):format(v148),
			["style"] = p147 and "h1" or "h2"
		}
		local v157
		if v148 > 0 then
			v157 = v_u_22.text
		else
			v157 = v_u_22.muted
		end
		v156.color = v157
		v156.size = UDim2.new(1, 0, 1, 0)
		v155(v156)
		local v158 = v_u_20.new("Frame", {
			["Name"] = "Pips",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.new(1, 0, 0, 6)
		}, v153)
		v_u_20.layout(v158, "h", 4)
		for v159 = 1, v149 do
			local v160 = v_u_20.new
			local v161 = "Frame"
			local v162 = {
				["Name"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Pip" .. v159,
				["Size"] = UDim2.new(1 / v149, -4, 1, 0)
			}
			local v163
			if v159 <= v148 then
				v163 = v_u_22.accent
			elseif v159 == v152 then
				v163 = v_u_22.accentDim
			else
				v163 = v_u_22.line
			end
			v162.BackgroundColor3 = v163
			v162.LayoutOrder = v159
			v160(v161, v162, v158)
		end
		local v164 = v_u_97(v153, "State", 3)
		if v150 then
			v_u_43.chip(v164, "FULLY UPGRADED", {
				["color"] = nil,
				["icon"] = "check",
				["order"] = 1,
				["color"] = v_u_22.success
			})
		elseif v151 then
			v_u_43.chip(v164, ("BUILDING LEVEL %d"):format(v152), {
				["color"] = nil,
				["icon"] = "clock",
				["order"] = 1,
				["color"] = v_u_22.accent
			})
		elseif p146.next and p146.next.canBuild then
			v_u_43.chip(v164, v_u_25.readyChip(v148), {
				["color"] = nil,
				["icon"] = "arrowUp",
				["order"] = 1,
				["color"] = v_u_22.accent
			})
		elseif v148 <= 0 then
			v_u_43.chip(v164, "NOT BUILT", {
				["color"] = nil,
				["icon"] = "lock",
				["order"] = 1,
				["color"] = v_u_22.muted
			})
		end
		local v165 = v_u_90(p143, "Now", 2, v148 > 0)
		local v166 = v_u_102
		local v167 = v148 > 0 and "ACTIVE NOW" or "WHEN BUILT"
		local v168 = 1
		local v169
		if v148 > 0 then
			v169 = v_u_22.accent
		else
			v169 = v_u_22.text2
		end
		v166(v165, v167, v168, v169)
		local v170
		if v148 > 0 and p145.levels[v148] then
			v170 = p145.levels[v148].desc
		else
			v170 = not p145.levels[1] and "" or p145.levels[1].desc
		end
		local v171 = v_u_20.label
		local v172 = {
			["parent"] = nil,
			["name"] = "Desc",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["track"] = false,
			["parent"] = v165,
			["text"] = v170
		}
		local v173
		if v148 > 0 then
			v173 = v_u_22.text
		else
			v173 = v_u_22.text2
		end
		v172.color = v173
		v171(v172)
		local v174 = v_u_79(p143, "Ladder", {
			["LayoutOrder"] = 3
		})
		v_u_20.layout(v174, "v", 0)
		v_u_102(v174, "LEVELS", 0)
		v_u_20.new("Frame", {
			["Name"] = "Gap",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 8)
		}, v174)
		for v175 = 1, v149 do
			local v176 = p145.levels[v175]
			local v177 = v175 <= v148
			local v178 = v152 == v175
			local v179 = not v177
			if v179 then
				v179 = v175 == v148 + 1
			end
			local v180 = v_u_79(v174, "Lvl" .. v175, {
				["LayoutOrder"] = v175 + 1
			})
			if v175 < v149 then
				local v181 = v_u_20.new
				local v182 = "Frame"
				local v183 = {
					["Name"] = "Line",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil
				}
				local v184
				if v175 < v148 then
					v184 = v_u_22.accentDim
				else
					v184 = v_u_22.line
				end
				v183.BackgroundColor3 = v184
				v183.Position = UDim2.fromOffset(8, 20)
				v183.Size = UDim2.new(0, 2, 1, -20)
				v181(v182, v183, v180)
			end
			local v185 = v_u_20.new
			local v186 = "Frame"
			local v187 = {
				["Name"] = "Node",
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Position"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["Size"] = UDim2.fromOffset(18, 18),
				["Position"] = UDim2.fromOffset(0, 0)
			}
			local v188
			if v177 then
				v188 = v_u_22.accent
			elseif v179 or v178 then
				v188 = v_u_22.accentDeep
			else
				v188 = v_u_22.raised
			end
			v187.BackgroundColor3 = v188
			local v189 = v185(v186, v187, v180)
			local v190 = v_u_20.stroke
			local v191
			if v177 or (v179 or v178) then
				v191 = v_u_22.accent
			else
				v191 = v_u_22.line
			end
			v190(v189, v191)
			local v192 = v_u_20.icon
			local v193 = v177 and "check" or (v178 and "clock" or (v179 and "arrowUp" or "lock"))
			local v194 = {
				["parent"] = nil,
				["size"] = 12,
				["color"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = v189
			}
			local v195
			if v177 then
				v195 = v_u_22.ink
			elseif v179 or v178 then
				v195 = v_u_22.accent
			else
				v195 = v_u_22.muted
			end
			v194.color = v195
			v194.position = UDim2.fromScale(0.5, 0.5)
			v194.anchor = Vector2.new(0.5, 0.5)
			v192(v193, v194)
			local v196 = v_u_79(v180, "Body", {
				["Position"] = UDim2.fromOffset(30, 0),
				["Size"] = UDim2.new(1, -30, 0, 0)
			})
			v_u_20.layout(v196, "v", 4)
			local v197 = Instance.new("UIPadding")
			v197.PaddingBottom = UDim.new(0, v175 < v149 and 14 or 0)
			v197.Parent = v196
			local v198 = v_u_20.new("Frame", {
				["Name"] = "Title",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 18)
			}, v196)
			local v199 = v_u_20.label
			local v200 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v198,
				["text"] = ("LEVEL %d"):format(v175)
			}
			local v201
			if v177 then
				v201 = v_u_22.accent
			elseif v179 or v178 then
				v201 = v_u_22.text
			else
				v201 = v_u_22.muted
			end
			v200.color = v201
			v200.size = UDim2.new(0, 70, 1, 0)
			v199(v200)
			local v202 = v178 and "BUILDING" or (v177 and "BUILT" or (v179 and "NEXT" or ""))
			if v202 ~= "" then
				local v203 = v_u_20.label
				local v204 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v198,
					["text"] = v202
				}
				local v205
				if v177 then
					v205 = v_u_22.muted
				else
					v205 = v_u_22.accent
				end
				v204.color = v205
				v204.size = UDim2.new(1, -74, 1, 0)
				v204.position = UDim2.fromOffset(74, 0)
				v203(v204)
			end
			local v206 = v_u_20.label
			local v207 = {
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["track"] = false,
				["parent"] = v196,
				["text"] = not v176 and "" or v176.desc
			}
			local v208
			if v177 then
				v208 = v_u_22.text2
			elseif v179 or v178 then
				v208 = v_u_22.text
			else
				v208 = v_u_22.muted
			end
			v207.color = v208
			v206(v207)
			local v209 = v_u_142(p144, p146, v175)
			if #v209 > 0 then
				local v210 = v_u_97(v196, "Unlocks", 3, 4)
				for v211, v212 in v209 do
					if v211 > 12 then
						break
					end
					v_u_43.cell(v210, v212.output.id, {
						["size"] = 36,
						["label"] = false,
						["order"] = nil,
						["name"] = nil,
						["locked"] = nil,
						["tip"] = nil,
						["order"] = v211,
						["name"] = "Unlock_" .. v212.id,
						["locked"] = not v177,
						["tip"] = {
							{
								["label"] = "Recipe",
								["value"] = nil,
								["value"] = v212.name
							},
							{
								["label"] = "Unlocks at",
								["value"] = nil,
								["value"] = ("Level %d"):format(v175)
							}
						}
					})
				end
			end
			local v213
			if v_u_27.partners == true and v176 then
				local v214 = v176.ep
				if type(v214) == "number" then
					v213 = v176.ep
				else
					v213 = nil
				end
			else
				v213 = nil
			end
			if v177 or not v176 or not (v176.requires and next(v176.requires) or v213) then
				continue
			end
			local v215 = v_u_97(v196, "Requires", 4, 4)
			local v216 = 0
			for v217, v218 in v176.requires or {} do
				v216 = v216 + 1
				local v219 = v218 <= (v_u_27.modules[v217] and (v_u_27.modules[v217].lvl or 0) or 0)
				local v220 = v_u_43.chip
				local v221 = "%s %d"
				local v222 = v_u_23
				if v222 then
					v222 = v_u_23.get(v217)
				end
				local v223
				if v222 then
					v223 = v222.name
				else
					v223 = string.upper(v217)
				end
				local v224 = v221:format(v223, v218)
				local v225 = {
					["color"] = nil,
					["icon"] = nil,
					["order"] = nil,
					["height"] = 18
				}
				local v226
				if v219 then
					v226 = v_u_22.success
				elseif v179 then
					v226 = v_u_22.danger
				else
					v226 = v_u_22.muted
				end
				v225.color = v226
				v225.icon = v219 and "check" or "lock"
				v225.order = v216
				v220(v215, v224, v225)
			end
			if not v213 then
				break
			end
			local v227
			if v179 then
				if p146.next == nil or p146.next.missing == nil then
					v227 = false
				else
					v227 = p146.next.missing.ep ~= nil
				end
			else
				v227 = v179
			end
			local v228 = v_u_43.chip
			local v229 = v_u_25.epChip(v213)
			local v230 = {
				["color"] = nil,
				["icon"] = nil,
				["order"] = nil,
				["height"] = 18
			}
			local v231
			if v179 then
				if v227 then
					v231 = v_u_22.danger
				else
					v231 = v_u_22.success
				end
			else
				v231 = v_u_22.muted
			end
			v230.color = v231
			v230.icon = v179 and not v227 and "check" or "lock"
			v230.order = v216 + 1
			v228(v215, v229, v230)
		end
		if p147 then
			v_u_20.label({
				["parent"] = nil,
				["name"] = "Flavour",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 9,
				["track"] = false,
				["parent"] = p143,
				["text"] = p145.desc,
				["color"] = v_u_22.muted
			})
		end
	end
	local function v_u_249(p233) -- name: buildReason
		-- upvalues: (copy) v_u_23, (copy) v_u_20, (copy) v_u_25, (ref) v_u_43
		if p233.canBuild then
			return nil
		end
		local v234 = p233.missing or {}
		local v235 = {}
		for _, v236 in v234.requires or {} do
			local v237 = "Needs %s level %d"
			local v238 = v236.module
			local v239 = v_u_23
			if v239 then
				v239 = v_u_23.get(v238)
			end
			local v240
			if v239 then
				v240 = v239.name
			else
				v240 = string.upper(v238)
			end
			local v241 = v236.lvl
			table.insert(v235, v237:format(v240, v241))
		end
		if v234.ep then
			local v242 = v234.ep.need
			local v243 = v234.ep.have
			table.insert(v235, ("Needs %d mission points (EP), you have %d"):format(v242, v243))
		end
		if v234.cash then
			local v244 = v_u_20.commas
			local v245 = v234.cash
			table.insert(v235, ("$%s short"):format(v244(v245)))
		end
		for _, v246 in v234.items or {} do
			local v247 = v_u_25.missingItem
			local v248 = v_u_43.name
			table.insert(v235, v247(v246, v248))
		end
		return #v235 <= 0 and "Not possible right now" or table.concat(v235, "\n")
	end
	local function v_u_405(p250, p_u_251, p252, p253, p254, p255) -- name: drawUpgrade
		-- upvalues: (ref) v_u_43, (copy) v_u_90, (copy) v_u_20, (copy) v_u_22, (copy) v_u_124, (ref) v_u_18, (copy) v_u_79, (copy) v_u_102, (copy) v_u_142, (copy) v_u_97, (ref) v_u_27, (copy) v_u_23, (copy) v_u_25, (copy) v_u_249, (ref) v_u_358, (copy) v_u_21, (copy) p_u_19
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v320, v321, v322, v_u_323, v324, v325, v326, v327, v_u_328, v329, v330, v331, v332, v333, v334, v335, v_u_336, v337, v338, v339, v_u_340, v341, v342, v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v_u_359, v360, v361, v362, v363, v_u_364, v365, v366, v367, v368, v369, v_u_370, v371, v372, v373, v374, v_u_375, v376, v377, v378, v379, v380, v381, v382, v383, v384
		local v320, v321, v322, v_u_323, v324, v325, v326, v327, v_u_328, v329, v330, v331, v332, v333, v334, v335, v_u_336, v337, v338, v339, v_u_340, v341, v342, v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v_u_358, v_u_359, v360, v361, v362, v363, v_u_364, v365, v366, v367, v368, v369, v_u_370, v371, v372, v373, v374, v_u_375, v376, v377, v378, v379, v380, v381, v382, v383, v384
		local v385 = 4
		while true do
			if v385 == 1 then
				v331 = v_u_375.ep
				if type(v331) == "number" then
					v385 = 2
				else
					v385 = 3
				end
			elseif v385 == 2 then
				v332 = v_u_79(v341, "Requires", {
					["LayoutOrder"] = 3
				})
				v_u_20.layout(v332, "v", 6)
				v_u_102(v332, "REQUIRES", 1)
				v337 = v_u_97(v332, "Chips", 2, 6)
				v371 = 0
				for v386, v387 in v344 do
					v371 = v371 + 1
					v372 = v_u_27.modules[v386] and (v_u_27.modules[v386].lvl or 0) or 0
					v338 = v387 <= v372
					v339 = v_u_43.chip
					v373 = "%s LEVEL %d"
					v355 = v_u_23
					if v355 then
						v355 = v_u_23.get(v386)
					end
					if v355 then
						v322 = v355.name
					else
						v322 = string.upper(v386)
					end
					v356 = v373:format(v322, v387)
					v357 = {
						["color"] = nil,
						["icon"] = nil,
						["order"] = nil,
						["height"] = 26
					}
					if v338 then
						v327 = v_u_22.success
					else
						v327 = v_u_22.danger
					end
					v357.color = v327
					v357.icon = v338 and "check" or "lock"
					v357.order = v371
					v362 = v339(v337, v356, v357)
					if v338 then
						v_u_340 = "Built."
					else
						v374 = "Your %s is at level %d."
						v348 = string.lower
						v349 = v_u_23
						if v349 then
							v349 = v_u_23.get(v386)
						end
						if v349 then
							v378 = v349.name
						else
							v378 = string.upper(v386)
						end
						v_u_340 = v374:format(v348(v378), v372)
					end
					v_u_20.tooltip(v362, function()
						-- upvalues: (copy) v_u_340
						return v_u_340
					end)
				end
				v379 = v_u_375.ep
				if type(v379) == "number" then
					v352 = v_u_375.missing
					if v352 then
						v352 = v_u_375.missing.ep
					end
					v321 = v_u_43.chip
					v353 = v_u_25.epChip(v_u_375.ep)
					v354 = {
						["color"] = nil,
						["icon"] = nil,
						["order"] = nil,
						["height"] = 26
					}
					if v352 then
						v345 = v_u_22.danger
					else
						v345 = v_u_22.success
					end
					v354.color = v345
					v354.icon = v352 and "lock" or "check"
					v354.order = v371 + 1
					v377 = v321(v337, v353, v354)
					v346 = v_u_25.epTip
					v347 = v_u_375.ep
					if v352 then
						v363 = v352.have
					else
						v363 = nil
					end
					v_u_364 = v346(v347, v363, v352 == nil)
					v_u_20.tooltip(v377, function()
						-- upvalues: (copy) v_u_364
						return v_u_364
					end)
				end
				v385 = 3
			elseif v385 == 3 then
				v333 = v_u_79(v341, "Cost", {
					["LayoutOrder"] = 4
				})
				v_u_20.layout(v333, "v", 6)
				v_u_102(v333, "COST", 1)
				v334 = v_u_97(v333, "Tiles", 2, 8)
				v350 = v_u_375.missing or {}
				v351 = {}
				for _, v388 in v350.items or {} do
					v351[v388.id] = v388
				end
				v380 = v_u_375.cost and (v_u_375.cost.cash or 0) or 0
				v381 = v_u_43.hasStock()
				v382 = v_u_375.lines
				if type(v382) == "table" then
					v383 = #v_u_375.lines > 0
				else
					v383 = false
				end
				if v383 then
					v334.Visible = false
					v384 = v_u_79(v333, "CostRows", {
						["LayoutOrder"] = 3
					})
					v_u_20.layout(v384, "v", 4)
					for v389, v390 in v_u_375.lines do
						v320 = v_u_25.costRow(v390, v_u_43.name)
						v365 = v_u_20.new("Frame", {
							["Name"] = nil,
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Name"] = "CostRow" .. v389,
							["Size"] = UDim2.new(1, 0, 0, v320.note and 38 or 24),
							["LayoutOrder"] = v389
						}, v384)
						v_u_20.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v365,
							["text"] = v320.name,
							["color"] = v_u_22.text,
							["size"] = UDim2.new(0.58, 0, 0, 20)
						})
						v366 = v_u_20.label
						v367 = {
							["parent"] = nil,
							["name"] = "Count",
							["text"] = nil,
							["style"] = "monoS",
							["color"] = nil,
							["align"] = "right",
							["size"] = nil,
							["position"] = nil,
							["track"] = false,
							["parent"] = v365,
							["text"] = v320.right
						}
						if v320.ok then
							v368 = v_u_22.success
						else
							v368 = v_u_22.danger
						end
						v367.color = v368
						v367.size = UDim2.new(0.42, 0, 0, 20)
						v367.position = UDim2.fromScale(0.58, 0)
						v366(v367)
						if not v320.note then
							continue
						end
						v_u_20.label({
							["parent"] = nil,
							["name"] = "Note",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["size"] = nil,
							["position"] = nil,
							["track"] = false,
							["parent"] = v365,
							["text"] = v320.note,
							["color"] = v_u_22.muted,
							["size"] = UDim2.new(1, 0, 0, 16),
							["position"] = UDim2.fromOffset(0, 20)
						})
					end
				end
				if v380 > 0 and not v383 then
					v_u_43.cashChip(v334, v380, v350.cash, 1, 64)
				end
				for v391, v392 in (v383 or not v_u_375.cost) and {} or (v_u_375.cost.items or {}) do
					v_u_43.cell(v334, v392.id, {
						["size"] = 64,
						["label"] = false,
						["caption"] = true,
						["order"] = nil,
						["name"] = nil,
						["count"] = nil,
						["need"] = nil,
						["haveKnown"] = nil,
						["missing"] = nil,
						["wish"] = true,
						["order"] = 1 + v391,
						["name"] = "Cost_" .. v392.id,
						["count"] = v392.n,
						["need"] = v392.n,
						["haveKnown"] = v381,
						["missing"] = v351[v392.id] ~= nil
					})
				end
				if not v_u_375.canBuild then
					v_u_20.label({
						["parent"] = nil,
						["name"] = "Note",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 5,
						["track"] = false,
						["parent"] = v341,
						["text"] = v_u_25.buildWhy(v_u_375),
						["color"] = v_u_22.text2
					})
				end
				v335 = v_u_249(v_u_375)
				v_u_336 = v_u_25.rush(v_u_27, v_u_375)
				if v_u_336.chip then
					v369 = v_u_43.chip(v341, v_u_336.chip, {
						["color"] = nil,
						["icon"] = "clock",
						["order"] = 6,
						["height"] = 24,
						["name"] = "RushVoucher",
						["color"] = v_u_22.accent
					})
					v_u_370 = v_u_336.tip
					v_u_20.tooltip(v369, function()
						-- upvalues: (copy) v_u_370
						return v_u_370
					end)
				end
				v_u_323, v324 = v_u_20.button({
					["parent"] = nil,
					["name"] = "Build",
					["text"] = nil,
					["kind"] = nil,
					["size"] = nil,
					["disabled"] = nil,
					["onClick"] = nil,
					["parent"] = v341,
					["text"] = v325 <= 0 and "BUILD" or ("BUILD LEVEL %d"):format(v_u_375.lvl),
					["kind"] = v_u_375.canBuild and not v_u_358 and "primary" or "secondary",
					["size"] = UDim2.new(1, 0, 0, v_u_21.touch(44)),
					["disabled"] = not v_u_375.canBuild,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_375, (copy) v_u_336, (ref) p_u_19, (copy) p_u_251, (ref) v_u_20, (ref) v_u_25, (ref) v_u_43
						if v_u_375.confirm == true then
							local v393 = {
								{
									["text"] = "Cancel",
									["kind"] = "secondary"
								}
							}
							if v_u_336.willUse then
								local v395 = {
									["text"] = "Keep voucher",
									["kind"] = "secondary",
									["onClick"] = nil,
									["onClick"] = function() -- name: onClick
										-- upvalues: (ref) p_u_19, (ref) p_u_251
										local v394 = {
											["module"] = nil,
											["keepRush"] = true,
											["confirm"] = true,
											["module"] = p_u_251
										}
										p_u_19.act("hideoutBuild", v394)
									end
								}
								table.insert(v393, v395)
							end
							local v397 = {
								["text"] = "Build",
								["kind"] = "primary",
								["onClick"] = nil,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) p_u_19, (ref) p_u_251
									local v396 = {
										["module"] = nil,
										["confirm"] = true,
										["module"] = p_u_251
									}
									p_u_19.act("hideoutBuild", v396)
								end
							}
							table.insert(v393, v397)
							v_u_20.modal({
								["title"] = nil,
								["body"] = nil,
								["width"] = 460,
								["buttons"] = nil,
								["title"] = v_u_25.confirmTitle(v_u_375),
								["body"] = v_u_25.confirmBody(v_u_375, v_u_43.name, v_u_336),
								["buttons"] = v393
							})
							return
						elseif v_u_336.short and v_u_336.askTitle then
							local v398 = v_u_20.modal
							local v401 = {
								["title"] = nil,
								["body"] = nil,
								["width"] = 460,
								["buttons"] = nil,
								["title"] = v_u_336.askTitle,
								["body"] = v_u_336.askBody,
								["buttons"] = {
									{
										["text"] = "Keep it",
										["kind"] = "secondary",
										["onClick"] = nil,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) p_u_19, (ref) p_u_251
											local v399 = {
												["module"] = nil,
												["keepRush"] = true,
												["module"] = p_u_251
											}
											p_u_19.act("hideoutBuild", v399)
										end
									},
									{
										["text"] = "Use it",
										["kind"] = "primary",
										["onClick"] = nil,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) p_u_19, (ref) p_u_251
											local v400 = {
												["module"] = p_u_251
											}
											p_u_19.act("hideoutBuild", v400)
										end
									}
								}
							}
							v398(v401)
						else
							local v402 = {
								["module"] = p_u_251
							}
							p_u_19.act("hideoutBuild", v402)
						end
					end
				})
				v_u_323.LayoutOrder = 7
				if v_u_375.canBuild then
					v_u_358 = true
				end
				if v324 and v324.setEnabled then
					v324.setEnabled(v_u_375.canBuild == true)
				end
				if v335 then
					v_u_359 = {
						["title"] = "NOT YET",
						["body"] = nil,
						["color"] = nil,
						["body"] = v335,
						["color"] = v_u_22.danger
					}
					v_u_20.tooltip(v_u_323, function()
						-- upvalues: (copy) v_u_359
						return v_u_359
					end)
					v_u_323.SelectionGained:Connect(function()
						-- upvalues: (ref) v_u_20, (copy) v_u_323
						v_u_20.showTooltip(v_u_323)
					end)
				elseif v_u_323 and not p255[1] then
					v_u_323:SetAttribute("PadDefault", true)
					p255[1] = true
				end
				break
			else
				v325 = p253.lvl or 0
				if p253.building then
					v360 = p253.building.target or v325 + 1
					v326 = v_u_90(v_u_43.section(p250, v325 <= 0 and "BUILD" or "UPGRADE", p254), "Upgrade", 2, true)
					v_u_20.label({
						["parent"] = nil,
						["name"] = "Title",
						["text"] = nil,
						["style"] = "h3",
						["order"] = 1,
						["size"] = nil,
						["parent"] = v326,
						["text"] = v325 <= 0 and "BUILDING THE STATION" or ("UPGRADING TO LEVEL %d"):format(v360),
						["size"] = UDim2.new(1, 0, 0, 24)
					})
					v361 = p252.levels[v360]
					if v361 then
						v_u_20.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["track"] = false,
							["parent"] = v326,
							["text"] = v361.desc,
							["color"] = v_u_22.text2
						})
					end
					v_u_124(v326, p253.building.untilAt, not v361 and 60 or v361.time, 3, "FINISHING...")
					return
				end
				v_u_375 = p253.next
				if not v_u_375 then
					return
				end
				v341 = v_u_90(v_u_43.section(p250, v325 <= 0 and "BUILD" or "UPGRADE", p254), "Upgrade", 2, false)
				v342 = v_u_20.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 26)
				}, v341)
				v_u_20.label({
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "h3",
					["size"] = nil,
					["parent"] = v342,
					["text"] = v325 <= 0 and "BUILD THE STATION" or ("LEVEL %d  >  LEVEL %d"):format(v325, v_u_375.lvl),
					["size"] = UDim2.new(1, -120, 1, 0)
				})
				v376 = v_u_43.chip(nil, v_u_18(v_u_375.time or 0), {
					["color"] = nil,
					["icon"] = "clock",
					["style"] = "monoS",
					["track"] = false,
					["color"] = v_u_22.text2
				})
				v376.AnchorPoint = Vector2.new(1, 0.5)
				v376.Position = UDim2.new(1, 0, 0.5, 0)
				v376.Parent = v342
				v_u_328 = "Build time. It keeps running while you raid or are offline."
				v_u_20.tooltip(v376, function()
					-- upvalues: (copy) v_u_328
					return v_u_328
				end)
				v329 = v_u_79(v341, "Unlocks", {
					["LayoutOrder"] = 2
				})
				v_u_20.layout(v329, "v", 4)
				v_u_102(v329, "UNLOCKS", 1)
				v_u_20.label({
					["parent"] = nil,
					["name"] = "Desc",
					["text"] = nil,
					["style"] = "bodyStrong",
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = v329,
					["text"] = v_u_375.desc
				})
				v330 = v_u_142(p_u_251, p253, v_u_375.lvl)
				if #v330 > 0 then
					v343 = v_u_97(v329, "Recipes", 3, 4)
					for v403, v404 in v330 do
						if v403 > 10 then
							break
						end
						v_u_43.cell(v343, v404.output.id, {
							["size"] = 48,
							["label"] = false,
							["order"] = nil,
							["name"] = nil,
							["tip"] = nil,
							["order"] = v403,
							["name"] = "New_" .. v404.id,
							["tip"] = {
								{
									["label"] = "Recipe",
									["value"] = nil,
									["value"] = v404.name
								}
							}
						})
					end
				end
				v344 = v_u_375.requires or {}
				if next(v344) then
					v385 = 2
				else
					v385 = 1
				end
			end
		end
	end
	local function v_u_420(p406, p407) -- name: craftReason
		-- upvalues: (copy) v_u_25, (ref) v_u_26, (copy) v_u_23, (ref) v_u_43
		if p406.canCraft then
			return nil
		end
		if not p406.locked then
			local v408
			if p407.slots == nil then
				v408 = p407.craft ~= nil
			else
				v408 = p407.slotsFull == true
			end
			if v408 then
				return (p407.slots or 1) >= 2 and "Both craft slots are busy: collect a finished craft or wait." or "One craft at a time: collect the running one first."
			end
			local v409 = {}
			for _, v410 in p406.inputs do
				local v411 = v_u_43.have(v410.id)
				if not v_u_43.hasStock() or v411 >= v410.n then
					continue
				end
				local v412 = v410.n - v411
				local v413 = v_u_43.name(v410.id)
				table.insert(v409, ("%d x %s missing (you have %d)"):format(v412, v413, v411))
			end
			return #v409 == 0 and "Missing materials." or table.concat(v409, "\n")
		end
		local v414 = v_u_25.lockedReason
		local v415 = p407.lvl or 0
		local v416 = p406.lvl
		local v417 = v_u_26 or ""
		local v418 = v_u_23
		if v418 then
			v418 = v_u_23.get(v417)
		end
		local v419
		if v418 then
			v419 = v418.name
		else
			v419 = string.upper(v417)
		end
		return v414(v415, v416, v419)
	end
	local function v_u_445(p421, p_u_422, p423, p_u_424, p425, p_u_426) -- name: runningCard
		-- upvalues: (ref) v_u_27, (copy) v_u_90, (copy) v_u_20, (ref) v_u_358, (copy) v_u_21, (copy) p_u_19, (copy) v_u_97, (ref) v_u_43, (copy) v_u_22, (copy) v_u_124, (copy) v_u_23, (copy) v_u_79
		local v427 = 0.1
		local v428 = v_u_27.effects
		if v428 then
			v428 = v_u_27.effects.craftSpeed
		end
		local v429 = tonumber(v428) or 1
		local v430 = math.max(v427, v429)
		local v_u_431 = v_u_90(p421, "Running" .. (p_u_424 <= 1 and "" or tostring(p_u_424)), p425, true)
		local function v436(p432) -- name: collectButton
			-- upvalues: (ref) v_u_20, (copy) v_u_431, (ref) v_u_358, (ref) v_u_21, (ref) p_u_19, (copy) p_u_422, (copy) p_u_424, (copy) p_u_426
			local v434 = v_u_20.button({
				["parent"] = nil,
				["name"] = "Collect",
				["text"] = "COLLECT",
				["kind"] = nil,
				["size"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_431,
				["kind"] = v_u_358 and "secondary" or "primary",
				["size"] = UDim2.new(1, 0, 0, v_u_21.touch(40)),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_19, (ref) p_u_422, (ref) p_u_424
					local v433 = {
						["module"] = p_u_422,
						["slot"] = p_u_424
					}
					p_u_19.act("hideoutCollect", v433)
				end
			})
			v434.LayoutOrder = p432
			v_u_358 = true
			local v435 = p_u_426
			if v434 and not v435[1] then
				v434:SetAttribute("PadDefault", true)
				v435[1] = true
			end
		end
		if p423.kind == "dismantle" then
			v_u_20.label({
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h3",
				["order"] = 1,
				["size"] = nil,
				["parent"] = v_u_431,
				["text"] = p423.name or "DISMANTLING",
				["size"] = UDim2.new(1, 0, 0, 24)
			})
			local v437 = v_u_97(v_u_431, "Pieces", 2, 6)
			local v438 = p423.outputs
			for v439, v440 in type(v438) ~= "table" and {} or p423.outputs do
				v_u_43.cell(v437, v440.id, {
					["size"] = 48,
					["label"] = false,
					["count"] = nil,
					["order"] = nil,
					["name"] = nil,
					["count"] = v440.n,
					["order"] = v439,
					["name"] = "Out_running_" .. v439
				})
			end
			if p423.ready then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "READY TO COLLECT",
					["style"] = "caps",
					["color"] = nil,
					["order"] = 3,
					["size"] = nil,
					["parent"] = v_u_431,
					["color"] = v_u_22.success,
					["size"] = UDim2.new(1, 0, 0, 16)
				})
				v436(4)
			else
				v_u_124(v_u_431, p423.readyAt, p423.total or 60, 3, "READY", "")
			end
		else
			local v441 = v_u_20.new("Frame", {
				["Name"] = "Row",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 64)
			}, v_u_431)
			local v442 = p423.output or (v_u_23.recipe(p_u_422, p423.recipe) or {}).output
			if v442 then
				v_u_43.cell(v441, v442.id, {
					["size"] = 64,
					["label"] = false,
					["count"] = nil,
					["name"] = "Out_running",
					["count"] = v442.n
				})
			end
			local v443 = v_u_79(v441, "Info", {
				["Position"] = UDim2.fromOffset(78, 0),
				["Size"] = UDim2.new(1, -78, 0, 0)
			})
			v_u_20.layout(v443, "v", 4)
			v_u_20.label({
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h3",
				["order"] = 1,
				["size"] = nil,
				["parent"] = v443,
				["text"] = p423.name or p423.recipe,
				["size"] = UDim2.new(1, 0, 0, 24)
			})
			if p423.ready then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "READY TO COLLECT",
					["style"] = "caps",
					["color"] = nil,
					["order"] = 2,
					["size"] = nil,
					["parent"] = v443,
					["color"] = v_u_22.success,
					["size"] = UDim2.new(1, 0, 0, 16)
				})
				v436(2)
			else
				local v444 = v_u_23.recipe(p_u_422, p423.recipe)
				v_u_124(v443, p423.readyAt, p423.total or (not v444 and 60 or v444.time / v430), 2, "READY", "")
			end
		end
	end
	local function v_u_498(p446, p447, p448) -- name: drawDismantle
		-- upvalues: (ref) v_u_27, (copy) p_u_19, (copy) v_u_20, (copy) v_u_22, (copy) v_u_25, (ref) v_u_43, (copy) v_u_79, (ref) v_u_14, (copy) v_u_21, (ref) v_u_18, (copy) v_u_97
		local v449 = (v_u_27.effects or {}).dismantleBonus
		local v450 = tonumber(v449) or 0
		local function v451()
			-- upvalues: (ref) p_u_19
			return p_u_19.cctx.shared.Dismantle
		end
		local v452, v453 = pcall(v451)
		local v454 = "Break stash items down into materials. It uses a craft slot and costs no cash. An item worn below 50 % gives one piece less of its main material."
		if v450 > 0 then
			v454 = v454 .. " Your workbench adds 50 % more of the main material."
		end
		v_u_20.label({
			["parent"] = nil,
			["name"] = "Note",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 10,
			["track"] = false,
			["parent"] = p446,
			["text"] = v454,
			["color"] = v_u_22.text2
		})
		if v452 and type(v453) == "table" then
			local v455 = p_u_19.hooks
			local v456
			if type(v455) == "table" then
				v456 = v455.dismantleItems
			else
				v456 = nil
			end
			local v457 = v453.candidates(not v456 and {} or v456(), {
				["bonus"] = v450
			})
			if #v457 == 0 then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "Nothing in your stash can be dismantled yet. Clothing, boots, vests, bags, electronics, pistols, rifles and ammunition can.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 11,
					["track"] = false,
					["parent"] = p446,
					["color"] = v_u_22.text2
				})
			else
				local v458
				if p447.slots == nil then
					v458 = p447.craft ~= nil
				else
					v458 = p447.slotsFull == true
				end
				local v459 = v_u_25.benchState(p447, os.time() + (v_u_27 and v_u_27.offset or 0))
				for v460, v_u_461 in v457 do
					if v460 > 40 then
						v_u_20.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["track"] = false,
							["parent"] = p446,
							["text"] = ("Showing the first 40 of %d. Dismantle some to see the rest."):format(#v457),
							["color"] = v_u_22.muted,
							["order"] = 20 + v460
						})
						return
					end
					local v462 = v_u_461.plan
					local v463 = v_u_43.def(v_u_461.id)
					local v464
					if v463 == nil then
						v464 = false
					else
						v464 = (v463.w or 1) > (v463.h or 1)
					end
					local v465 = v_u_79
					local v466 = v_u_461.uid
					local v467 = v465(p446, "Dismantle_" .. tostring(v466), {
						["BackgroundColor3"] = v_u_22.raised,
						["BackgroundTransparency"] = v462.ok and 0.2 or 0.55,
						["LayoutOrder"] = 20 + v460
					})
					v_u_20.stroke(v467, v_u_22.line)
					v_u_20.pad(v467, {
						12,
						12,
						8,
						10
					})
					v_u_20.layout(v467, "v", 6)
					local v468 = v_u_20.new("Frame", {
						["Name"] = "Head",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 20)
					}, v467)
					local v469 = v_u_43.name(v_u_461.id)
					if v_u_461.group == "ammo" then
						v469 = v469 .. ("  x%d"):format(v_u_461.n)
					end
					local v470 = v_u_20.label
					local v471 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v468,
						["text"] = v469
					}
					local v472
					if v462.ok then
						v472 = v_u_22.text
					else
						v472 = v_u_22.muted
					end
					v471.color = v472
					v471.size = UDim2.new(1, -84, 1, 0)
					v470(v471)
					if v462.ok then
						local v473 = v_u_20.new("Frame", {
							["Name"] = "Time",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = UDim2.fromOffset(74, 20),
							["AnchorPoint"] = Vector2.new(1, 0),
							["Position"] = UDim2.new(1, 0, 0, 0)
						}, v468)
						v_u_20.icon("clock", {
							["parent"] = nil,
							["size"] = 12,
							["color"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["parent"] = v473,
							["color"] = v_u_22.muted,
							["position"] = UDim2.new(0, 0, 0.5, 0),
							["anchor"] = Vector2.new(0, 0.5)
						})
						v_u_20.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "monoS",
							["color"] = nil,
							["align"] = "right",
							["size"] = nil,
							["position"] = nil,
							["track"] = false,
							["parent"] = v473,
							["text"] = v_u_14(v462.seconds),
							["color"] = v_u_22.text2,
							["size"] = UDim2.new(1, -16, 1, 0),
							["position"] = UDim2.fromOffset(16, 0)
						})
					end
					local v474 = v_u_20.new("Frame", {
						["Name"] = "Line",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 2,
						["Size"] = UDim2.new(1, 0, 0, 56)
					}, v467)
					local v475 = v_u_20.new("Frame", {
						["Name"] = "Tiles",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["Size"] = UDim2.new(1, -142, 1, 0)
					}, v474)
					v_u_20.layout(v475, "h", 8).VerticalAlignment = Enum.VerticalAlignment.Center
					if v462.ok then
						for v476, v477 in v462.outputs do
							v_u_43.cell(v475, v477.id, {
								["size"] = 40,
								["label"] = false,
								["order"] = nil,
								["name"] = nil,
								["count"] = nil,
								["output"] = true,
								["order"] = v476,
								["name"] = "Out_" .. v477.id,
								["count"] = v477.n
							})
						end
						v_u_43.arrow(v475, 50, 40)
					end
					local v478 = v_u_43.cell
					local v479 = v_u_461.id
					local v480 = {
						["size"] = 52,
						["w"] = nil,
						["label"] = false,
						["order"] = 60,
						["name"] = "Item",
						["known"] = true,
						["count"] = nil,
						["w"] = v464 and 2 or 1
					}
					local v481
					if v_u_461.group == "ammo" then
						if v462.ok then
							v481 = v462.take
						else
							v481 = v_u_461.n
						end
					else
						v481 = nil
					end
					v480.count = v481
					v478(v475, v479, v480)
					local v482 = v_u_20.new("Frame", {
						["Name"] = "Action",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = UDim2.new(1, 0, 0, 0),
						["Size"] = UDim2.new(0, 130, 1, 0)
					}, v474)
					if v462.ok and not v458 then
						local v_u_483 = nil
						local v484, v485 = v_u_20.button({
							["parent"] = nil,
							["name"] = "Dismantle",
							["text"] = "DISMANTLE",
							["kind"] = "secondary",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["onClick"] = nil,
							["parent"] = v482,
							["size"] = UDim2.new(1, 0, 0, v_u_21.touch(40)),
							["position"] = UDim2.new(1, 0, 0.5, 0),
							["anchor"] = Vector2.new(1, 0.5),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_483, (ref) p_u_19, (copy) v_u_461
								if v_u_483 and v_u_483.setEnabled then
									v_u_483.setEnabled(false)
								end
								p_u_19.act("dismantle", {
									["uid"] = v_u_461.uid
								})
							end
						})
						v_u_483 = v485
						local v_u_486 = {
							["title"] = "DISMANTLE",
							["body"] = nil,
							["body"] = ("Uses %s and makes the materials shown. Ready in %s."):format(v_u_461.group ~= "ammo" and "the item" or ("%d rounds"):format(v462.take), string.lower(v_u_18(v462.seconds)))
						}
						v_u_20.tooltip(v484, function()
							-- upvalues: (copy) v_u_486
							return v_u_486
						end)
						if v484 and not p448[1] then
							v484:SetAttribute("PadDefault", true)
							p448[1] = true
						end
					else
						local v487 = v_u_20.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = nil,
							["style"] = "caps",
							["color"] = nil,
							["align"] = "right",
							["track"] = false,
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["parent"] = v482,
							["text"] = not v462.ok and "BLOCKED" or v459.label,
							["color"] = v_u_22.muted,
							["size"] = UDim2.new(1, 0, 0, 20),
							["position"] = UDim2.new(1, 0, 0.5, 0),
							["anchor"] = Vector2.new(1, 0.5)
						})
						v487.TextTruncate = Enum.TextTruncate.AtEnd
						local v_u_488 = {
							["title"] = not v462.ok and "BLOCKED" or v459.label
						}
						local v489
						if v462.ok then
							v489 = v459.hint
						else
							v489 = v_u_25.blockedBody(v462.reason)
						end
						v_u_488.body = v489
						v_u_20.tooltip(v487, function()
							-- upvalues: (copy) v_u_488
							return v_u_488
						end)
					end
					local v490 = v_u_97(v467, "Tags", 3, 4)
					local v491 = 0
					local v492 = v_u_461.dur
					if type(v492) == "number" then
						v491 = v491 + 1
						local v493 = v_u_43.chip
						local v494 = v_u_461.dur * 100 + 0.5
						local v495 = ("CONDITION %d %%"):format((math.floor(v494)))
						local v496 = {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil
						}
						local v497
						if v_u_461.dur < 0.5 then
							v497 = v_u_22.danger
						else
							v497 = v_u_22.text2
						end
						v496.color = v497
						v496.order = v491
						v493(v490, v495, v496)
					end
					if v462.ok and v462.dropped then
						v491 = v491 + 1
						v_u_43.chip(v490, "UNDER 50 %: 1 PIECE LESS", {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil,
							["color"] = v_u_22.danger,
							["order"] = v491
						})
					end
					if v462.ok and (v462.bonusPieces or 0) > 0 then
						v491 = v491 + 1
						v_u_43.chip(v490, ("WORKBENCH 4: +%d"):format(v462.bonusPieces), {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil,
							["color"] = v_u_22.success,
							["order"] = v491
						})
					end
					if v462.ok and v_u_461.group == "ammo" then
						v491 = v491 + 1
						v_u_43.chip(v490, ("%d OF %d ROUNDS USED"):format(v462.take, v_u_461.n), {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil,
							["color"] = v_u_22.text2,
							["order"] = v491
						})
					end
					if v462.ok and v458 then
						v491 = v491 + 1
						v_u_43.chip(v490, v459.hint, {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil,
							["color"] = v_u_22.text2,
							["order"] = v491
						})
					end
					if not v462.ok and v462.reason then
						v491 = v491 + 1
						v_u_43.chip(v490, v462.reason, {
							["color"] = nil,
							["height"] = 18,
							["order"] = nil,
							["color"] = v_u_22.danger,
							["order"] = v491
						})
					end
					if v491 ~= 0 then
						continue
					end
					v490:Destroy()
				end
			end
		else
			v_u_20.label({
				["parent"] = nil,
				["text"] = "Dismantling is not available right now.",
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 11,
				["track"] = false,
				["parent"] = p446,
				["color"] = v_u_22.text2
			})
			return
		end
	end
	local function v_u_560(p499, p_u_500, p501, p502, p503) -- name: drawCrafting
		-- upvalues: (copy) v_u_25, (ref) v_u_43, (copy) v_u_445, (copy) v_u_20, (ref) v_u_41, (copy) v_u_21, (ref) v_u_42, (copy) v_u_498, (copy) v_u_22, (copy) v_u_79, (ref) v_u_18, (copy) v_u_420, (ref) v_u_358, (copy) p_u_19, (copy) v_u_23
		local v504 = table.clone(p501.recipes or {})
		local v505 = 0
		for _, v506 in v504 do
			if not v506.canCraft then
				continue
			end
			v505 = v505 + 1
		end
		local v507 = v_u_25.canMakeHeader(v505, #v504, p501.slots)
		local v508 = v_u_43.section(p499, "CRAFTING", p502, v507)
		if p501.craft then
			v_u_445(v508, p_u_500, p501.craft, 1, 2, p503)
		end
		if p501.craft2 then
			v_u_445(v508, p_u_500, p501.craft2, 2, 3, p503)
		end
		if p_u_500 == "workbench" and p501.dismantle == true then
			v_u_20.tabs({
				["parent"] = nil,
				["name"] = "BenchTabs",
				["tabs"] = nil,
				["selected"] = nil,
				["size"] = nil,
				["onChange"] = nil,
				["parent"] = v508,
				["tabs"] = {
					{
						["id"] = "craft",
						["text"] = "CRAFT"
					},
					{
						["id"] = "dismantle",
						["text"] = "DISMANTLE"
					}
				},
				["selected"] = v_u_41,
				["size"] = UDim2.new(1, 0, 0, v_u_21.touch(34)),
				["onChange"] = function(p509) -- name: onChange
					-- upvalues: (ref) v_u_41, (ref) v_u_42
					v_u_41 = p509
					if v_u_42 then
						v_u_42()
					end
				end
			}).LayoutOrder = 5
			if v_u_41 == "dismantle" then
				v_u_498(v508, p501, p503)
				return
			end
		end
		if #v504 == 0 then
			v_u_20.label({
				["parent"] = nil,
				["text"] = "No recipes yet.",
				["style"] = "small",
				["color"] = nil,
				["order"] = 3,
				["parent"] = v508,
				["color"] = v_u_22.muted
			})
		else
			local v_u_510 = {}
			for v511, v512 in v504 do
				v_u_510[v512] = v511
			end
			table.sort(v504, function(p513, p514)
				-- upvalues: (copy) v_u_510
				local v515 = p513.canCraft and 0 or (p513.locked and 2 or 1)
				local v516 = p514.canCraft and 0 or (p514.locked and 2 or 1)
				if v515 == v516 then
					if p513.locked and (p514.locked and p513.lvl ~= p514.lvl) then
						return p513.lvl < p514.lvl
					else
						return v_u_510[p513] < v_u_510[p514]
					end
				else
					return v515 < v516
				end
			end)
			local v517 = v_u_43.hasStock()
			for v518, v_u_519 in v504 do
				local v520 = v_u_79(v508, "Recipe_" .. v_u_519.id, {
					["BackgroundColor3"] = v_u_22.raised,
					["BackgroundTransparency"] = v_u_519.locked and 0.55 or 0.2,
					["LayoutOrder"] = 10 + v518
				})
				local v_u_521 = v_u_20.stroke(v520, v_u_22.line)
				v520.MouseEnter:Connect(function()
					-- upvalues: (copy) v_u_521, (ref) v_u_22
					v_u_521.Color = v_u_22.accentDim
				end)
				v520.MouseLeave:Connect(function()
					-- upvalues: (copy) v_u_521, (ref) v_u_22
					v_u_521.Color = v_u_22.line
				end)
				v_u_20.pad(v520, {
					12,
					12,
					8,
					10
				})
				v_u_20.layout(v520, "v", 6)
				local v522 = v_u_20.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 20)
				}, v520)
				local v523
				if v_u_519.blueprint then
					local v524 = v_u_43.chip(nil, "BLUEPRINT", {
						["color"] = nil,
						["height"] = 18,
						["color"] = v_u_22.accent
					})
					v524.AnchorPoint = Vector2.new(1, 0.5)
					v524.Position = UDim2.new(1, -78, 0.5, 0)
					v524.Parent = v522
					v523 = 92
				else
					v523 = 0
				end
				local v525 = string.gsub
				local v526 = v_u_519.name or ""
				local v527 = v525(tostring(v526), "%s+[xX]%d+$", "")
				local v528 = v_u_20.label
				local v529 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v522,
					["text"] = v527
				}
				local v530
				if v_u_519.locked then
					v530 = v_u_22.muted
				else
					v530 = v_u_22.text
				end
				v529.color = v530
				v529.size = UDim2.new(1, -(v523 + 84), 1, 0)
				v528(v529)
				local v531 = v_u_20.new("Frame", {
					["Name"] = "Time",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = UDim2.fromOffset(74, 20),
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, 0, 0, 0)
				}, v522)
				v_u_20.icon("clock", {
					["parent"] = nil,
					["size"] = 12,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v531,
					["color"] = v_u_22.muted,
					["position"] = UDim2.new(0, 0, 0.5, 0),
					["anchor"] = Vector2.new(0, 0.5)
				})
				v_u_20.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v531,
					["text"] = v_u_18(v_u_519.time or 0),
					["color"] = v_u_22.text2,
					["size"] = UDim2.new(1, -16, 1, 0),
					["position"] = UDim2.fromOffset(16, 0)
				})
				local v532 = v_u_20.new("Frame", {
					["Name"] = "Line",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["Size"] = UDim2.new(1, 0, 0, 80)
				}, v520)
				local v533 = v_u_20.new("Frame", {
					["Name"] = "Tiles",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, -162, 1, 0)
				}, v532)
				v_u_20.layout(v533, "h", 8).VerticalAlignment = Enum.VerticalAlignment.Top
				v_u_43.cell(v533, v_u_519.output.id, {
					["size"] = 72,
					["label"] = false,
					["order"] = 1,
					["name"] = nil,
					["count"] = nil,
					["locked"] = nil,
					["tip"] = nil,
					["name"] = "Out_" .. v_u_519.output.id,
					["count"] = v_u_519.output.n,
					["locked"] = v_u_519.locked,
					["tip"] = {
						{
							["label"] = "Makes",
							["value"] = nil,
							["value"] = ("%d x %s"):format(v_u_519.output.n, v_u_43.name(v_u_519.output.id))
						}
					}
				})
				v_u_43.arrow(v533, 2, 72)
				local v534 = {}
				for v535, v536 in v_u_519.inputs do
					local v537 = v_u_43.cell
					local v538 = v536.id
					local v539 = {
						["size"] = 64,
						["label"] = false,
						["caption"] = true,
						["order"] = nil,
						["name"] = nil,
						["count"] = nil,
						["need"] = nil,
						["haveKnown"] = nil,
						["missing"] = nil,
						["locked"] = nil,
						["wish"] = true,
						["order"] = 2 + v535,
						["name"] = "In_" .. v536.id,
						["count"] = v536.n,
						["need"] = v536.n,
						["haveKnown"] = v517
					}
					local v540 = not (v517 or (v_u_519.canCraft or v_u_519.locked))
					if v540 then
						local v541
						if p501.slots == nil then
							v541 = p501.craft ~= nil
						else
							v541 = p501.slotsFull == true
						end
						v540 = not v541
					end
					v539.missing = v540
					v539.locked = v_u_519.locked
					v537(v533, v538, v539)
					local v542 = v_u_43.have(v536.id)
					if not v517 or v542 >= v536.n then
						continue
					end
					local v543 = {
						["n"] = v536.n - v542,
						["id"] = v536.id
					}
					table.insert(v534, v543)
				end
				local v544 = v_u_420(v_u_519, p501)
				local v545 = v_u_20.new("Frame", {
					["Name"] = "Action",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, 0, 0, 0),
					["Size"] = UDim2.new(0, 150, 0, 72)
				}, v532)
				if v_u_519.canCraft then
					local v546 = not v_u_358
					local v547 = v_u_20.button({
						["parent"] = nil,
						["name"] = "Craft",
						["text"] = "CRAFT",
						["kind"] = nil,
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["onClick"] = nil,
						["parent"] = v545,
						["kind"] = v546 and "primary" or "secondary",
						["size"] = UDim2.new(1, 0, 0, v_u_21.touch(40)),
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) p_u_19, (copy) p_u_500, (copy) v_u_519
							p_u_19.act("craft", {
								["module"] = p_u_500,
								["recipe"] = v_u_519.id
							})
						end
					})
					local v_u_548 = {
						["title"] = "CRAFT",
						["body"] = nil,
						["body"] = ("Takes the materials from your stash. Ready in %s."):format(string.lower(v_u_18(v_u_519.time or 0)))
					}
					v_u_20.tooltip(v547, function()
						-- upvalues: (copy) v_u_548
						return v_u_548
					end)
					if not v546 then
						break
					end
					v_u_358 = true
					if not v547 or p503[1] then
						break
					end
					v547:SetAttribute("PadDefault", true)
					p503[1] = true
				elseif v_u_519.locked then
					local v549 = v_u_43.chip(v545, v_u_25.lockedChip(p501.lvl or 0, v_u_519.lvl), {
						["color"] = nil,
						["icon"] = "lock",
						["height"] = 26,
						["name"] = "Locked",
						["color"] = v_u_22.muted
					})
					v549.AnchorPoint = Vector2.new(1, 0.5)
					v549.Position = UDim2.new(1, 0, 0.5, 0)
					if not v544 then
						break
					end
					local v_u_550 = {
						["title"] = "LOCKED",
						["body"] = nil,
						["body"] = v544
					}
					v_u_20.tooltip(v549, function()
						-- upvalues: (copy) v_u_550
						return v_u_550
					end)
				else
					local v551 = v_u_22.danger
					local v552
					if p501.slots == nil then
						v552 = p501.craft ~= nil
					else
						v552 = p501.slotsFull == true
					end
					local v553
					if v552 then
						v551 = v_u_22.muted
						v553 = "BENCH IN USE"
					elseif #v534 == 1 then
						v553 = ("MISSING %d %s"):format(v534[1].n, string.upper((v_u_43.def(v534[1].id) or {}).short or v_u_43.name(v534[1].id)))
					elseif #v534 > 1 then
						local v554 = 0
						for _, v555 in v534 do
							v554 = v554 + v555.n
						end
						v553 = ("MISSING %d ITEMS"):format(v554)
					else
						v553 = "MISSING MATERIALS"
					end
					local v556 = v_u_20.label({
						["parent"] = nil,
						["name"] = "Reason",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["align"] = "right",
						["wrap"] = true,
						["track"] = false,
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v545,
						["text"] = v553,
						["color"] = v551,
						["size"] = UDim2.new(1, 0, 0, 34),
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["anchor"] = Vector2.new(1, 0.5)
					})
					v556.TextTruncate = Enum.TextTruncate.AtEnd
					if not v544 then
						break
					end
					local v_u_557 = {}
					local v558
					if p501.slots == nil then
						v558 = p501.craft ~= nil
					else
						v558 = p501.slotsFull == true
					end
					v_u_557.title = v558 and ((p501.slots or 1) >= 2 and "BOTH SLOTS BUSY" or "ONE CRAFT AT A TIME") or "CAN\'T CRAFT YET"
					v_u_557.body = v544
					v_u_557.color = v551
					v_u_20.tooltip(v556, function()
						-- upvalues: (copy) v_u_557
						return v_u_557
					end)
				end
			end
			local v559 = v_u_25.blueprintNote((v_u_23.get(p_u_500) or {}).recipes, v504)
			if v559 then
				v_u_20.label({
					["parent"] = nil,
					["name"] = "BlueprintNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["track"] = false,
					["parent"] = v508,
					["text"] = v559,
					["color"] = v_u_22.muted,
					["order"] = #v504 + 10 + 1
				})
			end
		end
	end
	local function v_u_566(p561, p562, p563) -- name: statRow
		-- upvalues: (copy) v_u_79
		local v564 = v_u_79(p561, p562, {
			["LayoutOrder"] = p563
		})
		local v565 = Instance.new("UIGridLayout")
		v565.CellPadding = UDim2.fromOffset(8, 8)
		v565.CellSize = UDim2.new(0.5, -4, 0, 92)
		v565.SortOrder = Enum.SortOrder.LayoutOrder
		v565.Parent = v564
		return v564
	end
	local function v_u_821(p567, p568, p569, p570, p571, p572) -- name: drawStation
		-- upvalues: (ref) v_u_27, (ref) v_u_43, (copy) v_u_566, (copy) v_u_22, (copy) v_u_23, (copy) v_u_79, (copy) v_u_20, (copy) p_u_19, (ref) v_u_358, (copy) v_u_21, (copy) v_u_25, (copy) v_u_97, (ref) v_u_30
		local v573 = v_u_27.effects or {}
		local v574 = p570.lvl or 0
		if p568 == "generator" then
			local v575 = v_u_43.section(p567, "POWER", p571)
			local v576 = v573.lightLevel
			local v577 = tonumber(v576) or 0
			local v578 = v573.craftSpeed
			local v579 = tonumber(v578) or 1
			local v580 = v_u_566(v575, "Stats", 2)
			v_u_43.stat(v580, {
				["label"] = "LIGHTS",
				["value"] = nil,
				["color"] = nil,
				["sub"] = nil,
				["order"] = 1,
				["value"] = v577 <= 0 and "BATTERY" or ("LEVEL %d"):format(v577),
				["color"] = v_u_22.text,
				["sub"] = v577 <= 0 and "Emergency lamps only." or "Brighter hideout, every lamp on."
			})
			local v581 = v_u_43.stat
			local v582 = {
				["label"] = "CRAFT SPEED",
				["value"] = nil,
				["color"] = nil,
				["sub"] = nil,
				["order"] = 2,
				["value"] = ("x%.2f"):format(v579)
			}
			local v583
			if v579 > 1 then
				v583 = v_u_22.success
			else
				v583 = v_u_22.text
			end
			v582.color = v583
			local v584
			if v579 > 1 then
				local v585 = (v579 - 1) * 100 + 0.5
				v584 = ("Crafts finish %d %% faster."):format((math.floor(v585)))
			else
				v584 = "Normal speed."
			end
			v582.sub = v584
			v581(v580, v582)
			local v586 = v573.craftSlots
			if (tonumber(v586) or 1) >= 2 then
				v_u_43.stat(v580, {
					["label"] = "CRAFT SLOTS",
					["value"] = "2",
					["color"] = nil,
					["sub"] = "The workbench and the med station run two crafts at once.",
					["order"] = 3,
					["color"] = v_u_22.success
				})
				return
			end
			return
		elseif p568 == "stash_rack" then
			local v587 = v_u_43.section(p567, "STASH", p571)
			local v588 = v573.stashRows
			local v589 = tonumber(v588) or v_u_23.BASE_STASH_ROWS
			local v590 = v589
			for _, v591 in p569.levels do
				local v592 = v591.effects
				if v592 then
					v592 = v591.effects.stashRows
				end
				local v593 = tonumber(v592) or 0
				v589 = math.max(v589, v593)
			end
			local v594 = p570.next and (p569.levels[p570.next.lvl] and (p569.levels[p570.next.lvl].effects and p569.levels[p570.next.lvl].effects.stashRows)) or nil
			local v595 = v_u_566(v587, "Stats", 2)
			v_u_43.stat(v595, {
				["label"] = "STASH SIZE",
				["value"] = nil,
				["sub"] = nil,
				["order"] = 1,
				["value"] = ("%d x %d"):format(v_u_23.STASH_WIDTH, v590),
				["sub"] = ("%d slots"):format(v_u_23.STASH_WIDTH * v590)
			})
			local v596 = v_u_43.stat
			local v597 = {
				["label"] = nil,
				["value"] = nil,
				["color"] = nil,
				["sub"] = nil,
				["order"] = 2,
				["label"] = v594 and "NEXT LEVEL" or "MAXIMUM",
				["value"] = ("%d x %d"):format(v_u_23.STASH_WIDTH, v594 or v589)
			}
			local v598
			if v594 then
				v598 = v_u_22.text
			else
				v598 = v_u_22.success
			end
			v597.color = v598
			v597.sub = not v594 and "Every shelf is up." or ("+%d rows"):format(v594 - v590)
			v596(v595, v597)
			local v599 = v_u_79(v587, "Capacity", {
				["LayoutOrder"] = 3
			})
			v_u_20.layout(v599, "v", 4)
			local v600 = v_u_20.new("Frame", {
				["Name"] = "Top",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 16)
			}, v599)
			v_u_20.label({
				["parent"] = nil,
				["text"] = "ROWS",
				["style"] = "caps",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v600,
				["color"] = v_u_22.text2,
				["size"] = UDim2.new(0.5, 0, 1, 0)
			})
			v_u_20.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["size"] = nil,
				["position"] = nil,
				["track"] = false,
				["parent"] = v600,
				["text"] = ("%d / %d"):format(v590, v589),
				["color"] = v_u_22.text2,
				["size"] = UDim2.new(0.5, 0, 1, 0),
				["position"] = UDim2.fromScale(0.5, 0)
			})
			local v601 = v_u_20.progress
			local v602 = {
				["parent"] = v599,
				["size"] = UDim2.new(1, 0, 0, 6),
				["value"] = v590 / math.max(1, v589)
			}
			local v603
			if v594 then
				v603 = v594 / math.max(1, v589)
			else
				v603 = nil
			end
			v602.ghost = v603
			v602.color = v_u_22.accent
			v601(v602).frame.LayoutOrder = 2
			local v604 = p_u_19.hooks
			local v605
			if type(v604) == "table" then
				v605 = v604.openStash
			else
				v605 = nil
			end
			if v605 then
				local v606 = v_u_20.button({
					["parent"] = nil,
					["name"] = "OpenStash",
					["text"] = "OPEN STASH",
					["kind"] = nil,
					["hint"] = "inventory",
					["size"] = nil,
					["onClick"] = nil,
					["parent"] = v587,
					["kind"] = v_u_358 and "secondary" or "primary",
					["size"] = UDim2.new(1, 0, 0, v_u_21.touch(44)),
					["onClick"] = v605
				})
				v606.LayoutOrder = 5
				v_u_358 = true
				if v606 and not p572[1] then
					v606:SetAttribute("PadDefault", true)
					p572[1] = true
					return
				end
			end
			return
		elseif p568 == "workbench" then
			local v607 = v_u_43.section(p567, "REPAIRS", p571)
			if v574 <= 0 then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "Build the workbench to repair weapons and armor.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = v607,
					["color"] = v_u_22.text2
				})
				return
			end
			local v608 = p_u_19.hooks
			local v609
			if type(v608) == "table" then
				v609 = v608.repairables
			else
				v609 = nil
			end
			local v610 = (v609 or function()
				return {}
			end)()
			local v611 = v_u_23.effectsAt("workbench", v574).repairQuality or 0.85
			local v612 = v574 < v_u_23.maxLevel("workbench") and (v_u_23.effectsAt("workbench", v574 + 1).repairQuality or 0.85) or nil
			if #v610 == 0 then
				local v613 = v_u_79(v607, "AllGood", {
					["LayoutOrder"] = 2
				})
				v_u_20.icon("check", {
					["parent"] = nil,
					["size"] = 16,
					["color"] = nil,
					["position"] = nil,
					["parent"] = v613,
					["color"] = v_u_22.success,
					["position"] = UDim2.fromOffset(0, 2)
				})
				v_u_20.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v613,
					["text"] = v_u_25.repairEmpty(v611, v612) .. " " .. v_u_25.REPAIR_HINT,
					["color"] = v_u_22.text2,
					["size"] = UDim2.new(1, -26, 0, 0),
					["position"] = UDim2.fromOffset(26, 0)
				})
				return
			end
			v_u_20.label({
				["parent"] = nil,
				["name"] = "RepairHead",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 1,
				["track"] = false,
				["parent"] = v607,
				["text"] = v_u_25.repairHead(v611),
				["color"] = v_u_22.text2
			})
			for v614, v_u_615 in v610 do
				if v_u_25.LIST_MAX < v614 then
					break
				end
				local v616 = v_u_43.def(v_u_615.id)
				local v617
				if v616 then
					v617 = (v616.w or 1) > (v616.h or 1)
				else
					v617 = v616
				end
				local v618 = v_u_79
				local v619 = v_u_615.uid
				local v620 = v618(v607, "Repair_" .. tostring(v619), {
					["LayoutOrder"] = 1 + v614
				})
				local v621 = (v_u_21.isPhone == nil or not v_u_21.isPhone()) and 52 or v_u_21.touch(52)
				v620.AutomaticSize = Enum.AutomaticSize.None
				local v622 = UDim2.new
				local v623 = v_u_21.touch
				v620.Size = v622(1, 0, 0, (math.max(v621, v623(40))))
				local v624 = v617 and 2 or 1
				v_u_43.cell(v620, v_u_615.id, {
					["size"] = nil,
					["w"] = nil,
					["name"] = "Item",
					["mods"] = nil,
					["known"] = true,
					["size"] = v621,
					["w"] = v624,
					["mods"] = v_u_615.mods
				})
				local v625 = v621 * v624 + 12
				local v626 = v_u_20.new("Frame", {
					["Name"] = "Info",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(v625, 4),
					["Size"] = UDim2.new(1, -(v625 + 132), 1, -8)
				}, v620)
				v_u_20.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["size"] = nil,
					["track"] = false,
					["parent"] = v626,
					["text"] = v_u_43.name(v_u_615.id),
					["size"] = UDim2.new(1, -52, 0, 20)
				})
				local v627 = v_u_20.label
				local v628 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v626
				}
				local v629 = v_u_615.dur * 100
				v628.text = ("%d %%"):format((math.floor(v629)))
				local v630
				if v_u_615.dur < 0.5 then
					v630 = v_u_22.danger
				else
					v630 = v_u_22.accent
				end
				v628.color = v630
				v628.size = UDim2.new(0, 50, 0, 20)
				v628.position = UDim2.new(1, -50, 0, 0)
				v627(v628)
				local v631 = v_u_20.progress
				local v632 = {
					["parent"] = v626,
					["size"] = UDim2.new(1, 0, 0, 4),
					["position"] = UDim2.new(0, 0, 1, -6),
					["value"] = v_u_615.dur,
					["ghost"] = p_u_19.cctx and (p_u_19.cctx.shared and (p_u_19.cctx.shared.AttachWear and p_u_19.cctx.shared.AttachWear.wears(v616))) and 1 or v611
				}
				local v633
				if v_u_615.dur < 0.5 then
					v633 = v_u_22.danger
				else
					v633 = v_u_22.accent
				end
				v632.color = v633
				v631(v632)
				local v634 = v616 and (v616.value or 0) or 0
				local v635 = v634 * 0.12 * (v611 - v_u_615.dur) / 5 + 0.5
				local v636 = math.floor(v635) * 5
				local v637 = math.max(50, v636)
				local v638 = p_u_19.cctx and p_u_19.cctx.shared
				if v638 then
					v638 = p_u_19.cctx.shared.AttachWear
				end
				local v639
				if v638 and v638.wears(v616) then
					v637 = v638.repairCost(v634, v_u_615.dur)
					v639 = 1
				else
					v639 = v611
				end
				local v640 = v_u_20.button({
					["parent"] = nil,
					["name"] = "RepairBtn",
					["text"] = nil,
					["kind"] = "secondary",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = v620,
					["text"] = "REPAIR $" .. v_u_20.commas(v637),
					["size"] = UDim2.fromOffset(124, v_u_21.touch(36)),
					["position"] = UDim2.new(1, 0, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_19, (copy) v_u_615
						p_u_19.act("repair", {
							["uid"] = v_u_615.uid
						})
					end
				})
				local v641 = v639 * 100
				local v_u_642 = ("Restores it to %d %% for $%s."):format(math.floor(v641), v_u_20.commas(v637))
				v_u_20.tooltip(v640, function()
					-- upvalues: (copy) v_u_642
					return v_u_642
				end)
			end
			local v643 = v_u_25.repairMore(#v610, v_u_25.LIST_MAX)
			if v643 then
				v_u_20.label({
					["parent"] = nil,
					["name"] = "RepairMore",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 40,
					["track"] = false,
					["parent"] = v607,
					["text"] = v643,
					["color"] = v_u_22.muted
				})
				return
			end
			return
		elseif p568 == "shooting_range" then
			local v644 = v_u_43.section(p567, "RANGE", p571)
			local v645 = v573.rangeTier
			local v646 = tonumber(v645) or 0
			if v646 <= 0 then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "Clear the lane and put up targets to train without waking the town.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = v644,
					["color"] = v_u_22.text2
				})
				return
			end
			local v647 = p_u_19.hooks
			local v648
			if type(v647) == "table" then
				v648 = v647.rangeStats
			else
				v648 = nil
			end
			local v649 = v648 and v648() or {
				["shots"] = 0,
				["hits"] = 0,
				["accuracy"] = 0,
				["score"] = 0,
				["head"] = 0
			}
			local v650 = v_u_79(v644, "Stats", {
				["LayoutOrder"] = 2
			})
			local v651 = Instance.new("UIGridLayout")
			v651.CellPadding = UDim2.fromOffset(8, 8)
			v651.CellSize = UDim2.new(0.25, -6, 0, 70)
			v651.SortOrder = Enum.SortOrder.LayoutOrder
			v651.Parent = v650
			local v652 = v_u_43.stat
			local v653 = {
				["label"] = "SHOTS",
				["value"] = nil,
				["order"] = 1
			}
			local v654 = v649.shots
			v653.value = tostring(v654)
			v652(v650, v653)
			local v655 = v_u_43.stat
			local v656 = {
				["label"] = "HITS",
				["value"] = nil,
				["order"] = 2
			}
			local v657 = v649.hits
			v656.value = tostring(v657)
			v655(v650, v656)
			local v658 = v_u_43.stat
			local v659 = {
				["label"] = "ACCURACY",
				["value"] = nil,
				["color"] = nil,
				["order"] = 3,
				["value"] = ("%d%%"):format(v649.accuracy)
			}
			local v660
			if v649.accuracy >= 60 then
				v660 = v_u_22.success
			else
				v660 = v_u_22.text
			end
			v659.color = v660
			v658(v650, v659)
			local v661 = v_u_43.stat
			local v662 = {
				["label"] = "SCORE",
				["value"] = nil,
				["color"] = nil,
				["order"] = 4
			}
			local v663 = v649.score
			v662.value = tostring(v663)
			v662.color = v_u_22.text
			v661(v650, v662)
			local v664 = v_u_97(v644, "Targets", 3, 6)
			for v665, v666 in { "10", "25", "50" } do
				v_u_43.chip(v664, v666 .. " STUDS" .. (v646 >= 2 and v666 == "25" and "  MOVING" or (v646 >= 3 and v666 == "50" and "  LONG RANGE" or "")), {
					["color"] = nil,
					["icon"] = "ping",
					["order"] = nil,
					["height"] = 22,
					["color"] = v_u_22.text2,
					["order"] = v665
				})
			end
			v_u_43.chip(v664, ("HEAD HITS %d"):format(v649.head or 0), {
				["color"] = nil,
				["icon"] = "skull",
				["order"] = 9,
				["height"] = 22,
				["color"] = v_u_22.text2
			})
			v_u_20.label({
				["parent"] = nil,
				["text"] = "Free ammo. Nothing you fire here is taken from your stash.",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 4,
				["track"] = false,
				["parent"] = v644,
				["color"] = v_u_22.muted
			})
			local v667 = p_u_19.hooks
			local v668
			if type(v667) == "table" then
				v668 = v667.rangeReset
			else
				v668 = nil
			end
			if v668 then
				v_u_20.button({
					["parent"] = nil,
					["name"] = "Reset",
					["text"] = "RESET TARGETS",
					["kind"] = "secondary",
					["size"] = nil,
					["onClick"] = nil,
					["parent"] = v644,
					["size"] = UDim2.new(1, 0, 0, v_u_21.touch(40)),
					["onClick"] = v668
				}).LayoutOrder = 5
			end
			local v669 = v_u_43.section(p567, "WEAPONS", p571 + 1)
			local v670 = p_u_19.hooks
			local v671
			if type(v670) == "table" then
				v671 = v670.ownedWeapons
			else
				v671 = nil
			end
			local v672 = (v671 or function()
				return {}
			end)()
			local v673 = p_u_19.hooks
			local v674
			if type(v673) == "table" then
				v674 = v673.inHands
			else
				v674 = nil
			end
			if v674 then
				v674 = v674()
			end
			if #v672 == 0 then
				v_u_20.label({
					["parent"] = nil,
					["text"] = "No firearms in your loadout or stash yet.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = v669,
					["color"] = v_u_22.text2
				})
			end
			local v675 = {}
			local v676 = {}
			for _, v677 in v672 do
				local v678 = {}
				local v679 = v677.inst
				if v679 then
					v679 = v677.inst.mods
				end
				if type(v679) == "table" then
					for v680, v682 in v679 do
						if type(v682) == "table" then
							local v682 = v682.id or v682.uid
						end
						local v683 = tostring(v680) .. "=" .. tostring(v682)
						table.insert(v678, v683)
					end
					table.sort(v678)
				end
				local v684 = v677.id
				local v685 = tostring(v684) .. "|" .. table.concat(v678, ",")
				local v686 = v675[v685]
				if not v686 then
					v686 = {
						["w"] = nil,
						["n"] = 0,
						["loadout"] = false,
						["stash"] = 0,
						["w"] = v677
					}
					v675[v685] = v686
					table.insert(v676, v686)
				end
				v686.n = v686.n + 1
				if v677.where == "LOADOUT" then
					if not v686.loadout then
						v686.w = v677
					end
					v686.loadout = true
				else
					v686.stash = v686.stash + 1
				end
			end
			table.sort(v676, function(p687, p688)
				if p687.loadout == p688.loadout then
					if p687.w.name == p688.w.name then
						local v689 = p687.w.uid
						local v690 = tostring(v689)
						local v691 = p688.w.uid
						return v690 < tostring(v691)
					else
						local v692 = p687.w.name
						local v693 = tostring(v692)
						local v694 = p688.w.name
						return v693 < tostring(v694)
					end
				else
					return p687.loadout
				end
			end)
			local v695 = p_u_19.hooks
			local v_u_696
			if type(v695) == "table" then
				v_u_696 = v695.tryWeapon
			else
				v_u_696 = nil
			end
			for v697, v698 in v676 do
				if v697 > 12 then
					break
				end
				local v699 = v698.w
				local v_u_700 = table.clone(v699)
				local v701
				if v698.loadout and v698.stash > 0 then
					v701 = ("LOADOUT + %d STASH"):format(v698.stash)
				else
					v701 = v698.loadout and "LOADOUT" or "STASH"
				end
				v_u_700.where = v701
				local v702 = v_u_20.new
				local v703 = {
					["Name"] = nil,
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil
				}
				local v704 = v_u_700.uid
				v703.Name = "Weapon_" .. tostring(v704)
				local v705 = UDim2.new
				local v706 = v_u_21.touch
				v703.Size = v705(1, 0, 0, (math.max(52, v706(40))))
				v703.LayoutOrder = v697 + 1
				local v707 = v702("Frame", v703, v669)
				local v708 = v_u_43.cell
				local v709 = v_u_700.id
				local v710 = {
					["size"] = 52,
					["w"] = 2,
					["label"] = false,
					["name"] = "Item",
					["mods"] = nil,
					["known"] = true,
					["count"] = nil
				}
				local v711
				if v_u_700.inst then
					v711 = v_u_700.inst.mods or nil
				else
					v711 = nil
				end
				v710.mods = v711
				local v712
				if v698.n > 1 then
					v712 = v698.n
				else
					v712 = nil
				end
				v710.count = v712
				v708(v707, v709, v710)
				local v713 = v_u_20.new("Frame", {
					["Name"] = "Info",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(116, 0),
					["Size"] = UDim2.new(1, -232, 1, 0)
				}, v707)
				v_u_20.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "bodyStrong",
					["size"] = nil,
					["position"] = nil,
					["track"] = false,
					["parent"] = v713,
					["text"] = v_u_700.name,
					["size"] = UDim2.new(1, 0, 0, 22),
					["position"] = UDim2.fromOffset(0, 4)
				})
				local v714 = v_u_97(v713, "Tags", 2, 4)
				v714.Position = UDim2.fromOffset(0, 28)
				local v715 = v_u_43.chip
				local v716 = v_u_700.where
				local v717 = {
					["color"] = nil,
					["height"] = 16,
					["order"] = 1
				}
				local v718
				if string.find(v_u_700.where, "LOADOUT", 1, true) then
					v718 = v_u_22.accent
				else
					v718 = v_u_22.text2
				end
				v717.color = v718
				v715(v714, v716, v717)
				if (v_u_700.mods or 0) > 0 then
					v_u_43.chip(v714, ("+%d MOD%s"):format(v_u_700.mods, v_u_700.mods > 1 and "S" or ""), {
						["color"] = nil,
						["height"] = 16,
						["order"] = 2,
						["color"] = v_u_22.text2
					})
				end
				if v674 == v_u_700.id then
					v_u_43.chip(v714, "IN HANDS", {
						["color"] = nil,
						["height"] = 16,
						["order"] = 3,
						["color"] = v_u_22.success
					})
				end
				v_u_20.button({
					["parent"] = nil,
					["name"] = "Try",
					["text"] = nil,
					["kind"] = "secondary",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = v707,
					["text"] = v674 == v_u_700.id and "AGAIN" or "TRY",
					["size"] = UDim2.fromOffset(108, v_u_21.touch(36)),
					["position"] = UDim2.new(1, 0, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) v_u_696, (ref) v_u_700
						if v_u_696 then
							v_u_696(v_u_700.uid)
						end
					end
				})
			end
			local v719 = p_u_19.hooks
			local v720
			if type(v719) == "table" then
				v720 = v719.ownWeapons
			else
				v720 = nil
			end
			if v720 then
				v_u_20.button({
					["parent"] = nil,
					["name"] = "Own",
					["text"] = "OWN LOADOUT",
					["kind"] = "ghost",
					["size"] = nil,
					["onClick"] = nil,
					["parent"] = v669,
					["size"] = UDim2.new(1, 0, 0, v_u_21.touch(36)),
					["onClick"] = v720
				}).LayoutOrder = 40
				return
			end
			return
		else
			if p568 == "radio" then
				local v721 = v_u_43.section(p567, "INTEL", p571)
				local v722 = v573.radioIntel
				local v723 = tonumber(v722) or 0
				local v724 = {
					{
						["icon"] = "extract",
						["title"] = nil,
						["text"] = nil,
						["title"] = v_u_25.RADIO_TITLES[1],
						["text"] = v_u_25.radioText(p569, 1)
					},
					{
						["icon"] = "map",
						["title"] = nil,
						["text"] = nil,
						["title"] = v_u_25.RADIO_TITLES[2],
						["text"] = v_u_25.radioText(p569, 2)
					},
					{
						["icon"] = "heli",
						["title"] = nil,
						["text"] = nil,
						["title"] = v_u_25.RADIO_TITLES[3],
						["text"] = v_u_25.radioText(p569, 3)
					}
				}
				if v_u_23.maxLevel("radio") >= 4 then
					table.insert(v724, {
						["icon"] = "skull",
						["title"] = "BOSS INTEL",
						["text"] = "Before a Hard or Nightmare raid the radio names the boss that waits in it."
					})
				end
				if v723 <= 0 then
					v_u_20.label({
						["parent"] = nil,
						["text"] = "Static. Build the radio to listen in before a raid.",
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["track"] = false,
						["parent"] = v721,
						["color"] = v_u_22.text2
					})
				end
				for v725, v726 in v724 do
					local v727
					if v725 >= 4 then
						v727 = v573.bossIntel == true
					else
						v727 = v725 <= v723
					end
					local v728 = v_u_79(v721, "Tier" .. v725, {
						["BackgroundColor3"] = v_u_22.raised,
						["BackgroundTransparency"] = v727 and 0.2 or 0.6,
						["LayoutOrder"] = 2 + v725
					})
					local v729 = v_u_20.stroke
					local v730
					if v727 then
						v730 = v_u_22.accentDim
					else
						v730 = v_u_22.line
					end
					v729(v728, v730)
					v_u_20.pad(v728, {
						12,
						12,
						10,
						10
					})
					local v731 = v_u_20.new
					local v732 = "Frame"
					local v733 = {
						["Name"] = "Icon",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil
					}
					local v734
					if v727 then
						v734 = v_u_22.accentDeep
					else
						v734 = v_u_22.bg
					end
					v733.BackgroundColor3 = v734
					v733.Size = UDim2.fromOffset(40, 40)
					local v735 = v731(v732, v733, v728)
					local v736 = v_u_20.stroke
					local v737 = v735
					local v738
					if v727 then
						v738 = v_u_22.accent
					else
						v738 = v_u_22.line
					end
					v736(v737, v738)
					local v739 = v_u_20.icon
					local v740 = v726.icon
					local v741 = {
						["parent"] = nil,
						["size"] = 22,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v735
					}
					local v742
					if v727 then
						v742 = v_u_22.accent
					else
						v742 = v_u_22.muted
					end
					v741.color = v742
					v741.position = UDim2.fromScale(0.5, 0.5)
					v741.anchor = Vector2.new(0.5, 0.5)
					v739(v740, v741)
					local v743 = v_u_79(v728, "Text", {
						["Position"] = UDim2.fromOffset(54, 0),
						["Size"] = UDim2.new(1, -150, 0, 0)
					})
					v_u_20.layout(v743, "v", 2)
					local v744 = v_u_20.label
					local v745 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["order"] = 1,
						["size"] = nil,
						["parent"] = v743,
						["text"] = v726.title
					}
					local v746
					if v727 then
						v746 = v_u_22.text
					else
						v746 = v_u_22.muted
					end
					v745.color = v746
					v745.size = UDim2.new(1, 0, 0, 16)
					v744(v745)
					local v747 = v_u_20.label
					local v748 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["track"] = false,
						["parent"] = v743,
						["text"] = v726.text
					}
					local v749
					if v727 then
						v749 = v_u_22.text2
					else
						v749 = v_u_22.muted
					end
					v748.color = v749
					v747(v748)
					local v750 = v_u_43.chip
					local v751 = nil
					local v752 = v727 and "ACTIVE" or ("LEVEL %d"):format(v725)
					local v753 = {
						["color"] = nil,
						["icon"] = nil,
						["height"] = 22
					}
					local v754
					if v727 then
						v754 = v_u_22.success
					else
						v754 = v_u_22.muted
					end
					v753.color = v754
					v753.icon = v727 and "check" or "lock"
					local v755 = v750(v751, v752, v753)
					v755.AnchorPoint = Vector2.new(1, 0)
					v755.Position = UDim2.new(1, 0, 0, 0)
					v755.Parent = v728
				end
				return
			end
			if p568 == "tv_vcr" then
				local v756 = p_u_19.cctx and p_u_19.cctx.shared
				if v756 then
					v756 = p_u_19.cctx.shared.VhsTapes
				end
				local v757 = not v756 or v756.HOME or (v756.LIST or {})
				local v758 = {}
				local v759
				if v756 then
					local v760 = v756.GROUPS
					if type(v760) == "table" then
						for _, v761 in v756.GROUPS do
							if v761.key == "home" then
								continue
							end
							table.insert(v758, v761)
						end
					elseif v756 and v756.CAMERA then
						v759 = {
							["key"] = "hollow",
							["title"] = "SITE CAMERAS",
							["list"] = nil,
							["list"] = v756.CAMERA
						}
						table.insert(v758, v759)
					end
				elseif v756 and v756.CAMERA then
					v759 = {
						["key"] = "hollow",
						["title"] = "SITE CAMERAS",
						["list"] = nil,
						["list"] = v756.CAMERA
					}
					table.insert(v758, v759)
				end
				local v762 = 0
				for _, v763 in v757 do
					if not v_u_43.seen(v763.id) then
						continue
					end
					v762 = v762 + 1
				end
				local v764 = v_u_43.section(p567, "HOME MOVIES", p571, ("%d / %d FOUND"):format(v762, #v757))
				local v765 = v574 >= 1 and "Pick a VHS tape and press play. Every VHS tape you bring back from a raid plays here, and the log discs open in the same window." or (p570.building and "VHS tapes play here as soon as the build is done." or "Build it to play the home videos you bring back. VHS tapes turn up in houses and shops around town.")
				v_u_20.label({
					["parent"] = nil,
					["name"] = "Note",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = v764,
					["text"] = v765,
					["color"] = v_u_22.text2
				})
				if #v757 > 0 then
					local v766 = v_u_97(v764, "Tapes", 3, 8)
					for v767, v768 in v757 do
						v_u_43.cell(v766, v768.id, {
							["size"] = 56,
							["label"] = false,
							["caption"] = true,
							["order"] = nil,
							["name"] = nil,
							["order"] = v767,
							["name"] = "Tape_" .. v768.id
						})
					end
				end
				for v769, v_u_770 in v758 do
					local v771 = v_u_770.list or {}
					local v772 = 0
					for _, v773 in v771 do
						if not v_u_43.seen(v773.id) then
							continue
						end
						v772 = v772 + 1
					end
					local v774
					if v_u_770.flag == nil then
						v774 = false
					else
						local function v775()
							-- upvalues: (ref) p_u_19, (copy) v_u_770
							return p_u_19.cctx.config.flag(v_u_770.flag)
						end
						local v776
						v774, v776 = pcall(v775)
						if v774 then
							v774 = v776 == false
						end
					end
					if v772 <= 0 or v774 then
						break
					end
					local v777 = v_u_770.title
					if v_u_770.place ~= nil and v_u_770.key ~= "hollow" then
						local function v780()
							-- upvalues: (ref) p_u_19
							local v778 = p_u_19.cctx and p_u_19.cctx.shared
							if v778 then
								v778 = p_u_19.cctx.shared.MapReveal
							end
							if v778 then
								local v779 = v778.clientRevealed
								if type(v779) == "function" then
									return v778.clientRevealed()
								end
							end
							return false
						end
						local v781, v782 = pcall(v780)
						local v783
						if v_u_770.placeRevealed == nil or (not v781 or v782 ~= true) then
							v783 = v_u_770.place
						else
							v783 = v_u_770.placeRevealed
						end
						v777 = ("%s  \194\183  %s"):format(v_u_770.title, v783)
					end
					v_u_20.label({
						["parent"] = nil,
						["name"] = nil,
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["order"] = nil,
						["size"] = nil,
						["parent"] = v764,
						["name"] = "CamHead_" .. v_u_770.key,
						["text"] = ("%s  %d / %d"):format(v777, v772, #v771),
						["color"] = v_u_22.muted,
						["order"] = 2 + v769 * 2,
						["size"] = UDim2.new(1, 0, 0, 16)
					})
					local v784 = v_u_97(v764, "Cameras_" .. v_u_770.key, 3 + v769 * 2, 8)
					for v785, v786 in v771 do
						v_u_43.cell(v784, v786.id, {
							["size"] = 56,
							["label"] = false,
							["caption"] = true,
							["order"] = nil,
							["name"] = nil,
							["order"] = v785,
							["name"] = "Tape_" .. v786.id
						})
					end
				end
				local v787 = p_u_19.cctx and p_u_19.cctx.shared
				if v787 then
					v787 = p_u_19.cctx.shared.LogDiscs
				end
				if v787 then
					local v_u_788 = {}
					local v789 = v_u_27
					local v790
					if type(v789) == "table" then
						local v791 = v_u_27.discs
						v790 = type(v791) == "table"
					else
						v790 = false
					end
					for _, v792 in v787.ids() do
						local v793
						if v790 then
							v793 = v_u_27.discs[v792] == true
						else
							v793 = v_u_43.seen(v792)
						end
						if not v793 then
							continue
						end
						v_u_788[v792] = true
					end
					local v794 = v787.view(v_u_788)
					v_u_20.label({
						["parent"] = nil,
						["name"] = "DiscHead",
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["order"] = 11,
						["size"] = nil,
						["parent"] = v764,
						["text"] = ("LOG DISCS  %s  (open one to read)"):format(v794.count),
						["color"] = v_u_22.muted,
						["size"] = UDim2.new(1, 0, 0, 16)
					})
					for v795, v796 in v794.groups do
						v_u_20.label({
							["parent"] = nil,
							["name"] = nil,
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["order"] = nil,
							["size"] = nil,
							["parent"] = v764,
							["name"] = "DiscGroup_" .. v796.map,
							["text"] = ("%s  %s"):format(v796.name, v796.count),
							["color"] = v_u_22.muted,
							["order"] = 10 + v795 * 2,
							["size"] = UDim2.new(1, 0, 0, 14)
						})
						local v797 = v_u_97(v764, "Discs_" .. v796.map, 11 + v795 * 2, 8)
						for v798, v799 in v796.rows do
							local v_u_800 = v799.id
							v_u_43.cell(v797, v_u_800, {
								["size"] = 56,
								["label"] = false,
								["caption"] = true,
								["order"] = nil,
								["name"] = nil,
								["known"] = nil,
								["order"] = v798,
								["name"] = "Disc_" .. v_u_800,
								["known"] = v_u_788[v_u_800] == true
							}).Activated:Connect(function()
								-- upvalues: (copy) v_u_788, (copy) v_u_800, (ref) v_u_20, (ref) v_u_22
								if v_u_788[v_u_800] then
									task.spawn(function()
										-- upvalues: (ref) v_u_800, (ref) v_u_20, (ref) v_u_22
										local v_u_801 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
										if v_u_801 then
											v_u_801 = v_u_801:FindFirstChild("menu.get")
										end
										local v802, v_u_803
										if v_u_801 and v_u_801:IsA("RemoteFunction") then
											local function v804()
												-- upvalues: (copy) v_u_801, (ref) v_u_800
												return v_u_801:InvokeServer({
													["what"] = "tape",
													["id"] = nil,
													["id"] = v_u_800
												})
											end
											v802, v_u_803 = pcall(v804)
										else
											v802 = false
											v_u_803 = nil
										end
										if v802 and type(v_u_803) == "table" then
											local v805 = v_u_803.text
											if type(v805) ~= "string" then
												v_u_803 = nil
											end
										else
											v_u_803 = nil
										end
										if v_u_803 then
											local v806 = v_u_20.modal
											local v807 = {
												["title"] = nil,
												["body"] = nil,
												["width"] = 640,
												["build"] = nil,
												["buttons"] = nil
											}
											local v808 = v_u_803.title or v_u_800
											v807.title = tostring(v808)
											local v809 = v_u_803.speaker or ""
											local v810 = tostring(v809)
											local v811 = v_u_803.date or ""
											v807.body = ("%s  \194\183  %s"):format(v810, (tostring(v811)))
											function v807.build(p812) -- name: build
												-- upvalues: (ref) v_u_20, (copy) v_u_803, (ref) v_u_22
												local v813 = v_u_20.list({
													["parent"] = p812,
													["size"] = UDim2.new(1, 0, 0, 300),
													["padding"] = {
														0,
														10,
														6,
														6
													}
												})
												local v814 = v_u_20.label
												local v815 = {
													["parent"] = nil,
													["text"] = nil,
													["style"] = "mono",
													["textSize"] = 14,
													["color"] = nil,
													["wrap"] = true,
													["autoY"] = true,
													["parent"] = v813
												}
												local v816 = v_u_803.text or ""
												v815.text = tostring(v816)
												v815.color = v_u_22.text
												v814(v815)
											end
											v807.buttons = {
												{
													["text"] = "Close"
												}
											}
											v806(v807)
										else
											v_u_20.toast("Disc not readable yet", "warn", "Try again in a moment")
										end
									end)
								else
									v_u_20.toast("Disc not found yet", "warn", "Find it in a raid and extract to read it")
								end
							end)
						end
					end
				end
				if v574 >= 1 then
					local v820 = v_u_20.button({
						["parent"] = nil,
						["name"] = "Watch",
						["text"] = "WATCH VHS",
						["kind"] = nil,
						["size"] = nil,
						["onClick"] = nil,
						["parent"] = v764,
						["kind"] = v_u_358 and "secondary" or "primary",
						["size"] = UDim2.new(1, 0, 0, v_u_21.touch(44)),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_30, (ref) p_u_19
							if v_u_30 then
								v_u_30.close()
							end
							local v_u_817 = p_u_19.cctx
							task.defer(function()
								-- upvalues: (copy) v_u_817
								local v818 = v_u_817.lib.VhsPlayer.open
								local v819 = v_u_817
								pcall(v818, v819, {
									["station"] = true
								})
							end)
						end
					})
					v820.LayoutOrder = 10
					v_u_358 = true
					if v820 and not p572[1] then
						v820:SetAttribute("PadDefault", true)
						p572[1] = true
					end
				end
			end
		end
	end
	local function v_u_854(p822, p823, p824, p825) -- name: drawTrophies
		-- upvalues: (ref) v_u_27, (copy) p_u_19, (copy) v_u_20, (copy) v_u_21, (copy) v_u_23, (ref) v_u_43, (copy) v_u_79, (ref) v_u_4, (ref) v_u_36, (copy) v_u_22, (copy) v_u_97
		local v826 = (v_u_27.effects or {}).trophySlots
		local v827 = tonumber(v826) or 0
		local v828 = v_u_27.trophies or {}
		local function v829()
			-- upvalues: (ref) p_u_19
			return p_u_19.cctx.lib.HideoutTrophy
		end
		local v830, v831 = pcall(v829)
		if v830 and type(v831) == "table" then
			local v832 = v831.render
			if type(v832) == "function" then
				local v833 = v831.render
				local v834 = v_u_27
				local v835 = {
					["HushUI"] = v_u_20,
					["Theme"] = v_u_21,
					["HM"] = v_u_23,
					["Items"] = p_u_19.Items,
					["act"] = p_u_19.act,
					["cctx"] = p_u_19.cctx,
					["Recipe"] = v_u_43,
					["split"] = p825 == true,
					["width"] = p824
				}
				local v836, v837 = pcall(v833, p822, p823, v834, v835)
				if v836 then
					return
				end
				warn("[HideoutPanel] HideoutTrophy.render failed:", v837)
				local v838 = p822:FindFirstChild("TrophyBlock")
				if v838 then
					v838:Destroy()
				end
			else
				local v839 = v831.mount
				if type(v839) == "function" then
					local v840 = v_u_79(p822, "TrophyMount", {
						["LayoutOrder"] = p823,
						["Size"] = UDim2.new(1, -8, 0, 0)
					})
					v_u_20.layout(v840, "v", 12)
					local v841 = v831.mount
					local v842 = {
						["view"] = v_u_27,
						["slots"] = v827,
						["trophies"] = v828,
						["seen"] = v_u_43.seen,
						["have"] = v_u_43.have,
						["cctx"] = p_u_19.cctx,
						["HushUI"] = v_u_20,
						["Theme"] = v_u_21,
						["Recipe"] = v_u_43,
						["compact"] = v_u_4.compact(v_u_21),
						["width"] = p824
					}
					local v843, v844 = pcall(v841, v840, v842)
					if v843 then
						v_u_36 = v844
						return
					end
					warn("[HideoutPanel] HideoutTrophy.mount failed:", v844)
					v840:Destroy()
				end
			end
		end
		local v845 = v_u_79(p822, "TrophyMount", {
			["LayoutOrder"] = p823,
			["Size"] = UDim2.new(1, -8, 0, 0)
		})
		local v846 = v_u_43.section
		local v847 = #v828
		local v848 = v846(v845, "TROPHIES", 1, ("%d / %d ON DISPLAY"):format(math.min(v847, v827), v827))
		v848.Size = UDim2.new(1, 0, 0, 0)
		if #v828 == 0 then
			v_u_20.label({
				["parent"] = nil,
				["text"] = "Rare finds and boss kills end up here. Nothing worth hanging up yet.",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["track"] = false,
				["parent"] = v848,
				["color"] = v_u_22.muted
			})
		else
			local v849 = v_u_97(v848, "Grid", 2, 8)
			for v850, v853 in v828 do
				if v_u_43.def(v853) then
					v_u_43.cell(v849, v853, {
						["size"] = 64,
						["order"] = nil,
						["name"] = nil,
						["locked"] = nil,
						["order"] = v850,
						["name"] = "Trophy_" .. v850,
						["locked"] = v827 < v850
					})
				else
					local v852 = v_u_20.new("Frame", {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "Plate_" .. v850,
						["BackgroundColor3"] = v_u_22.accentDeep,
						["Size"] = UDim2.fromOffset(200, 64),
						["LayoutOrder"] = v850
					}, v849)
					v_u_20.stroke(v852, v_u_22.accentDim)
					if string.sub(v853, 1, 7) == "zombie_" then
						local v853 = string.upper((string.gsub(string.sub(v853, 8), "_", " ")))
					end
					v_u_20.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "caps",
						["color"] = nil,
						["wrap"] = true,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["track"] = false,
						["parent"] = v852,
						["text"] = v853,
						["color"] = v_u_22.accent,
						["size"] = UDim2.new(1, -12, 1, -8),
						["position"] = UDim2.fromOffset(6, 4)
					})
				end
			end
		end
	end
	local function v_u_906() -- name: renderNow
		-- upvalues: (ref) v_u_29, (ref) v_u_26, (ref) v_u_27, (copy) v_u_31, (ref) v_u_36, (copy) v_u_20, (copy) v_u_25, (copy) v_u_79, (copy) v_u_22, (copy) p_u_19, (copy) v_u_21, (copy) v_u_23, (ref) v_u_4, (ref) v_u_358, (ref) v_u_28, (ref) v_u_43, (ref) v_u_39, (copy) v_u_232, (copy) v_u_405, (copy) v_u_560, (ref) v_u_37, (copy) v_u_854, (copy) v_u_821, (copy) v_u_112, (copy) v_u_133
		local v855 = v_u_29
		if v855 and (v_u_26 and v_u_27) then
			table.clear(v_u_31)
			local v856 = v_u_36
			v_u_36 = nil
			if type(v856) == "table" then
				local v857 = v856.destroy
				if type(v857) == "function" then
					local v858 = v856.destroy
					pcall(v858)
				end
			end
			v_u_20.hideTooltip()
			for _, v859 in v855:GetChildren() do
				if v859:IsA("UIPadding") then
					continue
				end
				v859:Destroy()
			end
			if v_u_25.loadState(v_u_27) == "offline" then
				local v860 = v_u_79(v855, "Offline", {})
				v_u_20.layout(v860, "v", 12)
				v_u_20.label({
					["parent"] = nil,
					["name"] = "Why",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 1,
					["track"] = false,
					["parent"] = v860,
					["text"] = v_u_25.LOAD_FAIL,
					["color"] = v_u_22.text
				})
				local v861 = p_u_19.hooks
				local v862
				if type(v861) == "table" then
					v862 = v861.retry
				else
					v862 = nil
				end
				if v862 then
					local v863 = v_u_20.button({
						["parent"] = nil,
						["name"] = "Retry",
						["text"] = nil,
						["kind"] = "primary",
						["size"] = nil,
						["onClick"] = nil,
						["parent"] = v860,
						["text"] = v_u_25.RETRY_TEXT,
						["size"] = UDim2.new(0, 180, 0, v_u_21.touch(44)),
						["onClick"] = v862
					})
					v863.LayoutOrder = 2
					local v864 = { false }
					if v863 and not v864[1] then
						v863:SetAttribute("PadDefault", true)
						v864[1] = true
					end
				end
				return
			else
				local v865 = v_u_26
				local v866 = v_u_23
				if v866 then
					v866 = v_u_23.get(v865)
				end
				local v867 = v_u_27.modules
				if v867 then
					v867 = v_u_27.modules[v865]
				end
				if v866 and v867 then
					local v868 = not v_u_4.compact(v_u_21)
					local v869 = v867.lvl or 0
					v_u_358 = false
					local v870 = v_u_28
					if v870 then
						v870 = v_u_28:FindFirstChild("Subtitle", true)
					end
					if v870 and v870:IsA("TextLabel") then
						v_u_20.setText(v870, "HIDEOUT")
					end
					local v871 = (v867.maxLevel or #v866.levels) <= 1
					local v872 = v_u_28
					if v872 then
						v872 = v_u_28:FindFirstChild("Header")
					end
					local v873
					if v872 then
						v873 = v872:FindFirstChild("StateChip")
					else
						v873 = v872
					end
					if v873 then
						v873:Destroy()
					end
					if v871 and v872 then
						local v874
						if v867.building == nil and v867.next == nil then
							v874 = v869 > 0
						else
							v874 = false
						end
						local v875 = v_u_43.chip
						local v876 = nil
						local v877 = v874 and "BUILT" or (v867.building and "BUILDING" or (v869 <= 0 and "NOT BUILT" or ("LEVEL %d"):format(v869)))
						local v878 = {
							["name"] = "StateChip",
							["color"] = nil,
							["icon"] = nil
						}
						local v879
						if v874 then
							v879 = v_u_22.success
						elseif v867.building then
							v879 = v_u_22.accent
						else
							v879 = v_u_22.muted
						end
						v878.color = v879
						v878.icon = v874 and "check" or (v867.building and "clock" or "lock")
						local v880 = v875(v876, v877, v878)
						v880.AnchorPoint = Vector2.new(1, 0)
						v880.Position = UDim2.new(1, -48, 0, 4)
						v880.Parent = v872
					end
					local v881
					if v868 then
						v881 = not v871
					else
						v881 = v868
					end
					local v882 = v_u_20.list
					local v883 = {
						["parent"] = nil,
						["name"] = "List",
						["size"] = nil,
						["position"] = nil,
						["gap"] = 20,
						["parent"] = v855
					}
					local v884
					if v881 then
						v884 = UDim2.new(1, -(v_u_39 + 24), 1, 0)
					else
						v884 = UDim2.fromScale(1, 1)
					end
					v883.size = v884
					local v885
					if v881 then
						v885 = UDim2.fromOffset(v_u_39 + 24, 0)
					else
						v885 = UDim2.fromOffset(0, 0)
					end
					v883.position = v885
					local v886 = v882(v883)
					local v887 = nil
					if v881 then
						v887 = v_u_20.list({
							["parent"] = nil,
							["name"] = "Left",
							["size"] = nil,
							["gap"] = 16,
							["parent"] = v855,
							["size"] = UDim2.new(0, v_u_39, 1, 0)
						})
						v_u_20.divider({
							["parent"] = nil,
							["vertical"] = true,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v855,
							["position"] = UDim2.fromOffset(v_u_39 + 11, 0),
							["size"] = UDim2.new(0, 1, 1, 0)
						})
					elseif not v871 then
						v887 = v_u_79(v886, "Left", {
							["Size"] = nil,
							["LayoutOrder"] = -1,
							["Size"] = UDim2.new(1, -8, 0, 0)
						})
						v_u_20.layout(v887, "v", 16)
					end
					if v887 then
						v_u_232(v887, v865, v866, v867, v868)
					end
					local v888 = { false }
					local v889 = 0
					local v890
					if v869 <= 0 or v867.building ~= nil then
						v890 = true
					elseif v867.next == nil then
						v890 = false
					else
						v890 = v867.next.canBuild == true
					end
					local v891
					if v890 then
						local v892 = v_u_405
						v889 = v889 + 1
						v892(v886, v865, v866, v867, v889 * 10, v888)
						v891 = v889
					else
						v891 = v889
					end
					if v867.recipes then
						local v893 = v_u_560
						v889 = v891 + 1
						v893(v886, v865, v867, v889 * 10, v888)
						v891 = v889
					end
					local v894
					if v881 then
						v894 = v_u_37 - 48 - v_u_39 - 24
					elseif v868 then
						v894 = v_u_37 - 48
					else
						v894 = v_u_21.refSize().X - 72
					end
					local v895 = v894 - 14
					if v865 == "trophy_wall" then
						local v896 = v_u_854
						v889 = v891 + 1
						v896(v886, v889 * 10, v895, v868 and v871)
					else
						local v897 = p_u_19.hooks
						if type(v897) == "table" then
							local v898 = v_u_821
							v889 = v891 + 1
							v898(v886, v865, v866, v867, v889 * 10, v888)
							v889 = v889 + 1
						elseif p_u_19.extra then
							local v899 = p_u_19.extra
							v889 = v891 + 1
							local v900 = v889 * 10
							local v901 = v_u_27
							local v902 = v_u_43.section
							local v903 = v_u_112
							local v904, v905 = pcall(v899, v865, v886, v900, v901, v902, v903)
							if not v904 then
								warn("[HideoutPanel] extra failed:", v905)
							end
						end
					end
					if not v890 then
						v_u_405(v886, v865, v866, v867, 900, v888)
					end
					v_u_133()
				else
					v_u_20.label({
						["parent"] = nil,
						["text"] = "No data for this station yet.",
						["style"] = "body",
						["color"] = nil,
						["parent"] = v855,
						["color"] = v_u_22.text2
					})
				end
			end
		else
			return
		end
	end
	local v_u_907 = nil
	local v_u_908 = nil
	local function _() -- name: render
		-- upvalues: (ref) v_u_29, (ref) v_u_26, (ref) v_u_907, (ref) v_u_908, (copy) v_u_20, (copy) v_u_906
		local v909 = v_u_29
		if v909 and (v_u_26 and (v_u_26 == v_u_907 and v909 == v_u_908)) then
			v_u_20.keepScroll(v909, v_u_906)
		else
			v_u_906()
		end
		v_u_907 = v_u_26
		v_u_908 = v909
	end
	local v_u_910 = {}
	local function v_u_950(p911) -- name: ensureWindow
		-- upvalues: (copy) v_u_21, (ref) v_u_4, (copy) v_u_52, (ref) v_u_28, (ref) v_u_34, (ref) v_u_36, (ref) v_u_29, (ref) v_u_30, (copy) v_u_20, (copy) v_u_72, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39, (copy) p_u_19, (ref) v_u_26
		local v912 = v_u_21.refSize()
		local v913 = v_u_4.compact
		local v914 = v_u_21
		local v915 = tostring(v913(v914))
		local v916 = v912.X
		local v917 = v912.Y
		local v918 = v_u_52().right
		local v919 = ("%s|%d|%d|%d"):format(v915, v916, v917, (math.floor(v918)))
		if not v_u_28 or (not v_u_28.Parent or v919 ~= v_u_34) then
			if v_u_28 then
				local v920 = v_u_36
				v_u_36 = nil
				if type(v920) == "table" then
					local v921 = v920.destroy
					if type(v921) == "function" then
						local v922 = v920.destroy
						pcall(v922)
					end
				end
				v_u_28:Destroy()
				v_u_28 = nil
				v_u_29 = nil
				v_u_30 = nil
			end
			v_u_34 = v919
			local v923 = v_u_4.compact(v_u_21)
			local v924 = not v_u_20.topInset and 64 or v_u_20.topInset()
			local v925, v926, v927, v928 = v_u_72()
			v_u_37 = v925
			v_u_38 = v926
			v_u_39 = v925 >= 1100 and 300 or 272
			local v929 = v_u_20.window
			local v930 = {
				["parent"] = nil,
				["title"] = nil,
				["subtitle"] = "HIDEOUT",
				["size"] = nil,
				["position"] = nil,
				["onClose"] = nil,
				["parent"] = p_u_19.root,
				["title"] = p911
			}
			local v931
			if v923 then
				v931 = UDim2.new(1, -24, 1, -(v924 + 12))
			else
				v931 = UDim2.fromOffset(v925, v926)
			end
			v930.size = v931
			local v932
			if v923 then
				local v933 = UDim2.new
				local v934 = v924 / 2
				v932 = v933(0.5, 0, 0.5, (math.floor(v934)))
			else
				local v935 = UDim2.fromOffset
				local v936 = v925 / 2
				local v937 = v927 + math.floor(v936)
				local v938 = v926 / 2
				v932 = v935(v937, v928 + math.floor(v938))
			end
			v930.position = v932
			function v930.onClose() -- name: onClose
				-- upvalues: (ref) v_u_26, (ref) v_u_36, (ref) v_u_20, (ref) p_u_19
				v_u_26 = nil
				local v939 = v_u_36
				v_u_36 = nil
				if type(v939) == "table" then
					local v940 = v939.destroy
					if type(v940) == "function" then
						local v941 = v939.destroy
						pcall(v941)
					end
				end
				v_u_20.hideTooltip()
				if p_u_19.onClosed then
					task.spawn(p_u_19.onClosed)
				end
			end
			local v942, v943, v944 = v929(v930)
			v_u_28 = v942
			v_u_29 = v943
			v_u_30 = v944
			if not v923 then
				local v945 = Instance.new("UISizeConstraint")
				local v946 = Vector2.new
				local v947 = v_u_21.refSize().X - 32
				local v948 = math.max(420, v947)
				local v949 = v_u_21.refSize().Y - v924 - 40
				v945.MaxSize = v946(v948, (math.max(360, v949)))
				v945.Parent = v942
			end
		end
	end
	local v_u_951 = 0
	local function v_u_967(p_u_952) -- name: padFocus
		-- upvalues: (copy) v_u_20, (ref) v_u_951, (ref) v_u_28, (ref) v_u_1, (copy) v_u_910, (ref) v_u_29
		if v_u_20.device() == "Gamepad" then
			v_u_951 = v_u_951 + 1
			local v_u_953 = v_u_951
			if p_u_952 then
				local v954 = v_u_28
				if v954 then
					for _, v955 in v954:GetDescendants() do
						if not v955:IsA("GuiObject") or (v955:GetAttribute("PadDefault") ~= true or not v955.Visible) then
							continue
						end
						v_u_1.SelectedObject = v955
					end
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_28, (copy) v_u_953, (ref) v_u_951, (ref) v_u_910, (ref) v_u_1, (copy) p_u_952, (ref) v_u_29
				local v956 = nil
				for _ = 1, 8 do
					task.wait(0.06)
					local v957 = v_u_28
					if v_u_953 ~= v_u_951 or not (v957 and (v957.Parent and v_u_910.isOpen())) then
						return
					end
					local v958 = v_u_1.SelectedObject
					if v958 and (v958:IsDescendantOf(v957) and (v958 == v956 or not p_u_952)) then
						return
					end
					local v959 = nil
					for _, v960 in v957:GetDescendants() do
						if not v960:IsA("GuiObject") or (v960:GetAttribute("PadDefault") ~= true or not v960.Visible) then
							continue
						end
						v959 = v960
					end
					if not v959 then
						local v961 = v_u_29
						local v962 = (1 / 0)
						for _, v963 in not v961 and {} or v961:GetDescendants() do
							if not v963:IsA("GuiButton") or (not v963.Selectable or (not v963.Visible or v963.AbsoluteSize.X <= 0)) then
								continue
							end
							local v964 = v963.AbsolutePosition
							local v965 = v964.Y / 8
							local v966 = math.floor(v965) * 100000 + v964.X
							if v966 >= v962 then
								continue
							end
							v959 = v963
							v962 = v966
						end
					end
					if not v959 then
						break
					end
					v_u_1.SelectedObject = v959
					v956 = v959
				end
			end)
		end
	end
	local function _(p968)
		-- upvalues: (ref) v_u_27, (ref) v_u_26, (ref) v_u_30, (ref) v_u_29, (ref) v_u_907, (ref) v_u_908, (copy) v_u_20, (copy) v_u_906, (ref) v_u_951, (ref) v_u_28, (copy) v_u_910, (ref) v_u_1
		if v_u_27 then
			local v969 = v_u_27.modules
			if type(v969) == "table" and (v_u_26 and (v_u_30 and v_u_30.isOpen())) then
				local v970 = false
				for _, v971 in v_u_27.modules do
					for _, v972 in { "craft", "craft2" } do
						local v973
						if type(v971) == "table" then
							v973 = v971[v972]
						else
							v973 = false
						end
						if type(v973) ~= "table" or v973.ready then
							continue
						end
						local v974 = v973.readyAt
						if type(v974) ~= "number" or v973.readyAt > p968 then
							continue
						end
						v973.ready = true
						v973.left = 0
						v970 = true
					end
				end
				if v970 then
					local v975 = v_u_29
					if v975 and (v_u_26 and (v_u_26 == v_u_907 and v975 == v_u_908)) then
						v_u_20.keepScroll(v975, v_u_906)
					else
						v_u_906()
					end
					v_u_907 = v_u_26
					v_u_908 = v975
					if v_u_20.device() ~= "Gamepad" then
						return
					end
					v_u_951 = v_u_951 + 1
					local v_u_976 = v_u_951
					local v_u_977 = false
					task.spawn(function()
						-- upvalues: (ref) v_u_28, (copy) v_u_976, (ref) v_u_951, (ref) v_u_910, (ref) v_u_1, (copy) v_u_977, (ref) v_u_29
						local v978 = nil
						for _ = 1, 8 do
							task.wait(0.06)
							local v979 = v_u_28
							if v_u_976 ~= v_u_951 or not (v979 and (v979.Parent and v_u_910.isOpen())) then
								return
							end
							local v980 = v_u_1.SelectedObject
							if v980 and (v980:IsDescendantOf(v979) and (v980 == v978 or not v_u_977)) then
								return
							end
							local v981 = nil
							for _, v982 in v979:GetDescendants() do
								if not v982:IsA("GuiObject") or (v982:GetAttribute("PadDefault") ~= true or not v982.Visible) then
									continue
								end
								v981 = v982
							end
							if not v981 then
								local v983 = v_u_29
								local v984 = (1 / 0)
								for _, v985 in not v983 and {} or v983:GetDescendants() do
									if not v985:IsA("GuiButton") or (not v985.Selectable or (not v985.Visible or v985.AbsoluteSize.X <= 0)) then
										continue
									end
									local v986 = v985.AbsolutePosition
									local v987 = v986.Y / 8
									local v988 = math.floor(v987) * 100000 + v986.X
									if v988 >= v984 then
										continue
									end
									v981 = v985
									v984 = v988
								end
							end
							if not v981 then
								break
							end
							v_u_1.SelectedObject = v981
							v978 = v981
						end
					end)
				end
				return
			end
		end
	end
	function v_u_910.show(p989, p990) -- name: show
		-- upvalues: (ref) v_u_27, (copy) v_u_23, (copy) v_u_950, (ref) v_u_26, (ref) v_u_30, (ref) v_u_907, (ref) v_u_41, (ref) v_u_29, (ref) v_u_908, (copy) v_u_20, (copy) v_u_906, (copy) v_u_967
		v_u_27 = p990
		local v991 = v_u_23
		if v991 then
			v991 = v_u_23.get(p989)
		end
		local v992
		if v991 then
			v992 = v991.name
		else
			v992 = string.upper(p989)
		end
		v_u_950(v992)
		v_u_26 = p989
		if v_u_30 then
			v_u_30.setTitle(v992)
		end
		if not (v_u_30 and v_u_30.isOpen()) then
			v_u_907 = nil
			v_u_41 = "craft"
		end
		local v993 = v_u_30
		if v993 then
			v993 = v_u_30.isOpen()
		end
		local v994 = not v993
		local v995 = v_u_29
		if v995 and (v_u_26 and (v_u_26 == v_u_907 and v995 == v_u_908)) then
			v_u_20.keepScroll(v995, v_u_906)
		else
			v_u_906()
		end
		v_u_907 = v_u_26
		v_u_908 = v995
		if v_u_30 and not v_u_30.isOpen() then
			v_u_30.open()
		end
		v_u_967(v994)
	end
	function v_u_910.update(p996) -- name: update
		-- upvalues: (ref) v_u_27, (ref) v_u_26, (ref) v_u_30, (ref) v_u_29, (ref) v_u_907, (ref) v_u_908, (copy) v_u_20, (copy) v_u_906, (ref) v_u_951, (ref) v_u_28, (copy) v_u_910, (ref) v_u_1
		v_u_27 = p996
		if v_u_26 and (v_u_30 and v_u_30.isOpen()) then
			local v997 = v_u_29
			if v997 and (v_u_26 and (v_u_26 == v_u_907 and v997 == v_u_908)) then
				v_u_20.keepScroll(v997, v_u_906)
			else
				v_u_906()
			end
			v_u_907 = v_u_26
			v_u_908 = v997
			if v_u_20.device() ~= "Gamepad" then
				return
			end
			v_u_951 = v_u_951 + 1
			local v_u_998 = v_u_951
			local v_u_999 = false
			task.spawn(function()
				-- upvalues: (ref) v_u_28, (copy) v_u_998, (ref) v_u_951, (ref) v_u_910, (ref) v_u_1, (copy) v_u_999, (ref) v_u_29
				local v1000 = nil
				for _ = 1, 8 do
					task.wait(0.06)
					local v1001 = v_u_28
					if v_u_998 ~= v_u_951 or not (v1001 and (v1001.Parent and v_u_910.isOpen())) then
						return
					end
					local v1002 = v_u_1.SelectedObject
					if v1002 and (v1002:IsDescendantOf(v1001) and (v1002 == v1000 or not v_u_999)) then
						return
					end
					local v1003 = nil
					for _, v1004 in v1001:GetDescendants() do
						if not v1004:IsA("GuiObject") or (v1004:GetAttribute("PadDefault") ~= true or not v1004.Visible) then
							continue
						end
						v1003 = v1004
					end
					if not v1003 then
						local v1005 = v_u_29
						local v1006 = (1 / 0)
						for _, v1007 in not v1005 and {} or v1005:GetDescendants() do
							if not v1007:IsA("GuiButton") or (not v1007.Selectable or (not v1007.Visible or v1007.AbsoluteSize.X <= 0)) then
								continue
							end
							local v1008 = v1007.AbsolutePosition
							local v1009 = v1008.Y / 8
							local v1010 = math.floor(v1009) * 100000 + v1008.X
							if v1010 >= v1006 then
								continue
							end
							v1003 = v1007
							v1006 = v1010
						end
					end
					if not v1003 then
						break
					end
					v_u_1.SelectedObject = v1003
					v1000 = v1003
				end
			end)
		end
	end
	function v_u_910.close() -- name: close
		-- upvalues: (ref) v_u_30, (ref) v_u_26, (ref) v_u_907, (ref) v_u_36
		if v_u_30 and v_u_30.isOpen() then
			v_u_30.close()
		end
		v_u_26 = nil
		v_u_907 = nil
		local v1011 = v_u_36
		v_u_36 = nil
		if type(v1011) == "table" then
			local v1012 = v1011.destroy
			if type(v1012) == "function" then
				local v1013 = v1011.destroy
				pcall(v1013)
			end
		end
	end
	function v_u_910.isOpen() -- name: isOpen
		-- upvalues: (ref) v_u_30, (ref) v_u_26
		local v1014 = v_u_30 ~= nil and v_u_30.isOpen()
		if v1014 then
			v1014 = v_u_26 ~= nil
		end
		return v1014
	end
	function v_u_910.module() -- name: module
		-- upvalues: (ref) v_u_26
		return v_u_26
	end
	function v_u_910.bench(p1015) -- name: bench
		-- upvalues: (ref) v_u_41, (ref) v_u_26, (ref) v_u_30, (ref) v_u_29, (ref) v_u_907, (ref) v_u_908, (copy) v_u_20, (copy) v_u_906
		v_u_41 = p1015 == "dismantle" and "dismantle" or "craft"
		if v_u_26 and (v_u_30 and v_u_30.isOpen()) then
			local v1016 = v_u_29
			if v1016 and (v_u_26 and (v_u_26 == v_u_907 and v1016 == v_u_908)) then
				v_u_20.keepScroll(v1016, v_u_906)
			else
				v_u_906()
			end
			v_u_907 = v_u_26
			v_u_908 = v1016
		end
	end
	function v_u_910.step(p1017) -- name: step
		-- upvalues: (ref) v_u_35, (ref) v_u_28, (ref) v_u_34, (copy) v_u_21, (ref) v_u_4, (copy) v_u_52, (ref) v_u_26, (ref) v_u_30, (copy) v_u_910, (ref) v_u_27, (ref) v_u_36, (ref) v_u_29, (copy) v_u_31, (ref) v_u_33, (copy) v_u_133
		v_u_35 = v_u_35 + p1017
		if v_u_35 >= 0.5 then
			v_u_35 = 0
			if v_u_28 then
				local v1018 = v_u_34
				local v1019 = v_u_21.refSize()
				local v1020 = v_u_4.compact
				local v1021 = v_u_21
				local v1022 = tostring(v1020(v1021))
				local v1023 = v1019.X
				local v1024 = v1019.Y
				local v1025 = v_u_52().right
				if v1018 ~= ("%s|%d|%d|%d"):format(v1022, v1023, v1024, (math.floor(v1025))) then
					local v1026 = v_u_26
					if v1026 and (v_u_30 and v_u_30.isOpen()) then
						v_u_910.show(v1026, v_u_27)
					else
						local v1027 = v_u_36
						v_u_36 = nil
						if type(v1027) == "table" then
							local v1028 = v1027.destroy
							if type(v1028) == "function" then
								local v1029 = v1027.destroy
								pcall(v1029)
							end
						end
						v_u_28:Destroy()
						v_u_28 = nil
						v_u_29 = nil
						v_u_30 = nil
						v_u_26 = nil
						table.clear(v_u_31)
					end
				end
			end
		end
		if #v_u_31 ~= 0 then
			v_u_33 = v_u_33 + p1017
			if v_u_33 >= 0.25 then
				v_u_33 = 0
				v_u_133()
			end
		end
	end
	local v1030, v1031 = pcall(function()
		-- upvalues: (copy) p_u_19
		return p_u_19.cctx.lib.VirtualPad
	end)
	local v_u_1032
	if v1030 and (type(v1031) == "table" and v1031.InputBegan) then
		v_u_1032 = v1031.InputBegan:Connect(function(p1033)
			-- upvalues: (copy) v_u_910
			if p1033.KeyCode == Enum.KeyCode.ButtonB and v_u_910.isOpen() then
				local v1034 = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
				if v1034 then
					v1034 = v1034:FindFirstChild("HushModal")
				end
				if v1034 and (v1034:IsA("ScreenGui") and v1034.Enabled) then
					for _, v1035 in v1034:GetChildren() do
						if v1035.Name ~= "Modal" or not (v1035:IsA("GuiObject") and v1035.Visible) then
							continue
						end
						return
					end
				end
				v_u_910.close()
			end
		end)
	else
		v_u_1032 = nil
	end
	function v_u_910.destroy() -- name: destroy
		-- upvalues: (ref) v_u_1032, (ref) v_u_36, (ref) v_u_43, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_26, (copy) v_u_31
		if v_u_1032 then
			v_u_1032:Disconnect()
			v_u_1032 = nil
		end
		local v1036 = v_u_36
		v_u_36 = nil
		if type(v1036) == "table" then
			local v1037 = v1036.destroy
			if type(v1037) == "function" then
				local v1038 = v1036.destroy
				pcall(v1038)
			end
		end
		local v1039 = v_u_43.destroy
		pcall(v1039)
		if v_u_28 then
			v_u_28:Destroy()
		end
		v_u_28 = nil
		v_u_29 = nil
		v_u_30 = nil
		v_u_26 = nil
		table.clear(v_u_31)
	end
	return v_u_910
end
return v_u_4