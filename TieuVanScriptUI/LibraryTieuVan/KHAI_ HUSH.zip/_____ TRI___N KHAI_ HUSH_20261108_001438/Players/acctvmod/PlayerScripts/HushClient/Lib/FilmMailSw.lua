-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmMailSw

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.lines(p6) -- name: lines
	local v7 = {}
	if type(p6) ~= "table" then
		table.insert(v7, {
			["name"] = "State",
			["text"] = "Reading the switch ...",
			["kind"] = "muted"
		})
		return v7
	end
	local v8 = p6.on == true
	local v9 = {
		["name"] = "State",
		["text"] = nil,
		["kind"] = nil
	}
	local v10 = p6.scope or "?"
	v9.text = ("Delivery by mail is %s  \194\183  scope %s  \194\183  switch %s"):format(v8 and "ON" or "OFF", tostring(v10), p6.rawOn == true and "on" or "off")
	v9.kind = v8 and "ok" or "muted"
	table.insert(v7, v9)
	if p6.flag == false then
		table.insert(v7, {
			["name"] = "Flag",
			["text"] = "The build flag Config.FLAGS.MailDelivery is OFF: nothing is delivered by mail whatever the switch says.",
			["kind"] = "warn"
		})
	end
	if p6.rawOn == true and (not v8 and p6.flag ~= false) then
		table.insert(v7, {
			["name"] = "Good",
			["text"] = "This server has no good read of the switch (10 minutes): new deliveries are off here until it reads it again.",
			["kind"] = "warn"
		})
	end
	local v11 = p6.byName
	local v12 = (type(v11) ~= "string" or p6.byName == "") and "" or " by " .. p6.byName
	local v13 = {
		["name"] = "Version",
		["text"] = nil,
		["kind"] = "text"
	}
	local v14 = p6.v
	v13.text = ("Version %d%s%s"):format(tonumber(v14) or 0, v12, p6.openDefault == true and "  \194\183  open by default here (Studio or test game)" or "  \194\183  closed by default (live)")
	table.insert(v7, v13)
	return v7
end
function v_u_4.mount(p_u_15, p_u_16, p_u_17, p18) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_19 = type(p18) ~= "table" and {} or p18
	if type(p_u_17) == "table" then
		local v20 = p_u_17.color
		if type(v20) ~= "table" then
			p_u_17 = v_u_3.Theme
		end
	else
		p_u_17 = v_u_3.Theme
	end
	local v_u_21 = p_u_17.color
	local v22 = v_u_19.inner
	local v23 = type(v22) ~= "number" and 438 or v_u_19.inner
	local v_u_24 = v_u_19.gui
	local v_u_25 = 0
	local v_u_26 = true
	if v_u_24 then
		v_u_24.Destroying:Connect(function()
			-- upvalues: (ref) v_u_26
			v_u_26 = false
		end)
	end
	local v27 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Delivery by mail  \194\183  all servers",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_15,
		["color"] = v_u_21.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v28 = v_u_19.order
	local v29
	if type(v28) == "function" then
		v29 = v_u_19.order()
	else
		v_u_25 = v_u_25 + 1
		v29 = v_u_25
	end
	v27.LayoutOrder = v29
	local v_u_30 = v_u_3.new("Frame", {
		["Name"] = "MailSwList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_15)
	v_u_3.layout(v_u_30, "v", 2)
	local v31 = v_u_19.order
	local v32
	if type(v31) == "function" then
		v32 = v_u_19.order()
	else
		v_u_25 = v_u_25 + 1
		v32 = v_u_25
	end
	v_u_30.LayoutOrder = v32
	local function v39(p33, p34, p35) -- name: small
		-- upvalues: (ref) v_u_3, (copy) p_u_15, (copy) v_u_21, (copy) v_u_19, (ref) v_u_25
		local v36 = v_u_3.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_15,
			["name"] = p33,
			["text"] = p34,
			["color"] = p35 or v_u_21.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v37 = v_u_19.order
		local v38
		if type(v37) == "function" then
			v38 = v_u_19.order()
		else
			v_u_25 = v_u_25 + 1
			v38 = v_u_25
		end
		v36.LayoutOrder = v38
		return v36
	end
	local function v53(p40, p41) -- name: row
		-- upvalues: (ref) v_u_3, (copy) p_u_17, (copy) p_u_15, (copy) v_u_19, (ref) v_u_25
		local v42 = v_u_3.new
		local v43 = "Frame"
		local v44 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = p41 or "MailSwRow"
		}
		local v45 = UDim2.new
		local v46 = 1
		local v47 = 0
		local v48 = 0
		if not p40 then
			local v49 = p_u_17.touch
			p40 = type(v49) ~= "function" and 32 or p_u_17.touch(32)
		end
		v44.Size = v45(v46, v47, v48, p40)
		local v50 = v42(v43, v44, p_u_15)
		v_u_3.layout(v50, "h", 6)
		local v51 = v_u_19.order
		local v52
		if type(v51) == "function" then
			v52 = v_u_19.order()
		else
			v_u_25 = v_u_25 + 1
			v52 = v_u_25
		end
		v50.LayoutOrder = v52
		return v50
	end
	local v_u_54 = nil
	local v_u_55 = false
	local v_u_56 = (-1 / 0)
	local v_u_57 = nil
	local v_u_58 = nil
	local v_u_59 = 0
	local v_u_60 = {}
	local v_u_61 = nil
	local function v75() -- name: refresh
		-- upvalues: (ref) v_u_55, (copy) p_u_16, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (ref) v_u_3, (ref) v_u_57, (copy) v_u_21, (ref) v_u_61, (copy) v_u_19
		local v62 = {
			["cmd"] = "status"
		}
		if not v_u_55 then
			local v63 = p_u_16
			if type(v63) ~= "function" then
				return
			end
			v_u_55 = true
			local v_u_64 = true
			local function v72(p65) -- name: done
				-- upvalues: (ref) v_u_55, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (copy) v_u_64, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
				v_u_55 = false
				if v_u_26 then
					v_u_56 = os.clock()
					if type(p65) == "table" then
						local v66 = p65.data
						if type(v66) == "table" then
							v_u_54 = p65.data
						end
						if not v_u_64 then
							local v67 = p65.msg or (p65.ok and "Done." or "Refused.")
							local v68 = tostring(v67)
							local v69 = p65.ok ~= true
							v_u_3.setText(v_u_57, v68)
							local v70 = v_u_57
							local v71
							if v69 then
								v71 = v_u_21.danger
							else
								v71 = v_u_21.text2
							end
							v70.TextColor3 = v71
						end
					elseif not v_u_64 then
						v_u_3.setText(v_u_57, "The server did not answer.")
						v_u_57.TextColor3 = v_u_21.danger
					end
					v_u_61(v_u_54)
				end
			end
			local v73 = v_u_19.sendQuiet
			local v74
			if type(v73) == "function" then
				v74 = v_u_19.sendQuiet
			else
				v74 = p_u_16
			end
			v74("server.mail", v62, v72)
		end
	end
	local v87 = {
		["parent"] = nil,
		["name"] = "MailSwToggle",
		["label"] = "Delivery by mail",
		["value"] = false,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = p_u_15,
		["width"] = v23,
		["onChange"] = function(p76) -- name: onChange
			-- upvalues: (ref) v_u_55, (copy) p_u_16, (ref) v_u_3, (ref) v_u_57, (copy) v_u_21, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (ref) v_u_61
			local v77 = {
				["cmd"] = "set",
				["on"] = nil,
				["on"] = p76
			}
			if not v_u_55 then
				local v78 = p_u_16
				if type(v78) ~= "function" then
					return
				end
				v_u_55 = true
				v_u_3.setText(v_u_57, "Working ...")
				v_u_57.TextColor3 = v_u_21.text2
				local v_u_79 = nil
				p_u_16("server.mail", v77, function(p80) -- name: done
					-- upvalues: (ref) v_u_55, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (copy) v_u_79, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
					v_u_55 = false
					if v_u_26 then
						v_u_56 = os.clock()
						if type(p80) == "table" then
							local v81 = p80.data
							if type(v81) == "table" then
								v_u_54 = p80.data
							end
							if not v_u_79 then
								local v82 = p80.msg or (p80.ok and "Done." or "Refused.")
								local v83 = tostring(v82)
								local v84 = p80.ok ~= true
								v_u_3.setText(v_u_57, v83)
								local v85 = v_u_57
								local v86
								if v84 then
									v86 = v_u_21.danger
								else
									v86 = v_u_21.text2
								end
								v85.TextColor3 = v86
							end
						elseif not v_u_79 then
							v_u_3.setText(v_u_57, "The server did not answer.")
							v_u_57.TextColor3 = v_u_21.danger
						end
						v_u_61(v_u_54)
					end
				end)
			end
		end
	}
	local v88, v89 = v_u_3.toggle(v87)
	local v90 = v_u_19.order
	local v91
	if type(v90) == "function" then
		v91 = v_u_19.order()
	else
		v_u_25 = v_u_25 + 1
		v91 = v_u_25
	end
	v88.LayoutOrder = v91
	local v_u_92 = v89
	v39("MailSwScopeLabel", "Who gets purchases by mail (the claim, the expiry and the view always work)", v_u_21.muted)
	local v93 = p_u_17.touch
	local v94 = v53(type(v93) ~= "function" and 32 or p_u_17.touch(32), "MailSwScopeRow")
	local function v_u_120(p95) -- name: setScope
		-- upvalues: (ref) v_u_54, (ref) v_u_58, (ref) v_u_59, (ref) v_u_55, (copy) p_u_16, (ref) v_u_3, (ref) v_u_57, (copy) v_u_21, (ref) v_u_26, (ref) v_u_56, (ref) v_u_61
		if p95 == "all" then
			local v96 = v_u_54
			local v97
			if type(v96) == "table" then
				v97 = v_u_54.openDefault == true and true or v_u_54.studio == true
			else
				v97 = false
			end
			if not v97 then
				local v98 = os.clock()
				if v_u_58 == "scope:all" and v98 - v_u_59 <= 6 then
					v_u_58 = nil
					local v99 = {
						["cmd"] = "set",
						["scope"] = "all"
					}
					if not v_u_55 then
						local v100 = p_u_16
						if type(v100) ~= "function" then
							return
						end
						v_u_55 = true
						v_u_3.setText(v_u_57, "Working ...")
						v_u_57.TextColor3 = v_u_21.text2
						local v_u_101 = nil
						p_u_16("server.mail", v99, function(p102) -- name: done
							-- upvalues: (ref) v_u_55, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (copy) v_u_101, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
							v_u_55 = false
							if v_u_26 then
								v_u_56 = os.clock()
								if type(p102) == "table" then
									local v103 = p102.data
									if type(v103) == "table" then
										v_u_54 = p102.data
									end
									if not v_u_101 then
										local v104 = p102.msg or (p102.ok and "Done." or "Refused.")
										local v105 = tostring(v104)
										local v106 = p102.ok ~= true
										v_u_3.setText(v_u_57, v105)
										local v107 = v_u_57
										local v108
										if v106 then
											v108 = v_u_21.danger
										else
											v108 = v_u_21.text2
										end
										v107.TextColor3 = v108
									end
								elseif not v_u_101 then
									v_u_3.setText(v_u_57, "The server did not answer.")
									v_u_57.TextColor3 = v_u_21.danger
								end
								v_u_61(v_u_54)
							end
						end)
					end
				else
					v_u_58 = "scope:all"
					v_u_59 = v98
					local v109 = ("Every player gets purchases by mail in the live game. Press EVERYONE again within %d seconds to confirm."):format(6)
					v_u_3.setText(v_u_57, v109)
					v_u_57.TextColor3 = v_u_21.danger
				end
			end
		end
		v_u_58 = nil
		local v110 = {
			["cmd"] = "set",
			["scope"] = nil,
			["scope"] = p95
		}
		if not v_u_55 then
			local v111 = p_u_16
			if type(v111) ~= "function" then
				return
			end
			v_u_55 = true
			v_u_3.setText(v_u_57, "Working ...")
			v_u_57.TextColor3 = v_u_21.text2
			local v_u_112 = nil
			p_u_16("server.mail", v110, function(p113) -- name: done
				-- upvalues: (ref) v_u_55, (ref) v_u_26, (ref) v_u_56, (ref) v_u_54, (copy) v_u_112, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
				v_u_55 = false
				if v_u_26 then
					v_u_56 = os.clock()
					if type(p113) == "table" then
						local v114 = p113.data
						if type(v114) == "table" then
							v_u_54 = p113.data
						end
						if not v_u_112 then
							local v115 = p113.msg or (p113.ok and "Done." or "Refused.")
							local v116 = tostring(v115)
							local v117 = p113.ok ~= true
							v_u_3.setText(v_u_57, v116)
							local v118 = v_u_57
							local v119
							if v117 then
								v119 = v_u_21.danger
							else
								v119 = v_u_21.text2
							end
							v118.TextColor3 = v119
						end
					elseif not v_u_112 then
						v_u_3.setText(v_u_57, "The server did not answer.")
						v_u_57.TextColor3 = v_u_21.danger
					end
					v_u_61(v_u_54)
				end
			end)
		end
	end
	local v121 = (v23 - 12) / 3
	local v122 = math.floor(v121)
	local v_u_123 = v_u_56
	local v_u_124 = v_u_55
	local v_u_125 = v_u_54
	for _, v126 in {
		{ "owner", "Owner" },
		{ "testers", "Testers" },
		{ "all", "Everyone" }
	} do
		local v_u_127 = v126[1]
		local v128 = v_u_3.button
		local v129 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v94,
			["text"] = v126[2]
		}
		local v130 = p_u_17.touch
		v129.height = type(v130) ~= "function" and 32 or p_u_17.touch(32)
		v129.width = v122
		v129.maxTextWidth = v122 - 12
		function v129.onClick() -- name: onClick
			-- upvalues: (copy) v_u_120, (copy) v_u_127
			v_u_120(v_u_127)
		end
		local v131, v132 = v128(v129)
		v131.Name = "MailSwScope_" .. v_u_127
		v_u_60[v_u_127] = {
			["btn"] = v131,
			["api"] = v132,
			["press"] = function() -- name: press
				-- upvalues: (copy) v_u_120, (copy) v_u_127
				v_u_120(v_u_127)
			end
		}
	end
	v_u_57 = v_u_3.label({
		["parent"] = nil,
		["name"] = "MailSwStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_15,
		["color"] = v_u_21.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v133 = v_u_19.order
	local v134
	if type(v133) == "function" then
		v134 = v_u_19.order()
	else
		v_u_25 = v_u_25 + 1
		v134 = v_u_25
	end
	v_u_57.LayoutOrder = v134
	v39("MailSwNote", "The switch reaches every server within a minute and decides NEW purchases only: a purchase that has begun keeps its delivery, entries in the mail stay claimable, a Blackmarket delivery expires after 14 days. In the live game it starts off and for the owner only (scope).", v_u_21.muted)
	v_u_61 = function(p135)
		-- upvalues: (copy) v_u_30, (ref) v_u_4, (copy) v_u_21, (ref) v_u_3, (ref) v_u_92, (copy) v_u_60, (ref) v_u_5
		for _, v136 in v_u_30:GetChildren() do
			if not v136:IsA("GuiObject") then
				continue
			end
			v136:Destroy()
		end
		for v137, v138 in v_u_4.lines(p135) do
			local v139
			if v138.kind == "ok" then
				v139 = v_u_21.success
			elseif v138.kind == "warn" then
				v139 = v_u_21.danger
			elseif v138.kind == "muted" then
				v139 = v_u_21.muted
			else
				v139 = v_u_21.text2
			end
			local v140 = v_u_3.label
			local v141 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_30
			}
			local v142 = v138.name
			v141.name = "MailSwLine_" .. tostring(v142)
			local v143 = v138.text
			v141.text = tostring(v143)
			v141.color = v139
			v141.size = UDim2.new(1, 0, 0, 0)
			v140(v141).LayoutOrder = v137
		end
		if v_u_92 then
			local v144 = v_u_92.set
			if type(v144) == "function" then
				local v145 = v_u_92.set
				local v146
				if type(p135) == "table" then
					v146 = p135.rawOn == true
				else
					v146 = false
				end
				v145(v146)
			end
		end
		for v147, v148 in v_u_60 do
			v148.api.setKind(type(p135) == "table" and p135.scope == v147 and "primary" or "secondary")
		end
		if v_u_5 then
			local v149 = type(p135) ~= "table" and {} or p135
			local v150 = v_u_5
			local v151 = v149.on == true and 1 or 0
			local v152 = v149.rawOn == true and 1 or 0
			local v153 = v149.scope or "?"
			local v154 = tostring(v153)
			local v155 = v149.flag == false and 0 or 1
			local v156 = v149.v or "?"
			v150:SetAttribute("FilmMailSw", ("on=%d|raw=%d|scope=%s|flag=%d|v=%s"):format(v151, v152, v154, v155, (tostring(v156))))
		end
	end
	v_u_61(nil)
	if v_u_2:IsStudio() and v_u_5 then
		local v_u_185 = v_u_5:GetAttributeChangedSignal("FilmMailCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_125, (ref) v_u_124, (copy) p_u_16, (ref) v_u_3, (ref) v_u_57, (copy) v_u_21, (ref) v_u_26, (ref) v_u_123, (ref) v_u_61, (copy) v_u_60, (copy) v_u_19
			local v157 = v_u_5:GetAttribute("FilmMailCmd")
			if type(v157) == "string" and v157 ~= "" then
				v_u_5:SetAttribute("FilmMailCmd", nil)
				local v158, v159 = string.match(v157, "^(%a+)%s*(%S*)$")
				if v158 == "toggle" then
					local v160 = v_u_125
					local v161
					if type(v160) == "table" then
						v161 = v_u_125.rawOn == true
					else
						v161 = false
					end
					local v162 = {
						["cmd"] = "set",
						["on"] = nil,
						["on"] = not v161
					}
					if not v_u_124 then
						local v163 = p_u_16
						if type(v163) == "function" then
							v_u_124 = true
							v_u_3.setText(v_u_57, "Working ...")
							v_u_57.TextColor3 = v_u_21.text2
							local v_u_164 = nil
							p_u_16("server.mail", v162, function(p165) -- name: done
								-- upvalues: (ref) v_u_124, (ref) v_u_26, (ref) v_u_123, (ref) v_u_125, (copy) v_u_164, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
								v_u_124 = false
								if v_u_26 then
									v_u_123 = os.clock()
									if type(p165) == "table" then
										local v166 = p165.data
										if type(v166) == "table" then
											v_u_125 = p165.data
										end
										if not v_u_164 then
											local v167 = p165.msg or (p165.ok and "Done." or "Refused.")
											local v168 = tostring(v167)
											local v169 = p165.ok ~= true
											v_u_3.setText(v_u_57, v168)
											local v170 = v_u_57
											local v171
											if v169 then
												v171 = v_u_21.danger
											else
												v171 = v_u_21.text2
											end
											v170.TextColor3 = v171
										end
									elseif not v_u_164 then
										v_u_3.setText(v_u_57, "The server did not answer.")
										v_u_57.TextColor3 = v_u_21.danger
									end
									v_u_61(v_u_125)
								end
							end)
						end
					end
				else
					if v158 == "scope" and v_u_60[v159] then
						v_u_60[v159].press()
						return
					end
					if v158 == "refresh" then
						local v172 = {
							["cmd"] = "status"
						}
						if not v_u_124 then
							local v173 = p_u_16
							if type(v173) ~= "function" then
								return
							end
							v_u_124 = true
							local v_u_174 = true
							local function v182(p175) -- name: done
								-- upvalues: (ref) v_u_124, (ref) v_u_26, (ref) v_u_123, (ref) v_u_125, (copy) v_u_174, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
								v_u_124 = false
								if v_u_26 then
									v_u_123 = os.clock()
									if type(p175) == "table" then
										local v176 = p175.data
										if type(v176) == "table" then
											v_u_125 = p175.data
										end
										if not v_u_174 then
											local v177 = p175.msg or (p175.ok and "Done." or "Refused.")
											local v178 = tostring(v177)
											local v179 = p175.ok ~= true
											v_u_3.setText(v_u_57, v178)
											local v180 = v_u_57
											local v181
											if v179 then
												v181 = v_u_21.danger
											else
												v181 = v_u_21.text2
											end
											v180.TextColor3 = v181
										end
									elseif not v_u_174 then
										v_u_3.setText(v_u_57, "The server did not answer.")
										v_u_57.TextColor3 = v_u_21.danger
									end
									v_u_61(v_u_125)
								end
							end
							local v183 = v_u_19.sendQuiet
							local v184
							if type(v183) == "function" then
								v184 = v_u_19.sendQuiet
							else
								v184 = p_u_16
							end
							v184("server.mail", v172, v182)
						end
					end
				end
			end
		end)
		if v_u_24 then
			v_u_24.Destroying:Connect(function()
				-- upvalues: (copy) v_u_185
				v_u_185:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_26, (copy) v_u_24, (copy) p_u_15, (ref) v_u_124, (ref) v_u_123, (copy) p_u_16, (ref) v_u_125, (ref) v_u_3, (ref) v_u_57, (copy) v_u_21, (ref) v_u_61, (copy) v_u_19
		local v186 = false
		while v_u_26 do
			local v187 = v_u_24 == nil or v_u_24.Enabled
			if v187 then
				v187 = p_u_15.Visible
			end
			if v187 and (not v_u_124 and (not v186 or os.clock() - v_u_123 >= 5)) then
				v_u_123 = os.clock()
				local v188 = {
					["cmd"] = "status"
				}
				if not v_u_124 then
					local v189 = p_u_16
					if type(v189) == "function" then
						v_u_124 = true
						local v_u_190 = true
						local function v198(p191) -- name: done
							-- upvalues: (ref) v_u_124, (ref) v_u_26, (ref) v_u_123, (ref) v_u_125, (copy) v_u_190, (ref) v_u_3, (ref) v_u_57, (ref) v_u_21, (ref) v_u_61
							v_u_124 = false
							if v_u_26 then
								v_u_123 = os.clock()
								if type(p191) == "table" then
									local v192 = p191.data
									if type(v192) == "table" then
										v_u_125 = p191.data
									end
									if not v_u_190 then
										local v193 = p191.msg or (p191.ok and "Done." or "Refused.")
										local v194 = tostring(v193)
										local v195 = p191.ok ~= true
										v_u_3.setText(v_u_57, v194)
										local v196 = v_u_57
										local v197
										if v195 then
											v197 = v_u_21.danger
										else
											v197 = v_u_21.text2
										end
										v196.TextColor3 = v197
									end
								elseif not v_u_190 then
									v_u_3.setText(v_u_57, "The server did not answer.")
									v_u_57.TextColor3 = v_u_21.danger
								end
								v_u_61(v_u_125)
							end
						end
						local v199 = v_u_19.sendQuiet
						local v200
						if type(v199) == "function" then
							v200 = v_u_19.sendQuiet
						else
							v200 = p_u_16
						end
						v200("server.mail", v188, v198)
					end
				end
			end
			task.wait(0.5)
			v186 = v187
		end
	end)
	return {
		["refresh"] = v75,
		["paint"] = function(p201) -- name: paint
			-- upvalues: (ref) v_u_125, (ref) v_u_61
			v_u_125 = p201
			v_u_61(p201)
		end
	}
end
return v_u_4