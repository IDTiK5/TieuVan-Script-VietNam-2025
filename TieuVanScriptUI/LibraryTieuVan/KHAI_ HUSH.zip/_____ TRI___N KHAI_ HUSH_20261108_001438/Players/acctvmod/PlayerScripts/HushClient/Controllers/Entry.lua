-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Entry

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = {
	["name"] = "Entry",
	["order"] = 21
}
local v_u_4 = game:GetService("Players").LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = -1000000000
local v_u_11 = 0
local v_u_12 = 0
local v_u_13 = {
	["ready"] = 0,
	["plans"] = 0,
	["played"] = 0,
	["ignored"] = 0,
	["skips"] = 0,
	["stops"] = 0,
	["resent"] = 0,
	["last"] = ""
}
local v_u_14 = nil
local v_u_15 = -1000000000
local v_u_16 = 0
local function v_u_21(p17, p18) -- name: onSceneEnd
	-- upvalues: (copy) v_u_13, (ref) v_u_7
	v_u_13.last = "end " .. p17 .. " " .. p18
	if p17 == "done" or p17 == "server" then
		return
	elseif p18 ~= "preview:local" then
		local v19 = v_u_13
		v19.skips = v19.skips + 1
		local v20 = v_u_7.fire
		pcall(v20, "entry.skip", {
			["id"] = p18
		})
	end
end
local function v_u_35(p22) -- name: onPlan
	-- upvalues: (copy) v_u_13, (ref) v_u_15, (ref) v_u_6, (copy) v_u_9, (ref) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_21
	local v23 = v_u_13
	v23.plans = v23.plans + 1
	v_u_15 = os.clock()
	local v24, v25 = v_u_6.decode(p22)
	if v24 then
		if v_u_9[v24.id] then
			local v26 = v_u_13
			v26.ignored = v26.ignored + 1
			v_u_13.last = "plan twice " .. v24.id
			return
		else
			v_u_9[v24.id] = true
			if v_u_8.active() then
				local v27 = v_u_13
				v27.ignored = v27.ignored + 1
				v_u_13.last = "busy " .. v24.id
				return
			else
				local v28 = v24.test == true
				for _, v29 in v24.m do
					if v29.u ~= v_u_4.UserId then
						continue
					end
					v28 = true
				end
				if v28 then
					local v30 = v24.test == true and "full" or v_u_6.normMode(v_u_4:GetAttribute("EntryMode"))
					local v31 = v_u_6.joinMode(v24, v_u_2.now(), v30)
					if v31.action == "off" or v31.action == "plain" then
						v_u_13.last = "no film (" .. v31.action .. ") " .. v24.id
					elseif v_u_8.start(v24, {
						["mode"] = v30,
						["offset"] = v31.offset,
						["onEnd"] = v_u_21
					}) then
						local v32 = v_u_13
						v32.played = v32.played + 1
						v_u_13.last = "playing " .. v24.id .. " " .. v24.k
					end
				else
					local v33 = v_u_13
					v33.ignored = v33.ignored + 1
					v_u_13.last = "not in the plan " .. v24.id
					return
				end
			end
		end
	else
		local v34 = v_u_13
		v34.ignored = v34.ignored + 1
		v_u_13.last = "plan refused: " .. tostring(v25)
		return
	end
end
local function v_u_39(p36) -- name: onStop
	-- upvalues: (copy) v_u_13, (ref) v_u_8
	local v37 = v_u_13
	v37.stops = v37.stops + 1
	if type(p36) == "table" then
		local v38 = p36.id
		if type(v38) == "string" then
			if v_u_8.activeId() == v38 then
				v_u_8.stop("server")
			elseif v_u_8.covered() then
				v_u_8.cover(false)
			end
		else
			return
		end
	else
		return
	end
end
function v3.init(p_u_40) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_35, (copy) v_u_39, (copy) v_u_4, (ref) v_u_11, (copy) v_u_13, (ref) v_u_10
	v_u_5 = p_u_40
	v_u_6 = p_u_40.shared.EntryRules
	v_u_7 = p_u_40.net
	local v41, v42 = pcall(function()
		-- upvalues: (copy) p_u_40
		return p_u_40.lib.EntryCine
	end)
	if v41 and v42 then
		v_u_8 = v42
		v_u_8.init(p_u_40)
		task.spawn(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_35
			v_u_7.listen("entry.plan", v_u_35)
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_39
			v_u_7.listen("entry.stop", v_u_39)
		end)
		p_u_40.on("place.ready", function(p43)
			-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_13, (ref) v_u_10, (ref) v_u_7
			if p43 == "Raid" then
				task.spawn(function()
					-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_13, (ref) v_u_10, (ref) v_u_7
					local v44 = os.clock()
					while os.clock() - v44 < v_u_6.TUNE.READY_LD_WAIT do
						local v45 = v_u_5 and v_u_5.controllers
						if v45 then
							v45 = v_u_5.controllers.Loading
						end
						local v46
						if v45 and not v45._broken then
							local v47 = v45.cardUp
							if type(v47) == "function" then
								local v48 = v45.cardUp
								local v49
								v46, v49 = pcall(v48)
								if v46 then
									v46 = v49 == true
								end
							else
								v46 = false
							end
						else
							v46 = false
						end
						if not (v_u_8.covered() or v_u_8.active()) then
							local v50 = v_u_4.Character
							local v51
							if v50 == nil then
								v51 = false
							else
								v51 = v50:GetAttribute("EntryHold") ~= nil
							end
							if v51 and v_u_4:GetAttribute("Place") == "Raid" then
								local v52 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
								if v52 then
									v52 = v52:GetAttribute("EntryOn") == false
								end
								if not v52 and v_u_6.normMode(v_u_4:GetAttribute("EntryMode")) ~= "off" then
									v_u_8.cover(true)
									v_u_11 = os.clock()
								end
							end
						end
						if v_u_8.covered() then
							if not v46 then
								break
							end
						elseif v_u_4:GetAttribute("LoadingVisible") ~= true and not v46 then
							break
						end
						task.wait(0.05)
					end
					if v_u_4:GetAttribute("Place") == "Raid" then
						local v53 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
						if v53 and v53:GetAttribute("EntryOn") == false then
							v_u_13.last = "scenes off (switch)"
							return
						elseif os.clock() - v_u_10 >= 4 then
							v_u_10 = os.clock()
							local v54 = v_u_6.normMode(v_u_4:GetAttribute("EntryMode"))
							local v55 = v_u_4.Character
							local v56
							if v55 == nil then
								v56 = false
							else
								v56 = v55:GetAttribute("EntryHold") ~= nil
							end
							if v56 and not v_u_8.active() then
								v_u_8.cover(true)
								v_u_11 = os.clock()
							end
							local v57 = v_u_13
							v57.ready = v57.ready + 1
							v_u_13.last = "ready " .. v54
							local v58 = v_u_7.fire
							pcall(v58, "entry.ready", {
								["m"] = v54
							})
						end
					else
						return
					end
				end)
			end
		end)
		p_u_40.command("entry.client", function()
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_13, (ref) v_u_8
			local v59 = string.format
			local v60 = "mode=%s ready=%d plans=%d played=%d ignored=%d skips=%d stops=%d held=%s cover=%s active=%s last=%s"
			local v61 = v_u_6.normMode(v_u_4:GetAttribute("EntryMode"))
			local v62 = v_u_13.ready
			local v63 = v_u_13.plans
			local v64 = v_u_13.played
			local v65 = v_u_13.ignored
			local v66 = v_u_13.skips
			local v67 = v_u_13.stops
			local v68 = v_u_4.Character
			local v69
			if v68 == nil then
				v69 = false
			else
				v69 = v68:GetAttribute("EntryHold") ~= nil
			end
			local v70 = tostring(v69)
			local v71 = v_u_8.covered
			local v72 = tostring(v71())
			local v73 = v_u_8.active
			return v59(v60, v61, v62, v63, v64, v65, v66, v67, v70, v72, tostring(v73()), v_u_13.last)
		end)
		p_u_40.command("entry.cover", function(p74)
			-- upvalues: (ref) v_u_8
			v_u_8.cover(p74[1] ~= "off")
			local v75 = p74[1] ~= "off"
			return "cover " .. tostring(v75)
		end)
	else
		warn("[Entry] EntryCine failed to load:", v42)
	end
end
function v3.step(p76) -- name: step
	-- upvalues: (ref) v_u_8, (ref) v_u_12, (copy) v_u_4, (ref) v_u_14, (copy) v_u_13, (ref) v_u_10, (ref) v_u_16, (ref) v_u_15, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11
	if not v_u_8 then
		return
	end
	v_u_8.tick(p76)
	v_u_12 = v_u_12 + p76
	if v_u_12 < 0.1 then
		return
	end
	v_u_12 = 0
	local v77 = v_u_4:GetAttribute("Place") == "Raid"
	local v78, v79
	if v77 and not v_u_8.active() then
		local v80 = v_u_4.Character
		local v81
		if v80 == nil then
			v81 = false
		else
			v81 = v80:GetAttribute("EntryHold") ~= nil
		end
		if v81 then
			local v82 = os.clock()
			local v83 = v_u_14 or v82
			v_u_14 = v83
			if v_u_13.ready > 0 and (v82 - v83 >= 3 and (v82 - v_u_10 >= 3 and (v_u_16 < 5 and v_u_15 < v83))) then
				v_u_16 = v_u_16 + 1
				local v84 = v_u_13
				v84.resent = v84.resent + 1
				v_u_10 = v82
				local v85 = v_u_16
				v_u_13.last = "ready again " .. tostring(v85)
				local v86 = v_u_7.fire
				local v87 = {
					["m"] = v_u_6.normMode(v_u_4:GetAttribute("EntryMode"))
				}
				pcall(v86, "entry.ready", v87)
			end
			if v_u_8.active() then
				if not v77 and v_u_8.activeId() ~= "preview:local" then
					v_u_8.stop("abort")
				end
				return
			end
			if not v_u_8.covered() then
				return
			end
		else
			v_u_14 = nil
			v78 = v_u_4.Character
			if v78 == nil then
				v79 = false
			else
				v79 = v78:GetAttribute("EntryHold") ~= nil
			end
			if not v79 then
				v_u_16 = 0
			end
			if v_u_8.active() then
				if not v77 and v_u_8.activeId() ~= "preview:local" then
					v_u_8.stop("abort")
				end
				return
			end
			if not v_u_8.covered() then
				return
			end
		end
	else
		v_u_14 = nil
		v78 = v_u_4.Character
		if v78 == nil then
			v79 = false
		else
			v79 = v78:GetAttribute("EntryHold") ~= nil
		end
		if not v79 then
			v_u_16 = 0
		end
		if v_u_8.active() then
			if not v77 and v_u_8.activeId() ~= "preview:local" then
				v_u_8.stop("abort")
			end
			return
		end
		if not v_u_8.covered() then
			return
		end
	end
	if v77 then
		local v88 = v_u_4.Character
		local v89
		if v88 == nil then
			v89 = false
		else
			v89 = v88:GetAttribute("EntryHold") ~= nil
		end
		if v89 and os.clock() - v_u_11 <= v_u_6.TUNE.ABS_MAX + 3 then
			return
		end
		v_u_8.cover(false)
	else
		v_u_8.cover(false)
	end
end
v3.onPlan = v_u_35
v3.onStop = v_u_39
v3.stats = v_u_13
v3.played = v_u_9
return v3