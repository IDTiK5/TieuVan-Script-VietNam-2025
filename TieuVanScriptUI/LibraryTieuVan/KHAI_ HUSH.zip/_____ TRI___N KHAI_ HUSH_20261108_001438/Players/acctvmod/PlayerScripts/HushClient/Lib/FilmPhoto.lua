-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPhoto

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("CollectionService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(script.Parent:WaitForChild("FilmPhotoPoses"))
local v_u_6 = require(script.Parent:WaitForChild("AnimRig"))
local v_u_7 = require(script.Parent:WaitForChild("FilmClean"))
local v_u_8 = require(script.Parent:WaitForChild("FilmPhotoHide"))
local v_u_9 = require(script.Parent:WaitForChild("MRProxyView"))
local v_u_10 = {}
local v_u_11 = v_u_1.LocalPlayer
local v_u_12 = nil
local v_u_13 = math.rad
local v_u_14 = Vector3.new
local v_u_15 = {
	["id"] = nil,
	["scene"] = nil,
	["anchor"] = nil,
	["ground"] = 0,
	["folder"] = nil,
	["actors"] = nil,
	["actorList"] = nil,
	["zombies"] = nil,
	["effects"] = 0,
	["emitters"] = nil,
	["lights"] = 0,
	["faces"] = 0,
	["plainHats"] = 0,
	["frozen"] = false,
	["forcedProps"] = nil,
	["camFx"] = nil,
	["vignette"] = nil,
	["visionOff"] = false,
	["flashOff"] = false,
	["hidOwn"] = false,
	["fxAnchor"] = false,
	["missing"] = nil,
	["token"] = 0,
	["doorParts"] = nil,
	["actors"] = {},
	["actorList"] = {},
	["zombies"] = {},
	["emitters"] = {},
	["forcedProps"] = {},
	["camFx"] = {},
	["missing"] = {},
	["doorParts"] = {}
}
local function v_u_22() -- name: publish
	-- upvalues: (copy) v_u_15, (copy) v_u_11
	if v_u_15.id then
		local v16 = 0
		for _ in v_u_15.actors do
			v16 = v16 + 1
		end
		local v17 = v_u_11
		local v18 = v_u_15.id
		local v19 = #v_u_15.zombies
		local v20 = v_u_15.effects
		local v21 = v_u_15.frozen
		v17:SetAttribute("FilmPhoto", ("%s|actors %d|zombies %d|effects %d|frozen %s"):format(v18, v16, v19, v20, (tostring(v21))))
	else
		v_u_11:SetAttribute("FilmPhoto", "")
	end
end
local function v_u_32(p23) -- name: fru
	if typeof(p23) == "Vector3" then
		return -p23.Z, p23.X, p23.Y
	elseif type(p23) == "table" then
		local v24 = p23.fwd or (p23.f or p23[1])
		local v25 = tonumber(v24)
		local v26 = (not v25 or v25 ~= v25) and 0 or v25
		local v27 = p23.right or (p23.r or p23[2])
		local v28 = tonumber(v27)
		local v29 = (not v28 or v28 ~= v28) and 0 or v28
		local v30 = p23.up or (p23.u or p23[3])
		local v31 = tonumber(v30)
		if v31 and v31 == v31 then
			return v26, v29, v31
		else
			return v26, v29, 0
		end
	else
		return 0, 0, 0
	end
end
local function v_u_40() -- name: rayParams
	-- upvalues: (copy) v_u_15, (copy) v_u_1
	local v33 = RaycastParams.new()
	v33.FilterType = Enum.RaycastFilterType.Exclude
	local v34 = {}
	if v_u_15.folder then
		local v35 = v_u_15.folder
		table.insert(v34, v35)
	end
	for _, v36 in v_u_1:GetPlayers() do
		if not v36.Character then
			continue
		end
		local v37 = v36.Character
		table.insert(v34, v37)
	end
	for _, v38 in { "HushLocal", "HushZombieRigs", "Zombies" } do
		local v39 = workspace:FindFirstChild(v38)
		if not v39 then
			continue
		end
		table.insert(v34, v39)
	end
	v33.FilterDescendantsInstances = v34
	v33.RespectCanCollide = true
	return v33
end
local function v_u_50(p41, p42) -- name: worldAt
	-- upvalues: (copy) v_u_15, (copy) v_u_32, (copy) v_u_14, (copy) v_u_40
	local v43 = v_u_15.anchor
	local v44, v45, v46 = v_u_32(p41)
	local v47 = v43.Position + v43.LookVector * v44 + v43.RightVector * v45
	local v48 = v_u_14(v47.X, v_u_15.ground, v47.Z)
	local v49 = p42 and workspace:Raycast(v48 + Vector3.new(0, 6, 0), Vector3.new(0, -20, 0), (v_u_40()))
	if v49 then
		return v_u_14(v47.X, v49.Position.Y + v46, v47.Z)
	else
		return v48 + v_u_14(0, v46, 0)
	end
end
local function v_u_74(p51, p52, p53) -- name: facingFrom
	-- upvalues: (copy) v_u_15, (copy) v_u_13, (copy) v_u_32, (copy) v_u_14
	local v54 = v_u_15.anchor
	local v55 = p52.yaw
	local v56 = tonumber(v55)
	local v57 = v_u_13((not v56 or v56 ~= v56) and 0 or v56)
	local v58 = nil
	if p53 == "camera" then
		local v59 = v_u_15.scene and v_u_15.scene.photo
		if v59 then
			v59 = v_u_15.scene.photo.camera
		end
		if v59 then
			local v60 = v59.at
			local v61 = v_u_15.anchor
			local v62, v63, v64 = v_u_32(v60)
			local v65 = v61.Position + v61.LookVector * v62 + v61.RightVector * v63
			v58 = v_u_14(v65.X, v_u_15.ground, v65.Z) + v_u_14(0, v64, 0)
		else
			v58 = nil
		end
	elseif type(p53) == "string" then
		local v66 = v_u_15.actors[p53]
		if v66 then
			v58 = v66.pos
		else
			v58 = nil
		end
	elseif type(p53) == "table" then
		local v67 = v_u_15.anchor
		local v68, v69, v70 = v_u_32(p53)
		local v71 = v67.Position + v67.LookVector * v68 + v67.RightVector * v69
		v58 = v_u_14(v71.X, v_u_15.ground, v71.Z) + v_u_14(0, v70, 0)
	end
	local v72 = v54.LookVector
	if v58 then
		local v73 = v_u_14(v58.X - p51.X, 0, v58.Z - p51.Z)
		if v73.Magnitude > 0.05 then
			v72 = v73.Unit
		end
	end
	return CFrame.lookAt(p51, p51 + v_u_14(v72.X, 0, v72.Z)) * CFrame.Angles(0, v57, 0)
end
local function v_u_77(p75, p76) -- name: col
	if typeof(p75) == "Color3" then
		return p75
	elseif type(p75) == "string" and string.match(p75, "^#?%x%x%x%x%x%x$") then
		return Color3.fromHex(p75)
	else
		return p76
	end
end
local function v_u_84(p78, p79) -- name: emitter
	-- upvalues: (copy) v_u_15
	local v_u_80 = Instance.new("ParticleEmitter")
	for v_u_81, v_u_82 in p79 do
		pcall(function()
			-- upvalues: (copy) v_u_80, (copy) v_u_81, (copy) v_u_82
			v_u_80[v_u_81] = v_u_82
		end)
	end
	v_u_80.Parent = p78
	local v83 = v_u_15.emitters
	table.insert(v83, v_u_80)
	return v_u_80
end
local function v_u_94(p85, p86, p87, p88, p89, p90, p91) -- name: light
	-- upvalues: (copy) v_u_15
	local v92
	if p85 == "spot" then
		v92 = Instance.new("SpotLight")
		v92.Angle = p91 or 45
		v92.Face = Enum.NormalId.Front
	else
		v92 = Instance.new("PointLight")
	end
	v92.Color = p87
	v92.Range = p88
	v92.Brightness = p89
	v92.Shadows = p90 == true
	v92.Parent = p86
	local v93 = v_u_15
	v93.lights = v93.lights + 1
	return v92
end
local function v_u_140(p95, p96) -- name: smokeAt
	-- upvalues: (copy) v_u_84, (copy) v_u_77
	local v97 = p96.color
	local v98 = Color3.fromRGB(150, 140, 150)
	if typeof(v97) == "Color3" then
		v98 = v97
	elseif type(v97) == "string" and string.match(v97, "^#?%x%x%x%x%x%x$") then
		v98 = Color3.fromHex(v97)
	end
	local v99 = v_u_84
	local v100 = {
		["Name"] = "Smoke",
		["Texture"] = "rbxasset://textures/particles/smoke_main.dds",
		["Color"] = nil,
		["Transparency"] = nil,
		["Size"] = nil,
		["Lifetime"] = nil,
		["Rate"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = nil,
		["RotSpeed"] = nil,
		["Rotation"] = nil,
		["LightEmission"] = nil,
		["LightInfluence"] = nil,
		["EmissionDirection"] = nil,
		["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v98), ColorSequenceKeypoint.new(1, v_u_77(p96.color2, v98:Lerp(Color3.fromRGB(60, 62, 70), 0.6))) })
	}
	local v101 = NumberSequence.new
	local v102 = {}
	local v103 = NumberSequenceKeypoint.new
	local v104 = p96.alpha
	local v105 = tonumber(v104)
	__set_list(v102, 1, {v103(0, (not v105 or v105 ~= v105) and 0.45 or v105), NumberSequenceKeypoint.new(0.6, 0.75), NumberSequenceKeypoint.new(1, 1)})
	v100.Transparency = v101(v102)
	local v106 = NumberSequence.new
	local v107 = {}
	local v108 = NumberSequenceKeypoint.new
	local v109 = p96.size0
	local v110 = tonumber(v109)
	local v111 = v108(0, (not v110 or v110 ~= v110) and 1 or v110)
	local v112 = NumberSequenceKeypoint.new
	local v113 = p96.size1
	local v114 = tonumber(v113)
	__set_list(v107, 1, {v111, v112(1, (not v114 or v114 ~= v114) and 6 or v114)})
	v100.Size = v106(v107)
	local v115 = NumberRange.new
	local v116 = p96.life0
	local v117 = tonumber(v116)
	local v118 = (not v117 or v117 ~= v117) and 3 or v117
	local v119 = p96.life1
	local v120 = tonumber(v119)
	v100.Lifetime = v115(v118, (not v120 or v120 ~= v120) and 5 or v120)
	local v121 = p96.rate
	local v122 = tonumber(v121)
	v100.Rate = (not v122 or v122 ~= v122) and 8 or v122
	local v123 = NumberRange.new
	local v124 = p96.speed0
	local v125 = tonumber(v124)
	local v126 = (not v125 or v125 ~= v125) and 1 or v125
	local v127 = p96.speed1
	local v128 = tonumber(v127)
	v100.Speed = v123(v126, (not v128 or v128 ~= v128) and 3 or v128)
	local v129 = Vector2.new
	local v130 = p96.spread
	local v131 = tonumber(v130)
	local v132 = (not v131 or v131 ~= v131) and 20 or v131
	local v133 = p96.spread
	local v134 = tonumber(v133)
	v100.SpreadAngle = v129(v132, (not v134 or v134 ~= v134) and 20 or v134)
	local v135 = p96.drift
	v100.Acceleration = typeof(v135) ~= "Vector3" and Vector3.new(0.8, 1.2, 0.4) or p96.drift
	v100.RotSpeed = NumberRange.new(-25, 25)
	v100.Rotation = NumberRange.new(0, 360)
	local v136 = p96.emission
	local v137 = tonumber(v136)
	v100.LightEmission = (not v137 or v137 ~= v137) and 0.15 or v137
	local v138 = p96.influence
	local v139 = tonumber(v138)
	v100.LightInfluence = (not v139 or v139 ~= v139) and 0.6 or v139
	v100.EmissionDirection = Enum.NormalId.Top
	v99(p95, v100)
end
local function v_u_158(p_u_141) -- name: weaponModel
	-- upvalues: (ref) v_u_12
	local v_u_142 = v_u_12.shared.WeaponDress
	local v143 = p_u_141.id or ""
	local v_u_144 = tostring(v143)
	local v145 = nil
	local v146 = v_u_142.build
	local v147 = p_u_141.mods
	local v148, v_u_149 = pcall(v146, v_u_144, v147)
	if not v148 or (typeof(v_u_149) ~= "Instance" or not v_u_149:IsA("Model")) then
		local function v151()
			-- upvalues: (ref) v_u_12, (copy) v_u_144
			local v150 = v_u_12.shared.Assets
			return v150.get("Weapon", v_u_144) or v150.get("Melee", v_u_144)
		end
		local v152
		v152, v_u_149 = pcall(v151)
		if v152 and (typeof(v_u_149) == "Instance" and v_u_149:IsA("Model")) then
			if v_u_142.stripOwn then
				local v153 = v_u_142.stripOwn
				pcall(v153, v_u_149)
			end
		else
			v_u_149 = v145
		end
	end
	if not v_u_149 then
		return nil
	end
	pcall(function()
		-- upvalues: (copy) v_u_142, (copy) v_u_149, (copy) p_u_141, (copy) v_u_144
		local v154 = v_u_142.applyScale
		local v155 = v_u_149
		local v156 = p_u_141.scale
		v154(v155, tonumber(v156) or v_u_142.scaleFor(v_u_144))
	end)
	for _, v157 in v_u_149:GetDescendants() do
		if v157:IsA("BasePart") then
			v157.Anchored = true
			v157.CanCollide = false
			v157.CanQuery = false
			v157.CanTouch = false
		else
			if not v157:IsA("LuaSourceContainer") then
				continue
			end
			v157:Destroy()
		end
	end
	return v_u_149
end
local function v_u_227(p159, p160, p161) -- name: flareModel
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_84, (copy) v_u_140
	local v162 = Instance.new("Model")
	v162.Name = "PhotoFlare"
	local v163 = p160 * 1
	local v164 = v_u_14(v163, p160 * 0.2, p160 * 0.2)
	local v165 = p159 * CFrame.new(0, 0, -v163 * 0.2) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v166 = Color3.fromRGB(176, 30, 26)
	local v167 = Enum.Material.Plastic
	local v168 = Instance.new("Part")
	v168.Name = "Stick"
	v168.Size = v164
	v168.CFrame = v165
	v168.Color = v166
	v168.Material = v167 or Enum.Material.SmoothPlastic
	v168.Anchored = true
	v168.CanCollide = false
	v168.CanQuery = false
	v168.CanTouch = false
	v168.CastShadow = false
	v168.Parent = v162 or v_u_15.folder
	local v169 = v_u_14(p160 * 0.12, p160 * 0.22, p160 * 0.22)
	local v170 = p159 * CFrame.new(0, 0, v163 * 0.3) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v171 = Color3.fromRGB(40, 38, 36)
	local v172 = Enum.Material.Plastic
	local v173 = Instance.new("Part")
	v173.Name = "Cap"
	v173.Size = v169
	v173.CFrame = v170
	v173.Color = v171
	v173.Material = v172 or Enum.Material.SmoothPlastic
	v173.Anchored = true
	v173.CanCollide = false
	v173.CanQuery = false
	v173.CanTouch = false
	v173.CastShadow = false
	v173.Parent = v162 or v_u_15.folder
	v173.Shape = Enum.PartType.Cylinder
	v168.Shape = Enum.PartType.Cylinder
	local v174 = p159 * CFrame.new(0, 0, -v163 * 0.72)
	local v175 = v_u_14(p160 * 0.26, p160 * 0.26, p160 * 0.26)
	local v176 = Color3.fromRGB(255, 120, 90)
	local v177 = Enum.Material.Neon
	local v178 = Instance.new("Part")
	v178.Name = "Burn"
	v178.Size = v175
	v178.CFrame = v174
	v178.Color = v176
	v178.Material = v177 or Enum.Material.SmoothPlastic
	v178.Anchored = true
	v178.CanCollide = false
	v178.CanQuery = false
	v178.CanTouch = false
	v178.CastShadow = false
	v178.Parent = v162 or v_u_15.folder
	v178.Shape = Enum.PartType.Ball
	local v179 = v_u_14(p160 * 0.7, p160 * 0.7, p160 * 0.7)
	local v180 = p161.color
	local v181 = Color3.fromRGB(255, 70, 50)
	if typeof(v180) == "Color3" then
		v181 = v180
	elseif type(v180) == "string" and string.match(v180, "^#?%x%x%x%x%x%x$") then
		v181 = Color3.fromHex(v180)
	end
	local v182 = Enum.Material.Neon
	local v183 = Instance.new("Part")
	v183.Name = "Halo"
	v183.Size = v179
	v183.CFrame = v174
	v183.Color = v181
	v183.Material = v182 or Enum.Material.SmoothPlastic
	v183.Anchored = true
	v183.CanCollide = false
	v183.CanQuery = false
	v183.CanTouch = false
	v183.CastShadow = false
	v183.Parent = v162 or v_u_15.folder
	v183.Shape = Enum.PartType.Ball
	v183.Transparency = 0.55
	local v184 = CFrame.new(v174.Position)
	local v185, v186, v187 = Color3.new(0, 0, 0)
	local v188 = Instance.new("Part")
	v188.Name = "FlareTip"
	v188.Size = Vector3.new(0.2, 0.2, 0.2)
	v188.CFrame = v184
	v188.Color = v185
	v188.Material = v186 or Enum.Material.SmoothPlastic
	v188.Anchored = true
	v188.CanCollide = false
	v188.CanQuery = false
	v188.CanTouch = false
	v188.CastShadow = false
	v188.Parent = v187 or v_u_15.folder
	v188.Transparency = 1
	v188.Parent = v162
	local v189 = p161.color
	local v190 = Color3.fromRGB(255, 46, 32)
	if typeof(v189) == "Color3" then
		v190 = v189
	elseif type(v189) == "string" and string.match(v189, "^#?%x%x%x%x%x%x$") then
		v190 = Color3.fromHex(v189)
	end
	local v191 = CFrame.new
	local v192 = v174.Position
	local v193 = p161.lightUp
	local v194 = tonumber(v193)
	local v195 = v191(v192 + v_u_14(0, ((not v194 or v194 ~= v194) and 1.1 or v194) * p160, 0))
	local v196, v197, v198 = Color3.new(0, 0, 0)
	local v199 = Instance.new("Part")
	v199.Name = "FlareGlow"
	v199.Size = Vector3.new(0.2, 0.2, 0.2)
	v199.CFrame = v195
	v199.Color = v196
	v199.Material = v197 or Enum.Material.SmoothPlastic
	v199.Anchored = true
	v199.CanCollide = false
	v199.CanQuery = false
	v199.CanTouch = false
	v199.CastShadow = false
	v199.Parent = v198 or v_u_15.folder
	v199.Transparency = 1
	v199.Parent = v162
	local v200 = p161.range
	local v201 = tonumber(v200)
	local v202 = (not v201 or v201 ~= v201) and 40 or v201
	local v203 = p161.brightness
	local v204 = tonumber(v203)
	local v205 = (not v204 or v204 ~= v204) and 2.2 or v204
	local v206 = p161.shadows ~= false
	local v207 = Instance.new("PointLight")
	v207.Color = v190
	v207.Range = v202
	v207.Brightness = v205
	v207.Shadows = v206 == true
	v207.Parent = v199
	local v208 = v_u_15
	v208.lights = v208.lights + 1
	local v209 = v_u_84
	local v210 = {
		["Name"] = "Fire",
		["Texture"] = "rbxasset://textures/particles/fire_main.dds",
		["Color"] = nil,
		["LightEmission"] = 1,
		["LightInfluence"] = 0,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rate"] = 90,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, 6, 0),
		["EmissionDirection"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(255, 190, 150), Color3.fromRGB(255, 60, 40))
	}
	local v211 = NumberSequence.new
	local v212 = {}
	local v213 = NumberSequenceKeypoint.new
	local v214 = p161.flame
	local v215 = tonumber(v214)
	__set_list(v212, 1, {v213(0, ((not v215 or v215 ~= v215) and 0.9 or v215) * p160), NumberSequenceKeypoint.new(1, p160 * 0.15)})
	v210.Size = v211(v212)
	v210.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v210.Lifetime = NumberRange.new(0.3, 0.55)
	v210.Speed = NumberRange.new(1.5, 3)
	v210.SpreadAngle = Vector2.new(18, 18)
	v210.EmissionDirection = Enum.NormalId.Top
	v209(v188, v210)
	local v216 = v_u_84
	local v217 = {
		["Name"] = "Sparks",
		["Texture"] = "rbxasset://textures/particles/fire_sparks_main.dds",
		["Color"] = nil,
		["LightEmission"] = 1,
		["LightInfluence"] = 0,
		["Orientation"] = nil,
		["Squash"] = nil,
		["Size"] = nil,
		["Lifetime"] = nil,
		["Rate"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, -18, 0),
		["EmissionDirection"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(255, 110, 70), Color3.fromRGB(255, 220, 170)),
		["Orientation"] = Enum.ParticleOrientation.VelocityParallel,
		["Squash"] = NumberSequence.new(1.8),
		["Size"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, p160 * 0.32), NumberSequenceKeypoint.new(1, 0) }),
		["Lifetime"] = NumberRange.new(0.4, 1.1)
	}
	local v218 = p161.sparks
	local v219 = tonumber(v218)
	v217.Rate = (not v219 or v219 ~= v219) and 120 or v219
	v217.Speed = NumberRange.new(5, 13)
	v217.SpreadAngle = Vector2.new(70, 70)
	v217.EmissionDirection = Enum.NormalId.Top
	v216(v188, v217)
	local v220 = v_u_140
	local v221 = {
		["color"] = nil,
		["color2"] = nil,
		["alpha"] = 0.45,
		["size0"] = nil,
		["size1"] = nil,
		["life0"] = 3.5,
		["life1"] = 6,
		["rate"] = nil,
		["speed0"] = 1.5,
		["speed1"] = 3.2,
		["spread"] = 14,
		["drift"] = nil,
		["emission"] = 0.12,
		["influence"] = 0.75,
		["color"] = Color3.fromRGB(230, 90, 80),
		["color2"] = Color3.fromRGB(70, 60, 72),
		["size0"] = p160 * 0.9
	}
	local v222 = p161.smokeSize
	local v223 = tonumber(v222)
	v221.size1 = (not v223 or v223 ~= v223) and 9 or v223
	local v224 = p161.smoke
	local v225 = tonumber(v224)
	v221.rate = (not v225 or v225 ~= v225) and 14 or v225
	local v226 = p161.drift
	v221.drift = typeof(v226) ~= "Vector3" and Vector3.new(1.2, 1.6, 0.6) or p161.drift
	v220(v188, v221)
	v162.Parent = v_u_15.folder
	return v162
end
local function v_u_286(p228, p229, p230) -- name: flashlightModel
	-- upvalues: (copy) v_u_14, (copy) v_u_15
	local v231 = Instance.new("Model")
	v231.Name = "PhotoFlashlight"
	local v232 = v_u_14(p229 * 0.72, p229 * 0.2, p229 * 0.2)
	local v233 = p228 * CFrame.new(0, 0, p229 * -0.15) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v234 = Color3.fromRGB(30, 31, 33)
	local v235 = Enum.Material.Metal
	local v236 = Instance.new("Part")
	v236.Name = "Body"
	v236.Size = v232
	v236.CFrame = v233
	v236.Color = v234
	v236.Material = v235 or Enum.Material.SmoothPlastic
	v236.Anchored = true
	v236.CanCollide = false
	v236.CanQuery = false
	v236.CanTouch = false
	v236.CastShadow = false
	v236.Parent = v231 or v_u_15.folder
	v236.Shape = Enum.PartType.Cylinder
	local v237 = p228 * CFrame.new(0, 0, p229 * -0.55)
	local v238 = v_u_14(p229 * 0.18, p229 * 0.3, p229 * 0.3)
	local v239 = v237 * CFrame.Angles(0, 1.5707963267948966, 0)
	local v240 = Color3.fromRGB(30, 31, 33)
	local v241 = Enum.Material.Metal
	local v242 = Instance.new("Part")
	v242.Name = "Head"
	v242.Size = v238
	v242.CFrame = v239
	v242.Color = v240
	v242.Material = v241 or Enum.Material.SmoothPlastic
	v242.Anchored = true
	v242.CanCollide = false
	v242.CanQuery = false
	v242.CanTouch = false
	v242.CastShadow = false
	v242.Parent = v231 or v_u_15.folder
	v242.Shape = Enum.PartType.Cylinder
	local v243 = v_u_14(p229 * 0.04, p229 * 0.26, p229 * 0.26)
	local v244 = v237 * CFrame.new(0, 0, p229 * -0.1) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v245 = Color3.fromRGB(255, 244, 222)
	local v246 = Enum.Material.Neon
	local v247 = Instance.new("Part")
	v247.Name = "Lens"
	v247.Size = v243
	v247.CFrame = v244
	v247.Color = v245
	v247.Material = v246 or Enum.Material.SmoothPlastic
	v247.Anchored = true
	v247.CanCollide = false
	v247.CanQuery = false
	v247.CanTouch = false
	v247.CastShadow = false
	v247.Parent = v231 or v_u_15.folder
	v247.Shape = Enum.PartType.Cylinder
	local v248 = v237 * CFrame.new(0, 0, p229 * -0.15)
	local v249, v250, v251 = Color3.new(0, 0, 0)
	local v252 = Instance.new("Part")
	v252.Name = "Beam"
	v252.Size = Vector3.new(0.2, 0.2, 0.2)
	v252.CFrame = v248
	v252.Color = v249
	v252.Material = v250 or Enum.Material.SmoothPlastic
	v252.Anchored = true
	v252.CanCollide = false
	v252.CanQuery = false
	v252.CanTouch = false
	v252.CastShadow = false
	v252.Parent = v251 or v_u_15.folder
	v252.Transparency = 1
	v252.Parent = v231
	local v253 = p230.color
	local v254 = Color3.fromRGB(255, 242, 218)
	if typeof(v253) == "Color3" then
		v254 = v253
	elseif type(v253) == "string" and string.match(v253, "^#?%x%x%x%x%x%x$") then
		v254 = Color3.fromHex(v253)
	end
	local v255 = p230.range
	local v256 = tonumber(v255)
	local v257 = (not v256 or v256 ~= v256) and 60 or v256
	local v258 = p230.brightness
	local v259 = tonumber(v258)
	local v260 = (not v259 or v259 ~= v259) and 3.5 or v259
	local v261 = p230.shadows ~= false
	local v262 = p230.angle
	local v263 = tonumber(v262)
	local v264 = (not v263 or v263 ~= v263) and 50 or v263
	local v265 = Instance.new("SpotLight")
	v265.Angle = v264 or 45
	v265.Face = Enum.NormalId.Front
	v265.Color = v254
	v265.Range = v257
	v265.Brightness = v260
	v265.Shadows = v261 == true
	v265.Parent = v252
	local v266 = v_u_15
	v266.lights = v266.lights + 1
	if p230.beam ~= false then
		local v267 = Instance.new("Attachment")
		v267.Parent = v252
		local v268 = Instance.new("Attachment")
		local v269 = p230.beamLength
		local v270 = tonumber(v269)
		v268.Position = v_u_14(0, 0, -((not v270 or v270 ~= v270) and 22 or v270))
		v268.Parent = v252
		local v271 = p230.beamAlpha
		local v272 = tonumber(v271)
		local v273 = (not v272 or v272 ~= v272) and 0.08 or v272
		local v274 = p230.beamWidth
		local v275 = tonumber(v274)
		local v276 = (not v275 or v275 ~= v275) and 9 or v275
		local v277 = {}
		local v278 = {
			["w0"] = p229 * 0.3,
			["w1"] = v276
		}
		local v279 = v273 + 0.2
		v278.t0 = math.min(1, v279)
		v278.t1 = v273
		__set_list(v277, 1, {v278})
		if p230.halo ~= false then
			local v280 = {
				["w0"] = nil,
				["w1"] = nil,
				["t0"] = 0.65,
				["t1"] = 0.5,
				["w0"] = p229 * 0.6,
				["w1"] = v276 * 1.6
			}
			table.insert(v277, v280)
		end
		for v281, v282 in v277 do
			local v283 = Instance.new("Beam")
			v283.Name = v281 == 1 and "Cone" or "Halo"
			v283.Attachment0 = v267
			v283.Attachment1 = v268
			v283.Color = ColorSequence.new(Color3.fromRGB(255, 240, 210))
			v283.LightEmission = 1
			v283.LightInfluence = 0
			v283.FaceCamera = true
			v283.Texture = "rbxasset://textures/particles/smoke_main.dds"
			v283.TextureMode = Enum.TextureMode.Stretch
			v283.TextureLength = 1
			v283.TextureSpeed = 0
			local v284 = v282.w0
			local v285 = v282.w1
			v283.Width0 = v284
			v283.Width1 = v285
			v283.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v282.t0), NumberSequenceKeypoint.new(0.15, v282.t1), NumberSequenceKeypoint.new(1, 1) })
			v283.Segments = 12
			v283.Parent = v252
		end
	end
	v231.Parent = v_u_15.folder
	return v231
end
local function v_u_332(p287, p288) -- name: muzzleFlash
	-- upvalues: (copy) v_u_15, (copy) v_u_13, (copy) v_u_84
	local v289 = nil
	for _, v290 in { "Muzzle", "MuzzleMount", "MuzzleEnd" } do
		local v291 = p287:FindFirstChild(v290, true)
		if not (v291 and v291:IsA("Attachment")) then
			continue
		end
		v289 = v291.WorldCFrame
	end
	local v292 = p287:GetPivot()
	if not v289 then
		local v293, v294 = p287:GetBoundingBox()
		local v295 = v292.LookVector
		local v296 = v293:VectorToObjectSpace(v295).Z
		local v297 = math.abs(v296) > 0.5 and v294.Z or v294.X
		v289 = CFrame.lookAt(v293.Position + v295 * v297 * 0.5, v293.Position + v295 * (v297 * 0.5 + 1))
	end
	local v298 = CFrame.lookAt(v289.Position, v289.Position + v292.LookVector)
	local v299 = p288.size
	local v300 = tonumber(v299)
	local v301 = (not v300 or v300 ~= v300) and 1 or v300
	local v302, v303, v304 = Color3.new(0, 0, 0)
	local v305 = Instance.new("Part")
	v305.Name = "MuzzleFlash"
	v305.Size = Vector3.new(0.2, 0.2, 0.2)
	v305.CFrame = v298
	v305.Color = v302
	v305.Material = v303 or Enum.Material.SmoothPlastic
	v305.Anchored = true
	v305.CanCollide = false
	v305.CanQuery = false
	v305.CanTouch = false
	v305.CastShadow = false
	v305.Parent = v304 or v_u_15.folder
	v305.Transparency = 1
	local v306 = Color3.fromRGB(255, 214, 140)
	local v307 = Vector3.new(0.32, 0.32, 0.32) * v301
	local v308 = v298 * CFrame.new(0, 0, v301 * -0.12)
	local v309 = Enum.Material.Neon
	local v310 = Instance.new("Part")
	v310.Name = "Core"
	v310.Size = v307
	v310.CFrame = v308
	v310.Color = v306
	v310.Material = v309 or Enum.Material.SmoothPlastic
	v310.Anchored = true
	v310.CanCollide = false
	v310.CanQuery = false
	v310.CanTouch = false
	v310.CastShadow = false
	v310.Parent = v_u_15.folder
	v310.Shape = Enum.PartType.Ball
	v310.Transparency = 0.1
	local v311 = Vector3.new(0.14, 0.14, 0.95) * v301
	local v312 = v298 * CFrame.new(0, 0, v301 * -0.55)
	local v313 = Color3.fromRGB(255, 196, 110)
	local v314 = Enum.Material.Neon
	local v315 = Instance.new("Part")
	v315.Name = "Tongue"
	v315.Size = v311
	v315.CFrame = v312
	v315.Color = v313
	v315.Material = v314 or Enum.Material.SmoothPlastic
	v315.Anchored = true
	v315.CanCollide = false
	v315.CanQuery = false
	v315.CanTouch = false
	v315.CastShadow = false
	v315.Parent = v_u_15.folder
	v315.Transparency = 0.2
	for v316 = 0, 3 do
		local v317 = v298 * CFrame.Angles(0, 0, (v_u_13(v316 * 90 + 45))) * CFrame.Angles(0.5585053606381855, 0, 0) * CFrame.new(0, 0, v301 * -0.32)
		local v318 = Vector3.new(0.06, 0.06, 0.55) * v301
		local v319 = Color3.fromRGB(255, 170, 80)
		local v320 = Enum.Material.Neon
		local v321 = Instance.new("Part")
		v321.Name = "Prong"
		v321.Size = v318
		v321.CFrame = v317
		v321.Color = v319
		v321.Material = v320 or Enum.Material.SmoothPlastic
		v321.Anchored = true
		v321.CanCollide = false
		v321.CanQuery = false
		v321.CanTouch = false
		v321.CastShadow = false
		v321.Parent = v_u_15.folder
		v321.Transparency = 0.3
	end
	local v322 = Color3.fromRGB(255, 180, 100)
	local v323 = p288.range
	local v324 = tonumber(v323)
	local v325 = (not v324 or v324 ~= v324) and 16 or v324
	local v326 = p288.brightness
	local v327 = tonumber(v326)
	local v328 = (not v327 or v327 ~= v327) and 3 or v327
	local v329 = Instance.new("PointLight")
	v329.Color = v322
	v329.Range = v325
	v329.Brightness = v328
	v329.Shadows = true
	v329.Parent = v305
	local v330 = v_u_15
	v330.lights = v330.lights + 1
	v_u_84(v305, {
		["Name"] = "MuzzleSmoke",
		["Texture"] = "rbxasset://textures/particles/smoke_main.dds",
		["Color"] = nil,
		["Transparency"] = nil,
		["Size"] = nil,
		["Lifetime"] = nil,
		["Rate"] = 12,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["EmissionDirection"] = nil,
		["LightInfluence"] = 0.7,
		["Color"] = ColorSequence.new(Color3.fromRGB(200, 196, 190)),
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(1, 1) }),
		["Size"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.4), NumberSequenceKeypoint.new(1, 2.4) }),
		["Lifetime"] = NumberRange.new(0.8, 1.4),
		["Speed"] = NumberRange.new(1, 3),
		["SpreadAngle"] = Vector2.new(25, 25),
		["EmissionDirection"] = Enum.NormalId.Front
	})
	local v331 = v_u_15
	v331.effects = v331.effects + 1
end
local v_u_333 = {
	["angry"] = {
		["LeftBrowLowerer"] = 1,
		["RightBrowLowerer"] = 1,
		["Corrugator"] = 0.9,
		["LeftNoseWrinkler"] = 0.55,
		["RightNoseWrinkler"] = 0.55,
		["LeftUpperLipRaiser"] = 0.45,
		["RightUpperLipRaiser"] = 0.45,
		["LeftLipStretcher"] = 0.55,
		["RightLipStretcher"] = 0.55,
		["LeftLidTightener"] = 0.7,
		["RightLidTightener"] = 0.7,
		["JawDrop"] = 0.22,
		["LeftCheekRaiser"] = 0.3,
		["RightCheekRaiser"] = 0.3
	},
	["scream"] = {
		["LeftBrowLowerer"] = 0.7,
		["RightBrowLowerer"] = 0.7,
		["Corrugator"] = 0.6,
		["JawDrop"] = 0.85,
		["LeftLipStretcher"] = 0.7,
		["RightLipStretcher"] = 0.7,
		["LeftUpperLipRaiser"] = 0.6,
		["RightUpperLipRaiser"] = 0.6,
		["LeftNoseWrinkler"] = 0.4,
		["RightNoseWrinkler"] = 0.4
	},
	["fear"] = {
		["LeftInnerBrowRaiser"] = 1,
		["RightInnerBrowRaiser"] = 1,
		["LeftOuterBrowRaiser"] = 0.6,
		["RightOuterBrowRaiser"] = 0.6,
		["LeftUpperLidRaiser"] = 0.8,
		["RightUpperLidRaiser"] = 0.8,
		["JawDrop"] = 0.35,
		["LeftLipStretcher"] = 0.6,
		["RightLipStretcher"] = 0.6
	},
	["focus"] = {
		["LeftBrowLowerer"] = 0.55,
		["RightBrowLowerer"] = 0.55,
		["LeftLidTightener"] = 0.5,
		["RightLidTightener"] = 0.5,
		["LipPresser"] = 0.5
	},
	["shush"] = {
		["LeftBrowLowerer"] = 0.35,
		["RightBrowLowerer"] = 0.35,
		["LipPucker"] = 0.8,
		["Funneler"] = 0.4,
		["LeftLidTightener"] = 0.3,
		["RightLidTightener"] = 0.3
	}
}
local function v_u_340(p334, p335) -- name: applyFace
	-- upvalues: (copy) v_u_333
	if type(p335) ~= "string" then
		return false
	end
	local v_u_336 = p334:FindFirstChild("Head")
	if v_u_336 then
		v_u_336 = v_u_336:FindFirstChildWhichIsA("FaceControls", true)
	end
	local v337 = v_u_333[p335]
	if not (v_u_336 and v337) then
		return false
	end
	for v_u_338, v_u_339 in v337 do
		pcall(function()
			-- upvalues: (copy) v_u_336, (copy) v_u_338, (copy) v_u_339
			v_u_336[v_u_338] = v_u_339
		end)
	end
	return true
end
local function v_u_354(p341) -- name: avatarTemplate
	-- upvalues: (copy) v_u_4, (copy) v_u_11, (ref) v_u_12
	local v342 = p341.rig or "hero"
	if tostring(v342) == "hero" then
		local v_u_343 = v_u_4:FindFirstChild("HushAvatars")
		if v_u_343 then
			local v344 = v_u_11.UserId
			v_u_343 = v_u_343:FindFirstChild((tostring(v344)))
		end
		if v_u_343 and v_u_343:IsA("Model") then
			local function v345()
				-- upvalues: (ref) v_u_12, (copy) v_u_343
				return v_u_12.shared.AvatarTemplate.ready(v_u_343)
			end
			local v346, v347 = pcall(v345)
			if v346 and v347 ~= true then
				return nil
			else
				return v_u_343
			end
		else
			return nil
		end
	else
		local v348 = p341.extra
		local v349 = tonumber(v348)
		local v350 = (not v349 or v349 ~= v349) and 1 or v349
		local v351 = math.floor(v350)
		local v352 = math.clamp(v351, 1, 8)
		local v353 = v_u_4:FindFirstChild("HushFilmRigs") or v_u_4:WaitForChild("HushFilmRigs", 6)
		if v353 then
			v353 = v353:FindFirstChild("Extra_" .. v352) or v353:WaitForChild("Extra_" .. v352, 6)
		end
		if v353 and v353:IsA("Model") then
			return v353
		else
			return nil
		end
	end
end
local v_u_355 = Color3.fromRGB(96, 100, 74)
local function v_u_364(p356, p357) -- name: plainHats
	local v358 = 0
	for _, v_u_359 in p356:GetDescendants() do
		if not v_u_359:IsA("Accessory") then
			continue
		end
		local v_u_360 = v_u_359:FindFirstChild("Handle")
		local v_u_361 = false
		local function v362()
			-- upvalues: (ref) v_u_361, (copy) v_u_359
			v_u_361 = v_u_359.AccessoryType == Enum.AccessoryType.Hat
		end
		pcall(v362)
		v_u_361 = v_u_360 and v_u_360:FindFirstChild("HatAttachment") and true or v_u_361
		if not (v_u_361 and (v_u_360 and v_u_360:IsA("BasePart"))) then
			continue
		end
		for _, v363 in v_u_360:GetDescendants() do
			if v363:IsA("SurfaceAppearance") or v363:IsA("Decal") then
				v363:Destroy()
			else
				if not v363:IsA("SpecialMesh") then
					continue
				end
				v363.TextureId = ""
				v363.VertexColor = Vector3.new(1, 1, 1)
			end
		end
		if v_u_360:IsA("MeshPart") then
			pcall(function()
				-- upvalues: (copy) v_u_360
				v_u_360.TextureID = ""
			end)
		end
		v_u_360.Color = p357
		v_u_360.Material = Enum.Material.Fabric
		v358 = v358 + 1
	end
	return v358
end
local function v_u_442(p365) -- name: buildActor
	-- upvalues: (copy) v_u_15, (copy) v_u_354, (copy) v_u_364, (copy) v_u_355, (copy) v_u_6, (copy) v_u_50, (copy) v_u_74, (copy) v_u_14, (copy) v_u_5, (copy) v_u_340, (copy) v_u_13, (copy) v_u_158, (copy) v_u_332, (copy) v_u_227, (copy) v_u_286
	local v366 = p365.id or "actor" .. #v_u_15.actorList + 1
	local v367 = tostring(v366)
	local v368 = v_u_354(p365)
	if v368 then
		local v369 = v368:Clone()
		v369.Name = "Actor_" .. v367
		local v370 = v_u_15.scene
		if v370 then
			v370 = v_u_15.scene.photo
		end
		local v371
		if p365.plainHat == nil then
			local v372 = p365.rig or "hero"
			if tostring(v372) == "hero" and type(v370) == "table" then
				v371 = v370.heroPlainHat
			else
				v371 = nil
			end
		else
			v371 = p365.plainHat
		end
		if v371 == true or typeof(v371) == "Color3" then
			local v373 = v_u_15
			local v374 = v373.plainHats
			local v375 = v_u_364
			if typeof(v371) ~= "Color3" then
				v371 = v_u_355
			end
			v373.plainHats = v374 + v375(v369, v371)
		end
		for _, v_u_376 in v369:GetDescendants() do
			if v_u_376:IsA("LuaSourceContainer") or v_u_376:IsA("Animator") then
				v_u_376:Destroy()
			else
				if not v_u_376:IsA("Humanoid") then
					continue
				end
				v_u_376.AutomaticScalingEnabled = false
				v_u_376.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				v_u_376.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
				v_u_376.BreakJointsOnDeath = false
				v_u_376.RequiresNeck = false
				pcall(function()
					-- upvalues: (copy) v_u_376
					v_u_376.EvaluateStateMachine = false
				end)
			end
		end
		local v377 = v369:FindFirstChild("HumanoidRootPart")
		if v377 then
			for _, v378 in v369:GetDescendants() do
				if not v378:IsA("BasePart") then
					continue
				end
				v378.CanCollide = false
				v378.CanQuery = false
				v378.CanTouch = false
				v378.Anchored = v378 == v377
			end
			v377.Transparency = 1
			local v379 = v_u_6.new(v369)
			if v379 then
				local v380 = v369:FindFirstChildOfClass("Humanoid")
				local v381 = not v380 and 2 or v380.HipHeight
				local v382 = ((v379.bone.LeftHip or 1.35) + (v379.bone.LeftKnee or 1.25)) / 2.6
				local v383 = v_u_50(p365.at, true)
				local v384 = v_u_74(v383, p365, p365.face) + v_u_14(0, v381 + v377.Size.Y / 2, 0)
				v369:PivotTo(v384 * v377.CFrame:Inverse() * v369:GetPivot())
				v369.Parent = v_u_15.folder
				local v385 = v_u_5.actorPose
				local v386 = p365.pose or "idle"
				local v387, v388 = pcall(v385, v379, v386, v382)
				if not v387 then
					local v389 = v_u_15.missing
					local v390 = p365.pose
					local v391 = "pose " .. tostring(v390) .. ": " .. tostring(v388)
					table.insert(v389, v391)
					v388 = {}
				end
				if p365.expression and v_u_340(v369, p365.expression) then
					local v392 = v_u_15
					v392.faces = v392.faces + 1
				end
				local v393 = {
					["id"] = v367,
					["model"] = v369,
					["rig"] = v379,
					["root"] = v384,
					["s"] = v382,
					["info"] = v388,
					["pos"] = v383,
					["items"] = {}
				}
				v_u_15.actors[v367] = v393
				local v394 = v_u_15.actorList
				table.insert(v394, v393)
				for _, v395 in p365.items or {} do
					local v396 = v395.hand or "Right"
					local v397 = tostring(v396)
					local v398
					if v397 == "grip" and v388.grip then
						v398 = v384 * v388.grip
					else
						local v399 = string.lower(v397) == "left" and "Left" or "Right"
						v398 = v384 * v_u_5.handFrame(v379, v399)
					end
					local v400 = v395.rot
					if type(v400) == "table" then
						local v401 = CFrame.fromEulerAnglesYXZ
						local v402 = v395.rot[1]
						local v403 = tonumber(v402)
						local v404 = v_u_13((not v403 or v403 ~= v403) and 0 or v403)
						local v405 = v395.rot[2]
						local v406 = tonumber(v405)
						local v407 = v_u_13((not v406 or v406 ~= v406) and 0 or v406)
						local v408 = v395.rot[3]
						local v409 = tonumber(v408)
						v398 = v398 * v401(v404, v407, (v_u_13((not v409 or v409 ~= v409) and 0 or v409)))
					end
					local v410 = v395.offset
					if type(v410) == "table" then
						local v411 = CFrame.new
						local v412 = v395.offset[1]
						local v413 = tonumber(v412)
						local v414 = (not v413 or v413 ~= v413) and 0 or v413
						local v415 = v395.offset[2]
						local v416 = tonumber(v415)
						local v417 = (not v416 or v416 ~= v416) and 0 or v416
						local v418 = v395.offset[3]
						local v419 = tonumber(v418)
						v398 = v398 * v411(v414, v417, (not v419 or v419 ~= v419) and 0 or v419)
					end
					local v420 = v395.kind or "weapon"
					local v421 = tostring(v420)
					if v421 == "weapon" then
						local v422 = v_u_158(v395)
						if v422 then
							v422:PivotTo(v398)
							v422.Parent = v369
							local v423 = v393.items
							table.insert(v423, v422)
							if not v395.muzzle then
								continue
							end
							local v424 = v_u_332
							local v425 = v395.muzzle
							v424(v422, type(v425) ~= "table" and {} or v395.muzzle)
						else
							local v426 = v_u_15.missing
							local v427 = v395.id
							local v428 = "weapon " .. tostring(v427)
							table.insert(v426, v428)
						end
					elseif v421 == "flare" then
						local v429 = v393.items
						local v430 = v_u_227(v398, v382, v395)
						table.insert(v429, v430)
						local v431 = v_u_15
						v431.effects = v431.effects + 1
					else
						if v421 ~= "flashlight" then
							continue
						end
						local v432 = v393.items
						local v433 = v_u_286(v398, v382, v395)
						table.insert(v432, v433)
						local v434 = v_u_15
						v434.effects = v434.effects + 1
					end
				end
			else
				v369:Destroy()
				local v435 = v_u_15.missing
				local v436 = "actor " .. v367 .. " (joints)"
				table.insert(v435, v436)
			end
		else
			v369:Destroy()
			local v437 = v_u_15.missing
			local v438 = "actor " .. v367 .. " (rig without root)"
			table.insert(v437, v438)
			return
		end
	else
		local v439 = v_u_15.missing
		local v440 = p365.rig or "hero"
		local v441 = "actor " .. v367 .. " (no " .. tostring(v440) .. " rig)"
		table.insert(v439, v441)
		return
	end
end
local function v_u_449(p443, p444, p445) -- name: zombieModelName
	-- upvalues: (ref) v_u_12
	if type(p445) == "string" then
		return p445
	else
		local v446 = v_u_12.shared.ZombieTypes
		local v447 = v446.get
		if v447 then
			v447 = v446.get(p443)
		end
		if v447 then
			p443 = v447.model or p443
		end
		if p443 == "walker" then
			local v448 = v446.WALKER_LOOKS or { "walker" }
			if type(p445) ~= "number" then
				p445 = p444
			end
			return v448[(p445 - 1) % #v448 + 1]
		elseif p445 == 2 then
			return p443 .. "_2"
		else
			return p443
		end
	end
end
local function v_u_477(p450, p451) -- name: addEyes
	-- upvalues: (copy) v_u_14, (copy) v_u_15
	if p451 == false then
		return
	else
		local v452 = type(p451) ~= "table" and {} or p451
		local v453 = p450:FindFirstChild("Head")
		if v453 then
			local v454 = v453.Size
			local v455 = v452.spread
			local v456 = tonumber(v455)
			local v457 = ((not v456 or v456 ~= v456) and 0.2 or v456) * v454.X
			local v458 = v452.height
			local v459 = tonumber(v458)
			local v460 = ((not v459 or v459 ~= v459) and 0.1 or v459) * v454.Y
			local v461 = v452.size
			local v462 = tonumber(v461)
			local v463 = ((not v462 or v462 ~= v462) and 0.16 or v462) * v454.X
			local v464 = v452.color
			local v465 = Color3.fromRGB(255, 206, 110)
			if typeof(v464) == "Color3" then
				v465 = v464
			elseif type(v464) == "string" and string.match(v464, "^#?%x%x%x%x%x%x$") then
				v465 = Color3.fromHex(v464)
			end
			for _, v466 in { -1, 1 } do
				local v467 = Instance.new("Part")
				v467.Name = "PhotoEye"
				v467.Shape = Enum.PartType.Ball
				v467.Size = v_u_14(v463, v463 * 0.7, v463 * 0.5)
				v467.Color = v465
				v467.Material = Enum.Material.Neon
				v467.CanCollide = false
				v467.CanQuery = false
				v467.CanTouch = false
				v467.CastShadow = false
				v467.Massless = true
				v467.Anchored = false
				v467.CFrame = v453.CFrame * CFrame.new(v466 * v457, v460, -v454.Z * 0.5 + v463 * 0.15)
				local v468 = Instance.new("Weld")
				v468.Part0 = v453
				v468.Part1 = v467
				v468.C0 = CFrame.new(v466 * v457, v460, -v454.Z * 0.5 + v463 * 0.15)
				v468.Parent = v467
				v467.Parent = p450
			end
			local v469 = v452.light
			local v470 = tonumber(v469)
			if ((not v470 or v470 ~= v470) and 0 or v470) > 0 then
				local v471 = Instance.new("PointLight")
				v471.Color = v465
				local v472 = v452.lightRange
				local v473 = tonumber(v472)
				v471.Range = (not v473 or v473 ~= v473) and 4 or v473
				local v474 = v452.light
				local v475 = tonumber(v474)
				v471.Brightness = (not v475 or v475 ~= v475) and 0.8 or v475
				v471.Parent = v453
				local v476 = v_u_15
				v476.lights = v476.lights + 1
			end
		end
	end
end
local function v_u_507(p478, p479, p480) -- name: buildZombie
	-- upvalues: (ref) v_u_12, (copy) v_u_15, (copy) v_u_449, (copy) v_u_50, (copy) v_u_74, (copy) v_u_5, (copy) v_u_477
	local v481 = v_u_12 and (v_u_12.controllers and v_u_12.controllers.ZombieRender) or nil
	if v481 and v481.previewRig then
		local v482 = p478.type or "walker"
		local v483 = tostring(v482)
		local v484 = v_u_449(v483, p479, p478.look)
		local v485 = v481.previewRig
		local v486, v487 = pcall(v485, v484)
		if not (v486 and v487) and v484 ~= v483 then
			local v488 = v481.previewRig
			v486, v487 = pcall(v488, v483)
		end
		if v486 and type(v487) == "table" then
			local v_u_489 = v487.model
			local v490 = v487.root
			v_u_489.Name = "Zombie_" .. p479
			local v491 = v_u_74(v_u_50(p478.at, true), p478, p478.face or "hero")
			local v492 = p478.scale
			local v493 = tonumber(v492)
			local v_u_494 = (not v493 or v493 ~= v493) and 1 or v493
			if v_u_494 ~= 1 then
				pcall(function()
					-- upvalues: (copy) v_u_489, (copy) v_u_494
					v_u_489:ScaleTo(v_u_489:GetScale() * v_u_494)
				end)
			end
			local v495 = v487.rootHeight * v_u_494
			v_u_489:PivotTo(v491 * CFrame.new(0, v495, 0) * v490.CFrame:Inverse() * v_u_489:GetPivot())
			v_u_489.Parent = v_u_15.folder
			local v496 = v_u_5.zombiePose
			local v497 = {
				["pose"] = p478.pose or "idle",
				["phase"] = p478.phase,
				["style"] = p478.style,
				["seed"] = p478.seed or p479 * 0.618 % 1
			}
			local v498, v499 = pcall(v496, v487, v483, v497)
			if not v498 then
				local v500 = v_u_15.missing
				local v501 = p478.pose
				local v502 = "zombie pose " .. tostring(v501) .. ": " .. tostring(v499)
				table.insert(v500, v502)
			end
			if p478.eyes ~= nil then
				p480 = p478.eyes
			end
			v_u_477(v_u_489, p480)
			local v503 = v_u_15.zombies
			table.insert(v503, v487)
		else
			local v504 = v_u_15.missing
			local v505 = "zombie rig " .. v484
			table.insert(v504, v505)
		end
	else
		local v506 = v_u_15.missing
		table.insert(v506, "ZombieRender.previewRig")
		return
	end
end
local function v_u_569(p508) -- name: expandZombies
	-- upvalues: (copy) v_u_32, (copy) v_u_13
	local v509 = {}
	for _, v510 in p508 do
		local v511 = v510.count
		local v512 = tonumber(v511)
		local v513 = (not v512 or v512 ~= v512) and 1 or v512
		local v514 = math.floor(v513)
		local v515 = math.max(1, v514)
		if v515 == 1 and not (v510.arc or (v510.scatter or v510.line)) then
			table.insert(v509, v510)
		else
			local v516 = Random.new
			local v517 = v510.seed
			local v518 = tonumber(v517)
			local v519 = ((not v518 or v518 ~= v518) and 7 or v518) * 1000
			local v520 = v516((math.floor(v519)))
			local v521 = v510.poses
			local v522
			if type(v521) == "table" then
				v522 = v510.poses
			else
				v522 = { v510.pose or "walk" }
			end
			for v523 = 1, v515 do
				local v524 = table.clone(v510)
				v524.count = nil
				local v525 = v515 <= 1 and 0.5 or (v523 - 1) / (v515 - 1)
				local v526 = 0
				local v527 = 0
				if v510.arc then
					local v528, v529 = v_u_32(v510.arc.center)
					local v530 = v510.arc.from
					local v531 = tonumber(v530)
					local v532 = (not v531 or v531 ~= v531) and -60 or v531
					local v533 = v510.arc.to
					local v534 = tonumber(v533)
					local v535 = (not v534 or v534 ~= v534) and 60 or v534
					local v536 = v510.arc.from
					local v537 = tonumber(v536)
					local v538 = v532 + (v535 - ((not v537 or v537 ~= v537) and -60 or v537)) * v525
					local v539 = v520:NextNumber(-1, 1)
					local v540 = v510.arc.jitter
					local v541 = tonumber(v540)
					local v542 = v_u_13(v538 + v539 * ((not v541 or v541 ~= v541) and 6 or v541))
					local v543 = v510.arc.r
					local v544 = tonumber(v543)
					local v545 = (not v544 or v544 ~= v544) and 10 or v544
					local v546 = v520:NextNumber(-1, 1)
					local v547 = v510.arc.depth
					local v548 = tonumber(v547)
					local v549 = v545 + v546 * ((not v548 or v548 ~= v548) and 1.5 or v548)
					v526 = v528 - math.cos(v542) * v549
					v527 = v529 + math.sin(v542) * v549
				elseif v510.scatter then
					local v550, v551 = v_u_32(v510.scatter.center)
					local v552 = v520:NextNumber(0, 6.283185307179586)
					local v553 = v520:NextNumber(0.05, 1)
					local v554 = math.sqrt(v553)
					local v555 = v510.scatter.radius
					local v556 = tonumber(v555)
					local v557 = v554 * ((not v556 or v556 ~= v556) and 6 or v556)
					v526 = v550 + math.cos(v552) * v557
					v527 = v551 + math.sin(v552) * v557
				elseif v510.line then
					local v558, v559 = v_u_32(v510.line.from)
					local v560, v561 = v_u_32(v510.line.to)
					v526 = v558 + (v560 - v558) * v525
					v527 = v559 + (v561 - v559) * v525
				end
				v524.at = { v526, v527, 0 }
				v524.pose = v522[(v523 - 1) % #v522 + 1]
				v524.seed = v520:NextNumber()
				v524.phase = v520:NextNumber()
				local v562
				if v510.look == nil then
					v562 = nil
				else
					v562 = v510.look
				end
				v524.look = v562
				local v563 = v510.yaw
				local v564 = tonumber(v563)
				local v565 = (not v564 or v564 ~= v564) and 0 or v564
				local v566 = v520:NextNumber(-1, 1)
				local v567 = v510.yawJitter
				local v568 = tonumber(v567)
				v524.yaw = v565 + v566 * ((not v568 or v568 ~= v568) and 10 or v568)
				table.insert(v509, v524)
			end
		end
	end
	return v509
end
local function v_u_583(p570) -- name: relRot
	-- upvalues: (copy) v_u_15, (copy) v_u_13
	local v571 = v_u_15.anchor
	local v572 = v571 - v571.Position
	local v573 = CFrame.Angles
	local v574 = p570.yaw
	local v575 = tonumber(v574)
	local v576 = v572 * v573(0, v_u_13((not v575 or v575 ~= v575) and 0 or v575), 0)
	local v577 = CFrame.Angles
	local v578 = p570.pitch
	local v579 = tonumber(v578)
	local v580 = v_u_13((not v579 or v579 ~= v579) and 0 or v579)
	local v581 = p570.roll
	local v582 = tonumber(v581)
	return v576 * v577(v580, 0, (v_u_13((not v582 or v582 ~= v582) and 0 or v582)))
end
local function v_u_617(p584, p585) -- name: textPlate
	local v586 = Instance.new("SurfaceGui")
	v586.Name = "Plate"
	local v587 = Enum.NormalId
	local v588 = p585.face or "Front"
	v586.Face = v587[tostring(v588)] or Enum.NormalId.Front
	v586.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	local v589 = p585.pps
	local v590 = tonumber(v589)
	v586.PixelsPerStud = (not v590 or v590 ~= v590) and 120 or v590
	local v591 = p585.lit
	local v592 = tonumber(v591)
	v586.LightInfluence = (not v592 or v592 ~= v592) and 1 or v592
	local v593 = p585.brightness
	local v594 = tonumber(v593)
	v586.Brightness = (not v594 or v594 ~= v594) and 1 or v594
	v586.AlwaysOnTop = false
	v586.Adornee = p584
	local v595 = Instance.new("TextLabel")
	v595.Size = UDim2.fromScale(1, 1)
	v595.BackgroundTransparency = p585.bg and 0 or 1
	local v596 = p585.bg
	local v597 = Color3.new(1, 1, 1)
	if typeof(v596) == "Color3" then
		v597 = v596
	elseif type(v596) == "string" and string.match(v596, "^#?%x%x%x%x%x%x$") then
		v597 = Color3.fromHex(v596)
	end
	v595.BackgroundColor3 = v597
	v595.BorderSizePixel = 0
	local v598 = p585.text or ""
	v595.Text = tostring(v598)
	local v599 = p585.color
	local v600 = Color3.fromRGB(20, 20, 22)
	if typeof(v599) == "Color3" then
		v600 = v599
	elseif type(v599) == "string" and string.match(v599, "^#?%x%x%x%x%x%x$") then
		v600 = Color3.fromHex(v599)
	end
	v595.TextColor3 = v600
	local v601 = v586.Face
	local v602
	if v601 == Enum.NormalId.Left or v601 == Enum.NormalId.Right then
		v602 = p584.Size.Z
	else
		v602 = p584.Size.X
	end
	local v603
	if v601 == Enum.NormalId.Top or v601 == Enum.NormalId.Bottom then
		v603 = p584.Size.Z
	else
		v603 = p584.Size.Y
	end
	local v604 = v586.PixelsPerStud
	local v605 = #v595.Text
	local v606 = math.max(1, v605)
	v595.TextScaled = false
	local v607 = v603 * v604
	local v608 = p585.scale
	local v609 = tonumber(v608)
	local v610 = v607 * ((not v609 or v609 ~= v609) and 0.62 or v609)
	local v611 = v602 * v604 * 0.86 / (v606 * 0.6)
	local v612 = math.min(v610, v611)
	local v613 = math.floor(v612)
	v595.TextSize = math.max(8, v613)
	v595.TextWrapped = p585.wrap == true
	local v614 = p585.font
	local v615
	if typeof(v614) == "EnumItem" then
		v615 = p585.font
	else
		v615 = Enum.Font.SpecialElite
	end
	v595.Font = v615
	local v616 = Instance.new("UIPadding")
	v616.PaddingLeft = UDim.new(0.06, 0)
	v616.PaddingRight = UDim.new(0.06, 0)
	v616.PaddingTop = UDim.new(0.08, 0)
	v616.PaddingBottom = UDim.new(0.08, 0)
	v616.Parent = v595
	v595.Parent = v586
	v586.Parent = p584
end
local function v_u_633(p_u_618) -- name: assetModel
	-- upvalues: (ref) v_u_12
	local function v623()
		-- upvalues: (ref) v_u_12, (copy) p_u_618
		local v619 = v_u_12.shared.Assets.get
		local v620 = p_u_618.category or "Vehicle"
		local v621 = tostring(v620)
		local v622 = p_u_618.name or "Heli"
		return v619(v621, (tostring(v622)))
	end
	local v624, v_u_625 = pcall(v623)
	if not v624 or (typeof(v_u_625) ~= "Instance" or not v_u_625:IsA("Model")) then
		return nil
	end
	if string.find(v_u_625.Name, "_MISSING", 1, true) then
		v_u_625:Destroy()
		return nil
	end
	for _, v626 in v_u_625:GetDescendants() do
		if v626:IsA("BasePart") then
			v626.Anchored = true
			v626.CanCollide = false
			v626.CanQuery = false
			v626.CanTouch = false
		else
			if not (v626:IsA("LuaSourceContainer") or v626:IsA("Sound")) then
				continue
			end
			v626:Destroy()
		end
	end
	local v627 = p_u_618.scale
	local v628 = tonumber(v627)
	if ((not v628 or v628 ~= v628) and 1 or v628) ~= 1 then
		pcall(function()
			-- upvalues: (copy) v_u_625, (copy) p_u_618
			local v629 = v_u_625
			local v630 = v_u_625:GetScale()
			local v631 = p_u_618.scale
			local v632 = tonumber(v631)
			v629:ScaleTo(v630 * ((not v632 or v632 ~= v632) and 1 or v632))
		end)
	end
	return v_u_625
end
local function v_u_660(p634, p635) -- name: rotorBlur
	-- upvalues: (copy) v_u_14, (copy) v_u_15
	local v636 = p634:GetPivot().UpVector
	local v637 = p634:GetPivot().RightVector
	for _, v638 in p634:GetDescendants() do
		local v639 = v638.Name
		local v640 = string.sub(v639, 1, 9) == "TailRotor"
		if not v640 and (string.sub(v639, 1, 5) ~= "Rotor" and string.sub(v639, 1, 9) ~= "MainRotor") or not (v638:IsA("Model") or v638:IsA("BasePart")) then
			continue
		end
		local v641, v642
		if v638:IsA("Model") then
			v641, v642 = v638:GetBoundingBox()
		else
			v641 = v638.CFrame
			v642 = v638.Size
		end
		for _, v643 in not v638:IsA("Model") and { v638 } or v638:GetDescendants() do
			if not v643:IsA("BasePart") then
				continue
			end
			local v644 = v643.Transparency
			local v645 = p635.bladeAlpha
			local v646 = tonumber(v645)
			local v647 = (not v646 or v646 ~= v646) and 0.55 or v646
			v643.Transparency = math.max(v644, v647)
		end
		local v648 = v642.X
		local v649 = v642.Y
		local v650 = v642.Z
		local v651 = math.max(v648, v649, v650)
		local v652
		if v640 then
			v652 = v637
		else
			v652 = v636
		end
		local v653 = v_u_14(0.06, v651, v651)
		local v654 = CFrame.lookAt(v641.Position, v641.Position + v652) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v655 = Color3.fromRGB(30, 32, 34)
		local v656 = Enum.Material.SmoothPlastic
		local v657 = Instance.new("Part")
		v657.Name = "RotorBlur"
		v657.Size = v653
		v657.CFrame = v654
		v657.Color = v655
		v657.Material = v656 or Enum.Material.SmoothPlastic
		v657.Anchored = true
		v657.CanCollide = false
		v657.CanQuery = false
		v657.CanTouch = false
		v657.CastShadow = false
		v657.Parent = p634 or v_u_15.folder
		v657.Shape = Enum.PartType.Cylinder
		local v658 = p635.rotorAlpha
		local v659 = tonumber(v658)
		v657.Transparency = (not v659 or v659 ~= v659) and 0.8 or v659
	end
end
local function v_u_889(p661) -- name: buildEffect
	-- upvalues: (copy) v_u_50, (copy) v_u_13, (copy) v_u_227, (copy) v_u_15, (copy) v_u_140, (copy) v_u_94, (copy) v_u_32, (copy) v_u_14, (copy) v_u_84, (copy) v_u_77, (copy) v_u_583, (copy) v_u_617, (copy) v_u_633, (copy) v_u_660, (copy) v_u_158
	local v662 = p661.kind or ""
	local v663 = tostring(v662)
	if v663 == "flare" then
		local v664 = v_u_50(p661.at, true)
		local v665 = CFrame.new(v664 + Vector3.new(0, 0.12, 0))
		local v666 = CFrame.Angles
		local v667 = p661.tilt
		local v668 = tonumber(v667)
		local v669 = v_u_13((not v668 or v668 ~= v668) and 70 or v668)
		local v670 = p661.yaw
		local v671 = tonumber(v670)
		local v672 = v665 * v666(v669, v_u_13((not v671 or v671 ~= v671) and 30 or v671), 0)
		local v673 = v_u_227
		local v674 = p661.scale
		local v675 = tonumber(v674)
		v673(v672, (not v675 or v675 ~= v675) and 1 or v675, p661)
		local v676 = v_u_15
		v676.effects = v676.effects + 1
		return
	elseif v663 == "smoke" then
		local v677 = CFrame.new((v_u_50(p661.at, p661.ground == true)))
		local v678, v679, v680 = Color3.new(0, 0, 0)
		local v681 = Instance.new("Part")
		v681.Name = "Smoke"
		v681.Size = Vector3.new(0.2, 0.2, 0.2)
		v681.CFrame = v677
		v681.Color = v678
		v681.Material = v679 or Enum.Material.SmoothPlastic
		v681.Anchored = true
		v681.CanCollide = false
		v681.CanQuery = false
		v681.CanTouch = false
		v681.CastShadow = false
		v681.Parent = v680 or v_u_15.folder
		v681.Transparency = 1
		v_u_140(v681, p661)
		local v682 = v_u_15
		v682.effects = v682.effects + 1
		return
	elseif v663 == "light" then
		local v683 = v_u_50(p661.at, p661.ground == true)
		local v684 = CFrame.new(v683)
		if p661.aim then
			v684 = CFrame.lookAt(v683, (v_u_50(p661.aim, p661.aimGround == true)))
		end
		local v685, v686, v687 = Color3.new(0, 0, 0)
		local v688 = Instance.new("Part")
		v688.Name = "Light"
		v688.Size = Vector3.new(0.2, 0.2, 0.2)
		v688.CFrame = v684
		v688.Color = v685
		v688.Material = v686 or Enum.Material.SmoothPlastic
		v688.Anchored = true
		v688.CanCollide = false
		v688.CanQuery = false
		v688.CanTouch = false
		v688.CastShadow = false
		v688.Parent = v687 or v_u_15.folder
		v688.Transparency = 1
		local v689 = v_u_94
		local v690 = p661.type == "spot" and "spot" or "point"
		local v691 = p661.color
		local v692 = Color3.new(1, 1, 1)
		if typeof(v691) == "Color3" then
			v692 = v691
		elseif type(v691) == "string" and string.match(v691, "^#?%x%x%x%x%x%x$") then
			v692 = Color3.fromHex(v691)
		end
		local v693 = p661.range
		local v694 = tonumber(v693)
		local v695 = (not v694 or v694 ~= v694) and 30 or v694
		local v696 = p661.brightness
		local v697 = tonumber(v696)
		local v698 = (not v697 or v697 ~= v697) and 2 or v697
		local v699 = p661.shadows == true
		local v700 = p661.angle
		local v701 = tonumber(v700)
		v689(v690, v688, v692, v695, v698, v699, (not v701 or v701 ~= v701) and 40 or v701)
		local v702 = v_u_15
		v702.effects = v702.effects + 1
		return
	elseif v663 == "beam" then
		local v703 = p661.from
		local v704 = v_u_15.anchor
		local v705, v706, v707 = v_u_32(v703)
		local v708 = v704.Position + v704.LookVector * v705 + v704.RightVector * v706
		local v709 = v_u_14(v708.X, v_u_15.ground, v708.Z) + v_u_14(0, v707, 0)
		local v710 = v_u_50(p661.to, p661.toGround == true)
		local v711 = CFrame.lookAt(v709, v710)
		local v712, v713, v714 = Color3.new(0, 0, 0)
		local v715 = Instance.new("Part")
		v715.Name = "Searchlight"
		v715.Size = Vector3.new(0.2, 0.2, 0.2)
		v715.CFrame = v711
		v715.Color = v712
		v715.Material = v713 or Enum.Material.SmoothPlastic
		v715.Anchored = true
		v715.CanCollide = false
		v715.CanQuery = false
		v715.CanTouch = false
		v715.CastShadow = false
		v715.Parent = v714 or v_u_15.folder
		v715.Transparency = 1
		local v716 = Instance.new("Attachment")
		v716.Parent = v715
		local v717 = Instance.new("Attachment")
		v717.Parent = v715
		v717.WorldPosition = v710
		local v718 = p661.color
		local v719 = Color3.fromRGB(220, 232, 255)
		if typeof(v718) == "Color3" then
			v719 = v718
		elseif type(v718) == "string" and string.match(v718, "^#?%x%x%x%x%x%x$") then
			v719 = Color3.fromHex(v718)
		end
		local v720 = {}
		local v721 = {}
		local v722 = p661.width0
		local v723 = tonumber(v722)
		v721.w = (not v723 or v723 ~= v723) and 1.2 or v723
		local v724 = p661.width1
		local v725 = tonumber(v724)
		v721.w1 = (not v725 or v725 ~= v725) and 10 or v725
		local v726 = p661.alpha
		local v727 = tonumber(v726)
		v721.t = (not v727 or v727 ~= v727) and 0.55 or v727
		local v728 = {}
		local v729 = p661.width0
		local v730 = tonumber(v729)
		v728.w = ((not v730 or v730 ~= v730) and 1.2 or v730) * 2.4
		local v731 = p661.width1
		local v732 = tonumber(v731)
		v728.w1 = ((not v732 or v732 ~= v732) and 10 or v732) * 1.7
		local v733 = p661.alpha
		local v734 = tonumber(v733)
		local v735 = ((not v734 or v734 ~= v734) and 0.55 or v734) + 0.3
		v728.t = math.min(0.92, v735)
		__set_list(v720, 1, {v721, v728})
		for _, v736 in v720 do
			local v737 = Instance.new("Beam")
			v737.Attachment0 = v716
			v737.Attachment1 = v717
			v737.Color = ColorSequence.new(v719)
			v737.LightEmission = 1
			v737.LightInfluence = 0
			v737.FaceCamera = true
			v737.Segments = 1
			local v738 = v736.w
			local v739 = v736.w1
			v737.Width0 = v738
			v737.Width1 = v739
			local v740 = NumberSequence.new
			local v741 = {}
			local v742 = NumberSequenceKeypoint.new(0, v736.t)
			local v743 = NumberSequenceKeypoint.new
			local v744 = v736.t + 0.25
			__set_list(v741, 1, {v742, v743(0.75, (math.min(1, v744))), NumberSequenceKeypoint.new(1, 1)})
			v737.Transparency = v740(v741)
			v737.Parent = v715
		end
		if p661.light ~= false then
			local v745 = p661.range
			local v746 = (v710 - v709).Magnitude + 10
			local v747 = tonumber(v745)
			if v747 then
				if v747 ~= v747 then
					v747 = v746
				end
			else
				v747 = v746
			end
			local v748 = p661.brightness
			local v749 = tonumber(v748)
			local v750 = (not v749 or v749 ~= v749) and 4 or v749
			local v751 = p661.shadows ~= false
			local v752 = p661.angle
			local v753 = tonumber(v752)
			local v754 = (not v753 or v753 ~= v753) and 24 or v753
			local v755 = Instance.new("SpotLight")
			v755.Angle = v754 or 45
			v755.Face = Enum.NormalId.Front
			v755.Color = v719
			v755.Range = v747
			v755.Brightness = v750
			v755.Shadows = v751 == true
			v755.Parent = v715
			local v756 = v_u_15
			v756.lights = v756.lights + 1
		end
		if p661.lamp ~= false then
			local v757 = CFrame.lookAt(v709, v710) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v758 = Enum.Material.Neon
			local v759 = Instance.new("Part")
			v759.Name = "Lamp"
			v759.Size = Vector3.new(0.25, 1.3, 1.3)
			v759.CFrame = v757
			v759.Color = v719
			v759.Material = v758 or Enum.Material.SmoothPlastic
			v759.Anchored = true
			v759.CanCollide = false
			v759.CanQuery = false
			v759.CanTouch = false
			v759.CastShadow = false
			v759.Parent = v_u_15.folder
			v759.Shape = Enum.PartType.Cylinder
		end
		local v760 = v_u_15
		v760.effects = v760.effects + 1
		return
	elseif v663 == "rain" then
		local v761 = p661.at or { 0, 0, 0 }
		local v762 = v_u_15.anchor
		local v763, v764, v765 = v_u_32(v761)
		local v766 = v762.Position + v762.LookVector * v763 + v762.RightVector * v764
		local v767 = v_u_14(v766.X, v_u_15.ground, v766.Z) + v_u_14(0, v765, 0)
		local v768 = p661.area
		local v769 = tonumber(v768)
		local v770 = (not v769 or v769 ~= v769) and 70 or v769
		local v771 = v_u_14(v770, 1, v770)
		local v772 = CFrame.new
		local v773 = p661.height
		local v774 = tonumber(v773)
		local v775 = v772(v767 + v_u_14(0, (not v774 or v774 ~= v774) and 26 or v774, 0))
		local v776, v777, v778 = Color3.new(1, 1, 1)
		local v779 = Instance.new("Part")
		v779.Name = "RainSheet"
		v779.Size = v771
		v779.CFrame = v775
		v779.Color = v776
		v779.Material = v777 or Enum.Material.SmoothPlastic
		v779.Anchored = true
		v779.CanCollide = false
		v779.CanQuery = false
		v779.CanTouch = false
		v779.CastShadow = false
		v779.Parent = v778 or v_u_15.folder
		v779.Transparency = 1
		local v780 = v_u_84
		local v781 = {
			["Name"] = "Rain",
			["Texture"] = "rbxasset://textures/particles/sparkles_main.dds",
			["Color"] = nil,
			["LightEmission"] = nil,
			["LightInfluence"] = 0.6,
			["Orientation"] = nil,
			["Squash"] = nil,
			["Size"] = nil,
			["Transparency"] = nil,
			["Lifetime"] = nil,
			["Rate"] = nil,
			["Speed"] = nil,
			["Acceleration"] = nil,
			["EmissionDirection"] = nil,
			["Shape"] = nil,
			["ShapeStyle"] = nil,
			["Color"] = ColorSequence.new(v_u_77(p661.color, Color3.fromRGB(196, 210, 230)))
		}
		local v782 = p661.emission
		local v783 = tonumber(v782)
		v781.LightEmission = (not v783 or v783 ~= v783) and 0.35 or v783
		v781.Orientation = Enum.ParticleOrientation.VelocityParallel
		local v784 = NumberSequence.new
		local v785 = p661.streak
		local v786 = tonumber(v785)
		v781.Squash = v784((not v786 or v786 ~= v786) and 3.2 or v786)
		local v787 = NumberSequence.new
		local v788 = p661.size
		local v789 = tonumber(v788)
		v781.Size = v787((not v789 or v789 ~= v789) and 0.16 or v789)
		local v790 = NumberSequence.new
		local v791 = p661.alpha
		local v792 = tonumber(v791)
		v781.Transparency = v790((not v792 or v792 ~= v792) and 0.35 or v792)
		v781.Lifetime = NumberRange.new(0.9, 1.3)
		local v793 = p661.rate
		local v794 = tonumber(v793)
		v781.Rate = (not v794 or v794 ~= v794) and 900 or v794
		local v795 = NumberRange.new
		local v796 = p661.speed
		local v797 = tonumber(v796)
		local v798 = (not v797 or v797 ~= v797) and 34 or v797
		local v799 = p661.speed
		local v800 = tonumber(v799)
		v781.Speed = v795(v798, ((not v800 or v800 ~= v800) and 34 or v800) + 8)
		local v801 = p661.windX
		local v802 = tonumber(v801)
		local v803 = (not v802 or v802 ~= v802) and 2 or v802
		local v804 = p661.windZ
		local v805 = tonumber(v804)
		v781.Acceleration = v_u_14(v803, 0, (not v805 or v805 ~= v805) and 1 or v805)
		v781.EmissionDirection = Enum.NormalId.Bottom
		v781.Shape = Enum.ParticleEmitterShape.Box
		v781.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v780(v779, v781)
		local v806 = v_u_15
		v806.effects = v806.effects + 1
		return
	elseif v663 == "dust" or (v663 == "embers" or v663 == "ash") then
		local v807 = p661.at or { 0, 0, 3 }
		local v808 = v_u_15.anchor
		local v809, v810, v811 = v_u_32(v807)
		local v812 = v808.Position + v808.LookVector * v809 + v808.RightVector * v810
		local v813 = v_u_14(v812.X, v_u_15.ground, v812.Z) + v_u_14(0, v811, 0)
		local v814 = p661.box
		local v815 = typeof(v814) ~= "Vector3" and Vector3.new(24, 8, 24) or p661.box
		local v816 = CFrame.new(v813)
		local v817, v818, v819 = Color3.new(1, 1, 1)
		local v820 = Instance.new("Part")
		v820.Name = "Motes"
		v820.Size = v815
		v820.CFrame = v816
		v820.Color = v817
		v820.Material = v818 or Enum.Material.SmoothPlastic
		v820.Anchored = true
		v820.CanCollide = false
		v820.CanQuery = false
		v820.CanTouch = false
		v820.CastShadow = false
		v820.Parent = v819 or v_u_15.folder
		v820.Transparency = 1
		local v821 = v663 == "embers"
		local v822 = v_u_84
		local v823 = {
			["Name"] = v663,
			["Texture"] = v821 and "rbxasset://textures/particles/fire_sparks_main.dds" or "rbxasset://textures/particles/sparkles_main.dds"
		}
		local v824 = ColorSequence.new
		local v825 = v_u_77
		local v826 = p661.color
		local v827
		if v821 then
			v827 = Color3.fromRGB(255, 120, 60)
		else
			v827 = Color3.fromRGB(220, 220, 230)
		end
		v823.Color = v824(v825(v826, v827))
		v823.LightEmission = v821 and 1 or 0.4
		v823.LightInfluence = v821 and 0 or 0.8
		local v828 = NumberSequence.new
		local v829 = {}
		local v830 = NumberSequenceKeypoint.new
		local v831 = 0
		local v832 = p661.size
		local v833 = v821 and 0.18 or 0.1
		local v834 = tonumber(v832)
		if v834 then
			if v834 ~= v834 then
				v834 = v833
			end
		else
			v834 = v833
		end
		__set_list(v829, 1, {v830(v831, v834), NumberSequenceKeypoint.new(1, 0)})
		v823.Size = v828(v829)
		local v835 = NumberSequence.new
		local v836 = {}
		local v837 = NumberSequenceKeypoint.new(0, 1)
		local v838 = NumberSequenceKeypoint.new
		local v839 = p661.alpha
		local v840 = tonumber(v839)
		__set_list(v836, 1, {v837, v838(0.2, (not v840 or v840 ~= v840) and 0.3 or v840), NumberSequenceKeypoint.new(1, 1)})
		v823.Transparency = v835(v836)
		v823.Lifetime = NumberRange.new(3, 6)
		local v841 = p661.rate
		local v842 = v821 and 25 or 40
		local v843 = tonumber(v841)
		if v843 then
			if v843 ~= v843 then
				v843 = v842
			end
		else
			v843 = v842
		end
		v823.Rate = v843
		v823.Speed = NumberRange.new(0.2, v821 and 2.5 or 0.8)
		v823.SpreadAngle = Vector2.new(180, 180)
		v823.Acceleration = v_u_14(0.3, v821 and 1.2 or 0.05, 0.2)
		v823.Shape = Enum.ParticleEmitterShape.Box
		v823.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v822(v820, v823)
		local v844 = v_u_15
		v844.effects = v844.effects + 1
		return
	elseif v663 == "prop" then
		local v845 = v_u_50(p661.at, p661.ground ~= false)
		local v846 = p661.size
		local v847 = typeof(v846) ~= "Vector3" and Vector3.new(2, 2, 2) or p661.size
		local v848 = CFrame.new(v845 + v_u_14(0, p661.ground == false and 0 or v847.Y / 2, 0)) * v_u_583(p661)
		local v849
		if p661.shape == "wedge" then
			v849 = Instance.new("WedgePart")
			v849.Name = "Prop"
			v849.Size = v847
			v849.CFrame = v848
			v849.Anchored = true
			v849.CanCollide = false
			v849.CanQuery = false
			v849.CanTouch = false
			v849.Parent = v_u_15.folder
		else
			local v850, v851, v852 = Color3.new(1, 1, 1)
			v849 = Instance.new("Part")
			v849.Name = "Prop"
			v849.Size = v847
			v849.CFrame = v848
			v849.Color = v850
			v849.Material = v851 or Enum.Material.SmoothPlastic
			v849.Anchored = true
			v849.CanCollide = false
			v849.CanQuery = false
			v849.CanTouch = false
			v849.CastShadow = false
			v849.Parent = v852 or v_u_15.folder
			if p661.shape == "cylinder" then
				v849.Shape = Enum.PartType.Cylinder
			elseif p661.shape == "ball" then
				v849.Shape = Enum.PartType.Ball
			end
		end
		local v853 = p661.color
		local v854 = Color3.fromRGB(90, 80, 70)
		if typeof(v853) == "Color3" then
			v854 = v853
		elseif type(v853) == "string" and string.match(v853, "^#?%x%x%x%x%x%x$") then
			v854 = Color3.fromHex(v853)
		end
		v849.Color = v854
		local v855 = p661.material
		local v856
		if typeof(v855) == "EnumItem" then
			v856 = p661.material
		else
			v856 = Enum.Material.WoodPlanks
		end
		v849.Material = v856
		local v857 = p661.alpha
		local v858 = tonumber(v857)
		v849.Transparency = (not v858 or v858 ~= v858) and 0 or v858
		local v859
		if p661.shadow == false then
			v859 = false
		else
			v859 = v849.Transparency < 0.5
		end
		v849.CastShadow = v859
		local v860 = p661.text
		if type(v860) == "table" then
			v_u_617(v849, p661.text)
		end
		local v861 = p661.glow
		if type(v861) == "table" then
			local v862 = v_u_94
			local v863 = p661.glow.type == "spot" and "spot" or "point"
			local v864 = p661.glow.color
			local v865 = v849.Color
			if typeof(v864) == "Color3" then
				v865 = v864
			elseif type(v864) == "string" and string.match(v864, "^#?%x%x%x%x%x%x$") then
				v865 = Color3.fromHex(v864)
			end
			local v866 = p661.glow.range
			local v867 = tonumber(v866)
			local v868 = (not v867 or v867 ~= v867) and 10 or v867
			local v869 = p661.glow.brightness
			local v870 = tonumber(v869)
			local v871 = (not v870 or v870 ~= v870) and 1 or v870
			local v872 = p661.glow.shadows == true
			local v873 = p661.glow.angle
			local v874 = tonumber(v873)
			v862(v863, v849, v865, v868, v871, v872, (not v874 or v874 ~= v874) and 60 or v874)
		end
		local v875 = v_u_15
		v875.effects = v875.effects + 1
		return
	elseif v663 == "model" then
		local v876 = v_u_633(p661)
		if v876 then
			local v877 = v_u_50(p661.at, p661.ground == true)
			v876:PivotTo(CFrame.new(v877) * v_u_583(p661))
			v876.Parent = v_u_15.folder
			if p661.rotorBlur ~= false then
				v_u_660(v876, p661)
			end
			local v878 = v_u_15
			v878.effects = v878.effects + 1
		else
			local v879 = v_u_15.missing
			local v880 = p661.category
			local v881 = tostring(v880)
			local v882 = p661.name
			local v883 = "model " .. v881 .. "/" .. tostring(v882)
			table.insert(v879, v883)
		end
	else
		if v663 == "item" then
			local v884 = v_u_158(p661)
			if v884 then
				v884:PivotTo(CFrame.new((v_u_50(p661.at, p661.ground == true))) * v_u_583(p661))
				v884.Parent = v_u_15.folder
				local v885 = v_u_15
				v885.effects = v885.effects + 1
				return
			end
			local v886 = v_u_15.missing
			local v887 = p661.id
			local v888 = "item " .. tostring(v887)
			table.insert(v886, v888)
		end
		return
	end
end
local function v_u_898(p890, p891, p892) -- name: camFx
	-- upvalues: (copy) v_u_15
	local v893 = workspace.CurrentCamera
	if not v893 then
		return nil
	end
	local v_u_894 = Instance.new(p890)
	v_u_894.Name = p891
	v_u_894:SetAttribute("FilmMode", true)
	for v_u_895, v_u_896 in p892 do
		pcall(function()
			-- upvalues: (copy) v_u_894, (copy) v_u_895, (copy) v_u_896
			v_u_894[v_u_895] = v_u_896
		end)
	end
	v_u_894.Parent = v893
	local v897 = v_u_15.camFx
	table.insert(v897, v_u_894)
	return v_u_894
end
local function v_u_907(p899) -- name: vignette
	-- upvalues: (copy) v_u_11, (copy) v_u_7, (copy) v_u_15
	local v900 = v_u_11:FindFirstChildOfClass("PlayerGui")
	if v900 and p899 > 0 then
		v_u_7.exempt("HushFilmVignette", true)
		local v901 = Instance.new("ScreenGui")
		v901.Name = "HushFilmVignette"
		v901.IgnoreGuiInset = true
		v901.ResetOnSpawn = false
		v901.DisplayOrder = 850
		v901.ScreenInsets = Enum.ScreenInsets.None
		local v902 = {
			{ UDim2.fromScale(0, 0), UDim2.fromScale(0.34, 1), 0 },
			{ UDim2.fromScale(0.66, 0), UDim2.fromScale(0.34, 1), 180 },
			{ UDim2.fromScale(0, 0), UDim2.fromScale(1, 0.36), 90 },
			{ UDim2.fromScale(0, 0.64), UDim2.fromScale(1, 0.36), 270 }
		}
		local v903 = 1 - math.clamp(p899, 0, 1)
		for _, v904 in v902 do
			local v905 = Instance.new("Frame")
			v905.BorderSizePixel = 0
			v905.BackgroundColor3 = Color3.fromRGB(2, 3, 6)
			v905.Position = v904[1]
			v905.Size = v904[2]
			local v906 = Instance.new("UIGradient")
			v906.Rotation = v904[3]
			v906.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v903), NumberSequenceKeypoint.new(0.45, v903 * 0.5 + 0.5), NumberSequenceKeypoint.new(1, 1) })
			v906.Parent = v905
			v905.Parent = v901
		end
		v901.Parent = v900
		v_u_15.vignette = v901
	end
end
local function v_u_988(p908) -- name: applyGrade
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_15, (copy) v_u_898, (copy) v_u_907
	if type(p908) == "table" then
		if p908.clock ~= nil then
			local v909 = v_u_2
			local v910 = p908.clock
			local v911 = tonumber(v910)
			local v912 = (not v911 or v911 ~= v911) and 0 or v911
			if v909 ~= nil and v912 ~= nil then
				v_u_7.force(v909, "ClockTime", v912)
				local v913 = v_u_15.forcedProps
				table.insert(v913, { v909, "ClockTime" })
			end
		end
		if p908.exposure ~= nil then
			local v914 = v_u_2
			local v915 = p908.exposure
			local v916 = tonumber(v915)
			local v917 = (not v916 or v916 ~= v916) and 0 or v916
			if v914 ~= nil and v917 ~= nil then
				v_u_7.force(v914, "ExposureCompensation", v917)
				local v918 = v_u_15.forcedProps
				table.insert(v918, { v914, "ExposureCompensation" })
			end
		end
		if p908.brightness ~= nil then
			local v919 = v_u_2
			local v920 = p908.brightness
			local v921 = tonumber(v920)
			local v922 = (not v921 or v921 ~= v921) and 1 or v921
			if v919 ~= nil and v922 ~= nil then
				v_u_7.force(v919, "Brightness", v922)
				local v923 = v_u_15.forcedProps
				table.insert(v923, { v919, "Brightness" })
			end
		end
		if p908.ambient ~= nil then
			local v924 = v_u_2
			local v925 = p908.ambient
			local v926 = v_u_2.Ambient
			if typeof(v925) == "Color3" then
				v926 = v925
			elseif type(v925) == "string" and string.match(v925, "^#?%x%x%x%x%x%x$") then
				v926 = Color3.fromHex(v925)
			end
			if v924 ~= nil and v926 ~= nil then
				v_u_7.force(v924, "Ambient", v926)
				local v927 = v_u_15.forcedProps
				table.insert(v927, { v924, "Ambient" })
			end
		end
		if p908.outdoorAmbient ~= nil then
			local v928 = v_u_2
			local v929 = p908.outdoorAmbient
			local v930 = v_u_2.OutdoorAmbient
			if typeof(v929) == "Color3" then
				v930 = v929
			elseif type(v929) == "string" and string.match(v929, "^#?%x%x%x%x%x%x$") then
				v930 = Color3.fromHex(v929)
			end
			if v928 ~= nil and v930 ~= nil then
				v_u_7.force(v928, "OutdoorAmbient", v930)
				local v931 = v_u_15.forcedProps
				table.insert(v931, { v928, "OutdoorAmbient" })
			end
		end
		local v932 = p908.atmosphere
		if type(v932) == "table" then
			local v933 = v_u_2:FindFirstChildOfClass("Atmosphere")
			local v934 = p908.atmosphere
			if v933 then
				local v935 = v934.density
				if v933 ~= nil and v935 ~= nil then
					v_u_7.force(v933, "Density", v935)
					local v936 = v_u_15.forcedProps
					table.insert(v936, { v933, "Density" })
				end
				local v937 = v934.haze
				if v933 ~= nil and v937 ~= nil then
					v_u_7.force(v933, "Haze", v937)
					local v938 = v_u_15.forcedProps
					table.insert(v938, { v933, "Haze" })
				end
				local v939 = v934.glare
				if v933 ~= nil and v939 ~= nil then
					v_u_7.force(v933, "Glare", v939)
					local v940 = v_u_15.forcedProps
					table.insert(v940, { v933, "Glare" })
				end
				local v941 = v934.offset
				if v933 ~= nil and v941 ~= nil then
					v_u_7.force(v933, "Offset", v941)
					local v942 = v_u_15.forcedProps
					table.insert(v942, { v933, "Offset" })
				end
				if v934.color ~= nil then
					local v943 = v934.color
					local v944 = v933.Color
					if typeof(v943) == "Color3" then
						v944 = v943
					elseif type(v943) == "string" and string.match(v943, "^#?%x%x%x%x%x%x$") then
						v944 = Color3.fromHex(v943)
					end
					if v933 ~= nil and v944 ~= nil then
						v_u_7.force(v933, "Color", v944)
						local v945 = v_u_15.forcedProps
						table.insert(v945, { v933, "Color" })
					end
				end
				if v934.decay ~= nil then
					local v946 = v934.decay
					local v947 = v933.Decay
					if typeof(v946) == "Color3" then
						v947 = v946
					elseif type(v946) == "string" and string.match(v946, "^#?%x%x%x%x%x%x$") then
						v947 = Color3.fromHex(v946)
					end
					if v933 ~= nil and v947 ~= nil then
						v_u_7.force(v933, "Decay", v947)
						local v948 = v_u_15.forcedProps
						table.insert(v948, { v933, "Decay" })
					end
				end
			end
		end
		if p908.contrast ~= nil or (p908.saturation ~= nil or (p908.tint ~= nil or p908.grade ~= nil)) then
			local v949 = v_u_898
			local v950 = "ColorCorrectionEffect"
			local v951 = "FilmPhotoGrade"
			local v952 = {}
			local v953 = p908.gradeBrightness
			local v954 = tonumber(v953)
			v952.Brightness = (not v954 or v954 ~= v954) and 0 or v954
			local v955 = p908.contrast
			local v956 = tonumber(v955)
			v952.Contrast = (not v956 or v956 ~= v956) and 0 or v956
			local v957 = p908.saturation
			local v958 = tonumber(v957)
			v952.Saturation = (not v958 or v958 ~= v958) and 0 or v958
			local v959 = p908.tint
			local v960 = Color3.new(1, 1, 1)
			if typeof(v959) == "Color3" then
				v960 = v959
			elseif type(v959) == "string" and string.match(v959, "^#?%x%x%x%x%x%x$") then
				v960 = Color3.fromHex(v959)
			end
			v952.TintColor = v960
			v949(v950, v951, v952)
		end
		local v961 = p908.bloom
		if type(v961) == "table" then
			for _, v962 in v_u_2:GetChildren() do
				if not v962:IsA("BloomEffect") or v962 == nil then
					continue
				end
				v_u_7.force(v962, "Enabled", false)
				local v963 = v_u_15.forcedProps
				table.insert(v963, { v962, "Enabled" })
			end
			local v964 = v_u_898
			local v965 = {}
			local v966 = p908.bloom.intensity
			local v967 = tonumber(v966)
			v965.Intensity = (not v967 or v967 ~= v967) and 1 or v967
			local v968 = p908.bloom.size
			local v969 = tonumber(v968)
			v965.Size = (not v969 or v969 ~= v969) and 30 or v969
			local v970 = p908.bloom.threshold
			local v971 = tonumber(v970)
			v965.Threshold = (not v971 or v971 ~= v971) and 0.9 or v971
			v964("BloomEffect", "FilmPhotoBloom", v965)
		end
		local v972 = p908.rays
		if type(v972) == "table" then
			local v973 = v_u_898
			local v974 = {}
			local v975 = p908.rays.intensity
			local v976 = tonumber(v975)
			v974.Intensity = (not v976 or v976 ~= v976) and 0.1 or v976
			local v977 = p908.rays.spread
			local v978 = tonumber(v977)
			v974.Spread = (not v978 or v978 ~= v978) and 0.6 or v978
			v973("SunRaysEffect", "FilmPhotoRays", v974)
		end
		if p908.blur ~= nil then
			local v979 = p908.blur
			local v980 = tonumber(v979)
			if ((not v980 or v980 ~= v980) and 0 or v980) > 0 then
				local v981 = v_u_898
				local v982 = {}
				local v983 = p908.blur
				local v984 = tonumber(v983)
				v982.Size = (not v984 or v984 ~= v984) and 2 or v984
				v981("BlurEffect", "FilmPhotoBlur", v982)
			end
		end
		local v985 = v_u_907
		local v986 = p908.vignette
		local v987 = tonumber(v986)
		v985((not v987 or v987 ~= v987) and 0 or v987)
	end
end
local function v_u_1001(p989) -- name: hideDoors
	-- upvalues: (copy) v_u_15, (copy) v_u_32, (copy) v_u_14, (copy) v_u_3, (copy) v_u_8
	if type(p989) == "table" then
		local v990 = {}
		for _, v991 in p989 do
			local v992 = v_u_15.anchor
			local v993, v994, v995 = v_u_32(v991)
			local v996 = v992.Position + v992.LookVector * v993 + v992.RightVector * v994
			local v997 = v_u_14(v996.X, v_u_15.ground, v996.Z) + v_u_14(0, v995, 0)
			table.insert(v990, v997)
		end
		for _, v998 in v_u_3:GetTagged("HushDoor") do
			if not (v998:IsA("Model") and v998:IsDescendantOf(workspace)) then
				continue
			end
			local v999 = v998:GetPivot().Position
			for _, v1000 in v990 do
				if Vector2.new(v999.X - v1000.X, v999.Z - v1000.Z).Magnitude > 3.5 then
					continue
				end
				v_u_8.tree(v998)
			end
		end
	end
end
local function v_u_1021(p1002) -- name: hideModels
	-- upvalues: (copy) v_u_15, (copy) v_u_32, (copy) v_u_14, (copy) v_u_8
	if type(p1002) == "table" then
		local v1003 = workspace:FindFirstChild("Raid")
		if v1003 then
			local v1004 = {}
			for _, v1005 in p1002 do
				if type(v1005) ~= "table" then
					continue
				end
				local v1006 = {}
				local v1007 = v1005.at
				local v1008 = v_u_15.anchor
				local v1009, v1010, v1011 = v_u_32(v1007)
				local v1012 = v1008.Position + v1008.LookVector * v1009 + v1008.RightVector * v1010
				v1006.p = v_u_14(v1012.X, v_u_15.ground, v1012.Z) + v_u_14(0, v1011, 0)
				local v1013 = v1005.radius
				local v1014 = tonumber(v1013)
				v1006.r = (not v1014 or v1014 ~= v1014) and 2.5 or v1014
				local v1015 = v1005.name
				local v1016
				if type(v1015) == "string" then
					v1016 = v1005.name
				else
					v1016 = nil
				end
				v1006.name = v1016
				v1006.keep = v1005.keepLights == true
				table.insert(v1004, v1006)
			end
			for _, v1017 in v1003:GetDescendants() do
				local v1018 = v1017:IsA("Model")
				if not (v1018 or v1017:IsA("BasePart")) then
					continue
				end
				for _, v1019 in v1004 do
					if (v1019.name ~= nil or not v1018) and v1017.Name ~= v1019.name then
						continue
					end
					local v1020
					if v1018 then
						v1020 = v1017:GetPivot().Position
					else
						v1020 = v1017.Position
					end
					if Vector2.new(v1020.X - v1019.p.X, v1020.Z - v1019.p.Z).Magnitude > v1019.r then
						continue
					end
					v_u_8.tree(v1017, v1019.keep)
				end
			end
		end
	else
		return
	end
end
function v_u_10.setup(p1022) -- name: setup
	-- upvalues: (ref) v_u_12, (copy) v_u_11
	v_u_12 = p1022
	v_u_11:SetAttribute("FilmPhoto", "")
end
function v_u_10.clear() -- name: clear
	-- upvalues: (copy) v_u_15, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8, (ref) v_u_12, (copy) v_u_22
	local v1023 = v_u_15
	v1023.token = v1023.token + 1
	if v_u_15.folder then
		v_u_15.folder:Destroy()
	end
	v_u_15.folder = nil
	for _, v1024 in v_u_15.camFx do
		v1024:Destroy()
	end
	v_u_15.camFx = {}
	if v_u_15.vignette then
		v_u_15.vignette:Destroy()
	end
	v_u_15.vignette = nil
	for v1025 = #v_u_15.forcedProps, 1, -1 do
		local v1026 = v_u_15.forcedProps[v1025]
		v_u_7.release(v1026[1], v1026[2])
	end
	v_u_15.forcedProps = {}
	for _, v1027 in v_u_15.doorParts do
		v1027.LocalTransparencyModifier = v_u_9.clampLtm(v1027, 0)
	end
	v_u_15.doorParts = {}
	v_u_8.restore()
	if v_u_15.visionOff then
		local v1028 = v_u_12 and (v_u_12.controllers and v_u_12.controllers.Vision) or nil
		if v1028 and v1028.setEnabled then
			local v1029 = v1028.setEnabled
			pcall(v1029, true)
		end
		v_u_15.visionOff = false
	end
	local v1030 = v_u_12 and (v_u_12.controllers and v_u_12.controllers.Atmosphere) or nil
	if v_u_15.flashOff then
		if v1030 and v1030.setFlashlight then
			local v1031 = v1030.setFlashlight
			pcall(v1031, nil)
		end
		v_u_15.flashOff = false
	end
	if v_u_15.fxAnchor then
		if v1030 and v1030.setFxAnchor then
			local v1032 = v1030.setFxAnchor
			pcall(v1032, nil)
		end
		v_u_15.fxAnchor = false
	end
	if v_u_15.hidOwn then
		v_u_7.setCharacterHidden(false)
		v_u_15.hidOwn = false
	end
	local v1033 = v_u_15
	local v1034 = v_u_15
	v_u_15.id = nil
	v1033.scene = nil
	v1034.anchor = nil
	local v1035 = v_u_15
	local v1036 = v_u_15
	local v1037 = v_u_15
	v_u_15.actors = {}
	v1035.actorList = {}
	v1036.zombies = {}
	v1037.emitters = {}
	local v1038 = v_u_15
	local v1039 = v_u_15
	v_u_15.effects = 0
	v1038.lights = 0
	v1039.faces = 0
	v_u_15.plainHats = 0
	v_u_15.frozen = false
	v_u_15.missing = {}
	v_u_22()
end
function v_u_10.setFxFrozen(p1040) -- name: setFxFrozen
	-- upvalues: (copy) v_u_15, (copy) v_u_22
	v_u_15.frozen = p1040 == true
	for _, v1041 in v_u_15.emitters do
		if not v1041.Parent then
			continue
		end
		v1041.TimeScale = v_u_15.frozen and 0 or 1
	end
	v_u_22()
end
function v_u_10.fxFrozen() -- name: fxFrozen
	-- upvalues: (copy) v_u_15
	return v_u_15.frozen
end
function v_u_10.active() -- name: active
	-- upvalues: (copy) v_u_15
	return v_u_15.id
end
function v_u_10.anchor() -- name: anchor
	-- upvalues: (copy) v_u_15
	return v_u_15.anchor
end
function v_u_10.build(p1042, p_u_1043) -- name: build
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_40, (copy) v_u_8, (copy) v_u_7, (ref) v_u_12, (copy) v_u_32, (copy) v_u_14, (copy) v_u_442, (copy) v_u_569, (copy) v_u_507, (copy) v_u_889, (copy) v_u_1001, (copy) v_u_1021, (copy) v_u_988, (copy) v_u_22
	v_u_10.clear()
	local v_u_1044
	if p1042 then
		v_u_1044 = p1042.photo
	else
		v_u_1044 = p1042
	end
	if type(v_u_1044) ~= "table" then
		return false, "not a photo scene"
	end
	local v_u_1045 = v_u_15.token
	v_u_15.id = p1042.id
	v_u_15.scene = p1042
	v_u_15.anchor = p_u_1043
	v_u_15.ground = p_u_1043.Position.Y
	local v1046 = workspace:Raycast(p_u_1043.Position + Vector3.new(0, 5, 0), Vector3.new(0, -20, 0), (v_u_40()))
	if v1046 then
		v_u_15.ground = v1046.Position.Y
	end
	local v1047 = Instance.new("Folder")
	v1047.Name = "HushFilmPhoto"
	v1047.Parent = workspace
	v_u_15.folder = v1047
	if p1042.weather ~= "Rain" and p1042.weather ~= "Storm" then
		v_u_8.rain(12)
	end
	if v_u_1044.hidePlayer ~= false and not v_u_7.isCharacterHidden() then
		v_u_7.setCharacterHidden(true)
		v_u_15.hidOwn = true
	end
	local v1048 = v_u_12 and (v_u_12.controllers and v_u_12.controllers.Vision) or nil
	if v1048 and v1048.setEnabled then
		local v1049 = v1048.setEnabled
		pcall(v1049, false)
		v_u_15.visionOff = true
	end
	local v1050 = v_u_12 and (v_u_12.controllers and v_u_12.controllers.Atmosphere) or nil
	if v1050 and v1050.setFlashlight then
		local v1051 = v1050.setFlashlight
		pcall(v1051, false)
		v_u_15.flashOff = true
	end
	if v1050 and v1050.setFxAnchor then
		local v1052 = v_u_1044.camera
		if type(v1052) == "table" then
			local v1053 = v1050.setFxAnchor
			local v1054 = v_u_1044.camera.at
			local v1055 = v_u_15.anchor
			local v1056, v1057, v1058 = v_u_32(v1054)
			local v1059 = v1055.Position + v1055.LookVector * v1056 + v1055.RightVector * v1057
			local v1060 = v_u_14(v1059.X, v_u_15.ground, v1059.Z) + v_u_14(0, v1058, 0)
			pcall(v1053, v1060)
			v_u_15.fxAnchor = true
		end
	end
	for _, v1061 in v_u_1044.actors or {} do
		if v_u_1045 ~= v_u_15.token then
			return false, "replaced"
		end
		local v1062 = v_u_442
		local v1063, v1064 = pcall(v1062, v1061)
		if v1063 then
			continue
		end
		local v1065 = v_u_15.missing
		local v1066 = "actor: " .. tostring(v1064)
		table.insert(v1065, v1066)
	end
	for v1067, v1068 in v_u_569(v_u_1044.zombies or {}) do
		if v_u_1045 ~= v_u_15.token then
			return false, "replaced"
		end
		local v1069 = v_u_507
		local v1070 = v_u_1044.eyes
		local v1071, v1072 = pcall(v1069, v1068, v1067, v1070)
		if v1071 then
			continue
		end
		local v1073 = v_u_15.missing
		local v1074 = "zombie: " .. tostring(v1072)
		table.insert(v1073, v1074)
	end
	for _, v1075 in v_u_1044.effects or {} do
		local v1076 = v_u_889
		local v1077, v1078 = pcall(v1076, v1075)
		if v1077 then
			continue
		end
		local v1079 = v_u_15.missing
		local v1080 = v1075.kind
		local v1081 = "effect " .. tostring(v1080) .. ": " .. tostring(v1078)
		table.insert(v1079, v1081)
	end
	v_u_1001(v_u_1044.hideDoors)
	v_u_1021(v_u_1044.hideModels)
	local v1082 = p1042.holdRadius
	local v1083 = tonumber(v1082)
	local v_u_1084 = (not v1083 or v1083 ~= v1083) and 140 or v1083
	v_u_8.extracts(p_u_1043.Position, v_u_1084)
	v_u_988(v_u_1044.grade)
	local v1085 = v_u_1044.warmup
	local v1086 = tonumber(v1085)
	local v1087 = (not v1086 or v1086 ~= v1086) and 3 or v1086
	if v_u_1044.freezeFx ~= false then
		task.delay(v1087, function()
			-- upvalues: (copy) v_u_1045, (ref) v_u_15, (ref) v_u_10
			if v_u_1045 == v_u_15.token then
				v_u_10.setFxFrozen(true)
			end
		end)
	end
	task.delay(v1087, function()
		-- upvalues: (copy) v_u_1045, (ref) v_u_15, (ref) v_u_1001, (copy) v_u_1044, (ref) v_u_1021, (ref) v_u_8, (copy) p_u_1043, (copy) v_u_1084
		if v_u_1045 == v_u_15.token then
			v_u_1001(v_u_1044.hideDoors)
			v_u_1021(v_u_1044.hideModels)
			v_u_8.extracts(p_u_1043.Position, v_u_1084)
		end
	end)
	v_u_22()
	local v1088 = #v_u_15.actorList
	local v1089 = p1042.title
	local v1090 = ("%s: %d actor(s), %d zombies, %d effects%s"):format(tostring(v1089), v1088, #v_u_15.zombies, v_u_15.effects, #v_u_15.missing <= 0 and "" or " (missing: " .. table.concat(v_u_15.missing, "; ") .. ")")
	if #v_u_15.missing > 0 then
		warn("[FilmPhoto]", v1090)
	end
	return true, v1090
end
function v_u_10.cameraOf() -- name: cameraOf
	-- upvalues: (copy) v_u_15, (copy) v_u_32, (copy) v_u_14
	local v1091 = v_u_15.scene
	if v1091 then
		v1091 = v_u_15.scene.photo
	end
	if not (v1091 and v_u_15.anchor) then
		return nil
	end
	local v1092 = v1091.camera or {}
	local v1093 = v1092.at or { 10, 0, 3 }
	local v1094 = v_u_15.anchor
	local v1095, v1096, v1097 = v_u_32(v1093)
	local v1098 = v1094.Position + v1094.LookVector * v1095 + v1094.RightVector * v1096
	local v1099 = v_u_14(v1098.X, v_u_15.ground, v1098.Z) + v_u_14(0, v1097, 0)
	local v1100 = nil
	local v1101 = v1092.focus
	if type(v1101) == "string" and v_u_15.actors[v1092.focus] then
		local v1102 = v_u_15.actors[v1092.focus]
		local v1103 = v1102.model:FindFirstChild("Head")
		if v1103 then
			v1100 = v1103.Position
		else
			v1100 = v1102.pos + Vector3.new(0, 4, 0)
		end
	else
		local v1104 = v1092.focus
		if type(v1104) == "table" then
			local v1105 = v1092.focus
			local v1106 = v_u_15.anchor
			local v1107, v1108, v1109 = v_u_32(v1105)
			local v1110 = v1106.Position + v1106.LookVector * v1107 + v1106.RightVector * v1108
			v1100 = v_u_14(v1110.X, v_u_15.ground, v1110.Z) + v_u_14(0, v1109, 0)
		end
	end
	local v1111
	if v1092.lookAt then
		local v1112 = v1092.lookAt
		local v1113 = v_u_15.anchor
		local v1114, v1115, v1116 = v_u_32(v1112)
		local v1117 = v1113.Position + v1113.LookVector * v1114 + v1113.RightVector * v1115
		v1111 = v_u_14(v1117.X, v_u_15.ground, v1117.Z) + v_u_14(0, v1116, 0)
	else
		v1111 = v1100 or v_u_15.anchor.Position + Vector3.new(0, 3, 0)
	end
	local v1118 = {
		["cf"] = CFrame.lookAt(v1099, v1111)
	}
	local v1119 = v1092.fov
	local v1120 = tonumber(v1119)
	v1118.fov = (not v1120 or v1120 ~= v1120) and 45 or v1120
	local v1121 = v1092.roll
	local v1122 = tonumber(v1121)
	v1118.roll = (not v1122 or v1122 ~= v1122) and 0 or v1122
	v1118.focus = v1100
	local v1123
	if v1092.dof == nil then
		v1123 = nil
	else
		local v1124 = v1092.dof
		local v1125 = tonumber(v1124)
		v1123 = (not v1125 or v1125 ~= v1125) and 0.5 or v1125
	end
	v1118.dof = v1123
	v1118.frame = v1091.frame or "16:9"
	v1118.logo = v1091.logo
	v1118.thirds = v1091.thirds ~= false
	return v1118
end
function v_u_10.stats() -- name: stats
	-- upvalues: (copy) v_u_15
	local v1126 = 0
	for _ in v_u_15.actors do
		v1126 = v1126 + 1
	end
	return {
		["id"] = v_u_15.id,
		["actors"] = v1126,
		["zombies"] = #v_u_15.zombies,
		["effects"] = v_u_15.effects,
		["emitters"] = #v_u_15.emitters,
		["lights"] = v_u_15.lights,
		["faces"] = v_u_15.faces,
		["plainHats"] = v_u_15.plainHats,
		["frozen"] = v_u_15.frozen,
		["missing"] = v_u_15.missing
	}
end
return v_u_10