-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MapToggleBar

return {
	["build"] = function(p_u_1) -- name: build
		local v_u_2 = p_u_1.UI
		local v3 = p_u_1.Theme
		local v_u_4 = p_u_1.Rule
		local v_u_5 = v3.color
		local v6 = p_u_1.device == "Touch"
		local v7
		if p_u_1.device == "Touch" then
			v7 = false
		else
			v7 = p_u_1.device ~= "Gamepad"
		end
		local v8 = v_u_4.barLayout(v6, p_u_1.phone == true, v3.uiScale(), p_u_1.width, v7)
		local v9 = v3.uiScale()
		local v10 = 10.5 / math.max(v9, 0.3)
		local v11 = math.ceil(v10)
		local v12 = not v3.phoneText and 13 or v3.phoneText(13, "text")
		local v13 = math.max(v12, v11)
		local v14 = not v3.phoneText and 12 or v3.phoneText(12, "text")
		local v15 = v11 - 1
		local v16 = math.max(v14, v15)
		local v17 = v8.h
		local v18
		if v8.twoLine then
			v18 = v13 + v16 + 12
		else
			v18 = v13 + 14
		end
		v8.h = math.max(v17, v18)
		local v_u_19 = v_u_2.new("Frame", {
			["Name"] = "MapToggleBar",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Position"] = p_u_1.position or UDim2.fromOffset(0, 0),
			["Size"] = UDim2.fromOffset(p_u_1.width, v8.h)
		}, p_u_1.parent)
		local v_u_20 = {}
		local v21 = {}
		for v22, v_u_23 in { "tasks", "labels" } do
			local v24 = (v22 - 1) * (v8.w + v8.gap)
			local v_u_25 = v_u_2.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["Selectable"] = true,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 6,
				["Name"] = v_u_23 == "tasks" and "Toggle_Tasks" or "Toggle_Labels",
				["BackgroundColor3"] = v_u_5.raised,
				["Position"] = UDim2.fromOffset(v24, 0),
				["Size"] = UDim2.fromOffset(v8.w, v8.h)
			}, v_u_19)
			v_u_25:SetAttribute("Which", v_u_23)
			local v_u_26 = v_u_2.stroke(v_u_25, v_u_5.line, 1)
			local v_u_27 = v_u_2.new("Frame", {
				["Name"] = "Lamp",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 7,
				["BackgroundColor3"] = v_u_5.accent,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v_u_25)
			local v28 = v7 and 26 or 0
			local v_u_29, v_u_30
			if v8.twoLine then
				local v31 = v_u_2.label
				local v32 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = "",
					["style"] = "caps",
					["textSize"] = nil,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_25,
					["textSize"] = v13,
					["color"] = v_u_5.text
				}
				local v33 = UDim2.fromOffset
				local v34 = v8.h * 0.5
				v32.position = v33(12, math.floor(v34) - v13 - 1)
				v32.size = UDim2.new(1, -(v28 + 12 + 4), 0, v13 + 2)
				v_u_29 = v31(v32)
				local v35 = v_u_2.label
				local v36 = {
					["parent"] = nil,
					["name"] = "State",
					["text"] = "",
					["style"] = "monoS",
					["textSize"] = nil,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_25,
					["textSize"] = v16,
					["color"] = v_u_5.muted
				}
				local v37 = UDim2.fromOffset
				local v38 = v8.h * 0.5
				v36.position = v37(12, math.floor(v38) + 1)
				v36.size = UDim2.new(1, -(v28 + 12 + 4), 0, v16 + 2)
				v_u_30 = v35(v36)
			else
				local v39 = v_u_2.label
				local v40 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = "",
					["style"] = "caps",
					["textSize"] = nil,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_25,
					["textSize"] = v13,
					["color"] = v_u_5.text
				}
				local v41 = UDim2.fromOffset
				local v42 = (v8.h - v13 - 2) / 2
				v40.position = v41(12, (math.floor(v42)))
				v40.size = UDim2.new(1, -(v28 + 12 + 52), 0, v13 + 2)
				v_u_29 = v39(v40)
				local v43 = v_u_2.label
				local v44 = {
					["parent"] = nil,
					["name"] = "State",
					["text"] = "",
					["style"] = "monoS",
					["textSize"] = nil,
					["color"] = nil,
					["align"] = "right",
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_25,
					["textSize"] = v16,
					["color"] = v_u_5.muted,
					["anchor"] = Vector2.new(1, 0)
				}
				local v45 = UDim2.new
				local v46 = -(v28 + 10)
				local v47 = (v8.h - v16 - 2) / 2
				v44.position = v45(1, v46, 0, (math.floor(v47)))
				v44.size = UDim2.fromOffset(40, v16 + 2)
				v_u_30 = v43(v44)
			end
			if v7 then
				local v48 = v_u_2.new("Frame", {
					["Name"] = "KeyChip",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 8,
					["BackgroundColor3"] = v_u_5.raised2,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -5, 0.5, 0),
					["Size"] = UDim2.fromOffset(20, 20)
				}, v_u_25)
				v_u_2.stroke(v48, v_u_5.lineStrong, 1)
				v_u_2.new("TextLabel", {
					["Name"] = "Key",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 12,
					["TextColor3"] = nil,
					["Text"] = nil,
					["ZIndex"] = 9,
					["Size"] = UDim2.fromScale(1, 1),
					["FontFace"] = v3.font.monoBold,
					["TextColor3"] = v_u_5.text,
					["Text"] = v_u_4.keys[v_u_23]
				}, v48)
			end
			local v_u_49 = false
			local function v_u_63() -- name: paint
				-- upvalues: (copy) p_u_1, (copy) v_u_23, (copy) v_u_4, (ref) v_u_29, (ref) v_u_30, (copy) v_u_5, (copy) v_u_27, (copy) v_u_26, (ref) v_u_49, (copy) v_u_25
				local v50 = p_u_1.get(v_u_23) == true
				local v51, v52 = v_u_4.texts(v_u_23, v50)
				v_u_29.Text = v51
				v_u_30.Text = v52
				local v53 = v_u_30
				local v54
				if v50 then
					v54 = v_u_5.accent
				else
					v54 = v_u_5.muted
				end
				v53.TextColor3 = v54
				local v55 = v_u_29
				local v56
				if v50 then
					v56 = v_u_5.text
				else
					v56 = v_u_5.text2
				end
				v55.TextColor3 = v56
				local v57 = v_u_27
				local v58
				if v50 then
					v58 = v_u_5.accent
				else
					v58 = v_u_5.line
				end
				v57.BackgroundColor3 = v58
				local v59 = v_u_26
				local v60
				if v50 then
					v60 = v_u_5.accent
				elseif v_u_49 then
					v60 = v_u_5.lineStrong
				else
					v60 = v_u_5.line
				end
				v59.Color = v60
				v_u_26.Thickness = v50 and 1.5 or 1
				local v61 = v_u_25
				local v62
				if v_u_49 then
					v62 = v_u_5.raised2
				else
					v62 = v_u_5.raised
				end
				v61.BackgroundColor3 = v62
				v_u_25.BackgroundTransparency = v50 and 0.1 or 0.35
				v_u_25:SetAttribute("On", v50)
			end
			v_u_20[v_u_23] = v_u_63
			v_u_25.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_49, (copy) v_u_63
				v_u_49 = true
				v_u_63()
			end)
			v_u_25.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_49, (copy) v_u_63
				v_u_49 = false
				v_u_63()
			end)
			v_u_25.SelectionImageObject = v_u_2.selectionImage()
			v_u_25.SelectionGained:Connect(function()
				-- upvalues: (ref) v_u_49, (copy) v_u_63
				v_u_49 = true
				v_u_63()
			end)
			v_u_25.SelectionLost:Connect(function()
				-- upvalues: (ref) v_u_49, (copy) v_u_63
				v_u_49 = false
				v_u_63()
			end)
			v_u_25.Activated:Connect(function()
				-- upvalues: (copy) v_u_2, (copy) p_u_1, (copy) v_u_23
				v_u_2.sound("click")
				p_u_1.press(v_u_23)
			end)
			v21[v_u_23] = v_u_25
			v_u_63()
		end
		return {
			["frame"] = v_u_19,
			["height"] = v8.h,
			["layout"] = v8,
			["buttons"] = v21,
			["refresh"] = function() -- name: refresh
				-- upvalues: (copy) v_u_19, (copy) v_u_20
				if v_u_19.Parent then
					for _, v64 in v_u_20 do
						v64()
					end
				end
			end
		}
	end
}