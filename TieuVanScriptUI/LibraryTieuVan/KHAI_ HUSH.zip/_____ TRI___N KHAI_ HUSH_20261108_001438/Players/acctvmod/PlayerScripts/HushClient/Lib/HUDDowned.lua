-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDDowned

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
return {
	["new"] = function(p_u_2) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_3 = p_u_2.UI
		local v_u_4 = p_u_2.Theme
		local v_u_5 = v_u_4.color
		local v_u_6 = {}
		local v_u_7 = nil
		local v_u_8 = false
		local v_u_9 = 0
		local v_u_10 = 30
		local v_u_11 = nil
		local function v_u_14() -- name: colorCorrection
			-- upvalues: (ref) v_u_11, (copy) v_u_3
			local v12 = workspace.CurrentCamera
			if not v12 then
				return nil
			end
			if v_u_11 and v_u_11.Parent == v12 then
				return v_u_11
			end
			local v13 = v12:FindFirstChild("HushDowned")
			if v13 and v13:IsA("ColorCorrectionEffect") then
				v_u_11 = v13
			else
				v_u_11 = v_u_3.new("ColorCorrectionEffect", {
					["Name"] = "HushDowned",
					["Saturation"] = 0,
					["Contrast"] = 0,
					["Brightness"] = 0,
					["TintColor"] = nil,
					["TintColor"] = Color3.new(1, 1, 1)
				}, v12)
			end
			return v_u_11
		end
		local v_u_15 = 0.3
		local v_u_16 = nil
		local v_u_17 = 360
		local v_u_18 = 18
		local v_u_19 = v_u_3.new("Frame", {
			["Name"] = "Downed",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 6,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.3),
			["Size"] = UDim2.fromOffset(420, 260)
		}, p_u_2.fx)
		local v_u_20 = v_u_3.label({
			["parent"] = nil,
			["text"] = "Downed",
			["style"] = "h1",
			["textSize"] = 44,
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_19,
			["color"] = v_u_5.danger,
			["size"] = UDim2.new(1, 0, 0, 52)
		})
		local v_u_21 = v_u_3.label({
			["parent"] = nil,
			["text"] = "Bleeding out",
			["style"] = "body",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["position"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_19,
			["color"] = v_u_5.text2,
			["size"] = UDim2.new(1, 0, 0, 18),
			["position"] = UDim2.fromOffset(0, 54)
		})
		local v_u_22 = v_u_3.label({
			["parent"] = nil,
			["text"] = "30",
			["style"] = "monoL",
			["textSize"] = 30,
			["align"] = "center",
			["size"] = nil,
			["position"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_19,
			["size"] = UDim2.new(1, 0, 0, 34),
			["position"] = UDim2.fromOffset(0, 78)
		})
		local v_u_23 = v_u_3.progress({
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["value"] = 1,
			["color"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_19,
			["size"] = UDim2.fromOffset(280, 3),
			["position"] = UDim2.new(0.5, 0, 0, 120),
			["anchor"] = Vector2.new(0.5, 0),
			["color"] = v_u_5.danger
		})
		local v_u_24 = v_u_3.new("Frame", {
			["Name"] = "Squad",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["Position"] = UDim2.fromOffset(0, 138),
			["Size"] = UDim2.new(1, 0, 0, 110)
		}, v_u_19)
		v_u_3.layout(v_u_24, "v", 4, "center")
		local v_u_25 = {}
		local function v_u_31(p26) -- name: setRows
			-- upvalues: (copy) v_u_25, (copy) v_u_3, (copy) v_u_24, (ref) v_u_17, (ref) v_u_18
			for v27, v28 in p26 do
				local v29 = v_u_25[v27]
				if not v29 then
					v29 = v_u_3.label({
						["parent"] = nil,
						["text"] = "",
						["style"] = "small",
						["align"] = "center",
						["size"] = nil,
						["order"] = nil,
						["zindex"] = 6,
						["parent"] = v_u_24,
						["size"] = UDim2.fromOffset(v_u_17, v_u_18),
						["order"] = v27
					})
					v_u_25[v27] = v29
				end
				v29.Visible = true
				v29.Text = v28.text
				v29.TextColor3 = v28.color
			end
			for v30 = #p26 + 1, #v_u_25 do
				v_u_25[v30].Visible = false
			end
		end
		local function v_u_45(p32) -- name: setDowned
			-- upvalues: (ref) v_u_8, (copy) v_u_14, (ref) v_u_9, (ref) v_u_1, (ref) v_u_7, (ref) v_u_10, (copy) v_u_19, (ref) v_u_16, (ref) v_u_15, (copy) v_u_3
			if p32 ~= v_u_8 then
				v_u_8 = p32
				local v33 = v_u_14()
				if p32 then
					v_u_9 = v_u_1.now()
					local v34 = v_u_7
					local v35
					if v34 then
						local v36 = v34:GetAttribute("DownedUntil")
						v35 = v_u_9 + 30
						if type(v36) == "number" then
							v35 = v36
						end
					else
						v35 = v_u_9 + 30
					end
					local v37 = v35 - v_u_9
					v_u_10 = math.max(1, v37)
					v_u_19.Visible = true
					local v38 = v_u_19
					local v39
					if v_u_16 then
						v39 = UDim2.fromOffset(v_u_16.x, v_u_16.y)
					else
						v39 = UDim2.fromScale(0.5, v_u_15)
					end
					v38.Position = v39 + UDim2.fromOffset(0, 8)
					v_u_3.fade(v_u_19, 0, "slower", {
						["from"] = v_u_3.fadeAlpha(v_u_19) <= 0 and 1 or nil
					})
					local v40 = v_u_3.tween
					local v41 = v_u_19
					local v42 = {}
					local v43
					if v_u_16 then
						v43 = UDim2.fromOffset(v_u_16.x, v_u_16.y)
					else
						v43 = UDim2.fromScale(0.5, v_u_15)
					end
					v42.Position = v43
					v40(v41, v42, "slower")
					if v33 then
						v_u_3.tween(v33, {
							["Saturation"] = -0.9,
							["Contrast"] = 0.18,
							["Brightness"] = -0.02,
							["TintColor"] = nil,
							["TintColor"] = Color3.fromRGB(255, 232, 228)
						}, 0.8)
						return
					end
				else
					local v44 = {
						["onDone"] = function() -- name: onDone
							-- upvalues: (ref) v_u_8, (ref) v_u_19
							if not v_u_8 then
								v_u_19.Visible = false
							end
						end
					}
					v_u_3.fade(v_u_19, 1, "slow", v44)
					if v33 then
						v_u_3.tween(v33, {
							["Saturation"] = 0,
							["Contrast"] = 0,
							["Brightness"] = 0,
							["TintColor"] = nil,
							["TintColor"] = Color3.new(1, 1, 1)
						}, 0.6)
					end
				end
			end
		end
		function v_u_6.setCharacter(p46) -- name: setCharacter
			-- upvalues: (ref) v_u_7, (copy) v_u_45
			v_u_7 = p46
			if not p46 then
				v_u_45(false)
			end
		end
		function v_u_6.layout(p47) -- name: layout
			-- upvalues: (ref) v_u_15, (copy) p_u_2, (copy) v_u_3, (ref) v_u_16, (copy) v_u_19, (copy) v_u_23, (ref) v_u_17, (copy) v_u_20, (copy) v_u_4, (copy) v_u_21, (copy) v_u_22, (copy) v_u_24, (ref) v_u_18, (copy) v_u_25
			v_u_15 = p47 and 0.44 or 0.3
			local v48
			if p47 then
				local v49 = p_u_2.centerColumn
				if type(v49) == "function" then
					v48 = p_u_2.centerColumn(true)
				else
					v48 = nil
				end
			else
				v48 = nil
			end
			if v48 then
				local v50 = v_u_3.safeInsets()
				local v51 = {}
				local v52 = v48.cx + v50.l
				v51.x = math.floor(v52)
				local v53 = v48.top + v50.t
				v51.y = math.floor(v53)
				local v54 = v48.w
				v51.w = math.floor(v54)
				v_u_16 = v51
				v_u_19.AnchorPoint = Vector2.new(0.5, 0)
				v_u_19.Size = UDim2.fromOffset(v_u_16.w, 260)
				local v55 = v_u_23.frame
				local v56 = UDim2.fromOffset
				local v57 = v_u_16.w - 20
				v55.Size = v56(math.min(280, v57), 3)
				v_u_17 = v_u_16.w
				v_u_20.TextSize = v_u_4.phoneText(32, "text")
				v_u_20.Size = UDim2.new(1, 0, 0, 38)
				v_u_21.Position = UDim2.fromOffset(0, 38)
				v_u_22.TextSize = v_u_4.phoneText(26, "text")
				v_u_22.Size = UDim2.new(1, 0, 0, 30)
				v_u_22.Position = UDim2.fromOffset(0, 58)
				v_u_23.frame.Position = UDim2.new(0.5, 0, 0, 92)
				v_u_24.Position = UDim2.fromOffset(0, 102)
				v_u_18 = 16
			else
				v_u_16 = nil
				v_u_19.AnchorPoint = Vector2.new(0.5, 0.5)
				v_u_19.Size = UDim2.fromOffset(420, 260)
				v_u_23.frame.Size = UDim2.fromOffset(280, 3)
				v_u_17 = 360
				v_u_20.TextSize = 44
				v_u_20.Size = UDim2.new(1, 0, 0, 52)
				v_u_21.Position = UDim2.fromOffset(0, 54)
				v_u_22.TextSize = 30
				v_u_22.Size = UDim2.new(1, 0, 0, 34)
				v_u_22.Position = UDim2.fromOffset(0, 78)
				v_u_23.frame.Position = UDim2.new(0.5, 0, 0, 120)
				v_u_24.Position = UDim2.fromOffset(0, 138)
				v_u_18 = 18
			end
			for _, v58 in v_u_25 do
				v58.Size = UDim2.fromOffset(v_u_17, v_u_18)
			end
			local v59 = v_u_19
			local v60
			if v_u_16 then
				v60 = UDim2.fromOffset(v_u_16.x, v_u_16.y)
			else
				v60 = UDim2.fromScale(0.5, v_u_15)
			end
			v59.Position = v60
		end
		function v_u_6.rect() -- name: rect
			-- upvalues: (copy) v_u_6, (copy) v_u_19, (copy) v_u_4
			local v61 = v_u_6.height()
			if v61 <= 0 then
				return nil, nil
			end
			local v62 = v_u_19.AbsolutePosition
			local v63 = Vector2.new
			local v64 = v_u_19.AbsoluteSize.X
			local v65 = v_u_4.uiScale
			return v62, v63(v64, v61 * math.max(0.01, v65()))
		end
		function v_u_6.height() -- name: height
			-- upvalues: (ref) v_u_16, (copy) v_u_19, (copy) v_u_25, (ref) v_u_18
			if not (v_u_16 and v_u_19.Visible) then
				return 0
			end
			local v66 = 0
			for _, v67 in v_u_25 do
				if not v67.Visible then
					continue
				end
				v66 = v66 + 1
			end
			return v66 * (v_u_18 + 4) + 102 + 4
		end
		local v_u_68 = 0
		local v_u_69 = 0
		function v_u_6.update(p70) -- name: update
			-- upvalues: (ref) v_u_69, (ref) v_u_7, (copy) v_u_45, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (copy) v_u_22, (copy) v_u_23, (copy) v_u_20, (copy) v_u_5, (ref) v_u_68, (copy) v_u_3, (copy) v_u_21, (copy) v_u_31
			v_u_69 = v_u_69 + p70
			local v71 = v_u_7
			local v72
			if v71 == nil or (v71.Parent == nil or v71:GetAttribute("Downed") ~= true) then
				v72 = false
			else
				v72 = v71:GetAttribute("Dead") ~= true
			end
			v_u_45(v72)
			if v72 and v71 then
				local v73 = v_u_1.now()
				local v74 = v71:GetAttribute("DownedUntil")
				local v75 = v_u_9 + v_u_10
				if type(v74) == "number" then
					v75 = v74
				end
				local v76 = v75 - v73
				local v77 = math.max(0, v76)
				v_u_22.Text = string.format("%d", (math.ceil(v77)))
				local v78 = v_u_23.set
				local v79 = v77 / v_u_10
				v78(math.clamp(v79, 0, 1), true)
				local v80 = v_u_69 * 3.141592653589793 * 2 * (v77 < 10 and 1.8 or 1.1)
				local v81 = math.sin(v80) * 0.5 + 0.5
				v_u_20.TextColor3 = v_u_5.danger:Lerp(v_u_5.text, v81 * 0.2)
				v_u_68 = v_u_68 + p70
				if v_u_68 >= 0.2 then
					v_u_68 = 0
					local v82 = v71:FindFirstChild("HumanoidRootPart")
					local v83 = v71:GetAttribute("SquadId")
					local v84 = {}
					local v85 = game:GetService("Players")
					local v86 = v71:GetAttribute("RevivingBy")
					local v87
					if type(v86) == "number" and v86 ~= 0 then
						local v88 = v85:GetPlayerByUserId(v86)
						v87 = v88 and v88.Character or nil
					else
						v87 = nil
					end
					for _, v89 in v85:GetPlayers() do
						local v90 = v89.Character
						if not v90 or (v90 == v71 or not v90.Parent) then
							continue
						end
						local v91 = v90:FindFirstChild("HumanoidRootPart")
						local v92 = not (v91 and v82) and (1 / 0) or (v91.Position - v82.Position).Magnitude
						if not v87 and v90:GetAttribute("Action") == "Revive" then
							if v92 < 12 then
								v87 = v90
							end
						end
						local v93
						if v83 == nil or v83 == "" then
							v93 = false
						else
							v93 = v90:GetAttribute("SquadId") == v83
						end
						if not v93 then
							continue
						end
						local v94 = v90:GetAttribute("Dead") == true and "  \194\183  dead" or (v90:GetAttribute("Downed") == true and "  \194\183  downed" or "")
						local v95
						if v92 < (1 / 0) then
							local v96 = v92 * 0.28 + 0.5
							local v97 = math.floor(v96)
							v95 = tostring(v97) .. " m"
						else
							v95 = "?"
						end
						local v98 = {
							["text"] = v89.DisplayName .. "   " .. v95 .. v94
						}
						local v99
						if v94 == "" then
							v99 = v_u_5.text
						else
							v99 = v_u_5.muted
						end
						v98.color = v99
						table.insert(v84, v98)
					end
					if v87 then
						local v100 = v87:GetAttribute("ActionEndsAt")
						local v101 = type(v100) ~= "number" and 0 or v100
						v_u_3.setText(v_u_21, "Being helped up")
						v_u_21.TextColor3 = v_u_5.success
						if v73 < v101 then
							v_u_22.Text = string.format("%.1f", v101 - v73)
							v_u_22.TextColor3 = v_u_5.success
						end
					else
						v_u_3.setText(v_u_21, #v84 == 0 and "Nobody is coming. Crawl to cover." or "Bleeding out  \194\183  call for help")
						v_u_21.TextColor3 = v_u_5.text2
						local v102 = v_u_22
						local v103
						if v77 < 10 then
							v103 = v_u_5.danger
						else
							v103 = v_u_5.text
						end
						v102.TextColor3 = v103
					end
					v_u_31(v84)
				end
			else
				return
			end
		end
		function v_u_6.destroy() -- name: destroy
			-- upvalues: (copy) v_u_45, (copy) v_u_19, (ref) v_u_11, (ref) v_u_8
			v_u_45(false)
			v_u_19:Destroy()
			task.delay(0.7, function()
				-- upvalues: (ref) v_u_11, (ref) v_u_8
				if v_u_11 and not v_u_8 then
					v_u_11:Destroy()
					v_u_11 = nil
				end
			end)
		end
		return v_u_6
	end
}