-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / ZombieRender

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("PhysicsService")
local v4 = {
	["name"] = "ZombieRender",
	["order"] = 25
}
local v_u_5 = CFrame.new(0, -5000, 0)
local v_u_6 = {
	["walker"] = 5,
	["walker_2"] = 4,
	["walker_3"] = 4,
	["walker_4"] = 4,
	["walker_5"] = 4,
	["walker_6"] = 4,
	["runner"] = 3,
	["crawler"] = 3,
	["brute"] = 2,
	["listener"] = 2,
	["hazmat"] = 1,
	["ringer"] = 1,
	["riot"] = 1
}
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = {}
local v_u_12 = {
	["head"] = 1,
	["torso"] = 2,
	["arm"] = 3,
	["leg"] = 4
}
local v_u_13 = v_u_1.LocalPlayer
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = {
	["RYAW_RATE"] = 30
}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = nil
local v_u_22 = 0
local v_u_23 = false
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = 0
local v_u_27 = 0
local v_u_28 = 0
local function v_u_29() -- name: serverNow
	return workspace:GetServerTimeNow()
end
local function v_u_35(p30, p31, p32) -- name: audio
	-- upvalues: (ref) v_u_7
	local v33 = v_u_7
	if v33 then
		v33 = v_u_7.controllers.Audio
	end
	if v33 and v33.zombie then
		local v34 = v33.zombie
		pcall(v34, p30, p31, p32)
	end
end
local v_u_36 = {
	["boss_hale"] = true
}
local v_u_37 = {}
local function v_u_50() -- name: localRootPos
	-- upvalues: (ref) v_u_7, (copy) v_u_13
	local v38 = v_u_7
	if v38 then
		v38 = v_u_7.controllers.Camera
	end
	if v38 then
		local v39 = v38.mode
		if type(v39) == "function" then
			local v40 = v38.subject
			if type(v40) == "function" then
				local v41 = v38.mode
				local v42, v43 = pcall(v41)
				if v42 and v43 == "spectate" then
					local v44 = v38.subject
					local v45, v46 = pcall(v44)
					local v47 = v_u_13.Character
					if v45 and (typeof(v46) == "Instance" and (v46:IsA("BasePart") and (v46.Parent and not (v47 and v46:IsDescendantOf(v47))))) then
						return v46.Position, true
					end
				end
			end
		end
	end
	local v48 = v_u_13.Character
	if v48 then
		v48 = v48:FindFirstChild("HumanoidRootPart")
	end
	if v48 then
		return v48.Position, false
	end
	local v49 = workspace.CurrentCamera
	if v49 then
		v49 = v49.Focus.Position
	end
	return v49, false
end
local function v_u_53() -- name: ensureFolder
	-- upvalues: (ref) v_u_21
	if v_u_21 and v_u_21.Parent then
		return v_u_21
	end
	local v51 = workspace:FindFirstChild("HushLocal")
	if not v51 then
		v51 = Instance.new("Folder")
		v51.Name = "HushLocal"
		v51.Parent = workspace
	end
	local v52 = v51:FindFirstChild("Zombies")
	if not v52 then
		v52 = Instance.new("Folder")
		v52.Name = "Zombies"
		v52.Parent = v51
	end
	v_u_21 = v52
	return v52
end
local v_u_54 = {
	["block"] = nil,
	["names"] = "",
	["set"] = nil,
	["block"] = {},
	["set"] = {}
}
local function v_u_57(p55) -- name: serverTemplate
	-- upvalues: (copy) v_u_2
	local v56 = v_u_2:FindFirstChild("HushRuntime")
	if v56 then
		v56 = v56:FindFirstChild("ZombieTemplates")
	end
	if v56 then
		v56 = v56:FindFirstChild("Roblox")
	end
	if v56 then
		v56 = v56:FindFirstChild(p55)
	end
	if v56 and v56:IsA("Model") then
		if v56:GetAttribute("RigKind") == "block" then
			return v56, "block"
		else
			return v56, "catalog"
		end
	else
		return nil, "none"
	end
end
local function v_u_66(p_u_58) -- name: localBlock
	-- upvalues: (copy) v_u_54, (copy) v_u_2
	local v59 = v_u_54.block[p_u_58]
	if v59 then
		return v59
	end
	local function v63()
		-- upvalues: (ref) v_u_2, (copy) p_u_58
		local v60 = v_u_2.Hush.Shared.Fallbacks:FindFirstChild("Zombie")
		local v61
		if v60 and v60:IsA("ModuleScript") then
			v61 = require(v60)
		else
			v61 = nil
		end
		if type(v61) == "table" and v61.ROBLOX then
			local v62 = v61.ROBLOX.block
			if type(v62) == "function" then
				return v61.ROBLOX.block(p_u_58)
			end
		end
		return nil
	end
	local v64, v65 = pcall(v63)
	if not v64 or (typeof(v65) ~= "Instance" or not v65:IsA("Model")) then
		return nil
	end
	v_u_54.block[p_u_58] = v65
	return v65
end
local function v_u_78(p_u_67) -- name: hasTemplate
	-- upvalues: (copy) v_u_2, (copy) v_u_54
	local v68 = v_u_2:FindFirstChild("HushRuntime")
	if v68 then
		v68 = v68:FindFirstChild("ZombieTemplates")
	end
	if v68 then
		v68 = v68:FindFirstChild("Roblox")
	end
	local v69
	if v68 then
		v69 = v68:FindFirstChild(p_u_67)
	else
		v69 = v68
	end
	if v69 and v69:IsA("Model") then
		return true
	end
	if string.sub(p_u_67, 1, 6) == "risen_" or v68 and v68:GetAttribute("Ready") == true then
		return false
	end
	if v68 then
		v68 = v68:GetAttribute("Names")
	end
	if type(v68) == "string" and v68 ~= "" then
		if v_u_54.names ~= v68 then
			v_u_54.names = v68
			table.clear(v_u_54.set)
			for v70 in string.gmatch(v68, "[^,]+") do
				v_u_54.set[v70] = true
			end
		end
		return v_u_54.set[p_u_67] == true
	end
	local function v75()
		-- upvalues: (ref) v_u_2, (copy) p_u_67
		local v71 = v_u_2.Hush.Shared.Fallbacks:FindFirstChild("Zombie")
		local v72
		if v71 and v71:IsA("ModuleScript") then
			v72 = require(v71)
		else
			v72 = nil
		end
		local v73
		if type(v72) == "table" and v72.ROBLOX ~= nil then
			local v74 = v72.ROBLOX.known
			if type(v74) == "function" then
				v73 = v72.ROBLOX.known(p_u_67) == true
			else
				v73 = false
			end
		else
			v73 = false
		end
		return v73
	end
	local v76, v77 = pcall(v75)
	if v76 then
		v76 = v77 == true
	end
	return v76
end
local function v_u_91(p79) -- name: solvedCFrames
	local v80 = p79:FindFirstChild("HumanoidRootPart")
	local v81 = {}
	if not v80 then
		return v81
	end
	v81[v80] = v80.CFrame
	local v82 = {}
	for _, v83 in p79:GetDescendants() do
		if v83:IsA("Motor6D") and (v83.Part0 and v83.Part1) then
			local v84 = {
				["p0"] = v83.Part0,
				["p1"] = v83.Part1,
				["c0"] = v83.C0,
				["c1"] = v83.C1
			}
			table.insert(v82, v84)
		else
			if not (v83:IsA("AnimationConstraint") and (v83.Attachment0 and v83.Attachment1)) then
				continue
			end
			local v85 = v83.Attachment0.Parent
			local v86 = v83.Attachment1.Parent
			if not (v85 and (v86 and (v85:IsA("BasePart") and v86:IsA("BasePart")))) then
				continue
			end
			local v87 = {
				["p0"] = v85,
				["p1"] = v86,
				["c0"] = v83.Attachment0.CFrame,
				["c1"] = v83.Attachment1.CFrame
			}
			table.insert(v82, v87)
		end
	end
	for _ = 1, 20 do
		local v88 = false
		for _, v89 in v82 do
			local v90 = v81[v89.p0]
			if not v90 or v81[v89.p1] then
				continue
			end
			v81[v89.p1] = v90 * v89.c0 * v89.c1:Inverse()
			v88 = true
		end
		if v88 then
			break
		end
	end
	return v81
end
local function v_u_100(p92) -- name: measure
	-- upvalues: (copy) v_u_91
	local v93 = p92:FindFirstChild("HumanoidRootPart")
	if not v93 then
		return 3, 1
	end
	local v94 = v_u_91(p92)
	local v95 = (1 / 0)
	for _, v96 in {
		"LeftFoot",
		"RightFoot",
		"LeftLowerLeg",
		"RightLowerLeg"
	} do
		local v97 = p92:FindFirstChild(v96, true)
		if not v97 then
			continue
		end
		local v98 = (v94[v97] or v97.CFrame).Y - v97.Size.Y / 2
		v95 = math.min(v95, v98)
	end
	if v95 == (1 / 0) then
		return 3, 1
	end
	local v99 = v93.Position.Y - v95
	return v99, v99 / 3.1
end
local function v_u_108(p101) -- name: toMotors
	for _, v102 in p101:GetDescendants() do
		if not v102:IsA("AnimationConstraint") then
			continue
		end
		local v103 = v102.Attachment0
		local v104 = v102.Attachment1
		local v105
		if v103 then
			v105 = v103.Parent
		else
			v105 = v103
		end
		local v106
		if v104 then
			v106 = v104.Parent
		else
			v106 = v104
		end
		if v103 and (v104 and (v105 and (v106 and (v105:IsA("BasePart") and v106:IsA("BasePart"))))) then
			local v107 = Instance.new("Motor6D")
			v107.Name = v102.Name
			v107.Part0 = v105
			v107.Part1 = v106
			v107.C0 = v103.CFrame
			v107.C1 = v104.CFrame
			v107.Parent = v106
		end
		v102:Destroy()
	end
end
local function v_u_113(p109) -- name: stripDeadWeight
	local v110 = false
	for _, v111 in p109:GetDescendants() do
		if not v111:IsA("WrapLayer") then
			continue
		end
		v110 = true
	end
	for _, v112 in p109:GetDescendants() do
		if v112:IsA("BallSocketConstraint") or v112:IsA("NoCollisionConstraint") then
			v112:Destroy()
		elseif v112:IsA("Vector3Value") and (v112.Name == "OriginalSize" or v112.Name == "OriginalPosition") then
			v112:Destroy()
		elseif v112:IsA("StringValue") and v112.Name == "AvatarPartScaleType" then
			v112:Destroy()
		else
			if not v112:IsA("WrapTarget") or v110 then
				continue
			end
			v112:Destroy()
		end
	end
end
local v_u_114 = {
	["Head"] = true,
	["UpperTorso"] = true,
	["LowerTorso"] = true,
	["LeftUpperArm"] = true,
	["LeftLowerArm"] = true,
	["LeftHand"] = true,
	["RightUpperArm"] = true,
	["RightLowerArm"] = true,
	["RightHand"] = true,
	["LeftUpperLeg"] = true,
	["LeftLowerLeg"] = true,
	["LeftFoot"] = true,
	["RightUpperLeg"] = true,
	["RightLowerLeg"] = true,
	["RightFoot"] = true
}
local v_u_115 = {
	["catalog"] = 0,
	["block"] = 0,
	["own"] = 0
}
local v_u_116 = {}
local function v_u_129(p117, p118) -- name: noteRigSource
	-- upvalues: (copy) v_u_115, (copy) v_u_13, (copy) v_u_116, (copy) v_u_2
	local v119 = p118 == "local" and "own" or p118
	v_u_115[v119] = (v_u_115[v119] or 0) + 1
	local function v120()
		-- upvalues: (ref) v_u_13, (ref) v_u_115
		v_u_13:SetAttribute("ZombieRigSource", string.format("catalog=%d block=%d local=%d", v_u_115.catalog, v_u_115.block, v_u_115.own))
	end
	pcall(v120)
	if p118 == "local" and not v_u_116[p117] then
		v_u_116[p117] = true
		local v121 = v_u_2:FindFirstChild("HushRuntime")
		if v121 then
			v121 = v121:FindFirstChild("ZombieTemplates")
		end
		if v121 then
			v121 = v121:FindFirstChild("Roblox")
		end
		local v122 = warn
		local v123 = string.format
		local v124 = "[ZombieRender] local block stand-in for %s: Roblox set %s, ready=%s, models=%s"
		local v125 = v121 and "present" or "MISSING"
		local v126
		if v121 then
			v126 = v121:GetAttribute("Ready")
		else
			v126 = v121
		end
		local v127 = tostring(v126)
		local v128 = v121 and #v121:GetChildren() or v121
		v122(v123(v124, p117, v125, v127, (tostring(v128))))
	end
end
local function v_u_160(p130, p131) -- name: newRig
	-- upvalues: (copy) v_u_57, (copy) v_u_66, (copy) v_u_129, (copy) v_u_108, (copy) v_u_113, (copy) v_u_20, (copy) v_u_100, (ref) v_u_8, (copy) v_u_3, (copy) v_u_16, (copy) v_u_114, (copy) v_u_5, (copy) v_u_53, (ref) v_u_22, (ref) v_u_9
	local v132, v133 = v_u_57(p130)
	if not v132 then
		v132 = v_u_66(p130)
		if v132 then
			v133 = "local"
		else
			v132 = nil
			v133 = "none"
		end
	end
	if not (v132 and v132:IsA("Model")) then
		return nil
	end
	v_u_129(p130, v133)
	local v_u_134 = v132:Clone()
	v_u_108(v_u_134)
	v_u_113(v_u_134)
	local v135 = v_u_134:FindFirstChild("HumanoidRootPart")
	if not v135 then
		v_u_134:Destroy()
		return nil
	end
	local v136 = v_u_20[p130 .. v133]
	if not v136 then
		local v137, v138 = v_u_100(v132)
		v136 = {
			["rootHeight"] = v137,
			["scale"] = v138
		}
		v_u_20[p130 .. v133] = v136
	end
	local v139 = p131 or 0
	local v140
	if v139 == 0 or (string.find(p130, "^boss") or string.find(p130, "^risen")) then
		v140 = 1
		v139 = 0
	else
		local v_u_141 = 1 + v139 * (v_u_8.HEIGHT_JITTER or 0.03)
		local function v142()
			-- upvalues: (copy) v_u_134, (ref) v_u_141
			v_u_134:ScaleTo(v_u_134:GetScale() * v_u_141)
		end
		pcall(v142)
		v140 = v_u_141
	end
	local v143 = false
	for _, v144 in v_u_134:GetDescendants() do
		if not (v144:IsA("Clothing") or (v144:IsA("ShirtGraphic") or v144:IsA("WrapLayer"))) then
			continue
		end
		v143 = true
	end
	local v_u_145 = false
	local function v146()
		-- upvalues: (ref) v_u_145, (ref) v_u_3
		v_u_145 = v_u_3:IsCollisionGroupRegistered("HushZombieRig")
	end
	pcall(v146)
	local v147 = nil
	local v148 = v_u_16.Halloween
	local v149
	if v148 and v148.wanted(p130) then
		local v150 = v148.dress
		local v151
		v151, v149 = pcall(v150, v_u_134, p130)
		if v151 then
			if typeof(v149) ~= "Instance" then
				v149 = v147
			end
		else
			v149 = v147
		end
	else
		v149 = v147
	end
	local v152 = v_u_145
	local v153 = {}
	for _, v_u_154 in v_u_134:GetDescendants() do
		if v_u_154:IsA("BasePart") then
			if v152 then
				v_u_154.CollisionGroup = "HushZombieRig"
			end
			v_u_154.CanCollide = false
			v_u_154.CanQuery = false
			v_u_154.CanTouch = false
			v_u_154.Anchored = v_u_154 == v135
			if v_u_154 == v135 then
				continue
			end
			table.insert(v153, v_u_154)
		elseif v_u_154:IsA("Humanoid") then
			if v143 and v152 then
				v_u_154.AutomaticScalingEnabled = false
				v_u_154.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
				v_u_154.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
				v_u_154.BreakJointsOnDeath = false
				v_u_154.RequiresNeck = false
				pcall(function()
					-- upvalues: (copy) v_u_154
					v_u_154.EvaluateStateMachine = false
				end)
			else
				v_u_154:Destroy()
			end
		else
			if not (v_u_154:IsA("Script") or (v_u_154:IsA("LocalScript") or v_u_154:IsA("Animator"))) then
				continue
			end
			v_u_154:Destroy()
		end
	end
	v135.Transparency = 1
	local v155 = {}
	local v156 = nil
	for _, v157 in v153 do
		if not v_u_114[v157.Name] or v157.Parent ~= v_u_134 then
			continue
		end
		v155[v157] = v157.Color
		if v157.CastShadow then
			continue
		end
		v156 = v156 == nil and {} or v156
		v156[v157] = true
	end
	v_u_134:PivotTo(v_u_5 * v135.CFrame:Inverse() * v_u_134:GetPivot())
	v_u_134.Parent = v_u_53()
	v_u_22 = v_u_22 + 1
	local v158 = v_u_134:FindFirstChild("Muzzle", true)
	local v159 = {
		["name"] = nil,
		["model"] = nil,
		["root"] = nil,
		["parts"] = nil,
		["pose"] = nil,
		["rootHeight"] = nil,
		["scale"] = nil,
		["vis"] = -1,
		["source"] = nil,
		["muzzle"] = nil,
		["bucket"] = nil,
		["base"] = nil,
		["tint"] = -1,
		["px"] = (1 / 0),
		["py"] = 0,
		["pz"] = 0,
		["pyaw"] = 0,
		["pumpkin"] = nil,
		["noShadow"] = nil,
		["name"] = p130,
		["model"] = v_u_134,
		["root"] = v135,
		["parts"] = v153,
		["pose"] = v_u_9.new(v_u_134, v136.rootHeight * v140, v136.scale * v140),
		["rootHeight"] = v136.rootHeight * v140,
		["scale"] = v136.scale * v140,
		["source"] = v133
	}
	if not (v158 and v158:IsA("Attachment")) then
		v158 = nil
	end
	v159.muzzle = v158
	v159.bucket = v139
	v159.base = v155
	v159.pumpkin = v149
	v159.noShadow = v156
	return v159
end
local function v_u_164(p161) -- name: risenUserOf
	-- upvalues: (copy) v_u_2
	if p161.risenUser ~= 0 then
		return p161.risenUser
	end
	local v162 = v_u_2:FindFirstChild("HushRuntime")
	if v162 then
		v162 = v162:FindFirstChild("ZombieTemplates")
	end
	if v162 then
		v162 = v162:FindFirstChild("Roblox")
	end
	if v162 then
		local v163 = p161.id
		v162 = v162:GetAttribute("RisenOf_" .. tostring(v163))
	end
	if type(v162) ~= "number" or v162 == 0 then
		return 0
	end
	p161.risenUser = v162
	return v162
end
local v_u_165 = {
	["at"] = -1000000000,
	["row"] = nil,
	["walkers"] = nil
}
local function v_u_169() -- name: mapRefresh
	-- upvalues: (copy) v_u_165, (copy) v_u_2, (ref) v_u_8
	local v166 = os.clock()
	if v166 - v_u_165.at > 0.5 then
		v_u_165.at = v166
		v_u_165.row = nil
		v_u_165.walkers = nil
		local v167 = v_u_2:FindFirstChild("HushRuntime")
		if v167 then
			v167 = v167:FindFirstChild("Raid")
		end
		if v167 then
			v167 = v167:GetAttribute("Map")
		end
		if type(v167) == "string" then
			local v168 = string.lower(v167)
			if v_u_8.LOOK_BY_MAP then
				v_u_165.row = v_u_8.LOOK_BY_MAP[v168]
			end
			if v_u_8.WALKER_LOOKS_BY_MAP then
				v_u_165.walkers = v_u_8.WALKER_LOOKS_BY_MAP[v168]
			end
		end
	end
end
function v_u_165.pick(p170) -- name: pick
	-- upvalues: (ref) v_u_8, (copy) v_u_169, (copy) v_u_165
	if v_u_8.LOOK_BY_MAP and p170.def then
		v_u_169()
		local v171 = v_u_165.row
		if v171 then
			return v171[p170.def.id]
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_165.variant(p172, p173, p174) -- name: variant
	-- upvalues: (ref) v_u_8, (copy) v_u_78
	local v175
	if v_u_8.variantsOf then
		v175 = v_u_8.variantsOf(p173)
	else
		v175 = nil
	end
	if not v175 then
		return p173
	end
	local v176 = #v175
	local v177 = v_u_8.variantIndex(p172.id, v176, p174)
	for _ = 1, v176 do
		local v178 = v175[v177]
		if v178 == p173 or v_u_78(v178) then
			return v178
		end
		v177 = v177 % v176 + 1
	end
	return p173
end
local function v_u_188(p179) -- name: modelNameFor
	-- upvalues: (copy) v_u_164, (copy) v_u_78, (copy) v_u_169, (copy) v_u_165, (ref) v_u_8
	local v180 = p179.def and (p179.def.model or "walker") or "walker"
	if v180 == "risen" then
		local v181 = v_u_164(p179)
		if v181 ~= 0 and v_u_78("risen_" .. tostring(v181)) then
			return "risen_" .. tostring(v181)
		end
	end
	local v182 = v180 == "risen" and not v_u_78("risen") and "walker" or v180
	if v182 == "walker" then
		v_u_169()
		local v183 = v_u_165.walkers or v_u_8.WALKER_LOOKS
		local v184 = #v183
		local v185 = p179.id % v184 + 1
		for _ = 1, v184 do
			local v186 = v183[v185]
			if v186 == "walker" or v_u_78(v186) then
				return v_u_165.variant(p179, v186, #v183)
			end
			v185 = v185 % v184 + 1
		end
		return "walker"
	else
		local v187 = v_u_165.pick(p179)
		if v187 and v_u_78(v187) then
			return v_u_165.variant(p179, v187, 1)
		elseif v_u_8.MAP_LOOK_TYPES and (p179.def and v_u_8.MAP_LOOK_TYPES[p179.def.id]) then
			return v182
		elseif p179.variant % 2 == 1 and v_u_78(v182 .. "_2") then
			return v182 .. "_2"
		else
			return v182
		end
	end
end
local v_u_189 = 0
local function v_u_207(p190, p191) -- name: applyTint
	-- upvalues: (ref) v_u_8
	local v192 = p191.id * 7 % 9
	if p190.tint == v192 then
		return
	else
		p190.tint = v192
		local v193 = p190.name
		if string.sub(v193, 1, 6) ~= "risen_" then
			local v194 = v_u_8.SKIN_JITTER or 0.06
			local v195 = 1 + v194 * (v192 % 3 - 1)
			local v196 = v192 // 3 - 1
			local v197
			if v196 < 0 then
				v197 = Color3.fromRGB(128, 132, 136)
			else
				v197 = Color3.fromRGB(150, 158, 104)
			end
			for v198, v199 in p190.base do
				if not v198.Parent then
					continue
				end
				local v200 = Color3.new
				local v201 = v199.R * v195
				local v202 = math.clamp(v201, 0, 1)
				local v203 = v199.G * v195
				local v204 = math.clamp(v203, 0, 1)
				local v205 = v199.B * v195
				local v206 = v200(v202, v204, (math.clamp(v205, 0, 1)))
				if v196 ~= 0 then
					v206 = v206:Lerp(v197, v194 * 1.2)
				end
				v198.Color = v206
			end
		end
	end
end
local function v_u_220(p208) -- name: acquireRig
	-- upvalues: (copy) v_u_188, (copy) v_u_19, (ref) v_u_22, (copy) v_u_57, (copy) v_u_16, (ref) v_u_189, (copy) v_u_160, (copy) v_u_207, (ref) v_u_9
	local v209 = v_u_188(p208)
	local v210 = v_u_19[v209]
	local v211 = nil
	local v212 = (p208.id * 5 + 1) % 3 - 1
	if v210 and #v210 > 1 then
		for v213 = #v210, 1, -1 do
			if v210[v213].bucket ~= v212 then
				continue
			end
			if v213 ~= #v210 then
				local v214 = #v210
				local v215 = v210[#v210]
				local v216 = v210[v213]
				v210[v213] = v215
				v210[v214] = v216
			end
		end
	end
	while true do
		while true do
			while true do
				if v211 or (not v210 or #v210 <= 0) then
					if not v211 then
						if v_u_189 >= 5 then
							return nil
						end
						v_u_189 = v_u_189 + 1
						v211 = v_u_160(v209, v212)
					end
					if v211 then
						v_u_207(v211, p208)
						v_u_16.glow(v211, 0)
						if v_u_16.K then
							v_u_16.K.reset(v211)
						end
						v_u_16.shieldUp[v211] = nil
						if v211.corpse then
							v211.corpse = false
							v211.model:SetAttribute("Corpse", nil)
						end
						if v211.lying then
							v211.lying = false
							v211.model:SetAttribute("Lying", nil)
						end
						v_u_9.reset(v211.pose)
						v211.vis = -1
						v211.px = (1 / 0)
						if v211.vis == 0 then
							return v211
						end
						v211.vis = 0
						for _, v217 in v211.parts do
							v217.LocalTransparencyModifier = 1
						end
					end
					return v211
				end
				v211 = table.remove(v210)
				if not v211 or v211.model.Parent ~= nil then
					break
				end
				v_u_22 = v_u_22 - 1
				v211 = nil
			end
			if v211 then
				break
			end
			if not (v211 and v_u_16.Halloween and v_u_16.Halloween.stale(v211.pumpkin ~= nil, v209)) then
				continue
			end
			v211.model:Destroy()
			v_u_22 = v_u_22 - 1
			v211 = nil
		end
		local v218 = v211.source
		local _, v219 = v_u_57(v209)
		if v218 == (v219 == "none" and "local" or v219) then
			if not (v211 and v_u_16.Halloween and v_u_16.Halloween.stale(v211.pumpkin ~= nil, v209)) then
				continue
			end
			v211.model:Destroy()
			v_u_22 = v_u_22 - 1
			v211 = nil
		else
			v211.model:Destroy()
			v_u_22 = v_u_22 - 1
			v211 = nil
		end
	end
end
local v_u_221 = {}
local function v_u_225() -- name: warmStep
	-- upvalues: (ref) v_u_7, (copy) v_u_221, (copy) v_u_78, (copy) v_u_160, (copy) v_u_19
	if v_u_7 and v_u_7.config.PLACE_MODE == "Menu" then
		table.clear(v_u_221)
	else
		for _ = 1, 2 do
			local v222 = table.remove(v_u_221)
			if not v222 then
				return
			end
			if not v_u_78(v222) then
				continue
			end
			local v223 = v_u_160(v222, #v_u_221 % 3 - 1)
			if not v223 then
				continue
			end
			local v224 = v_u_19[v222]
			if not v224 then
				v224 = {}
				v_u_19[v222] = v224
			end
			table.insert(v224, v223)
		end
	end
end
local function v_u_230(p226) -- name: releaseRig
	-- upvalues: (copy) v_u_16, (ref) v_u_9, (copy) v_u_5, (ref) v_u_22, (copy) v_u_19
	local v227 = p226.rig
	if v227 then
		p226.rig = nil
		if v227.far then
			v_u_16.farRig(v227, false)
		end
		v_u_9.reset(v227.pose)
		v227.root.CFrame = v_u_5
		if v227.vis ~= 1 then
			v227.vis = 1
			for _, v228 in v227.parts do
				v228.LocalTransparencyModifier = 0
			end
		end
		if v227.model.Parent == nil then
			v_u_22 = v_u_22 - 1
			return
		else
			local v229 = v_u_19[v227.name]
			if not v229 then
				v229 = {}
				v_u_19[v227.name] = v229
			end
			if #v229 < 40 then
				table.insert(v229, v227)
			else
				v227.model:Destroy()
				v_u_22 = v_u_22 - 1
			end
		end
	else
		return
	end
end
local function v_u_239() -- name: trimPools
	-- upvalues: (copy) v_u_19, (copy) v_u_6, (copy) v_u_57, (ref) v_u_22
	local v231 = 0
	for v232, v233 in v_u_19 do
		local v234 = v_u_6[v232] or 0
		local _, v235 = v_u_57(v232)
		local v236 = v235 == "none" and "local" or v235
		for v237 = #v233, 1, -1 do
			local v_u_238 = v233[v237]
			if v_u_238.model.Parent ~= nil and v_u_238.source == v236 then
				continue
			end
			table.remove(v233, v237)
			pcall(function()
				-- upvalues: (copy) v_u_238
				v_u_238.model:Destroy()
			end)
			v_u_22 = v_u_22 - 1
			v231 = v231 + 1
		end
		while v234 < #v233 do
			table.remove(v233).model:Destroy()
			v_u_22 = v_u_22 - 1
			v231 = v231 + 1
		end
	end
	return v231
end
local function v_u_248() -- name: rebuildRigs
	-- upvalues: (copy) v_u_14, (ref) v_u_22, (copy) v_u_19, (copy) v_u_20, (copy) v_u_221, (copy) v_u_6
	local v240 = 0
	for _, v241 in v_u_14 do
		local v_u_242 = v241.rig
		if not v_u_242 then
			continue
		end
		v241.rig = nil
		pcall(function()
			-- upvalues: (copy) v_u_242
			v_u_242.model:Destroy()
		end)
		v_u_22 = v_u_22 - 1
		v240 = v240 + 1
	end
	for _, v243 in v_u_19 do
		for _, v_u_244 in v243 do
			pcall(function()
				-- upvalues: (copy) v_u_244
				v_u_244.model:Destroy()
			end)
			v_u_22 = v_u_22 - 1
			v240 = v240 + 1
		end
	end
	table.clear(v_u_19)
	table.clear(v_u_20)
	table.clear(v_u_221)
	for v245, v246 in v_u_6 do
		for _ = 1, v246 do
			local v247 = v_u_221
			table.insert(v247, v245)
		end
	end
	return v240
end
local function v_u_253(p249, p250) -- name: newZ
	-- upvalues: (ref) v_u_8
	local v251 = v_u_8.byIndex[p250] or v_u_8.byIndex[0]
	local v252 = p249 * 7919 % 1000 / 1000
	return {
		["id"] = p249,
		["typeIndex"] = p250,
		["def"] = v251,
		["kind"] = v251.id,
		["variant"] = 0,
		["seed"] = v252,
		["st"] = table.create(4, 0),
		["sx"] = table.create(4, 0),
		["sy"] = table.create(4, 0),
		["sz"] = table.create(4, 0),
		["syaw"] = table.create(4, 0),
		["head"] = 0,
		["count"] = 0,
		["lastRecv"] = os.clock(),
		["state"] = 0,
		["flags"] = 0,
		["x"] = 0,
		["y"] = 0,
		["z"] = 0,
		["yaw"] = 0,
		["ryaw"] = 0,
		["speed"] = 0,
		["rig"] = nil,
		["hiddenSince"] = os.clock(),
		["visTarget"] = 1,
		["vis"] = 0,
		["visAt"] = 0,
		["actState"] = -1,
		["actStart"] = 0,
		["actDur"] = 0,
		["flinch"] = 0,
		["flinchX"] = 0,
		["flinchZ"] = 0,
		["limbs"] = 0,
		["hitPart"] = 0,
		["hitKick"] = 0,
		["attackVariant"] = -1,
		["noticeAt"] = -1000000000,
		["dead"] = false,
		["deadAt"] = 0,
		["deathSign"] = 1,
		["wasLying"] = false,
		["riseFromLying"] = false,
		["headshot"] = false,
		["groanAt"] = os.clock() + 2 + v252 * 8,
		["voiceAt"] = 0,
		["lodAcc"] = 0,
		["risenUser"] = 0,
		["snapVis"] = false,
		["kx"] = 0,
		["fpCut"] = false
	}
end
local function v_u_308(p254, p255, p256, p257, p258, p259, p260, p261, p262, p263, p264) -- name: onRecord
	-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_253, (ref) v_u_8, (copy) v_u_230, (ref) v_u_11, (copy) v_u_36, (ref) v_u_7, (copy) v_u_37
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v265, v266, v267, v268, v269, v270, v271, v272, v273, v274, v275, v276, v277, v278, v279, v280, v281, v_u_282, v283, v284, v285, v286, v287, v288, v289, v290, v291, v292, v293, v294, v295, v296, v297, v298, v299, v300, v301, v302, v303
	local v304 = 15
	while true do
		if v304 == 1 then
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 2 then
			return
		elseif v304 == 3 then
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 4 then
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 5 then
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 6 then
			v301 = os.clock()
			v284 = v293.def
			v285 = v293.kind
			if v284 == nil then
				v286 = false
			else
				v286 = v284.human == true and true or v_u_36[v285] == true
			end
			if v286 then
				v304 = 8
			else
				v304 = 7
			end
		elseif v304 == 7 then
			if v301 - v293.noticeAt > 1.5 then
				v287 = p257 + 5
				v288 = Vector3.new(p256, v287, p258)
				v289 = v293.kind
				v302 = v_u_7
				if v302 then
					v302 = v_u_7.controllers.Audio
				end
				if v302 and v302.zombie then
					v303 = v302.zombie
					pcall(v303, "alert", v288, v289)
				end
			end
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 8 then
			if v293.voiceAt <= v301 then
				v304 = 9
			else
				v304 = 5
			end
		elseif v304 == 9 then
			v293.voiceAt = v301 + 3.5
			v269 = v293.def
			v270 = v293.kind
			v271 = p257 + 5
			v272 = Vector3.new(p256, v271, p258)
			if v269 == nil then
				v280 = false
			else
				v280 = v269.human == true and true or v_u_36[v270] == true
			end
			if v280 then
				v304 = 10
			else
				v304 = 11
			end
		elseif v304 == 10 then
			v281 = v_u_37.humanShout
			if v281 == nil then
				v_u_282 = "humanShout"
				v283 = function()
					-- upvalues: (ref) v_u_7, (copy) v_u_282
					local v305 = v_u_7.shared.Sounds
					local v306
					if v305 == nil then
						v306 = false
					else
						local v307 = v305.zombie
						if type(v307) == "table" then
							v306 = v305.zombie[v_u_282] ~= nil
						else
							v306 = false
						end
					end
					return v306
				end
				v281, v265 = pcall(v283)
				if v281 then
					v281 = v265 == true
				end
				v_u_37.humanShout = v281
			end
			if v281 then
				v304 = 12
			else
				v304 = 13
			end
		elseif v304 == 11 then
			v266 = v_u_7
			if v266 then
				v266 = v_u_7.controllers.Audio
			end
			if v266 and v266.zombie then
				v267 = v266.zombie
				pcall(v267, "alert", v272, v270)
			end
			v304 = 1
		elseif v304 == 12 then
			v268 = v_u_7
			if v268 then
				v268 = v_u_7.controllers.Audio
			end
			if v268 and v268.zombie then
				v292 = v268.zombie
				pcall(v292, "humanShout", v272, v270)
			end
			if p261 == v_u_11.stagger and v293.actState ~= v_u_11.stagger then
				v293.actState = v_u_11.stagger
				v293.actStart = os.clock()
				v293.actDur = 0.6
				return
			end
			if p261 == v_u_11.rise and v293.actState ~= v_u_11.rise then
				v293.riseFromLying = v279 == v_u_11.lying and true or v279 == v_u_11.down
				v290 = v_u_11.rise
				v291 = v293.riseFromLying and 0.9 or 1.2
				v293.actState = v290
				v293.actStart = os.clock()
				v293.actDur = v291
				return
			end
			if p261 == v_u_11.down and v293.actState ~= v_u_11.down then
				v293.actState = v_u_11.down
				v293.actStart = os.clock()
				v293.actDur = 2
				return
			end
			if p261 == v_u_11.attack and v293.actState ~= v_u_11.attack then
				v296 = v_u_11.attack
				v297 = v293.def.attackWindup or 0.6
				v293.actState = v296
				v293.actStart = os.clock()
				v293.actDur = v297
				return
			end
			if p261 == v_u_11.scream and v293.actState ~= v_u_11.scream then
				v298 = v293.def.scream
				v299 = v_u_11.scream
				v300 = not v298 and 1.4 or v298.windup + 0.4
				v293.actState = v299
				v293.actStart = os.clock()
				v293.actDur = v300
				return
			end
			if p261 == v_u_11.bash and v293.actState ~= v_u_11.bash then
				v293.actState = v_u_11.bash
				v293.actStart = os.clock()
				v293.actDur = 1.2
				return
			end
			if p261 == v_u_11.aim and v293.actState ~= v_u_11.aim then
				v293.actState = v_u_11.aim
				v293.actStart = os.clock()
				v293.actDur = 0.8
			end
			v304 = 2
		elseif v304 == 13 then
			if v269.human == true then
				v304 = 3
			else
				v304 = 14
			end
		elseif v304 == 14 then
			v266 = v_u_7
			if v266 then
				v266 = v_u_7.controllers.Audio
			end
			if v266 and v266.zombie then
				v267 = v266.zombie
				pcall(v267, "alert", v272, v270)
			end
			v304 = 1
		else
			if v_u_17[p255] then
				return
			end
			v293 = v_u_14[p255]
			if v293 then
				if v293.dead then
					return
				end
			else
				v293 = v_u_253(p255, p260)
				v_u_14[p255] = v293
				v293.x = p256
				v293.y = p257
				v293.z = p258
				v293.yaw = p259
				v293.ryaw = p259
			end
			if v293.typeIndex ~= p260 then
				v293.typeIndex = p260
				v293.def = v_u_8.byIndex[p260] or v293.def
				v293.kind = v293.def.id
				v_u_230(v293)
			end
			if v293.count > 0 and p254 <= v293.st[v293.head] then
				return
			end
			v294 = v293.head % 4 + 1
			v293.head = v294
			v295 = v293.count + 1
			v293.count = math.min(v295, 4)
			v273 = v293.st
			v274 = v293.sx
			v275 = v293.sy
			v276 = v293.sz
			v277 = v293.syaw
			v273[v294] = p254
			v274[v294] = p256
			v275[v294] = p257
			v276[v294] = p258
			v277[v294] = p259
			v293.lastRecv = os.clock()
			v293.flags = p262
			v293.limbs = p263 or 0
			v293.kx = p264 or 0
			v278 = bit32.rshift(p262, 4)
			v293.variant = bit32.band(v278, 3)
			if p261 == v293.state then
				return
			end
			v279 = v293.state
			v293.state = p261
			if p261 == v_u_11.chase and (v279 ~= v_u_11.attack and (v279 ~= v_u_11.stagger and v279 ~= v_u_11.aim)) then
				v304 = 6
			else
				v304 = 4
			end
		end
	end
end
local v_u_309 = {
	["newest"] = -1000000000,
	["recvAt"] = -1000000000,
	["sentAt"] = 0,
	["pic"] = 0,
	["sent"] = 0,
	["eff"] = 0,
	["effAt"] = -1000000000
}
local v_u_310 = {
	["id"] = 0,
	["dists"] = nil,
	["k"] = 1,
	["log"] = nil,
	["n"] = 0,
	["trace"] = nil,
	["dists"] = {},
	["log"] = {},
	["trace"] = {}
}
local function v_u_313(p311) -- name: onSnap
	-- upvalues: (copy) v_u_309, (ref) v_u_8, (copy) v_u_308
	if typeof(p311) == "buffer" then
		if buffer.len(p311) >= 8 then
			local v312 = buffer.readf64(p311, 0)
			if v_u_309.newest < v312 then
				v_u_309.newest = v312
			end
			v_u_309.recvAt = os.clock()
		end
		v_u_8.decode(p311, v_u_308)
	end
end
local function v_u_322(p314, p315) -- name: clockStep
	-- upvalues: (copy) v_u_309, (ref) v_u_7, (copy) v_u_310
	if p314 - v_u_309.sentAt >= 0.25 and p314 - v_u_309.recvAt <= 1 then
		v_u_309.sentAt = p314
		local v316
		if p314 - v_u_309.effAt < 0.5 then
			v316 = v_u_309.eff
		else
			local v317 = v_u_309.newest + 0.25
			v316 = math.min(p315, v317)
		end
		v_u_309.pic = v316
		local v318 = v_u_309
		v318.sent = v318.sent + 1
		local v319 = v_u_7.net.fireUnreliable
		local v320 = "zombie.clock"
		local v321
		if v_u_310.id == 0 then
			v321 = nil
		else
			v321 = os.clock()
		end
		pcall(v319, v320, v316, v321)
	end
end
local function v_u_346(p323) -- name: followStep
	-- upvalues: (copy) v_u_310, (copy) v_u_14, (copy) v_u_50, (copy) v_u_309, (copy) v_u_13
	if v_u_310.id == 0 then
		return
	else
		local v324 = v_u_14[v_u_310.id]
		local v325 = v_u_50()
		if v324 and (not v324.dead and v325) then
			local v326 = v324.x - v325.X
			local v327 = v324.z - v325.Z
			local v328 = v326 * v326 + v327 * v327
			local v329 = math.sqrt(v328)
			local v330 = v_u_310.dists[v_u_310.k]
			if #v_u_310.trace < 1500 then
				local v331 = v_u_310.trace
				local v332 = string.format
				local v333 = v_u_309.eff
				local v334 = v324.x
				local v335 = v324.z
				local v336 = v325.X
				local v337 = v325.Z
				table.insert(v331, v332("%.3f,%.3f,%.2f,%.2f,%.2f,%.2f", p323, v333, v334, v335, v336, v337))
			end
			local v338 = v_u_310
			v338.n = v338.n + 1
			if v330 and v329 <= v330 then
				local v339 = v_u_310
				v339.k = v339.k + 1
				local v340 = v_u_310.log
				local v341 = string.format
				local v342 = v324.x
				local v343 = v324.z
				local v344 = v_u_309.pic
				table.insert(v340, v341("fire osc=%.3f at drawn %.1f studs drawn=%.2f,%.2f pic=%.3f", p323, v329, v342, v343, v344))
				v_u_13:SetAttribute("HushClientCmd", "weapon.fire 1")
			elseif v_u_13:GetAttribute("HushClientCmd") == "" then
				v_u_13:SetAttribute("HushClientCmd", string.format("weapon.aim %.2f %.2f", v324.x, v324.z))
			end
		else
			local v345 = v_u_310.log
			table.insert(v345, "end (gone)")
			v_u_310.id = 0
			return
		end
	end
end
local function v_u_650(p347, p348, ...) -- name: onEvent
	-- upvalues: (copy) v_u_14, (copy) v_u_16, (copy) v_u_230, (copy) v_u_18, (copy) v_u_17, (ref) v_u_10, (ref) v_u_7, (copy) v_u_253, (copy) v_u_188, (ref) v_u_11, (copy) v_u_50, (ref) v_u_23, (copy) v_u_36, (copy) v_u_37, (copy) v_u_12
	local v349 = table.pack(...)
	if p347 == "clear" then
		for _, v350 in v_u_14 do
			v_u_16.pullClear(v350.id)
			v_u_16.stopRing(v350.id)
			if v_u_16.K then
				v_u_16.K.removed(v350)
			end
			v_u_230(v350)
			v_u_14[v350.id] = nil
		end
		table.clear(v_u_18)
		table.clear(v_u_17)
		v_u_10.clear()
		return
	end
	if type(p348) ~= "number" then
		return
	end
	if p347 == "gas" then
		local v351 = v349[1]
		local v352 = v349[2]
		local v353 = v349[3]
		local v354 = tonumber(v351) or 0
		local v355 = tonumber(v352) or 0
		local v356 = tonumber(v353) or 0
		local v357 = Vector3.new(v354, v355, v356)
		local v358 = v349[4]
		local v359 = tonumber(v358) or 9
		local v360 = math.clamp(v359, 2, 30)
		local v361 = v349[5]
		local v362 = tonumber(v361) or 9
		local v363 = math.clamp(v362, 1, 30)
		local v364 = v349[6]
		local v365 = tonumber(v364)
		if v365 then
			local v366 = workspace:GetServerTimeNow() - v365
			local v367 = v363 - math.max(0, v366)
			v363 = math.max(0.5, v367)
		end
		v_u_10.gas(v357, v360, v363)
		local v368 = v357 + Vector3.new(0, 2, 0)
		local v369 = v_u_7
		if v369 then
			v369 = v_u_7.controllers.Audio
		end
		if v369 and v369.zombie then
			local v370 = v369.zombie
			pcall(v370, "gas", v368, "hazmat")
		end
		return
	end
	if p347 == "kind" then
		if v_u_16.K then
			v_u_16.K.event(p348, v_u_14[p348], ...)
		end
		return
	end
	local v371 = v_u_14[p348]
	local v372 = os.clock()
	if p347 == "spawn" then
		local v373 = v349[1]
		local v374 = tonumber(v373) or 0
		if not v371 then
			v371 = v_u_253(p348, v374)
			v_u_14[p348] = v371
		end
		local v375 = v349[2]
		local v376 = tonumber(v375) or 0
		local v377 = v349[3]
		local v378 = tonumber(v377) or 0
		local v379 = v349[4]
		local v380 = tonumber(v379) or 0
		v371.x = v376
		v371.y = v378
		v371.z = v380
		local v381 = v349[5]
		v371.yaw = tonumber(v381) or 0
		v371.ryaw = v371.yaw
		v371.lastRecv = v372
		local v382 = v349[7]
		local v383 = tonumber(v382) or 0
		if v383 ~= 0 then
			v371.risenUser = v383
			v371.snapVis = true
			if v371.rig and v371.rig.name ~= v_u_188(v371) then
				v_u_230(v371)
			end
		end
		if v349[6] == true then
			v371.state = v_u_11.rise
			v371.riseFromLying = true
			v371.actState = v_u_11.rise
			v371.actStart = os.clock()
			v371.actDur = 2.4
		end
		return
	end
	if p347 == "die" then
		local v384 = v349[1]
		local v385 = tonumber(v384) or 0
		local v386 = v349[2]
		local v387 = v349[3]
		local v388 = v349[4]
		local v389 = tonumber(v386) or 0
		local v390 = tonumber(v387) or 0
		local v391 = tonumber(v388) or 0
		local v392 = Vector3.new(v389, v390, v391)
		local v393 = v349[6]
		local v394 = tonumber(v393) or 0
		local v395 = v349[7]
		local v396 = tonumber(v395) or 0
		v_u_17[p348] = v372 + 4
		if not v371 then
			local v397 = v_u_50()
			if not v397 or (v397 - v392).Magnitude > 120 then
				return
			end
			v371 = v_u_253(p348, v385)
			v_u_14[p348] = v371
			local v398 = v392.X
			local v399 = v392.Y
			local v400 = v392.Z
			v371.x = v398
			v371.y = v399
			v371.z = v400
			local v401 = v349[5]
			v371.yaw = tonumber(v401) or 0
			v371.ryaw = v371.yaw
		end
		v371.yaw = v371.ryaw
		v_u_16.stopRing(p348)
		if v_u_16.K then
			v_u_16.K.removed(v371)
		end
		v371.dead = true
		v371.deadAt = v372
		v_u_16.pullClear(v371.id)
		v371.headshot = v349[8] == true
		v371.wasLying = v349[9] == true and true or v371.state == v_u_11.lying
		v371.state = v_u_11.dead
		local v402 = v371.yaw
		local v403 = -math.sin(v402)
		local v404 = v371.yaw
		local v405 = -math.cos(v404)
		local v406 = v394 * v403 + v396 * v405
		if math.abs(v394) + math.abs(v396) < 0.01 then
			v371.deathSign = v371.seed > 0.5 and 1 or -1
		else
			v371.deathSign = v406 < 0 and 1 or -1
		end
		v371.actState = v_u_11.dead
		v371.actStart = os.clock()
		v371.actDur = 1.2
		local v407 = v_u_18
		table.insert(v407, v371)
		local v408 = #v_u_18 > 36 and table.remove(v_u_18, 1)
		if v408 then
			v_u_16.pullClear(v408.id)
			v_u_16.stopRing(v408.id)
			if v_u_16.K then
				v_u_16.K.removed(v408)
			end
			v_u_230(v408)
			v_u_14[v408.id] = nil
		end
		if v371.vis > 0.05 or v_u_23 then
			local v409 = v_u_10.death
			local v410 = v371.x
			local v411 = v371.y
			local v412 = v371.z
			v409(Vector3.new(v410, v411, v412), v394, v396)
		end
		local v413 = v349[10]
		local v414 = tonumber(v413) or 0
		if v414 > 0 and v_u_16.Punch then
			local v415 = v_u_16.Punch.start
			pcall(v415, v371, v394, v396, v414, v372)
		end
		local v416 = v371.def
		local v417 = v371.kind
		local v418
		if v416 == nil then
			v418 = false
		else
			v418 = v416.human == true and true or v_u_36[v417] == true
		end
		local v419, v420
		if v418 then
			local v421 = v_u_37.humanDeath
			if v421 == nil then
				local v_u_422 = "humanDeath"
				local function v426()
					-- upvalues: (ref) v_u_7, (copy) v_u_422
					local v423 = v_u_7.shared.Sounds
					local v424
					if v423 == nil then
						v424 = false
					else
						local v425 = v423.zombie
						if type(v425) == "table" then
							v424 = v423.zombie[v_u_422] ~= nil
						else
							v424 = false
						end
					end
					return v424
				end
				local v427
				v421, v427 = pcall(v426)
				if v421 then
					v421 = v427 == true
				end
				v_u_37.humanDeath = v421
			end
			if v421 then
				local v428 = v_u_7
				if v428 then
					v428 = v_u_7.controllers.Audio
				end
				if v428 and v428.zombie then
					local v429 = v428.zombie
					pcall(v429, "humanDeath", v392, v417)
					return
				end
			else
				if v416.human == true then
					return
				end
				v419 = v_u_7
				if v419 then
					v419 = v_u_7.controllers.Audio
				end
				if v419 and v419.zombie then
					v420 = v419.zombie
					pcall(v420, "die", v392, v417)
				end
			end
		else
			v419 = v_u_7
			if v419 then
				v419 = v_u_7.controllers.Audio
			end
			if v419 and v419.zombie then
				v420 = v419.zombie
				pcall(v420, "die", v392, v417)
			end
			return
		end
	else
		if not v371 or v371.dead then
			return
		end
		local v430 = v371.x
		local v431 = v371.y
		local v432 = v371.z
		local v433 = Vector3.new(v430, v431, v432)
		if p347 == "hit" then
			local v434 = v349[1]
			local v435 = v349[2]
			local v436 = v349[3]
			local v437 = tonumber(v434) or 0
			local v438 = tonumber(v435) or 0
			local v439 = tonumber(v436) or 0
			local v440 = Vector3.new(v437, v438, v439)
			local v441 = v349[4]
			local v442 = tonumber(v441) or 0
			local v443 = v349[5]
			local v444 = tonumber(v443) or 0
			local v445 = v349[7]
			local v446 = tonumber(v445) or 1
			local v447 = v371.yaw
			local v448 = math.cos(v447)
			local v449 = v371.yaw
			local v450 = math.sin(v449)
			v371.flinchX = v442 * v448 - v444 * v450
			v371.flinchZ = v442 * v450 + v444 * v448
			local v451 = v371.flinch + 0.55 + 0.1 * v446
			v371.flinch = math.min(1, v451)
			if v349[8] == "shield" then
				local v452 = v371.flinch * 0.5 + 0.12
				v371.flinch = math.min(1, v452)
				v_u_16.clang(v440, v442, v444, v446, v371.vis > 0.05 and true or v_u_23)
				return
			end
			local v453 = v_u_12
			local v454 = v349[8]
			v371.hitPart = v453[tostring(v454)] or (v349[6] == true and 1 or 2)
			v371.hitKick = 1
			if v371.vis > 0.05 or v_u_23 then
				v_u_10.blood(v440, v442, v444, math.min(v446, 4), v349[6] == true)
			end
			local v455 = v371.def
			local v456 = v371.kind
			local v457
			if v455 == nil then
				v457 = false
			else
				v457 = v455.human == true and true or v_u_36[v456] == true
			end
			if v457 then
				if v371.voiceAt <= v372 and math.random() < 0.6 then
					v371.voiceAt = v372 + 0.9 + math.random() * 0.6
					local v458 = v371.def
					local v459 = v371.kind
					local v460 = v433 + Vector3.new(0, 4.5, 0)
					local v461
					if v458 == nil then
						v461 = false
					else
						v461 = v458.human == true and true or v_u_36[v459] == true
					end
					local v462, v463
					if v461 then
						local v464 = v_u_37.humanPain
						if v464 == nil then
							local v_u_465 = "humanPain"
							local function v469()
								-- upvalues: (ref) v_u_7, (copy) v_u_465
								local v466 = v_u_7.shared.Sounds
								local v467
								if v466 == nil then
									v467 = false
								else
									local v468 = v466.zombie
									if type(v468) == "table" then
										v467 = v466.zombie[v_u_465] ~= nil
									else
										v467 = false
									end
								end
								return v467
							end
							local v470
							v464, v470 = pcall(v469)
							if v464 then
								v464 = v470 == true
							end
							v_u_37.humanPain = v464
						end
						if v464 then
							local v471 = v_u_7
							if v471 then
								v471 = v_u_7.controllers.Audio
							end
							if v471 and v471.zombie then
								local v472 = v471.zombie
								pcall(v472, "humanPain", v460, v459)
								return
							end
							return
						end
						if v458.human == true then
							return
						end
						v462 = v_u_7
						if v462 then
							v462 = v_u_7.controllers.Audio
						end
						if v462 and v462.zombie then
							v463 = v462.zombie
							pcall(v463, "pain", v460, v459)
							return
						end
					else
						v462 = v_u_7
						if v462 then
							v462 = v_u_7.controllers.Audio
						end
						if v462 and v462.zombie then
							v463 = v462.zombie
							pcall(v463, "pain", v460, v459)
							return
						end
					end
				end
			else
				if math.random() < 0.35 then
					local v473 = v371.kind
					local v474 = v_u_7
					if v474 then
						v474 = v_u_7.controllers.Audio
					end
					if v474 and v474.zombie then
						local v475 = v474.zombie
						pcall(v475, "pain", v433, v473)
						return
					end
				end
				return
			end
		elseif p347 == "attack" then
			local v476 = v_u_11.attack
			local v477 = v349[1]
			local v478 = tonumber(v477) or 0.6
			v371.actState = v476
			v371.actStart = os.clock()
			v371.actDur = v478
			local v479 = v349[3]
			v371.attackVariant = tonumber(v479) or -1
			local v480 = v349[4]
			local v481 = tonumber(v480)
			if v481 then
				local v482 = 0.13 - (workspace:GetServerTimeNow() - v481)
				v371.actStart = v372 + math.clamp(v482, 0, 0.13)
			end
			if v371.def.human then
				if v371.voiceAt <= v372 and math.random() < 0.5 then
					v371.voiceAt = v372 + 3
					local v483 = v371.def
					local v484 = v371.kind
					local v485 = v433 + Vector3.new(0, 4.5, 0)
					local v486
					if v483 == nil then
						v486 = false
					else
						v486 = v483.human == true and true or v_u_36[v484] == true
					end
					if v486 then
						local v487 = v_u_37.humanShout
						if v487 == nil then
							local v_u_488 = "humanShout"
							local function v492()
								-- upvalues: (ref) v_u_7, (copy) v_u_488
								local v489 = v_u_7.shared.Sounds
								local v490
								if v489 == nil then
									v490 = false
								else
									local v491 = v489.zombie
									if type(v491) == "table" then
										v490 = v489.zombie[v_u_488] ~= nil
									else
										v490 = false
									end
								end
								return v490
							end
							local v493
							v487, v493 = pcall(v492)
							if v487 then
								v487 = v493 == true
							end
							v_u_37.humanShout = v487
						end
						if v487 then
							local v494 = v_u_7
							if v494 then
								v494 = v_u_7.controllers.Audio
							end
							if v494 and v494.zombie then
								local v495 = v494.zombie
								pcall(v495, "humanShout", v485, v484)
								return
							end
						elseif v483.human == true then
							return
						end
					end
				end
			else
				local v496 = v371.kind
				local v497 = v_u_7
				if v497 then
					v497 = v_u_7.controllers.Audio
				end
				if v497 and v497.zombie then
					local v498 = v497.zombie
					pcall(v498, "attack", v433, v496)
					return
				end
			end
			return
		else
			if p347 == "ring" then
				local v499 = v349[2]
				local v500 = tonumber(v499) or 2
				local v501 = math.clamp(v500, 0.3, 10)
				local v502 = v349[3]
				local v503 = tonumber(v502)
				if v503 then
					local v504 = workspace:GetServerTimeNow() - v503
					local v505 = v501 - math.max(0, v504)
					v501 = math.max(0.2, v505)
				end
				local v506 = v_u_16.startRing
				local v507 = v349[1]
				v506(v371, tonumber(v507) or 1, v501)
				return
			end
			if p347 == "shield" then
				local v508 = v349[1]
				local v509 = v349[2]
				local v510 = v349[3]
				local v511 = tonumber(v508) or 0
				local v512 = tonumber(v509) or 0
				local v513 = tonumber(v510) or 0
				local v514 = Vector3.new(v511, v512, v513)
				local v515 = v349[4]
				if (tonumber(v515) or 0) == 0 then
					local v516 = v371.flags
					v371.flags = bit32.band(v516, 4294967231)
					local v517 = v_u_16.clang
					local v518 = v349[5]
					local v519 = tonumber(v518) or 0
					local v520 = v349[6]
					v517(v514, v519, tonumber(v520) or 0, 3, v371.vis > 0.05 and true or v_u_23)
					if v371.rig then
						v_u_16.shield(v371, v371.rig)
						return
					end
				end
				return
			elseif p347 == "notice" then
				local v521 = v349[2]
				local v522 = tonumber(v521)
				local v523
				if v522 then
					local v524 = 0.13 - (workspace:GetServerTimeNow() - v522)
					v523 = math.clamp(v524, 0, 0.13)
				else
					v523 = 0
				end
				v371.noticeAt = v372 + v523
				local v525 = v371.def
				local v526 = v371.kind
				local v527
				if v525 == nil then
					v527 = false
				else
					v527 = v525.human == true and true or v_u_36[v526] == true
				end
				if not v527 then
					local v528 = v433 + Vector3.new(0, 5, 0)
					local v529 = v371.kind
					local v530 = v_u_7
					if v530 then
						v530 = v_u_7.controllers.Audio
					end
					if v530 and v530.zombie then
						local v531 = v530.zombie
						pcall(v531, "alert", v528, v529)
						return
					end
				end
				return
			elseif p347 == "aim" then
				local v532 = v_u_11.aim
				local v533 = v349[1]
				local v534 = tonumber(v533) or 0.8
				v371.actState = v532
				v371.actStart = os.clock()
				v371.actDur = v534
				local v535 = v371.def
				local v536 = v371.kind
				local v537
				if v535 == nil then
					v537 = false
				else
					v537 = v535.human == true and true or v_u_36[v536] == true
				end
				if v537 and (v371.voiceAt <= v372 and math.random() < 0.35) then
					v371.voiceAt = v372 + 4 + math.random() * 3
					local v538 = v371.def
					local v539 = v371.kind
					local v540 = v433 + Vector3.new(0, 4.5, 0)
					local v541
					if v538 == nil then
						v541 = false
					else
						v541 = v538.human == true and true or v_u_36[v539] == true
					end
					if v541 then
						local v542 = v_u_37.humanShout
						if v542 == nil then
							local v_u_543 = "humanShout"
							local function v547()
								-- upvalues: (ref) v_u_7, (copy) v_u_543
								local v544 = v_u_7.shared.Sounds
								local v545
								if v544 == nil then
									v545 = false
								else
									local v546 = v544.zombie
									if type(v546) == "table" then
										v545 = v544.zombie[v_u_543] ~= nil
									else
										v545 = false
									end
								end
								return v545
							end
							local v548
							v542, v548 = pcall(v547)
							if v542 then
								v542 = v548 == true
							end
							v_u_37.humanShout = v542
						end
						if v542 then
							local v549 = v_u_7
							if v549 then
								v549 = v_u_7.controllers.Audio
							end
							if v549 and v549.zombie then
								local v550 = v549.zombie
								pcall(v550, "humanShout", v540, v539)
								return
							end
						elseif v538.human == true then
							return
						end
					end
				end
				return
			else
				if p347 == "shoot" then
					local v551 = v349[1]
					local v552 = v349[2]
					local v553 = v349[3]
					local v554 = tonumber(v551) or 0
					local v555 = tonumber(v552) or 0
					local v556 = tonumber(v553) or 0
					local v557 = Vector3.new(v554, v555, v556)
					local v558 = v349[4]
					local v559 = v349[5]
					local v560 = v349[6]
					local v561 = tonumber(v558) or 0
					local v562 = tonumber(v559) or 0
					local v563 = tonumber(v560) or 0
					local v564 = Vector3.new(v561, v562, v563)
					local v565 = v371.rig
					if v565 and (v565.muzzle and v565.muzzle.Parent) then
						v557 = v565.muzzle.WorldPosition
					end
					if v371.vis > 0.05 or v_u_23 then
						v_u_10.muzzle(v557, v564)
					end
					local v566 = v_u_50()
					local v567 = v557 + (v564.Magnitude <= 0 and Vector3.new(0, 0, -1) or v564.Unit) * 40
					if v566 then
						local v568 = v349[8]
						if (tonumber(v568) or 0) > 0 and (v566 - v557).Magnitude < 60 then
							v567 = v566 + Vector3.new(0, 1.5, 0)
						end
					end
					v_u_10.tracer(v557, v567)
					local v569 = v_u_7.controllers.Audio
					if v569 and v569.gunshot then
						local v570 = v569.gunshot
						local v571 = v349[7] or "shotgun_870"
						local v572 = tostring(v571)
						pcall(v570, v572, v557, false, false)
					end
					local v573 = v371.flinch + 0.3
					v371.flinch = math.min(1, v573)
					v371.flinchX = 0
					v371.flinchZ = 1
					return
				end
				if p347 == "scream" then
					local v574 = v349[1]
					local v575 = tonumber(v574) or 1.2
					local v576 = v_u_11.scream
					local v577 = v575 + 0.4
					v371.actState = v576
					v371.actStart = os.clock()
					v371.actDur = v577
					local v578 = v371.kind
					local v579 = v_u_7
					if v579 then
						v579 = v_u_7.controllers.Audio
					end
					if v579 and v579.zombie then
						local v580 = v579.zombie
						pcall(v580, "scream", v433, v578)
					end
					local v581 = v_u_50()
					if v581 and (v581 - v433).Magnitude < 30 then
						local v582 = v_u_7.controllers.Camera
						if v582 and v582.shake then
							local v583 = v582.shake
							pcall(v583, 0.25, 0.5)
							return
						end
					end
					return
				elseif p347 == "bash" then
					v371.actState = v_u_11.bash
					v371.actStart = os.clock()
					v371.actDur = 1.2
					local v584 = v349[1]
					local v585 = v349[2]
					local v586 = v349[3]
					local v587 = tonumber(v584) or 0
					local v588 = tonumber(v585) or 0
					local v589 = tonumber(v586) or 0
					local v590 = Vector3.new(v587, v588, v589)
					local v591 = v371.kind
					local v592 = v_u_7
					if v592 then
						v592 = v_u_7.controllers.Audio
					end
					if v592 and v592.zombie then
						local v593 = v592.zombie
						pcall(v593, "bash", v590, v591)
						return
					end
					return
				else
					if p347 == "stagger" then
						local v594 = v349[1]
						local v595 = tonumber(v594) or 0
						local v596 = v349[2]
						local v597 = tonumber(v596) or 0
						local v598 = v371.yaw
						local v599 = math.cos(v598)
						local v600 = v371.yaw
						local v601 = math.sin(v600)
						v371.flinchX = v595 * v599 - v597 * v601
						v371.flinchZ = v595 * v601 + v597 * v599
						local v602 = v_u_12
						local v603 = v349[3]
						local v604 = v602[tostring(v603)]
						if v604 then
							v371.hitPart = v604
							v371.hitKick = 1
						end
						local v605 = v_u_11.stagger
						local v606 = v349[4]
						local v607 = tonumber(v606) or 0.65
						local v608 = math.clamp(v607, 0.3, 1.2)
						v371.actState = v605
						v371.actStart = os.clock()
						v371.actDur = v608
						return
					end
					if p347 == "down" then
						local v609 = v349[2]
						local v610 = tonumber(v609) or 0
						local v611 = v349[3]
						local v612 = tonumber(v611) or 0
						local v613 = v371.yaw
						local v614 = math.cos(v613)
						local v615 = v371.yaw
						local v616 = math.sin(v615)
						v371.flinchX = v610 * v614 - v612 * v616
						v371.flinchZ = v610 * v616 + v612 * v614
						v371.flinch = 1
						local v617 = v_u_11.down
						local v618 = v349[1]
						local v619 = tonumber(v618) or 2
						local v620 = math.clamp(v619, 0.5, 4)
						v371.actState = v617
						v371.actStart = os.clock()
						v371.actDur = v620
						local v621 = v371.def
						local v622 = v371.kind
						local v623
						if v621 == nil then
							v623 = false
						else
							v623 = v621.human == true and true or v_u_36[v622] == true
						end
						if not v623 and math.random() < 0.6 then
							local v624 = v371.kind
							local v625 = v_u_7
							if v625 then
								v625 = v_u_7.controllers.Audio
							end
							if v625 and v625.zombie then
								local v626 = v625.zombie
								pcall(v626, "pain", v433, v624)
								return
							end
						end
						return
					elseif p347 == "wake" then
						v371.riseFromLying = v371.state == v_u_11.lying and true or v371.def.lying == true
						local v627 = v_u_11.rise
						local v628 = v371.riseFromLying and 0.9 or 1.3
						v371.actState = v627
						v371.actStart = os.clock()
						v371.actDur = v628
						local v629 = v371.def
						local v630 = v371.kind
						local v631
						if v629 == nil then
							v631 = false
						else
							v631 = v629.human == true and true or v_u_36[v630] == true
						end
						if v631 then
							if v371.voiceAt <= v372 then
								v371.voiceAt = v372 + 3.5
								local v632 = v371.def
								local v633 = v371.kind
								local v634 = v433 + Vector3.new(0, 4.5, 0)
								local v635
								if v632 == nil then
									v635 = false
								else
									v635 = v632.human == true and true or v_u_36[v633] == true
								end
								local v636, v637
								if v635 then
									local v638 = v_u_37.humanShout
									if v638 == nil then
										local v_u_639 = "humanShout"
										local function v643()
											-- upvalues: (ref) v_u_7, (copy) v_u_639
											local v640 = v_u_7.shared.Sounds
											local v641
											if v640 == nil then
												v641 = false
											else
												local v642 = v640.zombie
												if type(v642) == "table" then
													v641 = v640.zombie[v_u_639] ~= nil
												else
													v641 = false
												end
											end
											return v641
										end
										local v644
										v638, v644 = pcall(v643)
										if v638 then
											v638 = v644 == true
										end
										v_u_37.humanShout = v638
									end
									if v638 then
										local v645 = v_u_7
										if v645 then
											v645 = v_u_7.controllers.Audio
										end
										if v645 and v645.zombie then
											local v646 = v645.zombie
											pcall(v646, "humanShout", v634, v633)
											return
										end
										return
									end
									if v632.human == true then
										return
									end
									v636 = v_u_7
									if v636 then
										v636 = v_u_7.controllers.Audio
									end
									if v636 and v636.zombie then
										v637 = v636.zombie
										pcall(v637, "alert", v634, v633)
									end
								else
									v636 = v_u_7
									if v636 then
										v636 = v_u_7.controllers.Audio
									end
									if v636 and v636.zombie then
										v637 = v636.zombie
										pcall(v637, "alert", v634, v633)
									end
								end
							end
						else
							local v647 = v371.kind
							local v648 = v_u_7
							if v648 then
								v648 = v_u_7.controllers.Audio
							end
							if v648 and v648.zombie then
								local v649 = v648.zombie
								pcall(v649, "alert", v433, v647)
								return
							end
							return
						end
					else
						return
					end
				end
			end
		end
	end
end
local function v_u_690(p651, p652) -- name: interpolate
	-- upvalues: (copy) v_u_16, (copy) v_u_309
	local v653 = p651.count
	if v653 ~= 0 then
		local v654 = p651.head
		local v655 = p651.st[v654]
		if v653 ~= 1 and v655 > p652 then
			for _ = 1, v653 - 1 do
				local v656 = (v654 - 2) % 4 + 1
				local v657 = p651.st[v656]
				if v657 <= p652 then
					local v658 = p651.st[v654]
					local v659 = v658 - v657 <= 0.0001 and 1 or (p652 - v657) / (v658 - v657)
					p651.x = p651.sx[v656] + (p651.sx[v654] - p651.sx[v656]) * v659
					p651.y = p651.sy[v656] + (p651.sy[v654] - p651.sy[v656]) * v659
					p651.z = p651.sz[v656] + (p651.sz[v654] - p651.sz[v656]) * v659
					local v660 = p651.syaw[v656]
					p651.yaw = v660 + ((p651.syaw[v654] - v660 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v659
					if v_u_309.newest - 0.2 <= v655 then
						local v661 = v_u_309
						local v662 = v_u_309
						local v663 = os.clock()
						v661.eff = p652
						v662.effAt = v663
					end
					return v657
				end
				v654 = v656
			end
			local v664 = p651.sx[v654]
			local v665 = p651.sy[v654]
			local v666 = p651.sz[v654]
			local v667 = p651.syaw[v654]
			p651.x = v664
			p651.y = v665
			p651.z = v666
			p651.yaw = v667
			if v_u_309.newest - 0.2 <= v655 then
				local v668 = v_u_309
				local v669 = v_u_309
				local v670 = p651.st[v654]
				local v671 = os.clock()
				v668.eff = v670
				v669.effAt = v671
			end
			return p651.st[v654]
		end
		local v672 = (v654 - 2) % 4 + 1
		local v673 = p651.sx[v654]
		local v674 = p651.sy[v654]
		local v675 = p651.sz[v654]
		local v676 = p651.syaw[v654]
		local v677
		if v653 >= 2 then
			v677 = p651.st[v672]
			local v678 = v_u_16.Zm
			if v678 == nil then
				local v679 = v655 - v677
				if v679 > 0.001 then
					local v680 = p652 - v655
					local v681 = math.min(v680, 0.25)
					if v681 > 0 then
						local v682 = v681 / v679
						v673 = v673 + (v673 - p651.sx[v672]) * v682
						v675 = v675 + (v675 - p651.sz[v672]) * v682
					end
				end
			else
				local v683
				if v655 < p652 and v_u_16.Fp.on then
					local v684 = v_u_16.holds(p652)[p651.id]
					if v684 == nil then
						v683 = false
					else
						v683 = v678.heldFor(v677 - v684)
					end
				else
					v683 = false
				end
				v673, v675 = v678.extrapolate(v673, v675, v655, p651.sx[v672], p651.sz[v672], v677, p652, 0.25, v683)
			end
		else
			v677 = v655
		end
		p651.x = v673
		p651.y = v674
		p651.z = v675
		p651.yaw = v676
		if v_u_309.newest - 0.2 <= v655 then
			local v685 = v_u_309
			local v686 = v_u_309
			local v687 = p652 - v655
			local v688 = v655 + math.clamp(v687, 0, 0.25)
			local v689 = os.clock()
			v685.eff = v688
			v686.effAt = v689
		end
		return v677
	end
end
local v_u_691 = {}
local v_u_692 = {}
local v_u_693 = {
	["state"] = 0,
	["speed"] = 0,
	["kind"] = "walker",
	["style"] = 0,
	["seed"] = 0,
	["t"] = 0,
	["act"] = 0,
	["actDur"] = 0,
	["flinch"] = 0,
	["flinchX"] = 0,
	["flinchZ"] = 0,
	["deathSign"] = 1,
	["wasLying"] = false,
	["legless"] = false,
	["human"] = false,
	["riseFromLying"] = false,
	["headshot"] = false,
	["variant"] = nil,
	["notice"] = -1,
	["ring"] = 0,
	["lieVariant"] = nil,
	["climb"] = false,
	["wade"] = false
}
local function v_u_701(p694, p695) -- name: animState
	-- upvalues: (ref) v_u_11
	if p694.dead then
		return v_u_11.dead, p695 - p694.deadAt, 1.2
	else
		local v696 = p694.actState
		if v696 >= 0 then
			local v697 = p695 - p694.actStart
			local v698 = p694.actDur
			local v699
			if v696 == v_u_11.attack then
				v699 = v698 + 0.6
			else
				v699 = v696 == v_u_11.bash and 1.6 or v698
			end
			if v697 < v699 then
				if v696 ~= v_u_11.bash or p694.state == v_u_11.bash then
					return v696, v697, v698
				end
				p694.actState = -1
			else
				p694.actState = -1
			end
		end
		local v700 = p694.state
		if v700 == v_u_11.rise then
			return v_u_11.idle, 0, 0
		elseif v700 == v_u_11.down then
			return v_u_11.down, 0, 0
		elseif v700 == v_u_11.attack or (v700 == v_u_11.aim or (v700 == v_u_11.bash or (v700 == v_u_11.stagger or v700 == v_u_11.scream))) then
			return v_u_11.chase, 0, 0
		else
			return v700, 0, 0
		end
	end
end
local function v_u_714(p702, p703, p704) -- name: updateVisibility
	-- upvalues: (copy) v_u_16, (ref) v_u_23, (ref) v_u_7
	if p703 < p702.visAt and not v_u_16.Fp.on then
		return
	else
		local v705 = p702.visTarget
		p702.visAt = p703 + (p704 < 2025 and 1 or (p704 < 8100 and 1.7 or 2.6)) * 0.1 * (p702.seed * 0.4 + 0.8)
		if v_u_23 then
			p702.visTarget = 1
		else
			local v706 = v_u_7.controllers.Vision
			if v706 and v706.visibility then
				local v707 = v706.zombieVisibility or v706.visibility
				local v708 = p702.x
				local v709 = p702.y + 3
				local v710 = p702.z
				local v711 = Vector3.new(v708, v709, v710)
				local v712, v713 = pcall(v707, v711)
				p702.visTarget = (not v712 or type(v713) ~= "number") and 1 or math.clamp(v713, 0, 1)
			else
				p702.visTarget = 1
			end
			if v_u_16.K then
				p702.visTarget = p702.visTarget * v_u_16.K.vis(p702, p704)
			end
			if v_u_16.Fp.on and (v705 <= 0 and p702.visTarget > 0) then
				p702.snapVis = true
			end
		end
	end
end
local v_u_715 = {}
local v_u_716 = {}
local v_u_717 = {}
local v_u_718 = {}
local function v_u_722(p719) -- name: makeBlockers
	-- upvalues: (copy) v_u_5, (copy) v_u_715, (copy) v_u_716
	for v720 = 1, 10 do
		local v721 = Instance.new("Part")
		v721.Name = "ZombieBlocker"
		v721.Shape = Enum.PartType.Cylinder
		v721.Size = Vector3.new(3.6, 1.8, 1.8)
		v721.Anchored = true
		v721.CanCollide = true
		v721.CanQuery = false
		v721.CanTouch = false
		v721.CastShadow = false
		v721.Transparency = 1
		v721.Massless = true
		v721.CFrame = v_u_5
		v721.Parent = p719
		v_u_715[v720] = v721
		v_u_716[v720] = true
	end
end
local v_u_723 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_755(p724, p725, p726) -- name: updateBlockers
	-- upvalues: (copy) v_u_715, (copy) v_u_717, (copy) v_u_13, (copy) v_u_14, (ref) v_u_11, (copy) v_u_718, (copy) v_u_723, (copy) v_u_716, (copy) v_u_5
	if #v_u_715 ~= 0 then
		table.clear(v_u_717)
		local v727 = 0
		local v728 = 0
		if p726 then
			local v729 = v_u_13.Character
			if v729 then
				v729 = v729:FindFirstChildOfClass("Humanoid")
			end
			if v729 then
				local v730 = v729.MoveDirection
				v727 = v730.X
				v728 = v730.Z
			end
		end
		if p726 and v727 * v727 + v728 * v728 > 0.01 then
			for _, v731 in v_u_14 do
				if v731.dead or (v731.state == v_u_11.lying or (v731.state == v_u_11.dormant or (v731.state == v_u_11.feed or v731.state == v_u_11.down))) then
					continue
				end
				local v732 = v731.x - p724
				local v733 = v731.z - p725
				local v734 = v732 * v732 + v733 * v733
				if v734 >= 81 or v732 * v727 + v733 * v728 <= math.sqrt(v734) * 0.25 then
					continue
				end
				local v735 = v_u_717
				table.insert(v735, v731)
				v_u_718[v731] = v734
			end
			if #v_u_717 > 10 then
				table.sort(v_u_717, function(p736, p737)
					-- upvalues: (ref) v_u_718
					return v_u_718[p736] < v_u_718[p737]
				end)
			end
		end
		for v738 = 1, 10 do
			local v739 = v_u_717[v738]
			local v740 = v_u_715[v738]
			if v739 then
				local v741 = (v739.def.radius or 1.2) * 0.6
				local v742 = math.clamp(v741, 0.7, 1.3)
				local v743 = v740.Size.Y - v742 * 2
				if math.abs(v743) > 0.01 then
					local v744 = v742 * 2
					local v745 = v742 * 2
					v740.Size = Vector3.new(3.6, v744, v745)
				end
				local v746 = v739.x
				local v747 = v739.z
				local v748 = v746 - p724
				local v749 = v747 - p725
				local v750 = v748 * v748 + v749 * v749
				local v751 = math.sqrt(v750)
				local v752 = v742 + 1.3
				if v751 < v752 then
					if v751 < 0.05 then
						local v753 = v739.ryaw
						v748 = math.sin(v753)
						local v754 = v739.ryaw
						v749 = math.cos(v754)
						v751 = 1
					end
					v746 = p724 + v748 / v751 * v752
					v747 = p725 + v749 / v751 * v752
				end
				v740.CFrame = CFrame.new(v746, v739.y + 2.6, v747) * v_u_723
				v_u_716[v738] = false
			else
				if v_u_716[v738] then
					continue
				end
				v740.CFrame = v_u_5
				v_u_716[v738] = true
			end
		end
		table.clear(v_u_718)
	end
end
local function v_u_964(p756) -- name: step
	-- upvalues: (ref) v_u_27, (copy) v_u_322, (copy) v_u_346, (copy) v_u_50, (copy) v_u_691, (copy) v_u_692, (ref) v_u_189, (copy) v_u_16, (copy) v_u_18, (ref) v_u_7, (copy) v_u_14, (copy) v_u_230, (copy) v_u_690, (copy) v_u_714, (ref) v_u_24, (ref) v_u_11, (copy) v_u_188, (copy) v_u_220, (copy) v_u_701, (copy) v_u_693, (ref) v_u_9, (ref) v_u_28, (copy) v_u_29, (ref) v_u_25, (copy) v_u_17, (copy) v_u_755, (copy) v_u_13, (ref) v_u_10, (copy) v_u_15, (ref) v_u_26
	local v757 = os.clock()
	v_u_27 = v_u_27 + 1
	local v758 = workspace:GetServerTimeNow() - 0.13
	v_u_322(v757, v758)
	v_u_346(v757)
	local v759, v760 = v_u_50()
	local v761, v762
	if v759 then
		v761 = v759.X
		v762 = v759.Z
	else
		v761 = 0
		v762 = 0
	end
	table.clear(v_u_691)
	table.clear(v_u_692)
	v_u_189 = 0
	local v763 = 0
	local v764 = v_u_16.fpBegin(v757, v761, v762)
	local v765 = v_u_16.Fp
	v765.wantN = 0
	v765.wantL = 0
	local v766
	if v_u_16.Eyes == nil then
		v766 = false
	else
		local v767 = v_u_16.Eyes.begin
		local v768
		if v760 then
			v768 = nil
		else
			v768 = v759
		end
		v766 = v767(v757, v768)
	end
	if v_u_16.Heat ~= nil then
		local v769 = v_u_16
		local v770 = v_u_16.Heat.begin
		local v771
		if v760 then
			v771 = nil
		else
			v771 = v759
		end
		v769.HeatOn = v770(v757, v771)
	end
	local v772 = 0
	local v773 = 0
	local v774 = 0
	local v775 = v_u_16.Pull
	if #v_u_18 > 0 and v_u_16.CF ~= false then
		local function v776()
			-- upvalues: (ref) v_u_16, (ref) v_u_7
			return v_u_16.CF or v_u_7.lib.VehicleCorpseFade
		end
		local v777, v778 = pcall(v776)
		local v779 = v_u_16
		if not v777 or type(v778) ~= "table" then
			v778 = false
		end
		v779.CF = v778
		local v780 = v_u_16.CF
		if v780 then
			local v781 = v780.check
			local v782 = v_u_18
			if not pcall(v781, v782, v757, 60) then
				v_u_16.CF = false
			end
		end
	end
	for v783, v784 in v_u_14 do
		if v784.dead then
			if v784.punch then
				v_u_16.Punch.step(v784, v757)
			end
			if v757 - v784.deadAt <= 63 then
				goto l37
			end
			local v785 = table.find(v_u_18, v784)
			if v785 then
				table.remove(v_u_18, v785)
			end
			v_u_16.pullClear(v784.id)
			v_u_16.stopRing(v784.id)
			if v_u_16.K then
				v_u_16.K.removed(v784)
			end
			v_u_230(v784)
			v_u_14[v784.id] = nil
		elseif v757 - v784.lastRecv > 1.6 then
			v_u_16.pullClear(v784.id)
			v_u_16.stopRing(v784.id)
			if v_u_16.K then
				v_u_16.K.removed(v784)
			end
			v_u_230(v784)
			v_u_14[v784.id] = nil
		else
			local v786 = v784.x
			local v787 = v784.z
			local v788 = v_u_690(v784, v758)
			if v775.n > 0 then
				v_u_16.pullDraw(v784, v758, v788, v757)
			end
			local v789 = v784.x - v786
			local v790 = v784.z - v787
			local v791
			if p756 > 0 then
				local v792 = v789 * v789 + v790 * v790
				v791 = math.sqrt(v792) / p756
			else
				v791 = 0
			end
			if v791 > 40 then
				v791 = v784.speed
			end
			local v793 = v784.speed
			local v794 = v791 - v784.speed
			local v795 = -p756 * 8
			v784.speed = v793 + v794 * (1 - math.exp(v795))
			local v796 = v784.ryaw
			local v797 = v784.yaw
			local v798 = -p756 * v_u_16.RYAW_RATE
			local v799 = 1 - math.exp(v798)
			v784.ryaw = v796 + ((v797 - v796 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v799
			::l37::
			local v800 = v784.flinch
			local v801 = -p756 * 7
			v784.flinch = v800 * math.exp(v801)
			local v802 = v784.hitKick
			local v803 = -p756 * 5
			v784.hitKick = v802 * math.exp(v803)
			local v804 = v784.x - v761
			local v805 = v784.z - v762
			local v806 = v804 * v804 + v805 * v805
			v_u_714(v784, v757, v806)
			local v807 = v784.vis
			local v808 = v784.visTarget - v784.vis
			local v809 = -p756 * 6
			v784.vis = v807 + v808 * (1 - math.exp(v809))
			if v784.snapVis then
				v784.snapVis = false
				v784.vis = v784.visTarget
			end
			if not v784.dead and (v806 < 3600 and not v784.def.human) then
				if v784.groanAt <= v757 then
					local v810 = v784.flags
					local v811
					if bit32.band(v810, 128) ~= 0 then
						v811 = 2.5 + math.random() * 3.5
					else
						v811 = 6 + math.random() * 10
					end
					v784.groanAt = v757 + v811
					if v757 - v_u_24 > 0.35 and (v784.state ~= v_u_11.dormant and v784.state ~= v_u_11.lying) then
						v_u_24 = v757
						local v812 = v784.state == v_u_11.feed and "eat" or "groan"
						local v813 = v784.x
						local v814 = v784.y + (v784.state == v_u_11.feed and 2 or 5)
						local v815 = v784.z
						local v816 = Vector3.new(v813, v814, v815)
						local v817 = v784.kind
						local v818 = v_u_7
						if v818 then
							v818 = v_u_7.controllers.Audio
						end
						if v818 and v818.zombie then
							local v819 = v818.zombie
							pcall(v819, v812, v816, v817)
						end
					end
				end
				if v806 < 1024 and v784.state ~= v_u_11.lying then
					v772 = v772 + 1
					v773 = v773 + v784.x
					v774 = v774 + v784.z
				end
			end
			local v820 = v784.vis > 0.02 and true or v784.visTarget > 0
			local v821
			if v764 then
				v821 = v765.V.hides(v806, v784.dead or v784.state == v_u_11.dead, v765.cut2, v765.ccut2, v765.keep2)
			else
				v821 = v764
			end
			v784.fpCut = v821
			if v784.fpCut then
				v820 = false
			end
			if v764 and (v820 and (v784.visTarget <= 0 and v765.heldN > v765.brakeN)) then
				v820 = false
			end
			local v822 = v784.rig
			if v822 and (v784.kind == "risen" and not v784.dead) then
				local v823 = v822.name
				if string.sub(v823, 1, 6) ~= "risen_" and v_u_188(v784) ~= v822.name then
					v_u_230(v784)
					v822 = nil
				end
			end
			if v820 then
				v784.hiddenSince = v757
				if v822 or v806 >= (not v764 and 28900 or v765.rigR2) then
					if v822 then
						::l156::
						local v824 = v784.vis
						if v822.corpse == true ~= v784.dead then
							v822.corpse = v784.dead
							v822.model:SetAttribute("Corpse", v784.dead and true or nil)
						end
						local v825 = not v784.dead
						if v825 then
							v825 = v784.state == v_u_11.lying
						end
						if v822.lying == true ~= v825 then
							v822.lying = v825
							v822.model:SetAttribute("Lying", v825 and true or nil)
						end
						if v784.dead then
							local v826 = v757 - v784.deadAt
							if v826 > 60 then
								local v827 = (v826 - 60) / 3
								v824 = v824 * (1 - math.clamp(v827, 0, 1))
							end
						end
						local v828 = v824 * 10 + 0.5
						local v829 = math.floor(v828) / 10
						if v829 ~= v822.vis then
							v822.vis = v829
							local v830 = 1 - v829
							for _, v831 in v822.parts do
								v831.LocalTransparencyModifier = v830
							end
						end
						if v764 then
							local v832
							if v822.far == true then
								v832 = v765.near2 < v806
							else
								v832 = v765.far2 < v806
							end
							if v832 ~= (v822.far == true) then
								v_u_16.farRig(v822, v832)
							end
						end
						if v784.kind == "riot" and not v784.dead then
							v_u_16.shield(v784, v822)
						end
						v763 = v763 + 1
						if v784.visTarget > 0 and not v784.fpCut then
							v765.wantN = v765.wantN + 1
							if not v784.dead then
								v765.wantL = v765.wantL + 1
							end
						end
						local v833 = v806 < 625 and 1 or (v806 < 2500 and 2 or (v806 < 6400 and 3 or 4))
						if v764 then
							v833 = v765.V.lod(math.sqrt(v806), v765.device)
						end
						if v833 > 1 and v_u_28 > 1 then
							local v834 = v833 * v_u_28
							local v835 = math.ceil(v834)
							v833 = math.min(v835, 8)
						end
						v784.lodAcc = v784.lodAcc + p756
						local v836 = (v_u_27 + v783) % v833 == 0
						if v784.dead and (v822.pose.settled and v757 - v784.deadAt > 1.5) then
							v836 = false
						end
						if v836 and v824 > 0.01 then
							local v837, v838, v839 = v_u_701(v784, v757)
							local v840 = v_u_693
							local v841 = v_u_693
							v_u_693.state = v837
							v840.act = v838
							v841.actDur = v839
							local v842 = v_u_693
							local v843 = v_u_693
							local v844 = v_u_693
							local v845 = v_u_693
							local v846 = v784.speed
							local v847 = v784.kind
							local v848 = v784.id // 4 % 4
							local v849 = v784.seed
							v842.speed = v846
							v843.kind = v847
							v844.style = v848
							v845.seed = v849
							v_u_693.t = v757
							local v850 = v_u_693
							local v851 = v_u_693
							local v852 = v_u_693
							local v853 = v784.flinch
							local v854 = v784.flinchX
							local v855 = v784.flinchZ
							v850.flinch = v853
							v851.flinchX = v854
							v852.flinchZ = v855
							local v856 = v_u_693
							local v857 = v_u_693
							local v858 = v_u_693
							local v859 = v784.deathSign
							local v860 = v784.wasLying
							local v861 = v784.riseFromLying
							v856.deathSign = v859
							v857.wasLying = v860
							v858.riseFromLying = v861
							v_u_693.headshot = v784.headshot
							local v862 = v_u_693
							local v863
							if v784.kind == "crawler" then
								v863 = true
							else
								local v864 = v784.limbs
								v863 = bit32.band(v864, 1) ~= 0
							end
							v862.legless = v863
							v_u_693.human = v784.def.human == true
							local v865 = v_u_693
							local v866 = v_u_693
							local v867 = v784.limbs
							local v868 = bit32.band(v867, 2) ~= 0
							local v869 = v784.limbs
							local v870 = bit32.band(v869, 4) ~= 0
							v865.limp = v868
							v866.armsHurt = v870
							local v871 = v_u_693
							local v872 = v784.limbs
							v871.climb = bit32.band(v872, 8) ~= 0
							local v873 = v_u_693
							local v874 = v784.limbs
							v873.wade = bit32.band(v874, 16) ~= 0
							local v875 = v_u_693
							local v876 = v_u_693
							local v877 = v784.hitPart
							local v878 = v784.hitKick
							v875.hitPart = v877
							v876.hitKick = v878
							local v879 = v_u_693
							local v880
							if v784.attackVariant >= 0 then
								v880 = v784.attackVariant
							else
								v880 = nil
							end
							v879.variant = v880
							v_u_693.notice = v757 - v784.noticeAt
							v_u_693.ring = v_u_16.ringPhase(v784.id)
							local v881 = v_u_693
							local v882
							if v784.kind == "risen" and v784.risenUser ~= 0 then
								v882 = v784.risenUser % 1000 % 3
							else
								v882 = nil
							end
							v881.lieVariant = v882
							v_u_9.update(v822.pose, v_u_693, v784.lodAcc)
							v784.lodAcc = 0
							local v883 = v_u_16.Td
							if v883 ~= nil and (v883.n > 0 and not v784.dead) then
								v883.apply(v784.id, v822.pose, v_u_29())
							end
						end
						if v_u_16.K and (v784.def.kind and not v784.dead) then
							v_u_16.K.rig(v784, v822, v757, v836, v806)
						end
						local v884
						if v784.dead then
							v884 = v784.yaw
						else
							v884 = v784.ryaw
						end
						local v885 = 0
						if v784.dead then
							local v886 = v757 - v784.deadAt
							if v886 > 60 then
								local v887 = (v886 - 60) / 3
								v885 = math.clamp(v887, 0, 1) * 1.6
							end
						end
						local v888 = v784.y + v822.rootHeight - v885
						local v889 = v784.x - v822.px
						local v890 = math.abs(v889)
						local v891 = v888 - v822.py
						local v892 = v890 + math.abs(v891)
						local v893 = v784.z - v822.pz
						if v892 + math.abs(v893) > 0.001 then
							::l270::
							local v894 = v784.x
							local v895 = v784.z
							v822.px = v894
							v822.py = v888
							v822.pz = v895
							v822.pyaw = v884
							local v896 = v_u_691
							local v897 = v822.root
							table.insert(v896, v897)
							local v898 = v_u_692
							local v899 = CFrame.new(v784.x, v888, v784.z) * CFrame.Angles(0, v884, 0)
							table.insert(v898, v899)
							if v766 and not v784.fpCut then
								v_u_16.Eyes.want(v784, v806, v822)
							end
							if not v_u_16.HeatOn or v784.fpCut then
								continue
							end
							v_u_16.Heat.want(v784, v806, v822)
						else
							local v900 = v884 - v822.pyaw
							if math.abs(v900) > 0.001 then
								goto l270
							end
							if v766 and not v784.fpCut then
								v_u_16.Eyes.want(v784, v806, v822)
							end
							if not v_u_16.HeatOn or v784.fpCut then
								continue
							end
							v_u_16.Heat.want(v784, v806, v822)
						end
					else
						if v766 and not v784.fpCut then
							v_u_16.Eyes.want(v784, v806, v822)
						end
						if not v_u_16.HeatOn or v784.fpCut then
							continue
						end
						v_u_16.Heat.want(v784, v806, v822)
					end
				else
					local v901, v902, v903, v904, v905, v906, v907, v908, v909, v910, v911, v912, v913, v914, v915, v916, v917, v918, v919, v920, v921, v922, v923, v924, v925, v926, v927, v928, v929, v930, v931, v932, v933, v934, v935, v936, v937, v938, v939, v940, v941, v942
					if v764 then
						if v784.visTarget > 0 then
							local v943
							if v765.far2 < v806 then
								v943 = v765.wantL < v765.farGuard
							else
								local v944 = v765.wantN
								local v945
								if v784.dead or v806 > v765.keep2 then
									v945 = v765.cap + v765.cfloor + 2
								else
									v945 = v765.hardCap
								end
								v943 = v944 < v945
							end
							if v943 then
								v822 = v_u_220(v784)
								v784.rig = v822
								if v822 then
									v901, v902, v903 = v_u_701(v784, v757)
									v904 = v_u_693
									v905 = v_u_693
									v_u_693.state = v901
									v904.act = v902
									v905.actDur = v903
									v906 = v_u_693
									v907 = v_u_693
									v908 = v_u_693
									v909 = v_u_693
									v910 = v784.speed
									v911 = v784.kind
									v912 = v784.id // 4 % 4
									v913 = v784.seed
									v906.speed = v910
									v907.kind = v911
									v908.style = v912
									v909.seed = v913
									v914 = v_u_693
									v915 = v_u_693
									v916 = v_u_693
									v_u_693.t = v757
									v914.flinch = 0
									v915.flinchX = 0
									v916.flinchZ = 0
									v917 = v_u_693
									v918 = v_u_693
									v919 = v_u_693
									v920 = v784.deathSign
									v921 = v784.wasLying
									v922 = v784.riseFromLying
									v917.deathSign = v920
									v918.wasLying = v921
									v919.riseFromLying = v922
									v_u_693.headshot = v784.headshot
									v923 = v_u_693
									v924 = v_u_693
									if v784.kind == "crawler" then
										v925 = true
									else
										v926 = v784.limbs
										v925 = bit32.band(v926, 1) ~= 0
									end
									v927 = v784.def.human == true
									v923.legless = v925
									v924.human = v927
									v928 = v_u_693
									v929 = v_u_693
									v930 = v784.limbs
									v931 = bit32.band(v930, 2) ~= 0
									v932 = v784.limbs
									v933 = bit32.band(v932, 4) ~= 0
									v928.limp = v931
									v929.armsHurt = v933
									v934 = v_u_693
									v935 = v784.limbs
									v934.climb = bit32.band(v935, 8) ~= 0
									v936 = v_u_693
									v937 = v784.limbs
									v936.wade = bit32.band(v937, 16) ~= 0
									v938 = v_u_693
									v_u_693.hitPart = 0
									v938.hitKick = 0
									v939 = v_u_693
									if v784.attackVariant >= 0 then
										v940 = v784.attackVariant
									else
										v940 = nil
									end
									v939.variant = v940
									v_u_693.notice = -1
									v_u_693.ring = v_u_16.ringPhase(v784.id)
									v941 = v_u_693
									if v784.kind == "risen" and v784.risenUser ~= 0 then
										v942 = v784.risenUser % 1000 % 3
									else
										v942 = nil
									end
									v941.lieVariant = v942
									v_u_9.update(v822.pose, v_u_693, 0.016666666666666666)
									v_u_9.snap(v822.pose)
								end
								if v822 then
									goto l156
								end
								if v766 and not v784.fpCut then
									v_u_16.Eyes.want(v784, v806, v822)
								end
								if not v_u_16.HeatOn or v784.fpCut then
									continue
								end
								v_u_16.Heat.want(v784, v806, v822)
							else
								if v822 then
									goto l156
								end
								if v766 and not v784.fpCut then
									v_u_16.Eyes.want(v784, v806, v822)
								end
								if not v_u_16.HeatOn or v784.fpCut then
									continue
								end
								v_u_16.Heat.want(v784, v806, v822)
							end
						else
							if v822 then
								goto l156
							end
							if v766 and not v784.fpCut then
								v_u_16.Eyes.want(v784, v806, v822)
							end
							if not v_u_16.HeatOn or v784.fpCut then
								continue
							end
							v_u_16.Heat.want(v784, v806, v822)
						end
					else
						v822 = v_u_220(v784)
						v784.rig = v822
						if v822 then
							v901, v902, v903 = v_u_701(v784, v757)
							v904 = v_u_693
							v905 = v_u_693
							v_u_693.state = v901
							v904.act = v902
							v905.actDur = v903
							v906 = v_u_693
							v907 = v_u_693
							v908 = v_u_693
							v909 = v_u_693
							v910 = v784.speed
							v911 = v784.kind
							v912 = v784.id // 4 % 4
							v913 = v784.seed
							v906.speed = v910
							v907.kind = v911
							v908.style = v912
							v909.seed = v913
							v914 = v_u_693
							v915 = v_u_693
							v916 = v_u_693
							v_u_693.t = v757
							v914.flinch = 0
							v915.flinchX = 0
							v916.flinchZ = 0
							v917 = v_u_693
							v918 = v_u_693
							v919 = v_u_693
							v920 = v784.deathSign
							v921 = v784.wasLying
							v922 = v784.riseFromLying
							v917.deathSign = v920
							v918.wasLying = v921
							v919.riseFromLying = v922
							v_u_693.headshot = v784.headshot
							v923 = v_u_693
							v924 = v_u_693
							if v784.kind == "crawler" then
								v925 = true
							else
								v926 = v784.limbs
								v925 = bit32.band(v926, 1) ~= 0
							end
							v927 = v784.def.human == true
							v923.legless = v925
							v924.human = v927
							v928 = v_u_693
							v929 = v_u_693
							v930 = v784.limbs
							v931 = bit32.band(v930, 2) ~= 0
							v932 = v784.limbs
							v933 = bit32.band(v932, 4) ~= 0
							v928.limp = v931
							v929.armsHurt = v933
							v934 = v_u_693
							v935 = v784.limbs
							v934.climb = bit32.band(v935, 8) ~= 0
							v936 = v_u_693
							v937 = v784.limbs
							v936.wade = bit32.band(v937, 16) ~= 0
							v938 = v_u_693
							v_u_693.hitPart = 0
							v938.hitKick = 0
							v939 = v_u_693
							if v784.attackVariant >= 0 then
								v940 = v784.attackVariant
							else
								v940 = nil
							end
							v939.variant = v940
							v_u_693.notice = -1
							v_u_693.ring = v_u_16.ringPhase(v784.id)
							v941 = v_u_693
							if v784.kind == "risen" and v784.risenUser ~= 0 then
								v942 = v784.risenUser % 1000 % 3
							else
								v942 = nil
							end
							v941.lieVariant = v942
							v_u_9.update(v822.pose, v_u_693, 0.016666666666666666)
							v_u_9.snap(v822.pose)
						end
						if v822 then
							goto l156
						end
						if v766 and not v784.fpCut then
							v_u_16.Eyes.want(v784, v806, v822)
						end
						if not v_u_16.HeatOn or v784.fpCut then
							continue
						end
						v_u_16.Heat.want(v784, v806, v822)
					end
				end
			else
				if v822 then
					local v946 = v757 - v784.hiddenSince
					local v947
					if v764 then
						if v765.heldN > v765.brakeN then
							v947 = -1
						elseif v765.far2 < v806 then
							v947 = v765.farRelease
						else
							v947 = v765.hideRelease
						end
					else
						v947 = 1.5
					end
					if v947 < v946 then
						v_u_230(v784)
						v822 = nil
					end
				end
				if v822 then
					goto l156
				end
				if v766 and not v784.fpCut then
					v_u_16.Eyes.want(v784, v806, v822)
				end
				if not v_u_16.HeatOn or v784.fpCut then
					continue
				end
				v_u_16.Heat.want(v784, v806, v822)
			end
		end
	end
	if v_u_16.Eyes then
		v_u_16.Eyes.finish(p756)
	end
	if v_u_16.Heat then
		v_u_16.Heat.finish(p756)
	end
	v_u_28 = v763 / 60
	v765.heldN = v763
	if #v_u_691 > 0 then
		workspace:BulkMoveTo(v_u_691, v_u_692, Enum.BulkMoveMode.FireCFrameChanged)
	end
	if v772 >= 6 and v_u_25 <= v757 then
		v_u_25 = v757 + 3.5
		local v948 = v773 / v772
		local v949 = v759 and (v759.Y or 0) or 0
		local v950 = v774 / v772
		local v951 = Vector3.new(v948, v949, v950)
		local v952 = v_u_7
		if v952 then
			v952 = v_u_7.controllers.Audio
		end
		if v952 and v952.zombie then
			local v953 = v952.zombie
			pcall(v953, "horde", v951, "walker")
		end
	end
	for v954, v955 in v_u_17 do
		if v955 >= v757 then
			continue
		end
		v_u_17[v954] = nil
	end
	local v956 = v_u_755
	local v957
	if v759 == nil or v_u_13.Character == nil then
		v957 = false
	else
		v957 = not v760
	end
	v956(v761, v762, v957)
	v_u_10.step(p756)
	v_u_15.step(v757, p756, v759)
	v_u_16.step(v757)
	if v_u_16.K then
		v_u_16.K.step(v757, p756, v759)
	end
	if v757 - v_u_26 > 1 then
		v_u_26 = v757
		local v958 = 0
		local v959 = 0
		local v960 = 0
		for _, v961 in v_u_14 do
			v958 = v958 + 1
			if v961.rig then
				v959 = v959 + 1
			else
				if not v764 or (v961.visTarget <= 0 or (v961.dead or v961.fpCut)) then
					continue
				end
				local v962 = v961.x - v761
				local v963 = v961.z - v762
				if v962 * v962 + v963 * v963 >= 3600 then
					continue
				end
				v960 = v960 + 1
			end
		end
		v765.noRigN = v960
		v_u_13:SetAttribute("ZombiesKnown", v958)
		v_u_13:SetAttribute("ZombiesRigs", v959)
		v_u_13:SetAttribute("ZombiesNearNoRig", v960)
	end
end
v_u_15.cc = nil
v_u_15.level = 0
v_u_15.coughAt = {}
function v_u_15.step(p965, p966, p967) -- name: step
	-- upvalues: (copy) v_u_15, (ref) v_u_10, (copy) v_u_1, (ref) v_u_7
	if v_u_15.level <= 0.01 and not (v_u_15.cc or v_u_10.hasGas()) then
		return
	else
		local v968 = not p967 and 0 or v_u_10.gasAt(p967)
		local v969 = v_u_15
		local v970 = v969.level
		local v971 = v968 - v_u_15.level
		local v972 = -p966 * (v_u_15.level < v968 and 4 or 1.5)
		v969.level = v970 + v971 * (1 - math.exp(v972))
		local v973 = workspace.CurrentCamera
		local v974 = v_u_15.cc
		if v_u_15.level > 0.01 then
			if not v974 or v974.Parent ~= v973 then
				if v974 then
					v974:Destroy()
				end
				v974 = Instance.new("ColorCorrectionEffect")
				v974.Name = "HushGasTint"
				v974:SetAttribute("HushGas", true)
				v974.Parent = v973
				v_u_15.cc = v974
			end
			local v975 = v_u_15.level
			local v976 = math.clamp(v975, 0, 1)
			v974.Enabled = true
			v974.TintColor = Color3.new(1, 1, 1):Lerp(Color3.fromRGB(214, 226, 160), v976)
			v974.Saturation = v976 * -0.25
			v974.Contrast = v976 * -0.1
			v974.Brightness = v976 * 0.03
		elseif v974 then
			v974:Destroy()
			v_u_15.cc = nil
		end
		if v_u_10.hasGas() then
			for _, v977 in v_u_1:GetPlayers() do
				local v978 = v977.Character
				if v978 then
					v978 = v978:FindFirstChild("HumanoidRootPart")
				end
				if v978 and v_u_10.gasAt(v978.Position) > 0.05 then
					if (v_u_15.coughAt[v977] or 0) > p965 then
						continue
					end
					v_u_15.coughAt[v977] = p965 + 1.5 + math.random() * 0.9
					local v979 = v978.Position + Vector3.new(0, 1.5, 0)
					local v980 = v_u_7
					if v980 then
						v980 = v_u_7.controllers.Audio
					end
					if not (v980 and v980.zombie) then
						continue
					end
					local v981 = v980.zombie
					pcall(v981, "cough", v979, nil)
				else
					if not v_u_15.coughAt[v977] or v_u_15.coughAt[v977] + 3 >= p965 then
						continue
					end
					v_u_15.coughAt[v977] = nil
				end
			end
		else
			table.clear(v_u_15.coughAt)
		end
	end
end
v_u_16.rings = {}
v_u_16.shieldUp = setmetatable({}, {
	["__mode"] = "k"
})
v_u_16.screens = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_16.ringPhase(p982) -- name: ringPhase
	-- upvalues: (copy) v_u_16
	local v983 = v_u_16.rings[p982]
	return not v983 and 0 or v983.phase
end
function v_u_16.glow(p984, p985) -- name: glow
	-- upvalues: (copy) v_u_16
	if p984 and p984.model.Parent then
		local v986 = v_u_16.screens[p984]
		if v986 == nil then
			v986 = p984.model:FindFirstChild("PhoneScreen", true) or false
			v_u_16.screens[p984] = v986
		end
		if v986 then
			local v987 = v986:FindFirstChild("PhoneGlow")
			if p985 > 0 then
				v986.Material = Enum.Material.Neon
				v986.Color = Color3.fromRGB(40, 70, 100):Lerp(Color3.fromRGB(160, 215, 255), p985)
				if v987 and v987:IsA("PointLight") then
					v987.Enabled = p984.vis > 0.05
					v987.Brightness = p985 * 2.5
					return
				end
			else
				v986.Material = Enum.Material.SmoothPlastic
				v986.Color = Color3.fromRGB(24, 34, 44)
				if v987 and v987:IsA("PointLight") then
					v987.Enabled = false
				end
			end
		end
	else
		return
	end
end
function v_u_16.stopRing(p988) -- name: stopRing
	-- upvalues: (copy) v_u_16
	local v989 = v_u_16.rings[p988]
	if v989 then
		v_u_16.rings[p988] = nil
		local v_u_990 = v989.h
		if v_u_990 then
			pcall(function()
				-- upvalues: (copy) v_u_990
				v_u_990:stop(0.12)
			end)
		end
		v_u_16.glow(v989.rig, 0)
	end
end
function v_u_16.startRing(p991, p992, p993) -- name: startRing
	-- upvalues: (copy) v_u_16, (ref) v_u_7
	v_u_16.stopRing(p991.id)
	local v994 = os.clock()
	local v995 = nil
	local v996 = v_u_7
	if v996 then
		v996 = v_u_7.controllers.Audio
	end
	if v996 and v996.play3D then
		local v997 = v996.play3D
		local v998 = p992 == 2 and "z_ring" or "z_buzz"
		local v999 = p991.x
		local v1000 = p991.y + 2.2
		local v1001 = p991.z
		local v1002 = Vector3.new(v999, v1000, v1001)
		local v1003, v1004 = pcall(v997, v998, v1002)
		if v1003 then
			v995 = v1004
		end
	end
	v_u_16.rings[p991.id] = {
		["z"] = p991,
		["phase"] = p992,
		["t0"] = v994,
		["untilT"] = v994 + p993,
		["h"] = v995,
		["rig"] = p991.rig
	}
end
v_u_16.Fp = {
	["on"] = false,
	["V"] = nil,
	["device"] = "pc",
	["devAt"] = 0,
	["cap"] = 48,
	["cut2"] = (1 / 0),
	["cutAt"] = 0,
	["buf"] = nil,
	["far2"] = 19600,
	["near2"] = 15876,
	["farCap"] = 24,
	["farGuard"] = 42,
	["farRelease"] = 0.4,
	["rigR2"] = 75625,
	["fbuf"] = nil,
	["reachAt"] = 0,
	["cbuf"] = nil,
	["ccut2"] = (1 / 0),
	["keep2"] = 256,
	["cfloor"] = 8,
	["hardCap"] = 60,
	["hideRelease"] = 0.6,
	["wantN"] = 0,
	["forceDevice"] = nil,
	["noRigN"] = 0,
	["watch"] = nil,
	["wantL"] = 0,
	["heldN"] = 0,
	["brakeN"] = 58,
	["buf"] = {},
	["fbuf"] = {},
	["cbuf"] = {}
}
function v_u_16.farRig(p1005, p1006) -- name: farRig
	p1005.far = p1006
	local v1007 = p1005.noShadow
	for v1008 in p1005.base do
		if not v1008.Parent or v1007 ~= nil and v1007[v1008] then
			continue
		end
		v1008.CastShadow = not p1006
	end
end
v_u_16.Hold = {
	["rt"] = -1,
	["set"] = nil,
	["failed"] = false,
	["set"] = {}
}
function v_u_16.holds(p1009) -- name: holds
	-- upvalues: (copy) v_u_16, (copy) v_u_1, (copy) v_u_13
	local v1010 = v_u_16.Hold
	if v1010.rt ~= p1009 then
		v1010.rt = p1009
		local v1011 = v_u_16.Zm.scan
		local v1012 = v1010.set
		local v1013 = v_u_1
		local v1014, v1015 = pcall(v1011, v1012, v1013:GetPlayers())
		if not v1014 then
			table.clear(v1010.set)
			if not v1010.failed then
				v1010.failed = true
				v_u_13:SetAttribute("ClientError", "ZombieRenderMath.scan: " .. tostring(v1015))
			end
		end
	end
	return v1010.set
end
v_u_16.Pull = {
	["n"] = 0,
	["set"] = nil,
	["set"] = {}
}
function v_u_16.pullSet(p1016, p1017, p1018, p1019, p1020, p1021) -- name: pullSet
	-- upvalues: (copy) v_u_16, (copy) v_u_14
	local v1022 = v_u_16.Pull
	if v_u_16.Zm == nil or not v_u_16.Fp.on then
		return false
	end
	local v1023
	if type(p1016) == "number" then
		v1023 = v_u_14[p1016]
	else
		v1023 = nil
	end
	if v1023 == nil or v1023.dead then
		return false
	end
	local v1024
	if type(p1017) == "number" and (p1017 == p1017 and p1017 ~= (1 / 0)) then
		v1024 = p1017 ~= (-1 / 0)
	else
		v1024 = false
	end
	if v1024 then
		local v1025
		if type(p1018) == "number" and (p1018 == p1018 and p1018 ~= (1 / 0)) then
			v1025 = p1018 ~= (-1 / 0)
		else
			v1025 = false
		end
		if v1025 then
			local v1026
			if type(p1019) == "number" and (p1019 == p1019 and p1019 ~= (1 / 0)) then
				v1026 = p1019 ~= (-1 / 0)
			else
				v1026 = false
			end
			if v1026 then
				local v1027
				if type(p1020) == "number" and (p1020 == p1020 and p1020 ~= (1 / 0)) then
					v1027 = p1020 ~= (-1 / 0)
				else
					v1027 = false
				end
				if v1027 then
					local v1028
					if type(p1021) == "number" and (p1021 == p1021 and p1021 ~= (1 / 0)) then
						v1028 = p1021 ~= (-1 / 0)
					else
						v1028 = false
					end
					if v1028 then
						if v1022.set[p1016] == nil then
							v1022.n = v1022.n + 1
						end
						v1022.set[p1016] = {
							["sx"] = nil,
							["sz"] = nil,
							["tx"] = nil,
							["tz"] = nil,
							["t0"] = nil,
							["x"] = nil,
							["z"] = nil,
							["last"] = nil,
							["seen"] = false,
							["sx"] = p1017,
							["sz"] = p1018,
							["tx"] = p1019,
							["tz"] = p1020,
							["t0"] = p1021,
							["x"] = p1017,
							["z"] = p1018,
							["last"] = p1021
						}
						return true
					end
				end
			end
		end
	end
	return false
end
function v_u_16.pullClear(p1029) -- name: pullClear
	-- upvalues: (copy) v_u_16
	local v1030 = v_u_16.Pull
	if v1030.set[p1029] ~= nil then
		v1030.set[p1029] = nil
		v1030.n = v1030.n - 1
	end
end
function v_u_16.pullReset() -- name: pullReset
	-- upvalues: (copy) v_u_16
	local v1031 = v_u_16.Pull
	table.clear(v1031.set)
	v1031.n = 0
end
function v_u_16.pullDraw(p1032, p1033, p1034, p1035) -- name: pullDraw
	-- upvalues: (copy) v_u_16
	local v1036 = v_u_16.Pull.set[p1032.id]
	if v1036 == nil then
		return
	else
		local v1037 = v_u_16.Zm
		if v1037.pullOver(v1036, p1035 - v1036.t0, v_u_16.holds(p1033)[p1032.id], p1034) then
			v_u_16.pullClear(p1032.id)
		else
			local v1038, v1039 = v1037.pullStep(v1036, p1035)
			p1032.x = v1038
			p1032.z = v1039
		end
	end
end
function v_u_16.fpBegin(p1040, p1041, p1042) -- name: fpBegin
	-- upvalues: (copy) v_u_16, (ref) v_u_7, (copy) v_u_13, (copy) v_u_14, (ref) v_u_11
	local v_u_1043 = v_u_16.Fp
	local v1044 = v_u_7.controllers.FpView
	local v1045
	if v1044 and v1044.viewOn then
		local v1046 = v1044.viewOn
		local v1047
		v1045, v1047 = pcall(v1046)
		if v1045 then
			v1045 = v1047 == true
		end
	else
		v1045 = false
	end
	if not v1045 then
		if v_u_1043.on then
			v_u_1043.on = false
			v_u_1043.cut2 = (1 / 0)
			v_u_1043.ccut2 = (1 / 0)
			v_u_1043.cutAt = 0
			v_u_1043.reachAt = 0
			v_u_16.pullReset()
		end
		return false
	end
	if v_u_1043.V == nil then
		local function v1048()
			-- upvalues: (ref) v_u_7
			return v_u_7.lib.ViewVis
		end
		local v1049, v1050 = pcall(v1048)
		if not v1049 or type(v1050) ~= "table" then
			v1050 = false
		end
		v_u_1043.V = v1050
	end
	if not v_u_1043.V then
		return false
	end
	if not v_u_1043.on or v_u_1043.devAt <= p1040 then
		v_u_1043.devAt = p1040 + 5
		local function v1052()
			-- upvalues: (ref) v_u_7, (copy) v_u_1043
			local v1051 = v_u_7.shared.Theme
			v_u_1043.device = v_u_1043.V.device(v1051.isTouch(), v1051.isPhone())
		end
		pcall(v1052)
		if v_u_1043.forceDevice ~= nil then
			v_u_1043.device = v_u_1043.forceDevice
		end
		v_u_1043.cap = v_u_1043.V.rigCap(v_u_1043.device)
		v_u_1043.farCap = v_u_1043.V.farCap(v_u_1043.device)
		v_u_1043.farGuard = v_u_1043.cap - 6
		v_u_1043.cfloor = v_u_1043.V.corpseFloor(v_u_1043.device)
		v_u_1043.hardCap = v_u_1043.cap + v_u_1043.V.NEAR_EXTRA
		v_u_1043.brakeN = v_u_1043.cap + v_u_1043.cfloor + 2
		v_u_1043.keep2 = v_u_1043.V.KEEP * v_u_1043.V.KEEP
		v_u_1043.hideRelease = v_u_1043.V.HIDE_RELEASE
	end
	v_u_1043.on = true
	if v_u_1043.reachAt <= p1040 then
		v_u_1043.reachAt = p1040 + 1
		local v1053 = v_u_13:GetAttribute("ZombieViewR")
		local v1054 = v_u_1043.V.setReach
		if type(v1053) ~= "number" then
			v1053 = v_u_1043.V.FAR
		end
		v1054(v1053)
		v_u_1043.far2 = v_u_1043.V.FAR * v_u_1043.V.FAR
		v_u_1043.near2 = v_u_1043.V.FAR * 0.9 * (v_u_1043.V.FAR * 0.9)
		v_u_1043.rigR2 = (v_u_1043.V.FADE_END + 5) * (v_u_1043.V.FADE_END + 5)
	end
	if v_u_1043.cutAt <= p1040 then
		v_u_1043.cutAt = p1040 + 0.25
		local v1055 = v_u_1043.buf
		local v1056 = v_u_1043.fbuf
		local v1057 = v_u_1043.cbuf
		table.clear(v1055)
		table.clear(v1056)
		table.clear(v1057)
		for _, v1058 in v_u_14 do
			if v1058.dead or v1058.state == v_u_11.dead then
				if v1058.vis <= 0.02 and v1058.visTarget <= 0 then
					continue
				end
				local v1059 = v1058.x - p1041
				local v1060 = v1058.z - p1042
				v1057[#v1057 + 1] = v1059 * v1059 + v1060 * v1060
			else
				if v1058.visTarget <= 0 then
					continue
				end
				local v1061 = v1058.x - p1041
				local v1062 = v1058.z - p1042
				local v1063 = v1061 * v1061 + v1062 * v1062
				v1055[#v1055 + 1] = v1063
				if v_u_1043.far2 >= v1063 then
					continue
				end
				v1056[#v1056 + 1] = v1063
			end
		end
		v_u_1043.cut2 = v_u_1043.V.cut2(v1055, v1056, v_u_1043.cap, v_u_1043.farCap)
		v_u_1043.ccut2 = v_u_1043.V.corpseCut2(v1057, #v1055, v_u_1043.cap, v_u_1043.cfloor)
	end
	return true
end
function v_u_16.fpSample(p1064) -- name: fpSample
	-- upvalues: (copy) v_u_50, (copy) v_u_14
	local v1065 = {
		["living"] = 0,
		["inFrame"] = 0,
		["rig"] = 0,
		["drawn"] = 0,
		["cutLiving"] = 0,
		["noRig"] = 0,
		["corpses"] = 0,
		["corpseRigs"] = 0,
		["list"] = nil,
		["set"] = nil,
		["list"] = {},
		["set"] = {}
	}
	local v1066 = v_u_50()
	if v1066 == nil then
		return v1065
	end
	local v1067 = p1064 * p1064
	for v1068, v1069 in v_u_14 do
		local v1070 = v1069.x - v1066.X
		local v1071 = v1069.z - v1066.Z
		local v1072 = v1070 * v1070 + v1071 * v1071
		if v1072 > v1067 then
			continue
		end
		if v1069.dead then
			v1065.corpses = v1065.corpses + 1
			if not v1069.rig then
				continue
			end
			v1065.corpseRigs = v1065.corpseRigs + 1
		else
			v1065.living = v1065.living + 1
			if v1069.rig then
				v1065.rig = v1065.rig + 1
				if v1069.rig.vis >= 0.5 then
					v1065.drawn = v1065.drawn + 1
				end
			end
			if v1069.fpCut == true then
				v1065.cutLiving = v1065.cutLiving + 1
			end
			if v1069.visTarget <= 0 then
				continue
			end
			v1065.inFrame = v1065.inFrame + 1
			if v1069.rig ~= nil or v1069.fpCut == true then
				continue
			end
			v1065.noRig = v1065.noRig + 1
			v1065.set[v1068] = true
			local v1073 = v1065.list
			local v1074 = { v1068, (math.sqrt(v1072)) }
			table.insert(v1073, v1074)
		end
	end
	table.sort(v1065.list, function(p1075, p1076)
		return p1075[2] < p1076[2]
	end)
	return v1065
end
function v_u_16.fpText(p1077) -- name: fpText
	-- upvalues: (copy) v_u_16
	local v1078 = v_u_16.Fp
	local v1079 = v_u_16.fpSample(p1077)
	local v1080 = {}
	for v1081, v1082 in v1079.list do
		if v1081 > 10 then
			break
		end
		local v1083 = string.format
		local v1084 = v1082[1]
		local v1085 = v1082[2]
		table.insert(v1080, v1083("%d@%.1f", v1084, v1085))
	end
	local v1086 = string.format
	local v1087 = v1078.on
	local v1088 = tostring(v1087)
	local v1089 = v1078.device
	local v1090 = v1078.cap
	local v1091 = v1078.cut2
	local v1092 = v1091 == (1 / 0) and "none" or (v1091 < 0 and "all" or string.format("%.1f studs", (math.sqrt(v1091))))
	local v1093 = v1078.ccut2
	local v1094 = v1093 == (1 / 0) and "none" or (v1093 < 0 and "all" or string.format("%.1f studs", (math.sqrt(v1093))))
	local v1095 = v1078.keep2
	local v1096 = math.sqrt(v1095) + 0.5
	return v1086("fptp=%s device=%s cap=%d cut=%s ccut=%s keep=%d held=%d/%d | living%.0f=%d inFrame=%d rig=%d drawn=%d cutLiving=%d noRigInFrame=%d | corpses%.0f=%d corpseRigs=%d | ids without rig: %s", v1088, v1089, v1090, v1092, v1094, math.floor(v1096), v1078.heldN, v1078.brakeN, p1077, v1079.living, v1079.inFrame, v1079.rig, v1079.drawn, v1079.cutLiving, v1079.noRig, p1077, v1079.corpses, v1079.corpseRigs, #v1080 <= 0 and "none" or table.concat(v1080, " "))
end
function v_u_16.fpWatchTick(p1097) -- name: fpWatchTick
	-- upvalues: (copy) v_u_16
	local v1098 = v_u_16.Fp.watch
	if v1098 ~= nil and not v1098.done then
		if v_u_16.Fp.heldN > v1098.maxHeld then
			v1098.maxHeld = v_u_16.Fp.heldN
		end
		if v_u_16.Fp.heldN > v_u_16.Fp.brakeN + 10 then
			v1098.over = v1098.over + 1
		end
		if v1098.nextT <= p1097 then
			v1098.nextT = p1097 + 0.1
			local v1099 = v_u_16.fpSample(v1098.radius)
			v1098.samples = v1098.samples + 1
			if v1099.noRig > v1098.maxNoRig then
				v1098.maxNoRig = v1099.noRig
			end
			for v1100 in v1099.set do
				local v1101 = v1098.since[v1100]
				if v1101 == nil then
					v1098.since[v1100] = p1097
					v1101 = p1097
				end
				if p1097 - v1101 <= (v1098.longest[v1100] or 0) then
					continue
				end
				v1098.longest[v1100] = p1097 - v1101
			end
			for v1102 in v1098.since do
				if v1099.set[v1102] ~= nil then
					continue
				end
				v1098.since[v1102] = nil
			end
		end
		if v1098.untilT <= p1097 then
			v1098.done = true
		end
	end
end
function v_u_16.fpWatchText() -- name: fpWatchText
	-- upvalues: (copy) v_u_16
	local v1103 = v_u_16.Fp.watch
	if v1103 == nil then
		return "no watch (zrender.fpcheck watch <seconds> [radius] starts one)"
	end
	local v1104 = {}
	for v1105, v1106 in v1103.longest do
		table.insert(v1104, { v1105, v1106 })
	end
	table.sort(v1104, function(p1107, p1108)
		return p1107[2] > p1108[2]
	end)
	local v1109 = {}
	for v1110, v1111 in v1104 do
		if v1110 > 8 then
			break
		end
		local v1112 = string.format
		local v1113 = v1111[1]
		local v1114 = v1111[2]
		table.insert(v1109, v1112("%d=%.1fs", v1113, v1114))
	end
	return string.format("watch %s samples=%d maxNoRigInFrame=%d maxRigsHeld=%d framesOver=%d longest without rig: %s", v1103.done and "done" or "running", v1103.samples, v1103.maxNoRig, v1103.maxHeld, v1103.over, #v1109 <= 0 and "none" or table.concat(v1109, " "))
end
function v_u_16.step(p1115) -- name: step
	-- upvalues: (copy) v_u_16, (copy) v_u_14
	if next(v_u_16.rings) ~= nil then
		local v1116 = {}
		for v1117, v1118 in v_u_16.rings do
			local v_u_1119 = v1118.z
			if v1118.untilT < p1115 or (v_u_1119.dead or v_u_14[v1117] ~= v_u_1119) then
				table.insert(v1116, v1117)
			else
				local v_u_1120 = v1118.h
				if v_u_1120 then
					pcall(function()
						-- upvalues: (copy) v_u_1120, (copy) v_u_1119
						local v1121 = v_u_1120
						local v1122 = v_u_1119.x
						local v1123 = v_u_1119.y + 2.2
						local v1124 = v_u_1119.z
						v1121:setPosition((Vector3.new(v1122, v1123, v1124)))
					end)
				end
				if v1118.rig ~= v_u_1119.rig then
					v_u_16.glow(v1118.rig, 0)
					v1118.rig = v_u_1119.rig
				end
				local v1125 = p1115 - v1118.t0
				local v1126
				if v1118.phase == 1 then
					local v1127 = v1125 * 22
					v1126 = math.sin(v1127) > 0 and 0.75 or 0.45
				else
					local v1128 = v1125 * 5
					local v1129 = math.sin(v1128)
					v1126 = math.abs(v1129) * 0.45 + 0.55
				end
				v_u_16.glow(v_u_1119.rig, v1126)
			end
		end
		for _, v1130 in v1116 do
			v_u_16.stopRing(v1130)
		end
	end
end
function v_u_16.shield(p1131, p1132) -- name: shield
	-- upvalues: (copy) v_u_16
	local v1133 = p1131.flags
	local v1134 = bit32.band(v1133, 64) ~= 0
	if v_u_16.shieldUp[p1132] == v1134 then
		return
	end
	v_u_16.shieldUp[p1132] = v1134
	for _, v1135 in p1132.model:GetDescendants() do
		if v1135:IsA("BasePart") then
			local v1136 = v1135.Name
			if string.sub(v1136, 1, 6) == "Shield" then
				local v1137 = v1135:GetAttribute("BaseT")
				if type(v1137) ~= "number" then
					v1137 = v1135.Transparency
					v1135:SetAttribute("BaseT", v1137)
				end
				v1135.Transparency = not v1134 and 1 or v1137
			else
				if not v1135:IsA("SurfaceGui") or v1135.Name ~= "ShieldText" then
					continue
				end
				v1135.Enabled = v1134
			end
		else
			if not v1135:IsA("SurfaceGui") or v1135.Name ~= "ShieldText" then
				continue
			end
			v1135.Enabled = v1134
		end
	end
end
function v_u_16.clang(p1138, p1139, p1140, p1141, p1142) -- name: clang
	-- upvalues: (ref) v_u_10, (ref) v_u_7
	if p1142 then
		local v1143 = v_u_10.muzzle
		local v1144 = -p1139
		local v1145 = -p1140
		v1143(p1138, (Vector3.new(v1144, 0.4, v1145)))
	end
	local v1146 = v_u_7
	if v1146 then
		v1146 = v_u_7.controllers.Audio
	end
	if v1146 and v1146.play3D then
		local v1147 = v1146.play3D
		local v1148 = {}
		local v1149 = p1141 * 0.1 + 0.8
		v1148.volume = math.min(1.4, v1149)
		pcall(v1147, "impact_ricochet", p1138, v1148)
	end
end
local function v_u_1151() -- name: clearAll
	-- upvalues: (copy) v_u_14, (copy) v_u_16, (copy) v_u_230, (copy) v_u_18, (copy) v_u_17, (ref) v_u_10
	for _, v1150 in v_u_14 do
		v_u_16.pullClear(v1150.id)
		v_u_16.stopRing(v1150.id)
		if v_u_16.K then
			v_u_16.K.removed(v1150)
		end
		v_u_230(v1150)
		v_u_14[v1150.id] = nil
	end
	table.clear(v_u_18)
	table.clear(v_u_17)
	v_u_16.pullReset()
	if v_u_10 then
		v_u_10.clear()
	end
	if v_u_16.Eyes then
		v_u_16.Eyes.reset()
	end
	if v_u_16.Heat then
		v_u_16.Heat.reset()
	end
end
local function v_u_1158(p1152) -- name: bodyPos
	-- upvalues: (ref) v_u_11
	local v1153 = p1152.def and (p1152.def.height or 5.8) or 5.8
	if p1152.state == v_u_11.lying or (p1152.state == v_u_11.dormant or (p1152.state == v_u_11.feed or p1152.state == v_u_11.down)) then
		v1153 = v1153 * 0.35
		v1155 = p1152.x
		v1156 = p1152.y + v1153 * 0.62
		v1157 = p1152.z
		return Vector3.new(v1155, v1156, v1157)
	end
	local v1154 = p1152.limbs
	if bit32.band(v1154, 1) == 0 then
		v1155 = p1152.x
		v1156 = p1152.y + v1153 * 0.62
		v1157 = p1152.z
		return Vector3.new(v1155, v1156, v1157)
	end
	v1153 = v1153 * 0.35
	local v1155 = p1152.x
	local v1156 = p1152.y + v1153 * 0.62
	local v1157 = p1152.z
	return Vector3.new(v1155, v1156, v1157)
end
function v4.targets(p1159, p1160) -- name: targets
	-- upvalues: (copy) v_u_14, (ref) v_u_11, (copy) v_u_1158, (ref) v_u_23
	local v1161 = {}
	local v1162, v1163, v1164
	if typeof(p1159) == "Vector3" and type(p1160) == "number" then
		v1162 = p1159.X
		v1163 = p1159.Z
		v1164 = p1160 * p1160
	else
		v1164 = (1 / 0)
		v1162 = 0
		v1163 = 0
	end
	for v1165, v1166 in v_u_14 do
		if v1166.dead or (v1166.state == v_u_11.dead or v1166.state == v_u_11.lying) then
			continue
		end
		if v1164 < (1 / 0) then
			local v1167 = v1166.x - v1162
			local v1168 = v1166.z - v1163
			if v1164 < v1167 * v1167 + v1168 * v1168 then
				continue
			end
		end
		local v1169 = {
			["id"] = v1165,
			["position"] = v_u_1158(v1166)
		}
		local v1170 = v_u_23
		if not v1170 then
			local v1171 = v1166.vis
			local v1172 = v1166.visTarget
			v1170 = math.max(v1171, v1172) >= 0.5
		end
		v1169.visible = v1170
		v1169.typeId = v1166.kind
		v1169.human = v1166.def and v1166.def.human == true and true or false
		v1169.state = v1166.state
		v1169.yaw = v1166.ryaw
		table.insert(v1161, v1169)
	end
	return v1161
end
function v4.nearest(p1173, p1174) -- name: nearest
	-- upvalues: (copy) v_u_14, (ref) v_u_11, (copy) v_u_1158
	if typeof(p1173) == "Vector3" then
		local v1175 = (type(p1174) ~= "number" or p1174 <= 0) and 14 or p1174
		local v1176 = os.clock()
		local v1177 = (1 / 0)
		local v1178 = nil
		for _, v1179 in v_u_14 do
			if v1179.dead or v1179.state == v_u_11.dead then
				continue
			end
			local v1180 = v1179.x - p1173.X
			local v1181 = v1179.z - p1173.Z
			local v1182 = v1180 * v1180 + v1181 * v1181
			if v1175 * v1175 < v1182 then
				continue
			end
			local v1183 = v1179.y - p1173.Y
			if math.abs(v1183) > 8 then
				continue
			end
			local v1184 = math.sqrt(v1182)
			local v1185
			if v1179.state == v_u_11.attack or v1179.state == v_u_11.aim then
				v1185 = true
			elseif v1179.actState == v_u_11.attack or v1179.actState == v_u_11.aim then
				v1185 = v1176 - v1179.actStart < 1.5
			else
				v1185 = false
			end
			if v1185 then
				v1184 = v1184 * 0.5
			end
			if v1184 >= v1177 then
				continue
			end
			v1178 = v1179
			v1177 = v1184
		end
		if v1178 then
			return v_u_1158(v1178)
		else
			return nil
		end
	else
		return nil
	end
end
function v4.setPull(p1186, p1187, p1188, p1189, p1190, p1191) -- name: setPull
	-- upvalues: (copy) v_u_16
	return v_u_16.pullSet(p1186, p1187, p1188, p1189, p1190, p1191)
end
function v4.clearPull(p1192) -- name: clearPull
	-- upvalues: (copy) v_u_16
	v_u_16.pullClear(p1192)
end
v4._test = {
	["newRig"] = function(p1193) -- name: newRig
		-- upvalues: (copy) v_u_160
		return v_u_160(p1193)
	end,
	["pool"] = function(p1194, p1195) -- name: pool
		-- upvalues: (copy) v_u_19
		local v1196 = v_u_19[p1194]
		if not v1196 then
			v1196 = {}
			v_u_19[p1194] = v1196
		end
		table.insert(v1196, p1195)
	end,
	["trim"] = function() -- name: trim
		-- upvalues: (copy) v_u_239
		return v_u_239()
	end,
	["counts"] = function() -- name: counts
		-- upvalues: (copy) v_u_19, (ref) v_u_22
		local v1197 = 0
		for _, v1198 in v_u_19 do
			v1197 = v1197 + #v1198
		end
		return v1197, v_u_22
	end,
	["setVis"] = function(p1199, p1200) -- name: setVis
		local v1201 = p1200 * 10 + 0.5
		local v1202 = math.floor(v1201) / 10
		if v1202 ~= p1199.vis then
			p1199.vis = v1202
			local v1203 = 1 - v1202
			for _, v1204 in p1199.parts do
				v1204.LocalTransparencyModifier = v1203
			end
		end
	end,
	["pulls"] = function() -- name: pulls
		-- upvalues: (copy) v_u_16
		return v_u_16.Pull.n
	end
}
function v4.previewRig(p1205) -- name: previewRig
	-- upvalues: (copy) v_u_57, (copy) v_u_66, (copy) v_u_108, (copy) v_u_113, (copy) v_u_100, (ref) v_u_9
	local v1206, v1207 = v_u_57(p1205)
	if not v1206 then
		v1206 = v_u_66(p1205)
		if v1206 then
			v1207 = "local"
		else
			v1207 = "none"
			v1206 = nil
		end
	end
	if v1207 == "local" or (v1207 == "none" or not (v1206 and v1206:IsA("Model"))) then
		return nil
	end
	local v1208 = v1206:Clone()
	v_u_108(v1208)
	v_u_113(v1208)
	local v1209 = v1208:FindFirstChild("HumanoidRootPart")
	if not v1209 then
		v1208:Destroy()
		return nil
	end
	local v1210, v1211 = v_u_100(v1206)
	for _, v_u_1212 in v1208:GetDescendants() do
		if v_u_1212:IsA("BasePart") then
			v_u_1212.CanCollide = false
			v_u_1212.CanQuery = false
			v_u_1212.CanTouch = false
			v_u_1212.Anchored = v_u_1212 == v1209
		elseif v_u_1212:IsA("Humanoid") then
			v_u_1212.AutomaticScalingEnabled = false
			v_u_1212.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			v_u_1212.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
			v_u_1212.BreakJointsOnDeath = false
			v_u_1212.RequiresNeck = false
			pcall(function()
				-- upvalues: (copy) v_u_1212
				v_u_1212.EvaluateStateMachine = false
			end)
		else
			if not (v_u_1212:IsA("Script") or (v_u_1212:IsA("LocalScript") or v_u_1212:IsA("Animator"))) then
				continue
			end
			v_u_1212:Destroy()
		end
	end
	v1209.Transparency = 1
	v1208:PivotTo(CFrame.new(0, v1210, 0) * v1209.CFrame:Inverse() * v1208:GetPivot())
	return {
		["model"] = v1208,
		["root"] = v1209,
		["rootHeight"] = v1210,
		["scale"] = v1211,
		["pose"] = v_u_9.new(v1208, v1210, v1211)
	}
end
function v4.init(p_u_1213) -- name: init
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (copy) v_u_53, (copy) v_u_722, (copy) v_u_16, (copy) v_u_13, (copy) v_u_14, (copy) v_u_35, (ref) v_u_21, (copy) v_u_19, (ref) v_u_22, (ref) v_u_28, (copy) v_u_115, (copy) v_u_310, (copy) v_u_239, (ref) v_u_23, (copy) v_u_1151
	v_u_7 = p_u_1213
	v_u_8 = p_u_1213.shared.ZombieTypes
	v_u_11 = v_u_8.STATE
	v_u_9 = p_u_1213.lib.ZombieAnimPose
	v_u_10 = p_u_1213.lib.ZombieAnimFx
	v_u_10.init((v_u_53()))
	v_u_722((v_u_53()))
	v_u_16.Eyes = p_u_1213.lib.ZombieEyes
	local v1214, v1215 = pcall(function()
		-- upvalues: (copy) p_u_1213
		return p_u_1213.lib.NvgHeat
	end)
	local v1216 = v_u_16
	if not v1214 or type(v1215) ~= "table" then
		v1215 = nil
	end
	v1216.Heat = v1215
	v_u_16.Punch = p_u_1213.lib.ZombiePunch
	local v1217, v1218 = pcall(function()
		-- upvalues: (copy) p_u_1213
		return p_u_1213.lib.TakedownZombiePose
	end)
	local v1219 = v_u_16
	if not v1217 or type(v1218) ~= "table" then
		v1218 = nil
	end
	v1219.Td = v1218
	local v1220, v1221 = pcall(function()
		-- upvalues: (copy) p_u_1213
		return p_u_1213.lib.ZombieRenderMath
	end)
	local v1222 = v_u_16
	local v1223
	if v1220 and type(v1221) == "table" then
		v1223 = v1221
	else
		v1223 = nil
	end
	v1222.Zm = v1223
	if v_u_16.Zm == nil then
		v_u_13:SetAttribute("ClientError", "ZombieRenderMath: " .. tostring(v1221))
	end
	local v1224, v1225 = pcall(function()
		-- upvalues: (copy) p_u_1213
		return p_u_1213.lib.ZombieHalloween
	end)
	local v1226 = v_u_16
	if not v1224 or type(v1225) ~= "table" then
		v1225 = nil
	end
	v1226.Halloween = v1225
	local function v1229()
		-- upvalues: (copy) p_u_1213, (ref) v_u_14, (ref) v_u_35, (ref) v_u_8, (ref) v_u_11, (ref) v_u_16
		local v1227 = p_u_1213.lib.ZombieKindsFx
		local v1228 = {
			["zombies"] = v_u_14,
			["audio"] = v_u_35,
			["T"] = v_u_8,
			["STATE"] = v_u_11
		}
		v1227.bind(p_u_1213, v1228)
		v_u_16.K = v1227
	end
	local v1230, v1231 = pcall(v1229)
	if not v1230 then
		v_u_16.K = nil
		v_u_13:SetAttribute("ClientError", "ZombieKindsFx: " .. tostring(v1231))
	end
	p_u_1213.command("zrender.eyes", function()
		-- upvalues: (ref) v_u_16
		local v1232 = v_u_16.Eyes
		if not v1232 then
			return "no ZombieEyes"
		end
		local v1233 = v1232.stats()
		local v1234 = string.format
		local v1235 = v1233.active
		return v1234("active=%s candidates=%d shown=%d losRays=%d pool=%d | %s", tostring(v1235), v1233.candidates, v1233.shown, v1233.los, v1233.pool, table.concat(v1232.shownList(), "; "))
	end)
	p_u_1213.command("zrender.stats", function()
		-- upvalues: (ref) v_u_14, (ref) v_u_21, (ref) v_u_19, (ref) v_u_22, (ref) v_u_28, (ref) v_u_115, (ref) v_u_16
		local v1236 = 0
		local v1237 = 0
		local v1238 = 0
		for _, v1239 in v_u_14 do
			v1236 = v1236 + 1
			if v1239.rig then
				v1237 = v1237 + 1
			end
			if not v1239.dead then
				continue
			end
			v1238 = v1238 + 1
		end
		local v1240 = 0
		local v1241 = v_u_21
		if v1241 then
			v1240 = v1241.Parent and #v1241:GetDescendants() or v1240
		end
		local v1242 = string.format
		local v1243 = 0
		local v1244 = "known %d rigs %d corpses %d pooled %d created %d folderInstances %d rigLoad %.2f ZombieRigSource %s"
		for _, v1245 in v_u_19 do
			v1243 = v1243 + #v1245
		end
		local v1246 = v1242(v1244, v1236, v1237, v1238, v1243, v_u_22, v1240, v_u_28, string.format("catalog=%d block=%d local=%d", v_u_115.catalog, v_u_115.block, v_u_115.own))
		local v1247 = string.format
		local v1248 = " | fptp on=%s device=%s cap=%d cut=%s"
		local v1249 = v_u_16.Fp.on
		local v1250 = tostring(v1249)
		local v1251 = v_u_16.Fp.device
		local v1252 = v_u_16.Fp.cap
		local v1253
		if v_u_16.Fp.cut2 == (1 / 0) then
			v1253 = "none"
		else
			local v1254 = string.format
			local v1255 = v_u_16.Fp.cut2
			v1253 = v1254("%.0f studs", (math.sqrt(v1255)))
		end
		local v1256 = v1247(v1248, v1250, v1251, v1252, v1253)
		local v1257 = string.format
		local v1258 = " ccut=%s wantN=%d"
		local v1259
		if v_u_16.Fp.ccut2 == (1 / 0) then
			v1259 = "none"
		elseif v_u_16.Fp.ccut2 < 0 then
			v1259 = "all"
		else
			local v1260 = string.format
			local v1261 = v_u_16.Fp.ccut2
			v1259 = v1260("%.0f studs", (math.sqrt(v1261)))
		end
		return v1246 .. v1256 .. v1257(v1258, v1259, v_u_16.Fp.wantN)
	end)
	p_u_1213.command("zrender.fpcheck", function(p1262)
		-- upvalues: (ref) v_u_16
		if p1262[1] ~= "watch" then
			local v1263 = v_u_16.fpText
			local v1264 = p1262[1]
			return v1263(tonumber(v1264) or 60)
		end
		local v1265 = p1262[2]
		local v1266 = tonumber(v1265)
		if v1266 == nil then
			return v_u_16.fpWatchText()
		end
		local v1267 = math.clamp(v1266, 0.5, 120)
		local v1268 = os.clock()
		local v1269 = v_u_16.Fp
		local v1270 = {
			["radius"] = nil,
			["nextT"] = nil,
			["untilT"] = nil,
			["samples"] = 0,
			["maxNoRig"] = 0,
			["maxHeld"] = 0,
			["over"] = 0,
			["since"] = nil,
			["longest"] = nil,
			["done"] = false
		}
		local v1271 = p1262[3]
		v1270.radius = tonumber(v1271) or 60
		v1270.nextT = v1268
		v1270.untilT = v1268 + v1267
		v1270.since = {}
		v1270.longest = {}
		v1269.watch = v1270
		return string.format("watching %.1f s, read the result with: zrender.fpcheck watch", v1267)
	end)
	p_u_1213.command("zrender.fpcap", function(p1272)
		-- upvalues: (ref) v_u_16
		if not game:GetService("RunService"):IsStudio() then
			return "Studio only"
		end
		local v1273 = p1272[1]
		if v1273 == "pc" or (v1273 == "tablet" or v1273 == "phone") then
			v_u_16.Fp.forceDevice = v1273
		else
			if v1273 ~= "auto" then
				local v1274 = v_u_16.Fp.forceDevice or "auto"
				return "usage: zrender.fpcap pc|tablet|phone|auto (now " .. tostring(v1274) .. ")"
			end
			v_u_16.Fp.forceDevice = nil
		end
		v_u_16.Fp.devAt = 0
		local v1275 = v_u_16.Fp.forceDevice or "auto"
		return "device budget: " .. tostring(v1275) .. " (takes effect at the next frame of the FP/TP mode)"
	end)
	p_u_1213.command("zrender.pumpkins", function()
		-- upvalues: (ref) v_u_14, (ref) v_u_16
		local v1276 = {}
		local v1277 = {}
		local v1278 = {}
		for v1279, v1280 in v_u_14 do
			local v1281 = v1280.rig
			if not v1281 then
				continue
			end
			local v1282
			if v1281.pumpkin then
				v1282 = v1276
			else
				v1282 = v1278
			end
			v1282[v1281.name] = (v1282[v1281.name] or 0) + 1
			local v1283 = v1281.model:FindFirstChild("Head")
			local v1284 = v1281.pumpkin
			if not v1284 or (not v1283 or #v1277 >= 8) then
				continue
			end
			local v1285 = v1283.CFrame:PointToObjectSpace(v1284.Position)
			local v1286 = string.format
			local v1287 = v1281.name
			local v1288 = v1284.Size.X
			local v1289 = v1283.Size.X
			local v1290 = v1283.Size.Z
			local v1291 = v1288 / math.max(v1289, v1290)
			local v1292 = v1285.X
			local v1293 = v1285.Y
			local v1294 = v1285.Z
			local v1295 = v1281.vis
			table.insert(v1277, v1286("%d %s w=%.2f off=%.2f,%.2f,%.2f vis=%.1f", v1279, v1287, v1291, v1292, v1293, v1294, v1295))
		end
		local function v1301(p1296) -- name: fmt
			local v1297 = {}
			for v1298, v1299 in p1296 do
				local v1300 = v1298 .. "=" .. v1299
				table.insert(v1297, v1300)
			end
			table.sort(v1297)
			return table.concat(v1297, ",")
		end
		local v1302 = v_u_16.Halloween
		local v1303 = string.format
		local v1304 = "enabled=%s pumpkin[%s] bare[%s] | %s"
		local v1305
		if v1302 == nil then
			v1305 = false
		else
			v1305 = v1302.enabled()
		end
		return v1303(v1304, tostring(v1305), v1301(v1276), v1301(v1278), table.concat(v1277, "; "))
	end)
	p_u_1213.command("zrender.follow", function(p1306)
		-- upvalues: (ref) v_u_310
		if p1306[1] == "log" then
			return table.concat(v_u_310.log, " | ")
		end
		if p1306[1] == "trace" then
			local v1307 = p1306[2]
			local v1308 = tonumber(v1307) or 1
			local v1309 = #v_u_310.trace
			local v1310 = table.concat
			local v1311 = v_u_310.trace
			local v1312 = #v_u_310.trace
			local v1313 = v1308 + 249
			return v1309 .. ";" .. v1310(v1311, ";", v1308, (math.min(v1312, v1313)))
		end
		local v1314 = v_u_310
		local v1315 = p1306[1]
		v1314.id = tonumber(v1315) or 0
		if v_u_310.id == 0 then
			return "stopped"
		end
		local v1316 = v_u_310
		local v1317 = v_u_310
		v_u_310.dists = {}
		v1316.k = 1
		v1317.n = 0
		table.clear(v_u_310.log)
		table.clear(v_u_310.trace)
		for v1318 in string.gmatch(p1306[2] or "25,15,8", "[^,]+") do
			local v1319 = v_u_310.dists
			local v1320 = tonumber(v1318) or 0
			table.insert(v1319, v1320)
		end
		return "following " .. v_u_310.id
	end)
	p_u_1213.command("zrender.heads", function()
		-- upvalues: (ref) v_u_14
		local v1321 = {}
		for v1322, v1323 in v_u_14 do
			local v1324 = v1323.rig
			local v1325
			if v1324 then
				v1325 = v1324.model:FindFirstChild("Head")
			else
				v1325 = v1324
			end
			if not v1325 or v1323.dead then
				continue
			end
			local v1326 = v1325.Position
			local v1327 = string.format
			local v1328 = v1324.name
			local v1329 = v1326.X
			local v1330 = v1326.Y
			local v1331 = v1326.Z
			table.insert(v1321, v1327("%d %s %.2f %.2f %.2f", v1322, v1328, v1329, v1330, v1331))
		end
		return table.concat(v1321, ";")
	end)
	p_u_1213.command("zrender.flat", function()
		-- upvalues: (ref) v_u_14
		local v1332 = {}
		for v1333, v1334 in v_u_14 do
			local v1335 = v1334.rig
			local v1336
			if v1335 then
				v1336 = v1335.model:FindFirstChild("Head")
			else
				v1336 = v1335
			end
			if not v1335 or (not v1336 or v1334.dead) then
				continue
			end
			local v1337 = v1335.root.CFrame.LookVector
			local v1338 = v1336.Position
			local v1339 = string.format
			local v1340 = v1334.state
			local v1341 = tostring(v1340)
			local v1342 = v1334.yaw
			local v1343 = v1334.ryaw
			local v1344 = v1337.X
			local v1345 = v1337.Z
			local v1346 = v1335.root.Position.X
			local v1347 = v1335.root.Position.Z
			local v1348 = v1338.X
			local v1349 = v1338.Y
			local v1350 = v1338.Z
			table.insert(v1332, v1339("%d st=%s yaw=%.2f ryaw=%.2f look=%.2f,%.2f root=%.1f,%.1f head=%.1f,%.1f,%.1f", v1333, v1341, v1342, v1343, v1344, v1345, v1346, v1347, v1348, v1349, v1350))
		end
		return table.concat(v1332, ";")
	end)
	p_u_1213.command("zrender.trim", function()
		-- upvalues: (ref) v_u_239, (ref) v_u_19, (ref) v_u_22
		local v1351 = v_u_239()
		local v1352 = string.format
		local v1353 = 0
		local v1354 = "trimmed %d pooled %d created %d"
		for _, v1355 in v_u_19 do
			v1353 = v1353 + #v1355
		end
		return v1352(v1354, v1351, v1353, v_u_22)
	end)
	p_u_1213.command("zrender.showall", function()
		-- upvalues: (ref) v_u_23
		v_u_23 = not v_u_23
		local v1356 = v_u_23
		return "showAll " .. tostring(v1356)
	end)
	p_u_1213.command("zrender.clear", function()
		-- upvalues: (ref) v_u_1151
		v_u_1151()
		return "cleared"
	end)
end
function v4.start() -- name: start
	-- upvalues: (ref) v_u_7, (copy) v_u_313, (copy) v_u_650, (copy) v_u_2, (copy) v_u_6, (copy) v_u_221, (copy) v_u_115, (copy) v_u_248, (copy) v_u_1151, (copy) v_u_239, (ref) v_u_28, (copy) v_u_13, (copy) v_u_19
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_313
		v_u_7.net.listenUnreliable("zombie.snap", v_u_313)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_650
		v_u_7.net.listen("zombie.event", function(p1357, p1358, ...)
			-- upvalues: (ref) v_u_650
			if type(p1357) == "string" then
				local v1359 = v_u_650
				local v1360, v1361 = pcall(v1359, p1357, p1358, ...)
				if not v1360 then
					warn("[ZombieRender] event", p1357, v1361)
				end
			end
		end)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_6, (ref) v_u_221, (ref) v_u_115, (ref) v_u_248
		local v1362 = v_u_2:WaitForChild("HushRuntime"):WaitForChild("ZombieTemplates", 60)
		if v1362 then
			local v1363 = os.clock()
			while v1362:GetAttribute("Ready") ~= true and os.clock() - v1363 < 60 do
				task.wait(0.5)
			end
			for v1364, v1365 in v_u_6 do
				for _ = 1, v1365 do
					local v1366 = v_u_221
					table.insert(v1366, v1364)
				end
			end
			local v1367 = v1362:WaitForChild("Roblox", 60)
			if v1367 then
				local v1368 = os.clock()
				while v1367:GetAttribute("Ready") ~= true and os.clock() - v1368 < 120 do
					task.wait(0.5)
				end
				if v_u_115.own > 0 then
					v_u_248()
				end
			end
		else
			return
		end
	end)
	v_u_7.session.onPlaceChanged(function(p1369, p1370)
		-- upvalues: (ref) v_u_1151, (ref) v_u_239, (ref) v_u_28, (ref) v_u_13, (ref) v_u_19
		if p1369 ~= p1370 and (p1369 == "Menu" or (p1369 == "Transit" or p1369 == "Hideout")) then
			v_u_1151()
			v_u_239()
			v_u_28 = 0
			v_u_13:SetAttribute("ZombiesKnown", 0)
			v_u_13:SetAttribute("ZombiesRigs", 0)
			v_u_13:SetAttribute("ZombiesNearNoRig", 0)
			local v1371 = v_u_13
			local v1372 = 0
			local v1373 = "ZombiesPooled"
			for _, v1374 in v_u_19 do
				v1372 = v1372 + #v1374
			end
			v1371:SetAttribute(v1373, v1372)
		end
	end)
end
function v4.step(p1375) -- name: step
	-- upvalues: (copy) v_u_221, (copy) v_u_225, (copy) v_u_16, (copy) v_u_14, (copy) v_u_755, (ref) v_u_10, (copy) v_u_50, (copy) v_u_964
	if #v_u_221 > 0 then
		v_u_225()
	end
	if v_u_16.Fp.watch ~= nil then
		v_u_16.fpWatchTick(os.clock())
	end
	if next(v_u_14) == nil then
		v_u_755(0, 0, false)
		v_u_10.step(p1375)
		v_u_16.Fp.heldN = 0
		if v_u_16.Eyes then
			v_u_16.Eyes.begin(os.clock(), nil)
			v_u_16.Eyes.finish(p1375)
		end
		if v_u_16.Heat and v_u_16.Heat.enabled() then
			local v1376, v1377 = v_u_50()
			local v1378 = v_u_16.Heat.begin
			local v1379 = os.clock()
			if v1377 then
				v1376 = nil
			end
			v1378(v1379, v1376)
			v_u_16.Heat.finish(p1375)
		end
	else
		v_u_964(p1375)
	end
end
return v4