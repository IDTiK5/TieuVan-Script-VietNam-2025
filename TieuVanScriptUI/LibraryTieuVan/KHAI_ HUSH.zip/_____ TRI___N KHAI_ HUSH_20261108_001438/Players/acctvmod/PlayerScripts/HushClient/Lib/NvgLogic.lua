-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / NvgLogic

local v_u_1 = {
	["POLL"] = 0.25,
	["GRACE"] = 0.75,
	["APPLY_EPS"] = 0.004,
	["LOS_TTL"] = 0.3,
	["LOS_KEEP"] = 3,
	["JUDGE_MAX"] = 24,
	["HEAT_ALPHA"] = 0.88,
	["MASK_ORDER"] = 2,
	["CLICK_PITCH"] = 0.8,
	["CLICK_VOLUME"] = 0.6
}
local v_u_2 = {
	[7] = true,
	[10] = true,
	[15] = true
}
function v_u_1.due(p3, p4) -- name: due
	-- upvalues: (copy) v_u_1
	return p3 - p4 >= v_u_1.POLL
end
function v_u_1.grace(p5, p6, p7) -- name: grace
	-- upvalues: (copy) v_u_1
	if p6 then
		return nil, false
	elseif p5 == nil then
		return p7, false
	else
		return p5, p7 - p5 >= v_u_1.GRACE
	end
end
function v_u_1.exclusion(p8, p9, p10) -- name: exclusion
	if p9 then
		if p8 and p10 then
			return "cut", false
		else
			return "none", p8
		end
	elseif p8 then
		return "restore", false
	else
		return "none", false
	end
end
function v_u_1.refusalText(p11, p12) -- name: refusalText
	if p12 == "hunt" then
		return nil
	end
	if type(p11) == "table" then
		local v13 = p11.refusalText
		if type(v13) == "function" then
			return p11.refusalText(p12)
		end
	end
	return nil
end
function v_u_1.maskAlpha(p14, p15, p16, p17, p18) -- name: maskAlpha
	if p18 == true or (p17 == true or (p15 ~= true or p16 ~= "fp")) then
		return 0
	end
	local v19 = (type(p14) ~= "number" or (p14 ~= p14 or (p14 == (1 / 0) or p14 == (-1 / 0)))) and 0 or p14
	if v19 ~= v19 then
		return 0
	end
	local v20 = math.min(1, v19)
	return math.max(0, v20)
end
function v_u_1.touchShown(p21, p22, p23, p24) -- name: touchShown
	local v25
	if p21 == nil or (p22 ~= "Raid" or p23 == true) then
		v25 = false
	else
		v25 = p24 ~= true
	end
	return v25
end
function v_u_1.changed(p26, p27, p28, p29) -- name: changed
	-- upvalues: (copy) v_u_1
	if p26 ~= p27 then
		return true
	end
	local v30 = p29 - p28
	if math.abs(v30) > v_u_1.APPLY_EPS then
		return true
	end
	local v31
	if p29 == p28 then
		v31 = false
	else
		v31 = p29 >= 1 and true or p29 <= 0
	end
	return v31
end
function v_u_1.mergeHalfDeg(p32, p33) -- name: mergeHalfDeg
	if p33 == nil then
		return p32
	end
	local v34 = math.deg(p33)
	return math.min(p32, v34)
end
function v_u_1.zombieHeat(p35, p36) -- name: zombieHeat
	-- upvalues: (copy) v_u_2
	if p36 == true then
		return false, false
	elseif type(p35) == "number" and v_u_2[p35] then
		return false, false
	else
		return true, p35 == 11
	end
end
function v_u_1.zombieBody(p37, p38, p39, p40, p41) -- name: zombieBody
	local v42 = (type(p37) ~= "number" or (p37 ~= p37 or (p37 == (1 / 0) or p37 == (-1 / 0)))) and 5.9 or p37
	local v43 = (v42 < 0.5 or v42 > 30) and 5.9 or v42
	local v44 = p41 == "crawler" and 0.4 or ((p40 == 14 or p40 == 11) and 0.55 or 1)
	local v45 = math.max(v44, 0.7)
	local v46 = v43 * 0.56 * v44
	local v47 = v43 * 0.34 * v45
	local v48 = v43 * 0.32 * v45
	local v49 = v43 * 0.19 * v45
	local v50 = v43 * 0.9
	if type(p38) == "number" and (p38 == p38 and (p38 ~= (1 / 0) and p38 ~= (-1 / 0))) then
		v50 = p38
	end
	local v51 = v50 * v44
	local v52 = v43 * 0.1
	if type(p39) == "number" and (p39 == p39 and (p39 ~= (1 / 0) and p39 ~= (-1 / 0))) then
		v52 = p39
	end
	local v53 = v52 * 2
	local v54
	if v53 == v53 then
		local v55 = math.min(3, v53)
		v54 = math.max(0.5, v55)
	else
		v54 = 0.5
	end
	return v46, v47, v48, v49, v51, v54
end
function v_u_1.playerBody() -- name: playerBody
	return 0.4, 2, 2.2, 1.2, 1.3
end
function v_u_1.transparency(p56, p57) -- name: transparency
	-- upvalues: (copy) v_u_1
	local v58 = (type(p56) ~= "number" or (p56 ~= p56 or (p56 == (1 / 0) or p56 == (-1 / 0)))) and 0 or p56
	local v59
	if v58 == v58 then
		local v60 = math.min(1, v58)
		v59 = math.max(0, v60)
	else
		v59 = 0
	end
	local v61 = (type(p57) ~= "number" or (p57 ~= p57 or (p57 == (1 / 0) or p57 == (-1 / 0)))) and 0 or p57
	local v62
	if v61 == v61 then
		local v63 = math.min(1, v61)
		v62 = math.max(0, v63)
	else
		v62 = 0
	end
	local v64 = (1 - v59 * v62 * v_u_1.HEAT_ALPHA) * 20 + 0.5
	return math.floor(v64) / 20
end
function v_u_1.sortNearest(p65, p66) -- name: sortNearest
	for v67 = 2, p66 do
		local v68 = p65[v67]
		local v69 = v67 - 1
		while v69 >= 1 and p65[v69].d2 > v68.d2 do
			p65[v69 + 1] = p65[v69]
			v69 = v69 - 1
		end
		p65[v69 + 1] = v68
	end
end
function v_u_1.pick(p70, p71, p72, p73, p74, p75) -- name: pick
	local v76 = 0
	local v77 = 0
	for v78 = 1, p71 do
		if p72 <= v76 or p73 <= v77 then
			break
		end
		v77 = v77 + 1
		local v79 = p70[v78]
		if not p74(v79) then
			continue
		end
		v76 = v76 + 1
		p75(v76, v79)
	end
	return v76, v77
end
function v_u_1.losGet(p80, p81, p82) -- name: losGet
	-- upvalues: (copy) v_u_1
	local v83 = p80[p81]
	if v83 == nil or p82 - v83.t >= v_u_1.LOS_TTL then
		return nil
	else
		return v83.ok
	end
end
function v_u_1.losPut(p84, p85, p86, p87) -- name: losPut
	local v88 = p84[p85]
	if v88 == nil then
		p84[p85] = {
			["t"] = p86,
			["ok"] = p87
		}
	else
		v88.t = p86
		v88.ok = p87
	end
end
function v_u_1.losPrune(p89, p90) -- name: losPrune
	-- upvalues: (copy) v_u_1
	local v91 = 0
	for v92, v93 in p89 do
		if p90 - v93.t <= v_u_1.LOS_KEEP then
			continue
		end
		p89[v92] = nil
		v91 = v91 + 1
	end
	return v91
end
return v_u_1