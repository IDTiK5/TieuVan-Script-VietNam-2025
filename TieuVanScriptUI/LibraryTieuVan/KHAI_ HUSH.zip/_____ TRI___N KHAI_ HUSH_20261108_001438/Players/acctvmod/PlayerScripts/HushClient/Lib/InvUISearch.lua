-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUISearch

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Players")
local v_u_4 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_5 = require(v_u_4:WaitForChild("Grid"))
local v_u_6 = {
	["MAX"] = 200,
	["CELL_MAX"] = 12
}
local v_u_7 = nil
local v_u_8 = nil
function v_u_6.list(p9) -- name: list
	-- upvalues: (copy) v_u_6
	local v10 = {}
	local v11
	if type(p9) == "table" then
		v11 = p9.ph
	else
		v11 = nil
	end
	if type(v11) ~= "table" then
		return v10
	end
	for _, v12 in v11 do
		if type(v12) ~= "table" then
			continue
		end
		local v13 = v12.uid
		if type(v13) ~= "string" or (#v12.uid < 1 or #v12.uid > 64) then
			continue
		end
		local v14 = v12.x
		local v15
		if type(v14) == "number" and (v14 == v14 and (v14 % 1 == 0 and v14 > -1000000)) then
			v15 = v14 < 1000000
		else
			v15 = false
		end
		if not v15 then
			continue
		end
		local v16 = v12.y
		local v17
		if type(v16) == "number" and (v16 == v16 and (v16 % 1 == 0 and v16 > -1000000)) then
			v17 = v16 < 1000000
		else
			v17 = false
		end
		if not v17 then
			continue
		end
		local v18 = v12.w
		local v19
		if type(v18) == "number" and (v18 == v18 and (v18 % 1 == 0 and v18 > -1000000)) then
			v19 = v18 < 1000000
		else
			v19 = false
		end
		if not v19 then
			continue
		end
		local v20 = v12.h
		local v21
		if type(v20) == "number" and (v20 == v20 and (v20 % 1 == 0 and v20 > -1000000)) then
			v21 = v20 < 1000000
		else
			v21 = false
		end
		if not v21 or (v12.x < 0 or (v12.y < 0 or (v12.w < 1 or (v12.h < 1 or (v12.w > v_u_6.CELL_MAX or v12.h > v_u_6.CELL_MAX))))) then
			continue
		end
		local v22 = {
			["uid"] = v12.uid,
			["w"] = v12.w,
			["h"] = v12.h,
			["x"] = v12.x,
			["y"] = v12.y
		}
		table.insert(v10, v22)
		if #v10 < v_u_6.MAX then
			continue
		end
	end
	return v10
end
function v_u_6.count(p23) -- name: count
	-- upvalues: (copy) v_u_6
	return #v_u_6.list(p23)
end
function v_u_6.blocks(p24, p25, p26, p27, p28, p29) -- name: blocks
	-- upvalues: (copy) v_u_6
	local v30
	if type(p24) == "table" then
		v30 = p24.ph
	else
		v30 = nil
	end
	if type(v30) ~= "table" or #v30 == 0 then
		return false
	end
	for _, v31 in v_u_6.list(p24) do
		if v31.uid == p29 or (p25 >= v31.x + v31.w or (v31.x >= p25 + p27 or (p26 >= v31.y + v31.h or v31.y >= p26 + p28))) then
			continue
		end
		return true
	end
	return false
end
function v_u_6.blocksItem(p32, p33, p34, p35, p36) -- name: blocksItem
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	local v37
	if type(p32) == "table" then
		v37 = p32.ph
	else
		v37 = nil
	end
	if type(v37) ~= "table" or (#v37 == 0 or type(p33) ~= "table") then
		return false
	end
	local v38, v39 = v_u_5.size({
		["id"] = nil,
		["r"] = nil,
		["uid"] = "",
		["x"] = 0,
		["y"] = 0,
		["n"] = 1,
		["id"] = p33.id,
		["r"] = p36 == true
	})
	return v_u_6.blocks(p32, p34, p35, v38, v39, p33.uid)
end
function v_u_6.bind(p40) -- name: bind
	-- upvalues: (ref) v_u_7
	v_u_7 = p40
end
local function v_u_54(p_u_41, p42) -- name: setScanning
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (copy) v_u_2
	if p_u_41.scanning ~= p42 then
		p_u_41.scanning = p42
		if v_u_8 == nil then
			local function v43()
				-- upvalues: (ref) v_u_4
				return require(v_u_4:WaitForChild("Theme"))
			end
			local v44, v45 = pcall(v43)
			if not v44 then
				v45 = false
			end
			v_u_8 = v45
		end
		local v46 = v_u_8 or nil
		if p_u_41.tween ~= nil then
			pcall(function()
				-- upvalues: (copy) p_u_41
				p_u_41.tween:Cancel()
			end)
			p_u_41.tween = nil
		end
		p_u_41.sweep.Visible = p42
		if v46 then
			local v47 = p_u_41.stroke
			local v48
			if p42 then
				v48 = v46.color.accent
			else
				v48 = v46.color.line
			end
			v47.Color = v48
			local v49 = p_u_41.mark
			local v50
			if p42 then
				v50 = v46.color.accent
			else
				v50 = v46.color.muted
			end
			v49.TextColor3 = v50
		end
		if p42 then
			p_u_41.grad.Offset = Vector2.new(-1, 0)
			local function v51()
				-- upvalues: (ref) v_u_2, (copy) p_u_41
				return v_u_2:Create(p_u_41.grad, TweenInfo.new(0.9, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), {
					["Offset"] = Vector2.new(1, 0)
				})
			end
			local v52, v53 = pcall(v51)
			if v52 and v53 then
				v53:Play()
				p_u_41.tween = v53
			end
		end
	end
end
local function v_u_67(p_u_55, p56) -- name: setFocusRim
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (ref) v_u_7, (copy) v_u_2
	if p_u_55.focusOn == p56 then
		return
	else
		p_u_55.focusOn = p56
		if p_u_55.focusTween ~= nil then
			pcall(function()
				-- upvalues: (copy) p_u_55
				p_u_55.focusTween:Cancel()
			end)
			p_u_55.focusTween = nil
		end
		if p56 then
			if v_u_8 == nil then
				local function v57()
					-- upvalues: (ref) v_u_4
					return require(v_u_4:WaitForChild("Theme"))
				end
				local v58, v59 = pcall(v57)
				if not v58 then
					v59 = false
				end
				v_u_8 = v59
			end
			local v60 = v_u_8 or nil
			if v_u_7 ~= nil and v60 then
				local v_u_61 = p_u_55.focusStroke
				if v_u_61 == nil then
					local v_u_62 = v_u_7.new("UIStroke", {
						["Name"] = "TutorialFocus",
						["Color"] = nil,
						["Thickness"] = 3,
						["ApplyStrokeMode"] = nil,
						["Transparency"] = 0,
						["Color"] = v60.color.accent,
						["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
					}, p_u_55.frame)
					local function v63()
						-- upvalues: (ref) v_u_62
						v_u_62.BorderStrokePosition = Enum.BorderStrokePosition.Inner
					end
					pcall(v63)
					p_u_55.focusStroke = v_u_62
					v_u_61 = v_u_62
				end
				v_u_61.Enabled = true
				local function v64()
					-- upvalues: (ref) v_u_2, (ref) v_u_61
					return v_u_2:Create(v_u_61, TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["Transparency"] = 0.6
					})
				end
				local v65, v66 = pcall(v64)
				if v65 and v66 then
					v66:Play()
					p_u_55.focusTween = v66
				end
			end
		else
			if p_u_55.focusStroke ~= nil then
				p_u_55.focusStroke.Enabled = false
			end
			return
		end
	end
end
local function v_u_96(p_u_68, p_u_69, p_u_70) -- name: make
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (ref) v_u_7, (copy) v_u_6
	if v_u_8 == nil then
		local function v71()
			-- upvalues: (ref) v_u_4
			return require(v_u_4:WaitForChild("Theme"))
		end
		local v72, v73 = pcall(v71)
		if not v72 then
			v73 = false
		end
		v_u_8 = v73
	end
	local v74 = v_u_8 or nil
	local v_u_75
	if v74 then
		v_u_75 = v74.color
	else
		v_u_75 = nil
	end
	local v76 = v_u_7.new
	local v77 = "TextButton"
	local v78 = {
		["Name"] = "Unexamined",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 3,
		["Active"] = true,
		["Selectable"] = true
	}
	local v79
	if v_u_75 then
		v79 = v_u_75.bgDeep
	else
		v79 = Color3.fromRGB(28, 28, 28)
	end
	v78.BackgroundColor3 = v79
	local v_u_80 = v76(v77, v78, nil)
	v_u_80:SetAttribute("Unexamined", true)
	local v81 = "UIStroke"
	local v82 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil
	}
	local v83
	if v_u_75 then
		v83 = v_u_75.line
	else
		v83 = Color3.fromRGB(70, 70, 70)
	end
	v82.Color = v83
	v82.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	local v_u_84 = v76(v81, v82, v_u_80)
	pcall(function()
		-- upvalues: (copy) v_u_84
		v_u_84.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	local v85 = "Frame"
	local v86 = {
		["Name"] = "Sweep",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Visible"] = false
	}
	local v87
	if v_u_75 then
		v87 = v_u_75.accent
	else
		v87 = Color3.fromRGB(200, 160, 60)
	end
	v86.BackgroundColor3 = v87
	v86.Size = UDim2.fromScale(1, 1)
	local v88 = v76(v85, v86, v_u_80)
	local v89 = v76("UIGradient", {
		["Rotation"] = 0,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.4, 1),
			NumberSequenceKeypoint.new(0.5, 0.78),
			NumberSequenceKeypoint.new(0.6, 1),
			NumberSequenceKeypoint.new(1, 1)
		})
	}, v88)
	local v90 = "TextLabel"
	local v91 = {
		["Name"] = "Mark",
		["BackgroundTransparency"] = 1,
		["Text"] = "?",
		["TextColor3"] = nil,
		["TextScaled"] = true,
		["Size"] = nil,
		["ZIndex"] = 5
	}
	local v92
	if v_u_75 then
		v92 = v_u_75.muted
	else
		v92 = Color3.fromRGB(150, 150, 150)
	end
	v91.TextColor3 = v92
	v91.Size = UDim2.fromScale(1, 1)
	local v93 = v76(v90, v91, v_u_80)
	if v74 and (v74.font and v74.font.heading) then
		v93.FontFace = v74.font.heading
	end
	v76("UITextSizeConstraint", {
		["MaxTextSize"] = 26,
		["MinTextSize"] = 8
	}, v93)
	v76("UIPadding", {
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingBottom"] = UDim.new(0, 2)
	}, v93)
	local function v94()
		-- upvalues: (ref) v_u_7, (copy) v_u_80
		if v_u_7.selection then
			v_u_80.SelectionImageObject = v_u_7.selection()
		end
	end
	pcall(v94)
	local v_u_95 = {
		["frame"] = nil,
		["stroke"] = nil,
		["sweep"] = nil,
		["grad"] = nil,
		["mark"] = nil,
		["scanning"] = false,
		["tween"] = nil,
		["uid"] = nil,
		["frame"] = v_u_80,
		["stroke"] = v_u_84,
		["sweep"] = v88,
		["grad"] = v89,
		["mark"] = v93,
		["uid"] = p_u_70
	}
	v_u_80.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_75, (copy) v_u_95, (copy) v_u_80
		if v_u_75 and not v_u_95.scanning then
			v_u_80.BackgroundColor3 = v_u_75.raised
		end
	end)
	v_u_80.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_75, (copy) v_u_80
		if v_u_75 then
			v_u_80.BackgroundColor3 = v_u_75.bgDeep
		end
	end)
	v_u_80.Activated:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_68, (copy) p_u_69, (copy) p_u_70
		v_u_6.examine(p_u_68, p_u_69, p_u_70)
	end)
	return v_u_95
end
function v_u_6.examine(p97, p98, p99) -- name: examine
	-- upvalues: (ref) v_u_7
	if v_u_7 and v_u_7.send then
		v_u_7.send(p97, {
			["op"] = "examine",
			["container"] = nil,
			["uid"] = nil,
			["container"] = p98,
			["uid"] = p99
		})
	end
	if v_u_7 and v_u_7.sound then
		v_u_7.sound("click")
	end
end
function v_u_6.clear(p100) -- name: clear
	if p100 then
		p100 = p100.ph
	end
	if type(p100) == "table" then
		for v101, v_u_102 in p100 do
			pcall(function()
				-- upvalues: (copy) v_u_102
				if v_u_102.tween ~= nil then
					v_u_102.tween:Cancel()
				end
				if v_u_102.focusTween ~= nil then
					v_u_102.focusTween:Cancel()
				end
				v_u_102.frame:Destroy()
			end)
			p100[v101] = nil
		end
	end
end
function v_u_6.render(p103, p104, p105, p106, p107) -- name: render
	-- upvalues: (ref) v_u_7, (copy) v_u_6, (copy) v_u_3, (copy) v_u_96, (copy) v_u_54, (copy) v_u_67
	if v_u_7 ~= nil and type(p104) == "table" then
		local v108 = p104.grid
		if type(v108) == "table" then
			local v109 = p104.grid.cells
			local v110 = v_u_6.list(p106)
			local v111 = p104.ph
			if type(v111) ~= "table" then
				v111 = {}
				p104.ph = v111
			end
			local v112 = v_u_3.LocalPlayer:GetAttribute("TutorialFocusId")
			local v113 = {}
			for _, v114 in v110 do
				v113[v114.uid] = true
				local v115 = v111[v114.uid]
				if v115 ~= nil and v115.frame.Parent == nil then
					v115 = nil
				end
				if v115 == nil then
					v115 = v_u_96(p103, p105, v114.uid)
					v111[v114.uid] = v115
				end
				v115.frame.Parent = v109
				if v_u_7.Pouch then
					v_u_7.Pouch.place(v109, v115.frame, v114.x, v114.y, v114.w, v114.h)
				end
				v_u_54(v115, v114.uid == p107)
				local v116 = v_u_67
				local v117
				if v112 == nil then
					v117 = false
				else
					v117 = v112 == p105
				end
				v116(v115, v117)
			end
			local v118 = {}
			for v119 in v111 do
				if v113[v119] then
					continue
				end
				table.insert(v118, v119)
			end
			for _, v120 in v118 do
				local v_u_121 = v111[v120]
				v111[v120] = nil
				pcall(function()
					-- upvalues: (copy) v_u_121
					if v_u_121.tween ~= nil then
						v_u_121.tween:Cancel()
					end
					if v_u_121.focusTween ~= nil then
						v_u_121.focusTween:Cancel()
					end
					v_u_121.frame:Destroy()
				end)
			end
			return
		end
	end
end
return v_u_6