-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ServerClock

local v_u_24 = {
	["MIN_PLAUSIBLE"] = 1600000000,
	["MAX_SKEW"] = 600,
	["OFF_TOLERANCE"] = 5,
	["off"] = nil,
	["source"] = nil,
	["osTime"] = nil,
	["plausible"] = function(p1, p2, p3) -- name: plausible
		-- upvalues: (copy) v_u_24
		if type(p1) ~= "number" or p1 ~= p1 then
			return false
		end
		if p1 < v_u_24.MIN_PLAUSIBLE then
			return false
		end
		local v4 = p1 - p2
		if math.abs(v4) <= v_u_24.MAX_SKEW then
			return true
		end
		local v5
		if p3 == nil then
			v5 = false
		else
			local v6 = v4 - p3
			v5 = math.abs(v6) <= v_u_24.OFF_TOLERANCE
		end
		return v5
	end,
	["pick"] = function(p7, p8, p9) -- name: pick
		-- upvalues: (copy) v_u_24
		if v_u_24.plausible(p7, p8, p9) then
			return p7
		else
			return p8 + (p9 or 0)
		end
	end,
	["calibrate"] = function(p10) -- name: calibrate
		-- upvalues: (copy) v_u_24
		if type(p10) ~= "number" or (p10 ~= p10 or p10 < v_u_24.MIN_PLAUSIBLE) then
			return false
		end
		local v11
		if v_u_24.osTime then
			v11 = v_u_24.osTime()
		else
			v11 = os.time()
		end
		v_u_24.off = p10 - v11
		return true
	end,
	["now"] = function() -- name: now
		-- upvalues: (copy) v_u_24
		local v12
		if v_u_24.osTime then
			v12 = v_u_24.osTime()
		else
			v12 = os.time()
		end
		local v13 = nil
		local v14 = v_u_24.source
		local v15
		if v14 then
			local v16
			v16, v15 = pcall(v14)
			if not v16 then
				v15 = v13
			end
		else
			local v17 = workspace.GetServerTimeNow
			local v18 = workspace
			local v19
			v19, v15 = pcall(v17, v18)
			if not v19 then
				v15 = v13
			end
		end
		return v_u_24.pick(v15, v12, v_u_24.off)
	end,
	["left"] = function(p20, p21) -- name: left
		-- upvalues: (copy) v_u_24
		if type(p20) == "number" and p20 == p20 then
			local v22 = p20 - v_u_24.now()
			local v23 = math.max(0, v22)
			if p21 == nil or p21 >= v23 then
				return v23
			else
				return p21
			end
		else
			return 0
		end
	end
}
return v_u_24