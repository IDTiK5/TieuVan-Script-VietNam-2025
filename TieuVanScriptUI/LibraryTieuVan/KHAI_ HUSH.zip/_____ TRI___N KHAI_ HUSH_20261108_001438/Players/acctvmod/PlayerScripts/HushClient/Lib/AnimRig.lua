-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimRig

local v_u_1 = {
	"Root",
	"Waist",
	"Neck",
	"LeftHip",
	"LeftKnee",
	"LeftAnkle",
	"RightHip",
	"RightKnee",
	"RightAnkle",
	"LeftShoulder",
	"LeftElbow",
	"LeftWrist",
	"RightShoulder",
	"RightElbow",
	"RightWrist"
}
local v_u_2 = {
	"Root",
	"Waist",
	"LeftHip",
	"LeftKnee",
	"RightHip",
	"RightKnee",
	"LeftShoulder",
	"LeftElbow",
	"RightShoulder",
	"RightElbow"
}
local v_u_3 = {}
v_u_3.__index = v_u_3
v_u_3.JOINT_ORDER = v_u_1
local v_u_4 = CFrame.identity
v_u_3.RIGID_RATIO = 0.3
local function v_u_14(p5, p6) -- name: frameFrom
	local v7 = p5.Unit
	local v8 = p6 - v7 * p6:Dot(v7)
	if v8.Magnitude < 0.0001 then
		local v9 = v7.Y
		if math.abs(v9) < 0.9 then
			v8 = Vector3.new(0, 1, 0) - v7 * v7.Y
		else
			v8 = Vector3.new(0, 0, 1) - v7 * v7.Z
		end
	end
	local v10 = v8.Unit
	local v11 = -v7
	local v12 = -v10
	local v13 = v11:Cross(v12)
	return CFrame.fromMatrix(Vector3.new(0, 0, 0), v13, v11, v12)
end
v_u_3.frameFrom = v_u_14
function v_u_3.new(p15) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	local v16 = p15:FindFirstChild("HumanoidRootPart")
	if not (v16 and v16:IsA("BasePart")) then
		return nil
	end
	local v17 = {}
	for _, v18 in p15:GetDescendants() do
		if not v18:IsA("Motor6D") or (not table.find(v_u_1, v18.Name) or (not v18.Part0 or (not v18.Part1 or v17[v18.Name]))) then
			continue
		end
		v17[v18.Name] = {
			["name"] = v18.Name,
			["m"] = v18,
			["c0"] = v18.C0,
			["c1"] = v18.C1,
			["c1i"] = v18.C1:Inverse(),
			["parent"] = v18.Part0.Name,
			["child"] = v18.Part1.Name
		}
	end
	for _, v19 in v_u_2 do
		if v17[v19] then
			continue
		end
		return nil
	end
	local v20 = v_u_3
	local v21 = setmetatable({
		["model"] = nil,
		["root"] = nil,
		["joints"] = nil,
		["order"] = nil,
		["bind"] = nil,
		["part"] = nil,
		["T"] = nil,
		["bone"] = nil,
		["bindDir"] = nil,
		["rigid"] = nil,
		["chainLen"] = nil,
		["ok"] = true,
		["model"] = p15,
		["root"] = v16,
		["joints"] = v17,
		["order"] = {},
		["bind"] = {},
		["part"] = {},
		["T"] = {},
		["bone"] = {},
		["bindDir"] = {},
		["rigid"] = {},
		["chainLen"] = {}
	}, v20)
	v21.bind[v16.Name] = v_u_4
	v21.part[v16.Name] = v_u_4
	for _, v22 in v_u_1 do
		local v23 = v17[v22]
		if not v23 then
			continue
		end
		local v24 = v21.order
		table.insert(v24, v23)
		local v25 = v21.bind[v23.parent]
		if not v25 then
			local v26 = v23.m.Part0
			v25 = v16.CFrame:ToObjectSpace(v26.CFrame)
			v21.bind[v23.parent] = v25
			v21.part[v23.parent] = v25
		end
		v21.bind[v23.child] = v25 * v23.c0 * v23.c1i
		v21.part[v23.child] = v21.bind[v23.child]
		v21.T[v22] = v_u_4
	end
	for _, v27 in { "Left", "Right" } do
		local v28 = v27 .. "Hip"
		local v29 = v27 .. "Knee"
		local v30 = v17[v28]
		local v31 = v17[v29]
		if v30 and v31 then
			local v32 = (v21.bind[v30.parent] * v30.c0).Position
			local v33 = (v21.bind[v31.parent] * v31.c0).Position
			v21.bone[v28] = (v33 - v32).Magnitude
			v21.bindDir[v28] = (v33 - v32).Unit
		end
		local v34 = v27 .. "Knee"
		local v35 = v27 .. "Ankle"
		local v36 = v17[v34]
		local v37 = v17[v35]
		if v36 and v37 then
			local v38 = (v21.bind[v36.parent] * v36.c0).Position
			local v39 = (v21.bind[v37.parent] * v37.c0).Position
			v21.bone[v34] = (v39 - v38).Magnitude
			v21.bindDir[v34] = (v39 - v38).Unit
		end
		local v40 = v27 .. "Shoulder"
		local v41 = v27 .. "Elbow"
		local v42 = v17[v40]
		local v43 = v17[v41]
		if v42 and v43 then
			local v44 = (v21.bind[v42.parent] * v42.c0).Position
			local v45 = (v21.bind[v43.parent] * v43.c0).Position
			v21.bone[v40] = (v45 - v44).Magnitude
			v21.bindDir[v40] = (v45 - v44).Unit
		end
		local v46 = v27 .. "Elbow"
		local v47 = v27 .. "Wrist"
		local v48 = v17[v46]
		local v49 = v17[v47]
		if not (v48 and v49) then
			continue
		end
		local v50 = (v21.bind[v48.parent] * v48.c0).Position
		local v51 = (v21.bind[v49.parent] * v49.c0).Position
		v21.bone[v46] = (v51 - v50).Magnitude
		v21.bindDir[v46] = (v51 - v50).Unit
	end
	for _, v52 in {
		{ "Shoulder", "Elbow", "Wrist" },
		{ "Hip", "Knee", "Ankle" }
	} do
		for _, v53 in { "Left", "Right" } do
			local v54 = v53 .. v52[1]
			local v55 = v53 .. v52[2]
			local v56 = v53 .. v52[3]
			local v57 = v21.bone[v54]
			local v58 = v21.bone[v55]
			local v59 = v17[v54]
			local v60 = v17[v56]
			if not v57 or (not v58 or (not v59 or (not v60 or math.min(v57, v58) >= 0.3 * (v57 + v58)))) then
				continue
			end
			local v61 = (v21.bind[v59.parent] * v59.c0).Position
			local v62 = (v21.bind[v60.parent] * v60.c0).Position
			if (v62 - v61).Magnitude <= 0.001 then
				continue
			end
			v21.rigid[v54] = (v62 - v61).Unit
			v21.chainLen[v54] = (v62 - v61).Magnitude
		end
	end
	return v21
end
function v_u_3.reset(p63) -- name: reset
	-- upvalues: (copy) v_u_4
	for _, v64 in p63.order do
		p63.T[v64.name] = v_u_4
		p63.part[v64.child] = p63.bind[v64.child]
	end
end
function v_u_3.fk(p65, p66) -- name: fk
	local v67 = p65.joints[p66]
	if v67 then
		p65.part[v67.child] = p65.part[v67.parent] * v67.c0 * p65.T[p66] * v67.c1i
	end
end
function v_u_3.setT(p68, p69, p70) -- name: setT
	if p68.joints[p69] then
		p68.T[p69] = p70
		p68:fk(p69)
	end
end
function v_u_3.pivot(p71, p72) -- name: pivot
	-- upvalues: (copy) v_u_4
	local v73 = p71.joints[p72]
	if v73 then
		return p71.part[v73.parent] * v73.c0
	else
		return v_u_4
	end
end
function v_u_3.bindPivot(p74, p75) -- name: bindPivot
	-- upvalues: (copy) v_u_4
	local v76 = p74.joints[p75]
	if v76 then
		return p74.bind[v76.parent] * v76.c0
	else
		return v_u_4
	end
end
function v_u_3.setRot(p77, p78, p79) -- name: setRot
	local v80 = p77.joints[p78]
	if v80 then
		local v81 = (p77.part[v80.parent] * v80.c0).Rotation
		local v82 = (p77.bind[v80.parent] * v80.c0).Rotation
		p77.T[p78] = v81:Inverse() * p79.Rotation * v82
		p77:fk(p78)
	end
end
function v_u_3.orientEnd(p83, p84, p85) -- name: orientEnd
	local v86 = p83.joints[p84]
	if v86 then
		local v87 = p83.bind[v86.child].Rotation
		p83:setRot(p84, p85.Rotation * v87:Inverse())
	end
end
function v_u_3.solve2(p88, p89, p90, p91, p92, p93, p94) -- name: solve2
	-- upvalues: (copy) v_u_4, (copy) v_u_14
	local v95 = p88.joints[p89]
	local v96 = p88.joints[p90]
	local v97 = p88.bone[p89]
	local v98 = p88.bone[p90]
	if not (v95 and (v96 and (v97 and (v98 and p88.joints[p91])))) then
		return 0
	end
	local v99 = p88:pivot(p89).Position
	local v100 = p92 - v99
	local v101 = v100.Magnitude
	local v102 = v101 / (v97 + v98)
	local v103 = (v97 + v98) * 0.9995
	local v104 = v97 - v98
	local v105 = math.abs(v104) + 0.02
	local v106 = math.min(v105, v103)
	local v107 = math.clamp(v101, v106, v103)
	local v108 = v100.Magnitude <= 0.0001 and Vector3.new(0, -1, 0) or v100.Unit
	local v109 = v99 + v108 * v107
	local v110 = (v97 * v97 - v98 * v98 + v107 * v107) / (2 * v107)
	local v111 = v97 * v97 - v110 * v110
	local v112 = math.max(0, v111)
	local v113 = math.sqrt(v112)
	local v114 = p93 - v108 * p93:Dot(v108)
	if v114.Magnitude < 0.0001 then
		local v115 = p94 - v108 * p94:Dot(v108)
		v114 = v115.Magnitude < 0.0001 and Vector3.new(0, 0, 1) or v115
	end
	local v116 = v114.Unit
	local v117 = p88.rigid[p89]
	if v117 then
		local v118 = (p88.part[v95.parent] * p88.bind[v95.parent]:Inverse()).Rotation
		p88:setRot(p89, CFrame.fromRotationBetweenVectors(v118:VectorToWorldSpace(v117), v108) * v118)
		p88:setT(p90, v_u_4)
		local v119 = v100.Magnitude
		local v120 = p88.chainLen[p89] or v97 + v98
		return v119 / math.max(v120, 0.001)
	end
	local v121 = v99 + v108 * v110 + v116 * v113
	local v122 = v_u_14(p88.bindDir[p89], p94)
	p88:setRot(p89, v_u_14(v121 - v99, v116) * v122:Inverse())
	local v123 = p88:pivot(p90).Position
	local v124 = v_u_14(p88.bindDir[p90], p94)
	p88:setRot(p90, v_u_14(v109 - v123, v116) * v124:Inverse())
	return v102
end
function v_u_3.apply(p125, p126) -- name: apply
	local v127 = p126 or 1
	for _, v128 in p125.order do
		local v129 = v128.m
		if not v129.Parent then
			continue
		end
		local v130 = p125.T[v128.name]
		if v127 < 1 then
			v129.Transform = v129.Transform:Lerp(v130, v127)
		else
			v129.Transform = v130
		end
	end
end
function v_u_3.alive(p131) -- name: alive
	local v132
	if p131.model.Parent == nil then
		v132 = false
	else
		v132 = p131.root.Parent ~= nil
	end
	return v132
end
local v_u_133 = {}
v_u_3.math = v_u_133
function v_u_133.damp(p134, p135, p136, p137) -- name: damp
	local v138 = p134 - p135
	local v139 = -p136 * p137
	return p135 + v138 * math.exp(v139)
end
function v_u_133.dampV(p140, p141, p142, p143) -- name: dampV
	local v144 = p140 - p141
	local v145 = -p142 * p143
	return p141 + v144 * math.exp(v145)
end
function v_u_133.dampCF(p146, p147, p148, p149) -- name: dampCF
	local v150 = -p148 * p149
	return p146:Lerp(p147, 1 - math.exp(v150))
end
function v_u_133.angleWrap(p151) -- name: angleWrap
	return (p151 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
end
function v_u_133.dampAngle(p152, p153, p154, p155) -- name: dampAngle
	-- upvalues: (copy) v_u_133
	local v156 = v_u_133.angleWrap(p153 - p152)
	local v157 = -p154 * p155
	return p152 + v156 * (1 - math.exp(v157))
end
function v_u_133.smooth(p158) -- name: smooth
	local v159 = math.clamp(p158, 0, 1)
	return v159 * v159 * (3 - v159 * 2)
end
function v_u_133.easeOut(p160) -- name: easeOut
	return 1 - (1 - math.clamp(p160, 0, 1)) ^ 3
end
function v_u_133.easeIn(p161) -- name: easeIn
	local v162 = math.clamp(p161, 0, 1)
	return v162 * v162 * v162
end
function v_u_133.lerp(p163, p164, p165) -- name: lerp
	return p163 + (p164 - p163) * p165
end
function v_u_133.remap(p166, p167, p168) -- name: remap
	if p168 == p167 then
		return 0
	end
	local v169 = (p166 - p167) / (p168 - p167)
	return math.clamp(v169, 0, 1)
end
return v_u_3