-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCutscenes

local v_u_29 = {
	["LOCKED_TITLE"] = "??",
	["NOTE"] = "A replay plays on your screen only and never changes your game. Skip it at any time after the first second.",
	["EMPTY"] = "Cutscenes are not available right now.",
	["LOADING"] = "Loading cutscenes...",
	["cleanView"] = function(p1) -- name: cleanView
		-- upvalues: (copy) v_u_29
		if type(p1) == "table" and p1.on == true then
			local v2 = p1.scenes
			if type(v2) == "table" then
				local v3 = {}
				local v4 = {}
				local v5 = 0
				for v12, v7 in p1.scenes do
					if #v3 >= 24 then
						break
					end
					if type(v7) ~= "table" then
						continue
					end
					local v8 = v7.id
					if type(v8) ~= "string" or (#v8 < 1 or (#v8 > 32 or not string.match(v8, "^[%w_]+$"))) then
						v8 = nil
					end
					if not v8 or v4[v8] then
						continue
					end
					v4[v8] = true
					local v9 = v7.scene
					if type(v9) ~= "string" or (#v9 < 1 or (#v9 > 32 or not string.match(v9, "^[%w_]+$"))) then
						v9 = nil
					end
					local v10
					if v7.unlocked == true then
						v10 = v9 ~= nil
					else
						v10 = false
					end
					local v11, v12
					if v10 then
						v11 = {
							["id"] = nil,
							["n"] = nil,
							["unlocked"] = true,
							["title"] = nil,
							["desc"] = nil,
							["scene"] = nil,
							["seconds"] = nil,
							["id"] = v8
						}
						local v13 = v7.n
						if type(v13) == "number" then
							v12 = v7.n
						end
						v11.n = v12
						local v14 = v7.title
						if type(v14) == "string" then
							if #v14 > 60 then
								v14 = string.sub(v14, 1, 60)
							end
						else
							v14 = nil
						end
						v11.title = v14 or v8
						local v15 = v7.desc
						if type(v15) == "string" then
							if #v15 > 260 then
								v15 = string.sub(v15, 1, 260)
							end
						else
							v15 = nil
						end
						v11.desc = v15
						v11.scene = v9
						local v16 = v7.seconds
						local v17
						if type(v16) == "number" and (v7.seconds > 0 and v7.seconds < 600) then
							local v18 = v7.seconds
							v17 = math.floor(v18)
						else
							v17 = nil
						end
						v11.seconds = v17
						v5 = v5 + 1
					else
						v11 = {
							["id"] = nil,
							["n"] = nil,
							["unlocked"] = false,
							["title"] = nil,
							["need"] = nil,
							["id"] = v8
						}
						local v19 = v7.n
						if type(v19) == "number" then
							v12 = v7.n
						end
						v11.n = v12
						v11.title = v_u_29.LOCKED_TITLE
						local v20 = v7.need
						if type(v20) == "string" then
							if #v20 > 60 then
								v20 = string.sub(v20, 1, 60)
							end
						else
							v20 = nil
						end
						v11.need = v20 or "Locked"
					end
					table.insert(v3, v11)
				end
				table.sort(v3, function(p21, p22)
					return p21.n < p22.n
				end)
				return {
					["rows"] = v3,
					["total"] = #v3,
					["unlocked"] = v5,
					["text"] = ("%d / %d UNLOCKED"):format(v5, #v3)
				}
			end
		end
		return nil
	end,
	["canPlay"] = function(p23, p24) -- name: canPlay
		if type(p24) == "table" and p24.unlocked == true then
			local v25 = p24.scene
			if type(v25) ~= "string" or (#v25 < 1 or (#v25 > 32 or not string.match(v25, "^[%w_]+$"))) then
				v25 = nil
			end
			if v25 ~= nil then
				if p23.hasIntro == true then
					if p23.place == "Menu" then
						if p23.gate == nil then
							if p23.transit == nil and p23.partyDeploying ~= true then
								if p23.introPlaying == true then
									return false, "A cutscene is already playing"
								else
									return true, nil
								end
							else
								return false, "A deployment is starting"
							end
						else
							return false, "Not available right now"
						end
					else
						return false, "Cutscenes play in the lobby"
					end
				else
					return false, "The cutscene player is not available"
				end
			end
		end
		local v26 = false
		if type(p24) == "table" then
			local v27 = p24.need
			if type(v27) == "string" then
				return v26, p24.need .. " to unlock it"
			end
		end
		return v26, "Not unlocked yet"
	end,
	["mustStop"] = function(p28) -- name: mustStop
		return p28.place ~= "Menu" and "left the lobby" or (p28.gate ~= nil and "gate" or ((p28.transit ~= nil or p28.partyDeploying == true) and "deploy" or nil))
	end
}
local function v_u_34() -- name: joinIntro
	local v30 = game:GetService("ReplicatedFirst"):FindFirstChild("JoinIntro")
	if v30 and v30:IsA("ModuleScript") then
		local v31 = require
		local v32, v33 = pcall(v31, v30)
		if v32 and type(v33) == "table" then
			return v33
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_29.env(p_u_35) -- name: env
	-- upvalues: (copy) v_u_34
	local v36 = p_u_35.cctx.player
	local v37 = v_u_34()
	local v_u_38 = false
	local function v39()
		-- upvalues: (ref) v_u_38, (copy) p_u_35
		v_u_38 = p_u_35.partyDeploying() == true
	end
	pcall(v39)
	local v40 = false
	if v37 then
		local v41 = v37.isPlaying
		if type(v41) == "function" then
			local v42 = v37.isPlaying
			local v43
			v40, v43 = pcall(v42)
			if v40 then
				v40 = v43 == true
			end
		end
	end
	local v44 = {
		["place"] = v36:GetAttribute("Place"),
		["partyDeploying"] = v_u_38,
		["gate"] = v36:GetAttribute("ReconnectGate"),
		["transit"] = v36:GetAttribute("TransitTo")
	}
	local v45
	if v37 == nil then
		v45 = false
	else
		local v46 = v37.play
		v45 = type(v46) == "function"
	end
	v44.hasIntro = v45
	v44.introPlaying = v40
	return v44
end
v_u_29.UNLOCK_PREFIX = "Cutscene unlocked: "
v_u_29.UNLOCK_SUB = "Replay it any time in TASKS, Cutscenes"
function v_u_29.unlockLine(p47, p48, p49, p50) -- name: unlockLine
	-- upvalues: (copy) v_u_29
	if type(p47) ~= "number" or (type(p48) ~= "number" or (p47 ~= p47 or (p48 ~= p48 or p47 >= p48))) then
		return nil, nil
	end
	if type(p49) == "table" then
		local v51 = p49.LIST
		if type(v51) == "table" then
			local v52 = nil
			for _, v53 in p49.LIST do
				if type(v53) ~= "table" then
					continue
				end
				local v54 = v53.stage
				if type(v54) ~= "number" then
					continue
				end
				local v55 = v53.title
				if type(v55) ~= "string" or (v53.title == "" or (p47 >= v53.stage or v53.stage > p48)) then
					continue
				end
				local v56
				if v53.new == true then
					local v57 = p49.READY
					if p50 == false then
						v56 = true
					elseif type(v57) == "table" then
						v56 = v57[v53.id] == false
					else
						v56 = false
					end
				else
					v56 = false
				end
				if v56 or v52 ~= nil and v53.stage <= v52.stage then
					continue
				end
				v52 = v53
			end
			if v52 == nil then
				return nil, nil
			else
				return v_u_29.UNLOCK_PREFIX .. v52.title, v_u_29.UNLOCK_SUB
			end
		end
	end
	return nil, nil
end
function v_u_29.playFailed(p58, p59) -- name: playFailed
	return (p58 == false or p59 == "error") and true or p59 == "title"
end
function v_u_29.watchUnlock(p_u_60) -- name: watchUnlock
	-- upvalues: (copy) v_u_29
	if type(p_u_60) ~= "table" or p_u_60._csUnlockWatch then
		return false
	end
	local function v71()
		-- upvalues: (copy) p_u_60, (ref) v_u_29
		local v_u_61 = p_u_60.cctx.player
		local v_u_62 = v_u_61:GetAttribute("StoryStage")
		v_u_61:GetAttributeChangedSignal("StoryStage"):Connect(function()
			-- upvalues: (copy) v_u_61, (ref) v_u_62, (ref) p_u_60, (ref) v_u_29
			local v_u_63 = v_u_61:GetAttribute("StoryStage")
			local v_u_64 = v_u_62
			v_u_62 = v_u_63
			local function v70()
				-- upvalues: (copy) v_u_64, (ref) p_u_60, (ref) v_u_29, (copy) v_u_63
				if v_u_64 == nil or p_u_60.cctx.config.flag("StoryScenes") ~= true then
					return
				else
					local v65 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					if v65 then
						v65 = v65:FindFirstChild("Shared")
					end
					if v65 then
						v65 = v65:FindFirstChild("Cutscenes")
					end
					if v65 and v65:IsA("ModuleScript") then
						local v_u_66 = true
						local function v67()
							-- upvalues: (ref) v_u_66, (ref) p_u_60
							v_u_66 = p_u_60.cctx.config.flag("StoryScenesNew") ~= false
						end
						pcall(v67)
						local v68, v69 = v_u_29.unlockLine(v_u_64, v_u_63, require(v65), v_u_66)
						if v68 then
							p_u_60.ui.toast(v68, "info", v69, 6)
						end
					end
				end
			end
			pcall(v70)
		end)
	end
	local v72 = pcall(v71)
	if v72 then
		p_u_60._csUnlockWatch = true
	end
	return v72
end
local v_u_73 = false
function v_u_29.isPlaying() -- name: isPlaying
	-- upvalues: (ref) v_u_73
	return v_u_73
end
function v_u_29.play(p_u_74, p_u_75) -- name: play
	-- upvalues: (ref) v_u_73, (copy) v_u_29, (copy) v_u_34
	if v_u_73 then
		return false, "A cutscene is already playing"
	end
	local v76 = v_u_29.env(p_u_74)
	local v77, v78 = v_u_29.canPlay(v76, p_u_75)
	if not v77 then
		return false, v78
	end
	local v_u_79 = v_u_34()
	if not v_u_79 then
		return false, "The cutscene player is not available"
	end
	v_u_73 = true
	task.spawn(function()
		-- upvalues: (ref) v_u_29, (copy) p_u_74, (copy) v_u_79, (copy) p_u_75, (ref) v_u_73
		local v_u_80 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_80, (ref) v_u_29, (ref) p_u_74, (ref) v_u_79
			while v_u_80 do
				task.wait(0.25)
				if not v_u_80 then
					return
				end
				local v81 = v_u_29.env
				local v82 = p_u_74
				local v83, v84 = pcall(v81, v82)
				if not v83 or v_u_29.mustStop(v84) == nil then
					continue
				end
				local v85 = v_u_79.skip
				pcall(v85)
			end
		end)
		local v86 = v_u_79.play
		local v87 = {
			["force"] = true,
			["scene"] = nil,
			["scene"] = p_u_75.scene
		}
		local v_u_88, v_u_89 = pcall(v86, v87)
		v_u_80 = false
		v_u_73 = false
		if v_u_29.playFailed(v_u_88, v_u_89) then
			local function v90()
				-- upvalues: (ref) p_u_74
				p_u_74.ui.toast("The scene could not be played", "warn", "Try again after the next menu open.")
			end
			pcall(v90)
		end
		local function v91()
			-- upvalues: (ref) p_u_74, (ref) p_u_75, (copy) v_u_88, (copy) v_u_89
			p_u_74.cctx.emit("cutscene.done", p_u_75.id, not v_u_88 and "error" or v_u_89)
		end
		pcall(v91)
	end)
	return true, nil
end
function v_u_29.drawList(p92, p93, p_u_94) -- name: drawList
	-- upvalues: (copy) v_u_29
	local v95 = p92.ui
	local v96 = p92.theme
	local v97 = v96.color
	local v98 = p92.kit
	local v99 = p_u_94.view
	if v99 == nil then
		if p_u_94.loading == true then
			v98.empty(p93, v_u_29.LOADING)
		else
			v98.empty(p93, v_u_29.EMPTY, 1)
			v95.button({
				["parent"] = nil,
				["name"] = "Retry",
				["text"] = "Retry",
				["kind"] = "secondary",
				["height"] = 40,
				["width"] = 140,
				["order"] = 2,
				["onClick"] = nil,
				["parent"] = p93,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_94
					local v100 = p_u_94.onRetry
					if type(v100) == "function" then
						p_u_94.onRetry()
					end
				end
			})
		end
	else
		local v101 = v96.touch(34) + 20
		local v102 = math.max(56, v101)
		for v103, v_u_104 in v99.rows do
			local v105 = v95.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Scene_" .. v_u_104.id,
				["BackgroundColor3"] = v97.raised,
				["Size"] = UDim2.new(1, -6, 0, v102),
				["LayoutOrder"] = v103
			}, p93)
			v95.stroke(v105, v97.line)
			local v106 = v95.new
			local v107 = "Frame"
			local v108 = {
				["Name"] = "State",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil
			}
			local v109
			if v_u_104.unlocked then
				v109 = v97.success
			else
				v109 = v97.muted
			end
			v108.BackgroundColor3 = v109
			v108.Size = UDim2.new(0, 3, 1, 0)
			v106(v107, v108, v105)
			local v110 = v_u_104.unlocked and 108 or 42
			local v111 = v95.label
			local v112 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v105,
				["text"] = v_u_104.title
			}
			local v113
			if v_u_104.unlocked then
				v113 = v97.text
			else
				v113 = v97.text2
			end
			v112.color = v113
			v112.position = UDim2.new(0, 14, 0.5, -17)
			v112.size = UDim2.new(1, -(v110 + 14), 0, 20)
			v111(v112)
			local v114
			if v_u_104.unlocked then
				v114 = not v_u_104.seconds and "Unlocked" or ("About %d seconds"):format(v_u_104.seconds)
			else
				v114 = v_u_104.need or "Locked"
			end
			local v115 = v95.label
			local v116 = {
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v105,
				["text"] = v114
			}
			local v117
			if v_u_104.unlocked then
				v117 = v97.text2
			else
				v117 = v97.accent
			end
			v116.color = v117
			v116.position = UDim2.new(0, 14, 0.5, 5)
			v116.size = UDim2.new(1, -(v110 + 14), 0, 14)
			v115(v116)
			if v_u_104.unlocked then
				local v119 = v95.button({
					["parent"] = nil,
					["name"] = "Play",
					["text"] = "Play",
					["kind"] = "primary",
					["icon"] = "chevronRight",
					["height"] = 34,
					["width"] = 96,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = v105,
					["position"] = UDim2.new(1, -12, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) p_u_94, (copy) v_u_104
						local v118 = p_u_94.onPlay
						if type(v118) == "function" then
							p_u_94.onPlay(v_u_104)
						end
					end
				})
				local v120 = p_u_94.up
				if typeof(v120) ~= "Instance" or not p_u_94.up:IsA("GuiObject") then
					continue
				end
				v119.NextSelectionUp = p_u_94.up
			else
				v95.icon("lock", {
					["parent"] = nil,
					["size"] = 18,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v105,
					["color"] = v97.muted,
					["position"] = UDim2.new(1, -14, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5)
				})
			end
		end
		return
	end
end
function v_u_29.drawDetail(p121, p122, p123) -- name: drawDetail
	-- upvalues: (copy) v_u_29
	local v124 = p121.ui
	local v125 = p121.theme.color
	local v126 = p121.kit
	local v127 = p123.view
	local v128 = v124.list({
		["parent"] = nil,
		["name"] = "Detail",
		["gap"] = 10,
		["parent"] = p122
	})
	v124.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new(980, (1 / 0))
	}, v128)
	local v129 = v124.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Size"] = UDim2.new(1, -8, 0, 64)
	}, v128)
	v124.label({
		["parent"] = nil,
		["text"] = "Story",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v129,
		["color"] = v125.text2,
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	v124.label({
		["parent"] = nil,
		["text"] = "Cutscenes",
		["style"] = "h1",
		["textSize"] = 30,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v129,
		["position"] = UDim2.fromOffset(0, 18),
		["size"] = UDim2.new(1, -170, 0, 40)
	})
	if v127 == nil then
		local v130 = v126.empty
		local v131
		if p123.loading == true then
			v131 = v_u_29.LOADING
		else
			v131 = v_u_29.EMPTY
		end
		v130(v128, v131, 2)
		return v128
	else
		v124.label({
			["parent"] = nil,
			["name"] = "Counts",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["parent"] = v129,
			["text"] = v127.text,
			["color"] = v125.text2,
			["position"] = UDim2.new(1, 0, 0, 30),
			["anchor"] = Vector2.new(1, 0),
			["size"] = UDim2.fromOffset(160, 16)
		})
		for v132, v133 in v127.rows do
			local v134 = v124.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Card_" .. v133.id,
				["BackgroundColor3"] = v125.raised,
				["Size"] = UDim2.new(1, -8, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = 1 + v132
			}, v128)
			v124.pad(v134, {
				18,
				16,
				12,
				12
			})
			local v135 = v124.new
			local v136 = "Frame"
			local v137 = {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil
			}
			local v138
			if v133.unlocked then
				v138 = v125.success
			else
				v138 = v125.muted
			end
			v137.BackgroundColor3 = v138
			v137.Position = UDim2.fromOffset(-18, -12)
			v137.Size = UDim2.new(0, 2, 1, 24)
			v135(v136, v137, v134)
			local v139 = v124.new("Frame", {
				["Name"] = "Stack",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v134)
			v124.layout(v139, "v", 6)
			local v140 = v124.new("Frame", {
				["Name"] = "Top",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 24)
			}, v139)
			local v141 = v124.label
			local v142 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v140,
				["text"] = v133.title
			}
			local v143
			if v133.unlocked then
				v143 = v125.text
			else
				v143 = v125.text2
			end
			v142.color = v143
			v142.size = UDim2.new(1, -110, 1, 0)
			v141(v142)
			v124.badge(v133.unlocked and "Unlocked" or "Locked", v133.unlocked and "success" or "muted", {
				["parent"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["height"] = 20,
				["parent"] = v140,
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["anchor"] = Vector2.new(1, 0.5)
			})
			local v144
			if v133.unlocked then
				v144 = v133.desc or ""
			else
				v144 = "Unlock: " .. (v133.need or "Locked")
			end
			if v144 ~= "" then
				local v145 = v124.label
				local v146 = {
					["parent"] = nil,
					["name"] = "Body",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v139,
					["text"] = v144
				}
				local v147
				if v133.unlocked then
					v147 = v125.text
				else
					v147 = v125.muted
				end
				v146.color = v147
				v145(v146)
			end
			if not (v133.unlocked and v133.seconds) then
				continue
			end
			v124.label({
				["parent"] = nil,
				["name"] = "Length",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["size"] = nil,
				["order"] = 3,
				["parent"] = v139,
				["text"] = ("About %d seconds"):format(v133.seconds),
				["color"] = v125.text2,
				["size"] = UDim2.new(1, 0, 0, 14)
			})
		end
		v124.label({
			["parent"] = nil,
			["name"] = "ReplayNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 90,
			["parent"] = v128,
			["text"] = v_u_29.NOTE,
			["color"] = v125.text2
		})
		return v128
	end
end
return v_u_29