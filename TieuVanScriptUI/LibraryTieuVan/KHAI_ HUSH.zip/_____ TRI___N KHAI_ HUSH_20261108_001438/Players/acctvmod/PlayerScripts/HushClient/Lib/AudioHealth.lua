-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioHealth

local v_u_1 = game:GetService("Players")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = {
	["t0"] = 0,
	["n"] = 0
}
local v_u_9 = {}
local v_u_10 = false
local v_u_11 = {
	["reported"] = 0,
	["dropped"] = 0,
	["watched"] = 0,
	["failed"] = 0
}
function v_u_2.report(p12, p13) -- name: report
	-- upvalues: (ref) v_u_11, (ref) v_u_6, (copy) v_u_1, (copy) v_u_8, (ref) v_u_4, (copy) v_u_9, (ref) v_u_10, (ref) v_u_3
	if type(p12) ~= "number" then
		return false
	end
	local v14 = v_u_11
	v14.failed = v14.failed + 1
	if v_u_6[p12] then
		local v15 = v_u_11
		v15.dropped = v15.dropped + 1
		local v16 = v_u_1.LocalPlayer
		if v16 then
			v16:SetAttribute("AudioHealth", string.format("reported %d dropped %d watched %d failed %d", v_u_11.reported, v_u_11.dropped, v_u_11.watched, v_u_11.failed))
		end
		return false
	end
	local v17 = os.clock()
	if v17 - v_u_8.t0 >= 60 then
		v_u_8.t0 = v17
		v_u_8.n = 0
	end
	local v18 = v_u_8.n
	local v19 = v_u_4.reportsPerMinute
	if (v19 == nil and 10 or v19) <= v18 then
		local v20 = v_u_11
		v20.dropped = v20.dropped + 1
		local v21 = v_u_1.LocalPlayer
		if v21 then
			v21:SetAttribute("AudioHealth", string.format("reported %d dropped %d watched %d failed %d", v_u_11.reported, v_u_11.dropped, v_u_11.watched, v_u_11.failed))
		end
		return false
	end
	local v22 = v_u_8
	v22.n = v22.n + 1
	v_u_6[p12] = true
	local v23 = v_u_11
	v23.reported = v23.reported + 1
	local v24 = v_u_9
	table.insert(v24, {
		["id"] = p12,
		["kind"] = p13 or "fail"
	})
	local v25 = v_u_1.LocalPlayer
	if v25 then
		v25:SetAttribute("AudioHealth", string.format("reported %d dropped %d watched %d failed %d", v_u_11.reported, v_u_11.dropped, v_u_11.watched, v_u_11.failed))
	end
	if not v_u_10 then
		v_u_10 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_3, (ref) v_u_10
			while #v_u_9 > 0 do
				local v26 = table.remove(v_u_9, 1)
				if v_u_3 then
					local v27 = v_u_3.fire
					local v28 = v26.id
					local v29 = v26.kind
					pcall(v27, "audio.report", v28, v29)
				end
				task.wait(0.6)
			end
			v_u_10 = false
		end)
	end
	return true
end
function v_u_2.onPreload(p30, p31) -- name: onPreload
	-- upvalues: (copy) v_u_5, (copy) v_u_2
	local v32 = string.match
	local v33 = tonumber(v32(p30, "(%d+)%s*$"))
	if v33 then
		if p31 == Enum.AssetFetchStatus.Success then
			v_u_5[v33] = true
		elseif p31 == Enum.AssetFetchStatus.Failure then
			v_u_2.report(v33, "preload")
		end
	else
		return
	end
end
function v_u_2.watchHandle(p_u_34) -- name: watchHandle
	-- upvalues: (copy) v_u_5, (ref) v_u_6, (copy) v_u_7, (ref) v_u_11, (ref) v_u_4, (copy) v_u_2
	if p_u_34 then
		p_u_34 = p_u_34.voice
	end
	if p_u_34 then
		p_u_34 = p_u_34.sound
	end
	if p_u_34 then
		local v35 = p_u_34.SoundId
		local v36 = string.match
		local v_u_37 = tonumber(v36(v35, "(%d+)%s*$"))
		if v_u_37 and not (v_u_5[v_u_37] or (v_u_6[v_u_37] or v_u_7[v_u_37])) then
			if p_u_34.IsLoaded then
				v_u_5[v_u_37] = true
			else
				v_u_7[v_u_37] = true
				local v38 = v_u_11
				v38.watched = v38.watched + 1
				local v_u_39 = p_u_34.SoundId
				local v40 = task.delay
				local v41 = v_u_4.loadTimeout
				v40(v41 == nil and 12 or v41, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_37, (copy) p_u_34, (ref) v_u_5, (copy) v_u_39, (ref) v_u_2
					v_u_7[v_u_37] = nil
					if p_u_34.IsLoaded then
						v_u_5[v_u_37] = true
					elseif p_u_34.Parent and p_u_34.SoundId == v_u_39 then
						v_u_2.report(v_u_37, "timeout")
					end
				end)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_2.isGood(p42) -- name: isGood
	-- upvalues: (copy) v_u_5
	return v_u_5[p42] == true
end
function v_u_2.stats() -- name: stats
	-- upvalues: (ref) v_u_11, (copy) v_u_9
	return string.format("reported %d dropped %d watched %d failed %d queue %d", v_u_11.reported, v_u_11.dropped, v_u_11.watched, v_u_11.failed, #v_u_9)
end
function v_u_2._reset() -- name: _reset
	-- upvalues: (ref) v_u_6, (copy) v_u_8, (ref) v_u_11, (copy) v_u_1
	v_u_6 = {}
	local v43 = v_u_8
	v_u_8.t0 = 0
	v43.n = 0
	v_u_11 = {
		["reported"] = 0,
		["dropped"] = 0,
		["watched"] = 0,
		["failed"] = 0
	}
	local v44 = v_u_1.LocalPlayer
	if v44 then
		v44:SetAttribute("AudioHealth", string.format("reported %d dropped %d watched %d failed %d", v_u_11.reported, v_u_11.dropped, v_u_11.watched, v_u_11.failed))
	end
end
function v_u_2.init(p45, p46) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_4
	v_u_3 = p45
	v_u_4 = p46 and p46.SOUND_AUDIT or {}
end
return v_u_2