-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayStats

local v_u_43 = {
	["KILLS_KEY"] = "pvpKills",
	["DEATHS_KEY"] = "pvpDeaths",
	["SIZE"] = 12,
	["EM"] = 0.6,
	["PVE"] = "RAIDS %d   EXTRACTS %d   SURVIVAL %d%%   KILLS %d",
	["PVP"] = { "RAIDS %d   EXTRACTS %d   SURVIVAL %d%%   PLAYER KILLS %d   DEATHS %d", "EXTRACTS %d   PLAYER KILLS %d   DEATHS %d", "PLAYER KILLS %d   DEATHS %d" },
	["pvpNumbers"] = function(p1) -- name: pvpNumbers
		-- upvalues: (copy) v_u_43
		local v2
		if type(p1) == "table" then
			local v3 = p1.stats
			v2 = type(v3) ~= "table" and {} or p1.stats
		else
			v2 = {}
		end
		local v4 = v2.raids
		local v5 = tonumber(v4) or 0
		local v6
		if v5 == v5 and (v5 ~= (1 / 0) and v5 ~= (-1 / 0)) then
			local v7 = math.floor(v5)
			v6 = math.max(0, v7)
		else
			v6 = 0
		end
		local v8 = v2.extracts
		local v9 = tonumber(v8) or 0
		local v10
		if v9 == v9 and (v9 ~= (1 / 0) and v9 ~= (-1 / 0)) then
			local v11 = math.floor(v9)
			v10 = math.max(0, v11)
		else
			v10 = 0
		end
		local v12
		if v6 > 0 then
			local v13 = v10 / v6 * 100 + 0.5
			v12 = math.floor(v13)
		else
			v12 = 0
		end
		local v14 = v2[v_u_43.KILLS_KEY]
		local v15 = tonumber(v14) or 0
		local v16
		if v15 == v15 and (v15 ~= (1 / 0) and v15 ~= (-1 / 0)) then
			local v17 = math.floor(v15)
			v16 = math.max(0, v17)
		else
			v16 = 0
		end
		local v18 = v2[v_u_43.DEATHS_KEY]
		local v19 = tonumber(v18) or 0
		if v19 ~= v19 or (v19 == (1 / 0) or v19 == (-1 / 0)) then
			return v6, v10, v12, v16, 0
		end
		local v20 = math.floor(v19)
		return v6, v10, v12, v16, math.max(0, v20)
	end,
	["widthOf"] = function(p21) -- name: widthOf
		-- upvalues: (copy) v_u_43
		local v22 = (utf8.len(p21) or #p21) * v_u_43.SIZE * v_u_43.EM
		return math.ceil(v22) + 1
	end,
	["line"] = function(p23, p24, p25) -- name: line
		-- upvalues: (copy) v_u_43
		if p24 == true then
			local v26, v27, v28, v29, v30 = v_u_43.pvpNumbers(p23)
			local v31 = { v_u_43.PVP[1]:format(v26, v27, v28, v29, v30), v_u_43.PVP[2]:format(v27, v29, v30), v_u_43.PVP[3]:format(v29, v30) }
			if type(p25) ~= "number" or p25 == 0 then
				return v31[1]
			end
			for _, v32 in v31 do
				if v_u_43.widthOf(v32) > p25 then
					continue
				end
				return v32
			end
			return v31[#v31]
		end
		local v33
		if type(p23) == "table" then
			local v34 = p23.stats
			v33 = type(v34) ~= "table" and {} or p23.stats
		else
			v33 = {}
		end
		local v35 = v33.raids
		local v36 = tonumber(v35) or 0
		local v37 = v33.extracts
		local v38 = tonumber(v37) or 0
		local v39
		if v36 > 0 then
			local v40 = v38 / v36 * 100 + 0.5
			v39 = math.floor(v40)
		else
			v39 = 0
		end
		local v41 = v_u_43.PVE
		local v42 = v33.kills
		return v41:format(v36, v38, v39, tonumber(v42) or 0)
	end
}
return v_u_43