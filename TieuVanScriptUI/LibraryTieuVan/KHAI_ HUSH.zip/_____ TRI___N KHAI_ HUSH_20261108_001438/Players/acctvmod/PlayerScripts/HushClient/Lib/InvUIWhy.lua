-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIWhy

local v_u_47 = {
	["waitingLabel"] = function(p1) -- name: waitingLabel
		local v2 = tonumber(p1) or 0
		local v3 = (v2 ~= v2 or v2 < 0) and 0 or math.floor(v2)
		return v3 <= 0 and "" or string.format("%d WAITING FOR ROOM", v3)
	end,
	["waitingTip"] = function(p4) -- name: waitingTip
		local v5 = tonumber(p4) or 0
		local v6 = (v5 ~= v5 or v5 < 0) and 0 or math.floor(v5)
		return v6 <= 0 and "" or (v6 == 1 and "1 item is waiting because your stash is full. Free some space and it moves in by itself." or string.format("%d items are waiting because your stash is full. Free some space and they move in by themselves.", v6))
	end,
	["tabTip"] = function(p7) -- name: tabTip
		local v8 = tonumber(p7) or 0
		return ((v8 ~= v8 or v8 < 0) and 0 or math.floor(v8)) <= 0 and "" or "Items are waiting for stash room."
	end,
	["stashSub"] = function(p9, p10, p11) -- name: stashSub
		-- upvalues: (copy) v_u_47
		local v12 = string.format("%d / %d", p9, p10)
		local v13 = v_u_47.waitingLabel(p11)
		if v13 == "" then
			return v12
		else
			return v12 .. "  |  " .. v13
		end
	end,
	["countInside"] = function(p14, p15) -- name: countInside
		-- upvalues: (copy) v_u_47
		local v16 = p15 or 0
		if type(p14) == "table" then
			local v17 = p14.items
			if type(v17) == "table" and v16 <= 4 then
				local v18 = 0
				for _, v19 in p14.items do
					v18 = v18 + (1 + v_u_47.countInside(v19, v16 + 1))
				end
				return v18
			end
		end
		return 0
	end,
	["discardBody"] = function(p20, p21, p22) -- name: discardBody
		local v23 = "Discard " .. p20
		if (p21 or 1) > 1 then
			v23 = v23 .. " x" .. tostring(p21)
		end
		local v24 = tonumber(p22) or 0
		local v25 = (v24 ~= v24 or v24 < 0) and 0 or math.floor(v24)
		if v25 > 0 then
			return v23 .. string.format("? It will be gone for good, with the %d %s inside it.", v25, v25 == 1 and "item" or "items")
		else
			return v23 .. "? It will be gone for good."
		end
	end,
	["hiddenHeader"] = function(p26, p27) -- name: hiddenHeader
		local v28 = tonumber(p26) or 0
		local v29 = (v28 ~= v28 or v28 < 0) and 0 or math.floor(v28)
		local v30 = tonumber(p27) or 0
		local v31 = (v30 ~= v30 or v30 < 0) and 0 or math.floor(v30)
		local v32 = string.format("%d %s", v29, v29 == 1 and "item" or "items")
		if v31 > 0 then
			return v32 .. string.format(", %d hidden (paid)", v31)
		else
			return v32
		end
	end,
	["hiddenTip"] = function() -- name: hiddenTip
		return "Paid items of other players are not shown for your account."
	end,
	["kitLabel"] = function(p33) -- name: kitLabel
		return p33 == "raid" and "Kit value" or "Kit sells"
	end,
	["kitTip"] = function(p34) -- name: kitTip
		return p34 == "raid" and {
			["title"] = "KIT VALUE",
			["body"] = "Base value of everything you carry. Traders pay less: see \'Sells for\' on each item."
		} or {
			["title"] = "KIT SELLS",
			["body"] = "What the traders would pay for everything you carry, each item at the best price."
		}
	end,
	["limitTail"] = function(p35) -- name: limitTail
		if type(p35) == "table" then
			local v36 = p35.w
			if type(v36) == "number" then
				local v37 = p35.h
				if type(v37) == "number" then
					return string.format("  |  %dx%d items only", p35.w, p35.h)
				end
			end
		end
		return ""
	end,
	["limitWhy"] = function(p38, p39) -- name: limitWhy
		if type(p39) == "table" then
			local v40 = p39.w
			if type(v40) == "number" then
				local v41 = p39.h
				if type(v41) == "number" then
					local v42 = p38 or "This container"
					local v43 = string.sub(v42, -1) == "s" and "hold" or "holds"
					return string.format("%s %s %dx%d items only.", v42, v43, p39.w, p39.h)
				end
			end
		end
		return nil
	end,
	["WHY"] = {
		["secure"] = "The secure container stays in its slot.",
		["empty"] = "Empty it first.",
		["itself"] = "It can\'t go inside itself.",
		["slot"] = "That doesn\'t go in this slot.",
		["raidSecure"] = "The secure container can\'t be swapped during a raid.",
		["quickGround"] = "Take it first.",
		["quickStash"] = "Only items in pockets, rig or backpack can go on a quick slot.",
		["noFit"] = "Doesn\'t fit this weapon.",
		["noStack"] = "These don\'t stack: different source."
	},
	["slotWhy"] = function(p44, p45) -- name: slotWhy
		-- upvalues: (copy) v_u_47
		if p44 == "raid" and p45 == "secure" then
			return v_u_47.WHY.raidSecure
		else
			return v_u_47.WHY.slot
		end
	end,
	["bagWhy"] = function(p46) -- name: bagWhy
		-- upvalues: (copy) v_u_47
		if p46 then
			return v_u_47.WHY.itself
		else
			return v_u_47.WHY.empty
		end
	end
}
local v_u_48 = {
	["lo_pockets"] = true,
	["lo_vest"] = true,
	["lo_bag"] = true
}
function v_u_47.quickSlotOk(p49, p50, p51, p52) -- name: quickSlotOk
	-- upvalues: (copy) v_u_47, (copy) v_u_48
	if p50 == "grid" then
		if p51 == nil or p51 ~= p52 then
			if p49 == "raid" or p51 ~= nil and v_u_48[p51] == true then
				return true, nil
			else
				return false, v_u_47.WHY.quickStash
			end
		else
			return false, v_u_47.WHY.quickGround
		end
	else
		return false, nil
	end
end
function v_u_47.quickEntryOk(p53, p54) -- name: quickEntryOk
	-- upvalues: (copy) v_u_48
	if p53 == "raid" then
		return true
	end
	local v55
	if p54 == nil then
		v55 = false
	else
		v55 = v_u_48[p54] == true
	end
	return v55
end
function v_u_47.stackWhy(p56, p57, p58) -- name: stackWhy
	-- upvalues: (copy) v_u_47
	if (tonumber(p58) or 1) <= 1 then
		return nil
	else
		return p56 and "That stack is full." or (p57 and "Items with parts or contents don\'t stack." or v_u_47.WHY.noStack)
	end
end
function v_u_47.attachNoneEntry() -- name: attachNoneEntry
	return {
		["text"] = "Attach (no matching weapon)",
		["say"] = "None of your guns takes this attachment. See the Fits line in its tooltip."
	}
end
function v_u_47.fitsLine(p59, p60, p61) -- name: fitsLine
	if p59 == "mag" then
		return nil
	end
	if p60 == "all" then
		return type(p59) == "string" and p59 ~= "" and { "Fits", "Any gun with a " .. string.lower(p59) .. " slot" } or nil
	end
	if type(p60) ~= "table" or #p60 == 0 then
		return nil
	end
	local v62 = {}
	for v63, v64 in p60 do
		if v63 > 3 then
			break
		end
		local v65 = p61(v64) or tostring(v64)
		table.insert(v62, v65)
	end
	local v66 = table.concat(v62, ", ")
	if #p60 > 3 then
		local v67 = #p60 - 3
		v66 = v66 .. ", +" .. tostring(v67)
	end
	return { "Fits", v66 }
end
function v_u_47.firValue() -- name: firValue
	return "Yes (counts for tasks, stacks only with found-in-raid items)"
end
function v_u_47.weightTip(p68) -- name: weightTip
	local v69 = 1.25
	local v70 = 0.45
	if type(p68) == "table" then
		local v71 = p68.overweightNoSprint
		v69 = tonumber(v71) or v69
		local v72 = p68.overweightMinMul
		v70 = tonumber(v72) or v70
	end
	local v73 = {
		["title"] = "CARRY WEIGHT",
		["body"] = nil
	}
	local v74 = string.format
	local v75 = v70 * 100 + 0.5
	local v76 = math.floor(v75)
	local v77 = v69 * 100 + 0.5
	v73.body = v74("Over your limit you walk slower, down to %d %% speed at twice the limit. Above %d %% of the limit you can\'t sprint. Strength raises the limit.", v76, (math.floor(v77)))
	return v73
end
function v_u_47.weightStage(p78, p79, p80) -- name: weightStage
	local v81 = tonumber(p78) or 0
	local v82 = tonumber(p79) or 0
	return (v82 <= 0 or v81 <= v82) and 0 or (v82 * (tonumber(p80) or 1.25) < v81 and 2 or 1)
end
function v_u_47.weightTag(p83, p84, p85, p86) -- name: weightTag
	-- upvalues: (copy) v_u_47
	local v87 = v_u_47.weightStage(p83, p84, p85)
	if v87 == 0 then
		return ""
	else
		local v88 = p86 and "OVER" or "OVERWEIGHT"
		if v87 == 2 then
			return "  " .. v88 .. "  NO SPRINT"
		else
			return "  " .. v88 .. "  SLOW"
		end
	end
end
function v_u_47.weightToast(p89, p90) -- name: weightToast
	return p90 > p89 and p90 ~= 0 and (p90 == 2 and "Overweight: you can\'t sprint. Drop something or get stronger." or "Overweight: you walk slower. Drop something or get stronger.") or nil
end
function v_u_47.weightWord(p91, p92, p93) -- name: weightWord
	-- upvalues: (copy) v_u_47
	local v94 = v_u_47.weightStage(p91, p92, p93)
	return v94 == 2 and "Weight: no sprint" or (v94 == 1 and "Weight: slow" or "Weight")
end
v_u_47.SAFE_RULE = "Keys and ammo in here can\'t be used, and it can\'t be swapped during a raid."
v_u_47.SAFE_TAIL = "survives death"
v_u_47.SAFE_SLOT_TIP = "Stays in its slot during a raid."
function v_u_47.safeTail(p95) -- name: safeTail
	-- upvalues: (copy) v_u_47
	return p95 ~= "secure" and p95 ~= "lo_secure" and "" or "  |  " .. v_u_47.SAFE_TAIL
end
function v_u_47.pocketAmmoLabel(p96) -- name: pocketAmmoLabel
	return p96 and "Pocket ammo: moves" or "Pocket ammo: stays"
end
function v_u_47.insureHint(p97, p98, p99) -- name: insureHint
	return p97 == "grid" and (p98 ~= nil and p99[p98] == true) and {
		["text"] = "Insure (equip it first)",
		["say"] = "Equip it first. Only worn gear can be insured."
	} or nil
end
function v_u_47.msgPlaceOk(p100) -- name: msgPlaceOk
	return p100 == "Raid" and true or p100 == "Hideout"
end
function v_u_47.loadingStash() -- name: loadingStash
	return "Loading your stash..."
end
function v_u_47.fallbackSubtitle() -- name: fallbackSubtitle
	return "The inventory is not ready yet. It retries by itself."
end
v_u_47.NAME_HINT = "Letters, digits, spaces and . , \' ! ? & + ( ) # / _ : * and hyphen only."
function v_u_47.nameDropped(p101) -- name: nameDropped
	-- upvalues: (copy) v_u_47
	if p101 then
		return v_u_47.NAME_HINT
	else
		return nil
	end
end
function v_u_47.sellOffered(p102) -- name: sellOffered
	local v103
	if type(p102) == "table" then
		local v104 = p102.price
		if type(v104) == "number" and p102.price == p102.price then
			v103 = p102.price > 0
		else
			v103 = false
		end
	else
		v103 = false
	end
	return v103
end
function v_u_47.notNeeded(p105, p106) -- name: notNeeded
	local v107 = tostring(p105 or "That")
	local v108 = {}
	if type(p106) == "table" then
		if p106.heal then
			table.insert(v108, "you are at full health")
		end
		if p106.stopsBleeding then
			table.insert(v108, "you aren\'t bleeding")
		end
		if p106.fixesFracture then
			table.insert(v108, "no bone is broken")
		end
		if p106.infectionDelay then
			table.insert(v108, "you aren\'t infected")
		end
	end
	return #v108 == 0 and "You don\'t need that right now." or v107 .. ": " .. table.concat(v108, " and ") .. "."
end
function v_u_47.noTitles() -- name: noTitles
	return "You have no titles yet. Titles come from tasks, collections, badges, the weekly leaderboard, faction wars and passes."
end
v_u_47.CANT_SELL = {
	["Task item"] = "Needed for a task",
	["Last copy"] = "Last copy, kept",
	["Not empty"] = "Empty it first",
	["Not bought"] = "Not traded now",
	["Not sold"] = "Not for sale"
}
return v_u_47