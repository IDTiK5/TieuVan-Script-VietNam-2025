-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewState

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Players")
local v_u_3 = {}
local v_u_4 = false
function v_u_3.apply(p_u_5, p_u_6) -- name: apply
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	if p_u_5 == nil then
		return 0
	end
	local function v8()
		-- upvalues: (ref) v_u_3, (ref) v_u_1, (copy) p_u_6
		local v7
		if v_u_3._rules == nil then
			v7 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewStateRules"))
		else
			v7 = v_u_3._rules
		end
		return v7.clean(p_u_6)
	end
	local v9, v10 = pcall(v8)
	if not v9 then
		return 0
	end
	local v11 = 0
	for _, v_u_12 in v10 do
		if not pcall(function()
			-- upvalues: (copy) p_u_5, (copy) v_u_12
			p_u_5:SetAttribute(v_u_12.name, v_u_12.value)
		end) then
			continue
		end
		v11 = v11 + 1
	end
	return v11
end
function v_u_3.init(_) -- name: init
	-- upvalues: (ref) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
	if v_u_4 then
		return
	else
		v_u_4 = true
		local v_u_13 = v_u_2.LocalPlayer
		if v_u_13 ~= nil then
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (ref) v_u_3, (copy) v_u_13
				local function v16()
					-- upvalues: (ref) v_u_1, (ref) v_u_3, (ref) v_u_13
					local v14 = v_u_1:WaitForChild("HushNet", 30)
					if v14 then
						v14 = v14:WaitForChild("rv.state", 60)
					end
					if v14 and v14:IsA("RemoteEvent") then
						v14.OnClientEvent:Connect(function(p15)
							-- upvalues: (ref) v_u_3, (ref) v_u_13
							v_u_3.apply(v_u_13, p15)
						end)
					end
				end
				local v17, v18 = pcall(v16)
				if not v17 then
					warn("[ReviewState] could not listen: " .. tostring(v18))
				end
			end)
		end
	end
end
return v_u_3