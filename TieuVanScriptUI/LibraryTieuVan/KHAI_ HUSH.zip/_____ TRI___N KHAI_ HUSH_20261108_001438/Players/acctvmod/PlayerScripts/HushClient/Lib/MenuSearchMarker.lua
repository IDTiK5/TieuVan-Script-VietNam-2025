-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSearchMarker

local v1 = {}
local v_u_2 = nil
local function v3()
	-- upvalues: (ref) v_u_2
	v_u_2 = require((script.Parent:WaitForChild("MenuSearch", 5)))
end
pcall(v3)
local function v_u_7(p4) -- name: clock
	-- upvalues: (ref) v_u_2
	if v_u_2 then
		return v_u_2.clock(p4)
	end
	local v5 = math.ceil(p4)
	local v6 = math.max(0, v5)
	return ("%d:%02d"):format(v6 // 60, v6 % 60)
end
local v_u_8 = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 0),
	NumberSequenceKeypoint.new(0.499, 0),
	NumberSequenceKeypoint.new(0.501, 1),
	NumberSequenceKeypoint.new(1, 1)
})
function v1.width(p9, p10) -- name: width
	local v11 = (p10 and 52 or 108) * p9 + 0.5
	return math.floor(v11)
end
function v1.clear(p12) -- name: clear
	if p12 then
		p12 = p12:FindFirstChild("SearchMarker")
	end
	if p12 then
		p12:Destroy()
	end
end
local function v_u_120(p13, p14, p_u_15) -- name: build
	-- upvalues: (copy) v_u_8
	local v_u_16 = p_u_15.shared.Theme
	local v_u_17 = v_u_16.color
	local v18 = v_u_16.uiScale
	local v19, v20 = pcall(v18)
	local v_u_21 = (not v19 or type(v20) ~= "number") and 1 or math.clamp(v20, 0.85, 1.2)
	local v22 = v_u_21 * 220 + 0.5
	local v_u_23 = math.floor(v22)
	local v24 = v_u_21 * 50 + 0.5
	local v25 = math.floor(v24)
	local v26 = Instance.new("BillboardGui")
	v26.Name = "SearchMarker"
	v26.Adornee = p14
	v26.Size = UDim2.fromOffset(v_u_23, v25)
	v26.StudsOffsetWorldSpace = Vector3.new(0, 1.7, 0)
	v26.AlwaysOnTop = true
	v26.LightInfluence = 0
	v26.MaxDistance = 140
	v26.ResetOnSpawn = false
	v26.ClipsDescendants = false
	v26:SetAttribute("K", v_u_21)
	v26:SetAttribute("H", v25)
	local v_u_27 = Instance.new("Frame")
	v_u_27.Name = "Panel"
	v_u_27.BackgroundColor3 = v_u_17.bg
	v_u_27.BackgroundTransparency = 0.12
	v_u_27.BorderSizePixel = 0
	v_u_27.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_27.Position = UDim2.fromScale(0.5, 0.5)
	v_u_27.Size = UDim2.fromOffset(0, v25)
	v_u_27.AutomaticSize = Enum.AutomaticSize.X
	v_u_27.Parent = v26
	local v28 = Instance.new("UIPadding")
	local v29 = UDim.new
	local v30 = v_u_21 * 12 + 0.5
	v28.PaddingRight = v29(0, (math.floor(v30)))
	v28.Parent = v_u_27
	local v_u_31 = Instance.new("UIStroke")
	v_u_31.Name = "Stroke"
	v_u_31.Color = v_u_17.accent
	v_u_31.Thickness = 1
	v_u_31.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	pcall(function()
		-- upvalues: (copy) v_u_31
		v_u_31.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	v_u_31.Parent = v_u_27
	local v32 = v_u_21 * 38 + 0.5
	local v_u_33 = math.floor(v32)
	local v_u_34 = Instance.new("Frame")
	v_u_34.Name = "Radar"
	v_u_34.BackgroundTransparency = 1
	local v35 = UDim2.fromOffset
	local v36 = v_u_21 * 7 + 0.5
	local v37 = math.floor(v36)
	local v38 = (v25 - v_u_33) / 2
	v_u_34.Position = v35(v37, (math.floor(v38)))
	v_u_34.Size = UDim2.fromOffset(v_u_33, v_u_33)
	v_u_34.Parent = v_u_27
	local function v47(p39, p40, p41, p42, p43) -- name: ring
		-- upvalues: (copy) v_u_33, (copy) v_u_17
		local v44 = Instance.new("Frame")
		v44.Name = p39
		v44.BackgroundTransparency = 1
		if p42 then
			v44.Position = p42
		else
			v44.AnchorPoint = Vector2.new(0.5, 0.5)
			v44.Position = UDim2.fromScale(0.5, 0.5)
		end
		v44.Size = UDim2.fromOffset(v_u_33, v_u_33)
		local v45 = Instance.new("UICorner")
		v45.CornerRadius = UDim.new(1, 0)
		v45.Parent = v44
		local v_u_46 = Instance.new("UIStroke")
		v_u_46.Color = v_u_17.accent
		v_u_46.Thickness = p40
		v_u_46.Transparency = p43 or 0
		v_u_46.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		pcall(function()
			-- upvalues: (copy) v_u_46
			v_u_46.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		end)
		v_u_46.Parent = v44
		v44.Parent = p41
		return v44, v_u_46
	end
	local v48 = v_u_21 * 2 + 0.5
	local v49 = math.floor(v48)
	local v50 = math.max(2, v49)
	v47("Track", v50, v_u_34, nil, 0.72)
	for _, v51 in { "R", "L" } do
		local v52 = Instance.new("Frame")
		v52.Name = "Arc" .. v51
		v52.BackgroundTransparency = 1
		v52.ClipsDescendants = true
		local v53 = UDim2.fromOffset
		local v54
		if v51 == "R" then
			local v55 = v_u_33 / 2
			v54 = v_u_33 - math.floor(v55)
		else
			v54 = 0
		end
		v52.Position = v53(v54, 0)
		local v56 = UDim2.fromOffset
		local v57 = v_u_33 / 2
		v52.Size = v56(math.floor(v57), v_u_33)
		v52.Parent = v_u_34
		local v58 = "Ring"
		local v59 = UDim2.fromOffset
		local v60
		if v51 == "R" then
			local v61 = v_u_33 / 2
			v60 = -(v_u_33 - math.floor(v61))
		else
			v60 = 0
		end
		local _, v62 = v47(v58, v50, v52, v59(v60, 0))
		local v63 = Instance.new("UIGradient")
		v63.Name = "Cut"
		v63.Transparency = v_u_8
		v63.Rotation = v51 == "R" and 180 or 360
		v63.Parent = v62
	end
	local v64 = v_u_21 * 1.5 + 0.5
	local v65 = math.floor(v64)
	v47("Pulse", math.max(1, v65), v_u_34)
	local v66 = Instance.new("Frame")
	v66.Name = "Blip"
	v66.BackgroundColor3 = v_u_17.accent
	v66.BorderSizePixel = 0
	v66.AnchorPoint = Vector2.new(0.5, 0.5)
	local v67 = UDim2.fromOffset
	local v68 = v_u_21 * 6 + 0.5
	local v69 = math.floor(v68)
	local v70 = v_u_21 * 6 + 0.5
	v66.Size = v67(v69, (math.floor(v70)))
	local v71 = Instance.new("UICorner")
	v71.CornerRadius = UDim.new(1, 0)
	v71.Parent = v66
	v66.Parent = v_u_34
	local v72 = Instance.new("TextLabel")
	v72.Name = "Num"
	v72.BackgroundTransparency = 1
	v72.AnchorPoint = Vector2.new(0.5, 0.5)
	v72.Position = UDim2.fromScale(0.5, 0.5)
	local v73 = UDim2.fromOffset
	local v74 = v_u_21 * 4 + 0.5
	local v75 = v_u_33 - math.floor(v74)
	local v76 = v_u_21 * 14 + 0.5
	v72.Size = v73(v75, (math.floor(v76)))
	v72.FontFace = v_u_16.font.monoBold
	local v77 = v_u_21 * 12 + 0.5
	v72.TextSize = math.floor(v77)
	v72.TextColor3 = v_u_17.text
	v72.Text = ""
	v72.TextScaled = false
	v72.TextTruncate = Enum.TextTruncate.None
	local v78 = Instance.new("UITextSizeConstraint")
	local v79 = v_u_21 * 12 + 0.5
	v78.MaxTextSize = math.floor(v79)
	v78.MinTextSize = 8
	v78.Parent = v72
	v72.Parent = v_u_34
	local v_u_80 = nil
	local function v81()
		-- upvalues: (ref) v_u_80, (copy) p_u_15
		v_u_80 = p_u_15.lib.HushUI
	end
	pcall(v81)
	if v_u_80 then
		local function v90()
			-- upvalues: (ref) v_u_80, (copy) v_u_34, (copy) v_u_21, (copy) v_u_16, (copy) v_u_17
			local v82 = v_u_80.icon
			local v83 = {
				["parent"] = v_u_34
			}
			local v84 = v_u_21 * 14 + 0.5
			v83.size = math.floor(v84)
			v83.color = v_u_16.kindColor("success")
			v83.position = UDim2.fromScale(0.5, 0.5)
			v83.anchor = Vector2.new(0.5, 0.5)
			local v85 = v82("check", v83)
			v85.Name = "Tick"
			v85.Visible = false
			local v86 = v_u_80.icon
			local v87 = {
				["parent"] = v_u_34
			}
			local v88 = v_u_21 * 14 + 0.5
			v87.size = math.floor(v88)
			v87.color = v_u_17.accent
			v87.position = UDim2.fromScale(0.5, 0.5)
			v87.anchor = Vector2.new(0.5, 0.5)
			local v89 = v86("arrowUp", v87)
			v89.Name = "Arrow"
			v89.Visible = false
		end
		pcall(v90)
	end
	local function v105(p91, p92, p93, p94, p95, p96) -- name: text
		-- upvalues: (copy) v_u_21, (copy) v_u_23, (copy) v_u_27
		local v97 = Instance.new("TextLabel")
		v97.Name = p91
		v97.BackgroundTransparency = 1
		v97.FontFace = p92
		v97.TextSize = p93
		v97.TextColor3 = p94
		v97.TextXAlignment = Enum.TextXAlignment.Left
		v97.TextTruncate = Enum.TextTruncate.AtEnd
		v97.Text = ""
		local v98 = UDim2.fromOffset
		local v99 = v_u_21 * 56 + 0.5
		v97.Position = v98(math.floor(v99), p95)
		v97.Size = UDim2.fromOffset(0, p96)
		v97.AutomaticSize = Enum.AutomaticSize.X
		local v100 = Instance.new("UISizeConstraint")
		local v101 = Vector2.new
		local v102 = v_u_23
		local v103 = v_u_21 * 70 + 0.5
		v100.MaxSize = v101(v102 - math.floor(v103), p96)
		v100.Parent = v97
		local v104 = Instance.new("UIPadding")
		v104.PaddingRight = UDim.new(0, 2)
		v104.Parent = v97
		v97.Parent = v_u_27
		return v97
	end
	local v106 = v_u_16.font.heading
	local v107 = v_u_21 * 17 + 0.5
	local v108 = math.floor(v107)
	local v109 = v_u_17.accent
	local v110 = v_u_21 * 6 + 0.5
	local v111 = math.floor(v110)
	local v112 = v_u_21 * 20 + 0.5
	v105("Title", v106, v108, v109, v111, (math.floor(v112)))
	local v113 = v_u_16.font.heading
	local v114 = v_u_21 * 11 + 0.5
	local v115 = math.floor(v114)
	local v116 = v_u_17.text
	local v117 = v_u_21 * 27 + 0.5
	local v118 = math.floor(v117)
	local v119 = v_u_21 * 14 + 0.5
	v105("Line", v113, v115, v116, v118, (math.floor(v119)))
	v26.Parent = p13
	return v26
end
local function v_u_127(p121) -- name: texts
	-- upvalues: (ref) v_u_2, (copy) v_u_7
	local v122 = p121.phase
	if v122 == "searching" then
		local v123
		if v_u_2 then
			v123 = v_u_2.found(p121)
		else
			v123 = nil
		end
		local v124
		if v123 then
			v124 = v123 .. " found"
		else
			v124 = not p121.regionName and "Looking for squads" or p121.regionName
		end
		return "Searching", v124, v_u_7(p121.remaining or 0)
	elseif v122 == "found" then
		local v125 = p121.match
		return "Found", type(v125) == "table" and v125.k == "join" and "Raid in progress" or (not p121.found and "Survivors found" or ("%d survivors"):format(p121.found)), ""
	else
		local v126 = p121.match
		return "Deploying", type(v126) == "table" and v126.k == "alone" and "New raid" or (not p121.regionName and "Moving out" or p121.regionName), ""
	end
end
function v1.update(p128, p129, p130) -- name: update
	-- upvalues: (copy) v_u_120, (copy) v_u_127
	if p128 then
		local v131 = p128:FindFirstChild("SearchMarker")
		if p129 then
			local v132 = p128:FindFirstChild("Head")
			if v132 and v132:IsA("BasePart") then
				local v133
				if p130 then
					v133 = p130.cctx
				else
					v133 = p130
				end
				if v133 then
					if not v131 or v131.Adornee ~= v132 then
						if v131 then
							v131:Destroy()
						end
						v131 = v_u_120(p128, v132, v133)
					end
					local v134 = v133.shared.Theme
					local v135 = v134.color
					local v136 = tonumber(v131:GetAttribute("K")) or 1
					local v137 = tonumber(v131:GetAttribute("H")) or 50
					local v138 = p130.plateH
					local v139 = tonumber(v138) or 0
					local v140
					if v139 > 0 then
						local v141 = v139 / 2
						local v142 = 6 * v136
						v140 = v141 + math.floor(v142) + v137 / 2
					else
						v140 = v137 / 2
					end
					local v143 = Vector2.new(0, v140 / v137)
					if v131.SizeOffset ~= v143 then
						v131.SizeOffset = v143
					end
					local v144 = v131:FindFirstChild("Panel")
					local v145
					if v144 then
						v145 = v144:FindFirstChild("Radar")
					else
						v145 = v144
					end
					if v144 and v145 then
						local v146, v147, v148 = v_u_127(p129)
						local v149 = p129.phase == "found"
						local v150
						if v149 then
							v150 = v134.kindColor("success")
						else
							v150 = v135.accent
						end
						local v151 = v146 .. "|" .. v147 .. "|" .. v148
						local v152 = p130.compact == true
						if v131:GetAttribute("Compact") ~= v152 then
							v131:SetAttribute("Compact", v152)
							v131:SetAttribute("Key", nil)
							local v153 = v144:FindFirstChildOfClass("UIPadding")
							if v153 then
								local v154 = UDim.new
								local v155 = (v152 and 7 or 12) * v136 + 0.5
								v153.PaddingRight = v154(0, (math.floor(v155)))
							end
							for _, v156 in { "Title", "Line" } do
								local v157 = v144:FindFirstChild(v156)
								if not v157 then
									continue
								end
								v157.Visible = not v152
							end
						end
						if v131:GetAttribute("Key") ~= v151 then
							v131:SetAttribute("Key", v151)
							v131:SetAttribute("Phase", p129.phase)
							local v158 = v144:FindFirstChild("Title")
							local v159 = v144:FindFirstChild("Line")
							local v160 = v145:FindFirstChild("Num")
							if v158 then
								v158.Text = string.upper(v146)
								v158.TextColor3 = v150
							end
							if v159 then
								v159.Text = string.upper(v147)
							end
							if v160 then
								v160.Text = v148
								v160.Visible = v148 ~= ""
							end
							local v161 = v145:FindFirstChild("Tick")
							local v162 = v145:FindFirstChild("Arrow")
							if v161 then
								v161.Visible = v149
							end
							if v162 then
								local v163
								if v148 == "" then
									v163 = not v149
								else
									v163 = false
								end
								v162.Visible = v163
							end
							local v164 = v144:FindFirstChild("Stroke")
							if v164 then
								v164.Color = v150
							end
							for _, v165 in { "Track", "ArcR", "ArcL" } do
								local v166 = v145:FindFirstChild(v165)
								if v166 and v165 ~= "Track" then
									v166 = v166:FindFirstChild("Ring")
								end
								if v166 then
									v166 = v166:FindFirstChildOfClass("UIStroke")
								end
								if not v166 then
									continue
								end
								v166.Color = v150
							end
							local v167 = v145:FindFirstChild("Pulse")
							if v167 then
								v167 = v167:FindFirstChildOfClass("UIStroke")
							end
							if v167 then
								v167.Color = v150
							end
						end
						local v168 = p130.t
						local v169 = tonumber(v168) or os.clock()
						local v170 = v145.AbsoluteSize.X
						if v170 <= 0 then
							local v171 = 32 * v136 + 0.5
							v170 = math.floor(v171)
						end
						local v172 = v145:FindFirstChild("Pulse")
						if v172 then
							local v173 = p129.phase == "searching" and 1.4 or 0.8
							local v174 = v169 % v173 / v173
							local v175 = v172:FindFirstChildOfClass("UIStroke")
							v172.Visible = not v149
							local v176 = v170 + v170 * 0.30000000000000004 * v174 + 0.5
							local v177 = math.floor(v176)
							v172.Size = UDim2.fromOffset(v177, v177)
							if v175 then
								v175.Transparency = 0.1 + 0.9 * v174
							end
						end
						local v178
						if p129.phase == "searching" then
							local v179 = p129.frac
							local v180 = tonumber(v179) or 0
							v178 = math.clamp(v180, 0, 1)
						else
							v178 = 1
						end
						local v181 = v178 * 360
						for _, v182 in { "R", "L" } do
							local v183 = v145:FindFirstChild("Arc" .. v182)
							if v183 then
								v183 = v183:FindFirstChild("Ring")
							end
							if v183 then
								v183 = v183:FindFirstChildOfClass("UIStroke")
							end
							if v183 then
								v183 = v183:FindFirstChild("Cut")
							end
							if not v183 then
								continue
							end
							local v184
							if v182 == "R" then
								v184 = math.clamp(v181, 0, 180)
							else
								local v185 = v181 - 180
								v184 = math.clamp(v185, 0, 180) + 180
							end
							local v186 = v184 * 2 + 0.5
							local v187 = math.floor(v186) / 2
							if v183.Rotation == v187 then
								continue
							end
							v183.Rotation = v187
						end
						local v188 = v145:FindFirstChild("Blip")
						if v188 then
							local v189 = p129.phase == "searching"
							v188.Visible = v189
							if v189 then
								local v190 = v169 * 2.4
								local v191 = v170 / 2 - 1
								local v192 = UDim2.new
								local v193 = math.cos(v190) * v191 + 0.5
								local v194 = math.floor(v193)
								local v195 = math.sin(v190) * v191 + 0.5
								v188.Position = v192(0.5, v194, 0.5, (math.floor(v195)))
							end
						end
					end
				else
					return
				end
			else
				return
			end
		else
			if v131 then
				v131:Destroy()
			end
			return
		end
	else
		return
	end
end
return v1