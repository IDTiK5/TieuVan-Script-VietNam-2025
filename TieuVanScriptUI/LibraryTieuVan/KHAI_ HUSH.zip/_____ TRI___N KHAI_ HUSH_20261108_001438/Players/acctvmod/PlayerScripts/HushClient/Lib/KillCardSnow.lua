-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardSnow

local v_u_1 = {
	["MAX"] = 40,
	["SNOW_N"] = 18,
	["BLIZZARD_N"] = 22,
	["TAU"] = 6.283185307179586,
	["EASE_IN"] = {
		["snow"] = 0.35,
		["blizzard"] = 0.12
	},
	["ORBIT"] = 1.7
}
local v_u_2 = v_u_1.TAU
local v_u_3 = math.sin
local v_u_4 = math.cos
local v_u_5 = math.floor
function v_u_1.count(p6) -- name: count
	-- upvalues: (copy) v_u_1
	if p6 == "blizzard" then
		return v_u_1.BLIZZARD_N
	else
		return p6 ~= "snow" and 0 or v_u_1.SNOW_N
	end
end
function v_u_1.flakes(p7, p8) -- name: flakes
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_2
	local v9 = v_u_1.count(p7)
	local v_u_10 = (((type(p8) ~= "number" or (p8 ~= p8 or (p8 <= -1000000000 or p8 >= 1000000000))) and 1 or v_u_5(p8)) * 7919 + 104729) % 2147483629 + 1
	local function v11()
		-- upvalues: (ref) v_u_10
		v_u_10 = v_u_10 * 48271 % 2147483647
		return v_u_10 / 2147483647
	end
	local v12 = {}
	for v13 = 1, v9 do
		if p7 == "snow" then
			local v14 = {}
			local v15 = 0.5 + (v11() - 0.5) * 0.96
			v14.x0 = math.clamp(v15, 0.03, 0.97)
			v14.phase = v11()
			v14.speed = 0.09 + 0.11 * v11()
			v14.amp = 0.012 + 0.03 * v11()
			v14.rate = 0.6 + 0.8 * v11()
			v14.sway = v11() * v_u_2
			v14.size = v_u_5(v11() * 4) + 3
			v14.alpha = 0.55 + 0.4 * v11()
			v12[v13] = v14
		else
			local v16 = (v13 - 1) % 3
			v12[v13] = {
				["a0"] = (v13 - 1) / v9 * v_u_2 + v11() * 0.5,
				["rx"] = v16 * 0.09 + 0.22 + 0.03 * v11(),
				["ry"] = v16 * 0.025 + 0.05 + 0.01 * v11(),
				["hy"] = v16 * 0.17 + 0.3 + 0.06 * (v11() - 0.5),
				["wob"] = v11() * v_u_2,
				["size"] = v_u_5(v11() * 4) + 4,
				["alpha"] = 0.6 + 0.35 * v11(),
				["ring"] = v16
			}
		end
	end
	return v12
end
function v_u_1.at(p17, p18, p19, p20, p21) -- name: at
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_1, (copy) v_u_4
	local v22 = p21 == true and 1 or ((type(p19) ~= "number" or p19 ~= p19) and 0 or p19)
	if p17 == "snow" then
		local v23 = p18.phase + p18.speed * v22
		local v24 = v23 - v_u_5(v23)
		local v25 = p18.x0 + v_u_3(p18.rate * v22 + p18.sway) * p18.amp
		local v26 = v24 / 0.08
		local v27 = (1 - v24) / 0.08
		local v28 = math.min(1, v26, v27)
		return {
			["x"] = nil,
			["y"] = nil,
			["size"] = nil,
			["alpha"] = nil,
			["front"] = true,
			["x"] = math.clamp(v25, 0, 1),
			["y"] = v24,
			["size"] = p18.size,
			["alpha"] = p18.alpha * math.max(0, v28)
		}
	end
	local v29
	if p20 then
		local v30 = p20.yaw
		if type(v30) == "number" and (p20.yaw == p20.yaw and p21 ~= true) then
			local v31 = p20.yaw
			v29 = math.rad(v31)
		else
			v29 = 0
		end
	else
		v29 = 0
	end
	local v32
	if p20 then
		local v33 = p20.settle
		if type(v33) == "number" and p20.settle == p20.settle then
			local v34 = p20.settle
			v32 = math.clamp(v34, 0, 1)
		else
			v32 = 0
		end
	else
		v32 = 0
	end
	local v35 = p18.a0 + v29 + (p21 == true and 0 or v_u_1.ORBIT * v22)
	local v36 = v32 * 0.5 + 1
	local v37 = v_u_3(v35)
	local v38 = 0.5 + v_u_4(v35) * p18.rx * v36
	local v39 = p18.hy + v37 * p18.ry * v36 + v32 * 0.22 * v32 + v_u_3(2.3 * v22 + p18.wob) * 0.012
	local v40 = v37 > 0
	local v41 = {
		["x"] = math.clamp(v38, 0, 1),
		["y"] = math.clamp(v39, 0, 1),
		["size"] = p18.size * (v37 * 0.3 + 1)
	}
	local v42 = p18.alpha
	local v43
	if v40 then
		v43 = v37 * 0.45 + 0.55
	else
		v43 = (v37 + 1) * 0.2 + 0.18
	end
	v41.alpha = v42 * v43
	v41.front = v40
	return v41
end
function v_u_1.gain(p44, p45, p46) -- name: gain
	-- upvalues: (copy) v_u_1
	local v47 = (type(p45) ~= "number" or p45 ~= p45) and 0 or math.clamp(p45, 0, 1)
	local v48 = ((type(p46) ~= "number" or p46 ~= p46) and 0 or p46) / (v_u_1.EASE_IN[p44] or 0.2)
	local v49 = math.clamp(v48, 0, 1)
	return v47 * (v49 * v49 * (3 - v49 * 2))
end
function v_u_1.new(p50, p51, p_u_52) -- name: new
	-- upvalues: (copy) v_u_1
	local v53 = {}
	local v_u_54 = true
	local v_u_55 = p51 or 6
	local v_u_56
	if p_u_52 and p_u_52.reduced ~= nil then
		v_u_56 = p_u_52.reduced == true
	else
		local v57
		v_u_56, v57 = pcall(function()
			local v58 = script.Parent
			if v58 then
				v58 = v58:FindFirstChild("KillCardBgFx")
			end
			if v58 == nil then
				return false
			else
				return require(v58).reducedMotion() == true
			end
		end)
		if v_u_56 then
			v_u_56 = v57 == true
		end
	end
	local v_u_59
	if p_u_52 then
		local v60 = p_u_52.clock
		if type(v60) == "function" then
			v_u_59 = p_u_52.clock
		else
			v_u_59 = os.clock
		end
	else
		v_u_59 = os.clock
	end
	local v_u_61 = Instance.new("Frame")
	v_u_61.Name = "KcSnow"
	v_u_61.BackgroundTransparency = 1
	v_u_61.BorderSizePixel = 0
	v_u_61.ClipsDescendants = true
	v_u_61.Size = UDim2.fromScale(1, 1)
	v_u_61.ZIndex = v_u_55
	v_u_61.Visible = false
	v_u_61.Parent = p50
	local v_u_62 = {}
	local v_u_63 = nil
	local function v_u_75(p64, p65) -- name: ensure
		-- upvalues: (ref) v_u_62, (ref) v_u_1, (copy) v_u_55, (copy) v_u_61
		local v66 = v_u_62[p64]
		if v66 ~= nil then
			return v66
		end
		local v67 = v_u_1.flakes(p64, p65)
		local v68 = {}
		for v69, v70 in v67 do
			local v71 = Instance.new("Frame")
			v71.Name = "Flake" .. v69
			v71.AnchorPoint = Vector2.new(0.5, 0.5)
			local v72
			if p64 == "snow" then
				v72 = Color3.fromRGB(244, 248, 255)
			else
				v72 = Color3.fromRGB(226, 238, 252)
			end
			v71.BackgroundColor3 = v72
			v71.BorderSizePixel = 0
			v71.BackgroundTransparency = 1
			v71.Size = UDim2.fromOffset(v70.size, v70.size)
			v71.ZIndex = v_u_55
			v71.Visible = false
			v71.Parent = v_u_61
			local v73 = Instance.new("UICorner")
			v73.CornerRadius = UDim.new(1, 0)
			v73.Parent = v71
			v68[v69] = v71
		end
		local v74 = {
			["flakes"] = nil,
			["frames"] = nil,
			["strength"] = 0,
			["seed"] = nil,
			["age0"] = 0,
			["clock0"] = 0,
			["info"] = nil,
			["on"] = false,
			["flakes"] = v67,
			["frames"] = v68,
			["seed"] = p65
		}
		v_u_62[p64] = v74
		return v74
	end
	local function v_u_92(p76, p77) -- name: draw
		-- upvalues: (copy) v_u_56, (copy) v_u_59, (ref) v_u_1, (copy) v_u_61
		local v78 = p77.age0 + (v_u_56 and 0 or v_u_59() - p77.clock0)
		local v79 = v_u_1.gain(p76, p77.strength, v_u_56 and 1 or v78)
		local v80 = v_u_61.AbsoluteSize.Y
		local v81
		if v80 < 2 then
			v81 = 1
		else
			local v82 = v80 / 256
			v81 = math.clamp(v82, 0.6, 2.2)
		end
		local v83 = p77.info
		if p76 == "blizzard" and v83 then
			v83 = {
				["yaw"] = v83.yaw
			}
			local v84 = p77.strength
			v83.settle = 1 - math.clamp(v84, 0, 1)
		end
		for v85, v86 in p77.flakes do
			local v87 = v_u_1.at(p76, v86, v78, v83, v_u_56)
			local v88 = p77.frames[v85]
			local v89 = v87.alpha * v79 * (v_u_56 and 0.75 or 1)
			v88.Visible = v89 > 0.01
			if not v88.Visible then
				continue
			end
			v88.Position = UDim2.fromScale(v87.x, v87.y)
			local v90 = v87.size * v81
			local v91 = math.max(2, v90)
			v88.Size = UDim2.fromOffset(v91, v91)
			v88.BackgroundTransparency = 1 - math.clamp(v89, 0, 1)
		end
	end
	function v53.set(p93, p94, p95, p96, p97) -- name: set
		-- upvalues: (ref) v_u_54, (ref) v_u_62, (copy) v_u_61, (ref) v_u_63, (copy) v_u_75, (copy) v_u_59, (copy) v_u_92, (copy) v_u_56, (copy) p_u_52
		if v_u_54 and (p93 == "snow" or p93 == "blizzard") then
			local v98 = (type(p94) ~= "number" or p94 ~= p94) and 0 or math.clamp(p94, 0, 1)
			local v99 = v_u_62[p93]
			if v98 <= 0 then
				if v99 ~= nil then
					v99.on = false
					v99.strength = 0
					for _, v100 in v99.frames do
						v100.Visible = false
					end
				end
				for _, v101 in v_u_62 do
					if not v101.on then
						continue
					end
					v102 = true
				end
				local v102 = false
				if not v102 then
					v_u_61.Visible = false
					if v_u_63 ~= nil then
						local function v103()
							-- upvalues: (ref) v_u_63
							v_u_63:Disconnect()
						end
						pcall(v103)
						v_u_63 = nil
					end
				end
			else
				local v104 = v_u_75(p93, p95)
				v104.strength = v98
				v104.age0 = (type(p96) ~= "number" or p96 ~= p96) and 0 or p96
				v104.clock0 = v_u_59()
				if type(p97) ~= "table" then
					p97 = v104.info
				end
				v104.info = p97
				v104.on = true
				v_u_61.Visible = true
				v_u_92(p93, v104)
				if v_u_63 == nil and not v_u_56 then
					if p_u_52 and p_u_52.noLoop == true then
						return
					end
					local function v107()
						-- upvalues: (ref) v_u_54, (ref) v_u_62, (ref) v_u_92
						return game:GetService("RunService").Heartbeat:Connect(function()
							-- upvalues: (ref) v_u_54, (ref) v_u_62, (ref) v_u_92
							if v_u_54 then
								for v105, v106 in v_u_62 do
									if not v106.on then
										continue
									end
									v_u_92(v105, v106)
								end
							end
						end)
					end
					local v108, v109 = pcall(v107)
					if v108 then
						v_u_63 = v109
					end
				end
			end
		else
			return
		end
	end
	function v53.count() -- name: count
		-- upvalues: (ref) v_u_62
		local v110 = 0
		for _, v111 in v_u_62 do
			v110 = v110 + #v111.frames
		end
		return v110
	end
	function v53.visible(p112) -- name: visible
		-- upvalues: (ref) v_u_62, (copy) v_u_61
		if p112 == nil then
			return v_u_61.Visible
		end
		local v113 = v_u_62[p112]
		local v114
		if v113 == nil then
			v114 = false
		else
			v114 = v113.on
		end
		return v114
	end
	function v53.host() -- name: host
		-- upvalues: (copy) v_u_61
		return v_u_61
	end
	function v53.reduced() -- name: reduced
		-- upvalues: (copy) v_u_56
		return v_u_56
	end
	function v53.looping() -- name: looping
		-- upvalues: (ref) v_u_63
		return v_u_63 ~= nil
	end
	function v53.destroy() -- name: destroy
		-- upvalues: (ref) v_u_54, (ref) v_u_63, (copy) v_u_61, (ref) v_u_62
		v_u_54 = false
		if v_u_63 ~= nil then
			local function v115()
				-- upvalues: (ref) v_u_63
				v_u_63:Disconnect()
			end
			pcall(v115)
			v_u_63 = nil
		end
		local function v116()
			-- upvalues: (ref) v_u_61
			v_u_61:Destroy()
		end
		pcall(v116)
		v_u_62 = {}
	end
	return v53
end
return v_u_1