-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MapDraw

local v_u_1 = require(script.Parent:WaitForChild("MapData"))
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v3, v_u_4 = pcall(function()
	return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapTagPlace", 5)))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
local v_u_5 = game:GetService("TextService")
local v6 = {}
local v_u_7 = {
	["paper"] = Color3.fromHex("D8CDB2"),
	["paperLight"] = Color3.fromHex("E6DCC4"),
	["paperEdge"] = Color3.fromHex("A99C7E"),
	["crease"] = Color3.fromHex("BDB091"),
	["grid"] = Color3.fromHex("C3B697"),
	["ink"] = Color3.fromHex("372F26"),
	["inkSoft"] = Color3.fromHex("6A5E4C"),
	["field"] = Color3.fromHex("CFC598"),
	["park"] = Color3.fromHex("B9BE92"),
	["forest"] = Color3.fromHex("B4B98F"),
	["tree"] = Color3.fromHex("7C8758"),
	["water"] = Color3.fromHex("8DA4AE"),
	["waterInk"] = Color3.fromHex("44606E"),
	["bank"] = Color3.fromHex("BDC0A6"),
	["lot"] = Color3.fromHex("C6BCA5"),
	["road"] = Color3.fromHex("F0E8D4"),
	["roadCase"] = Color3.fromHex("5D5345"),
	["highway"] = Color3.fromHex("F2DFA9"),
	["build"] = Color3.fromHex("8C806D"),
	["buildEdge"] = Color3.fromHex("4A4136"),
	["landmark"] = Color3.fromHex("9C4B39"),
	["landmarkEdge"] = Color3.fromHex("5E2A1F"),
	["red"] = Color3.fromHex("B0322A"),
	["redDeep"] = Color3.fromHex("7E2019"),
	["green"] = Color3.fromHex("3E6E4A")
}
v6.INK = v_u_7
local function v_u_20(p8, p9, p10, p11, p12, p13, p14) -- name: text
	-- upvalues: (copy) v_u_7
	local v15 = Instance.new("TextLabel")
	v15.Name = "Txt"
	v15.BackgroundTransparency = 1
	v15.AnchorPoint = Vector2.new(0.5, 0.5)
	v15.Position = UDim2.fromOffset(p10.X, p10.Y)
	local v16 = UDim2.fromOffset
	local v17 = (utf8.len(p9) or #p9) * p11 * 0.62 + 8
	v15.Size = v16(math.max(20, v17), p11 + 4)
	v15.FontFace = p12
	v15.TextSize = p11
	v15.TextColor3 = p13
	v15.TextStrokeColor3 = v_u_7.paper
	v15.TextStrokeTransparency = 0.25
	v15.Text = p9
	v15.TextTruncate = Enum.TextTruncate.AtEnd
	if p14 then
		for v18, v19 in p14 do
			v15[v18] = v19
		end
	end
	v15.Parent = p8
	return v15
end
local function v_u_26(p21) -- name: spaced
	local v22 = utf8.char(8202)
	local v23 = {}
	for _, v24 in utf8.codes(string.upper(p21)) do
		local v25 = utf8.char
		table.insert(v23, v25(v24))
	end
	return table.concat(v23, v22)
end
function v6.build(p27, p28, p29, p30, p_u_31) -- name: build
	-- upvalues: (copy) v_u_20, (copy) v_u_2, (copy) v_u_1, (copy) v_u_7, (ref) v_u_4, (copy) v_u_26, (copy) v_u_5
	local v_u_32 = v_u_20
	local v33
	if p_u_31 then
		v33 = p_u_31.phone
	else
		v33 = v_u_2.isPhone()
	end
	local v_u_34 = v_u_1.HALF
	local v35 = p28 * 0.035
	local v36 = math.floor(v35)
	local v37 = p28 - v36 * 2
	local v_u_38 = v37 / (v_u_34 * 2)
	local v39 = p28 / 880
	local v40 = p30 and p30.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
	local v41 = p30 and p30.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v42 = p30 and p30.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v43 = p30 and p30.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v44 = {
		["Name"] = "Sheet",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_7.paper,
		["Size"] = UDim2.fromOffset(p28, p28)
	}
	local v45 = Instance.new("Frame")
	v45.BorderSizePixel = 0
	for v46, v47 in v44 do
		v45[v46] = v47
	end
	v45.Parent = p27
	local v48 = v_u_7.paperEdge
	local v49 = Instance.new("UIStroke")
	v49.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v49.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v49.Color = v48
	v49.Thickness = 2
	v49.Transparency = 0
	v49.Parent = v45
	local v50 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v_u_7.paperLight,
		["Position"] = UDim2.fromOffset(v36, v36),
		["Size"] = UDim2.fromOffset(v37, v37)
	}
	local v51 = Instance.new("Frame")
	v51.BorderSizePixel = 0
	for v52, v53 in v50 do
		v51[v52] = v53
	end
	v51.Parent = v45
	local v54 = v_u_7.ink
	local v55 = Instance.new("UIStroke")
	v55.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v55.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v55.Color = v54
	v55.Thickness = 1
	v55.Transparency = 0
	v55.Parent = v51
	local v56 = {
		["Name"] = "Ground",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v57 = Instance.new("Frame")
	v57.BorderSizePixel = 0
	local function v85(p58, p59, p60, p61, p62, p63, p64) -- name: rect
		-- upvalues: (copy) v_u_34, (copy) v_u_38
		local v65 = math.min(p59, p61)
		local v66 = math.min(p60, p62)
		local v67 = Vector2.new((v65 + v_u_34) * v_u_38, (v66 + v_u_34) * v_u_38)
		local v68 = math.max(p59, p61)
		local v69 = math.max(p60, p62)
		local v70 = Vector2.new((v68 + v_u_34) * v_u_38, (v69 + v_u_34) * v_u_38)
		local v71 = {
			["BackgroundColor3"] = p63,
			["BackgroundTransparency"] = p64 or 0
		}
		local v72 = UDim2.fromOffset
		local v73 = v67.X
		local v74 = math.floor(v73)
		local v75 = v67.Y
		v71.Position = v72(v74, (math.floor(v75)))
		local v76 = UDim2.fromOffset
		local v77 = v70.X - v67.X
		local v78 = math.ceil(v77)
		local v79 = math.max(1, v78)
		local v80 = v70.Y - v67.Y
		local v81 = math.ceil(v80)
		v71.Size = v76(v79, (math.max(1, v81)))
		local v82 = Instance.new("Frame")
		v82.BorderSizePixel = 0
		for v83, v84 in v71 do
			v82[v83] = v84
		end
		v82.Parent = p58
		return v82
	end
	local function v88(p86, p87) -- name: toPx
		-- upvalues: (copy) v_u_34, (copy) v_u_38
		return Vector2.new((p86 + v_u_34) * v_u_38, (p87 + v_u_34) * v_u_38)
	end
	local function v109(p89, p90, p91, p92, p93, p94, p95) -- name: box
		-- upvalues: (copy) v_u_34, (copy) v_u_38
		local v96 = Vector2.new((p90 + v_u_34) * v_u_38, (p91 + v_u_34) * v_u_38)
		local v97 = p94 % 180
		local v98 = -p94
		local v99 = v97 - 90
		if math.abs(v99) < 1 then
			local v100 = p93
			p93 = p92
			p92 = v100
			v98 = 0
		elseif v97 < 1 or v97 > 179 then
			v98 = 0
		end
		local v101 = {
			["BackgroundColor3"] = p95,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v96.X, v96.Y)
		}
		local v102 = UDim2.fromOffset
		local v103 = p92 * v_u_38
		local v104 = math.max(2, v103)
		local v105 = p93 * v_u_38
		v101.Size = v102(v104, (math.max(2, v105)))
		v101.Rotation = v98
		local v106 = Instance.new("Frame")
		v106.BorderSizePixel = 0
		for v107, v108 in v101 do
			v106[v107] = v108
		end
		v106.Parent = p89
		return v106
	end
	for v110, v111 in v56 do
		v57[v110] = v111
	end
	v57.Parent = v51
	for _, v112 in v_u_1.FIELDS do
		v85(v57, v112[1], v112[2], v112[3], v112[4], v_u_7.field, 0.15).Name = "Field"
	end
	for _, v113 in v_u_1.FORESTS do
		v85(v57, v113[1], v113[2], v113[3], v113[4], v_u_7.forest, 0.1).Name = "Forest"
	end
	for _, v114 in { v_u_1.PARK, v_u_1.SPORTS, v_u_1.CEMETERY } do
		local v115 = v85(v57, v114[1], v114[2], v114[3], v114[4], v_u_7.park, 0)
		v115.Name = "Green"
		local v116 = v_u_7.inkSoft
		local v117 = Instance.new("UIStroke")
		v117.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v117.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v117.Color = v116
		v117.Thickness = 1
		v117.Transparency = 0.55
		v117.Parent = v115
	end
	for _, v118 in { v_u_1.JUNKYARD, v_u_1.PLAYGROUND } do
		local v119 = v85(v57, v118[1], v118[2], v118[3], v118[4], v_u_7.lot, 0.2)
		v119.Name = "Yard"
		local v120 = v_u_7.inkSoft
		local v121 = Instance.new("UIStroke")
		v121.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v121.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v121.Color = v120
		v121.Thickness = 1
		v121.Transparency = 0.6
		v121.Parent = v119
	end
	local v122 = v_u_1.SPORTS
	local v123 = (v122[1] + v122[3]) / 2
	v85(v57, v123 - 0.6, v122[2] + 6, v123 + 0.6, v122[4] - 6, v_u_7.paperLight, 0.2).Name = "Line"
	local v124 = v_u_1.CEMETERY
	for v125 = 0, 2 do
		for v126 = 0, 3 do
			local v127 = v124[1] + 10 + v125 * 15
			local v128 = v124[2] + 12 + v126 * 20
			local v129 = Vector2.new((v127 + v_u_34) * v_u_38, (v128 + v_u_34) * v_u_38)
			local v130 = v39 * 6
			local v131 = math.max(4, v130)
			local v132 = {
				["Name"] = "Cross",
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_7.inkSoft,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v129.X, v129.Y),
				["Size"] = UDim2.fromOffset(1, v131)
			}
			local v133 = Instance.new("Frame")
			v133.BorderSizePixel = 0
			for v134, v135 in v132 do
				v133[v134] = v135
			end
			v133.Parent = v57
			local v136 = {
				["Name"] = "Cross",
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_7.inkSoft,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v129.X, v129.Y - v131 * 0.18),
				["Size"] = UDim2.fromOffset(v131 * 0.6, 1)
			}
			local v137 = Instance.new("Frame")
			v137.BorderSizePixel = 0
			for v138, v139 in v136 do
				v137[v138] = v139
			end
			v137.Parent = v57
		end
	end
	v85(v57, v_u_1.BANK_X, -v_u_34, v_u_1.RIVER_X, v_u_34, v_u_7.bank, 0).Name = "Bank"
	v85(v57, v_u_1.RIVER_X, -v_u_34, v_u_34, v_u_34, v_u_7.water, 0).Name = "River"
	v85(v57, v_u_1.RIVER_X, -v_u_34, v_u_1.RIVER_X + 1.5, v_u_34, v_u_7.waterInk, 0.2).Name = "Shore"
	for v140 = 0, 11 do
		local v141 = -v_u_34 + 40 + v140 * 100
		local v142 = v_u_1.RIVER_X + 28 + v140 % 3 * 18
		v85(v57, v142, v141, v142 + 1.2, v141 + 46, v_u_7.waterInk, 0.55).Name = "Current"
	end
	local v143 = {
		["Name"] = "Trees",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v144 = Instance.new("Frame")
	v144.BorderSizePixel = 0
	for v145, v146 in v143 do
		v144[v145] = v146
	end
	v144.Parent = v51
	for _, v147 in v_u_1.trees() do
		local v148 = v147[1]
		local v149 = v147[2]
		local v150 = Vector2.new((v148 + v_u_34) * v_u_38, (v149 + v_u_34) * v_u_38)
		local v151 = (9 + v147[3] * 3) * v_u_38
		local v152 = math.max(3, v151)
		local v153 = {
			["Name"] = "T",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.18,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.tree,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v150.X, v150.Y),
			["Size"] = UDim2.fromOffset(v152, v152)
		}
		local v154 = Instance.new("Frame")
		v154.BorderSizePixel = 0
		for v155, v156 in v153 do
			v154[v155] = v156
		end
		v154.Parent = v144
		local v157 = UDim.new(0.5, 0)
		local v158 = Instance.new("UICorner")
		v158.CornerRadius = v157
		v158.Parent = v154
	end
	local v159 = {
		["Name"] = "Lots",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v160 = Instance.new("Frame")
	v160.BorderSizePixel = 0
	for v161, v162 in v159 do
		v160[v161] = v162
	end
	v160.Parent = v51
	for _, v163 in v_u_1.LOTS do
		v85(v160, v163[1], v163[2], v163[3], v163[4], v_u_7.lot, 0).Name = "Lot"
	end
	local v164 = {
		["Name"] = "RoadCase",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v165 = Instance.new("Frame")
	v165.BorderSizePixel = 0
	for v166, v167 in v164 do
		v165[v166] = v167
	end
	v165.Parent = v51
	local v168 = {
		["Name"] = "RoadFill",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v169 = Instance.new("Frame")
	v169.BorderSizePixel = 0
	for v170, v171 in v168 do
		v169[v170] = v171
	end
	v169.Parent = v51
	local v172 = v39 * 1.6 + 0.5
	local v173 = math.floor(v172)
	local v174 = math.max(1, v173)
	for _, v175 in v_u_1.ROADS do
		local v176 = v175.x0
		local v177 = v175.z0
		local v178 = Vector2.new((v176 + v_u_34) * v_u_38, (v177 + v_u_34) * v_u_38)
		local v179 = v175.x1
		local v180 = v175.z1
		local v181 = Vector2.new((v179 + v_u_34) * v_u_38, (v180 + v_u_34) * v_u_38)
		local v182 = {
			["Name"] = "Case",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.roadCase
		}
		local v183 = UDim2.fromOffset
		local v184 = v178.X
		local v185 = math.floor(v184) - v174
		local v186 = v178.Y
		v182.Position = v183(v185, math.floor(v186) - v174)
		local v187 = UDim2.fromOffset
		local v188 = v181.X - v178.X
		local v189 = math.ceil(v188) + v174 * 2
		local v190 = v181.Y - v178.Y
		v182.Size = v187(v189, math.ceil(v190) + v174 * 2)
		local v191 = Instance.new("Frame")
		v191.BorderSizePixel = 0
		for v192, v193 in v182 do
			v191[v192] = v193
		end
		v191.Parent = v165
		v191:SetAttribute("Road", v175.name)
		local v194 = {
			["Name"] = "Road",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil
		}
		local v195
		if v175.kind == "highway" then
			v195 = v_u_7.highway
		else
			v195 = v_u_7.road
		end
		v194.BackgroundColor3 = v195
		local v196 = UDim2.fromOffset
		local v197 = v178.X
		local v198 = math.floor(v197)
		local v199 = v178.Y
		v194.Position = v196(v198, (math.floor(v199)))
		local v200 = UDim2.fromOffset
		local v201 = v181.X - v178.X
		local v202 = math.ceil(v201)
		local v203 = v181.Y - v178.Y
		v194.Size = v200(v202, (math.ceil(v203)))
		local v204 = Instance.new("Frame")
		v204.BorderSizePixel = 0
		for v205, v206 in v194 do
			v204[v205] = v206
		end
		v204.Parent = v169
		v204:SetAttribute("Road", v175.name)
	end
	local v207 = 14 * v_u_38
	local v208 = math.max(3, v207)
	for v209 = -v_u_34 + 6, 432, 26 do
		local v210 = Vector2.new((v209 + v_u_34) * v_u_38, (0 + v_u_34) * v_u_38)
		local v211 = {
			["Name"] = "Dash",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.45,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.roadCase,
			["Position"] = UDim2.fromOffset(v210.X, v210.Y),
			["Size"] = UDim2.fromOffset(v208, 1)
		}
		local v212 = Instance.new("Frame")
		v212.BorderSizePixel = 0
		for v213, v214 in v211 do
			v212[v213] = v214
		end
		v212.Parent = v169
	end
	local v215 = {
		["Name"] = "Buildings",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v216 = Instance.new("Frame")
	v216.BorderSizePixel = 0
	for v217, v218 in v215 do
		v216[v217] = v218
	end
	v216.Parent = v51
	local v219 = {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_220 = Instance.new("Frame")
	v_u_220.BorderSizePixel = 0
	for v221, v222 in v219 do
		v_u_220[v221] = v222
	end
	v_u_220.Parent = v51
	local v_u_223 = {}
	local v_u_224 = {}
	local v_u_225 = {}
	local v_u_226 = false
	local function v_u_232(p227, p228, p229, p230) -- name: free
		-- upvalues: (copy) v_u_223
		for _, v231 in v_u_223 do
			if p227 >= v231[3] or (v231[1] >= p229 or (p228 >= v231[4] or v231[2] >= p230)) then
				continue
			end
			return false
		end
		return true
	end
	local function v263(p233, p234, p235, p236, p237, p238, p239, p240) -- name: label
		-- upvalues: (ref) v_u_2, (copy) p_u_31, (copy) v_u_34, (copy) v_u_38, (copy) v_u_232, (copy) v_u_223, (copy) v_u_224, (copy) v_u_220, (copy) v_u_32, (ref) v_u_226, (copy) v_u_225
		local v241 = v_u_2.phoneText
		local v242 = "caption"
		local v243
		if p_u_31 then
			v243 = p_u_31.scale
		else
			v243 = nil
		end
		local v244
		if p_u_31 then
			v244 = p_u_31.phone
		else
			v244 = nil
		end
		local v245 = v241(p236, v242, v243, v244)
		local v246 = Vector2.new((p234 + v_u_34) * v_u_38, (p235 + v_u_34) * v_u_38)
		local v247 = (utf8.len(p233) or #p233) * v245 * 0.56 + 6
		local v248 = v245 + 2
		local v249
		if p239 then
			v249 = p239.Rotation
		else
			v249 = p239
		end
		if v249 then
			if math.abs(v249) ~= 90 then
				local v250 = v247
				v247 = v248
				v248 = v250
			end
		else
			local v251 = v247
			v247 = v248
			v248 = v251
		end
		if not (p240 or v_u_232(v246.X - v248 / 2, v246.Y - v247 / 2, v246.X + v248 / 2, v246.Y + v247 / 2)) then
			return nil
		end
		local v252 = {
			v246.X - v248 / 2,
			v246.Y - v247 / 2,
			v246.X + v248 / 2,
			v246.Y + v247 / 2
		}
		local v253 = v_u_223
		table.insert(v253, v252)
		v_u_224[v252] = true
		local v254 = v_u_220
		local v255 = v_u_32
		local v256 = v_u_2.phoneText
		local v257 = "caption"
		local v258
		if p_u_31 then
			v258 = p_u_31.scale
		else
			v258 = nil
		end
		local v259
		if p_u_31 then
			v259 = p_u_31.phone
		else
			v259 = nil
		end
		local v260 = v255(v254, p233, v246, v256(v245, v257, v258, v259), p237, p238, p239)
		if v_u_226 then
			local v261 = v_u_225
			local v262 = {
				["id"] = "",
				["kind"] = "name",
				["rect"] = nil,
				["obj"] = nil,
				["rect"] = v_u_223[#v_u_223],
				["obj"] = v260
			}
			table.insert(v261, v262)
		end
		return v260
	end
	local v264 = {}
	if p29 then
		local v265 = p29.buildings
		if type(v265) == "table" and #p29.buildings > 0 then
			for _, v266 in p29.buildings do
				local v267 = v266.cf
				if typeof(v267) ~= "CFrame" then
					continue
				end
				local v268 = v266.size
				if typeof(v268) ~= "Vector3" then
					continue
				end
				local _, v269, _ = v266.cf:ToOrientation()
				local v270 = {
					["kind"] = v266.kind,
					["id"] = v266.id,
					["x"] = v266.cf.X,
					["z"] = v266.cf.Z,
					["w"] = v266.size.X,
					["d"] = v266.size.Z,
					["yaw"] = math.deg(v269),
					["name"] = v266.name
				}
				table.insert(v264, v270)
			end
		end
	end
	if #v264 == 0 then
		for _, v271 in v_u_1.BUILDINGS do
			local v272 = {
				["kind"] = v271[1],
				["id"] = v271[2],
				["x"] = v271[3],
				["z"] = v271[4],
				["w"] = v271[5],
				["d"] = v271[6],
				["yaw"] = v271[7],
				["name"] = v271[8]
			}
			table.insert(v264, v272)
		end
	else
		for _, v273 in v_u_1.BUILDINGS do
			if v273[1] ~= "Annex" then
				continue
			end
			local v274 = {
				["kind"] = v273[1],
				["id"] = v273[2],
				["x"] = v273[3],
				["z"] = v273[4],
				["w"] = v273[5],
				["d"] = v273[6],
				["yaw"] = v273[7],
				["name"] = v273[8]
			}
			table.insert(v264, v274)
		end
	end
	local v275 = {}
	for _, v276 in v264 do
		local v277 = v_u_1.LANDMARKS[v276.id] or v_u_1.LANDMARK_KINDS[v276.kind]
		local v278 = v276.x
		local v279 = v276.z
		local v280 = v276.w
		local v281 = v276.d
		local v282 = v276.yaw
		local v283
		if v277 then
			v283 = v_u_7.landmark
		else
			v283 = v_u_7.build
		end
		local v284 = v109(v216, v278, v279, v280, v281, v282, v283)
		local v285 = v276.id
		v284.Name = "B_" .. tostring(v285)
		local v286
		if v277 then
			v286 = v_u_7.landmarkEdge
		else
			v286 = v_u_7.buildEdge
		end
		local v287 = Instance.new("UIStroke")
		v287.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v287.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v287.Color = v286
		v287.Thickness = 1
		v287.Transparency = 0.1
		v287.Parent = v284
		if not v277 then
			continue
		end
		table.insert(v275, {
			["text"] = v277,
			["b"] = v276
		})
	end
	for _, v288 in v_u_1.STRUCTURES do
		local v289 = v109(v216, v288[1], v288[2], v288[3], v288[4], v288[5], v_u_7.build)
		v289.Name = "S"
		v289.BackgroundTransparency = 0.15
		local v290 = v_u_7.buildEdge
		local v291 = Instance.new("UIStroke")
		v291.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v291.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v291.Color = v290
		v291.Thickness = 1
		v291.Transparency = 0.3
		v291.Parent = v289
	end
	local v292 = v39 * 13 + 0.5
	local v293 = math.floor(v292)
	local v294 = math.max(10, v293)
	local v295 = v_u_2.phoneText
	local v296 = "text"
	local v297
	if p_u_31 then
		v297 = p_u_31.scale
	else
		v297 = nil
	end
	local v298
	if p_u_31 then
		v298 = p_u_31.phone
	else
		v298 = nil
	end
	local v299 = v295(v294, v296, v297, v298)
	table.sort(v275, function(p300, p301)
		return p300.b.w * p300.b.d > p301.b.w * p301.b.d
	end)
	for _, v302 in v275 do
		local v303 = v302.b
		local v304 = v303.w
		local v305 = v303.d
		local v306 = math.max(v304, v305) * 0.5 + 9 / v_u_38 * 0.9
		local v307 = string.upper(v302.text)
		if v263(v307, v303.x, v303.z + v306, v299, v41, v_u_7.redDeep) or v263(v307, v303.x, v303.z - v306, v299, v41, v_u_7.redDeep) then
			continue
		end
		local v308 = v303.w
		local v309 = v303.d
		local v310 = math.max(v308, v309) * 0.5 + ((utf8.len(v307) or #v307) * v299 * 0.56 + 6 + 4) * 0.5 / v_u_38
		if v33 and (v263(v307, v303.x + v310, v303.z, v299, v41, v_u_7.redDeep) or v263(v307, v303.x - v310, v303.z, v299, v41, v_u_7.redDeep)) then
			continue
		end
		v263(v307, v303.x, v303.z, v299, v41, v_u_7.redDeep, nil, true)
	end
	local v311 = #v_u_223
	local v312
	if v_u_4 == nil then
		v312 = false
	else
		v312 = v_u_4.clean()
	end
	v_u_226 = v312
	local v313 = v39 * 11 + 0.5
	local v314 = math.floor(v313)
	local v315 = math.max(9, v314)
	local v316 = {
		["Route 9"] = -500,
		["Main St"] = 130,
		["River Rd"] = -250,
		["Oak Ave"] = -60,
		["Elm St"] = 150,
		["Pine St"] = -380,
		["Church St"] = -380,
		["Hospital Rd"] = -230,
		["School Rd"] = 120,
		["Farm Rd"] = -300
	}
	for _, v317 in v_u_1.ROADS do
		local v318 = v317.x1 - v317.x0 > v317.z1 - v317.z0
		local v319 = v316[v317.name] or 0
		local v320
		if v318 then
			v320 = v319
		else
			v320 = (v317.x0 + v317.x1) / 2
		end
		local v321
		if v318 then
			v321 = (v317.z0 + v317.z1) / 2
		else
			v321 = v319
		end
		local v322 = {
			["Rotation"] = nil,
			["TextStrokeColor3"] = nil,
			["TextStrokeTransparency"] = 0.1,
			["Rotation"] = v318 and 0 or 90,
			["TextStrokeColor3"] = v_u_7.road
		}
		local v323 = false
		if v33 then
			local v324
			if v318 then
				v324 = v317.x0
			else
				v324 = v317.z0
			end
			local v325
			if v318 then
				v325 = v317.x1
			else
				v325 = v317.z1
			end
			local v326 = ((utf8.len(v317.name) or #v317.name) * v315 * 0.56 + 6) * 0.5 / v_u_38
			for _, v327 in {
				0,
				30,
				-30,
				60,
				-60,
				90,
				-90,
				120,
				-120,
				150,
				-150,
				180,
				-180,
				240,
				-240,
				300,
				-300
			} do
				local v328 = v319 + v327
				if v324 > v328 - v326 or v328 + v326 > v325 then
					continue
				end
				local v329
				if v318 then
					v329 = v328
				else
					v329 = v320
				end
				if v318 then
					v328 = v321
				end
				if not v263(string.upper(v317.name), v329, v328, v315, v43, v_u_7.inkSoft, v322, false) then
					continue
				end
				v323 = true
			end
		end
		if v323 then
			continue
		end
		v263(string.upper(v317.name), v320, v321, v315, v43, v_u_7.inkSoft, v322, true)
	end
	local v330 = v39 * 13 + 0.5
	local v331 = math.floor(v330)
	local v332 = math.max(10, v331)
	for _, v333 in v_u_1.AREAS do
		local v334 = v333[4]
		local v335
		if v334 == "water" then
			v335 = v_u_7.waterInk
		elseif v334 == "wood" then
			v335 = Color3.fromHex("4E5A33")
		else
			v335 = v_u_7.inkSoft
		end
		local v336 = {
			["TextStrokeTransparency"] = 0.45
		}
		if v334 == "water" then
			v336.Rotation = 90
			v336.TextStrokeColor3 = v_u_7.water
		end
		local v337 = v_u_26(v333[3])
		local v338 = v333[1]
		local v339 = v333[2]
		local _ = v334 == "water"
		v263(v337, v338, v339, v332, v40, v335, v336)
	end
	local v340 = {
		["Name"] = "Deco",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v341 = Instance.new("Frame")
	v341.BorderSizePixel = 0
	for v342, v343 in v340 do
		v341[v342] = v343
	end
	v341.Parent = v51
	for v344 = 1, 5 do
		local v345 = v344 / 6
		local v346 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.grid,
			["Position"] = UDim2.new(v345, 0, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v347 = Instance.new("Frame")
		v347.BorderSizePixel = 0
		for v348, v349 in v346 do
			v347[v348] = v349
		end
		v347.Parent = v341
		local v350 = {
			["Name"] = "Grid",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.grid,
			["Position"] = UDim2.new(0, 0, v345, 0),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v351 = Instance.new("Frame")
		v351.BorderSizePixel = 0
		for v352, v353 in v350 do
			v351[v352] = v353
		end
		v351.Parent = v341
	end
	for _, v354 in { 0.3333333333333333, 0.6666666666666666 } do
		local v355 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_7.paperLight,
			["Position"] = UDim2.new(v354, 0, 0, 0),
			["Size"] = UDim2.new(0, 2, 1, 0)
		}
		local v356 = Instance.new("Frame")
		v356.BorderSizePixel = 0
		for v357, v358 in v355 do
			v356[v357] = v358
		end
		v356.Parent = v45
		local v359 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_7.crease,
			["Position"] = UDim2.new(v354, 2, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v360 = Instance.new("Frame")
		v360.BorderSizePixel = 0
		for v361, v362 in v359 do
			v360[v361] = v362
		end
		v360.Parent = v45
	end
	local v363 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_7.paperLight,
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v364 = Instance.new("Frame")
	v364.BorderSizePixel = 0
	for v365, v366 in v363 do
		v364[v365] = v366
	end
	v364.Parent = v45
	local v367 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_7.crease,
		["Position"] = UDim2.new(0, 0, 0.5, 2),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v368 = Instance.new("Frame")
	v368.BorderSizePixel = 0
	for v369, v370 in v367 do
		v368[v369] = v370
	end
	v368.Parent = v45
	local v371 = v39 * 12 + 0.5
	local v372 = math.floor(v371)
	local v373 = math.max(9, v372)
	local v374 = {
		"A",
		"B",
		"C",
		"D",
		"E",
		"F"
	}
	for v375 = 1, 6 do
		local v376 = v36 + v37 * (v375 - 0.5) / 6
		for _, v377 in { v36 / 2, p28 - v36 / 2 } do
			local v378 = v374[v375]
			local v379 = Vector2.new(v376, v377)
			local v380 = v_u_7.inkSoft
			local v381 = v_u_2.phoneText
			local v382 = "caption"
			local v383
			if p_u_31 then
				v383 = p_u_31.scale
			else
				v383 = nil
			end
			local v384
			if p_u_31 then
				v384 = p_u_31.phone
			else
				v384 = nil
			end
			local v385 = v_u_32(v45, v378, v379, v381(v373, v382, v383, v384), v40, v380, nil)
			v385.ZIndex = 21
			v385.TextStrokeTransparency = 1
		end
		for _, v386 in { v36 / 2, p28 - v36 / 2 } do
			local v387 = tostring(v375)
			local v388 = Vector2.new(v386, v376)
			local v389 = v_u_7.inkSoft
			local v390 = v_u_2.phoneText
			local v391 = "caption"
			local v392
			if p_u_31 then
				v392 = p_u_31.scale
			else
				v392 = nil
			end
			local v393
			if p_u_31 then
				v393 = p_u_31.phone
			else
				v393 = nil
			end
			local v394 = v_u_32(v45, v387, v388, v390(v373, v391, v392, v393), v40, v389, nil)
			v394.ZIndex = 21
			v394.TextStrokeTransparency = 1
		end
	end
	local v395 = 196 * v39
	local v396 = math.floor(v395)
	local v397 = 52 * v39
	local v398 = math.floor(v397)
	local v_u_399 = v_u_26("Stillwater")
	local v400 = v39 * 20
	local v401 = math.floor(v400)
	local v402 = math.max(13, v401)
	local v403 = v_u_2.phoneText
	local v404 = "text"
	local v405
	if p_u_31 then
		v405 = p_u_31.scale
	else
		v405 = nil
	end
	local v406
	if p_u_31 then
		v406 = p_u_31.phone
	else
		v406 = nil
	end
	local v_u_407 = v403(v402, v404, v405, v406)
	if v33 then
		local function v408()
			-- upvalues: (ref) v_u_5, (copy) v_u_399, (copy) v_u_407
			return v_u_5:GetTextSize(v_u_399, v_u_407, Enum.Font.GothamBold, Vector2.new(1000, 100))
		end
		local v409, v410 = pcall(v408)
		local v411
		if v409 then
			v411 = v410.X
		else
			v411 = #v_u_399 * v_u_407 * 0.7
		end
		local v412 = v411 + 14
		local v413 = math.ceil(v412)
		v396 = math.max(v396, v413)
		local v414 = 34 * v39
		local v415 = math.floor(v414)
		local v416 = v_u_407 + 10
		v398 = math.max(v415, v416)
	end
	local v417 = {
		["Name"] = "Cartouche",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_7.paperLight
	}
	local v418 = UDim2.fromOffset
	local v419 = v39 * 10
	local v420 = math.floor(v419)
	local v421 = v39 * 10
	v417.Position = v418(v420, (math.floor(v421)))
	v417.Size = UDim2.fromOffset(v396, v398)
	local v422 = Instance.new("Frame")
	v422.BorderSizePixel = 0
	for v423, v424 in v417 do
		v422[v423] = v424
	end
	v422.Parent = v51
	local v425 = v_u_7.ink
	local v426 = Instance.new("UIStroke")
	v426.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v426.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v426.Color = v425
	v426.Thickness = 1
	v426.Transparency = 0
	v426.Parent = v422
	local v427 = Vector2.new
	local v428
	if v33 then
		v428 = v396 / 2
	else
		v428 = 98 * v39
	end
	local v429
	if v33 then
		v429 = v398 / 2
	else
		v429 = 19 * v39
	end
	local v430 = v427(v428, v429)
	local v431 = v_u_7.ink
	local v432 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil
	}
	local v433 = UDim2.fromOffset
	local v434
	if v33 then
		v434 = v396 - 4
	else
		v434 = 190 * v39
	end
	local v435
	if v33 then
		v435 = v398 - 4
	else
		v435 = 24 * v39
	end
	v432.Size = v433(v434, v435)
	local v436 = v_u_2.phoneText
	local v437 = "caption"
	local v438
	if p_u_31 then
		v438 = p_u_31.scale
	else
		v438 = nil
	end
	local v439
	if p_u_31 then
		v439 = p_u_31.phone
	else
		v439 = nil
	end
	v_u_32(v422, v_u_399, v430, v436(v_u_407, v437, v438, v439), v41, v431, v432).ZIndex = 11
	if not v33 then
		local v440 = Vector2.new(98 * v39, 39 * v39)
		local v441 = v39 * 11
		local v442 = math.floor(v441)
		local v443 = math.max(9, v442)
		local v444 = v_u_7.inkSoft
		local v445 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(190 * v39, 14 * v39)
		}
		local v446 = "Town map, county survey"
		local v447 = v_u_2.phoneText
		local v448 = "caption"
		local v449
		if p_u_31 then
			v449 = p_u_31.scale
		else
			v449 = nil
		end
		local v450
		if p_u_31 then
			v450 = p_u_31.phone
		else
			v450 = nil
		end
		v_u_32(v422, v446, v440, v447(v443, v448, v449, v450), v42, v444, v445).ZIndex = 11
	end
	local v451
	if v_u_4 == nil then
		v451 = false
	else
		v451 = v_u_4.clean()
	end
	local v452 = {}
	local v453 = v39 * 15
	local v454 = math.floor(v453)
	local v455 = math.max(11, v454)
	local v456 = v37 - 34 * v39
	local v457 = v39 * 40
	if v451 then
		local v458 = 17 * v39 + v455 + 4
		v457 = math.max(v457, v458)
		local v459 = {
			v456 - 17 * v39 - 2,
			v457 - 17 * v39 - v455 - 4,
			v456 + 17 * v39 + 2,
			v457 + 17 * v39 + 2
		}
		table.insert(v452, v459)
		local v460 = {}
		local v461 = v39 * 10
		local v462 = math.floor(v461)
		local v463 = v39 * 10
		local v464 = math.floor(v463)
		local v465 = v39 * 10
		local v466 = math.floor(v465) + v396
		local v467 = v39 * 10
		__set_list(v460, 1, {v462, v464, v466, math.floor(v467) + v398})
		table.insert(v452, v460)
	end
	local v468 = Vector2.new
	local v469
	if v451 then
		v469 = 17 * v39 + v455 * 0.5 + 3
	else
		v469 = 22 * v39
	end
	local v470 = v468(v456, v457 - v469)
	local v471 = v_u_7.ink
	local v472 = {
		["TextStrokeTransparency"] = 1
	}
	local v473 = "N"
	local v474 = v_u_2.phoneText
	local v475 = "caption"
	local v476
	if p_u_31 then
		v476 = p_u_31.scale
	else
		v476 = nil
	end
	local v477
	if p_u_31 then
		v477 = p_u_31.phone
	else
		v477 = nil
	end
	v_u_32(v51, v473, v470, v474(v455, v475, v476, v477), v41, v471, v472).ZIndex = 10
	local v478 = {
		["Name"] = "Needle",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_7.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v456, v457),
		["Size"] = UDim2.fromOffset(2, v39 * 28)
	}
	local v479 = Instance.new("Frame")
	v479.BorderSizePixel = 0
	for v480, v481 in v478 do
		v479[v480] = v481
	end
	v479.Parent = v51
	local v482 = {
		["Name"] = "NeedleTip",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_7.red,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v456, v457 - v39 * 9),
		["Size"] = UDim2.fromOffset(v39 * 7, v39 * 7)
	}
	local v483 = Instance.new("Frame")
	v483.BorderSizePixel = 0
	for v484, v485 in v482 do
		v483[v484] = v485
	end
	v483.Parent = v51
	local v486 = {
		["Name"] = "Cross",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_7.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v456, v457),
		["Size"] = UDim2.fromOffset(16 * v39, 1)
	}
	local v487 = Instance.new("Frame")
	v487.BorderSizePixel = 0
	for v488, v489 in v486 do
		v487[v488] = v489
	end
	v487.Parent = v51
	local v490 = {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v456, v457),
		["Size"] = UDim2.fromOffset(34 * v39, 34 * v39)
	}
	local v491 = Instance.new("Frame")
	v491.BorderSizePixel = 0
	for v492, v493 in v490 do
		v491[v492] = v493
	end
	v491.Parent = v51
	local v494 = UDim.new(0.5, 0)
	local v495 = Instance.new("UICorner")
	v495.CornerRadius = v494
	v495.Parent = v491
	local v496 = v_u_7.ink
	local v497 = Instance.new("UIStroke")
	v497.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v497.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v497.Color = v496
	v497.Thickness = 1
	v497.Transparency = 0.3
	v497.Parent = v491
	local v498 = 100 / v_u_1.STUDS_TO_M * v_u_38
	local v499 = 14 * v39
	local v500 = v37 - 26 * v39
	for v501 = 0, 3 do
		local v502 = {
			["Name"] = "Scale",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 10
		}
		local v503
		if v501 % 2 == 0 then
			v503 = v_u_7.ink
		else
			v503 = v_u_7.paperLight
		end
		v502.BackgroundColor3 = v503
		v502.Position = UDim2.fromOffset(v499 + v501 * v498 / 4, v500)
		local v504 = UDim2.fromOffset
		local v505 = v498 / 4
		local v506 = v39 * 5
		v502.Size = v504(v505, (math.max(3, v506)))
		local v507 = Instance.new("Frame")
		v507.BorderSizePixel = 0
		for v508, v509 in v502 do
			v507[v508] = v509
		end
		v507.Parent = v51
		local v510 = v_u_7.ink
		local v511 = Instance.new("UIStroke")
		v511.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v511.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v511.Color = v510
		v511.Thickness = 1
		v511.Transparency = 0
		v511.Parent = v507
	end
	local v512
	if v451 then
		v512 = v39 * 9 + 3
	else
		v512 = v39 * 9
	end
	local v513 = Vector2.new(v499, v500 - v512)
	local v514 = v39 * 11
	local v515 = math.floor(v514)
	local v516 = math.max(9, v515)
	local v517 = v_u_7.ink
	local v518 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v519 = "0"
	local v520 = v_u_2.phoneText
	local v521 = "caption"
	local v522
	if p_u_31 then
		v522 = p_u_31.scale
	else
		v522 = nil
	end
	local v523
	if p_u_31 then
		v523 = p_u_31.phone
	else
		v523 = nil
	end
	v_u_32(v51, v519, v513, v520(v516, v521, v522, v523), v43, v517, v518).ZIndex = 10
	local v524 = Vector2.new(v499 + v498, v500 - v512)
	local v525 = v39 * 11
	local v526 = math.floor(v525)
	local v527 = math.max(9, v526)
	local v528 = v_u_7.ink
	local v529 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v530 = "100 m"
	local v531 = v_u_2.phoneText
	local v532 = "caption"
	local v533
	if p_u_31 then
		v533 = p_u_31.scale
	else
		v533 = nil
	end
	local v534
	if p_u_31 then
		v534 = p_u_31.phone
	else
		v534 = nil
	end
	v_u_32(v51, v530, v524, v531(v527, v532, v533, v534), v43, v528, v529).ZIndex = 10
	if v451 then
		local v535 = {}
		local v536 = v499 - 8
		local v537 = v500 - v512 - 9
		local v538 = v499 + v498 + 34
		local v539 = v39 * 5
		__set_list(v535, 1, {v536, v537, v538, v500 + math.max(3, v539) + 3})
		table.insert(v452, v535)
	end
	local v540 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v541 = Instance.new("Frame")
	v541.BorderSizePixel = 0
	for v542, v543 in v540 do
		v541[v542] = v543
	end
	v541.Parent = v51
	return {
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["labelLayer"] = nil,
		["nameRects"] = nil,
		["removable"] = nil,
		["reserved"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["positions"] = true,
		["frame"] = v45,
		["area"] = v51,
		["marks"] = v541,
		["toPx"] = v88,
		["toWorld"] = function(p544, p545) -- name: toWorld
			-- upvalues: (copy) v_u_38, (copy) v_u_34
			return Vector2.new(p544 / v_u_38 - v_u_34, p545 / v_u_38 - v_u_34)
		end,
		["inside"] = function(p546, p547) -- name: inside
			-- upvalues: (copy) v_u_34
			local v548
			if math.abs(p546) <= v_u_34 then
				v548 = math.abs(p547) <= v_u_34
			else
				v548 = false
			end
			return v548
		end,
		["placed"] = v_u_223,
		["labelLayer"] = v_u_220,
		["nameRects"] = v_u_224,
		["removable"] = v_u_225,
		["reserved"] = v452,
		["nLandmarks"] = v311,
		["scale"] = v_u_38,
		["k"] = v39,
		["ink"] = v_u_7,
		["inner"] = v37
	}
end
return v6