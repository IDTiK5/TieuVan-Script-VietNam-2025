-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIRoll

local v_u_1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_2 = require(v_u_1:WaitForChild("Items"))
local v_u_3 = require(v_u_1:WaitForChild("RollRules"))
local v_u_81 = {
	["TEXT"] = v_u_3.TEXT,
	["IDS"] = {
		["roll"] = true,
		["unroll"] = true,
		["unrollwear"] = true
	},
	["env"] = nil,
	["GAP"] = 0.8,
	["sentAt"] = {},
	["contents"] = function(p4, p5) -- name: contents
		local v6 = p5.item
		if p5.kind ~= "slot" then
			local v7 = v6.items
			return type(v7) == "table" and #v6.items or 0
		end
		local v8 = p4.work
		local v9
		if type(v8) == "table" then
			v9 = p4.work.containers
		else
			v9 = nil
		end
		local v10
		if type(v9) == "table" then
			if p4.mode == "raid" then
				v10 = v9.bag
			else
				v10 = v9.lo_bag
			end
		else
			v10 = nil
		end
		if type(v10) == "table" then
			local v11 = v10.items
			if type(v11) == "table" then
				return #v10.items
			end
		end
		return 0
	end,
	["facts"] = function(p12, p13) -- name: facts
		-- upvalues: (copy) v_u_81
		local v14 = {}
		local v15
		if p13.kind == "slot" then
			v15 = "slot"
		else
			local v16
			if p13.container == "ground" then
				v16 = true
			else
				local v17 = p13.c
				if type(v17) == "table" then
					v16 = p13.c.world == true
				else
					v16 = false
				end
			end
			v15 = v16 and "world" or (p13.container == "stash" and "stash" or "kit")
		end
		v14.where = v15
		v14.contents = v_u_81.contents(p12, p13)
		local v18 = p12.work
		local v19
		if type(v18) == "table" then
			local v20 = v18.kit
			if type(v20) == "table" then
				v19 = v18.kit
			else
				v19 = nil
			end
		else
			v19 = nil
		end
		local v21
		if v19 then
			local v22 = v19.slots
			if type(v22) == "table" then
				v21 = v19.slots.bag
			else
				v21 = nil
			end
			if v21 == nil then
				v21 = v19.bag
			end
			if type(v21) ~= "table" then
				v21 = nil
			end
		else
			v21 = nil
		end
		v14.slotFree = v21 == nil
		return v14
	end,
	["entries"] = function(p23, p24) -- name: entries
		-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_81
		local v25 = {}
		if type(p23) == "table" and (not p23.fake and type(p24) == "table") then
			local v26 = p24.item
			if type(v26) == "table" then
				if p24.kind == "slot" and p24.slot ~= "bag" then
					return v25
				end
				local v27 = v_u_2.get(p24.item.id)
				local v28 = v_u_3.offer(v27, p24.item, v_u_81.facts(p23, p24))
				local v29 = v_u_81.TEXT
				if v28.roll then
					local v30 = {
						["id"] = "roll",
						["text"] = nil,
						["text"] = v29.roll
					}
					table.insert(v25, v30)
				end
				if v28.unroll then
					local v31 = {
						["id"] = "unroll",
						["text"] = nil,
						["text"] = v29.unroll
					}
					table.insert(v25, v31)
					if v28.wear then
						local v32 = {
							["id"] = "unrollwear",
							["text"] = nil,
							["text"] = v29.wear
						}
						table.insert(v25, v32)
					end
				end
				return v25
			end
		end
		return v25
	end,
	["acts"] = function(p33, p34, p35) -- name: acts
		-- upvalues: (copy) v_u_81
		for _, v36 in v_u_81.entries(p33, p34) do
			table.insert(p35, v36)
		end
	end,
	["strip"] = function(p37, p38, p39) -- name: strip
		-- upvalues: (copy) v_u_81
		for _, v40 in v_u_81.entries(p37, p38) do
			local v41 = {
				["id"] = nil,
				["text"] = nil,
				["icon"] = "use",
				["id"] = v40.id,
				["text"] = v40.text
			}
			table.insert(p39, v41)
		end
	end,
	["op"] = function(p42, p43) -- name: op
		return {
			["op"] = p42,
			["uid"] = p43
		}
	end,
	["run"] = function(p44, p45, p46) -- name: run
		-- upvalues: (copy) v_u_81
		if v_u_81.IDS[p46] ~= true then
			return false
		end
		local v47 = p45 .. "|" .. p46
		local v48 = os.clock()
		local v49 = v_u_81.sentAt[v47]
		if v49 ~= nil and v48 - v49 < v_u_81.GAP then
			return true
		end
		v_u_81.sentAt[v47] = v48
		local v50 = v_u_81.env
		if v50 then
			v50 = v_u_81.env.send
		end
		if type(v50) == "function" then
			v50(p44, v_u_81.op(p46, p45))
		end
		return true
	end,
	["tip"] = function(p51, p52) -- name: tip
		-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_81
		if type(p51) == "table" and type(p52) == "table" then
			local v53 = p52.item
			if type(v53) == "table" then
				if p52.kind == "slot" and p52.slot ~= "bag" then
					return nil
				else
					return v_u_3.offer(v_u_2.get(p52.item.id), p52.item, v_u_81.facts(p51, p52)).tip
				end
			end
		end
		return nil
	end,
	["tipFilled"] = function(p54) -- name: tipFilled
		-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_81
		if type(p54) == "table" then
			local v55 = p54.items
			if type(v55) == "table" and #p54.items ~= 0 then
				if v_u_3.canRoll(v_u_2.get(p54.id)) then
					return v_u_81.TEXT.tipFilled
				else
					return nil
				end
			end
		end
		return nil
	end,
	["addRow"] = function(p_u_56, p_u_57, p_u_58) -- name: addRow
		-- upvalues: (copy) v_u_1
		local function v69()
			-- upvalues: (ref) v_u_1, (copy) p_u_58, (copy) p_u_57, (copy) p_u_56
			local v59 = require(v_u_1:WaitForChild("Theme"))
			local v60 = require(script.Parent:WaitForChild("HushUI"))
			local v61 = v59.color
			local v62 = Instance.new("Frame")
			v62.Name = "RollChip"
			v62.LayoutOrder = p_u_58
			v62.BackgroundColor3 = v61.raised
			v62.BackgroundTransparency = 0.25
			v62.BorderSizePixel = 0
			v62.Size = UDim2.new(1, -6, 0, 0)
			v62.AutomaticSize = Enum.AutomaticSize.Y
			v62.ZIndex = 63
			local v63 = Instance.new("UIPadding")
			local v64 = UDim.new(0, 10)
			local v65 = UDim.new(0, 8)
			local v66 = UDim.new(0, 6)
			local v67 = UDim.new(0, 6)
			v63.PaddingLeft = v64
			v63.PaddingRight = v65
			v63.PaddingTop = v66
			v63.PaddingBottom = v67
			v63.Parent = v62
			local v68 = v60.label({
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["size"] = nil,
				["track"] = false,
				["text"] = p_u_57,
				["color"] = v61.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			v68.Name = "Text"
			v68.ZIndex = 64
			v68.Parent = v62
			v62.Parent = p_u_56
			return v62
		end
		local v70, v71 = pcall(v69)
		if v70 then
			return v71
		else
			return nil
		end
	end,
	["predict"] = function(p72, p73, p74) -- name: predict
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		if p74 == "menu" and (type(p73) == "table" and (p73.op == "roll" and type(p72) == "table")) then
			local v75 = p72.containers
			if type(v75) == "table" then
				for _, v76 in p72.containers do
					if type(v76) ~= "table" then
						continue
					end
					local v77 = v76.items
					if type(v77) ~= "table" or v76.world == true then
						continue
					end
					for _, v78 in v76.items do
						if v78.uid ~= p73.uid then
							continue
						end
						local v79 = v_u_2.get(v78.id)
						if v_u_3.canRoll(v79) then
							local v80 = v78.items
							if (type(v80) ~= "table" or #v78.items <= 0) and v78.lk ~= true then
								v78.id = v79.rollsTo
								v78.items = nil
								return true
							end
						end
						return false
					end
				end
				return false
			end
		end
		return false
	end
}
return v_u_81