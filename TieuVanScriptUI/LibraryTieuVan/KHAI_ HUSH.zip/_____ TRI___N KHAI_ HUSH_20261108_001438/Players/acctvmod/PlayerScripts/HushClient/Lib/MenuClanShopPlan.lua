-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanShopPlan

local v_u_180 = {
	["GAP"] = 10,
	["PAD"] = 10,
	["SWATCH"] = 56,
	["CHAR_W"] = 7.8,
	["SMALL_W"] = 7.4,
	["LINE"] = 16,
	["PHONE_FIXED_MAX"] = 96,
	["colsFor"] = function(p1) -- name: colsFor
		local v2 = tonumber(p1) or 0
		return v2 >= 1100 and 3 or (v2 >= 700 and 2 or 1)
	end,
	["chipW"] = function(p3) -- name: chipW
		-- upvalues: (copy) v_u_180
		local v4 = #tostring(p3 or "") * v_u_180.CHAR_W + 18
		return math.ceil(v4)
	end,
	["lines"] = function(p5, p6, p7) -- name: lines
		-- upvalues: (copy) v_u_180
		local v8 = tostring(p5 or "")
		local v9 = (tonumber(p6) or 100) / (tonumber(p7) or v_u_180.SMALL_W)
		local v10 = math.floor(v9)
		local v11 = math.max(1, v10)
		local v12 = 0
		local v13 = 1
		for v14 in string.gmatch(v8, "%S+") do
			local v15 = #v14
			if v12 == 0 then
				v12 = v15
			elseif v12 + 1 + v15 <= v11 then
				v12 = v12 + (v15 + 1)
			else
				v13 = v13 + 1
				v12 = v15
			end
			while v11 < v12 do
				v13 = v13 + 1
				v12 = v12 - v11
			end
		end
		return v13
	end,
	["btnW"] = function(p16, p17) -- name: btnW
		local v18 = tonumber(p17) or 44
		local v19 = math.max(44, v18) * 2
		local v20 = math.ceil(v19)
		local v21 = #tostring(p16 or "") * 9.5
		local v22 = math.ceil(v21) + 56
		return math.max(v20, v22)
	end,
	["stepper"] = function(p23, p24) -- name: stepper
		local v25 = {
			["prev"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p24,
				["h"] = p24
			}
		}
		local v26 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = p24
		}
		local v27 = p23 - p24 * 2
		v26.w = math.max(1, v27)
		v26.h = p24
		v25.label = v26
		v25.next = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = p23 - p24,
			["w"] = p24,
			["h"] = p24
		}
		return v25
	end,
	["STEPPER_LABEL"] = 96,
	["top"] = function(p28, p29, p30) -- name: top
		local v31 = p29 == "phone"
		local v32 = {
			["W"] = p28,
			["kind"] = p29,
			["groups"] = {}
		}
		local v33 = math.max(44, p30 or 44)
		local v34 = v31 and 30 or 52
		local v35 = v31 and {
			["coins"] = 150,
			["pts"] = 330,
			["payout"] = 190
		} or {
			["coins"] = 150,
			["pts"] = 330,
			["payout"] = 170
		}
		if p28 < v35.coins + v35.pts + v35.payout + 16 then
			local v36 = (p28 - 16) / (v35.coins + v35.pts + v35.payout)
			for v37, v38 in v35 do
				local v39 = v38 * v36
				local v40 = math.floor(v39)
				v35[v37] = math.max(40, v40)
			end
			local _ = v35.coins + v35.pts + v35.payout + 16
		end
		local v41 = 0
		local v42 = {}
		for _, v43 in { "coins", "pts", "payout" } do
			local v44 = v35[v43]
			local v45 = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v41,
				["w"] = v44,
				["h"] = v34
			}
			local v46
			if v31 then
				v46 = {
					["value"] = {
						["x"] = 0,
						["y"] = 0,
						["w"] = nil,
						["h"] = nil,
						["w"] = v44,
						["h"] = v43 == "pts" and 26 or v34
					}
				}
				if v43 == "pts" then
					v46.bar = {
						["x"] = 0,
						["y"] = 26,
						["w"] = nil,
						["h"] = 4,
						["w"] = v44
					}
				end
			else
				v46 = {
					["label"] = {
						["x"] = 12,
						["y"] = 6,
						["w"] = nil,
						["h"] = 14,
						["w"] = v44 - 24
					},
					["value"] = {
						["x"] = 12,
						["y"] = 20,
						["w"] = nil,
						["h"] = 22,
						["w"] = v44 - 24
					}
				}
				if v43 == "pts" then
					v46.bar = {
						["x"] = 12,
						["y"] = 44,
						["w"] = nil,
						["h"] = 4,
						["w"] = v44 - 24
					}
				end
			end
			v42[v43] = {
				["box"] = v45,
				["parts"] = v46
			}
			local v47 = v32.groups
			table.insert(v47, {
				["name"] = v43,
				["box"] = v45,
				["parts"] = v46
			})
			v41 = v41 + (v44 + 8)
		end
		local v48 = p28 - v41
		if not v31 and v48 >= 150 then
			local v49 = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v41,
				["w"] = v48,
				["h"] = v34
			}
			local v50 = {
				["label"] = {
					["x"] = 12,
					["y"] = 6,
					["w"] = nil,
					["h"] = 14,
					["w"] = v48 - 24
				},
				["value"] = {
					["x"] = 12,
					["y"] = 20,
					["w"] = nil,
					["h"] = 22,
					["w"] = v48 - 24
				}
			}
			v42.last = {
				["box"] = v49,
				["parts"] = v50
			}
			local v51 = v32.groups
			table.insert(v51, {
				["name"] = "last",
				["box"] = nil,
				["parts"] = nil,
				["box"] = v49,
				["parts"] = v50
			})
		end
		v32.chips = v42
		v32.headH = v34
		local v52 = v34 + (v31 and 6 or 8)
		if not v31 then
			v32.cats = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v52,
				["w"] = p28,
				["h"] = v33
			}
			local v53 = v32.groups
			local v54 = {
				["name"] = "cats",
				["box"] = nil,
				["box"] = v32.cats
			}
			table.insert(v53, v54)
			v52 = v52 + (v33 + 8)
		end
		local v55 = v31 and 44 or 56
		local v56 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v52,
			["w"] = p28,
			["h"] = v55
		}
		local v57
		if v31 then
			local v58 = (p28 - 8) / 2
			local v59 = math.floor(v58)
			v57 = {
				["dark"] = {
					["x"] = 0,
					["y"] = 2,
					["w"] = nil,
					["h"] = nil,
					["w"] = v59,
					["h"] = v55 - 4
				},
				["light"] = {
					["x"] = nil,
					["y"] = 2,
					["w"] = nil,
					["h"] = nil,
					["x"] = v59 + 8,
					["w"] = p28 - v59 - 8,
					["h"] = v55 - 4
				}
			}
		else
			local v60 = (p28 - 84 - 10 - 8) / 2
			local v61 = math.floor(v60)
			v57 = {
				["label"] = {
					["x"] = 10,
					["y"] = 0,
					["w"] = 70,
					["h"] = nil,
					["h"] = v55
				},
				["dark"] = {
					["x"] = 84,
					["y"] = 6,
					["w"] = nil,
					["h"] = nil,
					["w"] = v61,
					["h"] = v55 - 12
				},
				["light"] = {
					["x"] = nil,
					["y"] = 6,
					["w"] = nil,
					["h"] = nil,
					["x"] = v61 + 84 + 8,
					["w"] = p28 - 84 - 10 - v61 - 8,
					["h"] = v55 - 12
				}
			}
		end
		v32.preview = {
			["box"] = v56,
			["parts"] = v57
		}
		local v62 = v32.groups
		table.insert(v62, {
			["name"] = "preview",
			["box"] = nil,
			["parts"] = nil,
			["box"] = v56,
			["parts"] = v57
		})
		v32.fixedH = v52 + v55 + (v31 and 6 or 8)
		v32.headPreviewH = v32.fixedH - (v31 and 6 or 8)
		return v32
	end,
	["card"] = function(p63, p64, p65) -- name: card
		-- upvalues: (copy) v_u_180
		local v66 = v_u_180.PAD
		local v67 = math.max(44, p64 or 44)
		local v68 = p63 - 2 * v66
		local v69 = {}
		local v70 = v_u_180.SWATCH
		local v71 = v66 + v70 + 8
		v69.swatch = {
			["x"] = v66,
			["y"] = v66,
			["w"] = v70,
			["h"] = v70
		}
		local v72 = v_u_180.chipW(p65.rarity or "COMMON")
		local v73 = v68 - v70 - 8 - 60
		local v74 = math.max(40, v73)
		local v75 = math.min(v72, v74)
		v69.pill = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 20,
			["x"] = p63 - v66 - v75,
			["y"] = v66 + 1,
			["w"] = v75
		}
		local v76 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 22,
			["x"] = v71,
			["y"] = v66
		}
		local v77 = p63 - v66 - v75 - 8 - v71
		v76.w = math.max(40, v77)
		v69.name = v76
		local v78 = p63 - v71 - v66
		local v79 = v_u_180.lines
		local v80 = p65.desc or ""
		local v81 = v_u_180.SMALL_W
		local v82 = math.min(2, v79(v80, v78, v81))
		v69.desc = {
			["x"] = v71,
			["y"] = v66 + 24,
			["w"] = v78,
			["h"] = v82 * v_u_180.LINE
		}
		local v83 = v66 + v70
		local v84 = v66 + 24 + v82 * v_u_180.LINE
		local v85 = math.max(v83, v84) + 6
		if p65.bar then
			v69.barText = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 16,
				["x"] = v66,
				["y"] = v85,
				["w"] = v68
			}
			v69.bar = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 8,
				["x"] = v66,
				["y"] = v85 + 18,
				["w"] = v68
			}
			v85 = v85 + 34
		end
		if p65.conseq then
			v69.conseq = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 18,
				["x"] = v66,
				["y"] = v85,
				["w"] = v68
			}
			v85 = v85 + 22
		end
		if p65.note then
			v69.note = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 18,
				["x"] = v66,
				["y"] = v85,
				["w"] = v68
			}
			v85 = v85 + 22
		end
		local v86 = {}
		if p65.stepper then
			local v87 = {
				["key"] = "stepper",
				["w"] = nil,
				["button"] = false,
				["w"] = v67 * 2 + v_u_180.STEPPER_LABEL
			}
			table.insert(v86, v87)
		end
		for v88, v89 in p65.buttons or {} do
			local v90 = {
				["key"] = nil,
				["w"] = nil,
				["button"] = true,
				["key"] = "b" .. v88,
				["w"] = v_u_180.btnW(v89, v67)
			}
			table.insert(v86, v90)
		end
		local v91 = 0
		local v92 = 0
		local v93 = 1
		local v94 = v85
		local v95 = v93
		local v96 = {}
		for v97, v98 in v86 do
			local v99 = v98.w
			local v100 = math.min(v99, v68)
			if v91 > 0 and v68 < v91 + 8 + v100 then
				if v92 == 1 and (v96[v95].button and p63 <= 450) then
					v96[v95].w = v68
				end
				v85 = v85 + (v67 + 8)
				v91 = 0
				v92 = 0
				v93 = v97
				v95 = v93
			end
			v98.x = v91
			v98.y = v85
			v98.w = v100
			v96[v97] = v98
			v92 = v92 + 1
			v91 = v91 + (v100 + 8)
		end
		local v101
		if #v86 > 0 then
			if v92 == 1 and (v96[v95].button and p63 <= 450) then
				v96[v95].w = v68
			end
			for _, v102 in v86 do
				v69[v102.key] = {
					["x"] = v66 + v102.x,
					["y"] = v102.y,
					["w"] = v102.w,
					["h"] = v67
				}
			end
			v101 = v85 + v67 + v66
		else
			v101 = v94 + (v66 - 4)
		end
		return {
			["h"] = v101,
			["parts"] = v69
		}
	end,
	["sheet"] = function(p103, p104, p105, p106, p107) -- name: sheet
		-- upvalues: (copy) v_u_180
		local v108 = p104 == "phone"
		local v109 = math.max(44, p105 or 44)
		local v110 = v_u_180.GAP
		local v111 = {
			["W"] = p103,
			["kind"] = p104,
			["groups"] = {},
			["cards"] = {}
		}
		local v112
		if v108 then
			v111.cats = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p103,
				["h"] = v109
			}
			local v113 = v111.groups
			local v114 = {
				["name"] = "cats",
				["box"] = nil,
				["box"] = v111.cats
			}
			table.insert(v113, v114)
			v112 = v109 + 8
		else
			v112 = 0
		end
		local v115 = v108 and 1 or v_u_180.colsFor(p103)
		v111.cols = v115
		local v116 = (p103 - (v115 - 1) * v110) / v115
		local v117 = math.floor(v116)
		local v118 = 0
		local v119 = v112
		local v120 = 0
		local v121 = {}
		local v122 = v119
		local v123 = v120
		local v124 = v121
		local v125 = v118
		for v126, v127 in p106 do
			if v127.full then
				for _, v128 in v124 do
					v128.box.h = v123
				end
				if #v124 > 0 then
					v112 = v122 + v123 + v110
				end
				v121 = {}
				v120 = 0
				v118 = 0
				v119 = v112
				local v129 = v_u_180.card(p103, v109, v127)
				local v130 = {
					["box"] = nil,
					["parts"] = nil,
					["full"] = true,
					["box"] = {
						["x"] = 0,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["y"] = v112,
						["w"] = p103,
						["h"] = v129.h
					},
					["parts"] = v129.parts
				}
				v111.cards[v126] = v130
				local v131 = v111.groups
				local v132 = {
					["name"] = "card" .. v126,
					["box"] = v130.box,
					["parts"] = v130.parts
				}
				table.insert(v131, v132)
				v112 = v112 + (v129.h + v110)
				v119 = v112
				v122 = v119
				v123 = v120
				v124 = v121
				v125 = v118
			else
				local v133 = v_u_180.card(v117, v109, v127)
				local v134 = {
					["box"] = {
						["x"] = v125 * (v117 + v110),
						["y"] = v122,
						["w"] = v117,
						["h"] = v133.h
					},
					["parts"] = v133.parts
				}
				v111.cards[v126] = v134
				local v135 = v111.groups
				local v136 = {
					["name"] = "card" .. v126,
					["box"] = v134.box,
					["parts"] = v134.parts
				}
				table.insert(v135, v136)
				table.insert(v124, v134)
				local v137 = v133.h
				v120 = math.max(v123, v137)
				v118 = v125 + 1
				if v115 <= v118 then
					local v138 = v120
					for _, v139 in v124 do
						v139.box.h = v138
					end
					if #v124 > 0 then
						v112 = v122 + v138 + v110
					end
					v121 = {}
					v120 = 0
					v118 = 0
					v119 = v112
					v122 = v119
					v123 = v120
					v124 = v121
					v125 = v118
				else
					v123 = v120
					v125 = v118
				end
			end
		end
		for _, v140 in v124 do
			v140.box.h = v123
		end
		if #v124 > 0 then
			v112 = v122 + v123 + v110
		end
		v121 = {}
		v120 = 0
		v118 = 0
		v119 = v112
		local v141 = v_u_180.lines(p107 or "", p103 - 20, v_u_180.SMALL_W)
		local v142 = v141 * v_u_180.LINE + 16
		v111.footer = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v112,
			["w"] = p103,
			["h"] = v142
		}
		v111.footerText = {
			["x"] = 10,
			["y"] = 8,
			["w"] = nil,
			["h"] = nil,
			["w"] = p103 - 20,
			["h"] = v141 * v_u_180.LINE
		}
		local v143 = v111.groups
		local v144 = {
			["name"] = "footer",
			["box"] = nil,
			["parts"] = nil,
			["box"] = v111.footer,
			["parts"] = {
				["text"] = v111.footerText
			}
		}
		table.insert(v143, v144)
		v111.height = v112 + v142
		return v111
	end,
	["boardRow"] = function(p145, p146, p147) -- name: boardRow
		if p147 and p145 < 450 then
			p147 = false
		end
		local v148 = p147 and 96 or 120
		local v149 = 12
		local v150 = {
			["place"] = {
				["x"] = nil,
				["y"] = 0,
				["w"] = 56,
				["h"] = nil,
				["x"] = v149,
				["h"] = p146
			}
		}
		local v151 = v149 + 56
		local v152 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 72,
			["h"] = 22,
			["x"] = v151
		}
		local v153 = (p146 - 22) / 2
		v152.y = math.floor(v153)
		v150.tag = v152
		local v154 = v151 + 82
		local v155 = p145 - 12
		if p147 then
			v150.total = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v155 - v148,
				["w"] = v148,
				["h"] = p146
			}
			v155 = v155 - (v148 + 8)
		end
		v150.weekly = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v155 - v148,
			["w"] = v148,
			["h"] = p146
		}
		local v156 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v154
		}
		local v157 = v155 - (v148 + 8) - v154
		v156.w = math.max(40, v157)
		v156.h = p146
		v150.name = v156
		return v150
	end,
	["audit"] = function(p158, p159) -- name: audit
		local v160 = {}
		for v161, v162 in p158 do
			local v163 = v162.box
			if v163.x < 0 or v163.x + v163.w > p159 + 0.001 then
				local v164 = v162.name .. " leaves the width"
				table.insert(v160, v164)
			end
			if v163.w <= 0 or v163.h <= 0 then
				local v165 = v162.name .. " has no size"
				table.insert(v160, v165)
			end
			for v166 = v161 + 1, #p158 do
				local v167 = p158[v166].box
				local v168
				if v163.x < v167.x + v167.w and (v167.x < v163.x + v163.w and v163.y < v167.y + v167.h) then
					v168 = v167.y < v163.y + v163.h
				else
					v168 = false
				end
				if not v168 then
					continue
				end
				local v169 = v162.name .. " overlaps " .. p158[v166].name
				table.insert(v160, v169)
			end
			local v170 = {}
			for v171 in v162.parts or {} do
				table.insert(v170, v171)
			end
			table.sort(v170)
			for v172, v173 in v170 do
				local v174 = v162.parts[v173]
				if v174.x < 0 or (v174.y < 0 or (v174.x + v174.w > v163.w + 0.001 or v174.y + v174.h > v163.h + 0.001)) then
					local v175 = v162.name .. "." .. v173 .. " leaves its box"
					table.insert(v160, v175)
				end
				for v176 = v172 + 1, #v170 do
					local v177 = v162.parts[v170[v176]]
					local v178
					if v174.x < v177.x + v177.w and (v177.x < v174.x + v174.w and v174.y < v177.y + v177.h) then
						v178 = v177.y < v174.y + v174.h
					else
						v178 = false
					end
					if not v178 then
						continue
					end
					local v179 = v162.name .. "." .. v173 .. " overlaps " .. v170[v176]
					table.insert(v160, v179)
				end
			end
		end
		return v160
	end
}
return v_u_180