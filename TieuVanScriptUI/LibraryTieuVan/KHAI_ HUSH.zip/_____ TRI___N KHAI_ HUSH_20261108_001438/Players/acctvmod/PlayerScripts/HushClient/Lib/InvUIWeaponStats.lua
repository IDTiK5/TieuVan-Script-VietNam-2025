-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIWeaponStats

local v_u_21 = {
	["ORDER"] = {
		"range",
		"head",
		"recoil",
		"spreadHip",
		"spreadAim",
		"reload",
		"draw",
		"handling"
	},
	["LABEL"] = {
		["range"] = "Range",
		["head"] = "Head x",
		["recoil"] = "Recoil",
		["spreadHip"] = "Spread hip",
		["spreadAim"] = "Spread aim",
		["reload"] = "Reload",
		["draw"] = "Draw",
		["handling"] = "Handling"
	},
	["DIR"] = {
		["range"] = "higher",
		["head"] = "higher",
		["recoil"] = "lower",
		["spreadHip"] = "lower",
		["spreadAim"] = "lower",
		["reload"] = "lower",
		["draw"] = "lower",
		["handling"] = "higher"
	},
	["values"] = function(p1) -- name: values
		local v2 = {}
		if type(p1) ~= "table" then
			return v2
		end
		local v3 = p1.range
		local v4
		if type(v3) == "number" and (v3 == v3 and v3 ~= (1 / 0)) then
			v4 = v3 ~= (-1 / 0)
		else
			v4 = false
		end
		if v4 then
			v2.range = p1.range
		end
		local v5 = p1.headMul
		local v6
		if type(v5) == "number" and (v5 == v5 and v5 ~= (1 / 0)) then
			v6 = v5 ~= (-1 / 0)
		else
			v6 = false
		end
		if v6 then
			v2.head = p1.headMul
		end
		local v7 = p1.recoil
		local v8
		if type(v7) == "number" and (v7 == v7 and v7 ~= (1 / 0)) then
			v8 = v7 ~= (-1 / 0)
		else
			v8 = false
		end
		if v8 then
			v2.recoil = p1.recoil
		end
		local v9 = p1.spreadHip
		local v10
		if type(v9) == "number" and (v9 == v9 and v9 ~= (1 / 0)) then
			v10 = v9 ~= (-1 / 0)
		else
			v10 = false
		end
		if v10 then
			v2.spreadHip = p1.spreadHip
		end
		local v11 = p1.spreadAim
		local v12
		if type(v11) == "number" and (v11 == v11 and v11 ~= (1 / 0)) then
			v12 = v11 ~= (-1 / 0)
		else
			v12 = false
		end
		if v12 then
			v2.spreadAim = p1.spreadAim
		end
		local v13
		if type(p1) == "table" and p1.reloadKind == "single" then
			local v14 = p1.reloadPerRound
			if type(v14) == "number" and (v14 == v14 and v14 ~= (1 / 0)) then
				v13 = v14 ~= (-1 / 0)
			else
				v13 = false
			end
		else
			v13 = false
		end
		if v13 then
			v2.reload = p1.reloadPerRound
		else
			local v15 = p1.reloadTime
			local v16
			if type(v15) == "number" and (v15 == v15 and v15 ~= (1 / 0)) then
				v16 = v15 ~= (-1 / 0)
			else
				v16 = false
			end
			if v16 then
				v2.reload = p1.reloadTime
			end
		end
		local v17 = p1.equipTime
		local v18
		if type(v17) == "number" and (v17 == v17 and v17 ~= (1 / 0)) then
			v18 = v17 ~= (-1 / 0)
		else
			v18 = false
		end
		if v18 then
			v2.draw = p1.equipTime
		end
		local v19 = p1.aimSpeedMul
		local v20
		if type(v19) == "number" and (v19 == v19 and v19 ~= (1 / 0)) then
			v20 = v19 ~= (-1 / 0)
		else
			v20 = false
		end
		if v20 then
			v2.handling = p1.aimSpeedMul * 100
		end
		return v2
	end
}
local function v_u_32(p22, p23, p24) -- name: fmt
	if p22 == "range" then
		local v25 = string.format
		local v26 = p23 + 0.5
		return v25("%d m", (math.floor(v26)))
	end
	if p22 == "head" then
		return "x" .. string.format("%.1f", p23)
	end
	if p22 == "recoil" then
		return string.format("%.1f", p23)
	end
	if p22 == "spreadHip" or p22 == "spreadAim" then
		return string.format("%.1f deg", p23)
	end
	if p22 == "reload" then
		local v27 = string.format("%.1f s", p23)
		local v28
		if type(p24) == "table" and p24.reloadKind == "single" then
			local v29 = p24.reloadPerRound
			if type(v29) == "number" and (v29 == v29 and v29 ~= (1 / 0)) then
				v28 = v29 ~= (-1 / 0)
			else
				v28 = false
			end
		else
			v28 = false
		end
		return v27 .. (v28 and " a round" or "")
	end
	if p22 == "draw" then
		return string.format("%.2f s", p23)
	end
	local v30 = string.format
	local v31 = p23 + 0.5
	return v30("%d%%", (math.floor(v31)))
end
function v_u_21.text(p33, p34) -- name: text
	-- upvalues: (copy) v_u_21, (copy) v_u_32
	local v35 = v_u_21.values(p34)[p33]
	if v35 == nil then
		return nil
	end
	local v36 = v_u_32(p33, v35, p34)
	if p33 == "range" and type(p34) == "table" then
		local v37 = p34.falloffStart
		local v38
		if type(v37) == "number" and (v37 == v37 and v37 ~= (1 / 0)) then
			v38 = v37 ~= (-1 / 0)
		else
			v38 = false
		end
		if v38 and p34.falloffStart < v35 then
			local v39 = string.format
			local v40 = p34.falloffStart + 0.5
			v36 = v36 .. v39(" (full to %d)", (math.floor(v40)))
		end
	end
	return v36
end
function v_u_21.statsFor(p41, p42, p43) -- name: statsFor
	if type(p41) ~= "table" then
		return p41
	end
	if type(p43) == "function" then
		local v44 = p41.id
		if type(v44) == "string" and type(p42) == "table" then
			local v45 = p41.id
			local v46, v47 = pcall(p43, v45, p42)
			if v46 and type(v47) == "table" then
				return v47
			end
		end
	end
	return p41
end
function v_u_21.rows(p48) -- name: rows
	-- upvalues: (copy) v_u_21
	local v49 = {}
	for _, v50 in v_u_21.ORDER do
		local v51 = v_u_21.text(v50, p48)
		if not v51 then
			continue
		end
		local v52 = { v_u_21.LABEL[v50], v51 }
		table.insert(v49, v52)
	end
	return v49
end
function v_u_21.compare(p53, p54, p55) -- name: compare
	-- upvalues: (copy) v_u_21, (copy) v_u_32
	local v56 = {}
	if type(p53) ~= "table" or type(p54) ~= "table" then
		return v56
	end
	local v57 = v_u_21.values(p53)
	local v58 = v_u_21.values(p54)
	local v59 = (not p55 or p55 == "") and "equipped" or p55
	for _, v60 in v_u_21.ORDER do
		local v61 = v57[v60]
		local v62 = v58[v60]
		if v61 == nil or v62 == nil then
			continue
		end
		if v60 == "reload" then
			local v63
			if type(p53) == "table" and p53.reloadKind == "single" then
				local v64 = p53.reloadPerRound
				if type(v64) == "number" and (v64 == v64 and v64 ~= (1 / 0)) then
					v63 = v64 ~= (-1 / 0)
				else
					v63 = false
				end
			else
				v63 = false
			end
			local v65
			if type(p54) == "table" and p54.reloadKind == "single" then
				local v66 = p54.reloadPerRound
				if type(v66) == "number" and (v66 == v66 and v66 ~= (1 / 0)) then
					v65 = v66 ~= (-1 / 0)
				else
					v65 = false
				end
			else
				v65 = false
			end
			if v63 ~= v65 then
				continue
			end
		end
		local v67 = v_u_32(v60, v61, p53)
		local v68 = v_u_32(v60, v62, p54)
		if v67 == v68 then
			continue
		end
		local v69
		if v_u_21.DIR[v60] == "higher" then
			v69 = v62 < v61
		else
			v69 = v61 < v62
		end
		local v70 = { "vs " .. v59 .. ": " .. v_u_21.LABEL[v60], v68 .. "  >  " .. v67, v69 }
		table.insert(v56, v70)
	end
	return v56
end
return v_u_21