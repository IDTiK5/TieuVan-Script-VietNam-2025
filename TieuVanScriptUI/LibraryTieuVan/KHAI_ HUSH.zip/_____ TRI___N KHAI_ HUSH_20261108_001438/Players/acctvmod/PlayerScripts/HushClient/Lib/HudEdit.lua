-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HudEdit

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = {}
local v_u_6 = {
	["interact"] = true,
	["throwCancel"] = true,
	["chat"] = true,
	["Squad"] = true,
	["Tasks"] = true,
	["Extracts"] = true,
	["Notices"] = true
}
function v_u_5.frameOf(p7, p8) -- name: frameOf
	local v9 = p8 or {
		["left"] = 0,
		["top"] = 0,
		["right"] = 0,
		["bottom"] = 0
	}
	local v10 = Vector2.new
	local v11 = p7.X - v9.left - v9.right
	local v12 = math.max(2, v11)
	local v13 = p7.Y - v9.top - v9.bottom
	return v10(v12, (math.max(2, v13)))
end
function v_u_5.layout(p14, p15, p16) -- name: layout
	-- upvalues: (copy) v_u_6
	local v17 = p15.TC
	local v18 = p15.HL
	local v19 = p15.S
	local v20 = p15.FC
	local v21 = p16.work or {}
	local v22 = p16.full or p14
	local v23 = v17.isPhoneViewport(p14)
	local v24
	if v23 then
		v24 = p16.phoneHud ~= false
	else
		v24 = v23
	end
	local v25 = v17.scaleFor(p14, p16.touchSize or 2)
	local v26 = v18.hudScale(v22, p16.uiMul or 1)
	local v27 = Vector2.new(p14.X / v25, p14.Y / v25)
	local v28 = p16.fptpControls ~= false
	local v29 = not v20 and "ring" or v20.effective(p16.fireMode, v28)
	local v30 = {}
	for v31, v32 in v21 do
		local v33 = v19.BY_NAME[v31]
		if not v33 or v33.root ~= "pad" then
			continue
		end
		v30[v31] = v32
	end
	local v34 = {
		["stick"] = nil,
		["fixed"] = nil,
		["phone"] = nil,
		["full"] = true,
		["scale"] = nil,
		["fptp"] = nil,
		["stick"] = p16.stick,
		["fixed"] = p16.fixed,
		["phone"] = v24,
		["scale"] = v25,
		["fptp"] = v28
	}
	local v35 = v17.layoutRects(v27, {
		["stick"] = nil,
		["fixed"] = nil,
		["phone"] = nil,
		["full"] = true,
		["scale"] = nil,
		["custom"] = nil,
		["fptp"] = nil,
		["stick"] = p16.stick,
		["fixed"] = p16.fixed,
		["phone"] = v24,
		["scale"] = v25,
		["custom"] = v30,
		["fptp"] = v28
	})
	local v36 = v17.layoutRects(v27, v34)
	local v37 = {}
	local v38 = nil
	if v23 then
		local v39 = {
			["tc"] = nil,
			["touchSize"] = nil,
			["stick"] = nil,
			["fixed"] = nil,
			["uiMul"] = nil,
			["squad"] = 3,
			["tasks"] = true,
			["events"] = 0,
			["cards"] = 2,
			["modTag"] = false,
			["padSize"] = nil,
			["barX"] = nil,
			["tc"] = v17,
			["touchSize"] = p16.touchSize,
			["stick"] = p16.stick,
			["fixed"] = p16.fixed,
			["uiMul"] = p16.uiMul,
			["padSize"] = p14,
			["barX"] = p16.barX
		}
		local v40 = v18.compute(v22, v39)
		v38 = v40.meta.weaponScale
		for _, v41 in {
			"Clock",
			"Weapon",
			"Squad",
			"Noise",
			"Tasks",
			"Notices"
		} do
			if not v40.rects[v41] then
				continue
			end
			local v42 = v40.rects[v41]
			v37[v41] = {
				v42[1] * v26 + 0,
				v42[2] * v26 + 0,
				v42[3] * v26 + 0,
				v42[4] * v26 + 0
			}
		end
		v39.extracts = true
		local v43 = v18.compute(v22, v39)
		if v43.rects.Extracts then
			local v44 = v43.rects.Extracts
			v37.Extracts = {
				v44[1] * v26 + 0,
				v44[2] * v26 + 0,
				v44[3] * v26 + 0,
				v44[4] * v26 + 0
			}
		end
	else
		local v45 = v18.squad({
			["refH"] = p14.Y / v26
		}, 3)
		local v46 = {
			v45.x0,
			v45.y0,
			v45.x1,
			v45.y1
		}
		v37.Squad = {
			v46[1] * v26 + 0,
			v46[2] * v26 + 0,
			v46[3] * v26 + 0,
			v46[4] * v26 + 0
		}
	end
	local v47 = {}
	local v48 = {}
	for _, v49 in v19.ELEMENTS do
		local v50 = v49.name
		local v51 = nil
		local v52 = nil
		local v53 = v21[v50]
		local v54 = "rect"
		if v49.root == "pad" then
			if v50 == "aim" then
				v51 = v35._aimStick
				v52 = v36._aimStick
				v54 = "round"
			elseif v50 == "move" then
				if p16.fixed then
					v51 = v35._moveFixed
				else
					v51 = v35._moveHint
				end
				if p16.fixed then
					v52 = v36._moveFixed
				else
					v52 = v36._moveHint
				end
				v54 = "round"
			elseif v50 == "fire" then
				if v20 and v20.buttonOn(v29) then
					v51 = v35.fire
					v52 = v36.fire
				end
			elseif v50 ~= "ads" and v50 ~= "viewToggle" or p16.fptpControls ~= false then
				v51 = v35[v50]
				v52 = v36[v50]
			end
			if v51 then
				v51 = {
					v51[1] * v25 + 0,
					v51[2] * v25 + 0,
					v51[3] * v25 + 0,
					v51[4] * v25 + 0
				}
				v52 = {
					v52[1] * v25 + 0,
					v52[2] * v25 + 0,
					v52[3] * v25 + 0,
					v52[4] * v25 + 0
				}
			end
		else
			v52 = v37[v50]
			if v52 then
				if v53 then
					local v55 = "TL"
					for _, v56 in v18.BLOCKS do
						if v56.name ~= v50 then
							continue
						end
						v55 = v56.anchor
					end
					local v57
					if v55 == "TR" or v55 == "BR" then
						v57 = v52[3]
					else
						v57 = v52[1]
					end
					local v58
					if v55 == "BL" or v55 == "BR" then
						v58 = v52[4]
					else
						v58 = v52[2]
					end
					local v59, v60 = v18.keep(v50, v53.fx, v53.fy, p14.X / v26, p14.Y / v26, v38)
					local v61 = v59 * p14.X - v57
					local v62 = v60 * p14.Y - v58
					local v63 = v52[3] - v52[1]
					local v64 = v52[4] - v52[2]
					local v65 = v52[1] + v61
					local v66 = p14.X - v63
					local v67 = math.max(0, v66)
					local v68 = math.clamp(v65, 0, v67)
					local v69 = v52[2] + v62
					local v70 = p14.Y - v64
					local v71 = math.max(0, v70)
					local v72 = math.clamp(v69, 0, v71)
					v51 = {
						v68,
						v72,
						v68 + v63,
						v72 + v64
					}
				else
					v51 = v52
				end
			end
		end
		if not (v51 and v52) then
			continue
		end
		local v73
		if v49.tray == nil then
			v73 = false
		else
			v73 = v53 == nil
		end
		local v74 = {
			["name"] = nil,
			["label"] = nil,
			["kind"] = nil,
			["root"] = nil,
			["rect"] = nil,
			["def"] = nil,
			["entry"] = nil,
			["faint"] = nil,
			["shape"] = nil,
			["tray"] = nil,
			["anchor"] = nil,
			["name"] = v50,
			["label"] = v49.label,
			["kind"] = v49.kind,
			["root"] = v49.root,
			["rect"] = v51,
			["def"] = v52,
			["entry"] = v53,
			["faint"] = v_u_6[v50] == true,
			["shape"] = v54,
			["tray"] = v73
		}
		if v49.root == "hud" then
			for _, v75 in v18.BLOCKS do
				if v75.name ~= v50 then
					continue
				end
				v74.anchor = v75.anchor
			end
		end
		table.insert(v48, v74)
		v47[v50] = v74
	end
	local v76 = {
		["items"] = v48,
		["byName"] = v47
	}
	local v77 = v35._tray
	v76.tray = {
		v77[1] * v25 + 0,
		v77[2] * v25 + 0,
		v77[3] * v25 + 0,
		v77[4] * v25 + 0
	}
	v76.ts = v25
	v76.hs = v26
	v76.phone = v23
	v76.vp = p14
	v76.full = v22
	v76.canvas = v27
	v76.weaponScale = v38
	return v76
end
function v_u_5.dragRect(p78, p79, p80, p81, p82) -- name: dragRect
	local v83 = p78[3] - p78[1]
	local v84 = p78[4] - p78[2]
	local v85 = p79.X - p80.X
	local v86 = p79.Y - p80.Y
	if p82 then
		local v87 = v85 / 12 + 0.5
		v85 = math.floor(v87) * 12
		local v88 = v86 / 12 + 0.5
		v86 = math.floor(v88) * 12
	end
	local v89 = p81.X - v83
	local v90 = math.max(0, v89)
	local v91 = math.clamp(v85, 0, v90)
	local v92 = p81.Y - v84
	local v93 = math.max(0, v92)
	local v94 = math.clamp(v86, 0, v93)
	return {
		v91,
		v94,
		v91 + v83,
		v94 + v84
	}
end
function v_u_5.entryFor(p95, p96, p97, p98) -- name: entryFor
	local v99, v100
	if p95.root == "pad" then
		v99 = (p96[1] + p96[3]) / 2 / p97.X
		v100 = (p96[2] + p96[4]) / 2 / p97.Y
	else
		local v101 = p95.anchor or "TL"
		local v102
		if v101 == "TR" or v101 == "BR" then
			v102 = p96[3]
		else
			v102 = p96[1]
		end
		local v103
		if v101 == "BL" or v101 == "BR" then
			v103 = p96[4]
		else
			v103 = p96[2]
		end
		v99 = v102 / p97.X
		v100 = v103 / p97.Y
	end
	local v104 = math.clamp(v99, 0, 1)
	local v105 = math.clamp(v100, 0, 1)
	if not p98 then
		if p95.entry then
			return v104, v105, p95.entry.sz
		end
		p98 = 2
	end
	return v104, v105, p98
end
function v_u_5.entryKept(p106, p107, p108, p109, p110, p111) -- name: entryKept
	-- upvalues: (copy) v_u_5
	local v112, v113, v114 = v_u_5.entryFor(p106, p107, p108, p109)
	if p106.root == "hud" and (p111 and (p111.keep and p110)) then
		local v115 = p110.hs
		if type(v115) == "number" then
			v112, v113 = p111.keep(p106.name, v112, v113, p108.X / p110.hs, p108.Y / p110.hs, p110.weaponScale)
		end
	end
	return v112, v113, v114
end
function v_u_5.keepWork(p116, p117, p118, p119) -- name: keepWork
	-- upvalues: (copy) v_u_5
	local v120 = {}
	local v121
	if p116 then
		local v122 = p116.ts
		v121 = type(v122) ~= "number" and 1 or p116.ts
	else
		v121 = 1
	end
	local v123 = v121 * 2 + 1
	for v124, v125 in p117 do
		local v126
		if p116 then
			v126 = p116.byName[v124]
		else
			v126 = p116
		end
		local v127
		if v126 then
			local v128, v129 = v_u_5.entryFor(v126, v126.rect, p118, v125.sz)
			v127 = p119.clean(v124, v128, v129, v125.sz)
			if v127 then
				local v130 = v127.fx - v125.fx
				if v123 >= math.abs(v130) * p118.X then
					local v131 = v127.fy - v125.fy
					if v123 >= math.abs(v131) * p118.Y then
						v127 = v125
					end
				end
			else
				v127 = v125
			end
		else
			v127 = v125
		end
		v120[v124] = v127
	end
	return v120
end
function v_u_5.overlaps(p132) -- name: overlaps
	local v133 = {}
	for v134 = 1, #p132 do
		local v135 = p132[v134]
		for v136 = v134 + 1, #p132 do
			local v137 = p132[v136]
			if v135.tray and v137.tray then
				continue
			end
			local v138 = v135.rect
			local v139 = v137.rect
			local v140
			if v138[1] < v139[3] - 1 and (v139[1] < v138[3] - 1 and v138[2] < v139[4] - 1) then
				v140 = v139[2] < v138[4] - 1
			else
				v140 = false
			end
			if not v140 then
				continue
			end
			local v141
			if v135.name == "Extracts" and v137.name == "Tasks" then
				v141 = true
			elseif v135.name == "Tasks" then
				v141 = v137.name == "Extracts"
			else
				v141 = false
			end
			local v142 = (v135.name == "Squad" and (v137.name == "move" or v137.name == "aim") or v137.name == "Squad" and (v135.name == "move" or v135.name == "aim")) and true or v141
			if (v135.tray or v137.tray) and true or v142 then
				continue
			end
			local v143 = { v135.name, v137.name }
			table.insert(v133, v143)
		end
	end
	return v133
end
local v_u_144 = nil
local function v_u_149(p145) -- name: pointer
	-- upvalues: (ref) v_u_144, (copy) v_u_4, (copy) v_u_2
	local v146 = v_u_144.root
	local v147 = v_u_144.ptr
	local v148
	if v147 and v147.ioAbs then
		v148 = v147.ioAbs(p145)
	elseif p145 and (p145.UserInputType == Enum.UserInputType.Touch or (p145.UserInputType == Enum.UserInputType.MouseButton1 or p145.UserInputType == Enum.UserInputType.MouseMovement)) then
		v148 = Vector2.new(p145.Position.X, p145.Position.Y)
	else
		v148 = v_u_4:GetMouseLocation() - v_u_2:GetGuiInset()
	end
	return v148 - v146.AbsolutePosition
end
local function v_u_158(p150, p151) -- name: frameNow
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v152 = p150.viewport()
	local v153 = v_u_1.LocalPlayer
	if typeof(v153:GetAttribute("DevViewport")) == "Vector2" then
		return v152, v152
	else
		if p151 and p151.Parent then
			local v154 = p151.AbsoluteSize
			if v154.X >= 64 and (v154.Y >= 64 and (v154.X <= v152.X + 1 and v154.Y <= v152.Y + 1)) then
				return v154, v152
			end
		end
		local v155 = p150.safeInsets
		local v156, v157 = pcall(v155)
		if v156 and type(v157) == "table" then
			return v_u_5.frameOf(v152, v157), v152
		else
			return v152, v152
		end
	end
end
local function v_u_170() -- name: compute
	-- upvalues: (copy) v_u_1, (ref) v_u_144, (copy) v_u_5, (copy) v_u_2
	local v159 = v_u_1.LocalPlayer
	local v160 = v_u_144.deps
	local v161 = v159:GetAttribute("UiScaleMul")
	local v162
	if type(v161) == "number" then
		v162 = math.clamp(v161, 0.8, 1.4)
	else
		v162 = nil
	end
	local v163 = v_u_5.layout
	local v164 = v_u_144.vp
	local v165 = {
		["stick"] = v160.TC.stickLevel(v159:GetAttribute("TouchStickSize")),
		["fixed"] = v159:GetAttribute("TouchMoveFixed") == true,
		["touchSize"] = v159:GetAttribute("TouchSize"),
		["uiMul"] = v162,
		["fireMode"] = v_u_144.fireMode,
		["work"] = v_u_144.work,
		["full"] = v_u_144.full
	}
	local v_u_166 = v160.HL.hudScale(v_u_144.full, v162 or 1)
	local v_u_167 = 0
	local function v169()
		-- upvalues: (ref) v_u_2, (ref) v_u_167, (copy) v_u_166
		local v168 = v_u_2.TopbarInset
		if v168.Width > 0 then
			v_u_167 = v168.Min.X / v_u_166 + 8
		end
	end
	pcall(v169)
	v165.barX = v_u_167
	v165.phoneHud = v_u_144.phoneHud
	v165.fptpControls = v_u_144.fptpControls
	return v163(v164, v160, v165)
end
local function v_u_176(p171) -- name: barSpan
	-- upvalues: (ref) v_u_144
	local v172 = v_u_144.barX
	local v173 = v_u_144.vp.X - 8
	for _, v174 in p171.items do
		if v174.rect[2] >= v_u_144.barH - 6 or v174.rect[1] <= v172 + 120 then
			continue
		end
		local v175 = v174.rect[1] - 8
		v173 = math.min(v173, v175)
	end
	return v172, v173
end
local function v_u_197() -- name: layoutBar
	-- upvalues: (ref) v_u_144, (copy) v_u_176
	local v177, v178 = v_u_176(v_u_144.lay)
	local v179 = v_u_144.barChips
	local v180 = 0
	for _, v181 in v179 do
		v180 = v180 + v181.w
	end
	local v182 = v180 + (#v179 - 1) * 4
	local v183 = (v178 - v177) / v182
	local v184 = math.clamp(v183, 0.78, 1)
	local v185 = v182 * v184
	local v186
	if v178 - v177 < v185 then
		v186 = v177
	else
		v186 = v178 - v185
	end
	local v187 = v_u_144.chipH
	for _, v188 in v179 do
		local v189 = v188.w * v184
		local v190 = math.floor(v189)
		v188.gui.Size = UDim2.fromOffset(v190, v187)
		local v191 = v188.gui
		local v192 = UDim2.fromOffset
		local v193 = math.floor(v186)
		local v194 = (v_u_144.barH - v187) / 2
		v191.Position = v192(v193, (math.floor(v194)))
		local v195 = v188.gui
		local v196 = (v184 * 0.2 + 0.8) * 13
		v195.TextSize = math.floor(v196)
		v186 = v186 + (v190 + v184 * 4)
	end
	v_u_144.title.Visible = v178 - v177 >= v182 + 90
	v_u_144.title.Position = UDim2.fromOffset(v177, 0)
end
function v_u_5.panelX(p198, p199, p200, p201, p202) -- name: panelX
	local v203 = p198.Y - p200 - 6
	local v204 = {}
	for _, v205 in p201 do
		local v206 = v205.rect
		if v205.root ~= p202 or (v203 >= v206[4] or v206[2] >= p198.Y) then
			continue
		end
		local v207 = { v206[1] - 6, v206[3] + 6 }
		table.insert(v204, v207)
	end
	table.sort(v204, function(p208, p209)
		return p208[1] < p209[1]
	end)
	local v210 = 6
	local v211 = -1
	local v212 = 0
	for _, v213 in v204 do
		if v211 < v213[1] - v210 then
			v211 = v213[1] - v210
			v212 = v210
		end
		local v214 = v213[2]
		v210 = math.max(v210, v214)
	end
	local v215 = p198.X - 6 - v210
	if v211 >= v215 then
		v210 = v212
		v215 = v211
	end
	local v216 = (p198.X - p199) / 2
	if p199 > v215 then
		return math.floor(v216)
	end
	local v217 = v210 + v215 - p199
	local v218 = math.clamp(v216, v210, v217)
	return math.floor(v218)
end
local function v_u_236() -- name: paintBar
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_197
	local v219 = v_u_144.lay
	if v219 then
		local v220 = v_u_144.T
		local v221 = v_u_5.overlaps(v219.items)
		v_u_144.overlapNames = {}
		for _, v222 in v221 do
			v_u_144.overlapNames[v222[1]] = true
			v_u_144.overlapNames[v222[2]] = true
		end
		local v223 = v_u_144.selected
		if v223 then
			v223 = v219.byName[v_u_144.selected]
		end
		if v223 and v223.root ~= v_u_144.layer then
			v_u_144.selected = nil
			v223 = nil
		end
		v_u_144.panel.Visible = v_u_144.drag == nil
		if v223 then
			v_u_144.panelLabel.Text = v223.label .. (v223.entry and " (moved)" or "")
			v_u_144.panelLabel.TextColor3 = v220.color.accent
			local v224
			if v223 == nil or v223.kind == "block" then
				v224 = false
			else
				v224 = not v223.tray
			end
			local v225 = not v223.entry and 2 or v223.entry.sz
			for v226, v227 in v_u_144.sizeChips do
				v227.Visible = v224
				local v228
				if v224 then
					v228 = v225 == v226
				else
					v228 = v224
				end
				local v229
				if v228 then
					v229 = v220.color.accent
				else
					v229 = v220.color.raised
				end
				v227.BackgroundColor3 = v229
				local v230
				if v228 then
					v230 = v220.color.ink
				else
					v230 = v220.color.text
				end
				v227.TextColor3 = v230
			end
			v_u_144.resetOne.Visible = v223.entry ~= nil
		else
			for _, v231 in v_u_144.sizeChips do
				v231.Visible = false
			end
			v_u_144.resetOne.Visible = false
			if #v221 > 0 then
				v_u_144.panelLabel.Text = "Some items overlap"
				v_u_144.panelLabel.TextColor3 = v220.color.danger
			elseif v_u_5.isRaidPlace(v_u_144.place) then
				v_u_144.panelLabel.Text = v_u_5.TEXT.raid
				v_u_144.panelLabel.TextColor3 = v220.color.accent
			else
				v_u_144.panelLabel.Text = "Drag an item. Tap it to resize."
				v_u_144.panelLabel.TextColor3 = v220.color.text2
			end
		end
		v_u_144.snapChip.Text = v_u_144.snap and "SNAP ON" or "SNAP OFF"
		local v232 = v_u_144.snapChip
		local v233
		if v_u_144.snap then
			v233 = v220.color.accent
		else
			v233 = v220.color.text2
		end
		v232.TextColor3 = v233
		local v234 = v_u_144.fireMode
		v_u_144.fireChip.Text = "FIRE: " .. (v234 == "both" and "BOTH" or (v234 == "button" and "BUTTON" or (v234 == "ring" and "RING" or "AUTO")))
		v_u_144.layerChip.Text = v_u_144.layer == "pad" and "EDIT: BUTTONS" or "EDIT: INFO"
		v_u_144.layerChip.TextColor3 = v220.color.accent
		v_u_197()
		local v235 = v_u_144.panel
		v235.Position = UDim2.new(0, v_u_5.panelX(v_u_144.vp, v235.Size.X.Offset, v235.Size.Y.Offset, v219.items, v_u_144.layer), 1, -6)
	end
end
local function v_u_302() -- name: paintItems
	-- upvalues: (ref) v_u_144, (copy) v_u_5
	local v237 = v_u_144.lay
	local v238 = v_u_144.T
	local v239 = {}
	local v240 = v237.tray
	local v241 = v_u_144.trayFrame
	v241.Position = UDim2.fromOffset(v240[1], v240[2])
	v241.Size = UDim2.fromOffset(v240[3] - v240[1], v240[4] - v240[2])
	local v242
	if v_u_144.drag then
		v242 = v_u_144.deps.S.BY_NAME[v_u_144.drag.name]
	else
		v242 = nil
	end
	local v243
	if v242 and v242.tray ~= nil then
		v243 = v238.color.accentDeep
	else
		v243 = v238.color.bg
	end
	v241.BackgroundColor3 = v243
	v241.BackgroundTransparency = v_u_144.layer == "pad" and 0.3 or 0.75
	v241:FindFirstChild("Cap").TextTransparency = v_u_144.layer == "pad" and 0 or 0.7
	for _, v244 in v237.items do
		v239[v244.name] = true
		local v245 = v_u_144.proxies[v244.name]
		if not v245 then
			local v246 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BorderSizePixel"] = 0,
				["Active"] = true,
				["Name"] = "P_" .. v244.name
			}
			local v247 = v_u_144.root
			local v248 = Instance.new("TextButton")
			for v249, v250 in v246 do
				v248[v249] = v250
			end
			if v247 then
				v248.Parent = v247
			end
			local v251 = {}
			local v252
			if v244.shape == "round" then
				v252 = UDim.new(0.5, 0)
			else
				v252 = UDim.new(0, 3)
			end
			v251.CornerRadius = v252
			local v253 = Instance.new("UICorner")
			v245 = v248
			for v254, v255 in v251 do
				v253[v254] = v255
			end
			if v248 then
				v253.Parent = v248
			end
			local v256 = {
				["Name"] = "S",
				["ApplyStrokeMode"] = nil,
				["Thickness"] = 1.5,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
			}
			local v257 = Instance.new("UIStroke")
			for v258, v259 in v256 do
				v257[v258] = v259
			end
			if v248 then
				v257.Parent = v248
			end
			local v260 = {
				["Name"] = "L",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["Active"] = false,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v238.font.heading,
				["TextColor3"] = v238.color.text,
				["TextTruncate"] = Enum.TextTruncate.AtEnd
			}
			local v261 = Instance.new("TextLabel")
			for v262, v263 in v260 do
				v261[v262] = v263
			end
			if v248 then
				v261.Parent = v248
			end
			local v_u_264 = v244.name
			v248.InputBegan:Connect(function(p265)
				-- upvalues: (ref) v_u_144, (ref) v_u_5, (copy) v_u_264
				if v_u_144 and (p265.UserInputType == Enum.UserInputType.Touch or p265.UserInputType == Enum.UserInputType.MouseButton1) then
					v_u_5._begin(v_u_264, p265)
				end
			end)
			v_u_144.proxies[v244.name] = v245
		end
		local v266 = v244.rect
		local v267 = v244.root == v_u_144.layer
		local v268 = (v266[1] + v266[3]) / 2
		local v269 = (v266[2] + v266[4]) / 2
		local v270 = v266[3] - v266[1]
		local v271 = math.max(v270, 28)
		local v272 = v266[4] - v266[2]
		local v273 = math.max(v272, 28)
		local v274 = v268 - v271 / 2 + 0.5
		local v275 = math.floor(v274)
		local v276 = v_u_144.vp.X - v271
		local v277 = math.floor(v276)
		local v278 = math.max(0, v277)
		local v279 = math.clamp(v275, 0, v278)
		local v280 = v269 - v273 / 2 + 0.5
		local v281 = math.floor(v280)
		local v282 = v_u_144.vp.Y - v273
		local v283 = math.floor(v282)
		local v284 = math.max(0, v283)
		local v285 = math.clamp(v281, 0, v284)
		v245.Position = UDim2.fromOffset(v279, v285)
		local v286 = UDim2.fromOffset
		local v287 = v271 + 0.5
		local v288 = math.floor(v287)
		local v289 = v273 + 0.5
		v245.Size = v286(v288, (math.floor(v289)))
		local v290 = v_u_144.selected == v244.name
		local v291 = v_u_144.overlapNames
		if v291 then
			v291 = v_u_144.overlapNames[v244.name] == true
		end
		local v292
		if v244.root == "hud" then
			v292 = v238.color.accentDeep
		elseif v244.shape == "round" then
			v292 = v238.color.raised2
		else
			v292 = v238.color.raised
		end
		v245.BackgroundColor3 = v292
		v245.BackgroundTransparency = v267 and (v244.faint and 0.5 or 0.2) or 0.82
		v245.Interactable = v267
		local v293 = v245:FindFirstChild("S")
		local v294
		if v291 and v267 then
			v294 = v238.color.danger
		elseif v290 then
			v294 = v238.color.accent
		elseif v244.root == "hud" then
			v294 = v238.color.accent
		else
			v294 = v238.color.lineStrong
		end
		v293.Color = v294
		v293.Thickness = v290 and 3 or 1.5
		v293.Transparency = v267 and (v244.faint and not v290 and 0.35 or 0) or 0.7
		local v295 = v245:FindFirstChild("L")
		v295.Text = v244.label
		local v296 = math.min(v271, v273) * 0.3
		local v297 = math.floor(v296)
		v295.TextSize = math.clamp(v297, 10, 14)
		v295.TextTransparency = v267 and (v244.faint and not v290 and 0.3 or 0) or 0.7
		local v298
		if v290 then
			v298 = v238.color.accent
		else
			v298 = v238.color.text
		end
		v295.TextColor3 = v298
		local v299 = v267 and (v290 and 8 or ((v244.name == "Extracts" or v244.name == "Notices") and 3 or (v244.root == "hud" and 4 or (v244.shape == "round" and 3 or 5)))) or 2
		v245.ZIndex = v299
		v295.ZIndex = v299
		v245.Visible = true
	end
	for v300, v301 in v_u_144.proxies do
		if v239[v300] then
			continue
		end
		v301.Visible = false
	end
end
function v_u_5._select(p303) -- name: _select
	-- upvalues: (ref) v_u_144, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if v_u_144 then
		v_u_144.selected = p303
		if v_u_144 then
			v_u_144.lay = v_u_170()
			v_u_236()
			v_u_302()
		end
	else
		return
	end
end
function v_u_5._layer(p304) -- name: _layer
	-- upvalues: (ref) v_u_144, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if v_u_144 then
		local v305 = p304 == "hud" and "hud" or "pad"
		if v305 ~= v_u_144.layer then
			v_u_144.layer = v305
			v_u_144.selected = nil
			if not v_u_144 then
				return
			end
			v_u_144.lay = v_u_170()
			v_u_236()
			v_u_302()
		end
	end
end
function v_u_5._begin(p306, p307, p308) -- name: _begin
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_149, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if v_u_144 and not v_u_144.drag then
		local v309 = v_u_144.lay.byName[p306]
		if v309 then
			if v309.root ~= v_u_144.layer then
				v_u_5._layer(v309.root)
				v309 = v_u_144.lay.byName[p306]
			end
			local v310 = p308 or v_u_149(p307)
			v_u_144.selected = p306
			v_u_144.drag = {
				["name"] = nil,
				["io"] = nil,
				["grab"] = nil,
				["start"] = nil,
				["moved"] = false,
				["w"] = nil,
				["h"] = nil,
				["name"] = p306,
				["io"] = p307,
				["grab"] = v310 - Vector2.new(v309.rect[1], v309.rect[2]),
				["start"] = v310,
				["w"] = v309.rect[3] - v309.rect[1],
				["h"] = v309.rect[4] - v309.rect[2]
			}
			if v_u_144 then
				v_u_144.lay = v_u_170()
				v_u_236()
				v_u_302()
			end
		else
			return
		end
	else
		return
	end
end
function v_u_5._move(p311) -- name: _move
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_170, (copy) v_u_302
	local v312 = v_u_144
	if v312 then
		v312 = v_u_144.drag
	end
	if v312 then
		if v312.moved or (p311 - v312.start).Magnitude >= 4 then
			v312.moved = true
			local v313 = v_u_144.lay.byName[v312.name]
			if v313 then
				local v314 = v_u_5.dragRect(v313.rect, p311, v312.grab, v_u_144.vp, v_u_144.snap)
				local v315, v316, v317 = v_u_5.entryKept(v313, v314, v_u_144.vp, not v313.entry and 2 or v313.entry.sz, v_u_144.lay, v_u_144.deps.HL)
				local v318 = v_u_144.deps.S.clean(v312.name, v315, v316, v317)
				if v318 then
					v_u_144.work[v312.name] = v318
				end
				v312.lastPoint = p311
				v_u_144.lay = v_u_170()
				v_u_302()
			end
		else
			return
		end
	else
		return
	end
end
function v_u_5._finish() -- name: _finish
	-- upvalues: (ref) v_u_144, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	local v319 = v_u_144
	if v319 then
		v319 = v_u_144.drag
	end
	if v319 then
		v_u_144.drag = nil
		if v319.moved then
			local v320 = v_u_144.lay.byName[v319.name]
			local v321 = v_u_144.work[v319.name]
			if v320 and v321 then
				local v322 = v_u_144.deps.S.BY_NAME[v319.name]
				local v323 = (v320.rect[1] + v320.rect[3]) / 2
				local v324 = (v320.rect[2] + v320.rect[4]) / 2
				local v325 = v_u_144.lay.tray
				if v322.tray and (v325[1] <= v323 and (v323 <= v325[3] and (v325[2] <= v324 and v324 <= v325[4]))) then
					v_u_144.work[v319.name] = nil
				else
					local v326 = v320.def[1] - v320.rect[1]
					local v327 = v320.def[2] - v320.rect[2]
					if math.abs(v326) < 1.5 and (math.abs(v327) < 1.5 and v321.sz == 2) then
						v_u_144.work[v319.name] = nil
					end
				end
			end
		end
		if v_u_144 then
			v_u_144.lay = v_u_170()
			v_u_236()
			v_u_302()
		end
	else
		return
	end
end
function v_u_5._setSize(p328, p329) -- name: _setSize
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if not v_u_144 then
		return
	end
	local v330 = v_u_144.lay.byName[p328]
	if v330 then
		local v331
		if v330 == nil or v330.kind == "block" then
			v331 = false
		else
			v331 = not v330.tray
		end
		if v331 then
			local v332, v333 = v_u_5.entryFor(v330, v330.rect, v_u_144.vp, 2)
			local v334 = v_u_144.deps.S.clean(p328, v332, v333, p329)
			if v334 then
				if v330.def and v334.sz == 2 then
					local v335 = v330.def[1] - v330.rect[1]
					if math.abs(v335) < 1.5 then
						local v336 = v330.def[2] - v330.rect[2]
						if math.abs(v336) < 1.5 then
							v_u_144.work[p328] = nil
							if v_u_144 then
								v_u_144.lay = v_u_170()
								v_u_236()
								v_u_302()
							end
						end
						v_u_144.work[p328] = v334
					else
						v_u_144.work[p328] = v334
					end
				else
					v_u_144.work[p328] = v334
				end
				if v_u_144 then
					v_u_144.lay = v_u_170()
					v_u_236()
					v_u_302()
				end
			elseif v_u_144 then
				v_u_144.lay = v_u_170()
				v_u_236()
				v_u_302()
			end
		else
			return
		end
	else
		return
	end
end
function v_u_5._reset(p337) -- name: _reset
	-- upvalues: (ref) v_u_144, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if v_u_144 then
		if p337 == "all" then
			table.clear(v_u_144.work)
		else
			v_u_144.work[p337] = nil
		end
		if v_u_144 then
			v_u_144.lay = v_u_170()
			v_u_236()
			v_u_302()
		end
	else
		return
	end
end
function v_u_5._setFire(p338) -- name: _setFire
	-- upvalues: (ref) v_u_144, (copy) v_u_1, (copy) v_u_170, (copy) v_u_236, (copy) v_u_302
	if v_u_144 then
		local v339 = v_u_144.deps.FC.choice(p338)
		v_u_144.fireMode = v339
		v_u_1.LocalPlayer:SetAttribute("TouchFireMode", v339)
		if v_u_144 then
			v_u_144.lay = v_u_170()
			v_u_236()
			v_u_302()
		end
	else
		return
	end
end
local function v_u_345(p_u_340) -- name: restoreWorld
	local v_u_341 = p_u_340.cctx
	pcall(function()
		-- upvalues: (copy) v_u_341
		local v342 = v_u_341.controllers.Input
		local v343 = v342 and v342.touch
		if v343 then
			v343 = v342.touch()
		end
		if v343 and v343.hold then
			v343:hold("hudedit", false)
		end
	end)
	pcall(function()
		-- upvalues: (copy) v_u_341, (copy) p_u_340
		local v344 = v_u_341.controllers.HUD
		if v344 and (v344.setVisible and p_u_340.prevHudVisible ~= nil) then
			v344.setVisible(p_u_340.prevHudVisible)
		end
	end)
end
function v_u_5.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_144
	return v_u_144 ~= nil
end
v_u_5.TEXT = {
	["raid"] = "Raid is running. Finish quickly.",
	["closedChanged"] = "HUD editor closed. Your changes were not saved.",
	["closedPlain"] = "HUD editor closed.",
	["cancelAsk"] = "Tap CANCEL again to drop your changes."
}
function v_u_5.isRaidPlace(p346) -- name: isRaidPlace
	local v347
	if type(p346) == "string" and (p346 ~= "" and (p346 ~= "Menu" and p346 ~= "Hideout")) then
		v347 = p346 ~= "Transit"
	else
		v347 = false
	end
	return v347
end
function v_u_5.closedText(p348) -- name: closedText
	-- upvalues: (copy) v_u_5
	if p348 then
		return v_u_5.TEXT.closedChanged
	else
		return v_u_5.TEXT.closedPlain
	end
end
function v_u_5.cancelStep(p349, p350, p351) -- name: cancelStep
	if p349 and p351 >= p350 then
		return false, p351 + 4
	else
		return true, 0
	end
end
function v_u_5.close(p352, p353) -- name: close
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_1, (copy) v_u_345
	local v_u_354 = v_u_144
	if v_u_354 then
		local v_u_355
		if p353 == true and p352 ~= true then
			local v356 = v_u_5.closedText
			local v357, v358 = pcall(function()
				-- upvalues: (copy) v_u_354
				return v_u_354.deps.S.encode(v_u_354.work) ~= v_u_354.baseText and true or v_u_354.fireMode ~= v_u_354.baseFire
			end)
			if v357 then
				v357 = v358 == true
			end
			v_u_355 = v356(v357)
		else
			v_u_355 = nil
		end
		if v_u_354.drag then
			v_u_354.drag = nil
		end
		local v_u_359 = {}
		local v_u_360 = v_u_354.deps.S
		if p352 == true then
			local v361 = v_u_354.cls
			local function v362()
				-- upvalues: (copy) v_u_354, (ref) v_u_5, (copy) v_u_360
				if v_u_354.lay then
					v_u_354.work = v_u_5.keepWork(v_u_354.lay, v_u_354.work, v_u_354.vp, v_u_360)
				end
			end
			pcall(v362)
			local v363 = v_u_360.encode(v_u_354.work)
			v_u_360.load(v361, v363)
			if v363 ~= v_u_354.baseText then
				v_u_359[v_u_360.KEY[v361]] = v363
			end
			if v_u_354.fireMode ~= v_u_354.baseFire then
				v_u_359.touchFire = v_u_354.fireMode
			end
			if next(v_u_359) ~= nil then
				pcall(function()
					-- upvalues: (copy) v_u_354, (copy) v_u_359
					local v364 = {
						["op"] = "setting",
						["settings"] = nil,
						["settings"] = v_u_359
					}
					v_u_354.cctx.net.fire("menu.op", v364)
				end)
			end
		else
			v_u_1.LocalPlayer:SetAttribute("TouchFireMode", v_u_354.baseFire)
		end
		v_u_144 = nil
		for _, v_u_365 in v_u_354.conns do
			pcall(function()
				-- upvalues: (copy) v_u_365
				v_u_365:Disconnect()
			end)
		end
		if v_u_354.gui then
			v_u_354.gui:Destroy()
		end
		v_u_345(v_u_354)
		v_u_1.LocalPlayer:SetAttribute("HudEditOpen", nil)
		if p352 == true and v_u_354.afterSave then
			local v366 = v_u_354.afterSave
			pcall(v366, v_u_359)
		end
		if v_u_355 then
			pcall(function()
				-- upvalues: (copy) v_u_354, (ref) v_u_355
				v_u_354.cctx.lib.HushUI.toast(v_u_355, "warn")
			end)
		end
	end
end
local function v_u_385(p367, p368, p369, p370, p371, p372) -- name: chip
	local v373 = {
		["Text"] = nil,
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = 13,
		["Size"] = nil,
		["Text"] = p369,
		["BackgroundColor3"] = p368.color.raised,
		["FontFace"] = p368.font.heading,
		["TextColor3"] = p368.color.text,
		["Size"] = UDim2.fromOffset(p370, p371)
	}
	local v374 = Instance.new("TextButton")
	for v375, v376 in v373 do
		v374[v375] = v376
	end
	if p367 then
		v374.Parent = p367
	end
	local v377 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v378 = Instance.new("UICorner")
	for v379, v380 in v377 do
		v378[v379] = v380
	end
	if v374 then
		v378.Parent = v374
	end
	local v381 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = p368.color.lineStrong
	}
	local v382 = Instance.new("UIStroke")
	for v383, v384 in v381 do
		v382[v383] = v384
	end
	if v374 then
		v382.Parent = v374
	end
	v374.Activated:Connect(p372)
	return v374
end
function v_u_5.open(p_u_386, p387) -- name: open
	-- upvalues: (ref) v_u_144, (copy) v_u_1, (copy) v_u_5, (copy) v_u_2, (copy) v_u_385, (copy) v_u_236, (copy) v_u_4, (copy) v_u_149, (copy) v_u_3, (copy) v_u_158, (copy) v_u_170, (copy) v_u_302
	if v_u_144 then
		return true
	end
	local v_u_388 = v_u_1.LocalPlayer
	local v_u_389 = p_u_386.lib
	local v_u_390 = {
		["TC"] = v_u_389.TouchControls,
		["HL"] = v_u_389.HudLayout,
		["S"] = v_u_389.HudLayoutStore,
		["FC"] = v_u_389.FireControl
	}
	if not (v_u_390.TC and (v_u_390.HL and (v_u_390.S and v_u_390.FC))) then
		return false
	end
	local v_u_391 = "TouchLayoutEdit"
	local v392, v393 = pcall(function()
		-- upvalues: (copy) p_u_386, (copy) v_u_391
		return p_u_386.config.flag(v_u_391)
	end)
	if v392 and v393 == false then
		return false
	end
	local v_u_394 = p_u_386.shared.Theme
	local v395 = v_u_394.viewport()
	local v396 = v_u_1.LocalPlayer
	local v_u_397
	if typeof(v396:GetAttribute("DevViewport")) == "Vector2" then
		v_u_397 = v395
	else
		local v398 = v_u_394.safeInsets
		local v399, v400 = pcall(v398)
		if v399 and type(v400) == "table" then
			v_u_397 = v_u_5.frameOf(v395, v400)
		else
			v_u_397 = v395
		end
	end
	local v401 = v_u_390.S.classFor(v_u_397)
	v_u_390.S.setClass(v401)
	v_u_390.S.attach(v_u_390.HL)
	local v402 = v_u_388:WaitForChild("PlayerGui")
	local v403 = v402:FindFirstChild("HushHudEdit")
	if v403 then
		v403:Destroy()
	end
	local v404 = {
		["Name"] = "HushHudEdit",
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = true,
		["DisplayOrder"] = nil,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = (v_u_394.layer.modal or 50) + 5,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v405 = Instance.new("ScreenGui")
	for v406, v407 in v404 do
		v405[v406] = v407
	end
	v405.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	local v408 = v_u_388:GetAttribute("DevViewport")
	local v409 = {
		["Name"] = "Root",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["BorderSizePixel"] = 0,
		["Active"] = true,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_394.color.bgDeep
	}
	local v410
	if typeof(v408) == "Vector2" then
		v410 = UDim2.fromOffset(v_u_397.X, v_u_397.Y)
	else
		v410 = UDim2.fromScale(1, 1)
	end
	v409.Size = v410
	local v411 = Instance.new("Frame")
	for v412, v413 in v409 do
		v411[v412] = v413
	end
	if v405 then
		v411.Parent = v405
	end
	local v414 = v_u_390.S.textOf(v401)
	local v415 = v_u_390.FC.choice(v_u_388:GetAttribute("TouchFireMode"))
	local v_u_416 = "FireOptions"
	local v417, v418 = pcall(function()
		-- upvalues: (copy) p_u_386, (copy) v_u_416
		return p_u_386.config.flag(v_u_416)
	end)
	local v419 = (v417 and v418 == false and true or false) and "ring" or v415
	local v420, v421 = pcall(function()
		-- upvalues: (copy) v_u_389
		return v_u_389.UiPointer
	end)
	local v_u_422 = true
	local function v423()
		-- upvalues: (ref) v_u_422, (copy) v_u_389, (copy) p_u_386
		v_u_422 = v_u_389.PlayModeSel.liveShown(p_u_386) == true
	end
	pcall(v423)
	local v424 = v_u_397.Y / 390
	local v425 = math.clamp(v424, 1, 1.5)
	local v_u_426 = 8
	local function v429()
		-- upvalues: (ref) v_u_2, (copy) v_u_397, (ref) v_u_426
		local v427 = v_u_2.TopbarInset
		if v427.Width > 0 and v427.Min.X < v_u_397.X / 2 then
			local v428 = v427.Min.X
			v_u_426 = math.floor(v428) + 8
		end
	end
	pcall(v429)
	local v430 = {
		["cctx"] = nil,
		["deps"] = nil,
		["T"] = nil,
		["gui"] = nil,
		["root"] = nil,
		["vp"] = nil,
		["full"] = nil,
		["ptr"] = nil,
		["phoneHud"] = nil,
		["fptpControls"] = nil,
		["cls"] = nil,
		["work"] = nil,
		["baseText"] = nil,
		["baseFire"] = nil,
		["fireMode"] = nil,
		["snap"] = true,
		["layer"] = "pad",
		["selected"] = nil,
		["drag"] = nil,
		["proxies"] = nil,
		["conns"] = nil,
		["afterSave"] = nil,
		["place"] = nil,
		["barX"] = nil,
		["barH"] = nil,
		["chipH"] = nil,
		["cctx"] = p_u_386,
		["deps"] = v_u_390,
		["T"] = v_u_394,
		["gui"] = v405,
		["root"] = v411,
		["vp"] = v_u_397,
		["full"] = v395
	}
	if not v420 or type(v421) ~= "table" then
		v421 = nil
	end
	v430.ptr = v421
	local v_u_431 = "PhoneHud"
	local v432, v433 = pcall(function()
		-- upvalues: (copy) p_u_386, (copy) v_u_431
		return p_u_386.config.flag(v_u_431)
	end)
	v430.phoneHud = not v432 or v433 ~= false
	v430.fptpControls = v_u_422
	v430.cls = v401
	v430.work = v_u_390.S.map(v401)
	v430.baseText = v414
	v430.baseFire = v419
	v430.fireMode = v419
	v430.proxies = {}
	v430.conns = {}
	if p387 then
		p387 = p387.afterSave
	end
	v430.afterSave = p387
	v430.place = v_u_388:GetAttribute("Place")
	v430.barX = v_u_426
	local v434 = v425 * 40
	local v435 = math.floor(v434) + 6
	v430.barH = math.max(50, v435)
	local v436 = v425 * 40
	local v437 = math.floor(v436)
	v430.chipH = math.max(44, v437)
	v_u_144 = v430
	pcall(function()
		-- upvalues: (copy) p_u_386
		local v438 = p_u_386.controllers.Input
		local v439 = v438 and v438.touch
		if v439 then
			v439 = v438.touch()
		end
		if v439 and v439.hold then
			v439:hold("hudedit", true)
		end
	end)
	local function v441()
		-- upvalues: (copy) p_u_386, (ref) v_u_144
		local v440 = p_u_386.controllers.HUD
		if v440 and v440.setVisible then
			v_u_144.prevHudVisible = not v440.isVisible and true or v440.isVisible()
			v440.setVisible(false)
		end
	end
	pcall(v441)
	local v442 = v_u_144
	local v443 = {
		["Name"] = "Tray",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 1,
		["Active"] = false,
		["BackgroundColor3"] = v_u_394.color.bg
	}
	local v444 = Instance.new("Frame")
	for v445, v446 in v443 do
		v444[v445] = v446
	end
	if v411 then
		v444.Parent = v411
	end
	v442.trayFrame = v444
	local v447 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_394.color.line
	}
	local v448 = v_u_144.trayFrame
	local v449 = Instance.new("UIStroke")
	for v450, v451 in v447 do
		v449[v450] = v451
	end
	if v448 then
		v449.Parent = v448
	end
	local v452 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v453 = v_u_144.trayFrame
	local v454 = Instance.new("UICorner")
	for v455, v456 in v452 do
		v454[v455] = v456
	end
	if v453 then
		v454.Parent = v453
	end
	local v457 = {
		["Name"] = "Cap",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 10,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Text"] = "MORE TRAY: drag a button out of it to pin it",
		["ZIndex"] = 1,
		["Position"] = UDim2.new(0, 4, 1, 2),
		["Size"] = UDim2.fromOffset(200, 12),
		["FontFace"] = v_u_394.font.heading,
		["TextColor3"] = v_u_394.color.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Left
	}
	local v458 = v_u_144.trayFrame
	local v459 = Instance.new("TextLabel")
	for v460, v461 in v457 do
		v459[v460] = v461
	end
	if v458 then
		v459.Parent = v458
	end
	local v462 = {
		["Name"] = "Bar",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 20,
		["Active"] = false,
		["Size"] = UDim2.new(1, 0, 0, v_u_144.barH)
	}
	local v463 = Instance.new("Frame")
	for v464, v465 in v462 do
		v463[v464] = v465
	end
	if v411 then
		v463.Parent = v411
	end
	v_u_144.bar = v463
	local v466 = v_u_144
	local v467 = {
		["Name"] = "Title",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Text"] = "EDIT HUD",
		["ZIndex"] = 21,
		["Size"] = UDim2.fromOffset(84, v_u_144.barH),
		["FontFace"] = v_u_394.font.headingBold,
		["TextColor3"] = v_u_394.color.accent,
		["TextXAlignment"] = Enum.TextXAlignment.Left
	}
	local v468 = Instance.new("TextLabel")
	for v469, v470 in v467 do
		v468[v469] = v470
	end
	if v463 then
		v468.Parent = v463
	end
	v466.title = v468
	v_u_144.barChips = {}
	local function v471()
		-- upvalues: (ref) v_u_5
		v_u_5._reset("all")
	end
	local v472 = v_u_385(v463, v_u_394, "RESET ALL", 80, v_u_144.chipH, v471)
	v472.ZIndex = 22
	local v473 = v_u_144.barChips
	table.insert(v473, {
		["gui"] = nil,
		["w"] = 80,
		["gui"] = v472
	})
	local v474 = v_u_144
	local function v475()
		-- upvalues: (ref) v_u_5, (ref) v_u_144
		v_u_5._layer(v_u_144.layer == "pad" and "hud" or "pad")
	end
	local v476 = v_u_385(v463, v_u_394, "EDIT: BUTTONS", 104, v_u_144.chipH, v475)
	v476.ZIndex = 22
	local v477 = v_u_144.barChips
	table.insert(v477, {
		["gui"] = nil,
		["w"] = 104,
		["gui"] = v476
	})
	v474.layerChip = v476
	local v478 = v_u_144
	local function v481()
		-- upvalues: (copy) v_u_390, (ref) v_u_144, (ref) v_u_5
		local v479 = v_u_390.FC.CHOICES
		local v480 = table.find(v479, v_u_144.fireMode) or 1
		v_u_5._setFire(v479[v480 % #v479 + 1])
	end
	local v482 = v_u_385(v463, v_u_394, "FIRE: AUTO", 86, v_u_144.chipH, v481)
	v482.ZIndex = 22
	local v483 = v_u_144.barChips
	table.insert(v483, {
		["gui"] = nil,
		["w"] = 86,
		["gui"] = v482
	})
	v478.fireChip = v482
	local v_u_484 = "FireOptions"
	local v485, v486 = pcall(function()
		-- upvalues: (copy) p_u_386, (copy) v_u_484
		return p_u_386.config.flag(v_u_484)
	end)
	if v485 and v486 == false then
		v_u_144.fireChip.Visible = false
		for _, v487 in v_u_144.barChips do
			if v487.gui ~= v_u_144.fireChip then
				continue
			end
			v487.w = 0
		end
	end
	local v488 = v_u_144
	local function v489()
		-- upvalues: (ref) v_u_144, (ref) v_u_236
		v_u_144.snap = not v_u_144.snap
		v_u_236()
	end
	local v490 = v_u_385(v463, v_u_394, "SNAP ON", 66, v_u_144.chipH, v489)
	v490.ZIndex = 22
	local v491 = v_u_144.barChips
	table.insert(v491, {
		["gui"] = nil,
		["w"] = 66,
		["gui"] = v490
	})
	v488.snapChip = v490
	local v492 = v_u_144
	local function v501()
		-- upvalues: (ref) v_u_5, (ref) v_u_144
		local v493 = os.clock()
		local v494 = v_u_5.cancelStep
		local v_u_495 = v_u_144
		local v496, v497 = pcall(function()
			-- upvalues: (copy) v_u_495
			return v_u_495.deps.S.encode(v_u_495.work) ~= v_u_495.baseText and true or v_u_495.fireMode ~= v_u_495.baseFire
		end)
		if v496 then
			v496 = v497 == true
		end
		local v498, v499 = v494(v496, v_u_144.cancelUntil or 0, v493)
		if v498 then
			v_u_5.close(false)
		else
			v_u_144.cancelUntil = v499
			v_u_144.cancelChip.Text = "SURE?"
			local function v500()
				-- upvalues: (ref) v_u_144, (ref) v_u_5
				v_u_144.cctx.lib.HushUI.toast(v_u_5.TEXT.cancelAsk, "warn")
			end
			pcall(v500)
			task.delay(4.1, function()
				-- upvalues: (ref) v_u_144
				if v_u_144 and (v_u_144.cancelUntil or 0) <= os.clock() then
					v_u_144.cancelChip.Text = "CANCEL"
				end
			end)
		end
	end
	local v502 = v_u_385(v463, v_u_394, "CANCEL", 66, v_u_144.chipH, v501)
	v502.ZIndex = 22
	local v503 = v_u_144.barChips
	table.insert(v503, {
		["gui"] = nil,
		["w"] = 66,
		["gui"] = v502
	})
	v492.cancelChip = v502
	local function v504()
		-- upvalues: (ref) v_u_5
		v_u_5.close(true)
	end
	local v505 = v_u_385(v463, v_u_394, "DONE", 58, v_u_144.chipH, v504)
	v505.ZIndex = 22
	local v506 = v_u_144.barChips
	table.insert(v506, {
		["gui"] = nil,
		["w"] = 58,
		["gui"] = v505
	})
	v505.BackgroundColor3 = v_u_394.color.accent
	v505.TextColor3 = v_u_394.color.ink
	local v507 = math.min(v425, 1.25)
	local v508 = v507 * 22
	local v509 = math.floor(v508)
	local v510 = v509 + v_u_144.chipH + 8
	local v511 = v507 * 238
	local v512 = math.floor(v511)
	local v513 = {
		["Name"] = "Panel",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 20,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_394.color.bgDeep,
		["AnchorPoint"] = Vector2.new(0, 1)
	}
	local v514 = UDim2.new
	local v515 = v512 / 2
	v513.Position = v514(0.5, -math.floor(v515), 1, -6)
	v513.Size = UDim2.fromOffset(v512, v510)
	local v516 = Instance.new("Frame")
	for v517, v518 in v513 do
		v516[v517] = v518
	end
	if v411 then
		v516.Parent = v411
	end
	local v519 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v520 = Instance.new("UICorner")
	for v521, v522 in v519 do
		v520[v521] = v522
	end
	if v516 then
		v520.Parent = v516
	end
	local v523 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_394.color.lineStrong
	}
	local v524 = Instance.new("UIStroke")
	for v525, v526 in v523 do
		v524[v525] = v526
	end
	if v516 then
		v524.Parent = v516
	end
	v_u_144.panel = v516
	local v527 = v_u_144
	local v528 = {
		["Name"] = "Label",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Text"] = "",
		["ZIndex"] = 21,
		["Position"] = UDim2.fromOffset(8, 2),
		["Size"] = UDim2.fromOffset(v512 - 16, v509),
		["FontFace"] = v_u_394.font.heading,
		["TextColor3"] = v_u_394.color.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}
	local v529 = Instance.new("TextLabel")
	for v530, v531 in v528 do
		v529[v530] = v531
	end
	if v516 then
		v529.Parent = v516
	end
	v527.panelLabel = v529
	v_u_144.sizeChips = {}
	local v532 = v509 + 2
	local v533 = 6
	for v_u_534, v535 in { "SMALL", "NORMAL", "LARGE" } do
		local v536 = v507 * 54
		local v537 = math.floor(v536)
		local v538 = v_u_385(v516, v_u_394, v535, v537, v_u_144.chipH, function()
			-- upvalues: (ref) v_u_144, (ref) v_u_5, (copy) v_u_534
			if v_u_144.selected then
				v_u_5._setSize(v_u_144.selected, v_u_534)
			end
		end)
		v538.Position = UDim2.fromOffset(v533, v532)
		v538.ZIndex = 22
		v538.TextSize = 12
		v533 = v533 + (v537 + 4)
		v_u_144.sizeChips[v_u_534] = v538
	end
	local v539 = v_u_144
	local v540 = v_u_385
	local v541 = v507 * 52
	v539.resetOne = v540(v516, v_u_394, "RESET", math.floor(v541), v_u_144.chipH, function()
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if v_u_144.selected then
			v_u_5._reset(v_u_144.selected)
		end
	end)
	v_u_144.resetOne.Position = UDim2.fromOffset(v533, v532)
	v_u_144.resetOne.ZIndex = 22
	v_u_144.resetOne.TextSize = 12
	local v542 = v_u_144.conns
	local v543 = v_u_4.InputChanged
	local function v546(p544)
		-- upvalues: (ref) v_u_144, (ref) v_u_5, (ref) v_u_149
		local v545 = v_u_144
		if v545 then
			v545 = v_u_144.drag
		end
		if v545 then
			if v545.io and p544 == v545.io or p544.UserInputType == Enum.UserInputType.MouseMovement and (v545.io and v545.io.UserInputType == Enum.UserInputType.MouseButton1) then
				v_u_5._move((v_u_149(p544)))
			end
		end
	end
	table.insert(v542, v543:Connect(v546))
	local v547 = v_u_144.conns
	local v548 = v_u_4.InputEnded
	local function v551(p549)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		local v550 = v_u_144
		if v550 then
			v550 = v_u_144.drag
		end
		if v550 and (v550.io and (p549 == v550.io or v550.io.UserInputType == Enum.UserInputType.MouseButton1 and p549.UserInputType == Enum.UserInputType.MouseButton1)) then
			v_u_5._finish()
		end
	end
	table.insert(v547, v548:Connect(v551))
	v411.InputBegan:Connect(function(p552)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if v_u_144 and (not v_u_144.drag and (p552.UserInputType == Enum.UserInputType.Touch or p552.UserInputType == Enum.UserInputType.MouseButton1)) then
			v_u_5._select(nil)
		end
	end)
	local v553 = v_u_144.conns
	local v554 = v_u_3.Heartbeat
	local function v562()
		-- upvalues: (ref) v_u_144, (ref) v_u_158, (copy) v_u_394, (copy) v_u_388, (ref) v_u_170, (ref) v_u_236, (ref) v_u_302, (copy) p_u_386, (ref) v_u_5
		if v_u_144 then
			local v555, v556 = v_u_158(v_u_394, v_u_144.root)
			if v555 ~= v_u_144.vp or v556 ~= v_u_144.full then
				v_u_144.vp = v555
				v_u_144.full = v556
				local v557 = v_u_388
				if typeof(v557:GetAttribute("DevViewport")) == "Vector2" then
					v_u_144.root.Size = UDim2.fromOffset(v555.X, v555.Y)
				end
				if v_u_144 then
					v_u_144.lay = v_u_170()
					v_u_236()
					v_u_302()
				end
			end
			local v_u_558 = p_u_386
			local v_u_559 = "TouchLayoutEdit"
			local v560, v561 = pcall(function()
				-- upvalues: (copy) v_u_558, (copy) v_u_559
				return v_u_558.config.flag(v_u_559)
			end)
			if v560 and v561 == false or v_u_388:GetAttribute("Place") ~= v_u_144.place then
				v_u_5.close(false, true)
			end
		end
	end
	table.insert(v553, v554:Connect(v562))
	v_u_388:SetAttribute("HudEditOpen", true)
	v405.Parent = v402
	if v_u_144 then
		v_u_144.lay = v_u_170()
		v_u_236()
		v_u_302()
	end
	return true
end
function v_u_5.state() -- name: state
	-- upvalues: (ref) v_u_144, (copy) v_u_5
	if not v_u_144 then
		return "closed"
	end
	local v563 = v_u_144.lay
	local v564 = {}
	local v565 = string.format
	local v566 = v_u_144.cls
	local v567 = v_u_144.layer
	local v568 = v_u_144.vp.X
	local v569 = v_u_144.vp.Y
	local v570 = v_u_144.full.X
	local v571 = v_u_144.full.Y
	local v572 = v563.ts
	local v573 = v563.hs
	local v574 = v_u_144.fireMode
	local v575 = v_u_144.snap
	local v576 = tostring(v575)
	local v577 = v_u_144.selected
	local v578 = tostring(v577)
	local v579 = v_u_144.drag ~= nil
	__set_list(v564, 1, {v565("open class=%s layer=%s vp=%dx%d full=%dx%d ts=%.3f hs=%.2f fire=%s snap=%s selected=%s drag=%s items=%d overlaps=%d", v566, v567, v568, v569, v570, v571, v572, v573, v574, v576, v578, tostring(v579), #v563.items, #v_u_5.overlaps(v563.items)), "work=" .. v_u_144.deps.S.encode(v_u_144.work)})
	for _, v580 in v563.items do
		local v581 = string.format
		local v582 = v580.name
		local v583 = v580.rect[1]
		local v584 = v580.rect[2]
		local v585 = v580.rect[3]
		local v586 = v580.rect[4]
		local v587 = v580.entry and " *" or ""
		local v588 = v580.tray and " (tray)" or ""
		table.insert(v564, v581("%s=%.0f,%.0f..%.0f,%.0f%s%s", v582, v583, v584, v585, v586, v587, v588))
	end
	return table.concat(v564, "\n")
end
function v_u_5.registerDebug(p_u_589) -- name: registerDebug
	-- upvalues: (ref) v_u_144, (copy) v_u_5, (copy) v_u_236
	p_u_589.command("hud.edit.open", function()
		-- upvalues: (ref) v_u_5, (copy) p_u_589
		return v_u_5.open(p_u_589, nil) and "opened" or "could not open"
	end)
	p_u_589.command("hud.edit.layer", function(p590)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		v_u_5._layer(p590[1] or "pad")
		return "layer=" .. v_u_144.layer
	end)
	p_u_589.command("hud.edit.state", function()
		-- upvalues: (ref) v_u_5
		return v_u_5.state()
	end)
	p_u_589.command("hud.edit.tap", function(p591)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		v_u_5._select(p591[1])
		return v_u_5.state()
	end)
	p_u_589.command("hud.edit.drag", function(p592)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		local v593 = p592[1]
		local v594
		if v593 then
			v594 = v_u_144.lay.byName[v593]
		else
			v594 = v593
		end
		if not v594 then
			return "no item " .. tostring(v593)
		end
		local v595 = p592[2]
		local v596 = tonumber(v595) or 0.5
		local v597 = p592[3]
		local v598 = tonumber(v597) or 0.5
		if v596 <= 1.5 and v598 <= 1.5 then
			v596 = v596 * v_u_144.vp.X
			v598 = v598 * v_u_144.vp.Y
		end
		local v599 = Vector2.new((v594.rect[1] + v594.rect[3]) / 2, (v594.rect[2] + v594.rect[4]) / 2)
		v_u_5._begin(v593, nil, v599)
		v_u_5._move(v599 + Vector2.new(5, 0))
		v_u_5._move(Vector2.new(v596, v598))
		v_u_5._finish()
		local v600 = v_u_144.lay.byName[v593]
		return string.format("%s -> %.0f,%.0f..%.0f,%.0f entry=%s", v593, v600.rect[1], v600.rect[2], v600.rect[3], v600.rect[4], not v600.entry and "none" or string.format("%.3f,%.3f,%d", v600.entry.fx, v600.entry.fy, v600.entry.sz))
	end)
	p_u_589.command("hud.edit.size", function(p601)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		local v602 = v_u_5._setSize
		local v603 = p601[1] or ""
		local v604 = p601[2]
		v602(v603, tonumber(v604) or 2)
		return v_u_5.state()
	end)
	p_u_589.command("hud.edit.reset", function(p605)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		v_u_5._reset(p605[1] or "all")
		return v_u_5.state()
	end)
	p_u_589.command("hud.edit.snap", function(p606)
		-- upvalues: (ref) v_u_144, (ref) v_u_236
		if not v_u_144 then
			return "closed"
		end
		v_u_144.snap = p606[1] == "1"
		v_u_236()
		local v607 = v_u_144.snap
		return "snap=" .. tostring(v607)
	end)
	p_u_589.command("hud.edit.fire", function(p608)
		-- upvalues: (ref) v_u_144, (ref) v_u_5
		if not v_u_144 then
			return "closed"
		end
		v_u_5._setFire(p608[1] or "auto")
		return "fire=" .. v_u_144.fireMode
	end)
	p_u_589.command("hud.edit.done", function()
		-- upvalues: (ref) v_u_5
		v_u_5.close(true)
		return "saved"
	end)
	p_u_589.command("hud.edit.cancel", function()
		-- upvalues: (ref) v_u_5
		v_u_5.close(false)
		return "cancelled"
	end)
end
return v_u_5