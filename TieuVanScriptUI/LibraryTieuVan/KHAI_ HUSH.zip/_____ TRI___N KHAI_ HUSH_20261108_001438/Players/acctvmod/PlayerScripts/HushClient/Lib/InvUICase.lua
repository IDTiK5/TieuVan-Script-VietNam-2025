-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUICase

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_2 = require(v1:WaitForChild("Items"))
local v_u_3 = require(v1:WaitForChild("Grid"))
local v_u_4 = require(v1:WaitForChild("StashCase"))
local v_u_5 = require(v1:WaitForChild("Config"))
local v_u_6 = require(v1:WaitForChild("Theme"))
local v_u_7 = {
	["env"] = {}
}
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = false
local function v_u_21(p11, p12) -- name: windowFlagOn
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_5
	local v13
	if type(p11) == "table" then
		local v14 = p11.work
		if type(v14) == "table" then
			v13 = p11.work
		else
			v13 = nil
		end
	else
		v13 = nil
	end
	local v15 = v13 and v13.containers
	if v15 then
		v15 = v13.containers[p12]
	end
	if type(v15) ~= "table" then
		return false
	end
	local v16 = v15.kind or v_u_4.hostKind(v_u_2.get(v15.itemId)) or "bag"
	if v16 == nil then
		return false
	end
	local v17 = v16 == "crate" and "StashCrates" or "CaseWindows"
	local v18 = v_u_5.flag
	local v19, v20 = pcall(v18, v17)
	if v19 then
		v19 = v20 == true
	end
	return v19
end
local v_u_22 = nil
local v_u_23 = false
function v_u_7.name(p24, p25) -- name: name
	-- upvalues: (copy) v_u_4
	return v_u_4.displayName(p24, p25)
end
function v_u_7.canRename(p26) -- name: canRename
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v27 = v_u_5.flag
	local v28, v29 = pcall(v27, "ItemNames")
	if v28 then
		v28 = v29 == true
	end
	if v28 then
		v28 = v_u_4.renamable(p26)
	end
	return v28
end
function v_u_7.openable(p30, p31, p32) -- name: openable
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v33
	if p30.mode == "raid" or (p31 == nil or (p31.kind ~= "grid" or p31.container ~= "stash")) then
		v33 = nil
	else
		v33 = v_u_4.hostKind(p32)
		local v34
		if v33 == nil then
			v34 = false
		else
			local v35 = v33 == "crate" and "StashCrates" or "CaseWindows"
			local v36 = v_u_5.flag
			local v37
			v34, v37 = pcall(v36, v35)
			if v34 then
				v34 = v37 == true
			end
		end
		if not v34 then
			v33 = nil
		end
	end
	local v38
	if v33 == nil then
		v38 = false
	else
		local v39 = p31.item.uid
		local v40
		if type(p30) == "table" then
			local v41 = p30.work
			if type(v41) == "table" then
				v40 = p30.work
			else
				v40 = nil
			end
		else
			v40 = nil
		end
		local v42
		if v40 == nil then
			v42 = false
		else
			local v43 = v40.containers
			if type(v43) == "table" then
				v42 = v40.containers["in:" .. v39] ~= nil
			else
				v42 = false
			end
		end
		v38 = not v42
	end
	return v38
end
local function v_u_61(p44, p45, p46) -- name: firstWindowFor
	-- upvalues: (copy) v_u_21, (copy) v_u_4, (copy) v_u_2, (copy) v_u_3
	local v47
	if type(p44) == "table" then
		local v48 = p44.work
		if type(v48) == "table" then
			v47 = p44.work
		else
			v47 = nil
		end
	else
		v47 = nil
	end
	if not v47 then
		return nil
	end
	for v49 = 1, 2 do
		local v50
		if type(p44) == "table" then
			local v51 = p44.work
			if type(v51) == "table" then
				v50 = p44.work
			else
				v50 = nil
			end
		else
			v50 = nil
		end
		local v52
		if v50 then
			local v53 = v50.cases
			v52 = type(v53) ~= "table" and {} or v50.cases
		else
			v52 = {}
		end
		for _, v54 in v52 do
			local v55 = v47.containers
			if v55 then
				v55 = v47.containers["in:" .. v54]
			end
			local v56 = p44.sections
			if v56 then
				v56 = p44.sections["in:" .. v54]
			end
			if type(v55) ~= "table" or v54 == p45.uid then
				continue
			end
			local v57 = v55.accepts
			if type(v57) == "table" ~= (v49 == 1) or (not v_u_21(p44, "in:" .. v54) or v56 and v56.folded) or not v_u_4.accepts(v_u_2.get(v55.itemId), p46, p45) then
				continue
			end
			local v58, v59, v60 = v_u_3.findSpot(v55, p45, p45.uid)
			if v58 == nil or v59 == nil then
				continue
			end
			return "in:" .. v54, v58, v59, v60 == true
		end
	end
	return nil
end
function v_u_7.acts(p62, p63, p64, p65) -- name: acts
	-- upvalues: (copy) v_u_21, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_61
	if p62.mode == "raid" or (p63 == nil or p64 == nil) then
		return
	else
		local v66 = p63.item
		local v67 = p63.container
		local v68
		if p63.kind == "grid" and (type(v67) == "string" and string.sub(v67, 1, 3) == "in:") then
			v68 = v_u_21(p62, v67)
		else
			v68 = false
		end
		local v69
		if p62.mode == "raid" or (p63 == nil or (p63.kind ~= "grid" or p63.container ~= "stash")) then
			v69 = nil
		else
			v69 = v_u_4.hostKind(p64)
			local v70
			if v69 == nil then
				v70 = false
			else
				local v71 = v69 == "crate" and "StashCrates" or "CaseWindows"
				local v72 = v_u_5.flag
				local v73
				v70, v73 = pcall(v72, v71)
				if v70 then
					v70 = v73 == true
				end
			end
			if not v70 then
				v69 = nil
			end
		end
		if v69 then
			local v74 = v66.uid
			local v75
			if type(p62) == "table" then
				local v76 = p62.work
				if type(v76) == "table" then
					v75 = p62.work
				else
					v75 = nil
				end
			else
				v75 = nil
			end
			local v77
			if v75 == nil then
				v77 = false
			else
				local v78 = v75.containers
				if type(v78) == "table" then
					v77 = v75.containers["in:" .. v74] ~= nil
				else
					v77 = false
				end
			end
			table.insert(p65, v77 and {
				["id"] = "caseclose",
				["text"] = "Close"
			} or {
				["id"] = "caseopen",
				["text"] = "Open"
			})
		end
		if v_u_7.canRename(p64) and p63.kind ~= "ground" then
			table.insert(p65, {
				["id"] = "caserename",
				["text"] = "Rename"
			})
		end
		if v68 then
			table.insert(p65, {
				["id"] = "casetake",
				["text"] = "Take out"
			})
			for v79 = #p65, 1, -1 do
				if p65[v79].id ~= "sell" then
					continue
				end
				table.remove(p65, v79)
			end
		elseif p63.kind == "grid" and (v67 == "stash" and (v_u_4.hostKind(p64) == nil and v_u_61(p62, v66, p64))) then
			table.insert(p65, {
				["id"] = "caseto",
				["text"] = "To case"
			})
		end
	end
end
local v_u_80 = {
	["caseopen"] = "openbag",
	["caseclose"] = "openbag",
	["caserename"] = "info",
	["caseto"] = "load",
	["casetake"] = "unequip"
}
function v_u_7.strip(p81, p82, p83, p84) -- name: strip
	-- upvalues: (copy) v_u_7, (copy) v_u_80, (copy) v_u_4
	local v85 = {}
	v_u_7.acts(p81, p82, p83, v85)
	for _, v86 in v85 do
		if not v_u_80[v86.id] then
			continue
		end
		local v87 = v_u_80[v86.id]
		local v88 = v87 == "openbag" and v_u_4.hostKind(p83) == "rig" and "openvest" or v87
		local v89 = {
			["id"] = v86.id,
			["text"] = v86.text,
			["icon"] = v88
		}
		table.insert(p84, v89)
	end
end
function v_u_7.run(p90, p91, p92) -- name: run
	-- upvalues: (copy) v_u_7, (ref) v_u_10, (ref) v_u_9, (copy) v_u_2, (copy) v_u_61, (copy) v_u_4, (copy) v_u_3
	if string.sub(p92, 1, 4) ~= "case" then
		return false
	end
	local v93 = v_u_7.env
	local v94
	if type(p90) == "table" then
		local v95 = p90.work
		if type(v95) == "table" then
			v94 = p90.work
		else
			v94 = nil
		end
	else
		v94 = nil
	end
	if not v94 then
		return true
	end
	local v96 = v93.locate
	if v96 then
		v96 = v93.locate(v94, p91)
	end
	if p92 == "caseopen" then
		local v97 = {
			["op"] = "openCase",
			["uid"] = nil,
			["uid"] = p91
		}
		local v98 = v_u_7.env
		if v98.send then
			v98.send(p90, v97)
		end
		p90.pendingSub = "in:" .. p91
		p90.caseFocus = p91
		p90.padFocusCase = "in:" .. p91
		if v93.sound then
			v93.sound("open")
		end
	elseif p92 == "caseclose" then
		local v99 = {
			["op"] = "closeCase",
			["uid"] = nil,
			["uid"] = p91
		}
		local v100 = v_u_7.env
		if v100.send then
			v100.send(p90, v99)
		end
		if v93.sound then
			v93.sound("close")
		end
	elseif p92 == "caserename" then
		if not v_u_10 then
			v_u_10 = true
			local v101, v102 = pcall(function()
				return require(script.Parent:WaitForChild("InvUIName", 3))
			end)
			if v101 then
				v_u_9 = v102
			end
		end
		local v103 = v_u_9
		if v103 and v96 then
			v103.open(p90, v96.item, v93)
		end
	elseif p92 == "caseto" and v96 then
		local v104 = v_u_2.get(v96.item.id)
		local v105, v106, v107, v108 = v_u_61(p90, v96.item, v104)
		if v105 then
			local v109 = {
				["op"] = "move",
				["uid"] = nil,
				["to"] = nil,
				["x"] = nil,
				["y"] = nil,
				["r"] = nil,
				["uid"] = p91,
				["to"] = v105,
				["x"] = v106,
				["y"] = v107,
				["r"] = v108
			}
			local v110 = v_u_7.env
			if v110.send then
				v110.send(p90, v109)
			end
			if v93.predictMove then
				v93.predictMove(p90, p91, v105, v106, v107, v108)
			end
			if v93.sound then
				v93.sound("click")
			end
		elseif v93.toast then
			v93.toast(v_u_4.REASON.full)
		end
	else
		if p92 ~= "casetake" or not v96 then
			return false
		end
		local v111 = v94.containers
		if v111 then
			v111 = v94.containers.stash
		end
		local v112, v113, v114
		if type(v111) == "table" then
			v112, v113, v114 = v_u_3.findSpot(v111, v96.item, v96.item.uid)
		else
			v112 = nil
			v113 = nil
			v114 = nil
		end
		if v112 == nil or v113 == nil then
			local v115 = {
				["op"] = "quick",
				["uid"] = nil,
				["uid"] = p91
			}
			local v116 = v_u_7.env
			if v116.send then
				v116.send(p90, v115)
			end
		else
			local v117 = {
				["op"] = "move",
				["uid"] = nil,
				["to"] = "stash",
				["x"] = nil,
				["y"] = nil,
				["r"] = nil,
				["uid"] = p91,
				["x"] = v112,
				["y"] = v113,
				["r"] = v114 == true
			}
			local v118 = v_u_7.env
			if v118.send then
				v118.send(p90, v117)
			end
			if v93.predictMove then
				v93.predictMove(p90, p91, "stash", v112, v113, v114 == true)
			end
		end
		if v93.sound then
			v93.sound("click")
		end
	end
	return true
end
function v_u_7.canDrop(p119, p120) -- name: canDrop
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	p119.caseWhy = nil
	if type(p120) ~= "table" or p120.case ~= true then
		return true
	end
	if p119.uid == p120.hostUid then
		p119.caseWhy = "It can\'t go inside itself."
		return false
	end
	local v121, v122 = v_u_4.accepts(v_u_2.get(p120.itemId), v_u_2.get(p119.inst.id), p119.inst)
	if v121 then
		return true
	end
	p119.caseWhy = v_u_4.REASON[v122 or "notHost"]
	return false
end
function v_u_7.padFocusTarget(p123, p124, p125) -- name: padFocusTarget
	if p124 == "Gamepad" and (p125 ~= true and type(p123) == "table") then
		return p123[#p123]
	else
		return nil
	end
end
function v_u_7.closeTopOf(p126) -- name: closeTopOf
	-- upvalues: (copy) v_u_7
	if not p126 or (p126.dead or (not p126.work or p126.mode == "raid")) then
		return false
	end
	if p126.isShown and not p126.isShown() then
		return false
	end
	local v127
	if type(p126) == "table" then
		local v128 = p126.work
		if type(v128) == "table" then
			v127 = p126.work
		else
			v127 = nil
		end
	else
		v127 = nil
	end
	local v129
	if v127 then
		local v130 = v127.cases
		v129 = type(v130) ~= "table" and {} or v127.cases
	else
		v129 = {}
	end
	local v131 = v129[#v129]
	if not v131 then
		return false
	end
	local v132 = {
		["op"] = "closeCase",
		["uid"] = nil,
		["uid"] = v131
	}
	local v133 = v_u_7.env
	if v133.send then
		v133.send(p126, v132)
	end
	local v134 = v_u_7.env
	if v134.sound then
		v134.sound("close")
	end
	if p126.work.cases then
		table.remove(p126.work.cases, #p126.work.cases)
		p126.work.containers["in:" .. v131] = nil
		if v134.renderMount then
			v134.renderMount(p126)
		end
	end
	return true
end
function v_u_7.closeTop() -- name: closeTop
	-- upvalues: (copy) v_u_7, (ref) v_u_8
	local v135, v136 = pcall(function()
		return require(script.Parent:WaitForChild("HushUI", 3))
	end)
	return v135 and (type(v136) == "table" and (v136.modalCount and v136.modalCount() > 0)) and true or v_u_7.closeTopOf(v_u_8)
end
local function v_u_147(p_u_137, p138, p_u_139) -- name: wrapGrid
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v_u_140 = v_u_7.env
	local v141 = p138.grid.holder
	local v142 = v_u_140.new("ScrollingFrame", {
		["Name"] = "CaseScroll",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 3,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 0,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["ElasticBehavior"] = nil,
		["ScrollingEnabled"] = false,
		["Size"] = v141.Size,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["ScrollBarImageColor3"] = v_u_6.color.lineStrong,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ElasticBehavior"] = Enum.ElasticBehavior.Never
	}, p138.frame)
	v141.LayoutOrder = 0
	v141.Parent = v142
	p138.scroll = v142
	p138.grid.clip = v142
	local v143 = v_u_140.new("TextButton", {
		["Name"] = "FoldTap",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 0,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, p138.header.frame)
	v143.Activated:Connect(function()
		-- upvalues: (copy) p_u_137, (copy) p_u_139, (copy) v_u_140
		p_u_137.caseFocus = p_u_139
		if v_u_140.sound then
			v_u_140.sound("click")
		end
		if v_u_140.renderMount then
			v_u_140.renderMount(p_u_137)
		end
	end)
	p138.tap = v143
	local v144 = p_u_137.scrollers
	if type(v144) == "table" then
		for v145 = #p_u_137.scrollers, 1, -1 do
			if p_u_137.scrollers[v145].Parent then
				continue
			end
			table.remove(p_u_137.scrollers, v145)
		end
		local v146 = p_u_137.scrollers
		table.insert(v146, 1, v142)
		v142:GetPropertyChangedSignal("CanvasPosition"):Connect(function()
			-- upvalues: (copy) p_u_137
			p_u_137.cullDirty = true
		end)
	end
end
local function v_u_163(p148, p149) -- name: planFor
	-- upvalues: (ref) v_u_23, (ref) v_u_22, (copy) v_u_6
	if not v_u_23 then
		v_u_23 = true
		local v150, v151 = pcall(function()
			return require(script.Parent:WaitForChild("InvUICaseLayout", 3))
		end)
		if v150 and type(v151) == "table" then
			v_u_22 = v151
		end
	end
	local v152 = v_u_22
	if not v152 or #p149 == 0 then
		return nil
	end
	local v153 = p148.touch == true
	local v154
	if p148.standalone then
		if v153 then
			v154 = v_u_6.touch(40) + 16
		else
			v154 = p148.compact and 48 or 64
		end
	else
		v154 = 0
	end
	local v155 = v152.columnVisible(p148.dw or 1280, p148.dh or 720, v153, v154)
	local v156 = v_u_6.touch(24) + 8
	local v157 = math.max(30, v156)
	local v158 = v_u_6.touch(24)
	local v159 = #p149
	local v160 = {}
	for v161, v162 in p149 do
		v160[v161] = v162.c.h
		if v162.uid ~= p148.caseFocus then
			continue
		end
		v159 = v161
	end
	return v152.plan(v155, p148.cell, v160, {
		["chrome"] = v157 + v158 + 22,
		["head"] = v157 + 10,
		["focus"] = v159
	})
end
local function v_u_176(p164, p165, p166, p167) -- name: applyItem
	-- upvalues: (ref) v_u_23, (ref) v_u_22
	local v168 = p165.scroll
	if v168 then
		if not v_u_23 then
			v_u_23 = true
			local v169, v170 = pcall(function()
				return require(script.Parent:WaitForChild("InvUICaseLayout", 3))
			end)
			if v169 and type(v170) == "table" then
				v_u_22 = v170
			end
		end
		local v171 = v_u_22
		local v172 = p164.cell
		local v173 = p166.w * v172
		local v174 = p166.h * v172
		local v175
		if p167 == nil then
			v175 = false
		else
			v175 = p167.collapsed == true
		end
		p165.folded = v175
		v168.Visible = not v175
		if p165.buttonRow then
			p165.buttonRow.Visible = not v175
		end
		if p165.tap then
			p165.tap.Visible = v175
		end
		if v175 then
			return
		elseif p167 == nil or not v171 then
			v168.Size = UDim2.fromOffset(v173, v174)
			v168.CanvasSize = UDim2.fromOffset(0, v174)
			v168.ScrollingEnabled = false
			v168.ScrollBarThickness = 0
		else
			v168.Size = UDim2.fromOffset(v171.innerWidth(v173, p167.scroll), p167.shown * v172)
			v168.CanvasSize = UDim2.fromOffset(0, v174)
			v168.ScrollingEnabled = p167.scroll
			v168.ScrollBarThickness = not p167.scroll and 0 or v171.SB
			if not p167.scroll and v168.CanvasPosition.Y ~= 0 then
				v168.CanvasPosition = Vector2.zero
			end
		end
	else
		return
	end
end
local function v_u_204(p177, p_u_178, p179, p180, p_u_181) -- name: buttonRow
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v_u_182 = v_u_7.env
	local v183 = v_u_6.touch(24)
	local v184 = v_u_182.new("ScrollingFrame", {
		["Name"] = "CaseButtons",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 2,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 0,
		["ScrollingDirection"] = nil,
		["ElasticBehavior"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v183),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
		["ScrollingDirection"] = Enum.ScrollingDirection.X,
		["ElasticBehavior"] = Enum.ElasticBehavior.Never
	}, p177.frame)
	v_u_182.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v184)
	p177.buttonRow = v184
	local v185 = 0
	if v_u_7.canRename(p180) then
		local function v186()
			-- upvalues: (ref) v_u_7, (copy) p_u_181, (copy) p_u_178
			v_u_7.run(p_u_181, p_u_178, "caserename")
		end
		v185 = v185 + 1
		local v187 = v_u_182.smallButton(v184, "Rename", "ghost", v185, v186)
		local v188 = p177.buttons
		table.insert(v188, v187)
	end
	if p179 ~= "rig" then
		local function v192()
			-- upvalues: (copy) p_u_181, (copy) p_u_178, (ref) v_u_7, (copy) v_u_182
			local v189 = p_u_181
			local v190 = {
				["op"] = "caseFill",
				["uid"] = nil,
				["uid"] = p_u_178
			}
			local v191 = v_u_7.env
			if v191.send then
				v191.send(v189, v190)
			end
			if v_u_182.sound then
				v_u_182.sound("confirm")
			end
		end
		v185 = v185 + 1
		local v193 = v_u_182.smallButton(v184, "Store all", "primary", v185, v192)
		local v194 = p177.buttons
		table.insert(v194, v193)
	end
	local function v198()
		-- upvalues: (copy) p_u_181, (copy) p_u_178, (ref) v_u_7, (copy) v_u_182
		local v195 = p_u_181
		local v196 = {
			["op"] = "caseEmpty",
			["uid"] = nil,
			["uid"] = p_u_178
		}
		local v197 = v_u_7.env
		if v197.send then
			v197.send(v195, v196)
		end
		if v_u_182.sound then
			v_u_182.sound("click")
		end
	end
	v185 = v185 + 1
	local v199 = v_u_182.smallButton(v184, "Empty", "ghost", v185, v198)
	local v200 = p177.buttons
	table.insert(v200, v199)
	local function v201()
		-- upvalues: (ref) v_u_7, (copy) p_u_181, (copy) p_u_178
		v_u_7.run(p_u_181, p_u_178, "caseclose")
	end
	v185 = v185 + 1
	local v202 = v_u_182.smallButton(v184, "Close", "ghost", v185, v201)
	local v203 = p177.buttons
	table.insert(v203, v202)
end
function v_u_7.render(p205, p206, p207, p208) -- name: render
	-- upvalues: (ref) v_u_8, (copy) v_u_7, (copy) v_u_163, (copy) v_u_2, (copy) v_u_4, (copy) v_u_147, (copy) v_u_204, (copy) v_u_6, (copy) v_u_3, (copy) v_u_176
	if p205.mode ~= "raid" and type(p206) == "table" then
		local v209 = p206.cases
		if type(v209) == "table" then
			v_u_8 = p205
			local v210 = v_u_7.env
			local v211 = p205.narrow and 90 or -10
			local v212 = {}
			for _, v213 in p206.cases do
				local v214 = p206.containers
				if v214 then
					v214 = p206.containers["in:" .. v213]
				end
				if type(v214) ~= "table" or v214.case ~= true then
					continue
				end
				table.insert(v212, {
					["uid"] = v213,
					["c"] = v214
				})
			end
			local v215 = v_u_163(p205, v212)
			for v216, v217 in v212 do
				local v218 = v217.uid
				local v219 = v217.c
				local v220 = "in:" .. v218
				p207[v220] = true
				local v221 = v210.containerSection(p205, p205.rightScroll, v220, v219, v211 + v216, p205.rightW)
				v221.kind = "stash"
				local v222 = v_u_2.get(v219.itemId)
				local v223 = v219.kind or (v_u_4.hostKind(v222) or "bag")
				if not v221.caseDone then
					v221.caseDone = true
					v_u_147(p205, v221, v218)
					v_u_204(v221, v218, v223, v222, p205)
					local v224 = v219.accepts
					if type(v224) == "table" then
						local v225 = v210.label
						local v226 = v221.grid.cells
						local v227 = {
							["position"] = UDim2.fromOffset(0, 0)
						}
						local v228 = UDim2.new
						local v229 = v219.h
						v227.size = v228(1, 0, 0, math.min(v229, 2) * p205.cell)
						v227.color = v_u_6.color.muted
						local v230 = v225(v226, "", "small", v227)
						v230.Name = "FilterHint"
						v230.TextXAlignment = Enum.TextXAlignment.Center
						v230.TextYAlignment = Enum.TextYAlignment.Center
						v230.ZIndex = 2
						v230.TextTransparency = 0.45
						v221.hint = v230
					end
				end
				v210.setLabel(v221.header.title, string.upper(v_u_4.displayName({
					["cname"] = v219.cname
				}, v222)))
				if v223 == "crate" then
					v221.header.title.TextColor3 = v_u_6.rarityColor(6)
				end
				local v231 = v_u_3.usedCells(v219)
				local v232 = v_u_176
				local v233
				if v215 then
					v233 = v215.items[v216]
				else
					v233 = nil
				end
				v232(p205, v221, v219, v233)
				v210.setLabel(v221.header.sub, string.format("%d / %d%s", v231, v_u_3.capacity(v219), v221.folded and "  SHOW" or ""))
				if v221.hint then
					local v234 = v219.accepts
					v221.hint.Text = #v219.items == 0 and (type(v234) == "table" and v234.ammo and "Ammunition only" or "Guns and blades only") or ""
				end
				for _, v235 in v219.items do
					p208[v235.uid] = true
					local v236 = v210.tileFor(p205, v235, v221.grid.cells, false)
					v210.Pouch.place(v221.grid.cells, v236.frame, v235.x, v235.y, v_u_3.size(v235))
				end
				if p205.padFocusCase ~= v220 then
					break
				end
				p205.padFocusCase = nil
				local v237, v238 = pcall(function()
					return require(script.Parent:WaitForChild("HushUI", 3))
				end)
				local v239 = v_u_7.padFocusTarget
				local v240 = v221.buttons
				local v241
				if v237 then
					v241 = v238.device()
				else
					v241 = nil
				end
				local v_u_242 = v239(v240, v241, v221.folded)
				if not v_u_242 then
					break
				end
				task.defer(function()
					-- upvalues: (copy) v_u_242
					if v_u_242.Parent then
						local function v243()
							-- upvalues: (ref) v_u_242
							game:GetService("GuiService").SelectedObject = v_u_242
						end
						pcall(v243)
					end
				end)
			end
			return
		end
	end
end
return v_u_7