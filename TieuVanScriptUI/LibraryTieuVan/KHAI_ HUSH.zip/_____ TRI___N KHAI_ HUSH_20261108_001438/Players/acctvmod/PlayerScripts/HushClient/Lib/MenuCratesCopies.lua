-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCratesCopies

local v_u_1 = {}
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("Skins"))
local v_u_5 = require(v3:WaitForChild("SkinRules"))
v_u_1.PAGE = 25
v_u_1.TEXT = {
	["title"] = "COPIES",
	["plain"] = "PLAIN",
	["equip"] = "EQUIP",
	["equipped"] = "EQUIPPED",
	["scrap"] = "DISCARD",
	["scrapTitle"] = "DISCARD COPY",
	["cancel"] = "CANCEL",
	["loading"] = "Loading your copies...",
	["failed"] = "The copies could not be loaded. Try again in a moment.",
	["again"] = "TRY AGAIN",
	["prev"] = "PREVIOUS",
	["next"] = "NEXT",
	["close"] = "Close",
	["foundYou"] = "Found by you",
	["foundName"] = "Found by %s",
	["foundAnon"] = "Found by a survivor",
	["lastCopy"] = "You have no spare copy.",
	["takeOff"] = "Take it off first.",
	["scrapPlain"] = nil,
	["scrapPlain"] = v_u_5.TEXT.discardAsk
}
local v_u_6 = {}
v_u_1.NAMES = v_u_6
local v_u_7 = {}
function v_u_1.originId(p8) -- name: originId
	if type(p8) == "string" then
		local v9 = string.match(p8, "^S(%d+)%-")
		if v9 then
			return tonumber(v9)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.foundBy(p10, p11, p12) -- name: foundBy
	-- upvalues: (copy) v_u_1
	local v13 = v_u_1.originId(p10)
	if v13 == nil then
		return v_u_1.TEXT.foundAnon
	elseif type(p11) == "number" and v13 == p11 then
		return v_u_1.TEXT.foundYou
	else
		local v14
		if type(p12) == "table" then
			v14 = p12[v13]
		else
			v14 = nil
		end
		if type(v14) == "string" and v14 ~= "" then
			return v_u_1.TEXT.foundName:format(v14)
		else
			return v_u_1.TEXT.foundAnon
		end
	end
end
function v_u_1.dateText(p15) -- name: dateText
	if type(p15) ~= "number" or (p15 ~= p15 or p15 <= 0) then
		return ""
	end
	local v16 = os.date
	local v17 = math.floor(p15)
	local v18, v19 = pcall(v16, "!%d %b %Y", v17)
	return (not v18 or type(v19) ~= "string") and "" or v19
end
function v_u_1.pageInfo(p20, p21, p22) -- name: pageInfo
	-- upvalues: (copy) v_u_1
	local v23 = 1
	local v24 = v_u_1.PAGE
	if type(p22) == "number" and p22 == p22 then
		v24 = p22
	end
	local v25 = math.floor(v24)
	local v26 = math.max(v23, v25)
	local v27 = (type(p20) ~= "number" or p20 ~= p20) and 0 or p20
	local v28 = math.floor(v27)
	local v29 = math.max(0, v28)
	local v30 = ((type(p21) ~= "number" or p21 ~= p21) and 0 or p21) / v26
	local v31 = math.floor(v30) * v26
	local v32 = math.max(0, v31)
	local v33 = v32 + v26
	local v34 = math.min(v29, v33)
	local v35 = {
		["from"] = v29 == 0 and 0 or v32 + 1,
		["to"] = v34,
		["hasPrev"] = v32 > 0,
		["hasNext"] = v34 < v29
	}
	local v36 = v32 - v26
	v35.prev = math.max(0, v36)
	v35.next = v32 + v26
	v35.total = v29
	return v35
end
function v_u_1.rowModel(p37, p38) -- name: rowModel
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v39 = type(p37) ~= "table" and {} or p37
	local v40 = type(p38) ~= "table" and {} or p38
	local v41 = v_u_1.TEXT
	local v42 = v39.k
	local v43
	if type(v42) == "number" and v39.k == v39.k then
		local v44 = v39.k
		local v45 = math.floor(v44)
		v43 = math.max(0, v45)
	else
		v43 = nil
	end
	local v46 = v40.TallyMark
	local v47 = v43 ~= nil
	local v48 = v39.eq == true
	local v49 = v40.total
	local v50 = (type(v49) ~= "number" or v49 ~= v49) and 1 or v49
	local v51 = math.floor(v50)
	local v52 = {
		["uid"] = nil,
		["tally"] = nil,
		["k"] = nil,
		["equipped"] = nil,
		["found"] = nil,
		["date"] = nil,
		["canEquip"] = nil,
		["canScrap"] = true,
		["uid"] = v39.uid,
		["tally"] = v47,
		["k"] = v43,
		["equipped"] = v48,
		["found"] = v_u_1.foundBy(v39.uid, v40.me, v40.names),
		["date"] = v_u_1.dateText(v39.t),
		["canEquip"] = not v48
	}
	if v47 then
		local v53
		if v46 then
			v53 = v46.chipText(v43)
		else
			v53 = "TALLY " .. tostring(v43)
		end
		v52.countText = v53
		v52.level = not v46 and 0 or v46.level(v43)
	else
		v52.countText = v41.plain
		v52.level = 0
	end
	if v48 then
		v52.canScrap = false
		v52.scrapWhy = v41.takeOff
	elseif v51 <= 1 then
		v52.canScrap = false
		v52.scrapWhy = v41.lastCopy
	end
	if not v47 then
		v52.scrapAsk = v41.scrapPlain
		v52.needsConfirm = false
		return v52
	end
	local v54 = v_u_5.commas and v_u_5.commas(v43) or tostring(v43)
	v52.scrapAsk = (v_u_5.TEXT.tallyConfirm or "This copy has %s kills on its TALLY. Discarding it removes the counter for good. Discard it anyway?"):format(v54)
	v52.needsConfirm = true
	return v52
end
function v_u_1.order(p55) -- name: order
	local v56 = {}
	local v57 = {}
	if type(p55) == "table" then
		for v58, v59 in p55 do
			if type(v59) ~= "table" then
				continue
			end
			local v60 = v59.k
			if type(v60) == "number" then
				table.insert(v56, {
					["r"] = v59,
					["i"] = v58
				})
			else
				table.insert(v57, v59)
			end
		end
	end
	table.sort(v56, function(p61, p62)
		if p61.r.k == p62.r.k then
			return p61.i < p62.i
		else
			return p61.r.k > p62.r.k
		end
	end)
	local v63 = {}
	for _, v64 in v56 do
		local v65 = v64.r
		table.insert(v63, v65)
	end
	for _, v66 in v57 do
		table.insert(v63, v66)
	end
	return v63
end
function v_u_1.breakdownRows(p67, p68) -- name: breakdownRows
	local v69 = {}
	if type(p67) ~= "table" then
		return v69
	end
	for v70, v71 in p67 do
		if type(v70) ~= "string" or (type(v71) ~= "number" or (v71 ~= v71 or v71 <= 0)) then
			continue
		end
		local v72 = {
			["id"] = v70,
			["label"] = string.upper((string.gsub(string.gsub(v70, "^boss_", "BOSS "), "_", " "))),
			["n"] = math.floor(v71)
		}
		table.insert(v69, v72)
	end
	table.sort(v69, function(p73, p74)
		if p73.n == p74.n then
			return p73.id < p74.id
		else
			return p73.n > p74.n
		end
	end)
	local v75 = (type(p68) ~= "number" or p68 ~= p68) and 5 or p68
	local v76 = math.floor(v75)
	local v77 = math.max(1, v76)
	while v77 < #v69 do
		table.remove(v69)
	end
	return v69
end
function v_u_1.open(p_u_78, p_u_79) -- name: open
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_6, (copy) v_u_7
	local v_u_80 = p_u_78.ui
	local v_u_81 = p_u_78.theme
	local v_u_82 = v_u_81.color
	local v_u_83 = p_u_79.skin
	local v_u_84 = v_u_4.get(v_u_83)
	if v_u_84 == nil then
		return nil
	end
	local v_u_85 = nil
	local function v86()
		-- upvalues: (ref) v_u_85, (copy) p_u_78
		v_u_85 = p_u_78.cctx.lib.TallyMark
	end
	pcall(v86)
	local v_u_87 = false
	local function v88()
		-- upvalues: (ref) v_u_87, (copy) v_u_81
		v_u_87 = v_u_81.isPhone()
	end
	pcall(v88)
	local v_u_89 = 0
	local function v90()
		-- upvalues: (ref) v_u_89, (ref) v_u_2
		v_u_89 = v_u_2.LocalPlayer.UserId
	end
	pcall(v90)
	local v_u_91 = true
	local v_u_92 = 0
	local v_u_93 = nil
	local v_u_94 = false
	local v_u_95 = nil
	local v_u_96 = {}
	local v_u_97 = nil
	local v98 = {}
	local v_u_99 = nil
	local v_u_100 = 0
	local v_u_101 = nil
	local function v_u_109() -- name: reload
		-- upvalues: (ref) v_u_91, (ref) v_u_100, (copy) p_u_78, (copy) v_u_83, (ref) v_u_92, (copy) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
		if v_u_91 then
			v_u_100 = v_u_100 + 1
			local v_u_102 = v_u_100
			task.spawn(function()
				-- upvalues: (ref) p_u_78, (ref) v_u_83, (ref) v_u_92, (ref) v_u_91, (copy) v_u_102, (ref) v_u_100, (ref) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
				local v103 = p_u_78.fetch
				local v104 = {
					["skin"] = v_u_83,
					["offset"] = v_u_92
				}
				local v105 = v_u_92
				v104.id = v_u_83 .. ":" .. tostring(v105)
				local v106 = v103("skinCopies", v104, 0)
				if v_u_91 and v_u_102 == v_u_100 then
					if type(v106) == "table" and v106.limited == true then
						task.delay(1.3, function()
							-- upvalues: (ref) v_u_91, (ref) v_u_102, (ref) v_u_100, (ref) v_u_109
							if v_u_91 and v_u_102 == v_u_100 then
								v_u_109()
							end
						end)
					else
						local v107
						if type(v106) == "table" then
							local v108 = v106.rows
							v107 = type(v108) ~= "table"
						else
							v107 = true
						end
						v_u_94 = v107
						if v_u_94 then
							v106 = nil
						end
						v_u_93 = v106
						v_u_101()
					end
				else
					return
				end
			end)
		end
	end
	local function v_u_115(p110) -- name: lookup
		-- upvalues: (ref) v_u_1, (ref) v_u_6, (ref) v_u_7, (ref) v_u_89, (ref) v_u_2, (ref) v_u_91, (ref) v_u_101
		local v_u_111 = v_u_1.originId(p110)
		if v_u_111 ~= nil and (v_u_6[v_u_111] == nil and (not v_u_7[v_u_111] and v_u_111 ~= v_u_89)) then
			v_u_7[v_u_111] = true
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (copy) v_u_111, (ref) v_u_7, (ref) v_u_6, (ref) v_u_91, (ref) v_u_101
				local function v112()
					-- upvalues: (ref) v_u_2, (ref) v_u_111
					return v_u_2:GetNameFromUserIdAsync(v_u_111)
				end
				local v113, v114 = pcall(v112)
				v_u_7[v_u_111] = nil
				if v113 and (type(v114) == "string" and v114 ~= "") then
					v_u_6[v_u_111] = v114
					if v_u_91 then
						v_u_101()
					end
				end
			end)
		end
	end
	local function v_u_120(p_u_116) -- name: askScrap
		-- upvalues: (copy) v_u_80, (ref) v_u_1, (copy) p_u_78, (copy) v_u_83, (copy) v_u_96
		local v117 = v_u_80.modal
		local v119 = {
			["title"] = nil,
			["body"] = nil,
			["width"] = 520,
			["buttons"] = nil,
			["title"] = v_u_1.TEXT.scrapTitle,
			["body"] = p_u_116.scrapAsk,
			["buttons"] = {
				{
					["text"] = v_u_1.TEXT.cancel
				},
				{
					["text"] = nil,
					["kind"] = "primary",
					["onClick"] = nil,
					["text"] = v_u_1.TEXT.scrap,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) p_u_116, (ref) p_u_78, (ref) v_u_83, (ref) v_u_96
						local v118 = {
							["op"] = "skinScrapCopy",
							["skin"] = nil,
							["uid"] = nil,
							["confirm"] = nil,
							["skin"] = v_u_83,
							["uid"] = p_u_116.uid,
							["confirm"] = p_u_116.needsConfirm or nil
						}
						v_u_96[p_u_78.op(v118)] = "scrap"
					end
				}
			}
		}
		v117(v119)
	end
	local v_u_121 = p_u_79.compact == true
	local function v_u_161(p122, p123, p124, p125) -- name: buildRow
		-- upvalues: (ref) v_u_1, (copy) v_u_81, (ref) v_u_87, (copy) v_u_121, (copy) v_u_80, (copy) v_u_82, (ref) v_u_85, (copy) v_u_120, (copy) p_u_78, (copy) p_u_79, (copy) v_u_83, (copy) v_u_96
		local v_u_126 = v_u_1.rowModel(p123, p124)
		local v127 = v_u_81.touch(v_u_87 and 64 or 60)
		if v_u_121 then
			v127 = 46 + v_u_81.touch(40) + 8
		end
		local v128 = v_u_80.new
		local v129 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil
		}
		local v130 = p123.uid
		v129.Name = "Copy_" .. tostring(v130)
		v129.BackgroundColor3 = v_u_82.raised
		v129.Size = UDim2.new(1, 0, 0, v127)
		v129.LayoutOrder = p125
		local v131 = v128("Frame", v129, p122)
		local v132 = v_u_80.stroke
		local v133
		if v_u_126.equipped then
			v133 = v_u_82.accent
		else
			v133 = v_u_82.line
		end
		v132(v131, v133)
		local v134
		if v_u_85 then
			v134 = v_u_85.colorOf(v_u_126.level, v_u_81)
		else
			v134 = v_u_82.text2
		end
		if v_u_126.tally and v_u_85 then
			local v135 = v_u_85.new(v131, {
				["size"] = 22,
				["level"] = nil,
				["name"] = "Sign",
				["level"] = v_u_126.level
			})
			v135.frame.AnchorPoint = Vector2.new(0, 0.5)
			v135.frame.Position = UDim2.new(0, 12, 0.5, 0)
		end
		if v_u_121 then
			local v136 = v_u_81.touch(40)
			local v137 = v_u_126.tally and v_u_85 and 40 or 10
			local v138 = v131:FindFirstChild("Sign")
			if v138 and v138:IsA("GuiObject") then
				v138.AnchorPoint = Vector2.new(0, 0)
				v138.Position = UDim2.fromOffset(10, 6)
			end
			local v139 = v_u_80.label
			local v140 = {
				["parent"] = nil,
				["name"] = "Count",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v131,
				["text"] = v_u_126.countText
			}
			if not v_u_126.tally then
				v134 = v_u_82.text2
			end
			v140.color = v134
			v140.position = UDim2.fromOffset(v137, 4)
			v140.size = UDim2.new(1, -(v137 + 8), 0, 20)
			v139(v140)
			local v141 = v_u_126.found
			if v_u_126.date ~= "" then
				v141 = v141 .. "  \194\183  " .. v_u_126.date
			end
			v_u_80.label({
				["parent"] = nil,
				["name"] = "Found",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v131,
				["text"] = v141,
				["color"] = v_u_82.text2,
				["position"] = UDim2.fromOffset(v137, 25),
				["size"] = UDim2.new(1, -(v137 + 8), 0, 14)
			})
			local _, v142 = v_u_80.button({
				["parent"] = nil,
				["name"] = "Scrap",
				["text"] = nil,
				["kind"] = "secondary",
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v131,
				["text"] = v_u_1.TEXT.scrap,
				["size"] = UDim2.new(0.5, -12, 0, v136),
				["anchor"] = Vector2.new(0, 1),
				["position"] = UDim2.new(0.5, 4, 1, -6),
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) v_u_126, (ref) v_u_120
					if v_u_126.canScrap then
						v_u_120(v_u_126)
					end
				end
			})
			v142.setEnabled(v_u_126.canScrap)
			local v143 = v_u_80.button
			local v144 = {
				["parent"] = nil,
				["name"] = "Equip",
				["text"] = nil,
				["kind"] = nil,
				["size"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v131
			}
			local v145
			if v_u_126.equipped then
				v145 = v_u_1.TEXT.equipped
			else
				v145 = v_u_1.TEXT.equip
			end
			v144.text = v145
			v144.kind = v_u_126.equipped and "secondary" or "primary"
			v144.size = UDim2.new(0.5, -12, 0, v136)
			v144.anchor = Vector2.new(0, 1)
			v144.position = UDim2.new(0, 8, 1, -6)
			function v144.onClick() -- name: onClick
				-- upvalues: (copy) v_u_126, (ref) p_u_78, (ref) p_u_79, (ref) v_u_83, (ref) v_u_96
				if v_u_126.canEquip then
					local v146 = v_u_126.uid
					v_u_96[p_u_78.op({
						["op"] = "skinEquip",
						["weapon"] = nil,
						["skin"] = nil,
						["uid"] = nil,
						["weapon"] = p_u_79.weapon,
						["skin"] = v_u_83,
						["uid"] = v146
					})] = "equip"
				end
			end
			local _, v147 = v143(v144)
			v147.setEnabled(v_u_126.canEquip)
			return v131
		end
		local v148 = v_u_81.touch(v_u_87 and 40 or 38)
		local v149 = v_u_87 and 140 or 112
		local v150 = v_u_87 and 136 or 118
		local v151 = v149 + v150 + 36
		local v152 = v_u_80.label
		local v153 = {
			["parent"] = nil,
			["name"] = "Count",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v131,
			["text"] = v_u_126.countText
		}
		if not v_u_126.tally then
			v134 = v_u_82.text2
		end
		v153.color = v134
		v153.position = UDim2.fromOffset(46, 6)
		v153.size = UDim2.new(1, -(v151 + 46), 0, 22)
		v152(v153)
		local v154 = v_u_126.found
		if v_u_126.date ~= "" then
			v154 = v154 .. "  \194\183  " .. v_u_126.date
		end
		v_u_80.label({
			["parent"] = nil,
			["name"] = "Found",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v131,
			["text"] = v154,
			["color"] = v_u_82.text2,
			["position"] = UDim2.fromOffset(46, 28),
			["size"] = UDim2.new(1, -(v151 + 46), 0, 16)
		})
		if v_u_126.scrapWhy and not v_u_87 then
			v_u_80.label({
				["parent"] = nil,
				["name"] = "Why",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v131,
				["text"] = v_u_126.scrapWhy,
				["color"] = v_u_82.muted,
				["position"] = UDim2.fromOffset(46, 44),
				["size"] = UDim2.new(1, -(v151 + 46), 0, 12)
			})
		end
		local _, v155 = v_u_80.button({
			["parent"] = nil,
			["name"] = "Scrap",
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = nil,
			["height"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v131,
			["text"] = v_u_1.TEXT.scrap,
			["width"] = v150,
			["height"] = v148,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -10, 0.5, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_126, (ref) v_u_120
				if v_u_126.canScrap then
					v_u_120(v_u_126)
				end
			end
		})
		v155.setEnabled(v_u_126.canScrap)
		local v156 = v_u_80.button
		local v157 = {
			["parent"] = nil,
			["name"] = "Equip",
			["text"] = nil,
			["kind"] = nil,
			["width"] = nil,
			["height"] = nil,
			["anchor"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v131
		}
		local v158
		if v_u_126.equipped then
			v158 = v_u_1.TEXT.equipped
		else
			v158 = v_u_1.TEXT.equip
		end
		v157.text = v158
		v157.kind = v_u_126.equipped and "secondary" or "primary"
		v157.width = v149
		v157.height = v148
		v157.anchor = Vector2.new(1, 0.5)
		v157.position = UDim2.new(1, -(v150 + 10 + 8), 0.5, 0)
		function v157.onClick() -- name: onClick
			-- upvalues: (copy) v_u_126, (ref) p_u_78, (ref) p_u_79, (ref) v_u_83, (ref) v_u_96
			if v_u_126.canEquip then
				local v159 = v_u_126.uid
				v_u_96[p_u_78.op({
					["op"] = "skinEquip",
					["weapon"] = nil,
					["skin"] = nil,
					["uid"] = nil,
					["weapon"] = p_u_79.weapon,
					["skin"] = v_u_83,
					["uid"] = v159
				})] = "equip"
			end
		end
		local _, v160 = v156(v157)
		v160.setEnabled(v_u_126.canEquip)
		return v131
	end
	v_u_101 = function() -- name: draw
		-- upvalues: (ref) v_u_95, (ref) v_u_91, (ref) v_u_94, (copy) v_u_80, (ref) v_u_1, (copy) v_u_82, (copy) v_u_81, (copy) v_u_109, (ref) v_u_93, (ref) v_u_92, (copy) v_u_121, (copy) v_u_84, (ref) v_u_89, (ref) v_u_6, (ref) v_u_85, (copy) v_u_115, (copy) v_u_161, (ref) v_u_101, (ref) v_u_100, (copy) p_u_78, (copy) v_u_83
		local v162 = v_u_95
		if v_u_91 and (v162 ~= nil and v162.Parent) then
			for _, v163 in v162:GetChildren() do
				if v163:IsA("UIListLayout") then
					continue
				end
				v163:Destroy()
			end
			local v164 = 0
			if v_u_94 then
				local v165 = v_u_80.label
				local v166 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v162,
					["text"] = v_u_1.TEXT.failed,
					["color"] = v_u_82.text2
				}
				v164 = v164 + 1
				v166.order = v164
				v165(v166)
				local v167 = v_u_80.button
				local v168 = {
					["parent"] = nil,
					["text"] = nil,
					["kind"] = "secondary",
					["width"] = 160,
					["height"] = nil,
					["order"] = nil,
					["name"] = "Again",
					["onClick"] = nil,
					["parent"] = v162,
					["text"] = v_u_1.TEXT.again,
					["height"] = v_u_81.touch(40)
				}
				v164 = v164 + 1
				v168.order = v164
				v168.onClick = v_u_109
				v167(v168)
				return
			elseif v_u_93 == nil then
				local v169 = v_u_80.label
				local v170 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v162,
					["text"] = v_u_1.TEXT.loading,
					["color"] = v_u_82.text2
				}
				v164 = v164 + 1
				v170.order = v164
				v169(v170)
			else
				local v171 = v_u_93.total
				local v172 = #v_u_93.rows
				if type(v171) == "number" and v171 == v171 then
					v172 = v171
				end
				local v173 = math.floor(v172)
				local v_u_174 = v_u_1.pageInfo(v173, v_u_92)
				local v175
				if v_u_121 then
					v175 = v164
				else
					local v176 = v_u_80.label
					local v177 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["size"] = nil,
						["order"] = nil,
						["parent"] = v162,
						["text"] = ("%d %s  \194\183  %s"):format(v173, v173 == 1 and "copy" or "copies", v_u_84.name),
						["color"] = v_u_82.text2,
						["size"] = UDim2.new(1, 0, 0, 16)
					}
					v164 = v164 + 1
					v177.order = v164
					v176(v177)
					v175 = v164
				end
				local v178 = {
					["total"] = v173,
					["me"] = v_u_89,
					["names"] = v_u_6,
					["TallyMark"] = v_u_85
				}
				for _, v179 in v_u_1.order(v_u_93.rows) do
					v_u_115(v179.uid)
					local v180 = v_u_161
					v164 = v175 + 1
					v180(v162, v179, v178, v164)
					v175 = v164
				end
				if v_u_174.hasPrev or v_u_174.hasNext then
					local v181 = v_u_80.new
					local v182 = {
						["Name"] = "Pager",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_81.touch(44))
					}
					v164 = v175 + 1
					v182.LayoutOrder = v164
					local v183 = v181("Frame", v182, v162)
					v_u_80.layout(v183, "h", v_u_121 and 6 or 10)
					local v184 = v_u_121 and 92 or 150
					if v_u_174.hasPrev then
						v_u_80.button({
							["parent"] = nil,
							["text"] = nil,
							["kind"] = "secondary",
							["width"] = nil,
							["height"] = nil,
							["order"] = 1,
							["name"] = "Prev",
							["onClick"] = nil,
							["parent"] = v183,
							["text"] = v_u_1.TEXT.prev,
							["width"] = v184,
							["height"] = v_u_81.touch(40),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_92, (copy) v_u_174, (ref) v_u_93, (ref) v_u_101, (ref) v_u_91, (ref) v_u_100, (ref) p_u_78, (ref) v_u_83, (ref) v_u_109, (ref) v_u_94
								v_u_92 = v_u_174.prev
								v_u_93 = nil
								v_u_101()
								if v_u_91 then
									v_u_100 = v_u_100 + 1
									local v_u_185 = v_u_100
									task.spawn(function()
										-- upvalues: (ref) p_u_78, (ref) v_u_83, (ref) v_u_92, (ref) v_u_91, (copy) v_u_185, (ref) v_u_100, (ref) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
										local v186 = p_u_78.fetch
										local v187 = {
											["skin"] = v_u_83,
											["offset"] = v_u_92
										}
										local v188 = v_u_92
										v187.id = v_u_83 .. ":" .. tostring(v188)
										local v189 = v186("skinCopies", v187, 0)
										if v_u_91 and v_u_185 == v_u_100 then
											if type(v189) == "table" and v189.limited == true then
												task.delay(1.3, function()
													-- upvalues: (ref) v_u_91, (ref) v_u_185, (ref) v_u_100, (ref) v_u_109
													if v_u_91 and v_u_185 == v_u_100 then
														v_u_109()
													end
												end)
											else
												local v190
												if type(v189) == "table" then
													local v191 = v189.rows
													v190 = type(v191) ~= "table"
												else
													v190 = true
												end
												v_u_94 = v190
												if v_u_94 then
													v189 = nil
												end
												v_u_93 = v189
												v_u_101()
											end
										else
											return
										end
									end)
								end
							end
						})
					end
					v_u_80.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["order"] = 2,
						["align"] = "center",
						["parent"] = v183,
						["text"] = ("%d to %d of %d"):format(v_u_174.from, v_u_174.to, v_u_174.total),
						["color"] = v_u_82.text2,
						["size"] = UDim2.fromOffset(v_u_121 and 84 or 150, v_u_81.touch(40))
					})
					if v_u_174.hasNext then
						v_u_80.button({
							["parent"] = nil,
							["text"] = nil,
							["kind"] = "secondary",
							["width"] = nil,
							["height"] = nil,
							["order"] = 3,
							["name"] = "Next",
							["onClick"] = nil,
							["parent"] = v183,
							["text"] = v_u_1.TEXT.next,
							["width"] = v184,
							["height"] = v_u_81.touch(40),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_92, (copy) v_u_174, (ref) v_u_93, (ref) v_u_101, (ref) v_u_91, (ref) v_u_100, (ref) p_u_78, (ref) v_u_83, (ref) v_u_109, (ref) v_u_94
								v_u_92 = v_u_174.next
								v_u_93 = nil
								v_u_101()
								if v_u_91 then
									v_u_100 = v_u_100 + 1
									local v_u_192 = v_u_100
									task.spawn(function()
										-- upvalues: (ref) p_u_78, (ref) v_u_83, (ref) v_u_92, (ref) v_u_91, (copy) v_u_192, (ref) v_u_100, (ref) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
										local v193 = p_u_78.fetch
										local v194 = {
											["skin"] = v_u_83,
											["offset"] = v_u_92
										}
										local v195 = v_u_92
										v194.id = v_u_83 .. ":" .. tostring(v195)
										local v196 = v193("skinCopies", v194, 0)
										if v_u_91 and v_u_192 == v_u_100 then
											if type(v196) == "table" and v196.limited == true then
												task.delay(1.3, function()
													-- upvalues: (ref) v_u_91, (ref) v_u_192, (ref) v_u_100, (ref) v_u_109
													if v_u_91 and v_u_192 == v_u_100 then
														v_u_109()
													end
												end)
											else
												local v197
												if type(v196) == "table" then
													local v198 = v196.rows
													v197 = type(v198) ~= "table"
												else
													v197 = true
												end
												v_u_94 = v197
												if v_u_94 then
													v196 = nil
												end
												v_u_93 = v196
												v_u_101()
											end
										else
											return
										end
									end)
								end
							end
						})
					end
				end
			end
		else
			return
		end
	end
	local function v200() -- name: stopList
		-- upvalues: (ref) v_u_91, (ref) v_u_97
		v_u_91 = false
		if v_u_97 then
			local function v199()
				-- upvalues: (ref) v_u_97
				v_u_97:Disconnect()
			end
			pcall(v199)
			v_u_97 = nil
		end
	end
	if p_u_79.embed == nil then
		v_u_99 = v_u_80.modal({
			["title"] = nil,
			["width"] = 640,
			["build"] = nil,
			["onClose"] = nil,
			["buttons"] = nil,
			["title"] = ("%s  %s"):format(v_u_1.TEXT.title, string.upper(v_u_84.name)),
			["build"] = function(p201) -- name: build
				-- upvalues: (ref) v_u_95, (copy) v_u_80, (ref) v_u_101
				v_u_95 = v_u_80.new("Frame", {
					["Name"] = "CopyRows",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, p201)
				v_u_80.layout(v_u_95, "v", 8)
				v_u_101()
			end,
			["onClose"] = v200,
			["buttons"] = {
				{
					["text"] = nil,
					["kind"] = "close",
					["text"] = v_u_1.TEXT.close
				}
			}
		})
		v_u_99 = v_u_99
		if v_u_99 then
			local v202 = v_u_99.frame
		end
		v98.frame = v202
	else
		local _ = p_u_79.embed
		v_u_101()
		v98.frame = p_u_79.embed
	end
	function v98.close() -- name: close
		-- upvalues: (ref) v_u_91, (ref) v_u_97, (ref) v_u_99
		v_u_91 = false
		if v_u_97 then
			local function v203()
				-- upvalues: (ref) v_u_97
				v_u_97:Disconnect()
			end
			pcall(v203)
			v_u_97 = nil
		end
		if v_u_99 and v_u_99.close then
			local v204 = v_u_99.close
			pcall(v204)
		end
	end
	v98.reload = v_u_109
	if p_u_78.changed and p_u_78.changed.Connect then
		local _ = p_u_78.changed:Connect(function(p205, p206)
			-- upvalues: (copy) v_u_96, (copy) p_u_79, (ref) v_u_91, (ref) v_u_100, (copy) p_u_78, (copy) v_u_83, (ref) v_u_92, (copy) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
			if p205 == "result" and (type(p206) == "table" and p206.req ~= nil) then
				local v207 = v_u_96[p206.req]
				if v207 ~= nil then
					v_u_96[p206.req] = nil
					if p206.ok == true then
						local v208 = p_u_79.onChange
						if type(v208) == "function" then
							local v209 = p_u_79.onChange
							pcall(v209, v207)
						end
						if not v_u_91 then
							return
						end
						v_u_100 = v_u_100 + 1
						local v_u_210 = v_u_100
						task.spawn(function()
							-- upvalues: (ref) p_u_78, (ref) v_u_83, (ref) v_u_92, (ref) v_u_91, (copy) v_u_210, (ref) v_u_100, (ref) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
							local v211 = p_u_78.fetch
							local v212 = {
								["skin"] = v_u_83,
								["offset"] = v_u_92
							}
							local v213 = v_u_92
							v212.id = v_u_83 .. ":" .. tostring(v213)
							local v214 = v211("skinCopies", v212, 0)
							if v_u_91 and v_u_210 == v_u_100 then
								if type(v214) == "table" and v214.limited == true then
									task.delay(1.3, function()
										-- upvalues: (ref) v_u_91, (ref) v_u_210, (ref) v_u_100, (ref) v_u_109
										if v_u_91 and v_u_210 == v_u_100 then
											v_u_109()
										end
									end)
								else
									local v215
									if type(v214) == "table" then
										local v216 = v214.rows
										v215 = type(v216) ~= "table"
									else
										v215 = true
									end
									v_u_94 = v215
									if v_u_94 then
										v214 = nil
									end
									v_u_93 = v214
									v_u_101()
								end
							else
								return
							end
						end)
					end
				end
			else
				return
			end
		end)
	end
	if v_u_91 then
		v_u_100 = v_u_100 + 1
		local v_u_217 = v_u_100
		task.spawn(function()
			-- upvalues: (copy) p_u_78, (copy) v_u_83, (ref) v_u_92, (ref) v_u_91, (copy) v_u_217, (ref) v_u_100, (copy) v_u_109, (ref) v_u_94, (ref) v_u_93, (ref) v_u_101
			local v218 = p_u_78.fetch
			local v219 = {
				["skin"] = v_u_83,
				["offset"] = v_u_92
			}
			local v220 = v_u_92
			v219.id = v_u_83 .. ":" .. tostring(v220)
			local v221 = v218("skinCopies", v219, 0)
			if v_u_91 and v_u_217 == v_u_100 then
				if type(v221) == "table" and v221.limited == true then
					task.delay(1.3, function()
						-- upvalues: (ref) v_u_91, (ref) v_u_217, (ref) v_u_100, (ref) v_u_109
						if v_u_91 and v_u_217 == v_u_100 then
							v_u_109()
						end
					end)
				else
					local v222
					if type(v221) == "table" then
						local v223 = v221.rows
						v222 = type(v223) ~= "table"
					else
						v222 = true
					end
					v_u_94 = v222
					if v_u_94 then
						v221 = nil
					end
					v_u_93 = v221
					v_u_101()
				end
			else
				return
			end
		end)
	end
	return v98
end
return v_u_1