-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITouch

local v_u_36 = {
	["TILE_INSET"] = 4,
	["BAND_COMPACT"] = 19,
	["BAND_WIDE"] = 23,
	["TOUCH_REAL"] = 44,
	["minCell"] = function(p1, p2, p3) -- name: minCell
		-- upvalues: (copy) v_u_36
		if not p3 then
			return p1
		end
		local v4 = (v_u_36.TOUCH_REAL + v_u_36.TILE_INSET) / math.max(p2, 0.3)
		local v5 = math.ceil(v4)
		return math.max(p1, v5)
	end,
	["quickLayout"] = function(p6, p_u_7, p8, p9) -- name: quickLayout
		local v10 = (p6 - p_u_7 * 3) / 4
		local v_u_11 = math.floor(v10)
		local v_u_12
		if p9 and p8 > v_u_11 then
			local v13 = (p6 - p_u_7) / 2
			local v14 = math.floor(v13)
			local v15 = math.min(64, v14)
			v_u_11 = math.max(p8, v15)
			v_u_12 = 2
		else
			v_u_12 = 4
		end
		local v16 = 4 / v_u_12
		local v17 = math.ceil(v16)
		return {
			["size"] = v_u_11,
			["cols"] = v_u_12,
			["rows"] = v17,
			["height"] = v17 * v_u_11 + (v17 - 1) * p_u_7,
			["width"] = v_u_12 * v_u_11 + (v_u_12 - 1) * p_u_7,
			["pos"] = function(p18) -- name: pos
				-- upvalues: (ref) v_u_12, (ref) v_u_11, (copy) p_u_7
				local v19 = (p18 - 1) % v_u_12
				local v20 = (p18 - 1) / v_u_12
				local v21 = math.floor(v20)
				return v19 * (v_u_11 + p_u_7), v21 * (v_u_11 + p_u_7)
			end
		}
	end,
	["plusLayout"] = function(p22, p23, p24, p25, p26) -- name: plusLayout
		-- upvalues: (copy) v_u_36
		if not p22 then
			local v27 = p23 and 24 or 30
			local v28 = p24 - 4 - v27
			local v29 = p25 - 4 - v27
			return {
				["badge"] = nil,
				["hit"] = nil,
				["capReserve"] = 0,
				["badge"] = {
					["x"] = v28,
					["y"] = v29,
					["size"] = v27
				},
				["hit"] = {
					["x"] = v28,
					["y"] = v29,
					["w"] = v27,
					["h"] = v27
				}
			}
		end
		local v30
		if p23 then
			v30 = v_u_36.BAND_COMPACT
		else
			v30 = v_u_36.BAND_WIDE
		end
		local v31 = v30 - 2
		local v32 = v_u_36.TOUCH_REAL / math.max(p26, 0.3)
		local v33 = math.ceil(v32)
		local v34 = math.min(v33, p24)
		local v35 = math.min(v33, p25)
		return {
			["badge"] = {
				["x"] = nil,
				["y"] = 1,
				["size"] = nil,
				["x"] = p24 - 3 - v31,
				["size"] = v31
			},
			["hit"] = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = p24 - v34,
				["w"] = v34,
				["h"] = v35
			},
			["capReserve"] = v31 + 3 + 4
		}
	end
}
return v_u_36