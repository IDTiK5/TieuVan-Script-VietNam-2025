-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPvpHoldCard

local v_u_1 = {
	["WIDTH"] = 480,
	["PAD"] = 24,
	["TOP"] = 24,
	["TITLE"] = 32,
	["GAP"] = 8,
	["BODY"] = 15,
	["LINE"] = 20,
	["HINT"] = 12,
	["HINT_LINE"] = 16,
	["LINK_SIZES"] = { 12, 11, 10 },
	["LINK_BOX"] = 30,
	["LINK_PAD"] = 8,
	["FOOT"] = 40,
	["CHAR"] = 0.62,
	["CHAR_CAPS"] = 0.74,
	["BTN_PAD"] = 20,
	["BTN_GAP"] = 12,
	["BTN_TEXT"] = 14
}
local v_u_2 = game:GetService("ReplicatedStorage")
function v_u_1.textW(p3, p4, p5) -- name: textW
	-- upvalues: (copy) v_u_1
	local v6 = (utf8.len(p3) or #p3) * p4
	local v7
	if p5 == true then
		v7 = v_u_1.CHAR_CAPS
	else
		v7 = v_u_1.CHAR
	end
	local v8 = v6 * v7 + 2
	return math.ceil(v8)
end
local function v_u_19(p9, p10, p11, p12) -- name: modalLimits
	local v13 = p12 or {
		["l"] = 0,
		["r"] = 0,
		["t"] = 0,
		["b"] = 0
	}
	local v14 = p10 - v13.l - v13.r - 32
	local v15 = math.min(p9, v14)
	local v16 = p11 * 0.9
	local v17 = p11 - v13.t - v13.b - 16
	local v18 = math.min(v16, v17)
	return v15, math.floor(v18)
end
v_u_1.modalLimits = v_u_19
function v_u_1.layout(p20, p21, p22) -- name: layout
	-- upvalues: (copy) v_u_1, (copy) v_u_19
	local v23 = v_u_1
	local v24 = p22.width
	local v25
	if type(v24) == "number" then
		v25 = p22.width
	else
		v25 = v23.WIDTH
	end
	local v26, v27 = v_u_19(v25, p20, p21, p22.safe)
	local v28 = v26 - 2 * v23.PAD
	local v29 = p22.buttonH
	local v30 = type(v29) ~= "number" and 40 or p22.buttonH
	local v31 = p22.body
	local v32 = v23.BODY
	local v33 = (utf8.len(v31) or #v31) * v32 * 0.6
	local v34 = v28 * 0.92
	local v35 = v33 / math.max(40, v34)
	local v36 = math.ceil(v35)
	local v37 = math.max(1, v36)
	local v38 = p22.ends
	local v39 = v23.BODY
	local v40 = (utf8.len(v38) or #v38) * v39 * 0.6
	local v41 = v28 * 0.92
	local v42 = v40 / math.max(40, v41)
	local v43 = math.ceil(v42)
	local v44 = math.max(1, v43)
	local v45 = p22.hint
	local v46 = v23.HINT
	local v47 = (utf8.len(v45) or #v45) * v46 * 0.6
	local v48 = v28 * 0.92
	local v49 = v47 / math.max(40, v48)
	local v50 = math.ceil(v49)
	local v51 = math.max(1, v50)
	local v52 = v23.LINK_SIZES[#v23.LINK_SIZES]
	local v53 = false
	for _, v54 in v23.LINK_SIZES do
		if v23.textW(p22.link, v54) > v28 - 2 * v23.LINK_PAD then
			continue
		end
		v52 = v54
		v53 = true
	end
	local v55 = v23.LINK_BOX
	local v56 = math.max(v55, v30)
	local v57 = v23.TOP + v23.TITLE
	local v58 = {
		["x"] = v23.PAD,
		["y"] = v57 + v23.GAP,
		["w"] = v28,
		["h"] = v37 * v23.LINE
	}
	local v59 = v57 + (v23.GAP + v58.h)
	local v60 = {
		["x"] = v23.PAD,
		["y"] = v59 + v23.GAP,
		["w"] = v28,
		["h"] = v44 * v23.LINE
	}
	local v61 = v59 + (v23.GAP + v60.h)
	local v62 = {
		["x"] = v23.PAD,
		["y"] = v61 + v23.GAP,
		["w"] = v28,
		["h"] = v51 * v23.HINT_LINE
	}
	local v63 = v61 + (v23.GAP + v62.h)
	local v64 = {
		["x"] = v23.PAD,
		["y"] = v63 + 4,
		["w"] = v28,
		["h"] = v56
	}
	local v65 = v63 + (v56 + 4)
	local v66 = v23.FOOT + v30
	local v67 = v65 + 3 + v66
	local v68 = v27 < v67
	local v69 = math.min(v67, v27)
	local v70 = v23.textW("OPEN A TICKET", v23.BTN_TEXT, true) + 2 * v23.BTN_PAD
	local v71 = v23.textW("Close", v23.BTN_TEXT, true) + 2 * v23.BTN_PAD
	local v72 = math.max(100, v71)
	local v73 = v70 + v23.BTN_GAP + v72
	local v74 = v69 - v23.FOOT + 16 - v30
	local v75 = {
		["x"] = v26 - v23.PAD - v70,
		["y"] = v74,
		["w"] = v70,
		["h"] = v30
	}
	local v76 = {
		["x"] = v75.x - v23.BTN_GAP - v72,
		["y"] = v74,
		["w"] = v72,
		["h"] = v30
	}
	local v77 = {
		["w"] = v26,
		["h"] = v69,
		["maxH"] = v27,
		["natural"] = v67,
		["scroll"] = v68,
		["bodyH"] = v69 - v66,
		["lines"] = {
			["body"] = v37,
			["ends"] = v44,
			["hint"] = v51
		},
		["body"] = v58,
		["ends"] = v60,
		["hint"] = v62,
		["link"] = v64,
		["linkSize"] = v52,
		["linkFits"] = v53,
		["linkH"] = v56,
		["buttons"] = {
			["ticket"] = v75,
			["close"] = v76
		},
		["rowW"] = v73,
		["inner"] = v28
	}
	if v73 > v28 then
		v53 = false
	end
	v77.fits = v53
	return v77
end
local function v_u_84(p_u_78) -- name: rulesMod
	-- upvalues: (copy) v_u_2
	local v79, v80 = pcall(function()
		-- upvalues: (copy) p_u_78
		return p_u_78.cctx.shared.PvpHoldRules
	end)
	if v79 and type(v80) == "table" then
		return v80
	else
		local function v81()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("PvpHoldRules", 5)))
		end
		local v82, v83 = pcall(v81)
		if v82 and type(v83) == "table" then
			return v83
		else
			return nil
		end
	end
end
function v_u_1.deployText(p85) -- name: deployText
	if type(p85) == "table" then
		local v86 = p85.deployText
		if type(v86) == "string" and p85.deployText ~= "" then
			return p85.deployText
		end
	end
	return "PVP PAUSED"
end
function v_u_1.spec(p87, p88, p89) -- name: spec
	-- upvalues: (copy) v_u_84, (copy) v_u_1
	local v90 = v_u_84(p87)
	local v91 = v90 == nil and {} or v90.TEXT
	local v_u_92
	if type(p88) == "table" then
		local v93 = p88.ticketUrl
		if type(v93) == "string" and p88.ticketUrl ~= "" then
			v_u_92 = p88.ticketUrl
		else
			v_u_92 = v90 == nil and "" or v90.TICKET_URL
		end
	else
		v_u_92 = v90 == nil and "" or v90.TICKET_URL
	end
	local v_u_94
	if type(p89) == "table" then
		local v95 = p89.open
		if type(v95) == "function" then
			v_u_94 = p89.open
		else
			v_u_94 = nil
		end
	else
		v_u_94 = nil
	end
	local v96 = {}
	local v97
	if type(p88) == "table" and p88.title then
		v97 = p88.title
	else
		v97 = v91.TITLE
	end
	v96.title = v97
	v96.width = v_u_1.WIDTH
	local v98
	if type(p88) == "table" and p88.body then
		v98 = p88.body
	else
		v98 = v91.BODY
	end
	v96.body = v98
	local v99
	if type(p88) == "table" and p88.ends then
		v99 = p88.ends
	else
		v99 = v91.ENDS_OPEN
	end
	v96.ends = v99
	v96.hint = v91.LINK_HINT
	v96.link = v_u_92
	local v100 = {}
	local v101 = {
		["text"] = nil,
		["kind"] = "primary",
		["onClick"] = nil
	}
	local v102
	if type(p88) == "table" and p88.button then
		v102 = p88.button
	else
		v102 = v91.BUTTON
	end
	v101.text = v102
	function v101.onClick() -- name: onClick
		-- upvalues: (copy) v_u_94, (copy) v_u_92
		local function v103()
			-- upvalues: (ref) v_u_94, (ref) v_u_92
			if v_u_94 == nil then
				game:GetService("GuiService"):OpenBrowserWindow(v_u_92)
			else
				v_u_94(v_u_92)
			end
		end
		pcall(v103)
		return true
	end
	__set_list(v100, 1, {v101, {
	["text"] = nil,
	["kind"] = "secondary",
	["text"] = v91.CLOSE
}})
	v96.buttons = v100
	return v96
end
local v_u_104 = {
	["api"] = nil
}
local function v_u_115(p105, p106, p_u_107) -- name: addContent
	-- upvalues: (copy) v_u_1
	local v_u_108 = p105.ui
	local v_u_109 = p105.theme
	local v_u_110 = v_u_109.color
	v_u_108.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["size"] = nil,
		["parent"] = p106,
		["text"] = p_u_107.body,
		["color"] = v_u_110.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_108.label({
		["parent"] = nil,
		["name"] = "Ends",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["size"] = nil,
		["parent"] = p106,
		["text"] = p_u_107.ends,
		["color"] = v_u_110.text,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_108.label({
		["parent"] = nil,
		["name"] = "LinkHint",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["textSize"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["size"] = nil,
		["parent"] = p106,
		["text"] = p_u_107.hint,
		["color"] = v_u_110.muted,
		["textSize"] = v_u_1.HINT,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v_u_111 = v_u_108.new("TextBox", {
		["Name"] = "TicketLink",
		["Text"] = nil,
		["TextEditable"] = false,
		["ClearTextOnFocus"] = false,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Text"] = p_u_107.link,
		["TextSize"] = v_u_1.LINK_SIZES[1],
		["TextColor3"] = v_u_110.text2,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["BackgroundColor3"] = v_u_110.raised,
		["Size"] = UDim2.new(1, 0, 0, v_u_109.touch(v_u_1.LINK_BOX))
	}, p106)
	local function v112()
		-- upvalues: (copy) v_u_111, (copy) v_u_108, (ref) v_u_1, (copy) v_u_110
		v_u_111.Font = Enum.Font.Code
		v_u_108.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, v_u_1.LINK_PAD),
			["PaddingRight"] = UDim.new(0, v_u_1.LINK_PAD)
		}, v_u_111)
		v_u_108.stroke(v_u_111, v_u_110.line)
	end
	pcall(v112)
	local function v114()
		-- upvalues: (copy) v_u_109, (ref) v_u_1, (copy) p_u_107, (copy) v_u_111
		local v113 = v_u_109.safeRefSize()
		v_u_111.TextSize = v_u_1.layout(v113.X, v113.Y, {
			["body"] = p_u_107.body,
			["ends"] = p_u_107.ends,
			["hint"] = p_u_107.hint,
			["link"] = p_u_107.link,
			["buttonH"] = v_u_109.touch(40)
		}).linkSize
	end
	pcall(v114)
end
function v_u_1.open(p_u_116, p117, p118) -- name: open
	-- upvalues: (copy) v_u_104, (copy) v_u_1, (copy) v_u_115
	if type(p117) == "table" then
		if v_u_104.api == nil then
			local v_u_119 = v_u_1.spec(p_u_116, p117, p118)
			local function v121()
				-- upvalues: (copy) p_u_116, (copy) v_u_119, (ref) v_u_115, (ref) v_u_104
				return p_u_116.ui.modal({
					["title"] = v_u_119.title,
					["width"] = v_u_119.width,
					["build"] = function(p120) -- name: build
						-- upvalues: (ref) v_u_115, (ref) p_u_116, (ref) v_u_119
						v_u_115(p_u_116, p120, v_u_119)
					end,
					["buttons"] = v_u_119.buttons,
					["onClose"] = function() -- name: onClose
						-- upvalues: (ref) v_u_104
						v_u_104.api = nil
					end
				})
			end
			local v122, v123 = pcall(v121)
			if v122 then
				v_u_104.api = v123
				return v123
			else
				warn("[MenuPvpHoldCard] card failed:", v123)
				return nil
			end
		else
			return v_u_104.api
		end
	else
		return nil
	end
end
function v_u_1.reset() -- name: reset
	-- upvalues: (copy) v_u_104
	v_u_104.api = nil
end
return v_u_1