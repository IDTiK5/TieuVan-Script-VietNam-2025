-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmTreeSw

local v_u_137 = {
	["TEXT"] = {
		["section"] = "Skill tree  \194\183  all servers",
		["on"] = "PERKS ON",
		["off"] = "PERKS OFF",
		["default"] = "FOLLOW BUILD",
		["note"] = "All three reach every server within a minute. OFF is the emergency brake: every Perk_ attribute disappears, learning says paused, Field XP and the weapon goals keep counting. ON forces the tree on whatever the build flag says. FOLLOW BUILD gives the decision back to Config.FLAGS.SkillTree."
	},
	["lines"] = function(p1) -- name: lines
		local v2 = {}
		if type(p1) ~= "table" then
			table.insert(v2, {
				["name"] = "State",
				["text"] = "Reading the switch ...",
				["kind"] = "muted"
			})
			return v2
		end
		local v3 = p1.effective == true
		local v4 = {
			["name"] = "Effect",
			["text"] = nil,
			["kind"] = nil,
			["text"] = ("Skill tree: %s"):format(v3 and "ON, perks work" or "OFF, perks are paused"),
			["kind"] = v3 and "ok" or "warn"
		}
		table.insert(v2, v4)
		local v5 = p1.val or "default"
		local v6 = tostring(v5)
		local v7 = {
			["name"] = "Switch",
			["text"] = nil,
			["kind"] = nil,
			["text"] = ("Switch: %s  \194\183  build flag %s"):format(v6 == "default" and "follows the build flag" or (v6 == "on" and "forced ON by the switch" or (v6 == "off" and "forced OFF by the switch" or v6)), p1.flag == false and "OFF" or "ON"),
			["kind"] = v6 == "off" and "warn" or "text"
		}
		table.insert(v2, v7)
		local v8 = p1.text
		if type(v8) == "string" and p1.text ~= "" then
			local v9 = {
				["name"] = "Server",
				["text"] = nil,
				["kind"] = "muted",
				["text"] = p1.text
			}
			table.insert(v2, v9)
		end
		if p1.good ~= true and not p1.studio then
			table.insert(v2, {
				["name"] = "Good",
				["text"] = "This server has no good read of the switch yet: it follows the build flag until it reads it.",
				["kind"] = "warn"
			})
		end
		local v10 = p1.byName
		local v11 = (type(v10) ~= "string" or p1.byName == "") and "" or " by " .. p1.byName
		local v12 = {
			["name"] = "Version",
			["text"] = nil,
			["kind"] = "muted"
		}
		local v13 = p1.v
		v12.text = ("Version %d%s"):format((type(v13) ~= "number" or v13 ~= v13) and 0 or math.floor(v13), v11)
		table.insert(v2, v12)
		return v2
	end,
	["mount"] = function(p_u_14, p_u_15, p16, p17) -- name: mount
		-- upvalues: (copy) v_u_137
		local v_u_18 = require(script.Parent:WaitForChild("HushUI"))
		local v19 = game:GetService("Players")
		local v20 = game:GetService("RunService")
		local v_u_21 = v19.LocalPlayer
		local v_u_22 = type(p17) ~= "table" and {} or p17
		if type(p16) == "table" then
			local v23 = p16.color
			if type(v23) ~= "table" then
				p16 = v_u_18.Theme
			end
		else
			p16 = v_u_18.Theme
		end
		local v_u_24 = p16.color
		local v_u_25 = v_u_22.gui
		local v26 = 0
		local v_u_27 = true
		if v_u_25 then
			v_u_25.Destroying:Connect(function()
				-- upvalues: (ref) v_u_27
				v_u_27 = false
			end)
		end
		local v28 = v_u_18.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p_u_14,
			["text"] = v_u_137.TEXT.section,
			["color"] = v_u_24.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v29 = v_u_22.order
		local v30, v31
		if type(v29) == "function" then
			v30 = v_u_22.order()
			v31 = v26
		else
			v26 = v26 + 1
			v30 = v26
			v31 = v26
		end
		v28.LayoutOrder = v30
		local v_u_32 = v_u_18.new("Frame", {
			["Name"] = "TreeSwList",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p_u_14)
		v_u_18.layout(v_u_32, "v", 2)
		local v33 = v_u_22.order
		local v34
		if type(v33) == "function" then
			v34 = v_u_22.order()
		else
			v26 = v31 + 1
			v34 = v26
			v31 = v26
		end
		v_u_32.LayoutOrder = v34
		local v_u_35 = nil
		local v_u_36 = false
		local v_u_37 = (-1 / 0)
		local v_u_38 = nil
		local v_u_39 = nil
		local function v53() -- name: refresh
			-- upvalues: (ref) v_u_36, (copy) p_u_15, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_18, (ref) v_u_38, (copy) v_u_24, (ref) v_u_39, (copy) v_u_22
			local v40 = {
				["cmd"] = "status"
			}
			if not v_u_36 then
				local v41 = p_u_15
				if type(v41) ~= "function" then
					return
				end
				v_u_36 = true
				local v_u_42 = true
				local function v50(p43) -- name: done
					-- upvalues: (ref) v_u_36, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_42, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_39
					v_u_36 = false
					if v_u_27 then
						v_u_37 = os.clock()
						if type(p43) == "table" then
							local v44 = p43.data
							if type(v44) == "table" then
								v_u_35 = p43.data
							end
							if not v_u_42 then
								local v45 = p43.msg or (p43.ok and "Done." or "Refused.")
								local v46 = tostring(v45)
								local v47 = p43.ok ~= true
								v_u_18.setText(v_u_38, v46)
								local v48 = v_u_38
								local v49
								if v47 then
									v49 = v_u_24.danger
								else
									v49 = v_u_24.text2
								end
								v48.TextColor3 = v49
							end
						elseif not v_u_42 then
							v_u_18.setText(v_u_38, "The server did not answer.")
							v_u_38.TextColor3 = v_u_24.danger
						end
						v_u_39(v_u_35)
					end
				end
				local v51 = v_u_22.sendQuiet
				local v52
				if type(v51) == "function" then
					v52 = v_u_22.sendQuiet
				else
					v52 = p_u_15
				end
				v52("tree.switch", v40, v50)
			end
		end
		local v_u_54 = v_u_18.new("Frame", {
			["Name"] = "TreeSwRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 40)
		}, p_u_14)
		v_u_18.layout(v_u_54, "h", 6)
		local v55 = v_u_22.order
		local v56
		if type(v55) == "function" then
			v56 = v_u_22.order()
		else
			v26 = v31 + 1
			v56 = v26
			v31 = v26
		end
		v_u_54.LayoutOrder = v56
		local function v74(p57, p58, p59, p60, p_u_61, p62) -- name: setBtn
			-- upvalues: (copy) v_u_18, (copy) v_u_54, (ref) v_u_36, (copy) p_u_15, (ref) v_u_38, (copy) v_u_24, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (ref) v_u_39
			local v73 = v_u_18.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = nil,
				["height"] = 36,
				["width"] = nil,
				["maxTextWidth"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_54,
				["text"] = p58,
				["kind"] = p59,
				["width"] = p60,
				["maxTextWidth"] = p60 - 24,
				["onClick"] = function() -- name: onClick
					-- upvalues: (copy) p_u_61, (ref) v_u_36, (ref) p_u_15, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (ref) v_u_39
					local v63 = {
						["cmd"] = "set",
						["value"] = nil,
						["value"] = p_u_61
					}
					if not v_u_36 then
						local v64 = p_u_15
						if type(v64) ~= "function" then
							return
						end
						v_u_36 = true
						v_u_18.setText(v_u_38, "Working ...")
						v_u_38.TextColor3 = v_u_24.text2
						local v_u_65 = nil
						p_u_15("tree.switch", v63, function(p66) -- name: done
							-- upvalues: (ref) v_u_36, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_65, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_39
							v_u_36 = false
							if v_u_27 then
								v_u_37 = os.clock()
								if type(p66) == "table" then
									local v67 = p66.data
									if type(v67) == "table" then
										v_u_35 = p66.data
									end
									if not v_u_65 then
										local v68 = p66.msg or (p66.ok and "Done." or "Refused.")
										local v69 = tostring(v68)
										local v70 = p66.ok ~= true
										v_u_18.setText(v_u_38, v69)
										local v71 = v_u_38
										local v72
										if v70 then
											v72 = v_u_24.danger
										else
											v72 = v_u_24.text2
										end
										v71.TextColor3 = v72
									end
								elseif not v_u_65 then
									v_u_18.setText(v_u_38, "The server did not answer.")
									v_u_38.TextColor3 = v_u_24.danger
								end
								v_u_39(v_u_35)
							end
						end)
					end
				end
			})
			v73.Name = p57
			v73.LayoutOrder = p62
		end
		v74("TreeSwOn", v_u_137.TEXT.on, "secondary", 120, "on", 1)
		v74("TreeSwOff", v_u_137.TEXT.off, "danger", 130, "off", 2)
		v74("TreeSwDefault", v_u_137.TEXT.default, "secondary", 170, "default", 3)
		v_u_38 = v_u_18.label({
			["parent"] = nil,
			["name"] = "TreeSwStatus",
			["text"] = "Open to read.",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_14,
			["color"] = v_u_24.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v75 = v_u_22.order
		local v76
		if type(v75) == "function" then
			v76 = v_u_22.order()
		else
			v26 = v31 + 1
			v76 = v26
			v31 = v26
		end
		v_u_38.LayoutOrder = v76
		local v77 = v_u_18.label({
			["parent"] = nil,
			["name"] = "TreeSwNote",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_14,
			["text"] = v_u_137.TEXT.note,
			["color"] = v_u_24.muted,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v78 = v_u_22.order
		local v79
		if type(v78) == "function" then
			v79 = v_u_22.order()
		else
			v26 = v31 + 1
			v79 = v26
		end
		v77.LayoutOrder = v79
		v_u_39 = function(p80)
			-- upvalues: (copy) v_u_32, (ref) v_u_137, (copy) v_u_24, (copy) v_u_18, (copy) v_u_21
			for _, v81 in v_u_32:GetChildren() do
				if not v81:IsA("GuiObject") then
					continue
				end
				v81:Destroy()
			end
			for v82, v83 in v_u_137.lines(p80) do
				local v84
				if v83.kind == "ok" then
					v84 = v_u_24.success
				elseif v83.kind == "warn" then
					v84 = v_u_24.danger
				elseif v83.kind == "muted" then
					v84 = v_u_24.muted
				else
					v84 = v_u_24.text2
				end
				local v85 = v_u_18.label
				local v86 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_32
				}
				local v87 = v83.name
				v86.name = "TreeSwLine_" .. tostring(v87)
				local v88 = v83.text
				v86.text = tostring(v88)
				v86.color = v84
				v86.size = UDim2.new(1, 0, 0, 0)
				v85(v86).LayoutOrder = v82
			end
			local v89 = type(p80) ~= "table" and {} or p80
			if v_u_21 then
				local v90 = v_u_21
				local v91 = v89.val or "?"
				local v92 = tostring(v91)
				local v93 = v89.effective == true and 1 or 0
				local v94 = v89.live == nil and 0 or 1
				local v95 = v89.v or "?"
				v90:SetAttribute("FilmTreeSw", ("val=%s|eff=%d|live=%d|v=%s"):format(v92, v93, v94, (tostring(v95))))
			end
		end
		v_u_39(nil)
		if v20:IsStudio() and v_u_21 then
			local v_u_120 = v_u_21:GetAttributeChangedSignal("FilmTreeCmd"):Connect(function()
				-- upvalues: (copy) v_u_21, (ref) v_u_36, (copy) p_u_15, (copy) v_u_18, (ref) v_u_38, (copy) v_u_24, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (ref) v_u_39, (copy) v_u_22
				local v96 = v_u_21:GetAttribute("FilmTreeCmd")
				if type(v96) == "string" and v96 ~= "" then
					v_u_21:SetAttribute("FilmTreeCmd", nil)
					if v96 == "on" or (v96 == "off" or v96 == "default") then
						local v97 = {
							["cmd"] = "set",
							["value"] = nil,
							["value"] = v96
						}
						if not v_u_36 then
							local v98 = p_u_15
							if type(v98) == "function" then
								v_u_36 = true
								v_u_18.setText(v_u_38, "Working ...")
								v_u_38.TextColor3 = v_u_24.text2
								local v_u_99 = nil
								p_u_15("tree.switch", v97, function(p100) -- name: done
									-- upvalues: (ref) v_u_36, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_99, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_39
									v_u_36 = false
									if v_u_27 then
										v_u_37 = os.clock()
										if type(p100) == "table" then
											local v101 = p100.data
											if type(v101) == "table" then
												v_u_35 = p100.data
											end
											if not v_u_99 then
												local v102 = p100.msg or (p100.ok and "Done." or "Refused.")
												local v103 = tostring(v102)
												local v104 = p100.ok ~= true
												v_u_18.setText(v_u_38, v103)
												local v105 = v_u_38
												local v106
												if v104 then
													v106 = v_u_24.danger
												else
													v106 = v_u_24.text2
												end
												v105.TextColor3 = v106
											end
										elseif not v_u_99 then
											v_u_18.setText(v_u_38, "The server did not answer.")
											v_u_38.TextColor3 = v_u_24.danger
										end
										v_u_39(v_u_35)
									end
								end)
							end
						end
					elseif v96 == "refresh" then
						local v107 = {
							["cmd"] = "status"
						}
						if not v_u_36 then
							local v108 = p_u_15
							if type(v108) ~= "function" then
								return
							end
							v_u_36 = true
							local v_u_109 = true
							local function v117(p110) -- name: done
								-- upvalues: (ref) v_u_36, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_109, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_39
								v_u_36 = false
								if v_u_27 then
									v_u_37 = os.clock()
									if type(p110) == "table" then
										local v111 = p110.data
										if type(v111) == "table" then
											v_u_35 = p110.data
										end
										if not v_u_109 then
											local v112 = p110.msg or (p110.ok and "Done." or "Refused.")
											local v113 = tostring(v112)
											local v114 = p110.ok ~= true
											v_u_18.setText(v_u_38, v113)
											local v115 = v_u_38
											local v116
											if v114 then
												v116 = v_u_24.danger
											else
												v116 = v_u_24.text2
											end
											v115.TextColor3 = v116
										end
									elseif not v_u_109 then
										v_u_18.setText(v_u_38, "The server did not answer.")
										v_u_38.TextColor3 = v_u_24.danger
									end
									v_u_39(v_u_35)
								end
							end
							local v118 = v_u_22.sendQuiet
							local v119
							if type(v118) == "function" then
								v119 = v_u_22.sendQuiet
							else
								v119 = p_u_15
							end
							v119("tree.switch", v107, v117)
						end
					end
				end
			end)
			if v_u_25 then
				v_u_25.Destroying:Connect(function()
					-- upvalues: (copy) v_u_120
					v_u_120:Disconnect()
				end)
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_27, (copy) v_u_25, (copy) p_u_14, (ref) v_u_36, (ref) v_u_37, (copy) p_u_15, (ref) v_u_35, (copy) v_u_18, (ref) v_u_38, (copy) v_u_24, (ref) v_u_39, (copy) v_u_22
			local v121 = false
			while v_u_27 do
				local v122 = v_u_25 == nil or v_u_25.Enabled
				if v122 then
					v122 = p_u_14.Visible
				end
				if v122 and (not v_u_36 and (not v121 or os.clock() - v_u_37 >= 5)) then
					v_u_37 = os.clock()
					local v123 = {
						["cmd"] = "status"
					}
					if not v_u_36 then
						local v124 = p_u_15
						if type(v124) == "function" then
							v_u_36 = true
							local v_u_125 = true
							local function v133(p126) -- name: done
								-- upvalues: (ref) v_u_36, (ref) v_u_27, (ref) v_u_37, (ref) v_u_35, (copy) v_u_125, (ref) v_u_18, (ref) v_u_38, (ref) v_u_24, (ref) v_u_39
								v_u_36 = false
								if v_u_27 then
									v_u_37 = os.clock()
									if type(p126) == "table" then
										local v127 = p126.data
										if type(v127) == "table" then
											v_u_35 = p126.data
										end
										if not v_u_125 then
											local v128 = p126.msg or (p126.ok and "Done." or "Refused.")
											local v129 = tostring(v128)
											local v130 = p126.ok ~= true
											v_u_18.setText(v_u_38, v129)
											local v131 = v_u_38
											local v132
											if v130 then
												v132 = v_u_24.danger
											else
												v132 = v_u_24.text2
											end
											v131.TextColor3 = v132
										end
									elseif not v_u_125 then
										v_u_18.setText(v_u_38, "The server did not answer.")
										v_u_38.TextColor3 = v_u_24.danger
									end
									v_u_39(v_u_35)
								end
							end
							local v134 = v_u_22.sendQuiet
							local v135
							if type(v134) == "function" then
								v135 = v_u_22.sendQuiet
							else
								v135 = p_u_15
							end
							v135("tree.switch", v123, v133)
						end
					end
				end
				task.wait(0.5)
				v121 = v122
			end
		end)
		return {
			["refresh"] = v53,
			["paint"] = function(p136) -- name: paint
				-- upvalues: (ref) v_u_35, (ref) v_u_39
				v_u_35 = p136
				v_u_39(p136)
			end
		}
	end
}
return v_u_137