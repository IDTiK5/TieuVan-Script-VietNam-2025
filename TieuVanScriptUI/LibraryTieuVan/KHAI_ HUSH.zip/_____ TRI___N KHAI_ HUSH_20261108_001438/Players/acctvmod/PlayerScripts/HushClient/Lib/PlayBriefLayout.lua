-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayBriefLayout

local v_u_3 = {
	["DOCK_GAP"] = 12,
	["GAP"] = {
		["wide"] = 12,
		["compact"] = 10,
		["phone"] = 8
	},
	["PAD"] = {
		["wide"] = 16,
		["compact"] = 12,
		["phone"] = 8
	},
	["TILE_IDS"] = {
		"difficulty",
		"time",
		"kit",
		"raid"
	},
	["SECTIONS"] = {
		"map",
		"difficulty",
		"time",
		"kit",
		"raid"
	},
	["TILE_IDS_PVE"] = {
		"difficulty",
		"time",
		"kit",
		"raid",
		"mode"
	},
	["SECTIONS_PVE"] = {
		"map",
		"difficulty",
		"time",
		"kit",
		"raid",
		"mode"
	},
	["FIVE_MIN_W"] = 60,
	["CHIP_GAP"] = 6,
	["DEFAULT_TUTORIAL_CARD"] = 156,
	["touchOf"] = function(p1, p2) -- name: touchOf
		if p1 > 44 then
			return math.max(p2, p1)
		else
			return p2
		end
	end
}
local function v_u_6(p4, p5) -- name: T
	-- upvalues: (copy) v_u_3
	return v_u_3.touchOf(p4, p5)
end
function v_u_3.tileIds(p7) -- name: tileIds
	-- upvalues: (copy) v_u_3
	if p7 == true then
		return v_u_3.TILE_IDS_PVE
	else
		return v_u_3.TILE_IDS
	end
end
function v_u_3.sectionIds(p8) -- name: sectionIds
	-- upvalues: (copy) v_u_3
	if p8 == true then
		return v_u_3.SECTIONS_PVE
	else
		return v_u_3.SECTIONS
	end
end
function v_u_3.fiveFit(p9, p10) -- name: fiveFit
	-- upvalues: (copy) v_u_3
	local v11
	if v_u_3.FIVE_MIN_W <= p9 then
		v11 = math.max(44, p10) <= p9
	else
		v11 = false
	end
	return v11
end
function v_u_3.classOf(p12, p13) -- name: classOf
	return p12 >= 500 and p13 >= 700 and "wide" or (p13 >= 420 and "compact" or "phone")
end
function v_u_3.textW(p14, p15) -- name: textW
	local v16 = utf8.len(p14) or #p14
	return p15 * 0.42 * v16 + 2
end
function v_u_3.fits(p17, p18, p19, _) -- name: fits
	-- upvalues: (copy) v_u_3
	return v_u_3.textW(p17, p18) <= p19
end
function v_u_3.tileH(p20, p21) -- name: tileH
	-- upvalues: (copy) v_u_6
	if p20 == "wide" then
		return 72
	elseif p20 == "compact" then
		return v_u_6(p21, 60)
	else
		return v_u_6(p21, 52)
	end
end
function v_u_3.heights(_, p22, p23, p24) -- name: heights
	-- upvalues: (copy) v_u_3
	if p22 == "hidden" then
		return 0
	elseif p22 == "mini" then
		return v_u_3.touchOf(p23, 52) + 8 + 8
	elseif p22 == "strip" then
		return v_u_3.touchOf(p23, 52) + 8 + 6 + v_u_3.touchOf(p23, 52) + 8
	elseif p22 == "compact" then
		if p24 == true then
			return v_u_3.touchOf(p23, 60) * 3 + 16 + 162 + 8 + v_u_3.touchOf(p23, 48) + 12
		else
			return v_u_3.touchOf(p23, 60) * 2 + 8 + 162 + 8 + v_u_3.touchOf(p23, 48) + 12
		end
	else
		return p24 ~= true and 464 or v_u_3.touchOf(p23, 52) + 476 + 16
	end
end
function v_u_3.blockHeight(p25, p26, p27, p28, p29) -- name: blockHeight
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	if p27 == "hidden" then
		return 0
	else
		local v30 = p29 or {}
		if p25 == "tutorial" then
			if p27 == "card" then
				return v30.card or v_u_3.DEFAULT_TUTORIAL_CARD
			else
				return v30.row or v_u_3.touchOf(p28, 44) + 16
			end
		elseif p25 == "pass" then
			if p26 == "wide" then
				return v_u_3.touchOf(p28, 64)
			else
				return v_u_3.touchOf(p28, 56)
			end
		elseif p25 == "brief" then
			return v_u_3.heights(p26, p27, p28, v30.mode == true)
		else
			return p25 ~= "task" and (p25 == "needed" and (p26 == "wide" and 76 or 68) or 0) or (p27 == "card" and (p26 == "wide" and 92 or 78) or v_u_6(p28, 48))
		end
	end
end
function v_u_3.dockHeight(p31, p32, p33) -- name: dockHeight
	-- upvalues: (copy) v_u_3
	local v34 = p33 == false and 18 or 38
	local v35
	if p31 == "wide" then
		v35 = v_u_3.touchOf(p32, 56)
	else
		v35 = v_u_3.touchOf(p32, 44)
	end
	local v36 = p31 == "wide" and 132 or 104
	local v37 = v34 + 12 + 4 + v35 + 14
	return math.max(v36, v37)
end
function v_u_3.dockParts(p38, p39, p40, p41) -- name: dockParts
	-- upvalues: (copy) v_u_3
	local v42 = p41 ~= false
	local v43
	if p39 == "wide" then
		v43 = v_u_3.touchOf(p40, 56)
	else
		v43 = v_u_3.touchOf(p40, 44)
	end
	local v44 = v42 and 38 or 18
	local v45 = {
		["textH"] = v44,
		["dockH"] = p38
	}
	if v42 then
		v45.summary = {
			["x"] = 0,
			["y"] = 12,
			["w"] = 1,
			["h"] = 18
		}
		v45.status = {
			["x"] = 0,
			["y"] = 32,
			["w"] = 1,
			["h"] = 18
		}
	else
		v45.status = {
			["x"] = 0,
			["y"] = 12,
			["w"] = 1,
			["h"] = 18
		}
	end
	local v46 = v44 + 12 + 4
	local v47 = p38 - 14 - v43
	v45.button = {
		["x"] = 0,
		["y"] = nil,
		["w"] = 1,
		["h"] = nil,
		["y"] = math.max(v46, v47),
		["h"] = v43
	}
	return v45
end
local v_u_48 = {
	"L1",
	"L2",
	"L3",
	"L4",
	"L5",
	"L6",
	"L7",
	"L8",
	"L9"
}
local function v_u_50(p49) -- name: startDensities
	return p49 == "wide" and {
		["tutorial"] = "card",
		["pass"] = "full",
		["brief"] = "full",
		["task"] = "card",
		["needed"] = "strip"
	} or (p49 == "compact" and {
		["tutorial"] = "row",
		["pass"] = "full",
		["brief"] = "compact",
		["task"] = "card",
		["needed"] = "strip"
	} or {
		["tutorial"] = "row",
		["pass"] = "full",
		["brief"] = "strip",
		["task"] = "row",
		["needed"] = "hidden"
	})
end
local v_u_51 = {
	"tutorial",
	"pass",
	"brief",
	"task",
	"needed"
}
local function v_u_95(p52, p53, p54, p55, p56) -- name: briefInner
	-- upvalues: (copy) v_u_3
	local v57 = v_u_3.PAD[p52]
	local v58 = p54 - 2 * v57
	local v59 = {
		["density"] = p53,
		["pad"] = v57
	}
	if p53 == "hidden" then
		return v59
	end
	local v60 = {}
	if p53 == "mini" then
		local v61 = v_u_3.touchOf(p55, 52)
		v59.row = {
			["x"] = nil,
			["y"] = 8,
			["w"] = nil,
			["h"] = nil,
			["x"] = v57,
			["w"] = v58,
			["h"] = v61
		}
		v59.thumb = {
			["x"] = nil,
			["y"] = 8,
			["w"] = 72,
			["h"] = nil,
			["x"] = v57,
			["h"] = v61
		}
		v59.values = {
			["x"] = nil,
			["y"] = 8,
			["w"] = nil,
			["h"] = nil,
			["x"] = v57 + 72 + 8,
			["w"] = v58 - 72 - 8 - 28,
			["h"] = v61
		}
		v59.chevron = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 20,
			["h"] = 20,
			["x"] = v57 + v58 - 24,
			["y"] = (v61 - 20) // 2 + 8
		}
		v59.tiles = v60
		return v59
	end
	if p53 == "strip" then
		local v62 = v_u_3.touchOf(p55, 52)
		v59.header = {
			["x"] = nil,
			["y"] = 8,
			["w"] = nil,
			["h"] = nil,
			["x"] = v57,
			["w"] = v58,
			["h"] = v62
		}
		v59.thumb = {
			["x"] = nil,
			["y"] = 8,
			["w"] = 88,
			["h"] = nil,
			["x"] = v57,
			["h"] = v62
		}
		v59.setup = {
			["x"] = nil,
			["y"] = 8,
			["w"] = 84,
			["h"] = nil,
			["x"] = v57 + v58 - 84,
			["h"] = v62
		}
		if p56 == true then
			local v63 = (v58 - 24) / 5
			local v64 = math.floor(v63)
			if v_u_3.fiveFit(v64, p55) then
				for v65, v66 in v_u_3.TILE_IDS_PVE do
					local v67 = {
						["id"] = nil,
						["x"] = nil,
						["y"] = nil,
						["w"] = nil,
						["h"] = nil,
						["dense"] = true,
						["id"] = v66,
						["x"] = v57 + (v65 - 1) * (v64 + 6),
						["y"] = v62 + 8 + 6,
						["w"] = v64,
						["h"] = v62
					}
					table.insert(v60, v67)
				end
				v59.dense = true
				v59.tiles = v60
				return v59
			end
			local v68 = v_u_3.touchOf(p55, 56)
			local v69
			if v62 - 6 >= math.max(44, p55) then
				v69 = v62 - 6
			else
				v69 = v62
			end
			local v70 = v59.setup.x - v_u_3.CHIP_GAP - v68
			v59.modeChip = {
				["x"] = v70,
				["y"] = (v62 - v69) // 2 + 8,
				["w"] = v68,
				["h"] = v69
			}
			local v71 = v57 + 88 + 10
			local v72 = v70 - 4 - v71
			v59.text = {
				["x"] = nil,
				["y"] = 8,
				["w"] = nil,
				["h"] = nil,
				["x"] = v71,
				["w"] = math.max(0, v72),
				["h"] = v62
			}
			v59.mapHit = {
				["x"] = nil,
				["y"] = 8,
				["w"] = nil,
				["h"] = nil,
				["x"] = v57,
				["w"] = v70 - 4 - v57,
				["h"] = v62
			}
		end
		local v73 = (v58 - 18) / 4
		local v74 = math.floor(v73)
		for v75, v76 in v_u_3.TILE_IDS do
			local v77 = {
				["id"] = v76,
				["x"] = v57 + (v75 - 1) * (v74 + 6),
				["y"] = v62 + 8 + 6,
				["w"] = v74,
				["h"] = v62
			}
			table.insert(v60, v77)
		end
		v59.tiles = v60
		return v59
	end
	local v78 = p53 == "full"
	local v79 = v78 and 20 or 18
	local v80 = v78 and 12 or 10
	local v81 = v78 and 176 or 112
	local v82 = v78 and 72 or v_u_3.touchOf(p55, 60)
	local v83
	if v78 then
		v83 = p56 ~= true and 52 or v_u_3.touchOf(p55, 52)
	else
		v83 = v_u_3.touchOf(p55, 48)
	end
	v59.header = {
		["x"] = v57,
		["y"] = v57,
		["w"] = v58,
		["h"] = v79
	}
	local v84 = v57 + v79 + v80
	v59.art = {
		["x"] = v57,
		["y"] = v84,
		["w"] = v58,
		["h"] = v81
	}
	local v85 = v84 + (v81 + v80)
	local v86 = (v58 - 8) / 2
	local v87 = math.floor(v86)
	for v88, v89 in v_u_3.TILE_IDS do
		local v90 = (v88 - 1) % 2
		local v91 = (v88 - 1) // 2
		local v92 = {
			["id"] = v89,
			["x"] = v57 + v90 * (v87 + 8),
			["y"] = v85 + v91 * (v82 + 8),
			["w"] = v87,
			["h"] = v82
		}
		table.insert(v60, v92)
	end
	local v93
	if p56 == true then
		local v94 = {
			["id"] = "mode",
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["x"] = v57,
			["y"] = v85 + (v82 + 8) * 2,
			["w"] = v58,
			["h"] = v82
		}
		table.insert(v60, v94)
		v93 = v85 + (v82 * 3 + 16 + 8)
	else
		v93 = v85 + (v82 * 2 + 8 + 8)
	end
	v59.setup = {
		["x"] = v57,
		["y"] = v93,
		["w"] = v58,
		["h"] = v83
	}
	v59.tiles = v60
	return v59
end
v_u_3.briefInner = v_u_95
function v_u_3.solve(p96) -- name: solve
	-- upvalues: (copy) v_u_3, (copy) v_u_50, (copy) v_u_51, (copy) v_u_48, (copy) v_u_95
	local v97 = p96.colW
	local v98 = p96.colH
	local v99 = p96.dockH
	local v_u_100 = p96.touch or 44
	local v101 = p96.has or {}
	local v102 = p96.mode == true
	local v103 = v98 - v99 - v_u_3.DOCK_GAP
	local v_u_104 = p96.class or v_u_3.classOf(v97, v103)
	local v_u_105 = p96.gap or v_u_3.GAP[v_u_104]
	local v_u_106 = v_u_50(v_u_104)
	local v107 = {
		["tutorial"] = nil,
		["pass"] = nil,
		["brief"] = true,
		["task"] = nil,
		["needed"] = nil,
		["tutorial"] = v101.tutorial == true,
		["pass"] = v101.pass == true,
		["task"] = v101.task == true
	}
	local v108 = v101.needed
	v107.needed = (tonumber(v108) or 0) > 0
	if not v107.needed then
		v_u_106.needed = "hidden"
	end
	if not v107.task then
		v_u_106.task = "hidden"
	end
	if not v107.pass then
		v_u_106.pass = "hidden"
	end
	if not v107.tutorial then
		v_u_106.tutorial = "hidden"
	end
	local v_u_109 = {}
	local v110
	if v101.tutorialH then
		v110 = v101.tutorialH.card or nil
	else
		v110 = nil
	end
	v_u_109.card = v110
	v_u_109.row = v101.tutorialH and v101.tutorialH.row or nil
	v_u_109.mode = v102
	local v_u_111 = false
	local function v117() -- name: used
		-- upvalues: (ref) v_u_51, (ref) v_u_3, (copy) v_u_104, (copy) v_u_106, (copy) v_u_100, (copy) v_u_109, (copy) v_u_105
		local v112 = 0
		local v113 = 0
		for _, v114 in v_u_51 do
			local v115 = v_u_3.blockHeight(v114, v_u_104, v_u_106[v114], v_u_100, v_u_109)
			if v115 <= 0 then
				continue
			end
			v112 = v112 + v115
			v113 = v113 + 1
		end
		local v116 = v113 - 1
		return v112 + math.max(0, v116) * v_u_105
	end
	local v_u_118 = {}
	local function v121(p119) -- name: apply
		-- upvalues: (copy) v_u_106, (ref) v_u_111, (copy) v_u_118
		if p119 == "L1" and v_u_106.needed ~= "hidden" then
			v_u_106.needed = "hidden"
		elseif p119 == "L2" and v_u_106.task == "card" then
			v_u_106.task = "row"
		elseif p119 == "L3" and v_u_106.tutorial == "card" then
			v_u_106.tutorial = "row"
		elseif p119 == "L4" and v_u_106.brief == "full" then
			v_u_106.brief = "compact"
		elseif p119 == "L5" and v_u_106.pass ~= "hidden" then
			v_u_106.pass = "hidden"
		elseif p119 == "L6" and v_u_106.brief == "compact" then
			v_u_106.brief = "strip"
		elseif p119 == "L7" and v_u_106.task == "row" then
			v_u_106.task = "hidden"
		elseif p119 == "L8" and v_u_106.brief == "strip" then
			v_u_106.brief = "mini"
		else
			if p119 ~= "L9" or v_u_106.brief ~= "mini" then
				return false
			end
			v_u_106.brief = "hidden"
			v_u_111 = true
		end
		local v120 = v_u_118
		table.insert(v120, p119)
		return true
	end
	local v122 = v_u_111
	local v123 = 0
	if v103 < v117() and v123 < 40 then
		v123 = v123 + 1
		local v124 = false
		for _, v125 in v_u_48 do
			if not v121(v125) then
				continue
			end
			v124 = true
		end
		if v124 then
			break
		end
	end
	local v126 = 0
	local v127 = {}
	for _, v128 in v_u_51 do
		local v129 = v_u_3.blockHeight(v128, v_u_104, v_u_106[v128], v_u_100, v_u_109)
		if v129 <= 0 then
			continue
		end
		local v130 = {
			["id"] = nil,
			["density"] = nil,
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["id"] = v128,
			["density"] = v_u_106[v128],
			["y"] = v126,
			["w"] = v97,
			["h"] = v129
		}
		table.insert(v127, v130)
		v126 = v126 + (v129 + v_u_105)
	end
	local v131 = {
		["class"] = v_u_104,
		["budget"] = v103,
		["used"] = v117(),
		["steps"] = v_u_118,
		["blocks"] = v127,
		["gap"] = v_u_105,
		["showSummary"] = v122,
		["dock"] = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v98 - v99,
			["w"] = v97,
			["h"] = v99
		},
		["colW"] = v97,
		["colH"] = v98,
		["touch"] = v_u_100,
		["densities"] = v_u_106
	}
	if v102 then
		v131.mode = true
	end
	for _, v132 in v127 do
		if v132.id ~= "brief" then
			continue
		end
		v131.briefBlock = v132
		local v133 = v_u_95(v_u_104, v132.density, v97, v_u_100, v102)
		v131.brief = v133
		local v134 = {}
		for _, v135 in v133.tiles do
			local v136 = {
				["id"] = v135.id,
				["x"] = v135.x,
				["y"] = v132.y + v135.y,
				["w"] = v135.w,
				["h"] = v135.h,
				["dense"] = v135.dense
			}
			table.insert(v134, v136)
		end
		v131.tiles = v134
	end
	if v131.tiles == nil then
		v131.tiles = {}
	end
	return v131
end
function v_u_3.tileParts(p137, p138, p139, p140) -- name: tileParts
	local v141 = {}
	if p137 == "wide" then
		v141.icon = {
			["x"] = 12,
			["y"] = 12,
			["w"] = 20,
			["h"] = 20
		}
		v141.label = {
			["x"] = 40,
			["y"] = 8,
			["w"] = nil,
			["h"] = 16,
			["w"] = p138 - 40 - 30
		}
		v141.value = {
			["x"] = 40,
			["y"] = 24,
			["w"] = nil,
			["h"] = 26,
			["w"] = p138 - 40 - 30
		}
		v141.sub = {
			["x"] = 12,
			["y"] = 52,
			["w"] = nil,
			["h"] = 16,
			["w"] = p138 - 12 - 30
		}
		v141.chevron = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 14,
			["h"] = 14,
			["x"] = p138 - 12 - 14,
			["y"] = (p139 - 14) // 2
		}
		v141.sizes = {
			["label"] = 13,
			["value"] = 20,
			["sub"] = 12
		}
		return v141
	elseif p137 == "compact" then
		v141.label = {
			["x"] = 12,
			["y"] = 6,
			["w"] = nil,
			["h"] = 16,
			["w"] = p138 - 12 - 30
		}
		v141.value = {
			["x"] = 12,
			["y"] = 22,
			["w"] = nil,
			["h"] = 26,
			["w"] = p138 - 12 - 30
		}
		v141.chevron = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 14,
			["h"] = 14,
			["x"] = p138 - 12 - 14,
			["y"] = (p139 - 14) // 2
		}
		v141.sizes = {
			["label"] = 13,
			["value"] = 18
		}
		return v141
	elseif p140 == true then
		v141.label = {
			["x"] = 4,
			["y"] = 3,
			["w"] = nil,
			["h"] = 16,
			["w"] = p138 - 8
		}
		local v142 = p138 - 8
		local v143 = p139 - 20 - 3
		v141.value = {
			["x"] = 4,
			["y"] = 20,
			["w"] = nil,
			["h"] = nil,
			["w"] = v142,
			["h"] = math.max(20, v143)
		}
		v141.sizes = {
			["label"] = 11,
			["value"] = 13
		}
		return v141
	else
		v141.label = {
			["x"] = 8,
			["y"] = 4,
			["w"] = nil,
			["h"] = 18,
			["w"] = p138 - 16
		}
		local v144 = p138 - 16
		local v145 = p139 - 22 - 4
		v141.value = {
			["x"] = 8,
			["y"] = 22,
			["w"] = nil,
			["h"] = nil,
			["w"] = v144,
			["h"] = math.max(20, v145)
		}
		v141.sizes = {
			["label"] = 13,
			["value"] = 15
		}
		return v141
	end
end
function v_u_3.chipWidths(p146, p147, p148, p149) -- name: chipWidths
	-- upvalues: (copy) v_u_3
	local v150 = {}
	for _, v151 in p146 do
		local v152 = v_u_3.textW(v151, p147)
		local v153 = math.ceil(v152) + p148 * 2
		local v154 = math.max(v153, p149 or 0)
		table.insert(v150, v154)
	end
	return v150
end
local v_u_155 = {
	"MAP",
	"DIFFICULTY",
	"TIME",
	"KIT",
	"RAID"
}
local v_u_156 = {
	"MAP",
	"DIFFICULTY",
	"TIME",
	"KIT",
	"RAID",
	"MODE"
}
function v_u_3.sheet(p157, p158, p159, p160, p161, p162) -- name: sheet
	-- upvalues: (copy) v_u_3, (copy) v_u_156, (copy) v_u_155
	local v163 = p159 == "phone"
	local v164 = v_u_3.touchOf(p160, 44)
	local v165 = v_u_3.sectionIds(p161)
	local v166 = v_u_3.chipWidths
	local v167
	if p161 == true then
		v167 = v_u_156
	else
		v167 = v_u_155
	end
	local v168 = v166(v167, p162 or 13, 10, v164)
	local v169 = {
		["class"] = p159,
		["areaH"] = p158,
		["colW"] = p157
	}
	local v170
	if v163 then
		v170 = v_u_3.touchOf(p160, 44)
	else
		v170 = v_u_3.touchOf(p160, 40)
	end
	local v171
	if v163 then
		v171 = v_u_3.touchOf(p160, 44)
		v169.header = nil
		v169.row = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = p157,
			["h"] = v171
		}
		local v172 = 8
		local v173 = {}
		for v174, v175 in v165 do
			local v176 = {
				["id"] = nil,
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["id"] = v175,
				["x"] = v172,
				["w"] = v168[v174],
				["h"] = v171
			}
			table.insert(v173, v176)
			v172 = v172 + (v168[v174] + 4)
		end
		v169.chips = v173
		v169.close = {
			["x"] = p157 - 8 - v170,
			["y"] = (v171 - v170) // 2,
			["w"] = v170,
			["h"] = v170
		}
		v169.contentW = v172 - 4 + 8
		v169.viewport = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v169.close.x - 4,
			["h"] = v171
		}
		v169.scrolls = v169.contentW > v169.viewport.w
	else
		local v177 = p159 == "wide" and 64 or 56
		v169.header = {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = p157,
			["h"] = v177
		}
		v169.title = {
			["x"] = 16,
			["y"] = 8,
			["w"] = nil,
			["h"] = 26,
			["w"] = p157 - 16 - v170 - 24
		}
		v169.sub = {
			["x"] = 16,
			["y"] = 36,
			["w"] = nil,
			["h"] = 18,
			["w"] = p157 - 16 - v170 - 24
		}
		v169.close = {
			["x"] = p157 - 12 - v170,
			["y"] = (v177 - v170) // 2,
			["w"] = v170,
			["h"] = v170
		}
		local v178 = v_u_3.touchOf(p160, 40)
		local v179 = 12
		local v180 = {}
		for v181, v182 in v165 do
			local v183 = {
				["id"] = v182,
				["x"] = v179,
				["y"] = v177,
				["w"] = v168[v181],
				["h"] = v178
			}
			table.insert(v180, v183)
			v179 = v179 + (v168[v181] + 4)
		end
		v169.chips = v180
		v169.jump = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v177,
			["w"] = p157,
			["h"] = v178
		}
		v169.contentW = v179 - 4 + 12
		v169.viewport = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v177,
			["w"] = p157,
			["h"] = v178
		}
		v169.scrolls = p157 < v169.contentW
		v171 = v177 + v178
	end
	local v184 = p158 - v171
	local v185 = math.max(0, v184)
	v169.body = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v171,
		["w"] = p157,
		["h"] = v185
	}
	v169.cueStrip = v163 and v185 > 72 and 32 or 0
	local v186 = v169.cueStrip <= 0 and (v163 and 40 or 48) or v169.cueStrip
	v169.fadeBottom = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v171 + v185 - v186,
		["w"] = p157,
		["h"] = math.min(v186, v185)
	}
	v169.fadeTop = {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["y"] = v171,
		["w"] = p157,
		["h"] = math.min(24, v185)
	}
	local v187 = v163 and 120 or 132
	v169.cue = {
		["x"] = nil,
		["y"] = nil,
		["w"] = nil,
		["h"] = 24,
		["x"] = (p157 - v187) // 2,
		["y"] = v171 + v185 - (v169.cueStrip > 0 and 4 or 12) - 24,
		["w"] = v187
	}
	local v188 = p157 + 3
	local v189 = v185 - v169.cueStrip
	v169.bar = {
		["x"] = nil,
		["y"] = nil,
		["w"] = 6,
		["h"] = nil,
		["x"] = v188,
		["y"] = v171,
		["h"] = math.max(0, v189)
	}
	return v169
end
function v_u_3.rows(p190) -- name: rows
	local v191 = {}
	for _, v192 in p190.blocks do
		if v192.id == "tutorial" then
			table.insert(v191, { "tut_play", "tut_no" })
		elseif v192.id == "pass" then
			table.insert(v191, { "pass" })
		elseif v192.id == "brief" then
			if v192.density == "full" or v192.density == "compact" then
				table.insert(v191, { "map" })
				table.insert(v191, { "difficulty", "time" })
				table.insert(v191, { "kit", "raid" })
				if p190.mode == true then
					table.insert(v191, { "mode" })
				end
				table.insert(v191, { "setup" })
			elseif v192.density == "strip" then
				if p190.mode == true and (p190.brief ~= nil and p190.brief.modeChip ~= nil) then
					table.insert(v191, { "map", "mode" })
					table.insert(v191, {
						"difficulty",
						"time",
						"kit",
						"raid"
					})
				elseif p190.mode == true then
					table.insert(v191, { "map" })
					table.insert(v191, {
						"difficulty",
						"time",
						"kit",
						"raid",
						"mode"
					})
				else
					table.insert(v191, { "map" })
					table.insert(v191, {
						"difficulty",
						"time",
						"kit",
						"raid"
					})
				end
			else
				if v192.density ~= "mini" then
					continue
				end
				table.insert(v191, { "map" })
			end
		elseif v192.id == "task" then
			table.insert(v191, { "task" })
		else
			if v192.id ~= "needed" then
				continue
			end
			table.insert(v191, { "needed" })
		end
	end
	return v191
end
function v_u_3.padLinks(p193, p194) -- name: padLinks
	-- upvalues: (copy) v_u_3
	local v195 = v_u_3.rows(p193)
	local v196 = {}
	for v197, v198 in v195 do
		for v199, v200 in v198 do
			local v201 = {}
			if v199 > 1 then
				v201.left = v198[v199 - 1]
			end
			if v199 < #v198 then
				v201.right = v198[v199 + 1]
			end
			if v197 > 1 then
				local v202 = v195[v197 - 1]
				local v203 = math.max(v199, 1)
				local v204 = #v202
				v201.up = v202[math.min(v203, v204)]
			end
			if v197 < #v195 then
				local v205 = v195[v197 + 1]
				local v206 = math.max(v199, 1)
				local v207 = #v205
				v201.down = v205[math.min(v206, v207)]
			elseif p194 ~= false then
				v201.down = "deploy"
			end
			v196[v200] = v201
		end
	end
	if p194 ~= false then
		local v208 = v195[#v195]
		local v209 = {}
		local v210
		if v208 then
			v210 = v208[1]
		else
			v210 = nil
		end
		v209.up = v210
		v196.deploy = v209
	end
	return v196
end
function v_u_3.firstFocus(p211) -- name: firstFocus
	-- upvalues: (copy) v_u_3
	local v212 = v_u_3.rows(p211)
	return v212[1] and v212[1][1] == "tut_play" and "tut_play" or "deploy"
end
return v_u_3