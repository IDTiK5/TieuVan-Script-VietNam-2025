-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuKit

local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = {}
local function v_u_10() end
function v_u_1.bind(p_u_11) -- name: bind
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (copy) v_u_1, (copy) v_u_7, (ref) v_u_10, (copy) v_u_9
	v_u_2 = p_u_11
	v_u_3 = p_u_11.ui
	v_u_4 = p_u_11.theme
	v_u_5 = v_u_4.color
	if p_u_11.changed and p_u_11.changed.Connect then
		p_u_11.changed:Connect(function(p12, p13)
			-- upvalues: (ref) v_u_1, (ref) v_u_7, (ref) v_u_10, (ref) v_u_2, (ref) v_u_9
			if p12 == "profile" then
				local v14 = v_u_1._serverWish()
				for v15, v16 in table.clone(v_u_7) do
					if v14[v15] == true ~= v16 then
						continue
					end
					v_u_7[v15] = nil
				end
				v_u_10()
				local v17 = v_u_2.profile
				local v18
				if type(v17) == "table" then
					local v19 = v17.settings
					v18 = type(v19) == "table" and v17.settings or {}
				else
					v18 = {}
				end
				for v20, v21 in table.clone(v_u_9) do
					if v18["traderSeen_" .. v20] ~= v21 then
						continue
					end
					v_u_9[v20] = nil
				end
			elseif p12 == "result" and (type(p13) == "table" and (p13.op == "wish" and p13.ok == false)) then
				table.clear(v_u_7)
				v_u_10()
			end
		end)
	end
	local function v25()
		-- upvalues: (copy) p_u_11, (ref) v_u_2
		local v22 = p_u_11.cctx
		if v22 then
			v22 = p_u_11.cctx.lib.InvUITile
		end
		if type(v22) == "table" then
			local v23 = v22.setSellSource
			if type(v23) == "function" then
				v22.setSellSource(function()
					-- upvalues: (ref) v_u_2
					local v24 = v_u_2
					if v24 then
						v24 = v_u_2.profile
					end
					return v24
				end)
			end
		end
	end
	pcall(v25)
	local v26 = v_u_1._tipHooks
	pcall(v26, p_u_11)
end
local function v_u_31() -- name: tipText
	local v27 = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if v27 then
		v27 = v27:FindFirstChild("HushTooltip")
	end
	if v27 then
		v27 = v27:FindFirstChild("Tooltip", true)
	end
	if not (v27 and v27.Visible) then
		return "no tooltip"
	end
	local v28 = {}
	for _, v29 in v27:GetDescendants() do
		if not v29:IsA("TextLabel") or v29.Text == "" then
			continue
		end
		local v30 = v29.Text .. (v29.TextFits and "" or "[!]")
		table.insert(v28, v30)
	end
	return table.concat(v28, " | ")
end
local function v_u_51(p32, p_u_33) -- name: findInst
	local v34
	if type(p32) == "table" then
		v34 = p32.inv or nil
	else
		v34 = nil
	end
	if type(v34) ~= "table" then
		return nil
	end
	local v_u_35 = nil
	local function v_u_40(p36, p37) -- name: scan
		-- upvalues: (ref) v_u_35, (copy) p_u_33, (copy) v_u_40
		if not v_u_35 and (type(p36) == "table" and p37 <= 5) then
			for _, v38 in p36 do
				if type(v38) ~= "table" then
					continue
				end
				local v39 = v38.id
				if type(v39) ~= "string" then
					continue
				end
				if v38.uid == p_u_33 or v38.id == p_u_33 and not v_u_35 then
					v_u_35 = v38
					if v38.uid == p_u_33 then
						return
					end
				end
				v_u_40(v38.items, p37 + 1)
			end
		end
	end
	local v41 = v34.containers
	local v42 = type(v41) == "table" and (v34.containers or {}) or {}
	local v43 = v42.stash
	if type(v43) == "table" then
		v_u_40(v42.stash.items, 0)
	end
	local v44 = v_u_35
	for v45, v46 in v42 do
		if v45 == "stash" or type(v46) ~= "table" then
			continue
		end
		v_u_40(v46.items, 0)
	end
	local v47 = v34.kit
	local v48
	if type(v47) == "table" then
		v48 = v34.kit.slots or nil
	else
		v48 = nil
	end
	if type(v48) == "table" then
		local v49 = {}
		for _, v50 in v48 do
			table.insert(v49, v50)
		end
		v_u_40(v49, 0)
	end
	return v44
end
function v_u_1._tipHooks(p52) -- name: _tipHooks
	-- upvalues: (copy) v_u_1, (copy) v_u_51, (ref) v_u_2, (ref) v_u_3, (copy) v_u_31
	local v_u_53 = p52.cctx
	if v_u_53 then
		local v54 = v_u_53.command
		if type(v54) == "function" and not v_u_1._tipHooked then
			v_u_1._tipHooked = true
			v_u_53.command("tip.sell", function(p55)
				-- upvalues: (copy) v_u_53, (ref) v_u_51, (ref) v_u_2, (ref) v_u_1
				local v56 = v_u_53.lib.InvUITile
				local v57 = p55[1] or ""
				local v58 = tostring(v57)
				local v59 = v_u_51
				local v60 = v_u_2
				if v60 then
					v60 = v_u_2.profile
				end
				local v61 = v59(v60, v58)
				if not v61 and v_u_1.itemDef(v58) then
					v61 = {
						["uid"] = "",
						["id"] = nil,
						["n"] = nil,
						["id"] = v58
					}
					local v62 = p55[3]
					local v63 = tonumber(v62) or 1
					v61.n = math.max(1, v63)
				end
				if not v61 then
					return "no item " .. v58
				end
				local v64
				if p55[2] and p55[2] ~= "-" then
					v64 = p55[2]
				else
					v64 = nil
				end
				local v65 = {}
				for _, v66 in v56.sellLines(v61, {
					["here"] = v64
				}) do
					local v67 = v66[1]
					local v68 = tostring(v67)
					local v69 = v66[2]
					local v70 = v68 .. "=" .. tostring(v69)
					table.insert(v65, v70)
				end
				local v71 = v56.sellQuote(v61, nil)
				local v72 = {}
				if type(v71) == "table" then
					local v73 = v71.prices
					if type(v73) == "table" then
						for v74, v75 in v71.prices do
							local v76 = v74 .. ":" .. tostring(v75)
							table.insert(v72, v76)
						end
						table.sort(v72)
					end
				end
				local v77 = "%s %s n=%s dur=%s mods=%s ammo=%s | %s | quote best=%s prices={%s} why=%s"
				local v78 = v61.id
				local v79 = tostring(v78)
				local v80 = v61.uid
				local v81 = tostring(v80)
				local v82 = v61.n or 1
				local v83 = tostring(v82)
				local v84 = v61.dur
				local v85 = tostring(v84)
				local v86 = v61.mods
				local v87
				if type(v86) == "table" then
					v87 = next(v61.mods) ~= nil
				else
					v87 = false
				end
				local v88 = tostring(v87)
				local v89 = v61.ammo
				local v90 = tostring(v89)
				local v91 = table.concat(v65, " ; ")
				local v92
				if v71 then
					v92 = v71.best
				else
					v92 = v71
				end
				local v93 = tostring(v92)
				local v94 = table.concat(v72, ",")
				if v71 then
					v71 = v71.whyShort
				end
				return v77:format(v79, v81, v83, v85, v88, v90, v91, v93, v94, (tostring(v71)))
			end)
			v_u_53.command("sell.totals", function()
				-- upvalues: (copy) v_u_53, (ref) v_u_2
				local v95 = v_u_53.lib.InvUITile
				local v96 = v_u_2 and v_u_2.profile
				if v96 then
					v96 = v_u_2.profile.inv
				end
				if type(v96) ~= "table" then
					return "no profile"
				end
				local v97 = v_u_2.derived and v_u_2.derived() or {}
				local v98 = v95.sellStash
				local v99 = tostring(v98(v96))
				local v100 = v97.stashValue
				local v101 = tostring(v100)
				local v102 = v95.sellKit
				local v103 = tostring(v102(v96))
				local v104 = v96.value
				local v105 = tostring(v104)
				local v106 = v_u_2.profile.cash
				return ("stash sells %s (base %s) | kit sells %s (base %s) | cash %s"):format(v99, v101, v103, v105, (tostring(v106)))
			end)
			v_u_53.command("tip.show", function(p107)
				-- upvalues: (ref) v_u_3, (ref) v_u_31
				local v108 = p107[1] or ""
				local v109 = tostring(v108)
				local v110 = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
				local v111 = v_u_3
				if v111 then
					v111 = v_u_3._tipFns
				end
				if v110 and type(v111) == "table" then
					local v112 = nil
					for _, v113 in v110:GetDescendants() do
						if v113.Name ~= v109 or not v113:IsA("GuiObject") then
							continue
						end
						if v111[v113] then
							v112 = v113
						else
							for _, v114 in v113:GetDescendants() do
								if not (v114:IsA("GuiObject") and v111[v114]) then
									continue
								end
								v112 = v114
							end
						end
						if not v112 then
							continue
						end
					end
					if v112 then
						return (v_u_3.showTooltip(v112) and "shown " or "not shown ") .. v112:GetFullName() .. " :: " .. v_u_31()
					else
						return "no tooltip owner " .. v109
					end
				else
					return "no tooltips"
				end
			end)
			v_u_53.command("tip.read", function()
				-- upvalues: (ref) v_u_31
				return v_u_31()
			end)
			v_u_53.command("tip.audit", function()
				-- upvalues: (copy) v_u_53, (ref) v_u_2
				local v115 = v_u_53.lib.InvUITile
				v_u_2.invalidate("traders")
				local v116 = v_u_2.fetch("traders", nil, 0)
				local v117
				if type(v116) == "table" then
					local v118 = v116.quotes
					if type(v118) == "table" then
						v117 = v116.quotes or nil
					else
						v117 = nil
					end
				else
					v117 = nil
				end
				local v119 = v_u_2.profile
				local v120
				if type(v119) == "table" then
					local v121 = v119.inv
					if type(v121) == "table" then
						local v122 = v119.inv.containers
						if type(v122) == "table" then
							v120 = v119.inv.containers.stash or nil
						else
							v120 = nil
						end
					else
						v120 = nil
					end
				else
					v120 = nil
				end
				if v117 and type(v120) == "table" then
					local v123 = v120.items
					if type(v123) == "table" then
						local v124 = 0
						local v125 = 0
						local v126 = {}
						local v127 = {}
						for _, v128 in v120.items do
							local v129 = v117[v128.uid]
							local v130 = v115.sellQuote(v128, nil)
							v124 = v124 + 1
							local v131
							if type(v129) == "table" and (type(v130) == "table" and v129.best == v130.best) then
								local v132 = v129.price
								local v133 = tonumber(v132)
								local v134 = v130.price
								if v133 == tonumber(v134) then
									local v135 = v129.whyShort
									local v136 = tostring(v135)
									local v137 = v130.whyShort
									v131 = v136 == tostring(v137)
								else
									v131 = false
								end
							else
								v131 = false
							end
							if v131 then
								for _, v138 in { "doc", "gunner", "scrapper" } do
									local v139 = v129.prices
									if v139 then
										v139 = v129.prices[v138]
									end
									local v140 = tonumber(v139)
									local v141 = v130.prices
									if v141 then
										v141 = v130.prices[v138]
									end
									if v140 == tonumber(v141) then
										continue
									end
									v131 = false
								end
							end
							if v131 then
								v125 = v125 + 1
							elseif #v126 < 6 then
								local v142 = "%s srv=%s:%s/%s cli=%s:%s/%s"
								local v143 = v128.id
								local v144
								if v129 then
									v144 = v129.best
								else
									v144 = v129
								end
								local v145 = tostring(v144)
								local v146
								if v129 then
									v146 = v129.price
								else
									v146 = v129
								end
								local v147 = tostring(v146)
								local v148
								if v129 then
									v148 = v129.whyShort
								else
									v148 = v129
								end
								local v149 = tostring(v148)
								local v150
								if v130 then
									v150 = v130.best
								else
									v150 = v130
								end
								local v151 = tostring(v150)
								local v152
								if v130 then
									v152 = v130.price
								else
									v152 = v130
								end
								local v153 = tostring(v152)
								if v130 then
									v130 = v130.whyShort
								end
								local v154 = tostring(v130)
								table.insert(v126, v142:format(v143, v145, v147, v149, v151, v153, v154))
							end
							local v155 = v128.dur
							local v156
							if type(v155) == "number" and v128.dur < 0.999 then
								v156 = true
							else
								local v157 = v128.mods
								if type(v157) == "table" and next(v128.mods) ~= nil then
									v156 = true
								else
									local v158 = v128.n
									if (tonumber(v158) or 1) > 1 then
										v156 = true
									else
										local v159 = v128.ammo
										if type(v159) == "number" and v128.ammo > 0 then
											v156 = true
										elseif type(v129) == "table" then
											v156 = v129.best == nil
										else
											v156 = false
										end
									end
								end
							end
							if not v156 or #v127 >= 14 then
								continue
							end
							local v160 = {}
							for _, v161 in v115.sellLines(v128, nil) do
								local v162 = v161[1]
								local v163 = tostring(v162)
								local v164 = v161[2]
								local v165 = v163 .. " " .. tostring(v164)
								table.insert(v160, v165)
							end
							local v166 = "%s[%s] n=%s dur=%s mods=%s ammo=%s srv=%s:%s -> %s"
							local v167 = v128.id
							local v168 = v128.uid
							local v169 = tostring(v168)
							local v170 = string.sub(v169, 1, 6)
							local v171 = v128.n or 1
							local v172 = tostring(v171)
							local v173 = v128.dur
							local v174 = type(v173) ~= "number" and "-" or ("%.2f"):format(v128.dur)
							local v175 = v128.mods
							local v176
							if type(v175) == "table" then
								v176 = next(v128.mods) ~= nil
							else
								v176 = false
							end
							local v177 = tostring(v176)
							local v178 = v128.ammo or 0
							local v179 = tostring(v178)
							local v180
							if v129 then
								v180 = v129.best
							else
								v180 = v129
							end
							local v181 = tostring(v180)
							if v129 then
								v129 = v129.price or v129.whyShort
							end
							local v182 = tostring(v129)
							local v183 = table.concat
							table.insert(v127, v166:format(v167, v170, v172, v174, v177, v179, v181, v182, v183(v160, " / ")))
						end
						return ("stash %d, same %d, differ %d%s || %s"):format(v124, v125, v124 - v125, #v126 <= 0 and "" or " :: " .. table.concat(v126, " ; "), table.concat(v127, " || "))
					end
				end
				return "no quotes or no stash"
			end)
			return
		end
	end
end
function v_u_1.isBound() -- name: isBound
	-- upvalues: (ref) v_u_2
	return v_u_2 ~= nil
end
function v_u_1._serverWish() -- name: _serverWish
	-- upvalues: (ref) v_u_2
	local v184 = v_u_2
	if v184 then
		v184 = v_u_2.profile
	end
	if type(v184) == "table" then
		local v185 = v184.wishlist
		if type(v185) == "table" then
			return v184.wishlist
		end
	end
	return {}
end
function v_u_1.wished(p186) -- name: wished
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v187 = v_u_7[p186]
	if v187 == nil then
		return v_u_1._serverWish()[p186] == true
	else
		return v187
	end
end
function v_u_1.wishList() -- name: wishList
	-- upvalues: (copy) v_u_1, (copy) v_u_7
	local v188 = {}
	local v189 = {}
	for v190, v191 in v_u_1._serverWish() do
		if v191 ~= true or v_u_7[v190] == false then
			continue
		end
		table.insert(v188, v190)
		v189[v190] = true
	end
	for v192, v193 in v_u_7 do
		if not v193 or v189[v192] then
			continue
		end
		table.insert(v188, v192)
	end
	table.sort(v188, function(p194, p195)
		-- upvalues: (ref) v_u_1
		return v_u_1.itemName(p194) < v_u_1.itemName(p195)
	end)
	return v188
end
function v_u_1.setWish(p_u_196, p197) -- name: setWish
	-- upvalues: (ref) v_u_2, (copy) v_u_1, (copy) v_u_7, (copy) v_u_8, (ref) v_u_10, (ref) v_u_3, (ref) v_u_4
	if v_u_2 and type(p_u_196) == "string" then
		if p197 == nil then
			p197 = not v_u_1.wished(p_u_196)
		end
		v_u_7[p_u_196] = p197
		local v_u_198 = os.clock()
		v_u_8[p_u_196] = v_u_198
		task.delay(8, function()
			-- upvalues: (ref) v_u_8, (copy) p_u_196, (copy) v_u_198, (ref) v_u_7, (ref) v_u_10
			if v_u_8[p_u_196] == v_u_198 and v_u_7[p_u_196] ~= nil then
				v_u_7[p_u_196] = nil
				v_u_8[p_u_196] = nil
				v_u_10()
			end
		end)
		v_u_2.op({
			["op"] = "wish",
			["id"] = nil,
			["on"] = nil,
			["id"] = p_u_196,
			["on"] = p197
		})
		local v199 = v_u_3.sound
		local v200
		if p197 then
			v200 = v_u_4.sounds.select or v_u_4.sounds.click
		else
			v200 = v_u_4.sounds.click
		end
		v199(v200)
		v_u_10()
		if v_u_2.changed then
			v_u_2.changed:Fire("wish", p_u_196, p197)
		end
	end
end
v_u_10 = function()
	-- upvalues: (copy) v_u_6
	for v201, v202 in v_u_6 do
		if not v201.Parent then
			continue
		end
		local v203 = v202.paint
		pcall(v203)
	end
end
function v_u_1.wishStar(p204, p_u_205, p206) -- name: wishStar
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_1, (ref) v_u_4, (copy) v_u_6
	local v207 = p206 or {}
	local v208 = v207.size or 14
	local v209 = v207.hit or v208 + 10
	local v210 = v_u_3.new("TextButton", {
		["Name"] = "Wish",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["ZIndex"] = nil,
		["Selectable"] = true,
		["Size"] = UDim2.fromOffset(v209, v209),
		["Position"] = v207.position or UDim2.new(1, 0, 0, 0),
		["AnchorPoint"] = v207.anchor or Vector2.new(1, 0),
		["ZIndex"] = v207.zindex or 4
	})
	local v211 = UDim2.fromScale(0.5, 0.5)
	if v207.look and v207.look < v209 then
		v211 = UDim2.new(1, -v207.look / 2, 0, v207.look / 2)
	end
	local v_u_212 = v_u_3.icon("star", {
		["parent"] = v210,
		["size"] = v208,
		["color"] = v_u_5.muted,
		["position"] = v211,
		["anchor"] = Vector2.new(0.5, 0.5),
		["zindex"] = v207.zindex or 4
	})
	local v_u_213 = false
	local v_u_214 = v207.hoverOnly
	local function v_u_221() -- name: paint
		-- upvalues: (ref) v_u_1, (copy) p_u_205, (ref) v_u_3, (copy) v_u_212, (ref) v_u_5, (ref) v_u_213, (ref) v_u_4, (copy) v_u_214
		local v215 = v_u_1.wished(p_u_205)
		local v216 = v_u_3.setIconColor
		local v217 = v_u_212
		local v218
		if v215 then
			v218 = v_u_5.accent
		elseif v_u_213 then
			v218 = v_u_5.text
		else
			v218 = v_u_5.text2
		end
		v216(v217, v218)
		local v_u_219 = false
		local function v220()
			-- upvalues: (ref) v_u_219, (ref) v_u_4
			v_u_219 = v_u_4.isTouch()
		end
		pcall(v220)
		v_u_212.Visible = v215 or v_u_213 or (v_u_219 or v_u_214 == nil)
	end
	v_u_6[v210] = {
		["id"] = p_u_205,
		["paint"] = v_u_221
	}
	v210.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_213, (copy) v_u_221
		v_u_213 = true
		v_u_221()
	end)
	v210.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_213, (copy) v_u_221
		v_u_213 = false
		v_u_221()
	end)
	if v_u_214 then
		v_u_214.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_213, (copy) v_u_221
			v_u_213 = true
			v_u_221()
		end)
		v_u_214.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_213, (copy) v_u_221
			v_u_213 = false
			v_u_221()
		end)
	end
	v210.Activated:Connect(function()
		-- upvalues: (ref) v_u_1, (copy) p_u_205
		v_u_1.setWish(p_u_205)
	end)
	v_u_3.tooltip(v210, function()
		-- upvalues: (ref) v_u_1, (copy) p_u_205
		local v222 = v_u_1.wished(p_u_205)
		return {
			["title"] = v222 and "NEEDED" or "MARK AS NEEDED",
			["body"] = v222 and "You need this item. It shows a star in raids so you do not walk past it. Select it again to remove it from the list." or "Add it to your NEEDED list: in a raid the item and containers holding it show a star."
		}
	end)
	v_u_221()
	if p204 then
		v210.Parent = p204
	end
	return v210
end
function v_u_1.shownDesc(p223, p224) -- name: shownDesc
	-- upvalues: (ref) v_u_2
	local v225 = p223.desc
	local function v226()
		-- upvalues: (ref) v_u_2
		return v_u_2.cctx.shared.Items
	end
	local v227, v228 = pcall(v226)
	local v229
	if v227 and type(v228) == "table" then
		local v230 = v228.shownDesc
		if type(v230) == "function" then
			local v231 = v228.shownDesc
			local v232
			v232, v229 = pcall(v231, p223)
			if not v232 then
				v229 = v225
			end
		else
			v229 = v225
		end
	else
		v229 = v225
	end
	if p224 then
		local function v233()
			-- upvalues: (ref) v_u_2
			return v_u_2.cctx.lib.InvUIGunsmith
		end
		local v234, v235 = pcall(v233)
		if v234 and type(v235) == "table" then
			v229 = v235.tipBody(v229, p224)
		end
	end
	return v229
end
function v_u_1.itemDef(p236) -- name: itemDef
	-- upvalues: (ref) v_u_2
	if not (p236 and v_u_2) then
		return nil
	end
	local function v237()
		-- upvalues: (ref) v_u_2
		return v_u_2.cctx.shared.Items
	end
	local v238, v239 = pcall(v237)
	if v238 and type(v239) == "table" then
		local v240 = v239.get
		if type(v240) == "function" then
			local v241 = v239.get
			local v242, v243 = pcall(v241, p236)
			if v242 then
				return v243
			else
				return nil
			end
		end
	end
	return nil
end
function v_u_1.itemName(p244) -- name: itemName
	-- upvalues: (copy) v_u_1
	local v245 = v_u_1.itemDef(p244)
	if v245 then
		local v246 = v245.name
		if type(v246) == "string" then
			return v245.name
		end
	end
	if not p244 then
		return "-"
	end
	local v247 = string.gsub(p244, "_", " ")
	return string.upper((string.sub(v247, 1, 1))) .. string.sub(v247, 2)
end
function v_u_1.money(p248) -- name: money
	-- upvalues: (ref) v_u_3
	return "$" .. v_u_3.commas(tonumber(p248) or 0)
end
function v_u_1.clear(p249) -- name: clear
	for _, v250 in p249:GetChildren() do
		if v250:IsA("UIListLayout") or (v250:IsA("UIGridLayout") or (v250:IsA("UIPadding") or (v250:IsA("UISizeConstraint") or (v250:IsA("UIStroke") or (v250:IsA("UIGradient") or (v250:IsA("UICorner") or (v250:IsA("UIAspectRatioConstraint") or (v250:IsA("UIScale") or v250:IsA("UITableLayout"))))))))) then
			continue
		end
		v250:Destroy()
	end
end
function v_u_1.section(p251, p252, p253, p254) -- name: section
	-- upvalues: (ref) v_u_3, (ref) v_u_5
	local v255 = {
		["Name"] = "Section",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 26),
		["LayoutOrder"] = p253 or 0
	}
	local v256 = v_u_3.new("Frame", v255, p251)
	local v257 = {
		["Name"] = "Tick",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_5.accent,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.fromOffset(3, 12)
	}
	v_u_3.new("Frame", v257, v256)
	v_u_3.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v256,
		["text"] = p252,
		["color"] = v_u_5.text2,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(p254 and 0.6 or 1, -12, 1, 0)
	})
	if p254 then
		v_u_3.label({
			["parent"] = nil,
			["name"] = "Right",
			["text"] = nil,
			["style"] = "monoS",
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v256,
			["text"] = p254,
			["position"] = UDim2.fromScale(0.6, 0),
			["size"] = UDim2.new(0.4, 0, 1, 0)
		})
	end
	return v256
end
function v_u_1.stat(p258, p259, p260, p261, p262) -- name: stat
	-- upvalues: (ref) v_u_3, (ref) v_u_5
	local v263 = {
		["Name"] = "Stat",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 24),
		["LayoutOrder"] = p261 or 0
	}
	local v264 = v_u_3.new("Frame", v263, p258)
	v_u_3.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["size"] = nil,
		["parent"] = v264,
		["text"] = p259,
		["size"] = UDim2.new(0.55, 0, 1, 0)
	})
	return v264, v_u_3.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = nil,
		["style"] = "mono",
		["color"] = nil,
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v264,
		["text"] = p260,
		["color"] = p262 or v_u_5.text,
		["position"] = UDim2.fromScale(0.55, 0),
		["size"] = UDim2.new(0.45, 0, 1, 0)
	})
end
function v_u_1.empty(p265, p266, p267) -- name: empty
	-- upvalues: (ref) v_u_3, (ref) v_u_5
	local v268 = v_u_3.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = nil,
		["parent"] = p265,
		["text"] = p266,
		["color"] = v_u_5.muted,
		["order"] = p267 or 999
	})
	v268.Name = "Empty"
	return v268
end
function v_u_1.card(p269, p270) -- name: card
	-- upvalues: (ref) v_u_3, (ref) v_u_4
	local v271 = v_u_3.panel
	local v272 = {
		["parent"] = p269,
		["name"] = p270.name or "Card",
		["raised"] = p270.raised ~= false,
		["transparency"] = p270.transparency,
		["size"] = p270.size or UDim2.new(1, 0, 0, 0)
	}
	local v273
	if p270.autoY == false then
		v273 = false
	else
		v273 = p270.size == nil
	end
	v272.autoY = v273
	v272.accent = p270.accent
	v272.padding = p270.padding or v_u_4.space.m
	v272.layout = p270.layout or "v"
	v272.gap = p270.gap or v_u_4.space.s
	v272.order = p270.order
	v272.strokeColor = p270.strokeColor
	local v274, v275 = v271(v272)
	if p270.order then
		v274.LayoutOrder = p270.order
	end
	return v274, v275
end
function v_u_1.bar(p276, p277) -- name: bar
	-- upvalues: (ref) v_u_3, (ref) v_u_5
	local v278 = p277.label and 40 or 8
	local v279 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = p277.name or "Bar",
		["Size"] = p277.size or UDim2.new(1, 0, 0, v278),
		["LayoutOrder"] = p277.order or 0
	}
	local v280 = v_u_3.new("Frame", v279, p276)
	local v281, v_u_282
	if p277.label then
		v281 = v_u_3.label({
			["parent"] = v280,
			["text"] = p277.label,
			["style"] = p277.labelStyle or "bodyStrong",
			["size"] = UDim2.new(0.6, 0, 0, 20)
		})
		v_u_282 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "monoS",
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v280,
			["text"] = p277.right or "",
			["position"] = UDim2.fromScale(0.6, 0),
			["size"] = UDim2.new(0.4, 0, 0, 20)
		})
	else
		v281 = nil
		v_u_282 = nil
	end
	local v_u_283 = v_u_3.progress({
		["parent"] = v280,
		["value"] = p277.value or 0,
		["color"] = p277.color or v_u_5.accent,
		["segments"] = p277.segments,
		["ghost"] = p277.ghost,
		["ghostColor"] = p277.ghostColor,
		["size"] = UDim2.new(1, 0, 0, p277.thickness or 4),
		["position"] = UDim2.new(0, 0, 1, -(p277.thickness or 4) - (p277.label and 6 or 0))
	})
	return {
		["frame"] = v280,
		["bar"] = v_u_283,
		["left"] = v281,
		["right"] = v_u_282,
		["set"] = function(p284, p285) -- name: set
			-- upvalues: (copy) v_u_283
			v_u_283.set(p284, p285)
		end,
		["setRight"] = function(p286) -- name: setRight
			-- upvalues: (ref) v_u_282
			if v_u_282 then
				v_u_282.Text = p286
			end
		end
	}
end
local v_u_287 = nil
local v_u_288 = false
local v_u_289 = setmetatable({}, {
	["__mode"] = "k"
})
v_u_1.MODEL_DIM = 0.55
function v_u_1.cellRender(p290, p291) -- name: cellRender
	-- upvalues: (copy) v_u_289, (ref) v_u_288, (ref) v_u_287, (ref) v_u_2, (ref) v_u_3, (ref) v_u_5
	local v292 = v_u_289[p290]
	if not v292 then
		return false
	end
	if not p291 then
		local v293 = v292.vp
		v292.vp = nil
		if v293 and v292.II then
			local v294 = v292.II.release
			pcall(v294, v293)
		end
		local v_u_295 = v292.glyph
		v292.glyph = nil
		if v_u_295 then
			pcall(function()
				-- upvalues: (copy) v_u_295
				v_u_295:Destroy()
			end)
		end
		return false
	end
	if v292.vp or v292.glyph then
		return true
	end
	local v296
	if v292.model then
		if v_u_288 then
			v296 = v_u_287
		else
			v_u_288 = true
			local function v297()
				-- upvalues: (ref) v_u_2
				return v_u_2.cctx.lib.ItemIcons
			end
			local v298, v299 = pcall(v297)
			if v298 and type(v299) == "table" then
				local v300 = v299.get
				if type(v300) == "function" then
					v_u_287 = v299
				end
			end
			v296 = v_u_287
		end
	else
		v296 = nil
	end
	if v296 then
		local v301 = v296.get
		local v302 = v292.id
		local v303 = {
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["zindex"] = 2,
			["mods"] = nil,
			["parent"] = p290,
			["size"] = UDim2.new(1, -8, 1, -(v292.top + 4)),
			["position"] = UDim2.fromOffset(4, v292.top),
			["mods"] = v292.mods
		}
		local v304, v305 = pcall(v301, v302, false, v303)
		if v304 and typeof(v305) == "Instance" then
			v292.vp = v305
			v292.II = v296
			if v292.dimA then
				v305.ImageTransparency = v292.dimA
			end
			return true
		end
	end
	local v306 = v_u_3.icon
	local v307 = v292.glyphName
	local v308 = {
		["parent"] = p290
	}
	local v309 = v292.box * 0.36
	v308.size = math.floor(v309)
	local v310
	if v292.dim then
		v310 = v_u_5.muted
	else
		v310 = v_u_5.text2
	end
	v308.color = v310
	v308.position = UDim2.fromScale(0.5, 0.44)
	v308.anchor = Vector2.new(0.5, 0.5)
	local v311 = v306(v307, v308)
	v311.Name = "Glyph"
	v292.glyph = v311
	return true
end
function v_u_1.cellHasModel(p312) -- name: cellHasModel
	-- upvalues: (copy) v_u_289
	local v313 = v_u_289[p312]
	local v314
	if v313 == nil then
		v314 = false
	else
		v314 = v313.vp ~= nil
	end
	return v314
end
function v_u_1.itemCell(p315, p_u_316, p317) -- name: itemCell
	-- upvalues: (copy) v_u_1, (ref) v_u_4, (ref) v_u_5, (ref) v_u_3, (copy) v_u_289, (ref) v_u_2
	local v_u_318 = p317 or {}
	local v_u_319 = v_u_1.itemDef(p_u_316)
	local v320 = v_u_318.size or 64
	local v321 = v_u_318.w or 1
	local v322 = v_u_318.h or 1
	local v_u_323 = not v_u_319 and 1 or (v_u_319.shown or v_u_319.rarity)
	local v324 = v_u_4.isPhone and v_u_4.isPhone() and 16 or 14
	local v325 = v_u_318.onClick and "TextButton" or "Frame"
	local v326 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["ClipsDescendants"] = true,
		["Name"] = "Item_" .. p_u_316,
		["BackgroundColor3"] = v_u_5.raised,
		["Size"] = UDim2.fromOffset(v320 * v321, v320 * v322),
		["LayoutOrder"] = v_u_318.order or 0
	}
	local v327 = v_u_3.new(v325, v326, nil)
	if v_u_318.onClick then
		v327.Text = ""
		v327.AutoButtonColor = false
		v327.Activated:Connect(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_318
			v_u_3.sound(v_u_4.sounds.click)
			task.spawn(v_u_318.onClick)
		end)
	end
	local v328 = {
		["Name"] = "Tint",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_4.rarityColor(v_u_323)
	}
	local v329
	if v_u_318.dim then
		v329 = v_u_318.model == true and 0.88 or 0.95
	else
		v329 = v_u_4.alpha.rarity
	end
	v328.BackgroundTransparency = v329
	v328.Size = UDim2.fromScale(1, 1)
	local v330 = v_u_3.new("Frame", v328, v327)
	local v331 = {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new(0.35, 0)
	}
	v_u_3.new("UIGradient", v331, v330)
	local v332 = v_u_3.stroke
	local v333
	if v_u_318.dim then
		v333 = v_u_5.line
	else
		v333 = v_u_4.rarityColor(v_u_323):Lerp(v_u_5.line, 0.55)
	end
	local v_u_334 = v332(v327, v333)
	local v335 = v_u_319 and (v_u_319.category or "") or ""
	local v336 = (string.find(v335, "fire") or (string.find(p_u_316, "^pistol_") or (string.find(p_u_316, "^rifle_") or (string.find(p_u_316, "^smg_") or (string.find(p_u_316, "^shotgun_") or string.find(p_u_316, "^revolver_")))))) and "weapon" or (string.find(p_u_316, "^ammo_") and "ammo" or (string.find(p_u_316, "^med_") and "health" or ((string.find(p_u_316, "^bag_") or string.find(p_u_316, "^secure_")) and "backpack" or (string.find(p_u_316, "^key") and "door" or (string.find(p_u_316, "^val_") and "cash" or ((string.find(p_u_316, "^tape_") or string.find(p_u_316, "^quest_")) and "task" or (string.find(p_u_316, "^zombie_") and "skull" or (string.find(p_u_316, "^throw_flare") and "flare" or ((string.find(p_u_316, "^ears_") or v_u_319 and v_u_319.equip == "ears") and "headphones" or ((string.find(p_u_316, "^helmet_") or v335 == "helmet") and "helmet" or ((string.find(p_u_316, "^vest_") or v_u_319 and v_u_319.equip == "armor") and "shield" or (string.find(p_u_316, "^melee_") and "weapon" or "loot"))))))))))))
	local v_u_337 = {
		["id"] = nil,
		["mods"] = nil,
		["model"] = nil,
		["dim"] = nil,
		["dimA"] = nil,
		["glyphName"] = nil,
		["box"] = nil,
		["top"] = nil,
		["vp"] = nil,
		["glyph"] = nil,
		["id"] = p_u_316,
		["mods"] = v_u_318.mods
	}
	local v338 = not string.find(p_u_316, "^zombie_")
	if v338 then
		v338 = not v_u_318.dim or v_u_318.model == true
	end
	v_u_337.model = v338
	v_u_337.dim = v_u_318.dim == true
	local v339
	if v_u_318.dim and v_u_318.model == true then
		v339 = v_u_318.dimAlpha or v_u_1.MODEL_DIM
	else
		v339 = nil
	end
	v_u_337.dimA = v339
	v_u_337.glyphName = v336
	local v340 = v320 * v321
	local v341 = v320 * v322
	v_u_337.box = math.min(v340, v341)
	v_u_337.top = v324
	v_u_289[v327] = v_u_337
	v327.Destroying:Connect(function()
		-- upvalues: (copy) v_u_337
		local v342 = v_u_337.vp
		v_u_337.vp = nil
		v_u_337.glyph = nil
		if v342 and v_u_337.II then
			local v343 = v_u_337.II.release
			pcall(v343, v342)
		end
	end)
	if v_u_318.lazy ~= true then
		v_u_1.cellRender(v327, true)
	end
	local v344
	if v_u_319 and v_u_319.short then
		v344 = v_u_319.short
	elseif string.find(p_u_316, "^zombie_") then
		v344 = string.upper((string.sub(p_u_316, 8)))
	else
		v344 = string.upper(p_u_316)
	end
	local v345 = v_u_318.dim and v_u_318.hideName and "???" or v344
	local v346
	if #v345 >= 10 and (string.find(v345, " ", 1, true) and v320 * v322 >= 56) then
		v346 = v324 * 2
	else
		v346 = v324
	end
	local v347 = v_u_3.label
	local v348 = {
		["parent"] = nil,
		["name"] = "Short",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v327,
		["text"] = v345
	}
	local v349
	if v_u_318.dim then
		v349 = v_u_5.muted
	else
		v349 = v_u_5.text
	end
	v348.color = v349
	v348.position = UDim2.fromOffset(4, 2)
	v348.size = UDim2.new(1, -8, 0, v346)
	v347(v348)
	if v_u_318.count and v_u_318.count > 1 then
		local v350 = v_u_3.label
		local v351 = {
			["parent"] = nil,
			["name"] = "Count",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v327
		}
		local v352 = v_u_318.count
		v351.text = "x" .. tostring(v352)
		v351.color = v_u_5.text
		v351.position = UDim2.new(0, 0, 1, -(v324 + 2))
		v351.size = UDim2.new(1, -4, 0, v324)
		v350(v351)
	end
	if v_u_318.badge then
		v_u_3.badge(v_u_318.badge, v_u_318.badgeKind or "warn", {
			["parent"] = v327,
			["position"] = UDim2.new(1, -3, 1, -3),
			["anchor"] = Vector2.new(1, 1),
			["height"] = v324
		}).ZIndex = 3
	end
	if v_u_318.dim and v_u_318.model ~= true then
		v_u_3.icon("lock", {
			["parent"] = nil,
			["size"] = 12,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v327,
			["color"] = v_u_5.muted,
			["position"] = UDim2.new(1, -4, 1, -4),
			["anchor"] = Vector2.new(1, 1)
		})
	end
	if v_u_318.wish ~= false and (v_u_319 ~= nil and not (v_u_318.dim and v_u_318.hideName)) and not string.find(p_u_316, "^zombie_") then
		local v353 = v320 * math.min(v321, v322) >= 56 and 13 or 11
		local v354 = v353 + 10
		if v_u_318.onClick == nil and v_u_4.isTouch() then
			local v355 = v_u_4.touch
			v354 = math.max(v354, v355(v354))
		end
		v_u_1.wishStar(v327, p_u_316, {
			["size"] = nil,
			["hit"] = nil,
			["look"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 4,
			["hoverOnly"] = nil,
			["size"] = v353,
			["hit"] = v354,
			["look"] = v353 + 10,
			["position"] = UDim2.new(1, 1, 0, -1),
			["anchor"] = Vector2.new(1, 0),
			["hoverOnly"] = v327
		})
		local v356 = v327:FindFirstChild("Short")
		if v356 and v356:IsA("GuiObject") then
			v356.Size = UDim2.new(1, -8 - v353 - 4, 0, v346)
		end
	end
	v327.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_334, (ref) v_u_5
		v_u_334.Color = v_u_5.accent
	end)
	v327.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_334, (copy) v_u_318, (ref) v_u_5, (ref) v_u_4, (copy) v_u_323
		local v357 = v_u_334
		local v358
		if v_u_318.dim then
			v358 = v_u_5.line
		else
			v358 = v_u_4.rarityColor(v_u_323):Lerp(v_u_5.line, 0.55)
		end
		v357.Color = v358
	end)
	v_u_3.tooltip(v327, function()
		-- upvalues: (copy) v_u_318, (copy) v_u_319, (ref) v_u_4, (ref) v_u_2, (copy) p_u_316, (ref) v_u_1
		if v_u_318.tooltip then
			return v_u_318.tooltip()
		end
		if v_u_318.dim and v_u_318.hideName then
			return {
				["title"] = "UNKNOWN",
				["body"] = "Find it in a raid to fill this entry."
			}
		end
		local v359 = {}
		if v_u_319 then
			local v360 = {
				["label"] = "Rarity",
				["value"] = nil,
				["color"] = nil
			}
			local v361 = v_u_4.rarityName
			local v362 = v_u_319.shown or (v_u_319.rarity or 1)
			v360.value = v361[math.clamp(v362, 1, 6)]
			v360.color = v_u_4.rarityColor(v_u_319.shown or v_u_319.rarity)
			table.insert(v359, v360)
			local v363 = {
				["label"] = "Size",
				["value"] = nil,
				["value"] = ("%dx%d"):format(v_u_319.w or 1, v_u_319.h or 1)
			}
			table.insert(v359, v363)
			if v_u_319.value then
				local function v364()
					-- upvalues: (ref) v_u_2
					return v_u_2.cctx.lib.InvUITile
				end
				local v365, v366 = pcall(v364)
				if v365 and (type(v366) == "table" and v366.sellLines) then
					local v367 = v366.sellLines
					local v368 = {
						["uid"] = "",
						["id"] = nil,
						["n"] = nil,
						["id"] = p_u_316
					}
					local v369 = v_u_318.count
					local v370 = tonumber(v369) or 1
					local v371 = math.floor(v370)
					v368.n = math.max(1, v371)
					local v372, v373 = pcall(v367, v368)
					if v372 and type(v373) == "table" then
						for _, v374 in v373 do
							local v375 = {
								["label"] = v374[1],
								["value"] = v374[2],
								["color"] = v374[3],
								["wide"] = v374.wide
							}
							table.insert(v359, v375)
						end
					end
				end
			end
			if v_u_319.weight then
				local v376 = {
					["label"] = "Weight",
					["value"] = nil,
					["value"] = ("%.1f kg"):format(v_u_319.weight)
				}
				table.insert(v359, v376)
			end
			if v_u_319.category == "ammo" then
				local function v377()
					-- upvalues: (ref) v_u_2
					return v_u_2.cctx.lib.InvUITile
				end
				local v378, v379 = pcall(v377)
				if v378 and (type(v379) == "table" and v379.ammoLines) then
					local v380 = v379.ammoLines
					local v381 = v_u_319
					local v382, v383 = pcall(v380, v381)
					if v382 and type(v383) == "table" then
						for _, v384 in v383 do
							local v385 = {
								["label"] = v384[1],
								["value"] = v384[2],
								["color"] = v384[3]
							}
							table.insert(v359, v385)
						end
					end
				end
			end
		end
		local v386 = {
			["title"] = v_u_1.itemName(p_u_316)
		}
		local v387
		if v_u_319 then
			v387 = v_u_1.shownDesc(v_u_319, p_u_316)
		else
			v387 = nil
		end
		v386.body = v387
		v386.lines = v359
		return v386
	end)
	if p315 then
		v327.Parent = p315
	end
	return v327
end
local function v_u_397(p388, p389, p390, p391, p392, p393, p394) -- name: blob
	-- upvalues: (ref) v_u_3
	local v395 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["ZIndex"] = nil,
		["BackgroundColor3"] = p389,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = p390,
		["Size"] = p391,
		["Rotation"] = p393 or 0,
		["ZIndex"] = p394 or 2
	}
	local v396 = v_u_3.new("Frame", v395, p388)
	if p392 then
		v_u_3.corner(v396, 999)
	end
	return v396
end
function v_u_1.portrait(p398, p399, p400, p401) -- name: portrait
	-- upvalues: (ref) v_u_5, (ref) v_u_3, (copy) v_u_397
	local v402 = {
		["Name"] = "Portrait",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_5.bgDeep or v_u_5.bg,
		["Size"] = UDim2.fromOffset(p401, p401)
	}
	local v403 = v_u_3.new("Frame", v402, p398)
	v_u_3.stroke(v403, v_u_5.line)
	local v404 = {
		["Name"] = "Glow",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 1,
		["BackgroundColor3"] = p400,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v405 = v_u_3.new("Frame", v404, v403)
	local v406 = {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.95), NumberSequenceKeypoint.new(0.45, 0.55), NumberSequenceKeypoint.new(1, 0.9) })
	}
	v_u_3.new("UIGradient", v406, v405)
	local v407 = Color3.fromHex("#07090C")
	local v408 = p400:Lerp(Color3.new(1, 1, 1), 0.2)
	v_u_397(v_u_397(v403, v408, UDim2.fromScale(0.5, 0.98), UDim2.fromScale(0.86, 0.5), true), v407, UDim2.fromScale(0.5, 0.52), UDim2.new(1, -3, 1, -2), true)
	local v409 = UDim2.fromScale(0.5, 0.64)
	local v410 = UDim2.fromScale(0.16, 0.14)
	local v411 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 0,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v407,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = v409,
		["Size"] = v410
	}
	v_u_3.new("Frame", v411, v403)
	v_u_397(v_u_397(v403, v408, UDim2.fromScale(0.5, 0.44), UDim2.fromScale(0.3, 0.36), true, 0, 3), v407, UDim2.fromScale(0.5, 0.52), UDim2.new(1, -3, 1, -2), true, 0, 3)
	if p399 == "doc" then
		v_u_397(v403, Color3.fromHex("#8FA3A8"), UDim2.fromScale(0.5, 0.52), UDim2.fromScale(0.22, 0.09), true, 0, 4)
		local v412 = Color3.fromHex("#5F6873")
		local v413 = UDim2.fromScale(0.38, 0.84)
		local v414 = UDim2.fromScale(0.02, 0.2)
		local v415 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 20,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v412,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v413,
			["Size"] = v414
		}
		v_u_3.new("Frame", v415, v403)
		local v416 = Color3.fromHex("#5F6873")
		local v417 = UDim2.fromScale(0.62, 0.84)
		local v418 = UDim2.fromScale(0.02, 0.2)
		local v419 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -20,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v416,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v417,
			["Size"] = v418
		}
		v_u_3.new("Frame", v419, v403)
		v_u_397(v403, Color3.fromHex("#8FA3A8"), UDim2.fromScale(0.5, 0.94), UDim2.fromScale(0.06, 0.06), true, 0, 4)
	elseif p399 == "gunner" then
		local v420 = UDim2.fromScale(0.54, 0.3)
		local v421 = UDim2.fromScale(0.42, 0.05)
		local v422 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -4,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v407,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v420,
			["Size"] = v421
		}
		v_u_3.new("Frame", v422, v403)
		local v423 = UDim2.fromScale(0.5, 0.86)
		local v424 = UDim2.fromScale(0.95, 0.045)
		local v425 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -24,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v423,
			["Size"] = v424
		}
		v_u_3.new("Frame", v425, v403)
		local v426 = UDim2.fromScale(0.5, 0.86)
		local v427 = UDim2.fromScale(0.93, 0.025)
		local v428 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -24,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v407,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v426,
			["Size"] = v427
		}
		v_u_3.new("Frame", v428, v403)
	elseif p399 == "gunsmith" then
		local v429 = UDim2.fromScale(0.5, 0.31)
		local v430 = UDim2.fromScale(0.3, 0.04)
		local v431 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 0,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v429,
			["Size"] = v430
		}
		v_u_3.new("Frame", v431, v403)
		v_u_397(v403, p400, UDim2.fromScale(0.43, 0.29), UDim2.fromScale(0.09, 0.06), true, 0, 5)
		v_u_397(v403, p400, UDim2.fromScale(0.57, 0.29), UDim2.fromScale(0.09, 0.06), true, 0, 5)
		local v432 = UDim2.fromScale(0.38, 0.84)
		local v433 = UDim2.fromScale(0.035, 0.3)
		local v434 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 22,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v432,
			["Size"] = v433
		}
		v_u_3.new("Frame", v434, v403)
		local v435 = UDim2.fromScale(0.62, 0.84)
		local v436 = UDim2.fromScale(0.035, 0.3)
		local v437 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -22,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v435,
			["Size"] = v436
		}
		v_u_3.new("Frame", v437, v403)
		local v438 = UDim2.fromScale(0.82, 0.64)
		local v439 = UDim2.fromScale(0.06, 0.5)
		local v440 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 0,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v438,
			["Size"] = v439
		}
		v_u_3.new("Frame", v440, v403)
		local v441 = UDim2.fromScale(0.82, 0.64)
		local v442 = UDim2.fromScale(0.03, 0.46)
		local v443 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 0,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v407,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v441,
			["Size"] = v442
		}
		v_u_3.new("Frame", v443, v403)
		local v444 = UDim2.fromScale(0.82, 0.38)
		local v445 = UDim2.fromScale(0.09, 0.035)
		local v446 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 0,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v408,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v444,
			["Size"] = v445
		}
		v_u_3.new("Frame", v446, v403)
	else
		v_u_397(v403, v408, UDim2.fromScale(0.5, 0.4), UDim2.fromScale(0.42, 0.44), true, 0, 2)
		v_u_397(v403, v407, UDim2.fromScale(0.5, 0.41), UDim2.fromScale(0.39, 0.41), true, 0, 2)
		v_u_397(v403, p400, UDim2.fromScale(0.43, 0.43), UDim2.fromScale(0.08, 0.05), true, 0, 5)
		v_u_397(v403, p400, UDim2.fromScale(0.57, 0.43), UDim2.fromScale(0.08, 0.05), true, 0, 5)
	end
	for v447 = 1, 6 do
		local v448 = {
			["Name"] = "Scan",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.82,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["BackgroundColor3"] = Color3.new(0, 0, 0),
			["Position"] = UDim2.fromScale(0, v447 / 7),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		v_u_3.new("Frame", v448, v403)
	end
	return v403
end
function v_u_1.mic(p449, p450, p451) -- name: mic
	-- upvalues: (ref) v_u_3
	local v452 = {
		["Name"] = "Mic",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(p450, p450)
	}
	local v453 = v_u_3.new("Frame", v452, p449)
	local v454 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.06),
		["Size"] = UDim2.fromScale(0.36, 0.56)
	}
	local v455 = v_u_3.new("Frame", v454, v453)
	v_u_3.corner(v455, 999)
	v_u_3.stroke(v455, p451, 1.5)
	local v456 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.3),
		["Size"] = UDim2.fromScale(0.62, 0.46)
	}
	local v457 = v_u_3.new("Frame", v456, v453)
	v_u_3.corner(v457, 999)
	local v458 = v_u_3.stroke(v457, p451, 1.5)
	v458.Transparency = 0
	local v459 = {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.49, 1),
			NumberSequenceKeypoint.new(0.5, 0),
			NumberSequenceKeypoint.new(1, 0)
		})
	}
	v_u_3.new("UIGradient", v459, v458)
	local v460 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = p451,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.76),
		["Size"] = UDim2.new(0, 2, 0.14, 0)
	}
	v_u_3.new("Frame", v460, v453)
	local v461 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = p451,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.9),
		["Size"] = UDim2.new(0.4, 0, 0, 2)
	}
	v_u_3.new("Frame", v461, v453)
	return v453
end
function v_u_1.offerLocked(p462, p463) -- name: offerLocked
	-- upvalues: (ref) v_u_2
	local v464 = v_u_2
	if v464 then
		v464 = v_u_2.profile
	end
	local v465
	if type(v464) == "table" then
		local v466 = v464.derived
		v465 = type(v466) == "table" and (v464.derived or {}) or {}
	else
		v465 = {}
	end
	local v467 = v465.traderLevels
	local v468
	if type(v467) == "table" then
		local v469 = v465.traderLevels[p462]
		v468 = tonumber(v469) or 1
	else
		v468 = 1
	end
	local v470 = p463.lvl
	if (v468 or 1) < (tonumber(v470) or 1) then
		return true
	end
	if p463.task then
		local v471
		if type(v464) == "table" then
			local v472 = v464.tasks
			v471 = type(v472) == "table" and (v464.tasks or {}) or {}
		else
			v471 = {}
		end
		local v473 = v471.done
		if not (type(v473) == "table" and (v471.done or {}) or {})[p463.task] then
			return true
		end
	end
	return false
end
function v_u_1.newOffers(p474) -- name: newOffers
	-- upvalues: (ref) v_u_2, (copy) v_u_9, (copy) v_u_1
	local v475 = {}
	local v_u_476 = nil
	local function v477()
		-- upvalues: (ref) v_u_476, (ref) v_u_2
		v_u_476 = v_u_2.cctx.shared.Traders
	end
	pcall(v477)
	local v478 = v_u_476
	local v479 = v478 and v478.defs
	if v479 then
		v479 = v478.defs[p474]
	end
	local v480 = v_u_9[p474]
	if not v480 then
		local v481 = v_u_2
		if v481 then
			v481 = v_u_2.profile
		end
		if type(v481) == "table" then
			local v482 = v481.settings
			if type(v482) == "table" then
				v480 = v481.settings or nil
			else
				v480 = nil
			end
		else
			v480 = nil
		end
		if v480 then
			v480 = v480["traderSeen_" .. p474]
		end
		if type(v480) ~= "string" then
			v480 = nil
		end
	end
	if v479 and v480 then
		local v483 = v_u_2.profile
		if type(v483) == "table" then
			local v484 = {}
			for v485 in string.gmatch(v480, "[^,]+") do
				v484[v485] = true
			end
			local v486 = 0
			for _, v487 in v479.offers do
				if not v484[v487.key] or v_u_1.offerLocked(p474, v487) then
					continue
				end
				v475[v487.key] = true
				v486 = v486 + 1
			end
			return v475, v486
		end
	end
	return v475, 0
end
function v_u_1.markOffersSeen(p488) -- name: markOffersSeen
	-- upvalues: (ref) v_u_2, (copy) v_u_1, (copy) v_u_9
	local v_u_489 = nil
	local function v490()
		-- upvalues: (ref) v_u_489, (ref) v_u_2
		v_u_489 = v_u_2.cctx.shared.Traders
	end
	pcall(v490)
	local v491 = v_u_489
	local v492 = v491 and v491.defs
	if v492 then
		v492 = v491.defs[p488]
	end
	local v493 = v_u_2
	if v493 then
		v493 = v_u_2.profile
	end
	if v492 and type(v493) == "table" then
		local v494 = v493.derived
		if type(v494) == "table" then
			local v495 = v493.derived.traderLevels
			if type(v495) == "table" then
				local v496 = {}
				for _, v497 in v492.offers do
					if not v_u_1.offerLocked(p488, v497) or string.find(v497.key, "[^%w_]") then
						continue
					end
					local v498 = v497.key
					table.insert(v496, v498)
				end
				local v499 = table.concat(v496, ",")
				local v500 = v_u_9[p488]
				if not v500 then
					local v501 = v_u_2
					if v501 then
						v501 = v_u_2.profile
					end
					if type(v501) == "table" then
						local v502 = v501.settings
						if type(v502) == "table" then
							v500 = v501.settings or nil
						else
							v500 = nil
						end
					else
						v500 = nil
					end
					if v500 then
						v500 = v500["traderSeen_" .. p488]
					end
					if type(v500) ~= "string" then
						v500 = nil
					end
				end
				if v499 == v500 then
					return false
				end
				v_u_9[p488] = v499
				v_u_2.op({
					["op"] = "setting",
					["key"] = nil,
					["value"] = nil,
					["key"] = "traderSeen_" .. p488,
					["value"] = v499
				})
				return true
			end
		end
	end
	return false
end
function v_u_1.newOffersTotal() -- name: newOffersTotal
	-- upvalues: (ref) v_u_2, (copy) v_u_1
	local v_u_503 = nil
	local function v504()
		-- upvalues: (ref) v_u_503, (ref) v_u_2
		v_u_503 = v_u_2.cctx.shared.Traders
	end
	pcall(v504)
	local v505 = v_u_503
	local v506 = 0
	for _, v507 in v505 and v505.ORDER or {} do
		local _, v508 = v_u_1.newOffers(v507)
		v506 = v506 + v508
	end
	return v506
end
return v_u_1