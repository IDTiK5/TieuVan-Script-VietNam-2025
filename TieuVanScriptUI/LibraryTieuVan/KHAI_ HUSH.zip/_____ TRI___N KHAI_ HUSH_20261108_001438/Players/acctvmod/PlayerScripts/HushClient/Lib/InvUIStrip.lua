-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIStrip

game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v1 = script.Parent
local v_u_2 = require(v1:WaitForChild("HushUI"))
local v_u_3 = require(v1:WaitForChild("InvUISilhouette"))
local v_u_145 = {
	["PAD"] = 4,
	["GAP"] = 4,
	["size"] = function(p4, p5, p6) -- name: size
		if p6 == "row" then
			return p4 * p5 + (p4 - 1) * 4 + 8, p5 + 8 + 2
		end
		local v7 = p4 / 2
		local v8 = math.ceil(v7)
		return p5 * 2 + 4 + 8, v8 * p5 + (v8 - 1) * 4 + 8 + 2
	end,
	["place"] = function(p9, p10, p11, p12, p13) -- name: place
		-- upvalues: (copy) v_u_2, (copy) v_u_145
		local v14 = v_u_2.safeInsets
		local v15, v16 = pcall(v14)
		local v17, v18, v19, v20
		if v15 and type(v16) == "table" then
			local v21 = v16.l
			local v22 = tonumber(v21) or 0
			local v23 = v16.t
			local v24 = tonumber(v23) or 0
			local v25 = v16.r
			local v26 = tonumber(v25) or 0
			local v27 = v16.b
			local v28 = tonumber(v27) or 0
			v17 = 8 + v22
			v18 = 8 + v24
			v19 = 8 + v22 + v26
			v20 = 8 + v24 + v28
		else
			v17 = 8
			v18 = 8
			v19 = 8
			v20 = 8
		end
		local v29 = (p11[1] + p11[3]) / 2
		local v30 = (p11[2] + p11[4]) / 2
		local v31 = v18
		local v32 = v17
		local v33 = (1 / 0)
		local v34 = "row"
		for _, v35 in { "row", "col" } do
			local v36, v37 = v_u_145.size(p9, p10, v35)
			local v38 = {}
			if v35 == "row" then
				for _, v39 in { v29 - v36 / 2, p11[1], p11[3] - v36 } do
					for _, v40 in {
						p11[2] - v37 - 6,
						p11[4] + 6,
						v18,
						p13.Y - v37 - v20
					} do
						table.insert(v38, { v39, v40 })
					end
				end
			else
				for _, v41 in { v30 - v37 / 2, p11[2], p11[4] - v37 } do
					for _, v42 in {
						p11[1] - v36 - 6,
						p11[3] + 6,
						v17,
						p13.X - v36 - v19
					} do
						table.insert(v38, { v42, v41 })
					end
				end
			end
			for _, v43 in v38 do
				local v44 = v43[1]
				local v45 = p13.X - v36 - v19
				local v46 = math.max(v17, v45)
				local v47 = math.clamp(v44, v17, v46)
				local v48 = v43[2]
				local v49 = p13.Y - v37 - v20
				local v50 = math.max(v18, v49)
				local v51 = math.clamp(v48, v18, v50)
				local v52 = {
					v47,
					v51,
					v47 + v36,
					v51 + v37
				}
				local v53 = v52[3]
				local v54 = p11[3]
				local v55 = math.min(v53, v54)
				local v56 = v52[1]
				local v57 = p11[1]
				local v58 = v55 - math.max(v56, v57)
				local v59 = v52[4]
				local v60 = p11[4]
				local v61 = math.min(v59, v60)
				local v62 = v52[2]
				local v63 = p11[2]
				local v64 = v61 - math.max(v62, v63)
				local v65 = ((v58 <= 0 or v64 <= 0) and 0 or v58 * v64) * 3
				for _, v66 in p12 do
					local v67 = v66.r
					local v68 = v52[3]
					local v69 = v67[3]
					local v70 = math.min(v68, v69)
					local v71 = v52[1]
					local v72 = v67[1]
					local v73 = v70 - math.max(v71, v72)
					local v74 = v52[4]
					local v75 = v67[4]
					local v76 = math.min(v74, v75)
					local v77 = v52[2]
					local v78 = v67[2]
					local v79 = v76 - math.max(v77, v78)
					v65 = v65 + ((v73 <= 0 or v79 <= 0) and 0 or v73 * v79) * v66.w
				end
				local v80 = v47 + v36 / 2 - v29
				local v81 = v51 + v37 / 2 - v30
				local v82 = v80 * v80 + v81 * v81
				local v83 = v65 + (math.sqrt(v82) * 6 + (v35 == "col" and 150 or 0))
				if v83 >= v33 then
					break
				end
				v31 = v51
				v32 = v47
				v34 = v35
				v33 = v83
			end
		end
		local v84 = v32 + 0.5
		local v85 = math.floor(v84)
		local v86 = v31 + 0.5
		return v34, v85, math.floor(v86)
	end,
	["glyph"] = function(p_u_87, p88, p_u_89, p_u_90, p91) -- name: glyph
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		local v92 = {
			["Name"] = "Glyph",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 7),
			["Size"] = UDim2.fromOffset(p91, p91),
			["ZIndex"] = p_u_90
		}
		local v_u_93 = Instance.new("Frame")
		for v94, v95 in v92 or {} do
			v_u_93[v94] = v95
		end
		if p_u_87 then
			v_u_93.Parent = p_u_87
		end
		local v96 = p91 / 10 + 0.5
		local v97 = math.floor(v96)
		local v_u_98 = math.max(2, v97)
		local function v109(p99, p100, p101, p102, p103) -- name: bar
			-- upvalues: (copy) p_u_89, (copy) v_u_98, (copy) p_u_90, (copy) v_u_93
			local v104 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = p_u_89,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(p99, p100),
				["Size"] = UDim2.new(p101, p101 ~= 0 and 0 or v_u_98, p102, p102 ~= 0 and 0 or v_u_98),
				["Rotation"] = p103 or 0,
				["ZIndex"] = p_u_90
			}
			local v105 = v_u_93
			local v106 = Instance.new("Frame")
			for v107, v108 in v104 or {} do
				v106[v107] = v108
			end
			if v105 then
				v106.Parent = v105
			end
		end
		if p88 == "rotate" then
			local v110 = {
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.55),
				["Size"] = UDim2.fromScale(0.78, 0.78),
				["ZIndex"] = p_u_90
			}
			local v111 = Instance.new("Frame")
			for v112, v113 in v110 or {} do
				v111[v112] = v113
			end
			if v_u_93 then
				v111.Parent = v_u_93
			end
			local v114 = {
				["CornerRadius"] = UDim.new(1, 0)
			}
			local v115 = Instance.new("UICorner")
			for v116, v117 in v114 or {} do
				v115[v116] = v117
			end
			if v111 then
				v115.Parent = v111
			end
			local v118 = {
				["Color"] = p_u_89,
				["Thickness"] = v_u_98,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
			}
			local v119 = Instance.new("UIStroke")
			for v120, v121 in v118 or {} do
				v119[v120] = v121
			end
			if v111 then
				v119.Parent = v111
			end
			local v122 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["BackgroundColor3"] = p_u_87.BackgroundColor3,
				["Position"] = UDim2.fromScale(0.54, 0.02),
				["Size"] = UDim2.fromScale(0.48, 0.4),
				["ZIndex"] = p_u_90 + 1
			}
			local v_u_123 = Instance.new("Frame")
			for v124, v125 in v122 or {} do
				v_u_123[v124] = v125
			end
			if v_u_93 then
				v_u_123.Parent = v_u_93
			end
			p_u_87:GetPropertyChangedSignal("BackgroundColor3"):Connect(function()
				-- upvalues: (copy) v_u_123, (copy) p_u_87
				v_u_123.BackgroundColor3 = p_u_87.BackgroundColor3
			end)
			v109(0.6, 0.17, 0.32, 0, 0)
			v109(0.74, 0.3, 0.3, 0, 90)
			for _, v126 in v_u_93:GetChildren() do
				if not v126:IsA("GuiObject") or (v126.ZIndex ~= p_u_90 or v126 == v111) then
					continue
				end
				v126.ZIndex = p_u_90 + 2
			end
		elseif p88 == "split" then
			for _, v127 in { 0.06, 0.58 } do
				local v128 = {
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = nil,
					["Position"] = UDim2.fromScale(v127, 0.18),
					["Size"] = UDim2.fromScale(0.36, 0.64),
					["ZIndex"] = p_u_90
				}
				local v129 = Instance.new("Frame")
				for v130, v131 in v128 or {} do
					v129[v130] = v131
				end
				if v_u_93 then
					v129.Parent = v_u_93
				end
				local v132 = {
					["Color"] = p_u_89,
					["Thickness"] = v_u_98,
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
				}
				local v133 = Instance.new("UIStroke")
				for v134, v135 in v132 or {} do
					v133[v134] = v135
				end
				if not v129 then
					break
				end
				v133.Parent = v129
			end
		elseif p88 == "drop" or p88 == "unequip" then
			v109(0.5, 0.36, 0, 0.62)
			v109(0.38, 0.56, 0.34, 0, 45)
			v109(0.62, 0.56, 0.34, 0, -45)
			v109(0.5, 0.94, 0.84, 0)
		elseif p88 == "equip" then
			v109(0.5, 0.64, 0, 0.62)
			v109(0.38, 0.44, 0.34, 0, -45)
			v109(0.62, 0.44, 0.34, 0, 45)
			v109(0.5, 0.06, 0.84, 0)
		elseif p88 == "load" then
			v109(0.5, 0.5, 0.3, 0.44)
			v109(0.5, 0.22, 0.2, 0.2, 45)
			v109(0.5, 0.86, 0.84, 0)
		elseif p88 == "use" then
			v109(0.5, 0.5, 0.26, 0.84)
			v109(0.5, 0.5, 0.84, 0.26)
		elseif p88 == "openbag" or p88 == "openvest" then
			local v136 = v_u_3.draw
			local v137 = p88 == "openvest" and "vest" or "backpack"
			local v138 = {
				["zindex"] = nil,
				["fill"] = 1,
				["color"] = nil,
				["cutColor"] = nil,
				["zindex"] = p_u_90,
				["color"] = p_u_89,
				["cutColor"] = p_u_87.BackgroundColor3
			}
			pcall(v136, v137, v_u_93, v138)
		else
			local v139 = p88 == "inspect" and "eye" or (p88 == "quick" and "star" or (p88 == "cancel" and "close" or (p88 == "ping" and "ping" or (p88 == "lock" and "lock" or "info"))))
			local v140 = v_u_2.icon
			local v141 = {
				["parent"] = v_u_93,
				["size"] = UDim2.fromScale(1, 1),
				["color"] = p_u_89,
				["zindex"] = p_u_90
			}
			pcall(v140, v139, v141)
		end
		local v_u_142 = v_u_2.Theme
		if v_u_142 and (v_u_142.isPhone and v_u_142.isPhone()) then
			task.defer(function()
				-- upvalues: (copy) p_u_87, (copy) v_u_142
				local v143 = p_u_87:FindFirstChild("Label")
				if v143 and v143:IsA("TextLabel") then
					v143.Size = UDim2.new(1, -4, 0, 16)
					local v144 = v143:FindFirstChildOfClass("UITextSizeConstraint")
					if v144 then
						v144.MaxTextSize = v_u_142.phoneText(13, "caption")
						v144.MinTextSize = v_u_142.phoneText(7, "scaled")
					end
				end
			end)
		end
		return v_u_93
	end
}
return v_u_145