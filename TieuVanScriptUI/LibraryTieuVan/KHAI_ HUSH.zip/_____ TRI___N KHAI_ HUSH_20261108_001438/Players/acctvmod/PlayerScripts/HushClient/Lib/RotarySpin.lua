-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RotarySpin

local v_u_1 = {
	["MAX_RPS"] = 3,
	["SPIN_UP"] = 0.35,
	["SPIN_DOWN"] = 1,
	["HOLD"] = 0.14,
	["MAX_STEP"] = 0.4886921905584123
}
local v_u_2 = nil
local v_u_3 = {}
v_u_1.clock = os.clock
function v_u_1.init(p4) -- name: init
	-- upvalues: (ref) v_u_2
	v_u_2 = p4
end
local function v_u_9(p5) -- name: find
	local v6 = p5:GetAttribute("SpinPart")
	if type(v6) == "string" and v6 ~= "" then
		local v7 = p5:FindFirstChild(v6)
		if v7 and v7:IsA("BasePart") then
			local v8 = v7:FindFirstChild("HandleWeld")
			if v8 and v8:IsA("Weld") then
				return v7, v8
			else
				return nil, nil
			end
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_1.shot(p10) -- name: shot
	-- upvalues: (ref) v_u_2, (copy) v_u_3, (copy) v_u_9, (copy) v_u_1
	if p10 then
		local v11
		if v_u_2 and (v_u_2.config and v_u_2.config.flag) then
			local v12 = v_u_2.config.flag
			local v13
			v11, v13 = pcall(v12, "NewAnims")
			if v11 then
				v11 = v13 == true
			end
		else
			v11 = true
		end
		if v11 then
			local v14 = v_u_3[p10]
			if not v14 then
				local v15, v16 = v_u_9(p10)
				if not (v15 and v16) then
					return
				end
				v14 = {
					["part"] = nil,
					["weld"] = nil,
					["base"] = nil,
					["written"] = nil,
					["angle"] = 0,
					["omega"] = 0,
					["last"] = -1,
					["part"] = v15,
					["weld"] = v16,
					["base"] = v16.C0
				}
				v_u_3[p10] = v14
			end
			v14.last = v_u_1.clock()
			return
		end
	end
end
function v_u_1.reset(p17) -- name: reset
	-- upvalues: (copy) v_u_3
	local v18 = v_u_3[p17]
	if v18 then
		if v18.weld and v18.weld.Parent then
			v18.weld.C0 = v18.base
		end
		v18.angle = 0
		v18.omega = 0
		v18.written = v18.base
		v_u_3[p17] = nil
	end
end
function v_u_1.resetAll() -- name: resetAll
	-- upvalues: (copy) v_u_3
	for v19, v20 in v_u_3 do
		if v20.weld and v20.weld.Parent then
			v20.weld.C0 = v20.base
		end
		v20.angle = 0
		v20.omega = 0
		v20.written = v20.base
		v_u_3[v19] = nil
	end
end
function v_u_1.step(p21) -- name: step
	-- upvalues: (copy) v_u_3, (ref) v_u_2, (copy) v_u_1
	if next(v_u_3) ~= nil then
		local v22
		if v_u_2 and (v_u_2.config and v_u_2.config.flag) then
			local v23 = v_u_2.config.flag
			local v24
			v22, v24 = pcall(v23, "NewAnims")
			if v22 then
				v22 = v24 == true
			end
		else
			v22 = true
		end
		local v25 = v_u_1.clock()
		for v26, v27 in v_u_3 do
			local v28 = v27.weld
			if v26.Parent and v28.Parent then
				if v22 then
					if v27.written ~= nil and v28.C0 ~= v27.written then
						local v29 = v28.C0
						local v30 = -v27.angle
						v27.base = v29 * CFrame.Angles(0, 0, v30)
					end
					local v31 = v25 - v27.last < v_u_1.HOLD
					local v32 = v_u_1.MAX_RPS * 6.283185307179586
					if v31 then
						local v33 = v27.omega + v32 / v_u_1.SPIN_UP * p21
						v27.omega = math.min(v32, v33)
					else
						local v34 = v27.omega - v32 / v_u_1.SPIN_DOWN * p21
						v27.omega = math.max(0, v34)
					end
					if v27.omega > 0 then
						local v35 = v27.angle
						local v36 = v27.omega * p21
						local v37 = v_u_1.MAX_STEP
						v27.angle = (v35 + math.min(v36, v37)) % 6.283185307179586
					end
					local v38
					if v27.angle == 0 then
						v38 = v27.base
					else
						local v39 = v27.base
						local v40 = v27.angle
						v38 = v39 * CFrame.Angles(0, 0, v40)
					end
					if v27.written == nil or v38 ~= v27.written then
						v28.C0 = v38
						v27.written = v38
					end
					if v27.omega > 0 or (v31 or v25 - v27.last <= v_u_1.SPIN_DOWN + 4) then
						continue
					end
					v_u_3[v26] = nil
				else
					if v27.weld and v27.weld.Parent then
						v27.weld.C0 = v27.base
					end
					v27.angle = 0
					v27.omega = 0
					v27.written = v27.base
					v_u_3[v26] = nil
				end
			else
				v_u_3[v26] = nil
			end
		end
	end
end
function v_u_1.speed(p41) -- name: speed
	-- upvalues: (copy) v_u_3
	local v42 = v_u_3[p41]
	return not v42 and 0 or v42.omega / 6.283185307179586
end
function v_u_1.angle(p43) -- name: angle
	-- upvalues: (copy) v_u_3
	local v44 = v_u_3[p43]
	return not v44 and 0 or v44.angle
end
return v_u_1