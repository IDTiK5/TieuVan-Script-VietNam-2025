-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIDebug

return {
	["check"] = function(p1, p2, p3, p4, p5) -- name: check
		local v6 = {}
		for v7, v8 in p1 do
			local v9 = v8.work
			local v10 = {}
			local v11 = {}
			local v12 = {}
			local v13 = {}
			local v14 = {}
			local v15 = {}
			for _, v16 in p2 do
				local v17 = p3(v9, v16.id)
				if not v17 then
					continue
				end
				v10[v17.uid] = (v10[v17.uid] or 0) + 1
			end
			for v18, v19 in type(v9) == "table" and (v9.containers or {}) or {} do
				if type(v19) ~= "table" then
					continue
				end
				local v20 = v19.items
				if type(v20) ~= "table" then
					continue
				end
				for _, v21 in v19.items do
					v10[v21.uid] = (v10[v21.uid] or 0) + 1
					local v22 = v8.grids[v18]
					if not (v22 and v8.opened) then
						continue
					end
					local v23 = v8.tiles[v21.uid]
					if v23 then
						if v23.frame.Parent == v22.cells then
							continue
						end
						local v24 = v21.id
						table.insert(v11, v24)
					else
						local v25 = v21.id
						table.insert(v12, v25)
					end
				end
			end
			for v26, v27 in v10 do
				if v27 <= 1 then
					continue
				end
				table.insert(v13, v26)
			end
			for v28, v29 in not v8.opened and {} or v8.tiles do
				local v30 = p4(v9, v28)
				if v30 and v30.kind == "grid" then
					continue
				end
				local v31 = v29.inst and v29.inst.id or "?"
				local v32
				if v30 then
					local v33 = v30.slot
					v32 = "@" .. tostring(v33)
				else
					v32 = "@gone"
				end
				local v34 = v31 .. v32
				table.insert(v14, v34)
			end
			if v8.opened then
				for v35, v36 in v8.slots do
					local v37 = p3(v9, v35)
					local v38 = v36.tile and v36.tile.inst
					if v38 then
						v38 = v36.tile.inst.uid
					end
					if v37 then
						v37 = v37.uid
					end
					if v37 == v38 then
						continue
					end
					table.insert(v15, v35)
				end
			end
			local v39 = 0
			local v40 = p5(v8)
			if type(v40) == "table" and type(v9) == "table" then
				for v41, v42 in v9.containers or {} do
					local v43 = v40.containers
					if v43 then
						v43 = v40.containers[v41]
					end
					if type(v42) ~= "table" or type(v43) ~= "table" then
						continue
					end
					local v44 = v42.items
					if type(v44) ~= "table" then
						continue
					end
					local v45 = v43.items
					if type(v45) ~= "table" or #v42.items == #v43.items then
						continue
					end
					v39 = v39 + 1
				end
			end
			local v46 = #v14 + #v11 + #v12 + #v15 + #v13
			local v47 = string.format
			local v48 = v8.mode
			local v49 = v46 == 0 and "OK" or "BAD"
			local v50 = #v14
			local v51 = table.concat(v14, ",")
			local v52 = #v11
			local v53 = table.concat(v11, ",")
			local v54 = #v12
			local v55 = table.concat(v12, ",")
			local v56 = #v15
			local v57 = table.concat(v15, ",")
			local v58 = #v13
			table.insert(v6, v47("#%d %s %s ghost=%d[%s] misplaced=%d[%s] missing=%d[%s] slots=%d[%s] snapDupes=%d predDiff=%d", v7, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v39))
		end
		return #v6 == 0 and "no mounts" or table.concat(v6, " | ")
	end,
	["dump"] = function(p59, p60, p61) -- name: dump
		local v62 = {}
		for v63, v64 in p59 do
			local v65 = 0
			local v66 = 0
			for _, v67 in v64.tiles do
				v65 = v65 + 1
				if not v67.hasIcon() then
					continue
				end
				v66 = v66 + 1
			end
			local v68 = 0
			for _, v69 in v64.root:GetDescendants() do
				if not v69:IsA("TextLabel") or (not v69.Visible or (v69.Text == "" or (v69.TextFits or (v69.TextTruncate ~= Enum.TextTruncate.None or v69.TextScaled)))) then
					continue
				end
				v68 = v68 + 1
			end
			local v70 = {}
			for v71, v72 in v64.grids do
				local v73 = string.format
				local v74 = v72.w
				local v75 = v72.h
				local v76 = v72.cells.AbsoluteSize.X
				local v77 = v72.w
				local v78 = v76 / math.max(v77, 1) + 0.5
				local v79 = math.floor(v78)
				table.insert(v70, v73("%s=%dx%d@%dpx", v71, v74, v75, v79))
			end
			local v80 = not v64.layer and "" or string.format(" layer=%s@%d", v64.layer.gui.Name, v64.layer.gui.DisplayOrder)
			local v81 = v64.rail and "split+rail" or (v64.split and "split" or (v64.narrow and "narrow" or "wide"))
			local v82 = string.format
			local v83 = v64.mode
			local v84 = v64.isShown
			local v85 = tostring(v84())
			local v86 = v64.cell
			local v87 = p60(v64)
			local v88 = v64.root.AbsoluteSize.X
			local v89 = v64.root.AbsoluteSize.Y
			local v90 = v64.dw or 0
			local v91 = v64.dh or 0
			local v92 = table.concat
			table.insert(v62, v82("#%d %s shown=%s layout=%s cell=%d real=%.1f size=%dx%d design=%dx%d tiles=%d icons=%d overflow=%d%s grids[%s]", v63, v83, v85, v81, v86, v87, v88, v89, v90, v91, v65, v66, v68, v80, v92(v70, " ")))
		end
		local v93 = p61.stats
		local v94, v95 = pcall(v93)
		if v94 and type(v95) == "table" then
			local v96 = string.format
			local v97 = v95.pooled
			local v98 = v95.bad
			local v99 = v95.ids
			table.insert(v62, v96("pool=%d bad=%d ids=%d", v97, v98, v99))
		end
		return table.concat(v62, " | ")
	end
}