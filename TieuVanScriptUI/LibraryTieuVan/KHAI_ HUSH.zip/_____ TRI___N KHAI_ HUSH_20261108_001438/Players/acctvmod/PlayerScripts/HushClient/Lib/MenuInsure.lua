-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuInsure

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("GuiService")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = v2:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_7 = require(v_u_6:WaitForChild("Theme"))
local v8 = require(v_u_6:WaitForChild("Signal"))
local v_u_9 = v_u_7.color
local v_u_10 = {
	["changed"] = v8.new()
}
local v_u_11 = v1.LocalPlayer
local v_u_12 = v4:IsStudio()
local v_u_13 = {
	["primary"] = "Primary weapon",
	["secondary"] = "Sidearm",
	["armor"] = "Body armor",
	["helmet"] = "Headwear",
	["bag"] = "Backpack",
	["ears"] = "Headset",
	["melee"] = "Melee weapon",
	["boots"] = "Boots",
	["legs"] = "Legs",
	["secure"] = "Secure container"
}
local v_u_14 = {
	["cctx"] = nil,
	["mc"] = nil,
	["data"] = nil,
	["loading"] = false,
	["failed"] = false,
	["win"] = nil,
	["body"] = nil,
	["closeConn"] = nil,
	["unbind"] = nil,
	["sel"] = nil,
	["armedAt"] = 0,
	["pending"] = nil,
	["err"] = nil,
	["showOther"] = false,
	["hilite"] = nil,
	["wantUid"] = nil,
	["scrollTo"] = nil,
	["req"] = 0,
	["gen"] = 0,
	["bound"] = false,
	["stub"] = nil,
	["refreshQueued"] = false,
	["bodyW"] = 912,
	["bodyH"] = 760,
	["focusUid"] = nil,
	["zoom"] = 1,
	["scaleOverride"] = nil,
	["rank"] = nil,
	["flash"] = nil,
	["closeConn"] = {},
	["unbind"] = {}
}
local function v_u_19(p15) -- name: commas
	local v16 = math.abs(p15) + 0.5
	local v17 = math.floor(v16)
	local v18 = tostring(v17):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if v18:sub(1, 1) == "," then
		v18 = v18:sub(2)
	end
	return (p15 < 0 and "-" or "") .. v18
end
function v_u_10.money(p20) -- name: money
	-- upvalues: (copy) v_u_19
	return "$" .. v_u_19(p20)
end
function v_u_10.riskText(p21) -- name: riskText
	return ("x%.2f"):format((type(p21) ~= "number" or (p21 ~= p21 or (p21 == (1 / 0) or p21 == (-1 / 0)))) and 1 or p21)
end
function v_u_10.short(p22, p23) -- name: short
	local v24
	if type(p22) == "table" then
		v24 = p22.premium
	else
		v24 = false
	end
	local v25 = ((type(v24) ~= "number" or (v24 ~= v24 or (v24 == (1 / 0) or v24 == (-1 / 0)))) and 0 or v24) - ((type(p23) ~= "number" or (p23 ~= p23 or (p23 == (1 / 0) or p23 == (-1 / 0)))) and 0 or p23)
	return math.max(0, v25)
end
function v_u_10.zoomFor(p26) -- name: zoomFor
	local v27 = (type(p26) ~= "number" or (p26 ~= p26 or (p26 == (1 / 0) or p26 == (-1 / 0)))) and 1 or p26
	if v27 <= 0.05 then
		return 1
	end
	local v28 = 0.92 / v27
	local v29 = math.clamp(v28, 1, 1.3) * 100 + 0.5
	return math.floor(v29) / 100
end
function v_u_10.phoneBodyH(p30, p31, p32) -- name: phoneBodyH
	local v33 = p30 * 0.9
	local v34 = p30 - (p32 or 0) - 16
	local v35 = math.min(v33, v34)
	local v36 = math.floor(v35) - p31 - 80
	return math.max(180, v36)
end
function v_u_10.cashShort(p37) -- name: cashShort
	-- upvalues: (copy) v_u_10
	local v38 = v_u_10.classify(p37)
	if #v38.buy == 0 then
		return false
	end
	local v39
	if type(p37) == "table" then
		v39 = p37.cash
	else
		v39 = nil
	end
	for _, v40 in v38.buy do
		if v_u_10.short(v40, v39) > 0 then
			continue
		end
		return false
	end
	return true
end
function v_u_10.reasonText(p41) -- name: reasonText
	local v42 = type(p41) ~= "string" and "" or p41
	local v43 = string.gsub(v42, "^%s+", "")
	local v44 = string.gsub(v43, "%s+$", "")
	if v44 == "" then
		return "Cannot be insured."
	end
	if not string.find(v44, "[%.%!%?]$") then
		v44 = v44 .. "."
	end
	return v44
end
function v_u_10.freeUsed(p45) -- name: freeUsed
	if type(p45) ~= "table" then
		return 0
	end
	p45.freeToday = false
	local v46 = 0
	local v47 = p45.eligible
	if type(v47) == "table" then
		for _, v48 in p45.eligible do
			if type(v48) ~= "table" or v48.free ~= true then
				continue
			end
			local v49 = v48.insured
			if type(v49) == "table" then
				continue
			end
			local v50 = v48.full
			if type(v50) ~= "number" then
				continue
			end
			v48.free = false
			v48.premium = v48.full
			v46 = v46 + 1
		end
	end
	return v46
end
function v_u_10.fillSlots(p51) -- name: fillSlots
	if type(p51) == "table" then
		local v52 = p51.eligible
		if type(v52) == "table" then
			local v53 = p51.slots
			local v54 = (type(v53) ~= "number" or (v53 ~= v53 or (v53 == (1 / 0) or v53 == (-1 / 0)))) and 0 or v53
			local v55 = math.floor(v54)
			if v55 > 0 then
				local v56 = p51.used
				local v57 = (type(v56) ~= "number" or (v56 ~= v56 or (v56 == (1 / 0) or v56 == (-1 / 0)))) and 0 or v56
				if math.floor(v57) >= v55 then
					local v58 = 0
					for _, v59 in p51.eligible do
						if type(v59) ~= "table" then
							continue
						end
						local v60 = v59.insured
						if type(v60) == "table" or (v59.premium == nil or v59.canBuy ~= true) then
							continue
						end
						v59.canBuy = false
						v59.reason = ("All %d policy slots are in use"):format(v55)
						v58 = v58 + 1
					end
					return v58
				end
			end
			return 0
		end
	end
	return 0
end
function v_u_10.classify(p61) -- name: classify
	local v62 = {
		["buy"] = {},
		["blocked"] = {},
		["insured"] = {},
		["other"] = {}
	}
	local v63
	if type(p61) == "table" then
		local v64 = p61.eligible
		v63 = type(v64) ~= "table" and {} or p61.eligible
	else
		v63 = {}
	end
	for _, v65 in v63 do
		if type(v65) ~= "table" then
			continue
		end
		local v66 = v65.insured
		if type(v66) == "table" then
			local v67 = v62.insured
			table.insert(v67, v65)
		elseif v65.canBuy == true then
			local v68 = v62.buy
			table.insert(v68, v65)
		elseif v65.premium == nil then
			local v69 = v62.other
			table.insert(v69, v65)
		else
			local v70 = v62.blocked
			table.insert(v70, v65)
		end
	end
	return v62
end
function v_u_10.stableRows(p71, p72) -- name: stableRows
	local v73 = {}
	for _, v74 in { "buy", "blocked", "insured" } do
		local v75
		if type(p71) == "table" then
			v75 = p71[v74]
		else
			v75 = nil
		end
		if type(v75) ~= "table" then
			continue
		end
		for _, v76 in v75 do
			if type(v76) ~= "table" then
				continue
			end
			table.insert(v73, {
				["row"] = v76,
				["kind"] = v74
			})
		end
	end
	local v_u_77 = {}
	local v78 = 0
	if type(p72) == "table" then
		for v79, v80 in p72 do
			if type(v80) ~= "number" then
				continue
			end
			v_u_77[v79] = v80
			v78 = math.max(v78, v80)
		end
	end
	for _, v81 in v73 do
		local v82 = v81.row.uid
		local v83 = tostring(v82)
		if v_u_77[v83] ~= nil then
			continue
		end
		v78 = v78 + 1
		v_u_77[v83] = v78
	end
	table.sort(v73, function(p84, p85)
		-- upvalues: (copy) v_u_77
		local v86 = v_u_77
		local v87 = p84.row.uid
		local v88 = v86[tostring(v87)]
		local v89 = v_u_77
		local v90 = p85.row.uid
		return v88 < v89[tostring(v90)]
	end)
	return {
		["list"] = v73,
		["rank"] = v_u_77
	}
end
function v_u_10.pickMap(p91, p92) -- name: pickMap
	local v93
	if type(p91) == "table" then
		local v94 = p91.rules
		if type(v94) == "table" then
			local v95 = p91.rules.maps
			v93 = type(v95) ~= "table" and {} or p91.rules.maps
		else
			v93 = {}
		end
	else
		v93 = {}
	end
	local v96
	if type(p92) == "string" then
		v96 = string.match(p92, "deploy=(%S+)")
		if v96 == nil then
			v96 = string.match(p92, "view=(%S+)")
		end
	else
		v96 = nil
	end
	if v96 then
		for _, v97 in v93 do
			if type(v97) ~= "table" then
				continue
			end
			local v98 = string.lower
			local v99 = v97.id
			if v98((tostring(v99))) ~= string.lower(v96) then
				continue
			end
			return v97
		end
	end
	return v93[1]
end
function v_u_10.returnText(p100, p101) -- name: returnText
	if type(p100) == "table" then
		local v102 = p100.returnMinutes
		local v103 = (type(v102) ~= "number" or (v102 ~= v102 or (v102 == (1 / 0) or v102 == (-1 / 0)))) and 0 or v102
		local v104 = math.floor(v103)
		local v105 = p100.returnMinutesPlus
		local v106 = (type(v105) ~= "number" or (v105 ~= v105 or (v105 == (1 / 0) or v105 == (-1 / 0)))) and 0 or v105
		local v107 = math.floor(v106)
		local v108 = p100.name or (p100.id or "this map")
		local v109 = tostring(v108)
		if p101 == true then
			return ("Returns after %d min on %s with INSURANCE PLUS (%d min without it)."):format(v107, v109, v104)
		else
			return ("Returns after %d min on %s, %d min with INSURANCE PLUS."):format(v104, v109, v107)
		end
	else
		return "The return time depends on the map."
	end
end
local v_u_110 = nil
local v_u_111 = nil
local function v_u_116() -- name: serverNow
	-- upvalues: (ref) v_u_111
	if v_u_111 == nil then
		local v_u_112 = script.Parent
		if v_u_112 then
			v_u_112 = script.Parent:FindFirstChild("ServerClock")
		end
		local v113, v114 = pcall(function()
			-- upvalues: (copy) v_u_112
			return require(v_u_112)
		end)
		if v113 and type(v114) == "table" then
			local v115 = v114.now
			if type(v115) ~= "function" then
				v114 = false
			end
		else
			v114 = false
		end
		v_u_111 = v114
	end
	if v_u_111 then
		return v_u_111.now()
	else
		return os.time()
	end
end
function v_u_10.returnLines(p117, p118) -- name: returnLines
	-- upvalues: (ref) v_u_110, (copy) v_u_6
	local v119 = {}
	local v120
	if type(p117) == "table" then
		local v121 = p117.returns
		v120 = type(v121) ~= "table" and {} or p117.returns
	else
		v120 = {}
	end
	if v_u_110 == nil then
		local function v122()
			-- upvalues: (ref) v_u_6
			return require((v_u_6:WaitForChild("InsuranceRules", 5)))
		end
		local v123, v124 = pcall(v122)
		if not v123 or type(v124) ~= "table" then
			v124 = false
		end
		v_u_110 = v124
	end
	local v125 = v_u_110 or nil
	if v125 then
		local v126 = v125.comesBackText
		if type(v126) == "function" then
			local v127 = v125.waitText
			if type(v127) ~= "function" then
				v125 = nil
			end
		else
			v125 = nil
		end
	end
	for _, v128 in v120 do
		if type(v128) ~= "table" then
			continue
		end
		local v129 = v128.name or "Item"
		local v130 = tostring(v129)
		local v131 = v128.readyAt
		if type(v131) == "number" then
			local v132 = v128.readyAt - p118
			local v133 = math.max(0, v132)
			local v134 = not v125 and "comes back by mail soon" or v125.comesBackText(v133)
			table.insert(v119, ("%s %s."):format(v130, v134))
		else
			local v135 = v128.after
			if type(v135) ~= "number" then
				continue
			end
			local v136 = not v125 and "some time" or v125.waitText(v128.after)
			table.insert(v119, ("%s: the raid has not ended yet. It comes back by mail %s after the raid ends."):format(v130, v136))
		end
	end
	return v119
end
function v_u_10.confirmLines(p137, p138, p139) -- name: confirmLines
	-- upvalues: (copy) v_u_10
	local v140
	if type(p138) == "table" then
		local v141 = p138.rules
		v140 = type(v141) ~= "table" and {} or p138.rules
	else
		v140 = {}
	end
	local v142 = {}
	local v143 = p137.premium
	if ((type(v143) ~= "number" or (v143 ~= v143 or (v143 == (1 / 0) or v143 == (-1 / 0)))) and 0 or v143) <= 0 then
		table.insert(v142, "Free policy of the day. No Cash is charged. Only one policy a day is free.")
	else
		local v144 = v_u_10.money
		local v145 = p137.premium
		local v146 = (type(v145) ~= "number" or (v145 ~= v145 or (v145 == (1 / 0) or v145 == (-1 / 0)))) and 0 or v145
		table.insert(v142, ("Premium %s, paid now from your Cash. It is not refunded."):format(v144(v146)))
	end
	local v147 = v140.term
	local v148 = (type(v147) ~= "number" or (v147 ~= v147 or (v147 == (1 / 0) or v147 == (-1 / 0)))) and 3 or v147
	local v149 = math.floor(v148)
	table.insert(v142, ("Covers %d raids. It ends after that, when it pays out, or when the item is gone."):format(v149))
	if type(p139) == "table" and p139.enabled == false then
		local v150 = p139.name
		local v151 = tostring(v150)
		table.insert(v142, ("Insurance is not active on %s: nothing is covered there."):format(v151))
		return v142
	end
	local v152 = "If you die and nobody carries it out, the same item comes back by mail. "
	local v153 = v_u_10.returnText
	local v154
	if type(p138) == "table" then
		v154 = p138.pass
	else
		v154 = false
	end
	local v155 = v152 .. v153(p139, v154) .. " The time counts from the end of the raid."
	table.insert(v142, v155)
	return v142
end
function v_u_10.rulesLines(p156) -- name: rulesLines
	local v157
	if type(p156) == "table" then
		local v158 = p156.rules
		v157 = type(v158) ~= "table" and {} or p156.rules
	else
		v157 = {}
	end
	local v159 = {}
	local v160 = v157.text
	local v161 = (type(v160) ~= "string" or v157.text == "") and "An insured item comes back if you died and nobody carried it out. It returns by mail, the same item, never Cash. Premiums are not refunded." or v157.text
	table.insert(v159, v161)
	local v162 = v157.term
	local v163 = (type(v162) ~= "number" or (v162 ~= v162 or (v162 == (1 / 0) or v162 == (-1 / 0)))) and 3 or v162
	local v164 = math.floor(v163)
	table.insert(v159, ("One policy covers one item for %d raids. Rifles, sidearms, body armor, rigs, helmets, headsets and backpacks can be insured. Attachments on a gun come back with it, the contents of bags, rigs and magazines do not."):format(v164))
	local v165 = v157.maps
	if type(v165) == "table" and #v157.maps > 0 then
		local v166 = {}
		for _, v167 in v157.maps do
			if type(v167) ~= "table" or v167.enabled == false then
				continue
			end
			local v168 = v167.name
			local v169 = tostring(v168)
			local v170 = v167.returnMinutes
			local v171 = (type(v170) ~= "number" or (v170 ~= v170 or (v170 == (1 / 0) or v170 == (-1 / 0)))) and 0 or v170
			local v172 = math.floor(v171)
			local v173 = v167.returnMinutesPlus
			local v174 = (type(v173) ~= "number" or (v173 ~= v173 or (v173 == (1 / 0) or v173 == (-1 / 0)))) and 0 or v173
			local v175 = math.floor(v174)
			table.insert(v166, ("%s %d min (%d)"):format(v169, v172, v175))
		end
		local v176 = v157.returnFactor
		local v177 = (type(v176) ~= "number" or (v176 ~= v176 or (v176 == (1 / 0) or v176 == (-1 / 0)))) and 4 or v176
		local v178 = tostring(v177)
		local v179 = v157.returnFactorPass
		local v180 = (type(v179) ~= "number" or (v179 ~= v179 or (v179 == (1 / 0) or v179 == (-1 / 0)))) and 1.5 or v179
		local v181 = tostring(v180)
		local v182 = table.concat
		table.insert(v159, ("Return time is %sx the longest raid of the map, %sx with INSURANCE PLUS. %s."):format(v178, v181, v182(v166, ", ")))
	end
	local v183 = v157.tiers
	local v184 = (1 / 0)
	local v185 = 0
	for _, v186 in type(v183) ~= "table" and {} or v157.tiers do
		if type(v186) ~= "table" then
			continue
		end
		local v187 = v186.rate
		if type(v187) ~= "number" then
			continue
		end
		local v188 = v186.rate
		v184 = math.min(v184, v188)
		local v189 = v186.rate
		v185 = math.max(v185, v189)
	end
	if v185 > 0 then
		local v190 = v184 * 100 + 0.5
		local v191 = math.floor(v190)
		local v192 = v185 * 100 + 0.5
		local v193 = math.floor(v192)
		table.insert(v159, ("The premium is %d to %d percent of the item\'s value. A higher trader level, INSURANCE PLUS and a low risk class make it cheaper."):format(v191, v193))
	end
	local v194 = v157.riskPayout
	if type(v194) == "number" then
		local v195 = v157.riskExtract
		if type(v195) == "number" then
			local v196 = v157.riskPayout
			local v197 = v157.riskMax
			local v198 = (type(v197) ~= "number" or (v197 ~= v197 or (v197 == (1 / 0) or v197 == (-1 / 0)))) and 1.6 or v197
			local v199 = v157.riskExtract
			table.insert(v159, ("Every payout raises your risk class by %.2f (up to x%.2f), every extraction lowers it by %.2f. A higher class makes every premium dearer."):format(v196, v198, v199))
		end
	end
	return v159
end
function v_u_10.sigOf(p200) -- name: sigOf
	if type(p200) ~= "table" then
		return ""
	end
	local v201 = {}
	local v202 = p200.slots
	local v203 = tostring(v202)
	local v204 = p200.used
	local v205 = tostring(v204)
	local v206 = p200.riskClass
	local v207 = tostring(v206)
	local v208 = p200.pass
	local v209 = tostring(v208)
	local v210 = p200.freeToday
	local v211 = tostring(v210)
	local v212 = p200.cash
	__set_list(v201, 1, {v203, v205, v207, v209, v211, (tostring(v212))})
	local v213 = p200.eligible
	if type(v213) == "table" then
		for _, v214 in p200.eligible do
			if type(v214) ~= "table" then
				continue
			end
			local v215 = "%s|%s|%s|%s|%s|%s|%s"
			local v216 = v214.uid
			local v217 = tostring(v216)
			local v218 = v214.id
			local v219 = tostring(v218)
			local v220 = v214.canBuy
			local v221 = tostring(v220)
			local v222 = v214.premium
			local v223 = tostring(v222)
			local v224 = v214.free
			local v225 = tostring(v224)
			local v226 = v214.reason
			local v227 = tostring(v226)
			local v228 = v214.insured
			local v229
			if type(v228) == "table" then
				v229 = v214.insured.raidsLeft or nil
			else
				v229 = nil
			end
			local v230 = tostring(v229)
			table.insert(v201, v215:format(v217, v219, v221, v223, v225, v227, v230))
		end
	end
	local v231 = p200.policies
	if type(v231) == "table" then
		for _, v232 in p200.policies do
			if type(v232) ~= "table" then
				continue
			end
			local v233 = v232.id
			local v234 = tostring(v233)
			local v235 = v232.uid
			local v236 = tostring(v235)
			local v237 = v232.raidsLeft
			local v238 = tostring(v237)
			table.insert(v201, ("p|%s|%s|%s"):format(v234, v236, v238))
		end
	end
	local v239 = p200.rules
	local v240
	if type(v239) == "table" then
		local v241 = p200.rules.maps
		v240 = type(v241) ~= "table" and {} or p200.rules.maps
	else
		v240 = {}
	end
	for _, v242 in v240 do
		if type(v242) ~= "table" then
			continue
		end
		local v243 = v242.id
		local v244 = tostring(v243)
		local v245 = v242.enabled
		local v246 = tostring(v245)
		local v247 = v242.returnMinutes
		local v248 = tostring(v247)
		local v249 = v242.returnMinutesPlus
		local v250 = tostring(v249)
		table.insert(v201, ("m|%s|%s|%s|%s"):format(v244, v246, v248, v250))
	end
	return table.concat(v201, ";")
end
function v_u_10.summaryOf(p251) -- name: summaryOf
	if type(p251) ~= "table" then
		return nil
	end
	local v252 = {}
	local v253 = p251.slots
	v252.slots = (type(v253) ~= "number" or (v253 ~= v253 or (v253 == (1 / 0) or v253 == (-1 / 0)))) and 0 or v253
	local v254 = p251.used
	v252.used = (type(v254) ~= "number" or (v254 ~= v254 or (v254 == (1 / 0) or v254 == (-1 / 0)))) and 0 or v254
	local v255 = p251.riskClass
	v252.riskClass = (type(v255) ~= "number" or (v255 ~= v255 or (v255 == (1 / 0) or v255 == (-1 / 0)))) and 1 or v255
	v252.pass = p251.pass == true
	return v252
end
function v_u_10.summary() -- name: summary
	-- upvalues: (copy) v_u_10, (copy) v_u_14
	return v_u_10.summaryOf(v_u_14.data)
end
function v_u_10.stubData(p256) -- name: stubData
	local v257 = tostring(p256)
	local v258 = {
		["term"] = 3,
		["mailMax"] = 20,
		["returnFactor"] = 4,
		["returnFactorPass"] = 1.5,
		["freeValueMax"] = 25000,
		["passDiscount"] = 20,
		["riskMin"] = 1,
		["riskMax"] = 1.6,
		["riskPayout"] = 0.15,
		["riskExtract"] = 0.05,
		["maps"] = nil,
		["tiers"] = nil,
		["text"] = "An insured item comes back if you died and nobody carried it out. It returns by mail, the same item, never Cash. Premiums are not refunded.",
		["maps"] = {
			{
				["id"] = "stillwater",
				["name"] = "Stillwater",
				["enabled"] = true,
				["maxRaidMinutes"] = 25,
				["returnMinutes"] = 100,
				["returnMinutesPlus"] = 38,
				["returnSeconds"] = 6000,
				["returnSecondsPlus"] = 2250
			},
			{
				["id"] = "hollow",
				["name"] = "The Hollow",
				["enabled"] = true,
				["maxRaidMinutes"] = 40,
				["returnMinutes"] = 160,
				["returnMinutesPlus"] = 60,
				["returnSeconds"] = 9600,
				["returnSecondsPlus"] = 3600
			},
			{
				["id"] = "kestrel",
				["name"] = "Kestrel Field",
				["enabled"] = true,
				["maxRaidMinutes"] = 30,
				["returnMinutes"] = 120,
				["returnMinutesPlus"] = 45,
				["returnSeconds"] = 7200,
				["returnSecondsPlus"] = 2700
			}
		},
		["tiers"] = {
			{
				["below"] = 5000,
				["rate"] = 0.3
			},
			{
				["below"] = 20000,
				["rate"] = 0.4
			},
			{
				["below"] = 60000,
				["rate"] = 0.5
			},
			{
				["rate"] = 0.6
			}
		}
	}
	local v259 = v257 == "5" and true or v257 == "pass"
	local v260 = {}
	local v261
	if v257 == "0" or v257 == "empty" then
		v261 = {}
	else
		local v262 = v257 == "2" and true or v257 == "limit"
		local v263 = v259 and 0.8 or 1
		local v264 = v263 * 27000 / 10 + 0.5
		local v265 = math.floor(v264) * 10
		table.insert(v260, {
			["uid"] = "u_akm",
			["id"] = "rifle_akm",
			["name"] = "AKM",
			["slot"] = "primary",
			["rarity"] = 3,
			["V"] = 54000,
			["premium"] = nil,
			["full"] = nil,
			["free"] = false,
			["canBuy"] = true,
			["premium"] = v265,
			["full"] = v265
		})
		local v266 = v263 * 7200 / 10 + 0.5
		local v267 = math.floor(v266) * 10
		table.insert(v260, {
			["uid"] = "u_g17",
			["id"] = "pistol_g17",
			["name"] = "G17",
			["slot"] = "secondary",
			["rarity"] = 3,
			["V"] = 18000,
			["premium"] = nil,
			["full"] = nil,
			["free"] = false,
			["canBuy"] = true,
			["premium"] = v267,
			["full"] = v267
		})
		local v268 = v263 * 7200 / 10 + 0.5
		local v269 = math.floor(v268) * 10
		table.insert(v260, {
			["uid"] = "u_vest",
			["id"] = "vest_platecarrier",
			["name"] = "Plate Carrier",
			["slot"] = "armor",
			["rarity"] = 3,
			["V"] = 18000,
			["premium"] = nil,
			["full"] = nil,
			["free"] = false,
			["canBuy"] = true,
			["premium"] = v269,
			["full"] = v269
		})
		local v270 = v263 * 4800 / 10 + 0.5
		local v271 = math.floor(v270) * 10
		table.insert(v260, {
			["uid"] = "u_helmet",
			["id"] = "helmet_military",
			["name"] = "Military Helmet",
			["slot"] = "helmet",
			["rarity"] = 3,
			["V"] = 12000,
			["premium"] = nil,
			["full"] = nil,
			["free"] = false,
			["canBuy"] = true,
			["premium"] = v271,
			["full"] = v271
		})
		local v272 = v263 * 900 / 10 + 0.5
		local v273 = math.floor(v272) * 10
		table.insert(v260, {
			["uid"] = "u_bag",
			["id"] = "bag_school",
			["name"] = "School Backpack",
			["slot"] = "bag",
			["rarity"] = 3,
			["V"] = 3000,
			["premium"] = nil,
			["full"] = nil,
			["free"] = false,
			["canBuy"] = true,
			["premium"] = v273,
			["full"] = v273
		})
		if v259 then
			for _, v274 in v260 do
				if v274.V > 25000 then
					continue
				end
				v274.free = true
				v274.premium = 0
			end
		end
		table.insert(v260, {
			["uid"] = "u_axe",
			["id"] = "melee_axe",
			["name"] = "Fire Axe",
			["slot"] = "melee",
			["rarity"] = 2,
			["V"] = 800,
			["canBuy"] = false,
			["reason"] = "Melee weapons cannot be insured"
		})
		table.insert(v260, {
			["uid"] = "u_secure",
			["id"] = "secure_2x2",
			["name"] = "Secure Pouch",
			["slot"] = "secure",
			["rarity"] = 1,
			["V"] = 0,
			["canBuy"] = false,
			["reason"] = "Secure containers cannot be insured"
		})
		table.insert(v260, {
			["uid"] = "u_paid",
			["id"] = "ears_tactical",
			["name"] = "Tactical Headset",
			["slot"] = "ears",
			["rarity"] = 3,
			["V"] = 9000,
			["canBuy"] = false,
			["reason"] = "Paid items cannot be insured."
		})
		if v262 then
			v261 = {
				{
					["id"] = "p1",
					["uid"] = "u_old1",
					["itemId"] = "rifle_hunting",
					["name"] = "Hunting Rifle",
					["premium"] = 9000,
					["raidsLeft"] = 1,
					["bought"] = 0,
					["free"] = false
				},
				{
					["id"] = "p2",
					["uid"] = "u_old2",
					["itemId"] = "smg_mp5",
					["name"] = "MK5 SMG",
					["premium"] = 12000,
					["raidsLeft"] = 2,
					["bought"] = 0,
					["free"] = false
				},
				{
					["id"] = "p3",
					["uid"] = "u_old3",
					["itemId"] = "vest_military",
					["name"] = "Military Rig",
					["premium"] = 13000,
					["raidsLeft"] = 3,
					["bought"] = 0,
					["free"] = false
				}
			}
			for _, v275 in v260 do
				if v275.premium == nil then
					continue
				end
				v275.canBuy = false
				v275.reason = "All 3 policy slots are in use"
			end
		else
			v261 = {
				{
					["id"] = "p1",
					["uid"] = "u_old2",
					["itemId"] = "smg_mp5",
					["name"] = "MK5 SMG",
					["premium"] = 12000,
					["raidsLeft"] = 2,
					["bought"] = 0,
					["free"] = false
				}
			}
			for _, v276 in v260 do
				if v276.uid ~= "u_vest" then
					continue
				end
				v276.canBuy = false
				v276.reason = "Already insured"
				v276.insured = {
					["id"] = "p9",
					["uid"] = "u_vest",
					["itemId"] = "vest_platecarrier",
					["name"] = "Plate Carrier",
					["premium"] = 7200,
					["raidsLeft"] = 3,
					["bought"] = 0,
					["free"] = false
				}
				local v277 = v276.insured
				table.insert(v261, v277)
			end
		end
	end
	if v257 == "long" then
		for v278, v279 in v260 do
			v279.name = ("Reinforced Tactical Assault Carrier Mk %d with Extended Hydration Panels"):format(v278)
			if v279.canBuy ~= false or (not v279.reason or v279.insured) then
				continue
			end
			v279.reason = "This item cannot be insured because it belongs to a category that is excluded from every policy"
		end
		for _, v280 in v261 do
			v280.name = "Reinforced Tactical Assault Carrier Mk 9 with Extended Hydration Panels"
		end
		local v281 = v260[1]
		local v282 = v260[1]
		local v283 = v260[1]
		v281.V = 5400000
		v282.premium = 3240000
		v283.full = 3240000
	end
	local v284 = (v257 == "3" or v257 == "cash") and 1200 or 5000000
	return {
		["slots"] = 3,
		["used"] = nil,
		["riskClass"] = 1.15,
		["pass"] = nil,
		["freeToday"] = nil,
		["freeValueMax"] = 25000,
		["cash"] = nil,
		["level"] = 2,
		["repPoints"] = 0.02,
		["policies"] = nil,
		["eligible"] = nil,
		["rules"] = nil,
		["serverTime"] = nil,
		["used"] = #v261,
		["pass"] = v259,
		["freeToday"] = v259,
		["cash"] = v284,
		["policies"] = v261,
		["eligible"] = v260,
		["rules"] = v258,
		["serverTime"] = os.time()
	}
end
local function v_u_292(p285) -- name: modsOf
	-- upvalues: (copy) v_u_14
	local v286 = v_u_14.mc
	if v286 then
		local v287 = v286.slots
		if type(v287) == "function" then
			local v288 = v286.slots
			local v289, v290 = pcall(v288)
			if v289 and type(v290) == "table" then
				local v291 = v290[p285.slot]
				if type(v291) == "table" and v291.uid == p285.uid then
					return v291.mods
				else
					return nil
				end
			else
				return nil
			end
		end
	end
	return nil
end
local v_u_293 = nil
local function v_u_301() -- name: fetchNow
	-- upvalues: (copy) v_u_14
	if v_u_14.stub then
		return v_u_14.stub
	end
	local v_u_294 = v_u_14.cctx
	if not v_u_294 then
		return nil
	end
	local v295, v296 = pcall(function()
		-- upvalues: (copy) v_u_294
		return v_u_294.net.invoke("menu.get", {
			["what"] = "insurance"
		})
	end)
	if v295 and (type(v296) == "table" and v296.error == nil) then
		local v297 = v296.eligible
		if type(v297) == "table" then
			v_u_14.err = nil
			return v296
		end
	end
	local v298 = v_u_14
	local v299
	if v295 and type(v296) == "table" then
		local v300 = v296.error
		if type(v300) == "string" then
			v299 = v296.error
		else
			v299 = nil
		end
	else
		v299 = nil
	end
	v298.err = v299
	return nil
end
function v_u_10.refresh(p302) -- name: refresh
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) v_u_301, (copy) v_u_11, (ref) v_u_293
	if p302 then
		v_u_14.mc = p302
		if p302.cctx then
			v_u_10.bind(p302.cctx)
		end
	end
	if v_u_14.cctx then
		if v_u_14.loading then
			v_u_14.again = true
		else
			v_u_14.loading = true
			task.spawn(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_301, (ref) v_u_10, (ref) v_u_11, (ref) v_u_293
				local v303 = v_u_14.gen
				local v_u_304 = v_u_301()
				v_u_14.loading = false
				local v305 = true
				local v306
				if v_u_304 == nil then
					v306 = false
				else
					v306 = v303 ~= v_u_14.gen
				end
				if v306 then
					v_u_14.again = true
					v_u_304 = nil
					v305 = false
				end
				if v_u_304 then
					local v307 = v_u_10.sigOf(v_u_304)
					v305 = v307 ~= v_u_14.sig and true or v_u_14.data == nil
					v_u_14.sig = v307
					v_u_14.data = v_u_304
					v_u_14.failed = false
					v_u_14.dataAt = os.clock()
					local function v308()
						-- upvalues: (ref) v_u_10, (ref) v_u_304
						v_u_10.changed:Fire(v_u_10.summaryOf(v_u_304))
					end
					pcall(v308)
				elseif not v306 then
					v_u_14.failed = v_u_14.data == nil
				end
				if v_u_11 and v_u_14.data then
					local v309 = v_u_11
					local v310 = v_u_14.data.used
					local v311 = (type(v310) ~= "number" or (v310 ~= v310 or (v310 == (1 / 0) or v310 == (-1 / 0)))) and 0 or v310
					local v312 = v_u_14.data.slots
					local v313 = (type(v312) ~= "number" or (v312 ~= v312 or (v312 == (1 / 0) or v312 == (-1 / 0)))) and 0 or v312
					local v314 = v_u_14.data.riskClass
					local v315 = (type(v314) ~= "number" or (v314 ~= v314 or (v314 == (1 / 0) or v314 == (-1 / 0)))) and 1 or v314
					local v316 = v_u_14.data.pass == true
					v309:SetAttribute("InsureSummary", ("%d/%d x%.2f pass=%s"):format(v311, v313, v315, (tostring(v316))))
				end
				if v_u_14.win and (v305 or v_u_14.sigDirty) then
					v_u_14.sigDirty = false
					v_u_293()
				end
				if v_u_14.again then
					v_u_14.again = false
					v_u_10.refresh(nil)
				end
			end)
		end
	else
		return
	end
end
local function v_u_326(p317) -- name: stubBuy
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	local v318 = v_u_14.stub
	local v319 = nil
	for _, v320 in v318.eligible do
		if v320.uid ~= p317 then
			continue
		end
		v319 = v320
	end
	if v319 then
		local v321 = v319.premium
		local v322 = (type(v321) ~= "number" or (v321 ~= v321 or (v321 == (1 / 0) or v321 == (-1 / 0)))) and 0 or v321
		local v323 = v318.cash
		v318.cash = ((type(v323) ~= "number" or (v323 ~= v323 or (v323 == (1 / 0) or v323 == (-1 / 0)))) and 0 or v323) - v322
		local v324 = {
			["id"] = nil,
			["uid"] = nil,
			["itemId"] = nil,
			["name"] = nil,
			["premium"] = nil,
			["raidsLeft"] = 3,
			["bought"] = nil,
			["free"] = nil,
			["id"] = "pn" .. #v318.policies,
			["uid"] = p317,
			["itemId"] = v319.id,
			["name"] = v319.name,
			["premium"] = v322,
			["bought"] = os.time(),
			["free"] = v322 == 0
		}
		local v325 = v318.policies
		table.insert(v325, v324)
		v318.used = #v318.policies
		v319.insured = v324
		v319.canBuy = false
		v319.reason = "Already insured"
		v_u_10.fillSlots(v318)
		if v322 == 0 then
			v_u_10.freeUsed(v318)
		end
	end
end
local function v_u_361(p327) -- name: onResult
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_293
	if type(p327) == "table" and p327.op == "insBuy" then
		local v328 = v_u_14.pending
		local v329
		if v328 == nil then
			v329 = false
		else
			v329 = p327.req == v328.req
		end
		if v329 then
			v_u_14.pending = nil
		end
		if p327.ok == true then
			local v330 = v_u_14
			v330.gen = v330.gen + 1
			if v329 then
				v_u_14.sel = nil
				v_u_14.err = nil
				v_u_14.flash = {
					["uid"] = v328.uid,
					["untilAt"] = os.clock() + 1.2
				}
				local v331 = v328.uid
				local v332 = v_u_14.data
				local v335
				if type(v332) == "table" then
					local v334 = v_u_14.data.eligible
					if type(v334) == "table" and v331 then
						for _, v335 in v_u_14.data.eligible do
							if v335.uid ~= v331 then
								continue
							end
						end
						v335 = nil
					else
						v335 = nil
					end
				else
					v335 = nil
				end
				local v336 = p327.data
				local v337 = type(v336) ~= "table" and {} or p327.data
				if v335 then
					local v338 = v_u_14.data
					if type(v338) == "table" then
						local v339 = v335.insured
						if type(v339) ~= "table" then
							local v340
							if v337.free == true then
								v340 = true
							elseif v335.free == true then
								local v341 = v335.premium
								v340 = ((type(v341) ~= "number" or (v341 ~= v341 or (v341 == (1 / 0) or v341 == (-1 / 0)))) and 0 or v341) <= 0
							else
								v340 = false
							end
							v335.canBuy = false
							v335.reason = "Already insured"
							local v342 = {
								["uid"] = v328.uid,
								["itemId"] = v335.id,
								["name"] = v335.name
							}
							local v343 = v337.premium
							local v344 = v335.premium
							local v345 = (type(v344) ~= "number" or (v344 ~= v344 or (v344 == (1 / 0) or v344 == (-1 / 0)))) and 0 or v344
							if type(v343) ~= "number" or (v343 ~= v343 or (v343 == (1 / 0) or v343 == (-1 / 0))) then
								v343 = v345
							end
							v342.premium = v343
							local v346 = v337.raidsLeft
							local v347 = v_u_14.data.rules
							local v348
							if type(v347) == "table" then
								v348 = v_u_14.data.rules.term
							else
								v348 = false
							end
							local v349 = (type(v348) ~= "number" or (v348 ~= v348 or (v348 == (1 / 0) or v348 == (-1 / 0)))) and 3 or v348
							if type(v346) ~= "number" or (v346 ~= v346 or (v346 == (1 / 0) or v346 == (-1 / 0))) then
								v346 = v349
							end
							v342.raidsLeft = v346
							v342.free = v337.free == true
							v335.insured = v342
							if not v_u_14.stub then
								local v350 = v_u_14.data
								local v351 = v_u_14.data.cash
								local v352 = (type(v351) ~= "number" or (v351 ~= v351 or (v351 == (1 / 0) or v351 == (-1 / 0)))) and 0 or v351
								local v353 = v337.premium
								local v354 = v335.premium
								local v355 = (type(v354) ~= "number" or (v354 ~= v354 or (v354 == (1 / 0) or v354 == (-1 / 0)))) and 0 or v354
								if type(v353) ~= "number" or (v353 ~= v353 or (v353 == (1 / 0) or v353 == (-1 / 0))) then
									v353 = v355
								end
								v350.cash = v352 - v353
								local v356 = v_u_14.data
								local v357 = v_u_14.data.used
								v356.used = ((type(v357) ~= "number" or (v357 ~= v357 or (v357 == (1 / 0) or v357 == (-1 / 0)))) and 0 or v357) + 1
							end
							if v340 then
								v_u_10.freeUsed(v_u_14.data)
							end
							v_u_10.fillSlots(v_u_14.data)
							v_u_14.sigDirty = true
						end
					end
				end
			end
			v_u_10.refresh(nil)
		else
			if v329 then
				local v358 = v_u_14
				local v359 = {
					["uid"] = v328.uid
				}
				local v360 = p327.msg
				v359.text = (type(v360) ~= "string" or p327.msg == "") and "That did not work. Try again." or p327.msg
				v358.err = v359
			end
			v_u_10.refresh(nil)
		end
		if v_u_14.win then
			v_u_293()
		end
	end
end
local function v_u_374(p_u_362, p363) -- name: confirmBuy
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) v_u_326, (copy) v_u_361, (ref) v_u_293
	if v_u_14.pending then
		return false
	end
	if p363 ~= true and os.clock() < v_u_14.armedAt then
		return false
	end
	local v364 = v_u_14.data
	local v367
	if type(v364) == "table" then
		local v366 = v_u_14.data.eligible
		if type(v366) == "table" and p_u_362 then
			for _, v367 in v_u_14.data.eligible do
				if v367.uid ~= p_u_362 then
					continue
				end
			end
			v367 = nil
		else
			v367 = nil
		end
	else
		v367 = nil
	end
	if not v367 or (v367.canBuy ~= true or not v_u_14.data) then
		return false
	end
	if v_u_10.short(v367, v_u_14.data.cash) > 0 then
		return false
	end
	local v368 = v_u_14
	v368.req = v368.req + 1
	local v369 = v_u_14.req
	local v_u_370 = "ins" .. tostring(v369)
	v_u_14.pending = {
		["uid"] = p_u_362,
		["req"] = v_u_370,
		["at"] = os.clock()
	}
	v_u_14.err = nil
	if v_u_14.stub then
		v_u_326(p_u_362)
		task.defer(v_u_361, {
			["op"] = "insBuy",
			["ok"] = true,
			["req"] = nil,
			["req"] = v_u_370
		})
	else
		local v_u_371 = v_u_14.cctx
		if not pcall(function()
			-- upvalues: (copy) v_u_371, (copy) p_u_362, (copy) v_u_370
			local v372 = {
				["op"] = "insBuy",
				["uid"] = nil,
				["req"] = nil,
				["uid"] = p_u_362,
				["req"] = v_u_370
			}
			v_u_371.net.fire("menu.op", v372)
		end) then
			v_u_14.pending = nil
			v_u_14.err = {
				["uid"] = nil,
				["text"] = "Not connected. Try again in a moment.",
				["uid"] = p_u_362
			}
		end
	end
	if v_u_14.win then
		v_u_293()
	end
	task.delay(8, function()
		-- upvalues: (ref) v_u_14, (copy) v_u_370, (copy) p_u_362, (ref) v_u_10, (ref) v_u_293
		local v373 = v_u_14.pending
		if v373 and v373.req == v_u_370 then
			v_u_14.pending = nil
			v_u_14.err = {
				["uid"] = nil,
				["text"] = "No answer from the server. Check your Cash and try again.",
				["uid"] = p_u_362
			}
			v_u_10.refresh(nil)
			if v_u_14.win then
				v_u_293()
			end
		end
	end)
	return true
end
local function v_u_380(p375) -- name: selectRow
	-- upvalues: (copy) v_u_14, (ref) v_u_293
	if v_u_14.pending then
		return
	elseif p375 == nil or v_u_14.sel ~= p375 then
		if p375 ~= nil then
			local v376 = v_u_14.data
			local v379
			if type(v376) == "table" then
				local v378 = v_u_14.data.eligible
				if type(v378) == "table" and p375 then
					for _, v379 in v_u_14.data.eligible do
						if v379.uid ~= p375 then
							continue
						end
					end
					v379 = nil
				else
					v379 = nil
				end
			else
				v379 = nil
			end
			if not v379 or v379.canBuy ~= true then
				return
			end
		end
		v_u_14.focusUid = p375 or v_u_14.sel
		v_u_14.sel = p375
		v_u_14.err = nil
		v_u_14.armedAt = os.clock() + 0.45
		v_u_14.scrollTo = p375
		v_u_293()
	end
end
function v_u_10.fitConstraint(p381, p382, p383) -- name: fitConstraint
	local v384 = p381:FindFirstChildOfClass("UITextSizeConstraint")
	if v384 then
		local v385 = (type(p383) ~= "number" or (p383 ~= p383 or (p383 == (1 / 0) or p383 == (-1 / 0)))) and 1 or p383
		local v386 = math.max(0.1, v385)
		local v387 = p382 * v386 + 0.5
		local v388 = math.floor(v387)
		local v389 = math.clamp(v388, 6, 100)
		local v390 = p382 * 0.55
		local v391 = math.floor(v390) * v386 + 0.5
		local v392 = math.floor(v391)
		local v393 = math.max(8, v392)
		local v394 = math.min(v389, v393)
		v384.MinTextSize = 1
		v384.MaxTextSize = v389
		v384.MinTextSize = v394
	end
end
local function v_u_402(p395) -- name: scaleTileText
	-- upvalues: (copy) v_u_14, (copy) v_u_7, (copy) v_u_10
	local v396 = v_u_14.scaleOverride
	local v397
	if type(v396) == "number" then
		v397 = v_u_14.scaleOverride
	else
		v397 = v_u_7.uiScale()
	end
	local v398 = v397 * v_u_14.zoom
	local v399 = v398 - 1
	if math.abs(v399) >= 0.01 and not v_u_7.isPhone() then
		for _, v400 in p395:GetDescendants() do
			if not (v400:IsA("TextLabel") and v400.TextScaled) then
				continue
			end
			local v401 = v400:FindFirstChildOfClass("UITextSizeConstraint")
			if not v401 then
				continue
			end
			v_u_10.fitConstraint(v400, v401.MaxTextSize, v398)
		end
	end
end
local function v_u_415(p403, p404, p405, p406) -- name: addLabel
	-- upvalues: (copy) v_u_7, (copy) v_u_14, (copy) v_u_10
	local v407 = p406 or {}
	v407.parent = p403
	v407.text = p404
	v407.style = p405
	local v408 = false
	if v407.fit and v_u_7.isPhone() then
		v407.fit = nil
		if (v407.lines or 1) > 1 then
			v407.wrap = true
			v407.fitWrap = false
			v408 = true
		end
	end
	local v409 = v_u_14.cctx.lib.HushUI.label(v407)
	if v408 then
		v409.TextTruncate = Enum.TextTruncate.AtEnd
	end
	if v407.fit then
		local v410 = v_u_7.styles[p405] or v_u_7.styles.body
		local v411 = v_u_10.fitConstraint
		local v412 = v407.textSize or v410.size
		local v413 = v_u_14.scaleOverride
		local v414
		if type(v413) == "number" then
			v414 = v_u_14.scaleOverride
		else
			v414 = v_u_7.uiScale()
		end
		v411(v409, v412, v414 * v_u_14.zoom)
	end
	return v409
end
local function v_u_422() -- name: openStore
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	local v_u_416 = v_u_14.cctx
	v_u_10.close()
	task.defer(function()
		-- upvalues: (copy) v_u_416, (ref) v_u_14
		local function v417()
			-- upvalues: (ref) v_u_416
			v_u_416.controllers.Menu.openStore("pass_insurance")
		end
		if not pcall(v417) then
			local v_u_418 = "The store is not available right now"
			local v_u_419 = "warn"
			local v_u_420 = "Open the STORE tab from the top bar."
			local function v421()
				-- upvalues: (ref) v_u_14, (copy) v_u_418, (copy) v_u_419, (copy) v_u_420
				v_u_14.cctx.lib.HushUI.toast(v_u_418, v_u_419, v_u_420)
			end
			pcall(v421)
		end
	end)
end
local function v_u_424(p423) -- name: stripGeo
	return p423 and {
		["h"] = 66,
		["titleY"] = 6,
		["valueY"] = 20,
		["valueH"] = 26,
		["subY"] = 46,
		["subH"] = 16
	} or {
		["h"] = 96,
		["titleY"] = 14,
		["valueY"] = 34,
		["valueH"] = 28,
		["subY"] = 66,
		["subH"] = 16
	}
end
local function v_u_434(p425, p426, p427, p428, p429, p430, p431) -- name: statBlock
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_415
	local v432 = v_u_14.cctx.lib.HushUI
	local v433 = v432.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Name"] = p431,
		["BackgroundColor3"] = v_u_9.raised,
		["Position"] = UDim2.fromOffset(p426, p427),
		["Size"] = UDim2.fromOffset(p428, p429.h)
	}, p425)
	v432.stroke(v433, v_u_9.line)
	v_u_415(v433, p430, "micro", {
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["color"] = v_u_9.text2,
		["position"] = UDim2.fromOffset(16, p429.titleY),
		["size"] = UDim2.new(1, -32, 0, 14)
	})
	return v433
end
local function v_u_519(p435, p436, p437) -- name: drawStrip
	-- upvalues: (copy) v_u_14, (copy) v_u_7, (copy) v_u_424, (copy) v_u_434, (copy) v_u_415, (copy) v_u_9, (copy) v_u_10, (copy) v_u_422
	local v438 = v_u_14.cctx.lib.HushUI
	local v439 = v_u_7.isPhone()
	local v440 = v_u_424(v439)
	local v441 = v438.new("Frame", {
		["Name"] = "Strip",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(p436, not v439 and 96 or 2 * v440.h + 8)
	}, p435)
	local v442
	if v439 then
		local v443 = (p436 - 8) / 2
		local v444 = math.floor(v443)
		v442 = {
			{ 0, 0, v444 },
			{ v444 + 8, 0, p436 - v444 - 8 },
			{ 0, v440.h + 8, v444 },
			{ v444 + 8, v440.h + 8, p436 - v444 - 8 }
		}
	else
		local v445 = p436 - 24
		local v446 = v445 * 0.2
		local v447 = math.floor(v446)
		local v448 = v445 * 0.34
		local v449 = math.floor(v448)
		local v450 = v445 * 0.26
		local v451 = math.floor(v450)
		local v452 = v445 - v447 - v449 - v451
		v442 = {
			{ 0, 0, v447 },
			{ v447 + 8, 0, v449 },
			{ v447 + v449 + 16, 0, v451 },
			{ v447 + v449 + v451 + 24, 0, v452 }
		}
	end
	local v453 = v440.valueY
	local v454 = v440.valueH
	local v455 = v440.subY
	local v456 = v440.subH
	local v457 = p437.used
	local v458 = (type(v457) ~= "number" or (v457 ~= v457 or (v457 == (1 / 0) or v457 == (-1 / 0)))) and 0 or v457
	local v459 = math.floor(v458)
	local v460 = p437.slots
	local v461 = (type(v460) ~= "number" or (v460 ~= v460 or (v460 == (1 / 0) or v460 == (-1 / 0)))) and 0 or v460
	local v462 = math.floor(v461)
	local v463 = v_u_434(v441, v442[1][1], v442[1][2], v442[1][3], v440, "POLICY SLOTS", "Stat_slots")
	local v464
	if v462 <= v459 then
		v464 = v462 > 0
	else
		v464 = false
	end
	local v465 = v_u_415
	local v466 = ("%d / %d"):format(v459, v462)
	local v467 = "monoL"
	local v468 = {
		["name"] = "Value",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true
	}
	local v469
	if v464 then
		v469 = v_u_9.accent
	else
		v469 = v_u_9.text
	end
	v468.color = v469
	v468.position = UDim2.fromOffset(16, v453)
	v468.size = UDim2.new(1, -32, 0, v454)
	v465(v463, v466, v467, v468)
	local v470 = p437.rules
	local v_u_471 = type(v470) ~= "table" and {} or p437.rules
	local v472 = v_u_415
	local v473 = v_u_471.term
	local v474 = (type(v473) ~= "number" or (v473 ~= v473 or (v473 == (1 / 0) or v473 == (-1 / 0)))) and 3 or v473
	v472(v463, ("Each lasts %d raids"):format((math.floor(v474))), "small", {
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["position"] = UDim2.fromOffset(16, v455),
		["size"] = UDim2.new(1, -32, 0, v456)
	})
	local v475 = v_u_434(v441, v442[2][1], v442[2][2], v442[2][3], v440, "RISK CLASS", "Stat_risk")
	local v476 = p437.riskClass
	local v477 = (type(v476) ~= "number" or (v476 ~= v476 or (v476 == (1 / 0) or v476 == (-1 / 0)))) and 1 or v476
	local v478 = v_u_415
	local v479 = v_u_10.riskText(v477)
	local v480 = "monoL"
	local v481 = {
		["name"] = "Value",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true
	}
	local v482 = v_u_471.riskMin
	local v483
	if ((type(v482) ~= "number" or (v482 ~= v482 or (v482 == (1 / 0) or v482 == (-1 / 0)))) and 1 or v482) + 0.001 < v477 then
		v483 = v_u_9.accent
	else
		v483 = v_u_9.text
	end
	v481.color = v483
	v481.position = UDim2.fromOffset(16, v453)
	v481.size = UDim2.new(1, -32, 0, v454)
	v478(v475, v479, v480, v481)
	v_u_415(v475, "Payouts raise it, extractions lower it.", "small", {
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["position"] = UDim2.fromOffset(16, v455),
		["size"] = UDim2.new(1, -32, 0, v456)
	})
	v438.tooltip(v475, function()
		-- upvalues: (copy) v_u_471
		local v484 = {
			["title"] = "Risk class",
			["body"] = "It multiplies every premium. A payout means you lost an insured item; an extraction means you got out with your gear.",
			["lines"] = nil
		}
		local v485 = {}
		local v486 = {}
		local v487 = v_u_471.riskPayout
		__set_list(v486, 1, {"Per payout", ("+%.2f"):format((type(v487) ~= "number" or (v487 ~= v487 or (v487 == (1 / 0) or v487 == (-1 / 0)))) and 0.15 or v487)})
		local v488 = {}
		local v489 = v_u_471.riskExtract
		__set_list(v488, 1, {"Per extraction", ("-%.2f"):format((type(v489) ~= "number" or (v489 ~= v489 or (v489 == (1 / 0) or v489 == (-1 / 0)))) and 0.05 or v489)})
		local v490 = {}
		local v491 = v_u_471.riskMin
		local v492 = (type(v491) ~= "number" or (v491 ~= v491 or (v491 == (1 / 0) or v491 == (-1 / 0)))) and 1 or v491
		local v493 = v_u_471.riskMax
		__set_list(v490, 1, {"Range", ("x%.2f to x%.2f"):format(v492, (type(v493) ~= "number" or (v493 ~= v493 or (v493 == (1 / 0) or v493 == (-1 / 0)))) and 1.6 or v493)})
		__set_list(v485, 1, {v486, v488, v490})
		v484.lines = v485
		return v484
	end)
	local v494 = v_u_434(v441, v442[3][1], v442[3][2], v442[3][3], v440, "INSURANCE PLUS", "Stat_pass")
	if p437.pass == true then
		v_u_415(v494, "OWNED", "h3", {
			["name"] = "Value",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["color"] = v_u_9.success,
			["position"] = UDim2.fromOffset(16, v453 - 2),
			["size"] = UDim2.new(1, -32, 0, v454)
		})
		local v495 = v_u_415
		local v496 = p437.freeToday == true and "Free policy today: pick one" or "Free policy today: used"
		local v497 = "small"
		local v498 = {
			["name"] = "Sub",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true
		}
		local v499
		if p437.freeToday == true then
			v499 = v_u_9.accent
		else
			v499 = v_u_9.text2
		end
		v498.color = v499
		v498.position = UDim2.fromOffset(16, v455)
		v498.size = UDim2.new(1, -32, 0, v456)
		v495(v494, v496, v497, v498)
	else
		v_u_415(v494, "NOT OWNED", "h3", {
			["name"] = "Value",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["color"] = v_u_9.text2,
			["position"] = UDim2.fromOffset(16, v453 - 2),
			["size"] = UDim2.new(1, -140, 0, v454)
		})
		local v500 = v_u_7.touch(32)
		local v501 = v438.button
		local v502 = {
			["parent"] = nil,
			["name"] = "StoreBtn",
			["text"] = "Store",
			["kind"] = "secondary",
			["height"] = 32,
			["width"] = 96,
			["anchor"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["tooltip"] = "See INSURANCE PLUS in the store",
			["parent"] = v494,
			["anchor"] = Vector2.new(1, 0)
		}
		local v503 = UDim2.new
		local v504 = v455 - 4 - v500
		v502.position = v503(1, -16, 0, (math.max(4, v504)))
		v502.onClick = v_u_422
		v501(v502)
		local v505 = v_u_415
		local v506 = v_u_471.passDiscount
		local v507 = (type(v506) ~= "number" or (v506 ~= v506 or (v506 == (1 / 0) or v506 == (-1 / 0)))) and 20 or v506
		local v508 = math.floor(v507)
		local v509 = v_u_471.returnFactorPass
		local v510 = (type(v509) ~= "number" or (v509 ~= v509 or (v509 == (1 / 0) or v509 == (-1 / 0)))) and 1.5 or v509
		v505(v494, ("%d%% off, %sx return, 1 free a day"):format(v508, (tostring(v510))), "small", {
			["name"] = "Sub",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["position"] = UDim2.fromOffset(16, v455),
			["size"] = UDim2.new(1, -32, 0, v456)
		})
	end
	local v511 = v_u_434(v441, v442[4][1], v442[4][2], v442[4][3], v440, "CASH", "Stat_cash")
	local v512 = v_u_415
	local v513 = v_u_10.money
	local v514 = p437.cash
	local v515 = v513((type(v514) ~= "number" or (v514 ~= v514 or (v514 == (1 / 0) or v514 == (-1 / 0)))) and 0 or v514)
	local v516 = "monoL"
	local v517 = {
		["name"] = "Value",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true
	}
	local v518
	if v_u_10.cashShort(p437) then
		v518 = v_u_9.danger
	else
		v518 = v_u_9.text
	end
	v517.color = v518
	v517.position = UDim2.fromOffset(16, v453)
	v517.size = UDim2.new(1, -32, 0, v454)
	v512(v511, v515, v516, v517)
	v_u_415(v511, "Premiums are paid in Cash", "small", {
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["position"] = UDim2.fromOffset(16, v455),
		["size"] = UDim2.new(1, -32, 0, v456)
	})
	return v441
end
local function v_u_532(p520, p521, p522, p523, p524) -- name: pips
	-- upvalues: (copy) v_u_14, (copy) v_u_9
	local v525 = v_u_14.cctx.lib.HushUI
	for v526 = 1, p522 do
		local v527 = v526 <= p521
		local v528 = v525.new
		local v529 = "Frame"
		local v530 = {
			["Name"] = "Pip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil
		}
		local v531
		if v527 then
			if p521 <= 1 then
				v531 = v_u_9.accent
			else
				v531 = v_u_9.success
			end
		else
			v531 = v_u_9.line
		end
		v530.BackgroundColor3 = v531
		v530.BackgroundTransparency = v527 and 0 or 0.2
		v530.Position = UDim2.fromOffset(p523 + (v526 - 1) * 18, p524)
		v530.Size = UDim2.fromOffset(14, 4)
		v528(v529, v530, p520)
	end
end
local function v_u_636(p533, p_u_534, p535, p536, p537, p538, p539) -- name: itemRow
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_292, (copy) v_u_402, (copy) v_u_7, (copy) v_u_415, (copy) v_u_10, (copy) v_u_13, (copy) v_u_380, (copy) v_u_5, (ref) v_u_293, (copy) v_u_374, (copy) v_u_3
	local v_u_540 = v_u_14.cctx.lib.HushUI
	local v541 = v_u_14.cctx.lib.MenuKit
	local v542 = v_u_540.new
	local v543 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil
	}
	local v544 = p_u_534.uid
	v543.Name = "Row_" .. tostring(v544)
	v543.Size = UDim2.new(1, 0, 0, 0)
	v543.AutomaticSize = Enum.AutomaticSize.Y
	v543.LayoutOrder = p536
	local v545 = v542("Frame", v543, p533)
	v_u_540.layout(v545, "v", 0)
	local v546
	if v_u_14.sel == p_u_534.uid then
		v546 = p535 == "buy"
	else
		v546 = false
	end
	local v547 = v_u_14.hilite == p_u_534.uid
	local v548 = v_u_540.new("Frame", {
		["Name"] = "Main",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["BackgroundColor3"] = v_u_9.raised,
		["BackgroundTransparency"] = p535 == "other" and 0.45 or 0.1,
		["Size"] = UDim2.new(1, 0, 0, 80)
	}, v545)
	local v549 = v_u_540.stroke
	local v550
	if v546 or v547 then
		v550 = v_u_9.accent
	else
		v550 = v_u_9.line
	end
	local v_u_551 = v549(v548, v550)
	local v552 = p535 == "other"
	local v553 = v541.itemCell
	local v554 = p_u_534.id
	local v555 = v553(v548, tostring(v554), {
		["size"] = 64,
		["mods"] = nil,
		["wish"] = false,
		["dim"] = nil,
		["model"] = true,
		["mods"] = v_u_292(p_u_534),
		["dim"] = v552
	})
	v555.Position = UDim2.fromOffset(8, 8)
	v_u_402(v555)
	local v556 = p537 - 88 - (v552 and 16 or 416)
	local v557 = v_u_7.isPhone()
	local v558 = {
		["name"] = "Name",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true
	}
	local v559
	if v552 then
		v559 = v_u_9.text2
	else
		v559 = v_u_9.text
	end
	v558.color = v559
	v558.position = UDim2.fromOffset(88, v552 and 16 or 14)
	v558.size = UDim2.fromOffset(v556, 20)
	if v557 then
		local v560 = UDim2.fromOffset(88, 6)
		local v561 = UDim2.fromOffset(v556, 34)
		v558.position = v560
		v558.size = v561
		v558.lines = 2
		v558.valign = "bottom"
	end
	local v562 = v_u_415
	local v563 = p_u_534.name or p_u_534.id
	v562(v548, tostring(v563), "bodyStrong", v558)
	local v564 = p_u_534.V
	local v565 = (type(v564) ~= "number" or (v564 ~= v564 or (v564 == (1 / 0) or v564 == (-1 / 0)))) and 0 or v564
	local v566 = {
		["name"] = nil,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["name"] = v552 and "Reason" or "Sub"
	}
	local v567
	if v552 then
		v567 = v_u_9.text2
	else
		v567 = nil
	end
	v566.color = v567
	v566.position = UDim2.fromOffset(88, v552 and 42 or 40)
	v566.size = UDim2.fromOffset(v556, 18)
	if v557 then
		local v568 = UDim2.fromOffset(88, 42)
		local v569 = UDim2.fromOffset(v556, 32)
		v566.position = v568
		v566.size = v569
		v566.lines = 2
		v566.valign = "top"
	end
	if v552 then
		v_u_415(v548, v_u_10.reasonText(p_u_534.reason), "small", v566)
	else
		local v570 = v_u_415
		local v571 = "%s  \194\183  Value %s"
		local v572 = v_u_13
		local v573 = p_u_534.slot
		local v574 = v572[tostring(v573)]
		if not v574 then
			local v575 = p_u_534.slot
			v574 = tostring(v575)
		end
		v570(v548, v571:format(v574, v_u_10.money(v565)), "small", v566)
	end
	if p535 == "insured" then
		local v576 = p_u_534.insured.raidsLeft
		local v577 = (type(v576) ~= "number" or (v576 ~= v576 or (v576 == (1 / 0) or v576 == (-1 / 0)))) and 0 or v576
		local v578 = math.floor(v577)
		local v579 = p538.rules
		local v580
		if type(v579) == "table" then
			v580 = p538.rules.term
		else
			v580 = false
		end
		local v581 = (type(v580) ~= "number" or (v580 ~= v580 or (v580 == (1 / 0) or v580 == (-1 / 0)))) and 3 or v580
		local v582 = math.floor(v581)
		local v583 = v_u_540.new("Frame", {
			["Name"] = "Insured",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -16, 0.5, 0),
			["Size"] = UDim2.fromOffset(400, 48)
		}, v548)
		v_u_540.icon("shield", {
			["size"] = 20,
			["color"] = nil,
			["position"] = nil,
			["parent"] = nil,
			["color"] = v_u_9.success,
			["position"] = UDim2.fromOffset(380, 2),
			["parent"] = v583
		})
		v_u_415(v583, "INSURED", "h3", {
			["name"] = "State",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["color"] = v_u_9.success,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.new(1, -28, 0, 24)
		})
		v_u_415(v583, ("%d of %d raids left"):format(v578, v582), "small", {
			["name"] = "Left",
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["position"] = UDim2.fromOffset(0, 26),
			["size"] = UDim2.new(1, -28, 0, 16)
		})
	else
		local v584 = v_u_10.short(p_u_534, p538.cash)
		local v585 = p535 == "buy"
		local v586
		if v585 then
			local v587 = p_u_534.premium
			v586 = ((type(v587) ~= "number" or (v587 ~= v587 or (v587 == (1 / 0) or v587 == (-1 / 0)))) and 0 or v587) <= 0
		else
			v586 = v585
		end
		if not v552 then
			local v588
			if v585 then
				if v584 > 0 then
					v588 = v_u_9.danger
				elseif v586 then
					v588 = v_u_9.accent
				else
					v588 = v_u_9.text
				end
			else
				v588 = v_u_9.muted
			end
			local v589
			if v586 then
				v589 = "FREE"
			else
				local v590 = v_u_10.money
				local v591 = p_u_534.premium
				local v592 = p_u_534.full
				local v593 = (type(v592) ~= "number" or (v592 ~= v592 or (v592 == (1 / 0) or v592 == (-1 / 0)))) and 0 or v592
				if type(v591) ~= "number" or (v591 ~= v591 or (v591 == (1 / 0) or v591 == (-1 / 0))) then
					v591 = v593
				end
				v589 = v590(v591)
			end
			v_u_415(v548, v589, "mono", {
				["name"] = "Price",
				["textSize"] = 18,
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["color"] = v588,
				["position"] = UDim2.new(1, -416, 0, 14),
				["size"] = UDim2.fromOffset(264, 22)
			})
			local v594 = v_u_9.muted
			local v595
			if v585 then
				if v584 > 0 then
					v595 = ("Short by %s"):format(v_u_10.money(v584))
					v594 = v_u_9.danger
				elseif v586 then
					local v596 = v_u_10.money
					local v597 = p_u_534.full
					v595 = ("Normally %s"):format(v596((type(v597) ~= "number" or (v597 ~= v597 or (v597 == (1 / 0) or v597 == (-1 / 0)))) and 0 or v597))
					v594 = v_u_9.muted
				else
					local v598 = "Premium for %d raids"
					local v599 = p538.rules
					local v600
					if type(v599) == "table" then
						v600 = p538.rules.term
					else
						v600 = false
					end
					local v601 = (type(v600) ~= "number" or (v600 ~= v600 or (v600 == (1 / 0) or v600 == (-1 / 0)))) and 3 or v600
					v595 = v598:format((math.floor(v601)))
				end
			else
				local v602 = p_u_534.reason or "Not available right now"
				v595 = tostring(v602)
				v594 = v_u_9.text2
			end
			local v603 = {
				["name"] = "PriceSub",
				["color"] = nil,
				["align"] = "right",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["color"] = v594,
				["position"] = UDim2.new(1, -416, 0, 40),
				["size"] = UDim2.fromOffset(264, 18)
			}
			if v557 then
				local v604 = UDim2.new(1, -416, 0, 42)
				local v605 = UDim2.fromOffset(264, 32)
				v603.position = v604
				v603.size = v605
				v603.lines = 2
				v603.valign = "top"
			end
			v_u_415(v548, v595, "small", v603)
			local v606 = v_u_540.button
			local v607 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = "Insure",
				["kind"] = nil,
				["width"] = 120,
				["height"] = 40,
				["anchor"] = nil,
				["position"] = nil,
				["disabled"] = nil,
				["onClick"] = nil,
				["parent"] = v548
			}
			local v608 = p_u_534.uid
			v607.name = "Insure_" .. tostring(v608)
			v607.kind = (v546 or (not v585 or v584 > 0)) and "secondary" or "primary"
			v607.anchor = Vector2.new(1, 0.5)
			v607.position = UDim2.new(1, -16, 0.5, 0)
			v607.disabled = not v585 or v584 > 0
			function v607.onClick() -- name: onClick
				-- upvalues: (ref) v_u_380, (copy) p_u_534
				v_u_380(p_u_534.uid)
			end
			local v609, v610 = v606(v607)
			v609:SetAttribute("Uid", p_u_534.uid)
			if v546 then
				v610.setSelected(true)
			end
		end
	end
	if v547 then
		v_u_551.Color = v_u_9.accent
	end
	if p535 == "insured" and (v_u_14.flash and v_u_14.flash.uid == p_u_534.uid) then
		local v_u_611 = v_u_14.flash.untilAt - os.clock()
		if v_u_611 > 0.05 then
			v_u_551.Color = v_u_9.success
			local function v612()
				-- upvalues: (ref) v_u_5, (copy) v_u_551, (copy) v_u_611, (ref) v_u_9
				v_u_5:Create(v_u_551, TweenInfo.new(v_u_611, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Color"] = v_u_9.line
				}):Play()
			end
			pcall(v612)
		else
			v_u_14.flash = nil
		end
	end
	if v546 then
		local v613 = v_u_540.new("Frame", {
			["Name"] = "Sheet",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["BackgroundColor3"] = v_u_9.raised2,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v545)
		v_u_540.stroke(v613, v_u_9.accent)
		v_u_540.pad(v613, {
			24,
			24,
			16,
			16
		})
		v_u_540.layout(v613, "v", 8)
		local v614 = v_u_415
		local v615 = p_u_534.name or p_u_534.id
		v614(v613, ("Insure %s?"):format((tostring(v615))), "bodyStrong", v557 and {
			["name"] = "Title",
			["order"] = 1,
			["wrap"] = true,
			["autoY"] = true
		} or {
			["name"] = "Title",
			["order"] = 1,
			["size"] = nil,
			["fit"] = true,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		for v616, v617 in v_u_10.confirmLines(p_u_534, p538, p539) do
			local v618 = v_u_415
			local v619 = "body"
			local v620 = {
				["name"] = "Line",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil
			}
			local v621
			if v616 == 1 then
				v621 = v_u_9.text
			else
				v621 = v_u_9.text2
			end
			v620.color = v621
			v620.order = 1 + v616
			v618(v613, v617, v619, v620)
		end
		local v622
		if v_u_14.err and v_u_14.err.uid == p_u_534.uid then
			v622 = v_u_14.err.text
		else
			v622 = nil
		end
		if v622 then
			v_u_415(v613, v622, "bodyStrong", {
				["name"] = "Error",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 20,
				["color"] = v_u_9.danger
			})
		end
		local v623 = v_u_540.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 30,
			["Size"] = UDim2.new(1, 0, 0, v_u_7.touch(40))
		}, v613)
		v_u_540.layout(v623, "h", 8, "right")
		local v624
		if v_u_14.pending == nil then
			v624 = false
		else
			v624 = v_u_14.pending.uid == p_u_534.uid
		end
		local v_u_625 = v_u_10.short(p_u_534, p538.cash)
		local v626 = {
			["parent"] = nil,
			["name"] = "Cancel",
			["text"] = "Cancel",
			["kind"] = "ghost",
			["width"] = 120,
			["height"] = 40,
			["order"] = 1,
			["disabled"] = nil,
			["onClick"] = nil,
			["parent"] = v623,
			["disabled"] = v624,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_14, (ref) v_u_293
				if not v_u_14.pending then
					v_u_14.focusUid = v_u_14.sel
					v_u_14.sel = nil
					v_u_14.err = nil
					v_u_14.armedAt = os.clock() + 0.45
					v_u_14.scrollTo = nil
					v_u_293()
				end
			end
		}
		v_u_540.button(v626)
		local v627 = p_u_534.premium
		local v628
		if ((type(v627) ~= "number" or (v627 ~= v627 or (v627 == (1 / 0) or v627 == (-1 / 0)))) and 0 or v627) <= 0 then
			v628 = "Free"
		else
			local v629 = v_u_10.money
			local v630 = p_u_534.premium
			v628 = v629((type(v630) ~= "number" or (v630 ~= v630 or (v630 == (1 / 0) or v630 == (-1 / 0)))) and 0 or v630)
		end
		local v_u_631, v_u_632 = v_u_540.button({
			["parent"] = nil,
			["name"] = "Confirm",
			["text"] = nil,
			["kind"] = "primary",
			["width"] = 240,
			["height"] = 40,
			["order"] = 2,
			["disabled"] = nil,
			["onClick"] = nil,
			["parent"] = v623,
			["text"] = v624 and "Paying..." or "Confirm  " .. v628,
			["disabled"] = v624 or (v_u_625 > 0 and true or os.clock() < v_u_14.armedAt),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_374, (copy) p_u_534
				v_u_374(p_u_534.uid)
			end
		})
		v_u_631:SetAttribute("PadDefault", true)
		v_u_631:SetAttribute("Uid", p_u_534.uid)
		local v633 = v_u_14.armedAt - os.clock()
		if v633 > 0 and not v624 then
			task.delay(v633 + 0.02, function()
				-- upvalues: (copy) v_u_631, (ref) v_u_14, (copy) p_u_534, (copy) v_u_625, (copy) v_u_632, (copy) v_u_540, (ref) v_u_3
				if v_u_631.Parent and (v_u_14.sel == p_u_534.uid and (not v_u_14.pending and v_u_625 <= 0)) then
					v_u_632.setEnabled(true)
					if v_u_540.device() == "Gamepad" then
						local v634 = v_u_3.SelectedObject
						if v634 == nil then
							v_u_3.SelectedObject = v_u_631
						else
							if not v634:IsA("GuiButton") then
								return
							end
							local v635 = v634.Name
							if string.sub(v635, 1, 7) ~= "Insure_" then
								return
							end
							v_u_3.SelectedObject = v_u_631
						end
					end
				else
					return
				end
			end)
		end
	end
	return v545
end
local function v_u_677(p637, p638, p639, p640, p641) -- name: policyRow
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_402, (copy) v_u_7, (copy) v_u_415, (copy) v_u_532, (copy) v_u_10
	local v642 = v_u_14.cctx.lib.HushUI
	local v643 = v_u_14.cctx.lib.MenuKit
	local v644 = v642.new("Frame", {
		["Name"] = "Policy",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_9.raised,
		["Size"] = UDim2.new(1, 0, 0, 64),
		["LayoutOrder"] = p639
	}, p637)
	v642.stroke(v644, v_u_9.line)
	local v645 = v643.itemCell
	local v646 = p638.itemId
	local v647 = v645(v644, tostring(v646), {
		["size"] = 48,
		["wish"] = false,
		["model"] = true
	})
	v647.Position = UDim2.fromOffset(8, 8)
	v_u_402(v647)
	local v648 = false
	for _, v649 in p641.eligible do
		if v649.uid ~= p638.uid then
			continue
		end
		v648 = true
	end
	local v650 = p641.rules
	local v651
	if type(v650) == "table" then
		v651 = p641.rules.term
	else
		v651 = false
	end
	local v652 = (type(v651) ~= "number" or (v651 ~= v651 or (v651 == (1 / 0) or v651 == (-1 / 0)))) and 3 or v651
	local v653 = math.floor(v652)
	local v654 = p638.raidsLeft
	local v655 = (type(v654) ~= "number" or (v654 ~= v654 or (v654 == (1 / 0) or v654 == (-1 / 0)))) and 0 or v654
	local v656 = math.floor(v655)
	local v657 = p640 - 72 - 300
	local v658 = v_u_7.isPhone()
	local v659 = {
		["name"] = "Name",
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["position"] = UDim2.fromOffset(72, 10),
		["size"] = UDim2.fromOffset(v657, 20)
	}
	local v660 = {
		["name"] = "Sub",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["color"] = v_u_9.text2,
		["position"] = UDim2.fromOffset(72, 34),
		["size"] = UDim2.fromOffset(v657, 18)
	}
	if v658 then
		local v661 = UDim2.fromOffset(72, 4)
		local v662 = UDim2.fromOffset(v657, 34)
		v659.position = v661
		v659.size = v662
		v659.lines = 2
		v659.valign = "bottom"
		local v663 = UDim2.fromOffset(72, 40)
		local v664 = UDim2.fromOffset(v657, 18)
		v660.position = v663
		v660.size = v664
	end
	local v665 = v_u_415
	local v666 = p638.name or p638.itemId
	v665(v644, tostring(v666), "bodyStrong", v659)
	v_u_415(v644, v648 and "Equipped" or "Not equipped", "small", v660)
	local v667 = p640 - 16 - 280
	v_u_532(v644, v656, v653, v667, 14)
	local v668 = v_u_415
	local v669 = ("%d of %d raids left"):format(v656, v653)
	local v670 = "small"
	local v671 = {
		["name"] = "Left",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil
	}
	local v672
	if v656 <= 1 then
		v672 = v_u_9.accent
	else
		v672 = v_u_9.text
	end
	v671.color = v672
	v671.position = UDim2.fromOffset(v667, 24)
	v671.size = UDim2.fromOffset(280, 18)
	v668(v644, v669, v670, v671)
	local v673 = v_u_415
	local v674
	if p638.free == true then
		v674 = "Free policy of the day"
	else
		local v675 = v_u_10.money
		local v676 = p638.premium
		v674 = ("Premium paid %s"):format(v675((type(v676) ~= "number" or (v676 ~= v676 or (v676 == (1 / 0) or v676 == (-1 / 0)))) and 0 or v676))
	end
	v673(v644, v674, "small", {
		["name"] = "Paid",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["color"] = v_u_9.muted,
		["position"] = UDim2.fromOffset(v667, 40),
		["size"] = UDim2.fromOffset(280, v658 and 18 or 16)
	})
end
local function v_u_684(p678, p679, p680, p681) -- name: emptyBox
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_415
	local v682 = v_u_14.cctx.lib.HushUI
	local v683 = v682.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.45,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = p681 or "Empty",
		["BackgroundColor3"] = v_u_9.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p680
	}, p678)
	v682.stroke(v683, v_u_9.line, 1, 0.3)
	v682.pad(v683, {
		24,
		24,
		16,
		16
	})
	v682.layout(v683, "v", 8)
	v_u_415(v683, p679, "body", {
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 1,
		["color"] = v_u_9.text2
	})
	return v683
end
local function v_u_693(p685, p686, p687, p688, p689) -- name: banner
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_415
	local v690 = v_u_14.cctx.lib.HushUI
	local v691 = v690.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = p689,
		["BackgroundColor3"] = v_u_9.raised,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p688
	}, p685)
	v690.stroke(v691, p687)
	v690.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = p687,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v691)
	local v692 = v690.new("Frame", {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v691)
	v690.pad(v692, {
		24,
		24,
		12,
		12
	})
	v_u_415(v692, p686, "body", {
		["wrap"] = true,
		["autoY"] = true
	})
	return v691
end
local function v_u_706(p_u_694, p_u_695) -- name: scrollIntoView
	local function v_u_705() -- name: fix
		-- upvalues: (copy) p_u_694, (copy) p_u_695
		if p_u_694.Parent and p_u_695.Parent then
			local v696 = p_u_695.AbsolutePosition.Y - p_u_694.AbsolutePosition.Y
			local v697 = p_u_694.AbsoluteWindowSize.Y
			local v698 = p_u_695.AbsoluteSize.Y
			if v696 < 0 or v697 < v696 + v698 then
				local v699 = p_u_694.AbsoluteCanvasSize.Y - v697
				local v700 = math.max(0, v699)
				local v701
				if v697 < v698 + 16 then
					v701 = p_u_694.CanvasPosition.Y + v696 - 8
				else
					local v702 = p_u_694.CanvasPosition.Y
					local v703 = v696 - 8
					local v704 = v696 + v698 - v697 + 8
					v701 = v702 + math.min(v703, v704)
				end
				p_u_694.CanvasPosition = Vector2.new(0, (math.clamp(v701, 0, v700)))
			end
		end
	end
	task.defer(function()
		-- upvalues: (copy) v_u_705
		task.defer(v_u_705)
	end)
	task.delay(0.7, v_u_705)
end
local function v_u_813() -- name: drawBody
	-- upvalues: (copy) v_u_14, (copy) v_u_684, (ref) v_u_293, (copy) v_u_10, (copy) v_u_7, (copy) v_u_519, (copy) v_u_9, (copy) v_u_11, (copy) v_u_693, (copy) v_u_636, (copy) v_u_116, (copy) v_u_415, (copy) v_u_677, (copy) v_u_706, (copy) v_u_3
	local v707 = v_u_14.cctx.lib.HushUI
	local v708 = v_u_14.cctx.lib.MenuKit
	local v709 = v_u_14.body
	if v709 and v709.Parent then
		local v710 = v_u_14.bodyW
		local v711 = v_u_14.bodyH
		v709:ClearAllChildren()
		local v712 = v_u_14.data
		if type(v712) == "table" then
			local v713 = v_u_7.isPhone()
			if not v713 then
				v_u_519(v709, v710, v712)
			end
			local v714 = v713 and 0 or 112
			local v_u_715 = v707.list({
				["parent"] = nil,
				["name"] = "Scroll",
				["position"] = nil,
				["size"] = nil,
				["gap"] = 16,
				["padding"] = nil,
				["parent"] = v709,
				["position"] = UDim2.fromOffset(0, v714),
				["size"] = UDim2.fromOffset(v710, v711 - v714),
				["padding"] = {
					0,
					12,
					0,
					8
				}
			})
			local v_u_716 = v707.new("Frame", {
				["Name"] = "BottomFade",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["Active"] = false,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_9.bg,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromOffset(0, v711),
				["Size"] = UDim2.fromOffset(v710, 16)
			}, v709)
			v707.new("UIGradient", {
				["Rotation"] = 90,
				["Transparency"] = nil,
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.72, 0), NumberSequenceKeypoint.new(1, 0) })
			}, v_u_716)
			local function v717() -- name: updateFade
				-- upvalues: (copy) v_u_716, (copy) v_u_715
				if v_u_716.Parent and v_u_715.Parent then
					v_u_716.Visible = v_u_715.CanvasPosition.Y + v_u_715.AbsoluteWindowSize.Y < v_u_715.AbsoluteCanvasSize.Y - 4
				end
			end
			v_u_715:GetPropertyChangedSignal("CanvasPosition"):Connect(v717)
			v_u_715:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v717)
			v_u_715:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v717)
			task.defer(v717)
			local v718 = v710 - 12 - v_u_7.scrollBar
			if v713 then
				v_u_519(v_u_715, v718, v712).LayoutOrder = 0
			end
			local v719 = v_u_10.classify(v712)
			local v720
			if v_u_14.mapAttr == nil then
				if v_u_11 then
					v720 = v_u_11:GetAttribute("MenuPlayMap")
				else
					v720 = nil
				end
			else
				v720 = v_u_14.mapAttr
			end
			local v721 = v_u_10.pickMap(v_u_14.data, v720)
			local v722 = 0
			local v723 = v712.used
			local v724 = (type(v723) ~= "number" or (v723 ~= v723 or (v723 == (1 / 0) or v723 == (-1 / 0)))) and 0 or v723
			local v725 = math.floor(v724)
			local v726 = v712.slots
			local v727 = (type(v726) ~= "number" or (v726 ~= v726 or (v726 == (1 / 0) or v726 == (-1 / 0)))) and 0 or v726
			local v728 = math.floor(v727)
			if v728 > 0 and v728 <= v725 then
				local v729 = v_u_693
				local v730 = "All %d policy slots are in use. A policy ends after %d raids, when it pays out or when the item is gone. A higher trader level opens more slots."
				local v731 = v712.rules
				local v732
				if type(v731) == "table" then
					v732 = v712.rules.term
				else
					v732 = false
				end
				local v733 = (type(v732) ~= "number" or (v732 ~= v732 or (v732 == (1 / 0) or v732 == (-1 / 0)))) and 3 or v732
				local v734 = v730:format(v728, (math.floor(v733)))
				local v735 = v_u_9.accent
				v722 = v722 + 1
				v729(v_u_715, v734, v735, v722, "LimitBanner")
			end
			local v736
			if type(v721) == "table" and v721.enabled ~= false then
				local v737 = "%s: returns after %d min"
				local v738 = v721.name
				local v739 = tostring(v738)
				local v740
				if v712.pass == true then
					v740 = v721.returnMinutesPlus
				else
					v740 = v721.returnMinutes
				end
				local v741 = (type(v740) ~= "number" or (v740 ~= v740 or (v740 == (1 / 0) or v740 == (-1 / 0)))) and 0 or v740
				v736 = v737:format(v739, (math.floor(v741)))
			else
				v736 = nil
			end
			local v742 = v708.section
			v722 = v722 + 1
			v742(v_u_715, "YOUR LOADOUT", v722, v736)
			local v743 = #v719.buy + #v719.blocked + #v719.insured > 0
			local v744 = v707.new
			local v745 = {
				["Name"] = "Rows",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}
			v722 = v722 + 1
			v745.LayoutOrder = v722
			local v746 = v744("Frame", v745, v_u_715)
			v707.layout(v746, "v", 8)
			local v747 = 0
			local v748 = nil
			local v749 = v_u_10.stableRows(v719, v_u_14.rank)
			v_u_14.rank = v749.rank
			local v750 = v748
			local v751 = v747
			for _, v752 in v749.list do
				local v753 = v752.row
				local v754 = v752.kind
				v747 = v751 + 1
				local v755 = v_u_636(v746, v753, v754, v747, v718, v712, v721)
				if v_u_14.scrollTo == v753.uid then
					v748 = v755
					v750 = v748
					v751 = v747
				else
					v751 = v747
				end
			end
			if not v743 then
				v_u_684(v746, #v719.other > 0 and "Nothing in your loadout can be insured." or "Nothing equipped. Equip a weapon, armor, a helmet, a headset or a backpack on the CHARACTER tab to insure it.", 1, "Empty")
			end
			if #v719.other > 0 then
				local v756 = v707.button
				local v757 = {
					["parent"] = nil,
					["name"] = "OtherToggle",
					["text"] = nil,
					["kind"] = "ghost",
					["height"] = 36,
					["width"] = 280,
					["order"] = 0,
					["onClick"] = nil,
					["parent"] = v_u_715
				}
				local v758
				if v_u_14.showOther then
					v758 = ("Hide other items (%d)"):format(#v719.other)
				else
					v758 = ("Show other items (%d)"):format(#v719.other)
				end
				v757.text = v758
				function v757.onClick() -- name: onClick
					-- upvalues: (ref) v_u_14, (ref) v_u_293
					v_u_14.showOther = not v_u_14.showOther
					v_u_293()
				end
				local v759 = v756(v757)
				v722 = v722 + 1
				v759.LayoutOrder = v722
				if v_u_14.showOther then
					local v760 = v707.new
					local v761 = {
						["Name"] = "Others",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}
					v722 = v722 + 1
					v761.LayoutOrder = v722
					local v762 = v760("Frame", v761, v_u_715)
					v707.layout(v762, "v", 8)
					for v763, v764 in v719.other do
						local v765 = v_u_636(v762, v764, "other", v763, v718, v712, v721)
						if v_u_14.scrollTo ~= v764.uid then
							continue
						end
						v748 = v765
						v750 = v748
					end
				end
			end
			local v766 = v_u_10.returnLines(v712, v_u_116())
			if #v766 > 0 then
				local v767 = v708.section
				v722 = v722 + 1
				v767(v_u_715, "ON THE WAY", v722)
				local v768 = v707.new
				local v769 = {
					["Name"] = "OnTheWay",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = nil,
					["BackgroundColor3"] = v_u_9.raised,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}
				v722 = v722 + 1
				v769.LayoutOrder = v722
				local v770 = v768("Frame", v769, v_u_715)
				v707.stroke(v770, v_u_9.line, 1, 0.3)
				v707.pad(v770, {
					24,
					24,
					12,
					12
				})
				v707.layout(v770, "v", 6)
				for v771, v772 in v766 do
					v_u_415(v770, v772, "body", {
						["name"] = "Line",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["color"] = v_u_9.text,
						["order"] = v771
					})
				end
			end
			local v773 = v708.section
			v722 = v722 + 1
			v773(v_u_715, "ACTIVE POLICIES", v722, ("%d / %d slots"):format(v725, v728))
			local v774 = v712.policies
			local v775 = {}
			for _, v776 in type(v774) ~= "table" and {} or v712.policies do
				table.insert(v775, v776)
			end
			table.sort(v775, function(p777, p778)
				local v779 = p777.raidsLeft
				local v780 = (type(v779) ~= "number" or (v779 ~= v779 or (v779 == (1 / 0) or v779 == (-1 / 0)))) and 0 or v779
				local v781 = p778.raidsLeft
				local v782 = (type(v781) ~= "number" or (v781 ~= v781 or (v781 == (1 / 0) or v781 == (-1 / 0)))) and 0 or v781
				if v780 ~= v782 then
					return v780 < v782
				end
				local v783 = p777.name
				local v784 = tostring(v783)
				local v785 = p778.name
				return v784 < tostring(v785)
			end)
			if #v775 == 0 then
				local v786 = v_u_684
				v722 = v722 + 1
				v786(v_u_715, "No active policies. Insure an item of your loadout above and it is covered for your next raids.", v722, "NoPolicies")
			else
				local v787 = v707.new
				local v788 = {
					["Name"] = "Policies",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}
				v722 = v722 + 1
				v788.LayoutOrder = v722
				local v789 = v787("Frame", v788, v_u_715)
				v707.layout(v789, "v", 8)
				for v790, v791 in v775 do
					v_u_677(v789, v791, v790, v718, v712)
				end
			end
			local v792 = v708.section
			v722 = v722 + 1
			v792(v_u_715, "HOW IT WORKS", v722)
			local v793 = v707.new
			local v794 = {
				["Name"] = "Rules",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_9.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}
			v722 = v722 + 1
			v794.LayoutOrder = v722
			local v795 = v793("Frame", v794, v_u_715)
			v707.stroke(v795, v_u_9.line, 1, 0.3)
			v707.pad(v795, {
				24,
				24,
				16,
				16
			})
			v707.layout(v795, "v", 8)
			for v796, v797 in v_u_10.rulesLines(v712) do
				local v798 = v_u_415
				local v799 = v796 == 1 and "bodyStrong" or "small"
				local v800 = {
					["name"] = "Line",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil
				}
				local v801
				if v796 == 1 then
					v801 = v_u_9.text
				else
					v801 = v_u_9.text2
				end
				v800.color = v801
				v800.order = v796
				v798(v795, v797, v799, v800)
			end
			if v750 then
				v_u_706(v_u_715, v750)
			end
			v_u_14.scrollTo = nil
			if v707.device() == "Gamepad" and not (v_u_3.SelectedObject and v_u_3.SelectedObject:IsDescendantOf(v709)) then
				local v802 = 0
				local v_u_803 = nil
				for _, v804 in v709:GetDescendants() do
					if not v804:IsA("GuiButton") or (not v804.Selectable or (not v804.Visible or v804:GetAttribute("Disabled") == true)) then
						continue
					end
					local v805 = 0
					local v806
					if v804.Name == "Confirm" then
						v806 = 3
					else
						local v807 = v804.Name
						v806 = string.sub(v807, 1, 7) == "Insure_" and (v804:GetAttribute("Uid") == v_u_14.focusUid and 2 or 1) or v805
					end
					if v802 >= v806 then
						continue
					end
					v_u_803 = v804
					v802 = v806
				end
				if v_u_803 then
					task.defer(function()
						-- upvalues: (copy) v_u_803, (ref) v_u_14, (ref) v_u_3
						if v_u_803.Parent and v_u_14.win then
							v_u_3.SelectedObject = v_u_803
						end
					end)
				end
			end
		else
			local v808
			if v_u_14.mc then
				local v809 = v_u_14.mc.failText
				if type(v809) == "function" then
					v808 = v_u_14.mc
				else
					v808 = nil
				end
			else
				v808 = nil
			end
			local v810 = v808 and v_u_14.err == "profile not loaded" and "Your profile is still loading. This can take a minute after a crash." or (v_u_14.err == "busy" and "Too many requests. Wait a few seconds." or "Insurance is not available right now. Check your connection and try again.")
			local v811 = v_u_684(v709, not v_u_14.failed and "Loading your policies..." or v810, 1, "State")
			if v_u_14.failed then
				local v812 = {
					["parent"] = nil,
					["name"] = "Retry",
					["text"] = "Try again",
					["kind"] = "secondary",
					["height"] = 36,
					["width"] = 160,
					["order"] = 2,
					["onClick"] = nil,
					["parent"] = v811,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_14, (ref) v_u_293, (ref) v_u_10
						v_u_14.failed = false
						v_u_293()
						v_u_10.refresh(nil)
					end
				}
				v707.button(v812)
			end
		end
	else
		return
	end
end
v_u_293 = function()
	-- upvalues: (copy) v_u_14, (copy) v_u_813, (copy) v_u_11
	if v_u_14.win and (v_u_14.body and v_u_14.body.Parent) then
		local function v814()
			-- upvalues: (ref) v_u_14, (ref) v_u_813
			v_u_14.cctx.lib.HushUI.keepScroll(v_u_14.body, v_u_813)
		end
		local v815, v816 = pcall(v814)
		if not v815 then
			warn("[MenuInsure] draw failed:", v816)
			if v_u_11 then
				v_u_11:SetAttribute("ClientError", "insure " .. "draw" .. ": " .. tostring(v816))
			end
		end
	end
end
local function v_u_819() -- name: disconnectAll
	-- upvalues: (copy) v_u_14
	for _, v817 in v_u_14.closeConn do
		v817:Disconnect()
	end
	table.clear(v_u_14.closeConn)
	for _, v818 in v_u_14.unbind do
		pcall(v818)
	end
	table.clear(v_u_14.unbind)
end
local function v_u_855() -- name: build
	-- upvalues: (copy) v_u_14, (copy) v_u_7, (copy) v_u_10, (copy) v_u_819, (copy) v_u_11, (ref) v_u_293
	local v_u_820 = v_u_14.cctx.lib.HushUI
	local v821 = v_u_7.refSize()
	local v822 = v_u_7.isPhone()
	local v823
	if v822 then
		v823 = 1
	else
		local v824 = v_u_10.zoomFor
		local v825 = v_u_14.scaleOverride
		local v826
		if type(v825) == "number" then
			v826 = v_u_14.scaleOverride
		else
			v826 = v_u_7.uiScale()
		end
		v823 = v824(v826)
	end
	v_u_14.zoom = v823
	local v827 = (v_u_7.safeRefSize().X - 32) / v823
	local v828 = math.floor(v827)
	local v829 = math.min(960, v828)
	local v_u_830 = v829 - 48
	local v831 = (v821.Y - 128) / v823
	local v832 = math.floor(v831) - 152
	local v_u_833 = math.clamp(v832, 360, 720)
	if v822 then
		local v834 = v_u_820.safeInsets()
		v_u_833 = v_u_10.phoneBodyH(v821.Y, v_u_7.space.m + v_u_7.touch(v_u_7.control) + v_u_7.space.l, v834.t + v834.b)
	end
	local v835 = v_u_14
	v_u_14.bodyW = v_u_830
	v835.bodyH = v_u_833
	local v836 = v_u_7.isTouch()
	local v_u_837 = nil
	local v839 = {
		["title"] = "Insurance",
		["width"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["build"] = nil,
		["width"] = v829,
		["buttons"] = {
			{
				["text"] = "Close",
				["kind"] = "primary",
				["hint"] = nil,
				["hint"] = not v836 and "menu" or nil
			}
		},
		["onClose"] = function() -- name: onClose
			-- upvalues: (ref) v_u_14, (ref) v_u_837, (ref) v_u_819
			if v_u_14.win == v_u_837 then
				v_u_14.win = nil
				v_u_14.body = nil
				v_u_14.sel = nil
				v_u_14.pending = nil
				v_u_14.err = nil
				v_u_14.hilite = nil
				v_u_14.showOther = false
				v_u_14.rank = nil
				v_u_14.flash = nil
				v_u_819()
			end
		end,
		["build"] = function(p838) -- name: build
			-- upvalues: (copy) v_u_820, (copy) v_u_830, (ref) v_u_833, (ref) v_u_14
			v_u_14.body = v_u_820.new("Frame", {
				["Name"] = "Body",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.fromOffset(v_u_830, v_u_833)
			}, p838)
		end
	}
	local v840 = v_u_820.modal(v839)
	v_u_14.win = v840
	if v823 > 1.001 and v840 then
		local v841 = v840.frame
		if typeof(v841) == "Instance" then
			v_u_820.new("UIScale", {
				["Name"] = "InsureZoom",
				["Scale"] = nil,
				["Scale"] = v823
			}, v840.frame)
		end
	end
	local v842 = v_u_14.cctx.controllers.Input
	if v842 then
		local v843 = v842.bind
		if type(v843) == "function" then
			local v844 = v842.bind
			local function v845()
				-- upvalues: (ref) v_u_10
				v_u_10.close()
			end
			local v846, v847 = pcall(v844, "menu", v845)
			if v846 and type(v847) == "function" then
				local v848 = v_u_14.unbind
				table.insert(v848, v847)
			end
		end
	end
	if v_u_11 then
		local v849 = v_u_14.closeConn
		local v850 = v_u_11:GetAttributeChangedSignal("MenuPlayMap")
		local function v851()
			-- upvalues: (ref) v_u_14, (ref) v_u_293
			if v_u_14.win and v_u_14.data then
				v_u_293()
			end
		end
		table.insert(v849, v850:Connect(v851))
		local v852 = v_u_14.closeConn
		local v853 = v_u_11:GetAttributeChangedSignal("MenuOpen")
		local function v854()
			-- upvalues: (ref) v_u_11, (ref) v_u_10
			if v_u_11:GetAttribute("MenuOpen") == false then
				v_u_10.close()
			end
		end
		table.insert(v852, v853:Connect(v854))
	end
	v_u_293()
end
function v_u_10.close() -- name: close
	-- upvalues: (copy) v_u_14
	local v856 = v_u_14.win
	if v856 then
		v856.close()
	end
end
local function v_u_863() -- name: applyWant
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	local v857 = v_u_14.wantUid
	if v857 then
		local v858 = v_u_14.data
		if type(v858) == "table" then
			v_u_14.wantUid = nil
			local v859 = v_u_14.data
			local v862
			if type(v859) == "table" then
				local v861 = v_u_14.data.eligible
				if type(v861) == "table" and v857 then
					for _, v862 in v_u_14.data.eligible do
						if v862.uid ~= v857 then
							continue
						end
					end
					v862 = nil
				else
					v862 = nil
				end
			else
				v862 = nil
			end
			if v862 then
				v_u_14.scrollTo = v857
				if v862.canBuy == true and v_u_10.short(v862, v_u_14.data.cash) <= 0 then
					v_u_14.sel = v857
					v_u_14.armedAt = os.clock() + 0.45
				else
					v_u_14.hilite = v857
					if v862.premium == nil then
						v_u_14.showOther = true
					end
				end
			else
				return
			end
		end
	end
end
function v_u_10.open(p864, p865) -- name: open
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) v_u_863, (ref) v_u_293, (copy) v_u_855, (copy) v_u_301
	if p864 then
		v_u_14.mc = p864
	end
	local v866 = v_u_14.cctx
	if v866 then
		p864 = v866
	elseif p864 then
		p864 = p864.cctx
	end
	if p864 then
		v_u_10.bind(p864)
		if v_u_14.win then
			if p865 then
				v_u_14.wantUid = p865
				v_u_863()
				v_u_293()
			end
			return
		else
			local v867 = v_u_14
			local v868 = v_u_14
			local v869 = v_u_14
			v_u_14.sel = nil
			v867.err = nil
			v868.hilite = nil
			v869.showOther = false
			v_u_14.pending = nil
			v_u_14.wantUid = p865
			local v870 = v_u_14
			v_u_14.rank = nil
			v870.flash = nil
			v_u_855()
			if v_u_14.stub then
				v_u_863()
				v_u_293()
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_14, (ref) v_u_301, (ref) v_u_10, (ref) v_u_863, (ref) v_u_293
					v_u_14.loading = false
					local v_u_871 = v_u_301()
					if v_u_871 then
						v_u_14.sig = v_u_10.sigOf(v_u_871)
						v_u_14.data = v_u_871
						v_u_14.rank = nil
						v_u_14.failed = false
						local function v872()
							-- upvalues: (ref) v_u_10, (copy) v_u_871
							v_u_10.changed:Fire(v_u_10.summaryOf(v_u_871))
						end
						pcall(v872)
					elseif v_u_14.data == nil then
						v_u_14.failed = true
					end
					v_u_863()
					if v_u_14.win then
						v_u_293()
					end
				end)
			end
		end
	else
		warn("[MenuInsure] open without a client context")
		return
	end
end
local function v_u_878() -- name: dumpWindow
	-- upvalues: (copy) v_u_14
	if not (v_u_14.win and v_u_14.body) then
		return "no window"
	end
	local v873 = {}
	for _, v874 in v_u_14.body:GetDescendants() do
		if v874:IsA("TextLabel") and (v874.Text ~= "" and v874.Visible) then
			local v875 = v874.Name .. ": " .. v874.Text .. (v874.TextFits and "" or "  [!]")
			table.insert(v873, v875)
		else
			if not (v874:IsA("TextButton") and v874.Visible) then
				continue
			end
			local v876 = v874:FindFirstChild("Text", true)
			local v877 = "BUTTON " .. v874.Name .. (not (v876 and v876:IsA("TextLabel")) and "" or ": " .. v876.Text) .. (v874:GetAttribute("Disabled") == true and " (disabled)" or "")
			table.insert(v873, v877)
		end
	end
	return table.concat(v873, "\n")
end
local function v_u_935(p879) -- name: registerCommands
	-- upvalues: (copy) v_u_12, (copy) v_u_10, (copy) v_u_14, (copy) v_u_11, (copy) v_u_878, (copy) v_u_7, (copy) v_u_380, (copy) v_u_374
	local v880 = p879.command
	if type(v880) == "function" and v_u_12 then
		p879.command("insure.state", function()
			-- upvalues: (ref) v_u_10, (ref) v_u_14, (ref) v_u_11
			local v881 = v_u_10.classify(v_u_14.data)
			local v882
			if v_u_14.mapAttr == nil then
				if v_u_11 then
					v882 = v_u_11:GetAttribute("MenuPlayMap")
				else
					v882 = nil
				end
			else
				v882 = v_u_14.mapAttr
			end
			local v883 = v_u_10.pickMap(v_u_14.data, v882)
			local v884 = "open=%s data=%s stub=%s slots=%s used=%s risk=%s pass=%s cash=%s map=%s sel=%s pending=%s rows buy=%d blocked=%d insured=%d other=%d policies=%d zoom=%s"
			local v885 = v_u_14.win ~= nil
			local v886 = tostring(v885)
			local v887 = v_u_14.data ~= nil
			local v888 = tostring(v887)
			local v889 = v_u_14.stub ~= nil
			local v890 = tostring(v889)
			local v891 = v_u_14.data
			if v891 then
				v891 = v_u_14.data.slots
			end
			local v892 = tostring(v891)
			local v893 = v_u_14.data
			if v893 then
				v893 = v_u_14.data.used
			end
			local v894 = tostring(v893)
			local v895 = v_u_14.data
			if v895 then
				v895 = v_u_14.data.riskClass
			end
			local v896 = tostring(v895)
			local v897 = v_u_14.data
			if v897 then
				v897 = v_u_14.data.pass
			end
			local v898 = tostring(v897)
			local v899 = v_u_14.data
			if v899 then
				v899 = v_u_14.data.cash
			end
			local v900 = tostring(v899)
			if v883 then
				v883 = v883.id
			end
			local v901 = tostring(v883)
			local v902 = v_u_14.sel
			local v903 = tostring(v902)
			local v904 = v_u_14.pending
			if v904 then
				v904 = v_u_14.pending.uid
			end
			local v905 = tostring(v904)
			local v906 = #v881.buy
			local v907 = #v881.blocked
			local v908 = #v881.insured
			local v909 = #v881.other
			local v910 = v_u_14.data and v_u_14.data.policies and #v_u_14.data.policies or 0
			local v911 = v_u_14.zoom
			return v884:format(v886, v888, v890, v892, v894, v896, v898, v900, v901, v903, v905, v906, v907, v908, v909, v910, (tostring(v911)))
		end)
		p879.command("insure.dump", function()
			-- upvalues: (ref) v_u_878
			return v_u_878()
		end)
		p879.command("insure.fonts", function()
			-- upvalues: (ref) v_u_14, (ref) v_u_7
			if not (v_u_14.win and v_u_14.body) then
				return "no window"
			end
			local v912 = 0
			local v913 = (1 / 0)
			local v914 = {}
			for _, v919 in v_u_14.body:GetDescendants() do
				if not v919:IsA("TextLabel") or (v919.Text == "" or not v919.Visible) then
					continue
				end
				local v916 = v919
				local v917 = 1
				while v919 do
					local v918 = v919:FindFirstChildOfClass("UIScale")
					if v918 then
						v917 = v917 * v918.Scale
					end
					local v919 = v919.Parent
				end
				local v920 = v916.TextSize * v917
				if v916.TextScaled then
					local v921 = v916:FindFirstChildOfClass("UITextSizeConstraint")
					if v921 then
						v920 = v921.MaxTextSize
					end
					local v922 = v916.AbsoluteSize.Y / 1.2
					v920 = math.min(v920, v922)
				end
				v912 = v912 + 1
				v913 = math.min(v913, v920)
				if v920 >= 9.5 then
					break
				end
				local v923 = v916.Name
				table.insert(v914, ("%s=%.1f"):format(v923, v920))
			end
			local v924 = "labels=%d lowest=%.1f zoom=%s scale=%.2f under9.5=%d %s"
			local v925 = v_u_14.zoom
			local v926 = tostring(v925)
			local v927 = v_u_14.scaleOverride
			local v928
			if type(v927) == "number" then
				v928 = v_u_14.scaleOverride
			else
				v928 = v_u_7.uiScale()
			end
			return v924:format(v912, v913, v926, v928, #v914, table.concat(v914, " "))
		end)
		p879.command("insure.open", function(p929)
			-- upvalues: (ref) v_u_10
			v_u_10.open(nil, p929[1])
			return "opening" .. (not p929[1] and "" or " " .. p929[1])
		end)
		p879.command("insure.close", function()
			-- upvalues: (ref) v_u_10
			v_u_10.close()
			return "closed"
		end)
		p879.command("insure.sel", function(p930)
			-- upvalues: (ref) v_u_380, (ref) v_u_14
			v_u_380(p930[1])
			local v931 = v_u_14.sel
			return "sel " .. tostring(v931)
		end)
		p879.command("insure.buy", function(p932)
			-- upvalues: (ref) v_u_14, (ref) v_u_374
			local v933 = p932[1]
			return v933 and (v_u_14.win and (v_u_374(v933, true) and "sent" or "refused (not buyable, not enough Cash or busy)") or "window is not open") or "usage: insure.buy <uid>"
		end)
		p879.command("insure.stub", function(p934)
			-- upvalues: (ref) v_u_10
			return v_u_10.setStub(p934[1] or "1")
		end)
	end
end
function v_u_10.setStub(p936) -- name: setStub
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_293
	local v937 = tostring(p936)
	if v937 == "off" then
		v_u_14.stub = nil
		v_u_14.data = nil
		v_u_10.refresh(nil)
		return "stub off"
	end
	v_u_14.stub = v_u_10.stubData(v937)
	v_u_14.data = v_u_14.stub
	v_u_14.sig = nil
	v_u_14.rank = nil
	v_u_14.pending = nil
	v_u_14.err = nil
	v_u_14.sel = nil
	v_u_14.hilite = nil
	if v937 == "4" or v937 == "confirm" then
		v_u_14.sel = "u_akm"
		v_u_14.armedAt = os.clock() - 1
	end
	if v_u_14.win then
		v_u_293()
	end
	local function v938()
		-- upvalues: (ref) v_u_10, (ref) v_u_14
		v_u_10.changed:Fire(v_u_10.summaryOf(v_u_14.data))
	end
	pcall(v938)
	return "stub " .. v937
end
function v_u_10.setMapAttr(p939) -- name: setMapAttr
	-- upvalues: (copy) v_u_14
	v_u_14.mapAttr = p939
end
function v_u_10.setScaleOverride(p940) -- name: setScaleOverride
	-- upvalues: (copy) v_u_14
	v_u_14.scaleOverride = p940
end
function v_u_10.zoom() -- name: zoom
	-- upvalues: (copy) v_u_14
	return v_u_14.zoom
end
function v_u_10.redraw() -- name: redraw
	-- upvalues: (ref) v_u_293
	v_u_293()
end
v_u_10.select = v_u_380
v_u_10.confirm = v_u_374
function v_u_10.bind(p_u_941) -- name: bind
	-- upvalues: (copy) v_u_14, (copy) v_u_361, (copy) v_u_10, (copy) v_u_935
	if p_u_941 then
		v_u_14.cctx = p_u_941
		if not v_u_14.bound then
			v_u_14.bound = true
			task.spawn(function()
				-- upvalues: (copy) p_u_941, (ref) v_u_361
				local function v942()
					-- upvalues: (ref) p_u_941, (ref) v_u_361
					p_u_941.net.listen("menu.result", v_u_361)
				end
				pcall(v942)
			end)
			task.spawn(function()
				-- upvalues: (copy) p_u_941, (ref) v_u_14, (ref) v_u_10
				local function v944()
					-- upvalues: (ref) p_u_941, (ref) v_u_14, (ref) v_u_10
					p_u_941.net.listen("menu.state", function(p943)
						-- upvalues: (ref) v_u_14, (ref) v_u_10
						if v_u_14.win and (type(p943) == "table" and not v_u_14.stub) then
							if v_u_14.refreshQueued then
								return
							end
							v_u_14.refreshQueued = true
							task.delay(0.35, function()
								-- upvalues: (ref) v_u_14, (ref) v_u_10
								v_u_14.refreshQueued = false
								v_u_10.refresh(nil)
							end)
						end
					end)
				end
				pcall(v944)
			end)
			local function v946()
				-- upvalues: (copy) p_u_941, (ref) v_u_14, (ref) v_u_10
				p_u_941.on("ui.rebuild", function()
					-- upvalues: (ref) v_u_14, (ref) v_u_10
					if v_u_14.win then
						local v_u_945 = v_u_14.sel
						v_u_14.win.close()
						task.defer(function()
							-- upvalues: (ref) v_u_10, (copy) v_u_945
							v_u_10.open(nil, v_u_945)
						end)
					end
				end)
			end
			pcall(v946)
			v_u_935(p_u_941)
		end
	else
		return
	end
end
return v_u_10