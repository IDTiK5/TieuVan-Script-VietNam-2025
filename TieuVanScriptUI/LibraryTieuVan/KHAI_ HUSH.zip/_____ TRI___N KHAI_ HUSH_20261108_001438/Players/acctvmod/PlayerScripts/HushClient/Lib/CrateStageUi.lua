-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / CrateStageUi

local v_u_1 = game:GetService("Players")
game:GetService("TweenService")
local v_u_2 = game:GetService("RunService")
local v3 = {}
local v_u_4 = {}
v_u_4.__index = v_u_4
local function v_u_8(p5, p6, p7) -- name: C
	return Color3.fromRGB(p5, p6, p7)
end
local v_u_9 = math.clamp
local function v_u_20(p10) -- name: deps
	local v11 = {}
	local v_u_12
	if p10 and p10.lib then
		v_u_12 = p10.lib
	else
		v_u_12 = nil
	end
	local v13
	if p10 and p10.shared then
		v13 = p10.shared
	else
		v13 = nil
	end
	local v14, v15 = pcall(function()
		-- upvalues: (copy) v_u_12
		if v_u_12 then
			return v_u_12.HushUI
		else
			return require(script.Parent:WaitForChild("HushUI", 5))
		end
	end)
	if not v14 or type(v15) ~= "table" then
		v15 = nil
	end
	v11.HushUI = v15
	local v16 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
	local v17
	if v13 then
		v17 = v13.Theme
	else
		v17 = require(v16:WaitForChild("Theme"))
	end
	v11.Theme = v17
	local v18
	if v13 then
		v18 = v13.Skins
	else
		v18 = require(v16:WaitForChild("Skins"))
	end
	v11.Skins = v18
	local v19
	if v13 then
		v19 = v13.SkinFinishes
	else
		v19 = require(v16:WaitForChild("SkinFinishes"))
	end
	v11.SF = v19
	return v11
end
function v3.new(p21) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_20
	local v22 = v_u_4
	local v23 = setmetatable({}, v22)
	local v_u_24 = p21 or {}
	v23.opts = v_u_24
	local v25 = v_u_1.LocalPlayer
	if not (v25 and v25:FindFirstChild("PlayerGui")) then
		error("CrateStageUi: no PlayerGui")
	end
	local v26 = v_u_20(v_u_24.cctx)
	v23.D = v26
	local v27 = v26.Theme
	v23.Theme = v27
	v23.phone = v_u_24.phone == true
	local v28 = v27.uiScale
	local v29 = 44 / math.max(0.3, v28())
	local v30 = math.ceil(v29)
	v23.touchH = math.max(44, v30)
	local v31 = v26.HushUI
	if v31 and v_u_24.cctx then
		local v32 = v31.bind
		local v33 = v_u_24.cctx
		pcall(v32, v33)
	end
	local v34, v35
	if v31 then
		v34, v35 = v31.screen("CrateStageUi", 58, {
			["insets"] = "None"
		})
	else
		local v36 = v_u_1.LocalPlayer
		if v36 then
			v36 = v_u_1.LocalPlayer:FindFirstChild("PlayerGui")
		end
		if not v36 then
			error("CrateStageUi: no PlayerGui")
		end
		v34 = Instance.new("ScreenGui")
		for v37, v38 in {
			["Name"] = "CrateStageUi",
			["ResetOnSpawn"] = false,
			["IgnoreGuiInset"] = true,
			["DisplayOrder"] = 58
		} do
			v34[v37] = v38
		end
		if v36 then
			v34.Parent = v36
		end
		local v39 = {
			["Name"] = "Root",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}
		v35 = Instance.new("Frame")
		for v40, v41 in v39 do
			v35[v40] = v41
		end
		if v34 then
			v35.Parent = v34
		end
	end
	v23.gui = v34
	v23.root = v35
	v23.items = {}
	local v42 = {
		["Name"] = "Catcher",
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Active"] = true,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v43 = Instance.new("TextButton")
	for v44, v45 in v42 do
		v43[v44] = v45
	end
	if v35 then
		v43.Parent = v35
	end
	v43.Activated:Connect(function()
		-- upvalues: (ref) v_u_24
		if v_u_24.onSkip then
			v_u_24.onSkip("tap")
		end
	end)
	v23.catcher = v43
	local v_u_46 = nil
	v43.InputBegan:Connect(function(p47)
		-- upvalues: (ref) v_u_46
		if p47.UserInputType == Enum.UserInputType.MouseButton1 or p47.UserInputType == Enum.UserInputType.Touch then
			v_u_46 = p47
		end
	end)
	v43.InputChanged:Connect(function(p48)
		-- upvalues: (ref) v_u_46, (ref) v_u_24
		if v_u_46 ~= nil and v_u_24.onDrag then
			if p48.UserInputType == Enum.UserInputType.MouseMovement or p48.UserInputType == Enum.UserInputType.Touch and p48 == v_u_46 then
				v_u_24.onDrag(p48.Delta.X)
			end
		end
	end)
	v43.InputEnded:Connect(function(p49)
		-- upvalues: (ref) v_u_46
		if p49 == v_u_46 or p49.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_46 = nil
		end
	end)
	local v50 = {
		["Name"] = "BarTop",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.new(1, 0, 0, 0)
	}
	local v51 = Instance.new("Frame")
	for v52, v53 in v50 do
		v51[v52] = v53
	end
	if v35 then
		v51.Parent = v35
	end
	v23.barTop = v51
	local v54 = {
		["Name"] = "BarBottom",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.new(1, 0, 0, 0)
	}
	local v55 = Instance.new("Frame")
	for v56, v57 in v54 do
		v55[v56] = v57
	end
	if v35 then
		v55.Parent = v35
	end
	v23.barBot = v55
	local v58 = v23.phone and 118 or 176
	v23.stripH = v58
	local v59 = {
		["Name"] = "Strip",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["Visible"] = false,
		["ZIndex"] = 5,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 1, 40),
		["Size"] = UDim2.new(1, 0, 0, v58),
		["BackgroundColor3"] = Color3.fromRGB(7, 9, 12)
	}
	local v60 = Instance.new("Frame")
	for v61, v62 in v59 do
		v60[v61] = v62
	end
	if v35 then
		v60.Parent = v35
	end
	local v63 = {
		["Name"] = "RuleTop",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 9,
		["Size"] = UDim2.new(1, 0, 0, 1),
		["BackgroundColor3"] = Color3.fromRGB(58, 69, 82)
	}
	local v64 = Instance.new("Frame")
	for v65, v66 in v63 do
		v64[v65] = v66
	end
	if v60 then
		v64.Parent = v60
	end
	local v67 = {
		["Name"] = "RuleBottom",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 9,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 1),
		["BackgroundColor3"] = Color3.fromRGB(58, 69, 82)
	}
	local v68 = Instance.new("Frame")
	for v69, v70 in v67 do
		v68[v69] = v70
	end
	if v60 then
		v68.Parent = v60
	end
	v23.strip = v60
	v23.tiles = {}
	local v71 = {
		["Name"] = "Selector",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 12,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0),
		["Size"] = UDim2.new(0, 2, 1, 0),
		["BackgroundColor3"] = Color3.fromRGB(232, 163, 61)
	}
	local v72 = Instance.new("Frame")
	for v73, v74 in v71 do
		v72[v73] = v74
	end
	if v60 then
		v72.Parent = v60
	end
	for v75, v76 in { 0, 1 } do
		local v77 = {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 13,
			["Name"] = "Dia" .. v75,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, v76, 0),
			["Size"] = UDim2.fromOffset(14, 14),
			["BackgroundColor3"] = Color3.fromRGB(232, 163, 61)
		}
		local v78 = Instance.new("Frame")
		for v79, v80 in v77 do
			v78[v79] = v80
		end
		if not v60 then
			break
		end
		v78.Parent = v60
	end
	v23.selector = v72
	local v81 = {
		["Name"] = "Stamp",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["ZIndex"] = 20,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(-0.5, 0, 0.36, 0),
		["Size"] = UDim2.fromOffset(v23.phone and 300 or 560, v23.phone and 90 or 150)
	}
	local v82 = Instance.new("Frame")
	for v83, v84 in v81 do
		v82[v83] = v84
	end
	if v35 then
		v82.Parent = v35
	end
	local v85 = {
		["Name"] = "Bar",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 21,
		["Size"] = UDim2.new(0, 6, 1, 0),
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255)
	}
	local v86 = Instance.new("Frame")
	for v87, v88 in v85 do
		v86[v87] = v88
	end
	if v82 then
		v86.Parent = v82
	end
	v23.stampBar = v86
	local v89 = {
		["Name"] = "Word",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["TextXAlignment"] = nil,
		["Text"] = "",
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.55,
		["TextStrokeColor3"] = nil,
		["ZIndex"] = 22,
		["Position"] = UDim2.fromOffset(22, 0),
		["Size"] = UDim2.new(1, -22, 0.72, 0),
		["FontFace"] = Font.fromName("Oswald", Enum.FontWeight.Bold),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextColor3"] = Color3.fromRGB(255, 255, 255),
		["TextStrokeColor3"] = Color3.fromRGB(0, 0, 0)
	}
	local v90 = Instance.new("TextLabel")
	for v91, v92 in v89 do
		v90[v91] = v92
	end
	if v82 then
		v90.Parent = v82
	end
	v23.stampWord = v90
	local v93 = {
		["MaxTextSize"] = nil,
		["MinTextSize"] = 14,
		["MaxTextSize"] = v23.phone and 70 or 130
	}
	local v94 = v23.stampWord
	local v95 = Instance.new("UITextSizeConstraint")
	for v96, v97 in v93 do
		v95[v96] = v97
	end
	if v94 then
		v95.Parent = v94
	end
	local v98 = {
		["Name"] = "Sub",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["TextXAlignment"] = nil,
		["Text"] = "",
		["TextColor3"] = nil,
		["ZIndex"] = 22,
		["Position"] = UDim2.new(0, 24, 0.72, 0),
		["Size"] = UDim2.new(1, -24, 0.26, 0),
		["FontFace"] = Font.fromName("RobotoMono", Enum.FontWeight.Medium),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextColor3"] = Color3.fromRGB(230, 232, 235)
	}
	local v99 = Instance.new("TextLabel")
	for v100, v101 in v98 do
		v99[v100] = v101
	end
	if v82 then
		v99.Parent = v82
	end
	v23.stampSub = v99
	local v102 = v23.stampSub
	local v103 = Instance.new("UITextSizeConstraint")
	for v104, v105 in {
		["MaxTextSize"] = 22,
		["MinTextSize"] = 10
	} do
		v103[v104] = v105
	end
	if v102 then
		v103.Parent = v102
	end
	v23.stampFrame = v82
	local v106 = {
		["Name"] = "Plate",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["ZIndex"] = 20,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -(v23.phone and 64 or 178)),
		["Size"] = UDim2.fromOffset(v23.phone and 480 or 760, v23.phone and 110 or 150)
	}
	local v107 = Instance.new("Frame")
	for v108, v109 in v106 do
		v107[v108] = v109
	end
	if v35 then
		v107.Parent = v35
	end
	local v110 = {
		["Name"] = "Weapon",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["Text"] = "",
		["TextColor3"] = nil,
		["ZIndex"] = 22,
		["Size"] = UDim2.new(1, 0, 0.22, 0),
		["FontFace"] = Font.fromName("RobotoMono", Enum.FontWeight.Medium),
		["TextColor3"] = Color3.fromRGB(154, 163, 174)
	}
	local v111 = Instance.new("TextLabel")
	for v112, v113 in v110 do
		v111[v112] = v113
	end
	if v107 then
		v111.Parent = v107
	end
	v23.plateWeapon = v111
	local v114 = v23.plateWeapon
	local v115 = Instance.new("UITextSizeConstraint")
	for v116, v117 in {
		["MaxTextSize"] = 22,
		["MinTextSize"] = 10
	} do
		v115[v116] = v117
	end
	if v114 then
		v115.Parent = v114
	end
	local v118 = {
		["Name"] = "Name",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["Text"] = "",
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.6,
		["ZIndex"] = 22,
		["Position"] = UDim2.fromScale(0, 0.2),
		["Size"] = UDim2.new(1, 0, 0.5, 0),
		["FontFace"] = Font.fromName("Oswald", Enum.FontWeight.Bold),
		["TextColor3"] = Color3.fromRGB(255, 255, 255)
	}
	local v119 = Instance.new("TextLabel")
	for v120, v121 in v118 do
		v119[v120] = v121
	end
	if v107 then
		v119.Parent = v107
	end
	v23.plateName = v119
	local v122 = {
		["MaxTextSize"] = nil,
		["MinTextSize"] = 16,
		["MaxTextSize"] = v23.phone and 56 or 84
	}
	local v123 = v23.plateName
	local v124 = Instance.new("UITextSizeConstraint")
	for v125, v126 in v122 do
		v124[v125] = v126
	end
	if v123 then
		v124.Parent = v123
	end
	local v127 = {
		["Name"] = "Rule",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 22,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.72),
		["Size"] = UDim2.new(0, 0, 0, 3),
		["BackgroundColor3"] = Color3.fromRGB(255, 255, 255)
	}
	local v128 = Instance.new("Frame")
	for v129, v130 in v127 do
		v128[v129] = v130
	end
	if v107 then
		v128.Parent = v107
	end
	v23.plateRule = v128
	local v131 = {
		["Name"] = "Sub",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["Text"] = "",
		["TextColor3"] = nil,
		["ZIndex"] = 22,
		["Position"] = UDim2.fromScale(0, 0.76),
		["Size"] = UDim2.new(1, 0, 0.24, 0),
		["FontFace"] = Font.fromName("RobotoMono", Enum.FontWeight.Medium),
		["TextColor3"] = Color3.fromRGB(230, 232, 235)
	}
	local v132 = Instance.new("TextLabel")
	for v133, v134 in v131 do
		v132[v133] = v134
	end
	if v107 then
		v132.Parent = v107
	end
	v23.plateSub = v132
	local v135 = v23.plateSub
	local v136 = Instance.new("UITextSizeConstraint")
	for v137, v138 in {
		["MaxTextSize"] = 24,
		["MinTextSize"] = 10
	} do
		v136[v137] = v138
	end
	if v135 then
		v136.Parent = v135
	end
	v23.plateFrame = v107
	local v139 = {
		["Name"] = "Buttons",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["ZIndex"] = 30,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -(v23.phone and 12 or 92)),
		["Size"] = UDim2.fromOffset(v23.phone and 520 or 640, not v23.phone and 52 or v23.touchH)
	}
	local v140 = Instance.new("Frame")
	for v141, v142 in v139 do
		v140[v141] = v142
	end
	if v35 then
		v140.Parent = v35
	end
	local v143 = {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["Padding"] = UDim.new(0, 12),
		["VerticalAlignment"] = Enum.VerticalAlignment.Center
	}
	local v144 = Instance.new("UIListLayout")
	for v145, v146 in v143 do
		v144[v145] = v146
	end
	if v140 then
		v144.Parent = v140
	end
	v23.row = v140
	v23.btn = {}
	local v147 = {
		["Name"] = "Skip",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["Text"] = "SKIP",
		["TextColor3"] = nil,
		["AutoButtonColor"] = false,
		["Visible"] = false,
		["ZIndex"] = 40,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -24, 1, -22),
		["Size"] = UDim2.fromOffset(v23.phone and 96 or 150, v23.touchH),
		["BackgroundColor3"] = Color3.fromRGB(14, 17, 22),
		["FontFace"] = Font.fromName("Oswald", Enum.FontWeight.Medium),
		["TextSize"] = v23.phone and 16 or 18,
		["TextColor3"] = Color3.fromRGB(230, 232, 235)
	}
	local v148 = Instance.new("TextButton")
	for v149, v150 in v147 do
		v148[v149] = v150
	end
	if v35 then
		v148.Parent = v35
	end
	local v151 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil,
		["Color"] = Color3.fromRGB(58, 69, 82),
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v152 = Instance.new("UIStroke")
	for v153, v154 in v151 do
		v152[v153] = v154
	end
	if v148 then
		v152.Parent = v148
	end
	v148.Activated:Connect(function()
		-- upvalues: (ref) v_u_24
		if v_u_24.onSkip then
			v_u_24.onSkip("button")
		end
	end)
	v23.skip = v148
	local v155 = {
		["Name"] = "SkipNote",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextXAlignment"] = nil,
		["TextColor3"] = nil,
		["Text"] = "",
		["Visible"] = false,
		["ZIndex"] = 40,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -24, 1, -70),
		["Size"] = UDim2.fromOffset(300, 20),
		["FontFace"] = Font.fromName("Roboto", Enum.FontWeight.Regular),
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextColor3"] = Color3.fromRGB(154, 163, 174)
	}
	local v156 = Instance.new("TextLabel")
	for v157, v158 in v155 do
		v156[v157] = v158
	end
	if v35 then
		v156.Parent = v35
	end
	v23.skipNote = v156
	local v159 = {
		["Name"] = "Counter",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextXAlignment"] = nil,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.6,
		["Text"] = "",
		["Visible"] = false,
		["ZIndex"] = 40,
		["Position"] = UDim2.fromOffset(28, v23.phone and 16 or 70),
		["Size"] = UDim2.fromOffset(420, 26),
		["FontFace"] = Font.fromName("RobotoMono", Enum.FontWeight.Medium),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextColor3"] = Color3.fromRGB(230, 232, 235)
	}
	local v160 = Instance.new("TextLabel")
	for v161, v162 in v159 do
		v160[v161] = v162
	end
	if v35 then
		v160.Parent = v35
	end
	v23.counterLbl = v160
	local v163 = {
		["Name"] = "Message",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextStrokeTransparency"] = 0.5,
		["Text"] = "",
		["Visible"] = false,
		["ZIndex"] = 50,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(760, 60),
		["FontFace"] = Font.fromName("Roboto", Enum.FontWeight.Medium),
		["TextColor3"] = Color3.fromRGB(230, 232, 235)
	}
	local v164 = Instance.new("TextLabel")
	for v165, v166 in v163 do
		v164[v165] = v166
	end
	if v35 then
		v164.Parent = v35
	end
	v23.msg = v164
	local v167 = {
		["Name"] = "HoldHint",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["Text"] = "",
		["Visible"] = false,
		["ZIndex"] = 40,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, v23.phone and 14 or 74),
		["Size"] = UDim2.fromOffset(420, 20),
		["FontFace"] = Font.fromName("Roboto", Enum.FontWeight.Regular),
		["TextColor3"] = Color3.fromRGB(154, 163, 174)
	}
	local v168 = Instance.new("TextLabel")
	for v169, v170 in v167 do
		v168[v169] = v170
	end
	if v35 then
		v168.Parent = v35
	end
	v23.holdHint = v168
	local v171 = {
		["Name"] = "Fade",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundTransparency"] = 0,
		["ZIndex"] = 100,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v172 = Instance.new("Frame")
	for v173, v174 in v171 do
		v172[v173] = v174
	end
	if v35 then
		v172.Parent = v35
	end
	v23.fade = v172
	v23.fadeA = 0
	local v175 = v23.warmTiles
	pcall(v175, v23)
	return v23
end
function v_u_4.designWidth(p176) -- name: designWidth
	local v177 = p176.root:FindFirstChildOfClass("UIScale")
	local v178 = (not v177 or v177.Scale <= 0) and 1 or v177.Scale
	return p176.root.AbsoluteSize.X / v178
end
function v_u_4.setFade(p179, p180) -- name: setFade
	-- upvalues: (copy) v_u_9
	p179.fade.BackgroundTransparency = 1 - v_u_9(p180, 0, 1)
	p179.fade.Visible = p180 > 0.001
end
function v_u_4.setLetterbox(p181, p182) -- name: setLetterbox
	local v183 = (p181.phone and 0 or p182) * 74
	local v184 = math.floor(v183)
	p181.barTop.Size = UDim2.new(1, 0, 0, v184)
	p181.barBot.Size = UDim2.new(1, 0, 0, v184)
end
local v_u_185 = nil
function v_u_4.warmTiles(p186) -- name: warmTiles
	-- upvalues: (ref) v_u_185
	if v_u_185 == nil then
		local v187, v188 = pcall(function()
			return require(script.Parent:WaitForChild("SkinTile", 5))
		end)
		if not v187 or type(v188) ~= "table" then
			v188 = false
		end
		v_u_185 = v188
	end
	local v189 = v_u_185 or nil
	local v190 = p186.D
	if v190 then
		v190 = p186.D.Skins
	end
	if v189 and (v190 and v190.LIST) then
		for _, v192 in v190.LIST do
			if type(v192) == "table" then
				local v192 = v192.id
			end
			local v193 = v190.get(v192)
			if not v193 then
				continue
			end
			local v194 = v189.new(p186.gui, {
				["size"] = nil,
				["weaponId"] = nil,
				["skinId"] = nil,
				["light"] = true,
				["name"] = "Warm",
				["size"] = UDim2.fromOffset(40, 40),
				["weaponId"] = v193.weapon,
				["skinId"] = v192
			})
			v194.frame.Visible = false
			v194.destroy()
			return
		end
	end
end
function v_u_4.buildStrip(p_u_195, p_u_196, _, p_u_197) -- name: buildStrip
	-- upvalues: (ref) v_u_185, (copy) v_u_8, (copy) v_u_2
	for _, v198 in p_u_195.tiles do
		v198.f:Destroy()
	end
	table.clear(p_u_195.tiles)
	p_u_195.tileGen = (p_u_195.tileGen or 0) + 1
	p_u_195.stripData = p_u_196
	local v_u_199 = p_u_195.D
	local v_u_200 = p_u_195.Theme
	local v_u_201 = p_u_196.tileW
	local v_u_202 = p_u_195.stripH - 16
	local v_u_203 = p_u_195.tileGen
	local function v_u_262(p204, p205) -- name: buildOne
		-- upvalues: (copy) v_u_199, (copy) v_u_200, (ref) v_u_185, (copy) p_u_195, (copy) v_u_201, (copy) v_u_202, (ref) v_u_8, (copy) p_u_196
		local v206 = v_u_199.Skins.get(p205)
		local v207
		if v206 then
			v207 = v_u_199.SF.get(v206.finish)
		else
			v207 = v206
		end
		local v208 = v207 and v207.swatch or {
			{ 120, 120, 120 },
			{ 60, 60, 60 }
		}
		local v209 = v206 and (v206.rarity or 1) or 1
		local v210 = v_u_200.rarity[v209] or Color3.fromRGB(107, 114, 128)
		local v211 = nil
		local v212 = nil
		if v_u_185 == nil then
			local v213, v214 = pcall(function()
				return require(script.Parent:WaitForChild("SkinTile", 5))
			end)
			if not v213 or type(v214) ~= "table" then
				v214 = false
			end
			v_u_185 = v214
		end
		local v215 = v_u_185 or nil
		local v216
		if v215 and v206 then
			local v217 = v215.new
			local v218 = p_u_195.strip
			local v219 = {
				["size"] = nil,
				["weaponId"] = nil,
				["skinId"] = nil,
				["name"] = nil,
				["colors"] = nil,
				["tex"] = nil,
				["transparency"] = 0,
				["light"] = true,
				["size"] = UDim2.fromOffset(v_u_201 - 6, v_u_202),
				["weaponId"] = v206.weapon,
				["skinId"] = p205,
				["name"] = "Tile" .. p204
			}
			local v220 = {}
			local v221 = v208[1][1]
			local v222 = v208[1][2]
			local v223 = v208[1][3]
			__set_list(v220, 1, {Color3.fromRGB(v221, v222, v223), v_u_8(v208[2][1], v208[2][2], v208[2][3])})
			v219.colors = v220
			v219.tex = p204 == p_u_196.winner
			local v224
			v224, v216 = pcall(v217, v218, v219)
			if v224 and v216 then
				v211 = v216.frame
				v211.Position = UDim2.fromOffset(0, 8)
				v211.ZIndex = 6
				v211.Visible = false
			else
				v216 = v212
			end
		else
			v216 = v212
		end
		if not v211 then
			local v225 = {
				["Name"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["ZIndex"] = 6,
				["Visible"] = false,
				["Name"] = "Tile" .. p204,
				["Position"] = UDim2.fromOffset(0, 8),
				["Size"] = UDim2.fromOffset(v_u_201 - 6, v_u_202)
			}
			local v226 = v208[1][1]
			local v227 = v208[1][2]
			local v228 = v208[1][3]
			v225.BackgroundColor3 = Color3.fromRGB(v226, v227, v228)
			local v229 = p_u_195.strip
			v211 = Instance.new("Frame")
			for v230, v231 in v225 do
				v211[v230] = v231
			end
			if v229 then
				v211.Parent = v229
			end
			local v232 = {
				["Color"] = nil,
				["Rotation"] = 60
			}
			local v233 = ColorSequence.new
			local v234 = v208[1][1]
			local v235 = v208[1][2]
			local v236 = v208[1][3]
			v232.Color = v233(Color3.fromRGB(v234, v235, v236), v_u_8(v208[2][1], v208[2][2], v208[2][3]))
			local v237 = Instance.new("UIGradient")
			for v238, v239 in v232 do
				v237[v238] = v239
			end
			if v211 then
				v237.Parent = v211
			end
		end
		local v240 = v211:FindFirstChild("Weapon")
		if v240 and not (v240:IsA("ViewportFrame") or v240:IsA("ImageLabel")) then
			v240 = nil
		end
		local v241 = v211:FindFirstChildWhichIsA("UIStroke")
		local v242 = {
			["Name"] = "Bar",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 8,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, 6),
			["BackgroundColor3"] = v210
		}
		local v243 = Instance.new("Frame")
		for v244, v245 in v242 do
			v243[v244] = v245
		end
		if v211 then
			v243.Parent = v211
		end
		local v246 = {
			["Name"] = "Weapon",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextXAlignment"] = nil,
			["TextColor3"] = nil,
			["TextStrokeTransparency"] = 0.5,
			["Text"] = nil,
			["ZIndex"] = 8,
			["Position"] = UDim2.fromOffset(8, 6),
			["Size"] = UDim2.new(1, -16, 0, 18),
			["FontFace"] = Font.fromName("RobotoMono", Enum.FontWeight.Medium),
			["TextSize"] = p_u_195.phone and 11 or 13,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextColor3"] = Color3.fromRGB(235, 238, 242),
			["Text"] = not v206 and "" or string.upper(v_u_199.Skins.weaponName(v206.weapon) or "")
		}
		local v247 = Instance.new("TextLabel")
		for v248, v249 in v246 do
			v247[v248] = v249
		end
		if v211 then
			v247.Parent = v211
		end
		local v250 = {
			["Name"] = "Skin",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextXAlignment"] = nil,
			["TextColor3"] = nil,
			["TextStrokeTransparency"] = 0.45,
			["Text"] = nil,
			["ZIndex"] = 8,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 8, 1, -12),
			["Size"] = UDim2.new(1, -16, 0, 30),
			["FontFace"] = Font.fromName("Oswald", Enum.FontWeight.Bold),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextColor3"] = Color3.fromRGB(255, 255, 255),
			["Text"] = not v206 and "" or string.upper(v206.name)
		}
		local v251 = Instance.new("TextLabel")
		for v252, v253 in v250 do
			v251[v252] = v253
		end
		if v211 then
			v251.Parent = v211
		end
		local v254 = {
			["MaxTextSize"] = nil,
			["MinTextSize"] = 9,
			["MaxTextSize"] = p_u_195.phone and 17 or 22
		}
		local v255 = Instance.new("UITextSizeConstraint")
		for v256, v257 in v254 do
			v255[v256] = v257
		end
		if v251 then
			v255.Parent = v251
		end
		local v258 = {
			["Name"] = "Dim",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 11,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.fromRGB(4, 5, 7)
		}
		local v259 = Instance.new("Frame")
		for v260, v261 in v258 do
			v259[v260] = v261
		end
		if v211 then
			v259.Parent = v211
		end
		p_u_195.tiles[p204] = {
			["f"] = v211,
			["wl"] = v247,
			["nl"] = v251,
			["dim"] = v259,
			["rar"] = v209,
			["rc"] = v210,
			["tile"] = v216,
			["vp"] = v240,
			["stroke"] = v241
		}
	end
	p_u_195.strip.Visible = false
	p_u_195.building = false
	p_u_195.buildFrames = 0
	p_u_195.buildMs = 0
	p_u_195.buildChunks = {}
	if type(p_u_197) == "number" and (p_u_197 >= 1 and #p_u_196.fields > p_u_197) then
		p_u_195.building = true
		task.spawn(function()
			-- upvalues: (copy) p_u_196, (copy) p_u_195, (copy) v_u_203, (copy) p_u_197, (copy) v_u_262, (ref) v_u_2
			local v263 = #p_u_196.fields
			local v264 = 1
			while v264 <= v263 do
				if p_u_195.tileGen ~= v_u_203 or not p_u_195.gui then
					return
				end
				local v265 = os.clock()
				local v266 = v264 + p_u_197 - 1
				for v267 = v264, math.min(v263, v266) do
					v_u_262(v267, p_u_196.fields[v267])
				end
				local v268 = p_u_195.buildChunks
				local v269 = (os.clock() - v265) * 1000
				table.insert(v268, v269)
				local v270 = p_u_195
				local v271 = p_u_195.buildMs
				local v272 = (os.clock() - v265) * 1000
				v270.buildMs = math.max(v271, v272)
				local v273 = p_u_195
				v273.buildFrames = v273.buildFrames + 1
				v264 = v264 + p_u_197
				if v264 > v263 then
					break
				end
				v_u_2.Heartbeat:Wait()
			end
			p_u_195.building = false
		end)
	else
		local v274 = os.clock()
		for v275, v276 in p_u_196.fields do
			v_u_262(v275, v276)
		end
		p_u_195.buildMs = (os.clock() - v274) * 1000
		p_u_195.buildFrames = 1
	end
end
function v_u_4.stripUpdate(p277, p278, p279, p280, p281, p282) -- name: stripUpdate
	-- upvalues: (copy) v_u_9
	local v283 = p277.stripData
	if v283 and not p277.warming then
		p277.strip.Visible = p279 > 0.001
		if p279 > 0.001 then
			local v284 = p277.strip
			local v285 = UDim2.new
			local v286 = v_u_9(p279, 0, 1)
			local v287 = (1 - v286 * v286 * (3 - v286 * 2)) * (p277.stripH + 60)
			v284.Position = v285(0.5, 0, 1, math.floor(v287) - p277.stripH - (p277.phone and 30 or 70))
			local v288 = p277:designWidth() / 2
			local v289 = v283.tileW
			local v290 = p280 <= 3
			local v291 = p280 <= 3 and 1 or 1 - v_u_9((p280 - 3) / 3, 0, 1) * 0.85
			for v292, v293 in p277.tiles do
				local v294 = v288 + (v292 - 1) * v289 - p278
				local v295
				if -v289 < v294 then
					v295 = v294 < v288 * 2 + v289
				else
					v295 = false
				end
				v293.f.Visible = v295
				if not v295 then
					continue
				end
				v293.f.Position = UDim2.fromOffset(math.floor(v294), 8)
				local v296
				if p282 == nil then
					v296 = false
				else
					v296 = v292 == p282
				end
				v293.f.BackgroundTransparency = 1 - v291
				v293.dim.BackgroundTransparency = 1 - v_u_9((v296 and 0 or p281) * 0.78, 0, 0.85)
				local v297 = v290 and 0 or 1
				v293.wl.TextTransparency = v297
				v293.nl.TextTransparency = v297
				v293.wl.TextStrokeTransparency = v290 and 0.5 or 1
				v293.nl.TextStrokeTransparency = v290 and 0.45 or 1
				v293.f.Bar.BackgroundTransparency = 1 - v291
				if v293.vp then
					v293.vp.ImageTransparency = 1 - v291
				end
				if not v293.stroke then
					continue
				end
				v293.stroke.Transparency = 1 - v291
			end
		end
	else
		return
	end
end
function v_u_4.warm(p298, p299) -- name: warm
	local v300 = p298.stripData
	if v300 then
		p298.warming = p299
		if p299 then
			p298.strip.Position = UDim2.new(0.5, 0, 1, -p298.stripH - (p298.phone and 30 or 70))
			p298.strip.Visible = true
			local v301 = p298:designWidth() / 2 - (v300.tileW - 6) / 2
			local v302 = math.floor(v301)
			for _, v303 in p298.tiles do
				v303.f.Position = UDim2.fromOffset(v302, 8)
				v303.f.BackgroundTransparency = 0.985
				v303.f.Bar.BackgroundTransparency = 0.985
				v303.dim.BackgroundTransparency = 1
				local v304 = v303.wl
				local v305 = v303.nl
				v304.TextTransparency = 0.985
				v305.TextTransparency = 0.985
				local v306 = v303.wl
				local v307 = v303.nl
				v306.TextStrokeTransparency = 1
				v307.TextStrokeTransparency = 1
				if v303.vp then
					v303.vp.ImageTransparency = 0.985
				end
				if v303.stroke then
					v303.stroke.Transparency = 0.985
				end
				v303.f.Visible = true
				v303.warmed = true
			end
		else
			p298.strip.Visible = false
			for _, v308 in p298.tiles do
				v308.f.Visible = false
				v308.f.BackgroundTransparency = 0
				v308.f.Bar.BackgroundTransparency = 0
				v308.dim.BackgroundTransparency = 1
				local v309 = v308.wl
				local v310 = v308.nl
				v309.TextTransparency = 0
				v310.TextTransparency = 0
				if v308.vp then
					v308.vp.ImageTransparency = 0
				end
				if not v308.stroke then
					continue
				end
				v308.stroke.Transparency = 0
			end
		end
	else
		return
	end
end
function v_u_4.warmedCount(p311) -- name: warmedCount
	local v312 = 0
	for _, v313 in p311.tiles do
		if not v313.warmed then
			continue
		end
		v312 = v312 + 1
	end
	return v312
end
local v_u_314 = game:GetService("ContentProvider")
local v_u_315 = {
	"ColorMap",
	"NormalMap",
	"MetalnessMap",
	"RoughnessMap"
}
local function v_u_345(p316) -- name: pendingOf
	-- upvalues: (copy) v_u_314, (copy) v_u_315
	if p316:IsA("ImageLabel") or p316:IsA("ImageButton") then
		if p316.Image ~= "" and not p316.IsLoaded then
			local v_u_317 = p316.Image
			local v318
			if type(v_u_317) == "string" and v_u_317 ~= "" then
				local function v319()
					-- upvalues: (ref) v_u_314, (copy) v_u_317
					return v_u_314:GetAssetFetchStatus(v_u_317)
				end
				local v320, v321 = pcall(v319)
				v318 = not (v320 and v321) and "None" or v321.Name
			else
				v318 = "Success"
			end
			if v318 ~= "Failure" then
				return 1
			end
		end
	else
		if p316:IsA("MeshPart") then
			local v322 = 0
			if p316.MeshId ~= "" then
				local v_u_323 = p316.MeshId
				local v324
				if type(v_u_323) == "string" and v_u_323 ~= "" then
					local function v325()
						-- upvalues: (ref) v_u_314, (copy) v_u_323
						return v_u_314:GetAssetFetchStatus(v_u_323)
					end
					local v326, v327 = pcall(v325)
					v324 = not (v326 and v327) and "None" or v327.Name
				else
					v324 = "Success"
				end
				if v324 == "Loading" then
					v322 = v322 + 1
				end
			end
			if p316.TextureID ~= "" then
				local v_u_328 = p316.TextureID
				local v329
				if type(v_u_328) == "string" and v_u_328 ~= "" then
					local function v330()
						-- upvalues: (ref) v_u_314, (copy) v_u_328
						return v_u_314:GetAssetFetchStatus(v_u_328)
					end
					local v331, v332 = pcall(v330)
					v329 = not (v331 and v332) and "None" or v332.Name
				else
					v329 = "Success"
				end
				if v329 == "Loading" then
					v322 = v322 + 1
				end
			end
			return v322
		end
		if p316:IsA("SurfaceAppearance") then
			local v333 = 0
			for _, v334 in v_u_315 do
				local v_u_335 = p316[v334]
				local v336
				if type(v_u_335) == "string" and v_u_335 ~= "" then
					local function v337()
						-- upvalues: (ref) v_u_314, (copy) v_u_335
						return v_u_314:GetAssetFetchStatus(v_u_335)
					end
					local v338, v339 = pcall(v337)
					v336 = not (v338 and v339) and "None" or v339.Name
				else
					v336 = "Success"
				end
				if v336 ~= "Loading" then
					continue
				end
				v333 = v333 + 1
			end
			return v333
		end
		if p316:IsA("Decal") or p316:IsA("Texture") then
			local v_u_340 = p316.Texture
			local v341
			if type(v_u_340) == "string" and v_u_340 ~= "" then
				local function v342()
					-- upvalues: (ref) v_u_314, (copy) v_u_340
					return v_u_314:GetAssetFetchStatus(v_u_340)
				end
				local v343, v344 = pcall(v342)
				v341 = not (v343 and v344) and "None" or v344.Name
			else
				v341 = "Success"
			end
			if v341 == "Loading" then
				return 1
			end
		end
	end
	return 0
end
function v_u_4.reelUnloaded(p346) -- name: reelUnloaded
	-- upvalues: (copy) v_u_345
	local v347 = 0
	for _, v348 in p346.tiles do
		if v348.warmed then
			continue
		end
		v347 = v347 + 1
	end
	if p346.gui then
		for _, v349 in p346.gui:GetDescendants() do
			v347 = v347 + v_u_345(v349)
		end
	end
	return v347
end
function v_u_4.winnerPunch(p350, p351, p352) -- name: winnerPunch
	-- upvalues: (copy) v_u_9
	local v353 = p350.tiles[p351]
	if v353 then
		local v354 = v_u_9(p352, 0, 1) * 3.141592653589793
		local v355 = math.sin(v354) * 0.12 + 1
		local v356 = p350.stripData.tileW
		local v357 = p350.stripH - 16
		local v358 = v353.f
		local v359 = UDim2.fromOffset
		local v360 = (v356 - 6) * v355
		local v361 = math.floor(v360)
		local v362 = v357 * v355
		v358.Size = v359(v361, (math.floor(v362)))
		v353.f.ZIndex = 10
	end
end
function v_u_4.shuffleShow(p363, p364, p365, p366) -- name: shuffleShow
	p363.strip.Visible = p366 > 0.001
	p363.strip.Position = UDim2.new(0.5, 0, 1, -p363.stripH - (p363.phone and 30 or 70))
	local v367 = p363:designWidth() / 2
	local v368 = p364.tileW
	for v369, v370 in p363.tiles do
		local v371 = v369 == p365
		v370.f.Visible = v371
		if not v371 then
			continue
		end
		local v372 = v370.f
		local v373 = UDim2.fromOffset
		local v374 = v367 - (v368 - 6) / 2
		v372.Position = v373(math.floor(v374), 8)
		v370.f.BackgroundTransparency = 0
		v370.dim.BackgroundTransparency = 1
		local v375 = v370.wl
		local v376 = v370.nl
		v375.TextTransparency = 0
		v376.TextTransparency = 0
	end
end
function v_u_4.stamp(p377, p378, p379, p380) -- name: stamp
	-- upvalues: (copy) v_u_9
	local v381 = p377.Theme
	local v382 = p377.stampFrame
	if p379 <= 0 then
		v382.Visible = false
	else
		v382.Visible = true
		local v383 = (p380 or (v381.rarity[p378] or Color3.fromRGB(255, 255, 255))):Lerp(Color3.fromRGB(255, 255, 255), 0.1)
		p377.stampWord.Text = v381.rarityName[p378] or ""
		p377.stampWord.TextColor3 = v383
		p377.stampBar.BackgroundColor3 = v383
		local v384 = v_u_9(p379, 0, 1)
		local v385 = v_u_9(v384 * v384 * (3 - v384 * 2), 0, 1) - 1
		local v386 = v385 * 2.4 * v385 * v385 + 1 + v385 * 1.4 * v385
		local v387 = p377.phone and 28 or 70
		local v388 = UDim2.new
		local v389 = (v387 + 420) * v386 + -420
		v382.Position = v388(0, math.floor(v389), 0.36, 0)
		local v390 = 1 - v_u_9(p379 * 1.6, 0, 1)
		p377.stampWord.TextTransparency = v390
		p377.stampBar.BackgroundTransparency = v390
		p377.stampWord.TextStrokeTransparency = v390 * 0.45 + 0.55
		p377.stampSub.TextTransparency = 1 - v_u_9(p379 * 1.2 - 0.3, 0, 1)
	end
end
function v_u_4.stampSubText(p391, p392) -- name: stampSubText
	p391.stampSub.Text = p392
end
function v_u_4.plate(p393, p394, p395) -- name: plate
	-- upvalues: (copy) v_u_9
	local v396 = p393.plateFrame
	if p394 and p395 > 0 then
		v396.Visible = true
		local v397 = p393.Theme
		local v398 = (p394.glow or (v397.rarity[p394.rarity] or Color3.fromRGB(255, 255, 255))):Lerp(Color3.fromRGB(255, 255, 255), 0.1)
		p393.plateWeapon.Text = p394.weapon or ""
		p393.plateName.Text = string.upper(p394.name or "")
		p393.plateName.TextColor3 = Color3.fromRGB(255, 255, 255):Lerp(v398, 0.35)
		p393.plateRule.BackgroundColor3 = v398
		p393.plateSub.Text = p394.line or ""
		p393.plateSub.TextColor3 = v398
		local v399 = v_u_9(p395, 0, 1)
		local v400 = v399 * v399 * (3 - v399 * 2)
		local v401 = UDim2.new
		local v402 = -(p393.phone and 64 or 178)
		local v403 = (1 - v400) * 36
		v396.Position = v401(0.5, 0, 1, v402 + math.floor(v403))
		local v404 = 1 - v_u_9(p395 * 1.5, 0, 1)
		p393.plateWeapon.TextTransparency = v404
		p393.plateName.TextTransparency = v404
		p393.plateName.TextStrokeTransparency = v404 * 0.4 + 0.6
		p393.plateSub.TextTransparency = v404
		p393.plateRule.BackgroundTransparency = v404
		local v405 = p393.plateRule
		local v406 = UDim2.new
		local v407 = v400 * (p393.phone and 300 or 480)
		v405.Size = v406(0, math.floor(v407), 0, 3)
	else
		v396.Visible = false
	end
end
function v_u_4.buttons(p_u_408, p409, p410) -- name: buttons
	local v411 = p_u_408.D.HushUI
	if p410 and not p_u_408.btnBuilt then
		p_u_408.btnBuilt = true
		for v412, v413 in p410 do
			local v_u_414 = v413.id
			local function v419()
				-- upvalues: (copy) p_u_408, (copy) v_u_414
				local v415 = v_u_414
				local v416 = string.upper((string.sub(v415, 1, 1)))
				local v417 = v_u_414
				local v418 = p_u_408.opts["on" .. v416 .. string.sub(v417, 2)]
				if v418 then
					v418(v_u_414)
				end
			end
			local v420
			if v411 then
				v420 = v411.button({
					["parent"] = nil,
					["text"] = nil,
					["kind"] = nil,
					["onClick"] = nil,
					["height"] = nil,
					["width"] = nil,
					["name"] = nil,
					["sound"] = false,
					["parent"] = p_u_408.row,
					["text"] = v413.text,
					["kind"] = v413.kind or "secondary",
					["onClick"] = v419,
					["height"] = not p_u_408.phone and 48 or p_u_408.touchH,
					["width"] = v413.width or (p_u_408.phone and 150 or 190),
					["name"] = "Btn_" .. v_u_414
				})
			else
				local v421 = {
					["Name"] = "Btn_" .. v_u_414,
					["Size"] = UDim2.fromOffset(190, 48),
					["Text"] = v413.text,
					["LayoutOrder"] = v412
				}
				local v422 = p_u_408.row
				v420 = Instance.new("TextButton")
				for v423, v424 in v421 do
					v420[v423] = v424
				end
				if v422 then
					v420.Parent = v422
				end
				v420.Activated:Connect(v419)
			end
			v420.LayoutOrder = v412
			p_u_408.btn[v_u_414] = v420
		end
	end
	p_u_408.row.Visible = p409
	if p409 then
		for _, v425 in p_u_408.btn do
			v425.Visible = true
		end
	end
end
function v_u_4.buttonVisible(p426, p427, p428) -- name: buttonVisible
	local v429 = p426.btn[p427]
	if v429 then
		v429.Visible = p428
	end
end
function v_u_4.buttonText(p430, p431, p432) -- name: buttonText
	local v433 = p430.btn[p431]
	local v434 = v433 and v433:FindFirstChild("Text", true)
	if v434 then
		v434.Text = string.upper(p432)
	end
end
function v_u_4.skipHint(p435, p436, p437) -- name: skipHint
	p435.skip.Visible = p436
	local v438 = p435.skipNote
	if p436 then
		p436 = p437 ~= nil
	end
	v438.Visible = p436
	if p437 then
		p435.skipNote.Text = p437
	end
end
function v_u_4.counter(p439, p440) -- name: counter
	local v441 = p439.counterLbl
	local v442
	if p440 == nil then
		v442 = false
	else
		v442 = p440 ~= ""
	end
	v441.Visible = v442
	p439.counterLbl.Text = p440 or ""
end
function v_u_4.holdHintText(p443, p444) -- name: holdHintText
	local v445 = p443.holdHint
	local v446
	if p444 == nil then
		v446 = false
	else
		v446 = p444 ~= ""
	end
	v445.Visible = v446
	p443.holdHint.Text = p444 or ""
end
function v_u_4.message(p447, p448) -- name: message
	local v449 = p447.msg
	local v450
	if p448 == nil then
		v450 = false
	else
		v450 = p448 ~= ""
	end
	v449.Visible = v450
	p447.msg.Text = p448 or ""
end
function v_u_4.count(p451) -- name: count
	if not p451.gui then
		return 0
	end
	local v452 = 0
	for _, v453 in p451.gui:GetDescendants() do
		if v453:FindFirstAncestorWhichIsA("ViewportFrame") then
			continue
		end
		v452 = v452 + 1
	end
	return v452
end
function v_u_4.destroy(p_u_454) -- name: destroy
	if p_u_454.gui then
		pcall(function()
			-- upvalues: (copy) p_u_454
			p_u_454.gui:Destroy()
		end)
	end
	p_u_454.gui = nil
end
return v3