-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuWhy

local v_u_1 = {}
local function v_u_7(p2) -- name: commas
	local v3 = math.abs(p2) + 0.5
	local v4 = math.floor(v3)
	local v5 = tostring(v4)
	repeat
		local v6
		v5, v6 = string.gsub(v5, "^(%d+)(%d%d%d)", "%1,%2")
	until v6 == 0
	return v5
end
local function v_u_11(p8) -- name: money
	-- upvalues: (copy) v_u_7
	local v9 = p8 + 0.5
	local v10 = math.floor(v9)
	return (v10 < 0 and "-$" or "$") .. v_u_7(v10)
end
v_u_1.money = v_u_11
v_u_1.FETCH_REASON = {
	["profile not loaded"] = "Your profile is still loading. This can take a minute after a crash.",
	["busy"] = "Too many requests. Wait a few seconds."
}
function v_u_1.failText(p12, p13) -- name: failText
	-- upvalues: (copy) v_u_1
	return type(p12) == "string" and v_u_1.FETCH_REASON[p12] or p13
end
v_u_1.PAGE_FAILED = "This screen could not be loaded. Close and reopen the menu. If it stays, rejoin HUSH."
v_u_1.MARKET_PAGE_FAILED = "This page could not be loaded. Close and reopen the menu. If it stays, rejoin HUSH."
v_u_1.REFUSED_SUB = "The server did not say why. Try once more; if it repeats, rejoin HUSH."
v_u_1.TOAST = {
	["notConnected"] = nil,
	["squads"] = nil,
	["hideoutSlow"] = nil,
	["insurance"] = nil,
	["store"] = nil,
	["cutscenes"] = nil,
	["scene"] = nil,
	["pingCargo"] = "What lies in a cargo crate is private, so it cannot be pinged.",
	["pingNo"] = "You cannot ping this item.",
	["transit"] = "You are already on your way somewhere. Wait for the loading screen.",
	["notConnected"] = { "Not connected", "The profile service is not available yet. Wait a few seconds and try again. If it stays, rejoin HUSH." },
	["squads"] = { "Squads are not available right now", "The squad service is still starting. Try again in a few seconds." },
	["hideoutSlow"] = { "The hideout is not reachable right now", "Nothing happened. Try once more; if it repeats, rejoin HUSH." },
	["insurance"] = { "Insurance is not available right now", "The window could not open. Close the menu and open it again." },
	["store"] = { "The store is not available right now", "Open the STORE tab from the top bar." },
	["cutscenes"] = { "Cutscenes are not available right now", "Try again after the next menu open." },
	["scene"] = { "The scene could not be played", "Try again after the next menu open." }
}
v_u_1.CLOCK_LABEL = "SERVER TIME"
v_u_1.CLOCK_TIP = "Server time (UTC). Weekly and daily resets use it."
function v_u_1.clockText(p14) -- name: clockText
	-- upvalues: (copy) v_u_1
	return v_u_1.CLOCK_LABEL .. "  " .. p14
end
v_u_1.TEMP_TITLE = "Your progress is not being saved"
v_u_1.TEMP_BODY = "Roblox\'s data service did not answer. What you earn in this session is lost when you leave. Rejoin later to play with saving."
v_u_1.TEMP_FOOT = "NOT SAVING"
v_u_1.TEMP_TIP = "Badges, leaderboard and titles wait until saving works again."
function v_u_1.footerSaving(p15, p16, p17) -- name: footerSaving
	-- upvalues: (copy) v_u_1
	local v18 = string.gsub(p15, "&", "&amp;")
	local v19 = string.gsub(v18, "<", "&lt;")
	local v20 = string.gsub(v19, ">", "&gt;")
	if p16 then
		return v20 .. "  \194\183  <font color=\"" .. p17 .. "\">" .. v_u_1.TEMP_FOOT .. "</font>"
	else
		return v20
	end
end
v_u_1.TEMP_POP_HEAD1 = "YOUR ITEMS ARE SAFE,"
v_u_1.TEMP_POP_HEAD2 = "BUT THIS SESSION IS NOT SAVING"
v_u_1.TEMP_POP_TITLE = v_u_1.TEMP_POP_HEAD1 .. " " .. v_u_1.TEMP_POP_HEAD2
v_u_1.TEMP_POP_LINES = {
	{
		["text"] = "Roblox\'s data service did not answer when you joined. Your real stash, cash and progress are safe and untouched.",
		["marks"] = nil,
		["marks"] = {
			{ "safe and untouched", "ok" }
		}
	},
	{
		["text"] = "This is a temporary empty profile. Nothing you do now is kept, so do not play raids.",
		["marks"] = nil,
		["marks"] = {
			{ "temporary empty profile", "bad" },
			{ "Nothing you do now is kept", "bad" }
		}
	},
	{
		["text"] = "Rejoin to load your real profile. If this comes back, wait a few minutes and try again.",
		["marks"] = nil,
		["marks"] = {
			{ "Rejoin to load your real profile", "ok" }
		}
	}
}
v_u_1.TEMP_POP_REJOIN = "REJOIN NOW"
v_u_1.TEMP_POP_REJOINING = "REJOINING"
v_u_1.TEMP_POP_HOLD = "HOLD TO CONFIRM"
v_u_1.TEMP_POP_DONE = "CONFIRMED"
v_u_1.TEMP_POP_REJOIN_FAIL = { "Could not rejoin", "Close HUSH and join the game again." }
function v_u_1.tempPopupLine(p21, p22, p23) -- name: tempPopupLine
	local v24 = string.gsub
	local v25 = p21.text
	local v26 = v24(tostring(v25), "&", "&amp;")
	local v27 = string.gsub(v26, "<", "&lt;")
	local v28 = string.gsub(v27, ">", "&gt;")
	for _, v29 in p21.marks or {} do
		local v30, v31 = string.find(v28, v29[1], 1, true)
		if v30 == nil then
			continue
		end
		local v32
		if v29[2] == "ok" then
			v32 = p22
		else
			v32 = p23
		end
		local v33 = v30 - 1
		local v34 = string.sub(v28, 1, v33)
		local v35 = string.sub(v28, v30, v31)
		local v36 = v31 + 1
		v28 = v34 .. "<font color=\"" .. v32 .. "\">" .. v35 .. "</font>" .. string.sub(v28, v36)
	end
	return v28
end
function v_u_1.tempPopupLines(p37, p38) -- name: tempPopupLines
	-- upvalues: (copy) v_u_1
	local v39 = {}
	for _, v40 in v_u_1.TEMP_POP_LINES do
		local v41 = v_u_1.tempPopupLine
		table.insert(v39, v41(v40, p37, p38))
	end
	return v39
end
v_u_1.CUT_TITLE = "Raid cut short"
v_u_1.CUT_TAIL = "Nothing from that raid counted: no experience, kills or task progress."
v_u_1.CUT_FRESH = 1800
function v_u_1.cutShort(p42) -- name: cutShort
	-- upvalues: (copy) v_u_1
	local v43 = (type(p42) ~= "string" or p42 == "") and "The server closed during your raid. You kept what you carried." or p42
	if string.find(v43, "counted", 1, true) then
		return v_u_1.CUT_TITLE, v43
	else
		return v_u_1.CUT_TITLE, v43 .. " " .. v_u_1.CUT_TAIL
	end
end
function v_u_1.cutShortDue(p44, p45, p46) -- name: cutShortDue
	-- upvalues: (copy) v_u_1
	if type(p44) == "table" and p44.outcome == "Interrupted" then
		local v47 = p44.note
		if type(v47) == "string" then
			local v48 = p44.at
			if type(v48) == "number" then
				if p46 == p44.at then
					return false
				end
				local v49 = p45 - p44.at
				local v50
				if v49 >= -60 then
					v50 = v49 < v_u_1.CUT_FRESH
				else
					v50 = false
				end
				return v50
			end
		end
	end
	return false
end
function v_u_1.isCardNotice(p51) -- name: isCardNotice
	if type(p51) == "string" then
		return p51 == "deploy_failed" and true or string.sub(p51, 1, 5) == "home_"
	else
		return false
	end
end
function v_u_1.noticeCard(p52) -- name: noticeCard
	local v53
	if type(p52) == "table" then
		v53 = p52.code
	else
		v53 = nil
	end
	local v54
	if type(p52) == "table" then
		local v55 = p52.text
		v54 = type(v55) ~= "string" and "" or p52.text
	else
		v54 = ""
	end
	if v53 == "deploy_failed" then
		return "The raid did not start", v54
	else
		return "Back in the lobby", v54
	end
end
function v_u_1.waitingToast(p56) -- name: waitingToast
	local v57 = tonumber(p56) or 0
	local v58 = (v57 ~= v57 or v57 < 0) and 0 or math.floor(v57)
	if v58 <= 0 then
		return "", nil
	else
		local v59 = "Items are waiting for stash room."
		local v60 = string.format("%d items move in by themselves as soon as you free some space.", v58)
		if v58 == 1 then
			return v59, "1 item moves in by itself as soon as you free some space."
		else
			return v59, v60
		end
	end
end
function v_u_1.characterTip(p61) -- name: characterTip
	local v62 = tonumber(p61) or 0
	local v63 = (v62 ~= v62 or v62 < 0) and 0 or math.floor(v62)
	return v63 <= 0 and "Your loadout, stash and skills." or (v63 == 1 and "1 item is waiting because your stash is full. Free some space and it moves in by itself." or string.format("%d items are waiting because your stash is full. Free some space and they move in by themselves.", v63))
end
function v_u_1.hideoutTip(p64) -- name: hideoutTip
	local v65 = tonumber(p64) or 0
	local v66 = (v65 ~= v65 or v65 < 0) and 0 or math.floor(v65)
	if v66 <= 0 then
		return "Walk into your basement under the gas station: stash rack, workbench, med station and more."
	end
	local v67 = string.format("%d finished crafts wait for you in the hideout. Walk to the station and press COLLECT.", v66)
	return v66 == 1 and "1 finished craft waits for you in the hideout. Walk to the station and press COLLECT." or v67
end
function v_u_1.hideoutBuilt(p68, p69) -- name: hideoutBuilt
	local v70 = (type(p68) ~= "string" or p68 == "") and "A station" or string.upper((string.sub(p68, 1, 1))) .. string.lower((string.sub(p68, 2)))
	local v71 = tonumber(p69) or 0
	local v72 = (v71 ~= v71 or v71 < 0) and 0 or math.floor(v71)
	if v72 >= 1 then
		return string.format("%s level %d is built.", v70, v72)
	else
		return v70 .. " is built."
	end
end
function v_u_1.levelNews(p73, p74) -- name: levelNews
	local v75 = tonumber(p73) or 0
	local v76 = (v75 ~= v75 or v75 < 0) and 0 or math.floor(v75)
	local v77 = tonumber(p74) or 0
	local v78 = (v77 ~= v77 or v77 < 0) and 0 or math.floor(v77)
	if v76 > 0 and v78 > 0 then
		return string.format("%d new %s in TRADERS, %d more need a task", v76, v76 == 1 and "offer" or "offers", v78)
	elseif v76 > 0 then
		return string.format("%d new %s in TRADERS", v76, v76 == 1 and "offer" or "offers")
	elseif v78 > 0 then
		return string.format("%d %s a task first, see TRADERS", v78, v78 == 1 and "offer needs" or "offers need")
	else
		return nil
	end
end
function v_u_1.partnerReadyToast(p79) -- name: partnerReadyToast
	return ((type(p79) ~= "string" or p79 == "") and "Your trader" or string.upper((string.sub(p79, 1, 1))) .. string.lower((string.sub(p79, 2)))) .. " is ready for LV 5", "Open TRADERS, PARTNER tab."
end
function v_u_1.fundsLines(p80, p81, p82, p83, p84) -- name: fundsLines
	-- upvalues: (copy) v_u_11
	local v85 = p84 or v_u_11
	local v86 = tonumber(p80) or 0
	local v87 = math.floor(v86)
	local v88 = tonumber(p81) or 0
	local v89 = math.floor(v88)
	local v90 = tonumber(p82) or 0
	local v91 = math.floor(v90)
	local v92 = tonumber(p83) or 0
	local v93 = (v92 ~= v92 or v92 < 0) and 0 or math.floor(v92)
	local v94 = {
		{
			["label"] = "Cash",
			["value"] = nil,
			["value"] = v85(v87)
		},
		{
			["label"] = "Stash sells for",
			["value"] = nil,
			["value"] = v85(v89)
		}
	}
	if v91 > 0 then
		local v95 = {
			["label"] = "Kit sells",
			["value"] = nil,
			["value"] = v85(v91)
		}
		table.insert(v94, v95)
	end
	if v93 > 0 then
		local v96 = {
			["label"] = "In buy orders",
			["value"] = nil,
			["value"] = v85(v93)
		}
		table.insert(v94, v96)
	end
	local v97 = v87 + v89 + v91 + v93
	local v98 = {
		["label"] = "Net worth",
		["value"] = nil,
		["value"] = v85(v97)
	}
	table.insert(v94, v98)
	return v94, v97
end
v_u_1.WAIT_AFTER = 12
function v_u_1.deployWait(p99, p100) -- name: deployWait
	-- upvalues: (copy) v_u_1
	local v101 = tonumber(p100) or 0
	local v102 = (v101 ~= v101 or v101 < 0) and 0 or math.floor(v101)
	if v102 < v_u_1.WAIT_AFTER then
		return nil
	elseif p99 == "deploy" then
		return string.format("Still waiting for the raid server (%d s). If it fails, you are sent back to the menu.", v102)
	elseif p99 == "return" then
		return string.format("Still saving your raid (%d s). You land in the menu when it is done.", v102)
	else
		return nil
	end
end
v_u_1.GATE_STILL_AFTER = 15
function v_u_1.gateTitle(p103) -- name: gateTitle
	return p103 == "parked" and "YOUR RAID WAITS" or (p103 == "checking" and "CHECKING YOUR RAID" or (p103 == "connecting" and "CONNECTING TO YOUR RAID" or (p103 == "unknown" and "WE CANNOT REACH YOUR RAID" or "YOUR RAID IS STILL RUNNING")))
end
function v_u_1.gateTimer(p104, p105, p106) -- name: gateTimer
	if p104 == "parked" then
		return p105 <= 0 and "WAITING FOR THE SAVED RAID" or "SAVED FOR  " .. p106
	else
		return p105 <= 0 and "WAITING FOR THE RAID SERVER" or "YOUR SURVIVOR WAITS  " .. p106
	end
end
function v_u_1.gateStill(p107) -- name: gateStill
	-- upvalues: (copy) v_u_1
	local v108 = tonumber(p107) or 0
	local v109 = (v108 ~= v108 or v108 < 0) and 0 or math.floor(v108)
	return v109 < v_u_1.GATE_STILL_AFTER and "" or string.format("Still working (%d s). If this does not change, rejoin HUSH. This screen comes back and your raid keeps waiting.", v109)
end
function v_u_1.gateHint(p110) -- name: gateHint
	return p110 == "open" and "At 0:00 the raid is lost: everything but your secure case." or (p110 == "parked" and "After this time the saved raid is given up: everything but your secure case." or "")
end
function v_u_1.hintFooter(p111, p112) -- name: hintFooter
	return p112 and (p111 == "market" and "LB / RB: switch tab  \194\183  LT / RT: switch page" or "LB / RB: switch tab") or ""
end
v_u_1.OFFLINE_SUB = "Offline, tap to retry"
v_u_1.VOTES_OFFLINE_TIP = "Votes are offline. Tap the card to try again."
v_u_1.MAIL_OFFLINE_TIP = "The mailbox did not answer. Tap the card to try again."
function v_u_1.mailBoth(p113, p114) -- name: mailBoth
	local v115 = tonumber(p113) or 0
	local v116 = (v115 ~= v115 or v115 < 0) and 0 or math.floor(v115)
	local v117 = tonumber(p114) or 0
	local v118 = (v117 ~= v117 or v117 < 0) and 0 or math.floor(v117)
	return string.format("%d %s, %d %s", v116, v116 == 1 and "letter" or "letters", v118, v118 == 1 and "delivery" or "deliveries")
end
return v_u_1