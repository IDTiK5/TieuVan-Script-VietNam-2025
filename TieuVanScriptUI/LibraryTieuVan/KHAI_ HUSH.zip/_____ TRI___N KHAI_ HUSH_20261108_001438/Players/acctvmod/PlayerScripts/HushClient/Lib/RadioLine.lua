-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RadioLine

local v_u_1 = game:GetService("RunService")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = ""
local v_u_12 = 0
function v_u_2.init(p13) -- name: init
	-- upvalues: (ref) v_u_4
	v_u_4 = p13
end
local function v_u_31() -- name: build
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
	if v_u_6 and (v_u_6.Parent and v_u_7) then
		return true
	end
	local v14 = v_u_4
	local v_u_15, v_u_16
	if v14 and (v14.lib and v14.shared) then
		v_u_15 = v14.lib.HushUI
		v_u_16 = v14.shared.Theme
	else
		v_u_15 = nil
		v_u_16 = nil
	end
	if not (v_u_15 and v_u_16) then
		return false
	end
	local function v30()
		-- upvalues: (copy) v_u_15, (copy) v_u_16, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
		local v17, v18 = v_u_15.screen("HushRadioLine", v_u_16.layer.inventory + 4, {
			["insets"] = "None"
		})
		v_u_6 = v17
		local v19 = Instance.new("Frame")
		v19.Name = "Box"
		v19.BackgroundColor3 = Color3.fromRGB(10, 10, 12)
		v19.BackgroundTransparency = 1
		v19.BorderSizePixel = 0
		v19.AnchorPoint = Vector2.new(0.5, 0)
		v19.Size = UDim2.fromOffset(520, 0)
		v19.AutomaticSize = Enum.AutomaticSize.Y
		v19.Visible = false
		v19.Parent = v18
		local v20 = Instance.new("UICorner")
		v20.CornerRadius = UDim.new(0, 6)
		v20.Parent = v19
		local v21 = Instance.new("UIPadding")
		local v22 = UDim.new(0, 12)
		local v23 = UDim.new(0, 12)
		v21.PaddingLeft = v22
		v21.PaddingRight = v23
		local v24 = UDim.new(0, 7)
		local v25 = UDim.new(0, 7)
		v21.PaddingTop = v24
		v21.PaddingBottom = v25
		v21.Parent = v19
		local v26 = Instance.new("UIListLayout")
		v26.FillDirection = Enum.FillDirection.Vertical
		v26.Padding = UDim.new(0, 1)
		v26.SortOrder = Enum.SortOrder.LayoutOrder
		v26.Parent = v19
		local v27 = v_u_16.color
		local v28 = v_u_15.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v19,
			["color"] = v27.accent,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		v28.LayoutOrder = 1
		local v29 = v_u_15.label({
			["parent"] = nil,
			["text"] = "",
			["style"] = "body",
			["textSize"] = 17,
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["size"] = nil,
			["fitWrap"] = false,
			["parent"] = v19,
			["color"] = Color3.fromRGB(246, 246, 248),
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		v29.LayoutOrder = 2
		v_u_7 = v19
		v_u_8 = v28
		v_u_9 = v29
	end
	if pcall(v30) then
		return true
	end
	if v_u_10 then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
	if v_u_6 then
		v_u_6:Destroy()
	end
	v_u_6 = nil
	v_u_7 = nil
	v_u_8 = nil
	v_u_9 = nil
	v_u_11 = ""
	return false
end
local function v_u_57() -- name: place
	-- upvalues: (ref) v_u_4, (ref) v_u_7
	local v32 = v_u_4
	local v33
	if v32 and (v32.lib and v32.shared) then
		local _ = v32.lib.HushUI
		v33 = v32.shared.Theme
	else
		v33 = nil
	end
	local v34 = v_u_7
	if v34 and v33 then
		local v35 = v33.refSize()
		if v33.isPhone() then
			local v36 = 100
			local v37 = v35.X * 0.8
			local v38 = math.floor(v37)
			local v39 = v_u_4
			local v40 = v39 and v39.controllers
			if v40 then
				v40 = v39.controllers.HUD
			end
			if v40 then
				local v41 = v40.centerColumn
				if type(v41) == "function" then
					local v42 = v40.centerColumn
					local v43, v44 = pcall(v42, true)
					if v43 and type(v44) == "table" then
						local v45 = v44.top
						if type(v45) == "number" then
							v36 = v44.top + 50
							local v46 = v44.w
							if type(v46) == "number" and v44.w > 120 then
								local v47 = v44.w
								v38 = math.min(v38, v47)
							end
						end
					end
				end
			end
			v34.AnchorPoint = Vector2.new(0.5, 0)
			local v48 = UDim2.fromOffset
			local v49 = v35.X / 2
			v34.Position = v48(math.floor(v49), v36)
			v34.Size = UDim2.fromOffset(math.min(v38, 520), 0)
		else
			v34.AnchorPoint = Vector2.new(0.5, 1)
			local v50 = UDim2.fromOffset
			local v51 = v35.X / 2
			local v52 = math.floor(v51)
			local v53 = v35.Y * 0.8
			v34.Position = v50(v52, (math.floor(v53)))
			local v54 = UDim2.fromOffset
			local v55 = v35.X * 0.55
			local v56 = math.floor(v55)
			v34.Size = v54(math.min(v56, 640), 0)
		end
	else
		return
	end
end
local function v_u_78(p58) -- name: paint
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_4, (ref) v_u_12, (copy) v_u_57
	local v59 = v_u_7
	if not (v59 and (v_u_8 and v_u_9)) then
		return
	end
	if not p58 then
		v59.Visible = false
		v_u_11 = ""
		return
	end
	local v60 = v_u_4
	local v61
	if v60 and (v60.lib and v60.shared) then
		v61 = v60.lib.HushUI
		local _ = v60.shared.Theme
	else
		v61 = nil
	end
	local v62 = p58.speaker
	local v63 = tostring(v62)
	local v64 = p58.text
	local v65 = v63 .. "|" .. tostring(v64)
	if v65 ~= v_u_11 then
		v_u_11 = v65
		v_u_12 = os.clock()
		local v66, v67, v68, v69, v70, v71, v72, v73
		if v61 then
			local v74 = v61.setText
			if type(v74) == "function" then
				local v75 = v61.setText
				local v76 = v_u_8
				local v77 = p58.speaker
				v75(v76, (tostring(v77)))
				v66 = v_u_9
				v67 = p58.text
				v66.Text = tostring(v67)
				v_u_57()
				v59.Visible = true
				v68 = v_u_4
				v69 = v68 and v68.controllers
				if v69 then
					v69 = v68.controllers.Audio
				end
				if v69 then
					v70 = v69.play
					if type(v70) == "function" then
						v71 = v69.play
						pcall(v71, "ev_radio_burst")
					end
				end
			else
				v72 = v_u_8
				v73 = p58.speaker
				v72.Text = tostring(v73)
				v66 = v_u_9
				v67 = p58.text
				v66.Text = tostring(v67)
				v_u_57()
				v59.Visible = true
				v68 = v_u_4
				v69 = v68 and v68.controllers
				if v69 then
					v69 = v68.controllers.Audio
				end
				if v69 then
					v70 = v69.play
					if type(v70) == "function" then
						v71 = v69.play
						pcall(v71, "ev_radio_burst")
					end
				end
			end
		else
			v72 = v_u_8
			v73 = p58.speaker
			v72.Text = tostring(v73)
			v66 = v_u_9
			v67 = p58.text
			v66.Text = tostring(v67)
			v_u_57()
			v59.Visible = true
			v68 = v_u_4
			v69 = v68 and v68.controllers
			if v69 then
				v69 = v68.controllers.Audio
			end
			if v69 then
				v70 = v69.play
				if type(v70) == "function" then
					v71 = v69.play
					pcall(v71, "ev_radio_burst")
				end
			end
		end
	end
end
local function v_u_93() -- name: step
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (copy) v_u_78, (ref) v_u_12
	local v79 = not v_u_3 and script.Parent:FindFirstChild("LiftClientRules")
	if v79 then
		local v80 = require
		local v81, v82 = pcall(v80, v79)
		if v81 then
			v_u_3 = v82
		end
	end
	local v83 = v_u_3
	if v83 and v_u_5 then
		local v84 = os.clock()
		local v85 = v83.radioStep(v_u_5, v84)
		if v85 == nil then
			if v_u_10 then
				v_u_10:Disconnect()
				v_u_10 = nil
			end
			if v_u_6 then
				v_u_6:Destroy()
			end
			v_u_6 = nil
			v_u_7 = nil
			v_u_8 = nil
			v_u_9 = nil
			v_u_11 = ""
		else
			v_u_78(v85)
			local v86 = v_u_7
			if v86 then
				local v87 = v84 - v_u_12
				local v88 = v85.untilAt - v84
				local v89 = v87 / 0.25
				local v90 = v88 / 0.25
				local v91 = math.min(v89, v90)
				local v92 = math.clamp(v91, 0, 1)
				v86.BackgroundTransparency = 1 - v92 * 0.62
				if v_u_9 then
					v_u_9.TextTransparency = 1 - v92
				end
				if v_u_8 then
					v_u_8.TextTransparency = 1 - v92
				end
			end
		end
	else
		if v_u_10 then
			v_u_10:Disconnect()
			v_u_10 = nil
		end
		return
	end
end
function v_u_2.show(p94, p95, p96) -- name: show
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_31, (ref) v_u_10, (copy) v_u_1, (copy) v_u_93
	local v97 = not v_u_3 and script.Parent:FindFirstChild("LiftClientRules")
	if v97 then
		local v98 = require
		local v99, v100 = pcall(v98, v97)
		if v99 then
			v_u_3 = v100
		end
	end
	local v101 = v_u_3
	if not v101 then
		return false, "rules"
	end
	local v102 = v101.radioLine({
		["speaker"] = p94,
		["line"] = p95,
		["dur"] = p96
	})
	if not v102 then
		return false, "text"
	end
	if not v_u_5 then
		v_u_5 = v101.radioNew(v101.TUNE.radioMax)
	end
	if not v_u_31() then
		return false, "ui"
	end
	if not v101.radioPush(v_u_5, v102, os.clock()) then
		return false, "dup"
	end
	if not v_u_10 then
		v_u_10 = v_u_1.Heartbeat:Connect(v_u_93)
	end
	return true, nil
end
function v_u_2.showPayload(p103) -- name: showPayload
	-- upvalues: (ref) v_u_3, (copy) v_u_2
	local v104 = not v_u_3 and script.Parent:FindFirstChild("LiftClientRules")
	if v104 then
		local v105 = require
		local v106, v107 = pcall(v105, v104)
		if v106 then
			v_u_3 = v107
		end
	end
	local v108 = v_u_3
	if v108 then
		local v109 = v108.radioLine(p103)
		if v109 then
			return v_u_2.show(v109.speaker, v109.text, v109.dur)
		else
			return false, "text"
		end
	else
		return false, "rules"
	end
end
function v_u_2.clear() -- name: clear
	-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11
	v_u_5 = nil
	if v_u_10 then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
	if v_u_6 then
		v_u_6:Destroy()
	end
	v_u_6 = nil
	v_u_7 = nil
	v_u_8 = nil
	v_u_9 = nil
	v_u_11 = ""
end
function v_u_2.state() -- name: state
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	local v110 = v_u_5
	if not v110 then
		return "radio idle"
	end
	local v111 = v110.cur
	local v112 = string.format
	local v113 = "radio cur=%s queued=%d ui=%s"
	local v114
	if v111 then
		local v115 = v111.text
		v114 = tostring(v115)
	else
		v114 = "none"
	end
	local v116 = #v110.queue
	local v117
	if v_u_6 == nil then
		v117 = false
	else
		v117 = v_u_6.Parent ~= nil
	end
	return v112(v113, v114, v116, (tostring(v117)))
end
return v_u_2