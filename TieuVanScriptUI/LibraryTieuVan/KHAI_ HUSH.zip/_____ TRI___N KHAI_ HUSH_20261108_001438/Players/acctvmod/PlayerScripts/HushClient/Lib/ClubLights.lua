-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ClubLights

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("GuiService")
local v_u_7 = game:GetService("TweenService")
local v_u_8 = {
	["clock"] = os.clock
}
local v_u_9 = v1.LocalPlayer
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = false
local v_u_14 = nil
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = "auto"
local v_u_20 = nil
local v_u_21 = 0
local v_u_22 = ""
local v_u_23 = false
local v_u_24 = false
local v_u_25 = ""
local v_u_26 = -1
local v_u_27 = true
local v_u_28 = 0
local v_u_29 = false
local v_u_30 = nil
local v_u_31 = {
	["loaded"] = false,
	["read"] = false,
	["seen"] = false,
	["shown"] = false,
	["owed"] = false,
	["stored"] = "",
	["fetching"] = false,
	["since"] = -1,
	["last"] = (-1 / 0),
	["gen"] = 0,
	["gui"] = nil
}
local v_u_32 = {
	["zone"] = "",
	["active"] = false,
	["q"] = "",
	["reduce"] = false,
	["beat"] = 0,
	["bps"] = 0,
	["show"] = 0,
	["act"] = 0,
	["hz"] = 0
}
local function v_u_39() -- name: loadModules
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_10
	if v_u_11 ~= nil and v_u_12 ~= nil then
		return true
	end
	if v_u_10 == nil then
		return false
	end
	local function v33()
		-- upvalues: (ref) v_u_10
		return v_u_10.shared.ClubLightsPlan
	end
	local v34, v35 = pcall(v33)
	local function v36()
		-- upvalues: (ref) v_u_10
		return v_u_10.shared.ClubRules
	end
	local v37, v38 = pcall(v36)
	if not v34 or (type(v35) ~= "table" or (not v37 or type(v38) ~= "table")) then
		return false
	end
	v_u_11 = v35
	v_u_12 = v38
	return true
end
local function v_u_47(p40) -- name: rgb
	local v41 = Color3.fromRGB
	local v42 = p40[1] + 0.5
	local v43 = math.floor(v42)
	local v44 = p40[2] + 0.5
	local v45 = math.floor(v44)
	local v46 = p40[3] + 0.5
	return v41(v43, v45, (math.floor(v46)))
end
local function v_u_49() -- name: raidFolder
	-- upvalues: (copy) v_u_4
	local v48 = v_u_4:FindFirstChild("HushRuntime")
	if v48 then
		v48 = v48:FindFirstChild("Raid")
	end
	if v48 and (v48:GetAttribute("MapId") == "tokyo" and v48:GetAttribute("Ready") == true) then
		return v48
	else
		return nil
	end
end
local function v_u_59() -- name: focusPoint
	-- upvalues: (ref) v_u_10, (copy) v_u_9, (copy) v_u_3
	local v_u_50 = v_u_10
	local v_u_51 = "Camera"
	local v52, v53 = pcall(function()
		-- upvalues: (copy) v_u_50, (copy) v_u_51
		return v_u_50.controllers[v_u_51]
	end)
	if not v52 then
		v53 = nil
	end
	local v54, v55
	if v53 == nil then
		v54 = false
		v55 = nil
	else
		local v56 = v53.subject
		v54, v55 = pcall(v56)
	end
	if v54 and (v55 ~= nil and v55:IsA("BasePart")) then
		return v55.Position
	else
		local v57 = v_u_9.Character
		if v57 then
			v57 = v57:FindFirstChild("HumanoidRootPart")
		end
		if v57 and v57:IsA("BasePart") then
			return v57.Position
		else
			local v58 = v_u_3.CurrentCamera
			if v58 then
				return v58.Focus.Position
			else
				return nil
			end
		end
	end
end
local function v_u_73() -- name: scanBaked
	-- upvalues: (ref) v_u_17, (copy) v_u_3, (ref) v_u_11
	local v_u_60 = {
		["head"] = {},
		["laser"] = {},
		["strobe"] = {},
		["ball"] = {},
		["wall"] = {},
		["fog"] = {}
	}
	local v_u_61 = v_u_17.layout.room
	local function v72()
		-- upvalues: (copy) v_u_61, (ref) v_u_3, (ref) v_u_17, (ref) v_u_11, (copy) v_u_60
		local v62 = CFrame.new((v_u_61.x0 + v_u_61.x1) / 2, (v_u_61.y0 + v_u_61.y1) / 2, (v_u_61.z0 + v_u_61.z1) / 2)
		local v63 = v_u_61.x1 - v_u_61.x0 + 8
		local v64 = v_u_61.y1 - v_u_61.y0 + 8
		local v65 = v_u_61.z1 - v_u_61.z0 + 8
		local v66 = {}
		for _, v67 in v_u_3:GetPartBoundsInBox(v62, Vector3.new(v63, v64, v65), OverlapParams.new()) do
			if v_u_17.folder and v67:IsDescendantOf(v_u_17.folder) then
				continue
			end
			for v68, v69 in v_u_11.FIXTURE_IDS do
				if v_u_60[v68] == nil then
					continue
				end
				local v70 = nil
				if v_u_11.matchFixture(v67.Name, v69) then
					v70 = v67
				elseif v67.Parent and (v67.Parent:IsA("Model") and v_u_11.matchFixture(v67.Parent.Name, v69)) then
					v70 = v67.Parent
				end
				if v70 == nil or v66[v70] then
					continue
				end
				v66[v70] = true
				local v71 = v_u_60[v68]
				table.insert(v71, v70)
			end
		end
	end
	if pcall(v72) then
		return v_u_60
	else
		return v_u_60
	end
end
local function v_u_101(p74, p75, p76) -- name: buildHeads
	-- upvalues: (ref) v_u_17
	local v77 = {}
	for v78 = 1, p75.heads do
		local v79 = p74.heads[v78]
		local v80 = v79.x
		local v81 = v79.y
		local v82 = v79.z
		local v83 = Vector3.new(v80, v81, v82)
		local v_u_84 = p76.head[v78]
		local v85
		if v_u_84 then
			local v86
			v86, v85 = pcall(function()
				-- upvalues: (copy) v_u_84
				return v_u_84:GetPivot().Position
			end)
			if not v86 then
				v85 = nil
			end
		else
			v85 = nil
		end
		if v85 then
			v83 = v85 + Vector3.new(0, -1.4, 0)
		end
		local v87
		if v85 then
			v87 = nil
		else
			local v88 = v_u_17.folder
			local v89 = "Head_" .. v78
			local v90 = CFrame.new(v83 + Vector3.new(0, 0.8, 0))
			v87 = Instance.new("Part")
			v87.Name = v89
			v87.Anchored = true
			v87.CanCollide = false
			v87.CanQuery = false
			v87.CanTouch = false
			v87.CastShadow = false
			v87.Size = Vector3.new(1.2, 1.6, 1.2)
			v87.CFrame = v90
			v87.Transparency = 0
			v87.Parent = v88
			v87.Color = Color3.fromRGB(28, 28, 34)
			v87.Material = Enum.Material.Metal
		end
		local v91 = v_u_17.folder
		local v92 = "HeadAim_" .. v78
		local v93 = CFrame.new(v83)
		local v94 = Instance.new("Part")
		v94.Name = v92
		v94.Anchored = true
		v94.CanCollide = false
		v94.CanQuery = false
		v94.CanTouch = false
		v94.CastShadow = false
		v94.Size = Vector3.new(0.3, 0.3, 0.3)
		v94.CFrame = v93
		v94.Transparency = 1
		v94.Parent = v91
		local v95
		if v78 <= p75.spots then
			v95 = Instance.new("SpotLight")
			v95.Name = "Spot"
			v95.Range = 40
			v95.Angle = 25
			v95.Brightness = 0
			v95.Shadows = false
			v95.Face = Enum.NormalId.Front
			v95.Enabled = false
			v95.Parent = v94
		else
			v95 = nil
		end
		local v96 = Instance.new("Attachment")
		v96.Name = "A0"
		v96.Parent = v94
		local v97 = v_u_17.targets
		local v98 = "H" .. v78
		local v99 = Instance.new("Attachment")
		v99.Name = v98
		v99.Parent = v97
		local v100
		if v78 <= p75.cones then
			v100 = Instance.new("Beam")
			v100.Name = "Cone"
			v100.Attachment0 = v96
			v100.Attachment1 = v99
			v100.Width0 = 0.5
			v100.Width1 = 8
			v100.LightEmission = 1
			v100.LightInfluence = 0
			v100.Brightness = 0
			v100.FaceCamera = true
			v100.Segments = 2
			v100.Transparency = NumberSequence.new(0.7, 1)
			v100.Enabled = false
			v100.Parent = v94
		else
			v100 = nil
		end
		table.insert(v77, {
			["body"] = nil,
			["aim"] = nil,
			["spot"] = nil,
			["beam"] = nil,
			["att1"] = nil,
			["pos"] = nil,
			["ca"] = 0,
			["cb"] = 0,
			["cm"] = -1,
			["body"] = v87,
			["aim"] = v94,
			["spot"] = v95,
			["beam"] = v100,
			["att1"] = v99,
			["pos"] = v83
		})
	end
	v_u_17.heads = v77
end
local function v_u_131(p102, p103, p104) -- name: buildLasers
	-- upvalues: (ref) v_u_17, (ref) v_u_11
	local v105 = {}
	for v106 = 1, p103.projectors do
		local v107 = p102.projectors[v106]
		local v108 = v107.x
		local v109 = v107.y
		local v110 = v107.z
		local v111 = Vector3.new(v108, v109, v110)
		local v_u_112 = p104.laser[v106]
		local v113
		if v_u_112 then
			local v114
			v114, v113 = pcall(function()
				-- upvalues: (copy) v_u_112
				return v_u_112:GetPivot().Position
			end)
			if not v114 then
				v113 = nil
			end
		else
			v113 = nil
		end
		if v113 then
			v111 = v113 + Vector3.new(0, -0.6, 0)
		end
		local v115
		if v113 then
			v115 = nil
		else
			local v116 = v_u_17.folder
			local v117 = "Projector_" .. v106
			local v118 = CFrame.new(v111 + Vector3.new(0, 0.4, 0))
			v115 = Instance.new("Part")
			v115.Name = v117
			v115.Anchored = true
			v115.CanCollide = false
			v115.CanQuery = false
			v115.CanTouch = false
			v115.CastShadow = false
			v115.Size = Vector3.new(1.4, 0.8, 1)
			v115.CFrame = v118
			v115.Transparency = 0
			v115.Parent = v116
			v115.Color = Color3.fromRGB(24, 24, 28)
		end
		local v119 = v_u_17.folder
		local v120 = "LaserSrc_" .. v106
		local v121 = CFrame.new(v111)
		local v122 = Instance.new("Part")
		v122.Name = v120
		v122.Anchored = true
		v122.CanCollide = false
		v122.CanQuery = false
		v122.CanTouch = false
		v122.CastShadow = false
		v122.Size = Vector3.new(0.2, 0.2, 0.2)
		v122.CFrame = v121
		v122.Transparency = 1
		v122.Parent = v119
		local v123 = Instance.new("Attachment")
		v123.Name = "A0"
		v123.Parent = v122
		local v124 = {}
		for v125 = 1, p103.beamsPerProjector do
			local v126 = v_u_17.targets
			local v127 = string.format("L%d_%d", v106, v125)
			local v128 = Instance.new("Attachment")
			v128.Name = v127
			v128.Parent = v126
			local v129 = Instance.new("Beam")
			v129.Name = "Laser_" .. v125
			v129.Attachment0 = v123
			v129.Attachment1 = v128
			v129.Width0 = 0.06
			v129.Width1 = 0.25
			v129.LightEmission = 1
			v129.LightInfluence = 0
			v129.Brightness = 0
			v129.FaceCamera = true
			v129.Segments = 1
			v129.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 0.9) })
			if v_u_11.ASSETS.laserTex ~= "" then
				v129.Texture = v_u_11.ASSETS.laserTex
				v129.TextureSpeed = 0.3
				v129.TextureLength = 12
			end
			v129.Enabled = false
			v129.Parent = v122
			table.insert(v124, {
				["beam"] = v129,
				["att1"] = v128
			})
		end
		local v130 = {
			["body"] = nil,
			["src"] = nil,
			["pos"] = nil,
			["facing"] = nil,
			["beams"] = nil,
			["col"] = 0,
			["body"] = v115,
			["src"] = v122,
			["pos"] = v111,
			["facing"] = v107.facing,
			["beams"] = v124
		}
		table.insert(v105, v130)
	end
	v_u_17.lasers = v105
end
local function v_u_168(p132, p133, p134) -- name: buildStrobes
	-- upvalues: (ref) v_u_17, (ref) v_u_11
	local v135 = {}
	for v136 = 1, #p132.strobes do
		local v137 = p132.strobes[v136]
		local v138 = v137.x
		local v139 = v137.y
		local v140 = v137.z
		local v141 = Vector3.new(v138, v139, v140)
		local v_u_142 = p134.strobe[v136]
		local v143
		if v_u_142 then
			local v144
			v144, v143 = pcall(function()
				-- upvalues: (copy) v_u_142
				return v_u_142:GetPivot().Position
			end)
			if not v144 then
				v143 = nil
			end
		else
			v143 = nil
		end
		if v143 then
			v141 = v143 + Vector3.new(0, -0.4, 0)
		end
		local v145
		if v143 then
			v145 = nil
		else
			local v146 = v_u_17.folder
			local v147 = "StrobeBar_" .. v136
			local v148 = CFrame.new(v141 + Vector3.new(0, 0.25, 0))
			v145 = Instance.new("Part")
			v145.Name = v147
			v145.Anchored = true
			v145.CanCollide = false
			v145.CanQuery = false
			v145.CanTouch = false
			v145.CastShadow = false
			v145.Size = Vector3.new(4, 0.5, 0.6)
			v145.CFrame = v148
			v145.Transparency = 0
			v145.Parent = v146
			local v149 = v_u_11.PAL.strobe
			local v150 = Color3.fromRGB
			local v151 = v149[1] + 0.5
			local v152 = math.floor(v151)
			local v153 = v149[2] + 0.5
			local v154 = math.floor(v153)
			local v155 = v149[3] + 0.5
			v145.Color = v150(v152, v154, (math.floor(v155)))
			v145.Material = Enum.Material.Neon
			v145.Transparency = 1
		end
		local v156 = v_u_17.folder
		local v157 = "StrobeLight_" .. v136
		local v158 = CFrame.new(v141)
		local v159 = Instance.new("Part")
		v159.Name = v157
		v159.Anchored = true
		v159.CanCollide = false
		v159.CanQuery = false
		v159.CanTouch = false
		v159.CastShadow = false
		v159.Size = Vector3.new(0.3, 0.3, 0.3)
		v159.CFrame = v158
		v159.Transparency = 1
		v159.Parent = v156
		local v160
		if v136 <= p133.strobeLights then
			v160 = Instance.new("SurfaceLight")
			v160.Name = "Strobe"
			v160.Range = 30
			v160.Angle = 150
			v160.Brightness = 0
			v160.Shadows = false
			v160.Face = Enum.NormalId.Bottom
			local v161 = v_u_11.PAL.strobe
			local v162 = Color3.fromRGB
			local v163 = v161[1] + 0.5
			local v164 = math.floor(v163)
			local v165 = v161[2] + 0.5
			local v166 = math.floor(v165)
			local v167 = v161[3] + 0.5
			v160.Color = v162(v164, v166, (math.floor(v167)))
			v160.Enabled = false
			v160.Parent = v159
		else
			v160 = nil
		end
		table.insert(v135, {
			["bar"] = v145,
			["host"] = v159,
			["light"] = v160
		})
	end
	v_u_17.strobes = v135
end
local function v_u_185(p169, p170, p171) -- name: buildBall
	-- upvalues: (ref) v_u_17
	local v_u_172 = p171.ball[1]
	local v173
	if v_u_172 then
		local v174
		v174, v173 = pcall(function()
			-- upvalues: (copy) v_u_172
			return v_u_172:GetPivot().Position
		end)
		if not v174 then
			v173 = nil
		end
	else
		v173 = nil
	end
	local v175 = p169.ball.x
	local v176 = p169.ball.y
	local v177 = p169.ball.z
	local v178 = Vector3.new(v175, v176, v177)
	if v173 then
		v178 = v173 + Vector3.new(0, -1.7, 0)
	end
	local v179 = CFrame.new(v178)
	local v180
	if v173 then
		v180 = nil
	else
		local v181 = v_u_17.folder
		v180 = Instance.new("Part")
		v180.Name = "MirrorBall"
		v180.Anchored = true
		v180.CanCollide = false
		v180.CanQuery = false
		v180.CanTouch = false
		v180.CastShadow = false
		v180.Size = Vector3.new(2.4, 2.4, 2.4)
		v180.CFrame = v179
		v180.Transparency = 0
		v180.Parent = v181
		v180.Shape = Enum.PartType.Ball
		v180.Material = Enum.Material.Metal
		v180.Color = Color3.fromRGB(190, 190, 205)
		v180.Reflectance = 0.5
	end
	local v182 = v_u_17.folder
	local v183 = Instance.new("Part")
	v183.Name = "BallLight"
	v183.Anchored = true
	v183.CanCollide = false
	v183.CanQuery = false
	v183.CanTouch = false
	v183.CastShadow = false
	v183.Size = Vector3.new(0.3, 0.3, 0.3)
	v183.CFrame = v179
	v183.Transparency = 1
	v183.Parent = v182
	local v184
	if p170.ballLights >= 1 then
		v184 = Instance.new("SpotLight")
		v184.Name = "Ball"
		v184.Range = 45
		v184.Angle = 60
		v184.Brightness = 0
		v184.Shadows = false
		v184.Face = Enum.NormalId.Bottom
		v184.Color = Color3.fromRGB(235, 235, 255)
		v184.Enabled = false
		v184.Parent = v183
	else
		v184 = nil
	end
	v_u_17.ball = {
		["part"] = v180,
		["host"] = v183,
		["light"] = v184,
		["base"] = v179
	}
end
local function v_u_208(p186, p187, p188) -- name: buildFog
	-- upvalues: (ref) v_u_17, (ref) v_u_11, (copy) v_u_47
	local v_u_189 = p188.fog[1]
	local v190
	if v_u_189 then
		local v191
		v191, v190 = pcall(function()
			-- upvalues: (copy) v_u_189
			return v_u_189:GetPivot().Position
		end)
		if not v191 then
			v190 = nil
		end
	else
		v190 = nil
	end
	local v192 = p186.fog.x
	local v193 = p186.fog.y
	local v194 = p186.fog.z
	local v195 = Vector3.new(v192, v193, v194)
	if v190 then
		v195 = v190 + Vector3.new(0, 0.6, 0)
	end
	local v196 = p186.center[1]
	local v197 = v195.Y
	local v198 = p186.center[3]
	local v199 = Vector3.new(v196, v197, v198)
	local v200 = v_u_17.folder
	local v201 = CFrame.lookAt(v195, v199)
	local v202 = Instance.new("Part")
	v202.Name = "FogVent"
	v202.Anchored = true
	v202.CanCollide = false
	v202.CanQuery = false
	v202.CanTouch = false
	v202.CastShadow = false
	v202.Size = Vector3.new(0.4, 0.4, 0.4)
	v202.CFrame = v201
	v202.Transparency = 1
	v202.Parent = v200
	local v203 = Instance.new("ParticleEmitter")
	v203.Name = "Fog"
	v203.Texture = v_u_11.ASSETS.smoke
	v203.Rate = 0
	v203.Lifetime = NumberRange.new(6, 10)
	v203.Speed = NumberRange.new(6, 10)
	v203.Size = NumberSequence.new(4, 14)
	v203.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
	v203.Color = ColorSequence.new(Color3.fromRGB(215, 215, 222))
	v203.LightEmission = 0.1
	v203.LightInfluence = 0.6
	v203.Acceleration = Vector3.new(0, -0.3, 0)
	v203.SpreadAngle = Vector2.new(25, 15)
	v203.EmissionDirection = Enum.NormalId.Front
	v203.Rotation = NumberRange.new(0, 360)
	v203.RotSpeed = NumberRange.new(-20, 20)
	v203.Enabled = true
	v203.Parent = v202
	v_u_17.fog = {
		["part"] = v202,
		["em"] = v203
	}
	if p187.hazeEmitters >= 1 then
		local v204 = v_u_17.folder
		local v205 = CFrame.new(p186.haze.x, p186.haze.y, p186.haze.z)
		local v206 = Instance.new("Part")
		v206.Name = "HazeSource"
		v206.Anchored = true
		v206.CanCollide = false
		v206.CanQuery = false
		v206.CanTouch = false
		v206.CastShadow = false
		v206.Size = Vector3.new(0.4, 0.4, 0.4)
		v206.CFrame = v205
		v206.Transparency = 1
		v206.Parent = v204
		local v207 = Instance.new("ParticleEmitter")
		v207.Name = "Haze"
		v207.Texture = v_u_11.ASSETS.smoke
		v207.Rate = 0
		v207.Lifetime = NumberRange.new(8, 12)
		v207.Speed = NumberRange.new(0.5, 1)
		v207.Size = NumberSequence.new(18)
		v207.Transparency = NumberSequence.new(0.92)
		v207.Color = ColorSequence.new(v_u_47(v_u_11.PAL.haze))
		v207.LightEmission = 0
		v207.LightInfluence = 0.5
		v207.SpreadAngle = Vector2.new(180, 180)
		v207.EmissionDirection = Enum.NormalId.Bottom
		v207.Enabled = true
		v207.Parent = v206
		v_u_17.haze = {
			["part"] = v206,
			["em"] = v207
		}
	end
end
local function v_u_233(p209, p210) -- name: buildUv
	-- upvalues: (ref) v_u_17, (ref) v_u_11
	local v211 = {}
	for v212 = 1, #p209.uv do
		local v213 = p209.uv[v212]
		local v214 = v_u_17.folder
		local v215 = "UvStrip_" .. v212
		local v216 = CFrame.new(v213.x, v213.y, v213.z)
		local v217 = Instance.new("Part")
		v217.Name = v215
		v217.Anchored = true
		v217.CanCollide = false
		v217.CanQuery = false
		v217.CanTouch = false
		v217.CastShadow = false
		v217.Size = Vector3.new(6, 0.25, 0.25)
		v217.CFrame = v216
		v217.Transparency = 0
		v217.Parent = v214
		v217.Material = Enum.Material.Neon
		local v218 = v_u_11.PAL.uv
		local v219 = Color3.fromRGB
		local v220 = v218[1] + 0.5
		local v221 = math.floor(v220)
		local v222 = v218[2] + 0.5
		local v223 = math.floor(v222)
		local v224 = v218[3] + 0.5
		v217.Color = v219(v221, v223, (math.floor(v224)))
		v217.Transparency = 1
		local v225
		if v212 <= p210.uvLights then
			v225 = Instance.new("SurfaceLight")
			v225.Name = "Uv"
			v225.Range = 14
			v225.Angle = 150
			v225.Brightness = 0
			v225.Shadows = false
			v225.Face = Enum.NormalId.Front
			local v226 = v_u_11.PAL.uv
			local v227 = Color3.fromRGB
			local v228 = v226[1] + 0.5
			local v229 = math.floor(v228)
			local v230 = v226[2] + 0.5
			local v231 = math.floor(v230)
			local v232 = v226[3] + 0.5
			v225.Color = v227(v229, v231, (math.floor(v232)))
			v225.Enabled = false
			v225.Parent = v217
		else
			v225 = nil
		end
		table.insert(v211, {
			["strip"] = v217,
			["light"] = v225
		})
	end
	v_u_17.uv = v211
end
local function v_u_251(p234, p235) -- name: buildEmergency
	-- upvalues: (ref) v_u_17, (ref) v_u_11
	local v236 = {}
	for v237 = 1, p235.emergencyLights do
		local v238 = p234.emergency[v237]
		local v239 = v_u_17.folder
		local v240 = "Emergency_" .. v237
		local v241 = CFrame.new(v238.x, v238.y, v238.z)
		local v242 = Instance.new("Part")
		v242.Name = v240
		v242.Anchored = true
		v242.CanCollide = false
		v242.CanQuery = false
		v242.CanTouch = false
		v242.CastShadow = false
		v242.Size = Vector3.new(0.3, 0.3, 0.3)
		v242.CFrame = v241
		v242.Transparency = 1
		v242.Parent = v239
		local v243 = Instance.new("PointLight")
		v243.Name = "Light"
		v243.Range = 14
		v243.Brightness = 0
		v243.Shadows = false
		local v244 = v_u_11.PAL.emergency
		local v245 = Color3.fromRGB
		local v246 = v244[1] + 0.5
		local v247 = math.floor(v246)
		local v248 = v244[2] + 0.5
		local v249 = math.floor(v248)
		local v250 = v244[3] + 0.5
		v243.Color = v245(v247, v249, (math.floor(v250)))
		v243.Enabled = false
		v243.Parent = v242
		table.insert(v236, {
			["host"] = v242,
			["light"] = v243
		})
	end
	v_u_17.emergency = v236
end
local function v_u_279(p252, _, p253) -- name: buildWall
	-- upvalues: (ref) v_u_17, (ref) v_u_11
	local v254 = nil
	local v255 = Enum.NormalId.Front
	local v_u_256 = p253.wall[1]
	if v_u_256 ~= nil then
		local v257, v258 = pcall(function()
			-- upvalues: (copy) v_u_256
			return v_u_256:GetPivot() * CFrame.new(0, 4.4, -0.83)
		end)
		if v257 then
			local v259 = v_u_17.folder
			v254 = Instance.new("Part")
			v254.Name = "LedWall"
			v254.Anchored = true
			v254.CanCollide = false
			v254.CanQuery = false
			v254.CanTouch = false
			v254.CastShadow = false
			v254.Size = Vector3.new(24, 8, 0.05)
			v254.CFrame = v258
			v254.Transparency = 1
			v254.Parent = v259
		end
	end
	if v254 == nil then
		local v260 = p252.wall
		local v261 = v260.x
		local v262 = v260.y
		local v263 = v260.z
		local v264 = Vector3.new(v261, v262, v263)
		local v265 = v_u_17.folder
		local v266 = CFrame.lookAt(v264, v264 + Vector3.new(1, 0, 0))
		local v267 = v260.w
		local v268 = v260.h
		local v269 = Vector3.new(v267, v268, 0.1)
		v254 = Instance.new("Part")
		v254.Name = "LedWall"
		v254.Anchored = true
		v254.CanCollide = false
		v254.CanQuery = false
		v254.CanTouch = false
		v254.CastShadow = false
		v254.Size = v269
		v254.CFrame = v266
		v254.Transparency = 0
		v254.Parent = v265
		v254.Color = Color3.fromRGB(8, 8, 12)
		v254.Material = Enum.Material.SmoothPlastic
	end
	local v270 = Instance.new("SurfaceGui")
	v270.Name = "ClubLed"
	v270.Adornee = v254
	v270.Face = v255
	v270.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	v270.PixelsPerStud = 10
	v270.LightInfluence = 0
	v270.Brightness = 1.5
	v270.MaxDistance = 120
	v270.AlwaysOnTop = false
	v270.Enabled = false
	v270.Parent = v254
	local v271 = Instance.new("Frame")
	v271.Name = "Bg"
	v271.Size = UDim2.new(1, 0, 1, 0)
	v271.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v271.BorderSizePixel = 0
	v271.Parent = v270
	local v272 = Instance.new("UIGradient")
	v272.Rotation = 25
	v272.Parent = v271
	local v273 = Instance.new("TextLabel")
	v273.Name = "Title"
	v273.BackgroundTransparency = 1
	v273.Size = UDim2.new(0.8, 0, 0.36, 0)
	v273.Position = UDim2.new(0.1, 0, 0.12, 0)
	v273.Text = v_u_11.WALL.title
	v273.TextScaled = true
	v273.Font = Enum.Font.GothamBlack
	v273.TextColor3 = Color3.fromRGB(245, 245, 255)
	v273.TextTransparency = 1
	v273.Parent = v271
	local v274 = Instance.new("Frame")
	v274.Name = "Bars"
	v274.BackgroundTransparency = 1
	v274.Position = UDim2.new(0.05, 0, 0.55, 0)
	v274.Size = UDim2.new(0.9, 0, 0.4, 0)
	v274.Parent = v271
	local v275 = {}
	for v276 = 1, 16 do
		local v277 = Instance.new("Frame")
		v277.Name = "Bar" .. v276
		v277.AnchorPoint = Vector2.new(0, 1)
		v277.Position = UDim2.new((v276 - 1) / 16, 0, 1, 0)
		v277.Size = UDim2.new(0.0565, 0, 0.1, 0)
		v277.BackgroundColor3 = Color3.fromRGB(235, 235, 255)
		v277.BackgroundTransparency = 0.25
		v277.BorderSizePixel = 0
		v277.Parent = v274
		v275[v276] = v277
	end
	local v278 = Instance.new("Frame")
	v278.Name = "Pale"
	v278.AnchorPoint = Vector2.new(0.5, 0.5)
	v278.Position = UDim2.new(0.5, 0, 0.5, 0)
	v278.Size = UDim2.new(0.7, 0, 0.05, 0)
	v278.BackgroundColor3 = Color3.fromRGB(190, 190, 205)
	v278.BackgroundTransparency = 1
	v278.BorderSizePixel = 0
	v278.Parent = v270
	v_u_17.wall = {
		["host"] = nil,
		["gui"] = nil,
		["bg"] = nil,
		["grad"] = nil,
		["title"] = nil,
		["bars"] = nil,
		["pale"] = nil,
		["barVals"] = nil,
		["acc"] = 0,
		["host"] = v254,
		["gui"] = v270,
		["bg"] = v271,
		["grad"] = v272,
		["title"] = v273,
		["bars"] = v275,
		["pale"] = v278,
		["barVals"] = {}
	}
end
local function v_u_295(p280) -- name: buildWorld
	-- upvalues: (ref) v_u_17, (ref) v_u_11, (ref) v_u_12, (copy) v_u_3, (copy) v_u_73, (copy) v_u_101, (copy) v_u_131, (copy) v_u_168, (copy) v_u_185, (copy) v_u_208, (copy) v_u_233, (copy) v_u_251, (copy) v_u_279
	if v_u_17 ~= nil and v_u_17.folder ~= nil then
		local function v281()
			-- upvalues: (ref) v_u_17
			v_u_17.folder:Destroy()
		end
		pcall(v281)
	end
	v_u_17 = nil
	local v282 = v_u_11.levelOf(p280)
	local v283 = v_u_12.ZONES.byId
	local v284 = v_u_11.layout
	local v285 = {
		["x0"] = nil,
		["z0"] = nil,
		["x1"] = nil,
		["z1"] = nil,
		["floorY"] = nil,
		["trussY"] = -2,
		["roomsCeilY"] = nil,
		["pod"] = nil,
		["podY"] = nil,
		["lounge"] = nil,
		["foyer"] = nil,
		["x0"] = v283.floor.x0,
		["z0"] = v283.floor.z0,
		["x1"] = v283.floor.x1,
		["z1"] = v283.floor.z1,
		["floorY"] = v_u_12.LEVEL_Y,
		["roomsCeilY"] = v_u_12.CEIL_ROOMS,
		["pod"] = {
			["x0"] = v283.pulpit.x0,
			["z0"] = v283.pulpit.z0,
			["x1"] = v283.pulpit.x1,
			["z1"] = v283.pulpit.z1
		},
		["podY"] = v_u_12.POD_Y,
		["lounge"] = {
			["x0"] = v283.lounge.x0,
			["z0"] = v283.lounge.z0,
			["x1"] = v283.lounge.x1,
			["z1"] = v283.lounge.z1
		},
		["foyer"] = {
			["x0"] = v283.foyer.x0,
			["z0"] = v283.foyer.z0,
			["x1"] = v283.foyer.x1,
			["z1"] = v283.foyer.z1
		}
	}
	local v286 = v284(v285)
	local v287 = v_u_3:FindFirstChild("HushLocal")
	if v287 == nil then
		v287 = Instance.new("Folder")
		v287.Name = "HushLocal"
		v287.Parent = v_u_3
	end
	local v288 = Instance.new("Folder")
	v288.Name = "ClubLights"
	v288.Parent = v287
	v_u_17 = {
		["folder"] = nil,
		["layout"] = nil,
		["level"] = nil,
		["q"] = nil,
		["born"] = nil,
		["rescans"] = 0,
		["bakedCount"] = 0,
		["folder"] = v288,
		["layout"] = v286,
		["level"] = v282,
		["q"] = p280,
		["born"] = os.clock()
	}
	local v289 = v_u_17
	local v290 = CFrame.new(0, 0, 0)
	local v291 = Instance.new("Part")
	v291.Name = "Targets"
	v291.Anchored = true
	v291.CanCollide = false
	v291.CanQuery = false
	v291.CanTouch = false
	v291.CastShadow = false
	v291.Size = Vector3.new(0.2, 0.2, 0.2)
	v291.CFrame = v290
	v291.Transparency = 1
	v291.Parent = v288
	v289.targets = v291
	local v292 = v_u_73()
	local v293 = 0
	for _, v294 in v292 do
		v293 = v293 + #v294
	end
	v_u_17.bakedCount = v293
	v_u_101(v286, v282, v292)
	v_u_131(v286, v282, v292)
	v_u_168(v286, v282, v292)
	v_u_185(v286, v282, v292)
	v_u_208(v286, v282, v292)
	v_u_233(v286, v282)
	v_u_251(v286, v282)
	v_u_279(v286, v282, v292)
end
local function v_u_404(p296, p297, p298, p299) -- name: applyFrame
	-- upvalues: (ref) v_u_17, (ref) v_u_11, (copy) v_u_47
	local v300 = v_u_17.level
	local v301 = p296.master
	local v302 = v_u_17.layout
	local v303 = v302.center[1]
	local v304 = v302.center[2]
	local v305 = v302.center[3]
	local v306 = (v302.room.x1 - v302.room.x0) / 2 - 3
	local v307 = (v302.room.z1 - v302.room.z0) / 2 - 3
	for _, v308 in v_u_17.strobes do
		local v309 = p296.strobe
		if v308.bar then
			local v310 = v308.bar
			local v311 = 0.22 * v301 + 0.78 * v309
			v310.Transparency = 1 - math.clamp(v311, 0, 1)
		end
		local v312 = v308.light
		local v313 = 6 * v309
		if v312 == nil then
			continue
		end
		local v314 = v313 > 0.01
		if v312.Enabled ~= v314 then
			v312.Enabled = v314
		end
		if not v314 then
			continue
		end
		v312.Brightness = v313
	end
	local v315 = #v_u_17.heads
	for v316, v317 in v_u_17.heads do
		local v318, v319, v320 = v_u_11.headAim(p297, p298, v316, v315)
		local v321 = v303 + v318 * v306
		local v322 = v305 + v319 * v307
		v317.att1.WorldPosition = Vector3.new(v321, v304, v322)
		if v317.spot ~= nil then
			v317.aim.CFrame = CFrame.lookAt(v317.pos, (Vector3.new(v321, v304, v322)))
		end
		local v323, v324, v325 = v_u_11.headColor(p297, v316)
		local v326, v327, v328, v329, v330, v331, v332, v333
		if v323 ~= v317.ca or v324 ~= v317.cb then
			v317.ca = v323
			v317.cb = v324
			v317.cm = v325
			v326 = v_u_11.mixColor(v_u_11.PAL.heads[v323], v_u_11.PAL.heads[v324], v325)
			v327 = Color3.fromRGB
			v328 = v326[1] + 0.5
			v329 = math.floor(v328)
			v330 = v326[2] + 0.5
			v331 = math.floor(v330)
			v332 = v326[3] + 0.5
			v333 = v327(v329, v331, (math.floor(v332)))
			if v317.spot ~= nil then
				v317.spot.Color = v333
			end
			if v317.beam ~= nil then
				v317.beam.Color = ColorSequence.new(v333)
			end
			goto l21
		end
		local v334 = v325 - v317.cm
		if math.abs(v334) > 0.02 then
			v317.ca = v323
			v317.cb = v324
			v317.cm = v325
			v326 = v_u_11.mixColor(v_u_11.PAL.heads[v323], v_u_11.PAL.heads[v324], v325)
			v327 = Color3.fromRGB
			v328 = v326[1] + 0.5
			v329 = math.floor(v328)
			v330 = v326[2] + 0.5
			v331 = math.floor(v330)
			v332 = v326[3] + 0.5
			v333 = v327(v329, v331, (math.floor(v332)))
			if v317.spot ~= nil then
				v317.spot.Color = v333
			end
			if v317.beam ~= nil then
				v317.beam.Color = ColorSequence.new(v333)
			end
			goto l21
		end
		::l21::
		local v335 = v317.spot
		local v336 = 4 * v320 * v301
		if v335 ~= nil then
			local v337 = v336 > 0.01
			if v335.Enabled ~= v337 then
				v335.Enabled = v337
			end
			if v337 then
				v335.Brightness = v336
			end
		end
		if v317.beam == nil then
			continue
		end
		local v338 = v317.beam
		local v339 = 2 * v320 * v301
		local v340 = v339 > 0.01
		if v338.Enabled ~= v340 then
			v338.Enabled = v340
		end
		if not v340 then
			continue
		end
		v338.Brightness = v339
	end
	local v341 = p296.laserEnv * v301
	local v342 = p296.laserScene
	for v343, v344 in v_u_17.lasers do
		local v345 = #v344.beams
		local v346 = (v342 + v343) % #v_u_11.PAL.laser + 1
		if v341 <= 0.01 and not v344.lit then
			continue
		end
		v344.lit = v341 > 0.01
		if v346 ~= v344.col and v341 < 0.2 then
			v344.col = v346
			local v347 = ColorSequence.new(v_u_47(v_u_11.PAL.laser[v346]))
			for _, v348 in v344.beams do
				v348.beam.Color = v347
			end
		end
		local v349 = v344.pos.X
		local v350 = v344.pos.Y
		local v351 = v344.pos.Z
		for v352, v353 in v344.beams do
			local v354, v355 = v_u_11.laserAngles(p297, p298, v343, v352, v345)
			local v356, v357, v358 = v_u_11.dirOf(v344.facing, v354, v355)
			local v359 = v_u_11.rayInBox(v349, v350, v351, v356, v357, v358, v302.room, 70)
			local v360 = v353.att1
			local v361 = v349 + v356 * v359
			local v362 = v350 + v357 * v359
			local v363 = v351 + v358 * v359
			v360.WorldPosition = Vector3.new(v361, v362, v363)
			local v364 = v353.beam
			local v365 = 3 * v341
			local v366 = v365 > 0.01
			if v364.Enabled ~= v366 then
				v364.Enabled = v366
			end
			if not v366 then
				continue
			end
			v364.Brightness = v365
		end
	end
	local v367 = v_u_17.ball
	if v367.part ~= nil then
		local v368 = v367.part
		local v369 = v367.base
		local v370 = CFrame.Angles
		local v371 = p296.ball
		v368.CFrame = v369 * v370(0, math.rad(v371), 0)
	end
	local v372 = v367.light
	local v373 = 1.5 * v301
	if v372 ~= nil then
		local v374 = v373 > 0.01
		if v372.Enabled ~= v374 then
			v372.Enabled = v374
		end
		if v374 then
			v372.Brightness = v373
		end
	end
	for _, v375 in v_u_17.uv do
		local v376 = v375.strip
		local v377 = 0.8 * v301
		v376.Transparency = 1 - math.clamp(v377, 0, 1)
		local v378 = v375.light
		local v379 = 1.5 * v301
		if v378 == nil then
			continue
		end
		local v380 = v379 > 0.01
		if v378.Enabled ~= v380 then
			v378.Enabled = v380
		end
		if not v380 then
			continue
		end
		v378.Brightness = v379
	end
	for _, v381 in v_u_17.emergency do
		local v382 = v381.light
		local v383 = 1 * p296.emerg
		if v382 == nil then
			continue
		end
		local v384 = v383 > 0.01
		if v382.Enabled ~= v384 then
			v382.Enabled = v384
		end
		if not v384 then
			continue
		end
		v382.Brightness = v383
	end
	v_u_17.fog.em.Rate = p296.fog
	if v_u_17.haze ~= nil then
		v_u_17.haze.em.Rate = p296.haze
	end
	local v385 = v_u_17.wall
	v385.acc = v385.acc + p299
	if v385.acc >= 1 / v300.wallHz or p296.act < 0.01 then
		v385.acc = 0
		local v386 = v_u_11.WALL.frames[p296.wallA]
		local v387 = v_u_11.WALL.frames[p296.wallB]
		local v388 = v_u_11.mixColor(v386[2], v387[2], p296.wallMix)
		local v389 = v_u_11.mixColor(v386[3], v387[3], p296.wallMix)
		local v390 = 0.1 + 0.9 * v301
		local v391 = v385.grad
		local v392 = ColorSequence.new
		local v393 = { v388[1] * v390, v388[2] * v390, v388[3] * v390 }
		local v394 = Color3.fromRGB
		local v395 = v393[1] + 0.5
		local v396 = math.floor(v395)
		local v397 = v393[2] + 0.5
		local v398 = math.floor(v397)
		local v399 = v393[3] + 0.5
		v391.Color = v392(v394(v396, v398, (math.floor(v399))), v_u_47({ v389[1] * v390, v389[2] * v390, v389[3] * v390 }))
		v385.title.TextTransparency = 1 - 0.9 * v301
		v_u_11.bars(p297, 16, p298, v385.barVals)
		for v400 = 1, 16 do
			local v401 = v385.bars[v400]
			local v402 = UDim2.new
			local v403 = v385.barVals[v400] * v301
			v401.Size = v402(0.0565, 0, math.clamp(v403, 0.02, 1), 0)
		end
		v385.pale.BackgroundTransparency = 1 - 0.4 * p296.emerg
		v385.gui.Enabled = p296.act > 0.01
	end
end
local function v_u_413() -- name: showWarn
	-- upvalues: (copy) v_u_31, (copy) v_u_9, (ref) v_u_11, (copy) v_u_7
	if v_u_31.gui == nil then
		local v405 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v405 ~= nil then
			local v_u_406 = Instance.new("ScreenGui")
			v_u_406.Name = "ClubFlashWarn"
			v_u_406.ResetOnSpawn = false
			v_u_406.IgnoreGuiInset = true
			v_u_406.DisplayOrder = 40
			local v_u_407 = Instance.new("Frame")
			v_u_407.AnchorPoint = Vector2.new(0.5, 1)
			v_u_407.Position = UDim2.new(0.5, 0, 1, -96)
			v_u_407.Size = UDim2.new(0, 560, 0, 46)
			v_u_407.BackgroundColor3 = Color3.fromRGB(14, 14, 20)
			v_u_407.BackgroundTransparency = 1
			v_u_407.BorderSizePixel = 0
			v_u_407.Parent = v_u_406
			local v408 = Instance.new("UICorner")
			v408.CornerRadius = UDim.new(0, 8)
			v408.Parent = v_u_407
			local v_u_409 = Instance.new("TextLabel")
			v_u_409.BackgroundTransparency = 1
			v_u_409.Size = UDim2.new(1, -24, 1, 0)
			v_u_409.Position = UDim2.new(0, 12, 0, 0)
			v_u_409.Text = v_u_11.WARN_TEXT
			v_u_409.TextSize = 20
			v_u_409.Font = Enum.Font.GothamMedium
			v_u_409.TextColor3 = Color3.fromRGB(255, 235, 190)
			v_u_409.TextTransparency = 1
			v_u_409.TextWrapped = true
			v_u_409.Parent = v_u_407
			v_u_406.Parent = v405
			v_u_31.gui = v_u_406
			local function v410()
				-- upvalues: (ref) v_u_7, (copy) v_u_407, (copy) v_u_409
				v_u_7:Create(v_u_407, TweenInfo.new(0.3), {
					["BackgroundTransparency"] = 0.25
				}):Play()
				v_u_7:Create(v_u_409, TweenInfo.new(0.3), {
					["TextTransparency"] = 0
				}):Play()
			end
			pcall(v410)
			task.delay(v_u_11.WARN_SECS, function()
				-- upvalues: (ref) v_u_7, (copy) v_u_407, (copy) v_u_409, (copy) v_u_406, (ref) v_u_31
				local function v411()
					-- upvalues: (ref) v_u_7, (ref) v_u_407, (ref) v_u_409
					v_u_7:Create(v_u_407, TweenInfo.new(0.4), {
						["BackgroundTransparency"] = 1
					}):Play()
					v_u_7:Create(v_u_409, TweenInfo.new(0.4), {
						["TextTransparency"] = 1
					}):Play()
				end
				pcall(v411)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_406, (ref) v_u_31
					local function v412()
						-- upvalues: (ref) v_u_406
						v_u_406:Destroy()
					end
					pcall(v412)
					v_u_31.gui = nil
				end)
			end)
		end
	else
		return
	end
end
local function v_u_419() -- name: saveTip
	-- upvalues: (copy) v_u_31, (ref) v_u_11, (ref) v_u_10
	if v_u_31.read then
		v_u_31.owed = false
		if v_u_11.tipHas(v_u_31.stored, v_u_11.WARN_TIP) then
			return
		else
			local v_u_414 = v_u_11.tipMerge(v_u_31.stored, v_u_11.WARN_TIP)
			if v_u_414 ~= nil then
				v_u_31.stored = v_u_414
				task.spawn(function()
					-- upvalues: (ref) v_u_10, (copy) v_u_414
					local v415 = v_u_10
					if v415 then
						v415 = v_u_10.net
					end
					if v415 then
						local v416 = v415.fire
						if type(v416) == "function" then
							local v417 = v415.fire
							local v418 = {
								["op"] = "setting",
								["key"] = "menuTipsSeen",
								["value"] = nil,
								["value"] = v_u_414
							}
							pcall(v417, "menu.op", v418)
						end
					end
				end)
			end
		end
	else
		v_u_31.owed = true
		return
	end
end
local function v_u_427(p420) -- name: loadTip
	-- upvalues: (copy) v_u_31, (copy) v_u_4, (ref) v_u_11, (copy) v_u_419
	if v_u_31.loaded then
		return
	else
		if v_u_31.since < 0 then
			v_u_31.since = p420
		elseif p420 - v_u_31.since >= 6 then
			v_u_31.loaded = true
			return
		end
		if not v_u_31.fetching and p420 - v_u_31.last >= 2 then
			v_u_31.fetching = true
			v_u_31.last = p420
			local v_u_421 = v_u_31.gen
			task.spawn(function()
				-- upvalues: (ref) v_u_4, (copy) v_u_421, (ref) v_u_31, (ref) v_u_11, (ref) v_u_419
				local v_u_422 = v_u_4:FindFirstChild("HushNet")
				if v_u_422 then
					v_u_422 = v_u_422:FindFirstChild("menu.get")
				end
				local v423, v424
				if v_u_422 and v_u_422:IsA("RemoteFunction") then
					v423, v424 = pcall(function()
						-- upvalues: (copy) v_u_422
						return v_u_422:InvokeServer({
							["what"] = "settings"
						})
					end)
				else
					v423 = false
					v424 = nil
				end
				if v_u_421 == v_u_31.gen then
					v_u_31.fetching = false
					if v423 and (type(v424) == "table" and v424.error == nil) then
						local v425 = v_u_31
						local v426 = v424.menuTipsSeen
						v425.stored = type(v426) ~= "string" and "" or v424.menuTipsSeen
						v_u_31.read = true
						v_u_31.loaded = true
						if v_u_11.tipHas(v_u_31.stored, v_u_11.WARN_TIP) then
							v_u_31.seen = true
							v_u_31.owed = false
							return
						end
						if v_u_31.owed then
							v_u_419()
						end
					end
				end
			end)
		end
	end
end
local function v_u_431(p428, p429, p430) -- name: stepTip
	-- upvalues: (copy) v_u_31, (copy) v_u_427, (ref) v_u_11, (copy) v_u_413, (copy) v_u_419
	if v_u_31.loaded then
		if not p430 then
			if v_u_11.warnDecide({
				["loaded"] = v_u_31.loaded,
				["seen"] = v_u_31.seen,
				["shown"] = v_u_31.shown,
				["zone"] = p428
			}) then
				v_u_31.shown = true
				v_u_413()
				if not v_u_31.seen then
					v_u_31.seen = true
					v_u_419()
				end
			end
		end
	else
		v_u_427(p429)
		return
	end
end
local function v_u_446() -- name: teardown
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_30, (ref) v_u_29, (ref) v_u_26, (ref) v_u_10, (ref) v_u_11, (copy) v_u_31, (copy) v_u_32, (copy) v_u_9, (ref) v_u_25
	if v_u_17 ~= nil and v_u_17.folder ~= nil then
		local function v432()
			-- upvalues: (ref) v_u_17
			v_u_17.folder:Destroy()
		end
		pcall(v432)
	end
	v_u_17 = nil
	v_u_18 = nil
	v_u_30 = nil
	if v_u_29 then
		v_u_29 = false
		v_u_26 = -1
		local function v433()
			-- upvalues: (ref) v_u_10
			return v_u_10.controllers.Atmosphere
		end
		local v434, v435 = pcall(v433)
		if not v434 then
			v435 = nil
		end
		if v435 then
			local v436 = v435.setOverlay
			if type(v436) == "function" then
				local v437 = v435.setOverlay
				local v438 = v_u_11 and v_u_11.HAZE.fade or 1.5
				pcall(v437, "club", nil, v438)
			end
		end
	end
	if v_u_31.gui ~= nil then
		local function v439()
			-- upvalues: (ref) v_u_31
			v_u_31.gui:Destroy()
		end
		pcall(v439)
		v_u_31.gui = nil
	end
	local v440 = v_u_31
	local v441 = v_u_31
	local v442 = v_u_31
	local v443 = v_u_31
	v_u_31.loaded = false
	v440.read = false
	v441.fetching = false
	v442.seen = false
	v443.stored = ""
	local v444 = v_u_31
	v_u_31.since = -1
	v444.last = (-1 / 0)
	local v445 = v_u_31
	v445.gen = v445.gen + 1
	v_u_32.active = false
	v_u_9:SetAttribute("ClubLights", nil)
	v_u_25 = ""
end
local function v_u_544(p447, p448) -- name: stepOnce
	-- upvalues: (copy) v_u_4, (ref) v_u_17, (ref) v_u_18, (ref) v_u_29, (copy) v_u_446, (ref) v_u_27, (copy) v_u_39, (ref) v_u_30, (copy) v_u_59, (ref) v_u_12, (copy) v_u_32, (ref) v_u_19, (ref) v_u_11, (ref) v_u_26, (ref) v_u_10, (copy) v_u_431, (ref) v_u_20, (copy) v_u_9, (copy) v_u_6, (copy) v_u_295, (copy) v_u_5, (copy) v_u_73, (copy) v_u_3, (copy) v_u_404
	local v449 = v_u_4:FindFirstChild("HushRuntime")
	if v449 then
		v449 = v449:FindFirstChild("Raid")
	end
	if not v449 or (v449:GetAttribute("MapId") ~= "tokyo" or v449:GetAttribute("Ready") ~= true) then
		v449 = nil
	end
	if v449 == nil then
		if v_u_17 ~= nil or (v_u_18 ~= nil or v_u_29) then
			v_u_446()
		end
		v_u_27 = true
		return
	elseif v_u_39() then
		if v449 ~= v_u_30 then
			if v_u_30 ~= nil then
				v_u_446()
			end
			v_u_30 = v449
		end
		local v450 = v_u_59()
		local v451 = 0
		local v452
		if v450 == nil then
			v452 = nil
		else
			v452 = v_u_12.zoneAt(v450.X, v450.Y, v450.Z)
			if v452 ~= nil and v452.level == "stair" then
				v451 = v_u_12.stairT(v452, v450.X, v450.Y, v450.Z)
			end
		end
		local v453
		if v452 == nil then
			v453 = nil
		else
			v453 = v452.id
		end
		v_u_32.zone = v453 or ""
		local v454 = (v452 == nil or v_u_19 == "off") and 0 or v_u_11.hazeWeight(v452, v451)
		local v455 = v454 - v_u_26
		if math.abs(v455) > 0.02 or v454 == 0 ~= (v_u_26 == 0) then
			v_u_26 = v454
			local function v456()
				-- upvalues: (ref) v_u_10
				return v_u_10.controllers.Atmosphere
			end
			local v457, v458 = pcall(v456)
			if not v457 then
				v458 = nil
			end
			if v458 then
				local v459 = v458.setOverlay
				if type(v459) == "function" then
					if v454 > 0 then
						v_u_29 = true
						local v460 = v458.setOverlay
						local v461 = {
							["Density"] = v_u_11.HAZE.density,
							["Haze"] = v_u_11.HAZE.haze
						}
						local v462 = v_u_11.HAZE.color
						local v463 = Color3.fromRGB
						local v464 = v462[1] + 0.5
						local v465 = math.floor(v464)
						local v466 = v462[2] + 0.5
						local v467 = math.floor(v466)
						local v468 = v462[3] + 0.5
						v461.Color = v463(v465, v467, (math.floor(v468)))
						v461.weight = v454
						local v469 = v_u_11.HAZE.fade
						pcall(v460, "club", v461, v469)
					elseif v_u_29 then
						v_u_29 = false
						v_u_26 = -1
						local function v470()
							-- upvalues: (ref) v_u_10
							return v_u_10.controllers.Atmosphere
						end
						local v471, v472 = pcall(v470)
						if not v471 then
							v472 = nil
						end
						if v472 then
							local v473 = v472.setOverlay
							if type(v473) == "function" then
								local v474 = v472.setOverlay
								local v475 = v_u_11 and v_u_11.HAZE.fade or 1.5
								pcall(v474, "club", nil, v475)
							end
						end
					end
				end
			end
		end
		local v476 = v_u_431
		local v477
		if v_u_20 == nil then
			local v478 = v_u_11.reduceOf
			local v479 = v_u_9:GetAttribute("ReduceFlashing")
			local function v480()
				-- upvalues: (ref) v_u_6
				return v_u_6.ReducedMotionEnabled
			end
			local v481, v482 = pcall(v480)
			if v481 then
				v481 = v482 == true
			end
			v477 = v478(v479, v481)
		else
			v477 = v_u_20
		end
		v476(v453, p448, v477)
		local v483 = false
		if v_u_19 == "on" then
			v483 = true
		elseif v_u_19 == "off" then
			v483 = false
		elseif v450 ~= nil and v452 ~= nil then
			local v484 = v_u_11.active
			local v485 = v452.level
			local v486 = v_u_11.distToBox
			local v487 = v450.X
			local v488 = v450.Y
			local v489 = v450.Z
			local v490 = v_u_12.BOX
			v483 = v484(v485, v486(v487, v488, v489, {
				["x0"] = v490.x0,
				["y0"] = v_u_12.BAND_LO,
				["z0"] = v490.z0,
				["x1"] = v490.x1,
				["y1"] = v_u_12.CEIL_FLOOR,
				["z1"] = v490.z1
			}))
		end
		v_u_32.active = v483
		if v_u_17 == nil then
			if not v483 then
				v_u_27 = not v_u_29
				return
			end
			local v491 = v_u_295
			local v492 = nil
			local v_u_493 = v_u_10
			local v_u_494 = "Atmosphere"
			local v495, v496 = pcall(function()
				-- upvalues: (copy) v_u_493, (copy) v_u_494
				return v_u_493.controllers[v_u_494]
			end)
			if not v495 then
				v496 = nil
			end
			local v497
			if v496 == nil then
				v497 = v492
			else
				local v498 = v496.quality
				local v499
				v499, v497 = pcall(v498)
				if not v499 then
					v497 = v492
				end
			end
			local v500 = v_u_5.TouchEnabled
			if v500 then
				v500 = not v_u_5.KeyboardEnabled
			end
			v491((v_u_11.qualityOf(v497, v500)))
		end
		if v_u_18 == nil then
			v_u_18 = v_u_11.new(tonumber(v449:GetAttribute("ClubTrack")) or 1)
		end
		if v_u_18.act <= 0 and not v483 then
			v_u_32.show = 0
			v_u_27 = not v_u_29
		else
			v_u_27 = false
			local v501 = nil
			local v_u_502 = v_u_10
			local v_u_503 = "Atmosphere"
			local v504, v505 = pcall(function()
				-- upvalues: (copy) v_u_502, (copy) v_u_503
				return v_u_502.controllers[v_u_503]
			end)
			if not v504 then
				v505 = nil
			end
			local v506
			if v505 == nil then
				v506 = v501
			else
				local v507 = v505.quality
				local v508
				v508, v506 = pcall(v507)
				if not v508 then
					v506 = v501
				end
			end
			local v509 = v_u_5.TouchEnabled
			if v509 then
				v509 = not v_u_5.KeyboardEnabled
			end
			local v510 = v_u_11.qualityOf(v506, v509)
			if v510 == v_u_17.q then
				if v_u_17.rescans < 6 and (p448 - v_u_17.born > 3 * (v_u_17.rescans + 1) and v_u_18.act > 0.01) then
					local v511 = v_u_17
					v511.rescans = v511.rescans + 1
					local v512 = 0
					for _, v513 in v_u_73() do
						v512 = v512 + #v513
					end
					if v_u_17.bakedCount < v512 then
						v_u_295(v510)
					end
				end
			else
				v_u_295(v510)
			end
			local v_u_514 = v449:GetAttribute("ClubTrack")
			local v515 = v449:GetAttribute("ClubStart")
			local v516 = v449:GetAttribute("ClubRate")
			local v_u_517 = nil
			local function v518()
				-- upvalues: (ref) v_u_517, (ref) v_u_10, (copy) v_u_514
				v_u_517 = v_u_10.shared.ClubTracks.get(v_u_514)
			end
			pcall(v518)
			local v519
			if v_u_12.trackOk(v_u_517) then
				v519 = v_u_517
			else
				v_u_517 = v_u_12.DEFAULT_TRACK
				v519 = v_u_517
			end
			local v520 = v_u_3:GetServerTimeNow()
			local v521, v522
			if type(v515) == "number" then
				local v523 = v_u_12.clockNew(v515, v519)
				v523.rate = (type(v516) ~= "number" or (v_u_12.RATE_MIN > v516 or v516 > v_u_12.RATE_MAX)) and 1 or v516
				v521 = v_u_12.clockBeat(v523, v520)
				v522 = v519.bpm * v523.rate / 60
			else
				v521 = 0
				v522 = 2.1
			end
			local v524
			if v_u_20 == nil then
				local v525 = v_u_11.reduceOf
				local v526 = v_u_9:GetAttribute("ReduceFlashing")
				local function v527()
					-- upvalues: (ref) v_u_6
					return v_u_6.ReducedMotionEnabled
				end
				local v528, v529 = pcall(v527)
				if v528 then
					v528 = v529 == true
				end
				v524 = v525(v526, v528)
			else
				v524 = v_u_20
			end
			local v530 = v_u_18.inp
			if v530 == nil then
				v530 = {}
				v_u_18.inp = v530
			end
			local v531 = v_u_17.q
			v530.beat = v521
			v530.bps = v522
			v530.reduce = v524
			v530.q = v531
			v530.active = v483
			v530.emergency = v449:GetAttribute("ClubEmergency") == true
			local v532
			if type(v515) == "number" then
				local v533 = v520 - v515
				v532 = math.max(v533, 0)
			else
				v532 = 0
			end
			v530.elapsed = v532
			v530.t = v520
			local v534 = v_u_11.step(v_u_18, v530, v520, p447)
			local v535 = v_u_32
			local v536 = v_u_32
			local v537 = v_u_32
			local v538 = v_u_32
			local v539 = v_u_32
			local v540 = v_u_32
			local v541 = v_u_17.q
			local v542 = v534.show
			local v543 = v534.act
			v535.q = v541
			v536.reduce = v524
			v537.beat = v521
			v538.bps = v522
			v539.show = v542
			v540.act = v543
			v_u_404(v534, v521, v524, p447)
		end
	else
		v_u_27 = true
		return
	end
end
local function v_u_557() -- name: guardedStep
	-- upvalues: (copy) v_u_8, (ref) v_u_28, (copy) v_u_544, (ref) v_u_21, (ref) v_u_22, (copy) v_u_9, (ref) v_u_23, (ref) v_u_24, (copy) v_u_49, (copy) v_u_446
	local v545 = v_u_8.clock()
	local v546 = v545 - v_u_28
	local v547 = math.clamp(v546, 0.001, 0.1)
	v_u_28 = v545
	local v548 = v_u_544
	local v549, v550 = pcall(v548, v547, v545)
	if v549 then
		v_u_21 = 0
	else
		v_u_21 = v_u_21 + 1
		local v551 = tostring(v550)
		v_u_22 = string.sub(v551, 1, 160)
		if v_u_21 == 1 then
			warn("[ClubLights]", v550)
			local function v552()
				-- upvalues: (ref) v_u_9, (ref) v_u_22
				v_u_9:SetAttribute("ClientError", "ClubLights: " .. v_u_22)
			end
			pcall(v552)
		end
		if v_u_21 >= 60 and not v_u_23 then
			v_u_23 = true
			local v553 = v_u_49
			local v554, v555 = pcall(v553)
			if not v554 or v555 == nil then
				v555 = false
			end
			v_u_24 = v555
			local v556 = v_u_446
			pcall(v556)
		end
	end
end
function v_u_8.status() -- name: status
	-- upvalues: (ref) v_u_25
	return v_u_25
end
local function v_u_578() -- name: describe
	-- upvalues: (copy) v_u_32, (ref) v_u_17, (ref) v_u_19, (ref) v_u_21, (ref) v_u_23
	local v558 = string.format
	local v559 = "zone=%s active=%s q=%s reduce=%s beat=%.1f bps=%.2f show=%.2f act=%.2f lights=%s forced=%s err=%d%s"
	local v560 = v_u_32.zone
	local v561 = v_u_32.active
	local v562 = tostring(v561)
	local v563 = v_u_32.q
	local v564 = v_u_32.reduce
	local v565 = tostring(v564)
	local v566 = v_u_32.beat
	local v567 = v_u_32.bps
	local v568 = v_u_32.show
	local v569 = v_u_32.act
	local v570
	if v_u_17 == nil then
		v570 = "none"
	else
		local v571 = #v_u_17.heads
		local v572 = tostring(v571)
		local v573 = #v_u_17.lasers
		local v574 = tostring(v573)
		local v575 = #v_u_17.strobes
		local v576 = tostring(v575)
		local v577 = v_u_17.bakedCount
		v570 = v572 .. "h/" .. v574 .. "p/" .. v576 .. "s/baked" .. tostring(v577)
	end
	return v558(v559, v560, v562, v563, v565, v566, v567, v568, v569, v570, v_u_19, v_u_21, v_u_23 and " BROKEN" or "")
end
function v_u_8.stop() -- name: stop
	-- upvalues: (ref) v_u_14, (ref) v_u_13, (ref) v_u_11, (copy) v_u_446
	if v_u_14 ~= nil then
		v_u_14:Disconnect()
		v_u_14 = nil
	end
	v_u_13 = false
	if v_u_11 ~= nil then
		local v579 = v_u_446
		pcall(v579)
	end
end
function v_u_8.start(p_u_580) -- name: start
	-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_23, (ref) v_u_24, (ref) v_u_21, (copy) v_u_578, (ref) v_u_19, (ref) v_u_20, (copy) v_u_39, (copy) v_u_413, (ref) v_u_11, (copy) v_u_9, (copy) v_u_6, (ref) v_u_14, (copy) v_u_2, (ref) v_u_15, (copy) v_u_49, (ref) v_u_27, (ref) v_u_16, (copy) v_u_557, (ref) v_u_17, (ref) v_u_25
	v_u_10 = p_u_580
	if not v_u_13 then
		v_u_13 = true
		v_u_23 = false
		v_u_24 = false
		v_u_21 = 0
		local function v597()
			-- upvalues: (copy) p_u_580, (ref) v_u_578, (ref) v_u_19, (ref) v_u_20, (ref) v_u_39, (ref) v_u_413, (ref) v_u_11, (ref) v_u_9, (ref) v_u_6
			p_u_580.command("clublights.state", function()
				-- upvalues: (ref) v_u_578
				return v_u_578()
			end)
			p_u_580.command("clublights.force", function(p581)
				-- upvalues: (ref) v_u_19
				local v582 = p581[1]
				if v582 == "on" or (v582 == "off" or v582 == "auto") then
					v_u_19 = v582
				end
				return "forced=" .. v_u_19
			end)
			p_u_580.command("clublights.reduce", function(p583)
				-- upvalues: (ref) v_u_20
				local v584 = p583[1]
				if v584 == "on" then
					v_u_20 = true
				elseif v584 == "off" then
					v_u_20 = false
				elseif v584 == "auto" then
					v_u_20 = nil
				end
				local v585 = v_u_20
				return "reduce=" .. tostring(v585)
			end)
			p_u_580.command("clublights.warn", function()
				-- upvalues: (ref) v_u_39, (ref) v_u_413
				if not v_u_39() then
					return "modules missing"
				end
				v_u_413()
				return "shown"
			end)
			p_u_580.command("clublights.audit", function(p586)
				-- upvalues: (ref) v_u_39, (ref) v_u_11, (ref) v_u_20, (ref) v_u_9, (ref) v_u_6
				if not v_u_39() then
					return "modules missing"
				end
				local v587 = v_u_11.audit
				local v588 = {
					["point"] = nil,
					["cam"] = nil,
					["dur"] = nil,
					["bpm"] = 128,
					["off"] = 0.12,
					["rate"] = 1,
					["q"] = "pc",
					["reduce"] = nil,
					["dt"] = 0.016666666666666666,
					["point"] = p586[1] or "floor_mid",
					["cam"] = p586[2] or "iso"
				}
				local v589 = p586[3]
				v588.dur = tonumber(v589) or 40
				local v590
				if v_u_20 == nil then
					local v591 = v_u_11.reduceOf
					local v592 = v_u_9:GetAttribute("ReduceFlashing")
					local function v593()
						-- upvalues: (ref) v_u_6
						return v_u_6.ReducedMotionEnabled
					end
					local v594, v595 = pcall(v593)
					if v594 then
						v594 = v595 == true
					end
					v590 = v591(v592, v594)
				else
					v590 = v_u_20
				end
				v588.reduce = v590
				local v596 = v587(v588)
				return string.format("flashes %d (closed second %d) strobe flashes %d denied %d", v596.flashes, v596.closed, v596.strobeFlashes, v596.strobeDenied)
			end)
		end
		pcall(v597)
		v_u_14 = v_u_2.Heartbeat:Connect(function(p598)
			-- upvalues: (ref) v_u_15, (ref) v_u_23, (ref) v_u_49, (ref) v_u_24, (ref) v_u_21, (ref) v_u_27, (ref) v_u_16, (ref) v_u_557, (ref) v_u_17, (ref) v_u_578, (ref) v_u_25, (ref) v_u_9
			v_u_15 = v_u_15 + p598
			if v_u_23 then
				if v_u_15 >= 0.5 then
					v_u_15 = 0
					local v599 = v_u_49
					local v600, v601 = pcall(v599)
					if not v600 or v601 == nil then
						v601 = false
					end
					if v601 ~= v_u_24 then
						v_u_23 = false
						v_u_24 = false
						v_u_21 = 0
						v_u_27 = true
						v_u_15 = 0
					end
				end
			else
				v_u_16 = v_u_16 + p598
				if v_u_27 then
					if v_u_15 < 0.5 then
						return
					end
					v_u_15 = 0
					v_u_557()
				else
					v_u_557()
				end
				if v_u_16 >= 1 then
					v_u_16 = 0
					if v_u_17 ~= nil then
						local v602 = v_u_578()
						if v602 ~= v_u_25 then
							v_u_25 = v602
							v_u_9:SetAttribute("ClubLights", v602)
						end
					end
				end
			end
		end)
	end
end
return v_u_8