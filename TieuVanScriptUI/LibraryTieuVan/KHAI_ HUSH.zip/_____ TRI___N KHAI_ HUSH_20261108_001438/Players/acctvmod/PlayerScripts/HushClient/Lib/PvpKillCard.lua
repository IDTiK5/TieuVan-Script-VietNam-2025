-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PvpKillCard

local v_u_188 = {
	["CARD_SEC"] = 25,
	["BACK_SEC"] = 8,
	["FX_STEP"] = 0.03333333333333333,
	["new"] = function(p_u_1) -- name: new
		-- upvalues: (copy) v_u_188
		local v_u_2 = p_u_1.UI
		local v_u_3 = p_u_1.Theme
		local v_u_4 = p_u_1.M
		local v_u_5 = p_u_1.L
		local v_u_6 = p_u_1.Look
		local v_u_7 = p_u_1.Fx
		local v_u_8 = p_u_1.Rig
		local v_u_9 = p_u_1.Anim
		local v_u_10 = v_u_3.color
		local v11 = v_u_4.TEXT
		local v12 = p_u_1.root
		local v_u_13 = p_u_1.now or os.clock
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = false
		local v_u_17 = false
		local v_u_18 = nil
		local v_u_19 = 0
		local v_u_20 = 0
		local v_u_21 = nil
		local v_u_22 = nil
		local v_u_23 = nil
		local v_u_24 = -1
		local v_u_25 = ""
		local v_u_26 = 0
		local v_u_27 = nil
		local v_u_28 = "tall"
		local v_u_29 = false
		local v_u_30 = false
		local v_u_31 = 0
		local v_u_32 = 0
		local v_u_33 = v_u_2.new("Frame", {
			["Name"] = "KillCard",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_10.bg,
			["Size"] = UDim2.fromOffset(200, 400)
		}, v12)
		v_u_2.stroke(v_u_33, v_u_10.lineStrong)
		local v_u_34 = v_u_2.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_33,
			["text"] = v11.cardTitle,
			["color"] = v_u_10.danger,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_35 = v_u_2.new("Frame", {
			["Name"] = "AvatarPlate",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["ClipsDescendants"] = true,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_10.raised
		}, v_u_33)
		v_u_2.stroke(v_u_35, v_u_10.line)
		local v_u_36 = v_u_2.label({
			["parent"] = nil,
			["name"] = "Initial",
			["text"] = "?",
			["style"] = "display",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["track"] = false,
			["size"] = nil,
			["zindex"] = 2,
			["parent"] = v_u_35,
			["color"] = v_u_10.muted,
			["size"] = UDim2.fromScale(1, 1)
		})
		local v_u_37 = v_u_2.new("ImageLabel", {
			["Name"] = "Avatar",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Image"] = "",
			["ImageTransparency"] = 0,
			["ScaleType"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["ScaleType"] = Enum.ScaleType.Crop,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_35)
		local v_u_38 = v_u_2.label({
			["parent"] = nil,
			["name"] = "Display",
			["text"] = "",
			["style"] = "bodyStrong",
			["textSize"] = 22,
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["track"] = false,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_33,
			["color"] = v_u_10.text,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_39 = v_u_2.new("Frame", {
			["Name"] = "ClanFrame",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 7,
			["Position"] = UDim2.fromOffset(4, 4),
			["Size"] = UDim2.new(1, -8, 1, -8)
		}, v_u_33)
		local v_u_40 = v_u_2.stroke(v_u_39, v_u_10.accent, 3, 0)
		local v_u_41 = nil
		local v_u_42 = v_u_2.label({
			["parent"] = nil,
			["name"] = "KillTitle",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["track"] = false,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_33,
			["color"] = v_u_10.accent,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_43 = v_u_2.label({
			["parent"] = nil,
			["name"] = "Stats",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["track"] = false,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_33,
			["color"] = v_u_10.text2,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_44 = v_u_2.label({
			["parent"] = nil,
			["name"] = "Weapon",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["align"] = "center",
			["fit"] = true,
			["track"] = false,
			["size"] = nil,
			["zindex"] = 4,
			["parent"] = v_u_33,
			["color"] = v_u_10.text2,
			["size"] = UDim2.fromOffset(10, 10)
		})
		local v_u_45, v46 = v_u_2.button({
			["parent"] = nil,
			["name"] = "KillReport",
			["text"] = nil,
			["kind"] = "alert",
			["size"] = nil,
			["zindex"] = 5,
			["onClick"] = nil,
			["parent"] = v_u_33,
			["text"] = v11.report,
			["size"] = UDim2.fromOffset(10, 52),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_14
				v_u_14.pressReport()
			end
		})
		v46.label.TextSize = 20
		local v_u_47 = v_u_2.button({
			["parent"] = nil,
			["name"] = "KillContinue",
			["text"] = nil,
			["kind"] = "secondary",
			["size"] = nil,
			["zindex"] = 5,
			["onClick"] = nil,
			["parent"] = v_u_33,
			["text"] = v11.cont,
			["size"] = UDim2.fromOffset(10, 44),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_14
				v_u_14.close("continue")
			end
		})
		local function v_u_51() -- name: dropLayers
			-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_31
			if v_u_21 then
				local v48 = v_u_21.destroy
				pcall(v48)
				v_u_21 = nil
			end
			if v_u_22 then
				local v49 = v_u_22.destroy
				pcall(v49)
				v_u_22 = nil
			end
			if v_u_23 then
				local v50 = v_u_23.destroy
				pcall(v50)
				v_u_23 = nil
			end
			v_u_31 = 0
		end
		local function v_u_93(p52, p53) -- name: fill
			-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_31, (copy) v_u_4, (ref) v_u_41, (copy) p_u_1, (copy) v_u_38, (copy) v_u_39, (copy) v_u_40, (copy) v_u_10, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_36, (ref) v_u_29, (copy) v_u_37, (copy) v_u_45, (ref) v_u_18, (copy) v_u_7, (copy) v_u_35, (copy) v_u_6, (copy) v_u_33, (copy) v_u_8, (copy) v_u_9, (ref) v_u_30, (copy) v_u_13
			if v_u_21 then
				local v54 = v_u_21.destroy
				pcall(v54)
				v_u_21 = nil
			end
			if v_u_22 then
				local v55 = v_u_22.destroy
				pcall(v55)
				v_u_22 = nil
			end
			if v_u_23 then
				local v56 = v_u_23.destroy
				pcall(v56)
				v_u_23 = nil
			end
			v_u_31 = 0
			local v57 = v_u_4.nameLine(p52)
			if v_u_41 == nil then
				local function v58()
					-- upvalues: (ref) p_u_1
					return p_u_1.ClanText or require((script.Parent:WaitForChild("ClanTagText", 5)))
				end
				local v59, v60 = pcall(v58)
				if not v59 or type(v60) ~= "table" then
					v60 = false
				end
				v_u_41 = v60
			end
			local v61
			if v_u_41 then
				v61 = v_u_41
			else
				v61 = nil
			end
			local v62 = nil
			if v61 ~= nil and p52.tag ~= "" then
				local v63 = p52.cs
				if type(v63) == "string" and (p52.cs ~= "" and v61.givenStyle ~= nil) then
					v62 = v61.givenStyle(p52.cs)
				end
			end
			if v62 == nil or (v61.richFor == nil or v61.esc == nil) then
				v_u_38.RichText = false
				v_u_38.Text = v57
				v_u_38.TextStrokeTransparency = 1
			else
				v_u_38.RichText = true
				v_u_38.Text = v_u_4.nameLineRich(p52, v61.richFor(p52.tag, v62, nil), v61.esc)
				local v64 = v61.outline(v62)
				v_u_38.TextStrokeTransparency = v64 == nil and 1 or v64
			end
			local v65
			if v62 == nil or (v62.frame ~= true or p52.clanFrame ~= true) then
				v65 = false
			else
				v65 = p52.frame == v_u_4.DEFAULTS.frame
			end
			v_u_39.Visible = v65
			if v65 and v_u_40 then
				local v66
				if v61.color3 == nil then
					v66 = nil
				else
					v66 = v61.color3(v62)
				end
				local v67 = v_u_40
				if typeof(v66) ~= "Color3" then
					v66 = v_u_10.accent
				end
				v67.Color = v66
			end
			v_u_42.Text = p52.title or ""
			v_u_43.Text = v_u_4.statLine(p52)
			v_u_44.Text = v_u_4.weaponLine(p52)
			local v68
			if p52.display == "" then
				v68 = nil
			else
				v68 = utf8.offset(p52.display, 2)
			end
			local v69 = v_u_36
			local v70
			if p52.display == "" then
				v70 = "?"
			else
				local v71 = string.upper
				local v72
				if v68 then
					local v73 = p52.display
					local v74 = v68 - 1
					v72 = string.sub(v73, 1, v74)
				else
					v72 = p52.display
				end
				v70 = v71(v72)
			end
			v69.Text = v70
			v_u_36.Visible = true
			v_u_29 = false
			v_u_37.Visible = true
			v_u_37.ImageTransparency = 0
			v_u_37.Image = p52.fake == true and "" or ("rbxthumb://type=Avatar&id=%d&w=420&h=420"):format(p52.uid)
			local v75 = v_u_45
			local v76
			if v_u_18 == nil or v_u_18.noReport ~= true then
				local v77 = p_u_1.canReport
				if type(v77) == "function" then
					local v78 = p_u_1.canReport
					local v79
					v76, v79 = pcall(v78)
					if v76 then
						v76 = v79 == true
					end
				else
					v76 = true
				end
			else
				v76 = false
			end
			v75.Visible = v76
			v_u_22 = v_u_7.bg(v_u_35, p52.bg, v_u_6, p_u_1.Art)
			v_u_23 = v_u_7.frame(v_u_33, p52.frame, v_u_6, p_u_1.Art)
			v_u_31 = (not v_u_22 and 0 or v_u_22.count) + (not v_u_23 and 0 or v_u_23.count)
			if v_u_22 then
				local v80 = (v_u_6.BACKGROUNDS[p52.bg] or v_u_6.BACKGROUNDS[v_u_6.DEFAULT_BG]).stops[1]
				v_u_33.BackgroundColor3 = v_u_10.bg:Lerp(Color3.fromRGB(v80[1], v80[2], v80[3]), 0.18)
			end
			local v81 = v_u_8.new
			local v82 = {
				["parent"] = nil,
				["AnimRig"] = nil,
				["Poses"] = nil,
				["Anim"] = nil,
				["deps"] = nil,
				["zindex"] = 4,
				["parent"] = v_u_35,
				["AnimRig"] = p_u_1.AnimRig,
				["Poses"] = p_u_1.Poses,
				["Anim"] = v_u_9,
				["deps"] = p_u_1.deps
			}
			local v83, v84 = pcall(v81, v82)
			if v83 then
				v_u_21 = v84
				local v85 = v84.setGunSkin
				if type(v85) == "function" then
					local v86 = v84.setGunSkin
					local v87 = p52.gunSkin
					pcall(v86, v87)
				end
				local v88 = v84.load
				local v89 = p52.uid
				local v90, v91 = pcall(v88, v89)
				if v90 and v91 ~= "thumb" then
					if p53 then
						v84.showEnd(p52.anim)
						v_u_30 = true
					else
						v84.play(p52.anim, v_u_13())
						v_u_30 = true
					end
				else
					local v92 = v84.destroy
					pcall(v92)
					v_u_21 = nil
					return
				end
			else
				warn("[PvpKillCard] figure failed:", v84)
				return
			end
		end
		local function v_u_117() -- name: relayout
			-- upvalues: (copy) p_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5, (ref) v_u_28, (ref) v_u_27, (copy) v_u_33, (ref) v_u_23, (copy) v_u_34, (copy) v_u_35, (copy) v_u_38, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_45, (copy) v_u_47
			local v94 = p_u_1.metrics
			local v95
			if type(v94) == "function" then
				v95 = p_u_1.metrics()
			else
				local v96 = v_u_3.safeRefSize()
				local v97 = v_u_3.isPhone()
				v95 = {
					["root"] = v96,
					["phone"] = v97,
					["btnH"] = v_u_3.touch(44),
					["top"] = v_u_2.topInset(),
					["hard"] = {},
					["soft"] = { v_u_5.spectatorBand(v96, v97) }
				}
			end
			local v98 = v_u_5.layout(v95.root, {
				["l"] = 0,
				["t"] = 0,
				["r"] = 0,
				["b"] = 0
			}, v95.phone, v95.btnH, v95.top, v95.hard, v95.soft)
			v_u_28 = v98.mode
			v_u_27 = v98.card
			local v99 = v98.card
			v_u_33.Position = UDim2.fromOffset(v99.x0, v99.y0)
			v_u_33.Size = UDim2.fromOffset(v99.x1 - v99.x0, v99.y1 - v99.y0)
			if v_u_23 then
				local v100 = v_u_23.resize
				if type(v100) == "function" then
					v_u_23.resize(v99.x1 - v99.x0, v99.y1 - v99.y0)
				end
			end
			local v101 = v_u_34
			local v102 = v98.header
			v101.Position = UDim2.fromOffset(v102.x0, v102.y0)
			v101.Size = UDim2.fromOffset(v102.x1 - v102.x0, v102.y1 - v102.y0)
			local v103 = v_u_35
			local v104 = v98.plate
			v103.Position = UDim2.fromOffset(v104.x0, v104.y0)
			v103.Size = UDim2.fromOffset(v104.x1 - v104.x0, v104.y1 - v104.y0)
			local v105 = v_u_38
			local v106 = v98.name
			v105.Position = UDim2.fromOffset(v106.x0, v106.y0)
			v105.Size = UDim2.fromOffset(v106.x1 - v106.x0, v106.y1 - v106.y0)
			local v107 = v_u_42
			local v108 = v98.sub
			v107.Position = UDim2.fromOffset(v108.x0, v108.y0)
			v107.Size = UDim2.fromOffset(v108.x1 - v108.x0, v108.y1 - v108.y0)
			local v109 = v_u_43
			local v110 = v98.stat
			v109.Position = UDim2.fromOffset(v110.x0, v110.y0)
			v109.Size = UDim2.fromOffset(v110.x1 - v110.x0, v110.y1 - v110.y0)
			local v111 = v_u_44
			local v112 = v98.wpn
			v111.Position = UDim2.fromOffset(v112.x0, v112.y0)
			v111.Size = UDim2.fromOffset(v112.x1 - v112.x0, v112.y1 - v112.y0)
			local v113 = v_u_45
			local v114 = v98.report
			v113.Position = UDim2.fromOffset(v114.x0, v114.y0)
			v113.Size = UDim2.fromOffset(v114.x1 - v114.x0, v114.y1 - v114.y0)
			local v115 = v_u_47
			local v116 = v98.cont
			v115.Position = UDim2.fromOffset(v116.x0, v116.y0)
			v115.Size = UDim2.fromOffset(v116.x1 - v116.x0, v116.y1 - v116.y0)
		end
		local function v_u_129(p_u_118) -- name: plainFields
			-- upvalues: (copy) v_u_38, (copy) v_u_4, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_45, (ref) v_u_18, (copy) p_u_1
			local function v119()
				-- upvalues: (ref) v_u_38, (ref) v_u_4, (copy) p_u_118
				v_u_38.RichText = false
				v_u_38.Text = v_u_4.nameLine(p_u_118)
				v_u_38.TextStrokeTransparency = 1
			end
			pcall(v119)
			local function v120()
				-- upvalues: (ref) v_u_42, (copy) p_u_118
				v_u_42.Text = p_u_118.title or ""
			end
			pcall(v120)
			local function v121()
				-- upvalues: (ref) v_u_43, (ref) v_u_4, (copy) p_u_118
				v_u_43.Text = v_u_4.statLine(p_u_118)
			end
			pcall(v121)
			local function v122()
				-- upvalues: (ref) v_u_44, (ref) v_u_4, (copy) p_u_118
				v_u_44.Text = v_u_4.weaponLine(p_u_118)
			end
			pcall(v122)
			local function v128()
				-- upvalues: (ref) v_u_45, (ref) v_u_18, (ref) p_u_1
				local v123 = v_u_45
				local v124
				if v_u_18 == nil or v_u_18.noReport ~= true then
					local v125 = p_u_1.canReport
					if type(v125) == "function" then
						local v126 = p_u_1.canReport
						local v127
						v124, v127 = pcall(v126)
						if v124 then
							v124 = v127 == true
						end
					else
						v124 = true
					end
				else
					v124 = false
				end
				v123.Visible = v124
			end
			pcall(v128)
		end
		function v_u_14.show(p130) -- name: show
			-- upvalues: (ref) v_u_15, (ref) v_u_18, (ref) v_u_16, (ref) v_u_17, (copy) v_u_13, (ref) v_u_19, (ref) v_u_20, (ref) v_u_188, (ref) v_u_24, (ref) v_u_26, (ref) v_u_30, (copy) v_u_93, (ref) v_u_32, (copy) v_u_51, (copy) v_u_129, (copy) v_u_117, (copy) v_u_33
			if v_u_15 and type(p130) == "table" then
				v_u_18 = p130
				v_u_16 = true
				v_u_17 = false
				local v131 = v_u_13()
				local v132 = v131 + v_u_188.CARD_SEC
				v_u_19 = v131
				v_u_20 = v132
				v_u_24 = -1
				v_u_26 = v_u_26 + 1
				v_u_30 = false
				local v133 = v_u_93
				local v134, v135 = pcall(v133, p130, false)
				if not v134 then
					v_u_32 = v_u_32 + 1
					warn("[PvpKillCard] fill failed, plain card shown:", v135)
					local v136 = v_u_51
					pcall(v136)
					v_u_129(p130)
				end
				local v137 = v_u_117
				local v138, v139 = pcall(v137)
				if not v138 then
					v_u_32 = v_u_32 + 1
					warn("[PvpKillCard] layout failed:", v139)
				end
				v_u_33.Visible = true
			end
		end
		function v_u_14.close(p140) -- name: close
			-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_25, (ref) v_u_18, (copy) v_u_33, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_31, (copy) p_u_1
			if v_u_16 then
				v_u_16 = false
				v_u_17 = false
				v_u_25 = p140 or "closed"
				v_u_18 = nil
				v_u_33.Visible = false
				local function v143()
					-- upvalues: (ref) v_u_33
					local v141 = game:GetService("GuiService")
					local v142 = v141.SelectedObject
					if v142 ~= nil and v142:IsDescendantOf(v_u_33) then
						v141.SelectedObject = nil
					end
				end
				pcall(v143)
				if v_u_21 then
					local v144 = v_u_21.destroy
					pcall(v144)
					v_u_21 = nil
				end
				if v_u_22 then
					local v145 = v_u_22.destroy
					pcall(v145)
					v_u_22 = nil
				end
				if v_u_23 then
					local v146 = v_u_23.destroy
					pcall(v146)
					v_u_23 = nil
				end
				v_u_31 = 0
				local v147 = p_u_1.onClosed
				if type(v147) == "function" then
					local v148 = p_u_1.onClosed
					local v149 = v_u_25
					pcall(v148, v149)
				end
			end
		end
		function v_u_14.relayout() -- name: relayout
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (copy) v_u_117
			if v_u_15 and (v_u_16 and not v_u_17) then
				v_u_117()
			end
		end
		function v_u_14.step(p150) -- name: step
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) p_u_1, (ref) v_u_19, (copy) v_u_14, (ref) v_u_17, (ref) v_u_20, (ref) v_u_29, (ref) v_u_18, (copy) v_u_37, (copy) v_u_36, (ref) v_u_21, (ref) v_u_24, (ref) v_u_188, (ref) v_u_22, (ref) v_u_23
			if v_u_15 and v_u_16 then
				if p_u_1.shouldClose and p_u_1.shouldClose(p150 - v_u_19) then
					v_u_14.close("alive")
					return
				elseif v_u_17 then
					if v_u_20 <= p150 then
						v_u_14.close("time")
					end
				else
					if not v_u_29 and (v_u_18 ~= nil and (v_u_18.fake ~= true and v_u_37.IsLoaded)) then
						v_u_29 = true
						v_u_36.Visible = false
					end
					if v_u_21 then
						v_u_21.step(p150)
						if v_u_21.state().shown then
							v_u_37.Visible = false
							v_u_36.Visible = false
						end
					end
					if p150 - v_u_19 - v_u_24 >= v_u_188.FX_STEP then
						v_u_24 = p150 - v_u_19
						if v_u_22 then
							v_u_22.step(v_u_24)
						end
						if v_u_23 then
							v_u_23.step(v_u_24)
						end
					end
					if v_u_20 <= p150 then
						v_u_14.close("time")
					end
				end
			else
				return
			end
		end
		function v_u_14.pressReport() -- name: pressReport
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) p_u_1, (copy) v_u_33
			if v_u_15 and (v_u_16 and (not v_u_17 and v_u_18 ~= nil)) then
				local v151 = p_u_1.onReport
				if type(v151) == "function" then
					local v152 = p_u_1.onReport
					local v153 = v_u_18
					local v154, v155 = pcall(v152, v153)
					if not v154 or v155 ~= true then
						return false
					end
					v_u_17 = true
					v_u_33.Visible = false
					return true
				end
			end
			return false
		end
		function v_u_14.reportClosed(p156) -- name: reportClosed
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (copy) v_u_14, (ref) v_u_20, (copy) v_u_13, (ref) v_u_188, (copy) v_u_117, (copy) v_u_33
			if v_u_15 and (v_u_16 and v_u_17) then
				if p156 == true then
					v_u_14.close("sent")
				else
					v_u_17 = false
					local v157 = v_u_20
					local v158 = v_u_13() + v_u_188.BACK_SEC
					v_u_20 = math.max(v157, v158)
					v_u_117()
					v_u_33.Visible = true
				end
			else
				return
			end
		end
		function v_u_14.isOpen() -- name: isOpen
			-- upvalues: (ref) v_u_16
			return v_u_16
		end
		function v_u_14.isHidden() -- name: isHidden
			-- upvalues: (ref) v_u_17
			return v_u_17
		end
		function v_u_14.focusTargets() -- name: focusTargets
			-- upvalues: (ref) v_u_16, (ref) v_u_17, (copy) v_u_47, (copy) v_u_45
			local v159 = {}
			if v_u_16 and not v_u_17 then
				local v160 = v_u_47
				table.insert(v159, v160)
				if v_u_45.Visible then
					local v161 = v_u_45
					table.insert(v159, v161)
				end
			end
			return v159
		end
		function v_u_14.buttons() -- name: buttons
			-- upvalues: (copy) v_u_45, (copy) v_u_47
			return {
				["report"] = v_u_45,
				["cont"] = v_u_47
			}
		end
		function v_u_14.frame() -- name: frame
			-- upvalues: (copy) v_u_33
			return v_u_33
		end
		function v_u_14.snapshot() -- name: snapshot
			-- upvalues: (ref) v_u_16, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_17
			return v_u_16 and {
				["model"] = v_u_18,
				["openedAt"] = v_u_19,
				["deadline"] = v_u_20,
				["hidden"] = v_u_17
			} or nil
		end
		function v_u_14.restore(p162) -- name: restore
			-- upvalues: (ref) v_u_15, (ref) v_u_18, (ref) v_u_16, (ref) v_u_17, (ref) v_u_19, (ref) v_u_20, (copy) v_u_93, (ref) v_u_32, (copy) v_u_51, (copy) v_u_129, (copy) v_u_117, (copy) v_u_33
			if v_u_15 and type(p162) == "table" then
				local v163 = p162.model
				if type(v163) == "table" then
					v_u_18 = p162.model
					local v164 = p162.hidden == true
					v_u_16 = true
					v_u_17 = v164
					local v165 = p162.openedAt
					local v166 = p162.deadline
					v_u_19 = v165
					v_u_20 = v166
					local v167 = v_u_93
					local v168 = v_u_18
					local v169, v170 = pcall(v167, v168, true)
					if not v169 then
						v_u_32 = v_u_32 + 1
						warn("[PvpKillCard] fill failed on restore, plain card shown:", v170)
						local v171 = v_u_51
						pcall(v171)
						v_u_129(v_u_18)
					end
					local v172 = v_u_117
					pcall(v172)
					v_u_33.Visible = not v_u_17
					return
				end
			end
		end
		function v_u_14.state() -- name: state
			-- upvalues: (copy) v_u_13, (ref) v_u_21, (ref) v_u_16, (ref) v_u_17, (copy) v_u_33, (ref) v_u_28, (ref) v_u_18, (copy) v_u_38, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (ref) v_u_20, (ref) v_u_27, (ref) v_u_25, (ref) v_u_26, (ref) v_u_32, (copy) v_u_45, (ref) v_u_30, (copy) v_u_37, (ref) v_u_31, (ref) v_u_22, (ref) v_u_23
			local v173 = v_u_13()
			local v174
			if v_u_21 then
				v174 = v_u_21.state()
			else
				v174 = nil
			end
			local v175 = {
				["open"] = v_u_16,
				["hidden"] = v_u_17,
				["visible"] = v_u_33.Visible,
				["mode"] = v_u_28
			}
			local v176
			if v_u_18 then
				v176 = v_u_18.uid
			else
				v176 = nil
			end
			v175.uid = v176
			v175.name = v_u_38.Text
			v175.title = v_u_42.Text
			v175.stats = v_u_43.Text
			v175.weapon = v_u_44.Text
			local v177
			if v_u_18 then
				v177 = v_u_18.anim
			else
				v177 = nil
			end
			v175.anim = v177
			local v178
			if v_u_18 then
				v178 = v_u_18.bg
			else
				v178 = nil
			end
			v175.bg = v178
			local v179
			if v_u_18 then
				v179 = v_u_18.frame
			else
				v179 = nil
			end
			v175.frameId = v179
			local v180
			if v_u_16 then
				local v181 = v_u_20 - v173
				v180 = math.max(0, v181)
			else
				v180 = 0
			end
			v175.left = v180
			v175.card = v_u_27
			v175.closedBy = v_u_25
			v175.shown = v_u_26
			v175.failed = v_u_32
			v175.reportVisible = v_u_45.Visible
			v175.figure = v174
			v175.animStarted = v_u_30
			v175.thumbVisible = v_u_37.Visible
			v175.layers = v_u_31
			v175.bgLayer = v_u_22 ~= nil
			v175.frameLayer = v_u_23 ~= nil
			local v182
			if v_u_23 == nil then
				v182 = false
			else
				v182 = v_u_23.isImage == true
			end
			v175.frameImage = v182
			local v183
			if v_u_22 then
				v183 = v_u_22.info
			else
				v183 = nil
			end
			v175.bgInfo = v183
			return v175
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_31, (copy) v_u_33
			v_u_15 = false
			v_u_16 = false
			v_u_17 = false
			v_u_18 = nil
			if v_u_21 then
				local v184 = v_u_21.destroy
				pcall(v184)
				v_u_21 = nil
			end
			if v_u_22 then
				local v185 = v_u_22.destroy
				pcall(v185)
				v_u_22 = nil
			end
			if v_u_23 then
				local v186 = v_u_23.destroy
				pcall(v186)
				v_u_23 = nil
			end
			v_u_31 = 0
			local function v187()
				-- upvalues: (ref) v_u_33
				v_u_33:Destroy()
			end
			pcall(v187)
		end
		return v_u_14
	end
}
return v_u_188