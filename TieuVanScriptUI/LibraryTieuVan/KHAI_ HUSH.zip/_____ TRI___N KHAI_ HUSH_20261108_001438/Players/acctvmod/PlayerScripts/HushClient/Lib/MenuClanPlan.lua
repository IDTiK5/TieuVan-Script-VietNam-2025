-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanPlan

local v_u_315 = {
	["GAP"] = 12,
	["PAD"] = 14,
	["TOUCH"] = 44,
	["CHAR_W"] = 7.8,
	["BODY_CHAR_W"] = 8.4,
	["LINE_H"] = 18,
	["colsFor"] = function(p1) -- name: colsFor
		local v2 = tonumber(p1) or 0
		return v2 >= 1100 and 3 or (v2 >= 700 and 2 or 1)
	end,
	["chipW"] = function(p3, _) -- name: chipW
		-- upvalues: (copy) v_u_315
		local v4 = #tostring(p3 or "") * v_u_315.CHAR_W + 18
		return math.ceil(v4)
	end,
	["lines"] = function(p5, p6, p7) -- name: lines
		-- upvalues: (copy) v_u_315
		local v8 = tostring(p5 or "")
		local v9 = (tonumber(p6) or 100) / (tonumber(p7) or v_u_315.BODY_CHAR_W)
		local v10 = math.floor(v9)
		local v11 = math.max(1, v10)
		local v12 = 0
		local v13 = 1
		for v14 in string.gmatch(v8, "%S+") do
			local v15 = #v14
			if v12 == 0 then
				v12 = v15
			elseif v12 + 1 + v15 <= v11 then
				v12 = v12 + (v15 + 1)
			else
				v13 = v13 + 1
				v12 = v15
			end
			while v11 < v12 do
				v13 = v13 + 1
				v12 = v12 - v11
			end
		end
		return v13
	end,
	["flow"] = function(p16, p17, p18, p19) -- name: flow
		local v20 = math.max(1, p18)
		local v21 = (p16 - (v20 - 1) * p17) / v20
		local v22 = math.floor(v21)
		local v23 = #p19
		local v24 = 1
		local v25 = 0
		local v26 = {}
		while v24 <= v23 do
			local v27 = 0
			for v28 = 0, v20 - 1 do
				local v29 = p19[v24 + v28] or 0
				v27 = math.max(v27, v29)
			end
			for v30 = 0, v20 - 1 do
				if not p19[v24 + v30] then
					continue
				end
				v26[v24 + v30] = {
					["x"] = v30 * (v22 + p17),
					["y"] = v25,
					["w"] = v22,
					["h"] = v27
				}
			end
			v25 = v25 + (v27 + p17)
			v24 = v24 + v20
		end
		local v31 = v25 - p17
		return v26, math.max(0, v31)
	end,
	["chipRow"] = function(p32, p33, p34, p35) -- name: chipRow
		local v36 = 0
		local v37 = 0
		local v38 = {}
		for v39, v40 in p33 do
			local v41 = math.min(v40, p32)
			if v36 > 0 and p32 < v36 + v41 then
				v37 = v37 + (p34 + p35)
				v36 = 0
			end
			v38[v39] = {
				["x"] = v36,
				["y"] = v37,
				["w"] = v41,
				["h"] = p34
			}
			v36 = v36 + (v41 + p35)
		end
		if #p33 == 0 then
			return v38, 0
		else
			return v38, v37 + p34
		end
	end,
	["parts"] = function(p42, p43) -- name: parts
		-- upvalues: (copy) v_u_315
		local v44 = {
			["title"] = {
				["x"] = nil,
				["y"] = 10,
				["w"] = nil,
				["h"] = 16,
				["x"] = v_u_315.PAD,
				["w"] = p42 - 2 * v_u_315.PAD
			}
		}
		local v45 = {
			["x"] = nil,
			["y"] = 32,
			["w"] = nil,
			["h"] = nil,
			["x"] = v_u_315.PAD,
			["w"] = p42 - 2 * v_u_315.PAD
		}
		local v46 = p43 - 32 - 12
		v45.h = math.max(0, v46)
		v44.body = v45
		return v44
	end,
	["overview"] = function(p47, p48, p49) -- name: overview
		-- upvalues: (copy) v_u_315
		local v50 = p48 == "phone"
		local v51 = v_u_315.GAP
		local v52 = v50 and 78 or 100
		local v53 = v50 and 52 or 72
		local v54 = v53 * 1.6
		local v55 = math.floor(v54)
		local v56 = v_u_315.PAD + v55 + 14
		local v57 = v50 and 28 or 34
		local v58 = v50 and 22 or 24
		local v59 = (v52 - v57 - 8 - v58) / 2
		local v60 = math.floor(v59)
		local v61 = {}
		local v62 = {
			["x"] = v_u_315.PAD
		}
		local v63 = (v52 - v53) / 2
		v62.y = math.floor(v63)
		v62.w = v55
		v62.h = v53
		v61.badge = v62
		v61.name = {
			["x"] = v56,
			["y"] = v60,
			["w"] = p47 - v56 - v_u_315.PAD,
			["h"] = v57
		}
		local v64 = p49 and (p49.chips or { "REQUEST", "MEMBER", "1 / 30 members" }) or { "REQUEST", "MEMBER", "1 / 30 members" }
		local v65 = 0
		local v66 = {
			["W"] = p47,
			["kind"] = p48,
			["groups"] = {}
		}
		for v67, v68 in v64 do
			local v69 = v_u_315.chipW(v68)
			if v67 == #v64 then
				local v70 = #tostring(v68) * v_u_315.BODY_CHAR_W * 0.8
				v69 = math.ceil(v70) + 4
			end
			v61["chip" .. v67] = {
				["x"] = v56,
				["y"] = v60 + v57 + 8,
				["w"] = v69,
				["h"] = v58
			}
			v56 = v56 + (v69 + 8)
		end
		v66.header = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v65,
			["w"] = p47,
			["h"] = v52
		}
		v66.headerParts = v61
		v66.groups[#v66.groups + 1] = {
			["name"] = "header",
			["box"] = nil,
			["parts"] = nil,
			["rel"] = true,
			["box"] = v66.header,
			["parts"] = v61
		}
		local v71 = v65 + (v52 + v51)
		local v72 = p47 >= 640 and 4 or 2
		local v73 = v50 and 62 or 72
		local v74, v75 = v_u_315.flow(p47, v51, v72, {
			v73,
			v73,
			v73,
			v73
		})
		v66.stats = {}
		for v76, v77 in v74 do
			local v78 = v77.w
			local v79 = {
				["x"] = v77.x,
				["y"] = v71 + v77.y,
				["w"] = v77.w,
				["h"] = v77.h
			}
			local v80 = {
				["label"] = {
					["x"] = 12,
					["y"] = 8,
					["w"] = nil,
					["h"] = 14,
					["w"] = v78 - 24
				},
				["value"] = {
					["x"] = 12,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v50 and 22 or 24,
					["w"] = v78 - 24,
					["h"] = v50 and 24 or 28
				},
				["bar"] = {
					["x"] = 12,
					["y"] = nil,
					["w"] = nil,
					["h"] = 4,
					["y"] = v77.h - 12,
					["w"] = v78 - 24
				}
			}
			v66.stats[v76] = {
				["box"] = v79,
				["parts"] = v80
			}
			v66.groups[#v66.groups + 1] = {
				["name"] = nil,
				["box"] = nil,
				["parts"] = nil,
				["rel"] = true,
				["name"] = "stat" .. v76,
				["box"] = v79,
				["parts"] = v80
			}
		end
		local v81 = v71 + (v75 + v51)
		if p49 and p49.expand then
			local v82 = v_u_315.TOUCH
			local v83 = p49.touch
			local v84 = tonumber(v83) or v_u_315.TOUCH
			local v85 = math.max(v82, v84)
			local v86 = v85 + 20
			local v87 = math.max(v86, 70)
			local v88 = p47 - 2 * v_u_315.PAD - 120
			local v89 = math.max(60, v88)
			local v90 = math.min(130, v89)
			local v91 = p47 - 2 * v_u_315.PAD - v90 - 12
			local v92 = math.max(40, v91)
			local v93 = {
				["text"] = {
					["x"] = nil,
					["y"] = 8,
					["w"] = nil,
					["h"] = 18,
					["x"] = v_u_315.PAD,
					["w"] = v92
				},
				["bar"] = {
					["x"] = nil,
					["y"] = 30,
					["w"] = nil,
					["h"] = 6,
					["x"] = v_u_315.PAD,
					["w"] = v92
				},
				["reason"] = {
					["x"] = nil,
					["y"] = 40,
					["w"] = nil,
					["h"] = 16,
					["x"] = v_u_315.PAD,
					["w"] = v92
				}
			}
			local v94 = {
				["x"] = p47 - v_u_315.PAD - v90
			}
			local v95 = (v87 - v85) / 2
			v94.y = math.floor(v95)
			v94.w = v90
			v94.h = v85
			v93.button = v94
			v66.expand = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v81,
				["w"] = p47,
				["h"] = v87
			}
			v66.expandParts = v93
			v66.groups[#v66.groups + 1] = {
				["name"] = "expand",
				["box"] = nil,
				["parts"] = nil,
				["rel"] = true,
				["box"] = v66.expand,
				["parts"] = v93
			}
			v81 = v81 + (v87 + v51)
		end
		if p49 then
			local v96 = p49.hint2
			if type(v96) == "string" and p49.hint2 ~= "" then
				local v97 = 14 + v_u_315.LINE_H
				v66.hint2 = {
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v81,
					["w"] = p47,
					["h"] = v97
				}
				v66.hint2Parts = {
					["text"] = {
						["x"] = nil,
						["y"] = 7,
						["w"] = nil,
						["h"] = nil,
						["x"] = v_u_315.PAD,
						["w"] = p47 - 2 * v_u_315.PAD,
						["h"] = v_u_315.LINE_H
					}
				}
				v66.groups[#v66.groups + 1] = {
					["name"] = "hint2",
					["box"] = nil,
					["parts"] = nil,
					["rel"] = true,
					["box"] = v66.hint2,
					["parts"] = v66.hint2Parts
				}
				v81 = v81 + (v97 + v51)
			end
		end
		if p49 then
			local v98 = p49.hint
			if type(v98) == "string" and p49.hint ~= "" then
				local v99 = v_u_315.lines
				local v100 = p49.hint
				local v101 = p47 - 2 * v_u_315.PAD
				local v102 = math.min(2, v99(v100, v101))
				local v103 = 14 + v102 * v_u_315.LINE_H
				v66.hint = {
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v81,
					["w"] = p47,
					["h"] = v103
				}
				v66.hintParts = {
					["text"] = {
						["x"] = nil,
						["y"] = 7,
						["w"] = nil,
						["h"] = nil,
						["x"] = v_u_315.PAD,
						["w"] = p47 - 2 * v_u_315.PAD,
						["h"] = v102 * v_u_315.LINE_H
					}
				}
				v66.groups[#v66.groups + 1] = {
					["name"] = "hint",
					["box"] = nil,
					["parts"] = nil,
					["rel"] = true,
					["box"] = v66.hint,
					["parts"] = v66.hintParts
				}
				v81 = v81 + (v103 + v51)
			end
		end
		local v104 = 1
		local v105 = { "crit", "desc" }
		if p49 and p49.standing then
			table.insert(v105, "standing")
		end
		if p49 and p49.result then
			table.insert(v105, "result")
		end
		local v106 = v50 and 1 or v_u_315.colsFor(p47)
		local v107 = (p47 - (v106 - 1) * v51) / v106
		local v108 = math.floor(v107) - 2 * v_u_315.PAD
		local v109 = {}
		for v110, v111 in v105 do
			local v112 = 100
			if v111 == "crit" then
				local v113
				v113, v104 = v_u_315.chipRow(v108, p49 and (p49.critWidths or { 80 }) or { 80 }, 26, 6)
				v112 = 32 + v104 + 14
			elseif v111 == "desc" then
				local v114 = v_u_315.lines
				local v115 = p49 and (p49.desc or "") or ""
				v112 = 32 + math.max(2, v114(v115, v108)) * v_u_315.LINE_H + 14
			elseif v111 == "standing" then
				if v50 then
					v112 = 108
				else
					v112 = 120
				end
			elseif v111 == "result" then
				v112 = 96
			end
			v109[v110] = v112
		end
		local v116, v117 = v_u_315.flow(p47, v51, v106, v109)
		v66.body = {}
		for v118, v119 in v105 do
			local v120 = v116[v118]
			local v121 = {
				["x"] = v120.x,
				["y"] = v81 + v120.y,
				["w"] = v120.w,
				["h"] = v120.h
			}
			v66.body[v119] = v121
			local v122 = {
				["name"] = nil,
				["box"] = nil,
				["parts"] = nil,
				["rel"] = true,
				["name"] = v119,
				["box"] = v121,
				["parts"] = v_u_315.parts(v120.w, v120.h)
			}
			v66.groups[#v66.groups + 1] = v122
		end
		v66.critRows = v104
		v66.bodyCols = v106
		local v123 = v81 + (v117 + v51)
		local v124 = v_u_315.PREVIEW_MAX
		local v125 = 0
		local v126
		if p49 then
			v126 = p49.tops
		else
			v126 = p49
		end
		local v127 = tonumber(v126) or 0
		local v128 = math.floor(v127)
		local v129 = math.max(v125, v128)
		local v130 = math.min(v124, v129)
		local v131 = v_u_315.PREVIEW_MAX
		local v132 = 0
		if p49 then
			p49 = p49.boardRows
		end
		local v133 = tonumber(p49) or 0
		local v134 = math.floor(v133)
		local v135 = math.max(v132, v134)
		local v136 = math.min(v131, v135)
		v66.preview = {}
		v66.previewRows = {}
		if v130 > 0 or v136 > 0 then
			local v137 = {}
			local v138 = {}
			local v139 = {}
			if v130 > 0 then
				table.insert(v137, "tops")
				table.insert(v138, v130)
				local v140 = v_u_315.previewHeight
				table.insert(v139, v140(v130))
			end
			if v136 > 0 then
				table.insert(v137, "boardMini")
				table.insert(v138, v136)
				local v141 = v_u_315.previewHeight
				table.insert(v139, v141(v136))
			end
			local v142
			if v50 then
				v142 = 1
			else
				local v143 = #v137
				local v144 = v_u_315.colsFor
				v142 = math.min(v143, v144(p47))
			end
			local v145, v146 = v_u_315.flow(p47, v51, math.max(1, v142), v139)
			for v147, v148 in v137 do
				local v149 = v145[v147]
				local v150 = {
					["x"] = v149.x,
					["y"] = v123 + v149.y,
					["w"] = v149.w,
					["h"] = v149.h
				}
				v66.preview[v148] = v150
				v66.previewRows[v148] = v_u_315.previewParts(v149.w, v149.h, v138[v147])
				v66.groups[#v66.groups + 1] = {
					["name"] = nil,
					["box"] = nil,
					["parts"] = nil,
					["rel"] = true,
					["name"] = v148,
					["box"] = v150,
					["parts"] = v66.previewRows[v148]
				}
			end
			v123 = v123 + (v146 + v51)
		end
		local v151 = v50 and 56 or 64
		v66.footer = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v123,
			["w"] = p47,
			["h"] = v151
		}
		local v152 = {
			["note"] = {
				["x"] = nil,
				["y"] = 6,
				["w"] = nil,
				["h"] = nil,
				["x"] = v_u_315.PAD,
				["w"] = p47 - 2 * v_u_315.PAD - 170,
				["h"] = v151 - 12
			}
		}
		local v153 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 150,
			["h"] = nil,
			["x"] = p47 - v_u_315.PAD - 150
		}
		local v154 = (v151 - v_u_315.TOUCH) / 2
		v153.y = math.floor(v154)
		v153.h = v_u_315.TOUCH
		v152.button = v153
		v66.footerParts = v152
		v66.groups[#v66.groups + 1] = {
			["name"] = "footer",
			["box"] = nil,
			["parts"] = nil,
			["rel"] = true,
			["box"] = v66.footer,
			["parts"] = v66.footerParts
		}
		v66.height = v123 + v151
		return v66
	end,
	["PREVIEW_ROW"] = 40,
	["PREVIEW_MAX"] = 5,
	["previewHeight"] = function(p155) -- name: previewHeight
		-- upvalues: (copy) v_u_315
		return 32 + p155 * (v_u_315.PREVIEW_ROW + 4) + 8
	end,
	["previewParts"] = function(p156, _, p157) -- name: previewParts
		-- upvalues: (copy) v_u_315
		local v158 = {}
		local v159 = {
			["x"] = nil,
			["y"] = 10,
			["w"] = nil,
			["h"] = 16,
			["x"] = v_u_315.PAD
		}
		local v160 = p156 - 2 * v_u_315.PAD
		v159.w = math.max(1, v160)
		v158.title = v159
		for v161 = 1, p157 do
			local v162 = "row" .. v161
			local v163 = {
				["x"] = 10,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = 32 + (v161 - 1) * (v_u_315.PREVIEW_ROW + 4)
			}
			local v164 = p156 - 20
			v163.w = math.max(1, v164)
			v163.h = v_u_315.PREVIEW_ROW
			v158[v162] = v163
		end
		return v158
	end,
	["HINT_H"] = 24,
	["membersHint"] = function(p165) -- name: membersHint
		-- upvalues: (copy) v_u_315
		local v166 = {
			["box"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p165,
				["h"] = v_u_315.HINT_H
			}
		}
		local v167 = {
			["x"] = 8,
			["y"] = 2,
			["w"] = nil,
			["h"] = nil
		}
		local v168 = p165 - 16
		v167.w = math.max(1, v168)
		v167.h = v_u_315.HINT_H - 4
		v166.text = v167
		return v166
	end,
	["memberRow"] = function(p169, p170, p171) -- name: memberRow
		local v172 = p170 - 8
		local v173 = math.min(36, v172)
		local v174 = p169 < 400 and 88 or (p169 < 460 and 104 or 120)
		local v175 = p169 < 400 and 52 or 64
		local v176 = p171 and 24 or 0
		local v177 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = p169 - 8 - v176,
			["w"] = v176,
			["h"] = p170
		}
		local v178 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v177.x - 4 - v175,
			["w"] = v175,
			["h"] = p170
		}
		local v179 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = nil,
			["h"] = 22,
			["x"] = v178.x - 4 - v174
		}
		local v180 = (p170 - 22) / 2
		v179.y = math.floor(v180)
		v179.w = v174
		local v181 = v179.x - 8
		local v182 = v173 + 14 + 10
		local v183 = {
			["bar"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 4,
				["h"] = nil,
				["h"] = p170
			}
		}
		local v184 = {
			["x"] = 14,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil
		}
		local v185 = (p170 - v173) / 2
		v184.y = math.floor(v185)
		v184.w = v173
		v184.h = v173
		v183.avatar = v184
		local v186 = {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v182
		}
		local v187 = v181 - v182
		v186.w = math.max(40, v187)
		v186.h = p170
		v183.name = v186
		v183.chip = v179
		v183.pts = v178
		v183.check = v177
		return v183
	end,
	["defaultMember"] = function(p188, p189) -- name: defaultMember
		if type(p188) ~= "table" then
			return nil
		end
		local v190 = nil
		for _, v191 in p188 do
			if type(v191) ~= "table" or v191.uid == nil then
				continue
			end
			local v192 = v191.uid
			local v193 = tostring(v192)
			if v190 == nil then
				v190 = v193
			end
			if p189 == nil or v193 ~= tostring(p189) then
				continue
			end
			return v193
		end
		return v190
	end,
	["memberDetail"] = function(p194, p195, p196) -- name: memberDetail
		-- upvalues: (copy) v_u_315
		local v197 = {
			["groups"] = {}
		}
		local v198
		if p195 then
			v197.back = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 110,
				["h"] = nil,
				["h"] = v_u_315.TOUCH
			}
			local v199 = v197.groups
			local v200 = {
				["name"] = "back",
				["box"] = nil,
				["parts"] = nil,
				["box"] = v197.back,
				["parts"] = {}
			}
			table.insert(v199, v200)
			v198 = v_u_315.TOUCH + 8
		else
			v198 = 0
		end
		local v201 = p195 and 64 or 96
		local v202 = v201 + 32
		local v203 = v201 + 16 + 16
		local v204 = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v198,
			["w"] = p194,
			["h"] = v202
		}
		local v205 = p195 and 28 or 34
		local v206 = v205 + 18 + 10
		local v207 = {
			["avatar"] = {
				["x"] = 16,
				["y"] = 16,
				["w"] = nil,
				["h"] = nil,
				["w"] = v201,
				["h"] = v201
			},
			["name"] = {
				["x"] = nil,
				["y"] = 18,
				["w"] = nil,
				["h"] = nil,
				["x"] = v203,
				["w"] = p194 - v203 - 16,
				["h"] = v205
			},
			["rank"] = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 24,
				["x"] = v203,
				["y"] = v206,
				["w"] = p196[1] or 80
			}
		}
		if (p196[2] or 0) > 0 then
			v207.online = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 24,
				["x"] = v203 + (p196[1] or 80) + 8,
				["y"] = v206,
				["w"] = p196[2]
			}
		end
		v197.card = v204
		v197.cardParts = v207
		local v208 = v197.groups
		table.insert(v208, {
			["name"] = "card",
			["box"] = nil,
			["parts"] = nil,
			["box"] = v204,
			["parts"] = v207
		})
		local v209 = v198 + (v202 + v_u_315.GAP)
		local v210 = (p194 - v_u_315.GAP) / 2
		local v211 = math.floor(v210)
		v197.stats = {}
		for v212 = 1, 2 do
			local v213 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 62,
				["x"] = (v212 - 1) * (v211 + v_u_315.GAP),
				["y"] = v209,
				["w"] = v211
			}
			local v214 = {
				["label"] = {
					["x"] = 12,
					["y"] = 8,
					["w"] = nil,
					["h"] = 14,
					["w"] = v211 - 24
				},
				["value"] = {
					["x"] = 12,
					["y"] = 26,
					["w"] = nil,
					["h"] = 26,
					["w"] = v211 - 24
				}
			}
			v197.stats[v212] = {
				["box"] = v213,
				["parts"] = v214
			}
			local v215 = v197.groups
			local v216 = {
				["name"] = "stat" .. v212,
				["box"] = v213,
				["parts"] = v214
			}
			table.insert(v215, v216)
		end
		local v217 = v209 + 78
		v197.rank = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v217,
			["w"] = math.min(p194, 320),
			["h"] = v_u_315.TOUCH
		}
		local v218 = v197.groups
		local v219 = {
			["name"] = "rankRow",
			["box"] = nil,
			["parts"] = nil,
			["box"] = v197.rank,
			["parts"] = {}
		}
		table.insert(v218, v219)
		local v220 = v217 + (v_u_315.TOUCH + 8)
		v197.actions = {}
		for v221 = 1, 3 do
			local v222 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = 130,
				["h"] = nil,
				["x"] = (v221 - 1) * 138,
				["y"] = v220,
				["h"] = v_u_315.TOUCH
			}
			v197.actions[v221] = v222
			local v223 = v197.groups
			local v224 = {
				["name"] = "act" .. v221,
				["box"] = v222,
				["parts"] = {}
			}
			table.insert(v223, v224)
		end
		v197.note = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 20,
			["y"] = v220,
			["w"] = p194
		}
		v197.height = v220 + v_u_315.TOUCH + 12
		return v197
	end,
	["logGrid"] = function(p225) -- name: logGrid
		-- upvalues: (copy) v_u_315
		local v226 = p225 >= 1100 and 2 or 1
		local v227 = v_u_315.GAP
		local v228 = (p225 - (v226 - 1) * v227) / v226
		return v226, math.floor(v228), 56
	end,
	["logCard"] = function(p229, p230) -- name: logCard
		local v231 = {
			["bar"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 3,
				["h"] = nil,
				["h"] = p230
			}
		}
		local v232 = {
			["x"] = 14,
			["y"] = nil,
			["w"] = 36,
			["h"] = 36
		}
		local v233 = (p230 - 36) / 2
		v232.y = math.floor(v233)
		v231.avatar = v232
		local v234 = {
			["x"] = 60,
			["y"] = 4,
			["w"] = nil,
			["h"] = nil
		}
		local v235 = p229 - 60 - 84 - 18
		v234.w = math.max(40, v235)
		v234.h = p230 - 8
		v231.text = v234
		v231.when = {
			["x"] = nil,
			["y"] = 0,
			["w"] = 84,
			["h"] = nil,
			["x"] = p229 - 84 - 10,
			["h"] = p230
		}
		return v231
	end,
	["boardCard"] = function(p236, p237, p238) -- name: boardCard
		local v239 = p238 and 44 or 40
		local v240 = p238 and 76 or 64
		local v241 = v239 + 12 + 8 + v240 + 12
		local v242 = p238 and 34 or 28
		local v243 = {
			["medal"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 4,
				["h"] = nil,
				["h"] = p237
			},
			["place"] = {
				["x"] = 12,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v239,
				["h"] = p237
			}
		}
		local v244 = {
			["x"] = v239 + 12 + 8
		}
		local v245 = (p237 - v242) / 2
		v244.y = math.floor(v245)
		v244.w = v240
		v244.h = v242
		v243.tag = v244
		local v246 = {
			["x"] = nil,
			["y"] = 6,
			["w"] = nil,
			["h"] = nil,
			["x"] = v241
		}
		local v247 = p236 - v241 - 96 - 16
		v246.w = math.max(40, v247)
		local v248 = (p237 - 12) / 2
		v246.h = math.floor(v248)
		v243.name = v246
		local v249 = {
			["x"] = v241
		}
		local v250 = (p237 - 12) / 2
		v249.y = math.floor(v250) + 6
		local v251 = p236 - v241 - 96 - 16
		v249.w = math.max(40, v251)
		local v252 = (p237 - 12) / 2
		v249.h = math.ceil(v252)
		v243.sub = v249
		v243.pts = {
			["x"] = nil,
			["y"] = 0,
			["w"] = 96,
			["h"] = nil,
			["x"] = p236 - 96 - 12,
			["h"] = p237
		}
		return v243
	end,
	["boardSplit"] = function(p253, p254) -- name: boardSplit
		if not p254 then
			return p253, 0, 0
		end
		local v255 = p253 * 0.36
		local v256 = math.floor(v255)
		local v257 = math.max(300, v256)
		return p253 - v257 - 16, v257, 16
	end,
	["ranksGrid"] = function(p258, p259, p260) -- name: ranksGrid
		-- upvalues: (copy) v_u_315
		local v261 = v_u_315.GAP + 4
		local v262 = v_u_315.colsFor(p258)
		if math.max(1, p259) < v262 then
			v262 = math.max(1, p259)
		end
		local v263 = (p258 - (v262 - 1) * v261) / v262
		local v264 = math.floor(v263)
		local v265
		if v262 == 1 then
			v265 = math.min(p258, 560)
		else
			v265 = math.min(v264, 420)
		end
		local v266 = {}
		for v267 = 1, p259 do
			local v268 = (v267 - 1) % v262
			local v269 = (v267 - 1) // v262
			v266[v267] = {
				["x"] = v268 * (v265 + v261),
				["y"] = v269 * (p260 + v261),
				["w"] = v265,
				["h"] = p260
			}
		end
		local v270 = p259 / v262
		local v271 = math.ceil(v270)
		return {
			["cols"] = v262,
			["cardW"] = v265,
			["gap"] = v261,
			["rects"] = v266,
			["height"] = p259 == 0 and 0 or v271 * p260 + (v271 - 1) * v261
		}
	end,
	["rankCard"] = function(p272, p273, p274) -- name: rankCard
		local v275 = p274 + 22 + 8
		local v276 = {}
		for v277 = 1, p273 do
			v276[v277] = {
				["x"] = 12,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v275,
				["w"] = p272 - 24,
				["h"] = p274
			}
			v275 = v275 + p274
		end
		local v278 = {
			["x"] = 12,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v275,
			["w"] = p272 - 24,
			["h"] = p274
		}
		local v279 = v275 + (p274 + 12)
		local v280 = {
			["head"] = {
				["x"] = 12,
				["y"] = 6,
				["w"] = nil,
				["h"] = 14,
				["w"] = p272 - 24
			},
			["name"] = {
				["x"] = 12,
				["y"] = 22,
				["w"] = nil,
				["h"] = nil,
				["w"] = p272 - 24,
				["h"] = p274
			},
			["toggles"] = v276,
			["wpd"] = v278,
			["height"] = v279
		}
		return v280
	end,
	["overlaps"] = function(p281, p282) -- name: overlaps
		local v283
		if p281.x < p282.x + p282.w and (p282.x < p281.x + p281.w and p281.y < p282.y + p282.h) then
			v283 = p282.y < p281.y + p281.h
		else
			v283 = false
		end
		return v283
	end,
	["resultCard"] = function(p284) -- name: resultCard
		local v285 = {
			["h"] = 108,
			["head"] = nil,
			["place"] = nil,
			["btn"] = nil
		}
		local v286 = {
			["x"] = 14,
			["y"] = 10,
			["w"] = nil,
			["h"] = 16
		}
		local v287 = p284 - 28
		v286.w = math.max(1, v287)
		v285.head = v286
		local v288 = {
			["x"] = 14,
			["y"] = 28,
			["w"] = nil,
			["h"] = 24
		}
		local v289 = p284 - 28
		v288.w = math.max(1, v289)
		v285.place = v288
		local v290 = {
			["x"] = 14,
			["y"] = 56,
			["w"] = nil,
			["h"] = 44
		}
		local v291 = p284 - 28
		local v292 = math.max(1, v291)
		v290.w = math.min(160, v292)
		v285.btn = v290
		return v285
	end,
	["audit"] = function(p293, p294) -- name: audit
		local v295 = {}
		for v296, v297 in p293 do
			local v298 = v297.box
			if v298.x < 0 or v298.x + v298.w > p294 + 0.001 then
				local v299 = v297.name .. " leaves the width"
				table.insert(v295, v299)
			end
			if v298.w <= 0 or v298.h <= 0 then
				local v300 = v297.name .. " has no size"
				table.insert(v295, v300)
			end
			for v301 = v296 + 1, #p293 do
				local v302 = p293[v301].box
				local v303
				if v298.x < v302.x + v302.w and (v302.x < v298.x + v298.w and v298.y < v302.y + v302.h) then
					v303 = v302.y < v298.y + v298.h
				else
					v303 = false
				end
				if not v303 then
					continue
				end
				local v304 = v297.name .. " overlaps " .. p293[v301].name
				table.insert(v295, v304)
			end
			local v305 = {}
			for v306 in v297.parts or {} do
				table.insert(v305, v306)
			end
			table.sort(v305)
			for v307, v308 in v305 do
				local v309 = v297.parts[v308]
				if v309.x < 0 or (v309.y < 0 or (v309.x + v309.w > v298.w + 0.001 or v309.y + v309.h > v298.h + 0.001)) then
					local v310 = v297.name .. "." .. v308 .. " leaves its box"
					table.insert(v295, v310)
				end
				for v311 = v307 + 1, #v305 do
					local v312 = v297.parts[v305[v311]]
					local v313
					if v309.x < v312.x + v312.w and (v312.x < v309.x + v309.w and v309.y < v312.y + v312.h) then
						v313 = v312.y < v309.y + v309.h
					else
						v313 = false
					end
					if not v313 then
						continue
					end
					local v314 = v297.name .. "." .. v308 .. " overlaps " .. v305[v311]
					table.insert(v295, v314)
				end
			end
		end
		return v295
	end
}
return v_u_315