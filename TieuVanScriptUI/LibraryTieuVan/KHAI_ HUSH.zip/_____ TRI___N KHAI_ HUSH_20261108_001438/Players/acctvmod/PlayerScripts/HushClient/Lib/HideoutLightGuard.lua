-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutLightGuard

local v_u_24 = {
	["INTERVAL"] = 0.5,
	["DARK_AFTER"] = 1.5,
	["BRIGHTNESS"] = 1.35,
	["new"] = function() -- name: new
		return {
			["darkSince"] = nil,
			["fixes"] = 0,
			["reported"] = false
		}
	end,
	["lit"] = function(p1) -- name: lit
		local v2 = 0
		local v3 = 0
		for _, v4 in p1 do
			if v4.Parent == nil then
				continue
			end
			v2 = v2 + 1
			local v5 = v4:FindFirstChildOfClass("PointLight")
			if v5 == nil or (not v5.Enabled or v5.Brightness <= 0) then
				continue
			end
			v3 = v3 + 1
		end
		return v3, v2
	end,
	["advance"] = function(p6, p7, p8, p9) -- name: advance
		-- upvalues: (copy) v_u_24
		if p9 <= 0 or p8 > 0 then
			p6.darkSince = nil
			return "idle"
		end
		local v10 = p6.darkSince
		if v10 == nil then
			p6.darkSince = p7
			return "idle"
		end
		if p7 - v10 < v_u_24.DARK_AFTER then
			return "idle"
		end
		p6.darkSince = p7
		return "fix"
	end,
	["force"] = function(p11) -- name: force
		-- upvalues: (copy) v_u_24
		local v12 = 0
		for _, v13 in p11 do
			if v13.Parent == nil then
				continue
			end
			local v14 = v13:FindFirstChildOfClass("PointLight")
			if v14 ~= nil then
				local v15 = v14.Brightness
				local v16 = v_u_24.BRIGHTNESS
				v14.Brightness = math.max(v15, v16)
				v14.Enabled = true
				v12 = v12 + 1
			end
			v13.Material = Enum.Material.Neon
			local v17 = v13:GetAttribute("LightColor")
			if typeof(v17) ~= "Color3" then
				continue
			end
			v13.Color = v17
		end
		return v12
	end,
	["step"] = function(p18, p19, p20) -- name: step
		-- upvalues: (copy) v_u_24
		local v21, v22 = v_u_24.lit(p20)
		local v23 = v_u_24.advance(p18, p19, v21, v22)
		if v23 == "fix" then
			v_u_24.force(p20)
			p18.fixes = p18.fixes + 1
		end
		return v23, v21, v22
	end
}
return v_u_24