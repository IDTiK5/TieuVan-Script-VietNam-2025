-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RaidEndCine

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("ContentProvider")
local v_u_6 = {}
local v_u_7 = v2.LocalPlayer
local v_u_8 = nil
local v_u_9 = nil
function v_u_6.cardScale(p10, p11, p12) -- name: cardScale
	local v13 = p11 / 1080
	local v14 = p10 / 1920 * 1.25
	local v15 = math.min(v13, v14)
	if p12 then
		local v16 = p10 / 1100
		local v17 = math.min(0.5, v16)
		v15 = math.max(v15, v17)
	end
	return v15
end
local v_u_18 = {
	["active"] = false,
	["endsAt"] = 0,
	["hold"] = 1.8,
	["raidId"] = nil,
	["mode"] = "mia",
	["preview"] = false,
	["conn"] = nil,
	["gui"] = nil,
	["white"] = nil,
	["black"] = nil,
	["card"] = nil,
	["cardTexts"] = nil,
	["cc"] = nil,
	["eqs"] = nil,
	["cutLevel"] = 0,
	["folder"] = nil,
	["jets"] = nil,
	["dir"] = Vector3.new(1, 0, 0),
	["side"] = Vector3.new(0, 0, 1),
	["roar"] = nil,
	["ring"] = nil,
	["fired"] = nil,
	["log"] = nil,
	["leaveAt"] = nil,
	["fade"] = nil,
	["cardTexts"] = {},
	["eqs"] = {},
	["jets"] = {},
	["fired"] = {},
	["log"] = {}
}
local function v_u_25(p19, ...) -- name: audio
	-- upvalues: (ref) v_u_8
	local v20 = v_u_8 and v_u_8.controllers
	if v20 then
		v20 = v_u_8.controllers.Audio
	end
	if not v20 or v20._broken then
		v20 = nil
	end
	if v20 then
		local v21 = v20[p19]
		if type(v21) == "function" then
			local v22 = v20[p19]
			local v23, v24 = pcall(v22, ...)
			if v23 then
				return v24
			end
		end
	end
	return nil
end
local function v_u_38(p26, p27, p28, p29, p30, p31, p32, p33) -- name: label
	local v34 = Instance.new("TextLabel")
	v34.Name = p27
	v34.BackgroundTransparency = 1
	v34.BorderSizePixel = 0
	v34.AnchorPoint = Vector2.new(0.5, 0.5)
	v34.Position = UDim2.new(0.5, 0, 0.5, p32)
	v34.Size = UDim2.new(0.9, 0, 0, p33)
	v34.FontFace = p29
	v34.TextSize = p30
	v34.TextColor3 = p31
	v34.TextTransparency = 1
	v34.TextXAlignment = Enum.TextXAlignment.Center
	v34.TextYAlignment = Enum.TextYAlignment.Center
	v34.TextTruncate = Enum.TextTruncate.AtEnd
	v34.Text = p28
	local v35 = Instance.new("UITextSizeConstraint")
	v35.MaxTextSize = p30
	local v36 = p30 * 0.5
	local v37 = math.floor(v36)
	v35.MinTextSize = math.max(10, v37)
	v35.Parent = v34
	v34.TextScaled = true
	v34.Parent = p26
	return v34
end
local function v_u_40() -- name: underground
	-- upvalues: (copy) v_u_18
	if v_u_18.ug ~= nil then
		return v_u_18.ug
	end
	local v39 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
	if v39 then
		v39 = v39:FindFirstChild("Raid")
	end
	if not v39 then
		return false
	end
	v_u_18.ug = v39:GetAttribute("MapId") == "hollow"
	return v_u_18.ug
end
local function v_u_42() -- name: curtain
	-- upvalues: (copy) v_u_18
	if v_u_18.cur ~= nil then
		return v_u_18.cur
	end
	local v41 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
	if v41 then
		v41 = v41:FindFirstChild("Raid")
	end
	if not v41 then
		return false
	end
	v_u_18.cur = v41:GetAttribute("MapId") == "overture"
	return v_u_18.cur
end
local function v_u_54() -- name: otherMap
	local v43 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
	if v43 then
		v43 = v43:FindFirstChild("Raid")
	end
	local v_u_44
	if v43 then
		v_u_44 = v43:GetAttribute("MapId")
	else
		v_u_44 = v43
	end
	if type(v_u_44) ~= "string" or (v_u_44 == "stillwater" or v_u_44 == "hollow") then
		return nil, nil
	end
	if v43 then
		v43 = v43:GetAttribute("Map")
	end
	local v_u_45 = "town"
	if v_u_44 == "unknown5" then
		local v48, v49, v50 = pcall(function()
			local v46 = require(game:GetService("ReplicatedStorage").Hush.Shared.MapReveal)
			local v47 = v46.clientRevealed()
			return v46.name(v47), v46.fields({
				["id"] = "unknown5"
			}, v47).noun
		end)
		if v48 and type(v49) == "string" then
			return string.upper(v49), type(v50) ~= "string" and "site" or v50
		end
	end
	pcall(function()
		-- upvalues: (copy) v_u_44, (ref) v_u_45
		local v51 = require(game:GetService("ReplicatedStorage").Hush.Shared.Maps).get(v_u_44)
		if v51 then
			local v52 = v51.noun
			if type(v52) == "string" then
				v_u_45 = v51.noun
			end
		end
	end)
	local v53
	if type(v43) == "string" then
		v53 = string.upper(v43)
	else
		v53 = nil
	end
	return v53, v_u_45
end
local function v_u_96() -- name: setCardText
	-- upvalues: (copy) v_u_18, (copy) v_u_42, (ref) v_u_9, (copy) v_u_40, (copy) v_u_54
	local v55 = v_u_18.cardTexts
	if v55.title then
		local v56 = v_u_18.mode == "dead"
		if v_u_42() then
			if v55.kicker then
				local v57 = v55.kicker
				local v58
				if v_u_9 then
					local v59 = v_u_9.track
					if type(v59) == "function" then
						local v60 = v_u_9.track
						local v61, v62 = pcall(v60, "OPERATION HUSH  /  PORT VESPER", 2)
						v58 = (not v61 or type(v62) ~= "string") and "OPERATION HUSH  /  PORT VESPER" or v62
					else
						v58 = "OPERATION HUSH  /  PORT VESPER"
					end
				else
					v58 = "OPERATION HUSH  /  PORT VESPER"
				end
				v57.Text = v58
			end
			local v63 = v55.title
			local v64
			if v_u_9 then
				local v65 = v_u_9.track
				if type(v65) == "function" then
					local v66 = v_u_9.track
					local v67, v68 = pcall(v66, "CURTAIN", 1)
					v64 = (not v67 or type(v68) ~= "string") and "CURTAIN" or v68
				else
					v64 = "CURTAIN"
				end
			else
				v64 = "CURTAIN"
			end
			v63.Text = v64
			v55.sub.Text = v56 and "The Overture ended. Nobody else is coming back." or "The Overture ended. Everything but your secure case is lost."
			return
		else
			local v69 = v_u_40()
			local v70, v71 = v_u_54()
			local v72 = v69 and "site" or (v71 or "town")
			local v73 = game:GetService("ReplicatedStorage"):FindFirstChild("HushRuntime")
			if v73 then
				v73 = v73:FindFirstChild("Raid")
			end
			local v74
			if v73 == nil then
				v74 = false
			else
				v74 = v73:GetAttribute("MapId") == "unknown5"
			end
			local v75
			if v74 then
				if v73 == nil then
					v75 = false
				else
					v75 = v73:GetAttribute("EndVariant") == "stood_down"
				end
			else
				v75 = v74
			end
			if v73 ~= nil and (v73:GetAttribute("MapId") == "tokyo" and v55.kicker) then
				local v76 = v55.kicker
				local v77
				if v_u_9 then
					local v78 = v_u_9.track
					if type(v78) == "function" then
						local v79 = v_u_9.track
						local v80, v81 = pcall(v79, "OPERATION HUSH  /  NOCTURNE", 2)
						v77 = (not v80 or type(v81) ~= "string") and "OPERATION HUSH  /  NOCTURNE" or v81
					else
						v77 = "OPERATION HUSH  /  NOCTURNE"
					end
				else
					v77 = "OPERATION HUSH  /  NOCTURNE"
				end
				v76.Text = v77
			end
			if v56 and (v74 and v70) then
				local v82 = v55.title
				local v83 = v70 .. (v75 and " STOOD DOWN" or " SEALED, AGAIN")
				if v_u_9 then
					local v84 = v_u_9.track
					if type(v84) == "function" then
						local v85 = v_u_9.track
						local v86, v87 = pcall(v85, v83, 1)
						if v86 and type(v87) == "string" then
							v83 = v87
						end
					end
				end
				v82.Text = v83
				v55.sub.Text = v75 and "The order was never carried out." or "The workings were sealed in 1966. They were sealed again."
			else
				local v88 = v55.title
				local v89 = not v56 and "MISSING IN ACTION" or (v69 and "THE SITE IS SEALED" or (not v70 and "STILLWATER SEALED" or v70 .. " SEALED"))
				if v_u_9 then
					local v90 = v_u_9.track
					if type(v90) == "function" then
						local v91 = v_u_9.track
						local v92, v93 = pcall(v91, v89, 1)
						if v92 and type(v93) == "string" then
							v89 = v93
						end
					end
				end
				v88.Text = v89
				local v94 = v55.sub
				local v95
				if v56 then
					v95 = "The " .. v72 .. " was sealed. Nobody else is coming back."
				else
					v95 = "The " .. v72 .. " was sealed. Everything but your secure case is lost."
				end
				v94.Text = v95
			end
		end
	else
		return
	end
end
local function v_u_130() -- name: buildOverlay
	-- upvalues: (copy) v_u_7, (ref) v_u_9, (copy) v_u_6, (copy) v_u_38, (copy) v_u_18, (copy) v_u_96
	local v97 = v_u_7:FindFirstChildOfClass("PlayerGui")
	if v97 then
		local v98 = v97:FindFirstChild("HushEndCine")
		if v98 then
			v98:Destroy()
		end
		local v_u_99 = Instance.new("ScreenGui")
		v_u_99.Name = "HushEndCine"
		v_u_99.ResetOnSpawn = false
		v_u_99.IgnoreGuiInset = true
		v_u_99.ScreenInsets = Enum.ScreenInsets.None
		v_u_99.DisplayOrder = 998
		v_u_99.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		local v100 = v_u_9 and v_u_9.color or {}
		local v101 = Instance.new("Frame")
		v101.Name = "Black"
		v101.BorderSizePixel = 0
		v101.Size = UDim2.fromScale(1, 1)
		v101.BackgroundColor3 = v100.bgDeep or Color3.fromRGB(7, 9, 12)
		v101.BackgroundTransparency = 1
		v101.ZIndex = 1
		v101.Parent = v_u_99
		local v102 = Instance.new("Frame")
		v102.Name = "White"
		v102.BorderSizePixel = 0
		v102.Size = UDim2.fromScale(1, 1)
		v102.BackgroundColor3 = Color3.fromRGB(255, 252, 244)
		v102.BackgroundTransparency = 1
		v102.ZIndex = 2
		v102.Parent = v_u_99
		local v103 = Instance.new("Frame")
		v103.Name = "Card"
		v103.BackgroundTransparency = 1
		v103.BorderSizePixel = 0
		v103.AnchorPoint = Vector2.new(0.5, 0.5)
		v103.Position = UDim2.fromScale(0.5, 0.5)
		v103.Size = UDim2.fromOffset(1920, 1080)
		v103.ZIndex = 3
		v103.Parent = v_u_99
		local v_u_104 = Instance.new("UIScale")
		v_u_104.Parent = v103
		local function v111() -- name: refit
			-- upvalues: (copy) v_u_99, (ref) v_u_9, (copy) v_u_104, (ref) v_u_6
			local v105 = v_u_99.AbsoluteSize.Y
			local v106 = v_u_99.AbsoluteSize.X
			local v107
			if v_u_9 then
				local v108 = v_u_9.devViewport
				if type(v108) == "function" then
					v107 = v_u_9.devViewport()
				else
					v107 = nil
				end
			else
				v107 = nil
			end
			if typeof(v107) == "Vector2" then
				v106 = v107.X
				v105 = v107.Y
			end
			if v105 > 1 and v106 > 1 then
				local v109
				if v_u_9 == nil then
					v109 = false
				else
					local v110 = v_u_9.isPhone
					if type(v110) == "function" then
						v109 = v_u_9.isPhone() == true
					else
						v109 = false
					end
				end
				v_u_104.Scale = v_u_6.cardScale(v106, v105, v109)
			end
		end
		v_u_99:GetPropertyChangedSignal("AbsoluteSize"):Connect(v111)
		local v112 = v_u_9 and v_u_9.font or {}
		local v113 = v112.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
		local v114 = v112.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
		local v115 = v112.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
		local v116 = v100.text or Color3.fromRGB(230, 232, 235)
		local v117 = v100.text2 or Color3.fromRGB(154, 163, 174)
		local v118 = v100.danger or Color3.fromRGB(216, 69, 59)
		local v119 = v_u_38
		local v120 = "Kicker"
		local v121
		if v_u_9 then
			local v122 = v_u_9.track
			if type(v122) == "function" then
				local v123 = v_u_9.track
				local v124, v125 = pcall(v123, "OPERATION HUSH", 2)
				v121 = (not v124 or type(v125) ~= "string") and "OPERATION HUSH" or v125
			else
				v121 = "OPERATION HUSH"
			end
		else
			v121 = "OPERATION HUSH"
		end
		local v126 = v119(v103, v120, v121, v114, 30, v118, -94, 38)
		local v127 = v_u_38(v103, "Title", "", v113, 112, v116, -12, 124)
		local v128 = v_u_38(v103, "Sub", "", v115, 24, v117, 96, 32)
		local v129 = Instance.new("Frame")
		v129.Name = "Rule"
		v129.BorderSizePixel = 0
		v129.AnchorPoint = Vector2.new(0.5, 0.5)
		v129.Position = UDim2.new(0.5, 0, 0.5, 62)
		v129.Size = UDim2.fromOffset(120, 3)
		v129.BackgroundColor3 = v118
		v129.BackgroundTransparency = 1
		v129.Parent = v103
		v_u_18.gui = v_u_99
		v_u_18.white = v102
		v_u_18.black = v101
		v_u_18.card = v103
		v_u_18.cardTexts = {
			["kicker"] = v126,
			["title"] = v127,
			["sub"] = v128,
			["rule"] = v129
		}
		v_u_96()
		v_u_99.Parent = v97
		v111()
		task.defer(v111)
	end
end
local function v_u_140(p131, p132, p133, p134) -- name: paintOverlay
	-- upvalues: (copy) v_u_18
	if v_u_18.white then
		v_u_18.white.BackgroundTransparency = 1 - math.clamp(p131, 0, 1)
	end
	if v_u_18.black then
		v_u_18.black.BackgroundTransparency = 1 - math.clamp(p132, 0, 1)
	end
	local v135 = v_u_18.cardTexts
	if v135.title then
		local v136 = math.clamp(p133, 0, 1)
		v135.kicker.TextTransparency = 1 - v136
		v135.title.TextTransparency = 1 - v136
		v135.sub.TextTransparency = 1 - v136 * 0.95
		v135.rule.BackgroundTransparency = 1 - v136
		v135.title.Position = UDim2.new(0.5, 0, 0.5, p134 + -12)
		local v137 = v135.rule
		local v138 = UDim2.fromOffset
		local v139 = v136 * 200 + 40
		v137.Size = v138(math.floor(v139), 3)
	end
	v_u_18.paint = { p131, p132, p133 }
end
local function v_u_146(p141, p142) -- name: setWorldColour
	-- upvalues: (copy) v_u_18
	local v143 = workspace.CurrentCamera
	if v143 then
		local v144 = v_u_18.cc
		if not v144 or v144.Parent ~= v143 then
			if v144 then
				v144:Destroy()
			end
			v144 = Instance.new("ColorCorrectionEffect")
			v144.Name = "HushEndCineFlash"
			v144.Parent = v143
			v_u_18.cc = v144
		end
		v144.Enabled = p141 > 0.001 and true or p142 > 0.001
		v144.Brightness = math.clamp(p141, 0, 1)
		v144.Contrast = math.clamp(p141, 0, 1) * -0.4
		local v145 = p141 + p142
		v144.Saturation = -math.clamp(v145, 0, 1)
		v144.TintColor = Color3.new(1, 1, 1):Lerp(Color3.new(0, 0, 0), (math.clamp(p142, 0, 1)))
	end
end
local v_u_147 = { "SFX", "Music", "Ambience" }
local function v_u_155(p148) -- name: setCut
	-- upvalues: (copy) v_u_18, (copy) v_u_4, (copy) v_u_147
	local v149 = math.clamp(p148, 0, 1)
	v_u_18.cutLevel = v149
	local v150 = v_u_4:FindFirstChild("HushMaster")
	for _, v151 in v_u_147 do
		local v152
		if v150 then
			v152 = v150:FindFirstChild(v151)
		else
			v152 = v150
		end
		local v153 = v_u_18.eqs[v151]
		if v149 <= 0.001 then
			if not v153 then
				continue
			end
			v153:Destroy()
			v_u_18.eqs[v151] = nil
		else
			if not v152 then
				continue
			end
			if not v153 or v153.Parent ~= v152 then
				v153 = Instance.new("EqualizerSoundEffect")
				v153.Name = "HushEndCineCut"
				v153.Priority = 20
				v153.Parent = v152
				v_u_18.eqs[v151] = v153
			end
			local v154 = v149 * -80
			v153.HighGain = v154
			v153.MidGain = v154
			v153.LowGain = v154
		end
	end
end
local v_u_156 = Color3.fromRGB(58, 64, 73)
local v_u_157 = Color3.fromRGB(84, 90, 100)
local v_u_158 = Color3.fromRGB(28, 34, 44)
local function v_u_167(p159, p160, p161, p162, p163, p164, p165) -- name: jetPart
	local v166
	if p160 == "Wedge" then
		v166 = Instance.new("WedgePart")
	else
		v166 = Instance.new("Part")
	end
	v166.Name = p161
	v166.Anchored = true
	v166.CanCollide = false
	v166.CanQuery = false
	v166.CanTouch = false
	v166.CastShadow = true
	v166.Size = p162
	v166.CFrame = p163
	v166.Color = p164
	v166.Material = p165 or Enum.Material.SmoothPlastic
	v166.TopSurface = Enum.SurfaceType.Smooth
	v166.BottomSurface = Enum.SurfaceType.Smooth
	if p160 == "Cylinder" then
		v166.Shape = Enum.PartType.Cylinder
	end
	v166.Parent = p159
	return v166
end
local function v_u_178(p168, p169, p170, p171, p172, p173, p174) -- name: trail
	local v175 = Instance.new("Attachment")
	v175.Position = p169
	v175.Parent = p168
	local v176 = Instance.new("Attachment")
	v176.Position = p170
	v176.Parent = p168
	local v177 = Instance.new("Trail")
	v177.Attachment0 = v175
	v177.Attachment1 = v176
	v177.Lifetime = p171
	v177.MinLength = 0.2
	v177.FaceCamera = true
	v177.LightEmission = 0.2
	v177.LightInfluence = 1
	v177.Color = ColorSequence.new(p174)
	v177.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, p173), NumberSequenceKeypoint.new(1, 1) })
	v177.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, p172) })
	v177.Parent = p168
end
local function v_u_187(p179, p180) -- name: buildJet
	-- upvalues: (copy) v_u_167, (copy) v_u_156, (copy) v_u_157, (copy) v_u_158, (copy) v_u_178
	local v181 = Instance.new("Model")
	v181.Name = p180
	local v182 = CFrame.new()
	local v183 = v_u_167(v181, "Block", "Fuselage", Vector3.new(2.6, 2.2, 15), v182, v_u_156)
	v_u_167(v181, "Block", "Belly", Vector3.new(2.4, 0.5, 12), v182 * CFrame.new(0, -1.25, 0.5), v_u_157)
	v_u_167(v181, "Wedge", "NoseTop", Vector3.new(2.6, 1.1, 5), v182 * CFrame.new(0, 0.55, -10), v_u_156)
	v_u_167(v181, "Wedge", "NoseBottom", Vector3.new(2.6, 1.1, 5), v182 * CFrame.new(0, -0.55, -10) * CFrame.Angles(0, 0, 3.141592653589793), v_u_157)
	v_u_167(v181, "Wedge", "Canopy", Vector3.new(1.5, 1.1, 4), v182 * CFrame.new(0, 1.65, -4.5), v_u_158, Enum.Material.Glass)
	v_u_167(v181, "Block", "CanopyBack", Vector3.new(1.5, 1.1, 2), v182 * CFrame.new(0, 1.65, -1.5), v_u_158, Enum.Material.Glass)
	v_u_167(v181, "Wedge", "WingR", Vector3.new(0.4, 8, 10), v182 * CFrame.new(5.3, -0.3, 1.5) * CFrame.Angles(0, 0, -1.5707963267948966), v_u_156)
	v_u_167(v181, "Wedge", "WingL", Vector3.new(0.4, 8, 10), v182 * CFrame.new(-5.3, -0.3, 1.5) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_156)
	v_u_167(v181, "Wedge", "TailR", Vector3.new(0.3, 3.2, 3.6), v182 * CFrame.new(2.9000000000000004, -0.2, 6.2) * CFrame.Angles(0, 0, -1.5707963267948966), v_u_156)
	v_u_167(v181, "Wedge", "TailL", Vector3.new(0.3, 3.2, 3.6), v182 * CFrame.new(-2.9000000000000004, -0.2, 6.2) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_156)
	v_u_167(v181, "Wedge", "FinR", Vector3.new(0.3, 3.6, 4.2), v182 * CFrame.new(0.8, 2.9, 5.6) * CFrame.Angles(0, 0, -0.18), v_u_156)
	v_u_167(v181, "Wedge", "FinL", Vector3.new(0.3, 3.6, 4.2), v182 * CFrame.new(-0.8, 2.9, 5.6) * CFrame.Angles(0, 0, 0.18), v_u_156)
	local v184 = v_u_167(v181, "Cylinder", "Nozzle", Vector3.new(0.8, 1.9, 1.9), v182 * CFrame.new(0, 0, 7.9) * CFrame.Angles(0, 1.5707963267948966, 0), Color3.fromRGB(255, 150, 70), Enum.Material.Neon)
	v184.CastShadow = false
	local v185 = Instance.new("PointLight")
	v185.Color = Color3.fromRGB(255, 160, 90)
	v185.Range = 14
	v185.Brightness = 2.5
	v185.Shadows = false
	v185.Parent = v184
	local v186 = Color3.fromRGB(240, 242, 245)
	v_u_178(v183, Vector3.new(9.3, -0.3, 6.2), Vector3.new(9.3, 0.1, 6.2), 1.6, 2.2, 0.45, v186)
	v_u_178(v183, Vector3.new(-9.3, -0.3, 6.2), Vector3.new(-9.3, 0.1, 6.2), 1.6, 2.2, 0.45, v186)
	v_u_178(v183, Vector3.new(0, -0.7, 8.4), Vector3.new(0, 0.7, 8.4), 0.9, 2.5, 0.75, Color3.fromRGB(150, 150, 150))
	v181.PrimaryPart = v183
	v181.Parent = p179
	return v181, v183
end
local function v_u_201() -- name: crossPoint
	-- upvalues: (ref) v_u_8
	local v188 = workspace.CurrentCamera
	if not v188 then
		return nil
	end
	local v189 = v_u_8 and v_u_8.controllers
	if v189 then
		v189 = v_u_8.controllers.Camera
	end
	if not v189 or v189._broken then
		v189 = nil
	end
	local v190 = v188.Focus.Position
	local v191
	if v189 then
		local v192 = v189.focus
		if type(v192) == "function" then
			local v193 = v189.focus
			local v194
			v194, v191 = pcall(v193)
			if v194 then
				if typeof(v191) ~= "Vector3" then
					v191 = v190
				end
			else
				v191 = v190
			end
		else
			v191 = v190
		end
	else
		v191 = v190
	end
	local v195 = v188.CFrame
	local v196 = v195.LookVector
	local v197 = v195.Position.Y - v191.Y
	local v198 = v197 * 0.3
	local v199 = math.clamp(v198, 14, 50)
	if v196.Y > -0.15 or v197 < 10 then
		return v191 + Vector3.new(0, v199, 0)
	end
	local v200 = (v195.Position.Y - (v191.Y + v199)) / -v196.Y
	return v195.Position + v196 * v200
end
local function v_u_224() -- name: buildJets
	-- upvalues: (copy) v_u_18, (copy) v_u_187
	local v202 = workspace.CurrentCamera
	if v202 then
		local v203 = v202.CFrame
		local v204 = v203.RightVector.X
		local v205 = v203.RightVector.Z
		local v206 = Vector3.new(v204, 0, v205)
		local v207 = v203.LookVector.X
		local v208 = v203.LookVector.Z
		local v209 = Vector3.new(v207, 0, v208)
		if v206.Magnitude < 0.1 or v209.Magnitude < 0.1 then
			v206 = Vector3.new(1, 0, 0)
			v209 = Vector3.new(0, 0, -1)
		end
		local v210 = v206.Unit
		local v211 = v209.Unit
		local v212 = (v210 * (math.random() < 0.5 and 1 or -1) * 0.882947592858927 + v211 * 0.4694715627858908).Unit
		v_u_18.dir = v212
		local v213 = v_u_18
		local v214 = -v212.Z
		local v215 = v212.X
		v213.side = Vector3.new(v214, 0, v215)
		local v216 = workspace:FindFirstChild("HushLocal")
		if not v216 then
			v216 = Instance.new("Folder")
			v216.Name = "HushLocal"
			v216.Parent = workspace
		end
		local v217 = Instance.new("Folder")
		v217.Name = "EndCineJets"
		v217.Parent = v216
		v_u_18.folder = v217
		for v218, v219 in {
			{
				["off"] = Vector3.new(0, 0, 0),
				["pass"] = 2.9
			},
			{
				["off"] = nil,
				["pass"] = 2.725,
				["off"] = Vector3.new(0, 2.5, 0) + v_u_18.side * 15
			},
			{
				["off"] = nil,
				["pass"] = 2.05,
				["off"] = Vector3.new(0, 3, 0) - v_u_18.side * 9
			},
			{
				["off"] = nil,
				["pass"] = 1.8749999999999998,
				["off"] = Vector3.new(0, 5, 0) + v_u_18.side * 7
			}
		} do
			local v220, v221 = v_u_187(v217, "Jet" .. v218)
			local v222 = v_u_18.jets
			local v223 = {
				["model"] = v220,
				["root"] = v221,
				["offset"] = v219.off,
				["passAt"] = v219.pass
			}
			table.insert(v222, v223)
		end
	end
end
local function v_u_245(p225) -- name: stepJets
	-- upvalues: (copy) v_u_18, (copy) v_u_201, (copy) v_u_7
	if #v_u_18.jets == 0 then
		return
	else
		local v226 = v_u_201()
		if v226 then
			local v227 = v_u_18.dir
			local v228 = CFrame.lookAt(Vector3.new(0, 0, 0), v227)
			local v229 = 0
			for _, v230 in v_u_18.jets do
				local v231 = (v230.passAt - p225) * 80
				if v231 > 520 then
					if not v230.model.Parent then
						continue
					end
					v230.model:Destroy()
				else
					v229 = v229 + 1
					local v232 = v226 + v230.offset + v227 * v231
					local v233 = v231 / 300
					local v234 = math.clamp(v233, -1, 1) * 3.141592653589793
					local v235 = math.sin(v234) * 0.12
					v230.model:PivotTo(CFrame.new(v232) * v228 * CFrame.Angles(0, 0, v235))
				end
			end
			local v236 = v_u_18.jets[1]
			local v237 = v_u_7.Character
			if v237 then
				v237 = v237:FindFirstChild("Head")
			end
			local v238
			if v237 then
				v238 = v237.Position
			else
				local v239 = workspace.CurrentCamera
				v238 = v239 and v239.CFrame.Position or nil
			end
			if v_u_18.roar and (v236 and (v236.root.Parent and v238)) then
				local v240 = v238 - v236.root.Position
				local v241 = 400 - (v240.Magnitude <= 0.1 and 0 or v227:Dot(v240.Unit) * 80)
				local v242 = 400 / math.max(v241, 1)
				local v_u_243 = math.clamp(v242, 0.78, 1.3)
				local function v244()
					-- upvalues: (ref) v_u_18, (copy) v_u_243
					v_u_18.roar:setPitch(v_u_243)
				end
				pcall(v244)
			end
			if v229 == 0 then
				table.clear(v_u_18.jets)
			end
		end
	end
end
local v_u_246 = {
	"ev_jet_roar",
	"ev_jet_flyby",
	"ev_end_boom",
	"ev_end_ring"
}
local function v_u_259() -- name: preload
	-- upvalues: (ref) v_u_8, (copy) v_u_246, (copy) v_u_5
	local function v247()
		-- upvalues: (ref) v_u_8
		return v_u_8.shared.Sounds
	end
	local v248, v249 = pcall(v247)
	if v248 and type(v249) == "table" then
		local v250 = v249.defs
		if type(v250) == "table" then
			local v_u_251 = {}
			for _, v252 in v_u_246 do
				local v253 = v249.defs[v252]
				if not v253 then
					continue
				end
				for _, v254 in v253.v do
					local v255 = Instance.new("Sound")
					local v256 = v254.id
					v255.SoundId = "rbxassetid://" .. tostring(v256)
					table.insert(v_u_251, v255)
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (copy) v_u_251
				local function v257()
					-- upvalues: (ref) v_u_5, (ref) v_u_251
					v_u_5:PreloadAsync(v_u_251)
				end
				pcall(v257)
				for _, v258 in v_u_251 do
					v258:Destroy()
				end
			end)
			return
		end
	end
end
local function v_u_266() -- name: cleanup
	-- upvalues: (copy) v_u_18, (copy) v_u_155, (copy) v_u_7
	if v_u_18.conn then
		v_u_18.conn:Disconnect()
		v_u_18.conn = nil
	end
	local v_u_260 = v_u_18.roar
	if type(v_u_260) == "table" then
		local v_u_261 = 0.3
		pcall(function()
			-- upvalues: (copy) v_u_260, (copy) v_u_261
			local v262 = v_u_260.stop or v_u_260.Stop
			if type(v262) == "function" then
				v262(v_u_260, v_u_261)
			end
		end)
	end
	local v_u_263 = v_u_18.ring
	if type(v_u_263) == "table" then
		local v_u_264 = 1.2
		pcall(function()
			-- upvalues: (copy) v_u_263, (copy) v_u_264
			local v265 = v_u_263.stop or v_u_263.Stop
			if type(v265) == "function" then
				v265(v_u_263, v_u_264)
			end
		end)
	end
	v_u_18.roar = nil
	v_u_18.ring = nil
	v_u_155(0)
	if v_u_18.cc then
		v_u_18.cc:Destroy()
		v_u_18.cc = nil
	end
	if v_u_18.folder then
		v_u_18.folder:Destroy()
		v_u_18.folder = nil
	end
	table.clear(v_u_18.jets)
	if v_u_18.gui then
		v_u_18.gui:Destroy()
	end
	v_u_18.gui = nil
	v_u_18.white = nil
	v_u_18.black = nil
	v_u_18.card = nil
	v_u_18.cardTexts = {}
	v_u_18.active = false
	v_u_18.fade = nil
	v_u_18.leaveAt = nil
	v_u_18.coverAt = nil
	v_u_7:SetAttribute("EndCine", "off")
end
function v_u_6.stop(p267, p268) -- name: stop
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	if v_u_18.active and not v_u_18.fade then
		local v269 = v_u_18.paint or { 0, 0, 0 }
		if p268 then
			v269 = { 0, 0, 0 }
			if v_u_18.gui then
				v_u_18.gui.Enabled = false
			end
		end
		v_u_18.fade = {
			["t0"] = os.clock(),
			["dur"] = math.max(p267 or 0.4, 0.05),
			["white"] = v269[1],
			["black"] = v269[2],
			["card"] = v269[3],
			["cut"] = v_u_18.cutLevel
		}
		if v_u_18.folder then
			v_u_18.folder:Destroy()
			v_u_18.folder = nil
		end
		table.clear(v_u_18.jets)
		local v_u_270 = v_u_18.roar
		if type(v_u_270) == "table" then
			local v_u_271 = 0.3
			pcall(function()
				-- upvalues: (copy) v_u_270, (copy) v_u_271
				local v272 = v_u_270.stop or v_u_270.Stop
				if type(v272) == "function" then
					v272(v_u_270, v_u_271)
				end
			end)
		end
		v_u_18.roar = nil
		local v_u_273 = v_u_18.ring
		local v_u_274 = p267 or 0.4
		if type(v_u_273) == "table" then
			pcall(function()
				-- upvalues: (copy) v_u_273, (copy) v_u_274
				local v275 = v_u_273.stop or v_u_273.Stop
				if type(v275) == "function" then
					v275(v_u_273, v_u_274)
				end
			end)
		end
		v_u_18.ring = nil
		v_u_7:SetAttribute("EndCine", "leaving")
	end
end
local function v_u_323(_) -- name: step
	-- upvalues: (copy) v_u_18, (copy) v_u_140, (copy) v_u_146, (copy) v_u_155, (copy) v_u_266, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (ref) v_u_8, (copy) v_u_40, (copy) v_u_42, (copy) v_u_224, (copy) v_u_25, (copy) v_u_245, (copy) v_u_96
	if v_u_18.active then
		local v276 = v_u_18.fade
		if v276 then
			local v277 = (os.clock() - v276.t0) / v276.dur
			local v278 = math.clamp(v277, 0, 1)
			v_u_140(v276.white * (1 - v278), v276.black * (1 - v278), v276.card * (1 - v278), 0)
			v_u_146(0, 0)
			v_u_155(v276.cut * (1 - v278))
			if v278 >= 1 then
				v_u_266()
			end
			return
		else
			local v279 = v_u_18.endsAt - v_u_1.now()
			if v_u_18.preview then
				if v279 < -v_u_18.hold then
					v_u_18.leaveAt = v_u_18.leaveAt or os.clock()
				end
			else
				local v280 = v_u_7:GetAttribute("RaidStatus")
				if v280 == "Extracted" or v280 == "Left" then
					v_u_6.stop(0.35)
					return
				end
				local v281 = v_u_8 and v_u_8.session
				if v281 then
					v281 = v_u_8.session.place(v_u_7)
				end
				if v281 ~= "Raid" then
					if not v_u_18.fired.white then
						v_u_6.stop(0.3)
						return
					end
					v_u_18.leaveAt = v_u_18.leaveAt or os.clock()
					local v_u_282 = v_u_8 and v_u_8.controllers
					if v_u_282 then
						v_u_282 = v_u_8.controllers.Loading
					end
					if not v_u_282 or v_u_282._broken then
						v_u_282 = nil
					end
					local v284, v285 = pcall(function()
						-- upvalues: (copy) v_u_282
						local v283
						if v_u_282 == nil then
							v283 = false
						else
							v283 = v_u_282.isShowing()
						end
						return v283
					end)
					if v284 and v285 then
						v_u_18.coverAt = v_u_18.coverAt or os.clock()
					end
					if v_u_18.coverAt and os.clock() - v_u_18.coverAt >= 0.5 then
						v_u_6.stop(1.2, true)
						return
					end
				end
			end
			if v_u_18.leaveAt and os.clock() - v_u_18.leaveAt >= 1.6 then
				v_u_6.stop(1.2, not v_u_18.preview)
				return
			elseif v279 < -8 then
				v_u_6.stop(0.5)
			else
				if not v_u_18.fired.jets and v279 > 1.4499999999999997 then
					if not v_u_18.fired.jets then
						v_u_18.fired.jets = true
						local v286 = v_u_18.log
						table.insert(v286, ("%s@%.2f"):format("jets", v279))
						v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
					end
					if v_u_40() or v_u_42() then
						v_u_18.fired.flyby = true
					else
						v_u_7:SetAttribute("EndCine", "jets")
						v_u_224()
						local v287 = v_u_18.jets[1]
						if v287 then
							v_u_18.roar = v_u_25("play3D", "ev_jet_roar", v287.root, {
								["occlude"] = false,
								["fadeIn"] = 0.8
							})
						end
					end
				end
				v_u_245(v279)
				if v_u_18.fired.jets and (not v_u_18.fired.flyby and v279 <= 3.5999999999999996) then
					if not v_u_18.fired.flyby then
						v_u_18.fired.flyby = true
						local v288 = v_u_18.log
						table.insert(v288, ("%s@%.2f"):format("flyby", v279))
						v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
					end
					v_u_25("play", "ev_jet_flyby")
					local v289 = v_u_8 and v_u_8.controllers
					if v289 then
						v289 = v_u_8.controllers.Camera
					end
					if not v289 or v289._broken then
						v289 = nil
					end
					if v289 then
						local v290 = v289.shake
						if type(v290) == "function" then
							local v291 = v289.shake
							pcall(v291, 0.25, 1.4)
						end
					end
				end
				if not v_u_18.fired.flash and v279 <= 1.55 then
					if not v_u_18.fired.flash then
						v_u_18.fired.flash = true
						local v292 = v_u_18.log
						table.insert(v292, ("%s@%.2f"):format("flash", v279))
						v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
					end
					v_u_7:SetAttribute("EndCine", "flash")
					if v_u_42() then
						local v293 = v_u_8 and v_u_8.controllers
						if v293 then
							v293 = v_u_8.controllers.Camera
						end
						if not v293 or v293._broken then
							v293 = nil
						end
						if v293 then
							local v294 = v293.shake
							if type(v294) == "function" then
								local v295 = v293.shake
								pcall(v295, 0.2, 1.2)
							end
						end
					else
						v_u_25("play", "ev_end_boom")
						local v296 = v_u_8 and v_u_8.controllers
						if v296 then
							v296 = v_u_8.controllers.Camera
						end
						if not v296 or v296._broken then
							v296 = nil
						end
						if v296 then
							local v297 = v296.shake
							if type(v297) == "function" then
								local v298 = v296.shake
								pcall(v298, 0.7, 2.2)
							end
						end
					end
				end
				if not v_u_18.fired.cut and v279 <= 1.35 then
					if not v_u_18.fired.cut then
						v_u_18.fired.cut = true
						local v299 = v_u_18.log
						table.insert(v299, ("%s@%.2f"):format("cut", v279))
						v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
					end
					local v_u_300 = v_u_18.roar
					if type(v_u_300) == "table" then
						local v_u_301 = 0.15
						pcall(function()
							-- upvalues: (copy) v_u_300, (copy) v_u_301
							local v302 = v_u_300.stop or v_u_300.Stop
							if type(v302) == "function" then
								v302(v_u_300, v_u_301)
							end
						end)
					end
					v_u_18.roar = nil
					if not v_u_42() then
						v_u_18.ring = v_u_25("play", "ev_end_ring", {
							["group"] = "UI",
							["fadeIn"] = 0.25
						})
					end
				end
				if v_u_18.fired.cut then
					local v303 = v_u_155
					local v304 = (1.35 - v279) / 0.25
					v303((math.clamp(v304, 0, 1)))
				end
				local v305 = 0
				local v306 = 0
				local v307 = 0
				local v308
				if v279 <= 1.55 then
					local v309 = (1.55 - v279) / 0.3
					local v310 = math.clamp(v309, 0, 1)
					local v311 = v310 * v310 * (3 - v310 * 2)
					v308 = v_u_42() and 0 or v311
					if v311 >= 1 then
						if v_u_18.fired.white then
							v305 = 1
						else
							if not v_u_18.fired.white then
								v_u_18.fired.white = true
								local v312 = v_u_18.log
								table.insert(v312, ("%s@%.2f"):format("white", v279))
								v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
							end
							v_u_7:SetAttribute("EndCine", "white")
							v305 = 1
						end
					elseif v_u_42() then
						v305 = v311
					end
					if v279 <= 1.05 and not v_u_42() then
						local v313 = (1.05 - v279) / 2
						local v314 = math.clamp(v313, 0, 1)
						v308 = 1 - v314 * v314 * (3 - v314 * 2)
					end
					local v315
					if v279 <= 1.05 then
						local v316 = (1.05 - v279) / 2
						local v317 = math.clamp(v316, 0, 1)
						v315 = v317 * v317 * (3 - v317 * 2)
					else
						v315 = 0
					end
					if v_u_42() then
						v_u_146(0, v311)
					else
						local v318 = v_u_146
						local v319 = v311 * (1 - v315)
						v318(math.max(v319, 0), v315)
					end
				else
					v308 = 0
				end
				if v279 <= 0.15 then
					if not v_u_18.fired.card then
						if not v_u_18.fired.card then
							v_u_18.fired.card = true
							local v320 = v_u_18.log
							table.insert(v320, ("%s@%.2f"):format("card", v279))
							v_u_7:SetAttribute("EndCineLog", table.concat(v_u_18.log, " "))
						end
						v_u_7:SetAttribute("EndCine", "card")
						if not v_u_18.preview and (v_u_18.mode ~= "dead" and v_u_7:GetAttribute("RaidStatus") == "Dead") then
							v_u_18.mode = "dead"
							v_u_96()
						end
					end
					local v321 = (0.15 - v279) / 0.7
					local v322 = math.clamp(v321, 0, 1)
					v306 = v322 * v322 * (3 - v322 * 2)
					v307 = (1 - v306) * 10
				end
				v_u_140(v308, v305, v306, v307)
			end
		end
	else
		return
	end
end
function v_u_6.onMessage(p324) -- name: onMessage
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_1, (copy) v_u_7
	if type(p324) == "table" then
		if p324.cancel then
			if v_u_18.active and (not v_u_18.preview and (p324.raidId == nil or p324.raidId == v_u_18.raidId)) then
				v_u_6.stop(0.4)
			end
			return
		else
			local v325 = p324.endsAt
			local v326 = tonumber(v325)
			if v326 and v_u_1.now() <= v326 + 1 then
				if v_u_18.active and (not v_u_18.fade and v_u_18.raidId == p324.raidId) then
					local v327 = v_u_18.endsAt - v326
					if math.abs(v327) < 0.05 then
						return
					end
				end
				local v328 = v_u_7:GetAttribute("RaidStatus")
				if v328 ~= "Extracted" and v328 ~= "Left" then
					local v329 = v_u_6.start
					local v330 = p324.hold
					v329(v326, tonumber(v330) or 1.8, p324.raidId, v328 == "Dead" and "dead" or "mia", false)
				end
			else
				return
			end
		end
	else
		return
	end
end
function v_u_6.start(p331, p332, p333, p334, p335) -- name: start
	-- upvalues: (copy) v_u_18, (copy) v_u_266, (copy) v_u_7, (copy) v_u_130, (copy) v_u_259, (copy) v_u_3, (copy) v_u_323
	if v_u_18.active then
		v_u_266()
	end
	v_u_18.active = true
	v_u_18.endsAt = p331
	v_u_18.hold = p332
	v_u_18.raidId = p333
	v_u_18.mode = p334
	v_u_18.preview = p335
	v_u_18.fired = {}
	v_u_18.ug = nil
	v_u_18.cur = nil
	v_u_18.log = {}
	v_u_18.paint = { 0, 0, 0 }
	v_u_7:SetAttribute("EndCineLog", "")
	v_u_130()
	v_u_259()
	v_u_18.conn = v_u_3.Heartbeat:Connect(v_u_323)
	v_u_7:SetAttribute("EndCine", "armed")
end
function v_u_6.preview(p336, p337) -- name: preview
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	v_u_6.start(v_u_1.now() + math.clamp(p336 or 5.5, 0.5, 30), 1.8, "preview", p337 == "dead" and "dead" or "mia", true)
end
function v_u_6.status() -- name: status
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_1
	local v338 = v_u_18.active
	local v339 = tostring(v338)
	local v340 = v_u_7
	local v341 = tostring(v340:GetAttribute("EndCine"))
	local v342 = not v_u_18.active and 0 or v_u_18.endsAt - v_u_1.now()
	local v343 = v_u_18.mode
	return ("active=%s phase=%s rem=%.2f mode=%s jets=%d cut=%.2f log=%s"):format(v339, v341, v342, tostring(v343), #v_u_18.jets, v_u_18.cutLevel, table.concat(v_u_18.log, " "))
end
function v_u_6.init(p_u_344) -- name: init
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_7
	v_u_8 = p_u_344
	local v345, v346 = pcall(function()
		-- upvalues: (copy) p_u_344
		return p_u_344.shared.Theme
	end)
	if not v345 then
		v346 = nil
	end
	v_u_9 = v346
	v_u_7:SetAttribute("EndCine", "off")
end
return v_u_6