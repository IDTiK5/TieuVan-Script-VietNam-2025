-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / RaidClient

local v_u_1 = game:GetService("Players")
local v2 = {
	["name"] = "RaidClient",
	["order"] = 50
}
local v_u_3 = nil
local v_u_4 = v_u_1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = 0
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = 0
local v_u_22 = false
local v_u_23 = false
local v_u_24 = 0
local v_u_25 = false
local v_u_26 = nil
local v_u_27 = 1
local v_u_28 = ""
local v_u_29 = {}
local v30 = script.Parent and script.Parent.Parent
if v30 then
	v30 = script.Parent.Parent:FindFirstChild("Lib")
end
if v30 then
	v30 = v30:FindFirstChild("ServerClock") or v30:WaitForChild("ServerClock", 5)
end
local v_u_31 = not v30 and {
	["now"] = function() -- name: now
		return workspace:GetServerTimeNow()
	end
} or require(v30)
local v_u_32 = Color3.fromRGB(232, 163, 61)
local function v_u_39(p33, ...) -- name: audio
	-- upvalues: (ref) v_u_3
	local v34 = v_u_3
	if v34 then
		v34 = v_u_3.controllers.Audio
	end
	if not v34 or v34._broken then
		v34 = nil
	end
	if v34 then
		local v35 = v34[p33]
		if type(v35) == "function" then
			local v36 = v34[p33]
			local v37, v38 = pcall(v36, ...)
			if v37 then
				return v38
			end
		end
	end
	return nil
end
local function v_u_42() -- name: localFolder
	local v40 = workspace:FindFirstChild("HushLocal")
	if not v40 then
		v40 = Instance.new("Folder")
		v40.Name = "HushLocal"
		v40.Parent = workspace
	end
	local v41 = v40:FindFirstChild("RaidFx")
	if not v41 then
		v41 = Instance.new("Folder")
		v41.Name = "RaidFx"
		v41.Parent = v40
	end
	return v41
end
local function v_u_46(p43, p44, p45) -- name: numSeq
	if p45 then
		return NumberSequence.new({ NumberSequenceKeypoint.new(0, p43), NumberSequenceKeypoint.new(0.5, p44), NumberSequenceKeypoint.new(1, p45) })
	else
		return NumberSequence.new(p43, p44)
	end
end
local function v_u_48(p47) -- name: stateColor
	-- upvalues: (ref) v_u_5, (ref) v_u_32
	if p47 == "boarding" or p47 == "running" then
		return v_u_5 and v_u_5.color.success or Color3.fromRGB(95, 191, 122)
	elseif p47 == "inbound" then
		return v_u_5 and v_u_5.color.info or Color3.fromRGB(111, 168, 220)
	else
		return v_u_32
	end
end
local function v_u_102(p49, p50) -- name: buildMarker
	-- upvalues: (copy) v_u_13, (ref) v_u_12, (ref) v_u_6, (copy) v_u_48, (copy) v_u_46, (ref) v_u_5
	local v51 = p49:GetAttribute("ExtractId") or p49.Name
	local v52 = v_u_13[v51]
	if v52 then
		v_u_13[v51] = nil
		if v52.model then
			v52.model:Destroy()
		end
	end
	if p49:GetAttribute("Open") == true then
		local v53 = v_u_12
		if v53 then
			local v54 = p49.CFrame
			local v55 = p49.Size
			local v56 = v54 * CFrame.new(0, -v55.Y * 0.5 + 0.12, 0)
			local v57 = Instance.new("Model")
			v57.Name = "Extract_" .. v51
			local v58 = v_u_6.get((tostring(v51)))
			local v59 = CFrame.new
			local v60
			if v58 then
				local v61 = v58.promptAt
				v60 = typeof(v61) ~= "Vector3" and Vector3.new(0, 0, 0) or v58.promptAt
			else
				v60 = Vector3.new(0, 0, 0)
			end
			local v62 = v56 * v59(v60)
			local v63 = Instance.new("Part")
			v63.Name = "Base"
			v63.Anchored = true
			v63.CanCollide = false
			v63.CanQuery = false
			v63.CanTouch = false
			v63.CastShadow = false
			v63.Transparency = 1
			v63.Size = Vector3.new(0.2, 0.2, 0.2)
			v63.CFrame = v62
			v63.Parent = v57
			local v64 = v_u_48((p49:GetAttribute("State")))
			local v65 = Instance.new("Attachment")
			v65.Parent = v63
			local v66 = Instance.new("Attachment")
			v66.Position = Vector3.new(0, p50 and 46 or 14, 0)
			v66.Parent = v63
			local v67 = Instance.new("Beam")
			v67.Attachment0 = v65
			v67.Attachment1 = v66
			v67.Width0 = 1.6
			v67.Width1 = 0.6
			v67.FaceCamera = true
			v67.LightEmission = 1
			v67.LightInfluence = 0
			v67.Segments = 1
			v67.Color = ColorSequence.new(v64)
			v67.Transparency = v_u_46(0.45, 0.8, 1)
			v67.Parent = v63
			local v68 = v67:Clone()
			v68.Width0 = 7
			v68.Width1 = 3
			v68.Transparency = v_u_46(0.82, 0.94, 1)
			v68.Parent = v63
			local v69 = v55.X * 0.5
			local v70 = v55.Z * 0.5
			local v71 = v55.X
			local v72 = v55.Z
			local v73 = math.min(v71, v72) * 0.18
			local v74 = math.clamp(v73, 2, 5)
			local v75 = {}
			for _, v76 in { -1, 1 } do
				for _, v77 in { -1, 1 } do
					local v78 = v76 * v69
					local v79 = v77 * v70
					local v80 = Vector3.new(v74, 0.08, 0.3)
					local v81 = v56 * CFrame.new(v78 - v76 * v74 * 0.5, 0, v79 - v77 * 0.15)
					local v82 = Enum.Material.Neon
					local v83 = Instance.new("Part")
					v83.Name = "Bracket"
					v83.Anchored = true
					v83.CanCollide = false
					v83.CanQuery = false
					v83.CanTouch = false
					v83.Size = v80
					v83.CFrame = v81
					v83.Color = v64
					v83.Material = v82 or Enum.Material.Metal
					v83.TopSurface = Enum.SurfaceType.Smooth
					v83.BottomSurface = Enum.SurfaceType.Smooth
					v83.Parent = v57
					local v84 = Vector3.new(0.3, 0.08, v74)
					local v85 = v56 * CFrame.new(v78 - v76 * 0.15, 0, v79 - v77 * v74 * 0.5)
					local v86 = Enum.Material.Neon
					local v87 = Instance.new("Part")
					v87.Name = "Bracket"
					v87.Anchored = true
					v87.CanCollide = false
					v87.CanQuery = false
					v87.CanTouch = false
					v87.Size = v84
					v87.CFrame = v85
					v87.Color = v64
					v87.Material = v86 or Enum.Material.Metal
					v87.TopSurface = Enum.SurfaceType.Smooth
					v87.BottomSurface = Enum.SurfaceType.Smooth
					v87.Parent = v57
					v83.CastShadow = false
					v87.CastShadow = false
					table.insert(v75, v83)
					table.insert(v75, v87)
				end
			end
			local v88 = Instance.new("PointLight")
			v88.Color = v64
			v88.Range = 16
			v88.Brightness = 0.9
			v88.Shadows = false
			v88.Parent = v63
			local v89 = Instance.new("BillboardGui")
			v89.Name = "Label"
			v89.Adornee = v63
			v89.AlwaysOnTop = true
			v89.LightInfluence = 0
			v89.Size = UDim2.fromOffset(260, 64)
			v89.StudsOffsetWorldSpace = Vector3.new(0, 9, 0)
			v89.MaxDistance = 2000
			v89.ResetOnSpawn = false
			v89.Parent = v63
			local v90 = v_u_5 and v_u_5.font.heading or Font.fromName("Oswald", Enum.FontWeight.Medium)
			local v91 = v_u_5 and v_u_5.font.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
			local v92 = v_u_5 and v_u_5.font.mono or Font.fromName("RobotoMono", Enum.FontWeight.Regular)
			local v93 = v_u_5 and v_u_5.color.text or Color3.fromRGB(230, 232, 235)
			local v94 = v_u_5 and v_u_5.color.text2 or Color3.fromRGB(154, 163, 174)
			local v95 = string.upper
			local v96 = p49:GetAttribute("Name") or v51
			local v97 = v95((tostring(v96)))
			if v_u_5 and v_u_5.track then
				v97 = v_u_5.track(v97, 1)
			end
			local v98 = Instance.new("TextLabel")
			v98.Name = "Title"
			v98.BackgroundTransparency = 1
			v98.Size = UDim2.new(1, 0, 0, 22)
			v98.FontFace = v90
			v98.TextSize = 18
			v98.TextColor3 = v93
			v98.TextStrokeTransparency = 0.6
			v98.TextStrokeColor3 = Color3.new(0, 0, 0)
			v98.Text = v97
			v98.TextTruncate = Enum.TextTruncate.AtEnd
			v98.Parent = v89
			local v99 = Instance.new("TextLabel")
			v99.Name = "Condition"
			v99.BackgroundTransparency = 1
			v99.Position = UDim2.fromOffset(0, 22)
			v99.Size = UDim2.new(1, 0, 0, 18)
			v99.FontFace = v91
			v99.TextSize = 13
			v99.TextColor3 = v64
			v99.TextStrokeTransparency = 0.7
			v99.TextStrokeColor3 = Color3.new(0, 0, 0)
			local v100 = p49:GetAttribute("Condition") or ""
			v99.Text = tostring(v100)
			v99.TextTruncate = Enum.TextTruncate.AtEnd
			v99.Parent = v89
			local v101 = Instance.new("TextLabel")
			v101.Name = "Distance"
			v101.BackgroundTransparency = 1
			v101.Position = UDim2.fromOffset(0, 40)
			v101.Size = UDim2.new(1, 0, 0, 16)
			v101.FontFace = v92
			v101.TextSize = 12
			v101.TextColor3 = v94
			v101.TextStrokeTransparency = 0.75
			v101.TextStrokeColor3 = Color3.new(0, 0, 0)
			v101.Text = ""
			v101.Parent = v89
			v57.Parent = v53
			v_u_13[v51] = {
				["id"] = nil,
				["src"] = nil,
				["model"] = nil,
				["base"] = nil,
				["beams"] = nil,
				["brackets"] = nil,
				["light"] = nil,
				["bb"] = nil,
				["title"] = nil,
				["cond"] = nil,
				["dist"] = nil,
				["alpha"] = -1,
				["state"] = nil,
				["personal"] = nil,
				["id"] = v51,
				["src"] = p49,
				["model"] = v57,
				["base"] = v63,
				["beams"] = { v67, v68 },
				["brackets"] = v75,
				["light"] = v88,
				["bb"] = v89,
				["title"] = v98,
				["cond"] = v99,
				["dist"] = v101,
				["state"] = p49:GetAttribute("State"),
				["personal"] = p50 == true
			}
		end
	else
		return
	end
end
local function v_u_110(p103) -- name: conditionText
	-- upvalues: (copy) v_u_31, (ref) v_u_6, (copy) v_u_48, (ref) v_u_5, (ref) v_u_32
	local v104 = p103:GetAttribute("State")
	local v105 = p103:GetAttribute("StateEndsAt")
	local v106 = type(v105) ~= "number" and 0 or v105 - v_u_31.now()
	if v104 == "inbound" then
		local v107 = p103:GetAttribute("Kind")
		return ((v107 == nil or v107 == "Heli") and "Helicopter inbound  " or "On its way  ") .. v_u_6.clock(v106), v_u_48(v104)
	end
	if v104 == "boarding" then
		return "Boarding: leaves in " .. v_u_6.clock(v106), v_u_48(v104)
	end
	if v104 == "running" then
		local v108 = p103:GetAttribute("Seats")
		return ("Engine running: %s  /  %s seats"):format(v_u_6.clock(v106), (tostring(v108 or "?"))), v_u_48(v104)
	end
	if v104 == "departed" then
		return "Departed", v_u_5 and v_u_5.color.muted or Color3.fromRGB(95, 104, 115)
	end
	local v109 = p103:GetAttribute("Condition") or ""
	return tostring(v109), v_u_32
end
local function v_u_118(p111, p112, p113) -- name: stateCue
	-- upvalues: (copy) v_u_39
	local v114 = p111.CFrame.Position
	local v115 = p111.Size.Y * 0.5
	local v116 = v114 - Vector3.new(0, v115, 0)
	local v117 = p111:GetAttribute("ExtractId")
	if p113 == "inbound" or p113 == "boarding" then
		v_u_39("play", "ev_radio_burst")
	elseif (v117 == "pickup" or p111:GetAttribute("Kind") == "Vehicle") and (p113 == "running" and p112 ~= "running") then
		v_u_39("play3D", "ev_engine", v116)
	end
end
local function v_u_145() -- name: updateMarkers
	-- upvalues: (copy) v_u_4, (ref) v_u_26, (ref) v_u_21, (copy) v_u_13, (copy) v_u_118, (ref) v_u_6, (copy) v_u_46, (copy) v_u_110, (copy) v_u_102
	local v119 = v_u_4.Character
	if v119 then
		v119 = v119:FindFirstChild("HumanoidRootPart")
	end
	local v120
	if v119 then
		v120 = v119.Position
	else
		local v121 = v_u_26 and (v_u_26.Parent and v_u_26:FindFirstChild("HumanoidRootPart"))
		if v121 then
			v120 = v121.Position
		else
			local v122 = workspace.CurrentCamera
			v120 = v122 and v122.Focus.Position or nil
		end
	end
	local v123 = os.clock() < v_u_21
	local v124 = {}
	local v125 = {}
	for v126, v127 in v_u_13 do
		local v128 = v127.src
		if v128.Parent and v128:GetAttribute("Open") == true then
			local v129 = v128:GetAttribute("State")
			if v129 == v127.state then
				local v130 = not v120 and 1000000000 or v_u_6.distanceToZone(v128.CFrame, v128.Size, v120)
				local v131
				if v127.personal then
					local v132 = (v130 - 55) / 85
					v131 = 1 - math.clamp(v132, 0, 1)
				else
					local v133 = (v130 - 22) / 8
					v131 = 1 - math.clamp(v133, 0, 1)
				end
				local v134 = math.max(v131, v123 and 0.55 or 0) * 10 + 0.5
				local v135 = math.floor(v134) / 10
				if v135 ~= v127.alpha then
					v127.alpha = v135
					local v136 = 1 - v135
					v127.beams[1].Transparency = v_u_46(v136 * 0.55 + 0.45, v136 * 0.2 + 0.8, 1)
					v127.beams[2].Transparency = v_u_46(v136 * 0.18 + 0.82, v136 * 0.06 + 0.94, 1)
					for _, v137 in v127.brackets do
						v137.Transparency = v136 * 0.65 + 0.35
					end
					v127.light.Enabled = v135 > 0.2
					v127.bb.Enabled = v135 > 0.05
				end
				if not v127.bb.Enabled then
					continue
				end
				local v138, v139 = v_u_110(v128)
				v127.cond.Text = v138
				v127.cond.TextColor3 = v139
				v127.dist.Text = not v120 and "" or v_u_6.distanceText(v128.CFrame, v128.Size, v120)
				local v140 = 1 - v135
				v127.title.TextTransparency = v140 * 0.9
				v127.cond.TextTransparency = v140 * 0.9
				v127.dist.TextTransparency = v140 * 0.9
			else
				local v141 = { v128, v127.personal }
				table.insert(v124, v141)
				v_u_118(v128, v127.state, v129)
			end
		else
			table.insert(v125, v126)
		end
	end
	for _, v142 in v125 do
		local v143 = v_u_13[v142]
		if not v143 then
			continue
		end
		v_u_13[v142] = nil
		if not v143.model then
			continue
		end
		v143.model:Destroy()
	end
	for _, v144 in v124 do
		v_u_102(v144[1], v144[2])
	end
end
local function v_u_160(p146, p_u_147) -- name: hookExtractFolder
	-- upvalues: (copy) v_u_102, (copy) v_u_9, (copy) v_u_13
	local function v151(p_u_148) -- name: hook
		-- upvalues: (ref) v_u_102, (copy) p_u_147, (ref) v_u_9
		if p_u_148:IsA("BasePart") then
			v_u_102(p_u_148, p_u_147)
			local v149 = p_u_148:GetAttributeChangedSignal("Open"):Connect(function()
				-- upvalues: (ref) v_u_102, (copy) p_u_148, (ref) p_u_147
				v_u_102(p_u_148, p_u_147)
			end)
			local v150 = v_u_9
			table.insert(v150, v149)
		end
	end
	for _, v152 in p146:GetChildren() do
		v151(v152)
	end
	local v153 = p146.ChildAdded:Connect(v151)
	local v154 = v_u_9
	table.insert(v154, v153)
	local v158 = p146.ChildRemoved:Connect(function(p155)
		-- upvalues: (ref) v_u_13
		local v156 = p155:GetAttribute("ExtractId") or p155.Name
		local v157 = v_u_13[v156]
		if v157 then
			v_u_13[v156] = nil
			if v157.model then
				v157.model:Destroy()
			end
		end
	end)
	local v159 = v_u_9
	table.insert(v159, v158)
end
local function v_u_164(p161) -- name: watchExtracts
	-- upvalues: (ref) v_u_8, (copy) v_u_160
	local v162 = v_u_8
	local v163 = p161:WaitForChild("Extracts", 10)
	if v163 and v162 == v_u_8 then
		v_u_160(v163)
	end
end
local function v_u_178() -- name: watchPersonal
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (copy) v_u_160, (copy) v_u_9, (copy) v_u_13
	local v165 = v_u_8
	local v166 = v_u_4:FindFirstChildOfClass("PlayerGui") or v_u_4:WaitForChild("PlayerGui", 10)
	if v166 and v165 == v_u_8 then
		local function v168(p167) -- name: hookFolder
			-- upvalues: (ref) v_u_160
			if p167.Name == "HushPersonalExtracts" and p167:IsA("Folder") then
				v_u_160(p167, true)
			end
		end
		for _, v169 in v166:GetChildren() do
			if v169.Name ~= "HushPersonalExtracts" or not v169:IsA("Folder") then
				continue
			end
			v_u_160(v169, true)
		end
		local v170 = v166.ChildAdded:Connect(v168)
		local v171 = v_u_9
		table.insert(v171, v170)
		local v176 = v166.ChildRemoved:Connect(function(p172)
			-- upvalues: (ref) v_u_13
			if p172.Name == "HushPersonalExtracts" then
				for _, v173 in p172:GetChildren() do
					local v174 = v173:GetAttribute("ExtractId") or v173.Name
					local v175 = v_u_13[v174]
					if not v175 then
						continue
					end
					v_u_13[v174] = nil
					if not v175.model then
						continue
					end
					v175.model:Destroy()
				end
			end
		end)
		local v177 = v_u_9
		table.insert(v177, v176)
	end
end
local v_u_179 = nil
local v_u_180 = 0
local v_u_181 = false
local function v_u_197() -- name: touchBand
	-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_7
	if v_u_5 then
		local v182 = v_u_5.isTouch
		if type(v182) == "function" and v_u_5.isTouch() then
			local v183
			if v_u_5 then
				local v184 = v_u_5.isPhone
				if type(v184) == "function" then
					local v185 = v_u_5.isPhone
					local v186
					v183, v186 = pcall(v185)
					if v183 then
						v183 = v186 == true
					end
				else
					v183 = false
				end
			else
				v183 = false
			end
			if v183 then
				local v187
				if v_u_3 and v_u_3.controllers then
					v187 = v_u_3.controllers.Input
				else
					v187 = nil
				end
				if v187 then
					local v188 = v187.touchRects
					if type(v188) == "function" then
						local v189 = v187.touchRects
						local v190, v191 = pcall(v189)
						if not v190 or type(v191) ~= "table" then
							return nil, nil
						end
						local v192 = v191.moveStick
						local v193 = v191.rightCluster
						if typeof(v192) ~= "Rect" or typeof(v193) ~= "Rect" then
							return nil, nil
						end
						local v194 = v_u_5.uiScale
						local v195 = math.max(0.1, v194())
						local v196 = v_u_7.safeInsets()
						return v192.Max.X / v195 - v196.l + 8, v193.Min.X / v195 - v196.l - 8
					end
				end
				return nil, nil
			end
		end
	end
	return nil, nil
end
local function v_u_215() -- name: placeCue
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_5, (copy) v_u_197
	if v_u_17 and (v_u_18 and v_u_5) then
		local v198, v199 = v_u_197()
		local v200 = v_u_5.safeRefSize().X / 2
		local v201 = v_u_17.baseW
		local v202
		if v198 and v199 then
			local v203 = v199 - v198
			if v201 <= v203 then
				local v204 = v198 + v201 / 2
				local v205 = v199 - v201 / 2
				local v206 = math.clamp(v200, v204, v205) - v200 + 0.5
				v202 = math.floor(v206)
			else
				v201 = math.max(v203, 200)
				local v207 = (v198 + v199) / 2 - v200 + 0.5
				v202 = math.floor(v207)
			end
		else
			v202 = 0
		end
		v_u_17.holder.Size = UDim2.fromOffset(v201, v_u_17.h)
		v_u_17.holder.Position = UDim2.new(0.5, v202, 0.5, v_u_17.y)
		local v208 = v_u_18.baseW
		local v209
		if v198 and v199 then
			local v210 = v199 - v198
			if v208 <= v210 then
				local v211 = v198 + v208 / 2
				local v212 = v199 - v208 / 2
				local v213 = math.clamp(v200, v211, v212) - v200 + 0.5
				v209 = math.floor(v213)
			else
				v208 = math.max(v210, 220)
				local v214 = (v198 + v199) / 2 - v200 + 0.5
				v209 = math.floor(v214)
			end
		else
			v209 = 0
		end
		v_u_18.frame.Size = UDim2.fromOffset(v208, 64)
		v_u_18.frame.Position = UDim2.new(0.5, v209, 0.5, v_u_18.y)
	end
end
local function v_u_272() -- name: buildGui
	-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) v_u_215
	if not (v_u_7 and v_u_5) then
		return
	end
	local v216 = v_u_7.screen
	local v217 = (v_u_5.layer and v_u_5.layer.hud or 10) + 1
	local v218, v219, v220 = pcall(v216, "HushRaid", v217)
	if not v218 then
		return
	end
	v_u_15 = v219
	v_u_16 = v220
	local v221 = v_u_5.color
	local v222
	if v_u_5 then
		local v223 = v_u_5.isPhone
		if type(v223) == "function" then
			local v224 = v_u_5.isPhone
			local v225
			v222, v225 = pcall(v224)
			if v222 then
				v222 = v225 == true
			end
		else
			v222 = false
		end
	else
		v222 = false
	end
	local v226 = v222 and 72 or 112
	local v227 = Instance.new("Frame")
	v227.Name = "Extract"
	v227.BackgroundTransparency = 1
	v227.AnchorPoint = Vector2.new(0.5, 0)
	v227.Visible = false
	v227.Parent = v220
	local v228 = Instance.new("Frame")
	v228.Name = "Disc"
	v228.Size = UDim2.fromOffset(v226, v226)
	v228.BackgroundColor3 = v221.bg
	v228.BackgroundTransparency = 0.2
	v228.BorderSizePixel = 0
	v228.Parent = v227
	local v229 = Instance.new("UICorner")
	v229.CornerRadius = UDim.new(1, 0)
	v229.Parent = v228
	v_u_7.stroke(v228, v221.line, 1, 0)
	local v230 = v_u_7.ring({
		["parent"] = nil,
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["segments"] = 40,
		["thickness"] = nil,
		["color"] = nil,
		["parent"] = v228,
		["size"] = v226 - 12,
		["position"] = UDim2.fromScale(0.5, 0.5),
		["anchor"] = Vector2.new(0.5, 0.5),
		["thickness"] = v222 and 3 or 4,
		["color"] = v221.accent
	})
	local v231 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Secs",
		["text"] = "8.0",
		["style"] = nil,
		["align"] = "center",
		["valign"] = "center",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v228,
		["style"] = v222 and "mono" or "monoL",
		["size"] = UDim2.fromOffset(v226 - 32, 28),
		["position"] = UDim2.fromScale(0.5, 0.5),
		["anchor"] = Vector2.new(0.5, 0.5)
	})
	local v232 = v_u_7.icon
	local v233 = {
		["parent"] = nil,
		["name"] = "Check",
		["size"] = nil,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["parent"] = v228
	}
	local v234 = v226 * 0.32
	v233.size = math.floor(v234)
	v233.color = v221.success
	v233.position = UDim2.fromScale(0.5, 0.5)
	v233.anchor = Vector2.new(0.5, 0.5)
	local v235 = v232("check", v233)
	v235.Visible = false
	local v236
	if v222 then
		v236 = v226 + 48
	else
		v236 = v226 + 56
	end
	v227.Size = UDim2.fromOffset(v222 and 320 or 360, v236)
	local v237 = UDim2.new
	local v238 = 0.5
	local v239 = 0
	local v240 = 0.5
	local v241
	if v_u_5 then
		local v242 = v_u_5.refSize
		if type(v242) == "function" then
			local v243 = v_u_5.refSize
			local v244
			v244, v241 = pcall(v243)
			if not v244 or typeof(v241) ~= "Vector2" then
				v241 = Vector2.new(1920, 1080)
			end
		else
			v241 = Vector2.new(1920, 1080)
		end
	else
		v241 = Vector2.new(1920, 1080)
	end
	local v245 = (v241.Y * 0.5 - v236 - (v222 and 96 or 160)) / 8
	local v246 = math.floor(v245) * 8
	v227.Position = v237(v238, v239, v240, (math.clamp(v246, 24, 72)))
	v228.AnchorPoint = Vector2.new(0.5, 0)
	v228.Position = UDim2.fromScale(0.5, 0)
	local v247
	if v222 then
		v247 = v226 + 6
	else
		v247 = v226 + 8
	end
	local v248
	if v222 then
		v248 = v226 + 30
	else
		v248 = v226 + 34
	end
	local v249 = {
		["holder"] = nil,
		["ring"] = nil,
		["secs"] = nil,
		["check"] = nil,
		["title"] = nil,
		["sub"] = nil,
		["doneAt"] = 0,
		["color"] = nil,
		["baseW"] = nil,
		["h"] = nil,
		["y"] = nil,
		["holder"] = v227,
		["ring"] = v230,
		["secs"] = v231,
		["check"] = v235,
		["title"] = v_u_7.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "Extracting",
			["style"] = "h3",
			["color"] = nil,
			["align"] = "center",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v227,
			["color"] = v221.accent,
			["size"] = UDim2.new(1, 0, 0, 24),
			["position"] = UDim2.fromOffset(0, v247)
		}),
		["sub"] = v_u_7.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["align"] = "center",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v227,
			["size"] = UDim2.new(1, 0, 0, 18),
			["position"] = UDim2.fromOffset(0, v248)
		}),
		["color"] = v221.accent,
		["baseW"] = v222 and 320 or 360,
		["h"] = v236
	}
	local v250, v251, v252, v253, v254, v255, v256, v257, v258, v259, v260, v261, v262, v263, v264, v265, v266, v267, v268
	if v_u_5 then
		local v269 = v_u_5.refSize
		if type(v269) == "function" then
			local v270 = v_u_5.refSize
			local v271
			v271, v250 = pcall(v270)
			if v271 and typeof(v250) == "Vector2" then
				v251 = (v250.Y * 0.5 - v236 - (v222 and 96 or 160)) / 8
				v252 = math.floor(v251) * 8
				v249.y = math.clamp(v252, 24, 72)
				v_u_17 = v249
				v253 = v222 and 320 or 416
				if v222 then
					if v_u_5 then
						v254 = v_u_5.refSize
						if type(v254) == "function" then
							v255 = v_u_5.refSize
							v256, v257 = pcall(v255)
							if v256 and typeof(v257) == "Vector2" then
								v258 = (v257.Y * 0.5 - 64 - 24) / 8
								v259 = math.floor(v258) * 8
								v260 = math.clamp(v259, 24, 96)
								v261, v262 = v_u_7.panel({
									["parent"] = nil,
									["name"] = "ExtractBlocked",
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["accent"] = true,
									["padding"] = 12,
									["parent"] = v220,
									["size"] = UDim2.fromOffset(v253, 64),
									["position"] = UDim2.new(0.5, 0, 0.5, v260),
									["anchor"] = Vector2.new(0.5, 0)
								})
								v261.Visible = false
								v_u_18 = {
									["frame"] = v261,
									["name"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Name",
										["text"] = "",
										["style"] = "h3",
										["align"] = "center",
										["size"] = nil,
										["parent"] = v262,
										["size"] = UDim2.new(1, 0, 0, 20)
									}),
									["reason"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Reason",
										["text"] = "",
										["style"] = "small",
										["color"] = nil,
										["align"] = "center",
										["size"] = nil,
										["position"] = nil,
										["parent"] = v262,
										["color"] = v221.accent,
										["size"] = UDim2.new(1, 0, 0, 16),
										["position"] = UDim2.fromOffset(0, 24)
									}),
									["baseW"] = v253,
									["y"] = v260
								}
								v_u_215()
							else
								v257 = Vector2.new(1920, 1080)
								v258 = (v257.Y * 0.5 - 64 - 24) / 8
								v259 = math.floor(v258) * 8
								v260 = math.clamp(v259, 24, 96)
								v261, v262 = v_u_7.panel({
									["parent"] = nil,
									["name"] = "ExtractBlocked",
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["accent"] = true,
									["padding"] = 12,
									["parent"] = v220,
									["size"] = UDim2.fromOffset(v253, 64),
									["position"] = UDim2.new(0.5, 0, 0.5, v260),
									["anchor"] = Vector2.new(0.5, 0)
								})
								v261.Visible = false
								v_u_18 = {
									["frame"] = v261,
									["name"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Name",
										["text"] = "",
										["style"] = "h3",
										["align"] = "center",
										["size"] = nil,
										["parent"] = v262,
										["size"] = UDim2.new(1, 0, 0, 20)
									}),
									["reason"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Reason",
										["text"] = "",
										["style"] = "small",
										["color"] = nil,
										["align"] = "center",
										["size"] = nil,
										["position"] = nil,
										["parent"] = v262,
										["color"] = v221.accent,
										["size"] = UDim2.new(1, 0, 0, 16),
										["position"] = UDim2.fromOffset(0, 24)
									}),
									["baseW"] = v253,
									["y"] = v260
								}
								v_u_215()
							end
						else
							v257 = Vector2.new(1920, 1080)
							v258 = (v257.Y * 0.5 - 64 - 24) / 8
							v259 = math.floor(v258) * 8
							v260 = math.clamp(v259, 24, 96)
							v261, v262 = v_u_7.panel({
								["parent"] = nil,
								["name"] = "ExtractBlocked",
								["size"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["accent"] = true,
								["padding"] = 12,
								["parent"] = v220,
								["size"] = UDim2.fromOffset(v253, 64),
								["position"] = UDim2.new(0.5, 0, 0.5, v260),
								["anchor"] = Vector2.new(0.5, 0)
							})
							v261.Visible = false
							v_u_18 = {
								["frame"] = v261,
								["name"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Name",
									["text"] = "",
									["style"] = "h3",
									["align"] = "center",
									["size"] = nil,
									["parent"] = v262,
									["size"] = UDim2.new(1, 0, 0, 20)
								}),
								["reason"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Reason",
									["text"] = "",
									["style"] = "small",
									["color"] = nil,
									["align"] = "center",
									["size"] = nil,
									["position"] = nil,
									["parent"] = v262,
									["color"] = v221.accent,
									["size"] = UDim2.new(1, 0, 0, 16),
									["position"] = UDim2.fromOffset(0, 24)
								}),
								["baseW"] = v253,
								["y"] = v260
							}
							v_u_215()
							return
						end
					else
						v257 = Vector2.new(1920, 1080)
						v258 = (v257.Y * 0.5 - 64 - 24) / 8
						v259 = math.floor(v258) * 8
						v260 = math.clamp(v259, 24, 96)
						v261, v262 = v_u_7.panel({
							["parent"] = nil,
							["name"] = "ExtractBlocked",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["accent"] = true,
							["padding"] = 12,
							["parent"] = v220,
							["size"] = UDim2.fromOffset(v253, 64),
							["position"] = UDim2.new(0.5, 0, 0.5, v260),
							["anchor"] = Vector2.new(0.5, 0)
						})
						v261.Visible = false
						v_u_18 = {
							["frame"] = v261,
							["name"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = "",
								["style"] = "h3",
								["align"] = "center",
								["size"] = nil,
								["parent"] = v262,
								["size"] = UDim2.new(1, 0, 0, 20)
							}),
							["reason"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["position"] = nil,
								["parent"] = v262,
								["color"] = v221.accent,
								["size"] = UDim2.new(1, 0, 0, 16),
								["position"] = UDim2.fromOffset(0, 24)
							}),
							["baseW"] = v253,
							["y"] = v260
						}
						v_u_215()
						return
					end
				else
					if v_u_5 then
						v263 = v_u_5.refSize
						if type(v263) == "function" then
							v264 = v_u_5.refSize
							v265, v266 = pcall(v264)
							if v265 and typeof(v266) == "Vector2" then
								v267 = (v266.Y * 0.5 - 64 - 160) / 8
								v268 = math.floor(v267) * 8
								v260 = math.clamp(v268, 24, 72)
							else
								v266 = Vector2.new(1920, 1080)
								v267 = (v266.Y * 0.5 - 64 - 160) / 8
								v268 = math.floor(v267) * 8
								v260 = math.clamp(v268, 24, 72)
							end
						else
							v266 = Vector2.new(1920, 1080)
							v267 = (v266.Y * 0.5 - 64 - 160) / 8
							v268 = math.floor(v267) * 8
							v260 = math.clamp(v268, 24, 72)
						end
					else
						v266 = Vector2.new(1920, 1080)
						v267 = (v266.Y * 0.5 - 64 - 160) / 8
						v268 = math.floor(v267) * 8
						v260 = math.clamp(v268, 24, 72)
					end
					v261, v262 = v_u_7.panel({
						["parent"] = nil,
						["name"] = "ExtractBlocked",
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["accent"] = true,
						["padding"] = 12,
						["parent"] = v220,
						["size"] = UDim2.fromOffset(v253, 64),
						["position"] = UDim2.new(0.5, 0, 0.5, v260),
						["anchor"] = Vector2.new(0.5, 0)
					})
					v261.Visible = false
					v_u_18 = {
						["frame"] = v261,
						["name"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = "",
							["style"] = "h3",
							["align"] = "center",
							["size"] = nil,
							["parent"] = v262,
							["size"] = UDim2.new(1, 0, 0, 20)
						}),
						["reason"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["position"] = nil,
							["parent"] = v262,
							["color"] = v221.accent,
							["size"] = UDim2.new(1, 0, 0, 16),
							["position"] = UDim2.fromOffset(0, 24)
						}),
						["baseW"] = v253,
						["y"] = v260
					}
					v_u_215()
					return
				end
			else
				v250 = Vector2.new(1920, 1080)
				v251 = (v250.Y * 0.5 - v236 - (v222 and 96 or 160)) / 8
				v252 = math.floor(v251) * 8
				v249.y = math.clamp(v252, 24, 72)
				v_u_17 = v249
				v253 = v222 and 320 or 416
				if v222 then
					if v_u_5 then
						v254 = v_u_5.refSize
						if type(v254) == "function" then
							v255 = v_u_5.refSize
							v256, v257 = pcall(v255)
							if v256 and typeof(v257) == "Vector2" then
								v258 = (v257.Y * 0.5 - 64 - 24) / 8
								v259 = math.floor(v258) * 8
								v260 = math.clamp(v259, 24, 96)
								v261, v262 = v_u_7.panel({
									["parent"] = nil,
									["name"] = "ExtractBlocked",
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["accent"] = true,
									["padding"] = 12,
									["parent"] = v220,
									["size"] = UDim2.fromOffset(v253, 64),
									["position"] = UDim2.new(0.5, 0, 0.5, v260),
									["anchor"] = Vector2.new(0.5, 0)
								})
								v261.Visible = false
								v_u_18 = {
									["frame"] = v261,
									["name"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Name",
										["text"] = "",
										["style"] = "h3",
										["align"] = "center",
										["size"] = nil,
										["parent"] = v262,
										["size"] = UDim2.new(1, 0, 0, 20)
									}),
									["reason"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Reason",
										["text"] = "",
										["style"] = "small",
										["color"] = nil,
										["align"] = "center",
										["size"] = nil,
										["position"] = nil,
										["parent"] = v262,
										["color"] = v221.accent,
										["size"] = UDim2.new(1, 0, 0, 16),
										["position"] = UDim2.fromOffset(0, 24)
									}),
									["baseW"] = v253,
									["y"] = v260
								}
								v_u_215()
							else
								v257 = Vector2.new(1920, 1080)
								v258 = (v257.Y * 0.5 - 64 - 24) / 8
								v259 = math.floor(v258) * 8
								v260 = math.clamp(v259, 24, 96)
								v261, v262 = v_u_7.panel({
									["parent"] = nil,
									["name"] = "ExtractBlocked",
									["size"] = nil,
									["position"] = nil,
									["anchor"] = nil,
									["accent"] = true,
									["padding"] = 12,
									["parent"] = v220,
									["size"] = UDim2.fromOffset(v253, 64),
									["position"] = UDim2.new(0.5, 0, 0.5, v260),
									["anchor"] = Vector2.new(0.5, 0)
								})
								v261.Visible = false
								v_u_18 = {
									["frame"] = v261,
									["name"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Name",
										["text"] = "",
										["style"] = "h3",
										["align"] = "center",
										["size"] = nil,
										["parent"] = v262,
										["size"] = UDim2.new(1, 0, 0, 20)
									}),
									["reason"] = v_u_7.label({
										["parent"] = nil,
										["name"] = "Reason",
										["text"] = "",
										["style"] = "small",
										["color"] = nil,
										["align"] = "center",
										["size"] = nil,
										["position"] = nil,
										["parent"] = v262,
										["color"] = v221.accent,
										["size"] = UDim2.new(1, 0, 0, 16),
										["position"] = UDim2.fromOffset(0, 24)
									}),
									["baseW"] = v253,
									["y"] = v260
								}
								v_u_215()
							end
						else
							v257 = Vector2.new(1920, 1080)
							v258 = (v257.Y * 0.5 - 64 - 24) / 8
							v259 = math.floor(v258) * 8
							v260 = math.clamp(v259, 24, 96)
							v261, v262 = v_u_7.panel({
								["parent"] = nil,
								["name"] = "ExtractBlocked",
								["size"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["accent"] = true,
								["padding"] = 12,
								["parent"] = v220,
								["size"] = UDim2.fromOffset(v253, 64),
								["position"] = UDim2.new(0.5, 0, 0.5, v260),
								["anchor"] = Vector2.new(0.5, 0)
							})
							v261.Visible = false
							v_u_18 = {
								["frame"] = v261,
								["name"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Name",
									["text"] = "",
									["style"] = "h3",
									["align"] = "center",
									["size"] = nil,
									["parent"] = v262,
									["size"] = UDim2.new(1, 0, 0, 20)
								}),
								["reason"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Reason",
									["text"] = "",
									["style"] = "small",
									["color"] = nil,
									["align"] = "center",
									["size"] = nil,
									["position"] = nil,
									["parent"] = v262,
									["color"] = v221.accent,
									["size"] = UDim2.new(1, 0, 0, 16),
									["position"] = UDim2.fromOffset(0, 24)
								}),
								["baseW"] = v253,
								["y"] = v260
							}
							v_u_215()
							return
						end
					else
						v257 = Vector2.new(1920, 1080)
						v258 = (v257.Y * 0.5 - 64 - 24) / 8
						v259 = math.floor(v258) * 8
						v260 = math.clamp(v259, 24, 96)
						v261, v262 = v_u_7.panel({
							["parent"] = nil,
							["name"] = "ExtractBlocked",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["accent"] = true,
							["padding"] = 12,
							["parent"] = v220,
							["size"] = UDim2.fromOffset(v253, 64),
							["position"] = UDim2.new(0.5, 0, 0.5, v260),
							["anchor"] = Vector2.new(0.5, 0)
						})
						v261.Visible = false
						v_u_18 = {
							["frame"] = v261,
							["name"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = "",
								["style"] = "h3",
								["align"] = "center",
								["size"] = nil,
								["parent"] = v262,
								["size"] = UDim2.new(1, 0, 0, 20)
							}),
							["reason"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["position"] = nil,
								["parent"] = v262,
								["color"] = v221.accent,
								["size"] = UDim2.new(1, 0, 0, 16),
								["position"] = UDim2.fromOffset(0, 24)
							}),
							["baseW"] = v253,
							["y"] = v260
						}
						v_u_215()
						return
					end
				else
					if v_u_5 then
						v263 = v_u_5.refSize
						if type(v263) == "function" then
							v264 = v_u_5.refSize
							v265, v266 = pcall(v264)
							if v265 and typeof(v266) == "Vector2" then
								v267 = (v266.Y * 0.5 - 64 - 160) / 8
								v268 = math.floor(v267) * 8
								v260 = math.clamp(v268, 24, 72)
							else
								v266 = Vector2.new(1920, 1080)
								v267 = (v266.Y * 0.5 - 64 - 160) / 8
								v268 = math.floor(v267) * 8
								v260 = math.clamp(v268, 24, 72)
							end
						else
							v266 = Vector2.new(1920, 1080)
							v267 = (v266.Y * 0.5 - 64 - 160) / 8
							v268 = math.floor(v267) * 8
							v260 = math.clamp(v268, 24, 72)
						end
					else
						v266 = Vector2.new(1920, 1080)
						v267 = (v266.Y * 0.5 - 64 - 160) / 8
						v268 = math.floor(v267) * 8
						v260 = math.clamp(v268, 24, 72)
					end
					v261, v262 = v_u_7.panel({
						["parent"] = nil,
						["name"] = "ExtractBlocked",
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["accent"] = true,
						["padding"] = 12,
						["parent"] = v220,
						["size"] = UDim2.fromOffset(v253, 64),
						["position"] = UDim2.new(0.5, 0, 0.5, v260),
						["anchor"] = Vector2.new(0.5, 0)
					})
					v261.Visible = false
					v_u_18 = {
						["frame"] = v261,
						["name"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = "",
							["style"] = "h3",
							["align"] = "center",
							["size"] = nil,
							["parent"] = v262,
							["size"] = UDim2.new(1, 0, 0, 20)
						}),
						["reason"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["position"] = nil,
							["parent"] = v262,
							["color"] = v221.accent,
							["size"] = UDim2.new(1, 0, 0, 16),
							["position"] = UDim2.fromOffset(0, 24)
						}),
						["baseW"] = v253,
						["y"] = v260
					}
					v_u_215()
					return
				end
			end
		else
			v250 = Vector2.new(1920, 1080)
			v251 = (v250.Y * 0.5 - v236 - (v222 and 96 or 160)) / 8
			v252 = math.floor(v251) * 8
			v249.y = math.clamp(v252, 24, 72)
			v_u_17 = v249
			v253 = v222 and 320 or 416
			if v222 then
				if v_u_5 then
					v254 = v_u_5.refSize
					if type(v254) == "function" then
						v255 = v_u_5.refSize
						v256, v257 = pcall(v255)
						if v256 and typeof(v257) == "Vector2" then
							v258 = (v257.Y * 0.5 - 64 - 24) / 8
							v259 = math.floor(v258) * 8
							v260 = math.clamp(v259, 24, 96)
							v261, v262 = v_u_7.panel({
								["parent"] = nil,
								["name"] = "ExtractBlocked",
								["size"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["accent"] = true,
								["padding"] = 12,
								["parent"] = v220,
								["size"] = UDim2.fromOffset(v253, 64),
								["position"] = UDim2.new(0.5, 0, 0.5, v260),
								["anchor"] = Vector2.new(0.5, 0)
							})
							v261.Visible = false
							v_u_18 = {
								["frame"] = v261,
								["name"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Name",
									["text"] = "",
									["style"] = "h3",
									["align"] = "center",
									["size"] = nil,
									["parent"] = v262,
									["size"] = UDim2.new(1, 0, 0, 20)
								}),
								["reason"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Reason",
									["text"] = "",
									["style"] = "small",
									["color"] = nil,
									["align"] = "center",
									["size"] = nil,
									["position"] = nil,
									["parent"] = v262,
									["color"] = v221.accent,
									["size"] = UDim2.new(1, 0, 0, 16),
									["position"] = UDim2.fromOffset(0, 24)
								}),
								["baseW"] = v253,
								["y"] = v260
							}
							v_u_215()
						else
							v257 = Vector2.new(1920, 1080)
							v258 = (v257.Y * 0.5 - 64 - 24) / 8
							v259 = math.floor(v258) * 8
							v260 = math.clamp(v259, 24, 96)
							v261, v262 = v_u_7.panel({
								["parent"] = nil,
								["name"] = "ExtractBlocked",
								["size"] = nil,
								["position"] = nil,
								["anchor"] = nil,
								["accent"] = true,
								["padding"] = 12,
								["parent"] = v220,
								["size"] = UDim2.fromOffset(v253, 64),
								["position"] = UDim2.new(0.5, 0, 0.5, v260),
								["anchor"] = Vector2.new(0.5, 0)
							})
							v261.Visible = false
							v_u_18 = {
								["frame"] = v261,
								["name"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Name",
									["text"] = "",
									["style"] = "h3",
									["align"] = "center",
									["size"] = nil,
									["parent"] = v262,
									["size"] = UDim2.new(1, 0, 0, 20)
								}),
								["reason"] = v_u_7.label({
									["parent"] = nil,
									["name"] = "Reason",
									["text"] = "",
									["style"] = "small",
									["color"] = nil,
									["align"] = "center",
									["size"] = nil,
									["position"] = nil,
									["parent"] = v262,
									["color"] = v221.accent,
									["size"] = UDim2.new(1, 0, 0, 16),
									["position"] = UDim2.fromOffset(0, 24)
								}),
								["baseW"] = v253,
								["y"] = v260
							}
							v_u_215()
						end
					else
						v257 = Vector2.new(1920, 1080)
						v258 = (v257.Y * 0.5 - 64 - 24) / 8
						v259 = math.floor(v258) * 8
						v260 = math.clamp(v259, 24, 96)
						v261, v262 = v_u_7.panel({
							["parent"] = nil,
							["name"] = "ExtractBlocked",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["accent"] = true,
							["padding"] = 12,
							["parent"] = v220,
							["size"] = UDim2.fromOffset(v253, 64),
							["position"] = UDim2.new(0.5, 0, 0.5, v260),
							["anchor"] = Vector2.new(0.5, 0)
						})
						v261.Visible = false
						v_u_18 = {
							["frame"] = v261,
							["name"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = "",
								["style"] = "h3",
								["align"] = "center",
								["size"] = nil,
								["parent"] = v262,
								["size"] = UDim2.new(1, 0, 0, 20)
							}),
							["reason"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["position"] = nil,
								["parent"] = v262,
								["color"] = v221.accent,
								["size"] = UDim2.new(1, 0, 0, 16),
								["position"] = UDim2.fromOffset(0, 24)
							}),
							["baseW"] = v253,
							["y"] = v260
						}
						v_u_215()
						return
					end
				else
					v257 = Vector2.new(1920, 1080)
					v258 = (v257.Y * 0.5 - 64 - 24) / 8
					v259 = math.floor(v258) * 8
					v260 = math.clamp(v259, 24, 96)
					v261, v262 = v_u_7.panel({
						["parent"] = nil,
						["name"] = "ExtractBlocked",
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["accent"] = true,
						["padding"] = 12,
						["parent"] = v220,
						["size"] = UDim2.fromOffset(v253, 64),
						["position"] = UDim2.new(0.5, 0, 0.5, v260),
						["anchor"] = Vector2.new(0.5, 0)
					})
					v261.Visible = false
					v_u_18 = {
						["frame"] = v261,
						["name"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = "",
							["style"] = "h3",
							["align"] = "center",
							["size"] = nil,
							["parent"] = v262,
							["size"] = UDim2.new(1, 0, 0, 20)
						}),
						["reason"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["position"] = nil,
							["parent"] = v262,
							["color"] = v221.accent,
							["size"] = UDim2.new(1, 0, 0, 16),
							["position"] = UDim2.fromOffset(0, 24)
						}),
						["baseW"] = v253,
						["y"] = v260
					}
					v_u_215()
					return
				end
			else
				if v_u_5 then
					v263 = v_u_5.refSize
					if type(v263) == "function" then
						v264 = v_u_5.refSize
						v265, v266 = pcall(v264)
						if v265 and typeof(v266) == "Vector2" then
							v267 = (v266.Y * 0.5 - 64 - 160) / 8
							v268 = math.floor(v267) * 8
							v260 = math.clamp(v268, 24, 72)
						else
							v266 = Vector2.new(1920, 1080)
							v267 = (v266.Y * 0.5 - 64 - 160) / 8
							v268 = math.floor(v267) * 8
							v260 = math.clamp(v268, 24, 72)
						end
					else
						v266 = Vector2.new(1920, 1080)
						v267 = (v266.Y * 0.5 - 64 - 160) / 8
						v268 = math.floor(v267) * 8
						v260 = math.clamp(v268, 24, 72)
					end
				else
					v266 = Vector2.new(1920, 1080)
					v267 = (v266.Y * 0.5 - 64 - 160) / 8
					v268 = math.floor(v267) * 8
					v260 = math.clamp(v268, 24, 72)
				end
				v261, v262 = v_u_7.panel({
					["parent"] = nil,
					["name"] = "ExtractBlocked",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["accent"] = true,
					["padding"] = 12,
					["parent"] = v220,
					["size"] = UDim2.fromOffset(v253, 64),
					["position"] = UDim2.new(0.5, 0, 0.5, v260),
					["anchor"] = Vector2.new(0.5, 0)
				})
				v261.Visible = false
				v_u_18 = {
					["frame"] = v261,
					["name"] = v_u_7.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = "",
						["style"] = "h3",
						["align"] = "center",
						["size"] = nil,
						["parent"] = v262,
						["size"] = UDim2.new(1, 0, 0, 20)
					}),
					["reason"] = v_u_7.label({
						["parent"] = nil,
						["name"] = "Reason",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["parent"] = v262,
						["color"] = v221.accent,
						["size"] = UDim2.new(1, 0, 0, 16),
						["position"] = UDim2.fromOffset(0, 24)
					}),
					["baseW"] = v253,
					["y"] = v260
				}
				v_u_215()
				return
			end
		end
	else
		v250 = Vector2.new(1920, 1080)
		v251 = (v250.Y * 0.5 - v236 - (v222 and 96 or 160)) / 8
		v252 = math.floor(v251) * 8
		v249.y = math.clamp(v252, 24, 72)
		v_u_17 = v249
		v253 = v222 and 320 or 416
		if v222 then
			if v_u_5 then
				v254 = v_u_5.refSize
				if type(v254) == "function" then
					v255 = v_u_5.refSize
					v256, v257 = pcall(v255)
					if v256 and typeof(v257) == "Vector2" then
						v258 = (v257.Y * 0.5 - 64 - 24) / 8
						v259 = math.floor(v258) * 8
						v260 = math.clamp(v259, 24, 96)
						v261, v262 = v_u_7.panel({
							["parent"] = nil,
							["name"] = "ExtractBlocked",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["accent"] = true,
							["padding"] = 12,
							["parent"] = v220,
							["size"] = UDim2.fromOffset(v253, 64),
							["position"] = UDim2.new(0.5, 0, 0.5, v260),
							["anchor"] = Vector2.new(0.5, 0)
						})
						v261.Visible = false
						v_u_18 = {
							["frame"] = v261,
							["name"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = "",
								["style"] = "h3",
								["align"] = "center",
								["size"] = nil,
								["parent"] = v262,
								["size"] = UDim2.new(1, 0, 0, 20)
							}),
							["reason"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["position"] = nil,
								["parent"] = v262,
								["color"] = v221.accent,
								["size"] = UDim2.new(1, 0, 0, 16),
								["position"] = UDim2.fromOffset(0, 24)
							}),
							["baseW"] = v253,
							["y"] = v260
						}
						v_u_215()
					else
						v257 = Vector2.new(1920, 1080)
						v258 = (v257.Y * 0.5 - 64 - 24) / 8
						v259 = math.floor(v258) * 8
						v260 = math.clamp(v259, 24, 96)
						v261, v262 = v_u_7.panel({
							["parent"] = nil,
							["name"] = "ExtractBlocked",
							["size"] = nil,
							["position"] = nil,
							["anchor"] = nil,
							["accent"] = true,
							["padding"] = 12,
							["parent"] = v220,
							["size"] = UDim2.fromOffset(v253, 64),
							["position"] = UDim2.new(0.5, 0, 0.5, v260),
							["anchor"] = Vector2.new(0.5, 0)
						})
						v261.Visible = false
						v_u_18 = {
							["frame"] = v261,
							["name"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Name",
								["text"] = "",
								["style"] = "h3",
								["align"] = "center",
								["size"] = nil,
								["parent"] = v262,
								["size"] = UDim2.new(1, 0, 0, 20)
							}),
							["reason"] = v_u_7.label({
								["parent"] = nil,
								["name"] = "Reason",
								["text"] = "",
								["style"] = "small",
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["position"] = nil,
								["parent"] = v262,
								["color"] = v221.accent,
								["size"] = UDim2.new(1, 0, 0, 16),
								["position"] = UDim2.fromOffset(0, 24)
							}),
							["baseW"] = v253,
							["y"] = v260
						}
						v_u_215()
					end
				else
					v257 = Vector2.new(1920, 1080)
					v258 = (v257.Y * 0.5 - 64 - 24) / 8
					v259 = math.floor(v258) * 8
					v260 = math.clamp(v259, 24, 96)
					v261, v262 = v_u_7.panel({
						["parent"] = nil,
						["name"] = "ExtractBlocked",
						["size"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["accent"] = true,
						["padding"] = 12,
						["parent"] = v220,
						["size"] = UDim2.fromOffset(v253, 64),
						["position"] = UDim2.new(0.5, 0, 0.5, v260),
						["anchor"] = Vector2.new(0.5, 0)
					})
					v261.Visible = false
					v_u_18 = {
						["frame"] = v261,
						["name"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Name",
							["text"] = "",
							["style"] = "h3",
							["align"] = "center",
							["size"] = nil,
							["parent"] = v262,
							["size"] = UDim2.new(1, 0, 0, 20)
						}),
						["reason"] = v_u_7.label({
							["parent"] = nil,
							["name"] = "Reason",
							["text"] = "",
							["style"] = "small",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["position"] = nil,
							["parent"] = v262,
							["color"] = v221.accent,
							["size"] = UDim2.new(1, 0, 0, 16),
							["position"] = UDim2.fromOffset(0, 24)
						}),
						["baseW"] = v253,
						["y"] = v260
					}
					v_u_215()
					return
				end
			else
				v257 = Vector2.new(1920, 1080)
				v258 = (v257.Y * 0.5 - 64 - 24) / 8
				v259 = math.floor(v258) * 8
				v260 = math.clamp(v259, 24, 96)
				v261, v262 = v_u_7.panel({
					["parent"] = nil,
					["name"] = "ExtractBlocked",
					["size"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["accent"] = true,
					["padding"] = 12,
					["parent"] = v220,
					["size"] = UDim2.fromOffset(v253, 64),
					["position"] = UDim2.new(0.5, 0, 0.5, v260),
					["anchor"] = Vector2.new(0.5, 0)
				})
				v261.Visible = false
				v_u_18 = {
					["frame"] = v261,
					["name"] = v_u_7.label({
						["parent"] = nil,
						["name"] = "Name",
						["text"] = "",
						["style"] = "h3",
						["align"] = "center",
						["size"] = nil,
						["parent"] = v262,
						["size"] = UDim2.new(1, 0, 0, 20)
					}),
					["reason"] = v_u_7.label({
						["parent"] = nil,
						["name"] = "Reason",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["position"] = nil,
						["parent"] = v262,
						["color"] = v221.accent,
						["size"] = UDim2.new(1, 0, 0, 16),
						["position"] = UDim2.fromOffset(0, 24)
					}),
					["baseW"] = v253,
					["y"] = v260
				}
				v_u_215()
				return
			end
		else
			if v_u_5 then
				v263 = v_u_5.refSize
				if type(v263) == "function" then
					v264 = v_u_5.refSize
					v265, v266 = pcall(v264)
					if v265 and typeof(v266) == "Vector2" then
						v267 = (v266.Y * 0.5 - 64 - 160) / 8
						v268 = math.floor(v267) * 8
						v260 = math.clamp(v268, 24, 72)
					else
						v266 = Vector2.new(1920, 1080)
						v267 = (v266.Y * 0.5 - 64 - 160) / 8
						v268 = math.floor(v267) * 8
						v260 = math.clamp(v268, 24, 72)
					end
				else
					v266 = Vector2.new(1920, 1080)
					v267 = (v266.Y * 0.5 - 64 - 160) / 8
					v268 = math.floor(v267) * 8
					v260 = math.clamp(v268, 24, 72)
				end
			else
				v266 = Vector2.new(1920, 1080)
				v267 = (v266.Y * 0.5 - 64 - 160) / 8
				v268 = math.floor(v267) * 8
				v260 = math.clamp(v268, 24, 72)
			end
			v261, v262 = v_u_7.panel({
				["parent"] = nil,
				["name"] = "ExtractBlocked",
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["accent"] = true,
				["padding"] = 12,
				["parent"] = v220,
				["size"] = UDim2.fromOffset(v253, 64),
				["position"] = UDim2.new(0.5, 0, 0.5, v260),
				["anchor"] = Vector2.new(0.5, 0)
			})
			v261.Visible = false
			v_u_18 = {
				["frame"] = v261,
				["name"] = v_u_7.label({
					["parent"] = nil,
					["name"] = "Name",
					["text"] = "",
					["style"] = "h3",
					["align"] = "center",
					["size"] = nil,
					["parent"] = v262,
					["size"] = UDim2.new(1, 0, 0, 20)
				}),
				["reason"] = v_u_7.label({
					["parent"] = nil,
					["name"] = "Reason",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["position"] = nil,
					["parent"] = v262,
					["color"] = v221.accent,
					["size"] = UDim2.new(1, 0, 0, 16),
					["position"] = UDim2.fromOffset(0, 24)
				}),
				["baseW"] = v253,
				["y"] = v260
			}
			v_u_215()
			return
		end
	end
end
local function v_u_295(p273, p274, p275) -- name: applyExtract
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_5, (ref) v_u_7, (copy) v_u_39, (ref) v_u_11
	if v_u_17 and (v_u_18 and v_u_5) then
		local v276 = v_u_5.color
		local v277 = p273.state
		local v278 = p273.name or ""
		local v279 = tostring(v278)
		v_u_17.secs.Visible = v277 ~= "done"
		v_u_17.check.Visible = v277 == "done"
		if v277 == "progress" or v277 == "interrupted" then
			v_u_18.frame.Visible = false
			if v_u_17 then
				v_u_17.holder.Visible = true
			end
			v_u_17.doneAt = 0
			if v277 == "interrupted" then
				local v280 = v276.danger
				if v_u_17 then
					v_u_17.color = v280
					local v281 = v_u_17.ring.setColor
					pcall(v281, v280)
					v_u_17.title.TextColor3 = v280
				end
				v_u_7.setText(v_u_17.title, "Interrupted")
				v_u_7.setText(v_u_17.sub, "Hit. Hold position")
			else
				local v282 = v276.accent
				if v_u_17 then
					v_u_17.color = v282
					local v283 = v_u_17.ring.setColor
					pcall(v283, v282)
					v_u_17.title.TextColor3 = v282
				end
				v_u_7.setText(v_u_17.title, "Extracting")
				v_u_7.setText(v_u_17.sub, v279)
			end
			if not p275 then
				if v277 == "interrupted" then
					v_u_39("ui", "error")
					return
				end
				if not p274 or p274.state ~= "progress" then
					v_u_39("ui", "confirm")
					return
				end
			end
		else
			if v277 == "blocked" then
				if v_u_17 then
					v_u_17.holder.Visible = false
				end
				v_u_7.setText(v_u_18.name, v279 == "" and "Extract" or v279)
				local v284 = v_u_7.setText
				local v285 = v_u_18.reason
				local v286 = p273.reason or ""
				v284(v285, (tostring(v286)))
				v_u_18.frame.Visible = true
				return
			end
			if v277 == "done" then
				v_u_18.frame.Visible = false
				if v_u_17 then
					v_u_17.holder.Visible = true
				end
				local v287 = v276.success
				if v_u_17 then
					v_u_17.color = v287
					local v288 = v_u_17.ring.setColor
					pcall(v288, v287)
					v_u_17.title.TextColor3 = v287
				end
				local v289 = v_u_17.ring.set
				pcall(v289, 1)
				v_u_7.setText(v_u_17.title, "Extracted")
				local v290 = v_u_11 and v_u_11:GetAttribute("Map") or "the raid"
				local v291 = tostring(v290)
				local v292 = v_u_7.setText
				local v293 = v_u_17.sub
				local v294
				if v279 == "" then
					v294 = "Leaving " .. v291
				else
					v294 = v279 .. "  \194\183  leaving " .. v291
				end
				v292(v293, v294)
				if not p275 then
					v_u_17.doneAt = os.clock()
					v_u_39("ui", "extracted")
					if p273.id == "smuggler_boat" then
						v_u_39("play", "ev_boat")
						return
					end
					if p273.id == "pickup" then
						v_u_39("play", "ev_engine")
						return
					end
				end
			else
				v_u_18.frame.Visible = false
				if v_u_17.doneAt == 0 and v_u_17 then
					v_u_17.holder.Visible = false
				end
			end
		end
	end
end
local function v_u_298(p296) -- name: onExtractProgress
	-- upvalues: (ref) v_u_20, (ref) v_u_179, (copy) v_u_295
	if type(p296) == "table" then
		local v297 = v_u_20
		v_u_20 = p296
		v_u_179 = nil
		v_u_295(p296, v297, false)
	end
end
local function v_u_310() -- name: updateRing
	-- upvalues: (ref) v_u_20, (ref) v_u_17, (ref) v_u_179, (copy) v_u_31, (copy) v_u_295
	local v299 = v_u_20
	if v_u_17 and not v_u_179 then
		if v_u_17.doneAt > 0 then
			if os.clock() - v_u_17.doneAt > 2.5 then
				v_u_17.doneAt = 0
				if v_u_17 then
					v_u_17.holder.Visible = false
				end
			end
			return
		elseif v299 and (v299.state == "progress" or v299.state == "interrupted") then
			local v300 = v299.duration
			local v301 = tonumber(v300) or 8
			local v302 = v_u_31.now()
			local v303 = v299.startedAt
			local v304 = v302 - (tonumber(v303) or v_u_31.now())
			if v299.state == "interrupted" and v304 > 1.2 then
				v299.state = "progress"
				v_u_295(v299, v299, true)
			end
			local v305 = v304 / v301
			local v306 = math.clamp(v305, 0, 1)
			v_u_17.ring.set(v306)
			local v307 = v_u_17.secs
			local v308 = string.format
			local v309 = v301 * (1 - v306)
			v307.Text = v308("%.1f", (math.max(0, v309)))
		end
	else
		return
	end
end
local function v_u_316() -- name: squadTargets
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v311 = v_u_4:GetAttribute("SquadId")
	local v312 = {}
	for _, v313 in v_u_1:GetPlayers() do
		if v313 == v_u_4 or (v311 == nil or v313:GetAttribute("SquadId") ~= v311) then
			continue
		end
		local v314 = v313:GetAttribute("RaidStatus")
		local v315 = v313.Character
		if not v315 or (not v315.Parent or v314 ~= "Alive" and v314 ~= "Downed") then
			continue
		end
		table.insert(v312, v315)
	end
	return v312
end
local function v_u_326(p317, p318) -- name: spectateSub
	-- upvalues: (ref) v_u_27, (ref) v_u_180, (ref) v_u_11, (ref) v_u_3
	if p317 then
		local v319 = v_u_27
		local v320 = math.max(p318, 1)
		return ("Squad mate %d of %d"):format(math.clamp(v319, 1, v320), (math.max(p318, 1)))
	end
	local v321 = 7 - (os.clock() - v_u_180)
	local v322 = math.ceil(v321)
	local v323 = math.max(0, v322)
	if v323 <= 0 then
		local v324 = v_u_11 and v_u_11:GetAttribute("Map") or "the raid"
		return "Leaving " .. tostring(v324)
	end
	local v325 = v_u_3
	if v325 then
		v325 = v_u_3.shared.HudWhy
	end
	return v325.noMateText(v323)
end
local function v_u_333() -- name: paintSpectate
	-- upvalues: (ref) v_u_19, (ref) v_u_179, (ref) v_u_7, (ref) v_u_26, (copy) v_u_1, (copy) v_u_316, (copy) v_u_326
	if v_u_19 then
		if v_u_179 == "spectate" then
			v_u_7.setText(v_u_19.head, "Killed in action  \194\183  spectating")
			v_u_7.setText(v_u_19.name, "Survivor_Mara")
			v_u_7.setText(v_u_19.sub, "Squad mate 1 of 2")
			v_u_19.next.Visible = true
		else
			local v327 = v_u_26
			local v328
			if v327 then
				v328 = v_u_1:GetPlayerFromCharacter(v327)
			else
				v328 = v327
			end
			local v329 = v_u_316()
			v_u_7.setText(v_u_19.head, v328 and "Killed in action  \194\183  spectating" or "Killed in action")
			v_u_7.setText(v_u_19.name, not v328 and "Your run ends here" or v328.DisplayName)
			local v330 = v_u_7.setText
			local v331 = v_u_19.sub
			local v332 = v_u_326
			if not v328 then
				v327 = nil
			end
			v330(v331, v332(v327, #v329))
			v_u_19.next.Visible = #v329 > 1
		end
	else
		return
	end
end
local function v_u_342(p334) -- name: setSpectate
	-- upvalues: (ref) v_u_26, (ref) v_u_3, (copy) v_u_1, (copy) v_u_333
	v_u_26 = p334
	local v335 = v_u_3
	if v335 then
		v335 = v_u_3.controllers.Camera
	end
	if not v335 or v335._broken then
		v335 = nil
	end
	if v335 then
		local v336 = v335.setMode
		if type(v336) == "function" then
			if p334 then
				local v337 = v335.setMode
				pcall(v337, "spectate", p334)
			else
				local v338 = v335.setMode
				pcall(v338, "iso")
			end
		end
	end
	if p334 then
		p334 = v_u_1:GetPlayerFromCharacter(p334)
	end
	local v_u_339 = not p334 and 0 or p334.UserId
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_339
		local v340 = v_u_3.net.fire
		local v341 = v_u_339
		pcall(v340, "raid.spectate", v341)
	end)
	v_u_333()
end
local function v_u_344() -- name: nextSpectate
	-- upvalues: (copy) v_u_316, (ref) v_u_27, (copy) v_u_342
	local v343 = v_u_316()
	if #v343 > 0 then
		v_u_27 = v_u_27 % #v343 + 1
		v_u_342(v343[v_u_27])
	end
end
local function v_u_364() -- name: buildSpectateUi
	-- upvalues: (ref) v_u_19, (ref) v_u_16, (ref) v_u_7, (ref) v_u_5, (ref) v_u_3, (copy) v_u_344, (ref) v_u_179, (copy) v_u_333
	if not v_u_19 and (v_u_16 and (v_u_7 and v_u_5)) then
		local v345 = v_u_5.color
		local v346
		if v_u_5 then
			local v347 = v_u_5.isPhone
			if type(v347) == "function" then
				local v348 = v_u_5.isPhone
				local v349
				v346, v349 = pcall(v348)
				if v346 then
					v346 = v349 == true
				end
			else
				v346 = false
			end
		else
			v346 = false
		end
		local v350 = v_u_5.touch
		local v351 = type(v350) ~= "function" and 40 or v_u_5.touch(40)
		local v352 = v346 and 600 or 680
		local v353 = math.max(64, v351) + 32
		local v354, v355 = v_u_7.panel({
			["parent"] = nil,
			["name"] = "Spectate",
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["accent"] = nil,
			["padding"] = 16,
			["parent"] = v_u_16,
			["size"] = UDim2.fromOffset(v352, v353),
			["position"] = UDim2.new(0.5, 0, 1, -(v346 and 24 or 136)),
			["anchor"] = Vector2.new(0.5, 1),
			["accent"] = v345.danger
		})
		local v356 = v352 - 32 - 208 - 128 - 8 - 24
		local v357 = Instance.new("Frame")
		v357.Name = "Who"
		v357.BackgroundTransparency = 1
		v357.AnchorPoint = Vector2.new(0, 0.5)
		v357.Position = UDim2.fromScale(0, 0.5)
		v357.Size = UDim2.fromOffset(v356, 64)
		v357.Parent = v355
		local v358 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Head",
			["text"] = "Killed in action",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v357,
			["color"] = v345.danger,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
		local v359 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = "",
			["style"] = "h2",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v357,
			["size"] = UDim2.new(1, 0, 0, 28),
			["position"] = UDim2.fromOffset(0, 18)
		})
		local v360 = v_u_7.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v357,
			["size"] = UDim2.new(1, 0, 0, 16),
			["position"] = UDim2.fromOffset(0, 48)
		})
		v_u_7.button({
			["parent"] = nil,
			["name"] = "Leave",
			["text"] = "Return to menu",
			["kind"] = "secondary",
			["width"] = 208,
			["height"] = 40,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v355,
			["position"] = UDim2.new(1, 0, 0.5, 0),
			["anchor"] = Vector2.new(1, 0.5),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_3
				local v361 = v_u_3.net.fire
				pcall(v361, "raid.op", {
					["op"] = "leave"
				})
			end
		})
		local v362 = v_u_7.button({
			["parent"] = nil,
			["name"] = "Next",
			["text"] = "Next",
			["kind"] = "ghost",
			["hint"] = "swap",
			["width"] = 128,
			["height"] = 40,
			["position"] = nil,
			["anchor"] = nil,
			["onClick"] = nil,
			["parent"] = v355,
			["position"] = UDim2.new(1, -216, 0.5, 0),
			["anchor"] = Vector2.new(1, 0.5),
			["onClick"] = v_u_344
		})
		if v_u_7.animateIn and not v_u_179 then
			local v363 = v_u_7.animateIn
			pcall(v363, v354)
		end
		v_u_19 = {
			["frame"] = v354,
			["head"] = v358,
			["name"] = v359,
			["sub"] = v360,
			["next"] = v362
		}
		v_u_333()
	end
end
local function v_u_372(p365) -- name: lockTouchInput
	-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_181
	local v366 = v_u_3
	if v366 then
		v366 = v_u_3.controllers.Input
	end
	if not v366 or v366._broken then
		v366 = nil
	end
	if v366 then
		local v367 = v366.setEnabled
		if type(v367) == "function" then
			if p365 then
				local v368 = v_u_5
				if v368 then
					local v369 = v_u_5.isTouch
					if type(v369) == "function" then
						v368 = v_u_5.isTouch()
					else
						v368 = false
					end
				end
				if v368 and not v_u_181 then
					v_u_181 = true
					local v370 = v366.setEnabled
					pcall(v370, false)
					return
				end
			elseif v_u_181 then
				v_u_181 = false
				local v371 = v366.setEnabled
				pcall(v371, true)
			end
			return
		end
	end
end
local function v_u_380() -- name: onStatus
	-- upvalues: (copy) v_u_4, (ref) v_u_28, (ref) v_u_25, (ref) v_u_180, (copy) v_u_39, (ref) v_u_17, (ref) v_u_18, (copy) v_u_364, (ref) v_u_3, (ref) v_u_5, (ref) v_u_181, (copy) v_u_316, (ref) v_u_27, (copy) v_u_342
	local v373 = v_u_4:GetAttribute("RaidStatus")
	if v373 ~= v_u_28 then
		v_u_28 = type(v373) ~= "string" and "" or v373
		if v373 == "Dead" and (v_u_25 and v_u_4:GetAttribute("HuntPlayer") ~= true) then
			v_u_180 = os.clock()
			v_u_39("ui", "death")
			if v_u_17 then
				v_u_17.holder.Visible = false
			end
			if v_u_18 then
				v_u_18.frame.Visible = false
			end
			v_u_364()
			local v374 = v_u_3
			if v374 then
				v374 = v_u_3.controllers.Input
			end
			if not v374 or v374._broken then
				v374 = nil
			end
			if v374 then
				local v375 = v374.setEnabled
				if type(v375) == "function" then
					local v376 = v_u_5
					if v376 then
						local v377 = v_u_5.isTouch
						if type(v377) == "function" then
							v376 = v_u_5.isTouch()
						else
							v376 = false
						end
					end
					if v376 and not v_u_181 then
						v_u_181 = true
						local v378 = v374.setEnabled
						pcall(v378, false)
					end
				end
			end
			local v379 = v_u_316()
			v_u_27 = 1
			v_u_342(v379[1])
		end
	end
end
local function v_u_385() -- name: updateSpectate
	-- upvalues: (ref) v_u_28, (ref) v_u_26, (copy) v_u_1, (copy) v_u_316, (copy) v_u_342, (copy) v_u_333
	if v_u_28 == "Dead" then
		local v381 = v_u_26
		local v382
		if v381 and v381.Parent then
			local v383 = v_u_1:GetPlayerFromCharacter(v381)
			if v383 then
				v383 = v383:GetAttribute("RaidStatus")
			end
			v382 = v383 == "Alive" and true or v383 == "Downed"
		else
			v382 = false
		end
		if not v382 then
			local v384 = v_u_316()
			if v384[1] ~= v381 then
				v_u_342(v384[1])
				return
			end
		end
		v_u_333()
	end
end
local function v_u_390() -- name: rebuildUi
	-- upvalues: (ref) v_u_25, (ref) v_u_19, (ref) v_u_17, (ref) v_u_15, (ref) v_u_16, (ref) v_u_18, (copy) v_u_272, (ref) v_u_20, (copy) v_u_295, (ref) v_u_179, (copy) v_u_364
	if v_u_25 then
		local v386 = v_u_19 ~= nil
		local v387 = not v_u_17 and 0 or v_u_17.doneAt
		if v_u_15 then
			v_u_15:Destroy()
		end
		v_u_15 = nil
		v_u_16 = nil
		v_u_17 = nil
		v_u_18 = nil
		v_u_19 = nil
		v_u_272()
		if v_u_17 and v_u_20 then
			v_u_295(v_u_20, v_u_20, true)
			v_u_17.doneAt = v387
			if v_u_20.state == "done" and (v387 == 0 and (not v_u_179 and v_u_17)) then
				v_u_17.holder.Visible = false
			end
		end
		if v386 or (v_u_179 == "spectate" or v_u_179 == "dead") then
			v_u_364()
		end
		if v_u_179 and (v_u_17 and (v_u_179 == "progress" or (v_u_179 == "interrupted" or v_u_179 == "done"))) then
			local v388 = v_u_179 == "progress" and 0.42 or (v_u_179 == "interrupted" and 0.18 or 1)
			local v389 = v_u_17.ring.set
			pcall(v389, v388)
			v_u_17.secs.Text = string.format("%.1f", (1 - v388) * 8)
		end
	end
end
local v_u_391 = {
	["progress"] = "Storm Drain",
	["interrupted"] = "Storm Drain",
	["blocked"] = "Storm Drain",
	["done"] = "Smuggler\'s Boat"
}
local function v_u_396(p392) -- name: preview
	-- upvalues: (ref) v_u_25, (ref) v_u_179, (ref) v_u_20, (ref) v_u_3, (ref) v_u_181, (ref) v_u_19, (copy) v_u_390, (copy) v_u_391, (copy) v_u_372, (copy) v_u_31, (ref) v_u_180
	if not v_u_25 then
		return "not in a raid"
	end
	if p392 ~= "off" then
		if p392 ~= "spectate" and (p392 ~= "dead" and not v_u_391[p392]) then
			return "states: progress interrupted blocked done spectate dead off"
		end
		v_u_179 = p392
		v_u_372(p392 == "spectate" and true or p392 == "dead")
		if v_u_19 and (p392 ~= "spectate" and p392 ~= "dead") then
			v_u_19.frame:Destroy()
			v_u_19 = nil
		end
		if v_u_391[p392] then
			v_u_20 = {
				["id"] = nil,
				["name"] = nil,
				["state"] = nil,
				["startedAt"] = nil,
				["duration"] = 8,
				["reason"] = nil,
				["id"] = p392 == "done" and "smuggler_boat" or "sewer",
				["name"] = v_u_391[p392],
				["state"] = p392,
				["startedAt"] = v_u_31.now(),
				["reason"] = p392 == "blocked" and "Too tight with a backpack" or nil
			}
		else
			v_u_20 = nil
			v_u_180 = os.clock()
		end
		v_u_390()
		return "preview " .. p392
	end
	v_u_179 = nil
	v_u_20 = nil
	local v393 = v_u_3
	if v393 then
		v393 = v_u_3.controllers.Input
	end
	if not v393 or v393._broken then
		v393 = nil
	end
	if v393 then
		local v394 = v393.setEnabled
		if type(v394) == "function" and v_u_181 then
			v_u_181 = false
			local v395 = v393.setEnabled
			pcall(v395, true)
		end
	end
	if v_u_19 then
		v_u_19.frame:Destroy()
		v_u_19 = nil
	end
	v_u_390()
	return "preview off"
end
local function v_u_459() -- name: heliModel
	-- upvalues: (ref) v_u_3
	local v397 = v_u_3.shared.Assets.get
	local v398, v399 = pcall(v397, "Vehicle", "Heli")
	if v398 and (typeof(v399) == "Instance" and v399:IsA("Model")) then
		local v400 = string.find(v399.Name, "_MISSING", 1, true) ~= nil
		for _, v401 in v399:GetDescendants() do
			if not string.find(v401.Name, "_MISSING", 1, true) then
				continue
			end
			v400 = true
		end
		if not v400 then
			for _, v402 in v399:GetDescendants() do
				if not v402:IsA("BasePart") then
					continue
				end
				v402.Anchored = true
				v402.CanCollide = false
				v402.CanQuery = false
				v402.CanTouch = false
			end
			return v399
		end
		v399:Destroy()
	end
	local v403 = Instance.new("Model")
	v403.Name = "Heli"
	local v404 = Color3.fromRGB(58, 62, 50)
	local v405 = Color3.fromRGB(28, 29, 30)
	local v406 = CFrame.new(0, 4.6, 0)
	local v407 = Enum.Material.Metal
	local v408 = Instance.new("Part")
	v408.Name = "Body"
	v408.Anchored = true
	v408.CanCollide = false
	v408.CanQuery = false
	v408.CanTouch = false
	v408.Size = Vector3.new(6.5, 6, 13)
	v408.CFrame = v406
	v408.Color = v404
	v408.Material = v407 or Enum.Material.Metal
	v408.TopSurface = Enum.SurfaceType.Smooth
	v408.BottomSurface = Enum.SurfaceType.Smooth
	v408.Parent = v403
	local v409 = CFrame.new(0, 4.4, -7.6)
	local v410 = Enum.Material.Metal
	local v411 = Instance.new("Part")
	v411.Name = "Nose"
	v411.Anchored = true
	v411.CanCollide = false
	v411.CanQuery = false
	v411.CanTouch = false
	v411.Size = Vector3.new(6.2, 4.4, 3.5)
	v411.CFrame = v409
	v411.Color = v404
	v411.Material = v410 or Enum.Material.Metal
	v411.TopSurface = Enum.SurfaceType.Smooth
	v411.BottomSurface = Enum.SurfaceType.Smooth
	v411.Parent = v403
	local v412 = CFrame.new(0, 5.6, -8.4) * CFrame.Angles(-0.3490658503988659, 0, 0)
	local v413 = Color3.fromRGB(34, 44, 52)
	local v414 = Enum.Material.Glass
	local v415 = Instance.new("Part")
	v415.Name = "Canopy"
	v415.Anchored = true
	v415.CanCollide = false
	v415.CanQuery = false
	v415.CanTouch = false
	v415.Size = Vector3.new(5.6, 2.6, 2.2)
	v415.CFrame = v412
	v415.Color = v413
	v415.Material = v414 or Enum.Material.Metal
	v415.TopSurface = Enum.SurfaceType.Smooth
	v415.BottomSurface = Enum.SurfaceType.Smooth
	v415.Parent = v403
	v415.Transparency = 0.25
	local v416 = CFrame.new(0, 6.2, 13.5)
	local v417 = Enum.Material.Metal
	local v418 = Instance.new("Part")
	v418.Name = "Tail"
	v418.Anchored = true
	v418.CanCollide = false
	v418.CanQuery = false
	v418.CanTouch = false
	v418.Size = Vector3.new(1.6, 1.8, 15)
	v418.CFrame = v416
	v418.Color = v404
	v418.Material = v417 or Enum.Material.Metal
	v418.TopSurface = Enum.SurfaceType.Smooth
	v418.BottomSurface = Enum.SurfaceType.Smooth
	v418.Parent = v403
	local v419 = CFrame.new(0, 8, 20.6)
	local v420 = Enum.Material.Metal
	local v421 = Instance.new("Part")
	v421.Name = "Fin"
	v421.Anchored = true
	v421.CanCollide = false
	v421.CanQuery = false
	v421.CanTouch = false
	v421.Size = Vector3.new(0.4, 4.2, 2.4)
	v421.CFrame = v419
	v421.Color = v404
	v421.Material = v420 or Enum.Material.Metal
	v421.TopSurface = Enum.SurfaceType.Smooth
	v421.BottomSurface = Enum.SurfaceType.Smooth
	v421.Parent = v403
	local v422 = CFrame.new(0, 8.1, -0.5)
	local v423 = Enum.Material.Metal
	local v424 = Instance.new("Part")
	v424.Name = "Engine"
	v424.Anchored = true
	v424.CanCollide = false
	v424.CanQuery = false
	v424.CanTouch = false
	v424.Size = Vector3.new(4, 1.4, 3)
	v424.CFrame = v422
	v424.Color = v405
	v424.Material = v423 or Enum.Material.Metal
	v424.TopSurface = Enum.SurfaceType.Smooth
	v424.BottomSurface = Enum.SurfaceType.Smooth
	v424.Parent = v403
	for _, v425 in { -2.9, 2.9 } do
		local v426 = CFrame.new(v425, 0.3, -0.5)
		local v427 = Enum.Material.Metal
		local v428 = Instance.new("Part")
		v428.Name = "Skid"
		v428.Anchored = true
		v428.CanCollide = false
		v428.CanQuery = false
		v428.CanTouch = false
		v428.Size = Vector3.new(0.35, 0.35, 12)
		v428.CFrame = v426
		v428.Color = v405
		v428.Material = v427 or Enum.Material.Metal
		v428.TopSurface = Enum.SurfaceType.Smooth
		v428.BottomSurface = Enum.SurfaceType.Smooth
		v428.Parent = v403
		local v429 = CFrame.new(v425, 1.2, -3.5)
		local v430 = Enum.Material.Metal
		local v431 = Instance.new("Part")
		v431.Name = "Strut"
		v431.Anchored = true
		v431.CanCollide = false
		v431.CanQuery = false
		v431.CanTouch = false
		v431.Size = Vector3.new(0.3, 1.8, 0.3)
		v431.CFrame = v429
		v431.Color = v405
		v431.Material = v430 or Enum.Material.Metal
		v431.TopSurface = Enum.SurfaceType.Smooth
		v431.BottomSurface = Enum.SurfaceType.Smooth
		v431.Parent = v403
		local v432 = CFrame.new(v425, 1.2, 2.5)
		local v433 = Enum.Material.Metal
		local v434 = Instance.new("Part")
		v434.Name = "Strut"
		v434.Anchored = true
		v434.CanCollide = false
		v434.CanQuery = false
		v434.CanTouch = false
		v434.Size = Vector3.new(0.3, 1.8, 0.3)
		v434.CFrame = v432
		v434.Color = v405
		v434.Material = v433 or Enum.Material.Metal
		v434.TopSurface = Enum.SurfaceType.Smooth
		v434.BottomSurface = Enum.SurfaceType.Smooth
		v434.Parent = v403
	end
	local v435 = Instance.new("Model")
	v435.Name = "Rotor"
	local v436 = CFrame.new(0, 9.3, -0.5)
	local v437 = Enum.Material.Metal
	local v438 = Instance.new("Part")
	v438.Name = "Hub"
	v438.Anchored = true
	v438.CanCollide = false
	v438.CanQuery = false
	v438.CanTouch = false
	v438.Size = Vector3.new(0.8, 0.6, 0.8)
	v438.CFrame = v436
	v438.Color = v405
	v438.Material = v437 or Enum.Material.Metal
	v438.TopSurface = Enum.SurfaceType.Smooth
	v438.BottomSurface = Enum.SurfaceType.Smooth
	v438.Parent = v435
	for v439 = 0, 3 do
		local v440 = v439 * 3.141592653589793 / 2
		local v441 = CFrame.new(0, 9.4, -0.5) * CFrame.Angles(0, v440, 0) * CFrame.new(0, 0, 7.6)
		local v442 = Enum.Material.Metal
		local v443 = Instance.new("Part")
		v443.Name = "Blade"
		v443.Anchored = true
		v443.CanCollide = false
		v443.CanQuery = false
		v443.CanTouch = false
		v443.Size = Vector3.new(0.9, 0.12, 15)
		v443.CFrame = v441
		v443.Color = v405
		v443.Material = v442 or Enum.Material.Metal
		v443.TopSurface = Enum.SurfaceType.Smooth
		v443.BottomSurface = Enum.SurfaceType.Smooth
		v443.Parent = v435
	end
	v435.PrimaryPart = v438
	v435.Parent = v403
	local v444 = Instance.new("Model")
	v444.Name = "TailRotor"
	local v445 = CFrame.new(0.5, 8.4, 20.8)
	local v446 = Enum.Material.Metal
	local v447 = Instance.new("Part")
	v447.Name = "Hub"
	v447.Anchored = true
	v447.CanCollide = false
	v447.CanQuery = false
	v447.CanTouch = false
	v447.Size = Vector3.new(0.3, 0.3, 0.3)
	v447.CFrame = v445
	v447.Color = v405
	v447.Material = v446 or Enum.Material.Metal
	v447.TopSurface = Enum.SurfaceType.Smooth
	v447.BottomSurface = Enum.SurfaceType.Smooth
	v447.Parent = v444
	for v448 = 0, 1 do
		local v449 = CFrame.new(0.5, 8.4, 20.8) * CFrame.Angles(v448 * 3.141592653589793 / 2, 0, 0)
		local v450 = Enum.Material.Metal
		local v451 = Instance.new("Part")
		v451.Name = "Blade"
		v451.Anchored = true
		v451.CanCollide = false
		v451.CanQuery = false
		v451.CanTouch = false
		v451.Size = Vector3.new(0.1, 3.6, 0.35)
		v451.CFrame = v449
		v451.Color = v405
		v451.Material = v450 or Enum.Material.Metal
		v451.TopSurface = Enum.SurfaceType.Smooth
		v451.BottomSurface = Enum.SurfaceType.Smooth
		v451.Parent = v444
	end
	v444.PrimaryPart = v447
	v444.Parent = v403
	local v452 = CFrame.new(0, 10.3, 20.8)
	local v453 = Color3.fromRGB(255, 60, 50)
	local v454 = Enum.Material.Neon
	local v455 = Instance.new("Part")
	v455.Name = "NavLight"
	v455.Anchored = true
	v455.CanCollide = false
	v455.CanQuery = false
	v455.CanTouch = false
	v455.Size = Vector3.new(0.3, 0.3, 0.3)
	v455.CFrame = v452
	v455.Color = v453
	v455.Material = v454 or Enum.Material.Metal
	v455.TopSurface = Enum.SurfaceType.Smooth
	v455.BottomSurface = Enum.SurfaceType.Smooth
	v455.Parent = v403
	local v456 = Instance.new("PointLight")
	v456.Color = Color3.fromRGB(255, 60, 50)
	v456.Range = 10
	v456.Brightness = 2
	v456.Parent = v455
	v403.PrimaryPart = v408
	local v457 = CFrame.new(0, 0, 0)
	local v458 = v403.PrimaryPart
	if v458 then
		v458.PivotOffset = v458.CFrame:ToObjectSpace(v457)
	end
	v403.WorldPivot = v457
	return v403
end
local function v_u_476(p460, p461) -- name: rigHeli
	-- upvalues: (copy) v_u_459, (copy) v_u_39
	local v462 = v_u_459()
	local v463 = v462:GetPivot()
	local v464 = {}
	for _, v465 in v462:GetDescendants() do
		if not (v465:IsA("BasePart") or v465:IsA("Model")) then
			continue
		end
		local v466 = v465.Name
		local v467 = string.sub(v466, 1, 9) == "TailRotor"
		if not v467 and (string.sub(v466, 1, 5) ~= "Rotor" and string.sub(v466, 1, 9) ~= "MainRotor") then
			continue
		end
		local v468 = v465.Parent
		if v468 and (v468 ~= v462 and v468:IsA("Model")) then
			local v469 = v468.Name
			if string.sub(v469, 1, 5) == "Rotor" or (string.sub(v469, 1, 9) == "MainRotor" or string.sub(v469, 1, 9) == "TailRotor") then
				continue
			end
		end
		local v470
		if v465:IsA("Model") then
			v470 = v465:GetPivot()
		else
			v470 = v465.CFrame
		end
		local v471 = {
			["inst"] = v465,
			["offset"] = v463:ToObjectSpace(v470),
			["speed"] = v467 and 38 or 24,
			["axis"] = v467 and "X" or "Y"
		}
		table.insert(v464, v471)
	end
	local v472 = {
		["model"] = nil,
		["rotors"] = nil,
		["light"] = nil,
		["lightPart"] = nil,
		["sound"] = nil,
		["spin"] = 0,
		["model"] = v462,
		["rotors"] = v464
	}
	if p461 then
		local v473 = v463 * CFrame.new(0, 1.5, -6)
		local v474 = Instance.new("Part")
		v474.Name = "Searchlight"
		v474.Anchored = true
		v474.CanCollide = false
		v474.CanQuery = false
		v474.CanTouch = false
		v474.CastShadow = false
		v474.Transparency = 1
		v474.Size = Vector3.new(0.2, 0.2, 0.2)
		v474.CFrame = v473
		v474.Parent = v462
		local v475 = Instance.new("SpotLight")
		v475.Face = Enum.NormalId.Front
		v475.Angle = 38
		v475.Range = 110
		v475.Brightness = 4
		v475.Color = Color3.fromRGB(255, 244, 222)
		v475.Shadows = true
		v475.Parent = v474
		v472.light = v475
		v472.lightPart = v474
	end
	v462.Parent = p460
	v472.sound = v_u_39("loop", "ev_heli_rotor", v462.PrimaryPart or v462:FindFirstChildWhichIsA("BasePart"))
	return v472
end
local function v_u_487(p477, p478, p479, p480) -- name: poseHeli
	p477.model:PivotTo(p478)
	p477.spin = p477.spin + p479
	for _, v481 in p477.rotors do
		local v482 = p477.spin * v481.speed
		local v483
		if v481.axis == "X" then
			v483 = CFrame.Angles(v482, 0, 0)
		else
			v483 = CFrame.Angles(0, v482, 0)
		end
		local v484 = p478 * v481.offset * v483
		if v481.inst:IsA("Model") then
			v481.inst:PivotTo(v484)
		else
			v481.inst.CFrame = v484
		end
	end
	if p477.lightPart then
		local v485 = p480 * 0.6
		local v486 = math.sin(v485) * 0.5
		p477.lightPart.CFrame = p478 * CFrame.new(0, 1.2, -6) * CFrame.Angles(-1.0821041362364843, v486, 0)
	end
end
local function v_u_496(p488, p489, p490) -- name: smoke
	-- upvalues: (ref) v_u_11
	local v491, v492 = CFrame.new(p489 + Vector3.new(0, 0.5, 0))
	local v493 = Instance.new("Part")
	v493.Name = "Smoke"
	v493.Anchored = true
	v493.CanCollide = false
	v493.CanQuery = false
	v493.CanTouch = false
	v493.CastShadow = false
	v493.Transparency = 1
	v493.Size = v492 or Vector3.new(0.2, 0.2, 0.2)
	v493.CFrame = v491
	v493.Parent = p488
	local v494 = Instance.new("ParticleEmitter")
	v494.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v494.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, p490), ColorSequenceKeypoint.new(0.4, p490:Lerp(Color3.fromRGB(90, 80, 80), 0.5)), ColorSequenceKeypoint.new(1, Color3.fromRGB(70, 70, 72)) })
	v494.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(1, 16) })
	v494.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(0.6, 0.7), NumberSequenceKeypoint.new(1, 1) })
	v494.Lifetime = NumberRange.new(7, 10)
	v494.Rate = 14
	v494.Speed = NumberRange.new(5, 8)
	v494.SpreadAngle = Vector2.new(12, 12)
	v494.Acceleration = Vector3.new(2.5, 1.2, 1.5)
	v494.RotSpeed = NumberRange.new(-20, 20)
	v494.Rotation = NumberRange.new(0, 360)
	v494.LightEmission = 0.05
	v494.LightInfluence = 0.8
	local v495 = v_u_11
	if v495 then
		v495 = v_u_11:GetAttribute("TimeOfDay")
	end
	if v495 == "Night" and true or v495 == "Dusk" then
		v494.LightInfluence = 0.3
		v494.LightEmission = 0.25
	end
	v494.Parent = v493
	return v493, v494
end
local function v_u_513(p497, p498) -- name: lightPillar
	local v499, v500 = CFrame.new(p498 + Vector3.new(0, 0.6, 0))
	local v_u_501 = Instance.new("Part")
	v_u_501.Name = "DropPillar"
	v_u_501.Anchored = true
	v_u_501.CanCollide = false
	v_u_501.CanQuery = false
	v_u_501.CanTouch = false
	v_u_501.CastShadow = false
	v_u_501.Transparency = 1
	v_u_501.Size = v500 or Vector3.new(0.2, 0.2, 0.2)
	v_u_501.CFrame = v499
	v_u_501.Parent = p497
	local v_u_502 = Instance.new("Attachment")
	v_u_502.Name = "Bottom"
	v_u_502.Parent = v_u_501
	local v_u_503 = Instance.new("Attachment")
	v_u_503.Name = "Top"
	v_u_503.Position = Vector3.new(0, 160, 0)
	v_u_503.Parent = v_u_501
	local v_u_504 = Color3.fromRGB(255, 62, 48)
	local function v511(p505, p506, p507, p508, p509) -- name: beam
		-- upvalues: (copy) v_u_502, (copy) v_u_503, (copy) v_u_504, (copy) v_u_501
		local v510 = Instance.new("Beam")
		v510.Name = p505
		v510.Attachment0 = v_u_502
		v510.Attachment1 = v_u_503
		v510.Color = ColorSequence.new(v_u_504)
		v510.LightEmission = 1
		v510.LightInfluence = 0
		v510.FaceCamera = true
		v510.Segments = 1
		v510.Width0 = p506
		v510.Width1 = p507
		v510.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, p508), NumberSequenceKeypoint.new(0.55, (p508 + p509) / 2), NumberSequenceKeypoint.new(1, 1) })
		v510.Parent = v_u_501
		return v510
	end
	v511("Core", 1.6, 0.8, 0.15, 0.6)
	v511("Glow", 7, 3, 0.7, 0.9)
	local v512 = Instance.new("PointLight")
	v512.Name = "Glow"
	v512.Color = v_u_504
	v512.Range = 18
	v512.Brightness = 2.5
	v512.Shadows = false
	v512.Parent = v_u_501
	return v_u_501
end
local function v_u_521(p514, p515) -- name: flareLight
	local v516, v517 = CFrame.new(p515 + Vector3.new(0, 0.4, 0))
	local v518 = Instance.new("Part")
	v518.Name = "Flare"
	v518.Anchored = true
	v518.CanCollide = false
	v518.CanQuery = false
	v518.CanTouch = false
	v518.CastShadow = false
	v518.Transparency = 1
	v518.Size = v517 or Vector3.new(0.2, 0.2, 0.2)
	v518.CFrame = v516
	v518.Parent = p514
	local v519 = Instance.new("PointLight")
	v519.Name = "Glow"
	v519.Color = Color3.fromRGB(255, 70, 50)
	v519.Range = 26
	v519.Brightness = 3
	v519.Shadows = true
	v519.Parent = v518
	local v520 = Instance.new("ParticleEmitter")
	v520.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v520.Color = ColorSequence.new(Color3.fromRGB(255, 120, 90))
	v520.Size = NumberSequence.new(0.35, 0)
	v520.Lifetime = NumberRange.new(0.3, 0.6)
	v520.Rate = 40
	v520.Speed = NumberRange.new(3, 6)
	v520.SpreadAngle = Vector2.new(35, 35)
	v520.LightEmission = 1
	v520.Parent = v518
	return v518
end
local function v_u_562(p522) -- name: parachuteRig
	local v523 = Instance.new("Model")
	v523.Name = "Airdrop"
	local v524 = CFrame.new(0, 1.8, 0)
	local v525 = Color3.fromRGB(74, 78, 56)
	local v526 = Enum.Material.WoodPlanks
	local v527 = Instance.new("Part")
	v527.Name = "Crate"
	v527.Anchored = true
	v527.CanCollide = false
	v527.CanQuery = false
	v527.CanTouch = false
	v527.Size = Vector3.new(5, 3.6, 3.6)
	v527.CFrame = v524
	v527.Color = v525
	v527.Material = v526 or Enum.Material.Metal
	v527.TopSurface = Enum.SurfaceType.Smooth
	v527.BottomSurface = Enum.SurfaceType.Smooth
	v527.Parent = v523
	local v528 = CFrame.new(-1.9, 1.8, 0)
	local v529 = Color3.fromRGB(46, 47, 44)
	local v530 = Enum.Material.DiamondPlate
	local v531 = Instance.new("Part")
	v531.Name = "Band"
	v531.Anchored = true
	v531.CanCollide = false
	v531.CanQuery = false
	v531.CanTouch = false
	v531.Size = Vector3.new(0.25, 3.7, 3.75)
	v531.CFrame = v528
	v531.Color = v529
	v531.Material = v530 or Enum.Material.Metal
	v531.TopSurface = Enum.SurfaceType.Smooth
	v531.BottomSurface = Enum.SurfaceType.Smooth
	v531.Parent = v523
	local v532 = CFrame.new(1.9, 1.8, 0)
	local v533 = Color3.fromRGB(46, 47, 44)
	local v534 = Enum.Material.DiamondPlate
	local v535 = Instance.new("Part")
	v535.Name = "Band"
	v535.Anchored = true
	v535.CanCollide = false
	v535.CanQuery = false
	v535.CanTouch = false
	v535.Size = Vector3.new(0.25, 3.7, 3.75)
	v535.CFrame = v532
	v535.Color = v533
	v535.Material = v534 or Enum.Material.Metal
	v535.TopSurface = Enum.SurfaceType.Smooth
	v535.BottomSurface = Enum.SurfaceType.Smooth
	v535.Parent = v523
	local v536 = CFrame.new(0, 17, 0)
	local v537 = Color3.fromRGB(182, 170, 142)
	local v538 = Enum.Material.Fabric
	local v539 = Instance.new("Part")
	v539.Name = "Canopy"
	v539.Anchored = true
	v539.CanCollide = false
	v539.CanQuery = false
	v539.CanTouch = false
	v539.Size = Vector3.new(18, 6, 18)
	v539.CFrame = v536
	v539.Color = v537
	v539.Material = v538 or Enum.Material.Metal
	v539.TopSurface = Enum.SurfaceType.Smooth
	v539.BottomSurface = Enum.SurfaceType.Smooth
	v539.Parent = v523
	local v540 = Instance.new("SpecialMesh")
	v540.MeshType = Enum.MeshType.Sphere
	v540.Parent = v539
	v539.CastShadow = true
	for _, v541 in {
		Vector3.new(-7, 0, -7),
		Vector3.new(7, 0, -7),
		Vector3.new(-7, 0, 7),
		Vector3.new(7, 0, 7)
	} do
		local v542 = v541.X
		local v543 = v541.Z
		local v544 = Vector3.new(v542, 15.5, v543)
		local v545 = v541.X * 0.25
		local v546 = v541.Z * 0.25
		local v547 = Vector3.new(v545, 3.6, v546)
		local v548 = (v544 + v547) / 2
		local v549 = (v544 - v547).Magnitude
		local v550 = Vector3.new(0.08, 0.08, v549)
		local v551 = CFrame.lookAt(v548, v544)
		local v552 = Color3.fromRGB(60, 58, 52)
		local v553 = Enum.Material.Fabric
		local v554 = Instance.new("Part")
		v554.Name = "Rope"
		v554.Anchored = true
		v554.CanCollide = false
		v554.CanQuery = false
		v554.CanTouch = false
		v554.Size = v550
		v554.CFrame = v551
		v554.Color = v552
		v554.Material = v553 or Enum.Material.Metal
		v554.TopSurface = Enum.SurfaceType.Smooth
		v554.BottomSurface = Enum.SurfaceType.Smooth
		v554.Parent = v523
		v554.CastShadow = false
	end
	local v555 = CFrame.new(1.8, 3.8, 1.2)
	local v556 = Color3.fromRGB(255, 80, 60)
	local v557 = Enum.Material.Neon
	local v558 = Instance.new("Part")
	v558.Name = "Strobe"
	v558.Anchored = true
	v558.CanCollide = false
	v558.CanQuery = false
	v558.CanTouch = false
	v558.Size = Vector3.new(0.35, 0.35, 0.35)
	v558.CFrame = v555
	v558.Color = v556
	v558.Material = v557 or Enum.Material.Metal
	v558.TopSurface = Enum.SurfaceType.Smooth
	v558.BottomSurface = Enum.SurfaceType.Smooth
	v558.Parent = v523
	local v559 = Instance.new("PointLight")
	v559.Color = Color3.fromRGB(255, 90, 70)
	v559.Range = 14
	v559.Brightness = 2
	v559.Parent = v558
	v523.PrimaryPart = v527
	local v560 = CFrame.new(0, 0, 0)
	local v561 = v523.PrimaryPart
	if v561 then
		v561.PivotOffset = v561.CFrame:ToObjectSpace(v560)
	end
	v523.WorldPivot = v560
	v523.Parent = p522
	return v523
end
local function v_u_600(p563) -- name: startEventVisual
	-- upvalues: (copy) v_u_14, (ref) v_u_12, (ref) v_u_6, (copy) v_u_31, (copy) v_u_476, (ref) v_u_11, (copy) v_u_521, (copy) v_u_496, (copy) v_u_39, (copy) v_u_562
	if v_u_14[p563] or not v_u_12 then
		return
	else
		local v564 = p563:GetAttribute("Kind")
		local v565 = {
			["folder"] = p563,
			["kind"] = v564,
			["parts"] = {},
			["sounds"] = {}
		}
		v_u_14[p563] = v565
		if v564 == "helicopter" then
			v565.path = v_u_6.decodePath((p563:GetAttribute("Path")))
			v565.speed = tonumber(p563:GetAttribute("Speed")) or 38
			v565.startAt = tonumber(p563:GetAttribute("StartAt")) or v_u_31.now()
			v565.endAt = tonumber(p563:GetAttribute("EndAt")) or v565.startAt + 120
			local v566 = v_u_476
			local v567 = v_u_12
			local v568 = v_u_11
			if v568 then
				v568 = v_u_11:GetAttribute("TimeOfDay")
			end
			v565.rig = v566(v567, v568 == "Night" and true or v568 == "Dusk")
			v565.bank = 0
			return
		elseif v564 == "extract_heli" then
			local v569 = p563:GetAttribute("Pad")
			v565.pad = typeof(v569) ~= "Vector3" and Vector3.new(0, 0, 0) or v569
			v565.startAt = tonumber(p563:GetAttribute("StartAt")) or v_u_31.now()
			v565.arriveAt = tonumber(p563:GetAttribute("ArriveAt")) or v565.startAt + 60
			v565.leaveAt = tonumber(p563:GetAttribute("LeaveAt")) or v565.arriveAt + 45
			local v570 = v565.pad.X * 13.7 + v565.pad.Z * 7.3
			local v571 = math.abs(v570) % 360
			local v572 = math.rad(v571)
			local v573 = math.cos(v572)
			local v574 = math.rad(v571)
			local v575 = math.sin(v574)
			v565.dir = Vector3.new(v573, 0, v575)
			local v576 = v_u_521(v_u_12, v565.pad)
			local v577 = v565.parts
			table.insert(v577, v576)
			local v578 = p563:GetAttribute("Tint")
			local v579 = v_u_496
			local v580 = v_u_12
			local v581 = v565.pad
			if typeof(v578) ~= "Color3" then
				v578 = Color3.fromRGB(220, 60, 48)
			end
			local v582 = v579(v580, v581, v578)
			local v583 = v565.parts
			table.insert(v583, v582)
			v_u_39("play3D", "ev_flare_ignite", v565.pad)
			local v584 = v565.sounds
			local v585 = v_u_39
			table.insert(v584, v585("loop", "ev_flare_loop", v576))
		elseif v564 == "airdrop" then
			local v586 = p563:GetAttribute("Position")
			v565.pos = typeof(v586) ~= "Vector3" and Vector3.new(0, 0, 0) or v586
			v565.startAt = tonumber(p563:GetAttribute("StartAt")) or v_u_31.now()
			v565.landAt = tonumber(p563:GetAttribute("LandAt")) or v565.startAt + 26
			v565.endAt = tonumber(p563:GetAttribute("EndAt")) or v565.landAt + 150
			v565.alt = tonumber(p563:GetAttribute("Altitude")) or 260
			if v_u_31.now() < v565.landAt then
				v565.rig = v_u_562(v_u_12)
				local v587 = v_u_39
				local v588 = v565.pos
				local v589 = v565.alt
				if not v587("play3D", "ev_plane", v588 + Vector3.new(0, v589, 0)) then
					local v590 = v_u_39
					local v591 = v565.pos
					local v592 = v565.alt
					v590("play3D", "ev_heli_flyby", v591 + Vector3.new(0, v592, 0))
					return
				end
			end
		else
			if v564 == "horde" then
				v565.path = v_u_6.decodePath((p563:GetAttribute("Path")))
				v565.speed = tonumber(p563:GetAttribute("Speed")) or 6.5
				v565.startAt = tonumber(p563:GetAttribute("StartAt")) or v_u_31.now()
				v565.endAt = tonumber(p563:GetAttribute("EndAt")) or v565.startAt + 120
				local v593 = v_u_12
				local v594, v595 = CFrame.new(v565.path[1] or Vector3.new(0, 0, 0))
				local v596 = Instance.new("Part")
				v596.Name = "HordeSource"
				v596.Anchored = true
				v596.CanCollide = false
				v596.CanQuery = false
				v596.CanTouch = false
				v596.CastShadow = false
				v596.Transparency = 1
				v596.Size = v595 or Vector3.new(0.2, 0.2, 0.2)
				v596.CFrame = v594
				v596.Parent = v593
				local v597 = v565.parts
				table.insert(v597, v596)
				v565.src = v596
				local v598 = v565.sounds
				local v599 = v_u_39
				table.insert(v598, v599("loop", "z_horde", v596))
				v_u_39("play3D", "amb_scream_far", v565.path[1] or Vector3.new(0, 0, 0))
				return
			end
			if v564 == "lift_heli" then
				v565.liftGiveUp = v_u_31.now() + 5
			end
		end
	end
end
local function v_u_620(p601) -- name: stopEventVisual
	-- upvalues: (copy) v_u_14, (ref) v_u_3
	local v602 = v_u_14[p601]
	if v602 then
		v_u_14[p601] = nil
		for _, v_u_603 in v602.sounds do
			if v_u_603 == nil then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_603
				local v604 = v_u_603
				if typeof(v604) == "Instance" then
					v_u_603:Destroy()
				else
					local v605 = v_u_603
					if type(v605) == "table" then
						local v606 = v_u_603.stop or v_u_603.Stop or (v_u_603.destroy or v_u_603.Destroy)
						if type(v606) == "function" then
							v606(v_u_603)
							return
						end
					else
						local v607 = v_u_603
						if type(v607) == "function" then
							v_u_603()
						end
					end
				end
			end)
		end
		if v602.kind == "helicopter" or v602.kind == "extract_heli" then
			local v608 = v602.rig
			if v608 then
				local v_u_609 = v608.sound
				if v_u_609 ~= nil then
					pcall(function()
						-- upvalues: (copy) v_u_609
						local v610 = v_u_609
						if typeof(v610) == "Instance" then
							v_u_609:Destroy()
						else
							local v611 = v_u_609
							if type(v611) == "table" then
								local v612 = v_u_609.stop or v_u_609.Stop or (v_u_609.destroy or v_u_609.Destroy)
								if type(v612) == "function" then
									v612(v_u_609)
									return
								end
							else
								local v613 = v_u_609
								if type(v613) == "function" then
									v_u_609()
								end
							end
						end
					end)
				end
				v608.model:Destroy()
			end
		elseif v602.rig then
			v602.rig:Destroy()
		end
		if v602.lift then
			local function v614()
				-- upvalues: (ref) v_u_3
				return v_u_3.lib.LiftHeliFx
			end
			local v615, v616 = pcall(v614)
			if not v615 or type(v616) ~= "table" then
				v616 = nil
			end
			if v616 then
				local v617 = v616.destroy
				local v618 = v602.lift
				pcall(v617, v618)
			end
			v602.lift = nil
		end
		if v602.pillar then
			v602.pillar:Destroy()
			v602.pillar = nil
		end
		for _, v619 in v602.parts do
			v619:Destroy()
		end
	end
end
local function v_u_726(p621) -- name: updateEvents
	-- upvalues: (copy) v_u_31, (copy) v_u_14, (ref) v_u_6, (copy) v_u_487, (copy) v_u_476, (ref) v_u_12, (ref) v_u_11, (copy) v_u_496, (copy) v_u_39, (copy) v_u_513, (ref) v_u_3, (copy) v_u_620
	local v622 = v_u_31.now()
	local v623 = {}
	for v624, v625 in v_u_14 do
		if v624.Parent then
			if v625.kind == "helicopter" and v625.rig then
				local v626 = (v622 - v625.startAt) * v625.speed
				local v627, v628 = v_u_6.pathSample(v625.path, v626)
				local v629 = v_u_6.pathSample(v625.path, v626 + 30)
				local v630 = v628.X
				local v631 = v628.Z
				local v632 = Vector3.new(v630, 0, v631)
				local v633 = v632.Magnitude < 0.01 and Vector3.new(0, 0, -1) or v632
				local v634 = v629.X - v627.X
				local v635 = v629.Z - v627.Z
				local v636 = Vector3.new(v634, 0, v635)
				local v637 = v636.Magnitude <= 0.1 and 0 or v633.Unit:Cross(v636.Unit).Y
				local v638 = v625.bank
				local v639 = v637 * 0.9
				local v640 = math.clamp(v639, -0.45, 0.45) - v625.bank
				local v641 = p621 * 2
				v625.bank = v638 + v640 * math.min(v641, 1)
				local v642 = CFrame.lookAt(v627, v627 + v633.Unit) * CFrame.Angles(-0.13962634015954636, 0, v625.bank)
				v_u_487(v625.rig, v642, p621, v622)
				if v625.endAt + 2 >= v622 then
					continue
				end
				table.insert(v623, v624)
			elseif v625.kind == "extract_heli" then
				if not v625.dirSet then
					local v643 = v624:GetAttribute("Dir")
					if typeof(v643) == "Vector3" then
						local v644 = v643.X
						local v645 = v643.Z
						if Vector3.new(v644, 0, v645).Magnitude > 0.01 then
							local v646 = v643.X
							local v647 = v643.Z
							v625.dir = Vector3.new(v646, 0, v647).Unit
							v625.dirSet = true
						end
					end
				end
				local v648
				if v625.arriveAt - 22 <= v622 then
					v648 = v622 <= v625.leaveAt + 22
				else
					v648 = false
				end
				if v648 and not v625.rig then
					local v649 = v_u_476
					local v650 = v_u_12
					local v651 = v_u_11
					if v651 then
						v651 = v_u_11:GetAttribute("TimeOfDay")
					end
					v625.rig = v649(v650, v651 == "Night" and true or v651 == "Dusk")
				elseif not v648 and v625.rig then
					local v652 = v625.rig
					if v652 then
						local v_u_653 = v652.sound
						if v_u_653 ~= nil then
							pcall(function()
								-- upvalues: (copy) v_u_653
								local v654 = v_u_653
								if typeof(v654) == "Instance" then
									v_u_653:Destroy()
								else
									local v655 = v_u_653
									if type(v655) == "table" then
										local v656 = v_u_653.stop or v_u_653.Stop or (v_u_653.destroy or v_u_653.Destroy)
										if type(v656) == "function" then
											v656(v_u_653)
											return
										end
									else
										local v657 = v_u_653
										if type(v657) == "function" then
											v_u_653()
										end
									end
								end
							end)
						end
						v652.model:Destroy()
					end
					v625.rig = nil
				end
				if v625.rig then
					local v658 = v625.pad
					local v659
					if v622 < v625.arriveAt then
						local v660 = (v625.arriveAt - v622) / 22
						local v661 = math.clamp(v660, 0, 1)
						local v662 = v661 * v661
						local v663 = v658 + v625.dir * (v662 * 520)
						local v664 = v662 * 110 + 4
						local v665 = v663 + Vector3.new(0, v664, 0)
						local v666 = CFrame.lookAt
						local v667 = v658.X
						local v668 = v665.Y
						local v669 = v658.Z
						local v670 = v666(v665, Vector3.new(v667, v668, v669) + Vector3.new(0.01, 0, 0))
						local v671 = CFrame.Angles
						local v672 = v661 * -10
						v659 = v670 * v671(math.rad(v672), 0, 0)
					elseif v622 < v625.leaveAt then
						local v673 = v622 * 1.3
						local v674 = math.sin(v673) * 0.25
						local v675 = CFrame.lookAt
						local v676 = v674 + 0.2
						v659 = v675(v658 + Vector3.new(0, v676, 0), v658 + Vector3.new(0, 0.2, 0) - v625.dir)
					else
						local v677 = (v622 - v625.leaveAt) / 22
						local v678 = math.clamp(v677, 0, 1)
						local v679 = v678 * v678
						local v680 = v658 - v625.dir * (v679 * 560)
						local v681 = v679 * 130 + 0.2
						local v682 = v680 + Vector3.new(0, v681, 0)
						local v683 = CFrame.lookAt(v682, v682 - v625.dir)
						local v684 = CFrame.Angles
						local v685 = v678 * 3
						local v686 = math.min(v685, 1) * -12
						v659 = v683 * v684(math.rad(v686), 0, 0)
					end
					v_u_487(v625.rig, v659, p621, v622)
				end
				if v625.leaveAt + 25 >= v622 then
					continue
				end
				table.insert(v623, v624)
			elseif v625.kind == "airdrop" then
				if v625.rig then
					if v625.landAt <= v622 then
						v625.rig:Destroy()
						v625.rig = nil
						v625.smoked = true
						local v687 = v_u_496(v_u_12, v625.pos, Color3.fromRGB(205, 52, 44))
						local v688 = v625.parts
						table.insert(v688, v687)
					else
						local v689 = v625.landAt - v622
						local v690 = v625.landAt - v625.startAt
						local v691 = v689 / math.max(v690, 1)
						local v692 = math.clamp(v691, 0, 1)
						local v693 = v622 * 0.9
						local v694 = math.sin(v693) * 0.12
						local v695 = v622 * 0.3
						local v696 = math.sin(v695) * 6 * v692
						local v697 = v622 * 0.23
						local v698 = math.cos(v697) * 6 * v692
						local v699 = Vector3.new(v696, 0, v698)
						local v700 = v625.pos
						local v701 = v625.alt * v692
						local v702 = v700 + Vector3.new(0, v701, 0) + v699
						v625.rig:PivotTo(CFrame.new(v702) * CFrame.Angles(v694, v622 * 0.1, v694 * 0.6))
					end
				elseif not v625.smoked and (v625.landAt <= v622 and v622 < v625.endAt) then
					v625.smoked = true
					local v703 = v_u_496(v_u_12, v625.pos, Color3.fromRGB(205, 52, 44))
					local v704 = v625.parts
					table.insert(v704, v703)
				end
				if v625.endAt < v622 then
					for _, v705 in v625.parts do
						v705:Destroy()
					end
					table.clear(v625.parts)
				end
				if v625.landAt > v622 then
					continue
				end
				if not v625.landFx then
					v625.landFx = true
					if v622 - v625.landAt < 4 then
						v_u_39("play3D", "ev_drop_land", v625.pos + Vector3.new(0, 1.5, 0))
					end
					v625.nextBeep = v622 + 1.2
				end
				local v706 = v625.folder:GetAttribute("Looted") == true
				if v706 or (v625.pillar or not v_u_12) then
					if v706 and v625.pillar then
						v625.pillar:Destroy()
						v625.pillar = nil
					end
				else
					v625.pillar = v_u_513(v_u_12, v625.pos)
				end
				if v625.pillar then
					local v707 = v622 * 3.2
					local v708 = math.sin(v707) * 0.5 + 0.5
					local v709 = v625.pillar:FindFirstChild("Glow")
					if v709 and v709:IsA("PointLight") then
						v709.Brightness = v708 * 2 + 1.5
					end
				end
				if v706 or ((v625.nextBeep or 0) > v622 or v622 >= v625.landAt + 150) then
					continue
				end
				v625.nextBeep = v622 + 3
				v_u_39("play3D", "ev_drop_beep", v625.pos + Vector3.new(0, 2, 0))
			elseif v625.kind == "lift_heli" then
				local function v710()
					-- upvalues: (ref) v_u_3
					return v_u_3.lib.LiftHeliFx
				end
				local v711, v712 = pcall(v710)
				if not v711 or type(v712) ~= "table" then
					v712 = nil
				end
				if v712 then
					if v625.lift then
						local v713 = v712.update
						local v714 = v625.lift
						local v715, v716 = pcall(v713, v714, p621, v622)
						if v715 then
							if not v716 then
								continue
							end
							table.insert(v623, v624)
						else
							warn("[RaidClient] cargo helicopter:", v716)
							table.insert(v623, v624)
						end
					else
						local v717 = v712.create
						local v718 = v_u_3
						local v719 = v_u_12
						local v720 = {}
						local v721 = v_u_11
						if v721 then
							v721 = v_u_11:GetAttribute("TimeOfDay")
						end
						v720.dark = v721 == "Night" and true or v721 == "Dusk"
						local v722, v723 = pcall(v717, v718, v719, v624, v720)
						if v722 and v723 then
							v625.lift = v723
						else
							if (v625.liftGiveUp or 0) >= v622 then
								continue
							end
							table.insert(v623, v624)
						end
					end
				else
					table.insert(v623, v624)
				end
			else
				if v625.kind ~= "horde" or not v625.src then
					continue
				end
				local v724 = v_u_6.pathSample(v625.path, (v622 - v625.startAt) * v625.speed)
				v625.src.CFrame = CFrame.new(v724 + Vector3.new(0, 2, 0))
				if v625.endAt >= v622 then
					continue
				end
				table.insert(v623, v624)
			end
		else
			table.insert(v623, v624)
		end
	end
	for _, v725 in v623 do
		v_u_620(v725)
	end
end
local function v_u_736(p727) -- name: watchEvents
	-- upvalues: (copy) v_u_600, (copy) v_u_9, (copy) v_u_620
	local v728 = p727:WaitForChild("Events", 10)
	if v728 then
		for _, v729 in v728:GetChildren() do
			v_u_600(v729)
		end
		local v731 = v728.ChildAdded:Connect(function(p730)
			-- upvalues: (ref) v_u_600
			task.defer(v_u_600, p730)
		end)
		local v732 = v_u_9
		table.insert(v732, v731)
		local v734 = v728.ChildRemoved:Connect(function(p733)
			-- upvalues: (ref) v_u_620
			v_u_620(p733)
		end)
		local v735 = v_u_9
		table.insert(v735, v734)
	end
end
local function v_u_749(p737, p738) -- name: playSiren
	-- upvalues: (ref) v_u_12, (copy) v_u_39
	local v739 = v_u_12
	if v739 then
		local v740, v741 = CFrame.new(0, 90, 0)
		local v_u_742 = Instance.new("Part")
		v_u_742.Name = "Siren"
		v_u_742.Anchored = true
		v_u_742.CanCollide = false
		v_u_742.CanQuery = false
		v_u_742.CanTouch = false
		v_u_742.CastShadow = false
		v_u_742.Transparency = 1
		v_u_742.Size = v741 or Vector3.new(0.2, 0.2, 0.2)
		v_u_742.CFrame = v740
		v_u_742.Parent = v739
		local v_u_743 = v_u_39("loop", "ev_siren", v_u_742)
		task.delay(p737, function()
			-- upvalues: (copy) v_u_743, (copy) v_u_742
			local v_u_744 = v_u_743
			if v_u_744 ~= nil then
				pcall(function()
					-- upvalues: (copy) v_u_744
					local v745 = v_u_744
					if typeof(v745) == "Instance" then
						v_u_744:Destroy()
					else
						local v746 = v_u_744
						if type(v746) == "table" then
							local v747 = v_u_744.stop or v_u_744.Stop or (v_u_744.destroy or v_u_744.Destroy)
							if type(v747) == "function" then
								v747(v_u_744)
								return
							end
						else
							local v748 = v_u_744
							if type(v748) == "function" then
								v_u_744()
							end
						end
					end
				end)
			end
			if v_u_742.Parent then
				v_u_742:Destroy()
			end
		end)
		v_u_39("threatHint", p738)
	end
end
local function v_u_754() -- name: checkSiren
	-- upvalues: (ref) v_u_11, (copy) v_u_31, (ref) v_u_22, (copy) v_u_749, (ref) v_u_23
	local v750 = v_u_11
	if v750 then
		local v751 = v_u_31.now()
		if not v_u_22 then
			local v752 = v750:GetAttribute("SirenAt")
			if type(v752) == "number" and v752 <= v751 then
				v_u_22 = true
				if v751 - v752 < 20 then
					v_u_749(24, 0.6)
				end
			end
		end
		if not v_u_23 then
			local v753 = v750:GetAttribute("EndsAt")
			if type(v753) == "number" and v753 - 60 <= v751 then
				v_u_23 = true
				if v751 < v753 - 45 then
					v_u_749(12, 0.9)
				end
			end
		end
	end
end
local function v_u_767() -- name: teardown
	-- upvalues: (ref) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_14, (copy) v_u_620, (copy) v_u_13, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_179, (ref) v_u_3, (ref) v_u_181, (ref) v_u_11, (ref) v_u_22, (ref) v_u_23, (ref) v_u_25, (ref) v_u_26, (ref) v_u_28
	v_u_8 = v_u_8 + 1
	for _, v755 in v_u_9 do
		v755:Disconnect()
	end
	table.clear(v_u_9)
	for _, v756 in v_u_10 do
		pcall(v756)
	end
	table.clear(v_u_10)
	local v757 = {}
	for v758 in v_u_14 do
		table.insert(v757, v758)
	end
	for _, v759 in v757 do
		v_u_620(v759)
	end
	local v760 = {}
	for v761 in v_u_13 do
		table.insert(v760, v761)
	end
	for _, v762 in v760 do
		local v763 = v_u_13[v762]
		if not v763 then
			continue
		end
		v_u_13[v762] = nil
		if not v763.model then
			continue
		end
		v763.model:Destroy()
	end
	if v_u_12 then
		v_u_12:Destroy()
		v_u_12 = nil
	end
	if v_u_15 then
		v_u_15:Destroy()
		v_u_15 = nil
	end
	v_u_16 = nil
	v_u_17 = nil
	v_u_18 = nil
	v_u_19 = nil
	v_u_20 = nil
	v_u_179 = nil
	local v764 = v_u_3
	if v764 then
		v764 = v_u_3.controllers.Input
	end
	if not v764 or v764._broken then
		v764 = nil
	end
	if v764 then
		local v765 = v764.setEnabled
		if type(v765) == "function" and v_u_181 then
			v_u_181 = false
			local v766 = v764.setEnabled
			pcall(v766, true)
		end
	end
	v_u_11 = nil
	v_u_22 = false
	v_u_23 = false
	v_u_25 = false
	v_u_26 = nil
	v_u_28 = ""
end
local function v_u_772(p768, p769) -- name: waitCharacter
	-- upvalues: (ref) v_u_8, (copy) v_u_4
	local v770 = os.clock() + p769
	while os.clock() < v770 and p768 == v_u_8 do
		local v771 = v_u_4.Character
		if v771 and v771:FindFirstChild("HumanoidRootPart") then
			return v771
		end
		task.wait(0.1)
	end
	return nil
end
local function v_u_801(p_u_773) -- name: arrive
	-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_11, (copy) v_u_772, (copy) v_u_4, (ref) v_u_12, (copy) v_u_42, (copy) v_u_272, (copy) v_u_164, (copy) v_u_178, (copy) v_u_736, (copy) v_u_380, (copy) v_u_9, (ref) v_u_28, (copy) v_u_316, (ref) v_u_27, (copy) v_u_342, (copy) v_u_10, (ref) v_u_22, (copy) v_u_31, (ref) v_u_23, (ref) v_u_25
	local v774 = v_u_3.session.waitForRaid(60)
	if p_u_773 == v_u_8 then
		if v774 then
			v_u_11 = v774
			local v_u_775 = v_u_772(p_u_773, 30)
			if p_u_773 == v_u_8 then
				local v_u_776
				if v_u_775 then
					v_u_776 = v_u_775:FindFirstChild("HumanoidRootPart")
				else
					v_u_776 = v_u_775
				end
				if v_u_776 then
					local v777 = not v_u_776.Anchored
					if v777 then
						v_u_776.Anchored = true
					end
					local function v783()
						-- upvalues: (ref) v_u_4, (copy) v_u_776, (copy) v_u_775, (copy) p_u_773, (ref) v_u_8
						local function v778()
							-- upvalues: (ref) v_u_4, (ref) v_u_776
							v_u_4:RequestStreamAroundAsync(v_u_776.Position, 6)
						end
						pcall(v778)
						local v779 = os.clock() + 12
						local v780 = RaycastParams.new()
						v780.FilterType = Enum.RaycastFilterType.Exclude
						v780.FilterDescendantsInstances = { v_u_775 }
						local v781 = 0
						while os.clock() < v779 and p_u_773 == v_u_8 do
							local v782 = workspace:Raycast(v_u_776.Position, Vector3.new(0, -30, 0), v780)
							if v782 and v782.Instance.CanCollide then
								v781 = v781 + 1
								if v781 >= 2 then
									break
								end
							else
								v781 = 0
							end
							task.wait(0.15)
						end
					end
					local v784, v785 = pcall(v783)
					if not v784 then
						warn("[RaidClient] floor hold failed:", v785)
					end
					if v777 and v_u_776.Parent then
						v_u_776.Anchored = false
					end
				end
				if p_u_773 == v_u_8 then
					local v786 = v_u_3.net.fire
					pcall(v786, "raid.floor")
					v_u_12 = v_u_42()
					v_u_272()
					task.spawn(v_u_164, v774)
					task.spawn(v_u_178)
					task.spawn(v_u_736, v774)
					local v787 = v_u_4:GetAttributeChangedSignal("RaidStatus"):Connect(v_u_380)
					local v788 = v_u_9
					table.insert(v788, v787)
					local v789 = v_u_3
					if v789 then
						v789 = v_u_3.controllers.Input
					end
					if not v789 or v789._broken then
						v789 = nil
					end
					if v789 then
						local v790 = v789.bind
						if type(v790) == "function" then
							local v791 = v789.bind
							local function v793()
								-- upvalues: (ref) v_u_28, (ref) v_u_316, (ref) v_u_27, (ref) v_u_342
								if v_u_28 == "Dead" then
									local v792 = v_u_316()
									if #v792 > 0 then
										v_u_27 = v_u_27 % #v792 + 1
										v_u_342(v792[v_u_27])
									end
								end
							end
							local v794, v795 = pcall(v791, "swap", v793)
							if v794 and type(v795) == "function" then
								local v796 = v_u_10
								table.insert(v796, v795)
							end
						end
					end
					local v797 = v774:GetAttribute("SirenAt")
					local v798
					if type(v797) == "number" then
						v798 = v797 <= v_u_31.now()
					else
						v798 = false
					end
					v_u_22 = v798
					local v799 = v774:GetAttribute("EndsAt")
					local v800
					if type(v799) == "number" then
						v800 = v_u_31.now() >= v799 - 60
					else
						v800 = false
					end
					v_u_23 = v800
					v_u_25 = true
					v_u_4:SetAttribute("RaidClientReady", true)
					v_u_3.emit("place.ready", "Raid")
					v_u_380()
				end
			else
				return
			end
		else
			warn("[RaidClient] raid resources did not arrive")
			v_u_3.emit("place.ready", "Raid")
			return
		end
	else
		return
	end
end
local function v_u_804(p802, _) -- name: onPlace
	-- upvalues: (copy) v_u_767, (copy) v_u_4, (ref) v_u_8, (copy) v_u_801
	if p802 == "Raid" then
		v_u_767()
		v_u_4:SetAttribute("RaidClientReady", false)
		local v803 = v_u_8
		task.spawn(v_u_801, v803)
	else
		v_u_4:SetAttribute("RaidClientReady", false)
		v_u_767()
	end
end
function v2.init(p_u_805) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (ref) v_u_32, (copy) v_u_29, (copy) v_u_298, (copy) v_u_13, (copy) v_u_14, (ref) v_u_25, (ref) v_u_20, (ref) v_u_28, (ref) v_u_26, (copy) v_u_390, (copy) v_u_215, (copy) v_u_396, (ref) v_u_21, (ref) v_u_24
	v_u_3 = p_u_805
	v_u_6 = p_u_805.shared.Extracts
	local v806, v807 = pcall(function()
		-- upvalues: (copy) p_u_805
		return p_u_805.shared.Theme
	end)
	if not v806 then
		v807 = nil
	end
	v_u_5 = v807
	local v808, v809 = pcall(function()
		-- upvalues: (copy) p_u_805
		return p_u_805.lib.HushUI
	end)
	if not v808 then
		v809 = nil
	end
	v_u_7 = v809
	if v_u_7 and v_u_7.bind then
		local v810 = v_u_7.bind
		pcall(v810, p_u_805)
	end
	if v_u_5 then
		v_u_32 = v_u_5.color.accent
	end
	local v811 = p_u_805.net
	local v812 = v_u_29
	local v813 = v811.listen
	local v814 = v_u_298
	table.insert(v812, v813("raid.extractProgress", v814))
	local v815, v_u_816 = pcall(function()
		-- upvalues: (copy) p_u_805
		return p_u_805.lib.RaidEndCine
	end)
	if v815 and type(v_u_816) == "table" then
		v_u_816.init(p_u_805)
		local v817 = v_u_29
		local v818 = v811.listen
		table.insert(v817, v818("raid.endcinematic", function(p819)
			-- upvalues: (copy) v_u_816
			local v820 = v_u_816.onMessage
			local v821, v822 = pcall(v820, p819)
			if not v821 then
				warn("[RaidClient] end cinematic failed:", v822)
			end
		end))
		p_u_805.command("endcine.play", function(p823)
			-- upvalues: (copy) v_u_816
			local v824 = type(p823) ~= "table" and {} or p823
			local v825 = v_u_816.preview
			local v826 = v824[1]
			v825(tonumber(v826), v824[2])
			local v827 = v824[1]
			local v828 = tonumber(v827) or 5.5
			return "playing (" .. tostring(v828) .. " s lead) -> attributes EndCine / EndCineLog"
		end)
		p_u_805.command("endcine.stop", function()
			-- upvalues: (copy) v_u_816
			v_u_816.stop(0.3)
			return "stopping"
		end)
		p_u_805.command("endcine.status", function()
			-- upvalues: (copy) v_u_816
			return v_u_816.status()
		end)
	end
	p_u_805.command("raidclient.status", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_25, (ref) v_u_20, (ref) v_u_28, (ref) v_u_26
		local v829 = 0
		for _ in v_u_13 do
			v829 = v829 + 1
		end
		local v830 = 0
		for _ in v_u_14 do
			v830 = v830 + 1
		end
		local v831 = "arrived=%s markers=%d events=%d ring=%s status=%s spectating=%s"
		local v832 = v_u_25
		local v833 = tostring(v832)
		local v834 = v_u_20
		if v834 then
			v834 = v_u_20.state
		end
		local v835 = tostring(v834)
		local v836 = v_u_28
		local v837 = v_u_26
		if v837 then
			v837 = v_u_26.Name
		end
		return v831:format(v833, v829, v830, v835, v836, (tostring(v837)))
	end)
	local v838 = p_u_805.on
	if type(v838) == "function" then
		p_u_805.on("ui.rebuild", function()
			-- upvalues: (ref) v_u_390
			v_u_390()
		end)
		p_u_805.on("touch.layout", function()
			-- upvalues: (ref) v_u_215
			v_u_215()
		end)
	end
	p_u_805.command("raidclient.ui", function(p839)
		-- upvalues: (ref) v_u_396
		if type(p839) == "table" then
			p839 = p839[1]
		elseif type(p839) ~= "string" then
			p839 = nil
		end
		return v_u_396((tostring(p839 or "")))
	end)
	p_u_805.command("raidclient.reveal", function()
		-- upvalues: (ref) v_u_21, (ref) v_u_24
		v_u_21 = os.clock() + 6
		v_u_24 = 1
		return "revealing extracts"
	end)
end
function v2.start() -- name: start
	-- upvalues: (ref) v_u_3, (copy) v_u_804
	v_u_3.session.onPlaceChanged(v_u_804)
end
function v2.step(p840) -- name: step
	-- upvalues: (ref) v_u_25, (copy) v_u_310, (copy) v_u_726, (ref) v_u_24, (copy) v_u_145, (copy) v_u_385, (copy) v_u_754
	if v_u_25 then
		v_u_310()
		v_u_726(p840)
		v_u_24 = v_u_24 + p840
		if v_u_24 >= 0.2 then
			v_u_24 = 0
			v_u_145()
			v_u_385()
			v_u_754()
		end
	end
end
return v2