-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewDesk

local v_u_1 = {}
local v_u_2 = {}
function v_u_1.use(p3) -- name: use
	-- upvalues: (ref) v_u_2
	v_u_2 = type(p3) ~= "table" and {} or p3
end
local function v_u_4() -- name: rules
	-- upvalues: (ref) v_u_2
	if v_u_2.rules == nil then
		return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewRules"))
	else
		return v_u_2.rules
	end
end
function v_u_1.cardSpec(p5, p6) -- name: cardSpec
	-- upvalues: (copy) v_u_4
	local v7 = v_u_4()
	local v8 = p5.live
	local v9 = type(v8) ~= "table" and {
		["state"] = "OFFLINE"
	} or p5.live
	local v10 = v9.state == "RAID" and "raid" or (v9.state == "LOBBY" and "lobby" or "offline")
	local v11 = {}
	local v12 = v7.liveText(v9, p6)
	local v13 = string.upper
	local v14 = p5.game or "pve"
	local v15 = v13((tostring(v14)))
	local v16 = p5.status or v7.TEXT.NOT_REVIEWED
	__set_list(v11, 1, {v12, v15, (tostring(v16))})
	local v17 = { v10, "plain", p5.statusCode == "mine" and "good" or ((p5.statusCode == "none" or p5.statusCode == "needs_more") and "warn" or "plain") }
	local v18 = p5.counts
	if type(v18) == "table" then
		local v19 = p5.counts.NOT_CHEATING or 0
		local v20 = p5.counts.UNCLEAR or 0
		local v21 = p5.counts.CHEATING or 0
		table.insert(v11, ("%d NOT CHEATING, %d UNCLEAR, %d CHEATING"):format(v19, v20, v21))
		table.insert(v17, "plain")
	end
	local v22 = p5.summary or ""
	local v23 = tostring(v22)
	local v24 = p5.note
	if type(v24) == "string" and p5.note ~= "" then
		v23 = v23 .. (v23 == "" and "" or "\n") .. "Note: " .. p5.note
	end
	local v25 = v23 == "" and "No summary." or v23
	local v26 = {
		["userId"] = p5.userId
	}
	local v27 = p5.name or "?"
	v26.name = tostring(v27)
	v26.summary = v25
	v26.chips = v11
	v26.kinds = v17
	v26.action = v7.actionOf(p5)
	v26.severity = p5.severity
	v26.row = p5
	return v26
end
function v_u_1.groupsFor(p28, p29, p30) -- name: groupsFor
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v31 = v_u_4()
	local v32 = type(p28) == "table" and #p28 or 0
	local v33 = v31.search(p28, p29)
	local v34 = {}
	for _, v35 in v31.group(v33) do
		local v36 = {}
		for _, v37 in v35.rows do
			local v38 = v_u_1.cardSpec
			table.insert(v36, v38(v37, p30))
		end
		local v39 = {
			["id"] = v35.id,
			["title"] = v35.title,
			["cards"] = v36
		}
		table.insert(v34, v39)
	end
	return v34, v32, #v33
end
function v_u_1.mineSpec(p40) -- name: mineSpec
	-- upvalues: (copy) v_u_4
	local v41 = v_u_4()
	local v42 = p40.date or ""
	local v43 = tostring(v42)
	local v44 = v41.watchText(p40.watchSeconds or 0)
	local v45 = p40.forced and ", sent as UNCLEAR: the minimum watch time was not reached" or ""
	local v46 = p40.game or "pve"
	local v47 = v43 .. ", watched " .. v44 .. v45 .. ", " .. tostring(v46):upper()
	local v48 = {}
	local v49 = p40.name or "?"
	v48.name = tostring(v49)
	local v50 = p40.text or (v41.VERDICT_TEXT[p40.verdict] or "")
	v48.verdict = tostring(v50)
	v48.meta = v47
	v48.comment = p40.comment
	return v48
end
function v_u_1.verdictNote(p51, p52) -- name: verdictNote
	-- upvalues: (copy) v_u_4
	local v53 = v_u_4()
	local v54 = tonumber(p51) or 0
	local v55 = tonumber(p52) or v53.MIN_WATCH_DEFAULT
	if v55 <= 0 then
		return string.format(v53.TEXT.MIN_OK, v53.watchText(v54))
	elseif v54 <= 0 then
		return string.format(v53.TEXT.NO_WATCH, v53.watchText(v55))
	elseif v55 <= v54 then
		return string.format(v53.TEXT.MIN_OK, v53.watchText(v54))
	else
		return string.format(v53.TEXT.MIN_NOTE, v53.watchText(v54), v53.watchText(v55))
	end
end
function v_u_1.context(p56, p57) -- name: context
	if type(p56) == "function" and p56("OverwatchTarget") == p57 then
		local v58 = p56("OverwatchWatchSeconds")
		local v59 = p56("OverwatchRaidId")
		local v60 = (type(v58) ~= "number" or v58 < 0) and 0 or math.floor(v58)
		if type(v59) == "string" then
			return v60, string.sub(v59, 1, 64)
		else
			return v60, ""
		end
	else
		return 0, ""
	end
end
local v_u_61 = game:GetService("Players")
local v_u_62 = game:GetService("ReplicatedStorage")
local v_u_63 = game:GetService("RunService")
local v_u_64 = game:GetService("UserInputService")
local v_u_65 = nil
local v_u_66 = nil
local v_u_67 = nil
local v_u_68 = nil
local v_u_69 = nil
local v_u_70 = nil
local v_u_71 = {}
local v_u_72 = nil
local v_u_73 = nil
local v_u_74 = nil
local v_u_75 = 0
local v_u_76 = {
	["tab"] = 1,
	["rows"] = nil,
	["mine"] = nil,
	["query"] = "",
	["loaded"] = false,
	["loading"] = false,
	["now"] = 0,
	["minWatch"] = 180,
	["role"] = nil,
	["status"] = "",
	["statusBad"] = false,
	["panel"] = nil,
	["truncated"] = false,
	["lastError"] = nil,
	["relayoutToken"] = 0,
	["rows"] = {},
	["mine"] = {}
}
local function v_u_80(p77, p78) -- name: remote
	-- upvalues: (copy) v_u_62
	local v79 = v_u_62:FindFirstChild("HushNet")
	if v79 then
		v79 = v79:FindFirstChild(p77)
	end
	if not v79 then
		v79 = v_u_62:WaitForChild("HushNet", 10)
		if v79 then
			v79 = v79:WaitForChild(p77, 10)
		end
	end
	if v79 and v79:IsA(p78) then
		return v79
	else
		return nil
	end
end
local function v_u_91(p81, p82) -- name: callGet
	-- upvalues: (copy) v_u_80, (copy) v_u_4
	local v_u_83 = {
		["what"] = p81
	}
	if type(p82) == "table" then
		for v84, v85 in p82 do
			v_u_83[v84] = v85
		end
	end
	local v_u_86 = v_u_80("menu.get", "RemoteFunction")
	if not v_u_86 then
		return {
			["ok"] = false,
			["msg"] = nil,
			["msg"] = v_u_4().TEXT.LOAD_FAIL
		}
	end
	local v87, v88 = pcall(function()
		-- upvalues: (copy) v_u_86, (copy) v_u_83
		return v_u_86:InvokeServer(v_u_83)
	end)
	if not v87 or type(v88) ~= "table" then
		return {
			["ok"] = false,
			["msg"] = nil,
			["msg"] = v_u_4().TEXT.LOAD_FAIL
		}
	end
	if v88.error == nil then
		return v88
	end
	local v89 = {
		["ok"] = false,
		["msg"] = nil
	}
	local v90
	if v88.error == "busy" then
		v90 = v_u_4().TEXT.BUSY
	else
		v90 = v_u_4().TEXT.LOAD_FAIL
	end
	v89.msg = v90
	return v89
end
local function v_u_101(p92, p93) -- name: fireOp
	-- upvalues: (ref) v_u_74, (copy) v_u_80
	local v94 = {
		["op"] = p92
	}
	for v95, v96 in p93 do
		v94[v95] = v96
	end
	local v97 = v_u_74
	if v97 and v97.net then
		local v98 = v97.net.fire
		if type(v98) == "function" then
			local v99 = v97.net.fire
			pcall(v99, "menu.op", v94)
			return
		end
	end
	local v100 = v_u_80("menu.op", "RemoteEvent")
	if v100 then
		v100:FireServer(v94)
	end
end
local function v_u_105() -- name: hook
	-- upvalues: (copy) v_u_61, (copy) v_u_1, (copy) v_u_76, (ref) v_u_65
	local v102 = v_u_61.LocalPlayer
	if v102 then
		local _, v103, v104 = v_u_1.groupsFor(v_u_76.rows, v_u_76.query, v_u_76.now)
		v102:SetAttribute("ReviewDesk", ("open=%d|tab=%d|rows=%d|shown=%d|panel=%d|status=%s"):format(v_u_65 and 1 or 0, v_u_76.tab, v103, v104, v_u_76.panel and 1 or 0, (string.gsub(v_u_76.status, "[|=]", " "))))
	end
end
local function v_u_121(p106, p107, p108, p109, p110, p111, p112, p113, p114) -- name: mkText
	local v115 = p114 or {}
	local v116 = p106.new
	local v117 = "TextLabel"
	local v118 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Text"] = nil,
		["TextWrapped"] = nil,
		["TextTruncate"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = nil,
		["Name"] = p109,
		["FontFace"] = v115.font or p107.font.body,
		["TextSize"] = p112,
		["TextColor3"] = p113,
		["Text"] = p111,
		["TextWrapped"] = v115.wrap == true
	}
	local v119
	if v115.wrap == true then
		v119 = Enum.TextTruncate.None
	else
		v119 = Enum.TextTruncate.AtEnd
	end
	v118.TextTruncate = v119
	v118.TextXAlignment = v115.align or Enum.TextXAlignment.Left
	local v120 = v115.valign
	if not v120 then
		if v115.wrap == true then
			v120 = Enum.TextYAlignment.Top
		else
			v120 = Enum.TextYAlignment.Center
		end
	end
	v118.TextYAlignment = v120
	v118.Position = UDim2.fromOffset(p110.x, p110.y)
	v118.Size = UDim2.fromOffset(p110.w, p110.h)
	v118.ZIndex = v115.z or 1
	return v116(v117, v118, p108)
end
local function v_u_136(p122, p123, p124, p125, p126, p127, p128, p_u_129, p130) -- name: mkButton
	local v_u_131 = p123.color
	local v132 = v_u_131.raised
	local v133 = v_u_131.text
	local v134 = v_u_131.line
	if p_u_129 == "primary" then
		v132 = v_u_131.accent
		v133 = v_u_131.ink
		v134 = v_u_131.accent
	elseif p_u_129 == "danger" then
		v132 = v_u_131.dangerDeep
		v133 = v_u_131.text
		v134 = v_u_131.danger
	elseif p_u_129 == "selected" then
		v132 = v_u_131.accentDeep
		v133 = v_u_131.text
		v134 = v_u_131.accent
	end
	local v_u_135 = p122.new("TextButton", {
		["Name"] = nil,
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Text"] = "",
		["Position"] = nil,
		["Size"] = nil,
		["Selectable"] = true,
		["ZIndex"] = 2,
		["Name"] = p125,
		["BackgroundColor3"] = v132,
		["Position"] = UDim2.fromOffset(p126.x, p126.y),
		["Size"] = UDim2.fromOffset(p126.w, p126.h)
	}, p124)
	p122.stroke(v_u_135, v134, 1, 0)
	p122.new("TextLabel", {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Text"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["FontFace"] = p123.font.heading,
		["TextSize"] = p128,
		["TextColor3"] = v133,
		["Text"] = p127,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(6, 0),
		["Size"] = UDim2.new(1, -12, 1, 0)
	}, v_u_135)
	v_u_135.MouseEnter:Connect(function()
		-- upvalues: (copy) p_u_129, (copy) v_u_135, (copy) v_u_131
		if p_u_129 == "secondary" then
			v_u_135.BackgroundColor3 = v_u_131.raised2
		end
	end)
	v_u_135.MouseLeave:Connect(function()
		-- upvalues: (copy) p_u_129, (copy) v_u_135, (copy) v_u_131
		if p_u_129 == "secondary" then
			v_u_135.BackgroundColor3 = v_u_131.raised
		end
	end)
	v_u_135.Activated:Connect(p130)
	return v_u_135
end
local v_u_137 = {
	["raid"] = "success",
	["lobby"] = "info",
	["offline"] = "muted",
	["plain"] = "text2",
	["warn"] = "accent",
	["good"] = "success"
}
local v_u_138 = {
	["red"] = "danger",
	["yellow"] = "accent",
	["green"] = "success"
}
local v_u_139 = nil
local v_u_140 = nil
local v_u_141 = nil
local function v_u_155(p142, p143) -- name: sendLive
	-- upvalues: (copy) v_u_4, (copy) v_u_76, (ref) v_u_69, (copy) v_u_105, (ref) v_u_75, (copy) v_u_101
	local v_u_144 = v_u_4()
	local v145
	if p142 == "reviewJoin" then
		v145 = v_u_144.TEXT.JOIN_WAIT
	else
		v145 = v_u_144.TEXT.FOLLOW_WAIT
	end
	v_u_76.status = v145
	v_u_76.statusBad = false
	if v_u_69 then
		local v146 = script.Parent
		local v147 = require(v146:WaitForChild("HushUI"))
		require(v146:WaitForChild("ReviewDeskPlan"))
		local v148 = v147.Theme
		v_u_69.Text = v145
		v_u_69.TextColor3 = v148.color.text2
	end
	v_u_105()
	local v_u_149 = v_u_75
	v_u_76.liveToken = (v_u_76.liveToken or 0) + 1
	local v_u_150 = v_u_76.liveToken
	v_u_76.liveAnswered = false
	v_u_101(p142, {
		["target"] = p143
	})
	task.delay(6, function()
		-- upvalues: (copy) v_u_149, (ref) v_u_75, (ref) v_u_76, (copy) v_u_150, (copy) v_u_144, (ref) v_u_69, (ref) v_u_105
		if v_u_149 == v_u_75 and (v_u_76.liveToken == v_u_150 and not v_u_76.liveAnswered) then
			local v151 = v_u_144.TEXT.NOT_READY
			v_u_76.status = v151
			v_u_76.statusBad = true
			if v_u_69 then
				local v152 = script.Parent
				local v153 = require(v152:WaitForChild("HushUI"))
				require(v152:WaitForChild("ReviewDeskPlan"))
				local v154 = v153.Theme
				v_u_69.Text = v151
				v_u_69.TextColor3 = v154.color.danger
			end
			v_u_105()
		end
	end)
end
local function v_u_190(p156, p157, p158, p159, p160, p161, p_u_162) -- name: buildCard
	-- upvalues: (copy) v_u_138, (copy) v_u_121, (copy) v_u_137, (copy) v_u_4, (copy) v_u_136, (copy) v_u_155, (ref) v_u_141
	local v163 = p158.color
	local v164 = p161.parts
	local v165 = p156.new
	local v166 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true
	}
	local v167 = p_u_162.userId
	v166.Name = "Card_" .. tostring(v167)
	v166.BackgroundColor3 = v163.raised
	local v168 = p161.rect
	v166.Position = UDim2.fromOffset(v168.x, v168.y)
	local v169 = p161.rect
	v166.Size = UDim2.fromOffset(v169.w, v169.h)
	local v170 = v165("Frame", v166, p160)
	p156.stroke(v170, v163.line, 1, 0)
	local v171 = p156.new
	local v172 = {
		["Name"] = "Severity",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v163[v_u_138[p_u_162.severity or "yellow"] or "accent"]
	}
	local v173 = v164.bar
	v172.Position = UDim2.fromOffset(v173.x, v173.y)
	local v174 = v164.bar
	v172.Size = UDim2.fromOffset(v174.w, v174.h)
	v171("Frame", v172, v170)
	local v175 = p156.new
	local v176 = {
		["Name"] = "Avatar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["BackgroundColor3"] = v163.bg
	}
	local v177 = v164.avatar
	v176.Position = UDim2.fromOffset(v177.x, v177.y)
	local v178 = v164.avatar
	v176.Size = UDim2.fromOffset(v178.w, v178.h)
	v176.Image = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(p_u_162.userId or 0)
	local v179 = v175("ImageLabel", v176, v170)
	p156.corner(v179, 6)
	v_u_121(p156, p158, v170, "Name", v164.name, p_u_162.name, p157.fs(p159, 15), v163.text, {
		["font"] = p158.font.bodyBold
	})
	for v180, v181 in v164.chips do
		local v182 = v163[v_u_137[p_u_162.kinds[v180] or "plain"] or "text2"]
		local v183 = p156.new
		local v184 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = "Chip" .. v180,
			["BackgroundColor3"] = v163.bg
		}
		local v185 = v181.rect
		v184.Position = UDim2.fromOffset(v185.x, v185.y)
		local v186 = v181.rect
		v184.Size = UDim2.fromOffset(v186.w, v186.h)
		local v187 = v183("Frame", v184, v170)
		p156.stroke(v187, v182, 1, 0.4)
		v_u_121(p156, p158, v187, "Text", {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v181.rect.w,
			["h"] = v181.rect.h
		}, v181.text, v181.size, v182, {
			["font"] = p158.font.bodyMedium,
			["align"] = Enum.TextXAlignment.Center
		})
	end
	v_u_121(p156, p158, v170, "Summary", v164.summary, v164.summaryText, v164.summarySize, v163.text2, {
		["wrap"] = true
	})
	local v188 = v_u_4()
	if v164.buttons.action then
		local v189
		if p_u_162.action == "join" then
			v189 = v188.TEXT.BTN_JOIN
		else
			v189 = v188.TEXT.BTN_FOLLOW
		end
		v_u_136(p156, p158, v170, "Action", v164.buttons.action, v189, v164.btnSize, "primary", function()
			-- upvalues: (ref) v_u_155, (copy) p_u_162
			v_u_155(p_u_162.action == "join" and "reviewJoin" or "reviewFollow", p_u_162.userId)
		end)
	end
	v_u_136(p156, p158, v170, "Verdict", v164.buttons.verdict, v188.TEXT.BTN_VERDICT, v164.btnSize, "secondary", function()
		-- upvalues: (ref) v_u_141, (copy) p_u_162
		v_u_141(p_u_162)
	end)
end
v_u_139 = function()
	-- upvalues: (ref) v_u_65, (ref) v_u_68, (copy) v_u_4, (copy) v_u_76, (copy) v_u_105, (copy) v_u_1, (copy) v_u_121, (copy) v_u_190
	if v_u_65 and v_u_68 then
		local v191 = script.Parent
		local v_u_192 = require(v191:WaitForChild("HushUI"))
		local v_u_193 = require(v191:WaitForChild("ReviewDeskPlan"))
		local v_u_194 = v_u_192.Theme
		local v_u_195 = v_u_194.color
		local v196 = v_u_4()
		local v197 = v_u_68
		if v197 then
			for _, v198 in v197:GetChildren() do
				v198:Destroy()
			end
		end
		local v_u_199 = v_u_193.opts(v_u_194.uiScale(), v_u_194.isTouch(), v_u_194.isPhone())
		local v200 = v_u_68:GetAttribute("PlanW") or 600
		local function v202(p201) -- name: message
			-- upvalues: (copy) v_u_192, (copy) v_u_194, (copy) v_u_193, (copy) v_u_199, (copy) v_u_195, (ref) v_u_68
			v_u_192.new("TextLabel", {
				["Name"] = "Message",
				["BackgroundTransparency"] = 1,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Text"] = nil,
				["TextWrapped"] = true,
				["Size"] = nil,
				["TextYAlignment"] = nil,
				["FontFace"] = v_u_194.font.body,
				["TextSize"] = v_u_193.fs(v_u_199, 15),
				["TextColor3"] = v_u_195.muted,
				["Text"] = p201,
				["Size"] = UDim2.new(1, -v_u_193.SB, 0, 60),
				["TextYAlignment"] = Enum.TextYAlignment.Top
			}, v_u_68)
			v_u_68.CanvasSize = UDim2.new(0, 0, 0, 60)
		end
		if v_u_76.tab == 1 then
			if not v_u_76.loaded then
				v202(v_u_76.loading and "Loading ..." or (v_u_76.status ~= "" and v_u_76.status or v196.TEXT.LOAD_FAIL))
				v_u_105()
				return
			end
			local v203, v204, v205 = v_u_1.groupsFor(v_u_76.rows, v_u_76.query, v_u_76.now)
			if v205 == 0 then
				local v206
				if v204 == 0 then
					v206 = v196.TEXT.EMPTY_LIST
				else
					v206 = v196.TEXT.EMPTY_SEARCH
				end
				v202(v206)
				v_u_105()
				return
			end
			local v207, v208 = v_u_193.list(v200, v203, v_u_199)
			local v209 = {}
			local v210 = 0
			for _, v211 in v203 do
				for _, v212 in v211.cards do
					table.insert(v209, v212)
				end
			end
			for _, v213 in v207 do
				if v213.kind == "header" then
					v_u_121(v_u_192, v_u_194, v_u_68, "Group", v213.rect, v213.title, v_u_193.fs(v_u_199, 13), v_u_195.accent, {
						["font"] = v_u_194.font.heading
					})
				else
					v210 = v210 + 1
					v_u_190(v_u_192, v_u_193, v_u_194, v_u_199, v_u_68, v213, v209[v210])
				end
			end
			v_u_68.CanvasSize = UDim2.new(0, 0, 0, v208)
		elseif v_u_76.tab == 2 then
			if not v_u_76.mineLoaded then
				v202(v_u_76.loading and "Loading ..." or v196.TEXT.LOAD_FAIL)
				v_u_105()
				return
			end
			if #v_u_76.mine == 0 then
				v202(v196.TEXT.EMPTY_MINE)
				v_u_105()
				return
			end
			local v214 = 0
			for v215, v216 in v_u_76.mine do
				local v217 = v_u_1.mineSpec(v216)
				local v218 = v_u_193.mineRow(v200 - v_u_193.SB, v_u_199, v217)
				local v219 = v_u_192.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Name"] = "Mine" .. v215,
					["BackgroundColor3"] = v_u_195.raised,
					["Position"] = UDim2.fromOffset(0, v214),
					["Size"] = UDim2.fromOffset(v218.w, v218.h)
				}, v_u_68)
				v_u_192.stroke(v219, v_u_195.line, 1, 0)
				v_u_121(v_u_192, v_u_194, v219, "Name", v218.name, v217.name, v_u_193.fs(v_u_199, 15), v_u_195.text, {
					["font"] = v_u_194.font.bodyBold
				})
				local v220
				if v216.verdict == "CHEATING" then
					v220 = v_u_195.danger
				elseif v216.verdict == "NOT_CHEATING" then
					v220 = v_u_195.success
				else
					v220 = v_u_195.accent
				end
				local v221 = v_u_192.new
				local v222 = {
					["Name"] = "Chip",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_195.bg
				}
				local v223 = v218.chip
				v222.Position = UDim2.fromOffset(v223.x, v223.y)
				local v224 = v218.chip
				v222.Size = UDim2.fromOffset(v224.w, v224.h)
				local v225 = v221("Frame", v222, v219)
				v_u_192.stroke(v225, v220, 1, 0.4)
				v_u_121(v_u_192, v_u_194, v225, "Text", {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v218.chip.w,
					["h"] = v218.chip.h
				}, v218.chipText, v218.chipSize, v220, {
					["font"] = v_u_194.font.bodyMedium,
					["align"] = Enum.TextXAlignment.Center
				})
				v_u_121(v_u_192, v_u_194, v219, "Meta", v218.meta, v218.metaText, v218.metaSize, v_u_195.text2, {
					["wrap"] = true
				})
				if v218.comment then
					v_u_121(v_u_192, v_u_194, v219, "Comment", v218.comment, v218.commentText, v218.commentSize, v_u_195.text, {
						["wrap"] = true
					})
				end
				v214 = v214 + (v218.h + v_u_199.gap)
			end
			v_u_68.CanvasSize = UDim2.new(0, 0, 0, v214)
		else
			local v226 = v_u_193.help(v200 - v_u_193.SB, v_u_199, v196.TEXT.HELP_TITLE, v196.TEXT.HELP)
			v_u_121(v_u_192, v_u_194, v_u_68, "HelpTitle", v226.title, v196.TEXT.HELP_TITLE, v_u_193.fs(v_u_199, 15), v_u_195.accent, {
				["font"] = v_u_194.font.heading
			})
			for v227, v228 in v226.items do
				v_u_121(v_u_192, v_u_194, v_u_68, "Dot" .. v227, v228.bullet, "+", v228.size, v_u_195.accent, {
					["align"] = Enum.TextXAlignment.Center
				})
				v_u_121(v_u_192, v_u_194, v_u_68, "Help" .. v227, v228.text, v196.TEXT.HELP[v227], v228.size, v_u_195.text2, {
					["wrap"] = true
				})
			end
			local v229 = v226.h
			local v230 = v_u_193.lines(v196.TEXT.HELP_BLIND, v226.items[1].text.w, v_u_193.fs(v_u_199, 13))
			local v231 = v_u_193.lineH(v_u_199, v_u_193.fs(v_u_199, 13))
			v_u_121(v_u_192, v_u_194, v_u_68, "Blind", {
				["x"] = 4,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v229,
				["w"] = v200 - 8 - v_u_193.SB,
				["h"] = v230 * v231
			}, v196.TEXT.HELP_BLIND, v_u_193.fs(v_u_199, 13), v_u_195.text, {
				["wrap"] = true
			})
			v_u_68.CanvasSize = UDim2.new(0, 0, 0, v229 + v230 * v231 + 8)
		end
		v_u_105()
	end
end
local function v_u_233() -- name: closeDesk
	-- upvalues: (ref) v_u_75, (copy) v_u_76, (ref) v_u_71, (ref) v_u_65, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_72, (ref) v_u_73, (copy) v_u_105
	v_u_75 = v_u_75 + 1
	v_u_76.panel = nil
	for _, v_u_232 in v_u_71 do
		pcall(function()
			-- upvalues: (copy) v_u_232
			v_u_232:Disconnect()
		end)
	end
	v_u_71 = {}
	if v_u_65 then
		v_u_65:Destroy()
	end
	v_u_65 = nil
	v_u_66 = nil
	v_u_67 = nil
	v_u_68 = nil
	v_u_69 = nil
	v_u_70 = nil
	v_u_72 = nil
	v_u_73 = nil
	v_u_105()
end
v_u_140 = function()
	-- upvalues: (ref) v_u_65, (copy) v_u_4, (ref) v_u_67, (ref) v_u_70, (ref) v_u_66, (copy) v_u_76, (copy) v_u_121, (copy) v_u_233, (ref) v_u_140, (ref) v_u_75, (ref) v_u_69, (copy) v_u_105, (ref) v_u_139, (copy) v_u_91, (copy) v_u_136, (ref) v_u_68, (ref) v_u_141
	if v_u_65 then
		local v234 = script.Parent
		local v235 = require(v234:WaitForChild("HushUI"))
		local v236 = require(v234:WaitForChild("ReviewDeskPlan"))
		local v237 = v235.Theme
		local v238 = v237.color
		local v239 = v_u_4()
		local v240 = v_u_67
		if v240 then
			for _, v241 in v240:GetChildren() do
				v241:Destroy()
			end
		end
		v_u_70 = nil
		local v242 = v236.opts(v237.uiScale(), v237.isTouch(), v237.isPhone())
		local v243 = v237.uiScale()
		local v244 = math.max(v243, 0.1)
		local v245 = v_u_66.AbsoluteSize.X / v244
		local v246 = math.floor(v245)
		local v247 = v_u_66.AbsoluteSize.Y / v244
		local v248 = math.floor(v247)
		local v249 = v236.window(v246, v248, v242, nil)
		v_u_76.win = v249
		v_u_67.Position = UDim2.fromOffset(v249.x, v249.y)
		v_u_67.Size = UDim2.fromOffset(v249.w, v249.h)
		local v250 = v236.frame(v249.w, v249.h, v242, v_u_76.tab)
		if v250.title then
			v_u_121(v235, v237, v_u_67, "Title", v250.title, v239.TEXT.TITLE, v236.fs(v242, 24), v238.text, {
				["font"] = v237.font.headingBold
			})
			v235.new("Frame", {
				["Name"] = "Accent",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v238.accent,
				["Size"] = UDim2.fromOffset(48, 2)
			}, v_u_67)
			v235.new("Frame", {
				["Name"] = "HeaderLine",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v238.line,
				["Position"] = UDim2.fromOffset(0, v250.header.h),
				["Size"] = UDim2.fromOffset(v249.w, 1)
			}, v_u_67)
		end
		local v251 = v235.new
		local v252 = {
			["Name"] = "Close",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Text"] = "",
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v238.raised
		}
		local v253 = v250.close
		v252.Position = UDim2.fromOffset(v253.x, v253.y)
		local v254 = v250.close
		v252.Size = UDim2.fromOffset(v254.w, v254.h)
		local v255 = v251("TextButton", v252, v_u_67)
		v235.stroke(v255, v238.line, 1, 0)
		v235.new("TextLabel", {
			["Name"] = "X",
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Text"] = "X",
			["Size"] = nil,
			["ZIndex"] = 3,
			["FontFace"] = v237.font.headingBold,
			["TextSize"] = v236.fs(v242, 18),
			["TextColor3"] = v238.text,
			["Size"] = UDim2.fromScale(1, 1)
		}, v255)
		v255.Activated:Connect(v_u_233)
		local v256 = { v239.TEXT.TAB_LIST, v239.TEXT.TAB_MINE, v239.TEXT.TAB_HELP }
		for v_u_257, v258 in v250.tabs do
			local v259 = v235.new("TextButton", {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Name"] = "Tab" .. v_u_257,
				["Position"] = UDim2.fromOffset(v258.x, v258.y),
				["Size"] = UDim2.fromOffset(v258.w, v258.h)
			}, v_u_67)
			local v260 = v_u_121
			local v261 = "Text"
			local v262 = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v258.w,
				["h"] = v258.h - 3
			}
			local v263 = v256[v_u_257]
			local v264 = v250.tabSize
			local v265
			if v_u_257 == v_u_76.tab then
				v265 = v238.text
			else
				v265 = v238.text2
			end
			v260(v235, v237, v259, v261, v262, v263, v264, v265, {
				["font"] = nil,
				["align"] = nil,
				["z"] = 3,
				["font"] = v237.font.heading,
				["align"] = Enum.TextXAlignment.Center
			})
			local v266 = v235.new
			local v267 = "Frame"
			local v268 = {
				["Name"] = "Line",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3
			}
			local v269
			if v_u_257 == v_u_76.tab then
				v269 = v238.accent
			else
				v269 = v238.line
			end
			v268.BackgroundColor3 = v269
			v268.Position = UDim2.new(0, 0, 1, -2)
			v268.Size = UDim2.new(1, 0, 0, 2)
			v266(v267, v268, v259)
			v259.Activated:Connect(function()
				-- upvalues: (copy) v_u_257, (ref) v_u_76, (ref) v_u_67, (ref) v_u_140, (ref) v_u_75, (ref) v_u_69, (ref) v_u_105, (ref) v_u_139, (ref) v_u_91, (ref) v_u_4
				local v270 = v_u_257
				if v_u_76.tab == v270 and v_u_67 then
					return
				else
					v_u_76.tab = v270
					v_u_76.panel = nil
					v_u_140()
					if v270 == 1 then
						if not v_u_76.loading then
							v_u_76.loading = true
							local v_u_271 = v_u_75
							v_u_76.status = "Loading ..."
							v_u_76.statusBad = false
							if v_u_69 then
								local v272 = script.Parent
								local v273 = require(v272:WaitForChild("HushUI"))
								require(v272:WaitForChild("ReviewDeskPlan"))
								local v274 = v273.Theme
								v_u_69.Text = "Loading ..."
								v_u_69.TextColor3 = v274.color.text2
							end
							v_u_105()
							v_u_139()
							local v_u_275 = false
							task.spawn(function()
								-- upvalues: (ref) v_u_91, (copy) v_u_275, (copy) v_u_271, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
								local v276 = v_u_91("reviewList", {
									["force"] = v_u_275 == true
								})
								if v_u_271 ~= v_u_75 then
									return
								end
								v_u_76.loading = false
								local v277, v278, v279, v280, v281
								if v276.ok == true then
									local v282 = v276.rows
									if type(v282) == "table" then
										v_u_76.rows = v276.rows
										local v283 = v_u_76
										local v284 = v276.now
										v283.now = tonumber(v284) or os.time()
										local v285 = v_u_76
										local v286 = v276.minWatchSec
										v285.minWatch = tonumber(v286) or 180
										v_u_76.role = v276.role
										v_u_76.loaded = true
										v_u_76.truncated = v276.truncated == true
										local v287 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
										local v288 = v_u_76.truncated
										v_u_76.status = v287
										v_u_76.statusBad = v288 == true
										if v_u_69 then
											local v289 = script.Parent
											local v290 = require(v289:WaitForChild("HushUI"))
											require(v289:WaitForChild("ReviewDeskPlan"))
											local v291 = v290.Theme
											v_u_69.Text = v287
											local v292 = v_u_69
											local v293
											if v288 then
												v293 = v291.color.danger
											else
												v293 = v291.color.text2
											end
											v292.TextColor3 = v293
										end
										v_u_105()
										v_u_139()
										v_u_105()
									else
										v_u_76.loaded = v_u_76.loaded and true or false
										v277 = v276.msg or v_u_4().TEXT.LOAD_FAIL
										v278 = tostring(v277)
										v_u_76.status = v278
										v_u_76.statusBad = true
										if v_u_69 then
											v279 = script.Parent
											v280 = require(v279:WaitForChild("HushUI"))
											require(v279:WaitForChild("ReviewDeskPlan"))
											v281 = v280.Theme
											v_u_69.Text = v278
											v_u_69.TextColor3 = v281.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
									end
								else
									v_u_76.loaded = v_u_76.loaded and true or false
									v277 = v276.msg or v_u_4().TEXT.LOAD_FAIL
									v278 = tostring(v277)
									v_u_76.status = v278
									v_u_76.statusBad = true
									if v_u_69 then
										v279 = script.Parent
										v280 = require(v279:WaitForChild("HushUI"))
										require(v279:WaitForChild("ReviewDeskPlan"))
										v281 = v280.Theme
										v_u_69.Text = v278
										v_u_69.TextColor3 = v281.color.danger
									end
									v_u_105()
									v_u_139()
									v_u_105()
									return
								end
							end)
						end
					elseif v270 == 2 then
						v_u_76.mineLoaded = false
						if not v_u_76.loading then
							v_u_76.loading = true
							local v_u_294 = v_u_75
							v_u_76.status = "Loading ..."
							v_u_76.statusBad = false
							if v_u_69 then
								local v295 = script.Parent
								local v296 = require(v295:WaitForChild("HushUI"))
								require(v295:WaitForChild("ReviewDeskPlan"))
								local v297 = v296.Theme
								v_u_69.Text = "Loading ..."
								v_u_69.TextColor3 = v297.color.text2
							end
							v_u_105()
							v_u_139()
							task.spawn(function()
								-- upvalues: (ref) v_u_91, (copy) v_u_294, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
								local v298 = v_u_91("reviewMine", {})
								if v_u_294 ~= v_u_75 then
									return
								end
								v_u_76.loading = false
								local v299, v300, v301, v302, v303
								if v298.ok == true then
									local v304 = v298.rows
									if type(v304) == "table" then
										v_u_76.mine = v298.rows
										v_u_76.mineLoaded = true
										v_u_76.status = ""
										v_u_76.statusBad = false
										if v_u_69 then
											local v305 = script.Parent
											local v306 = require(v305:WaitForChild("HushUI"))
											require(v305:WaitForChild("ReviewDeskPlan"))
											local v307 = v306.Theme
											v_u_69.Text = ""
											v_u_69.TextColor3 = v307.color.text2
										end
										v_u_105()
										v_u_139()
										v_u_105()
									else
										v299 = v298.msg or v_u_4().TEXT.LOAD_FAIL
										v300 = tostring(v299)
										v_u_76.status = v300
										v_u_76.statusBad = true
										if v_u_69 then
											v301 = script.Parent
											v302 = require(v301:WaitForChild("HushUI"))
											require(v301:WaitForChild("ReviewDeskPlan"))
											v303 = v302.Theme
											v_u_69.Text = v300
											v_u_69.TextColor3 = v303.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
									end
								else
									v299 = v298.msg or v_u_4().TEXT.LOAD_FAIL
									v300 = tostring(v299)
									v_u_76.status = v300
									v_u_76.statusBad = true
									if v_u_69 then
										v301 = script.Parent
										v302 = require(v301:WaitForChild("HushUI"))
										require(v301:WaitForChild("ReviewDeskPlan"))
										v303 = v302.Theme
										v_u_69.Text = v300
										v_u_69.TextColor3 = v303.color.danger
									end
									v_u_105()
									v_u_139()
									v_u_105()
									return
								end
							end)
						end
					else
						v_u_139()
						return
					end
				end
			end)
		end
		if v_u_76.tab == 1 then
			local v308 = v235.input
			local v309 = {
				["parent"] = nil,
				["name"] = "Search",
				["size"] = nil,
				["placeholder"] = nil,
				["text"] = nil,
				["maxLength"] = 40,
				["parent"] = v_u_67
			}
			local v310 = v250.search
			v309.size = UDim2.fromOffset(v310.w, v310.h)
			v309.placeholder = v239.TEXT.SEARCH
			v309.text = v_u_76.query
			local v311, v_u_312 = v308(v309)
			local v313 = v250.search
			v311.Position = UDim2.fromOffset(v313.x, v313.y)
			v_u_70 = v_u_312
			local v_u_314 = 0
			v_u_312:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_314, (ref) v_u_65, (ref) v_u_76, (copy) v_u_312, (ref) v_u_139
				v_u_314 = v_u_314 + 1
				local v_u_315 = v_u_314
				task.delay(0.12, function()
					-- upvalues: (copy) v_u_315, (ref) v_u_314, (ref) v_u_65, (ref) v_u_76, (ref) v_u_312, (ref) v_u_139
					if v_u_315 == v_u_314 and v_u_65 then
						v_u_76.query = v_u_312.Text
						v_u_139()
					end
				end)
			end)
			v_u_136(v235, v237, v_u_67, "Reload", v250.reload, v239.TEXT.BTN_RELOAD, v236.fs(v242, 13), "secondary", function()
				-- upvalues: (ref) v_u_76, (ref) v_u_75, (ref) v_u_69, (ref) v_u_105, (ref) v_u_139, (ref) v_u_91, (ref) v_u_4
				if not v_u_76.loading then
					v_u_76.loading = true
					local v_u_316 = v_u_75
					v_u_76.status = "Loading ..."
					v_u_76.statusBad = false
					if v_u_69 then
						local v317 = script.Parent
						local v318 = require(v317:WaitForChild("HushUI"))
						require(v317:WaitForChild("ReviewDeskPlan"))
						local v319 = v318.Theme
						v_u_69.Text = "Loading ..."
						v_u_69.TextColor3 = v319.color.text2
					end
					v_u_105()
					v_u_139()
					local v_u_320 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_91, (copy) v_u_320, (copy) v_u_316, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
						local v321 = v_u_91("reviewList", {
							["force"] = v_u_320 == true
						})
						if v_u_316 ~= v_u_75 then
							return
						end
						v_u_76.loading = false
						local v322, v323, v324, v325, v326
						if v321.ok == true then
							local v327 = v321.rows
							if type(v327) == "table" then
								v_u_76.rows = v321.rows
								local v328 = v_u_76
								local v329 = v321.now
								v328.now = tonumber(v329) or os.time()
								local v330 = v_u_76
								local v331 = v321.minWatchSec
								v330.minWatch = tonumber(v331) or 180
								v_u_76.role = v321.role
								v_u_76.loaded = true
								v_u_76.truncated = v321.truncated == true
								local v332 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
								local v333 = v_u_76.truncated
								v_u_76.status = v332
								v_u_76.statusBad = v333 == true
								if v_u_69 then
									local v334 = script.Parent
									local v335 = require(v334:WaitForChild("HushUI"))
									require(v334:WaitForChild("ReviewDeskPlan"))
									local v336 = v335.Theme
									v_u_69.Text = v332
									local v337 = v_u_69
									local v338
									if v333 then
										v338 = v336.color.danger
									else
										v338 = v336.color.text2
									end
									v337.TextColor3 = v338
								end
								v_u_105()
								v_u_139()
								v_u_105()
							else
								v_u_76.loaded = v_u_76.loaded and true or false
								v322 = v321.msg or v_u_4().TEXT.LOAD_FAIL
								v323 = tostring(v322)
								v_u_76.status = v323
								v_u_76.statusBad = true
								if v_u_69 then
									v324 = script.Parent
									v325 = require(v324:WaitForChild("HushUI"))
									require(v324:WaitForChild("ReviewDeskPlan"))
									v326 = v325.Theme
									v_u_69.Text = v323
									v_u_69.TextColor3 = v326.color.danger
								end
								v_u_105()
								v_u_139()
								v_u_105()
							end
						else
							v_u_76.loaded = v_u_76.loaded and true or false
							v322 = v321.msg or v_u_4().TEXT.LOAD_FAIL
							v323 = tostring(v322)
							v_u_76.status = v323
							v_u_76.statusBad = true
							if v_u_69 then
								v324 = script.Parent
								v325 = require(v324:WaitForChild("HushUI"))
								require(v324:WaitForChild("ReviewDeskPlan"))
								v326 = v325.Theme
								v_u_69.Text = v323
								v_u_69.TextColor3 = v326.color.danger
							end
							v_u_105()
							v_u_139()
							v_u_105()
							return
						end
					end)
				end
			end)
		end
		local v339 = v_u_121
		local v340 = v_u_67
		local v341 = "Status"
		local v342 = v250.status
		local v343 = v_u_76.status
		local v344 = v236.fs(v242, 12)
		local v345
		if v_u_76.statusBad then
			v345 = v238.danger
		else
			v345 = v238.text2
		end
		v_u_69 = v339(v235, v237, v340, v341, v342, v343, v344, v345, {})
		local v346 = v235.new
		local v347 = {
			["Name"] = "Body",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["ScrollBarThickness"] = 4,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil
		}
		local v348 = v250.body
		v347.Position = UDim2.fromOffset(v348.x, v348.y)
		local v349 = v250.body
		v347.Size = UDim2.fromOffset(v349.w, v349.h)
		v347.CanvasSize = UDim2.new()
		v347.ScrollingDirection = Enum.ScrollingDirection.Y
		v347.ElasticBehavior = Enum.ElasticBehavior.WhenScrollable
		v_u_68 = v346("ScrollingFrame", v347, v_u_67)
		v_u_68:SetAttribute("PlanW", v250.body.w)
		v_u_139()
		if v_u_76.panel then
			v_u_141(v_u_76.panel.spec)
		end
	end
end
local function v_u_352()
	-- upvalues: (ref) v_u_65, (copy) v_u_76, (ref) v_u_140
	if v_u_65 then
		local v350 = v_u_76
		v350.relayoutToken = v350.relayoutToken + 1
		local v_u_351 = v_u_76.relayoutToken
		task.delay(0.15, function()
			-- upvalues: (copy) v_u_351, (ref) v_u_76, (ref) v_u_65, (ref) v_u_140
			if v_u_351 == v_u_76.relayoutToken and v_u_65 then
				v_u_140()
			end
		end)
	end
end
v_u_141 = function(p_u_353)
	-- upvalues: (ref) v_u_65, (ref) v_u_67, (copy) v_u_4, (ref) v_u_72, (copy) v_u_76, (copy) v_u_61, (copy) v_u_1, (copy) v_u_121, (copy) v_u_105, (copy) v_u_136, (ref) v_u_73, (ref) v_u_75, (ref) v_u_69, (copy) v_u_91, (ref) v_u_139
	if v_u_65 and v_u_67 then
		local v354 = script.Parent
		local v355 = require(v354:WaitForChild("HushUI"))
		local v356 = require(v354:WaitForChild("ReviewDeskPlan"))
		local v357 = v355.Theme
		local v_u_358 = v357.color
		local v_u_359 = v_u_4()
		if v_u_72 then
			v_u_72:Destroy()
			v_u_72 = nil
		end
		local v360 = v356.opts(v357.uiScale(), v357.isTouch(), v357.isPhone())
		local v361 = v_u_76.win.w
		local v362 = v_u_76.win.h
		local v_u_363 = v_u_61.LocalPlayer
		local v_u_366, v_u_367 = v_u_1.context(function(p364)
			-- upvalues: (copy) v_u_363
			local v365 = v_u_363
			if v365 then
				v365 = v_u_363:GetAttribute(p364)
			end
			return v365
		end, p_u_353.userId)
		local v368 = {
			["note"] = v_u_1.verdictNote(v_u_366, v_u_76.minWatch)
		}
		local v369 = v356.verdict(v361, v362, v360, v368)
		local v370 = v_u_76
		local v371 = v_u_76.panel
		if not v371 then
			v371 = {
				["spec"] = nil,
				["pick"] = nil,
				["comment"] = "",
				["spec"] = p_u_353
			}
		end
		v370.panel = v371
		v_u_76.panel.spec = p_u_353
		v_u_72 = v355.new("TextButton", {
			["Name"] = "VerdictOverlay",
			["AutoButtonColor"] = false,
			["Text"] = "",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 20,
			["Active"] = true,
			["BackgroundColor3"] = v_u_358.black,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_67)
		local v372
		if v369.scroll then
			local v373 = v355.new
			local v374 = {
				["Name"] = "VerdictPanel",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["ScrollBarThickness"] = 4,
				["ZIndex"] = 21,
				["BackgroundColor3"] = v_u_358.bg
			}
			local v375 = v369.panel
			v374.Position = UDim2.fromOffset(v375.x, v375.y)
			local v376 = v369.panel
			v374.Size = UDim2.fromOffset(v376.w, v376.h)
			v374.CanvasSize = UDim2.fromOffset(0, v369.panelH)
			v372 = v373("ScrollingFrame", v374, v_u_72)
		else
			local v377 = v355.new
			local v378 = {
				["Name"] = "VerdictPanel",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 21,
				["BackgroundColor3"] = v_u_358.bg
			}
			local v379 = v369.panel
			v378.Position = UDim2.fromOffset(v379.x, v379.y)
			local v380 = v369.panel
			v378.Size = UDim2.fromOffset(v380.w, v380.h)
			v372 = v377("Frame", v378, v_u_72)
		end
		v355.stroke(v372, v_u_358.line, 1, 0)
		v_u_121(v355, v357, v372, "Title", v369.title, v_u_359.TEXT.VERDICT_TITLE, v356.fs(v360, 18), v_u_358.text, {
			["font"] = nil,
			["z"] = 22,
			["font"] = v357.font.headingBold
		})
		v_u_121(v355, v357, v372, "Who", v369.who, p_u_353.name .. "  \194\183  " .. v_u_359.liveText(p_u_353.row.live, v_u_76.now), v356.fs(v360, 15), v_u_358.accent, {
			["font"] = nil,
			["z"] = 22,
			["font"] = v357.font.bodyBold
		})
		v_u_121(v355, v357, v372, "Note", v369.note, v369.noteText, v369.noteSize, v_u_358.text2, {
			["wrap"] = true,
			["z"] = 22
		})
		local v_u_381 = {}
		local v_u_382 = nil
		local function v_u_393() -- name: paintPick
			-- upvalues: (copy) v_u_381, (ref) v_u_76, (copy) v_u_358, (ref) v_u_382, (ref) v_u_105
			for v383, v384 in v_u_381 do
				local v385 = v_u_76.panel.pick == v383
				local v386
				if v385 then
					v386 = v_u_358.accentDeep
				else
					v386 = v_u_358.raised
				end
				v384.BackgroundColor3 = v386
				local v387 = v384:FindFirstChildOfClass("UIStroke")
				if not v387 then
					continue
				end
				local v388
				if v385 then
					v388 = v_u_358.accent
				else
					v388 = v_u_358.line
				end
				v387.Color = v388
			end
			if v_u_382 then
				local v389 = v_u_382
				local v390
				if v_u_76.panel.pick then
					v390 = v_u_358.accent
				else
					v390 = v_u_358.raised
				end
				v389.BackgroundColor3 = v390
				local v391 = v_u_382:FindFirstChild("Text")
				if v391 then
					local v392
					if v_u_76.panel.pick then
						v392 = v_u_358.ink
					else
						v392 = v_u_358.muted
					end
					v391.TextColor3 = v392
				end
			end
			v_u_105()
		end
		for v394, v_u_395 in v_u_359.VERDICTS do
			local v396 = v_u_136(v355, v357, v372, "Pick_" .. v_u_395, v369.verdicts[v394], v_u_359.VERDICT_SHORT[v_u_395], v369.btnSize, "secondary", function()
				-- upvalues: (ref) v_u_76, (copy) v_u_395, (copy) v_u_393
				v_u_76.panel.pick = v_u_395
				v_u_393()
			end)
			v396.ZIndex = 22
			v_u_381[v_u_395] = v396
		end
		local v397 = v355.input
		local v398 = {
			["parent"] = nil,
			["name"] = "Comment",
			["size"] = nil,
			["placeholder"] = nil,
			["text"] = nil,
			["maxLength"] = nil,
			["parent"] = v372
		}
		local v399 = v369.comment
		v398.size = UDim2.fromOffset(v399.w, v399.h)
		v398.placeholder = v_u_359.TEXT.COMMENT
		v398.text = v_u_76.panel.comment or ""
		v398.maxLength = v_u_359.COMMENT_MAX
		local v400, v_u_401 = v397(v398)
		local v402 = v369.comment
		v400.Position = UDim2.fromOffset(v402.x, v402.y)
		v400.ZIndex = 22
		v_u_401:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_76, (copy) v_u_401
			v_u_76.panel.comment = v_u_401.Text
		end)
		local function v403() -- name: dismiss
			-- upvalues: (ref) v_u_76, (ref) v_u_73, (ref) v_u_72, (ref) v_u_105
			v_u_76.panel = nil
			v_u_73 = nil
			if v_u_72 then
				v_u_72:Destroy()
				v_u_72 = nil
			end
			v_u_105()
		end
		v_u_136(v355, v357, v372, "Cancel", v369.cancel, v_u_359.TEXT.BTN_CANCEL, v369.btnSize, "secondary", v403).ZIndex = 22
		local v_u_404 = false
		local function v444() -- name: doSend
			-- upvalues: (ref) v_u_404, (ref) v_u_76, (ref) v_u_75, (copy) p_u_353, (copy) v_u_366, (copy) v_u_367, (ref) v_u_69, (ref) v_u_105, (ref) v_u_91, (copy) v_u_359, (ref) v_u_73, (ref) v_u_72, (ref) v_u_139, (ref) v_u_4
			if not v_u_404 and (v_u_76.panel and v_u_76.panel.pick) then
				v_u_404 = true
				local v_u_405 = v_u_75
				local v_u_406 = {
					["target"] = p_u_353.userId,
					["verdict"] = v_u_76.panel.pick,
					["watchSeconds"] = v_u_366,
					["raidId"] = v_u_367,
					["comment"] = v_u_76.panel.comment or ""
				}
				v_u_76.status = "Sending ..."
				v_u_76.statusBad = false
				if v_u_69 then
					local v407 = script.Parent
					local v408 = require(v407:WaitForChild("HushUI"))
					require(v407:WaitForChild("ReviewDeskPlan"))
					local v409 = v408.Theme
					v_u_69.Text = "Sending ..."
					v_u_69.TextColor3 = v409.color.text2
				end
				v_u_105()
				task.spawn(function()
					-- upvalues: (ref) v_u_91, (copy) v_u_406, (copy) v_u_405, (ref) v_u_75, (ref) v_u_404, (ref) v_u_359, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_73, (ref) v_u_72, (ref) v_u_139, (ref) v_u_4
					local v410 = v_u_91("reviewVerdict", v_u_406)
					if v_u_405 == v_u_75 then
						v_u_404 = false
						if v410.ok == true then
							local v411 = v410.msg or v_u_359.TEXT.SENT
							local v412 = tostring(v411)
							v_u_76.status = v412
							v_u_76.statusBad = false
							if v_u_69 then
								local v413 = script.Parent
								local v414 = require(v413:WaitForChild("HushUI"))
								require(v413:WaitForChild("ReviewDeskPlan"))
								local v415 = v414.Theme
								v_u_69.Text = v412
								v_u_69.TextColor3 = v415.color.text2
							end
							v_u_105()
							v_u_76.panel = nil
							v_u_73 = nil
							if v_u_72 then
								v_u_72:Destroy()
								v_u_72 = nil
							end
							v_u_105()
							v_u_76.loading = false
							if not v_u_76.loading then
								v_u_76.loading = true
								local v_u_416 = v_u_75
								v_u_76.status = "Loading ..."
								v_u_76.statusBad = false
								if v_u_69 then
									local v417 = script.Parent
									local v418 = require(v417:WaitForChild("HushUI"))
									require(v417:WaitForChild("ReviewDeskPlan"))
									local v419 = v418.Theme
									v_u_69.Text = "Loading ..."
									v_u_69.TextColor3 = v419.color.text2
								end
								v_u_105()
								v_u_139()
								local v_u_420 = true
								task.spawn(function()
									-- upvalues: (ref) v_u_91, (copy) v_u_420, (copy) v_u_416, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
									local v421 = v_u_91("reviewList", {
										["force"] = v_u_420 == true
									})
									if v_u_416 ~= v_u_75 then
										return
									end
									v_u_76.loading = false
									local v422, v423, v424, v425, v426
									if v421.ok == true then
										local v427 = v421.rows
										if type(v427) == "table" then
											v_u_76.rows = v421.rows
											local v428 = v_u_76
											local v429 = v421.now
											v428.now = tonumber(v429) or os.time()
											local v430 = v_u_76
											local v431 = v421.minWatchSec
											v430.minWatch = tonumber(v431) or 180
											v_u_76.role = v421.role
											v_u_76.loaded = true
											v_u_76.truncated = v421.truncated == true
											local v432 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
											local v433 = v_u_76.truncated
											v_u_76.status = v432
											v_u_76.statusBad = v433 == true
											if v_u_69 then
												local v434 = script.Parent
												local v435 = require(v434:WaitForChild("HushUI"))
												require(v434:WaitForChild("ReviewDeskPlan"))
												local v436 = v435.Theme
												v_u_69.Text = v432
												local v437 = v_u_69
												local v438
												if v433 then
													v438 = v436.color.danger
												else
													v438 = v436.color.text2
												end
												v437.TextColor3 = v438
											end
											v_u_105()
											v_u_139()
											v_u_105()
										else
											v_u_76.loaded = v_u_76.loaded and true or false
											v422 = v421.msg or v_u_4().TEXT.LOAD_FAIL
											v423 = tostring(v422)
											v_u_76.status = v423
											v_u_76.statusBad = true
											if v_u_69 then
												v424 = script.Parent
												v425 = require(v424:WaitForChild("HushUI"))
												require(v424:WaitForChild("ReviewDeskPlan"))
												v426 = v425.Theme
												v_u_69.Text = v423
												v_u_69.TextColor3 = v426.color.danger
											end
											v_u_105()
											v_u_139()
											v_u_105()
										end
									else
										v_u_76.loaded = v_u_76.loaded and true or false
										v422 = v421.msg or v_u_4().TEXT.LOAD_FAIL
										v423 = tostring(v422)
										v_u_76.status = v423
										v_u_76.statusBad = true
										if v_u_69 then
											v424 = script.Parent
											v425 = require(v424:WaitForChild("HushUI"))
											require(v424:WaitForChild("ReviewDeskPlan"))
											v426 = v425.Theme
											v_u_69.Text = v423
											v_u_69.TextColor3 = v426.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
										return
									end
								end)
							end
						else
							local v439 = v410.msg or "Refused."
							local v440 = tostring(v439)
							v_u_76.status = v440
							v_u_76.statusBad = true
							if v_u_69 then
								local v441 = script.Parent
								local v442 = require(v441:WaitForChild("HushUI"))
								require(v441:WaitForChild("ReviewDeskPlan"))
								local v443 = v442.Theme
								v_u_69.Text = v440
								v_u_69.TextColor3 = v443.color.danger
							end
							v_u_105()
							return
						end
					else
						return
					end
				end)
			end
		end
		v_u_382 = v_u_136(v355, v357, v372, "Send", v369.send, v_u_359.TEXT.BTN_SEND, v369.btnSize, "secondary", v444)
		v_u_382.ZIndex = 22
		v_u_73 = {
			["pick"] = function(p445) -- name: pick
				-- upvalues: (copy) v_u_359, (ref) v_u_76, (copy) v_u_393
				if v_u_359.VERDICT_TEXT[p445] ~= nil then
					v_u_76.panel.pick = p445
					v_u_393()
				end
			end,
			["note"] = function(p446) -- name: note
				-- upvalues: (ref) v_u_76, (copy) v_u_401
				v_u_76.panel.comment = p446
				v_u_401.Text = p446
			end,
			["send"] = v444,
			["cancel"] = v403
		}
		v_u_393()
	end
end
local function v_u_531(p_u_447) -- name: studioHook
	-- upvalues: (copy) v_u_63, (ref) v_u_71, (copy) v_u_76, (ref) v_u_67, (ref) v_u_140, (ref) v_u_75, (ref) v_u_69, (copy) v_u_105, (ref) v_u_139, (copy) v_u_91, (copy) v_u_4, (ref) v_u_70, (ref) v_u_141, (copy) v_u_1, (ref) v_u_73, (copy) v_u_155, (copy) v_u_233
	if v_u_63:IsStudio() and p_u_447 then
		local v448 = v_u_71
		local v449 = p_u_447:GetAttributeChangedSignal("ReviewDeskCmd")
		local function v530()
			-- upvalues: (copy) p_u_447, (ref) v_u_76, (ref) v_u_67, (ref) v_u_140, (ref) v_u_75, (ref) v_u_69, (ref) v_u_105, (ref) v_u_139, (ref) v_u_91, (ref) v_u_4, (ref) v_u_70, (ref) v_u_141, (ref) v_u_1, (ref) v_u_73, (ref) v_u_155, (ref) v_u_233
			local v450 = p_u_447:GetAttribute("ReviewDeskCmd")
			if type(v450) == "string" and v450 ~= "" then
				p_u_447:SetAttribute("ReviewDeskCmd", nil)
				local v451, v452 = string.match(v450, "^(%a+)%s*(.-)$")
				if v451 == "tab" then
					local v453 = tonumber(v452) or 1
					if v_u_76.tab == v453 and v_u_67 then
						return
					else
						v_u_76.tab = v453
						v_u_76.panel = nil
						v_u_140()
						if v453 == 1 then
							if not v_u_76.loading then
								v_u_76.loading = true
								local v_u_454 = v_u_75
								v_u_76.status = "Loading ..."
								v_u_76.statusBad = false
								if v_u_69 then
									local v455 = script.Parent
									local v456 = require(v455:WaitForChild("HushUI"))
									require(v455:WaitForChild("ReviewDeskPlan"))
									local v457 = v456.Theme
									v_u_69.Text = "Loading ..."
									v_u_69.TextColor3 = v457.color.text2
								end
								v_u_105()
								v_u_139()
								local v_u_458 = false
								task.spawn(function()
									-- upvalues: (ref) v_u_91, (copy) v_u_458, (copy) v_u_454, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
									local v459 = v_u_91("reviewList", {
										["force"] = v_u_458 == true
									})
									if v_u_454 ~= v_u_75 then
										return
									end
									v_u_76.loading = false
									local v460, v461, v462, v463, v464
									if v459.ok == true then
										local v465 = v459.rows
										if type(v465) == "table" then
											v_u_76.rows = v459.rows
											local v466 = v_u_76
											local v467 = v459.now
											v466.now = tonumber(v467) or os.time()
											local v468 = v_u_76
											local v469 = v459.minWatchSec
											v468.minWatch = tonumber(v469) or 180
											v_u_76.role = v459.role
											v_u_76.loaded = true
											v_u_76.truncated = v459.truncated == true
											local v470 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
											local v471 = v_u_76.truncated
											v_u_76.status = v470
											v_u_76.statusBad = v471 == true
											if v_u_69 then
												local v472 = script.Parent
												local v473 = require(v472:WaitForChild("HushUI"))
												require(v472:WaitForChild("ReviewDeskPlan"))
												local v474 = v473.Theme
												v_u_69.Text = v470
												local v475 = v_u_69
												local v476
												if v471 then
													v476 = v474.color.danger
												else
													v476 = v474.color.text2
												end
												v475.TextColor3 = v476
											end
											v_u_105()
											v_u_139()
											v_u_105()
										else
											v_u_76.loaded = v_u_76.loaded and true or false
											v460 = v459.msg or v_u_4().TEXT.LOAD_FAIL
											v461 = tostring(v460)
											v_u_76.status = v461
											v_u_76.statusBad = true
											if v_u_69 then
												v462 = script.Parent
												v463 = require(v462:WaitForChild("HushUI"))
												require(v462:WaitForChild("ReviewDeskPlan"))
												v464 = v463.Theme
												v_u_69.Text = v461
												v_u_69.TextColor3 = v464.color.danger
											end
											v_u_105()
											v_u_139()
											v_u_105()
										end
									else
										v_u_76.loaded = v_u_76.loaded and true or false
										v460 = v459.msg or v_u_4().TEXT.LOAD_FAIL
										v461 = tostring(v460)
										v_u_76.status = v461
										v_u_76.statusBad = true
										if v_u_69 then
											v462 = script.Parent
											v463 = require(v462:WaitForChild("HushUI"))
											require(v462:WaitForChild("ReviewDeskPlan"))
											v464 = v463.Theme
											v_u_69.Text = v461
											v_u_69.TextColor3 = v464.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
										return
									end
								end)
							end
						elseif v453 == 2 then
							v_u_76.mineLoaded = false
							if not v_u_76.loading then
								v_u_76.loading = true
								local v_u_477 = v_u_75
								v_u_76.status = "Loading ..."
								v_u_76.statusBad = false
								if v_u_69 then
									local v478 = script.Parent
									local v479 = require(v478:WaitForChild("HushUI"))
									require(v478:WaitForChild("ReviewDeskPlan"))
									local v480 = v479.Theme
									v_u_69.Text = "Loading ..."
									v_u_69.TextColor3 = v480.color.text2
								end
								v_u_105()
								v_u_139()
								task.spawn(function()
									-- upvalues: (ref) v_u_91, (copy) v_u_477, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
									local v481 = v_u_91("reviewMine", {})
									if v_u_477 ~= v_u_75 then
										return
									end
									v_u_76.loading = false
									local v482, v483, v484, v485, v486
									if v481.ok == true then
										local v487 = v481.rows
										if type(v487) == "table" then
											v_u_76.mine = v481.rows
											v_u_76.mineLoaded = true
											v_u_76.status = ""
											v_u_76.statusBad = false
											if v_u_69 then
												local v488 = script.Parent
												local v489 = require(v488:WaitForChild("HushUI"))
												require(v488:WaitForChild("ReviewDeskPlan"))
												local v490 = v489.Theme
												v_u_69.Text = ""
												v_u_69.TextColor3 = v490.color.text2
											end
											v_u_105()
											v_u_139()
											v_u_105()
										else
											v482 = v481.msg or v_u_4().TEXT.LOAD_FAIL
											v483 = tostring(v482)
											v_u_76.status = v483
											v_u_76.statusBad = true
											if v_u_69 then
												v484 = script.Parent
												v485 = require(v484:WaitForChild("HushUI"))
												require(v484:WaitForChild("ReviewDeskPlan"))
												v486 = v485.Theme
												v_u_69.Text = v483
												v_u_69.TextColor3 = v486.color.danger
											end
											v_u_105()
											v_u_139()
											v_u_105()
										end
									else
										v482 = v481.msg or v_u_4().TEXT.LOAD_FAIL
										v483 = tostring(v482)
										v_u_76.status = v483
										v_u_76.statusBad = true
										if v_u_69 then
											v484 = script.Parent
											v485 = require(v484:WaitForChild("HushUI"))
											require(v484:WaitForChild("ReviewDeskPlan"))
											v486 = v485.Theme
											v_u_69.Text = v483
											v_u_69.TextColor3 = v486.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
										return
									end
								end)
							end
						else
							v_u_139()
							return
						end
					end
				elseif v451 == "search" then
					if v_u_70 then
						v_u_70.Text = v452
					end
					v_u_76.query = v452
					v_u_139()
				elseif v451 == "reload" then
					if v_u_76.tab == 1 then
						if not v_u_76.loading then
							v_u_76.loading = true
							local v_u_491 = v_u_75
							v_u_76.status = "Loading ..."
							v_u_76.statusBad = false
							if v_u_69 then
								local v492 = script.Parent
								local v493 = require(v492:WaitForChild("HushUI"))
								require(v492:WaitForChild("ReviewDeskPlan"))
								local v494 = v493.Theme
								v_u_69.Text = "Loading ..."
								v_u_69.TextColor3 = v494.color.text2
							end
							v_u_105()
							v_u_139()
							local v_u_495 = true
							task.spawn(function()
								-- upvalues: (ref) v_u_91, (copy) v_u_495, (copy) v_u_491, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
								local v496 = v_u_91("reviewList", {
									["force"] = v_u_495 == true
								})
								if v_u_491 ~= v_u_75 then
									return
								end
								v_u_76.loading = false
								local v497, v498, v499, v500, v501
								if v496.ok == true then
									local v502 = v496.rows
									if type(v502) == "table" then
										v_u_76.rows = v496.rows
										local v503 = v_u_76
										local v504 = v496.now
										v503.now = tonumber(v504) or os.time()
										local v505 = v_u_76
										local v506 = v496.minWatchSec
										v505.minWatch = tonumber(v506) or 180
										v_u_76.role = v496.role
										v_u_76.loaded = true
										v_u_76.truncated = v496.truncated == true
										local v507 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
										local v508 = v_u_76.truncated
										v_u_76.status = v507
										v_u_76.statusBad = v508 == true
										if v_u_69 then
											local v509 = script.Parent
											local v510 = require(v509:WaitForChild("HushUI"))
											require(v509:WaitForChild("ReviewDeskPlan"))
											local v511 = v510.Theme
											v_u_69.Text = v507
											local v512 = v_u_69
											local v513
											if v508 then
												v513 = v511.color.danger
											else
												v513 = v511.color.text2
											end
											v512.TextColor3 = v513
										end
										v_u_105()
										v_u_139()
										v_u_105()
									else
										v_u_76.loaded = v_u_76.loaded and true or false
										v497 = v496.msg or v_u_4().TEXT.LOAD_FAIL
										v498 = tostring(v497)
										v_u_76.status = v498
										v_u_76.statusBad = true
										if v_u_69 then
											v499 = script.Parent
											v500 = require(v499:WaitForChild("HushUI"))
											require(v499:WaitForChild("ReviewDeskPlan"))
											v501 = v500.Theme
											v_u_69.Text = v498
											v_u_69.TextColor3 = v501.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
									end
								else
									v_u_76.loaded = v_u_76.loaded and true or false
									v497 = v496.msg or v_u_4().TEXT.LOAD_FAIL
									v498 = tostring(v497)
									v_u_76.status = v498
									v_u_76.statusBad = true
									if v_u_69 then
										v499 = script.Parent
										v500 = require(v499:WaitForChild("HushUI"))
										require(v499:WaitForChild("ReviewDeskPlan"))
										v501 = v500.Theme
										v_u_69.Text = v498
										v_u_69.TextColor3 = v501.color.danger
									end
									v_u_105()
									v_u_139()
									v_u_105()
									return
								end
							end)
						end
					end
					if v_u_76.tab == 2 then
						if not v_u_76.loading then
							v_u_76.loading = true
							local v_u_514 = v_u_75
							v_u_76.status = "Loading ..."
							v_u_76.statusBad = false
							if v_u_69 then
								local v515 = script.Parent
								local v516 = require(v515:WaitForChild("HushUI"))
								require(v515:WaitForChild("ReviewDeskPlan"))
								local v517 = v516.Theme
								v_u_69.Text = "Loading ..."
								v_u_69.TextColor3 = v517.color.text2
							end
							v_u_105()
							v_u_139()
							task.spawn(function()
								-- upvalues: (ref) v_u_91, (copy) v_u_514, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
								local v518 = v_u_91("reviewMine", {})
								if v_u_514 ~= v_u_75 then
									return
								end
								v_u_76.loading = false
								local v519, v520, v521, v522, v523
								if v518.ok == true then
									local v524 = v518.rows
									if type(v524) == "table" then
										v_u_76.mine = v518.rows
										v_u_76.mineLoaded = true
										v_u_76.status = ""
										v_u_76.statusBad = false
										if v_u_69 then
											local v525 = script.Parent
											local v526 = require(v525:WaitForChild("HushUI"))
											require(v525:WaitForChild("ReviewDeskPlan"))
											local v527 = v526.Theme
											v_u_69.Text = ""
											v_u_69.TextColor3 = v527.color.text2
										end
										v_u_105()
										v_u_139()
										v_u_105()
									else
										v519 = v518.msg or v_u_4().TEXT.LOAD_FAIL
										v520 = tostring(v519)
										v_u_76.status = v520
										v_u_76.statusBad = true
										if v_u_69 then
											v521 = script.Parent
											v522 = require(v521:WaitForChild("HushUI"))
											require(v521:WaitForChild("ReviewDeskPlan"))
											v523 = v522.Theme
											v_u_69.Text = v520
											v_u_69.TextColor3 = v523.color.danger
										end
										v_u_105()
										v_u_139()
										v_u_105()
									end
								else
									v519 = v518.msg or v_u_4().TEXT.LOAD_FAIL
									v520 = tostring(v519)
									v_u_76.status = v520
									v_u_76.statusBad = true
									if v_u_69 then
										v521 = script.Parent
										v522 = require(v521:WaitForChild("HushUI"))
										require(v521:WaitForChild("ReviewDeskPlan"))
										v523 = v522.Theme
										v_u_69.Text = v520
										v_u_69.TextColor3 = v523.color.danger
									end
									v_u_105()
									v_u_139()
									v_u_105()
									return
								end
							end)
						end
					end
				else
					if v451 == "verdict" then
						local v528 = tonumber(v452)
						for _, v529 in v_u_76.rows do
							if v529.userId ~= v528 then
								continue
							end
							v_u_76.panel = nil
							v_u_141(v_u_1.cardSpec(v529, v_u_76.now))
						end
						return
					end
					if v451 == "pick" and v_u_73 then
						v_u_73.pick(v452)
						return
					end
					if v451 == "note" and v_u_73 then
						v_u_73.note(v452)
						return
					end
					if v451 == "send" and v_u_73 then
						v_u_73.send()
						return
					end
					if v451 == "cancel" and v_u_73 then
						v_u_73.cancel()
						return
					end
					if v451 == "join" then
						v_u_155("reviewJoin", tonumber(v452) or 0)
						return
					end
					if v451 == "follow" then
						v_u_155("reviewFollow", tonumber(v452) or 0)
						return
					end
					if v451 == "close" then
						v_u_233()
					end
				end
			else
				return
			end
		end
		table.insert(v448, v449:Connect(v530))
	end
end
function v_u_1.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_65
	return v_u_65 ~= nil
end
function v_u_1.close() -- name: close
	-- upvalues: (ref) v_u_65, (copy) v_u_233
	if v_u_65 then
		v_u_233()
	end
end
function v_u_1.open(p532) -- name: open
	-- upvalues: (ref) v_u_65, (copy) v_u_61, (ref) v_u_74, (ref) v_u_75, (copy) v_u_76, (ref) v_u_66, (ref) v_u_67, (ref) v_u_71, (ref) v_u_352, (copy) v_u_64, (ref) v_u_73, (copy) v_u_233, (ref) v_u_69, (copy) v_u_105, (ref) v_u_139, (copy) v_u_91, (copy) v_u_4, (copy) v_u_531, (ref) v_u_140
	if v_u_65 then
		return
	else
		local v533 = v_u_61.LocalPlayer
		if v533 and v533:GetAttribute("OverwatchReviewer") == true then
			v_u_74 = p532
			local v534 = script.Parent
			local v535 = require(v534:WaitForChild("HushUI"))
			require(v534:WaitForChild("ReviewDeskPlan"))
			local v536 = v535.Theme
			v_u_75 = v_u_75 + 1
			v_u_76.panel = nil
			v_u_76.loading = false
			v_u_76.status = ""
			v_u_76.statusBad = false
			local v537, v538 = v535.screen("ReviewDesk", 40)
			v_u_65 = v537
			v_u_66 = v538
			v535.new("Frame", {
				["Name"] = "Dim",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.45,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Active"] = true,
				["BackgroundColor3"] = v536.color.black,
				["Size"] = UDim2.fromScale(1, 1)
			}, v_u_66)
			v_u_67 = v535.new("Frame", {
				["Name"] = "Window",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = v536.color.bg,
				["BackgroundTransparency"] = v536.alpha.panel
			}, v_u_66)
			v535.stroke(v_u_67, v536.color.line, 1, 0)
			local v539 = v_u_71
			local v540 = v_u_66:GetPropertyChangedSignal("AbsoluteSize")
			local v541 = v_u_352
			table.insert(v539, v540:Connect(v541))
			local v542 = v_u_71
			local v543 = v536.scaleChanged
			local v544 = v_u_352
			table.insert(v542, v543:Connect(v544))
			local v545 = v_u_71
			local v546 = v_u_64.InputBegan
			local function v548(p547, _)
				-- upvalues: (ref) v_u_64, (ref) v_u_76, (ref) v_u_73, (ref) v_u_233
				if p547.UserInputType == Enum.UserInputType.Keyboard and (p547.KeyCode == Enum.KeyCode.Escape and not v_u_64:GetFocusedTextBox()) then
					if v_u_76.panel and v_u_73 then
						v_u_73.cancel()
						return
					end
					v_u_233()
				end
			end
			table.insert(v545, v546:Connect(v548))
			if p532 and p532.net then
				local v549 = p532.net.listen
				if type(v549) == "function" then
					local v550 = p532.net.listen
					local function v560(p551)
						-- upvalues: (ref) v_u_76, (ref) v_u_69, (ref) v_u_105
						if type(p551) == "table" and (p551.op == "reviewJoin" or (p551.op == "reviewFollow" or p551.op == "reviewStopFollow")) then
							v_u_76.liveAnswered = true
							if p551.msg and p551.msg ~= "" then
								local v552 = p551.msg
								local v553 = tostring(v552)
								local v554 = p551.ok ~= true
								v_u_76.status = v553
								v_u_76.statusBad = v554 == true
								if v_u_69 then
									local v555 = script.Parent
									local v556 = require(v555:WaitForChild("HushUI"))
									require(v555:WaitForChild("ReviewDeskPlan"))
									local v557 = v556.Theme
									v_u_69.Text = v553
									local v558 = v_u_69
									local v559
									if v554 then
										v559 = v557.color.danger
									else
										v559 = v557.color.text2
									end
									v558.TextColor3 = v559
								end
								v_u_105()
							end
						end
					end
					local v561, v562 = pcall(v550, "menu.result", v560)
					if v561 and v562 then
						local v563 = v_u_71
						table.insert(v563, v562)
					end
				end
			end
			local v_u_564 = v_u_75
			task.spawn(function()
				-- upvalues: (ref) v_u_65, (copy) v_u_564, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_139, (ref) v_u_91, (ref) v_u_4
				while v_u_65 and v_u_564 == v_u_75 do
					task.wait(30)
					if not v_u_65 or (v_u_564 ~= v_u_75 or (v_u_76.tab ~= 1 or (v_u_76.panel or (v_u_76.loading or v_u_76.loading)))) then
						continue
					end
					v_u_76.loading = true
					local v_u_565 = v_u_75
					v_u_76.status = "Loading ..."
					v_u_76.statusBad = false
					if v_u_69 then
						local v566 = script.Parent
						local v567 = require(v566:WaitForChild("HushUI"))
						require(v566:WaitForChild("ReviewDeskPlan"))
						local v568 = v567.Theme
						v_u_69.Text = "Loading ..."
						v_u_69.TextColor3 = v568.color.text2
					end
					v_u_105()
					v_u_139()
					local v_u_569 = false
					task.spawn(function()
						-- upvalues: (ref) v_u_91, (copy) v_u_569, (copy) v_u_565, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
						local v570 = v_u_91("reviewList", {
							["force"] = v_u_569 == true
						})
						if v_u_565 ~= v_u_75 then
							return
						end
						v_u_76.loading = false
						local v571, v572, v573, v574, v575
						if v570.ok == true then
							local v576 = v570.rows
							if type(v576) == "table" then
								v_u_76.rows = v570.rows
								local v577 = v_u_76
								local v578 = v570.now
								v577.now = tonumber(v578) or os.time()
								local v579 = v_u_76
								local v580 = v570.minWatchSec
								v579.minWatch = tonumber(v580) or 180
								v_u_76.role = v570.role
								v_u_76.loaded = true
								v_u_76.truncated = v570.truncated == true
								local v581 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
								local v582 = v_u_76.truncated
								v_u_76.status = v581
								v_u_76.statusBad = v582 == true
								if v_u_69 then
									local v583 = script.Parent
									local v584 = require(v583:WaitForChild("HushUI"))
									require(v583:WaitForChild("ReviewDeskPlan"))
									local v585 = v584.Theme
									v_u_69.Text = v581
									local v586 = v_u_69
									local v587
									if v582 then
										v587 = v585.color.danger
									else
										v587 = v585.color.text2
									end
									v586.TextColor3 = v587
								end
								v_u_105()
								v_u_139()
								v_u_105()
							else
								v_u_76.loaded = v_u_76.loaded and true or false
								v571 = v570.msg or v_u_4().TEXT.LOAD_FAIL
								v572 = tostring(v571)
								v_u_76.status = v572
								v_u_76.statusBad = true
								if v_u_69 then
									v573 = script.Parent
									v574 = require(v573:WaitForChild("HushUI"))
									require(v573:WaitForChild("ReviewDeskPlan"))
									v575 = v574.Theme
									v_u_69.Text = v572
									v_u_69.TextColor3 = v575.color.danger
								end
								v_u_105()
								v_u_139()
								v_u_105()
							end
						else
							v_u_76.loaded = v_u_76.loaded and true or false
							v571 = v570.msg or v_u_4().TEXT.LOAD_FAIL
							v572 = tostring(v571)
							v_u_76.status = v572
							v_u_76.statusBad = true
							if v_u_69 then
								v573 = script.Parent
								v574 = require(v573:WaitForChild("HushUI"))
								require(v573:WaitForChild("ReviewDeskPlan"))
								v575 = v574.Theme
								v_u_69.Text = v572
								v_u_69.TextColor3 = v575.color.danger
							end
							v_u_105()
							v_u_139()
							v_u_105()
							return
						end
					end)
				end
			end)
			v_u_531(v533)
			v_u_140()
			if not v_u_76.loading then
				v_u_76.loading = true
				local v_u_588 = v_u_75
				v_u_76.status = "Loading ..."
				v_u_76.statusBad = false
				if v_u_69 then
					local v589 = script.Parent
					local v590 = require(v589:WaitForChild("HushUI"))
					require(v589:WaitForChild("ReviewDeskPlan"))
					local v591 = v590.Theme
					v_u_69.Text = "Loading ..."
					v_u_69.TextColor3 = v591.color.text2
				end
				v_u_105()
				v_u_139()
				local v_u_592 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_91, (copy) v_u_592, (copy) v_u_588, (ref) v_u_75, (ref) v_u_76, (ref) v_u_69, (ref) v_u_105, (ref) v_u_4, (ref) v_u_139
					local v593 = v_u_91("reviewList", {
						["force"] = v_u_592 == true
					})
					if v_u_588 ~= v_u_75 then
						return
					end
					v_u_76.loading = false
					local v594, v595, v596, v597, v598
					if v593.ok == true then
						local v599 = v593.rows
						if type(v599) == "table" then
							v_u_76.rows = v593.rows
							local v600 = v_u_76
							local v601 = v593.now
							v600.now = tonumber(v601) or os.time()
							local v602 = v_u_76
							local v603 = v593.minWatchSec
							v602.minWatch = tonumber(v603) or 180
							v_u_76.role = v593.role
							v_u_76.loaded = true
							v_u_76.truncated = v593.truncated == true
							local v604 = v_u_76.truncated and "Some entries could not be refreshed this time. Press RELOAD in a minute." or ""
							local v605 = v_u_76.truncated
							v_u_76.status = v604
							v_u_76.statusBad = v605 == true
							if v_u_69 then
								local v606 = script.Parent
								local v607 = require(v606:WaitForChild("HushUI"))
								require(v606:WaitForChild("ReviewDeskPlan"))
								local v608 = v607.Theme
								v_u_69.Text = v604
								local v609 = v_u_69
								local v610
								if v605 then
									v610 = v608.color.danger
								else
									v610 = v608.color.text2
								end
								v609.TextColor3 = v610
							end
							v_u_105()
							v_u_139()
							v_u_105()
						else
							v_u_76.loaded = v_u_76.loaded and true or false
							v594 = v593.msg or v_u_4().TEXT.LOAD_FAIL
							v595 = tostring(v594)
							v_u_76.status = v595
							v_u_76.statusBad = true
							if v_u_69 then
								v596 = script.Parent
								v597 = require(v596:WaitForChild("HushUI"))
								require(v596:WaitForChild("ReviewDeskPlan"))
								v598 = v597.Theme
								v_u_69.Text = v595
								v_u_69.TextColor3 = v598.color.danger
							end
							v_u_105()
							v_u_139()
							v_u_105()
						end
					else
						v_u_76.loaded = v_u_76.loaded and true or false
						v594 = v593.msg or v_u_4().TEXT.LOAD_FAIL
						v595 = tostring(v594)
						v_u_76.status = v595
						v_u_76.statusBad = true
						if v_u_69 then
							v596 = script.Parent
							v597 = require(v596:WaitForChild("HushUI"))
							require(v596:WaitForChild("ReviewDeskPlan"))
							v598 = v597.Theme
							v_u_69.Text = v595
							v_u_69.TextColor3 = v598.color.danger
						end
						v_u_105()
						v_u_139()
						v_u_105()
						return
					end
				end)
			end
			v_u_105()
		end
	end
end
function v_u_1.toggle(p611) -- name: toggle
	-- upvalues: (ref) v_u_65, (copy) v_u_233, (copy) v_u_1
	if v_u_65 then
		v_u_233()
	else
		v_u_1.open(p611)
	end
end
return v_u_1