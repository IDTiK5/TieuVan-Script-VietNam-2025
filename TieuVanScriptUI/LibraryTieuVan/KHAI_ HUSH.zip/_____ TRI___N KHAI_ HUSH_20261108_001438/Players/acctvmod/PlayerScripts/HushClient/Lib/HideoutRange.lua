-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutRange

local v1 = {}
local function v_u_7(p2) -- name: biggestPart
	local v3 = -1
	local v4 = nil
	for _, v5 in p2:GetDescendants() do
		if not v5:IsA("BasePart") then
			continue
		end
		local v6 = v5.Size.X * v5.Size.Y
		if v3 >= v6 then
			continue
		end
		v4 = v5
		v3 = v6
	end
	return v4
end
function v1.new(p8, p_u_9, p_u_10, p_u_11) -- name: new
	-- upvalues: (copy) v_u_7
	local v_u_12 = Instance.new("Folder")
	v_u_12.Name = "HideoutRange"
	v_u_12.Parent = p8
	local v13 = p_u_10.lane
	local v_u_14 = (v13.x0 + v13.x1) / 2
	local v_u_15 = p_u_10.rangeFireZ
	local v_u_16 = {}
	local v_u_17 = {}
	local v_u_18 = 0
	local v_u_19 = nil
	local v_u_20 = nil
	local v_u_21 = {}
	local v_u_22 = {
		["shots"] = 0,
		["hits"] = 0,
		["score"] = 0,
		["last"] = 0,
		["head"] = 0
	}
	local function v_u_28(p23, p24) -- name: distSign
		-- upvalues: (copy) v_u_12
		local v25 = Instance.new("Part")
		v25.Name = "DistSign"
		v25.Anchored = true
		v25.CanCollide = false
		v25.CanQuery = false
		v25.CanTouch = false
		v25.CastShadow = false
		v25.Size = Vector3.new(1.6, 0.9, 0.12)
		v25.Color = Color3.fromHex("D9D4C5")
		v25.Material = Enum.Material.SmoothPlastic
		v25.CFrame = CFrame.new(p24) * CFrame.Angles(-0.4363323129985824, 0, 0)
		local v26 = Instance.new("SurfaceGui")
		v26.Face = Enum.NormalId.Back
		v26.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		v26.PixelsPerStud = 50
		v26.LightInfluence = 1
		local v27 = Instance.new("TextLabel")
		v27.BackgroundTransparency = 1
		v27.Size = UDim2.fromScale(1, 1)
		v27.Text = tostring(p23)
		v27.TextScaled = true
		v27.Font = Enum.Font.Oswald
		v27.TextColor3 = Color3.fromHex("1D1F22")
		v27.Parent = v26
		v26.Parent = v25
		v25.Parent = v_u_12
		return v25
	end
	local function v_u_69() -- name: buildTier3
		-- upvalues: (copy) p_u_9, (copy) v_u_14, (copy) v_u_15, (copy) v_u_12
		local v29 = p_u_9.X + v_u_14
		local v30 = p_u_9.Z + v_u_15 - 3.6
		local v31 = p_u_9.Z + v_u_15 - 51.5
		local v32 = v30 - v31
		local v33 = (v30 + v31) / 2
		local v34 = Vector3.new(10.4, 0.08, v32)
		local v35 = CFrame.new(v29, p_u_9.Y + 0.04, v33)
		local v36 = Color3.fromHex("4B4E52")
		local v37 = Enum.Material.Concrete
		local v38 = Instance.new("Part")
		v38.Name = "HardLane"
		v38.Anchored = true
		v38.CanCollide = false
		v38.CanQuery = false
		v38.CanTouch = false
		v38.CastShadow = false
		v38.Size = v34
		v38.CFrame = v35
		v38.Color = v36
		v38.Material = v37
		v38.Parent = v_u_12
		v38:SetAttribute("Tier", 3)
		for _, v39 in { -1, 1 } do
			local v40 = Vector3.new(0.28, 0.02, v32)
			local v41 = CFrame.new(v29 + v39 * 5, p_u_9.Y + 0.09, v33)
			local v42 = Color3.fromHex("D9A52B")
			local v43 = Enum.Material.SmoothPlastic
			local v44 = Instance.new("Part")
			v44.Name = "HardLaneEdge"
			v44.Anchored = true
			v44.CanCollide = false
			v44.CanQuery = false
			v44.CanTouch = false
			v44.CastShadow = false
			v44.Size = v40
			v44.CFrame = v41
			v44.Color = v42
			v44.Material = v43
			v44.Parent = v_u_12
		end
		for _, v45 in { 10, 25, 50 } do
			local v46 = CFrame.new(v29, p_u_9.Y + 0.09, p_u_9.Z + v_u_15 - v45)
			local v47 = Color3.fromHex("D9D4C5")
			local v48 = Enum.Material.SmoothPlastic
			local v49 = Instance.new("Part")
			v49.Name = "HardLaneMark"
			v49.Anchored = true
			v49.CanCollide = false
			v49.CanQuery = false
			v49.CanTouch = false
			v49.CastShadow = false
			v49.Size = Vector3.new(9.6, 0.02, 0.3)
			v49.CFrame = v46
			v49.Color = v47
			v49.Material = v48
			v49.Parent = v_u_12
		end
		local v50 = p_u_9.Z + v_u_15 - 50.7
		for _, v51 in { -1, 1 } do
			local v52 = CFrame.new(v29 + v51 * 5.1, p_u_9.Y + 4.4, v50)
			local v53 = Color3.fromHex("2E3236")
			local v54 = Enum.Material.Metal
			local v55 = Instance.new("Part")
			v55.Name = "BackstopWing"
			v55.Anchored = true
			v55.CanCollide = false
			v55.CanQuery = false
			v55.CanTouch = false
			v55.CastShadow = false
			v55.Size = Vector3.new(0.3, 8.8, 3.4)
			v55.CFrame = v52
			v55.Color = v53
			v55.Material = v54
			v55.Parent = v_u_12
			local v56 = CFrame.new(v29 + v51 * 5.1, p_u_9.Y + 0.15, v50)
			local v57 = Color3.fromHex("1D1F22")
			local v58 = Enum.Material.Metal
			local v59 = Instance.new("Part")
			v59.Name = "BackstopWingFoot"
			v59.Anchored = true
			v59.CanCollide = false
			v59.CanQuery = false
			v59.CanTouch = false
			v59.CastShadow = false
			v59.Size = Vector3.new(0.6, 0.3, 3.6)
			v59.CFrame = v56
			v59.Color = v57
			v59.Material = v58
			v59.Parent = v_u_12
		end
		local v60 = p_u_9.Z + v_u_15 - 49.2
		local v61 = CFrame.new(v29, p_u_9.Y + 8.55, v60)
		local v62 = Color3.fromHex("D9A52B")
		local v63 = Enum.Material.Metal
		local v64 = Instance.new("Part")
		v64.Name = "BackstopLintel"
		v64.Anchored = true
		v64.CanCollide = false
		v64.CanQuery = false
		v64.CanTouch = false
		v64.CastShadow = false
		v64.Size = Vector3.new(10.4, 0.5, 0.5)
		v64.CFrame = v61
		v64.Color = v62
		v64.Material = v63
		v64.Parent = v_u_12
		local v65 = CFrame.new(v29, p_u_9.Y + 9, v50) * CFrame.Angles(0.4886921905584123, 0, 0)
		local v66 = Color3.fromHex("3A3F44")
		local v67 = Enum.Material.Metal
		local v68 = Instance.new("Part")
		v68.Name = "BackstopBaffle"
		v68.Anchored = true
		v68.CanCollide = false
		v68.CanQuery = false
		v68.CanTouch = false
		v68.CastShadow = false
		v68.Size = Vector3.new(10.6, 0.3, 2.8)
		v68.CFrame = v65
		v68.Color = v66
		v68.Material = v67
		v68.Parent = v_u_12
	end
	local function v_u_102() -- name: buildTargets
		-- upvalues: (copy) v_u_16, (copy) v_u_12, (ref) v_u_18, (copy) p_u_10, (copy) p_u_11, (ref) v_u_7, (copy) p_u_9, (copy) v_u_14, (copy) v_u_15, (copy) v_u_28, (copy) v_u_69
		for _, v70 in v_u_16 do
			v70.model:Destroy()
		end
		table.clear(v_u_16)
		for _, v71 in v_u_12:GetChildren() do
			v71:Destroy()
		end
		if v_u_18 > 0 then
			for v72, v73 in p_u_10.rangeTargets or { 10, 25, 50 } do
				local v_u_74 = p_u_11
				if v_u_74 then
					v_u_74 = p_u_11.get("Hideout", "range_target")
				end
				if not (v_u_74 and v_u_74:IsA("Model")) then
					continue
				end
				v_u_74.Name = "Target_" .. v73
				local v75 = v_u_74:FindFirstChild("Face", true)
				if not (v75 and v75:IsA("BasePart")) then
					v75 = v_u_7(v_u_74)
				end
				if v75 then
					for _, v76 in v_u_74:GetDescendants() do
						if not v76:IsA("BasePart") then
							continue
						end
						v76.Anchored = true
						v76.CanCollide = false
						v76.CanQuery = true
						v76.CanTouch = false
					end
					local v77 = CFrame.new
					local v78 = p_u_9
					local v79 = v_u_14
					local v80 = v_u_15 - v73
					local v81 = v77(v78 + Vector3.new(v79, 0, v80)) * CFrame.Angles(0, 3.141592653589793, 0)
					v_u_74:PivotTo(v81)
					if v_u_18 >= 3 and v73 >= 50 then
						local v82, v83 = pcall(function()
							return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush", 2):WaitForChild("Shared", 2):WaitForChild("Config", 2)).flag("RangeTier3")
						end)
						if not v82 or v83 ~= false then
							pcall(function()
								-- upvalues: (copy) v_u_74
								v_u_74:ScaleTo(1.4)
							end)
							local v84 = CFrame.new
							local v85 = p_u_9
							local v86 = v_u_14
							local v87 = v_u_15 - v73 + 3
							local v88 = v84(v85 + Vector3.new(v86, 9.2, v87))
							local v89 = Color3.fromHex("FFF2C2")
							local v90 = Enum.Material.Neon
							local v91 = Instance.new("Part")
							v91.Name = "LongRangeLamp"
							v91.Anchored = true
							v91.CanCollide = false
							v91.CanQuery = false
							v91.CanTouch = false
							v91.CastShadow = false
							v91.Size = Vector3.new(0.4, 0.4, 0.4)
							v91.CFrame = v88
							v91.Color = v89
							v91.Material = v90
							v91.Parent = v_u_12
							local v92 = Instance.new("PointLight")
							v92.Range = 14
							v92.Brightness = 1
							v92.Color = Color3.fromHex("FFF2C2")
							v92.Parent = v91
						end
					end
					v_u_74.Parent = v_u_12
					local v93 = v_u_28
					local v94 = p_u_9
					local v95 = v_u_14 + 2.2
					local v96 = v_u_15 - v73 + 1.2
					v93(v73, v94 + Vector3.new(v95, 0.5, v96))
					local v97 = v_u_16
					local v98 = {
						["model"] = nil,
						["face"] = nil,
						["base"] = nil,
						["dist"] = nil,
						["ang"] = 0,
						["vel"] = 0,
						["holes"] = nil,
						["moving"] = nil,
						["phase"] = 0,
						["model"] = v_u_74,
						["face"] = v75,
						["base"] = v81,
						["dist"] = v73,
						["holes"] = {}
					}
					local v99
					if v_u_18 >= 2 then
						v99 = v72 == 2
					else
						v99 = false
					end
					v98.moving = v99
					table.insert(v97, v98)
				else
					v_u_74:Destroy()
				end
			end
			if v_u_18 >= 3 then
				local v100, v101 = pcall(function()
					return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush", 2):WaitForChild("Shared", 2):WaitForChild("Config", 2)).flag("RangeTier3")
				end)
				if not v100 or v101 ~= false then
					v_u_69()
				end
			end
		end
	end
	local function v_u_116(p103, p104, p105) -- name: drawMapDot
		-- upvalues: (ref) v_u_20, (copy) v_u_21
		local v106 = v_u_20
		if v106 then
			local v107 = Instance.new("Frame")
			v107.AnchorPoint = Vector2.new(0.5, 0.5)
			v107.Size = UDim2.fromOffset(9, 9)
			v107.Position = UDim2.fromScale(p103 + 0.5, p104 + 0.5)
			local v108
			if p105 then
				v108 = Color3.fromHex("D8453B")
			else
				v108 = Color3.fromHex("1D1F22")
			end
			v107.BackgroundColor3 = v108
			v107.BorderSizePixel = 0
			local v109 = Instance.new("UICorner")
			v109.CornerRadius = UDim.new(1, 0)
			v109.Parent = v107
			v107.Parent = v106:FindFirstChild("Sheet") or v106
			local v110 = v_u_21
			table.insert(v110, v107)
			while #v_u_21 > 40 do
				local v111 = table.remove(v_u_21, 1)
				if not v111 then
					continue
				end
				v111:Destroy()
			end
			for v112, v113 in v_u_21 do
				if v113 == v107 then
					continue
				end
				local v114 = (#v_u_21 - v112) * 0.02 + 0.1
				v113.BackgroundTransparency = math.clamp(v114, 0, 0.7)
			end
			local v115
			if p105 then
				v115 = Color3.fromHex("D8453B")
			else
				v115 = Color3.fromHex("E8A33D")
			end
			v107.BackgroundColor3 = v115
		end
	end
	local function v_u_124(p117, p118, p119) -- name: popup
		-- upvalues: (copy) v_u_12, (copy) v_u_17
		local v120 = Instance.new("BillboardGui")
		v120.Size = UDim2.fromOffset(120, 40)
		v120.StudsOffsetWorldSpace = Vector3.new(0, 0.6, 0)
		v120.AlwaysOnTop = true
		v120.LightInfluence = 0
		v120.MaxDistance = 400
		local v121 = Instance.new("Part")
		v121.Name = "PopupAnchor"
		v121.Anchored = true
		v121.CanCollide = false
		v121.CanQuery = false
		v121.CanTouch = false
		v121.Transparency = 1
		v121.Size = Vector3.new(0.1, 0.1, 0.1)
		v121.CFrame = CFrame.new(p117)
		v121.Parent = v_u_12
		local v122 = Instance.new("TextLabel")
		v122.BackgroundTransparency = 1
		v122.Size = UDim2.fromScale(1, 1)
		v122.Text = p118
		v122.TextColor3 = p119
		v122.TextStrokeTransparency = 0.4
		v122.TextStrokeColor3 = Color3.fromHex("07090C")
		v122.FontFace = Font.fromName("Oswald", Enum.FontWeight.Bold)
		v122.TextSize = 26
		v122.Parent = v120
		v120.Adornee = v121
		v120.Parent = v121
		local v123 = v_u_17
		table.insert(v123, {
			["gui"] = nil,
			["label"] = nil,
			["t"] = 0,
			["gui"] = v120,
			["label"] = v122
		})
	end
	local v181 = {
		["setLevel"] = function(p125) -- name: setLevel
			-- upvalues: (ref) v_u_18, (copy) v_u_16, (copy) v_u_102
			if p125 ~= v_u_18 or #v_u_16 <= 0 then
				v_u_18 = p125
				v_u_102()
			end
		end,
		["setHitMap"] = function(p126) -- name: setHitMap
			-- upvalues: (ref) v_u_20, (copy) v_u_21, (ref) v_u_19
			if v_u_20 then
				v_u_20:Destroy()
				v_u_20 = nil
			end
			table.clear(v_u_21)
			v_u_19 = p126
			if p126 then
				local v127 = Instance.new("SurfaceGui")
				v127.Name = "HitMapGui"
				v127.Face = Enum.NormalId.Front
				v127.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
				v127.PixelsPerStud = 60
				v127.LightInfluence = 1
				local v128 = Instance.new("Frame")
				v128.Name = "Sheet"
				v128.AnchorPoint = Vector2.new(0.5, 0.5)
				v128.Position = UDim2.fromScale(0.5, 0.5)
				v128.Size = UDim2.fromScale(0.55, 0.9)
				v128.BackgroundTransparency = 1
				v128.Parent = v127
				local v129 = Instance.new("Frame")
				v129.AnchorPoint = Vector2.new(0.5, 0)
				v129.Position = UDim2.fromScale(0.5, 0.36)
				v129.Size = UDim2.fromScale(0.62, 0.62)
				v129.BackgroundColor3 = Color3.fromHex("2A2C2E")
				v129.BackgroundTransparency = 0.75
				v129.BorderSizePixel = 0
				v129.Parent = v128
				local v130 = Instance.new("Frame")
				v130.AnchorPoint = Vector2.new(0.5, 0.5)
				v130.Position = UDim2.fromScale(0.5, 0.2)
				v130.Size = UDim2.fromScale(0.34, 0.22)
				v130.BackgroundColor3 = Color3.fromHex("2A2C2E")
				v130.BackgroundTransparency = 0.75
				v130.BorderSizePixel = 0
				local v131 = Instance.new("UICorner")
				v131.CornerRadius = UDim.new(1, 0)
				v131.Parent = v130
				v130.Parent = v128
				v127.Parent = p126
				v_u_20 = v127
			end
		end,
		["onShot"] = function() -- name: onShot
			-- upvalues: (copy) v_u_22
			local v132 = v_u_22
			v132.shots = v132.shots + 1
		end,
		["onHit"] = function(p133, p134) -- name: onHit
			-- upvalues: (copy) v_u_16, (copy) v_u_22, (copy) v_u_124, (ref) v_u_19, (copy) v_u_116
			if not p133 then
				return false
			end
			local v135 = nil
			for _, v136 in v_u_16 do
				if p133 ~= v136.model and not p133:IsDescendantOf(v136.model) then
					continue
				end
				v135 = v136
			end
			if not v135 then
				return false
			end
			local v137 = v135.face.CFrame:PointToObjectSpace(p134)
			local v138 = v137.X
			local v139 = v137.Y
			local v140 = v135.face.Size.Y
			local v141 = v139 / v140
			local v142 = v138 / v135.face.Size.X
			local v143
			if math.abs(v142) < 0.18 then
				local v144 = v141 - 0.33
				v143 = math.abs(v144) < 0.12
			else
				v143 = false
			end
			local v145 = (v142 * v135.face.Size.X) ^ 2 + ((v141 + 0.08) * v140) ^ 2
			local v146 = math.sqrt(v145)
			local v147, v148, v149
			if v143 then
				v147 = Color3.fromHex("D8453B")
				local v150 = v_u_22
				v150.head = v150.head + 1
				v148 = 10
				v149 = "HEAD"
			elseif v146 < 0.3 then
				v147 = Color3.fromHex("E8A33D")
				v148 = 10
				v149 = "10"
			elseif v146 < 0.7 then
				v147 = Color3.fromHex("E6E8EB")
				v148 = 8
				v149 = "8"
			elseif math.abs(v142) < 0.3 and (v141 < 0.22 and v141 > -0.42) then
				v147 = Color3.fromHex("E6E8EB")
				v148 = 6
				v149 = "6"
			else
				v147 = Color3.fromHex("9AA3AE")
				v148 = 3
				v149 = "3"
			end
			local v151 = v_u_22
			v151.hits = v151.hits + 1
			local v152 = v_u_22
			v152.score = v152.score + v148
			v_u_22.last = v148
			local v153 = Instance.new("Part")
			v153.Name = "Hole"
			v153.Anchored = true
			v153.CanCollide = false
			v153.CanQuery = false
			v153.CanTouch = false
			v153.CastShadow = false
			v153.Size = Vector3.new(0.14, 0.14, 0.03)
			v153.Color = Color3.fromHex("0E0F10")
			v153.Material = Enum.Material.SmoothPlastic
			local v154 = v135.face.CFrame
			local v155 = CFrame.new
			local v156 = -v135.face.Size.X / 2
			local v157 = v135.face.Size.X / 2
			local v158 = math.clamp(v138, v156, v157)
			local v159 = -v140 / 2
			local v160 = v140 / 2
			local v161 = v154 * v155(v158, math.clamp(v139, v159, v160), -v135.face.Size.Z / 2 - 0.02)
			v153.CFrame = v161
			v153:SetAttribute("Rel", v135.face.CFrame:ToObjectSpace(v161))
			v153.Parent = v135.model
			local v162 = v135.holes
			table.insert(v162, v153)
			local v163 = #v135.holes > 36 and table.remove(v135.holes, 1)
			if v163 then
				v163:Destroy()
			end
			v135.vel = v135.vel + (3.5 + v148 * 0.25)
			v_u_124(p134, v149, v147)
			if v_u_19 and v_u_19.Parent then
				local v164 = v_u_116
				local v165 = math.clamp(v142, -0.5, 0.5) * 0.62
				local v166 = -v141
				v164(v165, math.clamp(v166, -0.5, 0.5) * 0.9, v143)
			end
			return true
		end,
		["stats"] = function() -- name: stats
			-- upvalues: (copy) v_u_22
			local v167 = {
				["shots"] = v_u_22.shots,
				["hits"] = v_u_22.hits,
				["score"] = v_u_22.score,
				["last"] = v_u_22.last,
				["head"] = v_u_22.head
			}
			local v168
			if v_u_22.shots > 0 then
				local v169 = v_u_22.hits / v_u_22.shots
				local v170 = math.min(1, v169) * 100 + 0.5
				v168 = math.floor(v170)
			else
				v168 = 0
			end
			v167.accuracy = v168
			return v167
		end,
		["reset"] = function() -- name: reset
			-- upvalues: (copy) v_u_22, (copy) v_u_16, (copy) v_u_21
			local v171 = v_u_22
			local v172 = v_u_22
			local v173 = v_u_22
			local v174 = v_u_22
			v_u_22.shots = 0
			v171.hits = 0
			v172.score = 0
			v173.last = 0
			v174.head = 0
			for _, v175 in v_u_16 do
				for _, v176 in v175.holes do
					v176:Destroy()
				end
				table.clear(v175.holes)
			end
			for _, v177 in v_u_21 do
				v177:Destroy()
			end
			table.clear(v_u_21)
		end,
		["targets"] = function() -- name: targets
			-- upvalues: (copy) v_u_16
			local v178 = {}
			for _, v179 in v_u_16 do
				local v180 = v179.model
				table.insert(v178, v180)
			end
			return v178
		end
	}
	local v_u_182 = 0
	function v181.step(p183) -- name: step
		-- upvalues: (ref) v_u_182, (copy) v_u_16, (copy) v_u_17
		v_u_182 = v_u_182 + p183
		for _, v184 in v_u_16 do
			if v184.model.Parent == nil then
				continue
			end
			local v185 = v184.base
			local v186
			if v184.moving then
				v184.phase = v184.phase + p183
				local v187 = v184.phase * 0.9
				local v188 = math.sin(v187) * 3.6
				v185 = v184.base * CFrame.new(v188, 0, 0)
				v186 = true
			else
				v186 = false
			end
			local v189 = v184.ang
			local v190
			if math.abs(v189) > 0.0001 then
				v184.vel = v184.vel + (v184.ang * -90 - v184.vel * 11) * p183
				v184.ang = v184.ang + v184.vel * p183
				v190 = v184.ang
				v184.ang = math.clamp(v190, -0.1, 0.9)
				v186 = true
				if not v186 then
					continue
				end
				v184.model:PivotTo(v185 * CFrame.Angles(v184.ang * 0.35, 0, 0))
			else
				local v191 = v184.vel
				if math.abs(v191) > 0.0001 then
					v184.vel = v184.vel + (v184.ang * -90 - v184.vel * 11) * p183
					v184.ang = v184.ang + v184.vel * p183
					v190 = v184.ang
					v184.ang = math.clamp(v190, -0.1, 0.9)
					v186 = true
					if not v186 then
						continue
					end
					v184.model:PivotTo(v185 * CFrame.Angles(v184.ang * 0.35, 0, 0))
				else
					if not v186 then
						continue
					end
					v184.model:PivotTo(v185 * CFrame.Angles(v184.ang * 0.35, 0, 0))
				end
			end
		end
		for v192 = #v_u_17, 1, -1 do
			local v193 = v_u_17[v192]
			v193.t = v193.t + p183
			local v194 = v193.t / 0.9
			if v194 >= 1 then
				local v195 = v193.gui.Adornee
				v193.gui:Destroy()
				if v195 then
					v195:Destroy()
				end
				table.remove(v_u_17, v192)
			else
				local v196 = v193.gui
				local v197 = v194 * 1.6 + 0.6
				v196.StudsOffsetWorldSpace = Vector3.new(0, v197, 0)
				local v198 = v193.label
				local v199 = v194 * 1.4 - 0.4
				v198.TextTransparency = math.max(0, v199)
				v193.label.TextStrokeTransparency = v194 * 0.6 + 0.4
			end
		end
	end
	function v181.destroy() -- name: destroy
		-- upvalues: (copy) v_u_16, (copy) v_u_17, (ref) v_u_20, (copy) v_u_12
		for _, v200 in v_u_16 do
			v200.model:Destroy()
		end
		table.clear(v_u_16)
		for _, v201 in v_u_17 do
			v201.gui:Destroy()
		end
		table.clear(v_u_17)
		if v_u_20 then
			v_u_20:Destroy()
		end
		v_u_12:Destroy()
	end
	return v181
end
return v1