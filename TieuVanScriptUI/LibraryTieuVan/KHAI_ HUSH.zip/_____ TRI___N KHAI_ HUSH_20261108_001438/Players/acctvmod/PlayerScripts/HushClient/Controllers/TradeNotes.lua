-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / TradeNotes

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {
	["name"] = "TradeNotes",
	["order"] = 93
}
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = -1000000000
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = 0
local v_u_13 = nil
local v_u_14 = {
	["events"] = 0,
	["upd"] = 0,
	["req"] = 0,
	["ended"] = 0,
	["done"] = 0,
	["note"] = 0,
	["gets"] = 0,
	["ops"] = 0,
	["refused"] = 0
}
local v_u_15 = false
local v_u_16 = {}
local v_u_17 = 0
local v_u_18 = {}
local v_u_19 = false
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = 0
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = 0
local v_u_29 = false
local v_u_30 = -1
local function v_u_31() -- name: now
	return os.clock()
end
function v_u_4.subscribe(p32) -- name: subscribe
	-- upvalues: (ref) v_u_12, (copy) v_u_11
	v_u_12 = v_u_12 + 1
	local v_u_33 = v_u_12
	v_u_11[v_u_33] = p32
	return function()
		-- upvalues: (ref) v_u_11, (copy) v_u_33
		v_u_11[v_u_33] = nil
	end
end
function v_u_4.state() -- name: state
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v_u_4.stateAge() -- name: stateAge
	-- upvalues: (ref) v_u_9
	return os.clock() - v_u_9
end
function v_u_4.tabState() -- name: tabState
	-- upvalues: (ref) v_u_8
	local v34 = v_u_8
	if type(v34) == "table" then
		if v_u_8.tab == true then
			return true
		elseif v_u_8.tab == false then
			return false
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_37() -- name: pruneReqs
	-- upvalues: (copy) v_u_10
	local v35 = os.clock()
	for v36 = #v_u_10, 1, -1 do
		if v_u_10[v36].expires > v35 then
			continue
		end
		table.remove(v_u_10, v36)
	end
end
function v_u_4.reqs() -- name: reqs
	-- upvalues: (copy) v_u_37, (copy) v_u_10
	v_u_37()
	local v38 = {}
	for _, v39 in v_u_10 do
		local v40 = {
			["from"] = v39.from,
			["name"] = v39.name,
			["expires"] = v39.expires
		}
		local v41 = v39.expires - os.clock()
		local v42 = math.ceil(v41)
		v40.left = math.max(0, v42)
		table.insert(v38, v40)
	end
	return v38
end
local function v_u_53(p43, p44, p45) -- name: addReq
	-- upvalues: (copy) v_u_10
	if type(p43) == "number" then
		local v46 = os.clock()
		local v47 = tonumber(p45) or 30
		local v48 = v46 + math.clamp(v47, 1, 30)
		for _, v49 in v_u_10 do
			if v49.from ~= p43 then
				continue
			end
			local v50 = p44 or v49.name
			v49.name = tostring(v50)
			v49.expires = v48
			return
		end
		local v51 = v_u_10
		local v52 = {
			["from"] = p43,
			["name"] = tostring(p44 or "Someone"),
			["expires"] = v48,
			["at"] = os.clock()
		}
		table.insert(v51, v52)
		while #v_u_10 > 3 do
			table.remove(v_u_10, 1)
		end
	end
end
local function v_u_56(p54) -- name: removeReq
	-- upvalues: (copy) v_u_10
	for v55 = #v_u_10, 1, -1 do
		if v_u_10[v55].from ~= p54 then
			continue
		end
		table.remove(v_u_10, v55)
	end
end
local function v_u_70(p57) -- name: applyState
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_53, (copy) v_u_10, (ref) v_u_30, (ref) v_u_5, (copy) v_u_11
	if type(p57) == "table" then
		v_u_8 = p57
		v_u_9 = os.clock()
		local v58 = p57.reqs
		if type(v58) == "table" then
			local v59 = {}
			for _, v60 in p57.reqs do
				if type(v60) ~= "table" then
					continue
				end
				local v61 = v60.from
				if type(v61) ~= "number" then
					continue
				end
				v_u_53(v60.from, v60.name, v60.left)
				v59[v60.from] = true
			end
			for v62 = #v_u_10, 1, -1 do
				if v59[v_u_10[v62].from] then
					continue
				end
				table.remove(v_u_10, v62)
			end
		end
		local v_u_63 = #v_u_10
		if v_u_63 ~= v_u_30 then
			v_u_30 = v_u_63
			local function v67()
				-- upvalues: (ref) v_u_5, (copy) v_u_63
				local v64 = v_u_5
				local v65 = "TradeReqCount"
				local v66
				if v_u_63 > 0 then
					v66 = v_u_63
				else
					v66 = nil
				end
				v64:SetAttribute(v65, v66)
			end
			pcall(v67)
		end
		local v68 = {
			["k"] = "state",
			["state"] = nil,
			["state"] = p57
		}
		for _, v69 in v_u_11 do
			pcall(v69, v68)
		end
	end
end
local function v_u_85(p71, p72) -- name: rawGet
	-- upvalues: (copy) v_u_14, (ref) v_u_13, (copy) v_u_2
	local v73 = v_u_14
	v73.gets = v73.gets + 1
	if v_u_13 == nil then
		local v_u_74 = {
			["what"] = p71
		}
		if type(p72) == "table" then
			for v75, v76 in p72 do
				v_u_74[v75] = v76
			end
		end
		local v77 = v_u_2:FindFirstChild("HushNet")
		local v_u_78 = v77
		if v_u_78 then
			v_u_78 = v77:FindFirstChild("menu.get")
		end
		if not v_u_78 then
			v_u_78 = v_u_2:WaitForChild("HushNet", 10)
			if v_u_78 then
				v_u_78 = v_u_78:WaitForChild("menu.get", 10)
			end
		end
		if v_u_78 and v_u_78:IsA("RemoteFunction") then
			local v79, v80 = pcall(function()
				-- upvalues: (ref) v_u_78, (copy) v_u_74
				return v_u_78:InvokeServer(v_u_74)
			end)
			if v79 and (type(v80) == "table" and v80.error == nil) then
				return v80
			end
		end
		return nil
	else
		local v81 = v_u_13.get
		local v82 = v_u_13
		local v83, v84 = pcall(v81, v82, p71, p72 or {})
		if v83 then
			return v84
		else
			return nil
		end
	end
end
function v_u_4.get(p86, p87) -- name: get
	-- upvalues: (copy) v_u_85
	return v_u_85(p86, p87)
end
function v_u_4.refresh(p88, p89) -- name: refresh
	-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_9, (copy) v_u_85, (copy) v_u_70, (ref) v_u_19, (ref) v_u_6, (copy) v_u_4
	if p89 ~= nil then
		local v90 = v_u_16
		table.insert(v90, { p89 })
	end
	if v_u_15 then
		return
	elseif p88 == true or (os.clock() - v_u_9 >= 2 or #v_u_16 ~= 0) then
		v_u_15 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_85, (ref) v_u_15, (ref) v_u_70, (ref) v_u_19, (ref) v_u_6, (ref) v_u_4, (ref) v_u_16
			local v91 = os.clock() - v_u_9
			if v91 < 0.6 then
				task.wait(0.6 - v91)
			end
			local v_u_92 = v_u_85("tradeState")
			v_u_15 = false
			if type(v_u_92) == "table" then
				v_u_70(v_u_92)
				if v_u_92.notes ~= nil and not v_u_19 then
					v_u_19 = true
					local function v95()
						-- upvalues: (ref) v_u_6, (copy) v_u_92
						local v93 = v_u_6.lib.HushUI.toast
						local v94 = v_u_92.noteText or "Your trade was completed while you were away. Check your stash."
						v93(tostring(v94), "success")
					end
					pcall(v95)
					task.spawn(function()
						-- upvalues: (ref) v_u_4
						v_u_4.op("tradeSeen", {})
					end)
				end
			end
			local v96 = v_u_16
			v_u_16 = {}
			for _, v97 in v96 do
				local v98 = v97[1]
				pcall(v98, v_u_92)
			end
		end)
	end
end
function v_u_4.op(p99, p100) -- name: op
	-- upvalues: (copy) v_u_14, (ref) v_u_13, (ref) v_u_6, (ref) v_u_17, (copy) v_u_2, (copy) v_u_18
	local v101 = v_u_14
	v101.ops = v101.ops + 1
	if v_u_13 ~= nil then
		local v102 = v_u_13.op
		local v103 = v_u_13
		local v104, v105, v_u_106, v107 = pcall(v102, v103, p99, p100 or {})
		if not v104 then
			return {
				["ok"] = false,
				["msg"] = nil,
				["msg"] = tostring(v105)
			}
		end
		if v105 ~= true then
			local v108 = v_u_14
			v108.refused = v108.refused + 1
			local function v110()
				-- upvalues: (ref) v_u_6, (copy) v_u_106
				local v109 = v_u_106 or "That did not work"
				v_u_6.lib.HushUI.toast(tostring(v109), "danger")
			end
			pcall(v110)
		end
		return {
			["ok"] = v105 == true,
			["msg"] = v_u_106,
			["data"] = v107
		}
	end
	v_u_17 = v_u_17 + 1
	local v111 = v_u_17
	local v_u_112 = "tn" .. tostring(v111)
	local v113 = {}
	if type(p100) == "table" then
		for v114, v115 in p100 do
			v113[v114] = v115
		end
	end
	v113.op = p99
	v113.req = v_u_112
	local v116 = v_u_2:FindFirstChild("HushNet")
	if v116 then
		v116 = v116:FindFirstChild("menu.op")
	end
	if not (v116 and v116:IsA("RemoteEvent")) then
		return {
			["ok"] = false,
			["msg"] = "Try again later."
		}
	end
	local v_u_117 = coroutine.running()
	v_u_18[v_u_112] = {
		["co"] = v_u_117,
		["at"] = os.clock()
	}
	task.delay(20, function()
		-- upvalues: (ref) v_u_18, (copy) v_u_112, (copy) v_u_117
		local v118 = v_u_18[v_u_112]
		if v118 ~= nil and v118.co == v_u_117 then
			v_u_18[v_u_112] = nil
			task.spawn(v_u_117, {
				["ok"] = false,
				["msg"] = "Try again later.",
				["timeout"] = true
			})
		end
	end)
	v116:FireServer(v113)
	local v119 = coroutine.yield()
	if type(v119) == "table" and v119.ok ~= true then
		local v120 = v_u_14
		v120.refused = v120.refused + 1
	end
	return v119
end
local function v_u_124(p121) -- name: onResult
	-- upvalues: (copy) v_u_18
	if type(p121) == "table" then
		local v122 = p121.req
		if type(v122) == "string" then
			local v123 = v_u_18[p121.req]
			if v123 ~= nil then
				v_u_18[p121.req] = nil
				task.spawn(v123.co, {
					["ok"] = p121.ok == true,
					["msg"] = p121.msg,
					["data"] = p121.data
				})
			end
		end
	end
end
function v_u_4.onEvent(p125) -- name: onEvent
	-- upvalues: (copy) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_56, (copy) v_u_37, (copy) v_u_10, (ref) v_u_30, (ref) v_u_5, (copy) v_u_11, (copy) v_u_4, (copy) v_u_53, (ref) v_u_19
	if type(p125) == "table" then
		local v126 = p125.k
		if type(v126) == "string" then
			local v127 = v_u_14
			v127.events = v127.events + 1
			local v128 = p125.k
			if v128 == "upd" then
				local v129 = v_u_14
				v129.upd = v129.upd + 1
				if p125.s == nil then
					local v130 = v_u_8
					if type(v130) == "table" then
						local v131 = v_u_8
						local v132 = v_u_8
						local v133 = v_u_8
						v_u_8.s = nil
						v131.phase = "none"
						v132.sid = nil
						v133.finishing = nil
					end
				end
				local v134 = p125.s
				if type(v134) == "table" then
					local v135 = v_u_8
					if type(v135) == "table" then
						v_u_8.s = p125.s
						v_u_8.phase = p125.s.phase
						v_u_8.sid = p125.s.sid
						if p125.s.phase == "go" then
							local v136 = v_u_8
							if v_u_7 == nil then
								local function v137()
									-- upvalues: (ref) v_u_6
									return v_u_6.shared.TradeView
								end
								local v138, v139 = pcall(v137)
								if not v138 then
									v139 = nil
								end
								v_u_7 = v139
							end
							local v140
							if v_u_7 then
								if v_u_7 == nil then
									local function v141()
										-- upvalues: (ref) v_u_6
										return v_u_6.shared.TradeView
									end
									local v142, v143 = pcall(v141)
									if not v142 then
										v143 = nil
									end
									v_u_7 = v143
								end
								v140 = v_u_7.rtext("completing", "Completing the trade. This takes a few seconds.") or nil
							else
								v140 = nil
							end
							v136.finishing = v140
						end
					end
					if p125.s.you then
						local v144 = p125.s.you.id
						if type(v144) == "number" then
							v_u_56(p125.s.you.id)
						end
					end
				end
				v_u_37()
				local v_u_145 = #v_u_10
				if v_u_145 ~= v_u_30 then
					v_u_30 = v_u_145
					local function v149()
						-- upvalues: (ref) v_u_5, (copy) v_u_145
						local v146 = v_u_5
						local v147 = "TradeReqCount"
						local v148
						if v_u_145 > 0 then
							v148 = v_u_145
						else
							v148 = nil
						end
						v146:SetAttribute(v147, v148)
					end
					pcall(v149)
				end
				local v150 = {
					["k"] = "upd",
					["s"] = nil,
					["s"] = p125.s
				}
				for _, v151 in v_u_11 do
					pcall(v151, v150)
				end
				local v152 = v_u_8
				if type(v152) ~= "table" then
					v_u_4.refresh(true)
					return
				end
			else
				if v128 == "req" then
					local v153 = v_u_14
					v153.req = v153.req + 1
					v_u_53(p125.from, p125.name, p125.left)
					local v_u_154 = #v_u_10
					if v_u_154 ~= v_u_30 then
						v_u_30 = v_u_154
						local function v158()
							-- upvalues: (ref) v_u_5, (copy) v_u_154
							local v155 = v_u_5
							local v156 = "TradeReqCount"
							local v157
							if v_u_154 > 0 then
								v157 = v_u_154
							else
								v157 = nil
							end
							v155:SetAttribute(v156, v157)
						end
						pcall(v158)
					end
					local v159 = {
						["k"] = "req",
						["from"] = nil,
						["name"] = nil,
						["from"] = p125.from,
						["name"] = p125.name
					}
					for _, v160 in v_u_11 do
						pcall(v160, v159)
					end
					return
				end
				if v128 == "end" then
					local v161 = v_u_14
					v161.ended = v161.ended + 1
					local v162 = v_u_8
					if type(v162) == "table" then
						v_u_8.s = nil
						v_u_8.phase = "none"
						v_u_8.sid = nil
					end
					v_u_37()
					local v_u_163 = #v_u_10
					if v_u_163 ~= v_u_30 then
						v_u_30 = v_u_163
						local function v167()
							-- upvalues: (ref) v_u_5, (copy) v_u_163
							local v164 = v_u_5
							local v165 = "TradeReqCount"
							local v166
							if v_u_163 > 0 then
								v166 = v_u_163
							else
								v166 = nil
							end
							v164:SetAttribute(v165, v166)
						end
						pcall(v167)
					end
					local v_u_168 = p125.text
					if type(v_u_168) == "string" and v_u_168 ~= "" then
						local v_u_169 = "info"
						local function v170()
							-- upvalues: (ref) v_u_6, (copy) v_u_168, (copy) v_u_169
							v_u_6.lib.HushUI.toast(v_u_168, v_u_169 or "info")
						end
						pcall(v170)
					end
					local v171 = {
						["k"] = "end",
						["why"] = nil,
						["text"] = nil,
						["sid"] = nil,
						["why"] = p125.why,
						["text"] = p125.text,
						["sid"] = p125.sid
					}
					for _, v172 in v_u_11 do
						pcall(v172, v171)
					end
					v_u_4.refresh(true)
					return
				end
				if v128 == "done" then
					local v173 = v_u_14
					v173.done = v173.done + 1
					local v174 = v_u_8
					if type(v174) == "table" then
						v_u_8.s = nil
						v_u_8.phase = "none"
						v_u_8.sid = nil
					end
					local v_u_175 = p125.text
					if type(v_u_175) == "string" and v_u_175 ~= "" then
						local v_u_176 = "success"
						local function v177()
							-- upvalues: (ref) v_u_6, (copy) v_u_175, (copy) v_u_176
							v_u_6.lib.HushUI.toast(v_u_175, v_u_176 or "info")
						end
						pcall(v177)
					end
					local v178 = {
						["k"] = "done",
						["beleg"] = nil,
						["text"] = nil,
						["beleg"] = p125.beleg,
						["text"] = p125.text
					}
					for _, v179 in v_u_11 do
						pcall(v179, v178)
					end
					v_u_4.refresh(true)
					return
				end
				if v128 == "note" then
					local v180 = v_u_14
					v180.note = v180.note + 1
					if not v_u_19 then
						v_u_19 = true
						local v_u_181 = p125.text
						if type(v_u_181) == "string" and v_u_181 ~= "" then
							local v_u_182 = "success"
							local function v183()
								-- upvalues: (ref) v_u_6, (copy) v_u_181, (copy) v_u_182
								v_u_6.lib.HushUI.toast(v_u_181, v_u_182 or "info")
							end
							pcall(v183)
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_4
							v_u_4.op("tradeSeen", {})
						end)
					end
					local v184 = {
						["k"] = "note",
						["n"] = nil,
						["n"] = p125.n
					}
					for _, v185 in v_u_11 do
						pcall(v185, v184)
					end
					v_u_4.refresh(true)
				end
			end
			return
		end
	end
end
function v_u_4.inject(p186) -- name: inject
	-- upvalues: (copy) v_u_4
	v_u_4.onEvent(p186)
end
function v_u_4.setBackend(p187) -- name: setBackend
	-- upvalues: (ref) v_u_13, (ref) v_u_8, (ref) v_u_9, (copy) v_u_10, (ref) v_u_19, (ref) v_u_30, (ref) v_u_5, (copy) v_u_11, (copy) v_u_4
	v_u_13 = p187
	v_u_8 = nil
	v_u_9 = -1000000000
	table.clear(v_u_10)
	v_u_19 = false
	local v_u_188 = #v_u_10
	if v_u_188 ~= v_u_30 then
		v_u_30 = v_u_188
		local function v192()
			-- upvalues: (ref) v_u_5, (copy) v_u_188
			local v189 = v_u_5
			local v190 = "TradeReqCount"
			local v191
			if v_u_188 > 0 then
				v191 = v_u_188
			else
				v191 = nil
			end
			v189:SetAttribute(v190, v191)
		end
		pcall(v192)
	end
	local v193 = {
		["k"] = "backend",
		["fake"] = nil,
		["fake"] = p187 ~= nil
	}
	for _, v194 in v_u_11 do
		pcall(v194, v193)
	end
	task.defer(function()
		-- upvalues: (ref) v_u_4
		v_u_4.refresh(true)
	end)
end
function v_u_4.backend() -- name: backend
	-- upvalues: (ref) v_u_13
	return v_u_13
end
local function v_u_199() -- name: holdFacts
	-- upvalues: (ref) v_u_5
	local v195 = {
		["crateStage"] = v_u_5:GetAttribute("CrateStageOn") == true,
		["loading"] = v_u_5:GetAttribute("LoadingVisible") == true
	}
	local v196 = v_u_5:GetAttribute("DeployBanner")
	v195.deploying = type(v196) == "string" and v196 ~= "" and true or v_u_5:GetAttribute("QueuePos") ~= nil
	v195.film = v_u_5:GetAttribute("FilmOpen") == true and true or v_u_5:GetAttribute("EntryActive") == true
	local v197 = false
	if v_u_5:GetAttribute("Place") == "Hideout" then
		local v198 = v_u_5.Character
		if v198 then
			v198 = v198:FindFirstChildOfClass("Humanoid")
		end
		v197 = v198 and v198.MoveDirection.Magnitude > 0.1 and true or v197
	end
	v195.moving = v197
	return v195
end
function v_u_4.held() -- name: held
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_199
	if v_u_7 == nil then
		local function v200()
			-- upvalues: (ref) v_u_6
			return v_u_6.shared.TradeView
		end
		local v201, v202 = pcall(v200)
		if not v201 then
			v202 = nil
		end
		v_u_7 = v202
	end
	local v203 = v_u_7
	return not v203 and true or v203.stripHold((v_u_199()))
end
local function v_u_224() -- name: buildStrip
	-- upvalues: (ref) v_u_20, (ref) v_u_6, (ref) v_u_23, (ref) v_u_24, (ref) v_u_25, (ref) v_u_7, (ref) v_u_26, (copy) v_u_4, (ref) v_u_21, (ref) v_u_22
	if v_u_20 == nil then
		local v_u_204 = v_u_6.lib.HushUI
		local v205 = v_u_204.Theme
		local v206 = v205.color
		local v207, v208 = v_u_204.screen("HushTradeStrip", v205.layer.toast - 2)
		v207.Enabled = false
		local v_u_209 = v205.touch(44)
		v_u_23 = v_u_209
		local v210 = v_u_204.new("Frame", {
			["Name"] = "Strip",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.06,
			["BorderSizePixel"] = 0,
			["Visible"] = false,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 74),
			["Size"] = UDim2.fromOffset(500, 40 + v_u_209 + 12),
			["BackgroundColor3"] = v206.bg
		}, v208)
		v_u_204.stroke(v210, v206.accent)
		v_u_24 = v_u_204.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = "",
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v210,
			["color"] = v206.text,
			["position"] = UDim2.fromOffset(14, 8),
			["size"] = UDim2.new(1, -86, 0, 24)
		})
		v_u_25 = v_u_204.label({
			["parent"] = nil,
			["name"] = "Left",
			["text"] = "",
			["style"] = "mono",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v210,
			["color"] = v206.text2,
			["position"] = UDim2.new(1, -66, 0, 8),
			["size"] = UDim2.fromOffset(52, 24)
		})
		local v_u_211 = v_u_204.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(12, 40),
			["Size"] = UDim2.new(1, -24, 0, v_u_209 + 2)
		}, v210)
		v_u_204.layout(v_u_211, "h", 8)
		if v_u_7 == nil then
			local function v212()
				-- upvalues: (ref) v_u_6
				return v_u_6.shared.TradeView
			end
			local v213, v214 = pcall(v212)
			if not v213 then
				v214 = nil
			end
			v_u_7 = v214
		end
		local v215 = v_u_7
		local function v223(p216, p217, p218, p219, p220) -- name: mk
			-- upvalues: (copy) v_u_204, (copy) v_u_211, (copy) v_u_209
			local v_u_221, v222 = v_u_204.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = nil,
				["size"] = nil,
				["height"] = nil,
				["name"] = nil,
				["order"] = nil,
				["onClick"] = nil,
				["maxTextWidth"] = 120,
				["parent"] = v_u_211,
				["text"] = p216,
				["kind"] = p217,
				["size"] = UDim2.new(0.3333333333333333, -6, 0, v_u_209),
				["height"] = v_u_209,
				["name"] = p218,
				["order"] = p219,
				["onClick"] = p220
			})
			pcall(function()
				-- upvalues: (copy) v_u_221
				v_u_221.Selectable = false
			end)
			return {
				["btn"] = v_u_221,
				["api"] = v222
			}
		end
		v_u_26 = {
			["accept"] = v223(v215.TEXT.accept, "primary", "Accept", 1, function()
				-- upvalues: (ref) v_u_4
				v_u_4.answerStrip(true, false)
			end),
			["decline"] = v223(v215.TEXT.decline, "secondary", "Decline", 2, function()
				-- upvalues: (ref) v_u_4
				v_u_4.answerStrip(false, false)
			end),
			["block"] = v223(v215.TEXT.block, "ghost", "Block", 3, function()
				-- upvalues: (ref) v_u_4
				v_u_4.answerStrip(false, true)
			end)
		}
		v_u_20 = v207
		v_u_21 = v208
		v_u_22 = v210
	end
end
function v_u_4.answer(p225, p226, p227) -- name: answer
	-- upvalues: (copy) v_u_56, (copy) v_u_10, (ref) v_u_30, (ref) v_u_5, (ref) v_u_27, (ref) v_u_22, (ref) v_u_20, (copy) v_u_4, (ref) v_u_6
	v_u_56(p225)
	local v_u_228 = #v_u_10
	if v_u_228 ~= v_u_30 then
		v_u_30 = v_u_228
		local function v232()
			-- upvalues: (ref) v_u_5, (copy) v_u_228
			local v229 = v_u_5
			local v230 = "TradeReqCount"
			local v231
			if v_u_228 > 0 then
				v231 = v_u_228
			else
				v231 = nil
			end
			v229:SetAttribute(v230, v231)
		end
		pcall(v232)
	end
	if v_u_27 == p225 then
		if v_u_22 then
			v_u_22.Visible = false
		end
		if v_u_20 then
			v_u_20.Enabled = false
		end
		v_u_27 = nil
	end
	local v233 = v_u_4.op("tradeAnswer", {
		["from"] = p225,
		["accept"] = p226,
		["block"] = p227 and true or nil
	})
	if v233.ok and p226 then
		local function v236()
			-- upvalues: (ref) v_u_6
			local v234 = v_u_6.controllers.Menu
			if v234 then
				local v235 = v234.openMarket
				if type(v235) == "function" then
					v234.openMarket("trade")
				end
			end
		end
		pcall(v236)
	end
	v_u_4.refresh(true)
	return v233
end
function v_u_4.answerStrip(p237, p238) -- name: answerStrip
	-- upvalues: (ref) v_u_27, (ref) v_u_7, (ref) v_u_6, (copy) v_u_10, (ref) v_u_28, (copy) v_u_31, (copy) v_u_4
	local v239 = v_u_27
	if v239 == nil then
		return
	else
		if v_u_7 == nil then
			local function v240()
				-- upvalues: (ref) v_u_6
				return v_u_6.shared.TradeView
			end
			local v241, v242 = pcall(v240)
			if not v241 then
				v242 = nil
			end
			v_u_7 = v242
		end
		local v243 = v_u_7
		local v244 = nil
		for _, v245 in v_u_10 do
			if v245.from ~= v239 then
				continue
			end
			v244 = v245
		end
		if not (p237 or p238) or v243.stripState(v244, v_u_28, v_u_31()).armed then
			task.spawn(v_u_4.answer, v239, p237, p238)
		end
	end
end
local function v_u_273() -- name: stripTick
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_37, (copy) v_u_10, (ref) v_u_30, (ref) v_u_5, (copy) v_u_4, (ref) v_u_29, (ref) v_u_27, (ref) v_u_22, (ref) v_u_20, (ref) v_u_23, (ref) v_u_21, (ref) v_u_26, (copy) v_u_224, (ref) v_u_28, (ref) v_u_24, (copy) v_u_31, (ref) v_u_25
	if v_u_7 == nil then
		local function v246()
			-- upvalues: (ref) v_u_6
			return v_u_6.shared.TradeView
		end
		local v247, v248 = pcall(v246)
		if not v247 then
			v248 = nil
		end
		v_u_7 = v248
	end
	local v249 = v_u_7
	if v249 == nil then
		return
	else
		v_u_37()
		local v_u_250 = #v_u_10
		if v_u_250 ~= v_u_30 then
			v_u_30 = v_u_250
			local function v254()
				-- upvalues: (ref) v_u_5, (copy) v_u_250
				local v251 = v_u_5
				local v252 = "TradeReqCount"
				local v253
				if v_u_250 > 0 then
					v253 = v_u_250
				else
					v253 = nil
				end
				v251:SetAttribute(v252, v253)
			end
			pcall(v254)
		end
		if v249.stripSkip(v_u_5:GetAttribute("Place")) then
			table.clear(v_u_10)
			local v_u_255 = #v_u_10
			if v_u_255 ~= v_u_30 then
				v_u_30 = v_u_255
				local function v259()
					-- upvalues: (ref) v_u_5, (copy) v_u_255
					local v256 = v_u_5
					local v257 = "TradeReqCount"
					local v258
					if v_u_255 > 0 then
						v258 = v_u_255
					else
						v258 = nil
					end
					v256:SetAttribute(v257, v258)
				end
				pcall(v259)
			end
		end
		local v260 = v_u_4.held()
		v_u_29 = v260
		local v261 = v_u_10[1]
		if v261 == nil or v260 then
			if v_u_27 ~= nil then
				if v_u_22 then
					v_u_22.Visible = false
				end
				if v_u_20 then
					v_u_20.Enabled = false
				end
				v_u_27 = nil
			end
		else
			if v_u_20 ~= nil then
				local function v262()
					-- upvalues: (ref) v_u_6
					return v_u_6.lib.HushUI.Theme.touch(44)
				end
				local v263, v264 = pcall(v262)
				if v263 and v264 ~= v_u_23 then
					local function v265()
						-- upvalues: (ref) v_u_20
						v_u_20:Destroy()
					end
					pcall(v265)
					v_u_20 = nil
					v_u_21 = nil
					v_u_22 = nil
					v_u_26 = nil
					v_u_27 = nil
				end
			end
			v_u_224()
			if v_u_27 ~= v261.from then
				v_u_27 = v261.from
				v_u_28 = os.clock()
				if v_u_22 then
					v_u_22.Visible = true
				end
				if v_u_20 then
					v_u_20.Enabled = true
				end
				if v_u_24 then
					v_u_24.Text = v249.rtext("wants", "%s wants to trade.", v261.name)
				end
			end
			local v266 = v249.stripState(v261, v_u_28, v_u_31())
			if v_u_25 then
				v_u_25.Text = v249.text("stripSub", v266.left)
			end
			if v_u_26 then
				v_u_26.accept.api.setEnabled(v266.armed)
				v_u_26.block.api.setEnabled(v266.armed)
				v_u_26.decline.api.setEnabled(true)
			end
			local function v272()
				-- upvalues: (ref) v_u_6, (ref) v_u_22, (ref) v_u_23
				local v267 = v_u_6.lib.HushUI
				local v268 = v267.Theme.refSize()
				local v269 = v267.safeInsets()
				local v270 = (v268.X - v269.l - v269.r) * 0.92
				local v271 = math.clamp(v270, 300, 500)
				if v_u_22 then
					v_u_22.Size = UDim2.fromOffset(v271, v_u_23 + 40 + 12)
				end
			end
			pcall(v272)
		end
	end
end
function v_u_4.stripInfo() -- name: stripInfo
	-- upvalues: (ref) v_u_27, (ref) v_u_22, (ref) v_u_29, (copy) v_u_10, (ref) v_u_28, (ref) v_u_26
	local v274 = {}
	local v275
	if v_u_27 == nil or v_u_22 == nil then
		v275 = false
	else
		v275 = v_u_22.Visible
	end
	v274.shown = v275
	v274.forUser = v_u_27
	v274.held = v_u_29
	v274.count = #v_u_10
	v274.shownAt = v_u_28
	local v276
	if v_u_26 == nil then
		v276 = false
	else
		v276 = v_u_26.accept.btn.Active
	end
	v274.enabledAccept = v276
	local v277
	if v_u_26 == nil then
		v277 = false
	else
		v277 = v_u_26.accept.btn.Selectable
	end
	v274.selectable = v277
	return v274
end
function v_u_4.counters() -- name: counters
	-- upvalues: (copy) v_u_14
	return table.clone(v_u_14)
end
local function v_u_279() -- name: maybeAsk
	-- upvalues: (ref) v_u_13, (copy) v_u_4, (ref) v_u_5
	if v_u_13 == nil then
		local v278 = v_u_5:GetAttribute("Place")
		if v_u_5:GetAttribute("PaidTrading") == true and (v278 == "Menu" or v278 == "Hideout") then
			v_u_4.refresh(false)
		end
	else
		v_u_4.refresh(true)
	end
end
function v_u_4.init(p_u_280) -- name: init
	-- upvalues: (ref) v_u_6, (copy) v_u_3, (copy) v_u_4, (ref) v_u_5, (ref) v_u_13, (copy) v_u_10
	v_u_6 = p_u_280
	p_u_280.lib.HushUI.bind(p_u_280)
	p_u_280.command("trade.fake", function(p281)
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (copy) p_u_280
		if v_u_3:IsStudio() then
			if (p281[1] or "on") == "off" then
				v_u_4.setBackend(nil)
				local function v282()
					-- upvalues: (ref) v_u_5
					v_u_5:SetAttribute("TradeUiFake", nil)
				end
				pcall(v282)
				return "trade.fake off"
			else
				local function v283()
					-- upvalues: (ref) p_u_280
					return p_u_280.lib.MenuTradeFake
				end
				local v284, v285 = pcall(v283)
				if v284 and type(v285) == "table" then
					local v286 = v285.new
					if type(v286) == "function" then
						local v287 = v285.new({
							["notes"] = v_u_4,
							["shared"] = p_u_280.shared,
							["lib"] = p_u_280.lib,
							["scenario"] = p281[2]
						})
						v_u_4.setBackend(v287)
						local function v288()
							-- upvalues: (ref) v_u_5
							v_u_5:SetAttribute("TradeUiFake", true)
							v_u_5:SetAttribute("PaidTrading", true)
						end
						pcall(v288)
						local v289 = p_u_280.controllers.Menu
						if v289 then
							local v290 = v289.rebuild
							if type(v290) == "function" then
								task.defer(v289.rebuild)
							end
						end
						local v291 = v287.scenarioName
						return "trade.fake on (" .. tostring(v291) .. "), the menu rebuilds"
					end
				end
				return "MenuTradeFake is not synced"
			end
		else
			return "Studio only"
		end
	end)
	p_u_280.command("trade.fake.do", function(p292)
		-- upvalues: (ref) v_u_13
		local v293 = v_u_13
		if v293 ~= nil then
			local v294 = v293.command
			if type(v294) == "function" then
				return tostring(v293:command(p292))
			end
		end
		return "trade.fake is off"
	end)
	p_u_280.command("trade.note", function(p295)
		-- upvalues: (ref) v_u_4
		local v296 = p295[1] or "req"
		if v296 == "req" then
			local v297 = v_u_4.inject
			local v298 = {
				["k"] = "req",
				["from"] = nil,
				["name"] = nil,
				["left"] = 30
			}
			local v299 = p295[2]
			v298.from = tonumber(v299) or 9001
			v298.name = p295[3] or "Fenris"
			v297(v298)
		elseif v296 == "end" then
			v_u_4.inject({
				["k"] = "end",
				["why"] = "declined",
				["text"] = nil,
				["sid"] = false,
				["text"] = p295[2] or "They declined."
			})
		elseif v296 == "done" then
			local v300 = {
				["k"] = "done",
				["beleg"] = nil,
				["text"] = "Trade complete.",
				["beleg"] = {
					["tid"] = "t0",
					["got"] = nil,
					["fee"] = 10000,
					["overflow"] = 0,
					["got"] = {
						["items"] = 2,
						["finishes"] = 1,
						["cash"] = 190000
					}
				}
			}
			v_u_4.inject(v300)
		else
			if v296 ~= "note" then
				return "kinds: req end done note"
			end
			v_u_4.inject({
				["k"] = "note",
				["n"] = 1,
				["text"] = "Your trade was completed while you were away. Check your stash."
			})
		end
		return "injected " .. v296
	end)
	p_u_280.command("trade.strip", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_10
		local v301 = v_u_4.stripInfo()
		local v302 = v301.shown
		local v303 = tostring(v302)
		local v304 = v301.forUser
		local v305 = tostring(v304)
		local v306 = v301.held
		local v307 = tostring(v306)
		local v308 = v301.count
		local v309 = v301.selectable
		local v310 = tostring(v309)
		local v311 = #v_u_10
		local v312 = v_u_4.tabState
		return ("shown=%s for=%s held=%s count=%d selectable=%s reqs=%d tab=%s"):format(v303, v305, v307, v308, v310, v311, (tostring(v312())))
	end)
	p_u_280.command("trade.ui", function(p313)
		-- upvalues: (copy) p_u_280
		local function v314()
			-- upvalues: (ref) p_u_280
			return p_u_280.lib.MenuMarket
		end
		local v315, v316 = pcall(v314)
		return (not v315 or type(v316) ~= "table") and "MenuMarket is not synced" or v316.command(p_u_280, "page", { "trade", table.unpack(p313) })
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_124, (ref) v_u_5, (copy) v_u_279, (copy) v_u_273
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_124
		local v317 = v_u_2:WaitForChild("HushNet", 60)
		if v317 then
			local v318 = v317:FindFirstChild("trade.ev")
			if v318 and v318:IsA("RemoteEvent") then
				v318.OnClientEvent:Connect(function(p319)
					-- upvalues: (ref) v_u_4
					v_u_4.onEvent(p319)
				end)
			end
			v317.ChildAdded:Connect(function(p320)
				-- upvalues: (ref) v_u_4
				if p320.Name == "trade.ev" and p320:IsA("RemoteEvent") then
					p320.OnClientEvent:Connect(function(p321)
						-- upvalues: (ref) v_u_4
						v_u_4.onEvent(p321)
					end)
				end
			end)
			local v322 = v317:FindFirstChild("menu.result") or v317:WaitForChild("menu.result", 30)
			if v322 and v322:IsA("RemoteEvent") then
				v322.OnClientEvent:Connect(v_u_124)
			end
		end
	end)
	for _, v323 in { "PaidTrading", "Place" } do
		v_u_5:GetAttributeChangedSignal(v323):Connect(function()
			-- upvalues: (ref) v_u_279
			task.delay(0.5, v_u_279)
		end)
	end
	task.delay(2, v_u_279)
	task.spawn(function()
		-- upvalues: (ref) v_u_273, (ref) v_u_5
		while true do
			repeat
				task.wait(0.25)
				local v324 = v_u_273
				local v325, v_u_326 = pcall(v324)
			until not v325
			local function v328()
				-- upvalues: (ref) v_u_5, (copy) v_u_326
				local v327 = v_u_326
				v_u_5:SetAttribute("ClientError", "TradeNotes: " .. tostring(v327))
			end
			pcall(v328)
			task.wait(5)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_279
		while true do
			task.wait(30)
			local v329 = v_u_279
			pcall(v329)
		end
	end)
end
v_u_4._test = {
	["reset"] = function() -- name: reset
		-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_10, (copy) v_u_11, (ref) v_u_13, (ref) v_u_19, (ref) v_u_30, (copy) v_u_14
		v_u_8 = nil
		v_u_9 = -1000000000
		table.clear(v_u_10)
		table.clear(v_u_11)
		v_u_13 = nil
		v_u_19 = false
		v_u_30 = -1
		for v330 in v_u_14 do
			v_u_14[v330] = 0
		end
	end,
	["setContext"] = function(p331) -- name: setContext
		-- upvalues: (ref) v_u_6
		v_u_6 = p331
	end,
	["setPlayer"] = function(p332) -- name: setPlayer
		-- upvalues: (ref) v_u_5
		v_u_5 = p332
	end,
	["applyState"] = v_u_70,
	["addReq"] = v_u_53,
	["pruneReqs"] = v_u_37
}
return v_u_4