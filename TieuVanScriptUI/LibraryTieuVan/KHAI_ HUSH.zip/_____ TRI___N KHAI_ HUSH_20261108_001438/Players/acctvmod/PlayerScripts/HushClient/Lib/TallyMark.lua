-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TallyMark

local v_u_1 = {}
local v3, v_u_4 = pcall(function()
	local v2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
	return require(v2:WaitForChild("TallyRules", 5))
end)
if not v3 or type(v_u_4) ~= "table" then
	v_u_4 = nil
end
v_u_1.count = 6
v_u_1.STROKES = 5
local v_u_5 = Color3.fromRGB(255, 138, 76)
local v_u_6 = Color3.fromRGB(255, 224, 138)
function v_u_1.colorOf(p7, p8) -- name: colorOf
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	local v9
	if type(p8) == "table" then
		local v10 = p8.color
		v9 = type(v10) ~= "table" and {} or p8.color
	else
		v9 = {}
	end
	local v11 = (type(p7) ~= "number" or p7 ~= p7) and 0 or p7
	local v12 = math.floor(v11)
	local v13 = v12 < 0 and 0 or (v12 > 5 and 5 or v12)
	return ({
		v9.text2 or Color3.fromRGB(154, 163, 174),
		v9.info or Color3.fromRGB(111, 168, 220),
		v9.success or Color3.fromRGB(95, 191, 122),
		v9.accent or Color3.fromRGB(232, 163, 61),
		v_u_5,
		v_u_6
	})[v13 + 1]
end
local v_u_14 = {
	0.14,
	0.34,
	0.54,
	0.74
}
local v_u_15 = { 0.06, 0.78 }
local v_u_16 = { 0.94, 0.22 }
function v_u_1.fraction(p17, p18) -- name: fraction
	local v19 = ((type(p18) ~= "number" or p18 ~= p18) and 0 or p18) * 5 - (p17 - 1)
	return v19 < 0 and 0 or (v19 > 1 and 1 or v19)
end
function v_u_1.rect(p20, p21, p22) -- name: rect
	-- upvalues: (copy) v_u_14, (copy) v_u_16, (copy) v_u_15
	local v23 = (type(p22) ~= "number" or p22 ~= p22) and 1 or p22
	local v24 = v23 < 0 and 0 or (v23 > 1 and 1 or v23)
	local v25 = p21 * 0.1 + 0.5
	local v26 = math.floor(v25)
	local v27 = math.max(2, v26)
	if p20 >= 1 and p20 <= 4 then
		local v28 = p21 * 0.8
		return {
			["cx"] = nil,
			["cy"] = nil,
			["w"] = nil,
			["h"] = nil,
			["rot"] = 0,
			["cx"] = p21 * v_u_14[p20],
			["cy"] = p21 * 0.19999999999999996 / 2 + v28 * v24 / 2,
			["w"] = v27,
			["h"] = v28 * v24
		}
	end
	local v29 = (v_u_16[1] - v_u_15[1]) * p21
	local v30 = (v_u_16[2] - v_u_15[2]) * p21
	local v31 = v29 * v29 + v30 * v30
	local v32 = math.sqrt(v31)
	local v33 = p21 * v_u_15[1]
	local v34 = p21 * v_u_15[2]
	local v35 = p21 * v_u_16[1]
	local v36 = p21 * v_u_16[2]
	local v37 = (v35 - v33) / v32
	local v38 = (v36 - v34) / v32
	local v39 = v32 * v24
	local v40 = {
		["cx"] = v33 + v37 * v39 / 2,
		["cy"] = v34 + v38 * v39 / 2,
		["w"] = v39,
		["h"] = v27
	}
	local v41 = v36 - v34
	local v42 = v35 - v33
	local v43 = math.atan2(v41, v42)
	v40.rot = math.deg(v43)
	return v40
end
function v_u_1.bounds(p44) -- name: bounds
	-- upvalues: (copy) v_u_1
	local v45 = (1 / 0)
	local v46 = (-1 / 0)
	local v47 = (1 / 0)
	local v48 = (-1 / 0)
	for v49 = 1, 5 do
		local v50 = v_u_1.rect(v49, p44, 1)
		local v51 = v50.rot
		local v52 = math.rad(v51)
		local v53 = math.cos(v52)
		local v54 = math.abs(v53) * v50.w
		local v55 = math.sin(v52)
		local v56 = (v54 + math.abs(v55) * v50.h) / 2
		local v57 = math.sin(v52)
		local v58 = math.abs(v57) * v50.w
		local v59 = math.cos(v52)
		local v60 = (v58 + math.abs(v59) * v50.h) / 2
		local v61 = v50.cx - v56
		v45 = math.min(v45, v61)
		local v62 = v50.cx + v56
		v46 = math.max(v46, v62)
		local v63 = v50.cy - v60
		v47 = math.min(v47, v63)
		local v64 = v50.cy + v60
		v48 = math.max(v48, v64)
	end
	return {
		["x0"] = v45,
		["y0"] = v47,
		["x1"] = v46,
		["y1"] = v48
	}
end
function v_u_1.level(p65) -- name: level
	-- upvalues: (ref) v_u_4
	if v_u_4 then
		return v_u_4.level(p65)
	end
	local v66 = (type(p65) ~= "number" or p65 ~= p65) and 0 or p65
	local v67 = 0
	for v68, v69 in {
		10,
		100,
		500,
		1000,
		5000
	} do
		if v69 > v66 then
			continue
		end
		v67 = v68
	end
	return v67
end
function v_u_1.commas(p70) -- name: commas
	-- upvalues: (ref) v_u_4
	if v_u_4 then
		return v_u_4.commas(p70)
	end
	local v71 = (type(p70) ~= "number" or p70 ~= p70) and 0 or p70
	local v72 = math.floor(v71)
	local v73 = math.abs(v72)
	local v74 = tostring(v73)
	local v75 = ""
	while #v74 > 3 do
		v75 = "," .. string.sub(v74, -3) .. v75
		local v76 = #v74 - 3
		v74 = string.sub(v74, 1, v76)
	end
	return v74 .. v75
end
function v_u_1.chipText(p77) -- name: chipText
	-- upvalues: (copy) v_u_1
	return "TALLY " .. v_u_1.commas(p77)
end
function v_u_1.parseAttr(p78) -- name: parseAttr
	-- upvalues: (ref) v_u_4
	if v_u_4 then
		return v_u_4.parseAttr(p78)
	end
	local v79 = {}
	if type(p78) ~= "string" then
		return v79
	end
	for v80, v81 in string.gmatch(p78, "([%w_]+)=(%d+)") do
		v79[v80] = tonumber(v81) or 0
	end
	return v79
end
function v_u_1.chipModel(p82) -- name: chipModel
	-- upvalues: (copy) v_u_1
	local v83 = type(p82) ~= "table" and {} or p82
	local v84 = v83.weapon
	if type(v84) ~= "string" or (v84 == "" or v83.gold == true) then
		return {
			["show"] = false
		}
	end
	local v85 = v83.attr
	local v86 = type(v85) ~= "table" and {} or v83.attr
	local v87 = v83.live
	local v88 = type(v87) ~= "table" and {} or v83.live
	local v89 = v86[v84]
	local v90 = v88[v84]
	if type(v89) ~= "number" and type(v90) ~= "number" then
		return {
			["show"] = false
		}
	end
	local v91 = (type(v89) ~= "number" or v89 ~= v89) and 0 or v89
	local v92 = (type(v90) ~= "number" or v90 ~= v90) and 0 or v90
	local v93 = math.max(v91, v92)
	return {
		["show"] = true,
		["k"] = nil,
		["text"] = nil,
		["level"] = nil,
		["weaponId"] = nil,
		["k"] = v93,
		["text"] = v_u_1.chipText(v93),
		["level"] = v_u_1.level(v93),
		["weaponId"] = v84
	}
end
function v_u_1.mateText(p94, p95) -- name: mateText
	-- upvalues: (copy) v_u_1, (ref) v_u_4
	if type(p95) ~= "string" or p95 == "" then
		return nil
	end
	if type(p94) ~= "table" then
		if type(p94) == "string" then
			p94 = v_u_1.parseAttr(p94)
		else
			p94 = nil
		end
	end
	if p94 == nil then
		return nil
	end
	local v96 = p94[p95]
	if type(v96) ~= "number" then
		return nil
	end
	if v_u_4 then
		local v97 = v_u_4.markerText
		if type(v97) == "function" then
			return v_u_4.markerText(v96)
		end
	end
	return v_u_1.chipText(v96)
end
function v_u_1.new(p98, p99) -- name: new
	-- upvalues: (copy) v_u_1
	local v100 = type(p99) ~= "table" and {} or p99
	local v101 = v100.size
	local v102 = (type(v101) ~= "number" or v101 ~= v101) and 24 or v101
	local v103 = math.floor(v102)
	local v_u_104 = math.max(8, v103)
	local v_u_105 = {
		["size"] = nil,
		["strokes"] = nil,
		["level"] = nil,
		["progress"] = 1,
		["size"] = v_u_104,
		["strokes"] = {}
	}
	local v106 = v100.level
	local v107 = (type(v106) ~= "number" or v106 ~= v106) and 0 or v106
	local v108 = math.floor(v107)
	v_u_105.level = v108 < 0 and 0 or (v108 > 5 and 5 or v108)
	local v_u_109 = nil
	local function v110()
		-- upvalues: (ref) v_u_109
		v_u_109 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme", 5))
	end
	pcall(v110)
	local v_u_111 = Instance.new("Frame")
	local v112 = v100.name
	v_u_111.Name = type(v112) ~= "string" and "TallyMark" or v100.name
	v_u_111.BackgroundTransparency = 1
	v_u_111.BorderSizePixel = 0
	v_u_111.Size = UDim2.fromOffset(v_u_104, v_u_104)
	v_u_105.frame = v_u_111
	local v113 = v100.color
	local v114
	if typeof(v113) == "Color3" then
		v114 = v100.color
	else
		v114 = v_u_1.colorOf(v_u_105.level, v_u_109)
	end
	v_u_105.color = v114
	local v_u_115 = v_u_109
	for v116 = 1, 5 do
		local v117 = v_u_105.strokes
		local v118 = Instance.new("Frame")
		v118.Name = "S" .. v116
		v118.BorderSizePixel = 0
		v118.BackgroundColor3 = v114
		v118.AnchorPoint = Vector2.new(0.5, 0.5)
		v118.Parent = v_u_111
		v117[v116] = v118
	end
	local function v_u_133() -- name: draw
		-- upvalues: (ref) v_u_1, (copy) v_u_105, (copy) v_u_104
		for v119 = 1, 5 do
			local v120 = v_u_1.fraction(v119, v_u_105.progress)
			local v121 = v_u_105.strokes[v119]
			if v120 <= 0 then
				v121.Visible = false
			else
				local v122 = v_u_1.rect(v119, v_u_104, v120)
				v121.Visible = true
				local v123 = UDim2.fromOffset
				local v124 = v122.w + 0.5
				local v125 = math.floor(v124)
				local v126 = math.max(1, v125)
				local v127 = v122.h + 0.5
				local v128 = math.floor(v127)
				v121.Size = v123(v126, (math.max(1, v128)))
				local v129 = UDim2.fromOffset
				local v130 = v122.cx + 0.5
				local v131 = math.floor(v130)
				local v132 = v122.cy + 0.5
				v121.Position = v129(v131, (math.floor(v132)))
				v121.Rotation = v122.rot
			end
		end
	end
	function v_u_105.setProgress(p134, p135) -- name: setProgress
		-- upvalues: (copy) v_u_133
		local v136 = (type(p135) ~= "number" or p135 ~= p135) and 1 or p135
		local v137 = v136 < 0 and 0 or (v136 > 1 and 1 or v136)
		if v137 ~= p134.progress then
			p134.progress = v137
			v_u_133()
		end
	end
	function v_u_105.setColor(p138, p139) -- name: setColor
		p138.color = p139
		for _, v140 in p138.strokes do
			v140.BackgroundColor3 = p139
		end
	end
	function v_u_105.setLevel(p141, p142) -- name: setLevel
		-- upvalues: (ref) v_u_1, (ref) v_u_115
		local v143 = (type(p142) ~= "number" or p142 ~= p142) and 0 or p142
		local v144 = math.floor(v143)
		p141.level = v144 < 0 and 0 or (v144 > 5 and 5 or v144)
		p141:setColor(v_u_1.colorOf(p141.level, v_u_115))
	end
	function v_u_105.destroy(_) -- name: destroy
		-- upvalues: (copy) v_u_111
		v_u_111:Destroy()
	end
	local v145 = v100.progress
	local v146 = (type(v145) ~= "number" or v145 ~= v145) and 1 or v145
	v_u_105.progress = v146 < 0 and 0 or (v146 > 1 and 1 or v146)
	v_u_133()
	if p98 then
		v_u_111.Parent = p98
	end
	return v_u_105
end
return v_u_1