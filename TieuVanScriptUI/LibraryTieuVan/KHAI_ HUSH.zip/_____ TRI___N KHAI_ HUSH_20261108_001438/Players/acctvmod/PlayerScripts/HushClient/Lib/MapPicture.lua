-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MapPicture

local v_u_1 = {}
local function v_u_8(p_u_2) -- name: defaultPreview
	local v6, v7 = pcall(function()
		-- upvalues: (copy) p_u_2
		local v3 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
		if v3 then
			v3 = game:GetService("ReplicatedStorage").Hush:FindFirstChild("Shared")
		end
		if v3 then
			local v4 = v3:FindFirstChild("Config")
			if v4 and require(v4).flag("MapPreviewRenders") == false then
				return nil
			else
				local v5 = v3:FindFirstChild("MapPreviews")
				if v5 then
					return (require(v5).get or function()
						return nil
					end)(p_u_2)
				else
					return nil
				end
			end
		else
			return nil
		end
	end)
	if v6 then
		return v7
	else
		return nil
	end
end
function v_u_1.cropRect(p9, p10, p11, p12) -- name: cropRect
	local v13 = p9.X
	local v14 = math.max(1, v13)
	local v15 = p9.Y
	local v16 = math.max(1, v15)
	local v17 = p10.X
	local v18 = math.max(0.001, v17)
	local v19 = p10.Y
	local v20 = v18 / math.max(0.001, v19)
	local v21 = v14 / v20
	local v22
	if v16 < v21 then
		v22 = v16 * v20
		v21 = v16
	else
		v22 = v14
	end
	local v23 = math.max(1, p12 or 1)
	local v24 = v22 / v23
	local v25 = v21 / v23
	local v26 = p11 or Vector2.new(0.5, 0.5)
	local v27 = v26.X * v14 - v24 / 2
	local v28 = v14 - v24
	local v29
	if v28 < 0 then
		v29 = (v28 + 0) / 2
	else
		v29 = math.clamp(v27, 0, v28)
	end
	local v30 = v26.Y * v16 - v25 / 2
	local v31 = v16 - v25
	local v32
	if v31 < 0 then
		v32 = (v31 + 0) / 2
	else
		v32 = math.clamp(v30, 0, v31)
	end
	local v33 = Vector2.new
	local v34 = v29 + 0.5
	local v35 = math.floor(v34)
	local v36 = v32 + 0.5
	local v37 = v33(v35, (math.floor(v36)))
	local v38 = Vector2.new
	local v39 = v24 + 0.5
	local v40 = math.floor(v39)
	local v41 = v25 + 0.5
	return v37, v38(v40, (math.floor(v41)))
end
function v_u_1.new(p_u_42, p43) -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v44 = p43 or {}
	local v_u_45 = v44.theme
	local v_u_46 = v_u_45 and (v_u_45.color or {}) or {}
	local v47 = v44.height
	local v_u_48 = tonumber(v47) or 100
	local v49 = v_u_46.bgDeep or Color3.fromHex("07090C")
	p_u_42.ClipsDescendants = true
	local v50 = {
		["Name"] = "Picture",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v49,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_51 = Instance.new("Frame")
	v_u_51.BorderSizePixel = 0
	local v_u_52 = {
		["kind"] = "plain"
	}
	for v53, v54 in v50 do
		v_u_51[v53] = v54
	end
	v_u_51.Parent = p_u_42
	local v55 = {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["ClipsDescendants"] = true,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_56 = Instance.new("Frame")
	v_u_56.BorderSizePixel = 0
	for v57, v58 in v55 do
		v_u_56[v57] = v58
	end
	v_u_56.Parent = v_u_51
	local v59 = {
		["Name"] = "Dim",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.42,
		["Size"] = nil,
		["ZIndex"] = 5,
		["BackgroundColor3"] = v49,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_60 = Instance.new("Frame")
	v_u_60.BorderSizePixel = 0
	for v61, v62 in v59 do
		v_u_60[v61] = v62
	end
	v_u_60.Parent = v_u_51
	local v63 = Instance.new("UIGradient")
	v63.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.18, 0.3),
		NumberSequenceKeypoint.new(0.82, 0.3),
		NumberSequenceKeypoint.new(1, 0)
	})
	v63.Parent = v_u_60
	local v_u_64 = nil
	local v_u_65 = ""
	local v_u_66 = nil
	local v_u_67 = nil
	local v_u_68 = 0
	local v69 = v44.preview
	local v_u_70
	if type(v69) == "function" then
		v_u_70 = v44.preview
	elseif v44.preview == false then
		v_u_70 = nil
	else
		v_u_70 = v_u_8
	end
	local v_u_71 = 0
	local v_u_72 = {}
	local v_u_73 = true
	local function v_u_76() -- name: clearBody
		-- upvalues: (copy) v_u_56, (copy) v_u_51, (copy) v_u_52, (ref) v_u_66, (ref) v_u_67, (ref) v_u_71
		for _, v74 in v_u_56:GetChildren() do
			v74:Destroy()
		end
		local v75 = v_u_51:FindFirstChild("Preview")
		if v75 then
			v75:Destroy()
		end
		v_u_52.preview = false
		v_u_66 = nil
		v_u_67 = nil
		v_u_71 = 0
	end
	local function v_u_82() -- name: fitImage
		-- upvalues: (ref) v_u_67, (ref) v_u_64, (ref) v_u_66, (copy) p_u_42, (ref) v_u_1
		local v77 = v_u_67 or v_u_64
		if v_u_66 and v77 then
			local v78 = p_u_42.AbsoluteSize
			local v79 = v77.imageSize
			if typeof(v79) == "Vector2" and (v78.X > 1 and v78.Y > 1) then
				local v80, v81 = v_u_1.cropRect(v79, v78, v77.focus, v77.zoom)
				v_u_66.ImageRectOffset = v80
				v_u_66.ImageRectSize = v81
			else
				v_u_66.ImageRectOffset = Vector2.zero
				v_u_66.ImageRectSize = Vector2.zero
			end
		else
			return
		end
	end
	local function v_u_116(p83) -- name: drawTown
		-- upvalues: (copy) p_u_42, (copy) v_u_48, (copy) v_u_56, (copy) v_u_45, (ref) v_u_71
		local v84 = p_u_42.AbsoluteSize
		local v85
		if v84.X < 2 or v84.Y < 2 then
			v85 = nil
		else
			local v86 = v84.Y / v_u_48
			v85 = Vector2.new(v84.X / v86, v_u_48)
		end
		if v85 then
			local v_u_87 = nil
			local function v88()
				-- upvalues: (ref) v_u_87
				v_u_87 = require((script.Parent:WaitForChild("MapDraw", 5)))
			end
			pcall(v88)
			if v_u_87 then
				local v_u_89 = nil
				local function v90()
					-- upvalues: (ref) v_u_89
					v_u_89 = require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapInfo", 2))).fromRuntime()
				end
				pcall(v90)
				local v91 = p83.zoom
				local v92 = tonumber(v91) or 1
				local v93 = math.max(1, v92)
				local v94 = v85.X
				local v95 = v85.Y
				local v96 = math.max(v94, v95) * v93 + 0.5
				local v_u_97 = math.floor(v96)
				local v98 = v_u_56
				local v99 = {
					["Name"] = "Town",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["ZIndex"] = 1,
					["Size"] = UDim2.fromOffset(v_u_97, v_u_97)
				}
				local v_u_100 = Instance.new("Frame")
				v_u_100.BorderSizePixel = 0
				local v_u_101 = v_u_89
				local v_u_102 = v_u_87
				for v103, v104 in v99 do
					v_u_100[v103] = v104
				end
				v_u_100.Parent = v98
				local function v105()
					-- upvalues: (ref) v_u_102, (copy) v_u_100, (copy) v_u_97, (ref) v_u_101, (ref) v_u_45
					v_u_102.build(v_u_100, v_u_97, v_u_101, v_u_45 and v_u_45.font or nil)
				end
				local v106, v107 = pcall(v105)
				if v106 then
					local v108 = p83.focus
					local v109
					if typeof(v108) == "Vector2" then
						v109 = p83.focus
					else
						v109 = Vector2.new(0.5, 0.5)
					end
					local v110 = v85.X / 2 - v109.X * v_u_97
					local v111 = v85.X - v_u_97
					local v112
					if v111 > 0 then
						v112 = (v111 + 0) / 2
					else
						v112 = math.clamp(v110, v111, 0)
					end
					local v113 = v85.Y / 2 - v109.Y * v_u_97
					local v114 = v85.Y - v_u_97
					local v115
					if v114 > 0 then
						v115 = (v114 + 0) / 2
					else
						v115 = math.clamp(v113, v114, 0)
					end
					v_u_100.Position = UDim2.fromOffset(math.floor(v112), (math.floor(v115)))
					v_u_71 = v85.X
				else
					warn("[MapPicture] town drawing failed:", v107)
					v_u_100:Destroy()
				end
			else
				return
			end
		else
			return
		end
	end
	local function v_u_163(p117) -- name: drawTunnels
		-- upvalues: (copy) v_u_46, (copy) v_u_56, (copy) v_u_45
		local v118 = Color3.fromHex("0B0E12")
		local v119 = v_u_46.raised2 or Color3.fromHex("1C222B")
		local v_u_120 = v_u_46.lineStrong or Color3.fromHex("3A4552")
		local v121 = v_u_46.info or Color3.fromHex("6FA8DC")
		local v122 = v_u_56
		local v123 = {
			["Name"] = "Tunnels",
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v118,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v_u_124 = Instance.new("Frame")
		v_u_124.BorderSizePixel = 0
		for v125, v126 in v123 do
			v_u_124[v125] = v126
		end
		v_u_124.Parent = v122
		local function v141(p127, p128, p129, p130, p131, p132, p133, p134) -- name: bar
			-- upvalues: (copy) v_u_124, (copy) v_u_120
			local v135 = v_u_124
			local v136 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ZIndex"] = 2,
				["Name"] = p134 or "Drift",
				["BackgroundColor3"] = p132,
				["BackgroundTransparency"] = p133 or 0,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(p127, p128),
				["Size"] = UDim2.new(p129, 0, 0, p130),
				["Rotation"] = p131
			}
			local v137 = Instance.new("Frame")
			v137.BorderSizePixel = 0
			for v138, v139 in v136 do
				v137[v138] = v139
			end
			v137.Parent = v135
			local v140 = Instance.new("UIStroke")
			v140.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v140.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v140.Color = v_u_120
			v140.Thickness = 1
			v140.Transparency = 0.35
			v140.Parent = v137
			return v137
		end
		v141(0.5, 0.52, 1.1, 10, -3, v119)
		v141(0.28, 0.5, 0.5, 8, 74, v119)
		v141(0.71, 0.48, 0.55, 8, -68, v119)
		v141(0.86, 0.28, 0.32, 7, 8, v119)
		v141(0.14, 0.78, 0.3, 7, -6, v119)
		v141(0.55, 0.82, 0.36, 7, 4, v119)
		v141(0.42, 0.2, 0.26, 7, -10, v119)
		for v142 = 0, 3 do
			for v143 = 0, 1 do
				local v144 = {
					["Name"] = "Pillar",
					["BackgroundColor3"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 3,
					["BackgroundColor3"] = v118,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(v142 * 0.045 + 0.585, v143 * 0.2 + 0.24),
					["Size"] = UDim2.fromOffset(9, 9)
				}
				local v145 = Instance.new("Frame")
				v145.BorderSizePixel = 0
				for v146, v147 in v144 do
					v145[v146] = v147
				end
				v145.Parent = v_u_124
			end
		end
		local v148 = {
			["Name"] = "Hall",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v119,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.65, 0.34),
			["Size"] = UDim2.fromScale(0.22, 0.52)
		}
		local v149 = Instance.new("Frame")
		v149.BorderSizePixel = 0
		for v150, v151 in v148 do
			v149[v150] = v151
		end
		v149.Parent = v_u_124
		local v152 = Instance.new("UIStroke")
		v152.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v152.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v152.Color = v_u_120
		v152.Thickness = 1
		v152.Transparency = 0.35
		v152.Parent = v149
		v141(0.36, 0.53, 0.12, 22, -3, v121, 0.8, "ColdStore").ZIndex = 3
		for v153 = 1, 9 do
			local v154 = {
				["Name"] = "Survey",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_120,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(v153 / 10, 0.52 - (v153 / 10 - 0.5) * 0.09),
				["Size"] = UDim2.fromOffset(2, 2)
			}
			local v155 = Instance.new("Frame")
			v155.BorderSizePixel = 0
			for v156, v157 in v154 do
				v155[v156] = v157
			end
			v155.Parent = v_u_124
		end
		local v158 = Instance.new("TextLabel")
		v158.Name = "PlanTitle"
		v158.BackgroundTransparency = 1
		v158.Position = UDim2.fromOffset(10, 6)
		local v159
		if v_u_45 then
			local v160 = v_u_45.phoneText
			v159 = type(v160) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
		else
			v159 = 12
		end
		v158.Size = UDim2.new(0.55, 0, 0, v159 + 2)
		v158.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
		v158.TextSize = v159
		v158.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
		v158.TextTransparency = 0.15
		v158.TextXAlignment = Enum.TextXAlignment.Left
		v158.TextTruncate = Enum.TextTruncate.AtEnd
		local v161 = string.upper
		local v162 = p117.name or ""
		v158.Text = v161((tostring(v162))) .. "  \194\183  LEVEL PLAN PENDING"
		v158.ZIndex = 6
		v158.Parent = v_u_124
	end
	local function v_u_269(p164) -- name: drawAirfield
		-- upvalues: (copy) p_u_42, (copy) v_u_48, (copy) v_u_46, (copy) v_u_56, (copy) v_u_45, (ref) v_u_71
		local v165 = p_u_42.AbsoluteSize
		local v166
		if v165.X < 2 or v165.Y < 2 then
			v166 = nil
		else
			local v167 = v165.Y / v_u_48
			v166 = Vector2.new(v165.X / v167, v_u_48)
		end
		if v166 then
			local v_u_168 = nil
			local function v169()
				-- upvalues: (ref) v_u_168
				v_u_168 = require((script.Parent:WaitForChild("KestrelMapData", 5)))
			end
			pcall(v169)
			local v170 = v_u_168
			if type(v170) == "table" then
				local v171 = v_u_168.HALF
				if type(v171) == "number" then
					local v172 = Color3.fromHex("0B0E12")
					local v173 = v_u_46.raised2 or Color3.fromHex("1C222B")
					local v174 = v_u_46.raised or Color3.fromHex("161B22")
					local v175 = v_u_46.lineStrong or Color3.fromHex("3A4552")
					local v176 = v_u_46.line or Color3.fromHex("2A323D")
					local v177 = v_u_46.accent or Color3.fromHex("E8A33D")
					local v_u_178 = v_u_168.HALF
					local v179 = p164.zoom
					local v180 = tonumber(v179) or 1
					local v181 = math.max(1, v180)
					local v182 = v166.X
					local v183 = v166.Y
					local v184 = math.max(v182, v183) * v181 + 0.5
					local v185 = math.floor(v184)
					local v_u_186 = v185 / (v_u_178 * 2)
					local v187 = v_u_56
					local v188 = {
						["Name"] = "Airfield",
						["BackgroundColor3"] = nil,
						["Size"] = nil,
						["ZIndex"] = 1,
						["BackgroundColor3"] = v172,
						["Size"] = UDim2.fromOffset(v185, v185)
					}
					local v_u_189 = Instance.new("Frame")
					v_u_189.BorderSizePixel = 0
					local v190 = v_u_168
					for v191, v192 in v188 do
						v_u_189[v191] = v192
					end
					v_u_189.Parent = v187
					local v193 = v190.FENCE_HALF or 580
					local function v224(p194, p195, p196, p197, p198, p199, p200, p201) -- name: box
						-- upvalues: (copy) v_u_178, (copy) v_u_186, (copy) v_u_189
						local v202 = math.min(p194, p196)
						local v203 = math.min(p195, p197)
						local v204 = Vector2.new((v202 + v_u_178) * v_u_186, (v203 + v_u_178) * v_u_186)
						local v205 = math.max(p194, p196)
						local v206 = math.max(p195, p197)
						local v207 = Vector2.new((v205 + v_u_178) * v_u_186, (v206 + v_u_178) * v_u_186)
						local v208 = v_u_189
						local v209 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Name"] = p201 or "Box",
							["BackgroundColor3"] = p198,
							["BackgroundTransparency"] = p199 or 0
						}
						local v210 = UDim2.fromOffset
						local v211 = v204.X
						local v212 = math.floor(v211)
						local v213 = v204.Y
						v209.Position = v210(v212, (math.floor(v213)))
						local v214 = UDim2.fromOffset
						local v215 = v207.X - v204.X
						local v216 = math.ceil(v215)
						local v217 = math.max(1, v216)
						local v218 = v207.Y - v204.Y
						local v219 = math.ceil(v218)
						v209.Size = v214(v217, (math.max(1, v219)))
						local v220 = Instance.new("Frame")
						v220.BorderSizePixel = 0
						for v221, v222 in v209 do
							v220[v221] = v222
						end
						v220.Parent = v208
						if p200 then
							local v223 = Instance.new("UIStroke")
							v223.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
							v223.BorderStrokePosition = Enum.BorderStrokePosition.Inner
							v223.Color = p200
							v223.Thickness = 1
							v223.Transparency = 0.35
							v223.Parent = v220
						end
						return v220
					end
					for _, v225 in {
						{
							-v193,
							-v193,
							v193,
							-v193
						},
						{
							-v193,
							v193,
							v193,
							v193
						},
						{
							-v193,
							-v193,
							-v193,
							v193
						},
						{
							v193,
							-v193,
							v193,
							v193
						}
					} do
						local v226 = v224(v225[1], v225[2], v225[3], v225[4], v175, 0.35, nil, "Fence")
						if v225[1] == v225[3] then
							v226.Size = UDim2.fromOffset(2, v226.Size.Y.Offset)
						else
							v226.Size = UDim2.fromOffset(v226.Size.X.Offset, 2)
						end
					end
					for _, v227 in v190.APRONS do
						v224(v227[1], v227[2], v227[3], v227[4], v173, 0.1, v176, "Apron")
					end
					for _, v228 in v190.TAXIWAYS do
						v224(v228[1], v228[2], v228[3], v228[4], v174, 0.05, v176, "Taxiway")
					end
					for _, v229 in v190.ROADS do
						if v229[6] == "service" then
							continue
						end
						v224(v229[1], v229[2], v229[3], v229[4], v176, 0.2, nil, "Road")
					end
					local v230 = v190.RUNWAY
					v224(v230.x0 - v230.overrun, v230.cz - v230.width / 2, v230.x1 + v230.overrun, v230.cz + v230.width / 2, v174, 0.1, v176, "Overrun")
					v224(v230.x0, v230.cz - v230.width / 2, v230.x1, v230.cz + v230.width / 2, v173, 0, v175, "Runway")
					local v231 = v230.x0 + 30
					while v231 < v230.x1 - 30 do
						local v232 = v224(v231, v230.cz - 0.6, v231 + 30, v230.cz + 0.6, v175, 0.2, nil, "Dash")
						local v233 = UDim2.fromOffset
						local v234 = v232.Size.X.Offset
						local v235 = v232.Size.Y.Offset
						v232.Size = v233(v234, (math.max(1, v235)))
						v231 = v231 + 52
					end
					for _, v236 in v190.PADS do
						v224(v236[1], v236[2], v236[3], v236[4], v174, 0.4, nil, "Pad")
					end
					for _, v237 in v190.LOTS do
						local v238 = v190.LANDMARKS[v237[1]] ~= nil
						local v239 = v237[4] - v237[6] / 2
						local v240 = v237[5] - v237[7] / 2
						local v241 = v237[4] + v237[6] / 2
						local v242 = v237[5] + v237[7] / 2
						local v243
						if v238 then
							v243 = v173:Lerp(v177, 0.28)
						else
							v243 = v174
						end
						local v244 = 0
						local v245
						if v238 then
							v245 = v177
						else
							v245 = v175
						end
						v224(v239, v240, v241, v242, v243, v244, v245, "Lot")
					end
					for _, v246 in v190.TENTS do
						local v247 = v246[3]
						local v248 = v246[4]
						local v249 = v246[5] / 90 + 0.5
						if math.floor(v249) % 2 == 0 then
							local v250 = v247
							v247 = v248
							v248 = v250
						end
						v224(v246[1] - v248 / 2, v246[2] - v247 / 2, v246[1] + v248 / 2, v246[2] + v247 / 2, v177, 0.55, v177, "Tent")
					end
					for _, v251 in v190.PLANES do
						if v251[1] ~= "small" and v251[1] ~= "twin" then
							continue
						end
						local v252 = v251[4]
						local v253 = v251[5]
						local v254 = v251[6] / 90 + 0.5
						if math.floor(v254) % 2 == 0 then
							local v255 = v252
							v252 = v253
							v253 = v255
						end
						v224(v251[2] - v253 / 2, v251[3] - v252 / 2, v251[2] + v253 / 2, v251[3] + v252 / 2, v175, 0.3, nil, "Plane")
					end
					local v256 = p164.focus
					local v257
					if typeof(v256) == "Vector2" then
						v257 = p164.focus
					else
						v257 = Vector2.new(0.5, 0.5)
					end
					local v258 = v166.X / 2 - v257.X * v185
					local v259 = v166.X - v185
					local v260
					if v259 > 0 then
						v260 = (v259 + 0) / 2
					else
						v260 = math.clamp(v258, v259, 0)
					end
					local v261 = v166.Y / 2 - v257.Y * v185
					local v262 = v166.Y - v185
					local v263
					if v262 > 0 then
						v263 = (v262 + 0) / 2
					else
						v263 = math.clamp(v261, v262, 0)
					end
					v_u_189.Position = UDim2.fromOffset(math.floor(v260), (math.floor(v263)))
					local v264 = Instance.new("TextLabel")
					v264.Name = "PlanTitle"
					v264.BackgroundTransparency = 1
					v264.Position = UDim2.fromOffset(10, 6)
					local v265
					if v_u_45 then
						local v266 = v_u_45.phoneText
						v265 = type(v266) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
					else
						v265 = 12
					end
					v264.Size = UDim2.new(0.55, 0, 0, v265 + 2)
					v264.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
					v264.TextSize = v265
					v264.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
					v264.TextTransparency = 0.15
					v264.TextXAlignment = Enum.TextXAlignment.Left
					v264.TextTruncate = Enum.TextTruncate.AtEnd
					local v267 = string.upper
					local v268 = p164.name or ""
					v264.Text = v267((tostring(v268))) .. "  \194\183  AIRFIELD PLAN"
					v264.ZIndex = 6
					v264.Parent = v_u_56
					v_u_71 = v166.X
					return
				end
			end
		end
	end
	local function v_u_406(p270) -- name: drawRidge
		-- upvalues: (copy) p_u_42, (copy) v_u_48, (copy) v_u_46, (copy) v_u_56, (copy) v_u_45, (ref) v_u_71
		local v271 = p_u_42.AbsoluteSize
		local v272
		if v271.X < 2 or v271.Y < 2 then
			v272 = nil
		else
			local v273 = v271.Y / v_u_48
			v272 = Vector2.new(v271.X / v273, v_u_48)
		end
		if v272 then
			local v_u_274 = nil
			local function v275()
				-- upvalues: (ref) v_u_274
				v_u_274 = require((script.Parent:WaitForChild("AshgroveMapData", 5)))
			end
			pcall(v275)
			local v276 = v_u_274
			if type(v276) == "table" then
				local v277 = v_u_274.HALF
				if type(v277) == "number" then
					local v278 = Color3.fromHex("0A1220")
					local v279 = Color3.fromHex("2F4560")
					local v280 = Color3.fromHex("8AA5C4")
					local v281 = Color3.fromHex("0E1A2A")
					local v282 = v_u_46.lineStrong or Color3.fromHex("3A4552")
					local v283 = Color3.fromHex("A9B8CA")
					local v284 = Color3.fromHex("F2B45A")
					local v_u_285 = v_u_274.HALF
					local v286 = p270.zoom
					local v287 = tonumber(v286) or 1
					local v288 = math.max(1, v287)
					local v289 = v272.X
					local v290 = v272.Y
					local v291 = math.max(v289, v290) * v288 + 0.5
					local v292 = math.floor(v291)
					local v_u_293 = v292 / (v_u_285 * 2)
					local v294 = v_u_56
					local v295 = {
						["Name"] = "Ridge",
						["BackgroundColor3"] = nil,
						["Size"] = nil,
						["ZIndex"] = 1,
						["BackgroundColor3"] = v278,
						["Size"] = UDim2.fromOffset(v292, v292)
					}
					local v_u_296 = Instance.new("Frame")
					v_u_296.BorderSizePixel = 0
					local v297 = v_u_274
					for v298, v299 in v295 do
						v_u_296[v298] = v299
					end
					v_u_296.Parent = v294
					local function v330(p300, p301, p302, p303, p304, p305, p306, p307) -- name: box
						-- upvalues: (copy) v_u_285, (copy) v_u_293, (copy) v_u_296
						local v308 = math.min(p300, p302)
						local v309 = math.min(p301, p303)
						local v310 = Vector2.new((v308 + v_u_285) * v_u_293, (v309 + v_u_285) * v_u_293)
						local v311 = math.max(p300, p302)
						local v312 = math.max(p301, p303)
						local v313 = Vector2.new((v311 + v_u_285) * v_u_293, (v312 + v_u_285) * v_u_293)
						local v314 = p307 or 1
						local v315 = v_u_296
						local v316 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Name"] = p306 or "Box",
							["BackgroundColor3"] = p304,
							["BackgroundTransparency"] = p305 or 0
						}
						local v317 = UDim2.fromOffset
						local v318 = v310.X
						local v319 = math.floor(v318)
						local v320 = v310.Y
						v316.Position = v317(v319, (math.floor(v320)))
						local v321 = UDim2.fromOffset
						local v322 = v313.X - v310.X
						local v323 = math.ceil(v322)
						local v324 = math.max(v314, v323)
						local v325 = v313.Y - v310.Y
						local v326 = math.ceil(v325)
						v316.Size = v321(v324, (math.max(v314, v326)))
						local v327 = Instance.new("Frame")
						v327.BorderSizePixel = 0
						for v328, v329 in v316 do
							v327[v328] = v329
						end
						v327.Parent = v315
						return v327
					end
					local function v346(p331, p332, p333, p334, p335, p336) -- name: line
						-- upvalues: (copy) v_u_296
						local v337 = p332 - p331
						local v338 = v_u_296
						local v339 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["Rotation"] = nil,
							["ZIndex"] = 3,
							["Name"] = p336 or "Seg",
							["BackgroundColor3"] = p334,
							["BackgroundTransparency"] = p335 or 0,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromOffset((p331.X + p332.X) / 2, (p331.Y + p332.Y) / 2),
							["Size"] = UDim2.fromOffset(v337.Magnitude + p333 * 0.5, p333)
						}
						local v340 = v337.Y
						local v341 = v337.X
						local v342 = math.atan2(v340, v341)
						v339.Rotation = math.deg(v342)
						local v343 = Instance.new("Frame")
						v343.BorderSizePixel = 0
						for v344, v345 in v339 do
							v343[v344] = v345
						end
						v343.Parent = v338
					end
					for _, v347 in v297.WOODS do
						v330(v347[1], v347[2], v347[3], v347[4], v281, 0, "Woods")
					end
					for _, v348 in v297.ROCKS do
						local v349 = v330(v348[1], v348[2], v348[3], v348[4], v279, 0.1, "Slope")
						local v350 = v348[5]
						local v351 = (tonumber(v350) or 40) / 100
						local v352 = math.clamp(v351, 0.2, 0.9)
						local v353 = Instance.new("UIGradient")
						v353.Color = ColorSequence.new(v280:Lerp(v279, 1 - v352), v279)
						v353.Rotation = 90
						v353.Parent = v349
					end
					for _, v354 in v297.PADS do
						v330(v354[1], v354[2], v354[3], v354[4], v282, 0.55, "Pad")
					end
					for _, v355 in v297.ROADS do
						if v355[6] == "main" then
							v330(v355[1], v355[2], v355[3], v355[4], v283, 0.1, "Road", 2)
						else
							if v355[6] ~= "street" then
								continue
							end
							v330(v355[1], v355[2], v355[3], v355[4], v282, 0.15, "Road", 1)
						end
					end
					local v356 = v297.TRAM_LINE
					for v357 = 1, #v356 - 1 do
						local v358 = v356[v357][1]
						local v359 = v356[v357][2]
						local v360 = Vector2.new((v358 + v_u_285) * v_u_293, (v359 + v_u_285) * v_u_293)
						local v361 = v356[v357 + 1][1]
						local v362 = v356[v357 + 1][2]
						local v363 = Vector2.new((v361 + v_u_285) * v_u_293, (v362 + v_u_285) * v_u_293)
						local v364 = (v363 - v360).Magnitude
						local v365 = v_u_293 * 12
						local v366 = math.max(5, v365)
						local v367 = v_u_293 * 8
						local v368 = math.max(3, v367)
						local v369 = 0
						local v370 = 0
						while v370 < v364 and v369 < 200 do
							v369 = v369 + 1
							local v371 = v370 + v366
							local v372 = math.min(v364, v371)
							if v372 - v370 > 1 then
								local v373 = (v363 - v360) / math.max(v364, 0.001)
								v346(v360 + v373 * v370, v360 + v373 * v372, 1, Color3.fromHex("DCE6F2"), 0.1, "Cable")
							end
							v370 = v372 + v368
						end
					end
					for _, v374 in v297.LOTS do
						v330(v374[4] - v374[6] / 2, v374[5] - v374[7] / 2, v374[4] + v374[6] / 2, v374[5] + v374[7] / 2, v282, 0.2, "Lot")
					end
					for _, v375 in { "v_term", "inst", "ut_station" } do
						for _, v376 in v297.LOTS do
							if v376[1] ~= v375 then
								continue
							end
							local v377 = v376[4]
							local v378 = v376[5]
							local v379 = Vector2.new((v377 + v_u_285) * v_u_293, (v378 + v_u_285) * v_u_293)
							local v380 = v_u_293 * 18 + 0.5
							local v381 = math.floor(v380)
							local v382 = math.max(4, v381)
							local v383 = {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.12,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["ZIndex"] = 4,
								["Name"] = "Window_" .. v375,
								["BackgroundColor3"] = v284,
								["AnchorPoint"] = Vector2.new(0.5, 0.5),
								["Position"] = UDim2.fromOffset(v379.X, v379.Y),
								["Size"] = UDim2.fromOffset(v382, v382)
							}
							local v384 = Instance.new("Frame")
							v384.BorderSizePixel = 0
							for v385, v386 in v383 do
								v384[v385] = v386
							end
							v384.Parent = v_u_296
							local v387 = Instance.new("UICorner")
							v387.CornerRadius = UDim.new(1, 0)
							v387.Parent = v384
							local v388 = {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.82,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["ZIndex"] = 3,
								["Name"] = "Halo_" .. v375,
								["BackgroundColor3"] = v284,
								["AnchorPoint"] = Vector2.new(0.5, 0.5),
								["Position"] = UDim2.fromOffset(v379.X, v379.Y),
								["Size"] = UDim2.fromOffset(v382 * 3, v382 * 3)
							}
							local v389 = Instance.new("Frame")
							v389.BorderSizePixel = 0
							for v390, v391 in v388 do
								v389[v390] = v391
							end
							v389.Parent = v_u_296
							local v392 = Instance.new("UICorner")
							v392.CornerRadius = UDim.new(1, 0)
							v392.Parent = v389
						end
					end
					local v393 = p270.focus
					local v394
					if typeof(v393) == "Vector2" then
						v394 = p270.focus
					else
						v394 = Vector2.new(0.5, 0.5)
					end
					local v395 = v272.X / 2 - v394.X * v292
					local v396 = v272.X - v292
					local v397
					if v396 > 0 then
						v397 = (v396 + 0) / 2
					else
						v397 = math.clamp(v395, v396, 0)
					end
					local v398 = v272.Y / 2 - v394.Y * v292
					local v399 = v272.Y - v292
					local v400
					if v399 > 0 then
						v400 = (v399 + 0) / 2
					else
						v400 = math.clamp(v398, v399, 0)
					end
					v_u_296.Position = UDim2.fromOffset(math.floor(v397), (math.floor(v400)))
					local v401 = Instance.new("TextLabel")
					v401.Name = "PlanTitle"
					v401.BackgroundTransparency = 1
					v401.Position = UDim2.fromOffset(10, 6)
					local v402
					if v_u_45 then
						local v403 = v_u_45.phoneText
						v402 = type(v403) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
					else
						v402 = 12
					end
					v401.Size = UDim2.new(0.55, 0, 0, v402 + 2)
					v401.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
					v401.TextSize = v402
					v401.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
					v401.TextTransparency = 0.15
					v401.TextXAlignment = Enum.TextXAlignment.Left
					v401.TextTruncate = Enum.TextTruncate.AtEnd
					local v404 = string.upper
					local v405 = p270.name or ""
					v401.Text = v404((tostring(v405))) .. "  \194\183  RIDGE PLAN"
					v401.ZIndex = 6
					v401.Parent = v_u_56
					v_u_71 = v272.X
					return
				end
			end
		end
	end
	local function v_u_564(p407) -- name: drawPlaza
		-- upvalues: (copy) p_u_42, (copy) v_u_48, (copy) v_u_46, (copy) v_u_56, (copy) v_u_45, (ref) v_u_71
		local v408 = p_u_42.AbsoluteSize
		local v409
		if v408.X < 2 or v408.Y < 2 then
			v409 = nil
		else
			local v410 = v408.Y / v_u_48
			v409 = Vector2.new(v408.X / v410, v_u_48)
		end
		if v409 then
			local v_u_411 = nil
			local function v412()
				-- upvalues: (ref) v_u_411
				v_u_411 = require((script.Parent:WaitForChild("OvertureMapData", 5)))
			end
			pcall(v412)
			local v413 = v_u_411
			if type(v413) == "table" then
				local v414 = v_u_411.HALF
				if type(v414) == "number" then
					local v415 = Color3.fromHex("0A0E14")
					local v416 = Color3.fromHex("0F2233")
					local v417 = Color3.fromHex("1D3A52")
					local v418 = Color3.fromHex("2A2A27")
					local v419 = Color3.fromHex("0C1812")
					local v420 = Color3.fromHex("27303A")
					local v421 = v_u_46.raised or Color3.fromHex("161B22")
					local v_u_422 = v_u_46.lineStrong or Color3.fromHex("3A4552")
					local v423 = v_u_46.line or Color3.fromHex("2A323D")
					local v424 = Color3.fromHex("4B5766")
					local v425 = v_u_46.accent or Color3.fromHex("E8A33D")
					local v426 = Color3.fromHex("F2B45A")
					local v_u_427 = v_u_411.HALF
					local v428 = p407.zoom
					local v429 = tonumber(v428) or 1
					local v430 = math.max(1, v429)
					local v431 = v409.X
					local v432 = v409.Y
					local v433 = math.max(v431, v432) * v430 + 0.5
					local v434 = math.floor(v433)
					local v_u_435 = v434 / (v_u_427 * 2)
					local v436 = v_u_56
					local v437 = {
						["Name"] = "Plaza",
						["BackgroundColor3"] = nil,
						["Size"] = nil,
						["ZIndex"] = 1,
						["BackgroundColor3"] = v415,
						["Size"] = UDim2.fromOffset(v434, v434)
					}
					local v_u_438 = Instance.new("Frame")
					v_u_438.BorderSizePixel = 0
					local v439 = v_u_411
					for v440, v441 in v437 do
						v_u_438[v440] = v441
					end
					v_u_438.Parent = v436
					local function v_u_474(p442, p443, p444, p445, p446, p447, p448, p449, p450) -- name: box
						-- upvalues: (copy) v_u_427, (copy) v_u_435, (copy) v_u_438
						local v451 = math.min(p442, p444)
						local v452 = math.min(p443, p445)
						local v453 = Vector2.new((v451 + v_u_427) * v_u_435, (v452 + v_u_427) * v_u_435)
						local v454 = math.max(p442, p444)
						local v455 = math.max(p443, p445)
						local v456 = Vector2.new((v454 + v_u_427) * v_u_435, (v455 + v_u_427) * v_u_435)
						local v457 = p450 or 1
						local v458 = v_u_438
						local v459 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Name"] = p449 or "Box",
							["BackgroundColor3"] = p446,
							["BackgroundTransparency"] = p447 or 0
						}
						local v460 = UDim2.fromOffset
						local v461 = v453.X
						local v462 = math.floor(v461)
						local v463 = v453.Y
						v459.Position = v460(v462, (math.floor(v463)))
						local v464 = UDim2.fromOffset
						local v465 = v456.X - v453.X
						local v466 = math.ceil(v465)
						local v467 = math.max(v457, v466)
						local v468 = v456.Y - v453.Y
						local v469 = math.ceil(v468)
						v459.Size = v464(v467, (math.max(v457, v469)))
						local v470 = Instance.new("Frame")
						v470.BorderSizePixel = 0
						for v471, v472 in v459 do
							v470[v471] = v472
						end
						v470.Parent = v458
						if p448 then
							local v473 = Instance.new("UIStroke")
							v473.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
							v473.BorderStrokePosition = Enum.BorderStrokePosition.Inner
							v473.Color = p448
							v473.Thickness = 1
							v473.Transparency = 0.35
							v473.Parent = v470
						end
						return v470
					end
					for _, v475 in v439.WOODS do
						v_u_474(v475[1], v475[2], v475[3], v475[4], v419, 0, nil, "Woods")
					end
					local v476 = v439.BEACH
					v_u_474(v476[1], v476[2], v476[3], v476[4], v418, 0, nil, "Beach")
					local v477 = v439.WATER
					local v478 = v_u_474(v477[1], v477[2], v477[3], v477[4], v416, 0, nil, "Lake")
					local v479 = Instance.new("UIGradient")
					v479.Color = ColorSequence.new(v417, v416)
					v479.Rotation = 90
					v479.Parent = v478
					for _, v480 in v439.PIERS do
						v_u_474(v480[3], v480[4], v480[5], v480[6], v_u_422, 0.2, nil, "Pier")
					end
					for _, v481 in v439.ROADS do
						local v482 = v481[1]
						local v483 = v481[2]
						local v484 = v481[3]
						local v485 = v481[4]
						local v486
						if v481[6] == "main" then
							v486 = v424
						else
							v486 = v423
						end
						v_u_474(v482, v483, v484, v485, v486, v481[6] == "main" and 0.05 or 0.2, nil, "Road", v481[6] == "service" and 1 or 2)
					end
					for _, v487 in v439.RAIL do
						v_u_474(v487[1], v487[2], v487[3], v487[4], v_u_422, 0.3, nil, "Rail", 1)
					end
					local v488 = v439.PLAZA
					local v489 = v_u_474(v488[1], v488[2], v488[3], v488[4], v420, 0, v_u_422, "Plaza")
					local v490 = Instance.new("UIGradient")
					v490.Color = ColorSequence.new(v420:Lerp(v426, 0.18), v420)
					v490.Rotation = 90
					v490.Parent = v489
					local v491 = v439.FOUNTAIN
					local v492 = v491[1]
					local v493 = v491[2]
					local v494 = Vector2.new((v492 + v_u_427) * v_u_435, (v493 + v_u_427) * v_u_435)
					local v495 = v491[3] * 2 * v_u_435 + 0.5
					local v496 = math.floor(v495)
					local v497 = math.max(4, v496)
					local v498 = {
						["Name"] = "Fountain",
						["BackgroundColor3"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 4,
						["BackgroundColor3"] = v417,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromOffset(v494.X, v494.Y),
						["Size"] = UDim2.fromOffset(v497, v497)
					}
					local v499 = Instance.new("Frame")
					v499.BorderSizePixel = 0
					for v500, v501 in v498 do
						v499[v500] = v501
					end
					v499.Parent = v_u_438
					local v502 = Instance.new("UICorner")
					v502.CornerRadius = UDim.new(1, 0)
					v502.Parent = v499
					for v503, v504 in v439.LOTS do
						local v505 = v439.LANDMARKS[v504[1]] ~= nil
						local v506 = v504[4] - v504[6] / 2
						local v507 = v504[5] - v504[7] / 2
						local v508 = v504[4] + v504[6] / 2
						local v509 = v504[5] + v504[7] / 2
						local v510
						if v505 then
							v510 = v421:Lerp(v425, 0.22)
						else
							v510 = v421
						end
						local v511 = 0
						local v512
						if v505 then
							v512 = v425
						else
							v512 = v_u_422
						end
						v_u_474(v506, v507, v508, v509, v510, v511, v512, "Lot").ZIndex = 3
						local v513 = 0
						for v514 = 1, #v504[1] do
							local v515 = v513 * 31
							local v516 = v504[1]
							v513 = (v515 + string.byte(v516, v514)) % 65521
						end
						for v517 = 1, v505 and 3 or v513 % 3 do
							local v518 = (v513 * (v517 + 3) + v503 * 7) % 100 / 100
							local v519 = (v513 * (v517 + 5) + v503 * 13) % 100 / 100
							local v520 = v506 + (v508 - v506) * (0.15 + 0.7 * v518)
							local v521 = v507 + (v509 - v507) * (0.15 + 0.7 * v519)
							local v522 = Vector2.new((v520 + v_u_427) * v_u_435, (v521 + v_u_427) * v_u_435)
							local v523 = v_u_435 * 5 + 0.5
							local v524 = math.floor(v523)
							local v525 = math.max(2, v524)
							local v526 = {
								["Name"] = "Window",
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = nil,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["ZIndex"] = 4,
								["BackgroundColor3"] = v426,
								["BackgroundTransparency"] = v505 and 0.05 or 0.3,
								["AnchorPoint"] = Vector2.new(0.5, 0.5),
								["Position"] = UDim2.fromOffset(v522.X, v522.Y),
								["Size"] = UDim2.fromOffset(v525, v525)
							}
							local v527 = Instance.new("Frame")
							v527.BorderSizePixel = 0
							for v528, v529 in v526 do
								v527[v528] = v529
							end
							v527.Parent = v_u_438
							v527:SetAttribute("Lot", v504[1])
						end
					end
					local v_u_530 = v439.RING
					local v531 = v439.SHORE
					local v532 = {
						["N"] = {},
						["W"] = {},
						["E"] = {}
					}
					for _, v533 in v439.RING_GAPS do
						local v534 = v532[v533[1]]
						local v535 = { v533[2] - v533[3] / 2, v533[2] + v533[3] / 2 }
						table.insert(v534, v535)
					end
					for v_u_536, v537 in v532 do
						table.sort(v537, function(p538, p539)
							return p538[1] < p539[1]
						end)
						local v540
						if v_u_536 == "N" then
							v540 = v_u_530
						else
							v540 = v531
						end
						local v541 = -v_u_530
						local function v549(p542, p543) -- name: run
							-- upvalues: (copy) v_u_536, (copy) v_u_530, (copy) v_u_474, (copy) v_u_422
							if p543 - p542 < 2 then
								return
							else
								local v544, v545
								if v_u_536 == "N" then
									local v546 = -v_u_530
									local v547 = -v_u_530
									v544 = p543
									p543 = v547
									v545 = p542
									p542 = v546
								elseif v_u_536 == "W" then
									v545 = -v_u_530
									v544 = -v_u_530
								else
									v545 = v_u_530
									v544 = v_u_530
								end
								local v548 = v_u_474(v545, p542, v544, p543, v_u_422, 0.25, nil, "Ring")
								if v_u_536 == "N" then
									v548.Size = UDim2.fromOffset(v548.Size.X.Offset, 1)
								else
									v548.Size = UDim2.fromOffset(1, v548.Size.Y.Offset)
								end
							end
						end
						for _, v550 in v537 do
							v549(v541, v550[1])
							v541 = v550[2]
						end
						v549(v541, v540)
					end
					local v551 = p407.focus
					local v552
					if typeof(v551) == "Vector2" then
						v552 = p407.focus
					else
						v552 = Vector2.new(0.5, 0.5)
					end
					local v553 = v409.X / 2 - v552.X * v434
					local v554 = v409.X - v434
					local v555
					if v554 > 0 then
						v555 = (v554 + 0) / 2
					else
						v555 = math.clamp(v553, v554, 0)
					end
					local v556 = v409.Y / 2 - v552.Y * v434
					local v557 = v409.Y - v434
					local v558
					if v557 > 0 then
						v558 = (v557 + 0) / 2
					else
						v558 = math.clamp(v556, v557, 0)
					end
					v_u_438.Position = UDim2.fromOffset(math.floor(v555), (math.floor(v558)))
					local v559 = Instance.new("TextLabel")
					v559.Name = "PlanTitle"
					v559.BackgroundTransparency = 1
					v559.Position = UDim2.fromOffset(10, 6)
					local v560
					if v_u_45 then
						local v561 = v_u_45.phoneText
						v560 = type(v561) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
					else
						v560 = 12
					end
					v559.Size = UDim2.new(0.55, 0, 0, v560 + 2)
					v559.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
					v559.TextSize = v560
					v559.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
					v559.TextTransparency = 0.15
					v559.TextXAlignment = Enum.TextXAlignment.Left
					v559.TextTruncate = Enum.TextTruncate.AtEnd
					local v562 = string.upper
					local v563 = p407.name or ""
					v559.Text = v562((tostring(v563))) .. "  \194\183  PORT VESPER"
					v559.ZIndex = 6
					v559.Parent = v_u_56
					v_u_71 = v409.X
					return
				end
			end
		end
	end
	local function v_u_716(p565) -- name: drawCity
		-- upvalues: (copy) p_u_42, (copy) v_u_48, (copy) v_u_46, (copy) v_u_56, (copy) v_u_45, (ref) v_u_71
		local v566 = p_u_42.AbsoluteSize
		local v567
		if v566.X < 2 or v566.Y < 2 then
			v567 = nil
		else
			local v568 = v566.Y / v_u_48
			v567 = Vector2.new(v566.X / v568, v_u_48)
		end
		if v567 then
			local v_u_569 = nil
			local function v570()
				-- upvalues: (ref) v_u_569
				v_u_569 = require((script.Parent:WaitForChild("TokyoMapData", 5)))
			end
			pcall(v570)
			local v571 = v_u_569
			if type(v571) == "table" then
				local v572 = v_u_569.HALF
				if type(v572) == "number" then
					local v573 = v_u_569.LOTS
					if type(v573) == "table" then
						local v574 = v_u_569.WATERS
						if type(v574) == "table" then
							local v575 = Color3.fromHex("090D14")
							local v576 = Color3.fromHex("0E2133")
							local v577 = Color3.fromHex("1B3850")
							local v578 = Color3.fromHex("1B222C")
							local v579 = Color3.fromHex("2A333F")
							local v580 = v_u_46.lineStrong or Color3.fromHex("3A4552")
							local v581 = Color3.fromHex("4B5766")
							local v582 = v_u_46.line or Color3.fromHex("2A323D")
							local v583 = v_u_46.accent or Color3.fromHex("E8A33D")
							local v584 = Color3.fromHex("F2B45A")
							local v585 = {
								Color3.fromHex("FF4FA3"),
								Color3.fromHex("37D6E8"),
								Color3.fromHex("9B6BFF"),
								Color3.fromHex("4FE38A")
							}
							local v_u_586 = v_u_569.HALF
							local v587 = p565.zoom
							local v588 = tonumber(v587) or 1
							local v589 = math.max(1, v588)
							local v590 = v567.X
							local v591 = v567.Y
							local v592 = math.max(v590, v591) * v589 + 0.5
							local v593 = math.floor(v592)
							local v_u_594 = v593 / (v_u_586 * 2)
							local v595 = v_u_56
							local v596 = {
								["Name"] = "City",
								["BackgroundColor3"] = nil,
								["Size"] = nil,
								["ZIndex"] = 1,
								["BackgroundColor3"] = v575,
								["Size"] = UDim2.fromOffset(v593, v593)
							}
							local v_u_597 = Instance.new("Frame")
							v_u_597.BorderSizePixel = 0
							local v598 = v_u_569
							for v599, v600 in v596 do
								v_u_597[v599] = v600
							end
							v_u_597.Parent = v595
							local function v633(p601, p602, p603, p604, p605, p606, p607, p608, p609) -- name: box
								-- upvalues: (copy) v_u_586, (copy) v_u_594, (copy) v_u_597
								local v610 = math.min(p601, p603)
								local v611 = math.min(p602, p604)
								local v612 = Vector2.new((v610 + v_u_586) * v_u_594, (v611 + v_u_586) * v_u_594)
								local v613 = math.max(p601, p603)
								local v614 = math.max(p602, p604)
								local v615 = Vector2.new((v613 + v_u_586) * v_u_594, (v614 + v_u_586) * v_u_594)
								local v616 = p609 or 1
								local v617 = v_u_597
								local v618 = {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = nil,
									["Position"] = nil,
									["Size"] = nil,
									["ZIndex"] = 2,
									["Name"] = p608 or "Box",
									["BackgroundColor3"] = p605,
									["BackgroundTransparency"] = p606 or 0
								}
								local v619 = UDim2.fromOffset
								local v620 = v612.X
								local v621 = math.floor(v620)
								local v622 = v612.Y
								v618.Position = v619(v621, (math.floor(v622)))
								local v623 = UDim2.fromOffset
								local v624 = v615.X - v612.X
								local v625 = math.ceil(v624)
								local v626 = math.max(v616, v625)
								local v627 = v615.Y - v612.Y
								local v628 = math.ceil(v627)
								v618.Size = v623(v626, (math.max(v616, v628)))
								local v629 = Instance.new("Frame")
								v629.BorderSizePixel = 0
								for v630, v631 in v618 do
									v629[v630] = v631
								end
								v629.Parent = v617
								if p607 then
									local v632 = Instance.new("UIStroke")
									v632.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
									v632.BorderStrokePosition = Enum.BorderStrokePosition.Inner
									v632.Color = p607
									v632.Thickness = 1
									v632.Transparency = 0.35
									v632.Parent = v629
								end
								return v629
							end
							local function v652(p634, p635, p636, p637, p638) -- name: glow
								-- upvalues: (copy) v_u_586, (copy) v_u_594, (copy) v_u_597
								local v639 = Vector2.new((p634 + v_u_586) * v_u_594, (p635 + v_u_586) * v_u_594)
								local v640 = v_u_597
								local v641 = {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = 0.82,
									["AnchorPoint"] = nil,
									["Position"] = nil,
									["Size"] = nil,
									["ZIndex"] = 3,
									["Name"] = "Halo_" .. p638,
									["BackgroundColor3"] = p636,
									["AnchorPoint"] = Vector2.new(0.5, 0.5),
									["Position"] = UDim2.fromOffset(v639.X, v639.Y),
									["Size"] = UDim2.fromOffset(p637 * 3, p637 * 3)
								}
								local v642 = Instance.new("Frame")
								v642.BorderSizePixel = 0
								for v643, v644 in v641 do
									v642[v643] = v644
								end
								v642.Parent = v640
								local v645 = Instance.new("UICorner")
								v645.CornerRadius = UDim.new(1, 0)
								v645.Parent = v642
								local v646 = v_u_597
								local v647 = {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = 0.1,
									["AnchorPoint"] = nil,
									["Position"] = nil,
									["Size"] = nil,
									["ZIndex"] = 4,
									["Name"] = p638,
									["BackgroundColor3"] = p636,
									["AnchorPoint"] = Vector2.new(0.5, 0.5),
									["Position"] = UDim2.fromOffset(v639.X, v639.Y),
									["Size"] = UDim2.fromOffset(p637, p637)
								}
								local v648 = Instance.new("Frame")
								v648.BorderSizePixel = 0
								for v649, v650 in v647 do
									v648[v649] = v650
								end
								v648.Parent = v646
								local v651 = Instance.new("UICorner")
								v651.CornerRadius = UDim.new(1, 0)
								v651.Parent = v648
							end
							for _, v653 in v598.WATERS do
								local v654 = v633(v653[3], v653[4], v653[5], v653[6], v576, 0, nil, "Water")
								if v653[7] ~= "harbor" then
									continue
								end
								local v655 = Instance.new("UIGradient")
								v655.Color = ColorSequence.new(v576, v577)
								v655.Rotation = 90
								v655.Parent = v654
							end
							for _, v656 in v598.BLOCKS do
								v633(v656[1], v656[2], v656[3], v656[4], v578, 0, nil, "Block")
							end
							for _, v657 in v598.ROADS do
								local v658 = v657[6] == "main"
								local v659 = v657[1]
								local v660 = v657[2]
								local v661 = v657[3]
								local v662 = v657[4]
								local v663
								if v658 then
									v663 = v581
								elseif v657[6] == "walk" then
									v663 = v580
								else
									v663 = v582
								end
								v633(v659, v660, v661, v662, v663, v658 and 0.05 or 0.25, nil, "Road", v657[6] == "service" and 1 or 2)
							end
							v633(v598.RAIL_RAMP[1], v598.RAIL_RAMP[2], v598.RAIL_RAMP[3], v598.RAIL_RAMP[4], v580, 0.6, nil, "RailRamp", 1)
							v633(v598.VIADUCT[1], v598.VIADUCT[2], v598.VIADUCT[3], v598.VIADUCT[4], v580, 0.35, nil, "Viaduct", 2)
							v633(v598.PLATFORM[1], v598.PLATFORM[2], v598.PLATFORM[3], v598.PLATFORM[4], v580, 0.3, nil, "Platform", 1)
							v633(v598.DECK[1], v598.DECK[2], v598.DECK[3], v598.DECK[4], v583, 0.55, nil, "Deck", 3)
							for _, v664 in v598.RAMPS do
								v633(v664[3], v664[4], v664[5], v664[6], v583, 0.62, nil, "Ramp", 2)
							end
							for v665, v666 in v598.LOTS do
								local v667 = v598.LANDMARKS[v666[1]] ~= nil
								if not v667 and v666[11] ~= 1 then
									continue
								end
								local v668 = v666[4] - v666[6] / 2
								local v669 = v666[5] - v666[7] / 2
								local v670 = v666[4] + v666[6] / 2
								local v671 = v666[5] + v666[7] / 2
								local v672
								if v667 then
									v672 = v579:Lerp(v583, 0.28)
								else
									v672 = v579
								end
								local v673 = 0
								local v674
								if v667 then
									v674 = v583
								else
									v674 = nil
								end
								v633(v668, v669, v670, v671, v672, v673, v674, "Lot", 2).ZIndex = 3
								local v675 = 0
								for v676 = 1, #v666[1] do
									local v677 = v675 * 31
									local v678 = v666[1]
									v675 = (v677 + string.byte(v678, v676)) % 65521
								end
								for v679 = 1, v667 and 2 or (v675 % 3 == 0 and 1 or 0) do
									local v680 = (v675 * (v679 + 3) + v665 * 7) % 100 / 100
									local v681 = (v675 * (v679 + 5) + v665 * 13) % 100 / 100
									local v682 = v668 + (v670 - v668) * (0.15 + 0.7 * v680)
									local v683 = v669 + (v671 - v669) * (0.15 + 0.7 * v681)
									local v684 = Vector2.new((v682 + v_u_586) * v_u_594, (v683 + v_u_586) * v_u_594)
									local v685 = v_u_594 * 7 + 0.5
									local v686 = math.floor(v685)
									local v687 = math.max(2, v686)
									local v688 = {
										["Name"] = "Window",
										["BackgroundColor3"] = nil,
										["BackgroundTransparency"] = nil,
										["AnchorPoint"] = nil,
										["Position"] = nil,
										["Size"] = nil,
										["ZIndex"] = 4,
										["BackgroundColor3"] = v584,
										["BackgroundTransparency"] = v667 and 0.05 or 0.3,
										["AnchorPoint"] = Vector2.new(0.5, 0.5),
										["Position"] = UDim2.fromOffset(v684.X, v684.Y),
										["Size"] = UDim2.fromOffset(v687, v687)
									}
									local v689 = Instance.new("Frame")
									v689.BorderSizePixel = 0
									for v690, v691 in v688 do
										v689[v690] = v691
									end
									v689.Parent = v_u_597
								end
							end
							local v692 = v598.FERMATA
							v633(v692.hull[1], v692.hull[2], v692.hull[3], v692.hull[4], v579, 0, v580, "Ship", 3).ZIndex = 3
							local v693 = (v692.house[1] + v692.house[3]) / 2
							local v694 = (v692.house[2] + v692.house[4]) / 2
							local v695 = v_u_594 * 8 + 0.5
							local v696 = math.floor(v695)
							v652(v693, v694, v584, math.max(3, v696), "ShipLight")
							for v697 = 0, 9 do
								local v698 = v697 * 38 + -190
								local v699 = v697 % 2 == 0 and -8 or 8
								local v700 = v585[v697 % 4 + 1]
								local v701 = v_u_594 * 6 + 0.5
								local v702 = math.floor(v701)
								v652(v699, v698, v700, math.max(3, v702), "Neon")
							end
							local v703 = p565.focus
							local v704
							if typeof(v703) == "Vector2" then
								v704 = p565.focus
							else
								v704 = Vector2.new(0.5, 0.5)
							end
							local v705 = v567.X / 2 - v704.X * v593
							local v706 = v567.X - v593
							local v707
							if v706 > 0 then
								v707 = (v706 + 0) / 2
							else
								v707 = math.clamp(v705, v706, 0)
							end
							local v708 = v567.Y / 2 - v704.Y * v593
							local v709 = v567.Y - v593
							local v710
							if v709 > 0 then
								v710 = (v709 + 0) / 2
							else
								v710 = math.clamp(v708, v709, 0)
							end
							v_u_597.Position = UDim2.fromOffset(math.floor(v707), (math.floor(v710)))
							local v711 = Instance.new("TextLabel")
							v711.Name = "PlanTitle"
							v711.BackgroundTransparency = 1
							v711.Position = UDim2.fromOffset(10, 6)
							local v712
							if v_u_45 then
								local v713 = v_u_45.phoneText
								v712 = type(v713) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
							else
								v712 = 12
							end
							v711.Size = UDim2.new(0.55, 0, 0, v712 + 2)
							v711.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
							v711.TextSize = v712
							v711.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
							v711.TextTransparency = 0.15
							v711.TextXAlignment = Enum.TextXAlignment.Left
							v711.TextTruncate = Enum.TextTruncate.AtEnd
							local v714 = string.upper
							local v715 = p565.name or ""
							v711.Text = v714((tostring(v715))) .. "  \194\183  MINATO DISTRICT"
							v711.ZIndex = 6
							v711.Parent = v_u_56
							v_u_71 = v567.X
							return
						end
					end
				end
			end
		end
	end
	local function v_u_751(p717, p718) -- name: drawTeaser
		-- upvalues: (copy) v_u_46, (copy) v_u_56, (copy) v_u_45
		local v719 = Color3.fromHex("0B0E12")
		local v720 = v_u_46.raised2 or Color3.fromHex("1C222B")
		local v721 = v_u_46.lineStrong or Color3.fromHex("3A4552")
		local v722 = v_u_46.accent or Color3.fromHex("E8A33D")
		local v723 = v_u_56
		local v724 = {
			["Name"] = "Teaser",
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v719,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v725 = Instance.new("Frame")
		v725.BorderSizePixel = 0
		for v726, v727 in v724 do
			v725[v726] = v727
		end
		v725.Parent = v723
		local v728 = Instance.new("UIGradient")
		v728.Color = ColorSequence.new(v719, v720:Lerp(v719, 0.55))
		v728.Rotation = 90
		v728.Parent = v725
		if p718 == "skyline" then
			for v729, v730 in {
				{ 0.03, 0.3 },
				{ 0.1, 0.5 },
				{ 0.17, 0.38 },
				{ 0.24, 0.64 },
				{ 0.32, 0.44 },
				{ 0.4, 0.86 },
				{ 0.49, 0.56 },
				{ 0.57, 0.42 },
				{ 0.64, 0.68 },
				{ 0.72, 0.48 },
				{ 0.79, 0.36 },
				{ 0.86, 0.6 },
				{ 0.93, 0.4 }
			} do
				local v731 = v729 == 6
				local v732 = {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["Name"] = v731 and "Overture" or "Tower",
					["BackgroundColor3"] = v720,
					["BackgroundTransparency"] = v731 and 0 or 0.1,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(v730[1], 1),
					["Size"] = UDim2.fromScale(v731 and 0.085 or 0.065, v730[2])
				}
				local v733 = Instance.new("Frame")
				v733.BorderSizePixel = 0
				for v734, v735 in v732 do
					v733[v734] = v735
				end
				v733.Parent = v725
				local v736 = Instance.new("UIStroke")
				v736.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
				local v737
				if v731 then
					v737 = v722
				else
					v737 = v721
				end
				v736.Color = v737
				v736.Transparency = v731 and 0.2 or 0.55
				v736.Thickness = 1
				v736.Parent = v733
				for v738 = 1, 7 do
					for v739 = 1, 2 do
						if (v729 * 5 + v738 * 3 + v739 * 7) % 4 ~= 0 then
							continue
						end
						local v740 = {
							["Name"] = "Window",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 3,
							["BackgroundColor3"] = v722,
							["BackgroundTransparency"] = v731 and 0.25 or 0.55,
							["Position"] = UDim2.fromScale((v739 - 1) * 0.46 + 0.16, (v738 - 1) * 0.125 + 0.06),
							["Size"] = UDim2.fromScale(0.28, 0.05)
						}
						local v741 = Instance.new("Frame")
						v741.BorderSizePixel = 0
						for v742, v743 in v740 do
							v741[v742] = v743
						end
						v741.Parent = v733
					end
				end
			end
		else
			local v744 = Instance.new("TextLabel")
			v744.Name = "Question"
			v744.BackgroundTransparency = 1
			v744.AnchorPoint = Vector2.new(0.5, 0.5)
			v744.Position = UDim2.fromScale(0.22, 0.52)
			v744.Size = UDim2.fromScale(0.3, 0.95)
			v744.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
			v744.TextScaled = true
			v744.Text = "?"
			v744.TextColor3 = v721
			v744.TextTransparency = 0.6
			v744.ZIndex = 2
			v744.Parent = v725
		end
		local v745 = Instance.new("TextLabel")
		v745.Name = "PlanTitle"
		v745.BackgroundTransparency = 1
		v745.Position = UDim2.fromOffset(10, 6)
		local v746
		if v_u_45 then
			local v747 = v_u_45.phoneText
			v746 = type(v747) ~= "function" and 12 or v_u_45.phoneText(12, "caption")
		else
			v746 = 12
		end
		v745.Size = UDim2.new(0.55, 0, 0, v746 + 2)
		v745.FontFace = v_u_45 and (v_u_45.font and v_u_45.font.heading) or Font.fromName("Oswald", Enum.FontWeight.Medium)
		v745.TextSize = v746
		v745.TextColor3 = v_u_46.text2 or Color3.fromHex("9AA3AE")
		v745.TextTransparency = 0.15
		v745.TextXAlignment = Enum.TextXAlignment.Left
		v745.TextTruncate = Enum.TextTruncate.AtEnd
		local v748
		if p718 == "skyline" then
			local v749 = string.upper
			local v750 = p717.name or ""
			v748 = v749((tostring(v750))) .. "  \194\183  PORT VESPER"
		else
			v748 = "LOCATION UNKNOWN"
		end
		v745.Text = v748
		v745.ZIndex = 6
		v745.Parent = v_u_56
	end
	local function v_u_759(p752) -- name: previewEntry
		-- upvalues: (copy) v_u_70
		if v_u_70 then
			local v753 = p752.id
			if type(v753) == "string" then
				local v754 = v_u_70
				local v755 = p752.id
				local v756, v757 = pcall(v754, v755)
				if v756 and (type(v757) == "table" and v757.fallback ~= true) then
					local v758 = v757.id
					if type(v758) == "string" and v757.id ~= "" then
						return v757
					end
				end
				return nil
			end
		end
		return nil
	end
	local function v_u_784(p_u_760) -- name: render
		-- upvalues: (copy) v_u_76, (ref) v_u_68, (copy) v_u_56, (ref) v_u_66, (ref) v_u_67, (copy) v_u_82, (copy) v_u_52, (copy) v_u_60, (copy) v_u_116, (copy) v_u_163, (copy) v_u_269, (copy) v_u_406, (ref) v_u_71, (copy) v_u_564, (copy) v_u_751, (copy) v_u_716, (copy) p_u_42, (copy) v_u_759, (copy) v_u_51, (ref) v_u_73
		v_u_76()
		v_u_68 = v_u_68 + 1
		local v_u_761 = v_u_68
		local v762 = p_u_760.image
		local v763
		if type(v762) == "string" and p_u_760.image ~= "" then
			v763 = p_u_760.image
		else
			v763 = nil
		end
		if v763 then
			local v764 = Instance.new("ImageLabel")
			v764.Name = "Image"
			v764.BackgroundTransparency = 1
			v764.Size = UDim2.fromScale(1, 1)
			v764.ScaleType = Enum.ScaleType.Crop
			v764.Image = v763
			v764.ZIndex = 1
			v764.Parent = v_u_56
			v_u_66 = v764
			v_u_67 = p_u_760
			v_u_82()
			v_u_52.kind = "image"
			v_u_60.BackgroundTransparency = 0.42
		elseif p_u_760.placeholder == "town" then
			v_u_116(p_u_760)
			v_u_52.kind = "town"
			v_u_60.BackgroundTransparency = 0.22
		elseif p_u_760.placeholder == "tunnels" then
			v_u_163(p_u_760)
			v_u_52.kind = "tunnels"
			v_u_60.BackgroundTransparency = 0.75
		elseif p_u_760.placeholder == "airfield" then
			v_u_269(p_u_760)
			v_u_52.kind = "airfield"
			v_u_60.BackgroundTransparency = 0.72
		elseif p_u_760.placeholder == "ridge" then
			v_u_406(p_u_760)
			v_u_52.kind = "ridge"
			v_u_60.BackgroundTransparency = 0.72
		elseif p_u_760.placeholder == "plaza" or p_u_760.placeholder == "skyline" and p_u_760.id == "overture" then
			v_u_71 = 0
			v_u_564(p_u_760)
			if v_u_71 > 0 then
				v_u_52.kind = "plaza"
				v_u_60.BackgroundTransparency = 0.72
			else
				v_u_751(p_u_760, "skyline")
				v_u_52.kind = "skyline"
				v_u_60.BackgroundTransparency = 0.8
			end
		elseif p_u_760.placeholder == "city" then
			v_u_71 = 0
			v_u_716(p_u_760)
			if v_u_71 > 0 then
				v_u_52.kind = "city"
				v_u_60.BackgroundTransparency = 0.72
			else
				v_u_52.kind = "plain"
				v_u_60.BackgroundTransparency = 1
			end
		elseif p_u_760.placeholder == "skyline" or p_u_760.placeholder == "unknown" then
			v_u_751(p_u_760, p_u_760.placeholder)
			v_u_52.kind = p_u_760.placeholder
			v_u_60.BackgroundTransparency = 0.8
		else
			v_u_52.kind = "plain"
			v_u_60.BackgroundTransparency = 1
		end
		local v765 = p_u_42
		local v766 = p_u_760.id
		v765:SetAttribute("MapPicture", tostring(v766) .. " " .. v_u_52.kind)
		local v_u_767
		if v763 then
			v_u_767 = nil
		else
			v_u_767 = v_u_759(p_u_760)
		end
		if v_u_767 then
			local v_u_768 = Instance.new("ImageLabel")
			v_u_768.Name = "Preview"
			v_u_768.BackgroundTransparency = 1
			v_u_768.Size = UDim2.fromScale(1, 1)
			v_u_768.ScaleType = Enum.ScaleType.Crop
			v_u_768.Image = v_u_767.id
			v_u_768.ImageTransparency = 1
			v_u_768.ZIndex = 4
			v_u_768.Parent = v_u_51
			local v_u_769 = v_u_52.kind
			local v_u_770 = v_u_60.BackgroundTransparency
			local function v_u_775() -- name: show
				-- upvalues: (ref) v_u_73, (copy) v_u_761, (ref) v_u_68, (copy) v_u_768, (ref) v_u_66, (ref) v_u_67, (copy) v_u_767, (ref) v_u_52, (ref) v_u_60, (ref) v_u_82, (ref) p_u_42, (copy) p_u_760
				if v_u_73 and (v_u_761 == v_u_68 and v_u_768.Parent) then
					v_u_768.ImageTransparency = 0
					v_u_66 = v_u_768
					v_u_67 = v_u_767
					v_u_52.kind = "image"
					v_u_52.preview = true
					local v771 = v_u_60
					local v772 = v_u_767.dim
					v771.BackgroundTransparency = type(v772) ~= "number" and 0.42 or v_u_767.dim
					v_u_82()
					local v773 = p_u_42
					local v774 = p_u_760.id
					v773:SetAttribute("MapPicture", tostring(v774) .. " render")
				end
			end
			local v_u_776 = false
			local function v778() -- name: fail
				-- upvalues: (ref) v_u_776, (ref) v_u_73, (copy) v_u_761, (ref) v_u_68, (copy) v_u_768, (ref) v_u_52, (copy) v_u_769, (ref) v_u_60, (copy) v_u_770
				if not v_u_776 and (v_u_73 and v_u_761 == v_u_68) then
					v_u_776 = true
					v_u_768:Destroy()
					local v777 = v_u_52
					v_u_52.kind = v_u_769
					v777.preview = false
					v_u_60.BackgroundTransparency = v_u_770
				end
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_768, (ref) v_u_776, (copy) v_u_775, (ref) v_u_73, (copy) v_u_761, (ref) v_u_68, (ref) v_u_52, (copy) v_u_769, (ref) v_u_60, (copy) v_u_770
				local function v782()
					-- upvalues: (ref) v_u_768, (ref) v_u_776, (ref) v_u_775, (ref) v_u_73, (ref) v_u_761, (ref) v_u_68, (ref) v_u_52, (ref) v_u_769, (ref) v_u_60, (ref) v_u_770
					local v779 = { v_u_768 }
					game:GetService("ContentProvider"):PreloadAsync(v779, function(_, p780)
						-- upvalues: (ref) v_u_776, (ref) v_u_775, (ref) v_u_73, (ref) v_u_761, (ref) v_u_68, (ref) v_u_768, (ref) v_u_52, (ref) v_u_769, (ref) v_u_60, (ref) v_u_770
						if v_u_776 then
							return
						elseif p780 == Enum.AssetFetchStatus.Success then
							v_u_776 = true
							v_u_775()
						elseif (p780 == Enum.AssetFetchStatus.Failure or p780 == Enum.AssetFetchStatus.TimedOut) and (not v_u_776 and v_u_73) then
							if v_u_761 ~= v_u_68 then
								return
							end
							v_u_776 = true
							v_u_768:Destroy()
							local v781 = v_u_52
							v_u_52.kind = v_u_769
							v781.preview = false
							v_u_60.BackgroundTransparency = v_u_770
						end
					end)
				end
				if not pcall(v782) and (not v_u_776 and v_u_73) then
					if v_u_761 ~= v_u_68 then
						return
					end
					v_u_776 = true
					v_u_768:Destroy()
					local v783 = v_u_52
					v_u_52.kind = v_u_769
					v783.preview = false
					v_u_60.BackgroundTransparency = v_u_770
				end
			end)
			task.delay(8, v778)
		end
	end
	function v_u_52.set(p785) -- name: set
		-- upvalues: (ref) v_u_73, (copy) v_u_759, (ref) v_u_64, (ref) v_u_65, (copy) v_u_784
		if v_u_73 and type(p785) == "table" then
			local v786
			if p785.image then
				v786 = nil
			else
				v786 = v_u_759(p785)
			end
			local v787 = p785.id
			local v788 = tostring(v787)
			local v789 = "|"
			local v790 = p785.image
			local v791 = tostring(v790)
			local v792 = "|"
			local v793
			if v786 then
				local v794 = v786.id
				v793 = tostring(v794)
			else
				v793 = "-"
			end
			local v795 = v788 .. v789 .. v791 .. v792 .. v793
			v_u_64 = p785
			if v795 ~= v_u_65 then
				v_u_65 = v795
				v_u_784(p785)
			end
		else
			return
		end
	end
	local v_u_796 = false
	local v797 = p_u_42:GetPropertyChangedSignal("AbsoluteSize")
	local function v802()
		-- upvalues: (ref) v_u_73, (ref) v_u_64, (ref) v_u_66, (copy) v_u_82, (copy) v_u_52, (ref) v_u_71, (copy) p_u_42, (copy) v_u_48, (ref) v_u_796, (ref) v_u_65
		if v_u_73 and v_u_64 then
			if v_u_66 then
				v_u_82()
			elseif v_u_52.kind == "town" or (v_u_52.kind == "airfield" or (v_u_52.kind == "ridge" or (v_u_52.kind == "plaza" or v_u_52.kind == "city"))) or (v_u_64.placeholder == "town" or (v_u_64.placeholder == "airfield" or (v_u_64.placeholder == "ridge" or (v_u_64.placeholder == "plaza" or v_u_64.placeholder == "city")))) and v_u_71 == 0 then
				local v798 = p_u_42.AbsoluteSize
				local v799
				if v798.X < 2 or v798.Y < 2 then
					v799 = nil
				else
					local v800 = v798.Y / v_u_48
					v799 = Vector2.new(v798.X / v800, v_u_48)
				end
				if v799 then
					local v801 = v799.X - v_u_71
					if math.abs(v801) > 2 and not v_u_796 then
						v_u_796 = true
						task.delay(0.15, function()
							-- upvalues: (ref) v_u_796, (ref) v_u_73, (ref) v_u_64, (ref) v_u_66, (ref) v_u_65, (ref) v_u_52
							v_u_796 = false
							if v_u_73 and (v_u_64 and not v_u_66) then
								v_u_65 = ""
								v_u_52.set(v_u_64)
							end
						end)
					end
				end
			end
		else
			return
		end
	end
	table.insert(v_u_72, v797:Connect(v802))
	function v_u_52.destroy() -- name: destroy
		-- upvalues: (ref) v_u_73, (copy) v_u_72, (copy) v_u_51
		v_u_73 = false
		for _, v803 in v_u_72 do
			v803:Disconnect()
		end
		v_u_51:Destroy()
	end
	return v_u_52
end
return v_u_1