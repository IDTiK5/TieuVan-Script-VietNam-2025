-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / CrateWindow

local v_u_1 = game:GetService("GuiService")
local v_u_2 = {}
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("CaseOdds"))
local v_u_5 = require(v3:WaitForChild("SkinRules"))
local v_u_6 = require(v3:WaitForChild("Skins"))
local v_u_7 = require(script.Parent:WaitForChild("MenuCrates"))
v_u_2.TEXT = {
	["openKey"] = "OPEN WITH KEY",
	["buyKey"] = "BUY KEY",
	["getCash"] = "GET CASH",
	["contents"] = "CONTENTS",
	["close"] = "Close",
	["market"] = "FIND ON THE MARKET",
	["loading"] = "Loading your case...",
	["missing"] = "This case is not available. Close the window and try again.",
	["error"] = "The case could not be loaded. Try again in a moment.",
	["keysFree"] = "Keys are free right now.",
	["keyUse"] = "Uses 1 %s. You have %d.",
	["keyUseShort"] = "You have %d.",
	["keyHeld"] = "Opens with %s. You have %d.",
	["noKey"] = "You have no %s.",
	["noKeyBuy"] = "No %s. Buy one below.",
	["needCase"] = "You need this case first.",
	["cashHave"] = "You have %s.",
	["cashShort"] = "Not enough cash. You need %s more.",
	["cashShortShort"] = "Need %s more.",
	["cashLine"] = "Your cash: %s",
	["noCashPath"] = "%s only. This case cannot be opened with cash.",
	["buySub"] = "%s from the store. You come back here after buying.",
	["buySubShort"] = "%s from the store.",
	["getCashSub"] = "Cash packs from the store. You come back here after buying.",
	["getCashSubShort"] = "Cash packs from the store.",
	["noCase"] = "You have no %s in your stash. Cases come from raids or the Market.",
	["bought"] = "Purchase complete. You now have %d %s.",
	["boughtCash"] = "Purchase complete. You now have %s cash.",
	["fine"] = "The chances are exact, see CONTENTS. Finishes are cosmetic and change no stats.",
	["backTo"] = "BACK TO %s",
	["backShort"] = "BACK TO CASE",
	["scanTitle"] = "SCAN INSTEAD",
	["scanBody"] = "Your account cannot open cases at random. Scan the case on the bench: you see the finish first and then buy exactly that finish.",
	["timeout"] = "No answer from the server. Try again in a moment."
}
v_u_2.KEY_PRODUCT = {
	["standard"] = "key_standard_1",
	["vault"] = "key_vault_1",
	["special"] = "key_special_1"
}
v_u_2.ALIAS = {
	["field"] = "skin_crate_field",
	["tacet"] = "skin_crate_tacet",
	["vault"] = "skin_crate_vault",
	["halloween"] = "skin_crate_halloween",
	["h2026"] = "skin_crate_halloween",
	["tokyo"] = "skin_crate_tokyo"
}
v_u_2.PENDING_SEC = 900
function v_u_2.resolve(p8) -- name: resolve
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	if type(p8) == "string" and p8 ~= "" then
		local v9 = v_u_2.ALIAS[string.lower(p8)] or p8
		if v_u_4.get(v9) == nil then
			return nil
		else
			return v9
		end
	else
		return nil
	end
end
function v_u_2.plural(p10, p11) -- name: plural
	local v12 = tostring(p10 or "KEY")
	local v13 = tonumber(p11)
	if ((not v13 or (v13 ~= v13 or (v13 < 0 or v13 == (1 / 0)))) and 0 or math.floor(v13)) == 1 then
		return v12
	else
		return v12 .. "S"
	end
end
function v_u_2.crateRow(p14, p15) -- name: crateRow
	if type(p14) == "table" then
		local v16 = p14.crates
		if type(v16) == "table" then
			for _, v17 in p14.crates do
				if type(v17) ~= "table" or v17.id ~= p15 then
					continue
				end
				return v17
			end
			return nil
		end
	end
	return nil
end
function v_u_2.pickCrate(p18) -- name: pickCrate
	if type(p18) == "table" then
		local v19 = p18.crates
		if type(v19) == "table" then
			for _, v20 in p18.crates do
				if type(v20) ~= "table" then
					continue
				end
				local v21 = v20.count
				local v22 = tonumber(v21)
				if ((not v22 or (v22 ~= v22 or (v22 < 0 or v22 == (1 / 0)))) and 0 or math.floor(v22)) <= 0 then
					continue
				end
				return v20.id
			end
			local v23 = p18.crates[1]
			if type(v23) == "table" then
				return v23.id
			else
				return nil
			end
		end
	end
	return nil
end
function v_u_2.stageAction(p24, p25, p26) -- name: stageAction
	return type(p26) == "string" and p26 ~= "" and (p24 and (p25 == p26 and "keep" or "rebuild") or "build") or "skip"
end
function v_u_2.shortfall(p27, p28) -- name: shortfall
	local v29 = tonumber(p28)
	local v30 = (not v29 or (v29 ~= v29 or (v29 < 0 or v29 == (1 / 0)))) and 0 or math.floor(v29)
	local v31 = tonumber(p27)
	local v32 = v30 - ((not v31 or (v31 ~= v31 or (v31 < 0 or v31 == (1 / 0)))) and 0 or math.floor(v31))
	return math.max(0, v32)
end
function v_u_2.backText(p33, p34) -- name: backText
	-- upvalues: (copy) v_u_2
	local v35 = v_u_2.TEXT
	local v36 = tostring(p33 or "")
	if p34 == true or (v36 == "" or #v36 > 16) then
		return v35.backShort
	else
		return string.format(v35.backTo, string.upper(v36))
	end
end
function v_u_2.layoutFor(p37, p38) -- name: layoutFor
	return (p38 == true or (tonumber(p37) or 1080) < 640) and "small" or "wide"
end
function v_u_2.layoutRows(p39, p40) -- name: layoutRows
	local v41 = {}
	local v42 = {}
	if type(p39) ~= "table" then
		return {
			["first"] = v41,
			["second"] = v42
		}
	end
	local v43
	if p40 == true and (p39.buy ~= nil and p39.buy.show == true) then
		local v44
		if p39.getCash == nil then
			v44 = false
		else
			v44 = p39.getCash.show == true
		end
		v43 = not v44
	else
		v43 = false
	end
	if p39.key and p39.key.show then
		table.insert(v41, "key")
	end
	if p39.cash and p39.cash.show then
		table.insert(v41, "cash")
	end
	if v43 then
		table.insert(v41, "buy")
	end
	if p39.buy and (p39.buy.show and not v43) then
		table.insert(v42, "buy")
	end
	if p39.getCash and p39.getCash.show then
		table.insert(v42, "getCash")
	end
	return {
		["first"] = v41,
		["second"] = v42
	}
end
function v_u_2.model(p45, p46, p47) -- name: model
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_5
	local v48 = v_u_2.TEXT
	local v49
	if type(p47) == "table" then
		v49 = p47.small == true
	else
		v49 = false
	end
	local v50
	if type(p47) == "table" then
		v50 = p47.cashPacks == false
	else
		v50 = false
	end
	local v51 = not v50
	local v52 = {
		["crateId"] = nil,
		["state"] = "loading",
		["notice"] = nil,
		["scan"] = false,
		["lines"] = nil,
		["key"] = nil,
		["cash"] = nil,
		["buy"] = nil,
		["getCash"] = nil,
		["market"] = nil,
		["crateId"] = p46,
		["lines"] = {},
		["key"] = {
			["show"] = false,
			["enabled"] = false
		},
		["cash"] = {
			["show"] = false,
			["enabled"] = false
		},
		["buy"] = {
			["show"] = false,
			["enabled"] = false
		},
		["getCash"] = {
			["show"] = false,
			["enabled"] = false
		},
		["market"] = {
			["show"] = false
		}
	}
	if type(p45) ~= "table" then
		return v52
	end
	local v53 = v_u_2.crateRow(p45, p46)
	if v53 == nil then
		v52.state = "missing"
		v52.notice = v48.missing
		return v52
	end
	v52.crate = v53
	local v54 = v53.name or "CASE"
	v52.name = tostring(v54)
	local v55 = v53.count
	local v56 = tonumber(v55)
	v52.count = (not v56 or (v56 ~= v56 or (v56 < 0 or v56 == (1 / 0)))) and 0 or math.floor(v56)
	local v57 = v53.held
	local v58 = tonumber(v57)
	v52.held = (not v58 or (v58 ~= v58 or (v58 < 0 or v58 == (1 / 0)))) and 0 or math.floor(v58)
	local v59 = v53.keys
	local v60 = tonumber(v59)
	v52.keys = (not v60 or (v60 ~= v60 or (v60 < 0 or v60 == (1 / 0)))) and 0 or math.floor(v60)
	local v61 = p45.cash
	local v62 = tonumber(v61)
	v52.cashHave = (not v62 or (v62 ~= v62 or (v62 < 0 or v62 == (1 / 0)))) and 0 or math.floor(v62)
	local v63 = v53.keyName or "KEY"
	v52.keyName = tostring(v63)
	v52.keyType = v53.key
	v52.free = p45.free == true
	v52.cashOpen = v53.cashOpen == true
	local v64 = v53.cashPrice
	local v65 = tonumber(v64)
	v52.price = (not v65 or (v65 ~= v65 or (v65 < 0 or v65 == (1 / 0)))) and 0 or math.floor(v65)
	v52.tally = p45.tally == true
	v52.lines.stash = v_u_7.stashLine(v53)
	local v66 = p45.scan
	local v67
	if type(v66) == "table" then
		v67 = p45.scan.visible == true
	else
		v67 = false
	end
	if p45.enabled ~= true then
		v52.state = "disabled"
		v52.notice = v_u_7.TEXT.disabled
		return v52
	end
	if p45.resolved == false then
		v52.state = "pending"
		local v68 = p45.pendingText
		local v69
		if type(v68) == "string" and p45.pendingText ~= "" then
			v69 = p45.pendingText
		else
			v69 = v_u_7.TEXT.pending
		end
		v52.notice = v69
		return v52
	end
	if p45.restricted == true then
		if v67 then
			v52.state = "scan"
			v52.scan = true
			return v52
		end
		v52.state = "restricted"
		local v70 = p45.restrictedText
		local v71
		if type(v70) == "string" and p45.restrictedText ~= "" then
			v71 = p45.restrictedText
		else
			v71 = v_u_7.TEXT.restricted
		end
		v52.notice = v71
	elseif v52.count < 1 then
		v52.state = "nocase"
		v52.notice = string.format(v48.noCase, v52.name)
	else
		v52.state = "ready"
	end
	local v72 = v52.state == "restricted"
	local v73 = v52.count < 1
	if not v72 then
		local v74 = v52.lines
		local v75
		if v52.free then
			v75 = v48.keysFree
		else
			v75 = string.format(v48.keyHeld, v52.keyName, v52.keys)
		end
		v74.key = v75
	end
	if v52.cashOpen then
		v52.lines.cash = string.format(v48.cashLine, v_u_7.money(v52.cashHave))
	end
	local v76 = v_u_2.KEY_PRODUCT[v53.key]
	local v77 = v_u_7.showGetKeys(p45) and not v52.free
	if v77 then
		v77 = v76 ~= nil
	end
	if not v72 then
		local v78 = v53.canOpen == true
		local v79
		if v78 then
			if v52.free then
				v79 = v48.keysFree
			elseif v49 then
				v79 = string.format(v48.keyUseShort, v52.keys)
			else
				v79 = string.format(v48.keyUse, v52.keyName, v52.keys)
			end
		elseif v73 then
			v79 = v48.needCase
		elseif v52.keys < 1 then
			local v80 = string.format
			local v81
			if v77 then
				v81 = v48.noKeyBuy
			else
				v81 = v48.noKey
			end
			v79 = v80(v81, v52.keyName)
		else
			local v82 = v53.why
			if type(v82) == "string" and v53.why ~= "" then
				v79 = v53.why
			else
				v79 = v_u_5.TEXT.notNow
			end
		end
		local v83 = {
			["show"] = true,
			["enabled"] = nil,
			["text"] = nil,
			["sub"] = nil,
			["variant"] = nil,
			["why"] = nil,
			["enabled"] = v78,
			["text"] = v48.openKey,
			["sub"] = v79,
			["variant"] = v78 and "primary" or "off"
		}
		if v78 then
			v79 = nil
		end
		v83.why = v79
		v52.key = v83
	end
	if v52.cashOpen then
		local v84 = v53.canCash == true
		local v85 = not v73
		if v85 then
			if v52.price > 0 then
				v85 = v52.cashHave < v52.price
			else
				v85 = false
			end
		end
		local v86
		if v85 then
			local v87 = string.format
			local v88
			if v49 then
				v88 = v48.cashShortShort
			else
				v88 = v48.cashShort
			end
			v86 = v87(v88, v_u_7.money(v_u_2.shortfall(v52.cashHave, v52.price)))
		elseif v84 then
			v86 = string.format(v48.cashHave, v_u_7.money(v52.cashHave))
		elseif v73 then
			v86 = v48.needCase
		else
			local v89 = v53.whyCash
			if type(v89) == "string" and v53.whyCash ~= "" then
				v86 = v53.whyCash
			else
				v86 = v_u_5.TEXT.notNow
			end
		end
		local v90 = {
			["show"] = true,
			["enabled"] = nil,
			["text"] = nil,
			["sub"] = nil,
			["short"] = nil,
			["variant"] = nil,
			["why"] = nil,
			["enabled"] = v84,
			["text"] = v_u_7.cashButtonText(v53),
			["sub"] = v86,
			["short"] = v85,
			["variant"] = v84 and "secondary" or (v85 and "short" or "off")
		}
		if v84 then
			v86 = nil
		end
		v90.why = v86
		v52.cash = v90
	elseif not v72 then
		v52.cashNote = string.format(v48.noCashPath, v52.keyName)
	end
	if v52.cashOpen and (v52.cash.short == true and (v51 and (v_u_7.showGetKeys(p45) and not v72))) then
		local v91 = {
			["show"] = true,
			["enabled"] = true,
			["text"] = nil,
			["sub"] = nil,
			["loud"] = true,
			["variant"] = "buy",
			["need"] = nil,
			["text"] = v48.getCash
		}
		local v92
		if v49 then
			v92 = v48.getCashSubShort
		else
			v92 = v48.getCashSub
		end
		v91.sub = v92
		v91.need = v_u_2.shortfall(v52.cashHave, v52.price)
		v52.getCash = v91
	end
	if v77 and not v72 then
		local v93 = v52.keys < 1
		local v94 = {
			["show"] = true,
			["enabled"] = true,
			["text"] = nil,
			["sub"] = nil,
			["product"] = nil,
			["loud"] = nil,
			["variant"] = nil,
			["text"] = v48.buyKey
		}
		local v95 = string.format
		local v96
		if v49 then
			v96 = v48.buySubShort
		else
			v96 = v48.buySub
		end
		v94.sub = v95(v96, v52.keyName)
		v94.product = v76
		v94.loud = v93
		v94.variant = v93 and "buy" or "buySoft"
		v52.buy = v94
	end
	local v97 = {}
	if v73 then
		v73 = p45.restricted ~= true
	end
	v97.show = v73
	v97.text = v48.market
	v52.market = v97
	return v52
end
local v_u_98 = false
local v_u_99 = nil
local v_u_100 = false
local v_u_101 = {}
local v_u_102 = nil
local v_u_103 = nil
function v_u_2.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_99
	return v_u_99 ~= nil
end
function v_u_2.current() -- name: current
	-- upvalues: (ref) v_u_99
	return v_u_99
end
function v_u_2.opening() -- name: opening
	-- upvalues: (ref) v_u_100
	return v_u_100
end
function v_u_2.close(p104) -- name: close
	-- upvalues: (ref) v_u_99
	local v105 = v_u_99
	if v105 then
		v_u_99 = nil
		local v106 = v105.destroy
		pcall(v106, p104)
	end
end
local function v_u_113(p107, p108, p109, p110) -- name: sendOpen
	-- upvalues: (copy) v_u_101, (copy) v_u_2
	local v_u_111 = p107.op({
		["op"] = "crateOpen",
		["crate"] = nil,
		["pay"] = nil,
		["crate"] = p108,
		["pay"] = p110 == "cash" and "cash" or nil
	})
	v_u_101[v_u_111] = p109
	task.delay(20, function()
		-- upvalues: (ref) v_u_101, (copy) v_u_111, (ref) v_u_2
		local v112 = v_u_101[v_u_111]
		if v112 then
			v_u_101[v_u_111] = nil
			v112(nil, v_u_2.TEXT.timeout)
		end
	end)
end
function v_u_2.startOpening(p_u_114, p115, p116, p_u_117) -- name: startOpening
	-- upvalues: (ref) v_u_100, (copy) v_u_5, (copy) v_u_113, (copy) v_u_6
	if v_u_100 then
		return false
	end
	local v_u_118 = p_u_114.cctx
	local v119 = p_u_117 == "cash"
	if v119 then
		if p116.canCash ~= true then
			local v120 = p116.whyCash or v_u_5.TEXT.notNow
			local v121 = p_u_114.ui.toast
			pcall(v121, v120, "warn")
			return false
		end
	elseif not p116.canOpen then
		local v122 = p116.why or v_u_5.TEXT.notNow
		local v123 = p_u_114.ui.toast
		pcall(v123, v122, "warn")
		return false
	end
	v_u_100 = true
	local v124, v125 = pcall(function()
		-- upvalues: (copy) v_u_118
		return v_u_118.lib.CrateStage
	end)
	if not v124 then
		v125 = nil
	end
	local v_u_126 = nil
	if v125 then
		local v127 = v125.begin
		local v128 = p116.id
		local v129 = {
			["alive"] = function() -- name: alive
				-- upvalues: (ref) v_u_100, (ref) v_u_126
				return v_u_100 or v_u_126 ~= nil
			end
		}
		local v130 = not v119
		if v130 then
			if type(p115) == "table" then
				v130 = p115.free == true
			else
				v130 = false
			end
		end
		v129.keysFree = v130
		function v129.requestNext(p131, p132) -- name: requestNext
			-- upvalues: (ref) v_u_113, (copy) p_u_114, (copy) p_u_117
			v_u_113(p_u_114, p131, p132, p_u_117)
		end
		function v129.onEquip(p133, p134, p135) -- name: onEquip
			-- upvalues: (copy) p_u_114
			local v136 = p_u_114.op
			local v137 = {
				["op"] = "skinEquip",
				["weapon"] = nil,
				["skin"] = nil,
				["uid"] = nil,
				["weapon"] = p133,
				["skin"] = p134
			}
			if type(p135) ~= "string" or #p135 > 40 then
				p135 = nil
			end
			v137.uid = p135
			v136(v137)
			return true
		end
		function v129.onDone() -- name: onDone
			-- upvalues: (copy) p_u_114, (ref) v_u_100
			local v138 = p_u_114
			v_u_100 = false
			v138.invalidate("crates")
		end
		local v139, v140 = pcall(v127, v128, v129)
		if v139 then
			v_u_126 = v140
		else
			warn("[CrateWindow] the opening scene did not start: " .. tostring(v140))
		end
	end
	v_u_113(p_u_114, p116.id, function(p141, p142)
		-- upvalues: (ref) v_u_126, (ref) v_u_5, (ref) v_u_6, (copy) p_u_114, (ref) v_u_100
		if v_u_126 then
			if p141 then
				v_u_126:resolve(p141)
			else
				v_u_126:fail(p142 or v_u_5.TEXT.notNow)
			end
		else
			local v143
			if p141 then
				v143 = v_u_6.get(p141.skin)
			else
				v143 = nil
			end
			if p141 and v143 then
				local v144 = v_u_6.RARITY_NAMES[v143.rarity] or ""
				local v145
				if p141.kept then
					local v146 = v_u_6.displayName(v143)
					local v147 = p141.total
					v145 = ("Duplicate kept: %s  you now own x%d"):format(v146, tonumber(v147) or 2)
				elseif p141.dup then
					v145 = ("Duplicate: %s"):format(v_u_6.displayName(v143))
				else
					v145 = ("New skin: %s  (%s)"):format(v_u_6.displayName(v143), v144)
				end
				if p141.tally == true then
					v145 = v145 .. "  TALLY"
				end
				local v148 = p_u_114.ui.toast
				pcall(v148, v145, "success")
			elseif p142 then
				local v149 = p_u_114.ui.toast
				pcall(v149, p142, "warn")
			end
			local v150 = p_u_114
			v_u_100 = false
			v150.invalidate("crates")
			return
		end
	end, p_u_117)
	return true
end
function v_u_2.startTrip(p151, p152, p153, p154, p155) -- name: startTrip
	-- upvalues: (ref) v_u_102
	local v156 = {
		["crate"] = nil,
		["key"] = nil,
		["product"] = nil,
		["keysBefore"] = nil,
		["at"] = nil,
		["tab"] = nil,
		["kind"] = "key",
		["crate"] = p151,
		["key"] = p152,
		["product"] = p153
	}
	local v157 = tonumber(p154)
	v156.keysBefore = (not v157 or (v157 ~= v157 or (v157 < 0 or v157 == (1 / 0)))) and 0 or math.floor(v157)
	v156.at = os.clock()
	v156.tab = p155
	v_u_102 = v156
	return v_u_102
end
function v_u_2.startCashTrip(p158, p159, p160) -- name: startCashTrip
	-- upvalues: (ref) v_u_102
	local v161 = {
		["crate"] = nil,
		["key"] = nil,
		["product"] = "CASH",
		["keysBefore"] = 0,
		["cashBefore"] = nil,
		["at"] = nil,
		["tab"] = nil,
		["kind"] = "cash",
		["crate"] = p158
	}
	local v162 = tonumber(p159)
	v161.cashBefore = (not v162 or (v162 ~= v162 or (v162 < 0 or v162 == (1 / 0)))) and 0 or math.floor(v162)
	v161.at = os.clock()
	v161.tab = p160
	v_u_102 = v161
	return v_u_102
end
function v_u_2.clearTrip() -- name: clearTrip
	-- upvalues: (ref) v_u_102
	v_u_102 = nil
end
function v_u_2.pending() -- name: pending
	-- upvalues: (ref) v_u_102, (copy) v_u_2, (copy) v_u_4
	local v163 = v_u_102
	if v163 == nil then
		return nil
	elseif os.clock() - v163.at > v_u_2.PENDING_SEC then
		v_u_102 = nil
		return nil
	else
		local v164 = v_u_4.get(v163.crate)
		return {
			["crate"] = v163.crate,
			["name"] = not v164 and "CASE" or v164.name,
			["product"] = v163.product,
			["key"] = v163.key,
			["kind"] = v163.kind or "key"
		}
	end
end
function v_u_2.back(p165) -- name: back
	-- upvalues: (ref) v_u_102, (ref) v_u_103, (copy) v_u_2
	local v166 = v_u_102
	local v_u_167 = v_u_103
	if v166 == nil or v_u_167 == nil then
		return false
	end
	v_u_102 = nil
	local v_u_168 = nil
	local function v169()
		-- upvalues: (ref) v_u_168, (copy) v_u_167
		v_u_168 = v_u_167.cctx.controllers.Menu
	end
	pcall(v169)
	if v_u_168 then
		local v170 = v_u_168.isOpen
		if type(v170) == "function" and not v_u_168.isOpen() then
			return false
		end
	end
	if v166.tab and v_u_168 then
		local v171 = v_u_168.tab
		if type(v171) == "function" and v_u_168.tab() ~= v166.tab then
			local v172 = v_u_168.setTab
			if type(v172) == "function" then
				local v173 = v_u_168.setTab
				local v174 = v166.tab
				pcall(v173, v174)
			end
		end
	end
	return v_u_2.open(v_u_167, v166.crate, {
		["banner"] = p165,
		["fromTab"] = v166.tab
	})
end
local function v_u_189(p_u_175, p176) -- name: onGrant
	-- upvalues: (ref) v_u_102, (copy) v_u_2, (copy) v_u_7
	local v_u_177 = v_u_102
	if v_u_177 == nil or (type(p176) ~= "table" or p176.ok ~= true) then
		return
	elseif os.clock() - v_u_177.at > v_u_2.PENDING_SEC then
		v_u_102 = nil
	else
		task.spawn(function()
			-- upvalues: (copy) p_u_175, (ref) v_u_2, (copy) v_u_177, (ref) v_u_102, (ref) v_u_7
			p_u_175.invalidate("crates")
			local v178 = p_u_175.fetch("crates", nil, 0)
			local v179 = v_u_2.crateRow(v178, v_u_177.crate)
			if v_u_102 == v_u_177 and v179 ~= nil then
				if v_u_177.kind == "cash" then
					local v180 = v178.cash
					local v181 = tonumber(v180)
					local v182 = (not v181 or (v181 ~= v181 or (v181 < 0 or v181 == (1 / 0)))) and 0 or math.floor(v181)
					local v183 = v_u_177.cashBefore
					local v184 = tonumber(v183)
					if ((not v184 or (v184 ~= v184 or (v184 < 0 or v184 == (1 / 0)))) and 0 or math.floor(v184)) < v182 then
						v_u_2.back(string.format(v_u_2.TEXT.boughtCash, v_u_7.money(v182)))
					end
				else
					local v185 = v179.keys
					local v186 = tonumber(v185)
					local v187 = (not v186 or (v186 ~= v186 or (v186 < 0 or v186 == (1 / 0)))) and 0 or math.floor(v186)
					if v_u_177.keysBefore < v187 then
						local v188 = string.format(v_u_2.TEXT.bought, v187, v_u_2.plural(v179.keyName, v187))
						v_u_2.back(v188)
					end
				end
			else
				return
			end
		end)
	end
end
local function v_u_192(p190, p191) -- name: variantOf
	return p191 == "primary" and {
		["bg"] = p190.accent,
		["hover"] = p190.accent:Lerp(p190.white, 0.14),
		["text"] = p190.ink,
		["sub"] = p190.ink,
		["stroke"] = p190.accentDim
	} or (p191 == "buy" and {
		["bg"] = p190.accent,
		["hover"] = p190.accent:Lerp(p190.white, 0.14),
		["text"] = p190.ink,
		["sub"] = p190.ink,
		["stroke"] = p190.white
	} or (p191 == "buySoft" and {
		["bg"] = p190.accentDeep,
		["hover"] = p190.accentDeep:Lerp(p190.accent, 0.25),
		["text"] = p190.accent,
		["sub"] = p190.text2,
		["stroke"] = p190.accent
	} or (p191 == "secondary" and {
		["bg"] = p190.raised,
		["hover"] = p190.raised2,
		["text"] = p190.text,
		["sub"] = p190.text2,
		["stroke"] = p190.accent
	} or (p191 == "short" and {
		["bg"] = p190.dangerDeep,
		["hover"] = p190.dangerDeep,
		["text"] = p190.danger,
		["sub"] = p190.danger,
		["stroke"] = p190.danger
	} or {
		["bg"] = p190.raised,
		["hover"] = p190.raised,
		["text"] = p190.muted,
		["sub"] = p190.muted,
		["stroke"] = p190.line
	}))))
end
local function v_u_227(p193, p194, p195, p_u_196, p197, p198, p_u_199) -- name: bigButton
	-- upvalues: (copy) v_u_192
	local v_u_200 = p193.ui
	local v_u_201 = p193.theme
	local v_u_202 = v_u_192(v_u_201.color, p_u_196.variant)
	local v_u_203 = v_u_200.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Selectable"] = true,
		["Name"] = p195,
		["BackgroundColor3"] = v_u_202.bg,
		["Size"] = p197,
		["LayoutOrder"] = p198
	}, p194)
	v_u_203.SelectionImageObject = v_u_200.selectionImage()
	v_u_203:SetAttribute("Disabled", p_u_196.enabled ~= true)
	v_u_203:SetAttribute("Variant", p_u_196.variant)
	local v_u_204 = v_u_200.stroke(v_u_203, v_u_202.stroke, (p_u_196.variant == "buy" or p_u_196.variant == "primary") and 2 or 1)
	local v205 = p197.Y.Offset
	local v206 = v205 * 0.46
	local v207 = math.floor(v206)
	local v208 = v_u_200.label
	local v209 = {
		["parent"] = nil,
		["name"] = "Main",
		["text"] = nil,
		["style"] = "h2",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_203,
		["text"] = p_u_196.text,
		["color"] = v_u_202.text
	}
	local v210 = UDim2.fromOffset
	local v211 = v205 * 0.12
	v209.position = v210(8, (math.floor(v211)))
	v209.size = UDim2.new(1, -16, 0, v207)
	v208(v209)
	local v212 = v_u_200.label
	local v213 = {
		["parent"] = nil,
		["name"] = "Sub",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_203,
		["text"] = p_u_196.sub or "",
		["color"] = v_u_202.sub
	}
	local v214 = UDim2.fromOffset
	local v215 = v205 * 0.12
	v213.position = v214(8, math.floor(v215) + v207 + 2)
	local v216 = UDim2.new
	local v217 = v205 * 0.26
	v213.size = v216(1, -16, 0, (math.floor(v217)))
	v212(v213)
	local v_u_218 = false
	v_u_203.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_218, (copy) v_u_203, (copy) p_u_196, (copy) v_u_202, (copy) v_u_204
		v_u_218 = true
		local v219 = v_u_203
		local v220
		if v_u_218 and p_u_196.enabled == true then
			v220 = v_u_202.hover
		else
			v220 = v_u_202.bg
		end
		v219.BackgroundColor3 = v220
		v_u_204.Transparency = 0
	end)
	v_u_203.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_218, (copy) v_u_203, (copy) p_u_196, (copy) v_u_202, (copy) v_u_204
		v_u_218 = false
		local v221 = v_u_203
		local v222
		if v_u_218 and p_u_196.enabled == true then
			v222 = v_u_202.hover
		else
			v222 = v_u_202.bg
		end
		v221.BackgroundColor3 = v222
		v_u_204.Transparency = 0
	end)
	v_u_203.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_218, (copy) v_u_203, (copy) p_u_196, (copy) v_u_202, (copy) v_u_204
		v_u_218 = true
		local v223 = v_u_203
		local v224
		if v_u_218 and p_u_196.enabled == true then
			v224 = v_u_202.hover
		else
			v224 = v_u_202.bg
		end
		v223.BackgroundColor3 = v224
		v_u_204.Transparency = 0
	end)
	v_u_203.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_218, (copy) v_u_203, (copy) p_u_196, (copy) v_u_202, (copy) v_u_204
		v_u_218 = false
		local v225 = v_u_203
		local v226
		if v_u_218 and p_u_196.enabled == true then
			v226 = v_u_202.hover
		else
			v226 = v_u_202.bg
		end
		v225.BackgroundColor3 = v226
		v_u_204.Transparency = 0
	end)
	v_u_203.Activated:Connect(function()
		-- upvalues: (copy) p_u_196, (copy) v_u_200, (copy) v_u_201, (copy) p_u_199
		if p_u_196.enabled == true then
			v_u_200.sound(v_u_201.sounds.confirm)
		else
			v_u_200.sound(v_u_201.sounds.error)
		end
		task.spawn(p_u_199)
	end)
	return v_u_203
end
function v_u_2.open(p_u_228, p229, p230) -- name: open
	-- upvalues: (ref) v_u_103, (ref) v_u_100, (copy) v_u_2, (ref) v_u_99, (ref) v_u_102, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_227, (copy) v_u_1
	v_u_103 = p_u_228
	if v_u_100 then
		return false
	end
	local v_u_231 = p_u_228.cctx
	local v_u_232 = true
	local function v233()
		-- upvalues: (ref) v_u_232, (copy) v_u_231
		v_u_232 = v_u_231.config.flag("CrateWindow") ~= false
	end
	pcall(v233)
	if not v_u_232 then
		return false
	end
	local v234, v235 = pcall(function()
		-- upvalues: (copy) v_u_231
		return v_u_231.lib.CrateStage
	end)
	if v234 and (v235 and (v235.active and v235.active())) then
		return false
	end
	local v236 = p230 or {}
	local v_u_237
	if p229 == nil then
		v_u_237 = nil
	else
		v_u_237 = v_u_2.resolve(p229)
	end
	if p229 ~= nil and v_u_237 == nil then
		return false
	end
	if v_u_99 then
		v_u_2.close("reopen")
	end
	local v_u_238 = p_u_228.ui
	local v_u_239 = p_u_228.theme
	local v_u_240 = v_u_239.color
	local v_u_241 = {
		["alive"] = true
	}
	local v_u_242 = nil
	local v_u_243 = nil
	local v_u_244 = 0
	local v_u_245 = nil
	local v_u_246 = nil
	local v_u_247 = nil
	local v_u_248 = nil
	local v_u_249 = nil
	local v_u_250 = nil
	local v_u_251 = nil
	local v_u_252 = nil
	local v_u_253 = nil
	local v_u_254 = nil
	local v_u_255 = v_u_2.layoutFor(v_u_239.refSize().Y, v_u_239.isPhone())
	local v_u_256 = v_u_255 == "small"
	local v_u_257 = v236.fromTab
	if v_u_257 == nil then
		pcall(function()
			-- upvalues: (ref) v_u_257, (copy) v_u_231
			v_u_257 = v_u_231.controllers.Menu.tab()
		end)
	end
	local v_u_258 = v236.banner
	local v_u_259 = {}
	if v_u_237 then
		v_u_102 = nil
	end
	local v_u_260
	if v_u_237 then
		local v261 = v_u_4.get(v_u_237)
		v_u_260 = not v261 and "CASE" or v261.name
	else
		v_u_260 = "CASE"
	end
	local function v_u_264(p262) -- name: clear
		if p262 ~= nil then
			for _, v263 in p262:GetChildren() do
				if v263:IsA("UIListLayout") or v263:IsA("UIPadding") then
					continue
				end
				v263:Destroy()
			end
		end
	end
	local function v_u_273() -- name: openOdds
		-- upvalues: (copy) v_u_231, (ref) v_u_237, (copy) p_u_228, (ref) v_u_260, (ref) v_u_7, (ref) v_u_242
		local function v265()
			-- upvalues: (ref) v_u_231
			return v_u_231.lib.MenuCratesOdds
		end
		local v266, v267 = pcall(v265)
		if v266 and (v267 and v_u_237) then
			local v268 = v267.open
			local v269 = p_u_228
			local v270 = { v_u_237 }
			local v271 = {
				["title"] = v_u_260 .. " " .. v_u_7.TEXT.odds
			}
			local v272
			if v_u_242 == nil then
				v272 = nil
			else
				v272 = v_u_242.tally == true
			end
			v271.tally = v272
			pcall(v268, v269, v270, v271)
		end
	end
	function v_u_241.refetch(p_u_274) -- name: refetch
		-- upvalues: (ref) v_u_244, (copy) p_u_228, (copy) v_u_241, (ref) v_u_242
		v_u_244 = v_u_244 + 1
		local v_u_275 = v_u_244
		task.spawn(function()
			-- upvalues: (ref) p_u_228, (copy) p_u_274, (copy) v_u_275, (ref) v_u_244, (ref) v_u_241, (ref) v_u_242
			local v276 = p_u_228.fetch("crates", nil, p_u_274 or 0)
			if v_u_275 == v_u_244 and v_u_241.alive then
				if type(v276) == "table" then
					v_u_242 = v276
				end
				local v277 = v_u_241.draw
				local v278
				if type(v276) == "table" then
					v278 = false
				else
					v278 = v_u_242 == nil
				end
				v277(v278)
			end
		end)
	end
	local function v_u_289() -- name: askCash
		-- upvalues: (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_100, (copy) p_u_228, (ref) v_u_5, (copy) v_u_238, (ref) v_u_7
		local v279 = v_u_2.crateRow(v_u_242, v_u_237)
		if v279 == nil or v_u_100 then
			return
		elseif v279.canCash == true then
			local v280 = v_u_238.modal
			local v281 = {
				["title"] = nil,
				["body"] = nil,
				["width"] = 520,
				["buttons"] = nil,
				["title"] = v_u_7.TEXT.cashTitle
			}
			local v282 = v_u_7.cashConfirmText
			local v283 = v_u_242
			if v283 then
				v283 = v_u_242.cash
			end
			v281.body = v282(v279, v283)
			v281.buttons = {
				{
					["text"] = v_u_7.TEXT.cancel
				},
				{
					["text"] = nil,
					["kind"] = "primary",
					["onClick"] = nil,
					["text"] = ("PAY %s"):format(v_u_7.money(v279.cashPrice)),
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_100, (ref) p_u_228
						local v284 = v_u_2.crateRow(v_u_242, v_u_237)
						if v284 ~= nil then
							if v_u_100 then
								return
							end
							local v285 = v_u_242
							v_u_2.close("opening")
							v_u_2.startOpening(p_u_228, v285, v284, "cash")
						end
					end
				}
			}
			v280(v281)
		else
			local v286 = p_u_228
			local v287 = v279.whyCash or v_u_5.TEXT.notNow
			local v288 = v286.ui.toast
			pcall(v288, v287, "warn")
		end
	end
	local function v_u_294() -- name: goBuy
		-- upvalues: (ref) v_u_243, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_257, (copy) p_u_228
		local v_u_290 = v_u_243
		local v291 = v_u_2.crateRow(v_u_242, v_u_237)
		if v_u_290 ~= nil and (v291 ~= nil and v_u_290.buy.show) then
			v_u_2.startTrip(v_u_237, v_u_290.keyType, v_u_290.buy.product, v_u_290.keys, v_u_257)
			v_u_2.close("store")
			local function v292()
				-- upvalues: (ref) p_u_228, (copy) v_u_290
				p_u_228.openStore(v_u_290.buy.product)
			end
			if not pcall(v292) then
				v_u_2.clearTrip()
				local v293 = p_u_228.ui.toast
				pcall(v293, "The store is not available right now.", "warn")
			end
		end
	end
	local function v_u_299() -- name: goGetCash
		-- upvalues: (ref) v_u_243, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_257, (copy) p_u_228
		local v295 = v_u_243
		local v296 = v_u_2.crateRow(v_u_242, v_u_237)
		if v295 ~= nil and (v296 ~= nil and v295.getCash.show) then
			v_u_2.startCashTrip(v_u_237, v295.cashHave, v_u_257)
			v_u_2.close("store")
			local function v297()
				-- upvalues: (ref) p_u_228
				p_u_228.openStore("CASH")
			end
			if not pcall(v297) then
				v_u_2.clearTrip()
				local v298 = p_u_228.ui.toast
				pcall(v298, "The store is not available right now.", "warn")
			end
		end
	end
	local function v_u_301() -- name: goMarket
		-- upvalues: (ref) v_u_2, (ref) v_u_7, (copy) p_u_228, (copy) v_u_231
		v_u_2.close("market")
		if not v_u_7.openMarket(p_u_228, v_u_231) then
			local v300 = p_u_228.ui.toast
			pcall(v300, "The Market is not available right now.", "warn")
		end
	end
	local function v_u_335() -- name: drawHead
		-- upvalues: (ref) v_u_247, (ref) v_u_243, (copy) v_u_256, (ref) v_u_2, (ref) v_u_253, (ref) v_u_254, (ref) v_u_237, (ref) v_u_252, (copy) v_u_231, (copy) v_u_239, (copy) v_u_238, (copy) v_u_240, (copy) v_u_273, (copy) v_u_259
		local v302 = v_u_247:FindFirstChild("Info")
		if v302 then
			v302:Destroy()
		end
		local v303 = v_u_243
		local v304 = v_u_256 and 104 or 168
		local v305 = v_u_256 and 150 or 252
		local v306 = v_u_2.stageAction
		local v307
		if v_u_253 == nil then
			v307 = false
		else
			v307 = v_u_253.Parent ~= nil
		end
		local v308 = v306(v307, v_u_254, v_u_237)
		if v_u_253 ~= nil and (v308 == "rebuild" or (v308 == "build" or v308 == "skip")) then
			if v_u_252 then
				local function v309()
					-- upvalues: (ref) v_u_231, (ref) v_u_252
					v_u_231.lib.ItemIcons.spin(v_u_252, false)
					v_u_231.lib.ItemIcons.release(v_u_252)
				end
				pcall(v309)
				v_u_252 = nil
			end
			local function v310()
				-- upvalues: (ref) v_u_253
				v_u_253:Destroy()
			end
			pcall(v310)
			v_u_253 = nil
			v_u_254 = nil
		end
		if v308 == "build" or v308 == "rebuild" then
			if v_u_252 then
				local function v311()
					-- upvalues: (ref) v_u_231, (ref) v_u_252
					v_u_231.lib.ItemIcons.spin(v_u_252, false)
					v_u_231.lib.ItemIcons.release(v_u_252)
				end
				pcall(v311)
				v_u_252 = nil
			end
			v_u_254 = v_u_237
			local v_u_312 = nil
			local function v313()
				-- upvalues: (ref) v_u_312, (ref) v_u_231, (ref) v_u_237
				v_u_312 = v_u_231.shared.Items.get(v_u_237)
			end
			pcall(v313)
			local v314 = v_u_239.rarityColor(not (v_u_312 and v_u_312.rarity) and 3 or v_u_312.rarity)
			v_u_253 = v_u_238.new("Frame", {
				["Name"] = "Stage",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_240.bgDeep,
				["Position"] = UDim2.fromOffset(0, 0),
				["Size"] = UDim2.fromOffset(v305, v304)
			}, v_u_247)
			v_u_238.stroke(v_u_253, v_u_240.line)
			v_u_238.new("UIGradient", {
				["Color"] = nil,
				["Rotation"] = 90,
				["Color"] = ColorSequence.new(v_u_240.bgDeep:Lerp(v314, 0.22), v_u_240.bgDeep)
			}, v_u_253)
			local function v315()
				-- upvalues: (ref) v_u_231, (ref) v_u_237, (ref) v_u_253
				return v_u_231.lib.ItemIcons.get(v_u_237, false, {
					["parent"] = nil,
					["size"] = nil,
					["position"] = nil,
					["zindex"] = 3,
					["name"] = "Crate3D",
					["parent"] = v_u_253,
					["size"] = UDim2.new(1, -16, 1, -16),
					["position"] = UDim2.fromOffset(8, 8)
				})
			end
			local v316, v_u_317 = pcall(v315)
			if v316 and v_u_317 then
				v_u_252 = v_u_317
				local function v318()
					-- upvalues: (ref) v_u_231, (copy) v_u_317
					v_u_231.lib.ItemIcons.spin(v_u_317, true)
				end
				pcall(v318)
			end
		end
		local v319 = v_u_238.new("Frame", {
			["Name"] = "Info",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(v305 + 16, 0),
			["Size"] = UDim2.new(1, -(v305 + 16), 0, v304)
		}, v_u_247)
		v_u_238.layout(v319, "v", v_u_256 and 3 or 6)
		local v320 = 0
		if v303 == nil or v303.crate == nil then
			local v321 = v_u_238.label
			local v322 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["order"] = nil,
				["size"] = nil,
				["parent"] = v319,
				["text"] = v_u_2.TEXT.loading,
				["color"] = v_u_240.text2
			}
			v320 = v320 + 1
			v322.order = v320
			v322.size = UDim2.new(1, 0, 0, 24)
			v321(v322)
		else
			local v323 = v_u_238.label
			local v324 = {
				["parent"] = nil,
				["name"] = "Stash",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["order"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v319,
				["text"] = v303.lines.stash
			}
			local v325
			if v303.count > 0 then
				v325 = v_u_240.accent
			else
				v325 = v_u_240.text2
			end
			v324.color = v325
			v320 = v320 + 1
			v324.order = v320
			v324.size = UDim2.new(1, 0, 0, v_u_256 and 20 or 26)
			v323(v324)
			local v326
			if v303.lines.key then
				local v327 = v_u_238.label
				local v328 = {
					["parent"] = nil,
					["name"] = "KeyLine",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["order"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v319,
					["text"] = v303.lines.key
				}
				local v329
				if v303.keys > 0 or v303.free then
					v329 = v_u_240.text2
				else
					v329 = v_u_240.danger
				end
				v328.color = v329
				v320 = v320 + 1
				v328.order = v320
				v328.size = UDim2.new(1, 0, 0, v_u_256 and 16 or 20)
				v327(v328)
				v326 = v320
			else
				v326 = v320
			end
			if v303.lines.cash then
				local v330 = v_u_238.label
				local v331 = {
					["parent"] = nil,
					["name"] = "CashLine",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["order"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v319,
					["text"] = v303.lines.cash,
					["color"] = v_u_240.text2
				}
				v320 = v326 + 1
				v331.order = v320
				v331.size = UDim2.new(1, 0, 0, v_u_256 and 16 or 20)
				v330(v331)
				v326 = v320
			end
			local v332 = v_u_238.button
			local v333 = {
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = nil,
				["name"] = "Contents",
				["order"] = nil,
				["onClick"] = nil,
				["parent"] = v319,
				["text"] = v_u_2.TEXT.contents,
				["height"] = v_u_239.touch(v_u_256 and 34 or 42),
				["width"] = v_u_256 and 150 or 190
			}
			v320 = v326 + 1
			v333.order = v320
			v333.onClick = v_u_273
			local v334, _ = v332(v333)
			v_u_259.contents = v334
		end
	end
	local function v_u_340(p336, _, p337, p338) -- name: actionRow
		-- upvalues: (copy) v_u_238
		local v339 = v_u_238.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Row" .. p338,
			["Size"] = UDim2.new(1, 0, 0, p337),
			["LayoutOrder"] = p338
		}, p336)
		v_u_238.layout(v339, "h", 10).VerticalAlignment = Enum.VerticalAlignment.Center
		return v339
	end
	local function v_u_421() -- name: drawActions
		-- upvalues: (ref) v_u_243, (ref) v_u_250, (ref) v_u_251, (copy) v_u_264, (ref) v_u_248, (copy) v_u_231, (copy) v_u_238, (copy) v_u_256, (copy) p_u_228, (ref) v_u_237, (ref) v_u_242, (ref) v_u_100, (ref) v_u_244, (copy) v_u_241, (copy) v_u_273, (copy) v_u_259, (ref) v_u_2, (copy) v_u_240, (copy) v_u_258, (copy) v_u_239, (ref) v_u_227, (ref) v_u_5, (copy) v_u_289, (copy) v_u_294, (copy) v_u_299, (copy) v_u_340, (copy) v_u_301, (ref) v_u_1
		local v_u_341 = v_u_243
		local v342 = (v_u_341 == nil or not v_u_341.scan) and "buttons" or "scan"
		if v342 ~= v_u_250 then
			if v_u_251 then
				local v343 = v_u_251.destroy
				pcall(v343)
				v_u_251 = nil
			end
			v_u_264(v_u_248)
			v_u_250 = v342
		end
		if v342 == "scan" then
			if v_u_251 == nil then
				local function v344()
					-- upvalues: (ref) v_u_231
					return v_u_231.lib.MenuCratesScan
				end
				local v345, v346 = pcall(v344)
				if v345 and v346 then
					local v347 = v_u_238.new("Frame", {
						["Name"] = "ScanHolder",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 2,
						["Size"] = UDim2.new(1, 0, 0, v_u_256 and 250 or 340)
					}, v_u_248)
					local v348 = v346.new
					local v349 = p_u_228
					local v355 = {
						["phone"] = true,
						["compact"] = true,
						["embed"] = true,
						["only"] = nil,
						["view"] = nil,
						["busy"] = nil,
						["refetch"] = nil,
						["odds"] = nil,
						["only"] = v_u_237,
						["view"] = function() -- name: view
							-- upvalues: (ref) v_u_242
							return v_u_242
						end,
						["busy"] = function() -- name: busy
							-- upvalues: (ref) v_u_100
							return v_u_100
						end,
						["refetch"] = function() -- name: refetch
							-- upvalues: (ref) v_u_244, (ref) p_u_228, (ref) v_u_241, (ref) v_u_242
							v_u_244 = v_u_244 + 1
							local v_u_350 = v_u_244
							local v_u_351 = 0
							task.spawn(function()
								-- upvalues: (ref) p_u_228, (copy) v_u_351, (copy) v_u_350, (ref) v_u_244, (ref) v_u_241, (ref) v_u_242
								local v352 = p_u_228.fetch("crates", nil, v_u_351 or 0)
								if v_u_350 == v_u_244 and v_u_241.alive then
									if type(v352) == "table" then
										v_u_242 = v352
									end
									local v353 = v_u_241.draw
									local v354
									if type(v352) == "table" then
										v354 = false
									else
										v354 = v_u_242 == nil
									end
									v353(v354)
								end
							end)
						end,
						["odds"] = function() -- name: odds
							-- upvalues: (ref) v_u_273
							v_u_273()
						end
					}
					local v356, v357 = pcall(v348, v349, v355)
					if v356 then
						v_u_251 = v357
						v357.frame.Parent = v347
						v357.frame.Visible = true
					else
						warn("[CrateWindow] the scan view failed: " .. tostring(v357))
					end
				end
			end
			if v_u_251 then
				v_u_251.draw()
				if v_u_238.device() == "Gamepad" then
					v_u_251.focus()
				end
			end
			return
		else
			v_u_264(v_u_248)
			table.clear(v_u_259)
			local v358 = v_u_2.TEXT
			local v359 = 0
			if v_u_341 == nil or v_u_341.crate == nil then
				if v_u_341 == nil or v_u_341.state ~= "missing" then
					local v360 = v_u_238.label
					local v361 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_248,
						["text"] = v358.loading,
						["color"] = v_u_240.text2
					}
					v359 = v359 + 1
					v361.order = v359
					v360(v361)
				else
					local v362 = v_u_238.label
					local v363 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_248,
						["text"] = v_u_341.notice or v358.missing,
						["color"] = v_u_240.text2
					}
					v359 = v359 + 1
					v363.order = v359
					v362(v363)
				end
			else
				local v364
				if v_u_258 then
					local v365 = v_u_238.new
					local v366 = {
						["Name"] = "Banner",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["BackgroundColor3"] = v_u_240.accentDeep,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}
					v359 = v359 + 1
					v366.LayoutOrder = v359
					local v367 = v365("Frame", v366, v_u_248)
					v_u_238.stroke(v367, v_u_240.accent)
					v_u_238.pad(v367, {
						12,
						12,
						8,
						8
					})
					v_u_238.label({
						["parent"] = nil,
						["name"] = "BannerText",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = v367,
						["text"] = v_u_258,
						["color"] = v_u_240.text
					})
					v364 = v359
				else
					v364 = v359
				end
				if v_u_341.notice then
					local v368 = v_u_238.label
					local v369 = {
						["parent"] = nil,
						["name"] = "Notice",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_248,
						["text"] = v_u_341.notice
					}
					local v370
					if v_u_341.state == "nocase" then
						v370 = v_u_240.text2
					else
						v370 = v_u_240.accent
					end
					v369.color = v370
					v359 = v364 + 1
					v369.order = v359
					v368(v369)
					v364 = v359
				end
				local v371 = v_u_239.touch(v_u_256 and 58 or 76)
				local v372 = v_u_2.layoutRows(v_u_341, v_u_256)
				local v_u_373 = nil
				local function v390(p374, p375, p376, p377) -- name: makeButton
					-- upvalues: (ref) v_u_227, (ref) p_u_228, (copy) v_u_341, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_100, (ref) v_u_5, (ref) v_u_259, (ref) v_u_373, (ref) v_u_289, (ref) v_u_294, (ref) v_u_299
					if p374 == "key" then
						local v383 = v_u_227(p_u_228, p375, "OpenKey", v_u_341.key, p376, p377, function()
							-- upvalues: (ref) v_u_341, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_100, (ref) p_u_228, (ref) v_u_5
							if v_u_341.key.enabled then
								local v378 = v_u_2.crateRow(v_u_242, v_u_237)
								if v378 ~= nil then
									if not v_u_100 then
										local v379 = v_u_242
										v_u_2.close("opening")
										v_u_2.startOpening(p_u_228, v379, v378, nil)
									end
								end
							else
								local v380 = p_u_228
								local v381 = v_u_341.key.why or v_u_5.TEXT.notNow
								local v382 = v380.ui.toast
								pcall(v382, v381, "warn")
							end
						end)
						v_u_259.key = v383
						if v_u_341.key.enabled then
							v_u_373 = v_u_373 or v383
							return
						end
					elseif p374 == "cash" then
						local v387 = v_u_227(p_u_228, p375, "OpenCash", v_u_341.cash, p376, p377, function()
							-- upvalues: (ref) v_u_341, (ref) v_u_289, (ref) p_u_228, (ref) v_u_5
							if v_u_341.cash.enabled then
								v_u_289()
							else
								local v384 = p_u_228
								local v385 = v_u_341.cash.why or v_u_5.TEXT.notNow
								local v386 = v384.ui.toast
								pcall(v386, v385, "warn")
							end
						end)
						v_u_259.cash = v387
						if v_u_341.cash.enabled then
							v_u_373 = v_u_373 or v387
							return
						end
					elseif p374 == "buy" then
						local v388 = v_u_227(p_u_228, p375, "BuyKey", v_u_341.buy, p376, p377, v_u_294)
						v_u_259.buy = v388
						if v_u_341.buy.loud then
							v_u_373 = v_u_373 or v388
							return
						end
					elseif p374 == "getCash" then
						local v389 = v_u_227(p_u_228, p375, "GetCash", v_u_341.getCash, p376, p377, v_u_299)
						v_u_259.getCash = v389
						v_u_373 = v_u_373 or v389
					end
				end
				if #v372.first > 0 then
					local v391 = v_u_340
					local v392 = v_u_248
					local v393 = #v372.first
					v359 = v364 + 1
					local v394 = v391(v392, v393, v371, v359)
					v364 = v359
					for v395, v396 in v372.first do
						local v397 = #v372.first
						local v398
						if v397 <= 1 then
							v398 = UDim2.new(1, 0, 0, v371)
						else
							local v399 = UDim2.new
							local v400 = 1 / v397
							local v401 = (v397 - 1) * 10 / v397
							v398 = v399(v400, -math.ceil(v401), 0, v371)
						end
						v390(v396, v394, v398, v395)
					end
				end
				if #v372.second == 1 then
					local v402 = v372.second[1]
					local v403 = v_u_248
					local v404 = UDim2.new(1, 0, 0, v371)
					v359 = v364 + 1
					v390(v402, v403, v404, v359)
					v364 = v359
				elseif #v372.second > 1 then
					local v405 = v_u_340
					local v406 = v_u_248
					local v407 = #v372.second
					v359 = v364 + 1
					local v408 = v405(v406, v407, v371, v359)
					v364 = v359
					for v409, v410 in v372.second do
						local v411 = #v372.second
						local v412
						if v411 <= 1 then
							v412 = UDim2.new(1, 0, 0, v371)
						else
							local v413 = UDim2.new
							local v414 = 1 / v411
							local v415 = (v411 - 1) * 10 / v411
							v412 = v413(v414, -math.ceil(v415), 0, v371)
						end
						v390(v410, v408, v412, v409)
					end
				end
				if v_u_341.cashNote then
					local v416 = v_u_238.label
					local v417 = {
						["parent"] = nil,
						["name"] = "CashNote",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_248,
						["text"] = v_u_341.cashNote,
						["color"] = v_u_240.muted
					}
					v359 = v364 + 1
					v417.order = v359
					v416(v417)
					v364 = v359
				end
				if v_u_341.market.show then
					local v418 = v_u_238.button
					local v419 = {
						["parent"] = nil,
						["text"] = nil,
						["kind"] = "primary",
						["height"] = nil,
						["width"] = 240,
						["name"] = "FindMarket",
						["order"] = nil,
						["onClick"] = nil,
						["parent"] = v_u_248,
						["text"] = v_u_341.market.text,
						["height"] = v_u_239.touch(44)
					}
					v359 = v364 + 1
					v419.order = v359
					v419.onClick = v_u_301
					local v420 = v418(v419)
					v_u_259.market = v420
					v_u_373 = v_u_373 or v420
				end
				if v_u_373 then
					v_u_373:SetAttribute("PadDefault", true)
					if v_u_238.device() == "Gamepad" then
						task.defer(function()
							-- upvalues: (ref) v_u_241, (ref) v_u_373, (ref) v_u_1
							if v_u_241.alive and v_u_373.Parent then
								v_u_1.SelectedObject = v_u_373
							end
						end)
					end
				end
			end
		end
	end
	local function v_u_422() -- name: drawFoot
		-- upvalues: (copy) v_u_264, (ref) v_u_249, (copy) v_u_238, (ref) v_u_2, (copy) v_u_240
		v_u_264(v_u_249)
		v_u_238.label({
			["parent"] = nil,
			["name"] = "Fine",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v_u_249,
			["text"] = v_u_2.TEXT.fine,
			["color"] = v_u_240.muted
		})
	end
	function v_u_241.draw(p423) -- name: draw
		-- upvalues: (copy) v_u_241, (ref) v_u_246, (ref) v_u_243, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (copy) v_u_256, (copy) v_u_231, (copy) v_u_335, (copy) v_u_421, (copy) v_u_422
		if v_u_241.alive and (v_u_246 ~= nil and v_u_246.Parent ~= nil) then
			local v424 = v_u_2.model
			local v425 = v_u_242
			local v426 = v_u_237
			local v427 = {
				["small"] = v_u_256
			}
			local v_u_428 = true
			local function v429()
				-- upvalues: (ref) v_u_428, (ref) v_u_231
				v_u_428 = v_u_231.config.flag("CashPacks") ~= false
			end
			pcall(v429)
			v427.cashPacks = v_u_428
			v_u_243 = v424(v425, v426, v427)
			if p423 then
				v_u_243.state = "missing"
				v_u_243.notice = v_u_2.TEXT.error
			end
			v_u_335()
			v_u_421()
			v_u_422()
		end
	end
	function v_u_241.destroy(_) -- name: destroy
		-- upvalues: (copy) v_u_241, (ref) v_u_244, (ref) v_u_252, (copy) v_u_231, (ref) v_u_251, (ref) v_u_245
		if v_u_241.alive then
			v_u_241.alive = false
			v_u_244 = v_u_244 + 1
			if v_u_252 then
				local function v430()
					-- upvalues: (ref) v_u_231, (ref) v_u_252
					v_u_231.lib.ItemIcons.spin(v_u_252, false)
					v_u_231.lib.ItemIcons.release(v_u_252)
				end
				pcall(v430)
				v_u_252 = nil
			end
			if v_u_251 then
				local v431 = v_u_251.destroy
				pcall(v431)
				v_u_251 = nil
			end
			if v_u_245 then
				local v432 = v_u_245.close
				pcall(v432)
				v_u_245 = nil
			end
		end
	end
	function v_u_241.state() -- name: state
		-- upvalues: (ref) v_u_243, (ref) v_u_237, (copy) v_u_258, (copy) v_u_255, (ref) v_u_251
		local v433 = v_u_243
		local v434 = {
			["crate"] = v_u_237,
			["state"] = not v433 and "loading" or v433.state
		}
		local v435
		if v433 then
			v435 = v433.count
		else
			v435 = nil
		end
		v434.count = v435
		local v436
		if v433 then
			v436 = v433.keys
		else
			v436 = nil
		end
		v434.keys = v436
		local v437
		if v433 == nil then
			v437 = false
		else
			v437 = v433.scan == true
		end
		v434.scan = v437
		local v438
		if v433 then
			v438 = v433.key
		else
			v438 = v433
		end
		v434.key = v438
		local v439
		if v433 then
			v439 = v433.cash
		else
			v439 = v433
		end
		v434.cash = v439
		local v440
		if v433 then
			v440 = v433.buy
		else
			v440 = v433
		end
		v434.buy = v440
		local v441
		if v433 then
			v441 = v433.getCash
		else
			v441 = v433
		end
		v434.getCash = v441
		if v433 then
			v433 = v433.notice
		end
		v434.notice = v433
		v434.banner = v_u_258
		v434.layout = v_u_255
		v434.hasScan = v_u_251 ~= nil
		return v434
	end
	function v_u_241.press(p442) -- name: press
		-- upvalues: (ref) v_u_243, (ref) v_u_2, (ref) v_u_242, (ref) v_u_237, (ref) v_u_100, (copy) p_u_228, (copy) v_u_289, (copy) v_u_294, (copy) v_u_299, (copy) v_u_273, (ref) v_u_7, (copy) v_u_231
		local v443 = v_u_243
		if v443 == nil then
			return false
		elseif p442 == "key" and v443.key.show then
			if v443.key.enabled then
				local v444 = v_u_2.crateRow(v_u_242, v_u_237)
				if v444 ~= nil and not v_u_100 then
					local v445 = v_u_242
					v_u_2.close("opening")
					v_u_2.startOpening(p_u_228, v445, v444, nil)
				end
			end
			return v443.key.enabled
		elseif p442 == "cash" and v443.cash.show then
			if v443.cash.enabled then
				v_u_289()
			end
			return v443.cash.enabled
		elseif p442 == "cashnow" and (v443.cash.show and v443.cash.enabled) then
			local v446 = v_u_2.crateRow(v_u_242, v_u_237)
			if v446 ~= nil and not v_u_100 then
				local v447 = v_u_242
				v_u_2.close("opening")
				v_u_2.startOpening(p_u_228, v447, v446, "cash")
			end
			return true
		elseif p442 == "buy" and v443.buy.show then
			v_u_294()
			return true
		elseif p442 == "getcash" and v443.getCash.show then
			v_u_299()
			return true
		elseif p442 == "contents" or p442 == "odds" then
			v_u_273()
			return true
		elseif p442 == "market" and v443.market.show then
			v_u_2.close("market")
			if not v_u_7.openMarket(p_u_228, v_u_231) then
				local v448 = p_u_228.ui.toast
				pcall(v448, "The Market is not available right now.", "warn")
			end
			return true
		else
			if p442 ~= "close" then
				return false
			end
			v_u_2.close("press")
			return true
		end
	end
	function v_u_241.scanView()
		-- upvalues: (ref) v_u_251
		return v_u_251
	end
	v_u_241.rows = v_u_259
	function v_u_241.view()
		-- upvalues: (ref) v_u_242
		return v_u_242
	end
	v_u_99 = v_u_241
	local v_u_452 = v_u_238.modal({
		["title"] = v_u_260,
		["width"] = v_u_256 and 700 or 820,
		["onClose"] = function() -- name: onClose
			-- upvalues: (ref) v_u_99, (copy) v_u_241, (ref) v_u_244, (ref) v_u_252, (copy) v_u_231, (ref) v_u_251
			if v_u_99 == v_u_241 then
				v_u_99 = nil
			end
			v_u_241.alive = false
			v_u_244 = v_u_244 + 1
			if v_u_252 then
				local function v449()
					-- upvalues: (ref) v_u_231, (ref) v_u_252
					v_u_231.lib.ItemIcons.spin(v_u_252, false)
					v_u_231.lib.ItemIcons.release(v_u_252)
				end
				pcall(v449)
				v_u_252 = nil
			end
			if v_u_251 then
				local v450 = v_u_251.destroy
				pcall(v450)
				v_u_251 = nil
			end
		end,
		["build"] = function(p451) -- name: build
			-- upvalues: (ref) v_u_246, (ref) v_u_247, (copy) v_u_238, (copy) v_u_256, (ref) v_u_248, (ref) v_u_249
			v_u_246 = p451
			v_u_247 = v_u_238.new("Frame", {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, v_u_256 and 104 or 168)
			}, p451)
			v_u_248 = v_u_238.new("Frame", {
				["Name"] = "Actions",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, p451)
			v_u_238.layout(v_u_248, "v", v_u_256 and 6 or 10)
			v_u_249 = v_u_238.new("Frame", {
				["Name"] = "Foot",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 3,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, p451)
			v_u_238.layout(v_u_249, "v", 4)
		end,
		["buttons"] = {
			{
				["text"] = nil,
				["kind"] = "close",
				["text"] = v_u_2.TEXT.close
			}
		}
	})
	v_u_241.modal = v_u_452
	local function v455()
		-- upvalues: (ref) v_u_452
		local v453 = v_u_452.frame:FindFirstChild("Buttons", true)
		if v453 then
			for _, v454 in v453:GetDescendants() do
				if not v454:IsA("GuiButton") then
					continue
				end
				v454:SetAttribute("PadDefault", nil)
			end
		end
	end
	pcall(v455)
	task.spawn(function()
		-- upvalues: (copy) p_u_228, (copy) v_u_241, (ref) v_u_242, (ref) v_u_237, (ref) v_u_2, (ref) v_u_4, (ref) v_u_260, (ref) v_u_452, (copy) v_u_238, (ref) v_u_244
		local v456 = p_u_228.cache
		local v457
		if type(v456) == "table" then
			v457 = p_u_228.cache.crates
		else
			v457 = nil
		end
		local v458
		if type(v457) == "table" then
			local v459 = v457.data
			if type(v459) == "table" then
				local v460 = os.clock()
				local v461 = v457.at
				v458 = v460 - (tonumber(v461) or 0) < 20
			else
				v458 = false
			end
		else
			v458 = false
		end
		local v462
		if v458 then
			v462 = v457.data
		else
			v462 = p_u_228.fetch("crates", nil, 0)
		end
		if v_u_241.alive then
			if type(v462) == "table" then
				v_u_242 = v462
			end
			if v_u_237 == nil then
				v_u_237 = v_u_2.pickCrate(v_u_242)
				if v_u_237 == nil then
					v_u_241.draw(true)
					return
				end
				local v463 = v_u_4.get(v_u_237)
				local v464
				if v463 then
					v464 = v463.name
				else
					v464 = v_u_260
				end
				v_u_260 = v464
				local function v466()
					-- upvalues: (ref) v_u_452, (ref) v_u_238, (ref) v_u_260
					local v465 = v_u_452.body:FindFirstChildWhichIsA("TextLabel")
					if v465 then
						v_u_238.setText(v465, v_u_260)
					end
				end
				pcall(v466)
			end
			local v467 = v_u_241.draw
			local v468
			if type(v462) == "table" then
				v468 = false
			else
				v468 = v_u_242 == nil
			end
			v467(v468)
			if v458 then
				v_u_244 = v_u_244 + 1
				local v_u_469 = v_u_244
				local v_u_470 = 0
				task.spawn(function()
					-- upvalues: (ref) p_u_228, (copy) v_u_470, (copy) v_u_469, (ref) v_u_244, (ref) v_u_241, (ref) v_u_242
					local v471 = p_u_228.fetch("crates", nil, v_u_470 or 0)
					if v_u_469 == v_u_244 and v_u_241.alive then
						if type(v471) == "table" then
							v_u_242 = v471
						end
						local v472 = v_u_241.draw
						local v473
						if type(v471) == "table" then
							v473 = false
						else
							v473 = v_u_242 == nil
						end
						v472(v473)
					end
				end)
			end
		end
	end)
	v_u_241.draw(false)
	return true
end
function v_u_2.menuClosed() -- name: menuClosed
	-- upvalues: (copy) v_u_2, (ref) v_u_102, (ref) v_u_100, (ref) v_u_103
	v_u_2.close("menu")
	v_u_102 = nil
	if v_u_100 and v_u_103 then
		local function v475()
			-- upvalues: (ref) v_u_103
			local v474 = v_u_103.cctx.lib.CrateStage
			if v474 and v474.abort then
				v474.abort("menu")
			end
		end
		pcall(v475)
		v_u_100 = false
	end
end
function v_u_2.menuRebuilt() -- name: menuRebuilt
	-- upvalues: (ref) v_u_100, (ref) v_u_103
	if v_u_100 and v_u_103 then
		local function v477()
			-- upvalues: (ref) v_u_103
			local v476 = v_u_103.cctx.lib.CrateStage
			if v476 and v476.abort then
				v476.abort("menu")
			end
		end
		pcall(v477)
		v_u_100 = false
	end
end
function v_u_2.install(p_u_478) -- name: install
	-- upvalues: (ref) v_u_103, (ref) v_u_98, (ref) v_u_99, (ref) v_u_100, (copy) v_u_101, (copy) v_u_5, (copy) v_u_189, (copy) v_u_2, (ref) v_u_102
	v_u_103 = p_u_478
	if v_u_98 then
		return
	else
		v_u_98 = true
		if p_u_478.changed and p_u_478.changed.Connect then
			p_u_478.changed:Connect(function(p479, p480)
				-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) v_u_101, (ref) v_u_5, (ref) v_u_189, (copy) p_u_478
				if p479 == "profile" then
					local v481 = v_u_99
					if v481 and not v_u_100 then
						v481.refetch(5)
					end
					return
				elseif p479 == "result" and type(p480) == "table" then
					if p480.op == "crateOpen" and p480.req ~= nil then
						local v482 = v_u_101[p480.req]
						if v482 then
							v_u_101[p480.req] = nil
							if p480.ok == true then
								local v483 = p480.data
								if type(v483) == "table" then
									v482(p480.data, nil)
									return
								end
							end
							local v484 = nil
							local v485 = p480.msg
							local v486
							if type(v485) == "string" then
								v486 = p480.msg
							else
								v486 = v_u_5.TEXT.notNow
							end
							v482(v484, v486)
							return
						end
					elseif p480.op == "storeGrant" then
						v_u_189(p_u_478, p480)
						local v487 = v_u_99
						if v487 and not v_u_100 then
							p_u_478.invalidate("crates")
							v487.refetch(0)
						end
					end
				end
			end)
		end
		local v_u_488 = p_u_478.cctx
		if v_u_488 then
			v_u_488 = p_u_478.cctx.config
		end
		if type(v_u_488) == "table" then
			local v489 = v_u_488.watchFlag
			if type(v489) == "function" then
				task.spawn(function()
					-- upvalues: (copy) v_u_488, (ref) v_u_99, (ref) v_u_100
					local v490 = v_u_488.watchFlag
					local function v492()
						-- upvalues: (ref) v_u_99, (ref) v_u_100
						local v491 = v_u_99
						if v491 and not v_u_100 then
							v491.draw(false)
						end
					end
					pcall(v490, "CashPacks", v492)
				end)
			end
		end
		local v_u_493 = p_u_478.cctx
		if v_u_493.command and not p_u_478._crateWinCmds then
			p_u_478._crateWinCmds = true
			v_u_493.command("crates.window", function(p494)
				-- upvalues: (ref) v_u_2, (copy) p_u_478
				local v495 = v_u_2.open(p_u_478, p494[1], {
					["banner"] = p494[2] == "bought" and "Purchase complete." or nil
				})
				local v496 = tostring(v495)
				local v497 = p494[1] or "(first case)"
				return "window " .. v496 .. " " .. tostring(v497)
			end)
			v_u_493.command("crates.state", function()
				-- upvalues: (ref) v_u_99, (ref) v_u_100, (ref) v_u_102
				local v498 = v_u_99
				if not v498 then
					local v499 = "no crate window (opening=%s pending=%s)"
					local v500 = v_u_100
					local v501 = tostring(v500)
					local v502 = v_u_102
					if v502 then
						v502 = v_u_102.crate
					end
					return v499:format(v501, (tostring(v502)))
				end
				local v503 = v498.state()
				local v504 = "crate=%s state=%s count=%s keys=%s key=%s/%s cash=%s/%s/short=%s buy=%s/loud=%s getcash=%s scan=%s layout=%s banner=%s"
				local v505 = v503.crate
				local v506 = tostring(v505)
				local v507 = v503.state
				local v508 = tostring(v507)
				local v509 = v503.count
				local v510 = tostring(v509)
				local v511 = v503.keys
				local v512 = tostring(v511)
				local v513 = v503.key
				if v513 then
					v513 = v503.key.show
				end
				local v514 = tostring(v513)
				local v515 = v503.key
				if v515 then
					v515 = v503.key.enabled
				end
				local v516 = tostring(v515)
				local v517 = v503.cash
				if v517 then
					v517 = v503.cash.show
				end
				local v518 = tostring(v517)
				local v519 = v503.cash
				if v519 then
					v519 = v503.cash.enabled
				end
				local v520 = tostring(v519)
				local v521 = v503.cash
				if v521 then
					v521 = v503.cash.short
				end
				local v522 = tostring(v521)
				local v523 = v503.buy
				if v523 then
					v523 = v503.buy.show
				end
				local v524 = tostring(v523)
				local v525 = v503.buy
				if v525 then
					v525 = v503.buy.loud
				end
				local v526 = tostring(v525)
				local v527 = v503.getCash
				if v527 then
					v527 = v503.getCash.show
				end
				local v528 = tostring(v527)
				local v529 = v503.scan
				local v530 = tostring(v529)
				local v531 = v503.layout
				local v532 = tostring(v531)
				local v533 = v503.banner
				return v504:format(v506, v508, v510, v512, v514, v516, v518, v520, v522, v524, v526, v528, v530, v532, (tostring(v533)))
			end)
			v_u_493.command("crates.press", function(p534)
				-- upvalues: (ref) v_u_99
				local v535 = v_u_99
				if not v535 then
					return "no crate window"
				end
				local v536 = p534[1]
				local v537 = tostring(v536)
				local v538 = v535.press
				local v539 = p534[1] or ""
				return "pressed " .. v537 .. " -> " .. tostring(v538(v539))
			end)
			v_u_493.command("crates.close", function()
				-- upvalues: (ref) v_u_2
				v_u_2.close("command")
				return "closed"
			end)
			v_u_493.command("crates.open", function(p540)
				-- upvalues: (copy) p_u_478, (ref) v_u_2
				local v541 = p_u_478.fetch("crates", nil, 0)
				local v542 = v_u_2.crateRow
				local v543 = p540[1]
				local v544 = v542(v541, v_u_2.resolve(v543) or v_u_2.pickCrate(v541))
				if not v544 then
					return "no such case"
				end
				local v545 = v_u_2.startOpening
				local v546 = p_u_478
				local v547 = p540[2] == "cash" and "cash" or nil
				return "start " .. tostring(v545(v546, v541, v544, v547))
			end)
			v_u_493.command("crates.odds", function(p548)
				-- upvalues: (ref) v_u_2, (copy) v_u_493, (copy) p_u_478
				local v549 = p548[1]
				local v550 = v_u_2.resolve(v549) or "skin_crate_field"
				local function v551()
					-- upvalues: (ref) v_u_493
					return v_u_493.lib.MenuCratesOdds
				end
				local v552, v553 = pcall(v551)
				if v552 and v553 then
					v553.open(p_u_478, { v550 })
				end
				return "odds " .. v550
			end)
			v_u_493.command("crates.pending", function()
				-- upvalues: (ref) v_u_2
				local v554 = v_u_2.pending()
				if not v554 then
					return "nothing pending"
				end
				local v555 = v554.crate
				local v556 = v554.product
				local v557 = tostring(v556)
				local v558 = v554.kind
				return ("pending %s product=%s kind=%s"):format(v555, v557, (tostring(v558)))
			end)
			v_u_493.command("crates.back", function()
				-- upvalues: (ref) v_u_2
				local v559 = v_u_2.back
				return "back " .. tostring(v559("Purchase complete."))
			end)
			v_u_493.command("crates.stage", function(p560)
				-- upvalues: (copy) v_u_493
				local function v561()
					-- upvalues: (ref) v_u_493
					return v_u_493.lib.CrateStage
				end
				local v562, v563 = pcall(v561)
				local v564
				if v562 and v563 then
					v564 = v563.active()
				else
					v564 = nil
				end
				if not v564 then
					return "no scene running"
				end
				if p560[1] == "next" then
					v564:_next()
				elseif p560[1] == "equip" then
					v564:_equip()
				else
					if p560[1] ~= "done" then
						return "usage: crates.stage next|equip|done"
					end
					v564:stop("done")
				end
				local v565 = p560[1]
				return "pressed " .. tostring(v565)
			end)
			local function v_u_570(p566, p567)
				-- upvalues: (ref) v_u_2, (ref) v_u_99
				local v568 = p566.scan
				local v569 = p567[1]
				v568(v_u_2.resolve(v569) or (v_u_99 and v_u_99.state().crate or "skin_crate_field"))
				return "scan sent"
			end
			v_u_493.command("crates.scan", function(p571)
				-- upvalues: (ref) v_u_99, (copy) v_u_570
				local v572 = v_u_99
				if not v572 then
					return "no crate window (open one: crates.window <crate>)"
				end
				local v573 = v572.scanView()
				return not v573 and "no scan bench in this window (the account is not restricted: F8 SIMULATE paid random items restricted)" or v_u_570(v573, p571)
			end)
			local function v_u_576(p574, p575)
				p574.scrap(p575[1] == "now")
				return p575[1] == "now" and "scrap sent" or "scrap confirm shown"
			end
			v_u_493.command("crates.scrap", function(p577)
				-- upvalues: (ref) v_u_99, (copy) v_u_576
				local v578 = v_u_99
				if not v578 then
					return "no crate window (open one: crates.window <crate>)"
				end
				local v579 = v578.scanView()
				return not v579 and "no scan bench in this window (the account is not restricted: F8 SIMULATE paid random items restricted)" or v_u_576(v579, p577)
			end)
			local function v_u_582(p580, p581)
				p580.buy(p581[1] == "now")
				return p581[1] == "now" and "buy sent" or "buy confirm shown"
			end
			v_u_493.command("crates.scanbuy", function(p583)
				-- upvalues: (ref) v_u_99, (copy) v_u_582
				local v584 = v_u_99
				if not v584 then
					return "no crate window (open one: crates.window <crate>)"
				end
				local v585 = v584.scanView()
				return not v585 and "no scan bench in this window (the account is not restricted: F8 SIMULATE paid random items restricted)" or v_u_582(v585, p583)
			end)
			local function v_u_587(p586)
				p586.claim()
				return "claim sent"
			end
			v_u_493.command("crates.claim", function(p588)
				-- upvalues: (ref) v_u_99, (copy) v_u_587
				local v589 = v_u_99
				if not v589 then
					return "no crate window (open one: crates.window <crate>)"
				end
				local v590 = v589.scanView()
				return not v590 and "no scan bench in this window (the account is not restricted: F8 SIMULATE paid random items restricted)" or v_u_587(v590, p588)
			end)
			local function v_u_605(p591)
				-- upvalues: (ref) v_u_99
				local v592 = p591.state()
				local v593 = v_u_99
				if v593 then
					v593 = v593.view()
				end
				if v593 then
					v593 = v593.scan
				end
				local v594 = "sel=%s revealing=%s pending=%s visible=%s open=%s day=%s"
				local v595 = v592.sel
				local v596 = tostring(v595)
				local v597 = v592.revealing
				local v598 = tostring(v597)
				local v599 = v592.pending
				local v600 = tostring(v599)
				local v601
				if v593 then
					v601 = v593.visible
				else
					v601 = v593
				end
				local v602 = tostring(v601)
				local v603 = v593 and v593.open
				if v603 then
					v603 = v593.open.skin
				end
				local v604 = tostring(v603)
				if v593 then
					v593 = v593.day
				end
				return v594:format(v596, v598, v600, v602, v604, (tostring(v593)))
			end
			v_u_493.command("crates.scanstate", function(p606)
				-- upvalues: (ref) v_u_99, (copy) v_u_605
				local v607 = v_u_99
				if not v607 then
					return "no crate window (open one: crates.window <crate>)"
				end
				local v608 = v607.scanView()
				return not v608 and "no scan bench in this window (the account is not restricted: F8 SIMULATE paid random items restricted)" or v_u_605(v608, p606)
			end)
		end
	end
end
return v_u_2