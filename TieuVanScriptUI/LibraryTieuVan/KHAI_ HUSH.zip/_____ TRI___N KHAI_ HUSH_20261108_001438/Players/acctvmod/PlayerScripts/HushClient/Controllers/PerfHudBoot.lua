-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / PerfHudBoot

return {
	["name"] = "PerfHudBoot",
	["order"] = 91,
	["init"] = function(p_u_1) -- name: init
		local v2, v3 = pcall(function()
			-- upvalues: (copy) p_u_1
			p_u_1.lib.PerfHud.start(p_u_1)
		end)
		if not v2 then
			warn("[PerfHudBoot] the performance line failed to start:", v3)
			p_u_1.player:SetAttribute("ClientError", "perfhud: " .. tostring(v3))
		end
	end
}