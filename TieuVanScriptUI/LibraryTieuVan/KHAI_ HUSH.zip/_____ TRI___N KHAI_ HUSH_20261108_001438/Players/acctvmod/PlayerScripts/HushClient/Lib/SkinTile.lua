-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SkinTile

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
v_u_1.LIST_TEX_MAX = 6
v_u_1.LIST_ICON_MAX = 400
v_u_1.YAW = 0.35
v_u_1.WEAR_YAW = 0.45
local v_u_3 = game:GetService("RunService")
v_u_1.LAZY_EVERY = 0.1
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = 0
local v_u_8 = 0
local v_u_9 = false
function v_u_1.watching() -- name: watching
	-- upvalues: (copy) v_u_4
	local v10 = 0
	for _ in v_u_4 do
		v10 = v10 + 1
	end
	return v10
end
local v_u_11 = 0
function v_u_1.live() -- name: live
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_1.texAllowed(p12) -- name: texAllowed
	-- upvalues: (copy) v_u_1
	local v13
	if type(p12) == "number" then
		v13 = p12 <= v_u_1.LIST_TEX_MAX
	else
		v13 = false
	end
	return v13
end
local v_u_14 = {}
v_u_1.iconsOverride = nil
function v_u_1.iconFor(p15, p16) -- name: iconFor
	-- upvalues: (copy) v_u_1, (copy) v_u_14, (copy) v_u_2
	if type(p15) ~= "string" then
		return nil
	end
	local v17 = v_u_1.iconsOverride
	if v17 == false then
		return nil
	end
	local v18
	if type(v17) == "table" then
		v18 = v17[p15]
	else
		local v19 = v_u_14.SSkinIcons
		if v19 == nil or v19 == false then
			local v20 = v_u_2:FindFirstChild("SkinIcons")
			local v21
			if v20 then
				local v22 = require
				v21, v19 = pcall(v22, v20)
			else
				v21 = false
				v19 = nil
			end
			if not v21 or type(v19) ~= "table" then
				v19 = false
			end
			if v19 then
				v_u_14.SSkinIcons = v19
			end
		end
		local v23 = v19 or nil
		if v23 then
			local v24 = v23.imageFor
			if type(v24) == "function" then
				v18 = v23.imageFor(p15)
			else
				v18 = nil
			end
		else
			v18 = nil
		end
	end
	if type(v18) == "table" then
		local v25 = v18.image
		if type(v25) == "string" and v18.image ~= "" then
			local v26 = v18.rectOffset
			if typeof(v26) == "Vector2" then
				local v27 = v18.rectSize
				if typeof(v27) == "Vector2" then
					if p16 ~= nil then
						local v28 = v_u_14.SSkins
						if v28 == nil then
							local v_u_29 = "Skins"
							local function v30()
								-- upvalues: (ref) v_u_2, (copy) v_u_29
								return require(v_u_2:WaitForChild(v_u_29, 5))
							end
							local v31
							v31, v28 = pcall(v30)
							if not v31 then
								v28 = false
							end
							v_u_14.SSkins = v28
						end
						local v32 = v28 or nil
						if v32 then
							v32 = v32.get(p15)
						end
						if v32 == nil or v32.weapon ~= p16 then
							return nil
						end
					end
					return v18
				end
			end
		end
	end
	return nil
end
function v_u_1.icon(p33, p34, p35) -- name: icon
	-- upvalues: (copy) v_u_1
	local v36 = p35 or {}
	local v37 = v_u_1.iconFor(p34, v36.weaponId)
	if v37 == nil then
		return nil
	end
	local v38 = Instance.new("ImageLabel")
	v38.Name = v36.name or "Weapon"
	v38.BackgroundTransparency = 1
	v38.BorderSizePixel = 0
	v38.Image = v37.image
	v38.ImageRectOffset = v37.rectOffset
	v38.ImageRectSize = v37.rectSize
	v38.ScaleType = Enum.ScaleType.Fit
	v38.Size = v36.size or UDim2.fromScale(1, 1)
	v38.Position = v36.position or UDim2.new()
	v38.AnchorPoint = v36.anchor or Vector2.zero
	v38.ZIndex = v36.zindex or 2
	v38:SetAttribute("SkinIcon", p34)
	if p33 then
		v38.Parent = p33
	end
	return v38
end
v_u_1.UPGRADES_PER_STEP = 4
v_u_1.UPGRADES_PER_STEP_TOUCH = 1
v_u_1.IDLE_DROP = 10
v_u_1.IDLE_DROP_TOUCH = 5
v_u_1.RETRY_BUDGET = 1
v_u_1.RETRY_OTHER = 5
v_u_1.REFRESH_EVERY = 30
v_u_1.hooks = {}
v_u_1.stepQuotaOverride = nil
local function v_u_40(p39) -- name: defaultRect
	return p39.AbsolutePosition, p39.AbsoluteSize
end
function v_u_1.onScreen(p41, p42) -- name: onScreen
	-- upvalues: (copy) v_u_40
	local v43 = p42 or {}
	if typeof(p41) ~= "Instance" or not p41:IsA("GuiObject") then
		return "off", 0, 0
	end
	local v44 = v43.rectOf or v_u_40
	local v45, v46, v47 = pcall(v44, p41)
	if not v45 or (typeof(v46) ~= "Vector2" or typeof(v47) ~= "Vector2") then
		return "off", 0, 0
	end
	local v48 = v46.X
	local v49 = v46.Y
	local v50 = v46.X + v47.X
	local v51 = v46.Y + v47.Y
	if v47.X < 1 or (v47.Y < 1 or not p41.Visible) then
		return "off", v48, v49
	end
	local v52 = v43.margin
	local v53
	if type(v52) == "number" then
		v53 = v43.margin
	else
		local v54 = v47.X
		local v55 = v47.Y
		v53 = math.max(v54, v55)
	end
	local v56 = p41.Parent
	local v57 = false
	local v58 = false
	local v59 = true
	local v60 = true
	while v56 ~= nil do
		if v56:IsA("GuiObject") then
			if not v56.Visible then
				return "off", v48, v49
			end
			if v56.ClipsDescendants then
				local v61, v62, v63 = pcall(v44, v56)
				if v61 and (typeof(v62) == "Vector2" and typeof(v63) == "Vector2") then
					local v64 = v62.X
					local v65 = v62.Y
					local v66 = v62.X + v63.X
					local v67 = v62.Y + v63.Y
					local v68
					if v64 - 0 < v50 and (v48 < v66 + 0 and v65 - 0 < v51) then
						v68 = v49 < v67 + 0
					else
						v68 = false
					end
					if not v68 then
						v59 = false
					end
					local v69 = v62.X
					local v70 = v62.Y
					local v71 = v62.X + v63.X
					local v72 = v62.Y + v63.Y
					local v73
					if v69 - v53 < v50 and (v48 < v71 + v53 and v70 - v53 < v51) then
						v73 = v49 < v72 + v53
					else
						v73 = false
					end
					if not v73 then
						v60 = false
					end
				end
			end
		elseif v56:IsA("LayerCollector") then
			if not v56.Enabled then
				return "off", v48, v49
			end
			v58 = v56:IsA("ScreenGui")
			v57 = true
			break
		end
		v56 = v56.Parent
	end
	if v57 then
		if v58 then
			local v74 = v43.viewport
			if v74 == nil then
				local v75 = workspace.CurrentCamera
				if v75 then
					v74 = v75.ViewportSize
				else
					v74 = nil
				end
			end
			if typeof(v74) == "Vector2" and (v74.X > 0 and v74.Y > 0) then
				local v76 = v74.X
				local v77 = v74.Y
				local v78
				if v50 > 0 and (v48 < v76 + 0 and v51 > 0) then
					v78 = v49 < v77 + 0
				else
					v78 = false
				end
				if not v78 then
					v59 = false
				end
				local v79 = v74.X
				local v80 = v74.Y
				local v81
				if 0 - v53 < v50 and (v48 < v79 + v53 and 0 - v53 < v51) then
					v81 = v49 < v80 + v53
				else
					v81 = false
				end
				if not v81 then
					v60 = false
				end
			end
		end
		if v59 then
			return "on", v48, v49
		else
			return v60 and "near" or "off", v48, v49
		end
	else
		return "off", v48, v49
	end
end
local v_u_82 = 0
local v_u_83 = {}
local function v_u_94(p84) -- name: entryDrop
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (copy) v_u_4, (ref) v_u_6, (copy) v_u_5
	local v85 = v_u_14.SSkinTex
	if v85 == nil then
		local v_u_86 = "SkinTex"
		local function v87()
			-- upvalues: (ref) v_u_2, (copy) v_u_86
			return require(v_u_2:WaitForChild(v_u_86, 5))
		end
		local v88
		v88, v85 = pcall(v87)
		if not v88 then
			v85 = false
		end
		v_u_14.SSkinTex = v85
	end
	local v89 = v85 or nil
	local v90 = p84.vp
	local v91
	if typeof(v90) == "Instance" then
		v91 = v90:FindFirstChildWhichIsA("Model")
	else
		v91 = nil
	end
	if v91 and v89 then
		local v92 = v_u_1.hooks.revert or v89.revert
		pcall(v92, v91)
	end
	p84.textured = false
	p84.watch = nil
	p84.nextTry = 0
	v_u_4[p84] = nil
	if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
		v_u_6:Disconnect()
		v_u_6 = nil
	end
	if p84.onChange then
		local v93 = p84.onChange
		pcall(v93, false)
	end
end
local function v_u_116(p95, p96) -- name: entryTextured
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (copy) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_3, (ref) v_u_9
	local v97 = v_u_14.SSkinTex
	if v97 == nil then
		local v_u_98 = "SkinTex"
		local function v99()
			-- upvalues: (ref) v_u_2, (copy) v_u_98
			return require(v_u_2:WaitForChild(v_u_98, 5))
		end
		local v100
		v100, v97 = pcall(v99)
		if not v100 then
			v97 = false
		end
		v_u_14.SSkinTex = v97
	end
	local v101 = v97 or nil
	p95.textured = true
	p95.lastOn = p96
	p95.nextTry = 0
	local v102
	if v101 then
		local v103 = v101.status
		local v104 = p95.skin
		local v105, v106 = pcall(v103, v104)
		if (not v105 or v106 ~= true) and v_u_1.hooks.upgrade == nil then
			local v107 = p95.watchUpgrade
			if type(v107) ~= "function" then
				if p95.onChange then
					v102 = p95.onChange
					pcall(v102, true)
				end
				return
			end
		end
		p95.watch = v101.watchNew(p95.skin, {
			["opts"] = {
				["own"] = false,
				["preview"] = true,
				["list"] = true
			},
			["upgrade"] = p95.watchUpgrade or v_u_1.hooks.upgrade
		})
		v_u_4[p95] = true
		if v_u_6 == nil then
			v_u_7 = 0
			v_u_8 = 0
			v_u_6 = v_u_3.Heartbeat:Connect(function(p108)
				-- upvalues: (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
				v_u_8 = v_u_8 + p108
				if v_u_8 >= v_u_1.LAZY_EVERY then
					v_u_8 = 0
					local v109 = v_u_1.lazyStep
					local v110 = os.clock
					local v111, v112 = pcall(v109, v110())
					if not (v111 or v_u_9) then
						v_u_9 = true
						warn("[SkinTile] a step of the texture queue failed (the tiles keep the colour look): " .. tostring(v112))
					end
				end
				v_u_7 = v_u_7 + p108
				if v_u_7 >= 1 then
					v_u_7 = 0
					local v113 = os.clock()
					for v114 in v_u_4 do
						local v115 = v114.watchTick
						pcall(v115, v113)
					end
				end
			end)
		end
		if p95.onChange then
			v102 = p95.onChange
			pcall(v102, true)
		end
	elseif p95.onChange then
		v102 = p95.onChange
		pcall(v102, true)
	end
end
local function v_u_160(p117, p118, p119, p120, p121) -- name: lazyAdd
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (ref) v_u_82, (copy) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_3, (ref) v_u_9, (copy) v_u_4
	local v122 = v_u_14.SSkinTex
	if v122 == nil then
		local v_u_123 = "SkinTex"
		local function v124()
			-- upvalues: (ref) v_u_2, (copy) v_u_123
			return require(v_u_2:WaitForChild(v_u_123, 5))
		end
		local v125
		v125, v122 = pcall(v124)
		if not v125 then
			v122 = false
		end
		v_u_14.SSkinTex = v122
	end
	local v126 = v122 or nil
	if not v126 or (typeof(p117) ~= "Instance" or typeof(p118) ~= "Instance") then
		return nil
	end
	local v127 = v_u_14.SSkins
	if v127 == nil then
		local v_u_128 = "Skins"
		local function v129()
			-- upvalues: (ref) v_u_2, (copy) v_u_128
			return require(v_u_2:WaitForChild(v_u_128, 5))
		end
		local v130
		v130, v127 = pcall(v129)
		if not v130 then
			v127 = false
		end
		v_u_14.SSkins = v127
	end
	local v131 = v127 or nil
	local v132 = v_u_14.SSkinFinishes
	if v132 == nil then
		local v_u_133 = "SkinFinishes"
		local function v134()
			-- upvalues: (ref) v_u_2, (copy) v_u_133
			return require(v_u_2:WaitForChild(v_u_133, 5))
		end
		local v135
		v135, v132 = pcall(v134)
		if not v135 then
			v132 = false
		end
		v_u_14.SSkinFinishes = v132
	end
	local v136 = v132 or nil
	if v131 then
		v131 = v131.get(p119)
	end
	if v131 then
		if v136 then
			v136 = v136.get(v131.finish)
		end
	else
		v136 = v131
	end
	local v137, v138
	if v136 == nil then
		v137 = nil
		v138 = false
	else
		v137 = v136.id
		if v136.tex == true then
			v138 = true
		else
			v138 = false
		end
	end
	if v137 == nil or not v138 then
		return nil
	end
	local v139 = p118:FindFirstChildWhichIsA("Model")
	if v139 == nil or v139:GetAttribute("SkinId") ~= p119 then
		return nil
	end
	if v_u_1.hooks.upgrade == nil and type(p121) ~= "function" then
		local v140 = v126.status
		local v141, v142 = pcall(v140, p119)
		if not v141 or v142 ~= true then
			return nil
		end
	end
	v_u_82 = v_u_82 + 1
	local v_u_151 = {
		["id"] = nil,
		["frame"] = nil,
		["vp"] = nil,
		["skin"] = nil,
		["finish"] = nil,
		["textured"] = false,
		["lastOn"] = (-1 / 0),
		["nextTry"] = 0,
		["state"] = "off",
		["x"] = 0,
		["y"] = 0,
		["onChange"] = nil,
		["watchUpgrade"] = nil,
		["alive"] = true,
		["id"] = v_u_82,
		["frame"] = p117,
		["vp"] = p118,
		["skin"] = p119,
		["finish"] = v137,
		["onChange"] = p120,
		["watchUpgrade"] = p121,
		["watchTick"] = function(p143) -- name: watchTick
			-- upvalues: (copy) v_u_151, (ref) v_u_14, (ref) v_u_2
			if v_u_151.alive and (v_u_151.watch and (v_u_151.textured and v_u_151.state == "on")) then
				local v144 = v_u_14.SSkinTex
				if v144 == nil then
					local v_u_145 = "SkinTex"
					local function v146()
						-- upvalues: (ref) v_u_2, (copy) v_u_145
						return require(v_u_2:WaitForChild(v_u_145, 5))
					end
					local v147
					v147, v144 = pcall(v146)
					if not v147 then
						v144 = false
					end
					v_u_14.SSkinTex = v144
				end
				local v148 = v144 or nil
				local v149 = v_u_151.vp
				local v150
				if typeof(v149) == "Instance" then
					v150 = v149:FindFirstChildWhichIsA("Model")
				else
					v150 = nil
				end
				if v148 and v150 then
					return v148.watchStep(v_u_151.watch, v150, p143)
				else
					return nil
				end
			else
				return nil
			end
		end
	}
	v_u_5[v_u_151] = true
	if v_u_6 == nil then
		v_u_7 = 0
		v_u_8 = 0
		v_u_6 = v_u_3.Heartbeat:Connect(function(p152)
			-- upvalues: (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			v_u_8 = v_u_8 + p152
			if v_u_8 >= v_u_1.LAZY_EVERY then
				v_u_8 = 0
				local v153 = v_u_1.lazyStep
				local v154 = os.clock
				local v155, v156 = pcall(v153, v154())
				if not (v155 or v_u_9) then
					v_u_9 = true
					warn("[SkinTile] a step of the texture queue failed (the tiles keep the colour look): " .. tostring(v156))
				end
			end
			v_u_7 = v_u_7 + p152
			if v_u_7 >= 1 then
				v_u_7 = 0
				local v157 = os.clock()
				for v158 in v_u_4 do
					local v159 = v158.watchTick
					pcall(v159, v157)
				end
			end
		end)
	end
	return v_u_151
end
local function v_u_172(p161) -- name: warmFor
	-- upvalues: (copy) v_u_83, (copy) v_u_14, (copy) v_u_2, (copy) v_u_1
	if v_u_83[p161] then
		return true
	end
	local v162 = v_u_14.SSkinTex
	if v162 == nil then
		local v_u_163 = "SkinTex"
		local function v164()
			-- upvalues: (ref) v_u_2, (copy) v_u_163
			return require(v_u_2:WaitForChild(v_u_163, 5))
		end
		local v165
		v165, v162 = pcall(v164)
		if not v165 then
			v162 = false
		end
		v_u_14.SSkinTex = v162
	end
	local v166 = v162 or nil
	if not v166 then
		return false
	end
	local v167 = v_u_1.hooks
	local v168 = v167.prewarm or v166.prewarm
	pcall(v168, p161)
	local v169 = v167.warm or v166.warm
	local v170, v171 = pcall(v169, p161)
	if not v170 or v171 ~= true then
		return false
	end
	v_u_83[p161] = true
	return true
end
local function v_u_188(p173) -- name: reclaim
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_5, (copy) v_u_94
	local v174 = v_u_14.SSkinTex
	if v174 == nil then
		local v_u_175 = "SkinTex"
		local function v176()
			-- upvalues: (ref) v_u_2, (copy) v_u_175
			return require(v_u_2:WaitForChild(v_u_175, 5))
		end
		local v177
		v177, v174 = pcall(v176)
		if not v177 then
			v174 = false
		end
		v_u_14.SSkinTex = v174
	end
	local v178 = v174 or nil
	if not v178 then
		return false
	end
	local v179 = {}
	for v180 in v_u_5 do
		if not v180.textured or (not v180.alive or v180.finish == p173.finish) then
			continue
		end
		local v181 = v179[v180.finish]
		if v181 == nil then
			v181 = {
				["list"] = nil,
				["lastOn"] = (-1 / 0),
				["on"] = false,
				["list"] = {}
			}
			v179[v180.finish] = v181
		end
		local v182 = v181.list
		table.insert(v182, v180)
		if v180.lastOn > v181.lastOn then
			v181.lastOn = v180.lastOn
		end
		if v180.state ~= "on" then
			continue
		end
		v181.on = true
	end
	local v183 = v178.residentFinishes()
	local v184 = nil
	for v185, v186 in v179 do
		if v186.on or (v183[v185] ~= #v186.list or v184 ~= nil and v186.lastOn >= v184.lastOn) then
			continue
		end
		v184 = v186
	end
	if v184 == nil then
		return false
	end
	for _, v187 in v184.list do
		v_u_94(v187)
	end
	return true
end
local function v_u_207(p189, p190) -- name: attempt
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1, (copy) v_u_116, (copy) v_u_188
	local v191 = v_u_14.SSkinTex
	if v191 == nil then
		local v_u_192 = "SkinTex"
		local function v193()
			-- upvalues: (ref) v_u_2, (copy) v_u_192
			return require(v_u_2:WaitForChild(v_u_192, 5))
		end
		local v194
		v194, v191 = pcall(v193)
		if not v194 then
			v191 = false
		end
		v_u_14.SSkinTex = v191
	end
	local v195 = v191 or nil
	local v196 = p189.vp
	local v197
	if typeof(v196) == "Instance" then
		v197 = v196:FindFirstChildWhichIsA("Model")
	else
		v197 = nil
	end
	if v195 and v197 ~= nil then
		local v198 = v_u_1.hooks.upgrade or v195.upgrade
		local v199 = {
			["own"] = false,
			["preview"] = true,
			["list"] = true
		}
		local v200 = p189.skin
		local v201, v202, v203 = pcall(v198, v197, v200, v199)
		if v201 and v202 == true then
			v_u_116(p189, p190)
			return
		elseif v201 and v203 == "budget" then
			if v_u_188(p189) then
				local v204 = p189.skin
				local v205, v206, _ = pcall(v198, v197, v204, v199)
				if v205 and v206 == true then
					v_u_116(p189, p190)
					return
				end
			end
			p189.nextTry = p190 + v_u_1.RETRY_BUDGET
		else
			p189.nextTry = p190 + v_u_1.RETRY_OTHER
		end
	else
		p189.nextTry = p190 + v_u_1.RETRY_OTHER
		return
	end
end
local function v_u_211(p208) -- name: listRootOf
	if p208.root ~= nil and p208.root.Parent ~= nil then
		return p208.root
	end
	local v209 = p208.frame
	if typeof(v209) ~= "Instance" then
		return nil
	end
	local v210 = v209.Parent
	while v210 ~= nil do
		if v210:IsA("ScrollingFrame") or v210:IsA("LayerCollector") then
			p208.root = v210
			return v210
		end
		v210 = v210.Parent
	end
	return nil
end
local function v_u_213(p212) -- name: rootShown
	while p212 ~= nil do
		if p212:IsA("GuiObject") then
			if not p212.Visible then
				return false
			end
		elseif p212:IsA("LayerCollector") then
			return p212.Enabled == true
		end
		p212 = p212.Parent
	end
	return false
end
function v_u_1.lazyStep(p214) -- name: lazyStep
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_5, (copy) v_u_1, (copy) v_u_211, (copy) v_u_213, (copy) v_u_94, (copy) v_u_172, (copy) v_u_207
	local v215 = v_u_14.SSkinTex
	if v215 == nil then
		local v_u_216 = "SkinTex"
		local function v217()
			-- upvalues: (ref) v_u_2, (copy) v_u_216
			return require(v_u_2:WaitForChild(v_u_216, 5))
		end
		local v218
		v218, v215 = pcall(v217)
		if not v218 then
			v215 = false
		end
		v_u_14.SSkinTex = v215
	end
	local v219 = v215 or nil
	if not v219 or next(v_u_5) == nil then
		return 0
	end
	local v220 = v219.isTouch()
	local v221
	if v220 then
		v221 = v_u_1.IDLE_DROP_TOUCH
	else
		v221 = v_u_1.IDLE_DROP
	end
	local v222 = v_u_1.stepQuotaOverride
	if not v222 then
		if v220 then
			v222 = v_u_1.UPGRADES_PER_STEP_TOUCH
		else
			v222 = v_u_1.UPGRADES_PER_STEP
		end
	end
	local v223 = v_u_1.hooks.screen or v_u_1.onScreen
	local v224 = v_u_1.hooks.screen == nil
	local v225 = {}
	local v226 = {}
	for v227 in v_u_5 do
		local v228 = true
		local v229 = nil
		local v230 = v227.x
		local v231 = v227.y
		local v232
		if v224 then
			v232 = v_u_211(v227)
		else
			v232 = nil
		end
		if v232 ~= nil then
			local v233 = v226[v232]
			if v233 == nil then
				v233 = v_u_213(v232)
				v226[v232] = v233
			end
			v229 = not v233 and "off" or v229
		end
		if v229 == nil then
			local v234 = v227.frame
			v228, v229, v230, v231 = pcall(v223, v234)
		end
		if not v228 then
			v230 = 0
			v231 = 0
			v229 = "off"
		end
		v227.state = v229
		v227.x = v230 or 0
		v227.y = v231 or 0
		if v229 == "on" then
			v227.lastOn = p214
		end
		if v227.textured then
			if v229 == "on" or v221 > p214 - v227.lastOn then
				continue
			end
			v_u_94(v227)
		else
			if v227.nextTry > p214 then
				continue
			end
			if v229 == "on" then
				table.insert(v225, v227)
			else
				if v229 ~= "near" then
					continue
				end
				v_u_172(v227.skin)
			end
		end
	end
	table.sort(v225, function(p235, p236)
		if p235.y == p236.y then
			if p235.x == p236.x then
				return p235.id < p236.id
			else
				return p235.x < p236.x
			end
		else
			return p235.y < p236.y
		end
	end)
	local v237 = 0
	for _, v238 in v225 do
		if v222 <= v237 then
			break
		end
		if not v238.alive or (v238.textured or not v_u_172(v238.skin)) then
			continue
		end
		v237 = v237 + 1
		v_u_207(v238, p214)
	end
	return v237
end
function v_u_1.lazyStats() -- name: lazyStats
	-- upvalues: (copy) v_u_5
	local v239 = 0
	local v240 = 0
	local v241 = 0
	for v242 in v_u_5 do
		v239 = v239 + 1
		if v242.textured then
			v240 = v240 + 1
		end
		if v242.state ~= "on" then
			continue
		end
		v241 = v241 + 1
	end
	return {
		["entries"] = v239,
		["textured"] = v240,
		["onScreen"] = v241
	}
end
function v_u_1.lazyList() -- name: lazyList
	-- upvalues: (copy) v_u_5
	local v243 = {}
	for v244 in v_u_5 do
		local v245 = {
			["skin"] = v244.skin,
			["finish"] = v244.finish,
			["state"] = v244.state,
			["textured"] = v244.textured
		}
		local v246 = v244.vp
		v245.parent = (typeof(v246) ~= "Instance" or not v244.vp.Parent) and "-" or v244.vp.Parent.Name
		table.insert(v243, v245)
	end
	table.sort(v243, function(p247, p248)
		return p247.skin < p248.skin
	end)
	return v243
end
function v_u_1.resetLazy() -- name: resetLazy
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_83, (ref) v_u_6
	for v249 in v_u_5 do
		v249.alive = false
		v_u_4[v249] = nil
	end
	table.clear(v_u_5)
	table.clear(v_u_83)
	if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
		v_u_6:Disconnect()
		v_u_6 = nil
	end
end
function v_u_1.textureFor(p_u_250, p_u_251, p252) -- name: textureFor
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_160, (copy) v_u_5, (copy) v_u_4, (ref) v_u_6, (copy) v_u_94, (copy) v_u_1, (copy) v_u_172, (ref) v_u_7, (ref) v_u_8, (copy) v_u_3, (ref) v_u_9
	if typeof(p_u_250) ~= "Instance" or (not p_u_250:IsA("ViewportFrame") or type(p_u_251) ~= "string") then
		return nil
	end
	local v253 = v_u_14.SSkinTex
	if v253 == nil then
		local v_u_254 = "SkinTex"
		local function v255()
			-- upvalues: (ref) v_u_2, (copy) v_u_254
			return require(v_u_2:WaitForChild(v_u_254, 5))
		end
		local v256
		v256, v253 = pcall(v255)
		if not v256 then
			v253 = false
		end
		v_u_14.SSkinTex = v253
	end
	local v_u_257 = v253 or nil
	if not v_u_257 then
		return nil
	end
	local v258 = v_u_14.SSkins
	if v258 == nil then
		local v_u_259 = "Skins"
		local function v260()
			-- upvalues: (ref) v_u_2, (copy) v_u_259
			return require(v_u_2:WaitForChild(v_u_259, 5))
		end
		local v261
		v261, v258 = pcall(v260)
		if not v261 then
			v258 = false
		end
		v_u_14.SSkins = v258
	end
	local v262 = v258 or nil
	local v263 = v_u_14.SSkinFinishes
	if v263 == nil then
		local v_u_264 = "SkinFinishes"
		local function v265()
			-- upvalues: (ref) v_u_2, (copy) v_u_264
			return require(v_u_2:WaitForChild(v_u_264, 5))
		end
		local v266
		v266, v263 = pcall(v265)
		if not v266 then
			v263 = false
		end
		v_u_14.SSkinFinishes = v263
	end
	local v267 = v263 or nil
	local v268 = v262
	if v268 then
		v268 = v262.get(p_u_251)
	end
	if v268 then
		if v267 then
			v267 = v267.get(v268.finish)
		end
	end
	local v269
	if v267 == nil then
		v269 = false
	else
		local _ = v267.id
		v269 = v267.tex == true
	end
	if not v269 then
		return nil
	end
	if not p252 or p252.big ~= true then
		local v_u_270 = v_u_160(p_u_250, p_u_250, p_u_251, nil, nil)
		if v_u_270 == nil then
			return nil
		end
		p_u_250.Destroying:Connect(function()
			-- upvalues: (copy) v_u_270, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6
			local v271 = v_u_270
			v271.alive = false
			v_u_5[v271] = nil
			v_u_4[v271] = nil
			if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
				v_u_6:Disconnect()
				v_u_6 = nil
			end
		end)
		return {
			["entry"] = v_u_270,
			["stop"] = function() -- name: stop
				-- upvalues: (copy) v_u_270, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_94
				if v_u_270.alive then
					local v272 = v_u_270
					v272.alive = false
					v_u_5[v272] = nil
					v_u_4[v272] = nil
					if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
						v_u_6:Disconnect()
						v_u_6 = nil
					end
					v_u_94(v_u_270)
				end
			end
		}
	end
	local v273 = v_u_257.status
	local v274, v275 = pcall(v273, p_u_251)
	local v276 = p_u_250:FindFirstChildWhichIsA("Model")
	if not v274 or (v275 ~= true or (v276 == nil or v276:GetAttribute("SkinId") ~= p_u_251)) then
		return nil
	end
	local v_u_277 = {
		["alive"] = true,
		["big"] = true
	}
	local v_u_278 = v_u_257.watchNew(p_u_251, {
		["opts"] = {
			["own"] = true,
			["preview"] = true
		},
		["refreshEvery"] = v_u_1.REFRESH_EVERY
	})
	local v_u_279 = nil
	local function v_u_291() -- name: startAnim
		-- upvalues: (ref) v_u_279, (ref) v_u_14, (ref) v_u_2, (copy) p_u_250, (copy) v_u_277, (copy) p_u_251
		if v_u_279 then
			local v280 = v_u_279
			pcall(v280)
			v_u_279 = nil
		end
		local v281 = v_u_14.SSkinApply
		if v281 == nil then
			local v_u_282 = "SkinApply"
			local function v283()
				-- upvalues: (ref) v_u_2, (copy) v_u_282
				return require(v_u_2:WaitForChild(v_u_282, 5))
			end
			local v284
			v284, v281 = pcall(v283)
			if not v284 then
				v281 = false
			end
			v_u_14.SSkinApply = v281
		end
		local v285 = v281 or nil
		local v286 = p_u_250:FindFirstChildWhichIsA("Model")
		if v285 and (v286 and v_u_277.alive) then
			local v287 = v285.animate
			local v288 = p_u_251
			local v289, v290 = pcall(v287, v286, v288)
			if v289 and type(v290) == "function" then
				v_u_279 = v290
			end
		end
	end
	function v_u_277.watchTick(p292) -- name: watchTick
		-- upvalues: (copy) v_u_277, (copy) p_u_250, (copy) v_u_257, (copy) v_u_278, (copy) v_u_291
		if not v_u_277.alive then
			return nil
		end
		local v293 = p_u_250:FindFirstChildWhichIsA("Model")
		if not v293 then
			return nil
		end
		local v294 = v_u_257.watchStep(v_u_278, v293, p292)
		if v294 == "restored" or v294 == "refreshed" then
			v_u_291()
		end
		return v294
	end
	function v_u_277.stop() -- name: stop
		-- upvalues: (copy) v_u_277, (ref) v_u_4, (ref) v_u_6, (ref) v_u_5, (ref) v_u_279, (copy) p_u_250, (copy) v_u_257
		if v_u_277.alive then
			v_u_277.alive = false
			v_u_4[v_u_277] = nil
			if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
				v_u_6:Disconnect()
				v_u_6 = nil
			end
			if v_u_279 then
				local v295 = v_u_279
				pcall(v295)
				v_u_279 = nil
			end
			local v296 = p_u_250:FindFirstChildWhichIsA("Model")
			if v296 then
				local v297 = v_u_257.revert
				pcall(v297, v296)
			end
		end
	end
	p_u_250.Destroying:Connect(v_u_277.stop)
	task.spawn(function()
		-- upvalues: (copy) v_u_277, (ref) v_u_172, (copy) p_u_251, (copy) p_u_250, (copy) v_u_257, (ref) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_3, (ref) v_u_1, (ref) v_u_9, (copy) v_u_291
		local v298 = os.clock()
		while v_u_277.alive and (not v_u_172(p_u_251) and os.clock() - v298 < 5) do
			task.wait(0.1)
		end
		for _, v299 in {
			0,
			0.25,
			0.6,
			1.2,
			2.5
		} do
			if v299 > 0 then
				task.wait(v299)
			end
			local v300 = p_u_250:FindFirstChildWhichIsA("Model")
			if not v_u_277.alive or v300 == nil then
				return
			end
			local v301 = v_u_257.upgrade
			local v302 = p_u_251
			local v303, v304 = pcall(v301, v300, v302, {
				["own"] = true,
				["preview"] = true
			})
			if not v303 or v304 ~= true then
				continue
			end
		end
		if v_u_277.alive then
			v_u_4[v_u_277] = true
			if v_u_6 == nil then
				v_u_7 = 0
				v_u_8 = 0
				v_u_6 = v_u_3.Heartbeat:Connect(function(p305)
					-- upvalues: (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
					v_u_8 = v_u_8 + p305
					if v_u_8 >= v_u_1.LAZY_EVERY then
						v_u_8 = 0
						local v306 = v_u_1.lazyStep
						local v307 = os.clock
						local v308, v309 = pcall(v306, v307())
						if not (v308 or v_u_9) then
							v_u_9 = true
							warn("[SkinTile] a step of the texture queue failed (the tiles keep the colour look): " .. tostring(v309))
						end
					end
					v_u_7 = v_u_7 + p305
					if v_u_7 >= 1 then
						v_u_7 = 0
						local v310 = os.clock()
						for v311 in v_u_4 do
							local v312 = v311.watchTick
							pcall(v312, v310)
						end
					end
				end)
			end
			v_u_291()
		end
	end)
	return v_u_277
end
v_u_1.MIN_RATIO = 1.8
v_u_1.CLASS_WEIGHT = {
	["body"] = 0.5,
	["moving"] = 0.2,
	["mag"] = 0.15,
	["stock"] = 0.15
}
local v_u_313 = Color3.fromRGB(176, 184, 198)
local v_u_314 = Color3.fromRGB(24, 27, 34)
function v_u_1.lum(p315) -- name: lum
	local v316 = p315.R
	local v317
	if v316 <= 0.04045 then
		v317 = v316 / 12.92
	else
		v317 = ((v316 + 0.055) / 1.055) ^ 2.4
	end
	local v318 = v317 * 0.2126
	local v319 = p315.G
	local v320
	if v319 <= 0.04045 then
		v320 = v319 / 12.92
	else
		v320 = ((v319 + 0.055) / 1.055) ^ 2.4
	end
	local v321 = v318 + v320 * 0.7152
	local v322 = p315.B
	local v323
	if v322 <= 0.04045 then
		v323 = v322 / 12.92
	else
		v323 = ((v322 + 0.055) / 1.055) ^ 2.4
	end
	return v321 + v323 * 0.0722
end
function v_u_1.ratio(p324, p325) -- name: ratio
	local v326 = math.max(p324, p325)
	local v327 = math.min(p324, p325)
	return (v326 + 0.05) / (v327 + 0.05)
end
function v_u_1.finishParts(p328) -- name: finishParts
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_1
	local v329 = {}
	local v330 = v_u_14.SSkins
	if v330 == nil then
		local v_u_331 = "Skins"
		local function v332()
			-- upvalues: (ref) v_u_2, (copy) v_u_331
			return require(v_u_2:WaitForChild(v_u_331, 5))
		end
		local v333
		v333, v330 = pcall(v332)
		if not v333 then
			v330 = false
		end
		v_u_14.SSkins = v330
	end
	local v334 = v330 or nil
	local v335 = v_u_14.SSkinFinishes
	if v335 == nil then
		local v_u_336 = "SkinFinishes"
		local function v337()
			-- upvalues: (ref) v_u_2, (copy) v_u_336
			return require(v_u_2:WaitForChild(v_u_336, 5))
		end
		local v338
		v338, v335 = pcall(v337)
		if not v338 then
			v335 = false
		end
		v_u_14.SSkinFinishes = v335
	end
	local v339 = v335 or nil
	local v340
	if v334 and type(p328) == "string" then
		v340 = v334.get(p328) or nil
	else
		v340 = nil
	end
	local v341
	if v340 and v339 then
		v341 = v339.get(v340.finish) or nil
	else
		v341 = nil
	end
	if not v341 then
		return v329
	end
	for v342, v343 in v_u_1.CLASS_WEIGHT do
		local v344 = v339.styleFor(v341, v342)
		if v344 then
			v344 = v344.c
		end
		if type(v344) ~= "table" or #v344 ~= 3 then
			continue
		end
		local v345 = {
			["color"] = Color3.fromRGB(v344[1], v344[2], v344[3]),
			["weight"] = v343
		}
		table.insert(v329, v345)
	end
	return v329
end
function v_u_1.modelParts(p346) -- name: modelParts
	local v347 = {}
	if typeof(p346) ~= "Instance" then
		return v347
	end
	for _, v348 in p346:GetDescendants() do
		if not v348:IsA("BasePart") or (v348.Transparency >= 0.9 or v348:GetAttribute("SkinPlate") == true) then
			continue
		end
		local v349 = v348.Size
		local v350 = {
			["color"] = v348.Color
		}
		local v351 = v349.X * v349.Y * v349.Z
		v350.weight = math.max(v351, 0.0001)
		table.insert(v347, v350)
	end
	return v347
end
local function v_u_359(p352) -- name: heaviest
	-- upvalues: (copy) v_u_1
	local v353 = -1
	local v354 = 0
	local v355 = 0
	local v356 = 0
	for _, v357 in p352 do
		local v358 = v_u_1.lum(v357.color)
		if v353 < v357.weight then
			v353 = v357.weight
			v356 = v358
		end
		v354 = v354 + v358 * v357.weight
		v355 = v355 + v357.weight
	end
	if v355 > 0 then
		return v356, v354 / v355
	else
		return v356, v356
	end
end
function v_u_1.contrast(p360, p361, p362) -- name: contrast
	-- upvalues: (copy) v_u_359, (copy) v_u_1
	if type(p362) ~= "table" or #p362 == 0 then
		return (1 / 0)
	end
	local v363, v364 = v_u_359(p362)
	local v365 = v_u_1.lum(p360:Lerp(p361, 0.5))
	local v366 = v_u_1.ratio(v365, v363)
	local v367 = v_u_1.ratio
	return math.min(v366, v367(v365, v364))
end
v_u_1.VIEW_RATIO = 2.6
function v_u_1.background(p368, p369, p370, p371) -- name: background
	-- upvalues: (copy) v_u_1, (copy) v_u_313, (copy) v_u_314
	if type(p371) ~= "number" then
		p371 = v_u_1.MIN_RATIO
	end
	if p371 <= v_u_1.contrast(p368, p369, p370) then
		return p368, p369, false
	end
	local v372 = v_u_313
	if v_u_1.contrast(v_u_314, v_u_314, p370) > v_u_1.contrast(v_u_313, v_u_313, p370) then
		v372 = v_u_314
	end
	for v373 = 1, 10 do
		local v374 = v373 / 10
		local v375 = p368:Lerp(v372, v374)
		local v376 = p369:Lerp(v372, v374)
		if v373 ~= 10 and p371 > v_u_1.contrast(v375, v376, p370) then
			continue
		end
		return v375, v376, true
	end
	return v372, v372, true
end
function v_u_1.new(p377, p378) -- name: new
	-- upvalues: (copy) v_u_1, (ref) v_u_11, (copy) v_u_14, (copy) v_u_2, (copy) v_u_160, (copy) v_u_4, (ref) v_u_6, (copy) v_u_5, (ref) v_u_7, (ref) v_u_8, (copy) v_u_3, (ref) v_u_9
	local v379 = p378 or {}
	local v380 = v379.size
	if typeof(v380) ~= "UDim2" then
		if type(v380) == "number" then
			v380 = UDim2.fromOffset(v380, v380)
		else
			v380 = UDim2.fromOffset(44, 44)
		end
	end
	local v381 = v379.colors
	local v_u_382, v383, v_u_384
	if type(v381) == "table" then
		local v385 = v381[1]
		if typeof(v385) == "Color3" then
			v_u_382 = v381[1]
			if type(v381) == "table" then
				v383 = v381[2]
				if typeof(v383) == "Color3" then
					v_u_384 = v381[2]
				else
					v_u_384 = Color3.fromRGB(28, 31, 38)
				end
			else
				v_u_384 = Color3.fromRGB(28, 31, 38)
			end
		else
			v_u_382 = Color3.fromRGB(40, 44, 52)
			if type(v381) == "table" then
				v383 = v381[2]
				if typeof(v383) == "Color3" then
					v_u_384 = v381[2]
				else
					v_u_384 = Color3.fromRGB(28, 31, 38)
				end
			else
				v_u_384 = Color3.fromRGB(28, 31, 38)
			end
		end
	else
		v_u_382 = Color3.fromRGB(40, 44, 52)
		if type(v381) == "table" then
			v383 = v381[2]
			if typeof(v383) == "Color3" then
				v_u_384 = v381[2]
			else
				v_u_384 = Color3.fromRGB(28, 31, 38)
			end
		else
			v_u_384 = Color3.fromRGB(28, 31, 38)
		end
	end
	local v386 = v379.hidden == true
	local v_u_387 = false
	local v388 = v379.skinId
	local v389
	if type(v388) == "string" then
		v389 = v379.skinId
	else
		v389 = nil
	end
	local v_u_390, v_u_391
	if v386 or not v389 then
		v_u_390 = v_u_384
		v_u_391 = v_u_382
	else
		local v392 = v_u_1.background
		local v393 = v_u_1.finishParts(v389)
		local v394 = v379.minRatio
		local v395
		if type(v394) == "number" then
			v395 = v379.minRatio
		else
			v395 = v_u_1.VIEW_RATIO
		end
		v_u_391, v_u_390, v_u_387 = v392(v_u_382, v_u_384, v393, v395)
	end
	local v_u_396 = Instance.new("Frame")
	v_u_396.Name = v379.name or "Swatch"
	local v397
	if v386 then
		v397 = v_u_390
	else
		v397 = v_u_391
	end
	v_u_396.BackgroundColor3 = v397
	v_u_396.BackgroundTransparency = v379.transparency or 0.08
	v_u_396.BorderSizePixel = 0
	v_u_396.Size = v380
	v_u_396.Position = v379.position or UDim2.new()
	v_u_396.AnchorPoint = v379.anchor or Vector2.zero
	v_u_396.LayoutOrder = v379.order or 0
	v_u_396.ClipsDescendants = true
	local v_u_398
	if v386 then
		v_u_398 = nil
	else
		v_u_398 = Instance.new("UIGradient")
		v_u_398.Color = ColorSequence.new(v_u_391, v_u_390)
		v_u_398.Rotation = 45
		v_u_398.Parent = v_u_396
	end
	local v_u_399 = v379.light == true
	if not v_u_399 then
		local v400 = Instance.new("UIStroke")
		local v401 = v379.line
		local v402
		if typeof(v401) == "Color3" then
			v402 = v379.line
		else
			v402 = Color3.fromRGB(70, 76, 86)
		end
		v400.Color = v402
		v400.Thickness = 1
		v400.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v400.Parent = v_u_396
	end
	local v_u_403 = nil
	local function v409(p404, p405, p406) -- name: setBackground
		-- upvalues: (ref) v_u_391, (ref) v_u_390, (ref) v_u_387, (copy) v_u_396, (ref) v_u_398, (copy) v_u_399, (ref) v_u_403, (copy) v_u_382, (copy) v_u_384
		v_u_391 = p404
		v_u_390 = p405
		v_u_387 = p406
		v_u_396.BackgroundColor3 = v_u_391
		if v_u_398 then
			v_u_398.Color = ColorSequence.new(v_u_391, v_u_390)
		end
		if v_u_399 then
			return
		elseif p406 and v_u_403 == nil then
			local v407 = Instance.new("Frame")
			v407.Name = "FinishEdge"
			v407.BorderSizePixel = 0
			v407.BackgroundColor3 = v_u_382
			v407.AnchorPoint = Vector2.new(0, 1)
			v407.Position = UDim2.new(0, 0, 1, 0)
			v407.Size = UDim2.new(1, 0, 0, 3)
			v407.ZIndex = 4
			local v408 = Instance.new("UIGradient")
			v408.Color = ColorSequence.new(v_u_382, v_u_384)
			v408.Parent = v407
			v407.Parent = v_u_396
			v_u_403 = v407
		elseif not p406 and v_u_403 then
			v_u_403:Destroy()
			v_u_403 = nil
		end
	end
	if v_u_387 then
		local v410 = v_u_382
		local v411 = v_u_384
		local v412 = false
		v409(v_u_391, v_u_390, true)
		v_u_390 = v411
		v_u_391 = v410
		v_u_387 = v412
	end
	local v_u_413 = {
		["frame"] = v_u_396
	}
	local v_u_414 = nil
	local v_u_415 = nil
	local v_u_416 = false
	local v_u_417 = true
	local v_u_418 = nil
	local v_u_419 = nil
	v_u_11 = v_u_11 + 1
	local v420 = nil
	local v421 = v379.wearId
	local v422
	if type(v421) == "string" then
		v422 = v379.wearId
	else
		v422 = nil
	end
	if v422 == nil and not v386 then
		local v423 = v379.skinId
		if type(v423) == "string" then
			local v424 = v_u_14.SWearSkins
			if v424 == nil then
				local v_u_425 = "WearSkins"
				local function v426()
					-- upvalues: (ref) v_u_2, (copy) v_u_425
					return require(v_u_2:WaitForChild(v_u_425, 5))
				end
				local v427
				v427, v424 = pcall(v426)
				if not v427 then
					v424 = false
				end
				v_u_14.SWearSkins = v424
			end
			local v428 = v424 or nil
			if v428 then
				local v429 = v428.isWear
				if type(v429) == "function" and v428.isWear(v379.skinId) then
					v422 = v379.skinId
				end
			end
		end
	end
	local v_u_430 = nil
	if not v386 then
		if v422 == nil then
			local v431 = v379.skinId
			if type(v431) == "string" then
				local v432 = v379.weaponId
				if type(v432) == "string" then
					v_u_430 = v_u_1.icon(v_u_396, v379.skinId, {
						["weaponId"] = nil,
						["name"] = "Weapon",
						["zindex"] = 2,
						["weaponId"] = v379.weaponId
					})
				end
			end
		else
			v_u_430 = v_u_1.icon(v_u_396, v422, {
				["name"] = "Wear",
				["zindex"] = 2
			})
		end
	end
	local v_u_433
	if v_u_430 == nil and (not v386 and v422 ~= nil) then
		local v434 = v_u_14.SkinPreview
		if v434 == nil then
			local v_u_435 = "SkinPreview"
			local v436
			v436, v434 = pcall(function()
				-- upvalues: (copy) v_u_435
				return require(script.Parent:WaitForChild(v_u_435, 5))
			end)
			if not v436 then
				v434 = false
			end
			v_u_14.SkinPreview = v434
		end
		local v437 = v434 or nil
		if v437 then
			local v438 = v437.wearView
			if type(v438) == "function" then
				local v439 = v437.wearView
				local v440 = {
					["size"] = nil,
					["name"] = "Wear",
					["zindex"] = 2,
					["size"] = UDim2.fromScale(1, 1)
				}
				local v441
				v441, v_u_433 = pcall(v439, v_u_396, v422, v440)
				if v441 and type(v_u_433) == "table" then
					local v442 = v_u_433.turn
					local v443 = v_u_1.WEAR_YAW
					pcall(v442, v443)
				else
					v_u_433 = v420
				end
			else
				v_u_433 = v420
			end
		else
			v_u_433 = v420
		end
	else
		v_u_433 = v420
	end
	local v444 = true
	if not v386 then
		local v445 = v379.weaponId
		if type(v445) == "string" then
			local v446 = v_u_14.SItems
			if v446 == nil then
				local v_u_447 = "Items"
				local function v448()
					-- upvalues: (ref) v_u_2, (copy) v_u_447
					return require(v_u_2:WaitForChild(v_u_447, 5))
				end
				local v449
				v449, v446 = pcall(v448)
				if not v449 then
					v446 = false
				end
				v_u_14.SItems = v446
			end
			local v450 = v446 or nil
			if v450 then
				local v451 = v450.get
				if type(v451) == "function" then
					local v452 = v450.get
					local v453 = v379.weaponId
					local v454
					v444, v454 = pcall(v452, v453)
					if v444 then
						v444 = v454 ~= nil
					end
				end
			end
		end
	end
	if v_u_433 ~= nil or v_u_430 ~= nil then
		v444 = false
	end
	if not v386 and v444 then
		local v455 = v379.weaponId
		if type(v455) == "string" then
			local v456 = v_u_14.ItemIcons
			if v456 == nil then
				local v_u_457 = "ItemIcons"
				local v458
				v458, v456 = pcall(function()
					-- upvalues: (copy) v_u_457
					return require(script.Parent:WaitForChild(v_u_457, 5))
				end)
				if not v458 then
					v456 = false
				end
				v_u_14.ItemIcons = v456
			end
			v_u_414 = v456 or nil
			if v_u_414 then
				local v459 = v379.skinId
				local v460
				if type(v459) == "string" then
					v460 = v379.skinId
				else
					v460 = nil
				end
				local v461 = v_u_414.get
				local v462 = v379.weaponId
				local v463 = {
					["parent"] = nil,
					["size"] = nil,
					["name"] = "Weapon",
					["skin"] = nil,
					["zindex"] = 2,
					["parent"] = v_u_396,
					["size"] = UDim2.fromScale(1, 1),
					["skin"] = v460
				}
				local v464, v465 = pcall(v461, v462, false, v463)
				if v464 and typeof(v465) == "Instance" then
					v_u_415 = v465
					if v_u_415:FindFirstChildWhichIsA("Model") == nil then
						local v466 = v_u_415.Destroy
						pcall(v466, v_u_415)
						v_u_415 = nil
						v_u_414 = nil
					end
				end
				if v_u_415 then
					local v467 = v_u_414.turn
					local v468 = v_u_1.YAW
					pcall(v467, v_u_415, v468)
					if v460 then
						local v469 = v_u_1.modelParts(v_u_415:FindFirstChildWhichIsA("Model"))
						if #v469 > 0 then
							local v470 = v_u_1.background
							local v471 = v379.minRatio
							local v472
							if type(v471) == "number" then
								v472 = v379.minRatio
							else
								v472 = v_u_1.VIEW_RATIO
							end
							local v473, v474, v475 = v470(v_u_382, v_u_384, v469, v472)
							v409(v473, v474, v475)
						end
					end
					if v460 and v379.tex ~= false then
						local v476 = v_u_14.SSkinTex
						if v476 == nil then
							local v_u_477 = "SkinTex"
							local function v478()
								-- upvalues: (ref) v_u_2, (copy) v_u_477
								return require(v_u_2:WaitForChild(v_u_477, 5))
							end
							local v479
							v479, v476 = pcall(v478)
							if not v479 then
								v476 = false
							end
							v_u_14.SSkinTex = v476
						end
						local v480 = v476 or nil
						local v481 = v_u_415:FindFirstChildWhichIsA("Model")
						if v480 and v481 then
							if v379.tex == true then
								local v482 = v480.upgrade
								local v483 = {
									["own"] = false,
									["preview"] = true,
									["list"] = nil,
									["list"] = v379.list == true
								}
								local v484
								v_u_416, v484 = pcall(v482, v481, v460, v483)
								if v_u_416 then
									v_u_416 = v484 == true
								end
								local v485 = v480.status
								local v486, v487 = pcall(v485, v460)
								if v486 and v487 == true then
									v_u_418 = v480.watchNew(v460, {
										["opts"] = {
											["own"] = false,
											["preview"] = true,
											["list"] = nil,
											["list"] = v379.list == true
										},
										["upgrade"] = v379.watchUpgrade
									})
								else
									local v488 = v379.watchUpgrade
									if type(v488) == "function" then
										v_u_418 = v480.watchNew(v460, {
											["opts"] = {
												["own"] = false,
												["preview"] = true,
												["list"] = nil,
												["list"] = v379.list == true
											},
											["upgrade"] = v379.watchUpgrade
										})
									end
								end
							else
								v_u_419 = v_u_160(v_u_396, v_u_415, v460, function(p489)
									-- upvalues: (ref) v_u_416
									v_u_416 = p489
								end, v379.watchUpgrade)
							end
						end
					end
				else
					v_u_414 = nil
				end
			end
		end
	end
	function v_u_413.watchTick(p490) -- name: watchTick
		-- upvalues: (ref) v_u_419, (ref) v_u_417, (ref) v_u_418, (ref) v_u_415, (ref) v_u_14, (ref) v_u_2, (ref) v_u_416
		if v_u_419 then
			return v_u_419.watchTick(p490)
		end
		if not (v_u_417 and (v_u_418 and v_u_415)) then
			return nil
		end
		local v491 = v_u_14.SSkinTex
		if v491 == nil then
			local v_u_492 = "SkinTex"
			local function v493()
				-- upvalues: (ref) v_u_2, (copy) v_u_492
				return require(v_u_2:WaitForChild(v_u_492, 5))
			end
			local v494
			v494, v491 = pcall(v493)
			if not v494 then
				v491 = false
			end
			v_u_14.SSkinTex = v491
		end
		local v495 = v491 or nil
		local v496 = v_u_415:FindFirstChildWhichIsA("Model")
		if not (v495 and v496) then
			return nil
		end
		local v497 = v495.watchStep(v_u_418, v496, p490)
		if v497 == "restored" or v497 == "refreshed" then
			v_u_416 = true
		end
		return v497
	end
	function v_u_413.watchState() -- name: watchState
		-- upvalues: (ref) v_u_419, (ref) v_u_418
		if v_u_419 then
			return v_u_419.watch
		else
			return v_u_418
		end
	end
	function v_u_413.lazy() -- name: lazy
		-- upvalues: (ref) v_u_419
		return v_u_419
	end
	function v_u_413.hasIcon() -- name: hasIcon
		-- upvalues: (ref) v_u_415, (ref) v_u_433, (ref) v_u_430
		return (v_u_415 ~= nil or v_u_433 ~= nil) and true or v_u_430 ~= nil
	end
	function v_u_413.icon() -- name: icon
		-- upvalues: (ref) v_u_430
		return v_u_430
	end
	function v_u_413.wear() -- name: wear
		-- upvalues: (ref) v_u_433
		return v_u_433
	end
	function v_u_413.textured() -- name: textured
		-- upvalues: (ref) v_u_416
		return v_u_416
	end
	function v_u_413.lifted() -- name: lifted
		-- upvalues: (ref) v_u_387
		return v_u_387
	end
	function v_u_413.colors() -- name: colors
		-- upvalues: (ref) v_u_391, (ref) v_u_390
		return v_u_391, v_u_390
	end
	function v_u_413.destroy() -- name: destroy
		-- upvalues: (ref) v_u_417, (ref) v_u_11, (ref) v_u_418, (copy) v_u_413, (ref) v_u_4, (ref) v_u_6, (ref) v_u_5, (ref) v_u_419, (ref) v_u_433, (ref) v_u_415, (ref) v_u_14, (ref) v_u_2, (ref) v_u_414, (copy) v_u_396
		if v_u_417 then
			v_u_417 = false
			local v498 = v_u_11 - 1
			v_u_11 = math.max(0, v498)
			v_u_418 = nil
			v_u_4[v_u_413] = nil
			if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
				v_u_6:Disconnect()
				v_u_6 = nil
			end
			if v_u_419 then
				local v499 = v_u_419
				v499.alive = false
				v_u_5[v499] = nil
				v_u_4[v499] = nil
				if v_u_6 and (next(v_u_4) == nil and next(v_u_5) == nil) then
					v_u_6:Disconnect()
					v_u_6 = nil
				end
				v_u_419 = nil
			end
			if v_u_433 then
				local v500 = v_u_433.destroy
				pcall(v500)
				v_u_433 = nil
			end
			if v_u_415 then
				local v501 = v_u_14.SSkinTex
				if v501 == nil then
					local v_u_502 = "SkinTex"
					local function v503()
						-- upvalues: (ref) v_u_2, (copy) v_u_502
						return require(v_u_2:WaitForChild(v_u_502, 5))
					end
					local v504
					v504, v501 = pcall(v503)
					if not v504 then
						v501 = false
					end
					v_u_14.SSkinTex = v501
				end
				local v505 = v501 or nil
				local v506 = v_u_415:FindFirstChildWhichIsA("Model")
				if v505 and v506 then
					local v507 = v505.revert
					pcall(v507, v506)
				end
				if v_u_414 then
					if v506 and v506:GetAttribute("SkinTexDirty") == true then
						local v508 = v_u_415.Destroy
						local v509 = v_u_415
						pcall(v508, v509)
					else
						local v510 = v_u_414.release
						local v511 = v_u_415
						pcall(v510, v511)
					end
				end
				v_u_415 = nil
			end
			local v512 = v_u_396.Destroy
			local v513 = v_u_396
			pcall(v512, v513)
		end
	end
	v_u_396.Destroying:Connect(function()
		-- upvalues: (ref) v_u_417, (copy) v_u_413
		if v_u_417 then
			v_u_413.destroy()
		end
	end)
	if v_u_418 then
		v_u_4[v_u_413] = true
		if v_u_6 == nil then
			v_u_7 = 0
			v_u_8 = 0
			v_u_6 = v_u_3.Heartbeat:Connect(function(p514)
				-- upvalues: (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
				v_u_8 = v_u_8 + p514
				if v_u_8 >= v_u_1.LAZY_EVERY then
					v_u_8 = 0
					local v515 = v_u_1.lazyStep
					local v516 = os.clock
					local v517, v518 = pcall(v515, v516())
					if not (v517 or v_u_9) then
						v_u_9 = true
						warn("[SkinTile] a step of the texture queue failed (the tiles keep the colour look): " .. tostring(v518))
					end
				end
				v_u_7 = v_u_7 + p514
				if v_u_7 >= 1 then
					v_u_7 = 0
					local v519 = os.clock()
					for v520 in v_u_4 do
						local v521 = v520.watchTick
						pcall(v521, v519)
					end
				end
			end)
		end
	end
	if p377 then
		v_u_396.Parent = p377
	end
	return v_u_413
end
return v_u_1