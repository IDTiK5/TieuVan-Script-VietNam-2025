-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTipOnce

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
local v_u_134 = {
	["KEY"] = "menuTipsSeen",
	["LIMIT"] = 200,
	["ID_MAX"] = 24,
	["LIFETIME"] = 9,
	["DELAY"] = 0.5,
	["MARGIN"] = 8,
	["TIPS"] = {
		["lbfac"] = {
			["text"] = "Factions: join a trader\'s team and compete every week."
		},
		["titlechg"] = {
			["text"] = "You have unlocked titles. Change the one under your name here.",
			["titles"] = true
		},
		["bmIntro"] = {
			["text"] = "List items for Cash. Other players buy them. Listings last 3 days."
		},
		["trdrep"] = {
			["text"] = "Hold the level box to see how to earn rep."
		},
		["trdsell"] = {
			["text"] = "Hold SELL to see what can be sold."
		},
		["gunparts"] = {
			["text"] = "Gun parts are for PINS, the Gunsmith. See TRADERS."
		},
		["paidrestrict"] = {
			["text"] = "Roblox limits paid items for your account, so some stay hidden.",
			["restricted"] = true
		},
		["clan"] = {
			["text"] = "Found in raid marks are removed in the clan stash."
		},
		["pvpintro"] = {
			["text"] = "Other squads can shoot you. Clans and the Pass are in the top bar."
		},
		["paidintro"] = {
			["text"] = "Two queues: PAID and FREE. Spending Robux on anything moves you to the PAID QUEUE."
		},
		["raidsetup"] = {
			["text"] = "Change map, difficulty and kit here."
		},
		["menustyle"] = {
			["text"] = "You can switch back to the old menu in SETTINGS.",
			["autoV2"] = true
		},
		["wipe30"] = {
			["text"] = "A stash wipe is coming. The timer is in the menu."
		},
		["wipe14"] = {
			["text"] = "A stash wipe is coming. The timer is in the menu."
		},
		["wipe7"] = {
			["text"] = "A stash wipe is coming. The timer is in the menu."
		},
		["wipe3"] = {
			["text"] = "A stash wipe is coming. The timer is in the menu."
		},
		["wipe1"] = {
			["text"] = "A stash wipe is coming. The timer is in the menu."
		}
	},
	["validId"] = function(p3) -- name: validId
		-- upvalues: (copy) v_u_134
		local v4
		if type(p3) == "string" and (#p3 >= 1 and #p3 <= v_u_134.ID_MAX) then
			v4 = not string.find(p3, "[^%w_]")
		else
			v4 = false
		end
		return v4
	end,
	["parse"] = function(p5) -- name: parse
		local v6 = {}
		if type(p5) ~= "string" then
			return v6
		end
		local v7 = {}
		for v8 in string.gmatch(p5, "[^,]+") do
			if string.find(v8, "[^%w_]") or v7[v8] then
				continue
			end
			v7[v8] = true
			table.insert(v6, v8)
		end
		return v6
	end,
	["has"] = function(p9, p10) -- name: has
		-- upvalues: (copy) v_u_134
		return table.find(v_u_134.parse(p9), p10) ~= nil
	end,
	["merge"] = function(p11, p12) -- name: merge
		-- upvalues: (copy) v_u_134
		local v13 = v_u_134.parse(p11)
		local v14 = {}
		for _, v15 in v13 do
			v14[v15] = true
		end
		local v16 = false
		for _, v17 in type(p12) ~= "table" and { p12 } or p12 do
			if not v_u_134.validId(v17) then
				return nil, "id"
			end
			if v14[v17] then
				continue
			end
			v14[v17] = true
			table.insert(v13, v17)
			v16 = true
		end
		local v18 = table.concat(v13, ",")
		if v16 and #v18 > v_u_134.LIMIT then
			return nil, "limit"
		else
			return v18, nil
		end
	end,
	["titleCount"] = function(p19) -- name: titleCount
		local v20
		if type(p19) == "table" then
			v20 = p19.derived
		else
			v20 = nil
		end
		local v21
		if type(v20) == "table" then
			v21 = v20.titles
		else
			v21 = nil
		end
		if type(v21) ~= "table" then
			return 0
		end
		local v22 = 0
		for _, v23 in v21 do
			local v24
			if type(v23) == "table" then
				v24 = v23.id
			else
				v24 = nil
			end
			if type(v24) ~= "string" or (v24 == "" or string.lower(v24) == "survivor") then
				continue
			end
			v22 = v22 + 1
		end
		return v22
	end,
	["restrictedFrom"] = function(p25, p26) -- name: restrictedFrom
		if p25 == true then
			return p26 ~= true
		else
			return nil
		end
	end,
	["restrictedNow"] = function() -- name: restrictedNow
		-- upvalues: (copy) v_u_134
		local v27 = game:GetService("Players").LocalPlayer
		if v27 then
			return v_u_134.restrictedFrom(v27:GetAttribute("PaidResolved"), v27:GetAttribute("PaidTrading"))
		else
			return nil
		end
	end,
	["decide"] = function(p28, p29, p30, p31) -- name: decide
		-- upvalues: (copy) v_u_134
		if type(p29) == "table" then
			local v32 = p29.settings
			if type(v32) == "table" then
				if p30 and p30[p28] or v_u_134.has(p29.settings[v_u_134.KEY], p28) then
					return "seen"
				end
				local v33 = v_u_134.TIPS[p28]
				if not v33 then
					return "none"
				end
				if v33.titles and v_u_134.titleCount(p29) < 1 then
					return "none"
				end
				if v33.autoV2 then
					local v34 = p29.settings.menuStyle
					if v34 == "v2" or v34 == "classic" then
						return "none"
					end
				end
				if v33.restricted then
					if p31 == nil then
						return "wait"
					end
					if p31 ~= true then
						return "none"
					end
				end
				return "show"
			end
		end
		return "wait"
	end,
	["layout"] = function(p35, p36, p37, p38, p39, p40) -- name: layout
		local v41 = p35.x + p35.w / 2
		local v42 = p35.y + p35.h / 2
		local v43 = p39 or 10
		local v44 = nil
		local v45 = p40 or 14
		for v46, v47 in p38 do
			local v48, v49
			if v47 == "below" or v47 == "above" then
				local v50 = v41 - p36.w / 2
				local v51 = p37.x0
				local v52 = p37.x0
				local v53 = p37.x1 - p36.w
				local v54 = math.max(v52, v53)
				v48 = math.clamp(v50, v51, v54)
				if v47 == "below" then
					v49 = p35.y + p35.h + v43
				else
					v49 = p35.y - v43 - p36.h
				end
			else
				local v55 = v42 - p36.h / 2
				local v56 = p37.y0
				local v57 = p37.y0
				local v58 = p37.y1 - p36.h
				local v59 = math.max(v57, v58)
				v49 = math.clamp(v55, v56, v59)
				if v47 == "right" then
					v48 = p35.x + p35.w + v43
				else
					v48 = p35.x - v43 - p36.w
				end
			end
			local v60 = p37.x0 - v48
			local v61 = math.max(0, v60)
			local v62 = v48 + p36.w - p37.x1
			local v63 = v61 + math.max(0, v62)
			local v64 = p37.y0 - v49
			local v65 = v63 + math.max(0, v64)
			local v66 = v49 + p36.h - p37.y1
			local v67 = v65 + math.max(0, v66)
			local v68
			if v48 < p35.x + p35.w and (v48 + p36.w > p35.x and v49 < p35.y + p35.h) then
				v68 = v49 + p36.h > p35.y
			else
				v68 = false
			end
			local v69 = v67 + (v68 and 1000 or 0) + v46 * 0.001
			if v44 == nil or v69 < v44.score then
				v44 = {
					["side"] = v47,
					["x"] = v48,
					["y"] = v49,
					["score"] = v69
				}
				local v70
				if v67 < 0.5 then
					v70 = not v68
				else
					v70 = false
				end
				v44.fits = v70
			end
			if not v44.fits then
				continue
			end
		end
		local v71 = v44 == nil and {
			["side"] = "below",
			["x"] = nil,
			["y"] = nil,
			["score"] = 0,
			["fits"] = false,
			["x"] = p35.x,
			["y"] = p35.y + p35.h + v43
		} or v44
		if not v71.fits then
			local v72 = v71.x
			local v73 = p37.x0
			local v74 = p37.x0
			local v75 = p37.x1 - p36.w
			local v76 = math.max(v74, v75)
			v71.x = math.clamp(v72, v73, v76)
			local v77 = v71.y
			local v78 = p37.y0
			local v79 = p37.y0
			local v80 = p37.y1 - p36.h
			local v81 = math.max(v79, v80)
			v71.y = math.clamp(v77, v78, v81)
		end
		local v82 = v71.x
		local v83 = v71.y
		local v84 = v71.side
		local v85, v86
		if v84 == "below" then
			local v87 = v82 + v45
			local v88 = v82 + v45
			local v89 = v82 + p36.w - v45
			local v90 = math.max(v88, v89)
			v85 = math.clamp(v41, v87, v90)
			v86 = v83
		elseif v84 == "above" then
			local v91 = v82 + v45
			local v92 = v82 + v45
			local v93 = v82 + p36.w - v45
			local v94 = math.max(v92, v93)
			v85 = math.clamp(v41, v91, v94)
			v86 = v83 + p36.h
		elseif v84 == "right" then
			local v95 = v83 + v45
			local v96 = v83 + v45
			local v97 = v83 + p36.h - v45
			local v98 = math.max(v96, v97)
			v86 = math.clamp(v42, v95, v98)
			v85 = v82
		else
			v85 = v82 + p36.w
			local v99 = v83 + v45
			local v100 = v83 + v45
			local v101 = v83 + p36.h - v45
			local v102 = math.max(v100, v101)
			v86 = math.clamp(v42, v99, v102)
		end
		return {
			["side"] = v84,
			["x"] = v82,
			["y"] = v83,
			["ax"] = v85,
			["ay"] = v86,
			["fits"] = v71.fits
		}
	end,
	["frame"] = function(p103, p104, p105, p106, p107, p108, p109) -- name: frame
		-- upvalues: (copy) v_u_134
		local v110 = math.max(p109, 0.01)
		local v111 = p103.AbsolutePosition.X
		local v112 = p103.AbsolutePosition.Y
		local v113 = p103.AbsoluteSize.X / v110
		local v114 = p103.AbsoluteSize.Y / v110
		local v115 = p104.AbsolutePosition
		local v116 = p104.AbsoluteSize
		if v113 < 40 or (v114 < 40 or (v116.X < 1 or v116.Y < 1)) then
			return nil
		end
		local v117 = v_u_134.MARGIN
		local v118 = {
			["x0"] = v117,
			["y0"] = v117,
			["x1"] = v113 - v117,
			["y1"] = v114 - v117
		}
		if p106.confine then
			local v119 = p106.confine
			local v120, v_u_121 = pcall(v119)
			local v122, v123 = pcall(function()
				-- upvalues: (copy) v_u_121
				return v_u_121.AbsoluteSize.X
			end)
			if v120 and (v_u_121 ~= nil and (v122 and v123 > 1)) then
				local v124 = (v_u_121.AbsolutePosition.X - v111) / v110
				local v125 = v118.x0
				v118.x0 = math.max(v125, v124)
				local v126 = v118.x1
				local v127 = v124 + v123 / v110 - v117
				v118.x1 = math.min(v126, v127)
			end
		end
		local v128 = v118.x1 - v118.x0
		local v129 = math.max(120, v128)
		local v130 = math.min(p107, v129)
		local v131 = math.floor(v130)
		local v132 = {
			["x"] = (v115.X - v111) / v110,
			["y"] = (v115.Y - v112) / v110,
			["w"] = v116.X / v110,
			["h"] = v116.Y / v110
		}
		local v133
		if p105.Y / v110 >= 1 then
			v133 = v_u_134.layout(v132, {
				["w"] = p105.X / v110,
				["h"] = p105.Y / v110
			}, v118, p108, 10, 14)
		else
			v133 = nil
		end
		return {
			["w"] = v131,
			["t"] = v132,
			["L"] = v133,
			["bounds"] = v118
		}
	end
}
local v_u_135 = {
	["mc"] = nil,
	["conn"] = nil,
	["cmds"] = false,
	["order"] = nil,
	["written"] = nil,
	["dismissed"] = nil,
	["active"] = nil,
	["live"] = nil,
	["inflight"] = nil,
	["failNext"] = 0,
	["sent"] = 0,
	["hold"] = false,
	["noTitles"] = false,
	["nconn"] = 0,
	["order"] = {},
	["written"] = {},
	["dismissed"] = {},
	["active"] = {},
	["live"] = {},
	["inflight"] = {}
}
local function v_u_139(p136) -- name: viewOf
	-- upvalues: (copy) v_u_135
	local v137 = p136.profile
	if not v_u_135.noTitles or type(v137) ~= "table" then
		return v137
	end
	local v138 = table.clone(v137)
	v138.derived = {
		["titles"] = {}
	}
	return v138
end
local v_u_140 = nil
v_u_140 = function(p_u_141, p142, p_u_143)
	-- upvalues: (copy) v_u_135, (copy) v_u_134, (ref) v_u_140
	local v144 = v_u_135
	v144.sent = v144.sent + 1
	if v_u_135.failNext > 0 then
		local v145 = v_u_135
		v145.failNext = v145.failNext - 1
		task.delay(0.2, function()
			-- upvalues: (copy) p_u_141, (copy) p_u_143, (ref) v_u_134, (ref) v_u_135, (ref) v_u_140
			local v146 = p_u_141
			local v147 = p_u_143 + 1
			if v147 <= 2 then
				if v146 == nil then
					return
				end
				local v148 = v_u_134.merge
				local v149 = v146.profile
				local v150
				if type(v149) == "table" then
					local v151 = v149.settings
					if type(v151) == "table" then
						v150 = v149.settings[v_u_134.KEY]
					else
						v150 = nil
					end
				else
					v150 = nil
				end
				local v152 = v148(type(v150) ~= "string" and "" or v150, v_u_135.order)
				if v152 then
					v_u_140(v146, v152, v147)
				end
			end
		end)
	else
		local v_u_153 = p_u_141.op({
			["op"] = "setting",
			["key"] = nil,
			["value"] = nil,
			["key"] = v_u_134.KEY,
			["value"] = p142
		})
		v_u_135.inflight[v_u_153] = p_u_143
		task.delay(8, function()
			-- upvalues: (ref) v_u_135, (copy) v_u_153, (copy) p_u_141, (copy) p_u_143, (ref) v_u_134, (ref) v_u_140
			if v_u_135.inflight[v_u_153] ~= nil then
				v_u_135.inflight[v_u_153] = nil
				local v154 = p_u_141
				local v155 = p_u_143 + 1
				if v155 <= 2 then
					if v154 == nil then
						return
					end
					local v156 = v_u_134.merge
					local v157 = v154.profile
					local v158
					if type(v157) == "table" then
						local v159 = v157.settings
						if type(v159) == "table" then
							v158 = v157.settings[v_u_134.KEY]
						else
							v158 = nil
						end
					else
						v158 = nil
					end
					local v160 = v156(type(v158) ~= "string" and "" or v158, v_u_135.order)
					if v160 then
						v_u_140(v154, v160, v155)
					end
				end
			end
		end)
	end
end
local function v_u_171(p161, p162) -- name: onChanged
	-- upvalues: (copy) v_u_135, (copy) v_u_134, (ref) v_u_140
	if p161 == "result" and (type(p162) == "table" and p162.op == "setting") then
		local v163 = v_u_135.inflight[p162.req]
		if v163 ~= nil then
			v_u_135.inflight[p162.req] = nil
			if p162.ok == false then
				local v164 = v_u_135.mc
				local v165 = v163 + 1
				if v165 <= 2 then
					if v164 == nil then
						return
					end
					local v166 = v_u_134.merge
					local v167 = v164.profile
					local v168
					if type(v167) == "table" then
						local v169 = v167.settings
						if type(v169) == "table" then
							v168 = v167.settings[v_u_134.KEY]
						else
							v168 = nil
						end
					else
						v168 = nil
					end
					local v170 = v166(type(v168) ~= "string" and "" or v168, v_u_135.order)
					if v170 then
						v_u_140(v164, v170, v165)
					end
				end
			end
		end
	else
		return
	end
end
local function v_u_180(p172, p173) -- name: persist
	-- upvalues: (copy) v_u_135, (copy) v_u_134, (ref) v_u_140
	local v174 = p172.profile
	if type(v174) == "table" then
		local v175 = v174.settings
		if type(v175) == "table" then
			local v176 = table.clone(v_u_135.order)
			table.insert(v176, p173)
			local v177, v178 = v_u_134.merge(v174.settings[v_u_134.KEY], v176)
			if v177 == nil then
				warn("[MenuTipOnce] tip " .. p173 .. " not saved (" .. tostring(v178) .. ")")
				return false
			end
			if not v_u_135.written[p173] then
				v_u_135.written[p173] = true
				local v179 = v_u_135.order
				table.insert(v179, p173)
			end
			v174.settings[v_u_134.KEY] = v177
			v_u_140(p172, v177, 1)
			return true
		end
	end
	return false
end
local function v_u_183(p181, p182) -- name: visibleIn
	while p181 and p181 ~= p182 do
		if p181:IsA("GuiObject") and not p181.Visible then
			return false
		end
		p181 = p181.Parent
	end
	return p181 == p182
end
local function v_u_189(p184, p185) -- name: scaleOf
	local v186 = p184.Parent
	while v186 do
		local v187 = v186:FindFirstChildOfClass("UIScale")
		if v187 then
			local v188 = v187.Scale
			return math.max(v188, 0.01)
		end
		v186 = v186.Parent
	end
	return math.max(p185, 0.01)
end
local function v_u_191(p_u_190) -- name: quiet
	pcall(function()
		-- upvalues: (copy) p_u_190
		p_u_190.Interactable = false
	end)
	pcall(function()
		-- upvalues: (copy) p_u_190
		p_u_190.Selectable = false
	end)
end
local function v_u_272(p_u_192, p_u_193, p_u_194, p_u_195, p_u_196) -- name: showCard
	-- upvalues: (copy) v_u_134, (copy) v_u_191, (copy) v_u_183, (copy) v_u_135, (copy) v_u_189, (copy) v_u_2, (copy) v_u_1
	local v197 = p_u_192.ui
	local v_u_198 = p_u_192.theme
	local v199 = v_u_198.color
	local v_u_200 = p_u_195.host
	local v201 = v_u_134.TIPS[p_u_193]
	local v202 = p_u_192.compact()
	local v203 = p_u_195.sides
	local v_u_204 = type(v203) ~= "table" and {
		"below",
		"above",
		"left",
		"right"
	} or p_u_195.sides
	local v_u_205 = {}
	local v_u_206 = true
	local v_u_207 = nil
	local v_u_208 = nil
	local v_u_209 = os.clock()
	local v210 = p_u_195.width
	local v_u_211
	if type(v210) == "number" then
		local v212 = p_u_195.width
		v_u_211 = math.floor(v212)
	else
		v_u_211 = v202 and 250 or 264
	end
	local v_u_213 = v197.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 50,
		["Active"] = false,
		["Name"] = "MenuTip_" .. p_u_193,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_200)
	v_u_213:SetAttribute("MenuTip", p_u_193)
	local v_u_214 = v197.new("Frame", {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 51,
		["Active"] = false,
		["Visible"] = false
	}, v_u_213)
	local v_u_215 = v197.stroke(v_u_214, v199.accent)
	v_u_215.Thickness = 2
	local v_u_216 = v197.new("Frame", {
		["Name"] = "Card",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 52,
		["Active"] = false,
		["BackgroundColor3"] = v199.bg,
		["Size"] = UDim2.fromOffset(v_u_211, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_213)
	v197.stroke(v_u_216, v199.accent)
	v197.pad(v_u_216, {
		14,
		14,
		10,
		11
	})
	v197.layout(v_u_216, "v", 4)
	local v_u_217 = v197.new("Frame", {
		["Name"] = "Arrow",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 51,
		["Active"] = false,
		["BackgroundColor3"] = v199.accent,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(10, 10)
	}, v_u_213)
	if p_u_195.slim ~= true then
		v197.label({
			["parent"] = nil,
			["name"] = "Kicker",
			["text"] = "Tip",
			["style"] = "caps",
			["color"] = nil,
			["order"] = 1,
			["size"] = nil,
			["parent"] = v_u_216,
			["color"] = v199.accent,
			["size"] = UDim2.new(1, 0, 0, 16)
		})
	end
	v197.label({
		["parent"] = nil,
		["name"] = "Body",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["textSize"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 2,
		["maxSize"] = nil,
		["parent"] = v_u_216,
		["text"] = v201.text,
		["color"] = v199.text,
		["textSize"] = v202 and 14 or 13,
		["maxSize"] = Vector2.new(4000, 96)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	for _, v218 in v_u_213:GetDescendants() do
		if not v218:IsA("GuiObject") then
			continue
		end
		local v219 = v218.ZIndex
		v218.ZIndex = math.max(v219, 53)
		v_u_191(v218)
	end
	v_u_214.ZIndex = 51
	v_u_217.ZIndex = 51
	v_u_216.ZIndex = 52
	v_u_191(v_u_213)
	local function v_u_224() -- name: stop
		-- upvalues: (ref) v_u_206, (copy) v_u_205, (ref) v_u_135, (ref) v_u_208, (copy) p_u_193, (copy) p_u_194, (copy) v_u_213
		v_u_206 = false
		for _, v_u_220 in v_u_205 do
			pcall(function()
				-- upvalues: (copy) v_u_220
				v_u_220:Disconnect()
			end)
		end
		local v221 = v_u_135
		v221.nconn = v221.nconn - #v_u_205
		table.clear(v_u_205)
		if v_u_208 then
			local function v222()
				-- upvalues: (ref) v_u_208
				v_u_208:Disconnect()
			end
			pcall(v222)
			v_u_208 = nil
			local v223 = v_u_135
			v223.nconn = v223.nconn - 1
		end
		if v_u_135.live[p_u_193] == p_u_194 then
			v_u_135.live[p_u_193] = nil
		end
		v_u_213:Destroy()
		p_u_194.state = "gone"
	end
	function p_u_194.dismiss(_) -- name: dismiss
		-- upvalues: (ref) v_u_206, (ref) v_u_135, (copy) p_u_193, (copy) v_u_224
		if v_u_206 then
			v_u_135.dismissed[p_u_193] = true
			v_u_135.active[p_u_193] = nil
			v_u_224()
		end
	end
	function p_u_194.detach() -- name: detach
		-- upvalues: (ref) v_u_206, (copy) v_u_224
		if v_u_206 then
			v_u_224()
		end
	end
	function p_u_194.card() -- name: card
		-- upvalues: (ref) v_u_206, (copy) v_u_216
		if v_u_206 then
			return v_u_216
		else
			return nil
		end
	end
	p_u_194.state = "shown"
	p_u_194.target = p_u_195.target
	local function v_u_254() -- name: place
		-- upvalues: (copy) p_u_195, (ref) v_u_183, (copy) v_u_200, (copy) v_u_213, (ref) v_u_207, (ref) v_u_208, (ref) v_u_135, (copy) p_u_194, (ref) v_u_134, (copy) v_u_216, (copy) v_u_211, (copy) v_u_204, (ref) v_u_189, (copy) v_u_198, (copy) v_u_217, (copy) v_u_214
		local v225 = p_u_195.target
		local v226, v227 = pcall(v225)
		if not v226 or (typeof(v227) ~= "Instance" or not (v227:IsA("GuiObject") and v_u_183(v227, v_u_200))) then
			v227 = nil
		end
		if v227 == nil then
			v_u_213.Visible = false
			return
		else
			if v227 ~= v_u_207 then
				v_u_207 = v227
				if v_u_208 then
					local function v228()
						-- upvalues: (ref) v_u_208
						v_u_208:Disconnect()
					end
					pcall(v228)
					v_u_208 = nil
					local v229 = v_u_135
					v229.nconn = v229.nconn - 1
				end
				if v227:IsA("GuiButton") then
					v_u_208 = v227.Activated:Connect(function()
						-- upvalues: (ref) p_u_194
						p_u_194.dismiss("activated")
					end)
					local v230 = v_u_135
					v230.nconn = v230.nconn + 1
				end
			end
			local v231 = v_u_134.frame(v_u_200, v227, v_u_216.AbsoluteSize, p_u_195, v_u_211, v_u_204, (v_u_189(v_u_200, v_u_198.uiScale())))
			if v231 == nil then
				v_u_213.Visible = false
				return
			else
				if v_u_216.Size.X.Offset ~= v231.w then
					v_u_216.Size = UDim2.fromOffset(v231.w, 0)
				end
				local v232 = v231.L
				local v233 = v231.t
				if v232 ~= nil then
					local v234 = v_u_216
					local v235 = UDim2.fromOffset
					local v236 = v232.x + 0.5
					local v237 = math.floor(v236)
					local v238 = v232.y + 0.5
					v234.Position = v235(v237, (math.floor(v238)))
					local v239 = v_u_217
					local v240 = UDim2.fromOffset
					local v241 = v232.ax + 0.5
					local v242 = math.floor(v241)
					local v243 = v232.ay + 0.5
					v239.Position = v240(v242, (math.floor(v243)))
					local v244 = v_u_214
					local v245 = UDim2.fromOffset
					local v246 = v233.x - 2 + 0.5
					local v247 = math.floor(v246)
					local v248 = v233.y - 2 + 0.5
					v244.Position = v245(v247, (math.floor(v248)))
					local v249 = v_u_214
					local v250 = UDim2.fromOffset
					local v251 = v233.w + 4
					local v252 = math.ceil(v251)
					local v253 = v233.h + 4
					v249.Size = v250(v252, (math.ceil(v253)))
					v_u_213:SetAttribute("Side", v232.side)
					v_u_214.Visible = true
					v_u_213.Visible = true
				end
			end
		end
	end
	local v255, v256 = pcall(function()
		-- upvalues: (copy) p_u_192
		return p_u_192.cctx.lib.VirtualPad
	end)
	local v257
	if v255 and (type(v256) == "table" and v256.InputBegan) then
		v257 = v256.InputBegan
	else
		v257 = v_u_2.InputBegan
	end
	table.insert(v_u_205, v257:Connect(function(p258)
		-- upvalues: (copy) v_u_209, (copy) p_u_194
		if os.clock() - v_u_209 < 0.3 then
			return
		else
			local v259 = p258.UserInputType
			if v259 == Enum.UserInputType.MouseButton1 or (v259 == Enum.UserInputType.MouseButton2 or v259 == Enum.UserInputType.Touch) then
				p_u_194.dismiss("pressed")
			elseif p258.KeyCode == Enum.KeyCode.ButtonA or p258.KeyCode == Enum.KeyCode.ButtonB then
				p_u_194.dismiss("pressed")
			end
		end
	end))
	local v260 = v_u_135
	v260.nconn = v260.nconn + 1
	local v_u_261 = os.clock()
	local v262 = v_u_1.Heartbeat
	local function v268()
		-- upvalues: (ref) v_u_206, (copy) v_u_213, (copy) p_u_194, (copy) p_u_196, (ref) v_u_135, (copy) p_u_195, (copy) v_u_254, (copy) v_u_215, (copy) v_u_261
		if v_u_206 then
			if v_u_213:IsDescendantOf(game) then
				if p_u_196 <= os.clock() and not v_u_135.hold then
					p_u_194.dismiss("timeout")
					return
				else
					local v263 = p_u_195.active
					local v264, v265 = pcall(v263)
					if v264 and v265 == true then
						v_u_254()
						local v266 = v_u_215
						local v267 = (os.clock() - v_u_261) * 4
						v266.Transparency = (math.sin(v267) * 0.5 + 0.5) * 0.35 + 0.15
					else
						p_u_194.dismiss("left")
					end
				end
			else
				p_u_194.detach()
				return
			end
		else
			return
		end
	end
	table.insert(v_u_205, v262:Connect(v268))
	local v269 = v_u_135
	v269.nconn = v269.nconn + 1
	v_u_254()
	local v270 = v197.fade
	pcall(v270, v_u_216, 0, "normal", {
		["from"] = 1
	})
	local v271 = v197.fade
	pcall(v271, v_u_217, 0, "normal", {
		["from"] = 1
	})
end
local function v_u_282(p_u_273, p274, p275) -- name: targetReady
	-- upvalues: (copy) v_u_183
	local v276 = p275.target
	local v277, v278 = pcall(v276)
	if not v277 or (typeof(v278) ~= "Instance" or not (v278:IsA("GuiObject") and v_u_183(v278, p274))) then
		return false
	end
	if v278.AbsoluteSize.X < 1 or v278.AbsoluteSize.Y < 1 then
		return false
	end
	local v279 = p_u_273.cctx
	if v279 then
		v279 = p_u_273.cctx.player
	end
	if v279 and v279:GetAttribute("MenuTour") ~= nil then
		return false
	end
	local v280, v281 = pcall(function()
		-- upvalues: (copy) p_u_273
		return p_u_273.ui.modalCount()
	end)
	if v280 then
		if type(v281) == "number" then
			v280 = v281 > 0
		else
			v280 = false
		end
	end
	return not v280
end
local v_u_283 = nil
local function v_u_288(p284) -- name: bind
	-- upvalues: (copy) v_u_135, (copy) v_u_171, (ref) v_u_283
	if v_u_135.mc ~= p284 then
		if v_u_135.conn then
			local function v285()
				-- upvalues: (ref) v_u_135
				v_u_135.conn:Disconnect()
			end
			pcall(v285)
			v_u_135.conn = nil
		end
		v_u_135.mc = p284
		local v286 = p284.changed
		if type(v286) == "table" then
			local v287 = p284.changed.Connect
			if type(v287) == "function" then
				v_u_135.conn = p284.changed:Connect(v_u_171)
			end
		end
		v_u_283(p284)
	end
end
local function v_u_298(p289, p290, p291, p292, p293) -- name: safeShow
	-- upvalues: (copy) v_u_272, (copy) v_u_135
	local v294 = v_u_272
	local v295, v296 = pcall(v294, p289, p290, p291, p292, p293)
	if not v295 then
		warn("[MenuTipOnce] card failed:", v296)
		local v297 = p292.host:FindFirstChild("MenuTip_" .. p290)
		if v297 then
			v297:Destroy()
		end
		p291.state = "gone"
		v_u_135.active[p290] = nil
		v_u_135.dismissed[p290] = true
		if v_u_135.live[p290] == p291 then
			v_u_135.live[p290] = nil
		end
	end
end
function v_u_134.show(p_u_299, p_u_300, p_u_301) -- name: show
	-- upvalues: (copy) v_u_134, (copy) v_u_288, (copy) v_u_135, (copy) v_u_298, (copy) v_u_139, (copy) v_u_282, (copy) v_u_180
	if type(p_u_299) == "table" and type(p_u_301) == "table" then
		local v302 = p_u_301.host
		if typeof(v302) == "Instance" then
			local v303 = p_u_301.target
			if type(v303) == "function" then
				local v304 = p_u_301.active
				if type(v304) == "function" then
					if v_u_134.TIPS[p_u_300] then
						v_u_288(p_u_299)
						if v_u_135.dismissed[p_u_300] then
							return nil
						else
							local v305 = v_u_135.live[p_u_300]
							if v305 and (v305.state ~= "gone" and v305.host == p_u_301.host) then
								return v305
							else
								if v305 then
									v305.detach()
								end
								local v306 = v_u_135.active[p_u_300]
								local v_u_307 = {
									["id"] = nil,
									["host"] = nil,
									["state"] = "pending",
									["id"] = p_u_300,
									["host"] = p_u_301.host,
									["alive"] = function() -- name: alive
										-- upvalues: (copy) v_u_307
										return v_u_307.state == "pending" and true or v_u_307.state == "shown"
									end,
									["shown"] = function() -- name: shown
										-- upvalues: (copy) v_u_307
										return v_u_307.state == "shown"
									end,
									["card"] = function() -- name: card
										return nil
									end,
									["dismiss"] = function(_) -- name: dismiss
										-- upvalues: (copy) v_u_307, (ref) v_u_135, (copy) p_u_300
										if v_u_307.state == "pending" then
											v_u_307.state = "gone"
											if v_u_135.live[p_u_300] == v_u_307 then
												v_u_135.live[p_u_300] = nil
											end
										end
									end,
									["detach"] = function() -- name: detach
										-- upvalues: (copy) v_u_307, (ref) v_u_135, (copy) p_u_300
										if v_u_307.state == "pending" then
											v_u_307.state = "gone"
											if v_u_135.live[p_u_300] == v_u_307 then
												v_u_135.live[p_u_300] = nil
											end
										end
									end
								}
								if v306 == nil then
									local v308 = v_u_134.decide(p_u_300, v_u_139(p_u_299), v_u_135.written, v_u_134.restrictedNow())
									if v308 == "seen" or v308 == "none" then
										return nil
									end
									v_u_135.live[p_u_300] = v_u_307
									local v_u_309 = os.clock()
									task.spawn(function()
										-- upvalues: (copy) v_u_307, (copy) p_u_301, (copy) v_u_309, (ref) v_u_135, (copy) p_u_300, (ref) v_u_134, (ref) v_u_139, (copy) p_u_299, (ref) v_u_282, (ref) v_u_180, (ref) v_u_298
										if v_u_307.state == "pending" then
											task.wait(0.1)
											if v_u_307.state == "pending" then
												local v310 = p_u_301.active
												local v311, v312 = pcall(v310)
												if v311 and (v312 == true and os.clock() - v_u_309 <= 120) then
													local v313 = v_u_134.decide(p_u_300, v_u_139(p_u_299), v_u_135.written, v_u_134.restrictedNow())
													if v313 == "seen" or v313 == "none" then
														if v_u_307.state == "pending" then
															v_u_307.state = "gone"
															if v_u_135.live[p_u_300] == v_u_307 then
																v_u_135.live[p_u_300] = nil
															end
														end
														return
													else
														if v313 ~= "show" or (os.clock() - v_u_309 < v_u_134.DELAY or not v_u_282(p_u_299, p_u_301.host, p_u_301)) then
															continue
														end
														if v_u_180(p_u_299, p_u_300) then
															local v314 = os.clock() + v_u_134.LIFETIME
															v_u_135.active[p_u_300] = v314
															v_u_298(p_u_299, p_u_300, v_u_307, p_u_301, v314)
														elseif v_u_307.state == "pending" then
															v_u_307.state = "gone"
															if v_u_135.live[p_u_300] == v_u_307 then
																v_u_135.live[p_u_300] = nil
															end
														end
													end
												else
													if v_u_307.state == "pending" then
														v_u_307.state = "gone"
														if v_u_135.live[p_u_300] == v_u_307 then
															v_u_135.live[p_u_300] = nil
														end
													end
													return
												end
											else
												return
											end
										else
											return
										end
									end)
									return v_u_307
								elseif v306 <= os.clock() and not v_u_135.hold then
									v_u_135.active[p_u_300] = nil
									v_u_135.dismissed[p_u_300] = true
									return nil
								else
									v_u_135.live[p_u_300] = v_u_307
									v_u_298(p_u_299, p_u_300, v_u_307, p_u_301, v306)
									return v_u_307
								end
							end
						end
					else
						return nil
					end
				end
			end
		end
	end
	return nil
end
function v_u_134.markSeen(p315, p316) -- name: markSeen
	-- upvalues: (copy) v_u_134, (copy) v_u_288, (copy) v_u_139, (copy) v_u_135, (copy) v_u_180
	if type(p315) == "table" and v_u_134.TIPS[p316] then
		v_u_288(p315)
		local v317 = v_u_134.decide(p316, v_u_139(p315), v_u_135.written, v_u_134.restrictedNow())
		if v317 ~= "none" then
			if v317 == "show" then
				v_u_180(p315, p316)
			end
			v_u_135.dismissed[p316] = true
			v_u_135.active[p316] = nil
			local v318 = v_u_135.live[p316]
			if v318 then
				v318.dismiss("used")
			end
		end
	else
		return
	end
end
local function v_u_401(p319) -- name: stateText
	-- upvalues: (copy) v_u_135, (copy) v_u_134
	local v320 = {}
	local v321 = {}
	local v322 = "-"
	for v323, v324 in v_u_135.live do
		if v324.state == "shown" then
			v322 = v323
		else
			if v324.state ~= "pending" then
				continue
			end
			table.insert(v320, v323)
		end
	end
	for v325 in v_u_135.dismissed do
		table.insert(v321, v325)
	end
	table.sort(v321)
	table.sort(v320)
	local v326 = p319.cctx.player:FindFirstChildOfClass("PlayerGui")
	if v326 then
		v326 = v326:FindFirstChild("HushMenu")
	end
	local v327 = {}
	if v326 then
		for _, v328 in v326:GetDescendants() do
			if not v328:IsA("Frame") then
				continue
			end
			local v329 = v328.Name
			if string.sub(v329, 1, 8) ~= "MenuTip_" then
				continue
			end
			table.insert(v327, v328)
		end
	end
	local v330 = 0
	for _ in v_u_135.inflight do
		v330 = v330 + 1
	end
	local v331 = "stored=%s session=%s dismissed=%s shown=%s pending=%s callouts=%d conns=%d inflight=%d sent=%d hold=%s"
	local v332 = p319.profile
	local v333
	if type(v332) == "table" then
		local v334 = v332.settings
		if type(v334) == "table" then
			v333 = v332.settings[v_u_134.KEY]
		else
			v333 = nil
		end
	else
		v333 = nil
	end
	local v335
	if (type(v333) ~= "string" and "" or v333) == "" then
		v335 = "-"
	else
		local v336 = p319.profile
		local v337
		if type(v336) == "table" then
			local v338 = v336.settings
			if type(v338) == "table" then
				v337 = v336.settings[v_u_134.KEY]
			else
				v337 = nil
			end
		else
			v337 = nil
		end
		v335 = type(v337) ~= "string" and "" or v337
	end
	local v339 = #v_u_135.order == 0 and "-" or table.concat(v_u_135.order, ",")
	local v340 = #v321 == 0 and "-" or table.concat(v321, ",")
	local v341 = #v320 == 0 and "-" or table.concat(v320, ",")
	local v342 = #v327
	local v343 = v_u_135.nconn
	local v344 = v_u_135.sent
	local v345 = v_u_135.hold
	local v346 = v331:format(v335, v339, v340, v322, v341, v342, v343, v330, v344, (tostring(v345)))
	local v347 = v_u_135.live[v322]
	local v348 = v327[1]
	if v347 and (v348 and v347.state == "shown") then
		local v349 = v348:FindFirstChild("Card")
		local v350 = v348:FindFirstChild("Arrow")
		local v351 = v348:FindFirstChild("Ring")
		local v352
		if v349 then
			v352 = v349:FindFirstChild("Body")
		else
			v352 = nil
		end
		local v353 = v347.target
		local v354, v355 = pcall(v353)
		local v356 = p319.theme.viewport()
		local v357 = " visible=%s side=%s card=%s arrow=%s ring=%s viewport=%dx%d"
		local v358 = v348.Visible
		local v359 = tostring(v358)
		local v360 = tostring(v348:GetAttribute("Side"))
		local v361
		if v349 then
			local v362 = v349.AbsolutePosition.X + 0.5
			local v363 = math.floor(v362)
			local v364 = v349.AbsolutePosition.Y + 0.5
			local v365 = math.floor(v364)
			local v366 = v349.AbsoluteSize.X + 0.5
			local v367 = math.floor(v366)
			local v368 = v349.AbsoluteSize.Y + 0.5
			v361 = ("%d,%d,%d,%d"):format(v363, v365, v367, (math.floor(v368)))
		else
			v361 = "-"
		end
		local v369
		if v350 then
			local v370 = v350.AbsolutePosition.X + 0.5
			local v371 = math.floor(v370)
			local v372 = v350.AbsolutePosition.Y + 0.5
			local v373 = math.floor(v372)
			local v374 = v350.AbsoluteSize.X + 0.5
			local v375 = math.floor(v374)
			local v376 = v350.AbsoluteSize.Y + 0.5
			v369 = ("%d,%d,%d,%d"):format(v371, v373, v375, (math.floor(v376)))
		else
			v369 = "-"
		end
		local v377
		if v351 then
			local v378 = v351.AbsolutePosition.X + 0.5
			local v379 = math.floor(v378)
			local v380 = v351.AbsolutePosition.Y + 0.5
			local v381 = math.floor(v380)
			local v382 = v351.AbsoluteSize.X + 0.5
			local v383 = math.floor(v382)
			local v384 = v351.AbsoluteSize.Y + 0.5
			v377 = ("%d,%d,%d,%d"):format(v379, v381, v383, (math.floor(v384)))
		else
			v377 = "-"
		end
		v346 = v346 .. v357:format(v359, v360, v361, v369, v377, v356.X, v356.Y)
		if v349 then
			local v385 = v349.AbsolutePosition
			local v386 = v349.AbsoluteSize
			local v387
			if v385.X >= 0 and (v385.Y >= 0 and v385.X + v386.X <= v356.X + 0.5) then
				v387 = v385.Y + v386.Y <= v356.Y + 0.5
			else
				v387 = false
			end
			v346 = v346 .. (" onscreen=%s text=%q"):format(tostring(v387), not v352 and "-" or v352.Text)
			if v352 then
				local v388 = " textfits=%s"
				local v389
				if v352.TextBounds.Y <= v352.AbsoluteSize.Y + 1 then
					v389 = v352.TextBounds.X <= v352.AbsoluteSize.X + 1
				else
					v389 = false
				end
				v346 = v346 .. v388:format((tostring(v389)))
			end
			if v354 and (typeof(v355) == "Instance" and v355:IsA("GuiObject")) then
				local v390 = v355.AbsolutePosition
				local v391 = v355.AbsoluteSize
				local v392
				if v385.X < v390.X + v391.X and (v385.X + v386.X > v390.X and v385.Y < v390.Y + v391.Y) then
					v392 = v385.Y + v386.Y > v390.Y
				else
					v392 = false
				end
				local v393 = string.gsub(v355:GetFullName(), "^.-PlayerGui%.", "")
				local v394 = v355.AbsolutePosition.X + 0.5
				local v395 = math.floor(v394)
				local v396 = v355.AbsolutePosition.Y + 0.5
				local v397 = math.floor(v396)
				local v398 = v355.AbsoluteSize.X + 0.5
				local v399 = math.floor(v398)
				local v400 = v355.AbsoluteSize.Y + 0.5
				v346 = v346 .. (" target=%s targetrect=%s overlap=%s"):format(v393, ("%d,%d,%d,%d"):format(v395, v397, v399, (math.floor(v400))), (tostring(v392)))
			end
		end
	end
	return v346
end
v_u_283 = function(p402)
	-- upvalues: (copy) v_u_135, (copy) v_u_1, (copy) v_u_401, (copy) v_u_134
	if not v_u_135.cmds and v_u_1:IsStudio() then
		local v403 = p402.cctx
		if type(v403) == "table" then
			local v404 = p402.cctx.command
			if type(v404) == "function" then
				v_u_135.cmds = true
				p402.cctx.command("menutip.state", function()
					-- upvalues: (ref) v_u_401, (ref) v_u_135
					return v_u_401(v_u_135.mc)
				end)
				p402.cctx.command("menutip.reset", function()
					-- upvalues: (ref) v_u_135, (ref) v_u_134
					local v405 = v_u_135.mc
					for _, v406 in table.clone(v_u_135.live) do
						v406.detach()
					end
					table.clear(v_u_135.order)
					table.clear(v_u_135.written)
					table.clear(v_u_135.dismissed)
					table.clear(v_u_135.active)
					table.clear(v_u_135.inflight)
					v_u_135.failNext = 0
					v_u_135.hold = false
					v_u_135.noTitles = false
					local v407 = v405.profile
					if type(v407) == "table" then
						local v408 = v407.settings
						if type(v408) == "table" then
							v407.settings[v_u_134.KEY] = nil
						end
					end
					v405.op({
						["op"] = "setting",
						["key"] = nil,
						["key"] = v_u_134.KEY
					})
					return "menuTipsSeen cleared"
				end)
				p402.cctx.command("menutip.fail", function(p409)
					-- upvalues: (ref) v_u_135
					local v410 = v_u_135
					local v411 = p409[1]
					local v412 = tonumber(v411) or 1
					local v413 = math.floor(v412)
					v410.failNext = math.clamp(v413, 0, 5)
					return "next " .. v_u_135.failNext .. " writes fail"
				end)
				p402.cctx.command("menutip.hold", function(p414)
					-- upvalues: (ref) v_u_135
					v_u_135.hold = p414[1] ~= "off"
					local v415 = v_u_135.hold
					return "hold " .. tostring(v415)
				end)
				p402.cctx.command("menutip.notitles", function(p416)
					-- upvalues: (ref) v_u_135
					v_u_135.noTitles = p416[1] ~= "off"
					local v417 = v_u_135.noTitles
					return "notitles " .. tostring(v417)
				end)
				return
			end
		end
	end
end
return v_u_134