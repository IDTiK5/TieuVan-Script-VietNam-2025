-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / FilmMode

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = {
	["name"] = "FilmMode",
	["order"] = 95
}
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = 0
local v_u_15 = nil
local v_u_16 = false
local v_u_17 = false
local v_u_18 = false
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = false
local v_u_23 = nil
local v_u_24 = false
local v_u_25 = 0
local v_u_26 = nil
function v_u_6.call(p27, p28, p29) -- name: call
	-- upvalues: (copy) v_u_5, (ref) v_u_24, (copy) v_u_7
	local v30 = v_u_5:FindFirstChild("HushNet")
	local v_u_31 = v30
	if v_u_31 then
		v_u_31 = v30:FindFirstChild("film.cmd")
	end
	if not (v_u_31 and v_u_31:IsA("RemoteFunction")) then
		v_u_31 = nil
	end
	if not v_u_31 then
		if not v_u_24 then
			v_u_24 = true
			warn("[FilmMode] remote film.cmd missing (server film system not running)")
		end
		return {
			["ok"] = false,
			["msg"] = "Server film system not available."
		}
	end
	local v_u_32 = table.clone(p28 or {})
	v_u_32.op = p27
	if not p29 then
		v_u_7:SetAttribute("FilmLastOp", p27)
	end
	local v_u_33 = false
	local v_u_34 = false
	local v_u_35 = nil
	task.spawn(function()
		-- upvalues: (ref) v_u_34, (ref) v_u_35, (copy) v_u_31, (copy) v_u_32, (ref) v_u_33
		local function v36()
			-- upvalues: (ref) v_u_31, (ref) v_u_32
			return v_u_31:InvokeServer(v_u_32)
		end
		local v37, v38 = pcall(v36)
		v_u_34 = v37
		v_u_35 = v38
		v_u_33 = true
	end)
	local v39 = os.clock()
	local v40 = v_u_35
	local v41 = v_u_34
	while not v_u_33 and os.clock() - v39 < 45 do
		task.wait(0.05)
	end
	return not v_u_33 and {
		["ok"] = false,
		["msg"] = nil,
		["msg"] = "No answer from the server (" .. p27 .. ")."
	} or (not v41 and {
		["ok"] = false,
		["msg"] = nil,
		["msg"] = "Request failed: " .. tostring(v40)
	} or (type(v40) ~= "table" and {
		["ok"] = false,
		["msg"] = "No answer."
	} or v40))
end
local function v_u_50(p_u_42, p_u_43, p_u_44) -- name: callAsync
	-- upvalues: (ref) v_u_15, (copy) v_u_7, (copy) v_u_6
	local v45 = p_u_42 .. " ..."
	if v_u_15 then
		v_u_15.status(v45, nil)
	else
		v_u_7:SetAttribute("FilmStatus", v45)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_42, (copy) p_u_43, (ref) v_u_15, (ref) v_u_7, (copy) p_u_44
		local v46 = v_u_6.call(p_u_42, p_u_43)
		local v47 = v46.msg
		if not v47 then
			if v46.ok then
				v47 = p_u_42 .. " done."
			else
				v47 = p_u_42 .. " failed."
			end
		end
		local v48 = tostring(v47)
		local v49 = v46.ok and "success" or "danger"
		if v_u_15 then
			v_u_15.status(v48, v49)
		else
			v_u_7:SetAttribute("FilmStatus", v48)
		end
		if p_u_44 then
			p_u_44(v46)
		end
	end)
end
local function v_u_58(p51) -- name: setGameInput
	-- upvalues: (ref) v_u_8, (ref) v_u_17, (ref) v_u_18
	local v_u_52 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
	if v_u_52 and v_u_52.setEnabled then
		if p51 then
			if v_u_17 then
				v_u_17 = false
				if not v_u_18 then
					local v53 = v_u_52.setEnabled
					pcall(v53, true)
				end
			end
		else
			if not v_u_17 then
				local v55, v56 = pcall(function()
					-- upvalues: (copy) v_u_52
					local v54 = v_u_52.gameBlocked
					if v54 then
						v54 = v_u_52.gameBlocked()
					end
					return v54
				end)
				if v55 then
					v55 = v56 == true
				end
				v_u_18 = v55
				v_u_17 = true
			end
			local v57 = v_u_52.setEnabled
			pcall(v57, false)
		end
	else
		return
	end
end
local function v_u_62(p59) -- name: renderOverride
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_20
	local v60, v61 = v_u_9.render(p59)
	if v60 then
		v_u_10.update(v60, v_u_20)
	end
	return v60, v61
end
function v_u_6.setCamMode(p63) -- name: setCamMode
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (copy) v_u_62, (ref) v_u_22, (ref) v_u_11, (copy) v_u_3, (copy) v_u_58, (ref) v_u_16, (ref) v_u_19, (ref) v_u_15
	v_u_9.setMode(p63)
	local v64 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Camera) or nil
	if v64 and v64.setOverride then
		local v65 = v64.setOverride
		local v66
		if v_u_9.mode() == "game" then
			v66 = nil
		else
			v66 = v_u_62
		end
		v65(v66)
	end
	if v_u_9.mode() ~= "free" and v_u_22 then
		v_u_22 = false
		v_u_11.release(v_u_3, "MouseBehavior")
	end
	local v67 = v_u_58
	local v68 = v_u_16
	if v68 then
		v68 = v_u_9.mode() == "free" and true or v_u_19 ~= nil
	end
	v67(not v68)
	if v_u_15 then
		v_u_15.sync()
	end
end
function v_u_6.applyPreset(p69) -- name: applyPreset
	-- upvalues: (copy) v_u_7, (ref) v_u_23, (ref) v_u_9, (copy) v_u_6, (ref) v_u_15
	if v_u_7:GetAttribute("Place") == "Raid" and v_u_7.Character then
		v_u_23 = nil
		local v70 = v_u_9.applyPreset(p69)
		if v70 then
			v_u_6.setCamMode(v_u_9.mode())
			local v71 = "Camera preset " .. tostring(v70) .. "."
			if v_u_15 then
				v_u_15.status(v71, "success")
				return
			end
			v_u_7:SetAttribute("FilmStatus", v71)
		end
	else
		v_u_23 = p69
	end
end
local function v_u_74(p72) -- name: setPoint
	-- upvalues: (ref) v_u_20, (ref) v_u_9, (ref) v_u_21, (ref) v_u_15
	v_u_20 = p72
	v_u_9.setPoint(p72)
	if v_u_21 then
		v_u_21:Destroy()
		v_u_21 = nil
	end
	if p72 then
		local v73 = Instance.new("SphereHandleAdornment")
		v73.Name = "FilmPoint"
		v73.Radius = 0.6
		v73.Color3 = Color3.fromRGB(232, 163, 61)
		v73.Transparency = 0.2
		v73.AlwaysOnTop = true
		v73.ZIndex = 5
		v73.Adornee = workspace.Terrain
		v73.CFrame = CFrame.new(p72)
		v73.Parent = workspace.Terrain
		v_u_21 = v73
	end
	if v_u_15 then
		v_u_15.sync()
	end
end
local function v_u_83() -- name: worldPointUnderMouse
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	local v75 = workspace.CurrentCamera
	if v75 then
		local v76 = v_u_3:GetMouseLocation()
		local v77 = v75:ViewportPointToRay(v76.X, v76.Y)
		local v78 = RaycastParams.new()
		v78.FilterType = Enum.RaycastFilterType.Exclude
		local v79 = {}
		if v_u_7.Character then
			local v80 = v_u_7.Character
			table.insert(v79, v80)
		end
		local v81 = workspace:FindFirstChild("HushLocal")
		if v81 then
			table.insert(v79, v81)
		end
		v78.FilterDescendantsInstances = v79
		local v82 = workspace:Raycast(v77.Origin, v77.Direction * 2000, v78)
		if v82 then
			return v82.Position
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_90(p84) -- name: pick
	-- upvalues: (ref) v_u_19, (ref) v_u_8, (ref) v_u_17, (ref) v_u_18
	v_u_19 = p84
	local v_u_85 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
	if v_u_85 then
		if not v_u_85.setEnabled then
			return
		end
		if not v_u_17 then
			local v87, v88 = pcall(function()
				-- upvalues: (copy) v_u_85
				local v86 = v_u_85.gameBlocked
				if v86 then
					v86 = v_u_85.gameBlocked()
				end
				return v86
			end)
			if v87 then
				v87 = v88 == true
			end
			v_u_18 = v87
			v_u_17 = true
		end
		local v89 = v_u_85.setEnabled
		pcall(v89, false)
	end
end
function v_u_6.photoClear() -- name: photoClear
	-- upvalues: (ref) v_u_14, (ref) v_u_13, (ref) v_u_10, (ref) v_u_15
	v_u_14 = v_u_14 + 1
	if v_u_13 and v_u_13.active() then
		v_u_13.clear()
		v_u_10.setDof("off")
		v_u_10.setTarget(nil)
		if v_u_15 then
			v_u_15.sync()
		end
	end
end
function v_u_6.photoCamera() -- name: photoCamera
	-- upvalues: (ref) v_u_13, (copy) v_u_6, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15
	local v91 = v_u_13
	if v91 then
		v91 = v_u_13.cameraOf()
	end
	if not v91 then
		return false
	end
	v_u_6.setCamMode("free")
	v_u_9.placeFree(v91.cf, v91.fov, v91.roll)
	if v91.dof and v91.focus then
		v_u_10.setTarget(v91.focus)
		v_u_10.setDof("target", v91.dof)
	end
	v_u_10.setGuideFrame(v91.frame, v91.thirds, v91.logo)
	if v_u_15 then
		v_u_15.sync()
	end
	return true
end
function v_u_6.photoLoaded(p_u_92) -- name: photoLoaded
	-- upvalues: (ref) v_u_14, (ref) v_u_8, (ref) v_u_15, (copy) v_u_7, (ref) v_u_16, (ref) v_u_13, (copy) v_u_6
	if type(p_u_92) == "table" then
		local v93 = p_u_92.anchor
		if typeof(v93) == "Vector3" then
			v_u_14 = v_u_14 + 1
			local v_u_94 = v_u_14
			local v_u_95 = v_u_8.shared.FilmScenes.get(p_u_92.scene)
			if v_u_95 then
				local v96 = p_u_92.look
				local v97 = (typeof(v96) ~= "Vector3" or p_u_92.look.Magnitude <= 0.1) and Vector3.new(0, 0, -1) or p_u_92.look
				local v98 = CFrame.lookAt
				local v99 = p_u_92.anchor
				local v100 = p_u_92.anchor
				local v101 = v97.X
				local v102 = v97.Z
				local v_u_103 = v98(v99, v100 + Vector3.new(v101, 0, v102))
				task.spawn(function()
					-- upvalues: (copy) v_u_94, (ref) v_u_14, (ref) v_u_16, (ref) v_u_7, (copy) p_u_92, (ref) v_u_15, (ref) v_u_13, (copy) v_u_95, (copy) v_u_103, (ref) v_u_6
					local v104 = os.clock()
					while os.clock() - v104 < 30 do
						if v_u_94 ~= v_u_14 or not v_u_16 then
							return
						end
						local v105 = v_u_7.Character
						if v105 then
							v105 = v105:FindFirstChild("HumanoidRootPart")
						end
						if v_u_7:GetAttribute("Place") == "Raid" and (v105 and (v105:IsA("BasePart") and (v105.Position - p_u_92.anchor).Magnitude < 80)) then
							break
						end
						task.wait(0.2)
					end
					task.wait(1.2)
					if v_u_94 == v_u_14 and v_u_16 then
						if v_u_15 then
							v_u_15.status("Building photo scene ...", nil)
						else
							v_u_7:SetAttribute("FilmStatus", "Building photo scene ...")
						end
						local v106, v107 = v_u_13.build(v_u_95, v_u_103)
						if v_u_94 == v_u_14 then
							if v106 then
								v_u_6.photoCamera()
							end
							local v108 = tostring(v107)
							local v109 = v106 and "success" or "danger"
							if v_u_15 then
								v_u_15.status(v108, v109)
							else
								v_u_7:SetAttribute("FilmStatus", v108)
							end
						else
							return
						end
					else
						return
					end
				end)
				return
			else
				local v110 = p_u_92.scene
				local v111 = "Unknown photo scene " .. tostring(v110)
				if v_u_15 then
					v_u_15.status(v111, "danger")
				else
					v_u_7:SetAttribute("FilmStatus", v111)
				end
			end
		end
	end
end
function v_u_6.toggleClean(p112) -- name: toggleClean
	-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_15, (copy) v_u_7
	if p112 == nil then
		p112 = not v_u_11.isClean()
	end
	if p112 and not v_u_16 then
		return
	else
		v_u_11.setClean(p112)
		local v113 = p112 and "Clean frame on (Ctrl+F8 to leave)." or "Clean frame off."
		if v_u_15 then
			v_u_15.status(v113, nil)
		else
			v_u_7:SetAttribute("FilmStatus", v113)
		end
	end
end
local function v_u_123() -- name: buildPanel
	-- upvalues: (ref) v_u_15, (copy) v_u_50, (copy) v_u_6, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_90, (ref) v_u_20, (copy) v_u_74, (ref) v_u_13, (ref) v_u_12, (copy) v_u_7
	if v_u_15 and (v_u_15.gui and v_u_15.gui.Parent) then
		return
	else
		local v119 = {
			["call"] = v_u_50,
			["callQuiet"] = function(p_u_114, p_u_115, p_u_116) -- name: callQuiet
				-- upvalues: (ref) v_u_6
				task.spawn(function()
					-- upvalues: (copy) p_u_116, (ref) v_u_6, (copy) p_u_114, (copy) p_u_115
					p_u_116(v_u_6.call(p_u_114, p_u_115, true))
				end)
			end,
			["cam"] = v_u_9,
			["look"] = v_u_10,
			["clean"] = v_u_11,
			["setCamMode"] = v_u_6.setCamMode,
			["applyPreset"] = v_u_6.applyPreset,
			["toggleClean"] = function() -- name: toggleClean
				-- upvalues: (ref) v_u_6
				v_u_6.toggleClean()
			end,
			["close"] = function() -- name: close
				-- upvalues: (ref) v_u_6
				v_u_6.close()
			end,
			["pick"] = v_u_90,
			["point"] = function() -- name: point
				-- upvalues: (ref) v_u_20
				return v_u_20
			end,
			["setPoint"] = v_u_74,
			["setCharHidden"] = function(p117) -- name: setCharHidden
				-- upvalues: (ref) v_u_11
				v_u_11.setCharacterHidden(p117)
			end,
			["charHidden"] = function() -- name: charHidden
				-- upvalues: (ref) v_u_11
				return v_u_11.isCharacterHidden()
			end,
			["sceneLoaded"] = function(p118) -- name: sceneLoaded
				-- upvalues: (ref) v_u_6
				if type(p118) == "table" and p118.kind == "photo" then
					v_u_6.photoLoaded(p118)
				else
					v_u_6.photoClear()
				end
			end,
			["photo"] = v_u_13,
			["photoCamera"] = v_u_6.photoCamera,
			["photoClear"] = v_u_6.photoClear
		}
		local v120 = v_u_12.build
		local v121, v122 = pcall(v120, v119)
		if v121 then
			v_u_15 = v122
			v_u_15.setVisible(false)
		else
			warn("[FilmMode] panel build failed:", v122)
			v_u_7:SetAttribute("ClientError", "FilmPanel: " .. tostring(v122))
		end
	end
end
function v_u_6.open() -- name: open
	-- upvalues: (copy) v_u_7, (ref) v_u_8, (copy) v_u_123, (ref) v_u_16, (ref) v_u_15
	if v_u_7:GetAttribute("FilmAllowed") == true then
		local v124 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		local v125, v126, v127, v128
		if v124 and v124.device then
			local v129 = v124.device
			local v130
			v130, v125 = pcall(v129)
			if v130 and type(v125) == "string" then
				if v125 == "Keyboard" then
					v_u_123()
					v_u_16 = true
					v_u_7:SetAttribute("FilmOpen", true)
					if v_u_15 then
						v_u_15.setVisible(true)
						if v_u_15.refreshScenes and not v_u_15._scenesLoaded then
							v_u_15._scenesLoaded = true
							v_u_15.refreshScenes()
						end
						if v_u_15.refreshLandmarks and v_u_7:GetAttribute("Place") == "Raid" then
							v_u_15.refreshLandmarks()
						end
					end
					v126 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Audio) or nil
					if v126 and v126.ui then
						v127 = v126.ui
						pcall(v127, "open")
					end
					return
				end
			else
				v128 = v_u_7:GetAttribute("InputDevice")
				v125 = type(v128) ~= "string" and "Keyboard" or v128
				if v125 == "Keyboard" then
					v_u_123()
					v_u_16 = true
					v_u_7:SetAttribute("FilmOpen", true)
					if v_u_15 then
						v_u_15.setVisible(true)
						if v_u_15.refreshScenes and not v_u_15._scenesLoaded then
							v_u_15._scenesLoaded = true
							v_u_15.refreshScenes()
						end
						if v_u_15.refreshLandmarks and v_u_7:GetAttribute("Place") == "Raid" then
							v_u_15.refreshLandmarks()
						end
					end
					v126 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Audio) or nil
					if v126 and v126.ui then
						v127 = v126.ui
						pcall(v127, "open")
					end
					return
				end
			end
		else
			v128 = v_u_7:GetAttribute("InputDevice")
			v125 = type(v128) ~= "string" and "Keyboard" or v128
			if v125 == "Keyboard" then
				v_u_123()
				v_u_16 = true
				v_u_7:SetAttribute("FilmOpen", true)
				if v_u_15 then
					v_u_15.setVisible(true)
					if v_u_15.refreshScenes and not v_u_15._scenesLoaded then
						v_u_15._scenesLoaded = true
						v_u_15.refreshScenes()
					end
					if v_u_15.refreshLandmarks and v_u_7:GetAttribute("Place") == "Raid" then
						v_u_15.refreshLandmarks()
					end
				end
				v126 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Audio) or nil
				if v126 and v126.ui then
					v127 = v126.ui
					pcall(v127, "open")
				end
				return
			end
		end
	end
end
function v_u_6.close() -- name: close
	-- upvalues: (ref) v_u_16, (copy) v_u_7, (ref) v_u_19, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_22, (copy) v_u_3, (copy) v_u_6, (ref) v_u_10, (ref) v_u_15, (ref) v_u_20, (ref) v_u_21, (ref) v_u_17, (ref) v_u_18
	if v_u_16 then
		v_u_16 = false
		v_u_7:SetAttribute("FilmOpen", false)
		v_u_19 = nil
		v_u_11.setClean(false)
		v_u_9.reset()
		local v131 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Camera) or nil
		if v131 and v131.setOverride then
			v131.setOverride(nil)
		end
		if v_u_22 then
			v_u_22 = false
			v_u_11.release(v_u_3, "MouseBehavior")
		end
		v_u_6.photoClear()
		v_u_10.clear()
		if v_u_15 and v_u_15.resetGuides then
			v_u_15.resetGuides()
		end
		v_u_11.setCharacterHidden(false)
		v_u_20 = nil
		v_u_9.setPoint(nil)
		if v_u_21 then
			v_u_21:Destroy()
			v_u_21 = nil
		end
		if v_u_15 then
			v_u_15.sync()
		end
		local v132 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		if v132 and (v132.setEnabled and v_u_17) then
			v_u_17 = false
			if not v_u_18 then
				local v133 = v132.setEnabled
				pcall(v133, true)
			end
		end
		if v_u_15 then
			v_u_15.setVisible(false)
		end
		local v134 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Audio) or nil
		if v134 and v134.ui then
			local v135 = v134.ui
			pcall(v135, "close")
		end
	end
end
function v_u_6.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_16
	return v_u_16
end
local function v_u_139() -- name: leaveFree
	-- upvalues: (ref) v_u_16, (ref) v_u_9, (copy) v_u_6, (ref) v_u_15, (copy) v_u_7, (ref) v_u_19, (copy) v_u_58
	if v_u_16 and v_u_9.mode() == "free" then
		v_u_6.setCamMode("game")
		if v_u_15 then
			v_u_15.status("Game camera.", nil)
		else
			v_u_7:SetAttribute("FilmStatus", "Game camera.")
		end
	end
	if v_u_19 then
		local v136 = v_u_19
		v_u_19 = nil
		local v137 = v_u_58
		local v138 = v_u_16
		if v138 then
			v138 = v_u_9.mode() == "free" and true or v_u_19 ~= nil
		end
		v137(not v138)
		task.spawn(v136, nil)
	end
end
local function v_u_154(p140, p141) -- name: onInputBegan
	-- upvalues: (copy) v_u_139, (copy) v_u_7, (ref) v_u_8, (copy) v_u_3, (copy) v_u_6, (ref) v_u_16, (ref) v_u_11, (copy) v_u_2, (ref) v_u_19, (copy) v_u_83, (copy) v_u_58, (ref) v_u_9, (ref) v_u_15, (ref) v_u_22
	if p140.UserInputType ~= Enum.UserInputType.Keyboard then
		if v_u_16 then
			if p140.UserInputType == Enum.UserInputType.MouseButton1 and (v_u_19 and not p141) then
				local v142 = v_u_19
				v_u_19 = nil
				local v143 = v_u_83()
				local v144 = v_u_58
				local v145 = v_u_16
				if v145 then
					v145 = v_u_9.mode() == "free" and true or v_u_19 ~= nil
				end
				v144(not v145)
				local v146 = not v143 and "Nothing hit." or "Point " .. string.format("%.0f, %.0f, %.0f", v143.X, v143.Y, v143.Z) .. "."
				local v147 = v143 and "success" or "danger"
				if v_u_15 then
					v_u_15.status(v146, v147)
				else
					v_u_7:SetAttribute("FilmStatus", v146)
				end
				task.spawn(v142, v143)
			elseif p140.UserInputType == Enum.UserInputType.MouseButton2 and (not p141 and v_u_9.mode() == "free") then
				v_u_22 = true
				v_u_11.force(v_u_3, "MouseBehavior", Enum.MouseBehavior.LockCurrentPosition)
			end
		else
			return
		end
	end
	local v148 = p140.KeyCode
	if v148 == Enum.KeyCode.Escape then
		v_u_139()
		return
	end
	if not p141 and v_u_7:GetAttribute("FilmAllowed") == true then
		local v149 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		local v150, v151
		if v149 and v149.device then
			local v152 = v149.device
			local v153
			v153, v150 = pcall(v152)
			if v153 and type(v150) == "string" then
				if v150 == "Keyboard" then
					if v148 == Enum.KeyCode.F8 then
						if v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl) then
							v_u_6.toggleClean()
							return
						elseif v_u_16 then
							if v_u_11.isClean() then
								v_u_6.toggleClean(false)
							else
								v_u_6.close()
							end
						else
							v_u_6.open()
							return
						end
					else
						if v_u_2:IsStudio() and ((v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl)) and (v_u_3:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_3:IsKeyDown(Enum.KeyCode.RightShift))) then
							if v148 == Enum.KeyCode.F then
								if v_u_16 then
									v_u_6.close()
								else
									v_u_6.open()
								end
							end
							if v148 == Enum.KeyCode.G then
								v_u_6.toggleClean()
							end
						end
						return
					end
				end
			else
				v151 = v_u_7:GetAttribute("InputDevice")
				v150 = type(v151) ~= "string" and "Keyboard" or v151
				if v150 == "Keyboard" then
					if v148 == Enum.KeyCode.F8 then
						if v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl) then
							v_u_6.toggleClean()
							return
						elseif v_u_16 then
							if v_u_11.isClean() then
								v_u_6.toggleClean(false)
							else
								v_u_6.close()
							end
						else
							v_u_6.open()
							return
						end
					else
						if v_u_2:IsStudio() and ((v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl)) and (v_u_3:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_3:IsKeyDown(Enum.KeyCode.RightShift))) then
							if v148 == Enum.KeyCode.F then
								if v_u_16 then
									v_u_6.close()
								else
									v_u_6.open()
								end
							end
							if v148 == Enum.KeyCode.G then
								v_u_6.toggleClean()
							end
						end
						return
					end
				end
			end
		else
			v151 = v_u_7:GetAttribute("InputDevice")
			v150 = type(v151) ~= "string" and "Keyboard" or v151
			if v150 == "Keyboard" then
				if v148 == Enum.KeyCode.F8 then
					if v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl) then
						v_u_6.toggleClean()
						return
					elseif v_u_16 then
						if v_u_11.isClean() then
							v_u_6.toggleClean(false)
						else
							v_u_6.close()
						end
					else
						v_u_6.open()
						return
					end
				else
					if v_u_2:IsStudio() and ((v_u_3:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_3:IsKeyDown(Enum.KeyCode.RightControl)) and (v_u_3:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_3:IsKeyDown(Enum.KeyCode.RightShift))) then
						if v148 == Enum.KeyCode.F then
							if v_u_16 then
								v_u_6.close()
							else
								v_u_6.open()
							end
						end
						if v148 == Enum.KeyCode.G then
							v_u_6.toggleClean()
						end
					end
					return
				end
			end
		end
	end
end
local function v_u_159(p155, p156) -- name: onInputChanged
	-- upvalues: (ref) v_u_16, (ref) v_u_26, (ref) v_u_22, (ref) v_u_9
	if v_u_16 then
		if p155.UserInputType == Enum.UserInputType.MouseMovement then
			local v157 = p155.Delta
			if v157.Magnitude == 0 and v_u_26 then
				v157 = p155.Position - v_u_26
			end
			v_u_26 = p155.Position
			if v_u_22 then
				v_u_9.look(v157.X, v157.Y)
				return
			end
		elseif p155.UserInputType == Enum.UserInputType.MouseWheel and not p156 then
			local v158 = v_u_9.mode()
			if v158 == "free" or v158 == "orbit" then
				v_u_9.wheel(p155.Position.Z)
			end
		end
	end
end
local function v_u_161(p160, _) -- name: onInputEnded
	-- upvalues: (ref) v_u_22, (ref) v_u_11, (copy) v_u_3
	if p160.UserInputType == Enum.UserInputType.MouseButton2 and v_u_22 then
		v_u_22 = false
		v_u_11.release(v_u_3, "MouseBehavior")
	end
end
local function v_u_175(p162, p163) -- name: parseArgs
	local v164 = {}
	for v165 = p163, #p162 do
		local v166, v167 = string.match(p162[v165], "^([%w_]+)=(.+)$")
		if not (v166 and v167) then
			continue
		end
		local v168 = tonumber(v167)
		if v167 == "true" then
			v164[v166] = true
		elseif v167 == "false" then
			v164[v166] = false
		elseif v168 then
			v164[v166] = v168
		elseif string.match(v167, "^[-%d.]+,[-%d.]+,[-%d.]+$") then
			local v169, v170, v171 = string.match(v167, "^([-%d.]+),([-%d.]+),([-%d.]+)$")
			local v172 = tonumber(v169) or 0
			local v173 = tonumber(v170) or 0
			local v174 = tonumber(v171) or 0
			v164[v166] = Vector3.new(v172, v173, v174)
		else
			v164[v166] = v167
		end
	end
	return v164
end
local function v_u_184(p176, p177) -- name: brief
	-- upvalues: (copy) v_u_184
	local v178 = p177 or 0
	if type(p176) ~= "table" then
		return tostring(p176)
	end
	if v178 > 2 then
		return "{...}"
	end
	local v179 = 0
	local v180 = {}
	for v181, v182 in p176 do
		v179 = v179 + 1
		if v179 > 12 then
			table.insert(v180, "...")
			break
		end
		local v183 = tostring(v181) .. "=" .. v_u_184(v182, v178 + 1)
		table.insert(v180, v183)
	end
	return "{" .. table.concat(v180, ", ") .. "}"
end
function v_u_6.init(p185) -- name: init
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_7, (copy) v_u_6, (ref) v_u_16, (ref) v_u_23, (ref) v_u_15, (copy) v_u_74, (ref) v_u_20, (copy) v_u_175, (copy) v_u_184, (ref) v_u_17, (copy) v_u_5
	v_u_8 = p185
	v_u_9 = p185.lib.FilmCam
	v_u_10 = p185.lib.FilmLook
	v_u_11 = p185.lib.FilmClean
	v_u_12 = p185.lib.FilmPanel
	v_u_13 = p185.lib.FilmPhoto
	v_u_13.setup(p185)
	v_u_7:SetAttribute("FilmOpen", false)
	p185.command("film.open", function()
		-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_16
		local v186, v187, v188
		if v_u_7:GetAttribute("FilmAllowed") ~= true then
			v_u_6.open()
			v186 = v_u_16
			v187 = tostring(v186)
			v188 = v_u_7:GetAttribute("FilmAllowed") == true
			return "open " .. v187 .. " allowed " .. tostring(v188)
		end
		local v189 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		if not (v189 and v189.device) then
			v193 = v_u_7:GetAttribute("InputDevice")
			v192 = type(v193) ~= "string" and "Keyboard" or v193
			if v192 == "Keyboard" then
				v_u_6.open()
				v186 = v_u_16
				v187 = tostring(v186)
				v188 = v_u_7:GetAttribute("FilmAllowed") == true
				return "open " .. v187 .. " allowed " .. tostring(v188)
			end
			v194 = "refused (device "
			v195 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
			if not (v195 and v195.device) then
				v199 = v_u_7:GetAttribute("InputDevice")
				v198 = type(v199) ~= "string" and "Keyboard" or v199
				return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
			end
			v196 = v195.device
			v197, v198 = pcall(v196)
			if v197 and type(v198) == "string" then
				return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
			end
			v199 = v_u_7:GetAttribute("InputDevice")
			v198 = type(v199) ~= "string" and "Keyboard" or v199
			return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
		end
		local v190 = v189.device
		local v191, v192 = pcall(v190)
		if v191 and type(v192) == "string" then
			if v192 == "Keyboard" then
				v_u_6.open()
				v186 = v_u_16
				v187 = tostring(v186)
				v188 = v_u_7:GetAttribute("FilmAllowed") == true
				return "open " .. v187 .. " allowed " .. tostring(v188)
			end
			v194 = "refused (device "
			v195 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
			if not (v195 and v195.device) then
				v199 = v_u_7:GetAttribute("InputDevice")
				v198 = type(v199) ~= "string" and "Keyboard" or v199
				return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
			end
			v196 = v195.device
			v197, v198 = pcall(v196)
			if v197 and type(v198) == "string" then
				return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
			end
			v199 = v_u_7:GetAttribute("InputDevice")
			v198 = type(v199) ~= "string" and "Keyboard" or v199
			return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
		end
		local v193 = v_u_7:GetAttribute("InputDevice")
		v192 = type(v193) ~= "string" and "Keyboard" or v193
		if v192 == "Keyboard" then
			v_u_6.open()
			v186 = v_u_16
			v187 = tostring(v186)
			v188 = v_u_7:GetAttribute("FilmAllowed") == true
			return "open " .. v187 .. " allowed " .. tostring(v188)
		end
		local v194 = "refused (device "
		local v195 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		if not (v195 and v195.device) then
			v199 = v_u_7:GetAttribute("InputDevice")
			v198 = type(v199) ~= "string" and "Keyboard" or v199
			return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
		end
		local v196 = v195.device
		local v197, v198 = pcall(v196)
		if v197 and type(v198) == "string" then
			return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
		end
		local v199 = v_u_7:GetAttribute("InputDevice")
		v198 = type(v199) ~= "string" and "Keyboard" or v199
		return v194 .. v198 .. ", the panel is for mouse and keyboard only) open false allowed true"
	end)
	p185.command("film.close", function()
		-- upvalues: (ref) v_u_6
		v_u_6.close()
		return "closed"
	end)
	p185.command("film.clean", function(p200)
		-- upvalues: (ref) v_u_6, (ref) v_u_11
		local v201 = p200[1]
		local v202 = v_u_6.toggleClean
		local v203
		if v201 == "on" then
			v203 = true
		elseif v201 == "off" then
			v203 = false
		else
			v203 = nil
		end
		v202(v203)
		local v204 = v_u_11.stats()
		local v205 = v204.clean
		return "clean " .. tostring(v205) .. " objects " .. v204.cleanObjects .. " forced " .. v204.forced
	end)
	p185.command("film.cam", function(p206)
		-- upvalues: (ref) v_u_6, (ref) v_u_9
		v_u_6.setCamMode(p206[1] or "game")
		return "cam " .. v_u_9.mode()
	end)
	p185.command("film.preset", function(p207)
		-- upvalues: (ref) v_u_6, (ref) v_u_9, (ref) v_u_23
		v_u_6.applyPreset(p207[1] or "shoulder")
		local v208 = v_u_9.mode()
		local v209 = v_u_9.get
		local v210 = v_u_23
		return "cam " .. v208 .. " follow " .. tostring(v209("follow")) .. " pending " .. tostring(v210)
	end)
	p185.command("film.set", function(p211)
		-- upvalues: (ref) v_u_9, (ref) v_u_15
		local v212 = p211[1]
		local v213 = p211[2]
		if not v212 then
			return "usage: film.set <key> [value]"
		end
		if v213 == nil then
			local v214 = v_u_9.get
			return v212 .. "=" .. tostring(v214(v212))
		end
		local v215 = v_u_9.set
		local v216 = tonumber(v213)
		if v216 then
			v213 = v216
		elseif v213 == "true" then
			v213 = true
		elseif v213 == "false" then
			v213 = false
		end
		v215(v212, v213)
		if v_u_15 then
			v_u_15.sync()
		end
		local v217 = v_u_9.get
		return v212 .. "=" .. tostring(v217(v212))
	end)
	p185.command("film.point", function(p218)
		-- upvalues: (ref) v_u_74, (ref) v_u_20
		local v219 = p218[1]
		local v220 = tonumber(v219)
		local v221 = p218[2]
		local v222 = tonumber(v221)
		local v223 = p218[3]
		local v224 = tonumber(v223)
		local v225 = v_u_74
		local v226
		if v220 and (v222 and v224) then
			v226 = Vector3.new(v220, v222, v224)
		else
			v226 = nil
		end
		v225(v226)
		local v227 = v_u_20
		return "point " .. tostring(v227)
	end)
	p185.command("film.key", function()
		-- upvalues: (ref) v_u_9
		local v228 = v_u_9.addKey
		return "keys " .. tostring(v228())
	end)
	p185.command("film.play", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_9
		v_u_6.setCamMode("dolly")
		v_u_9.play(true)
		local v229 = v_u_9.playing
		return "playing " .. tostring(v229())
	end)
	p185.command("film.look", function(p230)
		-- upvalues: (ref) v_u_10
		v_u_10.setLook(table.concat(p230, " "))
		return "look " .. v_u_10.look()
	end)
	p185.command("film.dof", function(p231)
		-- upvalues: (ref) v_u_10
		local v232 = v_u_10.setDof
		local v233 = p231[1] or "off"
		local v234 = p231[2]
		local v235 = tonumber(v234)
		local v236 = p231[3]
		v232(v233, v235, (tonumber(v236)))
		return "dof " .. v_u_10.dof()
	end)
	p185.command("film.guides", function(p237)
		-- upvalues: (ref) v_u_10, (ref) v_u_7
		v_u_10.setGuides(p237[1] == "1", p237[2] == "1")
		local v238 = v_u_7
		return "guides " .. tostring(v238:GetAttribute("FilmGuides"))
	end)
	p185.command("film.hide", function(p239)
		-- upvalues: (ref) v_u_11
		v_u_11.setCharacterHidden(p239[1] == "1")
		local v240 = v_u_11.isCharacterHidden
		return "hidden " .. tostring(v240())
	end)
	p185.command("film.tab", function(p241)
		-- upvalues: (ref) v_u_15, (ref) v_u_7
		if v_u_15 then
			v_u_15.select(p241[1] or "scenes")
		end
		local v242 = v_u_7
		return "tab " .. tostring(v242:GetAttribute("FilmTab"))
	end)
	p185.command("film.loot", function(p243)
		-- upvalues: (ref) v_u_15
		if v_u_15 and v_u_15.searchLoot then
			v_u_15.searchLoot(table.concat(p243, " "))
		end
		return "searched"
	end)
	p185.command("film.op", function(p244)
		-- upvalues: (ref) v_u_6, (ref) v_u_175, (ref) v_u_184
		local v245 = p244[1]
		return not v245 and "usage: film.op <op> [k=v ...]" or v_u_184((v_u_6.call(v245, (v_u_175(p244, 2)))))
	end)
	p185.command("film.photo", function(p246)
		-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_7, (ref) v_u_10
		local v247 = p246[1] or "state"
		if v247 == "load" then
			local v248 = v_u_6.call("scene.load", {
				["id"] = p246[2]
			})
			if v248.ok then
				local v249 = v248.data
				if type(v249) == "table" and v248.data.kind == "photo" then
					v_u_6.photoLoaded(v248.data)
				end
			end
			local v250 = v248.msg
			return tostring(v250)
		end
		if v247 == "cam" then
			local v251 = v_u_6.photoCamera
			return "camera " .. tostring(v251())
		end
		if v247 == "clear" then
			v_u_6.photoClear()
			return "cleared"
		end
		if v247 == "freeze" then
			v_u_13.setFxFrozen(p246[2] ~= "0")
			local v252 = v_u_13.fxFrozen
			return "frozen " .. tostring(v252())
		end
		local v253 = v_u_13.stats()
		local v254 = workspace.CurrentCamera
		local v255 = string.format
		local v256 = "id=%s actors=%d zombies=%d effects=%d emitters=%d lights=%d faces=%d frozen=%s missing=[%s] cam=%s fov=%.1f guides=%s dof=%s"
		local v257 = v253.id
		local v258 = tostring(v257)
		local v259 = v253.actors
		local v260 = v253.zombies
		local v261 = v253.effects
		local v262 = v253.emitters
		local v263 = v253.lights
		local v264 = v253.faces
		local v265 = v253.frozen
		local v266 = tostring(v265)
		local v267 = table.concat(v253.missing, "; ")
		local v268
		if v254 then
			v268 = v254.CFrame.Position
		else
			v268 = v254
		end
		local v269 = v_u_7
		return v255(v256, v258, v259, v260, v261, v262, v263, v264, v266, v267, tostring(v268), v254 and v254.FieldOfView or -1, tostring(v269:GetAttribute("FilmGuides")), v_u_10.dof())
	end)
	p185.command("film.frame", function(p270)
		-- upvalues: (ref) v_u_10, (ref) v_u_7
		local v271 = p270[1] or "off"
		v_u_10.setGuideFrame(v271 == "off" and "" or v271, p270[2] == "1")
		local v272 = v_u_7
		return "guides " .. tostring(v272:GetAttribute("FilmGuides"))
	end)
	p185.command("film.guidesclean", function(p273)
		-- upvalues: (ref) v_u_11
		v_u_11.exempt("HushFilmGuides", p273[1] == "1")
		local v274 = v_u_11.isExempt
		return "guides in clean frame " .. tostring(v274("HushFilmGuides"))
	end)
	p185.command("film.state", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_16, (ref) v_u_7, (ref) v_u_9, (ref) v_u_10, (ref) v_u_17, (ref) v_u_20, (ref) v_u_5
		local v275 = workspace.CurrentCamera
		local v276 = v_u_11.stats()
		local v277 = string.format
		local v278 = "open=%s allowed=%s cam=%s override=%s fov=%.1f camPos=%s clean=%s cleanObj=%d forced=%d hidden=%s look=%s dof=%s inputOff=%s point=%s keys=%d remote=%s"
		local v279 = v_u_16
		local v280 = tostring(v279)
		local v281 = v_u_7:GetAttribute("FilmAllowed") == true
		local v282 = tostring(v281)
		local v283 = v_u_9.mode()
		local v284 = v_u_7
		local v285 = tostring(v284:GetAttribute("CamOverride"))
		local v286 = v275 and (v275.FieldOfView or -1) or -1
		if v275 then
			v275 = v275.CFrame.Position
		end
		local v287 = tostring(v275)
		local v288 = v276.clean
		local v289 = tostring(v288)
		local v290 = v276.cleanObjects
		local v291 = v276.forced
		local v292 = v276.hidden
		local v293 = tostring(v292)
		local v294 = v_u_10.look()
		local v295 = v_u_10.dof()
		local v296 = v_u_17
		local v297 = tostring(v296)
		local v298 = v_u_20
		local v299 = tostring(v298)
		local v300 = v_u_9.keys()
		local v301 = v_u_5:FindFirstChild("HushNet")
		if v301 then
			v301 = v301:FindFirstChild("film.cmd")
		end
		if not (v301 and v301:IsA("RemoteFunction")) then
			v301 = nil
		end
		local v302 = v301 ~= nil
		return v277(v278, v280, v282, v283, v285, v286, v287, v289, v290, v291, v293, v294, v295, v297, v299, v300, (tostring(v302)))
	end)
end
function v_u_6.sceneArrived(p303) -- name: sceneArrived
	-- upvalues: (copy) v_u_7, (ref) v_u_16, (copy) v_u_6
	if type(p303) == "table" and v_u_7:GetAttribute("FilmAllowed") == true then
		if not v_u_16 then
			v_u_6.open()
		end
		if p303.kind == "photo" then
			v_u_6.photoLoaded(p303)
		else
			v_u_6.photoClear()
			local v304 = p303.camera or p303.cam or (p303.preset or p303)
			if v304 ~= nil then
				v_u_6.applyPreset(v304)
			end
		end
		local v305 = v_u_7
		local v306 = p303.scene
		v305:SetAttribute("FilmArrivedScene", (tostring(v306)))
	end
end
local v_u_307 = nil
local function v_u_314() -- name: checkStaged
	-- upvalues: (copy) v_u_7, (ref) v_u_307, (copy) v_u_6, (ref) v_u_15
	local v308 = v_u_7:GetAttribute("FilmStaged")
	if type(v308) == "string" and v308 ~= v_u_307 and v_u_7:GetAttribute("FilmAllowed") == true then
		v_u_307 = v308
		task.spawn(function()
			-- upvalues: (ref) v_u_6, (ref) v_u_15, (ref) v_u_7
			local v309 = v_u_6.call("scene.current", {}, true)
			if v309.ok then
				v_u_6.sceneArrived(v309.data)
				local v310 = v309.msg or "Scene staged."
				local v311 = tostring(v310)
				if v_u_15 then
					v_u_15.status(v311, "success")
				else
					v_u_7:SetAttribute("FilmStatus", v311)
				end
			else
				local v312 = v309.msg or "Scene not staged."
				local v313 = tostring(v312)
				if v_u_15 then
					v_u_15.status(v313, "danger")
				else
					v_u_7:SetAttribute("FilmStatus", v313)
				end
			end
		end)
	end
end
function v_u_6.start() -- name: start
	-- upvalues: (copy) v_u_7, (copy) v_u_314, (copy) v_u_3, (copy) v_u_154, (copy) v_u_159, (copy) v_u_161, (copy) v_u_4, (copy) v_u_139, (ref) v_u_16, (copy) v_u_6, (ref) v_u_8, (ref) v_u_9, (ref) v_u_20, (ref) v_u_21, (ref) v_u_15
	v_u_7:GetAttributeChangedSignal("FilmStaged"):Connect(v_u_314)
	task.defer(v_u_314)
	v_u_3.InputBegan:Connect(v_u_154)
	v_u_3.InputChanged:Connect(v_u_159)
	v_u_3.InputEnded:Connect(v_u_161)
	local function v315()
		-- upvalues: (ref) v_u_4, (ref) v_u_139
		v_u_4.MenuOpened:Connect(v_u_139)
	end
	pcall(v315)
	v_u_7:GetAttributeChangedSignal("FilmAllowed"):Connect(function()
		-- upvalues: (ref) v_u_16, (ref) v_u_7, (ref) v_u_6
		if v_u_16 and v_u_7:GetAttribute("FilmAllowed") ~= true then
			v_u_6.close()
		end
	end)
	task.defer(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_16, (ref) v_u_6
		local v316 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
		if v316 then
			v316 = v316.deviceChanged
		end
		if v316 and v316.Connect then
			v316:Connect(function(p317)
				-- upvalues: (ref) v_u_16, (ref) v_u_6
				if v_u_16 and p317 == "Touch" then
					v_u_6.close()
				end
			end)
		end
	end)
	local v318 = v_u_8.session
	if v318 and v318.onPlaceChanged then
		v318.onPlaceChanged(function(p319)
			-- upvalues: (ref) v_u_16, (ref) v_u_9, (ref) v_u_6, (ref) v_u_20, (ref) v_u_21, (ref) v_u_15
			if v_u_16 then
				if p319 ~= "Raid" and p319 ~= "Hideout" then
					if v_u_9.mode() ~= "game" then
						v_u_6.setCamMode("game")
					end
					v_u_20 = nil
					v_u_9.setPoint(nil)
					if v_u_21 then
						v_u_21:Destroy()
						v_u_21 = nil
					end
					if v_u_15 then
						v_u_15.sync()
					end
					v_u_6.photoClear()
				end
			end
		end)
	end
end
function v_u_6.step(_) -- name: step
	-- upvalues: (ref) v_u_16, (ref) v_u_11, (ref) v_u_9, (ref) v_u_19, (ref) v_u_8, (ref) v_u_17, (ref) v_u_18, (ref) v_u_10, (ref) v_u_20, (ref) v_u_23, (copy) v_u_7, (copy) v_u_6, (ref) v_u_15, (ref) v_u_25
	if v_u_16 then
		v_u_11.step()
		local v320 = v_u_16
		if v320 then
			v320 = v_u_9.mode() == "free" and true or v_u_19 ~= nil
		end
		if v320 then
			local v_u_321 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
			if v_u_321 and v_u_321.setEnabled then
				if not v_u_17 then
					local v323, v324 = pcall(function()
						-- upvalues: (copy) v_u_321
						local v322 = v_u_321.gameBlocked
						if v322 then
							v322 = v_u_321.gameBlocked()
						end
						return v322
					end)
					if v323 then
						v323 = v324 == true
					end
					v_u_18 = v323
					v_u_17 = true
				end
				local v325 = v_u_321.setEnabled
				pcall(v325, false)
			end
		elseif v_u_17 then
			local v326 = v_u_8 and (v_u_8.controllers and v_u_8.controllers.Input) or nil
			if v326 and (v326.setEnabled and v_u_17) then
				v_u_17 = false
				if not v_u_18 then
					local v327 = v326.setEnabled
					pcall(v327, true)
				end
			end
		end
		local v328 = v_u_9.mode() == "game" and (v_u_10.dof() ~= "off" and workspace.CurrentCamera)
		if v328 then
			v_u_10.update(v328.CFrame, v_u_20)
		end
		if v_u_23 ~= nil and (v_u_7:GetAttribute("Place") == "Raid" and (v_u_7.Character and v_u_7.Character:FindFirstChild("HumanoidRootPart"))) then
			local v_u_329 = v_u_23
			task.delay(0.5, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_329
				v_u_6.applyPreset(v_u_329)
			end)
			v_u_23 = nil
		end
		local v330 = os.clock()
		if v_u_15 and (v_u_15.isVisible() and v330 - v_u_25 > 0.3) then
			v_u_25 = v330
			v_u_15.sync()
		end
	end
end
return v_u_6