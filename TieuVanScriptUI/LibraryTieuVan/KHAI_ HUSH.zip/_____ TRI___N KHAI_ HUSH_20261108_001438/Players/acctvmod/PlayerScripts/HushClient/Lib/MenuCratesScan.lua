-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCratesScan

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Players")
local v_u_4 = {}
local v5 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Skins"))
local v_u_7 = require(v5:WaitForChild("CaseOdds"))
local v_u_8 = require(v5:WaitForChild("SkinRules"))
local v_u_9 = nil
local function v11()
	-- upvalues: (ref) v_u_9
	local v10 = script.Parent:FindFirstChild("TallyMark")
	if v10 then
		v_u_9 = require(v10)
	end
end
pcall(v11)
local v_u_12 = {
	"COMMON",
	"UNCOMMON",
	"RARE",
	"EPIC",
	"LEGENDARY",
	"MYTHIC",
	"SIGNATURE"
}
v_u_4.TEXT = {
	["title"] = "X-RAY BENCH",
	["why"] = "Roblox does not allow paid random items for your account. So nothing here is random for you: scan a case for free and see the finish, then buy exactly that finish, keep the case for later or discard it.",
	["scan"] = "SCAN",
	["keep"] = "KEEP FOR LATER",
	["keepToast"] = "Kept. The case waits on the bench until you buy or discard it.",
	["claim"] = "USE PREPAID PURCHASE",
	["scanning"] = "Scanning...",
	["empty"] = "No cases to scan. Cases come from raids: safes, lockers, duffel bags and more. Your account cannot buy them on the Market.",
	["pending"] = "Checking your account settings with Roblox. This takes a moment.",
	["off"] = "The scanner is not available right now.",
	["loading"] = "Loading the scanner...",
	["error"] = "The scanner could not be loaded. Try again in a moment.",
	["fixed"] = "This result is final. It will not change and nothing about it is random any more. While this case waits on the bench you cannot scan another one.",
	["buyTitle"] = "CONFIRM PURCHASE",
	["scrapTitle"] = "DISCARD THIS CASE",
	["cancel"] = "Cancel",
	["preview"] = "Test game: nothing is charged.",
	["prices"] = "WHAT EACH FINISH COSTS",
	["pricesNote"] = "Prices are fixed by rarity. Taken together with their chances, a finish costs no more than a key would, on average. Skins are cosmetic and change no stats.",
	["stash"] = "In your stash",
	["waiting"] = "Waiting for the purchase to finish...",
	["odds"] = "ODDS"
}
function v_u_4.robux(p13) -- name: robux
	local v14 = tonumber(p13) or 0
	local v15 = math.floor(v14)
	local v16 = math.abs(v15)
	local v17 = tostring(v16)
	local v18 = ""
	while #v17 > 3 do
		v18 = "," .. string.sub(v17, -3) .. v18
		local v19 = #v17 - 3
		v17 = string.sub(v17, 1, v19)
	end
	return (v15 < 0 and "-" or "") .. v17 .. v18
end
function v_u_4.showSegment(p20) -- name: showSegment
	local v21
	if type(p20) == "table" and p20.enabled == true then
		local v22 = p20.scan
		if type(v22) == "table" then
			v21 = p20.scan.visible == true
		else
			v21 = false
		end
	else
		v21 = false
	end
	return v21
end
function v_u_4.state(p23) -- name: state
	if type(p23) ~= "table" then
		return "loading"
	end
	local v24 = p23.scan
	if p23.enabled ~= true or type(v24) ~= "table" then
		return "off"
	end
	if v24.visible ~= true then
		return v24.pending == true and "pending" or "off"
	end
	local v25 = v24.open
	if type(v25) == "table" then
		return "bench"
	end
	local v26 = 0
	for _, v27 in p23.crates or {} do
		local v28 = v27.count
		v26 = v26 + (tonumber(v28) or 0)
	end
	return v26 == 0 and "empty" or "ready"
end
function v_u_4.dayLine(p29) -- name: dayLine
	-- upvalues: (copy) v_u_8
	local v30
	if type(p29) == "table" then
		local v31 = p29.day
		local v32 = tonumber(v31) or 0
		v30 = math.floor(v32)
	else
		v30 = 0
	end
	local v33
	if type(p29) == "table" then
		local v34 = p29.cap
		local v35 = tonumber(v34) or v_u_8.TUNE.scannerDailyCap
		v33 = math.floor(v35)
	else
		v33 = v_u_8.TUNE.scannerDailyCap
	end
	return ("Scans claimed today %d / %d"):format(v30, v33)
end
function v_u_4.buyText(p36) -- name: buyText
	-- upvalues: (copy) v_u_4
	local v37
	if p36 then
		v37 = p36.offer
	else
		v37 = p36
	end
	if type(v37) == "table" and v37.soon == true then
		return "COMING SOON"
	end
	local v38 = "BUY FOR R$ %s"
	local v39 = v_u_4.robux
	local v40
	if p36 then
		v40 = p36.offer
	else
		v40 = p36
	end
	if type(v40) ~= "table" then
		if p36 then
			p36 = p36.price
		end
		v42 = tonumber(p36) or 0
		return v38:format(v39(v42))
	end
	local v41 = v40.price
	if type(v41) == "number" then
		v42 = v40.price
		return v38:format(v39(v42))
	end
	if p36 then
		p36 = p36.price
	end
	local v42 = tonumber(p36) or 0
	return v38:format(v39(v42))
end
function v_u_4.confirmText(p43, p44) -- name: confirmText
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_6, (copy) v_u_4
	local v45 = v_u_12
	local v46
	if p43 then
		v46 = p43.rarity
	else
		v46 = p43
	end
	local v47 = v45[tonumber(v46) or 1] or ""
	local v48
	if type(p44) == "table" then
		local v49 = p44.day
		local v50 = tonumber(v49) or 0
		v48 = math.floor(v50)
	else
		v48 = 0
	end
	local v51
	if type(p44) == "table" then
		local v52 = p44.cap
		local v53 = tonumber(v52) or v_u_8.TUNE.scannerDailyCap
		v51 = math.floor(v53)
	else
		v51 = v_u_8.TUNE.scannerDailyCap
	end
	local v54 = "Buy %s (%s) for R$ %s. This is the exact finish you scanned, not a chance. Roblox charges the amount in Robux when you confirm. You have bought %d of %d scanned finishes today."
	local v55 = v_u_6.get
	local v56
	if p43 then
		v56 = p43.skin
	else
		v56 = p43
	end
	local v57 = v55(v56)
	local v58
	if v57 then
		v58 = v_u_6.displayName(v57)
	else
		local v59 = not p43 or p43.skinName or (p43.skin or "?")
		v58 = tostring(v59)
	end
	local v60 = v_u_4.robux
	local v61
	if p43 then
		v61 = p43.offer
	else
		v61 = p43
	end
	local v62, v63
	if type(v61) ~= "table" then
		if p43 then
			v62 = p43.price
		else
			v62 = p43
		end
		v65 = tonumber(v62) or 0
		v66 = v54:format(v58, v47, v60(v65), v48, v51)
		if type(p43) == "table" then
			v63 = p43.offer
			if type(v63) == "table" and p43.offer.preview == true then
				v66 = v66 .. " " .. v_u_4.TEXT.preview
			end
		end
		return v66
	end
	local v64 = v61.price
	if type(v64) == "number" then
		v65 = v61.price
		v66 = v54:format(v58, v47, v60(v65), v48, v51)
		if type(p43) == "table" then
			v63 = p43.offer
			if type(v63) == "table" and p43.offer.preview == true then
				v66 = v66 .. " " .. v_u_4.TEXT.preview
			end
		end
		return v66
	end
	if p43 then
		v62 = p43.price
	else
		v62 = p43
	end
	local v65 = tonumber(v62) or 0
	local v66 = v54:format(v58, v47, v60(v65), v48, v51)
	if type(p43) == "table" then
		v63 = p43.offer
		if type(v63) == "table" and p43.offer.preview == true then
			v66 = v66 .. " " .. v_u_4.TEXT.preview
		end
	end
	return v66
end
function v_u_4.scrapText(_) -- name: scrapText
	-- upvalues: (copy) v_u_8
	return v_u_8.TEXT.discardCaseAsk
end
function v_u_4.scrapButton(_) -- name: scrapButton
	return "DISCARD CASE"
end
function v_u_4.priceRows(p67, p68) -- name: priceRows
	-- upvalues: (copy) v_u_12, (copy) v_u_7
	local v69 = nil
	local v70 = {}
	for _, v71 in type(p67) == "table" and (p67.crates or {}) or {} do
		if v71.id ~= p68 then
			continue
		end
		v69 = v71
	end
	if v69 == nil then
		return v70
	end
	local v72 = {}
	for _, v73 in v69.pool or {} do
		local v74 = v73.rarity
		local v75 = tonumber(v74) or 1
		local v76 = v72[v75]
		if v76 == nil then
			v76 = {
				["rarity"] = nil,
				["word"] = nil,
				["price"] = nil,
				["count"] = 0,
				["w"] = 0,
				["rarity"] = v75,
				["word"] = v_u_12[v75] or "?",
				["price"] = v73.price
			}
			v72[v75] = v76
			table.insert(v70, v76)
		end
		v76.count = v76.count + 1
		local v77 = v76.w
		local v78 = v73.w
		v76.w = v77 + (tonumber(v78) or 0)
	end
	table.sort(v70, function(p79, p80)
		return p79.rarity < p80.rarity
	end)
	for _, v81 in v70 do
		v81.pct = v_u_7.percent(v81.w)
	end
	return v70
end
function v_u_4.resultLine(p82) -- name: resultLine
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_12
	local v83 = v_u_7.get
	local v84
	if p82 then
		v84 = p82.crate
	else
		v84 = p82
	end
	local v85 = v83(v84)
	local v86 = "%s  %s  %s"
	local v87 = v85 and v85.name or "CASE"
	local v88 = v_u_6.get
	local v89
	if p82 then
		v89 = p82.skin
	else
		v89 = p82
	end
	local v90 = v88(v89)
	local v91
	if v90 then
		v91 = v_u_6.displayName(v90)
	else
		local v92 = not p82 or p82.skinName or (p82.skin or "?")
		v91 = tostring(v92)
	end
	local v93 = v_u_12
	if p82 then
		p82 = p82.rarity
	end
	return v86:format(v87, v91, v93[tonumber(p82) or 1] or "")
end
function v_u_4.new(p_u_94, p_u_95) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6, (copy) v_u_2, (copy) v_u_12, (ref) v_u_9, (copy) v_u_7
	local v_u_96 = p_u_94.ui
	local v_u_97 = p_u_94.theme
	local v_u_98 = v_u_97.color
	local v_u_99 = p_u_94.kit
	local v_u_100 = p_u_95.phone == true
	local v_u_101 = p_u_95.compact == true
	local v_u_102 = v_u_4.TEXT
	local v_u_103 = {}
	local v_u_104 = v_u_96.new("Frame", {
		["Name"] = "ScanView",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v_u_103.frame = v_u_104
	local v_u_105 = true
	local v_u_106 = nil
	local v_u_107 = 0
	local v_u_108 = 0
	local v_u_109 = {}
	local v_u_110 = false
	local v_u_111 = 0
	local v_u_112 = 0
	local v_u_113 = nil
	local v_u_114 = nil
	local function v_u_117(p115) -- name: crateById
		-- upvalues: (copy) p_u_95
		for _, v116 in p_u_95.view() and p_u_95.view().crates or {} do
			if v116.id ~= p115 then
				continue
			end
			return v116
		end
		return nil
	end
	local function v_u_119(p118) -- name: swatchOf
		-- upvalues: (copy) v_u_98
		if p118 then
			p118 = p118.swatch
		end
		return type(p118) == "table" and (p118[1] and p118[2]) and { Color3.fromRGB(p118[1][1], p118[1][2], p118[1][3]), Color3.fromRGB(p118[2][1], p118[2][2], p118[2][3]) } or { v_u_98.raised2, v_u_98.raised }
	end
	function v_u_103.scan(p120) -- name: scan
		-- upvalues: (copy) p_u_95, (ref) v_u_110, (copy) v_u_117, (ref) v_u_8, (copy) v_u_96, (ref) v_u_113, (ref) v_u_107, (ref) v_u_1, (ref) v_u_3, (ref) v_u_108, (ref) v_u_105, (copy) v_u_103, (copy) p_u_94, (copy) v_u_109
		if p_u_95.busy() or v_u_110 then
			return
		else
			local v121 = v_u_117(p120)
			if v121 == nil or v121.canScan ~= true then
				local v122 = v121 and v121.whyScan or v_u_8.TEXT.notNow
				local v123 = v_u_96.toast
				pcall(v123, v122, "warn")
			else
				v_u_113 = nil
				local function v134(p124)
					-- upvalues: (ref) v_u_107, (ref) v_u_1, (ref) v_u_3, (ref) v_u_108, (ref) v_u_105, (ref) v_u_103, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95
					if p124.ok == true then
						local function v125()
							-- upvalues: (ref) v_u_1
							return v_u_1.ReducedMotionEnabled
						end
						local v126, v127 = pcall(v125)
						local v128
						if v126 and v127 == true then
							v128 = true
						else
							local v129 = v_u_3.LocalPlayer
							if v129 == nil then
								v128 = false
							else
								v128 = v129:GetAttribute("ReduceMotion") == true
							end
						end
						v_u_107 = v128 and 0 or os.clock() + 1.1
						v_u_108 = v_u_108 + 1
						local v_u_130 = v_u_108
						if v_u_107 > 0 then
							task.delay(1.15, function()
								-- upvalues: (ref) v_u_105, (copy) v_u_130, (ref) v_u_108, (ref) v_u_103
								if v_u_105 and v_u_130 == v_u_108 then
									v_u_103.draw()
								end
							end)
						end
					else
						local v131 = p124.msg
						local v132
						if type(v131) == "string" then
							v132 = p124.msg
						else
							v132 = v_u_8.TEXT.notNow
						end
						local v133 = v_u_96.toast
						pcall(v133, v132, "warn")
					end
					p_u_94.invalidate("crates")
					p_u_95.refetch()
				end
				local v_u_135 = p_u_94.op({
					["op"] = "scanStart",
					["crate"] = nil,
					["crate"] = p120
				})
				v_u_109[v_u_135] = v134
				task.delay(25, function()
					-- upvalues: (ref) v_u_109, (copy) v_u_135
					local v136 = v_u_109[v_u_135]
					if v136 then
						v_u_109[v_u_135] = nil
						v136({
							["ok"] = false,
							["msg"] = "No answer from the server. Try again in a moment."
						})
					end
				end)
			end
		end
	end
	function v_u_103.scrap(p137) -- name: scrap
		-- upvalues: (copy) p_u_95, (ref) v_u_110, (ref) v_u_8, (copy) v_u_96, (ref) v_u_113, (copy) p_u_94, (copy) v_u_109, (copy) v_u_102, (ref) v_u_4
		local v138 = p_u_95.view()
		if v138 then
			v138 = p_u_95.view().scan
		end
		if p_u_95.busy() or (v_u_110 or (v138 == nil or v138.open == nil)) then
			return
		elseif v138.open.canScrap == true then
			local function v146() -- name: go
				-- upvalues: (ref) v_u_113, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95, (ref) v_u_109
				local function v143(p139)
					-- upvalues: (ref) v_u_113, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95
					if p139.ok == true then
						v_u_113 = {
							["text"] = nil,
							["kind"] = "info",
							["text"] = v_u_8.TEXT.scanScrapped
						}
					else
						local v140 = p139.msg
						local v141
						if type(v140) == "string" then
							v141 = p139.msg
						else
							v141 = v_u_8.TEXT.notNow
						end
						local v142 = v_u_96.toast
						pcall(v142, v141, "warn")
					end
					p_u_94.invalidate("crates")
					p_u_95.refetch()
				end
				local v_u_144 = p_u_94.op({
					["op"] = "scanScrap"
				})
				v_u_109[v_u_144] = v143
				task.delay(25, function()
					-- upvalues: (ref) v_u_109, (copy) v_u_144
					local v145 = v_u_109[v_u_144]
					if v145 then
						v_u_109[v_u_144] = nil
						v145({
							["ok"] = false,
							["msg"] = "No answer from the server. Try again in a moment."
						})
					end
				end)
			end
			if p137 then
				local function v151(p147)
					-- upvalues: (ref) v_u_113, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95
					if p147.ok == true then
						v_u_113 = {
							["text"] = nil,
							["kind"] = "info",
							["text"] = v_u_8.TEXT.scanScrapped
						}
					else
						local v148 = p147.msg
						local v149
						if type(v148) == "string" then
							v149 = p147.msg
						else
							v149 = v_u_8.TEXT.notNow
						end
						local v150 = v_u_96.toast
						pcall(v150, v149, "warn")
					end
					p_u_94.invalidate("crates")
					p_u_95.refetch()
				end
				local v_u_152 = p_u_94.op({
					["op"] = "scanScrap"
				})
				v_u_109[v_u_152] = v151
				task.delay(25, function()
					-- upvalues: (ref) v_u_109, (copy) v_u_152
					local v153 = v_u_109[v_u_152]
					if v153 then
						v_u_109[v_u_152] = nil
						v153({
							["ok"] = false,
							["msg"] = "No answer from the server. Try again in a moment."
						})
					end
				end)
			else
				v_u_96.modal({
					["title"] = nil,
					["body"] = nil,
					["width"] = 520,
					["buttons"] = nil,
					["title"] = v_u_102.scrapTitle,
					["body"] = v_u_4.scrapText(v138),
					["buttons"] = {
						{
							["text"] = v_u_102.cancel
						},
						{
							["text"] = nil,
							["kind"] = "primary",
							["onClick"] = nil,
							["text"] = v_u_4.scrapButton(v138),
							["onClick"] = v146
						}
					}
				})
			end
		else
			local v154 = v138.open.whyScrap or v_u_8.TEXT.notNow
			local v155 = v_u_96.toast
			pcall(v155, v154, "warn")
			return
		end
	end
	function v_u_103.buy(p156) -- name: buy
		-- upvalues: (copy) p_u_95, (ref) v_u_110, (ref) v_u_8, (copy) v_u_96, (ref) v_u_112, (ref) v_u_111, (ref) v_u_113, (copy) v_u_103, (copy) p_u_94, (copy) v_u_109, (ref) v_u_105, (copy) v_u_102, (ref) v_u_4
		local v157 = p_u_95.view()
		if v157 then
			v157 = p_u_95.view().scan
		end
		if p_u_95.busy() or (v_u_110 or (v157 == nil or v157.open == nil)) then
			return
		else
			local v_u_158 = v157.open
			if v_u_158.canBuy == true then
				local function v169() -- name: go
					-- upvalues: (ref) v_u_110, (ref) v_u_112, (ref) v_u_111, (ref) v_u_113, (ref) v_u_103, (copy) v_u_158, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95, (ref) v_u_109, (ref) v_u_105
					v_u_110 = true
					v_u_112 = os.clock()
					v_u_111 = v_u_111 + 1
					local v_u_159 = v_u_111
					v_u_113 = nil
					v_u_103.draw()
					local v160 = {
						["op"] = "storeBuy",
						["id"] = nil
					}
					local v161 = v_u_158.offer
					if v161 then
						v161 = v_u_158.offer.id
					end
					v160.id = v161
					local function v166(p162)
						-- upvalues: (ref) v_u_110, (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95
						if p162.ok ~= true then
							v_u_110 = false
							local v163 = p162.msg
							local v164
							if type(v163) == "string" then
								v164 = p162.msg
							else
								v164 = v_u_8.TEXT.notNow
							end
							local v165 = v_u_96.toast
							pcall(v165, v164, "warn")
							p_u_94.invalidate("crates")
							p_u_95.refetch()
						end
					end
					local v_u_167 = p_u_94.op(v160)
					v_u_109[v_u_167] = v166
					task.delay(25, function()
						-- upvalues: (ref) v_u_109, (copy) v_u_167
						local v168 = v_u_109[v_u_167]
						if v168 then
							v_u_109[v_u_167] = nil
							v168({
								["ok"] = false,
								["msg"] = "No answer from the server. Try again in a moment."
							})
						end
					end)
					task.delay(120, function()
						-- upvalues: (ref) v_u_105, (ref) v_u_110, (copy) v_u_159, (ref) v_u_111, (ref) p_u_94, (ref) p_u_95
						if v_u_105 and (v_u_110 and v_u_159 == v_u_111) then
							v_u_110 = false
							p_u_94.invalidate("crates")
							p_u_95.refetch()
						end
					end)
				end
				if p156 then
					v169()
				else
					v_u_96.modal({
						["title"] = nil,
						["body"] = nil,
						["width"] = 540,
						["buttons"] = nil,
						["title"] = v_u_102.buyTitle,
						["body"] = v_u_4.confirmText(v_u_158, v157),
						["buttons"] = {
							{
								["text"] = v_u_102.cancel
							},
							{
								["text"] = nil,
								["kind"] = "primary",
								["onClick"] = nil,
								["text"] = v_u_4.buyText(v_u_158),
								["onClick"] = v169
							}
						}
					})
				end
			else
				local v170 = v_u_158.whyBuy or v_u_8.TEXT.notNow
				local v171 = v_u_96.toast
				pcall(v171, v170, "warn")
				return
			end
		end
	end
	function v_u_103.claim() -- name: claim
		-- upvalues: (copy) p_u_95, (ref) v_u_110, (ref) v_u_8, (copy) v_u_96, (copy) p_u_94, (copy) v_u_109
		local v172 = p_u_95.view()
		if v172 then
			v172 = p_u_95.view().scan
		end
		if not p_u_95.busy() and (not v_u_110 and (v172 ~= nil and (v172.open ~= nil and v172.open.canClaim == true))) then
			local function v177(p173)
				-- upvalues: (ref) v_u_8, (ref) v_u_96, (ref) p_u_94, (ref) p_u_95
				if p173.ok ~= true then
					local v174 = p173.msg
					local v175
					if type(v174) == "string" then
						v175 = p173.msg
					else
						v175 = v_u_8.TEXT.notNow
					end
					local v176 = v_u_96.toast
					pcall(v176, v175, "warn")
				end
				p_u_94.invalidate("crates")
				p_u_95.refetch()
			end
			local v_u_178 = p_u_94.op({
				["op"] = "scanClaim"
			})
			v_u_109[v_u_178] = v177
			task.delay(25, function()
				-- upvalues: (ref) v_u_109, (copy) v_u_178
				local v179 = v_u_109[v_u_178]
				if v179 then
					v_u_109[v_u_178] = nil
					v179({
						["ok"] = false,
						["msg"] = "No answer from the server. Try again in a moment."
					})
				end
			end)
		end
	end
	local v_u_180 = {}
	local function v_u_201(p181, p182, p183, p184) -- name: swatchFrame
		-- upvalues: (copy) v_u_119, (copy) p_u_94, (ref) v_u_6, (copy) v_u_98, (copy) v_u_180, (copy) v_u_96
		local v185 = v_u_119(p182)
		local function v186()
			-- upvalues: (ref) p_u_94
			return p_u_94.cctx.lib.SkinTile
		end
		local v187, v188 = pcall(v186)
		local v189 = v_u_6.get
		if p182 then
			p182 = p182.skin
		end
		local v190 = v189(p182)
		if v187 and (v188 and v190) then
			local v191 = v188.new
			local v192 = {
				["size"] = p183,
				["weaponId"] = v190.weapon,
				["skinId"] = v190.id,
				["hidden"] = p184,
				["colors"] = v185,
				["line"] = v_u_98.line
			}
			local v193, v194 = pcall(v191, p181, v192)
			if v193 and (type(v194) == "table" and v194.frame) then
				local v195 = v_u_180
				table.insert(v195, v194)
				return v194.frame
			end
		end
		local v196 = v_u_96.new
		local v197 = "Frame"
		local v198 = {
			["Name"] = "Swatch",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.08,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ClipsDescendants"] = true
		}
		local v199
		if p184 then
			v199 = v_u_98.raised2
		else
			v199 = v185[1]
		end
		v198.BackgroundColor3 = v199
		v198.Size = UDim2.fromOffset(p183, p183)
		local v200 = v196(v197, v198, p181)
		if not p184 then
			v_u_96.new("UIGradient", {
				["Color"] = nil,
				["Rotation"] = 45,
				["Color"] = ColorSequence.new(v185[1], v185[2])
			}, v200)
		end
		v_u_96.stroke(v200, v_u_98.line)
		return v200
	end
	local function v_u_206(p202, p203, p204) -- name: buildHeader
		-- upvalues: (copy) v_u_96, (copy) p_u_95, (copy) v_u_102, (copy) v_u_98, (ref) v_u_4
		local v205 = v_u_96.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p204
		}, p202)
		v_u_96.layout(v205, "v", 6)
		if p_u_95.embed ~= true then
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h2",
				["size"] = nil,
				["order"] = 1,
				["parent"] = v205,
				["text"] = v_u_102.title,
				["size"] = UDim2.new(1, 0, 0, 28)
			})
		end
		v_u_96.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v205,
			["text"] = v_u_102.why,
			["color"] = v_u_98.text2
		})
		v_u_96.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["autoY"] = true,
			["wrap"] = true,
			["order"] = 3,
			["name"] = "DayLine",
			["parent"] = v205,
			["text"] = v_u_4.dayLine(p203),
			["color"] = v_u_98.text
		})
		return v205
	end
	local function v_u_210(p207, p208) -- name: buildBanner
		-- upvalues: (ref) v_u_113, (copy) v_u_96, (copy) v_u_98
		if v_u_113 ~= nil then
			local v209 = v_u_96.new("Frame", {
				["Name"] = "Banner",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_98.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = p208
			}, p207)
			v_u_96.stroke(v209, v_u_98.accent)
			v_u_96.pad(v209, {
				12,
				12,
				8,
				8
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "bodyStrong",
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v209,
				["text"] = v_u_113.text
			})
		end
	end
	local function v_u_257(p211, p212, p213) -- name: buildResult
		-- upvalues: (ref) v_u_107, (copy) v_u_97, (copy) v_u_96, (copy) v_u_98, (copy) v_u_100, (copy) v_u_201, (ref) v_u_2, (copy) v_u_102, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_108, (copy) v_u_103, (copy) p_u_95, (ref) v_u_110, (ref) v_u_114
		local v214 = p212.open
		local v215 = os.clock() < v_u_107
		local v216 = v_u_97.rarityColor(v214.rarity)
		local v217 = v_u_96.new("Frame", {
			["Name"] = "Result",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_98.raised,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p213
		}, p211)
		local v218 = v_u_96.stroke
		local v219
		if v215 then
			v219 = v_u_98.line
		else
			v219 = v216
		end
		v218(v217, v219)
		v_u_96.new("Frame", {
			["Name"] = "Rarity",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v216,
			["Position"] = UDim2.fromOffset(-18, -12),
			["Size"] = UDim2.new(0, 4, 1, 26)
		}, v217)
		v_u_96.pad(v217, {
			18,
			14,
			12,
			14
		})
		local v220 = v_u_96.new("Frame", {
			["Name"] = "Stack",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v217)
		v_u_96.layout(v220, "v", 10)
		local v221 = v_u_100 and 76 or 104
		local v222 = v_u_96.new("Frame", {
			["Name"] = "Top",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, (math.max(v221, 92)))
		}, v220)
		local v223 = v_u_201(v222, v214, v221, v215)
		if v215 then
			local v_u_224 = v_u_96.new("Frame", {
				["Name"] = "Sweep",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Position"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_98.accent,
				["Size"] = UDim2.new(1, 0, 0, 3),
				["Position"] = UDim2.fromScale(0, 0)
			}, v223)
			local function v225()
				-- upvalues: (ref) v_u_2, (copy) v_u_224
				v_u_2:Create(v_u_224, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
					["Position"] = UDim2.new(0, 0, 1, -3)
				}):Play()
			end
			pcall(v225)
		end
		local v226 = v221 + 14
		if v215 then
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["name"] = "Scanning",
				["parent"] = v222,
				["text"] = v_u_102.scanning,
				["color"] = v_u_98.text2,
				["position"] = UDim2.fromOffset(v226, 8),
				["size"] = UDim2.new(1, -v226, 0, 24)
			})
		else
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v222,
				["text"] = v214.crateName or "CASE",
				["color"] = v_u_98.text2,
				["position"] = UDim2.fromOffset(v226, 0),
				["size"] = UDim2.new(1, -v226, 0, 14)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h2",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["name"] = "SkinName",
				["parent"] = v222,
				["text"] = v214.skinName or v214.skin,
				["position"] = UDim2.fromOffset(v226, 16),
				["size"] = UDim2.new(1, -v226, 0, 28)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["name"] = "Rarity",
				["parent"] = v222,
				["text"] = v_u_12[v214.rarity] or "",
				["color"] = v216,
				["position"] = UDim2.fromOffset(v226, 46),
				["size"] = UDim2.new(1, -v226, 0, 14)
			})
			if v214.tally == true and v_u_9 then
				local v227 = v_u_96.new("Frame", {
					["Name"] = "TallyChip",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["ZIndex"] = 3,
					["BackgroundColor3"] = v_u_98.bg,
					["Position"] = UDim2.fromOffset(v226 + 108, 44),
					["Size"] = UDim2.fromOffset(0, 18),
					["AutomaticSize"] = Enum.AutomaticSize.X
				}, v222)
				v_u_96.stroke(v227, v_u_9.colorOf(0, v_u_97), 1, 0.4)
				v_u_96.pad(v227, {
					5,
					6,
					0,
					0
				})
				v_u_96.layout(v227, "h", 5).VerticalAlignment = Enum.VerticalAlignment.Center
				v_u_9.new(v227, {
					["size"] = 12,
					["level"] = 0,
					["name"] = "Sign"
				}).frame.LayoutOrder = 1
				v_u_96.label({
					["parent"] = nil,
					["text"] = "TALLY",
					["style"] = "micro",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 2,
					["parent"] = v227,
					["color"] = v_u_98.text,
					["size"] = UDim2.fromOffset(0, 16)
				}).Name = "Word"
			end
			local v228 = v214.offer
			local v229 = "FIXED PRICE   R$ %s"
			local v230 = v_u_4.robux
			local v231
			if v214 then
				v231 = v214.offer
			else
				v231 = v214
			end
			local v232, v233, v234
			if type(v231) == "table" then
				local v235 = v231.price
				if type(v235) == "number" then
					v232 = v231.price
					v233 = v229:format(v230(v232))
					if type(v228) == "table" and v228.preview == true then
						v233 = v233 .. "   PREVIEW"
					end
					v_u_96.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["name"] = "Price",
						["parent"] = v222,
						["text"] = v233,
						["color"] = v_u_98.text,
						["position"] = UDim2.fromOffset(v226, 64),
						["size"] = UDim2.new(1, -v226, 0, 20)
					})
				else
					if v214 then
						v234 = v214.price
					else
						v234 = v214
					end
					v232 = tonumber(v234) or 0
					v233 = v229:format(v230(v232))
					if type(v228) == "table" and v228.preview == true then
						v233 = v233 .. "   PREVIEW"
					end
					v_u_96.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["name"] = "Price",
						["parent"] = v222,
						["text"] = v233,
						["color"] = v_u_98.text,
						["position"] = UDim2.fromOffset(v226, 64),
						["size"] = UDim2.new(1, -v226, 0, 20)
					})
				end
			else
				if v214 then
					v234 = v214.price
				else
					v234 = v214
				end
				v232 = tonumber(v234) or 0
				v233 = v229:format(v230(v232))
				if type(v228) == "table" and v228.preview == true then
					v233 = v233 .. "   PREVIEW"
				end
				v_u_96.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "mono",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["name"] = "Price",
					["parent"] = v222,
					["text"] = v233,
					["color"] = v_u_98.text,
					["position"] = UDim2.fromOffset(v226, 64),
					["size"] = UDim2.new(1, -v226, 0, 20)
				})
			end
		end
		v_u_96.new("TextButton", {
			["Name"] = "SkipReveal",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Visible"] = nil,
			["Selectable"] = false,
			["Size"] = UDim2.fromScale(1, 1),
			["Visible"] = v215
		}, v222).Activated:Connect(function()
			-- upvalues: (ref) v_u_107, (ref) v_u_108, (ref) v_u_103
			v_u_107 = 0
			v_u_108 = v_u_108 + 1
			v_u_103.draw()
		end)
		if v215 then
			return v217
		end
		v_u_96.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v220,
			["text"] = v_u_102.fixed,
			["color"] = v_u_98.muted
		})
		local v236 = v_u_96.new("Frame", {
			["Name"] = "Ways",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 3,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v220)
		local v237 = v_u_96.layout(v236, "h", 10)
		v237.Wraps = true
		v237.SortOrder = Enum.SortOrder.LayoutOrder
		local v238 = v_u_97.touch(44)
		local v239 = p_u_95.busy() or v_u_110
		local v240 = v_u_100 and 250 or 230
		local v241 = v_u_96.button
		local v242 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "primary",
			["width"] = nil,
			["height"] = nil,
			["name"] = "Buy",
			["order"] = 1,
			["onClick"] = nil,
			["parent"] = v236
		}
		local v243
		if v_u_110 then
			v243 = v_u_102.waiting
		else
			v243 = v_u_4.buyText(v214)
		end
		v242.text = v243
		v242.width = v_u_110 and 300 or v240
		v242.height = v238
		function v242.onClick() -- name: onClick
			-- upvalues: (ref) v_u_103
			v_u_103.buy()
		end
		local v244, v245 = v241(v242)
		local v246 = v245.setEnabled
		local v247
		if v214.canBuy == true then
			v247 = not v239
		else
			v247 = false
		end
		v246(v247)
		if v214.canBuy ~= true or v239 then
			v244 = nil
		end
		v_u_114 = v244
		v_u_96.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = 190,
			["height"] = nil,
			["name"] = "Keep",
			["order"] = 2,
			["onClick"] = nil,
			["parent"] = v236,
			["text"] = v_u_102.keep,
			["height"] = v238,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_102, (ref) v_u_96
				local v248 = v_u_102.keepToast
				local v249 = v_u_96.toast
				pcall(v249, v248, "info")
			end
		})
		local v250, v251 = v_u_96.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = nil,
			["height"] = nil,
			["name"] = "Scrap",
			["order"] = 3,
			["onClick"] = nil,
			["parent"] = v236,
			["text"] = v_u_4.scrapButton(p212),
			["width"] = v_u_100 and 250 or 240,
			["height"] = v238,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_103
				v_u_103.scrap()
			end
		})
		local v252 = v251.setEnabled
		local v253
		if v214.canScrap == true then
			v253 = not v239
		else
			v253 = false
		end
		v252(v253)
		if v_u_114 == nil then
			v_u_114 = v250
		end
		if v214.canClaim == true then
			local v254, v255 = v_u_96.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "primary",
				["width"] = 250,
				["height"] = nil,
				["name"] = "Claim",
				["order"] = 0,
				["onClick"] = nil,
				["parent"] = v236,
				["text"] = v_u_102.claim,
				["height"] = v238,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_103
					v_u_103.claim()
				end
			})
			v255.setEnabled(not v239)
			v_u_114 = v254
		end
		if v214.canBuy ~= true then
			local v256 = v214.whyBuy
			if type(v256) == "string" and (v214.whyBuy ~= "" and not v_u_110) then
				v_u_96.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 4,
					["name"] = "WhyBuy",
					["parent"] = v220,
					["text"] = v214.whyBuy,
					["color"] = v_u_98.muted
				})
				return v217
			end
		end
		if v_u_110 then
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 4,
				["name"] = "Waiting",
				["parent"] = v220,
				["text"] = v_u_102.waiting,
				["color"] = v_u_98.muted
			})
		end
		return v217
	end
	local function v_u_282(p258, _, p259) -- name: buildCases
		-- upvalues: (copy) v_u_96, (copy) v_u_97, (copy) v_u_100, (copy) p_u_95, (copy) v_u_98, (ref) v_u_106, (copy) p_u_94, (copy) v_u_103, (copy) v_u_99, (copy) v_u_102, (ref) v_u_110, (ref) v_u_114
		local v260 = v_u_96.new("Frame", {
			["Name"] = "Cases",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p259
		}, p258)
		v_u_96.layout(v260, "v", 10)
		local v261 = v_u_97.touch(v_u_100 and 40 or 42)
		local v262 = 0
		for v263, v_u_264 in p_u_95.view() and p_u_95.view().crates or {} do
			if p_u_95.only ~= nil and v_u_264.id ~= p_u_95.only then
				continue
			end
			v262 = v262 + 1
			local v265 = v_u_264.count
			local v266 = tonumber(v265) or 0
			local v267
			if v_u_264.canScan == true or v266 <= 0 then
				v267 = false
			else
				local v268 = v_u_264.whyScan
				if type(v268) == "string" then
					v267 = v_u_264.whyScan ~= ""
				else
					v267 = false
				end
			end
			local v269 = (v267 and 34 or 0) + 84
			local v270 = v_u_96.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Crate_" .. v_u_264.id,
				["BackgroundColor3"] = v_u_98.raised,
				["Size"] = UDim2.new(1, 0, 0, v269),
				["LayoutOrder"] = v263
			}, v260)
			local v271 = v_u_96.stroke
			local v272
			if v_u_106 == v_u_264.id then
				v272 = v_u_98.accent
			else
				v272 = v_u_98.line
			end
			v271(v270, v272)
			local v273 = p_u_94.cctx.shared.Items.get(v_u_264.id)
			v_u_96.new("Frame", {
				["Name"] = "Rarity",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v_u_97.rarityColor(not (v273 and v273.rarity) and 3 or v273.rarity),
				["Size"] = UDim2.new(0, 4, 1, 0)
			}, v270)
			v_u_96.new("TextButton", {
				["Name"] = "Hit",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 1,
				["Size"] = UDim2.fromScale(1, 1)
			}, v270).Activated:Connect(function()
				-- upvalues: (ref) v_u_106, (copy) v_u_264, (ref) v_u_103
				if v_u_106 ~= v_u_264.id then
					v_u_106 = v_u_264.id
					v_u_103.draw()
				end
			end)
			local v274 = v_u_100 and 30 or 38
			local v275 = v_u_99.itemCell(v270, v_u_264.id, {
				["size"] = nil,
				["w"] = 2,
				["h"] = 1,
				["size"] = v274
			})
			v275.Position = UDim2.fromOffset(16, 12)
			v275.ZIndex = 2
			local v276 = v274 * 2 + 16 + 14
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["zindex"] = 2,
				["parent"] = v270,
				["text"] = v_u_264.name,
				["position"] = UDim2.fromOffset(v276, 8),
				["size"] = UDim2.new(1, -v276 - 160, 0, 24)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["zindex"] = 2,
				["parent"] = v270,
				["text"] = ("%s: %d"):format(v_u_102.stash, v266),
				["color"] = v_u_98.text2,
				["position"] = UDim2.fromOffset(v276, 34),
				["size"] = UDim2.new(1, -v276 - 160, 0, 18)
			})
			local v277, v278 = v_u_96.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "primary",
				["width"] = 120,
				["height"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["name"] = "Scan",
				["zindex"] = 3,
				["onClick"] = nil,
				["parent"] = v270,
				["text"] = v_u_102.scan,
				["height"] = v261,
				["anchor"] = Vector2.new(1, 0),
				["position"] = UDim2.new(1, -14, 0, 14),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_103, (copy) v_u_264
					v_u_103.scan(v_u_264.id)
				end
			})
			local v279 = v278.setEnabled
			local v280
			if v_u_264.canScan == true then
				local v281 = p_u_95.busy() or v_u_110
				v280 = not v281
			else
				v280 = false
			end
			v279(v280)
			if v_u_114 == nil and v_u_264.canScan == true then
				v_u_114 = v277
			end
			if not v267 then
				continue
			end
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["zindex"] = 2,
				["parent"] = v270,
				["text"] = v_u_264.whyScan,
				["color"] = v_u_98.muted,
				["position"] = UDim2.fromOffset(16, 82),
				["size"] = UDim2.new(1, -32, 0, 30)
			})
		end
		if v262 == 0 then
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v260,
				["text"] = v_u_102.error,
				["color"] = v_u_98.muted
			})
		end
		return v260
	end
	local function v_u_297(p283, _, p284) -- name: buildPrices
		-- upvalues: (copy) v_u_96, (copy) v_u_102, (copy) v_u_99, (copy) p_u_95, (ref) v_u_106, (copy) v_u_97, (copy) v_u_103, (ref) v_u_4, (copy) v_u_98, (ref) v_u_7
		local v285 = v_u_96.new("Frame", {
			["Name"] = "Prices",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p284
		}, p283)
		v_u_96.layout(v285, "v", 8)
		local v286 = v_u_102.prices
		v_u_99.section(v285, v286, 1)
		local v287 = v_u_96.new("Frame", {
			["Name"] = "CaseChips",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v285)
		local v288 = v_u_96.layout(v287, "h", 8)
		v288.Wraps = true
		v288.SortOrder = Enum.SortOrder.LayoutOrder
		for v289, v_u_290 in p_u_95.view() and p_u_95.view().crates or {} do
			if p_u_95.only ~= nil then
				break
			end
			v_u_96.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = nil,
				["height"] = nil,
				["width"] = 110,
				["name"] = nil,
				["order"] = nil,
				["onClick"] = nil,
				["parent"] = v287,
				["text"] = v_u_290.short or v_u_290.name,
				["kind"] = v_u_106 == v_u_290.id and "primary" or "secondary",
				["height"] = v_u_97.touch(36),
				["name"] = "Chip_" .. v_u_290.id,
				["order"] = v289,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_106, (copy) v_u_290, (ref) v_u_103
					if v_u_106 ~= v_u_290.id then
						v_u_106 = v_u_290.id
						v_u_103.draw()
					end
				end
			})
		end
		for v291, v292 in v_u_4.priceRows(p_u_95.view(), v_u_106) do
			local v293 = v_u_96.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.18,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Price_" .. v292.rarity,
				["BackgroundColor3"] = v_u_98.raised,
				["Size"] = UDim2.new(1, 0, 0, v_u_97.touch(40)),
				["LayoutOrder"] = 10 + v291
			}, v285)
			v_u_96.stroke(v293, v_u_98.line)
			v_u_96.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_97.rarityColor(v292.rarity),
				["Size"] = UDim2.new(0, 4, 1, 0)
			}, v293)
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v293,
				["text"] = v292.word,
				["color"] = v_u_97.rarityColor(v292.rarity),
				["position"] = UDim2.fromOffset(14, 0),
				["size"] = UDim2.new(0, 110, 1, 0)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v293,
				["text"] = ("%d %s"):format(v292.count, v292.count == 1 and "finish" or "finishes"),
				["color"] = v_u_98.text2,
				["position"] = UDim2.fromOffset(128, 0),
				["size"] = UDim2.new(0, 90, 1, 0)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v293,
				["text"] = ("%s %%"):format(v292.pct),
				["color"] = v_u_98.text2,
				["anchor"] = Vector2.new(1, 0),
				["position"] = UDim2.new(1, -110, 0, 0),
				["size"] = UDim2.new(0, 90, 1, 0)
			})
			v_u_96.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "mono",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v293,
				["text"] = not v292.price and "n/a" or ("R$ %s"):format(v_u_4.robux(v292.price)),
				["color"] = v_u_98.text,
				["anchor"] = Vector2.new(1, 0),
				["position"] = UDim2.new(1, -12, 0, 0),
				["size"] = UDim2.new(0, 90, 1, 0)
			})
		end
		v_u_96.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 98,
			["parent"] = v285,
			["text"] = v_u_102.pricesNote,
			["color"] = v_u_98.muted
		})
		local v294 = p_u_95.view()
		local v295 = v_u_7.tallyScan(type(v294) == "table" and {
			["tally"] = v294.tally == true
		} or nil)
		if v295 ~= "" then
			v_u_96.label({
				["parent"] = nil,
				["name"] = "TallyNote",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 99,
				["parent"] = v285,
				["text"] = v295,
				["color"] = v_u_98.accent
			})
		end
		local v296 = p_u_95.odds
		if type(v296) == "function" and v_u_106 then
			v_u_96.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["width"] = 120,
				["name"] = "Odds",
				["order"] = 100,
				["onClick"] = nil,
				["parent"] = v285,
				["text"] = v_u_102.odds,
				["height"] = v_u_97.touch(38),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_95, (ref) v_u_106
					p_u_95.odds(v_u_106)
				end
			})
		end
		return v285
	end
	function v_u_103.draw() -- name: draw
		-- upvalues: (ref) v_u_105, (ref) v_u_114, (copy) v_u_180, (copy) v_u_104, (copy) p_u_95, (ref) v_u_4, (copy) v_u_96, (copy) v_u_102, (copy) v_u_98, (copy) v_u_117, (ref) v_u_106, (ref) v_u_110, (ref) v_u_112, (copy) v_u_206, (copy) v_u_210, (copy) v_u_257, (copy) v_u_282, (copy) v_u_100, (copy) v_u_297, (copy) v_u_101
		if v_u_105 then
			v_u_114 = nil
			for _, v298 in v_u_180 do
				local v299 = v298.destroy
				pcall(v299)
			end
			table.clear(v_u_180)
			for _, v300 in v_u_104:GetChildren() do
				v300:Destroy()
			end
			local v301 = p_u_95.view()
			local v_u_302 = v_u_4.state(v301)
			if v_u_302 == "loading" then
				v_u_96.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_104,
					["text"] = v_u_102.loading,
					["color"] = v_u_98.muted
				})
				return
			elseif v_u_302 == "off" or v_u_302 == "pending" then
				local v303 = v_u_96.label
				local v304 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_104
				}
				local v305
				if v_u_302 == "pending" then
					v305 = v_u_102.pending
				else
					v305 = v_u_102.off
				end
				v304.text = v305
				v304.color = v_u_98.muted
				v303(v304)
				return
			else
				local v_u_306 = v301.scan
				local v307 = v_u_306.open
				if v307 then
					v307 = v_u_306.open.crate
				end
				if p_u_95.only == nil or not v_u_117(p_u_95.only) then
					if v307 and v_u_117(v307) then
						v_u_106 = v307
					elseif v_u_106 == nil or v_u_117(v_u_106) == nil then
						v_u_106 = nil
						for _, v308 in v301.crates or {} do
							local v309 = v308.count
							if (tonumber(v309) or 0) <= 0 then
								continue
							end
							v_u_106 = v308.id
						end
						local v310 = not v_u_106 and (v301.crates and v301.crates[1])
						if v310 then
							v310 = v301.crates[1].id
						end
						v_u_106 = v310
					end
				else
					v_u_106 = p_u_95.only
				end
				if v_u_110 and v_u_306.open == nil then
					v_u_110 = false
				elseif v_u_110 and (v_u_306.open and (v_u_306.open.payHeld ~= true and os.clock() - v_u_112 > 4)) then
					v_u_110 = false
				end
				local function v312(p311) -- name: body
					-- upvalues: (ref) v_u_206, (copy) v_u_306, (ref) v_u_210, (ref) v_u_257, (copy) v_u_302, (ref) v_u_96, (ref) v_u_102, (ref) v_u_98, (ref) v_u_282
					v_u_206(p311, v_u_306, 1)
					v_u_210(p311, 2)
					if v_u_306.open then
						v_u_257(p311, v_u_306, 3)
					elseif v_u_302 == "empty" then
						v_u_96.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 3,
							["parent"] = p311,
							["text"] = v_u_102.empty,
							["color"] = v_u_98.muted
						})
					end
					if not v_u_306.open then
						v_u_282(p311, v_u_306, 4)
					end
				end
				if v_u_100 then
					local v313 = v_u_96.list({
						["parent"] = nil,
						["name"] = "PhoneList",
						["size"] = nil,
						["gap"] = 12,
						["padding"] = nil,
						["parent"] = v_u_104,
						["size"] = UDim2.fromScale(1, 1),
						["padding"] = {
							0,
							6,
							0,
							8
						}
					})
					v312(v313)
					v_u_297(v313, v_u_306, 20)
				else
					local v314 = v_u_101 and 440 or 560
					v312((v_u_96.list({
						["parent"] = nil,
						["name"] = "Bench",
						["size"] = nil,
						["gap"] = 12,
						["padding"] = nil,
						["parent"] = v_u_104,
						["size"] = UDim2.new(0, v314, 1, 0),
						["padding"] = {
							0,
							6,
							0,
							8
						}
					})))
					v_u_297(v_u_96.list({
						["parent"] = nil,
						["name"] = "PriceList",
						["position"] = nil,
						["size"] = nil,
						["gap"] = 10,
						["padding"] = nil,
						["parent"] = v_u_104,
						["position"] = UDim2.fromOffset(v314 + 18, 0),
						["size"] = UDim2.new(1, -(v314 + 18), 1, 0),
						["padding"] = {
							0,
							6,
							0,
							8
						}
					}), v_u_306, 1)
				end
			end
		else
			return
		end
	end
	function v_u_103.focus() -- name: focus
		-- upvalues: (copy) v_u_96, (ref) v_u_114, (ref) v_u_1
		if v_u_96.device() == "Gamepad" and (v_u_114 and (v_u_114.Parent and v_u_114:GetAttribute("Disabled") ~= true)) then
			v_u_1.SelectedObject = v_u_114
		end
	end
	function v_u_103.state() -- name: state
		-- upvalues: (ref) v_u_106, (ref) v_u_107, (ref) v_u_110
		return {
			["sel"] = v_u_106,
			["revealing"] = os.clock() < v_u_107,
			["pending"] = v_u_110
		}
	end
	local v_u_315
	if p_u_94.changed and p_u_94.changed.Connect then
		v_u_315 = p_u_94.changed:Connect(function(p316, p317)
			-- upvalues: (copy) v_u_109, (ref) v_u_110, (ref) v_u_113, (copy) v_u_96, (copy) p_u_94, (copy) p_u_95
			if p316 == "result" and type(p317) == "table" then
				if p317.req == nil or not v_u_109[p317.req] then
					if p317.op == "storeGrant" then
						if v_u_110 then
							v_u_110 = false
						end
						if p317.ok == true then
							local v318 = p317.msg
							if type(v318) == "string" then
								v_u_113 = {
									["text"] = nil,
									["kind"] = "success",
									["text"] = p317.msg
								}
								local v319 = p317.msg
								local v320 = v_u_96.toast
								pcall(v320, v319, "success")
							end
						end
						p_u_94.invalidate("crates")
						p_u_95.refetch()
					end
				else
					local v321 = v_u_109[p317.req]
					v_u_109[p317.req] = nil
					v321(p317)
				end
			else
				return
			end
		end)
	else
		v_u_315 = nil
	end
	function v_u_103.destroy() -- name: destroy
		-- upvalues: (ref) v_u_105, (copy) v_u_180, (ref) v_u_108, (ref) v_u_111, (ref) v_u_315, (copy) v_u_104
		v_u_105 = false
		for _, v322 in v_u_180 do
			local v323 = v322.destroy
			pcall(v323)
		end
		table.clear(v_u_180)
		v_u_108 = v_u_108 + 1
		v_u_111 = v_u_111 + 1
		if v_u_315 then
			local function v324()
				-- upvalues: (ref) v_u_315
				v_u_315:Disconnect()
			end
			pcall(v324)
		end
		v_u_104:Destroy()
	end
	return v_u_103
end
return v_u_4