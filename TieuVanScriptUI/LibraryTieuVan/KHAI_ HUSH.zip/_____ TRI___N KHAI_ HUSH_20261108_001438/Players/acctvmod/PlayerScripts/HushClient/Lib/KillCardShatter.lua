-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / KillCardShatter

local v_u_1 = {
	["THICK_MAX"] = 4,
	["THICK_MIN"] = 1.2,
	["REVEAL_SEC"] = 0.14,
	["FLASH_SEC"] = 0.18
}
local function v_u_4() -- name: cracksLib
	local v2 = script.Parent
	local v3 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
	if v3 then
		v3 = v3:FindFirstChild("Shared")
	end
	if v3 then
		v3 = v3:FindFirstChild("KillCardCracks")
	end
	if v3 == nil and v2 ~= nil then
		v3 = v2:FindFirstChild("KillCardCracks")
	end
	return require(v3)
end
function v_u_1.plan(p5, p6, p7, p8) -- name: plan
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v9 = p8 or v_u_4()
	local v10 = (type(p5) ~= "number" or p5 ~= p5) and 1 or p5
	local v11 = math.max(1, v10)
	local v12 = (type(p6) ~= "number" or p6 ~= p6) and 1 or p6
	local v13 = math.max(1, v12)
	local v14 = v9.build(p7, v11 / v13)
	local v15 = {}
	for _, v16 in v14.segs do
		local v17, v18, v19, v20 = v9.rotOf(v16.x1 * v13, v16.y1 * v13, v16.x2 * v13, v16.y2 * v13)
		local v21 = v_u_1.THICK_MIN + (v_u_1.THICK_MAX - v_u_1.THICK_MIN) * v16.w
		local v22 = {
			["cx"] = v17,
			["cy"] = v18,
			["len"] = math.max(v19, 1),
			["th"] = v21,
			["rot"] = v20,
			["d0"] = v16.d0 * v13,
			["kind"] = v16.kind,
			["w"] = v16.w
		}
		table.insert(v15, v22)
	end
	local v23 = {}
	for _, v24 in v14.shards do
		local v25 = {
			["cx"] = v24.cx * v13,
			["cy"] = v24.cy * v13,
			["w"] = v24.w * v13,
			["h"] = v24.h * v13,
			["rot"] = v24.rot,
			["a"] = v24.a,
			["d0"] = v24.d0 * v13
		}
		table.insert(v23, v25)
	end
	return {
		["lines"] = v15,
		["shards"] = v23,
		["impact"] = {
			["x"] = v14.cx * v13,
			["y"] = v14.cy * v13
		},
		["maxR"] = v14.maxR * v13
	}
end
function v_u_1.reveal(p26) -- name: reveal
	-- upvalues: (copy) v_u_1
	local v27 = ((type(p26) ~= "number" or p26 ~= p26) and 0 or p26) / v_u_1.REVEAL_SEC
	local v28 = math.clamp(v27, 0, 1)
	return 1 - (1 - v28) * (1 - v28)
end
function v_u_1.flashAlpha(p29) -- name: flashAlpha
	-- upvalues: (copy) v_u_1
	local v30 = 1 - ((type(p29) ~= "number" or p29 ~= p29) and 0 or p29) / v_u_1.FLASH_SEC
	return math.clamp(v30, 0, 1)
end
function v_u_1.new(p_u_31, p32, p_u_33) -- name: new
	-- upvalues: (copy) v_u_1
	local v34 = {}
	local v_u_35 = true
	local v_u_36 = p32 or 6
	local v_u_37 = Instance.new("Frame")
	v_u_37.Name = "KcShatter"
	v_u_37.BackgroundTransparency = 1
	v_u_37.BorderSizePixel = 0
	v_u_37.ClipsDescendants = true
	v_u_37.Size = UDim2.fromScale(1, 1)
	v_u_37.ZIndex = v_u_36
	v_u_37.Visible = false
	v_u_37.Parent = p_u_31
	local v_u_38 = Instance.new("Frame")
	v_u_38.Name = "Tint"
	v_u_38.BackgroundColor3 = Color3.fromRGB(8, 12, 20)
	v_u_38.BorderSizePixel = 0
	v_u_38.Size = UDim2.fromScale(1, 1)
	v_u_38.ZIndex = v_u_36
	v_u_38.Parent = v_u_37
	local v_u_39 = Instance.new("Frame")
	v_u_39.Name = "Flash"
	v_u_39.BackgroundColor3 = Color3.fromRGB(255, 250, 235)
	v_u_39.BorderSizePixel = 0
	v_u_39.Size = UDim2.fromScale(1, 1)
	v_u_39.ZIndex = v_u_36 + 3
	v_u_39.Parent = v_u_37
	local v_u_40 = {}
	local v_u_41 = {}
	local v_u_42 = ""
	local v_u_43 = nil
	local function v_u_46() -- name: clearFrames
		-- upvalues: (ref) v_u_40, (ref) v_u_41, (ref) v_u_42
		for _, v44 in v_u_40 do
			v44.fr:Destroy()
		end
		for _, v45 in v_u_41 do
			v45.fr:Destroy()
		end
		v_u_40 = {}
		v_u_41 = {}
		v_u_42 = ""
	end
	local function v_u_65(p47) -- name: build
		-- upvalues: (copy) v_u_37, (copy) p_u_33, (copy) p_u_31, (ref) v_u_42, (copy) v_u_46, (ref) v_u_43, (ref) v_u_1, (copy) v_u_36, (ref) v_u_41, (ref) v_u_40
		local v48 = v_u_37.AbsoluteSize
		if v48.X < 2 or v48.Y < 2 then
			local function v49()
				-- upvalues: (ref) p_u_33, (ref) p_u_31
				if p_u_33 then
					return p_u_33()
				else
					return Vector2.new(p_u_31.Size.X.Offset, p_u_31.Size.Y.Offset)
				end
			end
			local v50
			v50, v48 = pcall(v49)
			if not v50 or (typeof(v48) ~= "Vector2" or (v48.X < 2 or v48.Y < 2)) then
				v48 = Vector2.new(256, 256)
			end
		end
		local v51 = tostring(p47)
		local v52 = v48.X
		local v53 = math.floor(v52)
		local v54 = v48.Y
		local v55 = ("%s|%d|%d"):format(v51, v53, (math.floor(v54)))
		if v55 ~= v_u_42 then
			v_u_46()
			v_u_42 = v55
			v_u_43 = v_u_1.plan(v48.X, v48.Y, p47)
			for _, v56 in v_u_43.shards do
				local v57 = Instance.new("Frame")
				v57.Name = "Pane"
				v57.AnchorPoint = Vector2.new(0.5, 0.5)
				v57.Position = UDim2.fromOffset(v56.cx, v56.cy)
				v57.Size = UDim2.fromOffset(v56.w, v56.h)
				v57.Rotation = v56.rot
				v57.BackgroundColor3 = Color3.fromRGB(205, 228, 255)
				v57.BorderSizePixel = 0
				v57.ZIndex = v_u_36 + 1
				v57.Visible = false
				v57.Parent = v_u_37
				local v58 = v_u_41
				local v59 = {
					["fr"] = v57,
					["d0"] = v56.d0,
					["a"] = v56.a
				}
				table.insert(v58, v59)
			end
			for _, v60 in v_u_43.lines do
				local v61 = Instance.new("Frame")
				v61.Name = "Crack"
				v61.AnchorPoint = Vector2.new(0.5, 0.5)
				v61.Position = UDim2.fromOffset(v60.cx, v60.cy)
				v61.Size = UDim2.fromOffset(v60.len, v60.th)
				v61.Rotation = v60.rot
				local v62
				if v60.kind == "ray" then
					v62 = Color3.fromRGB(246, 250, 255)
				else
					v62 = Color3.fromRGB(214, 228, 244)
				end
				v61.BackgroundColor3 = v62
				v61.BorderSizePixel = 0
				v61.ZIndex = v_u_36 + 2
				v61.Visible = false
				v61.Parent = v_u_37
				local v63 = v_u_40
				local v64 = {
					["fr"] = v61,
					["d0"] = v60.d0,
					["kind"] = v60.kind,
					["w"] = v60.w
				}
				table.insert(v63, v64)
			end
		end
	end
	function v34.set(p66, p67, p68) -- name: set
		-- upvalues: (ref) v_u_35, (copy) v_u_37, (copy) v_u_65, (ref) v_u_1, (ref) v_u_43, (copy) v_u_38, (copy) v_u_39, (ref) v_u_40, (ref) v_u_41
		if v_u_35 then
			local v69 = (type(p66) ~= "number" or p66 ~= p66) and 0 or math.clamp(p66, 0, 1)
			if v69 <= 0 then
				v_u_37.Visible = false
			else
				v_u_65(p67)
				local v70 = (type(p68) ~= "number" or p68 ~= p68) and 0 or p68
				local v71 = v_u_1.reveal(v70) * (v_u_43.maxR or 1) * 1.7
				v_u_37.Visible = true
				v_u_38.BackgroundTransparency = 1 - v69 * 0.22 * v_u_1.reveal(v70)
				v_u_39.BackgroundTransparency = 1 - 0.85 * v_u_1.flashAlpha(v70) * v69
				for _, v72 in v_u_40 do
					local v73 = v72.d0 <= v71
					v72.fr.Visible = v73
					if not v73 then
						continue
					end
					v72.fr.BackgroundTransparency = 1 - (v72.kind == "ray" and 0.95 or (v72.kind == "branch" and 0.7 or 0.78)) * v69
				end
				for _, v74 in v_u_41 do
					local v75 = v74.d0 <= v71
					v74.fr.Visible = v75
					if not v75 then
						continue
					end
					v74.fr.BackgroundTransparency = 1 - 0.2 * v74.a * v69
				end
			end
		else
			return
		end
	end
	function v34.count() -- name: count
		-- upvalues: (ref) v_u_40, (ref) v_u_41
		return #v_u_40 + #v_u_41
	end
	function v34.visible() -- name: visible
		-- upvalues: (copy) v_u_37
		return v_u_37.Visible
	end
	function v34.host() -- name: host
		-- upvalues: (copy) v_u_37
		return v_u_37
	end
	function v34.destroy() -- name: destroy
		-- upvalues: (ref) v_u_35, (copy) v_u_37, (ref) v_u_40, (ref) v_u_41
		v_u_35 = false
		local function v76()
			-- upvalues: (ref) v_u_37
			v_u_37:Destroy()
		end
		pcall(v76)
		v_u_40 = {}
		v_u_41 = {}
	end
	return v34
end
return v_u_1