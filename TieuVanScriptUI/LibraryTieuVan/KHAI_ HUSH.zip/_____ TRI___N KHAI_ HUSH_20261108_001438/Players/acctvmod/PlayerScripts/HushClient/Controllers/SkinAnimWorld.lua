-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / SkinAnimWorld

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {
	["name"] = "SkinAnimWorld",
	["order"] = 92,
	["TUNE"] = {
		["tick"] = 0.5,
		["cap"] = 4,
		["capTouch"] = 2,
		["range"] = 60,
		["retry"] = 3,
		["seen"] = 400,
		["hysteresis"] = 4
	}
}
local v_u_5 = v_u_4.TUNE
v_u_4.HELD = "HeldWeapon"
v_u_4.BACK = "BackWeapon"
local v_u_6 = {}
function v_u_4.touch() -- name: touch
	-- upvalues: (copy) v_u_3
	local function v8()
		-- upvalues: (ref) v_u_3
		local v7 = v_u_3.TouchEnabled
		if v7 then
			v7 = not v_u_3.MouseEnabled
		end
		return v7
	end
	local v9, v10 = pcall(v8)
	if v9 then
		v9 = v10 == true
	end
	return v9
end
function v_u_4.characters() -- name: characters
	-- upvalues: (copy) v_u_1
	local v11 = v_u_1.LocalPlayer
	local v12 = {}
	for _, v13 in v_u_1:GetPlayers() do
		local v14 = v13.Character
		if not v14 then
			continue
		end
		local v15 = {
			["char"] = v14,
			["own"] = v13 == v11
		}
		table.insert(v12, v15)
	end
	return v12
end
function v_u_4.cameraView() -- name: cameraView
	local v16 = workspace.CurrentCamera
	if v16 then
		return v16.Focus.Position, v16.CFrame.LookVector, v16.CFrame.Position
	else
		return nil, nil, nil
	end
end
function v_u_4.capNow() -- name: capNow
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_2
	local v17
	if v_u_4.touch() then
		v17 = v_u_5.capTouch
	else
		v17 = v_u_5.cap
	end
	local v18 = v_u_6.SkinApply
	if v18 == nil then
		local v_u_19 = "SkinApply"
		local function v21()
			-- upvalues: (ref) v_u_2, (copy) v_u_19
			local v20 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v20:WaitForChild(v_u_19, 5)))
		end
		local v22
		v22, v18 = pcall(v21)
		if not v22 then
			v18 = false
		end
		v_u_6.SkinApply = v18
	end
	if v18 then
		local v23 = v18.MAX_ANIM_WORLD
		if type(v23) == "number" then
			local v24 = v18.MAX_ANIM_WORLD
			v17 = math.min(v17, v24)
		end
	end
	return v17
end
function v_u_4.kindOf(p25, p26) -- name: kindOf
	-- upvalues: (copy) v_u_6, (copy) v_u_2
	local v27 = v_u_6.Skins
	if v27 == nil then
		local v_u_28 = "Skins"
		local function v30()
			-- upvalues: (ref) v_u_2, (copy) v_u_28
			local v29 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v29:WaitForChild(v_u_28, 5)))
		end
		local v31
		v31, v27 = pcall(v30)
		if not v31 then
			v27 = false
		end
		v_u_6.Skins = v27
	end
	local v32 = v_u_6.SkinFinishes
	if v32 == nil then
		local v_u_33 = "SkinFinishes"
		local function v35()
			-- upvalues: (ref) v_u_2, (copy) v_u_33
			local v34 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v34:WaitForChild(v_u_33, 5)))
		end
		local v36
		v36, v32 = pcall(v35)
		if not v36 then
			v32 = false
		end
		v_u_6.SkinFinishes = v32
	end
	if v27 and (v32 and type(p26) == "string") then
		local v37 = v27.get(p26)
		if v37 then
			v37 = v32.get(v37.finish)
		end
		if v37 then
			return v37.texAnim and p25:GetAttribute("SkinTex") == p26 and "tint" or (v37.anim and "colour" or nil)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_4.pick(p38, p39) -- name: pick
	-- upvalues: (copy) v_u_5
	local v40 = table.clone(p38)
	table.sort(v40, function(p41, p42)
		-- upvalues: (ref) v_u_5
		if p41.prio ~= p42.prio then
			return p41.prio < p42.prio
		end
		local v43 = p41.dist - (not p41.live and 0 or v_u_5.hysteresis)
		local v44 = p42.dist - (not p42.live and 0 or v_u_5.hysteresis)
		if v43 ~= v44 then
			return v43 < v44
		end
		local v45 = p41.key
		local v46 = tostring(v45)
		local v47 = p42.key
		return v46 < tostring(v47)
	end)
	local v48 = #v40
	local v49 = {}
	for v50 = 1, math.min(p39, v48) do
		local v51 = v40[v50]
		table.insert(v49, v51)
	end
	return v49
end
local v_u_52 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_53 = 0
local v_u_54 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_55 = {}
local v_u_56 = 0
local v_u_57 = false
local function v_u_64(p58) -- name: snapshot
	local v59 = {}
	local v60 = {}
	for _, v61 in p58:GetDescendants() do
		if v61:IsA("BasePart") then
			if v61:GetAttribute("SkinClass") == nil then
				continue
			end
			local v62 = {
				["p"] = v61,
				["color"] = v61.Color
			}
			table.insert(v59, v62)
		else
			if not v61:IsA("SurfaceAppearance") or v61.Name ~= "SkinTexAppearance" then
				continue
			end
			local v63 = {
				["sa"] = v61,
				["tint"] = v61.EmissiveTint
			}
			table.insert(v60, v63)
		end
	end
	return v59, v60
end
local function v_u_68(p65) -- name: restore
	for _, v66 in p65.parts do
		if not v66.p.Parent then
			continue
		end
		v66.p.Color = v66.color
	end
	for _, v67 in p65.tints do
		if not v67.sa.Parent then
			continue
		end
		v67.sa.EmissiveTint = v67.tint
	end
end
function v_u_4.stop() -- name: stop
	-- upvalues: (copy) v_u_55, (copy) v_u_68, (ref) v_u_56
	for v69, v70 in table.clone(v_u_55) do
		v_u_55[v69] = nil
		local v71 = v70.stop
		pcall(v71)
		if v69:GetAttribute("SkinHidden") == true then
			continue
		end
		v_u_68(v70)
	end
	v_u_56 = 0
end
function v_u_4.active() -- name: active
	-- upvalues: (copy) v_u_55
	local v72 = 0
	for _ in v_u_55 do
		v72 = v72 + 1
	end
	return v72
end
function v_u_4.enabled() -- name: enabled
	-- upvalues: (copy) v_u_6, (copy) v_u_2
	local v73 = v_u_6.SkinVisibility
	if v73 == nil then
		local v_u_74 = "SkinVisibility"
		local function v76()
			-- upvalues: (ref) v_u_2, (copy) v_u_74
			local v75 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v75:WaitForChild(v_u_74, 5)))
		end
		local v77
		v77, v73 = pcall(v76)
		if not v77 then
			v73 = false
		end
		v_u_6.SkinVisibility = v73
	end
	return (not v73 or (not v73.enabled or v73.enabled())) and true or false
end
function v_u_4.otherFx() -- name: otherFx
	-- upvalues: (copy) v_u_1
	local v78 = v_u_1.LocalPlayer
	return v78 == nil and true or v78:GetAttribute("SkinFx") ~= false
end
function v_u_4.remember(p79) -- name: remember
	-- upvalues: (copy) v_u_52, (ref) v_u_53, (copy) v_u_5
	if v_u_52[p79] or v_u_53 >= v_u_5.seen then
		return false
	end
	if p79:GetAttribute("SkinId") == nil then
		return false
	end
	v_u_52[p79] = true
	v_u_53 = v_u_53 + 1
	return true
end
local function v_u_101(p_u_80, p81, p82, p83, p84, p85, p86, p87) -- name: entryOf
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_55, (copy) v_u_54, (copy) v_u_5
	if p87[p_u_80] or not (p_u_80:IsA("Model") and p_u_80:IsDescendantOf(workspace)) then
		return nil
	end
	p87[p_u_80] = true
	local v88 = p_u_80:GetAttribute("SkinId")
	if type(v88) ~= "string" or p_u_80:GetAttribute("SkinHidden") == true then
		return nil
	end
	if p_u_80:FindFirstAncestorWhichIsA("GuiBase2d") then
		return nil
	end
	local v89 = v_u_4.kindOf(p_u_80, v88)
	if not v89 then
		return nil
	end
	local v90 = v_u_6.SkinApply
	if v90 == nil then
		local v_u_91 = "SkinApply"
		local function v93()
			-- upvalues: (ref) v_u_2, (copy) v_u_91
			local v92 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v92:WaitForChild(v_u_91, 5)))
		end
		local v94
		v94, v90 = pcall(v93)
		if not v94 then
			v90 = false
		end
		v_u_6.SkinApply = v90
	end
	local v95 = v_u_55[p_u_80]
	if not v95 and (v90.isAnimated(p_u_80) or p85 < (v_u_54[p_u_80] or 0)) then
		return nil
	end
	local v96
	if p81 == nil then
		v96 = false
	else
		v96 = p_u_80:IsDescendantOf(p81)
	end
	local v97 = 0
	local v98
	if v96 then
		if p_u_80.Name == v_u_4.HELD then
			v98 = 0
		else
			v98 = 1
		end
	else
		if not p86 then
			return nil
		end
		v98 = 2
		local v99, v100 = pcall(function()
			-- upvalues: (copy) p_u_80
			return p_u_80:GetPivot().Position
		end)
		if not v99 then
			return nil
		end
		if p82 then
			v97 = (v100 - p82).Magnitude
			if v_u_5.range < v97 then
				return nil
			end
		end
		if p83 and (p84 and (v100 - p84):Dot(p83) < 0) then
			return nil
		end
	end
	return {
		["model"] = p_u_80,
		["skin"] = v88,
		["kind"] = v89,
		["prio"] = v98,
		["dist"] = v97,
		["key"] = p_u_80:GetFullName(),
		["live"] = v95 ~= nil
	}
end
local function v_u_120(p102) -- name: collect
	-- upvalues: (copy) v_u_4, (copy) v_u_101, (copy) v_u_52, (ref) v_u_53
	local v103, v104, v105 = v_u_4.cameraView()
	local v106 = v_u_4.otherFx()
	local v107 = v_u_4.characters()
	local v108 = {}
	local v109 = nil
	local v110 = {}
	for _, v111 in v107 do
		if not v111.own then
			continue
		end
		v109 = v111.char
	end
	for _, v112 in v107 do
		local v113 = v112.char:FindFirstChild(v_u_4.HELD)
		local v114 = v113 and v_u_101(v113, v109, v103, v104, v105, p102, v106, v110)
		if v114 then
			table.insert(v108, v114)
		end
		local v115 = v112.char:FindFirstChild(v_u_4.BACK)
		if not v115 then
			continue
		end
		local v116 = v_u_101(v115, v109, v103, v104, v105, p102, v106, v110)
		if not v116 then
			continue
		end
		table.insert(v108, v116)
	end
	local v117 = 0
	for v118 in table.clone(v_u_52) do
		if v118.Parent == nil or type(v118:GetAttribute("SkinId")) ~= "string" then
			v_u_52[v118] = nil
		else
			v117 = v117 + 1
			if not v118 then
				continue
			end
			local v119 = v_u_101(v118, v109, v103, v104, v105, p102, v106, v110)
			if not v119 then
				continue
			end
			table.insert(v108, v119)
		end
	end
	v_u_53 = v117
	return v108
end
function v_u_4.tick(p121) -- name: tick
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_55, (copy) v_u_68, (copy) v_u_4, (copy) v_u_120, (copy) v_u_64, (copy) v_u_54, (copy) v_u_5
	local v122 = p121 or os.clock()
	local v123 = v_u_6.SkinApply
	if v123 == nil then
		local v_u_124 = "SkinApply"
		local function v126()
			-- upvalues: (ref) v_u_2, (copy) v_u_124
			local v125 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
			return require((v125:WaitForChild(v_u_124, 5)))
		end
		local v127
		v127, v123 = pcall(v126)
		if not v127 then
			v123 = false
		end
		v_u_6.SkinApply = v123
	end
	if v123 and v123.isAnimated then
		for v128, v129 in table.clone(v_u_55) do
			if v123.isAnimated(v128, v129.skin) then
				continue
			end
			v_u_55[v128] = nil
			if v128:GetAttribute("SkinHidden") == true then
				continue
			end
			v_u_68(v129)
		end
		if v_u_4.enabled() then
			local v130 = v_u_4.pick(v_u_120(v122), v_u_4.capNow())
			local v131 = {}
			for _, v132 in v130 do
				v131[v132.model] = v132
			end
			for v133, v134 in table.clone(v_u_55) do
				local v135 = v131[v133]
				if v135 and (v135.skin == v134.skin and v135.kind == v134.kind) then
					continue
				end
				v_u_55[v133] = nil
				local v136 = v134.stop
				pcall(v136)
				if v133:GetAttribute("SkinHidden") == true then
					continue
				end
				v_u_68(v134)
			end
			for _, v137 in v130 do
				if v_u_55[v137.model] then
					continue
				end
				local v138, v139 = v_u_64(v137.model)
				local v140 = v123.animate
				local v141 = v137.model
				local v142 = v137.skin
				local v143, v144 = pcall(v140, v141, v142, {
					["world"] = true
				})
				if v143 and (type(v144) == "function" and v123.isAnimated(v137.model, v137.skin)) then
					v_u_55[v137.model] = {
						["skin"] = v137.skin,
						["kind"] = v137.kind,
						["stop"] = v144,
						["parts"] = v138,
						["tints"] = v139
					}
				else
					v_u_54[v137.model] = v122 + v_u_5.retry
				end
			end
		else
			v_u_4.stop()
		end
	else
		return
	end
end
function v_u_4.init(p145) -- name: init
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_55, (copy) v_u_4
	p145.command("skinanim.state", function()
		-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_55, (ref) v_u_4
		local v146 = v_u_6.SkinApply
		if v146 == nil then
			local v_u_147 = "SkinApply"
			local function v149()
				-- upvalues: (ref) v_u_2, (copy) v_u_147
				local v148 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
				return require((v148:WaitForChild(v_u_147, 5)))
			end
			local v150
			v150, v146 = pcall(v149)
			if not v150 then
				v146 = false
			end
			v_u_6.SkinApply = v146
		end
		local v151 = {}
		for v152, v153 in v_u_55 do
			local v154 = v152:GetFullName()
			local v155 = v153.skin
			local v156 = v153.kind
			table.insert(v151, ("%s=%s/%s"):format(v154, v155, v156))
		end
		table.sort(v151)
		local v157 = "skin anim world: %d drift (cap %d), SkinApply world %s of %s, previews %s; %s"
		local v158 = v_u_4.active()
		local v159 = v_u_4.capNow()
		local v160 = v146 and v146.worldAnimatedCount
		if v160 then
			v160 = v146.worldAnimatedCount()
		end
		local v161 = tostring(v160)
		local v162
		if v146 then
			v162 = v146.MAX_ANIM_WORLD
		else
			v162 = v146
		end
		local v163 = tostring(v162)
		local v164 = v146 and v146.animatedCount
		if v164 then
			v164 = v146.animatedCount()
		end
		return v157:format(v158, v159, v161, v163, tostring(v164), table.concat(v151, " | "))
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_57, (copy) v_u_4, (ref) v_u_56, (copy) v_u_5, (copy) v_u_1
	if not v_u_57 then
		v_u_57 = true
		workspace.DescendantAdded:Connect(function(p165)
			-- upvalues: (ref) v_u_4, (ref) v_u_56, (ref) v_u_5
			if p165:IsA("Model") and v_u_4.remember(p165) then
				v_u_56 = v_u_5.tick
			end
		end)
		local v166 = v_u_1.LocalPlayer
		if v166 then
			local function v170() -- name: now
				-- upvalues: (ref) v_u_4
				local v167 = v_u_4.tick
				local v168, v169 = pcall(v167)
				if not v168 then
					warn("[SkinAnimWorld] " .. tostring(v169))
				end
			end
			v166:GetAttributeChangedSignal("WeaponSkins"):Connect(v170)
			v166:GetAttributeChangedSignal("SkinFx"):Connect(v170)
		end
	end
end
function v_u_4.step(p171) -- name: step
	-- upvalues: (ref) v_u_56, (copy) v_u_5, (copy) v_u_4
	v_u_56 = v_u_56 + p171
	if v_u_56 >= v_u_5.tick then
		v_u_56 = 0
		v_u_4.tick()
	end
end
return v_u_4