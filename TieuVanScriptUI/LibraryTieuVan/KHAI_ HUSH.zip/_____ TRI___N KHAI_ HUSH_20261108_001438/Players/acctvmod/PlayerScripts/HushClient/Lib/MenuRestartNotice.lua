-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRestartNotice

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = {}
local v_u_6 = v2.LocalPlayer
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = false
local v_u_10 = nil
local v_u_11 = 0
local v_u_12 = false
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = 0
function v_u_5.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_10
	local v17
	if v_u_10 == nil or v_u_10.api == nil then
		v17 = false
	else
		v17 = v_u_10.api.frame.Parent ~= nil
	end
	return v17
end
function v_u_5.close() -- name: close
	-- upvalues: (ref) v_u_10
	local v18 = v_u_10
	v_u_10 = nil
	if v18 and v18.api then
		local v19 = v18.api.close
		pcall(v19)
	end
end
function v_u_5.state() -- name: state
	-- upvalues: (copy) v_u_5, (ref) v_u_10, (ref) v_u_11, (ref) v_u_16, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15
	local v20 = {
		["open"] = v_u_5.isOpen()
	}
	local v21
	if v_u_10 then
		v21 = v_u_10.id
	else
		v21 = nil
	end
	v20.shown = v21
	v20.dismissed = v_u_11
	v20.shows = v_u_16
	v20.raw = v_u_13
	v20.notice = v_u_14
	v20.preview = v_u_15 ~= nil
	return v20
end
local function v_u_22() -- name: nowServer
	-- upvalues: (copy) v_u_1
	return v_u_1.now()
end
local function v_u_30(p_u_23) -- name: idle
	local v24, v25 = pcall(function()
		-- upvalues: (copy) p_u_23
		return p_u_23.cctx.lib.MenuConnNotice
	end)
	if v24 and type(v25) == "table" then
		local v26 = v25.idle
		if type(v26) == "function" then
			local v27 = v25.idle
			local v28, v29 = pcall(v27, p_u_23)
			if v28 then
				v28 = v29 == true
			end
			return v28
		end
	end
	return false
end
local function v_u_40(p31, p_u_32) -- name: show
	-- upvalues: (ref) v_u_7, (copy) v_u_22, (ref) v_u_11, (ref) v_u_15, (copy) v_u_5, (ref) v_u_10, (ref) v_u_16
	local v_u_33 = p31.ui
	local v_u_34 = p31.theme.color
	local v_u_35 = {
		["id"] = nil,
		["notice"] = nil,
		["count"] = nil,
		["id"] = p_u_32.id,
		["notice"] = p_u_32
	}
	local v36 = v_u_33.modal
	local v39 = {
		["title"] = nil,
		["width"] = 520,
		["dismissable"] = false,
		["build"] = nil,
		["buttons"] = nil,
		["title"] = v_u_7.TITLE,
		["build"] = function(p37) -- name: build
			-- upvalues: (copy) v_u_33, (copy) p_u_32, (copy) v_u_34, (ref) v_u_7, (ref) v_u_22, (copy) v_u_35
			v_u_33.badge("HEADS UP", "warn", {
				["parent"] = nil,
				["order"] = 0,
				["name"] = "Status",
				["parent"] = p37
			})
			v_u_33.label({
				["parent"] = nil,
				["name"] = "Message",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["rich"] = false,
				["order"] = 1,
				["track"] = false,
				["parent"] = p37,
				["text"] = p_u_32.msg,
				["color"] = v_u_34.text
			})
			local v38 = v_u_7.line(p_u_32, v_u_22())
			if v38 then
				v_u_35.count = v_u_33.label({
					["parent"] = nil,
					["name"] = "Countdown",
					["text"] = nil,
					["style"] = "monoL",
					["color"] = nil,
					["autoY"] = true,
					["wrap"] = true,
					["order"] = 2,
					["track"] = false,
					["parent"] = p37,
					["text"] = v38,
					["color"] = v_u_34.accent
				})
			end
		end,
		["buttons"] = {
			{
				["text"] = nil,
				["kind"] = "primary",
				["onClick"] = nil,
				["text"] = v_u_7.BUTTON,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_11, (copy) p_u_32, (ref) v_u_15, (ref) v_u_5
					v_u_11 = p_u_32.id
					if v_u_15 and v_u_15.id == p_u_32.id then
						v_u_15 = nil
					end
					v_u_5.close()
				end
			}
		}
	}
	v_u_35.api = v36(v39)
	v_u_10 = v_u_35
	v_u_16 = v_u_16 + 1
end
local function v_u_51() -- name: step
	-- upvalues: (ref) v_u_8, (ref) v_u_15, (copy) v_u_3, (ref) v_u_7, (ref) v_u_13, (ref) v_u_14, (ref) v_u_11, (ref) v_u_10, (copy) v_u_5, (copy) v_u_6, (copy) v_u_22, (copy) v_u_30, (copy) v_u_40
	local v41 = v_u_8
	local v42
	if v_u_15 then
		v42 = v_u_15
	else
		local v43 = v_u_3:FindFirstChild("HushRuntime")
		local v44
		if v43 then
			v44 = v43:GetAttribute(v_u_7.ATTRIBUTE)
		else
			v44 = nil
		end
		if v44 ~= v_u_13 then
			v_u_13 = v44
			v_u_14 = v_u_7.decode(v44)
		end
		v42 = v_u_14
	end
	if v42 == nil or v42.id == v_u_11 then
		if v_u_10 then
			v_u_5.close()
		end
	else
		if v_u_10 then
			if v_u_10.id == v42.id then
				local v45
				if v_u_6:GetAttribute("Place") == "Menu" then
					v45 = v_u_6:GetAttribute("MenuOpen") == true
				else
					v45 = false
				end
				if not v45 then
					v_u_5.close()
					return
				end
				if v_u_5.isOpen() then
					local v46 = v_u_10
					local v47 = v46 and (v46.count and (v46.count.Parent and v_u_7.line(v46.notice, v_u_22())))
					if v47 then
						v_u_8.ui.setText(v46.count, v47)
					end
					return
				end
				v_u_10 = nil
			else
				v_u_5.close()
			end
		end
		if v_u_30(v41) then
			local v48 = v_u_40
			local v49, v50 = pcall(v48, v41, v42)
			if not v49 then
				warn("[MenuRestartNotice] show failed:", v50)
				v_u_6:SetAttribute("ClientError", "restart notice: " .. tostring(v50))
				v_u_11 = v42.id
			end
		end
	end
end
function v_u_5.start(p_u_52) -- name: start
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12, (copy) v_u_5, (ref) v_u_15, (copy) v_u_3, (ref) v_u_13, (ref) v_u_14, (ref) v_u_10, (ref) v_u_11, (copy) v_u_30, (copy) v_u_51, (copy) v_u_4, (ref) v_u_16, (copy) v_u_1
	v_u_8 = p_u_52
	if not v_u_9 then
		v_u_9 = true
		v_u_7 = p_u_52.cctx.shared.RestartNotice
		if not v_u_12 then
			v_u_12 = true
			local v53 = p_u_52.cctx.on
			local function v54()
				-- upvalues: (ref) v_u_5
				if v_u_5.isOpen() then
					v_u_5.close()
				end
			end
			pcall(v53, "ui.rebuild", v54)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_3, (ref) v_u_7, (ref) v_u_13, (ref) v_u_14, (ref) v_u_10, (ref) v_u_11, (ref) v_u_30, (ref) v_u_8, (ref) v_u_51
			local v55 = 0
			while true do
				task.wait(0.5)
				local v56
				if v_u_15 then
					v56 = v_u_15
				else
					local v57 = v_u_3:FindFirstChild("HushRuntime")
					local v58
					if v57 then
						v58 = v57:GetAttribute(v_u_7.ATTRIBUTE)
					else
						v58 = nil
					end
					if v58 ~= v_u_13 then
						v_u_13 = v58
						v_u_14 = v_u_7.decode(v58)
					end
					v56 = v_u_14
				end
				if v56 == nil or (v_u_10 ~= nil or v56.id == v_u_11) then
					v55 = 0
					local v59 = v_u_51
					local v60, v61 = pcall(v59)
					if v60 then
						continue
					end
					warn("[MenuRestartNotice] step failed:", v61)
				else
					v55 = not v_u_30(v_u_8) and 0 or v55 + 1
					if v55 < 2 then
						continue
					end
					v55 = 0
					local v62 = v_u_51
					local v63, v64 = pcall(v62)
					if v63 then
						continue
					end
					warn("[MenuRestartNotice] step failed:", v64)
				end
			end
		end)
		if v_u_4:IsStudio() then
			local function v83()
				-- upvalues: (copy) p_u_52, (ref) v_u_7, (ref) v_u_15, (ref) v_u_16, (ref) v_u_1, (ref) v_u_5, (ref) v_u_11
				p_u_52.cctx.command("restart.show", function(p65)
					-- upvalues: (ref) v_u_7, (ref) v_u_15, (ref) v_u_16, (ref) v_u_1
					local v66 = table.concat(p65, " ")
					local v67 = v_u_7.cleanMessage(v66) or v_u_7.DEFAULT_TEXT
					local v68 = v_u_7.make
					local v69 = v_u_16 + 900000 + 1
					local v70 = v_u_1.now()
					v_u_15 = v68(v69, v67, math.floor(v70) + 90)
					return "preview " .. v_u_15.id
				end)
				p_u_52.cctx.command("restart.state", function()
					-- upvalues: (ref) v_u_5
					local v71 = v_u_5.state()
					local v72 = "open=%s shown=%s dismissed=%s shows=%d preview=%s notice=%s"
					local v73 = v71.open
					local v74 = tostring(v73)
					local v75 = v71.shown
					local v76 = tostring(v75)
					local v77 = v71.dismissed
					local v78 = tostring(v77)
					local v79 = v71.shows
					local v80 = v71.preview
					local v81 = tostring(v80)
					local v82 = v71.notice
					if v82 then
						v82 = v71.notice.msg
					end
					return v72:format(v74, v76, v78, v79, v81, (tostring(v82)))
				end)
				p_u_52.cctx.command("restart.reset", function()
					-- upvalues: (ref) v_u_11, (ref) v_u_15
					v_u_11 = 0
					v_u_15 = nil
					return "reset"
				end)
			end
			pcall(v83)
		end
	end
end
return v_u_5