-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / DeployBanner

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v5 = {}
local v_u_6 = v2.LocalPlayer
function v5.mount(p_u_7) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1, (copy) v_u_4
	local v_u_8 = p_u_7.lib.HushUI
	local v_u_9 = p_u_7.shared.Theme
	local v_u_10 = v_u_9.color
	local v_u_11 = {}
	local v_u_12 = v_u_3:FindFirstChild("Config")
	local v_u_13 = {}
	local v_u_14 = nil
	local v_u_15 = nil
	local v_u_16 = nil
	local v_u_17 = nil
	local v_u_18 = nil
	local v_u_19 = nil
	local v_u_20 = nil
	local v_u_21 = ""
	local function v_u_27() -- name: build
		-- upvalues: (copy) v_u_8, (copy) v_u_9, (ref) v_u_14, (copy) v_u_10, (ref) v_u_15, (ref) v_u_20, (ref) v_u_19, (ref) v_u_16, (ref) v_u_18, (ref) v_u_17, (ref) v_u_21
		local v22, v23 = v_u_8.screen("HushDeployBanner", v_u_9.layer.menu + 5, {
			["insets"] = "Device"
		})
		v_u_14 = v22
		local v24 = v_u_8.new("Frame", {
			["Name"] = "DeployBanner",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.06,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["Active"] = false,
			["BackgroundColor3"] = v_u_10.bg,
			["Size"] = UDim2.fromOffset(560, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v23)
		v_u_15 = v24
		v_u_20 = v_u_8.stroke(v24, v_u_10.danger, 1, 0.25)
		v_u_19 = v_u_8.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.danger,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v24)
		local v25 = v_u_8.new("Frame", {
			["Name"] = "Inner",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v24)
		v_u_8.pad(v25, {
			16,
			14,
			8,
			8
		})
		v_u_8.layout(v25, "v", 3)
		local v26 = v_u_8.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 20)
		}, v25)
		v_u_16 = v_u_8.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "DEPLOYMENTS CLOSED",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v26,
			["color"] = v_u_10.danger,
			["size"] = UDim2.new(0.6, 0, 1, 0)
		})
		v_u_18 = v_u_8.label({
			["parent"] = nil,
			["name"] = "Reopen",
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["parent"] = v26,
			["color"] = v_u_10.text2,
			["position"] = UDim2.fromScale(1, 0),
			["anchor"] = Vector2.new(1, 0),
			["size"] = UDim2.new(0.4, 0, 1, 0)
		})
		v_u_17 = v_u_8.label({
			["parent"] = nil,
			["name"] = "Message",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 2,
			["parent"] = v25,
			["color"] = v_u_10.text
		})
		v_u_21 = ""
	end
	local function v_u_41(p28, p29, p30) -- name: rectOf
		local v31 = p28.Size
		local v32 = p28.Position
		local v33 = p28.AnchorPoint
		local v34 = v31.X.Scale * p29.X + v31.X.Offset
		local v35 = v31.Y.Scale * p29.Y + v31.Y.Offset
		local v36 = p28.AutomaticSize
		if p30 > 0 and (v36 == Enum.AutomaticSize.X or v36 == Enum.AutomaticSize.XY) then
			local v37 = p28.AbsoluteSize.X / p30
			v34 = math.max(v34, v37)
		end
		if p30 > 0 and (v36 == Enum.AutomaticSize.Y or v36 == Enum.AutomaticSize.XY) then
			local v38 = p28.AbsoluteSize.Y / p30
			v35 = math.max(v35, v38)
		end
		if v34 <= 0 or v35 <= 0 then
			return nil
		end
		local v39 = v32.X.Scale * p29.X + v32.X.Offset - v33.X * v34
		local v40 = v32.Y.Scale * p29.Y + v32.Y.Offset - v33.Y * v35
		return {
			v39,
			v40,
			v39 + v34,
			v40 + v35
		}
	end
	local function v_u_59(p42) -- name: hideoutObstacles
		-- upvalues: (copy) v_u_9, (ref) v_u_6, (copy) v_u_41, (copy) p_u_7
		local v43 = v_u_9.uiScale()
		local v44 = {}
		local v45 = nil
		local v46 = nil
		local v47 = v_u_6:FindFirstChildOfClass("PlayerGui")
		if v47 then
			v47 = v47:FindFirstChild("HushHideout")
		end
		local v48
		if v47 then
			v48 = v47:FindFirstChild("Root")
		else
			v48 = v47
		end
		if v47 and (v47.Enabled and v48) then
			for _, v49 in v48:GetChildren() do
				if not (v49:IsA("GuiObject") and v49.Visible) then
					continue
				end
				local v50 = v_u_41(v49, p42, v43)
				if not v50 then
					continue
				end
				table.insert(v44, v50)
				if v49.Name == "Head" then
					v45 = v50
				else
					if v49.Name ~= "Stations" then
						continue
					end
					v46 = v50
				end
			end
		end
		local v51 = p_u_7.controllers.Input
		if v51 then
			local v52 = v51.touchRects
			if type(v52) == "function" and v43 > 0 then
				local v53 = v51.touchRects
				local v54, v55 = pcall(v53)
				if v54 and type(v55) == "table" then
					for v56, v57 in v55 do
						if typeof(v57) ~= "Rect" or v56 == "moveZone" then
							continue
						end
						local v58 = {
							v57.Min.X / v43,
							v57.Min.Y / v43,
							v57.Max.X / v43,
							v57.Max.Y / v43
						}
						table.insert(v44, v58)
					end
				end
			end
		end
		return v44, v45, v46
	end
	local v_u_60 = ""
	local function v_u_88(p61) -- name: place
		-- upvalues: (ref) v_u_6, (copy) v_u_9, (copy) v_u_59, (copy) v_u_8, (ref) v_u_60
		local v62 = v_u_6:GetAttribute("Place")
		if (type(v62) ~= "string" and "Menu" or v62) ~= "Hideout" then
			local v63 = v_u_9.refSize()
			local v64 = v63.X < 1320 and true or v63.Y < 640
			local v65 = v_u_6:GetAttribute("MenuTab")
			if v64 and (type(v65) == "string" and (v65 ~= "" and v65 ~= "play")) then
				v_u_60 = "none"
				return false
			end
			v_u_60 = "menu"
			p61.AnchorPoint = Vector2.new(0, 0)
			if v64 then
				p61.Position = UDim2.fromOffset(24, 128)
				local v66 = UDim2.fromOffset
				local v67 = v63.X - 440 - 24 - 48
				p61.Size = v66(math.clamp(v67, 320, 560), 0)
			else
				p61.Position = UDim2.fromOffset(24, 65)
				p61.Size = UDim2.fromOffset(560, 0)
			end
			return true
		end
		local v_u_68 = v_u_9.refSize()
		local v69 = v_u_9.uiScale()
		local v70
		if v69 > 0 and p61.AbsoluteSize.Y > 0 then
			local v71 = p61.AbsoluteSize.Y / v69
			v70 = math.max(48, v71)
		else
			v70 = 64
		end
		local v_u_72, v73, v74 = v_u_59(v_u_68)
		local function v78(p75) -- name: free
			-- upvalues: (copy) v_u_68, (copy) v_u_72
			if p75[1] < 8 or (p75[3] > v_u_68.X - 8 or p75[4] > v_u_68.Y - 8) then
				return false
			end
			for _, v76 in v_u_72 do
				local v77
				if p75[1] < v76[3] + 8 and (v76[1] < p75[3] + 8 and p75[2] < v76[4] + 8) then
					v77 = v76[2] < p75[4] + 8
				else
					v77 = false
				end
				if not v77 then
					continue
				end
				return false
			end
			return true
		end
		local v79 = v_u_8.topInset() + 64
		local v80 = v_u_68.X / 2 - 280
		if not v78({
			v80,
			v79,
			v80 + 560,
			v79 + v70
		}) then
			if v73 then
				local v81 = v73[1]
				local v82 = v73[4] + 12
				local v83
				if v74 then
					v83 = v74[1] - 16
				else
					v83 = v_u_68.X - 24
				end
				local v84 = v83 - v81
				local v85 = math.min(560, v84)
				local v86 = math.floor(v85)
				if v86 >= 320 then
					local v87 = v70 * (560 / v86)
					if v78({
						v81,
						v82,
						v81 + v86,
						v82 + v87
					}) then
						p61.AnchorPoint = Vector2.new(0, 0)
						p61.Position = UDim2.fromOffset(v81, v82)
						p61.Size = UDim2.fromOffset(v86, 0)
						v_u_60 = "underHead"
						return true
					end
				end
			end
			v_u_60 = "none"
			return false
		end
		p61.AnchorPoint = Vector2.new(0.5, 0)
		p61.Position = UDim2.new(0.5, 0, 0, v79)
		p61.Size = UDim2.fromOffset(560, 0)
		v_u_60 = "top"
		return true
	end
	function v_u_11.refresh() -- name: refresh
		-- upvalues: (ref) v_u_14, (copy) v_u_27, (ref) v_u_15, (ref) v_u_6, (ref) v_u_12, (ref) v_u_1, (ref) v_u_21, (copy) v_u_88, (ref) v_u_60, (copy) v_u_10, (ref) v_u_16, (ref) v_u_19, (ref) v_u_20, (ref) v_u_17, (copy) v_u_8, (ref) v_u_18
		if not (v_u_14 and v_u_14.Parent) then
			v_u_27()
		end
		local v89 = v_u_15
		local v90 = v_u_6:GetAttribute("Place")
		local v91 = type(v90) ~= "string" and "Menu" or v90
		local v92
		if v_u_12 == nil then
			v92 = false
		else
			v92 = v_u_12:GetAttribute("DeployClosed") == true
		end
		local v93
		if v92 then
			v93 = nil
		else
			if v_u_12 then
				local v94 = v_u_12
				v93 = tonumber(v94:GetAttribute("DeployCloseAt")) or 0
			else
				v93 = 0
			end
			if not v93 or (v93 <= 0 or v_u_1.now() - 1 >= v93) then
				v93 = nil
			end
		end
		local v95
		if v92 or v93 ~= nil then
			v95 = v91 == "Menu" and true or v91 == "Hideout"
		else
			v95 = false
		end
		v89.Visible = v95
		if v95 then
			if not v_u_88(v89) then
				v89.Visible = false
			end
			if v_u_6:GetAttribute("DeployBannerSpot") ~= v_u_60 then
				v_u_6:SetAttribute("DeployBannerSpot", v_u_60)
			end
			local v96, v97, v98
			if v93 then
				local v99 = v_u_12
				if v99 then
					v99 = v_u_12:GetAttribute("DeployPlanMsg")
				end
				local v100
				if v_u_12 then
					local v101 = v_u_12
					v100 = tonumber(v101:GetAttribute("DeployPlanReopenAt")) or 0
				else
					v100 = 0
				end
				if type(v99) ~= "string" or v99 == "" then
					v99 = nil
				end
				if v99 and not string.match(v99, "[%.!?]$") then
					v99 = v99 .. "."
				end
				v96 = ("At %s your time. "):format((os.date("%H:%M", v93))) .. (v99 or "No new raids from then on. Raids in progress can still finish.")
				if v100 and v100 > 0 then
					v96 = v96 .. (" Back at %s."):format((os.date("%H:%M", v100)))
				end
				local v102 = v93 - v_u_1.now()
				local v103 = math.floor(v102)
				local v104 = math.max(0, v103)
				local v105 = v104 // 3600
				local v106 = v104 % 3600 // 60
				local v107 = v104 % 60
				if v105 > 0 then
					v97 = ("%d:%02d:%02d"):format(v105, v106, v107)
				else
					v97 = ("%d:%02d"):format(v106, v107)
				end
				v98 = "DEPLOYMENTS CLOSE IN"
			else
				local v108 = v_u_12
				if v108 then
					v108 = v_u_12:GetAttribute("DeployMsg")
				end
				v96 = (type(v108) ~= "string" or v108 == "") and "Deployments are closed right now. Raids in progress can still finish." or v108
				local v109
				if v_u_12 then
					local v110 = v_u_12
					v109 = tonumber(v110:GetAttribute("DeployReopenAt")) or 0
				else
					v109 = 0
				end
				if v109 and v109 > 0 then
					local v111 = "REOPENS IN %s"
					local v112 = v109 - v_u_1.now()
					local v113 = math.floor(v112)
					local v114 = math.max(0, v113)
					local v115 = v114 // 3600
					local v116 = v114 % 3600 // 60
					local v117 = v114 % 60
					local v118
					if v115 > 0 then
						v118 = ("%d:%02d:%02d"):format(v115, v116, v117)
					else
						v118 = ("%d:%02d"):format(v116, v117)
					end
					v97 = v111:format(v118)
				else
					v97 = ""
				end
				v98 = "DEPLOYMENTS CLOSED"
			end
			local v119
			if v93 then
				v119 = v_u_10.accent
			else
				v119 = v_u_10.danger
			end
			if v_u_16.Text ~= v98 then
				v_u_16.Text = v98
			end
			v_u_16.TextColor3 = v119
			if v_u_19 then
				v_u_19.BackgroundColor3 = v119
			end
			if v_u_20 then
				v_u_20.Color = v119
			end
			if v_u_17.Text ~= v96 then
				v_u_8.setText(v_u_17, v96)
			end
			if v_u_18.Text ~= v97 then
				v_u_18.Text = v97
			end
			local v120 = ("%s|%s|%s|%s"):format(v91, v98, v96, v97)
			if v120 ~= v_u_21 then
				v_u_21 = v120
				v_u_6:SetAttribute("DeployBanner", v120)
			end
		elseif v_u_21 ~= "" then
			v_u_21 = ""
			v_u_6:SetAttribute("DeployBanner", "")
			v_u_6:SetAttribute("DeployBannerSpot", "")
		end
	end
	local function v_u_126(p121) -- name: watchCfg
		-- upvalues: (ref) v_u_12, (copy) v_u_13, (copy) v_u_11
		v_u_12 = p121
		for _, v122 in {
			"DeployClosed",
			"DeployMsg",
			"DeployReopenAt",
			"DeployCloseAt",
			"DeployPlanReopenAt",
			"DeployPlanMsg"
		} do
			local v123 = v_u_13
			local v124 = p121:GetAttributeChangedSignal(v122)
			local v125 = v_u_11.refresh
			table.insert(v123, v124:Connect(v125))
		end
		v_u_11.refresh()
	end
	v_u_27()
	if v_u_12 then
		v_u_126(v_u_12)
	else
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_126
			local v127 = v_u_3:WaitForChild("Config", 60)
			if v127 then
				v_u_126(v127)
			end
		end)
	end
	local v128 = v_u_6:GetAttributeChangedSignal("Place")
	local v129 = v_u_11.refresh
	table.insert(v_u_13, v128:Connect(v129))
	local v130 = v_u_6:GetAttributeChangedSignal("MenuTab")
	local v131 = v_u_11.refresh
	table.insert(v_u_13, v130:Connect(v131))
	local v_u_132 = 0
	local v133 = v_u_4.Heartbeat
	local function v135(p134)
		-- upvalues: (ref) v_u_132, (ref) v_u_15, (ref) v_u_60, (copy) v_u_11
		v_u_132 = v_u_132 + p134
		if v_u_132 >= 1 then
			v_u_132 = 0
			if v_u_15 and (v_u_15.Visible or v_u_60 == "none") then
				v_u_11.refresh()
			end
		end
	end
	table.insert(v_u_13, v133:Connect(v135))
	local v136 = p_u_7.on
	pcall(v136, "ui.rebuild", function()
		-- upvalues: (copy) v_u_27, (copy) v_u_11
		task.defer(function()
			-- upvalues: (ref) v_u_27, (ref) v_u_11
			v_u_27()
			v_u_11.refresh()
		end)
	end)
	v_u_11.refresh()
	function v_u_11.destroy() -- name: destroy
		-- upvalues: (copy) v_u_13, (ref) v_u_14
		for _, v137 in v_u_13 do
			v137:Disconnect()
		end
		if v_u_14 then
			v_u_14:Destroy()
		end
	end
	v_u_11.gui = v_u_14
	return v_u_11
end
return v5