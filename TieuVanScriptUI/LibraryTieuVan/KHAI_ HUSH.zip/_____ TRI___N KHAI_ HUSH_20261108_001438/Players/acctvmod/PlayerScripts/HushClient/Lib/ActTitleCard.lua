-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ActTitleCard

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {
	["GUI_NAME"] = "HushActTitle",
	["GUI_ORDER"] = 996,
	["SKIP_AFTER"] = 0.8
}
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = 0
local v_u_11 = false
local v_u_12 = ""
local v_u_13 = "none"
local function v_u_20() -- name: fonts
	-- upvalues: (ref) v_u_6
	local v_u_14 = Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v_u_15 = Font.fromName("Roboto", Enum.FontWeight.Regular)
	local function v19()
		-- upvalues: (ref) v_u_6, (ref) v_u_14, (ref) v_u_15
		local v16 = v_u_6.shared.Theme.font
		local v17 = v16.headingBold
		if typeof(v17) == "Font" then
			v_u_14 = v16.headingBold
		end
		local v18 = v16.body
		if typeof(v18) == "Font" then
			v_u_15 = v16.body
		end
	end
	pcall(v19)
	return v_u_14, v_u_15
end
function v_u_4.active() -- name: active
	-- upvalues: (ref) v_u_7
	return v_u_7 ~= nil
end
function v_u_4.state() -- name: state
	-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12
	local v21 = v_u_7 ~= nil
	local v22 = v_u_11
	return ("active=%s skipped=%s last=%s raid=%s"):format(tostring(v21), tostring(v22), v_u_13, v_u_12)
end
function v_u_4.init(p23) -- name: init
	-- upvalues: (ref) v_u_6
	v_u_6 = p23
end
function v_u_4.stop() -- name: stop
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
	if v_u_8 then
		v_u_8:Disconnect()
		v_u_8 = nil
	end
	if v_u_9 then
		v_u_9:Disconnect()
		v_u_9 = nil
	end
	if v_u_7 then
		v_u_7:Destroy()
		v_u_7 = nil
	end
end
local function v_u_36(p24, p25, p26, p27, p28, p29, p30, p31) -- name: label
	local v32 = Instance.new("TextLabel")
	v32.Name = p25
	v32.BackgroundTransparency = 1
	v32.BorderSizePixel = 0
	v32.AnchorPoint = Vector2.new(0.5, 0.5)
	v32.Position = UDim2.new(0.5, 0, 0.5, p30)
	v32.Size = UDim2.new(0.9, 0, 0, p31)
	v32.FontFace = p27
	v32.TextSize = p28
	v32.TextColor3 = p29
	v32.TextTransparency = 1
	v32.TextXAlignment = Enum.TextXAlignment.Center
	v32.TextYAlignment = Enum.TextYAlignment.Center
	v32.Text = p26
	local v33 = Instance.new("UITextSizeConstraint")
	v33.MaxTextSize = p28
	local v34 = p28 * 0.5
	local v35 = math.floor(v34)
	v33.MinTextSize = math.max(10, v35)
	v33.Parent = v32
	v32.TextScaled = true
	v32.Parent = p24
	return v32
end
function v_u_4.play() -- name: play
	-- upvalues: (ref) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_20, (copy) v_u_36, (ref) v_u_7, (ref) v_u_11, (ref) v_u_10, (ref) v_u_8, (copy) v_u_2, (ref) v_u_9, (copy) v_u_3, (ref) v_u_13
	local function v37()
		-- upvalues: (ref) v_u_6
		return v_u_6.shared.Act2Intro
	end
	local v38, v_u_39 = pcall(v37)
	if not v38 or type(v_u_39) ~= "table" then
		v_u_39 = nil
	end
	if v_u_39 == nil or v_u_5 == nil then
		return false
	end
	v_u_4.stop()
	local v_u_40 = v_u_5:FindFirstChildOfClass("PlayerGui")
	if v_u_40 == nil then
		return false
	end
	local function v56()
		-- upvalues: (ref) v_u_20, (ref) v_u_4, (copy) v_u_40, (copy) v_u_39, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (ref) v_u_10, (ref) v_u_8, (ref) v_u_2, (ref) v_u_9, (ref) v_u_3
		local v41, v42 = v_u_20()
		local v43 = Instance.new("ScreenGui")
		v43.Name = v_u_4.GUI_NAME
		v43.ResetOnSpawn = false
		v43.IgnoreGuiInset = true
		v43.DisplayOrder = v_u_4.GUI_ORDER
		v43.Parent = v_u_40
		local v_u_44 = Instance.new("Frame")
		v_u_44.Name = "Cover"
		v_u_44.BackgroundColor3 = Color3.new(0, 0, 0)
		v_u_44.BorderSizePixel = 0
		v_u_44.Size = UDim2.fromScale(1, 1)
		v_u_44.Active = false
		v_u_44.Parent = v43
		local v45 = v_u_39.CARD
		local v_u_46 = v_u_36(v_u_44, "Speaker", v45.speaker, v42, 18, Color3.fromRGB(235, 168, 52), -34, 24)
		local v_u_47 = v_u_36(v_u_44, "Line", v45.line, v42, 26, Color3.fromRGB(240, 240, 240), 0, 40)
		local v_u_48 = v_u_36(v_u_44, "Title", v45.text, v41, 54, Color3.fromRGB(240, 240, 240), 0, 80)
		v_u_7 = v43
		v_u_11 = false
		v_u_10 = os.clock()
		local v49 = v_u_39.frame(0)
		v_u_44.BackgroundTransparency = 1 - v49.cover
		v_u_46.TextTransparency = 1 - v49.line
		v_u_47.TextTransparency = 1 - v49.line
		v_u_48.TextTransparency = 1 - v49.title
		v_u_8 = v_u_2.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_39, (ref) v_u_4, (copy) v_u_44, (copy) v_u_46, (copy) v_u_47, (copy) v_u_48
			local v50 = os.clock() - v_u_10
			if v_u_39.CARD.seconds <= v50 then
				v_u_4.stop()
			else
				local v51 = v_u_39.frame(v50)
				v_u_44.BackgroundTransparency = 1 - v51.cover
				v_u_46.TextTransparency = 1 - v51.line
				v_u_47.TextTransparency = 1 - v51.line
				v_u_48.TextTransparency = 1 - v51.title
			end
		end)
		v_u_9 = v_u_3.InputBegan:Connect(function(p52, _)
			-- upvalues: (ref) v_u_11, (ref) v_u_10, (ref) v_u_4, (ref) v_u_39
			if not v_u_11 and os.clock() - v_u_10 >= v_u_4.SKIP_AFTER then
				local v53 = p52.UserInputType
				if v53 == Enum.UserInputType.Keyboard or (v53 == Enum.UserInputType.MouseButton1 or (v53 == Enum.UserInputType.Touch or v53 == Enum.UserInputType.Gamepad1)) then
					v_u_11 = true
					local v54 = v_u_10
					local v55 = os.clock() - v_u_39.skipTime()
					v_u_10 = math.min(v54, v55)
				end
			end
		end)
	end
	if pcall(v56) then
		return true
	end
	v_u_4.stop()
	v_u_13 = "error"
	return false
end
function v_u_4.maybePlay() -- name: maybePlay
	-- upvalues: (ref) v_u_6, (ref) v_u_13, (copy) v_u_5, (ref) v_u_12, (ref) v_u_7, (copy) v_u_4
	local function v57()
		-- upvalues: (ref) v_u_6
		return v_u_6.shared.Act2Intro
	end
	local v58, v59 = pcall(v57)
	if not v58 or type(v59) ~= "table" then
		v59 = nil
	end
	if v59 == nil then
		v_u_13 = "error"
		return false, "error"
	end
	local v_u_60 = nil
	local function v61()
		-- upvalues: (ref) v_u_60, (ref) v_u_6
		v_u_60 = v_u_6.runtime:GetAttribute("MapId")
	end
	pcall(v61)
	local v62 = v_u_5:GetAttribute("StoryStage")
	local v63 = v_u_5:GetAttribute(v59.BEGUN_ATTR)
	local v64 = v_u_5:GetAttribute("RaidId") or ""
	local v65 = tostring(v64)
	if v_u_60 ~= v59.MAP then
		v_u_13 = "map"
		return false, "map"
	end
	local v66 = v59.shouldShow
	local v67 = v_u_60
	local v68
	if v65 == "" then
		v68 = false
	else
		v68 = v65 == v_u_12
	end
	if not v66(v67, v62, v68, v63) then
		local v69
		if type(v63) == "boolean" and v63 == false then
			v69 = true
		elseif type(v63) == "boolean" or type(v62) ~= "number" then
			v69 = false
		else
			v69 = v62 < v59.ACT2_FROM
		end
		v_u_13 = v69 and "again" or "stage"
		return false, v_u_13
	end
	if v_u_7 ~= nil then
		v_u_13 = "busy"
		return false, "busy"
	end
	if v_u_5:GetAttribute("EntryActive") == true then
		v_u_13 = "entry"
		return false, "entry"
	end
	if not v_u_4.play() then
		return false, "error"
	end
	v_u_12 = v65
	v_u_13 = "played"
	return true, nil
end
return v_u_4