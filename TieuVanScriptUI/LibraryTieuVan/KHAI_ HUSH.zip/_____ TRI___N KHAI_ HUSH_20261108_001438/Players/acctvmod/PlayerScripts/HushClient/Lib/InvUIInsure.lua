-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIInsure

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = v1:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v_u_3:WaitForChild("Theme"))
local v_u_5 = v_u_4.color
local v_u_6 = {}
local v_u_7 = {
	["primary"] = true,
	["secondary"] = true,
	["armor"] = true,
	["helmet"] = true,
	["bag"] = true,
	["ears"] = true
}
local v_u_8 = {}
local v_u_9 = ""
local v_u_10 = false
local v_u_11 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_12 = false
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local function v_u_28(p16) -- name: placeChip
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v17 = p16.Parent
	if v_u_4.isPhone ~= nil and (v_u_4.isPhone() and (v17 and v17:IsA("GuiObject"))) then
		local v18 = v17.AbsoluteSize.Y
		local v19 = v_u_4.uiScale()
		local v20 = v18 / math.max(v19, 0.1)
		local v21 = v17:FindFirstChild("SlotPad")
		if v21 and v21:IsA("UIPadding") then
			v20 = v20 - v21.PaddingTop.Offset
		end
		local v22
		if v20 > 1 then
			v22 = v20 < 34
		else
			v22 = false
		end
		local v23 = p16:FindFirstChild("Line")
		local v24 = p16:FindFirstChild("Shield")
		local v25 = p16:FindFirstChild("Left")
		if v22 then
			local v26 = UDim2.fromOffset
			local v27 = math.floor(v20) - 8
			p16.Size = v26(4, (math.max(8, v27)))
			p16.Position = UDim2.fromOffset(2, 4)
			p16.BackgroundTransparency = 0
			if v23 and v23:IsA("UIStroke") then
				p16.BackgroundColor3 = v23.Color
			end
		else
			p16.Size = UDim2.fromOffset(36, 14)
			p16.Position = UDim2.fromOffset(3, 18)
			p16.BackgroundColor3 = v_u_5.bgDeep
			p16.BackgroundTransparency = 0.12
		end
		if v25 and v25:IsA("TextLabel") then
			v25.Visible = not v22
		end
		if v24 and v24:IsA("GuiObject") then
			v24.Visible = not v22
		end
	end
end
local function v_u_41(p_u_29) -- name: buildChip
	-- upvalues: (copy) v_u_5, (ref) v_u_14, (copy) v_u_4, (copy) v_u_28
	local v30 = p_u_29.ZIndex + 4
	local v_u_31 = Instance.new("Frame")
	v_u_31.Name = "InsMark"
	v_u_31.BackgroundColor3 = v_u_5.bgDeep
	v_u_31.BackgroundTransparency = 0.12
	v_u_31.BorderSizePixel = 0
	v_u_31.AnchorPoint = Vector2.new(0, 0)
	v_u_31.Position = UDim2.fromOffset(3, 17)
	v_u_31.Size = UDim2.fromOffset(30, 15)
	v_u_31.ZIndex = v30
	local v_u_32 = Instance.new("UIStroke")
	v_u_32.Name = "Line"
	v_u_32.Color = v_u_5.success
	v_u_32.Thickness = 1
	v_u_32.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	pcall(function()
		-- upvalues: (copy) v_u_32
		v_u_32.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	v_u_32.Parent = v_u_31
	if v_u_14 == nil then
		local v33, v34 = pcall(function()
			return require((script.Parent:WaitForChild("HushUI")))
		end)
		if not v33 then
			v34 = false
		end
		v_u_14 = v34
	end
	local v35 = v_u_14 or nil
	if v35 and v35.icon then
		local v36 = v35.icon
		local v37 = {
			["parent"] = nil,
			["name"] = "Shield",
			["size"] = 10,
			["color"] = nil,
			["position"] = nil,
			["zindex"] = nil,
			["parent"] = v_u_31,
			["color"] = v_u_5.success,
			["position"] = UDim2.fromOffset(4, 2),
			["zindex"] = v30 + 1
		}
		pcall(v36, "shield", v37)
	end
	local v38 = Instance.new("TextLabel")
	v38.Name = "Left"
	v38.BackgroundTransparency = 1
	v38.FontFace = v_u_4.font.monoBold
	v38.TextSize = v_u_4.phoneText(11, "caption")
	v38.TextColor3 = v_u_5.text
	local v39
	if v_u_4.isPhone == nil then
		v39 = false
	else
		v39 = v_u_4.isPhone()
	end
	v38.Position = UDim2.fromOffset(v39 and 17 or 15, 0)
	v38.Size = UDim2.fromOffset(v39 and 17 or 13, v39 and 14 or 15)
	v38.Text = ""
	v38.ZIndex = v30 + 1
	v38.Parent = v_u_31
	v_u_31.Parent = p_u_29
	if v39 then
		v_u_28(v_u_31)
		local v_u_40 = nil
		v_u_40 = p_u_29:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (copy) v_u_31, (copy) p_u_29, (ref) v_u_28, (ref) v_u_40
			if v_u_31.Parent == p_u_29 then
				v_u_28(v_u_31)
			elseif v_u_40 then
				v_u_40:Disconnect()
			end
		end)
	end
	return v_u_31
end
local function v_u_52(p42, p43) -- name: paintChip
	-- upvalues: (copy) v_u_5, (ref) v_u_14, (copy) v_u_28
	local v44
	if p43 <= 1 then
		v44 = v_u_5.accent
	else
		v44 = v_u_5.success
	end
	local v45 = p42:FindFirstChild("Line")
	if v45 and v45:IsA("UIStroke") then
		v45.Color = v44
	end
	if v_u_14 == nil then
		local v46, v47 = pcall(function()
			return require((script.Parent:WaitForChild("HushUI")))
		end)
		if not v46 then
			v47 = false
		end
		v_u_14 = v47
	end
	local v48 = v_u_14 or nil
	local v49 = p42:FindFirstChild("Shield")
	if v49 and (v48 and v48.setIconColor) then
		local v50 = v48.setIconColor
		pcall(v50, v49, v44)
	end
	local v51 = p42:FindFirstChild("Left")
	if v51 and v51:IsA("TextLabel") then
		v51.Text = tostring(p43)
	end
	p42:SetAttribute("RaidsLeft", p43)
	v_u_28(p42)
end
local function v_u_59(p53, p54) -- name: markTile
	-- upvalues: (copy) v_u_41, (copy) v_u_52
	if type(p53) == "table" then
		local v55 = p53.frame
		if typeof(v55) == "Instance" then
			local v56 = p53.alive
			if type(v56) == "function" and not p53.alive() then
				return
			else
				local v57 = p53.frame
				local v58 = v57:FindFirstChild("InsMark")
				if p54 == nil then
					if v58 then
						v58:Destroy()
					end
				else
					v_u_52(v58 or v_u_41(v57), p54)
				end
			end
		end
	end
end
function v_u_6.paintMount(p60) -- name: paintMount
	-- upvalues: (copy) v_u_59, (ref) v_u_8
	if type(p60) == "table" and (p60.mode == "menu" and p60.dead ~= true) then
		local v61 = p60.tiles
		if type(v61) == "table" then
			for v62, v63 in p60.tiles do
				v_u_59(v63, v_u_8[v62])
			end
		end
		local v64 = p60.slots
		if type(v64) == "table" then
			for _, v65 in p60.slots do
				local v66
				if type(v65) == "table" then
					v66 = v65.tile or nil
				else
					v66 = nil
				end
				if type(v66) ~= "table" then
					continue
				end
				local v67 = v66.inst
				if type(v67) ~= "table" then
					continue
				end
				v_u_59(v66, v_u_8[v66.inst.uid])
			end
		end
	end
end
function v_u_6.setPolicies(p68) -- name: setPolicies
	-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (copy) v_u_11, (copy) v_u_6
	local v69 = {}
	local v70 = {}
	if type(p68) == "table" then
		for _, v71 in p68 do
			if type(v71) ~= "table" then
				continue
			end
			local v72 = v71.uid
			if type(v72) ~= "string" then
				continue
			end
			local v73 = v71.raidsLeft
			if type(v73) ~= "number" or v71.raidsLeft <= 0 then
				continue
			end
			local v74 = v71.raidsLeft
			local v75 = math.floor(v74)
			v69[v71.uid] = v75
			local v76 = v71.uid .. ":" .. v75
			table.insert(v70, v76)
		end
	end
	table.sort(v70)
	local v77 = table.concat(v70, ",")
	if not v_u_10 or v77 ~= v_u_9 then
		v_u_10 = true
		v_u_9 = v77
		v_u_8 = v69
		for v78 in v_u_11 do
			local v79 = v_u_6.paintMount
			pcall(v79, v78)
		end
	end
end
function v_u_6.policies() -- name: policies
	-- upvalues: (ref) v_u_8
	return v_u_8
end
local function v_u_124(p80) -- name: bind
	-- upvalues: (ref) v_u_13, (ref) v_u_12, (copy) v_u_6, (ref) v_u_10, (copy) v_u_2, (copy) v_u_11, (ref) v_u_8
	if p80 then
		v_u_13 = p80
	end
	if not v_u_12 and v_u_13 then
		v_u_12 = true
		local v_u_81 = v_u_13
		task.spawn(function()
			-- upvalues: (copy) v_u_81, (ref) v_u_6
			local function v87()
				-- upvalues: (ref) v_u_81, (ref) v_u_6
				v_u_81.net.listen("menu.state", function(p82)
					-- upvalues: (ref) v_u_6
					if type(p82) == "table" then
						local v83 = p82.profile
						if type(v83) == "table" then
							local v84 = p82.profile.insurance
							local v85 = v_u_6.setPolicies
							local v86
							if type(v84) == "table" then
								v86 = v84.policies
							else
								v86 = nil
							end
							v85(v86)
						end
					end
				end)
			end
			pcall(v87)
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_81, (ref) v_u_10, (ref) v_u_6
			local v88 = v_u_81.net.invoke
			local v89, v90 = pcall(v88, "menu.get", {
				["what"] = "profile"
			})
			if v89 and (type(v90) == "table" and not v_u_10) then
				local v91 = v90.insurance
				local v92 = v_u_6.setPolicies
				local v93
				if type(v91) == "table" then
					v93 = v91.policies
				else
					v93 = nil
				end
				v92(v93)
			end
		end)
		pcall(function()
			-- upvalues: (copy) v_u_81
			v_u_81.lib.MenuInsure.bind(v_u_81)
		end)
		if v_u_2:IsStudio() then
			local v94 = v_u_81.command
			if type(v94) == "function" then
				v_u_81.command("insure.marks", function()
					-- upvalues: (ref) v_u_11, (ref) v_u_8
					local v_u_95 = {}
					for v96 in v_u_11 do
						if type(v96) ~= "table" or (v96.mode ~= "menu" or v96.dead == true) then
							continue
						end
						local function v106(p97, p98) -- name: scan
							-- upvalues: (copy) v_u_95
							if type(p97) == "table" then
								local v99 = p97.frame
								local v100 = typeof(v99) == "Instance" and p97.frame:FindFirstChild("InsMark")
								if v100 then
									local v101 = p97.inst
									if type(v101) == "table" then
										local v102 = v_u_95
										local v103 = p97.inst.uid
										local v104 = tostring(v103)
										local v105 = tostring(v100:GetAttribute("RaidsLeft"))
										table.insert(v102, ("%s=%s@%s"):format(v104, v105, p98))
									end
								end
							end
						end
						for _, v107 in v96.tiles or {} do
							v106(v107, "grid")
						end
						for v108, v109 in v96.slots or {} do
							local v110
							if type(v109) == "table" then
								v110 = v109.tile or nil
							else
								v110 = nil
							end
							v106(v110, v108)
						end
					end
					table.sort(v_u_95)
					local v111 = 0
					for _ in v_u_8 do
						v111 = v111 + 1
					end
					return ("marks %d: %s | policies %d"):format(#v_u_95, table.concat(v_u_95, " "), v111)
				end)
				v_u_81.command("insure.fake", function(p112)
					-- upvalues: (ref) v_u_6, (ref) v_u_11
					if p112[1] == "off" then
						v_u_6.setPolicies({})
						return "fake policies cleared"
					end
					local v_u_113 = {}
					for v114 in v_u_11 do
						if type(v114) ~= "table" or (v114.mode ~= "menu" or v114.dead == true) then
							continue
						end
						local function v120(p115) -- name: add
							-- upvalues: (copy) v_u_113
							if type(p115) == "table" then
								local v116 = p115.inst
								if type(v116) == "table" then
									local v117 = p115.inst.uid
									if type(v117) == "string" then
										local v118 = v_u_113
										local v119 = {
											["uid"] = p115.inst.uid,
											["raidsLeft"] = #v_u_113 % 3 + 1
										}
										table.insert(v118, v119)
									end
								end
							end
						end
						for _, v121 in v114.tiles or {} do
							v120(v121)
						end
						for _, v122 in v114.slots or {} do
							local v123
							if type(v122) == "table" then
								v123 = v122.tile
							else
								v123 = nil
							end
							v120(v123)
						end
					end
					v_u_6.setPolicies(v_u_113)
					return ("fake policies %d"):format(#v_u_113)
				end)
			end
		end
	end
end
function v_u_6.paint(p_u_125, p_u_126) -- name: paint
	-- upvalues: (copy) v_u_124, (copy) v_u_11, (copy) v_u_6
	if type(p_u_126) == "table" and p_u_126.mode == "menu" then
		local function v127()
			-- upvalues: (ref) v_u_124, (copy) p_u_125, (ref) v_u_11, (copy) p_u_126, (ref) v_u_6
			v_u_124(p_u_125)
			v_u_11[p_u_126] = true
			v_u_6.paintMount(p_u_126)
		end
		local v128, v129 = pcall(v127)
		if not v128 then
			warn("[InvUIInsure] paint failed:", v129)
		end
	end
end
function v_u_6.acts(p_u_130, p131, p_u_132, p_u_133) -- name: acts
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_124, (ref) v_u_8
	if type(p131) == "table" and p131.mode == "menu" then
		local function v152()
			-- upvalues: (copy) p_u_132, (ref) v_u_3, (ref) v_u_7, (copy) p_u_133, (ref) v_u_124, (copy) p_u_130, (ref) v_u_8
			local v134 = p_u_132
			if type(v134) == "table" and p_u_132.kind == "grid" then
				local v135 = p_u_132.item
				if type(v135) == "table" then
					local v_u_136 = nil
					local v_u_137 = nil
					local function v138()
						-- upvalues: (ref) v_u_136, (ref) v_u_137, (ref) v_u_3
						v_u_136 = require((script.Parent:WaitForChild("InvUIWhy", 3)))
						v_u_137 = require((v_u_3:WaitForChild("Items", 3)))
					end
					pcall(v138)
					if v_u_136 and v_u_137 then
						local v139 = v_u_137.get(p_u_132.item.id)
						local v140 = v_u_136.insureHint
						local v141 = "grid"
						local v142
						if v139 then
							v142 = v_u_137.equipSlot(v139)
						else
							v142 = nil
						end
						local v143 = v140(v141, v142, v_u_7)
						if v143 then
							local v144 = p_u_133
							local v145 = {
								["id"] = "insurehint",
								["text"] = nil,
								["say"] = nil,
								["kind"] = "muted",
								["text"] = v143.text,
								["say"] = v143.say
							}
							table.insert(v144, v145)
						end
					end
					return
				end
			end
			local v146 = p_u_132
			if type(v146) == "table" and p_u_132.kind == "slot" then
				local v147 = v_u_7
				local v148 = p_u_132.slot
				if v147[tostring(v148)] then
					local v149 = p_u_132.item
					if type(v149) == "table" then
						v_u_124(p_u_130)
						local v150 = p_u_133
						local v151 = {
							["id"] = "insure",
							["text"] = nil,
							["text"] = v_u_8[p_u_132.item.uid] and "View policy" or "Insure"
						}
						table.insert(v150, v151)
						return
					end
				end
			end
		end
		pcall(v152)
	end
end
function v_u_6.tip(p_u_153, p_u_154, p_u_155) -- name: tip
	-- upvalues: (ref) v_u_8, (copy) v_u_5, (ref) v_u_15, (copy) v_u_3
	local function v171()
		-- upvalues: (copy) p_u_153, (copy) p_u_154, (copy) p_u_155, (ref) v_u_8, (ref) v_u_5, (ref) v_u_15, (ref) v_u_3
		local v156 = p_u_153
		if type(v156) == "table" then
			local v157 = p_u_154
			if type(v157) == "table" then
				local v158 = p_u_155
				if type(v158) == "table" and p_u_155.mode == "menu" then
					local v159 = p_u_153.lines
					local v160 = type(v159) == "table" and v_u_8[p_u_154.uid]
					if v160 then
						local v161 = p_u_153.lines
						local v162 = { "Insured", v160 == 1 and "1 raid left" or ("%d raids left"):format(v160), v_u_5.success }
						table.insert(v161, v162)
					end
				end
				local v163 = game:GetService("Players").LocalPlayer
				if v163 and v163:GetAttribute("PaidTrading") == false then
					if v_u_15 == nil then
						local function v164()
							-- upvalues: (ref) v_u_3
							return require((v_u_3:WaitForChild("PaidItems", 5)))
						end
						local v165, v166 = pcall(v164)
						if not v165 then
							v166 = false
						end
						v_u_15 = v166
					end
					local v167 = v_u_15 or nil
					if v167 and v167.anyPaid(p_u_154) then
						local v168 = p_u_153.body
						local v169 = p_u_153
						local v170
						if type(v168) == "string" and v168 ~= "" then
							v170 = v168 .. "\n" .. v167.NOTICE
						else
							v170 = v167.NOTICE
						end
						v169.body = v170
					end
				end
				return p_u_153
			end
		end
		return p_u_153
	end
	local v172, v173 = pcall(v171)
	if v172 then
		return v173
	else
		return p_u_153
	end
end
function v_u_6.open(p_u_174, p_u_175) -- name: open
	-- upvalues: (copy) v_u_124
	local function v176()
		-- upvalues: (ref) v_u_124, (copy) p_u_174, (copy) p_u_175
		v_u_124(p_u_174)
		p_u_174.lib.MenuInsure.open(nil, p_u_175)
	end
	local v177, v178 = pcall(v176)
	if not v177 then
		warn("[InvUIInsure] open failed:", v178)
		pcall(function()
			-- upvalues: (copy) p_u_174
			p_u_174.lib.HushUI.toast("Insurance is not available right now", "warn", "The window could not open. Close the menu and open it again.")
		end)
	end
end
return v_u_6