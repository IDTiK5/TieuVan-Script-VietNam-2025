-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStory

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {}
v_u_4.__index = v_u_4
v_u_4.FLAG = "LobbyStory"
v_u_4.ATTR = "StoryStage"
v_u_4.FOLDER = "Story"
v_u_4.BIRD = "PaperBird"
v_u_4.MAX_PARTS = 300
v_u_4.MAX_LIGHTS = 12
v_u_4.MAX_BIRD_PARTS = 90
local v_u_5 = math.rad
v_u_4.SPOTS = {
	["Car_Taxi"] = {
		["lx"] = 1.25,
		["lz"] = -6.8,
		["y"] = 2.85,
		["normal"] = Vector3.new(0.04, 0.98, -0.2)
	}
}
v_u_4.CAR_ORDER = { "Car_Taxi", "Car_Wreck" }
v_u_4.HEAD_DIR = Vector3.new(0.9, 0, -0.45)
v_u_4.TILT = {
	["x"] = 2.2,
	["z"] = -1.8
}
local v_u_6 = {
	["paper"] = Color3.fromHex("#F2EEE2"),
	["edge"] = Color3.fromHex("#B3A68D"),
	["crease"] = Color3.fromHex("#8F8571"),
	["damp"] = Color3.fromHex("#5B5C5E"),
	["drop"] = Color3.fromHex("#B9C6D2"),
	["shadow"] = Color3.fromHex("#050507")
}
local v_u_7 = (Vector3.new(-0.35, 0.85, -0.4)).Unit
v_u_4.SCALE = 0.8
local v8 = Vector3.new(-0.16, 0, 0.02) * v_u_4.SCALE
local v9 = Vector3.new(0.16, 0, 0.02) * v_u_4.SCALE
local v10 = Vector3.new(0, 0, -0.27) * v_u_4.SCALE
local v11 = Vector3.new(0, 0, 0.3) * v_u_4.SCALE
local v12 = Vector3.new(0, 0.14, -0.1) * v_u_4.SCALE
local v13 = Vector3.new(0, 0.14, 0.12) * v_u_4.SCALE
local v14 = Vector3.new(0, 0.3, -0.42) * v_u_4.SCALE
local v15 = Vector3.new(0, 0.235, -0.56) * v_u_4.SCALE
local v16 = Vector3.new(0, 0.205, -0.445) * v_u_4.SCALE
local v17 = Vector3.new(0, 0.29, 0.44) * v_u_4.SCALE
local function v28(p18) -- name: wingPoints
	-- upvalues: (copy) v_u_4
	local v19 = p18 * 0.04
	local v20 = Vector3.new(v19, 0.13, -0.17) * v_u_4.SCALE
	local v21 = p18 * 0.04
	local v22 = Vector3.new(v21, 0.12, 0.17) * v_u_4.SCALE
	local v23 = p18 * 0.52
	local v24 = Vector3.new(v23, 0.28, 0.12) * v_u_4.SCALE
	local v25 = p18 * 0.24
	local v26 = Vector3.new(v25, 0.06, -0.13) * v_u_4.SCALE
	local v27 = p18 * 0.27
	return v20, v22, v24, v26, Vector3.new(v27, 0.07, 0.2) * v_u_4.SCALE
end
local v_u_29 = {}
local v_u_30 = nil
for _, v31 in { -1, 1 } do
	local v32
	if v31 < 0 then
		v32 = v8
	else
		v32 = v9
	end
	local v33 = v31 < 0 and "L" or "R"
	local v34 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = "body",
		["thick"] = nil,
		["worn"] = nil,
		["name"] = "Body" .. v33 .. "Mid",
		["a"] = v32,
		["b"] = v12,
		["c"] = v13
	}
	table.insert(v_u_29, v34)
	local v35 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = "body",
		["thick"] = nil,
		["worn"] = nil,
		["name"] = "Body" .. v33 .. "Front",
		["a"] = v32,
		["b"] = v10,
		["c"] = v12
	}
	table.insert(v_u_29, v35)
	local v36 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = "body",
		["thick"] = nil,
		["worn"] = nil,
		["name"] = "Body" .. v33 .. "Back",
		["a"] = v32,
		["b"] = v13,
		["c"] = v11
	}
	table.insert(v_u_29, v36)
	local v37, v38, v39, v40, v41 = v28(v31)
	local v42 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = nil,
		["thick"] = nil,
		["worn"] = true,
		["name"] = "Wing" .. v33,
		["a"] = v37,
		["b"] = v38,
		["c"] = v39,
		["group"] = "wing" .. v33
	}
	table.insert(v_u_29, v42)
	local v43 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = nil,
		["thick"] = nil,
		["worn"] = nil,
		["name"] = "Flap" .. v33 .. "Front",
		["a"] = v37,
		["b"] = v39,
		["c"] = v40,
		["group"] = "wing" .. v33
	}
	table.insert(v_u_29, v43)
	local v44 = {
		["name"] = nil,
		["a"] = nil,
		["b"] = nil,
		["c"] = nil,
		["group"] = nil,
		["thick"] = nil,
		["worn"] = nil,
		["name"] = "Flap" .. v33 .. "Back",
		["a"] = v38,
		["b"] = v39,
		["c"] = v41,
		["group"] = "wing" .. v33
	}
	table.insert(v_u_29, v44)
end
table.insert(v_u_29, {
	["name"] = "Neck",
	["a"] = nil,
	["b"] = nil,
	["c"] = nil,
	["group"] = "neck",
	["thick"] = 0.022400000000000003,
	["worn"] = nil,
	["a"] = v12,
	["b"] = v10,
	["c"] = v14
})
table.insert(v_u_29, {
	["name"] = "Beak",
	["a"] = nil,
	["b"] = nil,
	["c"] = nil,
	["group"] = "beak",
	["thick"] = 0.022400000000000003,
	["worn"] = true,
	["a"] = v14,
	["b"] = v15,
	["c"] = v16
})
table.insert(v_u_29, {
	["name"] = "Tail",
	["a"] = nil,
	["b"] = nil,
	["c"] = nil,
	["group"] = "tail",
	["thick"] = 0.022400000000000003,
	["worn"] = true,
	["a"] = v13,
	["b"] = v11,
	["c"] = v17
})
v_u_4.FACET_LIST = v_u_29
v_u_4.CREASES = {
	{
		["a"] = v12 + Vector3.new(0, 0.004, 0) * v_u_4.SCALE,
		["b"] = v13 + Vector3.new(0, 0.004, 0) * v_u_4.SCALE
	},
	{
		["a"] = v12 + Vector3.new(0.006, 0, 0) * v_u_4.SCALE,
		["b"] = v14 + Vector3.new(0.006, 0, 0.002) * v_u_4.SCALE
	},
	{
		["a"] = Vector3.new(0.045, 0.135, -0.17) * v_u_4.SCALE,
		["b"] = Vector3.new(0.045, 0.125, 0.17) * v_u_4.SCALE
	},
	{
		["a"] = Vector3.new(-0.045, 0.135, -0.17) * v_u_4.SCALE,
		["b"] = Vector3.new(-0.045, 0.125, 0.17) * v_u_4.SCALE
	}
}
v_u_4.DAMP_GROUP = "wingR"
v_u_4.DROP_SIZE = Vector3.new(0.046, 0.024, 0.046)
v_u_4.ROOT = Vector3.new(0.04, 0.125, 0) * v_u_4.SCALE
local function v_u_46(p45) -- name: readFlag
	-- upvalues: (copy) v_u_4
	return p45.cctx.config.flag(v_u_4.FLAG)
end
local function v_u_50(p47) -- name: readStage
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v48 = p47.cctx.storyStage
	if type(v48) == "function" then
		return v48()
	else
		local v49 = v_u_1.LocalPlayer
		if v49 then
			return v49:GetAttribute(v_u_4.ATTR)
		else
			return nil
		end
	end
end
local function v_u_53(p51) -- name: readQuality
	local v52 = p51.cctx.controllers.Atmosphere
	if v52 and v52.quality then
		return v52.quality()
	else
		return nil
	end
end
function v_u_4.stageOf(p54) -- name: stageOf
	if type(p54) ~= "number" or (p54 ~= p54 or (p54 == (1 / 0) or p54 == (-1 / 0))) then
		return 0
	end
	local v55 = math.floor(p54)
	return math.clamp(v55, 0, 99)
end
function v_u_4.layers(p56) -- name: layers
	return {
		["bird"] = p56 >= 1
	}
end
function v_u_4.wanted(p57, p58) -- name: wanted
	-- upvalues: (copy) v_u_4
	local v59
	if p57 == true then
		v59 = v_u_4.layers(v_u_4.stageOf(p58)).bird
	else
		v59 = false
	end
	return v59
end
function v_u_4.facets() -- name: facets
	-- upvalues: (copy) v_u_29
	return v_u_29
end
local function v_u_70(p60, p61, p62, p63, p64, p65, p66, p67) -- name: newPart
	local v68 = Instance.new(p62)
	v68.Name = p61
	v68.Anchored = true
	v68.CanCollide = false
	v68.CanTouch = false
	v68.CanQuery = false
	v68.CastShadow = false
	v68.TopSurface = Enum.SurfaceType.Smooth
	v68.BottomSurface = Enum.SurfaceType.Smooth
	v68.Size = p63
	v68.CFrame = p64
	v68.Color = p65
	v68.Material = p66
	if p67 then
		v68.Transparency = p67
	end
	v68.Parent = p60.model
	p60.n = p60.n + 1
	local v69 = p60.parts
	table.insert(v69, v68)
	return v68
end
function v_u_4.triangle(p71, p72, p73, p74) -- name: triangle
	local v75 = p72 - p71
	local v76 = p73 - p71
	local v77 = p73 - p72
	local v78 = v75:Dot(v75)
	local v79 = v76:Dot(v76)
	local v80 = v77:Dot(v77)
	if v79 < v78 and v80 < v78 then
		local v81 = p73
		p73 = p71
		p71 = p72
		p72 = v81
	elseif v80 < v79 then
		if v78 >= v79 then
			local v82 = p72
			p72 = p71
			p71 = v82
		end
	else
		local v83 = p72
		p72 = p71
		p71 = v83
	end
	local v84 = p71 - p72
	local v85 = p73 - p72
	local v86 = p73 - p71
	local v87 = v85:Cross(v84)
	if v87.Magnitude < 1e-7 or v86.Magnitude < 0.00001 then
		return nil
	end
	local v88 = v87.Unit
	local v89 = v86:Cross(v88).Unit
	local v90 = v86.Unit
	local v91 = v84:Dot(v89)
	local v92 = math.abs(v91)
	local v93 = v84:Dot(v90)
	local v94 = math.abs(v93)
	local v95 = v85:Dot(v90)
	local v96 = math.abs(v95)
	if v92 < 0.0001 then
		return nil
	end
	local v97 = {}
	if v94 > 0.0001 then
		local v98 = {
			["cf"] = CFrame.fromMatrix((p72 + p71) / 2, v88, v89, v90),
			["size"] = Vector3.new(p74, v92, v94)
		}
		table.insert(v97, v98)
	end
	if v96 > 0.0001 then
		local v99 = {
			["cf"] = CFrame.fromMatrix((p72 + p73) / 2, -v88, v89, -v90),
			["size"] = Vector3.new(p74, v92, v96)
		}
		table.insert(v97, v99)
	end
	return v97
end
local function v_u_118(p100, p101, p102, p103, p104, p105, p106, p107, p108) -- name: placeFacet
	-- upvalues: (copy) v_u_4, (copy) v_u_70
	local v109 = p102.a
	local v110 = p102.b
	local v111 = p102.c
	if p108 then
		local v112 = (v109 + v110 + v111) / 3
		v109 = v112 + (v109 - v112) * p108
		v110 = v112 + (v110 - v112) * p108
		v111 = v112 + (v111 - v112) * p108
	end
	if p106 then
		v109 = v109 + p106
		v110 = v110 + p106
		v111 = v111 + p106
	end
	local v113 = v_u_4.triangle(v109, v110, v111, p105)
	if v113 then
		for _, v114 in v113 do
			local v115 = v_u_70(p100, p102.name, "WedgePart", v114.size, p101 * v114.cf, p104, Enum.Material.SmoothPlastic, p107)
			local v116 = p103[p102.group]
			if not v116 then
				v116 = {}
				p103[p102.group] = v116
			end
			local v117 = {
				["part"] = v115,
				["rel"] = v114.cf
			}
			table.insert(v116, v117)
		end
	end
end
local function v_u_122(p119) -- name: findCar
	-- upvalues: (copy) v_u_4
	for _, v120 in v_u_4.CAR_ORDER do
		for _, v121 in p119.root:GetChildren() do
			if not v121:IsA("Model") or v121.Name ~= v120 then
				continue
			end
			return v121
		end
	end
	return nil
end
local function v_u_148(p123, p_u_124, p_u_125) -- name: probeHood
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if v_u_2:IsRunning() then
		local v_u_126 = p123:GetPivot()
		local v127 = {}
		local v128 = {}
		for _, v129 in p123:GetDescendants() do
			if not v129:IsA("BasePart") or v129.Transparency >= 0.9 then
				continue
			end
			table.insert(v127, v129)
			v128[v129] = v129.CanQuery
			v129.CanQuery = true
		end
		local v_u_130 = RaycastParams.new()
		v_u_130.FilterType = Enum.RaycastFilterType.Include
		v_u_130.FilterDescendantsInstances = v127
		local v_u_131 = {}
		local function v141()
			-- upvalues: (copy) v_u_126, (copy) p_u_124, (copy) p_u_125, (ref) v_u_3, (copy) v_u_130, (copy) v_u_131
			for _, v132 in { Vector3.new(0, 0, 0), Vector3.new(0.4, 0, 0), Vector3.new(0, 0, 0.4) } do
				local v133 = (v_u_126 * CFrame.new(p_u_124 + v132.X, 0, p_u_125 + v132.Z)).Position
				local v134 = v_u_3
				local v135 = v133.X
				local v136 = v_u_126.Position.Y + 9
				local v137 = v133.Z
				local v138 = v134:Raycast(Vector3.new(v135, v136, v137), Vector3.new(0, -20, 0), v_u_130)
				if not v138 then
					return
				end
				local v139 = v_u_131
				local v140 = v138.Position
				table.insert(v139, v140)
			end
		end
		local v142 = pcall(v141)
		for v143, v144 in v128 do
			v143.CanQuery = v144
		end
		if v142 and #v_u_131 >= 3 then
			local v145 = (v_u_131[2] - v_u_131[1]):Cross(v_u_131[3] - v_u_131[1])
			if v145.Magnitude < 1e-6 then
				return nil, nil
			else
				local v146 = v145.Unit
				if v146.Y < 0 then
					v146 = -v146
				end
				local v147 = v_u_131[1].Y - v_u_126.Position.Y
				if v146.Y < 0.8 or (v147 < 1.2 or v147 > 3.9) then
					return nil, nil
				else
					return v_u_131[1], v146
				end
			end
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_4.birdFrame(p149, p150, p151) -- name: birdFrame
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v152 = p150.Unit
	local v153 = p151 - v152 * p151:Dot(v152)
	if v153.Magnitude < 0.001 then
		v153 = Vector3.new(1, 0, 0) - v152 * v152.X
	end
	return CFrame.lookAt(p149, p149 + v153.Unit, v152) * CFrame.Angles(v_u_5(v_u_4.TILT.x), 0, (v_u_5(v_u_4.TILT.z)))
end
function v_u_4.placement(p154) -- name: placement
	-- upvalues: (copy) v_u_4, (copy) v_u_148
	local v155 = v_u_4.SPOTS[p154.Name]
	local v156 = not v155 and 1.25 or v155.lx
	local v157 = not v155 and -6.8 or v155.lz
	local v158 = p154:GetPivot()
	local v159, v160 = v_u_148(p154, v156, v157)
	local v161
	if v159 and v160 then
		v161 = "probe"
	else
		if not v155 then
			return nil, "none"
		end
		local v162 = (v158 * CFrame.new(v156, 0, v157)).Position
		local v163 = v162.X
		local v164 = v158.Position.Y + v155.y
		local v165 = v162.Z
		v159 = Vector3.new(v163, v164, v165)
		v160 = v158:VectorToWorldSpace(v155.normal.Unit)
		v161 = "measured"
	end
	local v166 = v158:VectorToWorldSpace(v_u_4.HEAD_DIR.Unit)
	return v_u_4.birdFrame(v159, v160, v166), v161
end
function v_u_4._build(p167) -- name: _build
	-- upvalues: (copy) v_u_122, (copy) v_u_4, (copy) v_u_53, (copy) v_u_6, (copy) v_u_70, (copy) v_u_29, (copy) v_u_118, (copy) v_u_7
	local v168 = p167.scene
	local v169 = v_u_122(v168)
	if not v169 then
		p167.reason = "no car"
		return false
	end
	local v170, v171 = v_u_4.placement(v169)
	if not v170 then
		p167.reason = "no hood"
		return false
	end
	local v172 = v_u_53
	local v173, v174 = pcall(v172, v168)
	if v173 then
		if type(v174) == "number" then
			v173 = v174 <= 2
		else
			v173 = false
		end
	end
	local v175 = Instance.new("Folder")
	v175.Name = v_u_4.FOLDER
	local v176 = Instance.new("Model")
	v176.Name = v_u_4.BIRD
	v176.Parent = v175
	local v177 = {
		["model"] = nil,
		["n"] = 0,
		["low"] = nil,
		["parts"] = nil,
		["model"] = v176,
		["low"] = v173,
		["parts"] = {}
	}
	local v178 = {}
	local v179 = v_u_70(v177, "ContactShadow", "Part", Vector3.new(0.86, 0.012, 0.66) * v_u_4.SCALE, v170 * CFrame.new(0, 0.007, 0.02 * v_u_4.SCALE), v_u_6.shadow, Enum.Material.SmoothPlastic, 0.86)
	local v180 = Instance.new("SpecialMesh")
	v180.MeshType = Enum.MeshType.Sphere
	v180.Parent = v179
	if not v173 then
		local v181 = 0.5 * v_u_4.SCALE
		local v182 = 0.38 * v_u_4.SCALE
		local v183 = v_u_70(v177, "ContactShadowCore", "Part", Vector3.new(v181, 0.012, v182), v170 * CFrame.new(0, 0.009, 0.02 * v_u_4.SCALE), v_u_6.shadow, Enum.Material.SmoothPlastic, 0.8)
		local v184 = Instance.new("SpecialMesh")
		v184.MeshType = Enum.MeshType.Sphere
		v184.Parent = v183
	end
	local v185 = v170 * CFrame.new(0, 0.012, 0)
	local v186 = {}
	for _, v187 in v_u_29 do
		v186[v187.name] = v187
		local v188 = (v187.b - v187.a):Cross(v187.c - v187.a)
		local v189 = v188.Magnitude <= 1e-9 and Vector3.new(0, 1, 0) or v188.Unit
		local v190 = v_u_118
		local v191 = v_u_6.paper
		local v192 = v189:Dot(v_u_7)
		local v193 = math.abs(v192)
		local v194 = math.clamp(v193, 0, 1) * 0.22 + 0.78
		v190(v177, v185, v187, v178, Color3.new(v191.R * v194, v191.G * v194, v191.B * v194), v187.thick or 0.014, nil, nil, nil)
	end
	for _, v195 in v_u_29 do
		if not v195.worn then
			continue
		end
		local v196
		if v195.name == "Beak" then
			v196 = v195.b
		elseif v195.name == "Tail" then
			v196 = v195.c
		else
			v196 = v195.c
		end
		local v197 = {
			["name"] = v195.name .. "Worn",
			["a"] = v196,
			["b"] = v196:Lerp(v195.a, 0.3),
			["c"] = v196:Lerp(v195.b, 0.3),
			["group"] = v195.group
		}
		if v195.name == "Beak" then
			local v198 = v196:Lerp(v195.a, 0.45)
			local v199 = v196:Lerp(v195.c, 0.45)
			v197.b = v198
			v197.c = v199
		elseif v195.name == "Tail" then
			local v200 = v196:Lerp(v195.a, 0.3)
			local v201 = v196:Lerp(v195.b, 0.3)
			v197.b = v200
			v197.c = v201
		end
		local v202 = (v197.b - v197.a):Cross(v197.c - v197.a)
		local v203
		if v202.Magnitude > 1e-9 then
			local v204 = v202.Unit
			if v204.Y < 0 then
				local v205 = v204.Y
				if math.abs(v205) >= 0.2 or v204.X < 0 then
					v204 = -v204
				end
			end
			v203 = v204 * ((v195.thick or 0.014) * 0.5 + 0.004)
		else
			v203 = Vector3.new(0, 0, 0)
		end
		v_u_118(v177, v185, v197, v178, v_u_6.edge, 0.006, v203, nil, nil)
	end
	for v206, v207 in v_u_4.CREASES do
		local v208 = "Crease" .. v206
		local v209 = v185 * v207.a
		local v210 = v185 * v207.b
		local v211 = v_u_6.crease
		local v212 = (v210 - v209).Magnitude
		local v213 = v_u_70
		local v214 = math.max(0.01, v212)
		local v215 = v213(v177, v208, "Part", Vector3.new(0.011, 0.011, v214), CFrame.lookAt((v209 + v210) / 2, v210), v211, Enum.Material.SmoothPlastic, 0.45)
		if v206 < 3 then
			continue
		end
		local v216 = v178[v207.a.X > 0 and "wingR" or "wingL"]
		local v217 = {
			["part"] = v215,
			["rel"] = v185:ToObjectSpace(v215.CFrame)
		}
		table.insert(v216, v217)
	end
	if not v173 then
		local v218 = v186.WingR
		local v219 = (v218.a + v218.b + v218.c) / 3
		local v220 = {
			["name"] = "Damp",
			["a"] = nil,
			["b"] = nil,
			["c"] = nil,
			["group"] = "wingR",
			["a"] = v218.c,
			["b"] = v218.c:Lerp(v218.a, 0.5),
			["c"] = v218.c:Lerp(v218.b, 0.55)
		}
		local v221 = (v220.b - v220.a):Cross(v220.c - v220.a)
		local v222 = v221.Magnitude <= 1e-9 and Vector3.new(0, 1, 0) or v221.Unit
		if v222.Y < 0 then
			v222 = -v222
		end
		v_u_118(v177, v185, v220, v178, v_u_6.damp, 0.006, v222 * 0.012, 0.45, nil)
		local v223 = v218.c:Lerp(v219, 0.62) + v222 * 0.019
		local v224 = v_u_70(v177, "Drop", "Part", v_u_4.DROP_SIZE, v185 * CFrame.lookAt(v223, v223 + v222:Cross(Vector3.new(1, 0, 0)).Unit, v222) * CFrame.Angles(0, 0, 0), v_u_6.drop, Enum.Material.Glass, 0.3)
		local v225 = Instance.new("SpecialMesh")
		v225.MeshType = Enum.MeshType.Sphere
		v225.Parent = v224
		v224.Reflectance = 0.25
		local v226 = v178.wingR
		local v227 = {
			["part"] = v224,
			["rel"] = v185:ToObjectSpace(v224.CFrame)
		}
		table.insert(v226, v227)
	end
	if v177.n > v_u_4.MAX_PARTS then
		v175:Destroy()
		p167.reason = "over budget"
		return false
	end
	v175.Parent = v168.root
	p167.root = v175
	p167.model = v176
	p167.bf = v185
	p167.pieces = v178
	p167.nParts = v177.n
	p167.nLights = 0
	p167.low = v173
	p167.src = v171
	p167.reason = "built"
	p167.fluttering = false
	return true
end
function v_u_4._unbuild(p228) -- name: _unbuild
	if p228.root then
		p228.root:Destroy()
		p228.root = nil
	end
	p228.model = nil
	p228.pieces = {}
	p228.fluttering = false
	p228.nParts = 0
	p228.nLights = 0
	p228.reason = "off"
end
function v_u_4._sync(p229) -- name: _sync
	-- upvalues: (copy) v_u_46, (copy) v_u_50, (copy) v_u_4, (copy) v_u_53
	local v230 = p229.scene
	if v230.root and v230.root.Parent then
		local v231 = v_u_46
		local v232, v233 = pcall(v231, v230)
		if v232 then
			v232 = v233 == true
		end
		local v234 = v_u_50
		local v235, v236 = pcall(v234, v230)
		if not v235 then
			v236 = nil
		end
		p229.flag = v232
		p229.stage = v_u_4.stageOf(v236)
		if v_u_4.wanted(v232, v236) then
			if p229.root then
				local v237 = v_u_53
				local v238, v239 = pcall(v237, v230)
				if v238 then
					if type(v239) == "number" then
						v238 = v239 <= 2
					else
						v238 = false
					end
				end
				if v238 ~= p229.low then
					p229:_unbuild()
					p229:_build()
					return
				end
			elseif p229.retryIn <= 0 and not p229:_build() then
				p229.retryIn = 2
				return
			end
		elseif p229.root then
			p229:_unbuild()
		end
	else
		p229:destroy()
	end
end
local function v_u_240() -- name: readWind
	-- upvalues: (copy) v_u_3
	return v_u_3.GlobalWind.Magnitude
end
local function v_u_248(p241, p242, p243, p244) -- name: turnWing
	-- upvalues: (copy) v_u_4
	if p242 then
		local v245 = v_u_4.ROOT
		local v246 = CFrame.new(p243 * v245.X, v245.Y, 0) * CFrame.Angles(0, 0, p243 * p244) * CFrame.new(-p243 * v245.X, -v245.Y, 0)
		for _, v247 in p242 do
			v247.part.CFrame = p241 * v246 * v247.rel
		end
	end
end
function v_u_4._flutter(p249) -- name: _flutter
	-- upvalues: (copy) v_u_248
	local v250 = p249.wind / 20
	local v251 = math.clamp(v250, 0, 1) * 0.061086523819801536
	local v252 = p249.t
	local v253 = v252 * 1.3
	local v254 = math.sin(v253) * 0.45
	local v255 = v252 * 0.47 + 1
	local v256 = v254 * math.sin(v255) + 0.55
	local v257 = p249.pieces
	local v258 = v_u_248
	local v259 = p249.bf
	local v260 = v257.wingR
	local v261 = v251 * v256
	local v262 = v252 * 8.5
	v258(v259, v260, 1, v261 * math.sin(v262))
	local v263 = v_u_248
	local v264 = p249.bf
	local v265 = v257.wingL
	local v266 = v251 * v256
	local v267 = v252 * 8.5 + 1.7
	v263(v264, v265, -1, v266 * math.sin(v267))
	p249.fluttering = v251 > 0
end
function v_u_4._rest(p268) -- name: _rest
	-- upvalues: (copy) v_u_248
	local v269 = p268.pieces
	v_u_248(p268.bf, v269.wingR, 1, 0)
	v_u_248(p268.bf, v269.wingL, -1, 0)
	p268.fluttering = false
end
function v_u_4._tick(p270, p271) -- name: _tick
	-- upvalues: (copy) v_u_240
	p270.t = p270.t + p271
	p270.retryIn = p270.retryIn - p271
	p270.pollIn = p270.pollIn - p271
	if p270.pollIn <= 0 then
		p270.pollIn = 0.25
		p270:_sync()
		if p270.dead then
			return
		end
		local v272
		if p270.root then
			local v273 = v_u_240
			local v274, v275 = pcall(v273)
			v272 = (not v274 or type(v275) ~= "number") and 0 or v275
		else
			v272 = 0
		end
		p270.wind = v272
		if p270.root and (p270.fluttering and p270.wind < 1) then
			p270:_rest()
		end
	end
	if p270.root and p270.wind >= 1 then
		p270.accFlutter = p270.accFlutter + p271
		if p270.accFlutter >= 0.05 then
			p270.accFlutter = 0
			p270:_flutter()
		end
	end
end
function v_u_4.step(p276, p277) -- name: step
	if p276.dead then
		return
	else
		local v278 = os.clock()
		local v279 = p276._tick
		local v280, v281 = pcall(v279, p276, p277)
		if v280 then
			p276.costSum = p276.costSum + (os.clock() - v278)
			p276.costN = p276.costN + 1
		else
			warn("[MenuStory] step failed, bird removed:", v281)
			p276:destroy()
		end
	end
end
function v_u_4.state(p282) -- name: state
	-- upvalues: (copy) v_u_50
	local v283 = 0
	if p282.conn then
		v283 = v283 + 1
	end
	if p282.destroyConn then
		v283 = v283 + 1
	end
	local v284 = {
		["flag"] = p282.flag,
		["stage"] = p282.stage
	}
	local v285 = p282.scene
	local v286 = v_u_50
	local v287, v288 = pcall(v286, v285)
	if not v287 then
		v288 = nil
	end
	v284.raw = v288
	local v289
	if p282.root == nil then
		v289 = false
	else
		v289 = p282.root.Parent ~= nil
	end
	v284.built = v289
	v284.parts = p282.nParts
	v284.lights = p282.nLights
	v284.low = p282.low
	v284.src = p282.src
	v284.reason = p282.reason
	v284.wind = p282.wind
	v284.fluttering = p282.fluttering
	v284.conns = v283
	v284.steps = p282.costN
	v284.avgMs = p282.costN <= 0 and 0 or p282.costSum / p282.costN * 1000
	v284.dead = p282.dead
	return v284
end
function v_u_4.destroy(p290) -- name: destroy
	-- upvalues: (ref) v_u_30
	if not p290.dead or (p290.root or (p290.conn or p290.destroyConn)) then
		p290.dead = true
		if p290.conn then
			p290.conn:Disconnect()
			p290.conn = nil
		end
		if p290.destroyConn then
			p290.destroyConn:Disconnect()
			p290.destroyConn = nil
		end
		local v291 = p290._unbuild
		pcall(v291, p290)
		if v_u_30 == p290 then
			v_u_30 = nil
		end
	end
end
function v_u_4.new(p_u_292) -- name: new
	-- upvalues: (copy) v_u_4, (ref) v_u_30, (copy) v_u_2, (copy) v_u_1
	local v293 = {
		["scene"] = nil,
		["root"] = nil,
		["model"] = nil,
		["bf"] = nil,
		["pieces"] = nil,
		["flag"] = false,
		["stage"] = 0,
		["low"] = false,
		["src"] = "",
		["reason"] = "new",
		["nParts"] = 0,
		["nLights"] = 0,
		["t"] = 0,
		["pollIn"] = 0,
		["retryIn"] = 0,
		["accFlutter"] = 0,
		["wind"] = 0,
		["fluttering"] = false,
		["costSum"] = 0,
		["costN"] = 0,
		["dead"] = false,
		["conn"] = nil,
		["destroyConn"] = nil,
		["scene"] = p_u_292,
		["bf"] = CFrame.identity,
		["pieces"] = {}
	}
	local v294 = v_u_4
	local v_u_295 = setmetatable(v293, v294)
	v_u_30 = v_u_295
	local function v325()
		-- upvalues: (copy) p_u_292, (ref) v_u_30, (ref) v_u_2, (ref) v_u_1, (ref) v_u_4
		p_u_292.cctx.command("story.state", function()
			-- upvalues: (ref) v_u_30
			local v296 = v_u_30
			if not v296 then
				return "no story decoration (no menu scene)"
			end
			local v297 = v296:state()
			local v298 = v297.flag
			local v299 = tostring(v298)
			local v300 = v297.stage
			local v301 = tostring(v300)
			local v302 = v297.raw
			local v303 = tostring(v302)
			local v304 = v297.built
			local v305 = tostring(v304)
			local v306 = v297.parts
			local v307 = v297.lights
			local v308 = v297.low
			local v309 = tostring(v308)
			local v310 = v297.src
			local v311 = tostring(v310)
			local v312 = v297.reason
			local v313 = tostring(v312)
			local v314 = v297.wind
			local v315 = v297.fluttering
			local v316 = tostring(v315)
			local v317 = v297.conns
			local v318 = v297.steps
			local v319 = v297.avgMs
			local v320 = v297.dead
			return ("flag=%s stage=%s raw=%s built=%s parts=%d lights=%d low=%s src=%s reason=%s wind=%.1f flutter=%s conns=%d steps=%d avgMs=%.4f dead=%s"):format(v299, v301, v303, v305, v306, v307, v309, v311, v313, v314, v316, v317, v318, v319, (tostring(v320)))
		end)
		p_u_292.cctx.command("story.stage", function(p321)
			-- upvalues: (ref) v_u_2, (ref) v_u_1, (ref) v_u_4
			if not v_u_2:IsStudio() then
				return "Studio only"
			end
			local v322 = v_u_1.LocalPlayer
			if not v322 then
				return "no player"
			end
			local v323 = p321[1]
			if v323 == nil or (v323 == "nil" or v323 == "off") then
				v322:SetAttribute(v_u_4.ATTR, nil)
				return "StoryStage cleared"
			end
			local v324 = tonumber(v323)
			if not v324 then
				return "number or nil"
			end
			v322:SetAttribute(v_u_4.ATTR, v324)
			return "StoryStage " .. tostring(v324)
		end)
	end
	pcall(v325)
	local v326 = v_u_295._sync
	local v327, v328 = pcall(v326, v_u_295)
	if not v327 then
		warn("[MenuStory] build failed:", v328)
		v_u_295:destroy()
		return v_u_295
	end
	v_u_295.pollIn = 0.25
	v_u_295.conn = v_u_2.Heartbeat:Connect(function(p329)
		-- upvalues: (copy) v_u_295
		v_u_295:step(p329)
	end)
	local v330 = p_u_292.root
	if v330 then
		v_u_295.destroyConn = v330.Destroying:Connect(function()
			-- upvalues: (copy) v_u_295
			v_u_295:destroy()
		end)
	end
	return v_u_295
end
return v_u_4