-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewLight

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = {}
local v_u_5 = {}
function v4.use(p6) -- name: use
	-- upvalues: (ref) v_u_5
	v_u_5 = type(p6) ~= "table" and {} or p6
end
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = false
local v_u_11 = nil
local v_u_12 = "NORMAL"
local v_u_13 = "RAID"
local v_u_14 = "OFF"
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = nil
local v_u_19 = ""
local v_u_20 = true
local v_u_21 = -1000000000
local v_u_22 = 0
local v_u_23 = false
local v_u_24 = {}
local v_u_25 = "Clear"
local v_u_26 = -1000000000
local v_u_27 = nil
local v_u_28 = true
local v_u_29 = false
local v_u_30 = nil
local v_u_31 = {}
local v_u_32 = {}
local v_u_33 = { 0, 0, 0 }
local v_u_34 = 0
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = nil
local v_u_38 = -1
local v_u_39 = -1
local function v_u_45(p40) -- name: instOf
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (copy) v_u_31
	local v41
	if v_u_5.lighting == nil then
		v41 = v_u_1
	else
		v41 = v_u_5.lighting
	end
	if p40 == "Lighting" then
		return v41
	end
	local v42 = v_u_31[p40]
	if v42 ~= nil and v42.Parent == v41 then
		return v42
	end
	local v43 = nil
	if p40 == "Atmosphere" then
		v43 = v41:FindFirstChildOfClass("Atmosphere")
	elseif p40 == "Grade" then
		local v44 = v41:FindFirstChild("HushGrade")
		if v44 ~= nil then
			if v44:IsA("ColorCorrectionEffect") then
				v43 = v44
			end
		end
	elseif p40 == "Bloom" then
		v43 = v41:FindFirstChildOfClass("BloomEffect")
	end
	v_u_31[p40] = v43
	return v43
end
local v_u_46 = nil
local function v_u_47() -- name: markDirty
	-- upvalues: (ref) v_u_20
	v_u_20 = true
end
local function v_u_54(p48, p_u_49) -- name: watchInst
	-- upvalues: (copy) v_u_24, (copy) v_u_47, (ref) v_u_20
	local v_u_50 = v_u_24[p48]
	if v_u_50 ~= nil and v_u_50.inst == p_u_49 then
		return true
	end
	if v_u_50 ~= nil then
		pcall(function()
			-- upvalues: (copy) v_u_50
			v_u_50.conn:Disconnect()
		end)
		v_u_24[p48] = nil
	end
	local function v51()
		-- upvalues: (copy) p_u_49, (ref) v_u_47
		return p_u_49.Changed:Connect(v_u_47)
	end
	local v52, v53 = pcall(v51)
	if not v52 or v53 == nil then
		return false
	end
	v_u_24[p48] = {
		["inst"] = p_u_49,
		["conn"] = v53
	}
	v_u_20 = true
	return true
end
local function v_u_56() -- name: unwatchAll
	-- upvalues: (copy) v_u_24, (ref) v_u_23, (ref) v_u_20
	for _, v_u_55 in v_u_24 do
		pcall(function()
			-- upvalues: (copy) v_u_55
			v_u_55.conn:Disconnect()
		end)
	end
	table.clear(v_u_24)
	v_u_23 = false
	v_u_20 = true
end
local function v_u_65(p57, p58, p59) -- name: readValue
	-- upvalues: (copy) v_u_32
	local v60 = p57[p58.key]
	if p58.kind ~= "rgb" then
		return v60
	end
	local v61 = v_u_32[p59]
	if v61 == nil then
		v61 = { 0, 0, 0 }
		v_u_32[p59] = v61
	end
	local v62 = v60.R
	local v63 = v60.G
	local v64 = v60.B
	v61[1] = v62
	v61[2] = v63
	v61[3] = v64
	return v61
end
local function v_u_68(p66) -- name: raidAttr
	-- upvalues: (ref) v_u_5, (copy) v_u_3
	if v_u_5.raidAttr == nil then
		local v67 = v_u_3:FindFirstChild("HushRuntime") or workspace:FindFirstChild("HushRuntime")
		if v67 then
			v67 = v67:FindFirstChild("Raid")
		end
		if v67 then
			return v67:GetAttribute(p66)
		else
			return nil
		end
	else
		return v_u_5.raidAttr(p66)
	end
end
local function v_u_84(p69) -- name: refreshRaid
	-- upvalues: (ref) v_u_26, (ref) v_u_5, (ref) v_u_8, (copy) v_u_3, (copy) v_u_68, (ref) v_u_27, (ref) v_u_28, (ref) v_u_9, (ref) v_u_25
	if p69 - v_u_26 >= 0.5 then
		v_u_26 = p69
		local v70
		if v_u_5.presets == nil then
			if v_u_8 == nil then
				v_u_8 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("LightingPresets"))
			end
			v70 = v_u_8
		else
			v70 = v_u_5.presets
		end
		local v71 = v_u_68("TimeOfDay")
		if not v70.isTime(v71) then
			v71 = nil
		end
		v_u_27 = v71
		local v72 = v_u_68("Weather")
		local v73 = nil
		v_u_28 = false
		local v74 = v_u_9 and v_u_9.controllers
		if v74 then
			v74 = v_u_9.controllers.Atmosphere
		end
		if v74 ~= nil and v74.current ~= nil then
			local v75 = v74.current
			local v76, v77 = pcall(v75)
			if v76 and type(v77) == "table" then
				v_u_28 = v77.place == "Raid" and true or v77.override ~= nil
				v73 = v77.weather
			end
		end
		local v78 = nil
		local v79
		if v70.isWeather(v72) or (v70.isWeather(v73) or v70.weatherForSeed == nil) then
			v79 = v78
		else
			local v80 = v70.weatherForSeed
			local v81 = v_u_68("RaidId") or "raid"
			local v82 = tostring(v81)
			local v83
			v83, v79 = pcall(v80, v82)
			if not v83 then
				v79 = v78
			end
		end
		if v70.isWeather(v72) then
			v73 = v72
		elseif not v70.isWeather(v73) then
			v73 = not v70.isWeather(v79) and "Clear" or v79
		end
		v_u_25 = v73
	end
end
local function v_u_100(p85) -- name: refreshImposed
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_8, (copy) v_u_84, (ref) v_u_13, (ref) v_u_28, (ref) v_u_27, (ref) v_u_25, (ref) v_u_29, (ref) v_u_20, (ref) v_u_18, (copy) v_u_17, (ref) v_u_19, (ref) v_u_46
	local v86
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v86 = v_u_7
	else
		v86 = v_u_5.rules
	end
	local v87
	if v_u_5.presets == nil then
		if v_u_8 == nil then
			v_u_8 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("LightingPresets"))
		end
		v87 = v_u_8
	else
		v87 = v_u_5.presets
	end
	v_u_84(p85)
	local v88, v89 = v86.lookFor(v_u_13, v_u_28, v_u_27, v_u_25, v_u_25, v87.isTime, v87.isWeather)
	local v90 = v_u_29
	local v91
	if v88 == nil then
		v91 = false
	else
		v91 = v_u_13 == "RAID"
	end
	v_u_29 = v91
	if v_u_29 ~= v90 then
		v_u_20 = true
	end
	if v88 == nil then
		if v_u_18 ~= nil then
			table.clear(v_u_17)
			v_u_18 = nil
			v_u_19 = ""
			v_u_20 = true
		end
		if v90 then
			v_u_46(false)
		end
		return
	elseif v88 == v_u_18 and v89 == v_u_19 then
		return
	else
		local v92 = v87.resolve
		local v93, v94 = pcall(v92, "Raid", v88, v89)
		if v93 and type(v94) == "table" then
			table.clear(v_u_17)
			for v95, v96 in v86.PROPS do
				local v97 = v94[v96.inst]
				local v98
				if type(v97) == "table" then
					v98 = v97[v96.key]
				else
					v98 = nil
				end
				if v98 == nil then
					continue
				end
				if v96.kind == "rgb" then
					local v99
					if typeof(v98) == "Color3" then
						v99 = true
					elseif type(v98) == "table" then
						v99 = v98.R ~= nil
					else
						v99 = false
					end
					if not v99 then
						continue
					end
					v_u_17[v95] = { v98.R, v98.G, v98.B }
				else
					if type(v98) ~= "number" then
						continue
					end
					v_u_17[v95] = v98
				end
			end
			v_u_18 = v88
			v_u_19 = v89
			v_u_20 = true
		end
	end
end
local function v_u_119(p101) -- name: lookFrame
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_30, (copy) v_u_100, (ref) v_u_12, (ref) v_u_13, (ref) v_u_29, (ref) v_u_20, (ref) v_u_23, (ref) v_u_21, (ref) v_u_22, (copy) v_u_45, (copy) v_u_54, (copy) v_u_16, (copy) v_u_65, (copy) v_u_17, (copy) v_u_33
	local v102
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v102 = v_u_7
	else
		v102 = v_u_5.rules
	end
	v_u_30 = p101
	v_u_100(p101)
	if v102.active(v_u_12, v_u_13, v_u_29) then
		if v_u_20 or (not v_u_23 or (p101 < v_u_21 or p101 - v_u_21 >= 0.25)) then
			v_u_20 = false
			v_u_21 = p101
			v_u_22 = v_u_22 + 1
			local v103 = true
			for v104, v105 in v102.PROPS do
				if not v102.relevant(v105, v_u_12, v_u_13, v_u_29) then
					continue
				end
				local v106 = v_u_45(v105.inst)
				if v106 == nil then
					v103 = false
				else
					if not v_u_54(v105.inst, v106) then
						v103 = false
					end
					local v107 = v_u_16[v104]
					if v107 == nil then
						v107 = v102.trackNew()
						v_u_16[v104] = v107
					end
					local v108 = v_u_65(v106, v105, v104)
					local v109 = v102.observe(v107, v108)
					local v110 = v102.wanted
					local v111 = v_u_12
					local v112
					if v_u_13 == "RAID" and not v_u_29 then
						v112 = nil
					else
						v112 = v_u_17[v104]
					end
					local v113 = v110(v105, v109, v111, v112, v_u_33)
					if not v102.same(v108, v113) then
						if v105.kind == "rgb" then
							local v114 = v105.key
							local v115 = v113[1]
							local v116 = v113[2]
							local v117 = v113[3]
							local v118
							if v_u_5.newColor == nil then
								v118 = Color3.new(v115, v116, v117)
							else
								v118 = v_u_5.newColor(v115, v116, v117)
							end
							v106[v114] = v118
						else
							v106[v105.key] = v113
						end
					end
					v102.wrote(v107, v113)
				end
			end
			v_u_23 = v103
		end
	else
		return
	end
end
v_u_46 = function(p120)
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (copy) v_u_16, (ref) v_u_12, (ref) v_u_13, (ref) v_u_29, (copy) v_u_45, (copy) v_u_65
	local v121
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v121 = v_u_7
	else
		v121 = v_u_5.rules
	end
	for v122, v123 in v121.PROPS do
		local v124 = v_u_16[v122]
		if v124 == nil or (v124.mine == nil or not p120 and v121.relevant(v123, v_u_12, v_u_13, v_u_29)) then
			continue
		end
		local v125 = v_u_45(v123.inst)
		if v125 ~= nil then
			local v126 = v121.restoreValue(v124, (v_u_65(v125, v123, v122)))
			if v126 ~= nil then
				if v123.kind == "rgb" then
					local v127 = v123.key
					local v128 = v126[1]
					local v129 = v126[2]
					local v130 = v126[3]
					local v131
					if v_u_5.newColor == nil then
						v131 = Color3.new(v128, v129, v130)
					else
						v131 = v_u_5.newColor(v128, v129, v130)
					end
					v125[v127] = v131
				else
					v125[v123.key] = v126
				end
			end
		end
		v121.trackClear(v124)
	end
end
local function v_u_137() -- name: ensureTorch
	-- upvalues: (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_38, (ref) v_u_39
	if v_u_35 ~= nil and (v_u_35.Parent ~= nil and v_u_36 ~= nil) then
		return true
	end
	if v_u_37 ~= nil then
		v_u_37:Destroy()
	end
	local v132
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v132 = v_u_7
	else
		v132 = v_u_5.rules
	end
	local v133 = workspace:FindFirstChild("HushLocal")
	local v134 = Instance.new("Folder")
	v134.Name = "ReviewLight"
	v134.Parent = v133 or workspace
	v_u_37 = v134
	local v135 = Instance.new("Part")
	v135.Name = "TorchPart"
	v135.Anchored = true
	v135.CanCollide = false
	v135.CanQuery = false
	v135.CanTouch = false
	v135.CastShadow = false
	v135.Transparency = 1
	v135.Size = Vector3.new(0.2, 0.2, 0.2)
	v135.Parent = v134
	local v136 = Instance.new("SpotLight")
	v136.Name = "Torch"
	v136.Face = Enum.NormalId.Front
	v136.Shadows = false
	v136.Brightness = v132.TORCH_BRIGHTNESS
	v136.Color = Color3.fromRGB(v132.TORCH_COLOR[1], v132.TORCH_COLOR[2], v132.TORCH_COLOR[3])
	v136.Enabled = false
	v136.Parent = v135
	v_u_35 = v135
	v_u_36 = v136
	v_u_38 = -1
	v_u_39 = -1
	return true
end
local function v_u_148() -- name: torchFrame
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_14, (ref) v_u_15, (ref) v_u_36, (ref) v_u_11, (copy) v_u_137, (ref) v_u_35, (ref) v_u_38, (ref) v_u_39
	local v138
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v138 = v_u_7
	else
		v138 = v_u_5.rules
	end
	if v_u_14 == "OFF" or v_u_15 == nil then
		if v_u_36 ~= nil and v_u_36.Enabled then
			v_u_36.Enabled = false
		end
		return
	else
		local v139 = workspace.CurrentCamera
		if v139 == nil then
			if v_u_36 ~= nil and v_u_36.Enabled then
				v_u_36.Enabled = false
			end
			return
		else
			local v140
			if v_u_11 == nil then
				v140 = nil
			else
				v140 = v_u_11()
			end
			if v140 == nil then
				v140 = v139.Focus.Position
			end
			local v141 = v139.CFrame.Position
			local v142, v143, v144 = v138.torchPose(v141.X, v141.Y, v141.Z, v140.X, v140.Y, v140.Z, v_u_15.range)
			local v145 = Vector3.new(v142, v143, v144)
			if (v140 - v145).Magnitude < 0.1 then
				if v_u_36 ~= nil and v_u_36.Enabled then
					v_u_36.Enabled = false
				end
				return
			else
				v_u_137()
				local v146 = v_u_35
				local v147 = v_u_36
				if v146 ~= nil and v147 ~= nil then
					v146.CFrame = CFrame.lookAt(v145, v140)
					if v_u_38 ~= v_u_15.range then
						v147.Range = v_u_15.range
						v_u_38 = v_u_15.range
					end
					if v_u_39 ~= v_u_15.angle then
						v147.Angle = v_u_15.angle
						v_u_39 = v_u_15.angle
					end
					if not v147.Enabled then
						v147.Enabled = true
					end
				end
			end
		end
	end
end
local function v_u_149() -- name: destroyTorch
	-- upvalues: (ref) v_u_37, (ref) v_u_35, (ref) v_u_36, (ref) v_u_38, (ref) v_u_39
	if v_u_37 ~= nil then
		v_u_37:Destroy()
	end
	v_u_37 = nil
	v_u_35 = nil
	v_u_36 = nil
	v_u_38 = -1
	v_u_39 = -1
end
local function v_u_150() -- name: step
	-- upvalues: (copy) v_u_119, (copy) v_u_148
	v_u_119(os.clock())
	v_u_148()
end
local function v_u_155(_) -- name: frame
	-- upvalues: (ref) v_u_10, (copy) v_u_150, (ref) v_u_34, (copy) v_u_2, (ref) v_u_46, (copy) v_u_149
	if v_u_10 then
		local v151 = v_u_150
		if not pcall(v151) then
			v_u_34 = v_u_34 + 1
			if v_u_34 >= 8 then
				v_u_10 = false
				local function v152()
					-- upvalues: (ref) v_u_2
					v_u_2:UnbindFromRenderStep("ReviewLight")
				end
				pcall(v152)
				warn("[ReviewLight] switched off after repeated errors")
				local v153 = v_u_46
				pcall(v153, true)
				local v154 = v_u_149
				pcall(v154)
			end
		end
	end
end
function v4.init(p156) -- name: init
	-- upvalues: (ref) v_u_9
	v_u_9 = p156
end
function v4.start(p157) -- name: start
	-- upvalues: (ref) v_u_11, (ref) v_u_10, (ref) v_u_34, (ref) v_u_18, (ref) v_u_19, (copy) v_u_17, (ref) v_u_26, (ref) v_u_29, (ref) v_u_30, (ref) v_u_20, (ref) v_u_15, (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_14, (copy) v_u_2, (copy) v_u_155
	v_u_11 = p157
	if not v_u_10 then
		v_u_10 = true
		v_u_34 = 0
		v_u_18 = nil
		v_u_19 = ""
		table.clear(v_u_17)
		v_u_26 = -1000000000
		v_u_29 = false
		v_u_30 = nil
		v_u_20 = true
		local v158
		if v_u_5.rules == nil then
			if v_u_7 == nil then
				v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
			end
			v158 = v_u_7
		else
			v158 = v_u_5.rules
		end
		v_u_15 = v158.torchSettings(v_u_14)
		v_u_2:BindToRenderStep("ReviewLight", Enum.RenderPriority.Last.Value, v_u_155)
	end
end
function v4.stop() -- name: stop
	-- upvalues: (ref) v_u_29, (ref) v_u_10, (copy) v_u_2, (ref) v_u_46, (copy) v_u_16, (copy) v_u_17, (ref) v_u_18, (ref) v_u_19, (copy) v_u_56, (copy) v_u_149, (ref) v_u_11
	v_u_29 = false
	if v_u_10 then
		v_u_10 = false
		local function v159()
			-- upvalues: (ref) v_u_2
			v_u_2:UnbindFromRenderStep("ReviewLight")
		end
		pcall(v159)
	end
	local v160 = v_u_46
	pcall(v160, true)
	table.clear(v_u_16)
	table.clear(v_u_17)
	v_u_18 = nil
	v_u_19 = ""
	v_u_56()
	local v161 = v_u_149
	pcall(v161)
	v_u_11 = nil
end
function v4.level() -- name: level
	-- upvalues: (ref) v_u_12
	return v_u_12
end
function v4.time() -- name: time
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v4.torch() -- name: torch
	-- upvalues: (ref) v_u_14
	return v_u_14
end
function v4.words() -- name: words
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	return {
		["level"] = v_u_12,
		["time"] = v_u_13,
		["torch"] = v_u_14
	}
end
function v4.cycleLevel() -- name: cycleLevel
	-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_20, (ref) v_u_10, (ref) v_u_46
	local v162
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v162 = v_u_7
	else
		v162 = v_u_5.rules
	end
	v_u_12 = v162.nextLevel(v_u_12)
	v_u_20 = true
	if v_u_10 then
		v_u_46(false)
	end
	return v_u_12
end
function v4.cycleTime() -- name: cycleTime
	-- upvalues: (ref) v_u_13, (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_18, (ref) v_u_19, (copy) v_u_17, (ref) v_u_20, (ref) v_u_10, (ref) v_u_30, (ref) v_u_26, (copy) v_u_100, (ref) v_u_46
	local v163
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v163 = v_u_7
	else
		v163 = v_u_5.rules
	end
	v_u_13 = v163.nextTime(v_u_13)
	v_u_18 = nil
	v_u_19 = ""
	table.clear(v_u_17)
	v_u_20 = true
	if v_u_10 then
		if v_u_30 ~= nil then
			v_u_26 = -1000000000
			v_u_100(v_u_30)
		end
		v_u_46(false)
	end
	return v_u_13
end
function v4.cycleTorch() -- name: cycleTorch
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (copy) v_u_3, (ref) v_u_14, (ref) v_u_15, (ref) v_u_36
	local v164
	if v_u_5.rules == nil then
		if v_u_7 == nil then
			v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
		end
		v164 = v_u_7
	else
		v164 = v_u_5.rules
	end
	v_u_14 = v164.nextTorch(v_u_14)
	v_u_15 = v164.torchSettings(v_u_14)
	if v_u_15 == nil and (v_u_36 ~= nil and v_u_36.Enabled) then
		v_u_36.Enabled = false
	end
	return v_u_14
end
function v4.adjustTorch(p165, p166) -- name: adjustTorch
	-- upvalues: (ref) v_u_15, (ref) v_u_5, (ref) v_u_7, (copy) v_u_3
	if v_u_15 ~= nil then
		local v167
		if v_u_5.rules == nil then
			if v_u_7 == nil then
				v_u_7 = require(v_u_3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewLightRules"))
			end
			v167 = v_u_7
		else
			v167 = v_u_5.rules
		end
		v167.torchAdjust(v_u_15, p165, p166)
	end
end
function v4._lookFrame(p168)
	-- upvalues: (copy) v_u_119
	v_u_119(p168)
end
function v4._release(p169)
	-- upvalues: (ref) v_u_46
	v_u_46(p169)
end
function v4._start()
	-- upvalues: (ref) v_u_10, (ref) v_u_18, (ref) v_u_19, (copy) v_u_17, (ref) v_u_26, (ref) v_u_29, (ref) v_u_30, (ref) v_u_20
	v_u_10 = true
	v_u_18 = nil
	v_u_19 = ""
	table.clear(v_u_17)
	v_u_26 = -1000000000
	v_u_29 = false
	v_u_30 = nil
	v_u_20 = true
end
function v4._reset()
	-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_31, (copy) v_u_32, (ref) v_u_18, (ref) v_u_19, (copy) v_u_56, (ref) v_u_21, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_34, (ref) v_u_11, (ref) v_u_9
	v_u_10 = false
	v_u_12 = "NORMAL"
	v_u_13 = "RAID"
	v_u_14 = "OFF"
	v_u_15 = nil
	table.clear(v_u_16)
	table.clear(v_u_17)
	table.clear(v_u_31)
	table.clear(v_u_32)
	v_u_18 = nil
	v_u_19 = ""
	v_u_56()
	v_u_21 = -1000000000
	v_u_25 = "Clear"
	v_u_26 = -1000000000
	v_u_27 = nil
	v_u_28 = true
	v_u_29 = false
	v_u_30 = nil
	v_u_34 = 0
	v_u_11 = nil
	v_u_9 = nil
end
function v4._passes()
	-- upvalues: (ref) v_u_22
	return v_u_22
end
function v4.state() -- name: state
	-- upvalues: (ref) v_u_15, (ref) v_u_12, (ref) v_u_13, (ref) v_u_29, (ref) v_u_14, (ref) v_u_36, (ref) v_u_10, (ref) v_u_34, (ref) v_u_22, (ref) v_u_23
	return ("level=%s time=%s auto=%d torch=%s range=%d angle=%d light=%d running=%d errors=%d passes=%d signals=%d"):format(v_u_12, v_u_13, v_u_29 and 1 or 0, v_u_14, v_u_15 == nil and 0 or v_u_15.range, v_u_15 == nil and 0 or v_u_15.angle, (v_u_36 == nil or not v_u_36.Enabled) and 0 or 1, v_u_10 and 1 or 0, v_u_34, v_u_22, v_u_23 and 1 or 0)
end
return v4