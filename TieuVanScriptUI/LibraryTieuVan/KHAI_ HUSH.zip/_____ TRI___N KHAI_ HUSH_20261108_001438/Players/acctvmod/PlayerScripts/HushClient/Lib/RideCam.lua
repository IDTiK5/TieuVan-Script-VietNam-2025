-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / RideCam

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("VehicleSpec"))
local v_u_5 = require(script.Parent.RideCamPlan)
local v6 = nil
local v7 = nil
local v8 = v3:FindFirstChild("RideArc")
local v_u_9
if v8 == nil then
	v_u_9 = v6
else
	local v10 = require
	local v11
	v11, v_u_9 = pcall(v10, v8)
	if v11 and type(v_u_9) == "table" then
		v_u_5.useArc(v_u_9)
	else
		v_u_9 = v6
	end
end
local v12 = v3:FindFirstChild("ViewMode")
local v_u_13
if v12 == nil then
	v_u_13 = v7
else
	local v14 = require
	local v15
	v15, v_u_13 = pcall(v14, v12)
	if not v15 or type(v_u_13) ~= "table" then
		v_u_13 = v7
	end
end
local v_u_16 = {
	["CLASSIC_TP"] = false,
	["ZOOM_MAX"] = v_u_4.CAMERA.ZOOM_MAX
}
local v_u_17 = v1.LocalPlayer
local v_u_18 = v_u_5.TUNE
local v_u_19 = nil
local v_u_20 = "none"
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = v_u_5.newChase()
local v_u_24 = v_u_5.newLean()
local v_u_25 = {
	["yawOff"] = 0,
	["elevOff"] = 0,
	["idle"] = 0,
	["eff"] = nil
}
local v_u_26 = v_u_5.newClassic()
local v_u_27 = 0
local v_u_28 = false
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = -1000000000
local v_u_35 = nil
local v_u_36 = -1000000000
local v_u_37 = -1000000000
local v_u_38 = 0
local v_u_39 = 0
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = {}
local v_u_44 = false
local v_u_45 = {
	["frames"] = 0,
	["modeChanges"] = 0,
	["wallPulls"] = 0,
	["classicFrames"] = 0
}
local function v_u_58() -- name: hookTouch
	-- upvalues: (ref) v_u_44, (copy) v_u_2, (copy) v_u_43, (ref) v_u_19, (copy) v_u_5, (copy) v_u_17, (ref) v_u_38, (ref) v_u_39
	if not v_u_44 then
		v_u_44 = true
		v_u_2.TouchStarted:Connect(function(p46, p47)
			-- upvalues: (ref) v_u_43
			local v48 = workspace.CurrentCamera
			local v49 = not v48 and 0 or v48.ViewportSize.X
			if not p47 and (v49 > 0 and p46.Position.X > v49 * 0.5) then
				v_u_43[p46] = true
			end
		end)
		v_u_2.TouchMoved:Connect(function(p50, _)
			-- upvalues: (ref) v_u_43, (ref) v_u_19, (ref) v_u_5, (ref) v_u_17, (ref) v_u_38, (ref) v_u_39
			if v_u_43[p50] and (v_u_19 ~= nil and v_u_19.kind ~= "none") then
				local v51 = v_u_5.lookFromTouch
				local v52 = p50.Delta.X
				local v53 = p50.Delta.Y
				local v54 = v_u_17:GetAttribute("Sensitivity")
				local v55, v56 = v51(v52, v53, (type(v54) ~= "number" or (v54 ~= v54 or v54 <= 0)) and 1 or math.clamp(v54, 0.05, 10))
				v_u_38 = v_u_38 + v55
				v_u_39 = v_u_39 + v56
			end
		end)
		v_u_2.TouchEnded:Connect(function(p57)
			-- upvalues: (ref) v_u_43
			v_u_43[p57] = nil
		end)
	end
end
local function v_u_68(p59) -- name: stickLook
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_17
	local function v60()
		-- upvalues: (ref) v_u_2
		return v_u_2:GetGamepadState(Enum.UserInputType.Gamepad1)
	end
	local v61, v62 = pcall(v60)
	if not v61 or type(v62) ~= "table" then
		return 0, 0
	end
	for _, v63 in v62 do
		if v63.KeyCode ~= Enum.KeyCode.Thumbstick2 then
			continue
		end
		local v64 = v_u_5.lookFromStick
		local v65 = v63.Position.X
		local v66 = v63.Position.Y
		local v67 = v_u_17:GetAttribute("Sensitivity")
		return v64(v65, v66, p59, (type(v67) ~= "number" or (v67 ~= v67 or v67 <= 0)) and 1 or math.clamp(v67, 0.05, 10))
	end
	return 0, 0
end
local function v_u_81(p69) -- name: readLook
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_17, (copy) v_u_68, (ref) v_u_38, (ref) v_u_39
	local v70, v71
	if v_u_2.MouseBehavior == Enum.MouseBehavior.Default then
		v70 = 0
		v71 = 0
	else
		local v72 = v_u_2:GetMouseDelta()
		local v73 = v_u_5.lookFromMouse
		local v74 = v72.X
		local v75 = v72.Y
		local v76 = v_u_17:GetAttribute("Sensitivity")
		v70, v71 = v73(v74, v75, (type(v76) ~= "number" or (v76 ~= v76 or v76 <= 0)) and 1 or math.clamp(v76, 0.05, 10))
	end
	local v77, v78 = v_u_68(p69)
	local v79 = v70 + (v77 + v_u_38)
	local v80 = v71 + (v78 + v_u_39)
	v_u_38 = 0
	v_u_39 = 0
	return v79, v80
end
function v_u_16.nudge(p82, p83) -- name: nudge
	-- upvalues: (ref) v_u_38, (copy) v_u_5, (ref) v_u_39
	v_u_38 = v_u_38 + v_u_5.num(p82, 0, -3.2, 3.2)
	v_u_39 = v_u_39 + v_u_5.num(p83, 0, -3.2, 3.2)
end
local function v_u_88(p84) -- name: rayParams
	-- upvalues: (ref) v_u_41, (ref) v_u_42, (copy) v_u_17
	if v_u_41 ~= nil and (v_u_42 == p84 and (p84 ~= nil and p84.Parent ~= nil)) then
		return v_u_41
	end
	local v85 = RaycastParams.new()
	v85.FilterType = Enum.RaycastFilterType.Exclude
	local v86 = {}
	if p84 ~= nil then
		table.insert(v86, p84)
	end
	if v_u_17.Character ~= nil then
		local v87 = v_u_17.Character
		table.insert(v86, v87)
	end
	v85.FilterDescendantsInstances = v86
	v85.RespectCanCollide = true
	v85.IgnoreWater = true
	v_u_41 = v85
	v_u_42 = p84
	return v85
end
local function v_u_92() -- name: headPos
	-- upvalues: (copy) v_u_17
	local v89 = v_u_17.Character
	if v89 == nil then
		return nil
	else
		local v90 = v89:FindFirstChild("Head")
		if v90 == nil or not v90:IsA("BasePart") then
			local v91 = v89:FindFirstChild("HumanoidRootPart")
			if v91 == nil or not v91:IsA("BasePart") then
				return nil
			else
				return v91.Position + Vector3.new(0, 1.5, 0)
			end
		else
			return v90.Position
		end
	end
end
local function v_u_102(p93) -- name: poseCF
	local v94 = p93.camX
	local v95 = p93.camY
	local v96 = p93.camZ
	local v97 = Vector3.new(v94, v95, v96)
	local v98 = p93.tgtX
	local v99 = p93.tgtY
	local v100 = p93.tgtZ
	local v101 = Vector3.new(v98, v99, v100)
	if (v101 - v97).Magnitude < 0.01 then
		v101 = v97 + Vector3.new(0, 0, -1)
	end
	return CFrame.lookAt(v97, v101), CFrame.new(v101)
end
local function v_u_119(p103) -- name: hullOf
	-- upvalues: (ref) v_u_32, (ref) v_u_34, (ref) v_u_33, (ref) v_u_35, (ref) v_u_36
	local v104 = p103.seatDef
	local v105
	if type(v104) == "table" then
		v105 = v104.arc
	else
		v105 = nil
	end
	if v105 == nil then
		return nil
	end
	local v106 = p103.typeId
	local v107 = tostring(v106)
	local v108 = v104.name
	local v109 = v107 .. "/" .. tostring(v108)
	if v109 == v_u_32 and os.clock() - v_u_34 < 2 then
		return v_u_33
	end
	if v_u_35 == nil and os.clock() - v_u_36 > 5 then
		v_u_36 = os.clock()
		local v110, v111 = pcall(function()
			return require(script.Parent.RidePose)
		end)
		if v110 and type(v111) == "table" then
			v_u_35 = v111
		end
	end
	local v112
	if v_u_35 == nil then
		v112 = v105
	else
		local v113 = v_u_35.hull
		if type(v113) == "function" then
			local v114 = v_u_35.hull
			local v115 = p103.typeId
			local v116 = v104.name
			local v117
			v117, v112 = pcall(v114, v115, v116, v105)
			if v117 then
				if type(v112) ~= "table" then
					v112 = v105
				end
			else
				v112 = v105
			end
		else
			v112 = v105
		end
	end
	local v118 = os.clock()
	v_u_32 = v109
	v_u_33 = v112
	v_u_34 = v118
	return v112
end
local function v_u_125() -- name: viewCeilings
	-- upvalues: (ref) v_u_9, (ref) v_u_13
	if v_u_9 ~= nil and v_u_13 ~= nil then
		local v120 = v_u_13.pitchLimits
		if type(v120) == "function" then
			local v121 = v_u_13.pitchLimits
			local v122, v123, v124 = pcall(v121, "fptp")
			if v122 and (type(v123) == "number" and type(v124) == "number") then
				return v_u_9.slopeDeg(v123), v_u_9.slopeDeg(-v124)
			else
				return nil, nil
			end
		end
	end
	return nil, nil
end
function v_u_16.set(p126) -- name: set
	-- upvalues: (copy) v_u_58, (ref) v_u_19, (copy) v_u_5, (ref) v_u_20, (ref) v_u_22, (ref) v_u_21, (copy) v_u_45, (copy) v_u_23, (copy) v_u_24, (ref) v_u_37, (ref) v_u_31, (copy) v_u_25
	if type(p126) == "table" then
		v_u_58()
		v_u_19 = p126
		local v127 = v_u_5.modeFor(p126.kind, p126.lean == true)
		if v127 ~= v_u_20 then
			local v128 = v_u_20
			if v_u_22 ~= nil then
				v_u_21 = {
					["from"] = v_u_22,
					["t0"] = os.clock(),
					["dur"] = v_u_5.blendTime(v128, v127)
				}
			end
			v_u_20 = v127
			local v129 = v_u_45
			v129.modeChanges = v129.modeChanges + 1
			if v127 == "drive" and (v128 == "none" or v128 == "eject") then
				v_u_23.ready = false
			end
			if v127 == "lean" then
				v_u_24.ready = false
				v_u_24.hold = 1
			else
				v_u_37 = -1000000000
				v_u_31 = 0
			end
			if v127 == "board" or v127 == "unboard" then
				local v130 = v_u_25
				local v131 = v_u_25
				v_u_25.yawOff = 0
				v130.elevOff = 0
				v131.idle = 0
			end
		end
	end
end
function v_u_16.clear() -- name: clear
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (ref) v_u_21, (copy) v_u_5, (copy) v_u_23, (copy) v_u_24, (ref) v_u_37
	if v_u_19 ~= nil or v_u_20 ~= "none" then
		if v_u_20 ~= "none" and v_u_22 ~= nil then
			v_u_21 = {
				["from"] = v_u_22,
				["t0"] = os.clock(),
				["dur"] = v_u_5.blendTime(v_u_20, "none")
			}
		end
		v_u_20 = "none"
		v_u_19 = nil
		v_u_23.ready = false
		v_u_24.ready = false
		v_u_37 = -1000000000
	end
end
function v_u_16.setEject(p132) -- name: setEject
	-- upvalues: (ref) v_u_40
	v_u_40 = p132
end
function v_u_16.mode() -- name: mode
	-- upvalues: (ref) v_u_20
	return v_u_20
end
function v_u_16.active() -- name: active
	-- upvalues: (ref) v_u_20
	return v_u_20 ~= "none"
end
function v_u_16.forcesTp() -- name: forcesTp
	-- upvalues: (ref) v_u_20
	return v_u_20 ~= "none"
end
function v_u_16.classicActive() -- name: classicActive
	-- upvalues: (ref) v_u_28
	return v_u_28
end
function v_u_16.zoomNow() -- name: zoomNow
	-- upvalues: (ref) v_u_28, (copy) v_u_26, (copy) v_u_16
	if not v_u_28 then
		return 1
	end
	local v133 = v_u_26.zoom
	local v134 = v_u_16.ZOOM_MAX
	return math.clamp(v133, 1, v134)
end
function v_u_16.aim() -- name: aim
	-- upvalues: (ref) v_u_20, (copy) v_u_5, (ref) v_u_37, (ref) v_u_29, (ref) v_u_30
	if v_u_20 == "lean" and v_u_5.aimFresh(os.clock() - v_u_37) then
		return v_u_29, v_u_30
	else
		return nil, nil
	end
end
function v_u_16.tint() -- name: tint
	-- upvalues: (ref) v_u_20, (copy) v_u_5, (ref) v_u_37, (ref) v_u_31
	if v_u_20 == "lean" and v_u_5.aimFresh(os.clock() - v_u_37) then
		return v_u_31
	else
		return nil
	end
end
function v_u_16.hull() -- name: hull
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_119
	if v_u_19 == nil or v_u_20 ~= "lean" then
		return nil
	else
		return v_u_119(v_u_19)
	end
end
local function v_u_172(p135, p136) -- name: chasePose
	-- upvalues: (ref) v_u_19, (copy) v_u_4, (copy) v_u_81, (copy) v_u_5, (copy) v_u_23, (copy) v_u_18, (copy) v_u_88, (copy) v_u_45
	local v137 = v_u_19
	local v_u_138 = v137.model
	local v139
	if v_u_138 == nil then
		v139 = nil
	else
		v139 = v_u_138:FindFirstChild("Chassis")
		if v139 == nil or not v139:IsA("BasePart") then
			v139 = nil
		end
	end
	if v139 == nil then
		return nil
	end
	local v140 = v137.spec
	local v141 = v139.AssemblyLinearVelocity
	local v142 = v139.CFrame.LookVector
	local v143 = v139:FindFirstChild("Cam_Focus")
	local v144
	if v143 == nil or not v143:IsA("Attachment") then
		local v145 = v139.Position
		local v146 = v139.Size.Y / 2 + v_u_4.CAMERA.TP_PIVOT_UP
		v144 = v145 + Vector3.new(0, v146, 0)
	else
		v144 = v143.WorldPosition
	end
	local v147 = v142.X * v142.X + v142.Z * v142.Z
	local v148 = math.sqrt(v147)
	local v149 = v148 <= 0.0001 and 0 or (v141.X * v142.X + v141.Z * v142.Z) / v148
	local v150, v151 = v_u_81(p135)
	local v152 = v_u_5.chaseStep
	local v153 = v_u_23
	local v154 = {}
	local v155 = v139.CFrame.LookVector
	v154.vehYaw = v_u_5.heading(v155.X, v155.Z)
	v154.pivotX = v144.X
	v154.pivotY = v144.Y
	v154.pivotZ = v144.Z
	v154.speed = v149
	v154.maxSpeed = not v140 and 60 or v140.maxSpeed
	v154.tpDist = not (v140 and v140.cam) and 16 or v140.cam.tpDist
	v154.dyaw = v150
	v154.delev = v151
	v154.baseFov = p136
	local v156, v157 = v152(v153, v154, p135)
	local v158 = v_u_23.px
	local v159 = v_u_23.py
	local v160 = v_u_23.pz
	local v_u_161 = Vector3.new(v158, v159, v160)
	local v162 = v156.camX
	local v163 = v156.camY
	local v164 = v156.camZ
	local v_u_165 = Vector3.new(v162, v163, v164) - v_u_161
	local v166
	if v_u_165.Magnitude < 0.1 then
		v166 = nil
	else
		local function v167()
			-- upvalues: (copy) v_u_161, (ref) v_u_18, (copy) v_u_165, (ref) v_u_88, (copy) v_u_138
			return workspace:Spherecast(v_u_161, v_u_18.COLLISION_RADIUS, v_u_165, (v_u_88(v_u_138)))
		end
		local v168, v169 = pcall(v167)
		if v168 and v169 then
			local v170 = v_u_45
			v170.wallPulls = v170.wallPulls + 1
			v166 = v169.Distance
		else
			v166 = nil
		end
	end
	local v171 = v_u_5.settle(v_u_23, v157.dist, v166, p135)
	return v_u_5.place(v_u_23, v157.yaw, v157.elev, v171)
end
local function v_u_192(p173, p174) -- name: leanPose
	-- upvalues: (ref) v_u_19, (copy) v_u_92, (copy) v_u_81, (copy) v_u_125, (copy) v_u_5, (copy) v_u_24, (copy) v_u_119, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_37
	local v175 = v_u_19
	local v176 = v175.model
	local v177
	if v176 == nil then
		v177 = nil
	else
		v177 = v176:FindFirstChild("Chassis")
		if v177 == nil or not v177:IsA("BasePart") then
			v177 = nil
		end
	end
	local v178 = v_u_92()
	if v177 == nil or v178 == nil then
		return nil
	end
	local v179, v180 = v_u_81(p173)
	local v181 = v175.side == "L" and -1 or 1
	local v182, v183 = v_u_125()
	local v184 = v_u_5.leanStep
	local v185 = v_u_24
	local v186 = {
		["headX"] = v178.X,
		["headY"] = v178.Y,
		["headZ"] = v178.Z
	}
	local v187 = v177.CFrame.LookVector
	v186.vehYaw = v_u_5.heading(v187.X, v187.Z)
	v186.arc = v_u_119(v175)
	v186.dyaw = v179
	v186.dpitch = -v180
	v186.shoulder = v181
	v186.baseFov = p174
	v186.viewUp = v182
	v186.viewDown = v183
	local v188, v189, v190, v191 = v184(v185, v186, p173)
	v_u_29 = v189
	v_u_30 = v190
	v_u_31 = type(v191) ~= "number" and 0 or v191
	v_u_37 = os.clock()
	return v188
end
local function v_u_230(p193, p194) -- name: sidePose
	-- upvalues: (ref) v_u_19, (copy) v_u_92, (copy) v_u_81, (copy) v_u_25, (copy) v_u_18, (copy) v_u_5, (copy) v_u_88, (copy) v_u_45
	local v195 = v_u_19
	local v196 = v195.model
	local v197
	if v196 == nil then
		v197 = nil
	else
		v197 = v196:FindFirstChild("Chassis")
		if v197 == nil or not v197:IsA("BasePart") then
			v197 = nil
		end
	end
	local v198 = v_u_92()
	if v197 == nil or v198 == nil then
		return nil
	end
	local v199, v200 = v_u_81(p193)
	if v199 == 0 and v200 == 0 then
		local v201 = v_u_25
		v201.idle = v201.idle + p193
		if v_u_25.idle >= v_u_18.RETURN_DELAY then
			local v202 = -v_u_18.RETURN_OMEGA * math.clamp(p193, 0, 0.25)
			local v203 = 1 - math.exp(v202)
			local v204 = v_u_25
			v204.yawOff = v204.yawOff - v_u_25.yawOff * v203
			local v205 = v_u_25
			v205.elevOff = v205.elevOff - v_u_25.elevOff * v203
		end
	else
		v_u_25.idle = 0
		v_u_25.yawOff = v_u_25.yawOff - v199
		local v206 = v_u_25
		local v207 = v_u_25.elevOff + v200
		v206.elevOff = math.clamp(v207, -0.6, 0.9)
	end
	local v208 = v_u_5.sidePose
	local v209 = {
		["pivotX"] = v198.X,
		["pivotY"] = v198.Y,
		["pivotZ"] = v198.Z
	}
	local v210 = v197.CFrame.LookVector
	v209.vehYaw = v_u_5.heading(v210.X, v210.Z)
	v209.side = v195.side or "L"
	v209.yawOff = v_u_25.yawOff
	v209.elevOff = v_u_25.elevOff
	v209.baseFov = p194
	local v211, v212 = v208(v209)
	local v213 = v212.pivotX
	local v214 = v212.pivotY
	local v215 = v212.pivotZ
	local v_u_216 = Vector3.new(v213, v214, v215)
	local v217 = v211.camX
	local v218 = v211.camY
	local v219 = v211.camZ
	local v220 = Vector3.new(v217, v218, v219)
	local v_u_221 = v195.model
	local v_u_222 = v220 - v_u_216
	local v223
	if v_u_222.Magnitude < 0.1 then
		v223 = nil
	else
		local function v224()
			-- upvalues: (copy) v_u_216, (ref) v_u_18, (copy) v_u_222, (ref) v_u_88, (copy) v_u_221
			return workspace:Spherecast(v_u_216, v_u_18.COLLISION_RADIUS, v_u_222, (v_u_88(v_u_221)))
		end
		local v225, v226 = pcall(v224)
		if v225 and v226 then
			local v227 = v_u_45
			v227.wallPulls = v227.wallPulls + 1
			v223 = v226.Distance
		else
			v223 = nil
		end
	end
	if v223 ~= nil then
		local v228 = (v223 - v_u_18.WALL_MARGIN) / (v220 - v_u_216).Magnitude
		local v229 = math.clamp(v228, 0.15, 1)
		v211.camX = v_u_216.X + (v220.X - v_u_216.X) * v229
		v211.camY = v_u_216.Y + (v220.Y - v_u_216.Y) * v229
		v211.camZ = v_u_216.Z + (v220.Z - v_u_216.Z) * v229
	end
	return v211
end
local function v_u_238(p231, p232) -- name: ejectPose
	-- upvalues: (ref) v_u_40, (copy) v_u_23, (copy) v_u_5
	local v233
	if v_u_40 then
		v233 = v_u_40()
	else
		v233 = nil
	end
	if type(v233) == "table" then
		local v234 = v233.pos
		if typeof(v234) == "Vector3" then
			local v235 = v233.vel
			local v236 = v_u_23.heading
			if typeof(v235) == "Vector3" and v235.X * v235.X + v235.Z * v235.Z > 9 then
				v236 = v_u_5.heading(v235.X / v235.Magnitude, v235.Z / v235.Magnitude)
			end
			local _, v237 = v_u_5.chaseStep(v_u_23, {
				["vehYaw"] = nil,
				["pivotX"] = nil,
				["pivotY"] = nil,
				["pivotZ"] = nil,
				["speed"] = 0,
				["maxSpeed"] = 60,
				["tpDist"] = 12,
				["dyaw"] = 0,
				["delev"] = 0,
				["baseFov"] = nil,
				["vehYaw"] = v236,
				["pivotX"] = v233.pos.X,
				["pivotY"] = v233.pos.Y + 2,
				["pivotZ"] = v233.pos.Z,
				["baseFov"] = p232
			}, p231)
			return v_u_5.place(v_u_23, v237.yaw, v237.elev, v237.dist)
		end
	end
	return nil
end
function v_u_16.render(p239, p240) -- name: render
	-- upvalues: (copy) v_u_5, (ref) v_u_20, (copy) v_u_172, (copy) v_u_192, (copy) v_u_230, (copy) v_u_238, (ref) v_u_21, (ref) v_u_22, (copy) v_u_45, (copy) v_u_102
	local v241 = type(p240) ~= "table" and {} or p240
	local v242 = v_u_5.num(v241.baseFov, 70, 20, 120)
	local v243 = os.clock()
	local v244 = nil
	if v_u_20 == "drive" then
		v244 = v_u_172(p239, v242)
	elseif v_u_20 == "lean" then
		v244 = v_u_192(p239, v242)
	elseif v_u_20 == "board" or v_u_20 == "unboard" then
		v244 = v_u_230(p239, v242)
	elseif v_u_20 == "eject" then
		v244 = v_u_238(p239, v242)
	elseif v_u_20 == "none" and v_u_21 ~= nil then
		local v245 = v241.natural
		if type(v245) == "table" then
			local v246 = v241.natural.cf
			if typeof(v246) == "CFrame" then
				local v247 = v241.natural.cf
				local v248 = v_u_5.num(v241.natural.fov, v242, 20, 120)
				local v249 = v247.Position
				local v250 = v249 + v247.LookVector * 20
				v244 = {
					["camX"] = v249.X,
					["camY"] = v249.Y,
					["camZ"] = v249.Z,
					["tgtX"] = v250.X,
					["tgtY"] = v250.Y,
					["tgtZ"] = v250.Z,
					["fov"] = v248
				}
			end
		end
	end
	if v244 == nil then
		local v251
		if v_u_20 == "none" then
			v251 = nil
		else
			v251 = v_u_21
		end
		v_u_21 = v251
		return nil
	end
	if v_u_21 ~= nil then
		local v252 = v_u_5.blendWeight(v_u_21, v243)
		v244 = v_u_5.blend(v_u_21.from, v244, v252)
		if v252 >= 1 then
			v_u_21 = nil
		end
	end
	v_u_22 = v244
	local v253 = v_u_45
	v253.frames = v253.frames + 1
	local v254, v255 = v_u_102(v244)
	return v254, v244.fov, v255
end
function v_u_16.classic(p256) -- name: classic
	-- upvalues: (ref) v_u_19, (ref) v_u_40, (copy) v_u_17, (ref) v_u_27, (copy) v_u_5, (copy) v_u_26, (copy) v_u_4, (ref) v_u_28, (copy) v_u_45
	local v257 = v_u_19
	local v258 = 1
	local v259 = 0
	local v260 = 0
	if v257 ~= nil and v257.kind == "eject" then
		local v261
		if v_u_40 then
			v261 = v_u_40()
		else
			v261 = nil
		end
		local v262 = v_u_17.Character
		local v263
		if v262 == nil then
			v263 = nil
		else
			local v264 = v262:FindFirstChild("HumanoidRootPart")
			if v264 == nil or not v264:IsA("BasePart") then
				v263 = nil
			else
				v263 = v264.Position
			end
		end
		local v265 = nil
		local v266 = nil
		if type(v261) == "table" then
			local v267 = v261.pos
			if typeof(v267) == "Vector3" then
				v265 = v261.pos.X
				v266 = v261.pos.Z
			end
		end
		v_u_27 = 0
		local v268 = v_u_5.classicEject
		local v269 = v_u_26
		local v270 = {
			["puppetX"] = v265,
			["puppetZ"] = v266
		}
		local v271
		if v263 then
			v271 = v263.X
		else
			v271 = nil
		end
		v270.rootX = v271
		local v272
		if v263 then
			v272 = v263.Z
		else
			v272 = nil
		end
		v270.rootZ = v272
		v270.blendOut = v_u_4.CAMERA.BLEND_OUT
		v270.zoomMax = v_u_4.CAMERA.ZOOM_MAX
		local v273, v274, v275 = v268(v269, v270, p256)
		v_u_28 = true
		local v276 = v_u_45
		v276.classicFrames = v276.classicFrames + 1
		return v273, v274, v275
	end
	local v277
	if v257 == nil or v257.kind ~= "ride" then
		if v257 == nil then
			v_u_27 = 0
		end
		if v257 == nil and not v_u_28 then
			return nil
		end
		v284, v285, v286, v287 = v_u_5.classicStep(v_u_26, {
			["zoom"] = v258,
			["ahead"] = v259,
			["vehYaw"] = v260,
			["blendIn"] = v_u_4.CAMERA.BLEND_IN,
			["blendOut"] = v_u_4.CAMERA.BLEND_OUT,
			["zoomMax"] = v_u_4.CAMERA.ZOOM_MAX
		}, p256)
		if v287 then
			v277 = v257 == nil
		else
			v277 = v287
		end
		v_u_28 = not v277
		if v287 and v257 == nil then
			return nil
		end
		v288 = v_u_45
		v288.classicFrames = v288.classicFrames + 1
		return v284, v285, v286
	end
	local v278 = v257.typeId
	if type(v278) ~= "string" then
		if v257 == nil then
			v_u_27 = 0
		end
		if v257 == nil and not v_u_28 then
			return nil
		end
		v284, v285, v286, v287 = v_u_5.classicStep(v_u_26, {
			["zoom"] = v258,
			["ahead"] = v259,
			["vehYaw"] = v260,
			["blendIn"] = v_u_4.CAMERA.BLEND_IN,
			["blendOut"] = v_u_4.CAMERA.BLEND_OUT,
			["zoomMax"] = v_u_4.CAMERA.ZOOM_MAX
		}, p256)
		if v287 then
			v277 = v257 == nil
		else
			v277 = v287
		end
		v_u_28 = not v277
		if v287 and v257 == nil then
			return nil
		end
		v288 = v_u_45
		v288.classicFrames = v288.classicFrames + 1
		return v284, v285, v286
	end
	local v279 = v_u_5.num(v257.speed, 0, -400, 400)
	local v280 = math.abs(v279)
	v258 = v_u_4.classicZoom(v257.typeId, v280, v_u_27)
	v_u_27 = v_u_4.classicStep(v257.typeId, v280, v_u_27)
	v259 = v_u_4.classicLookAhead(v257.typeId, (math.max(v279, 0)))
	local v281 = v257.model
	local v282
	if v281 == nil then
		v282 = nil
	else
		v282 = v281:FindFirstChild("Chassis")
		if v282 == nil or not v282:IsA("BasePart") then
			v282 = nil
		end
	end
	if v282 ~= nil then
		local v283 = v282.CFrame.LookVector
		v260 = v_u_5.heading(v283.X, v283.Z)
	end
	if v257 == nil and not v_u_28 then
		return nil
	end
	local v284, v285, v286, v287 = v_u_5.classicStep(v_u_26, {
		["zoom"] = v258,
		["ahead"] = v259,
		["vehYaw"] = v260,
		["blendIn"] = v_u_4.CAMERA.BLEND_IN,
		["blendOut"] = v_u_4.CAMERA.BLEND_OUT,
		["zoomMax"] = v_u_4.CAMERA.ZOOM_MAX
	}, p256)
	if v287 then
		v277 = v257 == nil
	else
		v277 = v287
	end
	v_u_28 = not v277
	if v287 and v257 == nil then
		return nil
	end
	local v288 = v_u_45
	v288.classicFrames = v288.classicFrames + 1
	return v284, v285, v286
end
function v_u_16.stats() -- name: stats
	-- upvalues: (copy) v_u_45, (ref) v_u_20, (ref) v_u_21, (ref) v_u_28
	local v289 = table.clone(v_u_45)
	v289.mode = v_u_20
	v289.blend = v_u_21 ~= nil
	v289.classicLive = v_u_28
	return v289
end
return v_u_16