-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmReviewers

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewRules"))
local v6 = {}
local v_u_7 = v1.LocalPlayer
function v6.mount(p8, p_u_9, p10, p11) -- name: mount
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3
	local v12 = type(p11) ~= "table" and {} or p11
	if type(p10) == "table" then
		local v13 = p10.color
		if type(v13) ~= "table" then
			p10 = v_u_4.Theme
		end
	else
		p10 = v_u_4.Theme
	end
	local v_u_14 = p10.color
	local v15 = v12.inner
	local v16 = type(v15) ~= "number" and 438 or v12.inner
	local v17 = v12.gui
	local v_u_18
	if v12.player == nil then
		v_u_18 = v_u_7
	else
		v_u_18 = v12.player
	end
	local v19 = 0
	local v_u_20 = true
	if v17 then
		v17.Destroying:Connect(function()
			-- upvalues: (ref) v_u_20
			v_u_20 = false
		end)
	end
	local v21 = v_u_4.label({
		["parent"] = nil,
		["text"] = "Overwatch  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p8,
		["color"] = v_u_14.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v22 = v12.order
	local v23, v24
	if type(v22) == "function" then
		v23 = v12.order()
		v24 = v19
	else
		v19 = v19 + 1
		v23 = v19
		v24 = v19
	end
	v21.LayoutOrder = v23
	local v25 = v_u_4.label({
		["parent"] = nil,
		["name"] = "ReviewNote",
		["text"] = "Approved reviewers open the OVERWATCH desk with F2 and judge the players you mark in HUSHGUARD. Type a user id or a Roblox name, then ADD or REMOVE. Accounts in the F8 list can always open the desk. A verdict never bans anybody.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p8,
		["color"] = v_u_14.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v26 = v12.order
	local v27
	if type(v26) == "function" then
		v27 = v12.order()
	else
		v19 = v24 + 1
		v27 = v19
		v24 = v19
	end
	v25.LayoutOrder = v27
	local v28 = (v16 - 6) / 2
	local v29 = math.floor(v28)
	local v30 = v_u_4.new
	local v31 = {
		["Name"] = "ReviewIdRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v32 = UDim2.new
	local v33 = p10.touch
	v31.Size = v32(1, 0, 0, type(v33) ~= "function" and 36 or p10.touch(36))
	local v34 = v30("Frame", v31, p8)
	local v35 = v12.order
	local v36
	if type(v35) == "function" then
		v36 = v12.order()
	else
		v19 = v24 + 1
		v36 = v19
		v24 = v19
	end
	v34.LayoutOrder = v36
	v_u_4.layout(v34, "h", 6)
	local v37 = v_u_4.input
	local v38 = {
		["parent"] = nil,
		["name"] = "ReviewTarget",
		["size"] = nil,
		["placeholder"] = "User id or Roblox name",
		["parent"] = v34
	}
	local v39 = UDim2.fromOffset
	local v40 = p10.touch
	v38.size = v39(v16, type(v40) ~= "function" and 36 or p10.touch(36))
	local v41, v_u_42 = v37(v38)
	v41.LayoutOrder = 1
	local v43 = v_u_4.new
	local v44 = {
		["Name"] = "ReviewButtons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v45 = UDim2.new
	local v46 = p10.touch
	v44.Size = v45(1, 0, 0, type(v46) ~= "function" and 34 or p10.touch(34))
	local v47 = v43("Frame", v44, p8)
	local v48 = v12.order
	local v49
	if type(v48) == "function" then
		v49 = v12.order()
	else
		v19 = v24 + 1
		v49 = v19
		v24 = v19
	end
	v47.LayoutOrder = v49
	v_u_4.layout(v47, "h", 6)
	local v50 = v_u_4.new
	local v51 = {
		["Name"] = "ReviewMinRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v52 = UDim2.new
	local v53 = p10.touch
	v51.Size = v52(1, 0, 0, type(v53) ~= "function" and 34 or p10.touch(34))
	local v54 = v50("Frame", v51, p8)
	local v55 = v12.order
	local v56
	if type(v55) == "function" then
		v56 = v12.order()
	else
		v19 = v24 + 1
		v56 = v19
		v24 = v19
	end
	v54.LayoutOrder = v56
	v_u_4.layout(v54, "h", 6)
	local v57 = v_u_4.input
	local v58 = {
		["parent"] = nil,
		["name"] = "ReviewMinWatch",
		["size"] = nil,
		["placeholder"] = "Minimum watch time, seconds",
		["parent"] = v54
	}
	local v59 = UDim2.fromOffset
	local v60 = p10.touch
	v58.size = v59(v29, type(v60) ~= "function" and 34 or p10.touch(34))
	local v61, v_u_62 = v57(v58)
	v61.LayoutOrder = 1
	local v_u_63 = v_u_4.label({
		["parent"] = nil,
		["name"] = "ReviewStatus",
		["text"] = "Idle.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p8,
		["color"] = v_u_14.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v64 = v12.order
	local v65
	if type(v64) == "function" then
		v65 = v12.order()
	else
		v19 = v24 + 1
		v65 = v19
		v24 = v19
	end
	v_u_63.LayoutOrder = v65
	local v66 = v_u_4.new("ScrollingFrame", {
		["Name"] = "ReviewOut",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollingDirection"] = nil,
		["BackgroundColor3"] = v_u_14.raised,
		["Size"] = UDim2.new(1, 0, 0, 150),
		["CanvasSize"] = UDim2.new(0, 0, 0, 0),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, p8)
	local v67 = v12.order
	local v68
	if type(v67) == "function" then
		v68 = v12.order()
	else
		v19 = v24 + 1
		v68 = v19
	end
	v66.LayoutOrder = v68
	local v_u_69 = v_u_4.label({
		["parent"] = nil,
		["name"] = "ReviewText",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v66,
		["color"] = v_u_14.text2,
		["size"] = UDim2.new(1, -8, 0, 0)
	})
	local v_u_70 = false
	local v_u_71 = "none"
	local v_u_72 = 0
	local v_u_73 = ""
	local function v_u_84(p74, p75, p_u_76) -- name: call
		-- upvalues: (ref) v_u_70, (copy) p_u_9, (ref) v_u_4, (copy) v_u_63, (copy) v_u_14, (copy) v_u_18, (ref) v_u_71, (ref) v_u_72, (ref) v_u_20
		if v_u_70 then
			return
		else
			local v77 = p_u_9
			if type(v77) == "function" then
				v_u_70 = true
				v_u_4.setText(v_u_63, p75)
				v_u_63.TextColor3 = v_u_14.text2
				if v_u_18 then
					v_u_18:SetAttribute("FilmReviewers", ("busy=%d|last=%s|rows=%d"):format(v_u_70 and 1 or 0, v_u_71, v_u_72))
				end
				p_u_9("review.admin", p74, function(p78)
					-- upvalues: (ref) v_u_70, (ref) v_u_20, (ref) v_u_71, (ref) v_u_4, (ref) v_u_63, (ref) v_u_14, (copy) p_u_76, (ref) v_u_18, (ref) v_u_72
					v_u_70 = false
					if v_u_20 then
						if type(p78) == "table" then
							v_u_71 = p78.ok == true and "ok" or "bad"
							local v79 = p78.msg
							local v80
							if type(v79) == "string" and p78.msg ~= "" then
								v80 = p78.msg
							else
								v80 = p78.ok == true and "Done." or "Refused or failed."
							end
							local v81 = p78.ok ~= true
							v_u_4.setText(v_u_63, v80)
							local v82 = v_u_63
							local v83
							if v81 then
								v83 = v_u_14.danger
							else
								v83 = v_u_14.text2
							end
							v82.TextColor3 = v83
							if p78.ok == true and p_u_76 then
								p_u_76(p78)
							end
						else
							v_u_71 = "bad"
							v_u_4.setText(v_u_63, "The server did not answer.")
							v_u_63.TextColor3 = v_u_14.danger
						end
						if v_u_18 then
							v_u_18:SetAttribute("FilmReviewers", ("busy=%d|last=%s|rows=%d"):format(v_u_70 and 1 or 0, v_u_71, v_u_72))
						end
					end
				end)
			else
				v_u_4.setText(v_u_63, "No connection to the server.")
				v_u_63.TextColor3 = v_u_14.danger
			end
		end
	end
	local function v_u_92(p85) -- name: showList
		-- upvalues: (ref) v_u_72, (ref) v_u_4, (copy) v_u_69, (ref) v_u_5, (ref) v_u_73, (copy) v_u_63, (copy) v_u_14, (copy) v_u_62
		local v86 = p85.data
		local v87
		if type(v86) == "table" then
			v87 = p85.data
		else
			v87 = nil
		end
		if v87 then
			local v88 = v87.rows
			if type(v88) == "table" then
				v_u_72 = #v87.rows
				v_u_4.setText(v_u_69, v_u_5.adminLines(v87))
				local v89 = (v_u_73 == "" and "" or v_u_73 .. " ") .. "List updated."
				v_u_4.setText(v_u_63, v89)
				v_u_63.TextColor3 = v_u_14.text2
				v_u_73 = ""
				if v87.minWatchSec ~= nil then
					local v90 = v_u_62
					local v91 = v87.minWatchSec
					v90.PlaceholderText = ("Minimum watch time, seconds (now %d)"):format(tonumber(v91) or 0)
				end
			end
		end
	end
	local function v_u_93()
		-- upvalues: (copy) v_u_84, (copy) v_u_92
		v_u_84({
			["action"] = "list"
		}, "Reading the reviewer list ...", v_u_92)
	end
	local function v_u_99(p94) -- name: change
		-- upvalues: (ref) v_u_5, (copy) v_u_42, (ref) v_u_4, (copy) v_u_63, (copy) v_u_14, (copy) v_u_84, (ref) v_u_73, (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
		local v95 = v_u_5.parseTarget(v_u_42.Text)
		if v95 == nil then
			v_u_4.setText(v_u_63, "Type a user id (digits) or a Roblox name (3 to 20 letters, digits, underscore).")
			v_u_63.TextColor3 = v_u_14.danger
		else
			local v96 = {
				["action"] = p94
			}
			if v95.userId then
				v96.userId = v95.userId
			else
				v96.name = v95.name
			end
			v_u_84(v96, p94 == "add" and "Approving ..." or "Removing ...", function(p97)
				-- upvalues: (ref) v_u_73, (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
				local v98 = p97.msg or ""
				v_u_73 = tostring(v98)
				task.defer(function()
					-- upvalues: (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
					if v_u_20 then
						v_u_70 = false
						v_u_93()
					end
				end)
			end)
		end
	end
	local function v_u_104() -- name: setMinWatch
		-- upvalues: (ref) v_u_5, (copy) v_u_62, (ref) v_u_4, (copy) v_u_63, (copy) v_u_14, (copy) v_u_84, (ref) v_u_73, (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
		local v100 = v_u_5.parseSeconds(v_u_62.Text)
		if v100 == nil then
			local v101 = ("Seconds from 0 to %d (0 switches the minimum off)."):format(v_u_5.MIN_WATCH_MAX)
			v_u_4.setText(v_u_63, v101)
			v_u_63.TextColor3 = v_u_14.danger
		else
			v_u_84({
				["action"] = "minwatch",
				["value"] = nil,
				["value"] = v100
			}, "Saving ...", function(p102)
				-- upvalues: (ref) v_u_73, (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
				local v103 = p102.msg or ""
				v_u_73 = tostring(v103)
				task.defer(function()
					-- upvalues: (ref) v_u_20, (ref) v_u_70, (ref) v_u_93
					if v_u_20 then
						v_u_70 = false
						v_u_93()
					end
				end)
			end)
		end
	end
	local v105 = v_u_4.button
	local v106 = {
		["parent"] = nil,
		["text"] = "Add",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v47
	}
	local v107 = p10.touch
	v106.height = type(v107) ~= "function" and 34 or p10.touch(34)
	local v108 = (v16 - 12) / 3
	v106.width = math.floor(v108)
	local v109 = (v16 - 12) / 3
	v106.maxTextWidth = math.floor(v109) - 12
	function v106.onClick() -- name: onClick
		-- upvalues: (copy) v_u_99
		v_u_99("add")
	end
	v105(v106).Name = "ReviewAdd"
	local v110 = v_u_4.button
	local v111 = {
		["parent"] = nil,
		["text"] = "Remove",
		["kind"] = "danger",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v47
	}
	local v112 = p10.touch
	v111.height = type(v112) ~= "function" and 34 or p10.touch(34)
	local v113 = (v16 - 12) / 3
	v111.width = math.floor(v113)
	local v114 = (v16 - 12) / 3
	v111.maxTextWidth = math.floor(v114) - 12
	function v111.onClick() -- name: onClick
		-- upvalues: (copy) v_u_99
		v_u_99("remove")
	end
	v110(v111).Name = "ReviewRemove"
	local v115 = v_u_4.button
	local v116 = {
		["parent"] = nil,
		["text"] = "Reload",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v47
	}
	local v117 = p10.touch
	v116.height = type(v117) ~= "function" and 34 or p10.touch(34)
	local v118 = (v16 - 12) / 3
	v116.width = math.floor(v118)
	local v119 = (v16 - 12) / 3
	v116.maxTextWidth = math.floor(v119) - 12
	v116.onClick = v_u_93
	v115(v116).Name = "ReviewReload"
	local v120 = v_u_4.button
	local v121 = {
		["parent"] = nil,
		["text"] = "Set",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v54
	}
	local v122 = p10.touch
	v121.height = type(v122) ~= "function" and 34 or p10.touch(34)
	v121.width = v29
	v121.maxTextWidth = v29 - 12
	v121.onClick = v_u_104
	v120(v121).Name = "ReviewSetMin"
	if v_u_3:IsStudio() and v_u_18 then
		local v_u_126 = v_u_18:GetAttributeChangedSignal("FilmReviewersCmd"):Connect(function()
			-- upvalues: (copy) v_u_18, (copy) v_u_42, (copy) v_u_99, (ref) v_u_93, (copy) v_u_62, (copy) v_u_104
			local v123 = v_u_18:GetAttribute("FilmReviewersCmd")
			if type(v123) == "string" and v123 ~= "" then
				v_u_18:SetAttribute("FilmReviewersCmd", nil)
				local v124, v125 = string.match(v123, "^(%a+)%s*(.-)$")
				if v124 == "target" then
					v_u_42.Text = v125
					return
				elseif v124 == "add" then
					v_u_99("add")
					return
				elseif v124 == "remove" then
					v_u_99("remove")
					return
				elseif v124 == "reload" then
					v_u_93()
				elseif v124 == "minwatch" then
					v_u_62.Text = v125
					v_u_104()
				end
			else
				return
			end
		end)
		if v17 then
			v17.Destroying:Connect(function()
				-- upvalues: (copy) v_u_126
				v_u_126:Disconnect()
			end)
		end
	end
	if v_u_18 then
		v_u_18:SetAttribute("FilmReviewers", ("busy=%d|last=%s|rows=%d"):format(v_u_70 and 1 or 0, v_u_71, v_u_72))
	end
	task.defer(v_u_93)
	return {
		["add"] = function() -- name: add
			-- upvalues: (copy) v_u_99
			v_u_99("add")
		end,
		["remove"] = function() -- name: remove
			-- upvalues: (copy) v_u_99
			v_u_99("remove")
		end,
		["reload"] = v_u_93,
		["setMinWatch"] = v_u_104,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_20
			return v_u_20
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_70, (ref) v_u_71, (ref) v_u_72
			return {
				["busy"] = v_u_70,
				["last"] = v_u_71,
				["rows"] = v_u_72
			}
		end
	}
end
return v6