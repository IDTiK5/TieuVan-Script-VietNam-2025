-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSkinsGrid

local v_u_1 = {}
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v_u_3:WaitForChild("Skins"))
local v_u_5 = require(v_u_3:WaitForChild("WearSkins"))
local v_u_6 = require(script.Parent:WaitForChild("MenuCratesSkins"))
v_u_1.TEXT = {
	["title"] = "SKINS",
	["owned"] = "OWNED",
	["all"] = "ALL",
	["back"] = "BACK",
	["close"] = "CLOSE",
	["factory"] = "Factory finish",
	["empty"] = "You have no skins yet. Open cases to find some. Head, vest and outfit skins drop from special cases.",
	["emptyWeapon"] = "No finishes for this weapon.",
	["pickHint"] = "Pick a skin to see your copies and a live preview.",
	["copiesHead"] = "YOUR COPIES",
	["notOwned"] = "You do not have this skin yet.",
	["takeOff"] = "TAKE OFF",
	["equip"] = "EQUIP",
	["equipped"] = "EQUIPPED",
	["worn"] = "ON",
	["locked"] = "LOCKED",
	["loading"] = "Loading your skins...",
	["failed"] = "Your skins could not be loaded. Try again in a moment.",
	["again"] = "TRY AGAIN",
	["noRegister"] = "You own %d of this skin.",
	["groupEmpty"] = nil,
	["groupEmpty"] = {
		["head"] = "No head skins yet. They come from special cases.",
		["vest"] = "No vest skins yet. They come from special cases.",
		["outfit"] = "No outfit yet. A full outfit is a very rare find."
	}
}
v_u_1.GROUPS = {
	{
		["id"] = "weapons",
		["title"] = "WEAPONS"
	},
	{
		["id"] = "knives",
		["title"] = "KNIVES"
	},
	{
		["id"] = "head",
		["title"] = "HEAD"
	},
	{
		["id"] = "vest",
		["title"] = "VEST"
	},
	{
		["id"] = "outfit",
		["title"] = "OUTFIT"
	}
}
v_u_1.WEAR_BLURB = {
	["head"] = "A head skin. It takes the place of the look of your helmet, on you and for everyone in a raid.",
	["vest"] = "A vest skin. It recolours the vest you wear and adds its own parts. You need to wear a vest.",
	["outfit"] = "A full outfit with head, vest and cape in one piece. It replaces the look of your helmet and vest."
}
local v_u_7 = v_u_6.RARITY_WORD
function v_u_1.groupOf(p8) -- name: groupOf
	-- upvalues: (copy) v_u_5
	if type(p8) ~= "table" then
		return "weapons"
	end
	if p8.kind == "wear" and v_u_5.SLOTS[p8.slot] ~= nil then
		return p8.slot
	end
	local v9 = p8.weapon
	local v10 = tostring(v9)
	return string.sub(v10, 1, 6) == "melee_" and "knives" or "weapons"
end
function v_u_1.copiesOf(p11, p12) -- name: copiesOf
	-- upvalues: (copy) v_u_6
	if type(p11) ~= "table" or type(p12) ~= "string" then
		return 0
	end
	local v13 = p11.owned
	if (type(v13) ~= "table" and {} or p11.owned)[p12] == nil then
		return 0
	end
	if p11.uid == true then
		local v14 = v_u_6.copiesCount
		return math.max(1, v14(p11, p12))
	end
	local v15 = p11.copies
	local v16
	if type(v15) == "table" then
		local v17 = p11.copies[p12]
		if type(v17) == "number" then
			local v18 = p11.copies[p12]
			local v19 = math.floor(v18)
			v16 = math.max(0, v19)
		else
			v16 = 0
		end
	else
		v16 = 0
	end
	return v16 + 1
end
function v_u_1.entries(p20, p21) -- name: entries
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6
	local v22 = type(p21) ~= "table" and {} or p21
	local v23 = type(p20) ~= "table" and {} or p20
	local v24 = v23.owned
	local v25 = type(v24) ~= "table" and {} or v23.owned
	local v26 = v23.equipped
	local v27 = type(v26) ~= "table" and {} or v23.equipped
	local v28
	if v22.all == true then
		v28 = true
	else
		local v29 = v22.weapon
		v28 = type(v29) == "string"
	end
	local v30 = {}
	if v28 then
		for _, v31 in v_u_4.LIST do
			table.insert(v30, v31)
		end
		for _, v32 in v_u_5.LIST do
			table.insert(v30, v32)
		end
	else
		for v33 in v25 do
			local v34 = v_u_4.get(v33)
			if v34 == nil then
				continue
			end
			table.insert(v30, v34)
		end
	end
	local v35 = {}
	local v36 = {
		["groups"] = nil,
		["ownedCount"] = 0,
		["shown"] = 0,
		["groups"] = {}
	}
	for _, v37 in v_u_1.GROUPS do
		local v38 = {
			["id"] = nil,
			["title"] = nil,
			["items"] = nil,
			["owned"] = 0,
			["total"] = 0,
			["id"] = v37.id,
			["title"] = v37.title,
			["items"] = {}
		}
		v35[v37.id] = v38
		local v39 = v36.groups
		table.insert(v39, v38)
	end
	for _, v40 in v30 do
		local v41 = v22.weapon
		if type(v41) == "string" and v40.weapon ~= v22.weapon then
			continue
		end
		local v42 = v25[v40.id] ~= nil
		local v43 = {
			["id"] = v40.id,
			["skin"] = v40,
			["key"] = v40.weapon,
			["owned"] = v42,
			["copies"] = v_u_1.copiesOf(v23, v40.id),
			["equipped"] = v27[v40.weapon] == v40.id
		}
		local v44
		if v42 and v40.kind ~= "wear" then
			v44 = v_u_6.tallyOf(v23, v40.id)
		else
			v44 = nil
		end
		v43.tally = v44
		v43.name = v40.name
		local v45
		if v40.kind == "wear" then
			v45 = v_u_5.SLOT_NAMES[v40.slot] or "WEAR"
		else
			v45 = v_u_4.weaponName(v40.weapon)
			if not v45 then
				local v46 = v40.weapon
				v45 = tostring(v46)
			end
		end
		v43.sub = v45
		v43.rarity = v40.rarity
		v43.group = v_u_1.groupOf(v40)
		local v47 = v35[v43.group]
		if v47 == nil then
			continue
		end
		local v48 = v47.items
		table.insert(v48, v43)
		v47.total = v47.total + 1
		v36.shown = v36.shown + 1
		if not v42 then
			continue
		end
		v47.owned = v47.owned + 1
		v36.ownedCount = v36.ownedCount + 1
	end
	for _, v49 in v36.groups do
		local v50 = v49.items
		table.sort(v50, function(p51, p52)
			if p51.owned == p52.owned then
				if p51.rarity == p52.rarity then
					local v53 = string.lower(p51.sub)
					local v54 = string.lower(p52.sub)
					if v53 == v54 then
						local v55 = string.lower(p51.name)
						local v56 = string.lower(p52.name)
						if v55 == v56 then
							return p51.id < p52.id
						else
							return v55 < v56
						end
					else
						return v53 < v54
					end
				else
					return p51.rarity > p52.rarity
				end
			else
				return p51.owned
			end
		end)
	end
	return v36
end
function v_u_1.signature(p57) -- name: signature
	local v58 = {}
	for _, v59 in p57.groups do
		for _, v60 in v59.items do
			local v61 = v60.id
			local v62 = v60.copies
			local v63 = tostring(v62)
			local v64 = not v60.tally and "" or v60.tally.best
			local v65 = v61 .. ":" .. v63 .. ":" .. tostring(v64) .. ":" .. (v60.owned and "1" or "0")
			table.insert(v58, v65)
		end
	end
	return table.concat(v58, ",")
end
function v_u_1.countLine(p66, p67) -- name: countLine
	if p67 then
		return ("%d of %d owned"):format(p66.ownedCount, p66.shown)
	else
		return ("%d %s"):format(p66.ownedCount, p66.ownedCount == 1 and "skin" or "skins")
	end
end
function v_u_1.blurbOf(p68) -- name: blurbOf
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	if type(p68) ~= "table" then
		return ""
	end
	if p68.kind == "wear" then
		return v_u_1.WEAR_BLURB[p68.slot] or ""
	end
	local function v69()
		-- upvalues: (ref) v_u_3
		return require(v_u_3:WaitForChild("SkinFinishes"))
	end
	local v70, v71 = pcall(v69)
	local v72
	if v70 then
		v72 = v71.get(p68.finish)
	else
		v72 = nil
	end
	if v72 then
		local v73 = v72.blurb
		if type(v73) == "string" then
			return v72.blurb
		end
	end
	return ""
end
function v_u_1.wearNote(p74, p75) -- name: wearNote
	-- upvalues: (copy) v_u_6
	if type(p74) == "table" and p74.kind == "wear" then
		if p74.reward == "hunt" then
			return "Earned in the Hollow Hunt"
		elseif p74.reward == "store" then
			return "Only in the CRIMSON NIGHT PACK"
		elseif p74.reward == "season" then
			return v_u_6.passLine(p74.id, p75)
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.panelModel(p76, p77) -- name: panelModel
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_5, (copy) v_u_4
	local v78 = type(p76) ~= "table" and {} or p76
	local v79 = v78.owned
	v78.owned = type(v79) ~= "table" and {} or v78.owned
	local v80 = v78.equipped
	v78.equipped = type(v80) ~= "table" and {} or v78.equipped
	local v81 = v_u_6.cardState(v78, p77)
	local v82 = v_u_1.copiesOf(v78, p77.id)
	local v83 = {
		["skin"] = p77,
		["owned"] = v78.owned[p77.id] ~= nil,
		["state"] = v81,
		["copies"] = v82,
		["equipped"] = v81 == "equipped"
	}
	local v84
	if p77.kind == "wear" then
		v84 = nil
	else
		v84 = v_u_6.tallyOf(v78, p77.id)
	end
	v83.tally = v84
	v83.rarityWord = v_u_7[p77.rarity] or ""
	local v85
	if p77.kind == "wear" then
		v85 = v_u_5.SLOT_NAMES[p77.slot] or "WEAR"
	else
		v85 = v_u_4.weaponName(p77.weapon)
		if not v85 then
			local v86 = p77.weapon
			v85 = tostring(v86)
		end
	end
	v83.sub = v85
	v83.blurb = v_u_1.blurbOf(p77)
	v83.previewKind = p77.kind == "wear" and "wear" or "weapon"
	local v87
	if v78.owned[p77.id] == nil then
		v87 = false
	else
		v87 = v78.uid == true
	end
	v83.hasList = v87
	if v81 == "equipped" then
		v83.primary = {
			["id"] = "unequip",
			["text"] = nil,
			["kind"] = "secondary",
			["enabled"] = true,
			["text"] = v_u_1.TEXT.takeOff
		}
	elseif v81 == "equip" then
		v83.primary = {
			["id"] = "equip",
			["text"] = nil,
			["kind"] = "primary",
			["enabled"] = true,
			["text"] = v_u_1.TEXT.equip
		}
	else
		v83.found = v_u_6.foundIn(p77)
	end
	v83.note = v_u_1.wearNote(p77)
	return v83
end
function v_u_1.layoutFor(p88, p89, p90) -- name: layoutFor
	local v91 = p90 or p88 < 900
	return {
		["stack"] = v91,
		["flow"] = p90 or p89 < 700,
		["tile"] = p90 and 84 or (p88 < 1320 and 92 or 104),
		["gap"] = p90 and 8 or 10,
		["gridFrac"] = v91 and 1 or 0.42
	}
end
function v_u_1.new(p_u_92, p93) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v_u_94 = p_u_92.ui
	local v_u_95 = p_u_92.theme
	local v_u_96 = v_u_95.color
	local v_u_97 = p93 or {}
	local v_u_98 = v_u_97.phone == true
	local v_u_99 = p_u_92.cctx
	local v_u_100 = nil
	local v_u_101 = nil
	local v_u_102 = nil
	local v_u_103 = nil
	local function v104()
		-- upvalues: (ref) v_u_100, (copy) v_u_99
		v_u_100 = v_u_99.lib.TallyMark
	end
	pcall(v104)
	local function v105()
		-- upvalues: (ref) v_u_101, (copy) v_u_99
		v_u_101 = v_u_99.lib.SkinPreview
	end
	pcall(v105)
	local function v106()
		-- upvalues: (ref) v_u_102, (copy) v_u_99
		v_u_102 = v_u_99.lib.SkinTile
	end
	pcall(v106)
	local function v107()
		-- upvalues: (ref) v_u_103, (copy) v_u_99
		v_u_103 = v_u_99.lib.MenuCratesCopies
	end
	pcall(v107)
	local v_u_108 = {}
	local v_u_109 = v_u_94.new("Frame", {
		["Name"] = "SkinsGrid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v_u_108.frame = v_u_109
	local v_u_110 = true
	local v_u_111 = false
	local v_u_112 = nil
	local v_u_113 = false
	local v_u_114 = 0
	local v_u_115 = 0
	local v_u_116 = false
	local v_u_117 = nil
	local v_u_118 = nil
	local v_u_119 = v_u_1.layoutFor(v_u_95.refSize().X, v_u_95.refSize().Y, v_u_98)
	local v_u_120 = {}
	local v_u_121 = {}
	local v_u_122 = ""
	local v_u_123 = nil
	local v_u_124 = nil
	local v_u_125 = 0
	local v_u_126 = {}
	local v_u_127 = ""
	local v_u_128 = {}
	local v129 = v_u_95.touch(34)
	local v130 = v_u_94.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v129)
	}, v_u_109)
	v_u_94.label({
		["parent"] = nil,
		["text"] = nil,
		["style"] = "h2",
		["size"] = nil,
		["name"] = "Title",
		["parent"] = v130,
		["text"] = v_u_1.TEXT.title,
		["size"] = UDim2.new(0, 96, 1, 0)
	})
	local v_u_131 = v_u_94.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v130,
		["color"] = v_u_96.text2,
		["position"] = UDim2.fromOffset(104, 0),
		["size"] = UDim2.new(0, 150, 1, 0)
	})
	local v_u_132 = v_u_94.new("Frame", {
		["Name"] = "Chips",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_98 and 224 or 256, 0),
		["Size"] = UDim2.new(1, -(v_u_98 and 224 or 256), 1, 0)
	}, v130)
	v_u_94.layout(v_u_132, "h", 8).VerticalAlignment = Enum.VerticalAlignment.Center
	local v133 = v_u_94.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v129 + 8),
		["Size"] = UDim2.new(1, 0, 1, -(v129 + 8))
	}, v_u_109)
	local v_u_134 = v_u_94.new("Frame", {
		["Name"] = "GridCol",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.45,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_96.bg,
		["Size"] = UDim2.fromScale(1, 1)
	}, v133)
	v_u_94.stroke(v_u_134, v_u_96.line)
	local v_u_135 = v_u_94.list({
		["parent"] = nil,
		["name"] = "Grid",
		["size"] = nil,
		["gap"] = 10,
		["padding"] = nil,
		["parent"] = v_u_134,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			10,
			14,
			8,
			12
		}
	})
	local v_u_136 = v_u_94.new("Frame", {
		["Name"] = "PanelHost",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(0.58, -6, 1, 0)
	}, v133)
	local function v_u_142(p137) -- name: swatchOf
		-- upvalues: (ref) v_u_3, (copy) v_u_96
		local v138 = p137.swatch
		if v138 == nil then
			local function v139()
				-- upvalues: (ref) v_u_3
				return require(v_u_3:WaitForChild("SkinFinishes"))
			end
			local v140, v141 = pcall(v139)
			if v140 then
				v138 = v141.get(p137.finish)
			else
				v138 = nil
			end
			if v138 then
				v138 = v138.swatch
			end
		end
		return type(v138) == "table" and (v138[1] and v138[2]) and { Color3.fromRGB(v138[1][1], v138[1][2], v138[1][3]), Color3.fromRGB(v138[2][1], v138[2][2], v138[2][3]) } or { v_u_96.raised2, v_u_96.raised }
	end
	local function v_u_147() -- name: closePanel
		-- upvalues: (ref) v_u_118, (ref) v_u_125, (ref) v_u_124, (ref) v_u_123, (ref) v_u_136, (ref) v_u_134, (copy) v_u_120
		v_u_118 = nil
		v_u_125 = v_u_125 + 1
		if v_u_124 then
			local v143 = v_u_124.close
			pcall(v143)
			v_u_124 = nil
		end
		if v_u_123 then
			local v144 = v_u_123.destroy
			pcall(v144)
			v_u_123 = nil
		end
		for _, v145 in v_u_136:GetChildren() do
			v145:Destroy()
		end
		v_u_136.Visible = false
		v_u_134.Visible = true
		v_u_134.Size = UDim2.fromScale(1, 1)
		for _, v146 in v_u_120 do
			if not v146.stroke then
				continue
			end
			v146.stroke.Color = v146.rim
			v146.stroke.Thickness = 2
		end
	end
	local function v_u_159() -- name: sigOfPanel
		-- upvalues: (ref) v_u_118, (ref) v_u_4, (ref) v_u_112, (ref) v_u_1
		local v148
		if v_u_118 then
			v148 = v_u_4.get(v_u_118)
		else
			v148 = nil
		end
		if v148 == nil or v_u_112 == nil then
			return ""
		end
		local v149 = v_u_1.panelModel(v_u_112, v148)
		local v150 = "%s|%s|%d|%s|%s|%s"
		local v151 = v148.id
		local v152 = v149.state
		local v153 = v149.copies
		local v154 = v149.tally
		if v154 then
			v154 = v149.tally.best
		end
		local v155 = tostring(v154)
		local v156 = v149.hasList
		local v157 = tostring(v156)
		local v158 = v149.primary
		if v158 then
			v158 = v149.primary.enabled
		end
		return v150:format(v151, v152, v153, v155, v157, (tostring(v158)))
	end
	local function v_u_230() -- name: drawPanel
		-- upvalues: (ref) v_u_127, (copy) v_u_159, (copy) v_u_128, (ref) v_u_125, (ref) v_u_124, (ref) v_u_123, (ref) v_u_136, (ref) v_u_118, (ref) v_u_4, (ref) v_u_112, (copy) v_u_119, (ref) v_u_134, (ref) v_u_1, (copy) v_u_95, (copy) v_u_94, (copy) v_u_96, (ref) v_u_100, (copy) v_u_147, (copy) v_u_97, (copy) p_u_92, (copy) v_u_108, (copy) v_u_98, (ref) v_u_101, (ref) v_u_103, (ref) v_u_110, (ref) v_u_114, (ref) v_u_113, (ref) v_u_111, (copy) v_u_109, (copy) v_u_120
		v_u_127 = v_u_159()
		table.clear(v_u_128)
		v_u_125 = v_u_125 + 1
		if v_u_124 then
			local v160 = v_u_124.close
			pcall(v160)
			v_u_124 = nil
		end
		if v_u_123 then
			local v161 = v_u_123.destroy
			pcall(v161)
			v_u_123 = nil
		end
		for _, v162 in v_u_136:GetChildren() do
			v162:Destroy()
		end
		local v_u_163
		if v_u_118 then
			v_u_163 = v_u_4.get(v_u_118)
		else
			v_u_163 = nil
		end
		if v_u_163 == nil or v_u_112 == nil then
			v_u_136.Visible = false
		else
			v_u_136.Visible = true
			if v_u_119.stack then
				v_u_134.Visible = false
				v_u_136.Size = UDim2.fromScale(1, 1)
			else
				v_u_134.Visible = true
				v_u_134.Size = UDim2.new(v_u_119.gridFrac, -6, 1, 0)
				v_u_136.Size = UDim2.new(1 - v_u_119.gridFrac, -6, 1, 0)
			end
			local v_u_164 = v_u_1.panelModel(v_u_112, v_u_163)
			local v165 = v_u_95.rarityColor(v_u_163.rarity)
			local v166 = v_u_94.new("Frame", {
				["Name"] = "Panel",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_96.raised,
				["Size"] = UDim2.fromScale(1, 1)
			}, v_u_136)
			v_u_94.stroke(v166, v_u_96.line)
			v_u_94.new("Frame", {
				["Name"] = "Rarity",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v165,
				["Size"] = UDim2.new(0, 4, 1, 0)
			}, v166)
			local v167
			if v_u_119.flow then
				v167 = v_u_94.list({
					["parent"] = nil,
					["name"] = "PanelScroll",
					["size"] = nil,
					["position"] = nil,
					["gap"] = 8,
					["padding"] = nil,
					["parent"] = v166,
					["size"] = UDim2.new(1, -4, 1, 0),
					["position"] = UDim2.fromOffset(4, 0),
					["padding"] = {
						10,
						14,
						8,
						10
					}
				})
			else
				v167 = v_u_94.new("Frame", {
					["Name"] = "PanelInner",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(4, 0),
					["Size"] = UDim2.new(1, -4, 1, 0)
				}, v166)
				v_u_94.pad(v167, {
					12,
					12,
					10,
					10
				})
			end
			local v168 = v_u_95.touch(40)
			local v169 = v_u_95.touch(34)
			local v170 = v169 + 18 + (v_u_164.note and 16 or 0) + (v_u_164.tally and v_u_100 and 18 or 0) + 38 + (not (v_u_164.primary or v_u_164.found) and 0 or v168) + 24
			local v171 = v_u_94.new
			local v172 = "Frame"
			local v173 = {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 1
			}
			local v174
			if v_u_119.flow then
				v174 = UDim2.new(1, 0, 0, 0)
			else
				v174 = UDim2.new(1, 0, 0, v170)
			end
			v173.Size = v174
			local v175
			if v_u_119.flow then
				v175 = Enum.AutomaticSize.Y
			else
				v175 = Enum.AutomaticSize.None
			end
			v173.AutomaticSize = v175
			local v176 = v171(v172, v173, v167)
			v_u_94.layout(v176, "v", 4)
			local v177 = v_u_94.new("Frame", {
				["Name"] = "Top",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, v169)
			}, v176)
			v_u_94.label({
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "h3",
				["size"] = nil,
				["fit"] = true,
				["parent"] = v177,
				["text"] = v_u_163.name,
				["size"] = UDim2.new(1, -(v_u_119.stack and 110 or 100), 1, 0)
			})
			local v178 = v_u_94.button
			local v179 = {
				["parent"] = nil,
				["name"] = "ClosePanel",
				["text"] = nil,
				["kind"] = "secondary",
				["width"] = nil,
				["height"] = 30,
				["anchor"] = nil,
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v177
			}
			local v180
			if v_u_119.stack then
				v180 = v_u_1.TEXT.back
			else
				v180 = v_u_1.TEXT.close
			end
			v179.text = v180
			v179.width = v_u_119.stack and 100 or 90
			v179.anchor = Vector2.new(1, 0)
			v179.position = UDim2.new(1, 0, 0, 0)
			v179.onClick = v_u_147
			v178(v179)
			local v181 = ("%s   %s"):format(v_u_164.sub, v_u_164.rarityWord)
			v_u_94.label({
				["parent"] = nil,
				["name"] = "Meta",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["size"] = nil,
				["order"] = 2,
				["track"] = false,
				["parent"] = v176,
				["text"] = v181,
				["color"] = v165,
				["size"] = UDim2.new(1, 0, 0, 18)
			})
			if v_u_164.note then
				v_u_94.label({
					["parent"] = nil,
					["name"] = "Note",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["order"] = 3,
					["parent"] = v176,
					["text"] = v_u_164.note,
					["color"] = v_u_96.accent,
					["size"] = UDim2.new(1, 0, 0, 16)
				})
			end
			if v_u_164.tally and v_u_100 then
				local v182 = v_u_100.colorOf(v_u_164.tally.level, v_u_95)
				v_u_94.label({
					["parent"] = nil,
					["name"] = "TallyLine",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["order"] = 4,
					["track"] = false,
					["parent"] = v176,
					["text"] = v_u_164.tally.text,
					["color"] = v182,
					["size"] = UDim2.new(1, 0, 0, 18)
				})
			end
			if v_u_119.flow then
				v_u_94.label({
					["parent"] = nil,
					["name"] = "Blurb",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 5,
					["parent"] = v176,
					["text"] = v_u_164.blurb,
					["color"] = v_u_96.text2
				})
			else
				v_u_94.label({
					["parent"] = nil,
					["name"] = "Blurb",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["size"] = nil,
					["valign"] = "top",
					["order"] = 5,
					["parent"] = v176,
					["text"] = v_u_164.blurb,
					["color"] = v_u_96.text2,
					["size"] = UDim2.new(1, 0, 0, 38)
				})
			end
			if v_u_164.primary or v_u_164.found then
				local v183 = v_u_94.new("Frame", {
					["Name"] = "Actions",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 6,
					["Size"] = UDim2.new(1, 0, 0, v168)
				}, v176)
				v_u_94.layout(v183, "h", 10).VerticalAlignment = Enum.VerticalAlignment.Center
				if v_u_164.primary then
					local function v194() -- name: doPrimary
						-- upvalues: (copy) v_u_164, (ref) v_u_112, (copy) v_u_163, (ref) v_u_97, (ref) p_u_92, (ref) v_u_108
						if v_u_164.primary.id == "equip" then
							if v_u_112 then
								v_u_112.equipped[v_u_163.weapon] = v_u_163.id
							end
							local v184 = {
								["op"] = "skinEquip",
								["weapon"] = nil,
								["skin"] = nil,
								["weapon"] = v_u_163.weapon,
								["skin"] = v_u_163.id
							}
							local v185 = v_u_97.busy
							local v186
							if type(v185) == "function" then
								local v187 = v_u_97.busy
								local v188
								v186, v188 = pcall(v187)
								if v186 then
									v186 = v188 == true
								end
							else
								v186 = false
							end
							if not v186 then
								p_u_92.op(v184)
							end
							v_u_108.repaint()
						elseif v_u_164.primary.id == "unequip" then
							if v_u_112 then
								v_u_112.equipped[v_u_163.weapon] = nil
							end
							local v189 = {
								["op"] = "skinUnequip",
								["weapon"] = nil,
								["weapon"] = v_u_163.weapon
							}
							local v190 = v_u_97.busy
							local v191
							if type(v190) == "function" then
								local v192 = v_u_97.busy
								local v193
								v191, v193 = pcall(v192)
								if v191 then
									v191 = v193 == true
								end
							else
								v191 = false
							end
							if not v191 then
								p_u_92.op(v189)
							end
							v_u_108.repaint()
						end
					end
					v_u_128.primary = v194
					local _, v195 = v_u_94.button({
						["parent"] = nil,
						["name"] = "Primary",
						["text"] = nil,
						["kind"] = nil,
						["width"] = 150,
						["height"] = nil,
						["order"] = 1,
						["onClick"] = nil,
						["parent"] = v183,
						["text"] = v_u_164.primary.text,
						["kind"] = v_u_164.primary.kind,
						["height"] = v168,
						["onClick"] = v194
					})
					v195.setEnabled(v_u_164.primary.enabled)
				end
				if v_u_164.found then
					v_u_94.label({
						["parent"] = nil,
						["name"] = "Found",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["order"] = 2,
						["fit"] = true,
						["parent"] = v183,
						["text"] = v_u_164.found,
						["color"] = v_u_96.muted,
						["size"] = UDim2.new(1, -(v_u_164.primary and 170 or 0), 1, 0)
					})
				end
			end
			local v196 = not v_u_164.hasList and v_u_164.owned
			if v196 then
				v196 = v_u_112.uid ~= true
			end
			local v197 = v_u_98 and 190 or 230
			local v198
			if v_u_119.flow then
				v198 = v_u_94.new("Frame", {
					["Name"] = "Body",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v167)
			else
				v198 = v_u_94.new("Frame", {
					["Name"] = "Body",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["Position"] = UDim2.fromOffset(0, v170 + 8),
					["Size"] = UDim2.new(1, 0, 1, -(v170 + 8))
				}, v167)
			end
			local v199
			if v_u_119.flow then
				v199 = UDim2.fromOffset(v197, v197)
			else
				v199 = UDim2.new(v196 and 0.44999999999999996 or 1, v196 and -6 or 0, 1, 0)
			end
			if v_u_119.flow and not v196 then
				v199 = UDim2.new(1, 0, 0, v197)
			end
			local v200 = v_u_94.new("Frame", {
				["Name"] = "PreviewBox",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.35,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_96.bg,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.fromScale(1, 0),
				["Size"] = v199
			}, v198)
			v_u_94.stroke(v200, v_u_96.line)
			if v_u_101 then
				local v201 = v_u_101.new
				local v202 = {
					["size"] = UDim2.new(1, -12, 1, -12),
					["position"] = UDim2.fromOffset(6, 6)
				}
				local v203, v204 = pcall(v201, v200, v202)
				if v203 then
					v_u_123 = v204
					if v_u_164.previewKind == "wear" then
						local v205 = v204.showWear
						local v206 = v_u_163.id
						pcall(v205, v206)
					else
						local v207 = v204.show
						local v208 = v_u_163.weapon
						local v209 = v_u_163.id
						pcall(v207, v208, v209)
					end
				end
			end
			if v196 then
				local v210 = v_u_94.new
				local v211 = "Frame"
				local v212 = {
					["Name"] = "CopiesCol",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil
				}
				local v213
				if v_u_119.flow then
					v213 = UDim2.new(1, -(v197 + 10), 0, 0)
				else
					v213 = UDim2.new(0.55, -6, 1, 0)
				end
				v212.Size = v213
				local v214
				if v_u_119.flow then
					v214 = Enum.AutomaticSize.Y
				else
					v214 = Enum.AutomaticSize.None
				end
				v212.AutomaticSize = v214
				local v215 = v210(v211, v212, v198)
				v_u_94.label({
					["parent"] = nil,
					["name"] = "CopiesHead",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["size"] = nil,
					["parent"] = v215,
					["text"] = ("%s  \194\183  %d"):format(v_u_1.TEXT.copiesHead, v_u_164.copies),
					["color"] = v_u_96.text2,
					["size"] = UDim2.new(1, 0, 0, 16)
				})
				if v_u_164.hasList then
					local v_u_216
					if v_u_119.flow then
						v_u_216 = v_u_94.new("Frame", {
							["Name"] = "CopyRows",
							["BackgroundTransparency"] = 1,
							["Position"] = nil,
							["Size"] = nil,
							["AutomaticSize"] = nil,
							["Position"] = UDim2.fromOffset(0, 20),
							["Size"] = UDim2.new(1, 0, 0, 0),
							["AutomaticSize"] = Enum.AutomaticSize.Y
						}, v215)
						v_u_94.layout(v_u_216, "v", 6)
					else
						v_u_216 = v_u_94.list({
							["parent"] = nil,
							["name"] = "CopyRows",
							["size"] = nil,
							["position"] = nil,
							["gap"] = 6,
							["padding"] = false,
							["parent"] = v215,
							["size"] = UDim2.new(1, 0, 1, -20),
							["position"] = UDim2.fromOffset(0, 20)
						})
					end
					if v_u_103 and v_u_103.open then
						local v_u_217 = v_u_125
						task.delay(0.12, function()
							-- upvalues: (ref) v_u_110, (copy) v_u_217, (ref) v_u_125, (ref) v_u_118, (copy) v_u_163, (ref) v_u_216, (ref) v_u_103, (ref) p_u_92, (copy) v_u_164, (ref) v_u_114, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108, (ref) v_u_124
							if v_u_110 and (v_u_217 == v_u_125 and (v_u_118 == v_u_163.id and v_u_216.Parent)) then
								local v218 = v_u_103.open
								local v219 = p_u_92
								local v223 = {
									["skin"] = nil,
									["weapon"] = nil,
									["total"] = nil,
									["embed"] = nil,
									["compact"] = true,
									["onChange"] = nil,
									["skin"] = v_u_163.id,
									["weapon"] = v_u_163.weapon,
									["total"] = v_u_164.copies,
									["embed"] = v_u_216,
									["onChange"] = function() -- name: onChange
										-- upvalues: (ref) p_u_92, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
										p_u_92.invalidate("crates")
										v_u_114 = v_u_114 + 1
										local v_u_220 = v_u_114
										local v_u_221 = 0
										task.spawn(function()
											-- upvalues: (ref) p_u_92, (copy) v_u_221, (copy) v_u_220, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
											local v222 = p_u_92.fetch("crates", nil, v_u_221 or 0)
											if v_u_220 == v_u_114 and v_u_110 then
												if type(v222) == "table" then
													v_u_112 = v222
													v_u_113 = false
												else
													v_u_113 = v_u_112 == nil
												end
												if v_u_111 and v_u_109.Parent then
													v_u_108.draw()
												end
											end
										end)
									end
								}
								local v224, v225 = pcall(v218, v219, v223)
								if v224 then
									v_u_124 = v225
								end
							end
						end)
					end
				else
					v_u_94.label({
						["parent"] = nil,
						["name"] = "NoRegister",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = v215,
						["text"] = v_u_1.TEXT.noRegister:format(v_u_164.copies),
						["color"] = v_u_96.text2,
						["position"] = UDim2.fromOffset(0, 24),
						["size"] = UDim2.new(1, 0, 0, 20)
					})
				end
			end
			for _, v226 in v_u_120 do
				if not v226.stroke then
					continue
				end
				local v227 = v226.id == v_u_118
				local v228 = v226.stroke
				local v229
				if v227 then
					v229 = v_u_96.accent
				else
					v229 = v226.rim
				end
				v228.Color = v229
				v226.stroke.Thickness = v227 and 3 or 2
			end
		end
	end
	function v_u_108.repaint() -- name: repaint
		-- upvalues: (ref) v_u_112, (copy) v_u_120, (ref) v_u_4, (ref) v_u_118, (copy) v_u_230
		if v_u_112 ~= nil then
			local v231 = v_u_112.equipped
			local v232 = type(v231) ~= "table" and {} or v_u_112.equipped
			for v233, v234 in v_u_120 do
				local v235 = v_u_4.get(v233)
				if not (v235 and v234.worn) then
					continue
				end
				v234.worn.Visible = v232[v235.weapon] == v233
			end
			if v_u_118 then
				v_u_230()
			end
		end
	end
	local function v_u_238() -- name: destroyTiles
		-- upvalues: (ref) v_u_115, (copy) v_u_121, (copy) v_u_120
		v_u_115 = v_u_115 + 1
		for _, v236 in v_u_121 do
			local v237 = v236.destroy
			pcall(v237)
		end
		table.clear(v_u_121)
		table.clear(v_u_120)
	end
	local function v_u_269(p239, p_u_240, p241) -- name: buildCard
		-- upvalues: (copy) v_u_119, (copy) v_u_94, (copy) v_u_95, (copy) v_u_96, (copy) v_u_142, (ref) v_u_102, (copy) v_u_121, (ref) v_u_100, (ref) v_u_1, (copy) v_u_108, (copy) v_u_120
		local v242 = v_u_119.tile
		local v243 = p_u_240.skin
		local v244 = v_u_94.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Name"] = "Skin_" .. p_u_240.id,
			["LayoutOrder"] = p241
		}, p239)
		local v245
		if p_u_240.owned then
			v245 = v_u_95.rarityColor(v243.rarity)
		else
			v245 = v_u_96.line
		end
		local v246 = v_u_94.new("Frame", {
			["Name"] = "TileHolder",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v242, v242)
		}, v244)
		local v247 = v_u_142(v243)
		local v248 = nil
		local v249
		if v_u_102 then
			local v250 = {
				["size"] = nil,
				["colors"] = nil,
				["line"] = nil,
				["light"] = true,
				["tex"] = false,
				["transparency"] = nil,
				["size"] = v242,
				["colors"] = v247,
				["line"] = v_u_96.line,
				["transparency"] = not p_u_240.owned and 0.55 or nil
			}
			if v243.kind == "wear" then
				v250.wearId = v243.id
			else
				v250.weaponId = v243.weapon
				v250.skinId = v243.id
				v250.tex = nil
			end
			local v251 = v_u_102.new
			local v252
			v252, v249 = pcall(v251, v246, v250)
			if v252 and (type(v249) == "table" and v249.frame) then
				local v253 = v_u_121
				table.insert(v253, v249)
			else
				v249 = v248
			end
		else
			v249 = v248
		end
		if v249 == nil then
			local v254 = v_u_94.new("Frame", {
				["Name"] = "Swatch",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v247[1],
				["BackgroundTransparency"] = p_u_240.owned and 0.08 or 0.55,
				["Size"] = UDim2.fromOffset(v242, v242)
			}, v246)
			v_u_94.new("UIGradient", {
				["Color"] = nil,
				["Rotation"] = 45,
				["Color"] = ColorSequence.new(v247[1], v247[2])
			}, v254)
		end
		local v255 = v_u_94.stroke(v246, v245, 2)
		if not p_u_240.owned then
			v_u_94.new("Frame", {
				["Name"] = "Dim",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.5,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 6,
				["Active"] = false,
				["BackgroundColor3"] = v_u_96.bg,
				["Size"] = UDim2.fromScale(1, 1)
			}, v246)
		end
		local v256 = {
			["id"] = p_u_240.id,
			["stroke"] = v255,
			["rim"] = v245,
			["card"] = v244
		}
		if p_u_240.copies >= 2 then
			local v257 = v_u_94.new("Frame", {
				["Name"] = "Copies",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["ZIndex"] = 8,
				["BackgroundColor3"] = v_u_96.bg,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -3, 0, 3),
				["Size"] = UDim2.fromOffset(0, 18),
				["AutomaticSize"] = Enum.AutomaticSize.X
			}, v246)
			v_u_94.pad(v257, {
				5,
				5,
				0,
				0
			})
			local v258 = v_u_94.label
			local v259 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["track"] = false,
				["zindex"] = 9,
				["parent"] = v257
			}
			local v260 = p_u_240.copies
			v259.text = "x" .. tostring(v260)
			v259.color = v_u_96.text
			v259.size = UDim2.fromOffset(0, 18)
			v258(v259)
		end
		if p_u_240.tally and v_u_100 then
			local v261 = v_u_100.new(v246, {
				["size"] = 16,
				["level"] = nil,
				["name"] = "TallySign",
				["level"] = p_u_240.tally.level
			})
			v261.frame.Position = UDim2.fromOffset(3, 3)
			v261.frame.ZIndex = 8
		end
		local v262 = v_u_94.new("Frame", {
			["Name"] = "Worn",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 8,
			["Visible"] = nil,
			["BackgroundColor3"] = v_u_96.accent,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 3, 1, -3),
			["Size"] = UDim2.fromOffset(0, 16),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Visible"] = p_u_240.equipped
		}, v246)
		v_u_94.pad(v262, {
			5,
			5,
			0,
			0
		})
		v_u_94.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["track"] = false,
			["zindex"] = 9,
			["parent"] = v262,
			["text"] = v_u_1.TEXT.worn,
			["color"] = v_u_96.ink,
			["size"] = UDim2.fromOffset(0, 16)
		})
		v256.worn = v262
		local v263 = v_u_94.label
		local v264 = {
			["parent"] = nil,
			["name"] = "SkinName",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v244,
			["text"] = v243.name
		}
		local v265
		if p_u_240.owned then
			v265 = v_u_96.text
		else
			v265 = v_u_96.muted
		end
		v264.color = v265
		v264.position = UDim2.fromOffset(0, v242 + 3)
		v264.size = UDim2.new(1, 0, 0, 16)
		v263(v264)
		local v266 = v_u_94.label
		local v267 = {
			["parent"] = nil,
			["name"] = "SkinSub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v244,
			["text"] = p_u_240.sub
		}
		local v268
		if p_u_240.owned then
			v268 = v_u_95.rarityColor(v243.rarity)
		else
			v268 = v_u_96.muted
		end
		v267.color = v268
		v267.position = UDim2.fromOffset(0, v242 + 19)
		v267.size = UDim2.new(1, 0, 0, 14)
		v266(v267)
		v244.Activated:Connect(function()
			-- upvalues: (ref) v_u_94, (ref) v_u_95, (ref) v_u_108, (copy) p_u_240
			v_u_94.sound(v_u_95.sounds.click)
			v_u_108.select(p_u_240.id)
		end)
		v_u_120[p_u_240.id] = v256
		return v244
	end
	local function v_u_297(p270) -- name: buildGrid
		-- upvalues: (copy) v_u_238, (ref) v_u_115, (ref) v_u_135, (copy) v_u_126, (copy) v_u_119, (ref) v_u_116, (ref) v_u_117, (ref) v_u_1, (copy) v_u_94, (copy) v_u_96, (ref) v_u_110, (copy) v_u_269, (ref) v_u_2, (ref) v_u_118, (copy) v_u_120
		v_u_238()
		local v_u_271 = v_u_115
		for _, v272 in v_u_135:GetChildren() do
			if v272:IsA("UIListLayout") or v272:IsA("UIPadding") then
				continue
			end
			v272:Destroy()
		end
		table.clear(v_u_126)
		local v_u_273 = {}
		local v274 = 0
		local v275 = v_u_119.tile + 36
		local v276 = v274
		local v277 = 0
		for _, v278 in p270.groups do
			v277 = v277 + #v278.items
		end
		for _, v279 in p270.groups do
			v_u_126[v279.id] = v279.owned
			if #v279.items <= 0 and (v_u_116 or (v_u_117 ~= nil or v_u_1.TEXT.groupEmpty[v279.id] == nil)) then
				continue
			end
			local v280 = v_u_94.new
			local v281 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Group_" .. v279.id,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}
			v274 = v276 + 1
			v281.LayoutOrder = v274
			local v282 = v280("Frame", v281, v_u_135)
			v_u_94.layout(v282, "v", 6)
			local v283
			if v_u_116 or v_u_117 then
				v283 = ("%s  %d / %d"):format(v279.title, v279.owned, #v279.items)
			else
				v283 = ("%s  %d"):format(v279.title, #v279.items)
			end
			v_u_94.label({
				["parent"] = nil,
				["name"] = "GroupTitle",
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["size"] = nil,
				["order"] = 1,
				["parent"] = v282,
				["text"] = v283,
				["color"] = v_u_96.accent,
				["size"] = UDim2.new(1, 0, 0, 18)
			})
			if #v279.items == 0 then
				v_u_94.label({
					["parent"] = nil,
					["name"] = "GroupEmpty",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["order"] = 2,
					["parent"] = v282,
					["text"] = v_u_1.TEXT.groupEmpty[v279.id],
					["color"] = v_u_96.muted,
					["size"] = UDim2.new(1, 0, 0, 18)
				})
				v276 = v274
			else
				local v284 = v_u_94.new("Frame", {
					["Name"] = "Cells",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v282)
				local v285 = Instance.new("UIGridLayout")
				v285.CellSize = UDim2.fromOffset(v_u_119.tile, v275)
				v285.CellPadding = UDim2.fromOffset(v_u_119.gap, 6)
				v285.SortOrder = Enum.SortOrder.LayoutOrder
				v285.Parent = v284
				v276 = v274
				for v286, v287 in v279.items do
					table.insert(v_u_273, {
						["grid"] = v284,
						["e"] = v287,
						["order"] = v286
					})
				end
			end
		end
		if v277 == 0 then
			local v288 = v_u_94.label
			local v289 = {
				["parent"] = nil,
				["name"] = "Empty",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v_u_135
			}
			local v290
			if v_u_117 then
				v290 = v_u_1.TEXT.emptyWeapon
			else
				v290 = v_u_1.TEXT.empty
			end
			v289.text = v290
			v289.color = v_u_96.muted
			v274 = v276 + 1
			v289.order = v274
			v288(v289)
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_273, (ref) v_u_110, (copy) v_u_271, (ref) v_u_115, (ref) v_u_269, (ref) v_u_2, (ref) v_u_118, (ref) v_u_120, (ref) v_u_96
			local v291 = 0
			for _, v292 in v_u_273 do
				if not v_u_110 or (v_u_271 ~= v_u_115 or not v292.grid.Parent) then
					return
				end
				v_u_269(v292.grid, v292.e, v292.order)
				v291 = v291 + 1
				if v291 % 6 ~= 0 then
					continue
				end
				v_u_2.Heartbeat:Wait()
			end
			if v_u_110 and (v_u_271 == v_u_115 and v_u_118) then
				for v293, v294 in v_u_120 do
					if not v294.stroke then
						continue
					end
					local v295 = v294.stroke
					local v296
					if v293 == v_u_118 then
						v296 = v_u_96.accent
					else
						v296 = v294.rim
					end
					v295.Color = v296
					v294.stroke.Thickness = v293 == v_u_118 and 3 or 2
				end
			end
		end)
	end
	local function v_u_300(p298) -- name: paintHead
		-- upvalues: (ref) v_u_131, (ref) v_u_1, (ref) v_u_116, (ref) v_u_117, (copy) v_u_132, (copy) v_u_94, (ref) v_u_4, (copy) v_u_108
		v_u_131.Text = v_u_1.countLine(p298, v_u_116 or v_u_117 ~= nil)
		for _, v299 in v_u_132:GetChildren() do
			if v299:IsA("UIListLayout") then
				continue
			end
			v299:Destroy()
		end
		if v_u_117 == nil then
			local _, _ = v_u_94.button({
				["parent"] = nil,
				["name"] = "ShowOwned",
				["text"] = nil,
				["kind"] = nil,
				["height"] = 30,
				["width"] = 124,
				["order"] = 1,
				["onClick"] = nil,
				["parent"] = v_u_132,
				["text"] = v_u_1.TEXT.owned,
				["kind"] = v_u_116 and "secondary" or "primary",
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_116, (ref) v_u_108
					if v_u_116 then
						v_u_116 = false
						v_u_108.draw()
					end
				end
			})
			local _, _ = v_u_94.button({
				["parent"] = nil,
				["name"] = "ShowAll",
				["text"] = nil,
				["kind"] = nil,
				["height"] = 30,
				["width"] = 96,
				["order"] = 2,
				["onClick"] = nil,
				["parent"] = v_u_132,
				["text"] = v_u_1.TEXT.all,
				["kind"] = v_u_116 and "primary" or "secondary",
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_116, (ref) v_u_108
					if not v_u_116 then
						v_u_116 = true
						v_u_108.draw()
					end
				end
			})
		else
			v_u_94.button({
				["parent"] = nil,
				["name"] = "FilterChip",
				["text"] = nil,
				["kind"] = "primary",
				["height"] = 30,
				["width"] = 150,
				["order"] = 1,
				["onClick"] = nil,
				["parent"] = v_u_132,
				["text"] = (v_u_4.weaponName(v_u_117) or v_u_117) .. "  X",
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_108
					v_u_108.focusWeapon(nil)
				end
			})
		end
	end
	function v_u_108.draw() -- name: draw
		-- upvalues: (ref) v_u_110, (ref) v_u_112, (copy) v_u_238, (ref) v_u_135, (ref) v_u_131, (ref) v_u_113, (copy) v_u_94, (ref) v_u_1, (copy) v_u_96, (copy) v_u_95, (ref) v_u_114, (copy) p_u_92, (ref) v_u_111, (copy) v_u_109, (copy) v_u_108, (ref) v_u_116, (ref) v_u_117, (copy) v_u_300, (copy) v_u_119, (ref) v_u_122, (copy) v_u_120, (copy) v_u_297, (ref) v_u_4, (ref) v_u_118, (copy) v_u_147, (copy) v_u_159, (ref) v_u_127, (ref) v_u_136, (copy) v_u_230
		if v_u_110 then
			if v_u_112 == nil then
				v_u_238()
				for _, v301 in v_u_135:GetChildren() do
					if v301:IsA("UIListLayout") or v301:IsA("UIPadding") then
						continue
					end
					v301:Destroy()
				end
				v_u_131.Text = ""
				if v_u_113 then
					v_u_94.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = v_u_135,
						["text"] = v_u_1.TEXT.failed,
						["color"] = v_u_96.text2
					})
					v_u_94.button({
						["parent"] = nil,
						["text"] = nil,
						["kind"] = "secondary",
						["width"] = 160,
						["height"] = nil,
						["onClick"] = nil,
						["parent"] = v_u_135,
						["text"] = v_u_1.TEXT.again,
						["height"] = v_u_95.touch(40),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_113, (ref) v_u_114, (ref) p_u_92, (ref) v_u_110, (ref) v_u_112, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
							v_u_113 = false
							v_u_114 = v_u_114 + 1
							local v_u_302 = v_u_114
							local v_u_303 = 0
							task.spawn(function()
								-- upvalues: (ref) p_u_92, (copy) v_u_303, (copy) v_u_302, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
								local v304 = p_u_92.fetch("crates", nil, v_u_303 or 0)
								if v_u_302 == v_u_114 and v_u_110 then
									if type(v304) == "table" then
										v_u_112 = v304
										v_u_113 = false
									else
										v_u_113 = v_u_112 == nil
									end
									if v_u_111 and v_u_109.Parent then
										v_u_108.draw()
									end
								end
							end)
							v_u_108.draw()
						end
					})
				else
					v_u_94.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["parent"] = v_u_135,
						["text"] = v_u_1.TEXT.loading,
						["color"] = v_u_96.muted
					})
				end
			else
				local v305 = v_u_112
				local v306 = v_u_112.owned
				v305.owned = type(v306) ~= "table" and {} or v_u_112.owned
				local v307 = v_u_112
				local v308 = v_u_112.copies
				v307.copies = type(v308) ~= "table" and {} or v_u_112.copies
				local v309 = v_u_112
				local v310 = v_u_112.equipped
				v309.equipped = type(v310) ~= "table" and {} or v_u_112.equipped
				local v311 = {
					["all"] = v_u_116,
					["weapon"] = v_u_117
				}
				local v312 = v_u_1.entries(v_u_112, v311)
				v_u_300(v312)
				local v313 = v_u_1.signature(v312)
				local v314 = v_u_116
				local v315 = tostring(v314)
				local v316 = v_u_117
				local v317 = tostring(v316)
				local v318 = v_u_119.tile
				local v319 = v313 .. "|" .. v315 .. "|" .. v317 .. "|" .. tostring(v318)
				if v319 == v_u_122 and next(v_u_120) ~= nil then
					for v320, v321 in v_u_120 do
						local v322 = v_u_4.get(v320)
						if not (v322 and v321.worn) then
							continue
						end
						v321.worn.Visible = v_u_112.equipped[v322.weapon] == v320
					end
				else
					v_u_122 = v319
					v_u_297(v312)
				end
				if v_u_118 then
					if v_u_4.get(v_u_118) == nil or v_u_112.owned[v_u_118] == nil and (not v_u_116 and v_u_117 == nil) then
						if v_u_112.owned[v_u_118] == nil and (not v_u_116 and v_u_117 == nil) then
							v_u_147()
							return
						end
					elseif v_u_159() ~= v_u_127 or not v_u_136.Visible then
						v_u_230()
					end
				end
				return
			end
		else
			return
		end
	end
	function v_u_108.select(p323) -- name: select
		-- upvalues: (copy) v_u_147, (ref) v_u_4, (ref) v_u_118, (copy) v_u_230
		if p323 == nil then
			v_u_147()
			return
		elseif v_u_4.get(p323) ~= nil then
			v_u_118 = p323
			v_u_230()
		end
	end
	function v_u_108.focusWeapon(p324) -- name: focusWeapon
		-- upvalues: (ref) v_u_117, (ref) v_u_116, (ref) v_u_122, (copy) v_u_147, (copy) v_u_108, (ref) v_u_112, (ref) v_u_4
		if type(p324) ~= "string" or p324 == "" then
			p324 = nil
		end
		v_u_117 = p324
		if v_u_117 ~= nil then
			v_u_116 = false
		end
		v_u_122 = ""
		v_u_147()
		v_u_108.draw()
		if v_u_117 ~= nil and v_u_112 ~= nil then
			local v325 = v_u_112.equipped
			local v326
			if type(v325) == "table" then
				v326 = v_u_112.equipped[v_u_117]
			else
				v326 = nil
			end
			if v326 == nil then
				for _, v327 in v_u_4.byWeapon(v_u_117) do
					if not (v_u_112.owned and v_u_112.owned[v327.id]) then
						continue
					end
					v326 = v327.id
				end
			end
			if v326 ~= nil then
				v_u_108.select(v326)
			end
		end
	end
	function v_u_108.setAll(p328) -- name: setAll
		-- upvalues: (ref) v_u_116, (ref) v_u_117, (ref) v_u_122, (copy) v_u_108
		v_u_116 = p328 == true
		if v_u_116 then
			v_u_117 = nil
		end
		v_u_122 = ""
		v_u_108.draw()
	end
	function v_u_108.press(p329) -- name: press
		-- upvalues: (copy) v_u_128, (copy) v_u_147
		local v330
		if p329 == "primary" then
			v330 = v_u_128.primary
		elseif p329 == "close" or p329 == "back" then
			v330 = v_u_147
		else
			v330 = nil
		end
		if v330 == nil then
			return "no such button"
		end
		v330()
		return "pressed " .. p329
	end
	function v_u_108.state() -- name: state
		-- upvalues: (copy) v_u_120, (ref) v_u_118, (ref) v_u_117, (ref) v_u_116, (copy) v_u_126, (ref) v_u_136, (ref) v_u_112, (copy) v_u_119
		local v331 = 0
		for _ in v_u_120 do
			v331 = v331 + 1
		end
		return {
			["skin"] = v_u_118,
			["weapon"] = v_u_117,
			["all"] = v_u_116,
			["groups"] = v_u_126,
			["panel"] = v_u_136.Visible,
			["tiles"] = v331,
			["view"] = v_u_112 ~= nil,
			["stack"] = v_u_119.stack,
			["flow"] = v_u_119.flow
		}
	end
	function v_u_108.cards() -- name: cards
		-- upvalues: (copy) v_u_120
		return v_u_120
	end
	function v_u_108.show() -- name: show
		-- upvalues: (ref) v_u_111, (copy) v_u_109, (copy) v_u_108, (ref) v_u_114, (copy) p_u_92, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113
		v_u_111 = true
		v_u_109.Visible = true
		v_u_108.draw()
		v_u_114 = v_u_114 + 1
		local v_u_332 = v_u_114
		local v_u_333 = 5
		task.spawn(function()
			-- upvalues: (ref) p_u_92, (copy) v_u_333, (copy) v_u_332, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
			local v334 = p_u_92.fetch("crates", nil, v_u_333 or 0)
			if v_u_332 == v_u_114 and v_u_110 then
				if type(v334) == "table" then
					v_u_112 = v334
					v_u_113 = false
				else
					v_u_113 = v_u_112 == nil
				end
				if v_u_111 and v_u_109.Parent then
					v_u_108.draw()
				end
			end
		end)
	end
	function v_u_108.hide() -- name: hide
		-- upvalues: (ref) v_u_111, (ref) v_u_125, (ref) v_u_124, (ref) v_u_123
		v_u_111 = false
		v_u_125 = v_u_125 + 1
		if v_u_124 then
			local v335 = v_u_124.close
			pcall(v335)
			v_u_124 = nil
		end
		if v_u_123 then
			local v336 = v_u_123.destroy
			pcall(v336)
			v_u_123 = nil
		end
	end
	local v_u_337
	if p_u_92.changed and p_u_92.changed.Connect then
		v_u_337 = p_u_92.changed:Connect(function(p338, p339)
			-- upvalues: (copy) v_u_97, (copy) p_u_92, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (copy) v_u_109, (copy) v_u_108
			if p338 == "result" and type(p339) == "table" then
				if p339.op == "skinEquip" or (p339.op == "skinUnequip" or (p339.op == "skinScrapCopy" or (p339.op == "storeGrant" or p339.op == "crateOpen"))) then
					local v340 = v_u_97.busy
					local v341
					if type(v340) == "function" then
						local v342 = v_u_97.busy
						local v343
						v341, v343 = pcall(v342)
						if v341 then
							v341 = v343 == true
						end
					else
						v341 = false
					end
					if not v341 then
						p_u_92.invalidate("crates")
						v_u_114 = v_u_114 + 1
						local v_u_344 = v_u_114
						local v_u_345 = 0
						task.spawn(function()
							-- upvalues: (ref) p_u_92, (copy) v_u_345, (copy) v_u_344, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
							local v346 = p_u_92.fetch("crates", nil, v_u_345 or 0)
							if v_u_344 == v_u_114 and v_u_110 then
								if type(v346) == "table" then
									v_u_112 = v346
									v_u_113 = false
								else
									v_u_113 = v_u_112 == nil
								end
								if v_u_111 and v_u_109.Parent then
									v_u_108.draw()
								end
							end
						end)
					end
				end
			end
		end)
	else
		v_u_337 = nil
	end
	function v_u_108.refresh(p347) -- name: refresh
		-- upvalues: (ref) v_u_111, (ref) v_u_114, (copy) p_u_92, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (copy) v_u_109, (copy) v_u_108
		if p347 == "profile" and v_u_111 then
			v_u_114 = v_u_114 + 1
			local v_u_348 = v_u_114
			local v_u_349 = 5
			task.spawn(function()
				-- upvalues: (ref) p_u_92, (copy) v_u_349, (copy) v_u_348, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
				local v350 = p_u_92.fetch("crates", nil, v_u_349 or 0)
				if v_u_348 == v_u_114 and v_u_110 then
					if type(v350) == "table" then
						v_u_112 = v350
						v_u_113 = false
					else
						v_u_113 = v_u_112 == nil
					end
					if v_u_111 and v_u_109.Parent then
						v_u_108.draw()
					end
				end
			end)
		end
	end
	function v_u_108.destroy() -- name: destroy
		-- upvalues: (ref) v_u_110, (ref) v_u_114, (ref) v_u_337, (ref) v_u_125, (ref) v_u_124, (ref) v_u_123, (copy) v_u_238, (copy) v_u_109
		v_u_110 = false
		v_u_114 = v_u_114 + 1
		if v_u_337 then
			local function v351()
				-- upvalues: (ref) v_u_337
				v_u_337:Disconnect()
			end
			pcall(v351)
			v_u_337 = nil
		end
		v_u_125 = v_u_125 + 1
		if v_u_124 then
			local v352 = v_u_124.close
			pcall(v352)
			v_u_124 = nil
		end
		if v_u_123 then
			local v353 = v_u_123.destroy
			pcall(v353)
			v_u_123 = nil
		end
		v_u_238()
		v_u_109:Destroy()
	end
	p_u_92._skinsGrid = v_u_108
	if v_u_99.command and not p_u_92._skinsGridCmds then
		p_u_92._skinsGridCmds = true
		v_u_99.command("skins.select", function(p354)
			-- upvalues: (copy) p_u_92
			local v355 = p_u_92._skinsGrid
			if not v355 then
				return "no skins grid (open it first: menu.openskins)"
			end
			local v356 = v355.select
			local v357
			if p354[1] == nil or p354[1] == "none" then
				v357 = nil
			else
				v357 = p354[1]
			end
			v356(v357)
			local v358 = v355.state().skin
			return "selected " .. tostring(v358)
		end)
		v_u_99.command("skins.focus", function(p359)
			-- upvalues: (copy) p_u_92
			local v360 = p_u_92._skinsGrid
			if not v360 then
				return "no skins grid"
			end
			local v361 = v360.focusWeapon
			local v362
			if p359[1] == nil or p359[1] == "none" then
				v362 = nil
			else
				v362 = p359[1]
			end
			v361(v362)
			local v363 = v360.state()
			local v364 = v363.weapon
			local v365 = tostring(v364)
			local v366 = v363.skin
			return ("weapon=%s skin=%s tiles=%d"):format(v365, tostring(v366), v363.tiles)
		end)
		v_u_99.command("skins.all", function(p367)
			-- upvalues: (copy) p_u_92
			local v368 = p_u_92._skinsGrid
			if not v368 then
				return "no skins grid"
			end
			v368.setAll(p367[1] == "on")
			local v369 = v368.state().all
			return "all=" .. tostring(v369)
		end)
		v_u_99.command("skins.state", function()
			-- upvalues: (copy) p_u_92
			local v370 = p_u_92._skinsGrid
			if not v370 then
				return "no skins grid"
			end
			local v371 = v370.state()
			local v372 = v371.skin
			local v373 = tostring(v372)
			local v374 = v371.weapon
			local v375 = tostring(v374)
			local v376 = v371.all
			local v377 = tostring(v376)
			local v378 = v371.panel
			local v379 = tostring(v378)
			local v380 = v371.tiles
			local v381 = v371.stack
			local v382 = tostring(v381)
			local v383 = v371.flow
			return ("skin=%s weapon=%s all=%s panel=%s tiles=%d stack=%s flow=%s groups=%d/%d/%d/%d/%d"):format(v373, v375, v377, v379, v380, v382, tostring(v383), v371.groups.weapons or -1, v371.groups.knives or -1, v371.groups.head or -1, v371.groups.vest or -1, v371.groups.outfit or -1)
		end)
		v_u_99.command("skins.press", function(p384)
			-- upvalues: (copy) p_u_92
			local v385 = p_u_92._skinsGrid
			return not v385 and "no skins grid" or v385.press(p384[1] or "primary")
		end)
	end
	task.defer(function()
		-- upvalues: (ref) v_u_110, (ref) v_u_114, (copy) p_u_92, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (copy) v_u_109, (copy) v_u_108
		if v_u_110 then
			v_u_114 = v_u_114 + 1
			local v_u_386 = v_u_114
			local v_u_387 = 20
			task.spawn(function()
				-- upvalues: (ref) p_u_92, (copy) v_u_387, (copy) v_u_386, (ref) v_u_114, (ref) v_u_110, (ref) v_u_112, (ref) v_u_113, (ref) v_u_111, (ref) v_u_109, (ref) v_u_108
				local v388 = p_u_92.fetch("crates", nil, v_u_387 or 0)
				if v_u_386 == v_u_114 and v_u_110 then
					if type(v388) == "table" then
						v_u_112 = v388
						v_u_113 = false
					else
						v_u_113 = v_u_112 == nil
					end
					if v_u_111 and v_u_109.Parent then
						v_u_108.draw()
					end
				end
			end)
		end
	end)
	return v_u_108
end
return v_u_1