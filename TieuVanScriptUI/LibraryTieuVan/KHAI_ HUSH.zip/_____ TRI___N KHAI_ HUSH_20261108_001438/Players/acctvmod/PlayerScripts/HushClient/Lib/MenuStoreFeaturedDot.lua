-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreFeaturedDot

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = {
	["KEY"] = "menuTipsSeen",
	["LIMIT"] = 200,
	["ID_MAX"] = 24,
	["PREFIX"] = "sf_",
	["STAMP_MOD"] = 10000000,
	["ATTR"] = "StoreFeatured",
	["ATTR_SALE"] = "StoreFeaturedSale",
	["player"] = nil,
	["serverNow"] = nil
}
local v_u_3 = nil
function v_u_2.setRules(p4) -- name: setRules
	-- upvalues: (ref) v_u_3
	v_u_3 = p4
end
local v_u_5 = nil
function v_u_2.setOwnApply(p6) -- name: setOwnApply
	-- upvalues: (ref) v_u_5
	if type(p6) ~= "function" then
		p6 = nil
	end
	v_u_5 = p6
end
v_u_2.FAMILY = {
	["bundle_minigun"] = "mg",
	["bundle_nvg_raid"] = "nvg",
	["bundle_katana_vial"] = "kv",
	["pack_crimson"] = "cr",
	["pack_crimson_r"] = "cr"
}
function v_u_2.family(p7) -- name: family
	-- upvalues: (copy) v_u_2
	if type(p7) == "string" and p7 ~= "" then
		local v8 = v_u_2.FAMILY[p7]
		if v8 == nil then
			local v9 = string.lower((string.gsub(p7, "[^%w]", "")))
			if v9 == "" then
				return nil
			else
				return string.sub(v9, 1, 8)
			end
		else
			return v8
		end
	else
		return nil
	end
end
function v_u_2.stamp(p10) -- name: stamp
	-- upvalues: (copy) v_u_2
	local v11
	if type(p10) == "number" and (p10 == p10 and p10 > (-1 / 0)) then
		v11 = p10 < (1 / 0)
	else
		v11 = false
	end
	if not v11 or p10 < 0 then
		return nil
	end
	local v12 = math.floor(p10) % v_u_2.STAMP_MOD
	return tostring(v12)
end
function v_u_2.idOf(p13, p14) -- name: idOf
	-- upvalues: (copy) v_u_2
	if type(p13) == "string" and (p13 ~= "" and not string.find(p13, "[^%w]")) then
		local v15 = v_u_2.PREFIX .. p13 .. "_" .. (type(p14) ~= "string" and "" or p14)
		if type(p14) == "string" and (p14 == "" or string.find(p14, "[^%d]")) then
			return nil
		elseif #v15 > v_u_2.ID_MAX then
			return nil
		else
			return v15
		end
	else
		return nil
	end
end
local function v_u_34(p16, p17, p18) -- name: featuredOffersFrom
	-- upvalues: (copy) v_u_2
	local v19 = {}
	if type(p16) == "table" then
		local v20 = p16.featured
		if type(v20) == "string" then
			local v21 = p16.products
			if type(v21) == "table" then
				for _, v22 in p16.products do
					if type(v22) ~= "table" or v22.id ~= p16.featured then
						continue
					end
					local v23 = v22.limited
					if type(v23) ~= "table" or v23.state ~= "running" then
						return v19
					end
					local v24 = v23.endsAt
					local v25
					if type(v24) == "number" and (v24 == v24 and v24 > (-1 / 0)) then
						v25 = v24 < (1 / 0)
					else
						v25 = false
					end
					if v25 then
						local v26 = v23.now
						local v27
						if type(v26) == "number" and (v26 == v26 and v26 > (-1 / 0)) then
							v27 = v26 < (1 / 0)
						else
							v27 = false
						end
						if v27 then
							local v28
							if type(p17) == "number" and (p17 == p17 and p17 > (-1 / 0)) then
								v28 = p17 < (1 / 0)
							else
								v28 = false
							end
							if v28 then
								local v29
								if type(p18) == "number" and (p18 == p18 and p18 > (-1 / 0)) then
									v29 = p18 < (1 / 0)
								else
									v29 = false
								end
								if v29 then
									local v30 = v23.now
									local v31 = p18 - p17
									if v30 + math.max(0, v31) >= v23.endsAt then
										return v19
									end
								end
							end
						end
					end
					local v32 = v_u_2.family(v22.id)
					if v32 ~= nil then
						local v33 = {
							["family"] = v32,
							["stamp"] = v_u_2.stamp(v23.endsAt),
							["product"] = v22.id
						}
						table.insert(v19, v33)
					end
					return v19
				end
				return v19
			end
		end
	end
	return v19
end
function v_u_2.saleOffers(p35, p36, p37) -- name: saleOffers
	-- upvalues: (ref) v_u_5, (ref) v_u_3, (copy) v_u_2
	local v38 = {}
	if type(p35) == "table" then
		local v39 = p35.products
		if type(v39) == "table" then
			local v40 = nil
			local v41 = p35.saleNow
			local v42
			if type(v41) == "number" and (v41 == v41 and v41 > (-1 / 0)) then
				v42 = v41 < (1 / 0)
			else
				v42 = false
			end
			if v42 then
				local v43
				if type(p36) == "number" and (p36 == p36 and p36 > (-1 / 0)) then
					v43 = p36 < (1 / 0)
				else
					v43 = false
				end
				if v43 then
					local v44
					if type(p37) == "number" and (p37 == p37 and p37 > (-1 / 0)) then
						v44 = p37 < (1 / 0)
					else
						v44 = false
					end
					if v44 then
						local v45 = p35.saleNow
						local v46 = p37 - p36
						v40 = v45 + math.max(0, v46)
					end
				end
			end
			if v_u_5 ~= nil then
				local v47 = v_u_5
				pcall(v47, p35)
			end
			local v48 = 0
			local v49 = false
			for _, v50 in p35.products do
				local v51
				if type(v50) == "table" then
					v51 = v50.sale
				else
					v51 = nil
				end
				if type(v51) ~= "table" or (v50.enabled == false or (v50.owned == true or v50.offSale == true)) then
					continue
				end
				local v52 = true
				local v53 = v51.ends
				local v54
				if type(v53) == "number" and (v53 == v53 and v53 > (-1 / 0)) then
					v54 = v53 < (1 / 0)
				else
					v54 = false
				end
				if v54 and (v40 ~= nil and v51.ends <= v40) then
					v52 = false
				end
				if v_u_3 == nil and game ~= nil then
					local function v56()
						-- upvalues: (ref) v_u_3
						local v55 = game:GetService("ReplicatedStorage")
						v_u_3 = require((v55:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("SaleRules", 5)))
					end
					pcall(v56)
				end
				local v57 = v_u_3
				if v52 then
					local v58 = v51.was
					local v59
					if type(v58) == "number" and (v58 == v58 and v58 > (-1 / 0)) then
						v59 = v58 < (1 / 0)
					else
						v59 = false
					end
					if v59 and v50.ownChecked ~= true then
						v52 = false
					end
				end
				if v52 and v57 ~= nil then
					local v60 = v51.was
					local v61
					if type(v60) == "number" and (v60 == v60 and v60 > (-1 / 0)) then
						v61 = v60 < (1 / 0)
					else
						v61 = false
					end
					if v61 then
						local v62 = v50.price
						local v63
						if type(v62) == "number" and (v62 == v62 and v62 > (-1 / 0)) then
							v63 = v62 < (1 / 0)
						else
							v63 = false
						end
						if v63 then
							local v64 = v57.clientView
							local v65 = v50.price
							local v66
							if v40 then
								v66 = v40
							else
								local v67 = v51.ends
								local v68
								if type(v67) == "number" and (v67 == v67 and v67 > (-1 / 0)) then
									v68 = v67 < (1 / 0)
								else
									v68 = false
								end
								v66 = not v68 and 0 or v51.ends - 1
							end
							if v64(v51, v65, v66) == nil then
								v52 = false
							end
						end
					end
				end
				if not v52 then
					continue
				end
				v49 = true
				local v69 = v51.since
				local v70
				if type(v69) == "number" and (v69 == v69 and v69 > (-1 / 0)) then
					v70 = v69 < (1 / 0)
				else
					v70 = false
				end
				if not v70 or v48 >= v51.since then
					continue
				end
				v48 = v51.since
			end
			if v49 then
				local v71 = {
					["family"] = "sale",
					["stamp"] = nil,
					["stamp"] = ("%07d"):format(math.floor(v48) % v_u_2.STAMP_MOD)
				}
				table.insert(v38, v71)
			end
			return v38
		end
	end
	return v38
end
function v_u_2.offersFromView(p72, p73, p74) -- name: offersFromView
	-- upvalues: (copy) v_u_34, (copy) v_u_2
	local v75 = v_u_34(p72, p73, p74)
	for _, v76 in v_u_2.saleOffers(p72, p73, p74) do
		table.insert(v75, v76)
	end
	return v75
end
function v_u_2.staticOffers(p77, p78, p79, p80) -- name: staticOffers
	-- upvalues: (copy) v_u_2
	local v81 = {}
	if p80 == "pve" and type(p79) == "table" then
		local v82 = p79.PRODUCTS
		if type(v82) == "table" and type(p78) == "function" then
			local v83
			if type(p77) == "number" and (p77 == p77 and p77 > (-1 / 0)) then
				v83 = p77 < (1 / 0)
			else
				v83 = false
			end
			if v83 then
				local v84 = {}
				for v85 in p79.PRODUCTS do
					table.insert(v84, v85)
				end
				table.sort(v84)
				for _, v86 in v84 do
					local v87 = p79.PRODUCTS[v86]
					if type(v87) ~= "table" then
						continue
					end
					local v88 = v87.fixedEnd
					local v89
					if type(v88) == "number" and (v88 == v88 and v88 > (-1 / 0)) then
						v89 = v88 < (1 / 0)
					else
						v89 = false
					end
					if not v89 or p77 >= v87.fixedEnd then
						continue
					end
					local v90 = v87.flag
					local v91, v92 = pcall(p78, v90)
					local v93 = v_u_2.family(v86)
					if not v91 or (v92 ~= true or v93 == nil) then
						continue
					end
					local v94 = {
						["family"] = v93,
						["stamp"] = v_u_2.stamp(v87.fixedEnd),
						["product"] = v86
					}
					table.insert(v81, v94)
					return v81
				end
				return v81
			end
		end
	end
	return v81
end
local function v_u_99(p95) -- name: parse
	local v96 = {}
	if type(p95) ~= "string" then
		return v96
	end
	local v97 = {}
	for v98 in string.gmatch(p95, "[^,]+") do
		if string.find(v98, "[^%w_]") or v97[v98] then
			continue
		end
		v97[v98] = true
		table.insert(v96, v98)
	end
	return v96
end
function v_u_2.seenIn(p100, p101, p102) -- name: seenIn
	-- upvalues: (copy) v_u_2, (copy) v_u_99
	if type(p102) == "table" then
		local v103 = p102.family
		if type(v103) == "string" then
			local v104 = type(p101) ~= "table" and {} or p101
			local v105 = v_u_2.idOf(p102.family, p102.stamp)
			local v106 = p102.stamp
			if type(v106) == "string" then
				return v105 == nil and true or (v104[v105] == true and true or table.find(v_u_99(p100), v105) ~= nil)
			end
			local v107 = v_u_2.PREFIX .. p102.family .. "_"
			for v108 in v104 do
				local v109 = #v107
				if string.sub(v108, 1, v109) ~= v107 then
					continue
				end
				return true
			end
			for _, v110 in v_u_99(p100) do
				local v111 = #v107
				if string.sub(v110, 1, v111) ~= v107 then
					continue
				end
				return true
			end
			return false
		end
	end
	return true
end
function v_u_2.unseen(p112, p113, p114) -- name: unseen
	-- upvalues: (copy) v_u_2
	local v115 = {}
	if type(p112) ~= "table" then
		return v115
	end
	for _, v116 in p112 do
		if v_u_2.seenIn(p113, p114, v116) then
			continue
		end
		table.insert(v115, v116)
	end
	return v115
end
function v_u_2.markValue(p117, p118) -- name: markValue
	-- upvalues: (copy) v_u_99, (copy) v_u_2
	local v119 = v_u_99(p117)
	local v120 = {}
	for _, v121 in v119 do
		v120[v121] = true
	end
	local v122 = false
	if type(p118) == "table" then
		for _, v123 in p118 do
			local v124
			if type(v123) == "table" then
				local v125 = v123.stamp
				if type(v125) == "string" then
					v124 = v_u_2.idOf(v123.family, v123.stamp)
				else
					v124 = nil
				end
			else
				v124 = nil
			end
			if v124 == nil or v120[v124] then
				continue
			end
			v120[v124] = true
			table.insert(v119, v124)
			v122 = true
		end
	end
	if v122 then
		local v126 = table.concat(v119, ",")
		if #v126 > v_u_2.LIMIT then
			return nil, "limit"
		else
			return v126, nil
		end
	else
		return nil, "none"
	end
end
local v_u_127 = {
	["attached"] = false,
	["mc"] = nil,
	["session"] = nil,
	["inflight"] = nil,
	["conn"] = nil,
	["last"] = -1,
	["view"] = nil,
	["session"] = {},
	["inflight"] = {}
}
function v_u_2.estimateOffers(p_u_128) -- name: estimateOffers
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v_u_129 = nil
	local v_u_130 = "pve"
	local function v131()
		-- upvalues: (ref) v_u_129, (copy) p_u_128
		v_u_129 = p_u_128.cctx.shared.LimitedSale
	end
	pcall(v131)
	local function v132()
		-- upvalues: (copy) p_u_128, (ref) v_u_130
		if p_u_128.cctx.shared.GameMode.rule("storeScope") == "pvp" then
			v_u_130 = "pvp"
		end
	end
	pcall(v132)
	local v133 = v_u_2.staticOffers
	local v134 = v_u_2.serverNow
	local v135
	if type(v134) == "function" then
		v135 = v_u_2.serverNow()
	else
		local v136 = v_u_1.now
		local v137
		v137, v135 = pcall(v136)
		if v137 then
			local v138
			if type(v135) == "number" and (v135 == v135 and v135 > (-1 / 0)) then
				v138 = v135 < (1 / 0)
			else
				v138 = false
			end
			if not v138 then
				v135 = os.time()
			end
		else
			v135 = os.time()
		end
	end
	return v133(v135, function(p139)
		-- upvalues: (copy) p_u_128
		return p_u_128.cctx.config.flag(p139) == true
	end, v_u_129, v_u_130)
end
function v_u_2.currentOffers(p_u_140) -- name: currentOffers
	-- upvalues: (copy) v_u_127, (copy) v_u_2
	local v_u_141 = nil
	local function v142()
		-- upvalues: (ref) v_u_141, (copy) p_u_140
		v_u_141 = p_u_140.cache.store
	end
	pcall(v142)
	local v143 = v_u_141
	if type(v143) == "table" then
		local v144 = v_u_141.data
		if type(v144) == "table" then
			local v145 = v_u_141.at
			local v146
			if type(v145) == "number" and (v145 == v145 and v145 > (-1 / 0)) then
				v146 = v145 < (1 / 0)
			else
				v146 = false
			end
			if v146 then
				v_u_127.view = {
					["data"] = v_u_141.data,
					["at"] = v_u_141.at
				}
			end
		end
	end
	if v_u_127.view == nil then
		return v_u_2.estimateOffers(p_u_140)
	else
		return v_u_2.offersFromView(v_u_127.view.data, v_u_127.view.at, os.clock())
	end
end
function v_u_2.refresh(p147) -- name: refresh
	-- upvalues: (copy) v_u_2, (copy) v_u_127
	local v_u_148 = v_u_2.player or game:GetService("Players").LocalPlayer
	local v149 = p147.profile
	local v150
	if type(v149) == "table" then
		local v151 = v149.settings
		if type(v151) == "table" then
			local v152 = v149.settings[v_u_2.KEY]
			v150 = type(v152) ~= "string" and "" or v152
		else
			v150 = nil
		end
	else
		v150 = nil
	end
	local v_u_153 = false
	local v_u_154
	if v150 == nil then
		v_u_154 = 0
	else
		local v155 = v_u_2.unseen(v_u_2.currentOffers(p147), v150, v_u_127.session)
		v_u_154 = #v155
		for _, v156 in v155 do
			if v156.family ~= "sale" then
				continue
			end
			v_u_153 = true
		end
	end
	v_u_127.last = v_u_154
	local function v159()
		-- upvalues: (ref) v_u_154, (copy) v_u_148, (ref) v_u_2, (ref) v_u_153
		local v157
		if v_u_154 > 0 then
			v157 = v_u_154
		else
			v157 = nil
		end
		if v_u_148:GetAttribute(v_u_2.ATTR) ~= v157 then
			v_u_148:SetAttribute(v_u_2.ATTR, v157)
		end
		local v158 = v_u_153 and true or nil
		if v_u_148:GetAttribute(v_u_2.ATTR_SALE) ~= v158 then
			v_u_148:SetAttribute(v_u_2.ATTR_SALE, v158)
		end
	end
	pcall(v159)
	return v_u_154
end
local v_u_160 = nil
local function v_u_171(p_u_161, p162, p_u_163) -- name: send
	-- upvalues: (copy) v_u_2, (copy) v_u_127, (copy) v_u_171
	local v_u_164 = p_u_161.op({
		["op"] = "setting",
		["key"] = nil,
		["value"] = nil,
		["key"] = v_u_2.KEY,
		["value"] = p162
	})
	v_u_127.inflight[v_u_164] = p_u_163
	task.delay(8, function()
		-- upvalues: (ref) v_u_127, (copy) v_u_164, (copy) p_u_163, (ref) v_u_2, (copy) p_u_161, (ref) v_u_171
		if v_u_127.inflight[v_u_164] ~= nil then
			v_u_127.inflight[v_u_164] = nil
			if p_u_163 < 2 then
				local v165 = v_u_2.mergeSession
				local v166 = p_u_161.profile
				local v167
				if type(v166) == "table" then
					local v168 = v166.settings
					if type(v168) == "table" then
						local v169 = v166.settings[v_u_2.KEY]
						v167 = type(v169) ~= "string" and "" or v169
					else
						v167 = nil
					end
				else
					v167 = nil
				end
				local v170 = v165(v167)
				if v170 ~= nil then
					v_u_171(p_u_161, v170, p_u_163 + 1)
				end
			end
		end
	end)
end
function v_u_2.mergeSession(p172) -- name: mergeSession
	-- upvalues: (copy) v_u_99, (copy) v_u_127, (copy) v_u_2
	local v173 = v_u_99(p172)
	local v174 = {}
	for _, v175 in v173 do
		v174[v175] = true
	end
	local v176 = {}
	for v177 in v_u_127.session do
		table.insert(v176, v177)
	end
	table.sort(v176)
	for _, v178 in v176 do
		if v174[v178] then
			continue
		end
		v174[v178] = true
		table.insert(v173, v178)
	end
	local v179 = table.concat(v173, ",")
	if #v179 > v_u_2.LIMIT then
		return nil
	else
		return v179
	end
end
function v_u_2.onStoreView(p180, p181, p182) -- name: onStoreView
	-- upvalues: (ref) v_u_160, (copy) v_u_2, (copy) v_u_127, (copy) v_u_171
	local v183 = {}
	if type(p180) ~= "table" then
		return v183
	end
	v_u_160(p180)
	local v184 = v_u_2.offersFromView(p181, p182, os.clock())
	local v185 = p180.profile
	local v186
	if type(v185) == "table" then
		local v187 = v185.settings
		if type(v187) == "table" then
			local v188 = v185.settings[v_u_2.KEY]
			v186 = type(v188) ~= "string" and "" or v188
		else
			v186 = nil
		end
	else
		v186 = nil
	end
	for _, v189 in v_u_2.unseen(v184, v186, v_u_127.session) do
		local v190 = v189.product
		if type(v190) ~= "string" then
			continue
		end
		v183[v189.product] = true
	end
	local v191 = {}
	local v192 = {}
	for _, v193 in v184 do
		local v194 = v193.stamp
		local v195
		if type(v194) == "string" then
			v195 = v_u_2.idOf(v193.family, v193.stamp)
		else
			v195 = nil
		end
		if v195 ~= nil then
			v192[v195] = true
		end
		table.insert(v191, v193)
	end
	if type(p181) == "table" then
		local v196 = p181.products
		if type(v196) == "table" then
			local v197 = v_u_127
			local v198 = {
				["data"] = p181
			}
			local v199
			if type(p182) == "number" and (p182 == p182 and p182 > (-1 / 0)) then
				v199 = p182 < (1 / 0)
			else
				v199 = false
			end
			if not v199 then
				p182 = os.clock()
			end
			v198.at = p182
			v197.view = v198
			for _, v200 in v_u_2.estimateOffers(p180) do
				local v201 = v200.stamp
				local v202
				if type(v201) == "string" then
					v202 = v_u_2.idOf(v200.family, v200.stamp)
				else
					v202 = nil
				end
				if v202 == nil or v192[v202] then
					continue
				end
				table.insert(v191, v200)
			end
		end
	end
	for _, v203 in v191 do
		local v204 = v203.stamp
		local v205
		if type(v204) == "string" then
			v205 = v_u_2.idOf(v203.family, v203.stamp)
		else
			v205 = nil
		end
		if v205 == nil then
			continue
		end
		v_u_127.session[v205] = true
	end
	local v206 = p180.profile
	if v186 ~= nil and type(v206) == "table" then
		local v207 = v206.settings
		if type(v207) == "table" then
			local v208 = v_u_2.markValue(v186, v191)
			if v208 ~= nil then
				v206.settings[v_u_2.KEY] = v208
				v_u_171(p180, v208, 1)
			end
		end
	end
	v_u_2.refresh(p180)
	return v183
end
v_u_160 = function(p_u_209)
	-- upvalues: (copy) v_u_127, (copy) v_u_2, (copy) v_u_171
	if not v_u_127.attached or v_u_127.mc ~= p_u_209 then
		v_u_127.attached = true
		v_u_127.mc = p_u_209
		v_u_127.last = -1
		if v_u_127.conn ~= nil then
			local function v210()
				-- upvalues: (ref) v_u_127
				v_u_127.conn:Disconnect()
			end
			pcall(v210)
			v_u_127.conn = nil
		end
		local v211 = p_u_209.changed
		if type(v211) == "table" then
			local v212 = p_u_209.changed.Connect
			if type(v212) == "function" then
				v_u_127.conn = p_u_209.changed:Connect(function(p213, p214)
					-- upvalues: (ref) v_u_127, (ref) v_u_2, (copy) p_u_209, (ref) v_u_171
					if p213 == "result" and (type(p214) == "table" and (p214.op == "setting" and v_u_127.inflight[p214.req] ~= nil)) then
						local v215 = v_u_127.inflight[p214.req]
						v_u_127.inflight[p214.req] = nil
						if p214.ok == false and v215 < 2 then
							local v216 = v_u_2.mergeSession
							local v217 = p_u_209.profile
							local v218
							if type(v217) == "table" then
								local v219 = v217.settings
								if type(v219) == "table" then
									local v220 = v217.settings[v_u_2.KEY]
									v218 = type(v220) ~= "string" and "" or v220
								else
									v218 = nil
								end
							else
								v218 = nil
							end
							local v221 = v216(v218)
							if v221 ~= nil then
								v_u_171(p_u_209, v221, v215 + 1)
							end
						end
					end
					if p213 == "profile" or p213 == "result" then
						v_u_2.refresh(p_u_209)
					end
				end)
			end
		end
	end
end
function v_u_2.attach(p222) -- name: attach
	-- upvalues: (ref) v_u_160, (copy) v_u_2
	if type(p222) == "table" then
		v_u_160(p222)
		v_u_2.refresh(p222)
	end
end
return v_u_2