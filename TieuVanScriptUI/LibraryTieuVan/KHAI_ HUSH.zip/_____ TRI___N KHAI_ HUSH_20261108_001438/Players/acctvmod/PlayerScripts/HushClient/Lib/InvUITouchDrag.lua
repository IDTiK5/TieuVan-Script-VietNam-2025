-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUITouchDrag

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("TweenService")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v4 = script.Parent
local v_u_5 = require(v3:WaitForChild("Theme"))
local v_u_6 = require(v4:WaitForChild("InvUITouchState"))
local v_u_7 = {
	["fsm"] = v_u_6.new(),
	["State"] = v_u_6,
	["POP"] = 1.1,
	["BAR_BAND"] = 78
}
local function v_u_12(p8) -- name: pop
	-- upvalues: (copy) v_u_7, (copy) v_u_2
	local v9 = p8.ghost
	if v9 and v9.Parent then
		local v_u_10 = v9:FindFirstChild("PopScale")
		if not v_u_10 then
			v_u_10 = Instance.new("UIScale")
			v_u_10.Name = "PopScale"
			v_u_10.Parent = v9
		end
		v_u_10.Scale = v_u_7.POP
		local function v11()
			-- upvalues: (ref) v_u_2, (copy) v_u_10
			v_u_2:Create(v_u_10, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
		pcall(v11)
	end
end
function v_u_7.began(p13) -- name: began
	-- upvalues: (copy) v_u_7, (copy) v_u_12
	local v14 = p13.pos
	v_u_7.fsm:begin(p13.io, not v14 and 0 or v14.X, not v14 and 0 or v14.Y)
	p13.parked = false
	v_u_12(p13)
end
local function v_u_21(p15) -- name: scrollSig
	local v16 = {}
	for _, v17 in p15.scrollers or {} do
		if not v17.Parent then
			continue
		end
		local v18 = string.format
		local v19 = v17.CanvasPosition.X
		local v20 = v17.CanvasPosition.Y
		table.insert(v16, v18("%d,%d", v19, v20))
	end
	return table.concat(v16, "|")
end
local function v_u_35(p22, p23, p24) -- name: regrab
	-- upvalues: (copy) v_u_7, (copy) v_u_12
	if p22.parked then
		local v25 = p24()
		if v25.drag() == p22 then
			local v26 = Vector2.new(p23.Position.X, p23.Position.Y)
			local v27 = p22.ghost
			p22.parked = false
			p22.io = p23
			v27.Active = false
			v27.BackgroundTransparency = 0.2
			v_u_7.fsm:grab(p23, v26.X, v26.Y)
			local v28 = v26 - v27.AbsolutePosition
			local v29 = Vector2.new
			local v30 = v28.X
			local v31 = v27.AbsoluteSize.X
			local v32 = math.clamp(v30, 0, v31)
			local v33 = v28.Y
			local v34 = v27.AbsoluteSize.Y
			p22.grab = v29(v32, (math.clamp(v33, 0, v34)))
			v_u_12(p22)
			v25.updateDrag(v26)
		end
	else
		return
	end
end
local function v_u_47(p_u_36, p_u_37, p38) -- name: park
	-- upvalues: (copy) v_u_35, (copy) v_u_21, (copy) v_u_1
	p_u_36.parked = true
	p_u_36.io = nil
	p_u_36.panelHover = nil
	local v39 = p_u_36.ghost
	v39.Active = true
	v39.BackgroundTransparency = 0.04
	p_u_36.gStroke.Thickness = 2
	v39.InputBegan:Connect(function(p40)
		-- upvalues: (copy) p_u_36, (ref) v_u_35, (copy) p_u_37
		if p40.UserInputType == Enum.UserInputType.Touch and p_u_36.parked then
			v_u_35(p_u_36, p40, p_u_37)
		end
	end)
	pcall(p38, p_u_36)
	local v_u_41 = p_u_37()
	local v_u_42 = v_u_21(p_u_36.m)
	local v_u_43 = nil
	v_u_43 = v_u_1.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_43, (copy) p_u_36, (copy) v_u_41, (ref) v_u_21, (ref) v_u_42
		local v44 = v_u_43
		if p_u_36.parked and (p_u_36.ghost.Parent and v_u_41.drag() == p_u_36) then
			local v45 = p_u_36.m
			if v45.dead == true and true or (not v45.isShown() or v_u_41.tileOf(v45, p_u_36.uid) == nil) then
				if v44 then
					v44:Disconnect()
				end
				v_u_41.endDrag(p_u_36.pos, true)
			else
				local v46 = v_u_21(v45)
				if v46 ~= v_u_42 then
					v_u_42 = v46
					v_u_41.updateDrag(p_u_36.pos)
				end
			end
		else
			if v44 then
				v44:Disconnect()
			end
			return
		end
	end)
	p_u_37().sound("tick")
end
function v_u_7.endHook(p48, p49, p50, p51) -- name: endHook
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_47
	if not p48.touch then
		return false
	end
	local v52 = v_u_7.fsm
	local v53 = nil
	if p49 then
		v52:cancel("cancel")
	else
		if p48.parked and not p48.panelHover then
			p48.target = nil
		end
		local v54 = {
			["action"] = p48.panelHover,
			["valid"] = p48.target ~= nil
		}
		local v55 = p48.from
		if v55 then
			if p48.from.kind == "slot" then
				v55 = p48.from.slot == "secure"
			else
				v55 = false
			end
		end
		v54.canPark = not v55
		v53 = v52:finish(v54) or v_u_6.decide(v54)
	end
	if v53 == "park" then
		v_u_47(p48, p50, p51)
		return true
	end
	p48.parked = false
	v52:cancel("end")
	return false
end
v_u_7.healed = 0
v_u_7.lastHeal = ""
function v_u_7.heal(p56) -- name: heal
	-- upvalues: (copy) v_u_7
	local v57 = v_u_7.fsm:heal(p56, os.clock())
	if v57 then
		local v58 = v_u_7
		v58.healed = v58.healed + 1
		v_u_7.lastHeal = v57
		if v_u_7.healed <= 3 then
			warn("[InvUI] touch state put right: " .. v57)
		end
	end
	return v57
end
function v_u_7.fingerGone(p59) -- name: fingerGone
	if p59 == nil or (p59.touch ~= true or p59.parked == true) then
		return nil
	else
		local v_u_60 = p59.io
		if v_u_60 == nil or typeof(v_u_60) ~= "Instance" then
			return nil
		else
			local v61, v62 = pcall(function()
				-- upvalues: (copy) v_u_60
				return v_u_60.UserInputState
			end)
			if v61 then
				return v62 == Enum.UserInputState.End and "end" or (v62 == Enum.UserInputState.Cancel and "cancel" or nil)
			else
				return nil
			end
		end
	end
end
function v_u_7.guard(p63, p64, p65, p66) -- name: guard
	-- upvalues: (copy) v_u_7
	local v67 = (p66 or v_u_7.fingerGone)(p63)
	if v67 then
		if p63.goneAt == nil then
			p63.goneAt = p64
			return
		elseif p64 - p63.goneAt >= 0.2 then
			local v68 = v_u_7
			v68.healed = v68.healed + 1
			v_u_7.lastHeal = "lost finger (" .. v67 .. ")"
			if v_u_7.healed <= 3 then
				warn("[InvUI] touch finger lost while an item was carried: " .. v67)
			end
			p65(p63.pos, v67 == "cancel")
		end
	else
		if p63 ~= nil and p63.goneAt ~= nil then
			p63.goneAt = nil
		end
		return
	end
end
function v_u_7.afterPickup(p69, p70, p71, p72) -- name: afterPickup
	-- upvalues: (copy) v_u_7
	if not p69 or (p71 == nil or p71.touch ~= true) then
		if not p69 then
			warn("[InvUI] touch pickup failed: " .. tostring(p70))
		end
		if p71 ~= nil then
			local v73 = p71.pos or Vector2.zero
			pcall(p72, v73, true)
		end
		v_u_7.fsm:cancel("pickup")
		local v74 = v_u_7
		v74.healed = v74.healed + 1
		v_u_7.lastHeal = p69 and "pickup without item" or "pickup error"
	end
end
function v_u_7.tap(p75, p76, p77) -- name: tap
	if p75.parked then
		p75.panelHover = p76
		p77().endDrag(p75.pos)
	end
end
function v_u_7.strip(p78, p79, p80, p81) -- name: strip
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v82 = {
		{
			["r"] = nil,
			["w"] = 2,
			["r"] = p81
		}
	}
	if p78.parked then
		local v83 = v_u_5.refSize()
		local v84 = p78.ghost.Parent
		local v85 = v_u_5.devViewport
		local v86, v87 = pcall(v85)
		if v84 and (not v86 or v87 == nil) then
			local v88 = v84.AbsoluteSize
			if v88.X > 10 and v88.Y > 10 then
				v83 = v88 / v_u_5.uiScale()
			end
		end
		p80 = {
			v83.X / 2 - 2,
			v83.Y - 4,
			v83.X / 2 + 2,
			v83.Y
		}
		local v89 = {
			["r"] = nil,
			["w"] = -3,
			["r"] = {
				0,
				v83.Y - v_u_7.BAR_BAND,
				v83.X,
				v83.Y
			}
		}
		table.insert(v82, v89)
	end
	return p79(p78.m, p78.uid, true, p80, v82)
end
function v_u_7.dbgGrab(p90, p91, p92) -- name: dbgGrab
	-- upvalues: (copy) v_u_35
	if not (p90 and p90.parked) then
		return "not parked"
	end
	local v93 = p91[1]
	local v94 = tonumber(v93) or p90.pos.X
	local v95 = p91[2]
	local v96 = tonumber(v95) or p90.pos.Y
	v_u_35(p90, {
		["Position"] = Vector3.new(v94, v96, 0),
		["UserInputType"] = Enum.UserInputType.Touch
	}, p92)
	local v97 = p91[3]
	local v98 = tonumber(v97)
	local v99 = p91[4]
	local v100 = tonumber(v99)
	if v98 and v100 then
		p92().updateDrag(Vector2.new(v98, v100))
	end
	local v101 = p90.target
	local v102 = "grabbed -> "
	local v103
	if v101 then
		local v104 = string.format
		local v105 = v101.kind
		local v106 = v101.container or (v101.slot or v101.index)
		local v107 = tostring(v106)
		local v108 = v101.x
		local v109 = tostring(v108)
		local v110 = v101.y
		v103 = v104("%s %s %s,%s", v105, v107, v109, (tostring(v110)))
	else
		v103 = "INVALID"
	end
	return v102 .. v103
end
function v_u_7.lift(p111) -- name: lift
	-- upvalues: (copy) v_u_7
	if p111.UserInputType == Enum.UserInputType.Touch then
		v_u_7.fsm:lift(p111)
	end
end
return v_u_7