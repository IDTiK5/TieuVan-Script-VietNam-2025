-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPvpveStatus

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_90 = {
	["RULES"] = {
		"pvp",
		"clans",
		"hardOnly",
		"mapsOpen",
		"clanAllies",
		"privateRaids",
		"cashPacks",
		"hunt",
		"visionCone"
	},
	["FLAGS"] = { "CashPacks", "HalloweenHunt", "VisionCone" },
	["lines"] = function(p5) -- name: lines
		-- upvalues: (copy) v_u_90
		local v6 = {}
		if type(p5) ~= "table" then
			table.insert(v6, {
				["name"] = "State",
				["text"] = "No status available.",
				["kind"] = "warn"
			})
			return v6
		end
		local v7 = p5.mode
		local v8 = tostring(v7)
		local v9
		if p5.override == nil then
			local v10 = p5.placeId
			v9 = "place id " .. tostring(v10)
		else
			local v11 = p5.override
			v9 = "Studio override " .. tostring(v11)
		end
		local v12 = {
			["name"] = "Game mode",
			["text"] = nil,
			["kind"] = nil,
			["text"] = v8 .. " (" .. v9 .. ")",
			["kind"] = v8 == "pvpve" and "ok" or "muted"
		}
		table.insert(v6, v12)
		local v13 = p5.rules
		local v14 = type(v13) ~= "table" and {} or p5.rules
		local v15 = {}
		for _, v16 in v_u_90.RULES do
			if v14[v16] == nil then
				continue
			end
			local v17 = v14[v16]
			local v18 = v16 .. " " .. (v17 == true and "on" or (v17 == false and "off" or tostring(v17)))
			table.insert(v15, v18)
		end
		local v19 = {
			["name"] = "Rules",
			["text"] = nil,
			["kind"] = "text",
			["text"] = #v15 <= 0 and "none" or table.concat(v15, ", ")
		}
		table.insert(v6, v19)
		if p5.zombieScale ~= nil then
			local v20 = {
				["name"] = "Zombie scale",
				["text"] = nil,
				["kind"] = "text"
			}
			local v21 = p5.zombieScale
			v20.text = tostring(v21)
			table.insert(v6, v20)
		end
		local v22 = p5.flags
		local v23 = type(v22) ~= "table" and {} or p5.flags
		local v24 = {}
		for _, v25 in v_u_90.FLAGS do
			if v23[v25] == nil then
				continue
			end
			local v26 = v23[v25]
			local v27 = v25 .. " " .. (v26 == true and "on" or (v26 == false and "off" or tostring(v26)))
			table.insert(v24, v27)
		end
		local v28 = {
			["name"] = "Switches",
			["text"] = nil,
			["kind"] = "text",
			["text"] = #v24 <= 0 and "none" or table.concat(v24, ", ")
		}
		table.insert(v6, v28)
		local v29 = p5.myClan
		local v30
		if type(v29) == "string" and p5.myClan ~= "" then
			local v31 = p5.myTag
			if type(v31) == "string" and p5.myTag ~= "" then
				v30 = "[" .. p5.myTag .. "]"
			else
				v30 = p5.myClan
			end
		else
			v30 = "none"
		end
		local v32 = {
			["name"] = "Clans here",
			["text"] = nil,
			["kind"] = "text"
		}
		local v33 = p5.clanCount
		local v34 = tonumber(v33) or 0
		local v35 = tostring(v34)
		local v36 = p5.players
		local v37 = tonumber(v36) or 0
		v32.text = v35 .. " in this server, " .. tostring(v37) .. " players, yours: " .. v30
		table.insert(v6, v32)
		return v6
	end,
	["collect"] = function(p38) -- name: collect
		-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_90, (copy) v_u_1
		local v_u_39 = type(p38) ~= "table" and {} or p38
		local v_u_40 = {
			["rules"] = {},
			["flags"] = {}
		}
		local v_u_41 = v_u_39.GM
		if v_u_41 == nil then
			local function v42()
				-- upvalues: (ref) v_u_41, (ref) v_u_2
				v_u_41 = require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("GameMode", 5)))
			end
			pcall(v42)
		end
		local v_u_43 = v_u_39.Config
		if v_u_43 == nil then
			local function v44()
				-- upvalues: (ref) v_u_43, (ref) v_u_2
				v_u_43 = require((v_u_2:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild("Config", 5)))
			end
			pcall(v44)
		end
		v_u_40.mode = v_u_39.mode
		if v_u_40.mode == nil and type(v_u_41) == "table" then
			pcall(function()
				-- upvalues: (copy) v_u_40, (ref) v_u_41
				v_u_40.mode = v_u_41.id()
			end)
		end
		v_u_40.mode = v_u_40.mode or "unknown"
		local v45
		if v_u_39.placeId == nil then
			v45 = game.PlaceId
		else
			v45 = v_u_39.placeId
		end
		v_u_40.placeId = v45
		if v_u_39.override == nil then
			if v_u_3:IsStudio() then
				v_u_40.override = workspace:GetAttribute("GameModeOverride")
			end
		else
			v_u_40.override = v_u_39.override
		end
		for _, v_u_46 in v_u_90.RULES do
			local v_u_47 = nil
			local v48 = v_u_39.rule
			if type(v48) == "function" then
				pcall(function()
					-- upvalues: (ref) v_u_47, (copy) v_u_39, (copy) v_u_46
					v_u_47 = v_u_39.rule(v_u_46)
				end)
			elseif type(v_u_41) == "table" then
				pcall(function()
					-- upvalues: (ref) v_u_47, (ref) v_u_41, (copy) v_u_46
					v_u_47 = v_u_41.rule(v_u_46)
				end)
			end
			v_u_40.rules[v_u_46] = v_u_47
		end
		local v49 = v_u_39.rule
		if type(v49) == "function" then
			pcall(function()
				-- upvalues: (copy) v_u_40, (copy) v_u_39
				v_u_40.zombieScale = v_u_39.rule("zombieScale")
			end)
		elseif type(v_u_41) == "table" then
			pcall(function()
				-- upvalues: (copy) v_u_40, (ref) v_u_41
				v_u_40.zombieScale = v_u_41.rule("zombieScale")
			end)
		end
		for _, v_u_50 in v_u_90.FLAGS do
			local v_u_51 = nil
			local v52 = v_u_39.flag
			if type(v52) == "function" then
				pcall(function()
					-- upvalues: (ref) v_u_51, (copy) v_u_39, (copy) v_u_50
					v_u_51 = v_u_39.flag(v_u_50)
				end)
			elseif type(v_u_43) == "table" then
				local v53 = v_u_43.flag
				if type(v53) == "function" then
					pcall(function()
						-- upvalues: (ref) v_u_51, (ref) v_u_43, (copy) v_u_50
						v_u_51 = v_u_43.flag(v_u_50)
					end)
				end
			end
			v_u_40.flags[v_u_50] = v_u_51
		end
		local v54 = v_u_39.players
		local v55
		if type(v54) == "table" then
			v55 = v_u_39.players
		else
			v55 = v_u_1:GetPlayers()
		end
		local v56 = {}
		local v57 = 0
		for _, v_u_58 in v55 do
			local v_u_59 = nil
			local function v60()
				-- upvalues: (ref) v_u_59, (copy) v_u_58
				v_u_59 = v_u_58:GetAttribute("ClanId")
			end
			pcall(v60)
			local v61 = v_u_59
			if type(v61) ~= "string" or (v_u_59 == "" or v56[v_u_59]) then
				continue
			end
			v56[v_u_59] = true
			v57 = v57 + 1
		end
		v_u_40.clanCount = v57
		v_u_40.players = #v55
		local v_u_62
		if v_u_39.me == nil then
			v_u_62 = v_u_1.LocalPlayer
		else
			v_u_62 = v_u_39.me
		end
		if v_u_62 ~= nil then
			pcall(function()
				-- upvalues: (copy) v_u_40, (copy) v_u_62
				v_u_40.myClan = v_u_62:GetAttribute("ClanId")
				v_u_40.myTag = v_u_62:GetAttribute("ClanTag")
			end)
		end
		return v_u_40
	end,
	["mount"] = function(p_u_63, p64, p65) -- name: mount
		-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_90
		local v_u_66 = type(p65) ~= "table" and {} or p65
		if type(p64) == "table" then
			local v67 = p64.color
			if type(v67) ~= "table" then
				p64 = v_u_4.Theme
			end
		else
			p64 = v_u_4.Theme
		end
		local v68 = p64.color
		local v69 = 0
		local v_u_70
		if v_u_66.player == nil then
			v_u_70 = v_u_1.LocalPlayer
		else
			v_u_70 = v_u_66.player
		end
		local v_u_71 = true
		if v_u_66.gui then
			v_u_66.gui.Destroying:Connect(function()
				-- upvalues: (ref) v_u_71
				v_u_71 = false
			end)
		end
		local v72 = v_u_4.label({
			["parent"] = nil,
			["text"] = "PvPvE status  \194\183  read only",
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = p_u_63,
			["color"] = v68.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		local v73 = v_u_66.order
		local v74, v75
		if type(v73) == "function" then
			v74 = v_u_66.order()
			v75 = v69
		else
			v69 = v69 + 1
			v74 = v69
			v75 = v69
		end
		v72.LayoutOrder = v74
		local v_u_76 = v_u_4.label({
			["parent"] = nil,
			["name"] = "PvpveStatusText",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = p_u_63,
			["color"] = v68.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		local v77 = v_u_66.order
		local v78
		if type(v77) == "function" then
			v78 = v_u_66.order()
		else
			v69 = v75 + 1
			v78 = v69
		end
		v_u_76.LayoutOrder = v78
		local v_u_79 = nil
		local v_u_80 = ""
		local function v_u_88() -- name: refresh
			-- upvalues: (ref) v_u_90, (copy) v_u_66, (ref) v_u_79, (ref) v_u_80, (ref) v_u_4, (copy) v_u_76, (copy) v_u_70
			local v81 = v_u_90.collect(v_u_66.env)
			v_u_79 = v81
			local v82 = v_u_90.lines(v81)
			local v83 = {}
			for _, v84 in v82 do
				local v85 = v84.name .. ": " .. v84.text
				table.insert(v83, v85)
			end
			v_u_80 = table.concat(v83, "\n")
			v_u_4.setText(v_u_76, v_u_80)
			if v_u_70 then
				local v86 = v_u_70
				local v87 = v81.mode
				v86:SetAttribute("FilmPvpveStatus", ("mode=%s|clans=%d|lines=%d"):format(tostring(v87), v81.clanCount or 0, #v82))
			end
		end
		v_u_88()
		task.spawn(function()
			-- upvalues: (ref) v_u_71, (copy) p_u_63, (copy) v_u_88
			while v_u_71 and p_u_63.Parent ~= nil do
				task.wait(5)
				if not v_u_71 or p_u_63.Parent == nil then
					return
				end
				if p_u_63.Visible == false then
					continue
				end
				local v89 = v_u_88
				pcall(v89)
			end
		end)
		return {
			["refresh"] = v_u_88,
			["info"] = function() -- name: info
				-- upvalues: (ref) v_u_79
				return v_u_79
			end,
			["text"] = function() -- name: text
				-- upvalues: (ref) v_u_80
				return v_u_80
			end
		}
	end
}
return v_u_90