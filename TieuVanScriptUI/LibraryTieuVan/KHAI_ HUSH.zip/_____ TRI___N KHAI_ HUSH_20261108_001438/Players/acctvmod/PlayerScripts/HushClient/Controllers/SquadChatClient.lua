-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / SquadChatClient

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("TextChatService")
local v3 = {
	["name"] = "SquadChatClient",
	["order"] = 49
}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = 1
local v_u_14 = nil
local v_u_15 = false
local v_u_16 = true
local v_u_17 = {
	["Keyboard"] = "Squad chat. Press %s to write.",
	["Touch"] = "Squad chat. MORE, then CHAT.",
	["Gamepad"] = "Squad chat. Your squad\'s messages show here."
}
local function v_u_19() -- name: wanted
	-- upvalues: (ref) v_u_5, (copy) v_u_4, (ref) v_u_8, (ref) v_u_9
	if v_u_5.session.place(v_u_4) == "Raid" then
		if v_u_8.flag("SquadChat") == true then
			if v_u_4:GetAttribute("SquadChatShow") == false then
				return false, nil
			else
				local v18 = v_u_4:GetAttribute("SquadChat")
				if type(v18) == "string" and v18 ~= "" then
					if v_u_9 == nil and v_u_4:GetAttribute("HudMounted") ~= true then
						return false, nil
					else
						return true, v18
					end
				else
					return false, nil
				end
			end
		else
			return false, nil
		end
	else
		return false, nil
	end
end
local function v_u_37() -- name: env
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (ref) v_u_5
	local v20 = v_u_7.safeRefSize()
	local v21 = v_u_6.device() == "Touch"
	local v22 = nil
	local v23
	if v21 then
		local v24 = v_u_5
		if v24 then
			v24 = v_u_5.controllers
		end
		local v25 = v24 and v24.HUD or nil
		if v25 then
			local v26 = v25.touchFrame
			if type(v26) == "function" then
				local v27 = v25.touchFrame
				local v28
				v28, v23 = pcall(v27)
				if v28 then
					if type(v23) ~= "table" then
						v23 = v22
					end
				else
					v23 = v22
				end
			else
				v23 = v22
			end
		else
			v23 = v22
		end
	else
		v23 = v22
	end
	local v29 = nil
	if v21 and v23 then
		local v30 = v_u_5
		if v30 then
			v30 = v_u_5.controllers
		end
		local v31 = v30 and v30.HUD or nil
		if v31 then
			local v32 = v31.centerColumn
			if type(v32) == "function" then
				local v33 = v31.centerColumn
				local v34, v35 = pcall(v33, true)
				if v34 and type(v35) == "table" then
					local v36 = v35.x0
					if type(v36) == "number" then
						v29 = v35.x0
					end
				end
			end
		end
	end
	return {
		["touch"] = v21,
		["refW"] = v20.X,
		["refH"] = v20.Y,
		["tf"] = v23,
		["colX0"] = v29
	}
end
local v_u_38 = ""
local function v_u_50(p39) -- name: relayout
	-- upvalues: (ref) v_u_9, (copy) v_u_37, (ref) v_u_38
	if v_u_9 then
		local v40 = v_u_37()
		local v41 = v_u_9.constructor.place(v40)
		local v42 = string.format
		local v43 = v41.x
		local v44 = v41.bottom
		local v45 = v41.w
		local v46 = v41.lines
		local v47 = v41.inputX
		local v48 = v41.inputOnTop
		local v49 = v42("%d|%d|%d|%d|%d|%s|%d|%d|%d", v43, v44, v45, v46, v47, tostring(v48), v41.inputY, v41.inputW, v40.refW)
		if p39 or v49 ~= v_u_38 then
			v_u_38 = v49
			v_u_9.layout(v40)
		end
	end
end
local function v_u_58() -- name: syncTouchButton
	-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_12
	local v51 = v_u_5
	if v51 then
		v51 = v_u_5.controllers
	end
	local v52 = v51 and v51.Input or nil
	local v53
	if v_u_9 == nil then
		v53 = false
	else
		v53 = v_u_6.device() == "Touch"
	end
	if v53 and not (v_u_12 and v_u_12.Parent) and v52 then
		local v54 = v52.touchButton
		if type(v54) == "function" then
			local v55 = v52.touchButton
			local v56, v57 = pcall(v55, "chat", {
				["text"] = "CHAT"
			})
			if v56 and (typeof(v57) == "Instance" and v57:IsA("GuiObject")) then
				v_u_12 = v57
			end
		end
	end
	if v_u_12 and v_u_12.Parent then
		v_u_12.Visible = v_u_9 ~= nil
	end
end
local function v_u_68(p59) -- name: mount
	-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (copy) v_u_4, (ref) v_u_16, (copy) v_u_50, (ref) v_u_6, (copy) v_u_17, (copy) v_u_58
	local v60 = v_u_5.lib.SquadChat
	v_u_9 = v60.new(v_u_5)
	v_u_9.constructor = v60
	v_u_10 = p59
	local v61 = v_u_9.setCanSend
	local v62
	if v_u_4:GetAttribute("SquadChatSend") == false then
		v62 = false
	else
		v62 = v_u_16
	end
	v61(v62)
	v_u_50(true)
	local v63 = v_u_6.device()
	local v64 = v_u_17[v63] or "Squad chat. Press %s to write."
	if v63 == "Keyboard" then
		v64 = string.format(v64, v_u_6.hint("chat"))
	end
	v_u_9.addSystem(v64)
	local v65 = v_u_5
	if v65 then
		v65 = v_u_5.controllers
	end
	local v66 = v65 and v65.HUD or nil
	if v66 then
		local v67 = v66.isVisible
		if type(v67) == "function" then
			v_u_9.setVisible(v66.isVisible())
		end
	end
	v_u_58()
end
function v3.init(p69) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_19, (copy) v_u_4, (copy) v_u_37, (copy) v_u_50
	v_u_5 = p69
	v_u_6 = p69.lib.HushUI
	v_u_6.bind(p69)
	v_u_7 = p69.shared.Theme
	v_u_8 = p69.config
	p69.command("chat.state", function()
		-- upvalues: (ref) v_u_9, (ref) v_u_19, (ref) v_u_4, (ref) v_u_5, (ref) v_u_8
		if v_u_9 then
			local v70 = v_u_9.snapshot()
			local v71 = #v70.rows - 2
			local v72 = {}
			for v73 = math.max(1, v71), #v70.rows do
				local v74 = v70.rows[v73]
				table.insert(v72, v74)
			end
			local v75 = v_u_9.channel()
			local v76 = v_u_9.state()
			local v77 = " channel="
			if v75 then
				v75 = v75.Name
			end
			return v76 .. v77 .. tostring(v75) .. " | " .. table.concat(v72, " || ")
		end
		local v78, _ = v_u_19()
		local v79 = string.format
		local v80 = tostring(v78)
		local v81 = v_u_4
		local v82 = tostring(v81:GetAttribute("SquadChat"))
		local v83 = v_u_5.session.place
		local v84 = v_u_4
		local v85 = tostring(v83(v84))
		local v86 = v_u_8.flag
		local v87 = v_u_4
		local v88 = v_u_4
		return v79("not mounted (want=%s channel attr=%s place=%s flag=%s show=%s hud=%s)", v80, v82, v85, tostring(v86("SquadChat")), tostring(v87:GetAttribute("SquadChatShow")), (tostring(v88:GetAttribute("HudMounted"))))
	end)
	p69.command("chat.say", function(p89)
		-- upvalues: (ref) v_u_9
		if not v_u_9 then
			return "not mounted"
		end
		local v90, v91 = v_u_9.say(table.concat(p89, " "))
		return (v90 and "sent: " or "refused: ") .. tostring(v91)
	end)
	p69.command("chat.type", function(p92)
		-- upvalues: (ref) v_u_9
		if not v_u_9 then
			return "not mounted"
		end
		if not v_u_9.open() then
			return "cannot open"
		end
		task.wait(0.05)
		v_u_9.snapshot().box.Text = table.concat(p92, " ")
		local v93 = v_u_9.state()
		v_u_9.close(true)
		return "typed and submitted | " .. v93
	end)
	p69.command("chat.open", function()
		-- upvalues: (ref) v_u_9
		if not v_u_9 then
			return "not mounted"
		end
		local v94 = v_u_9.open
		return "open=" .. tostring(v94())
	end)
	p69.command("chat.close", function(p95)
		-- upvalues: (ref) v_u_9
		if not v_u_9 then
			return "not mounted"
		end
		v_u_9.close(p95[1] == "send")
		return "closed"
	end)
	p69.command("chat.fake", function(p96)
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_5
		if not v_u_9 then
			return "not mounted"
		end
		local v97 = p96[1]
		local v98 = tonumber(v97) or 3
		local v99 = math.floor(v98)
		local v100 = math.clamp(v99, 1, 60)
		local v101 = {
			"Anna",
			"Bartholomew Longname",
			"Chris",
			"Dee"
		}
		for v102 = 1, v100 do
			local v103 = v_u_4.UserId + v102 % 4
			v_u_9.addLine(v103, v101[v102 % 4 + 1], ("Test line %d: the quick brown fox jumps over the lazy dog, again and again until it wraps."):format(v102), v_u_5.lib.HUDSquad.COLORS[v102 % 4 + 1])
		end
		return "added " .. v100
	end)
	p69.command("chat.layout", function()
		-- upvalues: (ref) v_u_9, (ref) v_u_37
		if not v_u_9 then
			return "not mounted"
		end
		local v104 = v_u_37()
		local v105 = v_u_9.constructor.place(v104)
		local v106 = string.format
		local v107 = v104.touch
		local v108 = tostring(v107)
		local v109 = v104.refW
		local v110 = v104.refH
		local v111 = v105.x
		local v112 = v105.bottom
		local v113 = v105.w
		local v114 = v105.lines
		local v115 = v105.inputOnTop
		return v106("touch=%s ref=%.0fx%.0f x=%d bottom=%d w=%d lines=%d inputOnTop=%s input=%d,%d w%d | %s", v108, v109, v110, v111, v112, v113, v114, tostring(v115), v105.inputX, v105.inputY, v105.inputW, v_u_9.state())
	end)
	p69.command("chat.hide", function(p116)
		-- upvalues: (ref) v_u_4
		local v117 = v_u_4
		local v118 = "SquadChatShow"
		local v119
		if p116[1] == "on" then
			v119 = false
		else
			v119 = nil
		end
		v117:SetAttribute(v118, v119)
		local v120 = v_u_4
		return "SquadChatShow=" .. tostring(v120:GetAttribute("SquadChatShow"))
	end)
	p69.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_50
		task.defer(v_u_50, true)
	end)
	local v121 = p69.on
	local function v122()
		-- upvalues: (ref) v_u_50
		task.defer(v_u_50)
	end
	pcall(v121, "touch.layout", v122)
end
local v_u_123 = nil
local function v_u_134() -- name: sayWhyNoChat
	-- upvalues: (ref) v_u_5, (copy) v_u_4, (ref) v_u_8, (ref) v_u_123, (ref) v_u_6
	local function v124()
		-- upvalues: (ref) v_u_5
		return v_u_5.lib.SquadsWhy
	end
	local v125, v126 = pcall(v124)
	if v125 and type(v126) == "table" then
		local function v127()
			-- upvalues: (ref) v_u_5, (ref) v_u_4
			return v_u_5.session.place(v_u_4)
		end
		local v128, v129 = pcall(v127)
		local v130 = v126.chatKeyReason
		local v131 = {}
		if not v128 then
			v129 = nil
		end
		v131.place = v129
		v131.flagOn = v_u_8.flag("SquadChat") == true
		v131.shown = v_u_4:GetAttribute("SquadChatShow")
		v131.channel = v_u_4:GetAttribute("SquadChat")
		local v132 = v130(v131)
		if v132 ~= nil and v126.keyDue(v_u_123, os.clock()) then
			v_u_123 = os.clock()
			local v133 = v_u_6.toast
			pcall(v133, "Squad chat", "info", v132)
		end
	else
		return
	end
end
function v3.start() -- name: start
	-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) v_u_134, (ref) v_u_11, (ref) v_u_6, (copy) v_u_50, (copy) v_u_58
	local v135 = v_u_5
	if v135 then
		v135 = v_u_5.controllers
	end
	local v136 = v135 and v135.Input or nil
	if v136 then
		local v137 = v136.bind
		if type(v137) == "function" then
			local v138 = v136.bind
			local function v139()
				-- upvalues: (ref) v_u_9, (ref) v_u_134
				if v_u_9 and not v_u_9.justClosed() then
					v_u_9.open()
				elseif v_u_9 == nil then
					v_u_134()
				end
			end
			local v140, v141 = pcall(v138, "chat", v139)
			if v140 and type(v141) == "function" then
				v_u_11 = v141
			end
		end
	end
	v_u_6.onDevice(function()
		-- upvalues: (ref) v_u_50, (ref) v_u_58
		task.defer(function()
			-- upvalues: (ref) v_u_50, (ref) v_u_58
			v_u_50()
			v_u_58()
		end)
	end)
end
function v3.step(p142) -- name: step
	-- upvalues: (ref) v_u_9, (ref) v_u_13, (ref) v_u_5, (copy) v_u_4, (ref) v_u_15, (ref) v_u_14, (copy) v_u_19, (ref) v_u_10, (ref) v_u_38, (ref) v_u_12, (copy) v_u_68, (copy) v_u_2, (ref) v_u_16, (copy) v_u_50, (copy) v_u_58
	if v_u_9 then
		v_u_9.update(p142)
	end
	v_u_13 = v_u_13 + p142
	if v_u_13 < 0.25 then
		return
	else
		v_u_13 = 0
		local v143 = v_u_5.session.place(v_u_4)
		if v143 == "Raid" and (not v_u_15 and v_u_4:GetAttribute("SquadChatShow") == nil) then
			v_u_15 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_5, (ref) v_u_4
				local v144 = v_u_5.net.invoke
				local v145, v146 = pcall(v144, "menu.get", {
					["what"] = "settings"
				})
				if v145 and type(v146) == "table" then
					local v147 = v146.squadChat
					if type(v147) == "boolean" and v_u_4:GetAttribute("SquadChatShow") == nil then
						v_u_4:SetAttribute("SquadChatShow", v146.squadChat)
					end
				end
			end)
		end
		if v143 ~= v_u_14 then
			v_u_14 = v143
			if v143 ~= "Raid" then
				v_u_15 = false
			end
		end
		local v148, v149 = v_u_19()
		if v148 then
			if not v_u_9 then
				v_u_68(v149)
				task.spawn(function()
					-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_16
					local function v150()
						-- upvalues: (ref) v_u_2, (ref) v_u_4
						return v_u_2:CanUserChatAsync(v_u_4.UserId)
					end
					local v151, v152 = pcall(v150)
					if v151 then
						v151 = v152 == false
					end
					v_u_16 = not v151
				end)
			end
			if v_u_9 then
				if v_u_10 ~= v149 then
					v_u_10 = v149
				end
				local v153 = v_u_9.channel()
				if v153 == nil or (v153.Name ~= v149 or v153.Parent == nil) then
					local v154 = (v_u_2:FindFirstChild("TextChannels") or v_u_2):FindFirstChild(v149)
					if not (v154 and v154:IsA("TextChannel")) then
						v154 = nil
					end
					if v154 then
						v_u_9.bind(v154)
					end
				end
				local v155 = v_u_9.setCanSend
				local v156
				if v_u_4:GetAttribute("SquadChatSend") == false then
					v156 = false
				else
					v156 = v_u_16
				end
				v155(v156)
				local v157 = v_u_5
				if v157 then
					v157 = v_u_5.controllers
				end
				local v158 = v157 and v157.HUD or nil
				if v158 then
					local v159 = v158.isVisible
					if type(v159) == "function" then
						v_u_9.setVisible(v158.isVisible())
					end
				end
				v_u_50()
				v_u_58()
			end
		elseif v_u_9 then
			if v_u_9 then
				local v160 = v_u_9.destroy
				pcall(v160)
			end
			v_u_9 = nil
			v_u_10 = nil
			v_u_38 = ""
			if v_u_12 and v_u_12.Parent then
				v_u_12.Visible = false
			end
		end
	end
end
return v3