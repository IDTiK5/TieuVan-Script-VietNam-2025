-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuHunt

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {
	["JOIN_LOCK"] = 1,
	["KEEP_SEC"] = 1.5
}
local v_u_5 = nil
v_u_4.POLL = 10
v_u_4.NEED = 6
v_u_4.BLOCK_HOLD = 12
v_u_4.TOAST_WINDOW = 8
local function v_u_9(p6) -- name: clock
	local v7 = math.floor(p6)
	local v8 = math.max(0, v7)
	return ("%d:%02d"):format(v8 // 60, v8 % 60)
end
v_u_4.clock = v_u_9
v_u_4.EVENT_MAX_SEC = 2592000
function v_u_4.endsText(p10, p11) -- name: endsText
	-- upvalues: (copy) v_u_4
	local v12 = (type(p11) ~= "number" or p11 ~= p11) and 0 or p11
	if v12 <= 60 or v_u_4.EVENT_MAX_SEC < v12 then
		return p10.MODE.endsSoon
	elseif v12 <= 3600 then
		local v13 = p10.format
		local v14 = p10.MODE.endsMin
		local v15 = v12 / 60
		return v13(v14, (math.ceil(v15)))
	elseif v12 <= 21600 then
		return p10.MODE.endsToday
	else
		local v16 = v12 / 86400
		local v17 = math.floor(v16)
		if v17 <= 1 then
			return p10.MODE.endsInOne
		else
			return p10.format(p10.MODE.endsIn, v17)
		end
	end
end
function v_u_4.countdown(p18, p19) -- name: countdown
	-- upvalues: (copy) v_u_4
	local v20 = (type(p19) ~= "number" or p19 ~= p19) and 0 or p19
	if v20 < 1 or v_u_4.EVENT_MAX_SEC < v20 then
		return p18.MODE.endsSoon
	else
		local v21 = math.floor(v20)
		local v22 = v21 // 86400
		local v23 = v21 % 86400 // 3600
		local v24 = v21 % 3600 // 60
		local v25 = v21 % 60
		if v21 >= 86400 then
			return p18.format(p18.TILE.endsDays, v22, v23, v24)
		elseif v21 >= 3600 then
			return p18.format(p18.TILE.endsHours, v23, v24)
		else
			return p18.format(p18.TILE.endsMinutes, v24, v25)
		end
	end
end
local v_u_26 = {
	["full"] = {
		["w"] = 264,
		["h"] = 152,
		["pad"] = 12,
		["tag"] = nil,
		["title"] = nil,
		["blurb"] = nil,
		["ends"] = nil,
		["status"] = nil,
		["count"] = nil,
		["btn"] = nil,
		["how"] = nil,
		["tag"] = {
			["y"] = 10,
			["h"] = 14,
			["size"] = 12
		},
		["title"] = {
			["y"] = 25,
			["h"] = 28,
			["size"] = 24
		},
		["blurb"] = {
			["y"] = 55,
			["h"] = 34,
			["size"] = 13
		},
		["ends"] = {
			["y"] = 91,
			["h"] = 14,
			["size"] = 12
		},
		["status"] = {
			["y"] = 55,
			["h"] = 34,
			["size"] = 14
		},
		["count"] = {
			["y"] = 75,
			["h"] = 14
		},
		["btn"] = {
			["y"] = 108,
			["h"] = 34
		},
		["how"] = {
			["w"] = 104,
			["gap"] = 6,
			["size"] = 12,
			["long"] = true
		}
	},
	["mini"] = {
		["w"] = 216,
		["h"] = 124,
		["pad"] = 10,
		["tag"] = nil,
		["title"] = nil,
		["blurb"] = nil,
		["ends"] = nil,
		["status"] = nil,
		["btn"] = nil,
		["how"] = nil,
		["tag"] = {
			["y"] = 8,
			["h"] = 12,
			["size"] = 11
		},
		["title"] = {
			["y"] = 21,
			["h"] = 24,
			["size"] = 20
		},
		["blurb"] = {
			["y"] = 0,
			["h"] = 0,
			["size"] = 12,
			["hidden"] = true
		},
		["ends"] = {
			["y"] = 47,
			["h"] = 14,
			["size"] = 12
		},
		["status"] = {
			["y"] = 63,
			["h"] = 16,
			["size"] = 13
		},
		["btn"] = {
			["y"] = 84,
			["h"] = 32
		},
		["how"] = {
			["w"] = 74,
			["gap"] = 6,
			["size"] = 11,
			["long"] = false
		}
	},
	["phone"] = {
		["w"] = 132,
		["h"] = 55,
		["pad"] = 8,
		["small"] = true,
		["tag"] = nil,
		["title"] = nil,
		["blurb"] = nil,
		["ends"] = nil,
		["status"] = nil,
		["btn"] = nil,
		["how"] = nil,
		["tag"] = {
			["y"] = 0,
			["h"] = 0,
			["size"] = 10,
			["hidden"] = true
		},
		["title"] = {
			["y"] = 3,
			["h"] = 15,
			["size"] = 13
		},
		["blurb"] = {
			["y"] = 0,
			["h"] = 0,
			["size"] = 10,
			["hidden"] = true
		},
		["ends"] = {
			["y"] = 19,
			["h"] = 12,
			["size"] = 10
		},
		["status"] = {
			["y"] = 19,
			["h"] = 12,
			["size"] = 10,
			["shareEnds"] = true
		},
		["btn"] = {
			["y"] = 34,
			["h"] = 16,
			["pill"] = true
		},
		["how"] = {
			["corner"] = true,
			["w"] = 44,
			["h"] = 34,
			["gap"] = 24
		}
	},
	["slim"] = {
		["w"] = 150,
		["h"] = 24,
		["pad"] = 5,
		["small"] = true,
		["pillW"] = 42,
		["tag"] = nil,
		["title"] = nil,
		["blurb"] = nil,
		["ends"] = nil,
		["status"] = nil,
		["btn"] = nil,
		["how"] = nil,
		["tag"] = {
			["y"] = 0,
			["h"] = 0,
			["size"] = 10,
			["hidden"] = true
		},
		["title"] = {
			["y"] = 4,
			["h"] = 14,
			["size"] = 11
		},
		["blurb"] = {
			["y"] = 0,
			["h"] = 0,
			["size"] = 10,
			["hidden"] = true
		},
		["ends"] = {
			["y"] = 4,
			["h"] = 14,
			["size"] = 10
		},
		["status"] = {
			["y"] = 4,
			["h"] = 14,
			["size"] = 10,
			["shareEnds"] = true
		},
		["btn"] = {
			["y"] = 4,
			["h"] = 14,
			["pill"] = true
		},
		["how"] = {
			["slim"] = true,
			["w"] = 32,
			["gap"] = 4
		}
	}
}
function v_u_4.layout(p27) -- name: layout
	-- upvalues: (copy) v_u_26
	return v_u_26[tostring(p27)] or v_u_26.full
end
function v_u_4.touchExtra(p28, p29) -- name: touchExtra
	-- upvalues: (copy) v_u_26
	local v30 = v_u_26[tostring(p28)] or v_u_26.full
	if v30.small or v30.btn == nil then
		return 0
	end
	local v31 = (tonumber(p29) or 0) - v30.btn.h
	return math.max(0, v31)
end
function v_u_4.visible(p32, p33, p34, p35, p36, p37, p38) -- name: visible
	local v39 = p33 ~= false
	if p32.status(v39, p34, p35) == "over" then
		return false
	else
		return p38 == true and true or p32.available(p36, p37 == true)
	end
end
function v_u_4.liveSoon(p_u_40) -- name: liveSoon
	local v42, v43 = pcall(function()
		local v41 = game:GetService("ReplicatedStorage"):FindFirstChild("Config")
		if v41 then
			return v41:GetAttribute("HuntSoon")
		else
			return nil
		end
	end)
	if v42 and type(v43) == "boolean" then
		return v43
	end
	local v44, v45 = pcall(function()
		-- upvalues: (copy) p_u_40
		return p_u_40.config.HUNT_SOON
	end)
	if v44 then
		v44 = v45 == true
	end
	return v44
end
function v_u_4.livePlaceId(p_u_46) -- name: livePlaceId
	local v47, v48 = pcall(function()
		-- upvalues: (copy) p_u_46
		return p_u_46.config.HUNT_PLACE_ID
	end)
	if v47 and (type(v48) == "number" and v48 > 0) then
		return v48
	end
	local v49, v50 = pcall(function()
		-- upvalues: (copy) p_u_46
		return p_u_46.config.huntPlaceOf(p_u_46.config.ENV)
	end)
	return (not v49 or type(v50) ~= "number") and 0 or v50
end
function v_u_4.openFor(p_u_51, p_u_52, p_u_53) -- name: openFor
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_3
	local v_u_54 = p_u_51.shared.HuntRules
	local function v62()
		-- upvalues: (copy) p_u_52, (copy) p_u_51, (ref) v_u_4, (copy) v_u_54, (ref) v_u_1, (copy) p_u_53, (ref) v_u_3
		local v55 = p_u_52 == true and true or p_u_51.config.flag("HalloweenHunt")
		local v56 = v_u_4.visible
		local v57 = v_u_54
		local v58 = v_u_1.now()
		local v59 = v_u_54.endUtc(p_u_51.config.HUNT_END_UTC)
		local v60 = v_u_4.livePlaceId(p_u_51)
		local v61
		if p_u_53 == nil then
			v61 = v_u_3:IsStudio()
		else
			v61 = p_u_53
		end
		return v56(v57, v55, v58, v59, v60, v61, v_u_4.liveSoon(p_u_51))
	end
	local v63, v64 = pcall(v62)
	if v63 then
		v63 = v64 == true
	end
	return v63
end
local v_u_65 = {
	["soon"] = true,
	["over"] = true
}
function v_u_4.view(p66, p67, p68, p69) -- name: view
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_65
	local v70 = {
		["state"] = "idle",
		["title"] = nil,
		["tag"] = nil,
		["blurb"] = nil,
		["safe"] = nil,
		["status"] = "",
		["count"] = "",
		["note"] = "",
		["button"] = nil,
		["kind"] = "primary",
		["enabled"] = true,
		["squad"] = false,
		["clock"] = "",
		["title"] = p66.MODE.name,
		["tag"] = p66.MODE.tag,
		["blurb"] = p66.MODE.blurb,
		["safe"] = p66.MODE.safe,
		["button"] = p66.MODE.join
	}
	local v71
	if type(p67) == "table" then
		v71 = p67.s
	else
		v71 = nil
	end
	if p69 == true and (v71 ~= "queued" and v71 ~= "found") then
		v70.button = p66.MODE.soon
		v70.enabled = false
		v70.soon = true
		return v70
	else
		local v72
		if type(p67) == "table" then
			local v73 = p67.s
			v72 = type(v73) ~= "string" and "idle" or p67.s
		else
			v72 = "idle"
		end
		if v72 == "idle" and type(p67) == "table" then
			local v74 = p67.t
			if type(v74) == "string" and p67.t ~= "" then
				v70.status = p67.t
			end
		end
		if v72 == "queued" then
			v70.state = "searching"
			local v75 = p67.sec
			local v76 = tonumber(v75) or 0
			local v77 = p67.at
			local v78 = p68 - (tonumber(v77) or p68)
			local v79 = v76 + math.max(0, v78)
			v70.status = p66.format(p66.LOBBY.searching, v_u_9(v79))
			local v80 = math.floor(v79)
			local v81 = math.max(0, v80)
			v70.clock = ("%d:%02d"):format(v81 // 60, v81 % 60)
			local v82 = p66.format
			local v83 = p66.LOBBY.count
			local v84 = p67.n
			local v85 = tonumber(v84) or 0
			local v86 = math.floor(v85)
			local v87 = math.max(0, v86)
			local v88 = p67.need
			local v89 = tonumber(v88) or v_u_4.NEED
			local v90 = math.floor(v89)
			v70.count = v82(v83, v87, (math.max(1, v90)))
			v70.note = p66.LOBBY.hideout
			v70.button = p66.MODE.cancel
			v70.kind = "close"
			local v91 = p67.sq
			if (tonumber(v91) or 0) > 1 and p67.lead ~= true then
				v70.squad = true
				v70.status = p66.LOBBY.squadSearching
				return v70
			end
		else
			if v72 == "found" then
				v70.state = "found"
				v70.status = p66.LOBBY.found
				v70.enabled = false
				return v70
			end
			if v72 == "blocked" then
				v70.state = "blocked"
				local v92 = p67.r
				local v93 = p67.t
				local v94
				if type(v93) == "string" and p67.t ~= "" then
					v94 = p67.t
				elseif type(v92) == "string" and v92 ~= "" then
					v94 = p66.reason(v92)
				else
					v94 = p66.reason("guard")
				end
				v70.status = v94
				local v95
				if type(v92) == "string" then
					v95 = v_u_65[v92] == true
				else
					v95 = false
				end
				v70.enabled = not v95
				local v96 = p67.rt
				if v92 == "raidTime" and type(v96) == "table" then
					local v97 = v96.need
					if type(v97) == "number" and v96.need > 0 then
						local v98 = v96.need
						local v99 = math.floor(v98)
						local v100 = v96.have
						local v101 = tonumber(v100) or 0
						local v102 = math.floor(v101)
						local v103 = math.clamp(v102, 0, v99)
						v70.locked = true
						v70.lockHave = v103
						v70.lockNeed = v99
						v70.progress = p66.format(p66.TILE.raidLock, v103, v99)
						local v104 = p67.t
						if type(v104) ~= "string" or p67.t == "" then
							v70.status = p66.reason("raidTime", v99 - v103)
						end
						v70.status = v70.progress .. "\n" .. v70.status
						v70.lockKind = "raid"
						v70.enabled = false
					end
				end
				local v105 = p67.ad
				if v92 == "accountAge" and type(v105) == "table" then
					local v106 = v105.need
					if type(v106) == "number" and v105.need > 0 then
						local v107 = v105.need
						local v108 = math.floor(v107)
						local v109 = v105.have
						local v110 = tonumber(v109) or 0
						local v111 = math.floor(v110)
						local v112 = math.clamp(v111, 0, v108)
						v70.locked = true
						v70.lockKind = "age"
						v70.lockHave = v112
						v70.lockNeed = v108
						v70.progress = p66.format(p66.TILE.ageLock, v112, v108)
						local v113 = p67.t
						if type(v113) ~= "string" or p67.t == "" then
							v70.status = p66.reason("accountAge", v108 - v112, v108)
						end
						v70.status = v70.progress .. "\n" .. v70.status
						v70.enabled = false
						return v70
					end
				end
			elseif v72 == "over" then
				v70.state = "over"
				v70.enabled = false
			end
		end
		return v70
	end
end
local v_u_114 = Color3.fromRGB(255, 124, 28)
local v_u_115 = Color3.fromRGB(255, 176, 96)
local v_u_116 = Color3.fromRGB(34, 14, 48)
local v_u_117 = Color3.fromRGB(132, 58, 12)
function v_u_4.new(p_u_118, p_u_119, p120, p_u_121) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_116, (copy) v_u_117, (copy) v_u_114, (copy) v_u_115, (copy) v_u_26, (copy) v_u_1, (copy) v_u_3, (ref) v_u_5, (copy) v_u_2
	local v_u_122 = p_u_118.ui
	local v_u_123 = p_u_118.theme
	local v_u_124 = v_u_123.color
	local v_u_125 = p_u_118.cctx
	local v_u_126 = v_u_125.shared.ModeNamesHalloween
	local v_u_127 = v_u_125.shared.HuntRules
	local v_u_128
	if type(p_u_121) == "table" then
		local v129 = p_u_121.mode
		v_u_128 = type(v129) ~= "string" and "full" or p_u_121.mode
	else
		v_u_128 = "full"
	end
	local v_u_130 = v_u_4.layout(v_u_128)
	local v_u_131
	if type(p_u_121) == "table" then
		local v132 = p_u_121.w
		if type(v132) == "number" then
			v_u_131 = p_u_121.w
		else
			v_u_131 = nil
		end
	else
		v_u_131 = nil
	end
	local v_u_133
	if type(p_u_121) == "table" then
		local v134 = p_u_121.onSize
		if type(v134) == "function" then
			v_u_133 = p_u_121.onSize
		else
			v_u_133 = nil
		end
	else
		v_u_133 = nil
	end
	local v_u_135 = 0
	local v_u_136 = (-1 / 0)
	local v_u_137 = (-1 / 0)
	local v_u_138 = ""
	local v_u_139 = {}
	local v_u_140 = true
	local v_u_141 = false
	local v_u_142 = {}
	local v_u_143 = nil
	local v_u_144 = 0
	local v_u_145 = (-1 / 0)
	local v_u_146 = false
	local v_u_147 = 0
	v_u_139.sent = {}
	v_u_139.toasts = {}
	v_u_139.ov = {}
	v_u_139.mode = v_u_128
	local v_u_148 = v_u_122.new("Frame", {
		["Name"] = "HuntTile",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["ClipsDescendants"] = true,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_116,
		["Size"] = UDim2.fromOffset(v_u_130.w, v_u_130.h),
		["LayoutOrder"] = p120
	}, p_u_119)
	v_u_139.frame = v_u_148
	local v149 = v_u_122.new("Frame", {
		["Name"] = "Fallback",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 1,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_148)
	v_u_122.new("UIGradient", {
		["Color"] = nil,
		["Rotation"] = 35,
		["Color"] = ColorSequence.new(v_u_116, v_u_117)
	}, v149)
	local v_u_150 = v_u_122.new("ImageLabel", {
		["Name"] = "Art",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ScaleType"] = nil,
		["Image"] = "",
		["ImageTransparency"] = 0.98,
		["Visible"] = false,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1),
		["ScaleType"] = Enum.ScaleType.Crop
	}, v_u_148)
	local v151 = v_u_122.new("Frame", {
		["Name"] = "ShadeLeft",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = Color3.fromRGB(6, 3, 10),
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_148)
	v_u_122.new("UIGradient", {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.05),
			NumberSequenceKeypoint.new(0.5, 0.3),
			NumberSequenceKeypoint.new(0.8, 0.55),
			NumberSequenceKeypoint.new(1, 0.75)
		})
	}, v151)
	local v152 = v_u_122.new("Frame", {
		["Name"] = "ShadeBottom",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = Color3.fromRGB(6, 3, 10),
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_148)
	v_u_122.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.3, 0.78),
			NumberSequenceKeypoint.new(0.55, 0.45),
			NumberSequenceKeypoint.new(1, 0.08)
		})
	}, v152)
	local v153 = v_u_122.new("Frame", {
		["Name"] = "Rim",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_148)
	local v_u_154 = v_u_122.stroke(v153, v_u_114, 2)
	local function v161(p155, p156, p157, p158, p159) -- name: row
		-- upvalues: (ref) v_u_130, (copy) v_u_122, (copy) v_u_148
		local v160 = v_u_130[p155:lower()] or v_u_130.title
		return v_u_122.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = nil,
			["color"] = nil,
			["textSize"] = nil,
			["position"] = nil,
			["size"] = nil,
			["wrap"] = nil,
			["valign"] = nil,
			["fitWrap"] = false,
			["track"] = false,
			["zindex"] = 6,
			["parent"] = v_u_148,
			["name"] = p155,
			["text"] = p156,
			["style"] = p157,
			["color"] = p158,
			["textSize"] = v160.size,
			["position"] = UDim2.fromOffset(0, 0),
			["size"] = UDim2.fromOffset(10, 10),
			["wrap"] = p159 == true,
			["valign"] = p159 and "top" or nil
		})
	end
	local v_u_162 = v161("Tag", v_u_126.MODE.tag, "caps", v_u_114)
	local v_u_163 = v161("Title", v_u_126.MODE.name, "h2", v_u_124.text)
	local v_u_164 = v161("Blurb", v_u_126.MODE.blurb, "small", v_u_124.text2, true)
	local v_u_165 = v161("Ends", v_u_126.TILE.endsDays, "bodyStrong", v_u_115)
	local v_u_166 = v161("Status", "", "bodyStrong", v_u_124.text, true)
	v_u_166.TextTruncate = Enum.TextTruncate.None
	local v_u_167 = v_u_122.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["textSize"] = 12,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["zindex"] = 6,
		["visible"] = false,
		["parent"] = v_u_148,
		["color"] = v_u_124.text2,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.fromOffset(10, 14)
	})
	v_u_163.TextTruncate = Enum.TextTruncate.AtEnd
	v_u_165.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_168 = v161("Probe", "A", "bodyStrong", v_u_124.text, true)
	v_u_168.TextTransparency = 1
	v_u_168.ZIndex = 1
	v_u_168.Active = false
	local v_u_169, v_u_170 = v_u_122.button({
		["parent"] = nil,
		["text"] = nil,
		["kind"] = "primary",
		["size"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_148,
		["text"] = v_u_126.MODE.join,
		["size"] = UDim2.fromOffset(100, 34),
		["position"] = UDim2.fromOffset(0, 0),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_139
			v_u_139.press()
		end
	})
	v_u_169.Name = "Main"
	v_u_169.ZIndex = 8
	local v_u_171 = v_u_122.new("TextButton", {
		["Name"] = "Tap",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 10,
		["Selectable"] = true,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_148)
	v_u_171.SelectionImageObject = v_u_122.selectionImage()
	v_u_171.Activated:Connect(function()
		-- upvalues: (copy) v_u_139
		v_u_139.press()
	end)
	local v_u_172 = v_u_122.new("Frame", {
		["Name"] = "Pill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_114,
		["Position"] = UDim2.fromOffset(0, 0),
		["Size"] = UDim2.fromOffset(100, 16)
	}, v_u_148)
	local v_u_173 = v_u_122.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "h3",
		["color"] = nil,
		["textSize"] = 12,
		["align"] = "center",
		["size"] = nil,
		["track"] = false,
		["zindex"] = 8,
		["parent"] = v_u_172,
		["text"] = v_u_126.TILE.joinShort,
		["color"] = Color3.fromRGB(24, 10, 4),
		["size"] = UDim2.fromScale(1, 1)
	})
	local v_u_174 = v_u_122.new("TextButton", {
		["Name"] = "HowTo",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Selectable"] = true,
		["Visible"] = false,
		["ZIndex"] = 8,
		["BackgroundColor3"] = v_u_116,
		["Size"] = UDim2.fromOffset(80, 32)
	}, v_u_148)
	v_u_122.stroke(v_u_174, v_u_115, 1)
	v_u_174.SelectionImageObject = v_u_122.selectionImage()
	local v_u_175 = v_u_122.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "h3",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["textSize"] = 12,
		["size"] = nil,
		["position"] = nil,
		["track"] = false,
		["zindex"] = 9,
		["parent"] = v_u_174,
		["text"] = v_u_126.HOWTO.button,
		["color"] = v_u_115,
		["size"] = UDim2.new(1, -8, 1, 0),
		["position"] = UDim2.fromOffset(4, 0)
	})
	local v_u_176 = v_u_122.new("TextButton", {
		["Name"] = "HowToTap",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Selectable"] = true,
		["Visible"] = false,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromOffset(44, 34)
	}, v_u_148)
	v_u_176.SelectionImageObject = v_u_122.selectionImage()
	local v_u_177 = v_u_122.new("Frame", {
		["Name"] = "Badge",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 12,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -6, 0, 4),
		["Size"] = UDim2.fromOffset(22, 22),
		["BackgroundColor3"] = v_u_114
	}, v_u_176)
	v_u_122.new("UICorner", {
		["CornerRadius"] = UDim.new(1, 0)
	}, v_u_177)
	v_u_122.label({
		["parent"] = nil,
		["name"] = "Mark",
		["text"] = nil,
		["style"] = "h3",
		["color"] = nil,
		["align"] = "center",
		["textSize"] = 14,
		["size"] = nil,
		["track"] = false,
		["zindex"] = 13,
		["parent"] = v_u_177,
		["text"] = v_u_126.HOWTO.buttonTiny,
		["color"] = Color3.fromRGB(24, 10, 4),
		["size"] = UDim2.fromScale(1, 1)
	})
	v_u_174.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_174
		v_u_174.BackgroundTransparency = 0.05
	end)
	v_u_174.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_174
		v_u_174.BackgroundTransparency = 0.3
	end)
	local v_u_178 = {}
	local v_u_179 = 0
	local function v_u_188(p180) -- name: lineH
		-- upvalues: (copy) v_u_148, (copy) v_u_123, (copy) v_u_178, (copy) v_u_168
		local v181 = v_u_148.AbsoluteSize.X
		local v182 = v_u_148.Size.X.Offset
		local v183
		if v181 > 0 and v182 > 0 then
			v183 = v181 / v182
		else
			local v184 = v_u_123.uiScale()
			v183 = math.max(v184, 0.01)
		end
		local v185 = "one|" .. p180 .. "|" .. v183
		local v186 = v_u_178[v185]
		if v186 == nil then
			v_u_168.TextSize = p180
			v_u_168.Size = UDim2.fromOffset(400, 400)
			v_u_168.Text = string.rep("A", 1)
			v186 = v_u_168.TextBounds.Y / v183
			if v186 <= 0 then
				local v187 = p180 * 1.2
				v186 = math.ceil(v187)
			end
			v_u_178[v185] = v186
		end
		return v186
	end
	local function v_u_212(p189, p190, p191) -- name: linesOf
		-- upvalues: (copy) v_u_148, (copy) v_u_123, (copy) v_u_178, (copy) v_u_188, (copy) v_u_168, (ref) v_u_179
		local v192 = "|"
		local v193 = "|"
		local v194 = v_u_148.AbsoluteSize.X
		local v195 = v_u_148.Size.X.Offset
		local v196
		if v194 > 0 and v195 > 0 then
			v196 = v194 / v195
		else
			local v197 = v_u_123.uiScale()
			v196 = math.max(v197, 0.01)
		end
		local v198 = p191 .. v192 .. p190 .. v193 .. v196 .. "|" .. p189
		local v199 = v_u_178[v198]
		if v199 == nil then
			local v200 = v_u_188(p191)
			v_u_168.TextSize = p191
			v_u_168.Size = UDim2.fromOffset(p190, 400)
			v_u_168.Text = p189
			local v201 = v_u_168.TextBounds.Y
			local v202 = v_u_148.AbsoluteSize.X
			local v203 = v_u_148.Size.X.Offset
			local v204
			if v202 > 0 and v203 > 0 then
				v204 = v202 / v203
			else
				local v205 = v_u_123.uiScale()
				v204 = math.max(v205, 0.01)
			end
			local v206 = v201 / v204
			local v207
			if v206 > 0 then
				local v208 = v206 / v200 + 0.5
				local v209 = math.floor(v208)
				v207 = math.max(1, v209)
			else
				local v210 = #p189 * p191 * 0.55 / math.max(p190, 1)
				local v211 = math.ceil(v210)
				v207 = math.max(1, v211)
			end
			v199 = math.min(v207, 12)
			v_u_179 = v_u_179 + 1
			if v_u_179 > 300 then
				table.clear(v_u_178)
				v_u_179 = 0
			end
			v_u_178[v198] = v199
		end
		return v199
	end
	local function v_u_217(p213, p214) -- name: statusFor
		-- upvalues: (ref) v_u_26, (copy) v_u_126
		if p214.status == "" then
			return ""
		else
			local v215 = v_u_26[p213]
			if p213 == "slim" then
				if p214.state == "searching" then
					if p214.squad then
						return v_u_126.format(v_u_126.TILE.slimSquad, p214.clock)
					else
						return v_u_126.format(v_u_126.TILE.slimSearching, p214.clock)
					end
				elseif p214.state == "found" then
					return v_u_126.TILE.slimFound
				elseif p214.state == "blocked" then
					if p214.locked == true then
						if p214.lockKind == "age" then
							return v_u_126.format(v_u_126.TILE.slimAgeLocked, p214.lockHave, p214.lockNeed)
						else
							return v_u_126.format(v_u_126.TILE.slimLocked, p214.lockHave, p214.lockNeed)
						end
					else
						return v_u_126.TILE.slimBlocked
					end
				else
					return v_u_126.TILE.slimGaveUp
				end
			else
				if v215.count ~= nil or (v215.small or p214.count == "") then
					return p214.status
				end
				local v216 = string.match(p214.count, "^(%d+ %a+ %d+)")
				return v_u_126.format(v_u_126.TILE.statusCount, p214.status, v216 or p214.count)
			end
		end
	end
	local function v_u_275(p218, p219) -- name: plan
		-- upvalues: (ref) v_u_26, (copy) v_u_131, (copy) v_u_123, (copy) v_u_212, (copy) v_u_188, (ref) v_u_4
		local v220 = v_u_26[p218]
		local v221
		if v220.small and v_u_131 then
			v221 = v_u_131
		else
			v221 = v220.w
		end
		local v222 = v220.pad
		local v223 = {
			["kind"] = nil,
			["w"] = nil,
			["pad"] = nil,
			["innerW"] = nil,
			["titleOn"] = true,
			["endsOn"] = true,
			["statusLines"] = 1,
			["kind"] = p218,
			["w"] = v221,
			["pad"] = v222,
			["innerW"] = v221 - v222 * 2
		}
		if v220.small then
			local v224 = v220.title.size
			local v225 = v_u_123.phoneText(v224, "text")
			local v226 = v220.ends.size
			local v227 = v_u_123.phoneText(v226, "text")
			local v228 = v220.status.size
			local v229 = v_u_123.phoneText(v228, "text")
			local v230 = v_u_123.phoneText(12, "text")
			local v231 = v225 * 1.2
			local v232 = math.ceil(v231)
			local v233 = v227 * 1.2
			local v234 = math.ceil(v233)
			local v235 = v230 * 1.2
			local v236 = math.ceil(v235) + 2
			v223.sizes = {
				["title"] = v225,
				["ends"] = v227,
				["status"] = v229,
				["pill"] = v230
			}
			if p218 == "slim" then
				local v237 = v220.title.size
				local v238 = v_u_123.phoneText(v237, "caption")
				local v239 = v_u_123.phoneText(10, "caption")
				local v240 = math.max(v238, v239) * 1.2
				local v241 = math.ceil(v240)
				v223.sizes = {
					["title"] = v238,
					["ends"] = v238,
					["status"] = v238,
					["pill"] = v239
				}
				v223.endsOn = false
				v223.head = p219
				v223.pillW = v220.pillW
				v223.titleY = 4
				v223.titleH = v241
				local v242 = v223.innerW - v220.pillW - 4
				v223.endsY = 4
				v223.endsH = v241
				v223.endsW = v242
				v223.innerTitleW = v223.innerW - v220.pillW - 4
				v223.btnY = 4
				v223.btnH = v241
				local v243 = v221 - v222 - v220.pillW
				local v244 = v220.pillW
				v223.btnX = v243
				v223.btnW = v244
				v223.h = v241 + 8
				if v220.how ~= nil and (v220.how.slim and p219 == "") then
					v223.howW = v220.how.w
					v223.howX = v223.btnX - v220.how.gap - v220.how.w
					v223.innerTitleW = v223.howX - v222 - 2
				end
			else
				v223.endsW = v223.innerW
				v223.titleY = 3
				v223.titleH = v232
				if v220.how ~= nil and v220.how.corner then
					v223.innerTitleW = v223.innerW - v220.how.gap
					local v245 = v220.how.w
					local v246 = v_u_123.touch
					local v247 = v220.how.w
					v223.howW = math.max(v245, v246(v247))
				end
				local v248 = v232 + 3 + 1
				v223.endsY = v248
				v223.endsH = v234
				local v249 = p219 == "" and 1 or v_u_212(p219, v223.innerW, v229)
				v223.statusLines = v249
				local v250 = v249 * v_u_188(v229)
				v223.statusH = math.ceil(v250)
				if p219 ~= "" then
					v223.endsOn = false
					if v249 > 1 then
						v223.titleOn = false
						v223.statusY = 3
					else
						v223.statusY = v248
						v223.statusH = v234
					end
				end
				local v251
				if p219 == "" or v249 <= 1 then
					v251 = v248 + v234 + 3
				else
					v251 = 3 + v223.statusH + 3
				end
				v223.btnY = v251
				v223.btnH = v236
				local v252 = v223.innerW
				v223.btnX = v222
				v223.btnW = v252
				if v220.how ~= nil and v220.how.corner then
					v223.btnW = v223.innerW - (v223.howW - v222) - 3
				end
				v223.h = v251 + v236 + 4
			end
			v223.statusY = v223.statusY or v223.endsY
			v223.statusH = v223.statusH or v234
			return v223
		end
		local v253 = v220.h
		local v254 = v220.title.y
		local v255 = v220.title.h
		local v256 = v220.ends.y
		local v257 = v220.ends.h
		local v258 = v223.innerW
		v223.h = v253
		v223.titleY = v254
		v223.titleH = v255
		v223.endsY = v256
		v223.endsH = v257
		v223.endsW = v258
		local v259 = v220.status.y
		local v260 = v220.status.h
		local v261 = v220.btn.y
		local v262 = v220.btn.h
		local v263 = v223.innerW
		v223.statusY = v259
		v223.statusH = v260
		v223.btnY = v261
		v223.btnH = v262
		v223.btnX = v222
		v223.btnW = v263
		local v264 = v_u_4.touchExtra(p218, v_u_123.touch(v220.btn.h))
		v223.btnH = v223.btnH + v264
		v223.h = v223.h + v264
		if v220.how ~= nil and not v220.how.corner then
			v223.btnW = v223.innerW - v220.how.w - v220.how.gap
			local v265 = v222 + v223.btnW + v220.how.gap
			local v266 = v220.how.w
			v223.howX = v265
			v223.howW = v266
		end
		local v267 = {
			["title"] = nil,
			["ends"] = nil,
			["status"] = nil,
			["pill"] = 12
		}
		local v268 = v220.title.size
		v267.title = v_u_123.phoneText(v268, "text")
		local v269 = v220.ends.size
		v267.ends = v_u_123.phoneText(v269, "text")
		local v270 = v220.status.size
		v267.status = v_u_123.phoneText(v270, "text")
		v223.sizes = v267
		if p219 ~= "" then
			local v271 = v_u_212(p219, v223.innerW, v223.sizes.status)
			v223.statusLines = v271
			local v272 = v271 * v_u_188(v223.sizes.status)
			local v273 = math.ceil(v272)
			if v271 > 1 and v220.status.h < v273 then
				local v274 = v273 - v220.status.h
				v223.statusH = v273
				v223.btnY = v223.btnY + v274
				v223.h = v223.h + v274
				if v220.ends.y > v220.status.y then
					v223.endsY = v223.endsY + v274
				end
				if v220.count ~= nil and v220.count.y > v220.status.y then
					v223.countY = v220.count.y + v274
				end
			end
		end
		return v223
	end
	local v_u_276 = v_u_275(v_u_128, "")
	local v_u_277 = ""
	local v_u_278 = nil
	local function v_u_354(p279, p280, _) -- name: applyPlan
		-- upvalues: (ref) v_u_26, (copy) v_u_148, (copy) v_u_162, (copy) v_u_123, (copy) v_u_163, (copy) v_u_164, (copy) v_u_165, (copy) v_u_166, (copy) v_u_167, (copy) v_u_169, (copy) v_u_171, (copy) v_u_172, (copy) v_u_173, (copy) v_u_174, (copy) v_u_176, (copy) v_u_175, (copy) v_u_126, (copy) v_u_122, (copy) v_u_177, (copy) p_u_121
		local v281 = v_u_26[p279.kind]
		local v282 = p279.pad
		v_u_148.Size = UDim2.fromOffset(p279.w, p279.h)
		v_u_162.Visible = not v281.tag.hidden
		local v283 = v_u_162
		local v284 = v281.tag.y
		local v285 = p279.innerW
		local v286 = v281.tag.h
		v283.Position = UDim2.fromOffset(v282, v284)
		v283.Size = UDim2.fromOffset(v285, v286)
		local v287 = v_u_162
		local v288 = v281.tag.size
		v287.TextSize = v_u_123.phoneText(v288, "caption")
		v_u_163.Visible = p279.titleOn
		local v289 = v_u_163
		local v290 = p279.titleY
		local v291 = p279.innerTitleW or p279.innerW
		local v292 = p279.titleH
		v289.Position = UDim2.fromOffset(v282, v290)
		v289.Size = UDim2.fromOffset(v291, v292)
		v_u_163.TextSize = p279.sizes.title
		local v293 = v_u_164
		local v294 = v281.blurb.y
		local v295 = p279.innerW
		local v296 = v281.blurb.h
		v293.Position = UDim2.fromOffset(v282, v294)
		v293.Size = UDim2.fromOffset(v295, v296)
		v_u_165.Visible = p279.endsOn
		local v297 = v_u_165
		local v298 = p279.endsY
		local v299 = p279.endsW
		local v300 = p279.endsH
		v297.Position = UDim2.fromOffset(v282, v298)
		v297.Size = UDim2.fromOffset(v299, v300)
		v_u_165.TextSize = p279.sizes.ends
		local v301 = v_u_166
		local v302 = p279.statusY
		local v303 = p279.innerW
		local v304 = p279.statusH
		v301.Position = UDim2.fromOffset(v282, v302)
		v301.Size = UDim2.fromOffset(v303, v304)
		v_u_166.TextSize = p279.sizes.status
		local v305 = v_u_167
		local v306 = p279.countY
		if not v306 then
			if v281.count then
				v306 = v281.count.y
			else
				v306 = v281.status.y + 16
			end
		end
		local v307 = p279.innerW
		local v308 = not v281.count and 14 or v281.count.h
		v305.Position = UDim2.fromOffset(v282, v306)
		v305.Size = UDim2.fromOffset(v307, v308)
		local v309 = p280.soon == true
		local v310 = v_u_169
		local v311 = not v281.small
		if v311 then
			v311 = not v309
		end
		v310.Visible = v311
		local v312 = v_u_171
		local v313
		if v281.small == true then
			v313 = not v309
		else
			v313 = false
		end
		v312.Visible = v313
		v_u_172.Visible = v281.small == true and true or v309
		if v281.small or v309 then
			local v314 = v_u_172
			local v315 = p279.btnX
			local v316 = p279.btnY
			local v317 = p279.btnW
			local v318 = p279.btnH
			v314.Position = UDim2.fromOffset(v315, v316)
			v314.Size = UDim2.fromOffset(v317, v318)
			v_u_173.TextSize = not v281.small and 15 or p279.sizes.pill
		else
			local v319 = v_u_169
			local v320 = p279.btnX
			local v321 = p279.btnY
			local v322 = p279.btnW
			local v323 = p279.btnH
			v319.Position = UDim2.fromOffset(v320, v321)
			v319.Size = UDim2.fromOffset(v322, v323)
		end
		local v324 = v281.how
		local v325 = v324 ~= nil and not v324.corner
		if v325 then
			v325 = not v324.slim
		end
		v_u_174.Visible = v325
		local v326 = v_u_176
		local v327
		if v324 == nil then
			v327 = false
		elseif v324.corner == true then
			v327 = true
		elseif v324.slim == true then
			v327 = p279.howX ~= nil
		else
			v327 = false
		end
		v326.Visible = v327
		if v325 then
			local v328 = v_u_174
			local v329 = p279.howX
			local v330 = p279.btnY
			local v331 = p279.howW
			local v332 = p279.btnH
			v328.Position = UDim2.fromOffset(v329, v330)
			v328.Size = UDim2.fromOffset(v331, v332)
			local v333 = v_u_175
			local v334 = v324.size
			v333.TextSize = v_u_123.phoneText(v334, "text")
			local v335
			if v324.long then
				v335 = v_u_126.HOWTO.button
			else
				v335 = v_u_126.HOWTO.buttonShort
			end
			if v_u_175:GetAttribute("HushShown") ~= v335 then
				v_u_175:SetAttribute("HushShown", v335)
				v_u_122.setText(v_u_175, v335)
			end
		elseif v324 == nil or not v324.corner then
			if v324 ~= nil and p279.howX ~= nil then
				local v336 = v_u_176
				local v337 = p279.howX
				local v338 = p279.howW
				local v339 = p279.h
				v336.Position = UDim2.fromOffset(v337, 0)
				v336.Size = UDim2.fromOffset(v338, v339)
				v_u_177.AnchorPoint = Vector2.new(0.5, 0.5)
				v_u_177.Position = UDim2.fromScale(0.5, 0.5)
				local v340 = v_u_177
				local v341 = UDim2.fromOffset
				local v342 = p279.h - 6
				local v343 = math.min(18, v342)
				local v344 = p279.h - 6
				v340.Size = v341(v343, (math.min(18, v344)))
			end
		else
			local v345 = v_u_176
			local v346 = p279.w - p279.howW
			local v347 = p279.howW
			local v348 = p279.h
			local v349 = v324.h
			local v350 = math.max(v348, v349)
			v345.Position = UDim2.fromOffset(v346, 0)
			v345.Size = UDim2.fromOffset(v347, v350)
			v_u_177.AnchorPoint = Vector2.new(1, 0)
			v_u_177.Position = UDim2.new(1, -6, 0, 4)
			v_u_177.Size = UDim2.fromOffset(22, 22)
		end
		local v351 = p_u_121
		if type(v351) == "table" and p_u_121.splitTap == true then
			local v352 = v_u_171
			local v353
			if v324 == nil or (v324.corner ~= true or p279.howW == nil) then
				v353 = UDim2.fromScale(1, 1)
			else
				v353 = UDim2.new(1, -p279.howW, 1, 0)
			end
			v352.Size = v353
		end
	end
	local function v_u_355() -- name: soonNow
		-- upvalues: (copy) v_u_139, (ref) v_u_4, (copy) v_u_125
		if v_u_139.ov.soon == nil then
			return v_u_4.liveSoon(v_u_125)
		else
			return v_u_139.ov.soon == true
		end
	end
	function v_u_139.isOpen()
		-- upvalues: (ref) v_u_140, (ref) v_u_4, (copy) v_u_127, (copy) v_u_139, (copy) v_u_125, (ref) v_u_1, (ref) v_u_3, (copy) v_u_355, (copy) v_u_126, (ref) v_u_143
		local v356 = v_u_140
		if v356 then
			local v357 = v_u_4.visible
			local v358 = v_u_127
			local v359
			if v_u_139.ov.flag == nil then
				local function v360()
					-- upvalues: (ref) v_u_125
					return v_u_125.config.flag("HalloweenHunt")
				end
				local v361
				v361, v359 = pcall(v360)
				if not v361 then
					v359 = nil
				end
			else
				v359 = v_u_139.ov.flag
			end
			local v362
			if v_u_139.ov.now == nil then
				v362 = v_u_1.now()
			else
				v362 = v_u_139.ov.now
			end
			local function v363()
				-- upvalues: (ref) v_u_125
				return v_u_125.config.HUNT_END_UTC
			end
			local v364, v365 = pcall(v363)
			local v366 = v_u_127.endUtc
			if not v364 then
				v365 = nil
			end
			local v367 = v366(v365)
			local v368
			if v_u_139.ov.placeId == nil then
				v368 = v_u_4.livePlaceId(v_u_125)
			else
				v368 = v_u_139.ov.placeId
			end
			local v369
			if v_u_139.ov.studio == nil then
				v369 = v_u_3:IsStudio()
			else
				v369 = v_u_139.ov.studio
			end
			v356 = v357(v358, v359, v362, v367, v368, v369, v_u_355())
			if v356 then
				v356 = v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355()).state ~= "over"
			end
		end
		return v356
	end
	local function v_u_374(p_u_370) -- name: send
		-- upvalues: (copy) v_u_139, (copy) v_u_125
		local v371 = v_u_139.sent
		table.insert(v371, p_u_370)
		if #v_u_139.sent > 20 then
			table.remove(v_u_139.sent, 1)
		end
		local function v373()
			-- upvalues: (ref) v_u_125, (copy) p_u_370
			local v372 = {
				["op"] = p_u_370
			}
			v_u_125.net.fire("hunt.op", v372)
		end
		pcall(v373)
	end
	local v_u_375 = nil
	if v_u_5 ~= nil then
		if v_u_5.isOpen() then
			v_u_375 = v_u_5
		end
		v_u_5 = nil
	end
	local v_u_376 = false
	v_u_139.howSent = 0
	local function v_u_384() -- name: markHowSeen
		-- upvalues: (copy) v_u_125, (copy) p_u_118
		local function v377()
			-- upvalues: (ref) v_u_125
			return v_u_125.lib.HuntHowTo
		end
		local v378, v_u_379 = pcall(v377)
		if not v378 then
			v_u_379 = nil
		end
		local v380 = p_u_118.profile
		if v_u_379 ~= nil and type(v380) == "table" then
			local v381 = v380.settings
			if type(v381) == "table" and not v_u_379.seenIn(v380.settings[v_u_379.SEEN_KEY]) then
				local v_u_382 = v_u_379.seenValue(v380.settings[v_u_379.SEEN_KEY])
				if v_u_382 ~= nil then
					v380.settings[v_u_379.SEEN_KEY] = v_u_382
					local function v383()
						-- upvalues: (ref) p_u_118, (copy) v_u_379, (copy) v_u_382
						p_u_118.op({
							["op"] = "setting",
							["key"] = nil,
							["value"] = nil,
							["key"] = v_u_379.SEEN_KEY,
							["value"] = v_u_382
						})
					end
					pcall(v383)
				end
			end
		end
	end
	function v_u_139.openHowTo(p385) -- name: openHowTo
		-- upvalues: (ref) v_u_140, (copy) v_u_139, (copy) v_u_125, (ref) v_u_375, (copy) v_u_122, (copy) v_u_123, (copy) v_u_126, (copy) v_u_127, (copy) v_u_384
		if v_u_140 then
			local v386 = v_u_139
			v386.howSent = v386.howSent + 1
			local v387 = v_u_139.ov.onHowTo
			if type(v387) == "function" then
				v_u_139.ov.onHowTo(p385 == true)
				return
			else
				local function v388()
					-- upvalues: (ref) v_u_125
					return v_u_125.lib.HuntHowTo
				end
				local v389, v390 = pcall(v388)
				if not v389 then
					v390 = nil
				end
				if v390 ~= nil and (v_u_375 == nil or not v_u_375.isOpen()) then
					local function v391()
						-- upvalues: (ref) v_u_125
						return v_u_125.shared.HuntRewards
					end
					local v392, v393 = pcall(v391)
					local v394 = v390.open
					local v395 = {
						["UI"] = nil,
						["Theme"] = nil,
						["Names"] = nil,
						["Rules"] = nil,
						["Rewards"] = nil,
						["blur"] = true,
						["onClose"] = nil,
						["UI"] = v_u_122,
						["Theme"] = v_u_123,
						["Names"] = v_u_126,
						["Rules"] = v_u_127
					}
					if not v392 then
						v393 = nil
					end
					v395.Rewards = v393
					function v395.onClose() -- name: onClose
						-- upvalues: (ref) v_u_375
						v_u_375 = nil
					end
					local v396, v397 = pcall(v394, v395)
					if v396 then
						v_u_375 = v397
						v_u_384()
					end
				end
			end
		else
			return
		end
	end
	v_u_174.Activated:Connect(function()
		-- upvalues: (copy) v_u_122, (copy) v_u_139
		v_u_122.sound("click")
		v_u_139.openHowTo(false)
	end)
	v_u_176.Activated:Connect(function()
		-- upvalues: (copy) v_u_122, (copy) v_u_139
		v_u_122.sound("click")
		v_u_139.openHowTo(false)
	end)
	function v_u_139.state() -- name: state
		-- upvalues: (ref) v_u_4, (copy) v_u_127, (copy) v_u_139, (copy) v_u_125, (ref) v_u_1, (ref) v_u_3, (copy) v_u_355, (copy) v_u_126, (ref) v_u_143
		local v398 = v_u_4.visible
		local v399 = v_u_127
		local v400
		if v_u_139.ov.flag == nil then
			local function v401()
				-- upvalues: (ref) v_u_125
				return v_u_125.config.flag("HalloweenHunt")
			end
			local v402
			v402, v400 = pcall(v401)
			if not v402 then
				v400 = nil
			end
		else
			v400 = v_u_139.ov.flag
		end
		local v403
		if v_u_139.ov.now == nil then
			v403 = v_u_1.now()
		else
			v403 = v_u_139.ov.now
		end
		local function v404()
			-- upvalues: (ref) v_u_125
			return v_u_125.config.HUNT_END_UTC
		end
		local v405, v406 = pcall(v404)
		local v407 = v_u_127.endUtc
		if not v405 then
			v406 = nil
		end
		local v408 = v407(v406)
		local v409
		if v_u_139.ov.placeId == nil then
			v409 = v_u_4.livePlaceId(v_u_125)
		else
			v409 = v_u_139.ov.placeId
		end
		local v410
		if v_u_139.ov.studio == nil then
			v410 = v_u_3:IsStudio()
		else
			v410 = v_u_139.ov.studio
		end
		return not v398(v399, v400, v403, v408, v409, v410, v_u_355()) and "over" or v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355()).state
	end
	function v_u_139.view() -- name: view
		-- upvalues: (ref) v_u_4, (copy) v_u_126, (ref) v_u_143, (copy) v_u_355
		return v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355())
	end
	function v_u_139.paint() -- name: paint
		-- upvalues: (ref) v_u_140, (ref) v_u_4, (copy) v_u_127, (copy) v_u_139, (copy) v_u_125, (ref) v_u_1, (ref) v_u_3, (copy) v_u_355, (copy) v_u_126, (ref) v_u_143, (copy) v_u_148, (ref) v_u_146, (copy) v_u_150, (copy) v_u_217, (ref) v_u_128, (copy) v_u_275, (ref) v_u_26, (ref) v_u_276, (ref) v_u_278, (copy) v_u_354, (copy) v_u_165, (copy) v_u_122, (copy) v_u_167, (copy) v_u_163, (ref) v_u_115, (copy) v_u_124, (copy) v_u_166, (copy) v_u_164, (copy) v_u_170, (copy) v_u_173, (copy) v_u_172, (ref) v_u_114, (ref) v_u_144, (copy) v_u_171, (ref) v_u_277, (copy) v_u_133
		if v_u_140 then
			local v411 = v_u_4.visible
			local v412 = v_u_127
			local v413
			if v_u_139.ov.flag == nil then
				local function v414()
					-- upvalues: (ref) v_u_125
					return v_u_125.config.flag("HalloweenHunt")
				end
				local v415
				v415, v413 = pcall(v414)
				if not v415 then
					v413 = nil
				end
			else
				v413 = v_u_139.ov.flag
			end
			local v416
			if v_u_139.ov.now == nil then
				v416 = v_u_1.now()
			else
				v416 = v_u_139.ov.now
			end
			local function v417()
				-- upvalues: (ref) v_u_125
				return v_u_125.config.HUNT_END_UTC
			end
			local v418, v419 = pcall(v417)
			local v420 = v_u_127.endUtc
			if not v418 then
				v419 = nil
			end
			local v421 = v420(v419)
			local v422
			if v_u_139.ov.placeId == nil then
				v422 = v_u_4.livePlaceId(v_u_125)
			else
				v422 = v_u_139.ov.placeId
			end
			local v423
			if v_u_139.ov.studio == nil then
				v423 = v_u_3:IsStudio()
			else
				v423 = v_u_139.ov.studio
			end
			local v424 = v411(v412, v413, v416, v421, v422, v423, v_u_355())
			local v425 = v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355())
			if v424 then
				v424 = v425.state ~= "over"
			end
			if v_u_148.Visible ~= v424 then
				v_u_148.Visible = v424
			end
			v_u_146 = v424
			if v424 then
				local v426
				if v_u_139.ov.art == nil then
					local v427 = v_u_126.ART
					if type(v427) == "table" then
						local v428 = v_u_126.ART.tile
						v426 = type(v428) ~= "string" and "" or v_u_126.ART.tile
					else
						v426 = ""
					end
				else
					v426 = v_u_139.ov.art
				end
				if v_u_150.Image ~= v426 then
					v_u_150.Image = v426
				end
				local v429 = v426 ~= ""
				if v_u_150.Visible ~= v429 then
					v_u_150.Visible = v429
				end
				local v430 = v429 and v_u_150.IsLoaded and 0 or 0.98
				if v_u_150.ImageTransparency ~= v430 then
					v_u_150.ImageTransparency = v430
				end
				local v431 = v_u_217(v_u_128, v425)
				local v432 = v_u_275(v_u_128, v431)
				local v433 = v_u_26[v432.kind]
				local v434 = v_u_276.h
				v_u_276 = v432
				v_u_278 = v425
				v_u_354(v432, v425, v431)
				local v435
				if v425.soon then
					v435 = v_u_126.MODE.opensSoon
				else
					local v436 = v_u_4.countdown
					local v437 = v_u_126
					local function v438()
						-- upvalues: (ref) v_u_125
						return v_u_125.config.HUNT_END_UTC
					end
					local v439, v440 = pcall(v438)
					local v441 = v_u_127.endUtc
					if not v439 then
						v440 = nil
					end
					local v442 = v441(v440)
					local v443
					if v_u_139.ov.now == nil then
						v443 = v_u_1.now()
					else
						v443 = v_u_139.ov.now
					end
					v435 = v436(v437, v442 - v443)
				end
				if v433.small and not v425.soon then
					v435 = string.gsub(v435, "^ENDS IN ", "")
				end
				local v444 = v_u_165
				if v444:GetAttribute("HushShown") ~= v435 then
					v444:SetAttribute("HushShown", v435)
					v_u_122.setText(v444, v435)
				end
				local v445 = v431 ~= ""
				if v433.count == nil then
					v_u_167.Visible = false
				else
					v_u_167.Visible = v425.count ~= ""
					if v425.count ~= "" then
						local v446 = v_u_167
						local v447 = v425.count
						if v446:GetAttribute("HushShown") ~= v447 then
							v446:SetAttribute("HushShown", v447)
							v_u_122.setText(v446, v447)
						end
					end
				end
				local v448
				if v432.kind == "slim" then
					v448 = v445
				else
					v448 = false
				end
				local v449 = v_u_163
				local v450
				if v448 then
					v450 = v431
				else
					v450 = v_u_126.MODE.name
				end
				if v449:GetAttribute("HushShown") ~= v450 then
					v449:SetAttribute("HushShown", v450)
					v_u_122.setText(v449, v450)
				end
				local v451 = v_u_163
				local v452
				if v448 and v425.state == "blocked" then
					v452 = v_u_115
				else
					v452 = v_u_124.text
				end
				v451.TextColor3 = v452
				local v453 = v_u_166
				local v454
				if v445 then
					v454 = not v448
				else
					v454 = v445
				end
				v453.Visible = v454
				if v445 and not v448 then
					local v455 = v_u_166
					if v455:GetAttribute("HushShown") ~= v431 then
						v455:SetAttribute("HushShown", v431)
						v_u_122.setText(v455, v431)
					end
					local v456 = v_u_166
					local v457
					if v425.state == "blocked" then
						v457 = v_u_115
					else
						v457 = v_u_124.text
					end
					v456.TextColor3 = v457
				end
				local v458 = v_u_164
				local v459 = not v433.blurb.hidden
				if v459 then
					v459 = not v445
				end
				v458.Visible = v459
				local v460 = v425.button
				local v461
				if v425.state == "searching" then
					v461 = v425.button
				elseif v425.state == "found" then
					v461 = v_u_126.TILE.foundShort
				elseif v425.soon then
					v461 = v_u_126.TILE.soonShort
				else
					v461 = v_u_126.TILE.joinShort
				end
				v_u_170.setText(v460)
				v_u_173.Text = v461
				local v462 = v425.kind
				v_u_170.setKind(v462)
				local v463 = v_u_172
				local v464
				if v462 == "close" then
					v464 = v_u_124.danger
				else
					v464 = v_u_114
				end
				v463.BackgroundColor3 = v464
				local v465 = v425.enabled
				if v465 then
					v465 = v_u_144 <= os.clock()
				end
				v_u_170.setEnabled(v465)
				v_u_172.BackgroundTransparency = v465 and 0 or 0.55
				v_u_171.Active = v465
				if v425.soon then
					v_u_172.BackgroundTransparency = 0
				end
				local v466 = v425.state .. "|" .. (v431 == "" and "i" or "s")
				local v467 = v466 ~= v_u_277
				v_u_277 = v466
				if (v432.h ~= v434 or v467) and v_u_133 then
					task.defer(v_u_133, v432.h)
				end
			end
		else
			return
		end
	end
	function v_u_139.heightFor(p468) -- name: heightFor
		-- upvalues: (ref) v_u_26, (ref) v_u_276, (ref) v_u_278, (ref) v_u_4, (copy) v_u_126, (ref) v_u_143, (copy) v_u_355, (copy) v_u_275, (copy) v_u_217
		if v_u_26[p468] == nil then
			return v_u_276.h
		else
			return v_u_275(p468, v_u_217(p468, v_u_278 or v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355()))).h
		end
	end
	local v_u_469 = ""
	local v_u_470 = 0
	function v_u_139.speaksSentence() -- name: speaksSentence
		-- upvalues: (ref) v_u_278, (ref) v_u_4, (copy) v_u_126, (ref) v_u_143, (copy) v_u_355, (ref) v_u_469, (ref) v_u_470
		local v471 = v_u_278 or v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355())
		local v472
		if v471.state == "blocked" or v471.state == "idle" then
			v472 = v471.status ~= ""
		else
			v472 = false
		end
		if not v472 then
			v_u_469 = ""
			return false
		end
		local v473 = os.clock()
		if v471.status ~= v_u_469 then
			v_u_469 = v471.status
			v_u_470 = v473
		end
		return v473 - v_u_470 < v_u_4.BLOCK_HOLD
	end
	function v_u_139.height() -- name: height
		-- upvalues: (ref) v_u_276
		return v_u_276.h
	end
	function v_u_139.plan() -- name: plan
		-- upvalues: (ref) v_u_276
		return v_u_276
	end
	v_u_139.probe = v_u_168
	function v_u_139.kind() -- name: kind
		-- upvalues: (ref) v_u_276
		return v_u_276.kind
	end
	function v_u_139.setKind(p474) -- name: setKind
		-- upvalues: (ref) v_u_140, (ref) v_u_26, (ref) v_u_128, (copy) v_u_128, (ref) v_u_130, (copy) v_u_139
		if v_u_140 and (v_u_26[p474] ~= nil and p474 ~= v_u_128) then
			if v_u_128 ~= "full" or p474 == "full" then
				v_u_128 = p474
				v_u_130 = v_u_26[p474]
				v_u_139.paint()
			end
		else
			return
		end
	end
	function v_u_139.press() -- name: press
		-- upvalues: (ref) v_u_144, (ref) v_u_4, (copy) v_u_127, (copy) v_u_139, (copy) v_u_125, (ref) v_u_1, (ref) v_u_3, (copy) v_u_355, (copy) v_u_126, (ref) v_u_143, (ref) v_u_136, (ref) v_u_135, (ref) v_u_138, (copy) v_u_374, (copy) v_u_122, (ref) v_u_140
		local v475 = os.clock()
		if v475 >= v_u_144 then
			local v476 = v_u_4.visible
			local v477 = v_u_127
			local v478
			if v_u_139.ov.flag == nil then
				local function v479()
					-- upvalues: (ref) v_u_125
					return v_u_125.config.flag("HalloweenHunt")
				end
				local v480
				v480, v478 = pcall(v479)
				if not v480 then
					v478 = nil
				end
			else
				v478 = v_u_139.ov.flag
			end
			local v481
			if v_u_139.ov.now == nil then
				v481 = v_u_1.now()
			else
				v481 = v_u_139.ov.now
			end
			local function v482()
				-- upvalues: (ref) v_u_125
				return v_u_125.config.HUNT_END_UTC
			end
			local v483, v484 = pcall(v482)
			local v485 = v_u_127.endUtc
			if not v483 then
				v484 = nil
			end
			local v486 = v485(v484)
			local v487
			if v_u_139.ov.placeId == nil then
				v487 = v_u_4.livePlaceId(v_u_125)
			else
				v487 = v_u_139.ov.placeId
			end
			local v488
			if v_u_139.ov.studio == nil then
				v488 = v_u_3:IsStudio()
			else
				v488 = v_u_139.ov.studio
			end
			if v476(v477, v478, v481, v486, v487, v488, v_u_355()) then
				local v489 = v_u_4.view(v_u_126, v_u_143, v475, v_u_355())
				if v489.enabled then
					v_u_144 = v475 + v_u_4.JOIN_LOCK
					v_u_136 = v475
					v_u_135 = 0
					v_u_138 = ""
					if v489.state == "searching" then
						v_u_374("cancel")
					else
						v_u_374("join")
					end
					v_u_122.sound("click")
					v_u_139.paint()
					task.delay(v_u_4.JOIN_LOCK + 0.05, function()
						-- upvalues: (ref) v_u_140, (ref) v_u_139
						if v_u_140 then
							v_u_139.paint()
						end
					end)
				end
			end
		end
	end
	function v_u_139.feed(p_u_490) -- name: feed
		-- upvalues: (ref) v_u_143, (ref) v_u_135, (ref) v_u_138, (ref) v_u_128, (copy) v_u_139, (ref) v_u_4, (copy) v_u_125, (copy) v_u_122, (copy) v_u_126, (ref) v_u_376, (ref) v_u_141, (copy) p_u_118, (ref) v_u_136, (ref) v_u_137, (copy) v_u_355
		if type(p_u_490) ~= "table" or p_u_490.k ~= "lobby" then
			return
		end
		local v491 = os.clock()
		if p_u_490.s == "idle" and (v_u_143 ~= nil and (v_u_143.s == "blocked" and v491 < v_u_135)) then
			return
		end
		v_u_143 = table.clone(p_u_490)
		v_u_143.at = v491
		if p_u_490.s == "queued" or p_u_490.s == "found" then
			v_u_138 = ""
		end
		if p_u_490.s == "idle" then
			local v492 = p_u_490.t
			if type(v492) == "string" and (p_u_490.t ~= "" and (v_u_128 == "slim" and v_u_138 ~= p_u_490.t)) then
				local v493
				if v_u_139.ov.soon == nil then
					v493 = v_u_4.liveSoon(v_u_125)
				else
					v493 = v_u_139.ov.soon == true
				end
				if not v493 then
					v_u_138 = p_u_490.t
					local v494 = v_u_139.toasts
					local v495 = p_u_490.t
					table.insert(v494, v495)
					if #v_u_139.toasts > 10 then
						table.remove(v_u_139.toasts, 1)
					end
					if v_u_139.ov.noToast ~= true then
						local function v496()
							-- upvalues: (ref) v_u_122, (ref) v_u_126, (copy) p_u_490
							v_u_122.toast(v_u_126.MODE.name, "warn", p_u_490.t, 6)
						end
						pcall(v496)
					end
				end
			end
		end
		if not v_u_376 and v_u_141 then
			local v497
			if v_u_139.ov.soon == nil then
				v497 = v_u_4.liveSoon(v_u_125)
			else
				v497 = v_u_139.ov.soon == true
			end
			if not v497 and (p_u_490.s == "queued" or p_u_490.s == "found") then
				local function v498()
					-- upvalues: (ref) v_u_125
					return v_u_125.lib.HuntHowTo
				end
				local v499, v500 = pcall(v498)
				if not v499 then
					v500 = nil
				end
				if v500 ~= nil then
					local v501 = v500.autoInLobby
					local v502 = {}
					local function v503()
						-- upvalues: (ref) v_u_125
						return v_u_125.lib.HuntHowTo
					end
					local v504, v505 = pcall(v503)
					if not v504 then
						v505 = nil
					end
					local v506 = p_u_118.profile
					local v507
					if v505 == nil or type(v506) ~= "table" then
						v507 = nil
					else
						local v508 = v506.settings
						if type(v508) == "table" then
							v507 = v505.seenIn(v506.settings[v505.SEEN_KEY])
						else
							v507 = nil
						end
					end
					v502.seen = v507
					v502.shown = v_u_376
					v502.state = p_u_490.s == "queued" and "searching" or "found"
					if v501(v502) then
						v_u_376 = true
						v_u_139.openHowTo(true)
					end
				end
			end
		end
		local v509
		if p_u_490.s == "blocked" then
			local v510, v511
			if p_u_490.r == "raidTime" then
				local v512 = p_u_490.rt
				if type(v512) == "table" then
					local v513 = p_u_490.rt.need
					if type(v513) == "number" and p_u_490.rt.need > 0 then
						v509 = true
					elseif p_u_490.r == "accountAge" then
						v510 = p_u_490.ad
						if type(v510) == "table" then
							v511 = p_u_490.ad.need
							if type(v511) == "number" then
								v509 = p_u_490.ad.need > 0
							else
								v509 = false
							end
						else
							v509 = false
						end
					else
						v509 = false
					end
				elseif p_u_490.r == "accountAge" then
					v510 = p_u_490.ad
					if type(v510) == "table" then
						v511 = p_u_490.ad.need
						if type(v511) == "number" then
							v509 = p_u_490.ad.need > 0
						else
							v509 = false
						end
					else
						v509 = false
					end
				else
					v509 = false
				end
			elseif p_u_490.r == "accountAge" then
				v510 = p_u_490.ad
				if type(v510) == "table" then
					v511 = p_u_490.ad.need
					if type(v511) == "number" then
						v509 = p_u_490.ad.need > 0
					else
						v509 = false
					end
				else
					v509 = false
				end
			else
				v509 = false
			end
		else
			v509 = false
		end
		if p_u_490.s == "blocked" and not v509 then
			local v514
			if v_u_139.ov.soon == nil then
				v514 = v_u_4.liveSoon(v_u_125)
			else
				v514 = v_u_139.ov.soon == true
			end
			if not v514 then
				v_u_135 = v491 + v_u_4.BLOCK_HOLD
				local v515
				if v491 - v_u_136 <= v_u_4.TOAST_WINDOW then
					v515 = v_u_137 ~= v_u_136
				else
					v515 = false
				end
				local v516
				if v_u_128 == "slim" then
					v516 = v_u_138 ~= v_u_4.view(v_u_126, v_u_143, v491, v_u_355()).status
				else
					v516 = false
				end
				if v515 or v516 then
					v_u_137 = v_u_136
					local v_u_517 = v_u_4.view(v_u_126, v_u_143, v491, v_u_355()).status
					v_u_138 = v_u_517
					local v518 = v_u_139.toasts
					table.insert(v518, v_u_517)
					if #v_u_139.toasts > 10 then
						table.remove(v_u_139.toasts, 1)
					end
					if v_u_139.ov.noToast ~= true then
						local function v519()
							-- upvalues: (ref) v_u_122, (ref) v_u_126, (copy) v_u_517
							v_u_122.toast(v_u_126.MODE.name, "warn", v_u_517, 6)
						end
						pcall(v519)
					end
				end
			end
		end
		v_u_139.paint()
	end
	function v_u_139.setActive(p520) -- name: setActive
		-- upvalues: (ref) v_u_140, (ref) v_u_141, (ref) v_u_145, (copy) v_u_374, (copy) v_u_139
		if v_u_140 and v_u_141 ~= p520 then
			v_u_141 = p520
			if p520 then
				v_u_145 = os.clock()
				v_u_374("state")
				v_u_139.paint()
			end
		end
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_125, (ref) v_u_140, (copy) v_u_139, (copy) v_u_142
		local function v522()
			-- upvalues: (ref) v_u_125, (ref) v_u_140, (ref) v_u_139
			return v_u_125.net.listen("hunt.state", function(p521)
				-- upvalues: (ref) v_u_140, (ref) v_u_139
				if v_u_140 then
					v_u_139.feed(p521)
				end
			end)
		end
		local v523, v524 = pcall(v522)
		if v523 and typeof(v524) == "RBXScriptConnection" then
			if v_u_140 then
				local v525 = v_u_142
				table.insert(v525, v524)
				return
			end
			v524:Disconnect()
		end
	end)
	local v526 = v_u_3.Heartbeat
	local function v532(p527)
		-- upvalues: (ref) v_u_140, (copy) p_u_119, (ref) v_u_146, (copy) v_u_139, (copy) v_u_123, (copy) v_u_154, (ref) v_u_147, (ref) v_u_141, (ref) v_u_145, (ref) v_u_4, (copy) v_u_374
		if v_u_140 and p_u_119.Parent then
			if v_u_146 then
				local v528
				if v_u_139.ov.reduced == nil then
					v528 = v_u_123.reduced()
				else
					v528 = v_u_139.ov.reduced == true
				end
				local v529 = v_u_154
				local v530
				if v528 then
					v530 = 0.2
				else
					local v531 = os.clock() * 1.6
					v530 = math.sin(v531) * 0.2 + 0.35
				end
				v529.Transparency = v530
			end
			v_u_147 = v_u_147 + p527
			if v_u_147 >= 0.5 then
				v_u_147 = 0
				v_u_139.paint()
				if v_u_146 and (v_u_141 and os.clock() - v_u_145 >= v_u_4.POLL) then
					v_u_145 = os.clock()
					v_u_374("state")
				end
			end
		else
			return
		end
	end
	table.insert(v_u_142, v526:Connect(v532))
	function v_u_139.destroy() -- name: destroy
		-- upvalues: (ref) v_u_140, (ref) v_u_375, (ref) v_u_5, (ref) v_u_4, (copy) v_u_142, (copy) v_u_148
		v_u_140 = false
		if v_u_375 ~= nil then
			local v_u_533 = v_u_375
			v_u_375 = nil
			if v_u_533.isOpen() then
				v_u_5 = v_u_533
				task.delay(v_u_4.KEEP_SEC, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_533
					if v_u_5 == v_u_533 then
						v_u_5 = nil
						local v534 = v_u_533.close
						pcall(v534)
					end
				end)
			end
		end
		for _, v535 in v_u_142 do
			v535:Disconnect()
		end
		table.clear(v_u_142)
		v_u_148:Destroy()
	end
	local v536 = v_u_125.command
	if type(v536) == "function" then
		v_u_125.command("menuhunt.state", function()
			-- upvalues: (ref) v_u_4, (copy) v_u_126, (ref) v_u_143, (copy) v_u_355, (copy) v_u_148, (copy) v_u_128, (copy) v_u_139, (copy) v_u_125, (copy) v_u_127, (ref) v_u_1, (copy) v_u_150
			local v537 = v_u_4.view(v_u_126, v_u_143, os.clock(), v_u_355())
			local v538 = v_u_148.AbsolutePosition
			local v539 = v_u_148.AbsoluteSize
			local v540 = "visible=%s mode=%s state=%s button=%s enabled=%s status=[%s] count=[%s] ends=[%s] art=[%s loaded=%s visible=%s] rect=%d,%d %dx%d sent=%s"
			local v541 = v_u_148.Visible
			local v542 = tostring(v541)
			local v543 = v_u_128
			local v544 = v_u_139.state()
			local v545 = v537.button
			local v546 = v537.enabled
			local v547 = tostring(v546)
			local v548 = v537.status
			local v549 = v537.count
			local v550 = v_u_4.countdown
			local v551 = v_u_126
			local function v552()
				-- upvalues: (ref) v_u_125
				return v_u_125.config.HUNT_END_UTC
			end
			local v553, v554 = pcall(v552)
			local v555 = v_u_127.endUtc
			if not v553 then
				v554 = nil
			end
			local v556 = v555(v554)
			local v557
			if v_u_139.ov.now == nil then
				v557 = v_u_1.now()
			else
				v557 = v_u_139.ov.now
			end
			local v558 = v550(v551, v556 - v557)
			local v559 = v_u_150.Image
			local v560 = v_u_150.IsLoaded
			local v561 = tostring(v560)
			local v562 = v_u_150.Visible
			return v540:format(v542, v543, v544, v545, v547, v548, v549, v558, v559, v561, tostring(v562), v538.X, v538.Y, v539.X, v539.Y, table.concat(v_u_139.sent, ","))
		end)
		v_u_125.command("menuhunt.fake", function(p563)
			-- upvalues: (ref) v_u_3, (copy) v_u_139
			if not v_u_3:IsStudio() then
				return "Studio only"
			end
			local v564 = p563[1]
			local v565 = ({
				["idle"] = {
					["k"] = "lobby",
					["s"] = "idle"
				},
				["search"] = {
					["k"] = "lobby",
					["s"] = "queued",
					["sec"] = 23,
					["n"] = 3,
					["need"] = 6
				},
				["squad"] = {
					["k"] = "lobby",
					["s"] = "queued",
					["sec"] = 23,
					["n"] = 3,
					["need"] = 6,
					["sq"] = 2,
					["lead"] = false
				},
				["blocked"] = {
					["k"] = "lobby",
					["s"] = "blocked",
					["r"] = "raidSearch",
					["t"] = "Mara1: Stop your raid search first."
				},
				["found"] = {
					["k"] = "lobby",
					["s"] = "found"
				},
				["over"] = {
					["k"] = "lobby",
					["s"] = "over"
				}
			})[tostring(v564)]
			if v565 == nil then
				return "usage: menuhunt.fake idle|search|squad|blocked|found|over"
			end
			v_u_139.feed(v565)
			local v566 = p563[1]
			return "fed " .. tostring(v566)
		end)
		v_u_125.command("menuhunt.press", function()
			-- upvalues: (copy) v_u_139
			v_u_139.press()
			return "pressed, sent=" .. table.concat(v_u_139.sent, ",")
		end)
	end
	v_u_139.paint()
	return v_u_139
end
return v_u_4