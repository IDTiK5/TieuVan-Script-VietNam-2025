-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDQuick

local v_u_1 = game:GetService("Players")
local v2 = {}
local v_u_3 = {}
local v_u_4 = false
local v_u_5 = nil
local v_u_6 = {
	["pistol"] = true,
	["rifle"] = true,
	["shotgun"] = true,
	["smg"] = true,
	["sniper"] = true
}
function v2.new(p_u_7) -- name: new
	-- upvalues: (ref) v_u_4, (copy) v_u_3, (ref) v_u_5, (copy) v_u_6, (copy) v_u_1
	local v_u_8 = p_u_7.UI
	local v_u_9 = p_u_7.Theme
	local v_u_10 = v_u_9.color
	local v_u_11 = {}
	local v_u_12 = nil
	local function v13()
		-- upvalues: (ref) v_u_12, (copy) p_u_7
		v_u_12 = p_u_7.cctx.shared.Items
	end
	pcall(v13)
	local v_u_14 = nil
	local function v15()
		-- upvalues: (ref) v_u_14, (copy) p_u_7
		v_u_14 = p_u_7.cctx.lib.ItemIcons
	end
	pcall(v15)
	local v_u_16 = nil
	local v_u_17 = nil
	local function v18()
		-- upvalues: (ref) v_u_16, (copy) p_u_7, (ref) v_u_17
		v_u_16 = p_u_7.cctx.lib.InvUIWhy
		v_u_17 = p_u_7.cctx.shared.Skills
	end
	pcall(v18)
	local v_u_19 = v_u_8.new("Frame", {
		["Name"] = "Quick",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -34),
		["Size"] = UDim2.fromOffset(296, 84)
	}, p_u_7.root)
	local v_u_20 = v_u_8.new("Frame", {
		["Name"] = "Strip",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 60)
	}, v_u_19)
	v_u_8.layout(v_u_20, "h", 8)
	local v_u_21 = v_u_8.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["align"] = "center",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_19,
		["color"] = v_u_10.accent,
		["size"] = UDim2.new(1, 0, 0, 16),
		["position"] = UDim2.fromOffset(0, 0)
	})
	v_u_21.Visible = false
	local v_u_22 = v_u_17
	local v_u_23 = v_u_16
	local v_u_24 = v_u_12
	local v_u_25 = v_u_14
	local v_u_26 = {}
	local v_u_27 = false
	local v_u_28 = nil
	local v_u_29 = false
	local v_u_30 = 0
	local v_u_31 = false
	local v_u_32 = 1
	local v_u_33 = 0
	for v34 = 1, 4 do
		local v35 = v_u_8.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.3,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Q" .. v34,
			["BackgroundColor3"] = v_u_10.bg,
			["Size"] = UDim2.fromOffset(68, 60),
			["LayoutOrder"] = v34
		}, v_u_20)
		v_u_26[v34] = {
			["frame"] = nil,
			["stroke"] = nil,
			["uid"] = "",
			["n"] = 0,
			["frame"] = v35,
			["stroke"] = v_u_8.stroke(v35, v_u_10.line, 1, 0.2)
		}
	end
	local function v_u_46(p36) -- name: keyText
		-- upvalues: (copy) p_u_7
		local function v37()
			-- upvalues: (ref) p_u_7
			return p_u_7.cctx.controllers.Input
		end
		local v38, v39 = pcall(v37)
		if not v38 then
			v39 = nil
		end
		if (not (v39 and v39.device) and "Keyboard" or v39.device()) == "Touch" then
			return tostring(p36)
		end
		local v40
		if v39 and v39.hint then
			local v41 = v39.hint
			local v42 = "quick" .. p36
			local v43, v44 = pcall(v41, v42)
			v40 = (not v43 or type(v44) ~= "string") and "" or v44
		else
			v40 = ""
		end
		if v40 == "" then
			return tostring(p36)
		end
		local v45 = string.gsub(v40, "^D%-Pad%s*", "D-")
		return string.upper(v45)
	end
	local function v_u_56(p47, p48, p49, p50, p51) -- name: textLabel
		-- upvalues: (copy) v_u_8
		local v52 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["TextScaled"] = true,
			["TextTruncate"] = nil,
			["Text"] = "",
			["ZIndex"] = 3,
			["Name"] = p47,
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		}
		for v53, v54 in p49 do
			v52[v53] = v54
		end
		local v55 = v_u_8.new("TextLabel", v52, p48)
		v_u_8.new("UITextSizeConstraint", {
			["MaxTextSize"] = p50,
			["MinTextSize"] = p51
		}, v55)
		return v55
	end
	local function v_u_59(_, p57) -- name: buildContent
		-- upvalues: (copy) v_u_8, (copy) v_u_56, (copy) v_u_9, (copy) v_u_10
		local v58 = v_u_8.new("Frame", {
			["Name"] = "HudQuickContent",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Size"] = UDim2.fromScale(1, 1)
		}, nil)
		p57.iconArea = v_u_8.new("Frame", {
			["Name"] = "IconArea",
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 2
		}, v58)
		p57.num = v_u_56("Key", v58, {
			["FontFace"] = v_u_9.font.monoBold,
			["TextColor3"] = v_u_10.muted,
			["TextXAlignment"] = Enum.TextXAlignment.Left
		}, 12, 7)
		p57.count = v_u_56("Count", v58, {
			["FontFace"] = v_u_9.font.monoBold,
			["TextColor3"] = v_u_10.text2,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0)
		}, 11, 7)
		p57.name = v_u_56("Short", v58, {
			["FontFace"] = v_u_9.font.bodyMedium,
			["TextColor3"] = v_u_10.text,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["AnchorPoint"] = Vector2.new(0, 1)
		}, 10, 6)
		p57.content = v58
		p57.icon = nil
		p57.iconId = nil
	end
	local function v_u_81(p60) -- name: placeContent
		-- upvalues: (ref) v_u_27, (copy) v_u_9, (copy) p_u_7
		local v61 = p60.iconArea
		local v62 = p60.num
		local v63 = p60.count
		local v64 = p60.name
		if v61 and (v62 and (v63 and v64)) then
			if v_u_27 and v_u_9.isPhone() then
				local v65 = 1
				local function v66()
					-- upvalues: (ref) p_u_7
					return p_u_7.cctx.controllers.Input
				end
				local v67, v68 = pcall(v66)
				if not v67 then
					v68 = nil
				end
				local v69
				if v68 and v68.touch then
					local v70 = v68.touch
					local v71
					v71, v69 = pcall(v70)
					if not v71 or type(v69) ~= "table" then
						v69 = nil
					end
				else
					v69 = nil
				end
				if v69 and v69.info then
					local v72 = v69.info
					local v73, v74 = pcall(v72, v69)
					if v73 and type(v74) == "table" then
						local v75 = v74.scale
						if type(v75) == "number" and v74.scale > 0.3 then
							v65 = v74.scale
						end
					end
				end
				v62.Position = UDim2.fromOffset(3, 1)
				v62.Size = UDim2.new(0.5, -3, 0, 11)
				v63.Position = UDim2.new(1, -3, 0, 1)
				v63.Size = UDim2.new(0.5, -3, 0, 11)
				v61.Position = UDim2.fromOffset(6, 12)
				v61.Size = UDim2.new(1, -12, 1, -24)
				v64.Position = UDim2.new(0, 2, 1, 0)
				v64.Size = UDim2.new(1, -4, 0, 11)
				for _, v76 in { v62, v63, v64 } do
					local v77 = v76:FindFirstChildOfClass("UITextSizeConstraint")
					if not v77 then
						continue
					end
					local v78 = v77.MaxTextSize
					local v79 = v_u_9.phoneText
					local v80 = v77.MinTextSize
					v77.MinTextSize = math.min(v78, v79(v80, "scaled", v65, true))
				end
				return
			elseif v_u_27 then
				v62.Position = UDim2.fromOffset(3, 2)
				v62.Size = UDim2.new(0.5, -3, 0, 10)
				v63.Position = UDim2.new(1, -3, 0, 2)
				v63.Size = UDim2.new(0.5, -3, 0, 10)
				v61.Position = UDim2.fromOffset(6, 9)
				v61.Size = UDim2.new(1, -12, 1, -19)
				v64.Position = UDim2.new(0, 2, 1, -1)
				v64.Size = UDim2.new(1, -4, 0, 9)
			else
				v62.Position = UDim2.fromOffset(5, 3)
				v62.Size = UDim2.new(0.6, -5, 0, 12)
				v63.Position = UDim2.new(1, -5, 0, 3)
				v63.Size = UDim2.new(0.4, -5, 0, 12)
				v61.Position = UDim2.fromOffset(8, 13)
				v61.Size = UDim2.new(1, -16, 1, -27)
				v64.Position = UDim2.new(0, 3, 1, -2)
				v64.Size = UDim2.new(1, -6, 0, 12)
			end
		else
			return
		end
	end
	local function v_u_97(p82, p83) -- name: attach
		-- upvalues: (ref) v_u_27, (copy) p_u_7, (ref) v_u_25, (copy) v_u_59, (copy) v_u_81
		local v_u_84 = p83.frame
		if v_u_27 then
			local function v85()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.controllers.Input
			end
			local v86, v87 = pcall(v85)
			if not v86 then
				v87 = nil
			end
			local v88
			if v87 and v87.touch then
				local v89 = v87.touch
				local v90
				v90, v88 = pcall(v89)
				if not v90 or type(v88) ~= "table" then
					v88 = nil
				end
			else
				v88 = nil
			end
			if v88 and v88.buttonGui then
				local v91 = v88.buttonGui
				local v92 = "quick" .. p82
				local v93
				v93, v_u_84 = pcall(v91, v88, v92)
				if not v93 then
					v_u_84 = nil
				end
			else
				v_u_84 = nil
			end
		end
		local v_u_94 = p83.content
		if v_u_94 and (v_u_84 and v_u_94.Parent == v_u_84) then
			return
		elseif v_u_94 and (v_u_84 and pcall(function()
			-- upvalues: (copy) v_u_94, (ref) v_u_84
			v_u_94.Parent = v_u_84
		end)) then
			return
		elseif v_u_84 then
			if p83.icon and v_u_25 then
				local v95 = v_u_25.release
				local v96 = p83.icon
				pcall(v95, v96)
			end
			v_u_59(p82, p83)
			v_u_81(p83)
			p83.content.Parent = v_u_84
		elseif v_u_94 then
			pcall(function()
				-- upvalues: (copy) v_u_94
				v_u_94.Parent = nil
			end)
		end
	end
	local function v_u_106(p98, p99) -- name: setIcon
		-- upvalues: (ref) v_u_25
		if p98.iconId ~= p99 or p99 ~= nil and (p98.icon == nil or v_u_25 and not v_u_25.alive(p98.icon)) then
			if p98.icon and v_u_25 then
				local v100 = v_u_25.release
				local v101 = p98.icon
				pcall(v100, v101)
			end
			p98.icon = nil
			p98.iconId = p99
			if p99 and (v_u_25 and p98.iconArea) then
				local v102 = v_u_25.get
				local v103 = {
					["parent"] = nil,
					["size"] = nil,
					["zindex"] = 2,
					["name"] = "Icon",
					["parent"] = p98.iconArea,
					["size"] = UDim2.fromScale(1, 1)
				}
				local v104, v105 = pcall(v102, p99, false, v103)
				if v104 and typeof(v105) == "Instance" then
					p98.icon = v105
				end
			end
		end
	end
	local function v_u_113(p107, p108) -- name: findItem
		if type(p107) == "table" then
			local v109 = p107.containers
			if type(v109) == "table" then
				for _, v110 in p107.containers do
					if type(v110) ~= "table" or v110.world == true then
						continue
					end
					local v111 = v110.items
					if type(v111) ~= "table" then
						continue
					end
					for _, v112 in v110.items do
						if type(v112) ~= "table" or v112.uid ~= p108 then
							continue
						end
						return v112
					end
				end
				return nil
			end
		end
		return nil
	end
	local function v_u_121(p114, p115) -- name: countOf
		local v116 = 0
		for _, v117 in p114.containers do
			if type(v117) ~= "table" or v117.world == true then
				continue
			end
			local v118 = v117.items
			if type(v118) ~= "table" then
				continue
			end
			for _, v119 in v117.items do
				if type(v119) ~= "table" or v119.id ~= p115 then
					continue
				end
				local v120 = v119.n
				v116 = v116 + (type(v120) ~= "number" and 1 or v119.n)
			end
		end
		return v116
	end
	local function v_u_142(p122, p123) -- name: paint
		-- upvalues: (copy) v_u_46, (copy) v_u_10, (ref) v_u_27, (copy) p_u_7, (ref) v_u_24, (copy) v_u_9, (copy) v_u_106
		local v124 = p123.num
		local v125 = p123.count
		local v126 = p123.name
		if v124 and (v125 and v126) then
			local v127 = p123.itemId ~= nil
			v124.Text = v_u_46(p122)
			local v128
			if v127 then
				v128 = v_u_10.accent
			else
				v128 = v_u_10.muted
			end
			v124.TextColor3 = v128
			local v129
			if v_u_27 then
				local function v130()
					-- upvalues: (ref) p_u_7
					return p_u_7.cctx.controllers.Input
				end
				local v131, v132 = pcall(v130)
				if not v131 then
					v132 = nil
				end
				if v132 and v132.touch then
					local v133 = v132.touch
					local v134
					v134, v129 = pcall(v133)
					if not v134 or type(v129) ~= "table" then
						v129 = nil
					end
				else
					v129 = nil
				end
			else
				v129 = nil
			end
			if v_u_27 then
				v124.Visible = v127
				if v129 and v129.setLabel then
					local v135 = v129.setLabel
					local v136 = "quick" .. p122
					pcall(v135, v129, v136, v127 and "" or nil)
				end
			else
				v124.Visible = true
			end
			if v127 then
				local v137 = v_u_24 and v_u_24.get
				if v137 then
					v137 = v_u_24.get(p123.itemId)
				end
				local v138 = v137 and (v137.short or v137.name)
				if not v138 then
					local v139 = p123.itemId
					v138 = tostring(v139)
				end
				v126.Text = string.upper((tostring(v138)))
				v125.Text = p123.n <= 1 and "" or "x" .. p123.n
				if v137 then
					v137 = v137.shown or v137.rarity
				end
				local v140 = p123.frame
				local v141
				if type(v137) == "number" and v137 > 1 then
					v141 = v_u_10.bg:Lerp(v_u_9.rarityColor(v137), 0.25)
				else
					v141 = v_u_10.bg
				end
				v140.BackgroundColor3 = v141
			else
				v126.Text = ""
				v125.Text = ""
				p123.frame.BackgroundColor3 = v_u_10.bg
			end
			p123.frame.BackgroundTransparency = v127 and 0.2 or 0.55
			v_u_106(p123, p123.itemId)
		end
	end
	function v_u_11.onInv(p143) -- name: onInv
		-- upvalues: (ref) v_u_28, (copy) v_u_26, (copy) v_u_113, (copy) v_u_121, (copy) v_u_10, (copy) v_u_8, (copy) v_u_97, (copy) v_u_142, (copy) v_u_21, (ref) v_u_29, (ref) v_u_23, (ref) v_u_22, (ref) v_u_30
		v_u_28 = p143
		local v144
		if type(p143) == "table" then
			v144 = p143.kit or nil
		else
			v144 = nil
		end
		local v145
		if type(v144) == "table" then
			v145 = v144.quick or nil
		else
			v145 = nil
		end
		for v146, v147 in v_u_26 do
			local v148
			if type(v145) == "table" then
				local v149 = v145[v146]
				v148 = type(v149) ~= "string" and "" or v145[v146]
			else
				v148 = ""
			end
			local v150
			if v148 == "" then
				v150 = nil
			else
				v150 = v_u_113(p143, v148)
			end
			if v150 then
				local v151 = v_u_121(p143, v150.id)
				if v147.uid == v148 and v151 < v147.n then
					v147.stroke.Color = v_u_10.accent
					v147.stroke.Transparency = 0
					v_u_8.tween(v147.stroke, {
						["Color"] = nil,
						["Transparency"] = 0.2,
						["Color"] = v_u_10.line
					}, 0.6)
				end
				v147.n = v151
				local v152 = v150.id
				v147.itemId = tostring(v152)
			else
				v147.n = 0
				v147.itemId = nil
			end
			v147.uid = v148
			v_u_97(v146, v147)
			v_u_142(v146, v147)
		end
		local v153
		if type(p143) == "table" then
			v153 = p143.weight or nil
		else
			v153 = nil
		end
		local v154
		if type(p143) == "table" then
			v154 = p143.maxWeight or nil
		else
			v154 = nil
		end
		if type(v153) == "number" and (type(v154) == "number" and (v154 > 0 and v154 * 0.75 <= v153)) then
			v_u_21.Visible = true
			local v155 = v154 < v153 and (v_u_29 and "  OVER" or "  OVERWEIGHT") or ""
			local v156
			if v_u_23 then
				local v157 = v_u_23.weightTag
				local v158
				if v_u_22 then
					local v159 = v_u_22.MOVE
					if type(v159) == "table" then
						v158 = v_u_22.MOVE.overweightNoSprint
					else
						v158 = nil
					end
				else
					v158 = nil
				end
				local v160 = v_u_29
				local v161
				v161, v156 = pcall(v157, v153, v154, v158, v160)
				if v161 and type(v156) == "string" then
					if v156 == "" then
						v156 = v155
					end
				else
					v156 = v155
				end
			else
				v156 = v155
			end
			v_u_21.Text = string.format("%.1f / %.0f KG%s", v153, v154, v156)
			local v162 = v_u_21
			local v163
			if v154 < v153 then
				v163 = v_u_10.danger
			else
				v163 = v_u_10.accent
			end
			v162.TextColor3 = v163
		else
			v_u_21.Visible = false
		end
		if v_u_23 then
			local v164 = v_u_23.weightStage
			local v165
			if v_u_22 then
				local v166 = v_u_22.MOVE
				if type(v166) == "table" then
					v165 = v_u_22.MOVE.overweightNoSprint
				else
					v165 = nil
				end
			else
				v165 = nil
			end
			local v167, v168 = pcall(v164, v153, v154, v165)
			if v167 and type(v168) == "number" then
				local v169 = v_u_23.weightToast
				local v170 = v_u_30
				local v171, v172 = pcall(v169, v170, v168)
				if v171 and type(v172) == "string" then
					local v173 = v_u_8.toast
					pcall(v173, v172, "warn")
				end
				v_u_30 = v168
			end
		end
	end
	local v_u_174 = nil
	function v_u_11.setCharacter(p175) -- name: setCharacter
		-- upvalues: (ref) v_u_174
		v_u_174 = p175
	end
	function v_u_11.uidAt(p176) -- name: uidAt
		-- upvalues: (copy) v_u_26
		local v177 = v_u_26[p176]
		return not v177 and "" or v177.uid
	end
	function v_u_11.pressed(p178, p179) -- name: pressed
		-- upvalues: (copy) v_u_26, (copy) v_u_10, (copy) v_u_8
		local v180 = v_u_26[p178]
		if v180 then
			local v181 = v180.stroke
			local v182
			if p179 then
				v182 = v_u_10.accent
			else
				v182 = v_u_10.danger
			end
			v181.Color = v182
			v180.stroke.Transparency = 0
			v_u_8.tween(v180.stroke, {
				["Color"] = nil,
				["Transparency"] = 0.2,
				["Color"] = v_u_10.line
			}, 0.45)
		end
	end
	function v_u_11.iconStats() -- name: iconStats
		-- upvalues: (copy) v_u_26, (ref) v_u_27
		local v183 = 0
		local v184 = {}
		for v185, v186 in v_u_26 do
			if v186.icon and v186.icon.Parent then
				v183 = v183 + 1
			end
			v184[v185] = v186.iconId or ""
		end
		return {
			["icons"] = v183,
			["ids"] = v184,
			["touch"] = v_u_27
		}
	end
	local v_u_187 = nil
	local function v188()
		-- upvalues: (ref) v_u_187, (copy) p_u_7
		v_u_187 = p_u_7.cctx.shared.Weapons
	end
	pcall(v188)
	local v_u_189 = p_u_7.cctx
	if not v_u_4 and (v_u_189 and (v_u_189.net and v_u_189.net.listen)) then
		v_u_4 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_189, (ref) v_u_3, (ref) v_u_4
			local v190 = v_u_189.net.listen
			local function v195(p191, p192, ...)
				-- upvalues: (ref) v_u_3
				if p191 == "down" then
					local v193 = tonumber((...)) or 2
					local v194 = math.clamp(v193, 0.5, 4)
					v_u_3[p192] = os.clock() + v194
					return
				elseif p191 == "wake" or p191 == "die" then
					v_u_3[p192] = nil
				elseif p191 == "clear" then
					table.clear(v_u_3)
				end
			end
			if not pcall(v190, "zombie.event", v195) then
				v_u_4 = false
			end
		end)
	end
	local v_u_196 = v_u_8.new("Frame", {
		["Name"] = "Tips",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -8),
		["Size"] = UDim2.fromOffset(560, 20)
	}, p_u_7.root)
	v_u_8.layout(v_u_196, "h", 14, "center")
	local v_u_197 = 0.2
	local v_u_198 = ""
	local v_u_199 = {}
	local function v_u_204(p200) -- name: throwName
		-- upvalues: (ref) v_u_187, (ref) v_u_24
		local v201 = v_u_187 and v_u_187.throwable
		if v201 then
			v201 = v_u_187.throwable(p200)
		end
		if not v201 and (v_u_24 and v_u_24.get) then
			v201 = v_u_24.get(p200)
		end
		local v202 = string.upper
		local v203 = v201 and v201.name or string.gsub(p200, "^throw_", "")
		return v202((tostring(v203)))
	end
	local function v_u_221(p205, p206, p207) -- name: tipFor
		-- upvalues: (copy) v_u_204, (copy) p_u_7, (copy) v_u_26
		local v208 = p207 == "Touch"
		if p205 == "finish" then
			return {
				["kind"] = nil,
				["action"] = "fire",
				["label"] = "FINISH",
				["kind"] = p205
			}
		end
		if p205 == "stomp" then
			return {
				["kind"] = nil,
				["action"] = "melee",
				["label"] = nil,
				["kind"] = p205,
				["label"] = v208 and "MELEE: STOMP" or "STOMP"
			}
		end
		if p205 == "shove" then
			return {
				["kind"] = nil,
				["action"] = "melee",
				["label"] = nil,
				["kind"] = p205,
				["label"] = v208 and "MELEE: SHOVE" or "SHOVE"
			}
		end
		if p205 ~= "throw" then
			return nil
		end
		local v209 = p206:GetAttribute("Throwable")
		if type(v209) ~= "string" or v209 == "" then
			return nil
		end
		local v210 = tonumber(p206:GetAttribute("Throwables")) or 0
		local v211 = v_u_204(v209) .. (v210 <= 1 and "" or " x" .. v210)
		if v208 then
			return {
				["kind"] = nil,
				["action"] = "throw",
				["label"] = nil,
				["kind"] = p205,
				["label"] = "THROW: " .. v211
			}
		end
		local function v212()
			-- upvalues: (ref) p_u_7
			return p_u_7.cctx.controllers.Input
		end
		local v213, v214 = pcall(v212)
		if not v213 then
			v214 = nil
		end
		local v215
		if v214 and v214.hint then
			local v216 = v214.hint
			local v217, v218 = pcall(v216, "throw")
			v215 = (not v217 or type(v218) ~= "string") and "" or v218
		else
			v215 = ""
		end
		if v215 ~= "" then
			return {
				["kind"] = nil,
				["action"] = "throw",
				["label"] = nil,
				["kind"] = p205,
				["label"] = "THROW " .. v211
			}
		end
		for v219, v220 in v_u_26 do
			if v220.itemId ~= v209 then
				continue
			end
			return {
				["kind"] = p205,
				["action"] = "quick" .. v219,
				["label"] = "THROW " .. v211
			}
		end
		return {
			["kind"] = nil,
			["action"] = "",
			["label"] = nil,
			["kind"] = p205,
			["label"] = "THROW " .. v211 .. ": USE A QUICK SLOT"
		}
	end
	local function v_u_266(p222) -- name: wantedKinds
		-- upvalues: (ref) v_u_5, (copy) p_u_7, (ref) v_u_187, (ref) v_u_6, (ref) v_u_3
		if v_u_5 then
			return v_u_5
		end
		local v223 = p222:FindFirstChild("HumanoidRootPart")
		local v_u_224 = "ZombieRender"
		local function v225()
			-- upvalues: (ref) p_u_7, (copy) v_u_224
			return p_u_7.cctx.controllers[v_u_224]
		end
		local v226, v227 = pcall(v225)
		if not v226 then
			v227 = nil
		end
		if v223 and v227 then
			local v228 = v227.targets
			if type(v228) == "function" then
				local v229 = p222:GetAttribute("Weapon")
				local v230 = p222:GetAttribute("HoldType")
				local v231
				if type(v229) == "string" and (v229 ~= "" and (v_u_187 and v_u_187.get)) then
					v231 = v_u_187.get(v229)
				else
					v231 = nil
				end
				local v232
				if type(v229) == "string" then
					v232 = v229 ~= ""
				else
					v232 = false
				end
				local v233
				if v232 then
					if v231 == nil or v231.kind ~= "melee" then
						if type(v230) == "string" then
							v233 = string.sub(v230, 1, 5) == "melee"
						else
							v233 = false
						end
					else
						v233 = true
					end
				else
					v233 = v232
				end
				local v234 = v232 and not v233
				if v234 then
					v234 = v231 ~= nil and true or v_u_6[tostring(v230)] == true
				end
				if v233 then
					if v231 then
						v231 = v231.meleeRange or v231.range
					end
				else
					v231 = v233
				end
				local v235 = tonumber(v231)
				if not v235 then
					local v236 = v_u_187 and v_u_187.SHOVE
					if v236 then
						v236 = v_u_187.SHOVE.meleeRange
					end
					v235 = tonumber(v236) or 4.6
				end
				local v237 = p222:GetAttribute("Throwable")
				local v238
				if type(v237) == "string" then
					v238 = v237 ~= ""
				else
					v238 = false
				end
				local v239 = v235 + 2.5
				local v240 = math.max(8, v239, v238 and 30 or 0)
				local v241 = v227.targets
				local v242 = v223.Position
				local v243, v244 = pcall(v241, v242, v240)
				if not v243 or type(v244) ~= "table" then
					return {}
				end
				local v245 = os.clock()
				for v246, v247 in v_u_3 do
					if v247 >= v245 then
						continue
					end
					v_u_3[v246] = nil
				end
				local v248 = v223.Position
				local v249 = false
				local v250 = false
				local v251 = false
				for _, v252 in v244 do
					if v252.visible ~= true then
						continue
					end
					local v253 = v252.position
					if typeof(v253) ~= "Vector3" then
						continue
					end
					local v254 = v252.position.X - v248.X
					local v255 = v252.position.Z - v248.Z
					local v256 = Vector3.new(v254, 0, v255).Magnitude
					v251 = true
					v249 = v256 <= v235 + 2.5 and (v245 < (v_u_3[v252.id] or 0) or v252.typeId == "crawler") and true or v249
					if v256 > 8 then
						continue
					end
					v250 = true
				end
				local v257 = {}
				if v249 then
					table.insert(v257, v233 and "finish" or "stomp")
				elseif v250 and v234 then
					table.insert(v257, "shove")
				end
				local v_u_258 = "WeaponClient"
				local function v259()
					-- upvalues: (ref) p_u_7, (copy) v_u_258
					return p_u_7.cctx.controllers[v_u_258]
				end
				local v260, v261 = pcall(v259)
				if not v260 then
					v261 = nil
				end
				local v262 = false
				if v261 then
					local v263 = v261.isThrowMode
					if type(v263) == "function" then
						local v264 = v261.isThrowMode
						local v265
						v262, v265 = pcall(v264)
						if v262 then
							v262 = v265 == true
						end
					end
				end
				if v238 and (v251 and not v262) then
					table.insert(v257, "throw")
				end
				return v257
			end
		end
		return {}
	end
	local function v_u_275(p267) -- name: paintTips
		-- upvalues: (copy) v_u_196, (copy) v_u_8, (copy) v_u_10
		for _, v268 in v_u_196:GetChildren() do
			if not v268:IsA("GuiObject") then
				continue
			end
			v268:Destroy()
		end
		for v269, v270 in p267 do
			if v269 > 2 then
				break
			end
			local v271 = v_u_8.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Tip_" .. v270.kind,
				["Size"] = UDim2.fromOffset(0, 20),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = v269
			}, v_u_196)
			v_u_8.layout(v271, "h", 6)
			if v270.action ~= "" then
				v_u_8.keyHint(v270.action, {
					["size"] = 20,
					["order"] = 1
				}).Parent = v271
			end
			local v272 = v_u_8.label
			local v273 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v271,
				["text"] = v270.label
			}
			local v274
			if v270.kind == "finish" or v270.kind == "stomp" then
				v274 = v_u_10.accent
			else
				v274 = v_u_10.text
			end
			v273.color = v274
			v273.size = UDim2.fromOffset(0, 20)
			v272(v273).TextStrokeTransparency = 0.6
		end
	end
	local function v_u_309(p276, p277) -- name: updateTips
		-- upvalues: (ref) v_u_197, (ref) v_u_174, (copy) p_u_7, (copy) v_u_266, (copy) v_u_221, (ref) v_u_198, (ref) v_u_199, (copy) v_u_275, (ref) v_u_1, (copy) v_u_196
		v_u_197 = v_u_197 + p276
		if v_u_197 >= 0.2 then
			v_u_197 = 0
			local v278 = v_u_174
			local v279 = {}
			local v_u_280 = {}
			if v278 and (v278.Parent and not p277) then
				local function v281()
					-- upvalues: (ref) p_u_7
					return p_u_7.cctx.controllers.Input
				end
				local v282, v_u_283 = pcall(v281)
				if not v282 then
					v_u_283 = nil
				end
				local v284, v285 = pcall(function()
					-- upvalues: (copy) v_u_283
					return v_u_283.device()
				end)
				local v286 = (not v284 or type(v285) ~= "string") and "Keyboard" or v285
				for _, v287 in v_u_266(v278) do
					local v288 = v_u_221(v287, v278, v286)
					if not v288 then
						continue
					end
					table.insert(v279, v288)
					table.insert(v_u_280, v287)
				end
			end
			local v289 = {}
			for _, v290 in v279 do
				local v291 = v290.kind
				local v292 = ":"
				local v293 = v290.action
				local v294 = ":"
				local v295 = v290.label
				local v296 = ":"
				local v297 = v290.action
				local function v298()
					-- upvalues: (ref) p_u_7
					return p_u_7.cctx.controllers.Input
				end
				local v299, v300 = pcall(v298)
				if not v299 then
					v300 = nil
				end
				local v301
				if v300 and v300.hint then
					local v302 = v300.hint
					local v303, v304 = pcall(v302, v297)
					v301 = (not v303 or type(v304) ~= "string") and "" or v304
				else
					v301 = ""
				end
				local v305 = v291 .. v292 .. v293 .. v294 .. v295 .. v296 .. v301
				table.insert(v289, v305)
			end
			local v306 = table.concat(v289, "|")
			if v306 ~= v_u_198 then
				v_u_198 = v306
				v_u_199 = v_u_280
				v_u_275(v279)
				local function v307()
					-- upvalues: (ref) v_u_1, (copy) v_u_280
					v_u_1.LocalPlayer:SetAttribute("HudTips", table.concat(v_u_280, ","))
				end
				pcall(v307)
			end
			local v308 = #v279 > 0
			if v_u_196.Visible ~= v308 then
				v_u_196.Visible = v308
			end
		end
	end
	local function v_u_318() -- name: placeTips
		-- upvalues: (ref) v_u_27, (copy) p_u_7, (copy) v_u_196
		local v310
		if v_u_27 and p_u_7.touchFrame then
			v310 = p_u_7.touchFrame()
		else
			v310 = nil
		end
		if v310 then
			v_u_196.AnchorPoint = Vector2.new(0.5, 1)
			local v311 = v_u_196
			local v312 = UDim2.new
			local v313 = v310.promptX
			v311.Position = v312(0, type(v313) ~= "number" and 0 or v310.promptX, 1, -4)
			local v314 = v_u_196
			local v315 = UDim2.fromOffset
			local v316 = v310.promptMaxW
			local v317 = type(v316) ~= "number" and 360 or v310.promptMaxW
			v314.Size = v315(math.max(200, v317), 20)
		else
			v_u_196.AnchorPoint = Vector2.new(0.5, 1)
			v_u_196.Position = UDim2.new(0.5, 0, 1, -8)
			v_u_196.Size = UDim2.fromOffset(560, 20)
		end
	end
	function v_u_11.tips() -- name: tips
		-- upvalues: (ref) v_u_199
		return table.clone(v_u_199)
	end
	local function v333()
		-- upvalues: (copy) p_u_7, (ref) v_u_5, (ref) v_u_197, (ref) v_u_198, (ref) v_u_199, (ref) v_u_3
		p_u_7.cctx.command("hud.tips", function(p319)
			-- upvalues: (ref) v_u_5, (ref) v_u_197, (ref) v_u_198, (ref) v_u_199, (ref) v_u_3
			local v320 = type(p319) ~= "table" and {} or p319
			if v320[1] ~= "force" then
				if v320[1] == "off" then
					v_u_5 = nil
				end
				v_u_197 = 0.2
				v_u_198 = "?"
				v326 = table.concat(v_u_199, ",")
				v327 = not v_u_5 and "-" or table.concat(v_u_5, ",")
				v328 = 0
				v329 = "tips="
				v330 = " force="
				v331 = " downed="
				for v332 in v_u_3 do
					v328 = v328 + 1
				end
				return v329 .. v326 .. v330 .. v327 .. v331 .. tostring(v328)
			end
			local v322 = v320[2]
			if type(v322) ~= "string" then
				if v320[1] == "off" then
					v_u_5 = nil
				end
				v_u_197 = 0.2
				v_u_198 = "?"
				v326 = table.concat(v_u_199, ",")
				v327 = not v_u_5 and "-" or table.concat(v_u_5, ",")
				v328 = 0
				v329 = "tips="
				v330 = " force="
				v331 = " downed="
				for v332 in v_u_3 do
					v328 = v328 + 1
				end
				return v329 .. v326 .. v330 .. v327 .. v331 .. tostring(v328)
			end
			local v324 = {}
			for v325 in string.gmatch(v320[2], "[^,]+") do
				table.insert(v324, v325)
			end
			v_u_5 = v324
			v_u_197 = 0.2
			v_u_198 = "?"
			local v326 = table.concat(v_u_199, ",")
			local v327 = not v_u_5 and "-" or table.concat(v_u_5, ",")
			local v328 = 0
			local v329 = "tips="
			local v330 = " force="
			local v331 = " downed="
			for v332 in v_u_3 do
				v328 = v328 + 1
			end
			return v329 .. v326 .. v330 .. v327 .. v331 .. tostring(v328)
		end)
	end
	pcall(v333)
	function v_u_11.layout(p334) -- name: layout
		-- upvalues: (ref) v_u_27, (copy) v_u_20, (ref) v_u_31, (copy) p_u_7, (ref) v_u_29, (copy) v_u_19, (copy) v_u_21, (copy) v_u_26, (copy) v_u_97, (copy) v_u_81, (copy) v_u_142, (ref) v_u_28, (copy) v_u_11, (copy) v_u_318, (ref) v_u_198
		local v335 = v_u_27
		v_u_27 = p334
		v_u_20.Visible = not v_u_27
		v_u_31 = false
		local v336
		if v_u_27 and p_u_7.touchFrame then
			v336 = p_u_7.touchFrame()
		else
			v336 = nil
		end
		local v337
		if v336 == nil then
			v337 = false
		else
			v337 = v336.corner ~= nil
		end
		v_u_29 = v337
		if v_u_29 then
			v_u_19.AnchorPoint = Vector2.new(0, 0)
			v_u_19.Size = UDim2.fromOffset(200, 16)
			v_u_21.TextXAlignment = Enum.TextXAlignment.Left
			v_u_31 = false
			local v338 = p_u_7.bandOffset
			local v339 = type(v338) ~= "function" and 0 or p_u_7.bandOffset("Quick")
			local v340 = v_u_19
			local v341 = UDim2.fromOffset
			local v342 = v336.bandLeft or v336.left
			local v343 = math.floor(v342)
			local v344 = v336.listY
			local v345
			if type(v344) == "number" then
				v345 = v336.listY
			else
				v345 = v336.top + 96
			end
			local v346 = v345 + v339
			v340.Position = v341(v343, (math.floor(v346)))
		elseif v336 then
			v_u_19.AnchorPoint = Vector2.new(1, 0)
			local v347 = v_u_19
			local v348 = UDim2.new
			local v349 = 1
			local v350 = -v336.right
			local v351 = 0
			local v352 = v336.weightY
			local v353
			if type(v352) == "number" then
				v353 = v336.weightY
			else
				local v354 = v336.top + 124
				local v355 = v336.rightMaxY - 16
				v353 = math.min(v354, v355)
			end
			v347.Position = v348(v349, v350, v351, v353)
			v_u_31 = v336.weightFits == false
			v_u_19.Size = UDim2.fromOffset(296, 16)
			v_u_21.TextXAlignment = Enum.TextXAlignment.Right
		else
			v_u_19.AnchorPoint = Vector2.new(0.5, 1)
			v_u_19.Position = UDim2.new(0.5, 0, 1, -34)
			v_u_19.Size = UDim2.fromOffset(296, 84)
			v_u_21.TextXAlignment = Enum.TextXAlignment.Center
		end
		if v335 and not v_u_27 then
			local function v356()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.controllers.Input
			end
			local v357, v358 = pcall(v356)
			if not v357 then
				v358 = nil
			end
			local v359
			if v358 and v358.touch then
				local v360 = v358.touch
				local v361
				v361, v359 = pcall(v360)
				if not v361 or type(v359) ~= "table" then
					v359 = nil
				end
			else
				v359 = nil
			end
			if v359 and v359.setLabel then
				local v362 = v359.setLabel
				local v363 = "quick" .. 1
				pcall(v362, v359, v363, nil)
				local v364 = v359.setLabel
				local v365 = "quick" .. 2
				pcall(v364, v359, v365, nil)
				local v366 = v359.setLabel
				local v367 = "quick" .. 3
				pcall(v366, v359, v367, nil)
				local v368 = v359.setLabel
				local v369 = "quick" .. 4
				pcall(v368, v359, v369, nil)
			end
		end
		for v370, v371 in v_u_26 do
			v_u_97(v370, v371)
			v_u_81(v371)
			v_u_142(v370, v371)
		end
		if v_u_28 then
			v_u_11.onInv(v_u_28)
		end
		v_u_318()
		v_u_198 = "?"
	end
	function v_u_11.update(p372) -- name: update
		-- upvalues: (ref) v_u_174, (ref) v_u_31, (ref) v_u_29, (copy) p_u_7, (copy) v_u_21, (ref) v_u_32, (copy) v_u_19, (copy) v_u_309, (ref) v_u_27, (ref) v_u_33, (copy) v_u_26, (copy) v_u_97, (copy) v_u_142
		local v373 = v_u_174
		local v374 = v_u_31
		if not v374 then
			if v373 == nil then
				v374 = false
			else
				v374 = v373:GetAttribute("Downed") == true and true or v373:GetAttribute("Dead") == true
			end
		end
		if v_u_29 then
			local v375 = p_u_7.mods
			local v376
			if type(v375) == "table" then
				v376 = p_u_7.mods.HUDClock
			else
				v376 = nil
			end
			local v377
			if v376 == nil then
				v377 = false
			else
				local v378 = v376.bandBusy
				if type(v378) == "function" then
					v377 = v376.bandBusy() == true
				else
					v377 = false
				end
			end
			v374 = v374 or (not v_u_21.Visible or v377)
			v_u_32 = v_u_32 + p372
			if v_u_32 >= 0.25 and not v374 then
				v_u_32 = 0
				local v379
				if p_u_7.touchFrame then
					v379 = p_u_7.touchFrame()
				else
					v379 = nil
				end
				if v379 then
					local v380 = p_u_7.bandOffset
					if type(v380) == "function" then
						local v381 = v_u_19
						local v382 = UDim2.fromOffset
						local v383 = v379.bandLeft or v379.left
						local v384 = math.floor(v383)
						local v385 = v379.listY
						local v386
						if type(v385) == "number" then
							v386 = v379.listY
						else
							v386 = v379.top + 96
						end
						local v387 = v386 + p_u_7.bandOffset("Quick")
						v381.Position = v382(v384, (math.floor(v387)))
					end
				end
			end
		end
		if v_u_19.Visible == v374 then
			v_u_19.Visible = not v374
		end
		local v388 = v_u_309
		local v389
		if v373 == nil then
			v389 = false
		else
			v389 = v373:GetAttribute("Downed") == true and true or v373:GetAttribute("Dead") == true
		end
		v388(p372, v389)
		if v_u_27 then
			v_u_33 = v_u_33 + p372
			if v_u_33 >= 0.5 then
				v_u_33 = 0
				for v390, v391 in v_u_26 do
					local v392 = v391.content
					v_u_97(v390, v391)
					if v391.content == v392 then
						continue
					end
					v_u_142(v390, v391)
				end
			end
		end
	end
	local v_u_393 = false
	local function v_u_406() -- name: cleanup
		-- upvalues: (ref) v_u_393, (copy) p_u_7, (copy) v_u_26, (ref) v_u_25
		if not v_u_393 then
			v_u_393 = true
			local function v394()
				-- upvalues: (ref) p_u_7
				return p_u_7.cctx.controllers.Input
			end
			local v395, v396 = pcall(v394)
			if not v395 then
				v396 = nil
			end
			local v397
			if v396 and v396.touch then
				local v398 = v396.touch
				local v399
				v399, v397 = pcall(v398)
				if not v399 or type(v397) ~= "table" then
					v397 = nil
				end
			else
				v397 = nil
			end
			for v400, v_u_401 in v_u_26 do
				if v_u_401.icon and v_u_25 then
					local v402 = v_u_25.release
					local v403 = v_u_401.icon
					pcall(v402, v403)
				end
				v_u_401.icon = nil
				if v_u_401.content then
					pcall(function()
						-- upvalues: (copy) v_u_401
						v_u_401.content:Destroy()
					end)
				end
				if not (v397 and v397.setLabel) then
					continue
				end
				local v404 = v397.setLabel
				local v405 = "quick" .. v400
				pcall(v404, v397, v405, nil)
			end
		end
	end
	v_u_19.Destroying:Connect(v_u_406)
	function v_u_11.destroy() -- name: destroy
		-- upvalues: (copy) v_u_406, (copy) v_u_196, (copy) v_u_19
		v_u_406()
		local function v407()
			-- upvalues: (ref) v_u_196
			v_u_196:Destroy()
		end
		pcall(v407)
		v_u_19:Destroy()
	end
	for v408, v409 in v_u_26 do
		v_u_59(v408, v409)
		v_u_81(v409)
		v_u_97(v408, v409)
		v_u_142(v408, v409)
	end
	local v410, v_u_411 = pcall(function()
		-- upvalues: (copy) p_u_7
		return p_u_7.cctx.controllers.Input
	end)
	if not v410 then
		v_u_411 = nil
	end
	if v_u_411 and (v_u_411.deviceChanged and v_u_411.deviceChanged.Connect) then
		pcall(function()
			-- upvalues: (copy) v_u_411, (copy) v_u_19, (copy) v_u_26, (copy) v_u_142
			local v_u_414 = v_u_411.deviceChanged:Connect(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_26, (ref) v_u_142
				task.defer(function()
					-- upvalues: (ref) v_u_19, (ref) v_u_26, (ref) v_u_142
					if v_u_19.Parent then
						for v412, v413 in v_u_26 do
							v_u_142(v412, v413)
						end
					end
				end)
			end)
			v_u_19.Destroying:Connect(function()
				-- upvalues: (copy) v_u_414
				v_u_414:Disconnect()
			end)
		end)
	end
	v_u_318()
	if p_u_7.inv then
		v_u_11.onInv(p_u_7.inv)
	end
	return v_u_11
end
return v2