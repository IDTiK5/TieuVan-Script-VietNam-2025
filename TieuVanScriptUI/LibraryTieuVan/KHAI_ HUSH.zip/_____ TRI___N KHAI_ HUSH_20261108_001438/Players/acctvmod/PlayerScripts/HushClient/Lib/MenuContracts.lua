-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuContracts

local v_u_1 = game:GetService("HttpService")
local v_u_2 = game:GetService("RunService")
local v3 = {}
local v_u_4 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_5 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_6 = {
	["view"] = nil,
	["json"] = "",
	["dirty"] = true,
	["skew"] = 0
}
local v_u_7 = nil
local v_u_8 = {
	["delivery"] = "DELIVERY",
	["mission"] = "MISSION"
}
function v3.addTab(p_u_9, p10) -- name: addTab
	local v11, v12 = pcall(function()
		-- upvalues: (copy) p_u_9
		return p_u_9.cctx.config.flag("Contracts")
	end)
	if v11 and v12 == true then
		table.insert(p10, {
			["id"] = "contracts",
			["text"] = "Contracts"
		})
	end
end
local function v_u_16(p13, p14) -- name: designWidth
	local v15 = p14:FindFirstAncestorWhichIsA("LayerCollector")
	if v15 then
		v15 = v15:FindFirstChild("Root")
	end
	if v15 and (v15:IsA("GuiObject") and (v15.AbsoluteSize.X > 40 and p14.AbsoluteSize.X > 1)) then
		return p14.AbsoluteSize.X / v15.AbsoluteSize.X * p13.theme.safeRefSize().X
	else
		return nil
	end
end
local function v_u_21(p17, p18) -- name: toDesign
	if p18 <= 0 then
		return nil
	end
	local v19 = 1
	while p17 do
		local v20 = p17:FindFirstChildOfClass("UIScale")
		if v20 then
			v19 = v19 * v20.Scale
		end
		p17 = p17.Parent
	end
	return p18 / math.max(0.05, v19)
end
local function v_u_26(p22) -- name: clock
	local v23 = math.floor(p22)
	local v24 = math.max(0, v23)
	local v25 = v24 / 60
	return ("%d:%02d"):format(math.floor(v25), v24 % 60)
end
function v3.draw(p_u_27, p_u_28, p_u_29, _) -- name: draw
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (ref) v_u_7, (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_26, (copy) v_u_16, (copy) v_u_21, (copy) v_u_1
	local v_u_30 = p_u_27.ui
	local v_u_31 = p_u_27.theme
	local v_u_32 = v_u_31.color
	local v_u_33 = p_u_27.kit
	local v34, v_u_35 = pcall(function()
		-- upvalues: (copy) p_u_27
		return p_u_27.cctx.shared.Contracts
	end)
	if not v34 or type(v_u_35) ~= "table" then
		v_u_35 = nil
	end
	local v36, v_u_37 = pcall(function()
		-- upvalues: (copy) p_u_27
		return p_u_27.cctx.shared.Traders
	end)
	if not v36 or type(v_u_37) ~= "table" then
		v_u_37 = nil
	end
	if not v_u_5[p_u_27] then
		v_u_5[p_u_27] = true
		if p_u_27.changed and p_u_27.changed.Connect then
			p_u_27.changed:Connect(function(p38, p39)
				-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (copy) p_u_27
				if p38 == "profile" then
					v_u_6.dirty = true
					local v40 = v_u_7
					if v40 and (v40.body.Parent and v_u_4[v40.body] == v40.gen) then
						v40.rerender()
						return
					end
				elseif p38 == "result" and type(p39) == "table" then
					local v41 = p39.op
					if type(v41) == "string" then
						local v42 = p39.op
						if string.sub(v42, 1, 8) == "contract" then
							v_u_6.dirty = true
							if p39.ok == true and p39.op == "contractHandIn" then
								local function v43()
									-- upvalues: (ref) p_u_27
									p_u_27.ui.sound(p_u_27.theme.sounds.purchase)
								end
								pcall(v43)
							end
							local v44 = v_u_7
							if v44 and (v44.body.Parent and v_u_4[v44.body] == v44.gen) then
								v44.refetch()
							end
						end
					end
				end
			end)
		end
	end
	local v_u_45 = (v_u_4[p_u_28] or 0) + 1
	v_u_4[p_u_28] = v_u_45
	local v_u_46 = p_u_27.compact()
	local v_u_47 = p_u_27.cctx
	if v_u_47 then
		v_u_47 = p_u_27.cctx.player
	end
	local v_u_48 = v_u_2:IsStudio()
	v_u_33.clear(p_u_28)
	if v_u_35 then
		local v49
		if v_u_37 and v_u_37.defs then
			v49 = v_u_37.defs[p_u_29]
		else
			v49 = nil
		end
		local v_u_50
		if v49 then
			v_u_50 = v49.name
		else
			v_u_50 = string.upper(p_u_29)
		end
		local v_u_51 = string.upper((string.sub(v_u_50, 1, 1))) .. string.lower((string.sub(v_u_50, 2)))
		local v_u_52 = {}
		local v_u_53 = nil
		local v_u_54 = {}
		local v_u_55 = {}
		local v_u_56 = 0
		local v_u_57 = 0
		local v_u_58 = ""
		local v_u_59 = false
		local v_u_60 = nil
		local v_u_61 = nil
		local function v_u_68(p62, p63, p64, p65, p66) -- name: confirm
			-- upvalues: (copy) v_u_30
			local v67 = {
				["title"] = nil,
				["body"] = nil,
				["width"] = 520,
				["buttons"] = nil,
				["title"] = p62,
				["body"] = p63,
				["buttons"] = {
					{
						["text"] = "Cancel"
					},
					{
						["text"] = p64,
						["kind"] = p65,
						["onClick"] = p66
					}
				}
			}
			v_u_30.modal(v67)
		end
		local function v_u_75(p69, p70, p71) -- name: send
			-- upvalues: (copy) p_u_27
			local v72 = {
				["op"] = p69,
				["slot"] = p70
			}
			for v73, v74 in p71 or {} do
				v72[v73] = v74
			end
			p_u_27.op(v72)
		end
		local function v_u_80(p76, p77, p78) -- name: infoCard
			-- upvalues: (copy) v_u_30
			local _, v79 = v_u_30.panel({
				["parent"] = nil,
				["name"] = nil,
				["raised"] = true,
				["autoY"] = true,
				["size"] = nil,
				["padding"] = 20,
				["layout"] = "v",
				["gap"] = 10,
				["order"] = nil,
				["parent"] = p76,
				["name"] = p77,
				["size"] = UDim2.new(1, 0, 0, 0),
				["order"] = p78
			})
			return v79
		end
		local function v_u_108(p81, p82) -- name: lockedPanel
			-- upvalues: (copy) v_u_80, (copy) v_u_30, (copy) v_u_32, (copy) v_u_35, (copy) v_u_51, (copy) v_u_37, (copy) p_u_27, (copy) p_u_29, (copy) v_u_33
			local v83 = v_u_80(p81, "Locked", 1)
			local v84 = v_u_30.new("Frame", {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 28)
			}, v83)
			v_u_30.icon("lock", {
				["parent"] = nil,
				["size"] = 20,
				["color"] = nil,
				["position"] = nil,
				["parent"] = v84,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(0, 4)
			})
			v_u_30.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v84,
				["text"] = ("Contracts open at LV %d"):format(v_u_35.MIN_LEVEL),
				["position"] = UDim2.fromOffset(30, 0),
				["size"] = UDim2.new(1, -30, 1, 0)
			})
			v_u_30.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["parent"] = v83,
				["text"] = ("Finish contracts for %s to earn cash and reputation. They open once you reach LV %d with %s."):format(v_u_51, v_u_35.MIN_LEVEL, v_u_51),
				["color"] = v_u_32.text2
			})
			local v85
			if v_u_37 then
				v85 = v_u_37.levelInfo(v_u_35.MIN_LEVEL)
			else
				v85 = nil
			end
			local v86 = p_u_27.profile
			if v85 and type(v86) == "table" then
				local v87 = v86.traders
				local v88
				if type(v87) == "table" then
					v88 = v86.traders[p_u_29] or nil
				else
					v88 = nil
				end
				local v89
				if type(v88) == "table" then
					local v90 = v88.rep
					v89 = tonumber(v90) or 0
				else
					v89 = 0
				end
				local v91 = v86.stats
				local v92
				if type(v91) == "table" then
					local v93 = v86.stats.extracts
					v92 = tonumber(v93) or 0
				else
					v92 = 0
				end
				local v94 = v_u_33.bar
				local v95 = {
					["label"] = "Reputation",
					["right"] = nil,
					["value"] = nil,
					["color"] = nil,
					["order"] = 3,
					["labelStyle"] = "body",
					["right"] = ("%d / %d"):format(v_u_37.points(v89), v_u_37.points(v85.rep))
				}
				local v96 = v85.rep
				local v97 = v89 / math.max(0.0001, v96)
				v95.value = math.clamp(v97, 0, 1)
				local v98
				if v89 + 1e-6 >= v85.rep then
					v98 = v_u_32.success
				else
					v98 = v_u_32.accent
				end
				v95.color = v98
				v94(v83, v95)
				local v99 = v_u_33.bar
				local v100 = {
					["label"] = "Extracts",
					["right"] = nil,
					["value"] = nil,
					["color"] = nil,
					["order"] = 4,
					["labelStyle"] = "body",
					["right"] = ("%d / %d"):format(v92, v85.extracts)
				}
				local v101 = v85.extracts
				local v102 = v92 / math.max(1, v101)
				v100.value = math.clamp(v102, 0, 1)
				local v103
				if v85.extracts <= v92 then
					v103 = v_u_32.success
				else
					v103 = v_u_32.accent
				end
				v100.color = v103
				v99(v83, v100)
			end
			v_u_30.label({
				["parent"] = nil,
				["name"] = "NextStep",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 5,
				["parent"] = v83,
				["text"] = ("How to get there: finish tasks for %s, sell to %s and extract from raids."):format(v_u_51, v_u_51),
				["color"] = v_u_32.text2
			})
			local v104 = v_u_30.label
			local v105 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["order"] = 6,
				["parent"] = v83
			}
			local v106 = v_u_51
			local v107 = p82.lvl
			v105.text = ("Your level with %s: LV %d"):format(v106, tonumber(v107) or 1)
			v105.color = v_u_32.muted
			v104(v105)
		end
		local function v_u_113(p109, p110) -- name: emptyCard
			-- upvalues: (copy) v_u_80, (copy) v_u_30, (copy) v_u_32
			local v111 = v_u_80(p109, "Empty", 1)
			local v112 = v_u_30.new("Frame", {
				["Name"] = "Line",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 24)
			}, v111)
			v_u_30.icon("info", {
				["parent"] = nil,
				["size"] = 18,
				["color"] = nil,
				["position"] = nil,
				["parent"] = v112,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(0, 3)
			})
			v_u_30.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v112,
				["text"] = p110,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(28, 0),
				["size"] = UDim2.new(1, -28, 1, 0)
			})
		end
		local function v_u_121(p114, p115, p116, p117, p118, p119) -- name: chip
			-- upvalues: (copy) v_u_30, (copy) v_u_32
			local v120 = v_u_30.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Chip" .. p115,
				["BackgroundColor3"] = v_u_32.bg,
				["Size"] = UDim2.new(p119.Scale, p119.Offset, 1, 0),
				["LayoutOrder"] = p115
			}, p114)
			v_u_30.stroke(v120, v_u_32.line)
			v_u_30.label({
				["parent"] = nil,
				["name"] = "Big",
				["text"] = nil,
				["style"] = "mono",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v120,
				["text"] = p116,
				["color"] = p118,
				["position"] = UDim2.fromOffset(10, 5),
				["size"] = UDim2.new(1, -20, 0, 22)
			})
			v_u_30.label({
				["parent"] = nil,
				["name"] = "Sub",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v120,
				["text"] = p117,
				["color"] = v_u_32.text2,
				["position"] = UDim2.fromOffset(10, 28),
				["size"] = UDim2.new(1, -20, 0, 16)
			})
			return v120
		end
		local function v_u_128(p122, p123, p124, p125, p126) -- name: stateBadge
			-- upvalues: (copy) v_u_30
			local v127 = v_u_30.new("Frame", {
				["Name"] = "State",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = p124,
				["Size"] = UDim2.fromOffset(0, 20),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = p126
			}, p122)
			v_u_30.pad(v127, {
				6,
				6,
				0,
				0
			})
			v_u_30.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["parent"] = v127,
				["text"] = p123,
				["color"] = p125,
				["size"] = UDim2.fromOffset(0, 20)
			})
			return v127
		end
		local function v_u_139(p129, p130, p131, p132, p133) -- name: lineBar
			-- upvalues: (copy) v_u_33, (copy) v_u_32
			local v134 = v_u_33.bar
			local v135 = {
				["label"] = nil,
				["right"] = nil,
				["value"] = nil,
				["color"] = nil,
				["order"] = nil,
				["labelStyle"] = "body",
				["label"] = p130,
				["right"] = ("%d / %d"):format(p131, p132)
			}
			local v136 = p131 / math.max(1, p132)
			v135.value = math.clamp(v136, 0, 1)
			local v137
			if p132 <= p131 then
				v137 = v_u_32.success
			else
				v137 = v_u_32.accent
			end
			v135.color = v137
			v135.order = p133
			local v138 = v134(p129, v135)
			if v138.left then
				v138.left.Size = UDim2.new(1, -88, 0, 20)
			end
			if v138.right then
				v138.right.Position = UDim2.new(1, -84, 0, 0)
				v138.right.Size = UDim2.fromOffset(84, 20)
			end
			return v138
		end
		local v_u_140 = v_u_31.touch(44)
		local function v_u_280(p141, p142, p143, _, p_u_144, p145) -- name: buildCard
			-- upvalues: (copy) v_u_35, (copy) v_u_32, (copy) v_u_30, (ref) v_u_8, (copy) v_u_128, (copy) v_u_139, (copy) v_u_33, (copy) v_u_37, (copy) v_u_51, (copy) v_u_121, (copy) v_u_50, (copy) v_u_140, (copy) v_u_52, (copy) p_u_27, (copy) v_u_75, (copy) v_u_54, (ref) v_u_26, (ref) v_u_56, (ref) v_u_6, (copy) v_u_55, (copy) v_u_68
			local v146 = v_u_35.get(p_u_144.tpl)
			if not v146 then
				return nil
			end
			local v_u_147 = p_u_144.state
			local v_u_148 = p_u_144.slot
			local v_u_149 = v146.kind == "mission"
			local v150
			if v_u_147 == "ready" then
				v150 = v_u_32.success
			elseif v_u_147 == "taken" then
				v150 = v_u_32.accent
			elseif v_u_147 == "done" then
				v150 = v_u_32.muted
			else
				v150 = nil
			end
			local v151, v152 = v_u_30.panel({
				["parent"] = nil,
				["name"] = nil,
				["raised"] = true,
				["autoY"] = true,
				["size"] = nil,
				["padding"] = 14,
				["layout"] = "v",
				["gap"] = 10,
				["accent"] = nil,
				["order"] = nil,
				["parent"] = p141,
				["name"] = "Card_" .. v_u_148,
				["size"] = p142,
				["accent"] = v150,
				["order"] = p_u_144.index
			})
			local v153 = 0
			local v154 = v_u_30.new
			local v155 = {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 20)
			}
			v153 = v153 + 1
			v155.LayoutOrder = v153
			local v156 = v154("Frame", v155, v152)
			local v157 = v_u_30.new("Frame", {
				["Name"] = "Left",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.new(0.8, 0, 1, 0)
			}, v156)
			v_u_30.layout(v157, "h", 6)
			local v158 = v_u_30.badge(v_u_8[v146.kind] or string.upper(v146.kind), v_u_149 and "accent" or "info", {
				["parent"] = nil,
				["order"] = 1,
				["height"] = 20,
				["parent"] = v157
			})
			if v_u_149 then
				v_u_30.tooltip(v158, function()
					return {
						["title"] = "Mission",
						["body"] = "Counts on its own in raids. Hard counts double, Nightmare triple."
					}
				end)
			end
			if v_u_147 == "ready" then
				v_u_128(v157, "READY", v_u_32.success, v_u_32.ink, 2)
			elseif v_u_147 == "taken" then
				v_u_128(v157, "TAKEN", v_u_32.accent, v_u_32.ink, 2)
			elseif v_u_147 == "done" then
				v_u_128(v157, "DONE", v_u_32.lineStrong, v_u_32.text, 2)
			end
			v_u_30.badge(("LV %d"):format(v146.lvl), "muted", {
				["parent"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["height"] = 20,
				["parent"] = v156,
				["position"] = UDim2.new(1, 0, 0, 0),
				["anchor"] = Vector2.new(1, 0)
			})
			local v159 = v_u_30.label
			local v160 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h3",
				["color"] = nil,
				["size"] = nil,
				["order"] = nil,
				["parent"] = v152,
				["text"] = v146.title
			}
			local v161
			if v_u_147 == "done" then
				v161 = v_u_32.text2
			else
				v161 = v_u_32.text
			end
			v160.color = v161
			v160.size = UDim2.new(1, 0, 0, 24)
			v153 = v153 + 1
			v160.order = v153
			v159(v160)
			local v162 = v_u_30.label
			local v163 = {
				["parent"] = nil,
				["name"] = "Blurb",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v152,
				["text"] = v146.blurb,
				["color"] = v_u_32.text2
			}
			v153 = v153 + 1
			v163.order = v153
			v162(v163)
			local v164 = v_u_30.divider({
				["parent"] = v152,
				["size"] = UDim2.new(1, 0, 0, 1),
				["position"] = UDim2.new()
			})
			v153 = v153 + 1
			v164.LayoutOrder = v153
			local v165 = v_u_30.new
			local v166 = {
				["Name"] = "Lines",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}
			v153 = v153 + 1
			v166.LayoutOrder = v153
			local v167 = v165("Frame", v166, v152)
			v_u_30.layout(v167, "v", 4)
			local v168 = {}
			local v169
			if v_u_149 then
				v169 = v153
				for v170, v171 in v146.objectives do
					local v172 = p_u_144.progress
					local v173
					if type(v172) == "table" then
						local v174 = p_u_144.progress[v170]
						v173 = tonumber(v174) or 0
					else
						v173 = 0
					end
					local v175 = v171.count
					if v_u_147 == "done" then
						v173 = v175
					end
					local v176 = v_u_139(v167, v171.desc, v173, v175, v170)
					local v177 = v_u_35.objectiveHow(v171)
					local v178 = (v177 and 1 or 0) + (v171.hint and 1 or 0)
					local v179 = v_u_147 == "done" and 0 or v178
					v176.frame.Size = UDim2.new(1, 0, 0, v179 * 16 + 40)
					if v179 > 0 then
						local v180 = 22
						if v177 then
							v_u_30.label({
								["parent"] = nil,
								["name"] = "How",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v176.frame,
								["text"] = v177,
								["color"] = v_u_32.info,
								["position"] = UDim2.fromOffset(0, v180),
								["size"] = UDim2.new(1, 0, 0, 16)
							})
							v180 = v180 + 16
						end
						if v171.hint then
							v_u_30.label({
								["parent"] = nil,
								["name"] = "Hint",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v176.frame,
								["text"] = v171.hint,
								["color"] = v_u_32.text2,
								["position"] = UDim2.fromOffset(0, v180),
								["size"] = UDim2.new(1, 0, 0, 16)
							})
						end
					end
					local v181 = v171.desc
					table.insert(v168, ("%s %d/%d"):format(v181, v173, v175))
				end
			else
				v169 = v153
				for v182, v_u_183 in v146.lines do
					local v184 = p_u_144.have
					local v185
					if type(v184) == "table" then
						local v186 = p_u_144.have[v182]
						v185 = tonumber(v186) or 0
					else
						v185 = 0
					end
					local v187 = v_u_183.n
					if v_u_147 == "done" then
						v185 = v187
					end
					local v188 = v_u_139(v167, v_u_183.name, v185, v187, v182)
					local v_u_189 = {}
					for _, v190 in v_u_183.ids do
						local v191 = v_u_33.itemName
						table.insert(v_u_189, v191(v190))
					end
					v_u_30.tooltip(v188.frame, function()
						-- upvalues: (copy) v_u_183, (copy) v_u_189
						return {
							["title"] = v_u_183.name,
							["body"] = "Accepted: " .. table.concat(v_u_189, ", ")
						}
					end)
					local v192 = v_u_183.name
					table.insert(v168, ("%s %d/%d"):format(v192, v185, v187))
				end
			end
			if not v_u_149 then
				local v193 = v_u_30.label
				local v194 = {
					["parent"] = nil,
					["name"] = "Rule",
					["text"] = "Stash goods at 50% condition or better. Attachments and loaded rounds come back to you.",
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v152,
					["color"] = v_u_32.text2
				}
				v153 = v169 + 1
				v194.order = v153
				v193(v194)
				v169 = v153
			end
			local v195 = not v_u_37 and "+4 REP" or v_u_37.gainText(v_u_35.REP)
			if v_u_147 == "done" then
				local v196 = { "Paid" }
				local v197 = p_u_144.paid
				if tonumber(v197) then
					local v198 = v_u_33.money
					local v199 = p_u_144.paid
					table.insert(v196, v198(v199))
				elseif v_u_149 then
					local v200 = v_u_33.money
					local v201 = p_u_144.reward
					table.insert(v196, v200(v201))
				end
				local v202 = v195 .. " with " .. v_u_51
				table.insert(v196, v202)
				local v203 = v_u_30.label
				local v204 = {
					["parent"] = nil,
					["name"] = "Paid",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v152,
					["text"] = table.concat(v196, "  \194\183  "),
					["color"] = v_u_32.text2
				}
				v153 = v169 + 1
				v204.order = v153
				v203(v204)
			else
				local v205 = v_u_30.new
				local v206 = {
					["Name"] = "Reward",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 50)
				}
				v153 = v169 + 1
				v206.LayoutOrder = v153
				local v207 = v205("Frame", v206, v152)
				v_u_30.layout(v207, "h", 8)
				local v208, v209
				if v_u_149 then
					v208 = v_u_33.money(p_u_144.reward)
					v209 = "Cash"
				elseif p_u_144.est == true then
					v208 = "About " .. v_u_33.money(p_u_144.reward)
					v209 = "75% of " .. v_u_51 .. "\'s price"
				else
					v208 = v_u_33.money(p_u_144.reward)
					v209 = "75% of " .. v_u_51 .. "\'s price"
				end
				local v210 = v_u_121(v207, 1, v208, v209, v_u_32.accent, UDim.new(0.58, -4))
				v_u_30.tooltip(v210, function()
					-- upvalues: (copy) v_u_149, (ref) v_u_51
					return v_u_149 and {
						["title"] = "Cash reward",
						["body"] = "Paid when you hand in the finished contract."
					} or {
						["title"] = "Cash reward",
						["body"] = nil,
						["body"] = "You get 75% of what " .. v_u_51 .. " pays for exactly the goods you hand in. Worn goods pay less. Attachments and loaded rounds are not paid, you get them back. The number is the price of the goods as they are now."
					}
				end)
				v_u_121(v207, 2, v195, v_u_50, v_u_32.info, UDim.new(0.42, -4))
			end
			local v211 = v_u_30.new
			local v212 = {
				["Name"] = "ActionsSpace",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, v_u_140)
			}
			v153 = v153 + 1
			v212.LayoutOrder = v153
			v211("Frame", v212, v152)
			local v213 = v_u_30.new("Frame", {
				["Name"] = "Actions",
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 14, 1, -14),
				["Size"] = UDim2.new(1, -28, 0, v_u_140)
			}, v151)
			v_u_30.layout(v213, "h", 8, "center")
			local v_u_214 = {}
			v_u_52[v_u_148] = v_u_214
			local v215 = nil
			local v_u_216 = false
			local v217 = nil
			local v_u_218 = true
			local v_u_219
			if p_u_144.left == nil then
				v_u_219 = true
			else
				local v220 = p_u_144.left
				v_u_219 = (tonumber(v220) or 0) > 0
			end
			local v221 = p_u_27.profile
			if v221 then
				v221 = p_u_27.profile.cash
			end
			local v_u_222 = tonumber(v221) or 0
			local v223 = p143.rerollPrice
			local v_u_224 = tonumber(v223) or v_u_35.REROLL_PRICE
			local v225
			if v_u_147 == "open" then
				if v_u_219 then
					v225 = v_u_222 < v_u_224
				else
					v225 = v_u_219
				end
			else
				v225 = false
			end
			if v_u_147 == "open" then
				v215 = "Take"
				v_u_216 = true
				if v_u_219 then
					v217 = "Reroll  " .. v_u_33.money(v_u_224)
					v_u_218 = not v225
				else
					v217 = "No other offer"
					v_u_218 = false
				end
			elseif v_u_147 == "taken" then
				if not v_u_149 then
					v215 = "Hand in"
					v_u_216 = false
				end
				v217 = "Drop"
			elseif v_u_147 == "ready" then
				v215 = v_u_149 and "Claim reward" or "Hand in"
				v217 = "Drop"
				v_u_216 = true
			end
			local v_u_226 = false
			local v_u_227 = {}
			local function v228() -- name: shortToast
				-- upvalues: (ref) v_u_30, (ref) v_u_33, (copy) v_u_224, (copy) v_u_222
				v_u_30.toast("Not enough cash", "danger", ("A new contract costs %s. You are %s short."):format(v_u_33.money(v_u_224), v_u_33.money(v_u_224 - v_u_222)))
			end
			local function v_u_229() -- name: doTake
				-- upvalues: (ref) v_u_75, (copy) v_u_148, (copy) p_u_144
				v_u_75("contractTake", v_u_148, {
					["tpl"] = p_u_144.tpl
				})
			end
			local function v_u_230() -- name: doHandIn
				-- upvalues: (ref) v_u_75, (copy) v_u_148
				v_u_75("contractHandIn", v_u_148)
			end
			local function v_u_231() -- name: doDrop
				-- upvalues: (ref) v_u_75, (copy) v_u_148
				v_u_75("contractAbandon", v_u_148)
			end
			local function v_u_232() -- name: doReroll
				-- upvalues: (copy) v_u_222, (copy) v_u_224, (ref) v_u_30, (ref) v_u_33, (ref) v_u_75, (copy) v_u_148
				if v_u_222 < v_u_224 then
					v_u_30.toast("Not enough cash", "danger", ("A new contract costs %s. You are %s short."):format(v_u_33.money(v_u_224), v_u_33.money(v_u_224 - v_u_222)))
				else
					v_u_75("contractReroll", v_u_148)
				end
			end
			if v_u_147 == "open" then
				function v_u_214.take()
					-- upvalues: (ref) v_u_226, (copy) v_u_227, (ref) v_u_216, (ref) v_u_218, (copy) v_u_229
					if not v_u_226 then
						v_u_226 = true
						for _, v233 in v_u_227 do
							local v234 = v233.setEnabled
							pcall(v234, false)
						end
						task.delay(4, function()
							-- upvalues: (ref) v_u_226, (ref) v_u_227, (ref) v_u_216, (ref) v_u_218
							v_u_226 = false
							for v235, v236 in v_u_227 do
								if not v236.btn.Parent then
									continue
								end
								local v237 = v236.setEnabled
								local v238
								if v235 == "Primary" then
									v238 = v_u_216
								else
									v238 = v_u_218
								end
								pcall(v237, v238)
							end
						end)
						v_u_229()
					end
				end
				if v_u_219 then
					function v_u_214.reroll()
						-- upvalues: (ref) v_u_226, (copy) v_u_227, (ref) v_u_216, (ref) v_u_218, (copy) v_u_232
						if not v_u_226 then
							v_u_226 = true
							for _, v239 in v_u_227 do
								local v240 = v239.setEnabled
								pcall(v240, false)
							end
							task.delay(4, function()
								-- upvalues: (ref) v_u_226, (ref) v_u_227, (ref) v_u_216, (ref) v_u_218
								v_u_226 = false
								for v241, v242 in v_u_227 do
									if not v242.btn.Parent then
										continue
									end
									local v243 = v242.setEnabled
									local v244
									if v241 == "Primary" then
										v244 = v_u_216
									else
										v244 = v_u_218
									end
									pcall(v243, v244)
								end
							end)
							v_u_232()
						end
					end
				end
			elseif v_u_147 == "taken" or v_u_147 == "ready" then
				function v_u_214.handin()
					-- upvalues: (ref) v_u_226, (copy) v_u_227, (ref) v_u_216, (ref) v_u_218, (copy) v_u_230
					if not v_u_226 then
						v_u_226 = true
						for _, v245 in v_u_227 do
							local v246 = v245.setEnabled
							pcall(v246, false)
						end
						task.delay(4, function()
							-- upvalues: (ref) v_u_226, (ref) v_u_227, (ref) v_u_216, (ref) v_u_218
							v_u_226 = false
							for v247, v248 in v_u_227 do
								if not v248.btn.Parent then
									continue
								end
								local v249 = v248.setEnabled
								local v250
								if v247 == "Primary" then
									v250 = v_u_216
								else
									v250 = v_u_218
								end
								pcall(v249, v250)
							end
						end)
						v_u_230()
					end
				end
				function v_u_214.abandon()
					-- upvalues: (ref) v_u_226, (copy) v_u_227, (ref) v_u_216, (ref) v_u_218, (copy) v_u_231
					if not v_u_226 then
						v_u_226 = true
						for _, v251 in v_u_227 do
							local v252 = v251.setEnabled
							pcall(v252, false)
						end
						task.delay(4, function()
							-- upvalues: (ref) v_u_226, (ref) v_u_227, (ref) v_u_216, (ref) v_u_218
							v_u_226 = false
							for v253, v254 in v_u_227 do
								if not v254.btn.Parent then
									continue
								end
								local v255 = v254.setEnabled
								local v256
								if v253 == "Primary" then
									v256 = v_u_216
								else
									v256 = v_u_218
								end
								pcall(v255, v256)
							end
						end)
						v_u_231()
					end
				end
			end
			local v257 = v215 ~= nil
			if v_u_147 == "done" then
				v_u_30.icon("check", {
					["parent"] = nil,
					["size"] = 16,
					["color"] = nil,
					["order"] = 1,
					["parent"] = v213,
					["color"] = v_u_32.success
				})
				local v258 = v_u_54
				local v259 = v_u_30.label
				local v260 = {
					["parent"] = nil,
					["name"] = "DoneText",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["size"] = nil,
					["order"] = 2,
					["parent"] = v213,
					["text"] = ("Finished. A new contract comes in %s"):format(v_u_26(v_u_56 - (os.time() + v_u_6.skew))),
					["color"] = v_u_32.text2,
					["size"] = UDim2.new(1, -24, 1, 0)
				}
				table.insert(v258, v259(v260))
			else
				if v257 then
					local v261, v262 = v_u_30.button({
						["parent"] = nil,
						["name"] = "Primary",
						["text"] = nil,
						["kind"] = nil,
						["icon"] = nil,
						["size"] = nil,
						["disabled"] = nil,
						["order"] = 1,
						["onClick"] = nil,
						["parent"] = v213,
						["text"] = v215,
						["kind"] = (v_u_147 == "ready" or v_u_147 == "open") and "primary" or "secondary",
						["icon"] = v_u_147 == "open" and "task" or "check",
						["size"] = UDim2.new(v217 and 0.5 or 1, v217 and -4 or 0, 1, 0),
						["disabled"] = not v_u_216,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_147, (copy) v_u_214
							if v_u_147 == "open" then
								v_u_214.take()
							else
								v_u_214.handin()
							end
						end
					})
					v_u_227.Primary = {
						["btn"] = v261,
						["setEnabled"] = v262.setEnabled
					}
					local v263 = v_u_55
					table.insert(v263, v261)
					if not v_u_216 then
						v_u_30.tooltip(v261, function()
							return {
								["title"] = "Not yet",
								["body"] = "Gather every item the contract asks for, then hand it in."
							}
						end)
					end
				else
					v_u_30.label({
						["parent"] = nil,
						["name"] = "Waiting",
						["text"] = "Counts in raids on its own",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["size"] = nil,
						["order"] = 1,
						["parent"] = v213,
						["color"] = v_u_32.text2,
						["size"] = UDim2.new(0.5, -4, 1, 0)
					})
				end
				if v217 then
					local v264, v265 = v_u_30.button({
						["parent"] = nil,
						["name"] = "Secondary",
						["text"] = nil,
						["kind"] = "secondary",
						["icon"] = nil,
						["size"] = nil,
						["disabled"] = nil,
						["order"] = 2,
						["onClick"] = nil,
						["parent"] = v213,
						["text"] = v217,
						["icon"] = v_u_147 == "open" and (v_u_219 and "cash" or "clock") or "close",
						["size"] = UDim2.new(0.5, -4, 1, 0),
						["disabled"] = not v_u_218,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_147, (copy) v_u_219, (ref) v_u_68, (ref) v_u_33, (copy) v_u_224, (copy) v_u_214
							if v_u_147 == "open" then
								if v_u_219 then
									v_u_68("Reroll this contract?", ("The offer is replaced by the next one. It costs %s."):format(v_u_33.money(v_u_224)), "Reroll", "primary", v_u_214.reroll)
								end
							else
								v_u_68("Drop this contract?", "Progress on it is lost. The slot shows the current offer again.", "Drop", "danger", v_u_214.abandon)
								return
							end
						end
					})
					v_u_227.Secondary = {
						["btn"] = v264,
						["setEnabled"] = v265.setEnabled
					}
					local v266 = v_u_55
					table.insert(v266, v264)
					if v_u_147 == "open" and not v_u_219 then
						v_u_30.tooltip(v264, function()
							return {
								["title"] = "No other offer",
								["body"] = "Every other contract this trader has for you was already shown in this slot. New ones come with the restock."
							}
						end)
					elseif v225 then
						v264.Activated:Connect(v228)
						v_u_30.tooltip(v264, function()
							-- upvalues: (ref) v_u_33, (copy) v_u_224, (copy) v_u_222
							return {
								["title"] = "Not enough cash",
								["body"] = nil,
								["body"] = ("A new contract costs %s. You are %s short."):format(v_u_33.money(v_u_224), v_u_33.money(v_u_224 - v_u_222))
							}
						end)
					end
				end
			end
			local v267 = v146.title
			local v268 = table.concat(v168, ";")
			local v269 = p_u_144.reward
			local v270 = tostring(v269)
			local v271 = p_u_144.est and "~" or ""
			local v272 = p_u_144.paid
			local v273 = tostring(v272)
			local v274 = tostring(v215)
			local v275 = tostring(v_u_216)
			local v276 = tostring(v217)
			local v277 = tostring(v_u_218)
			local v278 = p_u_144.left
			local v279 = tostring(v278)
			table.insert(p145, ("%s|%s|%s|%s|reward=%s%s|paid=%s|btn1=%s/%s|btn2=%s/%s|left=%s"):format(v_u_148, v_u_147, v267, v268, v270, v271, v273, v274, v275, v276, v277, v279))
			return {
				["card"] = v151,
				["content"] = v152
			}
		end
		local function v_u_354(p281) -- name: render
			-- upvalues: (ref) v_u_59, (copy) v_u_33, (copy) p_u_28, (copy) v_u_52, (copy) v_u_54, (copy) v_u_55, (ref) v_u_53, (copy) p_u_29, (copy) v_u_113, (ref) v_u_56, (ref) v_u_60, (copy) p_u_27, (copy) v_u_35, (copy) v_u_30, (copy) v_u_108, (copy) v_u_50, (copy) v_u_32, (ref) v_u_6, (copy) v_u_31, (copy) v_u_46, (ref) v_u_16, (copy) v_u_280, (ref) v_u_21, (copy) v_u_48, (copy) v_u_47
			v_u_59 = true
			v_u_33.clear(p_u_28)
			table.clear(v_u_52)
			table.clear(v_u_54)
			table.clear(v_u_55)
			v_u_53 = nil
			if type(p281) == "table" and p281.enabled == true then
				local v282 = p281.traders
				if type(v282) == "table" then
					local v283 = p281.traders[p_u_29]
					if type(v283) == "table" then
						local v284 = v283.nextAt
						v_u_56 = tonumber(v284) or 0
						local v285 = p_u_27.profile
						if v285 then
							v285 = p_u_27.profile.cash
						end
						local v286 = tonumber(v285) or 0
						local v287 = p281.rerollPrice
						v_u_60 = (tonumber(v287) or v_u_35.REROLL_PRICE) <= v286
						local v_u_288 = v_u_30.list({
							["parent"] = nil,
							["name"] = "Contracts",
							["size"] = nil,
							["gap"] = 12,
							["padding"] = nil,
							["parent"] = p_u_28,
							["size"] = UDim2.fromScale(1, 1),
							["padding"] = {
								0,
								0,
								2,
								8
							}
						})
						v_u_288.VerticalScrollBarInset = Enum.ScrollBarInset.None
						local v289 = {}
						if v283.locked == true then
							v_u_108(v_u_288, v283)
							local v290 = v283.lvl
							local v291 = "locked lvl=" .. tostring(v290)
							table.insert(v289, v291)
						else
							local v292 = v_u_30.new("Frame", {
								["Name"] = "Top",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 1,
								["Size"] = UDim2.new(1, 0, 0, 26)
							}, v_u_288)
							local v293 = 0
							local v294 = 0
							for _, v295 in v283.slots do
								if v295.state == "taken" or v295.state == "ready" then
									v293 = v293 + 1
								else
									if v295.state ~= "done" then
										continue
									end
									v294 = v294 + 1
								end
							end
							v_u_30.label({
								["parent"] = nil,
								["name"] = "Summary",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["size"] = nil,
								["parent"] = v292,
								["text"] = ("%s  \194\183  %d of %d taken  \194\183  %d done this restock"):format(v_u_50, v293, v_u_35.SLOTS, v294),
								["color"] = v_u_32.text2,
								["size"] = UDim2.new(1, -176, 1, 0)
							})
							local v296 = v_u_30.new("Frame", {
								["Name"] = "Restock",
								["BackgroundTransparency"] = 1,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["AnchorPoint"] = Vector2.new(1, 0),
								["Position"] = UDim2.new(1, 0, 0, 0),
								["Size"] = UDim2.new(0, 0, 1, 0),
								["AutomaticSize"] = Enum.AutomaticSize.X
							}, v292)
							v_u_30.layout(v296, "h", 8)
							v_u_30.icon("clock", {
								["parent"] = nil,
								["size"] = 14,
								["color"] = nil,
								["order"] = 1,
								["parent"] = v296,
								["color"] = v_u_32.text2
							})
							local v297 = v_u_30.label({
								["parent"] = nil,
								["name"] = "Countdown",
								["text"] = "",
								["style"] = "monoS",
								["color"] = nil,
								["autoX"] = true,
								["align"] = "right",
								["order"] = 2,
								["parent"] = v296,
								["color"] = v_u_32.text2
							})
							local v298 = v_u_30.setText
							local v299 = v_u_56 - (os.time() + v_u_6.skew)
							local v300 = math.floor(v299)
							local v301 = math.max(0, v300)
							local v302 = v301 / 60
							v298(v297, "Restock in " .. ("%d:%02d"):format(math.floor(v302), v301 % 60))
							v_u_53 = v297
							local v_u_303 = v_u_30.new("Frame", {
								["Name"] = "Cards",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["LayoutOrder"] = 2,
								["Size"] = UDim2.new(1, 0, 0, 0),
								["AutomaticSize"] = Enum.AutomaticSize.Y
							}, v_u_288)
							v_u_30.new("UIListLayout", {
								["FillDirection"] = nil,
								["Wraps"] = true,
								["SortOrder"] = nil,
								["Padding"] = nil,
								["VerticalAlignment"] = nil,
								["FillDirection"] = Enum.FillDirection.Horizontal,
								["SortOrder"] = Enum.SortOrder.LayoutOrder,
								["Padding"] = UDim.new(0, 12),
								["VerticalAlignment"] = Enum.VerticalAlignment.Top
							}, v_u_303)
							local v_u_304 = v_u_31.safeRefSize().X - 48 - (v_u_46 and 210 or 290) - 1 - 36
							local v305 = v_u_16(p_u_27, v_u_288)
							if not v305 or v305 >= v_u_304 then
								v305 = v_u_304
							end
							local v306 = v305 - 4
							local v307 = math.max(300, v306)
							local v308 = v_u_46 or v_u_31.isTouch()
							local v309 = v_u_31.isPhone()
							local v310 = (v307 + 12) / ((v309 and 340 or 300) + 12)
							local v311 = math.floor(v310)
							local v_u_312 = math.clamp(v311, 1, 3)
							if v308 and v307 < 1100 then
								v_u_312 = math.min(v_u_312, 2)
							end
							local v_u_313 = {}
							for _, v314 in v283.slots do
								local v315 = v_u_280
								local v316 = UDim2.new
								local v317 = 1 / v_u_312
								local v318 = (v_u_312 - 1) * 12 / v_u_312
								local v319 = v315(v_u_303, v316(v317, -(math.ceil(v318) + 1), 0, 0), p281, v283, v314, v289)
								if not v319 then
									continue
								end
								table.insert(v_u_313, v319)
							end
							for v320 = 1, #v_u_55 - 1 do
								v_u_55[v320].NextSelectionRight = v_u_55[v320 + 1]
								v_u_55[v320 + 1].NextSelectionLeft = v_u_55[v320]
							end
							local function v_u_330() -- name: equalize
								-- upvalues: (copy) v_u_303, (copy) v_u_313, (ref) v_u_21, (copy) v_u_288
								if v_u_303.Parent then
									local v321 = 0
									for _, v322 in v_u_313 do
										local v323 = v_u_21(v322.content, v322.content.AbsoluteSize.Y)
										if not v323 then
											continue
										end
										v321 = math.max(v321, v323)
									end
									local v324 = {}
									for _, v325 in v_u_313 do
										if v321 > 0 then
											local v326 = v325.card.Size
											v325.card.Size = UDim2.new(v326.X.Scale, v326.X.Offset, 0, (math.ceil(v321)))
										end
										local v327 = v325.card.AbsoluteSize.Y + 0.5
										local v328 = math.floor(v327)
										local v329 = tostring(v328)
										table.insert(v324, v329)
									end
									v_u_288:SetAttribute("CardHeights", table.concat(v324, ","))
								end
							end
							local v_u_331 = false
							local function v332() -- name: scheduleEqualize
								-- upvalues: (ref) v_u_331, (copy) v_u_330
								if not v_u_331 then
									v_u_331 = true
									task.defer(function()
										-- upvalues: (ref) v_u_331, (ref) v_u_330
										v_u_331 = false
										v_u_330()
									end)
								end
							end
							local v333 = v_u_312
							local v_u_334 = v_u_331
							for _, v335 in v_u_313 do
								v335.content:GetPropertyChangedSignal("AbsoluteSize"):Connect(v332)
							end
							v_u_288:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
								-- upvalues: (ref) v_u_16, (ref) p_u_27, (copy) v_u_288, (copy) v_u_304, (ref) v_u_31, (ref) v_u_312, (copy) v_u_313, (ref) v_u_334, (copy) v_u_330
								local v336 = v_u_16(p_u_27, v_u_288)
								if v336 then
									local v337 = v_u_304
									local v338 = math.min(v336, v337) - 4
									local v339 = math.max(300, v338)
									local v340 = p_u_27.compact() or v_u_31.isTouch()
									local v341 = v_u_31.isPhone()
									local v342 = (v339 + 12) / ((v341 and 340 or 300) + 12)
									local v343 = math.floor(v342)
									local v344 = math.clamp(v343, 1, 3)
									if v340 and v339 < 1100 then
										v344 = math.min(v344, 2)
									end
									if v344 ~= v_u_312 then
										v_u_312 = v344
										v_u_288:SetAttribute("Cols", v344)
										for _, v345 in v_u_313 do
											local v346 = v345.card
											local v347 = UDim2.new
											local v348 = 1 / v344
											local v349 = (v344 - 1) * 12 / v344
											v346.Size = v347(v348, -(math.ceil(v349) + 1), 0, 0)
										end
										if v_u_334 then
											return
										end
										v_u_334 = true
										task.defer(function()
											-- upvalues: (ref) v_u_334, (ref) v_u_330
											v_u_334 = false
											v_u_330()
										end)
									end
								end
							end)
							local v350 = v_u_30.label
							local v351 = {
								["parent"] = nil,
								["name"] = "Footnote",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 3,
								["parent"] = v_u_288
							}
							local v352 = v283.sec
							local v353 = (tonumber(v352) or 0) / 60 + 0.5
							v351.text = ("Contracts restock every %d minutes. A taken contract stays until you finish it or drop it. A new offer costs %s, and a slot has only a few offers per restock. Missions count on their own in raids: Hard counts double, Nightmare triple. Deliveries use the cheapest fitting goods first."):format(math.floor(v353), v_u_33.money(p281.rerollPrice or v_u_35.REROLL_PRICE))
							v351.color = v_u_32.text2
							v350(v351)
							v_u_288:SetAttribute("Cols", v333)
							if not v_u_334 then
								v_u_331 = true
								task.defer(function()
									-- upvalues: (ref) v_u_331, (copy) v_u_330
									v_u_331 = false
									v_u_330()
								end)
							end
						end
						if v_u_48 and v_u_47 then
							v_u_47:SetAttribute("DevContractDump", table.concat(v289, " || "))
						end
					else
						v_u_113(p_u_28, "No contracts from this trader.")
					end
				end
			end
			v_u_33.empty(p_u_28, "Contracts are not available right now.")
		end
		local function v_u_362() -- name: tickCountdown
			-- upvalues: (ref) v_u_53, (ref) v_u_56, (ref) v_u_6, (copy) v_u_30, (copy) v_u_54, (ref) v_u_26, (ref) v_u_57, (ref) v_u_61
			local v355 = v_u_53
			if v355 and v355.Parent then
				local v356 = v_u_56 - (os.time() + v_u_6.skew)
				local v357 = v_u_30.setText
				local v358 = math.floor(v356)
				local v359 = math.max(0, v358)
				local v360 = v359 / 60
				v357(v355, "Restock in " .. ("%d:%02d"):format(math.floor(v360), v359 % 60))
				for _, v361 in v_u_54 do
					if not v361.Parent then
						continue
					end
					v_u_30.setText(v361, ("Finished. A new contract comes in %s"):format(v_u_26(v356)))
				end
				if v356 <= 0 and (v_u_56 > 0 and v_u_57 ~= v_u_56) then
					v_u_57 = v_u_56
					v_u_6.dirty = true
					v_u_61()
				end
			end
		end
		v_u_61 = function() -- name: refetch
			-- upvalues: (copy) p_u_27, (ref) v_u_4, (copy) p_u_28, (copy) v_u_45, (ref) v_u_59, (copy) v_u_33, (ref) v_u_6, (ref) v_u_1, (ref) v_u_58, (copy) v_u_30, (copy) v_u_354, (copy) v_u_362
			task.spawn(function()
				-- upvalues: (ref) p_u_27, (ref) v_u_4, (ref) p_u_28, (ref) v_u_45, (ref) v_u_59, (ref) v_u_33, (ref) v_u_6, (ref) v_u_1, (ref) v_u_58, (ref) v_u_30, (ref) v_u_354, (ref) v_u_362
				local v_u_363 = p_u_27.fetch("contracts", nil, 0)
				local v364
				if v_u_4[p_u_28] == v_u_45 then
					v364 = p_u_28.Parent ~= nil
				else
					v364 = false
				end
				if v364 then
					if type(v_u_363) == "table" then
						v_u_6.view = v_u_363
						v_u_6.dirty = false
						local v365 = v_u_363.now
						if type(v365) == "number" then
							v_u_6.skew = v_u_363.now - os.time()
						end
						local v366 = v_u_1.JSONEncode
						local v367 = v_u_1
						local v368, v369 = pcall(v366, v367, v_u_363)
						if not v368 then
							local v370 = os.clock
							v369 = tostring(v370())
						end
						local v371 = string.gsub(v369, "\"now\":%d+", "")
						if not v_u_59 or v371 ~= v_u_58 then
							v_u_58 = v371
							if v_u_59 then
								v_u_30.keepScroll(p_u_28, function()
									-- upvalues: (ref) v_u_354, (copy) v_u_363
									v_u_354(v_u_363)
								end)
							else
								v_u_354(v_u_363)
							end
							v_u_362()
						end
					else
						if not v_u_59 then
							v_u_33.clear(p_u_28)
							v_u_33.empty(p_u_28, "Contracts are not available right now.")
						end
						return
					end
				else
					return
				end
			end)
		end
		v_u_7 = {
			["body"] = p_u_28,
			["gen"] = v_u_45,
			["refetch"] = v_u_61,
			["rerender"] = function() -- name: rerender
				-- upvalues: (ref) v_u_4, (copy) p_u_28, (copy) v_u_45, (ref) v_u_59, (ref) v_u_6, (copy) v_u_35, (copy) p_u_27, (ref) v_u_60, (copy) v_u_30, (copy) v_u_354
				local v372
				if v_u_4[p_u_28] == v_u_45 then
					v372 = p_u_28.Parent ~= nil
				else
					v372 = false
				end
				if v372 and v_u_59 then
					local v373 = v_u_6.view
					if type(v373) == "table" then
						local v374 = v_u_6.view.rerollPrice
						local v375 = tonumber(v374) or v_u_35.REROLL_PRICE
						local v376 = p_u_27.profile
						if v376 then
							v376 = p_u_27.profile.cash
						end
						if v375 <= (tonumber(v376) or 0) ~= v_u_60 then
							v_u_30.keepScroll(p_u_28, function()
								-- upvalues: (ref) v_u_354, (ref) v_u_6
								v_u_354(v_u_6.view)
							end)
						end
					end
				end
			end
		}
		local v377 = v_u_6.view
		if type(v377) == "table" then
			local v378 = v_u_1.JSONEncode
			local v379 = v_u_1
			local v380 = v_u_6.view
			local v381, v382 = pcall(v378, v379, v380)
			if v381 then
				v_u_58 = string.gsub(v382, "\"now\":%d+", "")
			else
				v_u_58 = ""
			end
			v_u_354(v_u_6.view)
		else
			v_u_33.empty(p_u_28, "Loading contracts...")
		end
		v_u_61()
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_28, (copy) v_u_45, (copy) v_u_362
			while true do
				local v383
				if v_u_4[p_u_28] == v_u_45 then
					v383 = p_u_28.Parent ~= nil
				else
					v383 = false
				end
				if not v383 then
					return
				end
				task.wait(1)
				local v384
				if v_u_4[p_u_28] == v_u_45 then
					v384 = p_u_28.Parent ~= nil
				else
					v384 = false
				end
				if not v384 then
					continue
				end
				v_u_362()
			end
		end)
		if v_u_48 and v_u_47 then
			local v_u_385 = nil
			v_u_385 = v_u_47:GetAttributeChangedSignal("DevContractAct"):Connect(function()
				-- upvalues: (ref) v_u_4, (copy) p_u_28, (copy) v_u_45, (ref) v_u_385, (copy) v_u_47, (ref) v_u_6, (ref) v_u_61, (copy) v_u_52
				local v386
				if v_u_4[p_u_28] == v_u_45 then
					v386 = p_u_28.Parent ~= nil
				else
					v386 = false
				end
				if v386 then
					local v387 = v_u_47:GetAttribute("DevContractAct")
					if type(v387) == "string" and v387 ~= "" then
						v_u_47:SetAttribute("DevContractAct", nil)
						if v387 == "refresh" then
							v_u_6.dirty = true
							v_u_61()
						else
							local v388, v389 = string.match(v387, "^(%a+):(.+)$")
							if v389 then
								v389 = v_u_52[v389]
							end
							if v389 then
								v389 = v389[v388 or ""]
							end
							if v389 then
								v389()
							end
						end
					else
						return
					end
				else
					if v_u_385 then
						v_u_385:Disconnect()
					end
					return
				end
			end)
		end
	else
		v_u_33.empty(p_u_28, "Contracts are not available right now.")
	end
end
return v3