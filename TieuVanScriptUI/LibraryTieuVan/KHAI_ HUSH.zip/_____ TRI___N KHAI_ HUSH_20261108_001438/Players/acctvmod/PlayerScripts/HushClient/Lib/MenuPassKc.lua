-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassKc

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
return {
	["new"] = function(p3, p4, p5, p6, _) -- name: new
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v7 = p3.ui
		local v8 = p3.theme
		local v9 = v8.color
		local v10 = p3.cctx.shared
		local v11 = p3.cctx.lib
		local v12 = v10.KillCardLook
		local v13 = v10.KillCardArt
		local v14 = v10.KillCardAnim
		local v15 = v10.KillCardLocker
		local v16 = v11.KillCardFx
		local v17 = v11.KillCardRig
		if v12 ~= nil and (v14 ~= nil and (v15 ~= nil and (v16 ~= nil and (v17 ~= nil and type(p6) == "table")))) then
			local v18 = p6.plate
			if type(v18) == "table" and type(p5) == "table" then
				local v19 = p5.id
				if type(v19) == "string" then
					local v20 = v_u_1.LocalPlayer
					local v21 = not v20 and 0 or v20.UserId
					local v22 = p3.profile
					local v23
					if type(v22) == "table" then
						v23 = p3.profile.kc
					else
						v23 = nil
					end
					local v_u_24 = v15.selection(v23)
					local v25 = p5.kind
					if v25 == "kc_anim" then
						v_u_24.anim = p5.id
					elseif v25 == "kc_bg" then
						v_u_24.bg = p5.id
					elseif v25 == "kc_frame" then
						v_u_24.frame = p5.id
					end
					local v26 = v8.rarityColor
					local v27 = p5.rarity
					local v28 = v26(type(v27) ~= "number" and 1 or p5.rarity)
					local v29 = p6.plate
					local v_u_30 = {}
					local v_u_31 = true
					local v_u_32 = v7.new("Frame", {
						["Name"] = "KcPlate",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["ClipsDescendants"] = true,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v9.raised,
						["Position"] = UDim2.fromOffset(v29.x, v29.y),
						["Size"] = UDim2.fromOffset(v29.w, v29.h)
					}, p4)
					v7.stroke(v_u_32, v28, 1, 0.3)
					local v_u_33 = v7.new("ImageLabel", {
						["Name"] = "Thumb",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ScaleType"] = nil,
						["Size"] = nil,
						["ZIndex"] = 3,
						["Image"] = ("rbxthumb://type=Avatar&id=%d&w=420&h=420"):format(v21),
						["ScaleType"] = Enum.ScaleType.Crop,
						["Size"] = UDim2.fromScale(1, 1)
					}, v_u_32)
					local v_u_34 = v16.bg(v_u_32, v_u_24.bg, v12, v13)
					local v_u_35 = v16.frame(v_u_32, v_u_24.frame, v12, v13, {
						["z"] = 5,
						["w"] = nil,
						["h"] = nil,
						["w"] = v29.w,
						["h"] = v29.h
					})
					local v_u_36 = nil
					local v37 = v17.new
					local v38 = {
						["parent"] = nil,
						["AnimRig"] = nil,
						["Poses"] = nil,
						["Anim"] = nil,
						["deps"] = nil,
						["zindex"] = 4,
						["parent"] = v_u_32,
						["AnimRig"] = v11.AnimRig,
						["Poses"] = v11.FilmPhotoPoses,
						["Anim"] = v14,
						["deps"] = v17.depsOf(p3.cctx)
					}
					local v39, v40 = pcall(v37, v38)
					if v39 and type(v40) == "table" then
						local v41 = v40.load
						local v42, v43 = pcall(v41, v21)
						if v42 and v43 ~= "thumb" then
							v_u_36 = v40
						else
							local v44 = v40.destroy
							pcall(v44)
						end
					end
					local v_u_45 = os.clock()
					if v_u_36 ~= nil then
						if v25 == "kc_anim" then
							local v46 = v_u_36.play
							local v47 = v_u_24.anim
							pcall(v46, v47, v_u_45)
						else
							local v48 = v_u_36.showEnd
							local v49 = v_u_24.anim
							pcall(v48, v49)
						end
					end
					function v_u_30.replay() -- name: replay
						-- upvalues: (ref) v_u_36, (ref) v_u_31, (copy) v_u_24, (ref) v_u_45
						if v_u_36 ~= nil and v_u_31 then
							local v50 = v_u_36.play
							local v51 = v_u_24.anim
							local v52 = os.clock
							pcall(v50, v51, v52())
							v_u_45 = os.clock()
						end
					end
					if v25 == "kc_anim" then
						local v53 = p6.replay
						if type(v53) == "table" then
							local v54 = p6.replay
							v_u_30.replayButton = v7.button({
								["parent"] = nil,
								["name"] = "Replay",
								["text"] = "REPLAY",
								["kind"] = "ghost",
								["height"] = nil,
								["width"] = nil,
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = p4,
								["height"] = v54.h,
								["width"] = v54.w,
								["position"] = UDim2.fromOffset(v54.x, v54.y),
								["onClick"] = function() -- name: onClick
									-- upvalues: (copy) v_u_30
									v_u_30.replay()
								end
							})
						end
					end
					local v_u_55 = -1
					local v_u_64 = v_u_2.Heartbeat:Connect(function()
						-- upvalues: (ref) v_u_31, (copy) v_u_32, (ref) v_u_36, (copy) v_u_33, (ref) v_u_45, (ref) v_u_55, (copy) v_u_34, (copy) v_u_35
						if v_u_31 and v_u_32.Parent then
							local v56 = os.clock()
							if v_u_36 ~= nil then
								local v57 = v_u_36.step
								pcall(v57, v56)
								local v58 = v_u_36.state
								local v59, v60 = pcall(v58)
								if v59 and (type(v60) == "table" and v60.shown) then
									v_u_33.Visible = false
								end
							end
							local v61 = v56 - v_u_45
							if v61 - v_u_55 >= 0.03333333333333333 then
								v_u_55 = v61
								if v_u_34 then
									local v62 = v_u_34.step
									pcall(v62, v61)
								end
								if v_u_35 then
									local v63 = v_u_35.step
									pcall(v63, v61)
								end
							end
						end
					end)
					v_u_30.plate = v_u_32
					function v_u_30.viewports() -- name: viewports
						-- upvalues: (copy) v_u_32
						local v65 = 0
						for _, v66 in v_u_32:GetDescendants() do
							if not v66:IsA("ViewportFrame") then
								continue
							end
							v65 = v65 + 1
						end
						return v65
					end
					function v_u_30.state() -- name: state
						-- upvalues: (copy) v_u_24, (ref) v_u_36
						return {
							["anim"] = v_u_24.anim,
							["bg"] = v_u_24.bg,
							["frame"] = v_u_24.frame,
							["rig"] = v_u_36 ~= nil
						}
					end
					function v_u_30.destroy() -- name: destroy
						-- upvalues: (ref) v_u_31, (copy) v_u_64, (copy) v_u_34, (copy) v_u_35, (ref) v_u_36, (copy) v_u_32, (copy) v_u_30
						if v_u_31 then
							v_u_31 = false
							v_u_64:Disconnect()
							if v_u_34 then
								local v67 = v_u_34.destroy
								pcall(v67)
							end
							if v_u_35 then
								local v68 = v_u_35.destroy
								pcall(v68)
							end
							if v_u_36 ~= nil then
								local v69 = v_u_36.destroy
								pcall(v69)
								v_u_36 = nil
							end
							local function v70()
								-- upvalues: (ref) v_u_32
								v_u_32:Destroy()
							end
							pcall(v70)
							if v_u_30.replayButton ~= nil then
								local function v71()
									-- upvalues: (ref) v_u_30
									v_u_30.replayButton:Destroy()
								end
								pcall(v71)
							end
						end
					end
					return v_u_30
				end
			end
		end
		return nil
	end
}