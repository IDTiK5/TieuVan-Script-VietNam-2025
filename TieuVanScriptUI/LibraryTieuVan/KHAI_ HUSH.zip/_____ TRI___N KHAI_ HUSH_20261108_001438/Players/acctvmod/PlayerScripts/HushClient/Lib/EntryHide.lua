-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryHide

local v_u_1 = game:GetService("Players")
local v_u_2 = {}
local v_u_3 = {}
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = 0
local v_u_7 = false
local function v_u_12(p_u_8) -- name: hideObj
	-- upvalues: (ref) v_u_4, (ref) v_u_6
	if (p_u_8:IsA("BasePart") or p_u_8:IsA("Decal")) and v_u_4[p_u_8] == nil then
		local v9, v10 = pcall(function()
			-- upvalues: (copy) p_u_8
			return p_u_8.LocalTransparencyModifier
		end)
		local v11 = (not v9 or type(v10) ~= "number") and 0 or v10
		v_u_4[p_u_8] = v11 >= 1 and p_u_8:GetAttribute("HushGearHidden") ~= true and 0 or v11
		v_u_6 = v_u_6 + 1
		pcall(function()
			-- upvalues: (copy) p_u_8
			p_u_8.LocalTransparencyModifier = 1
		end)
	end
end
local function v_u_15(p13) -- name: hookCharacter
	-- upvalues: (copy) v_u_5, (copy) v_u_12
	if not v_u_5[p13] then
		for _, v14 in p13:GetDescendants() do
			v_u_12(v14)
		end
		v_u_5[p13] = p13.DescendantAdded:Connect(v_u_12)
	end
end
function v_u_2.start(p16) -- name: start
	-- upvalues: (copy) v_u_2, (ref) v_u_7, (ref) v_u_3
	v_u_2.stop()
	v_u_7 = true
	for _, v17 in p16 do
		v_u_3[v17] = true
	end
	v_u_2.step()
end
function v_u_2.step() -- name: step
	-- upvalues: (ref) v_u_7, (ref) v_u_3, (copy) v_u_1, (copy) v_u_5, (copy) v_u_15, (ref) v_u_4
	if v_u_7 then
		for v18 in v_u_3 do
			local v19 = v_u_1:GetPlayerByUserId(v18)
			if v19 then
				v19 = v19.Character
			end
			if not v19 or v_u_5[v19] then
				continue
			end
			v_u_15(v19)
		end
		for v20, _ in v_u_4 do
			if not v20.Parent or v20.LocalTransparencyModifier == 1 then
				continue
			end
			v20.LocalTransparencyModifier = 1
		end
	end
end
function v_u_2.stop() -- name: stop
	-- upvalues: (copy) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7
	for v21, v22 in v_u_5 do
		v22:Disconnect()
		v_u_5[v21] = nil
	end
	for v_u_23, v_u_24 in v_u_4 do
		if not v_u_23.Parent then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_24
			v_u_23.LocalTransparencyModifier = v_u_24
		end)
	end
	v_u_4 = {}
	v_u_6 = 0
	v_u_3 = {}
	v_u_7 = false
end
function v_u_2.active() -- name: active
	-- upvalues: (ref) v_u_7
	return v_u_7
end
function v_u_2.count() -- name: count
	-- upvalues: (ref) v_u_6
	return v_u_6
end
return v_u_2