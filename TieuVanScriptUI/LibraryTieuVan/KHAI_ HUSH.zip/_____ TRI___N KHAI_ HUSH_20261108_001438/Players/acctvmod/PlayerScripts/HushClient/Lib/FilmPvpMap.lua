-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmPvpMap

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = require(script.Parent:WaitForChild("MenuRotationLayout"))
local v_u_6 = {
	["POLL_SEC"] = 5
}
local v_u_7 = v1.LocalPlayer
function v_u_6.maps() -- name: maps
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v_u_8 = "Maps"
	local function v10()
		-- upvalues: (ref) v_u_2, (copy) v_u_8
		local v9 = v_u_2:FindFirstChild("Hush")
		if v9 then
			v9 = v9:FindFirstChild("Shared")
		end
		if v9 then
			v9 = v9:FindFirstChild(v_u_8)
		end
		if v9 then
			return require(v9)
		else
			return nil
		end
	end
	local v11, v_u_12 = pcall(v10)
	if not v11 or type(v_u_12) ~= "table" then
		v_u_12 = nil
	end
	local v_u_13 = "PvpMapRotation"
	local function v15()
		-- upvalues: (ref) v_u_2, (copy) v_u_13
		local v14 = v_u_2:FindFirstChild("Hush")
		if v14 then
			v14 = v14:FindFirstChild("Shared")
		end
		if v14 then
			v14 = v14:FindFirstChild(v_u_13)
		end
		if v14 then
			return require(v14)
		else
			return nil
		end
	end
	local v16, v_u_17 = pcall(v15)
	if not v16 or type(v_u_17) ~= "table" then
		v_u_17 = nil
	end
	local v_u_18 = "MapReveal"
	local function v20()
		-- upvalues: (ref) v_u_2, (copy) v_u_18
		local v19 = v_u_2:FindFirstChild("Hush")
		if v19 then
			v19 = v19:FindFirstChild("Shared")
		end
		if v19 then
			v19 = v19:FindFirstChild(v_u_18)
		end
		if v19 then
			return require(v19)
		else
			return nil
		end
	end
	local v21, v_u_22 = pcall(v20)
	if not v21 or type(v_u_22) ~= "table" then
		v_u_22 = nil
	end
	return v_u_5.orderIds(v_u_17, v_u_12), function(p23) -- name: nameOf
		-- upvalues: (copy) v_u_17, (copy) v_u_12, (copy) v_u_22
		if v_u_17 then
			local v24 = v_u_17.ownerNameOf
			if type(v24) == "function" then
				local v25 = v_u_17.ownerNameOf
				local v26, v27 = pcall(v25, p23)
				if v26 and (type(v27) == "string" and v27 ~= "") then
					return string.upper(v27)
				end
			end
		end
		local v28 = nil
		if v_u_12 then
			local v29 = v_u_12.get
			if type(v29) == "function" then
				local v30 = v_u_12.get
				local v31
				v31, v28 = pcall(v30, p23)
				if not v31 then
					v28 = nil
				end
			end
		end
		local v32
		if type(v28) == "table" then
			v32 = v28.name
		else
			v32 = nil
		end
		local v33
		if v_u_22 then
			local v34 = v_u_22.displayName
			if type(v34) == "function" and type(v32) == "string" then
				local v35 = v_u_22.displayName
				local v36
				v36, v33 = pcall(v35, p23, v32, true)
				if v36 and type(v33) == "string" then
					if v33 == "" then
						v33 = v32
					end
				else
					v33 = v32
				end
			else
				v33 = v32
			end
		else
			v33 = v32
		end
		local v37 = string.upper
		if type(v33) == "string" and v33 ~= "" then
			p23 = v33
		end
		return v37(p23)
	end
end
function v_u_6.mount(p38, p_u_39, p40, p41) -- name: mount
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3
	local v42 = type(p41) ~= "table" and {} or p41
	if type(p40) == "table" then
		local v43 = p40.color
		if type(v43) ~= "table" then
			p40 = v_u_4.Theme
		end
	else
		p40 = v_u_4.Theme
	end
	local v_u_44 = p40.color
	local v45 = v42.inner
	local v46 = type(v45) ~= "number" and 438 or v42.inner
	local v47 = v42.gui
	local v_u_48
	if v42.player == nil then
		v_u_48 = v_u_7
	else
		v_u_48 = v42.player
	end
	local v49 = v42.sendQuiet
	local v_u_50
	if type(v49) == "function" then
		v_u_50 = v42.sendQuiet
	else
		v_u_50 = p_u_39
	end
	local v51 = v42.now
	local v_u_52
	if type(v51) == "function" then
		v_u_52 = v42.now
	else
		v_u_52 = os.clock
	end
	local v53 = 0
	local v_u_54 = true
	if v47 then
		v47.Destroying:Connect(function()
			-- upvalues: (ref) v_u_54
			v_u_54 = false
		end)
	end
	local v55 = v42.ids
	local v56, v_u_57
	if type(v55) == "table" then
		v56 = v42.ids
		local v58 = v42.nameOf
		if type(v58) == "function" then
			v_u_57 = v42.nameOf
		else
			v_u_57 = function(p59)
				return string.upper(p59)
			end
		end
	else
		v56, v_u_57 = v_u_6.maps()
	end
	local v60 = v_u_5.f8Layout
	local v61 = p40.touch
	local v62 = v60(v46, type(v61) ~= "function" and 34 or p40.touch(34), #v56)
	local v63 = v_u_4.label({
		["parent"] = nil,
		["text"] = "PVP map  \194\183  owner only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p38,
		["color"] = v_u_44.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v64 = v42.order
	local v65, v66
	if type(v64) == "function" then
		v65 = v42.order()
		v66 = v53
	else
		v53 = v53 + 1
		v65 = v53
		v66 = v53
	end
	v63.LayoutOrder = v65
	local v67 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PvpMapNote",
		["text"] = "In PVP every player deploys to the same map and the map changes every 45 minutes in a fixed order. A map button sets the map by hand; it then stays until you press ROTATE AGAIN. Searching squads move to the new map and keep their waiting time, raids that already run are not touched. Other servers follow within 15 seconds.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p38,
		["color"] = v_u_44.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v68 = v42.order
	local v69
	if type(v68) == "function" then
		v69 = v42.order()
	else
		v53 = v66 + 1
		v69 = v53
		v66 = v53
	end
	v67.LayoutOrder = v69
	local v_u_70 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PvpMapStatus",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p38,
		["text"] = v_u_5.TEXT.f8Reading,
		["color"] = v_u_44.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v71 = v42.order
	local v72
	if type(v71) == "function" then
		v72 = v42.order()
	else
		v53 = v66 + 1
		v72 = v53
		v66 = v53
	end
	v_u_70.LayoutOrder = v72
	local v73 = v_u_4.new("Frame", {
		["Name"] = "PvpMapControls",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(v62.w, v62.h)
	}, p38)
	local v74 = v42.order
	local v75
	if type(v74) == "function" then
		v75 = v42.order()
	else
		v53 = v66 + 1
		v75 = v53
		v66 = v53
	end
	v73.LayoutOrder = v75
	local v_u_76 = v_u_4.label({
		["parent"] = nil,
		["name"] = "PvpMapAnswer",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p38,
		["color"] = v_u_44.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v77 = v42.order
	local v78
	if type(v77) == "function" then
		v78 = v42.order()
	else
		v53 = v66 + 1
		v78 = v53
	end
	v_u_76.LayoutOrder = v78
	local v_u_79 = false
	local v_u_80 = "none"
	local v_u_81 = nil
	local v_u_82 = 0
	local v_u_83 = {}
	local function v_u_89() -- name: hook
		-- upvalues: (copy) v_u_48, (ref) v_u_81, (ref) v_u_79, (ref) v_u_80
		if v_u_48 then
			local v84 = v_u_81
			local v85 = type(v84) == "table" and (v_u_81.forced == true and "1" or "0") or "?"
			local v86 = v_u_81
			local v87
			if type(v86) == "table" then
				local v88 = v_u_81.map
				v87 = type(v88) ~= "string" and "?" or v_u_81.map
			else
				v87 = "?"
			end
			v_u_48:SetAttribute("FilmPvpMap", ("busy=%d|last=%s|forced=%s|map=%s"):format(v_u_79 and 1 or 0, v_u_80, v85, v87))
		end
	end
	local function v_u_97(p90) -- name: paintStatus
		-- upvalues: (ref) v_u_81, (copy) v_u_52, (ref) v_u_82, (ref) v_u_4, (copy) v_u_70, (ref) v_u_5, (copy) v_u_44
		local v91 = v_u_81
		if type(v91) == "table" then
			local v92 = v_u_81.secondsLeft
			local v93
			if type(v92) == "number" then
				local v94 = v_u_81.secondsLeft - (v_u_52() - v_u_82)
				v93 = math.max(0, v94)
			else
				v93 = nil
			end
			v_u_4.setText(v_u_70, v_u_5.f8Status(v_u_81, v93))
			local v95 = v_u_70
			local v96
			if p90 == true then
				v96 = v_u_44.danger
			elseif v_u_81.forced == true then
				v96 = v_u_44.accent
			else
				v96 = v_u_44.success
			end
			v95.TextColor3 = v96
		end
	end
	local function v_u_103() -- name: paintButtons
		-- upvalues: (copy) v_u_83, (ref) v_u_81
		for v98, v99 in v_u_83 do
			local v100 = v_u_81
			local v101
			if type(v100) == "table" then
				v101 = v_u_81.map == v98
			else
				v101 = false
			end
			if not v99.api then
				continue
			end
			local v102 = v99.api.setKind
			if type(v102) ~= "function" then
				continue
			end
			v99.api.setKind(v101 and "primary" or "secondary")
		end
	end
	local function v_u_111(p104, p105) -- name: take
		-- upvalues: (ref) v_u_80, (ref) v_u_81, (ref) v_u_82, (copy) v_u_52, (ref) v_u_4, (copy) v_u_76, (copy) v_u_44, (copy) v_u_97, (copy) v_u_103, (copy) v_u_89
		if type(p104) == "table" then
			v_u_80 = p104.ok == true and "ok" or "bad"
			local v106 = p104.data
			if type(v106) == "table" then
				v_u_81 = p104.data
				v_u_82 = v_u_52()
			end
			if p105 ~= true then
				local v107 = p104.msg
				local v108
				if type(v107) == "string" and p104.msg ~= "" then
					v108 = p104.msg
				else
					v108 = p104.ok == true and "Done." or "Refused or failed."
				end
				v_u_4.setText(v_u_76, v108)
				local v109 = v_u_76
				local v110
				if p104.ok == true then
					v110 = v_u_44.text2
				else
					v110 = v_u_44.danger
				end
				v109.TextColor3 = v110
			end
			v_u_97(p104.ok ~= true)
			v_u_103()
		else
			v_u_80 = "bad"
			v_u_4.setText(v_u_76, "The server did not answer.")
			v_u_76.TextColor3 = v_u_44.danger
		end
		v_u_89()
	end
	local function v_u_116(p112, p113) -- name: call
		-- upvalues: (ref) v_u_79, (copy) p_u_39, (ref) v_u_4, (copy) v_u_76, (copy) v_u_44, (copy) v_u_89, (ref) v_u_54, (copy) v_u_111
		if v_u_79 then
			return
		else
			local v114 = p_u_39
			if type(v114) == "function" then
				v_u_79 = true
				v_u_4.setText(v_u_76, p113)
				v_u_76.TextColor3 = v_u_44.text2
				v_u_89()
				p_u_39("pvp.map", p112, function(p115)
					-- upvalues: (ref) v_u_79, (ref) v_u_54, (ref) v_u_111
					v_u_79 = false
					if v_u_54 then
						v_u_111(p115)
					end
				end)
			else
				v_u_4.setText(v_u_76, "No connection to the server.")
				v_u_76.TextColor3 = v_u_44.danger
			end
		end
	end
	local v_u_117 = v_u_82
	local v_u_118 = v_u_81
	local v_u_119 = v_u_80
	local v_u_120 = v_u_79
	local function v_u_122(p121) -- name: setMap
		-- upvalues: (copy) v_u_116, (ref) v_u_57
		if type(p121) == "string" and p121 ~= "" then
			v_u_116({
				["action"] = "set",
				["map"] = nil,
				["map"] = p121
			}, ("Setting the map to %s ..."):format(v_u_57(p121)))
		end
	end
	local function v123() -- name: clear
		-- upvalues: (copy) v_u_116
		v_u_116({
			["action"] = "clear"
		}, "Starting the rotation again ...")
	end
	local function v124() -- name: status
		-- upvalues: (copy) v_u_116
		v_u_116({
			["action"] = "status"
		}, "Reading the map rotation ...")
	end
	for v125, v_u_126 in v56 do
		local v127 = v62.maps[v125]
		local v128, v129 = v_u_4.button({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["size"] = nil,
			["position"] = nil,
			["maxTextWidth"] = nil,
			["onClick"] = nil,
			["parent"] = v73,
			["name"] = "PvpMap_" .. v_u_126,
			["text"] = v_u_57(v_u_126),
			["size"] = UDim2.fromOffset(v127.w, v127.h),
			["position"] = UDim2.fromOffset(v127.x, v127.y),
			["maxTextWidth"] = v127.w - 12,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_122, (copy) v_u_126
				v_u_122(v_u_126)
			end
		})
		v_u_83[v_u_126] = {
			["btn"] = v128,
			["api"] = v129
		}
	end
	v_u_4.button({
		["parent"] = nil,
		["name"] = "PvpMapRotate",
		["text"] = nil,
		["kind"] = "secondary",
		["size"] = nil,
		["position"] = nil,
		["maxTextWidth"] = nil,
		["onClick"] = nil,
		["parent"] = v73,
		["text"] = v_u_5.TEXT.f8Rotate,
		["size"] = UDim2.fromOffset(v62.rotate.w, v62.rotate.h),
		["position"] = UDim2.fromOffset(v62.rotate.x, v62.rotate.y),
		["maxTextWidth"] = v62.rotate.w - 12,
		["onClick"] = v123
	})
	if v42.noPoll ~= true then
		task.spawn(function()
			-- upvalues: (ref) v_u_54, (ref) v_u_6, (ref) v_u_120, (copy) v_u_50, (ref) v_u_119, (ref) v_u_118, (ref) v_u_117, (copy) v_u_52, (copy) v_u_97, (copy) v_u_103, (ref) v_u_4, (copy) v_u_76, (copy) v_u_44, (copy) v_u_89
			local v130 = 0
			while true do
				while true do
					if not v_u_54 then
						return
					end
					task.wait(1)
					if not v_u_54 then
						break
					end
					v130 = v130 + 1
					if v_u_6.POLL_SEC <= v130 and not v_u_120 then
						break
					end
					v_u_97()
				end
				local v131 = v_u_50
				if type(v131) == "function" then
					v_u_50("pvp.map", {
						["action"] = "status"
					}, function(p132)
						-- upvalues: (ref) v_u_54, (ref) v_u_120, (ref) v_u_119, (ref) v_u_118, (ref) v_u_117, (ref) v_u_52, (ref) v_u_97, (ref) v_u_103, (ref) v_u_4, (ref) v_u_76, (ref) v_u_44, (ref) v_u_89
						if v_u_54 and (not v_u_120 and type(p132) == "table") then
							if type(p132) == "table" then
								v_u_119 = p132.ok == true and "ok" or "bad"
								local v133 = p132.data
								if type(v133) == "table" then
									v_u_118 = p132.data
									v_u_117 = v_u_52()
								end
								v_u_97(p132.ok ~= true)
								v_u_103()
							else
								v_u_119 = "bad"
								v_u_4.setText(v_u_76, "The server did not answer.")
								v_u_76.TextColor3 = v_u_44.danger
							end
							v_u_89()
						end
					end)
					v130 = 0
				else
					v_u_97()
				end
			end
		end)
	end
	if v_u_3:IsStudio() and v_u_48 then
		local v_u_137 = v_u_48:GetAttributeChangedSignal("FilmPvpMapCmd"):Connect(function()
			-- upvalues: (copy) v_u_48, (copy) v_u_122, (copy) v_u_116
			local v134 = v_u_48:GetAttribute("FilmPvpMapCmd")
			if type(v134) == "string" and v134 ~= "" then
				v_u_48:SetAttribute("FilmPvpMapCmd", nil)
				local v135, v136 = string.match(v134, "^(%a+)%s*(.-)$")
				if v135 == "set" then
					v_u_122(v136)
					return
				elseif v135 == "clear" then
					v_u_116({
						["action"] = "clear"
					}, "Starting the rotation again ...")
				elseif v135 == "status" then
					v_u_116({
						["action"] = "status"
					}, "Reading the map rotation ...")
				end
			else
				return
			end
		end)
		if v47 then
			v47.Destroying:Connect(function()
				-- upvalues: (copy) v_u_137
				v_u_137:Disconnect()
			end)
		end
	end
	v_u_89()
	task.defer(v124)
	return {
		["set"] = v_u_122,
		["clear"] = v123,
		["status"] = v124,
		["ids"] = v56,
		["buttons"] = v_u_83,
		["alive"] = function() -- name: alive
			-- upvalues: (ref) v_u_54
			return v_u_54
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_120, (ref) v_u_119, (ref) v_u_118
			return {
				["busy"] = v_u_120,
				["last"] = v_u_119,
				["data"] = v_u_118
			}
		end
	}
end
return v_u_6