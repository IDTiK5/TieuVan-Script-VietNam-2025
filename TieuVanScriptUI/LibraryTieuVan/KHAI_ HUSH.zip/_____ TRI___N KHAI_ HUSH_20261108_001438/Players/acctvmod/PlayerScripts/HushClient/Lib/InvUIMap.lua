-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIMap

local v_u_16 = {
	["opened"] = 0,
	["button"] = function(p_u_1, p2, p3, p4, p5) -- name: button
		-- upvalues: (copy) v_u_16
		local v6, v7 = pcall(function()
			-- upvalues: (copy) p_u_1
			return p_u_1.lib.HushUI
		end)
		if v6 and v7 then
			local v8 = v7.button
			if type(v8) == "function" then
				local v9 = p5 and 84 or 104
				local v10 = v7.button
				local v15 = {
					["parent"] = nil,
					["text"] = "Map",
					["kind"] = "secondary",
					["icon"] = "map",
					["name"] = "MapButton",
					["size"] = nil,
					["width"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["onClick"] = nil,
					["parent"] = p2,
					["size"] = UDim2.fromOffset(v9, p4),
					["width"] = v9,
					["position"] = UDim2.new(1, -p3, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5),
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) p_u_1, (ref) v_u_16
						local v11 = p_u_1.controllers
						if v11 then
							v11 = p_u_1.controllers.MapUI
						end
						if v11 then
							local v12 = v11.open
							if type(v12) == "function" then
								local v13 = v_u_16
								v13.opened = v13.opened + 1
								local v14 = v11.open
								pcall(v14)
							end
						end
					end
				}
				return not pcall(v10, v15) and 0 or v9
			end
		end
		return 0
	end
}
return v_u_16