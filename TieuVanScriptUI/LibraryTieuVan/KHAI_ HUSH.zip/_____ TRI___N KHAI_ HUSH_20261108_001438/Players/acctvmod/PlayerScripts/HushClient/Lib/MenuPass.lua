-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPass

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("MarketplaceService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = {}
local v_u_6 = utf8.char(57346)
function v5.new(p_u_7, p8, p9) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_2, (copy) v_u_6, (copy) v_u_3
	local v_u_10 = p_u_7.ui
	local v_u_11 = p_u_7.theme
	local v_u_12 = v_u_11.color
	local v_u_13 = p_u_7.kit
	local v_u_14 = p_u_7.cctx
	local v_u_15 = v_u_1.LocalPlayer
	local v_u_16 = {}
	local v_u_17 = true
	local v_u_18 = false
	local v_u_19 = "MenuPassRules"
	local v20, v_u_21 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_19
		return v_u_14.shared[v_u_19]
	end)
	if not v20 then
		v_u_21 = nil
	end
	if type(v_u_21) ~= "table" then
		local _, v22 = v_u_10.panel({
			["parent"] = nil,
			["name"] = "Pass",
			["position"] = nil,
			["size"] = nil,
			["padding"] = 16,
			["parent"] = p8,
			["position"] = UDim2.fromOffset(24, 8),
			["size"] = UDim2.new(1, -48, 1, -8)
		})
		v_u_10.label({
			["parent"] = nil,
			["text"] = "Battle Pass",
			["style"] = "h2",
			["size"] = nil,
			["parent"] = v22,
			["size"] = UDim2.new(1, 0, 0, 30)
		})
		v_u_10.label({
			["parent"] = nil,
			["text"] = "The Battle Pass is not available right now.",
			["style"] = "small",
			["wrap"] = true,
			["valign"] = "top",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v22,
			["position"] = UDim2.fromOffset(0, 44),
			["size"] = UDim2.new(1, 0, 0, 40)
		})
		function v_u_16.show() -- name: show end
		function v_u_16.hide() -- name: hide end
		function v_u_16.refresh(_) -- name: refresh end
		function v_u_16.tick(_) -- name: tick end
		function v_u_16.destroy() -- name: destroy end
		return v_u_16
	end
	local v_u_23 = v_u_21.TEXT
	local v_u_24 = "GameMode"
	local v25, v_u_26 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_24
		return v_u_14.shared[v_u_24]
	end)
	if not v25 then
		v_u_26 = nil
	end
	local v_u_27 = "pve"
	local v_u_28 = false
	local v_u_29 = false
	local function v30()
		-- upvalues: (copy) v_u_26, (ref) v_u_27
		if v_u_26 and v_u_26.isPvpve() then
			v_u_27 = "pvpve"
		end
	end
	pcall(v30)
	local function v32()
		-- upvalues: (ref) v_u_28, (copy) v_u_26
		local v31
		if v_u_26 == nil then
			v31 = false
		else
			v31 = v_u_26.rule("killCardCosmetics") == true
		end
		v_u_28 = v31
	end
	pcall(v32)
	local function v34()
		-- upvalues: (ref) v_u_29, (copy) v_u_26
		local v33
		if v_u_26 == nil then
			v33 = false
		else
			v33 = v_u_26.rule("clans") == true
		end
		v_u_29 = v33
	end
	pcall(v34)
	local v_u_35 = "SeasonRules"
	local v36, v_u_37 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_35
		return v_u_14.shared[v_u_35]
	end)
	if not v36 then
		v_u_37 = nil
	end
	local v_u_38 = {
		["mode"] = v_u_27,
		["killCard"] = v_u_28,
		["clans"] = v_u_29
	}
	local v_u_39 = "SeasonOp1"
	local v40, v41 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_39
		return v_u_14.shared[v_u_39]
	end)
	if not v40 then
		v41 = nil
	end
	v_u_38.ops = v41
	local v42
	if type(v_u_37) == "table" then
		v42 = v_u_37.TUNE
	else
		v42 = nil
	end
	v_u_38.tune = v42
	local v_u_43 = "MenuPassArt"
	local v44, v_u_45 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_43
		return v_u_14.lib[v_u_43]
	end)
	if not v44 then
		v_u_45 = nil
	end
	local v_u_46 = "PassTileLook"
	local v47, v_u_48 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_46
		return v_u_14.shared[v_u_46]
	end)
	if not v47 then
		v_u_48 = nil
	end
	local v_u_49 = "MenuPassMissions"
	local v50, v51 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_49
		return v_u_14.lib[v_u_49]
	end)
	if not v50 then
		v51 = nil
	end
	local v_u_52 = "MenuPassXp"
	local v53, v_u_54 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_52
		return v_u_14.lib[v_u_52]
	end)
	if not v53 then
		v_u_54 = nil
	end
	local v_u_55 = "MenuPassKc"
	local v56, v_u_57 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_55
		return v_u_14.lib[v_u_55]
	end)
	if not v56 then
		v_u_57 = nil
	end
	local v_u_58 = "PassDetailRules"
	local v59, v_u_60 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_58
		return v_u_14.shared[v_u_58]
	end)
	if not v59 then
		v_u_60 = nil
	end
	local v_u_61 = "PassGiftRules"
	local v62, v_u_63 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_61
		return v_u_14.shared[v_u_61]
	end)
	if not v62 then
		v_u_63 = nil
	end
	local v_u_64 = nil
	local v_u_65 = nil
	local v_u_66 = v_u_21.model(nil, v_u_38)
	local v_u_67 = os.clock()
	local v_u_68 = false
	local v_u_69 = false
	local v_u_70 = nil
	local v_u_71 = "rewards"
	local v_u_72 = nil
	local v_u_73 = 0
	local v_u_74 = nil
	local v_u_75 = nil
	local v_u_76 = 0
	local v_u_77 = 0
	local v_u_78 = 0
	local v_u_79 = 0
	local v_u_80 = nil
	local v_u_81 = {}
	local v_u_82 = nil
	local v_u_83 = 0
	local v_u_84 = false
	local v_u_85 = false
	local v86 = nil
	local v_u_87 = nil
	local v_u_88 = {}
	local v_u_89 = nil
	local v90, v91, v92, v93
	if type(p9) == "table" then
		local v94 = p9.layout
		if type(v94) == "table" then
			v90 = p9.layout
		else
			v91 = v_u_11.safeRefSize()
			v92, v93 = v_u_21.room(v91.X, v91.Y, p_u_7.compact())
			v90 = v_u_21.layout(v92, v93, v_u_11.touch(36))
		end
	else
		v91 = v_u_11.safeRefSize()
		v92, v93 = v_u_21.room(v91.X, v91.Y, p_u_7.compact())
		v90 = v_u_21.layout(v92, v93, v_u_11.touch(36))
	end
	local v95 = {
		["show"] = false
	}
	local v_u_96, v_u_97
	if v_u_60 == nil then
		v_u_96 = v90
		v_u_97 = v95
	else
		local v98 = v_u_60.apply
		local v99 = v90.h - (v90.headH + v90.gap + v90.subH + v90.gap)
		local v100
		v100, v_u_96, v_u_97 = pcall(v98, v90, v99, 4)
		if not v100 or (type(v_u_96) ~= "table" or type(v_u_97) ~= "table") then
			v_u_96 = v90
			v_u_97 = v95
		end
	end
	local _, v101 = v_u_10.panel({
		["parent"] = nil,
		["name"] = "Pass",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 12,
		["parent"] = p8,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v_u_102 = v_u_10.new("Frame", {
		["Name"] = "State",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = true,
		["Size"] = UDim2.fromScale(1, 1)
	}, v101)
	local v_u_103 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = nil,
		["style"] = "body",
		["color"] = nil,
		["align"] = "center",
		["wrap"] = true,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_102,
		["text"] = v_u_23.loading,
		["color"] = v_u_12.text2,
		["anchor"] = Vector2.new(0.5, 0.5),
		["position"] = UDim2.fromScale(0.5, 0.42),
		["size"] = UDim2.new(0.8, 0, 0, 48)
	})
	local v_u_104 = v_u_10.button({
		["parent"] = nil,
		["name"] = "Retry",
		["text"] = nil,
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 200,
		["anchor"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_102,
		["text"] = v_u_23.retry,
		["height"] = v_u_11.touch(40),
		["anchor"] = Vector2.new(0.5, 0),
		["position"] = UDim2.new(0.5, 0, 0.42, 36),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_16
			v_u_16.load(true)
		end
	})
	v_u_104.Visible = false
	local v_u_105 = v_u_10.new("Frame", {
		["Name"] = "Main",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v101)
	local v_u_106 = v_u_10.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_96.headH)
	}, v_u_105)
	local v_u_107 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Season",
		["text"] = "",
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v_u_106,
		["size"] = UDim2.new(1, -(v_u_96.ctaColW + v_u_96.gap + 190), 0, v_u_96.row1H)
	})
	local v_u_108 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Countdown",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_106,
		["position"] = UDim2.new(1, -(v_u_96.ctaColW + v_u_96.gap + 190), 0, 0),
		["size"] = UDim2.fromOffset(190, v_u_96.row1H)
	})
	local v_u_109 = v_u_96.row1H + 4
	local v110 = v_u_10.new("Frame", {
		["Name"] = "TierChip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_12.accentDeep,
		["Position"] = UDim2.fromOffset(0, v_u_109),
		["Size"] = UDim2.fromOffset(v_u_96.tierChipW, v_u_96.meterH)
	}, v_u_106)
	v_u_10.stroke(v110, v_u_12.accent, 1, 0.35)
	v_u_10.label({
		["parent"] = nil,
		["name"] = "Word",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v110,
		["text"] = v_u_23.tierWord,
		["color"] = v_u_12.accent,
		["position"] = UDim2.fromOffset(0, 3),
		["size"] = UDim2.new(1, 0, 0, 12)
	})
	local v_u_111 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Num",
		["text"] = "0",
		["style"] = "h2",
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v110,
		["position"] = UDim2.fromOffset(0, 15),
		["size"] = UDim2.new(1, 0, 0, v_u_96.meterH - 16)
	})
	local function v117(p112, p113, p114) -- name: meter
		-- upvalues: (ref) v_u_96, (copy) v_u_10, (copy) v_u_109, (copy) v_u_106, (copy) v_u_12
		local v115 = v_u_96.tierChipW + v_u_96.gap + (p112 - 1) * (v_u_96.meterW + v_u_96.gap)
		local v116 = v_u_10.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = "Meter" .. p112,
			["Position"] = UDim2.fromOffset(v115, v_u_109),
			["Size"] = UDim2.fromOffset(v_u_96.meterW, v_u_96.meterH)
		}, v_u_106)
		return {
			["frame"] = v116,
			["cap"] = v_u_10.label({
				["parent"] = nil,
				["name"] = "Cap",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v116,
				["text"] = p113,
				["color"] = v_u_12.text2,
				["position"] = UDim2.fromOffset(0, 0),
				["size"] = UDim2.new(1, 0, 0, 14)
			}),
			["bar"] = v_u_10.progress({
				["parent"] = nil,
				["value"] = 0,
				["color"] = nil,
				["size"] = nil,
				["position"] = nil,
				["parent"] = v116,
				["color"] = p114,
				["size"] = UDim2.new(1, 0, 0, 8),
				["position"] = UDim2.fromOffset(0, 17)
			}),
			["val"] = v_u_10.label({
				["parent"] = nil,
				["name"] = "Val",
				["text"] = "",
				["style"] = "monoS",
				["textSize"] = 12,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v116,
				["color"] = v_u_12.text,
				["position"] = UDim2.fromOffset(0, 27),
				["size"] = UDim2.new(1, 0, 0, v_u_96.meterH - 27)
			})
		}
	end
	local v_u_118 = v117(1, "", v_u_12.accent)
	local v_u_119 = v117(2, v_u_23.avail, v_u_12.info)
	local v_u_120 = v117(3, v_u_23.waiting, v_u_12.success)
	local v_u_121 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Caption",
		["text"] = "",
		["style"] = "small",
		["textSize"] = 12,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_106,
		["color"] = v_u_12.text2,
		["position"] = UDim2.fromOffset(0, v_u_109 + v_u_96.meterH + 4),
		["size"] = UDim2.new(1, -(v_u_96.ctaColW + v_u_96.gap), 0, v_u_96.captionH)
	})
	local v_u_122 = ""
	for _, v123 in { v_u_119.frame, v_u_120.frame, v_u_121 } do
		v_u_10.tooltip(v123, function()
			-- upvalues: (copy) v_u_23, (ref) v_u_122, (copy) v_u_12
			return {
				["title"] = v_u_23.limitTitle,
				["body"] = v_u_122,
				["color"] = v_u_12.info
			}
		end)
	end
	local v_u_124 = v_u_10.new("Frame", {
		["Name"] = "Cta",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 0),
		["Size"] = UDim2.fromOffset(v_u_96.ctaColW, v_u_96.headH)
	}, v_u_106)
	v_u_10.label({
		["parent"] = nil,
		["name"] = "Track",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["track"] = true,
		["parent"] = v_u_124,
		["text"] = v_u_23.classifiedName,
		["color"] = v_u_12.accent,
		["size"] = UDim2.new(1, 0, 0, 14)
	}).Visible = v_u_96.cta.labelH > 0
	local v125 = v_u_10.new
	local v126 = "Frame"
	local v127 = {
		["Name"] = "Holder",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil
	}
	local v128
	if v_u_96.cta.stack then
		v128 = Vector2.new(0, 0)
	else
		v128 = Vector2.new(1, 0)
	end
	v127.AnchorPoint = v128
	local v129
	if v_u_96.cta.stack then
		v129 = UDim2.new(0, 0, 0, v_u_96.cta.labelH)
	else
		v129 = UDim2.new(1, 0, 0, v_u_96.cta.labelH)
	end
	v127.Position = v129
	local v130
	if v_u_96.cta.stack then
		v130 = UDim2.new(1, 0, 0, v_u_96.cta.h)
	else
		v130 = UDim2.fromOffset(v_u_96.cta.w, v_u_96.cta.h)
	end
	v127.Size = v130
	local v_u_131 = v125(v126, v127, v_u_124)
	local v132 = v_u_10.new
	local v133 = "Frame"
	local v134 = {
		["Name"] = "BuyTiersHolder",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false
	}
	local v135
	if v_u_96.cta.stack then
		v135 = Vector2.new(0, 1)
	else
		v135 = Vector2.new(0, 0)
	end
	v134.AnchorPoint = v135
	local v136
	if v_u_96.cta.stack then
		v136 = UDim2.new(0, 0, 1, 0)
	else
		v136 = UDim2.new(0, 0, 0, v_u_96.cta.labelH)
	end
	v134.Position = v136
	local v137
	if v_u_96.cta.stack then
		v137 = UDim2.new(1, 0, 0, v_u_96.cta.h)
	else
		v137 = UDim2.fromOffset(v_u_96.cta.w, v_u_96.cta.h)
	end
	v134.Size = v137
	local v_u_138 = v132(v133, v134, v_u_124)
	local v_u_139 = { v_u_118, v_u_119, v_u_120 }
	local v_u_140 = false
	local v_u_141 = false
	local v_u_142 = false
	local v_u_143 = false
	local v_u_144 = v_u_10.new("Frame", {
		["Name"] = "GiftHolder",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromOffset(v_u_96.cta.w, v_u_96.cta.h)
	}, v_u_124)
	local function v_u_162(p145) -- name: placeHead
		-- upvalues: (ref) v_u_143, (copy) v_u_63, (copy) v_u_21, (ref) v_u_96, (ref) v_u_140, (copy) v_u_124, (copy) v_u_107, (copy) v_u_108, (copy) v_u_121, (copy) v_u_139, (copy) v_u_109, (ref) v_u_141, (copy) v_u_144, (ref) v_u_142, (copy) v_u_131, (copy) v_u_138
		v_u_143 = p145
		local v146
		if v_u_63 == nil then
			v146 = v_u_21.headCols(v_u_96, p145)
		else
			v146 = v_u_63.headCols(v_u_21, v_u_96, p145, v_u_140)
		end
		v_u_124.Size = UDim2.fromOffset(v146.ctaColW, v_u_96.headH)
		v_u_107.Size = UDim2.new(1, -(v146.ctaColW + v_u_96.gap + 190), 0, v_u_96.row1H)
		v_u_108.Position = UDim2.new(1, -(v146.ctaColW + v_u_96.gap + 190), 0, 0)
		v_u_121.Size = UDim2.new(1, -(v146.ctaColW + v_u_96.gap), 0, v_u_96.captionH)
		for v147, v148 in v_u_139 do
			v148.frame.Position = UDim2.fromOffset(v_u_96.tierChipW + v_u_96.gap + (v147 - 1) * (v146.meterW + v_u_96.gap), v_u_109)
			v148.frame.Size = UDim2.fromOffset(v146.meterW, v_u_96.meterH)
		end
		v_u_141 = v146.gift == true
		v_u_144.Visible = v_u_141
		if v_u_141 then
			local v149 = v_u_63.ctaRects(v_u_21, v_u_96, p145, true)
			v_u_142 = true
			v_u_131.AnchorPoint = Vector2.zero
			v_u_131.Position = UDim2.fromOffset(v149.unlock.x, v149.unlock.y)
			v_u_131.Size = UDim2.fromOffset(v149.unlock.w, v149.unlock.h)
			if v149.buy ~= nil then
				v_u_138.AnchorPoint = Vector2.zero
				v_u_138.Position = UDim2.fromOffset(v149.buy.x, v149.buy.y)
				v_u_138.Size = UDim2.fromOffset(v149.buy.w, v149.buy.h)
			end
			v_u_144.Position = UDim2.fromOffset(v149.gift.x, v149.gift.y)
			v_u_144.Size = UDim2.fromOffset(v149.gift.w, v149.gift.h)
		elseif v_u_142 then
			v_u_142 = false
			local v150 = v_u_131
			local v151
			if v_u_96.cta.stack then
				v151 = Vector2.new(0, 0)
			else
				v151 = Vector2.new(1, 0)
			end
			v150.AnchorPoint = v151
			local v152 = v_u_131
			local v153
			if v_u_96.cta.stack then
				v153 = UDim2.new(0, 0, 0, v_u_96.cta.labelH)
			else
				v153 = UDim2.new(1, 0, 0, v_u_96.cta.labelH)
			end
			v152.Position = v153
			local v154 = v_u_131
			local v155
			if v_u_96.cta.stack then
				v155 = UDim2.new(1, 0, 0, v_u_96.cta.h)
			else
				v155 = UDim2.fromOffset(v_u_96.cta.w, v_u_96.cta.h)
			end
			v154.Size = v155
			local v156 = v_u_138
			local v157
			if v_u_96.cta.stack then
				v157 = Vector2.new(0, 1)
			else
				v157 = Vector2.new(0, 0)
			end
			v156.AnchorPoint = v157
			local v158 = v_u_138
			local v159
			if v_u_96.cta.stack then
				v159 = UDim2.new(0, 0, 1, 0)
			else
				v159 = UDim2.new(0, 0, 0, v_u_96.cta.labelH)
			end
			v158.Position = v159
			local v160 = v_u_138
			local v161
			if v_u_96.cta.stack then
				v161 = UDim2.new(1, 0, 0, v_u_96.cta.h)
			else
				v161 = UDim2.fromOffset(v_u_96.cta.w, v_u_96.cta.h)
			end
			v160.Size = v161
		end
	end
	v_u_162(false)
	local v163 = v_u_96.headH + v_u_96.gap
	local v164 = v_u_21.subTabs()
	local _, v166 = v_u_10.tabs({
		["parent"] = nil,
		["tabs"] = nil,
		["selected"] = "rewards",
		["position"] = nil,
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_105,
		["tabs"] = v164,
		["position"] = UDim2.fromOffset(0, v163),
		["size"] = UDim2.fromOffset(#v164 * 120 + 12, v_u_96.subH),
		["onChange"] = function(p165) -- name: onChange
			-- upvalues: (copy) v_u_16
			v_u_16.setSub(p165)
		end
	})
	local v_u_167 = v_u_10.button({
		["parent"] = nil,
		["name"] = "HowToXp",
		["text"] = nil,
		["kind"] = "ghost",
		["icon"] = "info",
		["height"] = nil,
		["width"] = 164,
		["anchor"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_105,
		["text"] = v_u_23.xpButton,
		["height"] = v_u_96.subH,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, 0, 0, v163),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_16
			v_u_16.openXp()
		end
	})
	v_u_167.Visible = false
	local v168 = v163 + v_u_96.subH + v_u_96.gap
	local v169 = v_u_10.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v168),
		["Size"] = UDim2.new(1, 0, 1, -v168)
	}, v_u_105)
	local v_u_170 = v_u_10.new("Frame", {
		["Name"] = "Rewards",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v169)
	local v_u_171 = v_u_10.new("Frame", {
		["Name"] = "Missions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v169)
	local v172
	if v_u_96.mergeBar then
		v172 = v_u_105
	else
		v172 = v_u_170
	end
	local v173 = v_u_10.new
	local v174 = "Frame"
	local v175 = {
		["Name"] = "ClaimBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v176
	if v_u_96.mergeBar then
		v176 = UDim2.new(1, -(#v164 * 120 + 24 + 164 + v_u_96.gap), 0, v_u_96.subH)
	else
		v176 = UDim2.new(1, 0, 0, v_u_96.barH)
	end
	v175.Size = v176
	local v_u_177 = v173(v174, v175, v172)
	if v_u_96.mergeBar then
		v_u_177.AnchorPoint = Vector2.new(1, 0)
		v_u_177.Position = UDim2.new(1, -(164 + v_u_96.gap), 0, v163)
	else
		v_u_177.Position = UDim2.fromOffset(0, 0)
	end
	local v_u_178, v_u_179 = v_u_10.button({
		["parent"] = nil,
		["name"] = "ClaimAll",
		["text"] = nil,
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 190,
		["anchor"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_177,
		["text"] = v_u_23.claimAll,
		["height"] = v_u_96.subH,
		["anchor"] = Vector2.new(1, 0.5),
		["position"] = UDim2.new(1, 0, 0.5, 0),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_16
			v_u_16.claim(nil)
		end
	})
	local v_u_180 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["valign"] = "center",
		["size"] = nil,
		["parent"] = v_u_177,
		["color"] = v_u_12.text2,
		["size"] = UDim2.new(1, -202, 1, 0)
	})
	local v_u_181 = "MenuPassAttention"
	local v182, v183 = pcall(function()
		-- upvalues: (copy) v_u_14, (copy) v_u_181
		return v_u_14.lib[v_u_181]
	end)
	if not v182 then
		v183 = nil
	end
	local v_u_184
	if v183 == nil then
		v_u_184 = nil
	else
		local v185 = v183.attach
		local v186 = v_u_12.accent
		local v187
		v187, v_u_184 = pcall(v185, v_u_178, v186)
		if not v187 then
			v_u_184 = nil
		end
	end
	local v188 = v_u_96.mergeBar and 0 or v_u_96.barH + v_u_96.gap
	local v_u_189 = v_u_10.new("Frame", {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v188),
		["Size"] = UDim2.fromOffset(v_u_96.labelW, v_u_96.stripH)
	}, v_u_170)
	local v_u_190 = v_u_10.new("ScrollingFrame", {
		["Name"] = "Strip",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = nil,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.2,
		["ClipsDescendants"] = true,
		["ElasticBehavior"] = nil,
		["Position"] = UDim2.fromOffset(v_u_96.labelW + v_u_96.gap, v188),
		["Size"] = UDim2.new(1, -(v_u_96.labelW + v_u_96.gap), 0, v_u_96.stripH),
		["CanvasSize"] = UDim2.fromOffset(0, 0),
		["ScrollingDirection"] = Enum.ScrollingDirection.X,
		["ScrollBarThickness"] = v_u_11.scrollBar,
		["ScrollBarImageColor3"] = v_u_12.lineStrong,
		["ElasticBehavior"] = Enum.ElasticBehavior.WhenScrollable
	}, v_u_170)
	local v_u_191 = v_u_96.tierHdrH + 2
	local v_u_192 = v_u_191 + v_u_96.cellH + v_u_96.gap
	local function v197(p193, p194, p195) -- name: trackLabel
		-- upvalues: (copy) v_u_10, (copy) v_u_189, (ref) v_u_96
		local v196 = v_u_10.label({
			["parent"] = nil,
			["name"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = nil,
			["fit"] = nil,
			["valign"] = "center",
			["position"] = nil,
			["size"] = nil,
			["track"] = nil,
			["parent"] = v_u_189,
			["name"] = p193,
			["text"] = p193,
			["color"] = p195,
			["wrap"] = v_u_96.kind ~= "phone",
			["fit"] = v_u_96.kind == "phone",
			["position"] = UDim2.fromOffset(0, p194),
			["size"] = UDim2.fromOffset(v_u_96.labelW, v_u_96.cellH),
			["track"] = v_u_96.kind ~= "phone"
		})
		if v_u_96.kind == "phone" then
			v196.TextWrapped = false
		end
		return v196
	end
	local v_u_198 = v197(v_u_23.fieldName, v_u_191, v_u_12.text)
	local v_u_199 = v197(v_u_23.classifiedName, v_u_192, v_u_12.accent)
	local v_u_200 = v_u_10.list({
		["parent"] = nil,
		["name"] = "List",
		["size"] = nil,
		["gap"] = 10,
		["padding"] = nil,
		["parent"] = v_u_171,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local v_u_201
	if v51 == nil or v_u_45 == nil then
		v_u_201 = v86
	else
		local v202 = v51.new
		local v203
		v203, v_u_201 = pcall(v202, p_u_7, v_u_200, {
			["R"] = v_u_21,
			["L"] = v_u_96,
			["art"] = v_u_45,
			["claim"] = function() -- name: claim
				-- upvalues: (copy) p_u_7, (copy) v_u_21
				p_u_7.op({
					["op"] = v_u_21.OPS.missions
				})
			end
		})
		if not v203 or type(v_u_201) ~= "table" then
			v_u_201 = v86
		end
	end
	local function v_u_223() -- name: paintBar
		-- upvalues: (copy) v_u_21, (ref) v_u_66, (ref) v_u_72, (copy) v_u_12, (ref) v_u_75, (ref) v_u_76, (copy) v_u_23, (copy) v_u_180, (copy) v_u_179, (copy) v_u_178, (copy) v_u_37, (ref) v_u_184, (copy) v_u_11, (copy) v_u_15, (ref) v_u_71
		local v204 = v_u_21.claimPlan(v_u_66)
		local v205 = v_u_72 ~= nil
		local v206 = v_u_12.text2
		local v207
		if v_u_75 and os.clock() < v_u_76 then
			v207 = v_u_75
			v206 = v_u_12.danger
		elseif v205 then
			v207 = v_u_23.claiming
		else
			v207 = v_u_21.claimLine(v_u_66, v204)
		end
		v_u_180.Text = v207
		v_u_180.TextColor3 = v206
		local v208 = v_u_179.setText
		local v209
		if v205 then
			v209 = v_u_23.claiming
		else
			v209 = v_u_23.claimAll
		end
		v208(v209)
		local v210 = v_u_179.setEnabled
		local v211 = v204.ok
		if v211 then
			v211 = not v205
		end
		v210(v211)
		v_u_178.Visible = true
		local v212 = v_u_37
		local v213
		if type(v212) == "table" then
			local v214 = v_u_37.attention
			v213 = type(v214) ~= "function" and {
				["pulse"] = false,
				["count"] = 0
			} or v_u_37.attention((v204.count or 0) + (v204.milestones or 0), v205, false)
		else
			v213 = {
				["pulse"] = false,
				["count"] = 0
			}
		end
		if v_u_184 ~= nil then
			local v215 = v_u_11.reduced
			local v216, v217 = pcall(v215)
			local v218 = v_u_184.set
			local v219
			if v213.pulse == true then
				v219 = v204.ok == true
			else
				v219 = false
			end
			if v216 then
				v216 = v217 == true
			end
			v218(v219, v216)
		end
		local v220 = v_u_15
		local v221 = "PassClaimable"
		local v222
		if v213.count > 0 then
			v222 = v213.count
		else
			v222 = nil
		end
		v220:SetAttribute(v221, v222)
		v_u_15:SetAttribute("MenuPass", ("%d/%d %d %s"):format(v_u_66.tier or 0, v_u_66.count or 0, v204.count or 0, v_u_71))
	end
	local function v_u_225() -- name: closePreviews
		-- upvalues: (copy) v_u_88
		for _, v_u_224 in v_u_88 do
			pcall(function()
				-- upvalues: (copy) v_u_224
				if v_u_224.conn then
					v_u_224.conn:Disconnect()
				end
				if v_u_224.destroy then
					v_u_224.destroy()
				end
			end)
		end
		table.clear(v_u_88)
	end
	local function v_u_241(p226, p227, _) -- name: viewportOfModel
		-- upvalues: (copy) v_u_60
		local v_u_228 = p227:Clone()
		if #v_u_228:GetDescendants() > 400 then
			v_u_228:Destroy()
			return nil
		end
		local v_u_229 = Instance.new("ViewportFrame")
		v_u_229.Name = "View"
		v_u_229.BackgroundTransparency = 1
		v_u_229.Size = UDim2.fromScale(1, 1)
		if v_u_60 ~= nil then
			v_u_229.Ambient = Color3.fromRGB(v_u_60.LIGHT.ambient[1], v_u_60.LIGHT.ambient[2], v_u_60.LIGHT.ambient[3])
			v_u_229.LightColor = Color3.fromRGB(v_u_60.LIGHT.light[1], v_u_60.LIGHT.light[2], v_u_60.LIGHT.light[3])
		end
		v_u_229.Parent = p226
		local v230 = Instance.new("Camera")
		v230.FieldOfView = 30
		v230.Parent = v_u_229
		v_u_229.CurrentCamera = v230
		v_u_228.Parent = v_u_229
		local v_u_231, v232
		if v_u_228:IsA("Model") then
			v_u_231, v232 = v_u_228:GetBoundingBox()
		else
			if not v_u_228:IsA("BasePart") then
				v_u_229:Destroy()
				return nil
			end
			v_u_231 = v_u_228.CFrame
			v232 = v_u_228.Size
		end
		local v233 = v232.Magnitude / 2
		local v234 = v230.FieldOfView / 2
		local v235 = math.rad(v234)
		local v236 = v233 / math.tan(v235) * 1.15
		local v_u_237 = v_u_231.Position
		v230.CFrame = CFrame.lookAt(v_u_237 + (Vector3.new(0.45, 0.3, 1)).Unit * v236, v_u_237)
		local v_u_238 = v_u_231:ToObjectSpace(v_u_228:IsA("Model") and v_u_228:GetPivot() or v_u_228.CFrame)
		return {
			["turn"] = function(p239) -- name: turn
				-- upvalues: (copy) v_u_237, (ref) v_u_231, (copy) v_u_228, (copy) v_u_238
				local v240 = CFrame.new(v_u_237) * CFrame.Angles(0, p239, 0) * (v_u_231 - v_u_237)
				if v_u_228:IsA("Model") then
					v_u_228:PivotTo(v240 * v_u_238)
				else
					v_u_228.CFrame = v240 * v_u_238
				end
			end,
			["destroy"] = function() -- name: destroy
				-- upvalues: (copy) v_u_229
				v_u_229:Destroy()
			end
		}
	end
	local function v_u_328(p242, p_u_243, p244) -- name: buildPreview
		-- upvalues: (copy) v_u_11, (copy) v_u_60, (copy) v_u_14, (copy) v_u_10, (copy) v_u_12, (copy) v_u_57, (ref) v_u_96, (copy) p_u_7, (copy) v_u_88, (ref) v_u_4, (copy) v_u_241, (ref) v_u_2, (copy) v_u_45
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v245, v_u_246, v247, v248, v249, v250, v251, v_u_252, v253, v_u_254, v255, v256, v257, v258, v259, v260, v261, v262, v263, v_u_264, v265, v266, v267, v268, v269, v270, v_u_271, v272, v273, v274, v275, v276, v_u_277, v278, v279, v280, v281, v282, v283, v284, v285, v286, v287, v288, v289, v290, v_u_291, v292, v293, v_u_294, v295, v296, v297, v298, v299, v300, v301, v302, v303, v304, v305, v306, v_u_307, v308, v309, v310, v311, v_u_312, v313, v314, v315, v316, v317, v318, v319, v320, v321
		local v322 = 7
		while true do
			if v322 == 1 then
				if v309.mode == "skin3d" then
					v322 = 4
				else
					v322 = 5
				end
			elseif v322 == 2 then
				v261 = v_u_60.kcPlate
				v262 = v_u_96.modalW - 48
				v270 = v261(math.max(200, v262), p244, v309.mode == "kcAnim")
				v303 = v270.group
				v_u_271 = v_u_10.new("Frame", {
					["Name"] = "Preview",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(0.5, 0),
					["Size"] = UDim2.fromOffset(v303.w, v303.h)
				}, p242)
				v304 = v_u_57.new
				v305 = p_u_7
				v272 = {}
				v250 = v270.plate
				v272.plate = v250 ~= nil and {
					["x"] = v250.x - v303.x,
					["y"] = v250.y - v303.y,
					["w"] = v250.w,
					["h"] = v250.h
				} or nil
				v282 = v270.replay
				v272.replay = v282 ~= nil and {
					["x"] = v282.x - v303.x,
					["y"] = v282.y - v303.y,
					["w"] = v282.w,
					["h"] = v282.h
				} or nil
				v251, v_u_252 = pcall(v304, v305, v_u_271, p_u_243, v272)
				if v251 and type(v_u_252) == "table" then
					v289 = v_u_88
					table.insert(v289, {
						["destroy"] = function() -- name: destroy
							-- upvalues: (copy) v_u_252, (copy) v_u_271
							v_u_252.destroy()
							v_u_271:Destroy()
						end
					})
					return
				end
				v_u_271:Destroy()
				v322 = 3
			elseif v322 == 3 then
				if v_u_45 ~= nil then
					v_u_45.draw(p_u_7, p242, p_u_243, p244, {
						["name"] = "Preview",
						["anchor"] = nil,
						["position"] = nil,
						["itemRenders"] = true,
						["track"] = nil,
						["anchor"] = Vector2.new(0.5, 0),
						["position"] = UDim2.fromScale(0.5, 0),
						["track"] = function(p323) -- name: track
							-- upvalues: (ref) v_u_88
							local v324 = v_u_88
							table.insert(v324, {
								["destroy"] = p323
							})
						end
					})
				end
				return
			elseif v322 == 4 then
				v290 = v309.weapon
				if type(v290) == "string" then
					v322 = 6
				else
					v322 = 5
				end
			elseif v322 == 5 then
				if v309.mode == "wear3d" or v309.mode == "trophy3d" then
					v306 = v_u_10.new("Frame", {
						["Name"] = "Preview",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["ClipsDescendants"] = true,
						["AnchorPoint"] = Vector2.new(0.5, 0),
						["Position"] = UDim2.fromScale(0.5, 0),
						["Size"] = UDim2.fromOffset(p244, p244),
						["BackgroundColor3"] = v_u_12.raised
					}, p242)
					v_u_10.stroke(v306, v260, 1, 0.3)
					if p_u_243.kind == "wear" then
						v_u_307 = "SkinPreview"
						v317 = function()
							-- upvalues: (ref) v_u_14, (copy) v_u_307
							return v_u_14.lib[v_u_307]
						end
						v318, v319 = pcall(v317)
						if not v318 then
							v319 = nil
						end
						if v319 then
							v320 = v319.wearView
							if type(v320) == "function" then
								if v_u_60 == nil then
									v280 = nil
								else
									v280 = v_u_60.LIGHT
								end
								v281 = v319.wearView
								v248 = p_u_243.id
								v249 = {
									["size"] = UDim2.fromScale(1, 1)
								}
								if v280 then
									v314 = Color3.fromRGB(v280.ambient[1], v280.ambient[2], v280.ambient[3])
								else
									v314 = nil
								end
								v249.ambient = v314
								if v280 then
									v315 = Color3.fromRGB(v280.light[1], v280.light[2], v280.light[3])
								else
									v315 = nil
								end
								v249.lightColor = v315
								v275, v316 = pcall(v281, v306, v248, v249)
								if v275 and (type(v316) == "table" and v316.frame) then
									v263 = v316.turn
									v_u_264 = type(v263) == "function" and {
										["turn"] = v316.turn,
										["destroy"] = v316.destroy
									} or v308
								else
									v_u_264 = v308
								end
							else
								v_u_264 = v308
							end
						else
							v_u_264 = v308
						end
					else
						v265 = function()
							-- upvalues: (ref) v_u_4, (copy) p_u_243
							return v_u_4.HushAssets.Item:FindFirstChild(p_u_243.id)
						end
						v266, v321 = pcall(v265)
						if v266 and v321 then
							v276 = v_u_241
							v245, v_u_264 = pcall(v276, v306, v321, p244)
							if not v245 then
								v_u_264 = v308
							end
						else
							v_u_264 = v308
						end
					end
					if v_u_264 then
						v_u_277 = 0
						v278 = v_u_88
						v279 = {
							["conn"] = v_u_2.Heartbeat:Connect(function(p325)
								-- upvalues: (ref) v_u_277, (ref) v_u_264
								v_u_277 = v_u_277 + p325 * 0.7
								local v326 = v_u_264.turn
								local v327 = v_u_277
								pcall(v326, v327)
							end),
							["destroy"] = v_u_264.destroy
						}
						table.insert(v278, v279)
						return
					end
					v306:Destroy()
				end
				v322 = 3
			elseif v322 == 6 then
				v_u_246 = "SkinPreview"
				v247 = function()
					-- upvalues: (ref) v_u_14, (copy) v_u_246
					return v_u_14.lib[v_u_246]
				end
				v298, v299 = pcall(v247)
				if not v298 then
					v299 = nil
				end
				if v299 then
					v300 = v299.new
					if type(v300) == "function" then
						v267 = v_u_10.new("Frame", {
							["Name"] = "Preview",
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.1,
							["BorderSizePixel"] = 0,
							["ClipsDescendants"] = true,
							["AnchorPoint"] = Vector2.new(0.5, 0),
							["Position"] = UDim2.fromScale(0.5, 0),
							["Size"] = UDim2.fromOffset(p244, p244),
							["BackgroundColor3"] = v_u_12.raised
						}, p242)
						v_u_10.stroke(v267, v260, 1, 0.3)
						v268 = v299.new
						v269 = {
							["size"] = nil,
							["name"] = "Skin3d",
							["size"] = UDim2.fromScale(1, 1)
						}
						v301, v302 = pcall(v268, v267, v269)
						if v301 and (type(v302) == "table" and v302.frame ~= nil) then
							v283 = v302.show
							v284 = v309.weapon
							v285 = v309.skin
							pcall(v283, v284, v285)
							if v302.frame:FindFirstChild("Weapon") ~= nil then
								v286 = v_u_88
								v287 = {
									["destroy"] = v302.destroy
								}
								table.insert(v286, v287)
								return
							end
							v288 = v302.destroy
							pcall(v288)
						end
						v267:Destroy()
					end
				end
				v322 = 3
			else
				v259 = p_u_243.rarity
				v260 = v_u_11.rarityColor(v259 or 1)
				v308 = nil
				if v_u_60 == nil then
					v309 = {
						["mode"] = "art"
					}
				else
					v273 = v_u_60.mode
					v274 = {}
					v_u_291 = "PassHeroArt"
					v292 = function()
						-- upvalues: (ref) v_u_14, (copy) v_u_291
						return v_u_14.shared[v_u_291]
					end
					v310, v311 = pcall(v292)
					if not v310 then
						v311 = nil
					end
					v274.hero = v311
					v_u_312 = "SkinIcons"
					v313 = function()
						-- upvalues: (ref) v_u_14, (copy) v_u_312
						return v_u_14.shared[v_u_312]
					end
					v293, v253 = pcall(v313)
					if not v293 then
						v253 = nil
					end
					v274.icons = v253
					v_u_254 = "Skins"
					v255 = function()
						-- upvalues: (ref) v_u_14, (copy) v_u_254
						return v_u_14.shared[v_u_254]
					end
					v256, v257 = pcall(v255)
					if not v256 then
						v257 = nil
					end
					v274.skins = v257
					v_u_294 = "SkinFinishes"
					v295 = function()
						-- upvalues: (ref) v_u_14, (copy) v_u_294
						return v_u_14.shared[v_u_294]
					end
					v296, v297 = pcall(v295)
					if not v296 then
						v297 = nil
					end
					v274.finishes = v297
					v309 = v273(p_u_243, v274)
				end
				p242:SetAttribute("PreviewMode", v309.mode)
				if v309.mode == "hero" then
					v258 = v_u_10.new("Frame", {
						["Name"] = "Preview",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.1,
						["BorderSizePixel"] = 0,
						["ClipsDescendants"] = true,
						["AnchorPoint"] = Vector2.new(0.5, 0),
						["Position"] = UDim2.fromScale(0.5, 0),
						["Size"] = UDim2.fromOffset(p244, p244),
						["BackgroundColor3"] = v_u_12.raised
					}, p242)
					v_u_10.stroke(v258, v260, 1, 0.3)
					v_u_10.new("ImageLabel", {
						["Name"] = "Hero",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ScaleType"] = nil,
						["Size"] = nil,
						["Image"] = v309.image,
						["ScaleType"] = Enum.ScaleType.Fit,
						["Size"] = UDim2.fromScale(1, 1)
					}, v258)
					return
				end
				if (v309.mode == "kcAnim" or (v309.mode == "kcFrame" or v309.mode == "kcBg")) and (v_u_57 ~= nil and v_u_60 ~= nil) then
					v322 = 2
				else
					v322 = 1
				end
			end
		end
	end
	local function v_u_374(p_u_329, p_u_330) -- name: openDetail
		-- upvalues: (ref) v_u_89, (ref) v_u_66, (copy) v_u_21, (copy) v_u_23, (copy) v_u_16, (ref) v_u_70, (copy) v_u_63, (copy) v_u_10, (ref) v_u_96, (copy) v_u_225, (copy) v_u_328, (copy) v_u_11, (copy) v_u_60, (copy) v_u_12, (copy) v_u_13
		if v_u_89 then
			return
		else
			local v331 = v_u_66.cells[p_u_329]
			if v331 then
				local v_u_332
				if p_u_330 == "paid" then
					v_u_332 = v331.paid
				else
					v_u_332 = v331.free
				end
				if #v_u_332 ~= 0 then
					local v_u_333 = v_u_21.cellState(v_u_66, p_u_330, p_u_329)
					local v_u_334 = v_u_21.claimPlan(v_u_66, p_u_329, p_u_330)
					local v_u_335 = v_u_332[1]
					local v_u_336
					if p_u_330 == "paid" then
						v_u_336 = v_u_66.classifiedName
					else
						v_u_336 = v_u_66.fieldName
					end
					local v337 = {
						{
							["text"] = v_u_23.close,
							["kind"] = (v_u_333 == "claimable" and v_u_334.ok or v_u_333 == "lockedPaid") and "ghost" or "primary"
						}
					}
					if v_u_333 == "claimable" and v_u_334.ok then
						local v338 = {
							["text"] = nil,
							["kind"] = "primary",
							["onClick"] = nil,
							["text"] = v_u_23.claimTo:format(p_u_329),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_16, (copy) p_u_329, (copy) p_u_330
								task.defer(v_u_16.claim, p_u_329, p_u_330)
							end
						}
						table.insert(v337, v338)
					elseif v_u_333 == "lockedPaid" then
						local v339 = v_u_21.premium(v_u_66, v_u_70)
						if v339.kind == "buy" then
							local v340 = {
								["text"] = nil,
								["kind"] = "primary",
								["onClick"] = nil,
								["text"] = v339.text,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_16
									task.defer(v_u_16.buy)
								end
							}
							table.insert(v337, v340)
						end
						if v_u_63 ~= nil and v_u_63.visible(v_u_70) then
							local v341 = {
								["text"] = nil,
								["kind"] = "secondary",
								["onClick"] = nil,
								["text"] = v_u_63.TEXT,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_16
									task.defer(v_u_16.gift)
								end
							}
							table.insert(v337, v341)
						end
					end
					v_u_89 = v_u_10.modal({
						["title"] = v_u_335.name,
						["width"] = v_u_96.modalW,
						["buttons"] = v337,
						["onClose"] = function() -- name: onClose
							-- upvalues: (ref) v_u_225, (ref) v_u_89
							v_u_225()
							v_u_89 = nil
						end,
						["build"] = function(p342) -- name: build
							-- upvalues: (ref) v_u_96, (copy) v_u_335, (ref) v_u_10, (ref) v_u_328, (ref) v_u_11, (ref) v_u_21, (copy) v_u_336, (copy) p_u_329, (ref) v_u_60, (copy) v_u_332, (ref) v_u_12, (ref) v_u_13, (ref) v_u_23, (copy) v_u_333, (copy) v_u_334
							local v343 = v_u_96.kind == "phone" and 120 or 168
							local v344 = (v_u_335.kind == "kc_anim" or (v_u_335.kind == "kc_frame" or v_u_335.kind == "kc_bg")) and (v_u_96.kind == "phone" and 128 or 210) or v343
							v_u_328(v_u_10.new("Frame", {
								["Name"] = "PreviewHolder",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["LayoutOrder"] = 1,
								["Size"] = UDim2.new(1, 0, 0, v344)
							}, p342), v_u_335, v344)
							local v345 = v_u_335.rarity
							local v346 = v_u_11.rarityColor(v345 or 1)
							local v347 = v_u_21.KINDS[v_u_335.kind] or {
								["label"] = "Reward"
							}
							local v348 = v_u_21.RARITY
							local v349 = v_u_335.rarity or 1
							local v350 = v348[math.clamp(v349, 1, 7)]
							v_u_10.label({
								["parent"] = nil,
								["name"] = "Meta",
								["text"] = nil,
								["style"] = "monoS",
								["textSize"] = 12,
								["color"] = nil,
								["align"] = "center",
								["size"] = nil,
								["track"] = false,
								["parent"] = p342,
								["text"] = ("%s   %s   %s TIER %d"):format(v347.label, v350, v_u_336, p_u_329),
								["color"] = v346,
								["size"] = UDim2.new(1, 0, 0, 18)
							}).LayoutOrder = 2
							local v351 = 3
							for _, v352 in (v_u_60 == nil or v_u_60.rewardRows == nil) and {} or v_u_60.rewardRows(v_u_332, v_u_21.KINDS) do
								local v353 = v352.reward
								local v354 = v_u_10.new("Frame", {
									["Name"] = nil,
									["BackgroundTransparency"] = 1,
									["Size"] = nil,
									["AutomaticSize"] = nil,
									["LayoutOrder"] = nil,
									["Name"] = "Reward_" .. v353.id,
									["Size"] = UDim2.new(1, 0, 0, 0),
									["AutomaticSize"] = Enum.AutomaticSize.Y,
									["LayoutOrder"] = v351
								}, p342)
								v_u_10.layout(v354, "v", 2)
								if v352.name then
									local v355 = v_u_10.label
									local v356 = {
										["parent"] = nil,
										["text"] = nil,
										["style"] = "h3",
										["textSize"] = 15,
										["color"] = nil,
										["size"] = nil,
										["order"] = 1,
										["parent"] = v354,
										["text"] = v352.name
									}
									local v357 = v353.rarity
									v356.color = v_u_11.rarityColor(v357 or 1)
									v356.size = UDim2.new(1, 0, 0, 20)
									v355(v356)
								end
								if v352.line then
									v_u_10.label({
										["parent"] = nil,
										["text"] = nil,
										["style"] = "small",
										["textSize"] = 12,
										["color"] = nil,
										["size"] = nil,
										["order"] = 2,
										["parent"] = v354,
										["text"] = v352.line,
										["color"] = v_u_12.text2,
										["size"] = UDim2.new(1, 0, 0, 16)
									})
								end
								if v353.items then
									for v358, v_u_359 in v353.items do
										local function v360()
											-- upvalues: (ref) v_u_13, (copy) v_u_359
											return v_u_13.itemName(v_u_359.id)
										end
										local v361, v362 = pcall(v360)
										local v363 = v_u_10.label
										local v364 = {
											["parent"] = nil,
											["text"] = nil,
											["style"] = "small",
											["textSize"] = 12,
											["color"] = nil,
											["size"] = nil,
											["order"] = nil,
											["parent"] = v354
										}
										local v365 = "%d x %s"
										local v366 = v_u_359.n or 1
										if not v361 or (type(v362) ~= "string" or v362 == "") then
											v362 = v_u_359.id
										end
										v364.text = v365:format(v366, v362)
										v364.color = v_u_12.text
										v364.size = UDim2.new(1, 0, 0, 16)
										v364.order = 2 + v358
										v363(v364)
									end
								end
								v351 = v351 + 1
							end
							local v367 = v_u_335
							local v368 = v_u_21.KINDS[v367.kind]
							local v369
							if v368 == nil then
								v369 = false
							else
								v369 = v368.bound == true
							end
							if v369 then
								v_u_10.label({
									["parent"] = nil,
									["name"] = "Bound",
									["text"] = nil,
									["style"] = "small",
									["textSize"] = 12,
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["parent"] = p342,
									["text"] = v_u_23.bound,
									["color"] = v_u_12.text2
								}).LayoutOrder = v351
								v351 = v351 + 1
							end
							local v370
							if v_u_333 == "claimed" then
								v370 = "You already have this reward."
							elseif v_u_333 == "claimable" then
								v370 = not v_u_334.ok and "" or ("Claiming takes %d %s up to tier %d."):format(v_u_334.count, v_u_334.count == 1 and "reward" or "rewards", p_u_329)
							elseif v_u_333 == "lockedPaid" then
								v370 = v_u_23.premiumHint
							elseif v_u_333 == "expired" then
								v370 = v_u_23.ended
							else
								v370 = v_u_23.lockedHint:format(p_u_329)
							end
							local v371 = v_u_10.label
							local v372 = {
								["parent"] = nil,
								["name"] = "StateLine",
								["text"] = nil,
								["style"] = "small",
								["textSize"] = 13,
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["parent"] = p342,
								["text"] = v370
							}
							local v373
							if v_u_333 == "claimable" then
								v373 = v_u_12.accent
							else
								v373 = v_u_12.text2
							end
							v372.color = v373
							v371(v372).LayoutOrder = v351
						end
					})
				end
			else
				return
			end
		end
	end
	local function v_u_417(p375, p_u_376, p_u_377, p378, p379) -- name: buildCell
		-- upvalues: (copy) v_u_21, (ref) v_u_66, (copy) v_u_10, (copy) v_u_12, (ref) v_u_96, (copy) v_u_23, (copy) v_u_11, (copy) v_u_48, (copy) v_u_45, (copy) p_u_7, (copy) v_u_374
		local v380 = v_u_21.cellState(v_u_66, p_u_377, p_u_376)
		local v_u_381 = v_u_66.cells[p_u_376][p_u_377]
		if v380 == "empty" then
			local v382 = v_u_10.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.8,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Name"] = ("T%d_%s_empty"):format(p_u_376, p_u_377),
				["BackgroundColor3"] = v_u_12.raised,
				["Position"] = UDim2.fromOffset(p378, p379),
				["Size"] = UDim2.fromOffset(v_u_96.cellW, v_u_96.cellH)
			}, p375)
			v_u_10.stroke(v382, v_u_12.line, 1, 0.6)
			v_u_10.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v382,
				["text"] = v_u_23.noReward,
				["color"] = v_u_12.muted,
				["size"] = UDim2.fromScale(1, 1)
			})
			return
		else
			local v_u_383 = v_u_381[1]
			local v384 = v_u_383.rarity
			local v_u_385 = v_u_11.rarityColor(v384 or 1)
			local v386 = (v380 == "claimed" or v380 == "locked") and true or v380 == "expired"
			local v387 = v_u_10.new
			local v388 = "TextButton"
			local v389 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["ClipsDescendants"] = true,
				["Name"] = ("T%d_%s"):format(p_u_376, p_u_377)
			}
			local v390
			if v380 == "claimable" then
				v390 = v_u_12.accentDeep
			else
				v390 = v_u_12.raised
			end
			v389.BackgroundColor3 = v390
			v389.BackgroundTransparency = v380 == "claimed" and 0.5 or (v386 and 0.3 or 0.08)
			v389.Position = UDim2.fromOffset(p378, p379)
			v389.Size = UDim2.fromOffset(v_u_96.cellW, v_u_96.cellH)
			local v391 = v387(v388, v389, p375)
			v391.SelectionImageObject = v_u_10.selectionImage()
			local v392 = v_u_10.stroke
			local v393
			if v380 == "claimable" then
				v393 = v_u_12.accent
			elseif v380 == "lockedPaid" then
				v393 = v_u_12.accentDim or v_u_12.accent
			else
				v393 = v_u_12.line
			end
			v392(v391, v393, v380 == "claimable" and 2 or 1, v380 == "claimable" and 0 or 0.25)
			v_u_10.new("Frame", {
				["Name"] = "Rarity",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_385,
				["BackgroundTransparency"] = v386 and 0.45 or 0,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v391)
			local v394
			if v_u_48 == nil then
				v394 = nil
			else
				v394 = v_u_48.tileLayout(v_u_96.cellW, v_u_96.cellH)
			end
			if v394 ~= nil then
				local v395 = v394.class == "mini"
				if v_u_45 ~= nil then
					local v396 = v_u_45.draw(p_u_7, v391, v_u_383, v394.art.w, {
						["name"] = "Art",
						["position"] = nil,
						["position"] = UDim2.fromOffset(v394.art.x, v394.art.y)
					})
					if v386 then
						v_u_10.new("Frame", {
							["Name"] = "Veil",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.5,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["ZIndex"] = 5,
							["BackgroundColor3"] = v_u_12.bg,
							["Size"] = UDim2.fromScale(1, 1)
						}, v396)
					end
					if v380 == "claimed" or v380 == "lockedPaid" then
						local v397 = v_u_10.icon
						local v398 = v380 == "claimed" and "check" or "lock"
						local v399 = {
							["parent"] = nil,
							["size"] = nil,
							["color"] = nil,
							["anchor"] = nil,
							["position"] = nil,
							["zindex"] = 6,
							["parent"] = v396
						}
						local v400 = v394.art.w * 0.38
						local v401 = math.floor(v400)
						v399.size = math.max(10, v401)
						local v402
						if v380 == "claimed" then
							v402 = v_u_12.success
						else
							v402 = v_u_12.accent
						end
						v399.color = v402
						v399.anchor = Vector2.new(1, 1)
						v399.position = UDim2.new(1, -2, 1, -2)
						v397(v398, v399)
					end
				end
				if v394.tag then
					v_u_10.label({
						["parent"] = nil,
						["name"] = "Tag",
						["text"] = nil,
						["style"] = "micro",
						["textSize"] = 10,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v391,
						["text"] = (v_u_21.KINDS[v_u_383.kind] or {
							["tag"] = ""
						}).tag,
						["color"] = v_u_12.text2,
						["position"] = UDim2.fromOffset(v394.tag.x, v394.tag.y),
						["size"] = UDim2.fromOffset(v394.tag.w, v394.tag.h)
					})
				end
				local v403 = v_u_10.label
				local v404 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "small",
					["textSize"] = 12,
					["color"] = nil,
					["wrap"] = nil,
					["valign"] = "top",
					["fitWrap"] = false,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v391,
					["text"] = v_u_383.name
				}
				local v405
				if v386 then
					v405 = v_u_12.text2
				else
					v405 = v_u_12.text
				end
				v404.color = v405
				v404.wrap = not v395
				v404.position = UDim2.fromOffset(v394.name.x, v394.name.y)
				v404.size = UDim2.fromOffset(v394.name.w, v394.name.h)
				v403(v404).TextTruncate = Enum.TextTruncate.AtEnd
				local v406, v407
				if v380 == "claimed" then
					v406 = v_u_23.claimedStamp
					v407 = v_u_12.success
				elseif v380 == "claimable" then
					v407 = v_u_12.accent
					v406 = "CLAIM"
				elseif v380 == "lockedPaid" then
					v406 = v395 and "LOCKED" or (v_u_66.classifiedName or v_u_23.classifiedName)
					v407 = v_u_12.accentDim
					if not v407 then
						v407 = v_u_12.accent
					end
				elseif v380 == "expired" then
					v407 = v_u_12.muted
					v406 = "EXPIRED"
				else
					v406 = ("TIER %d"):format(p_u_376)
					v407 = v_u_12.muted
				end
				v_u_10.label({
					["parent"] = nil,
					["name"] = "State",
					["text"] = nil,
					["style"] = "micro",
					["textSize"] = 10,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v391,
					["text"] = v406,
					["color"] = v407,
					["position"] = UDim2.fromOffset(v394.state.x, v394.state.y),
					["size"] = UDim2.fromOffset(v394.state.w, v394.state.h)
				}).TextTruncate = Enum.TextTruncate.AtEnd
				if #v_u_381 > 1 then
					v_u_10.label({
						["parent"] = nil,
						["name"] = "More",
						["text"] = nil,
						["style"] = "micro",
						["textSize"] = 10,
						["color"] = nil,
						["align"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v391,
						["text"] = v_u_23.moreRewards:format(#v_u_381 - 1),
						["color"] = v_u_12.text2,
						["align"] = v395 and "left" or "right",
						["position"] = UDim2.fromOffset(v394.more.x, v394.more.y),
						["size"] = UDim2.fromOffset(v394.more.w, v394.more.h)
					}).TextTruncate = Enum.TextTruncate.AtEnd
				end
				v391.Activated:Connect(function()
					-- upvalues: (ref) v_u_374, (copy) p_u_376, (copy) p_u_377
					v_u_374(p_u_376, p_u_377)
				end)
				v_u_10.tooltip(v391, function()
					-- upvalues: (copy) p_u_377, (ref) v_u_66, (copy) p_u_376, (ref) v_u_21, (copy) v_u_383, (copy) v_u_381, (ref) v_u_23, (copy) v_u_385
					local v408 = {}
					local v409 = {
						["label"] = "Track",
						["value"] = nil
					}
					local v410
					if p_u_377 == "paid" then
						v410 = v_u_66.classifiedName
					else
						v410 = v_u_66.fieldName
					end
					v409.value = v410
					local v411 = {
						["label"] = "Tier",
						["value"] = nil
					}
					local v412 = p_u_376
					v411.value = tostring(v412)
					local v413 = {
						["label"] = "Rarity",
						["value"] = nil
					}
					local v414 = v_u_21.RARITY
					local v415 = v_u_383.rarity or 1
					v413.value = v414[math.clamp(v415, 1, 7)]
					__set_list(v408, 1, {v409, v411, v413})
					if #v_u_381 > 1 then
						local v416 = {
							["label"] = "Also",
							["value"] = nil,
							["value"] = v_u_23.moreRewards:format(#v_u_381 - 1)
						}
						table.insert(v408, v416)
					end
					return {
						["title"] = v_u_383.name,
						["body"] = (v_u_21.KINDS[v_u_383.kind] or {
							["label"] = "Reward"
						}).label,
						["lines"] = v408,
						["color"] = v_u_385
					}
				end)
			end
		end
	end
	local v_u_418
	if v_u_60 == nil or not v_u_97.show then
		v_u_418 = nil
	else
		v_u_418 = v_u_10.new("Frame", {
			["Name"] = "BuyStrip",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_12.raised,
			["Position"] = UDim2.fromOffset(0, v_u_97.y),
			["Size"] = UDim2.new(1, 0, 0, v_u_97.h)
		}, v_u_170)
		v_u_10.stroke(v_u_418, v_u_12.line, 1, 0.3)
	end
	local function v_u_434() -- name: drawBuyStrip
		-- upvalues: (ref) v_u_418, (copy) v_u_13, (copy) v_u_60, (copy) v_u_21, (ref) v_u_66, (ref) v_u_81, (ref) v_u_80, (ref) v_u_70, (ref) v_u_77, (ref) v_u_96, (ref) v_u_97, (copy) v_u_10, (copy) v_u_12, (copy) v_u_63, (copy) v_u_16, (ref) v_u_6
		if v_u_418 == nil then
			return
		else
			v_u_13.clear(v_u_418)
			local v419 = v_u_60.stripItems(v_u_21, v_u_66, v_u_81, v_u_80, v_u_70, os.clock() < v_u_77)
			local v420 = v_u_60.stripLayout(v_u_96.w, v_u_97.avail, v_u_96.ctl, #v419)
			v_u_418.Visible = v420.show == true
			if v420.show then
				v_u_418.Size = UDim2.new(1, 0, 0, v420.h)
				v_u_418:SetAttribute("Mode", v420.mode)
				if v420.title then
					v_u_10.label({
						["parent"] = nil,
						["name"] = "StripTitle",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v_u_418,
						["text"] = v_u_60.TITLE,
						["color"] = v_u_12.accent,
						["position"] = UDim2.fromOffset(v420.title.x, v420.title.y),
						["size"] = UDim2.fromOffset(v420.title.w, v420.title.h)
					})
				end
				for v421, v_u_422 in v419 do
					local v423 = v420.cards[v421]
					local v424 = v423.button
					if v_u_422.kind == "premium" and v_u_63 ~= nil then
						local v425 = v_u_63.stripSplit(v423.button, v_u_63.visible(v_u_70))
						if v425 ~= nil then
							v424 = v425.unlock
							v_u_10.button({
								["parent"] = nil,
								["name"] = "StripGift",
								["text"] = nil,
								["kind"] = "secondary",
								["icon"] = "heart",
								["height"] = nil,
								["width"] = nil,
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = v_u_418,
								["text"] = v_u_63.TEXT,
								["height"] = v425.gift.h,
								["width"] = v425.gift.w,
								["position"] = UDim2.fromOffset(v425.gift.x, v425.gift.y),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_16
									v_u_16.gift()
								end
							})
						end
					end
					local v426, v427 = v_u_10.button({
						["parent"] = v_u_418,
						["name"] = v_u_422.kind == "premium" and "StripUnlock" or ("StripSkip_%d"):format(v_u_422.tiers or 0),
						["text"] = v_u_422.label,
						["kind"] = v_u_422.primary and v_u_422.canPress and "primary" or "secondary",
						["height"] = v424.h,
						["width"] = v424.w,
						["maxTextWidth"] = v424.w - 40,
						["position"] = UDim2.fromOffset(v424.x, v424.y),
						["disabled"] = not v_u_422.canPress,
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) v_u_422, (ref) v_u_16
							if v_u_422.kind == "premium" then
								v_u_16.buy()
							else
								v_u_16.buySkip(v_u_422.key)
							end
						end
					})
					local v428 = v427.label
					v428.RichText = true
					v428.TextSize = 13
					if v_u_422.state == "buy" and v_u_422.price then
						v428.Text = ("%s\n<font face=\"GothamBold\">%s</font> %s"):format(v_u_422.label, v_u_6, v_u_10.commas(v_u_422.price))
					elseif v_u_422.sub then
						v428.Text = v_u_422.label .. "\n" .. v_u_422.sub
					end
					v_u_10.tooltip(v426, function()
						-- upvalues: (copy) v_u_422, (ref) v_u_12
						local v429 = {
							["title"] = v_u_422.label,
							["body"] = v_u_422.note or v_u_422.caption
						}
						local v430
						if v_u_422.state == "blocked" then
							v430 = v_u_12.danger
						else
							v430 = v_u_12.accent
						end
						v429.color = v430
						return v429
					end)
					if not v423.caption then
						continue
					end
					local v431 = v_u_10.label
					local v432 = {
						["parent"] = nil,
						["name"] = "StripCaption",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v_u_418,
						["text"] = v_u_422.caption
					}
					local v433
					if v_u_422.state == "blocked" then
						v433 = v_u_12.danger
					else
						v433 = v_u_12.text2
					end
					v432.color = v433
					v432.position = UDim2.fromOffset(v423.caption.x, v423.caption.y)
					v432.size = UDim2.fromOffset(v423.caption.w, v423.caption.h)
					v431(v432).TextTruncate = Enum.TextTruncate.AtEnd
				end
			end
		end
	end
	local function v_u_445() -- name: drawCta
		-- upvalues: (copy) v_u_63, (ref) v_u_70, (ref) v_u_140, (copy) v_u_162, (ref) v_u_143, (copy) v_u_13, (copy) v_u_144, (ref) v_u_141, (copy) v_u_10, (ref) v_u_96, (copy) v_u_16, (copy) v_u_434, (copy) v_u_131, (copy) v_u_21, (ref) v_u_66, (copy) v_u_12, (copy) v_u_23, (ref) v_u_77, (ref) v_u_6
		local v435
		if v_u_63 == nil then
			v435 = false
		else
			v435 = v_u_63.visible(v_u_70)
		end
		if v435 ~= v_u_140 then
			v_u_140 = v435
			v_u_162(v_u_143)
		end
		v_u_13.clear(v_u_144)
		if v_u_141 then
			v_u_10.button({
				["parent"] = nil,
				["name"] = "Gift",
				["text"] = nil,
				["kind"] = "secondary",
				["icon"] = "heart",
				["height"] = nil,
				["size"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_144,
				["text"] = v_u_63.TEXT,
				["height"] = v_u_96.cta.h,
				["size"] = UDim2.fromScale(1, 1),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_16
					v_u_16.gift()
				end
			})
		end
		v_u_434()
		v_u_13.clear(v_u_131)
		local v436 = v_u_21.premium(v_u_66, v_u_70)
		if v436.kind == "owned" then
			local v437 = v_u_10.new("Frame", {
				["Name"] = "Owned",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_12.raised,
				["Size"] = UDim2.fromScale(1, 1)
			}, v_u_131)
			v_u_10.stroke(v437, v_u_12.success, 1, 0.3)
			v_u_10.tooltip(v437, function()
				-- upvalues: (ref) v_u_23, (ref) v_u_21, (ref) v_u_12
				return {
					["title"] = v_u_23.title,
					["body"] = v_u_21.bothLines(true),
					["color"] = v_u_12.success
				}
			end)
			v_u_10.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = 14,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["parent"] = v437,
				["text"] = v_u_23.owned,
				["color"] = v_u_12.success,
				["size"] = UDim2.fromScale(1, 1)
			})
		else
			local v438 = os.clock() < v_u_77
			local v439 = v_u_10.button
			local v440 = {
				["parent"] = nil,
				["name"] = "Unlock",
				["text"] = nil,
				["kind"] = nil,
				["height"] = nil,
				["size"] = nil,
				["disabled"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_131
			}
			local v441
			if v436.kind == "buy" then
				v441 = v_u_23.unlock
			else
				v441 = v436.text
			end
			v440.text = v441
			v440.kind = v436.kind == "buy" and "primary" or "secondary"
			v440.height = v_u_96.cta.h
			v440.size = UDim2.fromScale(1, 1)
			v440.disabled = v436.kind ~= "buy"
			function v440.onClick() -- name: onClick
				-- upvalues: (ref) v_u_16
				v_u_16.buy()
			end
			local v442, v443 = v439(v440)
			v_u_10.tooltip(v442, function()
				-- upvalues: (ref) v_u_23, (ref) v_u_21, (ref) v_u_12
				return {
					["title"] = v_u_23.title,
					["body"] = v_u_21.bothLines(false),
					["color"] = v_u_12.accent
				}
			end)
			if v436.kind == "buy" then
				local v444 = v443.label
				v444.RichText = true
				if v436.price then
					v444.Text = ("%s  <font face=\"GothamBold\">%s</font> %s"):format(string.upper("Unlock"), v_u_6, v_u_10.commas(v436.price))
					return
				end
				if v438 then
					v444.Text = "WAITING..."
				end
			end
		end
	end
	local function v_u_447() -- name: drawBuy
		-- upvalues: (copy) v_u_13, (copy) v_u_138, (copy) v_u_21, (ref) v_u_66, (copy) v_u_162, (copy) v_u_10, (copy) v_u_23, (ref) v_u_96, (copy) v_u_16
		v_u_13.clear(v_u_138)
		local v446 = v_u_21.canBuyTiers(v_u_66)
		v_u_138.Visible = v446
		v_u_162(v446)
		if v446 then
			v_u_10.button({
				["parent"] = nil,
				["name"] = "BuyTiers",
				["text"] = nil,
				["kind"] = "secondary",
				["height"] = nil,
				["size"] = nil,
				["onClick"] = nil,
				["parent"] = v_u_138,
				["text"] = v_u_23.buyTiers,
				["height"] = v_u_96.cta.h,
				["size"] = UDim2.fromScale(1, 1),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_16
					v_u_16.openBuy()
				end
			})
		end
	end
	local v_u_448 = {
		["buy"] = "Instant, no daily limit",
		["soon"] = "Not available yet.",
		["off"] = "Not for sale right now.",
		["wait"] = "Waiting for the purchase..."
	}
	function v_u_16.openBuy() -- name: openBuy
		-- upvalues: (ref) v_u_82, (ref) v_u_89, (copy) v_u_21, (ref) v_u_66, (ref) v_u_81, (ref) v_u_80, (copy) v_u_10, (copy) v_u_23, (ref) v_u_96, (copy) v_u_12, (copy) v_u_448, (copy) v_u_16, (ref) v_u_6
		if v_u_82 == nil and (v_u_89 == nil and v_u_21.canBuyTiers(v_u_66)) then
			local v_u_449 = v_u_21.skipRows(v_u_66, v_u_81, v_u_80)
			local v450 = v_u_10.modal
			local v465 = {
				["title"] = v_u_23.buyTitle,
				["width"] = v_u_96.modalW,
				["buttons"] = {
					{
						["text"] = nil,
						["kind"] = "primary",
						["text"] = v_u_23.close
					}
				},
				["onClose"] = function() -- name: onClose
					-- upvalues: (ref) v_u_82
					v_u_82 = nil
				end,
				["build"] = function(p451) -- name: build
					-- upvalues: (ref) v_u_10, (ref) v_u_23, (ref) v_u_12, (copy) v_u_449, (ref) v_u_96, (ref) v_u_448, (ref) v_u_16, (ref) v_u_6, (ref) v_u_66
					v_u_10.label({
						["parent"] = nil,
						["name"] = "Intro",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 13,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = p451,
						["text"] = v_u_23.buyBody,
						["color"] = v_u_12.text2
					}).LayoutOrder = 1
					for v452, v_u_453 in v_u_449 do
						local v454 = v_u_10.new
						local v455 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.1,
							["BorderSizePixel"] = 0,
							["LayoutOrder"] = nil,
							["Size"] = nil,
							["Name"] = "Pack_" .. v_u_453.key,
							["BackgroundColor3"] = v_u_12.raised,
							["LayoutOrder"] = 1 + v452
						}
						local v456 = UDim2.new
						local v457 = v_u_96.cta.h + 16
						v455.Size = v456(1, 0, 0, (math.max(60, v457)))
						local v458 = v454("Frame", v455, p451)
						v_u_10.stroke(v458, v_u_12.line, 1, 0)
						v_u_10.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = nil,
							["style"] = "h3",
							["textSize"] = 15,
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v458,
							["text"] = v_u_453.label,
							["color"] = v_u_12.text,
							["position"] = UDim2.fromOffset(10, 6),
							["size"] = UDim2.new(1, -160, 0, 20)
						})
						local v459 = v_u_10.label
						local v460 = {
							["parent"] = nil,
							["name"] = "Sub",
							["text"] = nil,
							["style"] = "small",
							["textSize"] = 12,
							["color"] = nil,
							["wrap"] = true,
							["valign"] = "top",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v458
						}
						local v461
						if v_u_453.state == "blocked" then
							v461 = v_u_453.why or v_u_23.packNone
						else
							v461 = v_u_448[v_u_453.state] or ""
						end
						v460.text = v461
						local v462
						if v_u_453.state == "blocked" then
							v462 = v_u_12.danger
						else
							v462 = v_u_12.text2
						end
						v460.color = v462
						v460.position = UDim2.fromOffset(10, 28)
						v460.size = UDim2.new(1, -160, 0, 28)
						v459(v460).TextTruncate = Enum.TextTruncate.AtEnd
						local _, v463 = v_u_10.button({
							["parent"] = nil,
							["name"] = "Buy",
							["text"] = nil,
							["kind"] = nil,
							["height"] = nil,
							["width"] = 132,
							["anchor"] = nil,
							["position"] = nil,
							["disabled"] = nil,
							["onClick"] = nil,
							["parent"] = v458,
							["text"] = v_u_453.text,
							["kind"] = v_u_453.canPress and "primary" or "secondary",
							["height"] = v_u_96.cta.h,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, -8, 0.5, 0),
							["disabled"] = not v_u_453.canPress,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_16, (copy) v_u_453
								v_u_16.buySkip(v_u_453.key)
							end
						})
						if v_u_453.state ~= "buy" or not v_u_453.price then
							continue
						end
						local v464 = v463.label
						v464.RichText = true
						v464.Text = ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_6, v_u_10.commas(v_u_453.price))
					end
					v_u_10.label({
						["parent"] = nil,
						["name"] = "Note",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 13,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = p451,
						["text"] = v_u_66.skipNote,
						["color"] = v_u_12.accent
					}).LayoutOrder = 100
					v_u_10.label({
						["parent"] = nil,
						["name"] = "TiersHere",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 13,
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = p451,
						["text"] = v_u_23.tiersHere,
						["color"] = v_u_12.text2
					}).LayoutOrder = 101
				end
			}
			v_u_82 = v450(v465)
		end
	end
	function v_u_16.buySkip(p466) -- name: buySkip
		-- upvalues: (copy) v_u_21, (ref) v_u_66, (ref) v_u_80, (ref) v_u_81, (copy) v_u_434, (ref) v_u_79, (ref) v_u_78, (ref) v_u_83, (ref) v_u_82, (ref) v_u_75, (copy) p_u_7
		local v467 = v_u_21.skipOp(p466)
		if v467 == nil or (not v_u_21.canBuyTiers(v_u_66) or v_u_80 ~= nil) then
			return
		else
			local v468 = false
			for _, v469 in v_u_21.skipRows(v_u_66, v_u_81, nil) do
				if v469.key ~= p466 or not v469.canPress then
					continue
				end
				v468 = true
			end
			if v468 then
				v_u_80 = p466
				v_u_434()
				v_u_79 = v_u_66.bought
				v_u_78 = os.clock() + 90
				v_u_83 = os.clock()
				local v470 = v_u_82
				v_u_82 = nil
				if v470 then
					local v471 = v470.close
					if type(v471) == "function" then
						local v472 = v470.close
						pcall(v472)
					end
				end
				v_u_75 = nil
				p_u_7.op(v467)
			end
		end
	end
	local function v_u_473() -- name: drawMissions
		-- upvalues: (ref) v_u_201, (ref) v_u_66, (ref) v_u_67, (copy) v_u_10, (copy) v_u_200, (copy) v_u_13, (copy) v_u_23
		if v_u_201 == nil then
			v_u_10.keepScroll(v_u_200, function()
				-- upvalues: (ref) v_u_13, (ref) v_u_200, (ref) v_u_23
				v_u_13.clear(v_u_200)
				v_u_13.empty(v_u_200, v_u_23.missionsOffOther, 1)
			end)
		else
			v_u_201.draw(v_u_66, os.clock() - v_u_67)
		end
	end
	local function v_u_475() -- name: paintTimers
		-- upvalues: (ref) v_u_67, (ref) v_u_66, (copy) v_u_108, (copy) v_u_21, (copy) v_u_121, (ref) v_u_201
		local v474 = os.clock() - v_u_67
		if v_u_66.ok then
			v_u_108.Text = v_u_21.timeLine(v_u_66, v474)
			v_u_121.Text = v_u_21.captionLine(v_u_66, v474)
		end
		if v_u_201 ~= nil then
			v_u_201.tick(v474)
		end
	end
	local function v_u_483() -- name: paintHead
		-- upvalues: (copy) v_u_107, (ref) v_u_66, (copy) v_u_111, (copy) v_u_118, (copy) v_u_21, (copy) v_u_119, (copy) v_u_120, (ref) v_u_198, (ref) v_u_199, (ref) v_u_122, (copy) v_u_23, (copy) v_u_475
		v_u_107.Text = v_u_66.name
		local v476 = v_u_111
		local v477 = v_u_66.tier
		v476.Text = tostring(v477)
		local v478
		if v_u_66.tier >= v_u_66.count then
			v478 = 1
		else
			local v479 = v_u_66.into
			local v480 = v_u_66.per
			v478 = v479 / math.max(1, v480)
		end
		v_u_118.cap.Text = v_u_21.xpLine(v_u_66)
		v_u_118.bar.set(v478, true)
		local v481 = v_u_21.boughtLine(v_u_66)
		v_u_118.val.TextTruncate = Enum.TextTruncate.AtEnd
		v_u_118.val.Text = ("%s XP"):format(v_u_21.commas(v_u_66.xp)) .. (v481 == "" and "" or "   " .. v481)
		local v482 = v_u_21.allowance(v_u_66)
		v_u_119.bar.set(v482.availFrac, true)
		v_u_119.val.Text = v482.availText
		v_u_120.bar.set(v482.pendFrac, true)
		v_u_120.val.Text = v482.pendText
		v_u_198.Text = v_u_66.fieldName
		v_u_199.Text = v_u_66.classifiedName
		v_u_122 = table.concat({ v_u_23.limitBody, v482.caption, v482.floorText }, "\n")
		v_u_475()
	end
	function v_u_16.draw() -- name: draw
		-- upvalues: (ref) v_u_17, (ref) v_u_66, (copy) v_u_105, (copy) v_u_167, (copy) v_u_102, (copy) v_u_104, (ref) v_u_69, (copy) v_u_103, (copy) v_u_21, (copy) v_u_23, (copy) p_u_7, (ref) v_u_65, (copy) v_u_15, (copy) v_u_483, (copy) v_u_445, (copy) v_u_447, (copy) v_u_10, (copy) v_u_190, (copy) v_u_13, (ref) v_u_96, (copy) v_u_192, (copy) v_u_12, (copy) v_u_417, (copy) v_u_191, (copy) v_u_473, (copy) v_u_170, (ref) v_u_71, (copy) v_u_171, (copy) v_u_177, (copy) v_u_223, (ref) v_u_85, (ref) v_u_82, (ref) v_u_84
		if v_u_17 then
			if v_u_66.ok then
				v_u_102.Visible = false
				v_u_105.Visible = true
				v_u_483()
				v_u_167.Visible = v_u_21.xpGuide(v_u_66).ok
				v_u_445()
				v_u_447()
				v_u_10.keepScroll(v_u_190, function()
					-- upvalues: (ref) v_u_13, (ref) v_u_190, (ref) v_u_21, (ref) v_u_96, (ref) v_u_66, (ref) v_u_192, (ref) v_u_10, (ref) v_u_12, (ref) v_u_417, (ref) v_u_191
					v_u_13.clear(v_u_190)
					local v484 = v_u_21.stripWidth(v_u_96, v_u_66)
					local v485 = v_u_192 + v_u_96.cellH + 2
					v_u_190.CanvasSize = UDim2.fromOffset(v484, v_u_96.stripH - v_u_96.scrollBar >= v485 and 0 or v485)
					local v486 = v_u_190
					local v487
					if v_u_96.stripH - v_u_96.scrollBar < v485 then
						v487 = Enum.ScrollingDirection.XY
					else
						v487 = Enum.ScrollingDirection.X
					end
					v486.ScrollingDirection = v487
					for v488 = 1, v_u_66.count do
						local v489 = v_u_96.gap + (v488 - 1) * (v_u_96.cellW + v_u_96.gap)
						local v490 = v488 <= v_u_66.tier
						local v491 = v_u_10.label
						local v492 = {
							["parent"] = nil,
							["name"] = nil,
							["text"] = nil,
							["style"] = "monoS",
							["textSize"] = 12,
							["color"] = nil,
							["align"] = "center",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v_u_190,
							["name"] = "Hdr" .. v488,
							["text"] = tostring(v488)
						}
						local v493
						if v488 == v_u_66.tier then
							v493 = v_u_12.accent
						elseif v490 then
							v493 = v_u_12.text
						else
							v493 = v_u_12.muted
						end
						v492.color = v493
						v492.position = UDim2.fromOffset(v489, 0)
						v492.size = UDim2.fromOffset(v_u_96.cellW, v_u_96.tierHdrH)
						v491(v492)
						if v488 == v_u_66.tier then
							v_u_10.new("Frame", {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["Name"] = "Here" .. v488,
								["BackgroundColor3"] = v_u_12.accent,
								["Position"] = UDim2.fromOffset(v489, v_u_96.tierHdrH),
								["Size"] = UDim2.fromOffset(v_u_96.cellW, 2)
							}, v_u_190)
						end
						v_u_417(v_u_190, v488, "free", v489, v_u_191)
						v_u_417(v_u_190, v488, "paid", v489, v_u_192)
					end
				end)
				v_u_473()
				v_u_170.Visible = v_u_71 == "rewards"
				v_u_171.Visible = v_u_71 == "missions"
				v_u_177.Visible = v_u_71 == "rewards"
				v_u_223()
				if not v_u_85 then
					v_u_85 = true
					task.defer(function()
						-- upvalues: (ref) v_u_17, (ref) v_u_190, (ref) v_u_21, (ref) v_u_96, (ref) v_u_66
						if v_u_17 and v_u_190.Parent then
							v_u_190.CanvasPosition = Vector2.new(v_u_21.scrollX(v_u_96, v_u_21.focusTier(v_u_66)), 0)
						end
					end)
				end
				if v_u_82 ~= nil and not v_u_21.canBuyTiers(v_u_66) then
					local v494 = v_u_82
					v_u_82 = nil
					if v494 then
						local v495 = v494.close
						if type(v495) == "function" then
							local v496 = v494.close
							pcall(v496)
						end
					end
				end
				v_u_84 = true
			else
				v_u_105.Visible = false
				v_u_167.Visible = false
				v_u_102.Visible = true
				v_u_104.Visible = v_u_69
				if v_u_66.noSeason then
					local v497 = v_u_103
					local v498
					if v_u_66.code and v_u_21.ERRORS[v_u_66.code] then
						v498 = v_u_21.ERRORS[v_u_66.code]
					else
						v498 = v_u_23.noSeason
					end
					v497.Text = v498
				elseif v_u_69 then
					v_u_103.Text = p_u_7.failText(v_u_21.GET, v_u_23.failed)
				elseif v_u_65 == nil then
					v_u_103.Text = v_u_23.loading
				else
					v_u_103.Text = v_u_23.failed
				end
				v_u_15:SetAttribute("MenuPass", "none")
			end
		else
			return
		end
	end
	function v_u_16.setSub(p499) -- name: setSub
		-- upvalues: (ref) v_u_71, (copy) v_u_170, (copy) v_u_171, (copy) v_u_177, (copy) v_u_223
		if p499 == "rewards" or p499 == "missions" then
			v_u_71 = p499
			v_u_170.Visible = v_u_71 == "rewards"
			v_u_171.Visible = v_u_71 == "missions"
			v_u_177.Visible = v_u_71 == "rewards"
			v_u_223()
		end
	end
	function v_u_16.openXp() -- name: openXp
		-- upvalues: (ref) v_u_87, (ref) v_u_89, (ref) v_u_82, (copy) v_u_54, (ref) v_u_66, (copy) p_u_7, (copy) v_u_21, (ref) v_u_96
		if v_u_87 == nil and (v_u_89 == nil and (v_u_82 == nil and (v_u_54 ~= nil and v_u_66.ok))) then
			local v500 = v_u_54.open
			local v501 = p_u_7
			local v502 = v_u_21
			local v503 = v_u_66
			local v504 = v_u_96.modalW
			local function v505()
				-- upvalues: (ref) v_u_87
				v_u_87 = nil
			end
			local v506, v507 = pcall(v500, v501, v502, v503, v504, v505)
			if v506 and type(v507) == "table" then
				v_u_87 = v507
			end
		end
	end
	function v_u_16.claim(p508, p509) -- name: claim
		-- upvalues: (ref) v_u_72, (copy) v_u_21, (ref) v_u_66, (ref) v_u_75, (ref) v_u_76, (copy) v_u_223, (ref) v_u_73, (ref) v_u_74, (copy) p_u_7
		if v_u_72 then
			return
		else
			local v510 = v_u_21.claimPlan(v_u_66, p508, p509)
			local v511 = v_u_21.claimOp(v510)
			if v511 then
				v_u_75 = nil
				v_u_72 = os.clock() + 10
				v_u_73 = 0
				v_u_74 = table.clone(v511)
				p_u_7.op(v511)
				v_u_223()
			else
				v_u_75 = v_u_21.errorText(v510.why, nil)
				v_u_76 = os.clock() + 8
				v_u_223()
			end
		end
	end
	function v_u_16.buy() -- name: buy
		-- upvalues: (copy) v_u_21, (ref) v_u_66, (ref) v_u_70, (ref) v_u_77, (ref) v_u_83, (copy) p_u_7, (copy) v_u_445
		if v_u_21.premium(v_u_66, v_u_70).kind == "buy" then
			v_u_77 = os.clock() + 90
			v_u_83 = os.clock()
			p_u_7.op({
				["op"] = "storeBuy",
				["id"] = nil,
				["id"] = v_u_21.PRODUCT
			})
			v_u_445()
		end
	end
	local v_u_512 = {}
	local function v_u_530() -- name: giftDialog
		-- upvalues: (ref) v_u_64, (copy) v_u_14, (copy) p_u_7, (copy) v_u_512, (ref) v_u_3, (ref) v_u_6, (copy) v_u_10
		if v_u_64 ~= nil then
			return v_u_64
		end
		local v_u_513 = "MenuStoreGive"
		local function v514()
			-- upvalues: (ref) v_u_14, (copy) v_u_513
			return v_u_14.lib[v_u_513]
		end
		local v515, v516 = pcall(v514)
		if not v515 then
			v516 = nil
		end
		if v516 == nil then
			return nil
		end
		local v517 = v516.new
		local v518 = p_u_7
		local v527 = {
			["clientPrice"] = function(p_u_519, _) -- name: clientPrice
				-- upvalues: (ref) v_u_512, (ref) v_u_3
				if p_u_519 <= 0 then
					return nil
				end
				local v520 = v_u_512[p_u_519]
				if v520 == nil or os.clock() - v520.t > 120 then
					local function v521()
						-- upvalues: (ref) v_u_3, (copy) p_u_519
						return v_u_3:GetProductInfoAsync(p_u_519, Enum.InfoType.Product)
					end
					local v522, v523 = pcall(v521)
					v520 = {}
					local v524
					if v522 and type(v523) == "table" then
						local v525 = v523.PriceInRobux
						v524 = tonumber(v525)
					else
						v524 = nil
					end
					v520.price = v524
					v520.t = os.clock()
					v_u_512[p_u_519] = v520
				end
				return v520.price
			end,
			["priceRich"] = function(p526) -- name: priceRich
				-- upvalues: (ref) v_u_6, (ref) v_u_10
				return not p526 and "GIFT" or ("<font face=\"GothamBold\">%s</font> %s"):format(v_u_6, v_u_10.commas(p526))
			end
		}
		local v528, v529 = pcall(v517, v518, v527)
		if v528 then
			v_u_64 = v529
		end
		return v_u_64
	end
	function v_u_16.gift() -- name: gift
		-- upvalues: (ref) v_u_17, (copy) v_u_63, (ref) v_u_70, (copy) v_u_530
		if v_u_17 and (v_u_63 ~= nil and v_u_63.visible(v_u_70)) then
			local v531 = v_u_530()
			if v531 ~= nil then
				v531.openGift(v_u_70)
			end
		end
	end
	function v_u_16.load(p_u_532) -- name: load
		-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_84, (copy) v_u_16, (copy) p_u_7, (copy) v_u_21, (ref) v_u_17, (ref) v_u_65, (ref) v_u_67, (ref) v_u_66, (copy) v_u_38, (ref) v_u_78, (ref) v_u_79, (ref) v_u_80, (ref) v_u_70, (ref) v_u_81, (copy) v_u_445
		if not v_u_68 then
			v_u_68 = true
			v_u_69 = false
			if not v_u_84 then
				v_u_16.draw()
			end
			task.spawn(function()
				-- upvalues: (copy) p_u_532, (ref) p_u_7, (ref) v_u_21, (ref) v_u_68, (ref) v_u_17, (ref) v_u_65, (ref) v_u_67, (ref) v_u_66, (ref) v_u_38, (ref) v_u_69, (ref) v_u_78, (ref) v_u_79, (ref) v_u_80, (ref) v_u_16
				if p_u_532 then
					p_u_7.invalidate(v_u_21.GET)
				end
				local v533 = p_u_7.fetch(v_u_21.GET, nil, 15)
				v_u_68 = false
				if v_u_17 then
					if type(v533) == "table" then
						v_u_65 = v533
						v_u_67 = os.clock()
						v_u_66 = v_u_21.model(v533, v_u_38)
						v_u_69 = false
						if v_u_78 > 0 and (v_u_66.ok and (v_u_79 < v_u_66.bought or v_u_66.tier >= v_u_66.count)) then
							v_u_78 = 0
							v_u_80 = nil
						end
						task.defer(function()
							-- upvalues: (ref) p_u_7
							local function v534()
								-- upvalues: (ref) p_u_7
								p_u_7.changed:Fire("pass")
							end
							pcall(v534)
						end)
					else
						v_u_69 = v_u_65 == nil
					end
					v_u_16.draw()
				end
			end)
			task.spawn(function()
				-- upvalues: (ref) p_u_7, (ref) v_u_21, (ref) v_u_70, (ref) v_u_81, (ref) v_u_17, (ref) v_u_66, (ref) v_u_84, (ref) v_u_445
				local v535 = p_u_7.fetch
				local v536, v537 = pcall(v535, "store", nil, 120)
				if v536 and type(v537) == "table" then
					local v538 = v537.products
					if type(v538) == "table" then
						for _, v539 in v537.products do
							if type(v539) == "table" and v539.id == v_u_21.PRODUCT then
								v_u_70 = v539
							else
								if type(v539) ~= "table" then
									continue
								end
								local v540 = v539.id
								if type(v540) ~= "string" or v_u_21.SKIP_KEYS[v539.id] == nil then
									continue
								end
								v_u_81[v539.id] = v539
							end
						end
						if v_u_17 and (v_u_66.ok and v_u_84) then
							v_u_445()
						end
					end
				end
			end)
		end
	end
	function v_u_16.show() -- name: show
		-- upvalues: (ref) v_u_18, (ref) v_u_72, (ref) v_u_75, (copy) v_u_16
		v_u_18 = true
		v_u_72 = nil
		v_u_75 = nil
		v_u_16.load(false)
		v_u_16.draw()
	end
	function v_u_16.hide() -- name: hide
		-- upvalues: (ref) v_u_18, (ref) v_u_82, (ref) v_u_87
		v_u_18 = false
		local v541 = v_u_82
		v_u_82 = nil
		if v541 then
			local v542 = v541.close
			if type(v542) == "function" then
				local v543 = v541.close
				pcall(v543)
			end
		end
		if v_u_87 ~= nil then
			local v544 = v_u_87.close
			if type(v544) == "function" then
				local v545 = v_u_87.close
				pcall(v545)
			end
		end
		v_u_87 = nil
	end
	function v_u_16.refresh(p546, p547) -- name: refresh
		-- upvalues: (ref) v_u_17, (ref) v_u_64, (copy) v_u_21, (ref) v_u_73, (ref) v_u_74, (ref) v_u_72, (copy) v_u_16, (copy) p_u_7, (copy) v_u_223, (ref) v_u_75, (ref) v_u_76, (ref) v_u_80, (ref) v_u_78, (copy) v_u_434, (ref) v_u_66, (ref) v_u_77
		if v_u_17 then
			if p546 == "result" and type(p547) == "table" then
				local v548 = p547.op
				if v_u_64 ~= nil then
					local v549 = v_u_64.onResult
					pcall(v549, p547)
				end
				if v548 == v_u_21.OPS.claim then
					local v550
					if p547.ok == false then
						local v551 = v_u_21.claimRetry
						if type(v551) == "function" then
							v550 = v_u_21.claimRetry(v_u_21.errorOf(p547), v_u_73)
						else
							v550 = nil
						end
					else
						v550 = nil
					end
					if v550 == nil or v_u_74 == nil then
						v_u_72 = nil
						if p547.ok == false then
							local v552, v553, v554 = v_u_21.errorOf(p547)
							v_u_75 = v_u_21.errorText(v552, v553, v554)
							v_u_76 = os.clock() + 8
						else
							v_u_75 = nil
						end
						v_u_16.load(true)
					else
						v_u_73 = v_u_73 + 1
						local v_u_555 = table.clone(v_u_74)
						v_u_72 = os.clock() + 10
						v_u_16._delay(v550, function()
							-- upvalues: (ref) v_u_17, (ref) p_u_7, (copy) v_u_555
							if v_u_17 then
								p_u_7.op(v_u_555)
							end
						end)
						v_u_223()
					end
				end
				if v548 == v_u_21.OPS.missions then
					v_u_16.load(true)
					return
				end
				if v548 == "storeBuy" or v548 == "storeGrant" then
					if v_u_80 == nil then
						if v_u_66.ok and not v_u_66.paid then
							local v556 = v_u_77
							local v557 = os.clock() + 30
							v_u_77 = math.max(v556, v557)
						end
					elseif v548 == "storeBuy" and p547.ok == false then
						v_u_75 = v_u_21.errorText(nil, p547.msg, nil)
						v_u_76 = os.clock() + 8
						v_u_80 = nil
						v_u_78 = 0
						v_u_223()
						v_u_434()
					else
						v_u_16.load(true)
					end
					if v548 == "storeGrant" and v_u_80 == nil then
						v_u_16.load(true)
					end
				end
			end
		end
	end
	function v_u_16._dialogEnded(p558, p559) -- name: _dialogEnded
		-- upvalues: (ref) v_u_17, (copy) v_u_21, (ref) v_u_80, (ref) v_u_81, (ref) v_u_78, (copy) v_u_223, (copy) v_u_434
		if v_u_17 and v_u_21.skipDialogEnded(v_u_80, v_u_81, p558, p559) then
			v_u_80 = nil
			v_u_78 = 0
			v_u_223()
			v_u_434()
		end
	end
	local v_u_560 = nil
	local function v564()
		-- upvalues: (ref) v_u_560, (ref) v_u_3, (copy) v_u_15, (copy) v_u_16
		v_u_560 = v_u_3.PromptProductPurchaseFinished:Connect(function(p561, p562, p563)
			-- upvalues: (ref) v_u_15, (ref) v_u_16
			if p561 == v_u_15.UserId then
				v_u_16._dialogEnded(p562, p563)
			end
		end)
	end
	pcall(v564)
	local v_u_565 = 0
	function v_u_16.tick(p566) -- name: tick
		-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_565, (ref) v_u_72, (copy) v_u_21, (ref) v_u_75, (ref) v_u_76, (copy) v_u_223, (ref) v_u_66, (copy) v_u_475, (ref) v_u_67, (ref) v_u_83, (copy) v_u_16, (ref) v_u_77, (copy) v_u_445, (ref) v_u_78, (ref) v_u_80, (copy) v_u_434
		if v_u_17 and v_u_18 then
			v_u_565 = v_u_565 + (p566 or 1)
			if v_u_565 >= 0.5 then
				v_u_565 = 0
				local v567 = os.clock()
				if v_u_72 and v_u_72 < v567 then
					v_u_72 = nil
					v_u_75 = v_u_21.errorText("FAILED", nil)
					v_u_76 = os.clock() + 8
					v_u_223()
				end
				if v_u_75 and v_u_76 < v567 then
					v_u_75 = nil
					v_u_223()
				end
				if v_u_66.ok then
					v_u_475()
				end
				if v_u_66.ok and (v_u_21.phaseExpired(v_u_66, v567 - v_u_67) and v567 - v_u_83 >= 5) then
					v_u_83 = v567
					v_u_16.load(true)
				end
				if v567 < v_u_77 and (v_u_66.ok and (not v_u_66.paid and v567 - v_u_83 >= 5)) then
					v_u_83 = v567
					v_u_16.load(true)
				elseif v_u_66.ok and (v_u_66.paid and v_u_77 > 0) then
					v_u_77 = 0
					v_u_445()
				elseif v_u_77 > 0 and v_u_77 <= v567 then
					v_u_77 = 0
					v_u_445()
				end
				if v_u_78 > 0 then
					if v_u_78 <= v567 then
						v_u_78 = 0
						v_u_80 = nil
						v_u_434()
						return
					end
					if v_u_66.ok and v567 - v_u_83 >= 5 then
						v_u_83 = v567
						v_u_16.load(true)
					end
				end
			end
		else
			return
		end
	end
	function v_u_16.destroy() -- name: destroy
		-- upvalues: (ref) v_u_17, (ref) v_u_184, (ref) v_u_560, (ref) v_u_82, (ref) v_u_87, (ref) v_u_64, (ref) v_u_201, (copy) v_u_225
		v_u_17 = false
		if v_u_184 ~= nil then
			v_u_184.destroy()
		end
		if v_u_560 ~= nil then
			local function v568()
				-- upvalues: (ref) v_u_560
				v_u_560:Disconnect()
			end
			pcall(v568)
			v_u_560 = nil
		end
		local v569 = v_u_82
		v_u_82 = nil
		if v569 then
			local v570 = v569.close
			if type(v570) == "function" then
				local v571 = v569.close
				pcall(v571)
			end
		end
		if v_u_87 ~= nil then
			local v572 = v_u_87.close
			if type(v572) == "function" then
				local v573 = v_u_87.close
				pcall(v573)
			end
		end
		v_u_87 = nil
		if v_u_64 ~= nil then
			local v574 = v_u_64.destroy
			pcall(v574)
			v_u_64 = nil
		end
		if v_u_201 ~= nil then
			local v575 = v_u_201.destroy
			pcall(v575)
		end
		v_u_225()
	end
	function v_u_16._delay(p576, p577)
		task.delay(p576, p577)
	end
	function v_u_16._model()
		-- upvalues: (ref) v_u_66
		return v_u_66
	end
	function v_u_16._layout()
		-- upvalues: (ref) v_u_96
		return v_u_96
	end
	v_u_16._subApi = v166
	function v_u_16._skipModal()
		-- upvalues: (ref) v_u_82
		return v_u_82
	end
	function v_u_16._xpModal()
		-- upvalues: (ref) v_u_87
		return v_u_87
	end
	function v_u_16._detail(p578, p579)
		-- upvalues: (copy) v_u_374
		v_u_374(p578, p579)
	end
	function v_u_16._closeDetail()
		-- upvalues: (ref) v_u_89
		local v580 = v_u_89
		if v580 then
			local v581 = v580.close
			if type(v581) == "function" then
				local v582 = v580.close
				pcall(v582)
			end
		end
	end
	function v_u_16._missions()
		-- upvalues: (ref) v_u_201
		return v_u_201
	end
	function v_u_16._feed(p583, p584, p585)
		-- upvalues: (ref) v_u_65, (ref) v_u_67, (ref) v_u_66, (copy) v_u_21, (copy) v_u_38, (ref) v_u_70, (ref) v_u_81, (ref) v_u_69, (ref) v_u_68, (copy) v_u_16
		v_u_65 = p583
		v_u_67 = os.clock()
		v_u_66 = v_u_21.model(p583, v_u_38)
		v_u_70 = p584
		v_u_81 = type(p585) ~= "table" and {} or p585
		v_u_69 = false
		v_u_68 = false
		v_u_16.draw()
	end
	return v_u_16
end
return v5