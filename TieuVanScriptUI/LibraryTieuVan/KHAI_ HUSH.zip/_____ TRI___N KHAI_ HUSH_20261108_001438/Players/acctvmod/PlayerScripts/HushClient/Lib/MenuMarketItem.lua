-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketItem

local v_u_542 = {
	["REFRESH_GAP"] = 3,
	["MORE_PAGE"] = 25,
	["new"] = function(p_u_1, p2) -- name: new
		-- upvalues: (copy) v_u_542
		local v_u_3 = p_u_1.ui
		local v_u_4 = p_u_1.theme
		local v_u_5 = p_u_1.C
		local v_u_6 = p_u_1.Data
		local v_u_7 = p_u_1.data
		local v_u_8 = p_u_1.h
		local v_u_9 = p_u_1.compact
		local _ = p_u_1.phone
		local v_u_10 = p_u_1.kit
		local v_u_11 = {}
		local v_u_12 = true
		local v_u_13 = false
		local v_u_14 = nil
		local v_u_15 = nil
		local v_u_16 = nil
		local v_u_17 = false
		local v_u_18 = nil
		local v_u_19 = nil
		local v_u_20 = {}
		local v_u_21 = 0
		local v_u_22 = false
		local v_u_23 = "loading"
		local v_u_24 = 0
		local v_u_25 = 0
		local v_u_26 = {}
		local v_u_27 = {}
		local v_u_28 = {}
		local v_u_29 = (-1 / 0)
		local v_u_30 = nil
		local v_u_31 = nil
		local function v32()
			-- upvalues: (ref) v_u_31, (copy) p_u_1
			v_u_31 = p_u_1.mc.cctx.shared.Items
		end
		pcall(v32)
		local v_u_33 = nil
		local function v34()
			-- upvalues: (ref) v_u_33, (copy) p_u_1
			v_u_33 = p_u_1.mc.cctx.lib.MenuMarketCrateKit
		end
		pcall(v34)
		local v_u_35 = false
		local v_u_36 = nil
		local v_u_37 = nil
		local v_u_38 = nil
		local v_u_39 = v_u_4.touch(34) + 32
		if v_u_9 then
			v_u_39 = math.max(v_u_39, 78)
		end
		local v_u_40 = v_u_3.new("Frame", {
			["Name"] = "ItemPage",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["Position"] = UDim2.fromOffset(0, 0),
			["Size"] = UDim2.fromScale(1, 1)
		}, p2)
		local v41 = v_u_4.touch(36)
		local v42 = v_u_3.new("Frame", {
			["Name"] = "Bar",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v41)
		}, v_u_40)
		local v43 = v_u_9 and 104 or 120
		local v44 = v_u_9 and 96 or 120
		local v_u_45, _ = v_u_8.button(v42, "Back", "secondary", function()
			-- upvalues: (copy) v_u_11
			v_u_11.close()
		end, {
			["icon"] = "chevronLeft",
			["name"] = "Back",
			["height"] = 36,
			["width"] = nil,
			["width"] = v43
		})
		local v46
		if v_u_9 then
			v46 = v43 + 8 + 44 + 8
		else
			v46 = v43 + 12
		end
		local v_u_47 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = nil,
			["textSize"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v42,
			["style"] = v_u_9 and "h3" or "h2",
			["textSize"] = v_u_9 and 20 or 26,
			["position"] = UDim2.fromOffset(v46, v_u_9 and 3 or 0),
			["size"] = UDim2.new(1, -(v46 + 104 + 8 + v44 + 8), 0, v_u_9 and 28 or v41)
		})
		local v_u_48 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Age",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v42,
			["color"] = v_u_5.muted,
			["position"] = UDim2.new(1, -(v44 + 112), 0, 0),
			["size"] = UDim2.fromOffset(v44, v41)
		})
		local _, _ = v_u_8.button(v42, "Refresh", "secondary", function()
			-- upvalues: (copy) v_u_11
			v_u_11.reload(true)
		end, {
			["name"] = "Refresh",
			["height"] = 36,
			["width"] = 104,
			["anchor"] = nil,
			["position"] = nil,
			["maxTextWidth"] = 90,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.new(1, 0, 0, 0)
		})
		local v49 = v41 + 8
		local v50 = not v_u_9
		local v_u_51, v_u_52
		if v50 then
			v_u_51 = v_u_3.list({
				["parent"] = nil,
				["name"] = "Left",
				["position"] = nil,
				["size"] = nil,
				["gap"] = 10,
				["padding"] = nil,
				["parent"] = v_u_40,
				["position"] = UDim2.fromOffset(0, v49),
				["size"] = UDim2.new(0.36, -8, 1, -v49),
				["padding"] = {
					0,
					8,
					0,
					8
				}
			})
			v_u_52 = v_u_3.new("Frame", {
				["Name"] = "Right",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.new(0.36, 8, 0, v49),
				["Size"] = UDim2.new(0.64, -8, 1, -v49)
			}, v_u_40)
		else
			v_u_51 = v_u_3.list({
				["parent"] = nil,
				["name"] = "Scroll",
				["position"] = nil,
				["size"] = nil,
				["gap"] = 8,
				["padding"] = nil,
				["parent"] = v_u_40,
				["position"] = UDim2.fromOffset(0, v49),
				["size"] = UDim2.new(1, 0, 1, -v49),
				["padding"] = {
					0,
					8,
					0,
					8
				}
			})
			v_u_52 = v_u_51
		end
		local v_u_53 = v_u_3.new("Frame", {
			["Name"] = "FilterRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 4,
			["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(34))
		})
		local v_u_54
		if v50 then
			v_u_53.Parent = v_u_52
			v_u_53.LayoutOrder = 0
			v_u_54 = v_u_3.list({
				["parent"] = nil,
				["name"] = "Listings",
				["position"] = nil,
				["size"] = nil,
				["gap"] = 6,
				["padding"] = nil,
				["parent"] = v_u_52,
				["position"] = UDim2.fromOffset(0, v_u_4.touch(34) + 8),
				["size"] = UDim2.new(1, 0, 1, -(v_u_4.touch(34) + 8)),
				["padding"] = {
					0,
					8,
					0,
					8
				}
			})
		else
			v_u_54 = v_u_3.new("Frame", {
				["Name"] = "ListWrap",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 5,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v_u_51)
			v_u_3.layout(v_u_54, "v", 8)
			v_u_53.Parent = v_u_54
		end
		local v_u_55 = {}
		local v56 = v_u_9 and 44 or 104
		local v_u_57, v_u_58, v_u_59
		if v_u_9 then
			local v60 = v_u_3.new
			local v61 = {
				["Name"] = "IconHost",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil
			}
			local v62 = UDim2.fromOffset
			local v63 = v43 + 8
			local v64 = (v41 - 44) / 2
			v61.Position = v62(v63, (math.floor(v64)))
			v61.Size = UDim2.fromOffset(44, 44)
			v_u_57 = v60("Frame", v61, v42)
			v_u_58 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Meta",
				["text"] = "",
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v42,
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(v46, 32),
				["size"] = UDim2.new(1, -(v46 + 104 + 8 + v44 + 8), 0, 18)
			})
			v_u_59 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = "",
				["style"] = "small",
				["visible"] = false,
				["parent"] = v42
			})
		else
			local v65 = v_u_3.new("Frame", {
				["Name"] = "Head",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 0,
				["Size"] = UDim2.new(1, 0, 0, 112)
			}, v_u_51)
			v_u_57 = v_u_3.new("Frame", {
				["Name"] = "IconHost",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.fromOffset(v56, v56)
			}, v65)
			local v66 = v56 + 12
			v_u_58 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Meta",
				["text"] = "",
				["style"] = "caps",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v65,
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(v66, 0),
				["size"] = UDim2.new(1, -v66, 0, 18)
			})
			v_u_59 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["valign"] = "top",
				["parent"] = v65,
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(v66, 22),
				["size"] = UDim2.new(1, -v66, 1, -22)
			})
		end
		local v67 = v_u_9 and 62 or 66
		local v68 = v_u_3.new
		local v69 = "Frame"
		local v70 = {
			["Name"] = "Numbers",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2
		}
		local v71 = UDim2.new
		local v72 = 1
		local v73 = 0
		local v74 = 0
		local v75
		if v_u_9 then
			v75 = v67
		else
			v75 = v67 * 2 + 6
		end
		v70.Size = v71(v72, v73, v74, v75)
		local v_u_76 = v68(v69, v70, v_u_51)
		local v77 = v_u_3.new
		local v78 = "UIGridLayout"
		local v79 = {}
		local v80
		if v_u_9 then
			v80 = UDim2.new(0.25, -5, 0, v67)
		else
			v80 = UDim2.new(0.5, -4, 0, v67)
		end
		v79.CellSize = v80
		v79.CellPadding = UDim2.fromOffset(6, 6)
		v79.SortOrder = Enum.SortOrder.LayoutOrder
		v77(v78, v79, v_u_76)
		local v_u_81 = v_u_33
		local v_u_82 = v_u_31
		for v83, v84 in {
			"min",
			"avg7",
			"last",
			"count"
		} do
			local v85 = v_u_3.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Name"] = "Num_" .. v84,
				["BackgroundColor3"] = v_u_5.raised,
				["LayoutOrder"] = v83
			}, v_u_76)
			v_u_3.stroke(v85, v_u_5.line)
			local v86 = v_u_3.label({
				["parent"] = nil,
				["name"] = "Label",
				["text"] = "",
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v85,
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(8, 3),
				["size"] = UDim2.new(1, -16, 0, 16)
			})
			v_u_55[v84] = {
				["value"] = v_u_3.label({
					["parent"] = nil,
					["name"] = "Value",
					["text"] = "",
					["style"] = "monoL",
					["textSize"] = nil,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v85,
					["textSize"] = v_u_9 and 16 or 19,
					["color"] = v_u_5.text,
					["position"] = UDim2.fromOffset(8, 19),
					["size"] = UDim2.new(1, -16, 0, 24)
				}),
				["sub"] = v_u_3.label({
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v85,
					["color"] = v_u_5.muted,
					["position"] = UDim2.fromOffset(8, 44),
					["size"] = UDim2.new(1, -16, 0, 16)
				}),
				["label"] = v86
			}
		end
		local v_u_87 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Trader",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v_u_51,
			["color"] = v_u_5.info
		})
		v_u_87.LayoutOrder = 3
		local v_u_88 = v_u_3.new("Frame", {
			["Name"] = "History",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 900,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_51)
		v_u_3.layout(v_u_88, "v", 6)
		local v89 = nil
		local v_u_90
		if p_u_1.rs == nil then
			v_u_90 = v89
		else
			local v91 = p_u_1.rs.newPinned
			if type(v91) == "function" then
				local v92 = p_u_1.rs.newPinned
				local v93
				v93, v_u_90 = pcall(v92, v_u_51, 1)
				if not v93 then
					v_u_90 = v89
				end
			else
				v_u_90 = v89
			end
		end
		local function v99(p94, p95, p96, p97) -- name: chip
			-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_53
			local v98 = v_u_3.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["Name"] = p97,
				["BackgroundColor3"] = v_u_5.raised,
				["Position"] = UDim2.fromOffset(p95, 0),
				["Size"] = UDim2.fromOffset(p96, v_u_4.touch(34))
			}, v_u_53)
			v98.SelectionImageObject = v_u_3.selectionImage()
			v_u_3.stroke(v98, v_u_5.line)
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["fit"] = true,
				["parent"] = v98,
				["text"] = p94,
				["color"] = v_u_5.text2,
				["size"] = UDim2.fromScale(1, 1)
			})
			return v98
		end
		local v_u_100 = v99("Any condition", 0, v_u_9 and 120 or 140, "Any")
		local v_u_101 = v99("Good, 70% and up", v_u_9 and 128 or 148, v_u_9 and 150 or 170, "Good")
		local v_u_102 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Count",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v_u_53,
			["color"] = v_u_5.text2,
			["position"] = UDim2.fromOffset(v_u_9 and 290 or 330, 0),
			["size"] = UDim2.new(1, -(v_u_9 and 290 or 330), 1, 0)
		})
		local function v_u_111() -- name: paintChips
			-- upvalues: (ref) v_u_100, (ref) v_u_17, (ref) v_u_101, (copy) v_u_5
			for _, v103 in {
				{ v_u_100, not v_u_17 },
				{ v_u_101, v_u_17 }
			} do
				local v104 = v103[1]
				local v105 = v103[2]
				local v106
				if v105 then
					v106 = v_u_5.accentDeep
				else
					v106 = v_u_5.raised
				end
				v104.BackgroundColor3 = v106
				v104.BackgroundTransparency = v105 and 0.05 or 0.3
				local v107 = v104:FindFirstChildOfClass("UIStroke")
				if v107 then
					local v108
					if v105 then
						v108 = v_u_5.accent
					else
						v108 = v_u_5.line
					end
					v107.Color = v108
				end
				local v109 = v104:FindFirstChild("Text")
				if not v109 then
					continue
				end
				local v110
				if v105 then
					v110 = v_u_5.text
				else
					v110 = v_u_5.text2
				end
				v109.TextColor3 = v110
			end
		end
		v_u_100.Activated:Connect(function()
			-- upvalues: (ref) v_u_17, (copy) v_u_3, (copy) v_u_4, (copy) v_u_11
			if v_u_17 then
				v_u_17 = false
				v_u_3.sound(v_u_4.sounds.tab)
				v_u_11.reload(false)
			end
		end)
		v_u_101.Activated:Connect(function()
			-- upvalues: (ref) v_u_17, (copy) v_u_3, (copy) v_u_4, (copy) v_u_11
			if not v_u_17 then
				v_u_17 = true
				v_u_3.sound(v_u_4.sounds.tab)
				v_u_11.reload(false)
			end
		end)
		local function v_u_114() -- name: clearRows
			-- upvalues: (copy) v_u_28, (ref) v_u_54
			for _, v_u_112 in v_u_28 do
				pcall(function()
					-- upvalues: (copy) v_u_112
					v_u_112.frame:Destroy()
				end)
			end
			table.clear(v_u_28)
			for _, v113 in v_u_54:GetChildren() do
				if not v113:GetAttribute("ItemRow") and (v113.Name ~= "Skeleton" and (v113.Name ~= "Message" and v113.Name ~= "MoreBtn")) then
					continue
				end
				v113:Destroy()
			end
		end
		local function v_u_122(p115) -- name: buyStateOf
			-- upvalues: (copy) v_u_7, (copy) p_u_1, (ref) v_u_35, (ref) v_u_81, (copy) v_u_6, (ref) v_u_14
			local v116 = v_u_7:remaining(p_u_1.state or {}, "buyIn")
			if v_u_35 and v_u_81 == nil then
				return {
					["show"] = true,
					["enabled"] = false,
					["reason"] = nil,
					["short"] = "Unavailable",
					["why"] = "STORE",
					["reason"] = v_u_6.text(p_u_1.rules, "STORE")
				}
			end
			local v117 = v_u_6.buyButton
			local v118 = p_u_1.state
			local v119 = v_u_7:cash()
			local v120 = p_u_1.rules
			local v121
			if v_u_35 then
				v121 = v_u_14
			else
				v121 = nil
			end
			return v117(v118, p115, v119, v116, v120, v121)
		end
		local function v_u_127() -- name: paintCrateBlock
			-- upvalues: (ref) v_u_35, (copy) v_u_6, (copy) p_u_1, (ref) v_u_36, (ref) v_u_38, (ref) v_u_14, (ref) v_u_37, (ref) v_u_81, (ref) v_u_51, (copy) v_u_9
			local v123
			if v_u_35 then
				local v124 = v_u_6.crateBanner(p_u_1.state)
				if v124 then
					v123 = v124.text
				else
					v123 = nil
				end
			else
				v123 = nil
			end
			if v_u_36 == nil or (not v_u_35 or (v_u_38 ~= v_u_14 or (v_u_37 ~= v123 or v_u_36.Parent == nil))) then
				if v_u_36 ~= nil then
					v_u_36:Destroy()
					v_u_36 = nil
				end
				v_u_38 = nil
				if v_u_35 and (v_u_81 ~= nil and v_u_14 ~= nil) then
					v_u_37 = v123
					v_u_38 = v_u_14
					local v125 = {
						["order"] = 3,
						["tight"] = nil,
						["strip"] = nil,
						["tight"] = v_u_9,
						["strip"] = v123
					}
					local v126 = v_u_81.block(p_u_1, v_u_51, v_u_14, v125)
					if v126 then
						v_u_36 = v126.frame
					end
				end
			else
				return
			end
		end
		local v_u_128 = nil
		local v_u_129 = nil
		local v_u_130 = nil
		local v_u_131 = nil
		local v_u_132 = nil
		local v_u_133 = nil
		local function v134()
			-- upvalues: (ref) v_u_132, (copy) p_u_1
			v_u_132 = p_u_1.mc.cctx.lib.MenuMarketBook
		end
		pcall(v134)
		local function v135()
			-- upvalues: (ref) v_u_133, (copy) p_u_1
			v_u_133 = p_u_1.mc.cctx.lib.MenuMarketOrder
		end
		pcall(v135)
		local v_u_136
		if v_u_132 == nil then
			v_u_136 = false
		else
			local v137, v138 = pcall(function()
				-- upvalues: (copy) p_u_1
				return p_u_1.mc.cctx.config.flag("BuyOrders")
			end)
			v_u_136 = not v137 or v138 ~= false
		end
		local v_u_139 = "listings"
		local v_u_140 = {}
		local v_u_141 = nil
		local function v_u_142() end
		local function v_u_143(_) end
		local v_u_144
		if v_u_136 then
			local v145 = v_u_4.touch(34) + 8
			local v146 = v_u_3.new
			local v147 = "Frame"
			local v148 = {
				["Name"] = "Segments",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 4,
				["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(34))
			}
			local v149
			if v50 then
				v149 = v_u_52
			else
				v149 = v_u_51
			end
			local v150 = v146(v147, v148, v149)
			v_u_3.layout(v150, "h", 6)
			local v151 = v_u_133
			local v_u_152 = v_u_132
			for v153, v_u_154 in {
				{
					["id"] = "listings",
					["text"] = "Listings"
				},
				{
					["id"] = "book",
					["text"] = "Book"
				},
				{
					["id"] = "order",
					["text"] = "Order"
				}
			} do
				local v155 = v_u_3.new
				local v156 = "TextButton"
				local v157 = {
					["Name"] = nil,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Seg_" .. v_u_154.id,
					["BackgroundColor3"] = v_u_5.raised
				}
				local v158
				if v_u_9 then
					v158 = UDim2.new(0.3333333333333333, -4, 1, 0)
				else
					v158 = UDim2.fromOffset(120, v_u_4.touch(34))
				end
				v157.Size = v158
				v157.LayoutOrder = v153
				local v159 = v155(v156, v157, v150)
				v159.SelectionImageObject = v_u_3.selectionImage()
				v_u_3.stroke(v159, v_u_5.line)
				v_u_3.label({
					["parent"] = nil,
					["name"] = "Text",
					["text"] = nil,
					["style"] = "caps",
					["color"] = nil,
					["align"] = "center",
					["size"] = nil,
					["fit"] = true,
					["parent"] = v159,
					["text"] = v_u_154.text,
					["color"] = v_u_5.text2,
					["size"] = UDim2.fromScale(1, 1)
				})
				v_u_140[v_u_154.id] = v159
				v159.Activated:Connect(function()
					-- upvalues: (copy) v_u_3, (copy) v_u_4, (ref) v_u_142, (copy) v_u_154
					v_u_3.sound(v_u_4.sounds.tab)
					v_u_142(v_u_154.id)
				end)
			end
			local v_u_160, v_u_161
			if v50 then
				v_u_160 = v_u_3.new("Frame", {
					["Name"] = "BookHost",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["Position"] = UDim2.fromOffset(0, v145),
					["Size"] = UDim2.new(1, 0, 1, -v145)
				}, v_u_52)
				v_u_161 = v_u_3.new("Frame", {
					["Name"] = "OrderHost",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["Position"] = UDim2.fromOffset(0, v145),
					["Size"] = UDim2.new(1, 0, 1, -v145)
				}, v_u_52)
				v_u_53.Position = UDim2.fromOffset(0, v145)
				v_u_54.Position = UDim2.fromOffset(0, v145 + v_u_4.touch(34) + 8)
				v_u_54.Size = UDim2.new(1, 0, 1, -(v145 + v_u_4.touch(34) + 8))
			else
				v_u_160 = v_u_3.new("Frame", {
					["Name"] = "BookHost",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 6,
					["Visible"] = false,
					["Size"] = UDim2.new(1, 0, 0, 380)
				}, v_u_51)
				v_u_161 = v_u_3.new("Frame", {
					["Name"] = "OrderHost",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 7,
					["Visible"] = false,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_51)
			end
			local function v_u_170() -- name: paintSeg
				-- upvalues: (copy) v_u_140, (ref) v_u_139, (copy) v_u_5, (copy) p_u_1
				for v162, v163 in v_u_140 do
					local v164 = v162 == v_u_139
					local v165
					if v164 then
						v165 = v_u_5.accentDeep
					else
						v165 = v_u_5.raised
					end
					v163.BackgroundColor3 = v165
					v163.BackgroundTransparency = v164 and 0.05 or 0.3
					local v166 = v163:FindFirstChildOfClass("UIStroke")
					if v166 then
						local v167
						if v164 then
							v167 = v_u_5.accent
						else
							v167 = v_u_5.line
						end
						v166.Color = v167
					end
					local v168 = v163:FindFirstChild("Text")
					if v168 then
						local v169
						if v164 then
							v169 = v_u_5.text
						else
							v169 = v_u_5.text2
						end
						v168.TextColor3 = v169
					end
					v163:SetAttribute("On", v164)
				end
				p_u_1.page:SetAttribute("MarketSeg", v_u_139)
			end
			v_u_144 = v_u_152.new(p_u_1, v_u_160, {
				["itemId"] = function() -- name: itemId
					-- upvalues: (ref) v_u_14
					return v_u_14
				end,
				["onAsk"] = function(p171) -- name: onAsk
					-- upvalues: (ref) v_u_152, (ref) v_u_20, (ref) v_u_128, (copy) v_u_3, (copy) v_u_6, (ref) v_u_142
					local v172, v173 = v_u_152.tapAsk(v_u_20, p171)
					if v172 then
						v_u_128(v172)
						return
					elseif v173 == "OWN" then
						local v174 = v_u_3.toast
						local v175 = v_u_6.CODES.OWN
						pcall(v174, v175, "warn")
					else
						v_u_142("listings")
					end
				end,
				["onBid"] = function(p176) -- name: onBid
					-- upvalues: (ref) v_u_141
					if v_u_141 then
						v_u_141.sellNow(p176)
					end
				end,
				["onPlace"] = function() -- name: onPlace
					-- upvalues: (ref) v_u_142
					v_u_142("order")
				end,
				["canPlace"] = function() -- name: canPlace
					-- upvalues: (ref) v_u_141, (copy) v_u_6
					if v_u_141 then
						return v_u_141.canPlace()
					else
						return false, v_u_6.CODES.DISABLED
					end
				end,
				["onModel"] = function() -- name: onModel
					-- upvalues: (ref) v_u_141
					if v_u_141 then
						v_u_141.refresh()
					end
				end
			})
			if v151 ~= nil then
				v_u_141 = v151.new(p_u_1, v_u_161, {
					["itemId"] = function() -- name: itemId
						-- upvalues: (ref) v_u_14
						return v_u_14
					end,
					["entry"] = function() -- name: entry
						-- upvalues: (ref) v_u_15
						return v_u_15
					end,
					["def"] = function() -- name: def
						-- upvalues: (ref) v_u_16
						return v_u_16
					end,
					["listings"] = function() -- name: listings
						-- upvalues: (ref) v_u_20
						return v_u_20
					end,
					["bookModel"] = function() -- name: bookModel
						-- upvalues: (ref) v_u_144
						if v_u_144 then
							return v_u_144.model()
						else
							return nil
						end
					end,
					["scroll"] = v50,
					["onPlaced"] = function() -- name: onPlaced
						-- upvalues: (ref) v_u_144, (ref) v_u_142
						if v_u_144 then
							v_u_144.reload(true, true)
						end
						v_u_142("book")
					end,
					["onBuyNow"] = function(p177) -- name: onBuyNow
						-- upvalues: (ref) v_u_142, (ref) v_u_143
						v_u_142("listings")
						v_u_143(p177)
					end,
					["onSold"] = function() -- name: onSold
						-- upvalues: (ref) v_u_144
						if v_u_144 then
							v_u_144.reload(true, true)
						end
					end
				})
			end
			local function v183(p178, p179)
				-- upvalues: (ref) v_u_139, (copy) v_u_53, (ref) v_u_54, (copy) v_u_9, (ref) v_u_76, (ref) v_u_87, (ref) v_u_88, (ref) v_u_160, (ref) v_u_161, (ref) v_u_144, (ref) v_u_14, (ref) v_u_141, (copy) v_u_170
				if p178 ~= v_u_139 or p179 == true then
					v_u_139 = p178
					local v180 = p178 == "listings"
					v_u_53.Visible = v180
					v_u_54.Visible = v180
					if v_u_9 then
						v_u_76.Visible = v180
						local v181 = v_u_87
						local v182
						if v180 then
							v182 = v_u_87.Text ~= ""
						else
							v182 = v180
						end
						v181.Visible = v182
						v_u_88.Visible = v180
					end
					if v_u_160 then
						v_u_160.Visible = p178 == "book"
					end
					if v_u_161 then
						v_u_161.Visible = p178 == "order"
					end
					if p178 == "book" then
						v_u_144.show(v_u_14)
					elseif p178 == "order" then
						if v_u_144.isShown() then
							v_u_144.hide()
						end
						v_u_144.prefetch(v_u_14)
					else
						v_u_144.hide()
					end
					if v_u_141 then
						if p178 == "order" then
							v_u_141.show()
						else
							v_u_141.hide()
						end
					end
					v_u_170()
				end
			end
			v_u_170()
			v_u_142 = v183
		else
			v_u_144 = nil
		end
		local v_u_184 = nil
		local function v185()
			-- upvalues: (ref) v_u_184, (copy) p_u_1
			v_u_184 = p_u_1.mc.cctx.lib.MenuMarketBest
		end
		pcall(v185)
		local v_u_186 = nil
		local v_u_187 = v_u_3.new("Frame", {
			["Name"] = "BestBar",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 100,
			["Visible"] = false,
			["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(44) + 6)
		}, v_u_54)
		v_u_187:SetAttribute("BestBar", true)
		local v_u_188 = nil
		local function v_u_203(p189) -- name: openBest
			-- upvalues: (ref) v_u_184, (ref) v_u_30, (ref) v_u_186, (copy) p_u_1, (ref) v_u_14, (ref) v_u_15, (ref) v_u_20, (ref) v_u_17, (ref) v_u_13, (ref) v_u_130, (ref) v_u_131, (ref) v_u_19, (copy) v_u_7, (ref) v_u_18, (copy) v_u_3, (ref) v_u_188, (copy) v_u_187, (ref) v_u_23, (copy) v_u_11
			if v_u_184 ~= nil and not (v_u_30 or v_u_186 and v_u_186.isOpen()) then
				if v_u_186 == nil then
					local v197 = {
						["itemId"] = function() -- name: itemId
							-- upvalues: (ref) v_u_14
							return v_u_14
						end,
						["entry"] = function() -- name: entry
							-- upvalues: (ref) v_u_15
							return v_u_15
						end,
						["rows"] = function() -- name: rows
							-- upvalues: (ref) v_u_20
							return v_u_20
						end,
						["good"] = function() -- name: good
							-- upvalues: (ref) v_u_17
							return v_u_17
						end,
						["isOpen"] = function() -- name: isOpen
							-- upvalues: (ref) v_u_13
							return v_u_13
						end,
						["repaint"] = function(p190) -- name: repaint
							-- upvalues: (ref) v_u_130
							v_u_130(p190)
						end,
						["afterBuy"] = function(p191) -- name: afterBuy
							-- upvalues: (ref) v_u_131, (ref) v_u_14
							v_u_131(p191, v_u_14)
						end,
						["age"] = function() -- name: age
							-- upvalues: (ref) v_u_19, (ref) v_u_7, (ref) v_u_18
							if v_u_19 then
								if v_u_19 then
									local v192 = v_u_7:clock() - v_u_19.at
									return math.max(0, v192)
								else
									if v_u_18 then
										local v193 = v_u_18._at
										if type(v193) == "number" then
											local v194 = v_u_7:clock() - v_u_18._at
											return math.max(0, v194)
										end
									end
									return 0
								end
							else
								if v_u_18 then
									local v195 = v_u_18._at
									if type(v195) == "number" then
										local v196 = v_u_18.age
										return (type(v196) ~= "number" and 0 or v_u_18.age) + v_u_7:clock() - v_u_18._at
									end
								end
								return nil
							end
						end,
						["focusBack"] = function() -- name: focusBack
							-- upvalues: (ref) v_u_13, (ref) v_u_3, (ref) v_u_188, (ref) v_u_187
							if v_u_13 and (v_u_3.device() == "Gamepad" and (v_u_188 and (v_u_188.Parent and v_u_187.Visible))) then
								game:GetService("GuiService").SelectedObject = v_u_188
							end
						end
					}
					v_u_186 = v_u_184.new(p_u_1, v197)
				end
				local v198 = v_u_186.open
				if type(p189) ~= "number" then
					p189 = nil
				end
				v198(p189)
				if v_u_186.isOpen() and v_u_23 == "ok" then
					local v199
					if v_u_19 then
						local v200 = v_u_7:clock() - v_u_19.at
						v199 = math.max(0, v200)
					elseif v_u_18 then
						local v201 = v_u_18._at
						if type(v201) == "number" then
							local v202 = v_u_7:clock() - v_u_18._at
							v199 = math.max(0, v202)
						else
							v199 = 0
						end
					else
						v199 = 0
					end
					if v199 >= 1.5 then
						v_u_11.reload(false, true)
					end
				end
			end
		end
		local v204 = v_u_9 and 228 or 280
		local v207 = {
			["name"] = "BuyBest",
			["height"] = 44,
			["width"] = nil,
			["onDisabledClick"] = nil,
			["width"] = v204,
			["onDisabledClick"] = function() -- name: onDisabledClick
				-- upvalues: (ref) v_u_35, (copy) v_u_6, (ref) v_u_20, (copy) v_u_122, (ref) v_u_81, (copy) p_u_1
				local v205 = v_u_35 and v_u_6.cheapestRow(v_u_20)
				if v205 then
					local v206 = v_u_122(v205)
					if v206.enabled == false and v_u_81 ~= nil then
						v_u_81.explain(p_u_1, v206.reason)
					end
				end
			end
		}
		local v208, v209 = v_u_8.button(v_u_187, "Buy cheapest with a limit", "secondary", v_u_203, v207)
		v_u_188 = v208
		local v_u_210 = v209
		local v_u_211 = v_u_3.label({
			["parent"] = nil,
			["name"] = "Reason",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["fit"] = true,
			["track"] = false,
			["parent"] = v_u_187,
			["color"] = v_u_5.accent,
			["position"] = UDim2.fromOffset(v204 + 8, 0),
			["size"] = UDim2.new(1, -(v204 + 8), 0, v_u_4.touch(44))
		})
		local function v_u_218() -- name: paintBest
			-- upvalues: (copy) v_u_6, (ref) v_u_20, (ref) v_u_23, (ref) v_u_184, (copy) p_u_1, (copy) v_u_187, (copy) v_u_122, (ref) v_u_210, (ref) v_u_211
			local v212 = v_u_6.cheapestRow(v_u_20)
			local v213
			if v_u_23 == "ok" and (v212 ~= nil and (v_u_184 ~= nil and (v_u_6.buy ~= nil and v_u_6.comfort ~= nil))) then
				local function v214()
					-- upvalues: (ref) p_u_1
					return p_u_1.mc.cctx.config.flag("BlackmarketBest")
				end
				local v215, v216 = pcall(v214)
				v213 = not v215 or v216 ~= false
			else
				v213 = false
			end
			v_u_187.Visible = v213
			if v213 then
				local v217 = v_u_122(v212)
				v_u_210.setEnabled(v217.enabled)
				v_u_211.Text = v217.short or (v217.reason or "")
				v_u_187:SetAttribute("Buy", v217.why)
			end
		end
		local function v_u_232(p219) -- name: paintRow
			-- upvalues: (copy) v_u_122, (copy) v_u_6, (ref) v_u_19, (copy) v_u_7, (ref) v_u_18
			local v220 = p219.l
			local v221 = v_u_122(v220)
			if p219.buy then
				p219.buy.btn.Visible = v221.show
				p219.buy.api.setEnabled(v221.enabled)
				p219.btnState = v221.why
			end
			p219.reason.Text = v221.short or (v221.reason or "")
			p219.reason.Visible = v221.reason ~= nil
			local v222 = p219.ends
			local v223 = "ends in %s"
			local v224 = v_u_6.duration
			local v225 = 0
			local v226 = v220.left or 0
			local v227
			if v_u_19 then
				local v228 = v_u_7:clock() - v_u_19.at
				v227 = math.max(0, v228)
			elseif v_u_18 then
				local v229 = v_u_18._at
				if type(v229) == "number" then
					local v230 = v_u_7:clock() - v_u_18._at
					v227 = math.max(0, v230)
				else
					v227 = 0
				end
			else
				v227 = 0
			end
			local v231 = v226 - v227
			v222.Text = v223:format(v224((math.max(v225, v231))))
			p219.frame:SetAttribute("Buy", v221.why)
			p219.frame:SetAttribute("Reason", v221.reason or "")
		end
		local function v_u_258(p_u_233, p234) -- name: makeRow
			-- upvalues: (ref) v_u_35, (copy) v_u_8, (ref) v_u_39, (copy) v_u_3, (copy) v_u_5, (ref) v_u_54, (copy) v_u_9, (ref) v_u_16, (copy) v_u_6, (ref) v_u_82, (ref) v_u_14, (ref) v_u_128, (copy) v_u_122, (ref) v_u_81, (copy) p_u_1, (copy) v_u_4, (copy) v_u_232
			local v235
			if v_u_35 then
				v235 = v_u_8.paidOf(nil)
			else
				v235 = v_u_8.paidOf(p_u_233.pk)
			end
			local v236
			if v_u_35 then
				v236 = v_u_39 + 50
			else
				v236 = v_u_39
			end
			local v237 = v236 + (v235.paid and 24 or 0)
			local v238 = v_u_3.new("Frame", {
				["Name"] = "Row",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.15,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_5.raised,
				["Size"] = UDim2.new(1, 0, 0, v237),
				["LayoutOrder"] = p234 + 100
			}, v_u_54)
			v238:SetAttribute("ItemRow", true)
			v238:SetAttribute("Lid", p_u_233.lid)
			local v239 = v_u_3.stroke
			local v240
			if p_u_233.own then
				v240 = v_u_5.info
			else
				v240 = v_u_5.line
			end
			local v241 = v239(v238, v240)
			if p234 == 1 then
				v241.Color = v_u_5.accent:Lerp(v_u_5.line, 0.4)
			end
			local v242 = {
				["frame"] = v238,
				["l"] = p_u_233
			}
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Qty",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = nil,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v238,
				["text"] = ("%d x"):format(p_u_233.n),
				["textSize"] = v_u_9 and 18 or 20,
				["color"] = v_u_5.text,
				["position"] = UDim2.fromOffset(12, 8),
				["size"] = UDim2.fromOffset(v_u_9 and 62 or 76, 24)
			})
			local v243
			if v_u_16 then
				v243 = v_u_6.condition(v_u_82, v_u_14, p_u_233.d, 70)
			else
				v243 = nil
			end
			local v244 = (v_u_9 and 66 or 80) + 12
			local v245 = v_u_9 and 120 or 160
			if v243 then
				v_u_8.condition(v238, v243, v245, {
					["h"] = 16
				}).Position = UDim2.fromOffset(v244, 12)
			else
				v_u_3.label({
					["parent"] = nil,
					["name"] = "NoCond",
					["text"] = "",
					["style"] = "small",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v238,
					["position"] = UDim2.fromOffset(v244, 8),
					["size"] = UDim2.fromOffset(v245, 20)
				})
			end
			v242.ends = v_u_3.label({
				["parent"] = nil,
				["name"] = "Ends",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v238,
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(12, 38),
				["size"] = UDim2.fromOffset(v244 + v245 - 12, 18)
			})
			local v246 = v_u_9 and 236 or 320
			local v247 = v_u_6.unitMoney
			local v248 = p_u_233.u
			if not v248 then
				local v249 = p_u_233.p
				local v250 = p_u_233.n
				v248 = v249 / math.max(1, v250)
			end
			local v251 = v247(v248)
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Unit",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = nil,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v238,
				["text"] = v251,
				["textSize"] = v_u_9 and 18 or 22,
				["color"] = v_u_5.accent,
				["position"] = UDim2.fromOffset(v246, 6),
				["size"] = UDim2.fromOffset(v_u_9 and 130 or 170, 26)
			})
			v_u_3.label({
				["parent"] = nil,
				["name"] = "UnitCap",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v238,
				["text"] = p_u_233.n > 1 and "each" or "",
				["color"] = v_u_5.muted,
				["position"] = UDim2.fromOffset(v246, 32),
				["size"] = UDim2.fromOffset(60, 14)
			})
			v_u_3.label({
				["parent"] = nil,
				["name"] = "Total",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v238,
				["text"] = p_u_233.n <= 1 and "" or v_u_6.money(p_u_233.p) .. " total",
				["color"] = v_u_5.text2,
				["position"] = UDim2.fromOffset(v246, 44),
				["size"] = UDim2.fromOffset(v_u_9 and 150 or 190, 16)
			})
			local v252 = v_u_3.new("Frame", {
				["Name"] = "Tags",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(v246 + (v_u_9 and 140 or 190), 10),
				["Size"] = UDim2.fromOffset(120, 18)
			}, v238)
			v_u_3.layout(v252, "h", 4)
			if p234 == 1 and not p_u_233.own then
				v_u_8.pill(v252, "CHEAPEST", v_u_5.accent, {
					["order"] = 1
				})
			end
			if p_u_233.own then
				v_u_8.pill(v252, "YOURS", v_u_5.info, {
					["order"] = 2
				})
			end
			local v253 = v_u_9 and 96 or 112
			if not p_u_233.own then
				local v255, v256 = v_u_8.button(v238, "Buy", "primary", function()
					-- upvalues: (ref) v_u_128, (copy) p_u_233
					v_u_128(p_u_233)
				end, {
					["name"] = "Buy",
					["height"] = 34,
					["width"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["onDisabledClick"] = nil,
					["width"] = v253,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, -10, 0, 8),
					["onDisabledClick"] = v_u_35 and function()
						-- upvalues: (copy) p_u_233, (ref) v_u_122, (ref) v_u_81, (ref) p_u_1
						local v254 = v_u_122(p_u_233)
						if v254.enabled == false and v_u_81 ~= nil then
							v_u_81.explain(p_u_1, v254.reason)
						end
					end or nil
				})
				v242.buy = {
					["btn"] = v255,
					["api"] = v256
				}
				v255:SetAttribute("Lid", p_u_233.lid)
			end
			v242.reason = v_u_3.label({
				["parent"] = nil,
				["name"] = "Reason",
				["text"] = "",
				["style"] = "small",
				["color"] = nil,
				["align"] = "right",
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["valign"] = "top",
				["parent"] = v238,
				["color"] = v_u_5.accent,
				["position"] = UDim2.new(1, -170, 0, v_u_4.touch(34) + 10),
				["size"] = UDim2.new(0, 160, 1, -(v_u_4.touch(34) + 12))
			})
			v242.reason.AnchorPoint = Vector2.new(0, 0)
			if v_u_35 and (v_u_81 ~= nil and v_u_14 ~= nil) then
				v242.extra = v_u_81.rowExtra(p_u_1, v238, v_u_14, {
					["top"] = v_u_39 - 2
				})
			end
			if v235.paid then
				local v257 = v_u_3.new("Frame", {
					["Name"] = "PaidStrip",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(12, v_u_39 - 4),
					["Size"] = UDim2.new(1, -24, 0, 20)
				}, v238)
				v_u_3.layout(v257, "h", 8)
				v_u_8.paidPill(v257, v235, {
					["order"] = 1,
					["h"] = 18
				})
				if v235.hint ~= nil then
					v_u_3.label({
						["parent"] = nil,
						["name"] = "PaidHint",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["autoX"] = true,
						["track"] = false,
						["order"] = 2,
						["parent"] = v257,
						["text"] = v235.hint,
						["color"] = v_u_5.text2,
						["size"] = UDim2.fromOffset(0, 18)
					})
				end
				v238:SetAttribute("Paid", true)
				v238:SetAttribute("Insurable", v235.insurable == true)
				v242.paid = v235
			end
			v_u_232(v242)
			return v242
		end
		local function v_u_262(p259) -- name: skeletonRows
			-- upvalues: (copy) v_u_3, (copy) v_u_5, (ref) v_u_39, (ref) v_u_54
			for v260 = 1, p259 do
				local v261 = v_u_3.new("Frame", {
					["Name"] = "Skeleton",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.5,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["BackgroundColor3"] = v_u_5.raised,
					["Size"] = UDim2.new(1, 0, 0, v_u_39),
					["LayoutOrder"] = v260 + 100
				}, v_u_54)
				v_u_3.new("Frame", {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.6,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_5.lineStrong,
					["Position"] = UDim2.fromOffset(12, 12),
					["Size"] = UDim2.fromOffset(140, 14)
				}, v261)
				v_u_3.new("Frame", {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.7,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_5.lineStrong,
					["Position"] = UDim2.fromOffset(12, 36),
					["Size"] = UDim2.fromOffset(90, 10)
				}, v261)
				v_u_3.new("Frame", {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.6,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_5.lineStrong,
					["Position"] = UDim2.new(0.42, 0, 0, 12),
					["Size"] = UDim2.fromOffset(110, 18)
				}, v261)
			end
		end
		local function v_u_268(p263, p264, p265) -- name: message
			-- upvalues: (copy) v_u_3, (ref) v_u_54, (copy) v_u_9, (copy) v_u_5, (copy) v_u_8, (ref) v_u_25, (copy) v_u_11
			local v266 = v_u_3.new("Frame", {
				["Name"] = "Message",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = 100 + (p265 or 1)
			}, v_u_54)
			v_u_3.layout(v266, "v", 10, "center")
			local v267 = {
				8,
				8,
				v_u_9 and 6 or 20,
				10
			}
			v_u_3.pad(v266, v267)
			v_u_3.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["align"] = "center",
				["order"] = 1,
				["parent"] = v266,
				["text"] = p263,
				["color"] = v_u_5.text2
			})
			if p264 then
				v_u_8.button(v266, "Retry", "primary", function()
					-- upvalues: (ref) v_u_25, (ref) v_u_11
					v_u_25 = 0
					v_u_11.reload(true)
				end, {
					["order"] = 2,
					["name"] = "Retry"
				})
			end
			return v266
		end
		local function v_u_270() -- name: clearHist
			-- upvalues: (ref) v_u_88
			for _, v269 in v_u_88:GetChildren() do
				if v269:IsA("UIListLayout") then
					continue
				end
				v269:Destroy()
			end
		end
		local function v_u_299(p271, p272) -- name: buildHistory
			-- upvalues: (copy) v_u_270, (copy) v_u_10, (ref) v_u_88, (copy) v_u_3, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_8
			v_u_270()
			local v273 = p271.daily
			local v274 = type(v273) ~= "table" and {} or p271.daily
			local v275 = p271.hist
			local v276 = type(v275) ~= "table" and {} or p271.hist
			if #v274 >= 2 then
				v_u_10.section(v_u_88, "Daily average, last 14 days", 1)
				local v277 = v_u_3.new("Frame", {
					["Name"] = "Chart",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.15,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["BackgroundColor3"] = v_u_5.raised,
					["Size"] = UDim2.new(1, 0, 0, v_u_9 and 84 or 100)
				}, v_u_88)
				v_u_3.stroke(v277, v_u_5.line)
				local v278 = 0
				local v279 = (1 / 0)
				local v280 = (1 / 0)
				local v281 = (-1 / 0)
				for _, v282 in v274 do
					local v283 = v282.avg
					v278 = math.max(v278, v283)
					local v284 = v282.avg
					v279 = math.min(v279, v284)
					local v285 = v282.day
					v280 = math.min(v280, v285)
					local v286 = v282.day
					v281 = math.max(v281, v286)
				end
				local v287 = v281 - v280
				math.max(1, v287)
				local v288 = v_u_3.new("Frame", {
					["Name"] = "Plot",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(74, 10),
					["Size"] = UDim2.new(1, -86, 1, -22)
				}, v277)
				v_u_3.label({
					["parent"] = nil,
					["name"] = "Max",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v277,
					["text"] = v_u_6.unitMoney(v278),
					["color"] = v_u_5.text2,
					["position"] = UDim2.fromOffset(8, 5),
					["size"] = UDim2.fromOffset(62, 16)
				})
				v_u_3.label({
					["parent"] = nil,
					["name"] = "Min",
					["text"] = nil,
					["style"] = "monoS",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v277,
					["text"] = v_u_6.unitMoney(v279),
					["color"] = v_u_5.muted,
					["position"] = UDim2.new(0, 8, 1, -30),
					["size"] = UDim2.fromOffset(62, 16)
				})
				for _, v289 in v274 do
					local v290 = (v289.day - (v281 - 14 + 1)) / 14
					local v291 = v278 <= 0 and 0 or v289.avg / v278
					v_u_3.new("Frame", {
						["Name"] = "Bar",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_5.accent,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(math.max(0, v290), 1, 1, 0),
						["Size"] = UDim2.new(0.07142857142857142, -3, math.max(0.04, v291), 0)
					}, v288).BackgroundTransparency = 0.1
				end
				v_u_3.label({
					["parent"] = nil,
					["name"] = "Cap",
					["text"] = "14 days",
					["style"] = "micro",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v277,
					["color"] = v_u_5.muted,
					["position"] = UDim2.new(1, -12, 1, -16),
					["size"] = UDim2.fromOffset(60, 12)
				})
				v277:SetAttribute("Points", #v274)
			end
			if #v276 > 0 then
				v_u_10.section(v_u_88, "Last sales, good condition", 3)
				local v292 = v_u_8.serverNow()
				for v293, v294 in v276 do
					if v293 > 10 then
						return
					end
					local v295 = v_u_3.new("Frame", {
						["Name"] = "Sale",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 22),
						["LayoutOrder"] = 3 + v293
					}, v_u_88)
					v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["textSize"] = 14,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v295,
						["text"] = ("%s x %d"):format(v_u_6.unitMoney(v294.u), v294.n),
						["color"] = v_u_5.text,
						["position"] = UDim2.fromOffset(4, 0),
						["size"] = UDim2.new(0.6, 0, 1, 0)
					})
					local v296
					if v292 then
						local v297 = v_u_6.ago
						local v298 = v292 - v294.t
						v296 = v297((math.max(0, v298)))
					else
						v296 = ""
					end
					v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v295,
						["text"] = v296,
						["color"] = v_u_5.text2,
						["position"] = UDim2.new(0.6, 0, 0, 0),
						["size"] = UDim2.new(0.4, -4, 1, 0)
					})
				end
			elseif #v274 < 2 then
				v_u_3.label({
					["parent"] = nil,
					["name"] = "HistNote",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 5,
					["parent"] = v_u_88,
					["text"] = v_u_6.historyNote(p271, p272) or v_u_6.TEXT.noSales,
					["color"] = v_u_5.muted
				})
			end
		end
		local function v_u_314(p300) -- name: paintNumbers
			-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_55, (copy) v_u_5
			local v301
			if p300 then
				local v302 = p300.stats
				if type(v302) == "table" then
					v301 = p300.stats
				else
					v301 = nil
				end
			else
				v301 = nil
			end
			local v303 = nil
			local v304 = v_u_8.serverNow()
			if v301 and v304 then
				local v305 = v301.lastAt
				if type(v305) == "number" then
					local v306 = v304 - v301.lastAt
					v303 = math.max(0, v306)
				end
			end
			local v307
			if v301 then
				v307 = v_u_6.numbers(v301, v303)
			else
				v307 = nil
			end
			for _, v308 in {
				"min",
				"avg7",
				"last",
				"count"
			} do
				local v309 = v_u_55[v308]
				local v310 = nil
				if v307 then
					for _, v311 in v307 do
						if v311.id ~= v308 then
							continue
						end
						v310 = v311
					end
				end
				v309.label.Text = ({
					["min"] = "CHEAPEST",
					["avg7"] = "7 DAY AVERAGE",
					["last"] = "LAST SALE",
					["count"] = "LISTED"
				})[v308]
				if v310 then
					v309.value.Text = v310.value
					local v312 = v309.value
					local v313
					if v310.empty then
						v313 = v_u_5.muted
					else
						v313 = v_u_5.text
					end
					v312.TextColor3 = v313
					v309.sub.Text = v310.sub or ""
				else
					v309.value.Text = ""
					v309.sub.Text = ""
				end
			end
		end
		local function v_u_326(p315) -- name: paintAge
			-- upvalues: (copy) v_u_48, (ref) v_u_19, (copy) v_u_7, (ref) v_u_18, (copy) v_u_6
			if p315 then
				local v316 = p315.age
				if type(v316) == "number" then
					local v317 = v_u_19 and 0 or p315.age
					local v318
					if v_u_19 then
						local v319 = v_u_7:clock() - v_u_19.at
						v318 = math.max(0, v319)
					elseif v_u_18 then
						local v320 = v_u_18._at
						if type(v320) == "number" then
							local v321 = v_u_7:clock() - v_u_18._at
							v318 = math.max(0, v321)
						else
							v318 = 0
						end
					else
						v318 = 0
					end
					local v322 = v317 + v318
					if v322 >= 25 then
						local v323 = v_u_48
						local v324 = "updated %s"
						local v325
						if v322 < 90 then
							v325 = ("%d s ago"):format((math.floor(v322)))
						else
							v325 = v_u_6.ago(v322)
						end
						v323.Text = v324:format(v325)
					else
						v_u_48.Text = ""
					end
				end
			end
			v_u_48.Text = ""
		end
		local function v_u_342() -- name: paintStatics
			-- upvalues: (ref) v_u_15, (copy) v_u_47, (copy) v_u_7, (ref) v_u_58, (copy) v_u_4, (copy) p_u_1, (ref) v_u_59, (ref) v_u_16, (ref) v_u_14, (copy) v_u_26, (ref) v_u_57, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (ref) v_u_87, (ref) v_u_100, (ref) v_u_101, (copy) v_u_127
			if v_u_15 then
				v_u_47.Text = v_u_15.name
				local v327 = ""
				for _, v328 in v_u_7:eligibility().CATEGORIES do
					if v328.id ~= v_u_15.cat then
						continue
					end
					v327 = v328.label
				end
				local v329 = v_u_58
				local v330 = string.upper
				local v331 = v_u_4.rarityName
				local v332 = v_u_15.rarity or 1
				v329.Text = v327 .. "  \194\183  " .. v330(v331[math.clamp(v332, 1, 6)])
				v_u_58.TextColor3 = v_u_4.rarityColor(v_u_15.rarity)
				local v333 = p_u_1.kit
				if v333 then
					v333 = p_u_1.kit.shownDesc
				end
				local v334 = v_u_59
				local v335
				if v_u_16 then
					local v336
					if type(v333) == "function" then
						v336 = v333(v_u_16, v_u_14)
					else
						v336 = v_u_16.desc
					end
					v335 = v336 or ""
				else
					v335 = ""
				end
				v334.Text = v335
				for _, v337 in v_u_26 do
					v337()
				end
				table.clear(v_u_26)
				for _, v338 in v_u_57:GetChildren() do
					v338:Destroy()
				end
				local _, v339 = v_u_8.icon(v_u_57, v_u_15.id, v_u_9 and 44 or 104)
				local v340 = v_u_26
				table.insert(v340, v339)
				local v341 = v_u_6.traderSells(p_u_1.mc, v_u_15.id)
				v_u_87.Text = not v341 and "" or ("A trader sells this for %s."):format(v_u_6.unitMoney(v341))
				v_u_87.Visible = v341 ~= nil
				v_u_100.Visible = v_u_15.dur == true
				v_u_101.Visible = v_u_15.dur == true
				v_u_127()
			end
		end
		local v_u_343 = nil
		local function v_u_349()
			-- upvalues: (copy) v_u_114, (copy) v_u_218, (ref) v_u_23, (ref) v_u_102, (copy) v_u_6, (ref) v_u_21, (copy) v_u_262, (ref) v_u_25, (copy) v_u_268, (copy) p_u_1, (ref) v_u_18, (ref) v_u_20, (ref) v_u_17, (copy) v_u_28, (copy) v_u_258, (ref) v_u_22, (copy) v_u_3, (copy) v_u_4, (ref) v_u_54, (copy) v_u_8, (ref) v_u_343
			v_u_114()
			v_u_218()
			if v_u_23 == "ok" then
				v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
			else
				v_u_102.Text = ""
			end
			if v_u_23 == "loading" then
				v_u_262(4)
				return
			elseif v_u_23 == "busy" then
				v_u_262(3)
				if v_u_25 >= v_u_6.RETRY_MAX then
					v_u_268(v_u_6.text(p_u_1.rules, "BUSY"), true, 50)
				else
					v_u_268("The market is busy. Trying again.", false, 50)
				end
			elseif v_u_23 == "down" then
				v_u_268(v_u_6.TEXT.storeDown, true)
				return
			elseif v_u_23 == "error" then
				v_u_268(v_u_18 and v_u_18.text or v_u_6.TEXT.pricesDown, true)
				return
			elseif #v_u_20 == 0 then
				v_u_268(v_u_17 and "No listings in good condition. Try ANY CONDITION." or "Nobody is selling this right now.", false)
			else
				for v344, v345 in v_u_20 do
					local v346 = v_u_28
					local v347 = v_u_258(v345, v344)
					table.insert(v346, v347)
				end
				if v_u_22 then
					local v348 = v_u_3.new("Frame", {
						["Name"] = "MoreBtn",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(40) + 6),
						["LayoutOrder"] = #v_u_20 + 100 + 1
					}, v_u_54)
					v_u_8.button(v348, "More", "secondary", function()
						-- upvalues: (ref) v_u_343
						v_u_343()
					end, {
						["name"] = "More",
						["position"] = nil,
						["width"] = 160,
						["height"] = 40,
						["position"] = UDim2.fromOffset(0, 4)
					})
				end
			end
		end
		local function v_u_359(p350, p351) -- name: loadFirst
			-- upvalues: (ref) v_u_24, (copy) v_u_7, (ref) v_u_14, (ref) v_u_23, (ref) v_u_349, (ref) v_u_17, (ref) v_u_12, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (copy) v_u_314, (copy) v_u_6, (copy) v_u_11, (copy) v_u_299, (copy) v_u_326, (ref) v_u_102, (ref) v_u_186, (copy) v_u_359, (copy) v_u_270
			v_u_24 = v_u_24 + 1
			local v_u_352 = v_u_24
			if p350 then
				v_u_7:invalidate("item/" .. v_u_14)
			end
			if not p351 or v_u_23 ~= "ok" then
				v_u_23 = "loading"
				v_u_349()
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_7, (ref) v_u_17, (copy) v_u_352, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (ref) v_u_314, (ref) v_u_6, (ref) v_u_11, (ref) v_u_299, (ref) v_u_326, (ref) v_u_102, (ref) v_u_349, (ref) v_u_186, (ref) v_u_359, (ref) v_u_270
				local v353 = v_u_7:item(v_u_14, 0, v_u_17)
				if v_u_352 == v_u_24 and (v_u_12 and v_u_13) then
					v_u_18 = v353
					if v353.ok then
						v_u_19 = nil
						v_u_23 = "ok"
						local v354 = v353.listings
						v_u_20 = type(v354) ~= "table" and {} or v353.listings
						v_u_21 = v353.total or #v_u_20
						v_u_22 = v353.more == true
						v_u_25 = 0
						v_u_314(v353)
						local v355 = v_u_6.historyRetry(v353, v_u_11.histTries)
						local v356 = v_u_299
						local v357
						if v353.histPending == true then
							v357 = v355 == nil
						else
							v357 = false
						end
						v356(v353, v357)
						v_u_326(v353)
						if v_u_23 == "ok" then
							v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
						else
							v_u_102.Text = ""
						end
						v_u_349()
						if v_u_186 and v_u_186.isOpen() then
							v_u_186.refresh()
						end
						if v355 ~= nil then
							v_u_11.histTries = (v_u_11.histTries or 0) + 1
							task.delay(v355, function()
								-- upvalues: (ref) v_u_352, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
								if v_u_352 == v_u_24 and (v_u_12 and v_u_13) then
									v_u_359(true, true)
								end
							end)
							return
						end
					elseif v353.code == "BUSY" then
						v_u_25 = v_u_25 + 1
						v_u_23 = "busy"
						v_u_314(nil)
						v_u_270()
						v_u_349()
						if v_u_25 < v_u_6.RETRY_MAX then
							local v358 = v_u_6.retryDelay(v353.retryIn, v_u_25, 0.9 + math.random() * 0.2)
							task.delay(v358, function()
								-- upvalues: (ref) v_u_352, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
								if v_u_352 == v_u_24 and (v_u_12 and v_u_13) then
									v_u_359(true)
								end
							end)
							return
						end
					else
						if v353.ds == "down" or v353.code == "STORE" then
							v_u_23 = "down"
							v_u_314(nil)
							v_u_270()
							v_u_349()
							return
						end
						v_u_23 = "error"
						v_u_314(nil)
						v_u_270()
						v_u_349()
					end
				end
			end)
		end
		v_u_343 = function()
			-- upvalues: (ref) v_u_22, (ref) v_u_23, (ref) v_u_24, (ref) v_u_349, (copy) v_u_7, (ref) v_u_14, (ref) v_u_20, (ref) v_u_17, (ref) v_u_12, (ref) v_u_13, (ref) v_u_21, (ref) v_u_102, (copy) v_u_6, (ref) v_u_186
			if v_u_22 and v_u_23 == "ok" then
				local v_u_360 = v_u_24
				v_u_22 = false
				v_u_349()
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_20, (ref) v_u_17, (copy) v_u_360, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_22, (ref) v_u_21, (ref) v_u_23, (ref) v_u_102, (ref) v_u_6, (ref) v_u_349, (ref) v_u_186
					local v361 = v_u_7:item(v_u_14, #v_u_20, v_u_17)
					if v_u_360 ~= v_u_24 or not (v_u_12 and v_u_13) then
						return
					end
					if v361.ok then
						local v362 = v361.listings
						if type(v362) == "table" then
							for _, v363 in v361.listings do
								local v364 = v_u_20
								table.insert(v364, v363)
							end
							v_u_22 = v361.more == true
							v_u_21 = v361.total or v_u_21
							if v_u_23 == "ok" then
								v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
							else
								v_u_102.Text = ""
							end
							v_u_349()
							if v_u_186 and v_u_186.isOpen() then
								v_u_186.refresh()
							end
						else
							v_u_22 = true
							v_u_349()
							if v_u_186 and v_u_186.isOpen() then
								v_u_186.refresh()
							end
						end
					else
						v_u_22 = true
						v_u_349()
						if v_u_186 and v_u_186.isOpen() then
							v_u_186.refresh()
						end
						return
					end
				end)
			end
		end
		v_u_130 = function(p365)
			-- upvalues: (ref) v_u_19, (copy) v_u_7, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_102, (copy) v_u_6, (ref) v_u_349, (copy) v_u_55, (copy) v_u_5, (ref) v_u_186
			v_u_19 = {
				["at"] = v_u_7:clock()
			}
			v_u_20 = p365.listings
			v_u_21 = p365.total or #v_u_20
			v_u_22 = p365.more == true
			v_u_23 = "ok"
			if v_u_23 == "ok" then
				v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
			else
				v_u_102.Text = ""
			end
			v_u_349()
			local v366 = v_u_55.min
			local v367 = v_u_55.count
			if v366 and (p365.min ~= nil or p365.all ~= nil) then
				local v368 = p365.min
				if type(v368) == "number" then
					v366.value.Text = v_u_6.unitMoney(p365.min)
					v366.value.TextColor3 = v_u_5.text
					v366.sub.Text = "each"
				else
					v366.value.Text = "No listings"
					v366.value.TextColor3 = v_u_5.muted
					v366.sub.Text = ""
				end
			end
			if v367 then
				local v369 = p365.all
				if type(v369) == "number" then
					v367.value.Text = v_u_6.commas(p365.all)
					local v370 = v367.value
					local v371
					if p365.all == 0 then
						v371 = v_u_5.muted
					else
						v371 = v_u_5.text
					end
					v370.TextColor3 = v371
				end
			end
			if v_u_186 and v_u_186.isOpen() then
				v_u_186.refresh()
			end
		end
		v_u_131 = function(p372, p_u_373)
			-- upvalues: (copy) p_u_1, (ref) v_u_13, (ref) v_u_14, (ref) v_u_20, (ref) v_u_21, (ref) v_u_23, (ref) v_u_102, (copy) v_u_6, (ref) v_u_349, (copy) v_u_11
			p_u_1.refreshState(true)
			if v_u_13 and v_u_14 == p_u_373 then
				if p372 then
					for v374 = #v_u_20, 1, -1 do
						if v_u_20[v374].lid ~= p372 then
							continue
						end
						table.remove(v_u_20, v374)
						local v375 = v_u_21 - 1
						v_u_21 = math.max(0, v375)
					end
					if v_u_23 == "ok" then
						v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
					else
						v_u_102.Text = ""
					end
					v_u_349()
				end
				v_u_11.reload(true)
				task.delay(3, function()
					-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) p_u_373, (ref) v_u_11
					if v_u_13 and v_u_14 == p_u_373 then
						v_u_11.reload(false)
					end
				end)
			end
		end
		local function v_u_482(p376, p_u_377)
			-- upvalues: (ref) v_u_30, (ref) v_u_35, (copy) v_u_122, (ref) v_u_81, (copy) p_u_1, (ref) v_u_14, (ref) v_u_15, (copy) v_u_7, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_11, (copy) v_u_4, (copy) v_u_8, (ref) v_u_131, (copy) v_u_9, (ref) v_u_129, (ref) v_u_82, (ref) v_u_12, (ref) v_u_17, (ref) v_u_130, (ref) v_u_13
			if not v_u_30 then
				if v_u_35 then
					local v378 = v_u_122(p376)
					if v378.enabled == false and (v_u_81 ~= nil and v_u_81.REFUSAL[v378.why] == true) then
						v_u_81.explain(p_u_1, v378.reason)
						return
					end
				end
				local v_u_379 = v_u_14
				local v_u_380 = v_u_15.name
				local v_u_381 = p376
				local v_u_382 = false
				local v_u_383 = nil
				local v_u_384 = nil
				local v_u_385 = nil
				local v_u_386 = nil
				local function v_u_391() -- name: paintAfter
					-- upvalues: (ref) v_u_386, (ref) v_u_7, (ref) v_u_385, (ref) v_u_381, (ref) v_u_6, (ref) v_u_5
					if v_u_386 ~= nil and v_u_386.Parent ~= nil then
						local v387 = v_u_7:cash()
						if v_u_385 ~= nil then
							if v_u_385 <= v387 then
								v_u_385 = nil
							else
								v387 = v_u_385
							end
						end
						local v388 = v387 - v_u_381.p
						v_u_386.Text = v_u_6.money(v388)
						local v389 = v_u_386
						local v390
						if v388 < 0 then
							v390 = v_u_5.danger
						else
							v390 = v_u_5.text
						end
						v389.TextColor3 = v390
					end
				end
				local function v_u_393() -- name: clear
					-- upvalues: (ref) v_u_383
					if v_u_383 then
						for _, v392 in v_u_383:GetChildren() do
							if v392:IsA("UIListLayout") then
								continue
							end
							v392:Destroy()
						end
					end
				end
				local function v_u_399(p394, p395, p396, p397) -- name: line
					-- upvalues: (ref) v_u_3, (ref) v_u_383, (ref) v_u_5
					local v398 = v_u_3.new("Frame", {
						["Name"] = "Line",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 22),
						["LayoutOrder"] = p397
					}, v_u_383)
					v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v398,
						["text"] = p394,
						["color"] = v_u_5.text2,
						["size"] = UDim2.new(0.55, 0, 1, 0)
					})
					return v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["textSize"] = 15,
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v398,
						["text"] = p395,
						["color"] = p396 or v_u_5.text,
						["position"] = UDim2.fromScale(0.55, 0),
						["size"] = UDim2.new(0.45, 0, 1, 0)
					})
				end
				local function v_u_406(p400) -- name: buttons
					-- upvalues: (ref) v_u_11, (ref) v_u_3, (ref) v_u_4, (ref) v_u_383, (ref) v_u_8
					v_u_11.panelButtons = {}
					for _, v401 in p400 do
						v_u_11.panelButtons[v401.text] = v401.onClick
					end
					local v402 = v_u_3.new("Frame", {
						["Name"] = "Buttons",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 90,
						["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(v_u_4.control))
					}, v_u_383)
					v_u_3.layout(v402, "h", 8, "right")
					for v403, v404 in p400 do
						local v405 = v_u_8.button(v402, v404.text, v404.kind, v404.onClick, {
							["order"] = v403
						})
						if v403 ~= #p400 then
							continue
						end
						v405:SetAttribute("PadDefault", true)
					end
				end
				local function v_u_407() -- name: close
					-- upvalues: (ref) v_u_384, (ref) v_u_382
					if v_u_384 and not v_u_382 then
						v_u_384.close()
					end
				end
				local function v_u_415(p408, p409, p410, p411, p412) -- name: result
					-- upvalues: (copy) v_u_393, (ref) v_u_3, (ref) v_u_383, (ref) v_u_5, (copy) v_u_406, (copy) v_u_407
					v_u_393()
					local v413 = v_u_3.new("Frame", {
						["Name"] = "Result",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}, v_u_383)
					v_u_3.layout(v413, "v", 8)
					local v414 = v_u_3.new("Frame", {
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 28)
					}, v413)
					v_u_3.icon(p408, {
						["parent"] = nil,
						["size"] = 22,
						["color"] = nil,
						["position"] = nil,
						["parent"] = v414,
						["color"] = p410,
						["position"] = UDim2.fromOffset(0, 3)
					})
					v_u_3.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v414,
						["text"] = p409,
						["color"] = v_u_5.text,
						["position"] = UDim2.fromOffset(32, 0),
						["size"] = UDim2.new(1, -32, 1, 0)
					})
					if p411 then
						v_u_3.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["parent"] = v413,
							["text"] = p411,
							["color"] = v_u_5.text2
						})
					end
					if p412 then
						p412()
					end
					v_u_406({
						{
							["text"] = "Close",
							["kind"] = "primary",
							["onClick"] = nil,
							["onClick"] = v_u_407
						}
					})
					v413.Name = "Result"
				end
				local function v_u_417(p416) -- name: refreshAll
					-- upvalues: (ref) v_u_131, (copy) v_u_379
					v_u_131(p416, v_u_379)
				end
				local function v_u_422(p418) -- name: progress
					-- upvalues: (copy) v_u_393, (ref) v_u_3, (ref) v_u_383, (ref) v_u_5, (ref) v_u_382
					v_u_393()
					local v_u_419 = v_u_3.new("Frame", {
						["Name"] = "Progress",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = 1,
						["Size"] = UDim2.new(1, 0, 0, 56)
					}, v_u_383)
					v_u_3.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v_u_419,
						["text"] = p418,
						["color"] = v_u_5.text,
						["size"] = UDim2.new(1, 0, 0, 24)
					})
					local v_u_420 = v_u_3.progress({
						["parent"] = nil,
						["size"] = nil,
						["position"] = nil,
						["value"] = 0.2,
						["color"] = nil,
						["parent"] = v_u_419,
						["size"] = UDim2.new(0.6, 0, 0, 4),
						["position"] = UDim2.new(0.2, 0, 0, 36),
						["color"] = v_u_5.accent
					})
					task.spawn(function()
						-- upvalues: (copy) v_u_419, (ref) v_u_382, (copy) v_u_420
						local v421 = 0.1
						while v_u_419.Parent and not v_u_382 do
							v421 = (v421 + 0.12) % 1
							v_u_420.set(v421)
							task.wait(0.25)
						end
					end)
				end
				local function v_u_479(p423)
					-- upvalues: (copy) v_u_393, (ref) v_u_381, (copy) v_u_380, (ref) v_u_7, (ref) v_u_385, (ref) v_u_386, (ref) v_u_3, (ref) v_u_383, (ref) v_u_5, (ref) v_u_35, (ref) v_u_81, (ref) v_u_6, (copy) v_u_379, (ref) p_u_1, (ref) v_u_9, (copy) v_u_399, (ref) v_u_129, (copy) v_u_391, (ref) v_u_82, (ref) v_u_8, (copy) v_u_406, (copy) v_u_407, (ref) v_u_4, (copy) v_u_422, (ref) v_u_382, (ref) v_u_12, (ref) v_u_11, (copy) v_u_415, (ref) v_u_384, (copy) v_u_417, (ref) v_u_17, (ref) v_u_130, (ref) v_u_479, (ref) v_u_13, (ref) v_u_14
					v_u_393()
					local v_u_424 = v_u_381
					local v_u_425
					if v_u_424.n > 1 then
						v_u_425 = ("%d x %s"):format(v_u_424.n, v_u_380)
					else
						v_u_425 = v_u_380
					end
					local v426 = v_u_7:cash()
					if v_u_385 ~= nil then
						if v_u_385 <= v426 then
							v_u_385 = nil
						else
							v426 = v_u_385
						end
					end
					local v427 = v426 - v_u_424.p
					v_u_386 = nil
					local v428 = 0
					if p423 then
						local v429 = v428 + 1
						local v430 = v_u_3.label
						local v431 = {
							["parent"] = nil,
							["name"] = "Notice",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_383,
							["text"] = p423.text
						}
						local v432
						if p423.kind == "warn" then
							v432 = v_u_5.accent
						else
							v432 = v_u_5.info
						end
						v431.color = v432
						v431.order = v429
						v430(v431):SetAttribute("Kind", p423.kind)
						v428 = v429 + 1
						v_u_3.new("Frame", {
							["Name"] = "Gap",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = nil,
							["Size"] = UDim2.new(1, 0, 0, 8),
							["LayoutOrder"] = v428
						}, v_u_383)
					end
					local v433
					if v_u_35 and v_u_81 ~= nil then
						v433 = v_u_6.crateConfirm(v_u_379, v_u_424.n, v_u_424.p, v426, "buy", {
							["mail"] = true
						})
					else
						v433 = nil
					end
					if v433 == nil then
						v428 = v428 + 1
						v_u_3.label({
							["parent"] = nil,
							["name"] = "Question",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_383,
							["text"] = ("Buy %s for %s?"):format(v_u_425, v_u_6.money(v_u_424.p)),
							["color"] = v_u_5.text,
							["order"] = v428
						})
						local v434 = v_u_399
						local v435 = "Price"
						local v436
						if v_u_424.n > 1 then
							v436 = ("%s (%s each)"):format(v_u_6.money(v_u_424.p), v_u_6.unitMoney(v_u_424.u or v_u_424.p / v_u_424.n))
						else
							v436 = v_u_6.money(v_u_424.p)
						end
						v434(v435, v436, v_u_5.text, v428 + 1)
						local v437 = v_u_399
						local v438 = "Your Cash after"
						local v439 = v_u_6.money(v427)
						local v440
						if v427 < 0 then
							v440 = v_u_5.danger
						else
							v440 = v_u_5.text
						end
						v_u_386 = v437(v438, v439, v440, v428 + 2)
						v_u_129 = v_u_391
						local v441 = v_u_6.traderSells(p_u_1.mc, v_u_379)
						if v441 then
							v_u_399("A trader sells this for", v_u_6.unitMoney(v441) .. (v_u_424.n > 1 and " each" or ""), v_u_5.info, v428 + 3)
						end
						local v442 = v_u_6.condition(v_u_82, v_u_379, v_u_424.d, 70)
						if v442 then
							local v443 = v_u_399
							local v444 = "Condition"
							local v445
							if v442.uses then
								v445 = ("%d of %d uses"):format(v442.uses.left, v442.uses.total)
							else
								v445 = ("%d%%"):format(v442.pct)
							end
							local v446
							if v442.kind == "good" then
								v446 = v_u_5.success
							elseif v442.kind == "worn" then
								v446 = v_u_5.accent
							else
								v446 = v_u_5.danger
							end
							v443(v444, v445, v446, v428 + 4)
						end
						local v447 = v_u_8.paidOf(v_u_424.pk)
						if v447.paid then
							local v448 = v_u_3.new("Frame", {
								["Name"] = "PaidRow",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.new(1, 0, 0, 0),
								["AutomaticSize"] = Enum.AutomaticSize.Y,
								["LayoutOrder"] = v428 + 5
							}, v_u_383)
							v_u_3.layout(v448, "h", 8)
							v_u_8.paidPill(v448, v447, {
								["order"] = 1,
								["h"] = 20
							})
							if v447.line ~= nil then
								v_u_3.label({
									["parent"] = nil,
									["name"] = "PaidLine",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["size"] = nil,
									["order"] = 2,
									["parent"] = v448,
									["text"] = v447.line,
									["color"] = v_u_5.text2,
									["size"] = UDim2.new(1, -90, 0, 0)
								})
							end
							v448:SetAttribute("Insurable", v447.insurable == true)
						end
						v_u_3.label({
							["parent"] = nil,
							["name"] = "Note",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = nil,
							["parent"] = v_u_383,
							["text"] = v_u_6.TEXT.cashSetAside,
							["color"] = v_u_5.text2,
							["order"] = v428 + 6
						})
					else
						for _, v449 in v433.elements do
							v428 = v428 + 1
							if v449.kind == "title" then
								v_u_3.label({
									["parent"] = nil,
									["name"] = "Question",
									["text"] = nil,
									["style"] = "bodyStrong",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_383,
									["text"] = v449.text,
									["color"] = v_u_5.text,
									["order"] = v428
								})
							elseif v449.kind == "block" then
								local v450 = {
									["order"] = v428,
									["tight"] = v_u_9
								}
								v_u_81.block(p_u_1, v_u_383, v_u_379, v450)
							elseif v449.kind == "price" then
								v_u_399(v449.label, v449.text, v_u_5.text, v428)
							elseif v449.kind == "cash" then
								local v451 = v_u_399
								local v452 = v449.label
								local v453 = v449.text
								local v454
								if v449.danger then
									v454 = v_u_5.danger
								else
									v454 = v_u_5.text
								end
								v_u_386 = v451(v452, v453, v454, v428)
								v_u_129 = v_u_391
							elseif v449.kind == "delivery" then
								v_u_3.label({
									["parent"] = nil,
									["name"] = "Delivery",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_383,
									["text"] = v449.text,
									["color"] = v_u_5.text2,
									["order"] = v428
								})
							else
								v_u_3.label({
									["parent"] = nil,
									["name"] = "Note",
									["text"] = nil,
									["style"] = "small",
									["color"] = nil,
									["wrap"] = true,
									["autoY"] = true,
									["order"] = nil,
									["parent"] = v_u_383,
									["text"] = v449.text,
									["color"] = v_u_5.text2,
									["order"] = v428
								})
							end
						end
					end
					local v_u_455 = v_u_3.label({
						["parent"] = nil,
						["name"] = "Reason",
						["text"] = "",
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v_u_383,
						["color"] = v_u_5.accent,
						["order"] = v428 + 7
					})
					v_u_406({
						{
							["text"] = "Cancel",
							["kind"] = "secondary",
							["onClick"] = nil,
							["onClick"] = v_u_407
						},
						{
							["text"] = "Buy",
							["kind"] = "primary",
							["onClick"] = nil,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_7, (ref) v_u_385, (ref) v_u_6, (ref) p_u_1, (copy) v_u_424, (ref) v_u_35, (ref) v_u_379, (copy) v_u_455, (ref) v_u_3, (ref) v_u_4, (ref) v_u_386, (ref) v_u_422, (ref) v_u_382, (ref) v_u_12, (ref) v_u_11, (ref) v_u_415, (ref) v_u_5, (ref) v_u_384, (ref) v_u_417, (copy) v_u_425, (ref) v_u_17, (ref) v_u_130, (ref) v_u_381, (ref) v_u_479, (ref) v_u_13, (ref) v_u_14
								local v_u_456 = v_u_7:cash()
								if v_u_385 ~= nil then
									if v_u_385 <= v_u_456 then
										v_u_385 = nil
									else
										v_u_456 = v_u_385
									end
								end
								local v457 = v_u_6.buyButton
								local v458 = p_u_1.state
								local v459 = v_u_424
								local v460 = v_u_7:remaining(p_u_1.state or {}, "buyIn")
								local v461 = p_u_1.rules
								local v462
								if v_u_35 then
									v462 = v_u_379
								else
									v462 = nil
								end
								local v463 = v457(v458, v459, v_u_456, v460, v461, v462)
								if v463.enabled then
									v_u_386 = nil
									v_u_422(v_u_6.TEXT.settingAside)
									local v_u_464 = 0
									task.delay(0.55, function()
										-- upvalues: (ref) v_u_382, (ref) v_u_464, (ref) v_u_422, (ref) v_u_6
										if not v_u_382 and v_u_464 == 0 then
											v_u_422(v_u_6.TEXT.buying)
										end
									end)
									task.spawn(function()
										-- upvalues: (ref) v_u_7, (ref) v_u_379, (ref) v_u_424, (ref) v_u_464, (ref) v_u_382, (ref) v_u_12, (ref) v_u_11, (ref) v_u_415, (ref) v_u_6, (ref) v_u_5, (ref) v_u_384, (ref) v_u_417, (ref) p_u_1, (ref) v_u_425, (ref) v_u_17, (ref) v_u_130, (ref) v_u_381, (ref) v_u_385, (copy) v_u_456, (ref) v_u_479, (ref) v_u_13, (ref) v_u_14
										local v465 = v_u_7:buy({
											["id"] = v_u_379,
											["lid"] = v_u_424.lid,
											["price"] = v_u_424.p
										})
										v_u_464 = 1
										if v_u_382 or not v_u_12 then
											return
										else
											v_u_11.lastBuy = v465
											if v465.ok and v465.state == "processing" then
												v_u_415("clock", v_u_6.TEXT.working, v_u_5.info, nil)
												task.delay(1.8, function()
													-- upvalues: (ref) v_u_384, (ref) v_u_382
													if v_u_384 and not v_u_382 then
														v_u_384.close()
													end
												end)
												task.defer(v_u_417)
												return
											elseif v465.ok then
												local function v466()
													-- upvalues: (ref) p_u_1
													return p_u_1.mc.cctx.controllers.BmNotes
												end
												local v467, v468 = pcall(v466)
												if v467 and (v468 and v468.quiet) then
													v468.quiet("bought", v_u_379)
												end
												v_u_415("check", v_u_6.TEXT.bought, v_u_5.success, ("%s for %s."):format(v_u_425, v_u_6.money(v_u_424.p)))
												task.defer(v_u_417, v_u_424.lid)
												return
											elseif v465.code == "PRICE" or v465.code == "GONE" then
												local v469 = v_u_6.nextOffer(v465, v_u_424, v_u_17)
												if v469 then
													v_u_130(v469.page)
													p_u_1.refreshState(true)
													local v470, v471 = v_u_6.lostNotice(v469, v465.code)
													v_u_381 = v469.row
													v_u_11.lastOffer = v469
													v_u_385 = v_u_456
													v_u_479({
														["text"] = v470,
														["kind"] = v471
													})
													task.delay(2.5, function()
														-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_379, (ref) v_u_382, (ref) v_u_11
														if v_u_13 and (v_u_14 == v_u_379 and not v_u_382) then
															v_u_11.reload(false, true)
														end
													end)
												else
													local v472 = v_u_6.applyNext
													local v473 = v465.data
													local v474
													if type(v473) == "table" then
														v474 = v465.data.next
													else
														v474 = nil
													end
													local v475 = v472(v474, v_u_17)
													if v475 then
														v_u_130(v475)
													end
													local v476 = v_u_415
													local v477 = "warning"
													local v478
													if v475 then
														v478 = v_u_6.TEXT.nobodyLeft
													else
														v478 = v465.text
													end
													v476(v477, v478, v_u_5.accent, nil)
													task.defer(v_u_417)
												end
											else
												v_u_415("warning", v465.text, v_u_5.danger, nil)
												task.defer(v_u_417)
												return
											end
										end
									end)
								else
									v_u_455.Text = v463.reason or ""
									v_u_3.sound(v_u_4.sounds.error)
								end
							end
						}
					})
				end
				local v481 = {
					["title"] = "Buy",
					["width"] = 480,
					["build"] = nil,
					["onClose"] = nil,
					["build"] = function(p480) -- name: build
						-- upvalues: (ref) v_u_383, (ref) v_u_479, (copy) p_u_377
						v_u_383 = p480
						v_u_479(p_u_377)
					end,
					["onClose"] = function() -- name: onClose
						-- upvalues: (ref) v_u_382, (ref) v_u_30, (ref) v_u_129
						v_u_382 = true
						v_u_30 = nil
						v_u_129 = nil
					end
				}
				v_u_384 = v_u_3.modal(v481)
				v_u_30 = v_u_384
				v_u_11.panelApi = v_u_384
			end
		end
		function v_u_11.layout() -- name: layout
			-- upvalues: (copy) p_u_1, (copy) v_u_40
			local v483 = p_u_1.itemTop()
			v_u_40.Position = UDim2.fromOffset(0, v483)
			v_u_40.Size = UDim2.new(1, 0, 1, -v483)
		end
		function v_u_11.isOpen() -- name: isOpen
			-- upvalues: (ref) v_u_13
			return v_u_13
		end
		function v_u_11.open(p484) -- name: open
			-- upvalues: (copy) v_u_7, (ref) v_u_15, (ref) v_u_16, (copy) p_u_1, (ref) v_u_14, (ref) v_u_35, (copy) v_u_6, (ref) v_u_36, (ref) v_u_38, (ref) v_u_17, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_18, (ref) v_u_19, (ref) v_u_25, (copy) v_u_11, (ref) v_u_13, (copy) v_u_9, (copy) v_u_40, (ref) v_u_142, (copy) v_u_111, (copy) v_u_342, (copy) v_u_314, (copy) v_u_270, (copy) v_u_48, (ref) v_u_23, (ref) v_u_102, (ref) v_u_90, (ref) v_u_24, (ref) v_u_349, (ref) v_u_12, (copy) v_u_299, (copy) v_u_326, (ref) v_u_186, (copy) v_u_359, (copy) v_u_3, (copy) v_u_45
			local v485 = v_u_7:catalog()
			v_u_15 = nil
			for _, v486 in v485 do
				if v486.id ~= p484 then
					continue
				end
				v_u_15 = v486
			end
			if v_u_15 then
				v_u_16 = p_u_1.kit.itemDef(p484)
				v_u_14 = p484
				v_u_35 = v_u_6.isCrateItem(p484)
				if v_u_36 ~= nil and v_u_38 ~= p484 then
					v_u_36:Destroy()
					v_u_36 = nil
					v_u_38 = nil
				end
				v_u_17 = false
				v_u_20 = {}
				v_u_21 = 0
				v_u_22 = false
				v_u_18 = nil
				v_u_19 = nil
				v_u_25 = 0
				v_u_11.histTries = 0
				v_u_13 = true
				p_u_1.body.Visible = false
				if v_u_9 then
					p_u_1.setSubRowVisible(false)
				else
					p_u_1.subHost.Visible = false
				end
				local v487 = p_u_1.itemTop()
				v_u_40.Position = UDim2.fromOffset(0, v487)
				v_u_40.Size = UDim2.new(1, 0, 1, -v487)
				v_u_40.Visible = true
				v_u_142("listings", true)
				v_u_111()
				v_u_342()
				v_u_314(nil)
				v_u_270()
				v_u_48.Text = ""
				if v_u_23 == "ok" then
					v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
				else
					v_u_102.Text = ""
				end
				p_u_1.page:SetAttribute("MarketItem", p484)
				if v_u_90 then
					local v488 = v_u_90.setItem
					pcall(v488, p484)
				end
				v_u_24 = v_u_24 + 1
				local v_u_489 = v_u_24
				v_u_23 = "loading"
				v_u_349()
				task.spawn(function()
					-- upvalues: (ref) v_u_14, (ref) v_u_7, (ref) v_u_17, (copy) v_u_489, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (ref) v_u_314, (ref) v_u_6, (ref) v_u_11, (ref) v_u_299, (ref) v_u_326, (ref) v_u_102, (ref) v_u_349, (ref) v_u_186, (ref) v_u_359, (ref) v_u_270
					local v490 = v_u_7:item(v_u_14, 0, v_u_17)
					if v_u_489 == v_u_24 and (v_u_12 and v_u_13) then
						v_u_18 = v490
						if v490.ok then
							v_u_19 = nil
							v_u_23 = "ok"
							local v491 = v490.listings
							v_u_20 = type(v491) ~= "table" and {} or v490.listings
							v_u_21 = v490.total or #v_u_20
							v_u_22 = v490.more == true
							v_u_25 = 0
							v_u_314(v490)
							local v492 = v_u_6.historyRetry(v490, v_u_11.histTries)
							local v493 = v_u_299
							local v494
							if v490.histPending == true then
								v494 = v492 == nil
							else
								v494 = false
							end
							v493(v490, v494)
							v_u_326(v490)
							if v_u_23 == "ok" then
								v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
							else
								v_u_102.Text = ""
							end
							v_u_349()
							if v_u_186 and v_u_186.isOpen() then
								v_u_186.refresh()
							end
							if v492 ~= nil then
								v_u_11.histTries = (v_u_11.histTries or 0) + 1
								task.delay(v492, function()
									-- upvalues: (ref) v_u_489, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
									if v_u_489 == v_u_24 and (v_u_12 and v_u_13) then
										v_u_359(true, true)
									end
								end)
								return
							end
						elseif v490.code == "BUSY" then
							v_u_25 = v_u_25 + 1
							v_u_23 = "busy"
							v_u_314(nil)
							v_u_270()
							v_u_349()
							if v_u_25 < v_u_6.RETRY_MAX then
								local v495 = v_u_6.retryDelay(v490.retryIn, v_u_25, 0.9 + math.random() * 0.2)
								task.delay(v495, function()
									-- upvalues: (ref) v_u_489, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
									if v_u_489 == v_u_24 and (v_u_12 and v_u_13) then
										v_u_359(true)
									end
								end)
								return
							end
						else
							if v490.ds == "down" or v490.code == "STORE" then
								v_u_23 = "down"
								v_u_314(nil)
								v_u_270()
								v_u_349()
								return
							end
							v_u_23 = "error"
							v_u_314(nil)
							v_u_270()
							v_u_349()
						end
					end
				end)
				if v_u_3.device() == "Gamepad" then
					task.defer(function()
						-- upvalues: (ref) v_u_13, (ref) v_u_45
						if v_u_13 and v_u_45.Parent then
							game:GetService("GuiService").SelectedObject = v_u_45
						end
					end)
				end
			end
		end
		function v_u_11.close(p496) -- name: close
			-- upvalues: (ref) v_u_13, (ref) v_u_24, (copy) v_u_40, (copy) p_u_1, (ref) v_u_90, (ref) v_u_30, (ref) v_u_186, (copy) v_u_26, (copy) v_u_114, (ref) v_u_144, (ref) v_u_141, (copy) v_u_3, (copy) v_u_4
			if v_u_13 then
				v_u_13 = false
				v_u_24 = v_u_24 + 1
				v_u_40.Visible = false
				p_u_1.body.Visible = true
				p_u_1.setSubRowVisible(true)
				p_u_1.subHost.Visible = true
				p_u_1.page:SetAttribute("MarketItem", nil)
				if v_u_90 then
					local v497 = v_u_90.setItem
					pcall(v497, nil)
				end
				if v_u_30 then
					local v498 = v_u_30.close
					pcall(v498)
				end
				if v_u_186 then
					v_u_186.close()
				end
				for _, v499 in v_u_26 do
					v499()
				end
				table.clear(v_u_26)
				v_u_114()
				if v_u_144 then
					v_u_144.hide()
				end
				if v_u_141 then
					v_u_141.hide()
				end
				if not p496 then
					v_u_3.sound(v_u_4.sounds.close)
				end
			end
		end
		function v_u_11.reload(p500, p501) -- name: reload
			-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_29, (ref) v_u_542, (ref) v_u_23, (ref) v_u_24, (copy) v_u_7, (ref) v_u_349, (ref) v_u_17, (ref) v_u_12, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (copy) v_u_314, (copy) v_u_6, (copy) v_u_11, (copy) v_u_299, (copy) v_u_326, (ref) v_u_102, (ref) v_u_186, (copy) v_u_359, (copy) v_u_270, (ref) v_u_144
			if v_u_13 and v_u_14 then
				if p500 == true then
					local v502 = os.clock()
					if v502 - v_u_29 < v_u_542.REFRESH_GAP and v_u_23 == "ok" then
						return
					end
					v_u_29 = v502
				end
				v_u_24 = v_u_24 + 1
				local v_u_503 = v_u_24
				v_u_7:invalidate("item/" .. v_u_14)
				if not p501 or v_u_23 ~= "ok" then
					v_u_23 = "loading"
					v_u_349()
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_14, (ref) v_u_7, (ref) v_u_17, (copy) v_u_503, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_18, (ref) v_u_19, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (ref) v_u_314, (ref) v_u_6, (ref) v_u_11, (ref) v_u_299, (ref) v_u_326, (ref) v_u_102, (ref) v_u_349, (ref) v_u_186, (ref) v_u_359, (ref) v_u_270
					local v504 = v_u_7:item(v_u_14, 0, v_u_17)
					if v_u_503 == v_u_24 and (v_u_12 and v_u_13) then
						v_u_18 = v504
						if v504.ok then
							v_u_19 = nil
							v_u_23 = "ok"
							local v505 = v504.listings
							v_u_20 = type(v505) ~= "table" and {} or v504.listings
							v_u_21 = v504.total or #v_u_20
							v_u_22 = v504.more == true
							v_u_25 = 0
							v_u_314(v504)
							local v506 = v_u_6.historyRetry(v504, v_u_11.histTries)
							local v507 = v_u_299
							local v508
							if v504.histPending == true then
								v508 = v506 == nil
							else
								v508 = false
							end
							v507(v504, v508)
							v_u_326(v504)
							if v_u_23 == "ok" then
								v_u_102.Text = ("%s listed"):format(v_u_6.commas(v_u_21))
							else
								v_u_102.Text = ""
							end
							v_u_349()
							if v_u_186 and v_u_186.isOpen() then
								v_u_186.refresh()
							end
							if v506 ~= nil then
								v_u_11.histTries = (v_u_11.histTries or 0) + 1
								task.delay(v506, function()
									-- upvalues: (ref) v_u_503, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
									if v_u_503 == v_u_24 and (v_u_12 and v_u_13) then
										v_u_359(true, true)
									end
								end)
								return
							end
						elseif v504.code == "BUSY" then
							v_u_25 = v_u_25 + 1
							v_u_23 = "busy"
							v_u_314(nil)
							v_u_270()
							v_u_349()
							if v_u_25 < v_u_6.RETRY_MAX then
								local v509 = v_u_6.retryDelay(v504.retryIn, v_u_25, 0.9 + math.random() * 0.2)
								task.delay(v509, function()
									-- upvalues: (ref) v_u_503, (ref) v_u_24, (ref) v_u_12, (ref) v_u_13, (ref) v_u_359
									if v_u_503 == v_u_24 and (v_u_12 and v_u_13) then
										v_u_359(true)
									end
								end)
								return
							end
						else
							if v504.ds == "down" or v504.code == "STORE" then
								v_u_23 = "down"
								v_u_314(nil)
								v_u_270()
								v_u_349()
								return
							end
							v_u_23 = "error"
							v_u_314(nil)
							v_u_270()
							v_u_349()
						end
					end
				end)
				if p500 == true and (v_u_144 and v_u_144.isShown()) then
					v_u_144.reload(true, p501)
				end
			end
		end
		function v_u_11.refresh(_, _) -- name: refresh
			-- upvalues: (ref) v_u_13, (copy) v_u_28, (copy) v_u_232, (copy) v_u_218, (copy) v_u_127, (ref) v_u_129, (ref) v_u_141
			if v_u_13 then
				for _, v510 in v_u_28 do
					v_u_232(v510)
				end
				v_u_218()
				v_u_127()
				if v_u_129 then
					v_u_129()
				end
				if v_u_141 then
					v_u_141.refresh()
				end
			end
		end
		function v_u_11.onNote(p511) -- name: onNote
			-- upvalues: (ref) v_u_13, (ref) v_u_23, (ref) v_u_30, (copy) v_u_11, (ref) v_u_144, (ref) v_u_141
			if v_u_13 and (v_u_23 == "ok" and not v_u_30) then
				v_u_11.reload(false)
			end
			if v_u_13 and v_u_144 then
				v_u_144.onNote(p511)
				if v_u_141 then
					v_u_141.onNote(p511)
				end
			end
		end
		function v_u_11.rows() -- name: rows
			-- upvalues: (copy) v_u_28
			local v512 = {}
			for _, v513 in v_u_28 do
				local v514 = {
					["lid"] = v513.l.lid,
					["own"] = v513.l.own == true,
					["buy"] = v513.frame:GetAttribute("Buy"),
					["reason"] = v513.frame:GetAttribute("Reason"),
					["n"] = v513.l.n,
					["p"] = v513.l.p,
					["frame"] = v513.frame
				}
				local v515
				if v513.buy then
					v515 = v513.buy.btn
				else
					v515 = nil
				end
				v514.btn = v515
				table.insert(v512, v514)
			end
			return v512
		end
		function v_u_11.status() -- name: status
			-- upvalues: (ref) v_u_23
			return v_u_23
		end
		function v_u_11.buy(p516) -- name: buy
			-- upvalues: (copy) v_u_28, (ref) v_u_482
			for _, v517 in v_u_28 do
				if v517.l.lid ~= p516 then
					continue
				end
				v_u_482(v517.l)
			end
		end
		function v_u_11.panel() -- name: panel
			-- upvalues: (ref) v_u_30
			return v_u_30
		end
		function v_u_11.openBest() -- name: openBest
			-- upvalues: (copy) v_u_203
			v_u_203()
		end
		function v_u_11.best() -- name: best
			-- upvalues: (ref) v_u_186
			return v_u_186
		end
		function v_u_11.bestBar() -- name: bestBar
			-- upvalues: (copy) v_u_187
			return v_u_187
		end
		function v_u_11.pressBest(p518) -- name: pressBest
			-- upvalues: (ref) v_u_186, (copy) v_u_6
			if v_u_186 == nil then
				return false
			end
			local v519 = {
				["buy"] = nil,
				["cancel"] = "Cancel",
				["close"] = "Close",
				["change"] = nil,
				["buy"] = v_u_6.TEXT.bestBuy,
				["change"] = v_u_6.TEXT.bestChange
			}
			return v_u_186.press(v519[p518 or "buy"] or tostring(p518))
		end
		function v_u_11.setBestLimit(p520) -- name: setBestLimit
			-- upvalues: (ref) v_u_186
			if v_u_186 and v_u_186.setLimit then
				v_u_186.setLimit(p520)
			end
		end
		function v_u_11.bestLimit() -- name: bestLimit
			-- upvalues: (ref) v_u_186
			return not (v_u_186 and v_u_186.getLimit) and 0 or v_u_186.getLimit()
		end
		function v_u_11.pressPanel(p521) -- name: pressPanel
			-- upvalues: (copy) v_u_11
			local v522
			if v_u_11.panelButtons then
				v522 = v_u_11.panelButtons[p521]
			else
				v522 = nil
			end
			if not v522 then
				return false
			end
			task.spawn(v522)
			return true
		end
		function v_u_11.more() -- name: more
			-- upvalues: (ref) v_u_22, (ref) v_u_23, (ref) v_u_343
			if v_u_22 and v_u_23 == "ok" then
				v_u_343()
			end
		end
		function v_u_11.setGood(p523) -- name: setGood
			-- upvalues: (ref) v_u_17, (copy) v_u_111, (copy) v_u_11
			local v524 = (p523 == true or p523 == "true") and true or p523 == 1
			if v_u_17 ~= v524 then
				v_u_17 = v524
				v_u_111()
				v_u_11.reload(false)
			end
		end
		function v_u_11.seg() -- name: seg
			-- upvalues: (ref) v_u_139
			return v_u_139
		end
		function v_u_11.setSeg(p525) -- name: setSeg
			-- upvalues: (ref) v_u_136, (ref) v_u_142
			if v_u_136 and (p525 == "listings" or (p525 == "book" or p525 == "order")) then
				v_u_142(p525)
			end
		end
		function v_u_11.book() -- name: book
			-- upvalues: (ref) v_u_144
			return v_u_144
		end
		function v_u_11.order() -- name: order
			-- upvalues: (ref) v_u_141
			return v_u_141
		end
		function v_u_11.state() -- name: state
			-- upvalues: (ref) v_u_14, (ref) v_u_35, (ref) v_u_36, (ref) v_u_38, (ref) v_u_23, (ref) v_u_17, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_25, (copy) v_u_40, (ref) v_u_51, (ref) v_u_52, (ref) v_u_54
			return {
				["id"] = v_u_14,
				["case"] = v_u_35,
				["crate"] = v_u_36,
				["crateFor"] = v_u_38,
				["status"] = v_u_23,
				["good"] = v_u_17,
				["listings"] = #v_u_20,
				["total"] = v_u_21,
				["more"] = v_u_22,
				["attempts"] = v_u_25,
				["root"] = v_u_40,
				["left"] = v_u_51,
				["right"] = v_u_52,
				["list"] = v_u_54
			}
		end
		local v527 = {
			["Disconnect"] = p_u_1.onTick(function()
				-- upvalues: (ref) v_u_13, (copy) v_u_28, (copy) v_u_232, (copy) v_u_218, (copy) v_u_326, (ref) v_u_18, (ref) v_u_129
				if v_u_13 then
					for _, v526 in v_u_28 do
						v_u_232(v526)
					end
					v_u_218()
					v_u_326(v_u_18)
					if v_u_129 then
						v_u_129()
					end
				end
			end)
		}
		table.insert(v_u_27, v527)
		local v529 = {
			["Disconnect"] = p_u_1.onState(function()
				-- upvalues: (ref) v_u_13, (copy) v_u_28, (copy) v_u_232, (copy) v_u_218, (copy) v_u_127, (ref) v_u_129
				if v_u_13 then
					for _, v528 in v_u_28 do
						v_u_232(v528)
					end
					v_u_218()
					v_u_127()
					if v_u_129 then
						v_u_129()
					end
				end
			end)
		}
		table.insert(v_u_27, v529)
		local v530, v531 = pcall(function()
			-- upvalues: (copy) p_u_1
			return p_u_1.mc.cctx.lib.VirtualPad
		end)
		if v530 and v531 then
			local v532 = v531.InputBegan
			local function v537(p533)
				-- upvalues: (ref) v_u_13, (ref) v_u_12, (copy) p_u_1, (copy) v_u_40, (copy) v_u_28, (ref) v_u_482
				if v_u_13 and (v_u_12 and (p533.KeyCode == Enum.KeyCode.ButtonX and not p_u_1.modalOpen())) then
					local v534 = game:GetService("GuiService").SelectedObject
					while v534 and v534 ~= v_u_40 do
						if v534:GetAttribute("ItemRow") then
							local v535 = v534:GetAttribute("Lid")
							for _, v536 in v_u_28 do
								if v536.l.lid ~= v535 or v536.l.own then
									continue
								end
								v_u_482(v536.l)
							end
							return
						end
						v534 = v534.Parent
					end
				end
			end
			table.insert(v_u_27, v532:Connect(v537))
		end
		function v_u_11.destroy() -- name: destroy
			-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) v_u_26, (copy) v_u_27, (ref) v_u_30, (ref) v_u_186, (ref) v_u_144, (ref) v_u_141, (ref) v_u_90, (copy) v_u_40
			v_u_12 = false
			v_u_13 = false
			for _, v538 in v_u_26 do
				v538()
			end
			for _, v_u_539 in v_u_27 do
				pcall(function()
					-- upvalues: (copy) v_u_539
					v_u_539:Disconnect()
				end)
			end
			if v_u_30 then
				local v540 = v_u_30.close
				pcall(v540)
			end
			if v_u_186 then
				v_u_186.close()
			end
			if v_u_144 then
				v_u_144.destroy()
			end
			if v_u_141 then
				v_u_141.destroy()
			end
			if v_u_90 then
				local v541 = v_u_90.destroy
				pcall(v541)
			end
			v_u_40:Destroy()
		end
		v_u_111()
		return v_u_11
	end
}
return v_u_542