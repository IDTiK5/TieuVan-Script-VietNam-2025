-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadsHint

local v_u_41 = {
	["TEXT"] = {
		["pvp"] = {
			["full"] = "Your friend is in the other lobby? Open INVITE, find them under FRIENDS IN OTHER LOBBIES and tap JOIN. The Roblox Join button does not work in PVP.",
			["short"] = "Friend in the PVE lobby? Tap INVITE, then JOIN."
		},
		["pve"] = {
			["full"] = "Your friend is in the other lobby? Open INVITE, find them under FRIENDS IN OTHER LOBBIES and tap JOIN. A whole squad travels when its leader taps TRAVEL.",
			["short"] = "Friend in the PVP lobby? Tap INVITE, then JOIN."
		}
	},
	["SIZE_FULL"] = 13,
	["SIZE_SHORT"] = 12,
	["CHAR"] = 0.62,
	["PAD_X"] = 10,
	["PAD_Y"] = 6,
	["BAR"] = 3,
	["MAX_LINES"] = 2,
	["COMPACT_REF_Y"] = 520,
	["textW"] = function(p1, p2) -- name: textW
		-- upvalues: (copy) v_u_41
		local v3 = (utf8.len(p1) or #p1) * p2 * v_u_41.CHAR + 2
		return math.ceil(v3)
	end,
	["wrap"] = function(p4, p5, p6) -- name: wrap
		-- upvalues: (copy) v_u_41
		if p6 <= 0 then
			return 99
		end
		local v7 = p5 * v_u_41.CHAR
		local v8 = math.ceil(v7)
		local v9 = 0
		local v10 = 1
		for v11 in string.gmatch(p4, "%S+") do
			local v12 = v_u_41.textW(v11, p5) - 2
			if v9 == 0 then
				v9 = v12
			elseif v9 + v8 + v12 <= p6 then
				v9 = v9 + (v8 + v12)
			else
				v10 = v10 + 1
				v9 = v12
			end
			if p6 >= v12 then
				continue
			end
			local v13 = v12 / p6
			v10 = v10 + (math.ceil(v13) - 1)
			v9 = v12 % p6
		end
		return v10
	end,
	["kind"] = function(p14) -- name: kind
		local v15 = type(p14) ~= "table" and {} or p14
		return v15.pvp == true and "pvp" or (v15.door == true and "pve" or nil)
	end,
	["text"] = function(p16, p17) -- name: text
		-- upvalues: (copy) v_u_41
		local v18 = v_u_41.TEXT[p16 == "pve" and "pve" or "pvp"]
		if p17 == true then
			return v18.short
		else
			return v18.full
		end
	end,
	["layout"] = function(p19, p20) -- name: layout
		-- upvalues: (copy) v_u_41
		local v21 = type(p20) ~= "table" and {} or p20
		local v22 = v21.kind
		if v22 ~= "pvp" and v22 ~= "pve" then
			return {
				["mode"] = "none",
				["kind"] = nil,
				["text"] = "",
				["size"] = nil,
				["lines"] = 0,
				["lineH"] = 0,
				["h"] = 0,
				["strip"] = nil,
				["bar"] = nil,
				["label"] = nil,
				["padX"] = nil,
				["fits"] = true,
				["kind"] = v22,
				["size"] = v_u_41.SIZE_SHORT,
				["strip"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = 0,
					["w"] = p19
				},
				["bar"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0
				},
				["label"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = 0,
					["h"] = 0
				},
				["padX"] = v_u_41.PAD_X
			}
		end
		local v23 = v21.refY
		local v24 = (tonumber(v23) or 1080) < v_u_41.COMPACT_REF_Y
		local v25 = p19 - v_u_41.BAR - 2 * v_u_41.PAD_X
		for _, v26 in v24 and { "short" } or { "full", "short" } do
			local v27 = v26 == "short"
			local v28 = v21.sizes
			local v29 = (type(v28) ~= "table" and {} or v21.sizes)[v26]
			local v30 = tonumber(v29)
			if not v30 then
				if v27 then
					v30 = v_u_41.SIZE_SHORT
				else
					v30 = v_u_41.SIZE_FULL
				end
			end
			local v31 = v_u_41.text(v22, v27)
			local v32 = v_u_41.wrap(v31, v30, v25)
			if v32 > v_u_41.MAX_LINES then
				continue
			end
			local v33 = v30 * 1.3
			local v34 = math.ceil(v33)
			local v35 = 2 * v_u_41.PAD_Y + v32 * v34
			return {
				["mode"] = nil,
				["kind"] = nil,
				["text"] = nil,
				["size"] = nil,
				["lines"] = nil,
				["lineH"] = nil,
				["h"] = nil,
				["strip"] = nil,
				["bar"] = nil,
				["label"] = nil,
				["padX"] = nil,
				["fits"] = true,
				["mode"] = v26,
				["kind"] = v22,
				["text"] = v31,
				["size"] = v30,
				["lines"] = v32,
				["lineH"] = v34,
				["h"] = v35,
				["strip"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = p19,
					["h"] = v35
				},
				["bar"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v_u_41.BAR,
					["h"] = v35
				},
				["label"] = {
					["x"] = v_u_41.BAR + v_u_41.PAD_X,
					["y"] = v_u_41.PAD_Y,
					["w"] = v25,
					["h"] = v32 * v34
				},
				["padX"] = v_u_41.PAD_X
			}
		end
		return {
			["mode"] = "none",
			["kind"] = nil,
			["text"] = "",
			["size"] = nil,
			["lines"] = 0,
			["lineH"] = 0,
			["h"] = 0,
			["strip"] = nil,
			["bar"] = nil,
			["label"] = nil,
			["padX"] = nil,
			["fits"] = true,
			["kind"] = v22,
			["size"] = v_u_41.SIZE_SHORT,
			["strip"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = 0,
				["w"] = p19
			},
			["bar"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 0,
				["h"] = 0
			},
			["label"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 0,
				["h"] = 0
			},
			["padX"] = v_u_41.PAD_X
		}
	end,
	["emptyText"] = function(p36) -- name: emptyText
		local v37 = type(p36) ~= "table" and {} or p36
		if v37.loaded ~= true then
			return "Loading"
		end
		local v38 = v37.filters
		local v39 = type(v38) ~= "table" and {} or v37.filters
		local v40 = v37.pvp == true
		return v39.friends == true and (v40 and "None of your friends has an open squad in PVP right now. A friend has to travel to PVP first. Turn the Friends filter off to see everybody." or "None of your friends has an open squad right now. Turn the Friends filter off to see everybody, or ask a friend to open a squad as FRIENDS or PUBLIC.") or ((v39.diff == nil or v39.diff == "Any") and (v39.voice ~= true and v39.region ~= true) and (v40 and "No open squads in PVP right now. Open yours as FRIENDS or PUBLIC, then ask your friends to travel to PVP and open SQUADS: they find you here." or "No open squads right now. A friend who opens a squad as FRIENDS or PUBLIC shows up here with a FRIEND tag. Open yours as FRIENDS or PUBLIC so they find you.") or "No squad matches these filters. Turn a filter off, or open your squad as PUBLIC so others find you.")
	end
}
return v_u_41