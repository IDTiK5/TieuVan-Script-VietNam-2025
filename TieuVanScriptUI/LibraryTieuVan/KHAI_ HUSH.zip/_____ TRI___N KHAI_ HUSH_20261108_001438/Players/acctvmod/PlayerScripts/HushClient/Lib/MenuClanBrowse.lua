-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanBrowse

game:GetService("Players")
local v_u_1 = {
	["STALE_SEC"] = 60,
	["FRESH_SEC"] = 5,
	["SPIN_SEC"] = 1.6,
	["LOAD_STUCK_SEC"] = 30,
	["CAPTION_EM"] = 0.6,
	["ROW_TEXT_MARGIN"] = 16,
	["WORDS"] = {
		["DECLINING"] = "Declining"
	}
}
local v_u_2 = {
	["join"] = "JOINING",
	["request"] = "SENDING",
	["cancel"] = "WITHDRAWING"
}
local v_u_3 = {
	["join"] = "Joining",
	["request"] = "Sending",
	["cancel"] = "Withdrawing"
}
local v_u_4 = {
	["join"] = 17,
	["request"] = 17,
	["cancel"] = 15,
	["decline"] = 15
}
local v_u_5 = {
	["join"] = "Join",
	["request"] = "Send",
	["cancel"] = "Cancel",
	["decline"] = "Decline"
}
function v_u_1.updatedText(p6) -- name: updatedText
	-- upvalues: (copy) v_u_1
	if type(p6) ~= "number" or (p6 ~= p6 or (p6 == (1 / 0) or p6 == (-1 / 0))) then
		return ""
	end
	local v7 = math.clamp(p6, 0, 31536000)
	local v8 = math.floor(v7)
	if v8 < v_u_1.FRESH_SEC then
		return "Updated just now"
	end
	if v8 < 60 then
		return ("Updated %ds ago"):format(v8)
	end
	local v9 = v8 / 60
	return ("Updated %dm ago"):format((math.floor(v9)))
end
function v_u_1.refreshState(p10, _, p11) -- name: refreshState
	return p10 == true and p11 ~= true and "busy" or "idle"
end
function v_u_1.loadStuck(p12, p13) -- name: loadStuck
	-- upvalues: (copy) v_u_1
	if type(p12) == "number" and (type(p13) == "number" and (p12 == p12 and p13 == p13)) then
		return p13 - p12 > v_u_1.LOAD_STUCK_SEC
	else
		return false
	end
end
function v_u_1.needsReload(p14, p15) -- name: needsReload
	-- upvalues: (copy) v_u_1
	if p14 == true then
		return (type(p15) ~= "number" or p15 ~= p15) and true or v_u_1.STALE_SEC < p15
	else
		return false
	end
end
function v_u_1.refreshWord(p16, p17) -- name: refreshWord
	local v18 = type(p17) ~= "table" and {} or p17
	if p16 == "busy" then
		local v19 = v18.REFRESHING
		local v20 = type(v19) ~= "string" and "" or v19
		local v21 = string.gsub(v20, "[%.%s]+$", "")
		return string.upper(v21 == "" and "Refreshing" or v21)
	else
		local v22 = v18.REFRESH
		local v23 = type(v22) ~= "string" and "" or v22
		local v24 = string.gsub(v23, "[%.%s]+$", "")
		return v24 == "" and "REFRESH" or v24
	end
end
function v_u_1.actWord(p25, p26) -- name: actWord
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
	if p25 == "decline" then
		return v_u_1.WORDS.DECLINING
	elseif type(p25) == "string" and v_u_2[p25] ~= nil then
		local v27 = (type(p26) ~= "table" and {} or p26)[v_u_2[p25]]
		local v28 = type(v27) ~= "string" and "" or v27
		local v29 = string.gsub(v28, "[%.%s]+$", "")
		if v29 == "" then
			return v_u_3[p25]
		else
			return v29
		end
	else
		return nil
	end
end
function v_u_1.captionWidth(p30, p31) -- name: captionWidth
	-- upvalues: (copy) v_u_1
	local v32 = type(p30) ~= "string" and "" or p30
	local v33 = (type(p31) ~= "number" or (p31 ~= p31 or p31 <= 0)) and 17 or p31
	return #v32 * v33 * v_u_1.CAPTION_EM
end
function v_u_1.busyCaption(p34, p35, p36) -- name: busyCaption
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_5
	local v37 = v_u_1.actWord(p34, p35)
	if v37 == nil then
		return nil
	end
	if type(p36) ~= "number" or p36 ~= p36 then
		return v37
	end
	local v38 = v_u_4[p34] or 15
	for _, v39 in { v37, v_u_5[p34] } do
		if type(v39) ~= "string" or v_u_1.captionWidth(v39 .. "...", v38) > p36 then
			continue
		end
		return v39
	end
	return "..."
end
function v_u_1.refreshLayout(p40, p41) -- name: refreshLayout
	local v42 = 44
	if p40 then
		p40 = p40.rowH
	end
	local v43 = tonumber(p40) or 44
	local v44 = math.max(v42, v43)
	local v45 = tonumber(p41) or 0
	local v46 = v45 - 44 - 150 - 10
	local v47 = math.min(160, v46)
	local v48 = math.max(0, v47)
	local v49 = {
		["h"] = nil,
		["glyphX"] = 14,
		["glyphSize"] = 20,
		["glyphY"] = nil,
		["wordX"] = 44,
		["wordW"] = 150,
		["updX"] = nil,
		["updW"] = nil,
		["showUpd"] = nil,
		["h"] = v44
	}
	local v50 = (v44 - 20) / 2
	v49.glyphY = math.floor(v50)
	v49.updX = v45 - 10 - v48
	v49.updW = v48
	v49.showUpd = v48 >= 90
	return v49
end
function v_u_1.rowLayout(p51, p52) -- name: rowLayout
	local v53 = p51.kind == "wide" and 120 or (p51.kind == "mid" and 112 or 104)
	local v54 = p52 - 80 - v53 - 14
	return {
		["tagX"] = 8,
		["tagW"] = 64,
		["textX"] = 80,
		["textW"] = nil,
		["btnW"] = nil,
		["btnX"] = nil,
		["textW"] = math.max(60, v54),
		["btnW"] = v53,
		["btnX"] = p52 - v53 - 6
	}
end
function v_u_1.browse(p_u_55, p56) -- name: browse
	-- upvalues: (copy) v_u_1
	local v_u_57 = p_u_55.UI
	local v58 = p_u_55.Theme
	local v_u_59 = p_u_55.C
	local v_u_60 = p_u_55.Kit
	local v_u_61 = p_u_55.U
	local v_u_62 = p_u_55.M
	local v_u_63 = p_u_55.m
	local v_u_64 = {}
	local v_u_65 = true
	local v_u_66 = false
	local v_u_67 = ""
	local v_u_68 = "members"
	local v_u_69 = {
		["open"] = false,
		["request"] = false
	}
	local v_u_70 = {}
	local v_u_71 = 1
	local v_u_72 = 1
	local v_u_73 = 0
	local v_u_74 = false
	local v_u_75 = "loading"
	local v_u_76 = 0
	local v_u_77 = false
	local v_u_78 = false
	local v_u_79 = nil
	local v_u_80 = false
	local v_u_81 = 0
	local v_u_82 = {}
	local v_u_83 = {}
	local v_u_84 = {}
	local v_u_85 = nil
	local v_u_86 = nil
	local v_u_87 = nil
	local v_u_88 = nil
	local v_u_89 = nil
	local v_u_90 = nil
	local v_u_91 = nil
	local v_u_92 = nil
	local v_u_93 = nil
	local v_u_94 = nil
	local v_u_95 = nil
	local v_u_96 = nil
	local v_u_97 = ""
	local v_u_98 = -1000000000
	local function v_u_103() -- name: now
		-- upvalues: (copy) p_u_55
		local v99 = p_u_55.clock
		if type(v99) == "function" then
			local v100 = p_u_55.clock
			local v101, v102 = pcall(v100)
			if v101 and type(v102) == "number" then
				return v102
			end
		end
		return os.clock()
	end
	local v104 = v58.touch(44)
	local v_u_105 = v_u_61.frame(p56, "Controls", UDim2.new(1, 0, 0, v104))
	local v_u_106 = v_u_63.chipW or (v_u_63.kind == "phone" and 76 or 96)
	local v_u_107 = v_u_63.chipText
	local v108 = v_u_63.kind == "phone" and 200 or 250
	local v109 = v_u_63.inner - v108 - 2 * v_u_106 - 3 * v_u_63.gap
	local _, _ = v_u_57.input({
		["parent"] = nil,
		["name"] = "Search",
		["placeholder"] = "Search tag or name",
		["maxLength"] = nil,
		["size"] = nil,
		["onChange"] = nil,
		["onSubmit"] = nil,
		["parent"] = v_u_105,
		["maxLength"] = v_u_62.SEARCH_MAX,
		["size"] = UDim2.fromOffset(v109, v104),
		["onChange"] = function(p110) -- name: onChange
			-- upvalues: (ref) v_u_67, (ref) v_u_81, (ref) v_u_65, (copy) v_u_64
			v_u_67 = p110
			v_u_81 = v_u_81 + 1
			local v_u_111 = v_u_81
			task.delay(0.45, function()
				-- upvalues: (ref) v_u_65, (copy) v_u_111, (ref) v_u_81, (ref) v_u_64
				if v_u_65 and v_u_111 == v_u_81 then
					v_u_64.load(true)
				end
			end)
		end,
		["onSubmit"] = function(p112) -- name: onSubmit
			-- upvalues: (ref) v_u_67, (ref) v_u_81, (copy) v_u_64
			v_u_67 = p112
			v_u_81 = v_u_81 + 1
			v_u_64.load(true)
		end
	})
	local v113 = v108 / 0.55
	local v114 = math.floor(v113)
	local v116, _ = v_u_57.dropdown({
		["parent"] = nil,
		["name"] = "Sort",
		["label"] = "",
		["options"] = nil,
		["value"] = nil,
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_105,
		["options"] = v_u_62.SORTS,
		["value"] = v_u_68,
		["width"] = v114,
		["onChange"] = function(p115) -- name: onChange
			-- upvalues: (ref) v_u_68, (copy) v_u_64
			v_u_68 = p115
			v_u_64.load(true)
		end
	})
	local v117 = UDim2.fromOffset
	local v118 = v109 + v_u_63.gap
	local v119 = v114 * 0.55
	v116.Position = v117(v118 - (v114 - math.floor(v119)), 0)
	local v_u_120 = {}
	local function v126(p_u_121, p122, p123) -- name: chipBtn
		-- upvalues: (copy) v_u_61, (copy) v_u_105, (copy) v_u_106, (copy) v_u_107, (copy) v_u_69, (copy) v_u_64, (copy) v_u_120
		local v_u_124 = nil
		local _, v125 = v_u_61.btn({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["width"] = nil,
			["maxTextWidth"] = nil,
			["name"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v_u_105,
			["text"] = p122,
			["width"] = v_u_106,
			["maxTextWidth"] = v_u_107,
			["name"] = "Chip_" .. p_u_121,
			["position"] = UDim2.fromOffset(p123, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_69, (copy) p_u_121, (ref) v_u_124, (ref) v_u_64
				v_u_69[p_u_121] = not v_u_69[p_u_121]
				v_u_124.setKind(v_u_69[p_u_121] and "primary" or "secondary")
				v_u_64.load(true)
			end
		})
		v_u_124 = v125
		v_u_120[p_u_121] = v_u_124
	end
	v126("open", "OPEN", v109 + v108 + 2 * v_u_63.gap)
	v126("request", "REQUEST", v109 + v108 + 3 * v_u_63.gap + v_u_106)
	local v_u_127 = v_u_61.status(p56, {
		["name"] = "Msg",
		["text"] = "",
		["style"] = "small",
		["size"] = nil,
		["position"] = nil,
		["visible"] = false,
		["size"] = UDim2.new(1, 0, 0, 20),
		["position"] = UDim2.fromOffset(0, v104 + 4)
	})
	local v128 = v104 + 28
	local v_u_129
	if v_u_63.twoCol then
		v_u_129 = v_u_63.listW
	else
		v_u_129 = v_u_63.inner
	end
	local v_u_130 = v_u_61.frame(p56, "ListHolder", UDim2.new(0, v_u_129, 1, -v128), UDim2.fromOffset(0, v128))
	local v_u_131 = v_u_57.list({
		["parent"] = nil,
		["name"] = "List",
		["size"] = nil,
		["gap"] = 2,
		["padding"] = nil,
		["parent"] = v_u_130,
		["size"] = UDim2.fromScale(1, 1),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local v132 = v_u_61.frame
	local v133 = "DetailHolder"
	local v134 = UDim2.new
	local v135 = 0
	local v136
	if v_u_63.twoCol then
		v136 = v_u_63.detailW
	else
		v136 = v_u_63.inner
	end
	local v_u_137 = v132(p56, v133, v134(v135, v136, 1, -v128), UDim2.fromOffset(not v_u_63.twoCol and 0 or v_u_129 + v_u_63.colGap, v128))
	v_u_137.Visible = v_u_63.twoCol
	local function v_u_145(p138, p139, p140, p141) -- name: registerAct
		-- upvalues: (copy) v_u_84, (copy) v_u_83, (ref) v_u_1, (copy) v_u_62
		if v_u_84[p138] == nil then
			v_u_84[p138] = {}
		end
		local v142 = {
			["api"] = p139,
			["room"] = p140
		}
		local v143 = v_u_84[p138]
		table.insert(v143, v142)
		if v_u_83[p138] ~= nil and (p141 == "join" or (p141 == "request" or p141 == "cancel")) then
			local v144 = v_u_83[p138]
			v142.api.busy(true, v_u_1.busyCaption(v144, v_u_62.UI, v142.room) or "...")
		end
	end
	local function v_u_164(p_u_146, p_u_147) -- name: act
		-- upvalues: (copy) v_u_83, (copy) v_u_84, (ref) v_u_1, (copy) v_u_62, (ref) v_u_127, (copy) p_u_55, (ref) v_u_65, (copy) v_u_64
		if v_u_83[p_u_146.id] == nil then
			local v148, v149
			if p_u_147 == "join" then
				v148 = {
					["id"] = p_u_146.id
				}
				v149 = "clanJoin"
			elseif p_u_147 == "request" then
				v148 = {
					["id"] = p_u_146.id
				}
				v149 = "clanRequest"
			else
				if p_u_147 ~= "cancel" then
					return
				end
				v148 = {
					["id"] = nil,
					["cancel"] = true,
					["id"] = p_u_146.id
				}
				v149 = "clanRequest"
			end
			v_u_83[p_u_146.id] = p_u_147
			for _, v150 in v_u_84[p_u_146.id] or {} do
				v150.api.busy(true, v_u_1.busyCaption(p_u_147, v_u_62.UI, v150.room) or "...")
			end
			v_u_127.set("", nil)
			p_u_55.send(v149, v148, function(p151, p152, p153, p154)
				-- upvalues: (ref) v_u_83, (copy) p_u_146, (ref) v_u_65, (ref) v_u_84, (ref) p_u_55, (copy) p_u_147, (ref) v_u_127, (ref) v_u_64, (ref) v_u_62
				v_u_83[p_u_146.id] = nil
				if v_u_65 then
					for _, v155 in v_u_84[p_u_146.id] or {} do
						local v156 = v155.api.busy
						pcall(v156, false)
					end
				end
				if v_u_65 then
					if p151 then
						local v157 = p_u_55.state()
						if p_u_147 == "request" then
							local v158 = v157.myRequests
							v157.myRequests = type(v158) ~= "table" and {} or v157.myRequests
							local v159 = v157.myRequests
							local v160 = p_u_146.id
							table.insert(v159, v160)
							v_u_127.set("Request sent.", "success")
						elseif p_u_147 == "cancel" then
							local v161 = {}
							for _, v162 in v157.myRequests or {} do
								if v162 == p_u_146.id then
									continue
								end
								table.insert(v161, v162)
							end
							v157.myRequests = v161
							v_u_127.set("Request withdrawn.", "info")
						end
						v_u_64.draw()
					else
						local v163 = v_u_62.reasonFor(p154 or {
							["msg"] = p152,
							["data"] = p153
						})
						v_u_127.set(v163, "danger")
					end
				else
					return
				end
			end, 20)
		end
	end
	local function v_u_181(p165, p_u_166, p167, p168, p169, p170) -- name: actionButton
		-- upvalues: (copy) v_u_62, (copy) p_u_55, (ref) v_u_1, (copy) v_u_61, (copy) v_u_164, (copy) v_u_145, (copy) v_u_57
		local v_u_171 = v_u_62.rowAction(p_u_166, p_u_55.state())
		if v_u_171 == "none" then
			return nil
		end
		local v_u_172 = v_u_62.ROW_BUTTON[v_u_171] or v_u_171
		local v173 = (v_u_171 == "join" or v_u_171 == "request") and "primary" or (v_u_171 == "cancel" and "secondary" or "ghost")
		local v174 = p168 - v_u_1.ROW_TEXT_MARGIN
		local v175, v176 = v_u_61.btn({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["width"] = nil,
			["height"] = nil,
			["maxTextWidth"] = nil,
			["name"] = "Act",
			["position"] = nil,
			["disabled"] = nil,
			["onClick"] = nil,
			["parent"] = p165,
			["text"] = v_u_172,
			["kind"] = v173,
			["width"] = p168,
			["height"] = p169,
			["maxTextWidth"] = v174,
			["position"] = UDim2.fromOffset(p167, p170),
			["disabled"] = v_u_171 == "locked" and true or v_u_171 == "full",
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_164, (copy) p_u_166, (copy) v_u_171
				v_u_164(p_u_166, v_u_171)
			end
		})
		v_u_145(p_u_166.id, v176, v174, v_u_171)
		if v_u_171 == "locked" or v_u_171 == "full" then
			local v177 = p_u_55.profile()
			local v178, v179 = v_u_62.mineFromStats(v177.stats)
			local v_u_180
			if v_u_171 == "full" then
				v_u_180 = v_u_62.TEXT.FULL
			else
				v_u_180 = v_u_62.needText(p_u_166, v178, v179)
			end
			v_u_57.tooltip(v175, function()
				-- upvalues: (copy) v_u_172, (copy) v_u_180
				return {
					["title"] = v_u_172,
					["body"] = v_u_180
				}
			end)
		end
		return v176
	end
	local function v_u_216(p182, p_u_183) -- name: rowFor
		-- upvalues: (ref) v_u_1, (copy) v_u_63, (copy) v_u_129, (ref) v_u_79, (copy) v_u_57, (copy) v_u_59, (copy) v_u_131, (copy) v_u_61, (ref) v_u_80, (copy) v_u_64, (copy) v_u_62, (copy) p_u_55, (copy) v_u_181, (copy) v_u_82
		local v184 = v_u_1.rowLayout(v_u_63, v_u_129 - 6)
		local v185
		if p_u_183.id == v_u_79 then
			v185 = v_u_63.twoCol
		else
			v185 = false
		end
		local v186 = v_u_57.new
		local v187 = "TextButton"
		local v188 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["ClipsDescendants"] = true
		}
		local v189 = p_u_183.id
		v188.Name = "Clan_" .. tostring(v189)
		local v190
		if v185 then
			v190 = v_u_59.accentDeep
		else
			v190 = v_u_59.raised
		end
		v188.BackgroundColor3 = v190
		v188.BackgroundTransparency = v185 and 0.1 or (p182 % 2 == 0 and 0.5 or 0.3)
		v188.Size = UDim2.new(1, -6, 0, v_u_63.rowH)
		v188.LayoutOrder = p182
		local v191 = v186(v187, v188, v_u_131)
		v191.SelectionImageObject = v_u_57.selectionImage()
		v_u_61.press(v191, function()
			-- upvalues: (ref) v_u_79, (copy) p_u_183, (ref) v_u_63, (ref) v_u_80, (ref) v_u_64
			v_u_79 = p_u_183.id
			if v_u_63.kind == "phone" then
				v_u_80 = true
			end
			v_u_64.draw()
		end)
		local v192 = v_u_61.frame
		local v193 = UDim2.fromOffset(v184.tagW, 20)
		local v194 = UDim2.fromOffset
		local v195 = v184.tagX
		local v196 = (v_u_63.rowH - 20) / 2
		local v197 = v192(v191, "TagHost", v193, v194(v195, (math.floor(v196))))
		v_u_61.tagChip(v197, p_u_183.tag, p_u_183.id, {
			["height"] = 20,
			["tagStyle"] = nil,
			["tagStyle"] = v_u_61.dirStyle(p_u_183.tc)
		})
		local v198 = v_u_57.label
		local v199 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "bodyStrong",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v191
		}
		local v200 = p_u_183.name or "?"
		v199.text = tostring(v200)
		v199.position = UDim2.fromOffset(v184.textX, 3)
		v199.size = UDim2.fromOffset(v184.textW, 22)
		v198(v199)
		local v201 = v_u_62.rowAction(p_u_183, p_u_55.state())
		local v202 = p_u_55.profile()
		local v203, v204 = v_u_62.mineFromStats(v202.stats)
		local v205 = v_u_59.text2
		local v206
		if v201 == "locked" then
			v206 = v_u_62.needText(p_u_183, v203, v204)
			v205 = v_u_59.danger
		else
			local v207 = p_u_183.count
			local v208 = tonumber(v207) or 0
			local v209 = p_u_183.cap
			v206 = ("%d/%d  %s"):format(v208, tonumber(v209) or 30, v_u_62.critText(p_u_183.minRaids, p_u_183.minPct))
			local v210 = p_u_183.desc
			if type(v210) == "string" and p_u_183.desc ~= "" then
				v206 = v206 .. "  " .. p_u_183.desc
			end
		end
		v_u_57.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v191,
			["text"] = v206,
			["color"] = v205,
			["position"] = UDim2.fromOffset(v184.textX, 25),
			["size"] = UDim2.fromOffset(v184.textW, 16)
		})
		v_u_57.tooltip(v191, function()
			-- upvalues: (copy) p_u_183, (ref) v_u_62
			local v211 = {}
			local v212 = p_u_183.name or ""
			v211.title = tostring(v212)
			local v213 = p_u_183.desc
			local v214
			if type(v213) == "string" and p_u_183.desc ~= "" then
				v214 = p_u_183.desc
			else
				v214 = v_u_62.MODE_HELP[p_u_183.mode or ""] or ""
			end
			v211.body = v214
			return v211
		end)
		local v215 = v_u_181(v191, p_u_183, v184.btnX, v184.btnW, v_u_63.rowH, 0)
		v_u_82[p_u_183.id] = v215
	end
	local function v_u_249() -- name: drawDetail
		-- upvalues: (copy) v_u_60, (copy) v_u_137, (ref) v_u_70, (ref) v_u_79, (copy) v_u_63, (copy) v_u_57, (copy) v_u_59, (copy) v_u_61, (ref) v_u_80, (copy) v_u_64, (copy) v_u_62, (copy) p_u_55, (copy) v_u_164, (copy) v_u_145
		v_u_60.clear(v_u_137)
		local v_u_217 = nil
		for _, v218 in v_u_70 do
			if v218.id ~= v_u_79 then
				continue
			end
			v_u_217 = v218
		end
		if v_u_217 == nil then
			if v_u_63.twoCol then
				v_u_57.label({
					["parent"] = nil,
					["text"] = "Select a clan to see its details.",
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["align"] = "center",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_137,
					["color"] = v_u_59.text2,
					["position"] = UDim2.fromOffset(0, 24),
					["size"] = UDim2.new(1, 0, 0, 40)
				})
			end
		else
			local v219
			if v_u_63.kind == "phone" then
				local v220 = {
					["parent"] = nil,
					["text"] = "BACK",
					["kind"] = "secondary",
					["width"] = 110,
					["name"] = "Back",
					["onClick"] = nil,
					["parent"] = v_u_137,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_80, (ref) v_u_64
						v_u_80 = false
						v_u_64.draw()
					end
				}
				v_u_61.btn(v220)
				v219 = 52
			else
				v219 = 0
			end
			local v221 = v_u_61.frame(v_u_137, "TagHost", UDim2.fromOffset(80, 22), UDim2.fromOffset(0, v219 + 4))
			v_u_61.tagChip(v221, v_u_217.tag, v_u_217.id, {
				["height"] = 22,
				["tagStyle"] = nil,
				["tagStyle"] = v_u_61.dirStyle(v_u_217.tc)
			})
			local v222 = v_u_57.label
			local v223 = {
				["parent"] = nil,
				["name"] = "Name",
				["text"] = nil,
				["style"] = "h2",
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_137
			}
			local v224 = v_u_217.name or "?"
			v223.text = tostring(v224)
			v223.position = UDim2.fromOffset(88, v219)
			v223.size = UDim2.new(1, -88, 0, 30)
			v222(v223)
			local v225 = v219 + 36
			v_u_61.chip(v_u_137, v_u_62.MODE_TEXT[v_u_217.mode or ""] or "", v_u_217.mode == "open" and "success" or "muted", {
				["position"] = nil,
				["height"] = 20,
				["position"] = UDim2.fromOffset(0, v225)
			})
			v_u_57.label({
				["parent"] = nil,
				["name"] = "ModeHelp",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_137,
				["text"] = v_u_62.MODE_HELP[v_u_217.mode or ""] or "",
				["color"] = v_u_59.text2,
				["position"] = UDim2.fromOffset(0, v225 + 24),
				["size"] = UDim2.new(1, 0, 0, 32)
			})
			local v226 = v225 + 62
			local v227 = p_u_55.profile()
			local v228, v229 = v_u_62.mineFromStats(v227.stats)
			local v230 = {}
			local v231 = {}
			local v232 = v_u_217.count
			local v233 = tonumber(v232) or 0
			local v234 = v_u_217.cap
			__set_list(v231, 1, {"Members", ("%d / %d"):format(v233, tonumber(v234) or 30)})
			local v235 = { "Requirements", v_u_62.critText(v_u_217.minRaids, v_u_217.minPct) }
			local v236 = {}
			local v237 = v_u_57.commas
			local v238 = v_u_217.wp
			__set_list(v236, 1, {"Points last week", v237(tonumber(v238) or 0)})
			__set_list(v230, 1, {v231, v235, v236})
			if v228 ~= nil then
				local v239 = { "Your numbers", ("%d raids, %d%%"):format(v228, v229 or 0) }
				table.insert(v230, v239)
			end
			for _, v240 in v230 do
				v_u_57.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_137,
					["text"] = v240[1],
					["color"] = v_u_59.text2,
					["position"] = UDim2.fromOffset(0, v226),
					["size"] = UDim2.new(0.4, 0, 0, 20)
				})
				v_u_57.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "body",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v_u_137,
					["text"] = v240[2],
					["position"] = UDim2.new(0.4, 0, 0, v226),
					["size"] = UDim2.new(0.6, 0, 0, 20)
				})
				v226 = v226 + 24
			end
			local v241 = v226 + 6
			local v242 = v_u_217.desc
			local v243 = (type(v242) ~= "string" or v_u_217.desc == "") and "No description." or v_u_217.desc
			v_u_57.label({
				["parent"] = nil,
				["name"] = "Desc",
				["text"] = nil,
				["style"] = "body",
				["wrap"] = true,
				["valign"] = "top",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = v_u_137,
				["text"] = v243,
				["color"] = v_u_59.text,
				["position"] = UDim2.fromOffset(0, v241),
				["size"] = UDim2.new(1, 0, 0, 52)
			})
			local v244 = v241 + 60
			local v_u_245 = v_u_62.rowAction(v_u_217, p_u_55.state())
			if v_u_245 ~= "none" then
				local v246 = v_u_63.detailW
				local v247 = math.min(240, v246)
				local _, v248 = v_u_61.btn({
					["parent"] = nil,
					["text"] = nil,
					["kind"] = nil,
					["width"] = nil,
					["name"] = "Act",
					["position"] = nil,
					["disabled"] = nil,
					["onClick"] = nil,
					["parent"] = v_u_137,
					["text"] = v_u_62.ROW_BUTTON[v_u_245] or v_u_245,
					["kind"] = (v_u_245 == "join" or v_u_245 == "request") and "primary" or "secondary",
					["width"] = v247,
					["position"] = UDim2.fromOffset(0, v244),
					["disabled"] = v_u_245 == "locked" and true or v_u_245 == "full",
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_164, (ref) v_u_217, (copy) v_u_245
						v_u_164(v_u_217, v_u_245)
					end
				})
				v_u_145(v_u_217.id, v248, v247 - 60, v_u_245)
				if v_u_245 == "locked" then
					v_u_57.label({
						["parent"] = nil,
						["name"] = "Needs",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v_u_137,
						["text"] = v_u_62.needText(v_u_217, v228, v229),
						["color"] = v_u_59.danger,
						["position"] = UDim2.fromOffset(0, v244 + 50),
						["size"] = UDim2.new(1, 0, 0, 20)
					})
				end
			end
		end
	end
	local function v_u_259() -- name: startSpin
		-- upvalues: (ref) v_u_89, (ref) v_u_1, (copy) v_u_61, (ref) v_u_96
		if v_u_89 ~= nil then
			local v_u_250 = v_u_1.SPIN_SEC
			local v251 = v_u_61.busyDots
			if v251 ~= nil then
				local v252 = v251.STEP
				if type(v252) == "number" then
					local v253 = v251.MAX
					if type(v253) == "number" then
						v_u_250 = v251.STEP * (v251.MAX + 1)
					end
				end
			end
			local function v256()
				-- upvalues: (ref) v_u_250, (ref) v_u_89
				local v254 = TweenInfo.new(v_u_250, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1)
				local v255 = game:GetService("TweenService"):Create(v_u_89, v254, {
					["Rotation"] = 360
				})
				v255:Play()
				return v255
			end
			local v257, v258 = pcall(v256)
			if v257 then
				v_u_96 = v258
			end
		end
	end
	local function v_u_262() -- name: stopRefreshAnim
		-- upvalues: (ref) v_u_95, (ref) v_u_96, (ref) v_u_89, (ref) v_u_94
		if v_u_95 ~= nil then
			local v260 = v_u_95
			pcall(v260)
			v_u_95 = nil
		end
		if v_u_96 ~= nil then
			local function v261()
				-- upvalues: (ref) v_u_96
				v_u_96:Cancel()
			end
			pcall(v261)
			v_u_96 = nil
		end
		if v_u_89 ~= nil then
			v_u_89.Rotation = 0
		end
		v_u_94 = nil
	end
	local function v_u_274() -- name: paintRefresh
		-- upvalues: (ref) v_u_88, (ref) v_u_1, (ref) v_u_77, (ref) v_u_75, (ref) v_u_85, (copy) v_u_103, (ref) v_u_66, (ref) v_u_80, (ref) v_u_94, (copy) v_u_262, (copy) v_u_62, (copy) v_u_59, (ref) v_u_92, (ref) v_u_90, (ref) v_u_91, (copy) v_u_61, (ref) v_u_95, (copy) v_u_259
		if v_u_88 ~= nil then
			local v263 = v_u_1.refreshState
			local v264 = v_u_77
			local v265 = v_u_75
			local v266 = v_u_77
			if v266 then
				v266 = v_u_1.loadStuck(v_u_85, v_u_103())
			end
			local v267 = v263(v264, v265, v266)
			local v268 = v267 == "busy" and v_u_66
			if v268 then
				v268 = not v_u_80
			end
			local v269 = v267 .. (v268 and "+" or "")
			if v269 ~= v_u_94 then
				v_u_262()
				v_u_94 = v269
				local v270 = v267 == "busy"
				local v271 = v_u_1.refreshWord(v267, v_u_62.UI)
				local v272
				if v270 then
					v272 = v_u_59.text2
				else
					v272 = v_u_59.text
				end
				v_u_88.BackgroundTransparency = v270 and 0.75 or 0.5
				v_u_92.TextColor3 = v272
				v_u_90.Color = v272
				v_u_91.BackgroundColor3 = v272
				if v268 and v_u_61.busyDots ~= nil then
					v_u_95 = v_u_61.busyDots.animate(v_u_92, v271)
				else
					local v273 = v_u_92
					if v270 then
						v271 = v271 .. "..."
					end
					v273.Text = v271
				end
				if v268 then
					v_u_259()
				end
			end
		end
	end
	local function v_u_288() -- name: buildRefresh
		-- upvalues: (ref) v_u_1, (copy) v_u_63, (copy) v_u_129, (copy) v_u_57, (copy) v_u_59, (copy) v_u_131, (copy) v_u_61, (ref) v_u_77, (ref) v_u_75, (ref) v_u_85, (copy) v_u_103, (copy) v_u_64, (copy) v_u_62, (ref) v_u_88, (ref) v_u_89, (ref) v_u_90, (ref) v_u_91, (ref) v_u_92, (ref) v_u_93, (ref) v_u_94, (ref) v_u_97, (ref) v_u_98
		local v275 = v_u_1.refreshLayout(v_u_63, v_u_129 - 6)
		local v276 = v_u_57.new("TextButton", {
			["Name"] = "Refresh",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Selectable"] = true,
			["ClipsDescendants"] = true,
			["BackgroundColor3"] = v_u_59.raised,
			["Size"] = UDim2.new(1, -6, 0, v275.h)
		}, v_u_131)
		v276.SelectionImageObject = v_u_57.selectionImage()
		v_u_61.press(v276, function()
			-- upvalues: (ref) v_u_1, (ref) v_u_77, (ref) v_u_75, (ref) v_u_85, (ref) v_u_103, (ref) v_u_64
			local v277 = v_u_1.refreshState
			local v278 = v_u_77
			local v279 = v_u_75
			local v280 = v_u_77
			if v280 then
				v280 = v_u_1.loadStuck(v_u_85, v_u_103())
			end
			if v277(v278, v279, v280) ~= "busy" then
				v_u_64.load(true)
			end
		end)
		local v281 = v_u_57.new("Frame", {
			["Name"] = "RefreshGlyph",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v275.glyphX + v275.glyphSize / 2, v275.glyphY + v275.glyphSize / 2),
			["Size"] = UDim2.fromOffset(v275.glyphSize, v275.glyphSize)
		}, v276)
		local v282 = v_u_57.corner
		local v283 = v275.glyphSize / 2
		v282(v281, (math.floor(v283)))
		local v284 = v_u_57.stroke(v281, v_u_59.text, 2, 0)
		v_u_57.new("UIGradient", {
			["Transparency"] = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0),
				NumberSequenceKeypoint.new(0.74, 0),
				NumberSequenceKeypoint.new(0.76, 1),
				NumberSequenceKeypoint.new(1, 1)
			})
		}, v284)
		local v285 = v_u_57.new("Frame", {
			["Name"] = "RefreshTip",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45,
			["BackgroundColor3"] = v_u_59.text,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.75, 0.08),
			["Size"] = UDim2.fromOffset(6, 6)
		}, v281)
		local v286 = v_u_57.label({
			["parent"] = nil,
			["name"] = "RefreshWord",
			["text"] = nil,
			["style"] = "bodyStrong",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v276,
			["text"] = v_u_1.refreshWord("idle", v_u_62.UI),
			["position"] = UDim2.fromOffset(v275.wordX, 0),
			["size"] = UDim2.fromOffset(v275.wordW, v275.h)
		})
		local v287 = v_u_57.label({
			["parent"] = nil,
			["name"] = "RefreshAge",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["visible"] = nil,
			["track"] = false,
			["parent"] = v276,
			["color"] = v_u_59.text2,
			["position"] = UDim2.fromOffset(v275.updX, 0),
			["size"] = UDim2.fromOffset(v275.updW, v275.h),
			["visible"] = v275.showUpd
		})
		v_u_88 = v276
		v_u_89 = v281
		v_u_90 = v284
		v_u_91 = v285
		v_u_92 = v286
		v_u_93 = v287
		v_u_94 = nil
		v_u_97 = ""
		v_u_98 = -1000000000
	end
	function v_u_64.draw() -- name: draw
		-- upvalues: (ref) v_u_65, (copy) v_u_130, (ref) v_u_80, (copy) v_u_137, (copy) v_u_63, (copy) v_u_57, (copy) v_u_131, (ref) v_u_88, (copy) v_u_60, (copy) v_u_82, (copy) v_u_84, (copy) v_u_288, (copy) v_u_274, (ref) v_u_93, (copy) p_u_55, (ref) v_u_98, (ref) v_u_1, (ref) v_u_86, (ref) v_u_97, (ref) v_u_70, (ref) v_u_75, (copy) v_u_61, (copy) v_u_62, (copy) v_u_64, (copy) v_u_216, (ref) v_u_71, (ref) v_u_72, (ref) v_u_74, (copy) v_u_249
		if v_u_65 then
			v_u_130.Visible = not v_u_80
			v_u_137.Visible = v_u_63.twoCol or v_u_80
			v_u_57.keepScroll(v_u_131, function()
				-- upvalues: (ref) v_u_88, (ref) v_u_60, (ref) v_u_131, (ref) v_u_82, (ref) v_u_84, (ref) v_u_288, (ref) v_u_274, (ref) v_u_93, (ref) p_u_55, (ref) v_u_98, (ref) v_u_1, (ref) v_u_86, (ref) v_u_97, (ref) v_u_70, (ref) v_u_75, (ref) v_u_61, (ref) v_u_63, (ref) v_u_62, (ref) v_u_64, (ref) v_u_216, (ref) v_u_71, (ref) v_u_72, (ref) v_u_74
				if v_u_88 ~= nil then
					v_u_88.Parent = nil
				end
				v_u_60.clear(v_u_131)
				table.clear(v_u_82)
				table.clear(v_u_84)
				if v_u_88 == nil then
					v_u_288()
				else
					v_u_88.Parent = v_u_131
				end
				v_u_274()
				if v_u_93 ~= nil then
					local v289 = p_u_55.clock
					local v290, v291, v292, v293, v294, v295, v296, v297
					if type(v289) == "function" then
						local v298 = p_u_55.clock
						local v299
						v299, v290 = pcall(v298)
						if v299 and type(v290) == "number" then
							v_u_98 = v290
							v291 = v_u_1.updatedText
							if v_u_86 == nil then
								v292 = nil
								v293 = v291(v292)
								if v293 ~= v_u_97 then
									v_u_97 = v293
									v_u_93.Text = v293
								end
							else
								v294 = p_u_55.clock
								if type(v294) == "function" then
									v295 = p_u_55.clock
									v296, v297 = pcall(v295)
									if v296 and type(v297) == "number" then
										v292 = v297 - v_u_86
									else
										v297 = os.clock()
										v292 = v297 - v_u_86
									end
								else
									v297 = os.clock()
									v292 = v297 - v_u_86
								end
								v293 = v291(v292)
								if v293 ~= v_u_97 then
									v_u_97 = v293
									v_u_93.Text = v293
								end
							end
						else
							v290 = os.clock()
							v_u_98 = v290
							v291 = v_u_1.updatedText
							if v_u_86 == nil then
								v292 = nil
								v293 = v291(v292)
								if v293 ~= v_u_97 then
									v_u_97 = v293
									v_u_93.Text = v293
								end
							else
								v294 = p_u_55.clock
								if type(v294) == "function" then
									v295 = p_u_55.clock
									v296, v297 = pcall(v295)
									if v296 and type(v297) == "number" then
										v292 = v297 - v_u_86
									else
										v297 = os.clock()
										v292 = v297 - v_u_86
									end
								else
									v297 = os.clock()
									v292 = v297 - v_u_86
								end
								v293 = v291(v292)
								if v293 ~= v_u_97 then
									v_u_97 = v293
									v_u_93.Text = v293
								end
							end
						end
					else
						v290 = os.clock()
						v_u_98 = v290
						v291 = v_u_1.updatedText
						if v_u_86 == nil then
							v292 = nil
							v293 = v291(v292)
							if v293 ~= v_u_97 then
								v_u_97 = v293
								v_u_93.Text = v293
							end
						else
							v294 = p_u_55.clock
							if type(v294) == "function" then
								v295 = p_u_55.clock
								v296, v297 = pcall(v295)
								if v296 and type(v297) == "number" then
									v292 = v297 - v_u_86
								else
									v297 = os.clock()
									v292 = v297 - v_u_86
								end
							else
								v297 = os.clock()
								v292 = v297 - v_u_86
							end
							v293 = v291(v292)
							if v293 ~= v_u_97 then
								v_u_97 = v293
								v_u_93.Text = v293
							end
						end
					end
				end
				if v_u_70[1] == nil then
					if v_u_75 == "loading" then
						v_u_61.skeleton(v_u_131, 4, v_u_63.rowH)
						v_u_60.empty(v_u_131, v_u_62.UI.LOADING, 100)
						return
					elseif v_u_75 == "retry" then
						v_u_60.empty(v_u_131, v_u_62.UI.LOAD_RETRY, 1)
						return
					elseif v_u_75 == "gave_up" then
						v_u_60.empty(v_u_131, v_u_62.UI.LOAD_FAIL, 1)
						local v300 = {
							["parent"] = nil,
							["text"] = "RETRY",
							["kind"] = "secondary",
							["width"] = 140,
							["order"] = 2,
							["name"] = "Retry",
							["onClick"] = nil,
							["parent"] = v_u_131,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_64
								v_u_64.load(true)
							end
						}
						v_u_61.btn(v300)
					else
						v_u_60.empty(v_u_131, v_u_62.UI.NO_CLANS, 1)
					end
				else
					for v301, v302 in v_u_70 do
						v_u_216(v301, v302)
					end
					if v_u_71 < v_u_72 then
						v_u_61.btn({
							["parent"] = nil,
							["text"] = "LOAD MORE",
							["kind"] = "secondary",
							["width"] = 160,
							["order"] = nil,
							["name"] = "More",
							["onClick"] = nil,
							["parent"] = v_u_131,
							["order"] = #v_u_70 + 1,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_64
								v_u_64.load(false)
							end
						})
					end
					if v_u_74 then
						v_u_60.empty(v_u_131, "Showing saved results.", #v_u_70 + 2)
					end
					return
				end
			end)
			v_u_249()
		end
	end
	function v_u_64.load(p_u_303, p304) -- name: load
		-- upvalues: (ref) v_u_65, (ref) v_u_77, (ref) v_u_1, (ref) v_u_85, (copy) v_u_103, (ref) v_u_78, (ref) v_u_70, (ref) v_u_71, (ref) v_u_79, (ref) v_u_80, (ref) v_u_76, (copy) p_u_55, (ref) v_u_75, (copy) v_u_64, (copy) v_u_62, (ref) v_u_67, (ref) v_u_68, (copy) v_u_69, (ref) v_u_72, (ref) v_u_73, (ref) v_u_74, (ref) v_u_87, (ref) v_u_86
		if not v_u_65 then
			return
		end
		if v_u_77 then
			local v305 = v_u_77
			if v305 then
				v305 = v_u_1.loadStuck(v_u_85, v_u_103())
			end
			if not v305 then
				if p_u_303 then
					v_u_78 = true
				end
				return
			end
			v_u_78 = false
		end
		local v_u_306
		if p_u_303 then
			if p304 == true then
				v_u_306 = v_u_70[1] ~= nil
			else
				v_u_306 = false
			end
		else
			v_u_306 = p_u_303
		end
		if p_u_303 and not v_u_306 then
			v_u_71 = 1
			v_u_79 = nil
			v_u_80 = false
		end
		v_u_76 = v_u_76 + 1
		local v_u_307 = v_u_76
		local v_u_308 = p_u_303 and 1 or v_u_71 + 1
		v_u_77 = true
		local v309 = p_u_55.clock
		local v310
		if type(v309) == "function" then
			local v311 = p_u_55.clock
			local v312
			v312, v310 = pcall(v311)
			if not v312 or type(v310) ~= "number" then
				v310 = os.clock()
			end
		else
			v310 = os.clock()
		end
		v_u_85 = v310
		v_u_75 = (v_u_70[1] == nil or p_u_303 and not v_u_306) and "loading" or v_u_75
		if p_u_303 and not v_u_306 then
			v_u_70 = {}
		end
		v_u_64.draw()
		task.spawn(function()
			-- upvalues: (ref) v_u_65, (ref) v_u_77, (copy) v_u_307, (ref) v_u_76, (ref) p_u_55, (ref) v_u_62, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_308, (ref) v_u_75, (ref) v_u_64, (ref) v_u_85, (copy) p_u_303, (ref) v_u_70, (ref) v_u_71, (ref) v_u_72, (ref) v_u_73, (ref) v_u_74, (copy) v_u_306, (ref) v_u_79, (ref) v_u_80, (ref) v_u_87, (ref) v_u_86, (ref) v_u_78
			local v313 = nil
			for v314 = 0, 3 do
				if v314 > 0 then
					task.wait(2 ^ (v314 - 1) * 3)
					if not v_u_65 then
						v_u_77 = false
						return
					end
					if v_u_307 ~= v_u_76 then
						return
					end
				end
				v313 = p_u_55.fetch("clanList", v_u_62.listArgs(v_u_67, v_u_68, v_u_69, v_u_308), 0)
				if v_u_307 ~= v_u_76 then
					return
				end
				if v313 ~= nil then
					break
				end
				v_u_75 = v314 < 3 and "retry" or "gave_up"
				v_u_64.draw()
			end
			v_u_77 = false
			v_u_85 = nil
			if not v_u_65 then
				return
			end
			if v313 == nil then
				if v313 == nil then
					if v_u_306 then
						v_u_75 = nil
					end
				else
					v_u_75 = not v_u_306 and "gave_up" or nil
				end
				v_u_64.draw()
				if v_u_78 then
					v_u_78 = false
					v_u_64.load(true)
				end
				return
			end
			local v315 = v313.rows
			if type(v315) ~= "table" then
				if v313 == nil then
					if v_u_306 then
						v_u_75 = nil
					end
				else
					v_u_75 = not v_u_306 and "gave_up" or nil
				end
				v_u_64.draw()
				if v_u_78 then
					v_u_78 = false
					v_u_64.load(true)
				end
				return
			end
			v_u_75 = nil
			if p_u_303 then
				v_u_70 = {}
			end
			for _, v316 in v313.rows do
				if type(v316) ~= "table" then
					continue
				end
				local v317 = v316.id
				if type(v317) ~= "string" then
					continue
				end
				local v318 = v_u_70
				table.insert(v318, v316)
			end
			local v319 = v313.page
			v_u_71 = tonumber(v319) or v_u_308
			local v320 = v313.pages
			local v321 = tonumber(v320) or 1
			v_u_72 = math.max(1, v321)
			local v322 = v313.total
			v_u_73 = tonumber(v322) or #v_u_70
			v_u_74 = v313.stale == true
			if v_u_306 and v_u_79 ~= nil then
				local v323 = false
				for _, v324 in v_u_70 do
					if v324.id ~= v_u_79 then
						continue
					end
					v323 = true
				end
				if not v323 then
					v_u_79 = nil
					v_u_80 = false
				end
			end
			if v_u_308 ~= 1 then
				v_u_64.draw()
				if v_u_78 then
					v_u_78 = false
					v_u_64.load(true)
				end
				return
			end
			local v325 = p_u_55.clock
			local v326, v327, v328, v329, v330
			if type(v325) == "function" then
				local v331 = p_u_55.clock
				local v332
				v332, v326 = pcall(v331)
				if v332 and type(v326) == "number" then
					v_u_87 = v326
					if v_u_74 then
						v_u_64.draw()
						if v_u_78 then
							v_u_78 = false
							v_u_64.load(true)
						end
					else
						v327 = p_u_55.clock
						if type(v327) == "function" then
							v328 = p_u_55.clock
							v329, v330 = pcall(v328)
							if v329 and type(v330) == "number" then
								v_u_86 = v330
							else
								v330 = os.clock()
								v_u_86 = v330
							end
						else
							v330 = os.clock()
							v_u_86 = v330
						end
						v_u_64.draw()
						if v_u_78 then
							v_u_78 = false
							v_u_64.load(true)
						end
					end
				else
					v326 = os.clock()
					v_u_87 = v326
					if v_u_74 then
						v_u_64.draw()
						if v_u_78 then
							v_u_78 = false
							v_u_64.load(true)
						end
					else
						v327 = p_u_55.clock
						if type(v327) == "function" then
							v328 = p_u_55.clock
							v329, v330 = pcall(v328)
							if v329 and type(v330) == "number" then
								v_u_86 = v330
							else
								v330 = os.clock()
								v_u_86 = v330
							end
						else
							v330 = os.clock()
							v_u_86 = v330
						end
						v_u_64.draw()
						if v_u_78 then
							v_u_78 = false
							v_u_64.load(true)
						end
					end
				end
			else
				v326 = os.clock()
				v_u_87 = v326
				if v_u_74 then
					v_u_64.draw()
					if v_u_78 then
						v_u_78 = false
						v_u_64.load(true)
					end
				else
					v327 = p_u_55.clock
					if type(v327) == "function" then
						v328 = p_u_55.clock
						v329, v330 = pcall(v328)
						if v329 and type(v330) == "number" then
							v_u_86 = v330
						else
							v330 = os.clock()
							v_u_86 = v330
						end
					else
						v330 = os.clock()
						v_u_86 = v330
					end
					v_u_64.draw()
					if v_u_78 then
						v_u_78 = false
						v_u_64.load(true)
					end
				end
			end
		end)
	end
	function v_u_64.show() -- name: show
		-- upvalues: (ref) v_u_66, (ref) v_u_77, (ref) v_u_1, (ref) v_u_85, (copy) v_u_103, (ref) v_u_70, (copy) v_u_64, (ref) v_u_87, (copy) p_u_55
		v_u_66 = true
		local v333 = v_u_77
		if v333 then
			local v334 = v_u_77
			if v334 then
				v334 = v_u_1.loadStuck(v_u_85, v_u_103())
			end
			v333 = not v334
		end
		if v_u_70[1] == nil and not v333 then
			v_u_64.load(true)
			return
		end
		if v333 then
			v_u_64.draw()
		else
			local v335 = v_u_1.needsReload
			local v336 = v_u_70[1] ~= nil
			local v337
			if v_u_87 == nil then
				v337 = nil
				if v335(v336, v337) then
					v_u_64.load(true, true)
					return
				end
			else
				local v338 = p_u_55.clock
				local v339
				if type(v338) == "function" then
					local v340 = p_u_55.clock
					local v341
					v341, v339 = pcall(v340)
					if v341 and type(v339) == "number" then
						v337 = v339 - v_u_87
					else
						v339 = os.clock()
						v337 = v339 - v_u_87
					end
				else
					v339 = os.clock()
					v337 = v339 - v_u_87
				end
				if v335(v336, v337) then
					v_u_64.load(true, true)
					return
				end
			end
			v_u_64.draw()
		end
	end
	function v_u_64.hide() -- name: hide
		-- upvalues: (ref) v_u_66, (copy) v_u_262, (copy) v_u_274, (ref) v_u_93, (copy) p_u_55, (ref) v_u_98, (ref) v_u_1, (ref) v_u_86, (ref) v_u_97
		v_u_66 = false
		v_u_262()
		v_u_274()
		if v_u_93 == nil then
			return
		end
		local v342 = p_u_55.clock
		local v343, v344, v345, v346, v347, v348, v349, v350
		if type(v342) == "function" then
			local v351 = p_u_55.clock
			local v352
			v352, v343 = pcall(v351)
			if v352 and type(v343) == "number" then
				v_u_98 = v343
				v344 = v_u_1.updatedText
				if v_u_86 == nil then
					v345 = nil
					v346 = v344(v345)
					if v346 ~= v_u_97 then
						v_u_97 = v346
						v_u_93.Text = v346
					end
				else
					v347 = p_u_55.clock
					if type(v347) == "function" then
						v348 = p_u_55.clock
						v349, v350 = pcall(v348)
						if v349 and type(v350) == "number" then
							v345 = v350 - v_u_86
						else
							v350 = os.clock()
							v345 = v350 - v_u_86
						end
					else
						v350 = os.clock()
						v345 = v350 - v_u_86
					end
					v346 = v344(v345)
					if v346 ~= v_u_97 then
						v_u_97 = v346
						v_u_93.Text = v346
					end
				end
			else
				v343 = os.clock()
				v_u_98 = v343
				v344 = v_u_1.updatedText
				if v_u_86 == nil then
					v345 = nil
					v346 = v344(v345)
					if v346 ~= v_u_97 then
						v_u_97 = v346
						v_u_93.Text = v346
					end
				else
					v347 = p_u_55.clock
					if type(v347) == "function" then
						v348 = p_u_55.clock
						v349, v350 = pcall(v348)
						if v349 and type(v350) == "number" then
							v345 = v350 - v_u_86
						else
							v350 = os.clock()
							v345 = v350 - v_u_86
						end
					else
						v350 = os.clock()
						v345 = v350 - v_u_86
					end
					v346 = v344(v345)
					if v346 ~= v_u_97 then
						v_u_97 = v346
						v_u_93.Text = v346
					end
				end
			end
		else
			v343 = os.clock()
			v_u_98 = v343
			v344 = v_u_1.updatedText
			if v_u_86 == nil then
				v345 = nil
				v346 = v344(v345)
				if v346 ~= v_u_97 then
					v_u_97 = v346
					v_u_93.Text = v346
				end
			else
				v347 = p_u_55.clock
				if type(v347) == "function" then
					v348 = p_u_55.clock
					v349, v350 = pcall(v348)
					if v349 and type(v350) == "number" then
						v345 = v350 - v_u_86
					else
						v350 = os.clock()
						v345 = v350 - v_u_86
					end
				else
					v350 = os.clock()
					v345 = v350 - v_u_86
				end
				v346 = v344(v345)
				if v346 ~= v_u_97 then
					v_u_97 = v346
					v_u_93.Text = v346
				end
			end
		end
	end
	function v_u_64.refresh(p353, _) -- name: refresh
		-- upvalues: (copy) v_u_64
		if p353 == "state" then
			v_u_64.draw()
		end
	end
	function v_u_64.tick() -- name: tick
		-- upvalues: (ref) v_u_93, (copy) p_u_55, (ref) v_u_98, (ref) v_u_1, (ref) v_u_86, (ref) v_u_97, (ref) v_u_77, (copy) v_u_274
		if v_u_93 == nil then
			if v_u_77 then
				v_u_274()
			end
			return
		end
		local v354 = p_u_55.clock
		local v355, v356, v357, v358, v359, v360, v361, v362
		if type(v354) == "function" then
			local v363 = p_u_55.clock
			local v364
			v364, v355 = pcall(v363)
			if v364 and type(v355) == "number" then
				if v355 - v_u_98 < 0.9 then
					if v_u_77 then
						v_u_274()
					end
				else
					v_u_98 = v355
					v356 = v_u_1.updatedText
					if v_u_86 == nil then
						v357 = nil
						v358 = v356(v357)
						if v358 ~= v_u_97 then
							v_u_97 = v358
							v_u_93.Text = v358
						end
					else
						v359 = p_u_55.clock
						if type(v359) == "function" then
							v360 = p_u_55.clock
							v361, v362 = pcall(v360)
							if v361 and type(v362) == "number" then
								v357 = v362 - v_u_86
							else
								v362 = os.clock()
								v357 = v362 - v_u_86
							end
						else
							v362 = os.clock()
							v357 = v362 - v_u_86
						end
						v358 = v356(v357)
						if v358 ~= v_u_97 then
							v_u_97 = v358
							v_u_93.Text = v358
						end
					end
					if v_u_77 then
						v_u_274()
					end
				end
			else
				v355 = os.clock()
				if v355 - v_u_98 < 0.9 then
					if v_u_77 then
						v_u_274()
					end
				else
					v_u_98 = v355
					v356 = v_u_1.updatedText
					if v_u_86 == nil then
						v357 = nil
						v358 = v356(v357)
						if v358 ~= v_u_97 then
							v_u_97 = v358
							v_u_93.Text = v358
						end
					else
						v359 = p_u_55.clock
						if type(v359) == "function" then
							v360 = p_u_55.clock
							v361, v362 = pcall(v360)
							if v361 and type(v362) == "number" then
								v357 = v362 - v_u_86
							else
								v362 = os.clock()
								v357 = v362 - v_u_86
							end
						else
							v362 = os.clock()
							v357 = v362 - v_u_86
						end
						v358 = v356(v357)
						if v358 ~= v_u_97 then
							v_u_97 = v358
							v_u_93.Text = v358
						end
					end
					if v_u_77 then
						v_u_274()
					end
				end
			end
		else
			v355 = os.clock()
			if v355 - v_u_98 < 0.9 then
				if v_u_77 then
					v_u_274()
				end
			else
				v_u_98 = v355
				v356 = v_u_1.updatedText
				if v_u_86 == nil then
					v357 = nil
					v358 = v356(v357)
					if v358 ~= v_u_97 then
						v_u_97 = v358
						v_u_93.Text = v358
					end
				else
					v359 = p_u_55.clock
					if type(v359) == "function" then
						v360 = p_u_55.clock
						v361, v362 = pcall(v360)
						if v361 and type(v362) == "number" then
							v357 = v362 - v_u_86
						else
							v362 = os.clock()
							v357 = v362 - v_u_86
						end
					else
						v362 = os.clock()
						v357 = v362 - v_u_86
					end
					v358 = v356(v357)
					if v358 ~= v_u_97 then
						v_u_97 = v358
						v_u_93.Text = v358
					end
				end
				if v_u_77 then
					v_u_274()
				end
			end
		end
	end
	function v_u_64.destroy() -- name: destroy
		-- upvalues: (ref) v_u_65, (copy) v_u_262
		v_u_65 = false
		v_u_262()
	end
	return v_u_64
end
function v_u_1.invites(p_u_365, p366) -- name: invites
	-- upvalues: (copy) v_u_1
	local v_u_367 = p_u_365.UI
	local _ = p_u_365.Theme
	local v_u_368 = p_u_365.C
	local v_u_369 = p_u_365.Kit
	local v_u_370 = p_u_365.U
	local v_u_371 = p_u_365.M
	local v_u_372 = p_u_365.m
	local v_u_373 = {}
	local v_u_374 = true
	local v_u_375 = v_u_370.status(p366, {
		["name"] = "Msg",
		["text"] = "",
		["style"] = "small",
		["size"] = nil,
		["visible"] = false,
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v_u_376 = v_u_367.list({
		["parent"] = nil,
		["name"] = "List",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 2,
		["padding"] = nil,
		["parent"] = p366,
		["position"] = UDim2.fromOffset(0, 24),
		["size"] = UDim2.new(1, 0, 1, -24),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local function v_u_392(p_u_377, p_u_378, p379) -- name: answer
		-- upvalues: (ref) v_u_1, (copy) v_u_371, (copy) p_u_365, (ref) v_u_374, (copy) v_u_373, (copy) v_u_375
		local v_u_380
		if p_u_378 == "join" then
			v_u_380 = p379[1]
		else
			v_u_380 = p379[2]
		end
		local v_u_381
		if p_u_378 == "join" then
			v_u_381 = p379[2]
		else
			v_u_381 = p379[1]
		end
		v_u_380.busy(true, v_u_1.busyCaption(p_u_378, v_u_371.UI, p379.room) or "...")
		v_u_381.enable(false)
		local v382 = p_u_378 == "join" and "clanJoin" or "clanDecline"
		p_u_365.send(v382, {
			["id"] = p_u_377.cid
		}, function(p383, p384, p385, p386)
			-- upvalues: (ref) v_u_374, (copy) v_u_380, (copy) v_u_381, (copy) p_u_378, (ref) p_u_365, (copy) p_u_377, (ref) v_u_373, (ref) v_u_375, (ref) v_u_371
			if v_u_374 then
				local v387 = v_u_380.busy
				pcall(v387, false)
				local v388 = v_u_381.enable
				pcall(v388, true)
				if p383 then
					if p_u_378 == "decline" then
						local v389 = p_u_365.state()
						local v390 = {}
						for _, v391 in v389.invites or {} do
							if v391.cid == p_u_377.cid then
								continue
							end
							table.insert(v390, v391)
						end
						v389.invites = v390
						p_u_365.apply(v389)
						v_u_373.draw()
						return
					end
				else
					v_u_375.set(v_u_371.reasonFor(p386 or {
						["msg"] = p384,
						["data"] = p385
					}), "danger")
				end
			end
		end, 20)
	end
	function v_u_373.draw() -- name: draw
		-- upvalues: (ref) v_u_374, (copy) v_u_367, (copy) v_u_376, (copy) v_u_369, (copy) p_u_365, (copy) v_u_371, (copy) v_u_370, (copy) v_u_372, (ref) v_u_1, (copy) v_u_368, (copy) v_u_392
		if v_u_374 then
			v_u_367.keepScroll(v_u_376, function()
				-- upvalues: (ref) v_u_369, (ref) v_u_376, (ref) p_u_365, (ref) v_u_371, (ref) v_u_370, (ref) v_u_372, (ref) v_u_1, (ref) v_u_367, (ref) v_u_368, (ref) v_u_392
				v_u_369.clear(v_u_376)
				local v393 = p_u_365.state().invites
				if type(v393) == "table" and #v393 ~= 0 then
					for v394, v_u_395 in v393 do
						if type(v_u_395) ~= "table" then
							continue
						end
						local v396 = v_u_395.cid
						if type(v396) ~= "string" then
							continue
						end
						local v397 = v_u_370.row(v_u_376, v394, v_u_372.rowH, false)
						local v398 = v_u_370.frame
						local v399 = UDim2.fromOffset(64, 20)
						local v400 = UDim2.fromOffset
						local v401 = (v_u_372.rowH - 20) / 2
						local v402 = v398(v397, "TagHost", v399, v400(8, (math.floor(v401))))
						v_u_370.tagChip(v402, v_u_395.tag, v_u_395.cid, {
							["height"] = 20
						})
						local v403 = v_u_372.kind == "phone" and 96 or 110
						local v404 = v403 - v_u_1.ROW_TEXT_MARGIN
						local v405 = v_u_372.inner - 6 - 80 - v403 * 2 - 24
						local v406 = v_u_367.label
						local v407 = {
							["parent"] = nil,
							["name"] = "Name",
							["text"] = nil,
							["style"] = "bodyStrong",
							["position"] = nil,
							["size"] = nil,
							["parent"] = v397
						}
						local v408 = v_u_395.name or "?"
						v407.text = tostring(v408)
						v407.position = UDim2.fromOffset(80, 3)
						v407.size = UDim2.fromOffset(math.max(60, v405), 22)
						v406(v407)
						local v409 = v_u_395.k == "ok" and "Your request was approved" or "You were invited"
						local v410 = v_u_395.by
						local v411 = (type(v410) ~= "string" or (v_u_395.by == "" or string.find(v_u_395.by, "^%d+$") ~= nil)) and "" or " by " .. v_u_395.by
						local v412 = v_u_367.label
						local v413 = {
							["parent"] = nil,
							["name"] = "Sub",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v397
						}
						local v414 = "  "
						local v415 = v_u_395.ex
						local v416 = tonumber(v415)
						local v417
						if v416 == nil then
							v417 = ""
						else
							local v418 = v_u_370.left(v416)
							v417 = v418 <= 0 and "expired" or "expires in " .. v_u_371.timeText(v418)
						end
						v413.text = v409 .. v411 .. v414 .. v417
						v413.color = v_u_368.text2
						v413.position = UDim2.fromOffset(80, 25)
						v413.size = UDim2.fromOffset(math.max(60, v405), 16)
						v412(v413)
						local v_u_419 = {
							["room"] = v404
						}
						local _, v420 = v_u_370.btn({
							["parent"] = nil,
							["text"] = "JOIN",
							["kind"] = "primary",
							["width"] = nil,
							["height"] = nil,
							["maxTextWidth"] = nil,
							["name"] = "Join",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v397,
							["width"] = v403,
							["height"] = v_u_372.rowH,
							["maxTextWidth"] = v404,
							["position"] = UDim2.new(1, -(v403 * 2 + 12), 0, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_392, (copy) v_u_395, (copy) v_u_419
								v_u_392(v_u_395, "join", v_u_419)
							end
						})
						local _, v421 = v_u_370.btn({
							["parent"] = nil,
							["text"] = "DECLINE",
							["kind"] = "secondary",
							["width"] = nil,
							["height"] = nil,
							["maxTextWidth"] = nil,
							["name"] = "Decline",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v397,
							["width"] = v403,
							["height"] = v_u_372.rowH,
							["maxTextWidth"] = v404,
							["position"] = UDim2.new(1, -(v403 + 6), 0, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_392, (copy) v_u_395, (copy) v_u_419
								v_u_392(v_u_395, "decline", v_u_419)
							end
						})
						v_u_419[1] = v420
						v_u_419[2] = v421
					end
				else
					v_u_369.empty(v_u_376, v_u_371.UI.NO_INVITES, 1)
				end
			end)
		end
	end
	function v_u_373.show() -- name: show
		-- upvalues: (copy) v_u_373
		v_u_373.draw()
	end
	function v_u_373.hide() -- name: hide end
	function v_u_373.refresh(p422) -- name: refresh
		-- upvalues: (copy) v_u_373
		if p422 == "state" then
			v_u_373.draw()
		end
	end
	function v_u_373.tick() -- name: tick end
	function v_u_373.destroy() -- name: destroy
		-- upvalues: (ref) v_u_374
		v_u_374 = false
	end
	return v_u_373
end
return v_u_1