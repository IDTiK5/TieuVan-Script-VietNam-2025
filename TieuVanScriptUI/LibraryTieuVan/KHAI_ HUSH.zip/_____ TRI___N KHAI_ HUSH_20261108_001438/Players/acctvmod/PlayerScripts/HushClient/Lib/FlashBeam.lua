-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FlashBeam

local v_u_104 = {
	["FP_RIGHT"] = 0.3,
	["FP_DOWN"] = 0.3,
	["FP_FWD"] = 0.45,
	["AIM_DEFAULT"] = 40,
	["AIM_MAX"] = 60,
	["FP_MIN_D"] = 8,
	["TP_MIN_D"] = 4,
	["FP_DIP_DEG"] = 1.5,
	["MAX_SWING_DEG"] = 25,
	["FILL_ANGLE"] = 125,
	["FILL_RANGE"] = 13,
	["FILL_RANGE_LOW"] = 11,
	["FILL_BRIGHT"] = 0.8,
	["FILL_BRIGHT_LOW"] = 0.95,
	["FILL_SHADOW_QUALITY"] = 4,
	["fpOrigin"] = function(p1, p2, p3, p4, p5, p6) -- name: fpOrigin
		-- upvalues: (copy) v_u_104
		local v7
		if type(p1) == "number" and (p1 == p1 and p1 ~= (1 / 0)) then
			v7 = p1 ~= (-1 / 0)
		else
			v7 = false
		end
		if v7 then
			local v8
			if type(p2) == "number" and (p2 == p2 and p2 ~= (1 / 0)) then
				v8 = p2 ~= (-1 / 0)
			else
				v8 = false
			end
			if v8 then
				local v9
				if type(p3) == "number" and (p3 == p3 and p3 ~= (1 / 0)) then
					v9 = p3 ~= (-1 / 0)
				else
					v9 = false
				end
				if v9 then
					local v10
					if type(p4) == "number" and (p4 == p4 and p4 ~= (1 / 0)) then
						v10 = p4 ~= (-1 / 0)
					else
						v10 = false
					end
					if v10 then
						local v11
						if type(p5) == "number" and (p5 == p5 and p5 ~= (1 / 0)) then
							v11 = p5 ~= (-1 / 0)
						else
							v11 = false
						end
						if v11 then
							local v12
							if type(p6) == "number" and (p6 == p6 and p6 ~= (1 / 0)) then
								v12 = p6 ~= (-1 / 0)
							else
								v12 = false
							end
							if v12 then
								local v13 = p4 * p4 + p5 * p5 + p6 * p6
								local v14 = math.sqrt(v13)
								local v15, v16, v17
								if v14 < 1e-6 then
									v14 = 0
									v15 = 0
									v16 = 0
									v17 = 0
								else
									v16 = p4 / v14
									v17 = p5 / v14
									v15 = p6 / v14
								end
								if v14 == 0 then
									return p1, p2, p3
								end
								local v18 = -v15
								local v19 = v18 * v18 + 0 + v16 * v16
								local v20 = math.sqrt(v19)
								local v21, v22
								if v20 < 1e-6 then
									v20 = 0
									v21 = 0
									v22 = 0
								else
									v22 = v18 / v20
									local _ = 0 / v20
									v21 = v16 / v20
								end
								if v20 == 0 then
									v21 = 0
									v22 = 1
								end
								local v23 = 0 * v15 - v21 * v17
								local v24 = v21 * v16 - v22 * v15
								local v25 = v22 * v17 - v16 * 0
								local v26 = v23 * v23 + v24 * v24 + v25 * v25
								local v27 = math.sqrt(v26)
								local v28, v29, v30
								if v27 < 1e-6 then
									v28 = 0
									v29 = 0
									v30 = 0
								else
									v29 = v23 / v27
									v30 = v24 / v27
									v28 = v25 / v27
								end
								return p1 + v22 * v_u_104.FP_RIGHT - v29 * v_u_104.FP_DOWN + v16 * v_u_104.FP_FWD, p2 - v30 * v_u_104.FP_DOWN + v17 * v_u_104.FP_FWD, p3 + v21 * v_u_104.FP_RIGHT - v28 * v_u_104.FP_DOWN + v15 * v_u_104.FP_FWD
							end
						end
					end
				end
			end
		end
		return p1, p2, p3
	end,
	["aimDir"] = function(p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42) -- name: aimDir
		-- upvalues: (copy) v_u_104
		local v43 = p37 * p37 + p38 * p38 + p39 * p39
		local v44 = math.sqrt(v43)
		local v45, v46, v47
		if v44 < 1e-6 then
			v45 = 0
			v44 = 0
			v46 = 0
			v47 = 0
		else
			v46 = p37 / v44
			v47 = p38 / v44
			v45 = p39 / v44
		end
		if v44 ~= 0 then
			local v48
			if type(p31) == "number" and (p31 == p31 and p31 ~= (1 / 0)) then
				v48 = p31 ~= (-1 / 0)
			else
				v48 = false
			end
			if v48 then
				local v49
				if type(p32) == "number" and (p32 == p32 and p32 ~= (1 / 0)) then
					v49 = p32 ~= (-1 / 0)
				else
					v49 = false
				end
				if v49 then
					local v50
					if type(p33) == "number" and (p33 == p33 and p33 ~= (1 / 0)) then
						v50 = p33 ~= (-1 / 0)
					else
						v50 = false
					end
					if v50 then
						local v51
						if type(p34) == "number" and (p34 == p34 and p34 ~= (1 / 0)) then
							v51 = p34 ~= (-1 / 0)
						else
							v51 = false
						end
						if v51 then
							local v52
							if type(p35) == "number" and (p35 == p35 and p35 ~= (1 / 0)) then
								v52 = p35 ~= (-1 / 0)
							else
								v52 = false
							end
							if v52 then
								local v53
								if type(p36) == "number" and (p36 == p36 and p36 ~= (1 / 0)) then
									v53 = p36 ~= (-1 / 0)
								else
									v53 = false
								end
								if v53 then
									local v54
									if type(p40) == "number" and (p40 == p40 and p40 ~= (1 / 0)) then
										v54 = p40 ~= (-1 / 0)
									else
										v54 = false
									end
									if not v54 then
										p40 = v_u_104.AIM_DEFAULT
									end
									local v55 = p41 or v_u_104.FP_MIN_D
									local v56 = v_u_104.AIM_MAX
									local v57 = math.clamp(p40, v55, v56)
									local v58 = p34 + v46 * v57
									local v59 = p35 + v47 * v57
									local v60 = p36 + v45 * v57
									local v61 = v58 - p31
									local v62 = v59 - p32
									local v63 = v60 - p33
									local v64 = v61 * v61 + v62 * v62 + v63 * v63
									local v65 = math.sqrt(v64)
									local v66, v67, v68
									if v65 < 1e-6 then
										v65 = 0
										v66 = 0
										v67 = 0
										v68 = 0
									else
										v66 = v61 / v65
										v67 = v62 / v65
										v68 = v63 / v65
									end
									if v65 < 0.001 then
										return v46, v47, v45
									end
									local v69 = v66 * v46 + v67 * v47 + v68 * v45
									local v70 = v_u_104.MAX_SWING_DEG
									local v71 = math.rad(v70)
									if v69 < math.cos(v71) then
										return v46, v47, v45
									end
									local v72
									if type(p42) == "number" and (p42 == p42 and p42 ~= (1 / 0)) then
										v72 = p42 ~= (-1 / 0)
									else
										v72 = false
									end
									local v73 = not v72 and 0 or math.rad(p42)
									if v73 ~= 0 then
										local v74 = -v66 * v67
										local v75 = 1 - v67 * v67
										local v76 = -v68 * v67
										local v77 = v74 * v74 + v75 * v75 + v76 * v76
										local v78 = math.sqrt(v77)
										local v79, v80, v81
										if v78 < 1e-6 then
											v78 = 0
											v79 = 0
											v80 = 0
											v81 = 0
										else
											v79 = v74 / v78
											v80 = v75 / v78
											v81 = v76 / v78
										end
										if v78 > 0.0001 then
											local v82 = math.cos(v73)
											local v83 = math.sin(v73)
											local v84 = v66 * v82 - v79 * v83
											local v85 = v67 * v82 - v80 * v83
											local v86 = v68 * v82 - v81 * v83
											local v87 = v84 * v84 + v85 * v85 + v86 * v86
											local v88 = math.sqrt(v87)
											if v88 < 1e-6 then
												v66 = 0
												v67 = 0
												v68 = 0
											else
												v66 = v84 / v88
												v67 = v85 / v88
												v68 = v86 / v88
											end
										end
									end
									return v66, v67, v68
								end
							end
						end
					end
				end
			end
		end
		return 0, 0, -1
	end,
	["fill"] = function(p89, _) -- name: fill
		-- upvalues: (copy) v_u_104
		local v90
		if type(p89) == "number" and (p89 == p89 and p89 ~= (1 / 0)) then
			v90 = p89 ~= (-1 / 0)
		else
			v90 = false
		end
		local v91 = not v90 and 3 or p89
		local v92 = v91 <= 2
		local v93 = {
			["angle"] = v_u_104.FILL_ANGLE
		}
		local v94
		if v92 then
			v94 = v_u_104.FILL_RANGE_LOW
		else
			v94 = v_u_104.FILL_RANGE
		end
		v93.range = v94
		local v95
		if v92 then
			v95 = v_u_104.FILL_BRIGHT_LOW
		else
			v95 = v_u_104.FILL_BRIGHT
		end
		v93.brightness = v95
		v93.shadows = v_u_104.FILL_SHADOW_QUALITY <= v91
		return v93
	end,
	["floorNear"] = function(p96, p97, p98) -- name: floorNear
		local v99 = p97 + math.rad(p98)
		if v99 >= 1.5706963267948966 then
			return nil
		else
			return p96 / math.tan(v99)
		end
	end,
	["wallRadius"] = function(p100, p101) -- name: wallRadius
		local v102 = math.min(p101, 89)
		local v103 = math.rad(v102)
		return p100 * math.tan(v103)
	end
}
return v_u_104