-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / TokyoWarnBlink

local v_u_22 = {
	["RANGE"] = 300,
	["STEP"] = 0.25,
	["OFF_T"] = 0.8,
	["MAX"] = 160,
	["PERIOD"] = 1,
	["phase"] = function(p1, p2) -- name: phase
		-- upvalues: (copy) v_u_22
		return (p1 + p2 % 1 * v_u_22.PERIOD) % v_u_22.PERIOD / v_u_22.PERIOD < 0.5
	end,
	["seedOf"] = function(p3, p4, p5) -- name: seedOf
		local v6 = p3 * 10 + 0.5
		local v7 = math.floor(v6) * 73856093
		local v8 = p4 * 10 + 0.5
		local v9 = v7 + math.floor(v8) * 19349663
		local v10 = p5 * 10 + 0.5
		return (v9 + math.floor(v10) * 83492791) % 1000 / 1000
	end,
	["isLampName"] = function(p11) -- name: isLampName
		return p11 == "neon" and true or string.sub(p11, -6) == "__neon"
	end,
	["isWarnLight"] = function(p12, p13, p14, p15) -- name: isWarnLight
		local v16 = p12 - 255
		local v17
		if math.abs(v16) < 2 then
			local v18 = p13 - 176
			if math.abs(v18) < 2 and p14 < 2 then
				local v19 = p15 - 12
				v17 = math.abs(v19) < 0.01
			else
				v17 = false
			end
		else
			v17 = false
		end
		return v17
	end,
	["isBarrierModel"] = function(p20) -- name: isBarrierModel
		local v21
		if type(p20) == "string" then
			v21 = string.sub(p20, 1, 3) == "rb_"
		else
			v21 = false
		end
		return v21
	end
}
local v_u_23 = false
function v_u_22.start(p_u_24) -- name: start
	-- upvalues: (ref) v_u_23, (copy) v_u_22
	if not v_u_23 then
		v_u_23 = true
		local v_u_25 = game:GetService("ReplicatedStorage")
		local v_u_26 = game:GetService("Workspace")
		local v_u_27 = {}
		local v_u_28 = {}
		local v_u_29 = {}
		local function v_u_36(p30) -- name: attachLight
			-- upvalues: (copy) v_u_27
			local v31 = p30.Parent
			local v32 = v31 and v31:IsA("BasePart")
			if v32 then
				v32 = v31.Position
			end
			if not v32 then
				return false
			end
			local v33 = false
			for _, v34 in v_u_27 do
				if (v34.part.Position - v32).Magnitude >= 8 then
					continue
				end
				local v35 = v34.lights
				table.insert(v35, p30)
				v33 = true
			end
			return v33
		end
		local function v_u_45(p37) -- name: addLamp
			-- upvalues: (copy) v_u_28, (copy) v_u_27, (ref) v_u_22, (copy) v_u_29, (copy) v_u_36
			if v_u_28[p37] or (#v_u_27 >= v_u_22.MAX or not (p37:IsA("BasePart") and v_u_22.isLampName(p37.Name))) then
				return
			else
				local v38 = p37:FindFirstAncestorWhichIsA("Model")
				while v38 and not v_u_22.isBarrierModel(v38:GetAttribute("PieceId")) do
					local v39 = v38.Parent
					if v39 then
						v38 = v38.Parent:FindFirstAncestorWhichIsA("Model")
					else
						v38 = v39
					end
				end
				if v38 then
					v_u_28[p37] = true
					local v40 = p37.Position
					local v41 = {
						["part"] = p37,
						["seed"] = v_u_22.seedOf(v40.X, v40.Y, v40.Z),
						["lights"] = {}
					}
					local v42 = v_u_27
					table.insert(v42, v41)
					for v43 = #v_u_29, 1, -1 do
						local v44 = v_u_29[v43]
						if v44.Parent then
							if not v_u_36(v44) then
								continue
							end
							table.remove(v_u_29, v43)
						else
							table.remove(v_u_29, v43)
						end
					end
				end
			end
		end
		local function v_u_48(p46) -- name: addAny
			-- upvalues: (ref) v_u_22, (copy) v_u_36, (copy) v_u_29, (copy) v_u_45
			if p46:IsA("PointLight") then
				if not v_u_22.isWarnLight(p46.Color.R * 255, p46.Color.G * 255, p46.Color.B * 255, p46.Range) then
					return
				end
				if not v_u_36(p46) then
					local v47 = v_u_29
					table.insert(v47, p46)
					return
				end
			else
				v_u_45(p46)
			end
		end
		local v_u_49 = nil
		local v_u_50 = nil
		local function v_u_55(p51) -- name: watch
			-- upvalues: (ref) v_u_50, (ref) v_u_49, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (ref) v_u_22, (copy) v_u_48, (copy) v_u_45
			if p51 == v_u_50 then
				return
			else
				if v_u_49 then
					v_u_49:Disconnect()
					v_u_49 = nil
				end
				v_u_50 = p51
				table.clear(v_u_27)
				table.clear(v_u_28)
				table.clear(v_u_29)
				if p51 then
					v_u_49 = p51.DescendantAdded:Connect(function(p52)
						-- upvalues: (ref) v_u_22, (ref) v_u_48
						if p52:IsA("PointLight") or v_u_22.isLampName(p52.Name) then
							v_u_48(p52)
						end
					end)
					for _, v53 in p51:GetDescendants() do
						if not (v53:IsA("BasePart") and v_u_22.isLampName(v53.Name)) then
							continue
						end
						v_u_45(v53)
					end
					for _, v54 in p51:GetDescendants() do
						if not v54:IsA("PointLight") then
							continue
						end
						v_u_48(v54)
					end
				end
			end
		end
		local function v_u_57() -- name: prune
			-- upvalues: (copy) v_u_27, (copy) v_u_28
			for v56 = #v_u_27, 1, -1 do
				if v_u_27[v56].part.Parent then
					continue
				end
				v_u_28[v_u_27[v56].part] = nil
				table.remove(v_u_27, v56)
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_22, (copy) v_u_25, (ref) v_u_50, (ref) v_u_49, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (copy) v_u_26, (copy) v_u_55, (copy) v_u_57, (copy) p_u_24
			local v_u_58 = 0
			while true do
				repeat
					task.wait(v_u_22.STEP)
					local function v72()
						-- upvalues: (ref) v_u_25, (ref) v_u_50, (ref) v_u_49, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (ref) v_u_55, (ref) v_u_58, (ref) v_u_57, (ref) p_u_24, (ref) v_u_22
						local v59 = v_u_25:FindFirstChild("HushRuntime")
						local v60
						if v59 == nil then
							v60 = false
						else
							v60 = v59:GetAttribute("MapId") == "tokyo"
						end
						if v60 then
							local v61 = v_u_26:FindFirstChild("Raid")
							local v62 = v_u_55
							if v61 then
								v61 = v61:FindFirstChild("Map")
							end
							v62(v61)
							v_u_58 = v_u_58 + 1
							if v_u_58 % 20 == 0 then
								v_u_57()
							end
							local v63 = v_u_26.CurrentCamera
							if v63 then
								local function v64()
									-- upvalues: (ref) p_u_24
									return p_u_24.shared.Config.FLAGS.TokyoWarnBlink
								end
								local v65, v66 = pcall(v64)
								if v65 then
									v65 = v66 == false
								end
								local v67 = not v65
								local v68 = os.clock()
								for _, v69 in v_u_27 do
									if not v69.part.Parent then
										continue
									end
									local v70 = not v67 and true or v_u_22.phase(v68, v69.seed)
									if (v69.part.Position - v63.CFrame.Position).Magnitude >= v_u_22.RANGE then
										continue
									end
									v69.part.Transparency = v70 and 0 or v_u_22.OFF_T
									for _, v71 in v69.lights do
										if not v71.Parent then
											continue
										end
										v71.Enabled = v70
									end
								end
							end
						elseif v_u_50 ~= nil then
							if v_u_49 then
								v_u_49:Disconnect()
								v_u_49 = nil
							end
							v_u_50 = nil
							table.clear(v_u_27)
							table.clear(v_u_28)
							table.clear(v_u_29)
						end
					end
				until not pcall(v72)
				task.wait(2)
			end
		end)
	end
end
return v_u_22