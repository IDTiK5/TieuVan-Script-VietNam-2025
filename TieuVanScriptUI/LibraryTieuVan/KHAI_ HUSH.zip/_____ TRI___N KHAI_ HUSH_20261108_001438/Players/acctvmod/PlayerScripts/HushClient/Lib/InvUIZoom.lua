-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIZoom

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("RunService")
local v4 = script.Parent
local v_u_5 = require(v4:WaitForChild("InvUIZoomMath"))
local v_u_6 = require(v4:WaitForChild("InvUIZoomLayout"))
local v_u_7 = {}
local v_u_8 = v1.LocalPlayer
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = false
local v_u_13 = {
	["P"] = false,
	["T"] = false,
	["K"] = false
}
local v_u_14 = {}
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = false
local v_u_18 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_19 = false
v_u_7.SAVE_DELAY = 2
v_u_7.REBUILD_DELAY = 0.15
v_u_7.rebuilds = 0
v_u_7.saved = 0
local function v_u_27() -- name: classNow
	-- upvalues: (ref) v_u_9, (copy) v_u_5
	local v20
	if v_u_9 then
		v20 = v_u_9.Theme
	else
		v20 = nil
	end
	local v21, v22
	if v20 then
		local v23 = v20.isPhone
		local v24
		v21, v24 = pcall(v23)
		local v25 = v20.isTouch
		local v26
		v22, v26 = pcall(v25)
		if v21 then
			v21 = v24 == true
		end
		if v22 then
			v22 = v26 == true
		end
	else
		v21 = false
		v22 = false
	end
	return v_u_5.class(v21, v22)
end
local function v_u_30(p28) -- name: stored
	-- upvalues: (copy) v_u_8, (copy) v_u_5
	local v29
	if v_u_8 then
		v29 = v_u_8:GetAttribute(v_u_5.attr(p28))
	else
		v29 = nil
	end
	return v_u_5.resolve(v29, p28)
end
local function v_u_41(p31, p32) -- name: setAttrs
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (ref) v_u_9
	if v_u_8 then
		local v33 = v_u_5.encode(p32)
		v_u_8:SetAttribute(v_u_5.attr(p31), v33)
		local v34
		if v_u_9 then
			v34 = v_u_9.Theme
		else
			v34 = nil
		end
		local v35, v36
		if v34 then
			local v37 = v34.isPhone
			local v38
			v35, v38 = pcall(v37)
			local v39 = v34.isTouch
			local v40
			v36, v40 = pcall(v39)
			if v35 then
				v35 = v38 == true
			end
			if v36 then
				v36 = v40 == true
			end
		else
			v35 = false
			v36 = false
		end
		if p31 == v_u_5.class(v35, v36) then
			v_u_8:SetAttribute("InvZoom", v33)
		end
	end
end
function v_u_7.on(p42) -- name: on
	-- upvalues: (ref) v_u_9, (ref) v_u_10
	local v43 = v_u_9 ~= nil and (p42 ~= nil and not p42.fake)
	if v43 then
		local v44 = v_u_10
		if v44 then
			local v45 = v44.config
			if type(v45) == "table" then
				local v46 = v44.config.flag
				if type(v46) == "function" then
					local v47 = v44.config.flag
					local v48, v49 = pcall(v47, "InvZoom")
					if v48 and v49 == false then
						return false
					end
					v43 = true
				else
					v43 = true
				end
			else
				v43 = true
			end
		else
			v43 = true
		end
	end
	return v43
end
local function v_u_52(p50) -- name: headFits
	-- upvalues: (ref) v_u_9, (copy) v_u_6
	local v51 = v_u_9.Theme
	return v_u_6.columnFits(p50, {
		["touchPx"] = v51.touch(28),
		["labelMin"] = v_u_6.labelMinFor(v51.phoneText(13, "text")),
		["chrome"] = v_u_9.RIGHT_CHROME
	})
end
function v_u_7.factorFor(p53, p54) -- name: factorFor
	-- upvalues: (copy) v_u_7, (ref) v_u_19, (ref) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_52, (copy) v_u_30, (copy) v_u_27
	if not v_u_7.on(p53) then
		p53.zoom = 1
		p53.zoomFit = false
		p53.zoomOn = false
		p53.zoomKey = nil
		p53.zoomMaxIn = nil
		p53.zoomHide = false
		v_u_19 = false
		return 1
	end
	local v55
	if v_u_9 then
		v55 = v_u_9.Theme
	else
		v55 = nil
	end
	local v56, v57
	if v55 then
		local v58 = v55.isPhone
		local v59
		v56, v59 = pcall(v58)
		local v60 = v55.isTouch
		local v61
		v57, v61 = pcall(v60)
		if v56 then
			v56 = v59 == true
		end
		if v57 then
			v57 = v61 == true
		end
	else
		v56 = false
		v57 = false
	end
	local v62 = v_u_5.class(v56, v57)
	local v63
	if v_u_8 then
		v63 = v_u_8:GetAttribute(v_u_5.attr(v62))
	else
		v63 = nil
	end
	local v64 = v_u_5.resolve(v63, v62)
	if v64 == "fit" then
		local v65 = v_u_5.fit
		local v66, v67 = pcall(v65, p54)
		v64 = (not v66 or type(v67) ~= "number") and 1 or v67
		p53.zoomFit = true
	else
		p53.zoomFit = false
	end
	local v68 = v_u_5.maxIn
	local v69 = v_u_52
	local v70, v71 = pcall(v68, p54, v69)
	if not v70 or type(v71) ~= "number" then
		v71 = nil
	end
	local v72 = v_u_5.shown(v64, v71)
	local v73 = true
	local v74 = v_u_30
	local v75 = v_u_27
	local v76 = tostring(v74(v75()))
	local v77
	if v_u_8 == nil then
		v77 = false
	else
		v77 = v_u_8:GetAttribute(v_u_5.attr(v_u_27())) ~= nil
	end
	local v78 = v76 .. (v77 and "+" or "")
	p53.zoom = v72
	p53.zoomOn = v73
	p53.zoomKey = v78
	p53.zoomMaxIn = v71
	local v79 = v_u_5.hideBlock
	local v80
	if v_u_8 == nil then
		v80 = false
	else
		v80 = v_u_8:GetAttribute(v_u_5.attr(v_u_27())) ~= nil
	end
	p53.zoomHide = v79(v80, p54)
	v_u_19 = p53.zoomHide
	if v_u_8 then
		v_u_8:SetAttribute("InvZoomEff", v72)
	end
	return v72
end
function v_u_7._env() -- name: _env
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_7.state() -- name: state
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_14, (ref) v_u_10
	local v81
	if v_u_9 then
		v81 = v_u_9.Theme
	else
		v81 = nil
	end
	local v82, v83
	if v81 then
		local v84 = v81.isPhone
		local v85
		v82, v85 = pcall(v84)
		local v86 = v81.isTouch
		local v87
		v83, v87 = pcall(v86)
		if v82 then
			v82 = v85 == true
		end
		if v83 then
			v83 = v87 == true
		end
	else
		v82 = false
		v83 = false
	end
	local v88 = v_u_5.class(v82, v83)
	local v89
	if v_u_8 then
		v89 = v_u_8:GetAttribute(v_u_5.attr(v88))
	else
		v89 = nil
	end
	local v90 = v_u_5.resolve(v89, v88)
	local v91
	if v90 == "fit" then
		v91 = nil
	else
		v91 = v90
	end
	for _, v92 in not v_u_9 and {} or v_u_9.mounts do
		if not (v92.zoomOn and v92.opened) then
			continue
		end
		local v93 = v92.zoom
		if type(v93) ~= "number" then
			continue
		end
		v91 = v92.zoom
	end
	local v94 = 0
	for _ in v_u_14 do
		v94 = v94 + 1
	end
	local v95 = {
		["class"] = v88,
		["stored"] = v90,
		["effective"] = v91,
		["fit"] = v90 == "fit",
		["pending"] = v94
	}
	local v96 = v_u_10
	local v97
	if v96 then
		local v98 = v96.config
		if type(v98) == "table" then
			local v99 = v96.config.flag
			if type(v99) == "function" then
				local v100 = v96.config.flag
				local v101, v102 = pcall(v100, "InvZoom")
				v97 = (not v101 or v102 ~= false) and true or false
			else
				v97 = true
			end
		else
			v97 = true
		end
	else
		v97 = true
	end
	v95.enabled = v97
	return v95
end
local function v_u_106(p103, p104) -- name: fadeIcon
	if p103 then
		for _, v105 in p103:GetDescendants() do
			if v105:IsA("ImageLabel") then
				v105.ImageTransparency = p104
			else
				if not v105:IsA("Frame") or v105.BackgroundTransparency > 0.6 then
					continue
				end
				v105.BackgroundTransparency = p104
			end
		end
	end
end
local function v_u_141(p107) -- name: paint
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_106
	local v108 = v_u_9.C
	if p107.block:IsDescendantOf(game) then
		local v109
		if v_u_9 then
			v109 = v_u_9.Theme
		else
			v109 = nil
		end
		local v110, v111
		if v109 then
			local v112 = v109.isPhone
			local v113
			v110, v113 = pcall(v112)
			local v114 = v109.isTouch
			local v115
			v111, v115 = pcall(v114)
			if v110 then
				v110 = v113 == true
			end
			if v111 then
				v111 = v115 == true
			end
		else
			v110 = false
			v111 = false
		end
		local v116 = v_u_5.class(v110, v111)
		local v117
		if v_u_8 then
			v117 = v_u_8:GetAttribute(v_u_5.attr(v116))
		else
			v117 = nil
		end
		local v118 = v_u_5.resolve(v117, v116)
		local v119 = v118 == "fit"
		local v120 = p107.m.zoomMaxIn
		local v121
		if type(v120) == "number" then
			v121 = p107.m.zoomMaxIn
		else
			v121 = nil
		end
		local v122
		if v119 then
			v122 = p107.m.zoom or 1
		else
			v122 = v_u_5.shown(v118, v121)
		end
		local v123 = p107.label
		local v124 = v_u_5.label
		if not v119 then
			v118 = v122
		end
		v123.Text = v124(v118)
		local v125 = v_u_5.canOut(v122)
		local v126 = v_u_5.canMore(v122, v121)
		local v127 = p107.minus
		local v128 = p107.plus
		v127.Active = v125
		v128.Active = v126
		local v129 = p107.minus
		local v130 = p107.plus
		local v131 = p107.label
		local v132 = v108.raised
		local v133 = v108.raised
		local v134 = v108.raised
		v129.BackgroundColor3 = v132
		v130.BackgroundColor3 = v133
		v131.BackgroundColor3 = v134
		p107.minus.BackgroundTransparency = v125 and 0 or 0.5
		p107.plus.BackgroundTransparency = v126 and 0 or 0.5
		v_u_106(p107.minusIcon, v125 and 0 or 0.6)
		v_u_106(p107.plusIcon, v126 and 0 or 0.6)
		p107.label.TextTransparency = 0
		if p107.fit then
			local v135 = p107.fit
			local v136
			if v119 then
				v136 = v108.accent
			else
				v136 = v108.raised
			end
			v135.BackgroundColor3 = v136
			local v137 = p107.fit
			local v138
			if v119 then
				v138 = v108.ink
			else
				v138 = v108.text2
			end
			v137.TextColor3 = v138
		end
		if p107.labelIsFit then
			local v139 = p107.label
			local v140
			if v119 then
				v140 = v108.accent
			else
				v140 = v108.text
			end
			v139.TextColor3 = v140
		end
	end
end
local function v_u_144() -- name: refreshBlocks
	-- upvalues: (copy) v_u_18, (copy) v_u_141
	for v142, v143 in v_u_18 do
		if v142:IsDescendantOf(game) then
			v_u_141(v143)
		else
			v_u_18[v142] = nil
		end
	end
end
local function v_u_186(p145, p146, p147) -- name: makeBlock
	-- upvalues: (ref) v_u_9, (copy) v_u_18, (copy) v_u_141, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
	local v_u_148 = v_u_9.C
	local v149 = v_u_9.Theme
	local v_u_150 = v_u_9.HushUI
	local v_u_151 = v_u_9.new
	local v_u_152 = v_u_9.stroke
	for v153 in v_u_18 do
		if v153:IsDescendantOf(game) then
			continue
		end
		v_u_18[v153] = nil
	end
	local v_u_154 = p147.block.x
	local v_u_155 = p147.block.y
	local v_u_156 = v_u_151("Frame", {
		["Name"] = "ZoomBlock",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Position"] = UDim2.fromOffset(v_u_154, v_u_155),
		["Size"] = UDim2.fromOffset(p147.block.w, p147.block.h)
	}, p146)
	v_u_156.Visible = p145.zoomHide ~= true
	local v_u_157 = {
		["block"] = v_u_156,
		["m"] = p145,
		["labelIsFit"] = p147.labelIsFit == true
	}
	local function v164(p158, p159, p160) -- name: mk
		-- upvalues: (copy) v_u_151, (copy) v_u_148, (copy) v_u_154, (copy) v_u_155, (copy) v_u_156, (copy) v_u_152, (copy) v_u_150, (ref) v_u_9, (ref) v_u_141, (copy) v_u_157
		local v_u_161 = v_u_151("TextButton", {
			["Name"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["ZIndex"] = 7,
			["Selectable"] = true,
			["Name"] = p158,
			["BackgroundColor3"] = v_u_148.raised,
			["Position"] = UDim2.fromOffset(p159.x - v_u_154, p159.y - v_u_155),
			["Size"] = UDim2.fromOffset(p159.w, p159.h)
		}, v_u_156)
		v_u_152(v_u_161, v_u_148.line)
		local function v162()
			-- upvalues: (copy) v_u_161, (ref) v_u_150
			v_u_161.SelectionImageObject = v_u_150.selectionImage()
		end
		pcall(v162)
		v_u_161.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_161, (ref) v_u_148, (ref) v_u_9
			if v_u_161.Active then
				v_u_161.BackgroundColor3 = v_u_148.raised2
				v_u_9.sound("hover")
			end
		end)
		v_u_161.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_141, (ref) v_u_157
			v_u_141(v_u_157)
		end)
		local v163 = v_u_150.tooltip
		pcall(v163, v_u_161, p160)
		return v_u_161
	end
	local function v175(p165, p166, p167) -- name: icon
		-- upvalues: (copy) v_u_150, (copy) v_u_148
		local v168 = p167.h * 0.45
		local v169 = math.floor(v168)
		local v170 = math.max(10, v169)
		local v171 = v_u_150.icon
		local v172 = {
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["color"] = nil,
			["zindex"] = 8,
			["parent"] = p165,
			["size"] = UDim2.fromOffset(v170, v170),
			["position"] = UDim2.fromScale(0.5, 0.5),
			["anchor"] = Vector2.new(0.5, 0.5),
			["color"] = v_u_148.text
		}
		local v173, v174 = pcall(v171, p166, v172)
		if v173 then
			return v174
		else
			return nil
		end
	end
	local v176 = v149.phoneText(13, "text")
	v_u_157.minus = v164("ZoomOut", p147.minus, function()
		return "Smaller grid"
	end)
	v_u_157.minusIcon = v175(v_u_157.minus, "minus", p147.minus)
	v_u_157.plus = v164("ZoomIn", p147.plus, function()
		return "Bigger grid"
	end)
	v_u_157.plusIcon = v175(v_u_157.plus, "plus", p147.plus)
	v_u_157.label = v164("ZoomLabel", p147.label, function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (copy) v_u_157
		local v177
		if v_u_9 then
			v177 = v_u_9.Theme
		else
			v177 = nil
		end
		local v178, v179
		if v177 then
			local v180 = v177.isPhone
			local v181
			v178, v181 = pcall(v180)
			local v182 = v177.isTouch
			local v183
			v179, v183 = pcall(v182)
			if v178 then
				v178 = v181 == true
			end
			if v179 then
				v179 = v183 == true
			end
		else
			v178 = false
			v179 = false
		end
		local v184 = v_u_5.class(v178, v179)
		local v185
		if v_u_8 then
			v185 = v_u_8:GetAttribute(v_u_5.attr(v184))
		else
			v185 = nil
		end
		return v_u_5.resolve(v185, v184) ~= "fit" and (v_u_157.labelIsFit and "Grid size. Use it to fit the grid to the screen" or "Grid size") or "Grid size: fit, " .. v_u_5.label(v_u_157.m.zoom or 1)
	end)
	v_u_157.label.BackgroundTransparency = 0.2
	v_u_157.label.Text = "100%"
	v_u_157.label.FontFace = v149.font.bodyBold
	v_u_157.label.TextSize = v176
	v_u_157.label.TextColor3 = v_u_148.text
	v_u_157.label.TextTruncate = Enum.TextTruncate.None
	v_u_157.label.Selectable = v_u_157.labelIsFit
	if p147.fit then
		v_u_157.fit = v164("ZoomFit", p147.fit, function()
			return "Fit the grid to the screen"
		end)
		v_u_157.fit.Text = "Fit"
		v_u_157.fit.FontFace = v149.font.bodyBold
		v_u_157.fit.TextSize = v149.phoneText(12, "text")
		v_u_157.fit.TextColor3 = v_u_148.text2
		v_u_157.fit.TextTruncate = Enum.TextTruncate.None
	end
	v_u_157.minus.Activated:Connect(function()
		-- upvalues: (copy) v_u_157, (ref) v_u_9, (ref) v_u_7
		if v_u_157.minus.Active then
			v_u_9.sound("tick")
			v_u_7.step(-1, v_u_157.m)
		end
	end)
	v_u_157.plus.Activated:Connect(function()
		-- upvalues: (copy) v_u_157, (ref) v_u_9, (ref) v_u_7
		if v_u_157.plus.Active then
			v_u_9.sound("tick")
			v_u_7.step(1, v_u_157.m)
		end
	end)
	if v_u_157.fit then
		v_u_157.fit.Activated:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (copy) v_u_157
			v_u_9.sound("tick")
			v_u_7.toggleFit(v_u_157.m)
		end)
	end
	if v_u_157.labelIsFit then
		v_u_157.label.Activated:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_7, (copy) v_u_157
			v_u_9.sound("tick")
			v_u_7.toggleFit(v_u_157.m)
		end)
	end
	v_u_18[v_u_156] = v_u_157
	p145.zoomBlock = v_u_156
	v_u_141(v_u_157)
	return v_u_156
end
function v_u_7.header(p187, p188, p189) -- name: header
	-- upvalues: (copy) v_u_186
	return v_u_186(p187, p188, p189)
end
function v_u_7.columnHead(p190, p191, p192, p193, p194, p195, p196) -- name: columnHead
	-- upvalues: (copy) v_u_186, (copy) v_u_7
	local v197 = v_u_186(p190, p191, p195)
	if p190.zoomHide == true then
		return v197
	end
	if p193 and p195.titleW then
		local v198 = UDim2.new
		local v199 = p195.titleW
		p193.Size = v198(0, math.max(0, v199), p193.Size.Y.Scale, p193.Size.Y.Offset)
		if p195.titleHidden then
			p193.Visible = false
		end
	end
	if p194 and p195.subW then
		local v200 = UDim2.new
		local v201 = p195.subW
		p194.Size = v200(0, math.max(0, v201), p194.Size.Y.Scale, p194.Size.Y.Offset)
		if p195.titleHidden then
			p194.Visible = false
		end
	end
	v_u_7.shiftContent(p192, p196, p195.top)
	return v197
end
function v_u_7.tabsHead(p202, p203, p204, p205, p206, p207) -- name: tabsHead
	-- upvalues: (copy) v_u_186, (copy) v_u_7
	local v208 = v_u_186(p202, p203, p206)
	if p202.zoomHide == true then
		return v208
	end
	if p205 and p206.tabsW then
		local v209 = UDim2.new
		local v210 = p206.tabsW
		p205.Size = v209(0, math.max(0, v210), 0, p205.Size.Y.Offset)
		p205.Position = UDim2.fromOffset(p207 and 12 or 16, p205.Position.Y.Offset)
	end
	v_u_7.shiftContent(p204, p207, p206.top)
	return v208
end
function v_u_7.shiftContent(p211, p212, p213) -- name: shiftContent
	-- upvalues: (ref) v_u_19
	if v_u_19 then
		return
	else
		local v214 = p212 and 12 or 16
		if p211.Position.Y.Offset ~= p213 then
			p211.Position = UDim2.fromOffset(v214, p213)
			p211.Size = UDim2.new(1, -v214 - 8, 1, -p213 - 8)
		end
	end
end
local function v_u_220() -- name: flushSave
	-- upvalues: (copy) v_u_14, (copy) v_u_5, (copy) v_u_30, (ref) v_u_10, (copy) v_u_7
	local v215 = {}
	for v216 in v_u_14 do
		v215[v_u_5.key(v216)] = v_u_5.encode(v_u_30(v216))
	end
	table.clear(v_u_14)
	if next(v215) ~= nil and (v_u_10 and v_u_10.net) then
		local v217 = v_u_10.net.fire
		if type(v217) == "function" then
			local v218 = v_u_10.net.fire
			if pcall(v218, "menu.op", {
				["op"] = "setting",
				["settings"] = nil,
				["settings"] = v215
			}) then
				local v219 = v_u_7
				v219.saved = v219.saved + 1
			end
			return
		end
	end
end
local function v_u_227(p221) -- name: ratioOf
	if typeof(p221) ~= "Instance" or not p221.Parent then
		return nil
	end
	local v222 = p221.CanvasPosition
	local v223 = p221.AbsoluteCanvasSize.X - p221.AbsoluteWindowSize.X
	local v224 = math.max(1, v223)
	local v225 = p221.AbsoluteCanvasSize.Y - p221.AbsoluteWindowSize.Y
	local v226 = math.max(1, v225)
	return {
		["x"] = v222.X / v224,
		["y"] = v222.Y / v226
	}
end
local v_u_228 = { "gearScroll", "rightScroll", "eqScroll" }
local function v_u_236(p229) -- name: capture
	-- upvalues: (copy) v_u_228, (copy) v_u_227, (copy) v_u_2
	local v230 = {
		["scroll"] = {}
	}
	for _, v231 in v_u_228 do
		v230.scroll[v231] = v_u_227(p229[v231])
	end
	local v232 = v_u_2.SelectedObject
	if v232 and (p229.root and v232:IsDescendantOf(p229.root)) then
		for v233, v234 in p229.tiles do
			if v234.frame ~= v232 then
				continue
			end
			v230.uid = v233
		end
		if not v230.uid then
			local v235 = v232.Name
			if string.sub(v235, 1, 4) == "Zoom" then
				v230.button = v232.Name
			end
		end
	end
	return v230
end
local function v_u_248(p237, p238) -- name: restore
	-- upvalues: (copy) v_u_228, (copy) v_u_2
	if not p237.dead and (p237.root and p237.root.Parent) then
		for _, v239 in v_u_228 do
			local v240 = p238.scroll[v239]
			local v241 = p237[v239]
			if not v240 or (typeof(v241) ~= "Instance" or not v241.Parent) then
				continue
			end
			local v242 = v241.AbsoluteCanvasSize.X - v241.AbsoluteWindowSize.X
			local v243 = math.max(0, v242)
			local v244 = v241.AbsoluteCanvasSize.Y - v241.AbsoluteWindowSize.Y
			local v245 = math.max(0, v244)
			v241.CanvasPosition = Vector2.new(v240.x * v243, v240.y * v245)
		end
		if p238.uid then
			local v246 = p237.tiles[p238.uid]
			if v246 and (v246.frame.Parent and v246.frame.Selectable) then
				v_u_2.SelectedObject = v246.frame
				return
			end
		elseif p238.button then
			local v247 = p237.root:FindFirstChild(p238.button, true)
			if v247 and v247:IsA("GuiObject") then
				v_u_2.SelectedObject = v247
			end
		end
	end
end
local function v_u_257() -- name: staleMounts
	-- upvalues: (copy) v_u_30, (copy) v_u_27, (copy) v_u_8, (copy) v_u_5, (ref) v_u_9, (copy) v_u_7
	local v249 = {}
	local v250 = v_u_30
	local v251 = v_u_27
	local v252 = tostring(v250(v251()))
	local v253
	if v_u_8 == nil then
		v253 = false
	else
		v253 = v_u_8:GetAttribute(v_u_5.attr(v_u_27())) ~= nil
	end
	local v254 = v252 .. (v253 and "+" or "")
	for _, v255 in table.clone(v_u_9.mounts) do
		if not v255.body or (v255.dead or v255.fake) then
			continue
		end
		local v256 = v_u_7.on(v255)
		if (not v256 or v255.zoomKey == v254) and (v256 or v255.zoomOn ~= true) then
			continue
		end
		table.insert(v249, v255)
	end
	return v249
end
local function v_u_285(p258) -- name: apply
	-- upvalues: (ref) v_u_11, (ref) v_u_9, (copy) v_u_257, (copy) v_u_285, (copy) v_u_236, (copy) v_u_7, (copy) v_u_3, (copy) v_u_248, (copy) v_u_144, (ref) v_u_17, (copy) v_u_5, (copy) v_u_8
	if v_u_11 and v_u_9 then
		local v259 = v_u_257()
		if #v259 == 0 then
			return
		else
			local v260 = v_u_9.drag()
			if v260 then
				for _, v261 in v259 do
					if v260.m ~= v261 then
						continue
					end
					v261.relayoutPending = true
				end
				if p258 < 60 then
					task.delay(0.3, v_u_285, p258 + 1)
				end
			else
				local v_u_262 = {}
				for _, v263 in v259 do
					if not v263.opened then
						continue
					end
					v_u_262[v263] = v_u_236(v263)
				end
				local v264 = v_u_7
				v264.rebuilds = v264.rebuilds + 1
				local v265 = v_u_11
				local v266, v267 = pcall(v265)
				if not v266 then
					warn("[InvUIZoom] rebuild failed:", v267)
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_3, (copy) v_u_262, (ref) v_u_248, (ref) v_u_144, (ref) v_u_17, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8
					v_u_3.Heartbeat:Wait()
					v_u_3.Heartbeat:Wait()
					for v268, v269 in v_u_262 do
						local v270 = v_u_248
						pcall(v270, v268, v269)
					end
					v_u_144()
					if v_u_17 then
						v_u_17 = false
						local v271
						if v_u_9 then
							v271 = v_u_9.Theme
						else
							v271 = nil
						end
						local v272, v273
						if v271 then
							local v274 = v271.isPhone
							local v275
							v272, v275 = pcall(v274)
							local v276 = v271.isTouch
							local v277
							v273, v277 = pcall(v276)
							if v272 then
								v272 = v275 == true
							end
							if v273 then
								v273 = v277 == true
							end
						else
							v272 = false
							v273 = false
						end
						local v278 = v_u_5.class(v272, v273)
						local v279
						if v_u_8 then
							v279 = v_u_8:GetAttribute(v_u_5.attr(v278))
						else
							v279 = nil
						end
						if v_u_5.resolve(v279, v278) == "fit" then
							local v280 = nil
							for _, v281 in v_u_9.mounts do
								if not (v281.zoomOn and v281.opened) then
									continue
								end
								local v282 = v281.zoom
								if type(v282) ~= "number" then
									continue
								end
								v280 = v281.zoom
							end
							if v280 then
								local v283 = v_u_9.HushUI.toast
								local v284 = "Grid fits the screen: " .. v_u_5.label(v280)
								pcall(v283, v284, "info")
							end
						end
					end
				end)
			end
		end
	else
		return
	end
end
function v_u_7.set(p286) -- name: set
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_13, (copy) v_u_8, (ref) v_u_17, (copy) v_u_41, (copy) v_u_144, (ref) v_u_16, (copy) v_u_7, (copy) v_u_285, (copy) v_u_14, (ref) v_u_15, (copy) v_u_220
	if v_u_9 then
		local v287
		if v_u_9 then
			v287 = v_u_9.Theme
		else
			v287 = nil
		end
		local v288, v289
		if v287 then
			local v290 = v287.isPhone
			local v291
			v288, v291 = pcall(v290)
			local v292 = v287.isTouch
			local v293
			v289, v293 = pcall(v292)
			if v288 then
				v288 = v291 == true
			end
			if v289 then
				v289 = v293 == true
			end
		else
			v288 = false
			v289 = false
		end
		local v294 = v_u_5.class(v288, v289)
		local v295 = v_u_5.snap(p286)
		v_u_13[v294] = true
		local v296
		if v_u_8 then
			v296 = v_u_8:GetAttribute(v_u_5.attr(v294))
		else
			v296 = nil
		end
		local v297 = v_u_5.resolve(v296, v294)
		if v295 == "fit" and v297 ~= "fit" then
			v_u_17 = true
		end
		v_u_41(v294, v295)
		v_u_144()
		if v297 ~= v295 then
			v_u_16 = v_u_16 + 1
			local v_u_298 = v_u_16
			task.delay(v_u_7.REBUILD_DELAY, function()
				-- upvalues: (copy) v_u_298, (ref) v_u_16, (ref) v_u_285
				if v_u_298 == v_u_16 then
					v_u_285(0)
				end
			end)
		end
		v_u_14[v294] = true
		v_u_15 = v_u_15 + 1
		local v_u_299 = v_u_15
		task.delay(v_u_7.SAVE_DELAY, function()
			-- upvalues: (copy) v_u_299, (ref) v_u_15, (ref) v_u_220
			if v_u_299 == v_u_15 then
				v_u_220()
			end
		end)
	end
end
function v_u_7.step(p300, p301) -- name: step
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
	local v302
	if v_u_9 then
		v302 = v_u_9.Theme
	else
		v302 = nil
	end
	local v303, v304
	if v302 then
		local v305 = v302.isPhone
		local v306
		v303, v306 = pcall(v305)
		local v307 = v302.isTouch
		local v308
		v304, v308 = pcall(v307)
		if v303 then
			v303 = v306 == true
		end
		if v304 then
			v304 = v308 == true
		end
	else
		v303 = false
		v304 = false
	end
	local v309 = v_u_5.class(v303, v304)
	local v310
	if v_u_8 then
		v310 = v_u_8:GetAttribute(v_u_5.attr(v309))
	else
		v310 = nil
	end
	local v311 = v_u_5.resolve(v310, v309)
	local v312
	if p301 then
		local v313 = p301.zoomMaxIn
		if type(v313) == "number" then
			v312 = p301.zoomMaxIn
		else
			v312 = nil
		end
	else
		v312 = nil
	end
	local v314 = v_u_5.stepTo
	local v315
	if v311 == "fit" then
		if p301 then
			local v316 = p301.zoom
			v315 = type(v316) ~= "number" and 1 or p301.zoom
		else
			v315 = 1
		end
	else
		v315 = nil
	end
	local v317 = v314(v311, p300, v315, v312)
	if v317 ~= nil then
		v_u_7.set(v317)
	end
end
function v_u_7.toggleFit(p318) -- name: toggleFit
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
	local v319
	if v_u_9 then
		v319 = v_u_9.Theme
	else
		v319 = nil
	end
	local v320, v321
	if v319 then
		local v322 = v319.isPhone
		local v323
		v320, v323 = pcall(v322)
		local v324 = v319.isTouch
		local v325
		v321, v325 = pcall(v324)
		if v320 then
			v320 = v323 == true
		end
		if v321 then
			v321 = v325 == true
		end
	else
		v320 = false
		v321 = false
	end
	local v326 = v_u_5.class(v320, v321)
	local v327
	if v_u_8 then
		v327 = v_u_8:GetAttribute(v_u_5.attr(v326))
	else
		v327 = nil
	end
	if v_u_5.resolve(v327, v326) == "fit" then
		local v328 = v_u_7.set
		local v329
		if p318 then
			local v330 = p318.zoom
			v329 = type(v330) ~= "number" and 1 or p318.zoom
		else
			v329 = 1
		end
		v328(v329)
	else
		v_u_7.set("fit")
	end
end
local function v_u_338() -- name: loadStored
	-- upvalues: (ref) v_u_10, (copy) v_u_5, (copy) v_u_13, (copy) v_u_8
	if v_u_10 and v_u_10.net then
		local v331 = v_u_10.net.invoke
		if type(v331) == "function" then
			for v332 = 1, 3 do
				local v333 = v_u_10.net.invoke
				local v334, v335 = pcall(v333, "menu.get", {
					["what"] = "settings"
				})
				if v334 and (type(v335) == "table" and v335.error == nil) then
					for _, v336 in { "P", "T", "K" } do
						local v337 = v335[v_u_5.key(v336)]
						if type(v337) ~= "number" or (v_u_13[v336] or v_u_8:GetAttribute(v_u_5.attr(v336)) ~= nil) then
							continue
						end
						v_u_8:SetAttribute(v_u_5.attr(v336), v_u_5.encode(v_u_5.snap(v337)))
					end
					return
				end
				task.wait(v332 * 2)
			end
			return
		end
	end
end
local function v_u_374(p339) -- name: debugCommand
	-- upvalues: (copy) v_u_7, (ref) v_u_9
	local v340 = p339[1]
	if v340 == "in" then
		v_u_7.step(1, nil)
	elseif v340 == "out" then
		v_u_7.step(-1, nil)
	elseif v340 == "fit" then
		v_u_7.toggleFit(nil)
	elseif v340 == "set" then
		local v341 = p339[2]
		local v342 = tonumber(v341)
		v_u_7.set(p339[2] == "fit" and "fit" or (v342 == nil and 1 or v342))
	elseif v340 == "bench" then
		local v343 = {}
		for v344, v345 in v_u_9.mounts do
			if not v345.opened or (not v345.body or v345.dead) then
				continue
			end
			local v346 = os.clock()
			local v347 = v_u_9.Ext.Layout.build
			local v348 = pcall(v347, v345)
			local v349 = string.format
			local v350 = v345.mode
			local v351 = (os.clock() - v346) * 1000
			table.insert(v343, v349("#%d %s %.1f ms%s", v344, v350, v351, v348 and "" or " FAILED"))
		end
		return #v343 == 0 and "no open mount" or table.concat(v343, " | ")
	end
	local v352 = v_u_7.state()
	local v353 = {}
	for v354, v355 in v_u_9.mounts do
		local v356 = string.format
		local v357 = v355.mode
		local v358 = v355.cell
		local v359 = tostring(v358)
		local v360 = v355.zoom
		local v361 = tostring(v360)
		local v362 = v355.zoomMaxIn
		local v363 = tostring(v362)
		table.insert(v353, v356("#%d %s cell=%s zoom=%s max=%s", v354, v357, v359, v361, v363))
	end
	local v364 = string.format
	local v365 = v352.class
	local v366 = v352.stored
	local v367 = tostring(v366)
	local v368 = v352.effective
	local v369 = tostring(v368)
	local v370 = v352.fit
	local v371 = tostring(v370)
	local v372 = v352.pending
	local v373 = v352.enabled
	return v364("class=%s stored=%s effective=%s fit=%s pending=%d enabled=%s rebuilds=%d saved=%d | %s", v365, v367, v369, v371, v372, tostring(v373), v_u_7.rebuilds, v_u_7.saved, table.concat(v353, " | "))
end
function v_u_7.start(p375, p376, p377) -- name: start
	-- upvalues: (ref) v_u_12, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_8, (copy) v_u_5, (copy) v_u_144, (ref) v_u_16, (copy) v_u_7, (copy) v_u_285, (copy) v_u_374, (copy) v_u_338
	if not v_u_12 then
		v_u_12 = true
		v_u_9 = p375
		v_u_10 = p376
		v_u_11 = p377
		if v_u_8 then
			local v378 = v_u_8
			local v379 = "InvZoomEnabled"
			local v380 = v_u_10
			local v381
			if v380 then
				local v382 = v380.config
				if type(v382) == "table" then
					local v383 = v380.config.flag
					if type(v383) == "function" then
						local v384 = v380.config.flag
						local v385, v386 = pcall(v384, "InvZoom")
						v381 = (not v385 or v386 ~= false) and true or false
					else
						v381 = true
					end
				else
					v381 = true
				end
			else
				v381 = true
			end
			v378:SetAttribute(v379, v381)
			for _, v_u_387 in { "P", "T", "K" } do
				v_u_8:GetAttributeChangedSignal(v_u_5.attr(v_u_387)):Connect(function()
					-- upvalues: (copy) v_u_387, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_144, (ref) v_u_16, (ref) v_u_7, (ref) v_u_285
					local v388 = v_u_387
					local v389
					if v_u_9 then
						v389 = v_u_9.Theme
					else
						v389 = nil
					end
					local v390, v391
					if v389 then
						local v392 = v389.isPhone
						local v393
						v390, v393 = pcall(v392)
						local v394 = v389.isTouch
						local v395
						v391, v395 = pcall(v394)
						if v390 then
							v390 = v393 == true
						end
						if v391 then
							v391 = v395 == true
						end
					else
						v390 = false
						v391 = false
					end
					if v388 == v_u_5.class(v390, v391) then
						v_u_8:SetAttribute("InvZoom", v_u_8:GetAttribute(v_u_5.attr(v_u_387)))
					end
					v_u_144()
					v_u_16 = v_u_16 + 1
					local v_u_396 = v_u_16
					task.delay(v_u_7.REBUILD_DELAY, function()
						-- upvalues: (copy) v_u_396, (ref) v_u_16, (ref) v_u_285
						if v_u_396 == v_u_16 then
							v_u_285(0)
						end
					end)
				end)
			end
		end
		if p376 then
			local v397 = p376.command
			if type(v397) == "function" then
				local v398 = p376.command
				local v399 = v_u_374
				pcall(v398, "invui.zoom", v399)
			end
		end
		task.spawn(v_u_338)
		v_u_16 = v_u_16 + 1
		local v_u_400 = v_u_16
		task.delay(v_u_7.REBUILD_DELAY, function()
			-- upvalues: (copy) v_u_400, (ref) v_u_16, (ref) v_u_285
			if v_u_400 == v_u_16 then
				v_u_285(0)
			end
		end)
	end
end
return v_u_7