-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MapZoom

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = require(v1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MapZoomRule"))
local v_u_4 = {
	["store"] = v_u_3.newStore(),
	["Rule"] = v_u_3
}
local v_u_5 = Color3.fromRGB(55, 47, 38)
local v_u_6 = Color3.fromRGB(232, 223, 200)
local v_u_7 = Color3.fromRGB(106, 94, 76)
local v_u_8 = Color3.fromRGB(46, 128, 214)
function v_u_4.new(p_u_9) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_8, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_2
	local v_u_10 = p_u_9.holder
	local v_u_11 = p_u_9.W
	local v_u_12 = p_u_9.H
	local v_u_13 = p_u_9.UI
	local v_u_14 = p_u_9.Theme
	local v_u_15 = p_u_9.UiPointer
	local v_u_16 = p_u_9.VirtualPad
	v_u_10.ClipsDescendants = true
	local v_u_17 = Instance.new("Frame")
	v_u_17.Name = "ZoomLayer"
	v_u_17.BackgroundTransparency = 1
	v_u_17.BorderSizePixel = 0
	v_u_17.Size = UDim2.fromOffset(v_u_11, v_u_12)
	v_u_17.Position = UDim2.fromOffset(0, 0)
	v_u_17.Parent = v_u_10
	local v_u_18 = Instance.new("UIScale")
	v_u_18.Name = "ZoomScale"
	v_u_18.Scale = 1
	v_u_18.Parent = v_u_17
	local v_u_19 = {
		["layer"] = v_u_17
	}
	local v_u_20 = {
		["z"] = 1,
		["x"] = 0,
		["y"] = 0,
		["follow"] = true
	}
	local v_u_21 = nil
	local v_u_22 = {}
	local v_u_23 = nil
	local v_u_24 = -10
	local v_u_25 = nil
	local v_u_26 = {}
	local v_u_27 = {}
	local v_u_28 = nil
	local v_u_29 = nil
	local v_u_30 = nil
	local v_u_31 = nil
	local v_u_32 = nil
	local v_u_33 = nil
	local v_u_34 = nil
	local v_u_35 = true
	local v_u_36 = 0
	local v_u_37 = {}
	local v_u_38 = -10
	local v_u_39 = {
		"X_",
		"Pos_",
		"Task_",
		"TaskHit_",
		"WP_",
		"WPHit",
		"PadCursor"
	}
	local v_u_40 = {
		{ "Tag_", "X_" },
		{ "Hit_", "X_" },
		{ "TaskTag_", "Task_" },
		{ "WPTag_", "WP_" }
	}
	local function v_u_51(p41, p42, p43) -- name: keepOne
		-- upvalues: (ref) v_u_3
		local v44 = p41:FindFirstChild("ZoomKeep")
		if v44 or (p43 > 1.001 or p41:GetAttribute("ZkZ") ~= nil) then
			if not v44 then
				v44 = Instance.new("UIScale")
				v44.Name = "ZoomKeep"
				v44.Parent = p41
			end
			if p41:GetAttribute("ZkX") == nil then
				p41:SetAttribute("ZkX", p41.Position.X.Offset)
				p41:SetAttribute("ZkY", p41.Position.Y.Offset)
			end
			if p42 then
				local v45 = p41:GetAttribute("ZkX")
				local v46 = p41:GetAttribute("ZkY")
				local v47 = p42.Position.X.Offset
				local v48 = p42.Position.Y.Offset
				local v49, v50 = v_u_3.keepPos(v45, v46, v47, v48, p43)
				p41.Position = UDim2.fromOffset(v49, v50)
			end
			v44.Scale = v_u_3.keepScale(p43)
			p41:SetAttribute("ZkZ", p43)
		end
	end
	local function v_u_67(p52, p53) -- name: keepRoot
		-- upvalues: (copy) v_u_39, (copy) v_u_51, (copy) v_u_40
		if p52 then
			for _, v54 in p52:GetChildren() do
				if not v54:IsA("GuiObject") or v54:GetAttribute("ZkZ") == p53 then
					continue
				end
				local v55 = v54.Name
				local v56 = false
				for _, v57 in v_u_39 do
					local v58 = #v57
					if string.sub(v55, 1, v58) ~= v57 then
						continue
					end
					local v59
					if v54.AnchorPoint.X == 0.5 and (v54.AnchorPoint.Y == 0.5 and v54.Position.X.Scale == 0) then
						v59 = v54.Position.Y.Scale == 0
					else
						v59 = false
					end
					if not v59 then
						continue
					end
					v_u_51(v54, nil, p53)
					v56 = true
				end
				if v56 then
					break
				end
				for _, v60 in v_u_40 do
					local v61 = v60[1]
					local v62 = v60[2]
					local v63 = #v61
					if string.sub(v55, 1, v63) ~= v61 then
						continue
					end
					local v64 = #v61 + 1
					local v65 = p52:FindFirstChild(v62 .. string.sub(v55, v64))
					if not (v65 and v65:IsA("GuiObject")) then
						break
					end
					local v66
					if v65.AnchorPoint.X == 0.5 and (v65.AnchorPoint.Y == 0.5 and v65.Position.X.Scale == 0) then
						v66 = v65.Position.Y.Scale == 0
					else
						v66 = false
					end
					if not v66 or (v54.AnchorPoint.X ~= 0 or (v54.AnchorPoint.Y ~= 0 or (v54.Position.X.Scale ~= 0 or v54.Position.Y.Scale ~= 0))) then
						break
					end
					v_u_51(v54, v65, p53)
				end
			end
		end
	end
	function v_u_19.keepPass() -- name: keepPass
		-- upvalues: (copy) p_u_9, (copy) v_u_20, (copy) v_u_67
		local v68 = p_u_9.sheet()
		if v68 then
			local v69 = v_u_20.z
			local v70 = v69 <= 1.001 and 1 or v69
			local v71 = v68.area
			v_u_67(v68.marks, v70)
			if v71 then
				v_u_67(v71, v70)
				v_u_67(v71:FindFirstChild("TaskMarks"), v70)
			end
		end
	end
	local function v_u_83() -- name: paint
		-- upvalues: (copy) v_u_18, (copy) v_u_20, (copy) v_u_19, (copy) v_u_17, (ref) v_u_30, (copy) p_u_9, (ref) v_u_35, (ref) v_u_33, (ref) v_u_8, (ref) v_u_5, (ref) v_u_34, (ref) v_u_3, (ref) v_u_31, (ref) v_u_32
		v_u_18.Scale = v_u_20.z
		v_u_19.keepPass()
		local v72 = v_u_17
		local v73 = UDim2.fromOffset
		local v74 = v_u_20.x
		local v75 = math.round(v74)
		local v76 = v_u_20.y
		v72.Position = v73(v75, (math.round(v76)))
		local v77 = v_u_20.z > 1.01
		if v_u_30 then
			local v78 = v_u_30
			local v79 = p_u_9.sheet()
			local v80 = v_u_35
			if v80 then
				if v79 == nil or v79.noMap == true then
					v80 = false
				else
					v80 = v79.marks ~= nil
				end
			end
			v78.Visible = v80
		end
		if v_u_33 then
			v_u_33.Visible = v77
			local v81 = v_u_33
			local v82
			if v_u_20.follow then
				v82 = v_u_8
			else
				v82 = v_u_5
			end
			v81.TextColor3 = v82
		end
		if v_u_34 then
			v_u_34.Text = v_u_3.percent(v_u_20.z)
		end
		if v_u_31 then
			v_u_31.TextTransparency = v_u_20.z >= v_u_3.MAX - 0.01 and 0.6 or 0
		end
		if v_u_32 then
			v_u_32.BackgroundTransparency = v_u_20.z <= 1.01 and 0.5 or 0.08
		end
	end
	function v_u_19.layerPoint(p84) -- name: layerPoint
		-- upvalues: (copy) p_u_9, (copy) v_u_17, (copy) v_u_11
		local v85 = p_u_9.sheet()
		if not v85 or (not v85.marks or v_u_17.AbsoluteSize.X < 1) then
			return nil
		end
		local v86 = v_u_17.AbsoluteSize.X / v_u_11
		return (v85.marks.AbsolutePosition - v_u_17.AbsolutePosition) / v86 + p84
	end
	function v_u_19.state() -- name: state
		-- upvalues: (copy) v_u_20, (ref) v_u_21
		return {
			["z"] = v_u_20.z,
			["x"] = v_u_20.x,
			["y"] = v_u_20.y,
			["follow"] = v_u_20.follow,
			["key"] = v_u_21
		}
	end
	function v_u_19.zoom() -- name: zoom
		-- upvalues: (copy) v_u_20
		return v_u_20.z
	end
	function v_u_19.justDragged() -- name: justDragged
		-- upvalues: (ref) v_u_25, (ref) v_u_24
		return v_u_25 ~= nil and v_u_25.moved == true and true or os.clock() - v_u_24 < 0.25
	end
	function v_u_19.sync() -- name: sync
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4, (copy) v_u_20, (ref) v_u_3, (copy) v_u_11, (copy) v_u_12
		local v87 = p_u_9.sheet()
		local v88 = v_u_35
		if v88 then
			if v87 == nil or v87.noMap == true then
				v88 = false
			else
				v88 = v87.marks ~= nil
			end
		end
		if v88 then
			local v89 = p_u_9.key()
			if v89 == v_u_21 then
				v_u_83()
			else
				if v_u_21 then
					v_u_4.store.set(v_u_21, v_u_20)
				end
				v_u_21 = v89
				local v90 = v_u_4.store.get(v89)
				local v91 = v_u_20
				local v92 = v_u_20
				local v93 = v_u_20
				local v94 = v_u_20
				local v95 = v90.z
				local v96 = v90.x
				local v97 = v90.y
				local v98 = v90.follow
				v91.z = v95
				v92.x = v96
				v93.y = v97
				v94.follow = v98
				local v99 = v_u_20
				local v100 = v_u_20
				local v101, v102 = v_u_3.clampPos(v_u_20.x, v_u_20.y, v_u_20.z, v_u_11, v_u_12)
				v99.x = v101
				v100.y = v102
				v_u_83()
			end
		else
			v_u_83()
			return
		end
	end
	function v_u_19.setZoom(p103, p104, p105) -- name: setZoom
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (ref) v_u_3, (copy) v_u_20, (copy) v_u_11, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v106 = p_u_9.sheet()
		local v107 = v_u_35
		if v107 then
			if v106 == nil or v106.noMap == true then
				v107 = false
			else
				v107 = v106.marks ~= nil
			end
		end
		if v107 then
			local v108, v109, v110 = v_u_3.zoomAt(v_u_20.z, v_u_20.x, v_u_20.y, p103, p104 or v_u_11 / 2, p105 or v_u_12 / 2, v_u_11, v_u_12)
			v_u_20.z = v_u_3.clampZoom(v108)
			local v111 = v_u_20
			local v112 = v_u_20
			local v113, v114 = v_u_3.clampPos(v109, v110, v_u_20.z, v_u_11, v_u_12)
			v111.x = v113
			v112.y = v114
			if v_u_20.z <= 1.001 then
				v_u_20.follow = true
			end
			v_u_83()
			if v_u_21 then
				v_u_4.store.set(v_u_21, v_u_20)
			end
		end
	end
	function v_u_19.zoomBy(p115) -- name: zoomBy
		-- upvalues: (copy) v_u_19, (ref) v_u_3, (copy) v_u_20
		v_u_19.setZoom(v_u_3.stepZoom(v_u_20.z, p115))
	end
	function v_u_19.reset() -- name: reset
		-- upvalues: (copy) v_u_20, (ref) v_u_3, (copy) v_u_11, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		v_u_20.follow = true
		v_u_20.z = v_u_3.clampZoom(1)
		local v116 = v_u_20
		local v117 = v_u_20
		local v118, v119 = v_u_3.clampPos(0, 0, v_u_20.z, v_u_11, v_u_12)
		v116.x = v118
		v117.y = v119
		if v_u_20.z <= 1.001 then
			v_u_20.follow = true
		end
		v_u_83()
		if v_u_21 then
			v_u_4.store.set(v_u_21, v_u_20)
		end
	end
	function v_u_19.centerMe() -- name: centerMe
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_20, (copy) v_u_17, (copy) v_u_11, (ref) v_u_3, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v120 = p_u_9.sheet()
		local v121 = v_u_35
		if v121 then
			if v120 == nil or v120.noMap == true then
				v121 = false
			else
				v121 = v120.marks ~= nil
			end
		end
		if v121 then
			v_u_20.follow = true
			local v122 = p_u_9.own()
			local v123
			if v122 then
				local v124 = p_u_9.sheet()
				if v124 and (v124.marks and v_u_17.AbsoluteSize.X >= 1) then
					local v125 = v_u_17.AbsoluteSize.X / v_u_11
					v123 = (v124.marks.AbsolutePosition - v_u_17.AbsolutePosition) / v125 + v122
				else
					v123 = nil
				end
			else
				v123 = nil
			end
			if v123 then
				local v126, v127 = v_u_3.centerOn(v_u_20.z, v123.X, v123.Y, v_u_11, v_u_12)
				local v128 = v_u_20.z
				v_u_20.z = v_u_3.clampZoom(v128)
				local v129 = v_u_20
				local v130 = v_u_20
				local v131, v132 = v_u_3.clampPos(v126, v127, v_u_20.z, v_u_11, v_u_12)
				v129.x = v131
				v130.y = v132
				if v_u_20.z <= 1.001 then
					v_u_20.follow = true
				end
				v_u_83()
				if v_u_21 then
					v_u_4.store.set(v_u_21, v_u_20)
					return
				end
			else
				local v133 = v_u_20.z
				local v134 = v_u_20.x
				local v135 = v_u_20.y
				v_u_20.z = v_u_3.clampZoom(v133)
				local v136 = v_u_20
				local v137 = v_u_20
				local v138, v139 = v_u_3.clampPos(v134, v135, v_u_20.z, v_u_11, v_u_12)
				v136.x = v138
				v137.y = v139
				if v_u_20.z <= 1.001 then
					v_u_20.follow = true
				end
				v_u_83()
				if v_u_21 then
					v_u_4.store.set(v_u_21, v_u_20)
				end
			end
		end
	end
	function v_u_19.reveal(p140) -- name: reveal
		-- upvalues: (copy) p_u_9, (copy) v_u_17, (copy) v_u_11, (copy) v_u_20, (ref) v_u_3, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v141 = p_u_9.sheet()
		local v142
		if v141 and (v141.marks and v_u_17.AbsoluteSize.X >= 1) then
			local v143 = v_u_17.AbsoluteSize.X / v_u_11
			v142 = (v141.marks.AbsolutePosition - v_u_17.AbsolutePosition) / v143 + p140
		else
			v142 = nil
		end
		if v142 and v_u_20.z > 1.01 then
			local v144, v145 = v_u_3.reveal(v_u_20.x, v_u_20.y, v_u_20.z, v142.X, v142.Y, v_u_11, v_u_12, 40)
			if v144 ~= v_u_20.x or v145 ~= v_u_20.y then
				local v146 = v_u_20.z
				v_u_20.z = v_u_3.clampZoom(v146)
				local v147 = v_u_20
				local v148 = v_u_20
				local v149, v150 = v_u_3.clampPos(v144, v145, v_u_20.z, v_u_11, v_u_12)
				v147.x = v149
				v148.y = v150
				if v_u_20.z <= 1.001 then
					v_u_20.follow = true
				end
				v_u_83()
				if v_u_21 then
					v_u_4.store.set(v_u_21, v_u_20)
				end
			end
		end
	end
	local function v166() -- name: build
		-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_30, (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (copy) v_u_13, (copy) v_u_19
		local v151 = v_u_14.touch
		local v_u_152 = math.max(30, v151(32))
		local v_u_153 = Instance.new("Frame")
		v_u_153.Name = "ZoomBar"
		v_u_153.BackgroundTransparency = 1
		v_u_153.AnchorPoint = Vector2.new(1, 0.5)
		v_u_153.Position = UDim2.new(1, -8, 0.5, 0)
		v_u_153.Size = UDim2.fromOffset(v_u_152, v_u_152 * 3 + 12 + 16)
		v_u_153.ZIndex = 100
		v_u_153.Parent = v_u_10
		v_u_30 = v_u_153
		local function v161(p154, p155, p156, p157) -- name: mk
			-- upvalues: (ref) v_u_6, (copy) v_u_152, (ref) v_u_5, (ref) v_u_14, (copy) v_u_153, (ref) v_u_7
			local v158 = Instance.new("TextButton")
			v158.Name = p154
			v158.AutoButtonColor = true
			v158.Selectable = false
			v158.BackgroundColor3 = v_u_6
			v158.BackgroundTransparency = 0.08
			v158.BorderSizePixel = 0
			v158.Position = UDim2.fromOffset(0, p155)
			v158.Size = UDim2.fromOffset(v_u_152, v_u_152)
			v158.Text = p156
			v158.TextColor3 = v_u_5
			v158.TextSize = p157
			v158.FontFace = v_u_14.font.headingBold
			v158.ZIndex = 101
			v158.Parent = v_u_153
			local v159 = Instance.new("UICorner")
			v159.CornerRadius = UDim.new(0, 6)
			v159.Parent = v158
			local v160 = Instance.new("UIStroke")
			v160.Color = v_u_7
			v160.Thickness = 1.5
			v160.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v160.Parent = v158
			return v158
		end
		v_u_31 = v161("ZoomIn", 0, "+", 24)
		v_u_32 = v161("ZoomOut", v_u_152 + 4, "", 24)
		local v162 = Instance.new("Frame")
		v162.Name = "MinusBar"
		v162.AnchorPoint = Vector2.new(0.5, 0.5)
		v162.Position = UDim2.fromScale(0.5, 0.5)
		local v163 = UDim2.fromOffset
		local v164 = v_u_152 * 0.42
		v162.Size = v163(math.floor(v164), 3)
		v162.BackgroundColor3 = v_u_5
		v162.BorderSizePixel = 0
		v162.ZIndex = 102
		v162.Parent = v_u_32
		v_u_33 = v161("ZoomMe", (v_u_152 + 4) * 2, "YOU", 13)
		local v165 = Instance.new("TextLabel")
		v165.Name = "ZoomPercent"
		v165.BackgroundTransparency = 1
		v165.Position = UDim2.fromOffset(-10, (v_u_152 + 4) * 3)
		v165.Size = UDim2.fromOffset(v_u_152 + 20, 14)
		v165.Text = "100%"
		v165.TextColor3 = v_u_5
		v165.TextSize = 12
		v165.FontFace = v_u_14.font.bodyMedium
		v165.TextStrokeColor3 = v_u_6
		v165.TextStrokeTransparency = 0.4
		v165.ZIndex = 101
		v165.Parent = v_u_153
		v_u_34 = v165
		v_u_31.Activated:Connect(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_19
			v_u_13.sound("click")
			v_u_19.zoomBy(1)
		end)
		v_u_32.Activated:Connect(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_19
			v_u_13.sound("click")
			v_u_19.zoomBy(-1)
		end)
		v_u_33.Activated:Connect(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_19
			v_u_13.sound("click")
			v_u_19.centerMe()
		end)
	end
	pcall(v166)
	local function v_u_169(p167) -- name: shown
		while p167 and not p167:IsA("LayerCollector") do
			if p167:IsA("GuiObject") and not p167.Visible then
				return false
			end
			p167 = p167.Parent
		end
		local v168
		if p167 == nil then
			v168 = false
		else
			v168 = not p167:IsA("ScreenGui") or p167.Enabled
		end
		return v168
	end
	local function v_u_178(p170) -- name: overScroller
		-- upvalues: (ref) v_u_38, (copy) v_u_37, (copy) v_u_10, (copy) v_u_169, (ref) v_u_3
		local v171 = os.clock()
		if v171 - v_u_38 > 2 then
			v_u_38 = v171
			table.clear(v_u_37)
			local v172 = v_u_10:FindFirstAncestorWhichIsA("LayerCollector")
			if v172 then
				for _, v173 in v172:GetDescendants() do
					if not v173:IsA("ScrollingFrame") then
						continue
					end
					local v174 = v_u_37
					table.insert(v174, v173)
				end
			end
		end
		local v175 = {}
		for _, v176 in v_u_37 do
			if not v176.Parent or (not v176.ScrollingEnabled or v176.AbsoluteCanvasSize.Y <= v176.AbsoluteSize.Y + 1 and v176.AbsoluteCanvasSize.X <= v176.AbsoluteSize.X + 1) or not v_u_169(v176) then
				continue
			end
			local v177 = {
				["x"] = v176.AbsolutePosition.X,
				["y"] = v176.AbsolutePosition.Y,
				["w"] = v176.AbsoluteSize.X,
				["h"] = v176.AbsoluteSize.Y
			}
			table.insert(v175, v177)
		end
		return v_u_3.overAny(v175, p170.X, p170.Y)
	end
	local function v_u_197(p179) -- name: wheel
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_10, (copy) v_u_15, (copy) v_u_11, (copy) v_u_12, (copy) v_u_178, (ref) v_u_3, (copy) v_u_20, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v180 = p_u_9.sheet()
		local v181 = v_u_35
		if v181 then
			if v180 == nil or v180.noMap == true then
				v181 = false
			else
				v181 = v180.marks ~= nil
			end
		end
		if v181 then
			if p_u_9.isOpen() == true then
				v181 = v_u_10.Visible
			else
				v181 = false
			end
		end
		if v181 then
			local v182 = v_u_15.mouseAbs()
			local v183 = v182 - v_u_10.AbsolutePosition
			local v184 = v_u_10.AbsoluteSize.X
			local v185 = v183 / ((v184 <= 1 or v_u_11 <= 0) and 1 or v184 / v_u_11)
			local v186
			if v185.X >= 0 and (v185.Y >= 0 and v185.X <= v_u_11) then
				v186 = v185.Y <= v_u_12
			else
				v186 = false
			end
			if v186 then
				if not v_u_178(v182) then
					local v187 = v182 - v_u_10.AbsolutePosition
					local v188 = v_u_10.AbsoluteSize.X
					local v189 = v187 / ((v188 <= 1 or v_u_11 <= 0) and 1 or v188 / v_u_11)
					local v190, v191, v192 = v_u_3.zoomAt(v_u_20.z, v_u_20.x, v_u_20.y, v_u_3.wheelZoom(v_u_20.z, p179.Position.Z), v189.X, v189.Y, v_u_11, v_u_12)
					if v190 > 1.01 then
						v_u_20.follow = false
					end
					v_u_20.z = v_u_3.clampZoom(v190)
					local v193 = v_u_20
					local v194 = v_u_20
					local v195, v196 = v_u_3.clampPos(v191, v192, v_u_20.z, v_u_11, v_u_12)
					v193.x = v195
					v194.y = v196
					if v_u_20.z <= 1.001 then
						v_u_20.follow = true
					end
					v_u_83()
					if v_u_21 then
						v_u_4.store.set(v_u_21, v_u_20)
					end
				end
			else
				return
			end
		else
			return
		end
	end
	local function v_u_215() -- name: pinchUpdate
		-- upvalues: (ref) v_u_3, (copy) v_u_27, (copy) v_u_26, (ref) v_u_28, (copy) v_u_10, (copy) v_u_11, (copy) v_u_20, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v198, v199 = v_u_3.pickTouches(v_u_27, v_u_26)
		if v198 == nil or v199 == nil then
			v_u_28 = nil
		else
			local v200 = v_u_26[v198]
			local v201 = v_u_26[v199]
			local v202 = (v200 - v201).Magnitude
			local v203 = v_u_10.AbsoluteSize.X
			local v204 = v202 / ((v203 <= 1 or v_u_11 <= 0) and 1 or v203 / v_u_11)
			local v205 = (v200 + v201) / 2 - v_u_10.AbsolutePosition
			local v206 = v_u_10.AbsoluteSize.X
			local v207 = v205 / ((v206 <= 1 or v_u_11 <= 0) and 1 or v206 / v_u_11)
			if v_u_28 then
				local v208, v209, v210 = v_u_3.pinch(v_u_20.z, v_u_20.x, v_u_20.y, v_u_28.d, v204, v_u_28.m.X, v_u_28.m.Y, v207.X, v207.Y, v_u_11, v_u_12)
				if v208 > 1.01 then
					v_u_20.follow = false
				end
				v_u_20.z = v_u_3.clampZoom(v208)
				local v211 = v_u_20
				local v212 = v_u_20
				local v213, v214 = v_u_3.clampPos(v209, v210, v_u_20.z, v_u_11, v_u_12)
				v211.x = v213
				v212.y = v214
				if v_u_20.z <= 1.001 then
					v_u_20.follow = true
				end
				v_u_83()
				if v_u_21 then
					v_u_4.store.set(v_u_21, v_u_20)
				end
			end
			v_u_28 = {
				["d"] = v204,
				["m"] = v207
			}
		end
	end
	local v216 = v_u_2.InputBegan
	local function v240(p217, _)
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_10, (copy) v_u_15, (copy) v_u_11, (copy) v_u_12, (ref) v_u_30, (copy) v_u_26, (copy) v_u_27, (ref) v_u_25, (ref) v_u_24, (ref) v_u_23, (ref) v_u_28, (copy) v_u_215
		local v218 = p_u_9.sheet()
		local v219 = v_u_35
		if v219 then
			if v218 == nil or v218.noMap == true then
				v219 = false
			else
				v219 = v218.marks ~= nil
			end
		end
		if v219 then
			if p_u_9.isOpen() == true then
				v219 = v_u_10.Visible
			else
				v219 = false
			end
		end
		if v219 then
			local v220 = p217.UserInputType
			if v220 == Enum.UserInputType.Touch then
				local v221 = v_u_15.ioAbs(p217)
				local v222 = v221 - v_u_10.AbsolutePosition
				local v223 = v_u_10.AbsoluteSize.X
				local v224 = v222 / ((v223 <= 1 or v_u_11 <= 0) and 1 or v223 / v_u_11)
				local v225
				if v224.X >= 0 and (v224.Y >= 0 and v224.X <= v_u_11) then
					v225 = v224.Y <= v_u_12
				else
					v225 = false
				end
				if v225 then
					local v226
					if v_u_30 and v_u_30.Visible then
						local v227 = v_u_30.AbsolutePosition
						local v228 = v_u_30.AbsoluteSize
						if v221.X >= v227.X and (v221.Y >= v227.Y and v221.X <= v227.X + v228.X) then
							v226 = v221.Y <= v227.Y + v228.Y
						else
							v226 = false
						end
					else
						v226 = false
					end
					if not v226 then
						v_u_26[p217] = v221
						local v229 = v_u_27
						table.insert(v229, p217)
						if next(v_u_26) ~= nil then
							local v230 = 0
							for _ in v_u_26 do
								v230 = v230 + 1
							end
							if v230 >= 2 then
								if v_u_25 then
									if v_u_25.moved then
										v_u_24 = os.clock()
										local v_u_231 = v_u_23
										v_u_23 = nil
										if v_u_231 then
											task.delay(0.15, function()
												-- upvalues: (copy) v_u_231
												v_u_231:Destroy()
											end)
										end
									end
									v_u_25 = nil
								end
								v_u_28 = nil
								v_u_215()
								return
							end
							if not v_u_25 then
								v_u_25 = {
									["io"] = nil,
									["last"] = nil,
									["start"] = nil,
									["moved"] = false,
									["touch"] = true,
									["io"] = p217,
									["last"] = v221,
									["start"] = v221
								}
								return
							end
						end
					end
				end
			elseif v220 == Enum.UserInputType.MouseButton1 or v220 == Enum.UserInputType.MouseButton3 then
				local v232 = v_u_15.ioAbs(p217)
				local v233 = v232 - v_u_10.AbsolutePosition
				local v234 = v_u_10.AbsoluteSize.X
				local v235 = v233 / ((v234 <= 1 or v_u_11 <= 0) and 1 or v234 / v_u_11)
				local v236
				if v235.X >= 0 and (v235.Y >= 0 and v235.X <= v_u_11) then
					v236 = v235.Y <= v_u_12
				else
					v236 = false
				end
				if v236 then
					local v237
					if v_u_30 and v_u_30.Visible then
						local v238 = v_u_30.AbsolutePosition
						local v239 = v_u_30.AbsoluteSize
						if v232.X >= v238.X and (v232.Y >= v238.Y and v232.X <= v238.X + v239.X) then
							v237 = v232.Y <= v238.Y + v239.Y
						else
							v237 = false
						end
					else
						v237 = false
					end
					if not v237 then
						v_u_25 = {
							["io"] = nil,
							["last"] = nil,
							["start"] = nil,
							["moved"] = false,
							["button"] = nil,
							["io"] = p217,
							["last"] = v232,
							["start"] = v232,
							["button"] = v220
						}
					end
				end
			end
		end
	end
	table.insert(v_u_22, v216:Connect(v240))
	local v241 = v_u_2.InputChanged
	local function v266(p242, p243)
		-- upvalues: (copy) v_u_197, (copy) v_u_26, (copy) v_u_15, (copy) p_u_9, (ref) v_u_35, (copy) v_u_10, (copy) v_u_215, (ref) v_u_25, (ref) v_u_24, (ref) v_u_23, (ref) v_u_2, (copy) v_u_20, (copy) v_u_11, (ref) v_u_3, (copy) v_u_12, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4
		local v244 = p242.UserInputType
		if v244 == Enum.UserInputType.MouseWheel then
			if not p243 then
				v_u_197(p242)
			end
			return
		else
			if v244 == Enum.UserInputType.Touch and v_u_26[p242] then
				v_u_26[p242] = v_u_15.ioAbs(p242)
				local v245 = 0
				for _ in v_u_26 do
					v245 = v245 + 1
				end
				if v245 >= 2 then
					local v246 = p_u_9.sheet()
					local v247 = v_u_35
					if v247 then
						if v246 == nil or v246.noMap == true then
							v247 = false
						else
							v247 = v246.marks ~= nil
						end
					end
					if v247 then
						if p_u_9.isOpen() == true then
							v247 = v_u_10.Visible
						else
							v247 = false
						end
					end
					if v247 then
						v_u_215()
					end
					return
				end
			end
			local v248 = v_u_25
			if v248 then
				local v249 = v244 == Enum.UserInputType.MouseMovement
				if v248.touch and p242 == v248.io or not v248.touch and v249 then
					local v250 = p_u_9.sheet()
					local v251 = v_u_35
					if v251 then
						if v250 == nil or v250.noMap == true then
							v251 = false
						else
							v251 = v250.marks ~= nil
						end
					end
					if v251 then
						if p_u_9.isOpen() == true then
							v251 = v_u_10.Visible
						else
							v251 = false
						end
					end
					if v251 then
						if v248.touch or v_u_2:IsMouseButtonPressed(v248.button) then
							local v252 = v_u_15.ioAbs(p242)
							if not v248.moved then
								if (v252 - v248.start).Magnitude < 6 or v_u_20.z <= 1.01 then
									return
								end
								v248.moved = true
								v_u_20.follow = false
								if not (v_u_23 and v_u_23.Parent) then
									local v253 = Instance.new("TextButton")
									v253.Name = "ZoomShield"
									v253.BackgroundTransparency = 1
									v253.BorderSizePixel = 0
									v253.Text = ""
									v253.AutoButtonColor = false
									v253.Selectable = false
									v253.Size = UDim2.fromScale(1, 1)
									v253.ZIndex = 90
									v253.Parent = v_u_10
									v_u_23 = v253
								end
							end
							local v254 = v252 - v248.last
							local v255 = v_u_10.AbsoluteSize.X
							local v256 = v254 / ((v255 <= 1 or v_u_11 <= 0) and 1 or v255 / v_u_11)
							v248.last = v252
							local v257, v258 = v_u_3.panBy(v_u_20.x, v_u_20.y, v_u_20.z, v256.X, v256.Y, v_u_11, v_u_12)
							local v259 = v_u_20.z
							v_u_20.z = v_u_3.clampZoom(v259)
							local v260 = v_u_20
							local v261 = v_u_20
							local v262, v263 = v_u_3.clampPos(v257, v258, v_u_20.z, v_u_11, v_u_12)
							v260.x = v262
							v261.y = v263
							if v_u_20.z <= 1.001 then
								v_u_20.follow = true
							end
							v_u_83()
							if v_u_21 then
								v_u_4.store.set(v_u_21, v_u_20)
							end
						elseif v_u_25 then
							if v_u_25.moved then
								v_u_24 = os.clock()
								local v_u_264 = v_u_23
								v_u_23 = nil
								if v_u_264 then
									task.delay(0.15, function()
										-- upvalues: (copy) v_u_264
										v_u_264:Destroy()
									end)
								end
							end
							v_u_25 = nil
						end
					else
						if v_u_25 then
							if v_u_25.moved then
								v_u_24 = os.clock()
								local v_u_265 = v_u_23
								v_u_23 = nil
								if v_u_265 then
									task.delay(0.15, function()
										-- upvalues: (copy) v_u_265
										v_u_265:Destroy()
									end)
								end
							end
							v_u_25 = nil
						end
						return
					end
				else
					return
				end
			else
				return
			end
		end
	end
	table.insert(v_u_22, v241:Connect(v266))
	local v267 = v_u_2.InputEnded
	local function v275(p268, _)
		-- upvalues: (copy) v_u_26, (copy) v_u_27, (ref) v_u_28, (copy) v_u_215, (ref) v_u_25, (ref) v_u_24, (ref) v_u_23
		local v269 = p268.UserInputType
		if v269 == Enum.UserInputType.Touch then
			v_u_26[p268] = nil
			local v270 = table.find(v_u_27, p268)
			if v270 then
				table.remove(v_u_27, v270)
			end
			v_u_28 = nil
			local v271 = 0
			for _ in v_u_26 do
				v271 = v271 + 1
			end
			if v271 >= 2 then
				v_u_215()
			end
			if v_u_25 and v_u_25.io == p268 then
				if v_u_25 then
					if v_u_25.moved then
						v_u_24 = os.clock()
						local v_u_272 = v_u_23
						v_u_23 = nil
						if v_u_272 then
							task.delay(0.15, function()
								-- upvalues: (copy) v_u_272
								v_u_272:Destroy()
							end)
						end
					end
					v_u_25 = nil
					return
				end
			elseif v271 == 0 and (v_u_25 and v_u_25) then
				if v_u_25.moved then
					v_u_24 = os.clock()
					local v_u_273 = v_u_23
					v_u_23 = nil
					if v_u_273 then
						task.delay(0.15, function()
							-- upvalues: (copy) v_u_273
							v_u_273:Destroy()
						end)
					end
				end
				v_u_25 = nil
				return
			end
		elseif v_u_25 and (not v_u_25.touch and (v269 == v_u_25.button and v_u_25)) then
			if v_u_25.moved then
				v_u_24 = os.clock()
				local v_u_274 = v_u_23
				v_u_23 = nil
				if v_u_274 then
					task.delay(0.15, function()
						-- upvalues: (copy) v_u_274
						v_u_274:Destroy()
					end)
				end
			end
			v_u_25 = nil
		end
	end
	table.insert(v_u_22, v267:Connect(v275))
	local v276 = v_u_2.InputBegan
	local function v282(p277, p278)
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_10, (copy) v_u_19
		if not p278 then
			local v279 = p_u_9.sheet()
			local v280 = v_u_35
			if v280 then
				if v279 == nil or v279.noMap == true then
					v280 = false
				else
					v280 = v279.marks ~= nil
				end
			end
			if v280 then
				if p_u_9.isOpen() == true then
					v280 = v_u_10.Visible
				else
					v280 = false
				end
			end
			if v280 and p277.UserInputType == Enum.UserInputType.Keyboard then
				local v281 = p277.KeyCode
				if v281 == Enum.KeyCode.Equals or (v281 == Enum.KeyCode.Plus or v281 == Enum.KeyCode.KeypadPlus) then
					v_u_19.zoomBy(1)
				elseif v281 == Enum.KeyCode.Minus or v281 == Enum.KeyCode.KeypadMinus then
					v_u_19.zoomBy(-1)
				end
			end
		end
	end
	table.insert(v_u_22, v276:Connect(v282))
	function v_u_19.step(p283) -- name: step
		-- upvalues: (copy) p_u_9, (ref) v_u_35, (copy) v_u_10, (copy) v_u_19, (ref) v_u_36, (copy) v_u_16, (ref) v_u_3, (copy) v_u_11, (copy) v_u_12, (copy) v_u_17, (copy) v_u_20, (copy) v_u_83, (ref) v_u_21, (ref) v_u_4, (ref) v_u_29, (ref) v_u_25
		local v284 = p_u_9.sheet()
		local v285 = v_u_35
		if v285 then
			if v284 == nil or v284.noMap == true then
				v285 = false
			else
				v285 = v284.marks ~= nil
			end
		end
		if v285 then
			if p_u_9.isOpen() == true then
				v285 = v_u_10.Visible
			else
				v285 = false
			end
		end
		if v285 then
			v_u_19.sync()
			v_u_36 = v_u_36 + p283
			if v_u_36 >= 0.1 then
				v_u_36 = 0
				v_u_19.keepPass()
			end
			if v_u_16 then
				local v286 = 0
				local v287 = v_u_16.gamepadState
				local v288, v289 = pcall(v287)
				if v288 and type(v289) == "table" then
					for _, v290 in v289 do
						if v290.KeyCode == Enum.KeyCode.ButtonR2 then
							v286 = v286 + v290.Position.Z
						else
							if v290.KeyCode ~= Enum.KeyCode.ButtonL2 then
								continue
							end
							v286 = v286 - v290.Position.Z
						end
					end
				end
				if math.abs(v286) > v_u_3.TRIGGER_DEAD then
					local v291 = v_u_3.triggerRate((math.abs(v286))) ^ (p283 * (v286 > 0 and 1 or -1))
					local v292 = v_u_11 / 2
					local v293 = v_u_12 / 2
					local v294 = p_u_9.cursor()
					local v295
					if v294 then
						local v296 = p_u_9.sheet()
						if v296 and (v296.marks and v_u_17.AbsoluteSize.X >= 1) then
							local v297 = v_u_17.AbsoluteSize.X / v_u_11
							v295 = (v296.marks.AbsolutePosition - v_u_17.AbsolutePosition) / v297 + v294
						else
							v295 = nil
						end
					else
						v295 = nil
					end
					if v295 then
						v292, v293 = v_u_3.toHolder(v_u_20.x, v_u_20.y, v_u_20.z, v295.X, v295.Y)
					end
					local v298, v299, v300 = v_u_3.zoomAt(v_u_20.z, v_u_20.x, v_u_20.y, v_u_20.z * v291, v292, v293, v_u_11, v_u_12)
					v_u_20.z = v_u_3.clampZoom(v298)
					local v301 = v_u_20
					local v302 = v_u_20
					local v303, v304 = v_u_3.clampPos(v299, v300, v_u_20.z, v_u_11, v_u_12)
					v301.x = v303
					v302.y = v304
					if v_u_20.z <= 1.001 then
						v_u_20.follow = true
					end
					v_u_83()
					if v_u_21 then
						v_u_4.store.set(v_u_21, v_u_20)
					end
				end
			end
			if v_u_20.z > 1.01 then
				local v305 = p_u_9.cursor()
				if v305 then
					if v_u_29 == nil or (v305 - v_u_29).Magnitude > 0.5 then
						if v_u_29 ~= nil then
							v_u_20.follow = false
						end
						v_u_29 = v305
						v_u_19.reveal(v305)
					end
					if not v_u_20.follow then
						return
					end
				else
					v_u_29 = nil
				end
				if v_u_20.follow and not (v_u_25 and v_u_25.moved) then
					local v306 = p_u_9.own()
					local v307
					if v306 then
						local v308 = p_u_9.sheet()
						if v308 and (v308.marks and v_u_17.AbsoluteSize.X >= 1) then
							local v309 = v_u_17.AbsoluteSize.X / v_u_11
							v307 = (v308.marks.AbsolutePosition - v_u_17.AbsolutePosition) / v309 + v306
						else
							v307 = nil
						end
					else
						v307 = nil
					end
					if v307 then
						local v310, v311 = v_u_3.centerOn(v_u_20.z, v307.X, v307.Y, v_u_11, v_u_12)
						local v312 = -p283 * 10
						local v313 = 1 - math.exp(v312)
						local v314 = v_u_20.x + (v310 - v_u_20.x) * v313
						local v315 = v_u_20.y + (v311 - v_u_20.y) * v313
						local v316 = v310 - v314
						if math.abs(v316) >= 0.5 then
							v310 = v314
						end
						local v317 = v311 - v315
						if math.abs(v317) >= 0.5 then
							v311 = v315
						end
						if v310 ~= v_u_20.x or v311 ~= v_u_20.y then
							local v318 = v_u_20.z
							v_u_20.z = v_u_3.clampZoom(v318)
							local v319 = v_u_20
							local v320 = v_u_20
							local v321, v322 = v_u_3.clampPos(v310, v311, v_u_20.z, v_u_11, v_u_12)
							v319.x = v321
							v320.y = v322
							if v_u_20.z <= 1.001 then
								v_u_20.follow = true
							end
							v_u_83()
							if v_u_21 then
								v_u_4.store.set(v_u_21, v_u_20)
							end
						end
					end
				end
			end
		else
			return
		end
	end
	function v_u_19.destroy() -- name: destroy
		-- upvalues: (ref) v_u_35, (copy) v_u_22, (ref) v_u_21, (ref) v_u_4, (copy) v_u_20, (ref) v_u_25, (ref) v_u_24, (ref) v_u_23, (copy) v_u_26, (copy) v_u_27, (copy) v_u_17, (ref) v_u_30
		v_u_35 = false
		for _, v323 in v_u_22 do
			v323:Disconnect()
		end
		table.clear(v_u_22)
		if v_u_21 then
			v_u_4.store.set(v_u_21, v_u_20)
		end
		if v_u_25 then
			if v_u_25.moved then
				v_u_24 = os.clock()
				local v_u_324 = v_u_23
				v_u_23 = nil
				if v_u_324 then
					task.delay(0.15, function()
						-- upvalues: (copy) v_u_324
						v_u_324:Destroy()
					end)
				end
			end
			v_u_25 = nil
		end
		table.clear(v_u_26)
		table.clear(v_u_27)
		if v_u_17.Parent then
			v_u_17:Destroy()
		end
		if v_u_30 then
			v_u_30:Destroy()
			v_u_30 = nil
		end
		if v_u_23 then
			v_u_23:Destroy()
			v_u_23 = nil
		end
	end
	return v_u_19
end
return v_u_4