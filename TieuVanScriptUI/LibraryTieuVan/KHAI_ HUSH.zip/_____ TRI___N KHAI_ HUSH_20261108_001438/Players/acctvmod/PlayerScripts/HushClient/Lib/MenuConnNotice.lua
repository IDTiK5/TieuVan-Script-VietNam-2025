-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuConnNotice

local v_u_1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
local v_u_3 = nil
local v_u_4 = false
local v_u_5 = {}
local v_u_6 = false
local v_u_7 = nil
function v_u_1.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_3
	local v8
	if v_u_3 == nil or v_u_3.api == nil then
		v8 = false
	else
		v8 = v_u_3.api.frame.Parent ~= nil
	end
	return v8
end
function v_u_1.close() -- name: close
	-- upvalues: (ref) v_u_3
	local v9 = v_u_3
	v_u_3 = nil
	if v9 and v9.api then
		local v10 = v9.api.close
		pcall(v10)
	end
end
function v_u_1.idle(p_u_11) -- name: idle
	-- upvalues: (copy) v_u_2
	if v_u_2:GetAttribute("Place") == "Menu" and (v_u_2:GetAttribute("MenuOpen") == true and v_u_2:GetAttribute("MenuReady") == true) then
		if v_u_2:GetAttribute("MenuTour") == nil then
			local v12, v13 = pcall(function()
				-- upvalues: (copy) p_u_11
				return p_u_11.partyDeploying()
			end)
			if v12 and v13 == true then
				return false
			else
				local v14 = v_u_2:FindFirstChildOfClass("PlayerGui")
				local v15
				if v14 then
					v15 = v14:FindFirstChild("HushMenu")
				else
					v15 = nil
				end
				if v15 and v15:FindFirstChild("Debrief", true) then
					return false
				else
					return p_u_11.ui.modalCount() <= 0
				end
			end
		else
			return false
		end
	else
		return false
	end
end
local function v_u_20(p16) -- name: serverNow
	local v17 = p16.profile
	local v18
	if type(v17) == "table" then
		v18 = p16.profile.derived
	else
		v18 = nil
	end
	if type(v18) == "table" then
		local v19 = v18.serverTime
		if type(v19) == "number" then
			return v18.serverTime
		end
	end
	return os.time()
end
local v_u_21 = {
	["main"] = "body",
	["guard"] = "body",
	["why"] = "small",
	["mail"] = "body"
}
function v_u_1.show(p_u_22, p_u_23) -- name: show
	-- upvalues: (copy) v_u_20, (copy) v_u_21, (copy) v_u_5, (ref) v_u_3
	local v_u_24 = p_u_22.ui
	local v25 = p_u_22.theme
	local v_u_26 = v25.color
	local v27 = p_u_22.cctx.shared.ConnGuard.noticeCard
	local v28, v29 = pcall(function()
		-- upvalues: (copy) p_u_22, (copy) p_u_23
		return p_u_22.cctx.shared.Maps.get(p_u_23.mapId)
	end)
	local v30
	if v28 and type(v29) == "table" then
		local v31 = v29.name
		if type(v31) == "string" then
			v30 = v29.name
		else
			v30 = nil
		end
	else
		v30 = nil
	end
	local v_u_32 = v27(p_u_23, v30, v_u_20(p_u_22))
	local v_u_33 = v25.isPhone()
	local v38 = v_u_24.modal({
		["title"] = nil,
		["kind"] = nil,
		["width"] = 560,
		["dismissable"] = false,
		["build"] = nil,
		["buttons"] = nil,
		["title"] = v_u_32.title,
		["kind"] = p_u_23.kind ~= "leave" and not p_u_23.granted and "danger" or nil,
		["build"] = function(p34) -- name: build
			-- upvalues: (copy) p_u_23, (copy) v_u_24, (copy) v_u_32, (copy) v_u_26, (copy) v_u_33, (ref) v_u_21
			if p_u_23.kind == "leave" then
				v_u_24.badge("RAID NOT KEPT", "warn", {
					["parent"] = nil,
					["order"] = 0,
					["name"] = "Status",
					["parent"] = p34
				})
			else
				v_u_24.badge(p_u_23.granted and "GEAR KEPT" or "GEAR LOST", p_u_23.granted and "success" or "danger", {
					["parent"] = nil,
					["order"] = 0,
					["name"] = "Status",
					["parent"] = p34
				})
			end
			for v35, v36 in v_u_32.lines do
				local v37
				if v36.key == "guard" then
					v37 = v_u_26.accent
				elseif v36.key == "why" then
					v37 = v_u_26.text2
				elseif v36.key == "mail" then
					v37 = v_u_26.success
				else
					v37 = v_u_26.text
				end
				v_u_24.label({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = nil,
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["track"] = false,
					["parent"] = p34,
					["name"] = "Line_" .. v36.key,
					["text"] = v36.text,
					["style"] = v_u_33 and v36.key ~= "main" and "small" or (v_u_21[v36.key] or "body"),
					["color"] = v37,
					["order"] = v35
				})
			end
		end,
		["buttons"] = {
			{
				["text"] = nil,
				["kind"] = "primary",
				["onClick"] = nil,
				["text"] = v_u_32.button,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_5, (copy) p_u_23, (ref) v_u_3, (copy) p_u_22
					v_u_5[p_u_23.t] = os.clock()
					v_u_3 = nil
					p_u_22.op({
						["op"] = "noticeSeen",
						["t"] = nil,
						["t"] = p_u_23.t
					})
				end
			}
		}
	})
	v_u_3 = {
		["api"] = v38,
		["t"] = p_u_23.t
	}
	return v38
end
function v_u_1.maybe(p_u_39, _) -- name: maybe
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_1, (ref) v_u_4, (copy) v_u_5, (copy) v_u_2
	v_u_7 = p_u_39
	if not v_u_6 then
		v_u_6 = true
		local v40 = p_u_39.cctx.on
		local function v47()
			-- upvalues: (ref) v_u_1, (copy) p_u_39
			if v_u_1.isOpen() then
				v_u_1.close()
				local v41 = p_u_39
				local v42 = v41.profile
				local v43
				if type(v42) == "table" then
					local v44 = v41.cctx.shared.ConnGuard.view
					local v45 = v42.notice
					local v46
					v46, v43 = pcall(v44, v45)
					if not v46 then
						v43 = nil
					end
				else
					v43 = nil
				end
				if v43 then
					v_u_1.maybe(p_u_39, p_u_39.profile)
				end
			end
		end
		pcall(v40, "ui.rebuild", v47)
	end
	if not v_u_4 then
		v_u_4 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_1, (ref) v_u_5, (ref) v_u_2, (ref) v_u_4
			local v48 = os.clock()
			local v49 = nil
			while os.clock() - v48 < 900 do
				task.wait(0.4)
				local v50 = v_u_7
				local v51 = v50.profile
				local v52
				if type(v51) == "table" then
					local v53 = v50.cctx.shared.ConnGuard.view
					local v54 = v51.notice
					local v55
					v55, v52 = pcall(v53, v54)
					if not v55 then
						v52 = nil
					end
				else
					v52 = nil
				end
				if v52 == nil or v_u_1.isOpen() then
					break
				end
				local v56 = v_u_5[v52.t]
				if (not v56 or os.clock() - v56 >= 20) and v_u_1.idle(v_u_7) then
					v49 = v49 or os.clock()
					if os.clock() - v49 < 1.2 then
						continue
					end
					local v57 = v_u_1.show
					local v58 = v_u_7
					local v59, v60 = pcall(v57, v58, v52)
					if not v59 then
						warn("[MenuConnNotice] show failed:", v60)
						v_u_2:SetAttribute("ClientError", "conn notice: " .. tostring(v60))
					end
					break
				end
				v49 = nil
			end
			v_u_4 = false
		end)
	end
end
return v_u_1