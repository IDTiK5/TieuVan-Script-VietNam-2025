-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCratesSkins

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v_u_2:WaitForChild("Skins"))
local v_u_4 = require(v_u_2:WaitForChild("CaseOdds"))
local v_u_5 = require(v_u_2:WaitForChild("SkinRules"))
local v_u_6 = nil
local v_u_7 = nil
local function v8()
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (ref) v_u_7
	v_u_6 = require(v_u_2:WaitForChild("SeasonRules"))
	v_u_7 = require(v_u_2:WaitForChild("GameMode"))
end
pcall(v8)
local v_u_9 = nil
local function v11()
	-- upvalues: (ref) v_u_9
	local v10 = script.Parent:FindFirstChild("TallyMark")
	if v10 then
		v_u_9 = require(v10)
	end
end
pcall(v11)
v_u_1.TEXT = {
	["copies"] = "COPIES",
	["bestRaid"] = "Best raid %s",
	["tallyHead"] = "TALLY",
	["factory"] = "FACTORY",
	["factoryBlurb"] = "No finish. The weapon as it comes.",
	["equip"] = "EQUIP",
	["equipped"] = "EQUIPPED",
	["noSkins"] = "No finishes yet. Open a case to find some.",
	["owned"] = "OWNED"
}
local v_u_12 = {
	"COMMON",
	"UNCOMMON",
	"RARE",
	"EPIC",
	"LEGENDARY",
	"MYTHIC",
	"SIGNATURE"
}
v_u_1.RARITY_WORD = v_u_12
function v_u_1.weaponRows(p13) -- name: weaponRows
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v14
	if type(p13) == "table" then
		local v15 = p13.owned
		v14 = type(v15) ~= "table" and {} or p13.owned
	else
		v14 = {}
	end
	local v16
	if type(p13) == "table" then
		local v17 = p13.equipped
		v16 = type(v17) ~= "table" and {} or p13.equipped
	else
		v16 = {}
	end
	local v18 = {}
	for _, v19 in v_u_3.weapons() do
		local v20 = v_u_3.byWeapon(v19)
		local v21 = 0
		for _, v22 in v20 do
			if not v14[v22.id] then
				continue
			end
			v21 = v21 + 1
		end
		local v23 = v_u_3.get(v16[v19])
		local v24 = {
			["weapon"] = v19,
			["name"] = v_u_3.weaponName(v19) or v19,
			["total"] = #v20,
			["owned"] = v21
		}
		local v25
		if v23 and v23.weapon == v19 then
			v25 = v23.name
		else
			v25 = nil
		end
		v24.equippedName = v25
		v24.tallyK = v_u_1.equippedTally(p13, v19)
		table.insert(v18, v24)
	end
	table.sort(v18, function(p26, p27)
		return string.lower(p26.name) < string.lower(p27.name)
	end)
	return v18
end
function v_u_1.chooseWeapon(p28, p29) -- name: chooseWeapon
	if p29 then
		for _, v30 in p28 do
			if v30.weapon ~= p29 then
				continue
			end
			return p29
		end
	end
	for _, v31 in p28 do
		if v31.owned <= 0 then
			continue
		end
		return v31.weapon
	end
	if p28[1] then
		return p28[1].weapon
	else
		return nil
	end
end
function v_u_1.cardState(p32, p33) -- name: cardState
	local v34
	if type(p32) == "table" then
		local v35 = p32.owned
		v34 = type(v35) ~= "table" and {} or p32.owned
	else
		v34 = {}
	end
	local v36
	if type(p32) == "table" then
		local v37 = p32.equipped
		v36 = type(v37) ~= "table" and {} or p32.equipped
	else
		v36 = {}
	end
	return v36[p33.weapon] == p33.id and "equipped" or (v34[p33.id] and "equip" or "locked")
end
function v_u_1.copyState(p38, p39) -- name: copyState
	-- upvalues: (copy) v_u_5
	local v40
	if type(p38) == "table" then
		local v41 = p38.copies
		v40 = type(v41) ~= "table" and {} or p38.copies
	else
		v40 = {}
	end
	local v42
	if type(p39) == "table" then
		local v43 = v40[p39.id]
		if type(v43) == "number" then
			local v44 = v40[p39.id]
			local v45 = math.floor(v44)
			v42 = math.max(0, v45)
		else
			v42 = 0
		end
	else
		v42 = 0
	end
	local v46 = v42 >= 1
	local v47
	if v42 < 1 then
		v47 = v_u_5.TEXT.noSpare
	else
		v47 = nil
	end
	return {
		["copies"] = nil,
		["total"] = nil,
		["can"] = nil,
		["why"] = nil,
		["label"] = "DISCARD COPY",
		["confirm"] = nil,
		["copies"] = v42,
		["total"] = v42 + 1,
		["can"] = v46,
		["why"] = v47,
		["confirm"] = v_u_5.TEXT.discardAsk
	}
end
function v_u_1.copiesCount(p48, p49) -- name: copiesCount
	local v50
	if type(p48) == "table" and p48.uid == true then
		local v51 = p48.items
		if type(v51) == "table" and type(p49) == "string" then
			v50 = p48.items[p49]
			if type(v50) ~= "table" then
				v50 = nil
			end
		else
			v50 = nil
		end
	else
		v50 = nil
	end
	if v50 then
		local v52 = v50.n
		if type(v52) == "number" then
			local v53 = v50.n
			local v54 = math.floor(v53)
			return math.max(0, v54)
		end
	end
	return 0
end
function v_u_1.tallyOf(p55, p56) -- name: tallyOf
	-- upvalues: (ref) v_u_9
	local v57
	if type(p55) == "table" and p55.uid == true then
		local v58 = p55.items
		if type(v58) == "table" and type(p56) == "string" then
			v57 = p55.items[p56]
			if type(v57) ~= "table" then
				v57 = nil
			end
		else
			v57 = nil
		end
	else
		v57 = nil
	end
	if v57 ~= nil then
		local v59 = v57.tally
		if type(v59) == "table" and #v57.tally ~= 0 then
			local v60 = v57.tally[1]
			if type(v60) == "table" then
				local v61 = v57.tally[1]
				local v62 = v61.k
				local v63
				if type(v62) == "number" and v61.k == v61.k then
					local v64 = v61.k
					local v65 = math.floor(v64)
					v63 = math.max(0, v65)
				else
					v63 = 0
				end
				local v66 = #v57.tally
				local v67 = v66 >= 12
				local v68
				if v_u_9 then
					v68 = v_u_9.chipText(v63)
				else
					v68 = "TALLY " .. tostring(v63)
				end
				if v66 > 1 then
					v68 = v68 .. "  x" .. tostring(v66) .. (v67 and "+" or "")
				end
				return {
					["count"] = v66,
					["more"] = v67,
					["best"] = v63,
					["text"] = v68,
					["level"] = not v_u_9 and 0 or v_u_9.level(v63),
					["br"] = v61.br,
					["b"] = v61.b
				}
			end
		end
	end
	return nil
end
function v_u_1.equippedTally(p69, p70) -- name: equippedTally
	if type(p69) ~= "table" or (p69.uid ~= true or type(p70) ~= "string") then
		return nil
	end
	local v71 = p69.equipped
	local v72
	if type(v71) == "table" then
		v72 = p69.equipped[p70]
	else
		v72 = nil
	end
	local v73 = p69.equippedUid
	local v74
	if type(v73) == "table" then
		v74 = p69.equippedUid[p70]
	else
		v74 = nil
	end
	local v75
	if type(p69) == "table" and p69.uid == true then
		local v76 = p69.items
		if type(v76) == "table" and type(v72) == "string" then
			v75 = p69.items[v72]
			if type(v75) ~= "table" then
				v75 = nil
			end
		else
			v75 = nil
		end
	else
		v75 = nil
	end
	if v74 ~= nil and v75 ~= nil then
		local v77 = v75.tally
		if type(v77) == "table" then
			for _, v78 in v75.tally do
				if type(v78) ~= "table" or v78.uid ~= v74 then
					continue
				end
				return v78.k
			end
			return nil
		end
	end
	return nil
end
function v_u_1.tallyNote(p79, p80) -- name: tallyNote
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	if type(p80) == "table" then
		local v81 = v_u_1.tallyOf(p79, p80.id)
		if v81 == nil or v81.more then
			return nil
		else
			local v82 = p79.equipped
			if type(v82) == "table" and p79.equipped[p80.weapon] == p80.id then
				if v_u_1.equippedTally(p79, p80.weapon) == nil then
					return v_u_5.TEXT.tallyNotEquipped
				else
					return nil
				end
			else
				return nil
			end
		end
	else
		return nil
	end
end
function v_u_1.scrapTarget(p83, p84) -- name: scrapTarget
	-- upvalues: (copy) v_u_1
	local v85
	if type(p84) == "table" then
		v85 = p84.id
	else
		v85 = nil
	end
	local v86
	if type(p83) == "table" and p83.uid == true then
		local v87 = p83.items
		if type(v87) == "table" and type(v85) == "string" then
			v86 = p83.items[v85]
			if type(v86) ~= "table" then
				v86 = nil
			end
		else
			v86 = nil
		end
	else
		v86 = nil
	end
	if v86 == nil then
		return "default"
	end
	local v88 = v_u_1.copiesCount(p83, p84.id)
	if v88 <= 1 then
		return "none"
	end
	local v89 = v86.tally
	local v90 = type(v89) ~= "table" and {} or v86.tally
	local v91 = v88 - #v90
	local v92 = p83.equipped
	local v93
	if type(v92) == "table" then
		v93 = p83.equipped[p84.weapon]
	else
		v93 = nil
	end
	local v94 = p83.equippedUid
	local v95
	if type(v94) == "table" then
		v95 = p83.equippedUid[p84.weapon]
	else
		v95 = nil
	end
	local v96
	if v93 == p84.id and v95 ~= nil then
		v96 = 1
		for _, v97 in v90 do
			if type(v97) ~= "table" or v97.uid ~= v95 then
				continue
			end
			v96 = 0
		end
	else
		v96 = 0
	end
	return v91 - v96 >= 1 and "default" or (#v90 >= 1 and "pick" or "none")
end
v_u_1.PASS_LINE = "Earned in the BATTLE PASS"
v_u_1.PASS_OTHER_LINE = "Only in the BATTLE PASS of the other game"
function v_u_1.passLine(p98, p99) -- name: passLine
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_1
	if p99 == nil and v_u_7 ~= nil then
		local v100 = v_u_7.id
		local v101
		v101, p99 = pcall(v100)
		if not v101 then
			p99 = nil
		end
	end
	if v_u_6 ~= nil and (p99 == "pve" or p99 == "pvpve") then
		local v102 = p99 == "pve" and "pvpve" or "pve"
		if not v_u_6.rewardIn(nil, p98, p99) and v_u_6.rewardIn(nil, p98, v102) then
			return v_u_1.PASS_OTHER_LINE
		end
	end
	return v_u_1.PASS_LINE
end
function v_u_1.foundIn(p103, p104) -- name: foundIn
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v105 = {}
	for _, v106 in p103.crates or {} do
		local v107 = v_u_4.get(v106)
		if not v107 then
			continue
		end
		local v108 = v107.name
		table.insert(v105, v108)
	end
	if #v105 == 0 then
		return p103.reward == "hunt" and "Earned in the Hollow Hunt" or (p103.reward == "store" and "Only in the CRIMSON NIGHT PACK" or (p103.reward ~= "season" and "Found in cases" or v_u_1.passLine(p103.id, p104)))
	else
		return "Found in " .. table.concat(v105, " or ")
	end
end
function v_u_1.new(p_u_109, p_u_110) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_1, (ref) v_u_9, (copy) v_u_12
	local v_u_111 = p_u_109.ui
	local v_u_112 = p_u_109.theme
	local v_u_113 = v_u_112.color
	local v_u_114 = p_u_110.phone == true
	local v_u_115 = p_u_110.compact == true
	local v116, v_u_117 = pcall(function()
		-- upvalues: (copy) p_u_109
		return p_u_109.cctx.lib.SkinPreview
	end)
	if not v116 then
		v_u_117 = nil
	end
	local v118, v_u_119 = pcall(function()
		-- upvalues: (copy) p_u_109
		return p_u_109.cctx.lib.SkinTile
	end)
	if not v118 then
		v_u_119 = nil
	end
	local v_u_120 = {}
	local v_u_121 = {}
	local v_u_122 = v_u_111.new("Frame", {
		["Name"] = "SkinsView",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v_u_121.frame = v_u_122
	local v_u_123 = nil
	local v_u_124 = nil
	local v_u_125 = nil
	local v_u_126 = true
	local function v_u_135(p127, p128) -- name: swatchOf
		-- upvalues: (ref) v_u_2, (copy) v_u_113
		local v129 = nil
		for _, v130 in p128.crates or {} do
			for _, v131 in v130.pool or {} do
				if v131.skin ~= p127.id or not v131.swatch then
					continue
				end
				v129 = v131.swatch
			end
		end
		if v129 == nil then
			local function v132()
				-- upvalues: (ref) v_u_2
				return require(v_u_2:WaitForChild("SkinFinishes"))
			end
			local v133, v134 = pcall(v132)
			if v133 then
				v129 = v134.get(p127.finish)
			else
				v129 = nil
			end
			if v129 then
				v129 = v129.swatch
			end
		end
		return type(v129) == "table" and (v129[1] and v129[2]) and { Color3.fromRGB(v129[1][1], v129[1][2], v129[1][3]), Color3.fromRGB(v129[2][1], v129[2][2], v129[2][3]) } or { v_u_113.raised2, v_u_113.raised }
	end
	local function v_u_147(p136, p137, p138, p139) -- name: swatchFrame
		-- upvalues: (copy) v_u_135, (ref) v_u_119, (copy) v_u_113, (copy) v_u_120, (copy) v_u_111
		local v140 = v_u_135(p137, p138)
		if v_u_119 then
			local v141 = v_u_119.new
			local v142 = {
				["size"] = p139,
				["weaponId"] = p137.weapon,
				["skinId"] = p137.id,
				["colors"] = v140,
				["line"] = v_u_113.line
			}
			local v143, v144 = pcall(v141, p136, v142)
			if v143 and (type(v144) == "table" and v144.frame) then
				local v145 = v_u_120
				table.insert(v145, v144)
				return v144.frame
			end
		end
		local v146 = v_u_111.new("Frame", {
			["Name"] = "Swatch",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.08,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v140[1],
			["Size"] = UDim2.fromOffset(p139, p139)
		}, p136)
		v_u_111.new("UIGradient", {
			["Color"] = nil,
			["Rotation"] = 45,
			["Color"] = ColorSequence.new(v140[1], v140[2])
		}, v146)
		v_u_111.stroke(v146, v_u_113.line)
		return v146
	end
	local function v_u_156(p148) -- name: openCopies
		-- upvalues: (ref) v_u_3, (copy) p_u_109, (ref) v_u_1, (copy) p_u_110
		local v149 = v_u_3.get(p148)
		if v149 == nil then
			return
		else
			local function v150()
				-- upvalues: (ref) p_u_109
				return p_u_109.cctx.lib.MenuCratesCopies
			end
			local v151, v152 = pcall(v150)
			if v151 and type(v152) == "table" then
				local v153 = v152.open
				local v154 = p_u_109
				local v155 = {
					["skin"] = p148,
					["weapon"] = v149.weapon,
					["total"] = v_u_1.copiesCount(p_u_110.view(), p148)
				}
				pcall(v153, v154, v155)
			end
		end
	end
	v_u_121.openCopies = v_u_156
	local function v_u_173(p157, p_u_158, p159, p160, p161, p162) -- name: drawWeapon
		-- upvalues: (copy) v_u_111, (copy) v_u_113, (ref) v_u_9, (copy) v_u_114, (copy) v_u_112, (ref) v_u_123, (ref) v_u_124, (copy) v_u_121
		local v163 = v_u_111.new
		local v164 = "TextButton"
		local v165 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Weapon_" .. p_u_158.weapon,
			["BackgroundColor3"] = v_u_113.raised,
			["BackgroundTransparency"] = p159 and 0.05 or 0.35
		}
		local v166
		if p160 then
			v166 = UDim2.fromOffset(p160, p161)
		else
			v166 = UDim2.new(1, 0, 0, p161)
		end
		v165.Size = v166
		v165.LayoutOrder = p162
		local v167 = v163(v164, v165, p157)
		local v168 = v_u_111.stroke
		local v169
		if p159 then
			v169 = v_u_113.accent
		else
			v169 = v_u_113.line
		end
		v168(v167, v169)
		if p159 then
			v_u_111.new("Frame", {
				["Name"] = "Mark",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_113.accent,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v167)
		end
		local v170 = ((p_u_158.tallyK == nil or not v_u_9) and 0 or 24) + 24
		v_u_111.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v167,
			["text"] = p_u_158.name,
			["position"] = UDim2.fromOffset(14, 4),
			["size"] = UDim2.new(1, -v170, 0, 22)
		})
		local v171 = ("%d / %d owned"):format(p_u_158.owned, p_u_158.total)
		if p_u_158.equippedName and not v_u_114 then
			v171 = v171 .. "   " .. p_u_158.equippedName
		end
		v_u_111.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v167,
			["text"] = v171,
			["color"] = v_u_113.text2,
			["position"] = UDim2.fromOffset(14, 26),
			["size"] = UDim2.new(1, -v170, 0, 18)
		})
		if p_u_158.tallyK ~= nil and v_u_9 then
			local v172 = v_u_9.new(v167, {
				["size"] = 16,
				["level"] = nil,
				["name"] = "TallySign",
				["level"] = v_u_9.level(p_u_158.tallyK)
			})
			v172.frame.AnchorPoint = Vector2.new(1, 0.5)
			v172.frame.Position = UDim2.new(1, -10, 0.5, 0)
		end
		v167.Activated:Connect(function()
			-- upvalues: (ref) v_u_111, (ref) v_u_112, (ref) v_u_123, (copy) p_u_158, (ref) v_u_124, (ref) v_u_121
			v_u_111.sound(v_u_112.sounds.click)
			if v_u_123 ~= p_u_158.weapon then
				v_u_123 = p_u_158.weapon
				v_u_124 = nil
				v_u_121._factoryPicked = false
				v_u_121.draw()
			end
		end)
		return v167
	end
	local function v_u_224(p174, p175, p_u_176, p177, p178) -- name: skinCard
		-- upvalues: (ref) v_u_123, (ref) v_u_1, (ref) v_u_124, (copy) v_u_112, (copy) v_u_114, (ref) v_u_9, (copy) v_u_111, (copy) v_u_113, (copy) v_u_147, (ref) v_u_119, (copy) v_u_120, (copy) p_u_110, (ref) v_u_12, (copy) v_u_156, (copy) v_u_121
		local v_u_179 = p_u_176 == nil
		local v180
		if v_u_179 then
			v180 = p175.equipped[v_u_123] == nil and "equipped" or "equip"
		else
			v180 = v_u_1.cardState(p175, p_u_176)
		end
		local v181
		if v_u_124 == nil and v_u_179 then
			v181 = v_u_179
		elseif p_u_176 == nil then
			v181 = false
		else
			v181 = v_u_124 == p_u_176.id
		end
		local v182 = v_u_112.touch(v_u_114 and 64 or 74)
		local v183
		if p_u_176 then
			v183 = v_u_1.copyState(p175, p_u_176)
		else
			v183 = nil
		end
		local v184
		if v183 == nil then
			v184 = false
		else
			v184 = v183.copies > 0
		end
		local v185
		if p_u_176 and v_u_9 then
			v185 = v_u_1.tallyOf(p175, p_u_176.id)
		else
			v185 = nil
		end
		local v186
		if p_u_176 and v_u_9 then
			v186 = v_u_1.tallyNote(p175, p_u_176)
		else
			v186 = nil
		end
		local v187 = v182 + (not v184 and 0 or v_u_112.touch(44) + 8) + (v186 and 20 or 0)
		local v188
		if v184 then
			local v189 = UDim2.new
			local v190 = v182 / 2
			v188 = v189(1, -10, 0, (math.floor(v190)))
		else
			v188 = UDim2.new(1, -10, 0.5, 0)
		end
		local v191 = v_u_111.new
		local v192 = "TextButton"
		local v193 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Skin_" .. (not p_u_176 and "factory" or p_u_176.id),
			["BackgroundColor3"] = v_u_113.raised
		}
		local v194
		if p178 then
			v194 = UDim2.fromOffset(p178, v187)
		else
			v194 = UDim2.new(1, 0, 0, v187)
		end
		v193.Size = v194
		v193.LayoutOrder = p177
		local v195 = v191(v192, v193, p174)
		local v196 = v_u_111.stroke
		local v197
		if v181 then
			v197 = v_u_113.accent
		else
			v197 = v_u_113.line
		end
		v196(v195, v197)
		local v198
		if p_u_176 then
			v198 = v_u_112.rarityColor(p_u_176.rarity)
		else
			v198 = v_u_113.lineStrong
		end
		local v199 = v_u_111.new("Frame", {
			["Name"] = "Rarity",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v198,
			["Size"] = UDim2.new(0, 4, 1, 0)
		}, v195)
		if p_u_176 and p_u_176.rarity == 7 then
			v_u_111.new("UIGradient", {
				["Color"] = nil,
				["Rotation"] = 90,
				["Color"] = ColorSequence.new(v198, v_u_112.rarityEdge(7))
			}, v199)
		end
		local v200
		if p_u_176 then
			v200 = v_u_147(v195, p_u_176, p175, 44)
		else
			local v201, v202
			if v_u_119 and v_u_123 then
				local v203 = v_u_119.new
				local v204 = {
					["size"] = 44,
					["weaponId"] = nil,
					["colors"] = nil,
					["line"] = nil,
					["transparency"] = 0,
					["weaponId"] = v_u_123,
					["colors"] = { v_u_113.raised2, v_u_113.raised },
					["line"] = v_u_113.line
				}
				v201, v202 = pcall(v203, v195, v204)
			else
				v201 = false
				v202 = nil
			end
			if v201 and (type(v202) == "table" and v202.frame) then
				local v205 = v_u_120
				table.insert(v205, v202)
				v200 = v202.frame
			else
				v200 = v_u_111.new("Frame", {
					["Name"] = "Swatch",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_113.raised2,
					["Size"] = UDim2.fromOffset(44, 44)
				}, v195)
				v_u_111.stroke(v200, v_u_113.line)
			end
		end
		v200.AnchorPoint = Vector2.new(0, 0.5)
		local v206
		if v184 then
			local v207 = UDim2.new
			local v208 = v182 / 2
			v206 = v207(0, 14, 0, (math.floor(v208)))
		else
			v206 = UDim2.new(0, 14, 0.5, 0)
		end
		v200.Position = v206
		local v209 = v_u_114 and 150 or 126
		local v210 = nil
		if v180 == "equipped" then
			local v211
			v210, v211 = v_u_111.button({
				["parent"] = nil,
				["text"] = nil,
				["disabled"] = true,
				["width"] = nil,
				["height"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["name"] = "Equipped",
				["parent"] = v195,
				["text"] = v_u_1.TEXT.equipped,
				["width"] = v209,
				["height"] = v_u_114 and 36 or 38,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = v188
			})
			v211.setEnabled(false)
		elseif v180 == "equip" then
			v210 = v_u_111.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "primary",
				["width"] = nil,
				["height"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["name"] = "Equip",
				["zindex"] = 3,
				["onClick"] = nil,
				["parent"] = v195,
				["text"] = v_u_1.TEXT.equip,
				["width"] = v209,
				["height"] = v_u_114 and 36 or 38,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = v188,
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_110, (copy) v_u_179, (ref) v_u_123, (copy) p_u_176
					if p_u_110.busy and p_u_110.busy() then
						return
					elseif v_u_179 then
						p_u_110.unequip(v_u_123)
					else
						p_u_110.equip(p_u_176.weapon, p_u_176.id)
					end
				end
			})
		end
		local v212 = UDim2.new(1, -((not v210 and 8 or v209 + 20) + 70), 0, 20)
		local v213
		if p_u_176 then
			v213 = p_u_176.name
		else
			v213 = v_u_1.TEXT.factory
		end
		if v184 then
			local v214 = v183.total
			v213 = v213 .. "  x" .. tostring(v214)
		end
		v_u_111.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "bodyStrong",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v195,
			["text"] = v213,
			["position"] = UDim2.fromOffset(70, v_u_114 and 6 or 10),
			["size"] = v212
		})
		local v215 = p_u_176 and (v_u_12[p_u_176.rarity] or "") or "DEFAULT"
		v_u_111.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v195,
			["text"] = v215,
			["color"] = v198,
			["position"] = UDim2.fromOffset(70, v_u_114 and 28 or 32),
			["size"] = UDim2.new(1, -((not v210 and 8 or v209 + 24) + 70), 0, 14)
		})
		if v185 and v_u_9 then
			local v216 = v_u_9.colorOf(v185.level, v_u_112)
			local v217 = v_u_111.new("Frame", {
				["Name"] = "TallyChip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v_u_113.bg,
				["Position"] = UDim2.fromOffset((v_u_114 and 84 or 90) + 70, v_u_114 and 26 or 30),
				["Size"] = UDim2.fromOffset(0, 18),
				["AutomaticSize"] = Enum.AutomaticSize.X
			}, v195)
			v_u_111.stroke(v217, v216, 1, 0.4)
			v_u_111.pad(v217, {
				5,
				6,
				0,
				0
			})
			v_u_111.layout(v217, "h", 5).VerticalAlignment = Enum.VerticalAlignment.Center
			v_u_9.new(v217, {
				["size"] = 12,
				["level"] = nil,
				["name"] = "Sign",
				["level"] = v185.level
			}).frame.LayoutOrder = 1
			v_u_111.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v217,
				["text"] = v185.text,
				["color"] = v216,
				["size"] = UDim2.fromOffset(0, 16)
			}).Name = "Count"
		end
		if v186 then
			v_u_111.label({
				["parent"] = nil,
				["name"] = "TallyNote",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["parent"] = v195,
				["text"] = v186,
				["color"] = v_u_113.accent,
				["position"] = UDim2.fromOffset(14, v182 + 2),
				["size"] = UDim2.new(1, -28, 0, 16)
			})
		end
		local v218
		if p_u_176 then
			if v180 == "locked" then
				v218 = v_u_1.foundIn(p_u_176)
			elseif (v180 == "equip" or v180 == "equipped") and (v183 and not v184) then
				v218 = v183.why
			else
				v218 = nil
			end
		else
			v218 = v_u_1.TEXT.factoryBlurb
		end
		if v218 and not v_u_114 then
			v_u_111.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v195,
				["text"] = v218,
				["color"] = v_u_113.muted,
				["position"] = UDim2.fromOffset(70, 48),
				["size"] = UDim2.new(1, -((not v210 and 8 or v209 + 24) + 70), 0, 16)
			})
		elseif v218 and (v_u_114 and v180 == "locked") then
			v_u_111.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["align"] = "right",
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["parent"] = v195,
				["text"] = v218,
				["color"] = v_u_113.muted,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -10, 0.5, 0),
				["size"] = UDim2.fromOffset(190, 20)
			})
		end
		if v184 and p_u_110.scrapCopy then
			local _, v222 = v_u_111.button({
				["parent"] = nil,
				["text"] = nil,
				["kind"] = "secondary",
				["width"] = nil,
				["height"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["name"] = "ScrapCopy",
				["zindex"] = 3,
				["onClick"] = nil,
				["parent"] = v195,
				["text"] = v183.label,
				["width"] = v_u_114 and 270 or 250,
				["height"] = v_u_112.touch(44),
				["anchor"] = Vector2.new(1, 1),
				["position"] = UDim2.new(1, -10, 1, -6),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) p_u_110, (ref) v_u_1, (copy) p_u_176, (ref) v_u_156, (ref) v_u_111
					if p_u_110.busy and p_u_110.busy() then
						return
					else
						local v219 = v_u_1.copyState(p_u_110.view(), p_u_176)
						if v219.can then
							if v_u_1.scrapTarget(p_u_110.view(), p_u_176) == "pick" then
								v_u_156(p_u_176.id)
							else
								local v220 = v_u_111.modal
								local v221 = {
									["title"] = "DISCARD COPY",
									["body"] = nil,
									["width"] = 480,
									["buttons"] = nil,
									["body"] = v219.confirm,
									["buttons"] = {
										{
											["text"] = "CANCEL"
										},
										{
											["text"] = "DISCARD",
											["kind"] = "primary",
											["onClick"] = nil,
											["onClick"] = function() -- name: onClick
												-- upvalues: (ref) p_u_110, (ref) p_u_176
												p_u_110.scrapCopy(p_u_176.id)
											end
										}
									}
								}
								v220(v221)
							end
						else
							return
						end
					end
				end
			})
			v222.setEnabled(v183.can)
			if not v183.can and v183.why then
				v_u_111.label({
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["parent"] = v195,
					["text"] = v183.why,
					["color"] = v_u_113.muted,
					["position"] = UDim2.fromOffset(70, v182 - 22),
					["size"] = UDim2.new(1, -350, 0, 14)
				})
			end
		end
		v195.Activated:Connect(function()
			-- upvalues: (copy) p_u_176, (ref) v_u_124, (ref) v_u_121
			local v223
			if p_u_176 then
				v223 = p_u_176.id
			else
				v223 = nil
			end
			if v_u_124 ~= v223 then
				v_u_124 = v223
				v_u_121._factoryPicked = v223 == nil
				v_u_121.draw()
			end
		end)
		return v195
	end
	local function v_u_238(p225, _, p226, p227) -- name: previewBlock
		-- upvalues: (copy) v_u_111, (copy) v_u_113, (ref) v_u_3, (ref) v_u_124, (ref) v_u_117, (ref) v_u_125, (ref) v_u_123
		local v228 = v_u_111.new("Frame", {
			["Name"] = "PreviewBox",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v_u_113.raised,
			["Size"] = UDim2.new(1, 0, 0, p226),
			["LayoutOrder"] = p227
		}, p225)
		v_u_111.stroke(v228, v_u_113.line)
		local v229 = v_u_3.get(v_u_124)
		if v_u_117 then
			if v_u_125 then
				local v230 = v_u_125.destroy
				pcall(v230)
				v_u_125 = nil
			end
			local v231 = v_u_117.new
			local v232 = {
				["size"] = UDim2.new(1, -16, 1, -16),
				["position"] = UDim2.fromOffset(8, 8)
			}
			local v233, v234 = pcall(v231, v228, v232)
			if v233 then
				v_u_125 = v234
				local v235 = v234.show
				local v236 = v_u_123
				local v237
				if v229 and v229.weapon == v_u_123 then
					v237 = v229.id
				else
					v237 = nil
				end
				pcall(v235, v236, v237)
				return v228
			end
			warn("[MenuCratesSkins] preview failed: " .. tostring(v234))
		end
		return v228
	end
	local function v_u_281(p239, p240) -- name: infoBlock
		-- upvalues: (ref) v_u_3, (ref) v_u_124, (copy) v_u_111, (ref) v_u_123, (ref) v_u_1, (ref) v_u_12, (copy) v_u_112, (copy) v_u_113, (ref) v_u_2, (copy) p_u_110, (ref) v_u_9, (copy) p_u_109, (copy) v_u_156
		local v_u_241 = v_u_3.get(v_u_124)
		local v242 = v_u_111.new("Frame", {
			["Name"] = "Info",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p240
		}, p239)
		v_u_111.layout(v242, "v", 2)
		local v243 = v_u_3.weaponName(v_u_123)
		if not v243 then
			local v244 = v_u_123
			v243 = tostring(v244)
		end
		local v245 = v_u_111.label
		local v246 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "h3",
			["size"] = nil,
			["order"] = 1,
			["parent"] = v242
		}
		local v247
		if v_u_241 then
			v247 = v_u_241.name
		else
			v247 = v_u_1.TEXT.factory
		end
		v246.text = v247
		v246.size = UDim2.new(1, 0, 0, 24)
		v245(v246)
		local v248 = v_u_111.label
		local v249 = {
			["parent"] = nil,
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["order"] = 2,
			["parent"] = v242,
			["text"] = v243 .. "   " .. (v_u_241 and (v_u_12[v_u_241.rarity] or "") or "DEFAULT")
		}
		local v250
		if v_u_241 then
			v250 = v_u_112.rarityColor(v_u_241.rarity)
		else
			v250 = v_u_113.text2
		end
		v249.color = v250
		v249.size = UDim2.new(1, 0, 0, 16)
		v248(v249)
		local v251 = v_u_1.TEXT.factoryBlurb
		if v_u_241 then
			local function v252()
				-- upvalues: (ref) v_u_2
				return require(v_u_2:WaitForChild("SkinFinishes"))
			end
			local v253, v254 = pcall(v252)
			local v255
			if v253 then
				v255 = v254.get(v_u_241.finish)
			else
				v255 = nil
			end
			v251 = not (v255 and v255.blurb) and "" or v255.blurb
		end
		v_u_111.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 3,
			["parent"] = v242,
			["text"] = v251,
			["color"] = v_u_113.text2
		})
		local v256 = p_u_110.view()
		local v257 = not v_u_241 and 0 or v_u_1.copiesCount(v256, v_u_241.id)
		local v258
		if v_u_241 then
			v258 = v_u_1.tallyOf(v256, v_u_241.id)
		else
			v258 = nil
		end
		if v_u_241 and (v257 >= 2 or v258 ~= nil) then
			local v259 = v_u_111.new("Frame", {
				["Name"] = "TallyInfo",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 4,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v242)
			v_u_111.layout(v259, "v", 6)
			local v260 = 0
			local v261
			if v258 and v_u_9 then
				local v262 = v_u_9.colorOf(v258.level, v_u_112)
				local v263 = v_u_111.new
				local v264 = {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 26)
				}
				v260 = v260 + 1
				v264.LayoutOrder = v260
				local v265 = v263("Frame", v264, v259)
				v_u_111.layout(v265, "h", 8).VerticalAlignment = Enum.VerticalAlignment.Center
				v_u_9.new(v265, {
					["size"] = 20,
					["level"] = nil,
					["name"] = "Sign",
					["level"] = v258.level
				}).frame.LayoutOrder = 1
				v_u_111.label({
					["parent"] = nil,
					["name"] = "Best",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["autoX"] = true,
					["size"] = nil,
					["order"] = 2,
					["track"] = false,
					["parent"] = v265,
					["text"] = v258.text,
					["color"] = v262,
					["size"] = UDim2.fromOffset(0, 24)
				})
				local v266 = v258.br
				if type(v266) == "number" then
					local v267 = v_u_111.label
					local v268 = {
						["parent"] = nil,
						["name"] = "BestRaid",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["size"] = nil,
						["order"] = nil,
						["track"] = false,
						["parent"] = v259,
						["text"] = v_u_1.TEXT.bestRaid:format(v_u_9.commas(v258.br)),
						["color"] = v_u_113.text2,
						["size"] = UDim2.new(1, 0, 0, 16)
					}
					v260 = v260 + 1
					v268.order = v260
					v267(v268)
					v261 = v260
				else
					v261 = v260
				end
				local function v269()
					-- upvalues: (ref) p_u_109
					return p_u_109.cctx.lib.MenuCratesCopies
				end
				local v270, v271 = pcall(v269)
				local v272 = (not v270 or type(v271) ~= "table") and {} or v271.breakdownRows(v258.b, 5)
				if #v272 > 0 then
					local v273 = v_u_111.new
					local v274 = {
						["Name"] = "Breakdown",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y
					}
					v260 = v261 + 1
					v274.LayoutOrder = v260
					local v275 = v273("Frame", v274, v259)
					local v276 = v_u_111.layout(v275, "h", 6)
					v276.Wraps = true
					v276.SortOrder = Enum.SortOrder.LayoutOrder
					v261 = v260
					for v277, v278 in v272 do
						v_u_111.badge(("%s %s"):format(v278.label, v_u_9.commas(v278.n)), "muted", {
							["parent"] = nil,
							["order"] = nil,
							["height"] = 22,
							["parent"] = v275,
							["order"] = v277
						})
					end
				end
			else
				v261 = v260
			end
			if v257 >= 2 or v258 ~= nil then
				local v279 = v_u_111.button
				local v280 = {
					["parent"] = nil,
					["text"] = nil,
					["kind"] = "secondary",
					["width"] = 170,
					["height"] = nil,
					["name"] = "Copies",
					["order"] = nil,
					["onClick"] = nil,
					["parent"] = v259,
					["text"] = ("%s (%d)"):format(v_u_1.TEXT.copies, v257),
					["height"] = v_u_112.touch(40)
				}
				v260 = v261 + 1
				v280.order = v260
				function v280.onClick() -- name: onClick
					-- upvalues: (ref) v_u_156, (copy) v_u_241
					v_u_156(v_u_241.id)
				end
				v279(v280)
			end
		end
		return v242
	end
	function v_u_121.draw() -- name: draw
		-- upvalues: (ref) v_u_126, (copy) p_u_110, (ref) v_u_125, (copy) v_u_120, (copy) v_u_122, (ref) v_u_1, (ref) v_u_123, (copy) v_u_111, (copy) v_u_113, (ref) v_u_124, (copy) v_u_121, (ref) v_u_3, (copy) v_u_114, (copy) v_u_112, (copy) v_u_173, (copy) v_u_238, (copy) v_u_281, (copy) v_u_224, (copy) v_u_115
		if v_u_126 then
			local v282 = p_u_110.view()
			if v_u_125 then
				local v283 = v_u_125.destroy
				pcall(v283)
				v_u_125 = nil
			end
			for _, v284 in v_u_120 do
				local v285 = v284.destroy
				pcall(v285)
			end
			table.clear(v_u_120)
			for _, v286 in v_u_122:GetChildren() do
				v286:Destroy()
			end
			if type(v282) == "table" then
				v282.owned = v282.owned or {}
				v282.copies = v282.copies or {}
				v282.equipped = v282.equipped or {}
				local v287 = v_u_1.weaponRows(v282)
				v_u_123 = v_u_1.chooseWeapon(v287, v_u_123)
				if v_u_123 == nil then
					v_u_111.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["parent"] = v_u_122,
						["text"] = v_u_1.TEXT.noSkins,
						["color"] = v_u_113.muted
					})
					return
				else
					if v_u_124 == nil and (v282.equipped[v_u_123] and not v_u_121._factoryPicked) then
						v_u_124 = v282.equipped[v_u_123]
					end
					local v288 = v_u_3.byWeapon(v_u_123)
					if v_u_114 then
						local v289 = v_u_111.list({
							["parent"] = nil,
							["name"] = "PhoneList",
							["size"] = nil,
							["gap"] = 10,
							["padding"] = nil,
							["parent"] = v_u_122,
							["size"] = UDim2.fromScale(1, 1),
							["padding"] = {
								0,
								6,
								0,
								8
							}
						})
						local v_u_290 = v_u_111.list({
							["parent"] = nil,
							["name"] = "Weapons",
							["horizontal"] = true,
							["size"] = nil,
							["gap"] = 8,
							["padding"] = nil,
							["parent"] = v289,
							["size"] = UDim2.new(1, 0, 0, v_u_112.touch(52) + 10),
							["padding"] = {
								0,
								0,
								0,
								6
							}
						})
						v_u_290.LayoutOrder = 1
						local v_u_291 = nil
						for v292, v293 in v287 do
							local v294 = v_u_173(v_u_290, v293, v293.weapon == v_u_123, 190, v_u_112.touch(52), v292)
							if v293.weapon ~= v_u_123 then
								continue
							end
							v_u_291 = v294
						end
						if v_u_291 then
							local v_u_295 = true
							task.defer(function()
								-- upvalues: (copy) v_u_290, (copy) v_u_291, (copy) v_u_295
								local function v301()
									-- upvalues: (ref) v_u_290, (ref) v_u_291, (ref) v_u_295
									if v_u_290.Parent and v_u_291.Parent then
										local v296
										if v_u_295 then
											v296 = v_u_291.AbsolutePosition.X - v_u_290.AbsolutePosition.X + v_u_290.CanvasPosition.X
										else
											v296 = v_u_291.AbsolutePosition.Y - v_u_290.AbsolutePosition.Y + v_u_290.CanvasPosition.Y
										end
										local v297 = v296 - 60
										local v298 = math.max(0, v297)
										local v299 = v_u_290
										local v300
										if v_u_295 then
											v300 = Vector2.new(v298, 0)
										else
											v300 = Vector2.new(0, v298)
										end
										v299.CanvasPosition = v300
									end
								end
								pcall(v301)
							end)
						end
						v_u_238(v289, v282, 210, 2)
						v_u_281(v289, 3)
						local v302 = 4
						v_u_224(v289, v282, nil, v302, nil)
						for _, v303 in v288 do
							v302 = v302 + 1
							v_u_224(v289, v282, v303, v302, nil)
						end
					else
						local v304 = v_u_115 and 230 or 280
						local v305 = v_u_115 and 380 or 440
						local v_u_306 = v_u_111.list({
							["parent"] = nil,
							["name"] = "Weapons",
							["size"] = nil,
							["gap"] = 8,
							["padding"] = nil,
							["parent"] = v_u_122,
							["size"] = UDim2.new(0, v304, 1, 0),
							["padding"] = {
								0,
								6,
								0,
								8
							}
						})
						local v_u_307 = nil
						for v308, v309 in v287 do
							local v310 = v_u_173(v_u_306, v309, v309.weapon == v_u_123, nil, v_u_112.touch(52), v308)
							if v309.weapon ~= v_u_123 then
								continue
							end
							v_u_307 = v310
						end
						if v_u_307 then
							local v_u_311 = false
							task.defer(function()
								-- upvalues: (copy) v_u_306, (copy) v_u_307, (copy) v_u_311
								local function v317()
									-- upvalues: (ref) v_u_306, (ref) v_u_307, (ref) v_u_311
									if v_u_306.Parent and v_u_307.Parent then
										local v312
										if v_u_311 then
											v312 = v_u_307.AbsolutePosition.X - v_u_306.AbsolutePosition.X + v_u_306.CanvasPosition.X
										else
											v312 = v_u_307.AbsolutePosition.Y - v_u_306.AbsolutePosition.Y + v_u_306.CanvasPosition.Y
										end
										local v313 = v312 - 60
										local v314 = math.max(0, v313)
										local v315 = v_u_306
										local v316
										if v_u_311 then
											v316 = Vector2.new(v314, 0)
										else
											v316 = Vector2.new(0, v314)
										end
										v315.CanvasPosition = v316
									end
								end
								pcall(v317)
							end)
						end
						local v318 = v_u_111.new("Frame", {
							["Name"] = "Mid",
							["BackgroundTransparency"] = 1,
							["Position"] = nil,
							["Size"] = nil,
							["Position"] = UDim2.fromOffset(v304 + 14, 0),
							["Size"] = UDim2.new(1, -(v304 + v305 + 28), 1, 0)
						}, v_u_122)
						v_u_111.layout(v318, "v", 10)
						v_u_238(v318, v282, v_u_115 and 230 or 300, 1)
						v_u_281(v318, 2)
						local v319 = v_u_111.list({
							["parent"] = nil,
							["name"] = "Finishes",
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["gap"] = 8,
							["padding"] = nil,
							["parent"] = v_u_122,
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.new(1, 0, 0, 0),
							["size"] = UDim2.new(0, v305, 1, 0),
							["padding"] = {
								0,
								6,
								0,
								8
							}
						})
						v_u_224(v319, v282, nil, 1, nil)
						for v320, v321 in v288 do
							v_u_224(v319, v282, v321, v320 + 1, nil)
						end
					end
				end
			else
				return
			end
		else
			return
		end
	end
	function v_u_121.pick(p322, p323) -- name: pick
		-- upvalues: (ref) v_u_123, (ref) v_u_124, (copy) v_u_121
		if p322 then
			v_u_123 = p322
		end
		v_u_124 = p323
		v_u_121._factoryPicked = p323 == nil
		v_u_121.draw()
	end
	function v_u_121.state() -- name: state
		-- upvalues: (ref) v_u_123, (ref) v_u_124
		return {
			["weapon"] = v_u_123,
			["skin"] = v_u_124
		}
	end
	function v_u_121.destroy() -- name: destroy
		-- upvalues: (ref) v_u_126, (ref) v_u_125, (copy) v_u_120, (copy) v_u_122
		v_u_126 = false
		if v_u_125 then
			local v324 = v_u_125.destroy
			pcall(v324)
			v_u_125 = nil
		end
		for _, v325 in v_u_120 do
			local v326 = v325.destroy
			pcall(v326)
		end
		table.clear(v_u_120)
		v_u_122:Destroy()
	end
	return v_u_121
end
return v_u_1