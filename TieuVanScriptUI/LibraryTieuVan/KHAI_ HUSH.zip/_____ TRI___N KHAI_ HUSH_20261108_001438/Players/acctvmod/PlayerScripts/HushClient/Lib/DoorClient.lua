-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / DoorClient

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("CollectionService")
local v4 = {}
local v_u_5 = nil
local v_u_6 = v_u_2.LocalPlayer
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = nil
local v_u_10 = {}
local function v_u_23(p11, p12) -- name: openCF
	local v13 = p11.model:GetAttribute("ClosedCF")
	if typeof(v13) ~= "CFrame" then
		v13 = nil
	end
	local v14 = p11.model:GetAttribute("HingePos")
	if typeof(v14) ~= "Vector3" then
		local v15 = p11.model:FindFirstChild("Hinge")
		v14 = v15 and v15.Position or nil
	end
	if v13 and v14 then
		local v16 = CFrame.new(v14) * v13.Rotation
		local v17 = v16:ToObjectSpace(v13)
		local v18 = p11.leaf.Size
		local v19
		if v18.X < v18.Z then
			v19 = v13.RightVector
		else
			v19 = v13.LookVector
		end
		local v20 = p12 and ((p12 - v13.Position):Dot(v19) >= 0 and 1 or -1) or 1
		local v21 = v16 * CFrame.Angles(0, 1.6580627893946132, 0) * v17
		local v22 = v16 * CFrame.Angles(0, -1.6580627893946132, 0) * v17
		if (v21.Position - v13.Position):Dot(v19) * v20 < (v22.Position - v13.Position):Dot(v19) * v20 then
			return v21
		else
			return v22
		end
	else
		return nil
	end
end
local function v_u_34(p24) -- name: targetCF
	-- upvalues: (copy) v_u_23
	local v25 = #p24.preds
	if v25 > 0 then
		local v26 = p24.preds[v25]
		if v26.state == "Closed" then
			local v27 = p24.model:GetAttribute("ClosedCF")
			if typeof(v27) ~= "CFrame" then
				v27 = nil
			end
			if not v27 then
				local v28 = p24.model:GetAttribute("LeafCF")
				if typeof(v28) == "CFrame" then
					return v28
				end
				v27 = p24.visual
			end
			return v27
		else
			local v29 = p24.model:GetAttribute("State")
			if (type(v29) ~= "string" and "Closed" or v29) == "Open" then
				local v30 = p24.model:GetAttribute("LeafCF")
				if typeof(v30) == "CFrame" then
					return v30
				else
					return p24.visual
				end
			else
				local v31 = v_u_23(p24, v26.from)
				if not v31 then
					local v32 = p24.model:GetAttribute("LeafCF")
					if typeof(v32) == "CFrame" then
						return v32
					end
					v31 = p24.visual
				end
				return v31
			end
		end
	else
		local v33 = p24.model:GetAttribute("LeafCF")
		if typeof(v33) == "CFrame" then
			return v33
		else
			return p24.visual
		end
	end
end
local function v_u_49(p35, p36) -- name: leaf2Pose
	local v37 = p35.model:GetAttribute("ClosedCF")
	if typeof(v37) ~= "CFrame" then
		v37 = nil
	end
	local v38 = p35.model:GetAttribute("HingePos")
	if typeof(v38) ~= "Vector3" then
		local v39 = p35.model:FindFirstChild("Hinge")
		v38 = v39 and v39.Position or nil
	end
	local v40 = p35.model:GetAttribute("ClosedCF2")
	local v41 = p35.model:GetAttribute("HingePos2")
	if not v37 or (not v38 or (typeof(v40) ~= "CFrame" or typeof(v41) ~= "Vector3")) then
		return nil
	end
	local v42 = CFrame.new(v38) * v37.Rotation
	local v43 = v42:ToObjectSpace(v37)
	local _, v44, _ = (v42:ToObjectSpace(p36) * v43:Inverse()):ToEulerAnglesYXZ()
	local v45 = v42 * CFrame.Angles(0, v44, 0) * v43
	local v46 = CFrame.new(v41) * v40.Rotation
	local v47 = v46 * CFrame.Angles(0, -v44, 0) * v46:ToObjectSpace(v40)
	local v48 = p36.Y - v45.Y
	return v47 + Vector3.new(0, v48, 0)
end
local function v_u_57(p_u_50) -- name: findLeaf2
	if p_u_50.leaf2 and p_u_50.leaf2.Parent then
		return p_u_50.leaf2
	end
	local v_u_51 = p_u_50.model:FindFirstChild("Leaf2") or p_u_50.leaf:FindFirstChild("Leaf2")
	if not (v_u_51 and v_u_51:IsA("BasePart")) then
		return nil
	end
	p_u_50.leaf2 = v_u_51
	local v52 = p_u_50.conns
	local v53 = v_u_51:GetPropertyChangedSignal("CFrame")
	table.insert(v52, v53:Connect(function()
		-- upvalues: (copy) p_u_50, (copy) v_u_51
		local v54 = p_u_50.visual2
		if v54 then
			local v55 = v_u_51.CFrame
			local v56
			if (v55.Position - v54.Position).Magnitude < 0.01 and v55.LookVector:Dot(v54.LookVector) > 0.99995 then
				v56 = v55.UpVector:Dot(v54.UpVector) > 0.99995
			else
				v56 = false
			end
			if not v56 then
				v_u_51.CFrame = v54
			end
		end
	end))
	return v_u_51
end
local function v_u_66(p58, p59) -- name: write
	-- upvalues: (copy) v_u_57, (copy) v_u_49
	p58.visual = p59
	local v60 = p58.leaf.CFrame
	local v61
	if (v60.Position - p59.Position).Magnitude < 0.01 and v60.LookVector:Dot(p59.LookVector) > 0.99995 then
		v61 = v60.UpVector:Dot(p59.UpVector) > 0.99995
	else
		v61 = false
	end
	if not v61 then
		p58.leaf.CFrame = p59
	end
	if p58.model:GetAttribute("ClosedCF2") ~= nil then
		local v62 = v_u_57(p58)
		local v63
		if v62 then
			v63 = v_u_49(p58, p59)
		else
			v63 = nil
		end
		if v62 and v63 then
			p58.visual2 = v63
			local v64 = v62.CFrame
			local v65
			if (v64.Position - v63.Position).Magnitude < 0.01 and v64.LookVector:Dot(v63.LookVector) > 0.99995 then
				v65 = v64.UpVector:Dot(v63.UpVector) > 0.99995
			else
				v65 = false
			end
			if not v65 then
				v62.CFrame = v63
			end
		end
	end
end
local function v_u_74(p67) -- name: retarget
	-- upvalues: (copy) v_u_34
	local v68 = v_u_34(p67)
	local v69 = p67.anim and p67.anim.to or p67.visual
	local v70
	if (v69.Position - v68.Position).Magnitude < 0.01 and v69.LookVector:Dot(v68.LookVector) > 0.99995 then
		v70 = v69.UpVector:Dot(v68.UpVector) > 0.99995
	else
		v70 = false
	end
	if not v70 then
		local v71 = false
		local v72 = p67.model:GetAttribute("ClosedCF")
		if typeof(v72) ~= "CFrame" then
			v72 = nil
		end
		if v72 ~= nil then
			local v73 = p67.model:GetAttribute("ClosedCF")
			if typeof(v73) ~= "CFrame" then
				v73 = nil
			end
			if (v68.Position - v73.Position).Magnitude < 0.01 and v68.LookVector:Dot(v73.LookVector) > 0.99995 then
				v71 = v68.UpVector:Dot(v73.UpVector) > 0.99995
			else
				v71 = false
			end
		end
		p67.anim = {
			["from"] = p67.visual,
			["to"] = v68,
			["t0"] = os.clock(),
			["dur"] = v71 and 0.3 or 0.4
		}
	end
end
local function v_u_86(p75, p76, p77) -- name: arc
	local v78 = math.clamp(p77, 0, 1)
	local v79 = 1 - (1 - v78) * (1 - v78) * (1 - v78)
	local v80 = p75.model:GetAttribute("HingePos")
	if typeof(v80) ~= "Vector3" then
		local v81 = p75.model:FindFirstChild("Hinge")
		v80 = v81 and v81.Position or nil
	end
	if not v80 then
		return p76.from:Lerp(p76.to, v79)
	end
	local v82 = p76.from:PointToObjectSpace(v80)
	local v83 = p76.from.Rotation:Lerp(p76.to.Rotation, v79)
	local v84 = CFrame.new(v80) * v83 * CFrame.new(-v82)
	local v85 = CFrame.new(v80) * p76.to.Rotation * CFrame.new(-v82)
	return v84 + (p76.to.Position - v85.Position) * v79
end
local function v_u_130(p_u_87) -- name: track
	-- upvalues: (copy) v_u_7, (copy) v_u_74, (copy) v_u_66, (copy) v_u_34
	if v_u_7[p_u_87] or not p_u_87:IsA("Model") then
		return
	else
		local v_u_88 = p_u_87:FindFirstChild("Leaf")
		if v_u_88 and v_u_88:IsA("BasePart") then
			local v_u_89 = {
				["model"] = nil,
				["leaf"] = nil,
				["conns"] = nil,
				["visual"] = nil,
				["anim"] = nil,
				["jolt"] = nil,
				["preds"] = nil,
				["unlockPred"] = 0,
				["lastState"] = "",
				["model"] = p_u_87,
				["leaf"] = v_u_88,
				["conns"] = {},
				["visual"] = v_u_88.CFrame,
				["preds"] = {}
			}
			local v90 = p_u_87:GetAttribute("LeafCF")
			if typeof(v90) == "CFrame" then
				v_u_89.visual = v90
			end
			local v91 = v_u_89.model:GetAttribute("State")
			v_u_89.lastState = type(v91) ~= "string" and "Closed" or v91
			v_u_7[p_u_87] = v_u_89
			local v92 = v_u_89.conns
			local v93 = v_u_88:GetPropertyChangedSignal("CFrame")
			table.insert(v92, v93:Connect(function()
				-- upvalues: (copy) v_u_88, (copy) v_u_89
				local v94 = v_u_88.CFrame
				local v95 = v_u_89.visual
				local v96
				if (v94.Position - v95.Position).Magnitude < 0.01 and v94.LookVector:Dot(v95.LookVector) > 0.99995 then
					v96 = v94.UpVector:Dot(v95.UpVector) > 0.99995
				else
					v96 = false
				end
				if not v96 then
					v_u_88.CFrame = v_u_89.visual
				end
			end))
			local v97 = v_u_89.conns
			local v98 = v_u_88:GetPropertyChangedSignal("CanCollide")
			table.insert(v97, v98:Connect(function()
				-- upvalues: (copy) v_u_89
				if #v_u_89.preds > 0 then
					local v99 = v_u_89
					local v100 = #v99.preds
					local v101
					if v100 > 0 then
						v101 = v99.preds[v100].state
					else
						local v102 = v99.model:GetAttribute("State")
						v101 = type(v102) ~= "string" and "Closed" or v102
					end
					local v103
					if v101 == "Closed" then
						v103 = v99.anim == nil
					else
						v103 = false
					end
					if v99.leaf.CanCollide ~= v103 then
						v99.leaf.CanCollide = v103
					end
					local v104 = v99.leaf2
					if v104 and v104.CanCollide ~= v103 then
						v104.CanCollide = v103
					end
				end
			end))
			local v105 = v_u_89.conns
			local v106 = p_u_87:GetAttributeChangedSignal("LeafCF")
			local function v107()
				-- upvalues: (ref) v_u_74, (copy) v_u_89
				v_u_74(v_u_89)
			end
			table.insert(v105, v106:Connect(v107))
			local v108 = v_u_89.conns
			local v109 = p_u_87:GetAttributeChangedSignal("State")
			local function v121()
				-- upvalues: (copy) v_u_89, (ref) v_u_74
				local v110 = v_u_89.model:GetAttribute("State")
				local v111 = type(v110) ~= "string" and "Closed" or v110
				v_u_89.lastState = v111
				local v112 = nil
				for v113, v114 in v_u_89.preds do
					if v114.state ~= v111 then
						continue
					end
					v112 = v113
				end
				if v112 then
					for _ = 1, v112 do
						table.remove(v_u_89.preds, 1)
					end
				else
					table.clear(v_u_89.preds)
				end
				v_u_74(v_u_89)
				local v115 = v_u_89
				local v116 = #v115.preds
				local v117
				if v116 > 0 then
					v117 = v115.preds[v116].state
				else
					local v118 = v115.model:GetAttribute("State")
					v117 = type(v118) ~= "string" and "Closed" or v118
				end
				local v119
				if v117 == "Closed" then
					v119 = v115.anim == nil
				else
					v119 = false
				end
				if v115.leaf.CanCollide ~= v119 then
					v115.leaf.CanCollide = v119
				end
				local v120 = v115.leaf2
				if v120 and v120.CanCollide ~= v119 then
					v120.CanCollide = v119
				end
			end
			table.insert(v108, v109:Connect(v121))
			local v122 = v_u_89.conns
			local v123 = p_u_87:GetAttributeChangedSignal("Locked")
			table.insert(v122, v123:Connect(function()
				-- upvalues: (copy) p_u_87, (copy) v_u_89
				if p_u_87:GetAttribute("Locked") == nil then
					v_u_89.unlockPred = 0
				end
			end))
			local v124 = v_u_89.conns
			local v125 = v_u_88.AncestryChanged
			local function v129()
				-- upvalues: (copy) v_u_88, (copy) p_u_87, (ref) v_u_7
				if not v_u_88:IsDescendantOf(workspace) then
					local v126 = p_u_87
					local v127 = v_u_7[v126]
					if not v127 then
						return
					end
					v_u_7[v126] = nil
					for _, v128 in v127.conns do
						v128:Disconnect()
					end
				end
			end
			table.insert(v124, v125:Connect(v129))
			v_u_66(v_u_89, (v_u_34(v_u_89)))
		end
	end
end
local function v_u_133() -- name: readKeys
	-- upvalues: (copy) v_u_8, (copy) v_u_6
	table.clear(v_u_8)
	local v131 = v_u_6:GetAttribute("DoorKeys")
	if type(v131) == "string" then
		for _, v132 in string.split(v131, ",") do
			if v132 == "" then
				continue
			end
			v_u_8[v132] = true
		end
	end
end
local function v_u_149(p134) -- name: powerHint
	-- upvalues: (ref) v_u_5, (copy) v_u_1
	local v135 = v_u_5
	if v135 then
		v135 = v_u_5.shared.HollowEscape
	end
	local v136 = v_u_5
	if v136 then
		v136 = v_u_5.shared.HollowPower
	end
	if not (v135 and v136) then
		return nil
	end
	local v137 = v_u_5.config.flag("HollowEscape") ~= false
	local v138 = p134.model:GetAttribute("Locked")
	local v139 = v136.pseudo(v138)
	if v139 == "lockdown" then
		local v140 = p134.model:GetAttribute("LockEndsAt")
		local v141
		if type(v140) == "number" then
			v141 = v140 - v_u_1.now()
		else
			v141 = nil
		end
		local _, v142 = v135.texts("lockdown", v141, nil, v137)
		return v142
	end
	if v139 ~= "power" then
		return nil
	end
	local v143 = p134.model:GetAttribute("Power")
	local v144 = v135.texts
	local v145 = "power"
	local v146 = nil
	local v147
	if type(v143) == "string" then
		v147 = v136.genLabel(v143)
	else
		v147 = nil
	end
	local _, v148 = v144(v145, v146, v147, v137)
	return v148
end
function v4.windowPartOf(p150) -- name: windowPartOf
	local v151 = p150.Parent
	if v151 ~= nil and v151:IsA("Attachment") then
		v151 = v151.Parent
	end
	if v151 == nil or not v151:IsA("BasePart") then
		return nil
	else
		return v151
	end
end
function v4.hidden(p152) -- name: hidden
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_3, (copy) v_u_130, (copy) v_u_10
	local v153 = p152:GetAttribute("NeedsKey")
	if type(v153) == "string" then
		if not v_u_8[v153] then
			return true
		end
		local v154 = p152:FindFirstAncestorOfClass("Model")
		local v155
		if v154 then
			v155 = v_u_7[v154]
			if not v155 and v_u_3:HasTag(v154, "HushDoor") then
				v_u_130(v154)
				v155 = v_u_7[v154]
			end
		else
			v155 = nil
		end
		return v155 and v155.unlockPred > os.clock() and true or false
	end
	local v156 = p152:GetAttribute("KeyHide")
	if type(v156) ~= "string" or not v_u_8[v156] then
		if p152:GetAttribute("Kind") == "glass" then
			local v157 = p152.Parent
			if v157 ~= nil and v157:IsA("Attachment") then
				v157 = v157.Parent
			end
			if v157 == nil or not v157:IsA("BasePart") then
				v157 = nil
			end
			if v157 and (v_u_10[v157] or 0) > os.clock() then
				return true
			end
		end
		return false
	end
	local v158 = p152:FindFirstAncestorOfClass("Model")
	local v159
	if v158 then
		v159 = v_u_7[v158]
		if not v159 and v_u_3:HasTag(v158, "HushDoor") then
			v_u_130(v158)
			v159 = v_u_7[v158]
		end
	else
		v159 = nil
	end
	if v159 then
		v159 = v159.unlockPred > os.clock()
	end
	return not v159
end
function v4.texts(p160) -- name: texts
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_130, (copy) v_u_149, (copy) v_u_8
	if p160:GetAttribute("Kind") == "door" then
		local v161 = p160:FindFirstAncestorOfClass("Model")
		local v162
		if v161 then
			v162 = v_u_7[v161]
			if not v162 and v_u_3:HasTag(v161, "HushDoor") then
				v_u_130(v161)
				v162 = v_u_7[v161]
			end
		else
			v162 = nil
		end
		if v162 then
			local v163 = #v162.preds
			local v164
			if v163 > 0 then
				v164 = v162.preds[v163].state
			else
				local v165 = v162.model:GetAttribute("State")
				v164 = type(v165) ~= "string" and "Closed" or v165
			end
			if v164 == "Open" then
				local v166 = "Close"
				local v167 = v162.model:GetAttribute("Kind")
				if v167 == "vent" then
					return v166, "Vent"
				elseif v167 == "blast" then
					if v162.model:GetAttribute("LayoutType") == "shutter" then
						return v166, "Shutter"
					else
						return v166, "Blast Door"
					end
				else
					return v166, "Door"
				end
			elseif v164 == "Closed" then
				local v168
				if v162.unlockPred > os.clock() then
					v168 = false
				else
					local v169 = v162.model
					v168 = type(v169:GetAttribute("Locked")) == "string"
				end
				if v168 then
					local v170 = v162.model:GetAttribute("LockTier")
					if v170 == "power" then
						local v171 = v_u_149
						local v172, v173 = pcall(v171, v162)
						local v174 = p160.ActionText
						if v172 then
							return v174, v173
						else
							return v174, nil
						end
					elseif v_u_8.melee_crowbar and v170 ~= "reinforced" then
						return "Pry open", nil
					else
						return "Locked", nil
					end
				else
					local v175 = "Open"
					local v176 = v162.model:GetAttribute("Kind")
					if v176 == "vent" then
						return v175, "Vent"
					elseif v176 == "blast" then
						if v162.model:GetAttribute("LayoutType") == "shutter" then
							return v175, "Shutter"
						else
							return v175, "Blast Door"
						end
					else
						return v175, "Door"
					end
				end
			else
				return nil, nil
			end
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
local function v_u_183(p177) -- name: doorwayFree
	-- upvalues: (copy) v_u_2
	local v178 = p177.model:GetAttribute("ClosedCF")
	if typeof(v178) ~= "CFrame" then
		v178 = nil
	end
	if not v178 then
		return false
	end
	for _, v179 in v_u_2:GetPlayers() do
		local v180 = v179.Character
		if v180 then
			v180 = v179.Character:FindFirstChild("HumanoidRootPart")
		end
		if not v180 then
			continue
		end
		local v181 = v180.Position - v178.Position
		local v182 = v181.Y
		if math.abs(v182) >= 6 or Vector2.new(v181.X, v181.Z).Magnitude >= 1.9 then
			continue
		end
		return false
	end
	return true
end
local function v_u_213(p184) -- name: predictToggle
	-- upvalues: (copy) v_u_6, (copy) v_u_183, (ref) v_u_5, (copy) v_u_74
	local v185 = #p184.preds
	local v186
	if v185 > 0 then
		v186 = p184.preds[v185].state
	else
		local v187 = p184.model:GetAttribute("State")
		v186 = type(v187) ~= "string" and "Closed" or v187
	end
	if v186 ~= "Broken" then
		local v188
		if p184.unlockPred > os.clock() then
			v188 = false
		else
			local v189 = p184.model
			v188 = type(v189:GetAttribute("Locked")) == "string"
		end
		if not v188 then
			local v190 = p184.model:GetAttribute("ClosedCF")
			if typeof(v190) ~= "CFrame" then
				v190 = nil
			end
			if v190 then
				local v191 = p184.model:GetAttribute("HingePos")
				if typeof(v191) ~= "Vector3" then
					local v192 = p184.model:FindFirstChild("Hinge")
					v191 = v192 and v192.Position or nil
				end
				if v191 then
					local v193 = v_u_6.Character
					if v193 then
						v193 = v193:FindFirstChild("HumanoidRootPart")
					end
					local v194
					if v193 then
						v194 = v193.Position
					else
						v194 = p184.leaf.Position
					end
					local v195 = p184.model:GetAttribute("Metal") == true
					if v186 == "Open" then
						if not v_u_183(p184) then
							return
						end
						local v196 = p184.preds
						local v197 = {
							["state"] = "Closed",
							["t"] = nil,
							["from"] = nil,
							["t"] = os.clock(),
							["from"] = v194
						}
						table.insert(v196, v197)
						local v198 = v195 and "door_metal" or "door_close"
						local v199 = p184.leaf.Position
						local v200 = v_u_5
						if v200 then
							v200 = v_u_5.controllers.Audio
						end
						if v200 and v200.play3D then
							local v201 = v200.play3D
							pcall(v201, v198, v199, nil)
						end
					else
						local v202 = p184.preds
						local v203 = {
							["state"] = "Open",
							["t"] = nil,
							["from"] = nil,
							["t"] = os.clock(),
							["from"] = v194
						}
						table.insert(v202, v203)
						local v204 = v195 and "door_metal" or "door_open"
						local v205 = p184.leaf.Position
						local v206 = v_u_5
						if v206 then
							v206 = v_u_5.controllers.Audio
						end
						if v206 and v206.play3D then
							local v207 = v206.play3D
							pcall(v207, v204, v205, nil)
						end
					end
					v_u_74(p184)
					local v208 = #p184.preds
					local v209
					if v208 > 0 then
						v209 = p184.preds[v208].state
					else
						local v210 = p184.model:GetAttribute("State")
						v209 = type(v210) ~= "string" and "Closed" or v210
					end
					local v211
					if v209 == "Closed" then
						v211 = p184.anim == nil
					else
						v211 = false
					end
					if p184.leaf.CanCollide ~= v211 then
						p184.leaf.CanCollide = v211
					end
					local v212 = p184.leaf2
					if v212 and v212.CanCollide ~= v211 then
						v212.CanCollide = v211
					end
					return
				end
			end
		end
	end
end
local v_u_214 = RaycastParams.new()
v_u_214.FilterType = Enum.RaycastFilterType.Exclude
v_u_214.IgnoreWater = true
local function v_u_260(p215) -- name: startClimb
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (copy) v_u_214, (ref) v_u_5
	if v_u_9 then
		return false
	end
	local v216 = p215:GetAttribute("ClimbA")
	local v217 = p215:GetAttribute("ClimbB")
	local v218 = p215:GetAttribute("SillY")
	local v219 = v_u_6.Character
	local v220 = v_u_6.Character
	if v220 then
		v220 = v220:FindFirstChild("HumanoidRootPart")
	end
	local v221
	if v219 then
		v221 = v219:FindFirstChildOfClass("Humanoid")
	else
		v221 = v219
	end
	if typeof(v216) ~= "Vector3" or (typeof(v217) ~= "Vector3" or (type(v218) ~= "number" or not (v220 and (v221 and v219)))) then
		return false
	end
	local v222 = p215.CFrame
	local v223 = p215.Size
	local v224
	if v223.X < v223.Z then
		v224 = v222.RightVector
	else
		v224 = v222.LookVector
	end
	local v225 = v224.X
	local v226 = v224.Z
	local v227 = Vector3.new(v225, 0, v226).Unit
	local v228 = (Vector3.new(0, 1, 0)):Cross(v227).Unit
	local v229 = v223.X
	local v230 = v223.Z
	local v231 = math.max(v229, v230)
	local v232 = (v220.Position - p215.Position):Dot(v227)
	local v233 = (v216 - p215.Position):Dot(v227)
	if v232 >= 0 ~= (v233 >= 0) then
		v217 = v216
	end
	v_u_214.FilterDescendantsInstances = { v219 }
	local v234 = workspace:Raycast(v220.Position, Vector3.new(0, -12, 0), v_u_214)
	local v235
	if v234 then
		local v236 = v220.Position.Y - v234.Position.Y
		v235 = math.clamp(v236, 1.5, 5)
	else
		v235 = v221.HipHeight + v220.Size.Y / 2
	end
	local v237 = (v220.Position - p215.Position):Dot(v228)
	local v238 = -(v231 / 2 - 0.9)
	local v239 = v231 / 2 - 0.9
	local v240 = math.clamp(v237, v238, v239)
	local v241 = p215.Position + v228 * v240
	local v242 = v241.X
	local v243 = v218 + v235 * 0.55 + 0.9
	local v244 = v241.Z
	local v245 = Vector3.new(v242, v243, v244)
	local v246 = v217.X
	local v247 = v217.Y + v235
	local v248 = v217.Z
	local v249 = Vector3.new(v246, v247, v248) + v228 * v240
	local v250 = v249.X - v220.Position.X
	local v251 = v249.Z - v220.Position.Z
	local v252 = Vector3.new(v250, 0, v251)
	if v252.Magnitude < 0.1 then
		return false
	end
	v_u_9 = {
		["t0"] = os.clock(),
		["p0"] = v220.Position,
		["p1"] = v245,
		["p2"] = v249,
		["look"] = v252.Unit,
		["root"] = v220
	}
	v_u_6:SetAttribute("PredAction", "Climb")
	v_u_6:SetAttribute("PredActionEnds", os.clock() + 1.1)
	local v253 = v220.Position
	local v254 = {
		["volume"] = 0.6
	}
	local v255 = v_u_5
	if v255 then
		v255 = v_u_5.controllers.Audio
	end
	if v255 and v255.play3D then
		local v256 = v255.play3D
		pcall(v256, "cloth", v253, v254)
	end
	if p215:GetAttribute("GlassCleared") ~= true then
		local v257 = {
			["volume"] = 0.7,
			["delay"] = 0.35
		}
		local v258 = v_u_5
		if v258 then
			v258 = v_u_5.controllers.Audio
		end
		if v258 and v258.play3D then
			local v259 = v258.play3D
			pcall(v259, "step_glass", v241, v257)
		end
	end
	return true
end
local function v_u_270() -- name: stepClimb
	-- upvalues: (ref) v_u_9, (copy) v_u_6, (ref) v_u_5
	local v261 = v_u_9
	if v261 then
		local v262 = v_u_6.Character
		if v261.root.Parent and (v262 and (v262:GetAttribute("Dead") ~= true and v262:GetAttribute("Downed") ~= true)) then
			local v263 = (os.clock() - v261.t0) / 1
			local v264 = math.clamp(v263, 0, 1)
			local v265 = v264 * v264 * (3 - v264 * 2)
			local v266 = v261.p0:Lerp(v261.p1, v265):Lerp(v261.p1:Lerp(v261.p2, v265), v265)
			v261.root.CFrame = CFrame.lookAt(v266, v266 + v261.look)
			v261.root.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			if v264 >= 1 then
				v_u_9 = nil
				if v_u_6:GetAttribute("PredAction") == "Climb" then
					v_u_6:SetAttribute("PredAction", nil)
					v_u_6:SetAttribute("PredActionEnds", nil)
				end
				local v267 = {
					["volume"] = 0.5
				}
				local v268 = v_u_5
				if v268 then
					v268 = v_u_5.controllers.Audio
				end
				if v268 and v268.play3D then
					local v269 = v268.play3D
					pcall(v269, "step_wood", v266, v267)
				end
			end
		else
			v_u_9 = nil
			if v_u_6:GetAttribute("PredAction") == "Climb" then
				v_u_6:SetAttribute("PredAction", nil)
				v_u_6:SetAttribute("PredActionEnds", nil)
			end
		end
	else
		return
	end
end
function v4.climbing() -- name: climbing
	-- upvalues: (ref) v_u_9
	return v_u_9 ~= nil
end
function v4.onTriggered(p271) -- name: onTriggered
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_130, (copy) v_u_213, (ref) v_u_5, (copy) v_u_6, (copy) v_u_260, (copy) v_u_10
	local v272 = p271:GetAttribute("Kind")
	if v272 == "door" then
		local v273 = p271:FindFirstAncestorOfClass("Model")
		local v274
		if v273 then
			v274 = v_u_7[v273]
			if not v274 and v_u_3:HasTag(v273, "HushDoor") then
				v_u_130(v273)
				v274 = v_u_7[v273]
			end
		else
			v274 = nil
		end
		if v274 then
			v_u_213(v274)
			return
		end
	else
		if v272 == "doorKey" then
			local v275 = p271:FindFirstAncestorOfClass("Model")
			local v276
			if v275 then
				v276 = v_u_7[v275]
				if not v276 and v_u_3:HasTag(v275, "HushDoor") then
					v_u_130(v275)
					v276 = v_u_7[v275]
				end
			else
				v276 = nil
			end
			if v276 then
				v276.unlockPred = os.clock() + 3
				local v277 = v276.leaf.Position
				local v278 = p271:GetAttribute("NeedsKey")
				if type(v278) == "string" and string.sub(v278, 1, 8) == "keycard_" then
					local v279 = {
						["pitch"] = 0.9,
						["volume"] = 0.9
					}
					local v280 = v_u_5
					if v280 then
						v280 = v_u_5.controllers.Audio
					end
					if v280 and v280.play3D then
						local v281 = v280.play3D
						pcall(v281, "ui_tick", v277, v279)
					end
					local v282 = {
						["pitch"] = 1.3,
						["volume"] = 0.35,
						["delay"] = 0.15
					}
					local v283 = v_u_5
					if v283 then
						v283 = v_u_5.controllers.Audio
					end
					if v283 and v283.play3D then
						local v284 = v283.play3D
						pcall(v284, "door_metal", v277, v282)
					end
				else
					local v285 = {
						["pitch"] = 1.25,
						["volume"] = 0.6
					}
					local v286 = v_u_5
					if v286 then
						v286 = v_u_5.controllers.Audio
					end
					if v286 and v286.play3D then
						local v287 = v286.play3D
						pcall(v287, "door_locked", v277, v285)
					end
				end
			end
			task.delay(0.25, function()
				-- upvalues: (ref) v_u_6
				if v_u_6:GetAttribute("PredAction") == "Unlock" then
					v_u_6:SetAttribute("PredAction", nil)
					v_u_6:SetAttribute("PredActionEnds", nil)
				end
			end)
			return
		end
		if v272 == "climb" then
			local v288 = p271.Parent
			if v288 ~= nil and v288:IsA("Attachment") then
				v288 = v288.Parent
			end
			if v288 == nil or not v288:IsA("BasePart") then
				v288 = nil
			end
			if v288 then
				v_u_260(v288)
				return
			end
		elseif v272 == "glass" then
			local v289 = p271.Parent
			if v289 ~= nil and v289:IsA("Attachment") then
				v289 = v289.Parent
			end
			if v289 == nil or not v289:IsA("BasePart") then
				v289 = nil
			end
			if v289 then
				v_u_10[v289] = os.clock() + 2.5
			end
			if v_u_6:GetAttribute("PredAction") == "Search" then
				v_u_6:SetAttribute("PredAction", nil)
				v_u_6:SetAttribute("PredActionEnds", nil)
			end
		end
	end
end
function v4.onHoldBegan(p290) -- name: onHoldBegan
	-- upvalues: (copy) v_u_6, (ref) v_u_5
	local v291 = p290:GetAttribute("Kind")
	if v291 == "doorKey" then
		v_u_6:SetAttribute("PredAction", "Unlock")
		v_u_6:SetAttribute("PredActionEnds", os.clock() + 1.1)
	elseif v291 == "glass" then
		local v292 = p290.HoldDuration + 0.2
		v_u_6:SetAttribute("PredAction", "Search")
		v_u_6:SetAttribute("PredActionEnds", os.clock() + v292)
		local v293 = p290.Parent
		if v293 ~= nil and v293:IsA("Attachment") then
			v293 = v293.Parent
		end
		if v293 == nil or not v293:IsA("BasePart") then
			v293 = nil
		end
		if v293 then
			local v294 = v293.Position
			local v295 = {
				["volume"] = 0.5
			}
			local v296 = v_u_5
			if v296 then
				v296 = v_u_5.controllers.Audio
			end
			if v296 and v296.play3D then
				local v297 = v296.play3D
				pcall(v297, "item_rummage", v294, v295)
			end
		end
	end
end
function v4.onHoldEnded(p298) -- name: onHoldEnded
	-- upvalues: (copy) v_u_6
	local v299 = p298:GetAttribute("Kind")
	if v299 == "doorKey" then
		task.delay(0.2, function()
			-- upvalues: (ref) v_u_6
			if v_u_6:GetAttribute("PredAction") == "Unlock" then
				v_u_6:SetAttribute("PredAction", nil)
				v_u_6:SetAttribute("PredActionEnds", nil)
			end
		end)
	elseif v299 == "glass" and v_u_6:GetAttribute("PredAction") == "Search" then
		v_u_6:SetAttribute("PredAction", nil)
		v_u_6:SetAttribute("PredActionEnds", nil)
	end
end
local function v_u_321(p300) -- name: onFx
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (ref) v_u_5
	if type(p300) == "table" then
		local v301 = p300.pos
		if typeof(v301) == "Vector3" then
			local v302 = p300.kind
			if v302 == "kick" or v302 == "bash" then
				local v303 = p300.id or ""
				local v304 = tostring(v303)
				for _, v306 in v_u_7 do
					if v306.model:GetAttribute("DoorId") ~= v304 then
						continue
					end
				end
				local v306 = nil
				if v306 then
					local v307 = #v306.preds
					local v308
					if v307 > 0 then
						v308 = v306.preds[v307].state
					else
						local v309 = v306.model:GetAttribute("State")
						v308 = type(v309) ~= "string" and "Closed" or v309
					end
					if v308 == "Closed" then
						local v310 = {
							["t0"] = os.clock()
						}
						local v311 = v302 == "kick" and 2.5 or 1.5
						v310.amp = math.rad(v311) * (math.random() < 0.5 and 1 or -1)
						v306.jolt = v310
						return
					end
				end
			elseif v302 == "climb" then
				local v312 = v_u_6.Character
				if v312 then
					v312 = v312:FindFirstChild("HumanoidRootPart")
				end
				if v312 and (v312.Position - p300.pos).Magnitude > 4 then
					local v313 = p300.pos
					local v314 = {
						["volume"] = 0.5
					}
					local v315 = v_u_5
					if v315 then
						v315 = v_u_5.controllers.Audio
					end
					if v315 and v315.play3D then
						local v316 = v315.play3D
						pcall(v316, "cloth", v313, v314)
						return
					end
				end
			elseif v302 == "glassClear" then
				local v317 = p300.pos
				local v318 = {
					["volume"] = 0.6
				}
				local v319 = v_u_5
				if v319 then
					v319 = v_u_5.controllers.Audio
				end
				if v319 and v319.play3D then
					local v320 = v319.play3D
					pcall(v320, "step_glass", v317, v318)
				end
			end
			return
		end
	end
end
local function v_u_340(p322) -- name: onDeny
	-- upvalues: (copy) v_u_7, (copy) v_u_74
	if type(p322) == "table" then
		local v323 = p322.id or ""
		local v324 = tostring(v323)
		for _, v326 in v_u_7 do
			if v326.model:GetAttribute("DoorId") ~= v324 then
				continue
			end
		end
		local v326 = nil
		if v326 then
			if p322.kind ~= "unlocked" then
				v326.unlockPred = 0
			end
			local v327 = v326.preds[#v326.preds]
			if p322.kind == "state" and (v327 and v327.state == p322.state) then
				local v328 = v326.model:GetAttribute("State")
				if (type(v328) ~= "string" and "Closed" or v328) ~= p322.state then
					table.clear(v326.preds)
					v327.t = os.clock()
					local v329 = v326.preds
					table.insert(v329, v327)
					v_u_74(v326)
					local v330 = #v326.preds
					local v331
					if v330 > 0 then
						v331 = v326.preds[v330].state
					else
						local v332 = v326.model:GetAttribute("State")
						v331 = type(v332) ~= "string" and "Closed" or v332
					end
					local v333
					if v331 == "Closed" then
						v333 = v326.anim == nil
					else
						v333 = false
					end
					if v326.leaf.CanCollide ~= v333 then
						v326.leaf.CanCollide = v333
					end
					local v334 = v326.leaf2
					if v334 and v334.CanCollide ~= v333 then
						v334.CanCollide = v333
					end
					return
				end
			end
			table.clear(v326.preds)
			v_u_74(v326)
			local v335 = #v326.preds
			local v336
			if v335 > 0 then
				v336 = v326.preds[v335].state
			else
				local v337 = v326.model:GetAttribute("State")
				v336 = type(v337) ~= "string" and "Closed" or v337
			end
			local v338
			if v336 == "Closed" then
				v338 = v326.anim == nil
			else
				v338 = false
			end
			if v326.leaf.CanCollide ~= v338 then
				v326.leaf.CanCollide = v338
			end
			local v339 = v326.leaf2
			if v339 and v339.CanCollide ~= v338 then
				v339.CanCollide = v338
			end
		end
	end
end
local v_u_341 = {
	["n"] = 0
}
local function v_u_382(p342, _, p343, p344) -- name: onHollowFx
	-- upvalues: (copy) v_u_341, (ref) v_u_5
	local v345 = v_u_341
	v345.n = v345.n + 1
	if typeof(p344) == "Vector3" then
		if p342 == "gen" then
			if p343 == "starting" then
				local v346 = {
					["pitch"] = 0.55,
					["volume"] = 1
				}
				local v347 = v_u_5
				if v347 then
					v347 = v_u_5.controllers.Audio
				end
				if v347 and v347.play3D then
					local v348 = v347.play3D
					pcall(v348, "ev_engine", p344, v346)
				end
				local v349 = {
					["pitch"] = 0.6,
					["volume"] = 0.5
				}
				local v350 = v_u_5
				if v350 then
					v350 = v_u_5.controllers.Audio
				end
				if v350 and v350.play3D then
					local v351 = v350.play3D
					pcall(v351, "door_metal", p344, v349)
					return
				end
			elseif p343 == "on" then
				local v352 = {
					["pitch"] = 0.75,
					["volume"] = 0.9
				}
				local v353 = v_u_5
				if v353 then
					v353 = v_u_5.controllers.Audio
				end
				if v353 and v353.play3D then
					local v354 = v353.play3D
					pcall(v354, "ev_engine", p344, v352)
				end
				local v355 = {
					["volume"] = 0.8
				}
				local v356 = v_u_5
				if v356 then
					v356 = v_u_5.controllers.Audio
				end
				if v356 and v356.play3D then
					local v357 = v356.play3D
					pcall(v357, "light_flicker", p344, v355)
					return
				end
			elseif p343 == "run" then
				local v358 = {
					["pitch"] = 0.7,
					["volume"] = 0.5
				}
				local v359 = v_u_5
				if v359 then
					v359 = v_u_5.controllers.Audio
				end
				if v359 and v359.play3D then
					local v360 = v359.play3D
					pcall(v360, "amb_fan", p344, v358)
					return
				end
			end
		elseif p342 == "power" then
			local v361 = {
				["volume"] = 0.7
			}
			local v362 = v_u_5
			if v362 then
				v362 = v_u_5.controllers.Audio
			end
			if v362 and v362.play3D then
				local v363 = v362.play3D
				pcall(v363, "light_flicker", p344, v361)
				return
			end
		elseif p342 == "lift" then
			if p343 == "nopower" then
				local v364 = {
					["volume"] = 0.5
				}
				local v365 = v_u_5
				if v365 then
					v365 = v_u_5.controllers.Audio
				end
				if v365 and v365.play3D then
					local v366 = v365.play3D
					pcall(v366, "ui_error", p344, v364)
					return
				end
			elseif p343 == "riding" then
				local v367 = {
					["pitch"] = 0.4,
					["volume"] = 0.7
				}
				local v368 = v_u_5
				if v368 then
					v368 = v_u_5.controllers.Audio
				end
				if v368 and v368.play3D then
					local v369 = v368.play3D
					pcall(v369, "ev_engine", p344, v367)
				end
				local v370 = {
					["pitch"] = 0.8,
					["volume"] = 0.6
				}
				local v371 = v_u_5
				if v371 then
					v371 = v_u_5.controllers.Audio
				end
				if v371 and v371.play3D then
					local v372 = v371.play3D
					pcall(v372, "door_metal", p344, v370)
					return
				end
			else
				local v373 = {
					["pitch"] = 0.9,
					["volume"] = 0.7
				}
				local v374 = v_u_5
				if v374 then
					v374 = v_u_5.controllers.Audio
				end
				if v374 and v374.play3D then
					local v375 = v374.play3D
					pcall(v375, "door_metal", p344, v373)
					return
				end
			end
		elseif p342 == "crank" then
			local v376 = {
				["pitch"] = 0.55,
				["volume"] = 0.8
			}
			local v377 = v_u_5
			if v377 then
				v377 = v_u_5.controllers.Audio
			end
			if v377 and v377.play3D then
				local v378 = v377.play3D
				pcall(v378, "rel_bolt", p344, v376)
			end
			if type(p343) == "number" and p343 >= 1 then
				local v379 = {
					["pitch"] = 0.7,
					["volume"] = 1
				}
				local v380 = v_u_5
				if v380 then
					v380 = v_u_5.controllers.Audio
				end
				if v380 and v380.play3D then
					local v381 = v380.play3D
					pcall(v381, "door_metal", p344, v379)
				end
			end
		end
	end
end
function v4.init(p_u_383) -- name: init
	-- upvalues: (ref) v_u_5, (copy) v_u_7, (copy) v_u_341, (copy) v_u_6, (copy) v_u_133, (copy) v_u_8, (copy) v_u_213, (copy) v_u_260
	v_u_5 = p_u_383
	p_u_383.command("doors.pred", function(p384)
		-- upvalues: (ref) v_u_7
		local v385 = 0
		local v386 = {}
		for _, v387 in v_u_7 do
			v385 = v385 + 1
			local v388 = v387.model
			local v389 = tostring(v388:GetAttribute("DoorId"))
			if (not p384[1] or v389 ~= p384[1]) and (p384[1] or #v387.preds <= 0 and not v387.anim) then
				continue
			end
			local v390 = {}
			for _, v391 in v387.preds do
				local v392 = v391.state
				table.insert(v390, v392)
			end
			local v393 = v387.model:GetAttribute("ClosedCF")
			if typeof(v393) ~= "CFrame" then
				v393 = nil
			end
			local v394
			if v393 then
				local v395 = v387.leaf.CFrame.LookVector:Dot(v393.LookVector)
				local v396 = math.clamp(v395, -1, 1)
				local v397 = math.acos(v396)
				v394 = math.deg(v397)
			else
				v394 = -1
			end
			local v398 = string.format
			local v399 = "%s server=%s shown=%s preds=[%s] anim=%s collide=%s leafAngle=%.0f visualOk=%s"
			local v400 = v387.model:GetAttribute("State")
			local v401 = type(v400) ~= "string" and "Closed" or v400
			local v402 = #v387.preds
			local v403
			if v402 > 0 then
				v403 = v387.preds[v402].state
			else
				local v404 = v387.model:GetAttribute("State")
				v403 = type(v404) ~= "string" and "Closed" or v404
			end
			local v405 = table.concat(v390, ",")
			local v406 = v387.anim ~= nil
			local v407 = tostring(v406)
			local v408 = v387.leaf.CanCollide
			local v409 = tostring(v408)
			local v410 = v387.leaf.CFrame
			local v411 = v387.visual
			local v412
			if (v410.Position - v411.Position).Magnitude < 0.01 and v410.LookVector:Dot(v411.LookVector) > 0.99995 then
				v412 = v410.UpVector:Dot(v411.UpVector) > 0.99995
			else
				v412 = false
			end
			local v413 = tostring(v412)
			table.insert(v386, v398(v399, v389, v401, v403, v405, v407, v409, v394, v413))
			local v414 = v387.leaf2
			local v415 = v387.model:GetAttribute("ClosedCF2")
			if not v414 or typeof(v415) ~= "CFrame" then
				break
			end
			local v416 = #v386
			local v417 = v386[v416]
			local v418 = string.format
			local v419 = v414.CFrame.LookVector:Dot(v415.LookVector)
			local v420 = math.clamp(v419, -1, 1)
			local v421 = math.acos(v420)
			local v422 = math.deg(v421)
			local v423 = v414.CanCollide
			v386[v416] = v417 .. v418(" leaf2Angle=%.0f collide2=%s", v422, (tostring(v423)))
		end
		return v385 .. " doors tracked; " .. table.concat(v386, " | ")
	end)
	p_u_383.command("doors.hollowfx", function()
		-- upvalues: (ref) v_u_341
		return "hollow.fx heard " .. v_u_341.n
	end)
	p_u_383.command("hollow.lamps", function(p424)
		-- upvalues: (copy) p_u_383, (ref) v_u_6
		local v425 = p_u_383.lib.WeatherLamps
		local v426 = v425.stats()
		local v427 = v_u_6.Character
		if v427 then
			v427 = v427:FindFirstChild("HumanoidRootPart")
		end
		local v428 = not v427 and Vector3.new(0, 0, 0) or v427.Position
		local v429 = p424[1]
		local v430 = tonumber(v429) or 12
		local v431 = {}
		for _, v432 in v425.nearest(v428, v430) do
			local v433 = (v432.powered and "on" or "off") .. "/" .. (v432.want and "want" or "dark")
			local v434 = v431[v433] or { 0 }
			v434[1] = v434[1] + 1
			v431[v433] = v434
		end
		local v435 = {}
		for v436, v437 in v431 do
			local v438 = v436 .. "=" .. v437[1]
			table.insert(v435, v438)
		end
		table.sort(v435)
		return string.format("total=%d active=%d unpowered=%d levelSkip=%d dead=%d | nearest %d: %s", v426.total, v426.active, v426.unpowered or -1, v426.levelSkip or -1, v426.dead, v430, table.concat(v435, " "))
	end)
	p_u_383.command("doors.keys", function()
		-- upvalues: (ref) v_u_133, (ref) v_u_8, (ref) v_u_6
		v_u_133()
		local v439 = {}
		for v440 in v_u_8 do
			table.insert(v439, v440)
		end
		local v441 = v_u_6
		return "DoorKeys=" .. tostring(v441:GetAttribute("DoorKeys")) .. " parsed=" .. table.concat(v439, ",")
	end)
	p_u_383.command("doors.press", function(p442)
		-- upvalues: (ref) v_u_7, (ref) v_u_213
		local v443 = p442[1] or ""
		for _, v445 in v_u_7 do
			if v445.model:GetAttribute("DoorId") ~= v443 then
				continue
			end
		end
		local v445 = nil
		if not v445 then
			local v446 = p442[1]
			return "no tracked door " .. tostring(v446)
		end
		v_u_213(v445)
		local v447 = "predicted "
		local v448 = #v445.preds
		local v449
		if v448 > 0 then
			v449 = v445.preds[v448].state
		else
			local v450 = v445.model:GetAttribute("State")
			v449 = type(v450) ~= "string" and "Closed" or v450
		end
		return v447 .. v449
	end)
	p_u_383.command("doors.climb", function(p451)
		-- upvalues: (ref) v_u_260
		local v452 = workspace:FindFirstChild("Raid")
		if v452 then
			v452 = v452:FindFirstChild("Map")
		end
		if not v452 then
			return "no map"
		end
		for _, v453 in v452:GetDescendants() do
			if not v453:IsA("BasePart") or v453:GetAttribute("WindowId") ~= p451[1] then
				continue
			end
			local v454 = v_u_260(v453)
			return "climb started " .. tostring(v454) .. " climbable " .. tostring(v453:GetAttribute("Climbable"))
		end
		local v455 = p451[1]
		return "no window " .. tostring(v455)
	end)
end
function v4.start() -- name: start
	-- upvalues: (copy) v_u_133, (copy) v_u_6, (copy) v_u_3, (copy) v_u_130, (copy) v_u_7, (ref) v_u_5, (copy) v_u_321, (copy) v_u_340, (copy) v_u_382
	v_u_133()
	v_u_6:GetAttributeChangedSignal("DoorKeys"):Connect(v_u_133)
	for _, v456 in v_u_3:GetTagged("HushDoor") do
		if not v456:IsA("Model") then
			continue
		end
		v_u_130(v456)
	end
	v_u_3:GetInstanceAddedSignal("HushDoor"):Connect(function(p457)
		-- upvalues: (ref) v_u_130
		if p457:IsA("Model") then
			task.defer(v_u_130, p457)
		end
	end)
	v_u_3:GetInstanceRemovedSignal("HushDoor"):Connect(function(p458)
		-- upvalues: (ref) v_u_7
		if p458:IsA("Model") then
			local v459 = v_u_7[p458]
			if not v459 then
				return
			end
			v_u_7[p458] = nil
			for _, v460 in v459.conns do
				v460:Disconnect()
			end
		end
	end)
	local v_u_461 = v_u_5
	if v_u_461 then
		v_u_461 = v_u_5.net
	end
	if v_u_461 and v_u_461.listen then
		task.spawn(function()
			-- upvalues: (copy) v_u_461, (ref) v_u_321
			local v462 = v_u_461.listen
			local v463 = v_u_321
			pcall(v462, "door.fx", v463)
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_461, (ref) v_u_340
			local v464 = v_u_461.listen
			local v465 = v_u_340
			pcall(v464, "door.deny", v465)
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_461, (ref) v_u_382
			local v466 = v_u_461.listen
			local v467 = v_u_382
			pcall(v466, "hollow.fx", v467)
		end)
	end
end
local v_u_468 = 0
function v4.step(_) -- name: step
	-- upvalues: (ref) v_u_468, (copy) v_u_3, (copy) v_u_7, (copy) v_u_130, (copy) v_u_10, (copy) v_u_74, (copy) v_u_66, (copy) v_u_86, (copy) v_u_34, (copy) v_u_270
	local v469 = os.clock()
	if v_u_468 <= v469 then
		v_u_468 = v469 + 2
		for _, v470 in v_u_3:GetTagged("HushDoor") do
			if not v470:IsA("Model") or v_u_7[v470] then
				continue
			end
			v_u_130(v470)
		end
		for v471, v472 in v_u_10 do
			if v472 >= v469 then
				continue
			end
			v_u_10[v471] = nil
		end
	end
	for _, v473 in v_u_7 do
		if #v473.preds > 0 and v469 - v473.preds[1].t > 2.5 then
			table.clear(v473.preds)
			v_u_74(v473)
			local v474 = #v473.preds
			local v475
			if v474 > 0 then
				v475 = v473.preds[v474].state
			else
				local v476 = v473.model:GetAttribute("State")
				v475 = type(v476) ~= "string" and "Closed" or v476
			end
			local v477
			if v475 == "Closed" then
				v477 = v473.anim == nil
			else
				v477 = false
			end
			if v473.leaf.CanCollide ~= v477 then
				v473.leaf.CanCollide = v477
			end
			local v478 = v473.leaf2
			if v478 and v478.CanCollide ~= v477 then
				v478.CanCollide = v477
			end
		end
		local v479 = v473.anim
		if v479 then
			local v480 = (v469 - v479.t0) / v479.dur
			if v480 >= 1 then
				v473.anim = nil
				v_u_66(v473, v479.to)
				if #v473.preds > 0 then
					local v481 = #v473.preds
					local v482
					if v481 > 0 then
						v482 = v473.preds[v481].state
					else
						local v483 = v473.model:GetAttribute("State")
						v482 = type(v483) ~= "string" and "Closed" or v483
					end
					local v484
					if v482 == "Closed" then
						v484 = v473.anim == nil
					else
						v484 = false
					end
					if v473.leaf.CanCollide ~= v484 then
						v473.leaf.CanCollide = v484
					end
					local v485 = v473.leaf2
					if v485 and v485.CanCollide ~= v484 then
						v485.CanCollide = v484
					end
				end
			else
				v_u_66(v473, v_u_86(v473, v479, v480))
			end
		end
		local v486 = v473.jolt
		if not v486 then
			continue
		end
		local v487 = (v469 - v486.t0) / 0.3
		local v488 = v473.model:GetAttribute("ClosedCF")
		if typeof(v488) ~= "CFrame" then
			v488 = nil
		end
		local v489 = v473.model:GetAttribute("HingePos")
		if typeof(v489) ~= "Vector3" then
			local v490 = v473.model:FindFirstChild("Hinge")
			v489 = v490 and v490.Position or nil
		end
		if v487 >= 1 or (not v488 or (not v489 or v473.anim)) then
			v473.jolt = nil
			if v473.anim then
				continue
			end
			v_u_66(v473, (v_u_34(v473)))
		else
			local v491 = v486.amp
			local v492 = v487 * 3.141592653589793 * 3
			local v493 = v491 * math.sin(v492) * (1 - v487)
			local v494 = CFrame.new(v489) * v488.Rotation
			v_u_66(v473, v494 * CFrame.Angles(0, v493, 0) * v494:ToObjectSpace(v488))
		end
	end
	v_u_270()
end
return v4