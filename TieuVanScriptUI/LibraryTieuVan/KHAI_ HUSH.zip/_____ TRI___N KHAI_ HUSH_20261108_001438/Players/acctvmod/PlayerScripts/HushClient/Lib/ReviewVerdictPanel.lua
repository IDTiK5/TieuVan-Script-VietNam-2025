-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewVerdictPanel

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {}
local v_u_3 = {}
function v_u_2.use(p4) -- name: use
	-- upvalues: (ref) v_u_3
	v_u_3 = type(p4) ~= "table" and {} or p4
end
function v_u_2.momentLines(p5, p6) -- name: momentLines
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	local v7 = {}
	if type(p5) ~= "table" then
		return v7
	end
	local v8
	if v_u_3.tools == nil then
		v8 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewToolsRules"))
	else
		v8 = v_u_3.tools
	end
	for v9, v10 in p5 do
		if (p6 or 10) < v9 then
			break
		end
		if type(v10) ~= "table" then
			continue
		end
		local v11 = v8.stamp(v10.t)
		local v12 = v10.note or ""
		local v13 = v11 .. "  " .. tostring(v12)
		table.insert(v7, v13)
	end
	return v7
end
function v_u_2.args(p14) -- name: args
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	local v15
	if v_u_3.rules == nil then
		v15 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewRules"))
	else
		v15 = v_u_3.rules
	end
	local v16 = {
		["target"] = p14.target,
		["verdict"] = p14.pick
	}
	local v17 = p14.watchSeconds
	if type(v17) == "number" and (v17 == v17 and v17 >= 0) then
		v16.watchSeconds = math.floor(v17)
	end
	local v18 = p14.raidId
	if type(v18) == "string" and p14.raidId ~= "" then
		local v19 = p14.raidId
		local v20 = v15.RAIDID_MAX or 64
		v16.raidId = string.sub(v19, 1, v20)
	end
	local v21 = v15.noDashes(p14.comment or "")
	local v22 = v15.COMMENT_MAX or 200
	local v23 = string.sub(v21, 1, v22)
	if v23 ~= "" then
		v16.comment = v23
	end
	local v24 = {}
	local v25 = p14.moments
	if type(v25) == "table" then
		for v26, v27 in p14.moments do
			if (v15.MOMENTS_MAX or 10) < v26 then
				break
			end
			if type(v27) ~= "table" then
				continue
			end
			local v28 = v27.t
			if type(v28) ~= "number" then
				continue
			end
			local v29 = {}
			local v30 = v27.t
			v29.t = math.floor(v30)
			local v31 = v15.noDashes
			local v32 = v27.note or ""
			local v33 = v31((tostring(v32)))
			local v34 = v15.MOMENT_NOTE_MAX or 80
			v29.note = string.sub(v33, 1, v34)
			table.insert(v24, v29)
		end
	end
	if #v24 > 0 then
		v16.moments = v24
	end
	return v16
end
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = nil
function v_u_2.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_35
	return v_u_35 ~= nil
end
function v_u_2.close() -- name: close
	-- upvalues: (ref) v_u_35, (ref) v_u_36, (ref) v_u_37
	if v_u_35 then
		v_u_35:Destroy()
	end
	v_u_35 = nil
	v_u_36 = nil
	v_u_37 = nil
end
function v_u_2.pick(p38) -- name: pick
	-- upvalues: (ref) v_u_37
	if v_u_37 then
		v_u_37.pick(p38)
	end
end
function v_u_2.note(p39) -- name: note
	-- upvalues: (ref) v_u_37
	if v_u_37 then
		v_u_37.note(p39)
	end
end
function v_u_2.send() -- name: send
	-- upvalues: (ref) v_u_37
	if v_u_37 then
		v_u_37.send()
	end
end
local function v_u_51(_, p_u_40) -- name: callGet
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	local v41
	if v_u_3.rules == nil then
		v41 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewRules"))
	else
		v41 = v_u_3.rules
	end
	local function v46()
		-- upvalues: (ref) v_u_1, (copy) p_u_40
		local v42 = v_u_1:WaitForChild("HushNet", 10)
		if v42 then
			v42 = v42:WaitForChild("menu.get", 10)
		end
		if not v42 then
			return nil
		end
		local v43 = {
			["what"] = "reviewVerdict"
		}
		for v44, v45 in p_u_40 do
			v43[v44] = v45
		end
		return v42:InvokeServer(v43)
	end
	local v47, v48 = pcall(v46)
	if not v47 or type(v48) ~= "table" then
		return {
			["ok"] = false,
			["msg"] = nil,
			["msg"] = v41.TEXT.LOAD_FAIL
		}
	end
	if v48.error == nil then
		return v48
	end
	local v49 = {
		["ok"] = false,
		["msg"] = nil
	}
	local v50
	if v48.error == "busy" then
		v50 = v41.TEXT.BUSY
	else
		v50 = v41.TEXT.LOAD_FAIL
	end
	v49.msg = v50
	return v49
end
function v_u_2.open(p_u_52) -- name: open
	-- upvalues: (ref) v_u_35, (ref) v_u_3, (copy) v_u_1, (ref) v_u_36, (copy) v_u_2, (copy) v_u_51, (ref) v_u_37
	if not v_u_35 and (type(p_u_52) == "table" and p_u_52.root ~= nil) then
		local v53 = script.Parent
		local v_u_54 = require(v53:WaitForChild("HushUI"))
		local v55 = v_u_3.plan or require(v53:WaitForChild("ReviewDeskPlan"))
		local v56 = v_u_3.desk or require(v53:WaitForChild("ReviewDesk"))
		local v_u_57 = v_u_54.Theme
		local v_u_58 = v_u_57.color
		local v_u_59
		if v_u_3.rules == nil then
			v_u_59 = require(v_u_1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("ReviewRules"))
		else
			v_u_59 = v_u_3.rules
		end
		v_u_36 = {
			["pick"] = nil,
			["comment"] = "",
			["busy"] = false,
			["host"] = nil,
			["host"] = p_u_52
		}
		local v60 = v55.opts(v_u_57.uiScale(), v_u_57.isTouch(), v_u_57.isPhone())
		local v61 = v_u_57.uiScale()
		local v62 = math.max(v61, 0.1)
		local v63 = p_u_52.root.AbsoluteSize.X / v62
		local v64 = math.floor(v63)
		local v65 = p_u_52.root.AbsoluteSize.Y / v62
		local v66 = math.floor(v65)
		local v67 = p_u_52.watchSeconds
		local v68 = type(v67) ~= "function" and 0 or p_u_52.watchSeconds()
		local v69 = v56.verdictNote(v68, p_u_52.minWatch)
		local v70 = v_u_2.momentLines(p_u_52.moments, 10)
		if #v70 > 0 then
			local v71 = #v70
			v69 = v69 .. "\nMoments: " .. tostring(v71)
		end
		local v_u_72 = v55.verdict(v64, v66, v60, {
			["note"] = v69
		})
		v_u_35 = v_u_54.new("TextButton", {
			["Name"] = "ReviewVerdictOverlay",
			["AutoButtonColor"] = false,
			["Text"] = "",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 60,
			["Active"] = true,
			["BackgroundColor3"] = v_u_58.black,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_52.root)
		local v_u_73
		if v_u_72.scroll then
			local v74 = v_u_54.new
			local v75 = {
				["Name"] = "Panel",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["ScrollBarThickness"] = 4,
				["ZIndex"] = 61,
				["BackgroundColor3"] = v_u_58.bg
			}
			local v76 = v_u_72.panel
			v75.Position = UDim2.fromOffset(v76.x, v76.y)
			local v77 = v_u_72.panel
			v75.Size = UDim2.fromOffset(v77.w, v77.h)
			v75.CanvasSize = UDim2.fromOffset(0, v_u_72.panelH)
			v_u_73 = v74("ScrollingFrame", v75, v_u_35)
		else
			local v78 = v_u_54.new
			local v79 = {
				["Name"] = "Panel",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 61,
				["BackgroundColor3"] = v_u_58.bg
			}
			local v80 = v_u_72.panel
			v79.Position = UDim2.fromOffset(v80.x, v80.y)
			local v81 = v_u_72.panel
			v79.Size = UDim2.fromOffset(v81.w, v81.h)
			v_u_73 = v78("Frame", v79, v_u_35)
		end
		v_u_54.stroke(v_u_73, v_u_58.line, 1, 0)
		local function v94(p82, p83, p84, p85, p86, p87, p88) -- name: text
			-- upvalues: (copy) v_u_54, (copy) v_u_57, (ref) v_u_73
			local v89 = v_u_54.new
			local v90 = "TextLabel"
			local v91 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Text"] = nil,
				["TextWrapped"] = nil,
				["TextTruncate"] = nil,
				["TextXAlignment"] = nil,
				["TextYAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ClipsDescendants"] = true,
				["ZIndex"] = 62,
				["Name"] = p82,
				["FontFace"] = p88 or v_u_57.font.body,
				["TextSize"] = p85,
				["TextColor3"] = p86,
				["Text"] = p84,
				["TextWrapped"] = p87 == true
			}
			local v92
			if p87 == true then
				v92 = Enum.TextTruncate.None
			else
				v92 = Enum.TextTruncate.AtEnd
			end
			v91.TextTruncate = v92
			v91.TextXAlignment = Enum.TextXAlignment.Left
			local v93
			if p87 == true then
				v93 = Enum.TextYAlignment.Top
			else
				v93 = Enum.TextYAlignment.Center
			end
			v91.TextYAlignment = v93
			v91.Position = UDim2.fromOffset(p83.x, p83.y)
			v91.Size = UDim2.fromOffset(p83.w, p83.h)
			return v89(v90, v91, v_u_73)
		end
		local v95 = p_u_52.target and (p_u_52.target.name or "?") or "?"
		local v96 = tostring(v95)
		v94("Title", v_u_72.title, v_u_59.TEXT.VERDICT_TITLE, v55.fs(v60, 18), v_u_58.text, false, v_u_57.font.headingBold)
		v94("Who", v_u_72.who, v96, v55.fs(v60, 15), v_u_58.accent, false, v_u_57.font.bodyBold)
		v94("Note", v_u_72.note, v_u_72.noteText, v_u_72.noteSize, v_u_58.text2, true)
		local function v106(p97, p98, p99, p100, p101) -- name: button
			-- upvalues: (copy) v_u_58, (copy) v_u_54, (ref) v_u_73, (copy) v_u_57, (copy) v_u_72
			local v102 = v_u_58.raised
			local v103 = v_u_58.text
			local v104 = v_u_58.line
			if p100 == "primary" then
				v102 = v_u_58.accent
				v103 = v_u_58.ink
				v104 = v_u_58.accent
			end
			local v105 = v_u_54.new("TextButton", {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Text"] = "",
				["Position"] = nil,
				["Size"] = nil,
				["Selectable"] = true,
				["ZIndex"] = 62,
				["Name"] = p97,
				["BackgroundColor3"] = v102,
				["Position"] = UDim2.fromOffset(p98.x, p98.y),
				["Size"] = UDim2.fromOffset(p98.w, p98.h)
			}, v_u_73)
			v_u_54.stroke(v105, v104, 1, 0)
			v_u_54.new("TextLabel", {
				["Name"] = "Text",
				["BackgroundTransparency"] = 1,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Text"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 63,
				["FontFace"] = v_u_57.font.heading,
				["TextSize"] = v_u_72.btnSize,
				["TextColor3"] = v103,
				["Text"] = p99,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(6, 0),
				["Size"] = UDim2.new(1, -12, 1, 0)
			}, v105)
			v105.Activated:Connect(p101)
			return v105
		end
		local v_u_107 = {}
		local v_u_108 = nil
		local function v_u_119() -- name: paint
			-- upvalues: (copy) v_u_107, (ref) v_u_36, (copy) v_u_58, (ref) v_u_108
			for v109, v110 in v_u_107 do
				local v111 = v_u_36.pick == v109
				local v112
				if v111 then
					v112 = v_u_58.accentDeep
				else
					v112 = v_u_58.raised
				end
				v110.BackgroundColor3 = v112
				local v113 = v110:FindFirstChildOfClass("UIStroke")
				if not v113 then
					continue
				end
				local v114
				if v111 then
					v114 = v_u_58.accent
				else
					v114 = v_u_58.line
				end
				v113.Color = v114
			end
			if v_u_108 then
				local v115 = v_u_108
				local v116
				if v_u_36.pick then
					v116 = v_u_58.accent
				else
					v116 = v_u_58.raised
				end
				v115.BackgroundColor3 = v116
				local v117 = v_u_108:FindFirstChild("Text")
				if v117 then
					local v118
					if v_u_36.pick then
						v118 = v_u_58.ink
					else
						v118 = v_u_58.muted
					end
					v117.TextColor3 = v118
				end
			end
		end
		for v120, v_u_121 in v_u_59.VERDICTS do
			v_u_107[v_u_121] = v106("Pick_" .. v_u_121, v_u_72.verdicts[v120], v_u_59.VERDICT_SHORT[v_u_121], "secondary", function()
				-- upvalues: (ref) v_u_36, (copy) v_u_121, (copy) v_u_119
				v_u_36.pick = v_u_121
				v_u_119()
			end)
		end
		local v122 = v_u_54.input
		local v123 = {
			["parent"] = nil,
			["name"] = "Comment",
			["size"] = nil,
			["placeholder"] = nil,
			["text"] = "",
			["maxLength"] = nil,
			["parent"] = v_u_73
		}
		local v124 = v_u_72.comment
		v123.size = UDim2.fromOffset(v124.w, v124.h)
		v123.placeholder = v_u_59.TEXT.COMMENT
		v123.maxLength = v_u_59.COMMENT_MAX
		local v125, v_u_126 = v122(v123)
		local v127 = v_u_72.comment
		v125.Position = UDim2.fromOffset(v127.x, v127.y)
		v125.ZIndex = 62
		v_u_126:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_36, (copy) v_u_126
			v_u_36.comment = v_u_126.Text
		end)
		local function v129() -- name: dismiss
			-- upvalues: (copy) p_u_52, (ref) v_u_2
			local v128 = p_u_52.onClose
			v_u_2.close()
			if type(v128) == "function" then
				pcall(v128)
			end
		end
		v106("Cancel", v_u_72.cancel, v_u_59.TEXT.BTN_CANCEL, "secondary", v129)
		local function v142() -- name: doSend
			-- upvalues: (ref) v_u_36, (ref) v_u_2, (copy) p_u_52, (ref) v_u_73, (copy) v_u_58, (ref) v_u_51, (copy) v_u_72
			if v_u_36 ~= nil and (not v_u_36.busy and v_u_36.pick) then
				v_u_36.busy = true
				local v_u_130 = v_u_36
				local v131 = v_u_2.args
				local v132 = {
					["target"] = p_u_52.target.userId,
					["pick"] = v_u_36.pick,
					["comment"] = v_u_36.comment,
					["moments"] = p_u_52.moments
				}
				local v133 = p_u_52.watchSeconds
				v132.watchSeconds = type(v133) ~= "function" and 0 or p_u_52.watchSeconds()
				local v134 = p_u_52.raidId
				v132.raidId = type(v134) ~= "function" and "" or p_u_52.raidId()
				local v_u_135 = v131(v132)
				local v136 = v_u_73:FindFirstChild("Note")
				if v136 then
					v136.Text = "Sending ..."
					v136.TextColor3 = v_u_58.text2
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_51, (ref) p_u_52, (copy) v_u_135, (ref) v_u_36, (copy) v_u_130, (ref) v_u_2, (ref) v_u_73, (ref) v_u_72, (ref) v_u_58
					local v137 = v_u_51(p_u_52, v_u_135)
					if v_u_36 == v_u_130 then
						v_u_36.busy = false
						if v137.ok == true then
							local v138 = p_u_52.onSent
							v_u_2.close()
							if type(v138) == "function" then
								pcall(v138, v137)
								return
							end
						else
							local v139 = v137.msg or "Refused."
							local v140 = tostring(v139)
							local v141 = v_u_73:FindFirstChild("Note")
							if v141 then
								if v140 == "" then
									v140 = v_u_72.noteText
								end
								v141.Text = v140
								v141.TextColor3 = v_u_58.danger
							end
						end
					end
				end)
			end
		end
		v_u_108 = v106("Send", v_u_72.send, v_u_59.TEXT.BTN_SEND, "secondary", v142)
		v_u_37 = {
			["pick"] = function(p143) -- name: pick
				-- upvalues: (copy) v_u_59, (ref) v_u_36, (copy) v_u_119
				if v_u_59.VERDICT_TEXT[p143] ~= nil then
					v_u_36.pick = p143
					v_u_119()
				end
			end,
			["note"] = function(p144) -- name: note
				-- upvalues: (ref) v_u_36, (copy) v_u_126
				v_u_36.comment = p144
				v_u_126.Text = p144
			end,
			["send"] = v142,
			["cancel"] = v129
		}
		v_u_119()
	end
end
return v_u_2