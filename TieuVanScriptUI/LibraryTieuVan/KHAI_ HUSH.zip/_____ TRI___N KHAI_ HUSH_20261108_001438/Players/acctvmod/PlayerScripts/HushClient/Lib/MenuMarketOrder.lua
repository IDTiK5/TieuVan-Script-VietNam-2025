-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketOrder

local v_u_64 = {
	["QTY_QUICK"] = { 1, 10, 50 },
	["SELL_FILLS"] = 3,
	["TEXT"] = {
		["title"] = "Buy order",
		["priceLabel"] = "PRICE EACH",
		["qtyLabel"] = "QUANTITY",
		["matchBtn"] = "MATCH BEST ORDER",
		["stepBtn"] = "ONE STEP ABOVE",
		["cheapBtn"] = "CHEAPEST LISTING",
		["maxBtn"] = "MAX",
		["place"] = "Place order",
		["buyNow"] = "Buy now",
		["enterPrice"] = "Enter a price.",
		["total"] = "Total set aside: {total}",
		["after"] = "Your Cash after: {cash}",
		["ahead"] = "Orders ahead of you at this price: {n}",
		["pays"] = "You pay exactly this price. The seller pays the fee.",
		["steps"] = "Prices above $9,999 count in steps (12,345 counts as 12,340).",
		["counts"] = "Your order counts at {u} each.",
		["ends"] = "Ends in {days} days, unused Cash comes back.",
		["cond"] = "Only items in good condition (70 percent and up) can fill this order.",
		["open"] = "You have {n} of {max} open buy orders.",
		["crosses"] = "A listing for {ask} each is already cheaper. Buy it now instead.",
		["confirm"] = "Place a buy order for {lot} at {u} each? {total} is set aside until the order is filled or you cancel it.",
		["sellTitle"] = "Sell now",
		["sellAsk"] = "Sell {lot} to the best buy orders?",
		["sellBest"] = "Best buy order: {u} each, {q} wanted.",
		["sellMin"] = "You sell for at least {u} each.",
		["sellGet"] = "You receive about {net} after the fee.",
		["sellFills"] = "One click fills up to 3 buy orders, the best price first.",
		["sellNone"] = "You have none of these.",
		["selling"] = "Selling",
		["sold"] = "Sold {sold} of {n}.",
		["soldAll"] = "Sold {sold}.",
		["sellMore"] = "Sell more",
		["strip"] = "Remove attachments first ({n})",
		["stripNote"] = "The attachments come off first and stay in your stash.",
		["collect"] = "Collected.",
		["placing"] = "Placing the order"
	},
	["fill"] = function(p1, p_u_2) -- name: fill
		return string.gsub(p1, "{(%w+)}", function(p3)
			-- upvalues: (copy) p_u_2
			local v4 = p_u_2[p3]
			return v4 == nil and "?" or tostring(v4)
		end)
	end,
	["gate"] = function(p5, p6, p7) -- name: gate
		if type(p5) == "table" then
			if p5.ok == false then
				local v8 = false
				local v9 = p5.text
				if type(v9) == "string" and p5.text ~= "" then
					return v8, p5.text
				else
					return v8, p6.text(p7, p5.code or "STORE")
				end
			else
				local v10 = p5.on
				if type(v10) == "table" then
					if v10.freeze == true then
						return false, p6.text(p7, "FREEZE")
					end
					if v10.scope == false then
						return false, p6.text(p7, "SCOPE")
					end
					if v10.drain == true then
						return false, p6.text(p7, "DRAIN")
					end
					if v10.book == false then
						return false, p6.text(p7, "OFF_BOOK")
					end
				end
				local v11 = p5.can
				if type(v11) == "table" and (v11.why == "PAID_BLOCKED" or (v11.why == "POLICY_WAIT" or (v11.why == "FREEZE" or v11.why == "SCOPE"))) then
					local v12 = false
					local v13 = v11.text
					if type(v13) == "string" and v11.text ~= "" then
						return v12, v11.text
					else
						return v12, p6.text(p7, v11.why)
					end
				else
					local v14 = p5.orders
					if type(v14) == "table" then
						if v14.can == false then
							local v15 = false
							local v16 = v14.text
							if type(v16) == "string" and v14.text ~= "" then
								return v15, v14.text
							else
								return v15, p6.text(p7, v14.why or "OFF_BOOK")
							end
						end
						if v14.full == true then
							return false, p6.text(p7, "ORDERS_FULL")
						end
					end
					return true, nil
				end
			end
		else
			return true, nil
		end
	end,
	["effective"] = function(p17, p18) -- name: effective
		local v19
		if type(p18) == "number" and (p18 == p18 and p18 > -1000000000000000) then
			v19 = p18 < 1000000000000000
		else
			v19 = false
		end
		if not v19 or (p18 ~= math.floor(p18) or p18 < 1) then
			return nil
		end
		local v20 = p17.bk
		if v20 ~= nil then
			local v21 = v20.step
			if type(v21) == "function" then
				local v22 = v20.step
				local v23, v24 = pcall(v22, p18)
				if v23 then
					local v25
					if type(v24) == "number" and (v24 == v24 and v24 > -1000000000000000) then
						v25 = v24 < 1000000000000000
					else
						v25 = false
					end
					if v25 then
						return v24
					end
				end
				return nil
			end
		end
		return p18
	end,
	["limits"] = function(p26) -- name: limits
		local v27
		if type(p26) == "table" then
			local v28 = p26.orders
			v27 = type(v28) ~= "table" and {} or p26.orders
		else
			v27 = {}
		end
		local v29 = {}
		local v30 = v27.qtyMax
		local v31
		if type(v30) == "number" and (v30 == v30 and v30 > -1000000000000000) then
			v31 = v30 < 1000000000000000
		else
			v31 = false
		end
		v29.qtyMax = not v31 and 255 or v27.qtyMax
		local v32 = v27.stackQty
		local v33
		if type(v32) == "number" and (v32 == v32 and v32 > -1000000000000000) then
			v33 = v32 < 1000000000000000
		else
			v33 = false
		end
		v29.stackQty = not v33 and 20 or v27.stackQty
		local v34 = v27.days
		local v35
		if type(v34) == "number" and (v34 == v34 and v34 > -1000000000000000) then
			v35 = v34 < 1000000000000000
		else
			v35 = false
		end
		v29.days = not v35 and 14 or v27.days
		local v36 = v27.open
		local v37
		if type(v36) == "number" and (v36 == v36 and v36 > -1000000000000000) then
			v37 = v36 < 1000000000000000
		else
			v37 = false
		end
		v29.open = not v37 and 0 or v27.open
		local v38 = v27.max
		local v39
		if type(v38) == "number" and (v38 == v38 and v38 > -1000000000000000) then
			v39 = v38 < 1000000000000000
		else
			v39 = false
		end
		v29.max = not v39 and 50 or v27.max
		return v29
	end,
	["maxQty"] = function(p40, p41, p42, p43) -- name: maxQty
		local v44 = p41.qtyMax
		if type(p40) == "table" and (p40.stack or 1) <= 1 then
			local v45 = p41.stackQty
			v44 = math.min(v44, v45)
		end
		if p42 ~= nil and p42 > 0 then
			local v46
			if type(p43) == "number" and (p43 == p43 and p43 > -1000000000000000) then
				v46 = p43 < 1000000000000000
			else
				v46 = false
			end
			if v46 then
				local v47 = p43 / p42
				local v48 = math.floor(v47)
				local v49 = math.max(1, v48)
				v44 = math.min(v44, v49)
			end
		end
		return math.max(1, v44)
	end,
	["check"] = function(p50, p51, p52, p53) -- name: check
		local v54 = p50.bk
		if v54 ~= nil then
			local v55 = v54.checkOrder
			if type(v55) == "function" then
				local v56, v57, v58 = v54.checkOrder(p51, p52, {
					["single"] = p53
				})
				if v56 then
					return nil, nil, v58
				else
					return v57 or "BAD", nil, nil
				end
			end
		end
		local v59
		if type(p51) == "number" and (p51 == p51 and p51 > -1000000000000000) then
			v59 = p51 < 1000000000000000
		else
			v59 = false
		end
		if v59 and (p51 == math.floor(p51) and (p51 >= 1 and p51 <= 99999999)) then
			local v60
			if type(p52) == "number" and (p52 == p52 and p52 > -1000000000000000) then
				v60 = p52 < 1000000000000000
			else
				v60 = false
			end
			if v60 and (p52 == math.floor(p52) and (p52 >= 1 and p52 <= 255)) then
				if p53 and p52 > 20 then
					return "QTY_STACK", nil, nil
				elseif p51 * p52 > 99999999 then
					return "PRICE_RANGE", nil, nil
				else
					return nil, nil, p51
				end
			else
				return "QTY", nil, nil
			end
		else
			return "PRICE_RANGE", nil, nil
		end
	end,
	["crosses"] = function(p61, p62) -- name: crosses
		local v63
		if type(p61) == "number" and (p61 == p61 and p61 > -1000000000000000) then
			v63 = p61 < 1000000000000000
		else
			v63 = false
		end
		if v63 then
			if type(p62) == "number" and (p62 == p62 and p62 > -1000000000000000) then
				v63 = p62 < 1000000000000000
			else
				v63 = false
			end
			if v63 then
				v63 = p62 <= p61
			end
		end
		return v63
	end
}
local function v_u_77(p65, p66) -- name: cheapestAsk
	local v67 = nil
	if type(p65) == "table" then
		for _, v68 in p65 do
			if v68.own == true then
				continue
			end
			local v69 = v68.u
			if not v69 then
				local v70 = v68.p
				local v71
				if type(v70) == "number" and (v70 == v70 and v70 > -1000000000000000) then
					v71 = v70 < 1000000000000000
				else
					v71 = false
				end
				if v71 then
					local v72 = v68.n
					local v73
					if type(v72) == "number" and (v72 == v72 and v72 > -1000000000000000) then
						v73 = v72 < 1000000000000000
					else
						v73 = false
					end
					if v73 and v68.n > 0 then
						v69 = v68.p / v68.n
					else
						v69 = nil
					end
				else
					v69 = nil
				end
			end
			local v74
			if type(v69) == "number" and (v69 == v69 and v69 > -1000000000000000) then
				v74 = v69 < 1000000000000000
			else
				v74 = false
			end
			if not v74 or v67 ~= nil and v69 >= v67 then
				continue
			end
			v67 = v69
		end
	end
	if v67 == nil and type(p66) == "table" then
		local v75 = p66.asks
		if type(v75) == "table" then
			for _, v76 in p66.asks do
				if v76.own == true or v67 ~= nil and v76.u >= v67 then
					continue
				end
				v67 = v76.u
			end
		end
	end
	return v67
end
v_u_64.cheapestAsk = v_u_77
function v_u_64.quick(p78, p79, p80) -- name: quick
	-- upvalues: (copy) v_u_77
	local v81 = {}
	if type(p79) ~= "table" or not p79.ok then
		v90 = v_u_77(p80, p79)
		if v90 ~= nil then
			v81.cheapest = math.ceil(v90)
		end
		return v81
	end
	local v82 = p79.bids
	if type(v82) ~= "table" then
		v90 = v_u_77(p80, p79)
		if v90 ~= nil then
			v81.cheapest = math.ceil(v90)
		end
		return v81
	end
	local v83 = nil
	for _, v84 in p79.bids do
		if v84.own == true then
			continue
		end
		v83 = v84.u
	end
	if v83 == nil then
		v90 = v_u_77(p80, p79)
		if v90 ~= nil then
			v81.cheapest = math.ceil(v90)
		end
		return v81
	end
	v81.match = v83
	local v85 = p78.bk
	if v85 == nil then
		v81.step = v83 + 1
	else
		local v86 = v85.level
		if type(v86) == "function" then
			local v87 = v85.price
			if type(v87) == "function" then
				local v88 = v85.level(v83)
				local v89
				if v88 == nil then
					v89 = nil
				else
					v89 = v85.price(v88 + 1)
				end
				v81.step = v89
				v90 = v_u_77(p80, p79)
				if v90 ~= nil then
					v81.cheapest = math.ceil(v90)
				end
				return v81
			end
			v81.step = v83 + 1
		else
			v81.step = v83 + 1
		end
	end
	local v90 = v_u_77(p80, p79)
	if v90 ~= nil then
		v81.cheapest = math.ceil(v90)
	end
	return v81
end
function v_u_64.ahead(p91, p92) -- name: ahead
	if type(p91) ~= "table" or (not p91.ok or p92 == nil) then
		return nil
	end
	if p91.bidsBusy then
		return nil
	end
	local v93 = nil
	for _, v94 in p91.bids do
		if v94.u == p92 then
			if v94.plus then
				local v95 = v94.c
				return tostring(v95) .. "+"
			else
				local v96 = v94.c
				return tostring(v96)
			end
		end
		v93 = v94
	end
	return v93 == nil and "0" or (v93.u < p92 and "0" or (not p91.more and "0" or nil))
end
local function v_u_111(p97, p98, p99) -- name: feeOf
	local v100 = p97.bk
	if v100 ~= nil then
		local v101 = v100.fillFee
		if type(v101) == "function" then
			local v102 = v100.fillFee
			local v103, v104, v105 = pcall(v102, p98, p99)
			if v103 then
				local v106
				if type(v104) == "number" and (v104 == v104 and v104 > -1000000000000000) then
					v106 = v104 < 1000000000000000
				else
					v106 = false
				end
				if v106 then
					local v107
					if type(v105) == "number" and (v105 == v105 and v105 > -1000000000000000) then
						v107 = v105 < 1000000000000000
					else
						v107 = false
					end
					if v107 then
						return v104, v105
					end
				end
			end
		end
	end
	local v108 = p98 * p99 / 100
	local v109 = math.floor(v108)
	local v110 = p98 >= 2 and v109 < 1 and 1 or v109
	return v110, p98 - v110
end
v_u_64.feeOf = v_u_111
function v_u_64.plan(p112, p113, p114, p115, p116) -- name: plan
	-- upvalues: (copy) v_u_64, (copy) v_u_111
	local v117 = {
		["sold"] = 0,
		["gross"] = 0,
		["fee"] = 0,
		["net"] = 0,
		["fills"] = 0
	}
	if type(p113) ~= "table" then
		return v117
	end
	for _, v118 in p113 do
		if v117.fills >= v_u_64.SELL_FILLS or p114 <= 0 then
			break
		end
		if v118.own == true then
			continue
		end
		local v119 = v118.u
		local v120
		if type(v119) == "number" and (v119 == v119 and v119 > -1000000000000000) then
			v120 = v119 < 1000000000000000
		else
			v120 = false
		end
		if not v120 then
			continue
		end
		local v121 = v118.q
		local v122
		if type(v121) == "number" and (v121 == v121 and v121 > -1000000000000000) then
			v122 = v121 < 1000000000000000
		else
			v122 = false
		end
		if not v122 or (v118.q <= 0 or p116 ~= nil and p116 > v118.u) then
			continue
		end
		local v123 = v118.q
		local v124 = math.min(p114, v123)
		local v125 = v118.u * v124
		local v126, v127 = v_u_111(p112, v125, p115)
		v117.sold = v117.sold + v124
		v117.gross = v117.gross + v125
		v117.fee = v117.fee + v126
		v117.net = v117.net + v127
		v117.fills = v117.fills + 1
		p114 = p114 - v124
		if v117.first ~= nil then
			continue
		end
		v117.first = v118.u
		v117.wanted = v118.q
	end
	return v117
end
function v_u_64.pick(p128, p129, p130) -- name: pick
	local v131 = nil
	local v132 = -1
	local v133 = nil
	local v134 = nil
	if type(p128) == "table" then
		for _, v135 in p128 do
			if type(v135) ~= "table" or v135.id ~= p129 then
				continue
			end
			local v136, v137, v138 = p130(v135)
			if v136 or v137 == "STRIP_FIRST" then
				local v139 = v135.dur
				local v140 = (type(v139) ~= "number" and 1 or v135.dur) * 1000 + (v135.n or 1) + (v136 and 100000 or 0)
				if v132 >= v140 then
					continue
				end
				v131 = v135
				v132 = v140
			else
				if v133 ~= nil then
					continue
				end
				v134 = v138
				v133 = v137
			end
		end
		if v131 == nil then
			return nil, v133, v134
		else
			return v131, nil, nil
		end
	else
		return nil, nil, nil
	end
end
function v_u_64.confirmText(p141, p142, p143, p144) -- name: confirmText
	-- upvalues: (copy) v_u_64
	local v145 = v_u_64.TEXT.confirm
	local v_u_146 = {
		["lot"] = p142,
		["u"] = p141.money(p143),
		["total"] = p141.money(p144)
	}
	return string.gsub(v145, "{(%w+)}", function(p147)
		-- upvalues: (copy) v_u_146
		local v148 = v_u_146[p147]
		return v148 == nil and "?" or tostring(v148)
	end)
end
function v_u_64.lotName(p149, p150, p151) -- name: lotName
	if type(p149) == "table" then
		local v152 = p149.name
		if type(v152) == "string" then
			p150 = p149.name
		end
	end
	if p151 > 1 then
		return ("%d x %s"):format(p151, p150)
	else
		return p150
	end
end
function v_u_64.openSellNow(p_u_153, p_u_154) -- name: openSellNow
	-- upvalues: (copy) v_u_64
	local v_u_155 = p_u_153.ui
	local v_u_156 = p_u_153.theme
	local v_u_157 = p_u_153.C
	local v_u_158 = p_u_153.Data
	local v_u_159 = p_u_153.data
	local v_u_160 = p_u_153.h
	local v_u_161 = p_u_154.inst
	local v_u_162 = p_u_154.def
	local v_u_163 = {}
	local v164 = v_u_161.n or 1
	local v165 = type(v_u_162) == "table" and (v_u_162.stack or 1) or 1
	local v166 = math.min(v164, v165)
	local v_u_167 = math.max(1, v166)
	local v_u_168 = v_u_167
	local v_u_169 = false
	local v_u_170 = false
	local v_u_171 = nil
	local v_u_172 = nil
	local v_u_173 = nil
	local v_u_174 = nil
	local v_u_175 = p_u_154.strip == true
	local v_u_176 = false
	local v_u_177 = p_u_153.state and p_u_153.state.fee or (p_u_153.state and p_u_153.state.tune and (p_u_153.state.tune.feePct or 5) or 5)
	local function v_u_181() -- name: levelsNow
		-- upvalues: (copy) p_u_154
		local v178
		if p_u_154.levels then
			v178 = p_u_154.levels()
		else
			v178 = nil
		end
		if type(v178) == "table" and #v178 > 0 then
			return v178
		end
		if p_u_154.best then
			local v179 = p_u_154.best.u
			local v180
			if type(v179) == "number" and (v179 == v179 and v179 > -1000000000000000) then
				v180 = v179 < 1000000000000000
			else
				v180 = false
			end
			if v180 then
				return {
					{
						["u"] = nil,
						["q"] = nil,
						["own"] = false,
						["u"] = p_u_154.best.u,
						["q"] = p_u_154.best.q or 1
					}
				}
			end
		end
		return {}
	end
	local function v_u_183() -- name: clear
		-- upvalues: (ref) v_u_172, (ref) v_u_173, (ref) v_u_174
		if v_u_172 then
			for _, v182 in v_u_172:GetChildren() do
				if v182:IsA("UIListLayout") then
					continue
				end
				v182:Destroy()
			end
		end
		v_u_173 = nil
		v_u_174 = nil
	end
	local function v_u_184() -- name: close
		-- upvalues: (ref) v_u_171, (ref) v_u_170
		if v_u_171 and not v_u_170 then
			v_u_171.close()
		end
	end
	local function v_u_199() -- name: paint
		-- upvalues: (ref) v_u_174, (ref) v_u_168, (ref) v_u_64, (copy) v_u_158, (copy) v_u_181, (copy) v_u_177, (copy) p_u_154, (ref) v_u_173
		if v_u_174 then
			local v185 = v_u_168
			v_u_174.Text = tostring(v185)
		end
		local v186 = v_u_64.plan
		local v187 = v_u_158
		local v188 = v_u_181()
		local v189 = v_u_168
		local v190 = v_u_177
		local v191
		if p_u_154.level then
			v191 = p_u_154.level.u
		else
			v191 = nil
		end
		local v192 = v186(v187, v188, v189, v190, v191)
		if v_u_173 then
			local v193 = v_u_173
			local v194
			if v192.sold > 0 then
				local v195 = v_u_64.TEXT.sellGet
				local v_u_196 = {
					["net"] = v_u_158.money(v192.net)
				}
				v194 = string.gsub(v195, "{(%w+)}", function(p197)
					-- upvalues: (copy) v_u_196
					local v198 = v_u_196[p197]
					return v198 == nil and "?" or tostring(v198)
				end)
			else
				v194 = ""
			end
			v193.Text = v194
		end
	end
	local function v_u_208(p200) -- name: buttons
		-- upvalues: (ref) v_u_171, (copy) v_u_163, (copy) v_u_155, (copy) v_u_156, (ref) v_u_172, (copy) v_u_160
		local v201
		if v_u_171 then
			v201 = v_u_171.frame
		else
			v201 = nil
		end
		local v202
		if v201 then
			v202 = v201:FindFirstChild("Footer", true)
		else
			v202 = nil
		end
		if v202 and v202:IsA("GuiObject") then
			v202.Visible = false
		end
		v_u_163.buttons = {}
		for _, v203 in p200 do
			v_u_163.buttons[v203.text] = v203.onClick
		end
		local v204 = v_u_155.new("Frame", {
			["Name"] = "Buttons",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 90,
			["Size"] = UDim2.new(1, 0, 0, v_u_156.touch(v_u_156.control))
		}, v_u_172)
		v_u_155.layout(v204, "h", 8, "right")
		for v205, v206 in p200 do
			local v207 = v_u_160.button(v204, v206.text, v206.kind, v206.onClick, {
				["order"] = v205,
				["name"] = "Result_" .. v206.text
			})
			if v205 ~= #p200 then
				continue
			end
			v207:SetAttribute("PadDefault", true)
		end
		v_u_155.new("Frame", {
			["Name"] = "FooterPad",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 91,
			["Size"] = UDim2.new(1, 0, 0, v_u_156.space.l - 3)
		}, v_u_172)
	end
	local function v_u_235(p209, p210) -- name: showResult
		-- upvalues: (copy) v_u_183, (copy) v_u_158, (copy) p_u_153, (copy) v_u_155, (ref) v_u_172, (copy) v_u_157, (ref) v_u_64, (copy) v_u_161, (ref) v_u_168, (copy) v_u_167, (copy) v_u_163, (copy) v_u_184, (copy) v_u_208, (copy) p_u_154
		v_u_183()
		local v211 = p209.ok
		if v211 then
			v211 = p209.state ~= "processing"
		end
		local v212 = p209.data
		local v213 = type(v212) ~= "table" and {} or p209.data
		local v214 = p209.text
		if type(v214) ~= "string" or v214 == "" then
			if p209.ok then
				v214 = v_u_158.text(p_u_153.rules, "PENDING")
			else
				v214 = v_u_158.text(p_u_153.rules, p209.code or "STORE")
			end
		end
		local v215 = v_u_155.new("Frame", {
			["Name"] = "Result",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_172)
		v_u_155.layout(v215, "v", 8)
		local v216 = v_u_155.label
		local v217 = {
			["parent"] = nil,
			["name"] = "ResultText",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v215,
			["text"] = v214
		}
		local v218
		if v211 then
			v218 = v_u_157.text
		elseif p209.ok then
			v218 = v_u_157.info
		else
			v218 = v_u_157.danger
		end
		v217.color = v218
		v216(v217)
		local v219 = v213.sold
		local v220
		if type(v219) == "number" then
			v220 = v213.sold
		else
			v220 = nil
		end
		local v221 = {}
		if v211 and v220 ~= nil then
			if v220 < p210 then
				local v222 = v_u_155.label
				local v223 = {
					["parent"] = nil,
					["name"] = "Progress",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = v215
				}
				local v224 = v_u_64.TEXT.sold
				local v_u_225 = {
					["sold"] = v_u_158.commas(v220),
					["n"] = v_u_158.commas(p210)
				}
				v223.text = string.gsub(v224, "{(%w+)}", function(p226)
					-- upvalues: (copy) v_u_225
					local v227 = v_u_225[p226]
					return v227 == nil and "?" or tostring(v227)
				end)
				v223.color = v_u_157.text2
				v222(v223)
			end
			local v_u_228 = p210 - v220
			if v_u_228 > 0 and (v_u_161.n or 1) - v220 > 0 then
				local v232 = {
					["text"] = nil,
					["kind"] = "secondary",
					["onClick"] = nil,
					["text"] = v_u_64.TEXT.sellMore,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_168, (copy) v_u_228, (ref) v_u_167, (ref) v_u_163
						local v229 = v_u_228
						local v230 = v_u_167
						local v231 = math.min(v229, v230)
						v_u_168 = math.max(1, v231)
						v_u_163.rebuild()
					end
				}
				table.insert(v221, v232)
			end
		end
		local v233 = {
			["text"] = "Close",
			["kind"] = "primary",
			["onClick"] = nil,
			["onClick"] = v_u_184
		}
		table.insert(v221, v233)
		v_u_208(v221)
		if p_u_154.onDone then
			local v234 = p_u_154.onDone
			pcall(v234, p209)
		end
	end
	local function v_u_254() -- name: run
		-- upvalues: (ref) v_u_169, (copy) v_u_183, (ref) v_u_171, (copy) v_u_155, (ref) v_u_172, (ref) v_u_64, (copy) v_u_157, (ref) v_u_168, (copy) v_u_161, (copy) p_u_154, (copy) v_u_175, (ref) v_u_176, (copy) p_u_153, (copy) v_u_159, (ref) v_u_170, (copy) v_u_235
		if not v_u_169 then
			v_u_169 = true
			v_u_183()
			local v236
			if v_u_171 then
				v236 = v_u_171.frame
			else
				v236 = nil
			end
			local v237
			if v236 then
				v237 = v236:FindFirstChild("Footer", true)
			else
				v237 = nil
			end
			if v237 and v237:IsA("GuiObject") then
				v237.Visible = false
			end
			local v238 = v_u_155.new("Frame", {
				["Name"] = "Progress",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.new(1, 0, 0, 56)
			}, v_u_172)
			v_u_155.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v238,
				["text"] = v_u_64.TEXT.selling,
				["color"] = v_u_157.text,
				["size"] = UDim2.new(1, 0, 0, 24)
			})
			local v_u_239 = v_u_168
			local v_u_240 = {
				["uid"] = v_u_161.uid,
				["n"] = v_u_168
			}
			local v241
			if p_u_154.level then
				v241 = p_u_154.level.u
			else
				v241 = nil
			end
			v_u_240.minPrice = v241
			local v242 = v_u_175
			if v242 then
				v242 = v_u_176
			end
			v_u_240.strip = v242
			local v_u_243 = p_u_153
			local v244 = v_u_161.id
			local v_u_245 = nil
			local function v246()
				-- upvalues: (ref) v_u_245, (copy) v_u_243
				v_u_245 = v_u_243.mc.cctx.controllers.BmNotes
			end
			pcall(v246)
			if v_u_245 then
				local v247 = v_u_245.quiet
				if type(v247) == "function" then
					v_u_245.quiet("hitBid", v244)
				end
			end
			local v_u_248 = p_u_153
			local v249 = v_u_161.id
			local v_u_250 = nil
			local function v251()
				-- upvalues: (ref) v_u_250, (copy) v_u_248
				v_u_250 = v_u_248.mc.cctx.controllers.BmNotes
			end
			pcall(v251)
			if v_u_250 then
				local v252 = v_u_250.quiet
				if type(v252) == "function" then
					v_u_250.quiet("hitBidPart", v249)
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_159, (copy) v_u_240, (ref) v_u_169, (ref) v_u_170, (ref) v_u_235, (copy) v_u_239, (ref) p_u_153
				local v253 = v_u_159:sellNow(v_u_240)
				v_u_169 = false
				if not v_u_170 then
					v_u_235(v253, v_u_239)
					p_u_153.refreshState(true)
				end
			end)
		end
	end
	function v_u_163.rebuild() -- name: rebuild
		-- upvalues: (copy) v_u_183, (ref) v_u_171, (ref) v_u_64, (copy) v_u_158, (copy) v_u_181, (ref) v_u_168, (copy) v_u_177, (copy) p_u_154, (copy) v_u_162, (copy) v_u_161, (copy) v_u_155, (ref) v_u_172, (copy) v_u_157, (copy) v_u_167, (copy) v_u_156, (copy) v_u_199, (ref) v_u_174, (copy) v_u_160, (ref) v_u_173, (copy) v_u_175, (ref) v_u_176
		v_u_183()
		local v255
		if v_u_171 then
			v255 = v_u_171.frame
		else
			v255 = nil
		end
		local v256
		if v255 then
			v256 = v255:FindFirstChild("Footer", true)
		else
			v256 = nil
		end
		if v256 and v256:IsA("GuiObject") then
			v256.Visible = true
		end
		local v257 = v_u_64.plan
		local v258 = v_u_158
		local v259 = v_u_181()
		local v260 = v_u_168
		local v261 = v_u_177
		local v262
		if p_u_154.level then
			v262 = p_u_154.level.u
		else
			v262 = nil
		end
		local v263 = v257(v258, v259, v260, v261, v262)
		local v264 = v_u_162
		local v265 = v_u_161.id
		local v266 = v_u_168
		if type(v264) == "table" then
			local v267 = v264.name
			if type(v267) == "string" then
				v265 = v264.name
			end
		end
		if v266 > 1 then
			v265 = ("%d x %s"):format(v266, v265)
		end
		local v268 = v_u_155.label
		local v269 = {
			["parent"] = nil,
			["name"] = "Ask",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 1,
			["parent"] = v_u_172
		}
		local v270 = v_u_64.TEXT.sellAsk
		local v_u_271 = {
			["lot"] = v265
		}
		v269.text = string.gsub(v270, "{(%w+)}", function(p272)
			-- upvalues: (copy) v_u_271
			local v273 = v_u_271[p272]
			return v273 == nil and "?" or tostring(v273)
		end)
		v269.color = v_u_157.text
		v268(v269)
		if v_u_167 > 1 and (v_u_161.n or 1) > 1 then
			local v274 = v_u_155.new("Frame", {
				["Name"] = "Qty",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, v_u_156.touch(40))
			}, v_u_172)
			v_u_155.label({
				["parent"] = nil,
				["text"] = nil,
				["style"] = "caps",
				["color"] = nil,
				["size"] = nil,
				["parent"] = v274,
				["text"] = v_u_64.TEXT.qtyLabel,
				["color"] = v_u_157.text2,
				["size"] = UDim2.fromOffset(100, v_u_156.touch(40))
			})
			local v275 = v_u_156.touch(40)
			v_u_155.iconButton({
				["parent"] = nil,
				["icon"] = "minus",
				["size"] = nil,
				["kind"] = "secondary",
				["name"] = "Step_minus",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v274,
				["size"] = v275,
				["position"] = UDim2.fromOffset(104, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_168, (ref) v_u_199
					local v276 = v_u_168 - 1
					v_u_168 = math.max(1, v276)
					v_u_199()
				end
			})
			local v277 = v_u_155.label
			local v278 = {
				["parent"] = nil,
				["name"] = "Units",
				["text"] = nil,
				["style"] = "monoL",
				["textSize"] = 20,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v274
			}
			local v279 = v_u_168
			v278.text = tostring(v279)
			v278.position = UDim2.fromOffset(104 + v275 + 4, 0)
			v278.size = UDim2.fromOffset(70, v_u_156.touch(40))
			v_u_174 = v277(v278)
			v_u_155.iconButton({
				["parent"] = nil,
				["icon"] = "plus",
				["size"] = nil,
				["kind"] = "secondary",
				["name"] = "Step_plus",
				["position"] = nil,
				["onClick"] = nil,
				["parent"] = v274,
				["size"] = v275,
				["position"] = UDim2.fromOffset(104 + v275 + 4 + 70 + 4, 0),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_168, (ref) v_u_167, (ref) v_u_199
					local v280 = v_u_167
					local v281 = v_u_168 + 1
					v_u_168 = math.min(v280, v281)
					v_u_199()
				end
			})
			v_u_160.button(v274, v_u_64.TEXT.maxBtn, "secondary", function()
				-- upvalues: (ref) v_u_168, (ref) v_u_167, (ref) v_u_199
				v_u_168 = v_u_167
				v_u_199()
			end, {
				["name"] = "Step_Max",
				["height"] = 40,
				["width"] = 76,
				["position"] = nil,
				["position"] = UDim2.fromOffset(104 + v275 + 4 + 70 + 4 + v275 + 6, 0)
			})
		end
		local v282 = nil
		for _, v283 in v_u_181() do
			if v283.own == true then
				continue
			end
			v282 = v283
		end
		if v282 then
			local v284 = v_u_155.label
			local v285 = {
				["parent"] = nil,
				["name"] = "Best",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["parent"] = v_u_172
			}
			local v286 = v_u_64.TEXT.sellBest
			local v_u_287 = {
				["u"] = v_u_158.unitMoney(v282.u),
				["q"] = v_u_158.commas(v282.q)
			}
			v285.text = string.gsub(v286, "{(%w+)}", function(p288)
				-- upvalues: (copy) v_u_287
				local v289 = v_u_287[p288]
				return v289 == nil and "?" or tostring(v289)
			end)
			v285.color = v_u_157.text2
			v284(v285)
		end
		if p_u_154.level then
			local v290 = v_u_155.label
			local v291 = {
				["parent"] = nil,
				["name"] = "Min",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 4,
				["parent"] = v_u_172
			}
			local v292 = v_u_64.TEXT.sellMin
			local v_u_293 = {
				["u"] = v_u_158.unitMoney(p_u_154.level.u)
			}
			v291.text = string.gsub(v292, "{(%w+)}", function(p294)
				-- upvalues: (copy) v_u_293
				local v295 = v_u_293[p294]
				return v295 == nil and "?" or tostring(v295)
			end)
			v291.color = v_u_157.text2
			v290(v291)
		end
		local v296 = v_u_155.label
		local v297 = {
			["parent"] = nil,
			["name"] = "Net",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 5,
			["parent"] = v_u_172
		}
		local v298
		if v263.sold > 0 then
			local v299 = v_u_64.TEXT.sellGet
			local v_u_300 = {
				["net"] = v_u_158.money(v263.net)
			}
			v298 = string.gsub(v299, "{(%w+)}", function(p301)
				-- upvalues: (copy) v_u_300
				local v302 = v_u_300[p301]
				return v302 == nil and "?" or tostring(v302)
			end)
		else
			v298 = ""
		end
		v297.text = v298
		v297.color = v_u_157.text
		v_u_173 = v296(v297)
		v_u_155.label({
			["parent"] = nil,
			["name"] = "Fills",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = 6,
			["parent"] = v_u_172,
			["text"] = v_u_64.TEXT.sellFills,
			["color"] = v_u_157.muted
		})
		if v_u_175 then
			local v303 = v_u_161.mods
			local v304 = type(v303) == "table" and #v_u_161.mods or 1
			local v305 = v_u_160.toggleRow
			local v306 = v_u_172
			local v307 = v_u_64.TEXT.strip
			local v_u_308 = {
				["n"] = v304
			}
			v305(v306, string.gsub(v307, "{(%w+)}", function(p309)
				-- upvalues: (copy) v_u_308
				local v310 = v_u_308[p309]
				return v310 == nil and "?" or tostring(v310)
			end), v_u_176, function(p311)
				-- upvalues: (ref) v_u_176, (ref) v_u_199
				v_u_176 = p311
				v_u_199()
			end, 7)
			v_u_155.label({
				["parent"] = nil,
				["name"] = "StripNote",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 8,
				["parent"] = v_u_172,
				["text"] = v_u_64.TEXT.stripNote,
				["color"] = v_u_157.muted
			})
		end
		v_u_199()
	end
	local v_u_318 = {
		{
			["text"] = "Cancel",
			["kind"] = "secondary"
		},
		{
			["text"] = "Sell now",
			["kind"] = "primary",
			["onClick"] = nil,
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_64, (copy) v_u_158, (copy) v_u_181, (ref) v_u_168, (copy) v_u_177, (copy) p_u_154, (ref) v_u_169, (copy) v_u_175, (ref) v_u_176, (copy) v_u_254
				local v312 = v_u_64.plan
				local v313 = v_u_158
				local v314 = v_u_181()
				local v315 = v_u_168
				local v316 = v_u_177
				local v317
				if p_u_154.level then
					v317 = p_u_154.level.u
				else
					v317 = nil
				end
				if v_u_169 or (v312(v313, v314, v315, v316, v317).sold <= 0 or v_u_175 and not v_u_176) then
					return true
				end
				v_u_254()
				return true
			end
		}
	}
	v_u_163.confirmButtons = v_u_318
	local v_u_320 = v_u_155.modal({
		["title"] = nil,
		["width"] = 500,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil,
		["title"] = v_u_64.TEXT.sellTitle,
		["build"] = function(p319) -- name: build
			-- upvalues: (ref) v_u_172, (copy) v_u_163
			v_u_172 = p319
			v_u_163.rebuild()
		end,
		["buttons"] = v_u_318,
		["onClose"] = function() -- name: onClose
			-- upvalues: (ref) v_u_170
			v_u_170 = true
		end
	})
	v_u_163.modal = v_u_320
	function v_u_163.press(p321) -- name: press
		-- upvalues: (copy) v_u_163, (copy) v_u_318
		local v322 = (v_u_163.buttons or {})[p321]
		if v322 then
			v322()
			return true
		else
			for _, v323 in v_u_318 do
				if v323.text ~= p321 or not v323.onClick then
					continue
				end
				v323.onClick()
				return true
			end
			return false
		end
	end
	function v_u_163.state() -- name: state
		-- upvalues: (ref) v_u_168, (copy) v_u_167, (ref) v_u_169, (ref) v_u_170, (ref) v_u_64, (copy) v_u_158, (copy) v_u_181, (copy) v_u_177, (copy) p_u_154, (ref) v_u_176, (copy) v_u_175
		local v324 = {
			["qty"] = v_u_168,
			["cap"] = v_u_167,
			["busy"] = v_u_169,
			["closed"] = v_u_170
		}
		local v325 = v_u_64.plan
		local v326 = v_u_158
		local v327 = v_u_181()
		local v328 = v_u_168
		local v329 = v_u_177
		local v330
		if p_u_154.level then
			v330 = p_u_154.level.u
		else
			v330 = nil
		end
		v324.plan = v325(v326, v327, v328, v329, v330)
		v324.stripOn = v_u_176
		v324.needStrip = v_u_175
		return v324
	end
	function v_u_163.setQty(p331) -- name: setQty
		-- upvalues: (ref) v_u_168, (copy) v_u_167, (copy) v_u_199
		local v332 = math.floor(p331)
		local v333 = v_u_167
		v_u_168 = math.clamp(v332, 1, v333)
		v_u_199()
	end
	function v_u_163.setStrip(p334) -- name: setStrip
		-- upvalues: (ref) v_u_176, (copy) v_u_199
		v_u_176 = p334
		v_u_199()
	end
	function v_u_163.close() -- name: close
		-- upvalues: (ref) v_u_320, (ref) v_u_170
		if v_u_320 and not v_u_170 then
			v_u_320.close()
		end
	end
	return v_u_163
end
function v_u_64.new(p_u_335, p_u_336, p_u_337) -- name: new
	-- upvalues: (copy) v_u_64, (copy) v_u_77
	local v_u_338 = p_u_335.ui
	local v_u_339 = p_u_335.theme
	local v_u_340 = p_u_335.C
	local v_u_341 = p_u_335.Data
	local v_u_342 = p_u_335.data
	local v_u_343 = p_u_335.h
	local v_u_344 = p_u_335.compact
	local v_u_345 = {}
	local v_u_346 = true
	local v_u_347 = false
	local v_u_348 = nil
	local function v349()
		-- upvalues: (ref) v_u_348, (copy) p_u_335
		v_u_348 = p_u_335.mc.cctx.lib.MenuMarketKeypad
	end
	pcall(v349)
	local v_u_350 = nil
	local function v351()
		-- upvalues: (ref) v_u_350, (copy) p_u_335
		v_u_350 = p_u_335.mc.cctx.shared.Items
	end
	pcall(v351)
	local v_u_352 = nil
	local function v353()
		-- upvalues: (ref) v_u_352, (copy) p_u_335
		v_u_352 = p_u_335.mc.cctx.lib.MenuMarketCrateKit
	end
	pcall(v353)
	local v_u_354 = nil
	local v_u_355 = 0
	local v_u_356 = 1
	local v_u_357 = false
	local v_u_358 = nil
	local v_u_359 = false
	local v_u_360 = nil
	local v_u_361 = nil
	local v_u_362 = false
	local v_u_363 = {}
	local v_u_364 = nil
	local v_u_365 = {}
	local function v_u_366() -- name: cashNow
		-- upvalues: (copy) v_u_342
		return v_u_342:cash()
	end
	local function v_u_374() -- name: hasCondition
		-- upvalues: (copy) p_u_337, (ref) v_u_350
		local v367 = p_u_337.def()
		if type(v367) ~= "table" then
			return false
		end
		if v_u_350 ~= nil then
			local v368 = v_u_350.hasCondition
			if type(v368) == "function" then
				local v369 = v_u_350.hasCondition
				local v370, v371 = pcall(v369, v367)
				if v370 then
					return v371 == true
				end
			end
		end
		local v372 = p_u_337.entry()
		local v373
		if type(v372) == "table" then
			v373 = v372.dur == true
		else
			v373 = false
		end
		return v373
	end
	local function v_u_403() -- name: evaluate
		-- upvalues: (ref) v_u_355, (ref) v_u_356, (ref) v_u_64, (copy) p_u_335, (copy) v_u_341, (copy) p_u_337, (ref) v_u_352, (ref) v_u_77, (ref) v_u_360, (ref) v_u_361, (copy) v_u_342, (ref) v_u_359
		local v375 = {
			["kind"] = "place",
			["enabled"] = false,
			["price"] = nil,
			["qty"] = nil,
			["price"] = v_u_355,
			["qty"] = v_u_356
		}
		local v376, v377 = v_u_64.gate(p_u_335.state, v_u_341, p_u_335.rules)
		if v376 then
			local v378 = p_u_337.itemId()
			local v379
			if type(v378) == "string" then
				v379 = v_u_341.isCrateItem(v378)
			else
				v379 = false
			end
			if v379 then
				local v380 = v_u_341.orderButton(p_u_335.state, p_u_337.itemId(), nil, p_u_335.rules)
				if v380.enabled == false then
					local v381 = v380.reason
					local v382 = v380.why
					v375.reason = v381
					v375.code = v382
					v375.hard = true
					return v375
				end
				if v_u_352 == nil then
					v375.reason = v_u_341.text(p_u_335.rules, "STORE")
					v375.code = "STORE"
					v375.hard = true
					return v375
				end
			end
			if v_u_355 < 1 then
				v375.reason = v_u_64.TEXT.enterPrice
				v375.code = "EMPTY"
				return v375
			else
				local v383 = v_u_64.check
				local v384 = v_u_341
				local v385 = v_u_355
				local v386 = v_u_356
				local v387 = p_u_337.def()
				local v388
				if type(v387) == "table" then
					v388 = (v387.stack or 1) <= 1
				else
					v388 = false
				end
				local v389, _, v390 = v383(v384, v385, v386, v388)
				if v389 == nil then
					v375.u = v390
					v375.total = v390 * v_u_356
					local v391 = v_u_77
					local v392 = p_u_337.listings and p_u_337.listings() or nil
					local v393
					if p_u_337.bookModel then
						v393 = p_u_337.bookModel()
					else
						v393 = nil
					end
					local v394 = v391(v392, v393)
					if v_u_360 ~= nil and (v394 == nil or v_u_360 < v394) then
						v394 = v_u_360
					end
					if v_u_64.crosses(v390, v394) then
						v375.kind = "buy"
						v375.ask = v394
						v375.enabled = true
						local v395 = v_u_64.TEXT.crosses
						local v_u_396 = {
							["ask"] = v_u_341.unitMoney(v394)
						}
						v375.reason = string.gsub(v395, "{(%w+)}", function(p397)
							-- upvalues: (copy) v_u_396
							local v398 = v_u_396[p397]
							return v398 == nil and "?" or tostring(v398)
						end)
						v375.code = "CROSSES"
						return v375
					else
						local v399
						if p_u_337.bookModel then
							v399 = p_u_337.bookModel()
						else
							v399 = nil
						end
						local v400
						if v399 and v399.band then
							v400 = v399.band.lo
						else
							v400 = nil
						end
						local v401
						if v399 and v399.band then
							v401 = v399.band.hi
						else
							v401 = nil
						end
						if v_u_361 then
							v400 = v_u_361.lo or v400
							v401 = v_u_361.hi or v401
						end
						if v401 == nil or v401 >= v390 then
							if v400 == nil or v390 >= v400 then
								local v402 = v_u_342:cash()
								if v402 < v375.total then
									v375.reason = v_u_341.text(p_u_335.rules, "CASH", {
										["need"] = v375.total - v402
									})
									v375.code = "CASH"
									return v375
								elseif v_u_359 then
									v375.code = "BUSY"
									return v375
								else
									v375.enabled = true
									return v375
								end
							else
								v375.reason = v_u_341.text(p_u_335.rules, "BAND_LOW", {
									["min"] = v400
								})
								v375.code = "BAND_LOW"
								return v375
							end
						else
							v375.reason = v_u_341.text(p_u_335.rules, "BAND_HIGH", {
								["max"] = v401
							})
							v375.code = "BAND_HIGH"
							return v375
						end
					end
				else
					v375.reason = v_u_341.text(p_u_335.rules, v389)
					v375.code = v389
					if v389 == "PRICE_RANGE" then
						v375.reason = v_u_341.text(p_u_335.rules, "PRICE_RANGE")
					end
					return v375
				end
			end
		else
			v375.reason = v377
			v375.code = "GATE"
			v375.hard = true
			return v375
		end
	end
	local v_u_404 = nil
	v_u_404 = function()
		-- upvalues: (ref) v_u_346, (ref) v_u_347, (ref) v_u_363, (ref) v_u_358, (copy) v_u_403, (ref) v_u_64, (copy) p_u_335, (ref) v_u_355, (copy) v_u_341, (copy) v_u_340, (ref) v_u_362, (ref) v_u_348, (ref) v_u_356, (copy) v_u_342, (copy) v_u_366, (copy) p_u_337, (copy) v_u_374, (ref) v_u_359, (ref) v_u_364
		if v_u_346 and (v_u_347 and v_u_363.total ~= nil) then
			if v_u_358 and os.clock() > v_u_358.untilT then
				v_u_358 = nil
			end
			local v405 = v_u_403()
			local v406 = v_u_64.limits(p_u_335.state)
			if v_u_363.priceLbl then
				v_u_363.priceLbl.Text = v_u_355 <= 0 and "$0" or v_u_341.money(v_u_355)
				local v407 = v_u_363.priceLbl
				local v408
				if v_u_355 > 0 then
					v408 = v_u_340.accent
				else
					v408 = v_u_340.muted
				end
				v407.TextColor3 = v408
			end
			if v_u_363.priceBox and not v_u_363.priceBox:IsFocused() then
				v_u_362 = true
				local v409 = v_u_363.priceBox
				local v410
				if v_u_355 > 0 and v_u_348 then
					v410 = v_u_348.group(v_u_355)
				elseif v_u_355 > 0 then
					local v411 = v_u_355
					v410 = tostring(v411)
				else
					v410 = ""
				end
				v409.Text = v410
				v_u_362 = false
			end
			if v_u_363.keypad then
				v_u_363.keypad.set(v_u_355)
			end
			if v_u_363.qtyLbl then
				local v412 = v_u_356
				v_u_363.qtyLbl.Text = tostring(v412)
			end
			local v413 = v405.u
			local v414 = v_u_363.total
			local v415
			if v413 then
				local v416 = v_u_64.TEXT.total
				local v_u_417 = {
					["total"] = v_u_341.money(v413 * v_u_356)
				}
				v415 = string.gsub(v416, "{(%w+)}", function(p418)
					-- upvalues: (copy) v_u_417
					local v419 = v_u_417[p418]
					return v419 == nil and "?" or tostring(v419)
				end)
			else
				local v420 = v_u_64.TEXT.total
				local v_u_421 = {
					["total"] = "$0"
				}
				v415 = string.gsub(v420, "{(%w+)}", function(p422)
					-- upvalues: (copy) v_u_421
					local v423 = v_u_421[p422]
					return v423 == nil and "?" or tostring(v423)
				end)
			end
			v414.Text = v415
			if v413 then
				local v424 = v_u_342:cash() - v413 * v_u_356
				local v425 = v_u_363.after
				local v426 = v_u_64.TEXT.after
				local v_u_427 = {
					["cash"] = v_u_341.money(v424)
				}
				v425.Text = string.gsub(v426, "{(%w+)}", function(p428)
					-- upvalues: (copy) v_u_427
					local v429 = v_u_427[p428]
					return v429 == nil and "?" or tostring(v429)
				end)
				local v430 = v_u_363.after
				local v431
				if v424 < 0 then
					v431 = v_u_340.danger
				else
					v431 = v_u_340.text
				end
				v430.TextColor3 = v431
			else
				local v432 = v_u_363.after
				local v433 = v_u_64.TEXT.after
				local v_u_434 = {
					["cash"] = v_u_341.money(v_u_366())
				}
				v432.Text = string.gsub(v433, "{(%w+)}", function(p435)
					-- upvalues: (copy) v_u_434
					local v436 = v_u_434[p435]
					return v436 == nil and "?" or tostring(v436)
				end)
				v_u_363.after.TextColor3 = v_u_340.text
			end
			local v437
			if v413 then
				local v438 = v_u_64.ahead
				local v439
				if p_u_337.bookModel then
					v439 = p_u_337.bookModel()
				else
					v439 = nil
				end
				v437 = v438(v439, v413)
			else
				v437 = nil
			end
			local v440 = v_u_363.ahead
			local v441
			if v437 then
				local v442 = v_u_64.TEXT.ahead
				local v_u_443 = {
					["n"] = v437
				}
				v441 = string.gsub(v442, "{(%w+)}", function(p444)
					-- upvalues: (copy) v_u_443
					local v445 = v_u_443[p444]
					return v445 == nil and "?" or tostring(v445)
				end)
			else
				v441 = ""
			end
			v440.Text = v441
			v_u_363.ahead.Visible = v437 ~= nil
			local v446 = v_u_355 > 9999
			v_u_363.steps.Visible = v446
			local v447 = v_u_363.steps
			local v448
			if v446 and (v413 and v413 ~= v_u_355) then
				local v449 = v_u_64.TEXT.steps
				local v450 = v_u_64.TEXT.counts
				local v_u_451 = {
					["u"] = v_u_341.money(v413)
				}
				v448 = v449 .. " " .. string.gsub(v450, "{(%w+)}", function(p452)
					-- upvalues: (copy) v_u_451
					local v453 = v_u_451[p452]
					return v453 == nil and "?" or tostring(v453)
				end)
			else
				v448 = v_u_64.TEXT.steps
			end
			v447.Text = v448
			local v454 = v_u_363.ends
			local v455 = v_u_64.TEXT.ends
			local v_u_456 = {
				["days"] = v406.days
			}
			v454.Text = string.gsub(v455, "{(%w+)}", function(p457)
				-- upvalues: (copy) v_u_456
				local v458 = v_u_456[p457]
				return v458 == nil and "?" or tostring(v458)
			end)
			local v459 = v_u_363.open
			local v460 = v_u_64.TEXT.open
			local v_u_461 = {
				["n"] = v406.open,
				["max"] = v406.max
			}
			v459.Text = string.gsub(v460, "{(%w+)}", function(p462)
				-- upvalues: (copy) v_u_461
				local v463 = v_u_461[p462]
				return v463 == nil and "?" or tostring(v463)
			end)
			v_u_363.cond.Visible = v_u_374()
			if v405.kind == "buy" then
				v_u_363.placeApi.setText(v_u_64.TEXT.buyNow)
			else
				local v464 = v_u_363.placeApi.setText
				local v465
				if v_u_359 then
					v465 = v_u_64.TEXT.placing
				else
					v465 = v_u_64.TEXT.place
				end
				v464(v465)
			end
			local v466 = v_u_363.placeApi.setEnabled
			local v467
			if v405.enabled == true then
				v467 = not v_u_359
			else
				v467 = false
			end
			v466(v467)
			local v468 = v405.reason
			local v469
			if v405.code == "EMPTY" then
				v469 = v_u_340.muted
			elseif v405.kind == "buy" then
				v469 = v_u_340.accent
			else
				v469 = v_u_340.danger
			end
			if v_u_358 then
				v468 = v_u_358.text
				v469 = v_u_358.color
			end
			v_u_363.reason.Text = v468 or ""
			v_u_363.reason.TextColor3 = v469
			v_u_363.reason.Visible = (v468 or "") ~= ""
			local v470 = v_u_64.quick
			local v471 = v_u_341
			local v472
			if p_u_337.bookModel then
				v472 = p_u_337.bookModel()
			else
				v472 = nil
			end
			local v473 = v470(v471, v472, p_u_337.listings and p_u_337.listings() or nil)
			for _, v474 in { "match", "step", "cheapest" } do
				local v475 = v_u_363.quick
				if v475 then
					v475 = v_u_363.quick[v474]
				end
				if not v475 then
					continue
				end
				local v476 = v475.api.setEnabled
				local v477
				if v473[v474] == nil then
					v477 = false
				else
					v477 = not v_u_359
				end
				v476(v477)
				v475.btn:SetAttribute("Value", v473[v474])
			end
			if v_u_363.keypad and v_u_363.keypad.setEnabled then
				v_u_363.keypad.setEnabled(not v_u_359)
			end
			v_u_364:SetAttribute("Eval", v405.code or (v405.enabled and "OK" or "NONE"))
			v_u_364:SetAttribute("Kind", v405.kind)
		end
	end
	local function v_u_493() -- name: openKeypadPanel
		-- upvalues: (ref) v_u_355, (copy) v_u_341, (ref) v_u_64, (copy) v_u_338, (copy) v_u_340, (ref) v_u_348, (copy) v_u_339, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404
		local v_u_478 = nil
		local v_u_479 = nil
		local function v_u_487() -- name: paintDisp
			-- upvalues: (ref) v_u_478, (ref) v_u_355, (ref) v_u_341, (ref) v_u_479, (ref) v_u_64
			if v_u_478 then
				v_u_478.Text = v_u_355 <= 0 and "$0" or v_u_341.money(v_u_355)
			end
			if v_u_479 then
				local v480 = v_u_64.effective(v_u_341, v_u_355)
				local v481 = v_u_479
				local v482
				if v480 and (v_u_355 > 9999 and v480 ~= v_u_355) then
					local v483 = v_u_64.TEXT.counts
					local v_u_484 = {
						["u"] = v_u_341.money(v480)
					}
					v482 = string.gsub(v483, "{(%w+)}", function(p485)
						-- upvalues: (copy) v_u_484
						local v486 = v_u_484[p485]
						return v486 == nil and "?" or tostring(v486)
					end)
				else
					v482 = ""
				end
				v481.Text = v482
			end
		end
		local v492 = {
			["title"] = "Price each",
			["width"] = 780,
			["build"] = nil,
			["buttons"] = nil,
			["build"] = function(p488) -- name: build
				-- upvalues: (ref) v_u_338, (ref) v_u_478, (ref) v_u_340, (ref) v_u_479, (ref) v_u_348, (ref) v_u_339, (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404, (copy) v_u_487
				local v489 = v_u_338.new("Frame", {
					["Name"] = "Display",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 40)
				}, p488)
				v_u_478 = v_u_338.label({
					["parent"] = nil,
					["name"] = "Price",
					["text"] = "",
					["style"] = "monoL",
					["textSize"] = 30,
					["color"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v489,
					["color"] = v_u_340.accent,
					["size"] = UDim2.new(0.5, 0, 1, 0)
				})
				v_u_479 = v_u_338.label({
					["parent"] = nil,
					["name"] = "Counts",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v489,
					["color"] = v_u_340.text2,
					["position"] = UDim2.fromScale(0.5, 0),
					["size"] = UDim2.new(0.5, 0, 1, 0)
				})
				if v_u_348 then
					v_u_348.mount(p488, {
						["ui"] = nil,
						["theme"] = nil,
						["price"] = nil,
						["n"] = 1,
						["quick"] = false,
						["keyCols"] = 6,
						["keyH"] = nil,
						["onChange"] = nil,
						["ui"] = v_u_338,
						["theme"] = v_u_339,
						["price"] = v_u_355,
						["keyH"] = v_u_339.touch(44),
						["onChange"] = function(p490) -- name: onChange
							-- upvalues: (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404, (ref) v_u_487
							local v491 = math.floor(p490)
							v_u_355 = math.clamp(v491, 0, 99999999)
							v_u_357 = true
							v_u_360 = nil
							v_u_361 = nil
							v_u_358 = nil
							v_u_404()
							v_u_487()
						end
					}).frame.LayoutOrder = 2
				end
				v_u_487()
			end,
			["buttons"] = {
				{
					["text"] = "Done",
					["kind"] = "primary"
				}
			}
		}
		v_u_338.modal(v492)
	end
	local function v_u_514(p494) -- name: afterPlace
		-- upvalues: (ref) v_u_359, (ref) v_u_346, (copy) p_u_335, (copy) p_u_337, (ref) v_u_358, (copy) v_u_341, (copy) v_u_340, (ref) v_u_355, (ref) v_u_356, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_404
		v_u_359 = false
		if not v_u_346 then
			return
		end
		local v495 = p494.data
		local v496 = type(v495) ~= "table" and {} or p494.data
		if p494.ok then
			local v_u_497 = p_u_335
			local v498 = p_u_337.itemId()
			local v_u_499 = nil
			local function v500()
				-- upvalues: (ref) v_u_499, (copy) v_u_497
				v_u_499 = v_u_497.mc.cctx.controllers.BmNotes
			end
			pcall(v500)
			if v_u_499 then
				local v501 = v_u_499.quiet
				if type(v501) == "function" then
					v_u_499.quiet("ordered", v498)
				end
			end
			if p494.state == "processing" then
				local v502 = {}
				local v503
				if p494.text == "" then
					v503 = v_u_341.TEXT.working
				else
					v503 = p494.text
				end
				v502.text = v503
				v502.color = v_u_340.info
				v502.untilT = os.clock() + 12
				v_u_358 = v502
			else
				local v504 = p_u_335
				local v505 = p494.text
				local v506 = v504.ui.toast
				pcall(v506, v505, "success")
				v_u_358 = nil
			end
			v_u_355 = 0
			v_u_356 = 1
			v_u_357 = false
			v_u_360 = nil
			v_u_361 = nil
			p_u_335.refreshState(true)
			v_u_404()
			if p494.state ~= "processing" and p_u_337.onPlaced then
				p_u_337.onPlaced(p494)
				return
			end
			return
		end
		local v507 = p494.code
		if v507 == "CROSSES" then
			local v508 = v496.ask
			local v509 = tonumber(v508)
			if v509 ~= nil then
				v_u_360 = v509
			end
			v_u_358 = {
				["text"] = p494.text,
				["color"] = v_u_340.danger,
				["untilT"] = os.clock() + 12
			}
			p_u_335.refreshState(true)
			v_u_404()
			return
		else
			local v510, v511
			if v507 == "BAND_HIGH" then
				local v512 = v496.max
				local v513
				if type(v512) == "number" and (v512 == v512 and v512 > -1000000000000000) then
					v513 = v512 < 1000000000000000
				else
					v513 = false
				end
				if v513 then
					v_u_361 = {
						["hi"] = v496.max
					}
					v_u_358 = {
						["text"] = p494.text,
						["color"] = v_u_340.danger,
						["untilT"] = os.clock() + 12
					}
					p_u_335.refreshState(true)
					v_u_404()
				else
					if v507 == "BAND_LOW" then
						v510 = v496.min
						if type(v510) == "number" and (v510 == v510 and v510 > -1000000000000000) then
							v511 = v510 < 1000000000000000
						else
							v511 = false
						end
						if v511 then
							v_u_361 = {
								["lo"] = v496.min
							}
						end
					end
					v_u_358 = {
						["text"] = p494.text,
						["color"] = v_u_340.danger,
						["untilT"] = os.clock() + 12
					}
					p_u_335.refreshState(true)
					v_u_404()
				end
			else
				if v507 == "BAND_LOW" then
					v510 = v496.min
					if type(v510) == "number" and (v510 == v510 and v510 > -1000000000000000) then
						v511 = v510 < 1000000000000000
					else
						v511 = false
					end
					if v511 then
						v_u_361 = {
							["lo"] = v496.min
						}
					end
				end
				v_u_358 = {
					["text"] = p494.text,
					["color"] = v_u_340.danger,
					["untilT"] = os.clock() + 12
				}
				p_u_335.refreshState(true)
				v_u_404()
				return
			end
		end
	end
	local v_u_515 = nil
	local function v_u_542() -- name: openConfirm
		-- upvalues: (copy) v_u_403, (copy) p_u_337, (ref) v_u_356, (ref) v_u_64, (copy) v_u_341, (ref) v_u_359, (ref) v_u_404, (ref) v_u_355, (copy) v_u_514, (copy) v_u_342, (copy) v_u_345, (ref) v_u_515, (copy) v_u_338, (ref) v_u_352, (copy) p_u_335, (copy) v_u_344, (copy) v_u_340, (copy) v_u_374
		local v_u_516 = v_u_403()
		if v_u_516.enabled and v_u_516.kind == "place" then
			p_u_337.entry()
			local v517 = p_u_337.def()
			local v518 = p_u_337.itemId()
			local v519 = v_u_356
			if type(v517) == "table" then
				local v520 = v517.name
				if type(v520) == "string" then
					v518 = v517.name
				end
			end
			if v519 > 1 then
				v518 = ("%d x %s"):format(v519, v518)
			end
			local v_u_521 = v_u_64.confirmText(v_u_341, v518, v_u_516.u, v_u_516.total)
			local v523 = {
				{
					["text"] = "Cancel",
					["kind"] = "secondary"
				},
				{
					["text"] = "Place order",
					["kind"] = "primary",
					["onClick"] = nil,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_359, (ref) v_u_404, (ref) p_u_337, (ref) v_u_356, (ref) v_u_355, (ref) v_u_514, (ref) v_u_342
						if v_u_359 then
							return false
						end
						v_u_359 = true
						v_u_404()
						local v_u_522 = {
							["id"] = p_u_337.itemId(),
							["n"] = v_u_356,
							["price"] = v_u_355
						}
						task.spawn(function()
							-- upvalues: (ref) v_u_514, (ref) v_u_342, (copy) v_u_522
							v_u_514(v_u_342:order(v_u_522))
						end)
						return false
					end
				}
			}
			v_u_345.confirmButtons = v523
			local v541 = {
				["title"] = "Place buy order",
				["width"] = 500,
				["build"] = nil,
				["buttons"] = nil,
				["build"] = function(p524) -- name: build
					-- upvalues: (ref) v_u_352, (ref) p_u_337, (ref) v_u_341, (ref) p_u_335, (ref) v_u_344, (ref) v_u_338, (copy) v_u_521, (ref) v_u_340, (ref) v_u_64, (copy) v_u_516, (ref) v_u_355, (ref) v_u_374
					if v_u_352 ~= nil then
						local v525 = p_u_337.itemId()
						local v526
						if type(v525) == "string" then
							v526 = v_u_341.isCrateItem(v525)
						else
							v526 = false
						end
						if v526 then
							local v527 = {
								["order"] = 0,
								["tight"] = nil,
								["tight"] = v_u_344
							}
							v_u_352.block(p_u_335, p524, p_u_337.itemId(), v527)
						end
					end
					v_u_338.label({
						["parent"] = nil,
						["name"] = "Ask",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = p524,
						["text"] = v_u_521,
						["color"] = v_u_340.text
					})
					v_u_338.label({
						["parent"] = nil,
						["name"] = "Pays",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 2,
						["parent"] = p524,
						["text"] = v_u_64.TEXT.pays,
						["color"] = v_u_340.text2
					})
					if v_u_516.u ~= v_u_355 then
						local v528 = v_u_338.label
						local v529 = {
							["parent"] = nil,
							["name"] = "Counts",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 3,
							["parent"] = p524
						}
						local v530 = v_u_64.TEXT.steps
						local v531 = v_u_64.TEXT.counts
						local v_u_532 = {
							["u"] = v_u_341.money(v_u_516.u)
						}
						v529.text = v530 .. " " .. string.gsub(v531, "{(%w+)}", function(p533)
							-- upvalues: (copy) v_u_532
							local v534 = v_u_532[p533]
							return v534 == nil and "?" or tostring(v534)
						end)
						v529.color = v_u_340.text2
						v528(v529)
					end
					local v535 = v_u_338.label
					local v536 = {
						["parent"] = nil,
						["name"] = "Ends",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 4,
						["parent"] = p524
					}
					local v537 = v_u_64.TEXT.ends
					local v_u_538 = {
						["days"] = v_u_64.limits(p_u_335.state).days
					}
					v536.text = string.gsub(v537, "{(%w+)}", function(p539)
						-- upvalues: (copy) v_u_538
						local v540 = v_u_538[p539]
						return v540 == nil and "?" or tostring(v540)
					end)
					v536.color = v_u_340.text2
					v535(v536)
					if v_u_374() then
						v_u_338.label({
							["parent"] = nil,
							["name"] = "Cond",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 5,
							["parent"] = p524,
							["text"] = v_u_64.TEXT.cond,
							["color"] = v_u_340.text2
						})
					end
				end,
				["buttons"] = v523
			}
			v_u_515 = v_u_338.modal(v541)
		end
	end
	local function v_u_544() -- name: onPlaceButton
		-- upvalues: (copy) v_u_403, (copy) v_u_338, (copy) v_u_339, (ref) v_u_358, (copy) v_u_340, (ref) v_u_404, (copy) p_u_337, (ref) v_u_355, (copy) v_u_542
		local v543 = v_u_403()
		if v543.enabled then
			if v543.kind == "buy" then
				if p_u_337.onBuyNow then
					p_u_337.onBuyNow(v_u_355)
				end
			else
				v_u_542()
			end
		else
			v_u_338.sound(v_u_339.sounds.error)
			if v543.reason and v543.code ~= "BUSY" then
				v_u_358 = {
					["text"] = v543.reason,
					["color"] = v_u_340.accent,
					["untilT"] = os.clock() + 6
				}
				v_u_404()
			end
			return
		end
	end
	local function v_u_546() -- name: clearForm
		-- upvalues: (ref) v_u_364, (ref) v_u_363
		if v_u_364 then
			for _, v545 in v_u_364:GetChildren() do
				if v545:IsA("UIListLayout") or v545:IsA("UIPadding") then
					continue
				end
				v545:Destroy()
			end
		end
		v_u_363 = {}
	end
	local function v_u_667() -- name: build
		-- upvalues: (copy) v_u_546, (copy) v_u_338, (copy) p_u_337, (ref) v_u_364, (copy) v_u_341, (copy) p_u_335, (ref) v_u_354, (ref) v_u_352, (copy) v_u_343, (ref) v_u_363, (ref) v_u_64, (copy) v_u_340, (copy) v_u_344, (copy) v_u_339, (ref) v_u_362, (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404, (ref) v_u_348, (copy) v_u_493, (ref) v_u_356, (copy) v_u_366, (copy) v_u_544
		v_u_546()
		local v547 = v_u_338.device() == "Keyboard"
		local v548 = 0
		local v549 = p_u_337.entry()
		local v550 = v_u_338.new
		local v551 = {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 52)
		}
		v548 = v548 + 1
		v551.LayoutOrder = v548
		local v552 = v550("Frame", v551, v_u_364)
		local v553 = p_u_337.itemId()
		local v554
		if type(v553) == "string" then
			v554 = v_u_341.isCrateItem(v553)
		else
			v554 = false
		end
		local v555
		if v554 then
			v555 = v_u_341.orderButton(p_u_335.state, p_u_337.itemId(), nil, p_u_335.rules)
		else
			v555 = nil
		end
		local v556
		if v555 then
			local v557 = v555.form
			local v558 = tostring(v557)
			local v559 = v555.reason
			local v560 = tostring(v559)
			local v561 = v_u_352 ~= nil
			v556 = v558 .. "|" .. v560 .. "|" .. tostring(v561)
		else
			v556 = nil
		end
		v_u_354 = v556
		local _, v562 = v_u_343.icon(v552, p_u_337.itemId(), 44)
		v_u_363.release = v562
		local v563 = v_u_338.label
		local v564 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v552
		}
		local v565
		if v549 then
			v565 = v549.name
		else
			v565 = p_u_337.itemId()
		end
		v564.text = v565
		v564.position = UDim2.fromOffset(54, 0)
		v564.size = UDim2.new(1, -54, 0, 26)
		v563(v564)
		v_u_338.label({
			["parent"] = nil,
			["name"] = "Word",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["parent"] = v552,
			["text"] = string.upper(v_u_64.TEXT.title),
			["color"] = v_u_340.info,
			["position"] = UDim2.fromOffset(54, 28),
			["size"] = UDim2.new(1, -54, 0, 18)
		})
		if v555 ~= nil then
			if v_u_352 ~= nil then
				local v566 = v_u_352.block
				local v567 = p_u_335
				local v568 = v_u_364
				local v569 = p_u_337.itemId()
				local v570 = {}
				v548 = v548 + 1
				v570.order = v548
				v570.tight = v_u_344
				v566(v567, v568, v569, v570)
			end
			if v555.form == false or v_u_352 == nil then
				local v571 = v_u_338.label
				local v572 = {
					["parent"] = nil,
					["name"] = "OrdCaseNo",
					["text"] = nil,
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v_u_364,
					["text"] = v555.reason or v_u_341.text(p_u_335.rules, "STORE"),
					["color"] = v_u_340.accent
				}
				v548 = v548 + 1
				v572.order = v548
				v571(v572)
				return
			end
		end
		local v573 = v_u_338.label
		local v574 = {
			["parent"] = nil,
			["name"] = "PriceCaption",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["order"] = nil,
			["track"] = false,
			["parent"] = v_u_364,
			["text"] = v_u_64.TEXT.priceLabel,
			["color"] = v_u_340.text2,
			["size"] = UDim2.new(1, 0, 0, 16)
		}
		v548 = v548 + 1
		v574.order = v548
		v573(v574)
		local v575 = v_u_338.new
		local v576 = {
			["Name"] = "PriceRow",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_339.touch(44))
		}
		v548 = v548 + 1
		v576.LayoutOrder = v548
		local v577 = v575("Frame", v576, v_u_364)
		if v547 and v_u_338.input then
			local _, v_u_578 = v_u_338.input({
				["parent"] = nil,
				["name"] = "PriceInput",
				["placeholder"] = "Price each in Cash",
				["size"] = nil,
				["position"] = nil,
				["maxLength"] = 12,
				["parent"] = v577,
				["size"] = UDim2.new(1, 0, 0, v_u_339.touch(40)),
				["position"] = UDim2.fromOffset(0, 0)
			})
			v_u_578:GetPropertyChangedSignal("Text"):Connect(function()
				-- upvalues: (ref) v_u_362, (copy) v_u_578, (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404
				if not v_u_362 then
					local v579 = string.gsub(v_u_578.Text, "[^%d]", "")
					local v580 = string.sub(v579, 1, 8)
					local v581 = tonumber(v580) or 0
					if v581 ~= v_u_355 then
						local v582 = math.floor(v581)
						v_u_355 = math.clamp(v582, 0, 99999999)
						v_u_357 = true
						v_u_360 = nil
						v_u_361 = nil
						v_u_358 = nil
						v_u_404()
					end
				end
			end)
			v_u_363.priceBox = v_u_578
		else
			local v583 = v_u_338.new("TextButton", {
				["Name"] = "PriceDisplay",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_340.raised,
				["Size"] = UDim2.new(1, 0, 1, 0)
			}, v577)
			v583.SelectionImageObject = v_u_338.selectionImage()
			v_u_338.stroke(v583, v_u_340.lineStrong)
			v_u_363.priceLbl = v_u_338.label({
				["parent"] = nil,
				["name"] = "Value",
				["text"] = "",
				["style"] = "monoL",
				["textSize"] = 24,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["fit"] = true,
				["parent"] = v583,
				["color"] = v_u_340.accent,
				["position"] = UDim2.fromOffset(12, 0),
				["size"] = UDim2.new(1, -24, 1, 0)
			})
			v_u_363.display = v583
			if v_u_344 or not v_u_348 then
				v583.Activated:Connect(function()
					-- upvalues: (ref) v_u_338, (ref) v_u_339, (ref) v_u_493
					v_u_338.sound(v_u_339.sounds.click)
					v_u_493()
				end)
				v_u_338.icon("chevronRight", {
					["parent"] = nil,
					["size"] = 14,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v583,
					["color"] = v_u_340.text2,
					["position"] = UDim2.new(1, -12, 0.5, 0),
					["anchor"] = Vector2.new(1, 0.5)
				})
			end
			if v_u_348 and not v_u_344 then
				v_u_363.keypad = v_u_348.mount(v_u_364, {
					["ui"] = nil,
					["theme"] = nil,
					["price"] = nil,
					["n"] = 1,
					["quick"] = false,
					["keyCols"] = 6,
					["keyH"] = nil,
					["onChange"] = nil,
					["ui"] = v_u_338,
					["theme"] = v_u_339,
					["price"] = v_u_355,
					["keyH"] = v_u_339.touch(44),
					["onChange"] = function(p584) -- name: onChange
						-- upvalues: (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404
						local v585 = math.floor(p584)
						v_u_355 = math.clamp(v585, 0, 99999999)
						v_u_357 = true
						v_u_360 = nil
						v_u_361 = nil
						v_u_358 = nil
						v_u_404()
					end
				})
				local v586 = v_u_363.keypad.frame
				v548 = v548 + 1
				v586.LayoutOrder = v548
			end
		end
		local v587 = v_u_338.new
		local v588 = {
			["Name"] = "QuickPrices",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}
		v548 = v548 + 1
		v588.LayoutOrder = v548
		local v_u_589 = v587("Frame", v588, v_u_364)
		v_u_338.layout(v_u_589, "v", 6)
		v_u_363.quick = {}
		local function v600(p_u_590, p591, p592) -- name: quickBtn
			-- upvalues: (ref) v_u_343, (copy) v_u_589, (ref) v_u_64, (ref) v_u_341, (ref) p_u_337, (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404, (ref) v_u_363
			local v598, v599 = v_u_343.button(v_u_589, p591, "secondary", function()
				-- upvalues: (ref) v_u_64, (ref) v_u_341, (ref) p_u_337, (copy) p_u_590, (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404
				local v593 = v_u_64.quick
				local v594 = v_u_341
				local v595
				if p_u_337.bookModel then
					v595 = p_u_337.bookModel()
				else
					v595 = nil
				end
				local v596 = v593(v594, v595, p_u_337.listings and p_u_337.listings() or nil)[p_u_590]
				if v596 ~= nil then
					local v597 = math.floor(v596)
					v_u_355 = math.clamp(v597, 0, 99999999)
					v_u_357 = true
					v_u_360 = nil
					v_u_361 = nil
					v_u_358 = nil
					v_u_404()
				end
			end, {
				["name"] = nil,
				["order"] = nil,
				["height"] = 40,
				["maxTextWidth"] = 260,
				["name"] = "Quick_" .. p_u_590,
				["order"] = p592
			})
			v_u_363.quick[p_u_590] = {
				["btn"] = v598,
				["api"] = v599
			}
		end
		v600("match", v_u_64.TEXT.matchBtn, 1)
		v600("step", v_u_64.TEXT.stepBtn, 2)
		v600("cheapest", v_u_64.TEXT.cheapBtn, 3)
		local v601 = v_u_338.label
		local v602 = {
			["parent"] = nil,
			["name"] = "QtyCaption",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["order"] = nil,
			["track"] = false,
			["parent"] = v_u_364,
			["text"] = v_u_64.TEXT.qtyLabel,
			["color"] = v_u_340.text2,
			["size"] = UDim2.new(1, 0, 0, 16)
		}
		v548 = v548 + 1
		v602.order = v548
		v601(v602)
		local v603 = v_u_338.new
		local v604 = {
			["Name"] = "Qty",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_339.touch(40))
		}
		v548 = v548 + 1
		v604.LayoutOrder = v548
		local v605 = v603("Frame", v604, v_u_364)
		local v606 = v_u_339.touch(40)
		v_u_338.iconButton({
			["parent"] = nil,
			["icon"] = "minus",
			["size"] = nil,
			["kind"] = "secondary",
			["name"] = "Step_minus",
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v605,
			["size"] = v606,
			["position"] = UDim2.fromOffset(0, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_356, (ref) p_u_337, (ref) v_u_64, (ref) v_u_341, (ref) v_u_355, (ref) p_u_335, (ref) v_u_361, (ref) v_u_404
				local v607 = v_u_356 - 1
				local v608 = p_u_337.def()
				v_u_64.effective(v_u_341, v_u_355)
				local v609 = math.floor(v607)
				local v610 = v_u_64.maxQty
				local v611 = v_u_64.limits(p_u_335.state)
				v_u_356 = math.clamp(v609, 1, v610(v608, v611, nil, nil))
				v_u_361 = nil
				v_u_404()
			end
		})
		v_u_363.qtyLbl = v_u_338.label({
			["parent"] = nil,
			["name"] = "Units",
			["text"] = "",
			["style"] = "monoL",
			["textSize"] = 20,
			["align"] = "center",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v605,
			["position"] = UDim2.fromOffset(v606 + 4, 0),
			["size"] = UDim2.fromOffset(70, v_u_339.touch(40))
		})
		v_u_338.iconButton({
			["parent"] = nil,
			["icon"] = "plus",
			["size"] = nil,
			["kind"] = "secondary",
			["name"] = "Step_plus",
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v605,
			["size"] = v606,
			["position"] = UDim2.fromOffset(v606 + 4 + 70 + 4, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (ref) v_u_356, (ref) p_u_337, (ref) v_u_64, (ref) v_u_341, (ref) v_u_355, (ref) p_u_335, (ref) v_u_361, (ref) v_u_404
				local v612 = v_u_356 + 1
				local v613 = p_u_337.def()
				v_u_64.effective(v_u_341, v_u_355)
				local v614 = math.floor(v612)
				local v615 = v_u_64.maxQty
				local v616 = v_u_64.limits(p_u_335.state)
				v_u_356 = math.clamp(v614, 1, v615(v613, v616, nil, nil))
				v_u_361 = nil
				v_u_404()
			end
		})
		local v617 = v_u_338.new
		local v618 = {
			["Name"] = "QtyQuick",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v_u_339.touch(40))
		}
		v548 = v548 + 1
		v618.LayoutOrder = v548
		local v619 = v617("Frame", v618, v_u_364)
		v_u_338.layout(v619, "h", 6)
		for v620, v_u_621 in v_u_64.QTY_QUICK do
			v_u_343.button(v619, tostring(v_u_621), "secondary", function()
				-- upvalues: (copy) v_u_621, (ref) p_u_337, (ref) v_u_64, (ref) v_u_341, (ref) v_u_355, (ref) v_u_356, (ref) p_u_335, (ref) v_u_361, (ref) v_u_404
				local v622 = v_u_621
				local v623 = p_u_337.def()
				v_u_64.effective(v_u_341, v_u_355)
				local v624 = math.floor(v622)
				local v625 = v_u_64.maxQty
				local v626 = v_u_64.limits(p_u_335.state)
				v_u_356 = math.clamp(v624, 1, v625(v623, v626, nil, nil))
				v_u_361 = nil
				v_u_404()
			end, {
				["name"] = nil,
				["order"] = nil,
				["height"] = 40,
				["width"] = 64,
				["name"] = "Qty_" .. v_u_621,
				["order"] = v620
			})
		end
		v_u_343.button(v619, v_u_64.TEXT.maxBtn, "secondary", function()
			-- upvalues: (ref) v_u_64, (ref) v_u_341, (ref) v_u_355, (ref) p_u_337, (ref) p_u_335, (ref) v_u_366, (ref) v_u_356, (ref) v_u_361, (ref) v_u_404
			local v627 = v_u_64.effective(v_u_341, v_u_355)
			local v628 = v_u_64.maxQty(p_u_337.def(), v_u_64.limits(p_u_335.state), v627, v_u_366())
			local v629 = p_u_337.def()
			v_u_64.effective(v_u_341, v_u_355)
			local v630 = math.floor(v628)
			local v631 = v_u_64.maxQty
			local v632 = v_u_64.limits(p_u_335.state)
			v_u_356 = math.clamp(v630, 1, v631(v629, v632, nil, nil))
			v_u_361 = nil
			v_u_404()
		end, {
			["name"] = "Qty_Max",
			["order"] = 9,
			["height"] = 40,
			["width"] = 84
		})
		local v633 = v_u_363
		local v634 = v_u_338.label
		local v635 = {
			["parent"] = nil,
			["name"] = "OrdTotal",
			["text"] = "",
			["style"] = "bodyStrong",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.text
		}
		v548 = v548 + 1
		v635.order = v548
		v633.total = v634(v635)
		local v636 = v_u_363
		local v637 = v_u_338.label
		local v638 = {
			["parent"] = nil,
			["name"] = "OrdAfter",
			["text"] = "",
			["style"] = "body",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.text
		}
		v548 = v548 + 1
		v638.order = v548
		v636.after = v637(v638)
		local v639 = v_u_363
		local v640 = v_u_338.label
		local v641 = {
			["parent"] = nil,
			["name"] = "OrdAhead",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.text2
		}
		v548 = v548 + 1
		v641.order = v548
		v639.ahead = v640(v641)
		local v642 = v_u_338.label
		local v643 = {
			["parent"] = nil,
			["name"] = "OrdPays",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["text"] = v_u_64.TEXT.pays,
			["color"] = v_u_340.text2
		}
		v548 = v548 + 1
		v643.order = v548
		v642(v643)
		local v644 = v_u_363
		local v645 = v_u_338.label
		local v646 = {
			["parent"] = nil,
			["name"] = "OrdSteps",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["text"] = v_u_64.TEXT.steps,
			["color"] = v_u_340.muted
		}
		v548 = v548 + 1
		v646.order = v548
		v644.steps = v645(v646)
		local v647 = v_u_363
		local v648 = v_u_338.label
		local v649 = {
			["parent"] = nil,
			["name"] = "OrdEnds",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.text2
		}
		v548 = v548 + 1
		v649.order = v548
		v647.ends = v648(v649)
		local v650 = v_u_363
		local v651 = v_u_338.label
		local v652 = {
			["parent"] = nil,
			["name"] = "OrdCond",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["text"] = v_u_64.TEXT.cond,
			["color"] = v_u_340.text2
		}
		v548 = v548 + 1
		v652.order = v548
		v650.cond = v651(v652)
		local v653 = v_u_363
		local v654 = v_u_338.label
		local v655 = {
			["parent"] = nil,
			["name"] = "OrdOpen",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.muted
		}
		v548 = v548 + 1
		v655.order = v548
		v653.open = v654(v655)
		local v656 = v_u_363
		local v657 = v_u_338.label
		local v658 = {
			["parent"] = nil,
			["name"] = "OrdReason",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v_u_364,
			["color"] = v_u_340.danger
		}
		v548 = v548 + 1
		v658.order = v548
		v656.reason = v657(v658)
		local v659 = v_u_343.button
		local v660 = v_u_364
		local v661 = v_u_64.TEXT.place
		local v662 = v_u_544
		local v663 = {
			["name"] = "PlaceOrder",
			["order"] = nil,
			["maxTextWidth"] = 240
		}
		v548 = v548 + 1
		v663.order = v548
		local v664, v665 = v659(v660, v661, "primary", v662, v663)
		local v666 = v_u_363
		v_u_363.placeBtn = v664
		v666.placeApi = v665
	end
	function v_u_345.show() -- name: show
		-- upvalues: (ref) v_u_347, (copy) p_u_336, (ref) v_u_364, (copy) p_u_337, (copy) v_u_338, (copy) v_u_667, (ref) v_u_404
		v_u_347 = true
		p_u_336.Visible = true
		if v_u_364 == nil then
			if p_u_337.scroll then
				v_u_364 = v_u_338.list({
					["parent"] = nil,
					["name"] = "OrderForm",
					["size"] = nil,
					["gap"] = 10,
					["padding"] = nil,
					["parent"] = p_u_336,
					["size"] = UDim2.fromScale(1, 1),
					["padding"] = {
						0,
						8,
						0,
						10
					}
				})
			else
				v_u_364 = v_u_338.new("Frame", {
					["Name"] = "OrderForm",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, p_u_336)
				v_u_338.layout(v_u_364, "v", 10)
			end
		end
		v_u_667()
		v_u_404()
	end
	function v_u_345.hide() -- name: hide
		-- upvalues: (ref) v_u_347, (ref) v_u_363, (ref) v_u_364, (copy) v_u_546
		v_u_347 = false
		if v_u_363.release then
			v_u_363.release()
			v_u_363.release = nil
		end
		if v_u_364 ~= nil then
			v_u_546()
		end
	end
	function v_u_345.refresh() -- name: refresh
		-- upvalues: (ref) v_u_347, (ref) v_u_364, (copy) p_u_337, (copy) v_u_341, (copy) p_u_335, (ref) v_u_354, (ref) v_u_352, (copy) v_u_667, (ref) v_u_404
		if v_u_347 then
			if v_u_364 ~= nil then
				local v668 = p_u_337.itemId()
				local v669
				if type(v668) == "string" then
					v669 = v_u_341.isCrateItem(v668)
				else
					v669 = false
				end
				if v669 then
					local v670 = v_u_341.orderButton(p_u_335.state, p_u_337.itemId(), nil, p_u_335.rules)
					local v671 = v_u_354
					local v672 = v670.form
					local v673 = tostring(v672)
					local v674 = v670.reason
					local v675 = tostring(v674)
					local v676 = v_u_352 ~= nil
					if v671 ~= v673 .. "|" .. v675 .. "|" .. tostring(v676) then
						v_u_667()
					end
				end
			end
			v_u_404()
		end
	end
	function v_u_345.onNote(_) -- name: onNote
		-- upvalues: (ref) v_u_347, (ref) v_u_404
		if v_u_347 then
			v_u_404()
		end
	end
	function v_u_345.canPlace() -- name: canPlace
		-- upvalues: (ref) v_u_64, (copy) p_u_335, (copy) v_u_341, (copy) p_u_337
		local v677, v678 = v_u_64.gate(p_u_335.state, v_u_341, p_u_335.rules)
		if v677 then
			local v679 = p_u_337.itemId()
			local v680
			if type(v679) == "string" then
				v680 = v_u_341.isCrateItem(v679)
			else
				v680 = false
			end
			if v680 then
				local v681 = v_u_341.orderButton(p_u_335.state, p_u_337.itemId(), nil, p_u_335.rules)
				if v681.enabled == false then
					return false, v681.reason
				end
			end
		end
		return v677, v678
	end
	function v_u_345.sellNow(p682) -- name: sellNow
		-- upvalues: (copy) v_u_342, (copy) p_u_337, (copy) p_u_335, (copy) v_u_341, (ref) v_u_64, (ref) v_u_350
		local v683 = v_u_342:stash()
		local v_u_684 = v_u_342:eligibility()
		local v685 = p_u_337.itemId()
		local function v694(p686) -- name: check
			-- upvalues: (ref) p_u_335, (ref) v_u_342, (ref) v_u_341, (copy) v_u_684
			local v687 = p_u_335.state
			local v688
			if type(v687) == "table" then
				local v689 = v687.tune
				v688 = type(v689) ~= "table" and {} or v687.tune
			else
				v688 = {}
			end
			local v690 = {
				["restricted"] = nil,
				["insured"] = nil,
				["topLevel"] = true,
				["denyPaid"] = nil
			}
			local v691
			if type(v687) == "table" then
				v691 = v687.restricted == true
			else
				v691 = false
			end
			v690.restricted = v691
			v690.insured = v_u_342:insured(p686.uid)
			v690.denyPaid = v688.denyPaid == true
			if v_u_341.isCrateItem(p686.id) then
				for v692, v693 in v_u_341.crateEnv(v687) do
					v690[v692] = v693
				end
			end
			return v_u_684.checkInst(p686, v690)
		end
		local v695, v696 = v_u_64.pick(v683, v685, v694)
		if v695 == nil then
			local v697 = p_u_335
			local v698
			if v696 then
				v698 = v_u_341.text(p_u_335.rules, v696)
			else
				v698 = v_u_64.TEXT.sellNone
			end
			local v699 = v697.ui.toast
			pcall(v699, v698, "warn")
			return nil
		end
		local v700, v701 = v694(v695)
		local v702 = v_u_64.openSellNow
		local v703 = p_u_335
		local v704 = {
			["inst"] = v695
		}
		local v705 = not p_u_337.def() and v_u_350
		if v705 then
			v705 = v_u_350.get(v695.id)
		end
		v704.def = v705
		v704.level = p682
		function v704.levels() -- name: levels
			-- upvalues: (ref) p_u_337
			local v706
			if p_u_337.bookModel then
				v706 = p_u_337.bookModel()
			else
				v706 = nil
			end
			if v706 and v706.ok then
				return v706.bids
			else
				return nil
			end
		end
		local v707 = not v700
		if v707 then
			v707 = v701 == "STRIP_FIRST"
		end
		v704.strip = v707
		function v704.onDone(p708) -- name: onDone
			-- upvalues: (ref) p_u_337
			if p_u_337.onSold then
				p_u_337.onSold(p708)
			end
		end
		return v702(v703, v704)
	end
	function v_u_345.destroy() -- name: destroy
		-- upvalues: (ref) v_u_346, (copy) v_u_365, (ref) v_u_363
		v_u_346 = false
		for _, v_u_709 in v_u_365 do
			pcall(function()
				-- upvalues: (copy) v_u_709
				v_u_709:Disconnect()
			end)
		end
		if v_u_363.release then
			v_u_363.release()
		end
	end
	function v_u_345.setPrice(p710) -- name: setPrice
		-- upvalues: (ref) v_u_355, (ref) v_u_357, (ref) v_u_360, (ref) v_u_361, (ref) v_u_358, (ref) v_u_404
		local v711 = math.floor(p710)
		v_u_355 = math.clamp(v711, 0, 99999999)
		v_u_357 = true
		v_u_360 = nil
		v_u_361 = nil
		v_u_358 = nil
		v_u_404()
	end
	function v_u_345.setQty(p712) -- name: setQty
		-- upvalues: (copy) p_u_337, (ref) v_u_64, (copy) v_u_341, (ref) v_u_355, (ref) v_u_356, (copy) p_u_335, (ref) v_u_361, (ref) v_u_404
		local v713 = p_u_337.def()
		v_u_64.effective(v_u_341, v_u_355)
		local v714 = math.floor(p712)
		local v715 = v_u_64.maxQty
		local v716 = v_u_64.limits(p_u_335.state)
		v_u_356 = math.clamp(v714, 1, v715(v713, v716, nil, nil))
		v_u_361 = nil
		v_u_404()
	end
	function v_u_345.eval() -- name: eval
		-- upvalues: (copy) v_u_403
		return v_u_403()
	end
	function v_u_345.state() -- name: state
		-- upvalues: (ref) v_u_355, (ref) v_u_356, (ref) v_u_359, (ref) v_u_358, (ref) v_u_360, (ref) v_u_361, (ref) v_u_347, (ref) v_u_364, (ref) v_u_363
		return {
			["price"] = v_u_355,
			["qty"] = v_u_356,
			["busy"] = v_u_359,
			["status"] = v_u_358,
			["serverAsk"] = v_u_360,
			["serverBand"] = v_u_361,
			["shown"] = v_u_347,
			["list"] = v_u_364,
			["form"] = v_u_363
		}
	end
	function v_u_345.form() -- name: form
		-- upvalues: (ref) v_u_363
		return v_u_363
	end
	function v_u_345.press(p717) -- name: press
		-- upvalues: (ref) v_u_64, (ref) v_u_364, (copy) v_u_544
		local v718 = v_u_64.findButton(v_u_364, p717)
		if v718 then
			v718:SetAttribute("Pressed", true)
			if p717 == v_u_64.TEXT.place or p717 == v_u_64.TEXT.buyNow then
				v_u_544()
				return true
			end
		end
		return false
	end
	function v_u_345.place() -- name: place
		-- upvalues: (copy) v_u_544
		v_u_544()
	end
	function v_u_345.confirm() -- name: confirm
		-- upvalues: (ref) v_u_515
		return v_u_515
	end
	local v719 = {
		["Disconnect"] = p_u_335.onTick(function()
			-- upvalues: (ref) v_u_347, (ref) v_u_404
			if v_u_347 then
				v_u_404()
			end
		end)
	}
	table.insert(v_u_365, v719)
	local v720 = {
		["Disconnect"] = v_u_338.onDevice(function()
			-- upvalues: (ref) v_u_347, (ref) v_u_346, (copy) v_u_667, (ref) v_u_404
			if v_u_347 and v_u_346 then
				v_u_667()
				v_u_404()
			end
		end)
	}
	table.insert(v_u_365, v720)
	local v721 = {
		["Disconnect"] = p_u_335.onState(function()
			-- upvalues: (ref) v_u_347, (ref) v_u_404
			if v_u_347 then
				v_u_404()
			end
		end)
	}
	table.insert(v_u_365, v721)
	return v_u_345
end
function v_u_64.findButton(p722, p723) -- name: findButton
	if p722 == nil then
		return nil
	end
	for _, v724 in p722:GetDescendants() do
		if not v724:IsA("TextButton") then
			continue
		end
		if v724.Text == p723 then
			return v724
		end
		local v725 = v724:FindFirstChild("Text", true)
		if not v725 or v725.Text ~= p723 then
			continue
		end
		return v724
	end
	return nil
end
return v_u_64