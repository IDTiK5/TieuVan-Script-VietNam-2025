-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDClock

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_204 = {
	["stateText"] = function(p2) -- name: stateText
		-- upvalues: (copy) v_u_1
		local v3 = p2:GetAttribute("State")
		if type(v3) ~= "string" or v3 == "" then
			return nil
		end
		if ({
			["idle"] = true,
			["ready"] = true,
			["open"] = true
		})[string.lower(v3)] then
			return nil
		end
		local v4 = string.upper((string.sub(v3, 1, 1))) .. string.sub(v3, 2)
		local v5 = p2:GetAttribute("StateEndsAt")
		if type(v5) == "number" and v5 > 0 then
			local v6 = v5 - v_u_1.now()
			local v7 = math.max(0, v6)
			local v8 = string.format
			local v9 = v7 / 60
			local v10 = math.floor(v9)
			local v11 = v7 % 60
			v4 = v4 .. v8(" %d:%02d", v10, (math.floor(v11)))
		end
		return v4
	end,
	["new"] = function(p_u_12) -- name: new
		-- upvalues: (copy) v_u_204, (copy) v_u_1
		local v_u_13 = p_u_12.UI
		local v_u_14 = p_u_12.Theme
		local v_u_15 = v_u_14.color
		local v16 = {}
		local v_u_17 = nil
		local v18 = v_u_13.topInset()
		local v_u_19 = v_u_13.new("Frame", {
			["Name"] = "Clock",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -40, 0, v18),
			["Size"] = UDim2.fromOffset(240, 48)
		}, p_u_12.root)
		local v_u_20 = v_u_13.label({
			["parent"] = nil,
			["text"] = "Raid time",
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["align"] = "right",
			["size"] = nil,
			["parent"] = v_u_19,
			["color"] = v_u_15.muted,
			["size"] = UDim2.new(1, 0, 0, 14)
		})
		local v_u_21 = v_u_13.label({
			["parent"] = nil,
			["text"] = "20:00",
			["style"] = "monoL",
			["textSize"] = 30,
			["align"] = "right",
			["size"] = nil,
			["position"] = nil,
			["parent"] = v_u_19,
			["size"] = UDim2.new(1, 0, 0, 32),
			["position"] = UDim2.fromOffset(0, 16)
		})
		local v_u_22 = v_u_13.icon("clock", {
			["parent"] = nil,
			["size"] = 14,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v_u_19,
			["color"] = v_u_15.text2,
			["position"] = UDim2.new(1, -102, 0, 32),
			["anchor"] = Vector2.new(1, 0.5)
		})
		local v_u_23 = v_u_13.new("Frame", {
			["Name"] = "Siren",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_15.dangerDeep,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -128, 0, 32),
			["Size"] = UDim2.fromOffset(0, 18),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v_u_19)
		v_u_13.stroke(v_u_23, v_u_15.danger, 1, 0.3)
		v_u_13.pad(v_u_23, {
			6,
			6,
			0,
			0
		})
		v_u_13.label({
			["parent"] = nil,
			["text"] = "Siren",
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["parent"] = v_u_23,
			["color"] = v_u_15.danger,
			["size"] = UDim2.fromOffset(0, 18)
		})
		local v_u_24 = v_u_13.new("Frame", {
			["Name"] = "Extracts",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_15.bg,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, 64),
			["Size"] = UDim2.fromOffset(320, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_19)
		v_u_13.stroke(v_u_24, v_u_15.line)
		v_u_13.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_15.accent,
			["Size"] = UDim2.new(0, 40, 0, 2)
		}, v_u_24)
		local v_u_25 = v_u_13.new("Frame", {
			["Name"] = "Body",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_24)
		v_u_13.pad(v_u_25, {
			16,
			16,
			12,
			12
		})
		local v_u_26 = v_u_13.layout(v_u_25, "v", 8)
		local v_u_27 = v_u_13.label({
			["parent"] = nil,
			["text"] = "Extractions",
			["style"] = "caps",
			["textSize"] = 14,
			["color"] = nil,
			["size"] = nil,
			["order"] = 0,
			["parent"] = v_u_25,
			["color"] = v_u_15.text2,
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		local v_u_28 = UDim2.new(1, 0, 0, 64)
		local v_u_29 = false
		local v_u_30 = {}
		local v_u_31 = false
		local v_u_32 = (1 / 0)
		local v_u_33 = nil
		local function v_u_53() -- name: fitTouch
			-- upvalues: (ref) v_u_33, (copy) p_u_12, (copy) v_u_14, (ref) v_u_28, (copy) v_u_24, (ref) v_u_32
			local v34 = v_u_33
			if v34 then
				local v_u_35 = v34.x
				local v_u_36 = v34.y
				local v_u_37 = v34.w
				local function v50()
					-- upvalues: (ref) p_u_12, (ref) v_u_14, (copy) v_u_35, (ref) v_u_37, (ref) v_u_36
					local v38 = p_u_12.root:FindFirstChild("Weapon")
					if v38 and (v38:IsA("GuiObject") and (v38.Visible and v38.AbsoluteSize.X > 4)) then
						local v39 = v_u_14.uiScale
						local v40 = math.max(0.01, v39())
						local v41 = p_u_12.root.AbsolutePosition
						local v42 = (v38.AbsolutePosition.X - v41.X) / v40
						local v43 = (v38.AbsolutePosition.Y + v38.AbsoluteSize.Y - v41.Y) / v40
						local v44 = (v38.AbsolutePosition.Y - v41.Y) / v40
						if v_u_35 + v_u_37 > v42 - 8 and (v_u_36 < v43 + 8 and v44 < v_u_36 + 200) then
							local v45 = v42 - 8 - v_u_35
							local v46 = math.floor(v45)
							if v46 >= 220 then
								v_u_37 = v46
								return
							end
							local v47 = v_u_36
							local v48 = v43 + 8
							local v49 = math.floor(v48)
							v_u_36 = math.max(v47, v49)
						end
					end
				end
				pcall(v50)
				v_u_28 = UDim2.fromOffset(v_u_35, v_u_36)
				v_u_24.Size = UDim2.fromOffset(v_u_37, 0)
				v_u_32 = (1 / 0)
				if v34.bottom then
					local v51 = (v34.bottom - v_u_36 - 24 - 20) / 26
					local v52 = math.floor(v51)
					v_u_32 = math.max(1, v52)
				end
			end
		end
		local v_u_54 = 0
		local v_u_55 = false
		local v_u_56 = 0
		local v_u_57 = false
		local v_u_58 = -1
		local v_u_59 = false
		local v_u_60 = nil
		local v_u_61 = nil
		local v_u_62 = 92
		local function v_u_68(p63, p64) -- name: row
			-- upvalues: (copy) v_u_30, (copy) v_u_13, (copy) v_u_25, (copy) v_u_15
			local v65 = v_u_30[p63]
			if v65 then
				v65.frame.LayoutOrder = p64
				return v65
			end
			local v66 = v_u_13.new("Frame", {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "X_" .. p63,
				["Size"] = UDim2.new(1, 0, 0, 38),
				["LayoutOrder"] = p64
			}, v_u_25)
			local v67 = {
				["frame"] = v66,
				["dot"] = v_u_13.new("Frame", {
					["Name"] = "Dot",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_15.success,
					["Position"] = UDim2.fromOffset(0, 7),
					["Size"] = UDim2.fromOffset(6, 6)
				}, v66),
				["name"] = v_u_13.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "bodyStrong",
					["position"] = nil,
					["size"] = nil,
					["parent"] = v66,
					["position"] = UDim2.fromOffset(14, 0),
					["size"] = UDim2.new(1, -90, 0, 20)
				}),
				["cond"] = v_u_13.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v66,
					["color"] = v_u_15.muted,
					["position"] = UDim2.fromOffset(14, 19),
					["size"] = UDim2.new(1, -90, 0, 16)
				}),
				["dist"] = v_u_13.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "mono",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["parent"] = v66,
					["color"] = v_u_15.text2,
					["position"] = UDim2.new(1, -26, 0, 0),
					["anchor"] = Vector2.new(1, 0),
					["size"] = UDim2.fromOffset(60, 20)
				}),
				["arrow"] = v_u_13.icon("arrowUp", {
					["parent"] = nil,
					["size"] = 16,
					["color"] = nil,
					["position"] = nil,
					["anchor"] = nil,
					["parent"] = v66,
					["color"] = v_u_15.accent,
					["position"] = UDim2.new(1, 0, 0, 2),
					["anchor"] = Vector2.new(1, 0)
				})
			}
			v_u_30[p63] = v67
			return v67
		end
		local function v_u_123() -- name: refreshList
			-- upvalues: (copy) p_u_12, (ref) v_u_17, (copy) v_u_68, (ref) v_u_204, (ref) v_u_31, (ref) v_u_32, (copy) v_u_15, (copy) v_u_27, (copy) v_u_13, (copy) v_u_30
			local v69 = p_u_12.raid
			local v70 = not (v69 and v69.Parent) and p_u_12.cctx.runtime
			if v70 then
				v70 = v70:FindFirstChild("Raid")
			end
			if v70 then
				v70 = v70:FindFirstChild("Extracts")
			end
			local v71 = {}
			local v72 = v_u_17
			if v72 then
				v72 = v_u_17:FindFirstChild("HumanoidRootPart")
			end
			local v73 = workspace.CurrentCamera
			local v74 = 0
			local v75 = 0
			local v76 = 0
			if v70 then
				local v77 = {}
				for _, v78 in v70:GetChildren() do
					if not v78:IsA("BasePart") then
						continue
					end
					table.insert(v77, v78)
				end
				local v_u_79 = not v72 and Vector3.new(0, 0, 0) or v72.Position
				table.sort(v77, function(p80, p81)
					-- upvalues: (copy) v_u_79
					local v82 = p80:GetAttribute("Open") == true
					if v82 == (p81:GetAttribute("Open") == true) then
						return (p80.Position - v_u_79).Magnitude < (p81.Position - v_u_79).Magnitude
					else
						return v82
					end
				end)
				for v83, v84 in v77 do
					local v85 = v84:GetAttribute("ExtractId") or v84.Name
					local v86 = tostring(v85)
					v71[v86] = true
					local v87 = v_u_68(v86, v83)
					local v88 = v84:GetAttribute("Open") == true
					local v89 = v_u_204.stateText(v84)
					local v90 = v87.name
					local v91 = v84:GetAttribute("Name") or v86
					v90.Text = tostring(v91)
					local v92 = v84:GetAttribute("Condition") or ""
					local v93 = tostring(v92)
					if v88 then
						if v89 then
							v93 = v93 .. "  \194\183  " .. v89
						end
					else
						v93 = "Closed this raid"
					end
					v87.cond.Text = v93
					local v94 = true
					if v_u_31 and v88 then
						if v75 < v_u_32 then
							v75 = v75 + 1
						else
							v76 = v76 + 1
							v94 = false
						end
					end
					v87.frame.Visible = v88 and v94 and v94 or not v_u_31
					v87.cond.Visible = not v_u_31
					v87.frame.Size = UDim2.new(1, 0, 0, v_u_31 and 20 or 38)
					if not v88 then
						v74 = v74 + 1
					end
					local v95 = v87.dot
					local v96
					if v88 then
						v96 = v_u_15.success
					else
						v96 = v_u_15.muted
					end
					v95.BackgroundColor3 = v96
					local v97 = v87.name
					local v98
					if v88 then
						v98 = v_u_15.text
					else
						v98 = v_u_15.muted
					end
					v97.TextColor3 = v98
					if v72 then
						local v99 = v84.Position - v72.Position
						local v100 = v99.X
						local v101 = v99.Z
						local v102 = Vector3.new(v100, 0, v101)
						local v103 = p_u_12.cctx.shared
						if v103 then
							v103 = p_u_12.cctx.shared.Extracts
						end
						local v104 = v87.dist
						local v105
						if v103 then
							v105 = v103.distanceText(v84.CFrame, v84.Size, v72.Position)
						else
							local v106 = v102.Magnitude * 0.28 + 0.5
							local v107 = math.floor(v106)
							v105 = tostring(v107) .. " m"
						end
						v104.Text = v105
						if v73 and v102.Magnitude > 0.1 then
							local v108 = v73.CFrame.LookVector
							local v109 = v108.X
							local v110 = v108.Z
							local v111 = Vector3.new(v109, 0, v110)
							if v111.Magnitude > 0.01 then
								local v112 = v111.Unit
								local v113 = -v112.Z
								local v114 = v112.X
								local v115 = Vector3.new(v113, 0, v114)
								local v116 = v102.Unit
								local v117 = v116:Dot(v115)
								local v118 = v116:Dot(v112)
								local v119 = math.atan2(v117, v118)
								v87.arrow.Rotation = math.deg(v119)
							end
						end
						v87.arrow.Visible = v88
					else
						v87.dist.Text = ""
						v87.arrow.Visible = false
					end
				end
			end
			local v120 = "Extractions"
			if v_u_31 and v74 > 0 then
				v120 = v120 .. string.format("  \194\183  %d closed", v74)
			end
			if v_u_31 and v76 > 0 then
				v120 = v120 .. string.format("  \194\183  %d more", v76)
			end
			if v_u_27:GetAttribute("Src") ~= v120 then
				v_u_27:SetAttribute("Src", v120)
				v_u_13.setText(v_u_27, v120)
			end
			for v121, v122 in v_u_30 do
				if v71[v121] then
					continue
				end
				v122.frame:Destroy()
				v_u_30[v121] = nil
			end
		end
		function v16.reveal(p124) -- name: reveal
			-- upvalues: (ref) v_u_17, (ref) v_u_55, (ref) v_u_54, (copy) v_u_13, (copy) v_u_24, (copy) v_u_123, (ref) v_u_29, (copy) v_u_53, (ref) v_u_28, (copy) p_u_12
			local v125 = v_u_17 or game:GetService("Players").LocalPlayer.Character
			local v126
			if v125 == nil then
				v126 = false
			else
				v126 = v125:GetAttribute("Dead") == true and true or v125:GetAttribute("Downed") == true
			end
			if v126 then
				v_u_55 = false
				v_u_54 = 0
				v_u_13.fadeStop(v_u_24)
				v_u_24.Visible = false
			else
				v_u_54 = os.clock() + (p124 or 8)
				v_u_123()
				if v_u_29 then
					v_u_53()
				else
					local v127 = p_u_12.freeTag
					local v128 = p_u_12.eventBarH
					local v129 = type(v128) ~= "number" and 0 or p_u_12.eventBarH
					v_u_28 = UDim2.new(1, 0, 0, (v127 and v127.Parent and 94 or 64) + v129)
				end
				if v_u_55 then
					v_u_24.Position = v_u_28
				end
				if not v_u_55 then
					v_u_55 = true
					v_u_24.Visible = true
					v_u_24.Position = v_u_28 + UDim2.fromOffset(0, 8)
					v_u_13.fade(v_u_24, 0, "slow", {
						["from"] = v_u_13.fadeAlpha(v_u_24) <= 0 and 1 or nil
					})
					local v130 = {
						["Position"] = v_u_28
					}
					v_u_13.tween(v_u_24, v130, "slow")
					v_u_13.sound("open")
				end
			end
		end
		function v16.setCharacter(p131) -- name: setCharacter
			-- upvalues: (ref) v_u_17
			v_u_17 = p131
		end
		function v16.isShown() -- name: isShown
			-- upvalues: (ref) v_u_55
			return v_u_55
		end
		function v16.bandBusy() -- name: bandBusy
			-- upvalues: (ref) v_u_55, (copy) v_u_14, (copy) p_u_12
			if v_u_55 then
				return true
			end
			if not v_u_14.isPhone() then
				return false
			end
			local function v135()
				-- upvalues: (ref) p_u_12
				local v132 = p_u_12.cctx.controllers.Input
				local v133
				if v132 and v132.touch then
					v133 = v132.touch()
				else
					v133 = nil
				end
				local v134
				if v133 == nil then
					v134 = false
				else
					v134 = v133.trayOpen == true
				end
				return v134
			end
			local v136, v137 = pcall(v135)
			if v136 then
				v136 = v137 == true
			end
			return v136
		end
		function v16.extent() -- name: extent
			-- upvalues: (ref) v_u_62, (copy) v_u_23, (copy) v_u_14
			local v138 = v_u_62 + 14
			if v_u_23.Visible then
				local v139 = v_u_23.AbsoluteSize.X
				local v140 = v_u_14.uiScale
				local v141 = v139 / math.max(0.01, v140())
				v138 = v_u_62 + 14 + 6 + (v141 <= 1 and 52 or v141)
			end
			return v138
		end
		function v16.corner() -- name: corner
			-- upvalues: (ref) v_u_59, (ref) v_u_60, (ref) v_u_61
			return v_u_59 and (v_u_60 and v_u_61) and {
				["right"] = v_u_60,
				["top"] = v_u_61
			} or nil
		end
		function v16.revealLeft() -- name: revealLeft
			-- upvalues: (ref) v_u_55, (ref) v_u_54
			if not v_u_55 then
				return 0
			end
			local v142 = v_u_54 - os.clock()
			return math.max(0, v142)
		end
		function v16.layout(p143) -- name: layout
			-- upvalues: (copy) p_u_12, (copy) v_u_14, (ref) v_u_31, (ref) v_u_29, (copy) v_u_26, (ref) v_u_32, (ref) v_u_33, (copy) v_u_19, (ref) v_u_60, (ref) v_u_61, (copy) v_u_20, (copy) v_u_21, (ref) v_u_59, (ref) v_u_58, (ref) v_u_62, (copy) v_u_22, (copy) v_u_23, (copy) v_u_24, (copy) v_u_53, (copy) v_u_13, (ref) v_u_28
			local v144
			if p143 and p_u_12.touchFrame then
				v144 = p_u_12.touchFrame()
			else
				v144 = nil
			end
			local v_u_145 = false
			local function v146()
				-- upvalues: (ref) v_u_145, (ref) v_u_14
				v_u_145 = v_u_14.viewport().Y < 600
			end
			pcall(v146)
			v_u_31 = v144 ~= nil and true or v_u_145
			v_u_29 = v144 ~= nil
			v_u_26.Padding = UDim.new(0, v_u_31 and 6 or 8)
			v_u_32 = (1 / 0)
			if v144 then
				local v147 = {
					["x"] = v144.bandLeft or v144.left
				}
				local v148 = v144.listY
				local v149
				if type(v148) == "number" then
					v149 = v144.listY
				else
					v149 = v144.top + 96
				end
				v147.y = v149
				local v150 = v144.listW
				v147.w = type(v150) ~= "number" and 300 or v144.listW
				local v151 = v144.listBottom
				local v152
				if type(v151) == "number" then
					v152 = v144.listBottom
				else
					v152 = nil
				end
				v147.bottom = v152
				v_u_33 = v147
				if v144.corner then
					local v153, v154 = p_u_12.cctx.lib.HudLayout.fractions("Extracts")
					if v153 and v154 then
						local v155 = v_u_33
						local v156 = v153 * v144.refW
						local v157 = v144.refW - v_u_33.w
						local v158 = math.max(0, v157)
						local v159 = math.min(v156, v158)
						v155.x = math.floor(v159)
						local v160 = v_u_33
						local v161 = v154 * v144.refH
						v160.y = math.floor(v161)
						v_u_33.bottom = v144.refH - 8
					end
				end
			else
				v_u_33 = nil
			end
			if v144 and v144.corner then
				local v162 = p_u_12.cctx.lib.HudLayout
				local v163, v164 = v162.fractions("Clock")
				v_u_19.AnchorPoint = Vector2.new(1, 0)
				v_u_19.Position = v162.position("Clock", UDim2.new(1, -v144.right, 0, v144.corner.clockTop))
				v_u_19.Size = UDim2.fromOffset(240, v144.corner.clockH)
				if v163 and v164 then
					local v165 = v144.refW * (1 - v163)
					local v166 = v144.refH * v164
					v_u_60 = v165
					v_u_61 = v166
				else
					local v167 = v144.right
					local v168 = v144.corner.clockTop
					v_u_60 = v167
					v_u_61 = v168
				end
				v_u_20.Visible = false
				v_u_21.Position = UDim2.fromOffset(0, 0)
				v_u_21.Size = UDim2.new(1, 0, 0, v144.corner.clockH)
				v_u_21.TextSize = v_u_14.phoneText(26, "text")
				v_u_59 = true
				v_u_58 = -1
				v_u_62 = 92
				v_u_22.Position = UDim2.new(1, -v_u_62, 0, v144.corner.clockH / 2)
				v_u_23.Position = UDim2.new(1, -(v_u_62 + 14 + 6), 0, v144.corner.clockH / 2)
				v_u_24.Parent = p_u_12.root
				v_u_24.AnchorPoint = Vector2.new(0, 0)
				v_u_53()
			elseif v144 then
				v_u_59 = false
				v_u_60 = nil
				v_u_61 = nil
				v_u_19.AnchorPoint = Vector2.new(1, 0)
				v_u_21.Size = UDim2.new(1, 0, 0, 32)
				v_u_21.TextSize = 30
				v_u_19.Position = UDim2.new(1, -v144.right, 0, v144.top)
				v_u_19.Size = UDim2.fromOffset(240, 32)
				v_u_20.Visible = false
				v_u_21.Position = UDim2.fromOffset(0, 0)
				v_u_22.Position = UDim2.new(1, -102, 0, 16)
				v_u_23.Position = UDim2.new(1, -128, 0, 16)
				v_u_24.Parent = p_u_12.root
				v_u_24.AnchorPoint = Vector2.new(0, 0)
				v_u_53()
			else
				v_u_59 = false
				v_u_60 = nil
				v_u_61 = nil
				local v169 = v_u_13.topInset()
				v_u_19.AnchorPoint = Vector2.new(1, 0)
				v_u_21.Size = UDim2.new(1, 0, 0, 32)
				v_u_21.TextSize = 30
				v_u_19.Position = UDim2.new(1, -40, 0, v169)
				v_u_19.Size = UDim2.fromOffset(240, 48)
				v_u_20.Visible = true
				v_u_21.Position = UDim2.fromOffset(0, 16)
				v_u_22.Position = UDim2.new(1, -102, 0, 32)
				v_u_23.Position = UDim2.new(1, -128, 0, 32)
				v_u_24.Parent = v_u_19
				v_u_24.AnchorPoint = Vector2.new(1, 0)
				local v170 = p_u_12.freeTag
				local v171 = p_u_12.eventBarH
				local v172 = type(v171) ~= "number" and 0 or p_u_12.eventBarH
				v_u_28 = UDim2.new(1, 0, 0, (v170 and v170.Parent and 94 or 64) + v172)
				v_u_24.Size = UDim2.fromOffset(320, 0)
			end
			v_u_24.Position = v_u_28
		end
		local v_u_173 = 0
		function v16.update(p174) -- name: update
			-- upvalues: (ref) v_u_56, (copy) p_u_12, (copy) v_u_19, (ref) v_u_1, (ref) v_u_58, (copy) v_u_21, (copy) v_u_13, (ref) v_u_59, (copy) v_u_14, (ref) v_u_62, (copy) v_u_22, (copy) v_u_23, (ref) v_u_57, (copy) v_u_20, (copy) v_u_15, (ref) v_u_55, (ref) v_u_17, (ref) v_u_54, (copy) v_u_24, (ref) v_u_173, (copy) v_u_123, (ref) v_u_29, (ref) v_u_28
			v_u_56 = v_u_56 + p174
			local v175 = p_u_12.raid
			local v176 = not (v175 and v175.Parent) and p_u_12.cctx.runtime
			if v176 then
				v176 = v176:FindFirstChild("Raid")
			end
			if v176 then
				v_u_19.Visible = true
				local v177 = v_u_1.now()
				local v178 = v176:GetAttribute("EndsAt")
				local v179 = type(v178) ~= "number" and 0 or v178
				local v180 = v176:GetAttribute("SirenAt")
				local v181 = type(v180) ~= "number" and (1 / 0) or v180
				local v182 = v179 <= 0 and 0 or p_u_12.cctx.shared.RaidClock.left(v179, v176:GetAttribute("StartedAt"), v177)
				local v183 = math.floor(v182)
				if v183 ~= v_u_58 then
					v_u_58 = v183
					v_u_21.Text = v_u_13.clock(v182)
					if v_u_59 then
						local v184 = v_u_21.TextBounds.X
						local v185 = v_u_14.uiScale
						local v186 = v184 / math.max(0.01, v185())
						if v186 > 8 then
							local v187 = v186 + 10
							local v188 = math.ceil(v187)
							if v188 ~= v_u_62 then
								v_u_62 = v188
								v_u_22.Position = UDim2.new(1, -v_u_62, 0, v_u_22.Position.Y.Offset)
								v_u_23.Position = UDim2.new(1, -(v_u_62 + 14 + 6), 0, v_u_23.Position.Y.Offset)
							end
						end
					end
				end
				local v189
				if v181 <= v177 then
					v189 = v179 > 0
				else
					v189 = false
				end
				if v189 ~= v_u_57 then
					v_u_57 = v189
					v_u_23.Visible = v189
					local v190 = v_u_20
					local v191
					if v189 then
						v191 = v_u_15.danger
					else
						v191 = v_u_15.muted
					end
					v190.TextColor3 = v191
					local v192 = v_u_13.setIconColor
					local v193 = v_u_22
					local v194
					if v189 then
						v194 = v_u_15.danger
					else
						v194 = v_u_15.text2
					end
					v192(v193, v194)
				end
				if v189 then
					local v195
					if v182 < 60 then
						local v196 = v_u_56 * 8
						v195 = math.sin(v196) * 0.5 + 0.5
					else
						v195 = 0
					end
					v_u_21.TextColor3 = v_u_15.danger:Lerp(v_u_15.text, v195 * 0.4)
				else
					v_u_21.TextColor3 = v_u_15.text
				end
				if v_u_55 then
					local v197 = v_u_17 or game:GetService("Players").LocalPlayer.Character
					local v198
					if v197 == nil then
						v198 = false
					else
						v198 = v197:GetAttribute("Dead") == true and true or v197:GetAttribute("Downed") == true
					end
					if v198 then
						v_u_55 = false
						v_u_54 = 0
						v_u_13.fadeStop(v_u_24)
						v_u_24.Visible = false
					end
				end
				if v_u_55 then
					v_u_173 = v_u_173 + p174
					if v_u_173 > 0.25 then
						v_u_173 = 0
						v_u_123()
						if not v_u_29 then
							local v199 = p_u_12.freeTag
							local v200 = p_u_12.eventBarH
							local v201 = type(v200) ~= "number" and 0 or p_u_12.eventBarH
							local v202 = UDim2.new(1, 0, 0, (v199 and v199.Parent and 94 or 64) + v201)
							if v_u_28 ~= v202 then
								v_u_28 = v202
								v_u_24.Position = v202
							end
						end
					end
					if v_u_54 < os.clock() then
						v_u_55 = false
						local v203 = {
							["onDone"] = function() -- name: onDone
								-- upvalues: (ref) v_u_55, (ref) v_u_24
								if not v_u_55 then
									v_u_24.Visible = false
								end
							end
						}
						v_u_13.fade(v_u_24, 1, "slow", v203)
					end
				end
			else
				v_u_19.Visible = false
			end
		end
		function v16.destroy() -- name: destroy
			-- upvalues: (copy) v_u_24, (copy) v_u_19
			v_u_24:Destroy()
			v_u_19:Destroy()
		end
		return v16
	end
}
return v_u_204