-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / HuntClient

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = {
	["name"] = "HuntClient",
	["order"] = 52
}
local v_u_8 = v_u_3.LocalPlayer
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = ""
local v_u_28 = false
local v_u_29 = false
local v_u_30 = 0
local v_u_31 = false
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = 0
local v_u_35 = "bear"
local v_u_36 = {
	["bear"] = Enum.KeyCode.Y,
	["alarm"] = Enum.KeyCode.U
}
local v_u_37 = Enum.KeyCode.N
local v_u_38 = 0
local v_u_39 = 0
local v_u_40 = {}
local v_u_41 = false
local v_u_42 = false
local v_u_43 = 0
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = nil
local v_u_47 = {}
local v_u_48 = false
local v_u_49 = 0
local v_u_50 = 0
local v_u_51 = ""
local v_u_52 = false
local v_u_53 = {}
local v_u_54 = {}
local v_u_55 = nil
local v_u_56 = {
	["states"] = 0,
	["flings"] = 0,
	["pulses"] = 0,
	["ignored"] = 0,
	["spectateAsks"] = 0,
	["pk"] = 0,
	["tr"] = 0,
	["steps"] = 0,
	["placed"] = 0,
	["dazes"] = 0,
	["colas"] = 0,
	["equips"] = 0
}
local function v_u_62() -- name: candidates
	-- upvalues: (copy) v_u_3, (copy) v_u_8
	local v57 = {}
	for _, v58 in v_u_3:GetPlayers() do
		if v58 == v_u_8 or (v58:GetAttribute("HuntPlayer") ~= true or v58:GetAttribute("HuntStatus") == "Out") then
			continue
		end
		local v59 = v58.Character
		if not v59 or (not v59.Parent or v59:GetAttribute("Dead") == true) then
			continue
		end
		table.insert(v57, v58)
	end
	table.sort(v57, function(p60, p61)
		return p60.UserId < p61.UserId
	end)
	return v57
end
local function v_u_64() -- name: leave
	-- upvalues: (ref) v_u_9
	local v63 = v_u_9.net.fire
	pcall(v63, "hunt.op", {
		["op"] = "leave"
	})
end
local function v_u_80(p_u_65) -- name: stepWatch
	-- upvalues: (copy) v_u_62, (ref) v_u_55, (copy) v_u_56, (ref) v_u_9, (copy) v_u_8
	local v_u_66 = v_u_62()
	if #v_u_66 ~= 0 then
		local v_u_67 = #v_u_66
		local v_u_68 = p_u_65 >= 0 and 0 or v_u_67 + 1
		for v69, v70 in v_u_66 do
			if v70.Name ~= v_u_55 then
				continue
			end
			v_u_68 = v69
		end
		local v71 = v_u_56
		v71.spectateAsks = v71.spectateAsks + 1
		task.spawn(function()
			-- upvalues: (copy) v_u_67, (copy) v_u_66, (ref) v_u_68, (copy) p_u_65, (ref) v_u_9, (ref) v_u_8
			for v72 = 1, v_u_67 do
				local v73 = v_u_66
				local v74 = v_u_68 - 1
				local v75
				if p_u_65 >= 0 then
					v75 = v72
				else
					v75 = -v72
				end
				local v76 = v73[(v74 + v75) % v_u_67 + 1]
				local v77 = v_u_9.net.fire
				local v78 = v76.UserId
				pcall(v77, "raid.spectate", v78)
				task.wait(0.4)
				local v79 = v_u_8:GetAttribute("SpectateFocus")
				if v79 ~= v76.Name and (v76.Character == nil or v79 ~= v76.Character.Name) then
					continue
				end
				return
			end
		end)
	end
end
local function v_u_90() -- name: syncSpectate
	-- upvalues: (copy) v_u_8, (ref) v_u_55, (copy) v_u_40, (copy) v_u_3, (ref) v_u_9
	local v81 = v_u_8:GetAttribute("SpectateFocus")
	if type(v81) == "string" and v81 ~= "" then
		local v82 = nil
		for _, v83 in v_u_3:GetPlayers() do
			if v83.Name ~= v81 and (v83.Character == nil or v83.Character.Name ~= v81) then
				continue
			end
			v82 = v83
		end
		if v82 ~= nil and v82.Character ~= nil then
			if v_u_55 ~= v82.Name then
				v_u_55 = v82.Name
				v_u_40.watching = v82.DisplayName
				local v_u_84 = "Camera"
				local function v85()
					-- upvalues: (ref) v_u_9, (copy) v_u_84
					return v_u_9.controllers[v_u_84]
				end
				local v86, v87 = pcall(v85)
				if not v86 then
					v87 = nil
				end
				if v87 and v87.setMode then
					local v88 = v87.setMode
					local v89 = v82.Character
					pcall(v88, "spectate", v89)
				end
			end
		end
	else
		if v_u_55 ~= nil then
			v_u_55 = nil
			v_u_40.watching = nil
		end
		return
	end
end
local function v_u_104(p91) -- name: touchButtons
	-- upvalues: (ref) v_u_9, (copy) v_u_54
	local v_u_92 = "Input"
	local function v93()
		-- upvalues: (ref) v_u_9, (copy) v_u_92
		return v_u_9.controllers[v_u_92]
	end
	local v94, v95 = pcall(v93)
	if not v94 then
		v95 = nil
	end
	if v95 then
		local v96 = v95.touch
		if type(v96) == "function" then
			local v97 = v95.touch
			local v98, v_u_99 = pcall(v97)
			if v98 and v_u_99 ~= nil then
				if p91 then
					local v100, v101 = pcall(function()
						-- upvalues: (copy) v_u_99
						return v_u_99:buttonGui("inventory")
					end)
					if v100 and (v101 ~= nil and v101.Visible) then
						v101.Visible = false
						local v102 = v_u_54
						table.insert(v102, v101)
						return
					end
				else
					for _, v103 in v_u_54 do
						if not v103.Parent then
							continue
						end
						v103.Visible = true
					end
					table.clear(v_u_54)
				end
			end
		end
	end
end
local function v_u_114(p105) -- name: reportKiller
	-- upvalues: (ref) v_u_23, (ref) v_u_9, (ref) v_u_24
	if v_u_23 == nil then
		return false
	end
	local v106 = v_u_23.openHunt
	local v107 = {
		["cctx"] = v_u_9
	}
	local v111 = {
		["userId"] = p105.uid,
		["name"] = p105.name,
		["display"] = p105.display,
		["onClose"] = function(p108) -- name: onClose
			-- upvalues: (ref) v_u_24
			if v_u_24 ~= nil then
				local v109 = v_u_24.reportClosed
				local v110 = p108 == true
				pcall(v109, v110)
			end
		end
	}
	local v112, v113 = pcall(v106, v107, v111)
	if v112 then
		v112 = v113 ~= nil
	end
	return v112
end
local function v_u_119() -- name: canReportKiller
	-- upvalues: (ref) v_u_23, (ref) v_u_9
	if v_u_23 == nil then
		return false
	end
	local v115 = v_u_23.available
	local v116 = {
		["cctx"] = v_u_9
	}
	local v117, v118 = pcall(v115, v116)
	if v117 then
		v117 = v118 == true
	end
	return v117
end
local function v_u_185(p120) -- name: onState
	-- upvalues: (copy) v_u_56, (copy) v_u_40, (ref) v_u_24, (ref) v_u_13, (ref) v_u_9, (ref) v_u_22, (copy) v_u_8
	if type(p120) == "table" then
		local v121 = p120.k
		if type(v121) == "string" then
			if p120.k ~= "lobby" then
				local v122 = v_u_56
				v122.states = v122.states + 1
				local v123 = os.clock()
				if p120.k == "wait" then
					v_u_40.phase = v_u_40.phase or "wait"
					local v124 = p120.t
					if type(v124) == "string" then
						v_u_40.waitT = p120.t
						return
					end
				else
					if p120.k == "role" then
						local v125 = p120.r == "stalker" and "stalker" or "survivor"
						v_u_40.role = v125
						local v126 = v_u_40
						local v127 = p120.s
						local v128
						if type(v127) == "number" then
							v128 = p120.s
						else
							v128 = v_u_40.s0
						end
						v126.s0 = v128
						local v129 = v_u_40
						local v130 = v_u_40
						v_u_40.out = nil
						v129.result = nil
						v130.home = nil
						if v_u_24 ~= nil then
							local v131 = v_u_24.close
							pcall(v131, "round")
						end
						local v132 = v_u_40
						v_u_40.t0 = v123
						v132.outAt = nil
						v_u_40.waitT = nil
						local v133 = v_u_13.splitRole
						local v134 = p120.t or ""
						local v135 = tostring(v134)
						local v136 = p120.sub
						local v137
						if type(v136) == "string" then
							v137 = p120.sub
						else
							v137 = nil
						end
						local v138, v139 = v133(v135, v137)
						v_u_40.roleCard = {
							["t"] = v138,
							["sub"] = v139,
							["r"] = v125,
							["untilT"] = v123 + v_u_13.ROLE_SEC
						}
						return
					end
					if p120.k == "phase" then
						local v140 = p120.phase
						if type(v140) == "string" then
							v_u_40.phase = p120.phase
						end
						local v141 = p120.endsAt
						if type(v141) == "number" then
							v_u_40.endsAt = p120.endsAt
							return
						end
					elseif p120.k == "notice" then
						local v142 = p120.t
						if type(v142) == "string" then
							local v143 = p120.key
							v_u_40.banner = {
								["t"] = p120.t,
								["kind"] = v143 == "payback" and "danger" or "info",
								["untilT"] = v123 + 6
							}
							if v143 == "newStalkerYou" then
								v_u_40.role = "stalker"
								v_u_40.roleCard = {
									["t"] = nil,
									["sub"] = "",
									["r"] = "stalker",
									["untilT"] = nil,
									["t"] = p120.t,
									["untilT"] = v123 + v_u_13.ROLE_SEC
								}
								return
							end
						end
					elseif p120.k == "out" then
						local v144 = v_u_40
						local v145 = {}
						local v146 = p120.t or ""
						v145.t = tostring(v146)
						local v147 = p120.sub or ""
						v145.sub = tostring(v147)
						v144.out = v145
						v_u_40.outAt = v_u_40.outAt or v123
						local v148 = p120.role
						if type(v148) == "string" then
							v_u_40.role = p120.role
						end
						v_u_40.roleCard = nil
						local v149 = v_u_9.net.fire
						pcall(v149, "raid.spectate", 0)
						if v_u_24 ~= nil then
							if v_u_22 == nil then
								return
							end
							local v150 = v_u_22.model(p120, v_u_8.UserId)
							if v150 ~= nil then
								local v151 = v_u_24.show
								local v152 = v_u_40
								pcall(v151, v150, v152)
								return
							end
						end
					else
						if p120.k == "result" then
							local v153 = v_u_40
							local v154 = {}
							local v155 = p120.t or ""
							v154.t = tostring(v155)
							v154.role = p120.role
							v154.won = p120.won == true
							local v156 = p120.titles
							v154.titles = type(v156) ~= "table" and {} or p120.titles
							local v157 = p120.sec
							v154.sec = type(v157) ~= "number" and 15 or p120.sec
							v154.at = v123
							local v158 = p120.pk
							local v159
							if type(v158) == "table" then
								v159 = p120.pk
							else
								v159 = nil
							end
							v154.pk = v159
							local v160 = p120.rewards
							v154.rewards = type(v160) ~= "table" and {} or p120.rewards
							local v161 = p120.crates
							v154.crates = type(v161) ~= "number" and 0 or p120.crates
							local v162 = p120.prog
							local v163
							if type(v162) == "table" then
								v163 = p120.prog
							else
								v163 = nil
							end
							v154.prog = v163
							v154.eligible = p120.eligible ~= false
							local v164 = p120.res
							local v165
							if type(v164) == "string" then
								v165 = p120.res
							else
								v165 = nil
							end
							v154.res = v165
							local v166 = v_u_40.t0
							local v167
							if type(v166) == "number" then
								local v168 = (v_u_40.outAt or v123) - v_u_40.t0
								v167 = math.max(0, v168)
							else
								v167 = nil
							end
							v154.survived = v167
							v154.outAfter = v_u_40.outAt ~= nil
							v153.result = v154
							local v169 = v_u_40
							local v170 = v_u_40
							v_u_40.out = nil
							v169.roleCard = nil
							v170.banner = nil
							return
						end
						if p120.k == "home" then
							local v171 = v_u_40
							local v172 = {}
							local v173 = p120.t or ""
							v172.t = tostring(v173)
							v171.home = v172
							if v_u_24 ~= nil then
								local v174 = v_u_24.close
								pcall(v174, "home")
								return
							end
						elseif p120.k == "loot" then
							local v175 = v_u_40.loot
							local v176 = v_u_40
							local v177 = {}
							local v178 = p120.melee
							v177.melee = type(v178) ~= "string" and "" or p120.melee
							local v179 = p120.cola
							v177.cola = type(v179) ~= "number" and 0 or p120.cola
							v177.frag = not v175 and 0 or v175.frag
							v177.flash = not v175 and 0 or v175.flash
							local v180
							if v175 then
								v180 = v175.sel
							else
								v180 = nil
							end
							v177.sel = v180
							local v181
							if v175 then
								v181 = v175.held
							else
								v181 = nil
							end
							v177.held = v181
							v176.loot = v177
							local v182 = p120.say
							if type(v182) == "string" and p120.say ~= "" then
								v_u_40.banner = {
									["t"] = p120.say,
									["kind"] = p120.kind == "warn" and "warn" or "info",
									["untilT"] = v123 + 2.5
								}
								return
							end
						else
							local v183 = v_u_56
							v183.ignored = v183.ignored + 1
						end
					end
				end
			end
		end
	end
	local v184 = v_u_56
	v184.ignored = v184.ignored + 1
end
local function v_u_197(p186) -- name: onPk
	-- upvalues: (copy) v_u_56, (ref) v_u_41, (copy) v_u_40, (ref) v_u_18
	if type(p186) == "table" then
		local v187 = v_u_56
		v187.pk = v187.pk + 1
		if v_u_41 then
			local v188 = p186.n
			local v189 = type(v188) ~= "number" and 0 or p186.n
			local v190 = v_u_40.pk
			local v191 = v_u_40
			local v192 = {
				["n"] = v189
			}
			local v193 = p186.t
			local v194
			if type(v193) == "number" then
				v194 = p186.t
			elseif v190 then
				v194 = v190.t
			else
				v194 = nil
			end
			v192.t = v194
			local v195
			if v190 == nil or v190.n ~= v189 then
				v195 = os.clock()
			else
				v195 = v190.at
			end
			v192.at = v195
			v191.pk = v192
			if v_u_18 ~= nil then
				local v196 = v_u_18.apply
				pcall(v196, p186)
			end
		end
	else
		return
	end
end
local function v_u_219(p198, p_u_199) -- name: trapSound
	-- upvalues: (ref) v_u_9
	local v_u_200 = "Audio"
	local function v201()
		-- upvalues: (ref) v_u_9, (copy) v_u_200
		return v_u_9.controllers[v_u_200]
	end
	local v202, v_u_203 = pcall(v201)
	if not v202 then
		v_u_203 = nil
	end
	local function v204()
		-- upvalues: (ref) v_u_9
		return v_u_9.shared.HuntSounds
	end
	local v205, v206 = pcall(v204)
	local function v207()
		-- upvalues: (ref) v_u_9
		return v_u_9.shared.Sounds
	end
	local v208, v209 = pcall(v207)
	local v_u_210
	if v205 and (v208 and (v206 and v209)) then
		v_u_210 = v206.nameFor(v209, p198)
	else
		v_u_210 = nil
	end
	if v_u_203 ~= nil and v_u_210 ~= nil then
		local function v218() -- name: once
			-- upvalues: (copy) p_u_199, (copy) v_u_203, (copy) v_u_210
			if p_u_199 ~= nil then
				local v211 = v_u_203.play3D
				if type(v211) == "function" then
					local v212 = v_u_203.play3D
					local v213 = v_u_210
					local v214 = p_u_199
					pcall(v212, v213, v214, {
						["volume"] = 1
					})
					return
				end
			end
			local v215 = v_u_203.play
			if type(v215) == "function" then
				local v216 = v_u_203.play
				local v217 = v_u_210
				pcall(v216, v217)
			end
		end
		v218()
		if p198 == "alarm" then
			task.delay(0.22, v218)
			task.delay(0.44, v218)
		end
	end
end
local function v_u_225() -- name: loadHowSeen
	-- upvalues: (ref) v_u_26, (ref) v_u_29, (ref) v_u_21, (ref) v_u_30, (ref) v_u_43, (ref) v_u_41, (ref) v_u_27
	if v_u_26 == nil and (not v_u_29 and (v_u_21 ~= nil and os.clock() >= v_u_30)) then
		v_u_29 = true
		v_u_30 = os.clock() + 6
		local v_u_220 = v_u_43
		task.spawn(function()
			-- upvalues: (ref) v_u_29, (copy) v_u_220, (ref) v_u_43, (ref) v_u_41, (ref) v_u_27, (ref) v_u_26, (ref) v_u_21
			local v_u_221 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
			if v_u_221 then
				v_u_221 = v_u_221:FindFirstChild("menu.get")
			end
			local v222, v223
			if v_u_221 == nil or not v_u_221:IsA("RemoteFunction") then
				v222 = false
				v223 = nil
			else
				v222, v223 = pcall(function()
					-- upvalues: (copy) v_u_221
					return v_u_221:InvokeServer({
						["what"] = "settings"
					})
				end)
			end
			v_u_29 = false
			if v_u_220 == v_u_43 and v_u_41 then
				if v222 and (type(v223) == "table" and v223.error == nil) then
					local v224 = v223.menuTipsSeen
					v_u_27 = type(v224) ~= "string" and "" or v223.menuTipsSeen
					v_u_26 = v_u_21.seenIn(v_u_27)
				end
			end
		end)
	end
end
local function v_u_229() -- name: markHowSeen
	-- upvalues: (ref) v_u_26, (ref) v_u_21, (copy) v_u_4, (ref) v_u_27, (ref) v_u_9
	if v_u_26 == true or v_u_21 == nil then
		return
	else
		v_u_26 = true
		if v_u_4:IsStudio() then
			return
		else
			local v_u_226 = v_u_21.seenValue(v_u_27)
			if v_u_226 ~= nil then
				v_u_27 = v_u_226
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (ref) v_u_21, (copy) v_u_226
					local v227 = v_u_9.net.fire
					local v228 = {
						["op"] = "setting",
						["key"] = nil,
						["value"] = nil,
						["key"] = v_u_21.SEEN_KEY,
						["value"] = v_u_226
					}
					pcall(v227, "menu.op", v228)
				end)
			end
		end
	end
end
local function v_u_242(p230, p231) -- name: openHowTo
	-- upvalues: (ref) v_u_21, (ref) v_u_41, (ref) v_u_25, (ref) v_u_28, (ref) v_u_31, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_229
	if v_u_21 == nil or not v_u_41 then
		return
	elseif v_u_25 == nil then
		v_u_28 = true
		v_u_31 = p231 == true
		local function v232()
			-- upvalues: (ref) v_u_9
			return v_u_9.shared.HuntRules
		end
		local v233, v234 = pcall(v232)
		local function v235()
			-- upvalues: (ref) v_u_9
			return v_u_9.shared.HuntRewards
		end
		local v236, v237 = pcall(v235)
		local v238 = v_u_21.open
		local v239 = {
			["UI"] = nil,
			["Theme"] = nil,
			["Names"] = nil,
			["Rules"] = nil,
			["Rewards"] = nil,
			["page"] = nil,
			["blur"] = false,
			["onClose"] = nil,
			["UI"] = v_u_10,
			["Theme"] = v_u_11,
			["Names"] = v_u_12
		}
		if not v233 then
			v234 = nil
		end
		v239.Rules = v234
		if not v236 then
			v237 = nil
		end
		v239.Rewards = v237
		v239.page = p230 or 1
		function v239.onClose() -- name: onClose
			-- upvalues: (ref) v_u_25
			v_u_25 = nil
		end
		local v240, v241 = pcall(v238, v239)
		if v240 then
			v_u_25 = v241
			v_u_229()
		end
	else
		v_u_25.goto(p230 or 1)
	end
end
local function v_u_264(p243) -- name: onTr
	-- upvalues: (copy) v_u_56, (ref) v_u_41, (ref) v_u_32, (ref) v_u_33, (copy) v_u_40, (ref) v_u_12, (copy) v_u_219
	if type(p243) == "table" then
		local v244 = p243.k
		if type(v244) == "string" then
			local v245 = v_u_56
			v245.tr = v245.tr + 1
			if v_u_41 then
				local v246 = p243.k
				if v246 == "steps" then
					if v_u_32 ~= nil then
						local v247 = v_u_56
						local v248 = v247.steps
						local v249 = p243.list
						v247.steps = v248 + (type(v249) == "table" and #p243.list or 0)
						local v250 = v_u_32.add
						pcall(v250, p243)
						return
					end
				elseif v246 == "traps" then
					if v_u_33 ~= nil then
						local v251 = v_u_33.apply
						pcall(v251, p243)
					end
					local v252 = p243.left
					if type(v252) == "table" then
						local v253 = v_u_40
						local v254 = {}
						local v255 = p243.left.bear
						v254.bear = tonumber(v255) or 0
						local v256 = p243.left.alarm
						v254.alarm = tonumber(v256) or 0
						v253.trap = v254
						return
					end
				elseif v246 == "ping" then
					if v_u_33 ~= nil then
						local v257 = v_u_33.ping
						pcall(v257, p243)
					end
					local v258 = v_u_12.TRAP
					local v259
					if p243.kind == "alarm" then
						v259 = v258.tripped
					elseif p243.kind == "broken" then
						v259 = v258.broken
					else
						v259 = v258.snapped
					end
					v_u_40.banner = {
						["t"] = nil,
						["kind"] = "warn",
						["untilT"] = nil,
						["t"] = v259,
						["untilT"] = os.clock() + 3
					}
					if p243.kind ~= "broken" then
						v_u_219(p243.kind == "alarm" and "alarm" or "trapSnap", nil)
						return
					end
				else
					if v246 == "set" then
						local v260
						if p243.kind == "alarm" then
							v260 = v_u_12.TRAP.setAlarm
						else
							v260 = v_u_12.TRAP.setBear
						end
						v_u_40.banner = {
							["t"] = nil,
							["kind"] = "info",
							["untilT"] = nil,
							["t"] = v260,
							["untilT"] = os.clock() + 2
						}
						v_u_219("trapSet", nil)
						return
					end
					if v246 == "deny" then
						local v261 = v_u_12.TRAP.deny
						local v262 = p243.why
						local v263 = v261[tostring(v262)]
						if type(v263) == "string" then
							v_u_40.banner = {
								["t"] = nil,
								["kind"] = "warn",
								["untilT"] = nil,
								["t"] = v263,
								["untilT"] = os.clock() + 2.5
							}
							return
						end
					else
						if v246 == "caught" then
							v_u_40.banner = {
								["t"] = nil,
								["kind"] = "danger",
								["untilT"] = nil,
								["t"] = v_u_12.TRAP.caught,
								["untilT"] = os.clock() + 3
							}
							return
						end
						if v246 == "clear" then
							if v_u_32 ~= nil then
								v_u_32.clear()
							end
							if v_u_33 ~= nil then
								v_u_33.clear()
							end
							v_u_40.trap = nil
						end
					end
				end
			end
		end
	end
end
local function v_u_269(p265) -- name: placeTrap
	-- upvalues: (ref) v_u_41, (ref) v_u_42, (copy) v_u_40, (ref) v_u_34, (copy) v_u_56, (ref) v_u_9
	if v_u_41 and not v_u_42 then
		if v_u_40.role == "stalker" and (v_u_40.out == nil and v_u_40.result == nil) then
			if v_u_40.phase == "hunt" or v_u_40.phase == "payback" then
				local v266 = os.clock()
				if v266 - v_u_34 >= 0.35 then
					v_u_34 = v266
					local v267 = v_u_56
					v267.placed = v267.placed + 1
					local v268 = v_u_9.net.fire
					pcall(v268, "hunt.op", {
						["op"] = "trap",
						["kind"] = nil,
						["kind"] = p265
					})
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_274() -- name: useCola
	-- upvalues: (ref) v_u_41, (ref) v_u_42, (copy) v_u_40, (ref) v_u_38, (copy) v_u_56, (ref) v_u_9
	if v_u_41 and not v_u_42 then
		if v_u_40.role == "survivor" and (v_u_40.out == nil and v_u_40.result == nil) then
			local v270 = v_u_40.loot
			if type(v270) == "table" and (v_u_40.loot.cola or 0) >= 1 then
				local v271 = os.clock()
				if v271 - v_u_38 >= 0.4 then
					v_u_38 = v271
					local v272 = v_u_56
					v272.colas = v272.colas + 1
					local v273 = v_u_9.net.fire
					pcall(v273, "hunt.op", {
						["op"] = "use",
						["kind"] = "cola"
					})
				end
			end
		end
	end
end
local function v_u_285(p275) -- name: onLoot
	-- upvalues: (ref) v_u_41, (ref) v_u_42, (copy) v_u_40, (copy) v_u_56, (ref) v_u_9, (copy) v_u_274
	if v_u_41 and (not v_u_42 and (v_u_40.role == "survivor" and (v_u_40.out == nil and v_u_40.result == nil))) then
		if p275 == "melee" then
			local v276 = v_u_56
			v276.equips = v276.equips + 1
			local v277 = v_u_9.net.fire
			pcall(v277, "combat.equip", {
				["slot"] = "melee"
			})
		elseif p275 == "frag" or p275 == "flash" then
			local v_u_278 = "WeaponClient"
			local function v279()
				-- upvalues: (ref) v_u_9, (copy) v_u_278
				return v_u_9.controllers[v_u_278]
			end
			local v280, v281 = pcall(v279)
			if not v280 then
				v281 = nil
			end
			if v281 then
				local v282 = v281.selectThrowable
				if type(v282) == "function" then
					local v283 = v281.selectThrowable
					local v284 = p275 == "frag" and "throw_frag" or "throw_flash"
					pcall(v283, v284)
					return
				end
			end
		elseif p275 == "cola" then
			v_u_274()
		end
	else
		return
	end
end
local function v_u_304(p286) -- name: onFx
	-- upvalues: (ref) v_u_41, (ref) v_u_15, (copy) v_u_56, (ref) v_u_9, (ref) v_u_46, (ref) v_u_12, (copy) v_u_40, (copy) v_u_219
	if type(p286) == "table" then
		if p286.kind == "fling" and (v_u_41 and v_u_15) then
			local v287 = v_u_56
			v287.flings = v287.flings + 1
			local v288 = v_u_15.fling
			local v_u_289 = "Atmosphere"
			local function v290()
				-- upvalues: (ref) v_u_9, (copy) v_u_289
				return v_u_9.controllers[v_u_289]
			end
			local v291, v292 = pcall(v290)
			if not v291 then
				v292 = nil
			end
			local v293
			if v292 and v292.quality then
				local v294 = v292.quality
				local v295, v296 = pcall(v294)
				v293 = (not v295 or type(v296) ~= "number") and 3 or v296
			else
				v293 = 3
			end
			pcall(v288, p286, v293)
			return
		elseif p286.kind == "pulse" and (v_u_41 and v_u_46) then
			local v297 = v_u_56
			v297.pulses = v297.pulses + 1
			local v298 = v_u_46.pulse
			local v299 = p286.pos
			local v300 = p286.sec
			pcall(v298, v299, v300)
			return
		elseif p286.kind == "daze" and v_u_41 then
			local v301 = v_u_56
			v301.dazes = v301.dazes + 1
			local v302
			if p286.stun == true then
				v302 = v_u_12.LOOT.stunned
			else
				v302 = v_u_12.LOOT.staggered
			end
			v_u_40.banner = {
				["t"] = nil,
				["kind"] = "warn",
				["untilT"] = nil,
				["t"] = v302,
				["untilT"] = os.clock() + 1.6
			}
			v_u_219("bonk", nil)
			return
		elseif p286.kind == "bonk" and v_u_41 then
			local v303 = v_u_56
			v303.dazes = v303.dazes + 1
			v_u_219("bonk", nil)
			return
		elseif p286.kind == "cache" and v_u_41 then
			v_u_219("cache", nil)
		elseif p286.kind == "sip" and v_u_41 then
			v_u_219("sip", nil)
		end
	else
		return
	end
end
local function v_u_306() -- name: unbindSpec
	-- upvalues: (copy) v_u_53
	for _, v305 in v_u_53 do
		if typeof(v305) == "RBXScriptConnection" then
			v305:Disconnect()
		else
			if type(v305) ~= "function" then
				continue
			end
			pcall(v305)
		end
	end
	table.clear(v_u_53)
end
local v_u_307 = nil
local function v_u_417() -- name: build
	-- upvalues: (ref) v_u_45, (copy) v_u_306, (ref) v_u_10, (ref) v_u_11, (ref) v_u_47, (ref) v_u_13, (ref) v_u_12, (copy) v_u_64, (copy) v_u_80, (copy) v_u_269, (copy) v_u_285, (copy) v_u_242, (ref) v_u_9, (copy) v_u_6, (copy) v_u_37, (copy) v_u_36, (copy) v_u_40, (copy) v_u_53, (ref) v_u_41, (ref) v_u_307, (copy) v_u_274, (ref) v_u_35, (ref) v_u_46, (ref) v_u_14, (ref) v_u_22, (ref) v_u_24, (copy) v_u_114, (copy) v_u_119, (ref) v_u_19, (ref) v_u_32, (copy) v_u_8, (ref) v_u_20, (ref) v_u_33, (copy) v_u_219, (ref) v_u_17, (ref) v_u_18, (copy) v_u_7
	if v_u_45 then
		return
	else
		v_u_306()
		local function v308()
			-- upvalues: (ref) v_u_10, (ref) v_u_11
			return v_u_10.screen("HushHuntHud", v_u_11.layer.hud + 1, {
				["insets"] = "Device"
			})
		end
		local v309, v310, v311 = pcall(v308)
		if v309 then
			local v312, v313 = v_u_10.screen("HushHuntBlind", v_u_11.layer.hud + 3, {
				["insets"] = "None"
			})
			local v314, v315 = v_u_10.screen("HushHuntFx", v_u_11.layer.hud + 2, {
				["insets"] = "None"
			})
			v_u_47 = { v310, v312, v314 }
			v_u_45 = v_u_13.new({
				["UI"] = v_u_10,
				["Theme"] = v_u_11,
				["Names"] = v_u_12,
				["root"] = v311,
				["blindRoot"] = v313,
				["onLeave"] = v_u_64,
				["onBack"] = v_u_64,
				["onNext"] = function() -- name: onNext
					-- upvalues: (ref) v_u_80
					v_u_80(1)
				end,
				["onPrev"] = function() -- name: onPrev
					-- upvalues: (ref) v_u_80
					v_u_80(-1)
				end,
				["onTrap"] = v_u_269,
				["onLoot"] = v_u_285,
				["onHowTo"] = function() -- name: onHowTo
					-- upvalues: (ref) v_u_242
					v_u_242(1)
				end,
				["Rules"] = v_u_9.shared.HuntRules,
				["Rewards"] = v_u_9.shared.HuntRewards,
				["lootKey"] = function(p316) -- name: lootKey
					-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_37
					if p316 ~= "cola" then
						return ""
					end
					local v317 = v_u_10.device
					local v318 = type(v317) ~= "function" and "Keyboard" or v_u_10.device()
					if v318 == "Touch" then
						return ""
					end
					if v318 == "Gamepad" then
						return "VIEW"
					end
					local function v319()
						-- upvalues: (ref) v_u_6, (ref) v_u_37
						return v_u_6:GetStringForKeyCode(v_u_37)
					end
					local v320, v321 = pcall(v319)
					return (not v320 or (type(v321) ~= "string" or v321 == "")) and "" or v321
				end,
				["keyLabel"] = function(p_u_322) -- name: keyLabel
					-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_36
					local v323 = v_u_10.device
					local v324 = type(v323) ~= "function" and "Keyboard" or v_u_10.device()
					if v324 == "Touch" then
						return ""
					end
					if v324 == "Gamepad" then
						return "VIEW"
					end
					local function v325()
						-- upvalues: (ref) v_u_6, (ref) v_u_36, (copy) p_u_322
						return v_u_6:GetStringForKeyCode(v_u_36[p_u_322])
					end
					local v326, v327 = pcall(v325)
					return (not v326 or (type(v327) ~= "string" or v327 == "")) and "" or v327
				end
			})
			local v_u_328 = "Input"
			local function v329()
				-- upvalues: (ref) v_u_9, (copy) v_u_328
				return v_u_9.controllers[v_u_328]
			end
			local v330, v331 = pcall(v329)
			if not v330 then
				v331 = nil
			end
			if v331 then
				local v332 = v331.bind
				if type(v332) == "function" then
					for v_u_333, v334 in {
						[-1] = v_u_13.SPEC_ACTIONS.prev,
						[1] = v_u_13.SPEC_ACTIONS.next
					} do
						local v335 = v331.bind
						local function v337()
							-- upvalues: (ref) v_u_40, (ref) v_u_80, (copy) v_u_333
							local v336
							if v_u_40.out == nil then
								v336 = false
							else
								v336 = v_u_40.result == nil
							end
							if v336 then
								v_u_80(v_u_333)
							end
						end
						local v338, v339 = pcall(v335, v334, v337)
						if not v338 or type(v339) ~= "function" then
							continue
						end
						local v340 = v_u_53
						table.insert(v340, v339)
					end
				end
			end
			local v_u_341 = v_u_11.touch(44) ~= 44
			local v342 = v_u_53
			local v343 = v_u_6.LastInputTypeChanged
			local function v344()
				-- upvalues: (ref) v_u_41, (ref) v_u_45, (ref) v_u_11, (copy) v_u_341, (ref) v_u_307
				task.delay(0.3, function()
					-- upvalues: (ref) v_u_41, (ref) v_u_45, (ref) v_u_11, (ref) v_u_341, (ref) v_u_307
					if v_u_41 and v_u_45 and v_u_11.touch(44) ~= 44 ~= v_u_341 then
						v_u_307()
					end
				end)
			end
			table.insert(v342, v343:Connect(v344))
			local v345 = v_u_53
			local v346 = v_u_6.InputBegan
			local function v352(p347, p348)
				-- upvalues: (ref) v_u_41, (ref) v_u_40, (ref) v_u_37, (ref) v_u_274, (ref) v_u_36, (ref) v_u_269, (ref) v_u_35
				if p348 or not v_u_41 then
					return
				elseif v_u_40.role == "survivor" then
					if p347.KeyCode == v_u_37 or p347.KeyCode == Enum.KeyCode.ButtonSelect then
						v_u_274()
					end
					return
				elseif v_u_40.role == "stalker" then
					if p347.KeyCode == v_u_36.bear then
						v_u_269("bear")
						return
					elseif p347.KeyCode == v_u_36.alarm then
						v_u_269("alarm")
					elseif p347.KeyCode == Enum.KeyCode.ButtonSelect then
						local v349 = v_u_40.trap
						local v350 = v_u_35
						local v351 = type(v349) == "table" and (v349[v350] or 0) <= 0 and (v350 == "bear" and "alarm" or "bear") or v350
						v_u_35 = v351 == "bear" and "alarm" or "bear"
						v_u_269(v351)
					end
				else
					return
				end
			end
			table.insert(v345, v346:Connect(v352))
			v_u_46 = v_u_14.new({
				["UI"] = v_u_10,
				["Theme"] = v_u_11,
				["Names"] = v_u_12,
				["root"] = v315,
				["cctx"] = v_u_9,
				["safe"] = v_u_10.safeInsets
			})
			if v_u_22 ~= nil and v_u_24 == nil then
				local function v353()
					-- upvalues: (ref) v_u_10, (ref) v_u_11
					return v_u_10.screen("HushHuntKill", v_u_11.layer.hud + 4, {
						["insets"] = "Device"
					})
				end
				local v354, v355, v356 = pcall(v353)
				if v354 then
					local v357 = v_u_47
					table.insert(v357, v355)
					local v358 = v_u_22.new
					local v359 = {
						["UI"] = v_u_10,
						["Theme"] = v_u_11,
						["R"] = v_u_9.shared.ReportRules,
						["root"] = v356,
						["onReport"] = v_u_114,
						["canReport"] = v_u_119,
						["hudRects"] = function() -- name: hudRects
							-- upvalues: (ref) v_u_45
							if v_u_45 == nil then
								return nil
							else
								return v_u_45.rects()
							end
						end
					}
					local v360, v361 = pcall(v358, v359)
					if v360 then
						v_u_24 = v361
					else
						warn("[HuntClient] kill card failed:", v361)
					end
				end
			end
			if v_u_19 ~= nil and v_u_32 == nil then
				v_u_32 = v_u_19.new({
					["parent"] = workspace,
					["rules"] = v_u_9.shared.HuntRules,
					["decalL"] = v_u_12 and (v_u_12.ART and v_u_12.ART.footL) or nil,
					["decalR"] = v_u_12 and (v_u_12.ART and v_u_12.ART.footR) or nil,
					["vis"] = function(p362) -- name: vis
						-- upvalues: (ref) v_u_9
						local v_u_363 = "Vision"
						local function v364()
							-- upvalues: (ref) v_u_9, (copy) v_u_363
							return v_u_9.controllers[v_u_363]
						end
						local v365, v366 = pcall(v364)
						if not v365 then
							v366 = nil
						end
						if v366 then
							local v367 = v366.visibility
							if type(v367) == "function" then
								local v368 = v366.visibility
								local v369, v370 = pcall(v368, p362)
								if v369 and type(v370) == "number" then
									return v370
								end
							end
						end
						return 1
					end,
					["focus"] = function() -- name: focus
						-- upvalues: (ref) v_u_8
						local v371 = v_u_8.Character
						if v371 then
							v371 = v371:FindFirstChild("HumanoidRootPart")
						end
						if v371 and v371:IsA("BasePart") then
							return v371.Position
						else
							return nil
						end
					end
				})
			end
			if v_u_20 ~= nil and v_u_33 == nil then
				local v372 = v_u_20.new
				local v373 = {
					["parent"] = workspace,
					["rules"] = v_u_9.shared.HuntRules
				}
				local v374 = {}
				local v_u_375 = "BearTrap"
				local function v377()
					-- upvalues: (ref) v_u_9, (copy) v_u_375
					local v376 = v_u_9.shared.Assets
					if v376.hasImported("Prop", v_u_375) then
						return v376.template("Prop", v_u_375)
					else
						return nil
					end
				end
				local v378, v379 = pcall(v377)
				if not v378 or typeof(v379) ~= "Instance" then
					v379 = nil
				end
				v374.bear = v379
				local v_u_380 = "MotionAlarm"
				local function v382()
					-- upvalues: (ref) v_u_9, (copy) v_u_380
					local v381 = v_u_9.shared.Assets
					if v381.hasImported("Prop", v_u_380) then
						return v381.template("Prop", v_u_380)
					else
						return nil
					end
				end
				local v383, v384 = pcall(v382)
				if not v383 or typeof(v384) ~= "Instance" then
					v384 = nil
				end
				v374.alarm = v384
				v373.templates = v374
				function v373.play(p385, p386) -- name: play
					-- upvalues: (ref) v_u_219
					v_u_219(p385, p386)
				end
				v_u_33 = v372(v373)
			end
			if v_u_17 ~= nil and v_u_18 == nil then
				local v387 = v_u_17.new
				local v388 = {
					["parent"] = workspace
				}
				local v_u_389 = "Pumpkin_S"
				local function v391()
					-- upvalues: (ref) v_u_9, (copy) v_u_389
					local v390 = v_u_9.shared.Assets
					if v390.hasImported("Prop", v_u_389) then
						return v390.template("Prop", v_u_389)
					else
						return nil
					end
				end
				local v392, v393 = pcall(v391)
				if not v392 or typeof(v393) ~= "Instance" then
					v393 = nil
				end
				v388.template = v393
				function v388.vis(p394) -- name: vis
					-- upvalues: (ref) v_u_9
					local v_u_395 = "Vision"
					local function v396()
						-- upvalues: (ref) v_u_9, (copy) v_u_395
						return v_u_9.controllers[v_u_395]
					end
					local v397, v398 = pcall(v396)
					if not v397 then
						v398 = nil
					end
					if v398 then
						local v399 = v398.visibility
						if type(v399) == "function" then
							local v400 = v398.visibility
							local v401, v402 = pcall(v400, p394)
							if v401 and type(v402) == "number" then
								return v402
							end
						end
					end
					return 1
				end
				function v388.play(p403) -- name: play
					-- upvalues: (ref) v_u_9
					local v_u_404 = "Audio"
					local function v405()
						-- upvalues: (ref) v_u_9, (copy) v_u_404
						return v_u_9.controllers[v_u_404]
					end
					local v406, v407 = pcall(v405)
					if not v406 then
						v407 = nil
					end
					local function v408()
						-- upvalues: (ref) v_u_9
						return v_u_9.shared.HuntSounds
					end
					local v409, v410 = pcall(v408)
					local function v411()
						-- upvalues: (ref) v_u_9
						return v_u_9.shared.Sounds
					end
					local v412, v413 = pcall(v411)
					local v414
					if v409 and (v412 and (v410 and v413)) then
						v414 = v410.nameFor(v413, "pumpkin")
					else
						v414 = nil
					end
					if v407 then
						local v415 = v407.play3D
						if type(v415) == "function" and v414 then
							local v416 = v407.play3D
							pcall(v416, v414, p403, {
								["volume"] = 1,
								["pitch"] = 1.1
							})
						end
					end
				end
				v_u_18 = v387(v388)
			end
			v_u_7._hud = v_u_45
		end
	end
end
v_u_307 = function()
	-- upvalues: (ref) v_u_41, (ref) v_u_45, (ref) v_u_24, (ref) v_u_46, (ref) v_u_47, (ref) v_u_51, (copy) v_u_417, (copy) v_u_40
	if v_u_41 and v_u_45 then
		local v418
		if v_u_24 == nil then
			v418 = nil
		else
			v418 = v_u_24.snapshot()
		end
		if v_u_24 ~= nil then
			v_u_24.destroy()
			v_u_24 = nil
		end
		v_u_45.destroy()
		v_u_45 = nil
		if v_u_46 then
			v_u_46.clear()
			v_u_46 = nil
		end
		for _, v419 in v_u_47 do
			v419:Destroy()
		end
		v_u_47 = {}
		v_u_51 = ""
		v_u_417()
		if v418 ~= nil and v_u_24 ~= nil then
			local v420 = v_u_24.restore
			local v421 = v_u_40
			pcall(v420, v418, v421)
		end
	end
end
local function v_u_442() -- name: teardown
	-- upvalues: (copy) v_u_306, (ref) v_u_24, (ref) v_u_23, (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_15, (ref) v_u_18, (ref) v_u_32, (ref) v_u_33, (ref) v_u_16, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_9, (ref) v_u_48, (copy) v_u_54, (copy) v_u_40, (ref) v_u_55, (ref) v_u_51, (ref) v_u_44, (copy) v_u_7
	v_u_306()
	if v_u_24 ~= nil then
		v_u_24.destroy()
		v_u_24 = nil
	end
	if v_u_23 ~= nil then
		local v422 = v_u_23.closeHunt
		pcall(v422)
	end
	if v_u_45 then
		v_u_45.destroy()
		v_u_45 = nil
	end
	if v_u_46 then
		v_u_46.clear()
		v_u_46 = nil
	end
	for _, v423 in v_u_47 do
		v423:Destroy()
	end
	v_u_47 = {}
	if v_u_15 then
		v_u_15.clear()
	end
	if v_u_18 ~= nil then
		v_u_18.destroy()
		v_u_18 = nil
	end
	if v_u_32 ~= nil then
		v_u_32.destroy()
		v_u_32 = nil
	end
	if v_u_33 ~= nil then
		v_u_33.destroy()
		v_u_33 = nil
	end
	if v_u_16 and v_u_16.setShadowBudget then
		local v424 = v_u_16.setShadowBudget
		pcall(v424, 1, 70)
	end
	if v_u_25 ~= nil then
		local v425 = v_u_25
		v_u_25 = nil
		local v426 = v425.close
		pcall(v426)
	end
	v_u_26 = nil
	v_u_27 = ""
	v_u_28 = false
	v_u_29 = false
	v_u_30 = 0
	v_u_31 = false
	local v_u_427 = "Input"
	local function v428()
		-- upvalues: (ref) v_u_9, (copy) v_u_427
		return v_u_9.controllers[v_u_427]
	end
	local v429, v430 = pcall(v428)
	if not v429 then
		v430 = nil
	end
	if v430 then
		local v431 = v430.setEnabled
		if type(v431) == "function" and v_u_48 then
			v_u_48 = false
			local v432 = v430.setEnabled
			pcall(v432, true)
		end
	end
	local v_u_433 = "Input"
	local function v434()
		-- upvalues: (ref) v_u_9, (copy) v_u_433
		return v_u_9.controllers[v_u_433]
	end
	local v435, v436 = pcall(v434)
	if not v435 then
		v436 = nil
	end
	if v436 then
		local v437 = v436.touch
		if type(v437) == "function" then
			local v438 = v436.touch
			local v439, v440 = pcall(v438)
			if v439 and v440 ~= nil then
				for _, v441 in v_u_54 do
					if not v441.Parent then
						continue
					end
					v441.Visible = true
				end
				table.clear(v_u_54)
			end
		end
	end
	table.clear(v_u_40)
	v_u_55 = nil
	v_u_51 = ""
	v_u_44 = nil
	v_u_7._hud = nil
end
local function v_u_446() -- name: activate
	-- upvalues: (ref) v_u_41, (ref) v_u_43, (copy) v_u_417, (ref) v_u_16, (ref) v_u_9, (ref) v_u_44
	v_u_41 = true
	v_u_43 = v_u_43 + 1
	local v_u_443 = v_u_43
	v_u_417()
	if v_u_16 and v_u_16.setShadowBudget then
		local v444 = v_u_16.setShadowBudget
		pcall(v444, 4, 70)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_9, (copy) v_u_443, (ref) v_u_43, (ref) v_u_41, (ref) v_u_44
		local v445 = v_u_9.session.waitForRaid(30)
		if v_u_443 == v_u_43 and v_u_41 then
			v_u_44 = v445
		end
	end)
end
function v_u_7.init(p_u_447) -- name: init
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_17, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_16, (ref) v_u_307, (copy) v_u_185, (copy) v_u_304, (copy) v_u_197, (copy) v_u_264, (ref) v_u_45, (ref) v_u_41, (ref) v_u_42, (copy) v_u_40, (copy) v_u_56, (ref) v_u_46, (ref) v_u_18, (ref) v_u_32, (ref) v_u_33, (ref) v_u_25, (copy) v_u_8, (ref) v_u_43, (copy) v_u_442, (copy) v_u_446, (copy) v_u_2, (copy) v_u_7, (copy) v_u_242, (ref) v_u_24
	v_u_9 = p_u_447
	v_u_10 = p_u_447.lib.HushUI
	local v448 = v_u_10.bind
	pcall(v448, p_u_447)
	v_u_11 = p_u_447.shared.Theme
	v_u_12 = p_u_447.shared.ModeNamesHalloween
	v_u_13 = p_u_447.lib.HuntHud
	v_u_14 = p_u_447.lib.HuntFx
	v_u_15 = p_u_447.lib.HuntRagdoll
	v_u_15._ctx = p_u_447
	local v449, v450 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.HuntPumpkinView
	end)
	if not v449 then
		v450 = nil
	end
	v_u_17 = v450
	local v451, v452 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.HuntTrackView
	end)
	if not v451 then
		v452 = nil
	end
	v_u_19 = v452
	local v453, v454 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.HuntTrapView
	end)
	if not v453 then
		v454 = nil
	end
	v_u_20 = v454
	local v455, v456 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.HuntHowTo
	end)
	if not v455 then
		v456 = nil
	end
	v_u_21 = v456
	local v457, v458 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.HuntKillCard
	end)
	if not v457 then
		v458 = nil
	end
	v_u_22 = v458
	local v459, v460 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.MenuReport
	end)
	if not v459 then
		v460 = nil
	end
	v_u_23 = v460
	local v461, v462 = pcall(function()
		-- upvalues: (copy) p_u_447
		return p_u_447.lib.WeatherFlashlight
	end)
	if not v461 then
		v462 = nil
	end
	v_u_16 = v462
	local v463 = p_u_447.on
	if type(v463) == "function" then
		p_u_447.on("ui.rebuild", function()
			-- upvalues: (ref) v_u_307
			v_u_307()
		end)
	end
	task.spawn(function()
		-- upvalues: (copy) p_u_447, (ref) v_u_185
		local v464 = p_u_447.net.listen
		local v465 = v_u_185
		pcall(v464, "hunt.state", v465)
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_447, (ref) v_u_304
		local v466 = p_u_447.net.listen
		local v467 = v_u_304
		pcall(v466, "hunt.fx", v467)
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_447, (ref) v_u_197
		local v468 = p_u_447.net.listen
		local v469 = v_u_197
		pcall(v468, "hunt.pk", v469)
	end)
	task.spawn(function()
		-- upvalues: (copy) p_u_447, (ref) v_u_264
		local v470 = p_u_447.net.listen
		local v471 = v_u_264
		pcall(v470, "hunt.tr", v471)
	end)
	p_u_447.command("huntclient.status", function()
		-- upvalues: (ref) v_u_15, (ref) v_u_45, (ref) v_u_16, (ref) v_u_41, (ref) v_u_42, (ref) v_u_40, (ref) v_u_56, (ref) v_u_46, (ref) v_u_18, (ref) v_u_32, (ref) v_u_33, (ref) v_u_25
		local v472 = v_u_15.stats()
		local v473 = {}
		for v474, v475 in not v_u_45 and {} or v_u_45.visible() do
			if not v475 then
				continue
			end
			table.insert(v473, v474)
		end
		table.sort(v473)
		local v476 = not (v_u_16 and v_u_16.shadowInfo) and {
			["budget"] = 0,
			["radius"] = 0,
			["others"] = 0
		} or v_u_16.shadowInfo()
		local v477 = "active=%s preview=%s phase=%s role=%s out=%s watching=%s cards=[%s] states=%d flings=%d pulses=%d | ragdoll sim=%d frozen=%d joints=%d path=%d impacts=%d | shadow budget=%d others=%d lights=%s marks=%d arrow=%s pumpkins=%d/%d prints=%d/%d traps=%d pings=%d tr=%d dazes=%d colas=%d loot=%s howto=%s"
		local v478 = v_u_41
		local v479 = tostring(v478)
		local v480 = v_u_42
		local v481 = tostring(v480)
		local v482 = v_u_40.phase
		local v483 = tostring(v482)
		local v484 = v_u_40.role
		local v485 = tostring(v484)
		local v486 = v_u_40.out ~= nil
		local v487 = tostring(v486)
		local v488 = v_u_40.watching
		local v489 = tostring(v488)
		local v490 = table.concat(v473, ",")
		local v491 = v_u_56.states
		local v492 = v_u_56.flings
		local v493 = v_u_56.pulses
		local v494 = v472.simulating
		local v495 = v472.frozen
		local v496 = v472.joints
		local v497 = v472.path
		local v498 = v472.impacts
		local v499 = v476.budget
		local v500 = v476.others
		local v501 = not (v_u_16 and v_u_16.count) and "?" or v_u_16.count()
		local v502 = tostring(v501)
		local v503 = not v_u_46 and 0 or v_u_46.marks()
		local v504
		if v_u_46 then
			v504 = v_u_46.arrowShown()
		else
			v504 = false
		end
		local v505 = tostring(v504)
		local v506 = not v_u_18 and 0 or v_u_18.count()
		local v507 = v_u_56.pk
		local v508 = not v_u_32 and 0 or v_u_32.shown()
		local v509 = not v_u_32 and 0 or v_u_32.count()
		local v510 = not v_u_33 and 0 or v_u_33.count()
		local v511 = not v_u_33 and 0 or v_u_33.pings()
		local v512 = v_u_56.tr
		local v513 = v_u_56.dazes
		local v514 = v_u_56.colas
		local v515 = v_u_40.loot
		local v516
		if type(v515) == "table" then
			local v517 = v_u_40.loot.melee
			v516 = ("%s/%d/%d/%d"):format(tostring(v517), v_u_40.loot.frag or 0, v_u_40.loot.flash or 0, v_u_40.loot.cola or 0)
		else
			v516 = "-"
		end
		local v518
		if v_u_25 == nil then
			v518 = "-"
		else
			local v519 = v_u_25.page
			v518 = tostring(v519())
		end
		return v477:format(v479, v481, v483, v485, v487, v489, v490, v491, v492, v493, v494, v495, v496, v497, v498, v499, v500, v502, v503, v505, v506, v507, v508, v509, v510, v511, v512, v513, v514, v516, v518)
	end)
	p_u_447.command("huntclient.ui", function(p520)
		-- upvalues: (ref) v_u_42, (ref) v_u_8, (ref) v_u_9, (ref) v_u_41, (ref) v_u_43, (ref) v_u_442, (ref) v_u_40, (ref) v_u_446, (ref) v_u_2, (ref) v_u_12, (ref) v_u_13
		local v521
		if type(p520) == "table" then
			local v522 = p520[1] or ""
			v521 = tostring(v522)
		else
			v521 = ""
		end
		if v521 == "off" or v521 == "" then
			v_u_42 = false
			local v523
			if v_u_8:GetAttribute("HuntPlayer") == true then
				local v524 = v_u_9.session.place
				local v525 = v_u_8
				local v526
				v523, v526 = pcall(v524, v525)
				if v523 then
					v523 = v526 == "Raid"
				end
			else
				v523 = false
			end
			if v523 then
				table.clear(v_u_40)
			else
				v_u_41 = false
				v_u_43 = v_u_43 + 1
				v_u_442()
			end
			return "preview off"
		end
		if not v_u_41 then
			v_u_42 = true
			v_u_446()
		end
		local v527 = os.clock()
		local function v528()
			-- upvalues: (ref) v_u_2
			return v_u_2.now()
		end
		local v529, v530 = pcall(v528)
		if not v529 or type(v530) ~= "number" then
			v530 = os.time()
		end
		table.clear(v_u_40)
		v_u_40.s0 = 9
		v_u_40.alive = 7
		v_u_40.stalkers = 1
		v_u_40.phase = "hunt"
		v_u_40.endsAt = v530 + 312
		if v521 == "wait" then
			v_u_40.phase = "wait"
			v_u_40.waitT = v_u_12.format(v_u_12.HUD.waiting, 4, 6)
		elseif v521 == "role_stalker" then
			v_u_40.role = "stalker"
			v_u_40.phase = "hide"
			v_u_40.endsAt = v530 + 20
			v_u_40.roleCard = {
				["t"] = nil,
				["sub"] = nil,
				["r"] = "stalker",
				["untilT"] = nil,
				["t"] = v_u_12.HUD.youStalker,
				["sub"] = v_u_12.HUD.youStalkerSub,
				["untilT"] = v527 + 60
			}
		elseif v521 == "role_survivor" then
			v_u_40.role = "survivor"
			v_u_40.phase = "hide"
			v_u_40.endsAt = v530 + 20
			local v531, v532 = v_u_13.splitRole(v_u_12.HUD.youSurvivor, nil)
			v_u_40.roleCard = {
				["t"] = nil,
				["sub"] = nil,
				["r"] = "survivor",
				["untilT"] = nil,
				["t"] = v531,
				["sub"] = v532,
				["untilT"] = v527 + 60
			}
		elseif v521 == "stalker" then
			v_u_40.role = "stalker"
			v_u_40.trap = {
				["bear"] = 2,
				["alarm"] = 2
			}
		elseif v521 == "hide_survivor" then
			v_u_40.role = "survivor"
			v_u_40.phase = "hide"
			v_u_40.endsAt = v530 + 17
		elseif v521 == "blind" then
			v_u_40.role = "stalker"
			v_u_40.phase = "hide"
			v_u_40.endsAt = v530 + 17
			v_u_40.blind = true
		elseif v521 == "hunt" then
			v_u_40.role = "survivor"
		elseif v521 == "loot" then
			v_u_40.role = "survivor"
			v_u_40.loot = {
				["melee"] = "melee_bat",
				["cola"] = 2,
				["frag"] = 1,
				["flash"] = 2,
				["sel"] = "throw_frag",
				["held"] = "melee"
			}
		elseif v521 == "payback" then
			v_u_40.role = "survivor"
			v_u_40.phase = "payback"
			v_u_40.endsAt = v530 + 150
			v_u_40.banner = {
				["t"] = nil,
				["kind"] = "danger",
				["untilT"] = nil,
				["t"] = v_u_12.HUD.payback,
				["untilT"] = v527 + 600
			}
		elseif v521 == "newstalker" then
			v_u_40.role = "survivor"
			v_u_40.banner = {
				["t"] = nil,
				["kind"] = "info",
				["untilT"] = nil,
				["t"] = v_u_12.HUD.newStalkerAll,
				["untilT"] = v527 + 600
			}
		elseif v521 == "out" then
			v_u_40.role = "survivor"
			v_u_40.out = {
				["t"] = v_u_12.HUD.out,
				["sub"] = v_u_12.HUD.outSub
			}
			v_u_40.watching = "Survivor_Mara"
		elseif v521 == "win" or (v521 == "lose" or (v521 == "early" or (v521 == "stalkerwin" or v521 == "plain"))) then
			local v533 = v521 == "stalkerwin"
			local v534 = v521 == "win" and true or v533
			local v535
			if v521 == "early" then
				v535 = false
			else
				v535 = v521 ~= "plain"
			end
			v_u_40.role = v533 and "stalker" or "survivor"
			local v536 = v_u_40
			local v537 = {
				["t"] = nil,
				["role"] = nil,
				["won"] = nil,
				["titles"] = nil,
				["sec"] = 15,
				["at"] = nil,
				["eligible"] = nil,
				["pk"] = nil,
				["rewards"] = nil,
				["crates"] = nil,
				["prog"] = nil,
				["survived"] = nil,
				["outAfter"] = nil
			}
			local v538
			if v521 == "early" then
				v538 = v_u_12.RESULT.walkover_survivors_gone
			elseif v521 == "win" or v521 == "plain" then
				v538 = v_u_12.RESULT.survivors_killed_stalkers
			else
				v538 = v_u_12.RESULT.stalker_all_out
			end
			v537.t = v538
			v537.role = v_u_40.role
			v537.won = v534
			v537.titles = v534 and v521 ~= "plain" and { v_u_12.TITLES.pumpkin_picker, v_u_12.TITLES.hunt_survivor } or {}
			v537.at = v527
			v537.eligible = v521 ~= "early"
			v537.pk = v535 and {
				["picked"] = nil,
				["catches"] = nil,
				["bonus"] = nil,
				["win"] = nil,
				["total"] = 86,
				["round"] = nil,
				["picked"] = v533 and 0 or 4,
				["catches"] = v533 and 2 or 0,
				["bonus"] = v534 and 7 or 2,
				["win"] = v534,
				["round"] = v533 and 13 or (v534 and 11 or 6)
			} or nil
			v537.rewards = v534 and v535 and { v_u_12.REWARD.pk15, v_u_12.REWARD.pk40 } or {}
			v537.crates = v535 and 1 or 0
			v537.prog = v535 and {
				["pumpkins"] = 86,
				["played"] = 12,
				["winsS"] = 5,
				["winsK"] = 1,
				["nextId"] = "pk140",
				["nextAt"] = 140,
				["toNext"] = 54,
				["crateIn"] = 10,
				["crates"] = 7,
				["steps"] = 4,
				["stepsTotal"] = 7
			} or nil
			v537.survived = v533 and 180 or (v521 == "lose" and 134 or (v535 and 192 or nil))
			v537.outAfter = v521 == "lose"
			v536.result = v537
		else
			if v521 ~= "home" then
				return "states: wait role_stalker role_survivor hide_survivor blind hunt loot stalker payback newstalker out win lose early stalkerwin plain home off"
			end
			v_u_40.home = {
				["t"] = v_u_12.HOME.notEnough
			}
		end
		return "preview " .. v521
	end)
	p_u_447.command("huntclient.howto", function(p539)
		-- upvalues: (ref) v_u_25, (ref) v_u_7, (ref) v_u_21, (ref) v_u_41, (ref) v_u_42, (ref) v_u_446, (ref) v_u_242
		local v540
		if type(p539) == "table" then
			local v541 = p539[1] or ""
			v540 = tostring(v541)
		else
			v540 = ""
		end
		if v540 == "close" then
			if v_u_25 ~= nil then
				local v542 = v_u_25
				v_u_25 = nil
				local v543 = v542.close
				pcall(v543)
			end
			return "how to play closed"
		end
		if v540 == "open" then
			local v544 = v_u_7.isOpen
			return "how to play open=" .. tostring(v544())
		end
		if v_u_21 == nil then
			return "no HuntHowTo"
		end
		if not v_u_41 then
			v_u_42 = true
			v_u_446()
		end
		v_u_242(tonumber(v540) or 1)
		local v545
		if v_u_25 == nil then
			v545 = nil
		else
			v545 = v_u_25.info()
		end
		if v545 == nil then
			return "not opened"
		end
		local v546 = v545.page
		local v547 = v545.count
		local v548 = v545.mode
		local v549 = v545.title
		local v550 = tostring(v549)
		local v551 = v545.photo
		local v552 = tostring(v551)
		local v553 = v545.photoShown
		return ("how to play page %d of %d mode=%s title=[%s] picture=[%s] shown=%s sign=%d"):format(v546, v547, v548, v550, v552, tostring(v553), v545.signShapes)
	end)
	p_u_447.command("huntclient.killcard", function(p554)
		-- upvalues: (ref) v_u_24, (ref) v_u_41, (ref) v_u_42, (ref) v_u_446, (ref) v_u_40, (ref) v_u_2, (ref) v_u_12, (ref) v_u_22, (ref) v_u_8
		local v555 = type(p554) ~= "table" and {} or p554
		local v556 = v555[1] or ""
		local v557 = tostring(v556)
		if v557 ~= "state" and v557 ~= "" then
			if v557 == "close" or v557 == "continue" then
				if v_u_24 ~= nil then
					local v558 = v_u_24.close
					pcall(v558, "command")
				end
				return "kill card closed"
			end
			if v557 == "report" then
				if v_u_24 == nil then
					return "no kill card"
				end
				local v559 = v_u_24.pressReport
				return "report pressed: " .. tostring(v559())
			end
			local v560 = tonumber(v557)
			if v560 == nil or v560 <= 0 then
				return "usage: huntclient.killcard <userId> <name> [display] [fake] | close | continue | report | state"
			end
			if not v_u_41 then
				v_u_42 = true
				v_u_446()
			end
			if v_u_24 == nil then
				return "no kill card (no hunt hud)"
			end
			if v_u_40.out == nil and v_u_40.result == nil then
				local function v561()
					-- upvalues: (ref) v_u_2
					return v_u_2.now()
				end
				local v562, v563 = pcall(v561)
				if not v562 or type(v563) ~= "number" then
					v563 = os.time()
				end
				table.clear(v_u_40)
				local v564 = v_u_40
				local v565 = v_u_40
				local v566 = v_u_40
				local v567 = v_u_40
				local v568 = v_u_40
				local v569 = v_u_40
				local v570 = v563 + 312
				v564.s0 = 9
				v565.alive = 7
				v566.stalkers = 1
				v567.phase = "hunt"
				v568.endsAt = v570
				v569.role = "survivor"
				v_u_40.out = {
					["t"] = v_u_12.HUD.out,
					["sub"] = v_u_12.HUD.outSub
				}
				v_u_40.watching = "Survivor_Mara"
			end
			local v571 = v555[2] or ""
			local v572 = tostring(v571)
			local v573 = {
				["k"] = "out",
				["kb"] = nil
			}
			local v574 = {
				["u"] = nil,
				["n"] = nil,
				["d"] = nil,
				["r"] = "stalker",
				["f"] = nil,
				["u"] = v560,
				["n"] = v572
			}
			local v575 = v555[3] or v572
			v574.d = tostring(v575)
			v574.f = v555[4] == "fake" and true or v560 >= 9000000000
			v573.kb = v574
			if v_u_24 ~= nil and v_u_22 ~= nil then
				local v576 = v_u_22.model(v573, v_u_8.UserId)
				if v576 ~= nil then
					local v577 = v_u_24.show
					local v578 = v_u_40
					pcall(v577, v576, v578)
				end
			end
			return v_u_24.isOpen() and "kill card shown" or "no card (own id?)"
		end
		if v_u_24 == nil then
			return "no kill card (huntclient.killcard <userId> <name> [display] first)"
		end
		local v579 = v_u_24.state()
		local v580 = v579.card
		local v581 = v579.open
		local v582 = tostring(v581)
		local v583 = v579.hidden
		local v584 = tostring(v583)
		local v585 = v579.visible
		local v586 = tostring(v585)
		local v587 = v579.mode
		local v588 = tostring(v587)
		local v589 = v579.uid
		local v590 = tostring(v589)
		local v591 = v579.display
		local v592 = tostring(v591)
		local v593 = v579.user
		local v594 = tostring(v593)
		local v595 = v579.initial
		local v596 = tostring(v595)
		local v597 = v579.imageShown
		local v598 = tostring(v597)
		local v599 = v579.left
		local v600 = v579.kept
		local v601 = tostring(v600)
		local v602 = v579.centerLeft
		local v603 = tostring(v602)
		local v604 = v579.closedBy
		local v605 = tostring(v604)
		local v606 = v579.shown
		local v607 = v579.reportVisible
		return ("open=%s hidden=%s visible=%s mode=%s uid=%s display=[%s] user=[%s] initial=[%s] imageShown=%s left=%.1f kept=%s centerLeft=%s closedBy=%s shown=%d report=%s card=%s"):format(v582, v584, v586, v588, v590, v592, v594, v596, v598, v599, v601, v603, v605, v606, tostring(v607), v580 == nil and "-" or ("%.0fx%.0f at %.0f,%.0f"):format(v580.x1 - v580.x0, v580.y1 - v580.y0, v580.x0, v580.y0))
	end)
	p_u_447.command("huntclient.fling", function(p608)
		-- upvalues: (ref) v_u_8, (ref) v_u_41, (ref) v_u_15, (ref) v_u_9
		local v609
		if type(p608) == "table" then
			v609 = p608[1]
		else
			v609 = nil
		end
		local v610 = tonumber(v609) or 0.8
		local v611
		if type(p608) == "table" then
			v611 = p608[2]
		else
			v611 = nil
		end
		local v612 = {
			["kind"] = "fling",
			["dir"] = Vector3.new(0, 0, -1),
			["power"] = nil,
			["power"] = v610
		}
		if type(v611) == "string" and v611 ~= "" then
			v612.dummy = v611
		else
			v612.uid = v_u_8.UserId
		end
		local v613 = v_u_41
		v_u_41 = true
		local v614 = v_u_15.fling
		local v_u_615 = "Atmosphere"
		local function v616()
			-- upvalues: (ref) v_u_9, (copy) v_u_615
			return v_u_9.controllers[v_u_615]
		end
		local v617, v618 = pcall(v616)
		if not v617 then
			v618 = nil
		end
		local v619
		if v618 and v618.quality then
			local v620 = v618.quality
			local v621, v622 = pcall(v620)
			v619 = (not v621 or type(v622) ~= "number") and 3 or v622
		else
			v619 = 3
		end
		local v623 = v614(v612, v619)
		v_u_41 = v613
		return "fling " .. tostring(v623)
	end)
	p_u_447.command("huntclient.pulse", function(p624)
		-- upvalues: (ref) v_u_46, (ref) v_u_8
		if not v_u_46 then
			return "no hunt hud (huntclient.ui hunt first)"
		end
		local v625 = v_u_8.Character
		if v625 then
			v625 = v625:FindFirstChild("HumanoidRootPart")
		end
		if not v625 then
			return "no character"
		end
		local v626
		if type(p624) == "table" then
			v626 = p624[1]
		else
			v626 = nil
		end
		local v627 = tonumber(v626) or 3
		v_u_46.pulse(v625.Position + Vector3.new(60, 0, 40), v627)
		return "pulse " .. tostring(v627)
	end)
	p_u_447.command("huntclient.mark", function(p628)
		-- upvalues: (ref) v_u_46, (ref) v_u_8
		if not v_u_46 then
			return "no hunt hud (huntclient.ui hunt first)"
		end
		local v629
		if type(p628) == "table" then
			v629 = p628[1] == "off"
		else
			v629 = false
		end
		local v630 = not v629
		v_u_46.selfMarks = v630
		v_u_8:SetAttribute("HuntTeam", v630 and "K" or nil)
		return "stalker mark test " .. (v630 and "on" or "off")
	end)
	p_u_447.command("huntclient.pk", function(p631)
		-- upvalues: (ref) v_u_41, (ref) v_u_18, (ref) v_u_197, (ref) v_u_8, (ref) v_u_40
		if not v_u_41 or v_u_18 == nil then
			return "no hunt hud (huntclient.ui hunt first)"
		end
		local v632
		if type(p631) == "table" then
			v632 = p631[1]
		else
			v632 = nil
		end
		if v632 == "clear" then
			v_u_197({
				["list"] = nil,
				["n"] = 0,
				["list"] = {}
			})
			return "pumpkins cleared"
		end
		local v633 = v_u_8.Character
		if v633 then
			v633 = v633:FindFirstChild("HumanoidRootPart")
		end
		if not v633 then
			return "no character"
		end
		local v634 = tonumber(v632) or 3
		local v635 = math.floor(v634)
		local v636 = math.clamp(v635, 1, 8)
		local v637 = {}
		for v638 = 1, v636 do
			local v639 = v638 / v636 * 3.141592653589793 * 2
			local v640 = {
				["i"] = v638 + 900,
				["x"] = v633.Position.X + math.cos(v639) * 10,
				["y"] = v633.Position.Y - 1.4,
				["z"] = v633.Position.Z + math.sin(v639) * 10
			}
			table.insert(v637, v640)
		end
		local v641 = v_u_40.pk and v_u_40.pk.n or 0
		v_u_197({
			["list"] = v637,
			["n"] = v641 + 1,
			["t"] = 120 + v641,
			["got"] = {
				["x"] = v633.Position.X,
				["y"] = v633.Position.Y - 1.4,
				["z"] = v633.Position.Z
			}
		})
		return ("pumpkins: %d"):format(v_u_18.count())
	end)
	p_u_447.command("huntclient.reset", function()
		-- upvalues: (ref) v_u_42, (ref) v_u_41, (ref) v_u_43, (ref) v_u_442
		v_u_42 = false
		v_u_41 = false
		v_u_43 = v_u_43 + 1
		v_u_442()
		return "reset"
	end)
end
function v_u_7.start() -- name: start end
function v_u_7.step(p642) -- name: step
	-- upvalues: (ref) v_u_49, (copy) v_u_8, (ref) v_u_9, (ref) v_u_41, (ref) v_u_42, (copy) v_u_446, (ref) v_u_43, (copy) v_u_442, (ref) v_u_45, (ref) v_u_11, (copy) v_u_104, (copy) v_u_40, (copy) v_u_2, (ref) v_u_13, (ref) v_u_44, (ref) v_u_12, (copy) v_u_4, (copy) v_u_225, (ref) v_u_25, (ref) v_u_21, (ref) v_u_26, (ref) v_u_28, (copy) v_u_242, (ref) v_u_31, (ref) v_u_48, (ref) v_u_50, (copy) v_u_90, (ref) v_u_39, (ref) v_u_24, (ref) v_u_46, (ref) v_u_15, (ref) v_u_18, (ref) v_u_32, (ref) v_u_33, (ref) v_u_10, (ref) v_u_52, (ref) v_u_51, (copy) v_u_5
	v_u_49 = v_u_49 + p642
	if v_u_49 >= 0.25 then
		v_u_49 = 0
		local v643
		if v_u_8:GetAttribute("HuntPlayer") == true then
			local v644 = v_u_9.session.place
			local v645 = v_u_8
			local v646
			v643, v646 = pcall(v644, v645)
			if v643 then
				v643 = v646 == "Raid"
			end
		else
			v643 = false
		end
		if v643 and not v_u_41 then
			v_u_42 = false
			v_u_446()
		elseif not v643 and (v_u_41 and not v_u_42) then
			v_u_41 = false
			v_u_43 = v_u_43 + 1
			v_u_442()
		end
	end
	if v_u_41 and v_u_45 then
		if v_u_49 == 0 and v_u_11.isTouch() then
			v_u_104(true)
		end
		local v647 = os.clock()
		local v648 = v_u_40
		local function v649()
			-- upvalues: (ref) v_u_2
			return v_u_2.now()
		end
		local v650, v651 = pcall(v649)
		if not v650 or type(v651) ~= "number" then
			v651 = os.time()
		end
		v648.now = v651
		if v_u_40.huntSec == nil then
			local function v652()
				-- upvalues: (ref) v_u_9
				return v_u_9.shared.HuntRules.HUNT_SEC
			end
			local v653, v654 = pcall(v652)
			local v655 = v_u_40
			if not v653 or type(v654) ~= "number" then
				v654 = v_u_13.HUNT_SEC
			end
			v655.huntSec = v654
		end
		local v656 = v_u_44
		if v656 and (v656.Parent and not v_u_42) then
			local v657 = v656:GetAttribute("HuntPhase")
			if type(v657) == "string" and v657 ~= "" then
				v_u_40.phase = v657
			end
			local v658 = v656:GetAttribute("HuntEndsAt")
			if type(v658) == "number" and v658 > 0 then
				v_u_40.endsAt = v658
			end
			local v659 = v656:GetAttribute("HuntAlive")
			if type(v659) == "number" then
				v_u_40.alive = v659
			end
			local v660 = v656:GetAttribute("HuntStalkers")
			if type(v660) == "number" then
				v_u_40.stalkers = v660
			end
		end
		if not v_u_42 then
			if v_u_8:GetAttribute("HuntStatus") == "Out" and (v_u_40.out == nil and (v_u_40.result == nil and v_u_40.home == nil)) then
				v_u_40.out = {
					["t"] = v_u_12.HUD.out,
					["sub"] = v_u_12.HUD.outSub
				}
			end
			local v661 = v_u_40
			local v662
			if v_u_40.role == "stalker" and (v_u_40.phase == "hide" and v_u_40.out == nil) then
				v662 = v_u_40.result == nil
			else
				v662 = false
			end
			v661.blind = v662
			if v_u_40.phase == "wait" and (not v_u_4:IsStudio() or v_u_8:GetAttribute("HuntHowToAuto") == true) then
				v_u_225()
				if v_u_25 == nil and v_u_21 ~= nil and v_u_21.autoInHunt({
					["seen"] = v_u_26,
					["shown"] = v_u_28,
					["phase"] = v_u_40.phase,
					["out"] = v_u_40.out ~= nil,
					["result"] = v_u_40.result ~= nil,
					["home"] = v_u_40.home ~= nil
				}) then
					v_u_242(1, true)
				end
			end
		end
		if v_u_25 ~= nil and (v_u_31 and v_u_40.phase ~= "wait" or (v_u_40.phase == "hunt" or (v_u_40.phase == "payback" or (v_u_40.out ~= nil or (v_u_40.result ~= nil or (v_u_40.home ~= nil or v_u_40.blind == true)))))) and v_u_25 ~= nil then
			local v663 = v_u_25
			v_u_25 = nil
			local v664 = v663.close
			pcall(v664)
		end
		if v_u_40.out ~= nil and v_u_40.result == nil then
			local v_u_665 = "Input"
			local function v666()
				-- upvalues: (ref) v_u_9, (copy) v_u_665
				return v_u_9.controllers[v_u_665]
			end
			local v667, v668 = pcall(v666)
			if not v667 then
				v668 = nil
			end
			if v668 then
				local v669 = v668.setEnabled
				if type(v669) == "function" then
					local v670 = v_u_11
					if v670 then
						local v671 = v_u_11.isTouch
						if type(v671) == "function" then
							v670 = v_u_11.isTouch()
						else
							v670 = false
						end
					end
					if v670 and not v_u_48 then
						v_u_48 = true
						local v672 = v668.setEnabled
						pcall(v672, false)
					end
				end
			end
			v_u_50 = v_u_50 + p642
			if v_u_50 >= 0.3 then
				v_u_50 = 0
				v_u_90()
			end
		end
		local v673 = v_u_8.Character
		local v674 = v_u_40.loot
		if type(v674) == "table" then
			local v675 = v_u_40.loot
			local v676
			if v673 == nil then
				v676 = nil
			else
				v676 = v673:GetAttribute("ThrowableList")
			end
			local v677 = 0
			local v678 = 0
			if type(v676) == "string" then
				for v679, v680 in string.gmatch(v676, "([%w_]+):(%d+)") do
					if v679 == "throw_frag" then
						v677 = tonumber(v680) or 0
					else
						if v679 ~= "throw_flash" then
							continue
						end
						v678 = tonumber(v680) or 0
					end
				end
			end
			v675.frag = v677
			v675.flash = v678
			local v681
			if v673 == nil then
				v681 = nil
			else
				v681 = v673:GetAttribute("Throwable")
			end
			if type(v681) ~= "string" then
				v681 = nil
			end
			v675.sel = v681
			local v682
			if v673 == nil then
				v682 = nil
			else
				v682 = v673:GetAttribute("WeaponSlot")
			end
			if type(v682) ~= "string" then
				v682 = nil
			end
			v675.held = v682
		elseif v_u_40.role == "survivor" then
			local v683
			if v673 == nil then
				v683 = nil
			else
				v683 = v673:GetAttribute("ThrowableList")
			end
			if type(v683) == "string" then
				local v684
				if v673 == nil then
					v684 = nil
				else
					v684 = v673:GetAttribute("ThrowableList")
				end
				if v684 ~= "" then
					v_u_40.loot = {
						["melee"] = "",
						["cola"] = 0,
						["frag"] = 0,
						["flash"] = 0
					}
				end
			end
		end
		if v_u_40.role == "stalker" and v647 - v_u_39 >= 0.5 then
			v_u_39 = v647
			for _, v685 in game:GetService("CollectionService"):GetTagged("HuntCache") do
				if not (v685:IsA("ProximityPrompt") and v685.Enabled) then
					continue
				end
				v685.Enabled = false
			end
		end
		v_u_45.render(v_u_40, v647)
		if v_u_24 ~= nil then
			v_u_24.step(v647, v_u_40)
		end
		if v_u_46 then
			v_u_46.step(p642)
		end
		if v_u_15 then
			v_u_15.step(p642)
		end
		if v_u_18 ~= nil then
			v_u_18.step(p642)
		end
		if v_u_32 ~= nil then
			v_u_32.step(p642)
		end
		if v_u_33 ~= nil then
			v_u_33.step(p642)
		end
		local v686 = v_u_45.focusTargets()
		local v_u_687
		if v_u_24 == nil then
			v_u_687 = v686
		else
			local v688 = v_u_24.focusTargets()
			if #v688 > 0 then
				v_u_687 = {}
				for _, v689 in v688 do
					table.insert(v_u_687, v689)
				end
				for _, v690 in v686 do
					table.insert(v_u_687, v690)
				end
			else
				v_u_687 = v686
			end
		end
		local v691 = ""
		for _, v692 in v_u_687 do
			v691 = v691 .. v692.Name .. ","
		end
		local v693
		if v_u_10.device == nil then
			v693 = false
		else
			v693 = v_u_10.device() == "Gamepad"
		end
		local v694
		if v693 then
			v694 = not v_u_52
		else
			v694 = v693
		end
		v_u_52 = v693
		if v691 ~= v_u_51 or v694 then
			v_u_51 = v691
			if #v_u_687 > 0 and v693 then
				local v695 = v_u_10.modalCount
				if type(v695) ~= "function" or v_u_10.modalCount() == 0 then
					local function v696()
						-- upvalues: (ref) v_u_5, (ref) v_u_687
						v_u_5.SelectedObject = v_u_687[1]
					end
					pcall(v696)
				end
			end
		end
	end
end
function v_u_7.state() -- name: state
	-- upvalues: (copy) v_u_40
	return v_u_40
end
function v_u_7.hud() -- name: hud
	-- upvalues: (ref) v_u_45
	return v_u_45
end
function v_u_7.isActive() -- name: isActive
	-- upvalues: (ref) v_u_41
	return v_u_41
end
function v_u_7.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_21
	if v_u_21 ~= nil then
		local v697 = v_u_21.active
		if type(v697) == "function" then
			local v698 = v_u_21.active
			local v699, v700 = pcall(v698)
			if v699 then
				v699 = v700 ~= nil
			end
			return v699
		end
	end
	return false
end
function v_u_7._onState(p701) -- name: _onState
	-- upvalues: (copy) v_u_185
	v_u_185(p701)
end
function v_u_7._onFx(p702) -- name: _onFx
	-- upvalues: (copy) v_u_304
	v_u_304(p702)
end
function v_u_7._onPk(p703) -- name: _onPk
	-- upvalues: (copy) v_u_197
	v_u_197(p703)
end
function v_u_7._onTr(p704) -- name: _onTr
	-- upvalues: (copy) v_u_264
	v_u_264(p704)
end
function v_u_7._placeTrap(p705) -- name: _placeTrap
	-- upvalues: (copy) v_u_269
	v_u_269(p705)
end
function v_u_7._useCola() -- name: _useCola
	-- upvalues: (copy) v_u_274
	v_u_274()
end
function v_u_7._onLoot(p706) -- name: _onLoot
	-- upvalues: (copy) v_u_285
	v_u_285(p706)
end
function v_u_7.tracks() -- name: tracks
	-- upvalues: (ref) v_u_32
	return v_u_32
end
function v_u_7.traps() -- name: traps
	-- upvalues: (ref) v_u_33
	return v_u_33
end
function v_u_7.pumpkins() -- name: pumpkins
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v_u_7.killCard() -- name: killCard
	-- upvalues: (ref) v_u_24
	return v_u_24
end
return v_u_7