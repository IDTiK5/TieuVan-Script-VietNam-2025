-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimMelee

local v_u_1 = {}
local v_u_2 = math.rad
local v3 = {
	["stab"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.55,
				["x"] = 0.12,
				["y"] = -0.8,
				["z"] = 0.12,
				["yaw"] = -39,
				["pitch"] = 18,
				["roll"] = 0,
				["ty"] = -0.36,
				["tp"] = 0.02,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.82,
				["x"] = -0.28,
				["y"] = -0.75,
				["z"] = -0.58,
				["yaw"] = -6,
				["pitch"] = 8,
				["roll"] = 0,
				["ty"] = 0.05,
				["tp"] = 0.05,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -0.5,
				["y"] = -0.58,
				["z"] = -1.18,
				["yaw"] = 8,
				["pitch"] = 4,
				["roll"] = 0,
				["ty"] = 0.32,
				["tp"] = 0.08,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.22,
				["x"] = -0.56,
				["y"] = -0.62,
				["z"] = -1.3,
				["yaw"] = 10,
				["pitch"] = 2,
				["roll"] = 0,
				["ty"] = 0.36,
				["tp"] = 0.08,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.6,
				["x"] = -0.3,
				["y"] = -0.85,
				["z"] = -0.85,
				["yaw"] = 0,
				["pitch"] = 20,
				["roll"] = 0,
				["ty"] = 0.12,
				["tp"] = 0.03,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	},
	["slash"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.62,
				["x"] = 0.36,
				["y"] = 0.3,
				["z"] = 0.12,
				["yaw"] = -30,
				["pitch"] = 62,
				["roll"] = -70,
				["ty"] = -0.4,
				["tp"] = -0.04,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.86,
				["x"] = -0.12,
				["y"] = -0.15,
				["z"] = -0.72,
				["yaw"] = 38,
				["pitch"] = 20,
				["roll"] = -30,
				["ty"] = 0.05,
				["tp"] = 0.06,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -0.62,
				["y"] = -0.58,
				["z"] = -1.05,
				["yaw"] = 78,
				["pitch"] = -8,
				["roll"] = 0,
				["ty"] = 0.45,
				["tp"] = 0.1,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.25,
				["x"] = -0.88,
				["y"] = -0.8,
				["z"] = -0.95,
				["yaw"] = 100,
				["pitch"] = -14,
				["roll"] = 8,
				["ty"] = 0.55,
				["tp"] = 0.1,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.62,
				["x"] = -0.5,
				["y"] = -0.95,
				["z"] = -0.65,
				["yaw"] = 40,
				["pitch"] = 8,
				["roll"] = 4,
				["ty"] = 0.2,
				["tp"] = 0.04,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	},
	["side"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.6,
				["x"] = 0.42,
				["y"] = -0.3,
				["z"] = 0.1,
				["yaw"] = -42,
				["pitch"] = 18,
				["roll"] = -40,
				["ty"] = -0.38,
				["tp"] = 0,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.85,
				["x"] = 0,
				["y"] = -0.38,
				["z"] = -0.62,
				["yaw"] = 20,
				["pitch"] = 6,
				["roll"] = -10,
				["ty"] = 0.05,
				["tp"] = 0.02,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -0.62,
				["y"] = -0.42,
				["z"] = -1,
				["yaw"] = 74,
				["pitch"] = 0,
				["roll"] = 0,
				["ty"] = 0.42,
				["tp"] = 0.04,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.25,
				["x"] = -0.86,
				["y"] = -0.52,
				["z"] = -0.9,
				["yaw"] = 96,
				["pitch"] = -2,
				["roll"] = 4,
				["ty"] = 0.5,
				["tp"] = 0.04,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.62,
				["x"] = -0.48,
				["y"] = -0.85,
				["z"] = -0.6,
				["yaw"] = 38,
				["pitch"] = 14,
				["roll"] = 2,
				["ty"] = 0.18,
				["tp"] = 0.02,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	},
	["overhead"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.66,
				["x"] = 0.3,
				["y"] = 0.55,
				["z"] = 0.38,
				["yaw"] = -12,
				["pitch"] = 84,
				["roll"] = 0,
				["ty"] = -0.18,
				["tp"] = -0.08,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.88,
				["x"] = -0.1,
				["y"] = 0.2,
				["z"] = -0.42,
				["yaw"] = 4,
				["pitch"] = 50,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0.06,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -0.38,
				["y"] = -0.38,
				["z"] = -1.08,
				["yaw"] = 8,
				["pitch"] = -26,
				["roll"] = 0,
				["ty"] = 0.14,
				["tp"] = 0.18,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.25,
				["x"] = -0.4,
				["y"] = -0.55,
				["z"] = -1.12,
				["yaw"] = 8,
				["pitch"] = -40,
				["roll"] = 0,
				["ty"] = 0.14,
				["tp"] = 0.2,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.62,
				["x"] = -0.25,
				["y"] = -0.85,
				["z"] = -0.7,
				["yaw"] = 2,
				["pitch"] = 6,
				["roll"] = 0,
				["ty"] = 0.06,
				["tp"] = 0.08,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.1,
				["y"] = -1.05,
				["z"] = -0.4,
				["yaw"] = -6,
				["pitch"] = 34,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	},
	["swing2h"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.45,
				["y"] = -1.22,
				["z"] = -0.68,
				["yaw"] = 16,
				["pitch"] = 64,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.62,
				["x"] = -0.85,
				["y"] = -0.3,
				["z"] = -0.95,
				["yaw"] = -78,
				["pitch"] = 40,
				["roll"] = -15,
				["ty"] = -0.6,
				["tp"] = -0.02,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.86,
				["x"] = -0.9,
				["y"] = -0.35,
				["z"] = -1,
				["yaw"] = -10,
				["pitch"] = 8,
				["roll"] = -5,
				["ty"] = -0.1,
				["tp"] = 0.02,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -1,
				["y"] = -0.4,
				["z"] = -1.05,
				["yaw"] = 45,
				["pitch"] = 0,
				["roll"] = 0,
				["ty"] = 0.35,
				["tp"] = 0.04,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.28,
				["x"] = -1.05,
				["y"] = -0.45,
				["z"] = -0.95,
				["yaw"] = 105,
				["pitch"] = -2,
				["roll"] = 0,
				["ty"] = 0.6,
				["tp"] = 0.04,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.66,
				["x"] = -0.8,
				["y"] = -0.85,
				["z"] = -0.8,
				["yaw"] = 55,
				["pitch"] = 28,
				["roll"] = 0,
				["ty"] = 0.25,
				["tp"] = 0.02,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.45,
				["y"] = -1.22,
				["z"] = -0.68,
				["yaw"] = 16,
				["pitch"] = 64,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	},
	["chop2h"] = {
		["keys"] = {
			{
				["ph"] = "W",
				["f"] = 0,
				["x"] = -0.45,
				["y"] = -1.22,
				["z"] = -0.68,
				["yaw"] = 16,
				["pitch"] = 64,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 0.7,
				["x"] = -0.85,
				["y"] = 0.15,
				["z"] = -1.1,
				["yaw"] = 0,
				["pitch"] = 88,
				["roll"] = 0,
				["ty"] = -0.12,
				["tp"] = -0.1,
				["hold"] = true
			},
			{
				["ph"] = "W",
				["f"] = 0.9,
				["x"] = -0.9,
				["y"] = -0.05,
				["z"] = -1.25,
				["yaw"] = 0,
				["pitch"] = 50,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0.06,
				["hold"] = nil
			},
			{
				["ph"] = "W",
				["f"] = 1,
				["x"] = -0.95,
				["y"] = -0.45,
				["z"] = -1.25,
				["yaw"] = 0,
				["pitch"] = -25,
				["roll"] = 0,
				["ty"] = 0.1,
				["tp"] = 0.26,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.28,
				["x"] = -0.95,
				["y"] = -0.7,
				["z"] = -1.15,
				["yaw"] = 0,
				["pitch"] = -45,
				["roll"] = 0,
				["ty"] = 0.1,
				["tp"] = 0.28,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 0.66,
				["x"] = -0.85,
				["y"] = -0.95,
				["z"] = -0.9,
				["yaw"] = 8,
				["pitch"] = 20,
				["roll"] = 0,
				["ty"] = 0.05,
				["tp"] = 0.1,
				["hold"] = nil
			},
			{
				["ph"] = "R",
				["f"] = 1,
				["x"] = -0.45,
				["y"] = -1.22,
				["z"] = -0.68,
				["yaw"] = 16,
				["pitch"] = 64,
				["roll"] = 0,
				["ty"] = 0,
				["tp"] = 0,
				["hold"] = true
			}
		}
	}
}
v_u_1.STYLES = v3
v_u_1.STYLES.shove = {
	["keys"] = {
		{
			["ph"] = "W",
			["f"] = 0,
			["x"] = -0.2,
			["y"] = -0.45,
			["z"] = -0.5,
			["yaw"] = 40,
			["pitch"] = 0,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "W",
			["f"] = 0.55,
			["x"] = -0.1,
			["y"] = -0.5,
			["z"] = -0.3,
			["yaw"] = 70,
			["pitch"] = 4,
			["roll"] = 0,
			["ty"] = -0.18,
			["tp"] = 0,
			["hold"] = true
		},
		{
			["ph"] = "W",
			["f"] = 0.85,
			["x"] = -0.2,
			["y"] = -0.45,
			["z"] = -0.7,
			["yaw"] = 78,
			["pitch"] = 2,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "W",
			["f"] = 1,
			["x"] = -0.4,
			["y"] = -0.4,
			["z"] = -1.25,
			["yaw"] = 82,
			["pitch"] = 0,
			["roll"] = 0,
			["ty"] = 0.25,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 0.25,
			["x"] = -0.42,
			["y"] = -0.4,
			["z"] = -1.3,
			["yaw"] = 82,
			["pitch"] = 0,
			["roll"] = 0,
			["ty"] = 0.25,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 0.65,
			["x"] = -0.25,
			["y"] = -0.45,
			["z"] = -0.8,
			["yaw"] = 50,
			["pitch"] = -4,
			["roll"] = 0,
			["ty"] = 0.1,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 1,
			["x"] = -0.2,
			["y"] = -0.45,
			["z"] = -0.5,
			["yaw"] = 40,
			["pitch"] = 0,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = true
		}
	}
}
v_u_1.STYLES.whip = {
	["keys"] = {
		{
			["ph"] = "W",
			["f"] = 0,
			["x"] = -0.5,
			["y"] = -0.7,
			["z"] = -0.9,
			["yaw"] = 4,
			["pitch"] = -20,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "W",
			["f"] = 0.55,
			["x"] = 0.2,
			["y"] = 0.15,
			["z"] = 0.15,
			["yaw"] = -8,
			["pitch"] = 70,
			["roll"] = 0,
			["ty"] = -0.25,
			["tp"] = 0,
			["hold"] = true
		},
		{
			["ph"] = "W",
			["f"] = 0.85,
			["x"] = -0.1,
			["y"] = 0,
			["z"] = -0.45,
			["yaw"] = 0,
			["pitch"] = 40,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "W",
			["f"] = 1,
			["x"] = -0.45,
			["y"] = -0.6,
			["z"] = -1.2,
			["yaw"] = 4,
			["pitch"] = -55,
			["roll"] = 0,
			["ty"] = 0.2,
			["tp"] = 0.08,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 0.25,
			["x"] = -0.45,
			["y"] = -0.7,
			["z"] = -1.25,
			["yaw"] = 4,
			["pitch"] = -65,
			["roll"] = 0,
			["ty"] = 0.2,
			["tp"] = 0.08,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 0.65,
			["x"] = -0.55,
			["y"] = -0.75,
			["z"] = -1,
			["yaw"] = 4,
			["pitch"] = -35,
			["roll"] = 0,
			["ty"] = 0.08,
			["tp"] = 0,
			["hold"] = nil
		},
		{
			["ph"] = "R",
			["f"] = 1,
			["x"] = -0.5,
			["y"] = -0.7,
			["z"] = -0.9,
			["yaw"] = 4,
			["pitch"] = -20,
			["roll"] = 0,
			["ty"] = 0,
			["tp"] = 0,
			["hold"] = true
		}
	}
}
function v_u_1.bashStyleOf(p4) -- name: bashStyleOf
	return (p4 == "pistol" or p4 == "revolver") and "whip" or "shove"
end
v_u_1.BASH_DUR = 0.5
function v_u_1.bashSample(p5, p6, p7, p_u_8) -- name: bashSample
	-- upvalues: (copy) v_u_1
	local v9 = 0.12
	local v10, v11 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.SHOVE.meleeWindup
	end)
	if v10 then
		if type(v11) ~= "number" then
			v11 = v9
		end
	else
		v11 = v9
	end
	return v_u_1.sample(v_u_1.bashStyleOf(p5), p6, v11, v_u_1.BASH_DUR, p7)
end
v_u_1.LEGACY_BY_ID = {
	["melee_knife"] = "stab",
	["melee_dagger"] = "stab",
	["melee_balisong"] = "stab",
	["melee_tactical"] = "stab",
	["melee_karambit"] = "slash",
	["melee_machete"] = "slash",
	["melee_baton"] = "side",
	["melee_crowbar"] = "overhead",
	["melee_nailbat"] = "swing2h",
	["melee_bat"] = "swing2h",
	["melee_axe"] = "chop2h",
	["melee_katana"] = "slash"
}
v_u_1.BY_ID = {
	["melee_knife"] = "knife",
	["melee_dagger"] = "dagger",
	["melee_balisong"] = "balisong",
	["melee_tactical"] = "tactical",
	["melee_karambit"] = "karambit",
	["melee_machete"] = "machete",
	["melee_baton"] = "baton",
	["melee_crowbar"] = "crowbar",
	["melee_nailbat"] = "nailbat",
	["melee_bat"] = "bat",
	["melee_axe"] = "axe",
	["melee_katana"] = "katana"
}
v_u_1.PARTS = {
	["knife"] = "MeleeAnimKnife",
	["dagger"] = "MeleeAnimDagger",
	["balisong"] = "MeleeAnimBalisong",
	["karambit"] = "MeleeAnimKarambit",
	["tactical"] = "MeleeAnimTactical",
	["machete"] = "MeleeAnimMachete",
	["baton"] = "MeleeAnimBaton",
	["crowbar"] = "MeleeAnimCrowbar",
	["bat"] = "MeleeAnimBat",
	["nailbat"] = "MeleeAnimNailbat",
	["axe"] = "MeleeAnimAxe",
	["katana"] = "MeleeAnimKatana"
}
local function v_u_26(p12) -- name: validKeys
	if type(p12) ~= "table" or #p12 < 3 then
		return false
	end
	local v13 = p12[1]
	local v14 = p12[#p12]
	if v13.ph ~= "W" or (v13.f ~= 0 or (v14.ph ~= "R" or v14.f ~= 1)) then
		return false
	end
	local v15 = -1
	local v16 = false
	for _, v17 in p12 do
		if v17.ph ~= "W" and v17.ph ~= "R" then
			return false
		end
		local v18 = v17.f
		if type(v18) ~= "number" then
			return false
		end
		local v19 = v17.x
		if type(v19) ~= "number" then
			return false
		end
		local v20 = v17.y
		if type(v20) ~= "number" then
			return false
		end
		local v21 = v17.z
		if type(v21) ~= "number" then
			return false
		end
		local v22 = v17.yaw
		if type(v22) ~= "number" then
			return false
		end
		local v23 = v17.pitch
		if type(v23) ~= "number" then
			return false
		end
		local v24 = v17.roll
		if type(v24) ~= "number" then
			return false
		end
		v16 = v17.ph == "W" and v17.f == 1 and true or v16
		local v25
		if v17.ph == "W" then
			v25 = v17.f
		else
			v25 = 1 + v17.f
		end
		if v25 < v15 then
			return false
		end
		v15 = v25
	end
	return v16
end
local function v_u_36(p27) -- name: validLeft
	if type(p27) ~= "table" or #p27 < 2 then
		return false
	end
	local v28 = -1
	for _, v29 in p27 do
		if v29.ph ~= "W" and v29.ph ~= "R" then
			return false
		end
		local v30 = v29.f
		if type(v30) ~= "number" then
			return false
		end
		local v31 = v29.x
		if type(v31) ~= "number" then
			return false
		end
		local v32 = v29.y
		if type(v32) ~= "number" then
			return false
		end
		local v33 = v29.z
		if type(v33) ~= "number" then
			return false
		end
		local v34
		if v29.ph == "W" then
			v34 = v29.f
		else
			v34 = 1 + v29.f
		end
		if v34 < v28 then
			return false
		end
		v28 = v34
	end
	local v35
	if p27[1].ph == "W" and (p27[1].f == 0 and p27[#p27].ph == "R") then
		v35 = p27[#p27].f == 1
	else
		v35 = false
	end
	return v35
end
local function v_u_47(p37) -- name: validVariants
	-- upvalues: (copy) v_u_26, (copy) v_u_36
	if type(p37) ~= "table" then
		return false
	end
	for v38, v39 in p37 do
		if type(v38) ~= "string" or (type(v39) ~= "table" or not v_u_26(v39.keys)) then
			return false
		end
		if v39.left ~= nil and not v_u_36(v39.left) then
			return false
		end
		if v39.windup ~= nil then
			local v40 = v39.windup
			if type(v40) ~= "number" or (v39.windup ~= v39.windup or (v39.windup <= 0.03 or v39.windup > 3)) then
				return false
			end
		end
		if v39.dur ~= nil then
			local v41 = v39.dur
			if type(v41) ~= "number" or (v39.dur ~= v39.dur or (v39.dur <= 0.1 or v39.dur > 6)) then
				return false
			end
		end
		local v42 = v39.windup
		if type(v42) == "number" then
			local v43 = v39.dur
			if type(v43) == "number" and v39.dur < v39.windup + 0.1 then
				return false
			end
		end
		local v44 = v39.flash
		if v44 == nil then
			continue
		end
		if type(v44) == "table" then
			local v45 = v44.from
			if type(v45) == "number" then
				local v46 = v44.to
				if type(v46) == "number" and (v44.from >= 0 and v44.to > v44.from) then
					continue
				end
			end
		end
		return false
	end
	return true
end
local function v_u_63(p48, p49) -- name: validPart
	-- upvalues: (copy) v_u_26, (copy) v_u_36, (copy) v_u_47
	if type(p49) ~= "table" then
		return false
	end
	local v50 = p49.keys
	if type(v50) ~= "table" or #p49.keys < 3 then
		return false
	end
	if p49.name ~= nil and p49.name ~= p48 then
		return false
	end
	if not v_u_26(p49.keys) then
		return false
	end
	local v51 = p49.toss
	if v51 == nil then
		v59 = p49.left
		if v59 ~= nil and not v_u_36(v59) then
			return false
		end
		if p49.variants ~= nil and not v_u_47(p49.variants) then
			return false
		end
		v60 = p49.idle
		if v60 ~= nil then
			if type(v60) ~= "table" then
				return false
			end
			for v61, v62 in v60 do
				if type(v62) == "number" and (v62 == v62 and (v62 ~= (1 / 0) and v62 ~= (-1 / 0))) then
					continue
				end
				return false
			end
		end
		return true
	end
	if type(v51) ~= "table" then
		return false
	end
	local v54 = v51.from
	if type(v54) ~= "number" then
		return false
	end
	local v55 = v51.to
	if type(v55) ~= "number" or (v51.from < 0 or (v51.to > 1 or v51.from >= v51.to)) then
		return false
	end
	local v56 = v51.height
	if type(v56) ~= "number" then
		return false
	end
	local v57 = v51.turns
	if type(v57) ~= "number" then
		return false
	end
	local v58 = v51.chance
	if type(v58) ~= "number" or (v51.chance < 0 or v51.chance > 1) then
		return false
	end
	if v51.keys ~= nil and not v_u_26(v51.keys) then
		return false
	end
	local v59 = p49.left
	if v59 ~= nil and not v_u_36(v59) then
		return false
	end
	if p49.variants ~= nil and not v_u_47(p49.variants) then
		return false
	end
	local v60 = p49.idle
	if v60 ~= nil then
		if type(v60) ~= "table" then
			return false
		end
		for v61, v62 in v60 do
			if type(v62) == "number" and (v62 == v62 and (v62 ~= (1 / 0) and v62 ~= (-1 / 0))) then
				continue
			end
			return false
		end
	end
	return true
end
function v_u_1.install(p_u_64) -- name: install
	-- upvalues: (copy) v_u_1, (copy) v_u_63
	if type(p_u_64) ~= "table" then
		return 0
	end
	local v65 = v_u_1.STYLES
	local v66 = 0
	for v67, v68 in {
		["knife"] = function() -- name: knife
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimKnife
		end,
		["dagger"] = function() -- name: dagger
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimDagger
		end,
		["balisong"] = function() -- name: balisong
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimBalisong
		end,
		["karambit"] = function() -- name: karambit
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimKarambit
		end,
		["tactical"] = function() -- name: tactical
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimTactical
		end,
		["machete"] = function() -- name: machete
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimMachete
		end,
		["baton"] = function() -- name: baton
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimBaton
		end,
		["crowbar"] = function() -- name: crowbar
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimCrowbar
		end,
		["bat"] = function() -- name: bat
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimBat
		end,
		["nailbat"] = function() -- name: nailbat
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimNailbat
		end,
		["axe"] = function() -- name: axe
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimAxe
		end,
		["katana"] = function() -- name: katana
			-- upvalues: (copy) p_u_64
			return p_u_64.MeleeAnimKatana
		end
	} do
		local v69, v70 = pcall(v68)
		if v69 and v_u_63(v67, v70) then
			v65[v67] = v70
			v66 = v66 + 1
		else
			v65[v67] = nil
		end
	end
	return v66
end
function v_u_1.styleOf(p71, p72, p73) -- name: styleOf
	-- upvalues: (copy) v_u_1
	if p73 and v_u_1.STYLES[p73] then
		return p73
	end
	if p72 then
		local v74 = p72.meleeStyle
		if type(v74) == "string" and v_u_1.STYLES[p72.meleeStyle] then
			return p72.meleeStyle
		end
	end
	local v75
	if p71 then
		v75 = v_u_1.BY_ID[p71]
		if not (v75 and v_u_1.STYLES[v75]) then
			v75 = v_u_1.LEGACY_BY_ID[p71]
		end
	else
		v75 = nil
	end
	if v75 then
		return v75
	end
	local v76 = string.gsub(p71 or "", "_gold$", "")
	local v77 = v_u_1.BY_ID[v76]
	if not (v77 and v_u_1.STYLES[v77]) then
		v77 = v_u_1.LEGACY_BY_ID[v76]
	end
	if v77 then
		return v77
	end
	local v78
	if p72 == nil then
		v78 = false
	else
		v78 = p72.holdType == "melee2h"
	end
	local v79
	if p72 then
		v79 = p72.weight
	else
		v79 = nil
	end
	return v78 and (v79 == "heavy" and (p72 and (p72.damage or 0) >= 70) and "chop2h" or "swing2h") or (v79 == "heavy" and "overhead" or (v79 == "medium" and "slash" or "stab"))
end
local function v_u_81(p80) -- name: vec
	return {
		p80.x,
		p80.y,
		p80.z,
		p80.yaw,
		p80.pitch,
		p80.roll,
		p80.ty or 0,
		p80.tp or 0
	}
end
function v_u_1.contactTime(p82, p83) -- name: contactTime
	local v84 = p83 * 0.8
	local v85 = math.max(0.05, v84)
	return math.clamp(p82, 0.04, v85)
end
local function v_u_120(p86, p87, p88, p89) -- name: evalKeys
	-- upvalues: (copy) v_u_81
	local v90 = #p86
	local v91 = table.create(v90)
	local v92 = table.create(v90)
	for v93, v94 in p86 do
		local v95
		if v94.ph == "W" then
			v95 = v94.f * p87
		else
			v95 = p87 + v94.f * p88
		end
		v91[v93] = v95
		v92[v93] = v_u_81(v94)
	end
	local v96 = v90 - 1
	for v97 = 1, v90 - 1 do
		if p89 > v91[v97 + 1] then
			continue
		end
		v96 = v97
	end
	local v98 = v91[v96]
	local v99 = v91[v96 + 1] - v98
	local v100 = math.max(v99, 0.0001)
	local v101 = (p89 - v98) / v100
	local v102 = math.clamp(v101, 0, 1)
	local v103 = table.create(8)
	for v104 = 1, 8 do
		local v105 = v92[v96][v104]
		local v106 = v92[v96 + 1][v104]
		local v107
		if p86[v96].hold == true or (v96 == 1 or v96 == v90) then
			v107 = 0
		else
			local v108 = v91[v96 - 1]
			local v109 = v91[v96 + 1]
			local v110 = v92[v96 + 1][v104] - v92[v96 - 1][v104]
			local v111 = v109 - v108
			v107 = v110 / math.max(v111, 0.0001)
		end
		local v112 = v96 + 1
		local v113
		if p86[v112].hold == true or (v112 == 1 or v112 == v90) then
			v113 = 0
		else
			local v114 = v91[v112 - 1]
			local v115 = v91[v112 + 1]
			local v116 = v92[v112 + 1][v104] - v92[v112 - 1][v104]
			local v117 = v115 - v114
			v113 = v116 / math.max(v117, 0.0001)
		end
		local v118 = v102 * v102
		local v119 = v118 * v102
		v103[v104] = (v119 * 2 - v118 * 3 + 1) * v105 + (v119 - v118 * 2 + v102) * v100 * v107 + (v119 * -2 + v118 * 3) * v106 + (v119 - v118) * v100 * v113
	end
	return v103
end
v_u_1.roll = math.random
function v_u_1.tossOf(p121) -- name: tossOf
	-- upvalues: (copy) v_u_1
	local v122 = v_u_1.STYLES[p121]
	if v122 then
		return v122.toss
	else
		return nil
	end
end
function v_u_1.rollToss(p123, p124) -- name: rollToss
	-- upvalues: (copy) v_u_1
	local v125 = v_u_1.tossOf(p123)
	if v125 then
		if p124 > 0 then
			return false, p124 - 1
		elseif v_u_1.roll() < (v125.chance or 0.3) then
			return true, 2
		else
			return false, 0
		end
	else
		return false, 0
	end
end
function v_u_1.hasVariant(p126, p127) -- name: hasVariant
	-- upvalues: (copy) v_u_1
	local v128 = v_u_1.STYLES[p126]
	local v129
	if type(p127) == "string" and type(v128) == "table" then
		local v130 = v128.variants
		if type(v130) == "table" then
			v129 = v128.variants[p127]
		else
			v129 = nil
		end
	else
		v129 = nil
	end
	return v129 ~= nil
end
function v_u_1.variantTiming(p131, p132, p133, p134) -- name: variantTiming
	-- upvalues: (copy) v_u_1
	local v135 = v_u_1.STYLES[p131]
	local v136
	if type(p132) == "string" and type(v135) == "table" then
		local v137 = v135.variants
		if type(v137) == "table" then
			v136 = v135.variants[p132]
		else
			v136 = nil
		end
	else
		v136 = nil
	end
	if v136 == nil then
		return p133, p134
	else
		local v138 = v136.windup
		if type(v138) == "number" then
			p133 = v136.windup
		end
		local v139 = v136.dur
		if type(v139) == "number" then
			return p133, v136.dur
		else
			return p133, p134
		end
	end
end
function v_u_1.idle(p140, p141, p142) -- name: idle
	-- upvalues: (copy) v_u_1
	local v143 = v_u_1.STYLES[p140]
	local v144
	if v143 == nil then
		v144 = nil
	else
		v144 = v143.idle
	end
	if type(v144) ~= "table" or (type(p141) ~= "number" or p141 ~= p141) then
		return {
			["x"] = 0,
			["y"] = 0,
			["z"] = 0,
			["pitch"] = 0,
			["roll"] = 0
		}
	end
	local v145 = (p142 or 0) / 8
	local v146 = math.clamp(v145, 0, 1)
	local v147 = (v144.hz or 0.3) * (1 + (v144.walkHz or 2) * v146)
	local v148 = 1 + (v144.walk or 1) * v146
	local v149 = 6.283185307179586 * v147 * p141
	local v150 = {
		["x"] = (v144.x or 0) * v148 * math.sin(v149)
	}
	local v151 = (v144.y or 0) * v148
	local v152 = 2 * v149 + 0.6
	v150.y = v151 * math.sin(v152)
	local v153 = (v144.z or 0) * v148
	local v154 = v149 + 1.3
	v150.z = v153 * math.sin(v154)
	local v155 = (v144.pitch or 0) * v148
	local v156 = 2 * v149 + 1.9
	v150.pitch = v155 * math.sin(v156)
	local v157 = (v144.roll or 0) * v148
	local v158 = v149 + 0.4
	v150.roll = v157 * math.sin(v158)
	return v150
end
function v_u_1.sample(p159, p160, p161, p162, p163, p164) -- name: sample
	-- upvalues: (copy) v_u_1, (copy) v_u_120
	local v165 = v_u_1.STYLES[p159] or v_u_1.STYLES.stab
	local v166
	if p164 == nil then
		v166 = nil
	else
		local v167 = p164.variant
		if type(v167) == "string" and type(v165) == "table" then
			local v168 = v165.variants
			if type(v168) == "table" then
				v166 = v165.variants[v167]
			else
				v166 = nil
			end
		else
			v166 = nil
		end
	end
	if v166 ~= nil then
		local v169 = v166.windup
		if type(v169) == "number" then
			p161 = v166.windup
		end
		local v170 = v166.dur
		if type(v170) == "number" then
			p162 = v166.dur
		end
	end
	local v171 = v_u_1.contactTime(p161, p162)
	local v172 = v171 + 0.1
	local v173 = math.max(p162, v172)
	local v174 = v173 - v171
	local v175
	if v166 == nil and (p164 ~= nil and p164.toss == true) then
		v175 = v165.toss ~= nil
	else
		v175 = false
	end
	local v176
	if v166 == nil then
		if v175 and v165.toss.keys ~= nil then
			v176 = v165.toss.keys
		else
			v176 = v165.keys
		end
	else
		v176 = v166.keys
	end
	local v177 = math.clamp(p160, 0, v173)
	local v178 = v_u_120(v176, v171, v174, v177)
	local v179 = p163 or 1
	local v180 = 0
	for _, v181 in v176 do
		if v181.ph ~= "W" or v181.hold ~= true then
			continue
		end
		if v181.ph == "W" then
			v180 = v181.f * v171
		else
			v180 = v171 + v181.f * v174
		end
	end
	local v182 = "wind"
	local v183
	if v173 - 0.0001 <= v177 then
		v183 = "ready"
	elseif v171 <= v177 then
		v183 = (v177 - v171) / math.max(v174, 0.0001) < 0.45 and "follow" or "recover"
	else
		v183 = v180 <= v177 and v180 > 0 and "strike" or v182
	end
	local v184 = nil
	local v185
	if v166 == nil then
		v185 = v165.left
	else
		v185 = v166.left
	end
	if v185 and #v185 >= 2 then
		local v186 = #v185
		local v187 = table.create(v186)
		for v188, v189 in v185 do
			local v190
			if v189.ph == "W" then
				v190 = v189.f * v171
			else
				v190 = v171 + v189.f * v174
			end
			v187[v188] = v190
		end
		local v191 = v186 - 1
		for v192 = 1, v186 - 1 do
			if v177 > v187[v192 + 1] then
				continue
			end
			v191 = v192
		end
		local v193 = v187[v191]
		local v194 = v187[v191 + 1] - v193
		local v195 = math.max(v194, 0.0001)
		local v196 = (v177 - v193) / v195
		local v197 = math.clamp(v196, 0, 1)
		local v198 = table.create(3)
		local v199 = { "x", "y", "z" }
		for v200 = 1, 3 do
			local v201 = v199[v200]
			local v202 = v185[v191][v201]
			local v203 = v185[v191 + 1][v201]
			local v204
			if v185[v191].hold == true or (v191 == 1 or v191 == v186) then
				v204 = 0
			else
				local v205 = v185[v191 + 1][v201] - v185[v191 - 1][v201]
				local v206 = v187[v191 + 1] - v187[v191 - 1]
				v204 = v205 / math.max(v206, 0.0001)
			end
			local v207 = v191 + 1
			local v208
			if v185[v207].hold == true or (v207 == 1 or v207 == v186) then
				v208 = 0
			else
				local v209 = v185[v207 + 1][v201] - v185[v207 - 1][v201]
				local v210 = v187[v207 + 1] - v187[v207 - 1]
				v208 = v209 / math.max(v210, 0.0001)
			end
			local v211 = v197 * v197
			local v212 = v211 * v197
			v198[v200] = (v212 * 2 - v211 * 3 + 1) * v202 + (v212 - v211 * 2 + v197) * v195 * v204 + (v212 * -2 + v211 * 3) * v203 + (v212 - v211) * v195 * v208
		end
		local v213 = v198[1]
		local v214 = v198[2]
		local v215 = v198[3]
		v184 = Vector3.new(v213, v214, v215) * v179
	end
	local v216 = nil
	if v175 then
		local v217 = v165.toss
		local v218 = v171 + v217.from * v174
		local v219 = v171 + v217.to * v174
		if v218 < v177 and v177 < v219 then
			local v220 = (v177 - v218) / (v219 - v218)
			local v221 = v_u_120(v176, v171, v174, v218)
			local v222 = v_u_120(v176, v171, v174, v219)
			local v223 = v221[1]
			local v224 = v221[2]
			local v225 = v221[3]
			local v226 = Vector3.new(v223, v224, v225) * v179
			local v227 = v222[1]
			local v228 = v222[2]
			local v229 = v222[3]
			local v230 = Vector3.new(v227, v228, v229) * v179
			local v231 = v178[1]
			local v232 = v178[2]
			local v233 = v178[3]
			local v234 = Vector3.new(v231, v232, v233) * v179
			v216 = {
				["off"] = v226:Lerp(v230, v220) - v234,
				["up"] = v217.height * 4 * v220 * (1 - v220),
				["angle"] = v217.turns * 2 * 3.141592653589793 * v220,
				["s"] = v220
			}
		end
	end
	local v235 = nil
	local v236
	if v166 == nil then
		v236 = nil
	else
		v236 = v166.flash
	end
	if v236 ~= nil and (v236.from <= v177 and v177 <= v236.to) then
		local v237 = v177 - v236.from
		local v238 = v236.to - v236.from
		local v239 = 3.141592653589793 * (v237 / math.max(v238, 0.0001))
		v235 = math.sin(v239)
	end
	local v240 = {
		["left"] = v184,
		["toss"] = v216
	}
	local v241 = v178[1]
	local v242 = v178[2]
	local v243 = v178[3]
	v240.pos = Vector3.new(v241, v242, v243) * v179
	v240.yaw = v178[4]
	v240.pitch = v178[5]
	v240.roll = v178[6]
	v240.torsoYaw = v178[7]
	v240.torsoPitch = v178[8]
	v240.phase = v183
	local v244 = v177 - v171
	v240.contact = math.abs(v244) <= 0.02
	v240.u = v177 / v173
	v240.t = v177
	local v245
	if v166 == nil or p164 == nil then
		v245 = nil
	else
		v245 = p164.variant
	end
	v240.variant = v245
	v240.flash = v235
	return v240
end
function v_u_1.grip(p246, p247) -- name: grip
	-- upvalues: (copy) v_u_2
	return CFrame.new(p247 + p246.pos) * CFrame.Angles(0, v_u_2(p246.yaw), 0) * CFrame.Angles(v_u_2(p246.pitch), 0, (v_u_2(p246.roll)))
end
return v_u_1