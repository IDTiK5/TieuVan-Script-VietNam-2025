-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCratesOdds

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_3 = require(v_u_2:WaitForChild("CaseOdds"))
local v_u_4 = require(v_u_2:WaitForChild("Skins"))
local v_u_5 = {
	"Common",
	"Uncommon",
	"Rare",
	"Epic",
	"Legendary",
	"Mythic",
	"Signature"
}
v_u_1.TEXT = {
	["title"] = "ODDS",
	["body"] = "Every result and its chance, exactly as the opening rolls it. The chances of one case add up to 100 percent. Finishes are cosmetic and change no stats."
}
function v_u_1.money(p6) -- name: money
	local v7 = tonumber(p6) or 0
	local v8 = math.floor(v7)
	local v9 = math.abs(v8)
	local v10 = tostring(v9)
	local v11 = ""
	while #v10 > 3 do
		v11 = "," .. string.sub(v10, -3) .. v11
		local v12 = #v10 - 3
		v10 = string.sub(v10, 1, v12)
	end
	return (v8 < 0 and "-$" or "$") .. v10 .. v11
end
function v_u_1.lines(p13, p14) -- name: lines
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_1, (copy) v_u_5, (copy) v_u_4
	local v15 = v_u_3.get(p13)
	if v15 == nil then
		return nil
	end
	local v16 = v_u_3.KEYS[v15.key] and (v_u_3.KEYS[v15.key].name or "KEY") or "KEY"
	local v17 = {
		["crateId"] = p13,
		["header"] = v15.name .. "  (needs a " .. v16 .. ")",
		["groups"] = {},
		["rows"] = {},
		["total"] = v_u_3.percent(v_u_3.TOTAL)
	}
	local v18 = v_u_3.tallyLine(p14)
	if v18 ~= "" then
		v17.tallyLine = v18
		v17.tallyBody = v_u_3.tallyBody(p14)
	end
	local v19 = require
	local v20 = v_u_2
	local v21, v22 = pcall(v19, v20:WaitForChild("SkinRules"))
	if v21 and (v22.cashAllowed(v15) and v22.cashPriceOf(v15) ~= nil) then
		v17.cashLine = ("Or open it with %s cash. The chances below are the same."):format(v_u_1.money(v22.cashPriceOf(v15)))
	end
	local v23 = v_u_3.group(p13)
	for v24 = 1, 7 do
		if (v23[v24] or 0) <= 0 then
			continue
		end
		local v25 = v17.groups
		local v26 = {
			["rarity"] = v24,
			["name"] = v_u_5[v24],
			["pct"] = v_u_3.percent(v23[v24])
		}
		table.insert(v25, v26)
	end
	local v27 = {}
	for _, v28 in v15.pool do
		table.insert(v27, v28)
	end
	table.sort(v27, function(p29, p30)
		-- upvalues: (ref) v_u_4
		local v31 = v_u_4.get(p29.skin)
		local v32 = v_u_4.get(p30.skin)
		local v33 = v31 and v31.rarity or 0
		local v34 = v32 and v32.rarity or 0
		if v33 == v34 then
			return p29.w < p30.w
		else
			return v34 < v33
		end
	end)
	local v35 = {}
	for _, v36 in v27 do
		local v37 = v_u_4.get(v36.skin)
		if v37 and v37.series then
			local v38 = v35[v37.series]
			if v38 == nil then
				v38 = {
					["skin"] = nil,
					["name"] = nil,
					["rarity"] = nil,
					["rarityName"] = nil,
					["w"] = 0,
					["count"] = 0,
					["min"] = (1 / 0),
					["max"] = 0,
					["skin"] = "series_" .. v37.series,
					["name"] = "SIGNATURE: " .. string.upper(v37.series),
					["rarity"] = v37.rarity,
					["rarityName"] = v_u_5[v37.rarity]
				}
				v35[v37.series] = v38
				local v39 = v17.rows
				table.insert(v39, v38)
			end
			v38.w = v38.w + v36.w
			v38.count = v38.count + 1
			local v40 = v38.min
			local v41 = v36.w
			v38.min = math.min(v40, v41)
			local v42 = v38.max
			local v43 = v36.w
			v38.max = math.max(v42, v43)
		else
			local v44 = v17.rows
			local v45 = {
				["skin"] = v36.skin,
				["name"] = v_u_4.displayName(v37),
				["rarity"] = v37 and (v37.rarity or 1) or 1,
				["rarityName"] = v_u_5[v37 and v37.rarity or 1],
				["pct"] = v_u_3.percent(v36.w),
				["w"] = v36.w
			}
			table.insert(v44, v45)
		end
	end
	for _, v46 in v35 do
		v46.pct = v_u_3.percent(v46.w)
		if v46.min == v46.max then
			v46.note = ("%d finishes, %s %% each"):format(v46.count, v_u_3.percent(v46.min))
		else
			v46.note = ("%d finishes, %s %% each (one of them %s %%)"):format(v46.count, v_u_3.percent(v46.min), v_u_3.percent(v46.max))
		end
	end
	table.sort(v17.rows, function(p47, p48)
		if p47.rarity == p48.rarity then
			return p47.w < p48.w
		else
			return p47.rarity > p48.rarity
		end
	end)
	return v17
end
function v_u_1.models(p49, p50) -- name: models
	-- upvalues: (copy) v_u_1
	local v51 = {}
	local v52 = {}
	local v53
	if type(p50) == "table" then
		local v54 = p50.tally
		v53 = type(v54) == "boolean" and {
			["tally"] = p50.tally
		} or nil
	else
		v53 = nil
	end
	if type(p49) ~= "table" then
		return v51, v52
	end
	for _, v55 in p49 do
		local v56 = v_u_1.lines(v55, v53)
		if v56 then
			table.insert(v51, v56)
		else
			table.insert(v52, v55)
		end
	end
	return v51, v52
end
v_u_1.last = nil
function v_u_1.open(p57, p58, p59) -- name: open
	-- upvalues: (copy) v_u_1
	local v_u_60 = p57.ui
	local v_u_61 = p57.theme
	local v_u_62 = v_u_61.color
	local v_u_63, v64 = v_u_1.models(p58, p59)
	local v65 = v_u_1.TEXT.body
	local v_u_66 = {}
	for _, v67 in v_u_63 do
		local v68 = v67.crateId
		table.insert(v_u_66, v68)
		if not v67.tallyBody or (v67.tallyBody == "" or string.find(v65, "TALLY", 1, true)) then
			continue
		end
		v65 = v65 .. " " .. v67.tallyBody
	end
	local v69 = {}
	if type(p58) == "table" then
		for _, v70 in p58 do
			table.insert(v69, v70)
		end
	end
	v_u_1.last = {
		["ids"] = v69,
		["shown"] = v_u_66,
		["unknown"] = v64
	}
	if #v_u_63 == 0 then
		return nil
	end
	local v_u_97 = v_u_60.modal({
		["title"] = nil,
		["width"] = 620,
		["body"] = nil,
		["build"] = nil,
		["buttons"] = nil,
		["title"] = p59 and p59.title or v_u_1.TEXT.title,
		["body"] = v65,
		["build"] = function(p71) -- name: build
			-- upvalues: (copy) v_u_63, (copy) v_u_60, (copy) v_u_62, (copy) v_u_61
			local v72 = 0
			local v73 = v72
			for _, v74 in v_u_63 do
				local v75 = v_u_60.label
				local v76 = {
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "h3",
					["size"] = nil,
					["order"] = nil,
					["parent"] = p71,
					["name"] = "OddsHeader_" .. v74.crateId,
					["text"] = v74.header,
					["size"] = UDim2.new(1, 0, 0, 24)
				}
				v72 = v73 + 1
				v76.order = v72
				v75(v76)
				local v77
				if v74.cashLine then
					local v78 = v_u_60.label
					local v79 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = p71,
						["text"] = v74.cashLine,
						["color"] = v_u_62.text2
					}
					v72 = v72 + 1
					v79.order = v72
					v78(v79)
					v77 = v72
				else
					v77 = v72
				end
				local v80 = {}
				for _, v81 in v74.groups do
					local v82 = v81.name
					local v83 = v81.pct
					table.insert(v80, ("%s %s %%"):format(v82, v83))
				end
				local v84 = v_u_60.label
				local v85 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = p71,
					["text"] = table.concat(v80, "     "),
					["color"] = v_u_62.text2
				}
				v72 = v77 + 1
				v85.order = v72
				v84(v85).TextXAlignment = Enum.TextXAlignment.Left
				local v86
				if v74.tallyLine then
					local v87 = v_u_60.label
					local v88 = {
						["parent"] = nil,
						["name"] = "TallyLine",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = p71,
						["text"] = v74.tallyLine,
						["color"] = v_u_62.accent
					}
					v72 = v72 + 1
					v88.order = v72
					v87(v88)
					v86 = v72
				else
					v86 = v72
				end
				for _, v89 in v74.rows do
					local v90 = v_u_60.new
					local v91 = {
						["Name"] = nil,
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Name"] = "Odds_" .. v89.skin,
						["Size"] = UDim2.new(1, 0, 0, v_u_61.touch(24))
					}
					v72 = v86 + 1
					v91.LayoutOrder = v72
					local v92 = v90("Frame", v91, p71)
					v_u_60.new("Frame", {
						["Name"] = "Rarity",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_61.rarityColor(v89.rarity),
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, 0, 0.5, 0),
						["Size"] = UDim2.fromOffset(4, 16)
					}, v92)
					v_u_60.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v92,
						["text"] = v89.name,
						["color"] = v_u_62.text,
						["position"] = UDim2.fromOffset(12, 0),
						["size"] = UDim2.new(1, -170, 1, 0)
					})
					v_u_60.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["align"] = "right",
						["anchor"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v92,
						["text"] = v89.rarityName,
						["color"] = v_u_61.rarityColor(v89.rarity),
						["anchor"] = Vector2.new(1, 0),
						["position"] = UDim2.new(1, -86, 0, 0),
						["size"] = UDim2.fromOffset(74, v_u_61.touch(24))
					})
					v_u_60.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "mono",
						["color"] = nil,
						["align"] = "right",
						["anchor"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v92,
						["text"] = v89.pct .. " %",
						["color"] = v_u_62.text,
						["anchor"] = Vector2.new(1, 0),
						["position"] = UDim2.new(1, 0, 0, 0),
						["size"] = UDim2.fromOffset(80, v_u_61.touch(24))
					})
					if v89.note then
						local v93 = v_u_60.label
						local v94 = {
							["parent"] = nil,
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["size"] = nil,
							["order"] = nil,
							["parent"] = p71,
							["text"] = v89.note,
							["color"] = v_u_62.muted,
							["size"] = UDim2.new(1, 0, 0, 16)
						}
						v72 = v72 + 1
						v94.order = v72
						v93(v94)
						v86 = v72
					else
						v86 = v72
					end
				end
				local v95 = v_u_60.label
				local v96 = {
					["parent"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["align"] = "right",
					["size"] = nil,
					["order"] = nil,
					["parent"] = p71,
					["text"] = "Total " .. v74.total .. " %",
					["color"] = v_u_62.muted,
					["size"] = UDim2.new(1, 0, 0, 18)
				}
				v72 = v86 + 1
				v96.order = v72
				v95(v96)
				v73 = v72
			end
		end,
		["buttons"] = {
			{
				["text"] = "Close",
				["kind"] = "close"
			}
		}
	})
	pcall(function()
		-- upvalues: (copy) v_u_97, (copy) v_u_66
		v_u_97.frame:SetAttribute("CrateIds", table.concat(v_u_66, ","))
	end)
	return v_u_97
end
return v_u_1