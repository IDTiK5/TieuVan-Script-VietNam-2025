-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AssistHead

local v_u_1 = game:GetService("Workspace")
local v_u_2 = game:GetService("CollectionService")
local v_u_25 = {
	["FLAG"] = "AssistHeadBias",
	["BIAS"] = {
		["Touch"] = {
			["pistol"] = 0.25,
			["smg"] = 0.25,
			["shotgun"] = 0.1,
			["rifle"] = 0.25,
			["sniper"] = 0.25,
			["mg"] = 0.25
		},
		["Gamepad"] = {
			["pistol"] = 0.25,
			["smg"] = 0.25,
			["shotgun"] = 0.1,
			["rifle"] = 0.25,
			["sniper"] = 0.25,
			["mg"] = 0.25
		}
	},
	["AUTO_MUL"] = 0.7,
	["HEAD_AT"] = 0.75,
	["DITHER"] = true,
	["MIN_RISE"] = 0.6,
	["LOW_DROP"] = 0.8,
	["CACHE_S"] = 0.06,
	["bias"] = function(p3, p4, p5) -- name: bias
		-- upvalues: (copy) v_u_25
		local v6 = v_u_25.BIAS[p3 or ""]
		if not v6 then
			return 0
		end
		local v7 = v6[p4 or ""]
		if type(v7) ~= "number" then
			return 0
		end
		if p5 == true then
			v7 = v7 * v_u_25.AUTO_MUL
		end
		return math.clamp(v7, 0, 1)
	end,
	["point"] = function(p8, p9, p10) -- name: point
		return p8:Lerp(p9, (math.clamp(p10, 0, 1)))
	end,
	["shotBias"] = function(p11, p12) -- name: shotBias
		-- upvalues: (copy) v_u_25
		if p12 == nil or (not v_u_25.DITHER or p11 <= 0) then
			return p11
		else
			local v13 = v_u_25.HEAD_AT
			if v13 <= p11 then
				return p11
			else
				return p12 >= p11 / v13 and 0 or v13
			end
		end
	end,
	["rigOk"] = function(p14, p15, p16, p17, p18) -- name: rigOk
		-- upvalues: (copy) v_u_25
		if p17 == true then
			return false, "corpse"
		elseif p18 == true then
			return false, "lying"
		elseif p15 then
			if p16 and p15.Y < p16.Y - v_u_25.LOW_DROP then
				return false, "low"
			elseif p15.Y - p14.Y < v_u_25.MIN_RISE then
				return false, "low"
			else
				return true, nil
			end
		else
			return false, "nohead"
		end
	end,
	["resolve"] = function(p19) -- name: resolve
		-- upvalues: (copy) v_u_25
		if p19.flag ~= true then
			return p19.torso, 0, "flag"
		end
		if p19.device ~= "Touch" and p19.device ~= "Gamepad" then
			return p19.torso, 0, "device"
		end
		if p19.assist ~= true then
			return p19.torso, 0, "assist"
		end
		if p19.kind ~= "firearm" or p19.noBias == true then
			return p19.torso, 0, "weapon"
		end
		local v20, v21 = v_u_25.rigOk(p19.torso, p19.head, p19.root, p19.corpse, p19.lying)
		if not v20 then
			return p19.torso, 0, v21
		end
		local v22 = p19.head
		local v23 = v_u_25.bias(p19.device, p19.class, p19.auto)
		if v23 <= 0 then
			return p19.torso, 0, "zero"
		end
		if p19.visible and not p19.visible(v22) then
			return p19.torso, 0, "hidden"
		end
		if p19.clear then
			if not p19.clear(p19.torso) then
				return p19.torso, 0, "torsoBlocked"
			end
			if not p19.clear(v22) then
				return p19.torso, 0, "headBlocked"
			end
		end
		local v24 = v_u_25.shotBias(v23, p19.u)
		return v_u_25.point(p19.torso, v22, v24), v24, nil
	end
}
local v_u_26 = {
	["Glass"] = true
}
local function v_u_37(p27, p28, p29) -- name: lineFree
	-- upvalues: (copy) v_u_1, (copy) v_u_26, (copy) v_u_2
	if (p28 - p27).Magnitude < 0.05 then
		return true
	end
	local v30 = table.clone(p29)
	local v31 = RaycastParams.new()
	v31.FilterType = Enum.RaycastFilterType.Exclude
	v31.IgnoreWater = true
	for _ = 1, 6 do
		v31.FilterDescendantsInstances = v30
		local v32 = v_u_1:Raycast(p27, p28 - p27, v31)
		if not v32 then
			return true
		end
		local v33 = v32.Instance
		local v34 = false
		local v35
		if v33.Transparency >= 0.98 and not v33.CanCollide or (v_u_26[v33.Material.Name] and v33:GetAttribute("Broken") ~= true or v_u_2:HasTag(v33, "HushWindow")) then
			v35 = true
		else
			local v36 = v33:FindFirstAncestorOfClass("Model")
			v35 = v36 and v36:FindFirstChild("HumanoidRootPart") and true or v34
		end
		if not v35 then
			return false
		end
		table.insert(v30, v33)
		p27 = v32.Position
	end
	return true
end
local v_u_38 = {
	["rig"] = nil,
	["at"] = -1,
	["o"] = nil,
	["tClear"] = true,
	["hClear"] = true
}
function v_u_25.pick(p39) -- name: pick
	-- upvalues: (ref) v_u_38, (copy) v_u_25, (copy) v_u_37
	local v_u_40 = p39.rig
	local v_u_41 = (v_u_40:FindFirstChild("UpperTorso") or v_u_40:FindFirstChild("HumanoidRootPart")).Position
	local v42 = v_u_40:FindFirstChild("Head")
	local v43 = v_u_40:FindFirstChild("HumanoidRootPart")
	local v44 = p39.stats
	local v_u_45
	if v42 and v42:IsA("BasePart") then
		v_u_45 = v42.Position
	else
		v_u_45 = nil
	end
	local v_u_46 = p39.ignore or {}
	local v_u_47 = os.clock()
	local v_u_48 = p39.origin
	local function v_u_54(_, p49) -- name: line
		-- upvalues: (ref) v_u_38, (copy) v_u_40, (copy) v_u_47, (ref) v_u_25, (copy) v_u_48, (ref) v_u_37, (copy) v_u_41, (copy) v_u_46, (copy) v_u_45
		local v50 = v_u_38
		local v51
		if v50.rig == v_u_40 and (v_u_47 - v50.at < v_u_25.CACHE_S and v50.o ~= nil) then
			v51 = (v50.o - v_u_48).Magnitude < 0.6
		else
			v51 = false
		end
		if not v51 then
			local v52 = {
				["rig"] = v_u_40,
				["at"] = v_u_47,
				["o"] = v_u_48,
				["tClear"] = v_u_37(v_u_48, v_u_41, v_u_46)
			}
			local v53
			if v_u_45 then
				v53 = v_u_37(v_u_48, v_u_45, v_u_46)
			else
				v53 = false
			end
			v52.hClear = v53
			v_u_38 = v52
			v50 = v_u_38
		end
		if p49 then
			return v50.hClear
		else
			return v50.tClear
		end
	end
	local v55 = v_u_25.resolve
	local v56 = {
		["device"] = p39.device,
		["flag"] = p39.flag,
		["assist"] = p39.assist
	}
	local v57
	if v44 then
		v57 = v44.kind
	else
		v57 = nil
	end
	v56.kind = v57
	local v58
	if v44 then
		v58 = v44.class
	else
		v58 = nil
	end
	v56.class = v58
	v56.auto = p39.auto
	local v59
	if v44 == nil then
		v59 = false
	else
		v59 = v44.flare ~= nil
	end
	v56.noBias = v59
	v56.torso = v_u_41
	v56.head = v_u_45
	local v60
	if v43 then
		v60 = v43.Position
	else
		v60 = nil
	end
	v56.root = v60
	v56.corpse = v_u_40:GetAttribute("Corpse") == true
	v56.lying = v_u_40:GetAttribute("Lying") == true
	v56.visible = p39.visible
	local v61
	if p39.shot == true then
		v61 = math.random()
	else
		v61 = nil
	end
	v56.u = v61
	function v56.clear(p62) -- name: clear
		-- upvalues: (copy) v_u_54, (copy) v_u_45
		local v63 = v_u_54
		local v64
		if v_u_45 == nil then
			v64 = false
		else
			v64 = p62 == v_u_45
		end
		return v63(p62, v64)
	end
	return v55(v56)
end
return v_u_25