-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreSaleLayout

local v_u_99 = {
	["EM_BOLD"] = 0.66,
	["BAND_H"] = 22,
	["PILL_H"] = 18,
	["PAD"] = 8,
	["GAP"] = 6,
	["OLD_MIN_W"] = 70,
	["COUNT_H"] = 14,
	["COUNT_SIZE"] = 10,
	["LABEL_SIZE"] = 12,
	["PILL_SIZE"] = 13,
	["OLD_SIZE"] = 12,
	["TAG_GAP"] = 4,
	["PULSE_MAX"] = 1.06,
	["NOTICE_MAX_W"] = 360,
	["rect"] = function(p1, p2, p3, p4) -- name: rect
		return {
			["x"] = p1,
			["y"] = p2,
			["w"] = p3,
			["h"] = p4
		}
	end,
	["textW"] = function(p5, p6) -- name: textW
		-- upvalues: (copy) v_u_99
		local v7 = utf8.len(p5)
		local v8 = (v7 == nil and #p5 or v7) * p6 * v_u_99.EM_BOLD
		return math.ceil(v8)
	end,
	["pillText"] = function(p9) -- name: pillText
		if type(p9) == "number" then
			return ("-%d%%"):format(p9)
		else
			return nil
		end
	end,
	["pillW"] = function(p10) -- name: pillW
		-- upvalues: (copy) v_u_99
		return v_u_99.textW(p10, v_u_99.PILL_SIZE) + 14
	end,
	["tile"] = function(p11) -- name: tile
		-- upvalues: (copy) v_u_99
		local v12 = p11.art
		local v13 = p11.buy
		local v14 = v12.x
		local v15 = v12.y
		local v16 = v12.w
		local v17 = v_u_99.BAND_H
		local v18 = v12.h
		local v19 = {
			["x"] = v14,
			["y"] = v15,
			["w"] = v16,
			["h"] = math.min(v17, v18)
		}
		local v20 = {
			["band"] = v19
		}
		local v21 = v_u_99.pillText(p11.pct)
		local v22 = v19.x + v19.w - v_u_99.PAD
		if v21 ~= nil then
			local v23 = v_u_99.pillW(v21)
			local v24 = v_u_99.PILL_H
			local v25 = v19.h
			local v26 = math.min(v24, v25)
			local v27 = {}
			local v28 = v19.x + v19.w - 6 - v23
			local v29 = v19.y
			local v30 = (v19.h - v26) / 2
			v27.rect = {
				["x"] = v28,
				["y"] = v29 + math.floor(v30),
				["w"] = v23,
				["h"] = v26
			}
			v27.text = v21
			v20.pill = v27
			v22 = v20.pill.rect.x - v_u_99.GAP
		end
		local v31 = p11.wasText
		local v32 = false
		if v31 ~= nil then
			local v33 = v_u_99.PAD + 4
			if p11.gift ~= nil then
				v33 = p11.gift.x + p11.gift.w + v_u_99.GAP
			end
			local v34 = v13.x - v_u_99.GAP - v33
			if p11.forceBand == true then
				v32 = true
			else
				local v35 = v_u_99.OLD_MIN_W
				local v36 = v_u_99.textW
				local v37 = v_u_99.OLD_SIZE
				if math.max(v35, v36(v31, v37)) <= v34 then
					v20.old = {
						["rect"] = nil,
						["text"] = nil,
						["where"] = "beside",
						["rect"] = {
							["x"] = v33,
							["y"] = v13.y,
							["w"] = v34,
							["h"] = v13.h
						},
						["text"] = v31
					}
				else
					v32 = true
				end
			end
		end
		local v38 = p11.hasEnds and "LIMITED SALE" or "SALE"
		local v39 = v19.x + v_u_99.PAD
		local v40 = v22 - v39
		local v41 = (not v32 or v31 == nil) and 0 or v_u_99.textW(v31, v_u_99.OLD_SIZE) + v_u_99.GAP
		local v42 = v40 < v_u_99.textW(v38, v_u_99.LABEL_SIZE) + v41 and "SALE" or v38
		local v43 = v_u_99.textW(v42, v_u_99.LABEL_SIZE)
		v20.label = {
			["rect"] = {
				["x"] = v39,
				["y"] = v19.y,
				["w"] = v43,
				["h"] = v19.h
			},
			["text"] = v42
		}
		if v32 and (v31 ~= nil and v43 + v41 <= v40) then
			v20.old = {
				["rect"] = nil,
				["text"] = nil,
				["where"] = "band",
				["rect"] = {
					["x"] = v39 + v43 + v_u_99.GAP,
					["y"] = v19.y,
					["w"] = v41 - v_u_99.GAP,
					["h"] = v19.h
				},
				["text"] = v31
			}
		end
		if p11.hasEnds and (p11.countText ~= nil and (p11.ownTimer ~= true and v12.h >= v19.h + v_u_99.COUNT_H + 2)) then
			local v44 = v_u_99.textW(p11.countText, v_u_99.COUNT_SIZE)
			local v45 = v19.y + v19.h + 2
			local v46 = v19.x + v19.w - v44 - 2
			if p11.hasTag and v46 < 10 + (p11.tagW or 90) + v_u_99.TAG_GAP then
				v45 = v19.y + v19.h + v_u_99.TAG_GAP + 16 + 2
			end
			if v45 + v_u_99.COUNT_H <= v12.y + v12.h then
				v20.countdown = {
					["rect"] = {
						["x"] = v46,
						["y"] = v45,
						["w"] = v44,
						["h"] = v_u_99.COUNT_H
					},
					["text"] = p11.countText
				}
			end
		end
		if p11.hasTag then
			v20.tagY = v19.y + v19.h + v_u_99.TAG_GAP
		end
		if p11.ownTimer then
			v20.timerY = v19.y + v19.h + 2
		end
		return v20
	end,
	["strip"] = function(p47, p48) -- name: strip
		-- upvalues: (copy) v_u_99
		local v49 = p47 - 24
		local v50 = {
			["x"] = 12,
			["y"] = 8,
			["w"] = nil,
			["h"] = 16,
			["w"] = math.max(0, v49)
		}
		local v51 = {
			["head"] = v50
		}
		if p48.hasEnds and p48.countText ~= nil then
			local v52 = v_u_99.textW(p48.countText, 12)
			v51.count = {
				["rect"] = {
					["x"] = nil,
					["y"] = 8,
					["w"] = nil,
					["h"] = 16,
					["x"] = p47 - 12 - v52,
					["w"] = v52
				},
				["text"] = p48.countText
			}
			local v53 = v51.count.rect.x - 12 - v_u_99.GAP
			v50.w = math.max(0, v53)
		end
		local v54 = p48.pct
		local v55 = type(v54) ~= "number" and "ON SALE" or ("SAVE %d%%"):format(p48.pct)
		local v56 = v_u_99.textW(v55, 24)
		local v57 = {}
		local v58 = p47 - 24
		v57.rect = {
			["x"] = 12,
			["y"] = 28,
			["w"] = nil,
			["h"] = 30,
			["w"] = math.min(v56, v58)
		}
		v57.text = v55
		v51.big = v57
		if p48.wasText ~= nil then
			local v59 = v_u_99.textW(p48.wasText, 16)
			local v60 = v51.big.rect.x + v51.big.rect.w + 14
			if v60 + v59 <= p47 - 12 then
				v51.old = {
					["rect"] = {
						["x"] = nil,
						["y"] = 36,
						["w"] = nil,
						["h"] = 20,
						["x"] = v60,
						["w"] = v59
					},
					["text"] = p48.wasText
				}
			end
		end
		local v61 = 58
		if p48.text ~= nil and p48.text ~= "" then
			local v62 = {}
			local v63 = v61 + 2
			local v64 = p47 - 24
			v62.rect = {
				["x"] = 12,
				["y"] = nil,
				["w"] = nil,
				["h"] = 18,
				["y"] = v63,
				["w"] = math.max(0, v64)
			}
			v62.text = p48.text
			v51.text = v62
			v61 = v61 + 22
		end
		v51.h = v61 + 8
		return v51
	end,
	["row"] = function(p65, p66) -- name: row
		-- upvalues: (copy) v_u_99
		local v67 = p66.touchH or 40
		local v68 = p66.n > p66.cols
		local v69 = not v68 and 28 or math.max(28, v67)
		local v70 = {
			["head"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p65,
				["h"] = v69
			}
		}
		local v71 = (v69 - 12) / 2
		v70.square = {
			["x"] = 0,
			["y"] = nil,
			["w"] = 12,
			["h"] = 12,
			["y"] = math.floor(v71)
		}
		v70.title = {
			["x"] = 20,
			["y"] = 0,
			["w"] = 90,
			["h"] = nil,
			["h"] = v69
		}
		if v68 then
			v70.seeAll = {
				["x"] = nil,
				["y"] = 0,
				["w"] = 130,
				["h"] = nil,
				["x"] = p65 - 130,
				["h"] = v67
			}
			local v72 = v70.title.x + v70.title.w + v_u_99.GAP
			local v73 = v70.seeAll.x - (v70.title.x + v70.title.w + v_u_99.GAP) - v_u_99.GAP
			v70.count = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v72,
				["w"] = math.max(0, v73),
				["h"] = v69
			}
		else
			local v74 = v70.title.x + v70.title.w + v_u_99.GAP
			local v75 = p65 - (v70.title.x + v70.title.w + v_u_99.GAP)
			v70.count = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v74,
				["w"] = math.max(0, v75),
				["h"] = v69
			}
		end
		local v76 = p66.n
		local v77 = p66.cols
		local v78 = math.min(v76, v77)
		v70.shown = v78
		v70.cards = {}
		for v79 = 1, v78 do
			local v80 = v70.cards
			local v81 = {
				["x"] = (v79 - 1) * (p66.cardW + 12),
				["y"] = v69 + 8,
				["w"] = p66.cardW,
				["h"] = p66.cardH
			}
			table.insert(v80, v81)
		end
		v70.h = v69 + 8 + p66.cardH
		return v70
	end,
	["notice"] = function(p82, p83) -- name: notice
		-- upvalues: (copy) v_u_99
		local v84 = p83.touchH or 44
		local v85 = {}
		local v86 = 0
		local v87 = v_u_99.pillText(p83.pct)
		local v88
		if v87 == nil then
			v88 = 0
		else
			v88 = v_u_99.pillW(v87)
			v85.pill = {
				["rect"] = {
					["x"] = nil,
					["y"] = 0,
					["w"] = nil,
					["h"] = 24,
					["x"] = p82 - v88,
					["w"] = v88
				},
				["text"] = v87
			}
		end
		local v89 = p82 - v88 - (v88 <= 0 and 0 or v_u_99.GAP)
		v85.title = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 24,
			["y"] = v86,
			["w"] = math.max(0, v89)
		}
		local v90 = v86 + 28
		v85.name = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 22,
			["y"] = v90,
			["w"] = p82
		}
		local v91 = v90 + 26
		v85.body = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = 36,
			["y"] = v91,
			["w"] = p82
		}
		local v92 = v91 + 40
		if p83.hasMore then
			v85.more = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = 16,
				["y"] = v92,
				["w"] = p82
			}
			v92 = v92 + 20
		end
		local v93 = v92 + 4
		local v94 = (p82 - v_u_99.GAP) / 2
		local v95 = math.floor(v94)
		local v96 = {
			["view"] = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = v93,
				["w"] = math.max(v95, 120),
				["h"] = v84
			}
		}
		local v97 = math.max(v95, 120) + v_u_99.GAP
		local v98 = p82 - math.max(v95, 120) - v_u_99.GAP
		v96.later = {
			["x"] = v97,
			["y"] = v93,
			["w"] = math.max(0, v98),
			["h"] = v84
		}
		v85.buttons = v96
		v85.h = v93 + v84
		return v85
	end
}
return v_u_99