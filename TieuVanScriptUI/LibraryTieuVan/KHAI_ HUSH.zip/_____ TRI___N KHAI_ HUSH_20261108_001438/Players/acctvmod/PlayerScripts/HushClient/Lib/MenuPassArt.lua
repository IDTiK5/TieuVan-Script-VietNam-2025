-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassArt

local v_u_1 = {}
local function v_u_3(p2) -- name: rgb
	return Color3.fromRGB(p2[1], p2[2], p2[3])
end
function v_u_1.plan(p_u_4, p5) -- name: plan
	local v_u_6 = "PassTileLook"
	local v7, v8 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_6
		return p_u_4.cctx.shared[v_u_6]
	end)
	if not v7 or type(v8) ~= "table" then
		v8 = nil
	end
	if v8 == nil then
		return nil
	end
	local v_u_9 = "Skins"
	local v10, v_u_11 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_9
		return p_u_4.cctx.shared[v_u_9]
	end)
	if not v10 or type(v_u_11) ~= "table" then
		v_u_11 = nil
	end
	local v_u_12 = "SkinFinishes"
	local v13, v_u_14 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_12
		return p_u_4.cctx.shared[v_u_12]
	end)
	if not v13 or type(v_u_14) ~= "table" then
		v_u_14 = nil
	end
	local v_u_15 = "PassTileArt"
	local v16, v_u_17 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_15
		return p_u_4.cctx.shared[v_u_15]
	end)
	if not v16 or type(v_u_17) ~= "table" then
		v_u_17 = nil
	end
	local v_u_18 = "ItemTileArt"
	local v19, v_u_20 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_18
		return p_u_4.cctx.shared[v_u_18]
	end)
	if not v19 or type(v_u_20) ~= "table" then
		v_u_20 = nil
	end
	local v23 = {
		["art"] = v_u_17 ~= nil and v_u_20 ~= nil and {
			["SIZE"] = v_u_17.SIZE,
			["IDS"] = v_u_17.IDS,
			["count"] = v_u_17.count,
			["image"] = function(p21) -- name: image
				-- upvalues: (copy) v_u_17, (copy) v_u_20
				local v22 = v_u_17.image(p21)
				if v22 == nil then
					v22 = v_u_20.image(p21)
				end
				return v22
			end
		} or v_u_17
	}
	local v_u_24 = "KillCardLook"
	local v25, v26 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_24
		return p_u_4.cctx.shared[v_u_24]
	end)
	if not v25 or type(v26) ~= "table" then
		v26 = nil
	end
	v23.look = v26
	local v_u_27 = "KillCardArt"
	local v28, v29 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_27
		return p_u_4.cctx.shared[v_u_27]
	end)
	if not v28 or type(v29) ~= "table" then
		v29 = nil
	end
	v23.kcArt = v29
	local v_u_30 = "KillCardFrames"
	local v31, v32 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_30
		return p_u_4.cctx.shared[v_u_30]
	end)
	if not v31 or type(v32) ~= "table" then
		v32 = nil
	end
	v23.kcFrames = v32
	local v_u_33 = "SkinIcons"
	local v34, v35 = pcall(function()
		-- upvalues: (copy) p_u_4, (copy) v_u_33
		return p_u_4.cctx.shared[v_u_33]
	end)
	if not v34 or type(v35) ~= "table" then
		v35 = nil
	end
	v23.icons = v35
	function v23.slotOf(p36) -- name: slotOf
		-- upvalues: (copy) v_u_11
		local v37
		if v_u_11 then
			local v38 = v_u_11.get
			if type(v38) == "function" then
				v37 = v_u_11.get(p36)
			else
				v37 = nil
			end
		else
			v37 = nil
		end
		if type(v37) == "table" then
			return v37.slot
		else
			return nil
		end
	end
	function v23.finishOf(p39) -- name: finishOf
		-- upvalues: (copy) v_u_11, (copy) v_u_14
		local v40
		if v_u_11 then
			local v41 = v_u_11.get
			if type(v41) == "function" then
				v40 = v_u_11.get(p39)
			else
				v40 = nil
			end
		else
			v40 = nil
		end
		local v42
		if type(v40) == "table" and v_u_14 then
			local v43 = v_u_14.get
			if type(v43) == "function" then
				v42 = v_u_14.get(v40.finish)
			else
				v42 = nil
			end
		else
			v42 = nil
		end
		if type(v42) == "table" then
			local v44 = v42.swatch
			if type(v44) == "table" then
				return v42.swatch[1]
			end
		end
		return nil
	end
	return v8.plan(p5, v23)
end
function v_u_1.kindIcon(p_u_45, p46, p47, p48, p49, p50) -- name: kindIcon
	local v51 = p_u_45.ui
	local v_u_52 = "PassTileLook"
	local v53, v54 = pcall(function()
		-- upvalues: (copy) p_u_45, (copy) v_u_52
		return p_u_45.cctx.shared[v_u_52]
	end)
	if not v53 or type(v54) ~= "table" then
		v54 = nil
	end
	local v55 = not v54 and "loot" or v54.kindGlyph(p47)
	return v51.icon(v55, {
		["parent"] = p46,
		["size"] = p48,
		["color"] = p49,
		["position"] = p50
	})
end
function v_u_1.draw(p_u_56, p57, p58, p59, p60) -- name: draw
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_61 = p_u_56.ui
	local v62 = p_u_56.theme
	local v63 = v62.color
	local v64 = type(p60) ~= "table" and {} or p60
	local v_u_65
	if type(p59) == "number" and (p59 == p59 and p59 < 4000) then
		local v66 = math.floor(p59)
		v_u_65 = math.max(16, v66)
	else
		v_u_65 = 64
	end
	local v_u_67 = "PassTileLook"
	local v68, v69 = pcall(function()
		-- upvalues: (copy) p_u_56, (copy) v_u_67
		return p_u_56.cctx.shared[v_u_67]
	end)
	if not v68 or type(v69) ~= "table" then
		v69 = nil
	end
	local v70
	if v69 then
		v70 = v_u_1.plan(p_u_56, p58)
	else
		v70 = nil
	end
	local v71 = v62.rarityColor
	local v72
	if type(p58) == "table" then
		local v73 = p58.rarity
		v72 = type(v73) ~= "number" and 1 or p58.rarity
	else
		v72 = 1
	end
	local v74 = v71(v72)
	local v_u_75 = v_u_61.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.88,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Name"] = v64.name or "Art",
		["BackgroundColor3"] = v74,
		["Size"] = UDim2.fromOffset(v_u_65, v_u_65)
	}, p57)
	if v64.position then
		v_u_75.Position = v64.position
	end
	if v64.anchor then
		v_u_75.AnchorPoint = v64.anchor
	end
	v_u_61.stroke(v_u_75, v74, 1, 0.65)
	if v70 == nil then
		v_u_75:SetAttribute("ArtMode", "none")
		return v_u_75
	end
	v_u_75:SetAttribute("ArtMode", v70.mode)
	if v70.mode == "image" then
		v_u_61.new("ImageLabel", {
			["Name"] = "Picture",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Image"] = nil,
			["ScaleType"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Image"] = v70.image,
			["ScaleType"] = Enum.ScaleType.Fit
		}, v_u_75)
		return v_u_75
	end
	if v70.mode == "glyph" then
		local v76 = v_u_61.icon
		local v77 = v70.glyph
		local v78 = {
			["parent"] = v_u_75
		}
		local v79 = v_u_65 * 0.6
		v78.size = math.floor(v79)
		v78.color = v74
		local v80 = v76(v77, v78)
		v80.AnchorPoint = Vector2.new(0.5, 0.5)
		v80.Position = UDim2.fromScale(0.5, 0.5)
		return v_u_75
	end
	if v70.mode ~= "trophy" then
		if v70.mode == "pack" then
			if #v70.items == 0 then
				local v81 = v_u_61.icon
				local v82 = v70.glyph
				local v83 = {
					["parent"] = v_u_75
				}
				local v84 = v_u_65 * 0.6
				v83.size = math.floor(v84)
				v83.color = v74
				local v85 = v81(v82, v83)
				v85.AnchorPoint = Vector2.new(0.5, 0.5)
				v85.Position = UDim2.fromScale(0.5, 0.5)
				return v_u_75
			end
			local v86 = v69.chipRects(#v70.items, v_u_65)
			local v_u_87
			if v64.itemRenders == true then
				local v_u_88 = "ItemIcons"
				local v89
				v89, v_u_87 = pcall(function()
					-- upvalues: (copy) p_u_56, (copy) v_u_88
					return p_u_56.cctx.lib[v_u_88]
				end)
				if not v89 or type(v_u_87) ~= "table" then
					v_u_87 = nil
				end
			else
				v_u_87 = nil
			end
			for v90, v91 in v70.items do
				local v92 = v86.rects[v90]
				local v93 = v_u_61.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["ClipsDescendants"] = true,
					["Name"] = "Chip" .. v90,
					["BackgroundColor3"] = v63.raised2
				}, v_u_75)
				v93.Position = UDim2.fromOffset(v92.x, v92.y)
				v93.Size = UDim2.fromOffset(v92.w, v92.h)
				v_u_61.stroke(v93, v63.line, 1, 0.2)
				local v94 = false
				if v_u_87 then
					local v95 = v_u_87.get
					if type(v95) == "function" then
						local v96 = v_u_87.get
						local v97 = v91.id
						local v98 = {
							["parent"] = nil,
							["size"] = nil,
							["position"] = nil,
							["zindex"] = 2,
							["parent"] = v93,
							["size"] = UDim2.fromScale(1, 1),
							["position"] = UDim2.fromOffset(0, 0)
						}
						local v99, v_u_100 = pcall(v96, v97, false, v98)
						if v99 and typeof(v_u_100) == "Instance" then
							v94 = true
							local v101 = v64.track
							if type(v101) == "function" then
								v64.track(function()
									-- upvalues: (copy) v_u_87, (copy) v_u_100
									local v102 = v_u_87.release
									local v103 = v_u_100
									pcall(v102, v103)
								end)
							end
						end
					end
				end
				if not v94 then
					local v104 = v_u_61.icon
					local v105 = v91.glyph
					local v106 = {
						["parent"] = v93
					}
					local v107 = v92.w * 0.58
					local v108 = math.floor(v107)
					v106.size = math.max(8, v108)
					v106.color = v63.text
					local v109 = v104(v105, v106)
					v109.AnchorPoint = Vector2.new(0.5, 0.5)
					v109.Position = UDim2.fromScale(0.5, 0.5)
				end
				if not v86.showCount or v91.n <= 1 then
					continue
				end
				local v110 = v_u_61.label
				local v111 = {
					["parent"] = nil,
					["name"] = "Count",
					["text"] = nil,
					["style"] = "micro",
					["textSize"] = 10,
					["color"] = nil,
					["align"] = "right",
					["valign"] = "bottom",
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["zindex"] = 3,
					["parent"] = v93
				}
				local v112 = v91.n
				v111.text = "x" .. tostring(v112)
				v111.color = v63.accent
				v111.position = UDim2.fromOffset(0, 0)
				v111.size = UDim2.new(1, -3, 1, -1)
				v110(v111).TextTruncate = Enum.TextTruncate.AtEnd
			end
			if v70.more and (v70.more > 0 and v_u_65 >= 48) then
				local v113 = v_u_61.label
				local v114 = {
					["parent"] = nil,
					["name"] = "More",
					["text"] = nil,
					["style"] = "micro",
					["textSize"] = 10,
					["color"] = nil,
					["align"] = "right",
					["valign"] = "bottom",
					["size"] = nil,
					["track"] = false,
					["parent"] = v_u_75
				}
				local v115 = v70.more
				v114.text = "+" .. tostring(v115)
				v114.color = v63.text2
				v114.size = UDim2.new(1, -3, 1, -1)
				v113(v114).TextTruncate = Enum.TextTruncate.AtEnd
				return v_u_75
			end
		else
			if v70.mode == "finish" then
				if v70.tint then
					local v116 = v70.tint
					v74 = Color3.fromRGB(v116[1], v116[2], v116[3])
				end
				if v70.icon ~= nil then
					v_u_61.new("ImageLabel", {
						["Name"] = "Icon",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ImageRectOffset"] = nil,
						["ImageRectSize"] = nil,
						["ScaleType"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Image"] = v70.icon.image,
						["ImageRectOffset"] = Vector2.new(v70.icon.x, v70.icon.y),
						["ImageRectSize"] = Vector2.new(v70.icon.w, v70.icon.h),
						["ScaleType"] = Enum.ScaleType.Fit,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Size"] = UDim2.fromScale(0.86, 0.86)
					}, v_u_75)
					return v_u_75
				end
				local v117 = v_u_61.icon
				local v118 = {
					["parent"] = v_u_75
				}
				local v119 = v_u_65 * 0.66
				v118.size = math.floor(v119)
				v118.color = v74
				local v120 = v117("weapon", v118)
				v120.AnchorPoint = Vector2.new(0.5, 0.5)
				v120.Position = UDim2.fromScale(0.5, 0.5)
				v120.Position = UDim2.new(0.5, 0, 0.46, 0)
				local v121 = v_u_61.new("Frame", {
					["Name"] = "Swatch",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = v74
				}, v_u_75)
				local v122 = UDim2.fromOffset
				local v123 = v_u_65 * 0.2
				local v124 = math.floor(v123)
				local v125 = v_u_65 * 0.8
				v121.Position = v122(v124, (math.floor(v125)))
				local v126 = UDim2.fromOffset
				local v127 = v_u_65 * 0.6
				local v128 = math.floor(v127)
				local v129 = v_u_65 * 0.05
				local v130 = math.floor(v129)
				v121.Size = v126(v128, (math.max(2, v130)))
				return v_u_75
			end
			if v70.mode == "title" then
				local v131 = v69.titleFit(v70.text, v_u_65)
				if v131.size > 0 then
					v_u_61.label({
						["parent"] = nil,
						["name"] = "Title",
						["text"] = nil,
						["style"] = "h3",
						["textSize"] = nil,
						["color"] = nil,
						["align"] = "center",
						["valign"] = "center",
						["size"] = nil,
						["track"] = false,
						["parent"] = v_u_75,
						["text"] = table.concat(v131.lines, "\n"),
						["textSize"] = v131.size,
						["color"] = v74,
						["size"] = UDim2.fromScale(1, 1)
					}).TextTruncate = Enum.TextTruncate.AtEnd
					for _, v132 in { 0.16, 0.82 } do
						local v133 = v_u_61.new("Frame", {
							["Name"] = "Rule",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.4,
							["BorderSizePixel"] = 0,
							["BackgroundColor3"] = v74
						}, v_u_75)
						local v134 = UDim2.fromOffset
						local v135 = v_u_65 * 0.3
						local v136 = math.floor(v135)
						local v137 = v_u_65 * v132
						v133.Position = v134(v136, (math.floor(v137)))
						local v138 = UDim2.fromOffset
						local v139 = v_u_65 * 0.4
						local v140 = math.floor(v139)
						local v141 = v_u_65 / 64
						local v142 = math.floor(v141)
						v133.Size = v138(v140, (math.max(1, v142)))
					end
					return v_u_75
				end
				local v143 = v_u_61.icon
				local v144 = {
					["parent"] = v_u_75
				}
				local v145 = v_u_65 * 0.56
				v144.size = math.floor(v145)
				v144.color = v74
				local v146 = v143("star", v144)
				v146.AnchorPoint = Vector2.new(0.5, 0.5)
				v146.Position = UDim2.fromScale(0.5, 0.5)
				return v_u_75
			end
			if v70.mode == "card" then
				local v147 = v69.cardRect(v_u_65)
				local v148 = v_u_61.new
				local v149 = {
					["Name"] = "Card",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ClipsDescendants"] = true
				}
				local v150 = v70.card.stops[1]
				v149.BackgroundColor3 = Color3.fromRGB(v150[1], v150[2], v150[3])
				local v151 = v148("Frame", v149, v_u_75)
				v151.Position = UDim2.fromOffset(v147.x, v147.y)
				v151.Size = UDim2.fromOffset(v147.w, v147.h)
				local v152 = v_u_61.new
				local v153 = {
					["Rotation"] = 90,
					["Color"] = nil
				}
				local v154 = ColorSequence.new
				local v155 = v70.card.stops[1]
				v153.Color = v154(Color3.fromRGB(v155[1], v155[2], v155[3]), v_u_3(v70.card.stops[2]))
				v152("UIGradient", v153, v151)
				local v156 = v70.card.px * v_u_65 / 96 + 0.5
				local v157 = math.floor(v156)
				local v158 = math.clamp(v157, 1, 6)
				if v70.card.frameImage == nil then
					local v159 = v_u_61.stroke
					local v160 = v70.card.stroke
					v159(v151, Color3.fromRGB(v160[1], v160[2], v160[3]), v158, 0)
				end
				if v70.card.glow then
					local v161 = v_u_61.new("Frame", {
						["Name"] = "Glow",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0
					}, v_u_75)
					v161.Position = UDim2.fromOffset(v147.x - 2, v147.y - 2)
					v161.Size = UDim2.fromOffset(v147.w + 4, v147.h + 4)
					local v162 = v_u_61.stroke
					local v163 = v70.card.stroke
					v162(v161, Color3.fromRGB(v163[1], v163[2], v163[3]), 1, 0.6)
				end
				local v164
				if v70.card.base == nil then
					v164 = false
				else
					v164 = true
					v_u_61.new("ImageLabel", {
						["Name"] = "Base",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ScaleType"] = nil,
						["Size"] = nil,
						["ZIndex"] = 1,
						["Image"] = v70.card.base,
						["ScaleType"] = Enum.ScaleType.Crop,
						["Size"] = UDim2.fromScale(1, 1)
					}, v151)
					if v70.card.fore ~= nil then
						v_u_61.new("ImageLabel", {
							["Name"] = "Fore",
							["BackgroundTransparency"] = 1,
							["BorderSizePixel"] = 0,
							["Image"] = nil,
							["ScaleType"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Image"] = v70.card.fore,
							["ScaleType"] = Enum.ScaleType.Crop,
							["Size"] = UDim2.fromScale(1, 1)
						}, v151)
					end
				end
				if v70.card.still ~= nil then
					v_u_61.new("ImageLabel", {
						["Name"] = "Still",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ScaleType"] = nil,
						["Size"] = nil,
						["ZIndex"] = 2,
						["Image"] = v70.card.still,
						["ScaleType"] = Enum.ScaleType.Fit,
						["Size"] = UDim2.fromScale(1, 1)
					}, v151)
					v164 = true
				end
				if v70.card.frameImage ~= nil then
					local v_u_165 = "KillCardArt"
					local v166, v167 = pcall(function()
						-- upvalues: (copy) p_u_56, (copy) v_u_165
						return p_u_56.cctx.shared[v_u_165]
					end)
					if not v166 or type(v167) ~= "table" then
						v167 = nil
					end
					if v167 ~= nil then
						local v168 = v167.sliceRect
						if type(v168) == "function" then
							local v169 = v167.sliceScale
							if type(v169) == "function" then
								local v170 = v167.sliceRect()
								v_u_61.new("ImageLabel", {
									["Name"] = "FrameImage",
									["BackgroundTransparency"] = 1,
									["BorderSizePixel"] = 0,
									["Image"] = nil,
									["ScaleType"] = nil,
									["SliceCenter"] = nil,
									["SliceScale"] = nil,
									["Size"] = nil,
									["ZIndex"] = 3,
									["Image"] = v70.card.frameImage,
									["ScaleType"] = Enum.ScaleType.Slice,
									["SliceCenter"] = Rect.new(v170[1], v170[2], v170[3], v170[4]),
									["SliceScale"] = v167.sliceScale(v147.w, v147.h),
									["Size"] = UDim2.fromScale(1, 1)
								}, v151)
								v164 = true
							end
						end
					end
				end
				if not v164 then
					local v171 = v70.card.part == "kc_anim" and "hand" or "skull"
					local v172 = v_u_61.icon
					local v173 = {
						["parent"] = v151
					}
					local v174 = v147.w * 0.5
					local v175 = math.floor(v174)
					v173.size = math.max(8, v175)
					if v70.card.part ~= "kc_anim" then
						local v176 = v70.card.stroke
						v74 = Color3.fromRGB(v176[1], v176[2], v176[3])
					end
					v173.color = v74
					local v177 = v172(v171, v173)
					v177.AnchorPoint = Vector2.new(0.5, 0.5)
					v177.Position = UDim2.fromScale(0.5, 0.5)
				end
			end
		end
		return v_u_75
	end
	local v_u_178 = v69.trophyRects(v_u_65)
	local v179 = v74:Lerp(Color3.new(1, 1, 1), 0.35)
	local v180 = v74:Lerp(Color3.new(0, 0, 0), 0.35)
	local function v189(p181, p182, p183) -- name: part
		-- upvalues: (copy) v_u_61, (copy) v_u_75, (copy) v_u_178, (copy) v_u_65
		local v184 = v_u_61.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Name"] = p181,
			["BackgroundColor3"] = p182,
			["BackgroundTransparency"] = p183 and 1 or 0
		}, v_u_75)
		local v185 = v_u_178[p181]
		v184.Position = UDim2.fromOffset(v185.x, v185.y)
		v184.Size = UDim2.fromOffset(v185.w, v185.h)
		if p183 then
			local v186 = v_u_61.stroke
			local v187 = v_u_65 / 24
			local v188 = math.floor(v187)
			v186(v184, p182, math.max(1, v188), 0)
		end
		return v184
	end
	v189("handleL", v180, true)
	v189("handleR", v180, true)
	local v190 = v_u_61.new("Frame", {
		["Name"] = "stem",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v180
	}, v_u_75)
	local v191 = v_u_178.stem
	v190.Position = UDim2.fromOffset(v191.x, v191.y)
	v190.Size = UDim2.fromOffset(v191.w, v191.h)
	local v192 = v_u_61.new("Frame", {
		["Name"] = "base",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v180
	}, v_u_75)
	local v193 = v_u_178.base
	v192.Position = UDim2.fromOffset(v193.x, v193.y)
	v192.Size = UDim2.fromOffset(v193.w, v193.h)
	local v194 = v_u_61.new("Frame", {
		["Name"] = "bowl",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v74
	}, v_u_75)
	local v195 = v_u_178.bowl
	v194.Position = UDim2.fromOffset(v195.x, v195.y)
	v194.Size = UDim2.fromOffset(v195.w, v195.h)
	local v196 = v_u_61.new("Frame", {
		["Name"] = "rim",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v179
	}, v_u_75)
	local v197 = v_u_178.rim
	v196.Position = UDim2.fromOffset(v197.x, v197.y)
	v196.Size = UDim2.fromOffset(v197.w, v197.h)
	return v_u_75
end
return v_u_1