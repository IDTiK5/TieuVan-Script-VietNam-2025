-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PaidHide

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("PaidItems"))
local v_u_5 = {
	["NOTICE"] = v_u_4.NOTICE
}
local v_u_6 = v2.LocalPlayer
local v_u_7 = nil
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_5.hiddenModel(p10) -- name: hiddenModel
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	return v_u_4.hiddenBySummary(p10:GetAttribute("PaidAny"), p10:GetAttribute("PaidFor"), p10:GetAttribute("LockTo"), v_u_6.UserId, v_u_6:GetAttribute("PaidTrading") == true)
end
local function v_u_28(p11, p12) -- name: hideInstance
	-- upvalues: (copy) v_u_8
	if p12:IsA("BasePart") then
		local v13 = p12.LocalTransparencyModifier
		local v14 = v_u_8[p11]
		if v14 then
			local v15 = v14[p12]
			if not v15 then
				v15 = {}
				v14[p12] = v15
			end
			if v15.LocalTransparencyModifier == nil then
				v15.LocalTransparencyModifier = v13
			end
		end
		local v16 = p12.CastShadow
		local v17 = v_u_8[p11]
		if v17 then
			local v18 = v17[p12]
			if not v18 then
				v18 = {}
				v17[p12] = v18
			end
			if v18.CastShadow == nil then
				v18.CastShadow = v16
			end
		end
		p12.LocalTransparencyModifier = 1
		p12.CastShadow = false
		return
	elseif p12:IsA("Decal") or p12:IsA("Texture") then
		local v19 = p12.Transparency
		local v20 = v_u_8[p11]
		if v20 then
			local v21 = v20[p12]
			if not v21 then
				v21 = {}
				v20[p12] = v21
			end
			if v21.Transparency == nil then
				v21.Transparency = v19
			end
		end
		p12.Transparency = 1
		return
	elseif p12:IsA("ProximityPrompt") then
		local v22 = p12.Enabled
		local v23 = v_u_8[p11]
		if v23 then
			local v24 = v23[p12]
			if not v24 then
				v24 = {}
				v23[p12] = v24
			end
			if v24.Enabled == nil then
				v24.Enabled = v22
			end
		end
		p12.Enabled = false
	elseif p12:IsA("Light") or (p12:IsA("ParticleEmitter") or (p12:IsA("Beam") or (p12:IsA("Trail") or (p12:IsA("Highlight") or (p12:IsA("BillboardGui") or p12:IsA("SurfaceGui")))))) then
		local v25 = p12.Enabled
		local v26 = v_u_8[p11]
		if v26 then
			local v27 = v26[p12]
			if not v27 then
				v27 = {}
				v26[p12] = v27
			end
			if v27.Enabled == nil then
				v27.Enabled = v25
			end
		end
		p12.Enabled = false
	end
end
local function v_u_35(p_u_29) -- name: hide
	-- upvalues: (copy) v_u_8, (copy) v_u_28, (copy) v_u_6, (copy) v_u_9
	if not v_u_8[p_u_29] then
		v_u_8[p_u_29] = {}
		for _, v30 in p_u_29:GetDescendants() do
			v_u_28(p_u_29, v30)
		end
		local v31 = 0
		for _ in v_u_8 do
			v31 = v31 + 1
		end
		local v32 = v_u_6
		local v33 = "PaidHidden"
		if v31 <= 0 then
			v31 = nil
		end
		v32:SetAttribute(v33, v31)
		if v_u_9[p_u_29] == nil then
			v_u_9[p_u_29] = true
			p_u_29.DescendantAdded:Connect(function(p34)
				-- upvalues: (ref) v_u_8, (copy) p_u_29, (ref) v_u_28
				if v_u_8[p_u_29] then
					v_u_28(p_u_29, p34)
				end
			end)
		end
	end
end
local function v_u_45(p36) -- name: show
	-- upvalues: (copy) v_u_8, (copy) v_u_6
	local v37 = v_u_8[p36]
	if v37 then
		v_u_8[p36] = nil
		local v38 = 0
		for _ in v_u_8 do
			v38 = v38 + 1
		end
		local v39 = v_u_6
		local v40 = "PaidHidden"
		if v38 <= 0 then
			v38 = nil
		end
		v39:SetAttribute(v40, v38)
		for v_u_41, v42 in v37 do
			if not v_u_41.Parent then
				continue
			end
			for v_u_43, v_u_44 in v42 do
				pcall(function()
					-- upvalues: (copy) v_u_41, (copy) v_u_43, (copy) v_u_44
					v_u_41[v_u_43] = v_u_44
				end)
			end
		end
	end
end
local function v_u_49(p_u_46) -- name: track
	-- upvalues: (copy) v_u_5, (copy) v_u_35, (copy) v_u_45
	if p_u_46:IsA("Model") then
		if p_u_46:IsA("Model") then
			if v_u_5.hiddenModel(p_u_46) then
				v_u_35(p_u_46)
			else
				v_u_45(p_u_46)
			end
		end
		for _, v47 in { "PaidAny", "PaidFor", "LockTo" } do
			p_u_46:GetAttributeChangedSignal(v47):Connect(function()
				-- upvalues: (copy) p_u_46, (ref) v_u_5, (ref) v_u_35, (ref) v_u_45
				local v48 = p_u_46
				if v48:IsA("Model") then
					if v_u_5.hiddenModel(v48) then
						v_u_35(v48)
					else
						v_u_45(v48)
					end
				else
					return
				end
			end)
		end
	end
end
function v_u_5.hiddenCount() -- name: hiddenCount
	-- upvalues: (copy) v_u_8
	local v50 = 0
	for _ in v_u_8 do
		v50 = v50 + 1
	end
	return v50
end
function v_u_5.start(p51) -- name: start
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (copy) v_u_49, (copy) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_35, (copy) v_u_45
	if not v_u_7 then
		v_u_7 = p51
		v_u_1:GetInstanceAddedSignal("HushItem"):Connect(v_u_49)
		v_u_1:GetInstanceRemovedSignal("HushItem"):Connect(function(p52)
			-- upvalues: (ref) v_u_8, (ref) v_u_6
			if p52:IsA("Model") then
				v_u_8[p52] = nil
				local v53 = 0
				for _ in v_u_8 do
					v53 = v53 + 1
				end
				local v54 = v_u_6
				local v55 = "PaidHidden"
				if v53 <= 0 then
					v53 = nil
				end
				v54:SetAttribute(v55, v53)
			end
		end)
		for _, v56 in v_u_1:GetTagged("HushItem") do
			v_u_49(v56)
		end
		v_u_6:GetAttributeChangedSignal("PaidTrading"):Connect(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_5, (ref) v_u_35, (ref) v_u_45
			for _, v57 in v_u_1:GetTagged("HushItem") do
				if not v57:IsA("Model") then
					continue
				end
				if v_u_5.hiddenModel(v57) then
					v_u_35(v57)
				else
					v_u_45(v57)
				end
			end
		end)
		if p51.command then
			p51.command("paidhide.state", function()
				-- upvalues: (ref) v_u_1, (ref) v_u_8, (ref) v_u_6
				local v58 = 0
				local v59 = 0
				for _, v60 in v_u_1:GetTagged("HushItem") do
					v58 = v58 + 1
					if not v_u_8[v60] then
						continue
					end
					v59 = v59 + 1
				end
				local v61 = v_u_6
				return ("PaidTrading=%s items=%d hidden=%d"):format(tostring(v61:GetAttribute("PaidTrading")), v58, v59)
			end)
		end
	end
end
return v_u_5