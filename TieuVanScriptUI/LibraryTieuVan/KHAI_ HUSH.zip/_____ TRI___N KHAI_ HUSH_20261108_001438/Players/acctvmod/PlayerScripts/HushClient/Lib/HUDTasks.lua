-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDTasks

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = {}
local v_u_5
if script and (script.Parent and script.Parent:FindFirstChild("TaskFold")) then
	v_u_5 = require(script.Parent.TaskFold)
else
	v_u_5 = nil
end
local v_u_6
if script and (script.Parent and script.Parent:FindFirstChild("TaskPlaceNames")) then
	v_u_6 = require(script.Parent.TaskPlaceNames)
else
	v_u_6 = nil
end
local v_u_7 = {
	["stillwater"] = "STILLWATER",
	["hollow"] = "THE HOLLOW"
}
local function v11()
	-- upvalues: (copy) v_u_3, (ref) v_u_7
	local v8 = v_u_3:WaitForChild("Hush", 5)
	if v8 then
		v8 = v8:WaitForChild("Shared", 5)
	end
	if v8 then
		v8 = v8:WaitForChild("Tasks", 5)
	end
	local v9
	if v8 then
		v9 = require(v8)
	else
		v9 = nil
	end
	if v9 then
		local v10 = v9.MAP_TAGS
		if type(v10) == "table" then
			v_u_7 = v9.MAP_TAGS
		end
	end
end
pcall(v11)
local function v_u_17(p12) -- name: mapTag
	-- upvalues: (ref) v_u_7, (copy) v_u_6
	local v13 = p12.map
	local v14
	if type(v13) == "string" then
		v14 = v_u_7[p12.map] or string.upper(p12.map)
		if v_u_6 then
			local v15 = p12.room
			if type(v15) == "string" then
				v14 = v_u_6.tag(v14, p12.map, p12.room)
			end
		end
	else
		v14 = nil
	end
	local v16 = p12.cond
	if type(v16) == "string" and p12.cond ~= "" then
		if v14 then
			return v14 .. "  \194\183  " .. p12.cond
		end
		v14 = p12.cond
	end
	return v14
end
local v_u_18 = nil
local v_u_19 = nil
local function v22()
	-- upvalues: (copy) v_u_3, (ref) v_u_18, (ref) v_u_19
	local v20 = v_u_3:WaitForChild("Hush", 5)
	if v20 then
		v20 = v20:WaitForChild("Shared", 5)
	end
	local v21
	if v20 then
		v21 = v20:WaitForChild("Tasks", 5)
	else
		v21 = v20
	end
	if v20 then
		v20 = v20:WaitForChild("TaskConds", 5)
	end
	if v21 and v20 then
		v_u_18 = require(v21)
		v_u_19 = require(v20)
	end
end
pcall(v22)
function v4.new(p_u_23) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_2, (ref) v_u_19, (ref) v_u_18, (copy) v_u_17
	local v_u_24 = p_u_23.UI
	local v_u_25 = p_u_23.Theme
	local v_u_26 = v_u_25.color
	local v_u_27 = v_u_1.LocalPlayer
	local v_u_28 = {}
	local v_u_29 = nil
	local v_u_30 = false
	local v_u_31 = false
	local v_u_32 = {}
	local v_u_33 = true
	local v_u_34 = ""
	local v_u_35 = {}
	local v_u_36 = false
	local v_u_37 = nil
	local v_u_38 = ""
	local function v_u_41() -- name: curLevel
		-- upvalues: (ref) v_u_5, (copy) p_u_23, (copy) v_u_27
		if v_u_5 == nil then
			return "full"
		end
		local v_u_39 = true
		local function v40()
			-- upvalues: (ref) v_u_39, (ref) p_u_23
			v_u_39 = p_u_23.cctx.config.flag("TaskFold") ~= false
		end
		pcall(v40)
		return v_u_5.effective(v_u_27:GetAttribute(v_u_5.ATTR), v_u_27:GetAttribute(v_u_5.SETTING_ATTR), v_u_39)
	end
	local v_u_42 = v_u_24.new("Frame", {
		["Name"] = "Tasks",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -40, 0, v_u_24.topInset() + 64),
		["Size"] = UDim2.fromOffset(300, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_23.root)
	local v_u_43 = v_u_24.new("UIListLayout", {
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 6),
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Right
	}, v_u_42)
	local function v_u_50(p44) -- name: decode
		-- upvalues: (copy) v_u_27, (ref) v_u_2
		local v45 = v_u_27:GetAttribute(p44)
		if type(v45) ~= "string" or v45 == "" then
			return {}
		end
		local v46 = v_u_2.JSONDecode
		local v47 = v_u_2
		local v48, v49 = pcall(v46, v47, v45)
		return (not v48 or type(v49) ~= "table") and {} or v49
	end
	local function v_u_63(p51) -- name: rowText
		-- upvalues: (copy) v_u_26
		local v52 = p51.have
		local v53 = tonumber(v52) or 0
		local v54 = p51.need
		local v55 = ("%d / %d"):format(v53, tonumber(v54) or 1)
		local v56 = v_u_26.accent
		if p51.contract == true then
			v56 = v_u_26.info
		end
		if p51.off == true then
			v56 = v_u_26.muted
		end
		local v57 = p51.kind == "handover"
		if p51.done == true then
			v56 = v_u_26.success
			if not v57 then
				v55 = "DONE"
			end
		else
			local v58 = p51.pend
			if (tonumber(v58) or 0) > 0 then
				v55 = v55 .. ("  +%d"):format(p51.pend)
			end
		end
		local v59 = p51.desc or ""
		local v60 = tostring(v59)
		if p51.done == true and not v57 then
			local v61 = p51.giver or "the trader"
			v60 = "Report to " .. tostring(v61) .. " after the raid"
		else
			local v62 = p51.pend
			if (tonumber(v62) or 0) > 0 then
				v60 = v60 .. " (extract to count)"
			end
		end
		return v60, v55, v56
	end
	local function v_u_134() -- name: build
		-- upvalues: (copy) v_u_42, (copy) v_u_41, (ref) v_u_38, (ref) v_u_5, (ref) v_u_32, (ref) v_u_31, (ref) v_u_19, (ref) v_u_18, (ref) v_u_37, (copy) v_u_24, (ref) v_u_30, (copy) v_u_26, (copy) v_u_28, (copy) v_u_63, (copy) v_u_35, (ref) v_u_17, (copy) v_u_25, (copy) v_u_27
		for _, v64 in v_u_42:GetChildren() do
			if not v64:IsA("GuiObject") then
				continue
			end
			v64:Destroy()
		end
		local v65 = v_u_41()
		v_u_38 = v65
		local v66
		if v_u_5 then
			v66 = v_u_5.view(v65, #v_u_32, v_u_31)
		else
			v66 = {
				["kind"] = "rows",
				["rows"] = nil
			}
			local v67
			if v_u_31 then
				local v68 = #v_u_32
				v67 = math.min(1, v68)
			else
				v67 = #v_u_32
			end
			v66.rows = v67
		end
		local v69 = v_u_31 or v65 == "compact"
		local v70 = v66.rows
		local v71
		if v_u_19 == nil or v_u_18 == nil then
			v71 = false
		else
			v71 = v_u_19.enabled()
		end
		v_u_37 = nil
		if v66.kind == "chip" then
			local v72 = v_u_24.new(v_u_30 and "TextButton" or "Frame", {
				["Name"] = "Chip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["BackgroundColor3"] = v_u_26.bg,
				["Size"] = UDim2.new(1, 0, 0, 26)
			}, v_u_42)
			if v_u_30 then
				v72.Text = ""
				v72.AutoButtonColor = false
				v72.Selectable = false
			end
			v_u_24.stroke(v72, v_u_26.line, 1, 0.4)
			v_u_24.new("Frame", {
				["Name"] = "Edge",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_26.accent,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}, v72)
			v_u_24.label({
				["parent"] = nil,
				["name"] = "Line",
				["text"] = nil,
				["style"] = "small",
				["textSize"] = 12,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v72,
				["text"] = v_u_5.chipText(#v_u_32),
				["color"] = v_u_26.text,
				["position"] = UDim2.fromOffset(10, 0),
				["size"] = UDim2.new(1, -20, 1, 0)
			})
			if v_u_30 then
				v72.Activated:Connect(function()
					-- upvalues: (ref) v_u_28
					v_u_28.fold("tap")
				end)
			end
		end
		for v73 = 1, v70 do
			local v74 = v_u_32[v73]
			local v75, v76, v77 = v_u_63(v74)
			local v78 = v74.item
			local v79
			if type(v78) == "string" and (v74.item ~= "" and v74.done ~= true) then
				local v80 = v74.pend
				if (tonumber(v80) or 0) == 0 then
					v79 = "ITEM: " .. v74.item
				else
					v79 = nil
				end
			else
				v79 = nil
			end
			local v81
			if v71 and v74.contract ~= true then
				v81 = v_u_19.rowParts(v74, v_u_18, v75)
			else
				v81 = nil
			end
			local v82
			if v81 and not v69 then
				v82 = #v_u_19.plain(v81) * 5.7 > 214
			else
				v82 = false
			end
			local v83 = v74.id
			local v84 = tostring(v83)
			local v85
			if v_u_35[v84] == nil then
				v85 = false
			else
				local v86 = v_u_35[v84]
				local v87 = v74.have
				local v88 = tonumber(v87) or 0
				local v89 = v74.pend
				v85 = v86 ~= v88 + (tonumber(v89) or 0)
			end
			local v90 = v_u_35
			local v91 = v74.have
			local v92 = tonumber(v91) or 0
			local v93 = v74.pend
			v90[v84] = v92 + (tonumber(v93) or 0)
			local v94 = v_u_24.new(v_u_30 and "TextButton" or "Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.25,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Row" .. v73,
				["BackgroundColor3"] = v_u_26.bg,
				["Size"] = UDim2.new(1, 0, 0, v69 and 26 or (v79 and 14 or 0) + 46 + (v82 and 14 or 0)),
				["LayoutOrder"] = v73
			}, v_u_42)
			local v95 = v_u_24.stroke
			local v96
			if v85 then
				v96 = v_u_26.accent
			else
				v96 = v_u_26.line
			end
			local v_u_97 = v95(v94, v96, 1, v85 and 0 or 0.4)
			if v_u_30 then
				v94.Text = ""
				v94.AutoButtonColor = false
				v94.Selectable = false
				v94.Activated:Connect(function()
					-- upvalues: (ref) v_u_28
					v_u_28.fold("tap")
				end)
			end
			v_u_24.new("Frame", {
				["Name"] = "Edge",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v77,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}, v94)
			if v69 then
				local v98
				if v74.off == true then
					v98 = v_u_17(v74)
				else
					v98 = nil
				end
				local v99 = v74.title
				local v100 = ("%s  \194\183  %s"):format(tostring(v99), v75)
				local v101 = not v98 and "" or v98 .. "  \194\183  "
				if v79 and v74.kind ~= "boss" then
					v75 = v79
				elseif not v_u_25.isPhone() or #v100 <= 28 then
					v75 = v100
				end
				local v102 = v101 .. v75
				local v103
				if v81 and (not v79 or v74.kind == "boss") then
					local v104 = {}
					local v105 = (v_u_42.Size.X.Offset - 78) / 5.3
					local v106 = math.floor(v105)
					local v107 = math.max(12, v106)
					local v108 = not v98 and "" or v98 .. "  \194\183  "
					local v109
					if v_u_25.isPhone() and #v100 > 28 then
						v109 = ""
					else
						local v110 = v74.title
						v109 = tostring(v110) .. "  \194\183  "
					end
					local v111 = utf8.len(v_u_19.plain(v81)) or 0
					local v112 = v108 .. v109
					if v107 < (utf8.len(v112) or #v112) + v111 then
						v112 = v108
					end
					local v113 = v107 < (utf8.len(v112) or #v112) + v111 and "" or v112
					if v113 ~= "" then
						table.insert(v104, {
							["text"] = nil,
							["kind"] = "plain",
							["text"] = v113
						})
					end
					for _, v114 in v81 do
						table.insert(v104, v114)
					end
					v103 = v_u_19.richFor(v_u_19.elide(v104, v107), v_u_25)
					v_u_37 = v_u_42.Size.X.Offset
				else
					v103 = nil
				end
				v_u_24.label({
					["parent"] = nil,
					["name"] = "Line",
					["text"] = nil,
					["rich"] = nil,
					["style"] = "small",
					["textSize"] = 12,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v94,
					["text"] = v103 or v102,
					["rich"] = v103 ~= nil,
					["color"] = v_u_26.text,
					["position"] = UDim2.fromOffset(10, 0),
					["size"] = UDim2.new(1, -78, 1, 0)
				})
				v_u_24.label({
					["parent"] = nil,
					["name"] = "Count",
					["text"] = nil,
					["style"] = "mono",
					["textSize"] = 12,
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v94,
					["text"] = v76,
					["color"] = v77,
					["position"] = UDim2.new(1, -8, 0, 0),
					["anchor"] = Vector2.new(1, 0),
					["size"] = UDim2.new(0, 64, 1, 0)
				})
			else
				local v115 = v74.contract == true and "CONTRACT" or v_u_17(v74)
				local v116
				if v115 then
					local v117 = #v115 * 7 + 6
					v116 = math.clamp(v117, 70, 150)
				else
					v116 = 0
				end
				local v118 = v_u_24.label
				local v119 = {
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "caps",
					["textSize"] = 11,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v94
				}
				local v120 = v74.title
				local v121 = tostring(v120)
				local v122 = v74.giver or ""
				v119.text = ("%s  \194\183  %s"):format(v121, (tostring(v122)))
				v119.color = v77
				v119.position = UDim2.fromOffset(10, 4)
				v119.size = UDim2.new(1, -20 - v116, 0, 14)
				v118(v119)
				if v115 then
					v_u_24.label({
						["parent"] = nil,
						["name"] = "MapTag",
						["text"] = nil,
						["style"] = "caps",
						["textSize"] = 10,
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v94,
						["text"] = v115,
						["color"] = v_u_26.text2,
						["position"] = UDim2.new(1, -10 - v116, 0, 4),
						["size"] = UDim2.fromOffset(v116, 14)
					})
				end
				local v123
				if v81 then
					v123 = v_u_19.richFor(v81, v_u_25)
				else
					v123 = nil
				end
				v_u_24.label({
					["parent"] = nil,
					["name"] = "Desc",
					["text"] = nil,
					["rich"] = nil,
					["style"] = "small",
					["textSize"] = 13,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["wrap"] = nil,
					["valign"] = nil,
					["track"] = false,
					["parent"] = v94,
					["text"] = v123 or v75,
					["rich"] = v123 ~= nil,
					["color"] = v_u_26.text,
					["position"] = UDim2.fromOffset(10, 20),
					["size"] = UDim2.new(1, -86, 0, v82 and 32 or 18),
					["wrap"] = v82 or nil,
					["valign"] = v82 and "top" or nil
				})
				if v79 then
					v_u_24.label({
						["parent"] = nil,
						["name"] = "ItemChip",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 12,
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["track"] = false,
						["parent"] = v94,
						["text"] = v79,
						["color"] = v_u_26.accent,
						["position"] = UDim2.fromOffset(10, v82 and 52 or 38),
						["size"] = UDim2.new(1, -20, 0, 14)
					})
				end
				v_u_24.label({
					["parent"] = nil,
					["name"] = "Count",
					["text"] = nil,
					["style"] = "mono",
					["textSize"] = 13,
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["anchor"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v94,
					["text"] = v76,
					["color"] = v77,
					["position"] = UDim2.new(1, -10, 0, 20),
					["anchor"] = Vector2.new(1, 0),
					["size"] = UDim2.new(0, 72, 0, 18)
				})
				local v124 = v74.have
				local v125 = tonumber(v124) or 0
				local v126 = v74.need
				local v127 = tonumber(v126) or 1
				local v128 = v125 / math.max(1, v127)
				local v129 = math.clamp(v128, 0, 1)
				local v130 = v_u_24.new("Frame", {
					["Name"] = "Track",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_26.line,
					["Position"] = UDim2.new(0, 10, 1, -5),
					["Size"] = UDim2.new(1, -20, 0, 2)
				}, v94)
				v_u_24.new("Frame", {
					["Name"] = "Fill",
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["BackgroundColor3"] = v77,
					["Size"] = UDim2.fromScale(v129, 1)
				}, v130)
			end
			if not v85 then
				continue
			end
			task.delay(1.2, function()
				-- upvalues: (copy) v_u_97, (ref) v_u_24, (ref) v_u_26
				if v_u_97.Parent then
					v_u_24.tween(v_u_97, {
						["Color"] = nil,
						["Transparency"] = 0.4,
						["Color"] = v_u_26.line
					}, "slow")
				end
			end)
		end
		local v131 = #v_u_32 - v70
		v_u_27:SetAttribute("HudTasksMore", (math.max(0, v131)))
		local v132
		if v131 > 0 and v66.kind == "rows" then
			if v_u_19 then
				local v133 = v_u_19.moreText
				if type(v133) == "function" then
					v132 = v_u_19.moreText(v131)
					if v132 then
						v_u_24.label({
							["parent"] = nil,
							["name"] = "More",
							["text"] = nil,
							["style"] = "small",
							["textSize"] = 11,
							["color"] = nil,
							["order"] = nil,
							["size"] = nil,
							["align"] = "right",
							["track"] = false,
							["parent"] = v_u_42,
							["text"] = v132,
							["color"] = v_u_26.text2,
							["order"] = v70 + 1,
							["size"] = UDim2.new(1, 0, 0, 14)
						})
					end
				else
					v132 = ("+%d more"):format(v131)
					if v132 then
						v_u_24.label({
							["parent"] = nil,
							["name"] = "More",
							["text"] = nil,
							["style"] = "small",
							["textSize"] = 11,
							["color"] = nil,
							["order"] = nil,
							["size"] = nil,
							["align"] = "right",
							["track"] = false,
							["parent"] = v_u_42,
							["text"] = v132,
							["color"] = v_u_26.text2,
							["order"] = v70 + 1,
							["size"] = UDim2.new(1, 0, 0, 14)
						})
					end
				end
			else
				v132 = ("+%d more"):format(v131)
				if v132 then
					v_u_24.label({
						["parent"] = nil,
						["name"] = "More",
						["text"] = nil,
						["style"] = "small",
						["textSize"] = 11,
						["color"] = nil,
						["order"] = nil,
						["size"] = nil,
						["align"] = "right",
						["track"] = false,
						["parent"] = v_u_42,
						["text"] = v132,
						["color"] = v_u_26.text2,
						["order"] = v70 + 1,
						["size"] = UDim2.new(1, 0, 0, 14)
					})
				end
				return
			end
		else
			v132 = nil
			if v132 then
				v_u_24.label({
					["parent"] = nil,
					["name"] = "More",
					["text"] = nil,
					["style"] = "small",
					["textSize"] = 11,
					["color"] = nil,
					["order"] = nil,
					["size"] = nil,
					["align"] = "right",
					["track"] = false,
					["parent"] = v_u_42,
					["text"] = v132,
					["color"] = v_u_26.text2,
					["order"] = v70 + 1,
					["size"] = UDim2.new(1, 0, 0, 14)
				})
			end
			return
		end
	end
	local function v_u_138() -- name: placeDesktop
		-- upvalues: (copy) p_u_23, (copy) v_u_42, (copy) v_u_24, (copy) v_u_43
		local v135 = p_u_23.freeTag
		local v136 = p_u_23.eventBarH
		local v137 = type(v136) ~= "number" and 0 or p_u_23.eventBarH
		v_u_42.AnchorPoint = Vector2.new(1, 0)
		v_u_42.Position = UDim2.new(1, -40, 0, v_u_24.topInset() + (v135 and v135.Parent and 94 or 64) + v137)
		v_u_42.Size = UDim2.fromOffset(300, 0)
		v_u_43.HorizontalAlignment = Enum.HorizontalAlignment.Right
	end
	local function v_u_177() -- name: placeTouch
		-- upvalues: (copy) p_u_23, (copy) v_u_25, (copy) v_u_42, (copy) v_u_43, (ref) v_u_33
		local v139 = p_u_23.touchFrame
		if v139 then
			v139 = p_u_23.touchFrame()
		end
		if v139 then
			if v_u_25.isPhone() then
				local v140 = p_u_23.bandOffset
				local v141 = type(v140) ~= "function" and 0 or p_u_23.bandOffset("Tasks")
				local v142 = v139.listY
				local v143
				if type(v142) == "number" then
					v143 = v139.listY
				else
					v143 = v139.top + 96
				end
				local v144 = v143 + v141
				local v145 = v139.listW
				local v146 = (type(v145) ~= "number" and 260 or v139.listW) - 20
				local v147 = math.clamp(v146, 200, 300)
				v_u_42.AnchorPoint = Vector2.new(0, 0)
				local v148 = v_u_42
				local v149 = UDim2.fromOffset
				local v150 = v139.bandLeft or v139.left
				v148.Position = v149(math.floor(v150), (math.floor(v144)))
				v_u_42.Size = UDim2.fromOffset(v147, 0)
				v_u_43.HorizontalAlignment = Enum.HorizontalAlignment.Left
				local v151 = v139.listBottom
				v_u_33 = type(v151) ~= "number" and true or v144 + 26 <= v139.listBottom + 2
				if v139.corner then
					local v152 = p_u_23.cctx.lib.HudLayout
					local v153, v154 = v152.fractions("Tasks")
					if v153 and v154 then
						v_u_42.Position = v152.position("Tasks", v_u_42.Position)
						v_u_33 = true
					end
				end
			else
				v_u_33 = true
				local v155 = v139.listY
				local v_u_156
				if type(v155) == "number" then
					v_u_156 = v139.listY
				else
					v_u_156 = v139.top + 96
				end
				local function v161()
					-- upvalues: (ref) p_u_23, (ref) v_u_156, (ref) v_u_25
					local v157 = p_u_23.root:FindFirstChild("EventBar")
					if v157 and (v157:IsA("GuiObject") and (v157.Visible and v157.AbsoluteSize.Y > 2)) then
						local v158 = v_u_156
						local v159 = v157.AbsoluteSize.Y
						local v160 = v_u_25.uiScale
						v_u_156 = v158 + (v159 / math.max(0.01, v160()) + 6)
					end
				end
				pcall(v161)
				local v162 = v139.listW
				local v163 = (type(v162) ~= "number" and 260 or v139.listW) - 20
				local v164 = math.clamp(v163, 200, 300)
				v_u_42.AnchorPoint = Vector2.new(0, 0)
				local v165 = v_u_42
				local v166 = UDim2.fromOffset
				local v167 = v139.left
				local v168 = v_u_156
				v165.Position = v166(math.floor(v167), (math.floor(v168)))
				v_u_42.Size = UDim2.fromOffset(v164, 0)
				v_u_43.HorizontalAlignment = Enum.HorizontalAlignment.Left
				local v169 = v139.listBottom
				if type(v169) == "number" and v_u_156 + 26 > v139.listBottom then
					local v170 = v_u_42
					local v171 = UDim2.fromOffset
					local v172 = v139.left
					local v173 = math.floor(v172)
					local v174 = v139.top + 40
					local v175 = v139.listBottom - 26
					local v176 = math.max(v174, v175)
					v170.Position = v171(v173, (math.floor(v176)))
				end
			end
		else
			return
		end
	end
	local function v_u_180(p178) -- name: setShown
		-- upvalues: (ref) v_u_36, (copy) v_u_27, (copy) v_u_42, (copy) v_u_24
		if p178 == v_u_36 then
			return
		else
			v_u_36 = p178
			v_u_27:SetAttribute("HudTasksShown", p178)
			if p178 then
				v_u_42.Visible = true
				v_u_24.fade(v_u_42, 0, "fast", {
					["from"] = 1
				})
			else
				local v179 = {
					["onDone"] = function() -- name: onDone
						-- upvalues: (ref) v_u_36, (ref) v_u_42
						if not v_u_36 then
							v_u_42.Visible = false
						end
					end
				}
				v_u_24.fade(v_u_42, 1, "fast", v179)
			end
		end
	end
	local function v_u_187() -- name: refresh
		-- upvalues: (copy) v_u_27, (copy) v_u_41, (ref) v_u_34, (ref) v_u_38, (ref) v_u_32, (copy) v_u_50, (copy) v_u_134
		local v181 = v_u_27:GetAttribute("TaskTrack")
		local v182 = type(v181) ~= "string" and "" or v181
		local v183 = v_u_27:GetAttribute("ContractTrack")
		if type(v183) == "string" and v183 ~= "" then
			v182 = v182 .. "|" .. v183
		end
		local v184 = v_u_41()
		if v182 ~= v_u_34 or v184 ~= v_u_38 then
			v_u_34 = v182
			local v185 = v_u_50("TaskTrack")
			for _, v186 in v_u_50("ContractTrack") do
				table.insert(v185, v186)
			end
			v_u_32 = v185
			v_u_134()
		end
	end
	function v_u_28.fold(p188) -- name: fold
		-- upvalues: (ref) v_u_5, (copy) v_u_41, (copy) v_u_27, (copy) v_u_187
		if v_u_5 == nil then
			return "full"
		end
		local v189 = v_u_41()
		local v190
		if p188 == "tap" then
			v190 = v_u_5.tap(v189)
		else
			v190 = v_u_5.cycle(v189)
		end
		v_u_27:SetAttribute(v_u_5.ATTR, v190)
		v_u_187()
		return v190
	end
	function v_u_28.layout(p191) -- name: layout
		-- upvalues: (ref) v_u_30, (copy) v_u_25, (ref) v_u_31, (copy) v_u_177, (copy) v_u_138, (ref) v_u_34, (copy) v_u_187
		local v192 = v_u_30
		v_u_30 = p191
		local v_u_193 = false
		local function v194()
			-- upvalues: (ref) v_u_193, (ref) v_u_25
			v_u_193 = v_u_25.viewport().Y < 600
		end
		pcall(v194)
		local v195 = v_u_31
		v_u_31 = p191 or v_u_193
		if v_u_30 then
			v_u_177()
		else
			v_u_138()
		end
		if v195 ~= v_u_31 or v192 ~= p191 then
			v_u_34 = ""
			v_u_187()
		end
	end
	function v_u_28.setCharacter(p196) -- name: setCharacter
		-- upvalues: (ref) v_u_29
		v_u_29 = p196
	end
	local v_u_197 = 1
	function v_u_28.update(p198) -- name: update
		-- upvalues: (ref) v_u_197, (copy) v_u_187, (ref) v_u_30, (copy) v_u_177, (copy) v_u_138, (ref) v_u_37, (copy) v_u_42, (ref) v_u_34, (copy) p_u_23, (ref) v_u_36, (copy) v_u_27, (copy) v_u_180, (ref) v_u_32, (copy) v_u_41, (ref) v_u_29, (ref) v_u_33
		v_u_197 = v_u_197 + p198
		if v_u_197 >= 0.25 then
			v_u_197 = 0
			v_u_187()
			if v_u_30 then
				v_u_177()
			else
				v_u_138()
			end
			if v_u_37 then
				local v199 = v_u_42.Size.X.Offset - v_u_37
				if math.abs(v199) > 2 then
					v_u_34 = ""
					v_u_187()
				end
			end
			local v200 = p_u_23.mods
			if v200 then
				v200 = p_u_23.mods.HUDClock
			end
			local v201 = false
			local v202
			if v200 then
				v202 = v200.bandBusy or v200.isShown
			else
				v202 = nil
			end
			if v202 then
				local v203
				v201, v203 = pcall(v202)
				if v201 then
					v201 = v203 == true
				end
			end
			if v201 and v_u_36 then
				v_u_36 = false
				v_u_42.Visible = false
				v_u_27:SetAttribute("HudTasksShown", false)
			end
			local v204 = v_u_180
			local v205
			if #v_u_32 > 0 and v_u_41() ~= "off" then
				local v206 = v_u_29 or v_u_27.Character
				local v207
				if v206 == nil then
					v207 = false
				else
					v207 = v206:GetAttribute("Dead") == true and true or v206:GetAttribute("Downed") == true
				end
				v205 = not (v207 or v201)
				if v205 then
					v205 = v_u_33 or not v_u_30
				end
			else
				v205 = false
			end
			v204(v205)
			local v208 = v_u_27
			local v209 = "HudTasksWaiting"
			local v210 = v_u_30 and not v_u_33
			if v210 then
				v210 = #v_u_32 > 0
			end
			v208:SetAttribute(v209, v210)
		end
	end
	function v_u_28.state() -- name: state
		-- upvalues: (ref) v_u_32, (ref) v_u_36, (ref) v_u_31, (copy) v_u_41
		local v211 = v_u_36
		local v212 = v_u_31
		return ("rows=%d shown=%s compact=%s level=%s"):format(#v_u_32, tostring(v211), tostring(v212), v_u_41())
	end
	local v_u_213 = nil
	local v_u_214
	if v_u_5 == nil then
		v_u_214 = nil
	else
		v_u_27:SetAttribute(v_u_5.ATTR, nil)
		local function v220()
			-- upvalues: (copy) p_u_23, (ref) v_u_213, (copy) v_u_28, (ref) v_u_30, (ref) v_u_36, (copy) v_u_42
			local v_u_215 = p_u_23.cctx.controllers.Input
			if v_u_215 then
				local v216 = v_u_215.bind
				if type(v216) == "function" then
					v_u_213 = v_u_215.bind("tasks", function()
						-- upvalues: (ref) v_u_28
						v_u_28.fold("key")
					end)
				end
			end
			if v_u_215 then
				local v217 = v_u_215.setTapRect
				if type(v217) == "function" then
					v_u_215.setTapRect("tasks", function()
						-- upvalues: (ref) v_u_30, (ref) v_u_36, (ref) v_u_42, (copy) v_u_215
						if not (v_u_30 and (v_u_36 and v_u_42.Visible)) then
							return nil
						end
						local v218 = v_u_215.touch
						if v218 then
							v218 = v_u_215.touch()
						end
						if v218 then
							v218 = v218.root
						end
						if not (v218 and v218:IsA("GuiObject")) then
							return nil
						end
						local v219 = v_u_42.AbsolutePosition - v218.AbsolutePosition
						return Rect.new(v219, v219 + v_u_42.AbsoluteSize)
					end)
				end
			end
		end
		pcall(v220)
		v_u_214 = v_u_27:GetAttributeChangedSignal(v_u_5.SETTING_ATTR):Connect(function()
			-- upvalues: (copy) v_u_27, (ref) v_u_5, (copy) v_u_187
			v_u_27:SetAttribute(v_u_5.ATTR, nil)
			v_u_187()
		end)
	end
	function v_u_28.destroy() -- name: destroy
		-- upvalues: (ref) v_u_213, (ref) v_u_214, (copy) p_u_23, (copy) v_u_42
		if v_u_213 then
			local v221 = v_u_213
			pcall(v221)
			v_u_213 = nil
		end
		if v_u_214 then
			v_u_214:Disconnect()
			v_u_214 = nil
		end
		local function v224()
			-- upvalues: (ref) p_u_23
			local v222 = p_u_23.cctx.controllers.Input
			if v222 then
				local v223 = v222.setTapRect
				if type(v223) == "function" then
					v222.setTapRect("tasks", nil)
				end
			end
		end
		pcall(v224)
		v_u_42:Destroy()
	end
	v_u_187()
	return v_u_28
end
return v4