-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketTradeKit

local v_u_1 = {}
local v_u_2 = game:GetService("Players")
function v_u_1.section(p3, p4, p5, p6, p7) -- name: section
	local v8 = p3.ui
	local v9 = p3.C
	local v10 = v8.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Section_" .. p5,
		["Size"] = UDim2.new(1, 0, 0, 24),
		["LayoutOrder"] = p6
	}, p4)
	v8.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["track"] = false,
		["parent"] = v10,
		["text"] = p5,
		["color"] = v9.text2,
		["position"] = UDim2.fromOffset(2, 0),
		["size"] = UDim2.new(0.6, 0, 1, 0)
	})
	if p7 ~= nil then
		v8.label({
			["parent"] = nil,
			["name"] = "Right",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v10,
			["text"] = p7,
			["color"] = v9.text2,
			["position"] = UDim2.fromScale(0.4, 0),
			["size"] = UDim2.fromScale(0.6, 1)
		})
	end
	v8.new("Frame", {
		["Name"] = "Line",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v9.line,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}, v10)
	return v10
end
function v_u_1.tallyChip(p_u_11, p12, p13, p14) -- name: tallyChip
	local v15 = p_u_11.ui
	local v16 = p_u_11.C
	local v17 = p_u_11.theme
	local v18 = p14 or {}
	local v_u_19 = "TallyMark"
	local v20, v21 = pcall(function()
		-- upvalues: (copy) p_u_11, (copy) v_u_19
		return p_u_11.mc.cctx.lib[v_u_19]
	end)
	if not v20 or type(v21) ~= "table" then
		v21 = nil
	end
	local v_u_22 = "TallyRules"
	local v23, v24 = pcall(function()
		-- upvalues: (copy) p_u_11, (copy) v_u_22
		return p_u_11.mc.cctx.shared[v_u_22]
	end)
	if not v23 or type(v24) ~= "table" then
		v24 = nil
	end
	local v25 = 0
	if v24 ~= nil then
		local v26 = v24.level
		if type(v26) == "function" then
			local v27 = v24.level
			local v28, v29 = pcall(v27, p13)
			v25 = (not v28 or type(v29) ~= "number") and 0 or v29
		end
	end
	local v30 = v16.accent
	local v31
	if v21 == nil then
		v31 = v30
	else
		local v32 = v21.colorOf
		if type(v32) == "function" then
			local v33 = v21.colorOf
			local v34
			v34, v31 = pcall(v33, v25, v17)
			if v34 then
				if typeof(v31) ~= "Color3" then
					v31 = v30
				end
			else
				v31 = v30
			end
		else
			v31 = v30
		end
	end
	local v35 = "TALLY " .. tostring(p13)
	local v36
	if v21 == nil then
		v36 = v35
	else
		local v37 = v21.chipText
		if type(v37) == "function" then
			local v38 = v21.chipText
			local v39
			v39, v36 = pcall(v38, p13)
			if v39 then
				if type(v36) ~= "string" then
					v36 = v35
				end
			else
				v36 = v35
			end
		else
			v36 = v35
		end
	end
	local v40 = v15.new("Frame", {
		["Name"] = "TallyChip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v16.bgDeep,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, v18.h or 18),
		["LayoutOrder"] = v18.order or 0
	}, p12)
	v15.stroke(v40, v31, 1, 0.3)
	v15.pad(v40, {
		5,
		6,
		0,
		0
	})
	v15.layout(v40, "h", 4)
	if v21 ~= nil then
		local v41 = v21.new
		if type(v41) == "function" then
			local v42 = v15.new("Frame", {
				["Name"] = "Mark",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Size"] = UDim2.fromOffset(14, 14)
			}, v40)
			local v43 = v21.new
			local v44, v45 = pcall(v43, v42, {
				["size"] = 14,
				["level"] = nil,
				["level"] = v25
			})
			if not v44 or v45 == nil then
				v42:Destroy()
			end
		end
	end
	v15.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["track"] = false,
		["order"] = 2,
		["parent"] = v40,
		["text"] = v36,
		["color"] = v31,
		["size"] = UDim2.fromOffset(0, v18.h or 18)
	})
	return v40
end
function v_u_1.row(p_u_46, p47, p_u_48, p_u_49) -- name: row
	-- upvalues: (copy) v_u_1
	local v50 = p_u_46.ui
	local v51 = p_u_46.C
	local v52 = p_u_46.theme
	local v53 = p_u_46.h
	local v54 = p_u_49.h or 52
	local v_u_55 = {}
	local v56 = p_u_48.mark
	local v57
	if v56 == "NEW" then
		v57 = p_u_46.C.success
	elseif v56 == "CHANGED" then
		v57 = p_u_46.C.accent
	else
		v57 = nil
	end
	local v58 = v50.new("Frame", {
		["Name"] = "Row",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v51.raised,
		["Size"] = UDim2.new(1, 0, 0, v54),
		["LayoutOrder"] = p_u_49.order or 0
	}, p47)
	v50.stroke(v58, v57 or v51.line)
	v58:SetAttribute("Kind", p_u_48.kind)
	v58:SetAttribute("Key", p_u_48.key)
	v58:SetAttribute("Mark", p_u_48.mark or "")
	local v59 = p_u_49.compact == true
	local v60 = v59 and 4 or 6
	local v61 = v54 - v60 * 2
	if p_u_48.kind == "skin" then
		local v_u_62 = "SkinTile"
		local v63, v64 = pcall(function()
			-- upvalues: (copy) p_u_46, (copy) v_u_62
			return p_u_46.mc.cctx.lib[v_u_62]
		end)
		if not v63 or type(v64) ~= "table" then
			v64 = nil
		end
		local v65 = false
		if v64 ~= nil then
			local v66 = v64.new
			if type(v66) == "function" then
				local v_u_67 = "Skins"
				local v68, v69 = pcall(function()
					-- upvalues: (copy) p_u_46, (copy) v_u_67
					return p_u_46.mc.cctx.shared[v_u_67]
				end)
				if not v68 or type(v69) ~= "table" then
					v69 = nil
				end
				local v70
				if v69 == nil then
					v70 = nil
				else
					v70 = v69.get(p_u_48.skinId)
				end
				local v71 = v64.new
				local v72 = {
					["light"] = true,
					["size"] = nil,
					["weaponId"] = nil,
					["skinId"] = nil,
					["name"] = "Tile",
					["position"] = nil,
					["size"] = v61
				}
				local v73
				if v70 then
					v73 = v70.weapon
				else
					v73 = nil
				end
				v72.weaponId = v73
				v72.skinId = p_u_48.skinId
				v72.position = UDim2.fromOffset(6, v60)
				local v74, v_u_75 = pcall(v71, v58, v72)
				if v74 and v_u_75 ~= nil then
					table.insert(v_u_55, function()
						-- upvalues: (copy) v_u_75
						local v76 = v_u_75.destroy
						pcall(v76)
					end)
					v65 = true
				end
			end
		end
		if not v65 then
			v50.new("Frame", {
				["Name"] = "Tile",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.6,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v51.accent,
				["Position"] = UDim2.fromOffset(6, v60),
				["Size"] = UDim2.fromOffset(v61, v61)
			}, v58)
		end
	else
		local _, v77 = v53.icon(v58, p_u_48.id, v61, {
			["position"] = UDim2.fromOffset(6, v60)
		})
		table.insert(v_u_55, v77)
	end
	local v78 = 6 + v61 + 10
	local v79 = (not p_u_49.remove and 6 or v52.touch(40) + 8) + (p_u_48.qty == "" and 0 or 46)
	local v80 = (not p_u_49.remove and 6 or v52.touch(40) + 8) + 2
	if v59 then
		v50.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v58,
			["text"] = p_u_48.name,
			["color"] = v51.text,
			["position"] = UDim2.fromOffset(v78, 0),
			["size"] = UDim2.new(0.42, -v78, 1, 0)
		})
	else
		v50.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "bodyStrong",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v58,
			["text"] = p_u_48.name,
			["color"] = v51.text,
			["position"] = UDim2.fromOffset(v78, 5),
			["size"] = UDim2.new(1, -(v78 + v79), 0, 22)
		})
	end
	if p_u_48.qty ~= "" then
		v50.label({
			["parent"] = nil,
			["name"] = "Qty",
			["text"] = nil,
			["style"] = "mono",
			["color"] = nil,
			["align"] = "right",
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v58,
			["text"] = p_u_48.qty,
			["color"] = v51.accent,
			["anchor"] = Vector2.new(1, v59 and 0.5 or 0),
			["position"] = UDim2.new(1, -v80, v59 and 0.5 or 0, v59 and 0 or 5),
			["size"] = UDim2.fromOffset(44, 22)
		})
	end
	local v81 = v50.new
	local v82 = "Frame"
	local v83 = {
		["Name"] = "Line2",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil
	}
	local v84
	if v59 then
		v84 = UDim2.new(0.42, 0, 0, 0)
	else
		v84 = UDim2.fromOffset(v78, 28)
	end
	v83.Position = v84
	local v85
	if v59 then
		v85 = UDim2.new(0.58, -(v80 + (p_u_48.qty == "" and 0 or 48)), 1, 0)
	else
		v85 = UDim2.new(1, -(v78 + (not p_u_49.remove and 6 or v52.touch(40) + 8)), 0, 20)
	end
	v83.Size = v85
	local v86 = v81(v82, v83, v58)
	v50.layout(v86, "h", 6, v59 and "right" or nil)
	local v87 = 0
	local v88
	if p_u_48.mark == nil then
		v88 = v87
	else
		local v89 = v53.pill
		local v90 = p_u_48.mark
		local v91 = v57 or v51.accent
		local v92 = {
			["name"] = "Mark",
			["order"] = nil,
			["h"] = 18,
			["solid"] = true
		}
		v87 = v87 + 1
		v92.order = v87
		v89(v86, v90, v91, v92)
		v88 = v87
	end
	if p_u_48.tally ~= nil then
		local v93 = v_u_1.tallyChip
		local v94 = p_u_48.tally
		local v95 = {}
		v87 = v88 + 1
		v95.order = v87
		v93(p_u_46, v86, v94, v95)
		v88 = v87
	end
	local v96 = {}
	local v97 = p_u_48.sub
	if type(v97) == "string" and p_u_48.sub ~= "" then
		local v98 = p_u_48.sub
		table.insert(v96, v98)
	end
	if p_u_48.firLost then
		local v99 = p_u_46.View.TEXT.firLost
		table.insert(v96, v99)
	end
	if #v96 > 0 then
		local v100 = v50.label
		local v101 = {
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["order"] = nil,
			["parent"] = v86,
			["text"] = table.concat(v96, ", ")
		}
		local v102
		if p_u_48.firLost then
			v102 = v51.accent
		else
			v102 = v51.text2
		end
		v101.color = v102
		v101.size = UDim2.new(1, -(p_u_48.tally == nil and 0 or 150) - (p_u_48.mark == nil and 0 or 70), 0, 20)
		v87 = v88 + 1
		v101.order = v87
		v100(v101)
	end
	local v103 = {
		["frame"] = v58
	}
	if p_u_49.remove then
		v103.remove = v50.iconButton({
			["parent"] = nil,
			["icon"] = "close",
			["size"] = nil,
			["kind"] = "ghost",
			["name"] = "Remove",
			["anchor"] = nil,
			["position"] = nil,
			["onClick"] = nil,
			["parent"] = v58,
			["size"] = v52.touch(40),
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -4, 0.5, 0),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_49, (copy) p_u_48
				p_u_49.remove(p_u_48)
			end
		})
	end
	function v103.release() -- name: release
		-- upvalues: (copy) v_u_55
		for _, v104 in v_u_55 do
			pcall(v104)
		end
		table.clear(v_u_55)
	end
	return v103
end
function v_u_1.cashRow(p105, p106, p107, p108, p109) -- name: cashRow
	local v110 = p105.ui
	local v111 = p105.C
	local v112 = p109 or {}
	local v113 = v112.h or 44
	local v114 = v112.mark
	local v115
	if v114 == "NEW" then
		v115 = p105.C.success
	elseif v114 == "CHANGED" then
		v115 = p105.C.accent
	else
		v115 = nil
	end
	local v116 = v110.new("Frame", {
		["Name"] = "CashRow",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v111.raised,
		["Size"] = UDim2.new(1, 0, 0, v113),
		["LayoutOrder"] = p108
	}, p106)
	v110.stroke(v116, v115 or v111.line)
	v110.label({
		["parent"] = nil,
		["name"] = "Label",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v116,
		["text"] = p105.View.TEXT.cash,
		["color"] = v111.text2,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.fromOffset(60, v113)
	})
	v110.label({
		["parent"] = nil,
		["name"] = "Value",
		["text"] = nil,
		["style"] = "monoL",
		["textSize"] = 20,
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["track"] = false,
		["parent"] = v116,
		["text"] = p107,
		["color"] = v111.accent,
		["position"] = UDim2.fromOffset(76, 0),
		["size"] = UDim2.new(1, -((v112.mark and 90 or 12) + 76), 1, 0)
	})
	if v112.mark ~= nil then
		p105.h.pill(v116, v112.mark, v115 or v111.accent, {
			["name"] = "Mark",
			["solid"] = true,
			["h"] = 18,
			["anchor"] = nil,
			["position"] = nil,
			["anchor"] = Vector2.new(1, 0.5),
			["position"] = UDim2.new(1, -10, 0.5, 0)
		})
	end
	return v116
end
local function v_u_124(p117, p118) -- name: itemSortKey
	local v119 = p117.h.item(p118.id)
	local v120
	if v119 then
		local v121 = v119.category
		v120 = tostring(v121)
	else
		v120 = "z"
	end
	local v122 = string.lower(p117.h.name(p118.id))
	local v123 = p118.uid
	return v120 .. "|" .. v122 .. "|" .. tostring(v123)
end
function v_u_1.iconNear(p125, p126, p127, p128, p129) -- name: iconNear
	local v130
	if p125 + p126 > p127 - p129 then
		v130 = p125 < p127 + p128 + p129
	else
		v130 = false
	end
	return v130
end
function v_u_1.pickItems(p_u_131, p_u_132) -- name: pickItems
	-- upvalues: (copy) v_u_124, (copy) v_u_1
	local v_u_133 = p_u_131.ui
	local v_u_134 = p_u_131.C
	local v_u_135 = p_u_131.theme
	local v_u_136 = p_u_131.h
	local v_u_137 = p_u_131.View
	local v_u_138 = p_u_132.cases == true
	local v_u_139 = {}
	local v_u_140 = {}
	local v_u_141 = {}
	local v_u_142 = false
	for _, v143 in p_u_132.stash() do
		if type(v143) ~= "table" then
			continue
		end
		local v144 = v143.uid
		if type(v144) ~= "string" then
			continue
		end
		local v145 = v143.id
		if type(v145) ~= "string" or v_u_137.isCase(v143.id) ~= v_u_138 then
			continue
		end
		table.insert(v_u_139, v143)
	end
	table.sort(v_u_139, function(p146, p147)
		-- upvalues: (ref) v_u_124, (copy) p_u_131
		return v_u_124(p_u_131, p146) < v_u_124(p_u_131, p147)
	end)
	local v_u_148 = #v_u_139 == 0
	local v149 = v_u_133.modal
	local v150 = {
		["title"] = nil,
		["width"] = 640,
		["build"] = nil,
		["buttons"] = nil,
		["onClose"] = nil
	}
	local v151
	if v_u_138 then
		v151 = v_u_137.TEXT.pickCaseTitle
	else
		v151 = v_u_137.TEXT.pickItemTitle
	end
	v150.title = v151
	function v150.build(p152) -- name: build
		-- upvalues: (copy) v_u_148, (copy) v_u_133, (copy) v_u_138, (copy) v_u_137, (copy) v_u_134, (copy) v_u_139, (copy) p_u_132, (copy) v_u_135, (copy) v_u_140, (copy) v_u_136, (copy) v_u_141, (copy) p_u_131
		p152.Name = "Pick"
		if v_u_148 then
			local v153 = v_u_133.label
			local v154 = {
				["parent"] = nil,
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 1,
				["parent"] = p152
			}
			local v155
			if v_u_138 then
				v155 = v_u_137.TEXT.pickCasesEmpty
			else
				v155 = v_u_137.TEXT.pickEmpty
			end
			v154.text = v155
			v154.color = v_u_134.text2
			v153(v154)
		else
			for v156, v_u_157 in v_u_139 do
				local v158 = p_u_132.reasonOf
				local v159
				if type(v158) == "function" then
					v159 = p_u_132.reasonOf(v_u_157)
				else
					v159 = nil
				end
				local v160 = v_u_157.n
				local v161 = tonumber(v160) or 1
				local v162 = math.floor(v161)
				local v_u_163 = math.max(1, v162)
				local v_u_164 = v_u_163
				local v165 = v_u_135.touch(54)
				local v166 = v_u_133.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Choice_" .. v_u_157.uid,
					["BackgroundColor3"] = v_u_134.raised,
					["BackgroundTransparency"] = v159 and 0.5 or 0.15,
					["Size"] = UDim2.new(1, 0, 0, v165),
					["LayoutOrder"] = v156
				}, p152)
				v_u_133.stroke(v166, v_u_134.line)
				v166:SetAttribute("Reason", v159 or "")
				local v167 = v_u_140
				local v168 = {
					["f"] = v166,
					["id"] = v_u_157.id,
					["px"] = v165 - 12
				}
				table.insert(v167, v168)
				local v169 = v165 + 2
				local v_u_170 = nil
				local v171
				if v159 == nil then
					v171 = (v_u_163 > 1 and 140 or 0) + 112
					local v172 = {
						["inst"] = v_u_157
					}
					if v_u_163 > 1 then
						local v173 = v_u_133.new("Frame", {
							["Name"] = "Stepper",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(1, 0.5),
							["Position"] = UDim2.new(1, -122, 0.5, 0),
							["Size"] = UDim2.fromOffset(130, v_u_135.touch(40))
						}, v166)
						local v_u_174 = v_u_133.label({
							["parent"] = nil,
							["name"] = "Qty",
							["text"] = nil,
							["style"] = "mono",
							["color"] = nil,
							["align"] = "center",
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v173,
							["text"] = tostring(v_u_164),
							["color"] = v_u_134.text,
							["position"] = UDim2.fromOffset(40, 0),
							["size"] = UDim2.new(1, -80, 1, 0)
						})
						local function v180(p175) -- name: setQty
							-- upvalues: (ref) v_u_164, (copy) v_u_163, (ref) v_u_174, (ref) v_u_170, (ref) v_u_137
							local v176 = v_u_163
							v_u_164 = math.clamp(p175, 1, v176)
							local v177 = v_u_164
							v_u_174.Text = tostring(v177)
							if v_u_170 then
								local v178 = v_u_170.api.setText
								local v179
								if v_u_163 > 1 then
									v179 = ("%s %d"):format(v_u_137.TEXT.pickAdd, v_u_164)
								else
									v179 = v_u_137.TEXT.pickAdd
								end
								v178(v179)
							end
						end
						v_u_133.iconButton({
							["parent"] = nil,
							["icon"] = "chevronLeft",
							["size"] = nil,
							["kind"] = "secondary",
							["name"] = "Less",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v173,
							["size"] = v_u_135.touch(38),
							["position"] = UDim2.fromOffset(0, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_164, (copy) v_u_163, (ref) v_u_174, (ref) v_u_170, (ref) v_u_137
								local v181 = v_u_164 - 1
								local v182 = v_u_163
								v_u_164 = math.clamp(v181, 1, v182)
								local v183 = v_u_164
								v_u_174.Text = tostring(v183)
								if v_u_170 then
									local v184 = v_u_170.api.setText
									local v185
									if v_u_163 > 1 then
										v185 = ("%s %d"):format(v_u_137.TEXT.pickAdd, v_u_164)
									else
										v185 = v_u_137.TEXT.pickAdd
									end
									v184(v185)
								end
							end
						})
						v_u_133.iconButton({
							["parent"] = nil,
							["icon"] = "chevronRight",
							["size"] = nil,
							["kind"] = "secondary",
							["name"] = "More",
							["position"] = nil,
							["onClick"] = nil,
							["parent"] = v173,
							["size"] = v_u_135.touch(38),
							["position"] = UDim2.new(1, -v_u_135.touch(38), 0, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_164, (copy) v_u_163, (ref) v_u_174, (ref) v_u_170, (ref) v_u_137
								local v186 = v_u_164 + 1
								local v187 = v_u_163
								v_u_164 = math.clamp(v186, 1, v187)
								local v188 = v_u_164
								v_u_174.Text = tostring(v188)
								if v_u_170 then
									local v189 = v_u_170.api.setText
									local v190
									if v_u_163 > 1 then
										v190 = ("%s %d"):format(v_u_137.TEXT.pickAdd, v_u_164)
									else
										v190 = v_u_137.TEXT.pickAdd
									end
									v189(v190)
								end
							end
						})
						v172.setQty = v180
					end
					local v191 = p_u_132.inTrade
					local v192
					if type(v191) == "function" then
						v192 = p_u_132.inTrade("item", v_u_157.uid)
					else
						v192 = false
					end
					local v_u_193 = nil
					local v194 = v_u_136.button
					local v195
					if v192 then
						v195 = v_u_137.TEXT.pickAdded
					elseif v_u_163 > 1 then
						v195 = ("%s %d"):format(v_u_137.TEXT.pickAdd, v_u_164)
					else
						v195 = v_u_137.TEXT.pickAdd
					end
					local v200, v201 = v194(v166, v195, v192 and "ghost" or "primary", function()
						-- upvalues: (ref) p_u_132, (copy) v_u_157, (copy) v_u_163, (ref) v_u_164, (ref) v_u_193, (ref) v_u_137
						task.spawn(function()
							-- upvalues: (ref) p_u_132, (ref) v_u_157, (ref) v_u_163, (ref) v_u_164, (ref) v_u_193, (ref) v_u_137
							local v196 = p_u_132.add
							local v197 = "item"
							local v198 = v_u_157.uid
							local v199
							if v_u_163 > 1 then
								v199 = v_u_164
							else
								v199 = nil
							end
							if v196(v197, v198, v199) then
								v_u_193.setEnabled(false)
								v_u_193.setText(v_u_137.TEXT.pickAdded)
							end
						end)
					end, {
						["name"] = "Add",
						["size"] = nil,
						["height"] = nil,
						["anchor"] = nil,
						["position"] = nil,
						["maxTextWidth"] = 92,
						["size"] = UDim2.fromOffset(104, v_u_135.touch(40)),
						["height"] = v_u_135.touch(40),
						["anchor"] = Vector2.new(1, 0.5),
						["position"] = UDim2.new(1, -8, 0.5, 0)
					})
					local v202 = v201
					local v203 = {
						["btn"] = v200,
						["api"] = v202
					}
					v172.add = v203
					if v192 then
						v202.setEnabled(false)
					end
					local v204 = v_u_141
					table.insert(v204, v172)
				else
					v171 = 0
				end
				local v205 = v_u_133.label
				local v206 = {
					["parent"] = nil,
					["name"] = "Name",
					["text"] = nil,
					["style"] = "bodyStrong",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v166,
					["text"] = v_u_136.name(v_u_157.id) .. (v_u_163 <= 1 and "" or "  x" .. tostring(v_u_163))
				}
				local v207
				if v159 then
					v207 = v_u_134.text2
				else
					v207 = v_u_134.text
				end
				v206.color = v207
				v206.position = UDim2.fromOffset(v169, 6)
				v206.size = UDim2.new(1, -(v169 + v171 + 12), 0, 22)
				v205(v206)
				local v208
				if v159 == nil then
					local v209 = p_u_131.condition
					if type(v209) == "function" then
						v208 = p_u_131.condition(v_u_157)
					else
						v208 = nil
					end
				else
					v208 = v159
				end
				if v208 == nil or v208 == "" then
					continue
				end
				local v210 = v_u_133.label
				local v211 = {
					["parent"] = nil,
					["name"] = "Sub",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v166,
					["text"] = v208
				}
				local v212
				if v159 then
					v212 = v_u_134.accent
				else
					v212 = v_u_134.text2
				end
				v211.color = v212
				v211.position = UDim2.fromOffset(v169, 30)
				v211.size = UDim2.new(1, -(v169 + v171 + 12), 0, 18)
				v210(v211)
			end
		end
	end
	v150.buttons = {
		{
			["text"] = nil,
			["kind"] = "primary",
			["text"] = v_u_137.TEXT.cashDone
		}
	}
	function v150.onClose() -- name: onClose
		-- upvalues: (ref) v_u_142, (copy) v_u_140
		v_u_142 = true
		for _, v213 in v_u_140 do
			if v213.rel == nil then
				continue
			end
			local v214 = v213.rel
			pcall(v214)
			v213.rel = nil
		end
	end
	local v_u_215 = v149(v150)
	local v_u_216 = false
	local function v_u_229() -- name: refreshIcons
		-- upvalues: (ref) v_u_216, (ref) v_u_215, (ref) v_u_142, (copy) v_u_140, (ref) v_u_1, (copy) v_u_136
		v_u_216 = false
		local v217
		if v_u_215 == nil then
			v217 = nil
		else
			v217 = v_u_215.body
		end
		if v_u_142 or (v217 == nil or v217.Parent == nil) then
			return
		else
			local v218 = v217:FindFirstAncestorWhichIsA("LayerCollector")
			local v219 = v218 == nil and (1 / 0) or v218.AbsoluteSize.Y
			local v220 = v217.AbsolutePosition.Y
			local v221 = math.max(v220, 0)
			local v222 = v217.AbsolutePosition.Y + v217.AbsoluteWindowSize.Y
			local v223 = math.min(v222, v219) - v221
			if v223 > 1 then
				for _, v224 in v_u_140 do
					local v225 = v224.f
					if v225.Parent == nil then
						continue
					end
					if v_u_1.iconNear(v225.AbsolutePosition.Y, v225.AbsoluteSize.Y, v221, v223, v223 * 0.75) then
						if v224.rel ~= nil then
							continue
						end
						local v226, v227 = v_u_136.icon(v225, v224.id, v224.px, {
							["position"] = UDim2.fromOffset(6, 6)
						})
						v224.box = v226
						v224.rel = v227
					else
						if v224.rel == nil then
							continue
						end
						local v228 = v224.rel
						pcall(v228)
						v224.rel = nil
						v224.box:Destroy()
						v224.box = nil
					end
				end
			end
		end
	end
	local function v230() -- name: wantIcons
		-- upvalues: (ref) v_u_216, (ref) v_u_142, (copy) v_u_229
		if not (v_u_216 or v_u_142) then
			v_u_216 = true
			task.defer(v_u_229)
		end
	end
	if v_u_215 ~= nil and (v_u_215.body ~= nil and #v_u_140 > 0) then
		local v231 = v_u_215.body
		v231:GetPropertyChangedSignal("CanvasPosition"):Connect(v230)
		v231:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v230)
		v231:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v230)
		if not (v_u_216 or v_u_142) then
			v_u_216 = true
			task.defer(v_u_229)
		end
		task.delay(0.2, v230)
	end
	return {
		["modal"] = v_u_215,
		["rows"] = v_u_141,
		["count"] = #v_u_139,
		["slots"] = v_u_140,
		["refreshIcons"] = v_u_229
	}
end
function v_u_1.pickSkins(p_u_232, p_u_233) -- name: pickSkins
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v_u_234 = p_u_232.ui
	local v_u_235 = p_u_232.C
	local v_u_236 = p_u_232.theme
	local v_u_237 = p_u_232.h
	local v_u_238 = p_u_232.View
	local v_u_239 = "Skins"
	local v240, v_u_241 = pcall(function()
		-- upvalues: (copy) p_u_232, (copy) v_u_239
		return p_u_232.mc.cctx.shared[v_u_239]
	end)
	if not v240 or type(v_u_241) ~= "table" then
		v_u_241 = nil
	end
	local v_u_242 = "SkinTile"
	local v243, v_u_244 = pcall(function()
		-- upvalues: (copy) p_u_232, (copy) v_u_242
		return p_u_232.mc.cctx.lib[v_u_242]
	end)
	if not v243 or type(v_u_244) ~= "table" then
		v_u_244 = nil
	end
	local v_u_245 = "MenuCratesCopies"
	local v246, v_u_247 = pcall(function()
		-- upvalues: (copy) p_u_232, (copy) v_u_245
		return p_u_232.mc.cctx.lib[v_u_245]
	end)
	if not v246 or type(v_u_247) ~= "table" then
		v_u_247 = nil
	end
	local v_u_248 = "TallyRules"
	local v249, v_u_250 = pcall(function()
		-- upvalues: (copy) p_u_232, (copy) v_u_248
		return p_u_232.mc.cctx.shared[v_u_248]
	end)
	if not v249 or type(v_u_250) ~= "table" then
		v_u_250 = nil
	end
	local v_u_251 = nil
	local v_u_252 = 0
	local v_u_253 = {}
	local v_u_254 = {
		["step"] = "skins",
		["skin"] = nil
	}
	local function v_u_257() -- name: clear
		-- upvalues: (copy) v_u_253, (ref) v_u_251
		for _, v255 in v_u_253 do
			pcall(v255)
		end
		table.clear(v_u_253)
		if v_u_251 then
			for _, v256 in v_u_251:GetChildren() do
				if v256:IsA("UIListLayout") or v256:IsA("UIPadding") then
					continue
				end
				v256:Destroy()
			end
		end
	end
	local function v_u_270(p258, p259, p260) -- name: tile
		-- upvalues: (copy) v_u_241, (copy) v_u_244, (copy) v_u_253, (copy) v_u_234, (copy) v_u_235
		local v261
		if v_u_241 == nil then
			v261 = nil
		else
			v261 = v_u_241.get(p259)
		end
		if v_u_244 ~= nil then
			local v262 = v_u_244.new
			if type(v262) == "function" then
				local v263 = v_u_244.new
				local v264 = {
					["light"] = true,
					["size"] = nil,
					["weaponId"] = nil,
					["skinId"] = nil,
					["name"] = "Tile",
					["position"] = nil,
					["size"] = p260
				}
				local v265
				if v261 then
					v265 = v261.weapon
				else
					v265 = nil
				end
				v264.weaponId = v265
				v264.skinId = p259
				v264.position = UDim2.fromOffset(6, 6)
				local v266, v_u_267 = pcall(v263, p258, v264)
				if v266 and v_u_267 ~= nil then
					local v268 = v_u_253
					table.insert(v268, function()
						-- upvalues: (copy) v_u_267
						local v269 = v_u_267.destroy
						pcall(v269)
					end)
					return
				end
			end
		end
		v_u_234.new("Frame", {
			["Name"] = "Tile",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.6,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_235.accent,
			["Position"] = UDim2.fromOffset(6, 6),
			["Size"] = UDim2.fromOffset(p260, p260)
		}, p258)
	end
	local v_u_271 = nil
	local function v_u_323(p_u_272, p_u_273)
		-- upvalues: (ref) v_u_252, (copy) v_u_254, (copy) v_u_257, (ref) v_u_251, (copy) v_u_237, (copy) v_u_238, (ref) v_u_271, (copy) v_u_236, (copy) v_u_234, (copy) v_u_241, (copy) v_u_235, (copy) p_u_232, (copy) v_u_247, (ref) v_u_2, (copy) v_u_270, (copy) p_u_233, (ref) v_u_1, (ref) v_u_323
		v_u_252 = v_u_252 + 1
		local v_u_274 = v_u_252
		local v275 = v_u_254
		v_u_254.step = "copies"
		v275.skin = p_u_272
		v_u_257()
		if v_u_251 ~= nil then
			local v_u_276 = v_u_251
			v_u_237.button(v_u_276, v_u_238.TEXT.back, "secondary", function()
				-- upvalues: (ref) v_u_271
				v_u_271()
			end, {
				["name"] = "Back",
				["height"] = nil,
				["width"] = 120,
				["order"] = 1,
				["height"] = v_u_236.touch(40)
			})
			local v277 = v_u_234.label
			local v278 = {
				["parent"] = nil,
				["name"] = "Title",
				["text"] = nil,
				["style"] = "bodyStrong",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 2,
				["parent"] = v_u_276
			}
			local v279
			if v_u_241 == nil then
				v279 = nil
			else
				v279 = v_u_241.get(p_u_272)
			end
			local v280
			if v279 and v_u_241 ~= nil then
				v280 = v_u_241.displayName(v279)
			else
				v280 = p_u_272
			end
			v278.text = v280
			v278.color = v_u_235.text
			v277(v278)
			local v_u_281 = v_u_234.label({
				["parent"] = nil,
				["name"] = "Loading",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 3,
				["parent"] = v_u_276,
				["text"] = v_u_238.TEXT.pickLoading,
				["color"] = v_u_235.text2
			})
			task.spawn(function()
				-- upvalues: (ref) p_u_232, (copy) p_u_272, (copy) p_u_273, (copy) v_u_274, (ref) v_u_252, (ref) v_u_251, (copy) v_u_281, (ref) v_u_234, (copy) v_u_276, (ref) v_u_238, (ref) v_u_235, (ref) v_u_247, (ref) v_u_2, (ref) v_u_236, (ref) v_u_270, (ref) p_u_233, (ref) v_u_1, (ref) v_u_237, (ref) v_u_323
				local v282 = p_u_232.notes.get
				local v283 = {
					["skin"] = p_u_272,
					["offset"] = p_u_273
				}
				local v284 = p_u_273
				v283.id = p_u_272 .. ":" .. tostring(v284)
				local v285 = v282("skinCopies", v283)
				if v_u_274 == v_u_252 and (v_u_251 ~= nil and v_u_251.Parent) then
					v_u_281:Destroy()
					if type(v285) == "table" then
						local v286 = v285.rows
						if type(v286) == "table" then
							local v287 = v285.rows
							local v288
							if v_u_247 == nil then
								v288 = v287
							else
								local v289 = v_u_247.order
								if type(v289) == "function" then
									local v290 = v_u_247.order
									local v291
									v291, v288 = pcall(v290, v287)
									if v291 then
										if type(v288) ~= "table" then
											v288 = v287
										end
									else
										v288 = v287
									end
								else
									v288 = v287
								end
							end
							local v292 = v_u_2.LocalPlayer.UserId
							for v293, v_u_294 in v288 do
								local v295 = v_u_236.touch(54)
								local v296 = v_u_294.eq == true
								local v297 = v_u_234.new
								local v298 = {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = nil,
									["BorderSizePixel"] = 0,
									["Size"] = nil,
									["LayoutOrder"] = nil
								}
								local v299 = v_u_294.uid
								v298.Name = "Copy_" .. tostring(v299)
								v298.BackgroundColor3 = v_u_235.raised
								v298.BackgroundTransparency = v296 and 0.5 or 0.15
								v298.Size = UDim2.new(1, 0, 0, v295)
								v298.LayoutOrder = 10 + v293
								local v300 = v297("Frame", v298, v_u_276)
								v_u_234.stroke(v300, v_u_235.line)
								v300:SetAttribute("Equipped", v296)
								v_u_270(v300, p_u_272, v295 - 12)
								local v301 = v295 + 2
								local v302 = v_u_238.TEXT.foundAnon
								local v303
								if v_u_247 == nil then
									v303 = v302
								else
									local v304 = v_u_247.foundBy
									if type(v304) == "function" then
										local v305 = v_u_247.foundBy
										local v306 = v_u_294.uid
										local v307 = v_u_247.NAMES
										local v308
										v308, v303 = pcall(v305, v306, v292, v307)
										if v308 then
											if type(v303) ~= "string" then
												v303 = v302
											end
										else
											v303 = v302
										end
									else
										v303 = v302
									end
								end
								local v309 = p_u_233.inTrade
								local v310
								if type(v309) == "function" then
									v310 = p_u_233.inTrade("skin", v_u_294.uid)
								else
									v310 = false
								end
								local v311 = v_u_294.k
								if type(v311) == "number" then
									local v312 = v_u_234.new("Frame", {
										["Name"] = "L1",
										["BackgroundTransparency"] = 1,
										["Position"] = nil,
										["Size"] = nil,
										["Position"] = UDim2.fromOffset(v301, 6),
										["Size"] = UDim2.new(1, -(v301 + 112 + 12), 0, 20)
									}, v300)
									v_u_234.layout(v312, "h", 6)
									v_u_1.tallyChip(p_u_232, v312, v_u_294.k, {
										["order"] = 1
									})
								else
									v_u_234.label({
										["parent"] = nil,
										["name"] = "Plain",
										["text"] = nil,
										["style"] = "bodyStrong",
										["color"] = nil,
										["position"] = nil,
										["size"] = nil,
										["fit"] = true,
										["track"] = false,
										["parent"] = v300,
										["text"] = v_u_238.TEXT.plain,
										["color"] = v_u_235.text,
										["position"] = UDim2.fromOffset(v301, 6),
										["size"] = UDim2.new(1, -(v301 + 112 + 12), 0, 20)
									})
								end
								local v313 = v296 and (v_u_247 and (v_u_247.TEXT and v_u_247.TEXT.takeOff) or "Take it off first.") or v303
								local v314 = v_u_234.label
								local v315 = {
									["parent"] = nil,
									["name"] = "Sub",
									["text"] = nil,
									["style"] = "micro",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v300,
									["text"] = v313
								}
								local v316
								if v296 then
									v316 = v_u_235.accent
								else
									v316 = v_u_235.text2
								end
								v315.color = v316
								v315.position = UDim2.fromOffset(v301, 30)
								v315.size = UDim2.new(1, -(v301 + 112 + 12), 0, 18)
								v314(v315)
								if v296 then
									continue
								end
								local v_u_317 = nil
								local v318 = v_u_237.button
								local v319
								if v310 then
									v319 = v_u_238.TEXT.pickAdded
								else
									v319 = v_u_238.TEXT.pickAdd
								end
								local _, v320 = v318(v300, v319, v310 and "ghost" or "primary", function()
									-- upvalues: (ref) p_u_233, (copy) v_u_294, (ref) v_u_317, (ref) v_u_238
									task.spawn(function()
										-- upvalues: (ref) p_u_233, (ref) v_u_294, (ref) v_u_317, (ref) v_u_238
										if p_u_233.add("skin", v_u_294.uid, nil) then
											v_u_317.setEnabled(false)
											v_u_317.setText(v_u_238.TEXT.pickAdded)
										end
									end)
								end, {
									["name"] = "Add",
									["size"] = nil,
									["height"] = nil,
									["anchor"] = nil,
									["position"] = nil,
									["maxTextWidth"] = 92,
									["size"] = UDim2.fromOffset(104, v_u_236.touch(40)),
									["height"] = v_u_236.touch(40),
									["anchor"] = Vector2.new(1, 0.5),
									["position"] = UDim2.new(1, -8, 0.5, 0)
								})
								local v321 = v320
								if not v310 then
									continue
								end
								v321.setEnabled(false)
							end
							local v322 = v285.total
							if (tonumber(v322) or #v288) > p_u_273 + #v285.rows then
								v_u_237.button(v_u_276, v_u_238.TEXT.pickMore, "secondary", function()
									-- upvalues: (ref) v_u_323, (ref) p_u_272, (ref) p_u_273
									v_u_323(p_u_272, p_u_273 + 25)
								end, {
									["name"] = "More",
									["height"] = nil,
									["width"] = 160,
									["order"] = 900,
									["height"] = v_u_236.touch(40)
								})
							end
							return
						end
					end
					v_u_234.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 4,
						["parent"] = v_u_276,
						["text"] = v_u_238.TEXT.pickFailed,
						["color"] = v_u_235.accent
					})
				end
			end)
		end
	end
	v_u_271 = function()
		-- upvalues: (ref) v_u_252, (copy) v_u_254, (copy) v_u_257, (ref) v_u_251, (copy) v_u_234, (copy) v_u_238, (copy) v_u_235, (copy) p_u_232, (copy) v_u_241, (copy) v_u_236, (copy) v_u_270, (ref) v_u_1, (copy) v_u_237, (ref) v_u_323, (copy) v_u_250
		v_u_252 = v_u_252 + 1
		local v_u_324 = v_u_252
		local v325 = v_u_254
		v_u_254.step = "skins"
		v325.skin = nil
		v_u_257()
		if v_u_251 ~= nil then
			local v_u_326 = v_u_251
			local v_u_327 = v_u_234.label({
				["parent"] = nil,
				["name"] = "Loading",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = 1,
				["parent"] = v_u_326,
				["text"] = v_u_238.TEXT.pickLoading,
				["color"] = v_u_235.text2
			})
			task.spawn(function()
				-- upvalues: (ref) p_u_232, (copy) v_u_324, (ref) v_u_252, (ref) v_u_251, (copy) v_u_327, (ref) v_u_234, (copy) v_u_326, (ref) v_u_238, (ref) v_u_235, (ref) v_u_241, (ref) v_u_236, (ref) v_u_270, (ref) v_u_1, (ref) v_u_237, (ref) v_u_323, (ref) v_u_250
				local v328 = p_u_232.notes.get("crates")
				if v_u_324 == v_u_252 and (v_u_251 ~= nil and v_u_251.Parent) then
					v_u_327:Destroy()
					local v329
					if type(v328) == "table" then
						v329 = v328.items
					else
						v329 = nil
					end
					if type(v329) == "table" then
						local v330 = {}
						for v331, v332 in v329 do
							local v333
							if v_u_241 == nil then
								v333 = false
							else
								local v334 = v_u_241.isExclusive
								if type(v334) == "function" then
									v333 = v_u_241.isExclusive(v331) == true
								else
									v333 = false
								end
							end
							if type(v332) ~= "table" or ((v332.n or 0) <= 0 or v333) then
								continue
							end
							table.insert(v330, v331)
						end
						table.sort(v330, function(p335, p336)
							-- upvalues: (ref) v_u_241
							local v337
							if v_u_241 then
								v337 = v_u_241.get(p335)
							else
								v337 = nil
							end
							local v338
							if v_u_241 then
								v338 = v_u_241.get(p336)
							else
								v338 = nil
							end
							local v339
							if v337 then
								v339 = v337.weapon
							else
								v339 = p335
							end
							local v340
							if v338 then
								v340 = v338.weapon
							else
								v340 = p336
							end
							if v339 == v340 then
								return p335 < p336
							else
								return v339 < v340
							end
						end)
						if #v330 == 0 then
							v_u_234.label({
								["parent"] = nil,
								["text"] = nil,
								["style"] = "body",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = 2,
								["parent"] = v_u_326,
								["text"] = v_u_238.TEXT.pickSkinsEmpty,
								["color"] = v_u_235.text2
							})
						else
							for v341, v_u_342 in v330 do
								local v343 = v329[v_u_342]
								local v344 = v_u_236.touch(54)
								local v345 = v_u_234.new("Frame", {
									["Name"] = nil,
									["BackgroundColor3"] = nil,
									["BackgroundTransparency"] = 0.15,
									["BorderSizePixel"] = 0,
									["Size"] = nil,
									["LayoutOrder"] = nil,
									["Name"] = "Skin_" .. v_u_342,
									["BackgroundColor3"] = v_u_235.raised,
									["Size"] = UDim2.new(1, 0, 0, v344),
									["LayoutOrder"] = 10 + v341
								}, v_u_326)
								v_u_234.stroke(v345, v_u_235.line)
								v_u_270(v345, v_u_342, v344 - 12)
								local v346 = v344 + 2
								local v347 = v_u_234.label
								local v348 = {
									["parent"] = nil,
									["name"] = "Name",
									["text"] = nil,
									["style"] = "bodyStrong",
									["color"] = nil,
									["position"] = nil,
									["size"] = nil,
									["fit"] = true,
									["track"] = false,
									["parent"] = v345
								}
								local v349
								if v_u_241 == nil then
									v349 = nil
								else
									v349 = v_u_241.get(v_u_342)
								end
								local v350
								if v349 and v_u_241 ~= nil then
									v350 = v_u_241.displayName(v349)
								else
									v350 = v_u_342
								end
								v348.text = v350
								v348.color = v_u_235.text
								v348.position = UDim2.fromOffset(v346, 5)
								v348.size = UDim2.new(1, -(v346 + 130), 0, 22)
								v347(v348)
								local v351 = v_u_234.new("Frame", {
									["Name"] = "L2",
									["BackgroundTransparency"] = 1,
									["Position"] = nil,
									["Size"] = nil,
									["Position"] = UDim2.fromOffset(v346, 28),
									["Size"] = UDim2.new(1, -(v346 + 130), 0, 20)
								}, v345)
								v_u_234.layout(v351, "h", 6)
								local v352 = v_u_234.label
								local v353 = {
									["parent"] = nil,
									["name"] = "Count",
									["text"] = nil,
									["style"] = "micro",
									["color"] = nil,
									["autoX"] = true,
									["size"] = nil,
									["track"] = false,
									["order"] = 1,
									["parent"] = v351
								}
								local v354
								if (v343.n or 0) == 1 then
									v354 = v_u_238.TEXT.copy1
								else
									v354 = v_u_238.text("copies", v343.n)
								end
								v353.text = v354
								v353.color = v_u_235.text2
								v353.size = UDim2.fromOffset(0, 20)
								v352(v353)
								local v355 = v343.best
								if type(v355) == "number" then
									v_u_1.tallyChip(p_u_232, v351, v343.best, {
										["order"] = 2
									})
								end
								v_u_237.button(v345, v_u_238.TEXT.pickChoose, "secondary", function()
									-- upvalues: (ref) v_u_323, (copy) v_u_342
									v_u_323(v_u_342, 0)
								end, {
									["name"] = "Choose",
									["size"] = nil,
									["height"] = nil,
									["anchor"] = nil,
									["position"] = nil,
									["maxTextWidth"] = 104,
									["size"] = UDim2.fromOffset(120, v_u_236.touch(40)),
									["height"] = v_u_236.touch(40),
									["anchor"] = Vector2.new(1, 0.5),
									["position"] = UDim2.new(1, -8, 0.5, 0)
								})
							end
						end
					else
						v_u_234.label({
							["parent"] = nil,
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["order"] = 2,
							["parent"] = v_u_326,
							["text"] = v_u_238.TEXT.pickFailed,
							["color"] = v_u_235.accent
						})
						return
					end
				else
					return
				end
			end)
		end
	end
	return {
		["modal"] = v_u_234.modal({
			["title"] = nil,
			["width"] = 640,
			["build"] = nil,
			["buttons"] = nil,
			["onClose"] = nil,
			["title"] = v_u_238.TEXT.pickSkinTitle,
			["build"] = function(p356) -- name: build
				-- upvalues: (ref) v_u_251, (ref) v_u_271
				p356.Name = "PickSkins"
				v_u_251 = p356
				v_u_271()
			end,
			["buttons"] = {
				{
					["text"] = nil,
					["kind"] = "primary",
					["text"] = v_u_238.TEXT.cashDone
				}
			},
			["onClose"] = function() -- name: onClose
				-- upvalues: (ref) v_u_252, (copy) v_u_257, (ref) v_u_251
				v_u_252 = v_u_252 + 1
				v_u_257()
				v_u_251 = nil
			end
		}),
		["state"] = v_u_254,
		["showSkins"] = v_u_271,
		["showCopies"] = v_u_323
	}
end
function v_u_1.cashDialog(p_u_357, p_u_358) -- name: cashDialog
	local v_u_359 = p_u_357.ui
	local v_u_360 = p_u_357.C
	local v_u_361 = p_u_357.theme
	local v_u_362 = p_u_357.View
	local v_u_363 = "MenuMarketKeypad"
	local v364, v_u_365 = pcall(function()
		-- upvalues: (copy) p_u_357, (copy) v_u_363
		return p_u_357.mc.cctx.lib[v_u_363]
	end)
	if not v364 or type(v_u_365) ~= "table" then
		v_u_365 = nil
	end
	local v_u_366 = v_u_362.cashCap(p_u_358.have)
	local v367 = p_u_358.cash or 0
	local v368 = math.floor(v367)
	local v369 = math.max(0, v368)
	local v_u_370 = math.min(v369, v_u_366)
	local v_u_371 = nil
	local v_u_372 = nil
	local v_u_373 = nil
	local v_u_374 = nil
	local v_u_375 = false
	local function v_u_376() -- name: paint
		-- upvalues: (ref) v_u_371, (copy) v_u_362, (ref) v_u_370, (ref) v_u_372, (copy) p_u_358, (ref) v_u_373, (ref) v_u_375
		if v_u_371 then
			v_u_371.Text = v_u_362.money(v_u_370)
		end
		if v_u_372 then
			v_u_372.Text = p_u_358.fee(v_u_370)
		end
		if v_u_373 and not v_u_373:IsFocused() then
			v_u_375 = true
			v_u_373.Text = v_u_370 <= 0 and "" or v_u_362.group(v_u_370)
			v_u_375 = false
		end
	end
	local function v380(p377) -- name: setValue
		-- upvalues: (ref) v_u_370, (copy) v_u_366, (ref) v_u_374, (copy) v_u_376
		local v378 = math.floor(p377)
		local v379 = v_u_366
		v_u_370 = math.clamp(v378, 0, v379)
		if v_u_374 then
			v_u_374.set(v_u_370)
		end
		v_u_376()
	end
	return {
		["modal"] = v_u_359.modal({
			["title"] = nil,
			["width"] = 640,
			["build"] = nil,
			["buttons"] = nil,
			["title"] = v_u_362.TEXT.cashTitle,
			["build"] = function(p381) -- name: build
				-- upvalues: (copy) v_u_359, (ref) v_u_371, (copy) v_u_360, (ref) v_u_372, (copy) v_u_362, (copy) p_u_358, (copy) v_u_361, (ref) v_u_373, (ref) v_u_375, (copy) v_u_366, (ref) v_u_370, (ref) v_u_374, (copy) v_u_365, (copy) v_u_376
				p381.Name = "CashDialog"
				local v382 = v_u_359.new("Frame", {
					["Name"] = "Display",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Size"] = UDim2.new(1, 0, 0, 44)
				}, p381)
				v_u_371 = v_u_359.label({
					["parent"] = nil,
					["name"] = "Value",
					["text"] = "",
					["style"] = "monoL",
					["textSize"] = 30,
					["color"] = nil,
					["size"] = nil,
					["track"] = false,
					["fit"] = true,
					["parent"] = v382,
					["color"] = v_u_360.accent,
					["size"] = UDim2.new(0.5, 0, 1, 0)
				})
				v_u_372 = v_u_359.label({
					["parent"] = nil,
					["name"] = "Fee",
					["text"] = "",
					["style"] = "small",
					["color"] = nil,
					["align"] = "right",
					["position"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["track"] = false,
					["parent"] = v382,
					["color"] = v_u_360.text2,
					["position"] = UDim2.fromScale(0.5, 0),
					["size"] = UDim2.new(0.5, 0, 1, 0)
				})
				v_u_359.label({
					["parent"] = nil,
					["name"] = "Have",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = 2,
					["parent"] = p381,
					["text"] = v_u_362.text("cashHave", v_u_362.money(p_u_358.have)) .. " " .. v_u_362.text("cashMax", v_u_362.money(v_u_362.cashMax())),
					["color"] = v_u_360.text2
				})
				local v383 = v_u_359.device() == "Keyboard"
				if v383 then
					local _, v_u_384 = v_u_359.input({
						["parent"] = nil,
						["name"] = "CashInput",
						["placeholder"] = "Cash",
						["size"] = nil,
						["maxLength"] = 12,
						["order"] = 3,
						["parent"] = p381,
						["size"] = UDim2.new(1, 0, 0, v_u_361.touch(40))
					})
					v_u_373 = v_u_384
					v_u_384:GetPropertyChangedSignal("Text"):Connect(function()
						-- upvalues: (ref) v_u_375, (ref) v_u_362, (copy) v_u_384, (ref) v_u_366, (ref) v_u_370, (ref) v_u_374, (ref) v_u_371, (ref) v_u_372, (ref) p_u_358
						if not v_u_375 then
							local v385 = v_u_362.cashKeyed(v_u_384.Text)
							local v386 = v_u_366
							local v387 = math.min(v385, v386)
							local v388 = string.find(v_u_384.Text, ".", 1, true) ~= nil
							v_u_370 = v387
							if v_u_374 then
								v_u_374.set(v387)
							end
							if v_u_371 then
								v_u_371.Text = v_u_362.money(v387)
							end
							if v_u_372 then
								v_u_372.Text = p_u_358.fee(v387)
							end
							local v389 = v387 <= 0 and "" or v_u_362.group(v387)
							if v_u_384.Text ~= v389 and not v388 then
								v_u_375 = true
								v_u_384.Text = v389
								v_u_384.CursorPosition = #v_u_384.Text + 1
								v_u_375 = false
							end
						end
					end)
				end
				if v_u_365 ~= nil then
					v_u_374 = v_u_365.mount(p381, {
						["ui"] = nil,
						["theme"] = nil,
						["price"] = nil,
						["n"] = 1,
						["max"] = nil,
						["keys"] = nil,
						["quick"] = false,
						["keyCols"] = 6,
						["keyH"] = nil,
						["onChange"] = nil,
						["ui"] = v_u_359,
						["theme"] = v_u_361,
						["price"] = v_u_370,
						["max"] = v_u_366,
						["keys"] = not v383,
						["keyH"] = v_u_361.touch(44),
						["onChange"] = function(p390) -- name: onChange
							-- upvalues: (ref) v_u_370, (ref) v_u_366, (ref) v_u_376
							local v391 = v_u_366
							v_u_370 = math.min(p390, v391)
							v_u_376()
						end
					})
					v_u_374.frame.LayoutOrder = 4
				end
				v_u_376()
			end,
			["buttons"] = {
				{
					["text"] = nil,
					["kind"] = "secondary",
					["onClick"] = nil,
					["text"] = v_u_362.TEXT.cashClear,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) v_u_370, (copy) v_u_366, (ref) v_u_374, (copy) v_u_376
						local v392 = v_u_366
						v_u_370 = math.clamp(0, 0, v392)
						if v_u_374 then
							v_u_374.set(v_u_370)
						end
						v_u_376()
						return true
					end
				},
				{
					["text"] = nil,
					["kind"] = "primary",
					["onClick"] = nil,
					["text"] = v_u_362.TEXT.cashEdit,
					["onClick"] = function() -- name: onClick
						-- upvalues: (copy) p_u_358, (ref) v_u_370
						task.spawn(p_u_358.onSet, v_u_370)
					end
				}
			}
		}),
		["set"] = v380,
		["get"] = function() -- name: get
			-- upvalues: (ref) v_u_370
			return v_u_370
		end
	}
end
return v_u_1