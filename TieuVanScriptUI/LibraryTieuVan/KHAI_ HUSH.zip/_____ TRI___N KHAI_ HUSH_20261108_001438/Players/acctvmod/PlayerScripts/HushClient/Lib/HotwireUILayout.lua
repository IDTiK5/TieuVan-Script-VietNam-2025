-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HotwireUILayout

local v_u_1 = {
	["VERSION"] = 1,
	["EM"] = 0.6,
	["CAPS_EXTRA"] = 1.18,
	["K"] = {
		["MARGIN"] = 12,
		["GAP"] = 8,
		["PAD"] = 10,
		["ROW_GAP"] = 6,
		["BAR_H"] = 30,
		["POINTER_W"] = 6,
		["TIMER_H"] = 4,
		["HINT_H"] = 28,
		["HINT_CHIP_W"] = 48,
		["HINT_GAP"] = 18,
		["CARD_W_MAX"] = 560,
		["CARD_W_MIN"] = 260,
		["SPARK_REAL"] = 96,
		["SPARK_MAX"] = 150,
		["SPARK_FRAC"] = 0.28,
		["MAX_MISSES"] = 0,
		["TIME_LIMIT"] = 0,
		["FLASH_S"] = 0.7,
		["DONE_S"] = 0.9,
		["PIP"] = 14,
		["PIP_GAP"] = 6
	}
}
local v_u_2 = v_u_1.K
v_u_1.TEXT = {
	["title"] = "Hotwire: spark in the green zone",
	["titleCord"] = "Pull the cord in the green zone",
	["spark"] = "SPARK",
	["hintSpark"] = "Spark",
	["hintExit"] = "Get out",
	["hit"] = "Nice",
	["miss"] = "Try again",
	["early"] = "Too early",
	["late"] = "Too slow",
	["wired"] = "Wired",
	["failed"] = "Failed",
	["retry"] = "Retry in ",
	["misses"] = "Misses "
}
local v_u_3 = v_u_1.TEXT
v_u_1.ACTION_SPARK = "vehicleSpark"
v_u_1.ACTION_EXIT = "vehicleHotwireExit"
v_u_1.PAD_SPARK_WORD = "A"
v_u_1.PAD_EXIT_WORD = "B"
function v_u_1.textW(p4, p5, p6) -- name: textW
	-- upvalues: (copy) v_u_1
	return #p4 * p5 * v_u_1.EM * (not p6 and 1 or v_u_1.CAPS_EXTRA)
end
function v_u_1.fitSize(p7, p8, p9, p10, p11) -- name: fitSize
	-- upvalues: (copy) v_u_1
	local v12 = math.max(p9, p10)
	local v13 = math.floor(v12)
	local v14 = math.min(p9, p10)
	local v15 = math.floor(v14)
	while v15 <= v13 do
		if v_u_1.textW(p7, v13, p11) <= p8 + 1e-6 then
			return v13, true
		end
		v13 = v13 - 1
	end
	return v15, false
end
function v_u_1.sparkKeyText(p16, p17) -- name: sparkKeyText
	-- upvalues: (copy) v_u_1
	local v18 = type(p17) ~= "string" and "" or p17
	if p16 == "Gamepad" then
		return v_u_1.PAD_SPARK_WORD
	else
		return p16 ~= "Keyboard" and "" or (v18 == "" and "Space" or v18)
	end
end
function v_u_1.exitKeyText(p19, p20, p21) -- name: exitKeyText
	-- upvalues: (copy) v_u_1
	local v22 = type(p20) ~= "string" and "" or p20
	local v23 = type(p21) ~= "string" and "" or p21
	if p19 == "Gamepad" then
		if v22 == "" or (v22 == v23 or v22 == v_u_1.PAD_SPARK_WORD) then
			return v_u_1.PAD_EXIT_WORD
		else
			return v22
		end
	elseif p19 == "Keyboard" then
		if v22 == "" then
			return v23 == "" and "F" or v23
		else
			return v22
		end
	else
		return ""
	end
end
function v_u_1.titleText(p24) -- name: titleText
	-- upvalues: (copy) v_u_3
	if p24 == "cord" then
		return v_u_3.titleCord
	else
		return v_u_3.title
	end
end
function v_u_1.countText(p25, p26) -- name: countText
	local v27 = (type(p26) ~= "number" or (p26 ~= p26 or (p26 == (1 / 0) or p26 == (-1 / 0)))) and 3 or p26
	local v28 = math.floor(v27)
	local v29 = math.max(1, v28)
	local v30 = (type(p25) ~= "number" or (p25 ~= p25 or (p25 == (1 / 0) or p25 == (-1 / 0)))) and 0 or p25
	local v31 = math.floor(v30)
	if v31 < 0 then
		v31 = 0
	elseif v29 < v31 then
		v31 = v29
	end
	return tostring(v31) .. "/" .. tostring(v29)
end
function v_u_1.missText(p32) -- name: missText
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if v_u_2.MAX_MISSES <= 0 then
		return ""
	end
	local v33 = v_u_3.misses
	local v34 = (type(p32) ~= "number" or (p32 ~= p32 or (p32 == (1 / 0) or p32 == (-1 / 0)))) and 0 or p32
	local v35 = math.floor(v34)
	local v36 = v_u_2.MAX_MISSES
	if v35 < 0 then
		v35 = 0
	elseif v36 < v35 then
		v35 = v36
	end
	local v37 = tostring(v35)
	local v38 = v_u_2.MAX_MISSES
	return v33 .. v37 .. "/" .. tostring(v38)
end
function v_u_1.flashText(p39) -- name: flashText
	-- upvalues: (copy) v_u_3
	if p39 == "hit" then
		return v_u_3.hit, "good"
	elseif p39 == "miss" then
		return v_u_3.miss, "bad"
	elseif p39 == "early" then
		return v_u_3.early, "neutral"
	elseif p39 == "late" then
		return v_u_3.late, "bad"
	else
		return nil, nil
	end
end
function v_u_1.resultText(p40, p41) -- name: resultText
	-- upvalues: (copy) v_u_3
	if p40 == "ok" then
		return v_u_3.wired, "good"
	end
	if p40 ~= "fail" then
		return nil, nil
	end
	local v42 = (type(p41) ~= "number" or (p41 ~= p41 or (p41 == (1 / 0) or p41 == (-1 / 0)))) and 0 or p41
	if v42 <= 0 then
		return v_u_3.failed, "bad"
	end
	local v43 = v_u_3.retry
	local v44 = math.ceil(v42)
	return v43 .. tostring(v44), "bad"
end
function v_u_1.pipStates(p45, p46) -- name: pipStates
	local v47 = (type(p46) ~= "number" or (p46 ~= p46 or (p46 == (1 / 0) or p46 == (-1 / 0)))) and 3 or p46
	local v48 = math.floor(v47)
	local v49 = v48 < 1 and 1 or (v48 > 4 and 4 or v48)
	local v50 = (type(p45) ~= "number" or (p45 ~= p45 or (p45 == (1 / 0) or p45 == (-1 / 0)))) and 0 or p45
	local v51 = math.floor(v50)
	if v51 < 0 then
		v51 = 0
	elseif v49 < v51 then
		v51 = v49
	end
	local v52 = {}
	for v53 = 1, v49 do
		local v54 = v53 <= v51 and "done" or "open"
		table.insert(v52, v54)
	end
	return v52
end
function v_u_1.zoneRect(p55, p56, p57) -- name: zoneRect
	local v58 = p55.bar
	local v59 = (type(p56) ~= "number" or (p56 ~= p56 or (p56 == (1 / 0) or p56 == (-1 / 0)))) and 0.4 or p56
	local v60 = v59 < 0 and 0 or (v59 > 1 and 1 or v59)
	local v61 = (type(p57) ~= "number" or (p57 ~= p57 or (p57 == (1 / 0) or p57 == (-1 / 0)))) and 0.6 or p57
	local v62 = v61 < 0 and 0 or (v61 > 1 and 1 or v61)
	if v62 >= v60 then
		local v63 = v60
		v60 = v62
		v62 = v63
	end
	local v64 = v58.x + v62 * v58.w
	local v65 = v58.y
	local v66 = (v60 - v62) * v58.w
	return {
		["x"] = v64,
		["y"] = v65,
		["w"] = math.max(2, v66),
		["h"] = v58.h
	}
end
function v_u_1.pointerRect(p67, p68) -- name: pointerRect
	-- upvalues: (copy) v_u_2
	local v69 = p67.bar
	local v70 = v_u_2.POINTER_W
	local v71 = v69.x
	local v72 = (type(p68) ~= "number" or (p68 ~= p68 or (p68 == (1 / 0) or p68 == (-1 / 0)))) and 0 or p68
	local v73 = v71 + (v72 < 0 and 0 or (v72 > 1 and 1 or v72)) * v69.w - v70 / 2
	local v74 = v69.x
	local v75 = v69.x + v69.w - v70
	if v73 < v74 then
		v73 = v74
	elseif v75 < v73 then
		v73 = v75
	end
	return {
		["x"] = v73,
		["y"] = v69.y - 2,
		["w"] = v70,
		["h"] = v69.h + 4
	}
end
function v_u_1.timerFill(p76, p77) -- name: timerFill
	-- upvalues: (copy) v_u_2
	local v78 = p76.timer
	if v_u_2.TIME_LIMIT <= 0 then
		return {
			["x"] = nil,
			["y"] = nil,
			["w"] = 0,
			["h"] = nil,
			["x"] = v78.x,
			["y"] = v78.y,
			["h"] = v78.h
		}
	end
	local v79 = v_u_2.TIME_LIMIT
	if type(p77) == "number" and (p77 == p77 and (p77 ~= (1 / 0) and p77 ~= (-1 / 0))) then
		v79 = p77
	end
	local v80 = v79 / v_u_2.TIME_LIMIT
	local v81 = v80 < 0 and 0 or (v80 > 1 and 1 or v80)
	return {
		["x"] = v78.x,
		["y"] = v78.y,
		["w"] = v78.w * v81,
		["h"] = v78.h
	}
end
function v_u_1.compute(p82, p83, p84) -- name: compute
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
	local v85 = type(p84) ~= "table" and {} or p84
	local v86 = (type(p82) ~= "number" or (p82 ~= p82 or (p82 == (1 / 0) or p82 == (-1 / 0)))) and 1920 or p82
	local v87 = v86 <= 0 and 1920 or v86
	local v88 = (type(p83) ~= "number" or (p83 ~= p83 or (p83 == (1 / 0) or p83 == (-1 / 0)))) and 1080 or p83
	local v89 = v88 <= 0 and 1080 or v88
	local v90 = v85.touch == true
	local v91 = v85.scale
	local v92 = (type(v91) ~= "number" or (v91 ~= v91 or (v91 == (1 / 0) or v91 == (-1 / 0)))) and (v90 and 0.8 or 1) or v91
	local v93 = v92 < 0.3 and 0.3 or (v92 > 3 and 3 or v92)
	local v94
	if v85.phone == nil then
		if v90 then
			v94 = math.min(v87, v89) * v93 < 600
		else
			v94 = v90
		end
	else
		v94 = v85.phone == true
	end
	local v95 = v85.need
	local v96 = (type(v95) ~= "number" or (v95 ~= v95 or (v95 == (1 / 0) or v95 == (-1 / 0)))) and 3 or v95
	local v97 = v96 < 1 and 1 or (v96 > 4 and 4 or v96)
	local v98 = math.floor(v97)
	local v99 = v85.style == "cord" and "cord" or "wire"
	local v100 = v_u_2.MARGIN
	local v101
	if v94 then
		local v102 = 10 / v93
		v101 = math.ceil(v102)
	else
		v101 = 11
	end
	local v103
	if v94 then
		local v104 = 11 / v93
		v103 = math.ceil(v104)
	else
		v103 = 13
	end
	local v105
	if v90 then
		local v106 = v_u_2.SPARK_REAL / v93
		local v107 = math.ceil(v106)
		local v108 = v_u_2.SPARK_MAX
		local v109 = v89 * v_u_2.SPARK_FRAC
		local v110 = math.floor(v109)
		local v111 = math.min(v108, v110)
		local v112 = math.max(v107, v111)
		v105 = {
			["x"] = v87 - v100 - v112,
			["y"] = v89 - v100 - v112,
			["w"] = v112,
			["h"] = v112
		}
	else
		v105 = nil
	end
	local v113 = v85.interval
	local v114 = type(v113) ~= "table" and {} or v85.interval
	local v115 = v114.left
	if type(v115) ~= "number" or (v115 ~= v115 or (v115 == (1 / 0) or v115 == (-1 / 0))) then
		v115 = v100
	end
	local v116 = math.max(v100, v115)
	local v117 = v87 - v100
	local v118 = v114.right
	local v119 = v87 - v100
	if type(v118) == "number" and (v118 == v118 and (v118 ~= (1 / 0) and v118 ~= (-1 / 0))) then
		v119 = v118
	end
	local v120 = math.min(v117, v119)
	if v105 ~= nil then
		local v121 = v105.x - v_u_2.GAP
		v120 = math.min(v120, v121)
	end
	if v120 - v116 < 100 then
		local v122 = v100 + 100
		local v123 = v87 - v100
		v120 = math.max(v122, v123)
		v116 = v100
	end
	local v124 = v120 - v116
	local v125 = v_u_2.CARD_W_MAX
	local v126 = v_u_2.CARD_W_MIN
	local v127 = v87 * 0.5
	local v128 = math.floor(v127)
	local v129 = math.max(v126, v128)
	local v130 = math.min(v124, v125, v129)
	local v131 = v87 / 2
	local v132 = v116 + v130 / 2
	local v133 = v120 - v130 / 2
	if v131 < v132 then
		v131 = v132
	elseif v133 < v131 then
		v131 = v133
	end
	local v134 = v130 - 2 * v_u_2.PAD
	local v135 = v103 + 6
	local v136 = v103 + 6
	local v137 = v_u_2.PAD + v135 + v_u_2.ROW_GAP + v_u_2.BAR_H + 4 + v_u_2.TIMER_H + v_u_2.ROW_GAP + v136 + ((v90 and 0 or 1) <= 0 and 0 or v_u_2.ROW_GAP + v_u_2.HINT_H) + v_u_2.PAD
	local v138 = v85.avoidY
	local v139 = v89 - v100 - 80
	if type(v138) ~= "number" or (v138 ~= v138 or (v138 == (1 / 0) or v138 == (-1 / 0))) then
		v138 = v139
	end
	local v140 = v138 - v_u_2.GAP - v137
	local v141 = math.floor(v140)
	local v142 = v100 + 8
	if v141 >= v142 then
		v142 = v141
	end
	local v143 = v131 - v130 / 2
	local v144 = math.floor(v143)
	local v145 = {
		["x"] = v144,
		["y"] = v142,
		["w"] = v130,
		["h"] = v137
	}
	local v146 = v144 + v_u_2.PAD
	local v147 = v142 + v_u_2.PAD
	local v148 = v_u_1.titleText(v99)
	local v149 = v_u_1.fitSize(v148, v134, v103 + 2, v101, false)
	local v150 = {
		["x"] = v146,
		["y"] = v147,
		["w"] = v134,
		["h"] = v135
	}
	local v151 = v147 + (v135 + v_u_2.ROW_GAP)
	local v152 = {
		["x"] = v146,
		["y"] = v151 + 2,
		["w"] = v134,
		["h"] = v_u_2.BAR_H
	}
	local v153 = v151 + (v_u_2.BAR_H + 4)
	local v154 = {
		["x"] = v146,
		["y"] = v153,
		["w"] = v134,
		["h"] = v_u_2.TIMER_H
	}
	local v155 = v153 + (v_u_2.TIMER_H + v_u_2.ROW_GAP)
	local v156 = v_u_1.countText(v98, v98)
	local v157 = v_u_1.textW(v156, v103, false)
	local v158 = math.ceil(v157) + 6
	local v159 = v_u_1.missText(v_u_2.MAX_MISSES)
	local v160 = v_u_1.textW(v159, v101 + 1, false)
	local v161 = math.ceil(v160) + 6
	local v162 = v98 * v_u_2.PIP + (v98 - 1) * v_u_2.PIP_GAP
	local v163 = v146 + v158 + 8
	local v164 = {}
	local v165 = {
		["x"] = v146,
		["y"] = v155,
		["w"] = v158,
		["h"] = v136
	}
	for v166 = 1, v98 do
		local v167 = v163 + (v166 - 1) * (v_u_2.PIP + v_u_2.PIP_GAP)
		local v168 = (v136 - v_u_2.PIP) / 2
		local v169 = {
			["x"] = v167,
			["y"] = v155 + math.floor(v168),
			["w"] = v_u_2.PIP,
			["h"] = v_u_2.PIP
		}
		table.insert(v164, v169)
	end
	local v170 = {
		["x"] = v146 + v134 - v161,
		["y"] = v155,
		["w"] = v161,
		["h"] = v136
	}
	local v171 = v163 + v162 + 10
	local v172 = v170.x - 8 - v171
	local v173 = {
		["x"] = v171,
		["y"] = v155,
		["w"] = math.max(20, v172),
		["h"] = v136
	}
	local v174 = v155 + v136
	local v175, v176 = v_u_1.fitSize(v_u_3.retry .. "3", v173.w, v103, v101, false)
	local v177 = {
		["w"] = nil,
		["h"] = nil,
		["scale"] = nil,
		["touch"] = nil,
		["phone"] = nil,
		["need"] = nil,
		["style"] = nil,
		["sizes"] = nil,
		["messageFits"] = nil,
		["card"] = nil,
		["title"] = nil,
		["titleText"] = nil,
		["bar"] = nil,
		["timer"] = nil,
		["count"] = nil,
		["pips"] = nil,
		["message"] = nil,
		["misses"] = nil,
		["spark"] = nil,
		["hints"] = nil,
		["interval"] = nil,
		["bottom"] = nil,
		["w"] = v87,
		["h"] = v89,
		["scale"] = v93,
		["touch"] = v90,
		["phone"] = v94,
		["need"] = v98,
		["style"] = v99,
		["sizes"] = {
			["cap"] = v101,
			["txt"] = v103,
			["title"] = v149,
			["status"] = v103,
			["misses"] = v101 + 1,
			["message"] = v175
		},
		["messageFits"] = v176,
		["card"] = v145,
		["title"] = v150,
		["titleText"] = v148,
		["bar"] = v152,
		["timer"] = v154,
		["count"] = v165,
		["pips"] = v164,
		["message"] = v173,
		["misses"] = v170,
		["spark"] = v105,
		["interval"] = {
			["left"] = v116,
			["right"] = v120,
			["cx"] = v131
		},
		["bottom"] = v145.y + v145.h
	}
	if not v90 then
		local v178 = v174 + v_u_2.ROW_GAP
		local v_u_179 = {
			{ v_u_1.ACTION_SPARK, v_u_3.hintSpark },
			{ v_u_1.ACTION_EXIT, v_u_3.hintExit }
		}
		local function v186(p180) -- name: rowW
			-- upvalues: (copy) v_u_179, (ref) v_u_2, (ref) v_u_1
			local v181 = 0
			for v182, v183 in v_u_179 do
				local v184 = v_u_2.HINT_CHIP_W + 6
				local v185 = v_u_1.textW(v183[2], p180, false)
				v181 = v181 + (v184 + math.ceil(v185) + 4)
				if v182 <= 1 then
					continue
				end
				v181 = v181 + v_u_2.HINT_GAP
			end
			return v181
		end
		local v187 = {}
		while v101 < v103 and v134 < v186(v103) do
			v103 = v103 - 1
		end
		local v188 = v186(v103)
		local v189 = (v134 - v188) / 2
		local v190 = v146 + math.floor(v189)
		for v191, v192 in v_u_179 do
			local v193 = v_u_1.textW(v192[2], v103, false)
			local v194 = math.ceil(v193) + 4
			if v191 > 1 then
				v190 = v190 + v_u_2.HINT_GAP
			end
			local v195 = {
				["action"] = v192[1],
				["text"] = v192[2],
				["textSize"] = v103
			}
			local v196 = (v_u_2.HINT_H - 24) / 2
			v195.chip = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = 24,
				["x"] = v190,
				["y"] = v178 + math.floor(v196),
				["w"] = v_u_2.HINT_CHIP_W
			}
			v195.label = {
				["x"] = v190 + v_u_2.HINT_CHIP_W + 6,
				["y"] = v178,
				["w"] = v194,
				["h"] = v_u_2.HINT_H
			}
			table.insert(v187, v195)
			v190 = v190 + (v_u_2.HINT_CHIP_W + 6 + v194)
		end
		v177.hints = {
			["items"] = v187,
			["row"] = {
				["x"] = v146,
				["y"] = v178,
				["w"] = v134,
				["h"] = v_u_2.HINT_H
			},
			["textSize"] = v103,
			["total"] = v188
		}
	end
	return v177
end
return v_u_1