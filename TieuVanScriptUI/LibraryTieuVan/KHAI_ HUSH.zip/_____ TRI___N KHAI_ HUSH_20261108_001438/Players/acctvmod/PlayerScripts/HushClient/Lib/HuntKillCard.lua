-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntKillCard

local v_u_6 = {
	["CARD_SEC"] = 15,
	["END_NEAR_SEC"] = 5,
	["CENTER_SEC"] = 8,
	["BACK_SEC"] = 5,
	["MARGIN"] = 12,
	["MAX_H"] = 520,
	["overlap"] = function(p1, p2, p3) -- name: overlap
		local v4 = p3 or 0
		local v5
		if p1.x0 < p2.x1 + v4 and (p2.x0 < p1.x1 + v4 and p1.y0 < p2.y1 + v4) then
			v5 = p2.y0 < p1.y1 + v4
		else
			v5 = false
		end
		return v5
	end
}
local function v_u_15(p7, p8) -- name: cleanName
	if type(p7) ~= "string" then
		return ""
	end
	local v9 = string.gsub(p7, "[%c\127]", " ")
	local v10 = string.gsub(v9, "%s+", " ")
	local v11 = string.gsub(v10, "^ ", "")
	local v12 = string.gsub(v11, " $", "")
	local v13 = utf8.len(v12)
	if v13 == nil then
		v12 = string.gsub(v12, "[\128-\255]", "?")
		v13 = #v12
	end
	if p8 < v13 then
		local v14 = (utf8.offset(v12, p8 + 1) or #v12 + 1) - 1
		v12 = string.sub(v12, 1, v14)
	end
	return v12
end
function v_u_6.model(p16, p17) -- name: model
	-- upvalues: (copy) v_u_15
	if type(p16) == "table" then
		local v18 = p16.kb
		if type(v18) == "table" then
			local v19 = p16.kb
			local v20 = v19.u
			if type(v20) ~= "number" or (v20 ~= v20 or (v20 <= 0 or (v20 % 1 ~= 0 or (v20 > 1125899906842624 or v20 == p17)))) then
				return nil
			end
			local v21 = v_u_15(v19.n, 20)
			local v22 = v_u_15(v19.d, 40)
			if v22 == "" then
				v22 = v21
			end
			local v23
			if v19.r == "stalker" or v19.r == "survivor" then
				v23 = v19.r
			else
				v23 = nil
			end
			return {
				["uid"] = v20,
				["name"] = v21,
				["display"] = v22,
				["role"] = v23,
				["fake"] = v19.f == true
			}
		end
	end
	return nil
end
function v_u_6.initial(p24) -- name: initial
	if type(p24) ~= "string" or p24 == "" then
		return "?"
	end
	local v25 = utf8.offset(p24, 2)
	if v25 then
		local v26 = v25 - 1
		p24 = string.sub(p24, 1, v26)
	end
	return string.upper(p24)
end
function v_u_6.thumb(p27) -- name: thumb
	return ("rbxthumb://type=Avatar&id=%d&w=420&h=420"):format(p27)
end
function v_u_6.parts(p28, p29, p30, p31) -- name: parts
	local v32 = p30 and 8 or 10
	local v33 = p30 and 16 or 18
	local v34 = p30 and 24 or 28
	local v35 = p30 and 16 or 18
	local v36 = math.max(p31, 52)
	local v37 = math.max(p31, 44)
	local v38 = p28 - v32 * 2
	local v39 = {
		["title"] = {
			["x0"] = v32,
			["y0"] = v32,
			["x1"] = v32 + v38,
			["y1"] = v32 + v33
		}
	}
	local v40 = v32 + (v33 + 6)
	local v41 = v34 + 2 + v35 + 8 + v36 + 6 + v37 + v32
	local v42 = p29 - v40 - 8 - v41
	local v43 = math.max(40, v42)
	v39.avatar = {
		["x0"] = v32,
		["y0"] = v40,
		["x1"] = v32 + v38,
		["y1"] = v40 + v43
	}
	local v44 = v40 + (v43 + 8)
	v39.name = {
		["x0"] = v32,
		["y0"] = v44,
		["x1"] = v32 + v38,
		["y1"] = v44 + v34
	}
	local v45 = v44 + (v34 + 2)
	v39.user = {
		["x0"] = v32,
		["y0"] = v45,
		["x1"] = v32 + v38,
		["y1"] = v45 + v35
	}
	local v46 = v45 + (v35 + 8)
	v39.report = {
		["x0"] = v32,
		["y0"] = v46,
		["x1"] = v32 + v38,
		["y1"] = v46 + v36
	}
	local v47 = v46 + (v36 + 6)
	v39.cont = {
		["x0"] = v32,
		["y0"] = v47,
		["x1"] = v32 + v38,
		["y1"] = v47 + v37
	}
	return v39
end
function v_u_6.minHeight(p48, p49, p50) -- name: minHeight
	-- upvalues: (copy) v_u_6
	local v51 = v_u_6.parts(150, 2000, p48, p49)
	local v52 = v51.cont.y1 + (p48 and 8 or 10) - (v51.avatar.y1 - v51.avatar.y0) + (p50 or 96) + 0.5
	return math.floor(v52)
end
function v_u_6.sizeFor(p53) -- name: sizeFor
	-- upvalues: (copy) v_u_6
	local v54 = v_u_6.MAX_H
	local v55 = math.min(v54, p53)
	local v56 = math.floor(v55)
	local v57 = v56 * 0.62 + 0.5
	local v58 = math.floor(v57)
	local v59 = math.clamp(v58, 150, 300)
	local v60 = v56 / 1.15
	local v61 = math.floor(v60)
	return math.min(v59, v61), v56
end
local function v_u_73(p62) -- name: cleanSafe
	local v63 = type(p62) ~= "table" and {} or p62
	local v64 = {}
	local v65 = v63.l
	local v66 = tonumber(v65) or 0
	v64.l = math.max(0, v66)
	local v67 = v63.t
	local v68 = tonumber(v67) or 0
	v64.t = math.max(0, v68)
	local v69 = v63.r
	local v70 = tonumber(v69) or 0
	v64.r = math.max(0, v70)
	local v71 = v63.b
	local v72 = tonumber(v71) or 0
	v64.b = math.max(0, v72)
	return v64
end
function v_u_6.layout(p74, p75, p76, p77, p78, p79, p80, p81) -- name: layout
	-- upvalues: (copy) v_u_73, (copy) v_u_6
	local v82 = v_u_73(p75)
	local v83 = p79 or {}
	local v84 = p81 or {}
	local v85 = v_u_6.MARGIN
	local v_u_86 = v82.l + v85
	local v_u_87 = p74.X - v82.r - v85
	local v_u_88 = v82.t + p78 + 4
	local v_u_89 = p74.Y - v82.b - v85
	local v90 = v_u_89 - v_u_88
	local v91 = v_u_6.minHeight(p76, p77)
	local v92 = nil
	local v93 = "side"
	local function v108(p94, p95) -- name: tryAt
		-- upvalues: (ref) v_u_6, (copy) v_u_87, (copy) v_u_86, (copy) v_u_88, (copy) v_u_89
		local v96 = v_u_6.sizeFor(p94)
		if v_u_87 - v_u_86 < v96 then
			return nil
		end
		local v97 = { v_u_86, v_u_87 - v96 }
		local v98 = { v_u_88 }
		for _, v99 in p95 do
			local v100 = v99.y1 + 8
			table.insert(v98, v100)
			local v101 = v99.y0 - 8 - p94
			table.insert(v98, v101)
		end
		local v102 = v_u_89 - p94
		table.insert(v98, v102)
		for _, v103 in v97 do
			for _, v104 in v98 do
				if v_u_88 - 0.01 > v104 or v104 + p94 > v_u_89 + 0.01 then
					continue
				end
				local v105 = {
					["x0"] = v103,
					["y0"] = v104,
					["x1"] = v103 + v96,
					["y1"] = v104 + p94
				}
				local v106 = true
				for _, v107 in p95 do
					if not v_u_6.overlap(v105, v107, 6) then
						continue
					end
					v106 = false
				end
				if not v106 then
					break
				end
				return v105
			end
		end
		return nil
	end
	if p80 ~= "center" and v91 <= v90 then
		local v109 = v_u_6.MAX_H
		local v110 = math.min(v109, v90)
		local v111 = math.floor(v110)
		local v112 = v111
		local v113 = {}
		while v91 < v111 do
			table.insert(v113, v111)
			v111 = v111 - 10
		end
		table.insert(v113, v91)
		local v114 = {}
		for _, v115 in v83 do
			table.insert(v114, v115)
		end
		for _, v116 in v84 do
			table.insert(v114, v116)
		end
		local v117 = v112 * 0.82
		local v118 = math.floor(v117)
		local v119 = math.max(v91, v118)
		for _, v120 in v113 do
			if v119 > v120 then
				continue
			end
			v92 = v108(v120, v114)
			if not v92 then
				continue
			end
		end
		if v92 == nil then
			for _, v121 in v113 do
				v92 = v108(v121, v83)
				if not v92 then
					continue
				end
			end
		end
	end
	if v92 == nil then
		local v122, v123 = v_u_6.sizeFor((math.max(v90, 1)))
		local v124 = (v90 - v123) / 2
		local v125 = v_u_88 + math.max(0, v124)
		local v126 = (p74.X - v122) / 2
		v92 = {
			["x0"] = v126,
			["y0"] = v125,
			["x1"] = v126 + v122,
			["y1"] = v125 + v123
		}
		v93 = "center"
	end
	local v127 = {
		["mode"] = v93,
		["card"] = v92
	}
	for v128, v129 in v_u_6.parts(v92.x1 - v92.x0, v92.y1 - v92.y0, p76, p77) do
		v127[v128] = v129
	end
	return v127
end
function v_u_6.avoidFrom(p130, p131, p132, p133) -- name: avoidFrom
	local v134 = {}
	local v135 = {}
	if type(p130) ~= "table" or type(p131) ~= "table" then
		return v134, v135
	end
	local v136 = (p133.X - p132.X) / 2
	if p131.result == nil then
		local v137 = p130.top
		local v138 = type(v137) == "table" and {
			["x0"] = v137.x0 + v136,
			["y0"] = v137.y0 + 0,
			["x1"] = v137.x1 + v136,
			["y1"] = v137.y1 + 0
		} or nil
		if v138 then
			table.insert(v134, v138)
		end
		if p131.out ~= nil then
			local v139 = p133.Y - p132.Y
			local v140 = p130.specPrev
			local v141 = type(v140) == "table" and {
				["x0"] = v140.x0 + v136,
				["y0"] = v140.y0 + v139,
				["x1"] = v140.x1 + v136,
				["y1"] = v140.y1 + v139
			} or nil
			if v141 then
				table.insert(v134, v141)
			end
			local v142 = p130.specNext
			local v143 = type(v142) == "table" and {
				["x0"] = v142.x0 + v136,
				["y0"] = v142.y0 + v139,
				["x1"] = v142.x1 + v136,
				["y1"] = v142.y1 + v139
			} or nil
			if v143 then
				table.insert(v134, v143)
			end
			local v144 = p130.specLeave
			local v145 = type(v144) == "table" and {
				["x0"] = v144.x0 + v136,
				["y0"] = v144.y0 + v139,
				["x1"] = v144.x1 + v136,
				["y1"] = v144.y1 + v139
			} or nil
			if v145 then
				table.insert(v134, v145)
			end
			local v146 = p130.spec
			local v147 = type(v146) == "table" and {
				["x0"] = v146.x0 + v136,
				["y0"] = v146.y0 + v139,
				["x1"] = v146.x1 + v136,
				["y1"] = v146.y1 + v139
			} or nil
			if v147 then
				table.insert(v135, v147)
			end
		end
		local v148 = p130.banner
		local v149 = type(v148) == "table" and {
			["x0"] = v148.x0 + v136,
			["y0"] = v148.y0 + 0,
			["x1"] = v148.x1 + v136,
			["y1"] = v148.y1 + 0
		} or nil
		if v149 then
			table.insert(v135, v149)
		end
	else
		local v150 = (p133.Y - p132.Y) / 2
		local v151 = p130.endcard
		local v152 = type(v151) == "table" and {
			["x0"] = v151.x0 + v136,
			["y0"] = v151.y0 + v150,
			["x1"] = v151.x1 + v136,
			["y1"] = v151.y1 + v150
		} or nil
		if v152 then
			table.insert(v134, v152)
			return v134, v135
		end
	end
	return v134, v135
end
function v_u_6.new(p_u_153) -- name: new
	-- upvalues: (copy) v_u_6
	local v_u_154 = p_u_153.UI
	local v_u_155 = p_u_153.Theme
	local v_u_156 = p_u_153.R.HUNT_TEXTS
	local v157 = v_u_155.color
	local v158 = p_u_153.root
	local v_u_159 = p_u_153.now or os.clock
	local v_u_160 = {}
	local v_u_161 = true
	local v_u_162 = false
	local v_u_163 = false
	local v_u_164 = nil
	local v_u_165 = 0
	local v_u_166 = 0
	local v_u_167 = nil
	local v_u_168 = false
	local v_u_169 = nil
	local v_u_170 = "side"
	local v_u_171 = nil
	local v_u_172 = nil
	local v_u_173 = false
	local v_u_174 = ""
	local v_u_175 = 0
	local v_u_176 = v_u_154.new("Frame", {
		["Name"] = "KillCard",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v157.bg,
		["Size"] = UDim2.fromOffset(200, 400)
	}, v158)
	v_u_154.stroke(v_u_176, v157.lineStrong)
	v_u_154.new("Frame", {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 6,
		["BackgroundColor3"] = v157.danger,
		["Size"] = UDim2.new(1, 0, 0, 2)
	}, v_u_176)
	local v_u_177 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_176,
		["text"] = v_u_156.cardTitle,
		["color"] = v157.danger,
		["size"] = UDim2.fromOffset(10, 10)
	})
	local v_u_178 = v_u_154.new("Frame", {
		["Name"] = "AvatarPlate",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v157.raised
	}, v_u_176)
	v_u_154.stroke(v_u_178, v157.line)
	local v_u_179 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Initial",
		["text"] = "?",
		["style"] = "display",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["track"] = false,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_178,
		["color"] = v157.muted,
		["size"] = UDim2.fromScale(1, 1)
	})
	local v_u_180 = v_u_154.new("ImageLabel", {
		["Name"] = "Avatar",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Image"] = "",
		["ImageTransparency"] = 1,
		["ScaleType"] = nil,
		["Size"] = nil,
		["ZIndex"] = 4,
		["ScaleType"] = Enum.ScaleType.Crop,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_178)
	local v_u_181 = v_u_154.label({
		["parent"] = nil,
		["name"] = "Display",
		["text"] = "",
		["style"] = "bodyStrong",
		["textSize"] = 22,
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["track"] = false,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_176,
		["color"] = v157.text,
		["size"] = UDim2.fromOffset(10, 10)
	})
	local v_u_182 = v_u_154.label({
		["parent"] = nil,
		["name"] = "User",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["align"] = "center",
		["fit"] = true,
		["track"] = false,
		["size"] = nil,
		["zindex"] = 3,
		["parent"] = v_u_176,
		["color"] = v157.text2,
		["size"] = UDim2.fromOffset(10, 10)
	})
	local v_u_183, v184 = v_u_154.button({
		["parent"] = nil,
		["name"] = "KillReport",
		["text"] = nil,
		["kind"] = "alert",
		["size"] = nil,
		["zindex"] = 3,
		["onClick"] = nil,
		["parent"] = v_u_176,
		["text"] = v_u_156.report,
		["size"] = UDim2.fromOffset(10, 52),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_160
			v_u_160.pressReport()
		end
	})
	v184.label.TextSize = 20
	local v_u_185, _ = v_u_154.button({
		["parent"] = nil,
		["name"] = "KillContinue",
		["text"] = nil,
		["kind"] = "secondary",
		["size"] = nil,
		["zindex"] = 3,
		["onClick"] = nil,
		["parent"] = v_u_176,
		["text"] = v_u_156.cont,
		["size"] = UDim2.fromOffset(10, 44),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_160
			v_u_160.close("continue")
		end
	})
	local function v_u_193(p186) -- name: fill
		-- upvalues: (copy) v_u_156, (copy) v_u_181, (copy) v_u_182, (copy) v_u_179, (ref) v_u_6, (ref) v_u_173, (copy) v_u_180, (copy) v_u_183, (copy) p_u_153
		local v187
		if p186.display == "" then
			v187 = v_u_156.unknownPlayer
		else
			v187 = p186.display
		end
		v_u_181.Text = v187
		v_u_182.Text = p186.name == "" and "" or "@" .. p186.name
		v_u_179.Text = v_u_6.initial(v187)
		v_u_173 = false
		v_u_179.Visible = true
		v_u_180.ImageTransparency = 0
		v_u_180.Image = p186.fake == true and "" or v_u_6.thumb(p186.uid)
		local v188 = v_u_183
		local v189 = p_u_153.canReport
		local v190
		if type(v189) == "function" then
			local v191 = p_u_153.canReport
			local v192
			v190, v192 = pcall(v191)
			if v190 then
				v190 = v192 == true
			end
		else
			v190 = true
		end
		v188.Visible = v190
	end
	local function v_u_214(p194) -- name: relayout
		-- upvalues: (ref) v_u_171, (copy) v_u_155, (copy) p_u_153, (ref) v_u_6, (copy) v_u_154, (ref) v_u_170, (ref) v_u_172, (copy) v_u_176, (copy) v_u_177, (copy) v_u_178, (copy) v_u_181, (copy) v_u_182, (copy) v_u_183, (copy) v_u_185, (ref) v_u_167, (ref) v_u_169, (copy) v_u_159
		v_u_171 = p194
		local v195 = v_u_155.safeRefSize()
		local v196 = p_u_153.hudRects
		local v197
		if type(v196) == "function" then
			v197 = p_u_153.hudRects()
		else
			v197 = nil
		end
		local v198, v199 = v_u_6.avoidFrom(v197, p194 or {}, v_u_155.refSize(), v195)
		local v200 = v_u_6.layout(v195, {
			["l"] = 0,
			["t"] = 0,
			["r"] = 0,
			["b"] = 0
		}, v_u_155.isPhone(), v_u_155.touch(44), v_u_154.topInset(), v198, nil, v199)
		v_u_170 = v200.mode
		v_u_172 = v200.card
		local v201 = v200.card
		v_u_176.Position = UDim2.fromOffset(v201.x0, v201.y0)
		v_u_176.Size = UDim2.fromOffset(v201.x1 - v201.x0, v201.y1 - v201.y0)
		local v202 = v_u_177
		local v203 = v200.title
		v202.Position = UDim2.fromOffset(v203.x0, v203.y0)
		v202.Size = UDim2.fromOffset(v203.x1 - v203.x0, v203.y1 - v203.y0)
		local v204 = v_u_178
		local v205 = v200.avatar
		v204.Position = UDim2.fromOffset(v205.x0, v205.y0)
		v204.Size = UDim2.fromOffset(v205.x1 - v205.x0, v205.y1 - v205.y0)
		local v206 = v_u_181
		local v207 = v200.name
		v206.Position = UDim2.fromOffset(v207.x0, v207.y0)
		v206.Size = UDim2.fromOffset(v207.x1 - v207.x0, v207.y1 - v207.y0)
		local v208 = v_u_182
		local v209 = v200.user
		v208.Position = UDim2.fromOffset(v209.x0, v209.y0)
		v208.Size = UDim2.fromOffset(v209.x1 - v209.x0, v209.y1 - v209.y0)
		local v210 = v_u_183
		local v211 = v200.report
		v210.Position = UDim2.fromOffset(v211.x0, v211.y0)
		v210.Size = UDim2.fromOffset(v211.x1 - v211.x0, v211.y1 - v211.y0)
		local v212 = v_u_185
		local v213 = v200.cont
		v212.Position = UDim2.fromOffset(v213.x0, v213.y0)
		v212.Size = UDim2.fromOffset(v213.x1 - v213.x0, v213.y1 - v213.y0)
		if v200.mode == "center" and (v_u_167 ~= nil and v_u_169 == nil) then
			v_u_169 = v_u_159() + v_u_6.CENTER_SEC
		elseif v200.mode == "side" then
			v_u_169 = nil
		end
	end
	function v_u_160.show(p215, p216) -- name: show
		-- upvalues: (ref) v_u_161, (ref) v_u_164, (ref) v_u_162, (ref) v_u_163, (copy) v_u_159, (ref) v_u_165, (ref) v_u_166, (ref) v_u_6, (ref) v_u_167, (ref) v_u_168, (ref) v_u_169, (ref) v_u_175, (copy) v_u_193, (copy) v_u_214, (copy) v_u_176
		if v_u_161 and type(p215) == "table" then
			v_u_164 = p215
			v_u_162 = true
			v_u_163 = false
			local v217 = v_u_159()
			local v218 = v217 + v_u_6.CARD_SEC
			v_u_165 = v217
			v_u_166 = v218
			v_u_167 = nil
			v_u_168 = false
			v_u_169 = nil
			if type(p216) == "table" and p216.result ~= nil then
				v_u_167 = v217
				v_u_168 = true
			end
			v_u_175 = v_u_175 + 1
			v_u_193(p215)
			v_u_214(p216)
			v_u_176.Visible = true
		end
	end
	function v_u_160.close(p219) -- name: close
		-- upvalues: (ref) v_u_162, (ref) v_u_163, (ref) v_u_174, (ref) v_u_164, (copy) v_u_176
		if v_u_162 then
			v_u_162 = false
			v_u_163 = false
			v_u_174 = p219 or "closed"
			v_u_164 = nil
			v_u_176.Visible = false
		end
	end
	function v_u_160.relayout(p220) -- name: relayout
		-- upvalues: (ref) v_u_161, (ref) v_u_162, (ref) v_u_163, (copy) v_u_214
		if v_u_161 and (v_u_162 and not v_u_163) then
			v_u_214(p220)
		end
	end
	function v_u_160.step(p221, p222) -- name: step
		-- upvalues: (ref) v_u_161, (ref) v_u_162, (ref) v_u_171, (copy) v_u_160, (ref) v_u_173, (ref) v_u_164, (copy) v_u_180, (copy) v_u_179, (ref) v_u_167, (ref) v_u_165, (ref) v_u_6, (ref) v_u_168, (ref) v_u_163, (copy) v_u_214, (ref) v_u_169, (ref) v_u_166
		if v_u_161 and (v_u_162 and type(p222) == "table") then
			v_u_171 = p222
			if p222.home == nil then
				if p222.out == nil and p222.result == nil then
					v_u_160.close("alive")
					return
				else
					if not v_u_173 and (v_u_164 ~= nil and (v_u_164.fake ~= true and v_u_180.IsLoaded)) then
						v_u_173 = true
						v_u_179.Visible = false
					end
					if p222.result ~= nil and v_u_167 == nil then
						v_u_167 = p221
						if p221 - v_u_165 > v_u_6.END_NEAR_SEC then
							v_u_160.close("result")
							return
						end
						v_u_168 = true
						if not v_u_163 then
							v_u_214(p222)
						end
					end
					if v_u_163 then
						return
					elseif v_u_169 == nil or v_u_169 > p221 then
						if v_u_166 <= p221 then
							v_u_160.close("time")
						end
					else
						v_u_160.close("center")
					end
				end
			else
				v_u_160.close("home")
				return
			end
		else
			return
		end
	end
	function v_u_160.pressReport() -- name: pressReport
		-- upvalues: (ref) v_u_161, (ref) v_u_162, (ref) v_u_163, (ref) v_u_164, (copy) p_u_153, (copy) v_u_176
		if v_u_161 and (v_u_162 and (not v_u_163 and v_u_164 ~= nil)) then
			local v223 = p_u_153.onReport
			if type(v223) == "function" then
				local v224 = p_u_153.onReport
				local v225 = v_u_164
				local v226, v227 = pcall(v224, v225)
				if not v226 or v227 ~= true then
					return false
				end
				v_u_163 = true
				v_u_176.Visible = false
				return true
			end
		end
		return false
	end
	function v_u_160.reportClosed(p228) -- name: reportClosed
		-- upvalues: (ref) v_u_161, (ref) v_u_162, (ref) v_u_163, (copy) v_u_160, (ref) v_u_166, (copy) v_u_159, (ref) v_u_6, (copy) v_u_214, (ref) v_u_171, (copy) v_u_176
		if v_u_161 and (v_u_162 and v_u_163) then
			if p228 == true then
				v_u_160.close("sent")
			else
				v_u_163 = false
				local v229 = v_u_166
				local v230 = v_u_159() + v_u_6.BACK_SEC
				v_u_166 = math.max(v229, v230)
				v_u_214(v_u_171)
				v_u_176.Visible = true
			end
		else
			return
		end
	end
	function v_u_160.isOpen() -- name: isOpen
		-- upvalues: (ref) v_u_162
		return v_u_162
	end
	function v_u_160.isHidden() -- name: isHidden
		-- upvalues: (ref) v_u_163
		return v_u_163
	end
	function v_u_160.focusTargets() -- name: focusTargets
		-- upvalues: (ref) v_u_162, (ref) v_u_163, (copy) v_u_185, (copy) v_u_183
		local v231 = {}
		if v_u_162 and not v_u_163 then
			local v232 = v_u_185
			table.insert(v231, v232)
			if v_u_183.Visible then
				local v233 = v_u_183
				table.insert(v231, v233)
			end
		end
		return v231
	end
	function v_u_160.buttons() -- name: buttons
		-- upvalues: (copy) v_u_183, (copy) v_u_185
		return {
			["report"] = v_u_183,
			["cont"] = v_u_185
		}
	end
	function v_u_160.frame() -- name: frame
		-- upvalues: (copy) v_u_176
		return v_u_176
	end
	function v_u_160.snapshot() -- name: snapshot
		-- upvalues: (ref) v_u_162, (ref) v_u_164, (ref) v_u_165, (ref) v_u_166, (ref) v_u_163, (ref) v_u_167, (ref) v_u_168, (ref) v_u_169
		return v_u_162 and {
			["model"] = v_u_164,
			["openedAt"] = v_u_165,
			["deadline"] = v_u_166,
			["hidden"] = v_u_163,
			["resultAt"] = v_u_167,
			["kept"] = v_u_168,
			["centerUntil"] = v_u_169
		} or nil
	end
	function v_u_160.restore(p234, p235) -- name: restore
		-- upvalues: (ref) v_u_161, (ref) v_u_164, (ref) v_u_162, (ref) v_u_163, (ref) v_u_165, (ref) v_u_166, (ref) v_u_167, (ref) v_u_168, (ref) v_u_169, (copy) v_u_193, (copy) v_u_214, (copy) v_u_176
		if v_u_161 and type(p234) == "table" then
			local v236 = p234.model
			if type(v236) == "table" then
				v_u_164 = p234.model
				local v237 = p234.hidden == true
				v_u_162 = true
				v_u_163 = v237
				local v238 = p234.openedAt
				local v239 = p234.deadline
				local v240 = p234.resultAt
				local v241 = p234.kept == true
				local v242 = p234.centerUntil
				v_u_165 = v238
				v_u_166 = v239
				v_u_167 = v240
				v_u_168 = v241
				v_u_169 = v242
				v_u_193(v_u_164)
				v_u_214(p235)
				v_u_176.Visible = not v_u_163
				return
			end
		end
	end
	function v_u_160.state() -- name: state
		-- upvalues: (copy) v_u_159, (ref) v_u_162, (ref) v_u_163, (copy) v_u_176, (ref) v_u_170, (ref) v_u_164, (copy) v_u_181, (copy) v_u_182, (copy) v_u_179, (copy) v_u_180, (ref) v_u_173, (ref) v_u_166, (ref) v_u_168, (ref) v_u_169, (ref) v_u_172, (ref) v_u_174, (ref) v_u_175, (copy) v_u_183
		local v243 = v_u_159()
		local v244 = {
			["open"] = v_u_162,
			["hidden"] = v_u_163,
			["visible"] = v_u_176.Visible,
			["mode"] = v_u_170
		}
		local v245
		if v_u_164 then
			v245 = v_u_164.uid
		else
			v245 = nil
		end
		v244.uid = v245
		v244.display = v_u_181.Text
		v244.user = v_u_182.Text
		v244.initial = v_u_179.Text
		v244.image = v_u_180.Image
		v244.imageShown = v_u_173
		local v246
		if v_u_162 then
			local v247 = v_u_166 - v243
			v246 = math.max(0, v247)
		else
			v246 = 0
		end
		v244.left = v246
		v244.kept = v_u_168
		local v248
		if v_u_169 then
			local v249 = v_u_169 - v243
			v248 = math.max(0, v249)
		else
			v248 = nil
		end
		v244.centerLeft = v248
		v244.card = v_u_172
		v244.closedBy = v_u_174
		v244.shown = v_u_175
		v244.reportVisible = v_u_183.Visible
		return v244
	end
	function v_u_160.destroy() -- name: destroy
		-- upvalues: (ref) v_u_161, (ref) v_u_162, (ref) v_u_163, (ref) v_u_164, (copy) v_u_176
		v_u_161 = false
		v_u_162 = false
		v_u_163 = false
		v_u_164 = nil
		local function v250()
			-- upvalues: (ref) v_u_176
			v_u_176:Destroy()
		end
		pcall(v250)
	end
	return v_u_160
end
return v_u_6