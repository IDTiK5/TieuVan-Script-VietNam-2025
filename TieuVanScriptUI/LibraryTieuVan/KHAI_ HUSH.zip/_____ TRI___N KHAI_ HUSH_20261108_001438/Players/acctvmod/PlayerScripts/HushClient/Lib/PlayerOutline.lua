-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PlayerOutline

local v_u_1 = {
	["REFRESH"] = 0.2,
	["STATUS_OK"] = {
		["Alive"] = true,
		["Downed"] = true
	},
	["FADE_FROM"] = 0.5,
	["FLOOR_VIS_BAND"] = 0.15,
	["FLOOR_RANGE_ON"] = 0.85,
	["FLOOR_DWELL"] = 0.75,
	["STICKY"] = 0.9,
	["HARD_MAX"] = 14,
	["TOTAL_LIMIT"] = 30
}
local v_u_2 = {
	["Head"] = true,
	["Torso"] = true,
	["UpperTorso"] = true,
	["LowerTorso"] = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	["LeftUpperArm"] = true,
	["LeftLowerArm"] = true,
	["LeftHand"] = true,
	["RightUpperArm"] = true,
	["RightLowerArm"] = true,
	["RightHand"] = true,
	["LeftUpperLeg"] = true,
	["LeftLowerLeg"] = true,
	["LeftFoot"] = true,
	["RightUpperLeg"] = true,
	["RightLowerLeg"] = true,
	["RightFoot"] = true
}
function v_u_1.transparency(p3, p4, p5) -- name: transparency
	-- upvalues: (copy) v_u_1
	local v6 = (type(p5) ~= "number" or p5 ~= p5) and 0.6 or math.clamp(p5, 0, 1)
	if type(p3) == "number" and (p3 == p3 and (type(p4) == "number" and (p4 == p4 and p4 > 0))) then
		if p4 <= p3 then
			return 1
		else
			local v7 = p4 * v_u_1.FADE_FROM
			if p3 <= v7 then
				return v6
			else
				return v6 + (1 - v6) * ((p3 - v7) / (p4 - v7))
			end
		end
	else
		return 1
	end
end
function v_u_1.fade(p8, p9) -- name: fade
	local v10 = (type(p8) ~= "number" or p8 ~= p8) and 1 or math.clamp(p8, 0, 1)
	local v11 = (type(p9) ~= "number" or p9 ~= p9) and 0 or math.clamp(p9, 0, 1)
	return 1 - (1 - v10) * v11
end
function v_u_1.floorStep(p12, p13, p14, p15) -- name: floorStep
	-- upvalues: (copy) v_u_1
	if type(p13) ~= "table" or type(p15) ~= "table" then
		return nil
	end
	if p13.alive ~= true or p13.status ~= nil and v_u_1.STATUS_OK[p13.status] ~= true or p13.huntStatus == "Out" then
		return nil
	end
	local v16 = p13.dist
	local v17 = p15.range
	if type(v16) ~= "number" or (v16 ~= v16 or (type(v17) ~= "number" or (v17 ~= v17 or v17 <= v16))) then
		return nil
	end
	local v18 = (type(p14) ~= "number" or p14 ~= p14) and 0 or p14
	local v19 = p15.minVis
	local v20 = type(v19) ~= "number" and 0.25 or p15.minVis
	local v21 = p13.vis
	local v22 = (type(v21) ~= "number" or p13.vis ~= p13.vis) and 0 or p13.vis
	local v23
	if type(p12) == "table" then
		v23 = p12.on == true
	else
		v23 = false
	end
	local v24
	if v23 then
		v24 = v20 < v22
	elseif v20 + v_u_1.FLOOR_VIS_BAND <= v22 then
		v24 = v16 <= v17 * v_u_1.FLOOR_RANGE_ON
	else
		v24 = false
	end
	if type(p12) ~= "table" then
		return {
			["on"] = v24,
			["t"] = v18 - v_u_1.FLOOR_DWELL
		}
	end
	if v24 ~= v23 then
		local v25 = p12.t
		if v18 - (tonumber(v25) or (-1 / 0)) >= v_u_1.FLOOR_DWELL then
			return {
				["on"] = v24,
				["t"] = v18
			}
		end
	end
	local v26 = {
		["on"] = v23
	}
	local v27 = p12.t
	v26.t = tonumber(v27) or v18
	return v26
end
function v_u_1.tint(p28, p29) -- name: tint
	local v30
	if type(p29) == "table" then
		if p28 then
			v30 = p29.mate
		else
			v30 = p29.other
		end
	else
		v30 = nil
	end
	if typeof(v30) == "Color3" then
		return v30
	elseif p28 then
		return Color3.fromRGB(120, 205, 150)
	else
		return Color3.fromRGB(225, 230, 238)
	end
end
function v_u_1.modeOn(p31, p32, p33, p34) -- name: modeOn
	local v35
	if p31 == true and p32 == "Raid" then
		v35 = p33 == true and true or p34 == true
	else
		v35 = false
	end
	return v35
end
function v_u_1.wants(p36, p37) -- name: wants
	-- upvalues: (copy) v_u_1
	if type(p36) ~= "table" or type(p37) ~= "table" then
		return false
	end
	if p36.alive ~= true then
		return false
	end
	if p36.status ~= nil and v_u_1.STATUS_OK[p36.status] ~= true then
		return false
	end
	if p36.huntStatus == "Out" then
		return false
	end
	local v38 = p36.dist
	local v39 = p37.range
	if type(v38) ~= "number" or (v38 ~= v38 or (type(v39) ~= "number" or (v39 ~= v39 or v39 <= v38))) then
		return false
	end
	local v40 = p37.minVis
	local v41 = type(v40) ~= "number" and 0.25 or p37.minVis
	local v42 = p36.vis
	return type(v42) == "number" and (p36.vis == p36.vis and p36.vis > v41)
end
function v_u_1.pick(p_u_43, p44) -- name: pick
	-- upvalues: (copy) v_u_1
	local v45
	if type(p44) == "number" and p44 == p44 then
		local v46 = math.floor(p44)
		v45 = math.max(0, v46)
	else
		v45 = 0
	end
	local v47 = {}
	for v48 = 1, #p_u_43 do
		table.insert(v47, v48)
	end
	table.sort(v47, function(p49, p50)
		-- upvalues: (copy) p_u_43, (ref) v_u_1
		local v51 = p_u_43[p49]
		local v52 = v51.d
		local v53 = type(v52) ~= "number" and (1 / 0) or v51.d
		if v51.had == true then
			v53 = v53 * v_u_1.STICKY
		end
		local v54 = p_u_43[p50]
		local v55 = v54.d
		local v56 = type(v55) ~= "number" and (1 / 0) or v54.d
		if v54.had == true then
			v56 = v56 * v_u_1.STICKY
		end
		if v53 == v56 then
			return p49 < p50
		else
			return v53 < v56
		end
	end)
	local v57 = #v47
	local v58 = {}
	for v59 = 1, math.min(v45, v57) do
		v58[v59] = v47[v59]
	end
	return v58
end
function v_u_1.budget(p60, p61) -- name: budget
	-- upvalues: (copy) v_u_1
	local v62
	if type(p60) == "number" and p60 == p60 then
		local v63 = math.floor(p60)
		v62 = math.max(0, v63)
	else
		v62 = 0
	end
	local v64 = v_u_1.HARD_MAX
	local v65 = math.min(v64, v62)
	if type(p61) == "number" and (p61 == p61 and p61 > 0) then
		local v66 = v_u_1.TOTAL_LIMIT - math.floor(p61)
		local v67 = math.max(0, v66)
		v65 = math.min(v65, v67)
	end
	return v65
end
v_u_1.OTHER_RESERVE = 13
v_u_1.TRAP_RESERVE = 4
function v_u_1.foreignEstimate(p68, p69, p70) -- name: foreignEstimate
	-- upvalues: (copy) v_u_1
	return ((type(p68) ~= "number" or p68 ~= p68) and 0 or math.max(0, p68)) + ((type(p69) ~= "number" or p69 ~= p69) and 0 or math.max(0, p69)) + v_u_1.OTHER_RESERVE + (p70 ~= true and 0 or v_u_1.TRAP_RESERVE)
end
function v_u_1.viewOk(p71, p72) -- name: viewOk
	local v73
	if p71 == "scripted" or p71 == "spectate" then
		v73 = false
	else
		v73 = p72 ~= "Out"
	end
	return v73
end
function v_u_1.liftColor(p74, p75) -- name: liftColor
	local v76 = (type(p75) ~= "number" or p75 ~= p75) and 0 or math.clamp(p75, 0, 1)
	if v76 <= 0 then
		return p74
	end
	local v77 = p74.R
	local v78 = p74.G
	local v79 = p74.B
	local v80 = math.max(v77, v78, v79)
	if v76 <= v80 then
		return p74
	end
	if v80 <= 0.0005 then
		return Color3.new(v76, v76, v76)
	end
	local v81 = v76 / v80
	local v82 = Color3.new
	local v83 = p74.R * v81
	local v84 = math.min(1, v83)
	local v85 = p74.G * v81
	local v86 = math.min(1, v85)
	local v87 = p74.B * v81
	return v82(v84, v86, (math.min(1, v87)))
end
function v_u_1.isBodyPart(p88) -- name: isBodyPart
	-- upvalues: (copy) v_u_2
	if typeof(p88) == "Instance" and (p88:IsA("BasePart") and v_u_2[p88.Name] == true) then
		return p88:GetAttribute("BlockRole") ~= "decor"
	else
		return false
	end
end
local v_u_89 = {}
v_u_89.__index = v_u_89
function v_u_1.new(p90) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_89
	local v91 = {
		["env"] = nil,
		["acc"] = nil,
		["hl"] = nil,
		["orig"] = nil,
		["fstate"] = nil,
		["nHl"] = 0,
		["nLift"] = 0,
		["on"] = false,
		["env"] = p90,
		["acc"] = v_u_1.REFRESH,
		["hl"] = {},
		["orig"] = {},
		["fstate"] = {}
	}
	local v92 = v_u_89
	return setmetatable(v91, v92)
end
local function v_u_97(p93, p94) -- name: restoreParts
	for v95, v96 in p93.orig do
		if p94 ~= nil and p94[v95] then
			continue
		end
		p93.orig[v95] = nil
		if v95.Parent == nil or v95.Color ~= v96.set then
			continue
		end
		v95.Color = v96.orig
	end
end
local function v_u_107(p98, p99, p100, p101) -- name: floorChar
	-- upvalues: (copy) v_u_1
	for _, v102 in p99:GetChildren() do
		if not v_u_1.isBodyPart(v102) then
			continue
		end
		p101[v102] = true
		local v103 = p98.orig[v102]
		local v104 = v102.Color
		local v105
		if v103 == nil or v104 ~= v103.set then
			v105 = v104
		else
			v105 = v103.orig
		end
		local v106 = v_u_1.liftColor(v105, p100)
		if v106 == v105 then
			if v103 == nil then
				continue
			end
			if v104 ~= v105 then
				v102.Color = v105
			end
			p98.orig[v102] = nil
		else
			if v104 ~= v106 then
				v102.Color = v106
			end
			p98.orig[v102] = {
				["orig"] = v105,
				["set"] = v102.Color
			}
		end
	end
end
function v_u_89.clear(p108) -- name: clear
	for v109 in table.clone(p108.hl) do
		local v_u_110 = p108.hl[v109]
		if not v_u_110 then
			continue
		end
		p108.hl[v109] = nil
		pcall(function()
			-- upvalues: (copy) v_u_110
			v_u_110:Destroy()
		end)
	end
	for v111, v112 in p108.orig do
		p108.orig[v111] = nil
		if v111.Parent == nil or v111.Color ~= v112.set then
			continue
		end
		v111.Color = v112.orig
	end
	table.clear(p108.fstate)
	p108.nHl = 0
	p108.nLift = 0
	p108.on = false
end
function v_u_89.forget(p113, p114) -- name: forget
	local v_u_115 = p113.hl[p114]
	if v_u_115 then
		p113.hl[p114] = nil
		pcall(function()
			-- upvalues: (copy) v_u_115
			v_u_115:Destroy()
		end)
	end
	p113.fstate[p114] = nil
end
function v_u_89.count(p116) -- name: count
	return p116.nHl
end
function v_u_89.lifted(p117) -- name: lifted
	return p117.nLift
end
function v_u_89.state(p118) -- name: state
	return string.format("on=%s outlines=%d lifted=%d", p118.on and "1" or "0", p118.nHl, p118.nLift)
end
function v_u_89.step(p119, p120) -- name: step
	-- upvalues: (copy) v_u_1
	p119.acc = p119.acc + p120
	if p119.acc >= v_u_1.REFRESH then
		p119.acc = 0
		p119:refresh()
	end
end
function v_u_89.refresh(p121) -- name: refresh
	-- upvalues: (copy) v_u_1, (copy) v_u_107, (copy) v_u_97
	local v122 = p121.env
	local v123 = p121.env.cfg
	if type(v123) == "function" then
		v123 = v123()
	end
	local v124 = type(v123) ~= "table" and {} or v123
	local v125 = v122.localPlayer
	local v126 = v125:GetAttribute("HuntPlayer") == true
	local v127 = v122.place()
	local v128 = v125.Character
	local v129
	if v128 then
		v129 = v128:FindFirstChild("HumanoidRootPart")
	else
		v129 = v128
	end
	local v130
	if v128 and v128.Parent ~= nil and v128:GetAttribute("Dead") ~= true then
		local v131 = v128:FindFirstChildOfClass("Humanoid")
		v130 = (not v131 or v131.Health > 0) and true or false
	else
		v130 = false
	end
	local v132 = v125:GetAttribute("RaidStatus")
	local v133
	if v122.cameraMode then
		v133 = v122.cameraMode()
	else
		v133 = nil
	end
	local v134 = v125:GetAttribute("HuntStatus")
	local v135 = v_u_1.modeOn(v124.enabled, v127, v122.pvpRule(), v126)
	if v135 then
		if v129 == nil then
			v130 = false
		elseif v130 then
			if v132 == nil or v_u_1.STATUS_OK[v132] == true then
				v130 = v_u_1.viewOk(v133, v134)
			else
				v130 = false
			end
		end
	else
		v130 = v135
	end
	p121.on = v130
	if v130 then
		local v136 = v129.Position
		local v137 = {}
		local v138 = {}
		local v139 = v124.floor
		local v140 = type(v139) ~= "number" and 0 or v124.floor
		local v141
		if v122.now then
			v141 = v122.now()
		else
			v141 = os.clock()
		end
		local v142 = {}
		for _, v143 in v122.players() do
			if v143 == v125 or v143.UserId == v125.UserId then
				continue
			end
			local v144 = v143.Character
			local v145
			if v144 then
				v145 = v144:FindFirstChild("HumanoidRootPart")
			else
				v145 = v144
			end
			if v144 == nil or v145 == nil then
				continue
			end
			local v146
			if v144 and v144.Parent ~= nil and v144:GetAttribute("Dead") ~= true then
				local v147 = v144:FindFirstChildOfClass("Humanoid")
				v146 = (not v147 or v147.Health > 0) and true or false
			else
				v146 = false
			end
			local v148 = (v145.Position - v136).Magnitude
			local v149 = v122.vis
			local v150 = not v149 and 1 or v149(v145.Position)
			local v151 = {
				["alive"] = v146,
				["status"] = v143:GetAttribute("RaidStatus"),
				["huntStatus"] = v143:GetAttribute("HuntStatus"),
				["vis"] = v150 or 1,
				["dist"] = v148
			}
			local v152 = v122.isMate(v143) == true
			local v153
			if v122.isTeam == nil then
				v153 = false
			else
				v153 = v122.isTeam(v143) == true
			end
			if v_u_1.wants(v151, v124) and (not v153 and (not v152 or v124.mates == true)) then
				local v154 = {
					["id"] = v143.UserId,
					["char"] = v144,
					["d"] = v148,
					["vis"] = v151.vis,
					["had"] = p121.hl[v143.UserId] ~= nil,
					["mate"] = v152
				}
				table.insert(v137, v154)
			end
			if v140 <= 0 or (v152 or v153) then
				continue
			end
			local v155 = v_u_1.floorStep(p121.fstate[v143.UserId], v151, v141, v124)
			if v155 == nil then
				continue
			end
			p121.fstate[v143.UserId] = v155
			v142[v143.UserId] = true
			if not v155.on then
				continue
			end
			v_u_107(p121, v144, v140, v138)
		end
		for v156 in table.clone(p121.fstate) do
			if v142[v156] then
				continue
			end
			p121.fstate[v156] = nil
		end
		v_u_97(p121, v138)
		local v157 = 0
		for _ in p121.orig do
			v157 = v157 + 1
		end
		p121.nLift = v157
		local v158 = not v122.foreign and 0 or v122.foreign()
		local v159 = v_u_1.pick(v137, v_u_1.budget(v124.max, v158))
		local v160 = v122.parent()
		local v161 = {}
		for _, v162 in v159 do
			local v163 = v137[v162]
			v161[v163.id] = true
			local v164 = p121.hl[v163.id]
			if v164 ~= nil and (v164.Parent == nil or v164.Adornee ~= v163.char) then
				local v165 = v163.id
				local v_u_166 = p121.hl[v165]
				if v_u_166 then
					p121.hl[v165] = nil
					pcall(function()
						-- upvalues: (copy) v_u_166
						v_u_166:Destroy()
					end)
					v164 = nil
				else
					v164 = nil
				end
			end
			if v164 == nil and v160 ~= nil then
				v164 = Instance.new("Highlight")
				local v167 = v163.id
				v164.Name = "Outline_" .. tostring(v167)
				v164.FillTransparency = 1
				v164.DepthMode = Enum.HighlightDepthMode.Occluded
				v164.OutlineTransparency = 1
				v164.Adornee = v163.char
				v164.Parent = v160
				p121.hl[v163.id] = v164
			end
			if v164 == nil then
				continue
			end
			v164.FillTransparency = 1
			v164.DepthMode = Enum.HighlightDepthMode.Occluded
			v164.OutlineColor = v_u_1.tint(v163.mate, v124.colors)
			v164.OutlineTransparency = v_u_1.fade(v_u_1.transparency(v163.d, v124.range, v124.transparency), v163.vis)
		end
		for v168 in table.clone(p121.hl) do
			if v161[v168] then
				continue
			end
			local v_u_169 = p121.hl[v168]
			if not v_u_169 then
				continue
			end
			p121.hl[v168] = nil
			pcall(function()
				-- upvalues: (copy) v_u_169
				v_u_169:Destroy()
			end)
		end
		local v170 = 0
		for _ in p121.hl do
			v170 = v170 + 1
		end
		p121.nHl = v170
	elseif p121.nHl > 0 or next(p121.orig) ~= nil then
		p121:clear()
	end
end
return v_u_1