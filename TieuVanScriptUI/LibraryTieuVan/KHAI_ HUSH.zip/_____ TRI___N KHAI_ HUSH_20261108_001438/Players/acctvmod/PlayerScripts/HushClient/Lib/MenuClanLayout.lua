-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanLayout

local v_u_138 = {
	["TOUCH"] = 44,
	["MARGIN"] = 24,
	["PAD"] = 16,
	["PAD_PHONE"] = 8,
	["PHONE_ROW_MIN"] = 560,
	["kindOf"] = function(p1, p2) -- name: kindOf
		local v3 = tonumber(p1) or 1280
		local v4 = tonumber(p2) or 720
		return (v3 < 900 or v4 < 500) and "phone" or (v3 < 1180 and "mid" or "wide")
	end,
	["CHIP_TEXT"] = 42,
	["btnPadX"] = function(p5, p6) -- name: btnPadX
		if p5 ~= true then
			return 20
		end
		local v7 = tonumber(p6) or 1
		local v8 = 20 / math.max(v7, 0.5)
		local v9 = math.ceil(v8)
		return math.max(20, v9)
	end,
	["chipW"] = function(p10, p11, p12, p13) -- name: chipW
		-- upvalues: (copy) v_u_138
		local v14 = v_u_138.btnPadX(p11, p12)
		local v15 = p10 == "phone" and 76 or 96
		if type(p13) == "number" and p13 < v_u_138.PHONE_ROW_MIN then
			local v16 = v15 - 2 * v14
			return v15, math.max(20, v16)
		end
		local v17 = v_u_138.CHIP_TEXT + 2 * v14 + 2
		local v18 = math.max(v15, v17)
		return v18, v18 - 2 * v14
	end,
	["gridWidth"] = function(p19, p20, p21) -- name: gridWidth
		local v22 = p19 * p20
		local v23 = p19 - 1
		return v22 + math.max(0, v23) * p21
	end,
	["metrics"] = function(p24, p25, p26) -- name: metrics
		-- upvalues: (copy) v_u_138
		local v27 = tonumber(p24) or 1280
		local v28 = tonumber(p25) or 720
		local v29 = v_u_138.kindOf(v27, v28)
		local v30 = v_u_138.TOUCH
		local v31 = tonumber(p26) or v_u_138.TOUCH
		local v32 = math.max(v30, v31)
		local v33 = v_u_138.TOUCH >= v32 and 0 or v32
		local v34
		if v29 == "phone" then
			v34 = v_u_138.PAD_PHONE
		else
			v34 = v_u_138.PAD
		end
		local v35 = v27 - 2 * v_u_138.MARGIN
		local v36 = v35 - 2 * v34
		local v37 = {
			["kind"] = nil,
			["refX"] = nil,
			["refY"] = nil,
			["panelW"] = nil,
			["pad"] = nil,
			["inner"] = nil,
			["touch"] = nil,
			["btnH"] = nil,
			["gap"] = 8,
			["colGap"] = 16,
			["twoCol"] = nil,
			["phoneRow"] = nil,
			["headH"] = nil,
			["subTabH"] = nil,
			["rowH"] = nil,
			["inputH"] = nil,
			["barH"] = nil,
			["kind"] = v29,
			["refX"] = v27,
			["refY"] = v28,
			["panelW"] = v35,
			["pad"] = v34,
			["inner"] = v36,
			["touch"] = v32,
			["btnH"] = v32,
			["twoCol"] = v29 ~= "phone"
		}
		local v38
		if v29 == "phone" then
			v38 = v_u_138.PHONE_ROW_MIN <= v36
		else
			v38 = false
		end
		v37.phoneRow = v38
		v37.headH = v29 == "phone" and 32 or 44
		local v39 = v29 == "phone" and 40 or 44
		v37.subTabH = math.max(v39, v33)
		local v40 = v29 == "wide" and 48 or 44
		v37.rowH = math.max(v40, v33)
		v37.inputH = v32
		local v41 = v29 == "phone" and 52 or 48
		local v42 = v33 <= 0 and 0 or v33 + 4
		v37.barH = math.max(v41, v42)
		if v29 == "wide" then
			v37.listW = 420
		elseif v29 == "mid" then
			local v43 = v36 * 0.4
			v37.listW = math.floor(v43)
		else
			v37.listW = v36
		end
		local v44
		if v37.twoCol then
			v44 = v36 - v37.listW - v37.colGap
		else
			v44 = v36
		end
		v37.detailW = v44
		local v45 = v29 == "wide" and 56 or 44
		v37.tile = math.max(v45, v33)
		v37.tileGap = v29 == "wide" and 3 or 2
		if v29 == "phone" then
			v37.switch = true
			v37.gridW = v36
			local v46 = (v36 + v37.tileGap) / (v37.tile + v37.tileGap)
			local v47 = math.floor(v46)
			v37.stashCols = math.max(1, v47)
			v37.stepperW = v36
		else
			v37.switch = false
			local v48 = (v36 - v37.colGap) / 2
			v37.gridW = math.floor(v48)
			local v49 = (v37.gridW + v37.tileGap) / (v37.tile + v37.tileGap)
			local v50 = math.floor(v49)
			local v51 = math.min(10, v50)
			v37.stashCols = math.max(1, v51)
			v37.stepperW = v37.gridW
		end
		v37.gridPx = v_u_138.gridWidth(v37.stashCols, v37.tile, v37.tileGap)
		local v52 = v29 == "wide" and 40 or 44
		v37.boardRowH = math.max(v52, v33)
		v37.memberRowH = v37.rowH
		v37.badgeH = 18
		local v53 = v37.detailW
		v37.fieldW = math.min(420, v53)
		return v37
	end,
	["shell"] = function(p54, p55, p56, p57) -- name: shell
		local v58 = p54.inner
		if not p54.phoneRow then
			local v59 = p54.headH
			local v60
			if p56 then
				v60 = {
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v59,
					["w"] = v58,
					["h"] = p57
				}
				v59 = v59 + p57
			else
				v60 = nil
			end
			local v61 = {
				["oneRow"] = false,
				["head"] = nil,
				["tabs"] = nil,
				["notice"] = nil,
				["bodyY"] = nil,
				["head"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = nil,
					["w"] = v58,
					["h"] = p54.headH
				},
				["tabs"] = {
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = v59,
					["w"] = v58,
					["h"] = p55
				},
				["notice"] = v60,
				["bodyY"] = v59 + p55 + 6
			}
			return v61
		end
		local v62 = v58 * 0.24
		local v63 = math.floor(v62)
		local v64 = math.min(200, v63)
		local v65 = v64 + 8
		local v66, v67
		if p56 then
			v66 = p55 + p57
			v67 = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["y"] = p55,
				["w"] = v58,
				["h"] = p57
			}
		else
			v66 = p55
			v67 = nil
		end
		local v68 = {
			["oneRow"] = true,
			["head"] = nil,
			["tabs"] = nil,
			["notice"] = nil,
			["bodyY"] = nil,
			["head"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = v64,
				["h"] = p55
			},
			["tabs"] = {
				["x"] = nil,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["x"] = v65,
				["w"] = v58 - v65,
				["h"] = p55
			},
			["notice"] = v67,
			["bodyY"] = v66 + 4
		}
		return v68
	end,
	["pageH"] = function(p69) -- name: pageH
		local v70 = p69.refY - 64 - (p69.kind == "phone" and 0 or 56) - 30 - 8 - 2 * p69.pad
		return math.max(0, v70)
	end,
	["bodyH"] = function(p71, p72, p73, p74) -- name: bodyH
		-- upvalues: (copy) v_u_138
		local v75 = v_u_138.shell(p71, p72, p73 == true, p74 or 0)
		local v76 = v_u_138.pageH(p71) - v75.bodyY
		return math.max(0, v76)
	end,
	["footParts"] = function(p77, p78, p79, p80, p81) -- name: footParts
		-- upvalues: (copy) v_u_138
		local v82 = v_u_138.TOUCH
		local v83 = math.max(v82, p79)
		if p80 then
			local v84 = {
				["x"] = nil,
				["y"] = 40,
				["w"] = 48,
				["h"] = nil,
				["x"] = v83 + 4,
				["h"] = v83
			}
			local v85 = {
				["x"] = nil,
				["y"] = 40,
				["w"] = nil,
				["h"] = nil,
				["x"] = v83 + 4 + 48 + 4,
				["w"] = v83,
				["h"] = v83
			}
			local v86 = v85.x + v83 + 4
			local v87 = p77 - v86
			local v88 = {
				["minus"] = {
					["x"] = 0,
					["y"] = 40,
					["w"] = nil,
					["h"] = nil,
					["w"] = v83,
					["h"] = v83
				},
				["qty"] = v84,
				["plus"] = v85,
				["all"] = {
					["x"] = nil,
					["y"] = 40,
					["w"] = nil,
					["h"] = nil,
					["x"] = v86,
					["w"] = math.max(0, v87),
					["h"] = v83
				},
				["picked"] = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = 34,
					["w"] = p77
				},
				["act"] = {
					["x"] = 0,
					["y"] = nil,
					["w"] = nil,
					["h"] = nil,
					["y"] = p78 - v83,
					["w"] = p77,
					["h"] = v83
				}
			}
			return v88
		end
		local v89 = p78 - 4
		local v90 = p81 or 130
		local v91 = 0
		local v92 = {
			["x"] = nil,
			["y"] = 2,
			["w"] = nil,
			["h"] = nil,
			["x"] = v91,
			["w"] = v83,
			["h"] = v89
		}
		local v93 = v91 + (v83 + 4)
		local v94 = {
			["x"] = nil,
			["y"] = 2,
			["w"] = 52,
			["h"] = nil,
			["x"] = v93,
			["h"] = v89
		}
		local v95 = v93 + 56
		local v96 = {
			["x"] = nil,
			["y"] = 2,
			["w"] = nil,
			["h"] = nil,
			["x"] = v95,
			["w"] = v83,
			["h"] = v89
		}
		local v97 = v95 + (v83 + 4)
		local v98 = {
			["x"] = nil,
			["y"] = 2,
			["w"] = nil,
			["h"] = nil,
			["x"] = v97,
			["w"] = math.max(60, v83),
			["h"] = v89
		}
		local v99 = v97 + (v98.w + 4)
		local v100 = p77 - v99 - v90 - 12
		local v101 = math.max(0, v100)
		local v102 = {
			["minus"] = v92,
			["qty"] = v94,
			["plus"] = v96,
			["all"] = v98,
			["picked"] = {
				["x"] = nil,
				["y"] = 2,
				["w"] = nil,
				["h"] = nil,
				["x"] = v99 + 4,
				["w"] = v101,
				["h"] = v89
			},
			["act"] = {
				["x"] = nil,
				["y"] = 2,
				["w"] = nil,
				["h"] = nil,
				["x"] = p77 - v90,
				["w"] = v90,
				["h"] = v89
			}
		}
		return v102
	end,
	["stashPhone"] = function(p103, p104, p105, p106, p107) -- name: stashPhone
		-- upvalues: (copy) v_u_138
		local v108 = v_u_138.TOUCH
		local v109 = math.max(v108, p105)
		local v110 = v109 + 6
		local v111 = p104 - v110
		local v112 = math.max(0, v111)
		local v113 = p103 - 244 - 10
		local v114 = (v113 - 8 + p107) / (p106 + p107)
		local v115 = math.floor(v114)
		local v116 = math.max(1, v115)
		local v117 = {
			["x"] = nil,
			["y"] = nil,
			["w"] = 244,
			["h"] = nil,
			["x"] = v113 + 10,
			["y"] = v110,
			["h"] = v112
		}
		local v118 = v112 - 26
		local v119 = {
			["x"] = 0,
			["y"] = 26,
			["w"] = 244,
			["h"] = nil,
			["h"] = math.max(0, v118)
		}
		local v120 = v_u_138.footParts(244, v119.h, v109, true)
		local v121 = {
			["top"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = nil,
				["h"] = nil,
				["w"] = p103,
				["h"] = v109
			},
			["switch"] = {
				["x"] = 0,
				["y"] = 0,
				["w"] = 200,
				["h"] = nil,
				["h"] = v109
			}
		}
		local v122 = p103 - 200 - 10 - 130 - 6
		v121.status = {
			["x"] = 210,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = math.max(0, v122),
			["h"] = v109
		}
		v121.limit = {
			["x"] = nil,
			["y"] = 0,
			["w"] = 130,
			["h"] = nil,
			["x"] = p103 - 130,
			["h"] = v109
		}
		v121.grid = {
			["x"] = 0,
			["y"] = nil,
			["w"] = nil,
			["h"] = nil,
			["y"] = v110,
			["w"] = v113,
			["h"] = v112
		}
		v121.cols = v116
		v121.gridPx = v_u_138.gridWidth(v116, p106, p107)
		local v123 = (v112 + p107) / (p106 + p107)
		v121.rows = math.floor(v123)
		v121.side = v117
		v121.sideHead = {
			["x"] = 0,
			["y"] = 0,
			["w"] = 244,
			["h"] = 22
		}
		v121.foot = v119
		v121.footParts = v120
		return v121
	end,
	["TIP_BAND_GAP"] = 24,
	["TIP_BAND_TIME"] = 0.15,
	["tipBand"] = function(p124, p125, p126) -- name: tipBand
		-- upvalues: (copy) v_u_138
		if p124 == nil or p124 <= 0 then
			return 0
		end
		local v127 = p124 / math.max(p125, 0.01) + v_u_138.TIP_BAND_GAP - p126
		local v128 = math.ceil(v127)
		return math.max(0, v128)
	end,
	["bandMove"] = function(p129, p130) -- name: bandMove
		-- upvalues: (copy) v_u_138
		local v131 = p130 - p129
		return math.abs(v131) >= 1 and {
			["from"] = p129,
			["to"] = p130,
			["time"] = v_u_138.TIP_BAND_TIME
		} or nil
	end,
	["invRow"] = function(p132) -- name: invRow
		local v133 = p132.kind == "phone" and 96 or 110
		local v134 = p132.inner - 6 - 12 - v133 - 14
		return {
			["rowH"] = nil,
			["btnW"] = nil,
			["textW"] = nil,
			["headH"] = nil,
			["cancelAllW"] = nil,
			["left"] = 12,
			["right"] = 6,
			["slotsX"] = 250,
			["slotsW"] = nil,
			["rowH"] = p132.rowH,
			["btnW"] = v133,
			["textW"] = v134,
			["headH"] = p132.rowH,
			["cancelAllW"] = p132.kind == "phone" and 180 or 200,
			["slotsW"] = p132.inner - 6 - 250
		}
	end,
	["fits"] = function(p135) -- name: fits
		-- upvalues: (copy) v_u_138
		local v136 = {}
		local v137 = v_u_138.invRow(p135)
		if v137.rowH < p135.touch or (v137.headH < p135.touch or (v137.btnW < p135.touch or (v137.textW < 60 or (v137.left + v137.textW + v137.btnW + v137.right > p135.inner or v137.cancelAllW + v137.left + v137.right > p135.inner)))) then
			table.insert(v136, "invRow")
		end
		if p135.rowH < v_u_138.TOUCH then
			table.insert(v136, "rowH")
		end
		if p135.btnH < v_u_138.TOUCH or (p135.inputH < v_u_138.TOUCH or p135.subTabH < v_u_138.TOUCH - 4) then
			table.insert(v136, "controls")
		end
		if p135.tile < v_u_138.TOUCH then
			table.insert(v136, "tile")
		end
		if p135.gridPx > p135.gridW then
			table.insert(v136, "grid wider than its column")
		end
		if not p135.switch and 2 * p135.gridW + p135.colGap > p135.inner then
			table.insert(v136, "two grids do not fit")
		end
		if p135.twoCol and p135.listW + p135.colGap + p135.detailW > p135.inner then
			table.insert(v136, "columns")
		end
		if p135.detailW < 300 then
			table.insert(v136, "detail too narrow")
		end
		return #v136 == 0, v136
	end
}
return v_u_138