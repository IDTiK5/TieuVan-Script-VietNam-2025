-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ScopeLayout

local v_u_1 = {
	["CIRCLE_FRACTION"] = 0.86,
	["ROWS"] = 120,
	["ENTER"] = 0.9,
	["EXIT"] = 0.9,
	["FADE"] = 0.08,
	["SWAY_DEG"] = 0.15,
	["TP_READY"] = 0.95,
	["SOFT_FRACTION"] = 0.012,
	["SOFT_TRANSPARENCY"] = 0.6,
	["RING_MIN_FRACTION"] = 0.008
}
local v_u_2 = math.floor
local v_u_3 = math.ceil
local v_u_4 = math.sqrt
local v_u_5 = math.abs
local v_u_6 = math.max
local v_u_7 = math.min
function v_u_1.circle(p8, p9, p10) -- name: circle
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7
	local v11 = v_u_6(1, (type(p8) ~= "number" or (p8 ~= p8 or (p8 <= -1000000000 or p8 >= 1000000000))) and 1 or p8)
	local v12 = v_u_6(1, (type(p9) ~= "number" or (p9 ~= p9 or (p9 <= -1000000000 or p9 >= 1000000000))) and 1 or p9)
	local v13 = v_u_1.CIRCLE_FRACTION
	if type(p10) == "number" and (p10 == p10 and (p10 > -1000000000 and p10 < 1000000000)) then
		v13 = p10
	end
	local v14 = v_u_6(0.3, (v_u_7(1, v13)))
	local v15 = v_u_7(v11, v12)
	local v16 = v15 * v14
	local v17 = v16 / 2
	local v18 = v11 / 2
	local v19 = v12 / 2
	return {
		["cx"] = v18,
		["cy"] = v19,
		["r"] = v17,
		["d"] = v16,
		["x"] = v18 - v17,
		["y"] = v19 - v17,
		["short"] = v15
	}
end
local function v_u_34(p20, p21, p22) -- name: boundaries
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3
	local v23 = v_u_6(2, p22 - 2)
	local v24 = {}
	local v25 = v_u_6(0, (v_u_7(p20, 0)))
	if #v24 == 0 or v24[#v24] < v25 then
		table.insert(v24, v25)
	end
	local v26 = v_u_6(0, (v_u_7(p20, (v_u_2(p21.cy - p21.r)))))
	if #v24 == 0 or v24[#v24] < v26 then
		table.insert(v24, v26)
	end
	for v27 = 1, v23 - 1 do
		local v28 = p21.cy
		local v29 = p21.r
		local v30 = 3.141592653589793 * v27 / v23
		local v31 = v_u_6(0, (v_u_7(p20, (v_u_2(v28 - v29 * math.cos(v30) + 0.5)))))
		if #v24 ~= 0 and v24[#v24] >= v31 then
			continue
		end
		table.insert(v24, v31)
	end
	local v32 = v_u_6(0, (v_u_7(p20, (v_u_3(p21.cy + p21.r)))))
	if #v24 == 0 or v24[#v24] < v32 then
		table.insert(v24, v32)
	end
	local v33 = v_u_6(0, (v_u_7(p20, p20)))
	if #v24 == 0 or v24[#v24] < v33 then
		table.insert(v24, v33)
	end
	return v24
end
function v_u_1.bars(p35, p36, p37, p38) -- name: bars
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_1, (copy) v_u_34, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_3
	local v39 = v_u_6(1, (v_u_2((type(p35) ~= "number" or (p35 ~= p35 or (p35 <= -1000000000 or p35 >= 1000000000))) and 1 or p35)))
	local v40 = v_u_6(1, (v_u_2((type(p36) ~= "number" or (p36 ~= p36 or (p36 <= -1000000000 or p36 >= 1000000000))) and 1 or p36)))
	local v41 = v_u_1.circle(v39, v40, p37)
	local v42 = v_u_34(v40, v41, v_u_1.ROWS)
	local v43 = {}
	local v44 = 0
	for v45 = 1, #v42 - 1 do
		local v46 = v42[v45]
		local v47 = v42[v45 + 1]
		local v48 = 0
		if v41.cy < v46 then
			v48 = v46 - v41.cy
		elseif v47 < v41.cy then
			v48 = v41.cy - v47
		end
		local v49 = v_u_6(v_u_5(v46 - v41.cy), (v_u_5(v47 - v41.cy)))
		local v50, v51, v52
		if v48 < v41.r then
			local v53 = v_u_4(v41.r * v41.r - v48 * v48)
			v50 = v_u_6(0, (v_u_7(v39, (v_u_2(v41.cx - v53)))))
			v51 = v_u_6(0, (v_u_7(v39, (v_u_3(v41.cx + v53)))))
			v52 = v39 - v51
			local v54 = v_u_6(v41.cx - v50, v51 - v41.cx)
			v44 = v_u_6(v44, v_u_4(v54 * v54 + v49 * v49) - v41.r)
		else
			v51 = v39
			v50 = v51
			local v55 = v51
			v51 = v50
			v55 = v50
			v52 = 0
		end
		local v56 = {
			["y"] = v46,
			["h"] = v47 - v46,
			["lw"] = v50,
			["rx"] = v51,
			["rw"] = v52
		}
		table.insert(v43, v56)
	end
	local v57 = v_u_6(0.5, (type(p38) ~= "number" or (p38 ~= p38 or (p38 <= -1000000000 or p38 >= 1000000000))) and 1 or p38)
	return {
		["circle"] = v41,
		["rows"] = v43,
		["ring"] = {
			["thickness"] = v_u_6(v_u_6(2, (v_u_2(v41.short * v_u_1.RING_MIN_FRACTION * v57 + 0.5))), v_u_3(v44) + 1),
			["soft"] = v_u_6(2, (v_u_2(v41.r * v_u_1.SOFT_FRACTION + 0.5))),
			["softTransparency"] = v_u_1.SOFT_TRANSPARENCY
		}
	}
end
function v_u_1.imageLayout(p58, p59, p60) -- name: imageLayout
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_1
	local v61 = v_u_6(1, (v_u_2((type(p58) ~= "number" or (p58 ~= p58 or (p58 <= -1000000000 or p58 >= 1000000000))) and 1 or p58)))
	local v62 = v_u_6(1, (v_u_2((type(p59) ~= "number" or (p59 ~= p59 or (p59 <= -1000000000 or p59 >= 1000000000))) and 1 or p59)))
	local v63 = v_u_1.circle(v61, v62, p60)
	local v64 = v_u_6(2, (v_u_2(v63.d + 0.5)))
	local v65 = v_u_2((v61 - v64) / 2)
	local v66 = v_u_2((v62 - v64) / 2)
	local v67 = {}
	if v65 > 0 and v62 > 0 then
		table.insert(v67, {
			["x"] = 0,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["w"] = v65,
			["h"] = v62
		})
	end
	local v68 = v65 + v64
	local v69 = v61 - (v65 + v64)
	if v69 > 0 and v62 > 0 then
		table.insert(v67, {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v68,
			["w"] = v69,
			["h"] = v62
		})
	end
	if v64 > 0 and v66 > 0 then
		table.insert(v67, {
			["x"] = nil,
			["y"] = 0,
			["w"] = nil,
			["h"] = nil,
			["x"] = v65,
			["w"] = v64,
			["h"] = v66
		})
	end
	local v70 = v66 + v64
	local v71 = v62 - (v66 + v64)
	if v64 > 0 and v71 > 0 then
		table.insert(v67, {
			["x"] = v65,
			["y"] = v70,
			["w"] = v64,
			["h"] = v71
		})
	end
	return {
		["circle"] = v63,
		["square"] = {
			["x"] = v65,
			["y"] = v66,
			["size"] = v64
		},
		["fill"] = v67
	}
end
local function v_u_80(p72, p73, p74, p75, p76, p77) -- name: segment
	local v78 = (p74 + p75) / 2
	local v79 = p75 - p74
	return p72 == 0 and {
		["x"] = 0,
		["y"] = nil,
		["w"] = nil,
		["h"] = nil,
		["rot"] = 0,
		["tag"] = nil,
		["y"] = p73 * v78,
		["w"] = p76,
		["h"] = v79,
		["tag"] = p77
	} or {
		["x"] = nil,
		["y"] = 0,
		["w"] = nil,
		["h"] = nil,
		["rot"] = 0,
		["tag"] = nil,
		["x"] = p72 * v78,
		["w"] = v79,
		["h"] = p76,
		["tag"] = p77
	}
end
function v_u_1.reticle(p81, p82, p83) -- name: reticle
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_80
	local v84 = v_u_6(8, (type(p82) ~= "number" or (p82 ~= p82 or (p82 <= -1000000000 or p82 >= 1000000000))) and 100 or p82)
	local v85 = v_u_6(0.5, (type(p83) ~= "number" or (p83 ~= p83 or (p83 <= -1000000000 or p83 >= 1000000000))) and 1 or p83)
	local v86 = {}
	if p81 ~= "duplex" then
		if p81 == "chevron" then
			local v87 = v_u_6(v_u_2(v85 * 2 + 0.5), (v_u_2(v84 * 0.011 + 0.5)))
			local v88 = v84 * 0.17
			local v89 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["rot"] = -45,
				["tag"] = "arm_right",
				["x"] = v88 * 0.7071067811865476 / 2,
				["y"] = v88 * 0.7071067811865476 / 2,
				["w"] = v87,
				["h"] = v88
			}
			table.insert(v86, v89)
			local v90 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["rot"] = 45,
				["tag"] = "arm_left",
				["x"] = v88 * -0.7071067811865476 / 2,
				["y"] = v88 * 0.7071067811865476 / 2,
				["w"] = v87,
				["h"] = v88
			}
			table.insert(v86, v90)
			local v91 = v88 * 0.7071067811865476 + v84 * 0.02
			local v92 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["rot"] = 0,
				["tag"] = "mark_left",
				["x"] = -(v84 * 0.06 + v84 * 0.03),
				["y"] = v91,
				["w"] = v84 * 0.06,
				["h"] = v_u_6(1, (v_u_2(v85 + 0.5)))
			}
			table.insert(v86, v92)
			local v93 = {
				["x"] = nil,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["rot"] = 0,
				["tag"] = "mark_right",
				["x"] = v84 * 0.06 + v84 * 0.03,
				["y"] = v91,
				["w"] = v84 * 0.06,
				["h"] = v_u_6(1, (v_u_2(v85 + 0.5)))
			}
			table.insert(v86, v93)
			local v94 = v91 + v84 * 0.03
			local v95 = v84 * 0.35
			local v96 = v_u_6(1, (v_u_2(v85 + 0.5)))
			local v97 = (v94 + v95) / 2
			local v98 = v95 - v94
			local v99 = {
				["x"] = 0,
				["y"] = nil,
				["w"] = nil,
				["h"] = nil,
				["rot"] = 0,
				["tag"] = "stem",
				["y"] = v97 * 1,
				["w"] = v96,
				["h"] = v98
			}
			table.insert(v86, v99)
		end
		return v86
	end
	local v100 = v_u_6(v_u_2(v85 * 2 + 0.5), (v_u_2(v84 * 0.009 + 0.5)))
	local v101 = v_u_6(1, (v_u_2(v85 + 0.5)))
	local v102 = v84 * 0.035
	local v103 = v84 * 0.3
	local v104 = v84 * 0.3
	local v105 = v84 * 0.93
	for _, v106 in {
		{ 0, -1, "up" },
		{ 0, 1, "down" },
		{ -1, 0, "left" },
		{ 1, 0, "right" }
	} do
		local v107 = v106[1]
		local v108 = v106[2]
		local v109 = v106[3]
		local v110 = v_u_80(v107, v108, v102, v103, v101, "thin_" .. v109)
		table.insert(v86, v110)
		local v111 = v_u_80(v107, v108, v104, v105, v100, "post_" .. v109)
		table.insert(v86, v111)
	end
	return v86
end
function v_u_1.corners(p112) -- name: corners
	local v113 = p112.rot
	local v114 = math.rad(v113)
	local v115 = math.cos(v114)
	local v116 = math.sin(v114)
	local v117 = {}
	for _, v118 in { -1, 1 } do
		for _, v119 in { -1, 1 } do
			local v120 = v118 * p112.w / 2
			local v121 = v119 * p112.h / 2
			local v122 = { p112.x + v120 * v115 - v121 * v116, p112.y + v120 * v116 + v121 * v115 }
			table.insert(v117, v122)
		end
	end
	return v117
end
function v_u_1.fov(p123, p124) -- name: fov
	local v125 = (type(p123) ~= "number" or (p123 ~= p123 or (p123 <= -1000000000 or p123 >= 1000000000))) and 70 or p123
	if v125 <= 0 or v125 >= 180 then
		return v125
	end
	local v126 = (type(p124) ~= "number" or (p124 ~= p124 or (p124 <= -1000000000 or p124 >= 1000000000))) and 1 or p124
	local v127 = v126 <= 0 and 1 or v126
	local v128 = math.rad(v125) / 2
	local v129 = math.tan(v128) / v127
	local v130 = math.atan(v129) * 2
	return math.deg(v130)
end
function v_u_1.wants(p131, p132, p133) -- name: wants
	-- upvalues: (copy) v_u_1
	if p131 == true and (type(p132) == "number" and p132 == p132) then
		if p133 == true then
			return v_u_1.EXIT <= p132
		else
			return v_u_1.ENTER <= p132
		end
	else
		return false
	end
end
function v_u_1.alphaStep(p134, p135, p136) -- name: alphaStep
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_1
	local v137 = v_u_6(0, (v_u_7(1, (type(p134) ~= "number" or (p134 ~= p134 or (p134 <= -1000000000 or p134 >= 1000000000))) and 0 or p134)))
	local v138 = v_u_6(0, (type(p136) ~= "number" or (p136 ~= p136 or (p136 <= -1000000000 or p136 >= 1000000000))) and 0 or p136) / v_u_1.FADE
	if p135 then
		return v_u_7(1, v137 + v138)
	else
		return v_u_6(0, v137 - v138)
	end
end
function v_u_1.blendOut(p139, p140) -- name: blendOut
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v141 = v_u_6(0, (v_u_7(1, (type(p139) ~= "number" or (p139 ~= p139 or (p139 <= -1000000000 or p139 >= 1000000000))) and 0 or p139)))
	local v142 = v_u_6(0, (v_u_7(1, (type(p140) ~= "number" or (p140 ~= p140 or (p140 <= -1000000000 or p140 >= 1000000000))) and 0 or p140)))
	return v141 + (1 - v141) * v142
end
function v_u_1.cameraReady(p143, p144, p145, p146) -- name: cameraReady
	-- upvalues: (copy) v_u_1
	if p144 == "fp" then
		if p143 == "tp" then
			return ((type(p145) ~= "number" or (p145 ~= p145 or (p145 <= -1000000000 or p145 >= 1000000000))) and 0 or p145) >= v_u_1.TP_READY
		else
			return ((type(p146) ~= "number" or (p146 ~= p146 or (p146 <= -1000000000 or p146 >= 1000000000))) and 0 or p146) <= 0.05
		end
	else
		return false
	end
end
function v_u_1.sway(p147, p148) -- name: sway
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_1
	local v149 = v_u_6(0, (v_u_7(1, (type(p148) ~= "number" or (p148 ~= p148 or (p148 <= -1000000000 or p148 >= 1000000000))) and 0 or p148)))
	local v150 = (type(p147) ~= "number" or (p147 ~= p147 or (p147 <= -1000000000 or p147 >= 1000000000))) and 0 or p147
	local v151 = v_u_1.SWAY_DEG * v149
	local v152 = 1.1938052083641213 * v150
	local v153 = math.sin(v152) * 0.7
	local v154 = 3.330088212805181 * v150 + 1.3
	local v155 = v151 * (v153 + math.sin(v154) * 0.3)
	local v156 = 1.6964600329384885 * v150 + 0.9
	local v157 = math.sin(v156) * 0.7
	local v158 = 4.461061568097506 * v150
	return v155, v151 * (v157 + math.sin(v158) * 0.3)
end
function v_u_1.transparencyOf(p159) -- name: transparencyOf
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	return 1 - v_u_6(0, (v_u_7(1, (type(p159) ~= "number" or (p159 ~= p159 or (p159 <= -1000000000 or p159 >= 1000000000))) and 0 or p159)))
end
return v_u_1