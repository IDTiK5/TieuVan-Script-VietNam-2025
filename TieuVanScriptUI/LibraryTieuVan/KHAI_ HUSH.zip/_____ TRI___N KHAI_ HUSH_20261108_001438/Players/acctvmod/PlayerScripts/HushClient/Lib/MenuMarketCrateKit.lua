-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketCrateKit

local v_u_13 = {
	["REFUSAL"] = {
		["CRATE_BUY"] = true,
		["CRATE_TRADE"] = true,
		["CRATE_PAID"] = true,
		["CRATE_SCANNED"] = true,
		["OFF_CRATES"] = true,
		["POLICY_WAIT"] = true,
		["POLICY_FAIL"] = true
	},
	["TEXT"] = {
		["noOdds"] = "The chances of this item could not be shown."
	},
	["odds"] = function(p_u_1, p2) -- name: odds
		-- upvalues: (copy) v_u_13
		local v3, v4 = pcall(function()
			-- upvalues: (copy) p_u_1
			return p_u_1.mc.cctx.lib.MenuCratesOdds
		end)
		local v5 = false
		if v3 and v4 ~= nil then
			local v6 = v4.open
			if type(v6) == "function" and (type(p2) == "string" and p2 ~= "") then
				local v7 = v4.open
				local v8 = p_u_1.mc
				local v9
				v5, v9 = pcall(v7, v8, { p2 })
				if v5 then
					v5 = v9 ~= nil
				end
			end
		end
		if not v5 then
			v_u_13.explain(p_u_1, v_u_13.TEXT.noOdds)
		end
		return v5
	end,
	["explain"] = function(p10, p11) -- name: explain
		if type(p11) == "string" and p11 ~= "" then
			local v12 = p10.ui.toast
			pcall(v12, p11, "warn")
		end
	end
}
local function v_u_20(p_u_14, p15, p_u_16, p17, p18) -- name: oddsButton
	-- upvalues: (copy) v_u_13
	local v19 = p18 or {}
	return p_u_14.h.button(p15, p17, "secondary", function()
		-- upvalues: (ref) v_u_13, (copy) p_u_14, (copy) p_u_16
		v_u_13.odds(p_u_14, p_u_16)
	end, {
		["name"] = "Odds",
		["height"] = 44,
		["width"] = nil,
		["order"] = nil,
		["anchor"] = nil,
		["position"] = nil,
		["maxTextWidth"] = 90,
		["width"] = v19.width or 112,
		["order"] = v19.order,
		["anchor"] = v19.anchor,
		["position"] = v19.position
	})
end
function v_u_13.block(p21, p22, p23, p24) -- name: block
	-- upvalues: (copy) v_u_20
	local v25 = p21.Data
	local v26 = p21.ui
	local v27 = p21.C
	local v28 = v25.crateBlock(p23)
	if v28 == nil then
		return nil
	end
	local v29 = p24 or {}
	local v30 = v26.new("Frame", {
		["Name"] = "CrateBlock",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = v29.order or 0
	}, p22)
	v26.layout(v30, "v", 6)
	v30:SetAttribute("CrateId", p23)
	local v31 = 0
	local v32 = v29.strip
	if type(v32) == "string" and v29.strip ~= "" then
		local v33 = v26.label
		local v34 = {
			["parent"] = nil,
			["name"] = "Strip",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v30,
			["text"] = v29.strip,
			["color"] = v27.accent
		}
		v31 = v31 + 1
		v34.order = v31
		v33(v34)
	end
	if v29.tight ~= true then
		local v35 = v28.sealed
		if type(v35) == "string" then
			local v36 = v26.label
			local v37 = {
				["parent"] = nil,
				["name"] = "Sealed",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v30,
				["text"] = v28.sealed,
				["color"] = v27.text2
			}
			v31 = v31 + 1
			v37.order = v31
			v36(v37)
		end
	end
	local v38 = v26.label
	local v39 = {
		["parent"] = nil,
		["name"] = "Chances",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = nil,
		["parent"] = v30,
		["text"] = ("%s %s"):format(v28.chancesLabel, v28.chanceLine or ""),
		["color"] = v27.text
	}
	v31 = v31 + 1
	v39.order = v31
	local v40 = v38(v39)
	local v41 = v28.tallyLine
	local v42
	if type(v41) == "string" and v28.tallyLine ~= "" then
		local v43 = v26.label
		local v44 = {
			["parent"] = nil,
			["name"] = "Tally",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = v30,
			["text"] = v28.tallyLine,
			["color"] = v27.accent
		}
		v31 = v31 + 1
		v44.order = v31
		v42 = v43(v44)
	else
		v42 = nil
	end
	local v45 = v_u_20
	local v46 = v28.odds.text
	local v47 = {}
	v31 = v31 + 1
	v47.order = v31
	local v48, v49 = v45(p21, v30, p23, v46, v47)
	v30:SetAttribute("Odds", true)
	return {
		["frame"] = v30,
		["odds"] = v48,
		["oddsApi"] = v49,
		["chances"] = v40,
		["tally"] = v42,
		["block"] = v28
	}
end
function v_u_13.rowExtra(p50, p51, p52, p53) -- name: rowExtra
	-- upvalues: (copy) v_u_20
	local v54 = p50.Data
	local v55 = p50.ui
	local v56 = p50.C
	local v57 = v54.crateBlock(p52)
	if v57 == nil then
		return nil
	end
	local v58 = v54.crateCard
	local v59
	if type(v58) == "function" then
		v59 = v54.crateCard(p50.state, p52, nil, nil, {
			["rules"] = p50.rules
		})
	else
		v59 = nil
	end
	local v60
	if v59 == nil then
		v60 = v57.sealed
	else
		v60 = v59.openLine
	end
	return {
		["label"] = v55.label({
			["parent"] = nil,
			["name"] = "OpenLine",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["valign"] = "top",
			["fit"] = true,
			["track"] = false,
			["parent"] = p51,
			["text"] = v60 or "",
			["color"] = v56.text2,
			["position"] = UDim2.fromOffset(12, p53.top + 4),
			["size"] = UDim2.new(1, -142, 0, 40)
		}),
		["odds"] = v_u_20(p50, p51, p52, v57.odds.text, {
			["anchor"] = nil,
			["position"] = nil,
			["width"] = 112,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.new(1, -10, 0, p53.top)
		})
	}
end
return v_u_13