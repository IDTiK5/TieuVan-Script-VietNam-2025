-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HUDVitals

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
return {
	["new"] = function(p_u_2) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_3 = p_u_2.UI
		local v_u_4 = p_u_2.Theme
		local v_u_5 = v_u_4.color
		local v6 = {}
		local v_u_7 = nil
		local v_u_8 = p_u_2.cctx.shared.HudWhy
		local v_u_9 = v_u_3.new("Frame", {
			["Name"] = "Vitals",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 40, 1, -40),
			["Size"] = UDim2.fromOffset(288, 84)
		}, p_u_2.root)
		local v_u_10 = v_u_3.new("Frame", {
			["Name"] = "Status",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 24)
		}, v_u_9)
		local v_u_11 = v_u_3.layout(v_u_10, "h", 8)
		local function v23(p12, p13, p14, p15) -- name: makeChip
			-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_10
			local v16 = v_u_3.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Visible"] = false,
				["Name"] = "Chip_" .. p12,
				["BackgroundColor3"] = v_u_5.bg,
				["Size"] = UDim2.fromOffset(24, 24),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["LayoutOrder"] = p14
			}, v_u_10)
			v_u_3.stroke(v16, p13, 1, 0.5)
			v_u_3.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = p13,
				["Size"] = UDim2.new(0, 2, 1, 0)
			}, v16)
			local v17 = v_u_3.new("Frame", {
				["Name"] = "Inner",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = UDim2.fromOffset(0, 24),
				["AutomaticSize"] = Enum.AutomaticSize.X
			}, v16)
			v_u_3.pad(v17, {
				10,
				8,
				0,
				0
			})
			v_u_3.layout(v17, "h", 6)
			local v18 = v_u_3.icon(p12, {
				["parent"] = nil,
				["size"] = 12,
				["color"] = nil,
				["parent"] = v17,
				["color"] = p13
			})
			v18.LayoutOrder = 1
			local v19 = v_u_3.label({
				["parent"] = nil,
				["text"] = "",
				["style"] = "caps",
				["textSize"] = 12,
				["color"] = nil,
				["autoX"] = true,
				["size"] = nil,
				["order"] = 2,
				["parent"] = v17,
				["color"] = p13,
				["size"] = UDim2.fromOffset(0, 24)
			})
			v19.Visible = false
			v19.TextTruncate = Enum.TextTruncate.None
			local v20
			if p15 then
				local v21 = v_u_3.new("Frame", {
					["Name"] = "Pips",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 3,
					["Size"] = UDim2.fromOffset(18, 24)
				}, v17)
				v20 = {}
				for v22 = 1, 3 do
					v20[v22] = v_u_3.new("Frame", {
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = p13,
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, (v22 - 1) * 7, 0.5, 0),
						["Size"] = UDim2.fromOffset(4, 10)
					}, v21)
				end
			else
				v20 = nil
			end
			return {
				["frame"] = nil,
				["label"] = nil,
				["icon"] = nil,
				["pips"] = nil,
				["on"] = false,
				["frame"] = v16,
				["label"] = v19,
				["icon"] = v18,
				["pips"] = v20
			}
		end
		local v_u_24 = v23("bleeding", v_u_5.danger, 1, true)
		local v_u_25 = v23("fracture", v_u_5.accent, 2, false)
		local v_u_26 = v23("infection", v_u_5.infection, 3, false)
		local v_u_27 = v23("stamina", v_u_5.info or v_u_5.success, 4, false)
		v_u_24.label.Visible = true
		v_u_3.setText(v_u_24.label, "Bleeding")
		v_u_25.label.Visible = true
		v_u_3.setText(v_u_25.label, v_u_8.fractureChip(false))
		local v_u_28 = v_u_3.new("Frame", {
			["Name"] = "HpRow",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, 40),
			["Size"] = UDim2.new(1, 0, 0, 32)
		}, v_u_9)
		v_u_3.icon("health", {
			["parent"] = nil,
			["size"] = 16,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v_u_28,
			["color"] = v_u_5.text2,
			["position"] = UDim2.new(0, 0, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5)
		})
		local v_u_29 = v_u_3.label({
			["parent"] = nil,
			["text"] = "100",
			["style"] = "monoL",
			["textSize"] = 30,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_28,
			["position"] = UDim2.fromOffset(22, 0),
			["size"] = UDim2.fromOffset(58, 32)
		})
		local v_u_30 = v_u_3.progress({
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["value"] = 1,
			["color"] = nil,
			["ghost"] = true,
			["ghostColor"] = nil,
			["bgColor"] = nil,
			["bgTransparency"] = 0.1,
			["segments"] = 10,
			["parent"] = v_u_28,
			["size"] = UDim2.new(1, -84, 0, 6),
			["position"] = UDim2.new(0, 84, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5),
			["color"] = v_u_5.text,
			["ghostColor"] = v_u_5.danger,
			["bgColor"] = v_u_5.line
		})
		local v_u_31 = v_u_3.new("Frame", {
			["Name"] = "StaminaRow",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, 76),
			["Size"] = UDim2.new(1, 0, 0, 8)
		}, v_u_9)
		local v_u_32 = v_u_3.icon("stamina", {
			["parent"] = nil,
			["size"] = 12,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["parent"] = v_u_31,
			["color"] = v_u_5.muted,
			["position"] = UDim2.new(0, 2, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5)
		})
		local v_u_33 = v_u_3.progress({
			["parent"] = nil,
			["size"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["value"] = 1,
			["color"] = nil,
			["bgColor"] = nil,
			["bgTransparency"] = 0.2,
			["parent"] = v_u_31,
			["size"] = UDim2.new(1, -84, 0, 2),
			["position"] = UDim2.new(0, 84, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5),
			["color"] = v_u_5.text2,
			["bgColor"] = v_u_5.line
		})
		local v_u_34 = -1
		local v_u_35 = -1
		local v_u_36 = 0
		local v_u_37 = false
		local v_u_38 = 0
		local v_u_39 = 0
		local function v_u_45(p40, p41, p42) -- name: putText
			-- upvalues: (copy) v_u_3
			local v_u_43 = p40.label
			local v44 = v_u_43.Text
			if p42 then
				v_u_3.setText(v_u_43, p41)
			else
				v_u_43.Text = p41
			end
			if v_u_43.Text ~= v44 and (v_u_43.Text ~= "" and (#v44 ~= #v_u_43.Text or not p40.frame.Visible)) then
				task.defer(function()
					-- upvalues: (copy) v_u_43
					if v_u_43.Parent and v_u_43.AutomaticSize == Enum.AutomaticSize.X then
						v_u_43.AutomaticSize = Enum.AutomaticSize.None
						v_u_43.AutomaticSize = Enum.AutomaticSize.X
					end
				end)
			end
		end
		function v6.setCharacter(p46) -- name: setCharacter
			-- upvalues: (ref) v_u_7, (ref) v_u_34, (ref) v_u_35, (ref) v_u_38, (ref) v_u_39
			v_u_7 = p46
			v_u_34 = -1
			v_u_35 = -1
			v_u_38 = 0
			v_u_39 = 0
		end
		function v6.layout(p47) -- name: layout
			-- upvalues: (copy) p_u_2, (ref) v_u_37, (copy) v_u_11, (copy) v_u_4, (copy) v_u_24, (copy) v_u_25, (copy) v_u_45, (copy) v_u_8, (copy) v_u_27, (copy) v_u_9, (copy) v_u_28, (copy) v_u_31, (copy) v_u_10
			local v48
			if p47 and p_u_2.touchFrame then
				v48 = p_u_2.touchFrame()
			else
				v48 = nil
			end
			v_u_37 = v48 ~= nil
			local v49 = v_u_11
			local v50 = v_u_37
			if v50 then
				v50 = v_u_4.isPhone()
			end
			v49.Wraps = v50
			v_u_24.label.Visible = not v_u_37
			v_u_25.label.Visible = true
			v_u_45(v_u_25, v_u_8.fractureChip(v_u_37), true)
			v_u_27.label.Visible = true
			if v48 then
				v_u_9.AnchorPoint = Vector2.new(0, 0)
				v_u_9.Position = UDim2.fromOffset(v48.left, v48.top)
				local v51 = v_u_9
				local v52 = UDim2.fromOffset
				local v53 = v48.vitalsW
				v51.Size = v52(math.min(288, v53), 76)
				v_u_28.Position = UDim2.fromOffset(0, 0)
				v_u_31.Position = UDim2.fromOffset(0, 36)
				v_u_10.Position = UDim2.fromOffset(0, 52)
			else
				v_u_9.AnchorPoint = Vector2.new(0, 1)
				v_u_9.Position = UDim2.new(0, 40, 1, -40)
				v_u_9.Size = UDim2.fromOffset(288, 84)
				v_u_10.Position = UDim2.fromOffset(0, 0)
				v_u_28.Position = UDim2.fromOffset(0, 40)
				v_u_31.Position = UDim2.fromOffset(0, 76)
			end
		end
		function v6.update(p54) -- name: update
			-- upvalues: (ref) v_u_36, (ref) v_u_7, (copy) v_u_9, (ref) v_u_34, (copy) v_u_30, (copy) v_u_29, (copy) v_u_5, (ref) v_u_35, (copy) v_u_33, (copy) v_u_3, (copy) v_u_32, (copy) v_u_24, (copy) v_u_25, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (copy) p_u_2, (copy) v_u_26, (ref) v_u_1, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39, (copy) v_u_27
			v_u_36 = v_u_36 + p54
			local v55 = v_u_7
			if v55 and v55.Parent then
				v_u_9.Visible = v55:GetAttribute("Dead") ~= true
				local v56 = v55:GetAttribute("MaxHp")
				local v57 = type(v56) ~= "number" and 100 or v56
				local v58 = math.max(1, v57)
				local v59 = v55:GetAttribute("Hp")
				if type(v59) ~= "number" then
					v59 = v58
				end
				local v60 = math.clamp(v59, 0, v58)
				if v60 ~= v_u_34 then
					local v61 = v60 / v58
					v_u_30.set(v61, v_u_34 < 0)
					local v62 = v_u_29
					local v63 = math.ceil(v60)
					v62.Text = tostring(v63)
					local v64
					if v61 <= 0.25 then
						v64 = v_u_5.danger
					elseif v61 <= 0.5 then
						v64 = v_u_5.accent
					else
						v64 = v_u_5.text
					end
					v_u_30.setColor(v64)
					v_u_29.TextColor3 = v64
					v_u_34 = v60
				end
				local v65 = v55:GetAttribute("Stamina")
				local v66 = type(v65) ~= "number" and 100 or v65
				local v67 = math.clamp(v66, 0, 100)
				local v68 = v67 - v_u_35
				if math.abs(v68) > 0.4 then
					v_u_33.set(v67 / 100, true)
					local v69 = v67 < 25
					local v70 = v_u_33.setColor
					local v71
					if v69 then
						v71 = v_u_5.accent
					else
						v71 = v_u_5.text2
					end
					v70(v71)
					local v72 = v_u_3.setIconColor
					local v73 = v_u_32
					local v74
					if v69 then
						v74 = v_u_5.accent
					else
						v74 = v_u_5.muted
					end
					v72(v73, v74)
					v_u_35 = v67
				end
				local v75 = v55:GetAttribute("Bleeding")
				local v76 = type(v75) ~= "number" and 0 or v75
				local v77 = math.floor(v76)
				local v78 = math.clamp(v77, 0, 3)
				local v79 = v_u_24
				local v80 = v78 > 0
				if v79.on ~= v80 then
					v79.on = v80
					v79.frame.Visible = v80
					if v80 then
						v79.frame.BackgroundTransparency = 0
						v_u_3.tween(v79.frame, {
							["BackgroundTransparency"] = 0.2
						}, 0.6)
					end
				end
				if v78 > 0 and v_u_24.pips then
					for v81, v82 in v_u_24.pips do
						v82.BackgroundTransparency = v81 <= v78 and 0 or 0.75
					end
					local v83 = v_u_36 * (v78 * 2 + 3)
					local v84 = math.sin(v83) * 0.5 + 0.5
					v_u_3.setIconColor(v_u_24.icon, v_u_5.danger:Lerp(v_u_5.text, v84 * 0.35))
				end
				local v85 = v55:GetAttribute("Fracture") == true
				if v85 and not v_u_25.on then
					local v86 = v_u_3.toast
					local v87 = v_u_8.fractureToastTitle
					local v88 = v_u_8.fractureToastText
					pcall(v86, v87, "warn", v88)
				end
				local v89 = v_u_25
				if v89.on ~= v85 then
					v89.on = v85
					v89.frame.Visible = v85
					if v85 then
						v89.frame.BackgroundTransparency = 0
						v_u_3.tween(v89.frame, {
							["BackgroundTransparency"] = 0.2
						}, 0.6)
					end
				end
				local v90 = v_u_11.Wraps
				if v90 then
					if v_u_10.AbsoluteSize.X > 0 then
						v90 = v_u_11.AbsoluteContentSize.Y > 30
					else
						v90 = false
					end
				end
				if p_u_2.vitalsWrapped ~= v90 then
					p_u_2.vitalsWrapped = v90
				end
				local v91 = v55:GetAttribute("Infected") == true
				local v92 = v_u_26
				if v92.on ~= v91 then
					v92.on = v91
					v92.frame.Visible = v91
					if v91 then
						v92.frame.BackgroundTransparency = 0
						v_u_3.tween(v92.frame, {
							["BackgroundTransparency"] = 0.2
						}, 0.6)
					end
				end
				if v91 then
					local v93 = v55:GetAttribute("InfectionEndsAt")
					local v94 = type(v93) ~= "number" and 0 or v93
					local v95 = v94 - v_u_1.now()
					local v96 = math.max(0, v95)
					local v97
					if v_u_37 then
						v97 = v94 <= 0 and "" or v_u_8.infectionChip(v96)
					else
						v97 = v94 <= 0 and "INFECTED" or "INFECTED  " .. v_u_8.infectionUntil(v96)
					end
					v_u_26.label.Visible = v97 ~= ""
					if v_u_26.label.Text ~= v97 then
						local v98 = v_u_26
						local v_u_99 = v98.label
						local v100 = v_u_99.Text
						v_u_99.Text = v97
						if v_u_99.Text ~= v100 and (v_u_99.Text ~= "" and (#v100 ~= #v_u_99.Text or not v98.frame.Visible)) then
							task.defer(function()
								-- upvalues: (copy) v_u_99
								if v_u_99.Parent and v_u_99.AutomaticSize == Enum.AutomaticSize.X then
									v_u_99.AutomaticSize = Enum.AutomaticSize.None
									v_u_99.AutomaticSize = Enum.AutomaticSize.X
								end
							end)
						end
					end
					if v_u_38 > 0 and (v94 > 0 and v94 < v_u_38 - 1) then
						v_u_39 = 1.2
					end
					v_u_38 = v94
					local v101 = v_u_36 * (v96 < 60 and 7 or (v96 < 120 and 4 or 2))
					local v102 = math.sin(v101) * 0.5 + 0.5
					local v103 = v_u_5.bg:Lerp(Color3.fromHex("#1E2A12"), v102)
					if v_u_39 > 0 then
						local v104 = v_u_39 - p54
						v_u_39 = math.max(0, v104)
						local v105 = v_u_39 / 1.2
						v_u_26.frame.BackgroundColor3 = v103:Lerp(v_u_5.dangerDeep or v_u_5.danger, v105)
						v_u_26.label.TextColor3 = v_u_5.infection:Lerp(v_u_5.danger, v105)
						v_u_3.setIconColor(v_u_26.icon, v_u_5.infection:Lerp(v_u_5.danger, v105))
					else
						v_u_26.frame.BackgroundColor3 = v103
						if v_u_26.label.TextColor3 ~= v_u_5.infection then
							v_u_26.label.TextColor3 = v_u_5.infection
							v_u_3.setIconColor(v_u_26.icon, v_u_5.infection)
						end
					end
				else
					v_u_38 = 0
					v_u_39 = 0
				end
				local v106 = v55:GetAttribute("StaminaBuffUntil")
				local v107 = type(v106) ~= "number" and 0 or v106
				local v108 = v107 <= 0 and 0 or v107 - v_u_1.now()
				local v109 = v_u_27
				local v110 = v108 > 0
				if v109.on ~= v110 then
					v109.on = v110
					v109.frame.Visible = v110
					if v110 then
						v109.frame.BackgroundTransparency = 0
						v_u_3.tween(v109.frame, {
							["BackgroundTransparency"] = 0.2
						}, 0.6)
					end
				end
				if v108 > 0 then
					v_u_27.label.Visible = true
					local v111
					if v_u_37 then
						v111 = v_u_3.clock(v108)
					else
						v111 = "ENERGY  " .. v_u_3.clock(v108)
					end
					if v_u_27.label.Text ~= v111 then
						local v112 = v_u_27
						local v_u_113 = v112.label
						local v114 = v_u_113.Text
						v_u_113.Text = v111
						if v_u_113.Text ~= v114 and (v_u_113.Text ~= "" and (#v114 ~= #v_u_113.Text or not v112.frame.Visible)) then
							task.defer(function()
								-- upvalues: (copy) v_u_113
								if v_u_113.Parent and v_u_113.AutomaticSize == Enum.AutomaticSize.X then
									v_u_113.AutomaticSize = Enum.AutomaticSize.None
									v_u_113.AutomaticSize = Enum.AutomaticSize.X
								end
							end)
						end
					end
					if v_u_35 >= 25 then
						v_u_33.setColor(v_u_5.info or v_u_5.success)
						return
					end
				elseif v_u_27.label.Text ~= "" then
					v_u_27.label.Text = ""
					v_u_35 = -1
				end
			else
				v_u_9.Visible = false
			end
		end
		function v6.destroy() -- name: destroy
			-- upvalues: (copy) v_u_9
			v_u_9:Destroy()
		end
		return v6
	end
}