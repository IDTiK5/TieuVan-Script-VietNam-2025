-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlayBrief

local v_u_216 = {
	["TILE_SECTION"] = {
		["difficulty"] = "difficulty",
		["time"] = "time",
		["kit"] = "kit",
		["raid"] = "raid",
		["mode"] = "mode"
	},
	["attach"] = function(p_u_1, p_u_2, p_u_3, p4) -- name: attach
		-- upvalues: (copy) v_u_216
		local v_u_5 = p_u_1.ui
		local v_u_6 = p_u_1.theme
		local v_u_7 = v_u_6.color
		local v_u_8 = p_u_1.cctx.lib
		local v_u_9 = v_u_8.PlayBriefLayout
		local v_u_10 = v_u_8.PlayBriefModel
		local v11 = v_u_8.MenuPlayBriefCard
		if type(v_u_9) ~= "table" or (type(v_u_10) ~= "table" or (type(v11) ~= "table" or (p_u_3.sheet == nil or (type(p4) ~= "table" or p4.col == nil)))) then
			return nil
		end
		local v12 = p4.col
		local v_u_13 = p4.dockH or 104
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = {}
		local v_u_17 = nil
		local v_u_18 = ""
		local v_u_19 = nil
		local v_u_20 = false
		local v_u_21 = false
		local v_u_22 = v_u_5.new("Frame", {
			["Name"] = "BriefView",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(0, 0),
			["Size"] = UDim2.new(1, 0, 1, -(v_u_13 + 12))
		}, v12)
		v_u_14.frame = v_u_22
		local v_u_23 = {
			["tutorial"] = v_u_5.new("Frame", {
				["Name"] = "Tutorial",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = true,
				["Visible"] = false
			}, v_u_22),
			["pass"] = v_u_5.new("Frame", {
				["Name"] = "Pass",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = true,
				["Visible"] = false
			}, v_u_22),
			["task"] = v_u_5.new("Frame", {
				["Name"] = "Task",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = false,
				["Visible"] = false
			}, v_u_22),
			["needed"] = v_u_5.new("Frame", {
				["Name"] = "Needed",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = false,
				["Visible"] = false
			}, v_u_22)
		}
		function v_u_14.host(p24) -- name: host
			-- upvalues: (copy) v_u_23
			return v_u_23[p24]
		end
		local v30 = {
			["onMap"] = function(p25) -- name: onMap
				-- upvalues: (copy) p_u_3
				if p_u_3.sheet then
					p_u_3.sheet.open("map", p25)
				end
			end,
			["onTile"] = function(p26, p27) -- name: onTile
				-- upvalues: (ref) v_u_216, (copy) p_u_3
				local v28 = v_u_216.TILE_SECTION[p26] or "map"
				if p_u_3.sheet then
					p_u_3.sheet.open(v28, p27)
				end
			end,
			["onSetup"] = function(p29) -- name: onSetup
				-- upvalues: (copy) p_u_3
				if p_u_3.sheet then
					p_u_3.sheet.open("map", p29)
				end
			end
		}
		local v_u_31 = v11.new(p_u_1, v_u_22, v30)
		v_u_14.card = v_u_31
		local v_u_32 = v_u_5.new("TextButton", {
			["Name"] = "BriefTask",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Selectable"] = true,
			["ClipsDescendants"] = true,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.raised,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_23.task)
		v_u_32.SelectionImageObject = v_u_5.selectionImage()
		local v_u_33 = v_u_5.stroke(v_u_32, v_u_7.line)
		local v_u_34 = v_u_5.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Active"] = false,
			["BackgroundColor3"] = v_u_7.accent,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v_u_32)
		local v_u_35 = v_u_5.icon("task", {
			["parent"] = nil,
			["name"] = "Icon",
			["size"] = 20,
			["thickness"] = 2,
			["color"] = nil,
			["zindex"] = 2,
			["parent"] = v_u_32,
			["color"] = v_u_7.accent
		})
		local v_u_36 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Kicker",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["track"] = false,
			["size"] = nil,
			["fit"] = true,
			["zindex"] = 2,
			["parent"] = v_u_32,
			["color"] = v_u_7.accent,
			["size"] = UDim2.fromOffset(100, 14)
		})
		local v_u_37 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "",
			["style"] = "h3",
			["textSize"] = 18,
			["size"] = nil,
			["fit"] = true,
			["zindex"] = 2,
			["track"] = false,
			["parent"] = v_u_32,
			["size"] = UDim2.fromOffset(100, 22)
		})
		local v_u_38 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Left",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["zindex"] = 2,
			["track"] = false,
			["parent"] = v_u_32,
			["color"] = v_u_7.text2,
			["size"] = UDim2.fromOffset(100, 18)
		})
		local v_u_39 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Right",
			["text"] = "",
			["style"] = "monoS",
			["color"] = nil,
			["align"] = "right",
			["size"] = nil,
			["zindex"] = 2,
			["track"] = false,
			["parent"] = v_u_32,
			["color"] = v_u_7.text2,
			["size"] = UDim2.fromOffset(80, 18)
		})
		local v_u_40 = v_u_5.progress({
			["parent"] = nil,
			["name"] = "Bar",
			["value"] = 0,
			["color"] = nil,
			["size"] = nil,
			["zindex"] = 2,
			["parent"] = v_u_32,
			["color"] = v_u_7.accent,
			["size"] = UDim2.fromOffset(100, 4)
		})
		local v_u_41 = v_u_5.icon("chevronRight", {
			["parent"] = nil,
			["name"] = "Chevron",
			["size"] = 14,
			["thickness"] = 2,
			["color"] = nil,
			["zindex"] = 2,
			["parent"] = v_u_32,
			["color"] = v_u_7.text2
		})
		local v42 = v_u_32.MouseEnter
		table.insert(v_u_16, v42:Connect(function()
			-- upvalues: (copy) v_u_33, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
			v_u_33.Color = v_u_7.lineStrong
			v_u_5.sound(v_u_6.sounds.hover)
		end))
		local v43 = v_u_32.MouseLeave
		table.insert(v_u_16, v43:Connect(function()
			-- upvalues: (copy) v_u_33, (copy) v_u_7
			v_u_33.Color = v_u_7.line
		end))
		local v44 = v_u_32.Activated
		table.insert(v_u_16, v44:Connect(function()
			-- upvalues: (copy) p_u_3
			if p_u_3.taskPress then
				p_u_3.taskPress()
			end
		end))
		local v_u_45 = {
			["kicker"] = "",
			["title"] = "",
			["left"] = "",
			["right"] = ""
		}
		local function v_u_51() -- name: taskView
			-- upvalues: (copy) p_u_3, (copy) p_u_1, (copy) v_u_10
			local v46 = p_u_3.taskParts
			if type(v46) ~= "table" then
				return nil
			end
			local v47 = p_u_1.cache and (p_u_1.cache.tasks and p_u_1.cache.tasks.data) or nil
			local v48 = {
				["kicker"] = v46.kicker.Text,
				["title"] = v46.title.Text,
				["left"] = not v46.bar.left and "" or v46.bar.left.Text,
				["right"] = not v46.bar.right and "" or v46.bar.right.Text,
				["frac"] = v46.bar.bar.get()
			}
			if not v46.bar.frame.Visible then
				v48.left = ""
				v48.right = ""
				v48.frac = 0
			end
			if type(v47) == "table" then
				local v49 = v47.order
				if type(v49) ~= "table" or #v47.order == 0 then
					v48.empty = true
				end
			else
				v48.failed = p_u_3.tasksAsked == true
				v48.loading = not v48.failed
			end
			v48.color = v46.edge.BackgroundColor3
			local v50 = v_u_10.taskView(v48)
			v50.color = v48.color
			return v50
		end
		local function v_u_97(p52, p53, p54) -- name: paintTask
			-- upvalues: (copy) v_u_51, (copy) v_u_34, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_38, (copy) v_u_40, (copy) v_u_39, (copy) v_u_37, (copy) v_u_6, (copy) v_u_41, (copy) v_u_45, (copy) v_u_32
			local v55 = v_u_51()
			if v55 ~= nil then
				local v56 = p52 == "card"
				local v57 = v_u_34
				local v58
				if v55.failed or (v55.loading or v55.empty) then
					v58 = v_u_7.muted
				else
					v58 = v55.color
				end
				v57.BackgroundColor3 = v58
				local v59 = v_u_36
				local v60
				if v55.failed or (v55.loading or v55.empty) then
					v60 = v_u_7.muted
				else
					v60 = v55.color
				end
				v59.TextColor3 = v60
				v_u_35.Visible = not v56
				v_u_36.Visible = v56
				v_u_38.Visible = v56
				local v61 = v_u_40.frame
				local v62 = v56 and not (v55.failed or (v55.loading or v55.empty))
				if v62 then
					v62 = v55.left ~= nil
				end
				v61.Visible = v62
				v_u_39.Visible = true
				if v56 then
					local v63 = v_u_36
					local v64 = v_u_36
					local v65 = UDim2.fromOffset(16, 8)
					local v66 = UDim2.fromOffset(p53 - 32 - 24, 14)
					v63.Position = v65
					v64.Size = v66
					local v67 = v_u_37
					local v68 = v_u_37
					local v69 = UDim2.fromOffset(16, 24)
					local v70 = UDim2.fromOffset(p53 - 32 - 24, 22)
					v67.Position = v69
					v68.Size = v70
					local v71 = v_u_38
					local v72 = v_u_38
					local v73 = UDim2.fromOffset(16, 48)
					local v74 = UDim2.fromOffset((p53 - 32 - 24) * 0.72, 18)
					v71.Position = v73
					v72.Size = v74
					local v75 = v_u_39
					local v76 = v_u_39
					local v77 = UDim2.fromOffset((p53 - 32 - 24) * 0.72 + 16, 48)
					local v78 = UDim2.fromOffset((p53 - 32 - 24) * 0.28, 18)
					v75.Position = v77
					v76.Size = v78
					local v79 = v_u_40.frame
					local v80 = v_u_40.frame
					local v81 = UDim2.fromOffset(16, p54 - 12)
					local v82 = UDim2.fromOffset(p53 - 32 - 24, 4)
					v79.Position = v81
					v80.Size = v82
					v_u_37.TextSize = v_u_6.phoneText(18, "text")
					v_u_41.Position = UDim2.fromOffset(p53 - 14 - 12, (p54 - 14) // 2)
					if p54 < 90 then
						local v83 = v_u_38
						local v84 = v_u_39
						local v85 = UDim2.fromOffset(16, 44)
						local v86 = UDim2.fromOffset((p53 - 32 - 24) * 0.72 + 16, 44)
						v83.Position = v85
						v84.Position = v86
					end
				else
					v_u_35.Position = UDim2.fromOffset(14, (p54 - 20) // 2)
					local v87 = v_u_37
					local v88 = v_u_37
					local v89 = UDim2.fromOffset(44, (p54 - 22) // 2)
					local v90 = UDim2.fromOffset(p53 - 44 - 100 - 28, 22)
					v87.Position = v89
					v88.Size = v90
					v_u_37.TextSize = v_u_6.phoneText(16, "text")
					local v91 = v_u_39
					local v92 = v_u_39
					local v93 = UDim2.fromOffset(p53 - 28 - 90, (p54 - 18) // 2)
					local v94 = UDim2.fromOffset(90, 18)
					v91.Position = v93
					v92.Size = v94
					v_u_41.Position = UDim2.fromOffset(p53 - 14 - 10, (p54 - 14) // 2)
				end
				local v95 = v55.title
				local v96
				if v56 then
					v96 = v55.right
				else
					v96 = v55.right == "" and "" or v55.right
				end
				if v_u_45.title ~= v95 then
					v_u_45.title = v95
					v_u_37.Text = v95
				end
				if v_u_45.kicker ~= v55.kicker then
					v_u_45.kicker = v55.kicker
					v_u_36.Text = v55.kicker
				end
				if v_u_45.left ~= v55.left then
					v_u_45.left = v55.left
					v_u_38.Text = v55.left
				end
				if v_u_45.right ~= v96 then
					v_u_45.right = v96
					v_u_39.Text = v96
				end
				v_u_40.set(v55.frac, true)
				v_u_40.setColor(v55.color or v_u_7.accent)
				v_u_32:SetAttribute("Title", v95)
			end
		end
		local v_u_98 = v_u_5.new("TextButton", {
			["Name"] = "BriefNeeded",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["Selectable"] = true,
			["ClipsDescendants"] = true,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7.raised,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_23.needed)
		v_u_98.SelectionImageObject = v_u_5.selectionImage()
		local v_u_99 = v_u_5.stroke(v_u_98, v_u_7.line)
		local v_u_100 = v_u_5.label({
			["parent"] = nil,
			["name"] = "Head",
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["zindex"] = 2,
			["parent"] = v_u_98,
			["text"] = v_u_10.T.needed,
			["color"] = v_u_7.text2,
			["size"] = UDim2.fromOffset(200, 14)
		})
		local v_u_101 = v_u_5.new("Frame", {
			["Name"] = "Cells",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Active"] = false,
			["Size"] = UDim2.fromOffset(100, 52)
		}, v_u_98)
		local v102 = v_u_98.MouseEnter
		table.insert(v_u_16, v102:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_7, (copy) v_u_5, (copy) v_u_6
			v_u_99.Color = v_u_7.lineStrong
			v_u_5.sound(v_u_6.sounds.hover)
		end))
		local v103 = v_u_98.MouseLeave
		table.insert(v_u_16, v103:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_7
			v_u_99.Color = v_u_7.line
		end))
		local v104 = v_u_98.Activated
		table.insert(v_u_16, v104:Connect(function()
			-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_98, (copy) p_u_3
			v_u_5.sound(v_u_6.sounds.click)
			local v105 = v_u_98
			if p_u_3.sheet then
				p_u_3.sheet.open("kit", v105)
			end
		end))
		local v_u_106 = ""
		local function v_u_110() -- name: wish
			-- upvalues: (copy) p_u_1
			local function v107()
				-- upvalues: (ref) p_u_1
				return p_u_1.kit.wishList()
			end
			local v108, v109 = pcall(v107)
			return (not v108 or type(v109) ~= "table") and {} or v109
		end
		local function v_u_134(p111, p112, p113) -- name: paintNeeded
			-- upvalues: (copy) v_u_110, (copy) v_u_100, (copy) v_u_10, (copy) v_u_101, (ref) v_u_106, (copy) p_u_1, (copy) v_u_5, (copy) v_u_7
			local v114 = v_u_110()
			local v115 = (p111 - 32 + 6) / (p113 + 6)
			local v116 = math.floor(v115)
			local v117 = math.max(1, v116)
			local v118 = table.concat(v114, ",") .. "|" .. p113 .. "|" .. v117
			v_u_100.Text = string.upper(v_u_10.T.needed) .. "  " .. #v114
			local v119 = v_u_100
			local v120 = v_u_100
			local v121 = UDim2.fromOffset(16, 6)
			local v122 = UDim2.fromOffset(p111 - 32, 14)
			v119.Position = v121
			v120.Size = v122
			local v123 = v_u_101
			local v124 = v_u_101
			local v125 = UDim2.fromOffset(16, p112 - 6 - p113)
			local v126 = UDim2.fromOffset(p111 - 32, p113)
			v123.Position = v125
			v124.Size = v126
			if v118 ~= v_u_106 then
				v_u_106 = v118
				for _, v127 in v_u_101:GetChildren() do
					v127:Destroy()
				end
				local v128 = #v114
				local v129 = math.min(v128, 6, v117)
				local v130 = #v114 - v129
				if v130 > 0 and v129 == v117 then
					local v131 = v129 - 1
					v129 = math.max(1, v131)
					v130 = #v114 - v129
				end
				for v132 = 1, v129 do
					p_u_1.kit.itemCell(v_u_101, v114[v132], {
						["size"] = p113,
						["order"] = v132
					}).Position = UDim2.fromOffset((v132 - 1) * (p113 + 6), 0)
				end
				if v130 > 0 then
					local v133 = v_u_5.new("Frame", {
						["Name"] = "More",
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["Position"] = nil,
						["BackgroundColor3"] = v_u_7.raised2,
						["Size"] = UDim2.fromOffset(p113, p113),
						["Position"] = UDim2.fromOffset(v129 * (p113 + 6), 0)
					}, v_u_101)
					v_u_5.stroke(v133, v_u_7.line)
					v_u_5.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "h3",
						["align"] = "center",
						["size"] = nil,
						["track"] = false,
						["fit"] = true,
						["parent"] = v133,
						["text"] = "+" .. v130,
						["size"] = UDim2.fromScale(1, 1)
					})
				end
			end
		end
		function v_u_14.solution() -- name: solution
			-- upvalues: (ref) v_u_19
			return v_u_19
		end
		function v_u_14.relayout() -- name: relayout
			-- upvalues: (ref) v_u_15, (copy) p_u_3, (copy) p_u_1, (copy) v_u_110, (copy) v_u_14, (copy) v_u_9, (ref) v_u_21, (ref) v_u_19, (copy) v_u_31, (copy) v_u_23, (copy) v_u_97, (copy) v_u_134, (copy) v_u_22, (ref) v_u_18
			if v_u_15 then
				local v135 = p_u_3.sheet.metrics()
				local v136 = p_u_1.tutorialCard
				local v137 = p_u_3.passWidget
				local v138 = {}
				local v139 = p_u_1.tutorialCard
				local v140
				if v139 == nil or v139.frame == nil then
					v140 = false
				else
					v140 = v139.frame.Visible == true
				end
				v138.tutorial = v140
				local v141
				if v137 == nil or v137.available == nil then
					v141 = false
				else
					v141 = v137.available() == true
				end
				v138.pass = v141
				local v142 = p_u_3.taskParts
				v138.task = type(v142) == "table"
				v138.needed = #v_u_110()
				if v136 and v136.onChange == nil then
					function v136.onChange()
						-- upvalues: (ref) v_u_15, (ref) v_u_14
						if v_u_15 then
							v_u_14.relayout()
						end
					end
				end
				if v136 and v136.heightFor then
					v138.tutorialH = {
						["card"] = v136.heightFor("card", v135.colW),
						["row"] = v136.heightFor("row", v135.colW)
					}
				end
				local v143 = v_u_9.solve({
					["colW"] = v135.colW,
					["colH"] = v135.colH,
					["dockH"] = v135.dockH,
					["touch"] = v135.touch,
					["has"] = v138,
					["mode"] = v_u_21 and true or nil
				})
				v_u_19 = v143
				local v144 = {
					v135.colW,
					v135.colH,
					v135.dockH,
					v135.touch,
					v_u_21 and "mode" or ""
				}
				for _, v145 in v143.blocks do
					local v146 = v145.id .. v145.density .. v145.y .. "," .. v145.h
					table.insert(v144, v146)
				end
				local v147 = table.concat(v144, "|")
				local v148 = {}
				for _, v149 in v143.blocks do
					v148[v149.id] = true
					if v149.id == "brief" then
						v_u_31.frame.Position = UDim2.fromOffset(v149.x, v149.y)
						v_u_31.apply(v149.density, v143.brief, v149.w, v149.h)
					else
						local v150 = v_u_23[v149.id]
						local v151 = UDim2.fromOffset(v149.x, v149.y)
						local v152 = UDim2.fromOffset(v149.w, v149.h)
						v150.Position = v151
						v150.Size = v152
						v150.Visible = true
					end
					if v149.id == "tutorial" and (v136 and v136.setForm) then
						v136.setForm(v149.density)
					elseif v149.id == "task" then
						v_u_97(v149.density, v149.w, v149.h)
					else
						if v149.id ~= "needed" then
							continue
						end
						v_u_134(v149.w, v149.h, v135.class == "wide" and 52 or 44)
					end
				end
				for v153, v154 in v_u_23 do
					if v148[v153] then
						continue
					end
					v154.Visible = false
				end
				if not v148.brief then
					v_u_31.frame.Visible = false
				end
				if v137 and v137.setVisible then
					v137.setVisible(v148.pass == true)
				end
				v_u_22:SetAttribute("Layout", ("%s %s"):format(v143.class, table.concat(v143.steps, ",")))
				if v147 ~= v_u_18 then
					v_u_18 = v147
					v_u_14.links()
				end
			end
		end
		local function v_u_162() -- name: controlMap
			-- upvalues: (copy) p_u_1, (copy) p_u_3, (copy) v_u_31, (copy) v_u_32, (copy) v_u_98, (ref) v_u_17
			local v155 = p_u_1.tutorialCard
			local v156 = {}
			local v157
			if v155 and v155.frame then
				v157 = v155.frame:FindFirstChild("Main", true)
			else
				v157 = nil
			end
			v156.tut_play = v157
			local v158
			if v155 and v155.frame then
				v158 = v155.frame:FindFirstChild("Side", true)
			else
				v158 = nil
			end
			v156.tut_no = v158
			local v159
			if p_u_3.passWidget then
				v159 = p_u_3.passWidget.frame
			else
				v159 = nil
			end
			v156.pass = v159
			v156.map = v_u_31.mapBtn
			v156.difficulty = v_u_31.tile("difficulty")
			v156.time = v_u_31.tile("time")
			v156.kit = v_u_31.tile("kit")
			v156.raid = v_u_31.tile("raid")
			v156.mode = v_u_31.tile("mode")
			local v160
			if v_u_31.setupBtn.Visible then
				v160 = v_u_31.setupBtn
			else
				v160 = nil
			end
			v156.setup = v160
			v156.task = v_u_32
			v156.needed = v_u_98
			local v161
			if v_u_17 then
				v161 = v_u_17.deployBtn
			else
				v161 = nil
			end
			v156.deploy = v161
			return v156
		end
		v_u_14.controls = v_u_162
		function v_u_14.links() -- name: links
			-- upvalues: (ref) v_u_15, (ref) v_u_19, (copy) v_u_162, (copy) v_u_9, (ref) v_u_17, (copy) p_u_3
			if v_u_15 and v_u_19 ~= nil then
				local v163 = v_u_162()
				local v164 = v_u_9.padLinks(v_u_19, v_u_17 ~= nil)
				for v165, v166 in v163 do
					if v166 == nil then
						continue
					end
					local v167 = v164[v165]
					if v167 == nil then
						v166.NextSelectionUp = nil
						v166.NextSelectionDown = nil
						v166.NextSelectionLeft = nil
						v166.NextSelectionRight = nil
					else
						local v168
						if v165 == "deploy" and p_u_3.sheet.isOpen() then
							v168 = v166.NextSelectionUp
						else
							local v169 = v167.up
							if v169 then
								v168 = v163[v169]
							else
								v168 = nil
							end
						end
						v166.NextSelectionUp = v168
						local v170 = v167.down
						local v171
						if v170 then
							v171 = v163[v170]
						else
							v171 = nil
						end
						v166.NextSelectionDown = v171
						local v172 = v167.left
						local v173
						if v172 then
							v173 = v163[v172]
						else
							v173 = nil
						end
						v166.NextSelectionLeft = v173
						local v174 = v167.right
						local v175
						if v174 then
							v175 = v163[v174]
						else
							v175 = nil
						end
						v166.NextSelectionRight = v175
					end
				end
				if p_u_3.paidChip ~= nil then
					local v176 = p_u_3.paidChip.link
					pcall(v176)
				end
			end
		end
		function v_u_14.tile(p177) -- name: tile
			-- upvalues: (copy) v_u_31
			return v_u_31.tile(p177)
		end
		function v_u_14.first() -- name: first
			-- upvalues: (copy) v_u_31
			return v_u_31.mapBtn
		end
		function v_u_14.padFirst() -- name: padFirst
			-- upvalues: (copy) p_u_1, (copy) v_u_162, (ref) v_u_17
			local v178 = p_u_1.tutorialCard
			local v179
			if v178 and v178.state then
				v179 = v178.state()
			else
				v179 = nil
			end
			local v180 = p_u_1.tutorialCard
			local v181
			if v180 == nil or v180.frame == nil then
				v181 = false
			else
				v181 = v180.frame.Visible == true
			end
			if v181 and (v179 == "offer" or (v179 == "retry" or v179 == "again")) then
				local v182 = v_u_162().tut_play
				if v182 and (v182:IsA("GuiObject") and v182.Visible) then
					return v182
				end
			end
			if v_u_17 then
				return v_u_17.deployBtn
			else
				return nil
			end
		end
		function v_u_14.setHidden(p183) -- name: setHidden
			-- upvalues: (ref) v_u_20, (copy) v_u_22
			v_u_20 = p183
			v_u_22.Visible = not p183
		end
		function v_u_14.setDockH(p184) -- name: setDockH
			-- upvalues: (ref) v_u_13, (copy) v_u_22, (copy) v_u_14
			v_u_13 = p184
			v_u_22.Size = UDim2.new(1, 0, 1, -(p184 + 12))
			v_u_14.relayout()
		end
		function v_u_14.paint() -- name: paint
			-- upvalues: (ref) v_u_15, (copy) p_u_3, (copy) v_u_10, (ref) v_u_21, (copy) v_u_31, (copy) v_u_14, (copy) v_u_22, (copy) p_u_2
			if v_u_15 then
				local v185 = p_u_3.briefState
				if type(v185) == "function" then
					local v186 = p_u_3.briefState
					local v187, v188 = pcall(v186)
					if v187 and type(v188) == "table" then
						local v189 = v_u_10.view(v188, v188.words)
						v_u_21 = v189.showMode == true
						v_u_31.paint(v189, v188)
						v_u_14.relayout()
						v_u_31.paint(v189, v188)
						if p_u_3.sheet then
							p_u_3.sheet.paint()
						end
						v_u_22:SetAttribute("Summary", v189.summary)
						p_u_2:SetAttribute("MenuPlayBrief", v189.summary .. " | " .. v189.values)
					end
				end
			end
		end
		function v_u_14.dock(p190) -- name: dock
			-- upvalues: (ref) v_u_17, (copy) v_u_6, (copy) p_u_3, (copy) v_u_14
			v_u_17 = p190
			local v191 = v_u_6.isPhone
			local v192
			if type(v191) == "function" then
				v192 = v_u_6.isPhone() == true
			else
				v192 = false
			end
			p_u_3.briefPhone = v192
			if v192 and (p190.summary and p190.status) then
				p190.summary.Visible = false
				p190.status.Position = UDim2.fromOffset(0, 0)
				if p190.planLine then
					p190.planLine.Position = UDim2.fromOffset(0, 20)
				end
			end
			v_u_14.links()
		end
		function v_u_14.tip() -- name: tip
			-- upvalues: (copy) v_u_8, (copy) p_u_1, (copy) p_u_3, (copy) p_u_2, (copy) v_u_31
			local function v199()
				-- upvalues: (ref) v_u_8, (ref) p_u_1, (ref) p_u_3, (ref) p_u_2, (ref) v_u_31
				local v193 = v_u_8.MenuTipOnce
				local v194 = p_u_1.tutorialCard
				local v195
				if v194 and v194.state then
					v195 = v194.state()
				else
					v195 = nil
				end
				if v195 == "offer" or v195 == "retry" then
					return
				else
					local v196 = p_u_3.introHandle
					if v196 == nil or v196.alive and not v196.alive() then
						local v198 = {
							["host"] = p_u_2,
							["target"] = function() -- name: target
								-- upvalues: (ref) v_u_31
								if v_u_31.setupBtn.Visible then
									return v_u_31.setupBtn
								else
									return v_u_31.mapBtn
								end
							end,
							["active"] = function() -- name: active
								-- upvalues: (ref) p_u_3, (ref) p_u_2
								local v197
								if p_u_3.shown == true and p_u_2.Parent ~= nil then
									v197 = not p_u_3.sheet.isOpen()
								else
									v197 = false
								end
								return v197
							end
						}
						v193.show(p_u_1, "raidsetup", v198)
					end
				end
			end
			return pcall(v199)
		end
		function v_u_14.finish() -- name: finish
			-- upvalues: (copy) p_u_3, (copy) v_u_14
			local v_u_200 = p_u_3.paint
			local v_u_201 = p_u_3.show
			local v_u_202 = p_u_3.hide
			local v_u_203 = p_u_3.refresh
			local v_u_204 = p_u_3.destroy
			function p_u_3.paint(...) -- name: paint
				-- upvalues: (copy) v_u_200, (ref) v_u_14
				if v_u_200 then
					v_u_200(...)
				end
				local v205 = v_u_14.paint
				pcall(v205)
			end
			function p_u_3.show(...) -- name: show
				-- upvalues: (copy) v_u_201, (ref) v_u_14
				if v_u_201 then
					v_u_201(...)
				end
				local v206 = v_u_14.paint
				pcall(v206)
				local v207 = v_u_14.tip
				pcall(v207)
			end
			function p_u_3.hide(...) -- name: hide
				-- upvalues: (ref) p_u_3, (copy) v_u_202
				if p_u_3.sheet then
					local v208 = p_u_3.sheet.close
					pcall(v208, "hide")
				end
				if v_u_202 then
					v_u_202(...)
				end
			end
			function p_u_3.refresh(...) -- name: refresh
				-- upvalues: (copy) v_u_203, (ref) v_u_14
				if v_u_203 then
					v_u_203(...)
				end
				local v209 = v_u_14.paint
				pcall(v209)
			end
			function p_u_3.destroy(...) -- name: destroy
				-- upvalues: (ref) v_u_14, (copy) v_u_204
				local v210 = v_u_14.destroy
				pcall(v210)
				if v_u_204 then
					v_u_204(...)
				end
			end
			local v211 = v_u_14.paint
			pcall(v211)
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15, (copy) v_u_16, (copy) v_u_31, (copy) p_u_3, (copy) v_u_22
			v_u_15 = false
			for _, v_u_212 in v_u_16 do
				pcall(function()
					-- upvalues: (copy) v_u_212
					v_u_212:Disconnect()
				end)
			end
			table.clear(v_u_16)
			local v213 = v_u_31.destroy
			pcall(v213)
			if p_u_3.sheet then
				local v214 = p_u_3.sheet.destroy
				pcall(v214, false)
			end
			local function v215()
				-- upvalues: (ref) v_u_22
				v_u_22:Destroy()
			end
			pcall(v215)
		end
		return v_u_14
	end
}
return v_u_216