-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuTempProfile

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("Players")
local v_u_6 = {}
local v_u_7 = {
	["handle"] = nil,
	["lastRejoin"] = nil
}
local function v_u_15(p_u_8, p_u_9) -- name: sharedMod
	-- upvalues: (copy) v_u_1
	local v10, v11 = pcall(function()
		-- upvalues: (copy) p_u_8, (copy) p_u_9
		return p_u_8.cctx.shared[p_u_9]
	end)
	if v10 and type(v11) == "table" then
		return v11
	else
		local function v12()
			-- upvalues: (ref) v_u_1, (copy) p_u_9
			return require((v_u_1:WaitForChild("Hush", 5):WaitForChild("Shared", 5):WaitForChild(p_u_9, 5)))
		end
		local v13, v14 = pcall(v12)
		if v13 then
			return v14
		else
			return nil
		end
	end
end
function v_u_6.isOpen() -- name: isOpen
	-- upvalues: (copy) v_u_7
	local v16
	if v_u_7.handle == nil then
		v16 = false
	else
		v16 = v_u_7.handle.alive()
	end
	return v16
end
function v_u_6.show(p_u_17, p18) -- name: show
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_15, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v_u_19 = p18 or {}
	if v_u_6.isOpen() then
		return v_u_7.handle
	end
	local v_u_20 = v_u_15(p_u_17, "StashWipeRules")
	local v_u_21 = "MenuPvpveIntro"
	local v22, v23 = pcall(function()
		-- upvalues: (copy) p_u_17, (copy) v_u_21
		return p_u_17.cctx.lib[v_u_21]
	end)
	if not v22 or type(v23) ~= "table" then
		v23 = nil
	end
	local v_u_24 = "MenuWhy"
	local v25, v_u_26 = pcall(function()
		-- upvalues: (copy) p_u_17, (copy) v_u_24
		return p_u_17.cctx.lib[v_u_24]
	end)
	if not v25 or type(v_u_26) ~= "table" then
		v_u_26 = nil
	end
	local v_u_27 = "MenuTempRules"
	local v28, v_u_29 = pcall(function()
		-- upvalues: (copy) p_u_17, (copy) v_u_27
		return p_u_17.cctx.lib[v_u_27]
	end)
	if not v28 or type(v_u_29) ~= "table" then
		v_u_29 = nil
	end
	if v_u_20 ~= nil and (v23 ~= nil and (v_u_26 ~= nil and v_u_29 ~= nil)) then
		local v30 = v23.holdController
		if type(v30) == "function" then
			local v_u_31 = p_u_17.ui
			local v_u_32 = p_u_17.theme
			local v_u_33 = v_u_32.color
			local v_u_34 = v23.holdController(v_u_20)
			local v_u_35 = {}
			local v_u_36 = nil
			local v_u_37 = nil
			local v_u_38 = nil
			local v_u_39 = nil
			local v_u_40 = nil
			local v_u_41 = true
			local v_u_42 = {
				["alive"] = function() -- name: alive
					-- upvalues: (ref) v_u_41
					return v_u_41
				end,
				["controller"] = function() -- name: controller
					-- upvalues: (copy) v_u_34
					return v_u_34
				end
			}
			local function v_u_45() -- name: finish
				-- upvalues: (ref) v_u_41, (ref) v_u_35, (ref) v_u_36, (ref) v_u_7, (copy) v_u_42
				v_u_41 = false
				for _, v_u_43 in v_u_35 do
					pcall(function()
						-- upvalues: (copy) v_u_43
						v_u_43:Disconnect()
					end)
				end
				v_u_35 = {}
				local v_u_44 = v_u_36
				if v_u_44 ~= nil then
					pcall(function()
						-- upvalues: (copy) v_u_44
						v_u_44:Destroy()
					end)
					v_u_36 = nil
				end
				if v_u_7.handle == v_u_42 then
					v_u_7.handle = nil
				end
			end
			local function v_u_60() -- name: rejoin
				-- upvalues: (copy) v_u_29, (ref) v_u_7, (ref) v_u_41, (ref) v_u_40, (copy) v_u_26, (copy) v_u_19, (copy) p_u_17, (ref) v_u_5, (copy) v_u_31
				local v46 = os.clock()
				if v_u_29.rejoinReady(v_u_7.lastRejoin, v46) then
					v_u_7.lastRejoin = v46
					local function v48() -- name: idle
						-- upvalues: (ref) v_u_41, (ref) v_u_40, (ref) v_u_26
						if v_u_41 and v_u_40 ~= nil then
							local function v47()
								-- upvalues: (ref) v_u_40, (ref) v_u_26
								v_u_40.setText(v_u_26.TEMP_POP_REJOIN)
								v_u_40.setEnabled(true)
							end
							pcall(v47)
						end
					end
					if v_u_40 ~= nil then
						local function v49()
							-- upvalues: (ref) v_u_40, (ref) v_u_26
							v_u_40.setText(v_u_26.TEMP_POP_REJOINING)
							v_u_40.setEnabled(false)
						end
						pcall(v49)
					end
					local v_u_50 = v_u_19.menuPlaceId
					if v_u_50 == nil then
						local function v51()
							-- upvalues: (ref) v_u_50, (ref) p_u_17
							v_u_50 = p_u_17.cctx.config.MENU_PLACE_ID
						end
						pcall(v51)
					end
					local v_u_52 = v_u_29.rejoinTarget(v_u_50, game.PlaceId)
					local v_u_53 = v_u_19.teleport
					local function v55()
						-- upvalues: (copy) v_u_52, (copy) v_u_53, (ref) v_u_5
						if v_u_52 == nil then
							error("no place to rejoin")
						end
						local v54 = v_u_53
						if type(v54) == "function" then
							v_u_53(v_u_52, v_u_5.LocalPlayer)
						else
							game:GetService("TeleportService"):Teleport(v_u_52, v_u_5.LocalPlayer)
						end
					end
					local v56, v57 = pcall(v55)
					if v56 then
						task.delay(v_u_29.REJOIN_COOLDOWN, v48)
					else
						warn("[MenuTempProfile] rejoin failed:", v57)
						v_u_7.lastRejoin = nil
						if v_u_41 and v_u_40 ~= nil then
							local function v58()
								-- upvalues: (ref) v_u_40, (ref) v_u_26
								v_u_40.setText(v_u_26.TEMP_POP_REJOIN)
								v_u_40.setEnabled(true)
							end
							pcall(v58)
						end
						local function v59()
							-- upvalues: (ref) v_u_31, (ref) v_u_26
							v_u_31.toast(v_u_26.TEMP_POP_REJOIN_FAIL[1], "danger", v_u_26.TEMP_POP_REJOIN_FAIL[2])
						end
						pcall(v59)
					end
				else
					return
				end
			end
			local v_u_61 = 0
			local function v62()
				-- upvalues: (ref) v_u_61, (copy) v_u_31
				v_u_61 = v_u_31.modalCount()
			end
			pcall(v62)
			local v_u_63 = "#" .. v_u_33.success:ToHex()
			local v_u_64 = "#" .. v_u_33.danger:ToHex()
			local function v74()
				-- upvalues: (copy) v_u_31, (copy) v_u_26, (copy) v_u_33, (copy) v_u_63, (copy) v_u_64, (copy) v_u_32, (copy) v_u_29, (copy) v_u_20, (ref) v_u_40, (copy) v_u_60, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39
				return v_u_31.modal({
					["title"] = nil,
					["kind"] = "danger",
					["width"] = 520,
					["dismissable"] = false,
					["build"] = nil,
					["title"] = v_u_26.TEMP_POP_HEAD1,
					["build"] = function(p65) -- name: build
						-- upvalues: (ref) v_u_31, (ref) v_u_26, (ref) v_u_33, (ref) v_u_63, (ref) v_u_64, (ref) v_u_32, (ref) v_u_29, (ref) v_u_20, (ref) v_u_40, (ref) v_u_60, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39
						v_u_31.label({
							["parent"] = nil,
							["name"] = "Head2",
							["text"] = nil,
							["style"] = "h2",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["track"] = false,
							["order"] = 1,
							["parent"] = p65,
							["text"] = v_u_26.TEMP_POP_HEAD2,
							["color"] = v_u_33.danger
						})
						for v66, v67 in v_u_26.tempPopupLines(v_u_63, v_u_64) do
							v_u_31.label({
								["parent"] = nil,
								["name"] = nil,
								["text"] = nil,
								["rich"] = true,
								["style"] = "body",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = p65,
								["name"] = "Line" .. v66,
								["text"] = v67,
								["color"] = v_u_33.text,
								["order"] = 1 + v66
							})
						end
						local v_u_68 = 520
						local function v69()
							-- upvalues: (ref) v_u_68, (ref) v_u_31, (ref) v_u_32
							v_u_68 = v_u_31.modalLimits(520, v_u_32.refSize(), v_u_31.safeInsets())
						end
						pcall(v69)
						local v70 = v_u_29.layout(v_u_20, v_u_68 - 2 * v_u_32.space.l, v_u_32.uiScale(), v_u_32.isTouch(), 0)
						local v71 = v_u_31.new("Frame", {
							["Name"] = "Buttons",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = 100,
							["Size"] = UDim2.new(1, 0, 0, v70.height)
						}, p65)
						local _, v72 = v_u_31.button({
							["parent"] = nil,
							["name"] = "Rejoin",
							["text"] = nil,
							["kind"] = "primary",
							["size"] = nil,
							["onClick"] = nil,
							["parent"] = v71,
							["text"] = v_u_26.TEMP_POP_REJOIN,
							["size"] = UDim2.new(1, 0, 0, v70.rejoin.h),
							["onClick"] = v_u_60
						})
						v_u_40 = v72
						v_u_37 = v_u_31.new("TextButton", {
							["Name"] = "HoldConfirm",
							["Text"] = "",
							["AutoButtonColor"] = false,
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["Selectable"] = true,
							["BackgroundColor3"] = v_u_33.raised,
							["Position"] = UDim2.fromOffset(0, v70.btn.y),
							["Size"] = UDim2.new(1, 0, 0, v70.btn.h)
						}, v71)
						v_u_37:SetAttribute("PadDefault", true)
						v_u_31.new("UICorner", {
							["CornerRadius"] = UDim.new(0, 6)
						}, v_u_37)
						v_u_31.stroke(v_u_37, v_u_33.lineStrong)
						v_u_38 = v_u_31.new("Frame", {
							["Name"] = "Fill",
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.1,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["Active"] = false,
							["ZIndex"] = 1,
							["BackgroundColor3"] = v_u_33.accent,
							["Size"] = UDim2.fromScale(0, 1)
						}, v_u_37)
						v_u_31.new("UICorner", {
							["CornerRadius"] = UDim.new(0, 6)
						}, v_u_38)
						v_u_39 = v_u_31.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "h3",
							["color"] = nil,
							["size"] = nil,
							["align"] = "center",
							["parent"] = v_u_37,
							["text"] = string.upper(v_u_26.TEMP_POP_HOLD),
							["color"] = v_u_33.text,
							["size"] = UDim2.fromScale(1, 1)
						})
						local function v73()
							-- upvalues: (ref) v_u_39
							v_u_39.ZIndex = 3
						end
						pcall(v73)
						v_u_31.label({
							["parent"] = nil,
							["name"] = "HoldHint",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["wrap"] = true,
							["position"] = nil,
							["size"] = nil,
							["parent"] = v71,
							["text"] = v_u_20.holdHint(v_u_31.device()),
							["color"] = v_u_33.muted,
							["position"] = UDim2.fromOffset(0, v70.hint.y),
							["size"] = UDim2.new(1, 0, 0, v70.hint.h)
						})
					end
				})
			end
			local v75, v76 = pcall(v74)
			if not v75 then
				warn("[MenuTempProfile] popup failed:", v76)
				return nil
			end
			local v_u_77 = v76
			if v_u_37 == nil then
				warn("[MenuTempProfile] popup built without the hold button")
				pcall(function()
					-- upvalues: (ref) v_u_77
					v_u_77.close()
				end)
				v_u_45()
				return nil
			end
			v_u_7.handle = v_u_42
			local function v79()
				-- upvalues: (ref) v_u_77, (copy) v_u_31, (ref) v_u_61, (ref) v_u_36
				local v78 = v_u_77.frame.Parent
				v_u_36 = v_u_31.new("Frame", {
					["Name"] = "TempVeil",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Active"] = false,
					["ZIndex"] = nil,
					["BackgroundColor3"] = Color3.new(0, 0, 0),
					["Size"] = UDim2.fromScale(1, 1),
					["ZIndex"] = v_u_61 * 2 + 1
				}, v78)
			end
			pcall(v79)
			if v_u_37 ~= nil then
				local v80 = v_u_35
				local v81 = v_u_37.InputBegan
				table.insert(v80, v81:Connect(function(p82)
					-- upvalues: (copy) v_u_34
					if p82.UserInputType == Enum.UserInputType.MouseButton1 or p82.UserInputType == Enum.UserInputType.Touch then
						v_u_34.press()
					end
				end))
				local v83 = v_u_35
				local v84 = v_u_37.MouseLeave
				table.insert(v83, v84:Connect(function()
					-- upvalues: (copy) v_u_34
					v_u_34.release()
				end))
			end
			local v85 = v_u_35
			local v86 = v_u_3.InputBegan
			local function v88(p87)
				-- upvalues: (ref) v_u_37, (ref) v_u_4, (copy) v_u_34
				if p87.KeyCode == Enum.KeyCode.ButtonA and (v_u_37 ~= nil and v_u_4.SelectedObject == v_u_37) then
					v_u_34.press()
				end
			end
			table.insert(v85, v86:Connect(v88))
			local v89 = v_u_35
			local v90 = v_u_3.InputEnded
			table.insert(v89, v90:Connect(function(p91)
				-- upvalues: (copy) v_u_34
				if p91.KeyCode == Enum.KeyCode.ButtonA or (p91.UserInputType == Enum.UserInputType.MouseButton1 or p91.UserInputType == Enum.UserInputType.Touch) then
					v_u_34.release()
				end
			end))
			local v_u_92 = true
			local v93 = v_u_35
			local v94 = v_u_3.WindowFocusReleased
			local function v95()
				-- upvalues: (ref) v_u_92, (copy) v_u_34
				v_u_92 = false
				v_u_34.release()
			end
			table.insert(v93, v94:Connect(v95))
			local v96 = v_u_35
			local v97 = v_u_3.WindowFocused
			local function v98()
				-- upvalues: (ref) v_u_92
				v_u_92 = true
			end
			table.insert(v96, v97:Connect(v98))
			local v99 = v_u_35
			local v100 = v_u_2.Heartbeat
			local function v107()
				-- upvalues: (ref) v_u_41, (ref) v_u_37, (ref) v_u_92, (copy) v_u_34, (ref) v_u_38, (ref) v_u_39, (copy) v_u_26, (ref) v_u_77, (copy) v_u_45, (copy) v_u_19
				if v_u_41 then
					local v101
					if v_u_37 == nil or v_u_37.Parent == nil then
						v101 = false
					else
						v101 = v_u_92
					end
					local v102 = v_u_34.step(os.clock(), v101)
					if v_u_38 ~= nil and v_u_38.Parent then
						v_u_38.Size = UDim2.fromScale(v102, 1)
					end
					if v_u_34.done then
						v_u_34.done = false
						v_u_41 = false
						local function v103()
							-- upvalues: (ref) v_u_39, (ref) v_u_26
							v_u_39.Text = string.upper(v_u_26.TEMP_POP_DONE)
						end
						pcall(v103)
						task.delay(0.35, function()
							-- upvalues: (ref) v_u_77, (ref) v_u_45, (ref) v_u_19
							local function v104()
								-- upvalues: (ref) v_u_77
								v_u_77.close()
							end
							pcall(v104)
							v_u_45()
							local v105 = v_u_19.onDone
							if type(v105) == "function" then
								local v106 = v_u_19.onDone
								pcall(v106)
							end
						end)
					end
				end
			end
			table.insert(v99, v100:Connect(v107))
			function v_u_42.close() -- name: close
				-- upvalues: (ref) v_u_77, (copy) v_u_45
				local function v108()
					-- upvalues: (ref) v_u_77
					v_u_77.close()
				end
				pcall(v108)
				v_u_45()
			end
			return v_u_42
		end
	end
	return nil
end
return v_u_6