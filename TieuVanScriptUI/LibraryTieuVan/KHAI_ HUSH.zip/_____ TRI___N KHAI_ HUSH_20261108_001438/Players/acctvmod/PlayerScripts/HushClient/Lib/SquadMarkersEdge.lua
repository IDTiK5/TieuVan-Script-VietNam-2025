-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / SquadMarkersEdge

local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local function v_u_8(p4) -- name: escRich
	local v5 = string.gsub(p4, "&", "&amp;")
	local v6 = string.gsub(v5, "<", "&lt;")
	local v7 = string.gsub(v6, ">", "&gt;")
	return string.gsub(v7, "\"", "&quot;")
end
local v_u_9 = {}
function v_u_1.setHudRects(p10, p11) -- name: setHudRects
	-- upvalues: (ref) v_u_2, (ref) v_u_3
	if not p10 or #p10 <= 0 then
		p10 = nil
	end
	v_u_2 = p10
	v_u_3 = p11
end
function v_u_1.hudRects() -- name: hudRects
	-- upvalues: (ref) v_u_2, (ref) v_u_3
	return v_u_2, v_u_3
end
function v_u_1.safeBox(p12, p13, p14, p15, p16, p17) -- name: safeBox
	local v18 = p16 or 46
	local v19
	if p13 then
		local v20 = p13.l + 28
		v19 = math.max(v18, v20)
	else
		v19 = v18
	end
	if p13 then
		local v21 = p13.r + 28
		v18 = math.max(v18, v21)
	end
	if p13 then
		local v22 = p13.t + 8
		p14 = math.max(p14, v22)
	end
	if p13 then
		p15 = p15 + p13.b
	end
	return (p17 == true or p13 and (p13.l > 0 or (p13.t > 0 or (p13.r > 0 or p13.b > 0)))) and {
		v19,
		p14,
		p12.X - v18,
		p12.Y - p15,
		not p13 and 0 or p13.l,
		not p13 and 0 or p13.t,
		p12.X - (not p13 and 0 or p13.r),
		p12.Y - (not p13 and 0 or p13.b)
	} or {
		v19,
		p14,
		p12.X - v18,
		p12.Y - p15
	}
end
function v_u_1.footprint(p23, p24, p25) -- name: footprint
	local v26 = p25.X / 2
	local v27 = p25.Y / 2
	local v28 = p24.X
	local v29 = v26 * math.abs(v28)
	local v30 = p24.Y
	local v31 = v27 * math.abs(v30)
	local v32 = p23 - p24 * (math.max(v29, v31) + 24)
	local v33 = {}
	local v34 = p23.X - 14
	local v35 = v32.X - v26
	local v36 = math.min(v34, v35)
	local v37 = p23.Y - 14
	local v38 = v32.Y - v27
	local v39 = math.min(v37, v38)
	local v40 = p23.X + 14
	local v41 = v32.X + v26
	local v42 = math.max(v40, v41)
	local v43 = p23.Y + 14
	local v44 = v32.Y + v27
	__set_list(v33, 1, {v36, v39, v42, (math.max(v43, v44))})
	return v33
end
function v_u_1.avoidMarker(p45, p_u_46, p_u_47, p_u_48, p49, p50) -- name: avoidMarker
	-- upvalues: (copy) v_u_1
	-- block 47
	local v_u_51 = p50 or 8
	local v52 = p49[1]
	local v53 = p49[2]
	local v54 = p49[3]
	local v55 = p49[4]
	local function v60(p56) -- name: hits
		-- upvalues: (ref) v_u_1, (copy) p_u_46, (copy) p_u_47, (copy) p_u_48, (copy) v_u_51
		local v57 = v_u_1.footprint(p56, p_u_46, p_u_47)
		local v58 = {}
		for _, v59 in p_u_48 do
			if v57[3] <= v59[1] - v_u_51 or (v57[1] >= v59[3] + v_u_51 or (v57[4] <= v59[2] - v_u_51 or v57[2] >= v59[4] + v_u_51)) then
				continue
			end
			table.insert(v58, v59)
		end
		return v58
	end
	if #v60(p45) == 0 then
		return p45
	end
	local function v77(p61) -- name: cost
		-- upvalues: (ref) v_u_1, (copy) p_u_46, (copy) p_u_47, (copy) p_u_48
		local v62 = v_u_1.footprint(p61, p_u_46, p_u_47)
		local v63 = 0
		for _, v64 in p_u_48 do
			local v65 = v62[3]
			local v66 = v64[3]
			local v67 = math.min(v65, v66)
			local v68 = v62[1]
			local v69 = v64[1]
			local v70 = v67 - math.max(v68, v69)
			local v71 = v62[4]
			local v72 = v64[4]
			local v73 = math.min(v71, v72)
			local v74 = v62[2]
			local v75 = v64[2]
			local v76 = v73 - math.max(v74, v75)
			if v70 <= 0 or v76 <= 0 then
				continue
			end
			v63 = v63 + v70 * v76 * (v64[5] or 1)
		end
		return v63
	end
	local v78 = false
	for _, v79 in p_u_48 do
		if v79[5] == nil then
			continue
		end
		v78 = true
	end
	local v80 = v77(p45)
	local v81, v82, v83
	-- NumForInit
local v81, v82, v83 = 1, 3, 1
-- end NumForInit
	local v84 = p45
	local v85 = { p45 }
	-- NumForNext
v81 = v81 + v83;
if v81 <= v82
-- end NumForNext
	::l8::
	v85 = {}
	local v86 = (1 / 0)
	local v87 = nil
	for _, v88 in v85 do
		local v89 = v_u_1.footprint(v88, p_u_46, p_u_47)
		for _, v90 in v60(v88) do
			for _, v91 in {
				Vector2.new(v88.X + (v90[1] - v_u_51 - 1) - v89[3], v88.Y),
				Vector2.new(v88.X + (v90[3] + v_u_51 + 1) - v89[1], v88.Y),
				Vector2.new(v88.X, v88.Y + (v90[2] - v_u_51 - 1) - v89[4]),
				Vector2.new(v88.X, v88.Y + (v90[4] + v_u_51 + 1) - v89[2])
			} do
				local v92 = Vector2.new
				local v93 = v91.X
				local v94 = math.clamp(v93, v52, v54)
				local v95 = v91.Y
				local v96 = v92(v94, (math.clamp(v95, v53, v55)))
				local v97, v98, v99
				if #v60(v96) == 0 then
					local v100
					if p49[5] == nil then
						v100 = true
					else
						local v101 = v_u_1.footprint(v96, p_u_46, p_u_47)
						if v101[1] >= p49[5] and (v101[2] >= p49[6] and v101[3] <= p49[7]) then
							v100 = v101[4] <= p49[8]
						else
							v100 = false
						end
					end
					if v100 then
						local v102 = (v96 - p45).Magnitude
						if v102 >= v86 then
							continue
						end
						v87 = v96
						v86 = v102
					else
						if #v85 >= 16 then
							continue
						end
						if p49[5] == nil then
							v97 = true
						else
							v98 = v_u_1.footprint(v96, p_u_46, p_u_47)
							if v98[1] >= p49[5] and (v98[2] >= p49[6] and v98[3] <= p49[7]) then
								v97 = v98[4] <= p49[8]
							else
								v97 = false
							end
						end
						if not v97 then
							continue
						end
						table.insert(v85, v96)
						v99 = v77(v96)
						if v99 >= v80 then
							continue
						end
						v84 = v96
						v80 = v99
					end
				else
					if #v85 >= 16 then
						continue
					end
					if p49[5] == nil then
						v97 = true
					else
						v98 = v_u_1.footprint(v96, p_u_46, p_u_47)
						if v98[1] >= p49[5] and (v98[2] >= p49[6] and v98[3] <= p49[7]) then
							v97 = v98[4] <= p49[8]
						else
							v97 = false
						end
					end
					if not v97 then
						continue
					end
					table.insert(v85, v96)
					v99 = v77(v96)
					if v99 >= v80 then
						continue
					end
					v84 = v96
					v80 = v99
				end
			end
		end
	end
	if v87 then
		return v87
	end
	if #v85 ~= 0 then
		break
	end
	if v78 then
		return v84
	else
		return p45
	end
	::l9::
	if v78 then
		return v84
	else
		return p45
	end
	-- block 11
	goto l8
	-- block 41
	goto l9
end
function v_u_1.short(p103) -- name: short
	local v104 = " "
	local v105 = {}
	for v106 = 1, #p103 do
		local v107 = string.sub(p103, v106, v106)
		local v108 = v107:match("%u") ~= nil
		if v107:match("%w") ~= nil and (not v104:match("%w") or v108 and v104:match("%l")) then
			table.insert(v105, v107)
		end
		v104 = v107
	end
	if #v105 >= 2 then
		return string.upper(v105[1] .. v105[2])
	end
	local v109 = p103:gsub("[^%w]", "")
	return string.upper((string.sub(v109, 1, 3)))
end
function v_u_1.avoid(p110, p_u_111, p112, p_u_113) -- name: avoid
	local v114 = p112[1]
	local v115 = p112[2]
	local v116 = p112[3]
	local v117 = p112[4]
	local function v120(p118) -- name: blocked
		-- upvalues: (copy) p_u_111, (copy) p_u_113
		for _, v119 in p_u_111 do
			if p118.X <= v119[1] - p_u_113 or (p118.X >= v119[3] + p_u_113 or (p118.Y <= v119[2] - p_u_113 or p118.Y >= v119[4] + p_u_113)) then
				continue
			end
			return true
		end
		return false
	end
	if not v120(p110) then
		return p110
	end
	local v121 = (1 / 0)
	local v122 = nil
	for _, v123 in p_u_111 do
		if p110.X <= v123[1] - p_u_113 or (p110.X >= v123[3] + p_u_113 or (p110.Y <= v123[2] - p_u_113 or p110.Y >= v123[4] + p_u_113)) then
			continue
		end
		for _, v124 in {
			Vector2.new(v123[1] - p_u_113 - 1, p110.Y),
			Vector2.new(v123[3] + p_u_113 + 1, p110.Y),
			Vector2.new(p110.X, v123[2] - p_u_113 - 1),
			Vector2.new(p110.X, v123[4] + p_u_113 + 1)
		} do
			local v125 = Vector2.new
			local v126 = v124.X
			local v127 = math.clamp(v126, v114, v116)
			local v128 = v124.Y
			local v129 = v125(v127, (math.clamp(v128, v115, v117)))
			if v120(v129) then
				continue
			end
			local v130 = (v129 - p110).Magnitude
			if v130 >= v121 then
				continue
			end
			v122 = v129
			v121 = v130
		end
	end
	return v122 or p110
end
local function v_u_146(p131, p132, p133) -- name: sideOf
	local v134 = p131.X - p133[1]
	local v135 = math.abs(v134)
	local v136 = p133[3] - p131.X
	local v137 = math.abs(v136)
	local v138 = p131.Y - p133[2]
	local v139 = math.abs(v138)
	local v140 = p133[4] - p131.Y
	local v141 = math.abs(v140)
	local v142 = math.min(v135, v137, v139, v141)
	if v142 <= 8 then
		return v142 == v135 and "L" or (v142 == v137 and "R" or (v142 == v139 and "T" or "B"))
	end
	local v143 = p132.X
	local v144 = math.abs(v143)
	local v145 = p132.Y
	return math.abs(v145) <= v144 and (p132.X < 0 and "L" or "R") or (p132.Y < 0 and "T" or "B")
end
function v_u_1.stack(p147, p148, p149) -- name: stack
	-- upvalues: (copy) v_u_146
	local v150 = p149 or 6
	if #p147 >= 2 then
		local v151 = {}
		for _, v152 in p147 do
			local v153 = v_u_146(v152.pos, v152.dir, p148)
			v151[v153] = v151[v153] or {}
			local v154 = v151[v153]
			table.insert(v154, v152)
		end
		for v155, v156 in v151 do
			if #v156 < 2 then
				continue
			end
			local v_u_157 = v155 == "L" and true or v155 == "R"
			local v158
			if v_u_157 then
				v158 = p148[2]
			else
				v158 = p148[1]
			end
			local v159
			if v_u_157 then
				v159 = p148[4]
			else
				v159 = p148[3]
			end
			table.sort(v156, function(p160, p161)
				-- upvalues: (copy) v_u_157
				local v162
				if v_u_157 then
					v162 = p160.pos.Y
				else
					v162 = p160.pos.X
				end
				local v163
				if v_u_157 then
					v163 = p161.pos.Y
				else
					v163 = p161.pos.X
				end
				return v162 < v163
			end)
			local v164 = {}
			for v165, v166 in v156 do
				local v167
				if v_u_157 then
					v167 = v166.pos.Y
				else
					v167 = v166.pos.X
				end
				v164[v165] = v167
			end
			for v168 = 2, #v156 do
				local v169 = v156[v168 - 1].ext or Vector2.new(120, 34)
				local v170
				if v_u_157 then
					v170 = v169.Y
				else
					v170 = v169.X
				end
				local v171 = math.max(v170, 22) / 2
				local v172 = v156[v168].ext or Vector2.new(120, 34)
				local v173
				if v_u_157 then
					v173 = v172.Y
				else
					v173 = v172.X
				end
				local v174 = v171 + math.max(v173, 22) / 2 + v150
				if v164[v168] >= v164[v168 - 1] + v174 then
					continue
				end
				v164[v168] = v164[v168 - 1] + v174
			end
			local v175 = v164[#v156]
			local v176 = v156[#v156].ext or Vector2.new(120, 34)
			local v177
			if v_u_157 then
				v177 = v176.Y
			else
				v177 = v176.X
			end
			local v178 = v175 - (v159 - math.max(v177, 22) / 2)
			if v178 > 0 then
				for v179 = 1, #v156 do
					v164[v179] = v164[v179] - v178
				end
				local v180 = v164[1]
				local v181 = v156[1].ext or Vector2.new(120, 34)
				local v182
				if v_u_157 then
					v182 = v181.Y
				else
					v182 = v181.X
				end
				local v183 = v158 + math.max(v182, 22) / 2
				v164[1] = math.max(v180, v183)
				for v184 = 2, #v156 do
					local v185 = v156[v184 - 1].ext or Vector2.new(120, 34)
					local v186
					if v_u_157 then
						v186 = v185.Y
					else
						v186 = v185.X
					end
					local v187 = math.max(v186, 22) / 2
					local v188 = v156[v184].ext or Vector2.new(120, 34)
					local v189
					if v_u_157 then
						v189 = v188.Y
					else
						v189 = v188.X
					end
					local v190 = v187 + math.max(v189, 22) / 2 + v150
					if v164[v184] >= v164[v184 - 1] + v190 then
						continue
					end
					v164[v184] = v164[v184 - 1] + v190
				end
			end
			for v191, v192 in v156 do
				local v193
				if v_u_157 then
					v193 = Vector2.new(v192.pos.X, v164[v191])
				else
					v193 = Vector2.new(v164[v191], v192.pos.Y)
				end
				v192.pos = v193
			end
		end
	end
end
function v_u_1.new(p_u_194, p_u_195, p196) -- name: new
	-- upvalues: (ref) v_u_3, (ref) v_u_2, (copy) v_u_9, (copy) v_u_1, (copy) v_u_8
	local v_u_197 = p_u_195.color
	local v198 = {}
	local v_u_199 = p_u_194.new("Frame", {
		["Name"] = "SquadEdge",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, p196)
	local v_u_200 = p_u_194.new("Frame", {
		["Name"] = "Arrow",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(22, 22)
	}, v_u_199)
	local v_u_201 = p_u_194.icon("chevronUp", {
		["parent"] = nil,
		["size"] = 22,
		["color"] = nil,
		["thickness"] = 3,
		["parent"] = v_u_200,
		["color"] = v_u_197.info
	})
	local v_u_202 = p_u_194.new("Frame", {
		["Name"] = "Chip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = v_u_197.bg,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(0, 34),
		["AutomaticSize"] = Enum.AutomaticSize.X
	}, v_u_199)
	local v_u_203 = p_u_194.stroke(v_u_202, v_u_197.info, 1, 0.2)
	p_u_194.pad(v_u_202, {
		7,
		7,
		1,
		1
	})
	local v_u_204 = p_u_194.new("Frame", {
		["Name"] = "Tick",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_197.info,
		["Position"] = UDim2.fromOffset(-7, -1),
		["Size"] = UDim2.new(0, 2, 1, 2)
	}, v_u_202)
	local v_u_205 = p_u_194.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["autoX"] = true,
		["textSize"] = 13,
		["size"] = nil,
		["maxSize"] = nil,
		["parent"] = v_u_202,
		["color"] = v_u_197.text,
		["size"] = UDim2.fromOffset(0, 17),
		["maxSize"] = Vector2.new(110, 17)
	})
	v_u_205.Name = "Name"
	local v_u_206 = p_u_194.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["autoX"] = true,
		["textSize"] = 11,
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_202,
		["color"] = v_u_197.text2,
		["size"] = UDim2.fromOffset(0, 14),
		["position"] = UDim2.fromOffset(0, 17)
	})
	v_u_206.Name = "Dist"
	local v_u_207 = p_u_194.new("Frame", {
		["Name"] = "Bleed",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_197.danger,
		["Position"] = UDim2.fromOffset(-12, 3),
		["Size"] = UDim2.fromOffset(4, 4)
	}, v_u_202)
	p_u_194.corner(v_u_207, 2)
	local v_u_208 = nil
	local v_u_209 = ""
	local v_u_210 = p_u_194.new("UIScale", {
		["Scale"] = 1
	}, v_u_200)
	local v_u_211 = p_u_194.new("UIScale", {
		["Scale"] = 1
	}, v_u_202)
	function v198.setTouch(_, p212) -- name: setTouch
		-- upvalues: (copy) v_u_210, (copy) v_u_211
		local v213 = p212 and 1.25 or 1
		if v_u_210.Scale ~= v213 then
			v_u_210.Scale = v213
			v_u_211.Scale = v213
		end
	end
	v198.holder = v_u_199
	v198.chip = v_u_202
	v198.arrow = v_u_200
	function v198.extent(_) -- name: extent
		-- upvalues: (copy) p_u_195, (copy) v_u_202, (copy) v_u_211
		local v214 = p_u_195.uiScale
		local v215 = math.max(0.01, v214())
		local v216 = v_u_202.AbsoluteSize / v215
		if v216.X < 4 then
			return Vector2.new(110, 34) * v_u_211.Scale
		else
			return v216
		end
	end
	function v198.place(p217, p218, p219) -- name: place
		-- upvalues: (ref) v_u_3, (ref) v_u_2, (ref) v_u_9, (ref) v_u_1, (copy) v_u_200, (copy) v_u_202, (copy) p_u_195
		local v220 = v_u_3
		local v221 = p217:extent()
		local v222 = os.clock()
		if v220 then
			local v223 = {}
			if v_u_2 then
				table.move(v_u_2, 1, #v_u_2, 1, v223)
			end
			for v224, v225 in v_u_9 do
				if v224 == p217 or v222 - v225.t >= 0.008 then
					continue
				end
				local v226 = v225.fp
				table.insert(v223, v226)
			end
			if #v223 > 0 then
				p218 = v_u_1.avoidMarker(p218, p219, v221, v223, v220, 6)
			end
		end
		v_u_9[p217] = {
			["fp"] = v_u_1.footprint(p218, p219, v221),
			["t"] = v222
		}
		local v227 = v_u_200
		local v228 = UDim2.fromOffset
		local v229 = p218.X + 0.5
		local v230 = math.floor(v229)
		local v231 = p218.Y + 0.5
		v227.Position = v228(v230, (math.floor(v231)))
		local v232 = v_u_200
		local v233 = p219.X
		local v234 = -p219.Y
		local v235 = math.atan2(v233, v234)
		v232.Rotation = math.deg(v235)
		local v236 = v_u_202.AbsoluteSize
		local v237 = p_u_195.uiScale
		local v238 = v236 / math.max(0.01, v237()) / 2
		local v239 = v238.X
		local v240 = p219.X
		local v241 = v239 * math.abs(v240)
		local v242 = v238.Y
		local v243 = p219.Y
		local v244 = v242 * math.abs(v243)
		local v245 = p218 - p219 * (math.max(v241, v244) + 24)
		local v246 = v_u_202
		local v247 = UDim2.fromOffset
		local v248 = v245.X + 0.5
		local v249 = math.floor(v248)
		local v250 = v245.Y + 0.5
		v246.Position = v247(v249, (math.floor(v250)))
	end
	local v_u_251 = ""
	local v_u_252 = ""
	local v_u_253 = nil
	function v198.set(_, p254) -- name: set
		-- upvalues: (copy) v_u_197, (ref) v_u_251, (ref) v_u_253, (copy) v_u_205, (ref) v_u_8, (copy) p_u_194, (ref) v_u_252, (copy) v_u_206, (ref) v_u_209, (ref) v_u_208, (copy) v_u_202, (copy) v_u_204, (copy) v_u_203, (copy) v_u_201, (copy) v_u_207
		local v255
		if p254.downed then
			v255 = v_u_197.danger
		else
			v255 = p254.color
		end
		local v256 = p254.downed and "DOWN" or p254.label
		local v257
		if p254.downed then
			v257 = nil
		else
			local v258 = p254.clanRich
			if type(v258) == "string" and p254.clanRich ~= "" then
				v257 = p254.clanRich
			else
				v257 = nil
			end
		end
		if v256 ~= v_u_251 or v257 ~= v_u_253 then
			v_u_251 = v256
			v_u_253 = v257
			if v257 == nil then
				v_u_205.RichText = false
				v_u_205.TextStrokeTransparency = 1
				p_u_194.setText(v_u_205, string.upper(v256))
			else
				v_u_205.RichText = true
				v_u_205.Text = v257 .. v_u_8(string.upper(v256))
				local v259 = p254.clanStroke
				v_u_205.TextStrokeTransparency = type(v259) ~= "number" and 1 or p254.clanStroke
			end
		end
		if p254.meters ~= v_u_252 then
			v_u_252 = p254.meters
			v_u_206.Text = p254.meters
		end
		local v260 = p254.hint
		local v261 = type(v260) ~= "string" and "" or p254.hint
		if v261 ~= v_u_209 then
			v_u_209 = v261
			if v261 ~= "" and not v_u_208 then
				v_u_208 = p_u_194.label({
					["parent"] = nil,
					["text"] = "",
					["style"] = "monoS",
					["color"] = nil,
					["autoX"] = true,
					["textSize"] = 11,
					["size"] = nil,
					["position"] = nil,
					["parent"] = v_u_202,
					["color"] = v_u_197.text2,
					["size"] = UDim2.fromOffset(0, 14),
					["position"] = UDim2.fromOffset(0, 31)
				})
				v_u_208.Name = "Hint"
				v_u_208.TextTruncate = Enum.TextTruncate.None
			end
			if v_u_208 then
				v_u_208.Text = v261
				v_u_208.Visible = v261 ~= ""
			end
			v_u_202.Size = UDim2.fromOffset(0, v261 == "" and 34 or 48)
		end
		local v262 = v_u_205
		local v263
		if p254.downed then
			v263 = v_u_197.danger
		else
			local v264 = p254.nameColor
			if typeof(v264) == "Color3" then
				v263 = p254.nameColor
			else
				v263 = v_u_197.text
			end
		end
		v262.TextColor3 = v263
		v_u_204.BackgroundColor3 = p254.color
		v_u_203.Color = v255
		p_u_194.setIconColor(v_u_201, v255)
		local v265 = v_u_207
		local v266
		if p254.bleeding == true then
			v266 = not p254.downed
		else
			v266 = false
		end
		v265.Visible = v266
		if p254.downed then
			local v267 = p254.t * 6
			local v268 = math.sin(v267) * 0.5 + 0.5
			v_u_202.BackgroundColor3 = v_u_197.bg:Lerp(v_u_197.dangerDeep, v268)
			v_u_203.Transparency = (1 - v268) * 0.5
		else
			v_u_202.BackgroundColor3 = v_u_197.bg
			v_u_203.Transparency = 0.2
		end
	end
	function v198.setShown(p269, p270) -- name: setShown
		-- upvalues: (ref) v_u_9, (copy) v_u_199
		if not p270 then
			v_u_9[p269] = nil
		end
		if v_u_199.Visible ~= p270 then
			v_u_199.Visible = p270
		end
	end
	function v198.destroy(p271) -- name: destroy
		-- upvalues: (ref) v_u_9, (copy) v_u_199
		v_u_9[p271] = nil
		v_u_199:Destroy()
	end
	return v198
end
return v_u_1