-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioVoices

local v_u_1 = game:GetService("SoundService")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = 0
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = Vector3.new(0, 0, 0)
local v_u_13 = {}
local v_u_14 = Random.new()
local v_u_15 = {}
v_u_2.fix = true
v_u_2.lastFail = ""
v_u_2.counters = {}
function v_u_2.count(p16) -- name: count
	-- upvalues: (copy) v_u_2
	local v17 = v_u_2.counters
	v17[p16] = (v17[p16] or 0) + 1
end
v_u_2.groups = {}
v_u_2.effects = {}
local function v_u_33() -- name: buildGroups
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v18 = v_u_1
	local v19 = v18:FindFirstChild("HushMaster")
	if not (v19 and v19:IsA("SoundGroup")) then
		v19 = Instance.new("SoundGroup")
		v19.Name = "HushMaster"
		v19.Volume = 1
		v19.Parent = v18
	end
	local v20 = v_u_2.groups
	v20.Master = v19
	local v21 = v19:FindFirstChild("Music")
	if not (v21 and v21:IsA("SoundGroup")) then
		v21 = Instance.new("SoundGroup")
		v21.Name = "Music"
		v21.Volume = 1
		v21.Parent = v19
	end
	v20.Music = v21
	local v22 = v19:FindFirstChild("SFX")
	if not (v22 and v22:IsA("SoundGroup")) then
		v22 = Instance.new("SoundGroup")
		v22.Name = "SFX"
		v22.Volume = 1
		v22.Parent = v19
	end
	v20.SFX = v22
	local v23 = v19:FindFirstChild("UI")
	if not (v23 and v23:IsA("SoundGroup")) then
		v23 = Instance.new("SoundGroup")
		v23.Name = "UI"
		v23.Volume = 1
		v23.Parent = v19
	end
	v20.UI = v23
	local v24 = v19:FindFirstChild("Ambience")
	if not (v24 and v24:IsA("SoundGroup")) then
		v24 = Instance.new("SoundGroup")
		v24.Name = "Ambience"
		v24.Volume = 1
		v24.Parent = v19
	end
	v20.Ambience = v24
	local v25 = v20.Ambience
	local v26 = v25:FindFirstChild("AmbOut")
	if not (v26 and v26:IsA("SoundGroup")) then
		v26 = Instance.new("SoundGroup")
		v26.Name = "AmbOut"
		v26.Volume = 1
		v26.Parent = v25
	end
	v20.AmbOut = v26
	local v27 = v20.Ambience
	local v28 = v27:FindFirstChild("AmbIn")
	if not (v28 and v28:IsA("SoundGroup")) then
		v28 = Instance.new("SoundGroup")
		v28.Name = "AmbIn"
		v28.Volume = 0
		v28.Parent = v27
	end
	v20.AmbIn = v28
	v20.AmbWorld = v20.Ambience
	local v29 = v20.SFX:FindFirstChild("Room")
	if not v29 then
		v29 = Instance.new("ReverbSoundEffect")
		v29.Name = "Room"
		v29.DecayTime = 0.7
		v29.Density = 0.9
		v29.Diffusion = 0.85
		v29.DryLevel = 0
		v29.WetLevel = -14
		v29.Priority = 1
		v29.Enabled = false
		v29.Parent = v20.SFX
	end
	v_u_2.effects.room = v29
	local v30 = v20.SFX:FindFirstChild("Muffle")
	if not v30 then
		v30 = Instance.new("EqualizerSoundEffect")
		v30.Name = "Muffle"
		v30.HighGain = 0
		v30.MidGain = 0
		v30.LowGain = 0
		v30.Priority = 2
		v30.Enabled = false
		v30.Parent = v20.SFX
	end
	v_u_2.effects.muffle = v30
	local v31 = v20.Master:FindFirstChild("Limiter")
	if not v31 then
		v31 = Instance.new("CompressorSoundEffect")
		v31.Name = "Limiter"
		v31.Threshold = -10
		v31.Ratio = 4
		v31.Attack = 0.005
		v31.Release = 0.25
		v31.GainMakeup = 0
		v31.Priority = 3
		v31.Parent = v20.Master
	end
	v_u_2.effects.limiter = v31
	local v32 = v20.AmbOut:FindFirstChild("Walls")
	if not v32 then
		v32 = Instance.new("EqualizerSoundEffect")
		v32.Name = "Walls"
		v32.HighGain = 0
		v32.MidGain = 0
		v32.LowGain = 0
		v32.Enabled = false
		v32.Parent = v20.AmbOut
	end
	v_u_2.effects.walls = v32
	v_u_2.effects.duckMusic = v20.Music
end
local function v_u_38() -- name: newVoice
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	if #v_u_4 >= 56 then
		return nil
	end
	local v34 = Instance.new("Sound")
	v34.Name = "HushVoice"
	v34.RollOffMode = Enum.RollOffMode.InverseTapered
	local v_u_35 = {
		["sound"] = nil,
		["att"] = nil,
		["busy"] = false,
		["serial"] = 0,
		["name"] = "",
		["priority"] = 1,
		["started"] = 0,
		["endsAt"] = 0,
		["base"] = 0,
		["unit"] = 0,
		["fadeFrom"] = 1,
		["fadeTo"] = 1,
		["fadeT0"] = 0,
		["fadeDur"] = 0,
		["stopAfterFade"] = false,
		["follow"] = nil,
		["pos"] = nil,
		["occl"] = false,
		["occAmount"] = 0,
		["occTarget"] = 0,
		["nextOccCheck"] = 0,
		["eq"] = nil,
		["rev"] = nil,
		["fixedLowpass"] = 0,
		["is3D"] = false,
		["pendingLen"] = false,
		["t0"] = 0,
		["tailAt"] = (1 / 0),
		["tailFadeDur"] = 0.1,
		["relSerial"] = 0,
		["relReason"] = "",
		["endConn"] = nil,
		["sound"] = v34
	}
	v34.Ended:Connect(function()
		-- upvalues: (ref) v_u_2, (copy) v_u_35
		if not v_u_2.fix then
			if v_u_35.busy and v_u_35.endsAt ~= (1 / 0) then
				if v_u_35.sound.IsPlaying or os.clock() - v_u_35.started < 0.05 then
					local v36 = v_u_2.counters
					v36.endedStaleFreed = (v36.endedStaleFreed or 0) + 1
				end
				v_u_2._release(v_u_35, "ended")
			end
		end
	end)
	local v37 = v_u_4
	table.insert(v37, v_u_35)
	return v_u_35
end
function v_u_2._release(p_u_39, p40) -- name: _release
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (copy) v_u_5
	if p_u_39.busy then
		local v41 = p40 or "stop"
		local v42 = "rel_" .. v41
		local v43 = v_u_2.counters
		v43[v42] = (v43[v42] or 0) + 1
		p_u_39.relSerial = p_u_39.serial
		p_u_39.relReason = v41
		if p_u_39.endConn then
			p_u_39.endConn:Disconnect()
			p_u_39.endConn = nil
		end
		p_u_39.busy = false
		p_u_39.serial = p_u_39.serial + 1
		p_u_39.tailAt = (1 / 0)
		pcall(function()
			-- upvalues: (copy) p_u_39
			p_u_39.sound:Stop()
		end)
		p_u_39.sound.PlaybackRegionsEnabled = false
		p_u_39.sound.Looped = false
		p_u_39.follow = nil
		p_u_39.pos = nil
		if p_u_39.eq then
			p_u_39.eq.Enabled = false
		end
		if p_u_39.rev then
			p_u_39.rev.Enabled = false
		end
		local v44 = v_u_10[p_u_39.name]
		local v45 = v44 and table.find(v44, p_u_39)
		if v45 then
			table.remove(v44, v45)
		end
		local v46 = table.find(v_u_5, p_u_39)
		if v46 then
			table.remove(v_u_5, v46)
		end
	end
end
local function v_u_52(p47) -- name: acquire
	-- upvalues: (copy) v_u_4, (copy) v_u_38, (copy) v_u_5, (copy) v_u_2
	for _, v48 in v_u_4 do
		if v48.busy then
			continue
		end
		return v48
	end
	local v49 = v_u_38()
	if v49 then
		return v49
	end
	local v50 = nil
	for _, v51 in v_u_5 do
		if v51.priority > p47 or (v51.endsAt == (1 / 0) or v50 and (v51.priority >= v50.priority and (v51.priority ~= v50.priority or v51.started >= v50.started))) then
			continue
		end
		v50 = v51
	end
	if not v50 then
		return nil
	end
	v_u_2._release(v50, "steal")
	return v50
end
local function v_u_58(p53) -- name: applyFilters
	local v54 = p53.occAmount
	local v55 = p53.fixedLowpass
	local v56 = math.max(v54, v55)
	if v56 > 0.02 then
		local v57 = p53.eq
		if not v57 then
			v57 = Instance.new("EqualizerSoundEffect")
			v57.Name = "Occl"
			v57.Priority = 5
			v57.Parent = p53.sound
			p53.eq = v57
		end
		v57.HighGain = v56 * -28
		v57.MidGain = v56 * -9
		v57.LowGain = v56 * 1.5
		v57.Enabled = true
	elseif p53.eq then
		p53.eq.Enabled = false
	end
end
local function v_u_91(p59, p60) -- name: makeHandle
	-- upvalues: (copy) v_u_2
	local v73 = {
		["voice"] = p59,
		["serial"] = p59.serial,
		["name"] = p60,
		["alive"] = function(p61) -- name: alive
			local v62 = p61.voice.busy
			if v62 then
				v62 = p61.voice.serial == p61.serial
			end
			return v62
		end,
		["stop"] = function(p63, p64) -- name: stop
			-- upvalues: (ref) v_u_2
			if p63:alive() then
				local v65 = p63.voice
				if p64 and p64 > 0 then
					local v66 = os.clock()
					local v67
					if v65.fadeDur > 0 then
						local v68 = (v66 - v65.fadeT0) / v65.fadeDur
						local v69 = math.clamp(v68, 0, 1)
						v67 = v65.fadeFrom + (v65.fadeTo - v65.fadeFrom) * v69
					else
						v67 = v65.fadeTo
					end
					local v70 = 1 - v65.occAmount * 0.5
					local v71 = v65.base * v67 * v70
					local v72 = v65.base * (1 - v65.occAmount * 0.5)
					v65.fadeFrom = v71 / math.max(v72, 0.0001)
					v65.fadeTo = 0
					v65.fadeT0 = v66
					v65.fadeDur = p64
					v65.stopAfterFade = true
				else
					v_u_2._release(v65, "stop")
				end
			else
				return
			end
		end
	}
	v73.Stop = v73.stop
	function v73.setVolume(p74, p75, p76) -- name: setVolume
		if p74:alive() then
			local v77 = p74.voice
			if p76 and p76 > 0 then
				local v78 = os.clock()
				local v79
				if v77.base > 0 then
					local v80
					if v77.fadeDur > 0 then
						local v81 = (v78 - v77.fadeT0) / v77.fadeDur
						local v82 = math.clamp(v81, 0, 1)
						v80 = v77.fadeFrom + (v77.fadeTo - v77.fadeFrom) * v82
					else
						v80 = v77.fadeTo
					end
					local v83 = 1 - v77.occAmount * 0.5
					local v84 = v77.base * v80 * v83
					local v85 = 1 - v77.occAmount * 0.5
					v79 = v84 / math.max(v85, 0.0001)
				else
					v79 = 0
				end
				v77.base = v77.unit * p75
				v77.fadeFrom = v77.base <= 0 and 0 or v79 / v77.base
				v77.fadeTo = 1
				v77.fadeT0 = v78
				v77.fadeDur = p76
			else
				v77.base = v77.unit * p75
			end
		else
			return
		end
	end
	v73.SetVolume = v73.setVolume
	function v73.setPitch(p86, p87) -- name: setPitch
		if p86:alive() then
			p86.voice.sound.PlaybackSpeed = p87
		end
	end
	function v73.setPosition(p88, p89) -- name: setPosition
		if p88:alive() and p88.voice.att then
			p88.voice.pos = p89
			p88.voice.att.WorldPosition = p89
		end
	end
	function v73.timePosition(p90) -- name: timePosition
		return not p90:alive() and 0 or p90.voice.sound.TimePosition
	end
	return v73
end
function v_u_2.play(p92, p93) -- name: play
	-- upvalues: (ref) v_u_3, (copy) v_u_15, (copy) v_u_2, (copy) v_u_9, (copy) v_u_10, (copy) v_u_14, (copy) v_u_8, (copy) v_u_52, (ref) v_u_7, (ref) v_u_6, (copy) v_u_58, (copy) v_u_5, (copy) v_u_91
	local v94 = v_u_3
	if v94 then
		v94 = v_u_3.defs[p92]
	end
	if not (v94 or v_u_15[p92]) then
		v_u_15[p92] = true
		warn("[HUSH:Audio] unknown sound name:", p92)
	end
	if not v94 then
		v_u_2.lastFail = "unknown"
		return nil
	end
	local v95 = p93 or {}
	local v96 = os.clock()
	if v94.cool and (v_u_9[p92] and v96 - v_u_9[p92] < v94.cool) then
		v_u_2.lastFail = "cooldown"
		return nil
	end
	local v97 = v_u_10[p92]
	if not v97 then
		v97 = {}
		v_u_10[p92] = v97
	end
	if v94.max and (#v97 >= v94.max and not v95.ignoreMax) then
		local v98 = v97[1]
		if v98.endsAt == (1 / 0) then
			v_u_2.lastFail = "loopmax"
			return nil
		end
		v_u_2._release(v98, "defmax")
	end
	local v99 = v95.variant
	local v100 = #v94.v
	local v101
	if v100 == 0 then
		v101 = nil
	elseif v99 then
		local v102 = math.clamp(v99, 1, v100)
		v101 = v94.v[v102]
	else
		local v103 = v_u_14:NextInteger(1, v100)
		if v100 > 1 and v_u_8[p92] == v103 then
			v103 = v103 % v100 + 1
		end
		v_u_8[p92] = v103
		v101 = v94.v[v103]
	end
	if not v101 then
		v_u_2.lastFail = "novariant"
		return nil
	end
	local v104 = v95.priority or (v94.group == "Music" and 5 or 1)
	local v_u_105 = v_u_52(v104)
	if not v_u_105 then
		v_u_2.lastFail = "novoice"
		return nil
	end
	v_u_9[p92] = v96
	v_u_7 = v_u_7 + 1
	v_u_105.serial = v_u_7
	v_u_105.busy = true
	v_u_105.name = p92
	v_u_105.priority = v104
	v_u_105.started = v96
	v_u_105.follow = v95.follow
	v_u_105.pos = v95.pos
	v_u_105.stopAfterFade = false
	v_u_105.occAmount = 0
	v_u_105.occTarget = 0
	v_u_105.nextOccCheck = 0
	v_u_105.fixedLowpass = v95.lowpass or 0
	local v_u_106 = v_u_105.sound
	local v107 = v95.pos ~= nil and true or v95.follow ~= nil
	v_u_105.is3D = v107
	if v107 then
		local v108 = v_u_105.att
		if not v108 then
			v108 = Instance.new("Attachment")
			v108.Name = "HushAudio"
			v108.Parent = workspace.Terrain
			v_u_105.att = v108
		end
		local v109 = v95.pos or Vector3.new(0, 0, 0)
		local v110 = v95.follow
		if v110 then
			if v110:IsA("BasePart") then
				v109 = v110.Position
			elseif v110:IsA("Attachment") then
				v109 = v110.WorldPosition
			end
		end
		v108.WorldPosition = v109
		v_u_105.pos = v109
		if v_u_106.Parent ~= v108 then
			v_u_106.Parent = v108
		end
		local v111 = v95.roll or v94.roll
		if v95.noRolloff then
			v_u_106.RollOffMode = Enum.RollOffMode.Linear
			v_u_106.RollOffMinDistance = 20000
			v_u_106.RollOffMaxDistance = 20001
		else
			v_u_106.RollOffMode = Enum.RollOffMode.InverseTapered
			v_u_106.RollOffMinDistance = not v111 and 10 or v111[1]
			v_u_106.RollOffMaxDistance = not v111 and 150 or v111[2]
		end
		local v112
		if v95.occlude == nil then
			v112 = v94.occl ~= false
		else
			v112 = v95.occlude
		end
		v_u_105.occl = v112
	else
		if v_u_106.Parent ~= v_u_6 then
			v_u_106.Parent = v_u_6
		end
		v_u_105.occl = false
	end
	local v113 = v95.group or v94.group
	local v114 = v113 == "Ambience" and "AmbOut" or v113
	v_u_106.SoundGroup = v_u_2.groups[v114] or v_u_2.groups.SFX
	local v115 = v101.id
	v_u_106.SoundId = "rbxassetid://" .. tostring(v115)
	local v116 = v94.pitch
	local v117 = (v101.p or 1) * (v95.pitch or 1)
	if v116 then
		v117 = v117 * (v116[1] + (v116[2] - v116[1]) * v_u_14:NextNumber())
	end
	v_u_106.PlaybackSpeed = v117
	local v118 = v95.t0 or (v101.t0 or 0)
	local v119 = v95.len or v101.len
	local v120
	if v95.loop == nil then
		v120 = v94.loop == true
	else
		v120 = v95.loop
	end
	v_u_106.Looped = v120
	if v119 or v118 > 0 then
		v_u_106.PlaybackRegionsEnabled = true
		local v121 = not v119 and 1000000 or v118 + v119
		v_u_106.PlaybackRegion = NumberRange.new(v118, v121)
		if v120 then
			v_u_106.LoopRegion = NumberRange.new(v118, v121)
		end
	else
		v_u_106.PlaybackRegionsEnabled = false
	end
	local v122 = v94.gain * (v101.g or 1)
	local v123 = v101.id
	local v124 = v_u_3.loudness
	if v124 then
		v124 = v_u_3.loudness[v123]
	end
	local v125
	if v124 and v124 > 0 then
		local v126 = (v_u_3.REF_LOUDNESS or 300) / v124
		v125 = math.clamp(v126, 0.25, 6)
	else
		v125 = 1
	end
	local v127 = v122 * v125
	v_u_105.unit = v127
	v_u_105.base = v127 * (v95.volume or 1)
	if v95.fadeIn and v95.fadeIn > 0 then
		v_u_105.fadeFrom = 0
		v_u_105.fadeTo = 1
		v_u_105.fadeT0 = v96
		v_u_105.fadeDur = v95.fadeIn
	else
		v_u_105.fadeFrom = 1
		v_u_105.fadeTo = 1
		v_u_105.fadeDur = 0
	end
	v_u_105.t0 = v118
	v_u_105.pendingLen = false
	v_u_105.tailAt = (1 / 0)
	if v119 and (not v120 and v119 > 0.05) then
		local v128 = v119 * 0.3
		local v129 = math.min(0.1, v128)
		v_u_105.tailAt = v118 + v119 - v129
		v_u_105.tailFadeDur = v129 / math.max(v117, 0.05)
	end
	if v120 then
		v_u_105.endsAt = (1 / 0)
	elseif v119 then
		v_u_105.endsAt = v96 + v119 / math.max(v117, 0.05) + 0.25
	elseif v_u_106.TimeLength > 0 then
		v_u_105.endsAt = v96 + (v_u_106.TimeLength - v118) / math.max(v117, 0.05) + 0.25
	else
		v_u_105.endsAt = v96 + 600
		v_u_105.pendingLen = true
	end
	if v95.reverb and v95.reverb > 0 then
		local v130 = v_u_105.rev
		if not v130 then
			v130 = Instance.new("ReverbSoundEffect")
			v130.Name = "Slap"
			v130.Priority = 4
			v130.Parent = v_u_106
			v_u_105.rev = v130
		end
		v130.DecayTime = 0.45 + 0.6 * v95.reverb
		v130.Density = 1
		v130.Diffusion = 0.8
		v130.DryLevel = 0
		v130.WetLevel = -6 + 4 * v95.reverb
		v130.Enabled = true
	elseif v_u_105.rev then
		v_u_105.rev.Enabled = false
	end
	v_u_58(v_u_105)
	local v131
	if v_u_105.fadeDur > 0 then
		local v132 = (v96 - v_u_105.fadeT0) / v_u_105.fadeDur
		local v133 = math.clamp(v132, 0, 1)
		v131 = v_u_105.fadeFrom + (v_u_105.fadeTo - v_u_105.fadeFrom) * v133
	else
		v131 = v_u_105.fadeTo
	end
	local v134 = 1 - v_u_105.occAmount * 0.5
	v_u_106.Volume = v_u_105.base * v131 * v134
	if v_u_106.TimePosition ~= v118 then
		v_u_106.TimePosition = v118
	end
	v_u_106:Play()
	if v_u_105.endConn then
		v_u_105.endConn:Disconnect()
		v_u_105.endConn = nil
	end
	if v_u_2.fix and not v120 then
		local v_u_135 = v_u_105.serial
		v_u_105.endConn = v_u_106.Ended:Connect(function()
			-- upvalues: (copy) v_u_105, (copy) v_u_135, (ref) v_u_2, (copy) v_u_106
			if v_u_105.serial == v_u_135 and (v_u_105.busy and v_u_105.endsAt ~= (1 / 0)) then
				if v_u_106.IsPlaying then
					local v136 = v_u_2.counters
					v136.endedStaleIgnored = (v136.endedStaleIgnored or 0) + 1
				else
					v_u_2._release(v_u_105, "ended")
				end
			else
				local v137 = v_u_2.counters
				v137.endedStaleIgnored = (v137.endedStaleIgnored or 0) + 1
				return
			end
		end)
	end
	table.insert(v97, v_u_105)
	local v138 = v_u_5
	table.insert(v138, v_u_105)
	return v_u_91(v_u_105, p92)
end
function v_u_2.bed(p_u_139, p140) -- name: bed
	-- upvalues: (ref) v_u_3, (copy) v_u_15, (copy) v_u_2, (copy) v_u_8, (copy) v_u_14, (copy) v_u_13
	local v_u_141 = v_u_3
	if v_u_141 then
		v_u_141 = v_u_3.defs[p_u_139]
	end
	if not (v_u_141 or v_u_15[p_u_139]) then
		v_u_15[p_u_139] = true
		warn("[HUSH:Audio] unknown sound name:", p_u_139)
	end
	if not v_u_141 then
		return nil
	end
	local v_u_142 = p140 or {}
	local v_u_143 = v_u_141.xfade or 2
	local v_u_144 = {
		["name"] = nil,
		["opts"] = nil,
		["cur"] = nil,
		["prev"] = nil,
		["vol"] = nil,
		["dead"] = false,
		["nextSwap"] = 0,
		["xf"] = nil,
		["pos"] = nil,
		["name"] = p_u_139,
		["opts"] = v_u_142,
		["vol"] = v_u_142.volume or 1,
		["xf"] = v_u_143,
		["pos"] = v_u_142.pos
	}
	local function v156(p145, p146) -- name: start
		-- upvalues: (copy) v_u_144, (copy) v_u_142, (ref) v_u_2, (copy) p_u_139, (copy) v_u_141, (ref) v_u_8, (copy) v_u_143, (ref) v_u_14
		local v147 = {
			["pos"] = nil,
			["follow"] = nil,
			["volume"] = nil,
			["pitch"] = nil,
			["loop"] = true,
			["fadeIn"] = nil,
			["roll"] = nil,
			["occlude"] = nil,
			["group"] = nil,
			["priority"] = nil,
			["lowpass"] = nil,
			["pos"] = v_u_144.pos,
			["follow"] = v_u_142.follow,
			["volume"] = v_u_144.vol,
			["pitch"] = v_u_142.pitch,
			["fadeIn"] = p145,
			["roll"] = v_u_142.roll,
			["occlude"] = v_u_142.occlude,
			["group"] = v_u_142.group,
			["priority"] = v_u_142.priority or 5,
			["lowpass"] = v_u_142.lowpass,
			["ignoreMax"] = true
		}
		local v148 = v_u_2.play(p_u_139, v147)
		if v148 then
			local v149 = v148.voice.sound
			local v150 = v_u_141.v[v_u_8[p_u_139] or 1] or v_u_141.v[1]
			local v151 = v150.t0 or 0
			local v152 = v150.len or (v149.TimeLength <= 0 and 0 or v149.TimeLength - v151)
			if p146 and v_u_143 * 4 < v152 then
				v149.TimePosition = v151 + v_u_14:NextNumber() * (v152 - v_u_143 * 3)
			end
			v_u_144.prev = v_u_144.cur
			v_u_144.cur = v148
			local v153
			if v152 > 0 then
				local v154 = v151 + v152 - v149.TimePosition
				local v155 = v149.PlaybackSpeed
				v153 = v154 / math.max(v155, 0.05)
			else
				v153 = 0
			end
			v_u_144.nextSwap = v_u_143 * 2 >= v153 and (1 / 0) or os.clock() + v153 - v_u_143
			v_u_144.len = v152
		end
	end
	v_u_144.start = v156
	v156(v_u_142.fadeIn or v_u_143, true)
	function v_u_144.alive(p157) -- name: alive
		return not p157.dead
	end
	function v_u_144.stop(p158, p159) -- name: stop
		-- upvalues: (ref) v_u_13
		if not p158.dead then
			p158.dead = true
			if p158.cur then
				p158.cur:stop(p159 or 1)
			end
			if p158.prev then
				p158.prev:stop(p159 or 1)
			end
			local v160 = table.find(v_u_13, p158)
			if v160 then
				table.remove(v_u_13, v160)
			end
		end
	end
	v_u_144.Stop = v_u_144.stop
	function v_u_144.setVolume(p161, p162, p163) -- name: setVolume
		p161.vol = p162
		if p161.cur then
			p161.cur:setVolume(p162, p163)
		end
	end
	v_u_144.SetVolume = v_u_144.setVolume
	function v_u_144.setPosition(p164, p165) -- name: setPosition
		p164.pos = p165
		if p164.cur then
			p164.cur:setPosition(p165)
		end
		if p164.prev then
			p164.prev:setPosition(p165)
		end
	end
	local v166 = v_u_13
	table.insert(v166, v_u_144)
	return v_u_144
end
local function v_u_177(p167) -- name: stepBeds
	-- upvalues: (copy) v_u_13, (ref) v_u_3, (copy) v_u_8
	for v168 = #v_u_13, 1, -1 do
		local v169 = v_u_13[v168]
		if v169.dead then
			continue
		end
		local v170 = v169.cur
		if v170 and v170:alive() then
			if v169.nextSwap == (1 / 0) and (v169.len or 0) <= 0 then
				local v171 = v170.voice.sound
				if v171.TimeLength <= 0 then
					continue
				end
				local v172 = v_u_3.defs[v169.name]
				if v172 then
					v172 = v172.v[v_u_8[v169.name] or 1]
				end
				local v173 = v172 and (v172.t0 or 0) or 0
				local v174 = v172 and v172.len or v171.TimeLength - v173
				v169.len = v174
				if v169.xf * 2 >= v174 then
					continue
				end
				local v175 = v173 + v174 - v171.TimePosition
				local v176 = v171.PlaybackSpeed
				v169.nextSwap = p167 + v175 / math.max(v176, 0.05) - v169.xf
			else
				if v169.nextSwap > p167 then
					continue
				end
				v169.start(v169.xf, false)
				v170:stop(v169.xf)
			end
		else
			v169.cur = nil
			v169.start(1.5, true)
		end
	end
end
function v_u_2.setOccluder(p178) -- name: setOccluder
	-- upvalues: (ref) v_u_11
	v_u_11 = p178
end
function v_u_2.step(p179, p180) -- name: step
	-- upvalues: (ref) v_u_12, (copy) v_u_177, (copy) v_u_5, (copy) v_u_2, (ref) v_u_11, (copy) v_u_14, (copy) v_u_58
	v_u_12 = p180
	local v181 = os.clock()
	v_u_177(v181)
	local v182 = 5
	for v183 = #v_u_5, 1, -1 do
		local v184 = v_u_5[v183]
		if not v184 then
			continue
		end
		if v184.busy then
			if v184.pendingLen then
				local v185 = v184.sound.TimeLength
				if v185 > 0 then
					v184.pendingLen = false
					local v186 = v184.started
					local v187 = v185 - v184.t0
					local v188 = v184.sound.PlaybackSpeed
					v184.endsAt = v186 + v187 / math.max(v188, 0.05) + 0.4
				elseif v181 - v184.started > 15 then
					v184.endsAt = v181
				end
			end
			if v184.endsAt < v181 then
				v_u_2._release(v184, "timeout")
			else
				if v184.tailAt ~= (1 / 0) and v184.sound.TimePosition >= v184.tailAt then
					v184.tailAt = (1 / 0)
					local v189 = v184.fadeTo
					if v184.fadeDur > 0 then
						local v190 = v184.fadeFrom
						local v191 = v184.fadeTo - v184.fadeFrom
						local v192 = (v181 - v184.fadeT0) / v184.fadeDur
						v189 = v190 + v191 * math.clamp(v192, 0, 1)
					end
					v184.fadeFrom = v189
					v184.fadeTo = 0
					v184.fadeT0 = v181
					local v193 = v184.tailFadeDur
					v184.fadeDur = math.max(v193, 0.02)
					v184.stopAfterFade = true
				end
				local v194 = v184.follow
				if v194 then
					if v194.Parent == nil then
						v184.follow = nil
					elseif v184.att then
						local v195
						if v194:IsA("BasePart") then
							v195 = v194.Position
						elseif v194:IsA("Attachment") then
							v195 = v194.WorldPosition
						else
							v195 = nil
						end
						if v195 then
							v184.pos = v195
							v184.att.WorldPosition = v195
						end
					end
				end
				if v184.occl and (v184.pos and (v_u_11 and (v184.nextOccCheck <= v181 and v182 > 0))) then
					v182 = v182 - 1
					v184.nextOccCheck = v181 + 0.3 + v_u_14:NextNumber() * 0.1
					local v196 = v_u_11
					local v197 = v_u_12
					local v198 = v184.pos
					local v199, v200 = pcall(v196, v197, v198)
					v184.occTarget = (not v199 or type(v200) ~= "number") and 0 or v200
				end
				local v201 = v184.occAmount - v184.occTarget
				local v202
				if math.abs(v201) > 0.01 then
					local v203 = v184.occAmount
					local v204 = v184.occTarget - v184.occAmount
					local v205 = p179 * 8
					v184.occAmount = v203 + v204 * math.min(1, v205)
					v_u_58(v184)
					v202 = true
				else
					v202 = false
				end
				if v184.fadeDur > 0 or v202 then
					local v206
					if v184.fadeDur > 0 then
						local v207 = (v181 - v184.fadeT0) / v184.fadeDur
						local v208 = math.clamp(v207, 0, 1)
						v206 = v184.fadeFrom + (v184.fadeTo - v184.fadeFrom) * v208
					else
						v206 = v184.fadeTo
					end
					local v209 = 1 - v184.occAmount * 0.5
					local v210 = v184.base * v206 * v209
					v184.sound.Volume = v210
					if v184.fadeDur <= 0 or v181 - v184.fadeT0 < v184.fadeDur then
						continue
					end
					v184.fadeFrom = v184.fadeTo
					v184.fadeDur = 0
					if not v184.stopAfterFade then
						continue
					end
					v_u_2._release(v184, "fade")
				else
					local v211 = v184.sound.Volume
					local v212
					if v184.fadeDur > 0 then
						local v213 = (v181 - v184.fadeT0) / v184.fadeDur
						local v214 = math.clamp(v213, 0, 1)
						v212 = v184.fadeFrom + (v184.fadeTo - v184.fadeFrom) * v214
					else
						v212 = v184.fadeTo
					end
					local v215 = 1 - v184.occAmount * 0.5
					local v216 = v211 - v184.base * v212 * v215
					if math.abs(v216) <= 0.005 then
						continue
					end
					local v217 = v184.sound
					local v218
					if v184.fadeDur > 0 then
						local v219 = (v181 - v184.fadeT0) / v184.fadeDur
						local v220 = math.clamp(v219, 0, 1)
						v218 = v184.fadeFrom + (v184.fadeTo - v184.fadeFrom) * v220
					else
						v218 = v184.fadeTo
					end
					local v221 = 1 - v184.occAmount * 0.5
					v217.Volume = v184.base * v218 * v221
				end
			end
		else
			table.remove(v_u_5, v183)
		end
	end
end
function v_u_2.occludeNow(p222) -- name: occludeNow
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_58
	if p222 and (p222:alive() and v_u_11) then
		local v223 = p222.voice
		if v223.pos and v223.occl then
			local v224 = v_u_11
			local v225 = v_u_12
			local v226 = v223.pos
			local v227, v228 = pcall(v224, v225, v226)
			if v227 and type(v228) == "number" then
				v223.occTarget = v228
				v223.occAmount = v228
				v223.nextOccCheck = os.clock() + 0.3
				v_u_58(v223)
				local v229 = v223.sound
				local v230 = os.clock()
				local v231
				if v223.fadeDur > 0 then
					local v232 = (v230 - v223.fadeT0) / v223.fadeDur
					local v233 = math.clamp(v232, 0, 1)
					v231 = v223.fadeFrom + (v223.fadeTo - v223.fadeFrom) * v233
				else
					v231 = v223.fadeTo
				end
				local v234 = 1 - v223.occAmount * 0.5
				v229.Volume = v223.base * v231 * v234
			end
		end
	end
end
function v_u_2.stopAll(p235, p236) -- name: stopAll
	-- upvalues: (copy) v_u_13, (copy) v_u_5, (copy) v_u_91
	local v237 = {}
	for _, v238 in v_u_13 do
		local v239 = v238.cur
		if v238.dead or (not v239 or (not v239:alive() or p235 and not p235(v239.voice))) then
			continue
		end
		table.insert(v237, v238)
	end
	for _, v240 in v237 do
		v240:stop(p236)
	end
	for v241 = #v_u_5, 1, -1 do
		local v242 = v_u_5[v241]
		if not v242 or (not v242.busy or p235 and not p235(v242)) then
			continue
		end
		v_u_91(v242, v242.name):stop(p236)
	end
end
function v_u_2.activeCount() -- name: activeCount
	-- upvalues: (copy) v_u_5
	return #v_u_5
end
function v_u_2.activeVoices() -- name: activeVoices
	-- upvalues: (copy) v_u_5
	return table.clone(v_u_5)
end
function v_u_2.bedOf(p243) -- name: bedOf
	-- upvalues: (copy) v_u_13
	for _, v244 in v_u_13 do
		if v244.dead or (not v244.cur or v244.cur.voice ~= p243) and (not v244.prev or v244.prev.voice ~= p243) then
			continue
		end
		return v244
	end
	return nil
end
function v_u_2.groupVoices(p245) -- name: groupVoices
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v246 = v_u_2.groups[p245]
	local v247 = {}
	if not v246 then
		return v247
	end
	for _, v248 in v_u_5 do
		if not v248.busy or v248.sound.SoundGroup ~= v246 then
			continue
		end
		table.insert(v247, v248)
	end
	return v247
end
function v_u_2.stats() -- name: stats
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_13
	local v249 = {}
	for _, v250 in v_u_5 do
		v249[v250.name] = (v249[v250.name] or 0) + 1
	end
	local v251 = {}
	for v252, v253 in v249 do
		local v254 = v252 .. "x" .. v253
		table.insert(v251, v254)
	end
	table.sort(v251)
	return string.format("voices %d/%d beds %d: %s", #v_u_5, #v_u_4, #v_u_13, table.concat(v251, " "))
end
function v_u_2.counterText(p255) -- name: counterText
	-- upvalues: (copy) v_u_2
	local v256 = {}
	for v257, v258 in v_u_2.counters do
		local v259 = v257 .. "=" .. v258
		table.insert(v256, v259)
	end
	table.sort(v256)
	if p255 then
		table.clear(v_u_2.counters)
	end
	return table.concat(v256, " ")
end
function v_u_2.init(p260) -- name: init
	-- upvalues: (ref) v_u_3, (copy) v_u_33, (copy) v_u_1, (ref) v_u_6
	v_u_3 = p260
	v_u_33()
	local v261 = v_u_1:FindFirstChild("HushVoices2D")
	if not v261 then
		v261 = Instance.new("Folder")
		v261.Name = "HushVoices2D"
		v261.Parent = v_u_1
	end
	v_u_6 = v261
end
return v_u_2