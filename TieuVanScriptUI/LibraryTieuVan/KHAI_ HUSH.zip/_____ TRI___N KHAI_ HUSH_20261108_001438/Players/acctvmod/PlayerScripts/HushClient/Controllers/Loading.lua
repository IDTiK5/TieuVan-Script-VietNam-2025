-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Loading

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {
	["name"] = "Loading",
	["order"] = 2
}
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = v3.LocalPlayer
local v_u_10 = {
	["Raid"] = 45,
	["Menu"] = 12,
	["Hideout"] = 25
}
local v_u_11 = {
	"Every gunshot rings the dinner bell. A blade is quiet.",
	"Zombies hear you long before they see you. Sneak past instead of fighting through.",
	"One exit is always open. Every other way out has a price.",
	"Bleeding kills slowly. Bandage first, loot later.",
	"A bite can infect you. Extract before the timer runs out.",
	"A downed squad mate can be helped up for 30 seconds. Don\'t leave them behind.",
	"Your secure case always comes home, whatever happens.",
	"Close doors behind you. It buys you seconds.",
	"Screamers call the horde. Silence them first.",
	"Night raids are darker and richer. Your flashlight is your lifeline.",
	"Strangers are not enemies. Help them up and they may return the favour.",
	"Carry too much and you move too slowly. Mind the weight.",
	"When the siren sounds, the dead wake up. Be on your way out.",
	"Blind patients hunt by ear. Freeze, and they lose you.",
	"Never finish a hazmat up close. Its tank bursts into a choking cloud.",
	"A buzzing belt means a pager about to shrill. Put the Ringer down quietly first.",
	"Riot shields stop bullets from the front. Flank them, or aim for the legs."
}
local v_u_12 = {
	"A recorded voice only works while the net is up.",
	"The runway is open ground. Cross it fast or go around, the dead see you from far away.",
	"Hangars and offices hold the best loot. Check the desks before you leave.",
	"Most exits on the field have a price: a card, a part, cash. Read the exit list before you commit.",
	"Sound carries across the apron. Shoot from cover or do not shoot.",
	"The gate is always open. Everything else costs something.",
	"The Reception Center is crowded. Keep to the edges of the tent rows."
}
local v_u_13 = {
	"Snow swallows footsteps. Iron and rock do not.",
	"A mound that breathes is not a mound.",
	"Three knocks and a pause. Someone is calling.",
	"When the hum rises, keep still.",
	"A thrown line can be cut. A rope needs a clear path.",
	"Kill the one who hums. The rest will follow.",
	"Pop a swollen one from far away, or not at all.",
	"The way up is long. The way out is a choice.",
	"Some doors want a key from another place."
}
local v_u_14 = {
	"The Overture plays for the whole raid. When the choir joins, five minutes are left.",
	"A red line from a rooftop is a marksman. Break the line of sight, do not run along it.",
	"A Cantor sings and the infected near it follow the note. Kill the Cantor first.",
	"Dust from the ceiling and a clank: step out of the circle.",
	"Patrons sleep in rows. Walk the aisles softly.",
	"Cards open doors. A guard\'s locker often holds a copy."
}
local v_u_15 = {}
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = false
local v_u_22 = 0
local v_u_23 = false
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = "Menu"
local v_u_27 = Random.new()
local v_u_28 = false
local v_u_29 = (-1 / 0)
local v_u_30 = nil
local function v_u_35() -- name: joinIntro
	local v31 = game:GetService("ReplicatedFirst"):FindFirstChild("JoinIntro")
	if v31 and v31:IsA("ModuleScript") then
		local v32 = require
		local v33, v34 = pcall(v32, v31)
		if v33 and type(v34) == "table" then
			return v34
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_36 = {
	{ 0, 1 },
	{ 0.35, 0.35 },
	{ 1, 0.1 }
}
local function v_u_41(p37) -- name: artGrad
	-- upvalues: (copy) v_u_36
	if p37 <= v_u_36[1][1] then
		return v_u_36[1][2]
	end
	for v38 = 2, #v_u_36 do
		local v39 = v_u_36[v38 - 1]
		local v40 = v_u_36[v38]
		if p37 > v40[1] then
			continue
		end
		return v39[2] + (v40[2] - v39[2]) * (p37 - v39[1]) / (v40[1] - v39[1])
	end
	return v_u_36[#v_u_36][2]
end
local v_u_42 = {}
local v_u_43 = 0.15
local function v_u_51(p44) -- name: paintArt
	-- upvalues: (ref) v_u_43, (copy) v_u_42, (copy) v_u_41
	v_u_43 = p44
	for _, v45 in v_u_42 do
		if not v45.o.Parent then
			continue
		end
		local v46 = v45.o
		local v47 = v45.p
		local v48 = v45.own
		local v49 = v45.x
		local v50 = not v49 and 0 or v_u_41(v49)
		v46[v47] = 1 - (1 - v48) * (1 - v50) * (1 - p44)
	end
end
local function v_u_225() -- name: build
	-- upvalues: (ref) v_u_19, (ref) v_u_8, (ref) v_u_7, (copy) v_u_27, (copy) v_u_42, (copy) v_u_41, (ref) v_u_6, (copy) v_u_51, (ref) v_u_43, (copy) v_u_5, (ref) v_u_20
	if v_u_19 and v_u_19.Parent then
		return
	end
	local v_u_52 = v_u_8.color
	local v53, v54 = v_u_7.screen("HushTransit", v_u_8.layer.loading - 1, {
		["insets"] = "None",
		["enabled"] = false
	})
	v_u_19 = v53
	local v55 = v_u_7.new("Frame", {
		["Name"] = "Card",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Active"] = true,
		["BackgroundColor3"] = v_u_52.bgDeep,
		["Size"] = UDim2.fromScale(1, 1)
	}, v54)
	local v56 = v_u_7.new("Frame", {
		["Name"] = "Rain",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Size"] = UDim2.fromScale(1, 1)
	}, v55)
	local v57 = {}
	for _ = 1, 40 do
		local v58 = {
			["f"] = v_u_7.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Rotation"] = 12,
				["BackgroundColor3"] = Color3.fromHex("#8FA3B8"),
				["BackgroundTransparency"] = v_u_27:NextNumber(0.87, 0.95),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.new(0, 1, v_u_27:NextNumber(0.05, 0.15), 0)
			}, v56),
			["x"] = v_u_27:NextNumber(-0.1, 1.1),
			["y"] = v_u_27:NextNumber(-0.2, 1.2),
			["v"] = v_u_27:NextNumber(0.9, 1.6)
		}
		table.insert(v57, v58)
	end
	local v59 = v_u_7.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_52.black,
		["Size"] = UDim2.fromScale(0.6, 1)
	}, v55)
	v_u_7.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.4), NumberSequenceKeypoint.new(1, 1) })
	}, v59)
	v_u_7.grain(v55, 0.07)
	local v60 = v_u_7.safeInsets()
	local v61 = v60.l + 24
	local v62 = math.ceil(v61)
	local v63 = math.max(72, v62)
	local v64 = v60.r + 24
	local v65 = math.ceil(v64)
	local v66 = math.max(72, v65)
	local v67 = v60.t + 24
	local v68 = math.ceil(v67)
	local v69 = math.max(64, v68)
	local v70 = v60.b + 16
	local v71 = math.ceil(v70)
	local v72 = math.max(48, v71)
	local v73 = v60.r + 16
	local v74 = math.ceil(v73)
	local v75 = math.max(56, v74)
	local v76 = v_u_7.new("Frame", {
		["Name"] = "Top",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v63, v69),
		["Size"] = UDim2.new(1, -(v63 + v66), 0, 28)
	}, v55)
	local v77 = v_u_7.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_52.accent,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(8, 8)
	}, v76)
	local v78 = v_u_7.label({
		["parent"] = nil,
		["text"] = "Deploying",
		["style"] = "h3",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v76,
		["color"] = v_u_52.accent,
		["position"] = UDim2.fromOffset(20, 0),
		["size"] = UDim2.new(1, -20, 1, 0)
	})
	local v79 = v_u_7.new("Frame", {
		["Name"] = "Block",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, v63, 0.47, 0),
		["Size"] = UDim2.new(1, -(v63 + v66), 0, 220)
	}, v55)
	local v80 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "display",
		["size"] = nil,
		["fit"] = true,
		["parent"] = v79,
		["size"] = UDim2.new(1, 0, 0, 120)
	})
	v_u_7.new("Frame", {
		["Name"] = "Rule",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_52.accent,
		["Position"] = UDim2.fromOffset(2, 128),
		["Size"] = UDim2.fromOffset(96, 2)
	}, v79)
	local v81 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "h3",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v79,
		["color"] = v_u_52.text2,
		["position"] = UDim2.fromOffset(0, 144),
		["size"] = UDim2.new(1, 0, 0, 26)
	})
	local v82 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v79,
		["color"] = v_u_52.muted,
		["position"] = UDim2.fromOffset(0, 178),
		["size"] = UDim2.new(1, 0, 0, 20)
	})
	local v83 = v_u_7.label({
		["parent"] = nil,
		["name"] = "Match",
		["text"] = "",
		["style"] = "bodyStrong",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v79,
		["color"] = v_u_52.accent,
		["position"] = UDim2.fromOffset(0, 176),
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v84 = v_u_7.new("Frame", {
		["Name"] = "Bottom",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, v63, 1, -v72),
		["Size"] = UDim2.new(1, -(v63 + v66), 0, 72)
	}, v55)
	v_u_7.label({
		["parent"] = nil,
		["text"] = "Tip",
		["style"] = "h3",
		["color"] = nil,
		["size"] = nil,
		["textSize"] = 15,
		["parent"] = v84,
		["color"] = v_u_52.accent,
		["size"] = UDim2.fromOffset(44, 22)
	})
	local v85 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "body",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v84,
		["color"] = v_u_52.text2,
		["position"] = UDim2.fromOffset(44, 0),
		["size"] = UDim2.new(1, -44, 0, 22)
	})
	local v86 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v84,
		["color"] = v_u_52.muted,
		["position"] = UDim2.fromOffset(0, 40),
		["size"] = UDim2.new(1, 0, 0, 18)
	})
	local v87 = v_u_7.new("Frame", {
		["Name"] = "Track",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_52.line,
		["Position"] = UDim2.new(0, 0, 1, -2),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}, v84)
	local v88 = v_u_7.new("Frame", {
		["Name"] = "Sweep",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_52.accent,
		["Size"] = UDim2.fromScale(0.22, 1)
	}, v87)
	v_u_7.new("UIGradient", {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) })
	}, v88)
	local v89 = v_u_7.new("Frame", {
		["Name"] = "MapArt",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -v66, 0.48, 0),
		["Size"] = UDim2.fromOffset(520, 520)
	}, v55)
	table.clear(v_u_42)
	local v90 = v_u_7.new("Frame", {
		["Name"] = "Town",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v89)
	local v91 = v_u_7.new("Frame", {
		["Name"] = "Field",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v89)
	local v92 = v_u_7.new("Frame", {
		["Name"] = "Plaza",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v89)
	local v93 = v_u_7.new("Frame", {
		["Name"] = "Ridge",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Size"] = UDim2.fromScale(1, 1)
	}, v89)
	local v_u_94 = v90
	local function v118(p95, p96, p97, p98, p99, p100, p101) -- name: seg
		-- upvalues: (ref) v_u_7, (ref) v_u_94, (ref) v_u_41, (ref) v_u_42
		local v102 = p97 - p95
		local v103 = p98 - p96
		local v104 = v_u_7.new
		local v105 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = p100,
			["BackgroundTransparency"] = p101,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale((p95 + p97) / 2, (p96 + p98) / 2)
		}
		local v106 = UDim2.new
		local v107 = v102 * v102 + v103 * v103
		v105.Size = v106(math.sqrt(v107), p99, 0, p99)
		local v108 = math.atan2(v103, v102)
		v105.Rotation = math.deg(v108)
		local v109 = v104("Frame", v105, v_u_94)
		if math.abs(v102) > 0.12 then
			local v110 = {}
			for v111 = 0, 6 do
				local v112 = v111 / 6
				local v113 = NumberSequenceKeypoint.new
				local v114 = v_u_41(p95 + v112 * v102)
				table.insert(v110, v113(v112, v114))
			end
			v_u_7.new("UIGradient", {
				["Transparency"] = NumberSequence.new(v110)
			}, v109)
			local v115 = v_u_42
			table.insert(v115, {
				["o"] = nil,
				["p"] = "BackgroundTransparency",
				["own"] = nil,
				["x"] = nil,
				["o"] = v109,
				["own"] = p101
			})
		else
			local v116 = v_u_42
			local v117 = {
				["o"] = nil,
				["p"] = "BackgroundTransparency",
				["own"] = nil,
				["x"] = nil,
				["o"] = v109,
				["own"] = p101,
				["x"] = (p95 + p97) / 2
			}
			table.insert(v116, v117)
		end
	end
	local v119 = v_u_94
	for v120 = 0, 13 do
		local v121 = v120 / 13
		v118(v121, 0, v121, 1, 1, v_u_52.line, 0.55)
		v118(0, v121, 1, v121, 1, v_u_52.line, 0.55)
	end
	v118(0.02, 0.62, 0.98, 0.58, 3, v_u_52.lineStrong, 0.1)
	v118(0.46, 0.02, 0.5, 0.98, 3, v_u_52.lineStrong, 0.1)
	v118(0.18, 0.2, 0.2, 0.9, 2, v_u_52.lineStrong, 0.3)
	v118(0.74, 0.12, 0.78, 0.86, 2, v_u_52.lineStrong, 0.3)
	v118(0.1, 0.34, 0.9, 0.3, 2, v_u_52.lineStrong, 0.3)
	v118(0.2, 0.82, 0.86, 0.8, 2, v_u_52.lineStrong, 0.3)
	local v122 = {
		0,
		0.12,
		0.26,
		0.34,
		0.38,
		0.36,
		0.42,
		0.56
	}
	local v123 = {
		0.12,
		0.1,
		0.14,
		0.24,
		0.38,
		0.5,
		0.66,
		1
	}
	for v124 = 1, #v122 - 1 do
		v118(v122[v124], v123[v124], v122[v124 + 1], v123[v124 + 1], 4, v_u_52.info, 0.72)
	end
	local v125 = Random.new(7)
	for _ = 1, 26 do
		local v126 = v125:NextNumber(0.08, 0.9)
		local v127 = v125:NextNumber(0.08, 0.9)
		local v128 = v125:NextNumber(0.025, 0.06)
		local v129 = v_u_42
		local v130 = {
			["o"] = nil,
			["p"] = "BackgroundTransparency",
			["own"] = 0.55,
			["x"] = nil,
			["o"] = v_u_7.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.55,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_52.lineStrong,
				["Position"] = UDim2.fromScale(v126, v127),
				["Size"] = UDim2.fromScale(v128, v125:NextNumber(0.02, 0.05))
			}, v119),
			["x"] = v126 + v128 / 2
		}
		table.insert(v129, v130)
	end
	local function v131()
		-- upvalues: (ref) v_u_6
		return v_u_6.lib.KestrelMapData
	end
	local v132, v133 = pcall(v131)
	if v132 and type(v133) == "table" then
		local v134 = v133.HALF
		if type(v134) == "number" then
			local v135 = v133.LOTS
			if type(v135) == "table" then
				v_u_94 = v91
				local v136 = v133.HALF * 2
				local v137 = v_u_94
				for v138 = 0, 13 do
					local v139 = v138 / 13
					v118(v139, 0, v139, 1, 1, v_u_52.line, 0.6)
					v118(0, v139, 1, v139, 1, v_u_52.line, 0.6)
				end
				local v140 = (-v133.FENCE_HALF + v133.HALF) / v136
				local v141 = (v133.FENCE_HALF + v133.HALF) / v136
				v118(v140, v140, 0.488, v140, 1, v_u_52.lineStrong, 0.3)
				v118(0.512, v140, v141, v140, 1, v_u_52.lineStrong, 0.3)
				v118(v140, v141, v141, v141, 1, v_u_52.lineStrong, 0.3)
				v118(v140, v140, v140, v141, 1, v_u_52.lineStrong, 0.3)
				v118(v141, v140, v141, v141, 1, v_u_52.lineStrong, 0.3)
				for _, v142 in v133.ROADS do
					if v142[6] == "service" then
						continue
					end
					local v143 = v142[6] == "main" and 3 or 2
					if v142[7] == "x" then
						v118((v142[1] + v133.HALF) / v136, ((v142[2] + v142[4]) / 2 + v133.HALF) / v136, (v142[3] + v133.HALF) / v136, ((v142[2] + v142[4]) / 2 + v133.HALF) / v136, v143, v_u_52.lineStrong, 0.25)
					else
						v118(((v142[1] + v142[3]) / 2 + v133.HALF) / v136, (v142[2] + v133.HALF) / v136, ((v142[1] + v142[3]) / 2 + v133.HALF) / v136, (v142[4] + v133.HALF) / v136, v143, v_u_52.lineStrong, 0.25)
					end
				end
				local v144 = v133.RUNWAY
				v118((v144.x0 + v133.HALF) / v136, (v144.cz + v133.HALF) / v136, (v144.x1 + v133.HALF) / v136, (v144.cz + v133.HALF) / v136, 14, v_u_52.lineStrong, 0.12)
				for _, v145 in v133.TAXIWAYS do
					if v145[5] ~= "x" then
						continue
					end
					v118((v145[1] + v133.HALF) / v136, ((v145[2] + v145[4]) / 2 + v133.HALF) / v136, (v145[3] + v133.HALF) / v136, ((v145[2] + v145[4]) / 2 + v133.HALF) / v136, 6, v_u_52.lineStrong, 0.35)
				end
				for _, v146 in v133.LOTS do
					local v147 = v133.LANDMARKS[v146[1]] ~= nil
					local v148 = (v146[4] - v146[6] / 2 + v133.HALF) / v136
					local v149 = (v146[5] - v146[7] / 2 + v133.HALF) / v136
					local v150 = v147 and 0.4 or 0.62
					local v151 = v_u_42
					local v152 = {
						["o"] = nil,
						["p"] = "BackgroundTransparency",
						["own"] = nil,
						["x"] = nil,
						["o"] = v_u_7.new("Frame", {
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = nil,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = v_u_52.lineStrong,
							["BackgroundTransparency"] = v150,
							["Position"] = UDim2.fromScale(v148, v149),
							["Size"] = UDim2.fromScale(v146[6] / v136, v146[7] / v136)
						}, v137),
						["own"] = v150,
						["x"] = v148 + v146[6] / v136 / 2
					}
					table.insert(v151, v152)
				end
				for _, v153 in v133.TENTS do
					local v154 = v153[3]
					local v155 = v153[4]
					local v156 = v153[5] / 90 + 0.5
					if math.floor(v156) % 2 == 0 then
						local v157 = v154
						v154 = v155
						v155 = v157
					end
					local v158 = v_u_42
					local v159 = {
						["o"] = nil,
						["p"] = "BackgroundTransparency",
						["own"] = 0.5,
						["x"] = nil,
						["o"] = v_u_7.new("Frame", {
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.5,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["BackgroundColor3"] = v_u_52.lineStrong,
							["Position"] = UDim2.fromScale((v153[1] - v155 / 2 + v133.HALF) / v136, (v153[2] - v154 / 2 + v133.HALF) / v136),
							["Size"] = UDim2.fromScale(v155 / v136, v154 / v136)
						}, v137),
						["x"] = (v153[1] + v133.HALF) / v136
					}
					table.insert(v158, v159)
				end
				v_u_94 = v90
			else
				v91:Destroy()
				v91 = nil
			end
		else
			v91:Destroy()
			v91 = nil
		end
	else
		v91:Destroy()
		v91 = nil
	end
	local function v160()
		-- upvalues: (ref) v_u_6
		return v_u_6.lib.AshgroveMapData
	end
	local v161, v162 = pcall(v160)
	if v161 and type(v162) == "table" then
		local v163 = v162.HALF
		if type(v163) == "number" then
			local v164 = v162.LOTS
			if type(v164) == "table" then
				local v165 = v162.ROCKS
				if type(v165) == "table" then
					v_u_94 = v93
					local v166 = v162.HALF * 2
					local v167 = v_u_94
					for v168 = 0, 11 do
						local v169 = v168 / 11
						v118(v169, 0, v169, 1, 1, v_u_52.line, 0.6)
						v118(0, v169, 1, v169, 1, v_u_52.line, 0.6)
					end
					for _, v170 in v162.ROCKS do
						local v171 = v_u_42
						local v172 = {
							["o"] = nil,
							["p"] = "BackgroundTransparency",
							["own"] = 0.8,
							["x"] = nil,
							["o"] = v_u_7.new("Frame", {
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.8,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_52.lineStrong,
								["Position"] = UDim2.fromScale((v170[1] + v162.HALF) / v166, (v170[2] + v162.HALF) / v166),
								["Size"] = UDim2.fromScale((v170[3] - v170[1]) / v166, (v170[4] - v170[2]) / v166)
							}, v167),
							["x"] = ((v170[1] + v170[3]) / 2 + v162.HALF) / v166
						}
						table.insert(v171, v172)
					end
					for _, v173 in v162.ROADS do
						if v173[6] == "track" then
							continue
						end
						local v174 = v173[6] == "main" and 3 or 2
						local v175 = v173[5] == "The Serpentine" and 0.1 or 0.3
						if v173[7] == "x" then
							v118((v173[1] + v162.HALF) / v166, ((v173[2] + v173[4]) / 2 + v162.HALF) / v166, (v173[3] + v162.HALF) / v166, ((v173[2] + v173[4]) / 2 + v162.HALF) / v166, v174, v_u_52.lineStrong, v175)
						else
							v118(((v173[1] + v173[3]) / 2 + v162.HALF) / v166, (v173[2] + v162.HALF) / v166, ((v173[1] + v173[3]) / 2 + v162.HALF) / v166, (v173[4] + v162.HALF) / v166, v174, v_u_52.lineStrong, v175)
						end
					end
					local v176 = v162.TRAM_LINE
					for v177 = 1, #v176 - 1 do
						v118((v176[v177][1] + v162.HALF) / v166, (v176[v177][2] + v162.HALF) / v166, (v176[v177 + 1][1] + v162.HALF) / v166, (v176[v177 + 1][2] + v162.HALF) / v166, 1, v_u_52.accent, 0.45)
					end
					for _, v178 in v162.LOTS do
						local v179 = v162.LANDMARKS[v178[1]] ~= nil
						local v180 = (v178[4] - v178[6] / 2 + v162.HALF) / v166
						local v181 = (v178[5] - v178[7] / 2 + v162.HALF) / v166
						local v182 = v179 and 0.4 or 0.62
						local v183 = v_u_42
						local v184 = {
							["o"] = nil,
							["p"] = "BackgroundTransparency",
							["own"] = nil,
							["x"] = nil,
							["o"] = v_u_7.new("Frame", {
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_52.lineStrong,
								["BackgroundTransparency"] = v182,
								["Position"] = UDim2.fromScale(v180, v181),
								["Size"] = UDim2.fromScale(v178[6] / v166, v178[7] / v166)
							}, v167),
							["own"] = v182,
							["x"] = v180 + v178[6] / v166 / 2
						}
						table.insert(v183, v184)
					end
					v_u_94 = v90
				else
					v93:Destroy()
					v93 = nil
				end
			else
				v93:Destroy()
				v93 = nil
			end
		else
			v93:Destroy()
			v93 = nil
		end
	else
		v93:Destroy()
		v93 = nil
	end
	local function v185()
		-- upvalues: (ref) v_u_6
		return v_u_6.lib.OvertureMapData
	end
	local v186, v_u_187 = pcall(v185)
	if v186 and type(v_u_187) == "table" then
		local v188 = v_u_187.HALF
		if type(v188) == "number" then
			local v189 = v_u_187.LOTS
			if type(v189) == "table" then
				local v190 = v_u_187.WATER
				if type(v190) == "table" then
					v_u_94 = v92
					local v_u_191 = v_u_187.HALF * 2
					local v_u_192 = v_u_94
					for v193 = 0, 7 do
						local v194 = v193 / 7
						v118(v194, 0, v194, 1, 1, v_u_52.line, 0.6)
						v118(0, v194, 1, v194, 1, v_u_52.line, 0.6)
					end
					local function v202(p195, p196, p197, p198, p199) -- name: boxW
						-- upvalues: (ref) v_u_7, (copy) v_u_52, (copy) v_u_187, (copy) v_u_191, (ref) v_u_192, (ref) v_u_42
						local v200 = v_u_42
						local v201 = {
							["o"] = nil,
							["p"] = "BackgroundTransparency",
							["own"] = nil,
							["x"] = nil,
							["o"] = v_u_7.new("Frame", {
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_52.lineStrong,
								["BackgroundTransparency"] = p199,
								["Position"] = UDim2.fromScale((p195 + v_u_187.HALF) / v_u_191, (p196 + v_u_187.HALF) / v_u_191),
								["Size"] = UDim2.fromScale((p197 - p195) / v_u_191, (p198 - p196) / v_u_191)
							}, v_u_192),
							["own"] = p199,
							["x"] = ((p195 + p197) / 2 + v_u_187.HALF) / v_u_191
						}
						table.insert(v200, v201)
					end
					v202(v_u_187.WATER[1], v_u_187.WATER[2], v_u_187.WATER[3], v_u_187.WATER[4], 0.8)
					v202(v_u_187.PLAZA[1], v_u_187.PLAZA[2], v_u_187.PLAZA[3], v_u_187.PLAZA[4], 0.82)
					local v203 = (-v_u_187.RING + v_u_187.HALF) / v_u_191
					local v204 = (v_u_187.RING + v_u_187.HALF) / v_u_191
					local v205 = (v_u_187.SHORE + v_u_187.HALF) / v_u_191
					v118(v203, v203, v204, v203, 1, v_u_52.lineStrong, 0.3)
					v118(v203, v203, v203, v205, 1, v_u_52.lineStrong, 0.3)
					v118(v204, v203, v204, v205, 1, v_u_52.lineStrong, 0.3)
					for _, v206 in v_u_187.ROADS do
						local v207 = v206[6] == "main" and 3 or 2
						local v208 = v206[6] == "main" and 0.15 or 0.3
						if v206[7] == "x" then
							v118((v206[1] + v_u_187.HALF) / v_u_191, ((v206[2] + v206[4]) / 2 + v_u_187.HALF) / v_u_191, (v206[3] + v_u_187.HALF) / v_u_191, ((v206[2] + v206[4]) / 2 + v_u_187.HALF) / v_u_191, v207, v_u_52.lineStrong, v208)
						else
							v118(((v206[1] + v206[3]) / 2 + v_u_187.HALF) / v_u_191, (v206[2] + v_u_187.HALF) / v_u_191, ((v206[1] + v206[3]) / 2 + v_u_187.HALF) / v_u_191, (v206[4] + v_u_187.HALF) / v_u_191, v207, v_u_52.lineStrong, v208)
						end
					end
					for _, v209 in v_u_187.LOTS do
						local v210 = v_u_187.LANDMARKS[v209[1]] ~= nil and 0.4 or 0.62
						local v211 = v_u_42
						local v212 = {
							["o"] = nil,
							["p"] = "BackgroundTransparency",
							["own"] = nil,
							["x"] = nil,
							["o"] = v_u_7.new("Frame", {
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v_u_52.lineStrong,
								["BackgroundTransparency"] = v210,
								["Position"] = UDim2.fromScale((v209[4] - v209[6] / 2 + v_u_187.HALF) / v_u_191, (v209[5] - v209[7] / 2 + v_u_187.HALF) / v_u_191),
								["Size"] = UDim2.fromScale(v209[6] / v_u_191, v209[7] / v_u_191)
							}, v_u_192),
							["own"] = v210,
							["x"] = (v209[4] + v_u_187.HALF) / v_u_191
						}
						table.insert(v211, v212)
					end
					v_u_94 = v90
				else
					v92:Destroy()
					v92 = nil
				end
			else
				v92:Destroy()
				v92 = nil
			end
		else
			v92:Destroy()
			v92 = nil
		end
	else
		v92:Destroy()
		v92 = nil
	end
	local v213 = v_u_7.new("Frame", {
		["Name"] = "DropZone",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.64, 0.7),
		["Size"] = UDim2.fromOffset(28, 28)
	}, v89)
	v_u_7.icon("ping", {
		["parent"] = nil,
		["size"] = 28,
		["color"] = nil,
		["parent"] = v213,
		["color"] = v_u_52.accent
	})
	local v214 = v_u_7.new("Frame", {
		["Name"] = "Pulse",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(28, 28)
	}, v213)
	v_u_7.new("UICorner", {
		["CornerRadius"] = UDim.new(1, 0)
	}, v214)
	local v215 = v_u_7.stroke(v214, v_u_52.accent, 1)
	local v216 = v_u_7.label({
		["parent"] = nil,
		["text"] = "Drop zone",
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v89,
		["color"] = v_u_52.accent,
		["position"] = UDim2.new(0.64, 22, 0.7, -8),
		["size"] = UDim2.fromOffset(120, 14)
	})
	local v217 = v_u_7.label({
		["parent"] = nil,
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v89,
		["color"] = v_u_52.muted,
		["position"] = UDim2.new(0.64, 22, 0.7, 6),
		["size"] = UDim2.fromOffset(140, 14)
	})
	v217.Text = string.format("GRID %02d-%02d", v_u_27:NextInteger(10, 48), v_u_27:NextInteger(10, 48))
	local v218 = {
		["Frame"] = { "BackgroundTransparency" },
		["TextLabel"] = { "BackgroundTransparency", "TextTransparency" },
		["ImageLabel"] = { "BackgroundTransparency", "ImageTransparency" },
		["UIStroke"] = { "Transparency" }
	}
	for _, v219 in {
		v213,
		v216,
		v217,
		table.unpack(v213:GetDescendants())
	} do
		if v219 == v215 then
			continue
		end
		for _, v220 in v218[v219.ClassName] or {} do
			local v221 = v_u_42
			local v222 = {
				["o"] = nil,
				["p"] = nil,
				["own"] = nil,
				["x"] = 0.64,
				["o"] = v219,
				["p"] = v220,
				["own"] = v219[v220]
			}
			table.insert(v221, v222)
		end
	end
	v_u_51(v_u_43)
	local v223, v224 = v_u_7.button({
		["parent"] = nil,
		["name"] = "LeaveQueue",
		["text"] = "Leave queue",
		["kind"] = "secondary",
		["hint"] = "menu",
		["anchor"] = nil,
		["position"] = nil,
		["height"] = nil,
		["onClick"] = nil,
		["parent"] = v55,
		["anchor"] = Vector2.new(1, 1),
		["position"] = UDim2.new(1, -v66, 1, -(v72 + 88)),
		["height"] = v_u_8.touch(40),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_5
			v_u_5.leaveQueue()
		end
	})
	v223.Visible = false
	v_u_20 = {
		["leaveBtn"] = v223,
		["leaveApi"] = v224,
		["card"] = v55,
		["headline"] = v78,
		["map"] = v80,
		["details"] = v81,
		["status"] = v86,
		["sweep"] = v88,
		["tip"] = v85,
		["squad"] = v82,
		["match"] = v83,
		["dot"] = v77,
		["drops"] = v57,
		["art"] = v89,
		["artTown"] = v90,
		["artField"] = v91,
		["artRidge"] = v93,
		["artPlaza"] = v92,
		["dz"] = v213,
		["dzLabel"] = v216,
		["dzRing"] = v214,
		["dzStroke"] = v215,
		["grid"] = v217,
		["mR"] = v66,
		["artR"] = v75
	}
end
local v_u_226 = {}
local v_u_227 = nil
local v_u_228 = ""
local function v_u_271(p229) -- name: applyInfo
	-- upvalues: (copy) v_u_226, (ref) v_u_20, (ref) v_u_7, (ref) v_u_8, (copy) v_u_51
	for v230, v231 in p229 do
		v_u_226[v230] = v231
	end
	if v_u_20 then
		if p229.kind then
			local v232 = v_u_7.setText
			local v233 = v_u_20.headline
			local v234 = p229.kind
			v232(v233, v234 == "return" and "Returning to base" or (v234 == "hideout" and "Entering hideout" or (v234 == "menu" and "Returning to menu" or "Deploying")))
			local v235 = v_u_8.refSize()
			local v236 = p229.kind == "deploy"
			v_u_20.art.Visible = true
			for _, v237 in { v_u_20.dz, v_u_20.dzLabel, v_u_20.grid } do
				if not v237 then
					continue
				end
				v237.Visible = v236
			end
			local v238 = v236 and 0 or 0.22
			if v235.X >= 1350 then
				v_u_20.art.Size = UDim2.fromOffset(520, 520)
				v_u_20.art.Position = UDim2.new(1, -v_u_20.mR, 0.48, 0)
				v_u_51(v238 + 0.15)
			else
				local v239 = v235.Y - 128
				local v240 = v235.X * 0.4
				local v241 = math.min(v239, v240)
				local v242 = math.clamp(v241, 200, 520)
				local v243 = math.floor(v242)
				v_u_20.art.Size = UDim2.fromOffset(v243, v243)
				v_u_20.art.Position = UDim2.new(1, -v_u_20.artR, 0.46, 0)
				v_u_51(v238 + 0.45)
			end
		end
		local v244 = p229.map
		local v245 = p229.kind == "hideout" and "Hideout" or (p229.kind == "menu" and "Stillwater" or v244)
		if v245 then
			v_u_7.setText(v_u_20.map, v245)
		end
		local v246 = v245 or v_u_226.map
		local v247
		if v246 == "Kestrel Field" then
			v247 = v_u_20.artField ~= nil
		else
			v247 = false
		end
		local v248 = (v246 == "???" or v246 == "ASHGROVE") and true or v246 == "Ashgrove"
		if v248 then
			v248 = v_u_20.artRidge ~= nil
		end
		local v249 = v246 == "Overture Plaza"
		if v249 then
			v249 = v_u_20.artPlaza ~= nil
		end
		local v250 = v246 == "The Hollow"
		if v_u_20.artRidge then
			v_u_20.artRidge.Visible = v248
		end
		if v_u_20.artPlaza then
			v_u_20.artPlaza.Visible = v249
		end
		if v_u_20.artField then
			v_u_20.artField.Visible = v247
		end
		if v_u_20.artField or (v_u_20.artRidge or v_u_20.artPlaza) then
			local v251 = v_u_20.artTown
			local v252 = not (v247 or v248)
			if v252 then
				v252 = not v249
				if v252 then
					v252 = not v250
				end
			end
			v251.Visible = v252
			local v253 = v_u_20.dz
			local v254
			if v247 then
				v254 = UDim2.fromScale(0.62, 0.05)
			elseif v248 then
				v254 = UDim2.fromScale(0.5, 0.9)
			elseif v249 then
				v254 = UDim2.fromScale(0.36, 0.05)
			else
				v254 = UDim2.fromScale(0.64, 0.7)
			end
			v253.Position = v254
			local v255 = v_u_20.dzLabel
			local v256
			if v247 then
				v256 = UDim2.new(0.62, 22, 0.05, -8)
			elseif v248 then
				v256 = UDim2.new(0.5, 22, 0.9, -8)
			elseif v249 then
				v256 = UDim2.new(0.36, 22, 0.05, -8)
			else
				v256 = UDim2.new(0.64, 22, 0.7, -8)
			end
			v255.Position = v256
			local v257 = v_u_20.grid
			local v258
			if v247 then
				v258 = UDim2.new(0.62, 22, 0.05, 6)
			elseif v248 then
				v258 = UDim2.new(0.5, 22, 0.9, 6)
			elseif v249 then
				v258 = UDim2.new(0.36, 22, 0.05, 6)
			else
				v258 = UDim2.new(0.64, 22, 0.7, 6)
			end
			v257.Position = v258
		end
		local v259 = {}
		if p229.difficulty then
			local v260 = p229.difficulty
			table.insert(v259, v260)
		end
		if p229.timeOfDay then
			local v261 = p229.timeOfDay
			table.insert(v259, v261)
		end
		if p229.weather then
			local v262 = p229.weather
			table.insert(v259, v262)
		end
		if #v259 > 0 then
			v_u_7.setText(v_u_20.details, table.concat(v259, "   /   "))
		elseif p229.kind and p229.kind ~= "deploy" then
			v_u_7.setText(v_u_20.details, "")
		end
		if p229.squad and #p229.squad > 0 then
			v_u_20.squad.Text = "Squad: " .. table.concat(p229.squad, ", ")
		end
		local v263 = p229.match
		if type(v263) == "string" and p229.match ~= "" then
			v_u_7.setText(v_u_20.match, p229.match)
		end
		local v264 = v_u_20.match.Text ~= ""
		v_u_20.squad.Position = UDim2.fromOffset(0, v264 and 200 or 178)
		local v265 = v_u_20.squad
		if v264 then
			v264 = v_u_8.refSize().Y < 440
		end
		v265.Visible = not v264
		if v_u_226.kind == "deploy" then
			local v266 = v_u_226.map == "The Hollow"
			v_u_7.setText(v_u_20.headline, v266 and "Descending" or "Deploying")
			if v_u_20.dzLabel then
				local v267 = v_u_7.setText
				local v268 = v_u_20.dzLabel
				local v269
				if v266 then
					v269 = "Shaft"
				elseif v_u_226.map == "Kestrel Field" then
					v269 = "Perimeter"
				else
					local v270 = v_u_226.map
					v269 = (v270 == "???" or v270 == "ASHGROVE" or v270 == "Ashgrove") and "Ridge" or (v_u_226.map == "Overture Plaza" and "Perimeter" or "Drop zone")
				end
				v267(v268, v269)
			end
		end
	end
end
local function v_u_273() -- name: raidInfo
	-- upvalues: (copy) v_u_4
	local v272 = v_u_4:FindFirstChild("HushRuntime")
	if v272 then
		v272 = v272:FindFirstChild("Raid")
	end
	return v272 and {
		["map"] = v272:GetAttribute("Map"),
		["difficulty"] = v272:GetAttribute("Difficulty"),
		["timeOfDay"] = v272:GetAttribute("TimeOfDay"),
		["weather"] = v272:GetAttribute("Weather")
	} or nil
end
local v_u_274 = {}
local function v_u_279() -- name: extraHeld
	-- upvalues: (copy) v_u_274
	local v275 = os.clock()
	local v276 = false
	for v277, v278 in v_u_274 do
		if v275 - v278.since > v278.max then
			v_u_274[v277] = nil
		else
			v276 = true
		end
	end
	return v276
end
local function v_u_284() -- name: publish
	-- upvalues: (copy) v_u_9, (ref) v_u_21, (copy) v_u_279
	local v280 = v_u_9
	local v281 = "LoadingVisible"
	local v282 = v_u_21
	if not v282 then
		v282 = true
		local v283 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v283 then
			v283 = v283:FindFirstChild("HushLoading")
		end
		if v283 == nil then
			v282 = v_u_279()
		end
	end
	v280:SetAttribute(v281, v282)
end
function v_u_5.holdExtra(p285, p286, p287) -- name: holdExtra
	-- upvalues: (copy) v_u_274, (copy) v_u_9, (ref) v_u_21, (copy) v_u_279
	if type(p285) == "string" and p285 ~= "" then
		if p286 then
			local v288 = (type(p287) ~= "number" or (p287 ~= p287 or p287 <= 0)) and 20 or math.min(p287, 60)
			v_u_274[p285] = {
				["since"] = os.clock(),
				["max"] = v288
			}
		else
			v_u_274[p285] = nil
		end
		local v289 = v_u_9
		local v290 = "LoadingVisible"
		local v291 = v_u_21
		if not v291 then
			v291 = true
			local v292 = v_u_9:FindFirstChildOfClass("PlayerGui")
			if v292 then
				v292 = v292:FindFirstChild("HushLoading")
			end
			if v292 == nil then
				v291 = v_u_279()
			end
		end
		v289:SetAttribute(v290, v291)
	end
end
local v_u_293 = false
local function v_u_305() -- name: watchTitleCard
	-- upvalues: (ref) v_u_293, (copy) v_u_284, (copy) v_u_9, (ref) v_u_21, (copy) v_u_279
	if v_u_293 then
		return
	else
		local function v_u_302(p294) -- name: hook
			-- upvalues: (ref) v_u_293, (ref) v_u_284, (ref) v_u_9, (ref) v_u_21, (ref) v_u_279
			if not v_u_293 then
				v_u_293 = true
				local function v296(p295) -- name: onChild
					-- upvalues: (ref) v_u_284
					if p295.Name == "HushLoading" then
						task.defer(v_u_284)
					end
				end
				p294.ChildAdded:Connect(v296)
				p294.ChildRemoved:Connect(v296)
				local v297 = v_u_9:FindFirstChildOfClass("PlayerGui")
				if v297 then
					v297 = v297:FindFirstChild("HushLoading")
				end
				if v297 then
					v297.Destroying:Connect(function()
						-- upvalues: (ref) v_u_284
						task.defer(v_u_284)
					end)
				end
				local v298 = v_u_9
				local v299 = "LoadingVisible"
				local v300 = v_u_21
				if not v300 then
					v300 = true
					local v301 = v_u_9:FindFirstChildOfClass("PlayerGui")
					if v301 then
						v301 = v301:FindFirstChild("HushLoading")
					end
					if v301 == nil then
						v300 = v_u_279()
					end
				end
				v298:SetAttribute(v299, v300)
			end
		end
		local v303 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v303 then
			v_u_302(v303)
		else
			task.spawn(function()
				-- upvalues: (ref) v_u_9, (copy) v_u_302
				local v304 = v_u_9:WaitForChild("PlayerGui", 30)
				if v304 then
					v_u_302(v304)
				end
			end)
		end
	end
end
function v_u_5.show(p306) -- name: show
	-- upvalues: (copy) v_u_225, (ref) v_u_20, (ref) v_u_19, (ref) v_u_24, (ref) v_u_25, (ref) v_u_23, (copy) v_u_11, (copy) v_u_27, (ref) v_u_21, (copy) v_u_226, (copy) v_u_271, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (ref) v_u_7, (copy) v_u_9, (copy) v_u_279
	v_u_225()
	if v_u_20 and v_u_19 then
		v_u_24 = v_u_24 + 1
		v_u_25 = os.clock()
		v_u_23 = false
		v_u_20.tip.Text = v_u_11[v_u_27:NextInteger(1, #v_u_11)]
		if not v_u_21 then
			table.clear(v_u_226)
			v_u_20.match.Text = ""
		end
		v_u_271(p306 or {
			["kind"] = "deploy"
		})
		if v_u_226.map == "Kestrel Field" and (v_u_226.kind == nil or v_u_226.kind == "deploy") then
			v_u_20.tip.Text = v_u_12[v_u_27:NextInteger(1, #v_u_12)]
		else
			local v307 = v_u_226.map
			if ((v307 == "???" or v307 == "ASHGROVE") and true or v307 == "Ashgrove") and (v_u_226.kind == nil or v_u_226.kind == "deploy") then
				v_u_20.tip.Text = v_u_13[v_u_27:NextInteger(1, #v_u_13)]
			elseif v_u_226.map == "Overture Plaza" and (v_u_226.kind == nil or v_u_226.kind == "deploy") then
				v_u_20.tip.Text = v_u_14[v_u_27:NextInteger(1, #v_u_14)]
			end
		end
		if not v_u_21 then
			v_u_21 = true
			v_u_19.Enabled = true
			v_u_7.fade(v_u_20.card, 0, 0.35, {
				["from"] = v_u_7.fadeAlpha(v_u_20.card) <= 0 and 1 or nil
			})
			local v308 = p306 and p306.kind or "deploy"
			v_u_7.sound("transit", v308 == "deploy" and "deploy" or "open")
			v_u_7.blur(true, 6)
		end
		local v309 = v_u_9
		local v310 = "LoadingVisible"
		local v311 = v_u_21
		if not v311 then
			v311 = true
			local v312 = v_u_9:FindFirstChildOfClass("PlayerGui")
			if v312 then
				v312 = v312:FindFirstChild("HushLoading")
			end
			if v312 == nil then
				v311 = v_u_279()
			end
		end
		v309:SetAttribute(v310, v311)
	end
end
local function v_u_320(p313) -- name: setQueueButton
	-- upvalues: (ref) v_u_20, (ref) v_u_28, (ref) v_u_29, (ref) v_u_6, (ref) v_u_30, (copy) v_u_5
	if v_u_20 and p313 ~= v_u_28 then
		v_u_28 = p313
		v_u_20.leaveBtn.Visible = p313
		if p313 then
			v_u_29 = (-1 / 0)
			v_u_20.leaveApi.setEnabled(true)
			local v314 = v_u_6.controllers.Input
			if v314 and (v314.bind and not v_u_30) then
				local v315 = v314.bind
				local function v316()
					-- upvalues: (ref) v_u_28, (ref) v_u_5
					if v_u_28 then
						v_u_5.leaveQueue()
					end
				end
				local v317, v318 = pcall(v315, "menu", v316)
				if v317 and type(v318) == "function" then
					v_u_30 = v318
					return
				end
			end
		elseif v_u_30 then
			local v319 = v_u_30
			pcall(v319)
			v_u_30 = nil
		end
	end
end
function v_u_5.leaveQueue() -- name: leaveQueue
	-- upvalues: (copy) v_u_5, (copy) v_u_9, (ref) v_u_29, (ref) v_u_20, (ref) v_u_228, (ref) v_u_7, (ref) v_u_6
	local v321
	if v_u_5._place == "Transit" then
		local v322 = v_u_9
		v321 = type(v322:GetAttribute("QueuePos")) == "number"
	else
		v321 = false
	end
	if not v321 or os.clock() - v_u_29 < 6 then
		return false
	end
	v_u_29 = os.clock()
	if v_u_20 then
		v_u_20.leaveApi.setEnabled(false)
	end
	v_u_228 = "Leaving the queue"
	if v_u_20 then
		v_u_7.setText(v_u_20.status, "Leaving the queue")
	end
	local v323 = v_u_6.net.fire
	local v324, v325 = pcall(v323, "raid.op", {
		["op"] = "leaveQueue"
	})
	if v324 then
		return true
	end
	warn("[Loading] leaveQueue", v325)
	v_u_29 = (-1 / 0)
	if v_u_20 then
		v_u_20.leaveApi.setEnabled(true)
	end
	return false
end
function v_u_5.hide() -- name: hide
	-- upvalues: (ref) v_u_21, (ref) v_u_20, (ref) v_u_28, (ref) v_u_30, (ref) v_u_22, (ref) v_u_24, (ref) v_u_7, (ref) v_u_19, (copy) v_u_9, (copy) v_u_279
	if v_u_21 then
		if v_u_20 and v_u_28 ~= false then
			v_u_28 = false
			v_u_20.leaveBtn.Visible = false
			if v_u_30 then
				local v326 = v_u_30
				pcall(v326)
				v_u_30 = nil
			end
		end
		v_u_21 = false
		v_u_22 = os.clock() + 0.8
		v_u_24 = v_u_24 + 1
		local v_u_327 = v_u_24
		v_u_7.blur(false)
		local function v328() -- name: off
			-- upvalues: (copy) v_u_327, (ref) v_u_24, (ref) v_u_19
			if v_u_327 == v_u_24 and v_u_19 then
				v_u_19.Enabled = false
			end
		end
		if v_u_20 then
			v_u_7.fade(v_u_20.card, 1, 0.6, {
				["style"] = Enum.EasingStyle.Quad,
				["onDone"] = v328
			})
		else
			task.delay(0.62, v328)
		end
		local v329 = v_u_9
		local v330 = "LoadingVisible"
		local v331 = v_u_21
		if not v331 then
			v331 = true
			local v332 = v_u_9:FindFirstChildOfClass("PlayerGui")
			if v332 then
				v332 = v332:FindFirstChild("HushLoading")
			end
			if v332 == nil then
				v331 = v_u_279()
			end
		end
		v329:SetAttribute(v330, v331)
	end
end
function v_u_5.isShowing() -- name: isShowing
	-- upvalues: (ref) v_u_21, (copy) v_u_9
	local v333 = v_u_21
	if not v333 then
		local v334 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v334 then
			v334 = v334:FindFirstChild("HushLoading")
		end
		v333 = v334 ~= nil
	end
	return v333
end
function v_u_5.cardUp() -- name: cardUp
	-- upvalues: (ref) v_u_21, (copy) v_u_9, (ref) v_u_22, (ref) v_u_19
	local v335 = v_u_21
	if not v335 then
		v335 = true
		local v336 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v336 then
			v336 = v336:FindFirstChild("HushLoading")
		end
		if v336 == nil then
			if os.clock() < v_u_22 then
				v335 = true
			elseif v_u_19 == nil then
				v335 = false
			else
				v335 = v_u_19.Enabled
			end
		end
	end
	return v335
end
function v_u_5.setTransitInfo(p337) -- name: setTransitInfo
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_21, (copy) v_u_271
	v_u_16 = p337
	v_u_17 = os.clock()
	if v_u_21 then
		v_u_271(p337)
	end
end
v_u_5._place = "Menu"
local v_u_338 = nil
local v_u_339 = false
function v_u_5._isObserverArrival() -- name: isObserverArrival
	-- upvalues: (ref) v_u_338, (ref) v_u_6
	if v_u_338 == nil then
		local function v340()
			-- upvalues: (ref) v_u_6
			if v_u_6 == nil or v_u_6.session.mode() ~= "Raid" then
				return false
			else
				return v_u_6.shared.ReviewLiveRules.isObserverArrival(game:GetService("TeleportService"):GetLocalPlayerTeleportData())
			end
		end
		local v341, v342 = pcall(v340)
		if v341 then
			v341 = v342 == true
		end
		v_u_338 = v341
	end
	return v_u_338 == true
end
local function v_u_358() -- name: checkObserver
	-- upvalues: (ref) v_u_339, (ref) v_u_21, (copy) v_u_5, (copy) v_u_9, (ref) v_u_338, (ref) v_u_6, (ref) v_u_25
	if v_u_339 or (not v_u_21 or v_u_5._place ~= "Transit") then
		return
	else
		local v_u_343 = v_u_9:GetAttribute("OverwatchTarget")
		if v_u_343 == nil then
			if v_u_338 == nil then
				local function v344()
					-- upvalues: (ref) v_u_6
					if v_u_6 == nil or v_u_6.session.mode() ~= "Raid" then
						return false
					else
						return v_u_6.shared.ReviewLiveRules.isObserverArrival(game:GetService("TeleportService"):GetLocalPlayerTeleportData())
					end
				end
				local v345, v346 = pcall(v344)
				if v345 then
					v345 = v346 == true
				end
				v_u_338 = v345
			end
			if v_u_338 ~= true then
				return
			end
		end
		local function v354()
			-- upvalues: (ref) v_u_6, (ref) v_u_21, (ref) v_u_5, (copy) v_u_343, (ref) v_u_338, (ref) v_u_25
			local v_u_347 = false
			local function v348()
				-- upvalues: (ref) v_u_347, (ref) v_u_6
				v_u_347 = v_u_6.lib.ReviewTools.active() == true
			end
			pcall(v348)
			local v349 = v_u_6.shared.ReviewLiveRules.observerCard
			local v350 = {
				["showing"] = v_u_21,
				["place"] = v_u_5._place,
				["target"] = v_u_343,
				["toolsUp"] = v_u_347
			}
			if v_u_338 == nil then
				local function v351()
					-- upvalues: (ref) v_u_6
					if v_u_6 == nil or v_u_6.session.mode() ~= "Raid" then
						return false
					else
						return v_u_6.shared.ReviewLiveRules.isObserverArrival(game:GetService("TeleportService"):GetLocalPlayerTeleportData())
					end
				end
				local v352, v353 = pcall(v351)
				if v352 then
					v352 = v353 == true
				end
				v_u_338 = v352
			end
			v350.observer = v_u_338 == true
			v350.shownFor = os.clock() - v_u_25
			return v349(v350)
		end
		local v355, v356 = pcall(v354)
		if v355 and v356 ~= nil then
			v_u_339 = true
			if v356 == "cap" then
				warn("[Loading] observer: transit card still up after the target wait, hidden")
			end
			v_u_5.hide()
			local v357 = v_u_9:FindFirstChildOfClass("PlayerGui")
			if v357 then
				v357 = v357:FindFirstChild("HushLoading")
			end
			if v357 then
				v357:SetAttribute("Release", true)
			end
		end
	end
end
v_u_5._checkObserver = v_u_358
local function v_u_378(p_u_359, p360) -- name: onPlace
	-- upvalues: (copy) v_u_5, (ref) v_u_20, (ref) v_u_28, (ref) v_u_30, (ref) v_u_26, (ref) v_u_227, (copy) v_u_273, (ref) v_u_18, (ref) v_u_16, (ref) v_u_17, (ref) v_u_228, (ref) v_u_7, (ref) v_u_25, (ref) v_u_21, (copy) v_u_271, (ref) v_u_6, (copy) v_u_226, (ref) v_u_24, (copy) v_u_10, (copy) v_u_15
	v_u_5._place = p_u_359
	if p_u_359 ~= "Transit" and (v_u_20 and v_u_28 ~= false) then
		v_u_28 = false
		v_u_20.leaveBtn.Visible = false
		if v_u_30 then
			local v361 = v_u_30
			pcall(v361)
			v_u_30 = nil
		end
	end
	if p_u_359 == "Transit" then
		v_u_26 = p360
		local v362 = p360 == "Raid" and "return" or (p360 == "Hideout" and "menu" or "deploy")
		local v363 = {
			["kind"] = v362
		}
		local v364
		if v362 == "return" then
			v364 = v_u_227 or (v_u_273() or {}).map
		else
			v364 = nil
		end
		v363.map = v364
		if v362 == "deploy" and v_u_18 then
			for v365, v366 in v_u_18 do
				v363[v365] = v366
			end
		end
		if v_u_16 and os.clock() - v_u_17 < 20 then
			for v367, v368 in v_u_16 do
				v363[v367] = v368
			end
			if p360 == "Raid" then
				v363.kind = "return"
			end
		end
		v_u_5.show(v363)
		local v369 = v363.kind == "deploy" and "Waiting for the raid server" or "Saving your raid"
		v_u_228 = v369
		if v_u_20 then
			v_u_7.setText(v_u_20.status, v369)
		end
	else
		local v_u_370 = v_u_25
		if v_u_21 then
			if p_u_359 == "Raid" then
				local v371 = v_u_273()
				if v371 then
					v371.kind = "deploy"
					v_u_271(v371)
				end
				local v_u_372 = nil
				local function v373()
					-- upvalues: (ref) v_u_372, (ref) v_u_6, (ref) v_u_226
					v_u_372 = v_u_6.shared.Maps.get(v_u_226.map)
				end
				pcall(v373)
				local v374 = "Loading the " .. (v_u_372 and (v_u_372.noun or "town") or "map")
				v_u_228 = v374
				if v_u_20 then
					v_u_7.setText(v_u_20.status, v374)
				end
			elseif p_u_359 == "Hideout" then
				v_u_227 = nil
				v_u_271({
					["kind"] = "hideout"
				})
				v_u_228 = "Lighting the generator"
				if v_u_20 then
					v_u_7.setText(v_u_20.status, "Lighting the generator")
				end
			elseif p_u_359 == "Menu" then
				if v_u_26 == "Raid" then
					v_u_271({
						["kind"] = "return"
					})
				end
				v_u_227 = nil
				v_u_228 = "Almost there"
				if v_u_20 then
					v_u_7.setText(v_u_20.status, "Almost there")
				end
			end
			local function v_u_375()
				-- upvalues: (ref) v_u_5
				v_u_5.hide()
			end
			local v_u_376 = v_u_24
			task.spawn(function()
				-- upvalues: (ref) v_u_10, (copy) p_u_359, (ref) v_u_15, (copy) v_u_370, (ref) v_u_5, (copy) v_u_376, (ref) v_u_24, (ref) v_u_21, (copy) v_u_375
				local v377 = os.clock() + (v_u_10[p_u_359] or 20)
				while os.clock() < v377 and v_u_370 > (v_u_15[p_u_359] or -1) do
					if v_u_5._place ~= p_u_359 then
						return
					end
					task.wait(0.1)
				end
				if v_u_376 == v_u_24 or not v_u_21 then
					v_u_375()
				end
			end)
		end
	end
end
local function v_u_385() -- name: rebuild
	-- upvalues: (ref) v_u_21, (ref) v_u_28, (ref) v_u_20, (ref) v_u_30, (ref) v_u_19, (copy) v_u_225, (copy) v_u_226, (copy) v_u_271, (ref) v_u_228, (ref) v_u_7, (copy) v_u_320, (copy) v_u_5, (copy) v_u_9
	local v379 = v_u_21
	local v380 = v_u_28
	local v381
	if v_u_20 then
		v381 = v_u_20.tip.Text
	else
		v381 = nil
	end
	if v_u_20 and v_u_28 ~= false then
		v_u_28 = false
		v_u_20.leaveBtn.Visible = false
		if v_u_30 then
			local v382 = v_u_30
			pcall(v382)
			v_u_30 = nil
		end
	end
	if v_u_19 then
		v_u_19:Destroy()
	end
	v_u_19 = nil
	v_u_20 = nil
	v_u_225()
	if v_u_20 and v_u_19 then
		v_u_271((table.clone(v_u_226)))
		if v381 then
			v_u_20.tip.Text = v381
		end
		if v_u_228 ~= "" then
			v_u_7.setText(v_u_20.status, v_u_228)
		end
		if v379 then
			v_u_7.fadeStop(v_u_20.card)
			v_u_19.Enabled = true
			local v383 = v_u_320
			if v380 then
				if v_u_5._place == "Transit" then
					local v384 = v_u_9
					v380 = type(v384:GetAttribute("QueuePos")) == "number"
				else
					v380 = false
				end
			end
			v383(v380)
		end
	end
end
function v_u_5.init(p386) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_9, (copy) v_u_15, (copy) v_u_5, (ref) v_u_228, (ref) v_u_20, (copy) v_u_385, (copy) v_u_2, (ref) v_u_28, (ref) v_u_30, (ref) v_u_21, (ref) v_u_19, (copy) v_u_35
	v_u_6 = p386
	v_u_7 = p386.lib.HushUI
	v_u_7.bind(p386)
	v_u_8 = p386.shared.Theme
	local v387 = v_u_9:FindFirstChildOfClass("PlayerGui")
	if v387 then
		v387 = v387:FindFirstChild("HushLoading")
	end
	if v387 then
		v387:SetAttribute("Adopted", true)
	end
	p386.on("place.ready", function(p388)
		-- upvalues: (ref) v_u_15
		v_u_15[p388] = os.clock()
	end)
	p386.on("transit.info", function(p389)
		-- upvalues: (ref) v_u_5
		if type(p389) == "table" then
			v_u_5.setTransitInfo(p389)
		end
	end)
	p386.command("loading.show", function(p390)
		-- upvalues: (ref) v_u_5, (ref) v_u_228, (ref) v_u_20, (ref) v_u_7
		local v391 = p390[1] or "deploy"
		local v392 = #p390 < 2 and "Stillwater" or table.concat(p390, " ", 2)
		v_u_5.show(v391 == "hideout" and {
			["kind"] = v391
		} or {
			["kind"] = nil,
			["map"] = nil,
			["difficulty"] = "Normal",
			["timeOfDay"] = "Night",
			["weather"] = "Rain",
			["kind"] = v391,
			["map"] = v392
		})
		local v393 = v391 == "deploy" and "Loading the map" or (v391 == "hideout" and "Lighting the generator" or "Saving your raid")
		v_u_228 = v393
		if v_u_20 then
			v_u_7.setText(v_u_20.status, v393)
		end
		return "showing"
	end)
	p386.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_385
		v_u_385()
	end)
	p386.command("loading.leavequeue", function()
		-- upvalues: (ref) v_u_5
		return v_u_5.leaveQueue() and "sent" or "not queued"
	end)
	p386.command("loading.queue", function(p394)
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_2, (ref) v_u_20, (ref) v_u_28, (ref) v_u_30
		if p394[1] == "on" then
			v_u_5._place = "Transit"
			v_u_9:SetAttribute("QueuePos", 3)
			v_u_9:SetAttribute("QueueEta", v_u_2.now() + 95)
			v_u_5.show({
				["kind"] = "deploy",
				["map"] = "Stillwater",
				["difficulty"] = "Normal",
				["timeOfDay"] = "Night",
				["weather"] = "Rain",
				["squad"] = nil,
				["match"] = "Joining a raid with 2 other squads  \194\183  Europe",
				["squad"] = { "Mara", "Doc" }
			})
			return "queued screen on"
		else
			v_u_5._place = "Menu"
			v_u_9:SetAttribute("QueuePos", nil)
			v_u_9:SetAttribute("QueueEta", nil)
			if v_u_20 and v_u_28 ~= false then
				v_u_28 = false
				v_u_20.leaveBtn.Visible = false
				if v_u_30 then
					local v395 = v_u_30
					pcall(v395)
					v_u_30 = nil
				end
			end
			return "queued screen off"
		end
	end)
	p386.command("loading.state", function()
		-- upvalues: (ref) v_u_21, (ref) v_u_5, (ref) v_u_19, (ref) v_u_9
		local v396 = string.format
		local v397 = "showing=%s cardUp=%s enabled=%s visible=%s place=%s"
		local v398 = v_u_21
		local v399 = tostring(v398)
		local v400 = v_u_5.cardUp
		local v401 = tostring(v400())
		local v402
		if v_u_19 == nil then
			v402 = false
		else
			v402 = v_u_19.Enabled
		end
		local v403 = tostring(v402)
		local v404 = v_u_9
		local v405 = tostring(v404:GetAttribute("LoadingVisible"))
		local v406 = v_u_5._place
		return v396(v397, v399, v401, v403, v405, (tostring(v406)))
	end)
	p386.command("loading.hold", function(p407)
		-- upvalues: (ref) v_u_5
		local v408 = v_u_5.holdExtra
		local v409 = p407[1] or ""
		local v410 = p407[2] ~= "off"
		local v411 = p407[3]
		v408(v409, v410, (tonumber(v411)))
		local v412 = p407[1]
		local v413 = tostring(v412)
		local v414 = p407[2] ~= "off"
		return "hold " .. v413 .. " " .. tostring(v414)
	end)
	p386.command("loading.hide", function()
		-- upvalues: (ref) v_u_5, (ref) v_u_9
		v_u_5.hide()
		local v415 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v415 then
			v415 = v415:FindFirstChild("HushLoading")
		end
		if v415 then
			v415:SetAttribute("Release", true)
		end
		return "hidden"
	end)
	p386.command("intro.play", function(p416)
		-- upvalues: (ref) v_u_35
		local v417 = v_u_35()
		if not v417 then
			return "no JoinIntro module"
		end
		if v417.isPlaying() then
			return "already playing"
		end
		if p416 then
			p416 = p416[1]
		end
		if p416 ~= "roblox" and p416 ~= "none" then
			p416 = nil
		end
		task.spawn(v417.play, {
			["force"] = true,
			["avatar"] = nil,
			["avatar"] = p416
		})
		return "playing" .. (not p416 and "" or " (" .. p416 .. ")")
	end)
	p386.command("intro.skip", function()
		-- upvalues: (ref) v_u_35
		local v418 = v_u_35()
		if not (v418 and v418.isPlaying()) then
			return "not playing"
		end
		v418.skip()
		return "skipping"
	end)
end
local function v_u_444(p419) -- name: onPartyState
	-- upvalues: (ref) v_u_18, (ref) v_u_6, (ref) v_u_21, (copy) v_u_226, (copy) v_u_271
	if type(p419) == "table" then
		local v420 = p419.party
		if type(v420) == "table" then
			local v421 = v420.settings
			local v422 = type(v421) == "table" and (v420.settings or {}) or {}
			local v423 = v420.members
			local v424 = {}
			for _, v425 in type(v423) == "table" and (v420.members or {}) or {} do
				if type(v425) ~= "table" then
					continue
				end
				local v426 = v425.displayName or (v425.name or "?")
				local v427 = tostring(v426)
				table.insert(v424, v427)
			end
			local v428 = nil
			local v429 = v420.deploying
			if type(v429) == "table" then
				local v430 = v429.match
				if type(v430) == "table" then
					local function v431()
						-- upvalues: (ref) v_u_6
						return v_u_6.lib.MenuSearch
					end
					local v432, v433 = pcall(v431)
					if v432 and type(v433) == "table" then
						local v434 = v433.matchLine
						local v435 = v429.match
						local v436
						v436, v428 = pcall(v434, v435)
						if not v436 or type(v428) ~= "string" then
							v428 = nil
						end
					end
				end
			end
			local v437 = {}
			local v438 = v422.map
			local v439
			if type(v438) == "string" then
				v439 = v422.map
			else
				v439 = nil
			end
			v437.map = v439
			local v440 = v422.difficulty
			local v441
			if type(v440) == "string" then
				v441 = v422.difficulty
			else
				v441 = nil
			end
			v437.difficulty = v441
			local v442 = v422.timeOfDay
			local v443
			if type(v442) == "string" then
				v443 = v422.timeOfDay
			else
				v443 = nil
			end
			v437.timeOfDay = v443
			if #v424 <= 1 then
				v424 = nil
			end
			v437.squad = v424
			v437.match = v428
			v_u_18 = v437
			if v428 and (v_u_21 and v_u_226.kind == "deploy") then
				v_u_271({
					["match"] = v428
				})
			end
		else
			v_u_18 = nil
		end
	else
		return
	end
end
function v_u_5.start() -- name: start
	-- upvalues: (copy) v_u_225, (ref) v_u_6, (copy) v_u_444, (copy) v_u_9, (copy) v_u_10, (copy) v_u_15, (ref) v_u_21, (copy) v_u_284, (copy) v_u_5, (copy) v_u_378, (copy) v_u_305, (copy) v_u_279
	v_u_225()
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_444
		v_u_6.net.listen("party.state", v_u_444)
	end)
	local v_u_445 = os.clock()
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_9, (copy) v_u_445, (ref) v_u_10, (ref) v_u_15, (ref) v_u_21, (ref) v_u_284
		local v446 = v_u_445 + (v_u_10[v_u_6.session.place(v_u_9)] or 20) + 6
		while os.clock() < v446 or v_u_9:GetAttribute("ProfileStatus") == "loading" and os.clock() - v_u_445 < 220 do
			local v447 = v_u_6.session.place(v_u_9)
			if v447 ~= "Transit" and v_u_15[v447] or v447 == "Transit" and v_u_21 then
				break
			end
			task.wait(0.1)
		end
		local v448 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v448 then
			v448 = v448:FindFirstChild("HushLoading")
		end
		if v448 then
			v448:SetAttribute("Release", true)
		end
		task.delay(1.6, v_u_284)
	end)
	v_u_6.session.onPlaceChanged(function(p449, p450)
		-- upvalues: (ref) v_u_5, (ref) v_u_378
		if p449 == p450 then
			v_u_5._place = p449
			if p449 == "Transit" then
				v_u_378(p449, "Menu")
			end
		else
			v_u_378(p449, p450)
		end
	end)
	v_u_305()
	local v451 = v_u_9
	local v452 = "LoadingVisible"
	local v453 = v_u_21
	if not v453 then
		v453 = true
		local v454 = v_u_9:FindFirstChildOfClass("PlayerGui")
		if v454 then
			v454 = v454:FindFirstChild("HushLoading")
		end
		if v454 == nil then
			v453 = v_u_279()
		end
	end
	v451:SetAttribute(v452, v453)
end
local v_u_455 = 0
local v_u_456 = 0
local v_u_457 = 0
function v_u_5.step(p458) -- name: step
	-- upvalues: (ref) v_u_457, (copy) v_u_9, (ref) v_u_21, (copy) v_u_279, (copy) v_u_358, (ref) v_u_19, (ref) v_u_22, (ref) v_u_23, (copy) v_u_5, (copy) v_u_15, (ref) v_u_25, (ref) v_u_20, (ref) v_u_455, (copy) v_u_27, (ref) v_u_43, (copy) v_u_41, (ref) v_u_456, (copy) v_u_2, (ref) v_u_29, (ref) v_u_7, (ref) v_u_228, (ref) v_u_28, (copy) v_u_320, (ref) v_u_338, (ref) v_u_6, (copy) v_u_226, (copy) v_u_273, (ref) v_u_227, (copy) v_u_271
	v_u_457 = v_u_457 + p458
	if v_u_457 >= 0.5 then
		v_u_457 = 0
		local v459 = v_u_9:GetAttribute("LoadingVisible")
		local v460 = v_u_21
		if not v460 then
			v460 = true
			local v461 = v_u_9:FindFirstChildOfClass("PlayerGui")
			if v461 then
				v461 = v461:FindFirstChild("HushLoading")
			end
			if v461 == nil then
				v460 = v_u_279()
			end
		end
		if v459 ~= v460 then
			local v462 = v_u_9
			local v463 = "LoadingVisible"
			local v464 = v_u_21
			if not v464 then
				v464 = true
				local v465 = v_u_9:FindFirstChildOfClass("PlayerGui")
				if v465 then
					v465 = v465:FindFirstChild("HushLoading")
				end
				if v465 == nil then
					v464 = v_u_279()
				end
			end
			v462:SetAttribute(v463, v464)
		end
		v_u_358()
	end
	if v_u_19 and (v_u_19.Enabled and (not v_u_21 and v_u_22 < os.clock())) then
		v_u_19.Enabled = false
		warn("[Loading] transit card was enabled without a show, switched off (stale restore)")
	end
	if v_u_21 and (not v_u_23 and (v_u_5._place == "Raid" and v_u_9:GetAttribute("RaidClientReady") == true)) then
		local v466 = v_u_15.Raid
		if v466 and (v_u_25 <= v466 and os.clock() - v466 > 8) then
			v_u_23 = true
			warn("[Loading] watchdog: transit card still up 8 s after place.ready (Raid), hidden")
			v_u_5.hide()
		end
	end
	if not (v_u_21 and v_u_20) then
		return
	end
	v_u_455 = v_u_455 + p458
	for _, v467 in v_u_20.drops do
		v467.y = v467.y + p458 * v467.v * 0.9
		v467.x = v467.x + p458 * v467.v * 0.19
		if v467.y > 1.2 then
			v467.y = -0.2
			v467.x = v_u_27:NextNumber(-0.2, 1)
		end
		v467.f.Position = UDim2.fromScale(v467.x, v467.y)
	end
	local v468 = v_u_455 % 1.6 / 1.6
	v_u_20.sweep.Position = UDim2.fromScale(v468 * 1.25 + -0.25, 0)
	local v469 = v_u_20.dot
	local v470 = v_u_455 * 4
	v469.BackgroundTransparency = 0.5 - math.cos(v470) * 0.5
	if v_u_20.art.Visible then
		local v471 = v_u_455 % 1.8 / 1.8
		local v472 = v471 * 56 + 28
		v_u_20.dzRing.Size = UDim2.fromOffset(v472, v472)
		local v473 = v_u_20.dzStroke
		local v474 = v_u_43
		local v475 = v_u_41(0.64)
		v473.Transparency = 1 - (1 - v471) * (1 - v475) * (1 - v474)
	end
	v_u_456 = v_u_456 + p458
	if v_u_456 < 0.25 then
		return
	end
	v_u_456 = 0
	if v_u_5._place == "Transit" then
		local v476 = v_u_9:GetAttribute("QueuePos")
		local v477 = v_u_9:GetAttribute("QueueEta")
		if type(v476) == "number" then
			local v478
			if type(v477) == "number" then
				local v479 = v477 - v_u_2.now()
				v478 = math.max(0, v479)
			else
				v478 = 0
			end
			if os.clock() - v_u_29 >= 6 then
				local v480 = string.format("In queue  \194\183  position %d  \194\183  next raid in %s", v476, v_u_7.clock(v478))
				v_u_228 = v480
				if v_u_20 then
					v_u_7.setText(v_u_20.status, v480)
				end
				if v_u_28 and v_u_20 then
					v_u_20.leaveApi.setEnabled(true)
				end
			end
		end
	end
	local v481 = v_u_320
	local v482
	if v_u_5._place == "Transit" then
		local v483 = v_u_9
		v482 = type(v483:GetAttribute("QueuePos")) == "number"
	else
		v482 = false
	end
	v481(v482)
	local v484 = v_u_9:GetAttribute("HuntWaitNeed")
	local v485
	if v_u_5._place == "Transit" and (type(v484) == "number" and v484 > 0) then
		local v486 = v_u_9:GetAttribute("HuntWaitHave")
		local v487 = string.format("Waiting for players  %d of %d", type(v486) ~= "number" and 0 or v486, v484)
		v_u_228 = v487
		if v_u_20 then
			v_u_7.setText(v_u_20.status, v487)
		end
		if v_u_5._place == "Raid" then
			v485 = v_u_273()
			if v485 and v485.map then
				v_u_227 = v485.map
				if v_u_226.kind == "deploy" then
					v_u_271(v485)
				end
			end
		end
	else
		if v_u_5._place == "Transit" then
			if v_u_338 == nil then
				local function v488()
					-- upvalues: (ref) v_u_6
					if v_u_6 == nil or v_u_6.session.mode() ~= "Raid" then
						return false
					else
						return v_u_6.shared.ReviewLiveRules.isObserverArrival(game:GetService("TeleportService"):GetLocalPlayerTeleportData())
					end
				end
				local v489, v490 = pcall(v488)
				if v489 then
					v489 = v490 == true
				end
				v_u_338 = v489
			end
			if v_u_338 == true then
				v_u_228 = "Waiting for the watched player"
				if v_u_20 then
					v_u_7.setText(v_u_20.status, "Waiting for the watched player")
				end
				if v_u_5._place == "Raid" then
					v485 = v_u_273()
					if v485 and v485.map then
						v_u_227 = v485.map
						if v_u_226.kind == "deploy" then
							v_u_271(v485)
						end
					end
				end
				return
			end
		end
		if v_u_5._place == "Transit" then
			local v491 = v_u_9
			if type(v491:GetAttribute("QueuePos")) ~= "number" then
				local function v493()
					-- upvalues: (ref) v_u_6, (ref) v_u_226, (ref) v_u_25, (ref) v_u_228, (ref) v_u_20, (ref) v_u_7
					local v492 = v_u_6.lib.MenuWhy.deployWait(v_u_226.kind, os.clock() - v_u_25)
					if v492 then
						v_u_228 = v492
						if v_u_20 then
							v_u_7.setText(v_u_20.status, v492)
						end
					end
				end
				pcall(v493)
			end
		end
		if v_u_5._place == "Raid" then
			v485 = v_u_273()
			if v485 and v485.map then
				v_u_227 = v485.map
				if v_u_226.kind == "deploy" then
					v_u_271(v485)
				end
			end
		end
	end
end
return v_u_5