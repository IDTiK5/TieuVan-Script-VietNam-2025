-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MailDeliveries

local v_u_1 = game:GetService("RunService")
local v_u_13 = {
	["header"] = function(p2, p3, p4, p5) -- name: header
		local v6 = p2.Kit.section(p2.list, p3, p4, p5)
		v6.Name = "Section_" .. string.lower((string.gsub(p3, "%s+", "")))
		v6.Size = UDim2.new(1, -8, 0, 26)
		return v6
	end,
	["notice"] = function(p7, p8, p9) -- name: notice
		local v10 = p7.UI
		local v11 = p7.C
		local v12 = v10.new("Frame", {
			["Name"] = "Notice",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = v11.raised,
			["Size"] = UDim2.new(1, -8, 0, 36),
			["LayoutOrder"] = p9
		}, p7.list)
		v10.stroke(v12, v11.line)
		v10.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v11.muted,
			["Size"] = UDim2.new(0, 3, 1, 0)
		}, v12)
		v10.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["track"] = false,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v12,
			["text"] = p8,
			["color"] = v11.text2,
			["position"] = UDim2.fromOffset(14, 0),
			["size"] = UDim2.new(1, -28, 1, 0)
		})
		return v12
	end
}
local function v_u_35(p14, p15, p16) -- name: drawTiles
	local v17 = p14.UI
	local v18 = p14.C
	local v19 = p14.Kit
	local v20 = 14
	if #p16.items ~= 1 then
		for _, v21 in p16.tiles do
			local v22 = v19.itemCell
			local v23 = v21.id
			local v24 = {
				["size"] = 46,
				["w"] = 1,
				["h"] = 1,
				["wish"] = false,
				["count"] = nil
			}
			local v25
			if v21.n > 1 then
				v25 = v21.n
			else
				v25 = nil
			end
			v24.count = v25
			local v26 = v22(p15, v23, v24)
			v26.Position = UDim2.fromOffset(v20, 17)
			if p14.Theme.isPhone() or p14.Theme.uiScale() < 0.8 then
				local v27 = v26:FindFirstChild("Short")
				if v27 and v27:IsA("GuiObject") then
					v27.Visible = false
				end
			end
			v20 = v20 + 50
		end
		local v28 = v20 - 4
		if p16.more > 0 then
			local v29 = v28 + 8
			v17.label({
				["parent"] = nil,
				["name"] = "More",
				["text"] = nil,
				["style"] = "bodyStrong",
				["textSize"] = 15,
				["color"] = nil,
				["track"] = false,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["parent"] = p15,
				["text"] = ("+%d"):format(p16.more),
				["color"] = v18.text,
				["position"] = UDim2.fromOffset(v29, 22),
				["size"] = UDim2.fromOffset(40, 18)
			})
			v17.label({
				["parent"] = nil,
				["name"] = "MoreWord",
				["text"] = "more",
				["style"] = "micro",
				["color"] = nil,
				["track"] = false,
				["align"] = "center",
				["position"] = nil,
				["size"] = nil,
				["parent"] = p15,
				["color"] = v18.text2,
				["position"] = UDim2.fromOffset(v29, 40),
				["size"] = UDim2.fromOffset(40, 14)
			})
			v28 = v29 + 40
		end
		return v28 + 14
	end
	local v30 = p16.items[1]
	local v31 = v19.itemCell
	local v32 = v30.id
	local v33 = {
		["size"] = 64,
		["w"] = 1.25,
		["h"] = 1,
		["wish"] = false,
		["count"] = nil
	}
	local v34
	if v30.n > 1 then
		v34 = v30.n
	else
		v34 = nil
	end
	v33.count = v34
	v31(p15, v32, v33).Position = UDim2.fromOffset(v20, 8)
	return v20 + 80 + 14
end
local function v_u_63(p_u_36, p_u_37, p38) -- name: buildRow
	-- upvalues: (copy) v_u_35, (copy) v_u_1
	local v_u_39 = p_u_36.UI
	local v40 = p_u_36.Theme
	local v41 = p_u_36.C
	local v_u_42 = v_u_39.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Mail_" .. p_u_37.id,
		["BackgroundColor3"] = v41.raised,
		["Size"] = UDim2.new(1, -8, 0, 80),
		["LayoutOrder"] = p38
	}, p_u_36.list)
	local v43 = v_u_39.stroke(v_u_42, v41.line)
	local v44 = v_u_39.new("Frame", {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v41.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v_u_42)
	local v45 = v_u_35(p_u_36, v_u_42, p_u_37)
	local v46 = -(v45 + 144 + 14 + 10)
	v_u_39.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = nil,
		["style"] = "bodyStrong",
		["textSize"] = 16,
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_42,
		["text"] = p_u_37.title,
		["position"] = UDim2.fromOffset(v45, 8),
		["size"] = UDim2.new(1, v46, 0, 22)
	}).TextTruncate = Enum.TextTruncate.AtEnd
	local v47 = v_u_39.new("Frame", {
		["Name"] = "Meta",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["Size"] = UDim2.new(1, v46, 0, 18),
		["Position"] = UDim2.fromOffset(v45, 31)
	}, v_u_42)
	v_u_39.layout(v47, "h", 8)
	v_u_39.badge(p_u_37.chip, p_u_37.src == "bm" and "warn" or "info", {
		["parent"] = nil,
		["name"] = "Chip",
		["height"] = 18,
		["order"] = 1,
		["parent"] = v47
	})
	if #p_u_37.items > 1 then
		v_u_39.label({
			["parent"] = nil,
			["name"] = "Count",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["track"] = false,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["parent"] = v47,
			["text"] = ("%d items"):format(#p_u_37.items),
			["color"] = v41.text2,
			["size"] = UDim2.fromOffset(0, 18)
		})
	end
	local v48 = v_u_39.new("Frame", {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["BackgroundColor3"] = v41.muted,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromOffset(v45, 61),
		["Size"] = UDim2.fromOffset(6, 6)
	}, v_u_42)
	local v49 = v_u_39.label({
		["parent"] = nil,
		["name"] = "Status",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_42,
		["color"] = v41.text2,
		["position"] = UDim2.fromOffset(v45 + 14, 52),
		["size"] = UDim2.new(1, v46 - 14, 0, 18)
	})
	local v_u_50 = p_u_37.id
	local v51, v52 = v_u_39.button({
		["parent"] = nil,
		["name"] = "ToStash",
		["text"] = "To stash",
		["kind"] = "primary",
		["width"] = 144,
		["maxTextWidth"] = 108,
		["height"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_42,
		["height"] = v40.touch(40),
		["position"] = UDim2.new(1, -14, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) p_u_36, (copy) v_u_50
			p_u_36.claim(v_u_50)
		end
	})
	local v_u_53 = v52.label
	local v54 = v52._visuals
	local v55
	if type(v54) == "table" then
		v55 = table.find(v54, v_u_53)
	else
		v55 = nil
	end
	if v55 then
		table.remove(v54, v55)
	end
	local v_u_56 = {
		["frame"] = nil,
		["edge"] = nil,
		["stroke"] = nil,
		["dot"] = nil,
		["status"] = nil,
		["btn"] = nil,
		["api"] = nil,
		["lbl"] = nil,
		["btnText"] = "To stash",
		["kind"] = "primary",
		["enabled"] = true,
		["delivery"] = true,
		["model"] = nil,
		["frame"] = v_u_42,
		["edge"] = v44,
		["stroke"] = v43,
		["dot"] = v48,
		["status"] = v49,
		["btn"] = v51,
		["api"] = v52,
		["lbl"] = v_u_53,
		["model"] = p_u_37
	}
	p_u_36.rows[v_u_50] = v_u_56
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (copy) v_u_53, (copy) p_u_36, (copy) v_u_56
		v_u_1.Heartbeat:Wait()
		v_u_1.Heartbeat:Wait()
		if v_u_53.Parent and p_u_36.alive then
			local v57 = v_u_53
			local v58
			if v_u_56.kind == "primary" then
				v58 = p_u_36.C.ink
			else
				v58 = p_u_36.C.text2
			end
			v57.TextColor3 = v58
		end
	end)
	pcall(function()
		-- upvalues: (copy) p_u_36, (copy) v_u_39, (copy) v_u_42, (copy) p_u_37
		local v_u_59 = p_u_36.MR
		v_u_39.tooltip(v_u_42, function()
			-- upvalues: (copy) v_u_59, (ref) p_u_37
			local v60 = not v_u_59 and {} or v_u_59.tipLines(p_u_37)
			local v61 = {
				["title"] = p_u_37.title
			}
			local v62
			if #v60 > 0 then
				v62 = table.concat(v60, "\n")
			else
				v62 = p_u_37.chip
			end
			v61.body = v62
			return v61
		end)
	end)
	return v51
end
function v_u_13.build(p64, p65, p66, p67) -- name: build
	-- upvalues: (copy) v_u_13, (copy) v_u_63
	if p67 ~= true then
		p66 = p66 + 1
		local v68 = #p65 == 1 and "1 WAITING" or ("%d WAITING"):format(#p65)
		v_u_13.header(p64, p64.MR.TEXT.sectionDeliveries, p66, v68)
	end
	for _, v69 in p65 do
		p66 = p66 + 1
		local v70 = v_u_63(p64, v69, p66)
		if p64.firstBtn then
			continue
		end
		p64.firstBtn = v70
	end
	return p66
end
function v_u_13.paint(p71, p72, p73) -- name: paint
	local v74 = p71.C
	local v75 = p71.MR
	if v75 and p72 then
		local v76 = p71.busy ~= nil
		local v77 = false
		for _, v78 in p72.deliveries do
			local v79 = p71.rows[v78.id]
			if not (v79 and v79.delivery) then
				continue
			end
			local v80 = p71.notes[v78.id]
			if v80 and v80.untilAt < p73 then
				p71.notes[v78.id] = nil
				v80 = nil
			end
			local v81 = v78.text
			local v82 = v78.level
			local v83
			if v82 == "warn" then
				v83 = v74.danger
			elseif v82 == "gone" then
				v83 = v74.muted
			elseif v82 == "none" then
				v83 = v74.text2
			else
				v83 = v74.text
			end
			if v80 then
				v81 = v80.text
				v83 = v74.danger
			end
			if v79.status.Text ~= v81 then
				v79.status.Text = v81
			end
			v79.status.TextColor3 = v83
			local v84 = v79.dot
			local v85
			if v80 then
				v85 = v74.danger
			elseif v82 == "warn" then
				v85 = v74.danger
			elseif v82 == "gone" then
				v85 = v74.muted
			else
				v85 = v74.success
			end
			v84.BackgroundColor3 = v85
			local v86 = v79.stroke
			local v87
			if v80 then
				v87 = v74.danger
			else
				v87 = v74.line
			end
			v86.Color = v87
			v79.edge.Visible = not v78.expired
			local v88
			if v78.expired then
				v88 = v75.TEXT.expired
			elseif p71.busy == v78.id then
				v88 = v75.TEXT.moving
			else
				v88 = v75.TEXT.toStash
			end
			if v79.btnText ~= v88 then
				v79.btnText = v88
				v79.api.setText(v88)
			end
			local v89 = v78.expired and "secondary" or "primary"
			if v79.kind ~= v89 then
				v79.kind = v89
				v79.api.setKind(v89)
				local v90 = v79.lbl
				local v91
				if v89 == "primary" then
					v91 = v74.ink
				else
					v91 = v74.text2
				end
				v90.TextColor3 = v91
			end
			local v92 = not v78.expired
			if v92 then
				v92 = not v76
			end
			if v79.enabled ~= v92 then
				v79.enabled = v92
				v79.api.setEnabled(v92)
			end
			if not v78.expired then
				continue
			end
			v77 = true
		end
		if v77 then
			p71.expiredSince = p71.expiredSince or p73
			local v93 = p71.expiredTries or 0
			local v94 = 4 * 2 ^ v93
			local v95 = math.min(30, v94)
			if p73 - p71.expiredSince >= 1 and v95 <= p73 - (p71.expiredLookAt or -1000000000) then
				p71.expiredLookAt = p73
				p71.expiredTries = v93 + 1
				p71.Rail.fetch(p71.mc, "mail", {
					["force"] = true
				})
				return
			end
		else
			p71.expiredSince = nil
			p71.expiredTries = nil
		end
	end
end
return v_u_13