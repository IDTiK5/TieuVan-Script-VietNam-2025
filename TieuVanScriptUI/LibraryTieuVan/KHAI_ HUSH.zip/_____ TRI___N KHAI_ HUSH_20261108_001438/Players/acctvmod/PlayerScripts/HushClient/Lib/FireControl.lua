-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FireControl

local v_u_23 = {
	["MODES"] = { "ring", "both", "button" },
	["CHOICES"] = {
		"auto",
		"ring",
		"both",
		"button"
	},
	["TEXT"] = {
		["auto"] = "Auto",
		["ring"] = "Ring only",
		["both"] = "Ring and button",
		["button"] = "Button only"
	},
	["normalize"] = function(p1) -- name: normalize
		return p1 ~= "both" and p1 ~= "button" and "ring" or p1
	end,
	["choice"] = function(p2) -- name: choice
		return p2 ~= "ring" and (p2 ~= "both" and p2 ~= "button") and "auto" or p2
	end,
	["effective"] = function(p3, p4) -- name: effective
		-- upvalues: (copy) v_u_23
		local v5 = v_u_23.choice(p3)
		return v5 == "auto" and (p4 == true and "button" or "ring") or v5
	end,
	["ringOn"] = function(p6) -- name: ringOn
		-- upvalues: (copy) v_u_23
		return v_u_23.normalize(p6) ~= "button"
	end,
	["buttonOn"] = function(p7) -- name: buttonOn
		-- upvalues: (copy) v_u_23
		return v_u_23.normalize(p7) ~= "ring"
	end,
	["plateText"] = function(p8) -- name: plateText
		-- upvalues: (copy) v_u_23
		local v9 = v_u_23.normalize(p8)
		return v9 == "ring" and "PUSH INTO THE RING TO FIRE" or (v9 == "both" and "RING OR FIRE BUTTON FIRES" or "")
	end,
	["inputHint"] = function(p10) -- name: inputHint
		-- upvalues: (copy) v_u_23
		local v11 = v_u_23.normalize(p10)
		return v11 == "button" and "Fire button" or (v11 == "both" and "Ring or button" or "Outer ring")
	end,
	["buttonEvents"] = function(p12, p13) -- name: buttonEvents
		return p12 and (p13 and {} or { true, false }) or { p13 }
	end,
	["holder"] = function(p_u_14) -- name: holder
		local v_u_15 = {}
		local v_u_16 = false
		return {
			["set"] = function(p17, p18) -- name: set
				-- upvalues: (copy) v_u_15, (ref) v_u_16, (copy) p_u_14
				local v19 = p18 == true
				if v_u_15[p17] == true == v19 then
					return false
				end
				v_u_15[p17] = v19 and true or nil
				for _, v20 in v_u_15 do
					if not v20 then
						continue
					end
					v21 = true
				end
				local v21 = false
				if v21 ~= v_u_16 then
					v_u_16 = v21
					p_u_14(v21)
				end
				return true
			end,
			["held"] = function() -- name: held
				-- upvalues: (ref) v_u_16
				return v_u_16
			end,
			["has"] = function(p22) -- name: has
				-- upvalues: (copy) v_u_15
				return v_u_15[p22] == true
			end,
			["clear"] = function() -- name: clear
				-- upvalues: (copy) v_u_15, (ref) v_u_16, (copy) p_u_14
				table.clear(v_u_15)
				if v_u_16 then
					v_u_16 = false
					p_u_14(false)
				end
			end
		}
	end
}
return v_u_23