-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPassMissions

return {
	["new"] = function(p_u_1, p_u_2, p_u_3) -- name: new
		local v_u_4 = p_u_1.ui
		local v_u_5 = p_u_1.theme
		local v_u_6 = v_u_5.color
		local v_u_7 = p_u_1.kit
		local v_u_8 = p_u_3.R
		local v_u_9 = p_u_3.L
		local v_u_10 = {}
		local v_u_11 = {}
		local v_u_12 = 0
		local v_u_13 = true
		local function v_u_18(p14, p15, p16) -- name: text
			-- upvalues: (copy) v_u_4
			p16.parent = p14
			p16.position = UDim2.fromOffset(p15.x, p15.y)
			p16.size = UDim2.fromOffset(p15.w, p15.h)
			p16.track = false
			local v17 = v_u_4.label(p16)
			if not p16.wrap then
				v17.TextTruncate = Enum.TextTruncate.AtEnd
			end
			return v17
		end
		local function v_u_33(p19, p20, p21, p22, p23) -- name: iconBox
			-- upvalues: (copy) v_u_4, (copy) v_u_6
			local v24 = v_u_4.new
			local v25 = "Frame"
			local v26 = {
				["Name"] = "IconBox",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0
			}
			local v27
			if p23 then
				v27 = v_u_6.success
			else
				v27 = v_u_6.accentDeep
			end
			v26.BackgroundColor3 = v27
			v26.BackgroundTransparency = p23 and 0.82 or 0.1
			local v28 = v24(v25, v26, p19)
			v28.Position = UDim2.fromOffset(p20.x, p20.y)
			v28.Size = UDim2.fromOffset(p20.w, p20.h)
			v_u_4.stroke(v28, p22, 1, 0.5)
			local v29 = v_u_4.icon
			local v30 = {
				["parent"] = v28
			}
			local v31 = p20.w * 0.56
			v30.size = math.floor(v31)
			v30.color = p22
			local v32 = v29(p21, v30)
			v32.AnchorPoint = Vector2.new(0.5, 0.5)
			v32.Position = UDim2.fromScale(0.5, 0.5)
			return v28
		end
		local function v_u_43(p34, p35, p36) -- name: sectionHeader
			-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_4, (ref) v_u_12, (copy) p_u_2, (copy) v_u_18, (copy) v_u_6, (copy) v_u_11
			local v37 = v_u_8.sectionLayout(p36, v_u_9.sectionH)
			local v38 = v_u_4.new
			local v39 = {
				["Name"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Name"] = "Sec_" .. p34,
				["Size"] = UDim2.fromOffset(p36, v37.h)
			}
			v_u_12 = v_u_12 + 1
			v39.LayoutOrder = v_u_12
			local v40 = v38("Frame", v39, p_u_2)
			v_u_18(v40, v37.title, {
				["name"] = "Title",
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["text"] = p34,
				["color"] = v_u_6.accent
			})
			local v41 = v_u_18(v40, v37.timer, {
				["name"] = "Timer",
				["text"] = "",
				["style"] = "monoS",
				["textSize"] = 12,
				["color"] = nil,
				["align"] = "right",
				["color"] = v_u_6.text2
			})
			if p35 then
				local v42 = v_u_11
				table.insert(v42, {
					["label"] = v41,
					["key"] = p35,
					["fn"] = function(_) -- name: fn
						return ""
					end
				})
			end
		end
		local function v_u_52(p44, p45) -- name: emptyCard
			-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_4, (copy) v_u_6, (ref) v_u_12, (copy) p_u_2, (copy) v_u_18, (copy) v_u_11
			local v46 = v_u_8.emptyLayout(p44, v_u_9.emptyH)
			local v47 = v_u_4.new
			local v48 = {
				["Name"] = "Empty",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.6,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_6.raised,
				["Size"] = UDim2.fromOffset(p44, v46.h)
			}
			v_u_12 = v_u_12 + 1
			v48.LayoutOrder = v_u_12
			local v49 = v47("Frame", v48, p_u_2)
			v_u_4.stroke(v49, v_u_6.line, 1, 0.5)
			v_u_4.icon("clock", {
				["parent"] = v49,
				["size"] = v46.icon.w,
				["color"] = v_u_6.muted
			}).Position = UDim2.fromOffset(v46.icon.x, v46.icon.y)
			local v50 = v_u_11
			local v51 = {
				["label"] = v_u_18(v49, v46.text, {
					["name"] = "Line",
					["text"] = nil,
					["style"] = "small",
					["textSize"] = 13,
					["color"] = nil,
					["wrap"] = true,
					["valign"] = "center",
					["text"] = p45(0),
					["color"] = v_u_6.text2
				}),
				["fn"] = p45
			}
			table.insert(v50, v51)
		end
		local function v_u_89(p53, p54, p55, p56, p57) -- name: missionCard
			-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_6, (copy) v_u_33, (copy) v_u_18
			local v58 = v_u_8.missionLayout(p55, p56)
			local v59 = v_u_4.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["ClipsDescendants"] = true,
				["Name"] = "M_" .. p54.id,
				["BackgroundColor3"] = v_u_6.raised,
				["LayoutOrder"] = p57
			}, p53)
			local v60 = v_u_4.stroke
			local v61
			if p54.done then
				v61 = v_u_6.success
			else
				v61 = v_u_6.line
			end
			v60(v59, v61, 1, p54.done and 0.4 or 0)
			local v62 = v_u_33
			local v63 = v58.icon
			local v64 = p54.icon or "task"
			local v65
			if p54.done then
				v65 = v_u_6.success
			else
				v65 = v_u_6.accent
			end
			v62(v59, v63, v64, v65, p54.done)
			local v66 = v_u_18
			local v67 = v58.title
			local v68 = {
				["name"] = "Title",
				["text"] = nil,
				["style"] = "h3",
				["textSize"] = 14,
				["color"] = nil,
				["text"] = p54.title
			}
			local v69
			if p54.done then
				v69 = v_u_6.text2
			else
				v69 = v_u_6.text
			end
			v68.color = v69
			v66(v59, v67, v68).TextTruncate = Enum.TextTruncate.AtEnd
			v_u_18(v59, v58.desc, {
				["name"] = "Desc",
				["text"] = nil,
				["style"] = "small",
				["textSize"] = 12,
				["color"] = nil,
				["text"] = p54.desc,
				["color"] = v_u_6.text2
			}).TextTruncate = Enum.TextTruncate.AtEnd
			local v70 = p54.have
			local v71 = p54.target
			local v72 = v70 / math.max(1, v71)
			local v73 = math.clamp(v72, 0, 1)
			local v74 = v_u_4.progress
			local v75 = {
				["parent"] = v59,
				["value"] = v73
			}
			local v76
			if p54.done then
				v76 = v_u_6.success
			else
				v76 = v_u_6.accent
			end
			v75.color = v76
			v75.size = UDim2.fromOffset(v58.bar.w, v58.bar.h)
			v75.position = UDim2.fromOffset(v58.bar.x, v58.bar.y)
			v74(v75)
			local v77 = v_u_4.new
			local v78 = "Frame"
			local v79 = {
				["Name"] = "Chip",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0
			}
			local v80
			if p54.done then
				v80 = v_u_6.success
			else
				v80 = v_u_6.accentDeep
			end
			v79.BackgroundColor3 = v80
			v79.BackgroundTransparency = p54.done and 0.8 or 0.1
			local v81 = v77(v78, v79, v59)
			local v82 = v58.chip
			v81.Position = UDim2.fromOffset(v82.x, v82.y)
			v81.Size = UDim2.fromOffset(v82.w, v82.h)
			local v83 = v_u_4.stroke
			local v84
			if p54.done then
				v84 = v_u_6.success
			else
				v84 = v_u_6.accent
			end
			v83(v81, v84, 1, 0.35)
			local v85
			if p54.done then
				v85 = v_u_8.TEXT.missionDone
			else
				v85 = ("+%s XP"):format(v_u_8.commas(p54.xp))
			end
			local v86 = v_u_4.label
			local v87 = {
				["parent"] = nil,
				["name"] = "Reward",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 12,
				["color"] = nil,
				["align"] = "center",
				["valign"] = "center",
				["size"] = nil,
				["track"] = false,
				["parent"] = v81,
				["text"] = v85
			}
			local v88
			if p54.done then
				v88 = v_u_6.success
			else
				v88 = v_u_6.accent
			end
			v87.color = v88
			v87.size = UDim2.fromScale(1, 1)
			v86(v87).TextTruncate = Enum.TextTruncate.AtEnd
			v_u_18(v59, v58.count, {
				["name"] = "Count",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["align"] = "right",
				["text"] = ("%s / %s"):format(v_u_8.commas(p54.have), v_u_8.commas(p54.target)),
				["color"] = v_u_6.text2
			})
		end
		local function v_u_100(p90, p91, p92) -- name: missionGrid
			-- upvalues: (copy) v_u_9, (copy) v_u_4, (ref) v_u_12, (copy) p_u_2, (copy) v_u_89
			local v93 = (p91 - v_u_9.gap * (p92 - 1)) / p92
			local v94 = math.floor(v93)
			local v95 = v_u_4.new
			local v96 = {
				["Name"] = "Grid",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.fromOffset(p91, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}
			v_u_12 = v_u_12 + 1
			v96.LayoutOrder = v_u_12
			local v97 = v95("Frame", v96, p_u_2)
			v_u_4.new("UIGridLayout", {
				["CellSize"] = UDim2.fromOffset(v94, v_u_9.missionH),
				["CellPadding"] = UDim2.fromOffset(v_u_9.gap, v_u_9.gap),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}, v97)
			for v98, v99 in p90 do
				v_u_89(v97, v99, v94, v_u_9.missionH, v98)
			end
		end
		local function v_u_138(p101, p102, p103, p104) -- name: milestoneCard
			-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_4, (copy) v_u_6, (copy) v_u_18, (copy) p_u_3, (copy) p_u_1
			local v105 = p102.kinds
			local v106 = type(v105) ~= "table" and {} or p102.kinds
			local v107 = #v106
			local v108 = math.min(v107, 3)
			local v109 = v_u_5.touch(36)
			local v110 = v_u_8.milestoneLayout(p103, v_u_9.milestoneH, v109, v108)
			local v111 = v_u_4.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["ClipsDescendants"] = true,
				["Name"] = "MS_" .. p102.id,
				["BackgroundColor3"] = v_u_6.raised,
				["LayoutOrder"] = p104
			}, p101)
			v111.Size = UDim2.fromOffset(p103, v110.h)
			local v112 = v_u_4.stroke
			local v113
			if p102.done then
				v113 = v_u_6.success
			else
				v113 = v_u_6.line
			end
			v112(v111, v113, 1, p102.done and 0.4 or 0)
			v_u_18(v111, v110.title, {
				["name"] = "Title",
				["text"] = nil,
				["style"] = "small",
				["textSize"] = 13,
				["color"] = nil,
				["text"] = p102.text,
				["color"] = v_u_6.text
			}).TextTruncate = Enum.TextTruncate.AtEnd
			for v114 = 1, v108 do
				local v115 = v_u_4.new("Frame", {
					["Name"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.1,
					["BorderSizePixel"] = 0,
					["Name"] = "Kind_" .. v106[v114],
					["BackgroundColor3"] = v_u_6.accentDeep
				}, v111)
				local v116 = v110.chips[v114]
				v115.Position = UDim2.fromOffset(v116.x, v116.y)
				v115.Size = UDim2.fromOffset(v116.w, v116.h)
				local v117 = v_u_4.stroke
				local v118
				if p102.done then
					v118 = v_u_6.success
				else
					v118 = v_u_6.accent
				end
				v117(v115, v118, 1, 0.5)
				local v119 = p_u_3.art.kindIcon
				local v120 = p_u_1
				local v121 = v106[v114]
				local v122 = 16
				local v123
				if p102.done then
					v123 = v_u_6.success
				else
					v123 = v_u_6.accent
				end
				local v124 = v119(v120, v115, v121, v122, v123)
				v124.AnchorPoint = Vector2.new(0.5, 0.5)
				v124.Position = UDim2.fromScale(0.5, 0.5)
			end
			if #p102.rewards > 0 then
				v_u_18(v111, v110.label, {
					["name"] = "Rewards",
					["text"] = nil,
					["style"] = "micro",
					["textSize"] = 11,
					["color"] = nil,
					["valign"] = "center",
					["text"] = table.concat(p102.rewards, ", "),
					["color"] = v_u_6.text2
				}).TextTruncate = Enum.TextTruncate.AtEnd
			end
			local v125 = v_u_4.progress
			local v126 = {
				["parent"] = v111
			}
			local v127 = p102.have
			local v128 = p102.target
			local v129 = v127 / math.max(1, v128)
			v126.value = math.clamp(v129, 0, 1)
			local v130
			if p102.done then
				v130 = v_u_6.success
			else
				v130 = v_u_6.accent
			end
			v126.color = v130
			v126.size = UDim2.fromOffset(v110.bar.w, v110.bar.h)
			v126.position = UDim2.fromOffset(v110.bar.x, v110.bar.y)
			v125(v126)
			v_u_18(v111, v110.count, {
				["name"] = "Count",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["align"] = "right",
				["text"] = ("%s / %s"):format(v_u_8.commas(p102.have), v_u_8.commas(p102.target)),
				["color"] = v_u_6.text2
			})
			if p102.done and not p102.handed then
				v_u_4.button({
					["parent"] = nil,
					["name"] = "Claim",
					["text"] = nil,
					["kind"] = "primary",
					["height"] = nil,
					["width"] = nil,
					["onClick"] = nil,
					["parent"] = v111,
					["text"] = v_u_8.TEXT.milestoneClaim,
					["height"] = v110.action.h,
					["width"] = v110.action.w,
					["onClick"] = function() -- name: onClick
						-- upvalues: (ref) p_u_3
						p_u_3.claim()
					end
				}).Position = UDim2.fromOffset(v110.action.x, v110.action.y)
				return
			elseif p102.handed then
				v_u_18(v111, {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 22,
					["x"] = v110.action.x,
					["y"] = v110.action.y,
					["w"] = v110.action.w
				}, {
					["name"] = "Handed",
					["text"] = nil,
					["style"] = "monoS",
					["textSize"] = 12,
					["color"] = nil,
					["align"] = "right",
					["valign"] = "center",
					["text"] = v_u_8.TEXT.milestoneHanded,
					["color"] = v_u_6.success
				})
			else
				local v131 = v_u_18
				local v132 = {
					["x"] = nil,
					["y"] = nil,
					["w"] = nil,
					["h"] = 22,
					["x"] = v110.action.x,
					["y"] = v110.action.y,
					["w"] = v110.action.w
				}
				local v133 = {
					["name"] = "Percent",
					["text"] = nil,
					["style"] = "monoS",
					["textSize"] = 12,
					["color"] = nil,
					["align"] = "right",
					["valign"] = "center"
				}
				local v134 = p102.have
				local v135 = p102.target
				local v136 = v134 / math.max(1, v135)
				local v137 = math.clamp(v136, 0, 1) * 100
				v133.text = ("%d%%"):format((math.floor(v137)))
				v133.color = v_u_6.muted
				v131(v111, v132, v133)
			end
		end
		function v_u_10.draw(p_u_139, p_u_140) -- name: draw
			-- upvalues: (ref) v_u_13, (copy) v_u_4, (copy) p_u_2, (copy) v_u_7, (copy) v_u_11, (ref) v_u_12, (copy) v_u_9, (copy) v_u_52, (copy) v_u_8, (copy) v_u_43, (copy) v_u_100, (copy) v_u_138, (copy) v_u_6, (copy) v_u_10
			if v_u_13 then
				v_u_4.keepScroll(p_u_2, function()
					-- upvalues: (ref) v_u_7, (ref) p_u_2, (ref) v_u_11, (ref) v_u_12, (ref) v_u_9, (copy) p_u_139, (copy) p_u_140, (ref) v_u_52, (ref) v_u_8, (ref) v_u_43, (ref) v_u_100, (ref) v_u_4, (ref) v_u_138, (ref) v_u_6, (ref) v_u_10
					v_u_7.clear(p_u_2)
					table.clear(v_u_11)
					v_u_12 = 0
					local v141 = v_u_9.w - 20
					local v142 = v_u_9.missionCols
					if p_u_139.ok then
						local v_u_143 = p_u_140 or 0
						if p_u_139.missionsLive then
							for _, v_u_144 in {
								{
									"daily",
									v_u_8.TEXT.daily,
									"dailyIn",
									p_u_139.daily
								},
								{
									"weekly",
									v_u_8.TEXT.weekly,
									"weeklyIn",
									p_u_139.weekly
								}
							} do
								v_u_43(v_u_144[2], v_u_144[3], v141)
								if #v_u_144[4] == 0 then
									v_u_52(v141, function(p145)
										-- upvalues: (ref) v_u_8, (ref) p_u_139, (copy) v_u_144, (copy) v_u_143
										return v_u_8.missionEmptyLine(p_u_139, v_u_144[1], v_u_143 + p145)
									end)
								else
									v_u_100(v_u_144[4], v141, v142)
								end
							end
						else
							v_u_52(v141, function(p146)
								-- upvalues: (ref) v_u_8, (ref) p_u_139, (copy) v_u_143
								return v_u_8.missionsOffLine(p_u_139, v_u_143 + p146)
							end)
						end
						if #p_u_139.milestones > 0 then
							v_u_43(v_u_8.TEXT.milestones, nil, v141)
							local v147 = math.min(v141, 900)
							local v148 = v_u_4.new
							local v149 = {
								["Name"] = "Milestones",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["AutomaticSize"] = nil,
								["LayoutOrder"] = nil,
								["Size"] = UDim2.fromOffset(v147, 0),
								["AutomaticSize"] = Enum.AutomaticSize.Y
							}
							v_u_12 = v_u_12 + 1
							v149.LayoutOrder = v_u_12
							local v150 = v148("Frame", v149, p_u_2)
							v_u_4.layout(v150, "v", v_u_9.gap)
							for v151, v152 in p_u_139.milestones do
								v_u_138(v150, v152, v147, v151)
							end
						end
						local v153 = v_u_4.label({
							["parent"] = nil,
							["name"] = "Note",
							["text"] = nil,
							["style"] = "small",
							["textSize"] = 12,
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["parent"] = p_u_2,
							["text"] = v_u_8.TEXT.noReroll,
							["color"] = v_u_6.muted
						})
						v_u_12 = v_u_12 + 1
						v153.LayoutOrder = v_u_12
						v_u_10._m = p_u_139
						v_u_10._base = v_u_143
					end
				end)
				v_u_10.tick(p_u_140 or 0)
			end
		end
		function v_u_10.tick(p154) -- name: tick
			-- upvalues: (ref) v_u_13, (copy) v_u_10, (copy) v_u_11, (copy) v_u_8
			if v_u_13 then
				local v155 = v_u_10._m
				for _, v156 in v_u_11 do
					if v156.key and v155 then
						local v157 = v_u_8.remaining(v155[v156.key], p154)
						v156.label.Text = v157 == nil and "" or v_u_8.TEXT.newIn:format(v_u_8.duration(v157))
					else
						if v156.key then
							continue
						end
						local v158 = v_u_10._base or 0
						v156.label.Text = v156.fn(p154 - v158)
					end
				end
			end
		end
		function v_u_10.destroy() -- name: destroy
			-- upvalues: (ref) v_u_13, (copy) v_u_11
			v_u_13 = false
			table.clear(v_u_11)
		end
		return v_u_10
	end
}