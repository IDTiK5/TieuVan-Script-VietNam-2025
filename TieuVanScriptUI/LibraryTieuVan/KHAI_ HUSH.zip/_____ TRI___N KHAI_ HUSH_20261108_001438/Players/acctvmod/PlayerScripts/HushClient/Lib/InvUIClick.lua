-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIClick

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items"))
local v_u_15 = {
	["mouseAction"] = function(p3) -- name: mouseAction
		-- upvalues: (copy) v_u_2
		local v4 = p3.loc
		if v4 then
			if v4.kind == "slot" then
				return v4.slot ~= "secure" and "unequip" or nil
			else
				local v5 = p3.def
				local v6
				if v5 then
					v6 = v_u_2.equipSlot(v5)
				else
					v6 = v5
				end
				local v7
				if v6 == nil then
					v7 = false
				else
					local v8 = p3.raid
					if v8 then
						v8 = v6 == "secure"
					end
					v7 = not v8
				end
				if p3.loot then
					if v7 then
						return not p3.worn and "equip" or (v6 ~= "bag" and v6 ~= "armor" and "equip" or (p3.openable and "openbag" or nil))
					else
						return nil
					end
				else
					return v7 and "equip" or (v5 and (v5.category == "medical" and p3.raid) and "use" or (v5 and v5.category == "throwable" and "quickslot" or nil))
				end
			end
		else
			return nil
		end
	end,
	["touchTapSelects"] = function(p9) -- name: touchTapSelects
		local v10
		if p9.raid == true and p9.loc ~= nil then
			v10 = p9.loc.kind == "slot"
		else
			v10 = false
		end
		return v10
	end,
	["touchSwapRefused"] = function(p11) -- name: touchSwapRefused
		local v12
		if p11.raid == true and (p11.touch == true and p11.fromWorld == true) then
			v12 = p11.slotTaken == true
		else
			v12 = false
		end
		return v12
	end,
	["touchDropAsks"] = function(p13) -- name: touchDropAsks
		local v14
		if p13.raid == true and (p13.touch == true and (p13.loc ~= nil and p13.loc.kind == "slot")) then
			v14 = p13.loc.slot ~= "secure"
		else
			v14 = false
		end
		return v14
	end
}
local v_u_16 = nil
function v_u_15.firAsk(p17, p18, p19, p20) -- name: firAsk
	-- upvalues: (ref) v_u_16
	if v_u_16 == nil then
		local v21, v22 = pcall(function()
			return require((script.Parent:WaitForChild("InvUIFirAsk", 5)))
		end)
		if not v21 or type(v22) ~= "table" then
			v22 = false
		end
		v_u_16 = v22
	end
	if not v_u_16 then
		return false
	end
	local v23 = v_u_16.intercept
	local v24, v25 = pcall(v23, p17, p18, p19, p20)
	if v24 then
		v24 = v25 == true
	end
	return v24
end
function v_u_15.ammoMix(p26, p27, p28) -- name: ammoMix
	-- upvalues: (copy) v_u_15, (ref) v_u_16
	v_u_15.firAsk(p26, nil, nil, nil)
	if not v_u_16 then
		return false
	end
	local v29 = v_u_16.mixable
	local v30, v31 = pcall(v29, p26, p27, p28)
	if v30 then
		v30 = type(v31) == "number"
	end
	return v30
end
function v_u_15.quickAsk(p32, p33, p34) -- name: quickAsk
	-- upvalues: (copy) v_u_15, (ref) v_u_16
	v_u_15.firAsk(p32, nil, nil, nil)
	if not v_u_16 then
		return false
	end
	local v35 = v_u_16.quick
	local v36, v37 = pcall(v35, p32, p33, p34)
	if v36 then
		v36 = v37 == true
	end
	return v36
end
return v_u_15