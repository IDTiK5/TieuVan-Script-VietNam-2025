-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUISlotHint

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = {
	["rules"] = nil,
	["items"] = nil
}
function v_u_3.inject(p5, p6) -- name: inject
	-- upvalues: (copy) v_u_4
	local v7 = v_u_4
	v_u_4.rules = p5
	v7.items = p6
end
local v_u_8 = {
	["compact"] = false,
	["long"] = false,
	["twin"] = false
}
function v_u_3.unlocks(p9) -- name: unlocks
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_1
	if v_u_4.rules == nil then
		local v10 = v_u_4
		local v_u_11 = "SlotRules"
		local function v12()
			-- upvalues: (ref) v_u_2, (copy) v_u_11
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_11, 5)))
		end
		local v13, v14 = pcall(v12)
		if not v13 then
			v14 = false
		end
		v10.rules = v14
	end
	local v15
	if v_u_4.rules then
		v15 = v_u_4.rules
	else
		v15 = nil
	end
	if v15 == nil then
		return v_u_8
	else
		local v18 = p9 == nil and function(p16)
			-- upvalues: (ref) v_u_1
			local v17 = v_u_1.LocalPlayer
			if v17 then
				return v17:GetAttribute(p16)
			else
				return nil
			end
		end or p9
		local v19 = v15.unlocksFrom
		local v20, v21 = pcall(v19, v18)
		if v20 and type(v21) == "table" then
			return v21
		else
			return v_u_8
		end
	end
end
function v_u_3.applies(p22, p23) -- name: applies
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	if v_u_4.rules == nil then
		local v24 = v_u_4
		local v_u_25 = "SlotRules"
		local function v26()
			-- upvalues: (ref) v_u_2, (copy) v_u_25
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_25, 5)))
		end
		local v27, v28 = pcall(v26)
		if not v27 then
			v28 = false
		end
		v24.rules = v28
	end
	local v29
	if v_u_4.rules then
		v29 = v_u_4.rules
	else
		v29 = nil
	end
	if v29 == nil or (p23 ~= "secondary" or (type(p22) ~= "table" or p22.equip ~= "primary")) then
		return false
	else
		return v29.isCompact(p22) == true and true or v29.isLong(p22) == true
	end
end
function v_u_3.dropOk(p30, p31, p32, p33) -- name: dropOk
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	if not v_u_3.applies(p30, p31) then
		return nil, nil
	end
	if v_u_4.rules == nil then
		local v34 = v_u_4
		local v_u_35 = "SlotRules"
		local function v36()
			-- upvalues: (ref) v_u_2, (copy) v_u_35
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_35, 5)))
		end
		local v37, v38 = pcall(v36)
		if not v37 then
			v38 = false
		end
		v34.rules = v38
	end
	local v39
	if v_u_4.rules then
		v39 = v_u_4.rules
	else
		v39 = nil
	end
	local v40, v41 = v39.canHold(p30, p31, p33 or v_u_3.unlocks(), p32)
	return v40 == true, v41
end
function v_u_3.fits(p42, p43, p44, p45) -- name: fits
	-- upvalues: (copy) v_u_3
	local v46 = v_u_3.dropOk(p42, p43, p44, p45)
	if v46 ~= nil then
		return v46
	end
	local v47
	if type(p42) == "table" then
		v47 = p42.equip == p43
	else
		v47 = false
	end
	return v47
end
function v_u_3.why(p48, p49, p50) -- name: why
	-- upvalues: (copy) v_u_3
	local v51, v52 = v_u_3.dropOk(p48, p49, p50, nil)
	if v51 == false then
		return v52
	else
		return nil
	end
end
function v_u_3.setCap(p53, p54, p55) -- name: setCap
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3
	if type(p53) == "table" then
		local v56 = p53.def
		if type(v56) == "table" and (p53.def.id == "secondary" and p53.cap ~= nil) then
			if v_u_4.items == nil then
				local v57 = v_u_4
				local v_u_58 = "Items"
				local function v59()
					-- upvalues: (ref) v_u_2, (copy) v_u_58
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_58, 5)))
				end
				local v60, v61 = pcall(v59)
				if not v60 then
					v61 = false
				end
				v57.items = v61
			end
			local v62
			if v_u_4.items then
				v62 = v_u_4.items
			else
				v62 = nil
			end
			local v63
			if p54 == nil or v62 == nil then
				v63 = nil
			else
				v63 = v62.get(p54.id)
			end
			local v64 = p53.cap
			local v65 = v_u_3.caption(v63, p55)
			if not v65 then
				if p55 then
					v65 = p53.def.short
				else
					v65 = p53.def.label
				end
			end
			v64.Text = v65
			return
		end
	end
end
function v_u_3.caption(p66, p67) -- name: caption
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	if not v_u_3.applies(p66, "secondary") then
		return nil
	end
	if v_u_4.rules == nil then
		local v68 = v_u_4
		local v_u_69 = "SlotRules"
		local function v70()
			-- upvalues: (ref) v_u_2, (copy) v_u_69
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_69, 5)))
		end
		local v71, v72 = pcall(v70)
		if not v71 then
			v72 = false
		end
		v68.rules = v72
	end
	local v73
	if v_u_4.rules then
		v73 = v_u_4.rules
	else
		v73 = nil
	end
	return v73.isCompact(p66) and "Compact" or (p67 and "2nd primary" or "Second primary")
end
function v_u_3.tipLine(p74, p75, p76, p77) -- name: tipLine
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	if not v_u_3.applies(p74, "secondary") then
		return nil
	end
	if v_u_4.rules == nil then
		local v78 = v_u_4
		local v_u_79 = "SlotRules"
		local function v80()
			-- upvalues: (ref) v_u_2, (copy) v_u_79
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_79, 5)))
		end
		local v81, v82 = pcall(v80)
		if not v81 then
			v82 = false
		end
		v78.rules = v82
	end
	local v83
	if v_u_4.rules then
		v83 = v_u_4.rules
	else
		v83 = nil
	end
	if p76 == "secondary" then
		return {
			"Slot",
			v83.isCompact(p74) and "Compact carry (sidearm slot)" or "Second primary (sidearm slot)",
			["wide"] = true
		}
	end
	local v84, v85 = v_u_3.dropOk(p74, "secondary", p75, p77)
	if v84 then
		return {
			"Sidearm slot",
			"Fits",
			["wide"] = true
		}
	end
	local v86 = {}
	local v87 = v85 or v83.LOCKED_TEXT.long
	__set_list(v86, 1, {"Sidearm slot", (tostring(v87))})
	v86.wide = true
	return v86
end
function v_u_3.drawOk(p88, p89, p90) -- name: drawOk
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_3
	if v_u_4.items == nil then
		local v91 = v_u_4
		local v_u_92 = "Items"
		local function v93()
			-- upvalues: (ref) v_u_2, (copy) v_u_92
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_92, 5)))
		end
		local v94, v95 = pcall(v93)
		if not v94 then
			v95 = false
		end
		v91.items = v95
	end
	local v96
	if v_u_4.items then
		v96 = v_u_4.items
	else
		v96 = nil
	end
	if v96 == nil or p88 == nil then
		return true
	end
	local v97 = v96.get
	local v98, v99 = pcall(v97, p88)
	if not v98 or type(v99) ~= "table" then
		return true
	end
	if v_u_4.rules == nil then
		local v100 = v_u_4
		local v_u_101 = "SlotRules"
		local function v102()
			-- upvalues: (ref) v_u_2, (copy) v_u_101
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_101, 5)))
		end
		local v103, v104 = pcall(v102)
		if not v103 then
			v104 = false
		end
		v100.rules = v104
	end
	local v105
	if v_u_4.rules then
		v105 = v_u_4.rules
	else
		v105 = nil
	end
	return (v105 == nil or v99.equip == p89) and true or v105.canHold(v99, p89, p90 or v_u_3.unlocks(), nil) == true
end
function v_u_3.isLongId(p106) -- name: isLongId
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	if v_u_4.items == nil then
		local v107 = v_u_4
		local v_u_108 = "Items"
		local function v109()
			-- upvalues: (ref) v_u_2, (copy) v_u_108
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_108, 5)))
		end
		local v110, v111 = pcall(v109)
		if not v110 then
			v111 = false
		end
		v107.items = v111
	end
	local v112
	if v_u_4.items then
		v112 = v_u_4.items
	else
		v112 = nil
	end
	if v_u_4.rules == nil then
		local v113 = v_u_4
		local v_u_114 = "SlotRules"
		local function v115()
			-- upvalues: (ref) v_u_2, (copy) v_u_114
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_114, 5)))
		end
		local v116, v117 = pcall(v115)
		if not v116 then
			v117 = false
		end
		v113.rules = v117
	end
	local v118
	if v_u_4.rules then
		v118 = v_u_4.rules
	else
		v118 = nil
	end
	if v112 == nil or (v118 == nil or p106 == nil) then
		return false
	end
	local v119 = v112.get
	local v120, v121 = pcall(v119, p106)
	if v120 then
		if type(v121) == "table" and v118.isLong(v121) == true then
			v120 = v118.isCompact(v121) ~= true
		else
			v120 = false
		end
	end
	return v120
end
function v_u_3.emptyKinds(p122) -- name: emptyKinds
	-- upvalues: (copy) v_u_3
	local v123 = p122 or v_u_3.unlocks()
	return type(v123) == "table" and v123.long == true and { "rifle", "pistol" } or { "pistol" }
end
return v_u_3