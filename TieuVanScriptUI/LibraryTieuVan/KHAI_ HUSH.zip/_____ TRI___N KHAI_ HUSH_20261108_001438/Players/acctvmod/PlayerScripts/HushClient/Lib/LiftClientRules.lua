-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / LiftClientRules

local v_u_1 = {
	["TUNE"] = {
		["approachLen"] = 300,
		["leaveLen"] = 300,
		["leaveDefault"] = 20,
		["abortDur"] = 2,
		["bobAmp"] = 0.3,
		["bankAmp"] = 1.4,
		["pitchMax"] = 9,
		["pitchSpeed"] = 24,
		["hook"] = 1.5,
		["gap"] = 0.8,
		["ringH"] = 5.2,
		["crateSize"] = nil,
		["swayMax"] = 3.2,
		["groundGrace"] = 0.5,
		["washReach"] = 40,
		["warn"] = 15,
		["chipHide"] = 3,
		["holdSec"] = 0.8,
		["holdCool"] = 2,
		["radioMax"] = 2,
		["radioDedupe"] = 2,
		["radioDefault"] = 5,
		["radioChars"] = 120,
		["nameChars"] = 7,
		["crateSize"] = {
			["x"] = 4.4,
			["y"] = 2.6,
			["z"] = 3.4
		}
	}
}
local v_u_2 = v_u_1.TUNE
function v_u_1.smooth(p3) -- name: smooth
	local v4 = math.min(1, p3)
	local v5 = math.max(0, v4)
	return v5 * v5 * (3 - v5 * 2)
end
local v_u_6 = nil
function v_u_1.useRules(p7) -- name: useRules
	-- upvalues: (ref) v_u_6
	v_u_6 = p7
end
local function v_u_13(p_u_8) -- name: vec3
	local v9, v10, v11, v12 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.X, p_u_8.Y, p_u_8.Z
	end)
	if v9 and (type(v10) == "number" and (type(v11) == "number" and (type(v12) == "number" and (v10 == v10 and (v11 == v11 and v12 == v12))))) then
		return v10, v11, v12
	else
		return nil, nil, nil
	end
end
function v_u_1.clock(p14) -- name: clock
	local v15 = tonumber(p14)
	local v16 = ((v15 == nil or (v15 ~= v15 or (v15 == (1 / 0) or v15 == (-1 / 0)))) and 0 or v15) + 0.5
	local v17 = math.floor(v16)
	local v18 = math.max(0, v17)
	return string.format("%d:%02d", v18 // 60, v18 % 60)
end
function v_u_1.squadOf(p19, p20, p21, p22) -- name: squadOf
	for _, v23 in { p19, p20, p21 } do
		if type(v23) ~= "string" or v23 == "" then
			continue
		end
		return v23
	end
	return "solo:" .. tostring(p22)
end
local v_u_24 = {
	"LevelY",
	"HoverY",
	"CruiseY",
	"StartAt",
	"ArriveAt",
	"OpenAt",
	"RaiseAt",
	"LeaveAt"
}
function v_u_1.fromGetter(p25) -- name: fromGetter
	-- upvalues: (copy) v_u_24, (copy) v_u_13, (copy) v_u_2
	local v26 = {}
	for _, v27 in v_u_24 do
		local v28 = p25(v27)
		if type(v28) ~= "number" or v28 ~= v28 then
			return nil
		end
		v26[string.lower((string.sub(v27, 1, 1))) .. string.sub(v27, 2)] = v28
	end
	local v29, v30, v31 = v_u_13(p25("Spot"))
	local v32, _, v33 = v_u_13(p25("Dir"))
	if v29 == nil or v32 == nil then
		return nil
	end
	local v34 = v32 ^ 2 + v33 ^ 2
	local v35 = math.sqrt(v34)
	if v35 < 0.01 then
		return nil
	end
	v26.spot = {
		["x"] = v29,
		["y"] = v30,
		["z"] = v31
	}
	v26.dir = {
		["x"] = v32 / v35,
		["z"] = v33 / v35
	}
	local v36 = p25("WarnAt")
	if type(v36) ~= "number" then
		v36 = v26.raiseAt - v_u_2.warn
	end
	v26.warnAt = v36
	local v37 = p25("DoneAt")
	if type(v37) ~= "number" then
		v37 = v26.leaveAt + v_u_2.leaveDefault
	end
	v26.doneAt = v37
	v26.aborted = p25("Aborted") == true
	local v38 = p25("Owner")
	local v39 = tonumber(v38)
	v26.owner = (v39 == nil or (v39 ~= v39 or (v39 == (1 / 0) or v39 == (-1 / 0)))) and 0 or v39
	v26.ownerName = type(p25("OwnerName")) ~= "string" and "" or p25("OwnerName")
	v26.squad = type(p25("Squad")) ~= "string" and "" or p25("Squad")
	v26.state = type(p25("State")) ~= "string" and "" or p25("State")
	return v26
end
function v_u_1.flight(p40, p41) -- name: flight
	-- upvalues: (ref) v_u_6, (copy) v_u_2, (copy) v_u_1
	local v42
	if v_u_6 then
		v42 = v_u_6
	else
		local v43, v44 = pcall(function()
			return require((game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("LiftRules")))
		end)
		if v43 and type(v44) == "table" then
			v_u_6 = v44
		end
		v42 = v_u_6
	end
	local v45 = p40.cruiseY - p40.hoverY
	local v46 = v_u_2.approachLen
	local v47 = p40.arriveAt - p40.startAt
	local v48 = math.max(0.5, v47)
	local v49
	if p40.doneAt > p40.leaveAt + 0.5 then
		v49 = p40.doneAt - p40.leaveAt
	else
		v49 = v_u_2.leaveDefault
	end
	local v50 = (p40.leaveAt - p40.startAt) / v48
	local v51 = math.min(1, v50)
	local v52 = math.max(0, v51)
	local v53 = v46 * (1 - v52) * (1 - v52)
	local v54, v55, v56
	if p41 < p40.leaveAt then
		local v57 = (p41 - p40.startAt) / v48
		local v58 = math.min(1, v57)
		local v59 = math.max(0, v58)
		v54 = v46 * (1 - v59) * (1 - v59)
		local v60 = (p41 - p40.startAt) / v48
		local v61 = math.min(1, v60)
		local v62 = math.max(0, v61)
		v55 = 2 * v46 * (1 - v62) / v48
		if p40.aborted then
			v56 = "aborted"
		elseif p41 < p40.arriveAt then
			v56 = "inbound"
		elseif p41 < p40.openAt then
			v56 = "lowering"
		elseif p41 < p40.raiseAt then
			v56 = "open"
		else
			v56 = "raising"
		end
	else
		local v63 = (p41 - p40.leaveAt) / v49
		local v64 = math.min(1, v63)
		local v65 = math.max(0, v64)
		v54 = v53 + (-v46 - v53) * v65 * v65
		local v66 = -v46 - v53
		v55 = math.abs(v66) * 2 * v65 / v49
		if p40.leaveAt + v49 <= p41 then
			v56 = "done"
		elseif p40.aborted then
			v56 = "aborted"
		else
			v56 = "leaving"
		end
	end
	local v67
	if p40.startAt <= p41 then
		v67 = p41 <= p40.leaveAt + v49 + 0.25
	else
		v67 = false
	end
	local v68 = math.abs(v54) / 20
	local v69 = math.min(1, v68)
	local v70 = 1 - math.max(0, v69)
	local v71 = p41 * 1.3
	local v72 = math.sin(v71) * v_u_2.bobAmp * v70
	local v73 = p40.spot.x + p40.dir.x * v54
	local v74 = p40.spot.z + p40.dir.z * v54
	local v75, v76, v77, v78, v79, v80, v81, v82, v83, v84, v85, v86, v87, v88, v89, v90, v91, v92, v93, v94, v95, v96
	if not v42 then
		v98 = p40.hoverY
		v99 = (math.abs(v54) - 60) / 90
		v100 = math.min(1, v99)
		v101 = v98 + v45 * math.max(0, v100)
		v102 = v101 + v72
		v103 = v102 + v_u_2.hook - v_u_2.gap - v_u_2.ringH
		v104 = p40.levelY
		v105 = 0
		if p40.aborted then
			v75 = p40.leaveAt - v_u_2.abortDur
			v76 = math.min(p41, v75) - p40.arriveAt
			v77 = p40.openAt - p40.arriveAt
			v78 = v76 / math.max(0.5, v77)
			v79 = math.min(1, v78)
			v80 = math.max(0, v79)
			v81 = v80 * v80 * (3 - v80 * 2)
			v82 = (p41 - v75) / v_u_2.abortDur
			v83 = math.min(1, v82)
			v84 = math.max(0, v83)
			v105 = v81 * (1 - v84 * v84 * (3 - v84 * 2))
			v85 = true
			v86 = "hang"
		elseif p41 < p40.arriveAt then
			v85 = true
			v86 = "hang"
		elseif p41 < p40.openAt then
			v87 = p41 - p40.arriveAt
			v88 = p40.openAt - p40.arriveAt
			v89 = v87 / math.max(0.5, v88)
			v90 = math.min(1, v89)
			v91 = math.max(0, v90)
			v105 = v91 * v91 * (3 - v91 * 2)
			v85 = true
			v86 = "hang"
		elseif p41 < p40.raiseAt then
			v86 = p41 < p40.openAt + v_u_2.groundGrace and "hang" or "ground"
			v105 = 1
			v85 = true
		elseif p41 < p40.leaveAt then
			v92 = p41 - p40.raiseAt
			v93 = p40.leaveAt - p40.raiseAt
			v94 = v92 / math.max(0.5, v93)
			v95 = math.min(1, v94)
			v96 = math.max(0, v95)
			v105 = 1 - v96 * v96 * (3 - v96 * 2)
			v85 = true
			v86 = "hang"
		else
			v85 = true
			v86 = "hang"
		end
		if v86 == "hang" or v86 == "ground" then
			v103 = v103 + (v104 - v103) * v105
			if v105 >= 0.999 then
				v103 = v104
			end
		end
		if v86 ~= "ground" then
			v104 = v103
		end
		v106 = 1 - v105 * 0.85
		v107 = v_u_2.swayMax
		v108 = math.rad(v107) * v106
		v109 = p41 * 0.9 + 1.3
		v110 = v108 * math.sin(v109) * (v86 == "hang" and 1 or 0)
		v111 = v_u_2.swayMax
		v112 = math.rad(v111) * v106
		v113 = p41 * 1.17
		v114 = v112 * math.sin(v113) * (v86 == "hang" and 1 or 0)
		v115 = v_u_1.travelOf(p40)
		v116 = {
			["visible"] = v67,
			["phase"] = v56,
			["s"] = v54,
			["x"] = v73,
			["y"] = v102,
			["z"] = v74,
			["face"] = {
				["x"] = v115.x,
				["z"] = v115.z
			}
		}
		v117 = v_u_2.pitchMax
		v118 = v55 / v_u_2.pitchSpeed
		v119 = math.min(1, v118)
		v116.pitchDeg = v117 * math.max(0, v119)
		v120 = v_u_2.bankAmp
		v121 = p41 * 0.7
		v116.bankDeg = v120 * math.sin(v121) * v70
		v116.speed = v55
		v122 = 1 - math.abs(v54) / v_u_2.washReach
		v123 = math.min(1, v122)
		v116.wash = math.max(0, v123) * (v67 and 1 or 0)
		v116.crate = {
			["mode"] = v86,
			["shown"] = v86 == "hang",
			["x"] = v73,
			["z"] = v74,
			["bottomY"] = v104,
			["swayX"] = v110,
			["swayZ"] = v114,
			["ext"] = v105
		}
		v116.rope = {
			["on"] = v85 and v67,
			["ringY"] = v104 + v_u_2.ringH
		}
		return v116
	end
	local v97 = v42.profileY
	if type(v97) == "function" then
		v101 = v42.profileY(p40.hoverY, v45, v54)
		v102 = v101 + v72
		v103 = v102 + v_u_2.hook - v_u_2.gap - v_u_2.ringH
		v104 = p40.levelY
		v105 = 0
		if p40.aborted then
			v75 = p40.leaveAt - v_u_2.abortDur
			v76 = math.min(p41, v75) - p40.arriveAt
			v77 = p40.openAt - p40.arriveAt
			v78 = v76 / math.max(0.5, v77)
			v79 = math.min(1, v78)
			v80 = math.max(0, v79)
			v81 = v80 * v80 * (3 - v80 * 2)
			v82 = (p41 - v75) / v_u_2.abortDur
			v83 = math.min(1, v82)
			v84 = math.max(0, v83)
			v105 = v81 * (1 - v84 * v84 * (3 - v84 * 2))
			v85 = true
			v86 = "hang"
		elseif p41 < p40.arriveAt then
			v85 = true
			v86 = "hang"
		elseif p41 < p40.openAt then
			v87 = p41 - p40.arriveAt
			v88 = p40.openAt - p40.arriveAt
			v89 = v87 / math.max(0.5, v88)
			v90 = math.min(1, v89)
			v91 = math.max(0, v90)
			v105 = v91 * v91 * (3 - v91 * 2)
			v85 = true
			v86 = "hang"
		elseif p41 < p40.raiseAt then
			v86 = p41 < p40.openAt + v_u_2.groundGrace and "hang" or "ground"
			v105 = 1
			v85 = true
		elseif p41 < p40.leaveAt then
			v92 = p41 - p40.raiseAt
			v93 = p40.leaveAt - p40.raiseAt
			v94 = v92 / math.max(0.5, v93)
			v95 = math.min(1, v94)
			v96 = math.max(0, v95)
			v105 = 1 - v96 * v96 * (3 - v96 * 2)
			v85 = true
			v86 = "hang"
		else
			v85 = true
			v86 = "hang"
		end
		if v86 == "hang" or v86 == "ground" then
			v103 = v103 + (v104 - v103) * v105
			if v105 >= 0.999 then
				v103 = v104
			end
		end
		if v86 ~= "ground" then
			v104 = v103
		end
		v106 = 1 - v105 * 0.85
		v107 = v_u_2.swayMax
		v108 = math.rad(v107) * v106
		v109 = p41 * 0.9 + 1.3
		v110 = v108 * math.sin(v109) * (v86 == "hang" and 1 or 0)
		v111 = v_u_2.swayMax
		v112 = math.rad(v111) * v106
		v113 = p41 * 1.17
		v114 = v112 * math.sin(v113) * (v86 == "hang" and 1 or 0)
		v115 = v_u_1.travelOf(p40)
		v116 = {
			["visible"] = v67,
			["phase"] = v56,
			["s"] = v54,
			["x"] = v73,
			["y"] = v102,
			["z"] = v74,
			["face"] = {
				["x"] = v115.x,
				["z"] = v115.z
			}
		}
		v117 = v_u_2.pitchMax
		v118 = v55 / v_u_2.pitchSpeed
		v119 = math.min(1, v118)
		v116.pitchDeg = v117 * math.max(0, v119)
		v120 = v_u_2.bankAmp
		v121 = p41 * 0.7
		v116.bankDeg = v120 * math.sin(v121) * v70
		v116.speed = v55
		v122 = 1 - math.abs(v54) / v_u_2.washReach
		v123 = math.min(1, v122)
		v116.wash = math.max(0, v123) * (v67 and 1 or 0)
		v116.crate = {
			["mode"] = v86,
			["shown"] = v86 == "hang",
			["x"] = v73,
			["z"] = v74,
			["bottomY"] = v104,
			["swayX"] = v110,
			["swayZ"] = v114,
			["ext"] = v105
		}
		v116.rope = {
			["on"] = v85 and v67,
			["ringY"] = v104 + v_u_2.ringH
		}
		return v116
	end
	local v98 = p40.hoverY
	local v99 = (math.abs(v54) - 60) / 90
	local v100 = math.min(1, v99)
	local v101 = v98 + v45 * math.max(0, v100)
	local v102 = v101 + v72
	local v103 = v102 + v_u_2.hook - v_u_2.gap - v_u_2.ringH
	local v104 = p40.levelY
	local v105 = 0
	if p40.aborted then
		v75 = p40.leaveAt - v_u_2.abortDur
		v76 = math.min(p41, v75) - p40.arriveAt
		v77 = p40.openAt - p40.arriveAt
		v78 = v76 / math.max(0.5, v77)
		v79 = math.min(1, v78)
		v80 = math.max(0, v79)
		v81 = v80 * v80 * (3 - v80 * 2)
		v82 = (p41 - v75) / v_u_2.abortDur
		v83 = math.min(1, v82)
		v84 = math.max(0, v83)
		v105 = v81 * (1 - v84 * v84 * (3 - v84 * 2))
		v85 = true
		v86 = "hang"
	elseif p41 < p40.arriveAt then
		v85 = true
		v86 = "hang"
	elseif p41 < p40.openAt then
		v87 = p41 - p40.arriveAt
		v88 = p40.openAt - p40.arriveAt
		v89 = v87 / math.max(0.5, v88)
		v90 = math.min(1, v89)
		v91 = math.max(0, v90)
		v105 = v91 * v91 * (3 - v91 * 2)
		v85 = true
		v86 = "hang"
	elseif p41 < p40.raiseAt then
		v86 = p41 < p40.openAt + v_u_2.groundGrace and "hang" or "ground"
		v105 = 1
		v85 = true
	elseif p41 < p40.leaveAt then
		v92 = p41 - p40.raiseAt
		v93 = p40.leaveAt - p40.raiseAt
		v94 = v92 / math.max(0.5, v93)
		v95 = math.min(1, v94)
		v96 = math.max(0, v95)
		v105 = 1 - v96 * v96 * (3 - v96 * 2)
		v85 = true
		v86 = "hang"
	else
		v85 = true
		v86 = "hang"
	end
	if v86 == "hang" or v86 == "ground" then
		v103 = v103 + (v104 - v103) * v105
		if v105 >= 0.999 then
			v103 = v104
		end
	end
	if v86 ~= "ground" then
		v104 = v103
	end
	local v106 = 1 - v105 * 0.85
	local v107 = v_u_2.swayMax
	local v108 = math.rad(v107) * v106
	local v109 = p41 * 0.9 + 1.3
	local v110 = v108 * math.sin(v109) * (v86 == "hang" and 1 or 0)
	local v111 = v_u_2.swayMax
	local v112 = math.rad(v111) * v106
	local v113 = p41 * 1.17
	local v114 = v112 * math.sin(v113) * (v86 == "hang" and 1 or 0)
	local v115 = v_u_1.travelOf(p40)
	local v116 = {
		["visible"] = v67,
		["phase"] = v56,
		["s"] = v54,
		["x"] = v73,
		["y"] = v102,
		["z"] = v74,
		["face"] = {
			["x"] = v115.x,
			["z"] = v115.z
		}
	}
	local v117 = v_u_2.pitchMax
	local v118 = v55 / v_u_2.pitchSpeed
	local v119 = math.min(1, v118)
	v116.pitchDeg = v117 * math.max(0, v119)
	local v120 = v_u_2.bankAmp
	local v121 = p41 * 0.7
	v116.bankDeg = v120 * math.sin(v121) * v70
	v116.speed = v55
	local v122 = 1 - math.abs(v54) / v_u_2.washReach
	local v123 = math.min(1, v122)
	v116.wash = math.max(0, v123) * (v67 and 1 or 0)
	v116.crate = {
		["mode"] = v86,
		["shown"] = v86 == "hang",
		["x"] = v73,
		["z"] = v74,
		["bottomY"] = v104,
		["swayX"] = v110,
		["swayZ"] = v114,
		["ext"] = v105
	}
	v116.rope = {
		["on"] = v85 and v67,
		["ringY"] = v104 + v_u_2.ringH
	}
	return v116
end
function v_u_1.endAt(p124) -- name: endAt
	-- upvalues: (copy) v_u_2
	local v125
	if p124.doneAt > p124.leaveAt + 0.5 then
		v125 = p124.doneAt - p124.leaveAt
	else
		v125 = v_u_2.leaveDefault
	end
	return p124.leaveAt + v125 + 0.25
end
function v_u_1.travelOf(p126) -- name: travelOf
	return {
		["x"] = -p126.dir.x,
		["z"] = -p126.dir.z
	}
end
function v_u_1.chipEntry(p127, p128, p129) -- name: chipEntry
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v130
	if p127.owner == 0 then
		v130 = false
	else
		v130 = p127.owner == p129.userId
	end
	local v131
	if p127.squad == "" then
		v131 = false
	else
		v131 = p127.squad == p129.squad
	end
	if not (v130 or v131) then
		return nil
	end
	local v132 = v_u_1.flight(p127, p128)
	if p127.leaveAt + v_u_2.chipHide < p128 or v132.phase == "done" then
		return nil
	end
	local v133 = "violet"
	local v134 = false
	local v135 = 0
	local v136
	if v132.phase == "aborted" then
		v136 = "leaving"
		v133 = "muted"
	elseif v132.phase == "inbound" or v132.phase == "lowering" then
		local v137 = p127.openAt - p128
		v135 = math.max(0, v137)
		v136 = (v132.phase == "inbound" and "inbound " or "line down ") .. v_u_1.clock(v135)
	elseif v132.phase == "open" then
		local v138 = p127.raiseAt - p128
		v135 = math.max(0, v138)
		v136 = v_u_1.clock(v135)
		v133 = v135 <= v_u_2.warn and "danger" or v133
		v134 = v130
	else
		v136 = "pulling up"
		v133 = "muted"
	end
	if not v130 then
		local v139 = p127.ownerName
		local v140 = v_u_2.nameChars
		local v141 = string.gsub(v139, "[%c]", " ")
		local v142 = string.upper((string.sub(v141, 1, v140)))
		if v142 ~= "" then
			v136 = v142 .. " " .. v136
		end
	end
	local v143 = {
		["key"] = nil,
		["short"] = "CARGO",
		["detail"] = nil,
		["tone"] = nil,
		["owner"] = nil,
		["canSendUp"] = nil,
		["left"] = nil,
		["phase"] = nil,
		["pos"] = nil
	}
	local v144 = p127.startAt * 10
	local v145 = math.floor(v144)
	v143.key = "lift_" .. tostring(v145)
	v143.detail = v136
	v143.tone = v133
	v143.owner = v130
	v143.canSendUp = v134
	v143.left = v135
	v143.phase = v132.phase
	v143.pos = {
		["x"] = p127.spot.x,
		["y"] = p127.spot.y,
		["z"] = p127.spot.z
	}
	return v143
end
function v_u_1.promptHidden(p146, p147, p148) -- name: promptHidden
	if p146 == true then
		return tonumber(p147) ~= tonumber(p148)
	else
		return false
	end
end
function v_u_1.holdNew() -- name: holdNew
	return {
		["t"] = 0,
		["fired"] = false,
		["cool"] = 0
	}
end
function v_u_1.holdStep(p149, p150, p151, p152) -- name: holdStep
	-- upvalues: (copy) v_u_2
	local v153 = tonumber(p151)
	local v154 = (v153 == nil or (v153 ~= v153 or (v153 == (1 / 0) or v153 == (-1 / 0)))) and 0 or v153
	local v155 = math.max(0, v154)
	if p149.cool > 0 then
		local v156 = p149.cool - v155
		p149.cool = math.max(0, v156)
	end
	if not (p150 and p152) then
		p149.t = 0
		p149.fired = false
		return 0, false
	end
	if p149.fired or p149.cool > 0 then
		return 1, false
	end
	p149.t = p149.t + v155
	if p149.t < v_u_2.holdSec then
		return p149.t / v_u_2.holdSec, false
	end
	p149.fired = true
	p149.cool = v_u_2.holdCool
	return 1, true
end
function v_u_1.radioLine(p157) -- name: radioLine
	-- upvalues: (copy) v_u_2
	if type(p157) ~= "table" then
		return nil
	end
	local v158 = p157.speaker
	local v159 = p157.line
	if type(v159) ~= "string" or v159 == "" then
		local v160 = p157.text
		if type(v160) == "string" then
			local v161
			v161, v159 = string.match(p157.text, "^(%u[%u ]*):%s*(.+)$")
			if v161 then
				v158 = v161
			else
				v159 = p157.text
			end
		end
	end
	if type(v159) ~= "string" then
		return nil
	end
	local v162 = string.gsub(v159, "[%c]", " ")
	local v163 = string.gsub(v162, "^%s+", "")
	local v164 = string.gsub(v163, "%s+$", "")
	if v164 == "" then
		return nil
	end
	if #v164 > v_u_2.radioChars then
		local v165 = v_u_2.radioChars
		v164 = string.sub(v164, 1, v165)
	end
	local v166 = "RADIO"
	if type(v158) == "string" and v158 ~= "" then
		local v167 = string.gsub(v158, "[%c]", " ")
		local v168 = string.gsub(v167, "^%s+", "")
		local v169 = string.gsub(v168, "%s+$", "")
		if v169 ~= "" then
			v166 = string.upper((string.sub(v169, 1, 16)))
		end
	end
	local v170 = p157.dur
	local v171 = v_u_2.radioDefault
	local v172 = tonumber(v170)
	if v172 ~= nil and (v172 == v172 and (v172 ~= (1 / 0) and v172 ~= (-1 / 0))) then
		v171 = v172
	end
	local v173 = {
		["speaker"] = v166,
		["text"] = v164
	}
	local v174 = math.min(10, v171)
	v173.dur = math.max(2, v174)
	return v173
end
function v_u_1.radioNew(p175) -- name: radioNew
	-- upvalues: (copy) v_u_2
	local v176 = {
		["cur"] = nil,
		["queue"] = nil,
		["max"] = nil,
		["seen"] = nil,
		["queue"] = {}
	}
	local v177 = p175 or v_u_2.radioMax
	local v178 = math.floor(v177)
	v176.max = math.max(1, v178)
	v176.seen = {}
	return v176
end
function v_u_1.radioPush(p179, p180, p181) -- name: radioPush
	-- upvalues: (copy) v_u_2
	if type(p180) == "table" then
		local v182 = p180.text
		if type(v182) == "string" then
			local v183 = p180.speaker
			local v184 = tostring(v183) .. "|" .. p180.text
			local v185 = p179.seen[v184]
			if v185 and p181 - v185 < v_u_2.radioDedupe then
				return false
			end
			p179.seen[v184] = p181
			if p179.cur == nil then
				p179.cur = {
					["speaker"] = p180.speaker,
					["text"] = p180.text,
					["dur"] = p180.dur,
					["untilAt"] = p181 + p180.dur
				}
				return true
			end
			local v186 = p179.queue
			table.insert(v186, p180)
			while #p179.queue > p179.max do
				table.remove(p179.queue, 1)
			end
			return true
		end
	end
	return false
end
function v_u_1.radioStep(p187, p188) -- name: radioStep
	local v189
	if p187.cur and p187.cur.untilAt <= p188 then
		p187.cur = nil
		v189 = true
	else
		v189 = false
	end
	if p187.cur == nil and #p187.queue > 0 then
		local v190 = table.remove(p187.queue, 1)
		p187.cur = {
			["speaker"] = v190.speaker,
			["text"] = v190.text,
			["dur"] = v190.dur,
			["untilAt"] = p188 + v190.dur
		}
		v189 = true
	end
	return p187.cur, v189
end
return v_u_1