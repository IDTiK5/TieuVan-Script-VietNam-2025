-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuLetters

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = {
	["data"] = nil,
	["busy"] = false,
	["again"] = false,
	["failed"] = false,
	["at"] = -1000000000,
	["listeners"] = nil,
	["listeners"] = {}
}
function v_u_3.listen(p_u_7) -- name: listen
	-- upvalues: (copy) v_u_6
	local v8 = v_u_6.listeners
	table.insert(v8, p_u_7)
	return function()
		-- upvalues: (ref) v_u_6, (copy) p_u_7
		local v9 = table.find(v_u_6.listeners, p_u_7)
		if v9 then
			table.remove(v_u_6.listeners, v9)
		end
	end
end
function v_u_3.data() -- name: data
	-- upvalues: (copy) v_u_6
	return v_u_6.data
end
function v_u_3.failed() -- name: failed
	-- upvalues: (copy) v_u_6
	local v10
	if v_u_6.failed == true then
		v10 = v_u_6.data == nil
	else
		v10 = false
	end
	return v10
end
function v_u_3.unread() -- name: unread
	-- upvalues: (copy) v_u_6, (copy) v_u_4
	local v11 = v_u_6.data
	if #v_u_6.listeners > 0 and v11 then
		local v12 = v11.unread
		if type(v12) == "number" then
			local v13 = v11.unread
			return math.max(0, v13)
		end
	end
	local v14 = v_u_4:GetAttribute("MailUnread")
	if type(v14) == "number" then
		local v15 = math.floor(v14)
		return math.max(0, v15)
	end
	local v16 = v_u_6.data
	if v16 then
		local v17 = v16.unread
		if type(v17) == "number" then
			return v16.unread
		end
	end
	return 0
end
function v_u_3.fetch(p_u_18, p_u_19) -- name: fetch
	-- upvalues: (copy) v_u_6, (copy) v_u_3
	if v_u_6.busy then
		if p_u_19 then
			v_u_6.again = true
		end
	else
		v_u_6.busy = true
		task.spawn(function()
			-- upvalues: (copy) p_u_18, (copy) p_u_19, (ref) v_u_6, (ref) v_u_3
			local v20 = p_u_18.fetch
			local v21 = p_u_19 and 0 or 10
			local v22, v23 = pcall(v20, "letters", nil, v21)
			v_u_6.busy = false
			v_u_6.at = os.clock()
			if v22 and (type(v23) == "table" and v23.error == nil) then
				local v24 = v23.letters
				if type(v24) == "table" then
					v_u_6.data = v23
					v_u_6.failed = false
					for v29, v30 in table.clone(v_u_6.listeners) do
						pcall(v30)
					end
					if v_u_6.again then
						v_u_6.again = false
						v_u_3.fetch(p_u_18, true)
					end
				else
					v_u_6.failed = true
					for v29, v30 in table.clone(v_u_6.listeners) do
						pcall(v30)
					end
					if v_u_6.again then
						v_u_6.again = false
						v_u_3.fetch(p_u_18, true)
					end
				end
			else
				v_u_6.failed = true
				for v29, v30 in table.clone(v_u_6.listeners) do
					pcall(v30)
				end
				if v_u_6.again then
					v_u_6.again = false
					v_u_3.fetch(p_u_18, true)
				end
				return
			end
		end)
	end
end
function v_u_3.watch(p_u_31) -- name: watch
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_3
	local v_u_32 = v_u_4:GetAttributeChangedSignal("MailRev"):Connect(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_3, (copy) p_u_31
		if #v_u_6.listeners > 0 then
			v_u_3.fetch(p_u_31, true)
		end
	end)
	return function()
		-- upvalues: (copy) v_u_32
		v_u_32:Disconnect()
	end
end
function v_u_3.markRead(p_u_33, p34) -- name: markRead
	-- upvalues: (copy) v_u_6
	local v35 = v_u_6.data
	local v36 = false
	if v35 then
		for _, v37 in v35.letters do
			if v37.id ~= p34 or v37.read then
				continue
			end
			v37.read = true
			local v38 = (v35.unread or 0) - 1
			v35.unread = math.max(0, v38)
			v36 = true
		end
	end
	if v36 then
		for _, v39 in table.clone(v_u_6.listeners) do
			pcall(v39)
		end
	end
	local v_u_40 = {
		["op"] = "letterRead",
		["id"] = nil,
		["id"] = p34
	}
	pcall(function()
		-- upvalues: (copy) p_u_33, (copy) v_u_40
		p_u_33.op(v_u_40)
	end)
end
function v_u_3.markAll(p_u_41) -- name: markAll
	-- upvalues: (copy) v_u_6
	local v42 = v_u_6.data
	if v42 then
		for _, v43 in v42.letters do
			v43.read = true
		end
		v42.unread = 0
		for _, v44 in table.clone(v_u_6.listeners) do
			pcall(v44)
		end
	end
	local v_u_45 = {
		["op"] = "letterRead",
		["all"] = true
	}
	pcall(function()
		-- upvalues: (copy) p_u_41, (copy) v_u_45
		p_u_41.op(v_u_45)
	end)
end
function v_u_3.delete(p_u_46, p47) -- name: delete
	-- upvalues: (copy) v_u_6
	local v48 = v_u_6.data
	if v48 then
		for v49, v50 in v48.letters do
			if v50.id ~= p47 then
				continue
			end
			table.remove(v48.letters, v49)
			if not v50.read then
				local v51 = (v48.unread or 0) - 1
				v48.unread = math.max(0, v51)
			end
			v48.count = #v48.letters
		end
		for _, v52 in table.clone(v_u_6.listeners) do
			pcall(v52)
		end
	end
	local v_u_53 = {
		["op"] = "letterDelete",
		["id"] = nil,
		["id"] = p47
	}
	pcall(function()
		-- upvalues: (copy) p_u_46, (copy) v_u_53
		p_u_46.op(v_u_53)
	end)
end
function v_u_3.mount(p54, p55, p56) -- name: mount
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_6
	local v_u_57 = p54.UI
	local v_u_58 = p54.Theme
	local v_u_59 = p54.C
	local v_u_60 = p54.mc
	if v_u_5 == nil then
		v_u_5 = require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("MailcastRules")))
	end
	local v_u_61 = v_u_5
	local v_u_62 = {
		["alive"] = true
	}
	local v_u_63 = {}
	local v_u_64 = ""
	local v_u_65 = {
		["news"] = v_u_59.accent,
		["changelog"] = v_u_59.success,
		["bugs"] = v_u_59.danger,
		["maintenance"] = v_u_59.text
	}
	local v66 = v_u_57.new("Frame", {
		["Name"] = "LettersHead",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Visible"] = false,
		["Size"] = UDim2.new(1, 0, 0, v_u_58.touch(32))
	}, p55)
	local v_u_67 = v_u_57.label({
		["parent"] = nil,
		["name"] = "Summary",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["track"] = false,
		["size"] = nil,
		["parent"] = v66,
		["color"] = v_u_59.text2,
		["size"] = UDim2.new(0.6, 0, 1, 0)
	})
	local v_u_68, v_u_69 = v_u_57.button({
		["parent"] = nil,
		["name"] = "MarkAll",
		["text"] = "Mark all read",
		["kind"] = "ghost",
		["height"] = nil,
		["width"] = 150,
		["maxTextWidth"] = 120,
		["position"] = nil,
		["anchor"] = nil,
		["onClick"] = nil,
		["parent"] = v66,
		["height"] = v_u_58.touch(32),
		["position"] = UDim2.new(1, 0, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_3, (copy) v_u_60
			v_u_3.markAll(v_u_60)
		end
	})
	local v_u_70 = v_u_57.list({
		["parent"] = nil,
		["name"] = "LettersList",
		["size"] = nil,
		["gap"] = 8,
		["parent"] = p55,
		["size"] = UDim2.new(1, 0, 0, p56)
	})
	v_u_70.LayoutOrder = 2
	v_u_70.Visible = false
	v_u_62.head = v66
	v_u_62.list = v_u_70
	local function v_u_100(p_u_71, p72) -- name: buildRow
		-- upvalues: (copy) v_u_63, (copy) v_u_57, (copy) v_u_59, (copy) v_u_70, (copy) v_u_61, (copy) v_u_65, (copy) v_u_58, (ref) v_u_3, (copy) v_u_60, (copy) v_u_62
		local v_u_73 = v_u_63[p_u_71.id] == true
		local v74 = v_u_57.new
		local v75 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil
		}
		local v76 = p_u_71.id
		v75.Name = "Letter_" .. tostring(v76)
		v75.BackgroundColor3 = v_u_59.raised
		v75.Size = UDim2.new(1, -8, 0, 0)
		v75.AutomaticSize = Enum.AutomaticSize.Y
		v75.LayoutOrder = p72
		local v77 = v74("Frame", v75, v_u_70)
		local v78 = v_u_57.stroke
		local v79
		if p_u_71.read then
			v79 = v_u_59.line
		else
			v79 = v_u_59.accentDim
		end
		v78(v77, v79)
		v_u_57.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_59.accent,
			["Size"] = UDim2.new(0, 3, 1, 0),
			["Visible"] = not p_u_71.read
		}, v77)
		local v80 = v_u_57.new("Frame", {
			["Name"] = "Inner",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v77)
		v_u_57.layout(v80, "v", 0)
		local v81 = v_u_57.new("TextButton", {
			["Name"] = "Head",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Selectable"] = true,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v80)
		v81.SelectionImageObject = v_u_57.selectionImage()
		v_u_57.pad(v81, {
			16,
			14,
			10,
			10
		})
		v_u_57.layout(v81, "v", 4)
		local v82 = v_u_57.new("Frame", {
			["Name"] = "Top",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Size"] = UDim2.new(1, 0, 0, 18)
		}, v81)
		local v83 = v_u_57.new("Frame", {
			["Name"] = "Left",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.new(0, 0, 1, 0),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}, v82)
		v_u_57.layout(v83, "h", 8, "center")
		v_u_57.new("Frame", {
			["Name"] = "Dot",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Rotation"] = 45,
			["Visible"] = nil,
			["LayoutOrder"] = 1,
			["BackgroundColor3"] = v_u_59.accent,
			["Size"] = UDim2.fromOffset(7, 7),
			["Visible"] = not p_u_71.read
		}, v83)
		local v84 = v_u_57.label
		local v85 = {
			["parent"] = nil,
			["name"] = "Tag",
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 2,
			["parent"] = v83
		}
		local v86 = p_u_71.label or v_u_61.tagLabel(p_u_71.tag)
		v85.text = tostring(v86)
		v85.color = v_u_65[p_u_71.tag] or v_u_59.accent
		v85.size = UDim2.fromOffset(0, 18)
		v84(v85).RichText = false
		local v87 = v_u_57.label
		local v88 = {
			["parent"] = nil,
			["name"] = "From",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["order"] = 3,
			["parent"] = v83
		}
		local v89 = p_u_71.from or "HUSH"
		v88.text = "FROM " .. tostring(v89)
		v88.color = v_u_59.muted
		v88.size = UDim2.fromOffset(0, 18)
		v87(v88).RichText = false
		v_u_57.label({
			["parent"] = nil,
			["name"] = "Date",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["track"] = false,
			["align"] = "right",
			["position"] = nil,
			["anchor"] = nil,
			["size"] = nil,
			["parent"] = v82,
			["text"] = v_u_61.dateText(p_u_71.at),
			["color"] = v_u_59.text2,
			["position"] = UDim2.new(1, 0, 0, 0),
			["anchor"] = Vector2.new(1, 0),
			["size"] = UDim2.fromOffset(110, 18)
		}).RichText = false
		local v90 = v_u_57.label
		local v91 = {
			["parent"] = nil,
			["name"] = "Subject",
			["text"] = nil,
			["style"] = "bodyStrong",
			["textSize"] = 16,
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["size"] = nil,
			["order"] = 2,
			["parent"] = v81
		}
		local v92 = p_u_71.subject
		v91.text = tostring(v92)
		local v93
		if p_u_71.read then
			v93 = v_u_59.text2
		else
			v93 = v_u_59.text
		end
		v91.color = v93
		v91.size = UDim2.new(1, 0, 0, 0)
		v90(v91).RichText = false
		if v_u_73 then
			local v94 = v_u_57.new("Frame", {
				["Name"] = "BodyBox",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v80)
			v_u_57.pad(v94, {
				16,
				14,
				0,
				12
			})
			v_u_57.layout(v94, "v", 8)
			local v95 = v_u_57.label
			local v96 = {
				["parent"] = nil,
				["name"] = "Body",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["track"] = false,
				["size"] = nil,
				["order"] = 1,
				["parent"] = v94
			}
			local v97 = p_u_71.body
			v96.text = tostring(v97)
			v96.color = v_u_59.text
			v96.size = UDim2.new(1, 0, 0, 0)
			local v98 = v95(v96)
			v98.RichText = false
			v98.TextYAlignment = Enum.TextYAlignment.Top
			local v99 = v_u_57.new("Frame", {
				["Name"] = "Foot",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Size"] = UDim2.new(1, 0, 0, v_u_58.touch(32))
			}, v94)
			v_u_57.button({
				["parent"] = nil,
				["name"] = "Delete",
				["text"] = "Delete",
				["kind"] = "ghost",
				["height"] = nil,
				["width"] = 110,
				["maxTextWidth"] = 80,
				["position"] = nil,
				["anchor"] = nil,
				["onClick"] = nil,
				["parent"] = v99,
				["height"] = v_u_58.touch(32),
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["anchor"] = Vector2.new(1, 0.5),
				["onClick"] = function() -- name: onClick
					-- upvalues: (ref) v_u_63, (copy) p_u_71, (ref) v_u_3, (ref) v_u_60
					v_u_63[p_u_71.id] = nil
					v_u_3.delete(v_u_60, p_u_71.id)
				end
			})
		end
		v81.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_57, (ref) v_u_58
			v_u_57.sound(v_u_58.sounds.hover)
		end)
		v81.Activated:Connect(function()
			-- upvalues: (ref) v_u_57, (ref) v_u_58, (ref) v_u_63, (copy) p_u_71, (copy) v_u_73, (ref) v_u_3, (ref) v_u_60, (ref) v_u_62
			v_u_57.sound(v_u_58.sounds.click)
			v_u_63[p_u_71.id] = not v_u_73
			if v_u_73 or p_u_71.read then
				v_u_62.refresh()
			else
				v_u_3.markRead(v_u_60, p_u_71.id)
			end
		end)
	end
	function v_u_62.refresh() -- name: refresh
		-- upvalues: (copy) v_u_62, (copy) v_u_70, (ref) v_u_6, (copy) v_u_63, (copy) v_u_67, (copy) v_u_69, (copy) v_u_68, (ref) v_u_64, (copy) v_u_57, (copy) v_u_59, (copy) v_u_100
		if v_u_62.alive and v_u_70.Parent then
			local v_u_101 = v_u_6.data
			local v_u_102 = not v_u_101 and {} or v_u_101.letters
			local v103 = { v_u_101 and "d" or (v_u_6.failed and "f" or "l") }
			for _, v104 in v_u_102 do
				local v105 = v104.id
				local v106 = v104.read and "r" or "u"
				local v107 = v_u_63[v104.id] and "o" or "c"
				table.insert(v103, ("%d%s%s"):format(v105, v106, v107))
			end
			local v108 = table.concat(v103, ",")
			local v109 = v_u_101 and (v_u_101.unread or 0) or 0
			local v110 = not v_u_101 and "" or (#v_u_102 == 0 and "" or ("%d UNREAD  \194\183  %d LETTERS"):format(v109, #v_u_102))
			if v_u_67.Text ~= v110 then
				v_u_67.Text = v110
			end
			v_u_69.setEnabled(v109 > 0)
			v_u_68.Visible = v109 > 0
			if v108 ~= v_u_64 then
				v_u_64 = v108
				v_u_57.keepScroll(v_u_70, function()
					-- upvalues: (ref) v_u_70, (copy) v_u_101, (copy) v_u_102, (ref) v_u_57, (ref) v_u_6, (ref) v_u_59, (ref) v_u_100
					for _, v111 in v_u_70:GetChildren() do
						if not v111:IsA("GuiObject") then
							continue
						end
						v111:Destroy()
					end
					if v_u_101 and #v_u_102 ~= 0 then
						for v112, v113 in v_u_102 do
							v_u_100(v113, v112)
						end
					else
						local v114 = v_u_57.new("Frame", {
							["Name"] = "Empty",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["LayoutOrder"] = 1,
							["Size"] = UDim2.new(1, -8, 0, 168)
						}, v_u_70)
						local v115 = v_u_101 and "No letters yet. News, patch notes and known bugs from the HUSH team arrive here." or (not v_u_6.failed and "Checking your letters..." or (not (v_u_6.mc and v_u_6.mc.failText) and "Your letters are not available right now. Try again in a moment." or v_u_6.mc.failText("letters", "Your letters are not available right now. Try again in a moment.")))
						v_u_57.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["wrap"] = true,
							["autoY"] = true,
							["align"] = "center",
							["valign"] = "top",
							["position"] = nil,
							["anchor"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v114,
							["text"] = v115,
							["color"] = v_u_59.text2,
							["position"] = UDim2.new(0.5, 0, 0, 56),
							["anchor"] = Vector2.new(0.5, 0),
							["size"] = UDim2.fromOffset(300, 0)
						}).TextYAlignment = Enum.TextYAlignment.Top
					end
				end)
			end
		else
			return
		end
	end
	function v_u_62.summary() -- name: summary
		-- upvalues: (copy) v_u_67
		return v_u_67.Text
	end
	local v_u_116 = v_u_3.listen(function()
		-- upvalues: (copy) v_u_62
		v_u_62.refresh()
	end)
	local v_u_117 = v_u_3.watch(v_u_60)
	function v_u_62.destroy() -- name: destroy
		-- upvalues: (copy) v_u_62, (copy) v_u_116, (copy) v_u_117
		v_u_62.alive = false
		v_u_116()
		v_u_117()
	end
	return v_u_62
end
return v_u_3