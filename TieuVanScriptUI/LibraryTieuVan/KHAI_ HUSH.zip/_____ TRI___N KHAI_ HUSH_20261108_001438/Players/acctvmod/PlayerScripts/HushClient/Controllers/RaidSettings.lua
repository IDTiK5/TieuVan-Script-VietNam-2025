-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / RaidSettings

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = {
	["name"] = "RaidSettings",
	["order"] = 57
}
local v_u_5 = v1.LocalPlayer
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = false
local v_u_14 = false
local v_u_15 = 0
local v_u_16 = "Menu"
local v_u_17 = nil
local v_u_18 = false
local function v_u_30() -- name: panelOpen
	-- upvalues: (ref) v_u_6
	local v19 = v_u_6
	if v19 then
		v19 = v_u_6.controllers.InventoryUI
	end
	if not v19 or v19._broken then
		v19 = nil
	end
	if v19 then
		local v20 = v19.isOpen
		if type(v20) == "function" then
			local v21 = v19.isOpen
			local v22, v23 = pcall(v21)
			if v22 and v23 then
				return true
			end
		end
	end
	for _, v24 in { "Map", "RaidMap" } do
		local v25 = v_u_6
		if v25 then
			v25 = v_u_6.controllers[v24]
		end
		if not v25 or v25._broken then
			v25 = nil
		end
		if not v25 then
			continue
		end
		local v26 = v25.isOpen
		if type(v26) ~= "function" then
			continue
		end
		local v27 = v25.isOpen
		local v28, v29 = pcall(v27)
		if not (v28 and v29) then
			continue
		end
		return true
	end
	return false
end
local v_u_31 = {
	["mapOpened"] = 0,
	["exitToggled"] = 0
}
function v_u_4.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_4.close() -- name: close
	-- upvalues: (ref) v_u_13, (copy) v_u_5, (ref) v_u_12, (ref) v_u_14, (ref) v_u_6, (copy) v_u_2, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8
	if v_u_13 then
		v_u_13 = false
		v_u_5:SetAttribute("RaidSettingsOpen", false)
		if v_u_12 then
			local function v32()
				-- upvalues: (ref) v_u_12
				v_u_12.flush()
			end
			pcall(v32)
			local function v33()
				-- upvalues: (ref) v_u_12
				v_u_12.destroy()
			end
			pcall(v33)
			v_u_12 = nil
		end
		if v_u_14 then
			v_u_14 = false
			local v34 = v_u_6
			if v34 then
				v34 = v_u_6.controllers.Input
			end
			if not v34 or v34._broken then
				v34 = nil
			end
			if v34 and v34.setEnabled then
				local v35 = v34.setEnabled
				pcall(v35, true)
			end
			if v_u_2.SelectedObject and (v_u_11 and v_u_2.SelectedObject:IsDescendantOf(v_u_11)) then
				v_u_2.SelectedObject = nil
			end
		end
		local v_u_36 = v_u_11
		v_u_11 = nil
		if v_u_36 then
			local v37 = v_u_36:FindFirstChild("Root")
			if v37 then
				v_u_7.fade(v37, 1, "fast", {
					["onDone"] = function() -- name: onDone
						-- upvalues: (copy) v_u_36
						v_u_36:Destroy()
					end
				})
				task.delay(0.6, function()
					-- upvalues: (copy) v_u_36
					if v_u_36.Parent then
						v_u_36:Destroy()
					end
				end)
			else
				v_u_36:Destroy()
			end
		end
		local v38 = v_u_7.sound
		local v39 = v_u_8.sounds.close or v_u_8.sounds.click
		pcall(v38, v39)
	end
end
function v_u_4.open() -- name: open
	-- upvalues: (ref) v_u_13, (ref) v_u_16, (ref) v_u_6, (ref) v_u_7, (copy) v_u_10, (copy) v_u_5, (ref) v_u_18, (copy) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_11, (copy) v_u_4, (ref) v_u_9, (copy) v_u_31, (ref) v_u_14, (copy) v_u_2
	if not v_u_13 and v_u_16 == "Raid" then
		local v_u_40 = nil
		local function v41()
			-- upvalues: (ref) v_u_40, (ref) v_u_6
			v_u_40 = v_u_6.lib.MenuSettings
		end
		pcall(v41)
		local function v42()
			-- upvalues: (ref) v_u_6
			return v_u_6.lib.MenuKit
		end
		local v43, v44 = pcall(v42)
		if not v43 or type(v44) ~= "table" then
			v44 = nil
		end
		local v45 = v_u_40
		if type(v45) == "table" then
			local v46 = v_u_40.new
			if type(v46) == "function" and v44 then
				local v47 = v44.isBound
				if type(v47) == "function" and not v44.isBound() then
					local v48 = v44.bind
					local v49 = v_u_10
					pcall(v48, v49)
				end
				v_u_13 = true
				v_u_5:SetAttribute("RaidSettingsOpen", true)
				if not v_u_18 then
					task.spawn(function()
						-- upvalues: (ref) v_u_3, (ref) v_u_18, (ref) v_u_10, (ref) v_u_13, (ref) v_u_12
						local v_u_50 = v_u_3:FindFirstChild("HushNet")
						if v_u_50 then
							v_u_50 = v_u_50:FindFirstChild("menu.get")
						end
						if v_u_50 and v_u_50:IsA("RemoteFunction") then
							local v51, v52 = pcall(function()
								-- upvalues: (copy) v_u_50
								return v_u_50:InvokeServer({
									["what"] = "settings"
								})
							end)
							if v51 and (type(v52) == "table" and v52.error == nil) then
								v_u_18 = true
								v_u_10.profile = {
									["settings"] = v52
								}
								if v_u_13 and v_u_12 then
									local v53 = v_u_12.show
									if type(v53) == "function" then
										local v54 = v_u_12.show
										pcall(v54, true)
									end
								end
							end
						end
					end)
				end
				local v55, v56 = v_u_7.screen("HushRaidSettings", v_u_8.layer.inventory + 5)
				v_u_11 = v55
				local v57 = v_u_7.topInset()
				local v58 = v_u_7.new("Frame", {
					["Name"] = "Page",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(0, v57),
					["Size"] = UDim2.new(1, 0, 1, -v57 - 12)
				}, v56)
				local v59 = v_u_40.new
				local v60 = v_u_10
				local v61, v62 = pcall(v59, v60, v58, {
					["raid"] = true
				})
				if v61 then
					v_u_12 = v62
					local function v63()
						-- upvalues: (ref) v_u_12
						v_u_12.show()
					end
					pcall(v63)
					local v_u_64 = v58:FindFirstChild("Settings")
					if v_u_64 then
						v_u_64.Active = true
						local v_u_65 = v_u_8.touch(36)
						local _, _ = v_u_7.closeIcon({
							["parent"] = v_u_64,
							["size"] = v_u_65,
							["position"] = UDim2.new(1, -12, 0, 12),
							["anchor"] = Vector2.new(1, 0),
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_4
								v_u_4.close()
							end
						})
						local v66 = v_u_6
						if v66 then
							v66 = v_u_6.controllers.Input
						end
						if not v66 or v66._broken then
							v66 = nil
						end
						local v67
						if v66 and v66.hint then
							local v68 = v66.hint
							local v69, v70 = pcall(v68, "menu")
							v67 = (not v69 or type(v70) ~= "string") and "" or v70
						else
							v67 = ""
						end
						local v71
						if v66 and v66.hint then
							local v72 = v66.hint
							local v73, v74 = pcall(v72, "map")
							v71 = (not v73 or type(v74) ~= "string") and "" or v74
						else
							v71 = ""
						end
						local v75
						if v71 == "" or v71 == "Tap" then
							v75 = false
						else
							v75 = v_u_7.device() ~= "Touch"
						end
						v_u_7.label({
							["parent"] = nil,
							["name"] = "RaidNote",
							["text"] = nil,
							["style"] = "caps",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["anchor"] = nil,
							["size"] = nil,
							["parent"] = v_u_64,
							["text"] = "The raid keeps running" .. ((v67 == "" or v67 == "Tap") and "" or ("  \194\183  %s closes"):format(v67)),
							["color"] = v_u_9.danger,
							["position"] = UDim2.new(1, -v_u_65 - 24, 0, v75 and 10 or 12),
							["anchor"] = Vector2.new(1, 0),
							["size"] = UDim2.new(1, -v_u_65 - 24 - 476, 0, v75 and 18 or v_u_65)
						}).TextTruncate = Enum.TextTruncate.AtEnd
						if v75 then
							v_u_7.label({
								["parent"] = nil,
								["name"] = "MapHint",
								["text"] = nil,
								["style"] = "caps",
								["textSize"] = 12,
								["color"] = nil,
								["align"] = "right",
								["position"] = nil,
								["anchor"] = nil,
								["size"] = nil,
								["parent"] = v_u_64,
								["text"] = ("%s: Map"):format(v71),
								["color"] = v_u_9.text2,
								["position"] = UDim2.new(1, -v_u_65 - 24, 0, 30),
								["anchor"] = Vector2.new(1, 0),
								["size"] = UDim2.new(1, -v_u_65 - 24 - 476, 0, 16)
							}).TextTruncate = Enum.TextTruncate.AtEnd
						end
						local function v103()
							-- upvalues: (ref) v_u_7, (copy) v_u_64, (copy) v_u_65, (ref) v_u_6, (ref) v_u_31, (ref) v_u_4
							v_u_7.button({
								["parent"] = nil,
								["name"] = "MapButton",
								["text"] = "Map",
								["kind"] = "secondary",
								["icon"] = "map",
								["size"] = nil,
								["width"] = 96,
								["position"] = nil,
								["tooltip"] = "Open the map",
								["onClick"] = nil,
								["parent"] = v_u_64,
								["size"] = UDim2.fromOffset(96, v_u_65),
								["position"] = UDim2.fromOffset(168, 12),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_6, (ref) v_u_31, (ref) v_u_4
									local v76 = v_u_6
									if v76 then
										v76 = v_u_6.controllers.MapUI
									end
									if not v76 or v76._broken then
										v76 = nil
									end
									if v76 then
										local v77 = v76.open
										if type(v77) == "function" then
											local v78 = v_u_31
											v78.mapOpened = v78.mapOpened + 1
											v_u_4.close()
											local v79 = v76.open
											pcall(v79)
										end
									end
								end
							})
							local v_u_80 = nil
							local v81 = v_u_7.button
							local v82 = {
								["parent"] = nil,
								["name"] = "ExitMarkerButton",
								["text"] = nil,
								["kind"] = "secondary",
								["icon"] = "extract",
								["size"] = nil,
								["width"] = 186,
								["position"] = nil,
								["tooltip"] = "A green marker points to the nearest open exit",
								["onClick"] = nil,
								["parent"] = v_u_64
							}
							local v83 = v_u_6
							if v83 then
								v83 = v_u_6.controllers.SquadMarkers
							end
							if not v83 or v83._broken then
								v83 = nil
							end
							local v84 = false
							if v83 then
								local v85 = v83.exitCompass
								if type(v85) == "function" then
									local v86 = v83.exitCompass
									local v87
									v84, v87 = pcall(v86)
									if v84 then
										v84 = v87 == true
									end
								end
							end
							v82.text = v84 and "Exit marker: On" or "Exit marker: Off"
							v82.size = UDim2.fromOffset(186, v_u_65)
							v82.position = UDim2.fromOffset(274, 12)
							function v82.onClick() -- name: onClick
								-- upvalues: (ref) v_u_6, (ref) v_u_31, (ref) v_u_80
								local v88 = v_u_6
								if v88 then
									v88 = v_u_6.controllers.SquadMarkers
								end
								if not v88 or v88._broken then
									v88 = nil
								end
								if v88 then
									local v89 = v88.exitCompass
									if type(v89) == "function" then
										local v90 = v88.setExitCompass
										if type(v90) == "function" then
											local v91 = v88.exitCompass
											local v92, v93 = pcall(v91)
											local v94 = v88.setExitCompass
											if v92 then
												v92 = v93 == true
											end
											pcall(v94, not v92)
											local v95 = v_u_31
											v95.exitToggled = v95.exitToggled + 1
											if v_u_80 and v_u_80.setText then
												local v96 = v_u_80.setText
												local v97 = v_u_6
												if v97 then
													v97 = v_u_6.controllers.SquadMarkers
												end
												if not v97 or v97._broken then
													v97 = nil
												end
												local v98 = false
												if v97 then
													local v99 = v97.exitCompass
													if type(v99) == "function" then
														local v100 = v97.exitCompass
														local v101
														v98, v101 = pcall(v100)
														if v98 then
															v98 = v101 == true
														end
													end
												end
												pcall(v96, v98 and "Exit marker: On" or "Exit marker: Off")
											end
										end
									end
								end
							end
							local _, v102 = v81(v82)
							local _ = v102
						end
						local v104, v105 = pcall(v103)
						if not v104 then
							warn("[RaidSettings] header buttons failed:", v105)
						end
					end
					local v_u_106 = v_u_6
					if v_u_106 then
						v_u_106 = v_u_6.controllers.Input
					end
					if not v_u_106 or v_u_106._broken then
						v_u_106 = nil
					end
					local v_u_107 = "Keyboard"
					if v_u_106 and v_u_106.device then
						pcall(function()
							-- upvalues: (ref) v_u_107, (copy) v_u_106
							v_u_107 = v_u_106.device()
						end)
					end
					if v_u_107 == "Gamepad" and (v_u_106 and v_u_106.setEnabled) then
						v_u_14 = true
						local v108 = v_u_106.setEnabled
						pcall(v108, false)
						task.defer(function()
							-- upvalues: (ref) v_u_13, (ref) v_u_11, (ref) v_u_2
							if v_u_13 and v_u_11 then
								local v109 = (1 / 0)
								local v110 = nil
								for _, v111 in v_u_11:GetDescendants() do
									if not v111:IsA("GuiButton") or (not v111.Selectable or (not v111.Visible or v111.AbsoluteSize.X <= 1)) then
										continue
									end
									local v112 = v111.AbsolutePosition.Y / 8
									local v113 = math.floor(v112) * 100000 + v111.AbsolutePosition.X
									if v113 >= v109 then
										continue
									end
									v110 = v111
									v109 = v113
								end
								if v110 then
									v_u_2.SelectedObject = v110
								end
							end
						end)
					end
					v_u_7.fade(v56, 0, "fast", {
						["from"] = 1
					})
					local v114 = v_u_7.sound
					local v115 = v_u_8.sounds.open or v_u_8.sounds.click
					pcall(v114, v115)
				else
					warn("[RaidSettings] settings page failed:", v62)
					v_u_5:SetAttribute("ClientError", "raid settings: " .. tostring(v62))
					v_u_13 = false
					v_u_5:SetAttribute("RaidSettingsOpen", false)
					v55:Destroy()
					v_u_11 = nil
				end
			end
		end
		local v116 = v_u_7.toast
		pcall(v116, "Settings are not available right now", "warn")
	end
end
function v_u_4.toggle() -- name: toggle
	-- upvalues: (ref) v_u_13, (copy) v_u_4
	if v_u_13 then
		v_u_4.close()
	else
		v_u_4.open()
	end
end
local function v_u_124() -- name: addGear
	-- upvalues: (ref) v_u_6, (ref) v_u_17, (ref) v_u_7, (ref) v_u_9
	local v117 = v_u_6
	if v117 then
		v117 = v_u_6.controllers.Input
	end
	if not v117 or v117._broken then
		v117 = nil
	end
	if v117 and v117.touchButton then
		if v_u_17 and v_u_17.Parent then
			v_u_17.Visible = true
		else
			local v118 = v117.touchButton
			local v119 = {
				["text"] = "",
				["anchor"] = "TR",
				["pos"] = nil,
				["size"] = 40,
				["pos"] = Vector2.new(-160, 92)
			}
			local v120, v_u_121 = pcall(v118, "menu", v119)
			if v120 and (typeof(v_u_121) == "Instance" and v_u_121:IsA("GuiButton")) then
				v_u_17 = v_u_121
				local v122 = v_u_121:FindFirstChild("Label")
				if v122 and v122:IsA("TextLabel") then
					v122.Text = ""
				end
				local function v123()
					-- upvalues: (ref) v_u_7, (copy) v_u_121, (ref) v_u_9
					v_u_7.icon("settings", {
						["parent"] = nil,
						["size"] = 20,
						["color"] = nil,
						["position"] = nil,
						["anchor"] = nil,
						["parent"] = v_u_121,
						["color"] = v_u_9.text,
						["position"] = UDim2.fromScale(0.5, 0.5),
						["anchor"] = Vector2.new(0.5, 0.5)
					})
				end
				pcall(v123)
			end
		end
	else
		return
	end
end
function v_u_4.init(p_u_125) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_10, (copy) v_u_3, (ref) v_u_13, (copy) v_u_4, (ref) v_u_16, (copy) v_u_30, (ref) v_u_18, (ref) v_u_11, (ref) v_u_17, (ref) v_u_14
	v_u_6 = p_u_125
	v_u_7 = p_u_125.lib.HushUI
	v_u_7.bind(p_u_125)
	v_u_8 = p_u_125.shared.Theme
	v_u_9 = v_u_8.color
	local v126 = p_u_125.shared.Signal
	v_u_10.cctx = p_u_125
	v_u_10.ui = v_u_7
	v_u_10.theme = v_u_8
	v_u_10.config = p_u_125.config
	v_u_10.cache = {}
	v_u_10.changed = v126.new()
	v_u_10.profile = {
		["settings"] = {}
	}
	local v127 = v_u_10
	local function v128()
		-- upvalues: (ref) v_u_6
		return v_u_6.lib.MenuKit
	end
	local v129, v130 = pcall(v128)
	if not v129 or type(v130) ~= "table" then
		v130 = nil
	end
	v127.kit = v130
	function v_u_10.op(p131) -- name: op
		-- upvalues: (ref) v_u_3
		local v132 = v_u_3:FindFirstChild("HushNet")
		if v132 then
			v132 = v132:FindFirstChild("menu.op")
		end
		if v132 and v132:IsA("RemoteEvent") then
			v132:FireServer(p131)
		end
		return 0
	end
	function v_u_10.compact() -- name: compact
		-- upvalues: (ref) v_u_8
		return v_u_8.refSize().X < 1320 and true or v_u_8.refSize().Y < 640
	end
	function v_u_10.derived() -- name: derived
		return {}
	end
	function v_u_10.setTab() -- name: setTab end
	local v133 = p_u_125.controllers.Input
	if v133 and v133.bind then
		local function v136()
			-- upvalues: (copy) p_u_125, (ref) v_u_13, (ref) v_u_4
			p_u_125.lib.VirtualPad.InputBegan:Connect(function(p134)
				-- upvalues: (ref) v_u_13, (ref) v_u_4
				if v_u_13 and p134.KeyCode == Enum.KeyCode.ButtonB then
					local v135 = p134.UserInputType.Name
					if string.sub(v135, 1, 7) == "Gamepad" then
						v_u_4.close()
					end
				end
			end)
		end
		pcall(v136)
		v133.bind("menu", function()
			-- upvalues: (ref) v_u_16, (ref) v_u_13, (ref) v_u_4, (ref) v_u_30
			if v_u_16 == "Raid" then
				if v_u_13 then
					v_u_4.close()
					return
				elseif not v_u_30() then
					v_u_4.open()
				end
			else
				return
			end
		end)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_18, (ref) v_u_10
		local v137 = v_u_3:WaitForChild("HushNet", 60)
		if v137 then
			v137 = v137:WaitForChild("menu.state", 60)
		end
		if v137 and v137:IsA("RemoteEvent") then
			v137.OnClientEvent:Connect(function(p138)
				-- upvalues: (ref) v_u_18, (ref) v_u_10
				local v139 = type(p138) == "table" and p138.profile or nil
				if type(v139) == "table" then
					local v140 = v139.settings
					if type(v140) == "table" then
						v_u_18 = true
						v_u_10.profile = {
							["settings"] = v139.settings,
							["derived"] = v139.derived
						}
					end
				end
			end)
		end
	end)
	p_u_125.on("ui.rebuild", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_4
		if v_u_13 then
			v_u_4.close()
			task.defer(v_u_4.open)
		end
	end)
	p_u_125.command("raidsettings.open", function()
		-- upvalues: (ref) v_u_16, (ref) v_u_4, (ref) v_u_13
		if v_u_16 ~= "Raid" then
			local v141 = v_u_16
			return "not in a raid (Place=" .. tostring(v141) .. ")"
		end
		v_u_4.open()
		local v142 = v_u_13
		return "open=" .. tostring(v142)
	end)
	p_u_125.command("raidsettings.close", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_13
		v_u_4.close()
		local v143 = v_u_13
		return "open=" .. tostring(v143)
	end)
	p_u_125.command("raidsettings.state", function()
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (ref) v_u_16, (ref) v_u_17, (ref) v_u_14, (ref) v_u_18
		local v144 = v_u_11
		if v144 then
			v144 = v_u_11:FindFirstChild("Settings", true)
		end
		local v145 = "open=%s place=%s gui=%s win=%s gear=%s gearVisible=%s inputOff=%s fetched=%s"
		local v146 = v_u_13
		local v147 = tostring(v146)
		local v148 = v_u_16
		local v149 = v_u_11 ~= nil
		local v150 = tostring(v149)
		local v151 = not (v144 and v144:IsA("GuiObject")) and "-" or ("%dx%d"):format(v144.AbsoluteSize.X, v144.AbsoluteSize.Y)
		local v152
		if v_u_17 == nil then
			v152 = false
		else
			v152 = v_u_17.Parent ~= nil
		end
		local v153 = tostring(v152)
		local v154
		if v_u_17 == nil then
			v154 = false
		else
			v154 = v_u_17.Visible
		end
		local v155 = v_u_14
		local v156 = v_u_18
		return v145:format(v147, v148, v150, v151, v153, tostring(v154), tostring(v155), (tostring(v156)))
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (ref) v_u_16, (copy) v_u_5, (ref) v_u_6, (copy) v_u_3, (copy) v_u_124, (copy) v_u_4, (ref) v_u_17
	local v157 = v_u_5:GetAttribute("Place") or "Menu"
	v_u_16 = tostring(v157)
	v_u_6.session.onPlaceChanged(function(p158)
		-- upvalues: (ref) v_u_16, (ref) v_u_3, (ref) v_u_6, (ref) v_u_5, (ref) v_u_124, (ref) v_u_4, (ref) v_u_17
		v_u_16 = p158
		if p158 == "Raid" then
			task.spawn(function()
				-- upvalues: (ref) v_u_3, (ref) v_u_16, (ref) v_u_6, (ref) v_u_5
				local v_u_159 = v_u_3:FindFirstChild("HushNet")
				if v_u_159 then
					v_u_159 = v_u_159:FindFirstChild("menu.get")
				end
				if v_u_159 and v_u_159:IsA("RemoteFunction") then
					local v160, v161 = pcall(function()
						-- upvalues: (copy) v_u_159
						return v_u_159:InvokeServer({
							["what"] = "settings"
						})
					end)
					if v160 and (type(v161) == "table" and (v161.error == nil and v_u_16 == "Raid")) then
						local v162 = v161.exitCompass
						local v163 = v_u_6
						if v163 then
							v163 = v_u_6.controllers.SquadMarkers
						end
						if not v163 or v163._broken then
							v163 = nil
						end
						if v163 then
							local v164 = v163.setExitCompass
							if type(v164) == "function" then
								local v165 = v163.setExitCompass
								local v166
								if type(v162) == "boolean" then
									v166 = v162
								else
									v166 = nil
								end
								pcall(v165, v166, true)
							end
						end
						v_u_5:SetAttribute("ExitCompassStored", type(v162) ~= "boolean" and "auto" or tostring(v162))
					end
				else
					return
				end
			end)
			local v167 = v_u_6
			if v167 then
				v167 = v_u_6.controllers.Input
			end
			if not v167 or v167._broken then
				v167 = nil
			end
			if v167 and (v167.device and v167.device() == "Touch") then
				v_u_124()
				return
			end
		else
			v_u_4.close()
			if v_u_17 and v_u_17.Parent then
				v_u_17.Visible = false
			end
		end
	end)
	local v168 = v_u_6
	if v168 then
		v168 = v_u_6.controllers.Input
	end
	if not v168 or v168._broken then
		v168 = nil
	end
	if v168 and v168.deviceChanged then
		v168.deviceChanged:Connect(function(p169)
			-- upvalues: (ref) v_u_16, (ref) v_u_124, (ref) v_u_17
			if p169 == "Touch" and v_u_16 == "Raid" then
				v_u_124()
			elseif p169 ~= "Touch" and (v_u_17 and v_u_17.Parent) then
				v_u_17.Visible = false
			end
		end)
	end
	if v_u_16 == "Raid" and (v168 and (v168.device and v168.device() == "Touch")) then
		v_u_124()
	end
	if v_u_16 == "Raid" then
		task.spawn(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_16, (ref) v_u_6, (ref) v_u_5
			local v_u_170 = v_u_3:FindFirstChild("HushNet")
			if v_u_170 then
				v_u_170 = v_u_170:FindFirstChild("menu.get")
			end
			if v_u_170 and v_u_170:IsA("RemoteFunction") then
				local v171, v172 = pcall(function()
					-- upvalues: (copy) v_u_170
					return v_u_170:InvokeServer({
						["what"] = "settings"
					})
				end)
				if v171 and (type(v172) == "table" and (v172.error == nil and v_u_16 == "Raid")) then
					local v173 = v172.exitCompass
					local v174 = v_u_6
					if v174 then
						v174 = v_u_6.controllers.SquadMarkers
					end
					if not v174 or v174._broken then
						v174 = nil
					end
					if v174 then
						local v175 = v174.setExitCompass
						if type(v175) == "function" then
							local v176 = v174.setExitCompass
							local v177
							if type(v173) == "boolean" then
								v177 = v173
							else
								v177 = nil
							end
							pcall(v176, v177, true)
						end
					end
					v_u_5:SetAttribute("ExitCompassStored", type(v173) ~= "boolean" and "auto" or tostring(v173))
				end
			else
				return
			end
		end)
	end
end
function v_u_4.step(p178) -- name: step
	-- upvalues: (ref) v_u_13, (ref) v_u_12, (ref) v_u_15
	if v_u_13 and v_u_12 then
		v_u_15 = v_u_15 + p178
		if v_u_15 >= 0.25 then
			v_u_15 = 0
			local function v179()
				-- upvalues: (ref) v_u_12
				v_u_12.tick()
			end
			pcall(v179)
		end
	end
end
return v_u_4