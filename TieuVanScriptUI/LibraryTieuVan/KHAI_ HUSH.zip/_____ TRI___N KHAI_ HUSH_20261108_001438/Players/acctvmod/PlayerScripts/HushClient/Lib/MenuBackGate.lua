-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuBackGate

local v_u_19 = {
	["new"] = function(p1) -- name: new
		return {
			["base"] = type(p1) ~= "number" and 0 or p1
		}
	end,
	["frame"] = function(p2, p3) -- name: frame
		if type(p3) == "number" then
			p2.base = p3
		end
	end,
	["key"] = function(p4, p5) -- name: key
		local v6 = p5 or {}
		local v7 = {
			["base"] = p4.base
		}
		local v8 = v6.modals
		v7.modals = type(v8) ~= "number" and 0 or v8
		v7.hunt = v6.hunt == true
		v7.dropdown = v6.dropdown == true
		v7.textBox = v6.textBox == true
		v7.blocked = v6.blocked == true
		return v7
	end,
	["reason"] = function(p9, p10) -- name: reason
		local v11 = p10 or {}
		if v11.alive == false then
			return "dead"
		end
		if v11.visible == false then
			return "hidden"
		end
		if v11.home == true then
			return "home"
		end
		local v12 = v11.counter
		if (type(v12) ~= "number" and 0 or v12) ~= p9.base then
			return "taken"
		end
		if p9.modals <= 0 then
			local v13 = v11.modals
			if (type(v13) ~= "number" and 0 or v13) <= 0 then
				return (p9.hunt or v11.hunt == true) and "hunt" or ((p9.dropdown or v11.dropdown == true) and "dropdown" or ((p9.blocked or v11.blocked == true) and "blocked" or ((p9.textBox or v11.textBox == true) and "textbox" or nil)))
			end
		end
		return "modal"
	end,
	["decide"] = function(p14, p15, p16) -- name: decide
		-- upvalues: (copy) v_u_19
		local v17 = v_u_19.reason(p15, p16)
		if p16 ~= nil then
			local v18 = p16.counter
			if type(v18) == "number" then
				p14.base = p16.counter
			end
		end
		return v17 == nil, v17
	end
}
return v_u_19