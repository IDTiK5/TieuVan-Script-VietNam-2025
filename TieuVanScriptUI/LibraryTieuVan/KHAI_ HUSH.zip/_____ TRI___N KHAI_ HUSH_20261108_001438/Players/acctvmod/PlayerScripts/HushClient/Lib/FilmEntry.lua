-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmEntry

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(script.Parent:WaitForChild("HushUI"))
local v_u_5 = v_u_4.Theme
local v_u_6 = v_u_5.color
local v_u_7 = {}
local v_u_8 = v1.LocalPlayer
v_u_7.START_WAIT = 6
v_u_7.BUSY_RETRIES = 4
local v_u_9 = "EntryRules"
local v10, v_u_11 = pcall(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_9
	return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_9, 5)))
end)
if not v10 then
	v_u_11 = nil
end
local v12, v13 = pcall(function()
	return require((script.Parent:WaitForChild("FilmEntryLogic", 5)))
end)
local v_u_14
if v12 and v_u_11 then
	v_u_14 = v13.new(v_u_11)
else
	v_u_14 = nil
end
v_u_7.PAUSE = 1.5
local v15
if v_u_14 then
	v15 = v_u_14.sequence
else
	v15 = nil
end
v_u_7.sequence = v15
local v16
if v_u_14 then
	v16 = v_u_14.markerOptions
else
	v16 = nil
end
v_u_7.markerOptions = v16
function v_u_7.build(p_u_17) -- name: build
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_14, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (copy) v_u_3
	if v_u_8:GetAttribute("FilmAllowed") ~= true then
		return nil
	end
	if not (v_u_11 and v_u_14) then
		warn("[FilmEntry] EntryRules or FilmEntryLogic missing")
		return nil
	end
	local v_u_18 = p_u_17.body
	local v_u_19 = p_u_17.api
	local v_u_20 = p_u_17.handle
	local v_u_21 = v_u_11.TEXTS
	local v_u_22 = true
	p_u_17.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_22
		v_u_22 = false
	end)
	local v23, v_u_24 = pcall(function()
		return require((script.Parent:WaitForChild("EntryCine", 5)))
	end)
	if not (v23 and v_u_24) then
		warn("[FilmEntry] EntryCine missing")
		return nil
	end
	local v_u_25 = 0
	local function v28(p26) -- name: section
		-- upvalues: (ref) v_u_4, (copy) v_u_18, (ref) v_u_6, (ref) v_u_25
		local v27 = v_u_4.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "caps",
			["color"] = nil,
			["size"] = nil,
			["parent"] = v_u_18,
			["text"] = p26,
			["color"] = v_u_6.accent,
			["size"] = UDim2.new(1, 0, 0, 22)
		})
		v_u_25 = v_u_25 + 1
		v27.LayoutOrder = v_u_25
		return v27
	end
	local function v32(p29, p30) -- name: note
		-- upvalues: (ref) v_u_4, (copy) v_u_18, (ref) v_u_6, (ref) v_u_25
		local v31 = v_u_4.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v_u_18,
			["text"] = p29,
			["color"] = p30 or v_u_6.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v_u_25 = v_u_25 + 1
		v31.LayoutOrder = v_u_25
		return v31
	end
	local v_u_33 = "here"
	local v_u_34 = 1
	local v_u_35 = 0
	local v_u_36 = false
	local v_u_37 = false
	local v_u_38 = nil
	local v_u_39 = 0
	local v_u_40 = {}
	local v_u_41 = v_u_14.sequence()
	local v_u_42 = {}
	local v_u_43 = {}
	local v44 = {}
	local v_u_45 = nil
	local v_u_46 = nil
	local v_u_47 = ""
	local v_u_48 = nil
	local function v_u_53() -- name: paintRows
		-- upvalues: (copy) v_u_41, (ref) v_u_11, (copy) v_u_42, (ref) v_u_14, (ref) v_u_34, (copy) v_u_43, (ref) v_u_40, (ref) v_u_48, (ref) v_u_8, (ref) v_u_33, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39
		for _, v49 in v_u_41 do
			local v50 = v_u_11.kindById(v49)
			local v51 = v_u_42[v49]
			if v51 and v50 then
				v51.Text = string.format("%s  \194\183  %s", v50.name, v_u_14.durationText(v49, v_u_34))
			end
			local v52 = v_u_43[v49]
			if not v52 then
				continue
			end
			v52.Text = v_u_14.auditLine(v_u_40[v49], v49)
		end
		if v_u_48 then
			v_u_48()
		end
		v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_33, v_u_34, v_u_36 and (v_u_37 and "all" or "playing") or "idle", v_u_38 or "-", v_u_39, #v_u_41))
	end
	v28(v_u_21.f8Title .. "  \194\183  owner only")
	v32("Plays the real arrival film on you: the same plan, camera, puppets and sounds as at the start of a raid. Your body stays where it is and is protected while it plays. Press SKIP in the picture or STOP here to end it.")
	v32(v_u_21.f8Taint, v_u_6.accent)
	v28("Entry scenes in the game")
	local v_u_54 = v_u_4.label({
		["parent"] = nil,
		["name"] = "EntrySwitchLine",
		["text"] = "Reading the switch ...",
		["style"] = "body",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_18,
		["color"] = v_u_6.text,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_25 = v_u_25 + 1
	v_u_54.LayoutOrder = v_u_25
	local function v_u_62(p55) -- name: paintSwitch
		-- upvalues: (copy) v_u_54, (ref) v_u_6, (ref) v_u_8
		if type(p55) == "table" and p55.ok == true then
			local v56 = p55.data
			if type(v56) == "table" then
				local v57 = p55.data.text
				if type(v57) == "string" then
					v_u_54.Text = p55.data.text
					local v58 = v_u_54
					local v59
					if p55.data.effective == true then
						v59 = v_u_6.accent
					else
						v59 = v_u_6.text
					end
					v58.TextColor3 = v59
					v_u_8:SetAttribute("FilmEntrySwitch", p55.data.text)
					return
				end
			end
		end
		local v60
		if type(p55) == "table" then
			local v61 = p55.msg
			v60 = type(v61) ~= "string" and "No answer from the server." or p55.msg
		else
			v60 = "No answer from the server."
		end
		v_u_54.Text = "Entry scenes: " .. v60
		v_u_8:SetAttribute("FilmEntrySwitch", "error: " .. v60)
	end
	local v63 = v_u_4.new("Frame", {
		["Name"] = "EntrySwitchRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(36))
	}, v_u_18)
	v_u_25 = v_u_25 + 1
	v63.LayoutOrder = v_u_25
	v_u_4.layout(v63, "h", 6)
	local function v65()
		-- upvalues: (copy) v_u_19, (ref) v_u_22, (copy) v_u_62
		v_u_19.callQuiet("entry.switch", {
			["cmd"] = "set",
			["value"] = "on"
		}, function(p64)
			-- upvalues: (ref) v_u_22, (ref) v_u_62
			if v_u_22 then
				v_u_62(p64)
			end
		end)
	end
	local v66 = v_u_4.button({
		["parent"] = nil,
		["text"] = "ON",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 90,
		["onClick"] = nil,
		["maxTextWidth"] = 78,
		["parent"] = v63,
		["height"] = v_u_5.touch(32),
		["onClick"] = v65
	})
	v66.Name = "EntrySwitchOn"
	v66.LayoutOrder = 1
	local function v68()
		-- upvalues: (copy) v_u_19, (ref) v_u_22, (copy) v_u_62
		v_u_19.callQuiet("entry.switch", {
			["cmd"] = "set",
			["value"] = "off"
		}, function(p67)
			-- upvalues: (ref) v_u_22, (ref) v_u_62
			if v_u_22 then
				v_u_62(p67)
			end
		end)
	end
	local v69 = v_u_4.button({
		["parent"] = nil,
		["text"] = "OFF",
		["kind"] = "danger",
		["height"] = nil,
		["width"] = 90,
		["onClick"] = nil,
		["maxTextWidth"] = 78,
		["parent"] = v63,
		["height"] = v_u_5.touch(32),
		["onClick"] = v68
	})
	v69.Name = "EntrySwitchOff"
	v69.LayoutOrder = 2
	local function v71()
		-- upvalues: (copy) v_u_19, (ref) v_u_22, (copy) v_u_62
		v_u_19.callQuiet("entry.switch", {
			["cmd"] = "set",
			["value"] = "default"
		}, function(p70)
			-- upvalues: (ref) v_u_22, (ref) v_u_62
			if v_u_22 then
				v_u_62(p70)
			end
		end)
	end
	local v72 = v_u_4.button({
		["parent"] = nil,
		["text"] = "DEFAULT",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 120,
		["onClick"] = nil,
		["maxTextWidth"] = 108,
		["parent"] = v63,
		["height"] = v_u_5.touch(32),
		["onClick"] = v71
	})
	v72.Name = "EntrySwitchDefault"
	v72.LayoutOrder = 3
	v32("ON and OFF are live for every server within a minute; a scene that is playing ends at once when the switch goes off. DEFAULT follows the build flag.")
	local v73 = p_u_17.syncers
	local function v75()
		-- upvalues: (ref) v_u_22, (copy) v_u_19, (copy) v_u_62
		if v_u_22 then
			v_u_19.callQuiet("entry.switch", {
				["cmd"] = "status"
			}, function(p74)
				-- upvalues: (ref) v_u_22, (ref) v_u_62
				if v_u_22 then
					v_u_62(p74)
				end
			end)
		end
	end
	table.insert(v73, v75)
	v_u_19.callQuiet("entry.switch", {
		["cmd"] = "status"
	}, function(p76)
		-- upvalues: (ref) v_u_22, (copy) v_u_62
		if v_u_22 then
			v_u_62(p76)
		end
	end)
	local v_u_77 = v_u_4.new("Frame", {
		["Name"] = "EntryMarkerHolder",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(40))
	}, v_u_18)
	v_u_25 = v_u_25 + 1
	v_u_77.LayoutOrder = v_u_25
	local function v_u_95() -- name: rebuildMarker
		-- upvalues: (ref) v_u_77, (ref) v_u_2, (ref) v_u_14, (ref) v_u_33, (ref) v_u_4, (copy) v_u_21, (copy) p_u_17, (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (copy) v_u_53
		for _, v78 in v_u_77:GetChildren() do
			v78:Destroy()
		end
		local v_u_79 = nil
		local v_u_80 = nil
		local function v88()
			-- upvalues: (ref) v_u_2, (ref) v_u_79, (ref) v_u_80
			local v81 = v_u_2:FindFirstChild("HushRuntime")
			if v81 then
				v81 = v81:FindFirstChild("Raid")
			end
			if v81 then
				v_u_79 = v81:GetAttribute("Map")
			end
			local v_u_82 = "MapInfo"
			local function v83()
				-- upvalues: (ref) v_u_2, (copy) v_u_82
				return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_82, 5)))
			end
			local v84, v85 = pcall(v83)
			if not v84 then
				v85 = nil
			end
			local v86
			if v85 then
				v86 = v85.fromRuntime()
			else
				v86 = nil
			end
			if v86 then
				local v87 = v86.spawns
				if type(v87) == "table" then
					v_u_80 = v86.spawns
				end
			end
		end
		pcall(v88)
		local v89 = v_u_79
		local v90 = v_u_80
		local v91 = v_u_14.markerOptions(v89, v90)
		local v92 = false
		for _, v93 in v91 do
			if v93.id ~= v_u_33 then
				continue
			end
			v92 = true
		end
		if not v92 then
			v_u_33 = "here"
		end
		v_u_4.dropdown({
			["parent"] = nil,
			["name"] = "EntryMarker",
			["label"] = nil,
			["options"] = nil,
			["value"] = nil,
			["width"] = nil,
			["onChange"] = nil,
			["parent"] = v_u_77,
			["label"] = v_u_21.f8Marker,
			["options"] = v91,
			["value"] = v_u_33,
			["width"] = p_u_17.inner,
			["onChange"] = function(p94) -- name: onChange
				-- upvalues: (ref) v_u_33, (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (ref) v_u_53
				v_u_33 = p94
				v_u_40 = {}
				v_u_46.Text = ""
				v_u_46.Visible = false
				v_u_8:SetAttribute("FilmEntryError", "")
				v_u_53()
			end
		})
	end
	v_u_95()
	local v98 = v_u_4.dropdown({
		["parent"] = nil,
		["name"] = "EntrySquad",
		["label"] = nil,
		["options"] = nil,
		["value"] = "1",
		["width"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_18,
		["label"] = v_u_21.f8Squad,
		["options"] = {
			{
				["id"] = "1",
				["text"] = "1"
			},
			{
				["id"] = "2",
				["text"] = "2"
			},
			{
				["id"] = "3",
				["text"] = "3"
			},
			{
				["id"] = "4",
				["text"] = "4"
			}
		},
		["width"] = p_u_17.inner,
		["onChange"] = function(p96) -- name: onChange
			-- upvalues: (ref) v_u_34, (copy) v_u_53
			local v97 = tonumber(p96) or 1
			v_u_34 = math.clamp(v97, 1, 4)
			v_u_53()
		end
	})
	v_u_25 = v_u_25 + 1
	v98.LayoutOrder = v_u_25
	local function v_u_105(p99) -- name: callWait
		-- upvalues: (copy) v_u_19, (ref) v_u_22
		local v_u_100 = false
		local v_u_101 = nil
		v_u_19.callQuiet("entry.test", p99, function(p102)
			-- upvalues: (ref) v_u_101, (ref) v_u_100
			v_u_101 = p102
			v_u_100 = true
		end)
		local v103 = os.clock()
		local v104 = v_u_101
		while not v_u_100 and (v_u_22 and os.clock() - v103 < 12) do
			task.wait(0.05)
		end
		return v104
	end
	local function v_u_125(p106, p107) -- name: playKind
		-- upvalues: (copy) v_u_105, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_22, (copy) v_u_21, (ref) v_u_7, (ref) v_u_46, (ref) v_u_8, (copy) v_u_20, (ref) v_u_40, (copy) v_u_53, (ref) v_u_11, (copy) v_u_24
		local v108 = 0
		while true do
			local v109 = v_u_105({
				["phase"] = "begin",
				["kind"] = nil,
				["marker"] = nil,
				["n"] = nil,
				["kind"] = p106,
				["marker"] = v_u_33,
				["n"] = v_u_34
			})
			if p107 ~= v_u_35 or not v_u_22 then
				break
			end
			if type(v109) == "table" and v109.ok == true then
				v_u_46.Text = ""
				v_u_46.Visible = false
				v_u_8:SetAttribute("FilmEntryError", "")
				local v110 = v109.data
				local v111 = type(v110) ~= "table" and {} or v109.data
				local v112 = v111.audit
				if type(v112) == "string" then
					v_u_40[p106] = v111.audit
					v_u_53()
				end
				local v113 = v111.id
				local v114 = v111.dur
				local v115
				if type(v114) == "number" then
					v115 = v111.dur
				else
					v115 = v_u_11.duration(p106, v_u_34)
				end
				local v116 = os.clock()
				while v_u_22 and (p107 == v_u_35 and (v_u_24.activeId() ~= v113 and os.clock() - v116 < v_u_7.START_WAIT)) do
					task.wait(0.05)
				end
				if v_u_24.activeId() == v113 then
					local v117 = os.clock()
					while v_u_22 and (p107 == v_u_35 and (v_u_24.activeId() == v113 and os.clock() - v117 < v115 + 12)) do
						task.wait(0.1)
					end
				end
				return p107 == v_u_35
			end
			local v118
			if type(v109) == "table" then
				v118 = v109.msg == v_u_21.f8Busy
			else
				v118 = false
			end
			v108 = v108 + 1
			if not v118 or v_u_7.BUSY_RETRIES < v108 then
				local v119
				if type(v109) == "table" then
					local v120 = v109.msg
					v119 = type(v120) ~= "string" and "No answer from the server." or v109.msg
				else
					v119 = "No answer from the server."
				end
				v_u_46.Text = v119 or ""
				local v121 = v_u_46
				local v122
				if v119 == nil then
					v122 = false
				else
					v122 = v119 ~= ""
				end
				v121.Visible = v122
				v_u_8:SetAttribute("FilmEntryError", v119 or "")
				local v123
				if type(v109) == "table" then
					local v124 = v109.msg
					if type(v124) == "string" then
						v123 = v109.msg
					else
						v123 = nil
					end
				else
					v123 = nil
				end
				if v123 and v123 ~= "" then
					v_u_20.status(v123, "danger")
				end
				return false
			end
			task.wait(0.7)
		end
		return false
	end
	local function v_u_134(p_u_126, p127) -- name: startRun
		-- upvalues: (ref) v_u_36, (copy) v_u_21, (ref) v_u_46, (ref) v_u_8, (ref) v_u_35, (ref) v_u_37, (ref) v_u_33, (ref) v_u_34, (ref) v_u_38, (ref) v_u_39, (copy) v_u_41, (ref) v_u_22, (ref) v_u_14, (ref) v_u_45, (copy) v_u_125, (ref) v_u_7
		if v_u_36 then
			local v128 = v_u_21.f8Busy
			v_u_46.Text = v128 or ""
			local v129 = v_u_46
			local v130
			if v128 == nil then
				v130 = false
			else
				v130 = v128 ~= ""
			end
			v129.Visible = v130
			v_u_8:SetAttribute("FilmEntryError", v128 or "")
		else
			v_u_35 = v_u_35 + 1
			local v_u_131 = v_u_35
			v_u_36 = true
			v_u_37 = p127
			v_u_46.Text = ""
			v_u_46.Visible = false
			v_u_8:SetAttribute("FilmEntryError", "")
			v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_33, v_u_34, v_u_36 and (v_u_37 and "all" or "playing") or "idle", v_u_38 or "-", v_u_39, #v_u_41))
			task.spawn(function()
				-- upvalues: (copy) p_u_126, (copy) v_u_131, (ref) v_u_35, (ref) v_u_22, (ref) v_u_38, (ref) v_u_39, (ref) v_u_14, (ref) v_u_34, (ref) v_u_45, (ref) v_u_8, (ref) v_u_33, (ref) v_u_36, (ref) v_u_37, (ref) v_u_41, (ref) v_u_125, (ref) v_u_7
				for v132, v133 in p_u_126 do
					if v_u_131 ~= v_u_35 or not v_u_22 then
						break
					end
					v_u_38 = v133
					v_u_39 = v132
					v_u_45.Text = v_u_14.progressText(v132, #p_u_126, v133, v_u_34)
					v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_33, v_u_34, v_u_36 and (v_u_37 and "all" or "playing") or "idle", v_u_38 or "-", v_u_39, #v_u_41))
					if not v_u_125(v133, v_u_131) then
						break
					end
					if v132 >= #p_u_126 or v_u_131 ~= v_u_35 then
						continue
					end
					task.wait(v_u_7.PAUSE)
				end
				if v_u_131 == v_u_35 then
					v_u_45.Text = "Done."
				end
				if v_u_131 == v_u_35 then
					v_u_36 = false
					v_u_37 = false
					v_u_38 = nil
					v_u_39 = 0
					v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_33, v_u_34, v_u_36 and (v_u_37 and "all" or "playing") or "idle", v_u_38 or "-", v_u_39, #v_u_41))
				end
			end)
		end
	end
	local function v_u_140() -- name: stop
		-- upvalues: (ref) v_u_35, (copy) v_u_24, (copy) v_u_19, (copy) v_u_20, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_39, (ref) v_u_45, (ref) v_u_8, (ref) v_u_33, (ref) v_u_34, (copy) v_u_41
		v_u_35 = v_u_35 + 1
		local v135 = v_u_24.activeId()
		if v135 ~= nil then
			local v136 = v_u_24.stop
			pcall(v136, "skip")
		end
		v_u_19.callQuiet("entry.test", {
			["phase"] = "end",
			["id"] = nil,
			["id"] = v135
		}, function(p137)
			-- upvalues: (ref) v_u_20
			local v138
			if type(p137) == "table" then
				local v139 = p137.msg
				if type(v139) == "string" then
					v138 = p137.msg
				else
					v138 = nil
				end
			else
				v138 = nil
			end
			if v138 and v138 ~= "" then
				v_u_20.status(v138, "success")
			end
		end)
		v_u_36 = false
		v_u_37 = false
		v_u_38 = nil
		v_u_39 = 0
		v_u_45.Text = "Stopped."
		v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_33, v_u_34, v_u_36 and (v_u_37 and "all" or "playing") or "idle", v_u_38 or "-", v_u_39, #v_u_41))
	end
	local function v156() -- name: audit
		-- upvalues: (copy) v_u_19, (ref) v_u_33, (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (copy) v_u_53, (copy) v_u_41, (copy) v_u_20
		local v141 = {
			["phase"] = "audit",
			["marker"] = nil,
			["marker"] = v_u_33
		}
		v_u_19.callQuiet("entry.test", v141, function(p142)
			-- upvalues: (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (ref) v_u_53, (ref) v_u_41, (ref) v_u_20
			if type(p142) == "table" and p142.ok == true then
				local v143 = p142.data
				if type(v143) == "table" then
					local v144 = p142.data.audit
					if type(v144) == "table" then
						v_u_40 = {}
						for v145, v146 in p142.data.audit do
							if type(v145) ~= "string" or type(v146) ~= "string" then
								continue
							end
							v_u_40[v145] = v146
						end
						v_u_46.Text = ""
						v_u_46.Visible = false
						v_u_8:SetAttribute("FilmEntryError", "")
						v_u_53()
						local v147 = {}
						for _, v148 in v_u_41 do
							local v149 = v148 .. "=" .. (v_u_40[v148] or "?")
							table.insert(v147, v149)
						end
						v_u_8:SetAttribute("FilmEntryAudit", table.concat(v147, "; "))
						return
					end
				end
			end
			local v150
			if type(p142) == "table" then
				local v151 = p142.msg
				v150 = type(v151) ~= "string" and "No answer from the server." or p142.msg
			else
				v150 = "No answer from the server."
			end
			v_u_46.Text = v150 or ""
			local v152 = v_u_46
			local v153
			if v150 == nil then
				v153 = false
			else
				v153 = v150 ~= ""
			end
			v152.Visible = v153
			v_u_8:SetAttribute("FilmEntryError", v150 or "")
			local v154
			if type(p142) == "table" then
				local v155 = p142.msg
				if type(v155) == "string" then
					v154 = p142.msg
				else
					v154 = nil
				end
			else
				v154 = nil
			end
			if v154 and v154 ~= "" then
				v_u_20.status(v154, "danger")
			end
		end)
	end
	local v_u_157 = { "walk_in", "heli_rope", "pickup_drop" }
	local v_u_158 = {}
	local v_u_159 = {}
	local v_u_160 = {}
	local v_u_161 = nil
	local v_u_162 = ""
	local v_u_163 = 0
	local v_u_164 = false
	v_u_48 = function()
		-- upvalues: (ref) v_u_33, (copy) v_u_157, (copy) v_u_159, (ref) v_u_158, (copy) v_u_160, (ref) v_u_162, (ref) v_u_8
		local v165 = { "marker=" .. v_u_33 }
		for _, v166 in v_u_157 do
			local v167
			if v_u_33 == "here" then
				v167 = false
			else
				local v168 = v_u_33
				local v169 = v_u_159[v168]
				if v169 and v169[v166] ~= nil then
					v167 = v169[v166] == true
				else
					local v170 = v_u_158[v168]
					if type(v170) == "table" then
						v167 = v170[v166] == true
					else
						v167 = false
					end
				end
			end
			local v171 = v_u_160[v166]
			if v171 then
				v171.set(v167)
			end
			local v172 = v166 .. "=" .. (v167 and "1" or "0")
			table.insert(v165, v172)
		end
		local v173 = 0
		local v174 = "pending="
		for _, v175 in v_u_159 do
			for _ in v175 do
				v173 = v173 + 1
			end
		end
		local v176 = v174 .. v173
		table.insert(v165, v176)
		local v177 = "line=" .. v_u_162
		table.insert(v165, v177)
		v_u_8:SetAttribute("FilmEntryApprove", table.concat(v165, "|"))
	end
	local function v_u_182(p178) -- name: applyApprovalData
		-- upvalues: (ref) v_u_158
		if type(p178) == "table" then
			local v179 = p178.markers
			if type(v179) == "table" then
				v_u_158 = {}
				for v180, v181 in p178.markers do
					if type(v180) ~= "string" or type(v181) ~= "table" then
						continue
					end
					v_u_158[v180] = {
						["walk_in"] = v181.walk_in == true,
						["heli_rope"] = v181.heli_rope == true,
						["pickup_drop"] = v181.pickup_drop == true
					}
				end
				return
			end
		end
	end
	local function v_u_189(p183) -- name: markersCall
		-- upvalues: (copy) v_u_19, (ref) v_u_22
		local v_u_184 = false
		local v_u_185 = nil
		v_u_19.callQuiet("entry.markers", p183, function(p186)
			-- upvalues: (ref) v_u_185, (ref) v_u_184
			v_u_185 = p186
			v_u_184 = true
		end)
		local v187 = os.clock()
		local v188 = v_u_185
		while not v_u_184 and (v_u_22 and os.clock() - v187 < 12) do
			task.wait(0.05)
		end
		return v188
	end
	local function v_u_219(p190, p191) -- name: setApproval
		-- upvalues: (ref) v_u_33, (ref) v_u_162, (ref) v_u_161, (ref) v_u_48, (copy) v_u_159, (ref) v_u_158, (ref) v_u_163, (ref) v_u_22, (ref) v_u_164, (copy) v_u_189, (copy) v_u_182, (ref) v_u_46, (ref) v_u_8
		if v_u_33 == "here" then
			v_u_162 = "Choose a marker above to approve scenes. HERE has no approval."
			if v_u_161 then
				v_u_161.Text = "Choose a marker above to approve scenes. HERE has no approval."
			end
			if v_u_48 then
				v_u_48()
			end
			return
		elseif p190 == "walk_in" or (p190 == "heli_rope" or p190 == "pickup_drop") then
			local v192 = v_u_33
			v_u_159[v192] = v_u_159[v192] or {}
			v_u_159[v192][p190] = p191
			local v193 = v_u_158[v192]
			local v194
			if type(v193) == "table" then
				v194 = v193[p190] == true
			else
				v194 = false
			end
			if p191 == v194 then
				v_u_159[v192][p190] = nil
				if next(v_u_159[v192]) == nil then
					v_u_159[v192] = nil
				end
			end
			local v195 = 0
			for _, v196 in v_u_159 do
				for _ in v196 do
					v195 = v195 + 1
				end
			end
			local v197 = v195 > 0 and "Changed, saving in a moment ..." or v_u_162
			v_u_162 = v197
			if v_u_161 then
				v_u_161.Text = v197
			end
			if v_u_48 then
				v_u_48()
			end
			v_u_163 = v_u_163 + 1
			local v_u_198 = v_u_163
			task.delay(1.2, function()
				-- upvalues: (ref) v_u_22, (copy) v_u_198, (ref) v_u_163, (ref) v_u_164, (ref) v_u_159, (ref) v_u_189, (ref) v_u_182, (ref) v_u_162, (ref) v_u_161, (ref) v_u_48, (ref) v_u_46, (ref) v_u_8, (ref) v_u_158
				if v_u_22 and v_u_198 == v_u_163 then
					if v_u_164 then
						return
					end
					v_u_164 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_22, (ref) v_u_159, (ref) v_u_189, (ref) v_u_182, (ref) v_u_162, (ref) v_u_161, (ref) v_u_48, (ref) v_u_46, (ref) v_u_8, (ref) v_u_158, (ref) v_u_164
						while v_u_22 do
							local v199, v200 = next(v_u_159)
							if v199 == nil or v200 == nil then
								break
							end
							local v201 = table.clone(v200)
							local v202 = v_u_189({
								["cmd"] = "set",
								["marker"] = nil,
								["kinds"] = nil,
								["marker"] = v199,
								["kinds"] = v201
							})
							if not v_u_22 then
								break
							end
							if type(v202) == "table" and v202.ok == true then
								for v203, v204 in v201 do
									if not v_u_159[v199] or v_u_159[v199][v203] ~= v204 then
										continue
									end
									v_u_159[v199][v203] = nil
								end
								if v_u_159[v199] and next(v_u_159[v199]) == nil then
									v_u_159[v199] = nil
								end
								v_u_182(v202.data)
								v_u_162 = "Saved."
								if v_u_161 then
									v_u_161.Text = "Saved."
								end
								if v_u_48 then
									v_u_48()
								end
								if next(v_u_159) == nil then
									break
								end
								task.wait(6.2)
							else
								local v205 = string.find
								local v206
								if type(v202) == "table" then
									local v207 = v202.msg
									v206 = (type(v207) ~= "string" or v202.msg == "") and "No answer from the server." or v202.msg
								else
									v206 = "No answer from the server."
								end
								if v205(v206, "One change every", 1, true) == nil then
									v_u_159[v199] = nil
									local v208 = "Not saved: "
									local v209
									if type(v202) == "table" then
										local v210 = v202.msg
										v209 = (type(v210) ~= "string" or v202.msg == "") and "No answer from the server." or v202.msg
									else
										v209 = "No answer from the server."
									end
									local v211 = v208 .. v209
									v_u_162 = v211
									if v_u_161 then
										v_u_161.Text = v211
									end
									local v212
									if type(v202) == "table" then
										local v213 = v202.msg
										v212 = (type(v213) ~= "string" or v202.msg == "") and "No answer from the server." or v202.msg
									else
										v212 = "No answer from the server."
									end
									v_u_46.Text = v212 or ""
									local v214 = v_u_46
									local v215
									if v212 == nil then
										v215 = false
									else
										v215 = v212 ~= ""
									end
									v214.Visible = v215
									v_u_8:SetAttribute("FilmEntryError", v212 or "")
									task.spawn(function()
										-- upvalues: (ref) v_u_189, (ref) v_u_22, (ref) v_u_182, (ref) v_u_162, (ref) v_u_161, (ref) v_u_158, (ref) v_u_48
										local v216 = v_u_189({
											["cmd"] = "get"
										})
										if v_u_22 then
											if type(v216) == "table" and v216.ok == true then
												v_u_182(v216.data)
												v_u_162 = "Approvals loaded."
												if v_u_161 then
													v_u_161.Text = "Approvals loaded."
												end
											else
												v_u_158 = {}
												local v217
												if type(v216) == "table" then
													local v218 = v216.msg
													v217 = (type(v218) ~= "string" or v216.msg == "") and "No answer from the server." or v216.msg
												else
													v217 = "No answer from the server."
												end
												v_u_162 = v217
												if v_u_161 then
													v_u_161.Text = v217
												end
											end
											if v_u_48 then
												v_u_48()
											end
										end
									end)
								else
									v_u_162 = "Waiting for the store, saving in a moment ..."
									if v_u_161 then
										v_u_161.Text = "Waiting for the store, saving in a moment ..."
									end
									if v_u_48 then
										v_u_48()
									end
									task.wait(6.5)
								end
							end
						end
						v_u_164 = false
						if v_u_48 then
							v_u_48()
						end
					end)
				end
			end)
		end
	end
	local v220 = v_u_4.new("Frame", {
		["Name"] = "EntryTopRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(36))
	}, v_u_18)
	v_u_25 = v_u_25 + 1
	v220.LayoutOrder = v_u_25
	v_u_4.layout(v220, "h", 6)
	local v221 = v_u_21.f8PlayAll
	local v222 = v_u_4.button({
		["parent"] = nil,
		["text"] = nil,
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 150,
		["onClick"] = nil,
		["maxTextWidth"] = 138,
		["parent"] = v220,
		["text"] = v221,
		["height"] = v_u_5.touch(32),
		["onClick"] = function()
			-- upvalues: (copy) v_u_134, (copy) v_u_41
			v_u_134(v_u_41, true)
		end
	})
	v222.Name = "EntryPlayAll"
	v222.LayoutOrder = 1
	local v223 = v_u_21.f8Stop
	local v224 = v_u_4.button({
		["parent"] = nil,
		["text"] = nil,
		["kind"] = "danger",
		["height"] = nil,
		["width"] = 110,
		["onClick"] = nil,
		["maxTextWidth"] = 98,
		["parent"] = v220,
		["text"] = v223,
		["height"] = v_u_5.touch(32),
		["onClick"] = function()
			-- upvalues: (copy) v_u_140
			v_u_140()
		end
	})
	v224.Name = "EntryStop"
	v224.LayoutOrder = 2
	local function v240()
		-- upvalues: (copy) v_u_19, (ref) v_u_33, (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (copy) v_u_53, (copy) v_u_41, (copy) v_u_20
		local v225 = {
			["phase"] = "audit",
			["marker"] = nil,
			["marker"] = v_u_33
		}
		v_u_19.callQuiet("entry.test", v225, function(p226)
			-- upvalues: (ref) v_u_40, (ref) v_u_46, (ref) v_u_8, (ref) v_u_53, (ref) v_u_41, (ref) v_u_20
			if type(p226) == "table" and p226.ok == true then
				local v227 = p226.data
				if type(v227) == "table" then
					local v228 = p226.data.audit
					if type(v228) == "table" then
						v_u_40 = {}
						for v229, v230 in p226.data.audit do
							if type(v229) ~= "string" or type(v230) ~= "string" then
								continue
							end
							v_u_40[v229] = v230
						end
						v_u_46.Text = ""
						v_u_46.Visible = false
						v_u_8:SetAttribute("FilmEntryError", "")
						v_u_53()
						local v231 = {}
						for _, v232 in v_u_41 do
							local v233 = v232 .. "=" .. (v_u_40[v232] or "?")
							table.insert(v231, v233)
						end
						v_u_8:SetAttribute("FilmEntryAudit", table.concat(v231, "; "))
						return
					end
				end
			end
			local v234
			if type(p226) == "table" then
				local v235 = p226.msg
				v234 = type(v235) ~= "string" and "No answer from the server." or p226.msg
			else
				v234 = "No answer from the server."
			end
			v_u_46.Text = v234 or ""
			local v236 = v_u_46
			local v237
			if v234 == nil then
				v237 = false
			else
				v237 = v234 ~= ""
			end
			v236.Visible = v237
			v_u_8:SetAttribute("FilmEntryError", v234 or "")
			local v238
			if type(p226) == "table" then
				local v239 = p226.msg
				if type(v239) == "string" then
					v238 = p226.msg
				else
					v238 = nil
				end
			else
				v238 = nil
			end
			if v238 and v238 ~= "" then
				v_u_20.status(v238, "danger")
			end
		end)
	end
	local v241 = v_u_4.button({
		["parent"] = nil,
		["text"] = "CHECK AUDIT",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 150,
		["onClick"] = nil,
		["maxTextWidth"] = 138,
		["parent"] = v220,
		["height"] = v_u_5.touch(32),
		["onClick"] = v240
	})
	v241.Name = "EntryAudit"
	v241.LayoutOrder = 3
	v_u_45 = v_u_4.label({
		["parent"] = nil,
		["name"] = "EntryProgress",
		["text"] = "Idle.",
		["style"] = "body",
		["color"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_18,
		["color"] = v_u_6.text,
		["size"] = UDim2.new(1, 0, 0, 24)
	})
	v_u_25 = v_u_25 + 1
	v_u_45.LayoutOrder = v_u_25
	v_u_46 = v_u_4.label({
		["parent"] = nil,
		["name"] = "EntryError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_18,
		["color"] = v_u_6.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_25 = v_u_25 + 1
	v_u_46.LayoutOrder = v_u_25
	v_u_46.Visible = false
	v28("Kinds")
	v32("APPROVE decides whether a kind may play at the marker chosen above. Nothing approved (the default) means PLAIN, the old arrival. The audit still decides first: an approval never overrides a blocked result. PLAY and PLAY ALL here ignore the approvals.")
	local v242 = v_u_4.label({
		["parent"] = nil,
		["name"] = "EntryApprovalLine",
		["text"] = "Reading the approvals ...",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["track"] = false,
		["parent"] = v_u_18,
		["color"] = v_u_6.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_25 = v_u_25 + 1
	v242.LayoutOrder = v_u_25
	v_u_161 = v242
	local v_u_243 = v_u_38
	local v_u_244 = v_u_37
	local v_u_245 = v_u_35
	local v_u_246 = v_u_36
	local v_u_247 = v_u_34
	local v_u_248 = v_u_33
	local v_u_249 = v_u_46
	local v_u_250 = v_u_39
	local v_u_251 = v_u_48
	local v_u_252 = v_u_158
	local v_u_253 = v_u_161
	local v_u_254 = v_u_162
	local v_u_255 = v_u_22
	local v_u_256 = v_u_40
	local v257 = v_u_25
	for _, v_u_258 in v_u_41 do
		local v259 = v_u_11.kindById(v_u_258)
		local v260 = v_u_4.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = "EntryKind_" .. v_u_258,
			["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(34))
		}, v_u_18)
		v_u_25 = v257 + 1
		v260.LayoutOrder = v_u_25
		v_u_4.layout(v260, "h", 6)
		local v261 = v_u_4.label({
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v260,
			["text"] = v259.name,
			["color"] = v_u_6.text,
			["size"] = UDim2.new(0, p_u_17.inner - 112, 1, 0)
		})
		v261.LayoutOrder = 1
		v_u_42[v_u_258] = v261
		local v262 = v_u_21.f8Play
		local v263 = "EntryPlay_" .. v_u_258
		local v264 = v_u_4.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = 100,
			["onClick"] = nil,
			["maxTextWidth"] = 88,
			["parent"] = v260,
			["text"] = v262,
			["height"] = v_u_5.touch(32),
			["onClick"] = function()
				-- upvalues: (copy) v_u_134, (copy) v_u_258
				v_u_134({ v_u_258 }, false)
			end
		})
		v264.Name = v263
		v44[v_u_258] = v264
		v44[v_u_258].LayoutOrder = 2
		local v265 = (v_u_258 == "walk_in" or v_u_258 == "heli_rope") and true or v_u_258 == "pickup_drop"
		local v266 = v_u_4.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Name"] = "EntryAuditRow_" .. v_u_258,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v_u_18)
		v_u_25 = v_u_25 + 1
		v266.LayoutOrder = v_u_25
		v_u_4.layout(v266, "h", 6)
		local v267 = v_u_4.label
		local v268 = {
			["parent"] = nil,
			["name"] = nil,
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v266,
			["name"] = "EntryAudit_" .. v_u_258,
			["color"] = v_u_6.text2
		}
		local v269 = UDim2.new
		local v270 = 0
		local v271
		if v265 then
			v271 = p_u_17.inner - 140
		else
			v271 = p_u_17.inner
		end
		v268.size = v269(v270, v271, 0, 0)
		local v272 = v267(v268)
		v272.LayoutOrder = 1
		v_u_43[v_u_258] = v272
		if v265 then
			local v274, v275 = v_u_4.toggle({
				["parent"] = nil,
				["name"] = nil,
				["label"] = "APPROVE",
				["value"] = false,
				["width"] = 134,
				["onChange"] = nil,
				["parent"] = v266,
				["name"] = "EntryApprove_" .. v_u_258,
				["onChange"] = function(p273) -- name: onChange
					-- upvalues: (copy) v_u_219, (copy) v_u_258
					v_u_219(v_u_258, p273)
				end
			})
			v274.LayoutOrder = 2
			v_u_160[v_u_258] = v275
			v257 = v_u_25
		else
			v257 = v_u_25
		end
	end
	v_u_53()
	task.spawn(function()
		-- upvalues: (copy) v_u_189, (ref) v_u_255, (copy) v_u_182, (ref) v_u_254, (ref) v_u_253, (ref) v_u_252, (ref) v_u_251
		local v276 = v_u_189({
			["cmd"] = "get"
		})
		if v_u_255 then
			if type(v276) == "table" and v276.ok == true then
				v_u_182(v276.data)
				v_u_254 = "Approvals loaded."
				if v_u_253 then
					v_u_253.Text = "Approvals loaded."
				end
			else
				v_u_252 = {}
				local v277
				if type(v276) == "table" then
					local v278 = v276.msg
					v277 = (type(v278) ~= "string" or v276.msg == "") and "No answer from the server." or v276.msg
				else
					v277 = "No answer from the server."
				end
				v_u_254 = v277
				if v_u_253 then
					v_u_253.Text = v277
				end
			end
			if v_u_251 then
				v_u_251()
			end
		end
	end)
	local v279 = p_u_17.syncers
	local function v300()
		-- upvalues: (ref) v_u_255, (ref) v_u_2, (ref) v_u_47, (copy) v_u_95, (ref) v_u_256, (ref) v_u_252, (copy) v_u_53, (copy) v_u_159, (copy) v_u_189, (copy) v_u_182, (ref) v_u_254, (ref) v_u_253, (ref) v_u_251
		if v_u_255 then
			local v_u_280 = nil
			local v_u_281 = nil
			local function v289()
				-- upvalues: (ref) v_u_2, (ref) v_u_280, (ref) v_u_281
				local v282 = v_u_2:FindFirstChild("HushRuntime")
				if v282 then
					v282 = v282:FindFirstChild("Raid")
				end
				if v282 then
					v_u_280 = v282:GetAttribute("Map")
				end
				local v_u_283 = "MapInfo"
				local function v284()
					-- upvalues: (ref) v_u_2, (copy) v_u_283
					return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_283, 5)))
				end
				local v285, v286 = pcall(v284)
				if not v285 then
					v286 = nil
				end
				local v287
				if v286 then
					v287 = v286.fromRuntime()
				else
					v287 = nil
				end
				if v287 then
					local v288 = v287.spawns
					if type(v288) == "table" then
						v_u_281 = v287.spawns
					end
				end
			end
			pcall(v289)
			local v290 = v_u_280
			local v291 = v_u_281
			local v292 = tostring(v290)
			local v293 = type(v291) == "table" and #v291 or 0
			local v294 = v292 .. ":" .. tostring(v293)
			if v294 ~= v_u_47 then
				v_u_47 = v294
				v_u_95()
				v_u_256 = {}
				v_u_252 = {}
				v_u_53()
			end
			local v295 = 0
			for _, v296 in v_u_159 do
				for _ in v296 do
					v295 = v295 + 1
				end
			end
			if v295 == 0 then
				task.spawn(function()
					-- upvalues: (ref) v_u_189, (ref) v_u_255, (ref) v_u_182, (ref) v_u_254, (ref) v_u_253, (ref) v_u_252, (ref) v_u_251
					local v297 = v_u_189({
						["cmd"] = "get"
					})
					if v_u_255 then
						if type(v297) == "table" and v297.ok == true then
							v_u_182(v297.data)
							v_u_254 = "Approvals loaded."
							if v_u_253 then
								v_u_253.Text = "Approvals loaded."
							end
						else
							v_u_252 = {}
							local v298
							if type(v297) == "table" then
								local v299 = v297.msg
								v298 = (type(v299) ~= "string" or v297.msg == "") and "No answer from the server." or v297.msg
							else
								v298 = "No answer from the server."
							end
							v_u_254 = v298
							if v_u_253 then
								v_u_253.Text = v298
							end
						end
						if v_u_251 then
							v_u_251()
						end
					end
				end)
			end
		end
	end
	table.insert(v279, v300)
	local v_u_301 = nil
	local v_u_302 = nil
	local function v310()
		-- upvalues: (ref) v_u_2, (ref) v_u_301, (ref) v_u_302
		local v303 = v_u_2:FindFirstChild("HushRuntime")
		if v303 then
			v303 = v303:FindFirstChild("Raid")
		end
		if v303 then
			v_u_301 = v303:GetAttribute("Map")
		end
		local v_u_304 = "MapInfo"
		local function v305()
			-- upvalues: (ref) v_u_2, (copy) v_u_304
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild(v_u_304, 5)))
		end
		local v306, v307 = pcall(v305)
		if not v306 then
			v307 = nil
		end
		local v308
		if v307 then
			v308 = v307.fromRuntime()
		else
			v308 = nil
		end
		if v308 then
			local v309 = v308.spawns
			if type(v309) == "table" then
				v_u_302 = v308.spawns
			end
		end
	end
	pcall(v310)
	local v311 = v_u_302
	local v312 = v_u_301
	local v313 = tostring(v312)
	local v314 = type(v311) == "table" and #v311 or 0
	local _ = v313 .. ":" .. tostring(v314)
	local v_u_321 = {
		["play"] = function(p315) -- name: play
			-- upvalues: (ref) v_u_11, (copy) v_u_134
			if v_u_11.isKind(p315) then
				v_u_134({ p315 }, false)
			end
		end,
		["playAll"] = function() -- name: playAll
			-- upvalues: (copy) v_u_134, (copy) v_u_41
			v_u_134(v_u_41, true)
		end,
		["stop"] = v_u_140,
		["audit"] = v156,
		["setMarker"] = function(p316) -- name: setMarker
			-- upvalues: (ref) v_u_248, (ref) v_u_256, (copy) v_u_53
			v_u_248 = p316
			v_u_256 = {}
			v_u_53()
		end,
		["setSquad"] = function(p317) -- name: setSquad
			-- upvalues: (ref) v_u_247, (copy) v_u_53
			local v318 = math.floor(p317)
			v_u_247 = math.clamp(v318, 1, 4)
			v_u_53()
		end,
		["approve"] = function(p319, p320) -- name: approve
			-- upvalues: (copy) v_u_219
			v_u_219(p319, p320)
		end,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_248, (ref) v_u_247, (ref) v_u_246, (ref) v_u_244, (ref) v_u_243, (ref) v_u_250, (ref) v_u_256
			return {
				["marker"] = v_u_248,
				["n"] = v_u_247,
				["running"] = v_u_246,
				["all"] = v_u_244,
				["kind"] = v_u_243,
				["index"] = v_u_250,
				["audit"] = v_u_256
			}
		end,
		["rows"] = function() -- name: rows
			-- upvalues: (copy) v_u_41
			return #v_u_41
		end
	}
	if v_u_3:IsStudio() then
		local v_u_348 = v_u_8:GetAttributeChangedSignal("FilmEntryCmd"):Connect(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_321, (copy) v_u_140, (copy) v_u_19, (ref) v_u_248, (ref) v_u_256, (ref) v_u_249, (copy) v_u_53, (copy) v_u_41, (copy) v_u_20, (copy) v_u_157, (copy) v_u_219, (copy) v_u_189, (ref) v_u_255, (copy) v_u_182, (ref) v_u_254, (ref) v_u_253, (ref) v_u_252, (ref) v_u_251, (copy) v_u_62
			local v322 = v_u_8:GetAttribute("FilmEntryCmd")
			if type(v322) == "string" and v322 ~= "" then
				v_u_8:SetAttribute("FilmEntryCmd", nil)
				local v323, v324 = string.match(v322, "^(%a+)%s*(.*)$")
				if v323 == "play" then
					v_u_321.play(v324)
					return
				elseif v323 == "all" then
					v_u_321.playAll()
					return
				elseif v323 == "stop" then
					v_u_140()
					return
				elseif v323 == "audit" then
					local v325 = {
						["phase"] = "audit",
						["marker"] = nil,
						["marker"] = v_u_248
					}
					v_u_19.callQuiet("entry.test", v325, function(p326)
						-- upvalues: (ref) v_u_256, (ref) v_u_249, (ref) v_u_8, (ref) v_u_53, (ref) v_u_41, (ref) v_u_20
						if type(p326) == "table" and p326.ok == true then
							local v327 = p326.data
							if type(v327) == "table" then
								local v328 = p326.data.audit
								if type(v328) == "table" then
									v_u_256 = {}
									for v329, v330 in p326.data.audit do
										if type(v329) ~= "string" or type(v330) ~= "string" then
											continue
										end
										v_u_256[v329] = v330
									end
									v_u_249.Text = ""
									v_u_249.Visible = false
									v_u_8:SetAttribute("FilmEntryError", "")
									v_u_53()
									local v331 = {}
									for _, v332 in v_u_41 do
										local v333 = v332 .. "=" .. (v_u_256[v332] or "?")
										table.insert(v331, v333)
									end
									v_u_8:SetAttribute("FilmEntryAudit", table.concat(v331, "; "))
									return
								end
							end
						end
						local v334
						if type(p326) == "table" then
							local v335 = p326.msg
							v334 = type(v335) ~= "string" and "No answer from the server." or p326.msg
						else
							v334 = "No answer from the server."
						end
						v_u_249.Text = v334 or ""
						local v336 = v_u_249
						local v337
						if v334 == nil then
							v337 = false
						else
							v337 = v334 ~= ""
						end
						v336.Visible = v337
						v_u_8:SetAttribute("FilmEntryError", v334 or "")
						local v338
						if type(p326) == "table" then
							local v339 = p326.msg
							if type(v339) == "string" then
								v338 = p326.msg
							else
								v338 = nil
							end
						else
							v338 = nil
						end
						if v338 and v338 ~= "" then
							v_u_20.status(v338, "danger")
						end
					end)
					return
				elseif v323 == "marker" then
					v_u_321.setMarker(v324)
					return
				elseif v323 == "squad" then
					v_u_321.setSquad(tonumber(v324) or 1)
				elseif v323 == "approve" then
					local v340, v341 = string.match(v324, "^(%S+)%s*(%a*)$")
					if v340 == "all" then
						for _, v342 in v_u_157 do
							v_u_219(v342, v341 ~= "off")
						end
						return
					end
					if v340 then
						v_u_219(v340, v341 ~= "off")
						return
					end
				else
					if v323 == "approvals" then
						task.spawn(function()
							-- upvalues: (ref) v_u_189, (ref) v_u_255, (ref) v_u_182, (ref) v_u_254, (ref) v_u_253, (ref) v_u_252, (ref) v_u_251
							local v343 = v_u_189({
								["cmd"] = "get"
							})
							if v_u_255 then
								if type(v343) == "table" and v343.ok == true then
									v_u_182(v343.data)
									v_u_254 = "Approvals loaded."
									if v_u_253 then
										v_u_253.Text = "Approvals loaded."
									end
								else
									v_u_252 = {}
									local v344
									if type(v343) == "table" then
										local v345 = v343.msg
										v344 = (type(v345) ~= "string" or v343.msg == "") and "No answer from the server." or v343.msg
									else
										v344 = "No answer from the server."
									end
									v_u_254 = v344
									if v_u_253 then
										v_u_253.Text = v344
									end
								end
								if v_u_251 then
									v_u_251()
								end
							end
						end)
						return
					end
					if v323 == "switch" then
						if v324 == "on" or (v324 == "off" or v324 == "default") then
							v_u_19.callQuiet("entry.switch", {
								["cmd"] = "set",
								["value"] = nil,
								["value"] = v324
							}, function(p346)
								-- upvalues: (ref) v_u_255, (ref) v_u_62
								if v_u_255 then
									v_u_62(p346)
								end
							end)
							return
						end
						v_u_19.callQuiet("entry.switch", {
							["cmd"] = "status"
						}, function(p347)
							-- upvalues: (ref) v_u_255, (ref) v_u_62
							if v_u_255 then
								v_u_62(p347)
							end
						end)
					end
				end
			else
				return
			end
		end)
		p_u_17.gui.Destroying:Connect(function()
			-- upvalues: (copy) v_u_348
			v_u_348:Disconnect()
		end)
	end
	p_u_17.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_245
		v_u_245 = v_u_245 + 1
	end)
	v_u_8:SetAttribute("FilmEntry", string.format("marker=%s|n=%d|state=%s|kind=%s|i=%d|rows=%d", v_u_248, v_u_247, v_u_246 and (v_u_244 and "all" or "playing") or "idle", v_u_243 or "-", v_u_250, #v_u_41))
	return v_u_321
end
return v_u_7