-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmReconn

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
function v_u_4.entryText(p6) -- name: entryText
	if type(p6) ~= "table" then
		return "?"
	end
	local v7 = "#%s %s UTC  %s  %s  %s  %s  left %s  others %s  |  ghost: %s  |  park: %s  |  guard: %s  |  %s"
	local v8 = p6.n
	local v9 = v8 == nil and "-" or tostring(v8)
	local v10 = p6.t
	local v11
	if type(v10) == "number" then
		local v12 = math.floor(v10) % 86400
		v11 = ("%02d:%02d:%02d"):format(v12 // 3600, v12 % 3600 // 60, v12 % 60)
	else
		v11 = "??:??"
	end
	local v13 = p6.name
	local v14 = v13 == nil and "-" or tostring(v13)
	local v15 = p6.map
	local v16 = v15 == nil and "-" or tostring(v15)
	local v17 = p6.mode
	local v18 = v17 == nil and "-" or tostring(v17)
	local v19 = p6.free == true and "FREE raid" or "normal raid"
	local v20 = p6.left
	local v21
	if type(v20) == "number" then
		local v22 = p6.left
		v21 = ("%ds"):format((math.floor(v22)))
	else
		v21 = "?"
	end
	local v23 = p6.others
	local v24 = v23 == nil and "-" or tostring(v23)
	local v25 = p6.ghost
	local v26 = v25 == nil and "-" or tostring(v25)
	local v27 = p6.park
	local v28 = v27 == nil and "-" or tostring(v27)
	local v29 = p6.guard
	local v30 = v29 == nil and "-" or tostring(v29)
	local v31 = p6.out
	return v7:format(v9, v11, v14, v16, v18, v19, v21, v24, v26, v28, v30, v31 == nil and "-" or tostring(v31))
end
function v_u_4.lines(p32) -- name: lines
	-- upvalues: (copy) v_u_4
	local v33 = {}
	if type(p32) ~= "table" then
		table.insert(v33, {
			["name"] = "State",
			["text"] = "Reading the server ...",
			["kind"] = "muted"
		})
		return v33
	end
	local v34 = p32.flags
	local v35 = {}
	local v36 = false
	for _, v37 in type(v34) ~= "table" and {} or p32.flags do
		local v38 = v37.name
		local v39 = tostring(v38)
		local v40 = v37.value
		local v41 = v40 == true and "ON" or (v40 == false and "OFF" or tostring(v40))
		table.insert(v35, ("%s %s"):format(v39, v41))
		if v37.value == v37.default then
			continue
		end
		v36 = true
	end
	local v42 = {
		["name"] = "Switches",
		["text"] = nil,
		["kind"] = nil,
		["text"] = table.concat(v35, "  \194\183  ") .. (v36 and "   (a switch differs from the build default)" or ""),
		["kind"] = v36 and "warn" or "ok"
	}
	table.insert(v33, v42)
	local v43 = p32.stale
	if type(v43) == "table" then
		local v44 = v43.stale
		if (type(v44) == "table" and #v43.stale or 0) == 0 then
			local v45 = {
				["name"] = "Stale",
				["text"] = nil,
				["kind"] = "ok"
			}
			local v46 = v43.checked or "?"
			v45.text = ("Stale values at the start of this server: none (%s values checked)"):format((tostring(v46)))
			table.insert(v33, v45)
		else
			for _, v47 in v43.stale do
				local v48 = false
				local v49 = v43.repaired
				if type(v49) == "table" then
					for _, v50 in v43.repaired do
						if v50 ~= v47.name then
							continue
						end
						v48 = true
					end
				end
				local v51 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "warn"
				}
				local v52 = v47.name
				v51.name = "Stale_" .. tostring(v52)
				local v53 = v47.name
				local v54 = tostring(v53)
				local v55 = v47.value
				local v56 = tostring(v55)
				local v57 = v47.default
				v51.text = ("STALE VALUE %s = %s overruled the default %s (saved into the place file)%s"):format(v54, v56, tostring(v57), v48 and ": put back to the default at the start" or ": left as it is")
				table.insert(v33, v51)
			end
		end
	else
		table.insert(v33, {
			["name"] = "Stale",
			["text"] = "The stale value guard has not run in this server (Studio edit mode or an old build).",
			["kind"] = "muted"
		})
	end
	local v58 = p32.last
	local v59 = type(v58) ~= "table" and {} or p32.last
	local v60 = {
		["name"] = "HeadLast",
		["text"] = nil,
		["kind"] = "head",
		["text"] = ("Leaves in THIS server: %d"):format(#v59)
	}
	table.insert(v33, v60)
	if #v59 == 0 then
		table.insert(v33, {
			["name"] = "NoLast",
			["text"] = "Nobody has left a raid in this server yet.",
			["kind"] = "muted"
		})
	end
	for v61, v62 in v59 do
		local v63 = {
			["name"] = nil,
			["text"] = nil,
			["kind"] = "text",
			["name"] = "Last" .. v61,
			["text"] = v_u_4.entryText(v62)
		}
		table.insert(v33, v63)
	end
	local v64 = p32.mine
	local v65 = type(v64) ~= "table" and {} or p32.mine
	local v66 = {
		["name"] = "HeadMine",
		["text"] = nil,
		["kind"] = "head",
		["text"] = ("YOUR leaves from earlier raid servers (store): %d"):format(#v65)
	}
	table.insert(v33, v66)
	if #v65 == 0 then
		local v67 = {
			["name"] = "NoMine",
			["text"] = nil,
			["kind"] = "muted"
		}
		local v68
		if p32.mineWhy then
			local v69 = p32.mineWhy
			v68 = "None readable: " .. tostring(v69)
		else
			v68 = "None yet."
		end
		v67.text = v68
		table.insert(v33, v67)
	end
	for v70, v71 in v65 do
		local v72 = {
			["name"] = nil,
			["text"] = nil,
			["kind"] = "text",
			["name"] = "Mine" .. v70,
			["text"] = v_u_4.entryText(v71)
		}
		table.insert(v33, v72)
	end
	return v33
end
function v_u_4.mount(p_u_73, p_u_74, p75, p76) -- name: mount
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	local v_u_77 = type(p76) ~= "table" and {} or p76
	if type(p75) == "table" then
		local v78 = p75.color
		if type(v78) ~= "table" then
			p75 = v_u_3.Theme
		end
	else
		p75 = v_u_3.Theme
	end
	local v_u_79 = p75.color
	local v_u_80 = v_u_77.gui
	local v81 = 0
	local v_u_82 = true
	if v_u_80 then
		v_u_80.Destroying:Connect(function()
			-- upvalues: (ref) v_u_82
			v_u_82 = false
		end)
	end
	local v83 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Reconnect  \194\183  why did it (not) work",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = p_u_73,
		["color"] = v_u_79.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v84 = v_u_77.order
	local v85, v86
	if type(v84) == "function" then
		v85 = v_u_77.order()
		v86 = v81
	else
		v81 = v81 + 1
		v85 = v81
		v86 = v81
	end
	v83.LayoutOrder = v85
	local v_u_87 = v_u_3.new("Frame", {
		["Name"] = "ReconnList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, p_u_73)
	v_u_3.layout(v_u_87, "v", 2)
	local v88 = v_u_77.order
	local v89
	if type(v88) == "function" then
		v89 = v_u_77.order()
	else
		v81 = v86 + 1
		v89 = v81
		v86 = v81
	end
	v_u_87.LayoutOrder = v89
	local v_u_90 = nil
	local v_u_91 = false
	local v_u_92 = (-1 / 0)
	local v_u_93 = nil
	local v_u_94 = nil
	local function v_u_107(p_u_95) -- name: act
		-- upvalues: (ref) v_u_91, (copy) p_u_74, (ref) v_u_3, (ref) v_u_93, (copy) v_u_79, (ref) v_u_82, (ref) v_u_92, (ref) v_u_90, (ref) v_u_94, (copy) v_u_77
		if v_u_91 then
			return
		else
			local v96 = p_u_74
			if type(v96) == "function" then
				v_u_91 = true
				if not p_u_95 then
					v_u_3.setText(v_u_93, "Working ...")
					v_u_93.TextColor3 = v_u_79.text2
				end
				local function v104(p97) -- name: done
					-- upvalues: (ref) v_u_91, (ref) v_u_82, (ref) v_u_92, (ref) v_u_90, (copy) p_u_95, (ref) v_u_3, (ref) v_u_93, (ref) v_u_79, (ref) v_u_94
					v_u_91 = false
					if v_u_82 then
						v_u_92 = os.clock()
						if type(p97) == "table" then
							local v98 = p97.data
							if type(v98) == "table" then
								v_u_90 = p97.data
							end
							if not p_u_95 then
								local v99 = p97.msg or (p97.ok and "Done." or "Refused.")
								local v100 = tostring(v99)
								local v101 = p97.ok ~= true
								v_u_3.setText(v_u_93, v100)
								local v102 = v_u_93
								local v103
								if v101 then
									v103 = v_u_79.danger
								else
									v103 = v_u_79.text2
								end
								v102.TextColor3 = v103
							end
						elseif not p_u_95 then
							v_u_3.setText(v_u_93, "The server did not answer.")
							v_u_93.TextColor3 = v_u_79.danger
						end
						v_u_94(v_u_90)
					end
				end
				local v105
				if p_u_95 then
					local v106 = v_u_77.sendQuiet
					if type(v106) == "function" then
						v105 = v_u_77.sendQuiet
						v105("server.reconn", {
							["cmd"] = "status"
						}, v104)
					else
						v105 = p_u_74
						v105("server.reconn", {
							["cmd"] = "status"
						}, v104)
					end
				else
					v105 = p_u_74
					v105("server.reconn", {
						["cmd"] = "status"
					}, v104)
					return
				end
			else
				return
			end
		end
	end
	local function v108() -- name: refresh
		-- upvalues: (copy) v_u_107
		v_u_107(true)
	end
	local v109 = v_u_3.new
	local v110 = {
		["Name"] = "ReconnRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil
	}
	local v111 = UDim2.new
	local v112 = p75.touch
	v110.Size = v111(1, 0, 0, type(v112) ~= "function" and 32 or p75.touch(32))
	local v113 = v109("Frame", v110, p_u_73)
	v_u_3.layout(v113, "h", 6)
	local v114 = v_u_77.order
	local v115
	if type(v114) == "function" then
		v115 = v_u_77.order()
	else
		v81 = v86 + 1
		v115 = v81
		v86 = v81
	end
	v113.LayoutOrder = v115
	local v116 = v_u_3.button
	local v117 = {
		["parent"] = nil,
		["text"] = "REFRESH",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 120,
		["onClick"] = nil,
		["parent"] = v113
	}
	local v118 = p75.touch
	v117.height = type(v118) ~= "function" and 32 or p75.touch(32)
	function v117.onClick() -- name: onClick
		-- upvalues: (copy) v_u_107
		v_u_107(false)
	end
	v116(v117).Name = "ReconnRefresh"
	v_u_93 = v_u_3.label({
		["parent"] = nil,
		["name"] = "ReconnStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_73,
		["color"] = v_u_79.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v119 = v_u_77.order
	local v120
	if type(v119) == "function" then
		v120 = v_u_77.order()
	else
		v81 = v86 + 1
		v120 = v81
		v86 = v81
	end
	v_u_93.LayoutOrder = v120
	local v121 = v_u_3.label({
		["parent"] = nil,
		["name"] = "ReconnNote",
		["text"] = "Read only. Every leave of a raid member writes one line here and one line into the raid server log. The ghost, the Connection Guard and the park are decided in that order; the line says which one answered and why the others did not.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = p_u_73,
		["color"] = v_u_79.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	local v122 = v_u_77.order
	local v123
	if type(v122) == "function" then
		v123 = v_u_77.order()
	else
		v81 = v86 + 1
		v123 = v81
	end
	v121.LayoutOrder = v123
	v_u_94 = function(p124)
		-- upvalues: (copy) v_u_87, (ref) v_u_4, (copy) v_u_79, (ref) v_u_3, (ref) v_u_5
		for _, v125 in v_u_87:GetChildren() do
			if not v125:IsA("GuiObject") then
				continue
			end
			v125:Destroy()
		end
		for v126, v127 in v_u_4.lines(p124) do
			local v128
			if v127.kind == "ok" then
				v128 = v_u_79.success
			elseif v127.kind == "warn" then
				v128 = v_u_79.danger
			elseif v127.kind == "muted" then
				v128 = v_u_79.muted
			elseif v127.kind == "head" then
				v128 = v_u_79.accent
			else
				v128 = v_u_79.text2
			end
			local v129 = v_u_3.label
			local v130 = {
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_87
			}
			local v131 = v127.name
			v130.name = "ReconnLine_" .. tostring(v131)
			local v132 = v127.text
			v130.text = tostring(v132)
			v130.color = v128
			v130.size = UDim2.new(1, 0, 0, 0)
			v129(v130).LayoutOrder = v126
		end
		if v_u_5 then
			local v133 = type(p124) ~= "table" and {} or p124
			local v134 = v133.stale
			local v135
			if type(v134) == "table" then
				local v136 = v133.stale.stale
				v135 = type(v136) == "table" and #v133.stale.stale or 0
			else
				v135 = 0
			end
			local v137 = v_u_5
			local v138 = v133.last
			local v139 = type(v138) == "table" and #v133.last or 0
			local v140 = v133.mine
			v137:SetAttribute("FilmReconn", ("%d last|%d mine|stale=%d"):format(v139, type(v140) == "table" and #v133.mine or 0, v135))
		end
	end
	v_u_94(nil)
	if v_u_2:IsStudio() and v_u_5 then
		local v_u_142 = v_u_5:GetAttributeChangedSignal("FilmReconnCmd"):Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_107
			local v141 = v_u_5:GetAttribute("FilmReconnCmd")
			if type(v141) == "string" and v141 ~= "" then
				v_u_5:SetAttribute("FilmReconnCmd", nil)
				if v141 == "refresh" then
					v_u_107(false)
				end
			end
		end)
		if v_u_80 then
			v_u_80.Destroying:Connect(function()
				-- upvalues: (copy) v_u_142
				v_u_142:Disconnect()
			end)
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_82, (copy) v_u_80, (copy) p_u_73, (ref) v_u_91, (ref) v_u_92, (copy) p_u_74, (ref) v_u_90, (ref) v_u_3, (ref) v_u_93, (copy) v_u_79, (ref) v_u_94, (copy) v_u_77
		local v143 = false
		while v_u_82 do
			local v144 = v_u_80 == nil or v_u_80.Enabled
			if v144 then
				v144 = p_u_73.Visible
			end
			if v144 and (not v_u_91 and (not v143 or os.clock() - v_u_92 >= 6)) then
				v_u_92 = os.clock()
				if not v_u_91 then
					local v145 = p_u_74
					if type(v145) == "function" then
						v_u_91 = true
						local v_u_146 = true
						local function v154(p147) -- name: done
							-- upvalues: (ref) v_u_91, (ref) v_u_82, (ref) v_u_92, (ref) v_u_90, (copy) v_u_146, (ref) v_u_3, (ref) v_u_93, (ref) v_u_79, (ref) v_u_94
							v_u_91 = false
							if v_u_82 then
								v_u_92 = os.clock()
								if type(p147) == "table" then
									local v148 = p147.data
									if type(v148) == "table" then
										v_u_90 = p147.data
									end
									if not v_u_146 then
										local v149 = p147.msg or (p147.ok and "Done." or "Refused.")
										local v150 = tostring(v149)
										local v151 = p147.ok ~= true
										v_u_3.setText(v_u_93, v150)
										local v152 = v_u_93
										local v153
										if v151 then
											v153 = v_u_79.danger
										else
											v153 = v_u_79.text2
										end
										v152.TextColor3 = v153
									end
								elseif not v_u_146 then
									v_u_3.setText(v_u_93, "The server did not answer.")
									v_u_93.TextColor3 = v_u_79.danger
								end
								v_u_94(v_u_90)
							end
						end
						local v155 = v_u_77.sendQuiet
						local v156
						if type(v155) == "function" then
							v156 = v_u_77.sendQuiet
						else
							v156 = p_u_74
						end
						v156("server.reconn", {
							["cmd"] = "status"
						}, v154)
					end
				end
			end
			task.wait(0.5)
			v143 = v144
		end
	end)
	return {
		["refresh"] = v108,
		["paint"] = function(p157) -- name: paint
			-- upvalues: (ref) v_u_90, (ref) v_u_94
			v_u_90 = p157
			v_u_94(p157)
		end
	}
end
return v_u_4