-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuPlaySheet

local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("UserInputService")
local v_u_327 = {
	["SECTIONS"] = {
		{
			["id"] = "map",
			["label"] = "Map",
			["orders"] = nil,
			["orders"] = { 1, 2, 3 }
		},
		{
			["id"] = "difficulty",
			["label"] = "Difficulty",
			["orders"] = nil,
			["orders"] = {
				9,
				10,
				11,
				12,
				13
			}
		},
		{
			["id"] = "time",
			["label"] = "Time",
			["orders"] = nil,
			["orders"] = { 20, 21, 22 }
		},
		{
			["id"] = "kit",
			["label"] = "Kit",
			["orders"] = nil,
			["orders"] = {
				40,
				41,
				42,
				43,
				44,
				45,
				46
			}
		},
		{
			["id"] = "raid",
			["label"] = "Raid",
			["orders"] = nil,
			["orders"] = { 55, 56, 99 }
		},
		{
			["id"] = "mode",
			["label"] = "Mode",
			["orders"] = nil,
			["orders"] = { 60, 61, 62 }
		}
	},
	["REMAP"] = {
		[30] = 2,
		[31] = 3,
		[50] = 43,
		[51] = 44,
		[35] = 45,
		[36] = 46
	},
	["HIDE_ORDERS"] = {
		[5] = true,
		[6] = true
	},
	["AIR"] = 24,
	["END_SLACK"] = 8,
	["remapOrder"] = function(p3) -- name: remapOrder
		-- upvalues: (copy) v_u_327
		return v_u_327.REMAP[p3] or p3
	end,
	["sectionOfOrder"] = function(p4) -- name: sectionOfOrder
		-- upvalues: (copy) v_u_327
		for _, v5 in v_u_327.SECTIONS do
			if not table.find(v5.orders, p4) then
				continue
			end
			return v5.id
		end
		return nil
	end,
	["sectionIndex"] = function(p6) -- name: sectionIndex
		-- upvalues: (copy) v_u_327
		for v7, v8 in v_u_327.SECTIONS do
			if v8.id ~= p6 then
				continue
			end
			return v7
		end
		return 1
	end,
	["cueVisible"] = function(p9, p10, p11) -- name: cueVisible
		-- upvalues: (copy) v_u_327
		local v12
		if p10 + 4 < p9 then
			v12 = p11 < p9 - p10 - v_u_327.END_SLACK
		else
			v12 = false
		end
		return v12
	end,
	["topFadeVisible"] = function(p13, p14, p15) -- name: topFadeVisible
		local v16
		if p14 + 4 < p13 then
			v16 = p15 > 4
		else
			v16 = false
		end
		return v16
	end,
	["activeSection"] = function(p17, p18, p19, p20) -- name: activeSection
		local v21 = not p17[1] and "map" or p17[1].id
		local v22 = p18 + p19 / 3
		for _, v23 in p17 do
			if v23.y > v22 + 0.5 then
				continue
			end
			v21 = v23.id
		end
		if p20 ~= nil and (p19 + 4 < p20 and (p20 - p19 - 1 <= p18 and #p17 > 0)) then
			v21 = p17[#p17].id
		end
		return v21
	end,
	["revealPos"] = function(p24, p25, p26, p27, p28, p29) -- name: revealPos
		-- upvalues: (copy) v_u_327
		local v30 = p29 or v_u_327.AIR
		local v31 = nil
		if p24 < p26 + v30 then
			v31 = p24 - v30
		elseif p24 + p25 > p26 + p27 - v30 then
			v31 = p24 + p25 - p27 + v30
		end
		if v31 == nil then
			return nil
		end
		local v32 = p28 - p27
		local v33 = math.max(0, v32)
		return math.clamp(v31, 0, v33)
	end,
	["attach"] = function(p_u_34, p_u_35, p36) -- name: attach
		-- upvalues: (copy) v_u_327, (copy) v_u_1, (copy) v_u_2
		local v_u_37 = p_u_34.ui
		local v_u_38 = p_u_34.theme
		local v_u_39 = v_u_38.color
		local v_u_40 = p_u_34.cctx.lib
		local v_u_41 = v_u_40.PlayBriefLayout
		local v_u_42 = v_u_40.PlayBriefModel
		if type(v_u_41) ~= "table" or (type(v_u_42) ~= "table" or (type(p36) ~= "table" or (p36.col == nil or p36.scroll == nil))) then
			return nil
		end
		local v_u_43 = p36.col
		local v_u_44 = p36.scroll
		local v_u_45 = p36.colW or 440
		local v_u_46 = p36.dockH or 104
		local v_u_47 = {
			["ov"] = {}
		}
		local v_u_48 = v_u_47.ov
		local v_u_49 = v_u_37.new("Frame", {
			["Name"] = "SetupSheet",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.04,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_39.bg,
			["Size"] = UDim2.new(1, 0, 1, -(v_u_46 + 12))
		}, v_u_43)
		local v_u_50 = v_u_37.stroke(v_u_49, v_u_39.line)
		v_u_37.new("Frame", {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 4,
			["BackgroundColor3"] = v_u_39.accent,
			["Size"] = UDim2.new(1, 0, 0, 2)
		}, v_u_49)
		v_u_47.frame = v_u_49
		local v_u_51 = v_u_37.label({
			["parent"] = nil,
			["name"] = "Title",
			["text"] = nil,
			["style"] = "h2",
			["size"] = nil,
			["zindex"] = 4,
			["track"] = false,
			["parent"] = v_u_49,
			["text"] = v_u_42.T.raidSetup,
			["size"] = UDim2.fromOffset(100, 26)
		})
		local v_u_52 = v_u_37.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "",
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["zindex"] = 4,
			["track"] = false,
			["parent"] = v_u_49,
			["color"] = v_u_39.text2,
			["size"] = UDim2.fromOffset(100, 18)
		})
		local v_u_53 = v_u_37.closeIcon({
			["parent"] = nil,
			["name"] = "SetupClose",
			["size"] = 40,
			["onClick"] = nil,
			["parent"] = v_u_49,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_47
				v_u_47.close("close")
			end
		})
		v_u_53.ZIndex = 5
		local v_u_54 = v_u_37.new("Frame", {
			["Name"] = "JumpRule",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_39.line,
			["Size"] = UDim2.new(1, 0, 0, 1)
		}, v_u_49)
		local v_u_55 = v_u_37.new("ScrollingFrame", {
			["Name"] = "JumpScroll",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = 0,
			["ScrollingDirection"] = nil,
			["CanvasSize"] = nil,
			["ClipsDescendants"] = true,
			["ZIndex"] = 4,
			["ElasticBehavior"] = nil,
			["ScrollingDirection"] = Enum.ScrollingDirection.X,
			["CanvasSize"] = UDim2.fromOffset(0, 0),
			["ElasticBehavior"] = Enum.ElasticBehavior.Never
		}, v_u_49)
		local v_u_56 = v_u_37.new("Frame", {
			["Name"] = "JumpLine",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 5,
			["BackgroundColor3"] = v_u_39.accent,
			["Size"] = UDim2.fromOffset(40, 2)
		}, v_u_55)
		local v_u_57 = {}
		local v_u_58 = "map"
		local v_u_59 = 0
		local v_u_60 = true
		local v_u_61 = nil
		local v_u_62 = false
		local v_u_63 = nil
		local v_u_64 = nil
		local v_u_65 = {}
		for v66, v_u_67 in v_u_327.SECTIONS do
			local v68 = v_u_37.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Selectable"] = true,
				["ZIndex"] = 4,
				["Name"] = "Jump_" .. v_u_67.id,
				["BackgroundColor3"] = v_u_39.raised
			}, v_u_55)
			v68.SelectionImageObject = v_u_37.selectionImage()
			local v69 = v_u_37.label
			local v70 = {
				["parent"] = nil,
				["name"] = "Label",
				["text"] = nil,
				["style"] = "caps",
				["textSize"] = nil,
				["color"] = nil,
				["align"] = "center",
				["size"] = nil,
				["fit"] = true,
				["track"] = false,
				["zindex"] = 5,
				["parent"] = v68,
				["text"] = v_u_67.label
			}
			local v_u_71 = 1
			local function v72()
				-- upvalues: (ref) v_u_71, (copy) v_u_38
				v_u_71 = v_u_38.uiScale()
			end
			pcall(v72)
			local v73 = v_u_71
			local v74 = 11 / math.max(v73, 0.1)
			local v75 = math.ceil(v74)
			v70.textSize = math.max(13, v75)
			v70.color = v_u_39.text2
			v70.size = UDim2.fromScale(1, 1)
			local v_u_76 = v69(v70)
			local v77 = {
				["id"] = v_u_67.id,
				["btn"] = v68,
				["lbl"] = v_u_76
			}
			table.insert(v_u_57, v77)
			v68.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_37, (copy) v_u_38, (copy) v_u_67, (ref) v_u_58, (copy) v_u_76, (copy) v_u_39
				v_u_37.sound(v_u_38.sounds.hover)
				if v_u_67.id ~= v_u_58 then
					v_u_76.TextColor3 = v_u_39.text
				end
			end)
			v68.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_76, (copy) v_u_67, (ref) v_u_58, (copy) v_u_39
				local v78 = v_u_76
				local v79
				if v_u_67.id == v_u_58 then
					v79 = v_u_39.accent
				else
					v79 = v_u_39.text2
				end
				v78.TextColor3 = v79
			end)
			v68.Activated:Connect(function(p80)
				-- upvalues: (copy) v_u_37, (copy) v_u_38, (copy) v_u_47, (copy) v_u_67
				local v81
				if p80 == nil then
					v81 = false
				else
					local v82 = string.find
					local v83 = p80.UserInputType
					v81 = v82(tostring(v83), "Gamepad") ~= nil
				end
				v_u_37.sound(v_u_38.sounds.click)
				v_u_47.jump(v_u_67.id, v81 or v_u_37.device() == "Gamepad")
			end)
			v_u_57[v66].index = v66
		end
		local v_u_84 = v_u_37.new("Frame", {
			["Name"] = "SetupBody",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 1,
			["Position"] = UDim2.fromOffset(0, 100),
			["Size"] = UDim2.new(1, 0, 1, -100)
		}, v_u_49)
		v_u_47.body = v_u_84
		local v_u_85 = v_u_37.new("Frame", {
			["Name"] = "SetupTrack",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v_u_39.line,
			["Position"] = UDim2.new(1, 3, 0, 0),
			["Size"] = UDim2.new(0, 6, 1, 0)
		}, v_u_84)
		v_u_44.Parent = v_u_84
		v_u_44.Position = UDim2.fromOffset(0, 0)
		v_u_44.Size = UDim2.new(1, 9, 1, 0)
		v_u_44.ScrollBarThickness = 6
		v_u_44.ScrollBarImageColor3 = v_u_39.accent
		v_u_44.ScrollBarImageTransparency = 0.35
		v_u_44.ZIndex = 2
		v_u_47.scroll = v_u_44
		local v_u_86 = v_u_37.new("Frame", {
			["Name"] = "SetupFadeBottom",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Active"] = false,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_39.bgDeep,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, 48)
		}, v_u_84)
		v_u_37.new("UIGradient", {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
		}, v_u_86)
		local v_u_87 = v_u_37.new("Frame", {
			["Name"] = "SetupFadeTop",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Active"] = false,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_39.bgDeep,
			["Position"] = UDim2.fromScale(0, 0),
			["Size"] = UDim2.new(1, 0, 0, 24)
		}, v_u_84)
		v_u_37.new("UIGradient", {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
		}, v_u_87)
		local v_u_88 = v_u_37.new("Frame", {
			["Name"] = "SetupMore",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Active"] = false,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_39.raised,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -12),
			["Size"] = UDim2.fromOffset(132, 24)
		}, v_u_84)
		local v_u_89 = v_u_37.stroke(v_u_88, v_u_39.accent)
		local v_u_90 = v_u_37.icon("chevronDown", {
			["parent"] = nil,
			["name"] = "Chevron",
			["size"] = 14,
			["thickness"] = 2,
			["color"] = nil,
			["position"] = nil,
			["anchor"] = nil,
			["zindex"] = 6,
			["parent"] = v_u_88,
			["color"] = v_u_39.accent,
			["position"] = UDim2.new(0, 10, 0.5, 0),
			["anchor"] = Vector2.new(0, 0.5)
		})
		v_u_37.label({
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "caps",
			["textSize"] = 12,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["zindex"] = 6,
			["parent"] = v_u_88,
			["text"] = v_u_42.T.moreBelow,
			["color"] = v_u_39.text,
			["position"] = UDim2.fromOffset(30, 0),
			["size"] = UDim2.new(1, -36, 1, 0)
		})
		local v_u_91 = false
		local v_u_92 = nil
		local v_u_93 = false
		local function v99()
			-- upvalues: (copy) v_u_40, (ref) v_u_92, (copy) p_u_34, (copy) v_u_44, (copy) v_u_45, (copy) p_u_35
			local v94 = v_u_40.MenuPlayMode
			if type(v94) == "table" then
				local v95 = v94.build
				if type(v95) == "function" then
					local v98 = {
						["order"] = 60,
						["width"] = nil,
						["state"] = nil,
						["choose"] = nil,
						["width"] = v_u_45,
						["state"] = function() -- name: state
							-- upvalues: (ref) p_u_35
							return p_u_35.briefState()
						end,
						["choose"] = function(p96) -- name: choose
							-- upvalues: (ref) p_u_35
							local v97 = p_u_35.choose
							if type(v97) == "function" then
								p_u_35.choose("viewMode", p96)
							end
						end
					}
					v_u_92 = v94.build(p_u_34, v_u_44, v98)
				end
			end
		end
		pcall(v99)
		v_u_47.modeApi = v_u_92
		function v_u_47.metrics() -- name: metrics
			-- upvalues: (copy) v_u_48, (copy) v_u_38, (copy) v_u_45, (copy) v_u_43, (copy) p_u_34, (ref) v_u_46, (copy) v_u_41
			local v100 = v_u_48.scale
			if not v100 then
				local v101 = v_u_38.uiScale()
				v100 = math.max(v101, 0.01)
			end
			local v102 = v_u_48.colW or v_u_45
			local v103 = v_u_48.colH
			if v103 == nil then
				if v_u_43.AbsoluteSize.Y > 0 then
					v103 = v_u_43.AbsoluteSize.Y / v100
				else
					local v104 = v_u_38.refSize()
					local v105 = not p_u_34.compact()
					v103 = v104.Y - 64 - 30 - (v105 and 56 or 0) - 8
				end
			end
			local v106 = v_u_48.touch or v_u_38.touch(44)
			local v107
			if v_u_48.phone == nil then
				local v108 = v_u_38.isPhone
				if type(v108) == "function" then
					v107 = v_u_38.isPhone() == true
				else
					v107 = false
				end
			else
				v107 = v_u_48.phone
			end
			local v109 = v103 - v_u_46 - v_u_41.DOCK_GAP
			return {
				["colW"] = v102,
				["colH"] = v103,
				["dockH"] = v_u_46,
				["budget"] = v109,
				["areaH"] = v103 - v_u_46 - 12,
				["scale"] = v100,
				["touch"] = v106,
				["phone"] = v107,
				["class"] = v_u_41.classOf(v102, v109)
			}
		end
		local function v_u_113(p110) -- name: anchorOf
			-- upvalues: (ref) v_u_327, (copy) v_u_44
			for _, v111 in v_u_327.SECTIONS[v_u_327.sectionIndex(p110)].orders do
				for _, v112 in v_u_44:GetChildren() do
					if not v112:IsA("GuiObject") or (v112.LayoutOrder ~= v111 or not v112.Visible) then
						continue
					end
					return v112
				end
			end
			return nil
		end
		local function v_u_116(p114) -- name: setCue
			-- upvalues: (ref) v_u_91, (copy) v_u_86, (copy) v_u_38, (copy) v_u_48, (copy) v_u_88, (copy) v_u_89, (copy) v_u_37, (ref) v_u_59, (ref) v_u_60
			if p114 == v_u_91 then
				return
			else
				v_u_91 = p114
				v_u_86.Visible = p114
				if v_u_38.reduced() or v_u_48.instant == true then
					v_u_88.Visible = p114
					v_u_88.BackgroundTransparency = 0
					return
				elseif p114 then
					v_u_88.Visible = true
					v_u_88.BackgroundTransparency = 1
					v_u_89.Transparency = 1
					v_u_37.tween(v_u_88, {
						["BackgroundTransparency"] = 0
					}, 0.12)
					v_u_37.tween(v_u_89, {
						["Transparency"] = 0
					}, 0.12)
				else
					v_u_37.tween(v_u_88, {
						["BackgroundTransparency"] = 1
					}, 0.12)
					v_u_37.tween(v_u_89, {
						["Transparency"] = 1
					}, 0.12)
					local v_u_115 = v_u_59
					task.delay(0.13, function()
						-- upvalues: (ref) v_u_60, (ref) v_u_91, (copy) v_u_115, (ref) v_u_59, (ref) v_u_88
						if v_u_60 and (not v_u_91 and v_u_115 == v_u_59) then
							v_u_88.Visible = false
						end
					end)
				end
			end
		end
		local function v_u_131(p117) -- name: placeUnderline
			-- upvalues: (copy) v_u_57, (ref) v_u_58, (ref) v_u_61, (copy) v_u_55, (copy) v_u_38, (copy) v_u_48, (copy) v_u_56, (copy) v_u_37
			for _, v118 in v_u_57 do
				if v118.id ~= v_u_58 or (v_u_61 == nil or v_u_61.chips[v118.index] == nil) then
					continue
				end
				local v119 = v_u_61.chips[v118.index]
				local v120 = v_u_61.viewport
				if v_u_61.scrolls == true then
					local v121 = v_u_55.CanvasPosition.X
					if v119.x - v121 < 0 then
						local v122 = v119.x - 8
						v121 = math.max(0, v122)
					elseif v119.x + v119.w - v121 > v120.w then
						local v123 = v_u_61.contentW - v120.w
						local v124 = math.max(0, v123)
						local v125 = v119.x + v119.w + 8 - v120.w
						v121 = math.min(v124, v125)
					end
					v_u_55.CanvasPosition = Vector2.new(v121, 0)
				end
				local v126 = UDim2.fromOffset(v119.x + 8 - v120.x, v119.y + v119.h - 2 - v120.y)
				local v127 = UDim2.fromOffset
				local v128 = v119.w - 16
				local v129 = v127(math.max(8, v128), 2)
				if p117 or (v_u_38.reduced() or v_u_48.instant == true) then
					local v130 = v_u_56
					v_u_56.Position = v126
					v130.Size = v129
				else
					v_u_37.tween(v_u_56, {
						["Position"] = v126,
						["Size"] = v129
					}, 0.12)
				end
			end
		end
		local function v_u_135() -- name: paintChips
			-- upvalues: (copy) v_u_57, (ref) v_u_58, (copy) v_u_39, (copy) v_u_131
			for _, v132 in v_u_57 do
				local v133 = v132.lbl
				local v134
				if v132.id == v_u_58 then
					v134 = v_u_39.accent
				else
					v134 = v_u_39.text2
				end
				v133.TextColor3 = v134
			end
			v_u_131(false)
		end
		function v_u_47.update() -- name: update
			-- upvalues: (ref) v_u_60, (copy) v_u_48, (copy) v_u_38, (copy) v_u_44, (ref) v_u_327, (copy) v_u_113, (ref) v_u_58, (copy) v_u_135, (copy) v_u_85, (copy) v_u_116, (ref) v_u_62, (copy) v_u_87
			if v_u_60 then
				local v136, v137, v138
				if v_u_48.canvas == nil then
					local v139 = v_u_38.uiScale()
					local v140 = math.max(v139, 0.01)
					v136 = v_u_44.AbsoluteCanvasSize.Y / v140
					v137 = v_u_44.AbsoluteWindowSize.Y / v140
					v138 = v_u_44.CanvasPosition.Y / v140
				else
					v136 = v_u_48.canvas
					v137 = v_u_48.view or 0
					v138 = v_u_48.pos or 0
				end
				local v141 = v_u_48.anchors or {}
				if v_u_48.anchors == nil then
					for _, v142 in v_u_327.SECTIONS do
						local v143 = v_u_113(v142.id)
						if not v143 then
							continue
						end
						local v144 = {
							["id"] = v142.id
						}
						local v145 = v_u_38.uiScale()
						local v146 = math.max(v145, 0.01)
						v144.y = (v143.AbsolutePosition.Y - v_u_44.AbsolutePosition.Y + v_u_44.CanvasPosition.Y) / v146
						table.insert(v141, v144)
					end
				end
				local v147 = v_u_327.activeSection(v141, v138, v137, v136)
				if v147 ~= v_u_58 then
					v_u_58 = v147
					v_u_135()
				end
				v_u_85.Visible = v137 + 4 < v136
				local v148 = v_u_116
				local v149 = v_u_62
				if v149 then
					v149 = v_u_327.cueVisible(v136, v137, v138)
				end
				v148(v149)
				local v150 = v_u_87
				local v151 = v_u_62
				if v151 then
					v151 = v_u_327.topFadeVisible(v136, v137, v138)
				end
				v150.Visible = v151
			end
		end
		function v_u_47.layout() -- name: layout
			-- upvalues: (copy) v_u_47, (ref) v_u_93, (ref) v_u_92, (copy) p_u_35, (ref) v_u_61, (copy) v_u_41, (copy) v_u_38, (copy) v_u_51, (copy) v_u_52, (copy) v_u_53, (copy) v_u_55, (copy) v_u_57, (copy) v_u_54, (copy) v_u_84, (copy) v_u_86, (copy) v_u_87, (copy) v_u_88, (copy) v_u_44, (copy) v_u_85, (copy) v_u_131, (copy) v_u_135
			local v152 = v_u_47.metrics()
			local v153
			if v_u_92 == nil then
				v153 = false
			else
				local v154 = p_u_35.briefState
				local v155
				v153, v155 = pcall(v154)
				if v153 then
					if type(v155) == "table" and v155.showMode == true then
						v153 = v155.pvpve ~= true
					else
						v153 = false
					end
				end
			end
			v_u_93 = v153
			local v156 = v_u_41.sheet
			local v157 = v152.colW
			local v158 = v152.areaH
			local v159 = v152.class
			local v160 = v152.touch
			local v161 = v_u_93
			local v_u_162 = 1
			local function v163()
				-- upvalues: (ref) v_u_162, (ref) v_u_38
				v_u_162 = v_u_38.uiScale()
			end
			pcall(v163)
			local v164 = v_u_162
			local v165 = 11 / math.max(v164, 0.1)
			local v166 = math.ceil(v165)
			v_u_61 = v156(v157, v158, v159, v160, v161, (math.max(13, v166)))
			local v167 = v152.class == "phone"
			v_u_51.Visible = not v167
			v_u_52.Visible = not v167
			if not v167 then
				local v168 = v_u_51
				local v169 = v_u_51
				local v170 = UDim2.fromOffset(v_u_61.title.x, v_u_61.title.y)
				local v171 = UDim2.fromOffset(v_u_61.title.w, v_u_61.title.h)
				v168.Position = v170
				v169.Size = v171
				local v172 = v_u_52
				local v173 = v_u_52
				local v174 = UDim2.fromOffset(v_u_61.sub.x, v_u_61.sub.y)
				local v175 = UDim2.fromOffset(v_u_61.sub.w, v_u_61.sub.h)
				v172.Position = v174
				v173.Size = v175
			end
			local v176 = v_u_53
			local v177 = v_u_53
			local v178 = UDim2.fromOffset(v_u_61.close.x, v_u_61.close.y)
			local v179 = UDim2.fromOffset(v_u_61.close.w, v_u_61.close.h)
			v176.Position = v178
			v177.Size = v179
			local v180 = v_u_55
			local v181 = v_u_55
			local v182 = UDim2.fromOffset(v_u_61.viewport.x, v_u_61.viewport.y)
			local v183 = UDim2.fromOffset(v_u_61.viewport.w, v_u_61.viewport.h)
			v180.Position = v182
			v181.Size = v183
			local v184 = v_u_55
			local v185 = UDim2.fromOffset
			local v186 = v_u_61.contentW
			local v187 = v_u_61.viewport.w
			v184.CanvasSize = v185(math.max(v186, v187), 0)
			for _, v188 in v_u_57 do
				local v189 = v_u_61.chips[v188.index]
				v188.btn.Visible = v189 ~= nil
				if v189 == nil then
					continue
				end
				local v190 = v188.btn
				local v191 = v188.btn
				local v192 = UDim2.fromOffset(v189.x - v_u_61.viewport.x, v189.y - v_u_61.viewport.y)
				local v193 = UDim2.fromOffset(v189.w, v189.h)
				v190.Position = v192
				v191.Size = v193
			end
			if v_u_61.scrolls ~= true then
				v_u_55.CanvasPosition = Vector2.zero
			end
			v_u_54.Position = UDim2.fromOffset(0, v_u_61.body.y - 1)
			v_u_84.Position = UDim2.fromOffset(0, v_u_61.body.y)
			v_u_84.Size = UDim2.new(1, 0, 1, -v_u_61.body.y)
			v_u_86.Size = UDim2.new(1, 0, 0, v_u_61.fadeBottom.h)
			v_u_87.Size = UDim2.new(1, 0, 0, v_u_61.fadeTop.h)
			v_u_88.Size = UDim2.fromOffset(v_u_61.cue.w, v_u_61.cue.h)
			local v194 = v_u_61.cueStrip
			local v195 = tonumber(v194) or 0
			v_u_44.Size = UDim2.new(1, 9, 1, -v195)
			v_u_85.Size = UDim2.new(0, 6, 1, -v195)
			v_u_88.Position = UDim2.new(0.5, 0, 1, v195 > 0 and -4 or -12)
			v_u_131(true)
			v_u_135()
			v_u_47.update()
		end
		function v_u_47.paint() -- name: paint
			-- upvalues: (ref) v_u_60, (copy) p_u_35, (copy) v_u_52, (copy) v_u_42, (ref) v_u_92, (ref) v_u_93, (copy) v_u_47
			if v_u_60 then
				local v196 = p_u_35.briefState
				local v197, v198 = pcall(v196)
				if v197 and type(v198) == "table" then
					v_u_52.Text = v_u_42.sheetLine(v198)
					if v_u_92 ~= nil then
						local v199 = v_u_92.paint
						pcall(v199, v198)
						local v200
						if v198.showMode == true then
							v200 = v198.pvpve ~= true
						else
							v200 = false
						end
						if v200 ~= v_u_93 then
							v_u_47.layout()
							v_u_47.links()
						end
					end
				end
			end
		end
		local function v_u_205(p201) -- name: firstSelectable
			if p201 == nil then
				return nil
			end
			local v202 = { p201 }
			for _, v203 in p201:GetDescendants() do
				table.insert(v202, v203)
			end
			for _, v204 in v202 do
				if not v204:IsA("GuiObject") or (not v204.Selectable or (not v204.Visible or v204.Active == false)) then
					continue
				end
				return v204
			end
			return nil
		end
		local function v_u_208(p206) -- name: byOrder
			-- upvalues: (copy) v_u_44
			for _, v207 in v_u_44:GetChildren() do
				if not v207:IsA("GuiObject") or v207.LayoutOrder ~= p206 then
					continue
				end
				return v207
			end
			return nil
		end
		local function v_u_221(p209) -- name: sectionFocus
			-- upvalues: (copy) p_u_35, (ref) v_u_63, (copy) v_u_44, (copy) v_u_205, (copy) v_u_208, (ref) v_u_92
			local v_u_210 = nil
			local function v211()
				-- upvalues: (ref) v_u_210, (ref) p_u_35
				v_u_210 = p_u_35.briefState()
			end
			pcall(v211)
			if p209 == "map" then
				local v212
				if v_u_63 then
					v212 = v_u_63.mapField
				else
					v212 = nil
				end
				return v212
			end
			if p209 == "difficulty" and v_u_210 then
				local v213 = v_u_44:FindFirstChild("Difficulty")
				local v214
				if v213 then
					local v215 = v_u_210.difficulty
					v214 = v213:FindFirstChild((tostring(v215)))
				else
					v214 = nil
				end
				if not (v214 and (v214:IsA("GuiObject") and v214.Selectable)) then
					v214 = v_u_205(v213)
				end
				return v214
			end
			if p209 == "time" and v_u_210 then
				local v216 = v_u_44:FindFirstChild("Time")
				local v217
				if v216 then
					local v218 = v_u_210.timeOfDay
					v217 = v216:FindFirstChild((tostring(v218)))
				else
					v217 = nil
				end
				if not (v217 and (v217:IsA("GuiObject") and v217.Selectable)) then
					v217 = v_u_205(v216)
				end
				return v217
			end
			if p209 == "kit" then
				return v_u_205((v_u_208(44))) or v_u_205((v_u_208(42)))
			end
			if p209 == "raid" then
				return v_u_205((v_u_208(56)))
			end
			if p209 ~= "mode" or v_u_92 == nil then
				return nil
			end
			local v219 = v_u_92.focus
			local v220
			if v_u_210 then
				v220 = v_u_210.viewMode
			else
				v220 = nil
			end
			return v219(v220)
		end
		v_u_47.sectionFocus = v_u_221
		local function v_u_228() -- name: bodyControls
			-- upvalues: (copy) v_u_44
			local v222 = {}
			for _, v223 in v_u_44:GetDescendants() do
				if not (v223:IsA("GuiObject") and (v223.Selectable and v223.Visible)) then
					continue
				end
				local v224 = v223.Parent
				local v225 = false
				while v224 ~= nil and v224 ~= v_u_44 do
					if v224:IsA("GuiObject") and not v224.Visible then
						v225 = true
						break
					end
					v224 = v224.Parent
				end
				if v225 then
					break
				end
				table.insert(v222, v223)
			end
			table.sort(v222, function(p226, p227)
				return p226.AbsolutePosition.Y < p227.AbsolutePosition.Y
			end)
			return v222
		end
		function v_u_47.links() -- name: links
			-- upvalues: (ref) v_u_60, (copy) v_u_57, (copy) v_u_53, (copy) v_u_221, (copy) v_u_228, (ref) v_u_58, (ref) v_u_63, (ref) v_u_62
			if v_u_60 then
				local v229 = {}
				for _, v230 in v_u_57 do
					if v230.btn.Visible then
						table.insert(v229, v230)
					else
						local v231 = v230.btn
						local v232 = v230.btn
						local v233 = v230.btn
						v231.NextSelectionLeft = nil
						v232.NextSelectionRight = nil
						v233.NextSelectionDown = nil
					end
				end
				for v234, v235 in v229 do
					local v236 = v235.btn
					local v237
					if v229[v234 - 1] then
						v237 = v229[v234 - 1].btn
					else
						v237 = nil
					end
					v236.NextSelectionLeft = v237
					local v238 = v235.btn
					local v239
					if v229[v234 + 1] then
						v239 = v229[v234 + 1].btn
					else
						v239 = v_u_53
					end
					v238.NextSelectionRight = v239
					v235.btn.NextSelectionDown = v_u_221(v235.id)
				end
				v_u_53.NextSelectionLeft = v229[#v229].btn
				local v240 = v_u_228()
				local v241 = v240[1]
				local v242 = v240[#v240]
				v_u_53.NextSelectionDown = v241
				if v241 then
					for _, v243 in v_u_57 do
						if v243.id ~= v_u_58 then
							continue
						end
						v241.NextSelectionUp = v243.btn
					end
				end
				if v_u_63 and v_u_63.deployBtn then
					if v242 then
						v242.NextSelectionDown = v_u_63.deployBtn
					end
					if v_u_62 then
						v_u_63.deployBtn.NextSelectionUp = v242
					end
				end
			end
		end
		function v_u_47.isOpen() -- name: isOpen
			-- upvalues: (ref) v_u_62
			return v_u_62
		end
		function v_u_47.section() -- name: section
			-- upvalues: (ref) v_u_58
			return v_u_58
		end
		function v_u_47.jump(p244, p245) -- name: jump
			-- upvalues: (copy) v_u_113, (copy) v_u_48, (copy) v_u_38, (copy) v_u_44, (ref) v_u_327, (ref) v_u_58, (copy) v_u_135, (copy) v_u_47, (copy) v_u_221, (ref) v_u_1
			local v246 = v_u_113(p244)
			if v246 == nil then
				if v_u_327.sectionIndex(p244) == 1 then
					v_u_44.CanvasPosition = Vector2.zero
				end
			else
				local v247, v248
				if v_u_48.canvas == nil then
					local v249 = v_u_38.uiScale()
					local v250 = math.max(v249, 0.01)
					v247 = v_u_44.AbsoluteCanvasSize.Y / v250
					v248 = v_u_44.AbsoluteWindowSize.Y / v250
					local _ = v_u_44.CanvasPosition.Y / v250
				else
					v247 = v_u_48.canvas
					v248 = v_u_48.view or 0
					local _ = v_u_48.pos or 0
				end
				local v251 = v_u_38.uiScale()
				local v252 = math.max(v251, 0.01)
				local v253 = (v246.AbsolutePosition.Y - v_u_44.AbsolutePosition.Y + v_u_44.CanvasPosition.Y) / v252 - 8
				local v254 = math.max(0, v253)
				if v247 - v248 - v254 <= v_u_327.END_SLACK + 4 then
					local v255 = v247 - v248
					v254 = math.max(0, v255)
				end
				local v256 = v_u_44
				local v257 = Vector2.new
				local v258 = v_u_38.uiScale()
				v256.CanvasPosition = v257(0, v254 * math.max(v258, 0.01))
			end
			v_u_58 = p244
			v_u_135()
			v_u_47.links()
			local v259 = p245 and v_u_221(p244)
			if v259 then
				v_u_1.SelectedObject = v259
			end
			v_u_47.update()
		end
		function v_u_47.open(p260, p261) -- name: open
			-- upvalues: (ref) v_u_60, (ref) v_u_1, (copy) v_u_43, (ref) v_u_64, (ref) v_u_62, (ref) v_u_59, (copy) v_u_47, (copy) p_u_35, (copy) v_u_49, (copy) v_u_38, (copy) v_u_48, (copy) v_u_50, (copy) v_u_37, (copy) v_u_44, (ref) v_u_91, (copy) v_u_90
			if not v_u_60 then
				return false
			end
			local v_u_262 = p260 or "map"
			local v263 = v_u_1.SelectedObject
			local v_u_264
			if v263 == nil then
				v_u_264 = false
			else
				v_u_264 = v263:IsDescendantOf(v_u_43)
			end
			if p261 then
				v263 = p261
			elseif not v_u_264 then
				v263 = nil
			end
			v_u_64 = v263
			local v265 = v_u_62
			v_u_62 = true
			v_u_59 = v_u_59 + 1
			local v_u_266 = v_u_59
			v_u_47.layout()
			v_u_47.paint()
			if p_u_35.brief and p_u_35.brief.setHidden then
				p_u_35.brief.setHidden(true)
			end
			v_u_49.Visible = true
			if v_u_38.reduced() or (v_u_48.instant == true and true or v265) then
				v_u_49.Position = UDim2.fromOffset(0, 0)
				v_u_50.Transparency = 0
			else
				v_u_49.Position = UDim2.fromOffset(16, 0)
				v_u_50.Transparency = 1
				v_u_37.tween(v_u_49, {
					["Position"] = UDim2.fromOffset(0, 0)
				}, 0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				v_u_37.tween(v_u_50, {
					["Transparency"] = 0
				}, 0.16)
			end
			v_u_44.CanvasPosition = Vector2.zero
			task.defer(function()
				-- upvalues: (ref) v_u_60, (ref) v_u_62, (copy) v_u_266, (ref) v_u_59, (ref) v_u_47, (copy) v_u_262, (copy) v_u_264, (ref) v_u_37, (ref) v_u_38, (ref) v_u_48, (ref) v_u_91, (ref) v_u_90
				if v_u_60 and (v_u_62 and v_u_266 == v_u_59) then
					v_u_47.jump(v_u_262, v_u_264 or v_u_37.device() == "Gamepad")
					if not v_u_38.reduced() and (v_u_48.instant ~= true and v_u_91) then
						task.delay(0, function()
							-- upvalues: (ref) v_u_60, (ref) v_u_62, (ref) v_u_266, (ref) v_u_59, (ref) v_u_37, (ref) v_u_90
							if v_u_60 and (v_u_62 and v_u_266 == v_u_59) then
								v_u_37.tween(v_u_90, {
									["Position"] = UDim2.new(0, 10, 0.5, 3)
								}, 0.2)
								task.delay(0.25, function()
									-- upvalues: (ref) v_u_60, (ref) v_u_90, (ref) v_u_37
									if v_u_60 and v_u_90.Parent then
										v_u_37.tween(v_u_90, {
											["Position"] = UDim2.new(0, 10, 0.5, 0)
										}, 0.2)
									end
								end)
							end
						end)
						task.delay(0.6, function()
							-- upvalues: (ref) v_u_60, (ref) v_u_62, (ref) v_u_266, (ref) v_u_59, (ref) v_u_37, (ref) v_u_90
							if v_u_60 and (v_u_62 and v_u_266 == v_u_59) then
								v_u_37.tween(v_u_90, {
									["Position"] = UDim2.new(0, 10, 0.5, 3)
								}, 0.2)
								task.delay(0.25, function()
									-- upvalues: (ref) v_u_60, (ref) v_u_90, (ref) v_u_37
									if v_u_60 and v_u_90.Parent then
										v_u_37.tween(v_u_90, {
											["Position"] = UDim2.new(0, 10, 0.5, 0)
										}, 0.2)
									end
								end)
							end
						end)
					end
				end
			end)
			v_u_47.jump(v_u_262, false)
			local v_u_267 = "open " .. v_u_262
			pcall(function()
				-- upvalues: (copy) v_u_267
				game:GetService("Players").LocalPlayer:SetAttribute("MenuPlaySheet", v_u_267)
			end)
			return true
		end
		function v_u_47.close(p268) -- name: close
			-- upvalues: (ref) v_u_62, (ref) v_u_59, (ref) v_u_1, (copy) v_u_49, (ref) v_u_64, (copy) v_u_116, (copy) v_u_87, (copy) p_u_35, (copy) v_u_38, (copy) v_u_48, (copy) v_u_37, (copy) v_u_50, (ref) v_u_60, (ref) v_u_63
			if not v_u_62 then
				return false
			end
			v_u_62 = false
			v_u_59 = v_u_59 + 1
			local v_u_269 = v_u_59
			local v270 = v_u_1.SelectedObject
			local v271
			if v270 == nil then
				v271 = false
			else
				v271 = v270:IsDescendantOf(v_u_49)
			end
			local v_u_272 = v_u_64
			v_u_64 = nil
			v_u_116(false)
			v_u_87.Visible = false
			if p_u_35.brief and p_u_35.brief.setHidden then
				p_u_35.brief.setHidden(false)
			end
			if v_u_38.reduced() or v_u_48.instant == true then
				v_u_49.Visible = false
			else
				v_u_37.tween(v_u_49, {
					["Position"] = UDim2.fromOffset(16, 0)
				}, 0.12)
				v_u_37.tween(v_u_50, {
					["Transparency"] = 1
				}, 0.12)
				task.delay(0.13, function()
					-- upvalues: (ref) v_u_60, (ref) v_u_62, (copy) v_u_269, (ref) v_u_59, (ref) v_u_49
					if v_u_60 and (not v_u_62 and v_u_269 == v_u_59) then
						v_u_49.Visible = false
						v_u_49.Position = UDim2.fromOffset(0, 0)
					end
				end)
			end
			if v_u_63 and (v_u_63.deployBtn and (p_u_35.brief and p_u_35.brief.links)) then
				local v273 = p_u_35.brief.links
				pcall(v273)
			end
			if v271 or (p268 == "pad" or p268 == "x") then
				local function v_u_275() -- name: put
					-- upvalues: (copy) v_u_272, (ref) p_u_35, (ref) v_u_1
					local v274 = v_u_272
					if v274 == nil or (v274.Parent == nil or not (v274.Visible and v274.Selectable)) then
						if p_u_35.brief and p_u_35.brief.first then
							v274 = p_u_35.brief.first()
						else
							v274 = nil
						end
					end
					if v274 ~= nil and (v274.Parent ~= nil and (v274:IsA("GuiObject") and v274.Selectable)) then
						v_u_1.SelectedObject = v274
					end
				end
				task.defer(function()
					-- upvalues: (copy) v_u_275, (ref) v_u_1, (ref) v_u_49
					v_u_275()
					task.defer(function()
						-- upvalues: (ref) v_u_1, (ref) v_u_49, (ref) v_u_275
						if v_u_1.SelectedObject == nil or v_u_1.SelectedObject:IsDescendantOf(v_u_49) then
							v_u_275()
						end
					end)
				end)
			end
			local v_u_276 = "close " .. tostring(p268)
			pcall(function()
				-- upvalues: (copy) v_u_276
				game:GetService("Players").LocalPlayer:SetAttribute("MenuPlaySheet", v_u_276)
			end)
			return true
		end
		function v_u_47.reveal(p277) -- name: reveal
			-- upvalues: (ref) v_u_60, (ref) v_u_62, (copy) v_u_44, (copy) v_u_48, (copy) v_u_38, (ref) v_u_327
			if v_u_60 and (v_u_62 and (p277 ~= nil and (p277:IsA("GuiObject") and p277:IsDescendantOf(v_u_44)))) then
				local v278, v279, v280
				if v_u_48.canvas == nil then
					local v281 = v_u_38.uiScale()
					local v282 = math.max(v281, 0.01)
					v278 = v_u_44.AbsoluteCanvasSize.Y / v282
					v279 = v_u_44.AbsoluteWindowSize.Y / v282
					v280 = v_u_44.CanvasPosition.Y / v282
				else
					v278 = v_u_48.canvas
					v279 = v_u_48.view or 0
					v280 = v_u_48.pos or 0
				end
				local v283 = v_u_327.revealPos
				local v284 = v_u_38.uiScale()
				local v285 = math.max(v284, 0.01)
				local v286 = (p277.AbsolutePosition.Y - v_u_44.AbsolutePosition.Y + v_u_44.CanvasPosition.Y) / v285
				local v287 = p277.AbsoluteSize.Y
				local v288 = v_u_38.uiScale()
				local v289 = v283(v286, v287 / math.max(v288, 0.01), v280, v279, v278, v_u_327.AIR)
				if v289 ~= nil then
					local v290 = v_u_44
					local v291 = Vector2.new
					local v292 = v_u_38.uiScale()
					v290.CanvasPosition = v291(0, v289 * math.max(v292, 0.01))
				end
			end
		end
		function v_u_47.setDockH(p293) -- name: setDockH
			-- upvalues: (ref) v_u_46, (copy) v_u_49, (copy) p_u_35, (copy) v_u_47
			v_u_46 = p293
			v_u_49.Size = UDim2.new(1, 0, 1, -(p293 + 12))
			if p_u_35.brief and p_u_35.brief.setDockH then
				local v294 = p_u_35.brief.setDockH
				pcall(v294, p293)
			end
			v_u_47.layout()
		end
		function v_u_47.dock(p295) -- name: dock
			-- upvalues: (ref) v_u_63, (copy) v_u_44, (ref) v_u_327, (copy) v_u_47
			v_u_63 = p295
			for _, v296 in v_u_44:GetChildren() do
				if not v296:IsA("GuiObject") then
					continue
				end
				local v297 = v296.LayoutOrder
				if v_u_327.HIDE_ORDERS[v297] then
					v296.Visible = false
				else
					v296.LayoutOrder = v_u_327.remapOrder(v297)
				end
			end
			if p295.moreFade then
				p295.moreFade.Visible = false
			end
			v_u_47.layout()
			v_u_47.links()
		end
		function v_u_47.onPad(p298) -- name: onPad
			-- upvalues: (ref) v_u_60, (ref) v_u_62, (copy) v_u_47, (ref) v_u_1, (copy) p_u_35, (copy) v_u_43, (copy) v_u_37
			if not v_u_60 then
				return false
			end
			if p298 == "ButtonX" then
				if v_u_62 then
					v_u_47.close("x")
					return true
				end
				local v299 = v_u_1.SelectedObject
				if p_u_35.shown == true and (v299 ~= nil and v299:IsDescendantOf(v_u_43)) then
					local v300 = v_u_37.modalCount
					local v301, v302 = pcall(v300)
					if v301 then
						if type(v302) == "number" then
							v301 = v302 > 0
						else
							v301 = false
						end
					end
					if not v301 then
						local v303
						if p_u_35.globe == nil or p_u_35.globe.isOpen == nil then
							v303 = false
						else
							v303 = p_u_35.globe.isOpen() == true
						end
						if not v303 then
							v_u_47.open("map", v299)
							return true
						end
					end
				end
			end
			return false
		end
		local v_u_304 = nil
		local function v305()
			-- upvalues: (ref) v_u_304, (copy) v_u_40
			v_u_304 = v_u_40.VirtualPad
		end
		pcall(v305)
		if v_u_304 and v_u_304.InputBegan then
			local v306 = v_u_304.InputBegan
			table.insert(v_u_65, v306:Connect(function(p307)
				-- upvalues: (copy) v_u_47
				if p307.KeyCode == Enum.KeyCode.ButtonX then
					v_u_47.onPad("ButtonX")
				end
			end))
		end
		local v308 = v_u_2.InputBegan
		table.insert(v_u_65, v308:Connect(function(p309)
			-- upvalues: (ref) v_u_62, (copy) p_u_35, (copy) v_u_37, (copy) v_u_47
			if p309.UserInputType == Enum.UserInputType.Keyboard and (p309.KeyCode == Enum.KeyCode.Escape and (v_u_62 and p_u_35.shown == true)) then
				local v310 = v_u_37.modalCount
				local v311, v312 = pcall(v310)
				if v311 then
					if type(v312) == "number" then
						v311 = v312 > 0
					else
						v311 = false
					end
				end
				if not v311 then
					local v313
					if p_u_35.globe == nil or p_u_35.globe.isOpen == nil then
						v313 = false
					else
						v313 = p_u_35.globe.isOpen() == true
					end
					if not v313 then
						v_u_47.close("escape")
						if v_u_37.takeBack then
							v_u_37.takeBack()
						end
					end
				end
			end
		end))
		local v314 = v_u_1:GetPropertyChangedSignal("SelectedObject")
		local function v315()
			-- upvalues: (ref) v_u_62, (copy) v_u_47, (ref) v_u_1
			if v_u_62 then
				v_u_47.reveal(v_u_1.SelectedObject)
			end
		end
		table.insert(v_u_65, v314:Connect(v315))
		local v_u_316 = v_u_92
		local v_u_317 = v_u_91
		for _, v318 in { "CanvasPosition", "AbsoluteCanvasSize", "AbsoluteWindowSize" } do
			local v319 = v_u_44:GetPropertyChangedSignal(v318)
			local v320 = v_u_47.update
			table.insert(v_u_65, v319:Connect(v320))
		end
		local v321 = v_u_43:GetPropertyChangedSignal("AbsoluteSize")
		table.insert(v_u_65, v321:Connect(function()
			-- upvalues: (ref) v_u_60, (copy) v_u_47, (copy) p_u_35
			if v_u_60 then
				v_u_47.layout()
				if p_u_35.brief and p_u_35.brief.relayout then
					local v322 = p_u_35.brief.relayout
					pcall(v322)
				end
			end
		end))
		function v_u_47.state() -- name: state
			-- upvalues: (ref) v_u_62, (ref) v_u_58, (ref) v_u_317, (copy) v_u_85, (copy) v_u_87, (copy) v_u_49, (ref) v_u_61
			return {
				["open"] = v_u_62,
				["section"] = v_u_58,
				["cue"] = v_u_317,
				["track"] = v_u_85.Visible,
				["fadeTop"] = v_u_87.Visible,
				["visible"] = v_u_49.Visible,
				["layout"] = v_u_61
			}
		end
		function v_u_47.destroy(p323) -- name: destroy
			-- upvalues: (ref) v_u_60, (copy) v_u_65, (ref) v_u_316, (copy) v_u_44, (copy) v_u_43, (ref) v_u_46, (copy) v_u_38, (copy) v_u_39, (copy) v_u_49
			v_u_60 = false
			for _, v_u_324 in v_u_65 do
				pcall(function()
					-- upvalues: (copy) v_u_324
					v_u_324:Disconnect()
				end)
			end
			table.clear(v_u_65)
			if v_u_316 ~= nil then
				local v325 = v_u_316.destroy
				pcall(v325)
			end
			if p323 then
				v_u_44.Parent = v_u_43
				v_u_44.Position = UDim2.fromOffset(0, 0)
				v_u_44.Size = UDim2.new(1, 9, 1, -v_u_46 - 12)
				v_u_44.ScrollBarThickness = v_u_38.scrollBar
				v_u_44.ScrollBarImageColor3 = v_u_39.lineStrong
				v_u_44.ScrollBarImageTransparency = 0.2
			end
			local function v326()
				-- upvalues: (ref) v_u_49
				v_u_49:Destroy()
			end
			pcall(v326)
		end
		v_u_47.layout()
		return v_u_47
	end
}
return v_u_327