-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmEco

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = v_u_3.Theme
local v_u_5 = v_u_4.color
local v_u_6 = {}
local v_u_7 = v1.LocalPlayer
local v_u_8 = {
	{ 1, "1 day" },
	{ 7, "7 days" },
	{ 14, "14 days" }
}
local function v_u_14(p9) -- name: commas
	local v10 = math.abs(p9) + 0.5
	local v11 = math.floor(v10)
	local v12 = tostring(v11)
	local v13 = string.reverse((string.gsub(string.reverse(v12), "(%d%d%d)", "%1,")))
	if string.sub(v13, 1, 1) == "," then
		v13 = string.sub(v13, 2)
	end
	return (p9 < 0 and "-" or "") .. v13
end
function v_u_6.short(p15) -- name: short
	-- upvalues: (copy) v_u_14
	local v16 = math.abs(p15)
	local v17 = p15 < 0 and "-" or ""
	if v16 >= 1000000 then
		return ("%s$%.2fM"):format(v17, v16 / 1000000)
	elseif v16 >= 10000 then
		return ("%s$%.1fk"):format(v17, v16 / 1000)
	else
		return v17 .. "$" .. v_u_14(v16)
	end
end
local function v_u_33(p18, p19, p20, p21, p22) -- name: flowRows
	-- upvalues: (copy) v_u_6
	local v23 = {
		["name"] = nil,
		["text"] = nil,
		["kind"] = "head",
		["name"] = "Head_" .. p19,
		["text"] = ("%s  \194\183  %s"):format(string.upper(p19), v_u_6.short(p21))
	}
	table.insert(p18, v23)
	if #p20 == 0 then
		local v24 = {
			["name"] = nil,
			["text"] = "nothing recorded",
			["kind"] = "muted",
			["name"] = "Empty_" .. p19
		}
		table.insert(p18, v24)
	else
		for _, v25 in p20 do
			local v26 = {}
			local v27 = v25.reason
			v26.name = "Flow_" .. tostring(v27)
			local v28 = v25.reason
			local v29 = tostring(v28)
			local v30 = v25.n
			local v31 = v_u_6.short(v25.sum)
			local v32 = v25.share * 100 + 0.5
			v26.text = ("%-15s %6d %8s %4s %8s"):format(v29, v30, v31, ("%d%%"):format((math.floor(v32))), not v25.perHour and "-" or v_u_6.short(v25.perHour) .. "/h")
			v26.kind = p22
			table.insert(p18, v26)
		end
	end
end
function v_u_6.rows(p34) -- name: rows
	-- upvalues: (copy) v_u_33, (copy) v_u_6
	local v35 = {}
	if type(p34) == "table" then
		local v36 = p34.report
		if type(v36) == "table" then
			local v37 = p34.report
			local v38 = {
				["name"] = "State",
				["text"] = nil,
				["kind"] = "text",
				["wrap"] = true
			}
			local v39 = p34.enabled and "ON" or "OFF (no new data)"
			local v40 = v37.store
			local v41 = tostring(v40)
			local v42 = v37.backend
			v38.text = ("EcoLog %s  \194\183  %s %s  \194\183  %d of %d day(s) with data  \194\183  %.2f player hours"):format(v39, v41, tostring(v42), v37.found, v37.days, v37.playerHours)
			table.insert(v35, v38)
			v_u_33(v35, "Cash in", v37.sources, v37.totalIn, "in")
			v_u_33(v35, "Cash out", v37.sinks, v37.totalOut, "out")
			local v43 = {
				["name"] = "Net",
				["text"] = nil,
				["kind"] = "head"
			}
			local v44 = v37.net >= 0 and "+" or "-"
			local v45 = v_u_6.short
			local v46 = v37.net
			v43.text = ("NET CASH  %s%s%s"):format(v44, v45((math.abs(v46))), v37.playerHours < 0.05 and "" or ("   %s/h per player hour"):format(v_u_6.short(v37.net / v37.playerHours)))
			table.insert(v35, v43)
			if #v37.topSinks > 0 then
				local v47 = {}
				for v48, v49 in v37.topSinks do
					local v50 = v49.reason
					local v51 = v_u_6.short
					local v52 = v49.sum
					table.insert(v47, ("%d %s %s"):format(v48, v50, v51(v52)))
				end
				local v53 = {
					["name"] = "TopSinks",
					["text"] = nil,
					["kind"] = "text",
					["wrap"] = true,
					["text"] = "Top sinks  " .. table.concat(v47, "  ")
				}
				table.insert(v35, v53)
			end
			table.insert(v35, {
				["name"] = "Head_Raids",
				["text"] = "INCOME PER RAID HOUR",
				["kind"] = "head"
			})
			if #v37.byDifficulty == 0 then
				table.insert(v35, {
					["name"] = "Empty_Raids",
					["text"] = "no raid recorded",
					["kind"] = "muted"
				})
			end
			for _, v54 in v37.byDifficulty do
				local v55 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "text",
					["wrap"] = true
				}
				local v56 = v54.difficulty
				v55.name = "Raid_" .. tostring(v56)
				local v57 = v54.difficulty
				local v58 = tostring(v57)
				local v59 = v54.raids
				local v60 = v54.extractRate * 100 + 0.5
				v55.text = ("%-9s %4d raids  %4s extracted  FIR %8s/h  cash %8s/h"):format(v58, v59, ("%d%%"):format((math.floor(v60))), v_u_6.short(v54.firPerHour), v_u_6.short(v54.cashPerHour))
				table.insert(v35, v55)
				local v61 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "muted"
				}
				local v62 = v54.difficulty
				v61.name = "Kit_" .. tostring(v62)
				v61.text = ("          avg %.1f min  FIR per raid %s  kit lost per death %s"):format(v54.avgMinutes, v_u_6.short(v54.firPerRaid), v_u_6.short(v54.kitLostPerDeath))
				table.insert(v35, v61)
			end
			if #v37.items > 0 then
				v_u_33(v35, "Item value", v37.items, v37.totalItems, "text")
			end
			if v37.other then
				local v63 = {
					["name"] = "Other",
					["text"] = nil,
					["kind"] = "muted",
					["text"] = ("OTHER (unknown reason)  n=%d  %s"):format(v37.other.n, v_u_6.short(v37.other.sum))
				}
				table.insert(v35, v63)
			end
			local v64 = {}
			for _, v65 in v37.funnel do
				local v66 = v65.index
				local v67 = v65.step
				local v68 = v65.n
				table.insert(v64, ("%d %s %d"):format(v66, v67, v68))
			end
			local v69 = {
				["name"] = "Funnel",
				["text"] = nil,
				["kind"] = "muted",
				["wrap"] = true,
				["text"] = "Funnel  " .. table.concat(v64, "  \194\183  ")
			}
			table.insert(v35, v69)
			return v35
		end
	end
	return v35
end
function v_u_6.build(p_u_70) -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v_u_71 = p_u_70.body
	local v_u_72 = true
	p_u_70.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_72
		v_u_72 = false
	end)
	local function v73()
		-- upvalues: (ref) v_u_2
		return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Net")))
	end
	local v74, v_u_75 = pcall(v73)
	if not v74 then
		v_u_75 = nil
	end
	v_u_3.label({
		["parent"] = nil,
		["text"] = "Economy  \194\183  money flows",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_71,
		["color"] = v_u_5.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	}).LayoutOrder = p_u_70.order()
	local v76 = v_u_3.new("Frame", {
		["Name"] = "EcoBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_4.touch(32))
	}, v_u_71)
	v76.LayoutOrder = p_u_70.order()
	v_u_3.layout(v76, "h", 6)
	local v_u_77 = v_u_3.new("Frame", {
		["Name"] = "EcoList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_71)
	v_u_3.layout(v_u_77, "v", 2)
	v_u_77.LayoutOrder = p_u_70.order()
	local v_u_78 = v_u_3.label({
		["parent"] = nil,
		["name"] = "EcoStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_71,
		["color"] = v_u_5.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_78.LayoutOrder = p_u_70.order()
	v_u_3.label({
		["parent"] = nil,
		["name"] = "EcoNote",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["text"] = "Per hour = per player hour online. Counters of this server that are not flushed yet are included, other servers\' are not (they flush every 5 minutes).",
		["parent"] = v_u_71,
		["color"] = v_u_5.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	}).LayoutOrder = p_u_70.order()
	local v_u_79 = 7
	local v_u_80 = false
	local v_u_81 = nil
	local v_u_82 = 0
	local v_u_83 = {}
	local function v_u_99(p84) -- name: paint
		-- upvalues: (ref) v_u_6, (copy) v_u_77, (copy) v_u_83, (ref) v_u_5, (ref) v_u_3, (ref) v_u_7
		local v85 = v_u_6.rows(p84)
		for _, v86 in v_u_77:GetChildren() do
			if not v86:IsA("GuiObject") then
				continue
			end
			v86:Destroy()
		end
		table.clear(v_u_83)
		for v87, v88 in v85 do
			local v89 = v88.kind == "head" and "caps" or "monoS"
			local v90
			if v88.kind == "head" then
				v90 = v_u_5.accent
			elseif v88.kind == "in" then
				v90 = v_u_5.success
			elseif v88.kind == "out" then
				v90 = v_u_5.danger
			elseif v88.kind == "muted" then
				v90 = v_u_5.muted
			else
				v90 = v_u_5.text2
			end
			local v91
			if v88.wrap then
				v91 = v_u_3.label({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = nil,
					["color"] = nil,
					["size"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["parent"] = v_u_77,
					["name"] = v88.name,
					["text"] = v88.text,
					["style"] = v89,
					["color"] = v90,
					["size"] = UDim2.new(1, 0, 0, 0)
				})
			else
				v91 = v_u_3.label({
					["parent"] = v_u_77,
					["name"] = v88.name,
					["text"] = v88.text,
					["style"] = v89,
					["color"] = v90,
					["size"] = UDim2.new(1, 0, 0, v88.kind == "head" and 20 or 16)
				})
				v91.TextTruncate = Enum.TextTruncate.AtEnd
			end
			v91.LayoutOrder = v87
			v_u_83[v88.name] = v91
		end
		local v92 = p84.report
		local v93 = v_u_7
		local v94 = p84.days
		local v95 = #v92.sources
		local v96 = #v92.sinks
		local v97 = #v92.byDifficulty
		local v98 = p84.enabled == true
		v93:SetAttribute("FilmEco", ("%s|%d|%d|%d|%d|%s"):format("1", v94, v95, v96, v97, (tostring(v98))))
	end
	local function v_u_123(p100) -- name: fetch
		-- upvalues: (ref) v_u_79, (ref) v_u_80, (ref) v_u_75, (ref) v_u_3, (copy) v_u_78, (ref) v_u_5, (ref) v_u_72, (ref) v_u_81, (ref) v_u_82, (ref) v_u_7, (copy) v_u_99
		if p100 then
			v_u_79 = p100
		end
		if not v_u_80 and v_u_75 then
			v_u_80 = true
			local v101, v102 = ("Reading the last %d day(s) ..."):format(v_u_79)
			v_u_3.setText(v_u_78, v101)
			local v103 = v_u_78
			local v104
			if v102 then
				v104 = v_u_5.danger
			else
				v104 = v_u_5.text2
			end
			v103.TextColor3 = v104
			task.spawn(function()
				-- upvalues: (ref) v_u_75, (ref) v_u_79, (ref) v_u_80, (ref) v_u_72, (ref) v_u_81, (ref) v_u_82, (ref) v_u_7, (ref) v_u_99, (ref) v_u_3, (ref) v_u_78, (ref) v_u_5
				local v105 = v_u_75.invoke
				local v106 = {
					["days"] = v_u_79
				}
				local v107, v108 = pcall(v105, "eco.report", v106)
				v_u_80 = false
				if v_u_72 then
					if v107 and (type(v108) == "table" and v108.ok == true) then
						local v109 = v108.report
						if type(v109) == "table" then
							local v110 = os.clock()
							v_u_81 = v108
							v_u_82 = v110
							v_u_7:SetAttribute("FilmEcoError", nil)
							v_u_99(v108)
							local v111 = "Last %d day(s), read %s.%s"
							local v112 = v108.days
							local v113 = os.date("%H:%M:%S")
							local v114
							if v108.err then
								local v115 = v108.err
								v114 = " Store read stopped: " .. tostring(v115)
							else
								v114 = ""
							end
							local v116 = v111:format(v112, v113, v114)
							local v117 = v108.err ~= nil
							v_u_3.setText(v_u_78, v116)
							local v118 = v_u_78
							local v119
							if v117 then
								v119 = v_u_5.danger
							else
								v119 = v_u_5.text2
							end
							v118.TextColor3 = v119
							return
						end
					end
					local v120
					if v107 and type(v108) == "table" then
						local v121 = v108.msg or "no data"
						v120 = tostring(v121)
					else
						v120 = "the server did not answer"
					end
					v_u_7:SetAttribute("FilmEcoError", v120)
					local v122 = "No economy data: " .. v120
					v_u_3.setText(v_u_78, v122)
					v_u_78.TextColor3 = v_u_5.danger
				end
			end)
		end
	end
	local v_u_124 = v_u_82
	local v_u_125 = v_u_81
	local v_u_126 = v_u_72
	local v_u_127 = v_u_79
	local v_u_128 = v_u_80
	for _, v_u_129 in v_u_8 do
		v_u_3.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "ghost",
			["height"] = 32,
			["width"] = 92,
			["maxTextWidth"] = 80,
			["onClick"] = nil,
			["parent"] = v76,
			["text"] = v_u_129[2],
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_123, (copy) v_u_129
				v_u_123(v_u_129[1])
			end
		}).Name = "EcoDays" .. v_u_129[1]
	end
	local v152 = {
		["parent"] = nil,
		["text"] = "Refresh",
		["kind"] = "secondary",
		["height"] = 32,
		["width"] = 110,
		["maxTextWidth"] = 98,
		["onClick"] = nil,
		["parent"] = v76,
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_128, (ref) v_u_75, (ref) v_u_127, (ref) v_u_3, (copy) v_u_78, (ref) v_u_5, (ref) v_u_126, (ref) v_u_125, (ref) v_u_124, (ref) v_u_7, (copy) v_u_99
			if not v_u_128 then
				if not v_u_75 then
					return
				end
				v_u_128 = true
				local v130, v131 = ("Reading the last %d day(s) ..."):format(v_u_127)
				v_u_3.setText(v_u_78, v130)
				local v132 = v_u_78
				local v133
				if v131 then
					v133 = v_u_5.danger
				else
					v133 = v_u_5.text2
				end
				v132.TextColor3 = v133
				task.spawn(function()
					-- upvalues: (ref) v_u_75, (ref) v_u_127, (ref) v_u_128, (ref) v_u_126, (ref) v_u_125, (ref) v_u_124, (ref) v_u_7, (ref) v_u_99, (ref) v_u_3, (ref) v_u_78, (ref) v_u_5
					local v134 = v_u_75.invoke
					local v135 = {
						["days"] = v_u_127
					}
					local v136, v137 = pcall(v134, "eco.report", v135)
					v_u_128 = false
					if v_u_126 then
						if v136 and (type(v137) == "table" and v137.ok == true) then
							local v138 = v137.report
							if type(v138) == "table" then
								local v139 = os.clock()
								v_u_125 = v137
								v_u_124 = v139
								v_u_7:SetAttribute("FilmEcoError", nil)
								v_u_99(v137)
								local v140 = "Last %d day(s), read %s.%s"
								local v141 = v137.days
								local v142 = os.date("%H:%M:%S")
								local v143
								if v137.err then
									local v144 = v137.err
									v143 = " Store read stopped: " .. tostring(v144)
								else
									v143 = ""
								end
								local v145 = v140:format(v141, v142, v143)
								local v146 = v137.err ~= nil
								v_u_3.setText(v_u_78, v145)
								local v147 = v_u_78
								local v148
								if v146 then
									v148 = v_u_5.danger
								else
									v148 = v_u_5.text2
								end
								v147.TextColor3 = v148
								return
							end
						end
						local v149
						if v136 and type(v137) == "table" then
							local v150 = v137.msg or "no data"
							v149 = tostring(v150)
						else
							v149 = "the server did not answer"
						end
						v_u_7:SetAttribute("FilmEcoError", v149)
						local v151 = "No economy data: " .. v149
						v_u_3.setText(v_u_78, v151)
						v_u_78.TextColor3 = v_u_5.danger
					end
				end)
			end
		end
	}
	v_u_3.button(v152).Name = "EcoRefresh"
	task.spawn(function()
		-- upvalues: (ref) v_u_126, (copy) p_u_70, (copy) v_u_71, (ref) v_u_124, (ref) v_u_128, (ref) v_u_75, (ref) v_u_127, (ref) v_u_3, (copy) v_u_78, (ref) v_u_5, (ref) v_u_125, (ref) v_u_7, (copy) v_u_99
		local v153 = false
		while v_u_126 do
			local v154 = p_u_70.gui.Enabled
			if v154 then
				v154 = v_u_71.Visible
			end
			if v154 and (not v153 or os.clock() - v_u_124 >= 30) then
				v_u_124 = os.clock()
				if not v_u_128 and v_u_75 then
					v_u_128 = true
					local v155, v156 = ("Reading the last %d day(s) ..."):format(v_u_127)
					v_u_3.setText(v_u_78, v155)
					local v157 = v_u_78
					local v158
					if v156 then
						v158 = v_u_5.danger
					else
						v158 = v_u_5.text2
					end
					v157.TextColor3 = v158
					task.spawn(function()
						-- upvalues: (ref) v_u_75, (ref) v_u_127, (ref) v_u_128, (ref) v_u_126, (ref) v_u_125, (ref) v_u_124, (ref) v_u_7, (ref) v_u_99, (ref) v_u_3, (ref) v_u_78, (ref) v_u_5
						local v159 = v_u_75.invoke
						local v160 = {
							["days"] = v_u_127
						}
						local v161, v162 = pcall(v159, "eco.report", v160)
						v_u_128 = false
						if v_u_126 then
							if v161 and (type(v162) == "table" and v162.ok == true) then
								local v163 = v162.report
								if type(v163) == "table" then
									local v164 = os.clock()
									v_u_125 = v162
									v_u_124 = v164
									v_u_7:SetAttribute("FilmEcoError", nil)
									v_u_99(v162)
									local v165 = "Last %d day(s), read %s.%s"
									local v166 = v162.days
									local v167 = os.date("%H:%M:%S")
									local v168
									if v162.err then
										local v169 = v162.err
										v168 = " Store read stopped: " .. tostring(v169)
									else
										v168 = ""
									end
									local v170 = v165:format(v166, v167, v168)
									local v171 = v162.err ~= nil
									v_u_3.setText(v_u_78, v170)
									local v172 = v_u_78
									local v173
									if v171 then
										v173 = v_u_5.danger
									else
										v173 = v_u_5.text2
									end
									v172.TextColor3 = v173
									return
								end
							end
							local v174
							if v161 and type(v162) == "table" then
								local v175 = v162.msg or "no data"
								v174 = tostring(v175)
							else
								v174 = "the server did not answer"
							end
							v_u_7:SetAttribute("FilmEcoError", v174)
							local v176 = "No economy data: " .. v174
							v_u_3.setText(v_u_78, v176)
							v_u_78.TextColor3 = v_u_5.danger
						end
					end)
				end
			end
			task.wait(0.5)
			v153 = v154
		end
	end)
	return {
		["refresh"] = function(p177) -- name: refresh
			-- upvalues: (copy) v_u_123
			v_u_123(p177)
		end,
		["data"] = function() -- name: data
			-- upvalues: (ref) v_u_125
			return v_u_125
		end
	}
end
return v_u_6