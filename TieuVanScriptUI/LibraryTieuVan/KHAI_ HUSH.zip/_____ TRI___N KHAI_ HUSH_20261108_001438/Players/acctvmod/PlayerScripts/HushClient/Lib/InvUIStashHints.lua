-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIStashHints

local v_u_1 = {}
local v2 = {
	["mailTitle"] = "MAIL",
	["mailWaitOne"] = "1 delivery is waiting in your MAIL. Claim it to put it in your stash.",
	["mailWait"] = "%d deliveries are waiting in your MAIL. Claim them to put them in your stash.",
	["mailCalm"] = "Bought something? Purchases and rewards arrive in your MAIL.",
	["mailButton"] = "Open mail",
	["short"] = nil,
	["gunsmithButton"] = "Show me",
	["gunsmith"] = nil,
	["casesOne"] = "You have 1 case.",
	["cases"] = "You have %d cases.",
	["casesButton"] = "Open case",
	["how"] = nil,
	["howShort"] = nil,
	["padKey"] = "X"
}
local v3 = {
	["mailWaitOne"] = "1 delivery is waiting in your MAIL.",
	["mailWait"] = "%d deliveries are waiting in your MAIL.",
	["mailCalm"] = "Purchases and rewards arrive in your MAIL.",
	["mailButton"] = "Mail",
	["casesButton"] = "Open",
	["gunsmithButton"] = "Show",
	["gunsmith"] = nil,
	["gunsmith"] = {
		[0] = "Gun parts are for PINS, the Gunsmith. Start with Gunner\'s QUIET WORK.",
		[1] = "Gun parts are for PINS, the Gunsmith. Finish her trust jobs."
	}
}
v2.short = v3
v2.gunsmith = {
	[0] = "Gun parts are for PINS, the Gunsmith. Gunner\'s job QUIET WORK introduces her.",
	[1] = "Gun parts are for PINS, the Gunsmith. Finish her trust jobs to open her bench."
}
v2.how = {
	["Keyboard"] = "Right click a case and choose Open.",
	["Touch"] = "Hold a case and tap OPEN.",
	["Gamepad"] = "Select a case, press %s and choose Open."
}
v2.howShort = {
	["Keyboard"] = "Right click a case, choose Open.",
	["Touch"] = "Hold a case, tap OPEN.",
	["Gamepad"] = "Press %s on a case, choose Open."
}
v_u_1.TEXT = v2
v_u_1.PREFIX = "skin_crate_"
v_u_1.ID = "stash_hints"
v_u_1.DOCK_MIN_HEIGHT = 700
function v_u_1.mailCount(p4) -- name: mailCount
	if type(p4) ~= "table" then
		return 0
	end
	local v5 = p4.waiting
	local v6 = tonumber(v5)
	local v7 = (not v6 or (v6 ~= v6 or v6 < 0)) and 0 or math.floor(v6)
	local v8 = p4.ready
	local v9 = tonumber(v8)
	return v7 + ((not v9 or (v9 ~= v9 or v9 < 0)) and 0 or math.floor(v9))
end
function v_u_1.caseCount(p10) -- name: caseCount
	-- upvalues: (copy) v_u_1
	local v11 = 0
	if type(p10) ~= "table" then
		return 0
	end
	for _, v12 in p10 do
		if type(v12) ~= "table" then
			continue
		end
		local v13 = v12.id
		local v14 = v_u_1.PREFIX
		local v15
		if type(v13) == "string" and #v13 > #v14 then
			local v16 = #v14
			v15 = string.sub(v13, 1, v16) == v14
		else
			v15 = false
		end
		if not v15 then
			continue
		end
		local v17 = v12.n
		local v18 = tonumber(v17)
		local v19 = (not v18 or (v18 ~= v18 or v18 < 0)) and 0 or math.floor(v18)
		v11 = v11 + math.max(1, v19)
	end
	return v11
end
function v_u_1.firstCase(p20) -- name: firstCase
	-- upvalues: (copy) v_u_1
	if type(p20) ~= "table" then
		return nil
	end
	for _, v21 in p20 do
		if type(v21) ~= "table" then
			continue
		end
		local v22 = v21.id
		local v23 = v_u_1.PREFIX
		local v24
		if type(v22) == "string" and #v22 > #v23 then
			local v25 = #v23
			v24 = string.sub(v22, 1, v25) == v23
		else
			v24 = false
		end
		if not v24 then
			continue
		end
		return v21.id
	end
	return nil
end
function v_u_1.howText(p26, p27) -- name: howText
	-- upvalues: (copy) v_u_1
	local v28 = p26 ~= "Touch" and p26 ~= "Gamepad" and "Keyboard" or p26
	local v29
	if p27 then
		v29 = v_u_1.TEXT.howShort[v28]
	else
		v29 = v_u_1.TEXT.how[v28]
	end
	if v28 == "Gamepad" then
		return string.format(v29, v_u_1.TEXT.padKey)
	else
		return v29
	end
end
function v_u_1.mailRow(p30, p31) -- name: mailRow
	-- upvalues: (copy) v_u_1
	local v32 = v_u_1.TEXT
	if p31 then
		v32 = v32.short
	end
	local v33 = tonumber(p30)
	local v34 = (not v33 or (v33 ~= v33 or v33 < 0)) and 0 or math.floor(v33)
	if v34 <= 0 then
		return {
			["urgent"] = false,
			["count"] = 0,
			["text"] = nil,
			["button"] = nil,
			["text"] = v32.mailCalm,
			["button"] = v32.mailButton
		}
	end
	local v35 = {
		["urgent"] = true,
		["count"] = nil,
		["text"] = nil,
		["button"] = nil,
		["count"] = v34
	}
	local v36
	if v34 == 1 then
		v36 = v32.mailWaitOne
	else
		v36 = string.format(v32.mailWait, v34)
	end
	v35.text = v36
	v35.button = v32.mailButton
	return v35
end
function v_u_1.casesRow(p37, p38, p39, p40) -- name: casesRow
	-- upvalues: (copy) v_u_1
	local v41 = v_u_1.TEXT
	if p38 == true then
		local v42 = tonumber(p37)
		if ((not v42 or (v42 ~= v42 or v42 < 0)) and 0 or math.floor(v42)) > 0 then
			local v43
			if p37 == 1 then
				v43 = v41.casesOne
			else
				v43 = string.format(v41.cases, p37)
			end
			local v44
			if p40 then
				v44 = v_u_1.howText(p39, true)
			else
				v44 = v43 .. " " .. v_u_1.howText(p39, false)
			end
			if p40 then
				v44 = string.format(p37 == 1 and "1 case. " or "%d cases. ", p37) .. v44
			end
			local v45 = {
				["count"] = p37,
				["text"] = v44
			}
			local v46
			if p40 then
				v46 = v41.short.casesButton
			else
				v46 = v41.casesButton
			end
			v45.button = v46
			return v45
		end
	end
	return nil
end
local v_u_47 = nil
local function v_u_53(p48) -- name: isGunItem
	-- upvalues: (ref) v_u_47
	if type(p48) ~= "string" then
		return false
	end
	if v_u_47 == nil then
		local v49, v50 = pcall(function()
			return require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items"))
		end)
		if not v49 or type(v50) ~= "table" then
			v50 = false
		end
		v_u_47 = v50
	end
	if not v_u_47 then
		return false
	end
	local v51 = v_u_47.get(p48)
	local v52
	if v51 == nil or v51.category ~= "material" then
		v52 = false
	else
		v52 = v_u_47.hasTag(v51, "gunpart")
	end
	return v52
end
function v_u_1.gunParts(p54, p55) -- name: gunParts
	-- upvalues: (copy) v_u_53, (copy) v_u_1
	local v56 = p55 or 1
	if type(p54) ~= "table" or v56 > 4 then
		return false
	end
	for _, v57 in p54 do
		if type(v57) ~= "table" then
			continue
		end
		if not v_u_53(v57.id) then
			local v58 = v57.items
			if type(v58) ~= "table" or not v_u_1.gunParts(v57.items, v56 + 1) then
				continue
			end
		end
		return true
	end
	return false
end
function v_u_1.gunsmithRow(p59, p60) -- name: gunsmithRow
	-- upvalues: (copy) v_u_1
	local v61
	if type(p59) == "table" then
		local v62 = p59.stage
		v61 = tonumber(v62)
	else
		v61 = nil
	end
	if v61 ~= nil and v61 >= 2 then
		return nil
	end
	local v63 = v_u_1.TEXT
	if p60 then
		v63 = v63.short
	end
	local v64 = v61 == 1 and 1 or 0
	return {
		["stage"] = v64,
		["text"] = v63.gunsmith[v64],
		["button"] = v63.gunsmithButton
	}
end
function v_u_1.plan(p65) -- name: plan
	-- upvalues: (copy) v_u_1
	if type(p65) ~= "table" or p65.mode == "raid" then
		return nil
	end
	local v66 = p65.items
	local v67 = v_u_1.caseCount(v66)
	local v68 = {
		["mail"] = v_u_1.mailRow(v_u_1.mailCount(p65.live), p65.short == true)
	}
	local v69 = v_u_1.casesRow(v67, p65.listed == true, p65.device, p65.short == true)
	if v69 then
		v69.first = v_u_1.firstCase(v66)
		v68.cases = v69
	end
	local v70 = p65.gunsmith
	if type(v70) == "table" and v70.show == true then
		v68.gunsmith = v_u_1.gunsmithRow(v70.know, p65.short == true)
	end
	return v68
end
function v_u_1.signature(p71, p72, p73) -- name: signature
	if not p71 then
		return ""
	end
	local v74 = p71.mail
	local v75 = p71.cases
	local v76 = p71.gunsmith
	local v77 = table.concat
	local v78 = {}
	local v79 = v74.text
	local v80 = v74.urgent
	__set_list(v78, 1, {v79, tostring(v80), v75 and (v75.text or "-") or "-", v75 and v75.first or "-", tostring(p72), tostring(p73), v76 and v76.text or "-"})
	return v77(v78, "|")
end
v_u_1.gunShown = false
v_u_1.gunDone = false
local function v_u_94(p_u_81, p82) -- name: gunsmithArgs
	-- upvalues: (copy) v_u_1
	if v_u_1.gunDone then
		return nil
	end
	local v83 = p_u_81.controllers.Menu
	if type(v83) == "table" then
		local v84 = v83.gunsmithHintState
		if type(v84) == "function" then
			local v85, v86 = pcall(function()
				-- upvalues: (copy) p_u_81
				return p_u_81.config.flag("Gunsmith") ~= false
			end)
			if v85 and v86 == false then
				return nil
			end
			if not v_u_1.gunParts(p82) then
				return nil
			end
			local v87 = v83.gunsmithHintState
			local v88, v89 = pcall(v87)
			if not v88 or v89 ~= "show" and not v_u_1.gunShown then
				return nil
			end
			local v90 = v83.gunsmithKnow
			local v91, v92 = pcall(v90)
			if (not v91 or v92 == nil) and not v_u_1.gunShown then
				return nil
			end
			local v93 = {
				["show"] = true,
				["know"] = nil
			}
			if not v91 then
				v92 = nil
			end
			v93.know = v92
			return v93
		end
	end
	return nil
end
local function v_u_100(p95) -- name: remove
	local v_u_96 = p95.stashHints
	local v97 = p95.stashHintsBase
	if v97 then
		if v97.scroll and v97.scroll.Parent then
			v97.scroll.Size = v97.size
		end
		p95.stashHintsBase = nil
	end
	if v_u_96 and v_u_96.conns then
		for _, v_u_98 in v_u_96.conns do
			pcall(function()
				-- upvalues: (copy) v_u_98
				v_u_98:Disconnect()
			end)
		end
		v_u_96.conns = nil
	end
	if v_u_96 then
		if v_u_96.frame then
			pcall(function()
				-- upvalues: (copy) v_u_96
				v_u_96.frame:Destroy()
			end)
		end
		p95.stashHints = nil
	end
	local v99 = p95.sections
	if type(v99) == "table" then
		p95.sections.stash_hints = nil
	end
end
local function v_u_138(p_u_101, p102, p103, p104, p_u_105, p_u_106, p107, _, p_u_108) -- name: drawRow
	local v109 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
	local v110 = require(v109:WaitForChild("Theme"))
	local v111 = require(script.Parent:WaitForChild("HushUI"))
	local v_u_112 = v110.color
	local v_u_113 = Instance.new("Frame")
	v_u_113.Name = "Row" .. p103
	v_u_113.LayoutOrder = p103
	local v114
	if p_u_105 then
		v114 = v_u_112.accentDeep
	else
		v114 = v_u_112.raised
	end
	v_u_113.BackgroundColor3 = v114
	v_u_113.BackgroundTransparency = 0
	v_u_113.BorderSizePixel = 0
	v_u_113.Size = UDim2.new(1, 0, 0, 0)
	v_u_113.AutomaticSize = Enum.AutomaticSize.Y
	v_u_113.Parent = p102
	local v115 = Instance.new("UIStroke")
	local v116
	if p_u_105 then
		v116 = v_u_112.accent
	else
		v116 = v_u_112.line
	end
	v115.Color = v116
	v115.Thickness = 1
	v115.Parent = v_u_113
	local v117 = Instance.new("UIPadding")
	local v118 = UDim.new(0, 8)
	local v119 = UDim.new(0, 8)
	local v120 = UDim.new(0, 8)
	local v121 = UDim.new(0, 8)
	v117.PaddingLeft = v118
	v117.PaddingRight = v119
	v117.PaddingTop = v120
	v117.PaddingBottom = v121
	v117.Parent = v_u_113
	local v122 = Instance.new("UIListLayout")
	v122.FillDirection = Enum.FillDirection.Horizontal
	v122.VerticalAlignment = Enum.VerticalAlignment.Center
	v122.SortOrder = Enum.SortOrder.LayoutOrder
	v122.Padding = UDim.new(0, 8)
	v122.Parent = v_u_113
	local v123 = Instance.new("UISizeConstraint")
	v123.MinSize = Vector2.new(0, 48)
	v123.Parent = v_u_113
	local v124 = 16
	if p_u_106 and (not p107 and pcall(function()
		-- upvalues: (copy) p_u_101, (copy) p_u_106, (copy) p_u_105, (copy) v_u_112, (copy) v_u_113
		local v125 = p_u_101.lib.MenuRail.glyph
		local v126 = p_u_106
		local v127 = nil
		local v128 = 22
		local v129
		if p_u_105 then
			v129 = v_u_112.accent
		else
			v129 = v_u_112.text2
		end
		local v130 = v125(v126, v127, v128, v129)
		v130.LayoutOrder = 1
		v130.Parent = v_u_113
	end)) then
		v124 = v124 + 30
	end
	local v131 = #p104.button * 9 + 56
	local v132 = v111.label
	local v133 = {
		["text"] = nil,
		["style"] = "small",
		["wrap"] = true,
		["autoY"] = true,
		["size"] = nil,
		["color"] = nil,
		["text"] = p104.text,
		["size"] = UDim2.new(1, -(v124 + v131 + 8), 0, 0)
	}
	local v134
	if p_u_105 then
		v134 = v_u_112.text
	else
		v134 = v_u_112.text2
	end
	v133.color = v134
	local v135 = v132(v133)
	v135.Name = "Text"
	v135.LayoutOrder = 2
	v135.Parent = v_u_113
	local v136 = v111.button({
		["text"] = nil,
		["kind"] = nil,
		["height"] = 32,
		["name"] = "Go",
		["text"] = p104.button,
		["kind"] = p_u_105 and "primary" or "default"
	})
	v136.LayoutOrder = 3
	v136.Parent = v_u_113
	v136.Activated:Connect(function()
		-- upvalues: (copy) p_u_108
		local v137 = p_u_108
		pcall(v137)
	end)
end
local function v_u_171(p_u_139, p_u_140, p141, p142, p143, p144) -- name: build
	-- upvalues: (copy) v_u_138, (copy) v_u_1
	local v_u_145 = Instance.new("Frame")
	v_u_145.Name = "StashHints"
	v_u_145.BackgroundTransparency = 1
	v_u_145.BorderSizePixel = 0
	v_u_145.Size = UDim2.new(1, 0, 0, 0)
	v_u_145.AutomaticSize = Enum.AutomaticSize.Y
	v_u_145.ZIndex = 5
	local v146 = Instance.new("UIListLayout")
	v146.SortOrder = Enum.SortOrder.LayoutOrder
	v146.Padding = UDim.new(0, 8)
	v146.Parent = v_u_145
	local v147 = Instance.new("UIPadding")
	v147.PaddingTop = UDim.new(0, 8)
	v147.Parent = v_u_145
	local v_u_148 = p_u_139.controllers.Menu
	v_u_138(p_u_139, v_u_145, 1, p141.mail, p141.mail.urgent, "mail", p142, p143, function()
		-- upvalues: (copy) v_u_148
		if v_u_148 then
			local v149 = v_u_148.openMail
			if type(v149) == "function" then
				v_u_148.openMail()
			end
		end
	end)
	if p141.cases then
		local v_u_150 = p141.cases.first
		v_u_138(p_u_139, v_u_145, 2, p141.cases, false, nil, p142, p143, function()
			-- upvalues: (copy) v_u_148, (copy) v_u_150
			if v_u_148 then
				local v151 = v_u_148.openCrates
				if type(v151) == "function" then
					v_u_148.openCrates(v_u_150)
				end
			end
		end)
	end
	if p141.gunsmith then
		local v_u_152 = p141.gunsmith
		v_u_138(p_u_139, v_u_145, 3, v_u_152, false, nil, p142, p143, function()
			-- upvalues: (ref) v_u_1, (copy) v_u_148, (copy) v_u_152, (copy) p_u_139, (copy) p_u_140
			v_u_1.gunDone = true
			if v_u_148 then
				local v153 = v_u_148.gunsmithHintMark
				if type(v153) == "function" then
					v_u_148.gunsmithHintMark()
				end
			end
			if v_u_148 then
				local v154 = v_u_148.openTraders
				if type(v154) == "function" then
					if v_u_152.stage == 1 then
						v_u_148.openTraders("tasks", "gunsmith")
					else
						v_u_148.openTraders("tasks", "gunner", "tasks")
					end
				end
			end
			local v155 = v_u_1.render
			local v156 = p_u_139
			local v157 = p_u_140
			pcall(v155, v156, v157)
		end)
	end
	local v_u_158 = p_u_140.rightScroll
	local v_u_159 = p_u_140.rightScroll.Parent
	if not p144 then
		v_u_145.Size = UDim2.fromOffset(p143, 0)
		v_u_145.LayoutOrder = 900
		v_u_145.Parent = v_u_158
		return v_u_145, nil
	end
	v_u_145.AnchorPoint = Vector2.new(0, 1)
	v_u_145.Position = UDim2.fromScale(0, 1)
	local v160 = p_u_140.stashHintsBase
	if not v160 or v160.scroll ~= v_u_158 then
		v160 = {
			["scroll"] = v_u_158,
			["size"] = v_u_158.Size
		}
		p_u_140.stashHintsBase = v160
	end
	local v_u_161 = v160.size
	local function v169() -- name: fit
		-- upvalues: (copy) v_u_158, (copy) v_u_145, (copy) v_u_159, (copy) v_u_161
		if v_u_158.Parent and v_u_145.Parent then
			local v162 = v_u_159.AbsoluteSize.Y
			local v163 = v_u_145.AbsoluteSize.Y
			if v162 > 0 and v163 > 0 then
				local v164 = v_u_158
				local v165 = UDim2.new
				local v166 = v_u_161.X.Scale
				local v167 = v_u_161.X.Offset
				local v168 = v_u_161.Y.Scale - v163 / v162
				v164.Size = v165(v166, v167, math.max(0.2, v168), v_u_161.Y.Offset)
			end
		end
	end
	v_u_145.Parent = v_u_159
	local v170 = { v_u_145:GetPropertyChangedSignal("AbsoluteSize"):Connect(v169), v_u_159:GetPropertyChangedSignal("AbsoluteSize"):Connect(v169) }
	task.defer(v169)
	return v_u_145, v170
end
function v_u_1.render(p_u_172, p_u_173) -- name: render
	-- upvalues: (copy) v_u_100, (copy) v_u_1, (copy) v_u_94, (copy) v_u_171
	if type(p_u_173) == "table" and (p_u_173.mode ~= "raid" and (p_u_173.rightScroll and p_u_173.rightScroll.Parent)) then
		local v176, v177 = pcall(function()
			-- upvalues: (copy) p_u_172
			local v174 = p_u_172.controllers.Menu
			if type(v174) == "table" then
				local v175 = v174.isOpen
				if type(v175) == "function" then
					return v174.isOpen()
				end
			end
			return true
		end)
		if v176 then
			v176 = v177 == true
		end
		if v176 then
			local v178 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
			local v179 = require(v178:WaitForChild("Theme"))
			local v180 = require(script.Parent:WaitForChild("HushUI")).device
			local v181, v182 = pcall(v180)
			local v183 = v179.viewport
			local v184, v185 = pcall(v183)
			if v184 then
				if typeof(v185) == "Vector2" and v185.Y >= v_u_1.DOCK_MIN_HEIGHT then
					v184 = p_u_173.narrow ~= true
				else
					v184 = false
				end
			end
			local v186 = v179.isPhone() == true and true or not v184
			local v187 = p_u_173.rightW
			local v188 = tonumber(v187) or 300
			local v189 = math.floor(v188)
			local v190 = math.max(200, v189)
			local v191 = p_u_173.work
			local v192
			if type(v191) == "table" then
				local v193 = v191.containers
				if type(v193) == "table" then
					v192 = v191.containers.stash
				else
					v192 = nil
				end
			else
				v192 = nil
			end
			local v194
			if type(v192) == "table" then
				v194 = v192.items
			else
				v194 = nil
			end
			local v195 = v_u_1.plan
			local v196 = {
				["mode"] = p_u_173.mode
			}
			local v197, v198 = pcall(function()
				-- upvalues: (copy) p_u_172
				return p_u_172.lib.MenuRail.mailLive()
			end)
			if not v197 then
				v198 = nil
			end
			v196.live = v198
			v196.items = v194
			local v199, v200 = pcall(function()
				-- upvalues: (copy) p_u_172
				return p_u_172.controllers.Menu.cratesListed()
			end)
			if v199 then
				v199 = v200 == true
			end
			v196.listed = v199
			v196.device = not v181 and "Keyboard" or v182
			v196.short = v186
			v196.gunsmith = v_u_94(p_u_172, v194)
			local v201 = v195(v196)
			if v201 then
				if v201.gunsmith and not v_u_1.gunShown then
					v_u_1.gunShown = true
					local v202 = p_u_172.controllers.Menu
					if type(v202) == "table" then
						local v203 = v202.gunsmithHintMark
						if type(v203) == "function" then
							local v204 = v202.gunsmithHintMark
							pcall(v204)
						end
					end
				end
				local v205 = v_u_1.signature(v201, v186, v184 and 0 or v190)
				local v206 = p_u_173.stashHints
				if not v206 or (v206.sig ~= v205 or not (v206.frame and v206.frame.Parent)) then
					v_u_100(p_u_173)
					local v207, v208 = v_u_171(p_u_172, p_u_173, v201, v186, v190, v184)
					p_u_173.stashHints = {
						["frame"] = v207,
						["sig"] = v205,
						["conns"] = v208
					}
					if not v184 then
						p_u_173.sections.stash_hints = {
							["frame"] = nil,
							["placeholder"] = true,
							["kind"] = "stash",
							["frame"] = v207
						}
						for v209, v210 in p_u_173.sections do
							if v209 == "stash_hints" or (type(v210) ~= "table" or (v210.kind ~= "stash" or not (v210.frame and v210.frame.Parent))) then
								continue
							end
							v207.Visible = v210.frame.Visible
						end
					end
					if not p_u_173.stashHintsTimer then
						p_u_173.stashHintsTimer = true
						task.spawn(function()
							-- upvalues: (copy) p_u_173, (ref) v_u_1, (copy) p_u_172
							for _ = 1, 20000 do
								task.wait(3)
								local v211 = p_u_173.stashHints
								if not (v211 and (v211.frame and v211.frame.Parent)) then
									break
								end
								local v212 = v_u_1.render
								local v213 = p_u_172
								local v214 = p_u_173
								pcall(v212, v213, v214)
							end
							p_u_173.stashHintsTimer = nil
						end)
					end
				end
			else
				v_u_100(p_u_173)
				return
			end
		end
	end
	if type(p_u_173) == "table" then
		v_u_100(p_u_173)
	end
end
return v_u_1