-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HollowMapDraw

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = game:GetService("TextService")
local v_u_4 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Theme"))
local v5 = nil
local v6 = nil
local v7, v_u_8 = pcall(function()
	return game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
end)
local v_u_9, v_u_10
if v7 then
	local v11
	v11, v_u_9 = pcall(function()
		-- upvalues: (copy) v_u_8
		return require((v_u_8:WaitForChild("MapTagPlace", 5)))
	end)
	if not v11 or type(v_u_9) ~= "table" then
		v_u_9 = v5
	end
	local v12
	v12, v_u_10 = pcall(function()
		-- upvalues: (copy) v_u_8
		return require((v_u_8:WaitForChild("Config", 5)))
	end)
	if not v12 or type(v_u_10) ~= "table" then
		v_u_10 = v6
	end
else
	v_u_10 = v6
	v_u_9 = v5
end
local v_u_13 = {}
local v14 = nil
local v15 = nil
local v16, v_u_17 = pcall(function()
	return require((script.Parent:WaitForChild("HollowMapData", 5)))
end)
if not v16 or type(v_u_17) ~= "table" then
	v_u_17 = nil
end
local v20, v_u_21 = pcall(function()
	local v18 = game:GetService("ReplicatedStorage")
	local v19 = v18:WaitForChild("Hush", 5)
	if v19 then
		v19 = v18.Hush:WaitForChild("Shared", 5)
	end
	return require((v19:WaitForChild("HollowLevels", 5)))
end)
if not v20 or type(v_u_21) ~= "table" then
	v_u_21 = v14
end
local v22, v23 = pcall(function()
	return require((script.Parent:WaitForChild("MapDraw", 5)))
end)
if v22 and type(v23) == "table" then
	local v24 = v23.INK
	if type(v24) == "table" then
		v15 = v23.INK
	end
end
local v_u_25 = v15 or {
	["paper"] = Color3.fromHex("D8CDB2"),
	["paperLight"] = Color3.fromHex("E6DCC4"),
	["paperEdge"] = Color3.fromHex("A99C7E"),
	["crease"] = Color3.fromHex("BDB091"),
	["grid"] = Color3.fromHex("C3B697"),
	["ink"] = Color3.fromHex("372F26"),
	["inkSoft"] = Color3.fromHex("6A5E4C"),
	["water"] = Color3.fromHex("8DA4AE"),
	["waterInk"] = Color3.fromHex("44606E"),
	["landmark"] = Color3.fromHex("9C4B39"),
	["landmarkEdge"] = Color3.fromHex("5E2A1F"),
	["red"] = Color3.fromHex("B0322A"),
	["redDeep"] = Color3.fromHex("7E2019"),
	["green"] = Color3.fromHex("3E6E4A"),
	["build"] = Color3.fromHex("8C806D"),
	["buildEdge"] = Color3.fromHex("4A4136"),
	["road"] = Color3.fromHex("F0E8D4"),
	["forest"] = Color3.fromHex("B4B98F")
}
local v_u_26 = Color3.fromHex("2F5C8A")
local v_u_27 = Color3.fromHex("E8A33D")
local v_u_28 = Color3.fromHex("CFC3A5")
local v_u_29 = {
	["white"] = Color3.fromHex("F2F2F2"),
	["green"] = Color3.fromHex("3DBB5B"),
	["blue"] = Color3.fromHex("3D7BEA"),
	["black"] = Color3.fromHex("202020"),
	["brass"] = Color3.fromHex("C8A040"),
	["red"] = Color3.fromHex("B04040")
}
v_u_13.LINK_INK = v_u_26
v_u_13.TIER = v_u_29
v_u_13.POWER_INK = Color3.fromHex("7E2019")
local v_u_30 = {
	["L0"] = "Quarry",
	["L1"] = "The Hollow",
	["L2"] = "The Hollow",
	["L3"] = "The Hollow"
}
function v_u_13.available() -- name: available
	-- upvalues: (ref) v_u_17
	local v31
	if v_u_17 == nil then
		v31 = false
	else
		local v32 = v_u_17.ROOMS
		if type(v32) == "table" then
			local v33 = v_u_17.LEVELS
			v31 = type(v33) == "table"
		else
			v31 = false
		end
	end
	return v31
end
function v_u_13.levels() -- name: levels
	-- upvalues: (ref) v_u_17, (ref) v_u_21, (copy) v_u_30
	local v34 = {}
	if v_u_17 then
		local v35 = v_u_17.LEVELS
		if type(v35) == "table" then
			for _, v36 in v_u_17.LEVELS do
				local v37 = v_u_21 and v_u_21.BY_ID
				if v37 then
					v37 = v_u_21.BY_ID[v36.id]
				end
				local v38 = {
					["id"] = v36.id
				}
				local v39
				if v37 then
					v39 = v37.name
				else
					v39 = v36.title
				end
				v38.name = v39
				v38.short = v_u_30[v36.id] or v36.id
				v38.floorY = not v37 and -79.4 or v37.floorY
				table.insert(v34, v38)
			end
		end
	end
	for _, v40 in #v34 == 0 and (v_u_21 and v_u_21.LEVELS or {}) or {} do
		local v41 = {
			["id"] = v40.id,
			["name"] = v40.name,
			["short"] = v_u_30[v40.id] or v40.id,
			["floorY"] = v40.floorY
		}
		table.insert(v34, v41)
	end
	if #v34 == 0 and v_u_17 then
		for v42, v43 in v_u_17.LEVELS do
			local v44 = {
				["id"] = v43.id,
				["name"] = v43.title,
				["short"] = v_u_30[v43.id] or v43.id,
				["floorY"] = 0.6 - 40 * (v42 - 1)
			}
			table.insert(v34, v44)
		end
	end
	return v34
end
function v_u_13.levelOfExtract(p45) -- name: levelOfExtract
	-- upvalues: (ref) v_u_17
	if not v_u_17 then
		return nil
	end
	for _, v46 in v_u_17.EXTRACTS or {} do
		if v46.id ~= p45 then
			continue
		end
		return v46.level
	end
	return nil
end
function v_u_13.roomName(p47) -- name: roomName
	-- upvalues: (ref) v_u_17
	if v_u_17 then
		local v48 = v_u_17.ROOMS
		if type(v48) == "table" and type(p47) == "string" then
			local v49 = string.upper(p47)
			for _, v50 in v_u_17.ROOMS do
				for _, v51 in v50 do
					if v51.id ~= v49 then
						continue
					end
					local v52 = v51.name
					if type(v52) ~= "string" or v51.name == "" then
						continue
					end
					return v51.name
				end
			end
			return nil
		end
	end
	return nil
end
function v_u_13.roomAt(p53) -- name: roomAt
	-- upvalues: (ref) v_u_17
	local v54 = v_u_17 and v_u_17.ROOM_AT
	if v54 then
		v54 = v_u_17.ROOM_AT[p53]
	end
	if type(v54) == "table" then
		return v54[1], v54[2], v54[3]
	else
		return nil, 0, 0
	end
end
local function v_u_67(p55, p56, p57, p58, p59, p60, p61) -- name: text
	-- upvalues: (ref) v_u_25
	local v62 = Instance.new("TextLabel")
	v62.Name = "Txt"
	v62.BackgroundTransparency = 1
	v62.AnchorPoint = Vector2.new(0.5, 0.5)
	v62.Position = UDim2.fromOffset(p57.X, p57.Y)
	local v63 = UDim2.fromOffset
	local v64 = (utf8.len(p56) or #p56) * p58 * 0.62 + 8
	v62.Size = v63(math.max(20, v64), p58 + 4)
	v62.FontFace = p59
	v62.TextSize = p58
	v62.TextColor3 = p60
	v62.TextStrokeColor3 = v_u_25.paperLight
	v62.TextStrokeTransparency = 0.25
	v62.Text = p56
	v62.TextTruncate = Enum.TextTruncate.AtEnd
	if p61 then
		for v65, v66 in p61 do
			v62[v65] = v66
		end
	end
	v62.Parent = p55
	return v62
end
local function v_u_73(p68) -- name: spaced
	local v69 = utf8.char(8202)
	local v70 = {}
	for _, v71 in utf8.codes(string.upper(p68)) do
		local v72 = utf8.char
		table.insert(v70, v72(v71))
	end
	return table.concat(v70, v69)
end
function v_u_13.build(p74, p75, p76, p77, p78, p_u_79) -- name: build
	-- upvalues: (ref) v_u_17, (copy) v_u_67, (copy) v_u_4, (ref) v_u_21, (ref) v_u_25, (copy) v_u_28, (ref) v_u_9, (ref) v_u_10, (copy) v_u_29, (copy) v_u_13, (copy) v_u_3, (copy) v_u_73, (copy) v_u_26, (copy) v_u_27, (copy) v_u_1, (copy) v_u_2
	local v80 = v_u_17
	assert(v80, "HollowMapData missing")
	local v_u_81 = v_u_67
	local v_u_82
	if p_u_79 then
		v_u_82 = p_u_79.phone
	else
		v_u_82 = v_u_4.isPhone()
	end
	for v83, v85 in v_u_17.LEVELS do
		if v85.id ~= p77 then
			continue
		end
		v_u_86 = v83 - 1
	end
	local v85 = v_u_17.LEVELS[1]
	local v_u_86 = 0
	local v_u_87 = v85.id
	local v88 = 0.6 - 40 * v_u_86
	local v_u_89
	if v_u_21 and (v_u_21.BY_ID and v_u_21.BY_ID[v_u_87]) then
		v88 = v_u_21.BY_ID[v_u_87].floorY
		v_u_89 = v_u_21.BY_ID[v_u_87].name
	else
		v_u_89 = v_u_87
	end
	if not (p78 and p78.heading) then
		Font.fromName("Oswald", Enum.FontWeight.Medium)
	end
	local v90 = p78 and p78.headingBold or Font.fromName("Oswald", Enum.FontWeight.Bold)
	local v91 = p78 and p78.body or Font.fromName("Roboto", Enum.FontWeight.Regular)
	local v92 = p78 and p78.bodyMedium or Font.fromName("Roboto", Enum.FontWeight.Medium)
	local v93 = math.min(p75, p76)
	local v94 = v93 * 0.03
	local v95 = math.floor(v94)
	local v96 = math.max(10, v95)
	local v_u_97 = p75 - v96 * 2
	local v98 = p76 - v96 * 2
	local v_u_99 = v93 / 880
	local v_u_100 = v85.bounds
	local v101 = v_u_100[3] - v_u_100[1]
	local v102 = v_u_100[4] - v_u_100[2]
	local v103 = v_u_97 / v101
	local v104 = v98 / v102
	local v_u_105 = math.min(v103, v104)
	local v_u_106 = (v_u_97 - v101 * v_u_105) / 2
	local v_u_107 = (v98 - v102 * v_u_105) / 2
	local v108 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Name"] = "Sheet_" .. v_u_87,
		["BackgroundColor3"] = v_u_25.paper,
		["Size"] = UDim2.fromOffset(p75, p76)
	}
	local v109 = Instance.new("Frame")
	v109.BorderSizePixel = 0
	local v_u_110 = 0
	for v111, v112 in v108 do
		v109[v111] = v112
	end
	v109.Parent = p74
	local v113 = v_u_25.paperEdge
	local v114 = Instance.new("UIStroke")
	v114.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v114.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v114.Color = v113
	v114.Thickness = 2
	v114.Transparency = 0
	v114.Parent = v109
	v109:SetAttribute("Level", v_u_87)
	local v115 = {
		["Name"] = "Area",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 1,
		["BackgroundColor3"] = v_u_28,
		["Position"] = UDim2.fromOffset(v96, v96),
		["Size"] = UDim2.fromOffset(v_u_97, v98)
	}
	local v116 = Instance.new("Frame")
	v116.BorderSizePixel = 0
	for v117, v118 in v115 do
		v116[v117] = v118
	end
	v116.Parent = v109
	local v119 = v_u_25.ink
	local v120 = Instance.new("UIStroke")
	v120.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v120.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v120.Color = v119
	v120.Thickness = 1
	v120.Transparency = 0
	v120.Parent = v116
	local v121 = {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v122 = Instance.new("Frame")
	v122.BorderSizePixel = 0
	local function v_u_137(p123, p124, p125, p126, p127, p128) -- name: seg
		-- upvalues: (ref) v_u_110
		local v129 = p125 - p124
		v_u_110 = v_u_110 + 1
		local v130 = {
			["Name"] = "Seg",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BackgroundColor3"] = p127,
			["BackgroundTransparency"] = p128 or 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset((p124.X + p125.X) / 2, (p124.Y + p125.Y) / 2),
			["Size"] = UDim2.fromOffset(v129.Magnitude + p126 * 0.5, p126)
		}
		local v131 = v129.Y
		local v132 = v129.X
		local v133 = math.atan2(v131, v132)
		v130.Rotation = math.deg(v133)
		local v134 = Instance.new("Frame")
		v134.BorderSizePixel = 0
		for v135, v136 in v130 do
			v134[v135] = v136
		end
		v134.Parent = p123
		return v134
	end
	local function v140(p138, p139) -- name: toPx
		-- upvalues: (copy) v_u_106, (copy) v_u_100, (copy) v_u_105, (copy) v_u_107
		return Vector2.new(v_u_106 + (p138 - v_u_100[1]) * v_u_105, v_u_107 + (p139 - v_u_100[2]) * v_u_105)
	end
	local function v_u_159(p141, p142, p143, p144, p145, p146, p147, p148) -- name: box
		-- upvalues: (copy) v_u_106, (copy) v_u_100, (copy) v_u_105, (copy) v_u_107, (ref) v_u_110
		local v149 = Vector2.new(v_u_106 + (p142 - v_u_100[1]) * v_u_105, v_u_107 + (p143 - v_u_100[2]) * v_u_105)
		local v150 = p148 or 1
		v_u_110 = v_u_110 + 1
		local v151 = {
			["BackgroundColor3"] = p147,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v149.X, v149.Y)
		}
		local v152 = UDim2.fromOffset
		local v153 = p144 * v_u_105
		local v154 = math.max(v150, v153)
		local v155 = p145 * v_u_105
		v151.Size = v152(v154, (math.max(v150, v155)))
		v151.Rotation = p146
		local v156 = Instance.new("Frame")
		v156.BorderSizePixel = 0
		for v157, v158 in v151 do
			v156[v157] = v158
		end
		v156.Parent = p141
		return v156
	end
	for v160, v161 in v121 do
		v122[v160] = v161
	end
	v122.Parent = v116
	local v162 = v_u_100[1] / 100
	for v163 = math.ceil(v162) * 100, v_u_100[3], 100 do
		local v164 = v_u_100[2]
		local v165 = Vector2.new(v_u_106 + (v163 - v_u_100[1]) * v_u_105, v_u_107 + (v164 - v_u_100[2]) * v_u_105)
		local v166 = {
			["Name"] = "GridV",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.45,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_25.grid
		}
		local v167 = UDim2.fromOffset
		local v168 = v165.X
		v166.Position = v167(math.floor(v168), 0)
		v166.Size = UDim2.new(0, 1, 1, 0)
		local v169 = Instance.new("Frame")
		v169.BorderSizePixel = 0
		for v170, v171 in v166 do
			v169[v170] = v171
		end
		v169.Parent = v122
	end
	local v172 = v_u_100[2] / 100
	for v173 = math.ceil(v172) * 100, v_u_100[4], 100 do
		local v174 = v_u_100[1]
		local v175 = Vector2.new(v_u_106 + (v174 - v_u_100[1]) * v_u_105, v_u_107 + (v173 - v_u_100[2]) * v_u_105)
		local v176 = {
			["Name"] = "GridH",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.45,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_25.grid
		}
		local v177 = UDim2.fromOffset
		local v178 = v175.Y
		v176.Position = v177(0, (math.floor(v178)))
		v176.Size = UDim2.new(1, 0, 0, 1)
		local v179 = Instance.new("Frame")
		v179.BorderSizePixel = 0
		for v180, v181 in v176 do
			v179[v180] = v181
		end
		v179.Parent = v122
	end
	local v182 = {
		["Name"] = "Rooms",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v183 = Instance.new("Frame")
	v183.BorderSizePixel = 0
	for v184, v185 in v182 do
		v183[v184] = v185
	end
	v183.Parent = v116
	local v186 = {
		["Name"] = "Hatch",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v187 = Instance.new("Frame")
	v187.BorderSizePixel = 0
	for v188, v189 in v186 do
		v187[v188] = v189
	end
	v187.Parent = v116
	local v190 = {
		["Name"] = "Outline",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v191 = Instance.new("Frame")
	v191.BorderSizePixel = 0
	for v192, v193 in v190 do
		v191[v192] = v193
	end
	v191.Parent = v116
	local v194 = {
		["Name"] = "Doors",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v195 = Instance.new("Frame")
	v195.BorderSizePixel = 0
	for v196, v197 in v194 do
		v195[v196] = v197
	end
	v195.Parent = v116
	local v198 = {
		["Name"] = "Symbols",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v199 = Instance.new("Frame")
	v199.BorderSizePixel = 0
	for v200, v201 in v198 do
		v199[v200] = v201
	end
	v199.Parent = v116
	local v202 = {
		["Name"] = "Labels",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 9,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_203 = Instance.new("Frame")
	v_u_203.BorderSizePixel = 0
	for v204, v205 in v202 do
		v_u_203[v204] = v205
	end
	v_u_203.Parent = v116
	local v206 = v_u_99 * 1.3 + 0.5
	local v207 = math.floor(v206)
	local v_u_208 = math.max(1, v207)
	local v_u_209 = {}
	local function v223(p210) -- name: tint
		-- upvalues: (copy) v_u_209, (ref) v_u_17, (ref) v_u_25
		local v211 = p210.zone
		local v212 = tostring(v211)
		local v213 = p210.flags or ""
		local v214 = tostring(v213)
		local v215 = p210.kind
		local v216 = v212 .. "|" .. v214 .. "|" .. tostring(v215)
		local v217 = v_u_209[v216]
		if v217 then
			return v217
		end
		local v218 = v_u_17.ZONES[p210.zone] or v_u_17.ZONES.passage
		local v219 = v_u_25.paperLight
		local v220 = v218.color
		local v221 = v219:Lerp(Color3.fromHex(v220), 0.2)
		local v222 = p210.flags or ""
		if string.find(v222, "W", 1, true) then
			v221 = v_u_25.water:Lerp(v_u_25.paperLight, 0.25)
		elseif p210.kind == "corridor" or (p210.kind == "drift" or p210.kind == "shaft") then
			v221 = v221:Lerp(v_u_25.paper, 0.35)
		end
		v_u_209[v216] = v221
		return v221
	end
	local v_u_224 = v_u_17.ROOMS[v_u_87] or {}
	local v_u_225
	if v_u_9 == nil then
		v_u_225 = false
	else
		local v226
		if v_u_10 == nil then
			v226 = false
		else
			local v227 = v_u_10.flag
			if type(v227) == "function" then
				v226 = v_u_10.flag("MapLabelClean") == false
			else
				v226 = false
			end
		end
		v_u_225 = not v226
	end
	local v_u_228 = {}
	local v_u_229 = {}
	for _, v230 in v_u_224 do
		local v231 = v223(v230)
		if v230.box then
			local v232 = v230.box
			local v233 = v_u_159(v183, v232[1], v232[2], v232[3], v232[4], v232[5], v231, 2)
			v233.Name = "R_" .. v230.id
			local v234 = v_u_25.ink
			local v235 = Instance.new("UIStroke")
			v235.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v235.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v235.Color = v234
			v235.Thickness = v_u_208
			v235.Transparency = 0.05
			v235.Parent = v233
			if not string.find(v230.flags or "", "P", 1, true) then
				continue
			end
			local v236 = v232[3]
			local v237 = v232[4]
			local v238 = math.max(v236, v237)
			local v239 = v232[3]
			local v240 = v232[4]
			local v241 = math.min(v239, v240)
			local v242 = v238 / 8
			local v243 = math.floor(v242)
			local v244 = math.clamp(v243, 3, 24)
			local v245 = v232[5]
			local v246 = math.rad(v245)
			local v247
			if v232[3] >= v232[4] then
				v247 = Vector2.new(math.cos(v246), (math.sin(v246)))
			else
				v247 = Vector2.new(-math.sin(v246), (math.cos(v246)))
			end
			local v248 = Vector2.new(-v247.Y, v247.X)
			for v249 = 1, v244 - 1 do
				local v250 = -v238 / 2 + v238 * v249 / v244
				local v251 = Vector2.new(v232[1], v232[2]) + v247 * v250
				local v252 = v251 + v248 * (v241 / 2 - 0.6)
				local v253 = v251 - v248 * (v241 / 2 - 0.6)
				local v254 = v252.X
				local v255 = v252.Y
				local v256 = Vector2.new(v_u_106 + (v254 - v_u_100[1]) * v_u_105, v_u_107 + (v255 - v_u_100[2]) * v_u_105)
				local v257 = v253.X
				local v258 = v253.Y
				v_u_137(v187, v256, Vector2.new(v_u_106 + (v257 - v_u_100[1]) * v_u_105, v_u_107 + (v258 - v_u_100[2]) * v_u_105), 1, v_u_25.inkSoft, 0.45)
			end
		else
			if not v230.poly then
				continue
			end
			local v259 = v230.fillRot or 0
			local v260 = math.rad(v259)
			local v261 = math.cos(v260)
			local v262 = math.sin(v260)
			local v263 = v230.fill or {}
			local v264 = 1.2 / v_u_105
			local v265 = math.max(0.4, v264)
			for v266 = 1, #v263 - 3, 4 do
				local v267 = v263[v266]
				local v268 = v263[v266 + 1]
				local v269 = v263[v266 + 2]
				local v270 = v263[v266 + 3]
				local v271 = (v267 + v269) / 2
				local v272 = (v268 + v270) / 2
				local v273 = v_u_159(v183, v271 * v261 - v272 * v262, v271 * v262 + v272 * v261, v269 - v267 + v265, v270 - v268 + v265, v230.fillRot or 0, v231, 1)
				v273.Name = "F_" .. v230.id
				if not v_u_228[v230.id] then
					v_u_228[v230.id] = {}
					v_u_229[v230.id] = v231
				end
				local v274 = v_u_228[v230.id]
				table.insert(v274, v273)
			end
			local v275 = v230.poly
			local v276 = #v275 // 2
			for v277 = 1, v276 do
				local v278 = v277 % v276 + 1
				local v279 = v275[v277 * 2 - 1]
				local v280 = v275[v277 * 2]
				local v281 = Vector2.new(v_u_106 + (v279 - v_u_100[1]) * v_u_105, v_u_107 + (v280 - v_u_100[2]) * v_u_105)
				local v282 = v275[v278 * 2 - 1]
				local v283 = v275[v278 * 2]
				v_u_137(v191, v281, Vector2.new(v_u_106 + (v282 - v_u_100[1]) * v_u_105, v_u_107 + (v283 - v_u_100[2]) * v_u_105), v_u_208, v_u_25.ink, 0.05).Name = "E_" .. v230.id
			end
		end
	end
	local v284 = v_u_17.DOORS[v_u_87] or {}
	local v285 = v_u_105 * 1.6
	local v286 = math.max(2, v285)
	local v287 = 0
	for v288 = 1, #v284 - 5, 6 do
		local v289 = v284[v288]
		local v290 = v284[v288 + 1]
		local v291 = v284[v288 + 2]
		local v292 = v284[v288 + 3]
		local v293 = v284[v288 + 4]
		local v294 = v284[v288 + 5]
		local v295 = Vector2.new(v_u_106 + (v289 - v_u_100[1]) * v_u_105, v_u_107 + (v290 - v_u_100[2]) * v_u_105)
		local v296 = v_u_25.paperLight
		local v297 = v_u_25.ink
		if v293 == "key" then
			v296 = v_u_29[v294] or v_u_29.brass
		elseif v293 == "power" then
			v296 = v_u_13.POWER_INK
			v297 = v_u_25.redDeep
		elseif v293 == "vent" then
			v296 = v_u_25.inkSoft
		elseif v293 == "gate" then
			v296 = v_u_25.ink
		end
		local v298 = v293 == "key" and true or v293 == "power"
		v_u_110 = v_u_110 + 1
		local v299 = {
			["Name"] = "D_" .. v293,
			["BackgroundColor3"] = v296,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v295.X, v295.Y)
		}
		local v300 = UDim2.fromOffset
		local v301 = v292 * v_u_105
		local v302 = math.max(v298 and 5 or 3, v301)
		local v303
		if v298 then
			local v304 = v286 * 1.6
			v303 = math.max(4, v304)
		else
			v303 = v286
		end
		v299.Size = v300(v302, v303)
		v299.Rotation = -v291
		local v305 = Instance.new("Frame")
		v305.BorderSizePixel = 0
		for v306, v307 in v299 do
			v305[v306] = v307
		end
		v305.Parent = v195
		local v308 = v293 == "door" and 0.35 or 0
		local v309 = Instance.new("UIStroke")
		v309.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v309.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v309.Color = v297
		v309.Thickness = 1
		v309.Transparency = v308 or 0
		v309.Parent = v305
		if v294 ~= "" then
			v305:SetAttribute("Tier", v294)
		end
		v287 = v287 + 1
	end
	local v_u_310 = {}
	local function v_u_316(p311, p312, p313, p314) -- name: free
		-- upvalues: (copy) v_u_310
		for _, v315 in v_u_310 do
			if p311 >= v315[3] or (v315[1] >= p313 or (p312 >= v315[4] or v315[2] >= p314)) then
				continue
			end
			return false
		end
		return true
	end
	local v_u_317 = 0
	local v318 = {}
	local v_u_319 = {}
	local v_u_320 = {}
	local function v351(p321, p322, p323, p324, p325, p326, p327, p328, p329) -- name: label
		-- upvalues: (ref) v_u_4, (copy) p_u_79, (copy) v_u_316, (copy) v_u_310, (copy) v_u_320, (ref) v_u_317, (ref) v_u_110, (copy) v_u_203, (copy) v_u_81, (copy) v_u_319
		local v330 = v_u_4.phoneText
		local v331 = "caption"
		local v332
		if p_u_79 then
			v332 = p_u_79.scale
		else
			v332 = nil
		end
		local v333
		if p_u_79 then
			v333 = p_u_79.phone
		else
			v333 = nil
		end
		local v334 = v330(p323, v331, v332, v333)
		local v335 = utf8.len(p321) or #p321
		local v336
		if string.find(p321, "\n", 1, true) then
			v336 = 0
			v335 = 0
			for v337 in string.gmatch(p321 .. "\n", "(.-)\n") do
				v336 = v336 + 1
				local v338 = utf8.len(v337) or #v337
				v335 = math.max(v335, v338)
			end
		else
			v336 = 1
		end
		local v339 = v335 * v334 * 0.56 + 6
		local v340
		if v336 > 1 then
			v340 = v336 * (v334 + 1) + 2
		else
			v340 = v334 + 2
		end
		if p328 and p328 < v339 then
			return nil
		end
		if not (p327 or v_u_316(p322.X - v339 / 2, p322.Y - v340 / 2, p322.X + v339 / 2, p322.Y + v340 / 2)) then
			return nil
		end
		local v341 = {
			p322.X - v339 / 2,
			p322.Y - v340 / 2,
			p322.X + v339 / 2,
			p322.Y + v340 / 2
		}
		local v342 = v_u_310
		table.insert(v342, v341)
		if not p329 then
			v_u_320[v341] = true
		end
		v_u_317 = v_u_317 + 1
		v_u_110 = v_u_110 + 1
		local v343 = v_u_203
		local v344 = v_u_81
		local v345 = v_u_4.phoneText
		local v346 = "caption"
		local v347
		if p_u_79 then
			v347 = p_u_79.scale
		else
			v347 = nil
		end
		local v348
		if p_u_79 then
			v348 = p_u_79.phone
		else
			v348 = nil
		end
		local v349 = v344(v343, p321, p322, v345(v334, v346, v347, v348), p324, p325, p326)
		if not p329 then
			local v350 = v_u_319
			table.insert(v350, v349)
		end
		if v336 > 1 then
			v349.Size = UDim2.fromOffset(v339, v336 * v334 * 1.3 + 4)
			v349.TextTruncate = Enum.TextTruncate.None
		end
		return v349
	end
	local function v401() -- name: planCartouche
		-- upvalues: (copy) v_u_99, (ref) v_u_17, (ref) v_u_89, (copy) v_u_86, (copy) v_u_82, (ref) v_u_3, (ref) v_u_73, (ref) v_u_4, (copy) p_u_79, (copy) v_u_97, (copy) v_u_224, (copy) v_u_106, (copy) v_u_100, (copy) v_u_105, (copy) v_u_107, (copy) v_u_225, (ref) v_u_87
		local v352 = v_u_99 * 230
		local v353 = math.max(170, v352)
		local v354 = math.floor(v353)
		local v355 = v_u_99 * 62
		local v356 = math.max(50, v355)
		local v357 = math.floor(v356)
		local v_u_358 = #v_u_17.LEVELS <= 1 and "ONE LEVEL" or string.upper(v_u_89) .. "  \194\183  SHEET " .. v_u_86 + 1 .. " OF " .. #v_u_17.LEVELS
		if v_u_82 then
			local function v368()
				-- upvalues: (ref) v_u_3, (ref) v_u_73, (ref) v_u_99, (ref) v_u_4, (ref) p_u_79
				local v359 = v_u_3
				local v360 = v_u_73("The Hollow")
				local v361 = v_u_99 * 18
				local v362 = math.floor(v361)
				local v363 = math.max(13, v362)
				local v364 = v_u_4.phoneText
				local v365 = "text"
				local v366
				if p_u_79 then
					v366 = p_u_79.scale
				else
					v366 = nil
				end
				local v367
				if p_u_79 then
					v367 = p_u_79.phone
				else
					v367 = nil
				end
				return v359:GetTextSize(v360, v364(v363, v365, v366, v367), Enum.Font.GothamBold, Vector2.new(1000, 100)).X
			end
			local v369, v370 = pcall(v368)
			local function v380()
				-- upvalues: (ref) v_u_3, (copy) v_u_358, (ref) v_u_99, (ref) v_u_4, (ref) p_u_79
				local v371 = v_u_3
				local v372 = v_u_358
				local v373 = v_u_99 * 12
				local v374 = math.floor(v373)
				local v375 = math.max(10, v374)
				local v376 = v_u_4.phoneText
				local v377 = "text"
				local v378
				if p_u_79 then
					v378 = p_u_79.scale
				else
					v378 = nil
				end
				local v379
				if p_u_79 then
					v379 = p_u_79.phone
				else
					v379 = nil
				end
				return v371:GetTextSize(v372, v376(v375, v377, v378, v379), Enum.Font.GothamBold, Vector2.new(1000, 100)).X
			end
			local v381, v382 = pcall(v380)
			local v383 = math.max(not v369 and 120 or v370, not v381 and 150 or v382) + 14
			local v384 = math.ceil(v383)
			v354 = math.max(v354, v384)
		end
		local v385 = (1 / 0)
		local v386 = 10
		local v387 = 10
		for _, v388 in {
			{ 10, 10 },
			{ v_u_97 - v354 - 10, 10 }
		} do
			local v389 = 0
			for _, v390 in v_u_224 do
				local v391 = v390.label[1]
				local v392 = v390.label[2]
				local v393 = Vector2.new(v_u_106 + (v391 - v_u_100[1]) * v_u_105, v_u_107 + (v392 - v_u_100[2]) * v_u_105)
				local v394 = v390.label[3]
				local v395 = v390.label[4]
				local v396 = math.max(v394, v395) * v_u_105 * 0.5
				if v393.X + v396 <= v388[1] or (v393.X - v396 >= v388[1] + v354 or (v393.Y + v396 <= v388[2] or v393.Y - v396 >= v388[2] + v357)) then
					continue
				end
				v389 = v389 + v396
			end
			if v_u_225 then
				for _, v397 in v_u_17.EXTRACTS or {} do
					if v397.level ~= v_u_87 then
						continue
					end
					local v398 = v397.x
					local v399 = v397.z
					local v400 = Vector2.new(v_u_106 + (v398 - v_u_100[1]) * v_u_105, v_u_107 + (v399 - v_u_100[2]) * v_u_105)
					if v400.X <= v388[1] - 12 or (v400.X >= v388[1] + v354 + 12 or (v400.Y <= v388[2] - 12 or v400.Y >= v388[2] + v357 + 12)) then
						continue
					end
					v389 = v389 + 1000
				end
			end
			if v389 >= v385 then
				break
			end
			v386 = v388[1]
			v387 = v388[2]
			v385 = v389
		end
		return {
			["cx"] = v386,
			["cy"] = v387,
			["cw"] = v354,
			["ch"] = v357,
			["levelText"] = v_u_358
		}
	end
	local v402
	if v_u_82 or v_u_225 then
		v402 = v401()
		local v403 = {
			v402.cx,
			v402.cy,
			v402.cx + v402.cw,
			v402.cy + v402.ch
		}
		table.insert(v_u_310, v403)
	else
		v402 = nil
	end
	local v404 = v_u_99 * 12 + 0.5
	local v405 = math.floor(v404)
	local v406 = math.max(10, v405)
	local v407 = v_u_4.phoneText
	local v408 = "text"
	local v409
	if p_u_79 then
		v409 = p_u_79.scale
	else
		v409 = nil
	end
	local v410
	if p_u_79 then
		v410 = p_u_79.phone
	else
		v410 = nil
	end
	local v411 = v407(v406, v408, v409, v410)
	local v412 = v_u_99 * 10 + 0.5
	local v413 = math.floor(v412)
	local v414 = math.max(9, v413)
	local v415 = v_u_4.phoneText
	local v416 = "caption"
	local v417
	if p_u_79 then
		v417 = p_u_79.scale
	else
		v417 = nil
	end
	local v418
	if p_u_79 then
		v418 = p_u_79.phone
	else
		v418 = nil
	end
	local v419 = v415(v414, v416, v417, v418)
	local v420 = table.clone(v_u_224)
	table.sort(v420, function(p421, p422)
		return p421.label[3] * p421.label[4] > p422.label[3] * p422.label[4]
	end)
	local v423 = {}
	local v424, v425
	if v_u_225 then
		v424 = v_u_317
		for _, v426 in v_u_17.MARKS or {} do
			if v426.level ~= v_u_87 then
				continue
			end
			local v427 = v426.x
			local v428 = v426.z
			local v429 = Vector2.new(v_u_106 + (v427 - v_u_100[1]) * v_u_105, v_u_107 + (v428 - v_u_100[2]) * v_u_105)
			local v430 = v_u_99 * 8 + 0.5
			local v431 = math.floor(v430)
			local v432 = math.max(6, v431) * 0.75 + 2
			local v433 = {
				v429.X - v432,
				v429.Y - v432,
				v429.X + v432,
				v429.Y + v432
			}
			v423[v433] = true
			table.insert(v_u_310, v433)
		end
		for _, v434 in v_u_17.EXTRACTS or {} do
			if v434.level ~= v_u_87 then
				continue
			end
			local v435 = v434.x
			local v436 = v434.z
			local v437 = Vector2.new(v_u_106 + (v435 - v_u_100[1]) * v_u_105, v_u_107 + (v436 - v_u_100[2]) * v_u_105)
			local v438 = v434.sx or 0
			local v439 = v434.sz or 0
			local v440 = math.max(v438, v439) * v_u_105 + v_u_99 * 12
			local v441 = v_u_99 * 18
			local v442 = v_u_99 * 40
			local v443 = math.clamp(v440, v441, v442) / 2 + 3
			local v444 = {
				v437.X - v443,
				v437.Y - v443,
				v437.X + v443,
				v437.Y + v443
			}
			table.insert(v_u_310, v444)
		end
		for _, v445 in v_u_17.GENERATORS or {} do
			if v445.level ~= v_u_87 then
				continue
			end
			local v446 = v445.x
			local v447 = v445.z
			local v448 = Vector2.new(v_u_106 + (v446 - v_u_100[1]) * v_u_105, v_u_107 + (v447 - v_u_100[2]) * v_u_105)
			local v449 = v_u_99 * 28 + 0.5
			local v450 = math.floor(v449)
			local v451 = math.max(22, v450) / 2
			local v452 = {
				v448.X - v451,
				v448.Y - v451,
				v448.X + v451,
				v448.Y + v451
			}
			table.insert(v_u_310, v452)
		end
		v425 = v_u_97 - v_u_99 * 30 - 6
		local v453 = v98 - v_u_99 * 44 - 8
		for v454 = 0, 6 do
			local v455 = v425 - v454 * (v_u_99 * 36 + 12)
			local v456 = {
				v455 - v_u_99 * 15 - 2,
				v453 - v_u_99 * 23 - 8,
				v455 + v_u_99 * 15 + 2,
				v453 + v_u_99 * 15 + 2
			}
			if not v_u_316(v456[1], v456[2], v456[3], v456[4]) then
				continue
			end
			v425 = v455
		end
		local v457 = {
			v425 - v_u_99 * 15 - 2,
			v453 - v_u_99 * 23 - 8,
			v425 + v_u_99 * 15 + 2,
			v453 + v_u_99 * 15 + 2
		}
		table.insert(v_u_310, v457)
		local v458 = (v_u_105 * 50 / (v_u_17.STUDS_TO_M or 0.28) > v_u_99 * 160 and 25 or 50) / (v_u_17.STUDS_TO_M or 0.28) * v_u_105
		local v459 = v_u_99 * 14 + 4
		local v460 = v98 - v_u_99 * 20 - 6
		local v461 = {
			v459 - 8,
			v460 - v_u_99 * 18,
			v459 + v458 + 24,
			v460 + 8
		}
		table.insert(v_u_310, v461)
	else
		v424 = v_u_317
		v425 = nil
	end
	for _, v462 in v420 do
		if not string.find(v462.flags or "", "L", 1, true) then
			continue
		end
		local v463 = v462.label[1]
		local v464 = v462.label[2]
		local v465 = Vector2.new(v_u_106 + (v463 - v_u_100[1]) * v_u_105, v_u_107 + (v464 - v_u_100[2]) * v_u_105)
		local v466 = nil
		if v_u_225 then
			local v467, v468 = v_u_9.splitName(v462.name)
			if v467 and (v468 and (utf8.len(v_u_73(v462.name)) or #v462.name) * v411 * 0.56 + 6 > v462.label[3] * v_u_105 * 1.3) then
				v466 = v351(v_u_73(v467) .. "\n" .. v_u_73(v468), v465, v411, v90, v_u_25.redDeep, nil, false)
			end
		end
		if v_u_225 and not v466 then
			local v469 = v411 + 3
			for _, v470 in {
				0,
				-v469,
				v469,
				v469 * -2,
				v469 * 2
			} do
				local v471 = v_u_73(v462.name)
				local v472 = Vector2.new
				local v473 = v465.X
				local v474 = v465.Y + v470
				local v475 = v411 * 0.6 + 1
				local v476 = v98 - v411 * 0.6 - 1
				v466 = v351(v471, v472(v473, (math.clamp(v474, v475, v476))), v411, v90, v_u_25.redDeep, nil, false)
				if not v466 then
					continue
				end
			end
		end
		local v477 = v466 or (v351(v_u_73(v462.name), v465, v411, v90, v_u_25.redDeep, nil, false) or v351(string.upper(v462.name), v465, v411, v90, v_u_25.redDeep, nil, false))
		if v_u_225 and not v477 then
			local v478 = v411 + 3
			local v479 = v411 * 2.2
			for _, v480 in {
				{ 0, 0 },
				{ 0, -v478 },
				{ 0, v478 },
				{ v479, 0 },
				{ -v479, 0 },
				{ 0, v478 * -2 },
				{ 0, v478 * 2 }
			} do
				local v481 = v462.id
				local v482 = Vector2.new
				local v483 = v465.X + v480[1]
				local v484 = v465.Y + v480[2]
				local v485 = v411 * 0.6 + 1
				local v486 = v98 - v411 * 0.6 - 1
				v477 = v351(v481, v482(v483, (math.clamp(v484, v485, v486))), v411, v90, v_u_25.redDeep, nil, false)
				if not v477 then
					continue
				end
			end
		end
		local v487 = v477 or v351(v462.id, v465, v411, v90, v_u_25.redDeep, nil, true)
		if not v487 then
			continue
		end
		v487.Name = "LM_" .. v462.id
	end
	local v488 = #v_u_310
	for _, v489 in v_u_17.GENERATORS or {} do
		if v489.level ~= v_u_87 then
			continue
		end
		local v490 = v489.x
		local v491 = v489.z
		local v492 = Vector2.new(v_u_106 + (v490 - v_u_100[1]) * v_u_105, v_u_107 + (v491 - v_u_100[2]) * v_u_105)
		local v493 = v_u_99 * 28 + 0.5
		local v494 = math.floor(v493)
		local v495 = math.max(22, v494)
		v_u_110 = v_u_110 + 2
		local v496 = {
			["Name"] = "Gen_" .. v489.id,
			["BackgroundColor3"] = Color3.fromRGB(240, 176, 52),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(v492.X, v492.Y),
			["Size"] = UDim2.fromOffset(v495, v495)
		}
		local v497 = Instance.new("Frame")
		v497.BorderSizePixel = 0
		for v498, v499 in v496 do
			v497[v498] = v499
		end
		v497.Parent = v199
		local v500 = UDim.new(0.5, 0)
		local v501 = Instance.new("UICorner")
		v501.CornerRadius = v500
		v501.Parent = v497
		local v502 = v_u_25.ink
		local v503 = Instance.new("UIStroke")
		v503.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v503.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v503.Color = v502
		v503.Thickness = 3
		v503.Transparency = 0
		v503.Parent = v497
		local v504 = v489.id
		local v505 = Vector2.new(v495 / 2, v495 / 2)
		local v506 = v495 * 0.52
		local v507 = math.floor(v506)
		local v508 = math.max(10, v507)
		local v509 = v_u_25.ink
		local v510 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v495, v495)
		}
		local v511 = v_u_4.phoneText
		local v512 = "caption"
		local v513
		if p_u_79 then
			v513 = p_u_79.scale
		else
			v513 = nil
		end
		local v514
		if p_u_79 then
			v514 = p_u_79.phone
		else
			v514 = nil
		end
		v_u_81(v497, v504, v505, v511(v508, v512, v513, v514), v90, v509, v510).Name = "Id"
		local v515 = {
			v492.X - v495 / 2,
			v492.Y - v495 / 2,
			v492.X + v495 / 2,
			v492.Y + v495 / 2
		}
		table.insert(v_u_310, v515)
		local v516 = "GENERATOR " .. (string.match(v489.id, "%d+") or "")
		local v517 = v495 * 0.5 + v419 * 0.7
		local v518 = false
		if v_u_82 or v_u_225 then
			local v519 = v495 * 0.5 + (#v516 * v419 * 0.56 + 6) / 2 + 2
			for _, v520 in {
				Vector2.new(0, v517),
				Vector2.new(0, -v517),
				Vector2.new(v519, 0),
				Vector2.new(-v519, 0)
			} do
				if not v351(v516, v492 + v520, v419, v90, v_u_25.redDeep, nil, false, nil, true) then
					continue
				end
				v518 = true
			end
		end
		if v518 then
			break
		end
		v351(v516, v492 + Vector2.new(0, v517), v419, v90, v_u_25.redDeep, nil, true, nil, true)
	end
	local v521 = 0
	local v522 = v_u_99 * 10 + 0.5
	local v523 = math.floor(v522)
	local v524 = math.max(9, v523)
	local v525 = v_u_4.phoneText
	local v526 = "caption"
	local v527
	if p_u_79 then
		v527 = p_u_79.scale
	else
		v527 = nil
	end
	local v528
	if p_u_79 then
		v528 = p_u_79.phone
	else
		v528 = nil
	end
	local v529 = v525(v524, v526, v527, v528)
	for _, v530 in v_u_17.LINKS or {} do
		local v531 = {}
		if v530.from == v_u_87 then
			local v532 = {
				v530.fx,
				v530.fz,
				"down",
				v530.to
			}
			table.insert(v531, v532)
		end
		if v530.to == v_u_87 then
			local v533 = {
				v530.tx,
				v530.tz,
				"up",
				v530.from
			}
			table.insert(v531, v533)
		end
		for _, v534 in v531 do
			v521 = v521 + 1
			local v535 = v534[1]
			local v536 = v534[2]
			local v537 = Vector2.new(v_u_106 + (v535 - v_u_100[1]) * v_u_105, v_u_107 + (v536 - v_u_100[2]) * v_u_105)
			local v538 = v530.type == "lift"
			local v539 = v_u_99 * 15 + 0.5
			local v540 = math.floor(v539)
			local v541 = math.max(12, v540)
			v_u_110 = v_u_110 + 1
			local v542 = {
				["Name"] = "Link_" .. v530.id .. "_" .. v534[3],
				["BackgroundColor3"] = v_u_25.paperLight,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v537.X, v537.Y),
				["Size"] = UDim2.fromOffset(v541, v541)
			}
			local v543 = Instance.new("Frame")
			v543.BorderSizePixel = 0
			for v544, v545 in v542 do
				v543[v544] = v545
			end
			v543.Parent = v199
			local v546 = v_u_26
			local v547 = Instance.new("UIStroke")
			v547.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v547.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v547.Color = v546
			v547.Thickness = 2
			v547.Transparency = 0
			v547.Parent = v543
			if v538 then
				for _, v548 in { 45, -45 } do
					v_u_110 = v_u_110 + 1
					local v549 = {
						["Name"] = "X",
						["BackgroundColor3"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Rotation"] = nil,
						["BackgroundColor3"] = v_u_26,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Size"] = UDim2.new(1.25, 0, 0, 1),
						["Rotation"] = v548
					}
					local v550 = Instance.new("Frame")
					v550.BorderSizePixel = 0
					for v551, v552 in v549 do
						v550[v551] = v552
					end
					v550.Parent = v543
				end
			else
				local v553 = UDim.new(0.5, 0)
				local v554 = Instance.new("UICorner")
				v554.CornerRadius = v553
				v554.Parent = v543
				local v555 = v534[3] == "down" and 1 or -1
				local v556 = Vector2.new(v541 / 2, v541 / 2)
				local v557 = v556 + Vector2.new(0, v555 * v541 * 0.3)
				v_u_137(v543, v556 - Vector2.new(0, v555 * v541 * 0.3), v557, 2, v_u_26)
				v_u_137(v543, v557, v557 + Vector2.new(-v541 * 0.22, -v555 * v541 * 0.22), 2, v_u_26)
				v_u_137(v543, v557, v557 + Vector2.new(v541 * 0.22, -v555 * v541 * 0.22), 2, v_u_26)
			end
			local v558 = {
				v537.X - v541 / 2,
				v537.Y - v541 / 2,
				v537.X + v541 / 2,
				v537.Y + v541 / 2
			}
			table.insert(v_u_310, v558)
			local v559 = v538 and "LIFT" or (v534[3] == "down" and "DOWN" or "UP")
			local v560 = v534[4]
			local v561 = v559 .. " \194\183 " .. tostring(v560)
			if v538 and v530.cond ~= "" then
				local v562 = string.match(v530.cond, "(G%d)")
				if v562 then
					v561 = v561 .. " (" .. v562 .. ")"
				end
			end
			local v563 = nil
			for _, v564 in {
				Vector2.new(0, v541 * 0.6 + v529 * 0.7),
				Vector2.new(0, -(v541 * 0.6 + v529 * 0.7)),
				Vector2.new(v541 * 0.6 + #v561 * v529 * 0.3, 0),
				Vector2.new(-(v541 * 0.6 + #v561 * v529 * 0.3), 0)
			} do
				v563 = v351(v561, v537 + v564, v529, v90, v_u_26, {
					["TextStrokeTransparency"] = 0.15
				}, false, nil, true)
				if not v563 then
					continue
				end
			end
			if v563 then
				break
			end
			v351(v561, v537 + Vector2.new(0, v541 * 0.6 + v529 * 0.7), v529, v90, v_u_26, {
				["TextStrokeTransparency"] = 0.15
			}, true, nil, true)
		end
	end
	for _, v565 in v_u_17.MARKS or {} do
		if v565.level ~= v_u_87 then
			continue
		end
		local v566 = v565.x
		local v567 = v565.z
		local v568 = Vector2.new(v_u_106 + (v566 - v_u_100[1]) * v_u_105, v_u_107 + (v567 - v_u_100[2]) * v_u_105)
		local v569 = v565.kind == "hazard"
		local v570 = v_u_99 * 8 + 0.5
		local v571 = math.floor(v570)
		local v572 = math.max(6, v571)
		if v_u_225 then
			local v573 = false
			for _, v574 in v_u_310 do
				if v423[v574] or (v568.X + v572 * 0.7 <= v574[1] or (v568.X - v572 * 0.7 >= v574[3] or (v568.Y + v572 * 0.7 <= v574[2] or v568.Y - v572 * 0.7 >= v574[4]))) then
					continue
				end
				v573 = true
			end
			if v573 then
				break
			end
		end
		v_u_110 = v_u_110 + 1
		local v575 = {
			["Name"] = "Poi",
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = 45
		}
		local v576
		if v569 then
			v576 = v_u_25.red
		else
			v576 = v_u_25.landmark
		end
		v575.BackgroundColor3 = v576
		v575.AnchorPoint = Vector2.new(0.5, 0.5)
		v575.Position = UDim2.fromOffset(v568.X, v568.Y)
		v575.Size = UDim2.fromOffset(v572, v572)
		local v577 = Instance.new("Frame")
		v577.BorderSizePixel = 0
		for v578, v579 in v575 do
			v577[v578] = v579
		end
		v577.Parent = v199
		local v580 = v_u_25.landmarkEdge
		local v581 = Instance.new("UIStroke")
		v581.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v581.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v581.Color = v580
		v581.Thickness = 1
		v581.Transparency = 0
		v581.Parent = v577
		local v582
		if v569 then
			v582 = "! " .. v565.text
		else
			v582 = v565.text
		end
		local v583 = v568 + Vector2.new(0, v572 + v419 * 0.6)
		local v584
		if v569 then
			v584 = v_u_25.red
		else
			v584 = v_u_25.landmarkEdge
		end
		v351(v582, v583, v419, v92, v584, {
			["TextStrokeTransparency"] = 0.15
		}, false, nil, v569)
	end
	for _, v585 in v420 do
		if string.find(v585.flags or "", "L", 1, true) then
			continue
		end
		local v586 = (v585.kind == "corridor" or v585.kind == "drift") and true or v585.kind == "shaft"
		local v587 = v585.label[3] * v_u_105
		local v588 = v585.label[4] * v_u_105
		local v589 = v585.label[1]
		local v590 = v585.label[2]
		local v591 = Vector2.new(v_u_106 + (v589 - v_u_100[1]) * v_u_105, v_u_107 + (v590 - v_u_100[2]) * v_u_105)
		if v588 < v419 + 2 then
			continue
		end
		local v592 = not v586 and v351(string.upper(v585.name), v591, v419, v92, v_u_25.ink, {
			["TextStrokeTransparency"] = 0.5
		}, false, v587 - 4)
		if v592 then
			v592.Name = "RN_" .. v585.id
			local v593 = {
				["id"] = nil,
				["kind"] = "name",
				["rect"] = nil,
				["obj"] = nil,
				["id"] = v585.id,
				["rect"] = v_u_310[#v_u_310],
				["obj"] = v592
			}
			table.insert(v318, v593)
		else
			local v594 = v585.id
			local v595 = v419 - 1
			local v596 = v351(v594, v591, math.max(8, v595), v91, v_u_25.inkSoft, {
				["TextStrokeTransparency"] = 0.6
			}, false, v587 - 2)
			if not v596 then
				continue
			end
			v596.Name = "RC_" .. v585.id
			local v597 = {
				["id"] = nil,
				["kind"] = "code",
				["rect"] = nil,
				["obj"] = nil,
				["id"] = v585.id,
				["rect"] = v_u_310[#v_u_310],
				["obj"] = v596
			}
			table.insert(v318, v597)
		end
	end
	for _, v598 in { 0.3333333333333333, 0.6666666666666666 } do
		local v599 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_25.paperLight,
			["Position"] = UDim2.new(v598, 0, 0, 0),
			["Size"] = UDim2.new(0, 2, 1, 0)
		}
		local v600 = Instance.new("Frame")
		v600.BorderSizePixel = 0
		for v601, v602 in v599 do
			v600[v601] = v602
		end
		v600.Parent = v109
		local v603 = {
			["Name"] = "Crease",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.5,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 20,
			["BackgroundColor3"] = v_u_25.crease,
			["Position"] = UDim2.new(v598, 2, 0, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v604 = Instance.new("Frame")
		v604.BorderSizePixel = 0
		for v605, v606 in v603 do
			v604[v605] = v606
		end
		v604.Parent = v109
	end
	local v607 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_25.paperLight,
		["Position"] = UDim2.new(0, 0, 0.5, 0),
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v608 = Instance.new("Frame")
	v608.BorderSizePixel = 0
	for v609, v610 in v607 do
		v608[v609] = v610
	end
	v608.Parent = v109
	local v611 = {
		["Name"] = "Crease",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["BackgroundColor3"] = v_u_25.crease,
		["Position"] = UDim2.new(0, 0, 0.5, 2),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v612 = Instance.new("Frame")
	v612.BorderSizePixel = 0
	for v613, v614 in v611 do
		v612[v613] = v614
	end
	v612.Parent = v109
	local v615 = v402 or v401()
	local v616 = v615.cx
	local v617 = v615.cy
	local v618 = v615.cw
	local v619 = v615.ch
	local v620 = v615.levelText
	local v621 = {
		["Name"] = "Cartouche",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_25.paperLight,
		["Position"] = UDim2.fromOffset(v616, v617),
		["Size"] = UDim2.fromOffset(v618, v619)
	}
	local v622 = Instance.new("Frame")
	v622.BorderSizePixel = 0
	for v623, v624 in v621 do
		v622[v623] = v624
	end
	v622.Parent = v116
	local v625 = v_u_25.ink
	local v626 = Instance.new("UIStroke")
	v626.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v626.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v626.Color = v625
	v626.Thickness = 1
	v626.Transparency = 0
	v626.Parent = v622
	local v627 = v_u_73("The Hollow")
	local v628 = Vector2.new(v618 / 2, v619 * (v_u_82 and 0.31 or 0.27))
	local v629 = v_u_99 * 18
	local v630 = math.floor(v629)
	local v631 = math.max(13, v630)
	local v632 = v_u_4.phoneText
	local v633 = "text"
	local v634
	if p_u_79 then
		v634 = p_u_79.scale
	else
		v634 = nil
	end
	local v635
	if p_u_79 then
		v635 = p_u_79.phone
	else
		v635 = nil
	end
	local v636 = v632(v631, v633, v634, v635)
	local v637 = v_u_25.ink
	local v638 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(v618 - 8, v619 * (v_u_82 and 0.42 or 0.4))
	}
	local v639 = v_u_4.phoneText
	local v640 = "caption"
	local v641
	if p_u_79 then
		v641 = p_u_79.scale
	else
		v641 = nil
	end
	local v642
	if p_u_79 then
		v642 = p_u_79.phone
	else
		v642 = nil
	end
	local v643 = v_u_81(v622, v627, v628, v639(v636, v640, v641, v642), v90, v637, v638)
	v643.Name = "Title"
	v643.ZIndex = 11
	local v644 = Vector2.new(v618 / 2, v619 * (v_u_82 and 0.72 or 0.58))
	local v645 = v_u_99 * 12
	local v646 = math.floor(v645)
	local v647 = math.max(10, v646)
	local v648 = v_u_4.phoneText
	local v649 = "text"
	local v650
	if p_u_79 then
		v650 = p_u_79.scale
	else
		v650 = nil
	end
	local v651
	if p_u_79 then
		v651 = p_u_79.phone
	else
		v651 = nil
	end
	local v652 = v648(v647, v649, v650, v651)
	local v653 = v_u_25.redDeep
	local v654 = {
		["TextStrokeTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(v618 - 8, v619 * (v_u_82 and 0.42 or 0.24))
	}
	local v655 = v_u_4.phoneText
	local v656 = "caption"
	local v657
	if p_u_79 then
		v657 = p_u_79.scale
	else
		v657 = nil
	end
	local v658
	if p_u_79 then
		v658 = p_u_79.phone
	else
		v658 = nil
	end
	local v659 = v_u_81(v622, v620, v644, v655(v652, v656, v657, v658), v90, v653, v654)
	v659.Name = "Level"
	v659.ZIndex = 11
	local v660 = v85.title or ""
	local v661 = string.match(v660, ":%s*(.+)$") or (string.match(v660, "/%s*(.+)$") or "")
	local v662
	if v661 == "" then
		v662 = "Site survey"
	else
		local v663 = string.lower(v661)
		v662 = string.upper((string.sub(v663, 1, 1))) .. string.sub(v663, 2)
	end
	if not v_u_82 then
		local v664 = Vector2.new(v618 / 2, v619 * 0.82)
		local v665 = v_u_99 * 10
		local v666 = math.floor(v665)
		local v667 = math.max(9, v666)
		local v668 = v_u_25.inkSoft
		local v669 = {
			["TextStrokeTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v618 - 8, v619 * 0.2)
		}
		local v670 = v_u_4.phoneText
		local v671 = "caption"
		local v672
		if p_u_79 then
			v672 = p_u_79.scale
		else
			v672 = nil
		end
		local v673
		if p_u_79 then
			v673 = p_u_79.phone
		else
			v673 = nil
		end
		local v674 = v_u_81(v622, v662, v664, v670(v667, v671, v672, v673), v91, v668, v669)
		v674.Name = "Sub"
		v674.ZIndex = 11
	end
	if not v402 then
		local v675 = {
			v616,
			v617,
			v616 + v618,
			v617 + v619
		}
		table.insert(v_u_310, 1, v675)
		v488 = v488 + 1
	end
	local v676 = v425 or v_u_97 - v_u_99 * 30 - 6
	local v677 = v98 - v_u_99 * 44 - 8
	local v678 = v_u_99 * 14
	local v679 = math.floor(v678)
	local v680 = math.max(11, v679)
	local v681 = Vector2.new
	local v682
	if v_u_225 then
		local v683 = v_u_99 * 20 + 3
		local v684 = v_u_99 * 15 + v680 * 0.5 + 3
		v682 = math.max(v683, v684)
	else
		v682 = v_u_99 * 20
	end
	local v685 = v681(v676, v677 - v682)
	local v686 = v_u_25.ink
	local v687 = {
		["TextStrokeTransparency"] = 1
	}
	local v688 = "N"
	local v689 = v_u_4.phoneText
	local v690 = "caption"
	local v691
	if p_u_79 then
		v691 = p_u_79.scale
	else
		v691 = nil
	end
	local v692
	if p_u_79 then
		v692 = p_u_79.phone
	else
		v692 = nil
	end
	v_u_81(v116, v688, v685, v689(v680, v690, v691, v692), v90, v686, v687).ZIndex = 10
	local v693 = {
		["Name"] = "Needle",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_25.ink,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v676, v677),
		["Size"] = UDim2.fromOffset(2, 26 * v_u_99)
	}
	local v694 = Instance.new("Frame")
	v694.BorderSizePixel = 0
	for v695, v696 in v693 do
		v694[v695] = v696
	end
	v694.Parent = v116
	local v697 = {
		["Name"] = "NeedleTip",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["ZIndex"] = 10,
		["BackgroundColor3"] = v_u_25.red,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v676, v677 - v_u_99 * 8),
		["Size"] = UDim2.fromOffset(v_u_99 * 6, v_u_99 * 6)
	}
	local v698 = Instance.new("Frame")
	v698.BorderSizePixel = 0
	for v699, v700 in v697 do
		v698[v699] = v700
	end
	v698.Parent = v116
	local v701 = {
		["Name"] = "Ring",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v676, v677),
		["Size"] = UDim2.fromOffset(v_u_99 * 30, v_u_99 * 30)
	}
	local v702 = Instance.new("Frame")
	v702.BorderSizePixel = 0
	for v703, v704 in v701 do
		v702[v703] = v704
	end
	v702.Parent = v116
	local v705 = UDim.new(0.5, 0)
	local v706 = Instance.new("UICorner")
	v706.CornerRadius = v705
	v706.Parent = v702
	local v707 = v_u_25.ink
	local v708 = Instance.new("UIStroke")
	v708.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v708.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	v708.Color = v707
	v708.Thickness = 1
	v708.Transparency = 0.3
	v708.Parent = v702
	local v709 = v_u_105 * 50 / (v_u_17.STUDS_TO_M or 0.28) > v_u_99 * 160 and 25 or 50
	local v710 = v709 / (v_u_17.STUDS_TO_M or 0.28) * v_u_105
	local v711 = v_u_99 * 14 + 4
	local v712 = v98 - v_u_99 * 20 - 6
	local v713 = {
		["Name"] = "ScaleBar",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["Position"] = UDim2.fromOffset(v711, v712)
	}
	local v714 = UDim2.fromOffset
	local v715 = v_u_99 * 5
	v713.Size = v714(v710, (math.max(3, v715)))
	local v716 = Instance.new("Frame")
	v716.BorderSizePixel = 0
	for v717, v718 in v713 do
		v716[v717] = v718
	end
	v716.Parent = v116
	for v719 = 0, 3 do
		local v720 = {
			["Name"] = "Scale",
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 10
		}
		local v721
		if v719 % 2 == 0 then
			v721 = v_u_25.ink
		else
			v721 = v_u_25.paperLight
		end
		v720.BackgroundColor3 = v721
		v720.Position = UDim2.fromScale(v719 / 4, 0)
		v720.Size = UDim2.fromScale(0.25, 1)
		local v722 = Instance.new("Frame")
		v722.BorderSizePixel = 0
		for v723, v724 in v720 do
			v722[v723] = v724
		end
		v722.Parent = v716
		local v725 = v_u_25.ink
		local v726 = Instance.new("UIStroke")
		v726.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v726.BorderStrokePosition = Enum.BorderStrokePosition.Inner
		v726.Color = v725
		v726.Thickness = 1
		v726.Transparency = 0
		v726.Parent = v722
	end
	local v727
	if v_u_225 then
		v727 = v_u_99 * 9 + 3
	else
		v727 = v_u_99 * 9
	end
	local v728 = Vector2.new(v711, v712 - v727)
	local v729 = 11 * v_u_99
	local v730 = math.floor(v729)
	local v731 = math.max(9, v730)
	local v732 = v_u_25.ink
	local v733 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v734 = "0"
	local v735 = v_u_4.phoneText
	local v736 = v731
	local v737 = "caption"
	local v738
	if p_u_79 then
		v738 = p_u_79.scale
	else
		v738 = nil
	end
	local v739
	if p_u_79 then
		v739 = p_u_79.phone
	else
		v739 = nil
	end
	v_u_81(v116, v734, v728, v735(v736, v737, v738, v739), v92, v732, v733).ZIndex = 10
	local v740 = v709 .. " m"
	local v741 = Vector2.new(v711 + v710, v712 - v727)
	local v742 = 11 * v_u_99
	local v743 = math.floor(v742)
	local v744 = math.max(9, v743)
	local v745 = v_u_25.ink
	local v746 = {
		["TextStrokeTransparency"] = 0.4
	}
	local v747 = v741
	local v748 = v_u_4.phoneText
	local v749 = "caption"
	local v750
	if p_u_79 then
		v750 = p_u_79.scale
	else
		v750 = nil
	end
	local v751
	if p_u_79 then
		v751 = p_u_79.phone
	else
		v751 = nil
	end
	v_u_81(v116, v740, v747, v748(v744, v749, v750, v751), v92, v745, v746).ZIndex = 10
	if not v_u_225 then
		local v752 = {
			v711 - 8,
			v712 - v_u_99 * 18,
			v711 + v710 + 24,
			v712 + 8
		}
		table.insert(v_u_310, v752)
	end
	local v753 = {
		["Name"] = "ObjectiveRooms",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_754 = Instance.new("Frame")
	v_u_754.BorderSizePixel = 0
	for v755, v756 in v753 do
		v_u_754[v755] = v756
	end
	v_u_754.Parent = v116
	local v_u_757 = {}
	for _, v758 in v_u_224 do
		v_u_757[v758.id] = v758
	end
	local function v_u_773(p759) -- name: areaPxOf
		-- upvalues: (copy) v_u_105, (copy) v_u_106, (copy) v_u_100, (copy) v_u_107
		if p759.box then
			return p759.box[3] * v_u_105 * p759.box[4] * v_u_105
		end
		local v760 = p759.poly or {}
		local v761 = (-1 / 0)
		local v762 = (-1 / 0)
		local v763 = (1 / 0)
		local v764 = (1 / 0)
		for v765 = 1, #v760 - 1, 2 do
			local v766 = v760[v765]
			local v767 = v760[v765 + 1]
			local v768 = Vector2.new(v_u_106 + (v766 - v_u_100[1]) * v_u_105, v_u_107 + (v767 - v_u_100[2]) * v_u_105)
			local v769 = v768.X
			v763 = math.min(v763, v769)
			local v770 = v768.Y
			v764 = math.min(v764, v770)
			local v771 = v768.X
			v761 = math.max(v761, v771)
			local v772 = v768.Y
			v762 = math.max(v762, v772)
		end
		return v761 < v763 and 0 or (v761 - v763) * (v762 - v764) * 0.7
	end
	local v_u_774 = {}
	local function v_u_815(p775) -- name: paintObjectiveRoom
		-- upvalues: (copy) v_u_754, (copy) v_u_225, (ref) v_u_9, (copy) v_u_773, (copy) v_u_159, (ref) v_u_27, (copy) v_u_208, (copy) v_u_105, (copy) v_u_228, (copy) v_u_229, (copy) v_u_774, (copy) v_u_137, (copy) v_u_106, (copy) v_u_100, (copy) v_u_107
		local v776 = v_u_754
		local v777 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Name"] = "O_" .. p775.id,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v778 = Instance.new("Frame")
		v778.BorderSizePixel = 0
		for v779, v780 in v777 do
			v778[v779] = v780
		end
		v778.Parent = v776
		local v781 = not v_u_225 and 0.45 or v_u_9.washMix((v_u_773(p775)))
		if p775.box then
			local v782 = p775.box
			local v783 = v_u_159(v778, v782[1], v782[2], v782[3], v782[4], v782[5], v_u_27, 3)
			v783.BackgroundTransparency = not v_u_225 and 0.55 or 1 - v781
			local v784 = v_u_27
			local v785 = v_u_208 + 1
			local v786 = math.max(2, v785)
			local v787 = Instance.new("UIStroke")
			v787.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v787.BorderStrokePosition = Enum.BorderStrokePosition.Inner
			v787.Color = v784
			v787.Thickness = v786
			v787.Transparency = 0
			v787.Parent = v783
		elseif p775.poly then
			local v788 = p775.fillRot or 0
			local v789 = math.rad(v788)
			local v790 = math.cos(v789)
			local v791 = math.sin(v789)
			local v792 = p775.fill or {}
			local v793 = 1.2 / v_u_105
			local v794 = math.max(0.4, v793)
			if v_u_225 and v_u_228[p775.id] then
				for _, v795 in v_u_228[p775.id] do
					v795.BackgroundColor3 = v_u_229[p775.id]:Lerp(v_u_27, v781)
				end
				v_u_774[p775.id] = true
			else
				for v796 = 1, #v792 - 3, 4 do
					local v797 = v792[v796]
					local v798 = v792[v796 + 1]
					local v799 = v792[v796 + 2]
					local v800 = v792[v796 + 3]
					local v801 = (v797 + v799) / 2
					local v802 = (v798 + v800) / 2
					v_u_159(v778, v801 * v790 - v802 * v791, v801 * v791 + v802 * v790, v799 - v797 + v794, v800 - v798 + v794, p775.fillRot or 0, v_u_27, 1).BackgroundTransparency = 0.55
				end
			end
			local v803 = p775.poly
			local v804 = #v803 // 2
			for v805 = 1, v804 do
				local v806 = v805 % v804 + 1
				local v807 = v_u_137
				local v808 = v803[v805 * 2 - 1]
				local v809 = v803[v805 * 2]
				local v810 = Vector2.new(v_u_106 + (v808 - v_u_100[1]) * v_u_105, v_u_107 + (v809 - v_u_100[2]) * v_u_105)
				local v811 = v803[v806 * 2 - 1]
				local v812 = v803[v806 * 2]
				local v813 = Vector2.new(v_u_106 + (v811 - v_u_100[1]) * v_u_105, v_u_107 + (v812 - v_u_100[2]) * v_u_105)
				local v814 = v_u_208 + 1
				v807(v778, v810, v813, math.max(2, v814), v_u_27, 0.1)
			end
		end
	end
	local v_u_816 = nil
	local function v_u_831() -- name: refreshObjectives
		-- upvalues: (copy) v_u_754, (copy) v_u_774, (copy) v_u_228, (copy) v_u_229, (ref) v_u_1, (ref) v_u_2, (copy) v_u_757, (ref) v_u_816, (copy) v_u_815
		for _, v817 in v_u_754:GetChildren() do
			v817:Destroy()
		end
		for v818 in v_u_774 do
			for _, v819 in v_u_228[v818] or {} do
				v819.BackgroundColor3 = v_u_229[v818]
			end
		end
		table.clear(v_u_774)
		local v820 = v_u_1.LocalPlayer
		if v820 then
			v820 = v820:GetAttribute("TaskPlaces")
		end
		if type(v820) == "string" and v820 ~= "" then
			local v821 = v_u_2.JSONDecode
			local v822 = v_u_2
			local v823, v824 = pcall(v821, v822, v820)
			if v823 and type(v824) == "table" then
				local v825 = {}
				for _, v826 in v824 do
					local v827
					if type(v826) == "table" then
						local v828 = v826.room
						if type(v828) == "string" then
							v827 = v826.room
						else
							v827 = v826.where
						end
					else
						v827 = nil
					end
					if type(v827) ~= "string" then
						continue
					end
					local v829 = string.upper(v827)
					local v830 = v_u_757[v829]
					if not v830 or (v825[v829] or v_u_816 ~= nil and not v_u_816(v826)) then
						continue
					end
					v825[v829] = true
					v_u_815(v830)
				end
			end
		else
			return
		end
	end
	v_u_831()
	local v832 = v_u_1.LocalPlayer
	if v832 then
		local v_u_833 = v832:GetAttributeChangedSignal("TaskPlaces"):Connect(v_u_831)
		v109.Destroying:Connect(function()
			-- upvalues: (copy) v_u_833
			v_u_833:Disconnect()
		end)
	end
	local v834 = {
		["Name"] = "Marks",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v835 = Instance.new("Frame")
	v835.BorderSizePixel = 0
	local v_u_836 = v_u_816
	for v837, v838 in v834 do
		v835[v837] = v838
	end
	v835.Parent = v116
	v109:SetAttribute("Frames", v_u_110)
	return {
		["refreshObjectives"] = nil,
		["setObjectiveFilter"] = nil,
		["nameLabels"] = nil,
		["nameRects"] = nil,
		["frame"] = nil,
		["area"] = nil,
		["marks"] = nil,
		["toPx"] = nil,
		["toWorld"] = nil,
		["inside"] = nil,
		["placed"] = nil,
		["removable"] = nil,
		["nLandmarks"] = nil,
		["scale"] = nil,
		["k"] = nil,
		["ink"] = nil,
		["inner"] = nil,
		["innerW"] = nil,
		["innerH"] = nil,
		["level"] = nil,
		["levelIndex"] = nil,
		["floorY"] = nil,
		["hollow"] = true,
		["stats"] = nil,
		["refreshObjectives"] = v_u_831,
		["setObjectiveFilter"] = function(p839) -- name: setObjectiveFilter
			-- upvalues: (ref) v_u_836, (copy) v_u_831
			v_u_836 = p839
			v_u_831()
		end,
		["nameLabels"] = v_u_319,
		["nameRects"] = v_u_320,
		["frame"] = v109,
		["area"] = v116,
		["marks"] = v835,
		["toPx"] = v140,
		["toWorld"] = function(p840, p841) -- name: toWorld
			-- upvalues: (copy) v_u_106, (copy) v_u_105, (copy) v_u_100, (copy) v_u_107
			return Vector2.new((p840 - v_u_106) / v_u_105 + v_u_100[1], (p841 - v_u_107) / v_u_105 + v_u_100[2])
		end,
		["inside"] = function(p842, p843) -- name: inside
			-- upvalues: (copy) v_u_100
			local v844
			if v_u_100[1] <= p842 and (p842 <= v_u_100[3] and v_u_100[2] <= p843) then
				v844 = p843 <= v_u_100[4]
			else
				v844 = false
			end
			return v844
		end,
		["placed"] = v_u_310,
		["removable"] = v318,
		["nLandmarks"] = v488,
		["scale"] = v_u_105,
		["k"] = v_u_99,
		["ink"] = v_u_25,
		["inner"] = math.min(v_u_97, v98),
		["innerW"] = v_u_97,
		["innerH"] = v98,
		["level"] = v_u_87,
		["levelIndex"] = v_u_86,
		["floorY"] = v88,
		["stats"] = {
			["rooms"] = #v_u_224,
			["frames"] = v_u_110,
			["labels"] = v424,
			["doors"] = v287,
			["links"] = v521
		}
	}
end
return v_u_13