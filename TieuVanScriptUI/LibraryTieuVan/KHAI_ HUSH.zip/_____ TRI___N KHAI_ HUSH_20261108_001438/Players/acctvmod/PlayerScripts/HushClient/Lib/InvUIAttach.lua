-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIAttach

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_2 = require(v1:WaitForChild("Items"))
local v_u_86 = {
	["ACTION"] = "attachto:",
	["WEAPON_SLOTS"] = { "primary", "secondary" },
	["env"] = {},
	["fits"] = function(p3, p4) -- name: fits
		-- upvalues: (copy) v_u_2
		if type(p3) ~= "table" or (type(p4) ~= "table" or p3.uid == p4.uid) then
			return false
		end
		local v5 = v_u_2.get(p3.id)
		local v6 = v_u_2.get(p4.id)
		if not v5 or (v5.category ~= "attachment" or (not v6 or v6.category ~= "firearm")) then
			return false
		end
		local v7 = v_u_2.fitsWeapon(v5, p4.id)
		if not v7 then
			if v6.weaponId == nil then
				v7 = false
			else
				v7 = v_u_2.fitsWeapon(v5, v6.weaponId)
			end
		end
		return v7
	end,
	["canSource"] = function(p8, p9) -- name: canSource
		local v10
		if type(p8) == "table" and p8.kind == "grid" then
			v10 = p8.container ~= p9
		else
			v10 = false
		end
		return v10
	end,
	["slotTarget"] = function(p11, p12, p13) -- name: slotTarget
		-- upvalues: (copy) v_u_86
		if p13 == "primary" or p13 == "secondary" then
			local v14
			if type(p11) == "table" then
				v14 = p11.kit or nil
			else
				v14 = nil
			end
			local v15
			if type(v14) == "table" then
				v15 = v14.slots
				if v15 then
					v15 = v14.slots[p13]
				end
				if v15 == nil then
					v15 = v14[p13]
				end
				if type(v15) ~= "table" then
					v15 = nil
				end
			else
				v15 = nil
			end
			if v15 and v_u_86.fits(p12, v15) then
				return v15
			else
				return nil
			end
		else
			return nil
		end
	end,
	["targets"] = function(p16, p17) -- name: targets
		-- upvalues: (copy) v_u_2, (copy) v_u_86
		local v18 = v_u_2.get(p17 and (p17.id or "") or "")
		local v19 = {}
		for _, v20 in v_u_86.WEAPON_SLOTS do
			local v21 = v_u_86.slotTarget(p16, p17, v20)
			if not v21 then
				continue
			end
			local v22 = v_u_2.get(v21.id)
			local v23
			if v18 then
				local v24 = v21.mods
				if type(v24) == "table" then
					v23 = v21.mods[v18.slot] or nil
				else
					v23 = nil
				end
			else
				v23 = nil
			end
			local v25
			if type(v23) == "table" then
				v25 = v_u_2.get(v23.id) or nil
			else
				v25 = nil
			end
			local v26 = {
				["uid"] = v21.uid,
				["slot"] = v20,
				["short"] = v22 and (v22.short or v22.name) or v21.id,
				["replaces"] = not v25 or v25.short or (v25.name or nil)
			}
			table.insert(v19, v26)
		end
		return v19
	end,
	["SLOT_NAMES"] = {
		["muzzle"] = "Muzzle",
		["sight"] = "Sight",
		["tactical"] = "Tactical",
		["grip"] = "Grip",
		["stock"] = "Stock",
		["mag"] = "Magazine"
	},
	["attachBlock"] = function(p_u_27, p_u_28, p29, p30, p31, p_u_32) -- name: attachBlock
		-- upvalues: (copy) v_u_86, (copy) v_u_2
		local v33 = v_u_86.env
		local v_u_34 = v33.new
		local v_u_35 = v33.label
		local v_u_36 = v33.stroke
		local v_u_37 = v33.sound
		local v_u_38 = v33.send
		local v_u_39 = v33.C
		local v40 = v33.Theme
		local v41 = v33.ItemIcons
		local v42 = {}
		if p29.category == "firearm" then
			local v43 = p29.modSlots
			if type(v43) == "table" and #p29.modSlots ~= 0 then
				v_u_35(v_u_34("Frame", {
					["Name"] = "AttachHead",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["ZIndex"] = 63,
					["Size"] = UDim2.new(1, -6, 0, 30),
					["LayoutOrder"] = p31
				}, p30), "ATTACHMENTS", "caps", {
					["position"] = UDim2.fromOffset(8, 10),
					["size"] = UDim2.new(1, -8, 0, 18),
					["color"] = v_u_39.accent
				}).ZIndex = 64
				local v44 = {}
				local v45 = p_u_27.work
				local v46
				if type(v45) == "table" then
					local v47 = p_u_27.work.containers
					v46 = type(v47) ~= "table" and {} or p_u_27.work.containers
				else
					v46 = {}
				end
				for _, v48 in v46 do
					if type(v48) ~= "table" then
						continue
					end
					local v49 = v48.items
					if type(v49) ~= "table" then
						continue
					end
					for _, v50 in v48.items do
						local v51 = v_u_2.get(v50.id)
						if not v51 or (v51.category ~= "attachment" or v44[v50.id]) then
							continue
						end
						v44[v50.id] = v50.uid
					end
				end
				local v_u_52 = v40.touch(26)
				local v53 = {}
				local function v61(p54, p55, p56, p57, p_u_58) -- name: button
					-- upvalues: (copy) v_u_34, (copy) v_u_39, (copy) v_u_52, (copy) v_u_36, (copy) v_u_35, (copy) v_u_37, (copy) p_u_32
					local v59 = v_u_34("TextButton", {
						["Name"] = nil,
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["Text"] = "",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 65,
						["Name"] = "Btn_" .. p55,
						["BackgroundColor3"] = v_u_39.raised,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = p56,
						["Size"] = UDim2.fromOffset(p57, v_u_52)
					}, p54)
					v_u_36(v59, v_u_39.lineStrong)
					local v60 = v_u_35(v59, string.upper(p55), "caps", {
						["size"] = UDim2.new(1, -8, 1, 0),
						["position"] = UDim2.fromOffset(4, 0),
						["color"] = v_u_39.text
					})
					v60.ZIndex = 66
					v60.TextXAlignment = Enum.TextXAlignment.Center
					v60.TextYAlignment = Enum.TextYAlignment.Center
					v59.Activated:Connect(function()
						-- upvalues: (ref) v_u_37, (copy) p_u_58, (ref) p_u_32
						v_u_37("click")
						p_u_58()
						task.delay(0.45, p_u_32)
					end)
					return v59
				end
				for _, v62 in v_u_2.byCategory("attachment") do
					if not v_u_2.fitsWeapon(v62, p29.id) then
						continue
					end
					table.insert(v53, v62)
				end
				for v63, v_u_64 in p29.modSlots do
					local v65 = p_u_28.mods
					local v66
					if type(v65) == "table" then
						v66 = p_u_28.mods[v_u_64] or nil
					else
						v66 = nil
					end
					local v67
					if type(v66) == "table" then
						v67 = v_u_2.get(v66.id)
					else
						v67 = nil
					end
					local v68 = v_u_34("Frame", {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = nil,
						["ZIndex"] = 63,
						["Name"] = "Slot_" .. v_u_64,
						["BackgroundColor3"] = v_u_39.raised,
						["BackgroundTransparency"] = v63 % 2 == 0 and 1 or 0.4,
						["Size"] = UDim2.new(1, -6, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["LayoutOrder"] = p31 + v63
					}, p30)
					local v69 = v_u_35(v68, string.upper(v_u_86.SLOT_NAMES[v_u_64] or v_u_64), "caps", {
						["position"] = UDim2.fromOffset(8, 4),
						["size"] = UDim2.new(0, 70, 0, v_u_52),
						["color"] = v_u_39.text2
					})
					v69.ZIndex = 64
					v69.TextYAlignment = Enum.TextYAlignment.Center
					if v67 then
						local v70 = v_u_34("Frame", {
							["BackgroundColor3"] = nil,
							["BorderSizePixel"] = 0,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 64,
							["BackgroundColor3"] = v_u_39.bgDeep,
							["Position"] = UDim2.fromOffset(80, 4),
							["Size"] = UDim2.fromOffset(v_u_52, v_u_52)
						}, v68)
						local v71 = v41.get
						local v72 = v67.id
						local v73, v74 = pcall(v71, v72, false, {
							["parent"] = nil,
							["zindex"] = 65,
							["parent"] = v70
						})
						if v73 and v74 then
							table.insert(v42, v74)
						end
						local v75 = v_u_35(v68, v67.name, "small", {
							["position"] = UDim2.fromOffset(86 + v_u_52, 4),
							["size"] = UDim2.new(1, -(86 + v_u_52 + 96), 0, v_u_52),
							["color"] = v_u_39.info
						})
						v75.ZIndex = 64
						v75.TextYAlignment = Enum.TextYAlignment.Center
						v75.TextTruncate = Enum.TextTruncate.AtEnd
						v61(v68, "Detach", UDim2.new(1, -6, 0, 4), 84, function()
							-- upvalues: (copy) v_u_38, (copy) p_u_27, (copy) p_u_28, (copy) v_u_64
							v_u_38(p_u_27, {
								["op"] = "detach",
								["weaponUid"] = nil,
								["slot"] = nil,
								["weaponUid"] = p_u_28.uid,
								["slot"] = v_u_64
							})
						end)
						v_u_34("Frame", {
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, 0, 0, v_u_52 + 8)
						}, v68)
					else
						local v76 = v_u_35(v68, "Empty", "small", {
							["position"] = UDim2.fromOffset(80, 4),
							["size"] = UDim2.new(1, -86, 0, v_u_52),
							["color"] = v_u_39.muted
						})
						v76.ZIndex = 64
						v76.TextYAlignment = Enum.TextYAlignment.Center
						local v77 = {}
						local v78 = {}
						for _, v79 in v53 do
							if v79.slot ~= v_u_64 then
								continue
							end
							local v80 = v79.name
							table.insert(v77, v80)
							if not v44[v79.id] then
								continue
							end
							table.insert(v78, v79)
						end
						local v81 = v_u_52 + 6
						if #v77 > 0 then
							local v82 = v_u_35(v68, "Fits: " .. table.concat(v77, ", "), "small", {
								["position"] = nil,
								["size"] = nil,
								["wrap"] = true,
								["color"] = nil,
								["position"] = UDim2.fromOffset(80, v81),
								["size"] = UDim2.new(1, -86, 0, 34),
								["color"] = v_u_39.text2
							})
							v82.ZIndex = 64
							v82.TextWrapped = true
							v82.TextYAlignment = Enum.TextYAlignment.Top
							v81 = v81 + 36
						end
						for _, v83 in v78 do
							local v_u_84 = v44[v83.id]
							local v85 = v_u_35(v68, v83.name, "small", {
								["position"] = UDim2.fromOffset(80, v81),
								["size"] = UDim2.new(1, -182, 0, v_u_52),
								["color"] = v_u_39.text
							})
							v85.ZIndex = 64
							v85.TextYAlignment = Enum.TextYAlignment.Center
							v85.TextTruncate = Enum.TextTruncate.AtEnd
							v61(v68, "Attach", UDim2.new(1, -6, 0, v81), 84, function()
								-- upvalues: (copy) v_u_38, (copy) p_u_27, (copy) v_u_84, (copy) p_u_28
								v_u_38(p_u_27, {
									["op"] = "attach",
									["uid"] = nil,
									["weaponUid"] = nil,
									["uid"] = v_u_84,
									["weaponUid"] = p_u_28.uid
								})
							end)
							v81 = v81 + (v_u_52 + 4)
						end
						v_u_34("Frame", {
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, 0, 0, v81 + 4)
						}, v68)
					end
				end
				v_u_34("Frame", {
					["Name"] = "AttachGap",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Size"] = UDim2.new(1, -6, 0, 10),
					["LayoutOrder"] = p31 + #p29.modSlots + 1
				}, p30)
				return v42
			end
		end
		return v42
	end
}
return v_u_86