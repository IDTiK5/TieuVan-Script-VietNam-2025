-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GlobeTable

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("GuiService")
local v4 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_5 = require(v4:WaitForChild("Theme"))
local v_u_6 = require(v4:WaitForChild("GlobeLayout"))
local v_u_7 = require(v4:WaitForChild("GlobeText"))
local v_u_8 = require(v4:WaitForChild("GlobeMath"))
local v_u_9 = require(script.Parent:WaitForChild("HushUI"))
local v_u_10 = v1.LocalPlayer
local v_u_11 = v_u_5.color
local v_u_12 = math.floor
local v_u_13 = math.min
local v_u_14 = math.max
local v_u_15 = math.sqrt
local v_u_16 = v_u_6.RULES
local v_u_17 = {
	["TUNING"] = {
		["GUI_NAME"] = "HushGlobe",
		["ROW_H"] = 84,
		["MINI_D"] = 76,
		["SPIN_S"] = 2.5,
		["SPIN_FROM_DEG"] = 75,
		["TAP_PX"] = 10,
		["PRIME_FRAMES"] = 2,
		["PRIME_BOX_MS"] = 3,
		["PHASE_A_MAX_S"] = 0.45,
		["DEBOUNCE_S"] = 0.15,
		["CARD_PAD_V"] = 8,
		["BODY_MAX_LINES"] = 3
	}
}
local v_u_18 = v_u_17.TUNING
v_u_17.TEST = {
	["inject"] = nil
}
local v_u_19 = 0
function v_u_17.connCount() -- name: connCount
	-- upvalues: (ref) v_u_19
	return v_u_19
end
function v_u_17.tapGesture(p20) -- name: tapGesture
	-- upvalues: (copy) v_u_18, (copy) v_u_15
	local v_u_36 = {
		["slop"] = nil,
		["active"] = false,
		["sx"] = 0,
		["sy"] = 0,
		["travel"] = 0,
		["moved"] = false,
		["taps"] = 0,
		["drags"] = 0,
		["slop"] = p20 or v_u_18.TAP_PX,
		["down"] = function(p21, p22) -- name: down
			-- upvalues: (copy) v_u_36
			local v23 = v_u_36
			local v24 = v_u_36
			local v25 = v_u_36
			local v26 = v_u_36
			v_u_36.active = true
			v23.sx = p21
			v24.sy = p22
			v25.travel = 0
			v26.moved = false
		end,
		["move"] = function(p27, p28) -- name: move
			-- upvalues: (copy) v_u_36, (ref) v_u_15
			if v_u_36.active then
				local v29 = v_u_15((p27 - v_u_36.sx) ^ 2 + (p28 - v_u_36.sy) ^ 2)
				if v_u_36.travel < v29 then
					v_u_36.travel = v29
				end
				if v_u_36.slop < v29 then
					v_u_36.moved = true
				end
			end
		end,
		["finish"] = function(p30, p31) -- name: finish
			-- upvalues: (copy) v_u_36
			if v_u_36.active and (p30 and p31) then
				v_u_36.move(p30, p31)
			end
			local v32 = not v_u_36.moved
			if v_u_36.active then
				if v32 then
					local v33 = v_u_36
					v33.taps = v33.taps + 1
				else
					local v34 = v_u_36
					v34.drags = v34.drags + 1
				end
			else
				local v35 = v_u_36
				v35.taps = v35.taps + 1
			end
			v_u_36.active = false
			v_u_36.moved = false
			v_u_36.travel = 0
			return v32
		end
	}
	return v_u_36
end
function v_u_17.measure(p37) -- name: measure
	-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_6
	local v38 = p37 or {}
	local v39, v40
	if v38.size then
		local v41 = v38.size()
		v39 = v41.X
		v40 = v41.Y
	else
		local v42 = v_u_5.safeRefSize()
		v39 = v42.X
		v40 = v42.Y
	end
	local v43
	if v38.topInset then
		v43 = v38.topInset()
	else
		v43 = v_u_9.topInset()
	end
	local v44
	if v38.topLeftW then
		v44 = v38.topLeftW()
	else
		v44 = v_u_6.FALLBACK.topLeftW
	end
	return {
		["W"] = v39,
		["H"] = v40,
		["topInset"] = v43,
		["topLeftW"] = v44
	}
end
function v_u_17.solve(p45) -- name: solve
	-- upvalues: (copy) v_u_6
	return v_u_6.solve({
		["pageW"] = nil,
		["pageH"] = nil,
		["tableW"] = nil,
		["tableH"] = nil,
		["phone"] = true,
		["compact"] = true,
		["topInset"] = nil,
		["topLeftW"] = nil,
		["pageW"] = p45.W,
		["pageH"] = p45.H,
		["tableW"] = p45.W,
		["tableH"] = p45.H,
		["topInset"] = p45.topInset,
		["topLeftW"] = p45.topLeftW
	})
end
function v_u_17.rectsOverlap(p46, p47) -- name: rectsOverlap
	local v48
	if p46.x < p47.x + p47.w and (p47.x < p46.x + p46.w and p46.y < p47.y + p47.h) then
		v48 = p47.y < p46.y + p46.h
	else
		v48 = false
	end
	return v48
end
local function v_u_53() -- name: loadMods
	local v_u_49 = script.Parent
	local v_u_50 = {}
	local v51, v52 = pcall(function()
		-- upvalues: (copy) v_u_50, (copy) v_u_49
		v_u_50.View = require(v_u_49:WaitForChild("GlobeView"))
		v_u_50.Input = require(v_u_49:WaitForChild("GlobeInput"))
		v_u_50.Dots = require(v_u_49:WaitForChild("GlobeDots"))
	end)
	if v51 then
		return v_u_50, nil
	else
		return nil, v52
	end
end
local function v_u_61(p_u_54) -- name: viewPin
	local v55 = {}
	local v56, v57 = pcall(function()
		-- upvalues: (copy) p_u_54
		return p_u_54.hooks.pins()
	end)
	if v56 then
		if type(v57) ~= "table" then
			v57 = v55
		end
	else
		v57 = v55
	end
	local v58 = nil
	local v59 = nil
	for _, v60 in v57 do
		if type(v60) ~= "table" then
			continue
		end
		v58 = v58 or v60
		if v60.viewing then
			return v60
		end
		if not v60.deploy then
			continue
		end
		v59 = v59 or v60
	end
	return v59 or v58
end
local function v_u_77(p62, p63, p64, p65, p66) -- name: roundButton
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_12
	local v67 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = true,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = p63,
		["BackgroundColor3"] = v_u_11.bgDeep,
		["Size"] = UDim2.fromOffset(p66, p66),
		["LayoutOrder"] = p65
	}
	local v_u_68 = Instance.new("TextButton")
	for v69, v70 in v67 do
		v_u_68[v69] = v70
	end
	if p62 then
		v_u_68.Parent = p62
	end
	local v71 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v72 = Instance.new("UICorner")
	for v73, v74 in v71 do
		v72[v73] = v74
	end
	if v_u_68 then
		v72.Parent = v_u_68
	end
	local v_u_75 = v_u_9.stroke(v_u_68, v_u_11.line, 1, 0)
	v_u_68:SetAttribute("StrokeBase", true)
	v_u_9.icon(p64, {
		["size"] = v_u_12(p66 * 0.45),
		["color"] = v_u_11.text,
		["position"] = UDim2.fromScale(0.5, 0.5),
		["anchor"] = Vector2.new(0.5, 0.5)
	}).Parent = v_u_68
	local function v76()
		-- upvalues: (copy) v_u_68, (ref) v_u_9
		v_u_68.SelectionImageObject = v_u_9.selectionImage()
	end
	pcall(v76)
	v_u_68.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_75, (ref) v_u_11
		v_u_75.Color = v_u_11.accent
	end)
	v_u_68.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_75, (ref) v_u_11
		v_u_75.Color = v_u_11.line
	end)
	return v_u_68
end
local function v_u_83(p78, p79) -- name: dimButton
	-- upvalues: (copy) v_u_9, (copy) v_u_11
	p78.BackgroundTransparency = p79 and 0.5 or 0.1
	for _, v80 in p78:GetChildren() do
		if not v80:IsA("Frame") or v80:GetAttribute("HushIcon") == nil then
			continue
		end
		local v81 = v_u_9.setIconColor
		local v82
		if p79 then
			v82 = v_u_11.muted
		else
			v82 = v_u_11.text
		end
		v81(v80, v82)
	end
end
local function v_u_148(p84, p85) -- name: buildCard
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_18, (copy) v_u_6, (copy) v_u_5, (copy) v_u_77, (copy) v_u_16, (copy) v_u_14, (copy) v_u_13, (copy) v_u_7
	local v86 = {
		["Name"] = "Card",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v_u_11.raised
	}
	local v87 = Instance.new("Frame")
	for v88, v89 in v86 do
		v87[v88] = v89
	end
	if p85 then
		v87.Parent = p85
	end
	v_u_9.stroke(v87, v_u_11.line, 1, 0)
	local v90 = {
		["Name"] = "Edge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.lineStrong,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}
	local v91 = Instance.new("Frame")
	for v92, v93 in v90 do
		v91[v92] = v93
	end
	if v87 then
		v91.Parent = v87
	end
	local v94 = {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(14, v_u_18.CARD_PAD_V),
		["Size"] = UDim2.new(1, -26, 1, -2 * v_u_18.CARD_PAD_V)
	}
	local v95 = Instance.new("Frame")
	for v96, v97 in v94 do
		v95[v96] = v97
	end
	if v87 then
		v95.Parent = v87
	end
	local v98 = {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["ScrollBarThickness"] = 2,
		["ScrollBarImageColor3"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ElasticBehavior"] = nil,
		["Size"] = nil,
		["Selectable"] = false,
		["ScrollBarImageColor3"] = v_u_11.lineStrong,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ElasticBehavior"] = Enum.ElasticBehavior.Never,
		["Size"] = UDim2.new(1, 0, 0, 100)
	}
	local v99 = Instance.new("ScrollingFrame")
	for v100, v101 in v98 do
		v99[v100] = v101
	end
	if v95 then
		v99.Parent = v95
	end
	local v102 = {
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, v_u_6.CARD_GAP)
	}
	local v103 = Instance.new("UIListLayout")
	for v104, v105 in v102 do
		v103[v104] = v105
	end
	if v99 then
		v103.Parent = v99
	end
	local v106 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = "",
		["style"] = "h3",
		["color"] = nil,
		["size"] = nil,
		["order"] = 1,
		["parent"] = v99,
		["color"] = v_u_11.text,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	local v107 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Place",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["order"] = 2,
		["parent"] = v99,
		["color"] = v_u_11.text2,
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v108 = {
		["Name"] = "Chips",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 3,
		["Size"] = UDim2.new(1, 0, 0, 22)
	}
	local v109 = Instance.new("Frame")
	for v110, v111 in v108 do
		v109[v110] = v111
	end
	if v99 then
		v109.Parent = v99
	end
	local v112 = {
		["Name"] = "Chip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.bgDeep,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 22)
	}
	local v113 = Instance.new("Frame")
	for v114, v115 in v112 do
		v113[v114] = v115
	end
	if v109 then
		v113.Parent = v109
	end
	local v116 = v_u_9.stroke(v113, v_u_11.text2, 1, 0.35)
	local v117 = {
		["PaddingLeft"] = UDim.new(0, 6),
		["PaddingRight"] = UDim.new(0, 6)
	}
	local v118 = Instance.new("UIPadding")
	for v119, v120 in v117 do
		v118[v119] = v120
	end
	if v113 then
		v118.Parent = v113
	end
	local v121 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["autoX"] = true,
		["size"] = nil,
		["parent"] = v113,
		["color"] = v_u_11.text2,
		["size"] = UDim2.fromOffset(0, 22)
	})
	local v122 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Line",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 4,
		["parent"] = v99,
		["color"] = v_u_11.accent
	})
	v122.TextTruncate = Enum.TextTruncate.None
	local v123 = {
		["Name"] = "BarBack",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 5,
		["BackgroundColor3"] = v_u_11.line,
		["Size"] = UDim2.new(1, 0, 0, 8)
	}
	local v124 = Instance.new("Frame")
	for v125, v126 in v123 do
		v124[v125] = v126
	end
	if v99 then
		v124.Parent = v99
	end
	local v127 = {
		["Name"] = "BarFill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.accent,
		["Size"] = UDim2.new(0, 0, 1, 0)
	}
	local v128 = Instance.new("Frame")
	for v129, v130 in v127 do
		v128[v129] = v130
	end
	if v124 then
		v128.Parent = v124
	end
	local v131 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Progress",
		["text"] = "",
		["style"] = "monoS",
		["color"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["order"] = 6,
		["parent"] = v99,
		["color"] = v_u_11.text2
	})
	v131.TextTruncate = Enum.TextTruncate.None
	local v132 = v_u_5.touch(44)
	local v133 = {
		["Name"] = "Buttons",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 7,
		["Size"] = UDim2.new(1, 0, 0, v132)
	}
	local v134 = Instance.new("Frame")
	for v135, v136 in v133 do
		v134[v135] = v136
	end
	if v99 then
		v134.Parent = v99
	end
	local v137 = {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, v_u_6.BUTTON_GAP),
		["VerticalAlignment"] = Enum.VerticalAlignment.Center
	}
	local v138 = Instance.new("UIListLayout")
	for v139, v140 in v137 do
		v138[v139] = v140
	end
	if v134 then
		v138.Parent = v134
	end
	local v141 = v_u_77(v134, "ZoomIn", "plus", 1, v132)
	local v142 = v_u_77(v134, "ZoomOut", "minus", 2, v132)
	local v143 = v_u_77(v134, "Home", "map", 3, v132)
	local v144 = v_u_13(v_u_16.DONE_H, (v_u_14(32, v_u_5.touch(44))))
	local v_u_145, v146 = v_u_9.button({
		["name"] = "Done",
		["text"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["text"] = v_u_7.PHONE.done,
		["size"] = UDim2.new(1, 0, 0, v144),
		["parent"] = v95
	})
	local function v147()
		-- upvalues: (copy) v_u_145, (ref) v_u_9
		v_u_145.SelectionImageObject = v_u_9.selectionImage()
	end
	pcall(v147)
	p84.card = {
		["panel"] = nil,
		["edge"] = nil,
		["inner"] = nil,
		["body"] = nil,
		["list"] = nil,
		["name"] = nil,
		["place"] = nil,
		["chip"] = nil,
		["chipLbl"] = nil,
		["chipStroke"] = nil,
		["line"] = nil,
		["barBack"] = nil,
		["barFill"] = nil,
		["prog"] = nil,
		["btnRow"] = nil,
		["zin"] = nil,
		["zout"] = nil,
		["home"] = nil,
		["done"] = nil,
		["doneApi"] = nil,
		["doneH"] = nil,
		["sig"] = "",
		["panel"] = v87,
		["edge"] = v91,
		["inner"] = v95,
		["body"] = v99,
		["list"] = v103,
		["name"] = v106,
		["place"] = v107,
		["chip"] = v113,
		["chipLbl"] = v121,
		["chipStroke"] = v116,
		["line"] = v122,
		["barBack"] = v124,
		["barFill"] = v128,
		["prog"] = v131,
		["btnRow"] = v134,
		["zin"] = v141,
		["zout"] = v142,
		["home"] = v143,
		["done"] = v_u_145,
		["doneApi"] = v146,
		["doneH"] = v144
	}
end
local function v_u_157(p149) -- name: fitCard
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_16, (copy) v_u_18, (copy) v_u_14, (copy) v_u_13, (copy) v_u_12
	local v150 = p149.card
	local v151 = p149.solved
	if v150 and v151 then
		local v152 = v_u_5.uiScale()
		local v153 = v_u_6.CARD_GAP
		local v154 = v150.list.AbsoluteContentSize.Y / v152
		if v154 <= 0 then
			v154 = v_u_6.cardNeed() - v_u_16.DONE_H - v153
		end
		local v155 = v_u_14(0, v151.cardH - 2 * v_u_18.CARD_PAD_V - v150.doneH - v153)
		local v156 = v_u_12(v_u_13(v154, v155) + 0.5)
		v150.body.Size = UDim2.new(1, 0, 0, v156)
		v150.body.ScrollingEnabled = v155 + 0.5 < v154
		v150.done.Position = UDim2.fromOffset(0, v156 + v153)
		v150.panel.Size = UDim2.fromOffset(v151.cardW, 2 * v_u_18.CARD_PAD_V + v156 + v153 + v150.doneH)
		v150.panel.Position = UDim2.fromOffset(v151.cardX, v151.cardY)
		p149.cardFit = {
			["contentH"] = v154,
			["bodyMax"] = v155,
			["bodyH"] = v156,
			["scrolls"] = v155 + 0.5 < v154
		}
	end
end
local function v_u_186(p_u_158, p159) -- name: paintCard
	-- upvalues: (copy) v_u_12, (copy) v_u_9, (copy) v_u_13, (copy) v_u_14, (copy) v_u_11, (copy) v_u_157
	local v160 = p_u_158.card
	if v160 and p159 then
		local v161 = p_u_158.mods.View.pv
		local v162 = v161.displayName(p159)
		local v163 = v161.chipText(p159)
		local v164 = p159.line or ""
		local v165 = tostring(v164)
		local v166 = p159.progressText or ""
		local v167 = tostring(v166)
		local v168 = v165 ~= "" and true or v167 ~= ""
		local v169 = table.concat
		local v170 = {}
		local v171 = p159.place
		local v172 = tostring(v171)
		local v173 = v161.stateKind(p159)
		local v174 = p159.deploy
		local v175 = tostring(v174)
		local v176 = v_u_12((p159.progress or 0) * 100)
		__set_list(v170, 1, {v162, v172, v163, v173, v175, v165, v167, (tostring(v176))})
		local v177 = v169(v170, "|")
		if v160.sig ~= v177 then
			v160.sig = v177
			v_u_9.setText(v160.name, v162)
			local v178 = v_u_9.setText
			local v179 = v160.place
			local v180 = p159.place or ""
			v178(v179, (tostring(v180)))
			v_u_9.setText(v160.chipLbl, v163)
			local v181 = v161.chipColor(p159)
			v160.chipLbl.TextColor3 = v181
			v160.chipStroke.Color = v181
			v160.line.Visible = v165 ~= ""
			v160.line.Text = v165
			local v182 = v160.barBack
			if v168 then
				local v183 = p159.progress
				v168 = type(v183) == "number"
			end
			v182.Visible = v168
			v160.barFill.Size = UDim2.new(v_u_14(0, (v_u_13(1, p159.progress or 0))), 0, 1, 0)
			v160.prog.Visible = v167 ~= ""
			v160.prog.Text = v167
			local v184 = v160.edge
			local v185
			if p159.deploy then
				v185 = v_u_11.accent
			else
				v185 = v_u_11.lineStrong
			end
			v184.BackgroundColor3 = v185
			task.defer(function()
				-- upvalues: (copy) p_u_158, (ref) v_u_157
				if p_u_158.open then
					v_u_157(p_u_158)
				end
			end)
		end
	else
		return
	end
end
function v_u_17.new(p_u_187) -- name: new
	-- upvalues: (copy) v_u_17, (copy) v_u_157, (copy) v_u_18, (copy) v_u_8, (copy) v_u_83, (copy) v_u_3, (ref) v_u_19, (copy) v_u_9, (copy) v_u_5, (copy) v_u_11, (copy) v_u_148, (copy) v_u_186, (copy) v_u_61, (copy) v_u_10, (copy) v_u_53
	local v_u_188 = {
		["alive"] = true,
		["open"] = false,
		["opening"] = false,
		["gen"] = 0,
		["conns"] = nil,
		["env"] = nil,
		["solved"] = nil,
		["measure"] = nil,
		["D"] = 0,
		["relayoutTok"] = 0,
		["mods"] = nil,
		["prevSel"] = nil,
		["conns"] = {},
		["env"] = p_u_187
	}
	local v_u_189 = {}
	local v_u_190 = p_u_187.session or {}
	local function v_u_207() -- name: guardTopBar
		-- upvalues: (copy) v_u_188
		local v191 = v_u_188.view
		local v192 = v_u_188.measure
		local v193 = v_u_188.solved
		if v191 and (v192 and v193) then
			local v194 = v193.globe
			local v195 = v194.y < v192.topInset
			local v196
			if v195 then
				v196 = v194.x + 6 < v192.topLeftW
			else
				v196 = v195
			end
			if v195 then
				v195 = v194.x < v192.topLeftW
			end
			local v197 = v191.lens:FindFirstChild("Chrome")
			if v197 then
				local v198 = v197:FindFirstChild("TitlePlate")
				if v198 then
					v198.Visible = not v196
				end
				for _, v199 in { "B11", "B12" } do
					local v200 = v197:FindFirstChild(v199)
					if not v200 then
						continue
					end
					v200.Visible = not v195
				end
			end
			local v201 = v191.lens:FindFirstChild("Rim")
			local v202 = 0
			if v201 then
				for _, v203 in v201:GetChildren() do
					if not (v203:IsA("Frame") and string.match(v203.Name, "^T%d+$")) then
						continue
					end
					local v204 = v194.x + v203.Position.X.Offset
					local v205 = v194.y + v203.Position.Y.Offset
					local v206
					if v204 + 4 > 0 and (v204 - 4 < v192.topLeftW and v205 + 4 > 0) then
						v206 = v205 - 4 < v192.topInset
					else
						v206 = false
					end
					v203.Visible = not v206
					if not v206 then
						continue
					end
					v202 = v202 + 1
				end
			end
			v_u_188.topBarGuard = {
				["title"] = v196,
				["bracket"] = v195,
				["ticks"] = v202
			}
		end
	end
	local function v_u_217(p208) -- name: apply
		-- upvalues: (ref) v_u_17, (copy) p_u_187, (copy) v_u_188, (ref) v_u_157, (copy) v_u_207
		local v209 = v_u_17.measure(p_u_187)
		local v210 = v_u_17.solve(v209)
		local v211 = v_u_188
		v_u_188.measure = v209
		v211.solved = v210
		local v212 = v_u_188.ui
		if v212 then
			v212.tbl.Size = UDim2.fromOffset(v209.W, v209.H)
			local v213 = v210.globe
			local v214 = v_u_188.view
			if v214 then
				if v210.D ~= v_u_188.D then
					v_u_188.D = v210.D
					local v215 = v214.setSize
					local v216 = v210.D
					pcall(v215, v216, "phone")
				end
				v214.root.Position = UDim2.fromOffset(v213.x, v213.y)
			end
			v_u_157(v_u_188)
			v_u_207()
			if not p208 and v_u_188.open then
				v_u_188.relayouts = (v_u_188.relayouts or 0) + 1
			end
		end
	end
	local function v_u_224() -- name: scheduleRelayout
		-- upvalues: (copy) v_u_188, (ref) v_u_18, (copy) v_u_217
		local v218 = v_u_188
		v218.relayoutTok = v218.relayoutTok + 1
		local v_u_219 = v_u_188.relayoutTok
		task.delay(v_u_18.DEBOUNCE_S, function()
			-- upvalues: (ref) v_u_188, (copy) v_u_219, (ref) v_u_217
			if v_u_188.alive and (v_u_188.open and v_u_219 == v_u_188.relayoutTok) then
				local v220 = v_u_217
				local v221, v222 = pcall(v220)
				if not v221 then
					local v223 = "table layout: " .. tostring(v222)
					warn("[globe] " .. v223)
				end
			end
		end)
	end
	local function v_u_229() -- name: paintZoomLimits
		-- upvalues: (copy) v_u_188, (ref) v_u_8, (ref) v_u_83
		local v225 = v_u_188.view
		local v226 = v_u_188.card
		if v225 and v226 then
			local v227 = v_u_8.CONST
			local v228 = v225.view.z
			v_u_83(v226.zin, v227.Z_MAX - 0.001 <= v228)
			v_u_83(v226.zout, v228 <= v227.Z_MIN + 0.001)
		end
	end
	local function v_u_233() -- name: releaseSelection
		-- upvalues: (ref) v_u_3, (copy) v_u_188
		local v230 = v_u_3.SelectedObject
		local v231 = v_u_188.ui
		if v230 and (v231 and (v231.gui and v230:IsDescendantOf(v231.gui))) then
			local v232 = v_u_188.prevSel
			if v232 and (v232.Parent and v232:IsDescendantOf(game)) then
				v_u_3.SelectedObject = v232
			else
				v_u_3.SelectedObject = nil
			end
		end
		v_u_188.prevSel = nil
	end
	function v_u_189.close(p234) -- name: close
		-- upvalues: (copy) v_u_188, (copy) v_u_233, (ref) v_u_19, (copy) p_u_187
		if v_u_188.open or v_u_188.ui then
			v_u_188.open = false
			local v235 = v_u_188
			v235.gen = v235.gen + 1
			local v236 = v_u_188
			v236.relayoutTok = v236.relayoutTok + 1
			local v237 = p234 or "close"
			for _, v_u_238 in v_u_188.conns do
				pcall(function()
					-- upvalues: (copy) v_u_238
					v_u_238:Disconnect()
				end)
			end
			table.clear(v_u_188.conns)
			local v239 = v_u_233
			pcall(v239)
			local v240 = v_u_188.view
			local v241 = v_u_188
			local v242 = v_u_188
			v_u_188.view = nil
			v241.input = nil
			v242.dots = nil
			if v240 then
				local v243 = v240.destroy
				local v244, v245 = pcall(v243)
				if not v244 then
					local v246 = "table close cleanup: " .. tostring(v245)
					warn("[globe] " .. v246)
				end
			end
			local v_u_247 = v_u_188.ui
			v_u_188.ui = nil
			v_u_188.card = nil
			if v_u_247 and v_u_247.gui then
				pcall(function()
					-- upvalues: (copy) v_u_247
					v_u_247.gui:Destroy()
				end)
			end
			if v_u_188.counted then
				v_u_188.counted = false
				v_u_19 = v_u_19 - 1
			end
			v_u_188.lastReason = v237
			if p_u_187.closed then
				local v248 = p_u_187.closed
				pcall(v248, v237)
			end
		end
	end
	local function v_u_319() -- name: build
		-- upvalues: (copy) v_u_188, (ref) v_u_17, (copy) p_u_187, (ref) v_u_9, (ref) v_u_18, (ref) v_u_5, (ref) v_u_11, (ref) v_u_148, (ref) v_u_157, (copy) v_u_189, (copy) v_u_190, (ref) v_u_8, (ref) v_u_83, (copy) v_u_207, (copy) v_u_229, (ref) v_u_186, (ref) v_u_61
		local v_u_249 = v_u_188.mods
		local v250 = v_u_17.measure(p_u_187)
		local v251 = v_u_17.solve(v250)
		local v252 = v_u_188
		v_u_188.measure = v250
		v252.solved = v251
		local v253, v254 = v_u_9.screen(v_u_18.GUI_NAME, v_u_5.layer.menu + 1, {
			["enabled"] = false
		})
		v_u_188.ui = {
			["gui"] = v253,
			["root"] = v254
		}
		local v255 = {
			["Name"] = "Plate",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Active"] = true,
			["ZIndex"] = 1,
			["BackgroundColor3"] = v_u_11.bgDeep,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v256 = Instance.new("Frame")
		for v257, v258 in v255 do
			v256[v257] = v258
		end
		if v254 then
			v256.Parent = v254
		end
		local v259 = {
			["Name"] = "Table",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Size"] = UDim2.fromOffset(v250.W, v250.H)
		}
		local v260 = Instance.new("Frame")
		for v261, v262 in v259 do
			v260[v261] = v262
		end
		if v254 then
			v260.Parent = v254
		end
		local v263 = v_u_188.ui
		local v264 = v_u_188.ui
		v263.plate = v256
		v264.tbl = v260
		v_u_148(v_u_188, v260)
		v_u_157(v_u_188)
		if v_u_17.TEST.inject == "build" then
			error("injected after the card")
		end
		local v_u_265 = not p_u_187.tier and "low" or p_u_187.tier()
		v_u_188.tier = v_u_265
		local v_u_266 = v_u_188.card
		local v274 = v_u_249.Input.new({
			["kind"] = "phone",
			["pad"] = nil,
			["source"] = nil,
			["pageVisible"] = nil,
			["windowOpen"] = nil,
			["blockRects"] = nil,
			["scrollRects"] = nil,
			["hooks"] = nil,
			["pad"] = p_u_187.pad,
			["source"] = p_u_187.source,
			["pageVisible"] = function() -- name: pageVisible
				-- upvalues: (ref) v_u_188
				return v_u_188.open
			end,
			["windowOpen"] = p_u_187.windowOpen,
			["blockRects"] = function() -- name: blockRects
				-- upvalues: (copy) v_u_266
				local v267 = {}
				local v268 = v_u_266.panel
				local v269 = v268 and (v268.Parent and v268.Visible) and {
					["x"] = v268.AbsolutePosition.X,
					["y"] = v268.AbsolutePosition.Y,
					["w"] = v268.AbsoluteSize.X,
					["h"] = v268.AbsoluteSize.Y
				} or nil
				if v269 then
					table.insert(v267, v269)
				end
				return v267
			end,
			["scrollRects"] = function() -- name: scrollRects
				-- upvalues: (copy) v_u_266
				local v270 = {}
				local v271 = v_u_266.body
				local v272 = v271 and (v271.Parent and v271.Visible) and {
					["x"] = v271.AbsolutePosition.X,
					["y"] = v271.AbsolutePosition.Y,
					["w"] = v271.AbsoluteSize.X,
					["h"] = v271.AbsoluteSize.Y
				} or nil
				if v272 then
					table.insert(v270, v272)
				end
				return v270
			end,
			["hooks"] = {
				["rail"] = v_u_266.done,
				["onBack"] = function(p273) -- name: onBack
					-- upvalues: (ref) v_u_189
					if not p273 then
						task.defer(v_u_189.close, "pad")
					end
				end
			}
		})
		v_u_188.input = v274
		local v275 = v_u_190.lat0
		local v276 = type(v275) == "number" and {
			["lat0"] = v_u_190.lat0,
			["lon0"] = v_u_190.lon0,
			["z"] = v_u_190.z
		} or nil
		local v277 = v251.globe
		local v_u_309 = v_u_249.View.new(v260, {
			["kind"] = "phone",
			["D"] = nil,
			["tier"] = nil,
			["position"] = nil,
			["pins"] = nil,
			["noCard"] = true,
			["labels"] = false,
			["pick"] = nil,
			["makeDots"] = nil,
			["justDragged"] = nil,
			["padOwns"] = nil,
			["inputKind"] = nil,
			["keyName"] = nil,
			["state"] = nil,
			["session"] = nil,
			["noIntro"] = true,
			["modal"] = nil,
			["switchOn"] = nil,
			["govTripped"] = nil,
			["onFatal"] = nil,
			["onState"] = nil,
			["frozenWhy"] = nil,
			["D"] = v251.D,
			["tier"] = v_u_265,
			["position"] = UDim2.fromOffset(v277.x, v277.y),
			["pins"] = p_u_187.hooks.pins,
			["pick"] = function(p278) -- name: pick
				-- upvalues: (ref) p_u_187
				return p_u_187.pick(p278)
			end,
			["makeDots"] = function(p279, p280) -- name: makeDots
				-- upvalues: (copy) v_u_249, (copy) v_u_265, (ref) v_u_188, (ref) p_u_187
				local v284 = v_u_249.Dots.new(p279, {
					["lensR"] = p280.lensR,
					["cx"] = p280.cx,
					["cy"] = p280.cy,
					["tier"] = v_u_265,
					["reduced"] = v_u_249.View.Motion.reduced,
					["onOff"] = function(p_u_281) -- name: onOff
						-- upvalues: (ref) v_u_188, (ref) p_u_187
						task.defer(function()
							-- upvalues: (ref) v_u_188, (ref) p_u_187, (copy) p_u_281
							if v_u_188.alive and p_u_187.onFatal then
								local v282 = p_u_187.onFatal
								local v283 = p_u_281
								pcall(v282, "perf", "table", v283)
							end
						end)
					end
				})
				v_u_188.dots = v284
				return v284
			end,
			["justDragged"] = v274.justDragged,
			["padOwns"] = v274.padOwns,
			["inputKind"] = v274.inputKind,
			["keyName"] = v274.keyName,
			["state"] = v276,
			["session"] = v_u_190,
			["modal"] = p_u_187.modal,
			["switchOn"] = p_u_187.switchOn,
			["govTripped"] = function() -- name: govTripped
				-- upvalues: (ref) v_u_188
				local v285 = v_u_188.dots
				if not (v285 and (v285.gov and v285.gov.off)) then
					return false
				end
				local v286 = v285.gov.off
				local v287 = v285.gov
				local v288, v289 = pcall(v286, v287)
				if v288 then
					v288 = v289 == true
				end
				return v288
			end,
			["onFatal"] = function(p_u_290, p_u_291) -- name: onFatal
				-- upvalues: (ref) v_u_188, (ref) p_u_187
				task.defer(function()
					-- upvalues: (ref) v_u_188, (copy) p_u_290, (copy) p_u_291, (ref) p_u_187
					if v_u_188.alive then
						local v292 = p_u_290
						local v293 = "view " .. tostring(v292)
						local v294 = p_u_291
						local v295 = "table " .. v293 .. ": " .. tostring(v294)
						warn("[globe] " .. v295)
						if p_u_187.onFatal then
							local v296 = p_u_187.onFatal
							local v297 = "table " .. v293
							pcall(v296, "error", v297, v294)
						end
					end
				end)
			end,
			["onState"] = function(p298) -- name: onState
				-- upvalues: (ref) v_u_190, (ref) v_u_188, (ref) v_u_8, (ref) v_u_83
				if type(p298) == "table" then
					local v299 = v_u_190
					local v300 = v_u_190
					local v301 = v_u_190
					local v302 = p298.lat0
					local v303 = p298.lon0
					local v304 = p298.z
					v299.lat0 = v302
					v300.lon0 = v303
					v301.z = v304
					task.defer(function()
						-- upvalues: (ref) v_u_188, (ref) v_u_8, (ref) v_u_83
						if v_u_188.open then
							local v305 = v_u_188.view
							local v306 = v_u_188.card
							if v305 then
								if not v306 then
									return
								end
								local v307 = v_u_8.CONST
								local v308 = v305.view.z
								v_u_83(v306.zin, v307.Z_MAX - 0.001 <= v308)
								v_u_83(v306.zout, v308 <= v307.Z_MIN + 0.001)
							end
						end
					end)
				end
			end,
			["frozenWhy"] = p_u_187.frozenWhy
		})
		v_u_188.view = v_u_309
		v_u_188.D = v251.D
		v_u_207()
		v_u_309.sync()
		v274.attach(v_u_309)
		for _, v310 in v_u_309.buttons do
			v310.Visible = false
		end
		v_u_188.acts = {
			["zin"] = function() -- name: zin
				-- upvalues: (copy) v_u_309, (ref) v_u_229
				v_u_309.gesture()
				v_u_309.zoomStep(1)
				task.delay(0.7, v_u_229)
			end,
			["zout"] = function() -- name: zout
				-- upvalues: (copy) v_u_309, (ref) v_u_229
				v_u_309.gesture()
				v_u_309.zoomStep(-1)
				task.delay(0.7, v_u_229)
			end,
			["home"] = function() -- name: home
				-- upvalues: (copy) v_u_309, (ref) v_u_229
				v_u_309.gesture()
				v_u_309.homeStep()
				task.delay(0.7, v_u_229)
			end,
			["done"] = function() -- name: done
				-- upvalues: (ref) v_u_189
				v_u_189.close("done")
			end
		}
		v_u_266.zin.Activated:Connect(v_u_188.acts.zin)
		v_u_266.zout.Activated:Connect(v_u_188.acts.zout)
		v_u_266.home.Activated:Connect(v_u_188.acts.home)
		v_u_266.done.Activated:Connect(v_u_188.acts.done)
		for _, v311 in {
			v_u_266.zin,
			v_u_266.zout,
			v_u_266.home,
			v_u_266.done
		} do
			v311.NextSelectionRight = v_u_309.focus
		end
		v_u_309.dotsLayer.Visible = false
		local v312 = p_u_187.mc and p_u_187.mc.cctx
		if v312 then
			v312 = p_u_187.mc.cctx.command
		end
		if v312 then
			local v313 = v_u_309.commands
			pcall(v313, v312)
			local v314 = v274.commands
			pcall(v314, v312)
		end
		v_u_186(v_u_188, (v_u_61(p_u_187)))
		local v315 = v_u_188.view
		local v316 = v_u_188.card
		if v315 then
			if not v316 then
				return
			end
			local v317 = v_u_8.CONST
			local v318 = v315.view.z
			v_u_83(v316.zin, v317.Z_MAX - 0.001 <= v318)
			v_u_83(v316.zout, v318 <= v317.Z_MIN + 0.001)
		end
	end
	local function v_u_332() -- name: startShow
		-- upvalues: (copy) v_u_188, (ref) v_u_18, (copy) v_u_190, (ref) v_u_9, (ref) v_u_3
		local v_u_320 = v_u_188.gen
		local v_u_321 = v_u_188.view
		local v322 = v_u_188.mods
		v_u_321.show({
			["noIntro"] = true
		})
		v_u_188.ui.gui.Enabled = true
		v_u_188.tShow = os.clock()
		task.spawn(function()
			-- upvalues: (ref) v_u_188, (ref) v_u_18, (copy) v_u_320, (copy) v_u_321, (ref) v_u_190
			local v323 = v_u_188.dots
			if v323 and v323.prime then
				for _ = 1, v_u_18.PRIME_FRAMES do
					local v324 = v323.prime
					local v325 = v_u_18.PRIME_BOX_MS
					pcall(v324, v325)
					task.wait()
					if v_u_188.alive and (v_u_188.gen == v_u_320 and v_u_188.open) then
						continue
					end
					return
				end
			end
			if v323 then
				v323 = v323._self
			end
			local v326 = os.clock()
			if v323 and (v323.bl and (v323.bl.phase == "A" and (v323.bl.n < 14 and (os.clock() - v_u_188.tShow < v_u_18.PHASE_A_MAX_S and os.clock() - v326 < 1)))) then
				task.wait()
				if v_u_188.alive and (v_u_188.gen == v_u_320 and v_u_188.open) then
					continue
				end
			else
				v_u_321.dotsLayer.Visible = true
				v_u_188.dotsOn = true
				local v327 = v_u_321.veilIn
				pcall(v327, nil)
				if v_u_190.introDone or v_u_190.lat0 then
					if not v_u_190.introDone then
						v_u_190.introDone = true
					end
				else
					v_u_190.introDone = true
					local v328 = v_u_321.intro
					pcall(v328)
				end
				v_u_321.wake()
			end
		end)
		local v329 = v_u_9.device
		local v330, v331 = pcall(v329)
		if v330 and (v331 == "Gamepad" and v_u_321.focus) then
			v_u_188.prevSel = v_u_3.SelectedObject
			task.defer(function()
				-- upvalues: (ref) v_u_188, (copy) v_u_321, (ref) v_u_3
				if v_u_188.open and (v_u_188.view == v_u_321 and v_u_321.focus.Selectable) then
					v_u_3.SelectedObject = v_u_321.focus
				end
			end)
		end
		return v322
	end
	function v_u_189.open() -- name: open
		-- upvalues: (copy) v_u_188, (copy) p_u_187, (ref) v_u_10, (ref) v_u_53, (copy) v_u_319, (copy) v_u_189, (ref) v_u_19, (copy) v_u_224, (ref) v_u_5, (ref) v_u_157, (copy) v_u_332
		if not v_u_188.alive then
			return false
		end
		if v_u_188.open then
			return true
		end
		if v_u_188.opening then
			return false
		end
		if p_u_187.switchOn and p_u_187.switchOn() == false then
			return false
		end
		if v_u_10 and v_u_10:GetAttribute("CrateStageOn") == true then
			return false
		end
		local v333, v334 = v_u_53()
		if not v333 then
			local v335 = "table " .. "modules" .. ": " .. tostring(v334)
			warn("[globe] " .. v335)
			if p_u_187.onFatal then
				local v336 = p_u_187.onFatal
				pcall(v336, "error", "table modules", v334)
			end
			return false
		end
		v_u_188.mods = v333
		v_u_188.opening = true
		local v337 = v_u_319
		local v339, v340 = xpcall(v337, function(p338)
			return tostring(p338) .. "\n" .. debug.traceback()
		end)
		v_u_188.opening = false
		if not v339 then
			v_u_188.open = true
			v_u_189.close("error")
			local v341 = "table " .. "build" .. ": " .. tostring(v340)
			warn("[globe] " .. v341)
			if p_u_187.onFatal then
				local v342 = p_u_187.onFatal
				pcall(v342, "error", "table build", v340)
			end
			return false
		end
		v_u_188.open = true
		local v343 = v_u_188
		v343.gen = v343.gen + 1
		v_u_188.counted = true
		v_u_19 = v_u_19 + 1
		local v344 = v_u_188.ui
		local v345 = v_u_188.conns
		local v346 = v_u_10:GetAttributeChangedSignal("CrateStageOn")
		local function v347()
			-- upvalues: (ref) v_u_10, (ref) v_u_189
			if v_u_10:GetAttribute("CrateStageOn") == true then
				v_u_189.close("crate")
			end
		end
		table.insert(v345, v346:Connect(v347))
		local v348 = v_u_188.conns
		local v349 = v_u_10:GetAttributeChangedSignal("MenuOpen")
		local function v350()
			-- upvalues: (ref) v_u_10, (ref) v_u_189
			if v_u_10:GetAttribute("MenuOpen") == false then
				v_u_189.close("menu")
			end
		end
		table.insert(v348, v349:Connect(v350))
		local v351 = v_u_188.conns
		local v352 = v344.gui:GetPropertyChangedSignal("AbsoluteSize")
		local v353 = v_u_224
		table.insert(v351, v352:Connect(v353))
		local v354 = v_u_188.conns
		local v355 = v_u_5.scaleChanged
		local v356 = v_u_224
		table.insert(v354, v355:Connect(v356))
		local v357 = v_u_188.conns
		local v358 = v344.gui.Destroying
		local function v359()
			-- upvalues: (ref) v_u_188, (ref) v_u_189
			if v_u_188.open then
				task.defer(v_u_189.close, "destroyed")
			end
		end
		table.insert(v357, v358:Connect(v359))
		local v360 = v_u_188.conns
		local v361 = v_u_188.card.list:GetPropertyChangedSignal("AbsoluteContentSize")
		local function v362()
			-- upvalues: (ref) v_u_157, (ref) v_u_188
			v_u_157(v_u_188)
		end
		table.insert(v360, v361:Connect(v362))
		v_u_332()
		return true
	end
	function v_u_189.isOpen() -- name: isOpen
		-- upvalues: (copy) v_u_188
		return v_u_188.open
	end
	function v_u_189.press(p363) -- name: press
		-- upvalues: (copy) v_u_188
		local v364 = v_u_188.acts
		if v364 then
			v364 = v_u_188.acts[p363]
		end
		if not (v364 and v_u_188.open) then
			return false
		end
		v364()
		return true
	end
	function v_u_189.sync() -- name: sync
		-- upvalues: (copy) v_u_188, (ref) v_u_186, (ref) v_u_61, (copy) p_u_187
		if v_u_188.open and v_u_188.view then
			v_u_188.view.sync()
			v_u_186(v_u_188, (v_u_61(p_u_187)))
		end
	end
	function v_u_189.relayout() -- name: relayout
		-- upvalues: (copy) v_u_188, (copy) v_u_217
		if v_u_188.open then
			v_u_217()
		end
	end
	function v_u_189.destroy() -- name: destroy
		-- upvalues: (copy) v_u_188, (copy) v_u_189
		if v_u_188.alive then
			v_u_189.close("destroy")
			v_u_188.alive = false
		end
	end
	function v_u_189.view() -- name: view
		-- upvalues: (copy) v_u_188
		return v_u_188.view
	end
	function v_u_189.input() -- name: input
		-- upvalues: (copy) v_u_188
		return v_u_188.input
	end
	function v_u_189.layout() -- name: layout
		-- upvalues: (copy) v_u_188
		return v_u_188.solved
	end
	function v_u_189.parts() -- name: parts
		-- upvalues: (copy) v_u_188
		local v365 = v_u_188.ui
		if not v365 then
			return nil
		end
		local v366 = v_u_188.card
		local v367 = {
			["gui"] = v365.gui,
			["root"] = v365.root,
			["plate"] = v365.plate,
			["tbl"] = v365.tbl
		}
		local v368
		if v366 then
			v368 = v366.panel
		else
			v368 = v366
		end
		v367.card = v368
		local v369
		if v366 then
			v369 = v366.body
		else
			v369 = v366
		end
		v367.body = v369
		local v370
		if v366 then
			v370 = v366.done
		else
			v370 = v366
		end
		v367.done = v370
		local v371
		if v366 then
			v371 = v366.zin
		else
			v371 = v366
		end
		v367.zin = v371
		local v372
		if v366 then
			v372 = v366.zout
		else
			v372 = v366
		end
		v367.zout = v372
		local v373
		if v366 then
			v373 = v366.home
		else
			v373 = v366
		end
		v367.home = v373
		local v374
		if v366 then
			v374 = v366.line
		else
			v374 = v366
		end
		v367.line = v374
		local v375
		if v366 then
			v375 = v366.prog
		else
			v375 = v366
		end
		v367.prog = v375
		local v376
		if v366 then
			v376 = v366.name
		else
			v376 = v366
		end
		v367.name = v376
		local v377
		if v366 then
			v377 = v366.place
		else
			v377 = v366
		end
		v367.place = v377
		local v378
		if v366 then
			v378 = v366.chipLbl
		else
			v378 = v366
		end
		v367.chipLbl = v378
		local v379
		if v366 then
			v379 = v366.barBack
		else
			v379 = v366
		end
		v367.barBack = v379
		if v366 then
			v366 = v366.list
		end
		v367.list = v366
		return v367
	end
	function v_u_189.stats() -- name: stats
		-- upvalues: (copy) v_u_188
		return {
			["open"] = v_u_188.open,
			["D"] = v_u_188.D,
			["tier"] = v_u_188.tier,
			["fit"] = v_u_188.cardFit,
			["relayouts"] = v_u_188.relayouts or 0,
			["solved"] = v_u_188.solved,
			["lastReason"] = v_u_188.lastReason,
			["dotsOn"] = v_u_188.dotsOn
		}
	end
	function v_u_189.state() -- name: state
		-- upvalues: (copy) v_u_188
		return v_u_188
	end
	pcall(function()
		-- upvalues: (copy) p_u_187, (copy) v_u_188, (copy) v_u_189
		if p_u_187.mc and (p_u_187.mc.cctx and p_u_187.mc.cctx.on) then
			p_u_187.mc.cctx.on("ui.rebuild", function()
				-- upvalues: (ref) v_u_188, (ref) v_u_189
				if v_u_188.alive and v_u_188.open then
					v_u_189.close("rebuild")
				end
			end)
		end
	end)
	return v_u_189
end
function v_u_17.row(p_u_380) -- name: row
	-- upvalues: (copy) v_u_18, (copy) v_u_11, (copy) v_u_9, (copy) v_u_7, (copy) v_u_17, (copy) v_u_61, (ref) v_u_19, (copy) v_u_53, (copy) v_u_13, (copy) v_u_14, (copy) v_u_2
	local v_u_381 = {
		["alive"] = true,
		["shown"] = false,
		["spun"] = false,
		["conn"] = nil,
		["placed"] = nil,
		["gen"] = 0
	}
	local v382 = {}
	local v383 = p_u_380.op
	local v_u_384 = p_u_380.art
	if typeof(v383) ~= "Instance" then
		return nil
	end
	local v385 = v_u_18.ROW_H
	local v386 = {
		["Name"] = "GlobeRow",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_11.bgDeep,
		["Size"] = UDim2.new(1, 0, 0, v385),
		["LayoutOrder"] = p_u_380.order or 6
	}
	local v_u_387 = Instance.new("Frame")
	for v388, v389 in v386 do
		v_u_387[v388] = v389
	end
	if v383 then
		v_u_387.Parent = v383
	end
	v_u_9.stroke(v_u_387, v_u_11.line, 1, 0)
	local v_u_390 = v_u_18.MINI_D
	local v391 = {
		["Name"] = "Mini",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.bgDeep:Lerp(v_u_11.info, 0.05),
		["Position"] = UDim2.fromOffset(8, (v385 - v_u_390) / 2),
		["Size"] = UDim2.fromOffset(v_u_390, v_u_390)
	}
	local v392 = Instance.new("Frame")
	for v393, v394 in v391 do
		v392[v393] = v394
	end
	if v_u_387 then
		v392.Parent = v_u_387
	end
	local v395 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v396 = Instance.new("UICorner")
	for v397, v398 in v395 do
		v396[v397] = v398
	end
	if v392 then
		v396.Parent = v392
	end
	v_u_9.stroke(v392, v_u_11.lineStrong, 1.5, 0)
	local v399 = {
		["Name"] = "Dots",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_400 = Instance.new("Frame")
	for v401, v402 in v399 do
		v_u_400[v401] = v402
	end
	if v392 then
		v_u_400.Parent = v392
	end
	v_u_400:SetAttribute("HushNoFade", true)
	local function v403()
		-- upvalues: (ref) v_u_9, (copy) v_u_400
		v_u_9.noFade[v_u_400] = true
	end
	pcall(v403)
	local v404 = {
		["Name"] = "Marker",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = 45,
		["Visible"] = false,
		["ZIndex"] = 3,
		["BackgroundColor3"] = v_u_11.accent,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(7, 7)
	}
	local v_u_405 = Instance.new("Frame")
	for v406, v407 in v404 do
		v_u_405[v406] = v407
	end
	if v392 then
		v_u_405.Parent = v392
	end
	v_u_9.stroke(v_u_405, v_u_11.bgDeep, 1, 0)
	local v408 = 8 + v_u_390 + 12
	v_u_9.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = nil,
		["style"] = "caps",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_387,
		["text"] = v_u_7.PHONE.title,
		["color"] = v_u_11.text2,
		["position"] = UDim2.fromOffset(v408, 12),
		["size"] = UDim2.new(1, -(v408 + 12), 0, 16)
	})
	local v_u_409 = v_u_9.label({
		["parent"] = nil,
		["name"] = "Place",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_387,
		["color"] = v_u_11.text,
		["position"] = UDim2.fromOffset(v408, 30),
		["size"] = UDim2.new(1, -(v408 + 12), 0, 18)
	})
	local v410 = {
		["Name"] = "Open",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.raised,
		["Position"] = UDim2.fromOffset(v408, 54),
		["Size"] = UDim2.fromOffset(104, 22)
	}
	local v411 = Instance.new("Frame")
	for v412, v413 in v410 do
		v411[v412] = v413
	end
	if v_u_387 then
		v411.Parent = v_u_387
	end
	v_u_9.stroke(v411, v_u_11.accent, 1, 0.3)
	v_u_9.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["parent"] = v411,
		["text"] = v_u_7.PHONE.open,
		["color"] = v_u_11.accent,
		["position"] = UDim2.fromOffset(8, 0),
		["size"] = UDim2.new(1, -30, 1, 0)
	})
	v_u_9.icon("chevronRight", {
		["size"] = 14,
		["color"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["color"] = v_u_11.accent,
		["position"] = UDim2.new(1, -6, 0.5, 0),
		["anchor"] = Vector2.new(1, 0.5)
	}).Parent = v411
	local v414 = {
		["Name"] = "Hit",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Selectable"] = true,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_415 = Instance.new("TextButton")
	for v416, v417 in v414 do
		v_u_415[v416] = v417
	end
	if v_u_387 then
		v_u_415.Parent = v_u_387
	end
	local function v418()
		-- upvalues: (copy) v_u_415, (ref) v_u_9
		v_u_415.SelectionImageObject = v_u_9.selectionImage()
	end
	pcall(v418)
	local v_u_419 = v_u_17.tapGesture(v_u_18.TAP_PX)
	v382.gesture = v_u_419
	local v_u_420 = 0
	local function v424(p421, p422) -- name: tapUp
		-- upvalues: (copy) v_u_419, (copy) v_u_381, (ref) v_u_420, (copy) p_u_380
		local v423 = v_u_419.finish(p421, p422)
		if v423 and v_u_381.alive then
			v_u_420 = v_u_420 + 1
			if p_u_380.open then
				task.defer(p_u_380.open)
			end
		end
		return v423
	end
	v382.tapDown = v_u_419.down
	v382.tapMove = v_u_419.move
	v382.tapUp = v424
	v_u_415.InputBegan:Connect(function(p425)
		-- upvalues: (copy) v_u_419
		if p425.UserInputType == Enum.UserInputType.Touch or p425.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_419.down(p425.Position.X, p425.Position.Y)
		end
	end)
	v_u_415.InputChanged:Connect(function(p426)
		-- upvalues: (copy) v_u_419
		if v_u_419.active and (p426.UserInputType == Enum.UserInputType.Touch or p426.UserInputType == Enum.UserInputType.MouseMovement) then
			v_u_419.move(p426.Position.X, p426.Position.Y)
		end
	end)
	v_u_415.Activated:Connect(function(p427)
		-- upvalues: (copy) v_u_419, (copy) v_u_381, (ref) v_u_420, (copy) p_u_380
		if p427 then
			p427 = p427.Position
		end
		local v428
		if p427 then
			v428 = p427.X
		else
			v428 = p427
		end
		if p427 then
			p427 = p427.Y
		end
		if v_u_419.finish(v428, p427) and v_u_381.alive then
			v_u_420 = v_u_420 + 1
			if p_u_380.open then
				task.defer(p_u_380.open)
			end
		end
	end)
	local v_u_429 = nil
	local v_u_430 = nil
	local function v_u_437() -- name: ensureDots
		-- upvalues: (ref) v_u_430, (ref) v_u_429, (ref) v_u_53, (copy) v_u_400, (copy) v_u_390
		if v_u_430 then
			return true
		end
		if not v_u_429 then
			v_u_429 = v_u_53()
		end
		if not v_u_429 then
			return false
		end
		local v431 = v_u_429.Dots.new
		local v432 = v_u_400
		local v433 = {
			["lensR"] = nil,
			["cx"] = nil,
			["cy"] = nil,
			["tier"] = "mini",
			["reduced"] = nil,
			["lensR"] = v_u_390 / 2,
			["cx"] = v_u_390 / 2,
			["cy"] = v_u_390 / 2,
			["reduced"] = v_u_429.View.Motion.reduced
		}
		local v434, v435 = pcall(v431, v432, v433)
		if v434 then
			v_u_430 = v435
			return true
		end
		local v436 = "mini globe: " .. tostring(v435)
		warn("[globe] " .. v436)
		return false
	end
	local function v_u_460() -- name: spin
		-- upvalues: (copy) v_u_437, (ref) v_u_61, (copy) p_u_380, (copy) v_u_381, (ref) v_u_429, (ref) v_u_430, (copy) v_u_405, (ref) v_u_18, (ref) v_u_13, (ref) v_u_14, (ref) v_u_19, (ref) v_u_2
		if not v_u_437() then
			return
		end
		local v438 = v_u_61({
			["hooks"] = p_u_380.hooks
		})
		local v439 = v438
		if v439 then
			if v438.hidden then
				local v440 = v438.fuzz
				if type(v440) == "table" then
					v439 = v438.fuzz
				else
					v439 = v438.geo
				end
			else
				v439 = v438.geo
			end
		end
		local v_u_441, v_u_442
		if type(v439) == "table" then
			local v443 = v439.lat
			if type(v443) == "number" then
				local v444 = v439.lon
				if type(v444) == "number" then
					v_u_441 = v439.lat
					v_u_442 = v439.lon
				else
					v_u_441 = 40.8
					v_u_442 = -85.8
				end
			else
				v_u_441 = 40.8
				v_u_442 = -85.8
			end
		else
			v_u_441 = 40.8
			v_u_442 = -85.8
		end
		local v_u_445 = 1
		v_u_381.placed = v_u_441 .. "|" .. v_u_442
		local v446 = v_u_429
		if v446 then
			v446 = v_u_429.View
		end
		local v447
		if v446 and (v446.Motion and v446.Motion.reduced) then
			local v448 = v446.Motion.reduced
			local v449
			v447, v449 = pcall(v448)
			if v447 then
				v447 = v449 == true
			end
		else
			v447 = false
		end
		if v447 then
			v_u_430.setView(v_u_441, v_u_442, v_u_445)
			v_u_430.step(0.016, 0, true)
			v_u_405.Visible = true
			v_u_381.spun = true
		else
			local v_u_450 = os.clock()
			local v_u_451 = v_u_442 - v_u_18.SPIN_FROM_DEG
			local v_u_452 = v_u_14(-30, (v_u_13(45, v_u_441 * 0.4 + 12)))
			if v_u_381.conn then
				v_u_381.conn:Disconnect()
				v_u_381.conn = nil
				v_u_19 = v_u_19 - 1
			end
			v_u_430.setMoving(true)
			v_u_19 = v_u_19 + 1
			local v_u_453 = 0
			v_u_381.conn = v_u_2.Heartbeat:Connect(function(p454)
				-- upvalues: (ref) v_u_381, (ref) v_u_19, (copy) v_u_450, (ref) v_u_18, (ref) v_u_13, (copy) v_u_452, (copy) v_u_441, (copy) v_u_451, (copy) v_u_442, (ref) v_u_430, (copy) v_u_445, (ref) v_u_405, (ref) v_u_453
				if v_u_381.alive and v_u_381.shown then
					local v455 = v_u_13(1, (os.clock() - v_u_450) / v_u_18.SPIN_S)
					local v456 = 1 - (1 - v455) ^ 3
					local v457 = v_u_452 + (v_u_441 - v_u_452) * v456
					local v458 = v_u_451 + (v_u_442 - v_u_451) * v456
					v_u_430.setView(v457, v458, v_u_445)
					local v459 = v_u_430.step(v_u_13(p454, 0.05), v455 >= 1 and 0 or (1 - v455) * 60, true)
					if v455 >= 1 then
						if not v_u_381.spun then
							v_u_381.spun = true
							v_u_430.setMoving(false)
							v_u_405.Visible = true
						end
						v_u_453 = v_u_453 + p454
						if (not v459 or v_u_453 > 1) and v_u_381.conn then
							v_u_381.conn:Disconnect()
							v_u_381.conn = nil
							v_u_19 = v_u_19 - 1
						end
					end
				elseif v_u_381.conn then
					v_u_381.conn:Disconnect()
					v_u_381.conn = nil
					v_u_19 = v_u_19 - 1
				end
			end)
		end
	end
	local function v_u_469() -- name: paintText
		-- upvalues: (ref) v_u_61, (copy) p_u_380, (ref) v_u_429, (ref) v_u_9, (copy) v_u_409
		local v461 = v_u_61({
			["hooks"] = p_u_380.hooks
		})
		if v461 then
			local v462 = v_u_429 and v_u_429.View
			if v462 then
				v462 = v_u_429.View.pv
			end
			local v463
			if v462 then
				v463 = v462.displayName(v461)
			else
				local v464 = v461.name or v461.id
				v463 = tostring(v464)
			end
			local v465 = v461.place or ""
			local v466 = tostring(v465)
			local v467 = v_u_9.setText
			local v468 = v_u_409
			if v466 ~= "" then
				v463 = v466
			end
			v467(v468, v463)
		end
	end
	function v382.show() -- name: show
		-- upvalues: (copy) v_u_381, (ref) v_u_429, (ref) v_u_53, (copy) v_u_469, (copy) v_u_460
		if v_u_381.alive then
			v_u_381.shown = true
			local v470 = v_u_381
			v470.gen = v470.gen + 1
			local v_u_471 = v_u_381.gen
			if not v_u_429 then
				v_u_429 = v_u_53()
			end
			v_u_469()
			task.delay(0.22, function()
				-- upvalues: (ref) v_u_381, (copy) v_u_471, (ref) v_u_460
				if v_u_381.alive and (v_u_381.gen == v_u_471 and v_u_381.shown) then
					if not v_u_381.spun then
						v_u_460()
					end
				end
			end)
		end
	end
	function v382.hide() -- name: hide
		-- upvalues: (copy) v_u_381, (ref) v_u_19, (ref) v_u_430
		v_u_381.shown = false
		local v472 = v_u_381
		v472.gen = v472.gen + 1
		if v_u_381.conn then
			v_u_381.conn:Disconnect()
			v_u_381.conn = nil
			v_u_19 = v_u_19 - 1
		end
		if v_u_430 then
			local v473 = v_u_430.setMoving
			pcall(v473, false)
		end
	end
	function v382.sync() -- name: sync
		-- upvalues: (copy) v_u_381, (copy) v_u_469, (ref) v_u_430, (ref) v_u_61, (copy) p_u_380
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v474, v475, v476, v477, v478, v479, v480, v481, v482, v483
		local v484 = 9
		while true do
			if v484 == 1 then
				return
			elseif v484 == 2 then
				if v475.hidden then
					v484 = 4
				else
					v484 = 5
				end
			elseif v484 == 3 then
				if type(v475) == "table" then
					v476 = v475.lat
					if type(v476) == "number" then
						v477 = v475.lon
						if type(v477) == "number" then
							v478 = v475.lat
							v479 = v475.lon
						else
							v478 = 40.8
							v479 = -85.8
						end
					else
						v478 = 40.8
						v479 = -85.8
					end
				else
					v478 = 40.8
					v479 = -85.8
				end
				v480 = 1
				v481 = v478 .. "|" .. v479
				if v481 ~= v_u_381.placed then
					v_u_381.placed = v481
					v482 = v_u_430.setView
					pcall(v482, v478, v479, v480)
					v483 = v_u_430.step
					pcall(v483, 0.016, 0, true)
				end
				v484 = 1
			elseif v484 == 4 then
				v474 = v475.fuzz
				if type(v474) == "table" then
					v484 = 6
				else
					v484 = 8
				end
			elseif v484 == 5 then
				v475 = v475.geo
				v484 = 7
			elseif v484 == 6 then
				v475 = v475.fuzz
				if type(v475) == "table" then
					v476 = v475.lat
					if type(v476) == "number" then
						v477 = v475.lon
						if type(v477) == "number" then
							v478 = v475.lat
							v479 = v475.lon
						else
							v478 = 40.8
							v479 = -85.8
						end
					else
						v478 = 40.8
						v479 = -85.8
					end
				else
					v478 = 40.8
					v479 = -85.8
				end
				v480 = 1
				v481 = v478 .. "|" .. v479
				if v481 ~= v_u_381.placed then
					v_u_381.placed = v481
					v482 = v_u_430.setView
					pcall(v482, v478, v479, v480)
					v483 = v_u_430.step
					pcall(v483, 0.016, 0, true)
				end
				v484 = 1
			elseif v484 == 7 then
				if type(v475) == "table" then
					v476 = v475.lat
					if type(v476) == "number" then
						v477 = v475.lon
						if type(v477) == "number" then
							v478 = v475.lat
							v479 = v475.lon
						else
							v478 = 40.8
							v479 = -85.8
						end
					else
						v478 = 40.8
						v479 = -85.8
					end
				else
					v478 = 40.8
					v479 = -85.8
				end
				v480 = 1
				v481 = v478 .. "|" .. v479
				if v481 ~= v_u_381.placed then
					v_u_381.placed = v481
					v482 = v_u_430.setView
					pcall(v482, v478, v479, v480)
					v483 = v_u_430.step
					pcall(v483, 0.016, 0, true)
				end
				v484 = 1
			elseif v484 == 8 then
				v475 = v475.geo
				v484 = 7
			else
				if not v_u_381.alive then
					return
				end
				v_u_469()
				if not (v_u_381.spun and v_u_430) then
					return
				end
				v475 = v_u_61({
					["hooks"] = p_u_380.hooks
				})
				if v475 then
					v484 = 2
				else
					v484 = 3
				end
			end
		end
	end
	function v382.destroy() -- name: destroy
		-- upvalues: (copy) v_u_381, (ref) v_u_19, (ref) v_u_430, (copy) v_u_387, (copy) v_u_384, (copy) p_u_380
		if v_u_381.alive then
			v_u_381.alive = false
			local v485 = v_u_381
			v485.gen = v485.gen + 1
			if v_u_381.conn then
				v_u_381.conn:Disconnect()
				v_u_381.conn = nil
				v_u_19 = v_u_19 - 1
			end
			if v_u_430 then
				local v486 = v_u_430.destroy
				pcall(v486)
				v_u_430 = nil
			end
			local function v487()
				-- upvalues: (ref) v_u_387
				v_u_387:Destroy()
			end
			pcall(v487)
			if v_u_384 and v_u_384.Parent then
				local function v488()
					-- upvalues: (ref) v_u_384, (ref) p_u_380
					v_u_384.Visible = p_u_380.artWas ~= false
				end
				pcall(v488)
			end
		end
	end
	function v382.stats() -- name: stats
		-- upvalues: (copy) v_u_381, (ref) v_u_420, (copy) v_u_419, (ref) v_u_430
		return {
			["spun"] = v_u_381.spun,
			["spinning"] = v_u_381.conn ~= nil,
			["shown"] = v_u_381.shown,
			["opened"] = v_u_420,
			["gesture"] = {
				["taps"] = v_u_419.taps,
				["drags"] = v_u_419.drags
			},
			["hasDots"] = v_u_430 ~= nil
		}
	end
	v382.frame = v_u_387
	v382.hit = v_u_415
	v382.openBtn = v411
	v382.marker = v_u_405
	if v_u_384 then
		p_u_380.artWas = v_u_384.Visible
		v_u_384.Visible = false
	end
	return v382
end
return v_u_17