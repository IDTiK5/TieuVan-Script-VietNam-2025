-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuRotationPlay

return {
	["attach"] = function(p_u_1, p_u_2, p3) -- name: attach
		-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
		local v4, v5, v6, v_u_7, v_u_8, v_u_9, v10, v11, v12, v_u_13, v_u_14, v_u_15, v_u_16, v_u_17, v_u_18, v_u_19, v20, v_u_21, v22, v_u_23, v_u_24, v25, v26, v27, v28, v29, v30, v_u_31, v_u_32, v33
		local v34 = 5
		while true do
			if v34 == 1 then
				v22 = v25.setDockH
				if type(v22) == "function" then
					v34 = 3
				else
					v34 = 2
				end
			elseif v34 == 2 then
				v_u_14.band = 0
				pcall(function()
					-- upvalues: (copy) v_u_7, (copy) v_u_21, (copy) v_u_24
					v_u_7.Parent = v_u_21.op
					v_u_7.AnchorPoint = Vector2.zero
					v_u_7.Position = UDim2.new(0, 0, 0, 0)
					v_u_7.Size = UDim2.new(1, 0, 0, v_u_24.height())
					v_u_7.LayoutOrder = 2
				end)
				v34 = 4
			elseif v34 == 3 then
				v_u_14.band = v_u_24.band()
				v_u_23 = v25.setDockH
				function v25.setDockH(p35)
					-- upvalues: (copy) v_u_24, (copy) v_u_23, (copy) v_u_14
					v_u_24.place(p35)
					return v_u_23((tonumber(p35) or 0) + v_u_14.band)
				end
				v26 = v_u_21.dep
				v27 = type(v26) ~= "function" and 104 or v_u_21.dep()
				v28 = v25.setDockH
				v29, v30 = pcall(v28, v27)
				if not v29 then
					warn("[MenuRotationPlay] dock height failed: " .. tostring(v30))
				end
				v34 = 4
			elseif v34 == 4 then
				function v_u_14.sync() -- name: sync
					-- upvalues: (copy) v_u_8, (copy) p_u_1, (copy) v_u_21, (ref) v_u_15, (copy) p_u_2
					local v_u_36 = v_u_8.rotationOf(p_u_1)
					if v_u_36 ~= nil then
						local v37 = v_u_21.sel
						if type(v37) == "table" then
							local function v38()
								-- upvalues: (ref) v_u_15, (copy) v_u_36
								return v_u_15.get(v_u_36.map)
							end
							local v39, v40 = pcall(v38)
							if v39 and v40 ~= nil then
								v_u_21.sel.mapId = v_u_36.map
								p_u_2.pendingMap = nil
							end
							return
						end
					end
				end
				v_u_31 = false
				v_u_16 = function() -- name: inert
					-- upvalues: (copy) v_u_21, (ref) v_u_31, (copy) v_u_14, (copy) v_u_13, (copy) v_u_8
					local v41 = v_u_21.op
					if v41 ~= nil then
						local v_u_42 = v41:FindFirstChild("MapSelect")
						if v_u_42 then
							if not v_u_31 then
								v_u_31 = true
								pcall(function()
									-- upvalues: (copy) v_u_42
									v_u_42.Active = false
									v_u_42.Selectable = false
									v_u_42.Interactable = false
								end)
							end
							local v43 = v_u_42:FindFirstChild("Chevron")
							if v43 then
								v43.Visible = false
							end
							local v44 = v_u_42:FindFirstChild("MapName")
							if v44 then
								v44.Size = UDim2.new(1, -24, 1, 0)
							end
						end
						local v45 = v41:FindFirstChild("Count", true)
						if v45 and v_u_14.countText ~= v45.Text then
							v_u_13.setText(v45, v_u_8.rotatesLine())
							v_u_14.countText = v45.Text
						end
					end
				end
				function v_u_14.paint() -- name: paint
					-- upvalues: (copy) v_u_24, (copy) v_u_8, (copy) p_u_1, (copy) v_u_16
					v_u_24.set(v_u_8.rotationOf(p_u_1))
					v_u_24.paint()
					v_u_16()
				end
				v_u_17 = p_u_2.paint
				function p_u_2.paint(...) -- name: paint
					-- upvalues: (copy) v_u_17, (copy) v_u_14
					if v_u_17 then
						v_u_17(...)
					end
					local v46 = v_u_14.paint
					pcall(v46)
				end
				v_u_18 = p_u_2.choose
				function p_u_2.choose(p47, p48) -- name: choose
					-- upvalues: (copy) v_u_18
					if p47 ~= "mapId" then
						if v_u_18 then
							return v_u_18(p47, p48)
						end
					end
				end
				function p_u_2.viewMap(_) -- name: viewMap
					return false
				end
				function p_u_2.openList(_) -- name: openList end
				v_u_19 = p_u_2.destroy
				function p_u_2.destroy(...) -- name: destroy
					-- upvalues: (copy) v_u_24, (copy) v_u_19
					local v49 = v_u_24.destroy
					pcall(v49)
					if v_u_19 then
						return v_u_19(...)
					end
				end
				function v_u_14.destroy() -- name: destroy
					-- upvalues: (copy) v_u_24
					local v50 = v_u_24.destroy
					pcall(v50)
				end
				p_u_2.rotation = v_u_14
				v20 = p_u_2.paint
				pcall(v20)
				return v_u_14
			else
				v_u_21 = p3 or {}
				v_u_32 = "MenuRotationLayout"
				v33, v_u_8 = pcall(function()
					-- upvalues: (copy) p_u_1, (copy) v_u_32
					return p_u_1.cctx.lib[v_u_32]
				end)
				if not v33 or type(v_u_8) ~= "table" then
					v_u_8 = nil
				end
				v_u_9 = "MenuRotationCard"
				v10, v11 = pcall(function()
					-- upvalues: (copy) p_u_1, (copy) v_u_9
					return p_u_1.cctx.lib[v_u_9]
				end)
				if not v10 or type(v11) ~= "table" then
					v11 = nil
				end
				if v_u_8 == nil or (v11 == nil or v_u_21.col == nil) then
					return nil
				end
				v12 = v_u_21.rule or function(p51)
					-- upvalues: (copy) p_u_1
					return p_u_1.cctx.shared.GameMode.rule(p51)
				end
				if v_u_8.enabled(v12) ~= true then
					return nil
				end
				v_u_13 = p_u_1.ui
				v_u_14 = {}
				v_u_15 = nil
				v4 = function()
					-- upvalues: (ref) v_u_15, (copy) p_u_1
					v_u_15 = p_u_1.cctx.shared.Maps
				end
				pcall(v4)
				v5 = function(p52, _) -- name: nameOf
					-- upvalues: (ref) v_u_15, (copy) p_u_2
					if v_u_15 ~= nil then
						local v53 = p_u_2.displayName
						if type(v53) == "function" then
							local v54 = v_u_15.get
							local v55, v56 = pcall(v54, p52)
							if v55 and v56 ~= nil then
								local v57 = p_u_2.displayName
								local v58, v59 = pcall(v57, v56)
								if v58 and (type(v59) == "string" and v59 ~= "") then
									return v59
								else
									return nil
								end
							else
								return nil
							end
						end
					end
					return nil
				end
				v6 = v_u_21.compact == true
				v_u_7, v_u_24 = v11.build(p_u_1, v_u_21.col, {
					["w"] = v_u_21.w,
					["compact"] = v6,
					["nameOf"] = v5,
					["now"] = v_u_21.now
				})
				v_u_14.card = v_u_24
				v_u_14.frame = v_u_7
				v25 = p_u_2.sheet
				if type(v25) == "table" then
					v34 = 1
				else
					v34 = 2
				end
			end
		end
	end
}