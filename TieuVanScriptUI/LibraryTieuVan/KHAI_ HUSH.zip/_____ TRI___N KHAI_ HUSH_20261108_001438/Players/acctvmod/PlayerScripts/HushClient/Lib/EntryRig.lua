-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / EntryRig

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local _ = v_u_1.LocalPlayer
local v_u_4 = Vector3.new
local function v_u_8(p5, p6) -- name: crouch
	local v7 = {
		["drop"] = p5 * 1.1,
		["fk"] = {
			["Root"] = { p5 * -14 * (p6 or 1), 0, 0 },
			["Waist"] = { p5 * -6, 0, 0 },
			["Neck"] = { p5 * 10, 0, 0 },
			["LeftHip"] = { p5 * 85, 0, p5 * -5 },
			["RightHip"] = { p5 * 85, 0, p5 * 5 },
			["LeftKnee"] = { p5 * -100, 0, 0 },
			["RightKnee"] = { p5 * -100, 0, 0 },
			["LeftAnkle"] = { p5 * 10, 0, 0 },
			["RightAnkle"] = { p5 * 10, 0, 0 },
			["LeftShoulder"] = { p5 * 24 + 4, 0, -4 - p5 * 6 },
			["RightShoulder"] = { p5 * 24 + 4, 0, p5 * 6 + 4 },
			["LeftElbow"] = { p5 * 35 + 10, 0, 0 },
			["RightElbow"] = { p5 * 35 + 10, 0, 0 }
		}
	}
	return v7
end
local function v_u_13(p9) -- name: rappel
	local v10 = p9 * 3.141592653589793 * 7
	local v11 = math.sin(v10)
	local v12 = {
		["drop"] = 0.35,
		["fk"] = nil,
		["fk"] = {
			["Root"] = { 12, 0, 0 },
			["Waist"] = { 4, 0, 0 },
			["Neck"] = { -8, 0, 0 },
			["LeftHip"] = { v11 * 9 + 40, 0, -4 },
			["RightHip"] = { 40 - v11 * 9, 0, 4 },
			["LeftKnee"] = { -55 - v11 * 10, 0, 0 },
			["RightKnee"] = { v11 * 10 + -55, 0, 0 },
			["LeftAnkle"] = { 14, 0, 0 },
			["RightAnkle"] = { 14, 0, 0 },
			["LeftShoulder"] = { 152, 0, 40 },
			["RightShoulder"] = { 152, 0, -40 },
			["LeftElbow"] = { 28, 0, 0 },
			["RightElbow"] = { 28, 0, 0 }
		}
	}
	return v12
end
local function v_u_19(p14) -- name: jump
	-- upvalues: (copy) v_u_8
	local v15 = 3.141592653589793 * math.clamp(p14, 0, 1)
	local v16 = math.sin(v15)
	local v17 = v_u_8((1 - v16) * 0.55, 1)
	local v18 = v17.fk
	v18.LeftHip = { v16 * 40 + 45, 0, -6 }
	v18.RightHip = { v16 * 40 + 20, 0, 6 }
	v18.LeftKnee = { -60 - v16 * 45, 0, 0 }
	v18.RightKnee = { -50 - v16 * 45, 0, 0 }
	v18.LeftShoulder = { v16 * 60 + 20, 0, -22 }
	v18.RightShoulder = { v16 * 60 + 20, 0, 22 }
	v18.LeftElbow = { 35, 0, 0 }
	v18.RightElbow = { 35, 0, 0 }
	v18.Root = { v16 * -10, 0, 0 }
	v17.drop = v16 * 0.3
	return v17
end
v_u_3.POSES = {
	"idle",
	"rappel",
	"crouch_land",
	"bed_crouch",
	"jump"
}
function v_u_3.specFor(p20, p21) -- name: specFor
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_19
	local v22 = math.clamp(p21, 0, 1)
	local v23
	if p20 == "rappel" then
		v23 = v_u_13(v22)
	elseif p20 == "crouch_land" then
		v23 = v_u_8(v22, 1)
	elseif p20 == "bed_crouch" then
		v23 = v_u_8(v22 * 0.35 + 0.45, 0.8)
	else
		if p20 ~= "jump" then
			return "idle"
		end
		v23 = v_u_19(v22)
	end
	return {
		["base"] = "idle",
		["fk"] = nil,
		["drop"] = nil,
		["fk"] = v23.fk,
		["drop"] = v23.drop
	}
end
local v_u_24 = nil
local v_u_25 = nil
function v_u_3.groundAt(p26, p27, p28, p29, p30) -- name: groundAt
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (copy) v_u_1, (copy) v_u_4
	if not v_u_24 then
		local v31 = RaycastParams.new()
		v31.FilterType = Enum.RaycastFilterType.Exclude
		v31.RespectCanCollide = true
		v_u_24 = v31
	end
	local v32 = v_u_24
	local v33 = {}
	if v_u_25 and v_u_25.Parent then
		local v34 = v_u_25
		table.insert(v33, v34)
	end
	for _, v35 in v_u_1:GetPlayers() do
		if not v35.Character then
			continue
		end
		local v36 = v35.Character
		table.insert(v33, v36)
	end
	local v37 = workspace:FindFirstChild("HushLocal")
	if v37 then
		table.insert(v33, v37)
	end
	v32.FilterDescendantsInstances = v33
	local v38 = p29 or 4
	local v39 = workspace:Raycast(v_u_4(p26, p27 + v38, p28), v_u_4(0, -(v38 + (p30 or 10)), 0), v32)
	if v39 then
		return v39.Position.Y
	else
		return nil
	end
end
local function v_u_47(p40) -- name: cleanClone
	for _, v41 in p40:GetDescendants() do
		if v41:IsA("LuaSourceContainer") or (v41:IsA("Animator") or (v41:IsA("Sound") or (v41:IsA("ForceField") or (v41:IsA("BillboardGui") or v41:IsA("Highlight"))))) then
			v41:Destroy()
		else
			if not (v41:IsA("ValueBase") or (v41:IsA("NoCollisionConstraint") or v41:IsA("HumanoidDescription"))) then
				continue
			end
			v41:Destroy()
		end
	end
	for _, v42 in p40:GetDescendants() do
		for v43 in v42:GetAttributes() do
			if string.sub(v43, 1, 3) == "RBX" then
				continue
			end
			v42:SetAttribute(v43, nil)
		end
		for _, v44 in v42:GetTags() do
			v42:RemoveTag(v44)
		end
	end
	for v45 in p40:GetAttributes() do
		if string.sub(v45, 1, 3) == "RBX" then
			continue
		end
		p40:SetAttribute(v45, nil)
	end
	for _, v46 in p40:GetTags() do
		p40:RemoveTag(v46)
	end
end
local function v_u_62(p_u_48, p_u_49, _) -- name: templateFor
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v_u_50 = v_u_1:GetPlayerByUserId(p_u_49)
	if v_u_50 then
		v_u_50 = v_u_50.Character
	end
	if v_u_50 and (v_u_50:GetAttribute("LookCode") == "blockrig" and (v_u_50:FindFirstChild("HumanoidRootPart") and v_u_50:FindFirstChild("UpperTorso"))) then
		local v52, v53 = pcall(function()
			-- upvalues: (copy) p_u_48, (copy) p_u_49
			local v51 = p_u_48.shared
			return v51.BlockRig.survivor(v51.BlockRigSpec.variantFor(p_u_49))
		end)
		if v52 and (typeof(v53) == "Instance" and v53:IsA("Model")) then
			return v53
		end
	end
	local v_u_54 = v_u_2:FindFirstChild("HushAvatars")
	if v_u_54 then
		v_u_54 = v_u_54:FindFirstChild((tostring(p_u_49)))
	end
	if v_u_54 and v_u_54:IsA("Model") then
		local v55, v56 = pcall(function()
			-- upvalues: (copy) p_u_48, (copy) v_u_54
			return p_u_48.shared.AvatarTemplate.ready(v_u_54)
		end)
		if not v55 or v56 == true then
			return v_u_54:Clone()
		end
	end
	if v_u_50 and (v_u_50:FindFirstChild("HumanoidRootPart") and v_u_50:FindFirstChild("UpperTorso")) then
		local v57, v58 = pcall(function()
			-- upvalues: (copy) v_u_50
			return v_u_50:Clone()
		end)
		if v57 and v58 then
			return v58
		end
	end
	local v60, v61 = pcall(function()
		-- upvalues: (copy) p_u_48, (copy) p_u_49
		local v59 = p_u_48.shared
		return v59.BlockRig.survivor(v59.BlockRigSpec.variantFor(p_u_49))
	end)
	if v60 and (typeof(v61) == "Instance" and v61:IsA("Model")) then
		return v61
	else
		return nil
	end
end
function v_u_3.new(p63, p64, p65, p66) -- name: new
	-- upvalues: (ref) v_u_25, (copy) v_u_62, (copy) v_u_47, (copy) v_u_3
	local v67 = p65.m[p66]
	if not v67 then
		return nil
	end
	v_u_25 = p64
	local v68 = v_u_62(p63, v67.u, p66)
	if not v68 then
		return nil
	end
	v68.Name = "Puppet_" .. p66
	v_u_47(v68)
	local v69 = v68:FindFirstChild("HumanoidRootPart")
	if not v69 then
		v68:Destroy()
		return nil
	end
	for _, v_u_70 in v68:GetDescendants() do
		if v_u_70:IsA("Humanoid") then
			v_u_70.AutomaticScalingEnabled = false
			v_u_70.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			v_u_70.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
			v_u_70.BreakJointsOnDeath = false
			v_u_70.RequiresNeck = false
			pcall(function()
				-- upvalues: (copy) v_u_70
				v_u_70.EvaluateStateMachine = false
			end)
		else
			if not v_u_70:IsA("BasePart") then
				continue
			end
			v_u_70.CanCollide = false
			v_u_70.CanQuery = false
			v_u_70.CanTouch = false
			v_u_70.Anchored = v_u_70 == v69
			v_u_70.LocalTransparencyModifier = 0
		end
	end
	v69.Transparency = 1
	local v71 = p63.lib.AnimRig
	local v72 = p63.lib.FilmPhotoPoses
	local v73 = v71.new(v68)
	if not v73 then
		v68:Destroy()
		return nil
	end
	local v74 = v68:FindFirstChildOfClass("Humanoid")
	local v75 = not v74 and 2 or v74.HipHeight
	local v76 = ((v73.bone.LeftHip or 1.35) + (v73.bone.LeftKnee or 1.25)) / 2.6
	local v77 = {
		["model"] = nil,
		["rig"] = nil,
		["root"] = nil,
		["lift"] = nil,
		["scale"] = nil,
		["poses"] = nil,
		["cctx"] = nil,
		["pose"] = "",
		["k"] = -1,
		["shown"] = nil,
		["attached"] = false,
		["place"] = nil,
		["baseGround"] = nil,
		["parts"] = nil,
		["model"] = v68,
		["rig"] = v73,
		["root"] = v69,
		["lift"] = v75 + v69.Size.Y / 2,
		["scale"] = v76,
		["poses"] = v72,
		["cctx"] = p63,
		["place"] = {
			["x"] = v67.x,
			["y"] = v67.y,
			["z"] = v67.z
		},
		["parts"] = {}
	}
	for _, v78 in v68:GetDescendants() do
		if not (v78:IsA("BasePart") or v78:IsA("Decal")) then
			continue
		end
		local v79 = v77.parts
		table.insert(v79, v78)
	end
	v68.Parent = p64
	v77.baseGround = v_u_3.groundAt(v67.x, v67.y, v67.z, 3, 8)
	return v77
end
function v_u_3.apply(p80, p81) -- name: apply
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	if not (p80 and p80.model.Parent) then
		return
	end
	local v82 = p81.vis ~= false
	if p80.shown ~= v82 then
		p80.shown = v82
		local v83 = v82 and 0 or 1
		for _, v84 in p80.parts do
			if not v84.Parent then
				continue
			end
			v84.LocalTransparencyModifier = v83
		end
		if p80.root then
			p80.root.Transparency = 1
		end
	end
	local v85 = p81.y
	if p81.pose == "walk" and p80.baseGround then
		local v86 = p81.x - p80.place.x
		local v87 = p81.z - p80.place.z
		local v88 = v86 * v86 + v87 * v87
		local v89 = math.sqrt(v88)
		local v90 = v_u_3.groundAt(p81.x, p81.y, p81.z, 3, 8)
		if v90 then
			local v91 = v90 - p80.baseGround
			local v92 = math.clamp(v91, -2.5, 2.5)
			local v93 = v89 / 6
			v85 = v85 + v92 * math.clamp(v93, 0, 1)
		end
	end
	local v94 = CFrame.new(p81.x, v85 + p80.lift, p81.z) * CFrame.Angles(0, p81.yaw, 0)
	if p81.pose == "rappel" and p81.hx then
		local v95 = CFrame.Angles(0, p81.yaw, 0)
		local v96 = p80.grip or Vector3.new(0, 2, 0.56)
		local v97 = v_u_4(p81.hx, p81.hy, p81.hz) - v95:VectorToWorldSpace(v96)
		local v98 = v_u_4(p81.x, v85 + p80.lift, p81.z)
		local v99 = ((p81.k or 0) - 0.82) / 0.18
		local v100 = math.clamp(v99, 0, 1)
		v94 = CFrame.new(v97:Lerp(v98, v100 * v100 * (3 - v100 * 2))) * v95
	end
	p80.model:PivotTo(v94 * p80.root.CFrame:Inverse() * p80.model:GetPivot())
	if p81.pose == "walk" then
		p80.model:SetAttribute("AnimVelocity", (v_u_4(p81.vx, 0, p81.vz)))
		if not p80.attached then
			local v101 = p80.cctx and p80.cctx.controllers
			if v101 then
				v101 = p80.cctx.controllers.CharacterAnim
			end
			if not v101 or v101._broken then
				v101 = nil
			end
			if v101 and v101.attach(p80.model) then
				p80.attached = true
				return
			end
			p80.attached = false
			if p80.pose ~= "idle" then
				p80.pose = "idle"
				local v102 = p80.poses.actorPose
				local v103 = p80.rig
				local v104 = p80.scale
				pcall(v102, v103, "idle", v104)
			end
		end
		return
	end
	if p80.attached then
		local v105 = p80.cctx and p80.cctx.controllers
		if v105 then
			v105 = p80.cctx.controllers.CharacterAnim
		end
		if not v105 or v105._broken then
			v105 = nil
		end
		if v105 then
			local v106 = v105.detach
			local v107 = p80.model
			pcall(v106, v107)
		end
		p80.attached = false
		p80.pose = ""
	end
	local v108 = p81.k or 0
	local v109, v110, v111, v112, v113, v114, v115, v116, v117, v118, v119, v120
	if p81.pose == p80.pose then
		local v121 = v108 - p80.k
		if math.abs(v121) > 0.015 then
			p80.pose = p81.pose
			p80.k = v108
			v109 = p80.poses.actorPose
			v110 = p80.rig
			v111 = v_u_3.specFor(p81.pose, v108)
			v112 = p80.scale
			if not pcall(v109, v110, v111, v112) then
				v113 = p80.poses.actorPose
				v114 = p80.rig
				v115 = p80.scale
				pcall(v113, v114, "idle", v115)
			end
			p80.poseAt = os.clock()
			if p81.pose == "rappel" and (p80.grip == nil and (p80.poseAt and os.clock() - p80.poseAt > 0.04)) then
				v116 = p80.model:FindFirstChild("LeftHand")
				v117 = p80.model:FindFirstChild("RightHand")
				if v116 and (v117 and (v116:IsA("BasePart") and v117:IsA("BasePart"))) then
					v118 = p80.root.CFrame:PointToObjectSpace((v116.Position + v117.Position) / 2)
					v119 = v118.X
					if math.abs(v119) < 1 and (v118.Y > 0.8 and v118.Y < 5) then
						v120 = v118.Z
						if math.abs(v120) < 2 then
							p80.grip = v118
							return
						end
					end
					p80.grip = Vector3.new(0, 2, 0.56)
				end
			end
		elseif p81.pose == "rappel" and (p80.grip == nil and (p80.poseAt and os.clock() - p80.poseAt > 0.04)) then
			v116 = p80.model:FindFirstChild("LeftHand")
			v117 = p80.model:FindFirstChild("RightHand")
			if v116 and (v117 and (v116:IsA("BasePart") and v117:IsA("BasePart"))) then
				v118 = p80.root.CFrame:PointToObjectSpace((v116.Position + v117.Position) / 2)
				v119 = v118.X
				if math.abs(v119) < 1 and (v118.Y > 0.8 and v118.Y < 5) then
					v120 = v118.Z
					if math.abs(v120) < 2 then
						p80.grip = v118
						return
					end
				end
				p80.grip = Vector3.new(0, 2, 0.56)
			end
		end
	else
		p80.pose = p81.pose
		p80.k = v108
		v109 = p80.poses.actorPose
		v110 = p80.rig
		v111 = v_u_3.specFor(p81.pose, v108)
		v112 = p80.scale
		if not pcall(v109, v110, v111, v112) then
			v113 = p80.poses.actorPose
			v114 = p80.rig
			v115 = p80.scale
			pcall(v113, v114, "idle", v115)
		end
		p80.poseAt = os.clock()
		if p81.pose == "rappel" and (p80.grip == nil and (p80.poseAt and os.clock() - p80.poseAt > 0.04)) then
			v116 = p80.model:FindFirstChild("LeftHand")
			v117 = p80.model:FindFirstChild("RightHand")
			if v116 and (v117 and (v116:IsA("BasePart") and v117:IsA("BasePart"))) then
				v118 = p80.root.CFrame:PointToObjectSpace((v116.Position + v117.Position) / 2)
				v119 = v118.X
				if math.abs(v119) < 1 and (v118.Y > 0.8 and v118.Y < 5) then
					v120 = v118.Z
					if math.abs(v120) < 2 then
						p80.grip = v118
						return
					end
				end
				p80.grip = Vector3.new(0, 2, 0.56)
			end
		end
		return
	end
end
function v_u_3.destroy(p_u_122) -- name: destroy
	if p_u_122 then
		if p_u_122.attached then
			local v123 = p_u_122.cctx and p_u_122.cctx.controllers
			if v123 then
				v123 = p_u_122.cctx.controllers.CharacterAnim
			end
			if not v123 or v123._broken then
				v123 = nil
			end
			if v123 then
				local v124 = v123.detach
				local v125 = p_u_122.model
				pcall(v124, v125)
			end
			p_u_122.attached = false
		end
		pcall(function()
			-- upvalues: (copy) p_u_122
			p_u_122.model:Destroy()
		end)
		p_u_122.model = nil
	end
end
return v_u_3