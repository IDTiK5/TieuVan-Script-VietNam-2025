-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIPredict

local v1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("Items"))
local v_u_5 = require(v3:WaitForChild("Grid"))
local v_u_6 = require(script.Parent:WaitForChild("InvUISlotHint"))
local v_u_7 = {}
local v_u_8 = v1.LocalPlayer
v_u_7.TIMEOUT = 3.5
v_u_7.stats = {
	["sent"] = 0,
	["predicted"] = 0,
	["acked"] = 0,
	["refused"] = 0,
	["expired"] = 0,
	["replayed"] = 0,
	["rtt"] = 0
}
local function v_u_19() -- name: publish
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v9 = v_u_7.stats
	local v10 = v_u_8
	local v11 = string.format
	local v12 = v9.sent
	local v13 = v9.predicted
	local v14 = v9.acked
	local v15 = v9.refused
	local v16 = v9.expired
	local v17 = v9.replayed
	local v18 = v9.rtt * 1000 + 0.5
	v10:SetAttribute("InvPred", v11("sent=%d predicted=%d acked=%d refused=%d expired=%d replayed=%d rttMs=%d pendRaid=%d pendMenu=%d", v12, v13, v14, v15, v16, v17, math.floor(v18), #v_u_7._pend.raid, #v_u_7._pend.menu))
end
local v_u_20 = {
	["raid"] = {},
	["menu"] = {}
}
v_u_7._pend = v_u_20
local v_u_21 = 0
local v_u_22 = {
	["raid"] = {
		"pockets",
		"vest",
		"bag",
		"secure"
	},
	["menu"] = {
		"lo_pockets",
		"lo_vest",
		"lo_bag",
		"lo_secure"
	}
}
local v_u_23 = {
	["raid"] = { "pockets", "vest", "bag" },
	["menu"] = { "lo_pockets", "lo_vest", "lo_bag" }
}
local v_u_24 = {
	["secure"] = true,
	["lo_secure"] = true
}
local v_u_25 = {
	"primary",
	"secondary",
	"melee",
	"helmet",
	"armor",
	"bag",
	"secure",
	"boots",
	"legs",
	"ears"
}
local function v_u_38(p26, p27) -- name: locate
	-- upvalues: (copy) v_u_25
	if type(p27) ~= "string" then
		return nil
	end
	local v28
	if type(p26) == "table" then
		local v29 = p26.kit
		if type(v29) == "table" then
			v28 = p26.kit or nil
		else
			v28 = nil
		end
	else
		v28 = nil
	end
	if v28 then
		for _, v30 in v_u_25 do
			local v31 = v28.slots
			if v31 then
				v31 = v28.slots[v30]
			end
			if v31 == nil then
				v31 = v28[v30]
			end
			if type(v31) ~= "table" then
				v31 = nil
			end
			if not v31 or v31.uid ~= p27 then
				continue
			end
			return {
				["kind"] = "slot",
				["slot"] = nil,
				["item"] = nil,
				["slot"] = v30,
				["item"] = v31
			}
		end
	end
	local v32
	if type(p26) == "table" then
		local v33 = p26.containers
		v32 = type(v33) == "table" and (p26.containers or {}) or {}
	else
		v32 = {}
	end
	for v34, v35 in v32 do
		if type(v35) ~= "table" then
			continue
		end
		local v36 = v35.items
		if type(v36) ~= "table" then
			continue
		end
		for _, v37 in v35.items do
			if type(v37) ~= "table" or v37.uid ~= p27 then
				continue
			end
			return {
				["kind"] = "grid",
				["container"] = nil,
				["c"] = nil,
				["item"] = nil,
				["container"] = v34,
				["c"] = v35,
				["item"] = v37
			}
		end
	end
	return nil
end
local function v_u_46(p39, p40, p41) -- name: canPut
	-- upvalues: (copy) v_u_4, (copy) v_u_24
	local v42 = v_u_4.get(p39.id)
	if not v42 or v42.category == "secure" then
		return false
	end
	local v43 = p39.items
	if type(v43) == "table" and p41.items == p39.items then
		return false
	end
	if not p41.world or p41.sub then
		local v44
		if type(p39) == "table" then
			local v45 = p39.items
			if type(v45) == "table" then
				v44 = #p39.items > 0
			else
				v44 = false
			end
		else
			v44 = false
		end
		if v44 then
			return false
		end
		if v_u_24[p40] and v42.grid then
			return false
		end
	end
	return true
end
local function v_u_60(p47, p48, p49, p50, p51) -- name: phBlocks
	-- upvalues: (copy) v_u_5
	local v52 = p47.ph
	if type(v52) ~= "table" or #v52 == 0 then
		return false
	end
	local v53, v54 = v_u_5.size({
		["id"] = nil,
		["r"] = nil,
		["uid"] = "",
		["x"] = 0,
		["y"] = 0,
		["n"] = 1,
		["id"] = p48.id,
		["r"] = p51 == true
	})
	for _, v55 in v52 do
		if type(v55) ~= "table" or v55.uid == p48.uid then
			continue
		end
		local v56 = v55.x
		if type(v56) ~= "number" then
			continue
		end
		local v57 = v55.y
		if type(v57) ~= "number" then
			continue
		end
		local v58 = v55.w
		if type(v58) ~= "number" then
			continue
		end
		local v59 = v55.h
		if type(v59) ~= "number" or (p49 >= v55.x + v55.w or (v55.x >= p49 + v53 or (p50 >= v55.y + v55.h or v55.y >= p50 + v54))) then
			continue
		end
		return true
	end
	return false
end
local function v_u_64(p61, p62) -- name: mergeInto
	-- upvalues: (copy) v_u_5
	if v_u_5.stackMax(p62) <= 1 then
		return false
	end
	for _, v63 in p61.items do
		if not v_u_5.canStack(p62, v63) then
			continue
		end
		v_u_5.merge(p62, v63)
		if (p62.n or 0) > 0 then
			continue
		end
		return true
	end
	return false
end
local function v_u_80(p65, p66, p67, p68) -- name: autoStore
	-- upvalues: (copy) v_u_22, (copy) v_u_46, (copy) v_u_64, (copy) v_u_23, (copy) v_u_5
	local v69
	if type(p65) == "table" then
		local v70 = p65.containers
		v69 = type(v70) == "table" and (p65.containers or {}) or {}
	else
		v69 = {}
	end
	for _, v71 in v_u_22[p66] do
		local v72 = v69[v71]
		if not v72 or (v72 == p68 or not (v_u_46(p67, v71, v72) and v_u_64(v72, p67))) then
			continue
		end
		return "merged"
	end
	for _, v73 in v_u_23[p66] do
		local v74 = v69[v73]
		if not v74 or (v74 == p68 or not v_u_46(p67, v73, v74)) then
			continue
		end
		local v75, v76, v77 = v_u_5.findSpot(v74, p67)
		if v75 == nil then
			continue
		end
		local v78 = v77 == true
		p67.x = v75
		p67.y = v76
		p67.r = v78
		local v79 = v74.items
		table.insert(v79, p67)
		return "placed"
	end
	return nil
end
local function v_u_92(p81) -- name: quickTarget
	local v82
	if type(p81) == "table" then
		local v83 = p81.containers
		v82 = type(v83) == "table" and (p81.containers or {}) or {}
	else
		v82 = {}
	end
	local v84 = p81.open
	local v85 = type(v84) == "table" and (p81.open or {}) or {}
	for v86 = #v85, 1, -1 do
		local v87 = v82[v85[v86]]
		local v88
		if type(v87) == "table" then
			v88 = v87.world == true
		else
			v88 = false
		end
		if not (v88 and v87.sub) then
			continue
		end
		return v85[v86], v87
	end
	for _, v89 in v85 do
		local v90 = v82[v89]
		if v89 == "ground" then
			continue
		end
		local v91
		if type(v90) == "table" then
			v91 = v90.world == true
		else
			v91 = false
		end
		if not v91 or v90.sub then
			continue
		end
		return v89, v90
	end
	return nil, nil
end
local v_u_93 = {}
local function v_u_103(p94, p95) -- name: toGround
	-- upvalues: (copy) v_u_5
	if p95.kind == "slot" and p95.slot == "secure" then
		return false
	end
	if p95.kind == "grid" then
		v_u_5.remove(p95.c, p95.item.uid)
	else
		local v96 = p94.kit
		local v97 = p95.slot
		local v98 = v96.slots
		if type(v98) ~= "table" then
			v96.slots = {}
		end
		v96.slots[v97] = nil
		v96[v97] = nil
	end
	local v99
	if type(p94) == "table" then
		local v100 = p94.containers
		v99 = type(v100) == "table" and (p94.containers or {}) or {}
	else
		v99 = {}
	end
	local v101 = v99.ground
	if type(v101) == "table" then
		local v102 = v101.items
		if type(v102) == "table" then
			v_u_5.autoPlace(v101, p95.item)
		end
	end
	return true
end
function v_u_93.move(p104, p105, p106)
	-- upvalues: (copy) v_u_38, (copy) v_u_103, (copy) v_u_93, (copy) v_u_46, (copy) v_u_5, (copy) v_u_60
	local v107 = v_u_38(p104, p105.uid)
	if not v107 then
		return false
	end
	if p105.to == "ground" then
		local v108
		if p106 == "raid" then
			v108 = v_u_103(p104, v107)
		else
			v108 = false
		end
		return v108
	end
	local v109 = p105.to
	if type(v109) == "string" then
		local v110 = p105.to
		if string.sub(v110, 1, 5) == "slot:" then
			local v111 = v_u_93.equip
			local v112 = {
				["uid"] = p105.uid
			}
			local v113 = p105.to
			v112.slot = string.sub(v113, 6)
			return v111(p104, v112, p106)
		end
	end
	local v114
	if type(p104) == "table" then
		local v115 = p104.containers
		v114 = type(v115) == "table" and (p104.containers or {}) or {}
	else
		v114 = {}
	end
	local v116 = v114[p105.to]
	local v117 = p105.x
	local v118 = p105.y
	local v119 = p105.r == true
	if type(v116) == "table" then
		local v120 = v116.items
		if type(v120) == "table" and (type(v117) == "number" and type(v118) == "number") then
			local v121 = v107.item
			if v107.kind == "slot" and v107.slot == "secure" then
				return false
			end
			if not v_u_46(v121, p105.to, v116) then
				return false
			end
			local v122 = v_u_5.itemAt(v116, v117, v118, v121.uid)
			if v122 and v_u_5.canStack(v121, v122) then
				v_u_5.merge(v121, v122)
				if (v121.n or 0) <= 0 then
					if v107.kind == "grid" then
						v_u_5.remove(v107.c, v107.item.uid)
					else
						local v123 = p104.kit
						local v124 = v107.slot
						local v125 = v123.slots
						if type(v125) ~= "table" then
							v123.slots = {}
						end
						v123.slots[v124] = nil
						v123[v124] = nil
					end
				end
				return true
			end
			if not v_u_5.fits(v116, v121, v117, v118, v119, v121.uid) or v_u_60(v116, v121, v117, v118, v119) then
				return false
			end
			if v107.kind == "grid" then
				v_u_5.remove(v107.c, v107.item.uid)
			else
				local v126 = p104.kit
				local v127 = v107.slot
				local v128 = v126.slots
				if type(v128) ~= "table" then
					v126.slots = {}
				end
				v126.slots[v127] = nil
				v126[v127] = nil
			end
			v121.x = v117
			v121.y = v118
			v121.r = v119
			local v129 = v116.items
			table.insert(v129, v121)
			return true
		end
	end
	return false
end
function v_u_93.equip(p130, p131, p132)
	-- upvalues: (copy) v_u_38, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_46, (copy) v_u_80
	local v133 = v_u_38(p130, p131.uid)
	if not v133 or v133.kind ~= "grid" then
		return false
	end
	local v134 = v133.item
	local v135 = v_u_4.get(v134.id)
	local v136
	if v135 then
		v136 = v_u_4.equipSlot(v135)
	else
		v136 = v135
	end
	if v135 and (v136 == "primary" and p131.slot == "secondary") then
		if v_u_6.dropOk(v135, "secondary", v134, nil) ~= true then
			return false
		end
		v136 = "secondary"
	end
	if not v136 or p131.slot ~= nil and p131.slot ~= v136 or (v136 == "secure" or v135.grid ~= nil) then
		return false
	end
	local v137
	if type(p130) == "table" then
		local v138 = p130.kit
		if type(v138) == "table" then
			v137 = p130.kit or nil
		else
			v137 = nil
		end
	else
		v137 = nil
	end
	if not v137 then
		return false
	end
	local v139 = v137.slots
	if v139 then
		v139 = v137.slots[v136]
	end
	if v139 == nil then
		v139 = v137[v136]
	end
	if type(v139) ~= "table" then
		v139 = nil
	end
	if v139 then
		local v140
		if v139 then
			v140 = v_u_4.get(v139.id)
		else
			v140 = v139
		end
		local v141
		if v140 == nil then
			v141 = false
		else
			v141 = v140.grid ~= nil
		end
		if v141 or p132 ~= "raid" then
			return false
		end
	end
	if v133.c.world and (v133.c.sub and v139) then
		return false
	end
	local v142 = v134.x
	local v143 = v134.y
	local v144 = v134.r == true
	v_u_5.remove(v133.c, v134.uid)
	if v139 then
		local v145 = false
		if v_u_46(v139, v133.container, v133.c) then
			for _, v146 in { v144, not v144 } do
				if not v_u_5.fits(v133.c, v139, v142, v143, v146) then
					continue
				end
				v139.x = v142
				v139.y = v143
				v139.r = v146
				local v147 = v133.c.items
				table.insert(v147, v139)
				v145 = true
			end
		end
		if not v145 then
			local v148 = v137.slots
			if type(v148) ~= "table" then
				v137.slots = {}
			end
			v137.slots[v136] = nil
			v137[v136] = nil
			if v_u_80(p130, p132, v139, nil) == nil then
				local v149 = v137.slots
				if type(v149) ~= "table" then
					v137.slots = {}
				end
				v137.slots[v136] = v139
				v137[v136] = v139
				local v150 = v133.c.items
				table.insert(v150, v134)
				return false
			end
		end
	end
	local v151 = v137.slots
	if type(v151) ~= "table" then
		v137.slots = {}
	end
	v137.slots[v136] = v134
	v137[v136] = v134
	return true
end
function v_u_93.unequip(p152, p153, p154)
	-- upvalues: (copy) v_u_4, (copy) v_u_46, (copy) v_u_5, (copy) v_u_60, (copy) v_u_80
	local v155
	if type(p152) == "table" then
		local v156 = p152.kit
		if type(v156) == "table" then
			v155 = p152.kit or nil
		else
			v155 = nil
		end
	else
		v155 = nil
	end
	local v157 = p153.slot
	if not v155 or (type(v157) ~= "string" or v157 == "secure") then
		return false
	end
	local v158 = v155.slots
	if v158 then
		v158 = v155.slots[v157]
	end
	if v158 == nil then
		v158 = v155[v157]
	end
	if type(v158) ~= "table" then
		v158 = nil
	end
	if v158 then
		local v159
		if v158 then
			v159 = v_u_4.get(v158.id)
		else
			v159 = v158
		end
		local v160
		if v159 == nil then
			v160 = false
		else
			v160 = v159.grid ~= nil
		end
		if not v160 then
			if p153.to ~= nil then
				local v161
				if type(p152) == "table" then
					local v162 = p152.containers
					v161 = type(v162) == "table" and (p152.containers or {}) or {}
				else
					v161 = {}
				end
				local v163 = v161[p153.to]
				if type(v163) == "table" then
					local v164 = p153.x
					if type(v164) == "number" then
						local v165 = p153.y
						if type(v165) == "number" and v_u_46(v158, p153.to, v163) then
							if not v_u_5.fits(v163, v158, p153.x, p153.y, p153.r == true) or v_u_60(v163, v158, p153.x, p153.y, p153.r == true) then
								return false
							end
							local v166 = v155.slots
							if type(v166) ~= "table" then
								v155.slots = {}
							end
							v155.slots[v157] = nil
							v155[v157] = nil
							local v167 = p153.x
							local v168 = p153.y
							local v169 = p153.r == true
							v158.x = v167
							v158.y = v168
							v158.r = v169
							local v170 = v163.items
							table.insert(v170, v158)
							return true
						end
					end
				end
				return false
			end
			local v171 = v155.slots
			if type(v171) ~= "table" then
				v155.slots = {}
			end
			v155.slots[v157] = nil
			v155[v157] = nil
			if p154 == "menu" then
				local v172
				if type(p152) == "table" then
					local v173 = p152.containers
					v172 = type(v173) == "table" and (p152.containers or {}) or {}
				else
					v172 = {}
				end
				local v174 = v172.stash
				if type(v174) == "table" and v_u_5.autoPlace(v174, v158) then
					return true
				end
			elseif v_u_80(p152, p154, v158, nil) then
				return true
			end
			local v175 = v155.slots
			if type(v175) ~= "table" then
				v155.slots = {}
			end
			v155.slots[v157] = v158
			v155[v157] = v158
			return false
		end
	end
	return false
end
local function v_u_188(p176, p177, p178) -- name: takeIntoKit
	-- upvalues: (copy) v_u_4, (copy) v_u_80
	local v179 = v_u_4.get(p178.id)
	if v179 then
		local v180
		if type(p178) == "table" then
			local v181 = p178.items
			if type(v181) == "table" then
				v180 = #p178.items > 0
			else
				v180 = false
			end
		else
			v180 = false
		end
		if not v180 then
			local v182
			if type(p176) == "table" then
				local v183 = p176.kit
				if type(v183) == "table" then
					v182 = p176.kit or nil
				else
					v182 = nil
				end
			else
				v182 = nil
			end
			if not v182 then
				return false
			end
			if v179.equip and v179.equip ~= "secure" then
				local v184 = v179.equip
				local v185 = v182.slots
				if v185 then
					v185 = v182.slots[v184]
				end
				if v185 == nil then
					v185 = v182[v184]
				end
				if type(v185) ~= "table" then
					v185 = nil
				end
				if not v185 then
					if v179.grid ~= nil then
						return false
					end
					local v186 = v179.equip
					local v187 = v182.slots
					if type(v187) ~= "table" then
						v182.slots = {}
					end
					v182.slots[v186] = p178
					v182[v186] = p178
					return true
				end
			end
			return v_u_80(p176, p177, p178, nil) ~= nil
		end
	end
	return false
end
function v_u_93.quick(p189, p190, p191)
	-- upvalues: (copy) v_u_38, (copy) v_u_93, (copy) v_u_5, (copy) v_u_188, (copy) v_u_92, (copy) v_u_46, (copy) v_u_64, (copy) v_u_80
	local v192 = v_u_38(p189, p190.uid)
	if v192 then
		local v193 = v192.item
		if v192.kind == "slot" then
			return v_u_93.unequip(p189, {
				["slot"] = v192.slot
			}, p191)
		else
			local v194 = v192.c
			if p191 == "menu" then
				if v192.container == "stash" then
					v_u_5.remove(v194, v193.uid)
					if v_u_188(p189, p191, v193) then
						return true
					end
					local v195 = v194.items
					table.insert(v195, v193)
					return false
				end
				local v196
				if type(p189) == "table" then
					local v197 = p189.containers
					v196 = type(v197) == "table" and (p189.containers or {}) or {}
				else
					v196 = {}
				end
				local v198 = v196.stash
				if type(v198) ~= "table" then
					return false
				end
				v_u_5.remove(v194, v193.uid)
				if v_u_5.autoPlace(v198, v193) then
					return true
				end
				local v199 = v194.items
				table.insert(v199, v193)
				return false
			else
				local v200
				if type(v194) == "table" then
					v200 = v194.world == true
				else
					v200 = false
				end
				if v200 then
					v_u_5.remove(v194, v193.uid)
					if v_u_188(p189, p191, v193) then
						return true
					end
					local v201 = v194.items
					table.insert(v201, v193)
					return false
				else
					local v202, v203 = v_u_92(p189)
					if v202 and v203 then
						local v204 = v203.ph
						if type(v204) == "table" and #v203.ph > 0 then
							return false
						end
					end
					if v202 and (v203 and v_u_46(v193, v202, v203)) then
						v_u_5.remove(v194, v193.uid)
						if v_u_64(v203, v193) or v_u_5.autoPlace(v203, v193) then
							return true
						end
						local v205 = v194.items
						table.insert(v205, v193)
						return false
					else
						v_u_5.remove(v194, v193.uid)
						if v_u_80(p189, p191, v193, v194) then
							return true
						end
						local v206 = v194.items
						table.insert(v206, v193)
						return false
					end
				end
			end
		end
	else
		return false
	end
end
function v_u_93.split(p207, p208, p209)
	-- upvalues: (copy) v_u_38, (copy) v_u_5, (copy) v_u_60, (copy) v_u_23
	local v210 = v_u_38(p207, p208.uid)
	if v210 and v210.kind == "grid" then
		local v211 = v210.item
		local v212 = p208.n
		local v213 = tonumber(v212) or 0
		local v214 = math.floor(v213)
		if v214 == v214 and (v214 >= 1 and (v211.n or 1) > v214) then
			local v215 = table.clone(v211)
			local v216 = p208.seq or (p208.req or os.clock())
			v215.uid = "~pred" .. tostring(v216)
			v215.n = v214
			v215.mods = nil
			v215.items = nil
			if p208.to == nil then
				if v_u_5.autoPlace(v210.c, v215) then
					v211.n = v211.n - v214
					return true
				else
					if p209 == "raid" then
						local v217 = v210.c
						local v218
						if type(v217) == "table" then
							v218 = v217.world == true
						else
							v218 = false
						end
						if not v218 then
							for _, v219 in v_u_23[p209] do
								local v220
								if type(p207) == "table" then
									local v221 = p207.containers
									v220 = type(v221) == "table" and (p207.containers or {}) or {}
								else
									v220 = {}
								end
								local v222 = v220[v219]
								if not (v222 and v_u_5.autoPlace(v222, v215)) then
									continue
								end
								v211.n = v211.n - v214
								return true
							end
						end
					end
					return false
				end
			else
				local v223
				if type(p207) == "table" then
					local v224 = p207.containers
					v223 = type(v224) == "table" and (p207.containers or {}) or {}
				else
					v223 = {}
				end
				local v225 = v223[p208.to]
				if type(v225) == "table" then
					local v226 = p208.x
					if type(v226) == "number" then
						local v227 = p208.y
						if type(v227) == "number" then
							local v228 = v_u_5.itemAt(v225, p208.x, p208.y, nil)
							if v228 and (v228.uid ~= v211.uid and v_u_5.canStack(v215, v228)) then
								v211.n = v211.n - v_u_5.merge(v215, v228)
								return true
							end
							if not v_u_5.fits(v225, v215, p208.x, p208.y, p208.r == true) or v_u_60(v225, v215, p208.x, p208.y, p208.r == true) then
								return false
							end
							local v229 = p208.x
							local v230 = p208.y
							local v231 = p208.r == true
							v215.x = v229
							v215.y = v230
							v215.r = v231
							local v232 = v225.items
							table.insert(v232, v215)
							v211.n = v211.n - v214
							return true
						end
					end
				end
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function v_u_93.drop(p233, p234, p235)
	-- upvalues: (copy) v_u_38, (copy) v_u_103, (copy) v_u_5
	local v236 = v_u_38(p233, p234.uid)
	if not v236 then
		return false
	end
	if p235 ~= "raid" then
		if v236.kind == "slot" and v236.slot == "secure" then
			return false
		end
		if v236.kind == "grid" then
			v_u_5.remove(v236.c, v236.item.uid)
		else
			local v237 = p233.kit
			local v238 = v236.slot
			local v239 = v237.slots
			if type(v239) ~= "table" then
				v237.slots = {}
			end
			v237.slots[v238] = nil
			v237[v238] = nil
		end
		return true
	end
	if v236.kind == "slot" then
		v242 = v_u_103(p233, v236)
		return v242
	end
	local v240 = v236.c
	local v241
	if type(v240) == "table" then
		v241 = v240.world == true
	else
		v241 = false
	end
	local v242 = not v241
	if not v242 then
		return v242
	end
	v242 = v_u_103(p233, v236)
	return v242
end
function v_u_93.setquick(p243, p244, _)
	-- upvalues: (copy) v_u_38
	local v245
	if type(p243) == "table" then
		local v246 = p243.kit
		if type(v246) == "table" then
			v245 = p243.kit or nil
		else
			v245 = nil
		end
	else
		v245 = nil
	end
	local v247 = p244.index
	local v248 = tonumber(v247) or 0
	local v249 = math.floor(v248)
	if v245 and (v249 == v249 and (v249 >= 1 and v249 <= 4)) then
		local v250 = v245.quick
		if type(v250) ~= "table" then
			v245.quick = {}
		end
		if p244.uid == nil or p244.uid == "" then
			v245.quick[v249] = ""
			v245["quick" .. v249] = ""
			return true
		else
			local v251 = v_u_38(p243, p244.uid)
			if v251 and v251.kind == "grid" then
				local v252 = v251.c
				local v253
				if type(v252) == "table" then
					v253 = v252.world == true
				else
					v253 = false
				end
				if not v253 then
					for v254 = 1, 4 do
						if v245.quick[v254] ~= p244.uid then
							continue
						end
						v245.quick[v254] = ""
						v245["quick" .. v254] = ""
					end
					v245.quick[v249] = p244.uid
					v245["quick" .. v249] = p244.uid
					return true
				end
			end
			return false
		end
	else
		return false
	end
end
function v_u_93.roll(p255, p256, p257)
	return require(script.Parent:WaitForChild("InvUIRoll")).predict(p255, p256, p257)
end
function v_u_93.sort(p258, p259, p260)
	-- upvalues: (copy) v_u_22, (copy) v_u_5
	local v261
	if type(p258) == "table" then
		local v262 = p258.containers
		v261 = type(v262) == "table" and (p258.containers or {}) or {}
	else
		v261 = {}
	end
	local v263 = v261[p259.container]
	if type(v263) == "table" then
		local v264
		if type(v263) == "table" then
			v264 = v263.world == true
		else
			v264 = false
		end
		if not v264 and (p260 ~= "raid" or table.find(v_u_22.raid, p259.container)) then
			return v_u_5.sort(v263)
		end
	end
	return false
end
function v_u_93.close(p265, p266, _)
	local v267 = p266.container
	local v268
	if type(p265) == "table" then
		local v269 = p265.containers
		v268 = type(v269) == "table" and (p265.containers or {}) or {}
	else
		v268 = {}
	end
	local v270 = v268[v267]
	if type(v267) == "string" and v267 ~= "ground" then
		local v271
		if type(v270) == "table" then
			v271 = v270.world == true
		else
			v271 = false
		end
		if v271 then
			p265.containers[v267] = nil
			local v272 = p265.open
			if type(v272) == "table" then
				for v273 = #p265.open, 1, -1 do
					local v274 = p265.open[v273]
					local v275
					if type(p265) == "table" then
						local v276 = p265.containers
						v275 = type(v276) == "table" and (p265.containers or {}) or {}
					else
						v275 = {}
					end
					local v277 = v275[v274]
					if v274 ~= v267 and (type(v277) ~= "table" or v277.parent ~= v267) then
						continue
					end
					table.remove(p265.open, v273)
					if v274 == v267 then
						continue
					end
					p265.containers[v274] = nil
				end
			end
			return true
		end
	end
	return false
end
function v_u_93.use(p278, p279, p280)
	-- upvalues: (copy) v_u_38, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_93
	local v281 = v_u_38(p278, p279.uid)
	if v281 then
		if v281.kind == "grid" then
			local v282 = v281.c
			local v283
			if type(v282) == "table" then
				v283 = v282.world == true
			else
				v283 = false
			end
			if v283 then
				local v284 = v_u_4.get(v281.item.id)
				if not v284 or v284.category ~= "medical" then
					return v_u_93.quick(p278, p279, p280)
				end
				if p280 ~= "raid" or v_u_7.needText(v284) ~= nil then
					return false
				end
				if (v281.item.n or 1) > 1 then
					local v285 = v281.item
					v285.n = v285.n - 1
				elseif v281.kind == "grid" then
					v_u_5.remove(v281.c, v281.item.uid)
				else
					local v286 = p278.kit
					local v287 = v281.slot
					local v288 = v286.slots
					if type(v288) ~= "table" then
						v286.slots = {}
					end
					v286.slots[v287] = nil
					v286[v287] = nil
				end
				return true
			end
		end
		local v289 = v_u_4.get(v281.item.id)
		if v289 and (v289.equip and (v281.kind ~= "slot" and (v289.category ~= "medical" and v289.category ~= "throwable"))) then
			return v_u_93.equip(p278, {
				["uid"] = p279.uid
			}, p280)
		else
			return false
		end
	else
		return false
	end
end
function v_u_7.apply(p290, p291, p292) -- name: apply
	-- upvalues: (copy) v_u_93
	if type(p291) == "table" then
		local v293 = p291.op
		if type(v293) == "string" then
			local v294 = v_u_93[p291.op]
			if v294 then
				local v295
				if type(p290) == "table" then
					local v296 = p290.kit
					if type(v296) == "table" then
						v295 = p290.kit or nil
					else
						v295 = nil
					end
				else
					v295 = nil
				end
				if v295 then
					local v297, v298 = pcall(v294, p290, p291, p292)
					if v297 then
						v297 = v298 == true
					end
					return v297
				end
			end
			return false
		end
	end
	return false
end
function v_u_7.applyNow(p299, p300, p301) -- name: applyNow
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_19
	local v302 = v_u_7.apply(p299, p300, p301)
	if v302 then
		local v303 = v_u_7.stats
		v303.predicted = v303.predicted + 1
		local v304 = v_u_8
		local v305 = string.format
		local v306 = p300.op
		v304:SetAttribute("InvPredLast", v305("%s@%.3f", tostring(v306), os.clock()))
	end
	v_u_19()
	return v302
end
local function v_u_313(p307) -- name: expire
	-- upvalues: (copy) v_u_20, (copy) v_u_7
	local v308 = v_u_20[p307]
	local v309 = os.clock()
	local v310 = false
	for v311 = #v308, 1, -1 do
		if v309 - v308[v311].t <= v_u_7.TIMEOUT then
			continue
		end
		table.remove(v308, v311)
		local v312 = v_u_7.stats
		v312.expired = v312.expired + 1
		v310 = true
	end
	return v310
end
function v_u_7.record(p314, p315, p316) -- name: record
	-- upvalues: (ref) v_u_21, (copy) v_u_93, (copy) v_u_20, (copy) v_u_7
	local v317 = p314 == "raid" and "raid" or "menu"
	local v318
	if v317 == "raid" then
		v_u_21 = v_u_21 + 1
		p315.seq = v_u_21
		v318 = v_u_21
	else
		v318 = p316 or ""
	end
	if v_u_93[p315.op] then
		local v319 = v_u_20[v317]
		local v320 = table.clone(p315)
		if v317 == "menu" then
			v320.req = v318
		end
		local v321 = {
			["key"] = v318,
			["op"] = v320,
			["t"] = os.clock()
		}
		table.insert(v319, v321)
		if #v319 > 40 then
			table.remove(v319, 1)
		end
	end
	local v322 = v_u_7.stats
	v322.sent = v322.sent + 1
	return p315
end
function v_u_7.replay(p323, p324) -- name: replay
	-- upvalues: (copy) v_u_313, (copy) v_u_20, (copy) v_u_7
	local v325 = p323 == "raid" and "raid" or "menu"
	v_u_313(v325)
	for _, v326 in v_u_20[v325] do
		if not v_u_7.apply(p324, v326.op, v325) then
			continue
		end
		local v327 = v_u_7.stats
		v327.replayed = v327.replayed + 1
	end
end
function v_u_7.ack(p328) -- name: ack
	-- upvalues: (copy) v_u_20, (copy) v_u_7, (copy) v_u_19
	if type(p328) == "number" then
		local v329 = v_u_20.raid
		for v330 = #v329, 1, -1 do
			local v331 = v329[v330].key
			if type(v331) ~= "number" or v331 > p328 then
				continue
			end
			v_u_7.stats.rtt = os.clock() - v329[v330].t
			table.remove(v329, v330)
			local v332 = v_u_7.stats
			v332.acked = v332.acked + 1
		end
		v_u_19()
	end
end
function v_u_7.menuResult(p333, p334) -- name: menuResult
	-- upvalues: (copy) v_u_20, (copy) v_u_7
	local v335 = v_u_20.menu
	for v336, v337 in v335 do
		if v337.key ~= p333 then
			continue
		end
		v_u_7.stats.rtt = os.clock() - v337.t
		if p334 then
			v337.ok = true
			v337.t = os.clock()
		else
			table.remove(v335, v336)
			local v338 = v_u_7.stats
			v338.refused = v338.refused + 1
		end
		return true
	end
	return false
end
function v_u_7.menuState() -- name: menuState
	-- upvalues: (copy) v_u_20, (copy) v_u_7
	local v339 = v_u_20.menu
	for v340 = #v339, 1, -1 do
		if not v339[v340].ok then
			continue
		end
		table.remove(v339, v340)
		local v341 = v_u_7.stats
		v341.acked = v341.acked + 1
	end
end
function v_u_7.pending(p342) -- name: pending
	-- upvalues: (copy) v_u_20
	return #(v_u_20[p342] or {})
end
function v_u_7.clear(p343) -- name: clear
	-- upvalues: (copy) v_u_20
	for v344, v345 in v_u_20 do
		if p343 ~= nil and p343 ~= v344 then
			continue
		end
		table.clear(v345)
	end
end
local v_u_346 = 0
v2.Heartbeat:Connect(function(p347)
	-- upvalues: (ref) v_u_346, (copy) v_u_20, (copy) v_u_313, (copy) v_u_7
	v_u_346 = v_u_346 + p347
	if v_u_346 >= 0.25 then
		v_u_346 = 0
		for _, v348 in { "raid", "menu" } do
			if #v_u_20[v348] <= 0 or not (v_u_313(v348) and v_u_7.onExpire) then
				continue
			end
			local v349 = v_u_7.onExpire
			pcall(v349, v348)
		end
	end
end)
local v_u_350 = 0
function v_u_7.needText(p_u_351) -- name: needText
	-- upvalues: (copy) v_u_8
	if type(p_u_351) == "table" and p_u_351.category == "medical" then
		local v352 = p_u_351.use
		if type(v352) == "table" then
			local v353 = v_u_8.Character
			if not v353 or (v353:GetAttribute("Dead") == true or v353:GetAttribute("Downed") == true) then
				return "You can\'t do that now"
			end
			local v354 = v353:GetAttribute("Action")
			if type(v354) == "string" and v354 ~= "" then
				return "busy"
			end
			local v_u_355 = p_u_351.use
			local v356 = tonumber(v353:GetAttribute("Hp")) or 100
			local v357 = tonumber(v353:GetAttribute("MaxHp")) or 100
			local v358 = (tonumber(v353:GetAttribute("Bleeding")) or 0) > 0
			if v_u_355.heal and (v_u_355.heal > 0 and v356 < v357) then
				v358 = true
			elseif not (v_u_355.stopsBleeding and v358) then
				if v_u_355.fixesFracture and v353:GetAttribute("Fracture") == true or v_u_355.infectionDelay and v353:GetAttribute("Infected") == true then
					v358 = true
				else
					local v359 = v_u_355.staminaBuff
					if type(v359) == "number" then
						v358 = v_u_355.staminaBuff > 0
					else
						v358 = false
					end
				end
			end
			if v358 then
				return nil
			end
			local v360, v361 = pcall(function()
				-- upvalues: (copy) p_u_351, (copy) v_u_355
				return require((script.Parent:WaitForChild("InvUIWhy", 3))).notNeeded(p_u_351.name, v_u_355)
			end)
			return (not v360 or (type(v361) ~= "string" or v361 == "")) and "You don\'t need that right now" or v361
		end
	end
	return "Can\'t use this"
end
function v_u_7.lootUse(p362, p363) -- name: lootUse
	-- upvalues: (copy) v_u_7
	local v364
	if p362 == "raid" then
		v364 = v_u_7.needText(p363) == nil
	else
		v364 = false
	end
	return v364
end
function v_u_7.useFeedback(p365) -- name: useFeedback
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (ref) v_u_350
	local v366 = v_u_7.needText(p365)
	if v366 == "Can\'t use this" or (v366 == "You can\'t do that now" or v366 == "busy") then
		return nil
	end
	if v366 then
		return v366
	end
	local v367 = p365.use
	local v368 = p365.id == "med_bandage" and "Bandage" or "Use"
	local v369 = v_u_8:GetAttribute("PredAction")
	if type(v369) == "string" and (v369 ~= "" and (v369 ~= "Bandage" and v369 ~= "Use")) then
		local v370 = v_u_8
		if os.clock() < (tonumber(v370:GetAttribute("PredActionEnds")) or 0) then
			return nil
		end
	end
	v_u_350 = os.clock()
	v_u_8:SetAttribute("PredAction", v368)
	local v371 = v_u_8
	local v372 = os.clock()
	local v373 = v367.time
	local v374 = tonumber(v373) or 1.6
	v371:SetAttribute("PredActionEnds", v372 + math.min(1.6, v374))
	v_u_8:SetAttribute("PredUseAt", v_u_350)
	return nil
end
function v_u_7.cancelUse() -- name: cancelUse
	-- upvalues: (copy) v_u_8, (ref) v_u_350
	local v375 = v_u_8:GetAttribute("PredAction")
	if (v375 == "Bandage" or v375 == "Use") and os.clock() - v_u_350 < 2 then
		v_u_8:SetAttribute("PredAction", nil)
		v_u_8:SetAttribute("PredActionEnds", nil)
	end
end
local v_u_376 = 0
v2.Heartbeat:Connect(function(p377)
	-- upvalues: (ref) v_u_376, (copy) v_u_8
	v_u_376 = v_u_376 + p377
	if v_u_376 < 0.1 then
		return
	end
	v_u_376 = 0
	local v378 = v_u_8:GetAttribute("PredAction")
	if v378 ~= "Bandage" and v378 ~= "Use" then
		return
	end
	local v379 = v_u_8.Character
	if v379 then
		v379 = v379:GetAttribute("Action")
	end
	if v379 == v378 then
		v_u_8:SetAttribute("PredAction", nil)
		v_u_8:SetAttribute("PredActionEnds", nil)
		return
	else
		local v380 = v_u_8
		if os.clock() >= (tonumber(v380:GetAttribute("PredActionEnds")) or 0) then
			v_u_8:SetAttribute("PredAction", nil)
			v_u_8:SetAttribute("PredActionEnds", nil)
		end
	end
end)
return v_u_7