-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / OccludeRules

local v_u_107 = {
	["MAPS"] = {
		["tokyo"] = true
	},
	["FADE"] = 1,
	["REVEAL_FADE"] = 1,
	["OCC_FADE"] = 1,
	["REVEAL_OCC"] = 1,
	["GUI_OFF"] = 0.5,
	["SHADOW_OFF"] = 1,
	["HOLD"] = 0.3,
	["END_PULL"] = 1.5,
	["BOX_MARGIN"] = 0.6,
	["SHELL_PAD"] = 1.6,
	["CORRIDOR_HALF"] = 10,
	["MAX_TOP"] = 110,
	["OVERHEAD_GAP"] = 1,
	["UNIT_MAX"] = 60,
	["STOREY_DY"] = 11,
	["SCAN_INTERVAL"] = 0.08333333333333333,
	["VOL_PAD"] = 8,
	["VOL_CAM"] = 30,
	["VOL_TOP"] = 160,
	["VOL_REFRESH"] = 1,
	["VOL_YAW"] = 0.2617993877991494,
	["VIEW_RADIUS"] = 120,
	["TAN_MIN"] = 0.4,
	["TAN_MAX"] = 3,
	["MONOLITH"] = {
		["fermata_aft"] = {
			["fer_aft_house"] = true,
			["fer_funnel"] = true
		}
	},
	["monolithPieces"] = function(p1) -- name: monolithPieces
		-- upvalues: (copy) v_u_107
		if type(p1) == "string" then
			return v_u_107.MONOLITH[p1]
		else
			return nil
		end
	end,
	["isMonolith"] = function(p2, p3) -- name: isMonolith
		-- upvalues: (copy) v_u_107
		local v4 = v_u_107.monolithPieces(p2)
		local v5
		if v4 == nil or type(p3) ~= "string" then
			v5 = false
		else
			v5 = v4[p3] == true
		end
		return v5
	end,
	["mapOn"] = function(p6) -- name: mapOn
		-- upvalues: (copy) v_u_107
		local v7
		if type(p6) == "string" then
			v7 = v_u_107.MAPS[p6] == true
		else
			v7 = false
		end
		return v7
	end,
	["corridorLength"] = function(p8, p9, p10, p11) -- name: corridorLength
		-- upvalues: (copy) v_u_107
		if p9 ~= p9 or p9 <= 0 then
			return 0
		end
		local v12 = v_u_107.TAN_MIN
		local v13 = v_u_107.TAN_MAX
		local v14 = math.clamp(p10, v12, v13)
		local v15 = (p11 - p8) / v14 + 4
		return math.clamp(v15, 0, p9)
	end,
	["key"] = function(p16, p17) -- name: key
		return (p16 + 4096) * 8192 + (p17 + 4096)
	end,
	["corridorCells"] = function(p18, p19, p20, p21, p22, p23, p24, p25) -- name: corridorCells
		table.clear(p25)
		if p22 ~= p22 or (p23 ~= p23 or p24 <= 0) then
			return 0
		end
		local v26 = p18 + p20 * p22
		local v27 = p19 + p21 * p22
		local v28 = p23 + p24
		local v29 = math.min(p18, v26) - v28
		local v30 = math.max(p18, v26) + v28
		local v31 = math.min(p19, v27) - v28
		local v32 = math.max(p19, v27) + v28
		local v33 = p24 * 0.7072
		local v34 = v29 / p24
		local v35 = math.floor(v34)
		local v36 = v30 / p24
		local v37 = 0
		for v38 = v35, math.floor(v36) do
			local v39 = (v38 + 0.5) * p24 - p18
			local v40 = v31 / p24
			local v41 = math.floor(v40)
			local v42 = v32 / p24
			for v43 = v41, math.floor(v42) do
				local v44 = (v43 + 0.5) * p24 - p19
				local v45 = v39 * p20 + v44 * p21
				local v46 = v39 * p21 - v44 * p20
				local v47 = math.abs(v46)
				if -v33 > v45 or (v45 > p22 + v33 or v47 > p23 + v33) then
					continue
				end
				v37 = v37 + 1
				p25[v37] = (v38 + 4096) * 8192 + (v43 + 4096)
			end
		end
		return v37
	end,
	["pullEnd"] = function(p48, p49, p50) -- name: pullEnd
		local v51 = p48 - p49
		local v52 = v51.Magnitude
		if v52 < 1e-6 then
			return p49
		end
		local v53 = v52 * 0.5
		return p49 + v51 * (math.min(p50, v53) / v52)
	end,
	["newHold"] = function() -- name: newHold
		return {
			["t"] = (-1 / 0)
		}
	end,
	["hold"] = function(p54, p55, p56) -- name: hold
		-- upvalues: (copy) v_u_107
		if not p55 then
			return p56 - p54.t <= v_u_107.HOLD
		end
		p54.t = p56
		return true
	end,
	["guiOn"] = function(p57) -- name: guiOn
		-- upvalues: (copy) v_u_107
		return p57 < v_u_107.GUI_OFF
	end,
	["shadowOn"] = function(p58) -- name: shadowOn
		-- upvalues: (copy) v_u_107
		return p58 < v_u_107.SHADOW_OFF
	end,
	["sameFloor"] = function(p59, p60, p61) -- name: sameFloor
		-- upvalues: (copy) v_u_107
		if p59 ~= p59 or p60 ~= p60 then
			return false
		end
		if p59 < p61 ~= (p60 < p61) then
			return false
		end
		local v62 = p59 - p60
		return math.abs(v62) <= v_u_107.STOREY_DY
	end,
	["overheadValue"] = function(p63, p64) -- name: overheadValue
		-- upvalues: (copy) v_u_107
		if type(p63) == "table" then
			local v65 = p63.transparency
			if type(v65) == "number" then
				local v66 = p63.bottom
				if type(v66) == "number" then
					if p63.transparency >= 0.95 then
						return nil
					else
						return p63.bottom >= p64 + v_u_107.OVERHEAD_GAP and 1 or nil
					end
				end
			end
		end
		return nil
	end,
	["unitOk"] = function(p67, p68, p69) -- name: unitOk
		-- upvalues: (copy) v_u_107
		local v70
		if p67 <= v_u_107.UNIT_MAX and p68 <= v_u_107.UNIT_MAX then
			v70 = p69 <= v_u_107.UNIT_MAX
		else
			v70 = false
		end
		return v70
	end,
	["underVolume"] = function(p71, p72, p73, p74, p75, p76, p77) -- name: underVolume
		-- upvalues: (copy) v_u_107
		local v78 = p71 - v_u_107.VOL_PAD
		local v79 = p73 + v_u_107.VOL_PAD
		local v80 = p72 - v_u_107.VOL_PAD
		local v81 = p74 + v_u_107.VOL_PAD
		local v82 = p76 * p76 + p77 * p77
		local v83 = math.sqrt(v82)
		if v83 > 1e-6 then
			local v84 = p76 / v83
			local v85 = p77 / v83
			local v86 = v_u_107.VOL_CAM
			local v87 = -v84
			v78 = v78 - v86 * math.max(v87, 0)
			v79 = v79 + v_u_107.VOL_CAM * math.max(v84, 0)
			local v88 = v_u_107.VOL_CAM
			local v89 = -v85
			v80 = v80 - v88 * math.max(v89, 0)
			v81 = v81 + v_u_107.VOL_CAM * math.max(v85, 0)
		end
		return (v78 + v79) * 0.5, (p75 + v_u_107.VOL_TOP) * 0.5, (v80 + v81) * 0.5, v79 - v78, v_u_107.VOL_TOP - p75, v81 - v80
	end,
	["viewBox"] = function(p90, p91, p92, p93, p94) -- name: viewBox
		-- upvalues: (copy) v_u_107
		local v95 = p90 - v_u_107.VIEW_RADIUS
		local v96 = p90 + v_u_107.VIEW_RADIUS
		local v97 = p91 - v_u_107.VIEW_RADIUS
		local v98 = p91 + v_u_107.VIEW_RADIUS
		local v99 = p93 * p93 + p94 * p94
		local v100 = math.sqrt(v99)
		if v100 > 1e-6 then
			local v101 = p93 / v100
			local v102 = p94 / v100
			local v103 = v_u_107.VOL_CAM
			local v104 = -v101
			v95 = v95 - v103 * math.max(v104, 0)
			v96 = v96 + v_u_107.VOL_CAM * math.max(v101, 0)
			local v105 = v_u_107.VOL_CAM
			local v106 = -v102
			v97 = v97 - v105 * math.max(v106, 0)
			v98 = v98 + v_u_107.VOL_CAM * math.max(v102, 0)
		end
		return (v95 + v96) * 0.5, (p92 + v_u_107.VOL_TOP) * 0.5, (v97 + v98) * 0.5, v96 - v95, v_u_107.VOL_TOP - p92, v98 - v97
	end
}
return v_u_107