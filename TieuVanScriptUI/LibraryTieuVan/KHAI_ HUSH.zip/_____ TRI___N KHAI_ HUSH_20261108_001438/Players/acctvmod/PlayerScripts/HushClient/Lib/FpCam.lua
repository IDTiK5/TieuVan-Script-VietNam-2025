-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FpCam

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = require(script.Parent.FpCamMath)
local v_u_4 = v1.LocalPlayer
local v_u_5 = v_u_3.TP
local v_u_6 = v_u_3.FOV_DEFAULT
local v_u_7 = RaycastParams.new()
v_u_7.FilterType = Enum.RaycastFilterType.Exclude
v_u_7.RespectCanCollide = true
local v_u_8 = {}
local v_u_9 = false
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = false
local v_u_14 = 0
local v_u_15 = false
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = 0
local v_u_19 = false
local v_u_20 = -1
local v21 = {
	["RIDE_HOOK"] = true
}
local v_u_22 = {}
local v_u_23 = 0
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = 10
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = 0
local v_u_33 = 0
local v_u_34 = 0
local v_u_35 = false
local v_u_36 = false
local v_u_37 = nil
local v_u_38 = nil
local v_u_39 = "fp"
local v_u_40 = -1000000000
local v_u_41 = 0
local v_u_42 = {}
local v_u_43 = 0
local v_u_44 = nil
local v_u_45 = false
local v_u_46 = false
local v_u_47 = nil
local v_u_48 = 0
local v_u_49 = 0
local v_u_50 = nil
local v_u_51 = 0
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = 0
local v_u_55 = 99
local v_u_56 = -1000000000
local v_u_57 = {}
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = 0
local v_u_61 = nil
local v_u_62 = {}
local v_u_63 = -1000000000
local v_u_64 = false
local v_u_65 = 0
local v_u_66 = nil
local v_u_67 = nil
local v_u_68 = nil
local v_u_69 = -1000000000
local v_u_70 = 0
local v_u_71 = 0
local v_u_72 = 0
local v_u_73 = nil
local v_u_74 = 0
for _, v75 in v_u_3.SETTINGS do
	v_u_8[v75.key] = v75.attr
end
local function v_u_80(p_u_76) -- name: lib
	-- upvalues: (copy) v_u_57, (ref) v_u_61
	local v77 = v_u_57[p_u_76]
	if v77 == nil then
		local v_u_78 = v_u_61
		if v_u_78 == nil then
			return nil
		end
		local v79
		v79, v77 = pcall(function()
			-- upvalues: (copy) v_u_78, (copy) p_u_76
			return v_u_78.lib[p_u_76]
		end)
		if not v79 or type(v77) ~= "table" then
			v77 = false
		end
		v_u_57[p_u_76] = v77
	end
	return v77 or nil
end
local function v_u_88(p81, p82, ...) -- name: callCtl
	-- upvalues: (ref) v_u_61
	local v83 = v_u_61 and v_u_61.controllers
	if v83 then
		v83 = v_u_61.controllers[p81]
	end
	if not v83 or v83._broken then
		v83 = nil
	end
	if v83 then
		local v84 = v83[p82]
		if type(v84) == "function" then
			local v85 = v83[p82]
			local v86, v87 = pcall(v85, ...)
			if v86 then
				return v87
			end
		end
	end
	return nil
end
local function v_u_93(p89) -- name: setting
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (ref) v_u_62
	local v90 = v_u_4
	if v90 ~= nil then
		local v91 = v90:GetAttribute(v_u_8[p89])
		if v91 ~= nil then
			return v_u_3.readSetting(p89, v91)
		end
	end
	local v92 = v_u_62[p89]
	if v92 == nil then
		return v_u_3.defaultOf(p89)
	else
		return v_u_3.readSetting(p89, v92)
	end
end
local function v_u_98(p94, p95) -- name: params
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_7
	local v96 = workspace.CurrentCamera
	if p94 ~= v_u_10 or (p95 ~= v_u_11 or v96 ~= v_u_12) then
		v_u_10 = p94
		v_u_11 = p95
		v_u_12 = v96
		local v97 = {}
		if p94 then
			table.insert(v97, p94)
		end
		if p95 then
			table.insert(v97, p95)
		end
		if v96 then
			table.insert(v97, v96)
		end
		v_u_7.FilterDescendantsInstances = v97
	end
	return v_u_7
end
local function v_u_104() -- name: fetchSettings
	-- upvalues: (ref) v_u_61, (ref) v_u_15, (ref) v_u_56, (ref) v_u_63, (ref) v_u_62, (ref) v_u_64, (ref) v_u_39, (copy) v_u_3, (ref) v_u_40, (ref) v_u_41
	local v_u_99 = v_u_61
	local v100 = os.clock()
	if v_u_99 ~= nil and (not v_u_15 and (v100 - v_u_56 >= 30 and v100 - v_u_63 >= 10)) then
		v_u_15 = true
		v_u_63 = v100
		task.spawn(function()
			-- upvalues: (copy) v_u_99, (ref) v_u_15, (ref) v_u_56, (ref) v_u_62, (ref) v_u_64, (ref) v_u_39, (ref) v_u_3, (ref) v_u_40, (ref) v_u_41
			local v101 = v_u_99.net.invoke
			local v102, v103 = pcall(v101, "menu.get", {
				["what"] = "settings"
			})
			v_u_15 = false
			if v102 and (type(v103) == "table" and v103.error == nil) then
				v_u_56 = os.clock()
				v_u_62 = v103
				if not v_u_64 then
					v_u_39 = v_u_3.sideOf(v103.fpSide)
					if os.clock() - v_u_40 < 3 then
						v_u_41 = v_u_39 == "tp" and 1 or 0
					end
				end
			end
		end)
	end
end
local function v_u_117(p105) -- name: wantMouse
	-- upvalues: (ref) v_u_9, (ref) v_u_61, (copy) v_u_4, (copy) v_u_88, (copy) v_u_2, (copy) v_u_80, (ref) v_u_45
	if not v_u_9 or (p105 or (v_u_61 == nil or v_u_4 == nil)) then
		return false
	end
	local v106 = v_u_88("Input", "device")
	if (type(v106) ~= "string" and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v106) ~= "Keyboard" or not v_u_2.MouseEnabled then
		return false
	end
	if v_u_88("Camera", "hasOverride") == true then
		return false
	end
	if v_u_88("Input", "gameBlocked") == true then
		return false
	end
	local v107 = v_u_4:FindFirstChildOfClass("PlayerGui")
	if v107 then
		v107 = v107:FindFirstChild("HushFilm")
	end
	if v107 ~= nil and (v107:IsA("ScreenGui") and v107.Enabled) then
		return false
	end
	local v108 = v_u_80("UiPointer")
	if v108 ~= nil then
		local v109 = v108.windowOpen
		local v110 = v_u_61
		local v111, v112 = pcall(v109, v110)
		if v111 and v112 == true then
			return false
		end
		if not v_u_45 then
			local v113 = v108.overButton
			local v114 = v_u_2
			local v115, v116 = pcall(v113, v114:GetMouseLocation())
			if v115 and v116 == true then
				return false
			end
		end
	end
	return true
end
local function v_u_120() -- name: releaseMouse
	-- upvalues: (ref) v_u_45, (ref) v_u_46, (copy) v_u_2, (ref) v_u_36
	if v_u_45 then
		v_u_45 = false
		v_u_46 = false
		local function v118()
			-- upvalues: (ref) v_u_2
			v_u_2.MouseBehavior = Enum.MouseBehavior.Default
		end
		pcall(v118)
		if v_u_36 then
			v_u_36 = false
			local function v119()
				-- upvalues: (ref) v_u_2
				v_u_2.MouseIconEnabled = true
			end
			pcall(v119)
		end
	end
end
local function v_u_129(p121, p122) -- name: frictionNow
	-- upvalues: (copy) v_u_88, (copy) v_u_2, (copy) v_u_4, (copy) v_u_42, (copy) v_u_3
	local v123 = v_u_88("Input", "device")
	if (type(v123) ~= "string" and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v123) ~= "Gamepad" then
		return 1
	end
	local v124 = v_u_4
	if v124 == nil or v124:GetAttribute("AimAssist") == false then
		return 1
	end
	local v125 = 180
	for _, v126 in v_u_42 do
		local v127 = v126 - p121
		local v128 = v_u_3.angleDeg(p122.X, p122.Y, p122.Z, v127.X, v127.Y, v127.Z)
		if v128 >= v125 then
			continue
		end
		v125 = v128
	end
	return v_u_3.frictionFactor(v125, true)
end
local function v_u_143(p130, p131) -- name: refreshZombies
	-- upvalues: (ref) v_u_69, (copy) v_u_42, (copy) v_u_88, (copy) v_u_2, (ref) v_u_61
	if p130 - v_u_69 < 0.2 then
		return
	end
	v_u_69 = p130
	table.clear(v_u_42)
	local v132 = v_u_88("Input", "device")
	if (type(v132) ~= "string" and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v132) ~= "Gamepad" then
		return
	end
	local v133 = v_u_61 and v_u_61.controllers
	if v133 then
		v133 = v_u_61.controllers.ZombieRender
	end
	if not v133 or v133._broken then
		v133 = nil
	end
	if v133 ~= nil then
		local v134 = v133.targets
		if type(v134) == "function" then
			local v135 = v133.targets
			local v136, v137 = pcall(v135, p131, 60)
			if not v136 or type(v137) ~= "table" then
				return
			end
			for _, v138 in v137 do
				if type(v138) == "table" then
					local v139 = v138.position
					if typeof(v139) == "Vector3" and v138.visible ~= false then
						local v140 = v_u_42
						local v141 = v138.position
						table.insert(v140, v141)
						if #v_u_42 < 60 then
							continue
						end
						break
					end
				end
				if typeof(v138) ~= "Vector3" then
					continue
				end
				local v142 = v_u_42
				table.insert(v142, v138)
			end
			return
		end
	end
end
local function v_u_148() -- name: drainInputs
	-- upvalues: (ref) v_u_45, (copy) v_u_2, (copy) v_u_80
	if v_u_45 then
		local function v144()
			-- upvalues: (ref) v_u_2
			v_u_2:GetMouseDelta()
		end
		pcall(v144)
	end
	local v145 = v_u_80("FpTouch")
	if v145 ~= nil then
		local v146 = v145.lookDelta
		if type(v146) == "function" then
			local v147 = v145.lookDelta
			pcall(v147)
		end
	end
end
local function v_u_215(p149, p150, p151, p152) -- name: integrateLook
	-- upvalues: (ref) v_u_67, (ref) v_u_23, (ref) v_u_37, (ref) v_u_38, (ref) v_u_58, (ref) v_u_59, (ref) v_u_60, (ref) v_u_70, (ref) v_u_43, (copy) v_u_3, (copy) v_u_148, (copy) v_u_22, (copy) v_u_88, (copy) v_u_93, (ref) v_u_71, (ref) v_u_72, (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (copy) v_u_2, (ref) v_u_61, (copy) v_u_143, (copy) v_u_129, (copy) v_u_80, (ref) v_u_73, (ref) v_u_24, (ref) v_u_25
	if v_u_67 ~= nil then
		if v_u_23 > 0 and v_u_23 < p150 then
			if v_u_67 ~= nil and (v_u_37 ~= nil and v_u_38 ~= nil) then
				local v153 = v_u_37
				local v154 = v_u_38
				local v155 = os.clock() + 0.6
				v_u_58 = v153
				v_u_59 = v154
				v_u_60 = v155
			end
			v_u_67 = nil
			v_u_23 = 0
			v_u_37 = nil
			v_u_38 = nil
		else
			local v156 = v_u_67
			local v157, v158, v159 = pcall(v156, p149)
			if v157 and (type(v158) == "number" and type(v159) == "number") then
				local v160, v161 = v_u_3.lockStep(v_u_70, v_u_43, v158, v159, p149)
				v_u_70 = v160
				v_u_43 = v161
				v_u_37 = v158
				v_u_38 = v159
				v_u_148()
				return
			end
			if not v157 then
				local v162 = (v_u_22.lockLook or 0) + 1
				v_u_22.lockLook = v162
				if v162 <= 3 or v162 % 300 == 0 then
					warn("[FpCam] " .. "lockLook" .. " failed: " .. tostring(v158))
				end
				if v_u_67 ~= nil and (v_u_37 ~= nil and v_u_38 ~= nil) then
					local v163 = v_u_37
					local v164 = v_u_38
					local v165 = os.clock() + 0.6
					v_u_58 = v163
					v_u_59 = v164
					v_u_60 = v165
				end
				v_u_67 = nil
				v_u_23 = 0
				v_u_37 = nil
				v_u_38 = nil
			end
		end
	end
	if p152 and v_u_88("Input", "gameBlocked") ~= true then
		local v166 = v_u_93("fpInvertY") == true
		local v167 = v_u_71
		local v168 = v_u_72
		local v169 = math.max(v167, v168)
		local v170 = v_u_93("fov")
		local v171 = v_u_3.adsLookFactor(v169, v_u_93("fpAdsSens"), v_u_44, v170)
		if v_u_45 then
			if v_u_46 then
				v_u_46 = false
				local function v172()
					-- upvalues: (ref) v_u_2
					v_u_2:GetMouseDelta()
				end
				pcall(v172)
			else
				local function v173()
					-- upvalues: (ref) v_u_2
					return v_u_2:GetMouseDelta()
				end
				local v174, v175 = pcall(v173)
				if v174 and (typeof(v175) == "Vector2" and (v175.X ~= 0 or v175.Y ~= 0)) then
					local v176, v177 = v_u_3.mouseLook(v_u_70, v_u_43, v175.X, v175.Y, v_u_93("sensitivity"), v171, v166)
					v_u_70 = v176
					v_u_43 = v177
				end
			end
		end
		local v178 = v_u_88("Input", "device")
		if (type(v178) ~= "string" and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v178) == "Gamepad" then
			local v179 = v_u_61 and v_u_61.controllers
			if v179 then
				v179 = v_u_61.controllers.Input
			end
			if not v179 or v179._broken then
				v179 = nil
			end
			if v179 ~= nil then
				local v180 = v179.rawLook
				if type(v180) == "function" then
					local v181 = v179.rawLook
					local v182, v183 = pcall(v181)
					if v182 and (typeof(v183) == "Vector2" and (v183.X ~= 0 or v183.Y ~= 0)) then
						local v184 = CFrame.fromOrientation(v_u_43, v_u_70, 0).LookVector
						v_u_143(p150, p151)
						local v185 = v_u_129(p151, v184)
						local v186, v187 = v_u_3.padLook(v_u_70, v_u_43, v183.X, v183.Y, p149, v_u_93("fpPadSens"), v169, v185, v166)
						v_u_70 = v186
						v_u_43 = v187
					end
				end
			end
		end
		local v188 = v_u_80("FpTouch")
		local v189 = 0
		local v190 = 0
		local v191, v192
		if v188 == nil then
			v191 = v190
			v192 = v189
		else
			local v193 = v188.lookDelta
			if type(v193) == "function" then
				local v194 = v188.lookDelta
				local v195
				v195, v192, v191 = pcall(v194)
				if v195 and (type(v192) == "number" and (type(v191) == "number" and (v192 ~= 0 or v191 ~= 0))) then
					local v196, v197 = v_u_3.touchLook(v_u_70, v_u_43, v192, v191, v166)
					v_u_70 = v196
					v_u_43 = v197
				else
					v191 = v190
					v192 = v189
				end
			else
				v191 = v190
				v192 = v189
			end
		end
		local v198 = v_u_80("AimPullFeed")
		if v198 ~= nil then
			local v199 = v198.step
			if type(v199) == "function" then
				local v200 = v198.step
				local v201 = v_u_73
				local v202 = v_u_24
				local v203 = v_u_70 + math.rad(v202)
				local v204 = v_u_25
				local v205 = v_u_43 + math.rad(v204)
				local v206 = v_u_88("Input", "device")
				local v207 = type(v206) ~= "string" and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v206
				local v208 = v_u_61
				local v209, v210, v211 = pcall(v200, p149, p150, v201, v203, v205, v192, v191, v207, v208)
				if v209 and (type(v210) == "number" and (type(v211) == "number" and (v210 == v210 and (v211 == v211 and (v210 ~= 0 or v211 ~= 0))))) then
					local v212 = v_u_3.wrapYaw(v_u_70 + v210)
					local v213 = v_u_3.clampPitch(v_u_43 + v211)
					v_u_70 = v212
					v_u_43 = v213
					return
				end
				if not v209 then
					local v214 = (v_u_22["AimPullFeed.step"] or 0) + 1
					v_u_22["AimPullFeed.step"] = v214
					if v214 <= 3 or v214 % 300 == 0 then
						warn("[FpCam] " .. "AimPullFeed.step" .. " failed: " .. tostring(v210))
					end
				end
			end
		end
	else
		v_u_148()
	end
end
local function v_u_225(p216, p217, p218, p219) -- name: tailStep
	-- upvalues: (ref) v_u_58, (ref) v_u_59, (ref) v_u_67, (ref) v_u_60, (ref) v_u_70, (ref) v_u_43, (copy) v_u_3
	local v220 = v_u_58
	local v221 = v_u_59
	if v220 == nil or (v221 == nil or v_u_67 ~= nil) then
		return
	elseif v_u_60 < p217 or (v_u_70 ~= p218 or v_u_43 ~= p219) then
		v_u_58 = nil
		v_u_59 = nil
	else
		local v222, v223, v224 = v_u_3.tailStep(v_u_70, v_u_43, v220, v221, p216)
		v_u_70 = v222
		v_u_43 = v223
		if v224 then
			v_u_58 = nil
			v_u_59 = nil
		end
	end
end
local function v_u_238(p226, p227, p228, p229) -- name: castBack
	-- upvalues: (copy) v_u_5, (copy) v_u_98, (copy) v_u_3
	local v230 = p227.Magnitude
	if v230 < 0.001 then
		return v230
	end
	local v231 = workspace.Spherecast
	local v232 = workspace
	local v233 = v_u_5.radius
	local v234 = v_u_98(p228, p229)
	local v235, v236 = pcall(v231, v232, p226, v233, p227, v234)
	local v237
	if v235 and v236 ~= nil then
		v237 = v236.Distance
	else
		v237 = nil
	end
	return v_u_3.tpDistance(v237, v230, v_u_5.minDist)
end
local function v_u_256(p239, p240, p241, p242, p243, p244, p245, p246, p247, p248) -- name: chaseFrame
	-- upvalues: (copy) v_u_3, (copy) v_u_238, (ref) v_u_28
	local v249, v250, v251 = v_u_3.tpCameraPos(p239.X, p239.Y, p239.Z, p240, p241, p242, p243, p244)
	local v252 = Vector3.new(v249, v250, v251) - p239
	local v253 = v252.Magnitude
	local v254 = v_u_238(p239, v252, p246, p247)
	if not p248 and v_u_28 ~= nil then
		v254 = v_u_3.tpRecover(v_u_28, v254, p245)
	end
	v_u_28 = v254
	local v255
	if v253 > 0.001 then
		v255 = p239 + v252.Unit * math.min(v254, v253)
	else
		v255 = p239
	end
	return CFrame.new(v255) * CFrame.fromOrientation(p241, p240, 0), (v255 - p239).Magnitude
end
local function v_u_402(p257, p258) -- name: renderFrame
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (ref) v_u_25, (ref) v_u_24, (copy) v_u_3, (ref) v_u_29, (ref) v_u_30, (ref) v_u_70, (ref) v_u_43, (ref) v_u_58, (ref) v_u_59, (ref) v_u_13, (ref) v_u_28, (ref) v_u_47, (ref) v_u_48, (copy) v_u_80, (copy) v_u_93, (ref) v_u_71, (ref) v_u_49, (copy) v_u_88, (ref) v_u_44, (ref) v_u_50, (ref) v_u_51, (ref) v_u_14, (copy) v_u_5, (copy) v_u_256, (ref) v_u_55, (ref) v_u_73, (ref) v_u_31, (ref) v_u_65, (ref) v_u_32, (ref) v_u_6, (ref) v_u_26, (ref) v_u_27, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_7, (copy) v_u_215, (copy) v_u_225, (ref) v_u_39, (ref) v_u_41, (ref) v_u_72, (ref) v_u_66, (ref) v_u_16, (ref) v_u_17, (ref) v_u_33, (ref) v_u_34, (ref) v_u_18, (ref) v_u_35, (ref) v_u_19
	if v_u_9 then
		local v259 = v_u_4
		if v259 == nil then
			return nil, nil, nil
		else
			local v260 = os.clock()
			local v261 = math.clamp(p257, 0, 0.1)
			if v_u_25 ~= 0 or v_u_24 ~= 0 then
				local v262, v263 = v_u_3.kickStep(v_u_25, v_u_24, v_u_29, v261)
				v_u_25 = v262
				v_u_24 = v263
				local v264 = v_u_25
				if math.abs(v264) < 0.001 then
					local v265 = v_u_24
					if math.abs(v265) < 0.001 then
						v_u_25 = 0
						v_u_24 = 0
					end
				end
			end
			local v266
			if type(p258) == "table" then
				local v267 = p258.mode
				v266 = type(v267) ~= "string" and "iso" or p258.mode
			else
				v266 = "iso"
			end
			local v268
			if type(p258) == "table" then
				local v269 = p258.subject
				if typeof(v269) == "Instance" then
					v268 = p258.subject
				else
					v268 = nil
				end
			else
				v268 = nil
			end
			local v270 = v_u_4
			local v_u_271
			if v270 then
				v_u_271 = v270.Character
			else
				v_u_271 = nil
			end
			local v272
			if v_u_271 == nil then
				v272 = nil
			else
				v272 = v_u_271:FindFirstChild("HumanoidRootPart")
				if not (v272 and v272:IsA("BasePart")) then
					v272 = nil
				end
			end
			local v273
			if v_u_271 == nil then
				v273 = false
			else
				v273 = v_u_271:GetAttribute("Downed") == true
			end
			local v274
			if v_u_271 == nil then
				v274 = false
			else
				v274 = v_u_271:GetAttribute("Dead") == true and true or v259:GetAttribute("RaidStatus") == "Dead"
			end
			if v272 ~= v_u_30 then
				v_u_30 = v272
				if v272 ~= nil then
					local v275 = v272.CFrame.LookVector
					local v276 = v_u_3.wrapYaw
					local v277 = -v275.X
					local v278 = -v275.Z
					v_u_70 = v276((math.atan2(v277, v278)))
					v_u_43 = 0
					v_u_58 = nil
					v_u_59 = nil
					v_u_25 = 0
					v_u_24 = 0
					v_u_13 = false
					v_u_28 = nil
					v_u_47 = nil
				end
			end
			if v274 then
				if v_u_47 == nil then
					v_u_47 = v260
					v_u_48 = v_u_70
					v_u_28 = nil
					local v279 = v_u_80("FpTouch")
					if v279 ~= nil then
						local v280 = v279.setAds
						if type(v280) == "function" then
							local v281 = v279.setAds
							pcall(v281, false)
						end
					end
				end
			else
				v_u_47 = nil
			end
			local v282 = v_u_93("fov")
			local v283 = v_u_71
			if v283 > 0 and (v260 - v_u_49 > 0.5 and v_u_88("Input", "isAiming") ~= true) then
				v_u_71 = v_u_3.blendStep(v_u_71, 0, v261, 0.2)
				v283 = v_u_71
			end
			local v284 = v_u_3.fovFor(v282, v_u_44, v283)
			local v285
			if v274 then
				if v_u_47 == nil then
					v285 = false
				else
					v285 = v260 - v_u_47 < v_u_3.DEATH_FALL
				end
			else
				v285 = v274
			end
			if v266 == "spectate" and (v268 ~= nil and (v268 ~= v272 and not v285)) then
				local v286 = v268.Parent
				local v287
				if type(p258) == "table" then
					v287 = p258.target
				else
					v287 = nil
				end
				if v287 ~= v_u_50 then
					v_u_50 = v287
					v_u_28 = nil
					if v286 then
						local v288, v289 = v_u_3.chaseAngles(v286:GetAttribute("AimYaw"), v286:GetAttribute("AimPitch"), v_u_51)
						v_u_51 = v288
						v_u_14 = v289
					end
				end
				if v286 then
					local v290, v291 = v_u_3.chaseAngles(v286:GetAttribute("AimYaw"), v286:GetAttribute("AimPitch"), v_u_51)
					v_u_51 = v_u_3.smoothAngle(v_u_51, v290, 10, v261)
					local v292 = v_u_14
					local v293 = v291 - v_u_14
					local v294 = v261 * -10
					v_u_14 = v292 + v293 * (1 - math.exp(v294))
				end
				local v295, v296, v297 = v_u_3.tpOffset(v_u_93("fpShoulder") == "left" and "left" or "right", false)
				local v298 = v268.Position
				local v299 = v_u_5.pivotUp
				local v300, v301 = v_u_256(v298 + Vector3.new(0, v299, 0), v_u_51, v_u_14, v295, v296, v297, v261, v286, v_u_271, false)
				v_u_55 = v301
				v_u_73 = v300
				v_u_31 = nil
				v_u_65 = v_u_51
				v_u_32 = v_u_3.BODY_SHOWN
				v_u_6 = v282
				if v_u_26 ~= "tp" then
					v_u_26 = "tp"
					local v302 = v_u_4
					if v302 ~= nil then
						v302:SetAttribute(v_u_27 and v_u_27.SIDE_ATTR or "ViewSide", "tp")
					end
				end
				return v300, v282, nil
			else
				v_u_50 = nil
				if v272 == nil then
					local v303 = v_u_73
					if v303 == nil then
						return nil, nil, nil
					else
						return v303, v_u_6, nil
					end
				else
					local v304
					if v_u_271 then
						v304 = v_u_271:FindFirstChild("Head")
					else
						v304 = v_u_271
					end
					local v305
					if v304 and v304:IsA("BasePart") then
						v305 = v304.Position
					else
						v305 = v272.Position + Vector3.new(0, 1.5, 0)
					end
					if v274 and v_u_47 ~= nil then
						local v306 = v260 - v_u_47
						if v306 >= v_u_3.DEATH_FALL then
							local v307 = v_u_3.deathOrbitYaw(v306)
							local v308 = v_u_3.wrapYaw(v_u_48 + v307)
							local v309 = v272.Position
							local v310 = v_u_3.DEATH_ORBIT_PIVOT_UP
							local v311 = v309 + Vector3.new(0, v310, 0)
							local v312 = v_u_256
							local v313 = v_u_3.DEATH_ORBIT_PITCH_DEG
							local v314, v315 = v312(v311, v308, -math.rad(v313), 0, 0, v_u_3.DEATH_ORBIT_DIST, v261, v_u_271, nil, false)
							v_u_55 = v315
							v_u_73 = v314
							v_u_31 = nil
							v_u_65 = v308
							v_u_32 = v_u_3.BODY_SHOWN
							v_u_6 = v282
							if v_u_26 ~= "tp" then
								v_u_26 = "tp"
								local v316 = v_u_4
								if v316 ~= nil then
									v316:SetAttribute(v_u_27 and v_u_27.SIDE_ATTR or "ViewSide", "tp")
								end
							end
							return v314, v282, nil
						end
						local v317, v318, v319 = v_u_3.deathFall(v306)
						local v320, v321, v322 = v_u_3.eyePosition(v305.X, v305.Y, v305.Z, v_u_48)
						local v323 = v321 - v317
						local v324 = Vector3.new(v320, v323, v322)
						local v325 = v324.X
						local v326 = v324.Y + 3
						local v327 = v324.Z
						local v_u_328 = Vector3.new(v325, v326, v327)
						local function v335()
							-- upvalues: (copy) v_u_328, (copy) v_u_271, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_7
							local v329 = workspace
							local v330 = v_u_328
							local v331 = Vector3.new(0, -10, 0)
							local v332 = v_u_271
							local v333 = workspace.CurrentCamera
							if v332 ~= v_u_10 or (v_u_11 ~= nil or v333 ~= v_u_12) then
								v_u_10 = v332
								v_u_11 = nil
								v_u_12 = v333
								local v334 = {}
								if v332 then
									table.insert(v334, v332)
								end
								if v333 then
									table.insert(v334, v333)
								end
								v_u_7.FilterDescendantsInstances = v334
							end
							return v329:Raycast(v330, v331, v_u_7)
						end
						local v336, v337 = pcall(v335)
						local v338
						if v336 and v337 ~= nil then
							v338 = v337.Position.Y
						else
							v338 = nil
						end
						if v338 ~= nil and v324.Y < v338 + 0.35 then
							local v339 = v324.X
							local v340 = v338 + 0.35
							local v341 = v324.Z
							v324 = Vector3.new(v339, v340, v341)
						end
						local v342 = CFrame.new(v324) * CFrame.fromOrientation(v_u_3.clampPitch(v_u_43 + v319), v_u_48, 0) * CFrame.Angles(0, 0, v318)
						v_u_73 = v342
						v_u_31 = v342
						v_u_65 = v_u_48
						v_u_32 = v_u_3.BODY_HIDDEN
						v_u_6 = v282
						if v_u_26 ~= "fp" then
							v_u_26 = "fp"
							local v343 = v_u_4
							if v343 ~= nil then
								v343:SetAttribute(v_u_27 and v_u_27.SIDE_ATTR or "ViewSide", "fp")
							end
						end
						return v342, v282, nil
					end
					local v344 = v_u_70
					local v345 = v_u_43
					v_u_215(v261, v260, v305, true)
					v_u_225(v261, v260, v344, v345)
					local v346 = v_u_80("RideCam")
					local v347
					if v346 == nil then
						v347 = false
					else
						v347 = v346.forcesTp() == true
					end
					local v348 = v_u_39 == "tp" and true or v347
					local v349 = v_u_88("Input", "isAiming") == true
					v_u_41 = v_u_3.blendStep(v_u_41, v348 and 1 or 0, v261, v_u_3.TOGGLE_TIME)
					v_u_72 = v_u_3.blendStep(v_u_72, v348 and (v349 and not (v273 or v347)) and 1 or 0, v261, v_u_3.ADS_TIME)
					local v350 = v_u_3.smooth(v_u_41) * (1 - v_u_3.smooth(v_u_72))
					local v351 = v_u_3.effectiveAction
					local v352
					if v_u_271 then
						v352 = v_u_271:GetAttribute("Action")
					else
						v352 = nil
					end
					local v353
					if v_u_4 then
						v353 = v_u_4:GetAttribute("PredAction")
					else
						v353 = nil
					end
					local v354
					if v_u_4 then
						v354 = v_u_4:GetAttribute("PredActionEnds")
					else
						v354 = nil
					end
					local v355 = v351(v352, v353, v354, os.clock())
					if v355 == "" and (v_u_271 ~= nil and (v_u_271:GetAttribute("Sneaking") ~= true and v_u_271:GetAttribute("Downed") ~= true)) then
						local v356 = v272.CFrame:PointToObjectSpace(v305)
						if v_u_3.standHead(v356.X, v356.Y, v356.Z) then
							v_u_66 = v356
						end
					elseif v_u_66 ~= nil and v_u_3.holdsEye(v355) then
						v305 = v272.CFrame:PointToWorldSpace(v_u_66)
					end
					local v357, v358, v359 = v_u_3.eyePosition(v305.X, v305.Y, v305.Z, v_u_70)
					if v_u_13 then
						local v360, v361 = v_u_3.eyeSpring(v_u_16, v_u_17, v358, v261)
						v_u_16 = v360
						v_u_17 = v361
					else
						v_u_13 = true
						v_u_16 = v358
						v_u_17 = 0
					end
					local v362 = v272.AssemblyLinearVelocity
					local v363 = v362.X
					local v364 = v362.Z
					local v365 = Vector3.new(v363, 0, v364).Magnitude
					local v366
					if v_u_271 then
						v366 = v_u_271:FindFirstChildOfClass("Humanoid")
					else
						v366 = v_u_271
					end
					local v367
					if v366 == nil then
						v367 = false
					else
						v367 = v366.FloorMaterial ~= Enum.Material.Air
					end
					if v367 then
						if v365 > 1.5 then
							v367 = not v274
						else
							v367 = false
						end
					end
					local v368 = v_u_33
					local v369 = (v367 and 1 or 0) - v_u_33
					local v370 = v261 * -10
					v_u_33 = v368 + v369 * (1 - math.exp(v370))
					v_u_34 = v_u_3.bobPhase(v_u_34, v365, v261)
					local v371
					if v_u_88("Input", "isSprinting") == true then
						v371 = v365 > 14
					else
						v371 = false
					end
					local v372, v373, v374 = v_u_3.bobOffset(v_u_34, v_u_33, v371, v_u_93("fpBob"), v283, 1 - v350)
					local v375 = v_u_24
					local v376 = v_u_3.wrapYaw(v_u_70 + math.rad(v375))
					local v377 = v_u_25
					local v378 = v_u_3.clampPitch(v_u_43 + math.rad(v377))
					local v379 = CFrame.fromOrientation(v378, v376, 0)
					local v380 = v_u_16
					local v381 = Vector3.new(v357, v380, v359) + v379.RightVector * v373 + Vector3.new(0, v372, 0)
					local v382 = CFrame.new(v381) * v379 * CFrame.Angles(0, 0, v374)
					local v383 = 99
					v_u_18 = v_u_3.blendStep(v_u_18, v_u_35 and 1 or 0, v261, v_u_3.TOGGLE_TIME)
					local v384
					if v350 > 0.001 then
						local v385, v386, v387, v388 = v_u_3.tpOffsetMix(v_u_93("fpShoulder") == "left" and "left" or "right", v273, v_u_18)
						local v389
						v389, v383 = v_u_256(v272.Position + Vector3.new(0, v388, 0), v376, v378, v385, v386, v387, v261, v_u_271, nil, false)
						v384 = v382:Lerp(v389, v350)
					else
						v_u_28 = nil
						v384 = v382
					end
					v_u_55 = v383
					local v390 = v_u_3.effectiveSide(v_u_41, v_u_72)
					v_u_32 = v_u_3.bodyLevel(v390, v383, v_u_32)
					v_u_73 = v384
					v_u_31 = v382
					v_u_65 = v_u_70
					v_u_6 = v284
					if v_u_26 ~= v390 then
						v_u_26 = v390
						local v391 = v_u_4
						if v391 ~= nil then
							v391:SetAttribute(v_u_27 and v_u_27.SIDE_ATTR or "ViewSide", v390)
						end
					end
					if v346 ~= nil and (v347 or v_u_19) then
						local v392 = v346.render
						local v393, v394, v395, v396 = pcall(v392, v261, {
							["baseFov"] = v282,
							["natural"] = {
								["cf"] = v384,
								["fov"] = v284
							}
						})
						if v393 then
							v393 = typeof(v394) == "CFrame"
						end
						v_u_19 = v393
						if v_u_19 then
							local v397, v398 = v346.aim()
							if v397 ~= nil and v398 ~= nil then
								local v399 = v_u_3.wrapYaw(v397)
								local v400 = v_u_3.clampPitch(v398)
								v_u_70 = v399
								v_u_43 = v400
							end
							v_u_32 = v_u_3.BODY_SHOWN
							v_u_73 = v394
							if type(v395) == "number" then
								v284 = v395
							end
							v_u_6 = v284
							local v401 = v_u_6
							if typeof(v396) == "CFrame" then
								return v394, v401, v396
							else
								return v394, v401, nil
							end
						end
					end
					return v384, v284, nil
				end
			end
		end
	else
		return nil, nil, nil
	end
end
local function v_u_421(p_u_403) -- name: aimPoint
	-- upvalues: (ref) v_u_20, (ref) v_u_52, (copy) v_u_80, (ref) v_u_73, (copy) v_u_4, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_7
	local v404 = os.clock()
	if v_u_20 == v404 then
		return v_u_52
	end
	v_u_20 = v404
	v_u_52 = nil
	local v405 = v_u_80("FpAim")
	if v405 ~= nil and v405.STUB ~= true then
		local v406 = v405.target
		if type(v406) == "function" then
			local v407 = v405.target
			local v408, v409 = pcall(v407, p_u_403)
			if v408 and typeof(v409) == "Vector3" then
				v_u_52 = v409
				return v409
			end
		end
	end
	local v_u_410 = v_u_73
	if v_u_410 == nil then
		return nil
	end
	local function v418()
		-- upvalues: (copy) v_u_410, (copy) p_u_403, (ref) v_u_4, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_7
		local v411 = workspace
		local v412 = v_u_410.Position
		local v413 = v_u_410.LookVector * p_u_403
		local v414 = v_u_4
		local v415
		if v414 then
			v415 = v414.Character
		else
			v415 = nil
		end
		local v416 = workspace.CurrentCamera
		if v415 ~= v_u_10 or (v_u_11 ~= nil or v416 ~= v_u_12) then
			v_u_10 = v415
			v_u_11 = nil
			v_u_12 = v416
			local v417 = {}
			if v415 then
				table.insert(v417, v415)
			end
			if v416 then
				table.insert(v417, v416)
			end
			v_u_7.FilterDescendantsInstances = v417
		end
		return v411:Raycast(v412, v413, v_u_7)
	end
	local v419, v420 = pcall(v418)
	if v419 and v420 ~= nil then
		v_u_52 = v420.Position
	else
		v_u_52 = v_u_410.Position + v_u_410.LookVector * p_u_403
	end
	return v_u_52
end
local v_u_422 = {
	["yaw"] = 0,
	["pitch"] = 0,
	["point"] = nil,
	["face"] = 0
}
local v_u_425 = {
	["step"] = function(_, _) -- name: step
		-- upvalues: (ref) v_u_9, (ref) v_u_73, (copy) v_u_422, (copy) v_u_3, (ref) v_u_70, (ref) v_u_24, (ref) v_u_43, (ref) v_u_25, (copy) v_u_421
		if not v_u_9 or v_u_73 == nil then
			return nil
		end
		local v423 = v_u_24
		v_u_422.yaw = v_u_3.wrapYaw(v_u_70 + math.rad(v423))
		local v424 = v_u_25
		v_u_422.pitch = v_u_3.clampPitch(v_u_43 + math.rad(v424))
		v_u_422.point = v_u_421(300)
		v_u_422.face = v_u_70
		return v_u_422
	end
}
local v_u_448 = {
	["modeName"] = function() -- name: modeName
		-- upvalues: (ref) v_u_26, (copy) v_u_3, (ref) v_u_41, (ref) v_u_72
		return v_u_26 or v_u_3.effectiveSide(v_u_41, v_u_72)
	end,
	["render"] = function(p426, p427) -- name: render
		-- upvalues: (copy) v_u_402
		return v_u_402(p426, p427)
	end,
	["after"] = function(p428, p429) -- name: after
		-- upvalues: (copy) v_u_80, (copy) v_u_22, (ref) v_u_61
		local v430 = v_u_80("Viewmodel")
		if v430 ~= nil then
			local v431 = v430.render
			if type(v431) == "function" then
				local v432 = v430.render
				local v433, v434 = pcall(v432, p428, p429)
				if not v433 then
					local v435 = (v_u_22["Viewmodel.render"] or 0) + 1
					v_u_22["Viewmodel.render"] = v435
					if v435 <= 3 or v435 % 300 == 0 then
						warn("[FpCam] " .. "Viewmodel.render" .. " failed: " .. tostring(v434))
					end
				end
			end
		end
		local v436 = v_u_61 and v_u_61.controllers
		if v436 then
			v436 = v_u_61.controllers.WeaponClient
		end
		if not v436 or v436._broken then
			v436 = nil
		end
		if v436 ~= nil then
			local v437 = v436.fpLaser
			if type(v437) == "function" then
				local v438 = v436.fpLaser
				local v439, v440 = pcall(v438, p428, p429)
				if not v439 then
					local v441 = (v_u_22["WeaponClient.fpLaser"] or 0) + 1
					v_u_22["WeaponClient.fpLaser"] = v441
					if v441 <= 3 or v441 % 300 == 0 then
						warn("[FpCam] " .. "WeaponClient.fpLaser" .. " failed: " .. tostring(v440))
					end
				end
			end
		end
		local v442 = v_u_80("ScopeView")
		if v442 ~= nil then
			local v443 = v442.render
			if type(v443) == "function" then
				local v444 = v442.render
				local v445, v446 = pcall(v444, p429)
				if not v445 then
					local v447 = (v_u_22["ScopeView.render"] or 0) + 1
					v_u_22["ScopeView.render"] = v447
					if v447 <= 3 or v447 % 300 == 0 then
						warn("[FpCam] " .. "ScopeView.render" .. " failed: " .. tostring(v446))
					end
				end
			end
		end
	end,
	["yaw"] = function() -- name: yaw
		-- upvalues: (ref) v_u_65
		return v_u_65
	end
}
v21.rig = v_u_448
v21.aim = v_u_425
local function v_u_466() -- name: activate
	-- upvalues: (ref) v_u_61, (ref) v_u_27, (ref) v_u_64, (ref) v_u_35, (ref) v_u_18, (ref) v_u_40, (ref) v_u_39, (copy) v_u_3, (ref) v_u_62, (ref) v_u_30, (ref) v_u_13, (ref) v_u_28, (ref) v_u_47, (ref) v_u_50, (ref) v_u_25, (ref) v_u_24, (ref) v_u_34, (ref) v_u_33, (ref) v_u_72, (ref) v_u_41, (ref) v_u_73, (ref) v_u_31, (ref) v_u_20, (copy) v_u_104, (copy) v_u_448, (copy) v_u_22, (copy) v_u_425
	if v_u_61 ~= nil then
		local function v449()
			-- upvalues: (ref) v_u_61
			return v_u_61.shared.ViewMode
		end
		local v450, v451 = pcall(v449)
		if not v450 then
			v451 = nil
		end
		v_u_27 = v451
	end
	v_u_64 = false
	v_u_35 = false
	v_u_18 = 0
	v_u_40 = os.clock()
	v_u_39 = v_u_3.sideOf(v_u_62.fpSide)
	v_u_30 = nil
	v_u_13 = false
	v_u_28 = nil
	v_u_47 = nil
	v_u_50 = nil
	v_u_25 = 0
	v_u_24 = 0
	v_u_34 = 0
	v_u_33 = 0
	v_u_72 = 0
	v_u_41 = v_u_39 == "tp" and 1 or 0
	v_u_73 = nil
	v_u_31 = nil
	v_u_20 = -1
	v_u_104()
	local v452 = v_u_61 and v_u_61.controllers
	if v452 then
		v452 = v_u_61.controllers.Camera
	end
	if not v452 or v452._broken then
		v452 = nil
	end
	if v452 ~= nil then
		local v453 = v452.setViewRig
		if type(v453) == "function" then
			local v454 = v452.setViewRig
			local v455 = v_u_448
			local v456, v457 = pcall(v454, v455)
			if not v456 then
				local v458 = (v_u_22["Camera.setViewRig"] or 0) + 1
				v_u_22["Camera.setViewRig"] = v458
				if v458 <= 3 or v458 % 300 == 0 then
					warn("[FpCam] " .. "Camera.setViewRig" .. " failed: " .. tostring(v457))
				end
			end
		end
	end
	local v459 = v_u_61 and v_u_61.controllers
	if v459 then
		v459 = v_u_61.controllers.Input
	end
	if not v459 or v459._broken then
		v459 = nil
	end
	if v459 ~= nil then
		local v460 = v459.setAimProvider
		if type(v460) == "function" then
			local v461 = v459.setAimProvider
			local v462 = v_u_425
			local v463, v464 = pcall(v461, v462)
			if not v463 then
				local v465 = (v_u_22["Input.setAimProvider"] or 0) + 1
				v_u_22["Input.setAimProvider"] = v465
				if v465 <= 3 or v465 % 300 == 0 then
					warn("[FpCam] " .. "Input.setAimProvider" .. " failed: " .. tostring(v464))
				end
			end
		end
	end
end
local function v_u_486() -- name: deactivate
	-- upvalues: (ref) v_u_68, (ref) v_u_61, (ref) v_u_62, (copy) v_u_448, (copy) v_u_120, (copy) v_u_80, (ref) v_u_53, (ref) v_u_67, (ref) v_u_37, (ref) v_u_38, (ref) v_u_58, (ref) v_u_59, (ref) v_u_25, (ref) v_u_24, (ref) v_u_71, (ref) v_u_44, (ref) v_u_73, (ref) v_u_31, (ref) v_u_32, (ref) v_u_26, (copy) v_u_4, (ref) v_u_27
	local v467 = v_u_68
	if v467 ~= nil then
		v_u_68 = nil
		local v468 = v_u_61
		if v468 ~= nil then
			v_u_62.fpSide = v467
			local v469 = v468.net.fire
			pcall(v469, "menu.op", {
				["op"] = "setting",
				["key"] = "fpSide",
				["value"] = nil,
				["value"] = v467
			})
		end
	end
	local v470 = v_u_61 and v_u_61.controllers
	if v470 then
		v470 = v_u_61.controllers.Camera
	end
	if not v470 or v470._broken then
		v470 = nil
	end
	if v470 ~= nil then
		local v471 = v470.setViewRig
		if type(v471) == "function" then
			local v472 = v470.viewRig
			if type(v472) == "function" then
				local v473 = v470.viewRig
				local v474, v475 = pcall(v473)
				if v474 and v475 == v_u_448 then
					local v476 = v470.setViewRig
					pcall(v476, nil)
				end
			end
		end
	end
	local v477 = v_u_61 and v_u_61.controllers
	if v477 then
		v477 = v_u_61.controllers.Input
	end
	if not v477 or v477._broken then
		v477 = nil
	end
	if v477 ~= nil then
		local v478 = v477.setAimProvider
		if type(v478) == "function" then
			local v479 = v477.setAimProvider
			pcall(v479, nil)
		end
	end
	v_u_120()
	local v480 = v_u_80("FpBodyHide")
	if v480 ~= nil then
		local v481 = v480.stop
		pcall(v481)
	end
	if v_u_53 == false then
		local v482 = v_u_80("Viewmodel")
		if v482 ~= nil then
			local v483 = v482.setVisible
			if type(v483) == "function" then
				local v484 = v482.setVisible
				pcall(v484, true)
			end
		end
	end
	v_u_53 = nil
	v_u_67 = nil
	v_u_37 = nil
	v_u_38 = nil
	v_u_58 = nil
	v_u_59 = nil
	v_u_25 = 0
	v_u_24 = 0
	v_u_71 = 0
	v_u_44 = nil
	v_u_73 = nil
	v_u_31 = nil
	v_u_32 = 0
	v_u_26 = nil
	local v485 = v_u_4
	if v485 ~= nil then
		v485:SetAttribute(v_u_27 and v_u_27.SIDE_ATTR or "ViewSide", nil)
	end
end
function v21.setActive(p487, p488) -- name: setActive
	-- upvalues: (ref) v_u_61, (ref) v_u_9, (copy) v_u_466, (copy) v_u_486
	if p488 ~= nil then
		v_u_61 = p488
	end
	local v489 = p487 == true
	if v489 == v_u_9 then
		return
	else
		v_u_9 = v489
		if v489 then
			v_u_466()
		else
			v_u_486()
		end
	end
end
function v21.step(p490) -- name: step
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (ref) v_u_50, (copy) v_u_117, (ref) v_u_45, (ref) v_u_46, (ref) v_u_36, (copy) v_u_2, (copy) v_u_120, (ref) v_u_68, (ref) v_u_74, (ref) v_u_61, (ref) v_u_62, (copy) v_u_88, (ref) v_u_32, (copy) v_u_3, (ref) v_u_13, (ref) v_u_28, (copy) v_u_80, (copy) v_u_22, (ref) v_u_41, (ref) v_u_72, (ref) v_u_73, (ref) v_u_53, (ref) v_u_56, (copy) v_u_104
	if v_u_9 then
		local v491 = os.clock()
		local v492 = v_u_4
		local v493
		if v492 then
			v493 = v492.Character
		else
			v493 = nil
		end
		local v494 = (v493 == nil or (v493:GetAttribute("Dead") == true or v_u_4 ~= nil and v_u_4:GetAttribute("RaidStatus") == "Dead")) and true or v_u_50 ~= nil
		if v_u_117(v494) then
			if not v_u_45 then
				v_u_45 = true
				v_u_46 = true
			end
			v_u_36 = true
			if v_u_2.MouseIconEnabled then
				v_u_2.MouseIconEnabled = false
			end
			if v_u_2.MouseBehavior ~= Enum.MouseBehavior.LockCenter then
				v_u_2.MouseBehavior = Enum.MouseBehavior.LockCenter
			end
		else
			v_u_120()
		end
		if v_u_68 ~= nil then
			local v495 = v_u_68
			if v495 ~= nil and os.clock() >= v_u_74 then
				v_u_68 = nil
				local v496 = v_u_61
				if v496 ~= nil then
					v_u_62.fpSide = v495
					local v497 = v496.net.fire
					pcall(v497, "menu.op", {
						["op"] = "setting",
						["key"] = "fpSide",
						["value"] = nil,
						["value"] = v495
					})
				end
			end
		end
		local v498 = v_u_88("Camera", "hasOverride") == true
		if v498 then
			v_u_32 = v_u_3.BODY_SHOWN
			v_u_13 = false
			v_u_28 = nil
		end
		local v499 = v_u_80("FpBodyHide")
		if v499 ~= nil then
			local v500 = v499.setLevel
			local v501 = v_u_32
			local v502, v503 = pcall(v500, v501, v493)
			if v502 then
				local v504 = v499.step
				v502, v503 = pcall(v504, p490)
			end
			if not v502 then
				local v505 = (v_u_22.FpBodyHide or 0) + 1
				v_u_22.FpBodyHide = v505
				if v505 <= 3 or v505 % 300 == 0 then
					warn("[FpCam] " .. "FpBodyHide" .. " failed: " .. tostring(v503))
				end
			end
		end
		local v506 = v_u_3.effectiveSide(v_u_41, v_u_72)
		local v507
		if v493 == nil then
			v507 = false
		else
			v507 = v493:GetAttribute("Downed") == true
		end
		local v508 = v506 == "fp" and not v494 and not (v507 or v498)
		if v508 then
			if v_u_32 >= v_u_3.BODY_HIDDEN then
				v508 = v_u_73 ~= nil
			else
				v508 = false
			end
		end
		if v508 ~= v_u_53 then
			v_u_53 = v508
			local v509 = v_u_80("Viewmodel")
			if v509 ~= nil then
				local v510 = v509.setVisible
				if type(v510) == "function" then
					local v511 = v509.setVisible
					local v512, v513 = pcall(v511, v508)
					if not v512 then
						local v514 = (v_u_22["Viewmodel.setVisible"] or 0) + 1
						v_u_22["Viewmodel.setVisible"] = v514
						if v514 <= 3 or v514 % 300 == 0 then
							warn("[FpCam] " .. "Viewmodel.setVisible" .. " failed: " .. tostring(v513))
						end
					end
				end
			end
		end
		if v491 - v_u_56 > 120 then
			v_u_104()
		end
	end
end
function v21.toggle() -- name: toggle
	-- upvalues: (copy) v_u_80, (ref) v_u_54, (copy) v_u_3, (ref) v_u_39, (ref) v_u_35, (ref) v_u_64, (ref) v_u_9, (ref) v_u_68, (ref) v_u_74
	local v515 = v_u_80("RideCam")
	if v515 == nil or v515.forcesTp() ~= true then
		local v516, v517 = v_u_3.nextView(v_u_39, v_u_35)
		local v518 = v516 ~= v_u_39
		v_u_39 = v516
		v_u_35 = v517
		v_u_64 = true
		if v_u_9 and v518 then
			v_u_68 = v_u_39
			v_u_74 = os.clock() + 1.5
		end
	else
		local v519 = os.clock()
		if v_u_54 <= v519 then
			v_u_54 = v519 + 2
			local function v520()
				-- upvalues: (ref) v_u_80
				v_u_80("HushUI").toast("Third person while in a vehicle", "warn")
			end
			pcall(v520)
		end
	end
end
function v21.side() -- name: side
	-- upvalues: (ref) v_u_39
	return v_u_39
end
function v21.effectiveSide() -- name: effectiveSide
	-- upvalues: (ref) v_u_26, (copy) v_u_3, (ref) v_u_41, (ref) v_u_72
	return v_u_26 or v_u_3.effectiveSide(v_u_41, v_u_72)
end
function v21.look() -- name: look
	-- upvalues: (ref) v_u_70, (ref) v_u_43
	return v_u_70, v_u_43
end
function v21.viewCF() -- name: viewCF
	-- upvalues: (ref) v_u_73
	return v_u_73
end
function v21.eyeCF() -- name: eyeCF
	-- upvalues: (ref) v_u_31
	return v_u_31
end
function v21.setAds(p521, p522) -- name: setAds
	-- upvalues: (ref) v_u_71, (ref) v_u_49, (ref) v_u_44
	if type(p521) == "number" and p521 == p521 then
		v_u_71 = math.clamp(p521, 0, 1)
		v_u_49 = os.clock()
	end
	if type(p522) == "number" and (p522 == p522 and p522 > 0) then
		v_u_44 = p522
	end
end
function v21.kick(p523, p524, p525) -- name: kick
	-- upvalues: (ref) v_u_25, (ref) v_u_24, (copy) v_u_3, (ref) v_u_29
	if type(p523) == "number" and (type(p524) == "number" and (p523 == p523 and p524 == p524)) then
		local v526, v527 = v_u_3.kickAdd(v_u_25, v_u_24, p523, p524)
		v_u_25 = v526
		v_u_24 = v527
		v_u_29 = (type(p525) ~= "number" or p525 <= 0) and 10 or p525
	end
end
function v21.lockLook(p528, p529) -- name: lockLook
	-- upvalues: (ref) v_u_67, (ref) v_u_37, (ref) v_u_38, (ref) v_u_58, (ref) v_u_59, (ref) v_u_60, (ref) v_u_23
	if type(p528) == "function" then
		v_u_67 = p528
		v_u_23 = (type(p529) ~= "number" or p529 <= 0) and 0 or os.clock() + p529
		v_u_37 = nil
		v_u_38 = nil
		v_u_58 = nil
		v_u_59 = nil
	else
		if v_u_67 ~= nil and (v_u_37 ~= nil and v_u_38 ~= nil) then
			local v530 = v_u_37
			local v531 = v_u_38
			local v532 = os.clock() + 0.6
			v_u_58 = v530
			v_u_59 = v531
			v_u_60 = v532
		end
		v_u_67 = nil
		v_u_23 = 0
		v_u_37 = nil
		v_u_38 = nil
	end
end
function v21.isMouseLocked() -- name: isMouseLocked
	-- upvalues: (ref) v_u_45
	return v_u_45
end
function v21.baseFov() -- name: baseFov
	-- upvalues: (copy) v_u_93
	return v_u_93("fov")
end
function v21.fov() -- name: fov
	-- upvalues: (ref) v_u_6
	return v_u_6
end
function v21.setting(p533) -- name: setting
	-- upvalues: (copy) v_u_8, (copy) v_u_93
	if v_u_8[p533] == nil then
		return nil
	else
		return v_u_93(p533)
	end
end
function v21.bodyLevel() -- name: bodyLevel
	-- upvalues: (ref) v_u_32
	return v_u_32
end
function v21.facts() -- name: facts
	-- upvalues: (ref) v_u_9, (ref) v_u_39, (copy) v_u_3, (ref) v_u_41, (ref) v_u_72, (ref) v_u_70, (ref) v_u_43, (ref) v_u_6, (ref) v_u_71, (ref) v_u_25, (ref) v_u_24, (ref) v_u_45, (ref) v_u_32, (ref) v_u_55, (ref) v_u_47, (ref) v_u_50, (ref) v_u_56
	local v534 = {
		["active"] = v_u_9,
		["side"] = v_u_39,
		["effective"] = v_u_3.effectiveSide(v_u_41, v_u_72)
	}
	local v535 = v_u_70
	v534.yawDeg = math.deg(v535)
	local v536 = v_u_43
	v534.pitchDeg = math.deg(v536)
	v534.fov = v_u_6
	v534.ads = v_u_71
	v534.tpAds = v_u_72
	v534.toggle = v_u_41
	v534.kickP = v_u_25
	v534.kickY = v_u_24
	v534.mouse = v_u_45
	v534.body = v_u_32
	v534.camDist = v_u_55
	v534.dead = v_u_47 ~= nil
	v534.spectating = v_u_50 ~= nil
	v534.stored = v_u_56 > 0
	return v534
end
return v21