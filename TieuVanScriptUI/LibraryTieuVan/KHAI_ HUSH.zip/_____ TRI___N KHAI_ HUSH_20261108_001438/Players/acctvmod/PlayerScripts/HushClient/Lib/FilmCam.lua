-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmCam

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = {
	["mode"] = "game",
	["fov"] = 50,
	["roll"] = 0,
	["shake"] = 0,
	["smooth"] = 0.35,
	["speed"] = 24,
	["orbitAuto"] = 8,
	["orbitRadius"] = 18,
	["orbitPitch"] = 18,
	["orbitHeight"] = 1.5,
	["follow"] = "shoulder",
	["dollyTime"] = 8,
	["dollyLoop"] = false
}
v_u_3.state = v_u_5
local v_u_6 = nil
local v_u_7 = Vector3.new(0, 0, 0)
local v_u_8 = 0
local v_u_9 = 0
local v_u_10 = 0
local v_u_11 = nil
local v_u_12 = 50
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = {}
local v_u_16 = false
local v_u_17 = 0
local v_u_18 = {
	["shoulder"] = {
		["back"] = 11,
		["up"] = 2.4,
		["side"] = 2.8,
		["lookUp"] = 1.8,
		["lookAhead"] = 14
	},
	["low"] = {
		["back"] = 9,
		["up"] = -1.8,
		["side"] = -1.6,
		["lookUp"] = 2.2,
		["lookAhead"] = 2
	},
	["top"] = {
		["back"] = 0.01,
		["up"] = 34,
		["side"] = 0,
		["lookUp"] = 0,
		["lookAhead"] = 0,
		["top"] = true
	}
}
v_u_3.FOLLOW = { "shoulder", "low", "top" }
function v_u_3.mode() -- name: mode
	-- upvalues: (copy) v_u_5
	return v_u_5.mode
end
function v_u_3.setMode(p19) -- name: setMode
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_6, (copy) v_u_4, (copy) v_u_5, (ref) v_u_10, (ref) v_u_16, (ref) v_u_17, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
	if p19 == "game" or (p19 == "free" or (p19 == "orbit" or (p19 == "follow" or p19 == "dolly"))) then
		local v20 = workspace.CurrentCamera
		local v21
		if v20 then
			v21 = v20.CFrame
		else
			v21 = CFrame.new()
		end
		if p19 == "free" then
			v_u_7 = v21.Position
			local v22 = v21.LookVector
			local v23 = -v22.X
			local v24 = -v22.Z
			local v25 = math.atan2(v23, v24)
			local v26 = v22.Y
			local v27 = math.clamp(v26, -1, 1)
			local v28 = math.asin(v27)
			v_u_8 = v25
			v_u_9 = v28
		elseif p19 == "orbit" then
			local v29 = v21.Position
			local v30
			if v_u_6 then
				v30 = v_u_6
			else
				local v31 = v_u_4.Character
				if v31 then
					v31 = v31:FindFirstChild("HumanoidRootPart")
				end
				if not (v31 and v31:IsA("BasePart")) then
					v31 = nil
				end
				if v31 then
					local v32 = v31.Position
					local v33 = v_u_5.orbitHeight
					v30 = v32 + Vector3.new(0, v33, 0)
				else
					local v34 = workspace.CurrentCamera
					local v35
					if v34 then
						v35 = v34.CFrame
					else
						v35 = CFrame.new()
					end
					local v36 = v35.Position
					local v37 = workspace.CurrentCamera
					local v38
					if v37 then
						v38 = v37.CFrame
					else
						v38 = CFrame.new()
					end
					v30 = v36 + v38.LookVector * 20
				end
			end
			local v39 = v29 - v30
			local v40 = v39.X
			local v41 = v39.Z
			v_u_10 = math.atan2(v40, v41)
		elseif p19 == "dolly" then
			v_u_16 = false
			v_u_17 = 0
		end
		if v_u_5.mode == "game" and p19 ~= "game" then
			v_u_11 = v21
			v_u_12 = workspace.CurrentCamera and workspace.CurrentCamera.FieldOfView or v_u_5.fov
			v_u_13 = nil
			v_u_14 = nil
		end
		v_u_5.mode = p19
		v_u_4:SetAttribute("FilmCamMode", p19)
	end
end
function v_u_3.set(p42, p43) -- name: set
	-- upvalues: (copy) v_u_5, (ref) v_u_13, (ref) v_u_14
	v_u_5[p42] = p43
	if p42 == "follow" then
		v_u_13 = nil
		v_u_14 = nil
	end
end
function v_u_3.get(p44) -- name: get
	-- upvalues: (copy) v_u_5
	return v_u_5[p44]
end
function v_u_3.setPoint(p45) -- name: setPoint
	-- upvalues: (ref) v_u_6
	v_u_6 = p45
end
function v_u_3.point() -- name: point
	-- upvalues: (ref) v_u_6
	return v_u_6
end
function v_u_3.addKey() -- name: addKey
	-- upvalues: (ref) v_u_15, (copy) v_u_5, (ref) v_u_11
	if #v_u_15 >= 6 then
		return nil
	end
	local v46
	if v_u_5.mode == "game" then
		local v47 = workspace.CurrentCamera
		if v47 then
			v46 = v47.CFrame
		else
			v46 = CFrame.new()
		end
	else
		v46 = v_u_11
		if not v46 then
			local v48 = workspace.CurrentCamera
			if v48 then
				v46 = v48.CFrame
			else
				v46 = CFrame.new()
			end
		end
	end
	local v49
	if v_u_5.mode == "game" then
		v49 = workspace.CurrentCamera and workspace.CurrentCamera.FieldOfView or v_u_5.fov
	else
		v49 = v_u_5.fov
	end
	local v50 = v_u_15
	table.insert(v50, {
		["cf"] = v46,
		["fov"] = v49
	})
	return #v_u_15
end
function v_u_3.removeKey(p51) -- name: removeKey
	-- upvalues: (ref) v_u_15
	if v_u_15[p51] then
		table.remove(v_u_15, p51)
	end
end
function v_u_3.clearKeys() -- name: clearKeys
	-- upvalues: (ref) v_u_15, (ref) v_u_16
	v_u_15 = {}
	v_u_16 = false
end
function v_u_3.keys() -- name: keys
	-- upvalues: (ref) v_u_15
	return #v_u_15
end
function v_u_3.play(p52) -- name: play
	-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_17, (copy) v_u_5, (copy) v_u_3
	if p52 == nil then
		p52 = not v_u_16
	end
	if not p52 or #v_u_15 >= 2 then
		v_u_16 = p52 == true
		v_u_17 = 0
		if v_u_16 and v_u_5.mode ~= "dolly" then
			v_u_3.setMode("dolly")
			v_u_16 = true
		end
	end
end
function v_u_3.playing() -- name: playing
	-- upvalues: (ref) v_u_16
	return v_u_16
end
function v_u_3.progress() -- name: progress
	-- upvalues: (copy) v_u_5, (ref) v_u_17
	if v_u_5.dollyTime <= 0 then
		return 0
	end
	local v53 = v_u_17 / v_u_5.dollyTime
	return math.clamp(v53, 0, 1)
end
local function v_u_79(p54) -- name: dollyAt
	-- upvalues: (ref) v_u_15, (copy) v_u_5
	local v55 = #v_u_15
	if v55 == 0 then
		local v56 = workspace.CurrentCamera
		local v57
		if v56 then
			v57 = v56.CFrame
		else
			v57 = CFrame.new()
		end
		return v57, v_u_5.fov
	end
	if v55 == 1 then
		return v_u_15[1].cf, v_u_15[1].fov
	end
	local v58 = p54 * p54 * (3 - p54 * 2) * (v55 - 1)
	local v59 = math.floor(v58) + 1
	local v60 = v55 - 1
	local v61 = math.clamp(v59, 1, v60)
	local v62 = v58 - (v61 - 1)
	local v63 = v_u_15
	local v64 = v61 - 1
	local v65 = v63[math.max(1, v64)]
	local v66 = v_u_15[v61]
	local v67 = v_u_15[v61 + 1]
	local v68 = v_u_15
	local v69 = v61 + 2
	local v70 = v68[math.min(v55, v69)]
	local v71 = v65.cf.Position
	local v72 = v66.cf.Position
	local v73 = v67.cf.Position
	local v74 = v70.cf.Position
	local v75 = v62 * v62
	local v76 = v62 * v62 * v62
	local v77 = (v72 * 2 + (-v71 + v73) * v62 + (v71 * 2 - v72 * 5 + v73 * 4 - v74) * v75 + (-v71 + v72 * 3 - v73 * 3 + v74) * v76) * 0.5
	local v78 = v66.cf.Rotation:Lerp(v67.cf.Rotation, v62)
	return CFrame.new(v77) * v78, v66.fov + (v67.fov - v66.fov) * v62
end
function v_u_3.wheel(p80) -- name: wheel
	-- upvalues: (copy) v_u_5
	if v_u_5.mode == "free" then
		local v81 = v_u_5
		local v82 = v_u_5.speed * (p80 > 0 and 1.2 or 0.8333333333333334)
		v81.speed = math.clamp(v82, 2, 200)
	elseif v_u_5.mode == "orbit" then
		local v83 = v_u_5
		local v84 = v_u_5.orbitRadius * (p80 > 0 and 0.8928571428571428 or 1.12)
		v83.orbitRadius = math.clamp(v84, 3, 150)
	end
end
function v_u_3.look(p85, p86) -- name: look
	-- upvalues: (copy) v_u_5, (ref) v_u_8, (ref) v_u_9
	if v_u_5.mode == "free" then
		local v87 = v_u_5.fov / 60
		local v88 = math.clamp(v87, 0.25, 1.5) * 0.003839724354387525
		v_u_8 = v_u_8 - p85 * v88
		local v89 = v_u_9 - p86 * v88
		v_u_9 = math.clamp(v89, -1.53588974175501, 1.53588974175501)
	end
end
local v_u_90 = {
	["game"] = {
		["mode"] = "game"
	},
	["iso"] = {
		["mode"] = "game"
	},
	["free"] = {
		["mode"] = "free"
	},
	["shoulder"] = {
		["mode"] = "follow",
		["follow"] = "shoulder",
		["fov"] = 55
	},
	["follow"] = {
		["mode"] = "follow",
		["follow"] = "shoulder",
		["fov"] = 55
	},
	["chase"] = {
		["mode"] = "follow",
		["follow"] = "shoulder",
		["fov"] = 60
	},
	["hero"] = {
		["mode"] = "follow",
		["follow"] = "low",
		["fov"] = 45
	},
	["low"] = {
		["mode"] = "follow",
		["follow"] = "low",
		["fov"] = 45
	},
	["lowangle"] = {
		["mode"] = "follow",
		["follow"] = "low",
		["fov"] = 45
	},
	["low_angle"] = {
		["mode"] = "follow",
		["follow"] = "low",
		["fov"] = 45
	},
	["top"] = {
		["mode"] = "follow",
		["follow"] = "top",
		["fov"] = 50
	},
	["topdown"] = {
		["mode"] = "follow",
		["follow"] = "top",
		["fov"] = 50
	},
	["top_down"] = {
		["mode"] = "follow",
		["follow"] = "top",
		["fov"] = 50
	},
	["orbit"] = {
		["mode"] = "orbit",
		["fov"] = 45,
		["auto"] = 8,
		["radius"] = 18,
		["pitch"] = 18
	},
	["orbit_slow"] = {
		["mode"] = "orbit",
		["fov"] = 40,
		["auto"] = 4,
		["radius"] = 22,
		["pitch"] = 14
	},
	["orbit_wide"] = {
		["mode"] = "orbit",
		["fov"] = 50,
		["auto"] = 5,
		["radius"] = 40,
		["pitch"] = 28
	},
	["wide"] = {
		["mode"] = "orbit",
		["fov"] = 50,
		["auto"] = 5,
		["radius"] = 40,
		["pitch"] = 28
	},
	["closeup"] = {
		["mode"] = "orbit",
		["fov"] = 30,
		["auto"] = 6,
		["radius"] = 9,
		["pitch"] = 8
	},
	["close"] = {
		["mode"] = "orbit",
		["fov"] = 30,
		["auto"] = 6,
		["radius"] = 9,
		["pitch"] = 8
	},
	["low_track"] = {
		["mode"] = "follow",
		["follow"] = "low",
		["fov"] = 45
	},
	["over_shoulder"] = {
		["mode"] = "follow",
		["follow"] = "shoulder",
		["fov"] = 55
	},
	["low_front"] = {
		["mode"] = "orbit",
		["fov"] = 40,
		["auto"] = 0,
		["radius"] = 12,
		["pitch"] = 4,
		["front"] = true
	},
	["front"] = {
		["mode"] = "orbit",
		["fov"] = 40,
		["auto"] = 0,
		["radius"] = 12,
		["pitch"] = 4,
		["front"] = true
	},
	["heli_wide"] = {
		["mode"] = "orbit",
		["fov"] = 50,
		["auto"] = 3,
		["radius"] = 70,
		["pitch"] = 32
	},
	["wide_static"] = {
		["mode"] = "orbit",
		["fov"] = 50,
		["auto"] = 0,
		["radius"] = 45,
		["pitch"] = 22,
		["front"] = true
	},
	["static"] = {
		["mode"] = "orbit",
		["fov"] = 45,
		["auto"] = 0,
		["radius"] = 25,
		["pitch"] = 18,
		["front"] = true
	}
}
v_u_3.PRESETS = v_u_90
function v_u_3.applyPreset(p91) -- name: applyPreset
	-- upvalues: (copy) v_u_90, (copy) v_u_3, (copy) v_u_5, (ref) v_u_6, (copy) v_u_4, (ref) v_u_10
	local v92 = nil
	local v93 = "?"
	if type(p91) == "string" then
		v93 = string.lower(p91)
		v92 = v_u_90[v93]
	elseif type(p91) == "table" then
		local v94 = p91.preset
		local v95
		if type(v94) == "string" then
			v95 = v_u_90[string.lower(p91.preset)] or nil
		else
			v95 = nil
		end
		v92 = table.clone(v95 or {})
		for v96, v97 in p91 do
			v92[v96] = v97
		end
		local v98 = p91.preset or (p91.mode or "custom")
		v93 = tostring(v98)
		local v99 = v92.mode
		if type(v99) ~= "string" then
			v92 = nil
		end
	end
	if not v92 then
		return nil
	end
	if v92.follow then
		v_u_3.set("follow", v92.follow)
	end
	local v100 = v92.fov
	if type(v100) == "number" then
		local v101 = v_u_5
		local v102 = v92.fov
		v101.fov = math.clamp(v102, 10, 90)
	end
	local v103 = v92.auto
	if type(v103) == "number" then
		v_u_5.orbitAuto = v92.auto
	end
	local v104 = v92.radius
	if type(v104) == "number" then
		v_u_5.orbitRadius = v92.radius
	end
	local v105 = v92.pitch
	if type(v105) == "number" then
		v_u_5.orbitPitch = v92.pitch
	end
	local v106 = v92.point
	if typeof(v106) == "Vector3" then
		v_u_6 = v92.point
	end
	v_u_3.setMode(v92.mode)
	if v92.mode == "orbit" and v92.front then
		local v107 = v_u_4.Character
		if v107 then
			v107 = v107:FindFirstChild("HumanoidRootPart")
		end
		if not (v107 and v107:IsA("BasePart")) then
			v107 = nil
		end
		if v107 then
			local v108 = v107.CFrame.LookVector
			local v109 = v108.X
			local v110 = v108.Z
			v_u_10 = math.atan2(v109, v110)
		end
	end
	return v93
end
local function v_u_169(p111) -- name: rawFrame
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (ref) v_u_9, (ref) v_u_8, (ref) v_u_7, (ref) v_u_10, (ref) v_u_6, (copy) v_u_4, (copy) v_u_18, (ref) v_u_14, (ref) v_u_13, (ref) v_u_15, (ref) v_u_11, (ref) v_u_16, (ref) v_u_17, (copy) v_u_79
	local v112 = v_u_5.mode
	if v112 == "free" then
		local v113 = v_u_2:GetFocusedTextBox() ~= nil
		local v114 = CFrame.fromOrientation(v_u_9, v_u_8, 0)
		if not v113 then
			local v115 = Vector3.new(0, 0, 0)
			if v_u_2:IsKeyDown(Enum.KeyCode.W) then
				v115 = v115 + Vector3.new(0, 0, -1)
			end
			if v_u_2:IsKeyDown(Enum.KeyCode.S) then
				v115 = v115 + Vector3.new(0, 0, 1)
			end
			if v_u_2:IsKeyDown(Enum.KeyCode.A) then
				v115 = v115 + Vector3.new(-1, 0, 0)
			end
			if v_u_2:IsKeyDown(Enum.KeyCode.D) then
				v115 = v115 + Vector3.new(1, 0, 0)
			end
			local v116 = 0
			if v_u_2:IsKeyDown(Enum.KeyCode.E) then
				v116 = v116 + 1
			end
			if v_u_2:IsKeyDown(Enum.KeyCode.Q) then
				v116 = v116 - 1
			end
			local v117 = v_u_5.speed
			if v_u_2:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_2:IsKeyDown(Enum.KeyCode.RightShift) then
				v117 = v117 * 3
			end
			if v_u_2:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_2:IsKeyDown(Enum.KeyCode.RightControl) then
				v117 = v117 * 0.3
			end
			if v115.Magnitude > 0 then
				v_u_7 = v_u_7 + v114:VectorToWorldSpace(v115.Unit) * v117 * p111
			end
			local v118 = v_u_7
			local v119 = v116 * v117 * p111
			v_u_7 = v118 + Vector3.new(0, v119, 0)
		end
		return CFrame.new(v_u_7) * v114, v_u_5.fov
	elseif v112 == "orbit" then
		local v120 = v_u_10
		local v121 = v_u_5.orbitAuto
		v_u_10 = v120 + math.rad(v121) * p111
		local v122
		if v_u_6 then
			v122 = v_u_6
		else
			local v123 = v_u_4.Character
			if v123 then
				v123 = v123:FindFirstChild("HumanoidRootPart")
			end
			if not (v123 and v123:IsA("BasePart")) then
				v123 = nil
			end
			if v123 then
				local v124 = v123.Position
				local v125 = v_u_5.orbitHeight
				v122 = v124 + Vector3.new(0, v125, 0)
			else
				local v126 = workspace.CurrentCamera
				local v127
				if v126 then
					v127 = v126.CFrame
				else
					v127 = CFrame.new()
				end
				local v128 = v127.Position
				local v129 = workspace.CurrentCamera
				local v130
				if v129 then
					v130 = v129.CFrame
				else
					v130 = CFrame.new()
				end
				v122 = v128 + v130.LookVector * 20
			end
		end
		local v131 = v_u_5.orbitPitch
		local v132 = math.rad(v131)
		local v133 = v_u_10
		local v134 = math.sin(v133) * math.cos(v132)
		local v135 = math.sin(v132)
		local v136 = v_u_10
		local v137 = math.cos(v136) * math.cos(v132)
		local v138 = Vector3.new(v134, v135, v137) * v_u_5.orbitRadius
		return CFrame.lookAt(v122 + v138, v122), v_u_5.fov
	elseif v112 == "follow" then
		local v139 = v_u_4.Character
		if v139 then
			v139 = v139:FindFirstChild("HumanoidRootPart")
		end
		if not (v139 and v139:IsA("BasePart")) then
			v139 = nil
		end
		if v139 then
			local v140 = v_u_18[v_u_5.follow] or v_u_18.shoulder
			local v141 = v139.CFrame.LookVector
			local v142 = v141.X
			local v143 = v141.Z
			local v144 = Vector3.new(v142, 0, v143)
			local v145 = (v144.Magnitude < 0.01 and Vector3.new(0, 0, -1) or v144).Unit
			local v146 = -p111 * 3.2
			local v147 = 1 - math.exp(v146)
			local v148
			if v_u_14 then
				v148 = v_u_14:Lerp(v145, v147)
			else
				v148 = v145
			end
			v_u_14 = v148
			local v149 = v_u_14
			if v149.Magnitude >= 0.01 then
				v145 = v149
			end
			local v150 = v145.Unit
			local v151 = -v150.Z
			local v152 = v150.X
			local v153 = Vector3.new(v151, 0, v152)
			local v154 = v139.Position
			local v155
			if v140.top then
				local v156 = v140.up
				v155 = v154 + Vector3.new(0, v156, 0)
			else
				local v157 = v154 - v150 * v140.back
				local v158 = v140.up
				v155 = v157 + Vector3.new(0, v158, 0) + v153 * v140.side
				local v159 = v140.lookUp
				v154 = v154 + Vector3.new(0, v159, 0) + v150 * v140.lookAhead
			end
			local v160 = -p111 * 6
			local v161 = 1 - math.exp(v160)
			if v_u_13 then
				v155 = v_u_13:Lerp(v155, v161)
			end
			v_u_13 = v155
			local v162 = v_u_13
			if v140.top then
				return CFrame.lookAt(v162, v154, v150), v_u_5.fov
			else
				return CFrame.lookAt(v162, v154), v_u_5.fov
			end
		else
			return nil, v_u_5.fov
		end
	else
		if v112 ~= "dolly" then
			return nil, v_u_5.fov
		end
		if #v_u_15 == 0 then
			local v163 = v_u_11
			if not v163 then
				local v164 = workspace.CurrentCamera
				if v164 then
					v163 = v164.CFrame
				else
					v163 = CFrame.new()
				end
			end
			return v163, v_u_5.fov
		end
		if v_u_16 then
			v_u_17 = v_u_17 + p111
			if v_u_17 >= v_u_5.dollyTime then
				if v_u_5.dollyLoop then
					v_u_17 = 0
				else
					v_u_17 = v_u_5.dollyTime
					v_u_16 = false
				end
			end
		end
		local v165
		if v_u_5.dollyTime > 0 then
			local v166 = v_u_17 / v_u_5.dollyTime
			v165 = math.clamp(v166, 0, 1)
		else
			v165 = 1
		end
		local v167, v168 = v_u_79(v165)
		return v167, v168
	end
end
local function v_u_177(p170) -- name: shakeRot
	-- upvalues: (copy) v_u_5
	local v171 = v_u_5.shake
	if v171 <= 0 then
		return CFrame.identity
	end
	local v172 = p170 * 1.15
	local v173 = math.noise(v172, 3.1, 0) + 0.5 * math.noise(v172 * 2.3, 7.7, 0)
	local v174 = math.noise(v172, 11.4, 0) + 0.5 * math.noise(v172 * 2.1, 5.3, 0)
	local v175 = math.noise(v172 * 0.8, 19.9, 0)
	local v176 = 0.027925268031909273 * v171
	return CFrame.Angles(v173 * v176, v174 * v176, v175 * v176 * 0.6)
end
function v_u_3.render(p178) -- name: render
	-- upvalues: (copy) v_u_169, (copy) v_u_5, (ref) v_u_11, (ref) v_u_12, (copy) v_u_177
	local v179 = math.clamp(p178, 0, 0.1)
	local v180, v181 = v_u_169(v179)
	if not v180 then
		return nil, nil
	end
	local v182 = v_u_5.smooth
	local v183 = (1 - math.clamp(v182, 0, 1)) ^ 2 * 40 + 2
	local v184 = -v179 * v183
	local v185 = 1 - math.exp(v184)
	if v_u_5.mode == "dolly" or not v_u_11 then
		v_u_11 = v180
		v_u_12 = v181
	else
		v_u_11 = v_u_11:Lerp(v180, v185)
		v_u_12 = v_u_12 + (v181 - v_u_12) * v185
	end
	local v186 = v_u_11
	local v187 = CFrame.Angles
	local v188 = v_u_5.roll
	return v186 * v187(0, 0, (math.rad(v188))) * v_u_177(os.clock()), v_u_12
end
function v_u_3.placeFree(p189, p190, p191) -- name: placeFree
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_5, (ref) v_u_11, (ref) v_u_12
	v_u_7 = p189.Position
	local v192 = p189.LookVector
	local v193 = -v192.X
	local v194 = -v192.Z
	local v195 = math.atan2(v193, v194)
	local v196 = v192.Y
	local v197 = math.clamp(v196, -1, 1)
	local v198 = math.asin(v197)
	v_u_8 = v195
	v_u_9 = v198
	if type(p190) == "number" then
		v_u_5.fov = math.clamp(p190, 10, 90)
	end
	v_u_5.roll = type(p191) ~= "number" and 0 or p191
	local v199 = CFrame.fromOrientation(v_u_9, v_u_8, 0)
	v_u_11 = CFrame.new(v_u_7) * v199
	v_u_12 = v_u_5.fov
end
function v_u_3.lastCFrame() -- name: lastCFrame
	-- upvalues: (ref) v_u_11
	local v200 = v_u_11
	if not v200 then
		local v201 = workspace.CurrentCamera
		if v201 then
			return v201.CFrame
		end
		v200 = CFrame.new()
	end
	return v200
end
function v_u_3.reset() -- name: reset
	-- upvalues: (ref) v_u_16, (ref) v_u_6, (ref) v_u_11, (ref) v_u_13, (ref) v_u_14, (copy) v_u_5, (copy) v_u_4
	v_u_16 = false
	v_u_6 = nil
	v_u_11 = nil
	v_u_13 = nil
	v_u_14 = nil
	v_u_5.mode = "game"
	v_u_4:SetAttribute("FilmCamMode", "game")
end
return v_u_3