-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuClanHome

return {
	["overview"] = function(p1, p2) -- name: overview
		return p1.lib("MenuClanOverview").mount(p1, p2)
	end,
	["members"] = function(p_u_3, p4) -- name: members
		local v_u_5 = p_u_3.UI
		local v_u_6 = p_u_3.Theme
		local v_u_7 = p_u_3.C
		local v_u_8 = p_u_3.Kit
		local v_u_9 = p_u_3.U
		local v_u_10 = p_u_3.M
		local v_u_11 = p_u_3.m
		local v_u_12 = p_u_3.lib("MenuClanPlan")
		local v_u_13 = p_u_3.lib("MenuClanLook")
		local v_u_14 = {}
		local v_u_15 = true
		local v_u_16 = nil
		local v_u_17 = false
		local v_u_18 = false
		local v_u_19 = {}
		local v_u_20 = v_u_6.touch(44)
		local v_u_21 = v_u_11.kind == "phone"
		local v_u_22 = v_u_9.status(p4, {
			["name"] = "Msg",
			["text"] = "",
			["style"] = "small",
			["size"] = nil,
			["visible"] = false,
			["size"] = UDim2.new(1, 0, 0, 20)
		})
		local v_u_23 = 24
		local v_u_24
		if v_u_11.twoCol then
			v_u_24 = v_u_11.listW
		else
			v_u_24 = v_u_11.inner
		end
		local v_u_25 = v_u_9.frame(p4, "ListHolder", UDim2.new(0, v_u_24, 1, -v_u_23), UDim2.fromOffset(0, v_u_23))
		local v_u_26 = v_u_5.list({
			["parent"] = nil,
			["name"] = "List",
			["size"] = nil,
			["gap"] = 4,
			["padding"] = nil,
			["parent"] = v_u_25,
			["size"] = UDim2.new(1, 0, 1, -(v_u_20 + 6)),
			["padding"] = {
				0,
				6,
				0,
				8
			}
		})
		local v_u_27 = v_u_9.frame(v_u_25, "Bar", UDim2.new(1, 0, 0, v_u_20), UDim2.new(0, 0, 1, -v_u_20))
		local v_u_28
		if v_u_11.twoCol then
			v_u_28 = v_u_11.detailW
		else
			v_u_28 = v_u_11.inner
		end
		local v_u_29 = v_u_9.frame(p4, "Detail", UDim2.new(0, v_u_28, 1, -v_u_23), UDim2.fromOffset(not v_u_11.twoCol and 0 or v_u_24 + v_u_11.colGap, v_u_23))
		local function v_u_34(p30) -- name: memberOf
			-- upvalues: (copy) p_u_3
			local v31 = p_u_3.clan()
			for _, v32 in v31 and v31.members or {} do
				local v33 = v32.uid
				if tostring(v33) ~= p30 then
					continue
				end
				return v32
			end
			return nil
		end
		local function v_u_38() -- name: pickedUids
			-- upvalues: (ref) v_u_19, (copy) v_u_34
			local v35 = {}
			for v36, v37 in v_u_19 do
				if not (v37 and v_u_34(v36)) then
					continue
				end
				table.insert(v35, v36)
			end
			table.sort(v35)
			return v35
		end
		local function v_u_51(p_u_39, p40, p_u_41) -- name: run
			-- upvalues: (ref) v_u_22, (copy) p_u_3, (ref) v_u_15, (copy) v_u_10, (ref) v_u_19, (ref) v_u_18, (ref) v_u_16, (ref) v_u_17
			if p_u_41 then
				p_u_41.busy(true, "...")
			end
			v_u_22.set("", nil)
			p_u_3.send(p_u_39, p40, function(p42, p43, p44, p45)
				-- upvalues: (ref) v_u_15, (copy) p_u_41, (ref) v_u_10, (ref) v_u_22, (ref) v_u_19, (ref) v_u_18, (copy) p_u_39, (ref) v_u_16, (ref) v_u_17
				if v_u_15 then
					if p_u_41 then
						local v46 = p_u_41.busy
						pcall(v46, false)
					end
					local v47 = nil
					local v48
					if type(p44) == "table" then
						v48 = p44.results
					else
						v48 = nil
					end
					if type(v48) == "table" then
						for _, v49 in v48 do
							if type(v49) ~= "table" or v49.ok == true then
								continue
							end
							local v50 = v49.code
							if type(v50) ~= "string" then
								continue
							end
							v47 = v_u_10.text(v49.code)
						end
					end
					if p42 then
						if v47 then
							v_u_22.set(v47, "warn")
						end
					else
						v_u_22.set(v_u_10.reasonFor(p45 or {
							["msg"] = p43,
							["data"] = p44
						}), "danger")
					end
					if p42 then
						v_u_19 = {}
						v_u_18 = false
						if p_u_39 == "clanKick" then
							v_u_16 = nil
							v_u_17 = false
						end
					end
				end
			end, 25)
		end
		local function v_u_53() -- name: applyTop
			-- upvalues: (ref) v_u_22, (ref) v_u_23, (copy) v_u_25, (copy) v_u_24, (copy) v_u_29, (copy) v_u_11, (copy) v_u_28
			local v52 = v_u_22.lbl.Visible and 24 or 0
			if v52 ~= v_u_23 then
				v_u_23 = v52
				v_u_25.Position = UDim2.fromOffset(0, v_u_23)
				v_u_25.Size = UDim2.new(0, v_u_24, 1, -v_u_23)
				v_u_29.Position = UDim2.fromOffset(not v_u_11.twoCol and 0 or v_u_24 + v_u_11.colGap, v_u_23)
				v_u_29.Size = UDim2.new(0, v_u_28, 1, -v_u_23)
			end
		end
		local function v_u_128() -- name: drawDetail
			-- upvalues: (copy) v_u_8, (copy) v_u_29, (copy) p_u_3, (ref) v_u_16, (copy) v_u_34, (copy) v_u_11, (copy) v_u_9, (copy) v_u_28, (copy) v_u_7, (copy) v_u_13, (copy) v_u_12, (copy) v_u_5, (ref) v_u_17, (copy) v_u_14, (copy) v_u_10, (ref) v_u_22, (ref) v_u_15, (ref) v_u_19, (ref) v_u_18, (copy) v_u_51
			v_u_8.clear(v_u_29)
			local v54 = p_u_3.clan()
			local v_u_55
			if v_u_16 then
				v_u_55 = v_u_34(v_u_16)
			else
				v_u_55 = nil
			end
			if v54 and v_u_55 then
				local v56 = v_u_11.kind == "phone"
				local v57 = v_u_13.rankChipText(v54, v_u_55.rank)
				local v58 = v_u_55.online == true
				local v_u_59 = v_u_12.memberDetail(v_u_28 - 6, v56, { v_u_12.chipW(v57), not v58 and 0 or v_u_12.chipW("ONLINE") })
				local v60 = v_u_5.list({
					["parent"] = nil,
					["name"] = "DetailList",
					["size"] = nil,
					["gap"] = 0,
					["padding"] = nil,
					["parent"] = v_u_29,
					["size"] = UDim2.fromScale(1, 1),
					["padding"] = {
						0,
						0,
						0,
						8
					}
				})
				local v_u_61 = v_u_9.frame(v60, "Sheet", UDim2.new(1, -6, 0, v_u_59.height), nil, 1)
				if v_u_59.back then
					v_u_9.btn({
						["parent"] = nil,
						["text"] = "BACK",
						["kind"] = "secondary",
						["width"] = nil,
						["name"] = "Back",
						["position"] = nil,
						["onClick"] = nil,
						["parent"] = v_u_61,
						["width"] = v_u_59.back.w,
						["position"] = UDim2.fromOffset(v_u_59.back.x, v_u_59.back.y),
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_17, (ref) v_u_14
							v_u_17 = false
							v_u_14.draw()
						end
					})
				end
				local v62 = v_u_13.rankColor(v_u_55.rank)
				local v63 = v_u_9.card(v_u_61, "Profile", v_u_59.card, {
					["fill"] = nil,
					["transparency"] = 0.1,
					["stroke"] = nil,
					["strokeTransparency"] = 0.55,
					["fill"] = v_u_7.raised,
					["stroke"] = v62
				})
				local v64 = v_u_59.cardParts
				local v65 = v_u_9.avatar
				local v66 = "Avatar"
				local v67 = v_u_55.uid
				local v68 = v_u_55.name
				local v69 = v64.avatar
				local v70 = {
					["ring"] = nil,
					["dot"] = nil,
					["glyphStyle"] = "h2",
					["ring"] = v62
				}
				local v71
				if v58 then
					v71 = v_u_7.success
				else
					v71 = nil
				end
				v70.dot = v71
				v65(v63, v66, v67, v68, v69, v70)
				local v72 = v_u_9.text
				local v73 = v_u_55.name or "?"
				v72(v63, "Name", tostring(v73), v64.name, {
					["style"] = v56 and "h3" or "h2"
				})
				v_u_9.pill(v63, "RankChip", v57, v62, v64.rank)
				if v64.online then
					v_u_9.pill(v63, "OnlineChip", "ONLINE", v_u_7.success, v64.online)
				end
				local v74 = {}
				local v75 = {}
				local v76 = v_u_5.commas
				local v77 = v_u_55.pts
				__set_list(v75, 1, {"Points this week", v76(tonumber(v77) or 0)})
				__set_list(v74, 1, {v75})
				local v78 = v_u_55.joined
				if tonumber(v78) then
					local v79 = {}
					local v80 = v_u_10.timeText
					local v81 = v_u_9.now() - v_u_55.joined
					__set_list(v79, 1, {"In the clan for", v80((math.max(1, v81)))})
					table.insert(v74, v79)
				else
					table.insert(v74, { "In the clan for", "Unknown" })
				end
				for v82, v83 in v74 do
					local v84 = v_u_59.stats[v82]
					local v85 = v_u_9.card(v_u_61, "Stat" .. v82, v84.box)
					v_u_9.text(v85, "Label", v83[1], v84.parts.label, {
						["style"] = "micro",
						["color"] = nil,
						["color"] = v_u_7.text2
					})
					v_u_9.text(v85, "Value", v83[2], v84.parts.value, {
						["style"] = "monoL"
					})
				end
				local v86 = v_u_10.memberActions(v54, v_u_55, p_u_3.selfUid)
				local v_u_87 = 0
				local function v94(p88, p89, p_u_90) -- name: actionBtn
					-- upvalues: (ref) v_u_87, (copy) v_u_59, (ref) v_u_9, (copy) v_u_61
					v_u_87 = v_u_87 + 1
					local v91 = v_u_59.actions[v_u_87]
					local v_u_92 = nil
					local _, v93 = v_u_9.btn({
						["parent"] = v_u_61,
						["text"] = p88,
						["kind"] = p89,
						["width"] = v91.w,
						["name"] = "Act_" .. p88,
						["position"] = UDim2.fromOffset(v91.x, v91.y),
						["onClick"] = function() -- name: onClick
							-- upvalues: (copy) p_u_90, (ref) v_u_92
							p_u_90(v_u_92)
						end
					})
					v_u_92 = v93
				end
				if #v86.ranks > 0 then
					local v95 = {}
					for _, v96 in v86.ranks do
						local v97 = {
							["id"] = v96,
							["text"] = v_u_13.rankChipText(v54, v96)
						}
						table.insert(v95, v97)
					end
					local v98 = v_u_59.rank
					v_u_5.dropdown({
						["parent"] = nil,
						["name"] = "ChangeRank",
						["label"] = "CHANGE RANK",
						["options"] = nil,
						["value"] = nil,
						["width"] = nil,
						["onChange"] = nil,
						["parent"] = v_u_61,
						["options"] = v95,
						["value"] = v_u_55.rank,
						["width"] = v98.w,
						["onChange"] = function(p99) -- name: onChange
							-- upvalues: (copy) v_u_55, (ref) v_u_22, (ref) p_u_3, (ref) v_u_15, (ref) v_u_10, (ref) v_u_19, (ref) v_u_18, (ref) v_u_16, (ref) v_u_17
							if p99 ~= v_u_55.rank then
								local v100 = {}
								local v101 = {}
								local v102 = {}
								local v103 = v_u_55.uid
								v102.uid = tostring(v103)
								v102.rank = p99
								__set_list(v101, 1, {v102})
								v100.changes = v101
								v_u_22.set("", nil)
								local v_u_104 = nil
								local v_u_105 = "clanRank"
								p_u_3.send("clanRank", v100, function(p106, p107, p108, p109)
									-- upvalues: (ref) v_u_15, (copy) v_u_104, (ref) v_u_10, (ref) v_u_22, (ref) v_u_19, (ref) v_u_18, (copy) v_u_105, (ref) v_u_16, (ref) v_u_17
									if v_u_15 then
										if v_u_104 then
											local v110 = v_u_104.busy
											pcall(v110, false)
										end
										local v111 = nil
										local v112
										if type(p108) == "table" then
											v112 = p108.results
										else
											v112 = nil
										end
										if type(v112) == "table" then
											for _, v113 in v112 do
												if type(v113) ~= "table" or v113.ok == true then
													continue
												end
												local v114 = v113.code
												if type(v114) ~= "string" then
													continue
												end
												v111 = v_u_10.text(v113.code)
											end
										end
										if p106 then
											if v111 then
												v_u_22.set(v111, "warn")
											end
										else
											v_u_22.set(v_u_10.reasonFor(p109 or {
												["msg"] = p107,
												["data"] = p108
											}), "danger")
										end
										if p106 then
											v_u_19 = {}
											v_u_18 = false
											if v_u_105 == "clanKick" then
												v_u_16 = nil
												v_u_17 = false
											end
										end
									end
								end, 25)
							end
						end
					}).Position = UDim2.fromOffset(v98.x, v98.y)
				end
				if v86.kick then
					v94("KICK", "danger", function(p_u_115)
						-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) v_u_55, (ref) v_u_51
						local v116 = v_u_9.confirm
						local v117 = {
							["title"] = "REMOVE MEMBER",
							["body"] = nil,
							["yes"] = "KICK",
							["no"] = "CANCEL",
							["danger"] = true,
							["onYes"] = nil
						}
						local v118 = v_u_10.CONFIRM.kick
						local v119 = v_u_55.name or "?"
						v117.body = v118((tostring(v119)))
						function v117.onYes() -- name: onYes
							-- upvalues: (ref) v_u_51, (ref) v_u_55, (copy) p_u_115
							local v120 = v_u_51
							local v121 = {}
							local v122 = {}
							local v123 = v_u_55.uid
							__set_list(v122, 1, {(tostring(v123))})
							v121.uids = v122
							v120("clanKick", v121, p_u_115)
						end
						v116(v117)
					end)
				end
				if #v86.ranks <= 0 and not v86.kick then
					local v124 = v_u_9.text
					local v125 = v_u_55.uid
					v124(v_u_61, "NoAct", tostring(v125) == p_u_3.selfUid and "This is you." or "You cannot manage this member.", v_u_59.note, {
						["style"] = "small",
						["color"] = nil,
						["color"] = v_u_7.text2
					})
				end
			elseif v_u_11.twoCol then
				local v126 = {
					["x"] = 0,
					["y"] = 0,
					["w"] = nil,
					["h"] = 120,
					["w"] = v_u_28
				}
				local v127 = v_u_9.card(v_u_29, "DetailEmpty", v126, {
					["transparency"] = 0.5
				})
				v_u_9.text(v127, "Glyph", "?", {
					["x"] = 16,
					["y"] = 16,
					["w"] = 56,
					["h"] = 56
				}, {
					["style"] = "h1",
					["color"] = nil,
					["align"] = "center",
					["color"] = v_u_7.muted
				})
				v_u_9.text(v127, "Hint", "Select a member to see their profile and the actions you can use.", {
					["x"] = 88,
					["y"] = 16,
					["w"] = nil,
					["h"] = 56,
					["w"] = v_u_28 - 104
				}, {
					["style"] = "body",
					["color"] = nil,
					["wrap"] = true,
					["valign"] = "center",
					["color"] = v_u_7.text2
				})
			end
		end
		local function v_u_138() -- name: drawBar
			-- upvalues: (copy) v_u_8, (copy) v_u_27, (copy) v_u_21, (ref) v_u_18, (copy) v_u_26, (copy) v_u_20, (copy) p_u_3, (copy) v_u_10, (copy) v_u_9, (ref) v_u_19, (copy) v_u_14, (copy) v_u_38, (copy) v_u_51
			v_u_8.clear(v_u_27)
			local v129 = not v_u_21 or v_u_18
			v_u_27.Visible = v129
			local v130 = v_u_26
			local v131
			if v129 then
				v131 = UDim2.new(1, 0, 1, -(v_u_20 + 6))
			else
				v131 = UDim2.fromScale(1, 1)
			end
			v130.Size = v131
			local v132 = p_u_3.clan()
			if v132 and v_u_10.can(v132, "kick") then
				if v129 then
					local v133 = {
						["parent"] = nil,
						["text"] = nil,
						["kind"] = "secondary",
						["width"] = 130,
						["name"] = "SelectMode",
						["onClick"] = nil,
						["parent"] = v_u_27,
						["text"] = v_u_18 and "DONE" or "SELECT",
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_14
							v_u_18 = not v_u_18
							v_u_19 = {}
							v_u_14.draw()
						end
					}
					local _, _ = v_u_9.btn(v133)
					if v_u_18 then
						local v134 = #v_u_38()
						local v_u_135 = nil
						local _, v137 = v_u_9.btn({
							["parent"] = nil,
							["text"] = nil,
							["kind"] = "danger",
							["width"] = 150,
							["name"] = "KickMany",
							["position"] = nil,
							["disabled"] = nil,
							["onClick"] = nil,
							["parent"] = v_u_27,
							["text"] = ("KICK %d"):format(v134),
							["position"] = UDim2.fromOffset(138, 0),
							["disabled"] = v134 == 0,
							["onClick"] = function() -- name: onClick
								-- upvalues: (ref) v_u_38, (ref) v_u_9, (ref) v_u_10, (ref) v_u_51, (ref) v_u_135
								local v_u_136 = v_u_38()
								if #v_u_136 ~= 0 then
									v_u_9.confirm({
										["title"] = "REMOVE MEMBERS",
										["body"] = nil,
										["yes"] = "KICK",
										["no"] = "CANCEL",
										["danger"] = true,
										["onYes"] = nil,
										["body"] = v_u_10.CONFIRM.kickMany(#v_u_136),
										["onYes"] = function() -- name: onYes
											-- upvalues: (ref) v_u_51, (copy) v_u_136, (ref) v_u_135
											v_u_51("clanKick", {
												["uids"] = v_u_136
											}, v_u_135)
										end
									})
								end
							end
						})
						local _ = v137
					end
				end
			else
				return
			end
		end
		function v_u_14.draw() -- name: draw
			-- upvalues: (ref) v_u_15, (copy) v_u_53, (copy) v_u_25, (ref) v_u_17, (copy) v_u_29, (copy) v_u_11, (ref) v_u_16, (copy) p_u_3, (copy) v_u_12, (copy) v_u_13, (copy) v_u_5, (copy) v_u_26, (copy) v_u_8, (copy) v_u_10, (copy) v_u_21, (ref) v_u_18, (copy) v_u_6, (copy) v_u_9, (ref) v_u_19, (copy) v_u_14, (copy) v_u_24, (copy) v_u_7, (copy) v_u_38, (ref) v_u_22, (copy) v_u_138, (copy) v_u_128
			if v_u_15 then
				v_u_53()
				v_u_25.Visible = not v_u_17
				v_u_29.Visible = v_u_11.twoCol or v_u_17
				if v_u_11.twoCol and v_u_16 == nil then
					local v139 = p_u_3.clan()
					local v140 = v_u_12.defaultMember
					local v141
					if v139 then
						v141 = v_u_13.sortMembers(v139.members)
					else
						v141 = nil
					end
					v_u_16 = v140(v141, p_u_3.selfUid)
				end
				v_u_5.keepScroll(v_u_26, function()
					-- upvalues: (ref) v_u_8, (ref) v_u_26, (ref) p_u_3, (ref) v_u_13, (ref) v_u_10, (ref) v_u_21, (ref) v_u_18, (ref) v_u_6, (ref) v_u_5, (ref) v_u_9, (ref) v_u_19, (ref) v_u_14, (ref) v_u_24, (ref) v_u_12, (ref) v_u_7, (ref) v_u_11, (ref) v_u_16, (ref) v_u_38, (ref) v_u_22, (ref) v_u_17
					v_u_8.clear(v_u_26)
					local v142 = p_u_3.clan()
					local v143 = not v142 and {} or v_u_13.sortMembers(v142.members)
					if #v143 == 0 then
						v_u_8.empty(v_u_26, v_u_10.UI.NO_MEMBERS, 1)
					else
						local v144 = #v143
						local v145 = v142.cap
						local v146 = ("%d / %d"):format(v144, tonumber(v145) or 30)
						local v147 = v_u_21 and not v_u_18
						if v147 then
							v147 = v_u_10.can(v142, "kick")
						end
						local v148 = v_u_8.section
						local v149 = v_u_26
						local v150 = "MEMBERS"
						local v151 = 0
						local v152
						if v147 then
							v152 = nil
						else
							v152 = v146
						end
						local v153 = v148(v149, v150, v151, v152)
						if v147 then
							v153.Size = UDim2.new(1, -6, 0, v_u_6.touch(44))
							v_u_5.label({
								["parent"] = nil,
								["name"] = "Count",
								["text"] = nil,
								["style"] = "monoS",
								["position"] = nil,
								["size"] = nil,
								["track"] = false,
								["parent"] = v153,
								["text"] = v146,
								["position"] = UDim2.fromOffset(92, 0),
								["size"] = UDim2.new(1, -232, 1, 0)
							})
							v_u_9.btn({
								["parent"] = nil,
								["text"] = "SELECT",
								["kind"] = "secondary",
								["width"] = 130,
								["name"] = "SelectMode",
								["anchor"] = nil,
								["position"] = nil,
								["onClick"] = nil,
								["parent"] = v153,
								["anchor"] = Vector2.new(1, 0.5),
								["position"] = UDim2.new(1, 0, 0.5, 0),
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_14
									v_u_18 = true
									v_u_19 = {}
									v_u_14.draw()
								end
							})
						end
						local v154 = v_u_24 - 6
						local v155 = v_u_12.membersHint(v154)
						local v156 = v_u_9.frame(v_u_26, "PointsHint", UDim2.new(1, -6, 0, v155.box.h), nil, 1)
						v_u_9.fitLine(v_u_9.text(v156, "Text", v_u_10.hintMembers(), v155.text, {
							["style"] = "small",
							["color"] = nil,
							["color"] = v_u_7.text2
						}), v155.text.w)
						local v157 = v_u_12.memberRow(v154, v_u_11.rowH, v_u_18)
						for v158, v159 in v143 do
							local v160 = v159.uid
							local v_u_161 = tostring(v160)
							local v162 = v_u_161 == p_u_3.selfUid
							local v_u_163 = v_u_10.memberActions(v142, v159, p_u_3.selfUid)
							local v164 = v_u_161 == v_u_16 and v_u_11.twoCol or v_u_19[v_u_161] == true
							local v165 = v_u_13.rankColor(v159.rank)
							local v166 = v_u_5.new
							local v167 = "TextButton"
							local v168 = {
								["Name"] = nil,
								["Text"] = "",
								["AutoButtonColor"] = false,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = nil,
								["BorderSizePixel"] = 0,
								["Size"] = nil,
								["LayoutOrder"] = nil,
								["Selectable"] = true,
								["ClipsDescendants"] = true,
								["Name"] = "M_" .. v_u_161
							}
							local v169
							if v164 or v162 then
								v169 = v_u_7.accentDeep
							else
								v169 = v_u_7.raised
							end
							v168.BackgroundColor3 = v169
							v168.BackgroundTransparency = v164 and 0.1 or (v162 and 0.35 or 0.3)
							v168.Size = UDim2.new(1, -6, 0, v_u_11.rowH)
							v168.LayoutOrder = v158 + 1
							local v170 = v166(v167, v168, v_u_26)
							v_u_5.corner(v170, 6)
							v170.SelectionImageObject = v_u_5.selectionImage()
							v_u_9.press(v170, function()
								-- upvalues: (ref) v_u_18, (copy) v_u_163, (ref) v_u_19, (copy) v_u_161, (ref) v_u_38, (ref) v_u_22, (ref) v_u_14, (ref) v_u_16, (ref) v_u_11, (ref) v_u_17
								if v_u_18 then
									if v_u_163.kick then
										if not v_u_19[v_u_161] and #v_u_38() >= 10 then
											v_u_22.set("You can pick up to 10 members at once.", "warn")
											return
										end
										v_u_19[v_u_161] = not v_u_19[v_u_161]
										v_u_14.draw()
									end
								else
									v_u_16 = v_u_161
									if v_u_11.kind == "phone" then
										v_u_17 = true
									end
									v_u_14.draw()
								end
							end)
							v_u_5.new("Frame", {
								["Name"] = "RankBar",
								["BackgroundColor3"] = nil,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["BackgroundColor3"] = v165,
								["Position"] = UDim2.fromOffset(v157.bar.x, v157.bar.y),
								["Size"] = UDim2.fromOffset(v157.bar.w, v157.bar.h)
							}, v170)
							local v171 = v_u_9.avatar
							local v172 = "Avatar"
							local v173 = v159.uid
							local v174 = v159.name
							local v175 = v157.avatar
							local v176 = {}
							local v177
							if v159.online == true then
								v177 = v_u_7.success
							else
								v177 = v_u_7.muted
							end
							v176.dot = v177
							v171(v170, v172, v173, v174, v175, v176)
							local v178 = v_u_5.label
							local v179 = {
								["parent"] = nil,
								["name"] = "Name",
								["text"] = nil,
								["style"] = "bodyStrong",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["parent"] = v170
							}
							local v180 = v159.name or "?"
							v179.text = tostring(v180) .. (v162 and " (you)" or "")
							local v181
							if v162 then
								v181 = v_u_7.accent
							else
								v181 = v_u_7.text
							end
							v179.color = v181
							v179.position = UDim2.fromOffset(v157.name.x, v157.name.y)
							v179.size = UDim2.fromOffset(v157.name.w, v157.name.h)
							v178(v179)
							local v182 = v_u_13.rankChipText(v142, v159.rank)
							local v183 = {
								["x"] = v157.chip.x,
								["y"] = v157.chip.y
							}
							local v184 = v157.chip.w
							local v185 = v_u_12.chipW
							v183.w = math.min(v184, v185(v182))
							v183.h = v157.chip.h
							v183.x = v157.chip.x + v157.chip.w - v183.w
							v_u_9.pill(v170, "Rank", v182, v165, v183)
							local v186 = v_u_5.label
							local v187 = {
								["parent"] = nil,
								["name"] = "Pts",
								["text"] = nil,
								["style"] = "mono",
								["align"] = "right",
								["position"] = nil,
								["size"] = nil,
								["parent"] = v170
							}
							local v188 = v_u_5.commas
							local v189 = v159.pts
							v187.text = v188(tonumber(v189) or 0)
							v187.position = UDim2.fromOffset(v157.pts.x, v157.pts.y)
							v187.size = UDim2.fromOffset(v157.pts.w, v157.pts.h)
							v186(v187)
							if not (v_u_18 and v_u_163.kick) then
								continue
							end
							v_u_5.label({
								["parent"] = nil,
								["name"] = "Check",
								["text"] = nil,
								["style"] = "mono",
								["color"] = nil,
								["align"] = "center",
								["position"] = nil,
								["size"] = nil,
								["parent"] = v170,
								["text"] = v_u_19[v_u_161] and "X" or "",
								["color"] = v_u_7.accent,
								["position"] = UDim2.fromOffset(v157.check.x, v157.check.y),
								["size"] = UDim2.fromOffset(v157.check.w, v157.check.h)
							})
						end
					end
				end)
				v_u_138()
				v_u_128()
			end
		end
		function v_u_14.show() -- name: show
			-- upvalues: (copy) v_u_14
			v_u_14.draw()
		end
		function v_u_14.hide() -- name: hide end
		function v_u_14.refresh(p190) -- name: refresh
			-- upvalues: (ref) v_u_16, (copy) v_u_34, (ref) v_u_17, (copy) v_u_14
			if p190 == "state" then
				if v_u_16 and not v_u_34(v_u_16) then
					v_u_16 = nil
					v_u_17 = false
				end
				v_u_14.draw()
			end
		end
		function v_u_14.tick() -- name: tick
			-- upvalues: (ref) v_u_15, (copy) v_u_53
			if v_u_15 then
				v_u_53()
			end
		end
		function v_u_14.destroy() -- name: destroy
			-- upvalues: (ref) v_u_15
			v_u_15 = false
		end
		return v_u_14
	end,
	["log"] = function(p_u_191, p192) -- name: log
		local v_u_193 = p_u_191.UI
		local _ = p_u_191.Theme
		local v_u_194 = p_u_191.C
		local v_u_195 = p_u_191.Kit
		local v_u_196 = p_u_191.U
		local v_u_197 = p_u_191.M
		local v198 = p_u_191.m
		local v_u_199 = p_u_191.lib("MenuClanPlan")
		local v_u_200 = p_u_191.lib("MenuClanLook")
		local v_u_201 = {}
		local v_u_202 = true
		local v_u_203 = {}
		local v_u_204 = 0
		local v_u_205 = false
		local v_u_206 = "loading"
		local v_u_207 = false
		local v_u_208 = v_u_193.list({
			["parent"] = nil,
			["name"] = "List",
			["size"] = nil,
			["gap"] = 8,
			["padding"] = nil,
			["parent"] = p192,
			["size"] = UDim2.fromScale(1, 1),
			["padding"] = {
				0,
				6,
				0,
				8
			}
		})
		local v_u_209 = v198.inner - 8
		function v_u_201.draw() -- name: draw
			-- upvalues: (ref) v_u_202, (copy) v_u_193, (copy) v_u_208, (copy) v_u_195, (ref) v_u_203, (ref) v_u_206, (copy) v_u_196, (copy) v_u_197, (copy) v_u_201, (copy) v_u_209, (copy) v_u_194, (copy) v_u_199, (copy) v_u_200, (ref) v_u_205
			if v_u_202 then
				v_u_193.keepScroll(v_u_208, function()
					-- upvalues: (ref) v_u_195, (ref) v_u_208, (ref) v_u_203, (ref) v_u_206, (ref) v_u_196, (ref) v_u_197, (ref) v_u_201, (ref) v_u_209, (ref) v_u_194, (ref) v_u_199, (ref) v_u_200, (ref) v_u_193, (ref) v_u_205
					v_u_195.clear(v_u_208)
					if #v_u_203 == 0 then
						if v_u_206 == "loading" then
							v_u_196.skeleton(v_u_208, 4, 56)
							return
						elseif v_u_206 == "gave_up" then
							v_u_195.empty(v_u_208, v_u_197.UI.LOAD_FAIL, 1)
							local v210 = {
								["parent"] = nil,
								["text"] = "RETRY",
								["kind"] = "secondary",
								["width"] = 140,
								["order"] = 2,
								["name"] = "Retry",
								["onClick"] = nil,
								["parent"] = v_u_208,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_201
									v_u_201.load(true)
								end
							}
							v_u_196.btn(v210)
						else
							local v211 = {
								["x"] = 0,
								["y"] = 0,
								["w"] = nil,
								["h"] = 96,
								["w"] = v_u_209
							}
							local v212 = v_u_196.card(v_u_208, "LogEmpty", v211, {
								["transparency"] = 0.5,
								["order"] = 1
							})
							v_u_196.text(v212, "Glyph", "?", {
								["x"] = 16,
								["y"] = 20,
								["w"] = 56,
								["h"] = 56
							}, {
								["style"] = "h1",
								["color"] = nil,
								["align"] = "center",
								["color"] = v_u_194.muted
							})
							v_u_196.text(v212, "Hint", v_u_197.UI.NO_LOG .. " Joins, ranks and stash moves show up here.", {
								["x"] = 88,
								["y"] = 16,
								["w"] = nil,
								["h"] = 64,
								["w"] = v_u_209 - 104
							}, {
								["style"] = "body",
								["color"] = nil,
								["wrap"] = true,
								["valign"] = "center",
								["color"] = v_u_194.text2
							})
						end
					else
						local v213 = v_u_196.now()
						local v214, v215, v216 = v_u_199.logGrid(v_u_209)
						local v217 = v_u_199.GAP
						local v218 = 0
						local v219 = 0
						while v218 < #v_u_203 do
							v219 = v219 + 1
							local v220 = v_u_196.frame(v_u_208, "Line" .. v219, UDim2.new(1, -8, 0, v216), nil, v219)
							for v221 = 0, v214 - 1 do
								local v_u_222 = v_u_203[v218 + v221 + 1]
								if not v_u_222 then
									continue
								end
								local v223 = {
									["x"] = nil,
									["y"] = 0,
									["w"] = nil,
									["h"] = nil,
									["x"] = v221 * (v215 + v217),
									["w"] = v215,
									["h"] = v216
								}
								local v224 = v_u_197.agoText
								local v225 = v_u_222.t
								local v_u_226 = v224(v213 - (tonumber(v225) or v213))
								local v227 = v_u_200.logUid(v_u_222)
								local v228 = v_u_222.rk
								local v229
								if type(v228) == "string" then
									v229 = v_u_222.rk
								else
									v229 = nil
								end
								local v230 = v_u_196.card(v220, "L" .. v218 + v221 + 1, v223)
								local v231 = v_u_199.logCard(v215, v216)
								if v229 then
									v_u_193.new("Frame", {
										["Name"] = "RankBar",
										["BackgroundColor3"] = nil,
										["BorderSizePixel"] = 0,
										["Position"] = nil,
										["Size"] = nil,
										["BackgroundColor3"] = v_u_200.rankColor(v229),
										["Position"] = UDim2.fromOffset(v231.bar.x, v231.bar.y),
										["Size"] = UDim2.fromOffset(v231.bar.w, v231.bar.h)
									}, v230)
								end
								v_u_196.avatar(v230, "Avatar", v227, "?", v231.avatar, {})
								local v232 = v_u_193.label
								local v233 = {
									["parent"] = nil,
									["name"] = "Text",
									["text"] = nil,
									["style"] = "small",
									["wrap"] = true,
									["valign"] = "center",
									["position"] = nil,
									["size"] = nil,
									["track"] = false,
									["parent"] = v230
								}
								local v234 = v_u_222.text or ""
								v233.text = tostring(v234)
								v233.position = UDim2.fromOffset(v231.text.x, v231.text.y)
								v233.size = UDim2.fromOffset(v231.text.w, v231.text.h)
								v232(v233)
								v_u_193.label({
									["parent"] = nil,
									["name"] = "When",
									["text"] = nil,
									["style"] = "micro",
									["color"] = nil,
									["align"] = "right",
									["position"] = nil,
									["size"] = nil,
									["track"] = false,
									["parent"] = v230,
									["text"] = v_u_226,
									["color"] = v_u_194.text2,
									["position"] = UDim2.fromOffset(v231.when.x, v231.when.y),
									["size"] = UDim2.fromOffset(v231.when.w, v231.when.h)
								})
								v_u_193.tooltip(v230, function()
									-- upvalues: (copy) v_u_226, (copy) v_u_222
									local v235 = {
										["title"] = v_u_226:upper()
									}
									local v236 = v_u_222.text or ""
									v235.body = tostring(v236)
									return v235
								end)
							end
							v218 = v218 + v214
						end
						if v_u_205 then
							v_u_196.btn({
								["parent"] = nil,
								["text"] = "LOAD MORE",
								["kind"] = "secondary",
								["width"] = 160,
								["order"] = nil,
								["name"] = "More",
								["onClick"] = nil,
								["parent"] = v_u_208,
								["order"] = #v_u_203 + 1,
								["onClick"] = function() -- name: onClick
									-- upvalues: (ref) v_u_201
									v_u_201.load(false)
								end
							})
						end
						return
					end
				end)
			end
		end
		function v_u_201.load(p237) -- name: load
			-- upvalues: (ref) v_u_207, (ref) v_u_202, (ref) v_u_203, (ref) v_u_204, (ref) v_u_205, (ref) v_u_206, (copy) v_u_201, (copy) p_u_191
			if not v_u_207 and v_u_202 then
				v_u_207 = true
				if p237 then
					v_u_203 = {}
					v_u_204 = 0
					v_u_205 = false
					v_u_206 = "loading"
					v_u_201.draw()
				end
				local v_u_238 = v_u_204 + 1
				task.spawn(function()
					-- upvalues: (ref) v_u_202, (ref) v_u_207, (ref) p_u_191, (copy) v_u_238, (ref) v_u_206, (ref) v_u_203, (ref) v_u_204, (ref) v_u_205, (ref) v_u_201
					local v239 = nil
					for v240 = 0, 2 do
						if v240 > 0 then
							task.wait(2 ^ (v240 - 1) * 3)
							if not v_u_202 then
								v_u_207 = false
								return
							end
						end
						local v241 = {
							["page"] = v_u_238
						}
						v239 = p_u_191.fetch("clanLog", v241, 0)
						if v239 == nil then
							continue
						end
					end
					v_u_207 = false
					if not v_u_202 then
						return
					end
					if v239 == nil then
						if #v_u_203 == 0 then
							v_u_206 = "gave_up"
						end
						v_u_201.draw()
						return
					else
						local v242 = v239.rows
						if type(v242) == "table" then
							v_u_206 = nil
							for _, v243 in v239.rows do
								if type(v243) ~= "table" then
									continue
								end
								local v244 = v_u_203
								table.insert(v244, v243)
							end
							v_u_204 = v_u_238
							v_u_205 = #v239.rows >= 30
							v_u_201.draw()
						else
							if #v_u_203 == 0 then
								v_u_206 = "gave_up"
							end
							v_u_201.draw()
						end
					end
				end)
			end
		end
		function v_u_201.show() -- name: show
			-- upvalues: (ref) v_u_203, (copy) v_u_201
			if #v_u_203 == 0 then
				v_u_201.load(true)
			else
				v_u_201.draw()
			end
		end
		function v_u_201.hide() -- name: hide end
		function v_u_201.refresh(p245) -- name: refresh
			-- upvalues: (ref) v_u_203
			if p245 == "result" then
				v_u_203 = {}
			end
		end
		function v_u_201.tick() -- name: tick end
		function v_u_201.destroy() -- name: destroy
			-- upvalues: (ref) v_u_202
			v_u_202 = false
		end
		return v_u_201
	end
}