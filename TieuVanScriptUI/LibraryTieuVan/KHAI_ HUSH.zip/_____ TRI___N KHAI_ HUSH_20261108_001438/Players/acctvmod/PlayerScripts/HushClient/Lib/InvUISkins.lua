-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUISkins

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared")
local v_u_2 = require(v1:WaitForChild("Skins"))
local v_u_38 = {
	["TEXT"] = {
		["entry"] = "Skins",
		["charButton"] = "Skins"
	},
	["ID"] = "skins",
	["weaponFor"] = function(p3) -- name: weaponFor
		-- upvalues: (copy) v_u_2
		if type(p3) == "string" and p3 ~= "" then
			if v_u_2.NO_SKIN[p3] then
				return nil
			elseif v_u_2.canHaveSkin(p3) then
				return p3
			else
				return nil
			end
		else
			return nil
		end
	end,
	["entry"] = function(p4, p5, p6) -- name: entry
		-- upvalues: (copy) v_u_38
		if p5 ~= true or p6 ~= true then
			return nil
		end
		local v7 = v_u_38.weaponFor(p4)
		return v7 and {
			["id"] = v_u_38.ID,
			["text"] = v_u_38.TEXT.entry,
			["weapon"] = v7
		} or nil
	end,
	["charButton"] = function(p8) -- name: charButton
		return p8 == true
	end,
	["acts"] = function(p_u_9, p10, p11, _, p12) -- name: acts
		-- upvalues: (copy) v_u_38
		if type(p11) == "table" then
			local v13 = p11.item
			if type(v13) == "table" then
				local v14 = v_u_38.entry
				local v15 = p11.item.id
				local v16 = p10.mode ~= "raid"
				local v17, v18 = pcall(function()
					-- upvalues: (copy) p_u_9
					return p_u_9.controllers.Menu.skinsListed()
				end)
				if v17 then
					v17 = v18 == true
				end
				local v19 = v14(v15, v16, v17)
				if v19 then
					local v20 = {
						["id"] = v19.id,
						["text"] = v19.text
					}
					table.insert(p12, v20)
				end
				return
			end
		end
	end,
	["strip"] = function(p_u_21, p22, p23, _, p24) -- name: strip
		-- upvalues: (copy) v_u_38
		if type(p23) == "table" then
			local v25 = p23.item
			if type(v25) == "table" then
				local v26 = v_u_38.entry
				local v27 = p23.item.id
				local v28 = p22.mode ~= "raid"
				local v29, v30 = pcall(function()
					-- upvalues: (copy) p_u_21
					return p_u_21.controllers.Menu.skinsListed()
				end)
				if v29 then
					v29 = v30 == true
				end
				local v31 = v26(v27, v28, v29)
				if v31 then
					local v32 = {
						["id"] = nil,
						["text"] = nil,
						["icon"] = "skins",
						["id"] = v31.id,
						["text"] = v31.text
					}
					table.insert(p24, v32)
				end
				return
			end
		end
	end,
	["run"] = function(p_u_33, p34, p35) -- name: run
		-- upvalues: (copy) v_u_38
		if p35 ~= v_u_38.ID then
			return false
		end
		local v_u_36
		if type(p34) == "table" then
			local v37 = p34.item
			if type(v37) == "table" then
				v_u_36 = v_u_38.weaponFor(p34.item.id)
			else
				v_u_36 = nil
			end
		else
			v_u_36 = nil
		end
		if v_u_36 then
			pcall(function()
				-- upvalues: (copy) p_u_33, (copy) v_u_36
				p_u_33.controllers.Menu.openSkins(v_u_36)
			end)
		end
		return true
	end
}
return v_u_38