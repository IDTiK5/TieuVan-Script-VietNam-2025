-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / InventoryUI

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("HapticService")
game:GetService("TweenService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("CollectionService")
local v_u_6 = v4:WaitForChild("Hush"):WaitForChild("Shared")
local v_u_7 = script.Parent.Parent:WaitForChild("Lib")
local v_u_8 = require(v_u_6:WaitForChild("Theme"))
local v_u_9 = require(v_u_6:WaitForChild("Items"))
local v_u_10 = require(v_u_6:WaitForChild("Grid"))
local v_u_11 = require(v_u_7:WaitForChild("HushUI"))
local v_u_12 = require(v_u_7:WaitForChild("ItemIcons"))
local v_u_13 = require(v_u_7:WaitForChild("InvUITile"))
local v_u_14 = require(v_u_7:WaitForChild("InvUISilhouette"))
local v_u_15 = require(v_u_7:WaitForChild("InvUILootGlow"))
local v_u_16 = require(v_u_7:WaitForChild("InvUIAmmo"))
local v_u_17 = require(v_u_7:WaitForChild("InvUIPing"))
local v_u_18 = v_u_8.color
local v_u_19 = {
	["name"] = "InventoryUI",
	["order"] = 45
}
local v_u_20 = nil
local v_u_21 = v1.LocalPlayer
local v_u_22 = 0
local function v_u_28(p23, p24, p25) -- name: countText
	local v26 = string.format
	local v27 = "%d %s"
	if p23 ~= 1 then
		p24 = p25 or p24 .. "s"
	end
	return v26(v27, p23, p24)
end
local v_u_29 = {
	"pockets",
	"vest",
	"bag",
	"secure"
}
local v_u_30 = {
	"lo_pockets",
	"lo_vest",
	"lo_bag",
	"lo_secure"
}
local v_u_31 = {
	["pockets"] = "Pockets",
	["vest"] = "Tactical rig",
	["bag"] = "Backpack",
	["secure"] = "Secure container",
	["lo_pockets"] = "Pockets",
	["lo_vest"] = "Tactical rig",
	["lo_bag"] = "Backpack",
	["lo_secure"] = "Secure container",
	["stash"] = "Stash"
}
local v_u_32 = {
	["vest"] = "armor",
	["bag"] = "bag",
	["secure"] = "secure",
	["lo_vest"] = "armor",
	["lo_bag"] = "bag",
	["lo_secure"] = "secure"
}
local v_u_33 = {
	{
		["id"] = "primary",
		["label"] = "Primary",
		["short"] = "Primary",
		["glyph"] = "rifle"
	},
	{
		["id"] = "secondary",
		["label"] = "Sidearm",
		["short"] = "Sidearm",
		["glyph"] = "pistol"
	},
	{
		["id"] = "melee",
		["label"] = "Melee",
		["short"] = "Melee",
		["glyph"] = "knife"
	},
	{
		["id"] = "helmet",
		["label"] = "Headwear",
		["short"] = "Head",
		["glyph"] = "helmet"
	},
	{
		["id"] = "armor",
		["label"] = "Body armor",
		["short"] = "Armor",
		["glyph"] = "vest"
	},
	{
		["id"] = "bag",
		["label"] = "Backpack",
		["short"] = "Bag",
		["glyph"] = "backpack"
	},
	{
		["id"] = "secure",
		["label"] = "Secure",
		["short"] = "Secure",
		["glyph"] = "case"
	},
	{
		["id"] = "legs",
		["label"] = "Legs",
		["short"] = "Legs",
		["glyph"] = "legs"
	},
	{
		["id"] = "boots",
		["label"] = "Boots",
		["short"] = "Boots",
		["glyph"] = "boots"
	},
	{
		["id"] = "ears",
		["label"] = "Headset",
		["short"] = "Headset",
		["glyph"] = "headset"
	}
}
local function v_u_40(p34, p35, p36) -- name: new
	local v37 = Instance.new(p34)
	if p35 then
		for v38, v39 in p35 do
			v37[v38] = v39
		end
	end
	if p36 then
		v37.Parent = p36
	end
	return v37
end
local function v_u_43(p41) -- name: sound
	-- upvalues: (copy) v_u_11
	local v42 = v_u_11.sound
	pcall(v42, p41)
end
local function v_u_47(p44, p45) -- name: toast
	-- upvalues: (copy) v_u_11
	local v46 = v_u_11.toast
	pcall(v46, p44, p45 or "warn")
end
local function v_u_52(p48) -- name: deepCopy
	-- upvalues: (copy) v_u_52
	if type(p48) ~= "table" then
		return p48
	end
	local v49 = {}
	for v50, v51 in p48 do
		v49[v50] = v_u_52(v51)
	end
	return v49
end
local function v_u_60(p53, p54, p55) -- name: stroke
	-- upvalues: (copy) v_u_18
	local v56 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["Transparency"] = nil,
		["ApplyStrokeMode"] = nil,
		["Color"] = p54 or v_u_18.line,
		["Transparency"] = p55 or 0,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v_u_57 = Instance.new("UIStroke")
	if v56 then
		for v58, v59 in v56 do
			v_u_57[v58] = v59
		end
	end
	if p53 then
		v_u_57.Parent = p53
	end
	pcall(function()
		-- upvalues: (copy) v_u_57
		v_u_57.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	return v_u_57
end
local function v_u_74(p61, p62, p63, p64) -- name: label
	-- upvalues: (copy) v_u_11, (copy) v_u_8
	local v65 = p64 or {}
	v65.parent = p61
	v65.text = p62
	v65.style = p63
	local v66 = v_u_11.label
	local v67, v68 = pcall(v66, v65)
	if v67 and v68 then
		return v68
	end
	local v69 = v_u_8.styles[p63] or v_u_8.styles.body
	local v70 = {
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Text"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["FontFace"] = v69.font,
		["TextSize"] = v69.size,
		["TextColor3"] = v65.color or v69.color
	}
	if v69.caps then
		p62 = string.upper(p62)
	end
	v70.Text = p62
	v70.Size = v65.size or UDim2.fromScale(1, 1)
	v70.Position = v65.position or UDim2.new()
	v70.TextXAlignment = Enum.TextXAlignment.Left
	v70.TextTruncate = Enum.TextTruncate.AtEnd
	local v71 = Instance.new("TextLabel")
	if v70 then
		for v72, v73 in v70 do
			v71[v72] = v73
		end
	end
	if p61 then
		v71.Parent = p61
	end
	return v71
end
local function v_u_76(p75) -- name: visibleChain
	while p75 do
		if p75:IsA("GuiObject") and not p75.Visible then
			return false
		end
		if p75:IsA("ScreenGui") then
			return p75.Enabled
		end
		if p75:IsA("LayerCollector") then
			return true
		end
		p75 = p75.Parent
	end
	return false
end
local function v_u_78(p77) -- name: canvasAncestor
	while p77 do
		if p77:IsA("CanvasGroup") then
			return p77
		end
		if p77:IsA("LayerCollector") then
			return nil
		end
		p77 = p77.Parent
	end
	return nil
end
local function v_u_80(p79) -- name: scrollerOf
	if p79 then
		p79 = p79.Parent
	end
	while p79 do
		if p79:IsA("ScrollingFrame") then
			return p79
		end
		if p79:IsA("LayerCollector") then
			return nil
		end
		p79 = p79.Parent
	end
	return nil
end
local v_u_81 = nil
local v_u_82 = nil
local v_u_83 = nil
local function v_u_106(p84) -- name: designSizeOf
	-- upvalues: (copy) v_u_8
	local v85 = v_u_8.uiScale()
	local v86 = v_u_8.devViewport
	local v87, v88 = pcall(v86)
	if v87 then
		v87 = v88 ~= nil
	end
	if v87 then
		local v89 = {}
		while p84 and p84:IsA("GuiObject") do
			table.insert(v89, p84)
			p84 = p84.Parent
		end
		local v90
		if p84 and p84:IsA("LayerCollector") then
			v90 = v_u_8.viewport()
		else
			v90 = v_u_8.refSize()
		end
		for v91 = #v89, 1, -1 do
			local v92 = v89[v91]
			local v93 = v92.Parent
			if v93 and v93:IsA("GuiObject") then
				local v94 = v93:FindFirstChildOfClass("UIPadding")
				if v94 then
					v90 = Vector2.new(v90.X - (v94.PaddingLeft.Scale + v94.PaddingRight.Scale) * v90.X - v94.PaddingLeft.Offset - v94.PaddingRight.Offset, v90.Y - (v94.PaddingTop.Scale + v94.PaddingBottom.Scale) * v90.Y - v94.PaddingTop.Offset - v94.PaddingBottom.Offset)
				end
			end
			local v95 = v92.Size
			v90 = Vector2.new(v90.X * v95.X.Scale + v95.X.Offset, v90.Y * v95.Y.Scale + v95.Y.Offset)
			local v96 = v92:FindFirstChildOfClass("UISizeConstraint")
			if not v96 then
				continue
			end
			local v97 = Vector2.new
			local v98 = v90.X
			local v99 = v96.MinSize.X
			local v100 = v96.MaxSize.X
			local v101 = math.clamp(v98, v99, v100)
			local v102 = v90.Y
			local v103 = v96.MinSize.Y
			local v104 = v96.MaxSize.Y
			v90 = v97(v101, (math.clamp(v102, v103, v104)))
		end
		return v90
	else
		local v105 = p84.AbsoluteSize
		if v105.X > 10 and v105.Y > 10 then
			return v105 / v85
		else
			return v_u_8.refSize()
		end
	end
end
local function v_u_127() -- name: overlay
	-- upvalues: (ref) v_u_81, (ref) v_u_82, (ref) v_u_83, (copy) v_u_21, (copy) v_u_8
	if v_u_81 and (v_u_81.Parent and (v_u_82 and v_u_83)) then
		return v_u_82, v_u_83
	end
	local v107 = v_u_21
	if v107 then
		v107 = v_u_21:FindFirstChildOfClass("PlayerGui")
	end
	local v108 = {
		["Name"] = "HushInventoryOverlay",
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = false,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = nil,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["DisplayOrder"] = v_u_8.layer.inventory + 5
	}
	local v109 = Instance.new("ScreenGui")
	if v108 then
		for v110, v111 in v108 do
			v109[v110] = v111
		end
	end
	local v112 = {
		["Name"] = "Raw",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v113 = Instance.new("Frame")
	if v112 then
		for v114, v115 in v112 do
			v113[v114] = v115
		end
	end
	if v109 then
		v113.Parent = v109
	end
	local v116 = {
		["Name"] = "Scaled",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_117 = Instance.new("Frame")
	if v116 then
		for v118, v119 in v116 do
			v_u_117[v118] = v119
		end
	end
	if v109 then
		v_u_117.Parent = v109
	end
	local v120 = {
		["Scale"] = v_u_8.uiScale()
	}
	local v_u_121 = Instance.new("UIScale")
	if v120 then
		for v122, v123 in v120 do
			v_u_121[v122] = v123
		end
	end
	if v_u_117 then
		v_u_121.Parent = v_u_117
	end
	local function v125() -- name: refresh
		-- upvalues: (ref) v_u_8, (copy) v_u_121, (copy) v_u_117
		local v124 = v_u_8.uiScale()
		v_u_121.Scale = v124
		v_u_117.Size = UDim2.fromScale(1 / v124, 1 / v124)
	end
	v_u_8.scaleChanged:Connect(v125)
	v109:GetPropertyChangedSignal("AbsoluteSize"):Connect(v125)
	v109.Parent = v107 or game:GetService("StarterGui")
	local v126 = v_u_8.uiScale()
	v_u_121.Scale = v126
	v_u_117.Size = UDim2.fromScale(1 / v126, 1 / v126)
	v_u_81 = v109
	v_u_82 = v_u_117
	v_u_83 = v113
	return v_u_117, v113
end
local v_u_128 = nil
local v_u_129 = {}
local v_u_130 = {
	["task"] = {},
	["glow"] = {}
}
local v_u_131 = nil
local v_u_132 = {}
local v_u_133 = nil
local v_u_134 = nil
local v_u_135 = nil
local v_u_136 = {}
local v_u_137 = nil
local v_u_138 = nil
local function v_u_147() -- name: pruneMounts
	-- upvalues: (copy) v_u_136
	for v139 = #v_u_136, 1, -1 do
		local v140 = v_u_136[v139]
		if not (v140 and v140.destroy) then
			continue
		end
		local v141
		if v140.dead or v140.gone then
			v141 = false
		else
			local v142 = v140.root
			if v142 and v142.Parent ~= nil then
				v141 = (not v140.layer or v140.layer.gui.Parent ~= nil) and true or false
			else
				v141 = false
			end
		end
		if v141 then
			continue
		end
		local v143 = v140.destroy
		local v144, v145 = pcall(v143)
		if not v144 then
			warn("[InventoryUI] destroy of a stale mount failed:", v145)
		end
		local v146 = table.find(v_u_136, v140)
		if not v146 then
			continue
		end
		table.remove(v_u_136, v146)
	end
end
local v_u_148 = nil
local v_u_149 = nil
local v_u_150 = nil
local v_u_151 = nil
local v_u_152 = {}
local v_u_153 = 0
local v_u_154 = nil
local v_u_155 = -1
local v_u_156 = nil
local v_u_157 = nil
local v_u_158 = Vector2.zero
local v_u_159 = nil
local v_u_160 = nil
local function v_u_164() -- name: closeContext
	-- upvalues: (ref) v_u_154
	if v_u_154 then
		local v161 = v_u_154:FindFirstChild("PadReturn")
		local v162 = game:GetService("GuiService")
		local v163
		if v162.SelectedObject == nil then
			v163 = false
		else
			v163 = v162.SelectedObject:IsDescendantOf(v_u_154)
		end
		v_u_154:Destroy()
		v_u_154 = nil
		if v163 then
			if v161 then
				v161 = v161.Value
			end
			if not (v161 and (v161:IsA("GuiObject") and v161.Parent)) then
				v161 = nil
			end
			v162.SelectedObject = v161
		end
	end
end
local function v_u_175(p165, p166) -- name: locate
	-- upvalues: (copy) v_u_33
	if type(p165) ~= "table" or not p166 then
		return nil
	end
	for _, v167 in v_u_33 do
		local v168 = v167.id
		local v169
		if type(p165) == "table" then
			v169 = p165.kit or nil
		else
			v169 = nil
		end
		local v170
		if v169 then
			v170 = v169.slots
			if v170 then
				v170 = v169.slots[v168]
			end
			if v170 == nil then
				v170 = v169[v168]
			end
			if type(v170) ~= "table" then
				v170 = nil
			end
		else
			v170 = nil
		end
		if not v170 or v170.uid ~= p166 then
			continue
		end
		return {
			["kind"] = "slot",
			["slot"] = nil,
			["item"] = nil,
			["slot"] = v167.id,
			["item"] = v170
		}
	end
	for v171, v172 in p165.containers or {} do
		if type(v172) ~= "table" then
			continue
		end
		local v173 = v172.items
		if type(v173) ~= "table" then
			continue
		end
		for _, v174 in v172.items do
			if v174.uid ~= p166 then
				continue
			end
			return {
				["kind"] = "grid",
				["container"] = nil,
				["item"] = nil,
				["c"] = nil,
				["container"] = v171,
				["item"] = v174,
				["c"] = v172
			}
		end
	end
	return nil
end
local v_u_176 = {
	["setquick"] = "setQuick",
	["drop"] = "discard"
}
local v_u_177 = 0
local v_u_178 = nil
local v_u_179 = nil
local v_u_180 = nil
local v_u_188 = {
	["Pred"] = require(v_u_7:WaitForChild("InvUIPredict")),
	["Plus"] = require(v_u_7:WaitForChild("InvUIStorePlus")),
	["Pouch"] = require(v_u_7:WaitForChild("InvUIPouch")),
	["wishText"] = function(p181, p182, p183)
		-- upvalues: (copy) v_u_6, (copy) v_u_130
		local function v184()
			-- upvalues: (ref) v_u_6
			return require(v_u_6:WaitForChild("TraderHints", 2))
		end
		local v185, v186 = pcall(v184)
		local v187 = v_u_130.task[p183] == true
		if v185 and type(v186) == "table" then
			if p181 == "label" then
				return v186.wishLabel(p182, v187)
			elseif p181 == "body" then
				return v186.wishBody(p182, v187)
			else
				return v186.removedNote(v187)
			end
		else
			return p181 == "label" and (p182 and "Remove from needed" or "Mark as needed") or ""
		end
	end
}
local function v_u_198(p189, p190) -- name: send
	-- upvalues: (ref) v_u_20, (copy) v_u_188, (copy) v_u_175, (copy) v_u_9, (copy) v_u_176, (ref) v_u_177, (ref) v_u_178
	if v_u_20 then
		local v191 = v_u_188.Pred
		if p189.mode == "raid" then
			v191.record("raid", p190)
			local v192 = v_u_20.net.fire
			pcall(v192, "inv.op", p190)
			if p190.op == "use" then
				local v193 = p189.work
				if v193 then
					v193 = v_u_175(p189.work, p190.uid)
				end
				local v194 = v191.useFeedback
				if v193 then
					v193 = v_u_9.get(v193.item.id)
				end
				v194(v193)
			end
		else
			local v195 = table.clone(p190)
			v195.op = v_u_176[p190.op] or p190.op
			local v196 = p190.op == "setquick" and (p190.uid == nil or p190.uid == "") and {
				["op"] = "clearQuick",
				["index"] = nil,
				["index"] = p190.index
			} or v195
			v_u_177 = v_u_177 + 1
			v196.req = "invui_" .. v_u_177
			v191.record("menu", p190, v196.req)
			local v197 = v_u_20.net.fire
			pcall(v197, "menu.op", v196)
		end
		if p190.op ~= "move" and (p189.work and (not p189.fake and v191.applyNow(p189.work, p190, p189.mode))) then
			v_u_178(p189)
		end
	end
end
local function v_u_212(p199, p200, p201, p202, p203, p204) -- name: predictMove
	-- upvalues: (copy) v_u_175, (copy) v_u_10, (ref) v_u_178, (copy) v_u_188
	local v205 = p199.work
	if v205 then
		local v206 = v_u_175(v205, p200)
		local v207 = v205.containers
		if v207 then
			v207 = v205.containers[p201]
		end
		if v206 and type(v207) == "table" then
			local v208 = v206.item
			local v209 = v_u_10.itemAt(v207, p202, p203, p200)
			if v209 and v_u_10.canStack(v208, v209) then
				v_u_10.merge(v208, v209)
				if (v208.n or 0) > 0 then
					v_u_178(p199)
					return
				end
			elseif not v_u_10.fits(v207, v208, p202, p203, p204, p200) or v_u_188.Search.blocksItem(v207, v208, p202, p203, p204) then
				return
			end
			if v206.kind == "grid" then
				v_u_10.remove(v206.c, p200)
			elseif v206.kind == "slot" then
				local v210 = v205.kit
				if v210.slots then
					v210.slots[v206.slot] = nil
				end
				v210[v206.slot] = nil
			end
			if (v208.n or 1) > 0 and (not v209 or (v209.uid == p200 or not v_u_10.canStack(v208, v209))) then
				v208.x = p202
				v208.y = p203
				v208.r = p204
				local v211 = v207.items
				table.insert(v211, v208)
			end
			v_u_178(p199)
		end
	else
		return
	end
end
local function v215(p213) -- name: wishedId
	-- upvalues: (copy) v_u_132, (ref) v_u_129
	local v214 = v_u_132[p213]
	if v214 and os.clock() - v214.t < 4 then
		return v214.on
	else
		return v_u_129[p213] == true
	end
end
local function v_u_228(p216, p217) -- name: setWishId
	-- upvalues: (copy) v_u_132, (ref) v_u_20, (copy) v_u_11, (copy) v_u_21, (ref) v_u_133
	v_u_132[p216] = {
		["on"] = p217,
		["t"] = os.clock()
	}
	local v218 = false
	local v219 = v_u_20
	if v219 then
		v219 = v_u_20.controllers
	end
	local v220 = v219 and v219.Menu or nil
	if v220 then
		local v221 = v220.setWish
		if type(v221) == "function" then
			local v222 = v220.isWished
			if type(v222) == "function" then
				local v223 = v220.setWish
				pcall(v223, p216, p217)
				local v224 = v220.isWished
				local v225
				v218, v225 = pcall(v224, p216)
				if v218 then
					v218 = v225 == p217
				end
			end
		end
	end
	if not v218 and (v_u_20 and v_u_20.net) then
		local v226 = v_u_20.net.fire
		pcall(v226, "menu.op", {
			["op"] = "wish",
			["id"] = nil,
			["on"] = nil,
			["id"] = p216,
			["on"] = p217
		})
		local v227 = v_u_11.sound
		pcall(v227, p217 and "confirm" or "click")
	end
	v_u_21:SetAttribute("InvUILastWish", p216 .. "=" .. tostring(p217))
	v_u_133()
	task.delay(4.2, function()
		-- upvalues: (ref) v_u_133
		v_u_133()
	end)
end
v_u_188.Att = require(v_u_7:WaitForChild("InvUIAttach"))
v_u_188.Strip = require(v_u_7:WaitForChild("InvUIStrip"))
v_u_188.Dbg = require(v_u_7:WaitForChild("InvUIDebug"))
v_u_188.Map = require(v_u_7:WaitForChild("InvUIMap"))
v_u_188.Pad = require(v_u_7:WaitForChild("InvUIPad"))
v_u_188.Click = require(v_u_7:WaitForChild("InvUIClick"))
v_u_188.Move = require(v_u_7:WaitForChild("InvUIMoveAll"))
v_u_188.Insure = require(v_u_7:WaitForChild("InvUIInsure"))
v_u_188.Why = require(v_u_7:WaitForChild("InvUIWhy"))
v_u_188.TD = require(v_u_7:WaitForChild("InvUITouchDrag"))
v_u_188.Case = require(v_u_7:WaitForChild("InvUICase"))
v_u_188.Layers = require(v_u_7:WaitForChild("InvLayerRules"))
v_u_188.Skins = require(v_u_7:WaitForChild("InvUISkins"))
v_u_188.CaseOpen = require(v_u_7:WaitForChild("InvUICaseOpen"))
v_u_188.StashHints = require(v_u_7:WaitForChild("InvUIStashHints"))
v_u_188.Gun = require(v_u_7:WaitForChild("InvUIGunsmith"))
v_u_188.Search = require(v_u_7:WaitForChild("InvUISearch"))
v_u_188.Zoom = require(v_u_7:WaitForChild("InvUIZoom"))
v_u_188.Lock = require(v_u_7:WaitForChild("InvUILock"))
v_u_188.TutPick = require(v_u_7:WaitForChild("InvUITutorialPick"))
local v232 = {
	["send"] = function(p229, p230) -- name: send
		-- upvalues: (copy) v_u_198
		v_u_198(p229, p230)
	end,
	["render"] = function(p231) -- name: render
		-- upvalues: (ref) v_u_178
		v_u_178(p231)
	end
}
v_u_188.Lock.env = v232
v_u_188.Roll = require(v_u_7:WaitForChild("InvUIRoll"))
v_u_188.Roll.env = {
	["send"] = function(p233, p234) -- name: send
		-- upvalues: (copy) v_u_198
		v_u_198(p233, p234)
	end
}
function v_u_188.fullBag(p235) -- name: fullBag
	-- upvalues: (copy) v_u_9
	if type(p235) == "table" then
		local v236 = p235.items
		if type(v236) == "table" and #p235.items ~= 0 then
			local v237 = v_u_9.get(p235.id)
			local v238
			if v237 == nil or v237.grid == nil then
				v238 = false
			else
				v238 = v237.category ~= "secure"
			end
			return v238
		end
	end
	return false
end
function v_u_188.canOpen(p239, p240) -- name: canOpen
	-- upvalues: (copy) v_u_29, (copy) v_u_9
	if p239.mode == "raid" and (p240 ~= nil and (p240.kind == "grid" and not table.find(v_u_29, p240.container))) then
		local v241 = p240.c
		if type(v241) == "table" and p240.c.sub ~= true then
			local v242 = v_u_9.get(p240.item.id)
			local v243
			if v242 == nil or v242.grid == nil then
				v243 = false
			else
				v243 = v242.category ~= "secure"
			end
			return v243
		end
	end
	return false
end
function v_u_188.viewId(p244) -- name: viewId
	return "sub:" .. p244
end
function v_u_188.isOpen(p245, p246) -- name: isOpen
	-- upvalues: (copy) v_u_188
	local v247 = p245.work
	local v248
	if type(v247) == "table" then
		local v249 = v247.containers
		if type(v249) == "table" then
			v248 = v247.containers[v_u_188.viewId(p246)] ~= nil
		else
			v248 = false
		end
	else
		v248 = false
	end
	return v248
end
function v_u_188.closeText(p250) -- name: closeText
	-- upvalues: (copy) v_u_9
	local v251 = v_u_9.get(p250.id)
	return v251 and v251.equip == "armor" and "Close rig" or "Close bag"
end
v_u_188.Att.env = {
	["new"] = v_u_40,
	["label"] = v_u_74,
	["stroke"] = v_u_60,
	["sound"] = v_u_43,
	["send"] = v_u_198,
	["C"] = v_u_18,
	["Theme"] = v_u_8,
	["ItemIcons"] = v_u_12
}
v_u_188.attachBlock = v_u_188.Att.attachBlock
local function v_u_288(p252, p253) -- name: actionsFor
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (copy) v_u_188, (copy) v_u_132, (ref) v_u_129, (copy) v_u_16, (copy) v_u_11, (copy) v_u_10, (copy) v_u_13, (ref) v_u_20
	local v254 = {}
	local v255 = v_u_175(p252.work, p253)
	if not v255 then
		return v254
	end
	local v256 = v255.item
	local v257 = v_u_9.get(v256.id)
	if not v257 then
		return v254
	end
	table.insert(v254, {
		["id"] = "inspect",
		["text"] = "Inspect"
	})
	local v258 = {
		["id"] = "wish",
		["text"] = nil
	}
	local v259 = v_u_188.wishText
	local v260 = "label"
	local v261 = v256.id
	local v262 = v_u_132[v261]
	local v263
	if v262 and os.clock() - v262.t < 4 then
		v263 = v262.on
	else
		v263 = v_u_129[v261] == true
	end
	v258.text = v259(v260, v263, v256.id)
	table.insert(v254, v258)
	if v255.container == "ground" then
		if v_u_9.equipSlot(v257) and v257.equip ~= "secure" then
			local v264 = {
				["id"] = "equip",
				["text"] = nil
			}
			local v265 = p252.work
			local v266 = v_u_9.get(v256.id)
			if v266 then
				v266 = v_u_9.equipSlot(v266)
			end
			local v267
			if v266 then
				local v268
				if type(v265) == "table" then
					v268 = v265.kit or nil
				else
					v268 = nil
				end
				if v268 then
					v267 = v268.slots
					if v267 then
						v267 = v268.slots[v266]
					end
					if v267 == nil then
						v267 = v268[v266]
					end
					if type(v267) ~= "table" then
						v267 = nil
					end
				else
					v267 = nil
				end
				if not v267 or v267.uid == v256.uid then
					v267 = nil
				end
			else
				v267 = nil
			end
			v264.text = v267 and "Swap" or "Equip"
			table.insert(v254, v264)
		end
		if v_u_188.canOpen(p252, v255) then
			local v269 = v_u_188.isOpen(p252, p253) and {
				["id"] = "closebag",
				["text"] = nil,
				["text"] = v_u_188.closeText(v256)
			} or {
				["id"] = "openbag",
				["text"] = "Open"
			}
			table.insert(v254, v269)
		end
		table.insert(v254, {
			["id"] = "quick",
			["text"] = "Take"
		})
		v_u_16.groundActs(v254, v256, v257)
		if p252.mode == "raid" and v257.category == "medical" then
			table.insert(v254, {
				["id"] = "use",
				["text"] = "Use"
			})
		end
		table.insert(v254, {
			["id"] = "ping",
			["text"] = "Ping for squad"
		})
		return v254
	end
	if p252.mode == "raid" and v255.kind == "grid" then
		local v270 = v255.c
		if type(v270) == "table" and v255.c.world == true then
			if v_u_188.canOpen(p252, v255) then
				local v271 = v_u_188.isOpen(p252, p253) and {
					["id"] = "closebag",
					["text"] = nil,
					["text"] = v_u_188.closeText(v256)
				} or {
					["id"] = "openbag",
					["text"] = "Open"
				}
				table.insert(v254, v271)
			end
			table.insert(v254, {
				["id"] = "ping",
				["text"] = "Ping for squad"
			})
		end
	end
	if v255.kind == "slot" then
		if v255.slot ~= "secure" then
			table.insert(v254, {
				["id"] = "unequip",
				["text"] = "Unequip"
			})
		end
	elseif v_u_9.equipSlot(v257) and (p252.mode ~= "raid" or v257.equip ~= "secure") then
		table.insert(v254, {
			["id"] = "equip",
			["text"] = "Equip"
		})
	end
	if v257.category == "attachment" and v_u_188.Att.canSource(v255, "ground") then
		local v272 = 0
		for _, v273 in v_u_188.Att.targets(p252.work, v256) do
			v272 = v272 + 1
			local v274 = {
				["id"] = v_u_188.Att.ACTION .. v273.uid,
				["text"] = "Attach to " .. v273.short
			}
			table.insert(v254, v274)
		end
		if v272 == 0 then
			local v275 = v_u_188.Why.attachNoneEntry()
			local v276 = {
				["id"] = "attachnone",
				["text"] = nil,
				["say"] = nil,
				["kind"] = "muted",
				["text"] = v275.text,
				["say"] = v275.say
			}
			table.insert(v254, v276)
		end
	end
	if p252.mode == "raid" and v257.category == "medical" then
		table.insert(v254, {
			["id"] = "use",
			["text"] = "Use"
		})
	elseif p252.mode == "raid" and v257.category == "throwable" then
		table.insert(v254, {
			["id"] = "use",
			["text"] = "Throw"
		})
	end
	if v257.category == "firearm" then
		for _, v277 in v_u_16.weaponActs(p252.work, p252.mode, v256, v257, v255) do
			table.insert(v254, v277)
		end
		local v278 = v256.ammo
		if type(v278) == "number" and v256.ammo > 0 then
			table.insert(v254, {
				["id"] = "unload",
				["text"] = "Unload"
			})
		end
		local v279 = v256.mods
		if type(v279) == "table" then
			for v280, v281 in v256.mods do
				local v282
				if type(v281) == "table" then
					v282 = v_u_9.get(v281.id)
				else
					v282 = false
				end
				if not v282 then
					continue
				end
				local v283 = {
					["id"] = "detach:" .. tostring(v280),
					["text"] = "Detach " .. v282.short
				}
				table.insert(v254, v283)
			end
		end
	end
	for _, v284 in v_u_16.stackActs(p252.work, p252.mode, v255, v257) do
		table.insert(v254, v284)
	end
	if v_u_11.device() == "Gamepad" and (v255.kind ~= "slot" or v255.slot ~= "secure") then
		table.insert(v254, {
			["id"] = "padmove",
			["text"] = "Move"
		})
	end
	if v255.kind == "grid" then
		local v285, v286 = v_u_10.size({
			["id"] = nil,
			["r"] = false,
			["uid"] = "",
			["x"] = 0,
			["y"] = 0,
			["n"] = 1,
			["id"] = v256.id
		})
		if v285 ~= v286 then
			table.insert(v254, {
				["id"] = "rotate",
				["text"] = "Rotate"
			})
		end
	end
	if v255.kind == "grid" then
		table.insert(v254, {
			["id"] = "quick",
			["text"] = "Quick move"
		})
		if (v256.n or 1) > 1 then
			table.insert(v254, {
				["id"] = "split",
				["text"] = "Split stack"
			})
		end
		if v_u_188.Why.quickEntryOk(p252.mode, v255.container) then
			table.insert(v254, {
				["id"] = "quickslot",
				["text"] = "Quick slot"
			})
		end
	end
	if p252.mode ~= "raid" and (v255.kind == "grid" and v_u_188.Why.sellOffered(v_u_13.sellQuote(v256))) then
		table.insert(v254, {
			["id"] = "sell",
			["text"] = "Sell"
		})
	end
	v_u_188.Lock.acts(p252, v255, v254)
	v_u_188.Roll.acts(p252, v255, v254)
	v_u_188.Skins.acts(v_u_20, p252, v255, v257, v254)
	v_u_188.CaseOpen.acts(v_u_20, p252, v255, v257, v254)
	v_u_188.Case.acts(p252, v255, v257, v254)
	v_u_188.Insure.acts(v_u_20, p252, v255, v254)
	if v255.kind == "grid" or v255.slot ~= "secure" then
		local v287 = {
			["id"] = "drop",
			["text"] = nil,
			["kind"] = "danger",
			["text"] = p252.mode ~= "raid" and "Discard" or "Drop"
		}
		table.insert(v254, v287)
	end
	return v254
end
local v_u_289 = nil
local v_u_290 = nil
local function v_u_325(p291, p292) -- name: firstFreeQuick
	local v293 = p291.work
	local v294
	if type(v293) == "table" then
		v294 = v293.kit or nil
	else
		v294 = nil
	end
	local v295
	if v294 then
		local v296 = v294.quick
		v295 = type(v296) == "table" and v296[1] or v294["quick" .. 1]
		if type(v295) ~= "string" or v295 == "" then
			v295 = nil
		end
	else
		v295 = nil
	end
	if v295 == p292 then
		return 2
	end
	local v297 = p291.work
	local v298
	if type(v297) == "table" then
		v298 = v297.kit or nil
	else
		v298 = nil
	end
	local v299
	if v298 then
		local v300 = v298.quick
		v299 = type(v300) == "table" and v300[2] or v298["quick" .. 2]
		if type(v299) ~= "string" or v299 == "" then
			v299 = nil
		end
	else
		v299 = nil
	end
	if v299 == p292 then
		return 3
	end
	local v301 = p291.work
	local v302
	if type(v301) == "table" then
		v302 = v301.kit or nil
	else
		v302 = nil
	end
	local v303
	if v302 then
		local v304 = v302.quick
		v303 = type(v304) == "table" and v304[3] or v302["quick" .. 3]
		if type(v303) ~= "string" or v303 == "" then
			v303 = nil
		end
	else
		v303 = nil
	end
	if v303 == p292 then
		return 4
	end
	local v305 = p291.work
	local v306
	if type(v305) == "table" then
		v306 = v305.kit or nil
	else
		v306 = nil
	end
	local v307
	if v306 then
		local v308 = v306.quick
		v307 = type(v308) == "table" and v308[4] or v306["quick" .. 4]
		if type(v307) ~= "string" or v307 == "" then
			v307 = nil
		end
	else
		v307 = nil
	end
	if v307 == p292 then
		return 1
	end
	local v309 = p291.work
	local v310
	if type(v309) == "table" then
		v310 = v309.kit or nil
	else
		v310 = nil
	end
	local v311
	if v310 then
		local v312 = v310.quick
		v311 = type(v312) == "table" and v312[1] or v310["quick" .. 1]
		if type(v311) ~= "string" or v311 == "" then
			v311 = nil
		end
	else
		v311 = nil
	end
	if not v311 then
		return 1
	end
	local v313 = p291.work
	local v314
	if type(v313) == "table" then
		v314 = v313.kit or nil
	else
		v314 = nil
	end
	local v315
	if v314 then
		local v316 = v314.quick
		v315 = type(v316) == "table" and v316[2] or v314["quick" .. 2]
		if type(v315) ~= "string" or v315 == "" then
			v315 = nil
		end
	else
		v315 = nil
	end
	if not v315 then
		return 2
	end
	local v317 = p291.work
	local v318
	if type(v317) == "table" then
		v318 = v317.kit or nil
	else
		v318 = nil
	end
	local v319
	if v318 then
		local v320 = v318.quick
		v319 = type(v320) == "table" and v320[3] or v318["quick" .. 3]
		if type(v319) ~= "string" or v319 == "" then
			v319 = nil
		end
	else
		v319 = nil
	end
	if not v319 then
		return 3
	end
	local v321 = p291.work
	local v322 = type(v321) == "table" and v321.kit or nil
	local v323
	if v322 then
		local v324 = v322.quick
		v323 = type(v324) == "table" and v324[4] or v322["quick" .. 4]
		if type(v323) ~= "string" or v323 == "" then
			v323 = nil
		end
	else
		v323 = nil
	end
	return v323 and 1 or 4
end
local function v_u_379(p_u_326, p_u_327, p328, p329) -- name: runAction
	-- upvalues: (copy) v_u_175, (copy) v_u_188, (ref) v_u_20, (copy) v_u_9, (copy) v_u_198, (copy) v_u_11, (copy) v_u_152, (copy) v_u_29, (copy) v_u_17, (copy) v_u_47, (copy) v_u_132, (ref) v_u_129, (copy) v_u_228, (ref) v_u_289, (copy) v_u_19, (copy) v_u_16, (ref) v_u_290, (copy) v_u_325, (copy) v_u_8
	local v330 = v_u_175(p_u_326.work, p_u_327)
	if v330 and not (v_u_188.Lock.run(p_u_326, p_u_327, p328) or (v_u_188.Roll.run(p_u_326, p_u_327, p328) or (v_u_188.Skins.run(v_u_20, v330, p328) or (v_u_188.CaseOpen.run(v_u_20, v330, p328) or v_u_188.Case.run(p_u_326, p_u_327, p328))))) then
		if p328 == "quick" and (v_u_188.canOpen(p_u_326, v330) and v_u_188.fullBag(v330.item)) then
			local v331 = p_u_326.work
			local v332 = v330.item
			local v333 = v_u_9.get(v332.id)
			if v333 then
				v333 = v_u_9.equipSlot(v333)
			end
			local v334
			if v333 then
				local v335
				if type(v331) == "table" then
					v335 = v331.kit or nil
				else
					v335 = nil
				end
				if v335 then
					v334 = v335.slots
					if v334 then
						v334 = v335.slots[v333]
					end
					if v334 == nil then
						v334 = v335[v333]
					end
					if type(v334) ~= "table" then
						v334 = nil
					end
				else
					v334 = nil
				end
				if not v334 or v334.uid == v332.uid then
					v334 = nil
				end
			else
				v334 = nil
			end
			p328 = v334 ~= nil and "openbag" or p328
		end
		if p328 == "openbag" or p328 == "closebag" then
			local v336 = v_u_188.viewId(p_u_327)
			if p328 == "openbag" then
				v_u_198(p_u_326, {
					["op"] = "open",
					["container"] = nil,
					["container"] = v336
				})
				p_u_326.pendingSub = v336
				local v337 = v_u_11.sound
				pcall(v337, "open")
			else
				v_u_198(p_u_326, {
					["op"] = "close",
					["container"] = nil,
					["container"] = v336
				})
				local v338 = v_u_11.sound
				pcall(v338, "close")
			end
		else
			local v339 = v_u_152[p_u_327]
			if v339 and (os.clock() - v339 < 0.6 and (p328 ~= "inspect" and (p328 ~= "ping" and p328 ~= "wish"))) then
				return
			else
				local v340
				if p_u_326.mode == "raid" and (v330 ~= nil and v330.kind == "grid") then
					v340 = not table.find(v_u_29, v330.container)
				else
					v340 = false
				end
				if v340 and (p328 == "quick" or (p328 == "equip" or p328 == "use")) then
					local v341 = os.clock()
					for v342, v343 in v_u_152 do
						if v341 - v343 <= 0.6 then
							continue
						end
						v_u_152[v342] = nil
					end
					v_u_152[p_u_327] = v341
				end
				local v344 = v330.item
				local v345 = v_u_9.get(v344.id)
				if p328 == "ping" then
					local v346 = v_u_17.ping
					local v347 = v_u_20
					if v347 then
						v347 = v_u_20.controllers
					end
					if v346(v330, v347 and v347.Comms or nil, v_u_47) then
						local v348 = v_u_11.sound
						pcall(v348, "confirm")
					end
					return
				elseif p328 == "wish" then
					local v349 = v344.id
					local v350 = v_u_132[v349]
					local v351
					if v350 and os.clock() - v350.t < 4 then
						v351 = v350.on
					else
						v351 = v_u_129[v349] == true
					end
					v_u_228(v344.id, not v351)
					if v351 then
						local v352 = v_u_188.wishText("note", false, v344.id)
						if v352 ~= "" then
							local v353 = v_u_11.toast
							pcall(v353, v352, "info")
						end
					end
					return
				elseif v330.container == "ground" and (p328 ~= "inspect" and (p328 ~= "equip" and (p328 ~= "quick" and (p328 ~= "use" and p328 ~= "unload")))) then
					local v354 = v_u_11.sound
					pcall(v354, "error")
					return
				elseif p328 == "inspect" then
					v_u_289(p_u_326, p_u_327)
					return
				elseif p328 == "padmove" then
					v_u_188.Pad.begin(p_u_326, p_u_327, v_u_188.padApi())
					return
				elseif p328 == "rotate" then
					v_u_188.rotateIn(p_u_326, p_u_327)
					return
				elseif p328 == "equip" then
					v_u_198(p_u_326, {
						["op"] = "equip",
						["uid"] = nil,
						["slot"] = nil,
						["uid"] = p_u_327,
						["slot"] = v345 and v_u_9.equipSlot(v345) or nil
					})
					local v355 = v_u_11.sound
					pcall(v355, "click")
					return
				elseif p328 == "unequip" then
					v_u_198(p_u_326, {
						["op"] = "unequip",
						["slot"] = nil,
						["slot"] = v330.slot
					})
					local v356 = v_u_11.sound
					pcall(v356, "click")
				elseif p328 == "use" then
					v_u_198(p_u_326, {
						["op"] = "use",
						["uid"] = nil,
						["uid"] = p_u_327
					})
					local v357 = v_u_11.sound
					pcall(v357, "click")
					if v345 and (v345.category == "throwable" and p_u_326.mode == "raid") then
						v_u_19.close()
						return
					end
				else
					if p328 == "load" then
						v_u_198(p_u_326, {
							["op"] = "load",
							["weaponUid"] = nil,
							["weaponUid"] = p_u_327
						})
						local v358 = v_u_11.sound
						pcall(v358, "click")
						return
					end
					if v_u_16.opFor(p328, p_u_327, v344) then
						v_u_198(p_u_326, v_u_16.opFor(p328, p_u_327, v344))
						local v359 = v_u_11.sound
						pcall(v359, "click")
						return
					end
					if p328 == "unload" then
						v_u_198(p_u_326, {
							["op"] = "unload",
							["weaponUid"] = nil,
							["weaponUid"] = p_u_327
						})
						local v360 = v_u_11.sound
						pcall(v360, "click")
						return
					end
					local v361 = #v_u_188.Att.ACTION
					if string.sub(p328, 1, v361) == v_u_188.Att.ACTION then
						local v362 = v_u_198
						local v363 = {
							["op"] = "attach",
							["uid"] = nil,
							["weaponUid"] = nil,
							["uid"] = p_u_327
						}
						local v364 = #v_u_188.Att.ACTION + 1
						v363.weaponUid = string.sub(p328, v364)
						v362(p_u_326, v363)
						local v365 = v_u_11.sound
						pcall(v365, "confirm")
						return
					end
					if string.sub(p328, 1, 7) == "detach:" then
						v_u_198(p_u_326, {
							["op"] = "detach",
							["weaponUid"] = nil,
							["slot"] = nil,
							["weaponUid"] = p_u_327,
							["slot"] = string.sub(p328, 8)
						})
						local v366 = v_u_11.sound
						pcall(v366, "click")
						return
					end
					if p328 == "quick" then
						if not v_u_188.Click.quickAsk(p_u_326, p_u_327, v_u_198) then
							v_u_198(p_u_326, {
								["op"] = "quick",
								["uid"] = nil,
								["uid"] = p_u_327
							})
							local v367 = v_u_11.sound
							pcall(v367, "click")
						end
					end
					if p328 == "sell" then
						local v368 = v_u_20.controllers.Menu.openTraders
						pcall(v368, "sell")
						return
					end
					if p328 == "insure" then
						v_u_188.Insure.open(v_u_20, p_u_327)
						return
					end
					if p328 == "split" then
						v_u_290(p_u_326, p_u_327)
						return
					end
					if p328 == "quickslot" then
						if type(p329) ~= "number" then
							p329 = v_u_325(p_u_326, p_u_327)
						end
						v_u_198(p_u_326, {
							["op"] = "setquick",
							["uid"] = nil,
							["index"] = nil,
							["uid"] = p_u_327,
							["index"] = p329
						})
						local v369 = v_u_11.sound
						pcall(v369, "confirm")
						return
					end
					if p328 == "drop" then
						if p_u_326.mode ~= "raid" then
							local v370 = v345 and v345.name or "item"
							local v371
							if v330.kind == "slot" then
								v371 = p_u_326.work.containers
								if v371 then
									v371 = p_u_326.work.containers[({
										["bag"] = "lo_bag",
										["armor"] = "lo_vest"
									})[v330.slot] or ""]
								end
							else
								v371 = v344
							end
							local v372 = v_u_11.modal
							local v373 = {
								["title"] = "Discard item",
								["body"] = nil,
								["kind"] = "danger",
								["buttons"] = nil,
								["body"] = v_u_188.Why.discardBody(v370, v344.n, v_u_188.Why.countInside(v371)),
								["buttons"] = {
									{
										["text"] = "Discard",
										["kind"] = "danger",
										["onClick"] = nil,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) v_u_198, (copy) p_u_326, (copy) p_u_327
											v_u_198(p_u_326, {
												["op"] = "drop",
												["uid"] = nil,
												["uid"] = p_u_327
											})
										end
									},
									{
										["text"] = "Cancel",
										["kind"] = "ghost"
									}
								}
							}
							pcall(v372, v373)
							return
						end
						if v_u_188.Click.touchDropAsks({
							["raid"] = p_u_326.mode == "raid",
							["touch"] = v_u_8.isTouch(),
							["loc"] = v330
						}) and v_u_188.gearGuard() then
							local v374 = not v345 and "this item" or v345.name
							local v375 = v_u_11.modal
							local v377 = {
								["title"] = nil,
								["body"] = "It stays on the ground where you stand. Anyone can take it.",
								["kind"] = "danger",
								["buttons"] = nil,
								["title"] = "Drop " .. v374 .. "?",
								["buttons"] = {
									{
										["text"] = "Drop",
										["kind"] = "danger",
										["onClick"] = nil,
										["onClick"] = function() -- name: onClick
											-- upvalues: (ref) v_u_198, (copy) p_u_326, (copy) p_u_327, (ref) v_u_11
											v_u_198(p_u_326, {
												["op"] = "drop",
												["uid"] = nil,
												["uid"] = p_u_327
											})
											local v376 = v_u_11.sound
											pcall(v376, "close")
										end
									},
									{
										["text"] = "Cancel",
										["kind"] = "ghost"
									}
								}
							}
							pcall(v375, v377)
							return
						end
						v_u_198(p_u_326, {
							["op"] = "drop",
							["uid"] = nil,
							["uid"] = p_u_327
						})
						local v378 = v_u_11.sound
						pcall(v378, "close")
					end
				end
			end
		end
	else
		return
	end
end
local function v_u_385(p380, p381) -- name: primaryAction
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (copy) v_u_29, (copy) v_u_379, (copy) v_u_188
	local v382 = v_u_175(p380.work, p381)
	if v382 then
		local v383 = v_u_9.get(v382.item.id)
		local v384
		if p380.mode == "raid" and (v382 ~= nil and v382.kind == "grid") then
			v384 = not table.find(v_u_29, v382.container)
		else
			v384 = false
		end
		if v384 then
			v_u_379(p380, p381, v_u_188.Pred.lootUse(p380.mode, v383) and "use" or "quick")
		elseif v382.kind == "slot" then
			if v382.slot ~= "secure" then
				v_u_379(p380, p381, "unequip")
				return
			end
		else
			if v_u_188.Case.openable(p380, v382, v383) then
				v_u_379(p380, p381, "caseopen")
				return
			end
			if v383 and (v_u_9.equipSlot(v383) and (p380.mode ~= "raid" or v383.equip ~= "secure")) then
				v_u_379(p380, p381, "equip")
				return
			end
			if v383 and (v383.category == "medical" and p380.mode == "raid") then
				v_u_379(p380, p381, "use")
				return
			end
			if v383 and v383.category == "throwable" then
				v_u_379(p380, p381, "quickslot")
				return
			end
			if v_u_188.Case.openable(p380, v382, v383) then
				v_u_379(p380, p381, "caseopen")
				return
			end
			v_u_379(p380, p381, "quick")
		end
	else
		return
	end
end
function v_u_188.mouseDouble(p386, p387) -- name: mouseDouble
	-- upvalues: (copy) v_u_175, (copy) v_u_29, (copy) v_u_188, (copy) v_u_9, (copy) v_u_379
	local v388 = v_u_175(p386.work, p387)
	local v389
	if v388 then
		v389 = v388.item
	else
		v389 = v388
	end
	if v388 then
		local v390
		if p386.mode == "raid" and (v388 ~= nil and v388.kind == "grid") then
			v390 = not table.find(v_u_29, v388.container)
		else
			v390 = false
		end
		if not v390 and v_u_188.Case.openable(p386, v388, v_u_9.get(v389.id)) then
			v_u_379(p386, p387, "caseopen")
			return
		end
	end
	local v391
	if v388 then
		local v392 = v_u_188.Click.mouseAction
		local v393 = {
			["loc"] = v388,
			["def"] = v_u_9.get(v389.id),
			["raid"] = p386.mode == "raid"
		}
		local v394
		if p386.mode == "raid" and (v388 ~= nil and v388.kind == "grid") then
			v394 = not table.find(v_u_29, v388.container)
		else
			v394 = false
		end
		v393.loot = v394
		local v395
		if v388.kind == "grid" then
			local v396 = p386.work
			local v397 = v_u_9.get(v389.id)
			if v397 then
				v397 = v_u_9.equipSlot(v397)
			end
			local v398
			if v397 then
				local v399
				if type(v396) == "table" then
					v399 = v396.kit or nil
				else
					v399 = nil
				end
				if v399 then
					v398 = v399.slots
					if v398 then
						v398 = v399.slots[v397]
					end
					if v398 == nil then
						v398 = v399[v397]
					end
					if type(v398) ~= "table" then
						v398 = nil
					end
				else
					v398 = nil
				end
				if not v398 or v398.uid == v389.uid then
					v398 = nil
				end
			else
				v398 = nil
			end
			v395 = v398 ~= nil
		else
			v395 = false
		end
		v393.worn = v395
		local v400 = v_u_188.canOpen(p386, v388) and v_u_188.fullBag(v389)
		if v400 then
			v400 = not v_u_188.isOpen(p386, p387)
		end
		v393.openable = v400
		v391 = v392(v393)
	else
		v391 = v388
	end
	if not v391 and v388 then
		local v401
		if p386.mode == "raid" and (v388 ~= nil and v388.kind == "grid") then
			v401 = not table.find(v_u_29, v388.container)
		else
			v401 = false
		end
		v391 = v401 and v_u_188.Pred.lootUse(p386.mode, v_u_9.get(v389.id)) and "use" or v391
	end
	local v402 = not v391 and (v388 and v_u_188.Case.openable(p386, v388, v_u_9.get(v389.id))) and "caseopen" or v391
	if v402 then
		v_u_379(p386, p387, v402)
	end
end
local function v_u_471(p_u_403, p_u_404, p_u_405, p_u_406) -- name: openContext
	-- upvalues: (copy) v_u_164, (copy) v_u_127, (copy) v_u_288, (copy) v_u_8, (copy) v_u_18, (copy) v_u_60, (copy) v_u_74, (copy) v_u_11, (copy) v_u_379, (copy) v_u_7, (ref) v_u_154, (ref) v_u_155
	v_u_164()
	local v_u_407 = v_u_127()
	local v408
	if p_u_406 then
		v408 = p_u_406.acts
	else
		v408 = v_u_288(p_u_403, p_u_404)
	end
	if #v408 ~= 0 then
		local v_u_409 = v_u_8.uiScale()
		local v410 = 196
		local v411 = not v_u_8.isTouch() and 30 or v_u_8.touch(34)
		local v412 = v_u_8.refSize().Y - 24
		if v412 < #v408 * v411 + 8 and not v_u_8.isTouch() then
			local v413 = (v412 - 8) / #v408
			local v414 = math.floor(v413)
			v411 = math.max(26, v414)
		end
		local v415 = v_u_8.isTouch() and 0 or 4
		if v415 == 0 then
			local v416 = 4 * v411 + 90
			v410 = math.max(v410, v416)
		end
		local v417 = {
			["Name"] = "ContextMenu",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.02,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 50,
			["BackgroundColor3"] = v_u_18.bg,
			["Size"] = UDim2.fromOffset(v410, #v408 * v411 + 8)
		}
		local v_u_418 = Instance.new("Frame")
		if v417 then
			for v419, v420 in v417 do
				v_u_418[v419] = v420
			end
		end
		if v_u_407 then
			v_u_418.Parent = v_u_407
		end
		v_u_60(v_u_418, v_u_18.lineStrong)
		local v421 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 52,
			["BackgroundColor3"] = v_u_18.accent,
			["Size"] = UDim2.new(1, 0, 0, 2)
		}
		local v422 = Instance.new("Frame")
		if v421 then
			for v423, v424 in v421 do
				v422[v423] = v424
			end
		end
		if v_u_418 then
			v422.Parent = v_u_418
		end
		local v425 = 4
		for _, v_u_426 in v408 do
			local v427 = {
				["Name"] = nil,
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["ZIndex"] = 51,
				["Name"] = v_u_426.id,
				["BackgroundColor3"] = v_u_18.raised2,
				["Position"] = UDim2.fromOffset(4, v425),
				["Size"] = UDim2.new(1, -8, 0, v411)
			}
			local v_u_428 = Instance.new("TextButton")
			if v427 then
				for v429, v430 in v427 do
					v_u_428[v429] = v430
				end
			end
			if v_u_418 then
				v_u_428.Parent = v_u_418
			end
			local v431 = v_u_74
			local v432 = v_u_426.text
			local v433 = "bodyStrong"
			local v434 = {
				["position"] = nil,
				["size"] = nil,
				["color"] = nil,
				["zindex"] = 52,
				["position"] = UDim2.fromOffset(12, 0),
				["size"] = UDim2.new(1, -20, 1, 0)
			}
			local v435
			if v_u_426.kind == "danger" then
				v435 = v_u_18.danger
			elseif v_u_426.kind == "current" then
				v435 = v_u_18.accent
			elseif v_u_426.kind == "muted" then
				v435 = v_u_18.muted
			else
				v435 = v_u_18.text
			end
			v434.color = v435
			local v436 = v431(v_u_428, v432, v433, v434)
			v436.ZIndex = 52
			v436.TextYAlignment = Enum.TextYAlignment.Center
			v436.TextTruncate = Enum.TextTruncate.AtEnd
			local v437 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Position"] = nil,
				["ZIndex"] = 53,
				["Visible"] = false,
				["BackgroundColor3"] = v_u_18.accent,
				["Size"] = UDim2.new(0, 2, 1, -8),
				["Position"] = UDim2.fromOffset(0, 4)
			}
			local v_u_438 = Instance.new("Frame")
			if v437 then
				for v439, v440 in v437 do
					v_u_438[v439] = v440
				end
			end
			if v_u_428 then
				v_u_438.Parent = v_u_428
			end
			v_u_428.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_428, (copy) v_u_438, (ref) v_u_11
				v_u_428.BackgroundTransparency = 0
				v_u_438.Visible = true
				local v441 = v_u_11.sound
				pcall(v441, "hover")
			end)
			v_u_428.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_428, (copy) v_u_438
				v_u_428.BackgroundTransparency = 1
				v_u_438.Visible = false
			end)
			v_u_428.SelectionGained:Connect(function()
				-- upvalues: (copy) v_u_428, (copy) v_u_438
				v_u_428.BackgroundTransparency = 0
				v_u_438.Visible = true
			end)
			v_u_428.SelectionLost:Connect(function()
				-- upvalues: (copy) v_u_428, (copy) v_u_438
				v_u_428.BackgroundTransparency = 1
				v_u_438.Visible = false
			end)
			if v_u_426.id == "quickslot" and not p_u_406 then
				for v_u_442 = 1, 4 do
					local v443 = {
						["Name"] = nil,
						["AutoButtonColor"] = false,
						["BackgroundColor3"] = nil,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 12,
						["TextColor3"] = nil,
						["Text"] = nil,
						["ZIndex"] = 54,
						["Name"] = "Q" .. v_u_442
					}
					local v444 = p_u_403.work
					local v445
					if type(v444) == "table" then
						v445 = v444.kit or nil
					else
						v445 = nil
					end
					local v446
					if v445 then
						local v447 = v445.quick
						v446 = type(v447) == "table" and v447[v_u_442] or v445["quick" .. v_u_442]
						if type(v446) ~= "string" or v446 == "" then
							v446 = nil
						end
					else
						v446 = nil
					end
					local v448
					if v446 == p_u_404 then
						v448 = v_u_18.accent
					else
						v448 = v_u_18.raised
					end
					v443.BackgroundColor3 = v448
					v443.AnchorPoint = Vector2.new(1, 0.5)
					v443.Position = UDim2.new(1, -4 - (4 - v_u_442) * (v411 - v415), 0.5, 0)
					v443.Size = UDim2.fromOffset(v411 - v415 * 2, v411 - v415 * 2)
					v443.FontFace = v_u_8.font.monoBold
					local v449 = p_u_403.work
					local v450
					if type(v449) == "table" then
						v450 = v449.kit or nil
					else
						v450 = nil
					end
					local v451
					if v450 then
						local v452 = v450.quick
						v451 = type(v452) == "table" and v452[v_u_442] or v450["quick" .. v_u_442]
						if type(v451) ~= "string" or v451 == "" then
							v451 = nil
						end
					else
						v451 = nil
					end
					local v453
					if v451 == p_u_404 then
						v453 = v_u_18.ink
					else
						v453 = v_u_18.text2
					end
					v443.TextColor3 = v453
					v443.Text = tostring(v_u_442)
					local v454 = Instance.new("TextButton")
					if v443 then
						for v455, v456 in v443 do
							v454[v455] = v456
						end
					end
					if v_u_428 then
						v454.Parent = v_u_428
					end
					v_u_60(v454, v_u_18.line)
					v454.Activated:Connect(function()
						-- upvalues: (ref) v_u_164, (ref) v_u_379, (copy) p_u_403, (copy) p_u_404, (copy) v_u_442
						v_u_164()
						v_u_379(p_u_403, p_u_404, "quickslot", v_u_442)
					end)
				end
				v436.Size = UDim2.new(1, -20 - 4 * (v411 - v415), 1, 0)
			end
			v_u_428.Activated:Connect(function()
				-- upvalues: (ref) v_u_164, (copy) v_u_426, (ref) v_u_11, (copy) p_u_406, (ref) v_u_379, (copy) p_u_403, (copy) p_u_404
				v_u_164()
				if v_u_426.say then
					local v457 = v_u_426.say
					local v458 = v_u_11.toast
					pcall(v458, v457, "warn")
					return
				elseif p_u_406 then
					p_u_406.run(v_u_426.id)
				else
					v_u_379(p_u_403, p_u_404, v_u_426.id)
				end
			end)
			v425 = v425 + v411
		end
		local v459 = UDim2.fromOffset
		local v460 = p_u_405.X / v_u_409
		local v461 = math.max(8, v460)
		local v462 = p_u_405.Y / v_u_409
		v_u_418.Position = v459(v461, (math.max(8, v462)))
		local function v463()
			-- upvalues: (ref) v_u_7, (copy) v_u_418, (copy) p_u_405, (copy) v_u_409, (copy) v_u_407
			require(v_u_7:WaitForChild("InvUICtxClamp")).place(v_u_418, p_u_405 / v_u_409, v_u_407)
		end
		pcall(v463)
		local v464 = v_u_11.animateIn
		pcall(v464, v_u_418, 4)
		v_u_154 = v_u_418
		v_u_155 = os.clock()
		if v_u_11.device() == "Gamepad" then
			local v465 = {
				["Name"] = "PadReturn",
				["Value"] = nil,
				["Value"] = game:GetService("GuiService").SelectedObject
			}
			local v466 = Instance.new("ObjectValue")
			if v465 then
				for v467, v468 in v465 do
					v466[v467] = v468
				end
			end
			if v_u_418 then
				v466.Parent = v_u_418
			end
			local v469 = v_u_418:FindFirstChildWhichIsA("TextButton")
			if v469 then
				game:GetService("GuiService").SelectedObject = v469
			end
		end
		local v470 = v_u_11.sound
		pcall(v470, "open")
	end
end
v_u_290 = function(p_u_472, p_u_473)
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (copy) v_u_11, (copy) v_u_74, (copy) v_u_198
	local v474 = v_u_175(p_u_472.work, p_u_473)
	if v474 and (v474.item.n or 1) >= 2 then
		local v_u_475 = v474.item.n
		local v_u_476 = v_u_9.get(v474.item.id)
		local v477 = v_u_475 / 2
		local v_u_478 = math.floor(v477)
		local v_u_479 = nil
		local function v490()
			-- upvalues: (ref) v_u_479, (ref) v_u_11, (ref) v_u_74, (copy) v_u_476, (copy) v_u_475, (ref) v_u_478, (ref) v_u_198, (copy) p_u_472, (copy) p_u_473
			local v489 = {
				["title"] = "Split stack",
				["width"] = 420,
				["build"] = nil,
				["buttons"] = nil,
				["build"] = function(p480) -- name: build
					-- upvalues: (ref) v_u_74, (ref) v_u_476, (ref) v_u_475, (ref) v_u_11, (ref) v_u_478
					v_u_74(p480, (v_u_476 and v_u_476.name or "Stack") .. "  \194\183  " .. v_u_475 .. " in stack", "small", {
						["size"] = nil,
						["autoY"] = false,
						["size"] = UDim2.new(1, 0, 0, 20)
					})
					v_u_11.slider({
						["parent"] = nil,
						["label"] = "Amount",
						["min"] = 1,
						["max"] = nil,
						["step"] = 1,
						["value"] = nil,
						["width"] = 372,
						["format"] = nil,
						["onChange"] = nil,
						["parent"] = p480,
						["max"] = v_u_475 - 1,
						["value"] = v_u_478,
						["format"] = function(p481) -- name: format
							-- upvalues: (ref) v_u_475
							return string.format("%d  |  %d", p481, v_u_475 - p481)
						end,
						["onChange"] = function(p482) -- name: onChange
							-- upvalues: (ref) v_u_478
							v_u_478 = math.floor(p482)
						end
					})
				end,
				["buttons"] = {
					{
						["text"] = "Split",
						["kind"] = "primary",
						["onClick"] = nil,
						["onClick"] = function() -- name: onClick
							-- upvalues: (ref) v_u_198, (ref) p_u_472, (ref) p_u_473, (ref) v_u_478, (ref) v_u_475, (ref) v_u_11
							local v483 = v_u_198
							local v484 = p_u_472
							local v485 = {
								["op"] = "split",
								["uid"] = nil,
								["n"] = nil,
								["uid"] = p_u_473
							}
							local v486 = v_u_478
							local v487 = v_u_475 - 1
							v485.n = math.clamp(v486, 1, v487)
							v483(v484, v485)
							local v488 = v_u_11.sound
							pcall(v488, "confirm")
						end
					},
					{
						["text"] = "Cancel",
						["kind"] = "ghost"
					}
				}
			}
			v_u_479 = v_u_11.modal(v489)
		end
		if not pcall(v490) then
			v_u_198(p_u_472, {
				["op"] = "split",
				["uid"] = nil,
				["n"] = nil,
				["uid"] = p_u_473,
				["n"] = v_u_478
			})
		end
	end
end
v_u_289 = function(p_u_491, p_u_492)
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (ref) v_u_157, (copy) v_u_164, (copy) v_u_127, (copy) v_u_8, (copy) v_u_18, (copy) v_u_60, (copy) v_u_12, (copy) v_u_74, (copy) v_u_188, (copy) v_u_13, (copy) v_u_19, (copy) v_u_11, (copy) v_u_132, (ref) v_u_129, (ref) v_u_134, (copy) v_u_228, (ref) v_u_289, (ref) v_u_20, (ref) v_u_158
	local v493 = v_u_175(p_u_491.work, p_u_492)
	if v493 then
		local v_u_494 = v493.item
		local v495 = v_u_9.get(v_u_494.id)
		if v495 then
			if v_u_157 then
				v_u_157:Destroy()
			end
			v_u_164()
			local v496 = v_u_127()
			local v497 = v_u_8.refSize()
			local v498 = v497.X - 32
			local v499 = math.min(760, v498)
			local v500 = v497.Y - 32
			local v501 = math.min(420, v500)
			local v502 = {
				["Name"] = "Inspect",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 60,
				["Size"] = UDim2.fromScale(1, 1)
			}
			local v_u_503 = Instance.new("TextButton")
			if v502 then
				for v504, v505 in v502 do
					v_u_503[v504] = v505
				end
			end
			if v496 then
				v_u_503.Parent = v496
			end
			v_u_157 = v_u_503
			local v506 = {
				["Name"] = "Panel",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.02,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 61,
				["BackgroundColor3"] = v_u_18.bg,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(v499, v501)
			}
			local v_u_507 = Instance.new("Frame")
			if v506 then
				for v508, v509 in v506 do
					v_u_507[v508] = v509
				end
			end
			if v_u_503 then
				v_u_507.Parent = v_u_503
			end
			v_u_60(v_u_507, v_u_18.lineStrong)
			local v510 = v_u_8.rarityColor(v_u_9.shownRarity(v495))
			local v511 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 63,
				["BackgroundColor3"] = v510,
				["Size"] = UDim2.new(1, 0, 0, 2)
			}
			local v512 = Instance.new("Frame")
			if v511 then
				for v513, v514 in v511 do
					v512[v513] = v514
				end
			end
			if v_u_507 then
				v512.Parent = v_u_507
			end
			local v515 = {
				["Name"] = "Stage",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 62,
				["BackgroundColor3"] = v_u_18.bgDeep,
				["Position"] = UDim2.fromOffset(16, 18),
				["Size"] = UDim2.new(0.5, -24, 1, -34)
			}
			local v516 = Instance.new("Frame")
			if v515 then
				for v517, v518 in v515 do
					v516[v517] = v518
				end
			end
			if v_u_507 then
				v516.Parent = v_u_507
			end
			v_u_60(v516, v_u_18.line)
			local v519 = {
				["Color"] = nil,
				["Rotation"] = 90,
				["Color"] = ColorSequence.new(v_u_18.bgDeep:Lerp(v510, 0.18), v_u_18.bgDeep)
			}
			local v520 = Instance.new("UIGradient")
			if v519 then
				for v521, v522 in v519 do
					v520[v521] = v522
				end
			end
			if v516 then
				v520.Parent = v516
			end
			local v_u_523 = v_u_12.get(v_u_494.id, false, {
				["parent"] = nil,
				["zindex"] = 63,
				["size"] = nil,
				["position"] = nil,
				["mods"] = nil,
				["parent"] = v516,
				["size"] = UDim2.new(1, -24, 1, -24),
				["position"] = UDim2.fromOffset(12, 12),
				["mods"] = v_u_494.mods
			})
			v_u_12.spin(v_u_523, true)
			local v524 = {
				["Name"] = "Info",
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 62,
				["Position"] = UDim2.new(0.5, 0, 0, 18),
				["Size"] = UDim2.new(0.5, -16, 1, -34)
			}
			local v525 = Instance.new("Frame")
			if v524 then
				for v526, v527 in v524 do
					v525[v526] = v527
				end
			end
			if v_u_507 then
				v525.Parent = v_u_507
			end
			local v528 = 2 * v_u_8.touch(32) + 22
			v_u_74(v525, v_u_8.rarityName[v_u_9.shownRarity(v495)] or "", "caps", {
				["color"] = v510,
				["size"] = UDim2.new(1, -v528, 0, 18)
			}).ZIndex = 63
			v_u_74(v525, v_u_188.Case.name(v_u_494, v495), "h2", {
				["position"] = nil,
				["size"] = nil,
				["fit"] = true,
				["position"] = UDim2.fromOffset(0, 18),
				["size"] = UDim2.new(1, -v528, 0, 32)
			}).ZIndex = 63
			v_u_74(v525, v_u_9.displayCategory(v495.category) .. "  \194\183  " .. v_u_13.kg(v_u_13.weight(v_u_494)), "monoS", {
				["position"] = UDim2.fromOffset(0, 52),
				["size"] = UDim2.new(1, 0, 0, 18)
			}).ZIndex = 63
			local v529 = v_u_74(v525, v_u_9.shownDesc(v495), "small", {
				["position"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["position"] = UDim2.fromOffset(0, 78),
				["size"] = UDim2.new(1, 0, 0, 60)
			})
			v529.ZIndex = 63
			v529.TextWrapped = true
			v529.TextTruncate = Enum.TextTruncate.None
			v529.TextYAlignment = Enum.TextYAlignment.Top
			local v530 = {
				["Name"] = "Stats",
				["BackgroundTransparency"] = 1,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["CanvasSize"] = nil,
				["AutomaticCanvasSize"] = nil,
				["ScrollBarThickness"] = nil,
				["ScrollBarImageColor3"] = nil,
				["ZIndex"] = 63,
				["Position"] = UDim2.fromOffset(0, 146),
				["Size"] = UDim2.new(1, 0, 1, -146),
				["CanvasSize"] = UDim2.new(),
				["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
				["ScrollBarThickness"] = v_u_8.scrollBar,
				["ScrollBarImageColor3"] = v_u_18.lineStrong
			}
			local v_u_531 = Instance.new("ScrollingFrame")
			if v530 then
				for v532, v533 in v530 do
					v_u_531[v532] = v533
				end
			end
			if v525 then
				v_u_531.Parent = v525
			end
			local v534 = {
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Padding"] = UDim.new(0, 2)
			}
			local v535 = Instance.new("UIListLayout")
			if v534 then
				for v536, v537 in v534 do
					v535[v536] = v537
				end
			end
			if v_u_531 then
				v535.Parent = v_u_531
			end
			local v538 = v_u_13.statLines(v_u_494)
			local v539 = p_u_491.work
			local v540 = v_u_9.get(v_u_494.id)
			local v541 = v540
			if v541 then
				v541 = v_u_9.equipSlot(v540)
			end
			local v542
			if v541 then
				local v543
				if type(v539) == "table" then
					v543 = v539.kit or nil
				else
					v543 = nil
				end
				if v543 then
					v542 = v543.slots
					if v542 then
						v542 = v543.slots[v541]
					end
					if v542 == nil then
						v542 = v543[v541]
					end
					if type(v542) ~= "table" then
						v542 = nil
					end
				else
					v542 = nil
				end
				if not v542 or v542.uid == v_u_494.uid then
					v542 = nil
				end
			else
				v542 = nil
			end
			local v544 = v_u_13.tooltip(v_u_494, v542, {
				["detail"] = true
			})
			local v545 = v544.lines or v538
			if v544.lines and #v545 > 1 then
				v545 = table.move(v545, 2, #v545, 1, {})
			end
			for v546, v547 in v545 do
				local v548 = {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["ZIndex"] = 63,
					["BackgroundColor3"] = v_u_18.raised,
					["BackgroundTransparency"] = v546 % 2 == 0 and 1 or 0.4,
					["Size"] = UDim2.new(1, -6, 0, 24),
					["LayoutOrder"] = v546
				}
				local v549 = Instance.new("Frame")
				if v548 then
					for v550, v551 in v548 do
						v549[v550] = v551
					end
				end
				if v_u_531 then
					v549.Parent = v_u_531
				end
				local v552 = v_u_74
				local v553 = v547[1]
				local v554 = v552(v549, tostring(v553), "small", {
					["position"] = UDim2.fromOffset(8, 0),
					["size"] = UDim2.new(0.55, -8, 1, 0)
				})
				v554.ZIndex = 64
				v554.TextYAlignment = Enum.TextYAlignment.Center
				local v555 = v_u_74
				local v556 = v547[2]
				local v557 = v555(v549, tostring(v556), "monoS", {
					["position"] = UDim2.new(0.55, 0, 0, 0),
					["size"] = UDim2.new(0.45, -8, 1, 0),
					["color"] = v547[3] or v_u_18.text
				})
				v557.ZIndex = 64
				v557.TextXAlignment = Enum.TextXAlignment.Right
				v557.TextYAlignment = Enum.TextYAlignment.Center
			end
			local v558 = {}
			local function v_u_559() end
			local v560 = v_u_188.Gun.addRow
			local v561 = v_u_494.id
			pcall(v560, v_u_531, v561, -40)
			local function v564()
				-- upvalues: (ref) v_u_175, (copy) p_u_491, (copy) v_u_494, (ref) v_u_188, (copy) v_u_531
				local v562 = v_u_175(p_u_491.work, v_u_494.uid)
				local v563
				if v562 then
					v563 = v_u_188.Roll.tip(p_u_491, v562)
				else
					v563 = nil
				end
				if v563 then
					v_u_188.Roll.addRow(v_u_531, v563, -39)
				end
			end
			pcall(v564)
			local v565 = v_u_188.attachBlock
			local function v566()
				-- upvalues: (ref) v_u_559
				v_u_559()
			end
			local v567, v_u_568 = pcall(v565, p_u_491, v_u_494, v495, v_u_531, -50, v566)
			if not v567 or type(v_u_568) ~= "table" then
				v_u_568 = v558
			end
			if p_u_491.mode ~= "raid" then
				local v569 = v_u_19.inspectExtra
				if type(v569) == "function" then
					local v570 = v_u_19.inspectExtra
					local v571 = v_u_494.id
					pcall(v570, v571, v495, v_u_531)
				end
			end
			local v572 = {
				["Name"] = "Close",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["ZIndex"] = 66,
				["BackgroundColor3"] = v_u_18.raised,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -10, 0, 12),
				["Size"] = UDim2.fromOffset(v_u_8.touch(32), v_u_8.touch(32))
			}
			local v573 = Instance.new("TextButton")
			if v572 then
				for v574, v575 in v572 do
					v573[v574] = v575
				end
			end
			if v_u_507 then
				v573.Parent = v_u_507
			end
			v_u_60(v573, v_u_18.line)
			local v576 = v_u_11.icon
			local v577 = {
				["parent"] = nil,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 67,
				["color"] = nil,
				["parent"] = v573,
				["size"] = UDim2.fromOffset(14, 14),
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5),
				["color"] = v_u_18.text2
			}
			pcall(v576, "close", v577)
			local v578 = {
				["Name"] = "Wish",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["ZIndex"] = 66,
				["BackgroundColor3"] = v_u_18.raised,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -16 - v_u_8.touch(32), 0, 12),
				["Size"] = UDim2.fromOffset(v_u_8.touch(32), v_u_8.touch(32))
			}
			local v579 = Instance.new("TextButton")
			if v578 then
				for v580, v581 in v578 do
					v579[v580] = v581
				end
			end
			if v_u_507 then
				v579.Parent = v_u_507
			end
			local v_u_582 = v_u_60(v579, v_u_18.line)
			local v583 = v_u_11.icon
			local v584 = {
				["parent"] = nil,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["zindex"] = 67,
				["color"] = nil,
				["parent"] = v579,
				["size"] = UDim2.fromOffset(20, 20),
				["position"] = UDim2.fromScale(0.5, 0.5),
				["anchor"] = Vector2.new(0.5, 0.5),
				["color"] = v_u_18.text2
			}
			local v_u_585, v_u_586 = pcall(v583, "star", v584)
			local function v595() -- name: paintWish
				-- upvalues: (copy) v_u_494, (ref) v_u_132, (ref) v_u_129, (copy) v_u_585, (copy) v_u_586, (ref) v_u_11, (ref) v_u_18, (copy) v_u_582
				local v587 = v_u_494.id
				local v588 = v_u_132[v587]
				local v589
				if v588 and os.clock() - v588.t < 4 then
					v589 = v588.on
				else
					v589 = v_u_129[v587] == true
				end
				if v_u_585 and v_u_586 then
					local v590 = v_u_11.setIconColor
					local v591 = v_u_586
					local v592
					if v589 then
						v592 = v_u_18.accent
					else
						v592 = v_u_18.text2
					end
					pcall(v590, v591, v592)
				end
				local v593 = v_u_582
				local v594
				if v589 then
					v594 = v_u_18.accent
				else
					v594 = v_u_18.line
				end
				v593.Color = v594
			end
			local v596 = v_u_494.id
			local v597 = v_u_132[v596]
			local v598
			if v597 and os.clock() - v597.t < 4 then
				v598 = v597.on
			else
				v598 = v_u_129[v596] == true
			end
			if v_u_585 and v_u_586 then
				local v599 = v_u_11.setIconColor
				local v600
				if v598 then
					v600 = v_u_18.accent
				else
					v600 = v_u_18.text2
				end
				pcall(v599, v_u_586, v600)
			end
			local v601
			if v598 then
				v601 = v_u_18.accent
			else
				v601 = v_u_18.line
			end
			v_u_582.Color = v601
			v_u_134 = v595
			v579.Activated:Connect(function()
				-- upvalues: (copy) v_u_494, (ref) v_u_132, (ref) v_u_129, (ref) v_u_228, (copy) v_u_585, (copy) v_u_586, (ref) v_u_11, (ref) v_u_18, (copy) v_u_582, (ref) v_u_188
				local v602 = v_u_494.id
				local v603 = v_u_132[v602]
				local v604
				if v603 and os.clock() - v603.t < 4 then
					v604 = v603.on
				else
					v604 = v_u_129[v602] == true
				end
				v_u_228(v_u_494.id, not v604)
				local v605 = v_u_494.id
				local v606 = v_u_132[v605]
				local v607
				if v606 and os.clock() - v606.t < 4 then
					v607 = v606.on
				else
					v607 = v_u_129[v605] == true
				end
				if v_u_585 and v_u_586 then
					local v608 = v_u_11.setIconColor
					local v609 = v_u_586
					local v610
					if v607 then
						v610 = v_u_18.accent
					else
						v610 = v_u_18.text2
					end
					pcall(v608, v609, v610)
				end
				local v611 = v_u_582
				local v612
				if v607 then
					v612 = v_u_18.accent
				else
					v612 = v_u_18.line
				end
				v611.Color = v612
				if v604 then
					local v613 = v_u_188.wishText("note", false, v_u_494.id)
					if v613 ~= "" then
						local v614 = v_u_11.toast
						pcall(v614, v613, "info")
					end
				end
			end)
			local v615 = v_u_11.tooltip
			local function v620()
				-- upvalues: (copy) v_u_494, (ref) v_u_132, (ref) v_u_129, (ref) v_u_188
				local v616 = v_u_494.id
				local v617 = v_u_132[v616]
				local v618
				if v617 and os.clock() - v617.t < 4 then
					v618 = v617.on
				else
					v618 = v_u_129[v616] == true
				end
				local v619 = v_u_188.wishText("body", v618, v_u_494.id)
				return {
					["title"] = v618 and "NEEDED" or "MARK AS NEEDED",
					["body"] = v619 == "" and (v618 and "On your NEEDED list: in a raid it shows a star, and containers holding it glow amber. Select it again to remove it." or "Add it to your NEEDED list: in a raid it shows a star, and containers holding it glow amber.") or v619
				}
			end
			pcall(v615, v579, v620)
			local function v_u_624(p621) -- name: close
				-- upvalues: (ref) v_u_12, (copy) v_u_523, (ref) v_u_568, (ref) v_u_157, (copy) v_u_503, (ref) v_u_11
				v_u_12.spin(v_u_523, false)
				v_u_12.release(v_u_523)
				for _, v622 in v_u_568 do
					v_u_12.release(v622)
				end
				if v_u_157 == v_u_503 then
					v_u_157 = nil
				end
				v_u_503:Destroy()
				if not p621 then
					local v623 = v_u_11.sound
					pcall(v623, "close")
				end
			end
			v_u_559 = function()
				-- upvalues: (ref) v_u_157, (copy) v_u_503, (copy) v_u_624, (ref) v_u_289, (copy) p_u_491, (copy) p_u_492
				if v_u_157 == v_u_503 then
					v_u_624(true)
					v_u_289(p_u_491, p_u_492)
				end
			end
			local v625 = v_u_188.CaseOpen.inspect
			local v626 = v_u_20
			pcall(v625, v626, p_u_491, v_u_494, v525, function()
				-- upvalues: (copy) v_u_624
				v_u_624(true)
			end)
			v573.Activated:Connect(function()
				-- upvalues: (copy) v_u_624
				v_u_624()
			end)
			v_u_503.Activated:Connect(function()
				-- upvalues: (ref) v_u_158, (copy) v_u_507, (copy) v_u_624
				local v627 = v_u_158
				local v628 = v_u_507
				local v629 = v628.AbsolutePosition
				local v630 = v628.AbsoluteSize
				local v631
				if v627.X >= v629.X and (v627.Y >= v629.Y and v627.X < v629.X + v630.X) then
					v631 = v627.Y < v629.Y + v630.Y
				else
					v631 = false
				end
				if not v631 then
					v_u_624()
				end
			end)
			local v632 = v_u_11.animateIn
			pcall(v632, v_u_507, 8)
			local v633 = v_u_11.sound
			pcall(v633, "open")
		end
	else
		return
	end
end
local function v_u_635(p634) -- name: cellReal
	-- upvalues: (copy) v_u_8
	return p634.cell * v_u_8.uiScale()
end
local function v_u_646(p636) -- name: setGhostSize
	-- upvalues: (copy) v_u_10, (copy) v_u_8, (copy) v_u_12
	local v637, v638 = v_u_10.size({
		["id"] = nil,
		["r"] = nil,
		["uid"] = "",
		["x"] = 0,
		["y"] = 0,
		["n"] = 1,
		["id"] = p636.inst.id,
		["r"] = p636.r
	})
	p636.w = v637
	p636.h = v638
	local v639 = p636.m.cell * v_u_8.uiScale()
	p636.ghost.Size = UDim2.fromOffset(v637 * v639 - 2, v638 * v639 - 2)
	if p636.touch then
		p636.grab = Vector2.new(v637 * v639 * 0.5, v638 * v639 * 0.5)
	else
		local v640 = Vector2.new
		local v641 = p636.grab.X
		local v642 = v637 * v639 - 4
		local v643 = math.min(v641, v642)
		local v644 = p636.grab.Y
		local v645 = v638 * v639 - 4
		p636.grab = v640(v643, (math.min(v644, v645)))
	end
	v_u_12.setRotated(p636.icon, p636.r)
end
local v_u_647 = nil
local function v649() -- name: rotateDrag
	-- upvalues: (ref) v_u_149, (copy) v_u_646, (copy) v_u_11, (ref) v_u_647
	if v_u_149 then
		v_u_149.r = not v_u_149.r
		v_u_646(v_u_149)
		local v648 = v_u_11.sound
		pcall(v648, "tick")
		v_u_647(v_u_149.pos)
	end
end
local function v_u_656(p650) -- name: designRect
	-- upvalues: (copy) v_u_127, (copy) v_u_8
	local v651 = v_u_127()
	local v652 = v_u_8.uiScale()
	local v653 = v651.AbsolutePosition
	local v654 = p650.AbsolutePosition
	local v655 = p650.AbsoluteSize
	return {
		(v654.X - v653.X) / v652,
		(v654.Y - v653.Y) / v652,
		(v654.X - v653.X + v655.X) / v652,
		(v654.Y - v653.Y + v655.Y) / v652
	}
end
local function v_u_684(p657, p658) -- name: stripAvoid
	-- upvalues: (copy) v_u_76, (copy) v_u_656
	local v659 = {}
	for _, v660 in p657.grids do
		if not (v660.cells.Parent and v_u_76(v660.cells)) then
			continue
		end
		local v661 = v_u_656(v660.cells)
		local v662
		if v660.clip and v660.clip.Parent then
			local v663 = v_u_656(v660.clip)
			v662 = {}
			local v664 = v661[1]
			local v665 = v663[1]
			local v666 = math.max(v664, v665)
			local v667 = v661[2]
			local v668 = v663[2]
			local v669 = math.max(v667, v668)
			local v670 = v661[3]
			local v671 = v663[3]
			local v672 = math.min(v670, v671)
			local v673 = v661[4]
			local v674 = v663[4]
			__set_list(v662, 1, {v666, v669, v672, (math.min(v673, v674))})
		else
			v662 = v661
		end
		if v662[3] <= v662[1] or v662[4] <= v662[2] then
			continue
		end
		table.insert(v659, {
			["r"] = nil,
			["w"] = 1,
			["r"] = v662
		})
	end
	for _, v675 in p657.slots do
		if not v_u_76(v675.frame) then
			continue
		end
		local v676 = {
			["r"] = nil,
			["w"] = 0.6,
			["r"] = v_u_656(v675.frame)
		}
		table.insert(v659, v676)
	end
	for _, v677 in p657.quick do
		if not v_u_76(v677.frame) then
			continue
		end
		local v678 = {
			["r"] = nil,
			["w"] = 0.4,
			["r"] = v_u_656(v677.frame)
		}
		table.insert(v659, v678)
	end
	for _, v679 in p657.sections do
		for _, v680 in v679.buttons or {} do
			if not (v680.Parent and v_u_76(v680)) then
				continue
			end
			local v681 = v_u_656(v680)
			local v682 = {
				["r"] = nil,
				["w"] = 12,
				["r"] = {
					v681[1] - 4,
					v681[2] - 4,
					v681[3] + 4,
					v681[4] + 4
				}
			}
			table.insert(v659, v682)
		end
	end
	for _, v683 in p658 or {} do
		table.insert(v659, v683)
	end
	return v659
end
local v_u_685 = v_u_188.Strip.size
local function v_u_695(p686, p687, p688, p689) -- name: placeStrip
	-- upvalues: (copy) v_u_8, (copy) v_u_127, (copy) v_u_188
	local v690 = v_u_8.refSize()
	local v691 = v_u_8.devViewport
	local v692, v693 = pcall(v691)
	if v692 then
		v692 = v693 ~= nil
	end
	if not v692 then
		local v694 = v_u_127().AbsoluteSize
		if v694.X > 10 and v694.Y > 10 then
			v690 = v694 / v_u_8.uiScale()
		end
	end
	return v_u_188.Strip.place(p686, p687, p688, p689, v690)
end
local function v_u_699(p696, p697) -- name: sameLoc
	if not p696 or (not p697 or p696.kind ~= p697.kind) then
		return false
	end
	if p696.kind == "slot" then
		return p696.slot == p697.slot
	end
	local v698
	if p696.container == p697.container and (p696.item.x == p697.x and p696.item.y == p697.y) then
		v698 = p696.item.r == true == p697.r
	else
		v698 = false
	end
	return v698
end
local function v_u_728(p700, p701, p702) -- name: stripActions
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (ref) v_u_159, (copy) v_u_16, (copy) v_u_188, (copy) v_u_699, (copy) v_u_10, (ref) v_u_20
	local v703 = {}
	local v704 = v_u_175(p700.work, p701)
	if not v704 then
		return v703
	end
	local v705 = v_u_9.get(v704.item.id)
	if v_u_159 and (v_u_159.pick == p701 and not p702) then
		return v_u_16.stripActs(p700.work, p700.mode, v704, v705, true, false)
	end
	if v704.container == "ground" then
		if v705 and (v_u_9.equipSlot(v705) and v705.equip ~= "secure") then
			local v706 = {
				["id"] = "equip",
				["text"] = nil,
				["icon"] = "equip"
			}
			local v707 = p700.work
			local v708 = v704.item
			local v709 = v_u_9.get(v708.id)
			if v709 then
				v709 = v_u_9.equipSlot(v709)
			end
			local v710
			if v709 then
				local v711
				if type(v707) == "table" then
					v711 = v707.kit or nil
				else
					v711 = nil
				end
				if v711 then
					v710 = v711.slots
					if v710 then
						v710 = v711.slots[v709]
					end
					if v710 == nil then
						v710 = v711[v709]
					end
					if type(v710) ~= "table" then
						v710 = nil
					end
				else
					v710 = nil
				end
				if not v710 or v710.uid == v708.uid then
					v710 = nil
				end
			else
				v710 = nil
			end
			v706.text = v710 and "Swap" or "Equip"
			table.insert(v703, v706)
		end
		if v_u_188.canOpen(p700, v704) then
			local v712 = v705 and v705.equip == "armor" and "openvest" or "openbag"
			local v713 = v_u_188.isOpen(p700, p701) and {
				["id"] = "closebag",
				["text"] = nil,
				["icon"] = nil,
				["text"] = v_u_188.closeText(v704.item),
				["icon"] = v712
			} or {
				["id"] = "openbag",
				["text"] = "Open",
				["icon"] = nil,
				["icon"] = v712
			}
			table.insert(v703, v713)
		end
		table.insert(v703, {
			["id"] = "quick",
			["text"] = "Take",
			["icon"] = "use"
		})
		if p700.mode == "raid" and (v705 and v705.category == "medical") then
			table.insert(v703, {
				["id"] = "use",
				["text"] = "Use",
				["icon"] = "use"
			})
		end
		if not p702 then
			v_u_16.groundActs(v703, v704.item, v705, true)
		end
		table.insert(v703, {
			["id"] = "inspect",
			["text"] = "Inspect",
			["icon"] = "inspect"
		})
		if not p702 then
			table.insert(v703, {
				["id"] = "ping",
				["text"] = "Ping",
				["icon"] = "ping"
			})
		end
		local v714
		if v_u_159 == nil or v_u_159.uid ~= p701 then
			v714 = false
		else
			v714 = not v_u_699(v704, v_u_159.origin)
		end
		table.insert(v703, {
			["id"] = "cancel",
			["text"] = nil,
			["icon"] = "cancel",
			["text"] = (p702 or v714) and "Cancel" or "Close"
		})
		return v703
	end
	local v715, v716 = v_u_10.size({
		["id"] = nil,
		["r"] = false,
		["uid"] = "",
		["x"] = 0,
		["y"] = 0,
		["n"] = 1,
		["id"] = v704.item.id
	})
	if p702 or v704.kind == "grid" and v715 ~= v716 then
		table.insert(v703, {
			["id"] = "rotate",
			["text"] = "Rotate",
			["icon"] = "rotate"
		})
	end
	if v704.kind == "slot" then
		if v704.slot ~= "secure" then
			table.insert(v703, {
				["id"] = "unequip",
				["text"] = "Unequip",
				["icon"] = "unequip"
			})
		end
	elseif v705 then
		local v717
		if v_u_9.equipSlot(v705) == nil then
			v717 = false
		else
			local v718
			if p700.mode == "raid" then
				v718 = v705.equip == "secure"
			else
				v718 = false
			end
			v717 = not v718
		end
		if v717 then
			table.insert(v703, {
				["id"] = "equip",
				["text"] = "Equip",
				["icon"] = "equip"
			})
		elseif p700.mode == "raid" and v705.category == "medical" then
			table.insert(v703, {
				["id"] = "use",
				["text"] = "Use",
				["icon"] = "use"
			})
		elseif p700.mode == "raid" and v705.category == "throwable" then
			table.insert(v703, {
				["id"] = "use",
				["text"] = "Throw",
				["icon"] = "equip"
			})
		end
	end
	if v705 and (v705.category == "attachment" and v_u_188.Att.canSource(v704, "ground")) then
		for _, v719 in v_u_188.Att.targets(p700.work, v704.item) do
			local v720 = {
				["id"] = nil,
				["text"] = nil,
				["icon"] = "equip",
				["id"] = v_u_188.Att.ACTION .. v719.uid,
				["text"] = "On " .. v719.short
			}
			table.insert(v703, v720)
		end
	end
	for _, v721 in v_u_16.stripActs(p700.work, p700.mode, v704, v705, false, p702) do
		table.insert(v703, v721)
	end
	if v704.kind == "grid" and (v704.item.n or 1) > 1 then
		table.insert(v703, {
			["id"] = "split",
			["text"] = "Split",
			["icon"] = "split"
		})
	end
	table.insert(v703, {
		["id"] = "inspect",
		["text"] = "Inspect",
		["icon"] = "inspect"
	})
	local v722
	if p700.mode == "raid" and v704.kind == "grid" then
		local v723 = v704.c
		if type(v723) == "table" then
			v722 = v704.c.world == true
		else
			v722 = false
		end
	else
		v722 = false
	end
	if v722 then
		if v_u_188.canOpen(p700, v704) then
			local v724 = v705 and v705.equip == "armor" and "openvest" or "openbag"
			local v725 = v_u_188.isOpen(p700, p701) and {
				["id"] = "closebag",
				["text"] = nil,
				["icon"] = nil,
				["text"] = v_u_188.closeText(v704.item),
				["icon"] = v724
			} or {
				["id"] = "openbag",
				["text"] = "Open",
				["icon"] = nil,
				["icon"] = v724
			}
			table.insert(v703, v725)
		end
		if not p702 then
			table.insert(v703, {
				["id"] = "ping",
				["text"] = "Ping",
				["icon"] = "ping"
			})
		end
	elseif v704.kind == "grid" and v_u_188.Why.quickEntryOk(p700.mode, v704.container) then
		table.insert(v703, {
			["id"] = "quickslot",
			["text"] = "Quick",
			["icon"] = "quick"
		})
	end
	v_u_188.Lock.strip(p700, v704, v703)
	v_u_188.Roll.strip(p700, v704, v703)
	v_u_188.Skins.strip(v_u_20, p700, v704, v705, v703)
	v_u_188.CaseOpen.strip(v_u_20, p700, v704, v705, v703)
	v_u_188.Case.strip(p700, v704, v705, v703)
	if v704.kind ~= "slot" or v704.slot ~= "secure" then
		local v726 = {
			["id"] = "drop",
			["text"] = nil,
			["icon"] = "drop",
			["text"] = p700.mode ~= "raid" and "Discard" or "Drop"
		}
		table.insert(v703, v726)
	end
	local v727
	if v_u_159 == nil or v_u_159.uid ~= p701 then
		v727 = false
	else
		v727 = not v_u_699(v704, v_u_159.origin)
	end
	table.insert(v703, {
		["id"] = "cancel",
		["text"] = nil,
		["icon"] = "cancel",
		["text"] = (p702 or v727) and "Cancel" or "Close"
	})
	return v703
end
local v_u_729 = v_u_188.Strip.glyph
local v_u_730 = nil
local v_u_731 = {}
local function v_u_781(p_u_732, p_u_733, p734, p735, p736) -- name: buildStrip
	-- upvalues: (copy) v_u_728, (ref) v_u_156, (copy) v_u_8, (copy) v_u_695, (copy) v_u_684, (ref) v_u_731, (copy) v_u_127, (copy) v_u_685, (copy) v_u_18, (copy) v_u_60, (copy) v_u_729, (ref) v_u_730
	local v737 = v_u_728(p_u_732, p_u_733, p734)
	if #v737 == 0 then
		if v_u_156 then
			v_u_156:Destroy()
			v_u_156 = nil
		end
		return {}
	end
	local v738 = v_u_8.touch(40)
	local v739, v740, v741 = v_u_695(#v737, v738, p735, (v_u_684(p_u_732, p736)))
	local v742 = {}
	for _, v743 in v737 do
		local v744 = v743.id .. "=" .. v743.text
		table.insert(v742, v744)
	end
	local v745 = string.format("%s|%s|%s|%d,%d|%s", p_u_733, tostring(p734), v739, v740, v741, table.concat(v742, ","))
	if v_u_156 and (v_u_156.Parent and v_u_156:GetAttribute("Sig") == v745) then
		return v_u_731
	end
	if v_u_156 then
		v_u_156:Destroy()
		v_u_156 = nil
	end
	local v746 = v_u_127()
	local v747, v748 = v_u_685(#v737, v738, v739)
	local v749 = {
		["Name"] = "SidePanel",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["BorderSizePixel"] = 0,
		["Active"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 70,
		["BackgroundColor3"] = v_u_18.bg,
		["Position"] = UDim2.fromOffset(v740, v741),
		["Size"] = UDim2.fromOffset(v747, v748)
	}
	local v750 = Instance.new("Frame")
	if v749 then
		for v751, v752 in v749 do
			v750[v751] = v752
		end
	end
	if v746 then
		v750.Parent = v746
	end
	v750:SetAttribute("Shape", v739)
	v750:SetAttribute("Sig", v745)
	v_u_60(v750, v_u_18.lineStrong)
	local v753 = {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 72,
		["BackgroundColor3"] = v_u_18.accent,
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v754 = Instance.new("Frame")
	if v753 then
		for v755, v756 in v753 do
			v754[v755] = v756
		end
	end
	if v750 then
		v754.Parent = v750
	end
	local v757 = v738 * 0.38
	local v758 = math.floor(v757)
	local v759 = {}
	for v760, v761 in v737 do
		local v762 = v760 - 1
		local v763
		if v739 == "col" then
			v762 = (v760 - 1) % 2
			v763 = (v760 - 1) // 2
		else
			v763 = 0
		end
		local v764 = v761.id
		local v765, v766, v767
		if v764 == "rotate" then
			v765 = v_u_18.accentDeep
			v766 = v_u_18.accent
			v767 = v_u_18.accentDim
		elseif v764 == "drop" then
			v765 = v_u_18.dangerDeep
			v766 = v_u_18.danger
			v767 = v_u_18.line
		else
			v765 = v_u_18.raised
			if v764 == "cancel" then
				v766 = v_u_18.text2
			else
				v766 = v_u_18.text
			end
			v767 = v_u_18.line
		end
		local v768 = {
			["Name"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["ZIndex"] = 71,
			["Name"] = v761.id,
			["BackgroundColor3"] = v765,
			["Position"] = UDim2.fromOffset(4 + v762 * (v738 + 4), 6 + v763 * (v738 + 4)),
			["Size"] = UDim2.fromOffset(v738, v738)
		}
		local v769 = Instance.new("TextButton")
		if v768 then
			for v770, v771 in v768 do
				v769[v770] = v771
			end
		end
		if v750 then
			v769.Parent = v750
		end
		v_u_60(v769, v767)
		v_u_729(v769, v761.icon, v766, 72, v758)
		local v772 = {
			["Name"] = "Label",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 11,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Text"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 72,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 2, 1, -4),
			["Size"] = UDim2.new(1, -4, 0, 12),
			["FontFace"] = v_u_8.font.heading,
			["TextColor3"] = v766,
			["Text"] = string.upper(v761.text),
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		}
		local v773 = Instance.new("TextLabel")
		if v772 then
			for v774, v775 in v772 do
				v773[v774] = v775
			end
		end
		if v769 then
			v773.Parent = v769
		end
		local v776 = {
			["MaxTextSize"] = 11,
			["MinTextSize"] = 7
		}
		local v777 = Instance.new("UITextSizeConstraint")
		if v776 then
			for v778, v779 in v776 do
				v777[v778] = v779
			end
		end
		if v773 then
			v777.Parent = v773
		end
		local v_u_780 = v761.id
		v769.Activated:Connect(function()
			-- upvalues: (ref) v_u_730, (copy) p_u_732, (copy) p_u_733, (copy) v_u_780
			v_u_730(p_u_732, p_u_733, v_u_780)
		end)
		table.insert(v759, {
			["id"] = v_u_780,
			["btn"] = v769,
			["base"] = v765
		})
	end
	v_u_156 = v750
	v_u_731 = v759
	return v759
end
local function v_u_785(p782) -- name: buildDragStrip
	-- upvalues: (copy) v_u_656, (copy) v_u_188, (copy) v_u_781
	local v783
	if p782.src then
		v783 = p782.src.frame or nil
	else
		v783 = nil
	end
	local v784
	if v783 and v783.Parent then
		v784 = v_u_656(v783)
	else
		v784 = v_u_656(p782.ghost)
	end
	p782.panelButtons = v_u_188.TD.strip(p782, v_u_781, v784, (v_u_656(p782.ghost)))
end
local function v_u_790(p786, p787) -- name: selTileFrame
	local v788 = p786.tiles[p787]
	if v788 and (v788.frame and v788.frame.Parent) then
		return v788.frame
	end
	for _, v789 in p786.slots do
		if not v789.tile or (not v789.tile.inst or (v789.tile.inst.uid ~= p787 or not v789.tile.frame.Parent)) then
			continue
		end
		return v789.tile.frame
	end
	return nil
end
local function v_u_803(p791, p792) -- name: rotateParked
	-- upvalues: (ref) v_u_159, (copy) v_u_175, (copy) v_u_10, (copy) v_u_11, (copy) v_u_198, (copy) v_u_212
	local v793 = v_u_159
	if not p791 then
		if v793 then
			p791 = v793.m
		else
			p791 = v793
		end
	end
	if not p792 then
		if v793 then
			p792 = v793.uid
		else
			p792 = v793
		end
	end
	if p791 and p792 then
		local v794 = v_u_175(p791.work, p792)
		if v794 and v794.kind == "grid" then
			local v795 = v794.item
			local v796 = v795.r ~= true
			local v797, v798 = v_u_10.size({
				["id"] = nil,
				["r"] = nil,
				["uid"] = "",
				["x"] = 0,
				["y"] = 0,
				["n"] = 1,
				["id"] = v795.id,
				["r"] = v796
			})
			if v797 == v798 then
				return
			else
				local v799 = v794.c
				if v_u_10.fits(v799, v795, v795.x, v795.y, v796, p792) and (not v799.limit or v799.limit.w >= v797 and v799.limit.h >= v798) then
					v_u_198(p791, {
						["op"] = "move",
						["uid"] = nil,
						["to"] = nil,
						["x"] = nil,
						["y"] = nil,
						["r"] = nil,
						["uid"] = p792,
						["to"] = v794.container,
						["x"] = v795.x,
						["y"] = v795.y,
						["r"] = v796
					})
					v_u_212(p791, p792, v794.container, v795.x, v795.y, v796)
					local v800 = v_u_11.sound
					pcall(v800, "tick")
					if v793 then
						v793.dirty = true
					end
				else
					local v801 = v_u_11.toast
					pcall(v801, "No room to turn it here", "warn")
					local v802 = v_u_11.sound
					pcall(v802, "error")
				end
			end
		else
			return
		end
	else
		return
	end
end
v_u_188.rotateIn = v_u_803
local function v_u_814() -- name: cancelSel
	-- upvalues: (ref) v_u_159, (copy) v_u_175, (copy) v_u_699, (copy) v_u_10, (copy) v_u_198, (copy) v_u_212, (copy) v_u_11, (ref) v_u_149, (ref) v_u_156, (copy) v_u_21
	local v804 = v_u_159
	if v804 then
		local v805 = v804.m
		local v806 = v804.origin
		local v807 = v_u_175(v805.work, v804.uid)
		if v807 and (v806 and not v_u_699(v807, v806)) then
			if v806.kind == "grid" then
				local v808 = v805.work.containers
				if v808 then
					v808 = v805.work.containers[v806.container]
				end
				if type(v808) == "table" and v_u_10.fits(v808, v807.item, v806.x, v806.y, v806.r, v804.uid) then
					v_u_198(v805, {
						["op"] = "move",
						["uid"] = nil,
						["to"] = nil,
						["x"] = nil,
						["y"] = nil,
						["r"] = nil,
						["uid"] = v804.uid,
						["to"] = v806.container,
						["x"] = v806.x,
						["y"] = v806.y,
						["r"] = v806.r
					})
					v_u_212(v805, v804.uid, v806.container, v806.x, v806.y, v806.r)
					local v809 = v_u_11.sound
					pcall(v809, "click")
				else
					local v810 = v_u_11.toast
					pcall(v810, "No room to put it back", "warn")
				end
			elseif v806.kind == "slot" then
				v_u_198(v805, {
					["op"] = "equip",
					["uid"] = nil,
					["slot"] = nil,
					["uid"] = v804.uid,
					["slot"] = v806.slot
				})
				local v811 = v_u_11.sound
				pcall(v811, "click")
			end
		else
			local v812 = v_u_11.sound
			pcall(v812, "close")
		end
		local v813 = v_u_159
		if v813 then
			v_u_159 = nil
			if v813.mark then
				v813.mark:Destroy()
			end
			if not v_u_149 and v_u_156 then
				v_u_156:Destroy()
				v_u_156 = nil
			end
			if v_u_21 then
				v_u_21:SetAttribute("InvUISelected", nil)
			end
		end
	else
		return
	end
end
function v_u_188.gearGuard()
	-- upvalues: (copy) v_u_188, (copy) v_u_6
	local v815 = os.clock()
	if v815 - (v_u_188.ggAt or -10) > 2 then
		v_u_188.ggAt = v815
		local function v816()
			-- upvalues: (ref) v_u_6
			return require(v_u_6:WaitForChild("Config", 2)).flag("TouchGearGuard")
		end
		local v817, v818 = pcall(v816)
		v_u_188.ggVal = not v817 or v818 ~= false
	end
	return v_u_188.ggVal
end
function v_u_188.selectTile(p819, p820)
	-- upvalues: (copy) v_u_175, (ref) v_u_159, (ref) v_u_149, (ref) v_u_156, (copy) v_u_21, (copy) v_u_11
	local v821 = v_u_175(p819.work, p820)
	if v821 then
		local v822 = v_u_159 and (v_u_159.uid ~= p820 or v_u_159.m ~= p819) and v_u_159
		if v822 then
			v_u_159 = nil
			if v822.mark then
				v822.mark:Destroy()
			end
			if not v_u_149 and v_u_156 then
				v_u_156:Destroy()
				v_u_156 = nil
			end
			if v_u_21 then
				v_u_21:SetAttribute("InvUISelected", nil)
			end
		end
		if not v_u_159 then
			local v823 = {
				["m"] = p819,
				["uid"] = p820,
				["origin"] = {
					["kind"] = v821.kind,
					["container"] = v821.container,
					["slot"] = v821.slot,
					["x"] = v821.item.x,
					["y"] = v821.item.y,
					["r"] = v821.item.r == true
				}
			}
			v_u_159 = v823
			if v_u_21 then
				v_u_21:SetAttribute("InvUISelected", p820)
			end
		end
		v_u_159.dirty = true
		local v824 = v_u_11.sound
		pcall(v824, "tick")
	end
end
v_u_730 = function(p825, p826, p827)
	-- upvalues: (ref) v_u_149, (copy) v_u_646, (copy) v_u_11, (ref) v_u_647, (copy) v_u_803, (copy) v_u_188, (copy) v_u_814, (copy) v_u_379, (ref) v_u_159
	if p827 == "rotate" then
		if v_u_149 then
			if v_u_149 then
				v_u_149.r = not v_u_149.r
				v_u_646(v_u_149)
				local v828 = v_u_11.sound
				pcall(v828, "tick")
				v_u_647(v_u_149.pos)
			end
		else
			v_u_803()
			return
		end
	elseif v_u_149 then
		v_u_188.TD.tap(v_u_149, p827, v_u_188.padApi)
		return
	elseif p827 == "cancel" then
		v_u_814()
	else
		if p827 ~= "loadpick" and p827 ~= "loadback" then
			v_u_379(p825, p826, p827)
		end
		if v_u_159 and v_u_159.uid == p826 then
			v_u_159.dirty = true
			local v829 = v_u_159
			if p827 ~= "loadpick" then
				p826 = nil
			end
			v829.pick = p826
		end
	end
end
local function v_u_834(p830) -- name: clearHighlights
	for _, v831 in p830.grids do
		v831.hl.Visible = false
	end
	for _, v832 in p830.slots do
		v832.hl.Visible = false
	end
	for _, v833 in p830.quick do
		v833.hl.Visible = false
	end
end
local function v_u_862(p835, p836) -- name: beginDrag
	-- upvalues: (copy) v_u_175, (copy) v_u_164, (copy) v_u_127, (copy) v_u_8, (copy) v_u_18, (copy) v_u_60, (copy) v_u_9, (copy) v_u_12, (copy) v_u_7, (ref) v_u_149, (copy) v_u_646, (copy) v_u_11, (ref) v_u_647, (ref) v_u_159, (ref) v_u_156, (copy) v_u_21, (copy) v_u_3, (copy) v_u_188, (copy) v_u_785
	local v837 = p835.m
	local v838 = v_u_175(v837.work, p835.uid)
	if v838 then
		v_u_164()
		local _, v839 = v_u_127()
		local v840 = v838.item
		local v841 = v837.cell * v_u_8.uiScale()
		local v842 = {
			["Name"] = "DragGhost",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["ZIndex"] = 80,
			["BackgroundColor3"] = v_u_18.raised
		}
		local v843 = Instance.new("Frame")
		if v842 then
			for v844, v845 in v842 do
				v843[v844] = v845
			end
		end
		if v839 then
			v843.Parent = v839
		end
		local v846 = v_u_60(v843, v_u_18.accent)
		local v847 = {
			["Name"] = "Tint",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.75,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 80,
			["BackgroundColor3"] = v_u_8.rarityColor(v_u_9.shownRarity(v_u_9.get(v840.id))),
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v848 = Instance.new("Frame")
		if v847 then
			for v849, v850 in v847 do
				v848[v849] = v850
			end
		end
		if v843 then
			v848.Parent = v843
		end
		local v851 = v_u_12.get(v840.id, v840.r == true, {
			["parent"] = nil,
			["zindex"] = 81,
			["size"] = nil,
			["position"] = nil,
			["mods"] = nil,
			["parent"] = v843,
			["size"] = UDim2.new(1, -6, 1, -6),
			["position"] = UDim2.fromOffset(3, 3),
			["mods"] = v840.mods
		})
		local v852 = p835.tileFrame
		local v853 = require(v_u_7.UiPointer).grab(v843, v852, p835.start, p836, v841)
		v_u_149 = {
			["m"] = nil,
			["uid"] = nil,
			["inst"] = nil,
			["r"] = nil,
			["ghost"] = nil,
			["gStroke"] = nil,
			["icon"] = nil,
			["io"] = nil,
			["touch"] = nil,
			["grab"] = nil,
			["pos"] = nil,
			["src"] = nil,
			["from"] = nil,
			["target"] = nil,
			["m"] = v837,
			["uid"] = p835.uid,
			["inst"] = v840,
			["r"] = v840.r == true,
			["ghost"] = v843,
			["gStroke"] = v846,
			["icon"] = v851,
			["io"] = p835.io,
			["touch"] = p835.touch,
			["grab"] = v853,
			["pos"] = p836,
			["src"] = p835.tile,
			["from"] = v838
		}
		v_u_646(v_u_149)
		if p835.tile then
			p835.tile.setGhosted(true)
		end
		local v854 = v_u_11.sound
		pcall(v854, "tick")
		v_u_647(p836)
		if p835.touch and v_u_149 then
			local v855 = v_u_159 and (v_u_159.uid ~= p835.uid or v_u_159.m ~= v837) and v_u_159
			if v855 then
				v_u_159 = nil
				if v855.mark then
					v855.mark:Destroy()
				end
				if not v_u_149 and v_u_156 then
					v_u_156:Destroy()
					v_u_156 = nil
				end
				if v_u_21 then
					v_u_21:SetAttribute("InvUISelected", nil)
				end
			end
			if not v_u_159 then
				v_u_159 = {
					["m"] = v837,
					["uid"] = p835.uid,
					["origin"] = {
						["kind"] = v838.kind,
						["container"] = v838.container,
						["slot"] = v838.slot,
						["x"] = v838.item.x,
						["y"] = v838.item.y,
						["r"] = v838.item.r == true
					}
				}
				v_u_21:SetAttribute("InvUISelected", p835.uid)
			end
			if v_u_159.mark then
				v_u_159.mark.Visible = false
			end
			local function v861()
				-- upvalues: (ref) v_u_3
				for _, v_u_856 in { Enum.UserInputType.Touch, Enum.UserInputType.Gamepad1 } do
					if not (v_u_3:IsVibrationSupported(v_u_856) and v_u_3:IsMotorSupported(v_u_856, Enum.VibrationMotor.Small)) then
						continue
					end
					v_u_3:SetMotor(v_u_856, Enum.VibrationMotor.Small, 0.6)
					task.delay(0.07, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_856
						local v857 = v_u_3.SetMotor
						local v858 = v_u_3
						local v859 = v_u_856
						local v860 = Enum.VibrationMotor.Small
						pcall(v857, v858, v859, v860, 0)
					end)
				end
			end
			pcall(v861)
			v_u_188.TD.began(v_u_149)
			v_u_785(v_u_149)
		end
	end
end
v_u_647 = function(p863)
	-- upvalues: (ref) v_u_149, (copy) v_u_8, (copy) v_u_834, (copy) v_u_18, (copy) v_u_188, (copy) v_u_76, (copy) v_u_16, (copy) v_u_9, (copy) v_u_13, (copy) v_u_29, (copy) v_u_30, (copy) v_u_10, (copy) v_u_31
	-- block 234
	local v864 = v_u_149
	if not v864 then
		return
	end
	v864.pos = p863
	local v865 = v864.m
	local v866 = v865.cell * v_u_8.uiScale()
	local v867 = p863 - v864.grab
	v864.ghost.Position = UDim2.fromOffset(v867.X, v867.Y)
	local v868 = v867 + Vector2.new(v864.w * v866, v864.h * v866) * 0.5
	local v869
	if v864.touch then
		v869 = v868
	else
		v869 = p863
	end
	v_u_834(v865)
	v864.target = nil
	v864.caseWhy = nil
	local v870 = false
	v864.panelHover = nil
	if v864.panelButtons then
		for _, v871 in v864.panelButtons do
			local v872 = v871.btn
			local v873 = v872.AbsolutePosition
			local v874 = v872.AbsoluteSize
			local v875
			if p863.X >= v873.X and (p863.Y >= v873.Y and p863.X < v873.X + v874.X) then
				v875 = p863.Y < v873.Y + v874.Y
			else
				v875 = false
			end
			local v876 = v871.btn
			local v877
			if v875 then
				v877 = v_u_18.raised2
			else
				v877 = v871.base
			end
			v876.BackgroundColor3 = v877
			if not v875 then
				continue
			end
			v864.panelHover = v871.id
		end
		if v864.panelHover then
			v864.gStroke.Color = v_u_18.accent
			return
		end
	end
	if v864.from.kind == "slot" and v864.from.slot == "secure" then
		v864.gStroke.Color = v_u_18.danger
		v864.caseWhy = v_u_188.Why.WHY.secure
		return
	end
	for v878, v879 in v865.slots do
		if not v_u_76(v879.frame) then
			continue
		end
		local v880 = v879.frame
		local v881 = v880.AbsolutePosition
		local v882 = v880.AbsoluteSize
		local v883
		if v869.X >= v881.X and (v869.Y >= v881.Y and v869.X < v881.X + v882.X) then
			v883 = v869.Y < v881.Y + v882.Y
		else
			v883 = false
		end
		if not v883 then
			continue
		end
		if not v_u_16.hover(v865, v864, v_u_16.slotItem(v865.work, v878), nil, v879.hl) then
			local v884 = v_u_9.get(v864.inst.id)
			local v885
			if v_u_188.Att.canSource(v864.from, "ground") then
				v885 = v_u_188.Att.slotTarget(v865.work, v864.inst, v878)
			else
				v885 = nil
			end
			local v886 = v885 == nil and (v884 ~= nil and v_u_13.hint.fits(v884, v878, v864.inst))
			if v886 then
				local v887
				if v864.from.kind == "slot" then
					v887 = v864.from.slot == v878
				else
					v887 = false
				end
				v886 = not v887
				if v886 then
					local v888
					if v865.mode == "raid" then
						v888 = v878 == "secure"
					else
						v888 = false
					end
					v886 = not v888
				end
			end
			local v889 = nil
			if v886 and (v885 == nil and v_u_188.gearGuard()) then
				local v890 = v_u_188.Click.touchSwapRefused
				local v891 = {
					["raid"] = v865.mode == "raid",
					["touch"] = v864.touch == true
				}
				local v892
				if v864.from.kind == "grid" then
					if v864.from.container == "ground" then
						v892 = true
					else
						local v893 = v864.from.c
						if type(v893) == "table" then
							v892 = v864.from.c.world == true
						else
							v892 = false
						end
					end
				else
					v892 = false
				end
				v891.fromWorld = v892
				v891.slotTaken = v_u_16.slotItem(v865.work, v878) ~= nil
				if v890(v891) then
					v886 = false
					v889 = "That slot is taken. Select the item and tap EQUIP to swap."
				end
			end
			v879.hl.Visible = true
			local v894 = v879.hl
			local v895
			if v886 then
				v895 = v_u_18.success
			else
				v895 = v_u_18.danger
			end
			v894.BackgroundColor3 = v895
			if v885 then
				v864.target = {
					["kind"] = "attach",
					["weaponUid"] = nil,
					["weaponUid"] = v885.uid
				}
			elseif v886 then
				v864.target = {
					["kind"] = "slot",
					["slot"] = nil,
					["slot"] = v878
				}
			end
			local v896 = v864.gStroke
			local v897
			if v886 then
				v897 = v_u_18.success
			else
				v897 = v_u_18.danger
			end
			v896.Color = v897
			if not v886 and (v864.from.kind ~= "slot" or v864.from.slot ~= v878) then
				v864.caseWhy = v889 or (v_u_13.hint.why(v884, v878, v864.inst) or v_u_188.Why.slotWhy(v865.mode, v878))
			end
		end
	end
	for v898, v899 in v865.quick do
		if not v_u_76(v899.frame) then
			continue
		end
		local v900 = v899.frame
		local v901 = v900.AbsolutePosition
		local v902 = v900.AbsoluteSize
		local v903
		if v869.X >= v901.X and (v869.Y >= v901.Y and v869.X < v901.X + v902.X) then
			v903 = v869.Y < v901.Y + v902.Y
		else
			v903 = false
		end
		if not v903 then
			continue
		end
		local v904, v905 = v_u_188.Why.quickSlotOk(v865.mode, v864.from.kind, v864.from.container, "ground")
		v864.caseWhy = v905
		v899.hl.Visible = true
		local v906 = v899.hl
		local v907
		if v904 then
			v907 = v_u_18.success
		else
			v907 = v_u_18.danger
		end
		v906.BackgroundColor3 = v907
		if v904 then
			v864.target = {
				["kind"] = "quick",
				["index"] = nil,
				["index"] = v898
			}
		end
		local v908 = v864.gStroke
		local v909
		if v904 then
			v909 = v_u_18.success
		else
			v909 = v_u_18.danger
		end
		v908.Color = v909
		return
	end
	local v910, v911, v912
	-- GenericForInit
v910, v911, v912 = v865.grids, nil, nil
[internal control] = v912
-- end GenericForInit
	local v913, v914
	-- GenericForNext
v913, v914 = v910(v911, [internal control])
if v913 ~= nil
[internal control] = v913
-- end GenericForNext
	::l110::
	if not (v914.cells.Parent and v_u_76(v914.cells)) then
		continue
	end
	local v915 = v914.clip or v914.cells
	local v916 = v915.AbsolutePosition
	local v917 = v915.AbsoluteSize
	local v918
	if v868.X >= v916.X and (v868.Y >= v916.Y and v868.X < v916.X + v917.X) then
		v918 = v868.Y < v916.Y + v917.Y
	else
		v918 = false
	end
	if not v918 then
		continue
	end
	local v919 = v914.cells
	local v920 = v919.AbsolutePosition
	local v921 = v919.AbsoluteSize
	local v922
	if v868.X >= v920.X and (v868.Y >= v920.Y and v868.X < v920.X + v921.X) then
		v922 = v868.Y < v920.Y + v921.Y
	else
		v922 = false
	end
	if not v922 then
		continue
	end
	local v923 = v865.work and v865.work.containers
	if v923 then
		v923 = v865.work.containers[v913]
	end
	if v923 and v913 == "ground" then
		local v924
		if v864.from.kind == "grid" then
			v924 = v864.from.container == "ground"
		else
			v924 = false
		end
		local v925 = not v924
		if v925 then
			local v926
			if v864.from.kind == "slot" then
				v926 = v864.from.slot == "secure"
			else
				v926 = false
			end
			v925 = not v926
		end
		v914.hl.Position = UDim2.fromOffset(0, 0)
		v914.hl.Size = UDim2.fromOffset(v923.w * v865.cell, v923.h * v865.cell)
		v914.hl.Visible = true
		local v927 = v914.hl
		local v928
		if v925 then
			v928 = v_u_18.success
		else
			v928 = v_u_18.danger
		end
		v927.BackgroundColor3 = v928
		local v929 = v914.hlStroke
		local v930
		if v925 then
			v930 = v_u_18.success
		else
			v930 = v_u_18.danger
		end
		v929.Color = v930
		local v931 = v864.gStroke
		local v932
		if v925 then
			v932 = v_u_18.success
		else
			v932 = v_u_18.danger
		end
		v931.Color = v932
		if v925 then
			v864.target = {
				["kind"] = "ground"
			}
		end
		return
	end
	local v933, v934, v935, v936, v937, v938, v939, v940, v941, v942, v943, v944, v945, v946, v947, v948, v949, v950, v951, v952, v953, v954, v955, v956, v957, v958, v959, v960, v961, v962, v963, v964, v965, v966, v967, v968, v969, v970
	if v923 then
		local v971, v972, v973, v974, v975, v976, v977, v978, v979, v980, v981, v982, v983, v984, v985, v986, v987, v988
		if v923.sub == true and v923.bagUid == v864.uid then
			v971 = v914.cells.AbsolutePosition
			v972 = (v867.X - v971.X) / v866 + 0.5
			v973 = math.floor(v972)
			v974 = (v867.Y - v971.Y) / v866 + 0.5
			v975 = math.floor(v974)
			v976 = v923.w - 1
			v977 = math.clamp(v973, 0, v976)
			v978 = v923.h - 1
			v979 = math.clamp(v975, 0, v978)
			v914.hl.Position = UDim2.fromOffset(v977 * v865.cell, v979 * v865.cell)
			v980 = v914.hl
			v981 = UDim2.fromOffset
			v982 = v864.w
			v983 = v923.w - v977
			v984 = math.min(v982, v983) * v865.cell
			v985 = v864.h
			v986 = v923.h - v979
			v980.Size = v981(v984, math.min(v985, v986) * v865.cell)
			v914.hl.Visible = true
			v914.hl.BackgroundColor3 = v_u_18.danger
			v914.hlStroke.Color = v_u_18.danger
			v864.gStroke.Color = v_u_18.danger
			v987 = v_u_188.Why.bagWhy
			if v923.sub == true then
				v988 = v923.bagUid == v864.uid
			else
				v988 = false
			end
			v864.caseWhy = v987(v988)
			return
		elseif v_u_188.fullBag(v864.inst) then
			if v923.sub == true then
				v971 = v914.cells.AbsolutePosition
				v972 = (v867.X - v971.X) / v866 + 0.5
				v973 = math.floor(v972)
				v974 = (v867.Y - v971.Y) / v866 + 0.5
				v975 = math.floor(v974)
				v976 = v923.w - 1
				v977 = math.clamp(v973, 0, v976)
				v978 = v923.h - 1
				v979 = math.clamp(v975, 0, v978)
				v914.hl.Position = UDim2.fromOffset(v977 * v865.cell, v979 * v865.cell)
				v980 = v914.hl
				v981 = UDim2.fromOffset
				v982 = v864.w
				v983 = v923.w - v977
				v984 = math.min(v982, v983) * v865.cell
				v985 = v864.h
				v986 = v923.h - v979
				v980.Size = v981(v984, math.min(v985, v986) * v865.cell)
				v914.hl.Visible = true
				v914.hl.BackgroundColor3 = v_u_18.danger
				v914.hlStroke.Color = v_u_18.danger
				v864.gStroke.Color = v_u_18.danger
				v987 = v_u_188.Why.bagWhy
				if v923.sub == true then
					v988 = v923.bagUid == v864.uid
				else
					v988 = false
				end
				v864.caseWhy = v987(v988)
				return
			else
				local v989 = table.find
				local v990
				if v865.mode == "raid" then
					v990 = v_u_29
				else
					v990 = v_u_30
				end
				if v989(v990, v913) == nil then
					if not v923 then
						continue
					end
					v933 = v914.cells.AbsolutePosition
					v934 = (v867.X - v933.X) / v866 + 0.5
					v935 = math.floor(v934)
					v936 = (v867.Y - v933.Y) / v866 + 0.5
					v937 = math.floor(v936)
					v938 = {
						["uid"] = nil,
						["id"] = nil,
						["x"] = 0,
						["y"] = 0,
						["r"] = nil,
						["n"] = nil,
						["uid"] = v864.uid,
						["id"] = v864.inst.id,
						["r"] = v864.r,
						["n"] = v864.inst.n or 1
					}
					v939 = v914.cells.AbsolutePosition
					v940 = (v869.X - v939.X) / v866
					v941 = math.floor(v940)
					v942 = (v869.Y - v939.Y) / v866
					v943 = math.floor(v942)
					v944 = v_u_10.itemAt(v923, v941, v943, v864.uid)
					v945 = v_u_9.get(v864.inst.id)
					if not v_u_16.hover(v865, v864, v944, v913, v914.hl, v914.hlStroke, v865.cell) then
						if v944 and v_u_10.canStack(v864.inst, v944) then
							v864.target = {
								["kind"] = "grid",
								["container"] = nil,
								["x"] = nil,
								["y"] = nil,
								["r"] = nil,
								["merge"] = nil,
								["container"] = v913,
								["x"] = v941,
								["y"] = v943,
								["r"] = v864.r,
								["merge"] = v944.uid
							}
							v946, v947 = v_u_10.size(v944)
							v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
							v914.hl.Size = UDim2.fromOffset(v946 * v865.cell, v947 * v865.cell)
							v870 = true
						elseif v944 and v_u_188.Click.ammoMix(v865, v864.inst, v944) then
							v864.target = {
								["kind"] = "grid",
								["container"] = nil,
								["x"] = nil,
								["y"] = nil,
								["r"] = nil,
								["merge"] = nil,
								["container"] = v913,
								["x"] = v941,
								["y"] = v943,
								["r"] = v864.r,
								["merge"] = v944.uid
							}
							v948, v949 = v_u_10.size(v944)
							v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
							v914.hl.Size = UDim2.fromOffset(v948 * v865.cell, v949 * v865.cell)
							v870 = true
						elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) and v_u_9.fitsWeapon(v945, v_u_9.get(v944.id).weaponId or v944.id) then
							v864.target = {
								["kind"] = "attach",
								["weaponUid"] = nil,
								["weaponUid"] = v944.uid
							}
							v950, v951 = v_u_10.size(v944)
							v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
							v914.hl.Size = UDim2.fromOffset(v950 * v865.cell, v951 * v865.cell)
							v870 = true
						elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) then
							v864.caseWhy = v_u_188.Why.WHY.noFit
							v952, v953 = v_u_10.size(v944)
							v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
							v914.hl.Size = UDim2.fromOffset(v952 * v865.cell, v953 * v865.cell)
						else
							v870 = v_u_10.fits(v923, v938, v935, v937, v864.r, v864.uid) and v_u_188.Case.canDrop(v864, v923)
							if v870 then
								v870 = not v_u_188.Search.blocksItem(v923, v938, v935, v937, v864.r)
							end
							if v923.limit and (v864.w > v923.limit.w or v864.h > v923.limit.h) then
								v864.caseWhy = v_u_188.Why.limitWhy(v_u_31[v913] or "This container", v923.limit)
								v870 = false
							end
							if not v870 and (v944 and (v944.id == v864.inst.id and (v944.uid ~= v864.uid and not v864.caseWhy))) then
								v864.caseWhy = v_u_188.Why.stackWhy((v944.n or 1) >= v_u_10.stackMax(v944), (v864.inst.mods ~= nil or (v944.mods ~= nil or v864.inst.items ~= nil)) and true or v944.items ~= nil, v_u_10.stackMax(v944))
							end
							if v870 then
								v864.target = {
									["kind"] = "grid",
									["container"] = nil,
									["x"] = nil,
									["y"] = nil,
									["r"] = nil,
									["container"] = v913,
									["x"] = v935,
									["y"] = v937,
									["r"] = v864.r
								}
							end
							v954 = v923.w - 1
							v955 = math.clamp(v935, 0, v954)
							v956 = v923.h - 1
							v957 = math.clamp(v937, 0, v956)
							v914.hl.Position = UDim2.fromOffset(v955 * v865.cell, v957 * v865.cell)
							v958 = v914.hl
							v959 = UDim2.fromOffset
							v960 = v864.w
							v961 = v923.w - v955
							v962 = math.min(v960, v961) * v865.cell
							v963 = v864.h
							v964 = v923.h - v957
							v958.Size = v959(v962, math.min(v963, v964) * v865.cell)
						end
						v914.hl.Visible = true
						v965 = v914.hl
						if v870 then
							v966 = v_u_18.success
						else
							v966 = v_u_18.danger
						end
						v965.BackgroundColor3 = v966
						v967 = v914.hlStroke
						if v870 then
							v968 = v_u_18.success
						else
							v968 = v_u_18.danger
						end
						v967.Color = v968
						v969 = v864.gStroke
						if v870 then
							v970 = v_u_18.success
						else
							v970 = v_u_18.danger
						end
						v969.Color = v970
					end
				else
					v971 = v914.cells.AbsolutePosition
					v972 = (v867.X - v971.X) / v866 + 0.5
					v973 = math.floor(v972)
					v974 = (v867.Y - v971.Y) / v866 + 0.5
					v975 = math.floor(v974)
					v976 = v923.w - 1
					v977 = math.clamp(v973, 0, v976)
					v978 = v923.h - 1
					v979 = math.clamp(v975, 0, v978)
					v914.hl.Position = UDim2.fromOffset(v977 * v865.cell, v979 * v865.cell)
					v980 = v914.hl
					v981 = UDim2.fromOffset
					v982 = v864.w
					v983 = v923.w - v977
					v984 = math.min(v982, v983) * v865.cell
					v985 = v864.h
					v986 = v923.h - v979
					v980.Size = v981(v984, math.min(v985, v986) * v865.cell)
					v914.hl.Visible = true
					v914.hl.BackgroundColor3 = v_u_18.danger
					v914.hlStroke.Color = v_u_18.danger
					v864.gStroke.Color = v_u_18.danger
					v987 = v_u_188.Why.bagWhy
					if v923.sub == true then
						v988 = v923.bagUid == v864.uid
					else
						v988 = false
					end
					v864.caseWhy = v987(v988)
					return
				end
			end
		else
			if not v923 then
				continue
			end
			v933 = v914.cells.AbsolutePosition
			v934 = (v867.X - v933.X) / v866 + 0.5
			v935 = math.floor(v934)
			v936 = (v867.Y - v933.Y) / v866 + 0.5
			v937 = math.floor(v936)
			v938 = {
				["uid"] = nil,
				["id"] = nil,
				["x"] = 0,
				["y"] = 0,
				["r"] = nil,
				["n"] = nil,
				["uid"] = v864.uid,
				["id"] = v864.inst.id,
				["r"] = v864.r,
				["n"] = v864.inst.n or 1
			}
			v939 = v914.cells.AbsolutePosition
			v940 = (v869.X - v939.X) / v866
			v941 = math.floor(v940)
			v942 = (v869.Y - v939.Y) / v866
			v943 = math.floor(v942)
			v944 = v_u_10.itemAt(v923, v941, v943, v864.uid)
			v945 = v_u_9.get(v864.inst.id)
			if not v_u_16.hover(v865, v864, v944, v913, v914.hl, v914.hlStroke, v865.cell) then
				if v944 and v_u_10.canStack(v864.inst, v944) then
					v864.target = {
						["kind"] = "grid",
						["container"] = nil,
						["x"] = nil,
						["y"] = nil,
						["r"] = nil,
						["merge"] = nil,
						["container"] = v913,
						["x"] = v941,
						["y"] = v943,
						["r"] = v864.r,
						["merge"] = v944.uid
					}
					v946, v947 = v_u_10.size(v944)
					v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
					v914.hl.Size = UDim2.fromOffset(v946 * v865.cell, v947 * v865.cell)
					v870 = true
				elseif v944 and v_u_188.Click.ammoMix(v865, v864.inst, v944) then
					v864.target = {
						["kind"] = "grid",
						["container"] = nil,
						["x"] = nil,
						["y"] = nil,
						["r"] = nil,
						["merge"] = nil,
						["container"] = v913,
						["x"] = v941,
						["y"] = v943,
						["r"] = v864.r,
						["merge"] = v944.uid
					}
					v948, v949 = v_u_10.size(v944)
					v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
					v914.hl.Size = UDim2.fromOffset(v948 * v865.cell, v949 * v865.cell)
					v870 = true
				elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) and v_u_9.fitsWeapon(v945, v_u_9.get(v944.id).weaponId or v944.id) then
					v864.target = {
						["kind"] = "attach",
						["weaponUid"] = nil,
						["weaponUid"] = v944.uid
					}
					v950, v951 = v_u_10.size(v944)
					v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
					v914.hl.Size = UDim2.fromOffset(v950 * v865.cell, v951 * v865.cell)
					v870 = true
				elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) then
					v864.caseWhy = v_u_188.Why.WHY.noFit
					v952, v953 = v_u_10.size(v944)
					v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
					v914.hl.Size = UDim2.fromOffset(v952 * v865.cell, v953 * v865.cell)
				else
					v870 = v_u_10.fits(v923, v938, v935, v937, v864.r, v864.uid) and v_u_188.Case.canDrop(v864, v923)
					if v870 then
						v870 = not v_u_188.Search.blocksItem(v923, v938, v935, v937, v864.r)
					end
					if v923.limit and (v864.w > v923.limit.w or v864.h > v923.limit.h) then
						v864.caseWhy = v_u_188.Why.limitWhy(v_u_31[v913] or "This container", v923.limit)
						v870 = false
					end
					if not v870 and (v944 and (v944.id == v864.inst.id and (v944.uid ~= v864.uid and not v864.caseWhy))) then
						v864.caseWhy = v_u_188.Why.stackWhy((v944.n or 1) >= v_u_10.stackMax(v944), (v864.inst.mods ~= nil or (v944.mods ~= nil or v864.inst.items ~= nil)) and true or v944.items ~= nil, v_u_10.stackMax(v944))
					end
					if v870 then
						v864.target = {
							["kind"] = "grid",
							["container"] = nil,
							["x"] = nil,
							["y"] = nil,
							["r"] = nil,
							["container"] = v913,
							["x"] = v935,
							["y"] = v937,
							["r"] = v864.r
						}
					end
					v954 = v923.w - 1
					v955 = math.clamp(v935, 0, v954)
					v956 = v923.h - 1
					v957 = math.clamp(v937, 0, v956)
					v914.hl.Position = UDim2.fromOffset(v955 * v865.cell, v957 * v865.cell)
					v958 = v914.hl
					v959 = UDim2.fromOffset
					v960 = v864.w
					v961 = v923.w - v955
					v962 = math.min(v960, v961) * v865.cell
					v963 = v864.h
					v964 = v923.h - v957
					v958.Size = v959(v962, math.min(v963, v964) * v865.cell)
				end
				v914.hl.Visible = true
				v965 = v914.hl
				if v870 then
					v966 = v_u_18.success
				else
					v966 = v_u_18.danger
				end
				v965.BackgroundColor3 = v966
				v967 = v914.hlStroke
				if v870 then
					v968 = v_u_18.success
				else
					v968 = v_u_18.danger
				end
				v967.Color = v968
				v969 = v864.gStroke
				if v870 then
					v970 = v_u_18.success
				else
					v970 = v_u_18.danger
				end
				v969.Color = v970
			end
		end
	else
		if not v923 then
			continue
		end
		v933 = v914.cells.AbsolutePosition
		v934 = (v867.X - v933.X) / v866 + 0.5
		v935 = math.floor(v934)
		v936 = (v867.Y - v933.Y) / v866 + 0.5
		v937 = math.floor(v936)
		v938 = {
			["uid"] = nil,
			["id"] = nil,
			["x"] = 0,
			["y"] = 0,
			["r"] = nil,
			["n"] = nil,
			["uid"] = v864.uid,
			["id"] = v864.inst.id,
			["r"] = v864.r,
			["n"] = v864.inst.n or 1
		}
		v939 = v914.cells.AbsolutePosition
		v940 = (v869.X - v939.X) / v866
		v941 = math.floor(v940)
		v942 = (v869.Y - v939.Y) / v866
		v943 = math.floor(v942)
		v944 = v_u_10.itemAt(v923, v941, v943, v864.uid)
		v945 = v_u_9.get(v864.inst.id)
		if not v_u_16.hover(v865, v864, v944, v913, v914.hl, v914.hlStroke, v865.cell) then
			if v944 and v_u_10.canStack(v864.inst, v944) then
				v864.target = {
					["kind"] = "grid",
					["container"] = nil,
					["x"] = nil,
					["y"] = nil,
					["r"] = nil,
					["merge"] = nil,
					["container"] = v913,
					["x"] = v941,
					["y"] = v943,
					["r"] = v864.r,
					["merge"] = v944.uid
				}
				v946, v947 = v_u_10.size(v944)
				v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
				v914.hl.Size = UDim2.fromOffset(v946 * v865.cell, v947 * v865.cell)
				v870 = true
			elseif v944 and v_u_188.Click.ammoMix(v865, v864.inst, v944) then
				v864.target = {
					["kind"] = "grid",
					["container"] = nil,
					["x"] = nil,
					["y"] = nil,
					["r"] = nil,
					["merge"] = nil,
					["container"] = v913,
					["x"] = v941,
					["y"] = v943,
					["r"] = v864.r,
					["merge"] = v944.uid
				}
				v948, v949 = v_u_10.size(v944)
				v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
				v914.hl.Size = UDim2.fromOffset(v948 * v865.cell, v949 * v865.cell)
				v870 = true
			elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) and v_u_9.fitsWeapon(v945, v_u_9.get(v944.id).weaponId or v944.id) then
				v864.target = {
					["kind"] = "attach",
					["weaponUid"] = nil,
					["weaponUid"] = v944.uid
				}
				v950, v951 = v_u_10.size(v944)
				v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
				v914.hl.Size = UDim2.fromOffset(v950 * v865.cell, v951 * v865.cell)
				v870 = true
			elseif v944 and (v945 and (v945.category == "attachment" and (v864.from.container ~= "ground" and (not v923.case and (v_u_9.get(v944.id) and v_u_9.get(v944.id).category == "firearm"))))) then
				v864.caseWhy = v_u_188.Why.WHY.noFit
				v952, v953 = v_u_10.size(v944)
				v914.hl.Position = UDim2.fromOffset(v944.x * v865.cell, v944.y * v865.cell)
				v914.hl.Size = UDim2.fromOffset(v952 * v865.cell, v953 * v865.cell)
			else
				v870 = v_u_10.fits(v923, v938, v935, v937, v864.r, v864.uid) and v_u_188.Case.canDrop(v864, v923)
				if v870 then
					v870 = not v_u_188.Search.blocksItem(v923, v938, v935, v937, v864.r)
				end
				if v923.limit and (v864.w > v923.limit.w or v864.h > v923.limit.h) then
					v864.caseWhy = v_u_188.Why.limitWhy(v_u_31[v913] or "This container", v923.limit)
					v870 = false
				end
				if not v870 and (v944 and (v944.id == v864.inst.id and (v944.uid ~= v864.uid and not v864.caseWhy))) then
					v864.caseWhy = v_u_188.Why.stackWhy((v944.n or 1) >= v_u_10.stackMax(v944), (v864.inst.mods ~= nil or (v944.mods ~= nil or v864.inst.items ~= nil)) and true or v944.items ~= nil, v_u_10.stackMax(v944))
				end
				if v870 then
					v864.target = {
						["kind"] = "grid",
						["container"] = nil,
						["x"] = nil,
						["y"] = nil,
						["r"] = nil,
						["container"] = v913,
						["x"] = v935,
						["y"] = v937,
						["r"] = v864.r
					}
				end
				v954 = v923.w - 1
				v955 = math.clamp(v935, 0, v954)
				v956 = v923.h - 1
				v957 = math.clamp(v937, 0, v956)
				v914.hl.Position = UDim2.fromOffset(v955 * v865.cell, v957 * v865.cell)
				v958 = v914.hl
				v959 = UDim2.fromOffset
				v960 = v864.w
				v961 = v923.w - v955
				v962 = math.min(v960, v961) * v865.cell
				v963 = v864.h
				v964 = v923.h - v957
				v958.Size = v959(v962, math.min(v963, v964) * v865.cell)
			end
			v914.hl.Visible = true
			v965 = v914.hl
			if v870 then
				v966 = v_u_18.success
			else
				v966 = v_u_18.danger
			end
			v965.BackgroundColor3 = v966
			v967 = v914.hlStroke
			if v870 then
				v968 = v_u_18.success
			else
				v968 = v_u_18.danger
			end
			v967.Color = v968
			v969 = v864.gStroke
			if v870 then
				v970 = v_u_18.success
			else
				v970 = v_u_18.danger
			end
			v969.Color = v970
		end
	end
	-- block 157
	goto l110
	-- block 158
	goto l233
	::l233::
	v864.gStroke.Color = v_u_18.lineStrong
	return
end
local function v_u_1010(_, p991) -- name: endDrag
	-- upvalues: (ref) v_u_149, (copy) v_u_11, (copy) v_u_188, (copy) v_u_785, (copy) v_u_834, (ref) v_u_156, (copy) v_u_12, (ref) v_u_159, (copy) v_u_21, (ref) v_u_180, (ref) v_u_179, (copy) v_u_803, (copy) v_u_814, (copy) v_u_379, (copy) v_u_198, (copy) v_u_212, (copy) v_u_16
	local v992 = v_u_149
	if v992 then
		if v992.touch and (v992.caseWhy and not (v992.target or (p991 or v992.panelHover))) then
			local v993 = v992.caseWhy
			local v994 = v_u_11.toast
			pcall(v994, v993, "warn")
			v992.caseWhy = nil
		end
		if v_u_188.TD.endHook(v992, p991, v_u_188.padApi, v_u_785) then
			return
		else
			v_u_149 = nil
			local v_u_995 = v992.m
			v_u_834(v_u_995)
			if v_u_156 then
				v_u_156:Destroy()
				v_u_156 = nil
			end
			v_u_12.release(v992.icon)
			v992.ghost:Destroy()
			if v992.src then
				v992.src.setGhosted(false)
			end
			if v992.touch then
				if p991 or (not v_u_159 or v_u_159.uid ~= v992.uid) then
					local v996 = v_u_159
					if v996 then
						v_u_159 = nil
						if v996.mark then
							v996.mark:Destroy()
						end
						if not v_u_149 and v_u_156 then
							v_u_156:Destroy()
							v_u_156 = nil
						end
						if v_u_21 then
							v_u_21:SetAttribute("InvUISelected", nil)
						end
					end
				else
					v_u_159.dirty = true
				end
			end
			if v992.railOpened and v_u_995.rail then
				task.delay(0.35, function()
					-- upvalues: (copy) v_u_995, (ref) v_u_149, (ref) v_u_180
					if not (v_u_995.dead or v_u_149) then
						v_u_180(v_u_995, false)
					end
				end)
			end
			if v_u_995.relayoutPending then
				v_u_995.relayoutPending = false
				task.defer(function()
					-- upvalues: (copy) v_u_995, (ref) v_u_149, (ref) v_u_179
					if not v_u_995.dead and (v_u_995.opened and not v_u_149) then
						v_u_179(v_u_995)
					end
				end)
			end
			if p991 then
				return
			elseif v992.panelHover then
				local v997 = v992.panelHover
				if v997 == "rotate" then
					v_u_803()
					return
				elseif v997 == "cancel" then
					v_u_814()
				else
					v_u_379(v_u_995, v992.uid, v997)
				end
			else
				local v998 = v992.target
				if v998 then
					if v998.kind == "grid" then
						local v999 = v992.from
						if v999.kind == "grid" and (v999.container == v998.container and (v999.item.x == v998.x and v999.item.y == v998.y)) and (v999.item.r == true == v998.r and not v998.merge) then
							return
						elseif not v_u_188.Click.firAsk(v_u_995, v992, v998, v_u_198) then
							v_u_198(v_u_995, {
								["op"] = "move",
								["uid"] = nil,
								["to"] = nil,
								["x"] = nil,
								["y"] = nil,
								["r"] = nil,
								["uid"] = v992.uid,
								["to"] = v998.container,
								["x"] = v998.x,
								["y"] = v998.y,
								["r"] = v998.r
							})
							v_u_212(v_u_995, v992.uid, v998.container, v998.x, v998.y, v998.r)
							local v1000 = v_u_11.sound
							pcall(v1000, "click")
						end
					elseif v998.kind == "ground" then
						v_u_198(v_u_995, {
							["op"] = "move",
							["uid"] = nil,
							["to"] = "ground",
							["uid"] = v992.uid
						})
						local v1001 = v_u_11.sound
						pcall(v1001, "close")
						return
					elseif v998.kind == "slot" then
						v_u_198(v_u_995, {
							["op"] = "equip",
							["uid"] = nil,
							["slot"] = nil,
							["uid"] = v992.uid,
							["slot"] = v998.slot
						})
						local v1002 = v_u_11.sound
						pcall(v1002, "click")
						return
					elseif v998.kind == "quick" then
						v_u_198(v_u_995, {
							["op"] = "setquick",
							["uid"] = nil,
							["index"] = nil,
							["uid"] = v992.uid,
							["index"] = v998.index
						})
						local v1003 = v_u_11.sound
						pcall(v1003, "confirm")
						return
					elseif v998.kind == "attach" then
						v_u_198(v_u_995, {
							["op"] = "attach",
							["uid"] = nil,
							["weaponUid"] = nil,
							["uid"] = v992.uid,
							["weaponUid"] = v998.weaponUid
						})
						local v1004 = v_u_11.sound
						pcall(v1004, "confirm")
					elseif v998.kind == "load" then
						v_u_198(v_u_995, v_u_16.dropOp(v998, v_u_995.mode))
						local v1005 = v998.ok and "confirm" or "error"
						local v1006 = v_u_11.sound
						pcall(v1006, v1005)
					end
				else
					local v1007 = v_u_11.sound
					pcall(v1007, "error")
					if v992.caseWhy then
						local v1008 = v992.caseWhy
						local v1009 = v_u_11.toast
						pcall(v1009, v1008, "warn")
					end
					return
				end
			end
		end
	else
		return
	end
end
function v_u_188.padApi() -- name: padApi
	-- upvalues: (copy) v_u_862, (ref) v_u_647, (copy) v_u_1010, (ref) v_u_149, (copy) v_u_635, (copy) v_u_11, (copy) v_u_47, (copy) v_u_43
	return {
		["beginDrag"] = v_u_862,
		["updateDrag"] = function(p1011) -- name: updateDrag
			-- upvalues: (ref) v_u_647
			v_u_647(p1011)
		end,
		["endDrag"] = v_u_1010,
		["drag"] = function() -- name: drag
			-- upvalues: (ref) v_u_149
			return v_u_149
		end,
		["cell"] = v_u_635,
		["tileOf"] = function(p1012, p1013) -- name: tileOf
			local v1014 = p1012.tiles[p1013]
			if v1014 and (v1014.frame and v1014.frame.Parent) then
				return v1014, v1014.frame
			end
			for _, v1015 in p1012.slots do
				if not v1015.tile or (not v1015.tile.inst or (v1015.tile.inst.uid ~= p1013 or not v1015.tile.frame)) then
					continue
				end
				return v1015.tile, v1015.tile.frame
			end
			return nil, nil
		end,
		["hint"] = function(p1016) -- name: hint
			-- upvalues: (ref) v_u_11
			return v_u_11.hint(p1016)
		end,
		["toast"] = v_u_47,
		["sound"] = v_u_43
	}
end
local function v_u_1040(p1017, p1018, p1019, p1020, p1021) -- name: onPress
	-- upvalues: (ref) v_u_149, (copy) v_u_188, (copy) v_u_1010, (ref) v_u_158, (copy) v_u_471, (copy) v_u_164, (copy) v_u_2, (copy) v_u_379, (copy) v_u_175, (ref) v_u_290, (ref) v_u_148, (copy) v_u_80, (ref) v_u_159, (copy) v_u_862, (copy) v_u_385
	if p1021.UserInputType == Enum.UserInputType.Touch then
		if v_u_149 and v_u_188.TD.fingerGone(v_u_149) then
			v_u_1010(v_u_149.pos, false)
		end
		v_u_188.TD.heal(v_u_149 ~= nil)
	end
	if v_u_149 and (not v_u_149.parked or p1021.UserInputType ~= Enum.UserInputType.Touch) or not p1017.isShown() then
		return
	else
		local v1022 = p1021.UserInputType
		local v1023 = Vector2.new(p1021.Position.X, p1021.Position.Y)
		v_u_158 = v1023
		if v1022 == Enum.UserInputType.MouseButton2 then
			v_u_471(p1017, p1018, v1023)
			return
		elseif v1022 == Enum.UserInputType.MouseButton1 then
			v_u_164()
			if v_u_2:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_2:IsKeyDown(Enum.KeyCode.RightControl) then
				v_u_379(p1017, p1018, v_u_175(p1017.work, p1018) and v_u_175(p1017.work, p1018).kind == "slot" and "unequip" or "quick")
				return
			elseif v_u_2:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_2:IsKeyDown(Enum.KeyCode.RightShift) then
				local v1024 = v_u_175(p1017.work, p1018)
				if v1024 and (v1024.item.n or 1) > 1 then
					v_u_290(p1017, p1018)
				end
			else
				v_u_148 = {
					["m"] = nil,
					["uid"] = nil,
					["tile"] = nil,
					["tileFrame"] = nil,
					["io"] = nil,
					["start"] = nil,
					["t"] = nil,
					["touch"] = false,
					["m"] = p1017,
					["uid"] = p1018,
					["tile"] = p1019,
					["tileFrame"] = p1020,
					["io"] = p1021,
					["start"] = v1023,
					["t"] = os.clock()
				}
			end
		elseif v1022 == Enum.UserInputType.Touch then
			v_u_164()
			local v1025 = v_u_80(p1020)
			local v1026
			if v_u_159 == nil or v_u_159.m ~= p1017 then
				v1026 = false
			else
				v1026 = v_u_159.uid == p1018
			end
			local v1027 = v_u_149 ~= nil and true or v1026
			local v_u_1028 = {
				["m"] = nil,
				["uid"] = nil,
				["tile"] = nil,
				["tileFrame"] = nil,
				["io"] = nil,
				["start"] = nil,
				["t"] = nil,
				["touch"] = true,
				["sc"] = nil,
				["canvas0"] = nil,
				["parked"] = nil,
				["inHand"] = nil,
				["m"] = p1017,
				["uid"] = p1018,
				["tile"] = p1019,
				["tileFrame"] = p1020,
				["io"] = p1021,
				["start"] = v1023,
				["t"] = os.clock(),
				["sc"] = v1025
			}
			local v1029
			if v1025 then
				v1029 = v1025.CanvasPosition
			else
				v1029 = nil
			end
			v_u_1028.canvas0 = v1029
			v_u_1028.parked = v1027
			v_u_1028.inHand = v_u_149 ~= nil
			local v1030 = v_u_188.TD.fsm
			local v1031 = v1023.X
			local v1032 = v1023.Y
			local v1033 = os.clock()
			if v1026 then
				v1026 = v_u_149 == nil
			end
			if v1030:press(p1021, v1031, v1032, v1033, v1026) ~= "ignore" then
				v_u_148 = v_u_1028
				task.delay(0.25, function()
					-- upvalues: (ref) v_u_148, (copy) v_u_1028, (ref) v_u_188, (ref) v_u_862, (ref) v_u_149, (ref) v_u_1010
					if v_u_148 == v_u_1028 and v_u_188.TD.fsm:tick(os.clock()) == "pickup" then
						v_u_148 = nil
						local v1034 = v_u_862
						local v1035 = v_u_1028
						local v1036 = v_u_1028.last or v_u_1028.start
						local v1037, v1038 = pcall(v1034, v1035, v1036)
						v_u_188.TD.afterPickup(v1037, v1038, v_u_149, v_u_1010)
					end
				end)
			end
		elseif p1021.KeyCode == Enum.KeyCode.ButtonA then
			local v1039 = v_u_175(p1017.work, p1018)
			v_u_379(p1017, p1018, v1039 and v1039.kind == "slot" and "unequip" or "quick")
			return
		elseif p1021.KeyCode == Enum.KeyCode.ButtonX then
			v_u_471(p1017, p1018, p1020.AbsolutePosition + p1020.AbsoluteSize * 0.5)
		elseif p1021.KeyCode == Enum.KeyCode.ButtonY then
			v_u_385(p1017, p1018)
		end
	end
end
local function v_u_1051(p1041, _) -- name: onRelease
	-- upvalues: (ref) v_u_150, (copy) v_u_188, (ref) v_u_149, (copy) v_u_11, (copy) v_u_175, (ref) v_u_151, (copy) v_u_385, (ref) v_u_153, (copy) v_u_136, (copy) v_u_379
	local v_u_1042 = p1041.m
	local v_u_1043 = p1041.uid
	if p1041.touch then
		if p1041.parked then
			if p1041.inHand and (v_u_149 ~= nil and (v_u_149.parked and os.clock() - (v_u_188.handHintAt or -10) > 3)) then
				v_u_188.handHintAt = os.clock()
				local v1044 = v_u_11.toast
				pcall(v1044, "Item in hand. Drop it on a cell or tap CANCEL.", "info")
			end
			return
		elseif v_u_188.Click.touchTapSelects({
			["loc"] = v_u_175(v_u_1042.work, v_u_1043),
			["raid"] = v_u_1042.mode == "raid"
		}) and v_u_188.gearGuard() then
			v_u_151 = nil
			v_u_188.selectTile(v_u_1042, v_u_1043)
			return
		else
			local v1045 = os.clock()
			if v_u_151 and (v_u_151.uid == v_u_1043 and v1045 - v_u_151.t < 0.3) then
				v_u_151 = nil
				v_u_385(v_u_1042, v_u_1043)
			else
				v_u_153 = v_u_153 + 1
				local v_u_1046 = v_u_153
				local v1047 = v_u_175(v_u_1042.work, v_u_1043)
				local v_u_1048
				if v1047 then
					v_u_1048 = v1047.container or v1047.slot
				else
					v_u_1048 = nil
				end
				v_u_151 = {
					["uid"] = v_u_1043,
					["t"] = v1045,
					["token"] = v_u_1046,
					["from"] = v_u_1048
				}
				task.delay(0.3, function()
					-- upvalues: (ref) v_u_151, (copy) v_u_1046, (ref) v_u_136, (copy) v_u_1042, (ref) v_u_175, (copy) v_u_1043, (copy) v_u_1048, (ref) v_u_149, (ref) v_u_379
					if v_u_151 and v_u_151.token == v_u_1046 then
						v_u_151 = nil
						local v1049
						if table.find(v_u_136, v_u_1042) then
							v1049 = v_u_175(v_u_1042.work, v_u_1043)
						else
							v1049 = nil
						end
						if v1049 and ((v1049.container or v1049.slot) == v_u_1048 and (v_u_1042.isShown() and v_u_149 == nil)) then
							v_u_379(v_u_1042, v_u_1043, "quick")
						end
					end
				end)
			end
		end
	else
		local v1050 = os.clock()
		if v_u_150 and (v_u_150.uid == v_u_1043 and v1050 - v_u_150.t < 0.3) then
			v_u_150 = nil
			v_u_188.mouseDouble(v_u_1042, v_u_1043)
		else
			v_u_150 = {
				["uid"] = v_u_1043,
				["t"] = v1050
			}
		end
	end
end
local function v_u_1070(p1052, p1053) -- name: touchScroll
	local v1054 = p1052.scroll
	local v1055 = v1054.sc
	if not v1054.native and v1055.Parent then
		local v1056 = v1055.CanvasPosition
		if v1054.wrote then
			if (v1056 - v1054.wrote).Magnitude > 1 then
				v1054.native = true
				return
			end
		elseif not v1054.origin then
			if (v1056 - v1054.startCanvas).Magnitude > 0.5 then
				v1054.native = true
				return
			end
			if (p1053 - v1054.startPos).Magnitude < 26 then
				return
			end
			v1054.origin = p1053
			v1054.originCanvas = v1056
		end
		local v1057 = p1053 - v1054.origin
		local v1058 = v1055.ScrollingDirection
		local v1059 = v1058 == Enum.ScrollingDirection.Y and 0 or v1057.X
		local v1060 = v1058 == Enum.ScrollingDirection.X and 0 or v1057.Y
		local v1061 = v1055.AbsoluteCanvasSize.X - v1055.AbsoluteWindowSize.X
		local v1062 = math.max(0, v1061)
		local v1063 = v1055.AbsoluteCanvasSize.Y - v1055.AbsoluteWindowSize.Y
		local v1064 = math.max(0, v1063)
		local v1065 = Vector2.new
		local v1066 = v1054.originCanvas.X - v1059
		local v1067 = math.clamp(v1066, 0, v1062)
		local v1068 = v1054.originCanvas.Y - v1060
		local v1069 = v1065(v1067, (math.clamp(v1068, 0, v1064)))
		if (v1069 - v1056).Magnitude > 0.25 then
			v1055.CanvasPosition = v1069
		end
		v1054.wrote = v1055.CanvasPosition
	end
end
local function v_u_1102() -- name: hookGlobalInput
	-- upvalues: (copy) v_u_2, (ref) v_u_158, (ref) v_u_149, (ref) v_u_647, (ref) v_u_148, (copy) v_u_188, (copy) v_u_1070, (copy) v_u_862, (copy) v_u_1010, (ref) v_u_160, (ref) v_u_159, (ref) v_u_156, (copy) v_u_790, (copy) v_u_21, (copy) v_u_1051, (ref) v_u_20, (ref) v_u_154, (ref) v_u_155, (copy) v_u_164, (copy) v_u_19, (copy) v_u_11
	v_u_2.InputChanged:Connect(function(p1071)
		-- upvalues: (ref) v_u_158, (ref) v_u_149, (ref) v_u_647, (ref) v_u_148, (ref) v_u_188, (ref) v_u_1070, (ref) v_u_862
		local v1072 = p1071.UserInputType
		if v1072 == Enum.UserInputType.MouseMovement or v1072 == Enum.UserInputType.Touch then
			local v1073 = Vector2.new(p1071.Position.X, p1071.Position.Y)
			v_u_158 = v1073
			if v_u_149 and not v_u_149.parked then
				if v_u_149.touch and p1071 == v_u_149.io or not v_u_149.touch and v1072 == Enum.UserInputType.MouseMovement then
					v_u_647(v1073)
				end
			else
				local v1074 = v_u_148
				if v1074 then
					if v1074.touch then
						if p1071 == v1074.io then
							v1074.last = v1073
							local v1075
							if v1074.scroll then
								v1075 = nil
							else
								v1075 = v_u_188.TD.fsm:move(p1071, v1073.X, v1073.Y)
							end
							if v1074.scroll then
								v_u_1070(v1074, v1073)
								return
							end
							if v1075 == "pickup" then
								v_u_148 = nil
								v_u_862(v1074, v1073)
								return
							end
							if v1075 == "swipe" then
								if v1074.sc and v1074.canvas0 then
									v1074.scroll = {
										["sc"] = v1074.sc,
										["startCanvas"] = v1074.canvas0,
										["startPos"] = v1074.start
									}
									v_u_1070(v1074, v1073)
								else
									v_u_148 = nil
								end
							end
						end
					elseif v1072 == Enum.UserInputType.MouseMovement and (v1073 - v1074.start).Magnitude > 6 then
						v_u_148 = nil
						v_u_862(v1074, v1073)
					end
				end
			end
		else
			return
		end
	end)
	v_u_2.InputEnded:Connect(function(p1076)
		-- upvalues: (ref) v_u_188, (ref) v_u_149, (ref) v_u_1010, (ref) v_u_160, (ref) v_u_159, (ref) v_u_156, (ref) v_u_790, (ref) v_u_21, (ref) v_u_148, (ref) v_u_1051
		local v1077 = p1076.UserInputType
		local v1078 = Vector2.new(p1076.Position.X, p1076.Position.Y)
		v_u_188.TD.lift(p1076)
		if v_u_149 and not v_u_149.parked then
			if v_u_149.touch and p1076 == v_u_149.io or not v_u_149.touch and v1077 == Enum.UserInputType.MouseButton1 then
				v_u_1010(v1078)
			end
		else
			local v1079 = false
			local v1080 = v_u_160
			if v1080 and p1076 == v1080.io then
				v_u_160 = nil
				if v_u_159 and (v1078 - v1080.pos).Magnitude <= 14 then
					local v1081
					if v_u_156 == nil or v_u_156.Parent == nil then
						v1081 = false
					else
						local v1082 = v_u_156
						local v1083 = v1082.AbsolutePosition
						local v1084 = v1082.AbsoluteSize
						if v1078.X >= v1083.X and (v1078.Y >= v1083.Y and v1078.X < v1083.X + v1084.X) then
							v1081 = v1078.Y < v1083.Y + v1084.Y
						else
							v1081 = false
						end
					end
					local v1085 = v_u_790(v_u_159.m, v_u_159.uid)
					local v1086
					if v1085 == nil then
						v1086 = false
					else
						local v1087 = v1085.AbsolutePosition
						local v1088 = v1085.AbsoluteSize
						if v1078.X >= v1087.X and (v1078.Y >= v1087.Y and v1078.X < v1087.X + v1088.X) then
							v1086 = v1078.Y < v1087.Y + v1088.Y
						else
							v1086 = false
						end
					end
					if not (v1081 or v1086) then
						local v1089 = v_u_159
						if v1089 then
							v_u_159 = nil
							if v1089.mark then
								v1089.mark:Destroy()
							end
							if not v_u_149 and v_u_156 then
								v_u_156:Destroy()
								v_u_156 = nil
							end
							if v_u_21 then
								v_u_21:SetAttribute("InvUISelected", nil)
								v1079 = true
							else
								v1079 = true
							end
						else
							v1079 = true
						end
					end
				end
			end
			local v1090 = v_u_148
			if v1090 and (v1090.touch and p1076 == v1090.io or not v1090.touch and v1077 == Enum.UserInputType.MouseButton1) then
				v_u_148 = nil
				if not (v1090.scroll or v1079) then
					v_u_1051(v1090, v1078)
				end
			end
		end
	end)
	v_u_20.lib.VirtualPad.InputBegan:Connect(function(p1091)
		-- upvalues: (ref) v_u_158, (ref) v_u_154, (ref) v_u_155, (ref) v_u_164, (ref) v_u_159, (ref) v_u_149, (ref) v_u_160, (ref) v_u_21, (ref) v_u_188, (ref) v_u_19, (ref) v_u_11, (ref) v_u_20
		if p1091.UserInputType == Enum.UserInputType.MouseButton1 or p1091.UserInputType == Enum.UserInputType.Touch then
			local v1092 = Vector2.new(p1091.Position.X, p1091.Position.Y)
			v_u_158 = v1092
			if v_u_154 then
				local v1093 = v_u_154
				local v1094 = v1093.AbsolutePosition
				local v1095 = v1093.AbsoluteSize
				local v1096
				if v1092.X >= v1094.X and (v1092.Y >= v1094.Y and v1092.X < v1094.X + v1095.X) then
					v1096 = v1092.Y < v1094.Y + v1095.Y
				else
					v1096 = false
				end
				if not v1096 and os.clock() - v_u_155 > 0.03 then
					task.defer(v_u_164)
				end
			end
			if v_u_159 and not v_u_149 then
				v_u_160 = {
					["io"] = p1091,
					["pos"] = v1092
				}
				return
			end
		elseif p1091.UserInputType == Enum.UserInputType.Keyboard and p1091.KeyCode == Enum.KeyCode.Escape or p1091.KeyCode == Enum.KeyCode.ButtonB then
			local v_u_1097 = nil
			local function v1098()
				-- upvalues: (ref) v_u_1097, (ref) v_u_21
				v_u_1097 = v_u_21:GetAttribute("MenuV2")
			end
			pcall(v1098)
			local v1099
			if v_u_188.Layers.visibleOnlyForKey(v_u_1097) then
				v1099 = v_u_19.closeTopLayer({
					["visibleOnly"] = true
				})
			else
				v1099 = v_u_19.closeTopLayer()
			end
			if v1099 then
				local v1100 = v_u_11.takeBack
				pcall(v1100)
			end
			if not v1099 and (p1091.KeyCode == Enum.KeyCode.ButtonB and v_u_19.isOpen()) then
				v_u_19.close()
				local v1101 = v_u_20.emit
				pcall(v1101, "inventory.padBack")
			end
		end
	end)
	v_u_2.WindowFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_148, (ref) v_u_149, (ref) v_u_1010
		v_u_148 = nil
		if v_u_149 and not v_u_149.touch then
			v_u_1010(v_u_149.pos, true)
		end
	end)
end
v_u_188.WEAPON_KEY_ACTION = {
	["primary"] = "primary",
	["secondary"] = "secondary",
	["melee"] = "meleeSlot"
}
function v_u_188.weaponKey(p1103) -- name: weaponKey
	-- upvalues: (copy) v_u_188, (copy) v_u_11, (copy) v_u_2
	local v1104 = v_u_188.WEAPON_KEY_ACTION[p1103]
	if not v1104 then
		return ""
	end
	local v1105 = v_u_11.device
	local v1106, v1107 = pcall(v1105)
	local v1108 = (not v1106 or type(v1107) ~= "string") and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v1107
	if v1108 == "Touch" then
		return ""
	end
	local v1109 = string.upper
	local v1110 = v1108 == "Gamepad" and "swap" or v1104
	local v1111 = v_u_11.hint
	local v1112, v1113 = pcall(v1111, v1110)
	return v1109((not v1112 or type(v1113) ~= "string") and "" or v1113)
end
local function v1155(p1114, p1115, p1116, p1117, p1118) -- name: makeSlotBox
	-- upvalues: (copy) v_u_18, (copy) v_u_60, (copy) v_u_14, (copy) v_u_188, (copy) v_u_8, (copy) v_u_74, (copy) v_u_11, (copy) v_u_43, (ref) v_u_20
	local v1119 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Name"] = "Slot_" .. p1116.id,
		["BackgroundColor3"] = v_u_18.bgDeep,
		["Position"] = p1117,
		["Size"] = p1118
	}
	local v1120 = Instance.new("Frame")
	if v1119 then
		for v1121, v1122 in v1119 do
			v1120[v1121] = v1122
		end
	end
	if p1115 then
		v1120.Parent = p1115
	end
	v_u_60(v1120, v_u_18.line)
	local v1123 = {
		["Name"] = "Silhouette",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v1124 = Instance.new("Frame")
	if v1123 then
		for v1125, v1126 in v1123 do
			v1124[v1125] = v1126
		end
	end
	if v1120 then
		v1124.Parent = v1120
	end
	local v1127 = {
		["Name"] = "Area",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Position"] = UDim2.fromOffset(8, 20),
		["Size"] = UDim2.new(1, -16, 1, -26)
	}
	local v1128 = Instance.new("Frame")
	if v1127 then
		for v1129, v1130 in v1127 do
			v1128[v1129] = v1130
		end
	end
	if v1124 then
		v1128.Parent = v1124
	end
	local v1131 = v_u_14.draw
	local v1132 = p1116.glyph
	local v1133 = {
		["zindex"] = 2,
		["fill"] = 0.86,
		["slot"] = nil,
		["slot"] = p1116.id
	}
	pcall(v1131, v1132, v1128, v1133)
	local v1134 = v_u_188.weaponKey(p1116.id)
	local v1135, v1136
	if v1134 == "" then
		v1135 = nil
		v1136 = 8
	else
		local v1137 = #v1134 * 7 + 2
		local v1138 = {
			["Name"] = "Key",
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["TextSize"] = 11,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["TextXAlignment"] = nil,
			["Text"] = nil,
			["ZIndex"] = 7,
			["FontFace"] = v_u_8.font.monoBold,
			["TextColor3"] = v_u_18.muted,
			["Position"] = UDim2.fromOffset(8, 4),
			["Size"] = UDim2.fromOffset(v1137, 14),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Text"] = v1134
		}
		v1135 = Instance.new("TextLabel")
		if v1138 then
			for v1139, v1140 in v1138 do
				v1135[v1139] = v1140
			end
		end
		if v1120 then
			v1135.Parent = v1120
		end
		local v1141 = {
			["MaxTextSize"] = 11,
			["MinTextSize"] = 7
		}
		local v1142 = Instance.new("UITextSizeConstraint")
		if v1141 then
			for v1143, v1144 in v1141 do
				v1142[v1143] = v1144
			end
		end
		if v1135 then
			v1142.Parent = v1135
		end
		v1136 = v1137 + 8 + 4
	end
	local v1145 = v_u_74
	local v1146
	if p1114.compact then
		v1146 = p1116.short
	else
		v1146 = p1116.label
	end
	local v1147 = v1145(v1120, v1146, "micro", {
		["position"] = UDim2.fromOffset(v1136, 4),
		["size"] = UDim2.new(1, -v1136 - 8, 0, 14)
	})
	v1147.ZIndex = 6
	local v1148 = {
		["Name"] = "Highlight",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.72,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_18.success,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v1149 = Instance.new("Frame")
	if v1148 then
		for v1150, v1151 in v1148 do
			v1149[v1150] = v1151
		end
	end
	if v1120 then
		v1149.Parent = v1120
	end
	local v1152
	if p1116.id == "secure" and p1114.mode ~= "raid" then
		local v1154 = {
			["theme"] = v_u_8,
			["hushUI"] = v_u_11,
			["sound"] = v_u_43,
			["cap"] = v1147,
			["menu"] = function() -- name: menu
				-- upvalues: (ref) v_u_20
				local v1153 = v_u_20
				if v1153 then
					v1153 = v_u_20.controllers
				end
				return v1153 and v1153.Menu or nil
			end
		}
		v1152 = v_u_188.Plus.make(v1120, p1114.compact, v1154)
	else
		v1152 = nil
	end
	return {
		["frame"] = nil,
		["sil"] = nil,
		["cap"] = nil,
		["key"] = nil,
		["hl"] = nil,
		["def"] = nil,
		["tile"] = nil,
		["uid"] = nil,
		["plus"] = nil,
		["frame"] = v1120,
		["sil"] = v1124,
		["cap"] = v1147,
		["key"] = v1135,
		["hl"] = v1149,
		["def"] = p1116,
		["plus"] = v1152
	}
end
local function v_u_1166(p1156) -- name: quickKeyText
	-- upvalues: (copy) v_u_11, (copy) v_u_2
	local v1157 = v_u_11.device
	local v1158, v1159 = pcall(v1157)
	if ((not v1158 or type(v1159) ~= "string") and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v1159) == "Touch" then
		return tostring(p1156)
	end
	local v1160 = "quick" .. p1156
	local v1161 = v_u_11.hint
	local v1162, v1163 = pcall(v1161, v1160)
	local v1164 = (not v1162 or type(v1163) ~= "string") and "" or v1163
	if v1164 == "" then
		return tostring(p1156)
	end
	local v1165 = string.gsub(v1164, "^D%-Pad%s*", "D-")
	return string.upper(v1165)
end
local function v_u_1180(p_u_1167, p_u_1168, p1169) -- name: openQuickContext
	-- upvalues: (copy) v_u_175, (copy) v_u_9, (copy) v_u_471, (copy) v_u_198, (copy) v_u_11, (copy) v_u_19, (ref) v_u_289
	local v1170 = p_u_1167.work
	local v1171
	if type(v1170) == "table" then
		v1171 = v1170.kit or nil
	else
		v1171 = nil
	end
	local v_u_1172
	if v1171 then
		local v1173 = v1171.quick
		v_u_1172 = type(v1173) == "table" and v1173[p_u_1168] or v1171["quick" .. p_u_1168]
		if type(v_u_1172) ~= "string" or v_u_1172 == "" then
			v_u_1172 = nil
		end
	else
		v_u_1172 = nil
	end
	if v_u_1172 and v_u_175(p_u_1167.work, v_u_1172) then
		local v_u_1174 = v_u_175(p_u_1167.work, v_u_1172)
		if v_u_1174 then
			v_u_1174 = v_u_9.get(v_u_1174.item.id)
		end
		local v1175 = {}
		if p_u_1167.mode == "raid" and (v_u_1174 and (v_u_1174.category == "medical" or v_u_1174.category == "throwable")) then
			local v1176 = {
				["id"] = "use",
				["text"] = nil,
				["text"] = v_u_1174.category == "throwable" and "Throw" or "Use"
			}
			table.insert(v1175, v1176)
		end
		table.insert(v1175, {
			["id"] = "inspect",
			["text"] = "Inspect"
		})
		table.insert(v1175, {
			["id"] = "clear",
			["text"] = "Clear quick slot",
			["kind"] = "danger"
		})
		v_u_471(p_u_1167, v_u_1172, p1169, {
			["acts"] = v1175,
			["run"] = function(p1177) -- name: run
				-- upvalues: (ref) v_u_198, (copy) p_u_1167, (copy) p_u_1168, (ref) v_u_11, (copy) v_u_1174, (ref) v_u_19, (ref) v_u_289, (copy) v_u_1172
				if p1177 == "use" then
					v_u_198(p_u_1167, {
						["op"] = "usequick",
						["index"] = nil,
						["index"] = p_u_1168
					})
					local v1178 = v_u_11.sound
					pcall(v1178, "click")
					if v_u_1174 and v_u_1174.category == "throwable" then
						v_u_19.close()
						return
					end
				else
					if p1177 == "inspect" then
						v_u_289(p_u_1167, v_u_1172)
						return
					end
					if p1177 == "clear" then
						v_u_198(p_u_1167, {
							["op"] = "setquick",
							["uid"] = "",
							["index"] = nil,
							["index"] = p_u_1168
						})
						local v1179 = v_u_11.sound
						pcall(v1179, "close")
					end
				end
			end
		})
	end
end
local function v1226(p_u_1181, p1182, p_u_1183, p1184, p1185) -- name: makeQuickBox
	-- upvalues: (copy) v_u_18, (copy) v_u_11, (copy) v_u_60, (copy) v_u_8, (copy) v_u_1166, (ref) v_u_20, (ref) v_u_149, (ref) v_u_158, (copy) v_u_1180
	local v1186 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Active"] = true,
		["Selectable"] = true,
		["Name"] = "Quick" .. p_u_1183,
		["BackgroundColor3"] = v_u_18.bgDeep,
		["Position"] = p1184,
		["Size"] = p1185
	}
	local v_u_1187 = Instance.new("Frame")
	if v1186 then
		for v1188, v1189 in v1186 do
			v_u_1187[v1188] = v1189
		end
	end
	if p1182 then
		v_u_1187.Parent = p1182
	end
	local function v1190()
		-- upvalues: (copy) v_u_1187, (ref) v_u_11
		v_u_1187.SelectionImageObject = v_u_11.selectionImage()
	end
	pcall(v1190)
	v_u_60(v_u_1187, v_u_18.line)
	local v1191 = {
		["Name"] = "Key",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextScaled"] = true,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Text"] = nil,
		["ZIndex"] = 7,
		["FontFace"] = v_u_8.font.monoBold,
		["TextColor3"] = v_u_18.muted,
		["Position"] = UDim2.fromOffset(4, 3),
		["Size"] = UDim2.new(0.62, -4, 0, 11),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Text"] = v_u_1166(p_u_1183)
	}
	local v1192 = Instance.new("TextLabel")
	if v1191 then
		for v1193, v1194 in v1191 do
			v1192[v1193] = v1194
		end
	end
	if v_u_1187 then
		v1192.Parent = v_u_1187
	end
	local v1195 = {
		["MaxTextSize"] = 11,
		["MinTextSize"] = 7
	}
	local v1196 = Instance.new("UITextSizeConstraint")
	if v1195 then
		for v1197, v1198 in v1195 do
			v1196[v1197] = v1198
		end
	end
	if v1192 then
		v1196.Parent = v1192
	end
	local v1199 = {
		["Name"] = "Count",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = 10,
		["TextScaled"] = true,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["Text"] = "",
		["ZIndex"] = 7,
		["FontFace"] = v_u_8.font.monoBold,
		["TextColor3"] = v_u_18.text2,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -4, 0, 3),
		["Size"] = UDim2.new(0.38, -4, 0, 11),
		["TextXAlignment"] = Enum.TextXAlignment.Right
	}
	local v1200 = Instance.new("TextLabel")
	if v1199 then
		for v1201, v1202 in v1199 do
			v1200[v1201] = v1202
		end
	end
	if v_u_1187 then
		v1200.Parent = v_u_1187
	end
	local v1203 = {
		["MaxTextSize"] = 10,
		["MinTextSize"] = 7
	}
	local v1204 = Instance.new("UITextSizeConstraint")
	if v1203 then
		for v1205, v1206 in v1203 do
			v1204[v1205] = v1206
		end
	end
	if v1200 then
		v1204.Parent = v1200
	end
	local v1207 = {
		["Name"] = "Short",
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = 10,
		["TextScaled"] = true,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Text"] = "",
		["ZIndex"] = 7,
		["FontFace"] = v_u_8.font.bodyMedium,
		["TextColor3"] = v_u_18.text2,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 3, 1, -2),
		["Size"] = UDim2.new(1, -6, 0, 11),
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}
	local v1208 = Instance.new("TextLabel")
	if v1207 then
		for v1209, v1210 in v1207 do
			v1208[v1209] = v1210
		end
	end
	if v_u_1187 then
		v1208.Parent = v_u_1187
	end
	local v1211 = {
		["MaxTextSize"] = 10,
		["MinTextSize"] = 7
	}
	local v1212 = Instance.new("UITextSizeConstraint")
	if v1211 then
		for v1213, v1214 in v1211 do
			v1212[v1213] = v1214
		end
	end
	if v1208 then
		v1212.Parent = v1208
	end
	local v1215 = {
		["Name"] = "Highlight",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.72,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_18.success,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v1216 = Instance.new("Frame")
	if v1215 then
		for v1217, v1218 in v1215 do
			v1216[v1217] = v1218
		end
	end
	if v_u_1187 then
		v1216.Parent = v_u_1187
	end
	local v_u_1219 = nil
	local v_u_1220 = Vector2.zero
	v_u_20.lib.VirtualPad.guiInputBegan(v_u_1187):Connect(function(p1221)
		-- upvalues: (ref) v_u_149, (copy) p_u_1181, (ref) v_u_158, (ref) v_u_1180, (copy) p_u_1183, (ref) v_u_1219, (ref) v_u_1220, (copy) v_u_1187
		if v_u_149 or not p_u_1181.isShown() then
			return
		else
			local v1222 = p1221.UserInputType
			local v1223 = Vector2.new(p1221.Position.X, p1221.Position.Y)
			if v1222 == Enum.UserInputType.MouseButton1 or v1222 == Enum.UserInputType.MouseButton2 then
				v_u_158 = v1223
				v_u_1180(p_u_1181, p_u_1183, v1223)
				return
			elseif v1222 == Enum.UserInputType.Touch then
				v_u_1219 = p1221
				v_u_1220 = v1223
			elseif p1221.KeyCode == Enum.KeyCode.ButtonA or p1221.KeyCode == Enum.KeyCode.ButtonX then
				v_u_1180(p_u_1181, p_u_1183, v_u_1187.AbsolutePosition + v_u_1187.AbsoluteSize * 0.5)
			end
		end
	end)
	v_u_1187.InputEnded:Connect(function(p1224)
		-- upvalues: (ref) v_u_1219, (ref) v_u_149, (ref) v_u_1220, (copy) p_u_1181, (ref) v_u_158, (ref) v_u_1180, (copy) p_u_1183
		if p1224 == v_u_1219 then
			v_u_1219 = nil
			local v1225 = Vector2.new(p1224.Position.X, p1224.Position.Y)
			if not v_u_149 and ((v1225 - v_u_1220).Magnitude <= 14 and p_u_1181.isShown()) then
				v_u_158 = v1225
				v_u_1180(p_u_1181, p_u_1183, v1225)
			end
		end
	end)
	return {
		["frame"] = nil,
		["num"] = nil,
		["count"] = nil,
		["name"] = nil,
		["hl"] = nil,
		["icon"] = nil,
		["iconId"] = nil,
		["uid"] = nil,
		["frame"] = v_u_1187,
		["num"] = v1192,
		["count"] = v1200,
		["name"] = v1208,
		["hl"] = v1216
	}
end
local function v_u_1260(p1227, p1228, p1229, p1230, p1231) -- name: smallButton
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_60, (copy) v_u_11
	local v_u_1232 = p1229 == "primary"
	local v1233 = {
		["Name"] = nil,
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["Text"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Btn_" .. p1228
	}
	local v1234
	if v_u_1232 then
		v1234 = v_u_18.accentDeep
	else
		v1234 = v_u_18.raised
	end
	v1233.BackgroundColor3 = v1234
	v1233.AutomaticSize = Enum.AutomaticSize.X
	v1233.Size = UDim2.fromOffset(v_u_8.touch(24), v_u_8.touch(24))
	v1233.FontFace = v_u_8.font.heading
	local v1235
	if v_u_1232 then
		v1235 = v_u_18.accent
	else
		v1235 = v_u_18.text2
	end
	v1233.TextColor3 = v1235
	v1233.Text = string.upper(p1228)
	v1233.LayoutOrder = p1230
	local v_u_1236 = Instance.new("TextButton")
	if v1233 then
		for v1237, v1238 in v1233 do
			v_u_1236[v1237] = v1238
		end
	end
	if p1227 then
		v_u_1236.Parent = p1227
	end
	local v1239 = {
		["PaddingLeft"] = UDim.new(0, 10),
		["PaddingRight"] = UDim.new(0, 10)
	}
	local v1240 = Instance.new("UIPadding")
	if v1239 then
		for v1241, v1242 in v1239 do
			v1240[v1241] = v1242
		end
	end
	if v_u_1236 then
		v1240.Parent = v_u_1236
	end
	local v1243 = v_u_60
	local v1244
	if v_u_1232 then
		v1244 = v_u_18.accentDim
	else
		v1244 = v_u_18.line
	end
	v1243(v_u_1236, v1244)
	local v1245 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_18.accent,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, -10, 1, 0),
		["Size"] = UDim2.new(0, 0, 0, 1)
	}
	local v_u_1246 = Instance.new("Frame")
	if v1245 then
		for v1247, v1248 in v1245 do
			v_u_1246[v1247] = v1248
		end
	end
	if v_u_1236 then
		v_u_1246.Parent = v_u_1236
	end
	v_u_1236.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_11, (copy) v_u_1236, (copy) v_u_1232, (ref) v_u_18, (copy) v_u_1246
		local v1249 = v_u_11.sound
		pcall(v1249, "hover")
		local v1250 = v_u_1236
		local v1251
		if v_u_1232 then
			v1251 = v_u_18.text
		else
			v1251 = v_u_18.text
		end
		v1250.TextColor3 = v1251
		local v1252 = v_u_11.tween
		local v1253 = v_u_1246
		local v1254 = {
			["Size"] = UDim2.new(1, 20, 0, 1)
		}
		pcall(v1252, v1253, v1254, "slow")
	end)
	v_u_1236.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_1236, (copy) v_u_1232, (ref) v_u_18, (ref) v_u_11, (copy) v_u_1246
		local v1255 = v_u_1236
		local v1256
		if v_u_1232 then
			v1256 = v_u_18.accent
		else
			v1256 = v_u_18.text2
		end
		v1255.TextColor3 = v1256
		local v1257 = v_u_11.tween
		local v1258 = v_u_1246
		local v1259 = {
			["Size"] = UDim2.new(0, 0, 0, 1)
		}
		pcall(v1257, v1258, v1259, "fast")
	end)
	v_u_1236.Activated:Connect(p1231)
	return v_u_1236
end
local function v_u_1283(p1261, p1262, p1263, p1264) -- name: sectionHeader
	-- upvalues: (copy) v_u_8, (copy) v_u_74, (copy) v_u_18
	local v1265 = v_u_8.touch(24) + 8
	local v1266 = math.max(30, v1265)
	local v1267 = {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.fromOffset(p1264, v1266),
		["LayoutOrder"] = p1263
	}
	local v1268 = Instance.new("Frame")
	if v1267 then
		for v1269, v1270 in v1267 do
			v1268[v1269] = v1270
		end
	end
	if p1261 then
		v1268.Parent = p1261
	end
	local v1271 = v_u_74
	local v1272 = {}
	local v1273 = UDim2.fromOffset
	local v1274 = (v1266 - 18) / 2
	v1272.position = v1273(0, (math.floor(v1274)))
	v1272.size = UDim2.new(1, -150, 0, 18)
	v1272.color = v_u_18.text
	local v1275 = v1271(v1268, p1262, "caps", v1272)
	local v1276 = v_u_74(v1268, "", "monoS", {
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, 0, 0, 7),
		["size"] = UDim2.fromOffset(150, 16),
		["color"] = v_u_18.muted
	})
	v1276.AnchorPoint = Vector2.new(1, 0)
	local v1277 = UDim2.new
	local v1278 = (v1266 - 16) / 2
	v1276.Position = v1277(1, 0, 0, (math.floor(v1278)))
	v1276.TextXAlignment = Enum.TextXAlignment.Right
	local v1279 = {
		["Name"] = "Line",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_18.line,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v1280 = Instance.new("Frame")
	if v1279 then
		for v1281, v1282 in v1279 do
			v1280[v1281] = v1282
		end
	end
	if v1268 then
		v1280.Parent = v1268
	end
	return {
		["frame"] = v1268,
		["title"] = v1275,
		["sub"] = v1276
	}
end
local function v_u_1303(p1284, p1285, p1286, p1287, p1288) -- name: gridFrame
	-- upvalues: (copy) v_u_18, (copy) v_u_60, (copy) v_u_188, (copy) v_u_40, (copy) v_u_8
	local v1289 = p1284.cell
	local v1290 = {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = "Grid_" .. p1286,
		["Size"] = UDim2.fromOffset(p1287.w * v1289, p1287.h * v1289),
		["LayoutOrder"] = p1288
	}
	local v1291 = Instance.new("Frame")
	if v1290 then
		for v1292, v1293 in v1290 do
			v1291[v1292] = v1293
		end
	end
	if p1285 then
		v1291.Parent = p1285
	end
	local v1294 = {
		["Name"] = "Cells",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = false,
		["BackgroundColor3"] = v_u_18.bgDeep,
		["Size"] = UDim2.fromOffset(p1287.w * v1289, p1287.h * v1289)
	}
	local v1295 = Instance.new("Frame")
	if v1294 then
		for v1296, v1297 in v1294 do
			v1295[v1296] = v1297
		end
	end
	if v1291 then
		v1295.Parent = v1291
	end
	v_u_60(v1295, v_u_18.line)
	local v1298 = {
		["new"] = v_u_40,
		["stroke"] = v_u_60,
		["theme"] = v_u_8
	}
	v_u_188.Pouch.draw(v1295, p1287, v1289, 1, v1298)
	local v1299 = {
		["Name"] = "Highlight",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.78,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 9,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_18.success
	}
	local v1300 = Instance.new("Frame")
	if v1299 then
		for v1301, v1302 in v1299 do
			v1300[v1301] = v1302
		end
	end
	if v1295 then
		v1300.Parent = v1295
	end
	return {
		["holder"] = v1291,
		["cells"] = v1295,
		["hl"] = v1300,
		["hlStroke"] = v_u_60(v1300, v_u_18.success, 0.1),
		["w"] = p1287.w,
		["h"] = p1287.h,
		["id"] = p1286
	}
end
local v_u_1304 = {
	["gear"] = true,
	["stash"] = true,
	["both"] = true
}
local v_u_1305 = { "gear", "stash", "both" }
local v_u_1306 = "both"
local function v1309(p1307) -- name: sectionOf
	-- upvalues: (ref) v_u_1306
	local v1308 = p1307.section
	if not v1308 then
		if p1307.mode == "raid" then
			return "both"
		end
		v1308 = v_u_1306
	end
	return v1308
end
local function v_u_1316(p1310) -- name: applySection
	-- upvalues: (ref) v_u_1306
	local v1311 = not p1310.narrow and "both" or (p1310.section or (p1310.mode == "raid" and "both" or v_u_1306))
	for _, v1312 in p1310.sections do
		local v1313 = v1312.frame
		if not (v1313 and v1313.Parent) then
			continue
		end
		local v1314 = v1311 == "both" and true or (v1312.kind or "gear") == v1311
		if v1313.Visible == v1314 then
			continue
		end
		v1313.Visible = v1314
	end
	if p1310.emptyNote and p1310.emptyNote.Parent then
		p1310.emptyNote.Visible = v1311 ~= "gear"
	end
	if p1310.secTabs then
		local v1315 = p1310.secTabs.select
		pcall(v1315, v1311, true)
	end
	p1310.cullDirty = true
end
local function v_u_1320(p1317, p1318) -- name: setMountSection
	-- upvalues: (copy) v_u_1304, (ref) v_u_1306, (copy) v_u_1316, (copy) v_u_21
	if v_u_1304[p1318] and not p1317.dead then
		local v1319 = (p1317.section or (p1317.mode == "raid" and "both" or v_u_1306)) ~= p1318
		p1317.section = p1318
		if p1317.mode ~= "raid" then
			v_u_1306 = p1318
		end
		v_u_1316(p1317)
		if v1319 and (p1317.narrow and (p1317.gearScroll and p1317.gearScroll.Parent)) then
			p1317.gearScroll.CanvasPosition = Vector2.zero
		end
		if v_u_21 then
			v_u_21:SetAttribute("InvUISection", p1318)
		end
	end
end
local function v1336(p_u_1321, p1322, p1323, p1324, p1325, p1326) -- name: buildSectionTabs
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (ref) v_u_1306, (copy) v_u_1320
	local v1327 = p1326 and 12 or 16
	local v1328 = v_u_8.touch(28)
	local v1329 = v_u_11.tabs
	local v1331 = {
		["parent"] = nil,
		["name"] = "SectionTabs",
		["tabs"] = nil,
		["selected"] = nil,
		["size"] = nil,
		["position"] = nil,
		["onChange"] = nil,
		["parent"] = p1322,
		["tabs"] = {
			{
				["id"] = "gear",
				["text"] = "Gear"
			},
			{
				["id"] = "stash",
				["text"] = nil,
				["text"] = p_u_1321.mode == "raid" and "Loot" or "Stash"
			},
			{
				["id"] = "both",
				["text"] = "All"
			}
		},
		["selected"] = not p_u_1321.narrow and "both" or (p_u_1321.section or (p_u_1321.mode == "raid" and "both" or v_u_1306)),
		["size"] = UDim2.new(1, v1327 * -2, 0, v1328),
		["position"] = UDim2.fromOffset(v1327, 4),
		["onChange"] = function(p1330) -- name: onChange
			-- upvalues: (ref) v_u_1320, (copy) p_u_1321
			v_u_1320(p_u_1321, p1330)
		end
	}
	local v1332, v1333, v1334 = pcall(v1329, v1331)
	if v1332 and (v1333 and type(v1334) == "table") then
		p1324.Visible = false
		p1325.Visible = false
		local v1335 = 4 + v1328 + 8
		p1323.Position = UDim2.fromOffset(v1327, v1335)
		p1323.Size = UDim2.new(1, -v1327 - 8, 1, -v1335 - 8)
		p_u_1321.secTabs = v1334
		p_u_1321.secTabFrame = v1333
	end
end
local function v_u_1346(p1337) -- name: rightKeyOf
	if p1337.mode ~= "raid" then
		return "stash"
	end
	local v1338 = p1337.work
	local v1339 = 0
	local v1340 = 0
	if type(v1338) == "table" then
		local v1341 = v1338.open
		if type(v1341) == "table" then
			for _, v1342 in v1338.open do
				local v1343 = v1338.containers
				if v1343 then
					v1343 = v1338.containers[v1342]
				end
				if type(v1343) ~= "table" then
					continue
				end
				v1339 = v1339 + 1
				local v1344 = v1343.w
				local v1345 = tonumber(v1344) or 0
				v1340 = math.max(v1340, v1345)
			end
		end
	end
	return v1339 == 0 and "" or "w" .. v1340
end
local function v_u_1356(p1347) -- name: gearNeedOf
	-- upvalues: (copy) v_u_29, (copy) v_u_30
	local v1348 = p1347.work
	local v1349 = 4
	if type(v1348) == "table" then
		local v1350 = v1348.containers
		if type(v1350) == "table" then
			local v1351
			if p1347.mode == "raid" then
				v1351 = v_u_29
			else
				v1351 = v_u_30
			end
			for _, v1352 in v1351 do
				local v1353 = v1348.containers[v1352]
				if type(v1353) ~= "table" then
					continue
				end
				local v1354 = v1353.w
				local v1355 = tonumber(v1354) or 0
				v1349 = math.max(v1349, v1355)
			end
		end
	end
	return math.min(v1349, 6)
end
v_u_180 = function(p1357, p1358)
	-- upvalues: (copy) v_u_11, (copy) v_u_21
	local v1359 = p1357.rail
	if v1359 and v1359.expanded ~= p1358 then
		v1359.expanded = p1358
		if v1359.panel.Parent then
			v1359.panel.Visible = p1358
		end
		if v1359.tab.Parent then
			v1359.tab.Visible = p1358
		end
		p1357.cullDirty = true
		local v1360 = v_u_11.sound
		pcall(v1360, p1358 and "open" or "close")
		if v_u_21 then
			v_u_21:SetAttribute("InvUIEquipOpen", p1358)
		end
	end
end
local function v1401(p_u_1361, p1362, p1363, p1364, p1365, p1366) -- name: buildRail
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_60, (copy) v_u_11, (copy) v_u_33, (copy) v_u_74, (ref) v_u_180, (copy) v_u_21
	local v1367 = {
		["Name"] = "EquipRail",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Text"] = "",
		["BackgroundColor3"] = v_u_18.bg,
		["BackgroundTransparency"] = v_u_8.alpha.panel,
		["Size"] = UDim2.fromOffset(p1364, p1365)
	}
	local v1368 = Instance.new("TextButton")
	if v1367 then
		for v1369, v1370 in v1367 do
			v1368[v1369] = v1370
		end
	end
	if p1362 then
		v1368.Parent = p1362
	end
	v_u_60(v1368, v_u_18.line)
	local v1371 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Color"] = ColorSequence.new(v_u_18.raised, v_u_18.bg)
	}
	local v1372 = Instance.new("UIGradient")
	if v1371 then
		for v1373, v1374 in v1371 do
			v1372[v1373] = v1374
		end
	end
	if v1368 then
		v1372.Parent = v1368
	end
	local v1375 = {
		["Name"] = "Accent",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_18.accent,
		["Size"] = UDim2.new(1, 0, 0, 2)
	}
	local v1376 = Instance.new("Frame")
	if v1375 then
		for v1377, v1378 in v1375 do
			v1376[v1377] = v1378
		end
	end
	if v1368 then
		v1376.Parent = v1368
	end
	local v1379 = v_u_11.icon
	local v1380 = {
		["parent"] = nil,
		["size"] = 16,
		["position"] = nil,
		["anchor"] = nil,
		["color"] = nil,
		["zindex"] = 2,
		["parent"] = v1368,
		["position"] = UDim2.new(0.5, 0, 0, 14),
		["anchor"] = Vector2.new(0.5, 0),
		["color"] = v_u_18.accent
	}
	pcall(v1379, "chevronRight", v1380)
	local v1381 = {
		["Name"] = "Caption",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = -90,
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["Text"] = "EQUIPMENT",
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 2,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 88),
		["Size"] = UDim2.fromOffset(96, 18),
		["FontFace"] = v_u_8.font.heading,
		["TextColor3"] = v_u_18.text,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	}
	local v1382 = Instance.new("TextLabel")
	if v1381 then
		for v1383, v1384 in v1381 do
			v1382[v1383] = v1384
		end
	end
	if v1368 then
		v1382.Parent = v1368
	end
	local v1385 = {}
	local v1386 = 148
	if p1365 - v1386 >= #v_u_33 * 14 + 34 then
		for _, v1387 in v_u_33 do
			local v1388 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Name"] = "Dot_" .. v1387.id,
				["BackgroundColor3"] = v_u_18.bgDeep,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, v1386),
				["Size"] = UDim2.fromOffset(10, 10)
			}
			local v1389 = Instance.new("Frame")
			if v1388 then
				for v1390, v1391 in v1388 do
					v1389[v1390] = v1391
				end
			end
			if v1368 then
				v1389.Parent = v1368
			end
			v_u_60(v1389, v_u_18.line)
			v1385[v1387.id] = v1389
			v1386 = v1386 + 14
		end
	end
	local v1392 = v_u_74(v1368, "", "monoS", {
		["anchor"] = Vector2.new(0, 1),
		["position"] = UDim2.new(0, 2, 1, -22),
		["size"] = UDim2.new(1, -4, 0, 16),
		["color"] = v_u_18.text2
	})
	v1392.AnchorPoint = Vector2.new(0, 1)
	v1392.Position = UDim2.new(0, 2, 1, -22)
	v1392.TextXAlignment = Enum.TextXAlignment.Center
	v1392.ZIndex = 2
	local v1393 = v_u_74(v1368, "kg", "micro", {
		["position"] = UDim2.new(0, 2, 1, -20),
		["size"] = UDim2.new(1, -4, 0, 14)
	})
	v1393.TextXAlignment = Enum.TextXAlignment.Center
	v1393.ZIndex = 2
	p1363.Visible = false
	p1363.ZIndex = 10
	p1363.Active = true
	p1363.BackgroundTransparency = 0
	local v1394 = v_u_8.touch(36)
	local v1395 = {
		["Name"] = "EquipCollapse",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["ZIndex"] = 11,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_18.raised,
		["Position"] = UDim2.fromOffset(p1366, 0),
		["Size"] = UDim2.fromOffset(v1394, v1394)
	}
	local v1396 = Instance.new("TextButton")
	if v1395 then
		for v1397, v1398 in v1395 do
			v1396[v1397] = v1398
		end
	end
	if p1362 then
		v1396.Parent = p1362
	end
	v_u_60(v1396, v_u_18.lineStrong)
	local v1399 = v_u_11.icon
	local v1400 = {
		["parent"] = nil,
		["size"] = 16,
		["position"] = nil,
		["anchor"] = nil,
		["color"] = nil,
		["zindex"] = 12,
		["parent"] = v1396,
		["position"] = UDim2.fromScale(0.5, 0.5),
		["anchor"] = Vector2.new(0.5, 0.5),
		["color"] = v_u_18.accent
	}
	pcall(v1399, "chevronLeft", v1400)
	p_u_1361.rail = {
		["btn"] = nil,
		["panel"] = nil,
		["tab"] = nil,
		["dots"] = nil,
		["weight"] = nil,
		["expanded"] = false,
		["btn"] = v1368,
		["panel"] = p1363,
		["tab"] = v1396,
		["dots"] = v1385,
		["weight"] = v1392
	}
	v1368.Activated:Connect(function()
		-- upvalues: (ref) v_u_180, (copy) p_u_1361
		v_u_180(p_u_1361, true)
	end)
	v1396.Activated:Connect(function()
		-- upvalues: (ref) v_u_180, (copy) p_u_1361
		v_u_180(p_u_1361, false)
	end)
	if v_u_21 then
		v_u_21:SetAttribute("InvUIEquipOpen", false)
	end
end
v_u_179 = function(p1402)
	-- upvalues: (copy) v_u_188
	v_u_188.Layout.build(p1402)
end
local function v_u_1423(p_u_1403, p1404, p1405, p1406) -- name: tileFor
	-- upvalues: (copy) v_u_13, (copy) v_u_11, (ref) v_u_20, (copy) v_u_1040, (ref) v_u_149, (copy) v_u_18, (ref) v_u_154, (copy) v_u_188, (copy) v_u_9
	local v1407 = p_u_1403.tiles[p1404.uid]
	if v1407 and (v1407.inst.id ~= p1404.id or v1407.alive and not v1407.alive()) then
		v1407.destroy()
		p_u_1403.tiles[p1404.uid] = nil
		v1407 = nil
	end
	if v1407 then
		v1407.set(p1404, p_u_1403.cell)
	else
		v1407 = v_u_13.create(p1404, p_u_1403.cell, {
			["zindex"] = 3,
			["lazy"] = true,
			["skin"] = nil,
			["skin"] = p_u_1403.knownWorld[p1404.uid] == nil
		})
		p_u_1403.tiles[p1404.uid] = v1407
		p_u_1403.cullDirty = true
		local v_u_1408 = p1404.uid
		local v_u_1409 = v1407.frame
		v_u_1409.Selectable = true
		v_u_1409:SetAttribute("PadDefault", true)
		local function v1410()
			-- upvalues: (copy) v_u_1409, (ref) v_u_11
			v_u_1409.SelectionImageObject = v_u_11.selectionImage()
		end
		pcall(v1410)
		v_u_20.lib.VirtualPad.guiInputBegan(v_u_1409):Connect(function(p1411)
			-- upvalues: (ref) v_u_1040, (copy) p_u_1403, (copy) v_u_1408, (copy) v_u_1409
			v_u_1040(p_u_1403, v_u_1408, p_u_1403.tiles[v_u_1408], v_u_1409, p1411)
		end)
		v_u_1409.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_149, (copy) v_u_1409, (ref) v_u_18
			if not v_u_149 then
				v_u_1409.BackgroundColor3 = v_u_18.raised2
			end
		end)
		v_u_1409.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_1409, (ref) v_u_18
			v_u_1409.BackgroundColor3 = v_u_18.raised
		end)
		local v1412 = v_u_11.tooltip
		local function v1422()
			-- upvalues: (ref) v_u_149, (ref) v_u_154, (copy) p_u_1403, (copy) v_u_1408, (ref) v_u_188, (ref) v_u_13, (ref) v_u_9
			if v_u_149 or v_u_154 then
				return nil
			end
			local v1413 = p_u_1403.tiles[v_u_1408]
			if not v1413 then
				return nil
			end
			local v1414 = v_u_188.Insure.tip
			local v1415 = v_u_13.tooltip
			local v1416 = v1413.inst
			local v1417 = p_u_1403.work
			local v1418 = v1413.inst
			local v1419 = v_u_9.get(v1418.id)
			if v1419 then
				v1419 = v_u_9.equipSlot(v1419)
			end
			local v1420
			if v1419 then
				local v1421
				if type(v1417) == "table" then
					v1421 = v1417.kit or nil
				else
					v1421 = nil
				end
				if v1421 then
					v1420 = v1421.slots
					if v1420 then
						v1420 = v1421.slots[v1419]
					end
					if v1420 == nil then
						v1420 = v1421[v1419]
					end
					if type(v1420) ~= "table" then
						v1420 = nil
					end
				else
					v1420 = nil
				end
				if not v1420 or v1420.uid == v1418.uid then
					v1420 = nil
				end
			else
				v1420 = nil
			end
			return v1414(v1415(v1416, v1420), v1413.inst, p_u_1403)
		end
		pcall(v1412, v_u_1409, v1422)
		if p1406 then
			task.defer(v1407.flash)
		end
	end
	v1407.frame.Parent = p1405
	return v1407
end
local function v_u_1501(p_u_1424, p1425, p_u_1426, p1427, p1428, p1429) -- name: containerSection
	-- upvalues: (copy) v_u_1283, (copy) v_u_31, (copy) v_u_1303, (copy) v_u_74, (copy) v_u_18, (copy) v_u_8, (copy) v_u_1260, (copy) v_u_11, (copy) v_u_198, (copy) v_u_188
	local v1430 = p_u_1426 .. ":" .. p1427.w .. "x" .. p1427.h
	local v1431 = p_u_1424.sections[p_u_1426]
	if v1431 and v1431.key ~= v1430 then
		for v1432, v1433 in p_u_1424.tiles do
			if v1433.frame.Parent ~= v1431.grid.cells then
				continue
			end
			v1433.destroy()
			p_u_1424.tiles[v1432] = nil
		end
		v1431.frame:Destroy()
		p_u_1424.sections[p_u_1426] = nil
		p_u_1424.grids[p_u_1426] = nil
		v1431 = nil
	end
	if not v1431 then
		local v1434 = p1427.w * p_u_1424.cell
		local v1435 = math.max(p1429, v1434)
		if p1427.world then
			local v1436 = p1427.w * p_u_1424.cell
			local v1437 = p_u_1424.touch and 400 or 380
			local v1438 = math.max(v1436, v1437)
			v1435 = math.min(v1435, v1438)
		end
		local v1439 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Name"] = "Section_" .. p_u_1426,
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Size"] = UDim2.fromOffset(v1435, 0),
			["LayoutOrder"] = p1428
		}
		local v1440 = Instance.new("Frame")
		if v1439 then
			for v1441, v1442 in v1439 do
				v1440[v1441] = v1442
			end
		end
		if p1425 then
			v1440.Parent = p1425
		end
		local v1443 = {
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 6)
		}
		local v1444 = Instance.new("UIListLayout")
		if v1443 then
			for v1445, v1446 in v1443 do
				v1444[v1445] = v1446
			end
		end
		if v1440 then
			v1444.Parent = v1440
		end
		local v1447 = p1427.sub and 12 or 0
		if v1447 > 0 then
			local v1448 = {
				["PaddingLeft"] = UDim.new(0, v1447)
			}
			local v1449 = Instance.new("UIPadding")
			if v1448 then
				for v1450, v1451 in v1448 do
					v1449[v1450] = v1451
				end
			end
			if v1440 then
				v1449.Parent = v1440
			end
		end
		local v1452 = v_u_1283
		local v1453 = v_u_31[p_u_1426] or (p1427.label or p_u_1426)
		local v1454 = 1
		local v1455
		if p_u_1424.split then
			v1455 = math.min(v1435, p1429)
		else
			v1455 = v1435
		end
		local v1456 = v1452(v1440, v1453, v1454, v1455 - v1447)
		local v1457 = v_u_1303(p_u_1424, v1440, p_u_1426, p1427, 3)
		local v1458 = {
			["frame"] = v1440,
			["header"] = v1456,
			["grid"] = v1457,
			["key"] = v1430,
			["buttons"] = {}
		}
		if p1427.sub then
			local v1459 = v_u_74
			local v1460 = ""
			local v1461 = "micro"
			local v1462 = {}
			local v1463 = UDim2.fromOffset
			if p_u_1424.split then
				v1435 = math.min(v1435, p1429)
			end
			v1462.size = v1463(v1435 - v1447, 14)
			v1462.color = v_u_18.muted
			local v1464 = v1459(v1440, v1460, v1461, v1462)
			v1464.Name = "Where"
			v1464.LayoutOrder = 2
			v1464.TextTruncate = Enum.TextTruncate.AtEnd
			v1458.where = v1464
			local v1465 = v_u_8.touch(24) + 8
			local v1466 = math.max(30, v1465) + 6 + 14 + 6 + p1427.h * p_u_1424.cell
			local v1467 = {
				["Name"] = "SubAccent",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_18.accent,
				["Position"] = UDim2.fromOffset(-v1447 + 2, 4),
				["Size"] = UDim2.fromOffset(2, v1466 - 4)
			}
			local v1468 = v1456.frame
			local v1469 = Instance.new("Frame")
			if v1467 then
				for v1470, v1471 in v1467 do
					v1469[v1470] = v1471
				end
			end
			if v1468 then
				v1469.Parent = v1468
			end
		end
		local v1472 = v_u_8.touch(24)
		local v1473 = {
			["Name"] = "Tools",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, 0, 0.5, -1),
			["Size"] = UDim2.new(0.66, 0, 0, v1472)
		}
		local v1474 = v1456.frame
		local v1475 = Instance.new("Frame")
		if v1473 then
			for v1476, v1477 in v1473 do
				v1475[v1476] = v1477
			end
		end
		if v1474 then
			v1475.Parent = v1474
		end
		local v1478 = {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
			["VerticalAlignment"] = Enum.VerticalAlignment.Center,
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}
		local v1479 = Instance.new("UIListLayout")
		if v1478 then
			for v1480, v1481 in v1478 do
				v1479[v1480] = v1481
			end
		end
		if v1475 then
			v1479.Parent = v1475
		end
		v1456.title.Size = UDim2.new(0.34, -6, 0, 18)
		v1456.sub.Parent = v1475
		v1456.sub.AnchorPoint = Vector2.zero
		v1456.sub.Position = UDim2.new()
		v1456.sub.AutomaticSize = Enum.AutomaticSize.X
		v1456.sub.Size = UDim2.fromOffset(0, 16)
		v1456.sub.TextTruncate = Enum.TextTruncate.None
		v1456.sub.LayoutOrder = 1
		if p1427.ground then
			v1456.sub.LayoutOrder = 1
		elseif p1427.world then
			local v1482 = v_u_11.ring
			local v1483 = {
				["parent"] = nil,
				["size"] = nil,
				["value"] = 0,
				["color"] = nil,
				["thickness"] = 2,
				["parent"] = v1475,
				["size"] = UDim2.fromOffset(16, 16),
				["color"] = v_u_18.accent
			}
			local v1484, v1485 = pcall(v1482, v1483)
			if v1484 and v1485 then
				v1485.frame.LayoutOrder = 2
				v1458.ring = v1485
			end
			local function v1487()
				-- upvalues: (ref) v_u_198, (copy) p_u_1424, (copy) p_u_1426, (ref) v_u_11
				v_u_198(p_u_1424, {
					["op"] = "quickloot",
					["container"] = nil,
					["container"] = p_u_1426
				})
				local v1486 = v_u_11.sound
				pcall(v1486, "confirm")
			end
			local v1488 = v1458.buttons
			local v1489 = v_u_1260(v1475, "Take best", "primary", 3, v1487)
			table.insert(v1488, v1489)
			local function v1491()
				-- upvalues: (ref) v_u_198, (copy) p_u_1424, (copy) p_u_1426, (ref) v_u_11
				v_u_198(p_u_1424, {
					["op"] = "close",
					["container"] = nil,
					["container"] = p_u_1426
				})
				local v1490 = v_u_11.sound
				pcall(v1490, "close")
			end
			local v1492 = v1458.buttons
			local v1493 = v_u_1260(v1475, "Close", "ghost", 4, v1491)
			table.insert(v1492, v1493)
		else
			local function v1495()
				-- upvalues: (ref) v_u_198, (copy) p_u_1424, (copy) p_u_1426, (ref) v_u_11
				v_u_198(p_u_1424, {
					["op"] = "sort",
					["container"] = nil,
					["container"] = p_u_1426
				})
				local v1494 = v_u_11.sound
				pcall(v1494, "click")
			end
			local v1496 = v1458.buttons
			local v1497 = v_u_1260(v1475, "Sort", "ghost", 3, v1495)
			table.insert(v1496, v1497)
			if p_u_1426 == "stash" then
				for _, v1499 in v_u_188.Move.stashTools(v1475, v_u_1260, function(p1498)
					-- upvalues: (ref) v_u_198, (copy) p_u_1424
					v_u_198(p_u_1424, p1498)
				end, v_u_18) do
					local v1500 = v1458.buttons
					table.insert(v1500, v1499)
				end
			end
		end
		p_u_1424.sections[p_u_1426] = v1458
		p_u_1424.grids[p_u_1426] = v1457
		v1457.clip = p1425
		v1431 = v1458
	end
	v1431.frame.LayoutOrder = p1428
	return v1431
end
local function v_u_1516(p1502) -- name: cullMount
	if p1502.scrollers then
		local v1503
		if p1502.dead or p1502.gone then
			v1503 = false
		else
			local v1504 = p1502.root
			if v1504 and v1504.Parent ~= nil then
				v1503 = (not p1502.layer or p1502.layer.gui.Parent ~= nil) and true or false
			else
				v1503 = false
			end
		end
		if v1503 and p1502.isShown() then
			p1502.cullDirty = false
			for _, v1505 in p1502.tiles do
				local v1506 = v1505.frame
				if not v1506 or (not v1506.Parent or v1505.alive and not v1505.alive()) then
					continue
				end
				local v1507 = v1505._sc
				if not (v1507 and (v1507.Parent and v1506:IsDescendantOf(v1507))) then
					v1507 = nil
					for _, v1508 in p1502.scrollers do
						if not (v1508 and (v1508.Parent and v1506:IsDescendantOf(v1508))) then
							continue
						end
						v1507 = v1508
					end
					v1505._sc = v1507
				end
				local v1509 = v1506.Parent.Parent
				if v1509 then
					v1509 = v1509.Parent
				end
				local v1510 = v1509 and v1509:IsA("GuiObject")
				if v1510 then
					v1510 = not v1509.Visible
				end
				local v1511 = not v1510
				if v1511 and v1507 then
					local v1512 = v1507.AbsolutePosition
					local v1513 = v1507.AbsoluteSize
					if v1513.X >= 2 and v1513.Y >= 2 then
						local v1514 = v1506.AbsolutePosition
						local v1515 = v1506.AbsoluteSize
						if v1514.Y + v1515.Y >= v1512.Y - 48 and (v1514.Y <= v1512.Y + v1513.Y + 48 and v1514.X + v1515.X >= v1512.X - 48) then
							v1511 = v1514.X <= v1512.X + v1513.X + 48
						else
							v1511 = false
						end
					end
				end
				if v1505.hasIcon() == v1511 then
					continue
				end
				v1505.showIcon(v1511)
			end
			return
		end
	end
end
v_u_188.Search.bind({
	["new"] = v_u_40,
	["send"] = v_u_198,
	["sound"] = v_u_43,
	["Pouch"] = v_u_188.Pouch,
	["selection"] = function() -- name: selection
		-- upvalues: (copy) v_u_11
		return v_u_11.selectionImage()
	end
})
v_u_188.Case.env = {
	["new"] = v_u_40,
	["label"] = v_u_74,
	["setLabel"] = function(p1517, p1518) -- name: setLabel
		-- upvalues: (copy) v_u_11
		local v1519 = v_u_11.setText
		if not pcall(v1519, p1517, p1518) then
			p1517.Text = p1518
		end
	end,
	["sound"] = v_u_43,
	["toast"] = v_u_47,
	["send"] = v_u_198,
	["smallButton"] = v_u_1260,
	["containerSection"] = v_u_1501,
	["net"] = function() -- name: net
		-- upvalues: (ref) v_u_20
		local v1520 = v_u_20
		if v1520 then
			v1520 = v_u_20.net
		end
		return v1520
	end,
	["tileFor"] = v_u_1423,
	["locate"] = v_u_175,
	["predictMove"] = v_u_212,
	["Pouch"] = v_u_188.Pouch,
	["renderMount"] = function(p1521) -- name: renderMount
		-- upvalues: (ref) v_u_178
		v_u_178(p1521)
	end
}
v_u_178 = function(p_u_1522)
	-- upvalues: (copy) v_u_13, (copy) v_u_188, (copy) v_u_11, (ref) v_u_20, (copy) v_u_1040, (ref) v_u_149, (ref) v_u_154, (copy) v_u_18, (copy) v_u_12, (copy) v_u_9, (copy) v_u_8, (copy) v_u_29, (copy) v_u_30, (copy) v_u_1501, (copy) v_u_10, (copy) v_u_32, (copy) v_u_31, (copy) v_u_1423, (copy) v_u_60, (copy) v_u_14, (copy) v_u_74, (copy) v_u_175, (copy) v_u_1010, (copy) v_u_6, (copy) v_u_28, (copy) v_u_1316, (ref) v_u_159, (copy) v_u_1516
	if p_u_1522.body then
		local v1523
		if p_u_1522.dead or p_u_1522.gone then
			v1523 = false
		else
			local v1524 = p_u_1522.root
			if v1524 and v1524.Parent ~= nil then
				v1523 = (not p_u_1522.layer or p_u_1522.layer.gui.Parent ~= nil) and true or false
			else
				v1523 = false
			end
		end
		if v1523 then
			local v1525 = p_u_1522.work
			local v1526 = type(v1525) ~= "table" and {
				["kit"] = {
					["slots"] = {},
					["quick"] = {}
				},
				["containers"] = {},
				["open"] = {}
			} or v1525
			local v1527 = {}
			local v1528
			if type(v1526) == "table" then
				v1528 = v1526.kit or nil
			else
				v1528 = nil
			end
			local v1529
			if v1528 then
				local v1530 = v1528.quick
				v1529 = type(v1530) == "table" and v1530[1] or v1528["quick" .. 1]
				if type(v1529) ~= "string" or v1529 == "" then
					v1529 = nil
				end
			else
				v1529 = nil
			end
			if v1529 then
				v1527[v1529] = 1
			end
			local v1531
			if type(v1526) == "table" then
				v1531 = v1526.kit or nil
			else
				v1531 = nil
			end
			local v1532
			if v1531 then
				local v1533 = v1531.quick
				v1532 = type(v1533) == "table" and v1533[2] or v1531["quick" .. 2]
				if type(v1532) ~= "string" or v1532 == "" then
					v1532 = nil
				end
			else
				v1532 = nil
			end
			if v1532 then
				v1527[v1532] = 2
			end
			local v1534
			if type(v1526) == "table" then
				v1534 = v1526.kit or nil
			else
				v1534 = nil
			end
			local v1535
			if v1534 then
				local v1536 = v1534.quick
				v1535 = type(v1536) == "table" and v1536[3] or v1534["quick" .. 3]
				if type(v1535) ~= "string" or v1535 == "" then
					v1535 = nil
				end
			else
				v1535 = nil
			end
			if v1535 then
				v1527[v1535] = 3
			end
			local v1537
			if type(v1526) == "table" then
				v1537 = v1526.kit or nil
			else
				v1537 = nil
			end
			local v1538
			if v1537 then
				local v1539 = v1537.quick
				v1538 = type(v1539) == "table" and v1539[4] or v1537["quick" .. 4]
				if type(v1538) ~= "string" or v1538 == "" then
					v1538 = nil
				end
			else
				v1538 = nil
			end
			if v1538 then
				v1527[v1538] = 4
			end
			local v1540 = {}
			for v_u_1541, v_u_1542 in p_u_1522.slots do
				local v1543
				if type(v1526) == "table" then
					v1543 = v1526.kit or nil
				else
					v1543 = nil
				end
				local v1544
				if v1543 then
					v1544 = v1543.slots
					if v1544 then
						v1544 = v1543.slots[v_u_1541]
					end
					if v1544 == nil then
						v1544 = v1543[v_u_1541]
					end
					if type(v1544) ~= "table" then
						v1544 = nil
					end
				else
					v1544 = nil
				end
				if v1544 then
					if v_u_1542.tile and (v_u_1542.tile.inst.uid ~= v1544.uid or v_u_1542.tile.alive and not v_u_1542.tile.alive()) then
						v_u_1542.tile.destroy()
						v_u_1542.tile = nil
					end
					local v1545 = table.clone(v1544)
					v1545.r = false
					v1545._slot = v_u_1541
					if v_u_1542.tile then
						v_u_1542.tile.set(v1545, p_u_1522.cell)
					else
						local v1546 = v_u_13.create(v1545, p_u_1522.cell, {
							["zindex"] = 4,
							["skin"] = true
						})
						local v_u_1547 = v1544.uid
						local v_u_1548 = v1546.frame
						v_u_188.Pad.selectable(v_u_1548, v_u_11)
						v_u_20.lib.VirtualPad.guiInputBegan(v_u_1548):Connect(function(p1549)
							-- upvalues: (ref) v_u_1040, (copy) p_u_1522, (copy) v_u_1547, (copy) v_u_1542, (copy) v_u_1548
							v_u_1040(p_u_1522, v_u_1547, v_u_1542.tile, v_u_1548, p1549)
						end)
						local v1550 = v_u_11.tooltip
						local function v1555()
							-- upvalues: (ref) v_u_149, (ref) v_u_154, (copy) v_u_1542, (ref) v_u_188, (ref) v_u_13, (copy) p_u_1522, (copy) v_u_1541
							if v_u_149 or (v_u_154 or not v_u_1542.tile) then
								return nil
							end
							local v1551 = v_u_188.Insure.tip(v_u_13.tooltip(v_u_1542.tile.inst, nil), v_u_1542.tile.inst, p_u_1522)
							if v_u_1541 == "secure" and type(v1551) == "table" then
								local v1552 = v1551.lines
								if type(v1552) == "table" then
									local v1553 = v1551.lines
									local v1554 = { "Rule", v_u_188.Why.SAFE_SLOT_TIP }
									table.insert(v1553, v1554)
								end
							end
							return v1551
						end
						pcall(v1550, v_u_1548, v1555)
						v_u_1542.tile = v1546
					end
					local v1556 = v_u_1542.tile.frame
					v_u_13.slotFit(v_u_1542.tile, p_u_1522.compact)
					v1556.Parent = v_u_1542.frame
					v_u_1542.sil.Visible = false
					if v_u_1542.key then
						v_u_1542.key.TextColor3 = v_u_18.accent
					end
				else
					if v_u_1542.tile then
						v_u_1542.tile.destroy()
						v_u_1542.tile = nil
					end
					v_u_1542.sil.Visible = true
					if v_u_1542.key then
						v_u_1542.key.TextColor3 = v_u_18.muted
					end
				end
				v_u_13.hint.setCap(v_u_1542, v1544, p_u_1522.compact)
			end
			local v1557 = v_u_188.Plus.update
			local v1558 = p_u_1522.slots.secure
			local v1559
			if type(v1526) == "table" then
				v1559 = v1526.kit or nil
			else
				v1559 = nil
			end
			local v1560
			if v1559 then
				v1560 = v1559.slots
				if v1560 then
					v1560 = v1559.slots.secure
				end
				if v1560 == nil then
					v1560 = v1559.secure
				end
				if type(v1560) ~= "table" then
					v1560 = nil
				end
			else
				v1560 = nil
			end
			v1557(v1558, v1560, p_u_1522.mode)
			local v1561 = {}
			local v1562 = {}
			for v1563, v1564 in v1526.containers or {} do
				if type(v1564) ~= "table" then
					continue
				end
				local v1565 = v1564.items
				if type(v1565) ~= "table" then
					continue
				end
				local v1566
				if v1564.world == true then
					v1566 = false
				else
					v1566 = v1563 ~= "stash"
				end
				for _, v1567 in v1564.items do
					v1561[v1567.uid] = v1567
					if not v1566 then
						continue
					end
					local v1568 = v1567.id
					local v1569 = v1562[v1567.id] or 0
					local v1570 = v1567.n
					v1562[v1568] = v1569 + (type(v1570) ~= "number" and 1 or v1567.n)
				end
			end
			for v1571, v1572 in p_u_1522.quick do
				local v1573
				if type(v1526) == "table" then
					v1573 = v1526.kit or nil
				else
					v1573 = nil
				end
				local v1574
				if v1573 then
					local v1575 = v1573.quick
					v1574 = type(v1575) == "table" and v1575[v1571] or v1573["quick" .. v1571]
					if type(v1574) ~= "string" or v1574 == "" then
						v1574 = nil
					end
				else
					v1574 = nil
				end
				local v1576
				if v1574 then
					v1576 = v1561[v1574]
				else
					v1576 = v1574
				end
				if v1576 then
					if v1572.icon and not v_u_12.alive(v1572.icon) then
						v1572.icon = nil
						v1572.iconId = nil
					end
					if v1572.iconId ~= v1576.id then
						if v1572.icon then
							v_u_12.release(v1572.icon)
							v1572.icon = nil
							v1572.iconId = nil
						end
						v1572.icon = v_u_12.get(v1576.id, false, {
							["parent"] = nil,
							["zindex"] = 4,
							["size"] = nil,
							["position"] = nil,
							["mods"] = nil,
							["parent"] = v1572.frame,
							["size"] = UDim2.new(1, -8, 1, -30),
							["position"] = UDim2.fromOffset(4, 15),
							["mods"] = v1576.mods
						})
						v1572.iconId = v1576.id
					end
					v1572.uid = v1574
					v1572.num.TextColor3 = v_u_18.accent
					local v1577 = v_u_9.get(v1576.id)
					local v1578 = v1572.name
					local v1579
					if v1577 then
						v1579 = string.upper(v1577.short or v1577.name)
					else
						local v1580 = v1576.id
						v1579 = tostring(v1580)
					end
					v1578.Text = v1579
					local v1581 = v1562[v1576.id] or 0
					v1572.count.Text = v1581 <= 1 and "" or "x" .. v1581
					local v1582 = v1572.frame
					local v1583
					if v1577 and v_u_9.shownRarity(v1577) > 1 then
						v1583 = v_u_18.bgDeep:Lerp(v_u_8.rarityColor(v_u_9.shownRarity(v1577)), 0.22)
					else
						v1583 = v_u_18.bgDeep
					end
					v1582.BackgroundColor3 = v1583
				else
					if v1572.icon then
						v_u_12.release(v1572.icon)
						v1572.icon = nil
						v1572.iconId = nil
					end
					v1572.uid = nil
					v1572.num.TextColor3 = v_u_18.muted
					v1572.name.Text = ""
					v1572.count.Text = ""
					v1572.frame.BackgroundColor3 = v_u_18.bgDeep
				end
			end
			local v1584 = 0
			local v1585 = {}
			local v1586
			if p_u_1522.mode == "raid" then
				v1586 = v_u_29
			else
				v1586 = v_u_30
			end
			for _, v1587 in v1586 do
				local v1588 = v1526.containers
				if v1588 then
					v1588 = v1526.containers[v1587]
				end
				v1584 = v1584 + 1
				if type(v1588) ~= "table" then
					continue
				end
				v1585[v1587] = true
				local v1589 = v_u_1501(p_u_1522, p_u_1522.gearScroll, v1587, v1588, v1584, p_u_1522.gearW)
				v1589.kind = "gear"
				local v1590 = v_u_10.usedCells(v1588)
				local v1591 = v1589.header.sub
				local v1592 = v_u_188.Pouch.subtitle(v1588, v1590, v_u_10.capacity(v1588), v1587)
				local v1593 = v_u_11.setText
				if not pcall(v1593, v1591, v1592) then
					v1591.Text = v1592
				end
				local v1594 = v_u_32[v1587]
				local v1595
				if v1594 then
					local v1596
					if type(v1526) == "table" then
						v1596 = v1526.kit or nil
					else
						v1596 = nil
					end
					if v1596 then
						v1595 = v1596.slots
						if v1595 then
							v1595 = v1596.slots[v1594]
						end
						if v1595 == nil then
							v1595 = v1596[v1594]
						end
						if type(v1595) ~= "table" then
							v1595 = nil
						end
					else
						v1595 = nil
					end
				else
					v1595 = v1594
				end
				local v1597
				if v1595 then
					v1597 = v_u_9.get(v1595.id)
				else
					v1597 = v1595
				end
				local v1598 = v1589.header.title
				local v1599
				if v1597 then
					v1599 = v_u_188.Case.name(v1595, v1597)
				else
					v1599 = v_u_31[v1587] or v1587
				end
				local v1600 = v_u_11.setText
				if not pcall(v1600, v1598, v1599) then
					v1598.Text = v1599
				end
				for _, v1601 in v1588.items do
					v1540[v1601.uid] = true
					local v1602
					if v1527[v1601.uid] then
						v1602 = table.clone(v1601)
						v1602._quick = v1527[v1601.uid]
					else
						v1602 = v1601
					end
					local v1603 = v_u_1423(p_u_1522, v1602, v1589.grid.cells, false)
					v_u_188.Pouch.place(v1589.grid.cells, v1603.frame, v1601.x, v1601.y, v_u_10.size(v1601))
				end
			end
			local v1604
			if p_u_1522.mode == "raid" then
				v1604 = v_u_29
			else
				v1604 = v_u_30
			end
			for _, v1605 in v1604 do
				local v1606 = p_u_1522.sections["ph_" .. v1605]
				local v1607 = not v1585[v1605]
				if v1607 then
					v1607 = v_u_32[v1605] == "bag" and true or v_u_32[v1605] == "armor"
				end
				if v1607 and not v1606 then
					local v1608 = v_u_32[v1605] == "bag"
					local v1609 = p_u_1522.tallPlaceholders == true
					local v1610 = not v1609 and 40 or (v1608 and 4 or 2) * p_u_1522.cell
					local v1611 = {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.5,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["Name"] = "Placeholder_" .. v1605,
						["BackgroundColor3"] = v_u_18.bgDeep,
						["Size"] = UDim2.fromOffset(p_u_1522.gearW, v1610)
					}
					local v1612 = p_u_1522.gearScroll
					local v1613 = Instance.new("Frame")
					if v1611 then
						for v1614, v1615 in v1611 do
							v1613[v1614] = v1615
						end
					end
					if v1612 then
						v1613.Parent = v1612
					end
					v_u_60(v1613, v_u_18.line, 0.4)
					if v1609 then
						local v1616 = v1610 - 24
						local v1617 = math.min(v1616, 84)
						local v1618 = {
							["Name"] = "Art",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(0, 0.5),
							["Position"] = UDim2.new(0, 18, 0.5, 0),
							["Size"] = UDim2.fromOffset(v1617, v1617)
						}
						local v1619 = Instance.new("Frame")
						if v1618 then
							for v1620, v1621 in v1618 do
								v1619[v1620] = v1621
							end
						end
						if v1613 then
							v1619.Parent = v1613
						end
						local v1622 = v_u_14.draw
						pcall(v1622, v1608 and "backpack" or "vest", v1619, {
							["zindex"] = 2,
							["fill"] = 0.8
						})
						local v1623 = v1617 + 18 + 18
						v_u_74(v1613, v1608 and "No backpack equipped" or "No rig equipped", "small", {
							["position"] = UDim2.new(0, v1623, 0.5, -21),
							["size"] = UDim2.new(1, -v1623 - 12, 0, 18),
							["color"] = v_u_18.text2
						}).TextYAlignment = Enum.TextYAlignment.Center
						v_u_74(v1613, v1608 and "Equip a backpack and its grid opens here." or "Equip a rig with pouches and its grid opens here.", "small", {
							["position"] = nil,
							["size"] = nil,
							["color"] = nil,
							["wrap"] = true,
							["position"] = UDim2.new(0, v1623, 0.5, 1),
							["size"] = UDim2.new(1, -v1623 - 12, 0, 36),
							["color"] = v_u_18.muted
						}).TextYAlignment = Enum.TextYAlignment.Top
					else
						v_u_74(v1613, v1608 and "No backpack equipped" or "No rig with pouches", "small", {
							["position"] = UDim2.fromOffset(12, 0),
							["size"] = UDim2.new(1, -24, 1, 0),
							["color"] = v_u_18.muted
						}).TextYAlignment = Enum.TextYAlignment.Center
					end
					p_u_1522.sections["ph_" .. v1605] = {
						["frame"] = nil,
						["placeholder"] = true,
						["kind"] = "gear",
						["frame"] = v1613
					}
					v1606 = p_u_1522.sections["ph_" .. v1605]
				elseif not v1607 and v1606 then
					v1606.frame:Destroy()
					p_u_1522.sections["ph_" .. v1605] = nil
					v1606 = nil
				end
				if not v1606 then
					continue
				end
				local v1624 = v1606.frame
				local v1625 = table.find
				local v1626
				if p_u_1522.mode == "raid" then
					v1626 = v_u_29
				else
					v1626 = v_u_30
				end
				v1624.LayoutOrder = v1625(v1626, v1605) or 9
			end
			local v1627 = {}
			if p_u_1522.mode == "raid" then
				for _, v1628 in v1526.open or {} do
					table.insert(v1627, v1628)
				end
			else
				table.insert(v1627, "stash")
			end
			local v1629 = 0
			for _, v1630 in v1627 do
				local v1631 = v1526.containers
				if v1631 then
					v1631 = v1526.containers[v1630]
				end
				if type(v1631) ~= "table" then
					continue
				end
				v1629 = v1629 + 1
				v1585[v1630] = true
				local v_u_1632 = v_u_1501(p_u_1522, p_u_1522.rightScroll, v1630, v1631, v1629 + (p_u_1522.narrow and (p_u_1522.mode == "raid" and -100 or 100) or 0), p_u_1522.rightW)
				v_u_1632.kind = "stash"
				local v1633 = v1631.world == true
				if v1633 then
					local v1634 = v_u_1632.header.title
					local v1635 = v1631.label or (v1631.kind or "Container")
					local v1636 = tostring(v1635)
					local v1637 = v_u_11.setText
					if not pcall(v1637, v1634, v1636) then
						v1634.Text = v1636
					end
					local v1638 = v1631.pending
					local v1639 = tonumber(v1638) or 0
					local v1640 = #v1631.items
					if v1631.searching or v1639 > 0 then
						local v1641 = v_u_1632.header.sub
						local v1642 = v1639 <= 0 and "Searching" or string.format("Searching \194\183 %d left", v1639)
						local v1643 = v_u_11.setText
						if not pcall(v1643, v1641, v1642) then
							v1641.Text = v1642
						end
						v_u_1632.header.sub.TextColor3 = v_u_18.accent
						if v_u_1632.ring then
							v_u_1632.ring.frame.Visible = true
						end
						local v1644 = v_u_1632.lastRevealed or 0
						if v1640 ~= v1644 then
							local v1645 = os.clock()
							if v_u_1632.lastRevealAt and v1644 < v1640 then
								local v1646 = v1645 - v_u_1632.lastRevealAt
								local v1647 = (v_u_1632.est or 1.2) * 0.5 + v1646 * 0.5
								v_u_1632.est = math.clamp(v1647, 0.3, 6)
							end
							v_u_1632.lastRevealAt = v1645
							v_u_1632.ringT = 0
						end
					else
						local v1648 = v_u_1632.header.sub
						local v1649 = v1631.hidden
						local v1650
						if (tonumber(v1649) or 0) > 0 then
							v1650 = v_u_188.Why.hiddenHeader(v1640, v1631.hidden)
						elseif v1631.ground then
							v1650 = string.format("%d %s", v1640, v1640 == 1 and "item" or "items") .. " in reach"
						else
							v1650 = string.format("%d %s", v1640, v1640 == 1 and "item" or "items")
						end
						local v1651 = v_u_11.setText
						if not pcall(v1651, v1648, v1650) then
							v1648.Text = v1650
						end
						local v1652 = v1631.hidden
						local v1653 = tonumber(v1652) or 0
						local v1654 = v_u_1632.header.sub
						local v1655
						if v1653 > 0 then
							v1655 = v_u_18.accent
						else
							v1655 = v_u_18.muted
						end
						v1654.TextColor3 = v1655
						if v1653 > 0 and not v_u_1632.hiddenTipSet then
							v_u_1632.hiddenTipSet = true
							v_u_1632.header.sub.Active = true
							local v1656 = v_u_11.tooltip
							local v1657 = v_u_1632.header.sub
							local function v1659()
								-- upvalues: (copy) v_u_1632, (ref) v_u_188
								local v1658 = v_u_1632.lastHidden
								return (tonumber(v1658) or 0) > 0 and {
									["title"] = "HIDDEN (PAID)",
									["body"] = nil,
									["body"] = v_u_188.Why.hiddenTip()
								} or nil
							end
							pcall(v1656, v1657, v1659)
						end
						v_u_1632.lastHidden = v1653
						if v_u_1632.ring then
							v_u_1632.ring.frame.Visible = false
						end
					end
					v_u_1632.searching = v1631.searching == true and true or v1639 > 0
					v_u_1632.lastRevealed = v1640
					if v1631.sub and v_u_1632.where then
						local v1660 = v1631.parentLabel or ""
						local v1661 = tostring(v1660)
						local v1662 = v_u_1632.where
						local v1663 = v1631.parent == "ground" and "On the ground" or "Inside " .. (v1661 == "" and "the container" or v1661)
						local v1664 = v_u_11.setText
						if not pcall(v1664, v1662, v1663) then
							v1662.Text = v1663
						end
					end
				else
					local v1665 = v_u_10.usedCells(v1631)
					local v1666 = v1630 ~= "stash" and 0 or v1526.waiting
					local v1667 = v_u_1632.header.sub
					local v1668 = v_u_188.Why.stashSub(v1665, v_u_10.capacity(v1631), v1666)
					local v1669 = v_u_11.setText
					if not pcall(v1669, v1667, v1668) then
						v1667.Text = v1668
					end
					local v1670 = v_u_1632.header.sub
					local v1671
					if v_u_188.Why.waitingLabel(v1666) == "" then
						v1671 = v_u_18.muted
					else
						v1671 = v_u_18.accent
					end
					v1670.TextColor3 = v1671
				end
				local v1672 = 0
				for _, v1673 in v1631.items do
					v1540[v1673.uid] = true
					local v1674
					if v1633 then
						if v1631.ground == true or (p_u_1522.tiles[v1673.uid] ~= nil or p_u_1522.knownWorld[v1673.uid] ~= nil) then
							v1674 = false
						else
							v1674 = p_u_1522.primed
						end
					else
						v1674 = v1633
					end
					if v1633 then
						if v1674 then
							v1672 = v1672 + 1
							if v1672 == 1 then
								local v1675 = v_u_11.sound
								pcall(v1675, "tick")
							end
						end
						p_u_1522.knownWorld[v1673.uid] = true
					end
					local v_u_1676 = v_u_1423(p_u_1522, v1673, v_u_1632.grid.cells, false)
					v_u_188.Pouch.place(v_u_1632.grid.cells, v_u_1676.frame, v1673.x, v1673.y, v_u_10.size(v1673))
					if not v1674 then
						continue
					end
					local v1677 = task.delay
					local v1678 = v1672 - 1
					v1677(math.min(v1678, 12) * 0.05, function()
						-- upvalues: (copy) v_u_1676
						if v_u_1676.alive() then
							local v1679 = v_u_1676.flash
							pcall(v1679)
						end
					end)
				end
				if not v1633 then
					break
				end
				local v1680 = v_u_188.Search.render
				local v1681 = v1526.search
				local v1682
				if type(v1681) == "table" and v1526.search.container == v1630 then
					v1682 = v1526.search.uid
				else
					v1682 = nil
				end
				v1680(p_u_1522, v_u_1632, v1630, v1631, v1682)
			end
			if p_u_1522.mode ~= "raid" and type(v1526) == "table" then
				local v1683 = v1526.cases
				if type(v1683) == "table" then
					v_u_188.lastCaseMount = p_u_1522
				end
			end
			v_u_188.Case.render(p_u_1522, v1526, v1585, v1540)
			local v1684 = v_u_188.StashHints.render
			local v1685 = v_u_20
			pcall(v1684, v1685, p_u_1522)
			p_u_1522.primed = true
			local v1686 = p_u_1522.pendingSub
			if v1686 and p_u_1522.sections[v1686] then
				p_u_1522.pendingSub = nil
				local v_u_1687 = p_u_1522.sections[v1686].frame
				local v_u_1688 = p_u_1522.rightScroll
				task.defer(function()
					-- upvalues: (copy) v_u_1688, (copy) v_u_1687
					if v_u_1688 and (v_u_1688.Parent and v_u_1687.Parent) then
						local v1689 = v_u_1687.AbsolutePosition.Y - v_u_1688.AbsolutePosition.Y
						if v1689 < 0 or v1689 + v_u_1687.AbsoluteSize.Y > v_u_1688.AbsoluteSize.Y then
							local v1690 = v_u_1688.AbsoluteCanvasSize.Y - v_u_1688.AbsoluteSize.Y
							local v1691 = math.max(0, v1690)
							local v1692 = v_u_1688
							local v1693 = Vector2.new
							local v1694 = v_u_1688.CanvasPosition.X
							local v1695 = v_u_1688.CanvasPosition.Y + v1689 - 8
							v1692.CanvasPosition = v1693(v1694, (math.clamp(v1695, 0, v1691)))
						end
					end
				end)
			end
			if p_u_1522.mode == "raid" and #v1627 == 0 then
				if not (p_u_1522.emptyNote and p_u_1522.emptyNote.Parent) then
					local v1696 = {
						["Name"] = "Empty",
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["Size"] = UDim2.fromOffset(p_u_1522.rightW, 120),
						["LayoutOrder"] = p_u_1522.narrow and 100 or 0
					}
					local v1697 = p_u_1522.rightScroll
					local v1698 = Instance.new("Frame")
					if v1696 then
						for v1699, v1700 in v1696 do
							v1698[v1699] = v1700
						end
					end
					if v1697 then
						v1698.Parent = v1697
					end
					v_u_74(v1698, "Nothing opened", "h3", {
						["position"] = UDim2.fromOffset(0, 24),
						["size"] = UDim2.new(1, 0, 0, 22),
						["color"] = v_u_18.text2
					}).TextXAlignment = Enum.TextXAlignment.Center
					local v1701 = v_u_74(v1698, "Walk up to cabinets, cars, bodies or items on the ground: what they hold shows up here.", "small", {
						["position"] = nil,
						["size"] = nil,
						["color"] = nil,
						["wrap"] = true,
						["position"] = UDim2.fromOffset(24, 52),
						["size"] = UDim2.new(1, -48, 0, 48),
						["color"] = v_u_18.muted
					})
					v1701.TextWrapped = true
					v1701.TextTruncate = Enum.TextTruncate.None
					v1701.TextXAlignment = Enum.TextXAlignment.Center
					v1701.TextYAlignment = Enum.TextYAlignment.Top
					p_u_1522.emptyNote = v1698
				end
			elseif p_u_1522.emptyNote then
				p_u_1522.emptyNote:Destroy()
				p_u_1522.emptyNote = nil
			end
			for v1702, v1703 in p_u_1522.sections do
				if v1703.placeholder or v1585[v1702] then
					continue
				end
				for v1704, v1705 in p_u_1522.tiles do
					if v1705.frame.Parent ~= v1703.grid.cells then
						continue
					end
					v1705.destroy()
					p_u_1522.tiles[v1704] = nil
				end
				v1703.frame:Destroy()
				p_u_1522.sections[v1702] = nil
				p_u_1522.grids[v1702] = nil
			end
			for v1706, v1707 in p_u_1522.tiles do
				if v1540[v1706] then
					continue
				end
				v1707.destroy()
				p_u_1522.tiles[v1706] = nil
			end
			if v_u_149 and v_u_149.m == p_u_1522 then
				if p_u_1522.tiles[v_u_149.uid] then
					p_u_1522.tiles[v_u_149.uid].setGhosted(true)
					v_u_149.src = p_u_1522.tiles[v_u_149.uid]
				elseif not v_u_175(v1526, v_u_149.uid) then
					v_u_149.src = nil
					task.defer(function()
						-- upvalues: (ref) v_u_149, (copy) p_u_1522, (ref) v_u_175, (ref) v_u_1010, (ref) v_u_11
						if v_u_149 and (v_u_149.m == p_u_1522 and not v_u_175(p_u_1522.work, v_u_149.uid)) then
							v_u_1010(v_u_149.pos, true)
							local v1708 = v_u_11.sound
							pcall(v1708, "error")
						end
					end)
				end
			end
			local v1709 = v1526.weight
			local v1710 = tonumber(v1709) or 0
			local v1711 = v1526.maxWeight
			local v1712 = tonumber(v1711) or 0
			local function v1713()
				-- upvalues: (ref) v_u_6
				return require(v_u_6:WaitForChild("Skills"))
			end
			local v1714, v1715 = pcall(v1713)
			local v1716
			if v1714 and type(v1715) == "table" then
				local v1717 = v1715.MOVE
				if type(v1717) == "table" then
					v1716 = v1715.MOVE.overweightNoSprint
				else
					v1716 = nil
				end
			else
				v1716 = nil
			end
			if p_u_1522.weightText then
				local v1718 = p_u_1522.weightText
				local v1719
				if v1712 > 0 then
					v1719 = string.format("%.1f / %.1f kg", v1710, v1712)
				else
					v1719 = string.format("%.1f kg", v1710)
				end
				local v1720 = v_u_11.setText
				if not pcall(v1720, v1718, v1719) then
					v1718.Text = v1719
				end
				local v1721 = p_u_1522.weightText
				local v1722
				if v1712 > 0 and v1712 < v1710 then
					v1722 = v_u_18.danger
				elseif v1712 > 0 and v1712 * 0.8 < v1710 then
					v1722 = v_u_18.accent
				else
					v1722 = v_u_18.text2
				end
				v1721.TextColor3 = v1722
				if p_u_1522.weightLabel then
					local v1723 = p_u_1522.weightLabel
					local v1724 = v_u_188.Why.weightWord(v1710, v1712, v1716)
					local v1725 = v_u_11.setText
					if not pcall(v1725, v1723, v1724) then
						v1723.Text = v1724
					end
				end
			end
			if p_u_1522.weightBar then
				local v1726
				if v1712 > 0 then
					local v1727 = v1710 / v1712
					v1726 = math.clamp(v1727, 0, 1)
				else
					v1726 = 0
				end
				local v1728 = p_u_1522.weightBar.set
				local v1729 = not p_u_1522.weightPrimed
				pcall(v1728, v1726, v1729)
				p_u_1522.weightPrimed = true
				local v1730 = p_u_1522.weightBar.setColor
				local v1731
				if v1712 > 0 and v1712 < v1710 then
					v1731 = v_u_18.danger
				elseif v1726 > 0.8 then
					v1731 = v_u_18.accent
				else
					v1731 = v_u_18.success
				end
				pcall(v1730, v1731)
			end
			if p_u_1522.summary then
				local v1732 = p_u_1522.summary
				local v1733
				if type(v1526) == "table" then
					v1733 = v1526.kit or nil
				else
					v1733 = nil
				end
				local v1734
				if v1733 then
					v1734 = v1733.slots
					if v1734 then
						v1734 = v1733.slots.armor
					end
					if v1734 == nil then
						v1734 = v1733.armor
					end
					if type(v1734) ~= "table" then
						v1734 = nil
					end
				else
					v1734 = nil
				end
				local v1735
				if type(v1526) == "table" then
					v1735 = v1526.kit or nil
				else
					v1735 = nil
				end
				local v1736
				if v1735 then
					v1736 = v1735.slots
					if v1736 then
						v1736 = v1735.slots.helmet
					end
					if v1736 == nil then
						v1736 = v1735.helmet
					end
					if type(v1736) ~= "table" then
						v1736 = nil
					end
				else
					v1736 = nil
				end
				if v1734 then
					v1734 = v_u_9.get(v1734.id)
				end
				if v1736 then
					v1736 = v_u_9.get(v1736.id)
				end
				local v1737 = v1732.Armor
				local v1738 = "Body "
				local v1739
				if v1734 and v1734.armorClass then
					local v1740 = v1734.armorClass
					v1739 = tostring(v1740)
				else
					v1739 = "-"
				end
				local v1741 = "  \194\183  Head "
				local v1742
				if v1736 and v1736.armorClass then
					local v1743 = v1736.armorClass
					v1742 = tostring(v1743)
				else
					v1742 = "-"
				end
				local v1744 = v1738 .. v1739 .. v1741 .. v1742
				local v1745 = v_u_11.setText
				if not pcall(v1745, v1737, v1744) then
					v1737.Text = v1744
				end
				local v1746 = v1734 and v1734.zombieBiteBlock or 0
				local v1747 = v1732["Bite block"]
				local v1748
				if v1746 > 0 then
					local v1749 = string.format
					local v1750 = v1746 * 100 + 0.5
					v1748 = v1749("%d%%", (math.floor(v1750)))
				else
					v1748 = "None"
				end
				local v1751 = v_u_11.setText
				if not pcall(v1751, v1747, v1748) then
					v1747.Text = v1748
				end
				local v1752 = v1732["Bite block"]
				local v1753
				if v1746 > 0 then
					v1753 = v_u_18.infection
				else
					v1753 = v_u_18.muted
				end
				v1752.TextColor3 = v1753
				local v1754 = 0
				local v1755 = 0
				local v1756 = 0
				local v1757 = 0
				local v1758
				if type(v1526) == "table" then
					v1758 = v1526.kit or nil
				else
					v1758 = nil
				end
				local v1759
				if v1758 then
					v1759 = v1758.slots
					if v1759 then
						v1759 = v1758.slots.primary
					end
					if v1759 == nil then
						v1759 = v1758.primary
					end
					if type(v1759) ~= "table" then
						v1759 = nil
					end
				else
					v1759 = nil
				end
				if v1759 then
					v1759 = v_u_9.get(v1759.id)
				end
				if v1759 then
					v1759 = v1759.caliber
				end
				local v1760
				if p_u_1522.mode == "raid" then
					v1760 = v_u_29
				else
					v1760 = v_u_30
				end
				for _, v1761 in v1760 do
					local v1762 = v1526.containers
					if v1762 then
						v1762 = v1526.containers[v1761]
					end
					if type(v1762) ~= "table" then
						continue
					end
					local v1763 = v1762.items
					if type(v1763) ~= "table" then
						continue
					end
					v1755 = v1755 + v_u_10.capacity(v1762)
					v1754 = v1754 + (v_u_10.capacity(v1762) - v_u_10.usedCells(v1762))
					for _, v1764 in v1762.items do
						local v1765 = v_u_9.get(v1764.id)
						local v1766 = v1764.n
						local v1767 = type(v1766) ~= "number" and 1 or v1764.n
						if v1765 and (v1765.category == "ammo" and (v1759 and v1765.caliber == v1759)) then
							v1756 = v1756 + v1767
						else
							if not v1765 or v1765.category ~= "medical" then
								continue
							end
							v1757 = v1757 + v1767
						end
					end
				end
				local v1768 = v1732["Free cells"]
				local v1769 = string.format("%d / %d", v1754, v1755)
				local v1770 = v_u_11.setText
				if not pcall(v1770, v1768, v1769) then
					v1768.Text = v1769
				end
				local v1771 = v1732["Free cells"]
				local v1772
				if v1755 > 0 and v1754 == 0 then
					v1772 = v_u_18.danger
				else
					v1772 = v_u_18.text
				end
				v1771.TextColor3 = v1772
				local v1773 = v1732.Ammo
				local v1774 = not v1759 and "No primary" or string.format("%d  \194\183  %s", v1756, v_u_9.CALIBER_LABEL[v1759] or string.upper((tostring(v1759))))
				local v1775 = v_u_11.setText
				if not pcall(v1775, v1773, v1774) then
					v1773.Text = v1774
				end
				local v1776 = v1732.Ammo
				local v1777
				if v1759 and v1756 == 0 then
					v1777 = v_u_18.danger
				elseif v1759 then
					v1777 = v_u_18.text
				else
					v1777 = v_u_18.muted
				end
				v1776.TextColor3 = v1777
				local v1778 = v1732.Medical
				local v1779 = tostring(v1757)
				local v1780 = v_u_11.setText
				if not pcall(v1780, v1778, v1779) then
					v1778.Text = v1779
				end
				local v1781 = v1732.Medical
				local v1782
				if v1757 == 0 then
					v1782 = v_u_18.danger
				else
					v1782 = v_u_18.text
				end
				v1781.TextColor3 = v1782
			end
			local v1783 = p_u_1522.mode ~= "raid" and v_u_13.sellKit(v1526)
			if not v1783 then
				local v1784 = v1526.value
				v1783 = tonumber(v1784) or 0
			end
			if p_u_1522.valueText then
				local v1785 = p_u_1522.valueText
				local v1786 = v_u_13.money(v1783)
				local v1787 = v_u_11.setText
				if not pcall(v1787, v1785, v1786) then
					v1785.Text = v1786
				end
			end
			if p_u_1522.headerStats then
				local v1788 = string.format("%s  \194\183  %.1f kg", v_u_13.money(v1783), v1710)
				if p_u_1522.mode ~= "raid" and (v1526.containers and v1526.containers.stash) then
					v1788 = string.format("Kit %s  \194\183  %s in stash", v_u_13.money(v1783), v_u_28(#v1526.containers.stash.items, "item"))
				end
				local v1789 = p_u_1522.headerStats
				local v1790 = v_u_11.setText
				if not pcall(v1790, v1789, v1788) then
					v1789.Text = v1788
				end
			end
			local v1791 = p_u_1522.work
			if type(v1791) ~= "table" and (p_u_1522.mode ~= "raid" and p_u_1522.headerStats) then
				local v1792 = p_u_1522.headerStats
				local v1793 = v_u_188.Why.loadingStash()
				local v1794 = v_u_11.setText
				if not pcall(v1794, v1792, v1793) then
					v1792.Text = v1793
				end
			end
			v_u_1316(p_u_1522)
			if p_u_1522.rail and p_u_1522.rail.dots then
				for v1795, v1796 in p_u_1522.rail.dots do
					local v1797
					if type(v1526) == "table" then
						v1797 = v1526.kit or nil
					else
						v1797 = nil
					end
					local v1798
					if v1797 then
						v1798 = v1797.slots
						if v1798 then
							v1798 = v1797.slots[v1795]
						end
						if v1798 == nil then
							v1798 = v1797[v1795]
						end
						if type(v1798) ~= "table" then
							v1798 = nil
						end
					else
						v1798 = nil
					end
					local v1799 = v1798 ~= nil
					local v1800
					if v1799 then
						v1800 = v_u_18.accent
					else
						v1800 = v_u_18.bgDeep
					end
					v1796.BackgroundColor3 = v1800
					v1796.BackgroundTransparency = v1799 and 0 or 0.2
				end
				if p_u_1522.rail.weight then
					local v1801 = p_u_1522.rail.weight
					local v1802 = string.format("%.1f", v1710)
					local v1803 = v_u_11.setText
					if not pcall(v1803, v1801, v1802) then
						v1801.Text = v1802
					end
					local v1804 = p_u_1522.rail.weight
					local v1805
					if v1712 > 0 and v1712 < v1710 then
						v1805 = v_u_18.danger
					elseif v1712 > 0 and v1712 * 0.8 < v1710 then
						v1805 = v_u_18.accent
					else
						v1805 = v_u_18.text2
					end
					v1804.TextColor3 = v1805
				end
			end
			if v_u_159 and v_u_159.m == p_u_1522 then
				v_u_159.dirty = true
			end
			v_u_188.Insure.paint(v_u_20, p_u_1522)
			v_u_1516(p_u_1522)
			p_u_1522.cullDirty = true
			return
		end
	end
end
local v_u_1806 = 0
local function v_u_1824(p1807, p1808) -- name: makeLayer
	-- upvalues: (ref) v_u_1806, (copy) v_u_8
	local v1809 = p1807:FindFirstAncestorWhichIsA("LayerCollector")
	if not (v1809 and v1809.Parent) then
		return nil
	end
	local v_u_1810
	if v1809:IsA("ScreenGui") then
		v_u_1810 = v1809
	else
		v_u_1810 = nil
	end
	v_u_1806 = v_u_1806 + 1
	local v1811 = {
		["Name"] = nil,
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = nil,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = nil,
		["Name"] = "HushInventoryLayer_" .. v_u_1806,
		["IgnoreGuiInset"] = not v_u_1810 and true or v_u_1810.IgnoreGuiInset,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v1812
	if v_u_1810 then
		v1812 = v_u_1810.DisplayOrder
	else
		v1812 = v_u_8.layer.menu
	end
	v1811.DisplayOrder = v1812 + 1
	local v_u_1813 = Instance.new("ScreenGui")
	if v1811 then
		for v1814, v1815 in v1811 do
			v_u_1813[v1814] = v1815
		end
	end
	if v_u_1810 then
		pcall(function()
			-- upvalues: (copy) v_u_1813, (copy) v_u_1810
			v_u_1813.ScreenInsets = v_u_1810.ScreenInsets
		end)
	end
	local v1816 = {
		["Name"] = "Host",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Size"] = UDim2.fromOffset(10, 10)
	}
	local v1817 = Instance.new("Frame")
	if v1816 then
		for v1818, v1819 in v1816 do
			v1817[v1818] = v1819
		end
	end
	if v_u_1813 then
		v1817.Parent = v_u_1813
	end
	local v1820 = {
		["Name"] = "HushScale",
		["Scale"] = nil,
		["Scale"] = v_u_8.uiScale()
	}
	local v1821 = Instance.new("UIScale")
	if v1820 then
		for v1822, v1823 in v1820 do
			v1821[v1822] = v1823
		end
	end
	if v1817 then
		v1821.Parent = v1817
	end
	v_u_1813.Parent = v1809.Parent
	return {
		["gui"] = v_u_1813,
		["host"] = v1817,
		["scale"] = v1821,
		["anchor"] = p1807,
		["canvas"] = p1808
	}
end
local function v_u_1848(p1825) -- name: syncLayer
	-- upvalues: (copy) v_u_8, (copy) v_u_106, (copy) v_u_76, (ref) v_u_149, (copy) v_u_1010, (ref) v_u_159, (ref) v_u_156, (copy) v_u_21, (copy) v_u_164
	local v1826 = p1825.layer
	if v1826 then
		local v1827 = v1826.anchor
		if v1827.Parent and v1826.gui.Parent then
			local v1828 = v_u_8.uiScale()
			if v1826.scale.Scale ~= v1828 then
				v1826.scale.Scale = v1828
			end
			local v1829 = v1827.AbsolutePosition
			local v1830 = v1826.gui.AbsolutePosition
			local v1831 = v1827.AbsoluteSize
			local v1832 = UDim2.fromOffset
			local v1833 = v1829.X - v1830.X + 0.5
			local v1834 = math.floor(v1833)
			local v1835 = v1829.Y - v1830.Y + 0.5
			local v1836 = v1832(v1834, (math.floor(v1835)))
			local v1837 = v_u_8.devViewport
			local v1838, v1839 = pcall(v1837)
			if v1838 then
				v1838 = v1839 ~= nil
			end
			local v1840
			if v1838 then
				v1840 = v_u_106(v1827)
			else
				v1840 = v1831 / v1828
			end
			local v1841 = UDim2.fromOffset
			local v1842 = v1840.X + 0.5
			local v1843 = math.floor(v1842)
			local v1844 = v1840.Y + 0.5
			local v1845 = v1841(v1843, (math.floor(v1844)))
			if v1826.host.Position ~= v1836 then
				v1826.host.Position = v1836
			end
			if v1826.host.Size ~= v1845 then
				v1826.host.Size = v1845
			end
			local v1846 = v_u_76(v1827)
			if v1826.host.Visible ~= v1846 then
				v1826.host.Visible = v1846
				if not v1846 and p1825.opened then
					if v_u_149 and v_u_149.m == p1825 then
						v_u_1010(v_u_149.pos, true)
					end
					local v1847 = v_u_159 and (v_u_159.m == p1825 and v_u_159)
					if v1847 then
						v_u_159 = nil
						if v1847.mark then
							v1847.mark:Destroy()
						end
						if not v_u_149 and v_u_156 then
							v_u_156:Destroy()
							v_u_156 = nil
						end
						if v_u_21 then
							v_u_21:SetAttribute("InvUISelected", nil)
						end
					end
					v_u_164()
				end
			end
		elseif not p1825.dead then
			p1825.destroy()
		end
	else
		return
	end
end
local function v_u_1913(p1849, p1850, p1851) -- name: makeMount
	-- upvalues: (copy) v_u_78, (copy) v_u_1824, (copy) v_u_52, (ref) v_u_128, (ref) v_u_135, (copy) v_u_188, (copy) v_u_76, (copy) v_u_1346, (copy) v_u_1356, (ref) v_u_149, (ref) v_u_179, (ref) v_u_178, (copy) v_u_1848, (copy) v_u_106, (copy) v_u_11, (copy) v_u_1010, (ref) v_u_159, (ref) v_u_156, (copy) v_u_21, (copy) v_u_164, (ref) v_u_157, (copy) v_u_136, (copy) v_u_12, (copy) v_u_8
	local v_u_1852 = {
		["mode"] = nil,
		["tiles"] = nil,
		["grids"] = nil,
		["slots"] = nil,
		["quick"] = nil,
		["sections"] = nil,
		["knownWorld"] = nil,
		["fake"] = nil,
		["opened"] = nil,
		["cell"] = 52,
		["mode"] = p1850 == "raid" and "raid" or "menu",
		["tiles"] = {},
		["grids"] = {},
		["slots"] = {},
		["quick"] = {},
		["sections"] = {},
		["knownWorld"] = {},
		["fake"] = p1851,
		["opened"] = p1850 ~= "raid"
	}
	local v1853 = p1849.Name == "Root" and p1849.Parent
	if v1853 then
		v1853 = p1849.Parent:IsA("ScreenGui")
	end
	v_u_1852.standalone = v1853
	local v1854 = v_u_78(p1849)
	if v1854 then
		local v1855 = v_u_1824(p1849, v1854)
		if v1855 then
			v_u_1852.layer = v1855
			p1849 = v1855.host
		end
	end
	local v1856 = {
		["Name"] = "HushInventoryUI",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Visible"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Visible"] = v_u_1852.opened
	}
	local v_u_1857 = Instance.new("Frame")
	if v1856 then
		for v1858, v1859 in v1856 do
			v_u_1857[v1858] = v1859
		end
	end
	if p1849 then
		v_u_1857.Parent = p1849
	end
	v_u_1852.root = v_u_1857
	local v1860 = v_u_52
	local v1861
	if v_u_1852.fake then
		v1861 = v_u_1852.fake
	elseif v_u_1852.mode == "raid" then
		v1861 = v_u_128
	else
		v1861 = v_u_135
	end
	v_u_1852.work = v1860(v1861)
	if not v_u_1852.fake and v_u_1852.work then
		v_u_188.Pred.replay(v_u_1852.mode, v_u_1852.work)
	end
	function v_u_1852.isShown() -- name: isShown
		-- upvalues: (copy) v_u_1852, (ref) v_u_76, (copy) v_u_1857
		local v1862 = v_u_1852.opened
		if v1862 then
			local v1863 = v_u_1852
			if v1863.dead or v1863.gone then
				v1862 = false
			else
				local v1864 = v1863.root
				if v1864 and v1864.Parent ~= nil then
					v1862 = (not v1863.layer or v1863.layer.gui.Parent ~= nil) and true or false
				else
					v1862 = false
				end
			end
			if v1862 then
				v1862 = v_u_76(v_u_1857)
			end
		end
		return v1862
	end
	function v_u_1852.setState(p1865) -- name: setState
		-- upvalues: (copy) v_u_1852, (ref) v_u_52, (ref) v_u_128, (ref) v_u_135, (ref) v_u_188, (ref) v_u_1346, (ref) v_u_1356, (ref) v_u_149, (ref) v_u_179, (ref) v_u_178
		local v1866 = v_u_1852
		local v1867
		if v1866.dead or v1866.gone then
			v1867 = false
		else
			local v1868 = v1866.root
			if v1868 and v1868.Parent ~= nil then
				v1867 = (not v1866.layer or v1866.layer.gui.Parent ~= nil) and true or false
			else
				v1867 = false
			end
		end
		if v1867 then
			if v_u_1852.fake then
				v_u_1852.fake = p1865
			end
			local v1869 = v_u_1852
			local v1870 = v_u_52
			local v1871
			if v1869.fake then
				v1871 = v1869.fake
			elseif v1869.mode == "raid" then
				v1871 = v_u_128
			else
				v1871 = v_u_135
			end
			v1869.work = v1870(v1871)
			if not v1869.fake and v1869.work then
				v_u_188.Pred.replay(v1869.mode, v1869.work)
			end
			if v_u_1852.body then
				local v1872 = v_u_1852
				local v1873
				if v1872.touchSplitCandidate == true then
					local v1874 = v_u_1346(v1872)
					v1873 = (v1874 == "" and "" or v1874 .. "|g" .. v_u_1356(v1872)) ~= v1872.builtRightKey
				else
					v1873 = false
				end
				if v1873 then
					if not v_u_149 or v_u_149.m ~= v_u_1852 then
						v_u_179(v_u_1852)
						return
					end
					v_u_1852.relayoutPending = true
				end
			end
			if v_u_149 and v_u_149.m == v_u_1852 then
				v_u_178(v_u_1852)
			else
				v_u_178(v_u_1852)
			end
		else
			v_u_1852.destroy()
			return
		end
	end
	function v_u_1852.open() -- name: open
		-- upvalues: (copy) v_u_1852, (ref) v_u_188, (ref) v_u_149, (copy) v_u_1857, (ref) v_u_1848, (ref) v_u_52, (ref) v_u_128, (ref) v_u_135, (ref) v_u_106, (ref) v_u_1346, (ref) v_u_1356, (ref) v_u_179, (ref) v_u_178, (ref) v_u_11
		if v_u_1852.opened then
			return
		end
		v_u_188.TD.heal(v_u_149 ~= nil)
		v_u_1852.opened = true
		v_u_1857.Visible = true
		v_u_1848(v_u_1852)
		if v_u_1852.dead then
			return
		end
		local v1875 = v_u_1852
		local v1876 = v_u_52
		local v1877
		if v1875.fake then
			v1877 = v1875.fake
		elseif v1875.mode == "raid" then
			v1877 = v_u_128
		else
			v1877 = v_u_135
		end
		v1875.work = v1876(v1877)
		if not v1875.fake and v1875.work then
			v_u_188.Pred.replay(v1875.mode, v1875.work)
		end
		local v1878, v1879, v1880
		if v_u_1852.body then
			local v1881 = (v_u_1852.dw or 0) - v_u_106(v_u_1857).X
			if math.abs(v1881) > 4 then
				v_u_179(v_u_1852)
				v1878 = v_u_11.animateIn
				v1879 = v_u_1857
				pcall(v1878, v1879, 8)
				v1880 = v_u_11.sound
				pcall(v1880, "open")
				if v_u_1852.onOpen then
					v_u_1852.onOpen()
				end
				return
			else
				local v1882 = v_u_1852
				local v1883
				if v1882.touchSplitCandidate == true then
					local v1884 = v_u_1346(v1882)
					v1883 = (v1884 == "" and "" or v1884 .. "|g" .. v_u_1356(v1882)) ~= v1882.builtRightKey
				else
					v1883 = false
				end
				if v1883 then
					v_u_179(v_u_1852)
					v1878 = v_u_11.animateIn
					v1879 = v_u_1857
					pcall(v1878, v1879, 8)
					v1880 = v_u_11.sound
					pcall(v1880, "open")
					if v_u_1852.onOpen then
						v_u_1852.onOpen()
					end
				else
					v_u_178(v_u_1852)
					v1878 = v_u_11.animateIn
					v1879 = v_u_1857
					pcall(v1878, v1879, 8)
					v1880 = v_u_11.sound
					pcall(v1880, "open")
					if v_u_1852.onOpen then
						v_u_1852.onOpen()
					end
				end
			end
		else
			v_u_179(v_u_1852)
			v1878 = v_u_11.animateIn
			v1879 = v_u_1857
			pcall(v1878, v1879, 8)
			v1880 = v_u_11.sound
			pcall(v1880, "open")
			if v_u_1852.onOpen then
				v_u_1852.onOpen()
			end
			return
		end
	end
	function v_u_1852.close() -- name: close
		-- upvalues: (copy) v_u_1852, (ref) v_u_149, (ref) v_u_1010, (ref) v_u_188, (ref) v_u_159, (ref) v_u_156, (ref) v_u_21, (ref) v_u_164, (ref) v_u_157, (copy) v_u_1857, (ref) v_u_11
		if v_u_1852.opened then
			if v_u_149 and v_u_149.m == v_u_1852 then
				v_u_1010(v_u_149.pos, true)
			end
			v_u_188.TD.heal(v_u_149 ~= nil)
			local v1885 = v_u_159 and (v_u_159.m == v_u_1852 and v_u_159)
			if v1885 then
				v_u_159 = nil
				if v1885.mark then
					v1885.mark:Destroy()
				end
				if not v_u_149 and v_u_156 then
					v_u_156:Destroy()
					v_u_156 = nil
				end
				if v_u_21 then
					v_u_21:SetAttribute("InvUISelected", nil)
				end
			end
			v_u_164()
			if v_u_157 then
				v_u_157:Destroy()
				v_u_157 = nil
			end
			v_u_1852.opened = false
			v_u_1857.Visible = false
			local v1886 = v_u_11.hideTooltip
			pcall(v1886)
			local v1887 = v_u_11.sound
			pcall(v1887, "close")
			if v_u_1852.onClose then
				v_u_1852.onClose()
			end
		end
	end
	function v_u_1852.toggle() -- name: toggle
		-- upvalues: (copy) v_u_1852
		if v_u_1852.opened then
			v_u_1852.close()
		else
			v_u_1852.open()
		end
	end
	function v_u_1852.destroy() -- name: destroy
		-- upvalues: (copy) v_u_1852, (ref) v_u_136, (ref) v_u_12, (copy) v_u_1857
		if not v_u_1852.dead then
			v_u_1852.dead = true
			local v1888 = table.find(v_u_136, v_u_1852)
			if v1888 then
				table.remove(v_u_136, v1888)
			end
			local v1889 = v_u_1852.close
			local v1890, v1891 = pcall(v1889)
			if not v1890 then
				warn("[InventoryUI] close during destroy failed:", v1891)
			end
			for _, v1892 in v_u_1852.tiles do
				local v1893 = v1892.destroy
				pcall(v1893)
			end
			v_u_1852.tiles = {}
			for _, v1894 in v_u_1852.slots do
				if not v1894.tile then
					continue
				end
				local v1895 = v1894.tile.destroy
				pcall(v1895)
				v1894.tile = nil
			end
			for _, v1896 in v_u_1852.quick do
				if not v1896.icon then
					continue
				end
				v_u_12.release(v1896.icon)
				v1896.icon = nil
				v1896.iconId = nil
			end
			local v1897 = v_u_1857.Destroy
			local v1898 = v_u_1857
			pcall(v1897, v1898)
			if v_u_1852.layer then
				local v1899 = v_u_1852.layer.gui.Destroy
				local v1900 = v_u_1852.layer.gui
				pcall(v1899, v1900)
			end
		end
	end
	v_u_1852.show = v_u_1852.open
	function v_u_1852.isOpen()
		-- upvalues: (copy) v_u_1852
		return v_u_1852.isShown()
	end
	local v_u_1901 = false
	v_u_1857:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (ref) v_u_1901, (copy) v_u_1857, (ref) v_u_8, (ref) v_u_106, (copy) v_u_1852, (ref) v_u_149, (ref) v_u_179
		if not v_u_1901 then
			v_u_1901 = true
			task.delay(0.12, function()
				-- upvalues: (ref) v_u_1901, (ref) v_u_1857, (ref) v_u_8, (ref) v_u_106, (ref) v_u_1852, (ref) v_u_149, (ref) v_u_179
				v_u_1901 = false
				if v_u_1857.Parent then
					local v1902 = v_u_8.devViewport
					local v1903, v1904 = pcall(v1902)
					if v1903 then
						v1903 = v1904 ~= nil
					end
					if v1903 or v_u_1857.AbsoluteSize.X > 10 then
						local v1905 = v_u_106(v_u_1857)
						local v1906 = (v_u_1852.dw or 0) - v1905.X
						if math.abs(v1906) > 4 then
							if not v_u_149 or v_u_149.m ~= v_u_1852 then
								v_u_179(v_u_1852)
							end
						else
							local v1907 = (v_u_1852.dh or 0) - v1905.Y
							if math.abs(v1907) <= 4 then
								return
							end
							if not v_u_149 or v_u_149.m ~= v_u_1852 then
								v_u_179(v_u_1852)
							end
						end
					end
				else
					return
				end
			end)
		end
	end)
	v_u_1857.Destroying:Connect(function()
		-- upvalues: (copy) v_u_1852
		if not v_u_1852.dead then
			v_u_1852.gone = true
			task.defer(function()
				-- upvalues: (ref) v_u_1852
				if not v_u_1852.dead then
					v_u_1852.destroy()
				end
			end)
		end
	end)
	local v1908 = v_u_136
	table.insert(v1908, v_u_1852)
	if v_u_1852.layer then
		local v1909 = v_u_1852.layer.anchor
		v1909.Destroying:Connect(function()
			-- upvalues: (copy) v_u_1852
			task.defer(function()
				-- upvalues: (ref) v_u_1852
				if not v_u_1852.dead then
					v_u_1852.destroy()
				end
			end)
		end)
		v1909:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (copy) v_u_1852, (ref) v_u_1848
			if not v_u_1852.dead then
				v_u_1848(v_u_1852)
			end
		end)
		v_u_1848(v_u_1852)
	end
	if v_u_1852.opened then
		local v1910 = v_u_179
		local v1911, v1912 = pcall(v1910, v_u_1852)
		if not v1911 then
			v_u_1852.destroy()
			error(v1912, 0)
		end
	end
	return v_u_1852
end
local function v_u_1919(p_u_1914) -- name: handleOf
	-- upvalues: (copy) v_u_19, (ref) v_u_1306
	return {
		["root"] = p_u_1914.root,
		["open"] = p_u_1914.open,
		["close"] = p_u_1914.close,
		["toggle"] = p_u_1914.toggle,
		["isOpen"] = p_u_1914.isOpen,
		["show"] = p_u_1914.show,
		["destroy"] = p_u_1914.destroy,
		["setState"] = p_u_1914.setState,
		["setSection"] = function(p1915) -- name: setSection
			-- upvalues: (ref) v_u_19, (copy) p_u_1914
			local v1916 = {
				["_mount"] = p_u_1914
			}
			return v_u_19.setSection(p1915, v1916)
		end,
		["getSection"] = function() -- name: getSection
			-- upvalues: (copy) p_u_1914, (ref) v_u_1306
			local v1917 = p_u_1914
			local v1918 = v1917.section
			if not v1918 then
				if v1917.mode == "raid" then
					return "both"
				end
				v1918 = v_u_1306
			end
			return v1918
		end,
		["isNarrow"] = function() -- name: isNarrow
			-- upvalues: (copy) p_u_1914
			return p_u_1914.narrow == true
		end,
		["_mount"] = p_u_1914
	}
end
function v_u_19.mount(p1920, p1921) -- name: mount
	-- upvalues: (copy) v_u_1913, (copy) v_u_1919
	local v1922
	if typeof(p1920) == "Instance" then
		v1922 = p1920:IsA("GuiObject")
	else
		v1922 = false
	end
	assert(v1922, "InventoryUI.mount: parent must be a GuiObject")
	return v_u_1919((v_u_1913(p1920, p1921)))
end
function v_u_19.unmount(p1923) -- name: unmount
	local v1924 = type(p1923) == "table" and p1923._mount or nil
	if v1924 and not v1924.dead then
		v1924.destroy()
	end
end
function v_u_19.preview(p1925, p1926, p1927) -- name: preview
	-- upvalues: (copy) v_u_1913, (copy) v_u_1919
	local v1928 = v_u_1913(p1925, p1927 or "raid", p1926)
	v1928.opened = false
	v1928.open()
	return v_u_1919(v1928)
end
function v_u_19.setSection(p1929, p1930) -- name: setSection
	-- upvalues: (copy) v_u_1304, (copy) v_u_1320, (ref) v_u_1306, (copy) v_u_136, (copy) v_u_21
	local v1931 = p1929 == "loot" and "stash" or p1929
	if type(v1931) ~= "string" or not v_u_1304[v1931] then
		return "bad section"
	end
	local v1932
	if type(p1930) == "table" then
		v1932 = p1930._mount or nil
	else
		v1932 = nil
	end
	if v1932 then
		v_u_1320(v1932, v1931)
		return v1931
	end
	v_u_1306 = v1931
	for _, v1933 in table.clone(v_u_136) do
		if v1933.mode == "raid" or v1933.dead then
			continue
		end
		v_u_1320(v1933, v1931)
	end
	if v_u_21 then
		v_u_21:SetAttribute("InvUISection", v1931)
	end
	return v1931
end
function v_u_19.getSection(p1934) -- name: getSection
	-- upvalues: (ref) v_u_1306
	local v1935 = type(p1934) == "table" and p1934._mount or nil
	local v1936
	if v1935 then
		v1936 = v1935.section
		if not v1936 then
			return v1935.mode == "raid" and "both" or v_u_1306
		end
	else
		v1936 = v_u_1306
	end
	return v1936
end
local v_u_1937 = false
local function v_u_1948(p1938) -- name: lockWorld
	-- upvalues: (ref) v_u_1937, (ref) v_u_20, (copy) v_u_21
	if v_u_1937 ~= p1938 then
		v_u_1937 = p1938
		local v1939 = v_u_20
		if v1939 then
			v1939 = v_u_20.controllers
		end
		local v1940 = v1939 and v1939.HUD or nil
		if v1940 and v1940.setVisible then
			local v1941 = v1940.setVisible
			pcall(v1941, not p1938)
		end
		local v1942 = v_u_20
		if v1942 then
			v1942 = v_u_20.controllers
		end
		local v1943 = v1942 and v1942.Prompts or nil
		if v1943 and v1943.setEnabled then
			local v1944 = v1943.setEnabled
			pcall(v1944, not p1938)
		end
		local v1945 = v_u_20
		if v1945 then
			v1945 = v_u_20.controllers
		end
		local v1946 = v1945 and v1945.Input or nil
		if v1946 and v1946.setEnabled then
			local v1947 = v1946.setEnabled
			pcall(v1947, not p1938)
		end
		if v_u_21 then
			v_u_21:SetAttribute("InvUIWorldLocked", p1938)
		end
	end
end
local function v_u_1961() -- name: ensureRaidMount
	-- upvalues: (ref) v_u_137, (copy) v_u_11, (copy) v_u_8, (ref) v_u_138, (copy) v_u_1913, (copy) v_u_1948, (copy) v_u_21, (copy) v_u_198, (ref) v_u_128, (copy) v_u_188
	if v_u_137 then
		local v1949 = v_u_137
		local v1950
		if v1949.dead or v1949.gone then
			v1950 = false
		else
			local v1951 = v1949.root
			if v1951 and v1951.Parent ~= nil then
				v1950 = (not v1949.layer or v1949.layer.gui.Parent ~= nil) and true or false
			else
				v1950 = false
			end
		end
		if v1950 then
			return v_u_137
		end
	end
	if v_u_137 then
		v_u_137.destroy()
		v_u_137 = nil
	end
	local v1952 = v_u_11.screen
	local v1953 = v_u_8.layer.inventory
	local v1954, v1955, v1956 = pcall(v1952, "HushInventory", v1953)
	if not (v1954 and v1955) then
		return nil
	end
	v_u_138 = v1955
	local v_u_1957 = v_u_1913(v1956, "raid")
	function v_u_1957.onOpen()
		-- upvalues: (ref) v_u_1948, (ref) v_u_21, (ref) v_u_198, (copy) v_u_1957
		v_u_1948(true)
		v_u_21:SetAttribute("InvUIOpen", true)
		v_u_198(v_u_1957, {
			["op"] = "nearby",
			["on"] = true
		})
	end
	function v_u_1957.onClose()
		-- upvalues: (ref) v_u_198, (copy) v_u_1957, (ref) v_u_128, (ref) v_u_188, (ref) v_u_1948, (ref) v_u_21
		v_u_198(v_u_1957, {
			["op"] = "nearby",
			["on"] = false
		})
		local v1958 = v_u_128
		if v1958 then
			local v1959 = v1958.open
			if type(v1959) == "table" then
				for _, v1960 in v1958.open do
					if v1960 == "ground" then
						continue
					end
					v_u_198(v_u_1957, {
						["op"] = "close",
						["container"] = nil,
						["container"] = v1960
					})
				end
			end
		end
		v_u_198(v_u_1957, {
			["op"] = "close"
		})
		v_u_188.closedAt = os.clock()
		v_u_1948(false)
		v_u_21:SetAttribute("InvUIOpen", false)
	end
	v_u_137 = v_u_1957
	return v_u_1957
end
local function v_u_1963() -- name: canOpenRaid
	-- upvalues: (copy) v_u_21
	if v_u_21:GetAttribute("Place") ~= "Raid" or v_u_21:GetAttribute("HuntPlayer") == true then
		return false
	end
	local v1962 = v_u_21.Character
	return (not v1962 or v1962:GetAttribute("Dead") ~= true and v1962:GetAttribute("Downed") ~= true) and true or false
end
function v_u_19.open() -- name: open
	-- upvalues: (copy) v_u_1963, (copy) v_u_1961
	if v_u_1963() then
		local v1964 = v_u_1961()
		if v1964 then
			v1964.open()
		end
	end
end
function v_u_19.close() -- name: close
	-- upvalues: (ref) v_u_137
	if v_u_137 then
		v_u_137.close()
	end
end
function v_u_19.toggle() -- name: toggle
	-- upvalues: (ref) v_u_137, (copy) v_u_19
	if v_u_137 and v_u_137.opened then
		v_u_19.close()
	else
		v_u_19.open()
	end
end
function v_u_19.closeTopLayer(p1965) -- name: closeTopLayer
	-- upvalues: (ref) v_u_149, (ref) v_u_154, (ref) v_u_159, (ref) v_u_157, (copy) v_u_188, (copy) v_u_1010, (copy) v_u_164, (ref) v_u_156, (copy) v_u_21, (copy) v_u_147, (copy) v_u_11, (copy) v_u_136, (copy) v_u_198
	if p1965 == nil or p1965.visibleOnly ~= true then
		local v1966 = v_u_149 ~= nil and true or (v_u_154 ~= nil and true or (v_u_159 ~= nil and true or (v_u_157 ~= nil and true or v_u_188.Case.closeTop())))
		if v_u_149 then
			v_u_1010(v_u_149.pos, true)
		end
		if v_u_157 then
			v_u_157:Destroy()
			v_u_157 = nil
		end
		v_u_164()
		local v1967 = v_u_159
		if not v1967 then
			return v1966
		end
		v_u_159 = nil
		if v1967.mark then
			v1967.mark:Destroy()
		end
		if not v_u_149 and v_u_156 then
			v_u_156:Destroy()
			v_u_156 = nil
		end
		if v_u_21 then
			v_u_21:SetAttribute("InvUISelected", nil)
		end
		return v1966
	else
		v_u_147()
		local v1968
		if v_u_159 then
			local v1969 = v_u_159.m
			v1968 = v1969 ~= nil and not v1969.dead
			if v1968 then
				if v1969.dead or v1969.gone then
					v1968 = false
				else
					local v1970 = v1969.root
					if v1970 and v1970.Parent ~= nil then
						v1968 = (not v1969.layer or v1969.layer.gui.Parent ~= nil) and true or false
					else
						v1968 = false
					end
				end
				if v1968 then
					v1968 = v1969.isShown()
				end
			end
		else
			v1968 = false
		end
		local v_u_1971 = false
		local function v1973()
			-- upvalues: (ref) v_u_1971, (ref) v_u_11
			local v1972
			if v_u_11.modalCount == nil then
				v1972 = false
			else
				v1972 = v_u_11.modalCount() > 0
			end
			v_u_1971 = v1972
		end
		pcall(v1973)
		local v1974 = v_u_1971
		local v1975 = {}
		local v1976 = nil
		for v1977, v_u_1978 in v_u_136 do
			local v_u_1979 = false
			local function v1980()
				-- upvalues: (ref) v_u_1979, (copy) v_u_1978
				v_u_1979 = v_u_1978.isShown()
			end
			pcall(v1980)
			v1975[v1977] = {
				["work"] = v_u_1978.work,
				["shown"] = v_u_1979,
				["raid"] = v_u_1978.mode == "raid",
				["dead"] = v_u_1978.dead == true
			}
			if v_u_1978 ~= v_u_188.lastCaseMount then
				continue
			end
			v1976 = v1977
		end
		local v1981 = v_u_188.Layers.decide
		local v1982 = {
			["drag"] = v_u_149 ~= nil
		}
		local v1983
		if v_u_154 == nil then
			v1983 = false
		else
			v1983 = v_u_154.Parent ~= nil
		end
		v1982.ctx = v1983
		local v1984
		if v_u_157 == nil then
			v1984 = false
		else
			v1984 = v_u_157.Parent ~= nil
		end
		v1982.inspect = v1984
		v1982.sel = v_u_159 ~= nil
		v1982.selShown = v1968
		v1982.modal = v1974
		v1982.mounts = v1975
		v1982.last = v1976
		local v1985 = v1981(v1982)
		v_u_188.lastLayer = v1985.layer
		if v_u_149 then
			v_u_1010(v_u_149.pos, true)
		end
		if v_u_157 then
			v_u_157:Destroy()
			v_u_157 = nil
		end
		v_u_164()
		local v1986 = v_u_159
		if v1986 then
			v_u_159 = nil
			if v1986.mark then
				v1986.mark:Destroy()
			end
			if not v_u_149 and v_u_156 then
				v_u_156:Destroy()
				v_u_156 = nil
			end
			if v_u_21 then
				v_u_21:SetAttribute("InvUISelected", nil)
			end
		end
		if v1985.layer == "drag" or (v1985.layer == "context" or (v1985.layer == "inspect" or (v1985.layer == "selection" or v1985.layer == "modal"))) then
			return true
		else
			for _, v1987 in v1985.stale do
				local v1988 = v_u_136[v1987.mount]
				local v1989
				if v1988 and v1988.work then
					v1989 = v1988.work.cases
				else
					v1989 = nil
				end
				local v1990
				if type(v1989) == "table" then
					v1990 = table.find(v1989, v1987.uid)
				else
					v1990 = nil
				end
				if not v1990 then
					continue
				end
				table.remove(v1989, v1990)
				local v1991 = v1987.uid
				if type(v1991) ~= "string" then
					continue
				end
				local v1992 = v_u_198
				local v1993 = {
					["op"] = "closeCase",
					["uid"] = nil,
					["uid"] = v1987.uid
				}
				pcall(v1992, v1988, v1993)
			end
			if v1985.target == nil then
				return false
			else
				return v_u_188.Case.closeTopOf(v_u_136[v1985.target]) == true
			end
		end
	end
end
function v_u_19.lastLayer() -- name: lastLayer
	-- upvalues: (copy) v_u_188
	return v_u_188.lastLayer
end
function v_u_19.isOpen() -- name: isOpen
	-- upvalues: (copy) v_u_147, (copy) v_u_136
	v_u_147()
	for _, v1994 in v_u_136 do
		if not v1994.isShown() then
			continue
		end
		return true
	end
	return false
end
function v_u_19.isDragging() -- name: isDragging
	-- upvalues: (ref) v_u_149
	return v_u_149 ~= nil
end
local v_u_1995 = {
	0,
	0,
	0,
	0
}
function v_u_19.useQuick(p1996) -- name: useQuick
	-- upvalues: (copy) v_u_21, (ref) v_u_137, (copy) v_u_1995, (ref) v_u_128, (copy) v_u_11, (ref) v_u_20, (copy) v_u_175, (copy) v_u_188, (copy) v_u_9
	local v1997 = tonumber(p1996) or 0
	local v1998 = math.floor(v1997)
	if v1998 < 1 or v1998 > 4 then
		return "bad slot"
	end
	if v_u_21:GetAttribute("Place") ~= "Raid" then
		return "not in raid"
	end
	if v_u_137 and v_u_137.opened then
		return "inventory open"
	end
	local v1999 = v_u_21.Character
	if not v1999 or (v1999:GetAttribute("Dead") == true or v1999:GetAttribute("Downed") == true) then
		return "no character"
	end
	local v2000 = os.clock()
	if v2000 - v_u_1995[v1998] < 0.25 then
		return "debounced"
	end
	v_u_1995[v1998] = v2000
	if v_u_128 then
		local v2001 = v_u_128
		local v2002
		if type(v2001) == "table" then
			v2002 = v2001.kit or nil
		else
			v2002 = nil
		end
		local v2003
		if v2002 then
			local v2004 = v2002.quick
			v2003 = type(v2004) == "table" and v2004[v1998] or v2002["quick" .. v1998]
			if type(v2003) ~= "string" or v2003 == "" then
				v2003 = nil
			end
		else
			v2003 = nil
		end
		if not v2003 then
			local v2005 = v_u_11.toast
			pcall(v2005, "Nothing on that quick slot", "info")
			return "empty"
		end
	end
	if v_u_20 then
		local v2006 = v_u_20.net.fire
		pcall(v2006, "inv.op", {
			["op"] = "usequick",
			["index"] = nil,
			["index"] = v1998
		})
		local v2007 = v_u_128
		if v2007 then
			local v2008 = v_u_175
			local v2009 = v_u_128
			local v2010 = v_u_128
			local v2011
			if type(v2010) == "table" then
				v2011 = v2010.kit or nil
			else
				v2011 = nil
			end
			local v2012
			if v2011 then
				local v2013 = v2011.quick
				v2012 = type(v2013) == "table" and v2013[v1998] or v2011["quick" .. v1998]
				if type(v2012) ~= "string" or v2012 == "" then
					v2012 = nil
				end
			else
				v2012 = nil
			end
			v2007 = v2008(v2009, v2012 or "")
		end
		local v2014 = v_u_188.Pred.useFeedback
		if v2007 then
			v2007 = v_u_9.get(v2007.item.id)
		end
		v2014(v2007)
	end
	return "sent"
end
function v_u_19.nextAmmo(p2015) -- name: nextAmmo
	-- upvalues: (copy) v_u_16, (ref) v_u_128
	return v_u_16.nextChoice(v_u_128, p2015)
end
function v_u_19.loadAmmo(p2016, p2017) -- name: loadAmmo
	-- upvalues: (copy) v_u_16, (ref) v_u_20
	local v2018 = v_u_16.load
	local v2019 = v_u_20
	if v2019 then
		v2019 = v_u_20.net
	end
	return v2018(v2019, p2016, p2017)
end
local function v_u_2040(p2020) -- name: onRaidState
	-- upvalues: (ref) v_u_128, (copy) v_u_188, (copy) v_u_147, (copy) v_u_136, (copy) v_u_21, (copy) v_u_52, (ref) v_u_135, (copy) v_u_1963, (ref) v_u_137, (copy) v_u_198, (copy) v_u_19
	if type(p2020) == "table" then
		local v2021 = {}
		if v_u_128 then
			local v2022 = v_u_128.open
			if type(v2022) == "table" then
				for _, v2023 in v_u_128.open do
					v2021[v2023] = true
				end
			end
		end
		v_u_128 = p2020
		v_u_188.Pred.ack(p2020.ack)
		local v2024 = false
		for _, v2025 in p2020.open or {} do
			local v2026 = p2020.containers
			if v2026 then
				v2026 = p2020.containers[v2025]
			end
			local v2027
			if type(v2026) == "table" then
				v2027 = v2026.near == true
			else
				v2027 = false
			end
			if v2021[v2025] or (v2025 == "ground" or v2027) then
				continue
			end
			v2024 = true
		end
		v_u_147()
		for _, v2028 in table.clone(v_u_136) do
			if v2028.mode ~= "raid" or (v2028.fake or v2028.dead) then
				continue
			end
			if v2028.opened then
				local v2029 = v2028.setState
				local v2030, v2031 = pcall(v2029, p2020)
				if v2030 then
					continue
				end
				warn("[InventoryUI] raid render failed:", v2031)
				v_u_21:SetAttribute("ClientError", "InventoryUI raid render: " .. tostring(v2031))
			else
				local v2032 = v_u_52
				local v2033
				if v2028.fake then
					v2033 = v2028.fake
				elseif v2028.mode == "raid" then
					v2033 = v_u_128
				else
					v2033 = v_u_135
				end
				v2028.work = v2032(v2033)
				if v2028.fake or not v2028.work then
					continue
				end
				v_u_188.Pred.replay(v2028.mode, v2028.work)
			end
		end
		if v2024 and v_u_1963() then
			if v_u_137 and (not v_u_137.opened and os.clock() - (v_u_188.closedAt or -99) < 2.5) then
				for _, v2034 in p2020.open or {} do
					if v2021[v2034] or v2034 == "ground" then
						continue
					end
					v_u_198(v_u_137, {
						["op"] = "close",
						["container"] = nil,
						["container"] = v2034
					})
				end
			else
				v_u_19.open()
			end
		end
		local v2035 = v_u_21
		local v2036 = 0
		local v2037 = "InvUIItems"
		for _, v2038 in p2020.containers or {} do
			if type(v2038) ~= "table" then
				continue
			end
			local v2039 = v2038.items
			if type(v2039) ~= "table" then
				continue
			end
			v2036 = v2036 + #v2038.items
		end
		v2035:SetAttribute(v2037, v2036)
	end
end
local function v_u_2046(p2041) -- name: onMenuInv
	-- upvalues: (ref) v_u_135, (copy) v_u_147, (copy) v_u_136, (copy) v_u_21
	if type(p2041) == "table" then
		v_u_135 = p2041
		v_u_147()
		for _, v2042 in table.clone(v_u_136) do
			if v2042.mode == "raid" or (v2042.fake or v2042.dead) then
				continue
			end
			local v2043 = v2042.setState
			local v2044, v2045 = pcall(v2043, p2041)
			if v2044 then
				continue
			end
			warn("[InventoryUI] menu render failed:", v2045)
			v_u_21:SetAttribute("ClientError", "InventoryUI menu render: " .. tostring(v2045))
		end
	end
end
v_u_133 = function()
	-- upvalues: (ref) v_u_131, (copy) v_u_21, (ref) v_u_129, (copy) v_u_130, (copy) v_u_132, (copy) v_u_13, (ref) v_u_134, (ref) v_u_157, (copy) v_u_136
	local v2047 = v_u_131 or v_u_21:GetAttribute("Wishlist")
	local v2048 = {}
	if type(v2047) == "string" then
		for _, v2049 in string.split(v2047, ",") do
			local v2050 = string.gsub(v2049, "%s", "")
			if v2050 == "" then
				continue
			end
			v2048[v2050] = true
		end
	end
	v_u_129 = v2048
	local v2051 = {}
	local v2052 = v_u_21:GetAttribute("TaskItems")
	if type(v2052) == "string" then
		for _, v2053 in string.split(v2052, ",") do
			local v2054 = string.gsub(v2053, "%s", "")
			if v2054 == "" then
				continue
			end
			v2051[v2054] = true
		end
	end
	v_u_130.task = v2051
	local v2055 = table.clone(v2048)
	local v2056 = os.clock()
	local v2057 = {}
	for v2058, v2059 in v_u_132 do
		if v2048[v2058] == true == v2059.on or v2056 - v2059.t >= 4 then
			table.insert(v2057, v2058)
		else
			v2055[v2058] = v2059.on and true or nil
		end
	end
	for _, v2060 in v2057 do
		v_u_132[v2060] = nil
	end
	for v2061 in v2051 do
		v2055[v2061] = true
	end
	local v2062 = table.clone(v2048)
	for v2063 in v2051 do
		v2062[v2063] = true
	end
	v_u_130.glow = v2062
	local v2064 = v_u_13.setWishlist
	pcall(v2064, v2055)
	if v_u_134 and v_u_157 then
		local v2065 = v_u_134
		pcall(v2065)
	end
	for _, v2066 in v_u_136 do
		for _, v2067 in v2066.tiles do
			if not (v2067.alive() and v2067.inst) then
				continue
			end
			local v2068 = v2067.set
			local v2069 = v2067.inst
			local v2070 = v2066.cell
			pcall(v2068, v2069, v2070)
		end
	end
end
function v_u_19.init(p2071) -- name: init
	-- upvalues: (ref) v_u_20, (copy) v_u_11, (copy) v_u_188
	v_u_20 = p2071
	local v2072 = v_u_11.bind
	pcall(v2072, p2071)
	v_u_188.Gun.bind(function()
		-- upvalues: (ref) v_u_20
		local v2073 = v_u_20.controllers.Menu
		if v2073 then
			local v2074 = v2073.gunsmithKnow
			if type(v2074) == "function" then
				return v2073.gunsmithKnow()
			end
		end
		return nil
	end)
	v_u_188.XDbg.install(p2071, v_u_188.E)
end
function v_u_19.start() -- name: start
	-- upvalues: (copy) v_u_1102, (copy) v_u_188, (copy) v_u_19, (ref) v_u_137, (copy) v_u_21, (ref) v_u_133, (copy) v_u_15, (ref) v_u_20, (copy) v_u_2040, (copy) v_u_136, (ref) v_u_128, (ref) v_u_135, (copy) v_u_11, (copy) v_u_2046, (ref) v_u_149, (copy) v_u_646, (ref) v_u_647, (copy) v_u_2, (copy) v_u_8, (ref) v_u_179, (copy) v_u_1010, (copy) v_u_164, (ref) v_u_159, (ref) v_u_156, (ref) v_u_157, (copy) v_u_147, (ref) v_u_138, (copy) v_u_1948
	v_u_1102()
	v_u_188.TutPick.bind({
		["isOpen"] = v_u_19.isOpen,
		["lootRect"] = function() -- name: lootRect
			-- upvalues: (ref) v_u_137
			local v2075
			if v_u_137 then
				v2075 = v_u_137.rightScroll
			else
				v2075 = nil
			end
			if v2075 and v2075.Parent then
				return v2075.AbsolutePosition, v2075.AbsoluteSize
			else
				return nil, nil
			end
		end
	})
	v_u_21:GetAttributeChangedSignal("Wishlist"):Connect(v_u_133)
	v_u_21:GetAttributeChangedSignal("TaskItems"):Connect(v_u_133)
	v_u_133()
	v_u_21:GetAttributeChangedSignal("Place"):Connect(function()
		-- upvalues: (ref) v_u_15
		local v2076 = v_u_15.clear
		pcall(v2076)
	end)
	local v_u_2077 = v_u_20.net
	task.spawn(function()
		-- upvalues: (copy) v_u_2077, (ref) v_u_2040, (ref) v_u_188, (ref) v_u_136, (ref) v_u_128, (ref) v_u_135
		local function v2082()
			-- upvalues: (ref) v_u_2077, (ref) v_u_2040, (ref) v_u_188, (ref) v_u_136, (ref) v_u_128, (ref) v_u_135
			v_u_2077.listen("inv.state", v_u_2040)
			function v_u_188.Pred.onExpire(p2078)
				-- upvalues: (ref) v_u_136, (ref) v_u_128, (ref) v_u_135
				for _, v2079 in table.clone(v_u_136) do
					if v2079.mode == "raid" ~= (p2078 == "raid") or (v2079.fake or (v2079.dead or not v2079.opened)) then
						continue
					end
					local v2080 = v2079.setState
					local v2081
					if v2079.fake then
						v2081 = v2079.fake
					elseif v2079.mode == "raid" then
						v2081 = v_u_128
					else
						v2081 = v_u_135
					end
					pcall(v2080, v2081)
				end
			end
		end
		local v2083, v2084 = pcall(v2082)
		if not v2083 then
			warn("[InventoryUI] inv.state:", v2084)
		end
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_2077, (ref) v_u_188, (ref) v_u_21, (ref) v_u_11, (ref) v_u_128, (ref) v_u_136
		local function v2098()
			-- upvalues: (ref) v_u_2077, (ref) v_u_188, (ref) v_u_21, (ref) v_u_11, (ref) v_u_128, (ref) v_u_136
			local v_u_2085 = ""
			local v_u_2086 = -10
			v_u_2077.listen("inv.msg", function(p2087)
				-- upvalues: (ref) v_u_188, (ref) v_u_21, (ref) v_u_2085, (ref) v_u_2086, (ref) v_u_11, (ref) v_u_128, (ref) v_u_136
				if type(p2087) == "table" then
					local v2088 = p2087.text
					if type(v2088) == "string" and p2087.text ~= "" then
						if v_u_188.Why.msgPlaceOk(v_u_21:GetAttribute("Place")) then
							local v2089 = os.clock()
							if p2087.text ~= v_u_2085 or v2089 - v_u_2086 >= 1 then
								v_u_2085 = p2087.text
								v_u_2086 = v2089
								local v2090 = p2087.kind == "error" and "danger" or p2087.kind
								local v2091 = v2090 ~= "info" and (v2090 ~= "warn" and (v2090 ~= "danger" and v2090 ~= "success")) and "warn" or v2090
								local v2092 = p2087.text
								local v2093 = string.sub(v2092, 1, 120)
								local v2094 = v_u_11.toast
								pcall(v2094, v2093, v2091 or "warn")
								v_u_21:SetAttribute("InvUILastMsg", p2087.text)
								if v2091 ~= "info" and (v2091 ~= "success" and v_u_128) then
									v_u_188.Pred.cancelUse()
									for _, v2095 in table.clone(v_u_136) do
										if v2095.mode ~= "raid" or (v2095.fake or (v2095.dead or not v2095.opened)) then
											continue
										end
										local v2096 = v2095.setState
										local v2097 = v_u_128
										pcall(v2096, v2097)
									end
								end
							end
						else
							return
						end
					end
				end
			end)
		end
		pcall(v2098)
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_2077, (ref) v_u_188, (ref) v_u_135, (ref) v_u_2046, (ref) v_u_21
		local function v2104()
			-- upvalues: (ref) v_u_2077, (ref) v_u_188, (ref) v_u_135, (ref) v_u_2046, (ref) v_u_21
			v_u_2077.listen("menu.result", function(p2099)
				-- upvalues: (ref) v_u_188, (ref) v_u_135, (ref) v_u_2046, (ref) v_u_21
				if type(p2099) == "table" then
					local v2100 = p2099.req
					if type(v2100) == "string" then
						v_u_188.Pred.menuResult(p2099.req, p2099.ok ~= false)
					end
				end
				if type(p2099) == "table" and p2099.ok == false then
					local v2101 = p2099.req
					if type(v2101) == "string" then
						local v2102 = p2099.req
						if string.sub(v2102, 1, 6) == "invui_" and v_u_135 then
							v_u_2046(v_u_135)
							local v2103 = v_u_21
							v_u_21:SetAttribute("InvUIRollback", (tonumber(v2103:GetAttribute("InvUIRollback")) or 0) + 1)
						end
					end
				end
			end)
		end
		pcall(v2104)
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_2077, (ref) v_u_188, (ref) v_u_2046
		local function v2107()
			-- upvalues: (ref) v_u_2077, (ref) v_u_188, (ref) v_u_2046
			v_u_2077.listen("menu.state", function(p2105)
				-- upvalues: (ref) v_u_188, (ref) v_u_2046
				if type(p2105) == "table" then
					local v2106 = p2105.profile
					if type(v2106) == "table" then
						v_u_188.Pred.menuState()
						v_u_188.Plus.setPasses(p2105.profile.passes)
						v_u_2046(p2105.profile.inv)
					end
				end
			end)
		end
		pcall(v2107)
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_2077, (ref) v_u_188, (ref) v_u_135, (ref) v_u_2046
		local v2108 = v_u_2077.invoke
		local v2109, v2110 = pcall(v2108, "menu.get", {
			["what"] = "profile"
		})
		if v2109 and type(v2110) == "table" then
			v_u_188.Plus.setPasses(v2110.passes)
		end
		if v2109 and type(v2110) == "table" then
			local v2111 = v2110.inv
			if type(v2111) == "table" and v_u_135 == nil then
				v_u_2046(v2110.inv)
			end
		end
	end)
	local v2112 = v_u_20
	if v2112 then
		v2112 = v_u_20.controllers
	end
	local v_u_2113 = v2112 and v2112.Input or nil
	if v_u_2113 and v_u_2113.bind then
		v_u_2113.bind("inventory", function()
			-- upvalues: (ref) v_u_21, (ref) v_u_19
			if v_u_21:GetAttribute("Place") == "Raid" then
				v_u_19.toggle()
			end
		end)
		v_u_2113.bind("rotateItem", function()
			-- upvalues: (ref) v_u_149, (ref) v_u_646, (ref) v_u_11, (ref) v_u_647
			if v_u_149 then
				if not v_u_149 then
					return
				end
				v_u_149.r = not v_u_149.r
				v_u_646(v_u_149)
				local v2114 = v_u_11.sound
				pcall(v2114, "tick")
				v_u_647(v_u_149.pos)
			end
		end)
		v_u_2113.bind("menu", function()
			-- upvalues: (ref) v_u_137, (ref) v_u_19
			if v_u_137 and v_u_137.opened then
				v_u_19.close()
			end
		end)
		for v_u_2115 = 1, 4 do
			v_u_2113.bind("quick" .. v_u_2115, function()
				-- upvalues: (ref) v_u_21, (ref) v_u_19, (copy) v_u_2115
				if v_u_21:GetAttribute("HudMounted") ~= true then
					v_u_19.useQuick(v_u_2115)
				end
			end)
		end
	else
		v_u_2.InputBegan:Connect(function(p2116, p2117)
			-- upvalues: (ref) v_u_21, (ref) v_u_19, (ref) v_u_149, (ref) v_u_646, (ref) v_u_11, (ref) v_u_647
			if p2117 then
				return
			elseif p2116.KeyCode == Enum.KeyCode.Tab and v_u_21:GetAttribute("Place") == "Raid" then
				v_u_19.toggle()
			elseif p2116.KeyCode == Enum.KeyCode.R and v_u_149 then
				if not v_u_149 then
					return
				end
				v_u_149.r = not v_u_149.r
				v_u_646(v_u_149)
				local v2118 = v_u_11.sound
				pcall(v2118, "tick")
				v_u_647(v_u_149.pos)
			end
		end)
	end
	if v_u_2113 and (v_u_2113.deviceChanged and v_u_2113.deviceChanged.Connect) then
		local function v2124()
			-- upvalues: (copy) v_u_2113, (ref) v_u_136, (ref) v_u_8, (ref) v_u_149, (ref) v_u_179
			v_u_2113.deviceChanged:Connect(function()
				-- upvalues: (ref) v_u_136, (ref) v_u_8, (ref) v_u_149, (ref) v_u_179
				task.defer(function()
					-- upvalues: (ref) v_u_136, (ref) v_u_8, (ref) v_u_149, (ref) v_u_179
					for _, v2119 in table.clone(v_u_136) do
						if not v2119.body then
							continue
						end
						if v2119.opened then
							local v2120 = v_u_8.devViewport
							local v2121, v2122 = pcall(v2120)
							if v2121 then
								v2121 = v2122 ~= nil
							end
							if (v2121 or v2119.root.AbsoluteSize.X > 10) and (not v_u_149 or v_u_149.m ~= v2119) then
								local v2123 = v_u_179
								pcall(v2123, v2119)
							else
								v2119.dw = -1
							end
						else
							v2119.dw = -1
						end
					end
				end)
			end)
		end
		pcall(v2124)
	end
	local function v_u_2130() -- name: rebuildAll
		-- upvalues: (ref) v_u_149, (ref) v_u_1010, (ref) v_u_164, (ref) v_u_159, (ref) v_u_156, (ref) v_u_21, (ref) v_u_157, (ref) v_u_147, (ref) v_u_136, (ref) v_u_179
		if v_u_149 then
			v_u_1010(v_u_149.pos, true)
		end
		v_u_164()
		local v2125 = v_u_159
		if v2125 then
			v_u_159 = nil
			if v2125.mark then
				v2125.mark:Destroy()
			end
			if not v_u_149 and v_u_156 then
				v_u_156:Destroy()
				v_u_156 = nil
			end
			if v_u_21 then
				v_u_21:SetAttribute("InvUISelected", nil)
			end
		end
		if v_u_156 then
			v_u_156:Destroy()
			v_u_156 = nil
		end
		if v_u_157 then
			v_u_157:Destroy()
			v_u_157 = nil
		end
		v_u_147()
		for _, v2126 in table.clone(v_u_136) do
			if not v2126.body or v2126.dead then
				continue
			end
			if v2126.opened then
				local v2127 = v_u_179
				local v2128, v2129 = pcall(v2127, v2126)
				if v2128 then
					continue
				end
				warn("[InventoryUI] rebuild failed:", v2129)
			else
				v2126.dw = -1
			end
		end
	end
	local v2131 = v_u_188.Zoom.start
	local v2132 = v_u_188.E
	local v2133 = v_u_20
	pcall(v2131, v2132, v2133, v_u_2130)
	if v_u_20.on then
		local v2134 = v_u_20.on
		pcall(v2134, "ui.rebuild", function()
			-- upvalues: (copy) v_u_2130
			task.defer(v_u_2130)
		end)
	end
	local v2135 = v_u_20.session
	if v2135 and v2135.onPlaceChanged then
		local v2136 = v2135.onPlaceChanged
		local function v2138(p2137, _)
			-- upvalues: (ref) v_u_137, (ref) v_u_138, (ref) v_u_1948, (ref) v_u_128
			if p2137 ~= "Raid" then
				if v_u_137 then
					v_u_137.close()
					v_u_137.destroy()
					v_u_137 = nil
				end
				if v_u_138 then
					v_u_138:Destroy()
					v_u_138 = nil
				end
				v_u_1948(false)
				if p2137 ~= "Transit" then
					v_u_128 = nil
				end
			end
		end
		pcall(v2136, v2138)
	else
		v_u_21:GetAttributeChangedSignal("Place"):Connect(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_137, (ref) v_u_138, (ref) v_u_1948, (ref) v_u_128
			local v2139 = v_u_21:GetAttribute("Place")
			if v2139 ~= "Raid" then
				if v_u_137 then
					v_u_137.close()
					v_u_137.destroy()
					v_u_137 = nil
				end
				if v_u_138 then
					v_u_138:Destroy()
					v_u_138 = nil
				end
				v_u_1948(false)
				if v2139 ~= "Transit" then
					v_u_128 = nil
				end
			end
		end)
	end
	v_u_21:SetAttribute("InvUIOpen", false)
end
local v_u_2140 = 0
local function v_u_2154() -- name: stepSelection
	-- upvalues: (ref) v_u_159, (copy) v_u_175, (ref) v_u_149, (ref) v_u_156, (copy) v_u_21, (copy) v_u_790, (copy) v_u_60, (copy) v_u_18, (copy) v_u_656, (ref) v_u_2140, (copy) v_u_781, (ref) v_u_157
	local v2141 = v_u_159
	if v2141 then
		local v2142 = v2141.m
		if v2142.dead or not (v2142.isShown() and v_u_175(v2142.work, v2141.uid)) then
			local v2143 = v_u_159
			if v2143 then
				v_u_159 = nil
				if v2143.mark then
					v2143.mark:Destroy()
				end
				if not v_u_149 and v_u_156 then
					v_u_156:Destroy()
					v_u_156 = nil
				end
				if v_u_21 then
					v_u_21:SetAttribute("InvUISelected", nil)
				end
			end
		elseif v_u_149 and v_u_149.uid == v2141.uid then
			return
		else
			local v2144 = v_u_790(v2142, v2141.uid)
			if v2144 then
				if not v2141.mark or v2141.mark.Parent ~= v2144 then
					if v2141.mark then
						v2141.mark:Destroy()
					end
					local v2145 = {
						["Name"] = "SelMark",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["ZIndex"] = 30,
						["Size"] = UDim2.fromScale(1, 1)
					}
					local v2146 = Instance.new("Frame")
					if v2145 then
						for v2147, v2148 in v2145 do
							v2146[v2147] = v2148
						end
					end
					if v2144 then
						v2146.Parent = v2144
					end
					v_u_60(v2146, v_u_18.accent).Thickness = 2
					v2141.mark = v2146
				end
				v2141.mark.Visible = true
				local v2149 = v_u_656(v2144)
				local v2150 = string.format("%d,%d,%d,%d", v2149[1], v2149[2], v2149[3], v2149[4])
				local v2151 = os.clock()
				local v2152 = v_u_156
				if v2152 then
					v2152 = v_u_156.Parent
				end
				if v2141.dirty or (not v2152 or v2150 ~= v2141.rectKey and v2151 - v_u_2140 > 0.08) then
					v2141.dirty = false
					v2141.rectKey = v2150
					v_u_2140 = v2151
					v_u_781(v2142, v2141.uid, false, v2149, nil)
				end
				if v_u_156 then
					local v2153 = v_u_157 == nil
					if v_u_156.Visible ~= v2153 then
						v_u_156.Visible = v2153
					end
				end
			end
		end
	else
		return
	end
end
local v_u_2155 = {
	["bag"] = "Swap bag",
	["armor"] = "Swap vest"
}
local v_u_2156 = 0
local function v_u_2168(p2157, p2158, p2159, p2160) -- name: fitsKit
	-- upvalues: (copy) v_u_10
	local v2161 = p2159.equip
	local v2162
	if type(p2157) == "table" then
		v2162 = p2157.kit or nil
	else
		v2162 = nil
	end
	local v2163
	if v2162 then
		v2163 = v2162.slots
		if v2163 then
			v2163 = v2162.slots[v2161]
		end
		if v2163 == nil then
			v2163 = v2162[v2161]
		end
		if type(v2163) ~= "table" then
			v2163 = nil
		end
	else
		v2163 = nil
	end
	if not v2163 then
		return true
	end
	if p2158:GetAttribute("Filled") == true then
		return false
	end
	local v2164 = {
		["uid"] = "",
		["id"] = nil,
		["x"] = 0,
		["y"] = 0,
		["r"] = false,
		["n"] = 1,
		["id"] = p2160
	}
	for _, v2165 in { "pockets", "vest", "bag" } do
		local v2166 = p2157.containers
		if v2166 then
			v2166 = p2157.containers[v2165]
		end
		if type(v2166) ~= "table" then
			continue
		end
		local v2167 = v2166.items
		if type(v2167) ~= "table" or v_u_10.findSpot(v2166, v2164) == nil then
			continue
		end
		return true
	end
	return false
end
local function v_u_2177() -- name: updateSwapPrompts
	-- upvalues: (ref) v_u_128, (copy) v_u_21, (copy) v_u_5, (copy) v_u_9, (copy) v_u_2155, (copy) v_u_2168
	local v2169 = v_u_128
	local v2170 = v_u_21.Character
	if v2170 then
		v2170 = v2170:FindFirstChild("HumanoidRootPart")
	end
	if type(v2169) == "table" and (v2170 and v_u_21:GetAttribute("Place") == "Raid") then
		for _, v2171 in v_u_5:GetTagged("HushItem") do
			local v2172 = v2171:GetAttribute("ItemId")
			local v2173
			if type(v2172) == "string" then
				v2173 = v_u_9.get(v2172) or nil
			else
				v2173 = nil
			end
			local v2174
			if v2173 then
				v2174 = v_u_2155[v2173.equip or ""]
			else
				v2174 = v2173
			end
			if not (v2174 and (v2171:IsA("Model") and v2171.Parent)) then
				continue
			end
			local v2175 = v2171:FindFirstChild("HushPrompt", true)
			if not v2175 or (not v2175:IsA("ProximityPrompt") or (v2171:GetPivot().Position - v2170.Position).Magnitude >= 24) then
				continue
			end
			local v2176 = v_u_2168(v2169, v2171, v2173, v2172) and "Pick up" or (v2171:GetAttribute("Filled") == true and "Open" or v2174)
			if v2175.ActionText == v2176 then
				continue
			end
			v2175.ActionText = v2176
		end
	end
end
function v_u_19.step(p2178) -- name: step
	-- upvalues: (copy) v_u_147, (ref) v_u_149, (copy) v_u_188, (copy) v_u_1010, (copy) v_u_15, (copy) v_u_130, (ref) v_u_2156, (copy) v_u_2177, (ref) v_u_647, (ref) v_u_180, (copy) v_u_1305, (ref) v_u_1306, (copy) v_u_1320, (copy) v_u_2154, (copy) v_u_136, (copy) v_u_1848, (ref) v_u_22, (copy) v_u_1516, (ref) v_u_137, (copy) v_u_21, (copy) v_u_19, (ref) v_u_1937, (copy) v_u_1948
	v_u_147()
	if v_u_149 then
		v_u_188.TD.guard(v_u_149, os.clock(), v_u_1010)
	end
	local v2179 = v_u_15.step
	local v2180 = v_u_130.glow
	pcall(v2179, p2178, v2180)
	v_u_2156 = v_u_2156 + p2178
	if v_u_2156 >= 0.3 then
		v_u_2156 = 0
		local v2181 = v_u_2177
		pcall(v2181)
	end
	local v_u_2182
	if v_u_149 and v_u_149.parked then
		v_u_2182 = nil
	else
		v_u_2182 = v_u_149
	end
	if v_u_2182 and not v_u_2182.touch then
		for _, v2183 in v_u_2182.m.scrollers or {} do
			if not v2183.Parent then
				continue
			end
			local v2184 = v_u_2182.pos
			local v2185 = v2183.AbsolutePosition
			local v2186 = v2183.AbsoluteSize
			local v2187
			if v2184.X >= v2185.X and (v2184.Y >= v2185.Y and v2184.X < v2185.X + v2186.X) then
				v2187 = v2184.Y < v2185.Y + v2186.Y
			else
				v2187 = false
			end
			if not v2187 then
				continue
			end
			local v2188 = v2183.AbsolutePosition
			local v2189 = v2183.AbsoluteSize
			local v2190 = v_u_2182.pos.Y < v2188.Y + 48 and -1 or (v_u_2182.pos.Y > v2188.Y + v2189.Y - 48 and 1 or 0)
			if v2190 ~= 0 then
				local v2191 = v2183.AbsoluteCanvasSize.Y - v2189.Y
				local v2192 = math.max(0, v2191)
				local v2193 = v2183.CanvasPosition.Y + v2190 * 620 * p2178
				local v2194 = math.clamp(v2193, 0, v2192)
				if v2194 ~= v2183.CanvasPosition.Y then
					v2183.CanvasPosition = Vector2.new(v2183.CanvasPosition.X, v2194)
					v_u_647(v_u_2182.pos)
				end
			end
			if v2183.ScrollingDirection == Enum.ScrollingDirection.Y then
				continue
			end
			local v2195 = v_u_2182.pos.X < v2188.X + 48 and -1 or (v_u_2182.pos.X > v2188.X + v2189.X - 48 and 1 or 0)
			local v2196 = v2183.AbsoluteCanvasSize.X - v2189.X
			local v2197 = math.max(0, v2196)
			local v2198 = v2183.CanvasPosition.X + v2195 * 620 * p2178
			local v2199 = math.clamp(v2198, 0, v2197)
			if v2195 == 0 or v2199 == v2183.CanvasPosition.X then
				continue
			end
			v2183.CanvasPosition = Vector2.new(v2199, v2183.CanvasPosition.Y)
			v_u_647(v_u_2182.pos)
		end
	end
	local v2200, v2201, v2202, v2203
	if v_u_2182 and (v_u_2182.m.rail and v_u_2182.m.rail.btn.Parent) then
		local v2204 = v_u_2182.m.rail
		if v2204.expanded then
			v_u_2182.railT = 0
			if not (v_u_2182 and (v_u_2182.m.narrow and (v_u_2182.m.secTabFrame and v_u_2182.m.secTabFrame.Parent))) then
				v_u_2154()
				for v2258, v2259 in v_u_136 do
					if not v2259.opened then
						continue
					end
					for v2260, v2261 in v2259.sections do
						if not (v2261.ring and v2261.searching) then
							continue
						end
						v2261.ringT = (v2261.ringT or 0) + p2178
						v2200 = v2261.ring.set
						v2201 = v2261.ringT / (v2261.est or 1.2)
						v2202 = math.clamp(v2201, 0, 1)
						pcall(v2200, v2202)
					end
				end
				for v2262, v2263 in table.clone(v_u_136) do
					if not v2263.layer then
						continue
					end
					v_u_1848(v2263)
				end
				v_u_22 = v_u_22 + p2178
				v2264 = v_u_22 >= 0.25
				if v2264 then
					v_u_22 = 0
				end
				for v2265, v2266 in v_u_136 do
					if not (v2266.cullDirty or v2264) then
						continue
					end
					v_u_1516(v2266)
				end
				if v_u_137 and v_u_137.opened then
					v2203 = v_u_21.Character
					if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
						v_u_19.close()
						return
					end
				elseif v_u_1937 then
					v_u_1948(false)
					v_u_21:SetAttribute("InvUIOpen", false)
				end
				return
			end
		else
			local v2213 = v_u_2182.pos
			local v2214 = v2204.btn
			local v2215 = v2214.AbsolutePosition
			local v2216 = v2214.AbsoluteSize
			local v2217
			if v2213.X >= v2215.X and (v2213.Y >= v2215.Y and v2213.X < v2215.X + v2216.X) then
				v2217 = v2213.Y < v2215.Y + v2216.Y
			else
				v2217 = false
			end
			if v2217 then
				v_u_2182.railT = (v_u_2182.railT or 0) + p2178
				if v_u_2182.railT >= 0.4 then
					v_u_2182.railT = 0
					v_u_2182.railOpened = true
					v_u_180(v_u_2182.m, true)
					task.defer(function()
						-- upvalues: (ref) v_u_149, (copy) v_u_2182, (ref) v_u_647
						if v_u_149 == v_u_2182 then
							v_u_647(v_u_2182.pos)
						end
					end)
				end
				if not (v_u_2182 and (v_u_2182.m.narrow and (v_u_2182.m.secTabFrame and v_u_2182.m.secTabFrame.Parent))) then
					v_u_2154()
					for v2258, v2259 in v_u_136 do
						if not v2259.opened then
							continue
						end
						for v2260, v2261 in v2259.sections do
							if not (v2261.ring and v2261.searching) then
								continue
							end
							v2261.ringT = (v2261.ringT or 0) + p2178
							v2200 = v2261.ring.set
							v2201 = v2261.ringT / (v2261.est or 1.2)
							v2202 = math.clamp(v2201, 0, 1)
							pcall(v2200, v2202)
						end
					end
					for v2262, v2263 in table.clone(v_u_136) do
						if not v2263.layer then
							continue
						end
						v_u_1848(v2263)
					end
					v_u_22 = v_u_22 + p2178
					v2264 = v_u_22 >= 0.25
					if v2264 then
						v_u_22 = 0
					end
					for v2265, v2266 in v_u_136 do
						if not (v2266.cullDirty or v2264) then
							continue
						end
						v_u_1516(v2266)
					end
					if v_u_137 and v_u_137.opened then
						v2203 = v_u_21.Character
						if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
							v_u_19.close()
							return
						end
					elseif v_u_1937 then
						v_u_1948(false)
						v_u_21:SetAttribute("InvUIOpen", false)
					end
					return
				end
			else
				v_u_2182.railT = 0
				if not (v_u_2182 and (v_u_2182.m.narrow and (v_u_2182.m.secTabFrame and v_u_2182.m.secTabFrame.Parent))) then
					v_u_2154()
					for v2258, v2259 in v_u_136 do
						if not v2259.opened then
							continue
						end
						for v2260, v2261 in v2259.sections do
							if not (v2261.ring and v2261.searching) then
								continue
							end
							v2261.ringT = (v2261.ringT or 0) + p2178
							v2200 = v2261.ring.set
							v2201 = v2261.ringT / (v2261.est or 1.2)
							v2202 = math.clamp(v2201, 0, 1)
							pcall(v2200, v2202)
						end
					end
					for v2262, v2263 in table.clone(v_u_136) do
						if not v2263.layer then
							continue
						end
						v_u_1848(v2263)
					end
					v_u_22 = v_u_22 + p2178
					v2264 = v_u_22 >= 0.25
					if v2264 then
						v_u_22 = 0
					end
					for v2265, v2266 in v_u_136 do
						if not (v2266.cullDirty or v2264) then
							continue
						end
						v_u_1516(v2266)
					end
					if v_u_137 and v_u_137.opened then
						v2203 = v_u_21.Character
						if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
							v_u_19.close()
							return
						end
					elseif v_u_1937 then
						v_u_1948(false)
						v_u_21:SetAttribute("InvUIOpen", false)
					end
					return
				end
			end
		end
	elseif not (v_u_2182 and (v_u_2182.m.narrow and (v_u_2182.m.secTabFrame and v_u_2182.m.secTabFrame.Parent))) then
		v_u_2154()
		for v2258, v2259 in v_u_136 do
			if not v2259.opened then
				continue
			end
			for v2260, v2261 in v2259.sections do
				if not (v2261.ring and v2261.searching) then
					continue
				end
				v2261.ringT = (v2261.ringT or 0) + p2178
				v2200 = v2261.ring.set
				v2201 = v2261.ringT / (v2261.est or 1.2)
				v2202 = math.clamp(v2201, 0, 1)
				pcall(v2200, v2202)
			end
		end
		for v2262, v2263 in table.clone(v_u_136) do
			if not v2263.layer then
				continue
			end
			v_u_1848(v2263)
		end
		v_u_22 = v_u_22 + p2178
		v2264 = v_u_22 >= 0.25
		if v2264 then
			v_u_22 = 0
		end
		for v2265, v2266 in v_u_136 do
			if not (v2266.cullDirty or v2264) then
				continue
			end
			v_u_1516(v2266)
		end
		if v_u_137 and v_u_137.opened then
			v2203 = v_u_21.Character
			if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
				v_u_19.close()
				return
			end
		elseif v_u_1937 then
			v_u_1948(false)
			v_u_21:SetAttribute("InvUIOpen", false)
		end
		return
	end
	local v2242 = nil
	for _, v2243 in v_u_1305 do
		local v2244 = v_u_2182.m.secTabFrame:FindFirstChild("Tab_" .. v2243, true)
		if not (v2244 and v2244:IsA("GuiObject")) then
			continue
		end
		local v2245 = v_u_2182.pos
		local v2246 = v2244.AbsolutePosition
		local v2247 = v2244.AbsoluteSize
		local v2248
		if v2245.X >= v2246.X and (v2245.Y >= v2246.Y and v2245.X < v2246.X + v2247.X) then
			v2248 = v2245.Y < v2246.Y + v2247.Y
		else
			v2248 = false
		end
		if not v2248 then
			continue
		end
		v2242 = v2243
	end
	if v2242 then
		local v2249 = v_u_2182.m
		if v2242 ~= (v2249.section or (v2249.mode == "raid" and "both" or v_u_1306)) then
			if v_u_2182.tabHover ~= v2242 then
				v_u_2182.tabHover = v2242
				v_u_2182.tabHoverT = 0
			end
			v_u_2182.tabHoverT = v_u_2182.tabHoverT + p2178
			if v_u_2182.tabHoverT >= 0.4 then
				v_u_2182.tabHover = nil
				v_u_1320(v_u_2182.m, v2242)
				task.defer(function()
					-- upvalues: (ref) v_u_149, (copy) v_u_2182, (ref) v_u_647
					if v_u_149 == v_u_2182 then
						v_u_647(v_u_2182.pos)
					end
				end)
			end
			v_u_2154()
			for v2258, v2259 in v_u_136 do
				if not v2259.opened then
					continue
				end
				for v2260, v2261 in v2259.sections do
					if not (v2261.ring and v2261.searching) then
						continue
					end
					v2261.ringT = (v2261.ringT or 0) + p2178
					v2200 = v2261.ring.set
					v2201 = v2261.ringT / (v2261.est or 1.2)
					v2202 = math.clamp(v2201, 0, 1)
					pcall(v2200, v2202)
				end
			end
			for v2262, v2263 in table.clone(v_u_136) do
				if not v2263.layer then
					continue
				end
				v_u_1848(v2263)
			end
			v_u_22 = v_u_22 + p2178
			v2264 = v_u_22 >= 0.25
			if v2264 then
				v_u_22 = 0
			end
			for v2265, v2266 in v_u_136 do
				if not (v2266.cullDirty or v2264) then
					continue
				end
				v_u_1516(v2266)
			end
			if v_u_137 and v_u_137.opened then
				v2203 = v_u_21.Character
				if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
					v_u_19.close()
					return
				end
			elseif v_u_1937 then
				v_u_1948(false)
				v_u_21:SetAttribute("InvUIOpen", false)
			end
			return
		end
		v_u_2182.tabHover = nil
	else
		v_u_2182.tabHover = nil
	end
	v_u_2154()
	for v2258, v2259 in v_u_136 do
		if not v2259.opened then
			continue
		end
		for v2260, v2261 in v2259.sections do
			if not (v2261.ring and v2261.searching) then
				continue
			end
			v2261.ringT = (v2261.ringT or 0) + p2178
			v2200 = v2261.ring.set
			v2201 = v2261.ringT / (v2261.est or 1.2)
			v2202 = math.clamp(v2201, 0, 1)
			pcall(v2200, v2202)
		end
	end
	for v2262, v2263 in table.clone(v_u_136) do
		if not v2263.layer then
			continue
		end
		v_u_1848(v2263)
	end
	v_u_22 = v_u_22 + p2178
	local v2264 = v_u_22 >= 0.25
	if v2264 then
		v_u_22 = 0
	end
	for v2265, v2266 in v_u_136 do
		if not (v2266.cullDirty or v2264) then
			continue
		end
		v_u_1516(v2266)
	end
	if v_u_137 and v_u_137.opened then
		v2203 = v_u_21.Character
		if v2203 and (v2203:GetAttribute("Dead") == true or v2203:GetAttribute("Downed") == true) then
			v_u_19.close()
			return
		end
	elseif v_u_1937 then
		v_u_1948(false)
		v_u_21:SetAttribute("InvUIOpen", false)
	end
end
v_u_188.Layout = require(v_u_7:WaitForChild("InvUIXLayout"))
v_u_188.XDbg = require(v_u_7:WaitForChild("InvUIXDebug"))
v_u_188.E = {
	["AmmoUI"] = v_u_16,
	["C"] = v_u_18,
	["Ext"] = v_u_188,
	["HushUI"] = v_u_11,
	["InventoryUI"] = v_u_19,
	["ItemIcons"] = v_u_12,
	["Items"] = v_u_9,
	["LootGlow"] = v_u_15,
	["RIGHT_CHROME"] = 34,
	["SLOT_DEFS"] = v_u_33,
	["Theme"] = v_u_8,
	["Tile"] = v_u_13,
	["actionsFor"] = v_u_288,
	["applyWishlist"] = v_u_133,
	["beginDrag"] = v_u_862,
	["buildDragStrip"] = v_u_785,
	["buildRail"] = v1401,
	["buildSectionTabs"] = v1336,
	["cellReal"] = v_u_635,
	["columnPanel"] = function(p2267, p2268, p2269, p2270, p2271, p2272, p2273, p2274) -- name: columnPanel
		-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_60, (copy) v_u_74
		local v2275 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = p2268,
			["BackgroundColor3"] = v_u_18.bg,
			["BackgroundTransparency"] = v_u_8.alpha.panel,
			["Position"] = UDim2.fromOffset(p2269, 0),
			["Size"] = UDim2.fromOffset(p2270, p2271)
		}
		local v2276 = Instance.new("Frame")
		if v2275 then
			for v2277, v2278 in v2275 do
				v2276[v2277] = v2278
			end
		end
		if p2267 then
			v2276.Parent = p2267
		end
		v_u_60(v2276, v_u_18.line)
		local v2279 = {
			["Rotation"] = 90,
			["Color"] = nil,
			["Transparency"] = nil,
			["Color"] = ColorSequence.new(v_u_18.raised, v_u_18.bg),
			["Transparency"] = NumberSequence.new(0)
		}
		local v2280 = Instance.new("UIGradient")
		if v2279 then
			for v2281, v2282 in v2279 do
				v2280[v2281] = v2282
			end
		end
		if v2276 then
			v2280.Parent = v2276
		end
		local v2283 = {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["ZIndex"] = 2,
			["BackgroundColor3"] = v_u_18.accent,
			["Size"] = UDim2.new(0, 28, 0, 2)
		}
		local v2284 = Instance.new("Frame")
		if v2283 then
			for v2285, v2286 in v2283 do
				v2284[v2285] = v2286
			end
		end
		if v2276 then
			v2284.Parent = v2276
		end
		local v2287 = p2274 and 12 or 16
		local v2288 = v_u_74(v2276, p2272, "h3", {
			["position"] = UDim2.fromOffset(v2287, p2274 and 8 or 12),
			["size"] = UDim2.new(1, v2287 * -2, 0, 22)
		})
		local v2289 = v_u_74(v2276, p2273 or "", "micro", {
			["position"] = UDim2.fromOffset(v2287, 34),
			["size"] = UDim2.new(1, v2287 * -2, 0, 14)
		})
		v2289.Visible = not p2274
		local v2290 = p2274 and 38 or 56
		local v2291 = {
			["Name"] = "Content",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(v2287, v2290),
			["Size"] = UDim2.new(1, -v2287 - 8, 1, -v2290 - 8)
		}
		local v2292 = Instance.new("Frame")
		if v2291 then
			for v2293, v2294 in v2291 do
				v2292[v2293] = v2294
			end
		end
		if v2276 then
			v2292.Parent = v2276
		end
		return v2276, v2292, v2289, v2288
	end,
	["designRect"] = v_u_656,
	["designSizeOf"] = v_u_106,
	["device"] = function() -- name: device
		-- upvalues: (copy) v_u_11, (copy) v_u_2
		local v2295 = v_u_11.device
		local v2296, v2297 = pcall(v2295)
		return (not v2296 or type(v2297) ~= "string") and (v_u_2.TouchEnabled and not v_u_2.KeyboardEnabled and "Touch" or "Keyboard") or v2297
	end,
	["endDrag"] = v_u_1010,
	["gearNeedOf"] = v_u_1356,
	["gridIds"] = function(p2298) -- name: gridIds
		-- upvalues: (copy) v_u_29, (copy) v_u_30
		if p2298.mode == "raid" then
			return v_u_29
		else
			return v_u_30
		end
	end,
	["label"] = v_u_74,
	["layoutKeyOf"] = function(p2299) -- name: layoutKeyOf
		-- upvalues: (copy) v_u_1346, (copy) v_u_1356
		local v2300 = v_u_1346(p2299)
		return v2300 == "" and "" or v2300 .. "|g" .. v_u_1356(p2299)
	end,
	["locate"] = v_u_175,
	["makeQuickBox"] = v1226,
	["makeScroller"] = function(p2301, p2302, p2303, p2304) -- name: makeScroller
		-- upvalues: (copy) v_u_8, (copy) v_u_18
		local v2305 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Position"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollBarThickness"] = nil,
			["ScrollBarImageColor3"] = nil,
			["ScrollingDirection"] = nil,
			["ElasticBehavior"] = nil,
			["Name"] = p2302,
			["Size"] = p2303,
			["Position"] = p2304 or UDim2.new(),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
			["ScrollBarThickness"] = v_u_8.scrollBar,
			["ScrollBarImageColor3"] = v_u_18.lineStrong,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["ElasticBehavior"] = Enum.ElasticBehavior.Never
		}
		local v2306 = Instance.new("ScrollingFrame")
		if v2305 then
			for v2307, v2308 in v2305 do
				v2306[v2307] = v2308
			end
		end
		if p2301 then
			v2306.Parent = p2301
		end
		local v2309 = {
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 10)
		}
		local v2310 = Instance.new("UIListLayout")
		if v2309 then
			for v2311, v2312 in v2309 do
				v2310[v2311] = v2312
			end
		end
		if v2306 then
			v2310.Parent = v2306
		end
		local v2313 = {
			["PaddingRight"] = UDim.new(0, 8),
			["PaddingBottom"] = UDim.new(0, 12)
		}
		local v2314 = Instance.new("UIPadding")
		if v2313 then
			for v2315, v2316 in v2313 do
				v2314[v2315] = v2316
			end
		end
		if v2306 then
			v2314.Parent = v2306
		end
		return v2306
	end,
	["makeSlotBox"] = v1155,
	["mountAlive"] = function(p2317) -- name: mountAlive
		if p2317.dead or p2317.gone then
			return false
		else
			local v2318 = p2317.root
			if v2318 and v2318.Parent ~= nil then
				return (not p2317.layer or p2317.layer.gui.Parent ~= nil) and true or false
			else
				return false
			end
		end
	end,
	["mounts"] = v_u_136,
	["new"] = v_u_40,
	["openContext"] = v_u_471,
	["overlapArea"] = function(p2319, p2320) -- name: overlapArea
		local v2321 = p2319[3]
		local v2322 = p2320[3]
		local v2323 = math.min(v2321, v2322)
		local v2324 = p2319[1]
		local v2325 = p2320[1]
		local v2326 = v2323 - math.max(v2324, v2325)
		local v2327 = p2319[4]
		local v2328 = p2320[4]
		local v2329 = math.min(v2327, v2328)
		local v2330 = p2319[2]
		local v2331 = p2320[2]
		local v2332 = v2329 - math.max(v2330, v2331)
		return (v2326 <= 0 or v2332 <= 0) and 0 or v2326 * v2332
	end,
	["player"] = v_u_21,
	["primaryAction"] = v_u_385,
	["renderMount"] = v_u_178,
	["rightKeyOf"] = v_u_1346,
	["rightNeedOf"] = function(p2333) -- name: rightNeedOf
		-- upvalues: (copy) v_u_1346
		if p2333.mode ~= "raid" then
			return 10
		end
		local v2334 = string.match
		local v2335 = v_u_1346(p2333)
		local v2336 = tonumber(v2334(v2335, "^w(%d+)$")) or 0
		return math.clamp(v2336, 4, 7)
	end,
	["rotateDrag"] = v649,
	["runAction"] = v_u_379,
	["screenDesign"] = function() -- name: screenDesign
		-- upvalues: (copy) v_u_8
		return v_u_8.refSize()
	end,
	["sectionOf"] = v1309,
	["setEqExpanded"] = v_u_180,
	["setMountSection"] = v_u_1320,
	["setWishId"] = v_u_228,
	["slotItem"] = function(p2337, p2338) -- name: slotItem
		local v2339
		if type(p2337) == "table" then
			v2339 = p2337.kit or nil
		else
			v2339 = nil
		end
		if v2339 then
			local v2340 = v2339.slots
			if v2340 then
				v2340 = v2339.slots[p2338]
			end
			if v2340 == nil then
				v2340 = v2339[p2338]
			end
			if type(v2340) == "table" then
				return v2340
			else
				return nil
			end
		else
			return nil
		end
	end,
	["sound"] = v_u_43,
	["stripAvoid"] = v_u_684,
	["stripButton"] = v_u_730,
	["stroke"] = v_u_60,
	["updateDrag"] = v_u_647,
	["watchScrollers"] = function(p_u_2341) -- name: watchScrollers
		for _, v2342 in p_u_2341.scrollers do
			local function v2343() -- name: dirty
				-- upvalues: (copy) p_u_2341
				p_u_2341.cullDirty = true
			end
			v2342:GetPropertyChangedSignal("CanvasPosition"):Connect(v2343)
			v2342:GetPropertyChangedSignal("AbsoluteSize"):Connect(v2343)
		end
	end,
	["wishedId"] = v215,
	["drag"] = function() -- name: drag
		-- upvalues: (ref) v_u_149
		return v_u_149
	end,
	["sel"] = function() -- name: sel
		-- upvalues: (ref) v_u_159
		return v_u_159
	end,
	["raidMount"] = function() -- name: raidMount
		-- upvalues: (ref) v_u_137
		return v_u_137
	end,
	["sidePanel"] = function() -- name: sidePanel
		-- upvalues: (ref) v_u_156
		return v_u_156
	end,
	["raidSnap"] = function() -- name: raidSnap
		-- upvalues: (ref) v_u_128
		return v_u_128
	end,
	["menuSnap"] = function() -- name: menuSnap
		-- upvalues: (ref) v_u_135
		return v_u_135
	end,
	["wishSet"] = function() -- name: wishSet
		-- upvalues: (ref) v_u_129
		return v_u_129
	end,
	["cctx"] = function() -- name: cctx
		-- upvalues: (ref) v_u_20
		return v_u_20
	end,
	["setWishOverride"] = function(p2344) -- name: setWishOverride
		-- upvalues: (ref) v_u_131
		v_u_131 = p2344
	end
}
v_u_188.Layout.bind(v_u_188.E)
v_u_19._test = {
	["touchScroll"] = v_u_1070,
	["cullMount"] = v_u_1516,
	["canvasAncestor"] = v_u_78,
	["prune"] = v_u_147,
	["mountCount"] = function() -- name: mountCount
		-- upvalues: (copy) v_u_136
		return #v_u_136
	end
}
return v_u_19