-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / WeaponClient

local v1 = script.Parent and script.Parent.Parent
if v1 then
	v1 = script.Parent.Parent:FindFirstChild("Lib")
end
if v1 then
	v1 = v1:FindFirstChild("ServerClock") or v1:WaitForChild("ServerClock", 5)
end
local v_u_2
if v1 then
	v_u_2 = require(v1)
else
	v_u_2 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = game:GetService("CollectionService")
local v_u_8 = {
	["name"] = "WeaponClient",
	["order"] = 30,
	["_noAy"] = false,
	["_pk"] = nil,
	["RIDE_HOOK"] = true,
	["_wr"] = false,
	["_wrT"] = -100,
	["_rk"] = "none",
	["_pk"] = {
		["t"] = 0,
		["perk"] = nil,
		["sig"] = "",
		["perk"] = {}
	}
}
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_1564 = false
local v_u_17 = v_u_3.LocalPlayer
local v_u_18 = false
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = 0
local v_u_24 = 0
local v_u_25 = 0
local v_u_1573 = 0
local v_u_27 = false
local v_u_1581 = false
local v_u_1562 = 0
local v_u_1575 = false
local v_u_31 = math.random(1, 100000)
local v_u_32 = 0
local v_u_33 = nil
local v_u_1594 = false
local v_u_35 = nil
local v_u_1552 = ""
local v_u_1679 = 0
local v_u_38 = 0
local v_u_39 = nil
local v_u_1723 = nil
local v_u_1724 = 0
local v_u_42 = nil
local v_u_43 = {}
local v_u_1572 = 0
local v_u_1604 = 0
local v_u_49 = {
	["at"] = 0,
	["dist"] = nil,
	["distAt"] = 0,
	["zombie"] = false,
	["lib"] = nil,
	["beamOpts"] = nil,
	["dotOpts"] = nil,
	["rng"] = nil,
	["rng"] = {
		["at"] = 0,
		["V"] = nil,
		["under"] = nil,
		["note"] = nil,
		["far"] = 0,
		["reach"] = 0
	},
	["get"] = function() -- name: get
		-- upvalues: (copy) v_u_49, (ref) v_u_9
		local v46 = v_u_49.lib
		if v46 == nil then
			local function v47()
				-- upvalues: (ref) v_u_9
				return v_u_9.lib.FpLaser
			end
			local v48
			v48, v46 = pcall(v47)
			if not v48 or type(v46) ~= "table" then
				v46 = false
			end
			v_u_49.lib = v46
			if v46 then
				v_u_49.beamOpts = {
					["width"] = v46.FP_WIDTH,
					["alpha"] = v46.FP_ALPHA
				}
				v_u_49.dotOpts = {
					["dotOnly"] = true
				}
			end
		end
		return v46 or nil
	end
}
local v_u_50 = ""
local v_u_51 = 0
local v_u_52 = -1
local v_u_1641 = -1
local v_u_1654 = 0
local v_u_1747 = 0
local v_u_1748 = 0
local v_u_57 = nil
local v_u_1559 = 0
local v_u_1716 = false
local v_u_60 = 0
local v_u_61 = 0.6
local v_u_62 = nil
local v_u_1577 = nil
local v_u_1584 = nil
local v_u_1672 = 0
local v_u_66 = RaycastParams.new()
v_u_66.FilterType = Enum.RaycastFilterType.Exclude
v_u_66.IgnoreWater = true
local function v_u_76(p67, p68, p69) -- name: meleeSound
	-- upvalues: (ref) v_u_9, (ref) v_u_11
	local v70 = v_u_9
	if v70 then
		v70 = v_u_9.controllers.Audio
	end
	if v70 and v70.melee then
		local v71 = v70.melee
		pcall(v71, p67, p68, p69)
	else
		local v72 = v_u_11 and v_u_11.melee
		if v72 then
			v72 = v_u_11.melee[p67 or "fists"]
		end
		local v73
		if v72 then
			if p69 == "hit" then
				v73 = v72.hit
			else
				v73 = v72.swing
			end
		else
			v73 = "mel_swing"
		end
		local v74 = v_u_9
		if v74 then
			v74 = v_u_9.controllers.Audio
		end
		if v74 and v74.play3D then
			local v75 = v74.play3D
			pcall(v75, v73, p68, nil)
		end
	end
end
local function v_u_79(p77) -- name: attr
	-- upvalues: (copy) v_u_17
	local v78 = v_u_17.Character
	if not (v78 and v78.Parent) then
		v78 = nil
	end
	if v78 then
		v78 = v78:GetAttribute(p77)
	end
	return v78
end
v_u_8._stun = {
	["at"] = -1000000000,
	["on"] = true,
	["SR"] = nil
}
function v_u_8._stunnedNow(p80) -- name: _stunnedNow
	-- upvalues: (copy) v_u_8, (ref) v_u_9, (copy) v_u_2
	if p80:GetAttribute("StunUntil") == nil then
		return false
	end
	local v81 = v_u_8._stun
	local v82 = os.clock()
	if v82 - v81.at > 2 then
		v81.at = v82
		local function v83()
			-- upvalues: (ref) v_u_9
			return v_u_9.config.flag("DjStun")
		end
		local v84, v85 = pcall(v83)
		if v84 then
			v84 = v85 == false
		end
		v81.on = not v84
	end
	if not v81.on then
		return false
	end
	if v81.SR == nil then
		local function v86()
			-- upvalues: (ref) v_u_9
			return v_u_9.shared.StunRules
		end
		local v87, v88 = pcall(v86)
		if not v87 or type(v88) ~= "table" then
			v88 = false
		end
		v81.SR = v88
	end
	local v89 = v81.SR
	local v90
	if v89 == false then
		v90 = false
	else
		v90 = v89.active(p80, v_u_2.now()) == true
	end
	return v90
end
local function v_u_99(p91) -- name: inputEnabledForGame
	-- upvalues: (ref) v_u_9, (copy) v_u_17, (copy) v_u_8
	for _, v92 in { "InventoryUI", "MapUI" } do
		local v93 = v_u_9
		if v93 then
			v93 = v_u_9.controllers[v92]
		end
		if not (v93 and v93.isOpen) then
			continue
		end
		local v94 = v93.isOpen
		local v95, v96 = pcall(v94)
		if not (v95 and v96) then
			continue
		end
		return false
	end
	local v97 = v_u_17.Character
	if not (v97 and v97.Parent) then
		v97 = nil
	end
	if v97 and (v97:GetAttribute("Dead") ~= true and v97:GetAttribute("Downed") ~= true) then
		local v98 = v97:GetAttribute("Action")
		if v98 == "Search" or (v98 == "Revive" or (v98 == "Bandage" or (v98 == "Use" or v98 == "Takedown"))) then
			return false
		else
			return p91 == true and true or not v_u_8._stunnedNow(v97)
		end
	else
		return false
	end
end
local function v_u_106() -- name: isAiming
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (ref) v_u_9
	local v100 = v_u_17.Character
	if not (v100 and v100.Parent) then
		v100 = nil
	end
	if v100 and v_u_8._stunnedNow(v100) then
		return false
	end
	local v101 = v_u_9
	if v101 then
		v101 = v_u_9.controllers.Input
	end
	if v101 and v101.isAiming then
		local v102 = v101.isAiming
		local v103, v104 = pcall(v102)
		if v103 then
			return v104 == true
		end
	end
	local v105 = v_u_17.Character
	if not (v105 and v105.Parent) then
		v105 = nil
	end
	if v105 then
		v105 = v105:GetAttribute("Aiming")
	end
	return v105 == true
end
local v_u_107 = nil
local function v_u_113() -- name: fpAim
	-- upvalues: (ref) v_u_9, (ref) v_u_107
	local v108 = v_u_9
	if v108 then
		v108 = v_u_9.controllers.FpView
	end
	if v108 then
		local v109 = v108.active
		if type(v109) == "function" and v108.active() == true then
			if v_u_107 == nil then
				local function v110()
					-- upvalues: (ref) v_u_9
					return v_u_9.lib.FpAim
				end
				local v111, v112 = pcall(v110)
				if not v111 or type(v112) ~= "table" then
					v112 = false
				end
				v_u_107 = v112
			end
			if v_u_107 then
				return v_u_107
			else
				return nil
			end
		end
	end
	return nil
end
local function v_u_131() -- name: aimYaw
	-- upvalues: (ref) v_u_42, (copy) v_u_17, (ref) v_u_9
	local v114 = v_u_42
	local v115
	if v114 then
		v115 = v_u_17.Character
		if not (v115 and v115.Parent) then
			v115 = nil
		end
		if v115 then
			v115 = v115:FindFirstChild("HumanoidRootPart")
		end
	else
		v115 = nil
	end
	local v116
	if v114 and v115 then
		local v117 = v114.X - v115.Position.X
		local v118 = v114.Z - v115.Position.Z
		local v119 = Vector3.new(v117, 0, v118)
		if v119.Magnitude < 0.8 then
			v116 = nil
		else
			local v120 = -v119.X
			local v121 = -v119.Z
			v116 = math.atan2(v120, v121)
		end
	else
		v116 = nil
	end
	if v116 then
		return v116
	end
	local v122 = v_u_9
	if v122 then
		v122 = v_u_9.controllers.Input
	end
	if v122 and v122.aimYaw then
		local v123 = v122.aimYaw
		local v124, v125 = pcall(v123)
		if v124 and type(v125) == "number" then
			return v125
		end
	end
	local v126 = v_u_17.Character
	if not (v126 and v126.Parent) then
		v126 = nil
	end
	if v126 then
		v126 = v126:GetAttribute("AimYaw")
	end
	if type(v126) == "number" then
		return v126
	end
	local v127 = v_u_17.Character
	if not (v127 and v127.Parent) then
		v127 = nil
	end
	if v127 then
		v127 = v127:FindFirstChild("HumanoidRootPart")
	end
	if not v127 then
		return 0
	end
	local v128 = v127.CFrame.LookVector
	local v129 = -v128.X
	local v130 = -v128.Z
	return math.atan2(v129, v130)
end
local function v_u_138() -- name: scanRigs
	-- upvalues: (copy) v_u_43, (copy) v_u_6
	table.clear(v_u_43)
	local v132 = v_u_6:FindFirstChild("HushLocal")
	if v132 then
		local function v_u_137(p133, p134) -- name: visit
			-- upvalues: (ref) v_u_43, (copy) v_u_137
			for _, v135 in p133:GetChildren() do
				if v135:IsA("Model") then
					if v135:FindFirstChild("HumanoidRootPart") then
						local v136 = v_u_43
						table.insert(v136, v135)
					else
						if p134 >= 2 then
							continue
						end
						v_u_137(v135, p134 + 1)
					end
				else
					if not v135:IsA("Folder") or (p134 >= 2 or v135.Name == "WeaponFx") then
						continue
					end
					v_u_137(v135, p134 + 1)
				end
			end
		end
		v_u_137(v132, 0)
	end
end
local function v_u_140(p139) -- name: rigOf
	if p139 then
		p139 = p139:FindFirstAncestorOfClass("Model")
	end
	while p139 do
		if p139:FindFirstChild("HumanoidRootPart") then
			return p139
		end
		p139 = p139:FindFirstAncestorOfClass("Model")
	end
	return nil
end
local v_u_141 = {
	["Head"] = "head",
	["UpperTorso"] = "torso",
	["LowerTorso"] = "torso",
	["Torso"] = "torso",
	["LeftUpperArm"] = "arm",
	["LeftLowerArm"] = "arm",
	["LeftHand"] = "arm",
	["RightUpperArm"] = "arm",
	["RightLowerArm"] = "arm",
	["RightHand"] = "arm",
	["Left Arm"] = "arm",
	["Right Arm"] = "arm",
	["LeftUpperLeg"] = "leg",
	["LeftLowerLeg"] = "leg",
	["LeftFoot"] = "leg",
	["RightUpperLeg"] = "leg",
	["RightLowerLeg"] = "leg",
	["RightFoot"] = "leg",
	["Left Leg"] = "leg",
	["Right Leg"] = "leg"
}
local v_u_142 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_148(p143) -- name: partsOf
	-- upvalues: (copy) v_u_142, (copy) v_u_141
	local v144 = v_u_142[p143]
	if v144 then
		return v144
	end
	local v145 = {}
	for _, v146 in p143:GetChildren() do
		local v147 = v_u_141[v146.Name]
		if not (v147 and v146:IsA("BasePart")) then
			continue
		end
		table.insert(v145, {
			["part"] = v146,
			["kind"] = v147
		})
	end
	v_u_142[p143] = v145
	return v145
end
local function v_u_167(p149, p150, p151, p152) -- name: rayBox
	local v153 = p151.CFrame
	local v154 = p151.Size * 0.5
	local v155 = v153:PointToObjectSpace(p149)
	local v156 = v153:VectorToObjectSpace(p150)
	local v157 = (-1 / 0)
	local v158 = (1 / 0)
	for v159 = 1, 3 do
		local v160
		if v159 == 1 then
			v160 = v155.X
		elseif v159 == 2 then
			v160 = v155.Y
		else
			v160 = v155.Z
		end
		local v161
		if v159 == 1 then
			v161 = v156.X
		elseif v159 == 2 then
			v161 = v156.Y
		else
			v161 = v156.Z
		end
		local v162
		if v159 == 1 then
			v162 = v154.X
		elseif v159 == 2 then
			v162 = v154.Y
		else
			v162 = v154.Z
		end
		local v163 = v162 + p152
		if math.abs(v161) < 1e-8 then
			if v160 >= -v163 and v163 >= v160 then
				continue
			end
			return nil
		end
		local v164 = (-v163 - v160) / v161
		local v165 = (v163 - v160) / v161
		if v165 >= v164 then
			local v166 = v164
			v164 = v165
			v165 = v166
		end
		if v157 >= v165 then
			v165 = v157
		end
		if v164 >= v158 then
			v164 = v158
		end
		if v164 < v165 then
			return nil
		end
		v158 = v164
		v157 = v165
	end
	if v158 < 0 then
		return nil
	else
		return math.max(v157, 0)
	end
end
local v_u_168 = {
	["cursor"] = nil,
	["legacy"] = false,
	["log"] = nil,
	["throwLand"] = nil
}
local function v_u_203(p169, p170, p171, p172, p173) -- name: rigRay
	-- upvalues: (copy) v_u_113, (copy) v_u_43, (copy) v_u_148, (copy) v_u_167
	local v174 = v_u_113() ~= nil
	local v175 = nil
	local v176 = nil
	local v177 = nil
	for _, v178 in v_u_43 do
		local v179 = v178:FindFirstChild("HumanoidRootPart")
		if not v179 or (not v178.Parent or v178:GetAttribute("Corpse") == true) then
			continue
		end
		local v180 = v179.Position
		if p172 and (v180 - p172).Magnitude > 170 then
			continue
		end
		local v181 = v180 - p169
		local v182 = v181:Dot(p170)
		if v182 < -5 - (not p173 and 0 or p173.back) or (p171 + 5 < v182 or (v181 - p170 * v182).Magnitude > 5) then
			continue
		end
		local v183
		if p173 then
			if (v180.X - p173.px) * p173.fx + (v180.Z - p173.pz) * p173.fz < 0 then
				v183 = p173.front
			else
				v183 = -p173.back
			end
		else
			v183 = 0
		end
		local v184
		if v183 == 0 then
			v184 = p169
		else
			v184 = p169 + p170 * v183
		end
		local v185 = v_u_148(v178)
		if #v185 == 0 then
			local v186 = v184 - v180
			local v187 = v186:Dot(p170)
			local v188 = v186:Dot(v186) - 1.2100000000000002
			local v189 = v187 * v187 - v188
			local v190
			if v189 < 0 then
				v190 = nil
			else
				v190 = -v187 - math.sqrt(v189)
				if v190 < 0 then
					v190 = -v187 + math.sqrt(v189) >= 0 and 0 or nil
				end
			end
			if not v190 or v190 + v183 >= p171 then
				continue
			end
			p171 = v190 + v183
			v177 = v180
			v175 = v178
			v176 = "torso"
		else
			local v191 = v178:FindFirstChild("Head")
			local v192
			if v191 == nil then
				v192 = false
			else
				v192 = v191.Position.Y < v180.Y - 0.8
			end
			local v193 = v174 and 0 or (v192 and 0.35 or 0.12)
			local v194 = (1 / 0)
			local v195 = (1 / 0)
			local v196 = nil
			local v197 = nil
			local v198 = nil
			for _, v199 in v185 do
				local v200 = v199.part
				if not v200.Parent then
					continue
				end
				local v201 = v_u_167(v184, p170, v200, v193)
				if not v201 then
					continue
				end
				local v202 = v201 + v183
				if v199.kind == "arm" then
					if v202 >= v195 then
						continue
					end
					v198 = v200.Position
					v195 = v202
				else
					if v202 >= v194 then
						continue
					end
					v196 = v199.kind
					v197 = v200.Position
					v194 = v202
				end
			end
			if v196 or not v198 then
				v198 = v197
				v195 = v194
			else
				v196 = "arm"
			end
			if not v196 or v195 >= p171 then
				break
			end
			v177 = v198
			v176 = v196
			v175 = v178
			p171 = v195
		end
	end
	if v175 then
		return p171, p169 + p170 * p171, v175, v176 == "head", v176, v177
	else
		return nil, nil, nil, false, nil, nil
	end
end
local function v_u_209(p204) -- name: visible
	-- upvalues: (ref) v_u_9
	local v205 = v_u_9
	if v205 then
		v205 = v_u_9.controllers.Vision
	end
	if v205 and v205.isVisible then
		local v206 = v205.isVisible
		local v207, v208 = pcall(v206, p204)
		if v207 then
			return v208 ~= false
		end
	end
	return true
end
function v_u_49.rangeCheck(p210, p211, p212, p213) -- name: rangeCheck
	-- upvalues: (copy) v_u_49, (ref) v_u_9, (ref) v_u_22, (copy) v_u_203, (copy) v_u_17, (ref) v_u_23, (ref) v_u_1679, (ref) v_u_1552
	local v214 = v_u_49.rng
	local v215 = os.clock()
	if v215 - v214.at < 0.1 then
		return
	else
		v214.at = v215
		v214.under = nil
		v214.note = nil
		v214.reach = p213
		if v214.V == nil then
			local function v216()
				-- upvalues: (ref) v_u_9
				return v_u_9.lib.ViewVis
			end
			local v217, v218 = pcall(v216)
			if not v217 or type(v218) ~= "table" then
				v218 = false
			end
			v214.V = v218
		end
		local v219 = v214.V
		if v219 and (v_u_22 ~= nil and v_u_22.kind == "firearm") then
			local v220 = v219.FADE_END + 10
			v214.far = v220
			local v221 = p210.target(v220)
			if v221 then
				v220 = (v221 - p211).Magnitude
			end
			local v222, v223, v224 = v_u_203(p211, p212, v220, nil)
			if v222 ~= nil and (v224 ~= nil and v223 ~= nil) then
				local v225 = v_u_9
				if v225 then
					v225 = v_u_9.controllers.Vision
				end
				local v226
				if v225 and v225.isVisible then
					local v227 = v225.isVisible
					local v228, v229 = pcall(v227, v223)
					v226 = not v228 and true or v229 ~= false
				else
					v226 = true
				end
				if v226 then
					v214.under = v222
					local v230 = v219.rangeNote(v222, p213)
					v214.note = v230
					if v230 ~= nil then
						local v231 = v_u_17.Character
						if not (v231 and v231.Parent) then
							v231 = nil
						end
						if v231 then
							v231 = v231:GetAttribute("Jammed")
						end
						if v231 ~= true then
							local v232 = v_u_17.Character
							if not (v232 and v232.Parent) then
								v232 = nil
							end
							if v232 then
								v232 = v232:GetAttribute("Reloading")
							end
							if v232 ~= true and (v_u_23 > 0 and (v_u_1679 <= os.clock() or v_u_1552 == v230)) then
								v_u_1552 = v230
								v_u_1679 = os.clock() + 0.3
							end
						end
					end
					return
				end
			end
		end
	end
end
local function v_u_257(p233, p234, p235, p236) -- name: headAimPoint
	-- upvalues: (ref) v_u_22, (ref) v_u_9, (copy) v_u_17, (copy) v_u_6, (copy) v_u_4, (copy) v_u_209
	if not (p235 and v_u_22) then
		return nil
	end
	local v237 = v_u_9.config.flag
	local v238, v239 = pcall(v237, "AssistHeadBias")
	if not v238 or v239 ~= true then
		return nil
	end
	local function v240()
		-- upvalues: (ref) v_u_9
		return v_u_9.lib.AssistHead
	end
	local v241, v242 = pcall(v240)
	if not v241 or type(v242) ~= "table" then
		return nil
	end
	local v243 = {}
	local v244 = v_u_17.Character
	if not (v244 and v244.Parent) then
		v244 = nil
	end
	if v244 then
		table.insert(v243, v244)
	end
	for _, v245 in { "HushCombat", "HushLocal" } do
		local v246 = v_u_6:FindFirstChild(v245)
		if not v246 then
			continue
		end
		table.insert(v243, v246)
	end
	local v247 = v_u_6:FindFirstChild("Raid")
	if v247 then
		for _, v248 in { "Items", "Extracts", "Spawns" } do
			local v249 = v247:FindFirstChild(v248)
			if not v249 then
				continue
			end
			table.insert(v243, v249)
		end
	end
	local v250 = v242.pick
	local v251 = {
		["rig"] = nil,
		["origin"] = nil,
		["device"] = nil,
		["flag"] = true,
		["assist"] = true,
		["stats"] = nil,
		["auto"] = nil,
		["shot"] = nil,
		["ignore"] = nil,
		["visible"] = nil,
		["rig"] = p233,
		["origin"] = p234
	}
	local v252 = v_u_9
	if v252 then
		v252 = v_u_9.controllers.Input
	end
	if not (v252 and v252.device) then
		v255 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		v251.device = v255
		v251.stats = v_u_22
		v256 = v_u_17.Character
		if not (v256 and v256.Parent) then
			v256 = nil
		end
		if v256 then
			v256 = v256:GetAttribute("FireMode")
		end
		v251.auto = v256 == "auto"
		v251.shot = p236 == true
		v251.ignore = v243
		v251.visible = v_u_209
		return v250(v251)
	end
	local v253 = v252.device
	local v254, v255 = pcall(v253)
	if v254 and type(v255) == "string" then
		v251.device = v255
		v251.stats = v_u_22
		v256 = v_u_17.Character
		if not (v256 and v256.Parent) then
			v256 = nil
		end
		if v256 then
			v256 = v256:GetAttribute("FireMode")
		end
		v251.auto = v256 == "auto"
		v251.shot = p236 == true
		v251.ignore = v243
		v251.visible = v_u_209
		return v250(v251)
	end
	v255 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
	v251.device = v255
	v251.stats = v_u_22
	local v256 = v_u_17.Character
	if not (v256 and v256.Parent) then
		v256 = nil
	end
	if v256 then
		v256 = v256:GetAttribute("FireMode")
	end
	v251.auto = v256 == "auto"
	v251.shot = p236 == true
	v251.ignore = v243
	v251.visible = v_u_209
	return v250(v251)
end
local function v_u_371(p258, p259) -- name: aimTarget
	-- upvalues: (copy) v_u_17, (copy) v_u_168, (ref) v_u_39, (ref) v_u_9, (copy) v_u_203, (ref) v_u_42, (copy) v_u_113, (ref) v_u_22, (copy) v_u_49, (copy) v_u_6, (copy) v_u_4, (copy) v_u_131, (copy) v_u_43, (copy) v_u_257
	local v260 = v_u_17.Character
	if not (v260 and v260.Parent) then
		v260 = nil
	end
	if v260 then
		v260 = v260:FindFirstChild("HumanoidRootPart")
	end
	if not v260 then
		return nil
	end
	local v261 = v_u_168.cursor
	if v261 then
		v_u_39 = nil
		local v_u_262 = v_u_9
		if v_u_262 then
			v_u_262 = v_u_9.controllers.Camera
		end
		local v264, v265 = pcall(function()
			-- upvalues: (copy) v_u_262
			local v263 = v_u_262 and v_u_262.yaw
			if v263 then
				v263 = v_u_262.yaw()
			end
			return v263
		end)
		local v266 = v_u_9.shared.Iso
		local v267 = v266.lookVector
		if not v264 or type(v265) ~= "number" then
			v265 = v266.BASE_YAW
		end
		local v268 = v267(v265, v266.PITCH)
		local _, v269, v270, _, _, v271 = v_u_203(v261 - v268 * 120, v268, 240, v260.Position)
		if v270 and v269 then
			local v272 = v_u_9
			if v272 then
				v272 = v_u_9.controllers.Vision
			end
			local v273
			if v272 and v272.isVisible then
				local v274 = v272.isVisible
				local v275, v276 = pcall(v274, v269)
				v273 = not v275 and true or v276 ~= false
			else
				v273 = true
			end
			if v273 then
				v_u_39 = v270
				return v271 or v269
			end
		end
		local v277 = v261.X
		local v278 = v261.Z
		return Vector3.new(v277, p258, v278)
	end
	if v_u_42 then
		v_u_39 = nil
		local v279 = v_u_203
		local v280 = v_u_42.X
		local v281 = v260.Position.Y + 25
		local v282 = v_u_42.Z
		local _, _, v283, _, _, v284 = v279(Vector3.new(v280, v281, v282), Vector3.new(0, -1, 0), 40, v260.Position)
		if v283 and v284 then
			v_u_39 = v283
			return v284
		end
		local v285 = v_u_42.X
		local v286 = v_u_42.Z
		return Vector3.new(v285, p258, v286)
	end
	local v287 = v_u_113()
	if v287 then
		v_u_39 = nil
		local v288
		if v_u_22 then
			local v289 = v_u_22.range
			v288 = type(v289) ~= "number" and 100 or v_u_22.range
		else
			v288 = 100
		end
		local v290, v291 = v287.ray()
		if v290 and v291 then
			local v292 = v287.target(v288)
			local v293
			if v292 then
				v293 = (v292 - v290).Magnitude
			else
				v293 = v288
			end
			local _, v294, v295 = v_u_203(v290, v291, v293, v260.Position)
			if v295 and v294 then
				local v296 = v_u_9
				if v296 then
					v296 = v_u_9.controllers.Vision
				end
				local v297
				if v296 and v296.isVisible then
					local v298 = v296.isVisible
					local v299, v300 = pcall(v298, v294)
					v297 = not v299 and true or v300 ~= false
				else
					v297 = true
				end
				if v297 then
					v_u_39 = v295
					return v294 + v291 * 0.15
				end
			end
			if p259 ~= true and (v292 == nil or v288 - 0.5 <= v293) then
				v_u_49.rangeCheck(v287, v290, v291, v288)
			end
			return v292 or v290 + v291 * v288
		end
	end
	local v301 = v_u_6.CurrentCamera
	local v302 = v_u_9
	if v302 then
		v302 = v_u_9.controllers.Input
	end
	local v303, v304, v305, v306, v307, v308, v309, v310, v311, v312, v313, v314, v315, v316, v317, v318, v319, v320, v321, v322, v323, v324, v325, v326, v327, v328, v329, v330, v331, v332, v333, v334, v335, v336, v337, v338, v339, v340, v341, v342, v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v358, v359, v360, v361, v362
	if v302 and v302.device then
		local v363 = v302.device
		local v364
		v364, v303 = pcall(v363)
		if v364 and type(v303) == "string" then
			v_u_39 = nil
			if v303 == "Keyboard" and v301 then
				v304 = v_u_4:GetMouseLocation()
				v305 = v301:ViewportPointToRay(v304.X, v304.Y)
				v306, v307, v308, v309, v310, v311 = v_u_203(v305.Origin, v305.Direction.Unit, 900, v260.Position)
				if v308 and v307 then
					v312 = v_u_9
					if v312 then
						v312 = v_u_9.controllers.Vision
					end
					if v312 and v312.isVisible then
						v313 = v312.isVisible
						v314, v315 = pcall(v313, v307)
						v316 = not v314 and true or v315 ~= false
					else
						v316 = true
					end
					if v316 then
						v_u_39 = v308
						return v311 or v307
					end
				end
				v317 = v_u_9
				if v317 then
					v317 = v_u_9.controllers.Input
				end
				v318 = v317 and v317.aimPoint
				if v318 then
					v318 = v317.aimPoint()
				end
				if typeof(v318) ~= "Vector3" then
					return nil
				end
				v319 = v318.X
				v320 = v318.Z
				return Vector3.new(v319, p258, v320)
			else
				v321 = 2
				v322 = false
				v323 = v_u_9
				if v323 then
					v323 = v_u_9.controllers.Input
				end
				if v323 then
					v324 = v323.aimAssist
					if type(v324) == "function" then
						v325 = v323.aimAssist
						v326, v327 = pcall(v325)
						if v326 and type(v327) == "table" then
							v328 = v327.cone
							if type(v328) == "number" then
								v329 = v327.cone
								v321 = math.deg(v329)
								v322 = true
							end
						end
					else
						v321 = 8
					end
				else
					v321 = 8
				end
				v330 = v_u_131()
				v331 = -math.sin(v330)
				v332 = -math.cos(v330)
				v333 = Vector3.new(v331, 0, v332)
				v334 = v260.Position
				v335 = (1 / 0)
				v336 = nil
				for v369, v370 in v_u_43 do
					v337 = v370:FindFirstChild("HumanoidRootPart")
					if not v337 or (not v370.Parent or (v370:GetAttribute("Corpse") == true or v321 > 2.5 and v370:GetAttribute("Lying") == true)) then
						continue
					end
					v338 = v337.Position - v334
					v339 = v338.X
					v340 = v338.Z
					v341 = Vector3.new(v339, 0, v340)
					v342 = v341.Magnitude
					if v342 <= 1 or v342 >= 110 then
						continue
					end
					v343 = v341.Unit:Dot(v333)
					v344 = math.clamp(v343, -1, 1)
					v345 = math.acos(v344)
					v346 = math.deg(v345)
					if v346 >= v321 then
						continue
					end
					v347 = v337.Position
					v348 = v_u_9
					if v348 then
						v348 = v_u_9.controllers.Vision
					end
					if v348 and v348.isVisible then
						v349 = v348.isVisible
						v350, v351 = pcall(v349, v347)
						v352 = not v350 and true or v351 ~= false
					else
						v352 = true
					end
					if not v352 then
						continue
					end
					v353 = v346 * 6 + v342 * 0.2
					if v353 >= v335 then
						continue
					end
					v336 = v370
					v335 = v353
				end
				if v336 then
					v_u_39 = v336
					v354 = v336:FindFirstChild("UpperTorso") or v336:FindFirstChild("HumanoidRootPart")
					v355 = v_u_257
					v356 = v334.X
					v357 = v334.Z
					v358 = Vector3.new(v356, p258, v357)
					v359, v360 = pcall(v355, v336, v358, v322, p259)
					if v359 and typeof(v360) == "Vector3" then
						return v360
					else
						return v354.Position
					end
				else
					v361 = v334.X
					v362 = v334.Z
					return Vector3.new(v361, p258, v362) + v333 * 30
				end
			end
		else
			v303 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			v_u_39 = nil
			if v303 == "Keyboard" and v301 then
				v304 = v_u_4:GetMouseLocation()
				v305 = v301:ViewportPointToRay(v304.X, v304.Y)
				v306, v307, v308, v309, v310, v311 = v_u_203(v305.Origin, v305.Direction.Unit, 900, v260.Position)
				if v308 and v307 then
					v312 = v_u_9
					if v312 then
						v312 = v_u_9.controllers.Vision
					end
					if v312 and v312.isVisible then
						v313 = v312.isVisible
						v314, v315 = pcall(v313, v307)
						v316 = not v314 and true or v315 ~= false
					else
						v316 = true
					end
					if v316 then
						v_u_39 = v308
						return v311 or v307
					end
				end
				v317 = v_u_9
				if v317 then
					v317 = v_u_9.controllers.Input
				end
				v318 = v317 and v317.aimPoint
				if v318 then
					v318 = v317.aimPoint()
				end
				if typeof(v318) ~= "Vector3" then
					return nil
				end
				v319 = v318.X
				v320 = v318.Z
				return Vector3.new(v319, p258, v320)
			else
				v321 = 2
				v322 = false
				v323 = v_u_9
				if v323 then
					v323 = v_u_9.controllers.Input
				end
				if v323 then
					v324 = v323.aimAssist
					if type(v324) == "function" then
						v325 = v323.aimAssist
						v326, v327 = pcall(v325)
						if v326 and type(v327) == "table" then
							v328 = v327.cone
							if type(v328) == "number" then
								v329 = v327.cone
								v321 = math.deg(v329)
								v322 = true
							end
						end
					else
						v321 = 8
					end
				else
					v321 = 8
				end
				v330 = v_u_131()
				v331 = -math.sin(v330)
				v332 = -math.cos(v330)
				v333 = Vector3.new(v331, 0, v332)
				v334 = v260.Position
				v335 = (1 / 0)
				v336 = nil
				for v369, v370 in v_u_43 do
					v337 = v370:FindFirstChild("HumanoidRootPart")
					if not v337 or (not v370.Parent or (v370:GetAttribute("Corpse") == true or v321 > 2.5 and v370:GetAttribute("Lying") == true)) then
						continue
					end
					v338 = v337.Position - v334
					v339 = v338.X
					v340 = v338.Z
					v341 = Vector3.new(v339, 0, v340)
					v342 = v341.Magnitude
					if v342 <= 1 or v342 >= 110 then
						continue
					end
					v343 = v341.Unit:Dot(v333)
					v344 = math.clamp(v343, -1, 1)
					v345 = math.acos(v344)
					v346 = math.deg(v345)
					if v346 >= v321 then
						continue
					end
					v347 = v337.Position
					v348 = v_u_9
					if v348 then
						v348 = v_u_9.controllers.Vision
					end
					if v348 and v348.isVisible then
						v349 = v348.isVisible
						v350, v351 = pcall(v349, v347)
						v352 = not v350 and true or v351 ~= false
					else
						v352 = true
					end
					if not v352 then
						continue
					end
					v353 = v346 * 6 + v342 * 0.2
					if v353 >= v335 then
						continue
					end
					v336 = v370
					v335 = v353
				end
				if v336 then
					v_u_39 = v336
					v354 = v336:FindFirstChild("UpperTorso") or v336:FindFirstChild("HumanoidRootPart")
					v355 = v_u_257
					v356 = v334.X
					v357 = v334.Z
					v358 = Vector3.new(v356, p258, v357)
					v359, v360 = pcall(v355, v336, v358, v322, p259)
					if v359 and typeof(v360) == "Vector3" then
						return v360
					else
						return v354.Position
					end
				else
					v361 = v334.X
					v362 = v334.Z
					return Vector3.new(v361, p258, v362) + v333 * 30
				end
			end
		end
	else
		v303 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		v_u_39 = nil
		if v303 == "Keyboard" and v301 then
			v304 = v_u_4:GetMouseLocation()
			v305 = v301:ViewportPointToRay(v304.X, v304.Y)
			v306, v307, v308, v309, v310, v311 = v_u_203(v305.Origin, v305.Direction.Unit, 900, v260.Position)
			if v308 and v307 then
				v312 = v_u_9
				if v312 then
					v312 = v_u_9.controllers.Vision
				end
				if v312 and v312.isVisible then
					v313 = v312.isVisible
					v314, v315 = pcall(v313, v307)
					v316 = not v314 and true or v315 ~= false
				else
					v316 = true
				end
				if v316 then
					v_u_39 = v308
					return v311 or v307
				end
			end
			v317 = v_u_9
			if v317 then
				v317 = v_u_9.controllers.Input
			end
			v318 = v317 and v317.aimPoint
			if v318 then
				v318 = v317.aimPoint()
			end
			if typeof(v318) ~= "Vector3" then
				return nil
			end
			v319 = v318.X
			v320 = v318.Z
			return Vector3.new(v319, p258, v320)
		else
			v321 = 2
			v322 = false
			v323 = v_u_9
			if v323 then
				v323 = v_u_9.controllers.Input
			end
			if v323 then
				v324 = v323.aimAssist
				if type(v324) == "function" then
					v325 = v323.aimAssist
					v326, v327 = pcall(v325)
					if v326 and type(v327) == "table" then
						v328 = v327.cone
						if type(v328) == "number" then
							v329 = v327.cone
							v321 = math.deg(v329)
							v322 = true
						end
					end
				else
					v321 = 8
				end
			else
				v321 = 8
			end
			v330 = v_u_131()
			v331 = -math.sin(v330)
			v332 = -math.cos(v330)
			v333 = Vector3.new(v331, 0, v332)
			v334 = v260.Position
			v335 = (1 / 0)
			v336 = nil
			for v369, v370 in v_u_43 do
				v337 = v370:FindFirstChild("HumanoidRootPart")
				if not v337 or (not v370.Parent or (v370:GetAttribute("Corpse") == true or v321 > 2.5 and v370:GetAttribute("Lying") == true)) then
					continue
				end
				v338 = v337.Position - v334
				v339 = v338.X
				v340 = v338.Z
				v341 = Vector3.new(v339, 0, v340)
				v342 = v341.Magnitude
				if v342 <= 1 or v342 >= 110 then
					continue
				end
				v343 = v341.Unit:Dot(v333)
				v344 = math.clamp(v343, -1, 1)
				v345 = math.acos(v344)
				v346 = math.deg(v345)
				if v346 >= v321 then
					continue
				end
				v347 = v337.Position
				v348 = v_u_9
				if v348 then
					v348 = v_u_9.controllers.Vision
				end
				if v348 and v348.isVisible then
					v349 = v348.isVisible
					v350, v351 = pcall(v349, v347)
					v352 = not v350 and true or v351 ~= false
				else
					v352 = true
				end
				if not v352 then
					continue
				end
				v353 = v346 * 6 + v342 * 0.2
				if v353 >= v335 then
					continue
				end
				v336 = v370
				v335 = v353
			end
			if v336 then
				v_u_39 = v336
				v354 = v336:FindFirstChild("UpperTorso") or v336:FindFirstChild("HumanoidRootPart")
				v355 = v_u_257
				v356 = v334.X
				v357 = v334.Z
				v358 = Vector3.new(v356, p258, v357)
				v359, v360 = pcall(v355, v336, v358, v322, p259)
				if v359 and typeof(v360) == "Vector3" then
					return v360
				else
					return v354.Position
				end
			else
				v361 = v334.X
				v362 = v334.Z
				return Vector3.new(v361, p258, v362) + v333 * 30
			end
		end
	end
end
local function v_u_376(p372, p373) -- name: muzzleCFrame
	local v374
	if p372 then
		v374 = p372:FindFirstChild(p373 == 2 and "HeldWeapon2" or "HeldWeapon")
	else
		v374 = p372
	end
	if not (v374 and v374:IsA("Model")) then
		v374 = nil
	end
	local v375
	if v374 then
		v375 = v374.PrimaryPart or v374:FindFirstChild("Handle", true)
		if v375 then
			v375 = v375:FindFirstChild("Muzzle")
		end
		if not (v375 and v375:IsA("Attachment")) then
			v375 = nil
		end
	else
		v375 = nil
	end
	if v375 then
		return v375.WorldCFrame
	else
		if p372 then
			p372 = p372:FindFirstChild("HumanoidRootPart")
		end
		if p372 then
			return p372.CFrame * CFrame.new(0.5, 1.2, -1.5)
		else
			return nil
		end
	end
end
local v_u_377 = {}
local v_u_378 = {}
local function v_u_395(p379, p380, p381, p382, p383) -- name: animateParts
	-- upvalues: (copy) v_u_377
	if p379 then
		local v384
		if p379 then
			v384 = p379.PrimaryPart or p379:FindFirstChild("Handle", true)
			if v384 then
				v384 = v384:FindFirstChild("Grip")
			end
			if not (v384 and v384:IsA("Attachment")) then
				v384 = nil
			end
		else
			v384 = nil
		end
		for _, v385 in p379:GetDescendants() do
			if not (v385:IsA("Weld") or v385:IsA("Motor6D")) or (v385.Name == "WeaponGrip" or not (v385.Part1 and v385.Part0)) then
				continue
			end
			local v386 = v385.Part1.Name
			local v387 = false
			for _, v388 in p380 do
				local v389 = #v388
				if string.sub(v386, 1, v389) ~= v388 then
					continue
				end
				v387 = true
			end
			if not v387 then
				break
			end
			local v390 = v385:GetAttribute("BaseC0")
			if typeof(v390) ~= "CFrame" then
				v385:SetAttribute("BaseC0", v385.C0)
				v390 = v385.C0
			end
			local v391
			if v384 then
				v391 = v385.Part0.CFrame:ToObjectSpace(v384.WorldCFrame)
			else
				v391 = CFrame.identity
			end
			local v392 = v391.Rotation
			local v393 = v_u_377
			local v394 = {
				["weld"] = nil,
				["base"] = nil,
				["offset"] = nil,
				["t"] = 0,
				["dur"] = nil,
				["delay"] = nil,
				["weld"] = v385,
				["base"] = v390,
				["offset"] = v392 * p381 * v392:Inverse(),
				["dur"] = p382,
				["delay"] = p383
			}
			table.insert(v393, v394)
		end
	end
end
function v_u_8._feel(p_u_396) -- name: _feel
	-- upvalues: (ref) v_u_9
	if type(p_u_396) == "table" and p_u_396.pellets then
		local function v397()
			-- upvalues: (ref) v_u_9, (copy) p_u_396
			return v_u_9.lib.ShotgunFeel.get(p_u_396)
		end
		local v398, v399 = pcall(v397)
		if v398 then
			return v399
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_8._bp() -- name: _bp
	-- upvalues: (copy) v_u_8, (ref) v_u_9
	local v400 = v_u_8._bpMod
	if v400 == nil then
		local function v401()
			-- upvalues: (ref) v_u_9
			return v_u_9.lib.BulletPassClient
		end
		local v402
		v402, v400 = pcall(v401)
		if not v402 or type(v400) ~= "table" then
			v400 = false
		end
		v_u_8._bpMod = v400
	end
	return v400 or nil
end
v_u_8._tw = {
	["on"] = false,
	["m2"] = 0,
	["side"] = 1,
	["was"] = false,
	["last2"] = -1,
	["reloadWas"] = false
}
function v_u_8._laserParams(p403) -- name: _laserParams
	-- upvalues: (copy) v_u_8, (copy) v_u_66
	local v404 = v_u_8._bp()
	if v404 then
		return v404.params({ p403 })
	end
	v_u_66.FilterDescendantsInstances = { p403 }
	return v_u_66
end
local function v_u_416(p_u_405, p406, p407) -- name: weaponKick
	-- upvalues: (ref) v_u_9, (copy) v_u_378, (copy) v_u_8, (copy) v_u_395
	if p_u_405 then
		p_u_405 = p_u_405:FindFirstChild(p407 == 2 and "HeldWeapon2" or "HeldWeapon")
	end
	if not (p_u_405 and p_u_405:IsA("Model")) then
		p_u_405 = nil
	end
	if p_u_405 and p406 then
		if p_u_405:GetAttribute("SpinPart") ~= nil then
			local function v408()
				-- upvalues: (ref) v_u_9, (copy) p_u_405
				v_u_9.lib.RotarySpin.shot(p_u_405)
			end
			pcall(v408)
		end
		local v409 = p_u_405:FindFirstChild("WeaponGrip", true)
		if v409 and v409:IsA("Motor6D") then
			local v410 = v_u_378[v409]
			local v411 = v_u_8._feel(p406)
			local v412 = (0.35 + p406.recoil * 0.25) * (not v411 and 1 or v411.kick)
			if v410 then
				local v413 = v410.amount + v412
				v410.amount = math.min(1.6, v413)
			else
				v_u_378[v409] = {
					["amount"] = math.min(1.6, v412)
				}
			end
		end
		local v414 = tonumber(p_u_405:GetAttribute("WeaponScale")) or 1
		if p406.holdType == "pistol" then
			local v415 = v_u_8._bp()
			v_u_395(p_u_405, { "Slide" }, CFrame.new(0, 0, (not v415 and 0.13 or v415.slideTravel(p_u_405, p406, v_u_9.shared)) * v414), 0.07, 0)
			return
		elseif p406.fireModes[1] == "pump" then
			v_u_395(p_u_405, { "Pump", "Slide" }, CFrame.new(0, 0, 0.35 * v414), 0.32, (p406.cycleTime or 0.6) * 0.25)
			return
		elseif p406.fireModes[1] == "bolt" then
			v_u_395(p_u_405, { "Bolt" }, CFrame.new(0, 0, 0.3 * v414), 0.45, (p406.cycleTime or 0.9) * 0.2)
		else
			v_u_395(p_u_405, { "Bolt" }, CFrame.new(0, 0, 0.12 * v414), 0.05, 0)
		end
	else
		return
	end
end
local function v_u_433(p417) -- name: stepKicks
	-- upvalues: (copy) v_u_377, (copy) v_u_378
	for v418 = #v_u_377, 1, -1 do
		local v419 = v_u_377[v418]
		v419.t = v419.t + p417
		if v419.weld.Parent then
			local v420 = v419.t - v419.delay
			if v420 < 0 then
				continue
			end
			if v419.dur <= v420 then
				v419.weld.C0 = v419.base
				table.remove(v_u_377, v418)
			else
				local v421 = v420 / v419.dur
				local v422
				if v421 < 0.35 then
					v422 = v421 / 0.35
				else
					v422 = 1 - (v421 - 0.35) / 0.65
				end
				v419.weld.C0 = v419.offset:Lerp(CFrame.identity, 1 - v422) * v419.base
			end
		else
			table.remove(v_u_377, v418)
		end
	end
	for v423, v424 in v_u_378 do
		if v423.Parent then
			local v425 = v424.amount
			local v426 = p417 * 9
			local v427 = v424.amount
			local v428 = v425 - v426 * math.max(0.4, v427)
			v424.amount = math.max(0, v428)
			local v429 = v424.amount
			local v430 = CFrame.new(0, 0, v429 * 0.06)
			local v431 = CFrame.Angles
			local v432 = v429 * 3.5
			v423.Transform = v430 * v431(math.rad(v432), 0, 0)
			if v429 > 0.001 then
				continue
			end
			v423.Transform = CFrame.identity
			v_u_378[v423] = nil
		else
			v_u_378[v423] = nil
		end
	end
end
local v_u_434 = { "HushWall", "HushWallBase", "HushFloor" }
local function v_u_444(p435, p436, p437) -- name: wallBetweenLocal
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_434
	if (p436 - p435).Magnitude < 0.05 then
		return false
	end
	local v438 = table.clone(p437)
	local v439 = RaycastParams.new()
	v439.FilterType = Enum.RaycastFilterType.Exclude
	v439.IgnoreWater = true
	for _ = 1, 6 do
		v439.FilterDescendantsInstances = v438
		local v440 = v_u_6:Raycast(p435, p436 - p435, v439)
		if not v440 then
			return false
		end
		local v441 = v440.Instance
		if v441 ~= v_u_6.Terrain and not v_u_7:HasTag(v441, "HushWindow") then
			for _, v442 in v_u_434 do
				if not v_u_7:HasTag(v441, v442) then
					continue
				end
				return true
			end
			if v441.Name == "Border" then
				return true
			end
			local v443 = v441:FindFirstAncestorOfClass("Model")
			while v443 do
				if v_u_7:HasTag(v443, "HushDoor") then
					return true
				end
				v443 = v443:FindFirstAncestorOfClass("Model")
			end
		end
		table.insert(v438, v441)
		p435 = v440.Position
	end
	return false
end
local function v_u_495(p445, p446, p447, p448, p449) -- name: predictTrace
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (copy) v_u_6, (copy) v_u_168, (copy) v_u_203, (copy) v_u_444, (copy) v_u_66, (ref) v_u_12, (copy) v_u_140, (copy) v_u_3, (ref) v_u_9
	local v450 = v_u_17.Character
	if not (v450 and v450.Parent) then
		v450 = nil
	end
	local v451 = v_u_8._bp()
	local v452 = false
	local v453 = {}
	if v450 then
		table.insert(v453, v450)
		local v454 = v_u_8.rideCar(v450)
		if v454 then
			table.insert(v453, v454)
		end
	end
	local v455 = v_u_6:FindFirstChild("HushCombat")
	if v455 then
		table.insert(v453, v455)
	end
	local v456 = v_u_6:FindFirstChild("Raid")
	if v456 then
		for _, v457 in { "Items", "Extracts", "Spawns" } do
			local v458 = v456:FindFirstChild(v457)
			if not v458 then
				continue
			end
			table.insert(v453, v458)
		end
	end
	local v459 = nil
	if p448 and not v_u_168.legacy then
		local v460 = p448.X
		local v461 = p448.Z
		local v462 = Vector3.new(v460, 0, v461)
		if v462.Magnitude > 0.001 then
			local v463 = v462.Unit
			v459 = {
				["back"] = 1.5,
				["front"] = 0.8,
				["px"] = nil,
				["pz"] = nil,
				["fx"] = nil,
				["fz"] = nil,
				["px"] = p445.X,
				["pz"] = p445.Z,
				["fx"] = v463.X,
				["fz"] = v463.Z
			}
		end
	end
	local v464, v465, v466, _, v467 = v_u_203(p445, p446, p447, p445, v459)
	local v468
	if v464 and (v466 and v459) then
		local v469 = v466:FindFirstChild("HumanoidRootPart")
		v468 = math.max(0, v464)
		if v468 < 1.6 and v469 then
			local v470 = v469.Position
			local v471 = v470.Y - 3
			local v472 = v_u_444
			local v473 = v470.X
			local v474 = p445.Y
			local v475 = v471 + 0.3
			local v476 = v471 + 7
			local v477 = math.clamp(v474, v475, v476)
			local v478 = v470.Z
			if v472(p445, Vector3.new(v473, v477, v478), v453) then
				v464 = nil
				v465 = nil
				v466 = nil
			end
		end
		if v464 then
			v465 = p445 + p446 * (v464 < 1 and 1 or v464)
		else
			v468 = v464
		end
	else
		v468 = v464
	end
	local v479 = v468 and v465 and {
		["pos"] = nil,
		["normal"] = nil,
		["material"] = "Flesh",
		["rig"] = nil,
		["inst"] = nil,
		["part"] = nil,
		["pos"] = v465,
		["normal"] = -p446,
		["rig"] = v466,
		["inst"] = v466,
		["part"] = v467
	} or nil
	local v480
	if v451 then
		v480 = v451.params(v453)
	else
		v480 = v_u_66
	end
	local v481 = p445
	for _ = 1, 4 do
		v480.FilterDescendantsInstances = v453
		local v482 = v_u_6:Raycast(p445, p446 * p447, v480)
		if not v482 then
			return v479
		end
		if v468 and v468 < (v482.Position - v481).Magnitude then
			return v479
		end
		local v483 = v482.Instance
		local v484 = (v482.Position - p445).Magnitude
		if v483.Transparency >= 0.98 and not (v483.CanCollide or v451 and v451.isShell(v483)) then
			table.insert(v453, v483)
			p445 = v482.Position
			p447 = p447 - v484
		elseif v483.Material == Enum.Material.Glass and v483:GetAttribute("Broken") ~= true then
			v_u_12.impact(v482.Position, v482.Normal, "Glass")
			table.insert(v453, v483)
			p445 = v482.Position + p446 * 0.05
			p447 = p447 - v484
		else
			local v485
			if p449 and (v451 and not v452) then
				v485 = v451.doorFor(v483)
			else
				v485 = nil
			end
			if v485 then
				local v486 = v451.passDoor(v_u_12, v482, p446, v453, v485)
				p445 = v486 + p446 * 0.05
				p447 = p447 - (v484 + (v486 - v482.Position).Magnitude)
				v452 = true
			else
				local v487 = v_u_140(v483)
				local v488
				if v487 then
					v488 = v_u_3:GetPlayerFromCharacter(v487)
				else
					v488 = nil
				end
				local v489
				if not v488 or v488 == v_u_17 then
					if v487 == nil then
						v489 = false
					else
						v489 = v487:FindFirstChildOfClass("Humanoid") ~= nil
					end
					return {
						["pos"] = v482.Position,
						["normal"] = v482.Normal,
						["material"] = (v487 or v489) and "Flesh" or v482.Material.Name,
						["rig"] = v487,
						["inst"] = v483
					}
				end
				local v490 = v_u_9.config.flag
				local v491, v492 = pcall(v490, "FriendlyFire")
				local v493 = v450 and v450:GetAttribute("SquadId") or v_u_17:GetAttribute("SquadId")
				local v494 = v487:GetAttribute("SquadId") or v488:GetAttribute("SquadId")
				if v491 then
					if v492 == true and (v493 ~= nil and v493 ~= "") then
						v491 = v493 == v494
					else
						v491 = false
					end
				end
				if v491 then
					if v487 == nil then
						v489 = false
					else
						v489 = v487:FindFirstChildOfClass("Humanoid") ~= nil
					end
					return {
						["pos"] = v482.Position,
						["normal"] = v482.Normal,
						["material"] = (v487 or v489) and "Flesh" or v482.Material.Name,
						["rig"] = v487,
						["inst"] = v483
					}
				end
				table.insert(v453, v487)
				p445 = v482.Position
				p447 = p447 - v484
			end
		end
	end
	return v479
end
local v_u_496 = {
	["metal"] = "impact_ricochet",
	["flesh"] = "impact_flesh"
}
local function v_u_512(p497, p498, p499) -- name: clampOriginLocal
	-- upvalues: (copy) v_u_6, (copy) v_u_8
	local v500 = p498 - p497
	if v500.Magnitude < 0.05 then
		return p498
	end
	local v501 = {}
	if p499 then
		table.insert(v501, p499)
	end
	for _, v502 in { v_u_6:FindFirstChild("HushCombat"), v_u_6:FindFirstChild("HushLocal") } do
		table.insert(v501, v502)
	end
	local v503 = v_u_6:FindFirstChild("Raid")
	if v503 then
		for _, v504 in { "Items", "Extracts", "Spawns" } do
			local v505 = v503:FindFirstChild(v504)
			if not v505 then
				continue
			end
			table.insert(v501, v505)
		end
	end
	local v506 = RaycastParams.new()
	v506.FilterType = Enum.RaycastFilterType.Exclude
	v506.IgnoreWater = true
	local v507 = v_u_8._bp()
	v506.CollisionGroup = v507 and (v507.group() or "Default") or "Default"
	for _ = 1, 4 do
		v506.FilterDescendantsInstances = v501
		local v508 = v_u_6:Raycast(p497, p498 - p497, v506)
		if not v508 then
			return p498
		end
		local v509 = v508.Instance
		local v510 = v509:FindFirstAncestorOfClass("Model")
		local v511
		if v510 == nil then
			v511 = false
		else
			v511 = v510:FindFirstChildOfClass("Humanoid") ~= nil
		end
		if (v509.Transparency < 0.98 or (v509.CanCollide or v507 and v507.isShell(v509))) and not v511 then
			return v508.Position - v500.Unit * 0.1
		end
		if v511 then
			v509 = v510
		end
		table.insert(v501, v509)
		p497 = v508.Position
	end
	return p498
end
local function v_u_580(p_u_513, p514, p515, p516, p517, p518, p_u_519) -- name: sendAndPredict
	-- upvalues: (ref) v_u_31, (copy) v_u_17, (copy) v_u_106, (ref) v_u_9, (copy) v_u_8, (ref) v_u_10, (ref) v_u_14, (ref) v_u_21, (copy) v_u_168, (copy) v_u_495, (ref) v_u_12, (copy) v_u_496, (copy) v_u_416
	v_u_31 = v_u_31 + 1
	local v520 = v_u_31
	local v521 = v_u_17.Character
	if not (v521 and v521.Parent) then
		v521 = nil
	end
	if v521 then
		v521 = v521:GetAttribute("WeaponUid")
	end
	local v522 = v_u_106()
	local v523 = v_u_9.net.fire
	local v524 = "combat.fire"
	local v525 = {
		["id"] = v520,
		["o"] = p514,
		["d"] = p515,
		["u"] = v521,
		["a"] = v522,
		["sp"] = p516
	}
	local v526
	if v_u_8._noAy then
		v526 = nil
	else
		v526 = p518
	end
	v525.ay = v526
	v525.sd = v_u_8._tw.on and (p_u_519 or 1) or nil
	v523(v524, v525)
	local v527 = v_u_10.shotDir
	if p_u_513.pellets then
		p516 = p516 * 0.4
	end
	local v528 = v527(p515, p516, v520)
	local v529 = p_u_513.flare and {} or (not p_u_513.pellets and { v528 } or v_u_10.pelletDirs(v528, v_u_10.pelletCone(p_u_513, v522), p_u_513.pellets, v520))
	local v_u_530 = p517.Position
	local v531, v532
	if v_u_14 then
		v531, v532 = v_u_14.tints(v_u_17, v_u_21)
	else
		v532 = nil
		v531 = nil
	end
	local v533 = v_u_168.log and {} or nil
	local v534 = 2
	for v535, v536 in v529 do
		local v537 = v_u_8._bp()
		local v538 = v_u_495
		local v539 = p_u_513.range
		local v540
		if v537 == nil then
			v540 = false
		else
			v540 = v537.weaponPasses(p_u_513)
		end
		local v541 = v538(p514, v536, v539, p515, v540)
		local v542
		if v541 then
			v542 = v541.pos
		else
			v542 = p514 + v536 * p_u_513.range
		end
		if p_u_513.tracer and (not p_u_513.pellets or v535 <= 4) and (v542 - v_u_530):Dot(v536) > 0.3 then
			v_u_12.tracer(v_u_530, v542, p_u_513.suppressed and 0.35 or 1, v531)
		end
		if v533 then
			local v543
			if v541 then
				if v541.part then
					v543 = "rig:" .. v541.part
				else
					v543 = v541.material
				end
			else
				v543 = "miss"
			end
			local v544 = string.format
			local v545 = not v541 and -1 or (v541.pos - p514).Magnitude
			table.insert(v533, v544("%s@%.1f", v543, v545))
		end
		if not v541 then
			continue
		end
		if v541.material == "Flesh" then
			v_u_12.blood(v541.pos, -v536 + v541.normal * 0.3, p_u_513.pellets and 0.25 or 0.6)
		else
			v_u_12.impact(v541.pos, v541.normal, v541.material)
		end
		if v534 > 0 and (v541.pos - p514).Magnitude < 90 then
			v534 = v534 - 1
			local v546 = v541.pos
			local v547 = v541.material
			local v548 = v_u_496[v_u_12.surfaceKind(v547)] or "impact_wall"
			local v549 = v_u_9
			if v549 then
				v549 = v_u_9.controllers.Audio
			end
			if v549 and v549.play3D then
				local v550 = v549.play3D
				pcall(v550, v548, v546, nil)
			end
		end
		v_u_9.emit("weapon.hit", v541.inst, v541.pos, v541.material)
	end
	if v533 and v_u_168.log then
		local v551 = v_u_168.log
		local v552 = string.format
		local v553 = v_u_21
		local v554 = tostring(v553)
		local v555 = p514.X
		local v556 = p514.Y
		local v557 = p514.Z
		local v558 = math.deg(p518 or 0)
		local v559 = table.concat
		table.insert(v551, v552("%s o=%.1f,%.1f,%.1f ay=%.0f %s", v554, v555, v556, v557, v558, v559(v533, " ")))
		while #v551 > 200 do
			table.remove(v551, 1)
		end
	end
	local v560 = v_u_8._feel(p_u_513)
	v_u_12.muzzle(p517, (p_u_513.flash or 1) * (not v560 and 1 or v560.flash), p_u_513.suppressed == true, v532)
	local v_u_561 = v_u_9
	if v_u_561 then
		v_u_561 = v_u_9.controllers.Audio
	end
	if v_u_561 and v_u_561.gunshot then
		local v562 = v_u_561.gunshot
		local v563 = v_u_21
		local v564 = p_u_513.suppressed == true
		pcall(v562, v563, v_u_530, v564, true)
	end
	if v560 and not p_u_513.suppressed then
		local function v565()
			-- upvalues: (ref) v_u_9, (copy) v_u_561, (copy) v_u_530, (copy) p_u_513
			v_u_9.lib.ShotgunFeel.boom(v_u_561, v_u_530, p_u_513, true)
		end
		pcall(v565)
	end
	local v566 = v_u_9
	if v566 then
		v566 = v_u_9.controllers.Camera
	end
	if v566 and v566.shake then
		local v567 = v566.shake
		local v568 = (0.05 + p_u_513.recoil * 0.035) * (not v560 and 1 or v560.shake)
		local v569 = (0.08 + p_u_513.recoil * 0.025) * (not v560 and 1 or 1 + (v560.shake - 1) * 0.5)
		pcall(v567, v568, v569)
	end
	if p_u_513.casing then
		local v570 = v_u_17.Character
		if not (v570 and v570.Parent) then
			v570 = nil
		end
		if v570 then
			v570 = v570:FindFirstChild(p_u_519 == 2 and "HeldWeapon2" or "HeldWeapon")
		end
		if not (v570 and v570:IsA("Model")) then
			v570 = nil
		end
		local v571
		if v570 then
			v571 = v570.PrimaryPart or v570:FindFirstChild("Handle", true)
			if v571 then
				v571 = v571:FindFirstChild("Eject")
			end
			if not (v571 and v571:IsA("Attachment")) then
				v571 = nil
			end
		else
			v571 = nil
		end
		local v_u_572
		if v571 then
			v_u_572 = v571.WorldCFrame
		else
			v_u_572 = p517 * CFrame.new(0.1, 0, 1)
		end
		if p_u_513.fireModes[1] == "pump" or p_u_513.fireModes[1] == "bolt" then
			task.delay((p_u_513.cycleTime or 0.6) * 0.45, function()
				-- upvalues: (ref) v_u_17, (copy) p_u_519, (ref) v_u_12, (copy) v_u_572, (copy) p_u_513
				local v573 = v_u_17.Character
				if not (v573 and v573.Parent) then
					v573 = nil
				end
				local v574 = p_u_519
				if v573 then
					v573 = v573:FindFirstChild(v574 == 2 and "HeldWeapon2" or "HeldWeapon")
				end
				if not (v573 and v573:IsA("Model")) then
					v573 = nil
				end
				local v575
				if v573 then
					v575 = v573.PrimaryPart or v573:FindFirstChild("Handle", true)
					if v575 then
						v575 = v575:FindFirstChild("Eject")
					end
					if not (v575 and v575:IsA("Attachment")) then
						v575 = nil
					end
				else
					v575 = nil
				end
				local v576 = v_u_12.casing
				local v577
				if v575 then
					v577 = v575.WorldCFrame
				else
					v577 = v_u_572
				end
				v576(v577, p_u_513.casing)
			end)
		else
			v_u_12.casing(v_u_572, p_u_513.casing)
		end
	end
	local v578 = v_u_416
	local v579 = v_u_17.Character
	if not (v579 and v579.Parent) then
		v579 = nil
	end
	v578(v579, p_u_513, p_u_519)
	v_u_9.emit("weapon.fired", (0.45 + p_u_513.recoil * 0.28) * (not v560 and 1 or v560.kick), v_u_21, p_u_519)
end
local v_u_584 = {
	["t"] = 0,
	["dur"] = 0,
	["win"] = 1.2,
	["meleeHitT"] = 0,
	["uid"] = nil,
	["on"] = function() -- name: on
		-- upvalues: (copy) v_u_584, (copy) v_u_17
		local v581
		if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win then
			v581 = false
			local v582 = v_u_17.Character
			if not (v582 and v582.Parent) then
				v582 = nil
			end
			if v582 then
				v582 = v582:GetAttribute("Reloading")
			end
			if v582 ~= true then
				local v583 = v_u_17.Character
				if not (v583 and v583.Parent) then
					v583 = nil
				end
				if v583 then
					v583 = v583:GetAttribute("WeaponUid")
				end
				v581 = v583 == v_u_584.uid
			end
		else
			v581 = false
		end
		return v581
	end
}
local v_u_585 = {
	["t"] = 0,
	["fromUid"] = nil,
	["slot"] = nil,
	["id"] = nil,
	["stats"] = nil,
	["win"] = 1.2,
	["refusedChar"] = nil,
	["refusedSeen"] = nil,
	["refusedCues"] = 0,
	["lastUid"] = nil,
	["log"] = nil,
	["switches"] = 0,
	["log"] = {}
}
local v_u_586 = { "primary", "secondary", "melee" }
function v_u_585.note(p587) -- name: note
	-- upvalues: (copy) v_u_585
	local v588 = v_u_585.log
	table.insert(v588, p587)
	if #v_u_585.log > 40 then
		table.remove(v_u_585.log, 1)
	end
end
function v_u_585.pending() -- name: pending
	-- upvalues: (copy) v_u_585, (copy) v_u_17
	local v589
	if v_u_585.t > 0 and os.clock() - v_u_585.t < v_u_585.win then
		local v590 = v_u_17.Character
		if not (v590 and v590.Parent) then
			v590 = nil
		end
		if v590 then
			v590 = v590:GetAttribute("WeaponUid")
		end
		v589 = v590 == v_u_585.fromUid
	else
		v589 = false
	end
	return v589
end
local v_u_594 = {
	["t"] = 0,
	["uid"] = nil,
	["win"] = 1.2,
	["riseT"] = 0,
	["minAge"] = 0.6,
	["n"] = 0,
	["pending"] = function() -- name: pending
		-- upvalues: (copy) v_u_594, (copy) v_u_17
		local v591
		if v_u_594.t > 0 and os.clock() - v_u_594.t < v_u_594.win then
			v591 = false
			local v592 = v_u_17.Character
			if not (v592 and v592.Parent) then
				v592 = nil
			end
			if v592 then
				v592 = v592:GetAttribute("Reloading")
			end
			if v592 == true then
				local v593 = v_u_17.Character
				if not (v593 and v593.Parent) then
					v593 = nil
				end
				if v593 then
					v593 = v593:GetAttribute("WeaponUid")
				end
				v591 = v593 == v_u_594.uid
			end
		else
			v591 = false
		end
		return v591
	end
}
function v_u_585.kit() -- name: kit
	-- upvalues: (copy) v_u_17
	local v595 = {}
	local v596 = v_u_17.Character
	if not (v596 and v596.Parent) then
		v596 = nil
	end
	if v596 then
		v596 = v596:GetAttribute("KitSlots")
	end
	if type(v596) == "string" then
		for v597, v598 in string.gmatch(v596, "(%a+)=([^,]+)") do
			v595[v597] = v598
		end
	end
	return v595
end
local function v_u_603(p599) -- name: cancelLocalReload
	-- upvalues: (copy) v_u_584, (copy) v_u_17, (ref) v_u_1747, (ref) v_u_9
	v_u_584.t = 0
	if v_u_17:GetAttribute("PredReloadAt") ~= nil then
		v_u_17:SetAttribute("PredReloadAt", 0)
	end
	v_u_1747 = 0
	local v600 = v_u_9
	if v600 then
		v600 = v_u_9.controllers.CharacterAnim
	end
	if v600 and v600.cancelReload then
		local v601 = v600.cancelReload
		local v602 = v_u_17.Character
		if not (v602 and v602.Parent) then
			v602 = nil
		end
		pcall(v601, v602, p599)
	end
end
local function v_u_639(p604) -- name: requestSwitch
	-- upvalues: (copy) v_u_8, (ref) v_u_9, (copy) v_u_585, (copy) v_u_17, (copy) v_u_586, (ref) v_u_10, (ref) v_u_22, (copy) v_u_603
	if p604 == "none" or not v_u_8.rideNo("draw") then
		v_u_9.net.fire("combat.equip", {
			["slot"] = p604
		})
		local v605 = v_u_585
		v605.switches = v605.switches + 1
		local v_u_606 = v_u_585.kit()
		local v607
		if v_u_585.pending() then
			v607 = v_u_585.slot
		else
			v607 = v_u_17.Character
			if not (v607 and v607.Parent) then
				v607 = nil
			end
			if v607 then
				v607 = v607:GetAttribute("WeaponSlot")
			end
		end
		local v_u_608
		if p604 == "next" then
			local v609 = table.find(v_u_586, v607) or 0
			v_u_608 = nil
			for v610 = 1, #v_u_586 do
				local v_u_611 = v_u_586[(v609 + v610 - 1) % #v_u_586 + 1]
				if v_u_611 == v607 or not v_u_606[v_u_611] then
					continue
				end
				local function v612()
					-- upvalues: (ref) v_u_9, (copy) v_u_606, (copy) v_u_611
					return v_u_9.lib.InvUISlotHint.drawOk(v_u_606[v_u_611], v_u_611, nil)
				end
				local v613, v614 = pcall(v612)
				if v613 then
					v613 = v614 == false
				end
				if v613 then
					continue
				end
				v_u_608 = v_u_611
			end
		else
			v_u_608 = p604
		end
		if v_u_608 and (v_u_608 ~= v607 and v_u_606[v_u_608]) then
			local function v615()
				-- upvalues: (ref) v_u_9, (copy) v_u_606, (copy) v_u_608
				return v_u_9.lib.InvUISlotHint.drawOk(v_u_606[v_u_608], v_u_608, nil)
			end
			local v616, v617 = pcall(v615)
			if v616 then
				v616 = v617 == false
			end
			if v616 then
				v_u_585.note(string.format("%.3f switch %s refused (slot rule)", os.clock(), p604))
			else
				if not v_u_585.pending() then
					local v618 = v_u_585
					local v619 = v_u_17.Character
					if not (v619 and v619.Parent) then
						v619 = nil
					end
					if v619 then
						v619 = v619:GetAttribute("WeaponUid")
					end
					v618.fromUid = v619
				end
				v_u_585.t = os.clock()
				v_u_585.slot = v_u_608
				v_u_585.id = v_u_606[v_u_608]
				local v620, v621 = v_u_8.perkPack()
				local v622 = v_u_10.forHand
				local v623 = v_u_585.id
				local v624 = nil
				local v625 = {
					["perk"] = v620,
					["slot"] = v_u_608
				}
				local v626
				if v_u_585.pending() and v_u_585.stats then
					v626 = v_u_585.stats
				else
					v626 = v_u_22
				end
				v625.prevStats = v626
				v625.training = v621
				local v627, v628 = pcall(v622, v623, v624, v625)
				if not v627 or v628 == nil then
					local v629 = v_u_10.stats
					local v630 = v_u_585.id
					v627, v628 = pcall(v629, v630, nil)
				end
				local v631 = v_u_585
				if not v627 then
					v628 = nil
				end
				v631.stats = v628
				local v632 = v_u_585
				local v633 = v_u_17:GetNetworkPing()
				local v634 = math.clamp(v633, 0, 0.6) * 4 + 0.6
				v632.win = math.max(1.2, v634)
				local v635 = v_u_585.note
				local v636 = string.format
				local v637 = os.clock()
				local v638 = v_u_585.id
				v635(v636("%.3f switch %s -> %s", v637, p604, (tostring(v638))))
				v_u_603()
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_658() -- name: requestReload
	-- upvalues: (copy) v_u_585, (ref) v_u_9, (copy) v_u_17, (copy) v_u_594, (ref) v_u_22, (copy) v_u_584, (ref) v_u_23, (copy) v_u_8, (copy) v_u_79, (copy) v_u_2
	if v_u_585.pending() then
		return
	else
		local v640 = v_u_9.net.fire
		local v641 = "combat.reload"
		local v642 = {}
		local v643 = v_u_17.Character
		if not (v643 and v643.Parent) then
			v643 = nil
		end
		if v643 then
			v643 = v643:GetAttribute("WeaponUid")
		end
		v642.u = v643
		v640(v641, v642)
		v_u_594.t = 0
		local v644 = v_u_22
		local v645 = v_u_17.Character
		if not (v645 and v645.Parent) then
			v645 = nil
		end
		if v644 and (v644.kind == "firearm" and (v645 and (v645:GetAttribute("Reloading") ~= true and (v645:GetAttribute("Jammed") ~= true and not v_u_584.on())))) then
			if (v_u_23 < (v644.capacity or 0) or v_u_8._tw.on and v_u_8._tw.m2 < v_u_9.lib.TwinFire.cap2(v_u_79, v_u_22)) and ((tonumber(v645:GetAttribute("AmmoReserve")) or 0) > 0 and not v_u_9.shared.EquipGate.blocked(v645:GetAttribute("EquipUntil"), v_u_2.now())) then
				local v646 = v_u_17:GetNetworkPing()
				local v647 = math.clamp(v646, 0, 0.6)
				local v648 = v_u_584
				local v649
				if v644.reloadKind == "single" then
					v649 = (v644.reloadTime or 0) + (v644.reloadPerRound or 0.5) * ((v644.capacity or 1) - v_u_23)
				else
					v649 = v_u_9.shared.PerkWeapon.reloadTime(v644, v_u_8.perkPack(), v_u_23, v644.capacity) * (v_u_23 <= 0 and 1.12 or 1)
				end
				v648.dur = v649 + v647
				if v645:GetAttribute("Sprinting") == true then
					local v650 = v_u_584
					v650.dur = v650.dur * 1.5
				end
				v_u_584.t = os.clock()
				v_u_594.riseT = v_u_584.t
				local v651 = v_u_584
				local v652 = v_u_17.Character
				if not (v652 and v652.Parent) then
					v652 = nil
				end
				if v652 then
					v652 = v652:GetAttribute("WeaponUid")
				end
				v651.uid = v652
				local v653 = v_u_584
				local v654 = v647 * 4 + 0.6
				v653.win = math.max(1.8, v654)
				v_u_17:SetAttribute("PredReloadAt", v_u_584.t)
				local v655 = v_u_9
				if v655 then
					v655 = v_u_9.controllers.CharacterAnim
				end
				if v655 and v655.reload then
					local v656 = v655.reload
					local v657 = v_u_584.dur
					pcall(v656, v657, v645)
				end
			end
		else
			return
		end
	end
end
local function v_u_672() -- name: cancelReloadInput
	-- upvalues: (ref) v_u_22, (copy) v_u_585, (copy) v_u_594, (copy) v_u_17, (copy) v_u_584, (ref) v_u_9, (copy) v_u_603, (ref) v_u_1552, (ref) v_u_1679
	local v659 = v_u_22
	if v659 and v659.kind == "firearm" then
		local v660
		if v_u_585.pending() or v_u_594.pending() then
			v660 = false
		else
			v660 = true
			local v661 = v_u_17.Character
			if not (v661 and v661.Parent) then
				v661 = nil
			end
			if v661 then
				v661 = v661:GetAttribute("Reloading")
			end
			if v661 ~= true then
				v660 = v_u_584.on()
			end
		end
		if v660 then
			if os.clock() - v_u_594.riseT < v_u_594.minAge then
				return true
			end
			local v662 = v_u_9.net.fire
			local v663 = "combat.reload"
			local v664 = {
				["u"] = nil,
				["x"] = true
			}
			local v665 = v_u_17.Character
			if not (v665 and v665.Parent) then
				v665 = nil
			end
			if v665 then
				v665 = v665:GetAttribute("WeaponUid")
			end
			v664.u = v665
			v662(v663, v664)
			v_u_594.t = os.clock()
			local v666 = v_u_594
			local v667 = v_u_17.Character
			if not (v667 and v667.Parent) then
				v667 = nil
			end
			if v667 then
				v667 = v667:GetAttribute("WeaponUid")
			end
			v666.uid = v667
			local v668 = v_u_594
			v668.n = v668.n + 1
			local v669 = v_u_594
			local v670 = v_u_17:GetNetworkPing()
			local v671 = math.clamp(v670, 0, 0.6) * 4 + 0.6
			v669.win = math.max(1.2, v671)
			v_u_603(true)
			v_u_1552 = "RELOAD CANCELLED"
			v_u_1679 = os.clock() + 0.9
			v_u_585.note(string.format("%.3f reload.cancel", os.clock()))
			return true
		end
	end
	return false
end
local function v_u_769() -- name: tryFire
	-- upvalues: (ref) v_u_22, (copy) v_u_17, (copy) v_u_585, (copy) v_u_8, (ref) v_u_24, (ref) v_u_9, (copy) v_u_2, (ref) v_u_1575, (ref) v_u_1552, (ref) v_u_1679, (copy) v_u_584, (copy) v_u_594, (ref) v_u_23, (copy) v_u_658, (copy) v_u_376, (copy) v_u_131, (copy) v_u_371, (copy) v_u_168, (ref) v_u_39, (ref) v_u_10, (copy) v_u_106, (ref) v_u_1573, (copy) v_u_113, (ref) v_u_42, (copy) v_u_512, (copy) v_u_580, (ref) v_u_25
	local v673 = v_u_22
	local v674 = v_u_17.Character
	if not (v674 and v674.Parent) then
		v674 = nil
	end
	local v675 = v_u_17.Character
	if not (v675 and v675.Parent) then
		v675 = nil
	end
	if v675 then
		v675 = v675:FindFirstChild("HumanoidRootPart")
	end
	if not v673 or (v673.kind ~= "firearm" or not (v674 and v675)) then
		return false
	end
	if v_u_585.pending() then
		return false
	end
	local v676 = v_u_8.rideKind(v674)
	if v676 ~= nil and v676 ~= "lean" then
		return false
	end
	if v676 == "lean" and not v_u_8.ride().canFireNow() then
		return false
	end
	local v677 = os.clock()
	if v677 < v_u_24 then
		return false
	end
	if v_u_9.shared.EquipGate.blocked(v674:GetAttribute("EquipUntil"), v_u_2.now(), 0.05) then
		return false
	end
	if v674:GetAttribute("Jammed") == true then
		if not v_u_1575 then
			v_u_1575 = true
			local v678 = v675.Position
			local v679 = v_u_9
			if v679 then
				v679 = v_u_9.controllers.Audio
			end
			if v679 and v679.play3D then
				local v680 = v679.play3D
				pcall(v680, "wpn_dry", v678, nil)
			end
			local v681 = "JAMMED  "
			local v682 = v_u_9
			if v682 then
				v682 = v_u_9.controllers.Input
			end
			local v683
			if v682 and v682.hint then
				local v684 = v682.hint
				local v685, v686 = pcall(v684, "reload")
				v683 = (not v685 or (type(v686) ~= "string" or v686 == "")) and "" or "[" .. v686 .. "]"
			else
				v683 = ""
			end
			v_u_1552 = v681 .. v683
			v_u_1679 = os.clock() + 1.2
		end
		return false
	end
	if (v674:GetAttribute("Reloading") == true or v_u_584.on()) and (not v_u_594.pending() and (v673.reloadKind ~= "single" or v_u_23 <= 0)) then
		return false
	end
	local v_u_687 = v_u_8._tw.on and (v_u_9.lib.TwinFire.pick(v_u_8._tw, v_u_23) or 0) or 1
	local v688
	if v_u_8._tw.on then
		v688 = v_u_687 == 0
	else
		v688 = v_u_23 <= 0
	end
	if v688 then
		if not v_u_1575 then
			v_u_1575 = true
			v_u_24 = v677 + 0.25
			local v689 = v675.Position
			local v690 = v_u_9
			if v690 then
				v690 = v_u_9.controllers.Audio
			end
			if v690 and v690.play3D then
				local v691 = v690.play3D
				pcall(v691, "wpn_dry", v689, nil)
			end
			if (tonumber(v674:GetAttribute("AmmoReserve")) or 0) > 0 then
				v_u_658()
			end
		end
		return false
	end
	local v692 = v_u_376(v674, v_u_687)
	local v693 = v_u_131()
	local v694 = -math.sin(v693)
	local v695 = -math.cos(v693)
	local v696 = Vector3.new(v694, 0, v695)
	local v697 = v692.Position.Y
	local v698 = v675.Position.Y + 0.6
	local v699 = math.max(v697, v698)
	local v700 = v675.Position.Y - 2.4
	local v701 = v675.Position.Y + 3.4
	local v702 = math.clamp(v699, v700, v701)
	local v703 = v_u_371(v702, true)
	local v704 = nil
	local v705
	if v_u_168.legacy then
		local v706 = v675.Position.X
		local v707 = v675.Position.Z
		v705 = Vector3.new(v706, v702, v707) + v696 * 0.8
	else
		local v708 = v675.Position
		if v703 and v_u_39 then
			local v709 = v703.X - v708.X
			local v710 = v703.Z - v708.Z
			local v711 = Vector3.new(v709, 0, v710)
			local v712 = v711.Magnitude
			if v702 < v703.Y and v712 < 3.5 then
				local v713 = v703.Y
				local v714 = v708.Y + 2.9
				v702 = math.min(v713, v714)
			end
			local v715 = v708.X
			local v716 = v708.Z
			v705 = Vector3.new(v715, v702, v716)
			local v717 = v703 - v705
			if v712 < 0.35 then
				local v718 = v_u_39:FindFirstChild("HumanoidRootPart")
				local v719
				if v718 then
					local v720 = v718.Position.X - v708.X
					local v721 = v718.Position.Z - v708.Z
					v719 = Vector3.new(v720, 0, v721)
				else
					v719 = Vector3.new(0, 0, 0)
				end
				if v719.Magnitude > 0.2 then
					v704 = v719.Unit
				else
					v704 = v696
				end
				if v717.Y < -0.8 then
					v704 = (v704 * 0.4 + Vector3.new(0, -1, 0)).Unit
				end
			else
				v704 = v717.Unit
				if v704.Y > 0.6 or v704.Y < -0.93 then
					local v722 = v704.Y > 0 and 0.6 or -0.93
					local v723 = 1 - v722 * v722
					local v724 = math.sqrt(v723)
					v704 = (v711.Unit * v724 + Vector3.new(0, v722, 0)).Unit
				end
			end
			local v725 = -v704.X
			local v726 = -v704.Z
			v693 = math.atan2(v725, v726)
		else
			local v727 = v708.X
			local v728 = v708.Z
			v705 = Vector3.new(v727, v702, v728)
			local v729 = not v703 and Vector3.new(0, 0, 0) or v703 - v705
			local v730 = v729.X
			local v731 = v729.Z
			if Vector3.new(v730, 0, v731).Magnitude < 3 then
				v704 = v696
			else
				v704 = v729.Unit
			end
			if v704.Y > 0.6 or v704.Y < -0.93 then
				v704 = v696
			end
		end
	end
	if v_u_168.legacy and v703 then
		local v732 = v703 - v705
		local v733 = v732.X
		local v734 = v732.Z
		local v735 = Vector3.new(v733, 0, v734)
		local v736
		if v732.Y < -0.8 then
			v736 = v_u_39 ~= nil
		else
			v736 = false
		end
		if v736 then
			local v737 = v675.Position.X
			local v738 = v675.Position.Z
			v705 = Vector3.new(v737, v702, v738)
			v732 = v703 - v705
			local v739 = v732.X
			local v740 = v732.Z
			v735 = Vector3.new(v739, 0, v740)
		end
		if v735.Magnitude < (v736 and 0.3 or 3) then
			if v736 then
				v696 = (v696 * 0.4 + Vector3.new(0, -1, 0)).Unit
			end
		else
			v696 = v732.Unit
			if v696.Y > 0.6 or v696.Y < -0.93 then
				local v741 = v696.Y > 0 and 0.6 or -0.93
				local v742 = 1 - v741 * v741
				local v743 = math.sqrt(v742)
				v696 = (v735.Unit * v743 + Vector3.new(0, v741, 0)).Unit
			end
		end
	elseif not v_u_168.legacy then
		v696 = v704
	end
	local v744
	if v676 == nil then
		v744 = v675.AssemblyLinearVelocity.Magnitude > 2
	else
		v744 = false
	end
	local v745 = v_u_8.calmSpread(v_u_10.spread(v673, v_u_106(), v744, v_u_1573, v674:GetAttribute("Sprinting") == true), v673, (v_u_106()))
	local v746
	if v676 == "lean" then
		v746 = v_u_8.ride()
	else
		v746 = nil
	end
	local v747
	if v746 == nil then
		v747 = v674
	else
		local v748 = v746.model(v674)
		v745 = v745 * v746.spreadMul(v746.speed(v748))
		v673 = table.clone(v673)
		v673.recoil = v673.recoil * v746.recoilMul()
		v747 = v748 or v674
	end
	local v749 = v_u_113()
	local v750, v751, v752, v753
	if v749 and (not v_u_168.legacy and (v_u_168.cursor == nil and v_u_42 == nil)) then
		v750, v751, v752 = v749.shot(v675, v674, v673.range, v703)
		if v750 and (v751 and v752) then
			local function v754()
				-- upvalues: (ref) v_u_9, (ref) v_u_687
				return v_u_9.lib.Viewmodel.muzzleCF(v_u_687)
			end
			local v755
			v755, v753 = pcall(v754)
			if v755 then
				if typeof(v753) ~= "CFrame" then
					v753 = v692
				end
			else
				v753 = v692
			end
		else
			v750 = v705
			v752 = v693
			v753 = v692
			v751 = v696
		end
	else
		v750 = v705
		v752 = v693
		v753 = v692
		v751 = v696
	end
	if v746 ~= nil then
		local v756, v757 = v746.aim()
		if v756 ~= nil and v757 ~= nil then
			local v758 = v746.dir
			v751 = Vector3.new(v758(v756, v757))
		end
		v751, v752 = v746.clampShot(v674, v750, v751)
		if v751 == nil then
			return false
		end
	end
	local v759 = v_u_512
	local v760 = v675.Position.X
	local v761 = v750.Y
	local v762 = v675.Position.Z
	local v763 = v759(Vector3.new(v760, v761, v762), v750, v747)
	local v764 = v_u_9
	if v764 then
		v764 = v_u_9.controllers.Input
	end
	if v764 then
		local v765 = v764.noteShot
		if type(v765) == "function" then
			local v766 = v764.noteShot
			pcall(v766)
		end
	end
	v_u_580(v673, v763, v751, v745, v753, v752, v_u_687)
	if v_u_8._tw.on then
		if v_u_9.lib.TwinFire.spent(v_u_8._tw, v_u_687) then
			v_u_23 = v_u_23 - 1
		end
	else
		v_u_23 = v_u_23 - 1
	end
	v_u_25 = v677
	if v677 - v_u_24 < 0.05 then
		v677 = v_u_24
	end
	v_u_24 = v677 + v_u_10.interval(v673)
	local v767 = v673.bloomMax
	local v768 = v_u_1573 + v673.bloom * (v_u_106() and 0.6 or 1)
	v_u_1573 = math.min(v767, v768)
	return true
end
local v_u_770 = false
local function v_u_804(p771, p772, p773) -- name: meleeAssistDir
	-- upvalues: (ref) v_u_9, (ref) v_u_10
	local v774 = v_u_9
	if v774 then
		v774 = v_u_9.controllers.ZombieRender
	end
	if v774 and v774.targets then
		local v775 = p771.meleeRange
		local v776 = (tonumber(v775) or 4.5) + 1.6
		local v777 = v774.targets
		local v778, v779 = pcall(v777, p772, v776)
		if v778 and type(v779) == "table" then
			local v_u_780 = v_u_9
			if v_u_780 then
				v_u_780 = v_u_9.controllers.Input
			end
			local v781, v782 = pcall(function()
				-- upvalues: (copy) v_u_780
				if v_u_780 and v_u_780.aimPoint then
					return v_u_780.aimPoint()
				else
					return nil
				end
			end)
			if not v781 or typeof(v782) ~= "Vector3" then
				v782 = nil
			end
			local v783 = p771.meleeArc
			local v784 = (tonumber(v783) or 90) * 0.5
			local v785 = math.rad(v784)
			local v786 = (1 / 0)
			local v787 = nil
			for _, v788 in v779 do
				local v789 = v788.position
				if typeof(v789) ~= "Vector3" or v788.visible == false then
					continue
				end
				local v790 = v789.X - p772.X
				local v791 = v789.Z - p772.Z
				local v792 = Vector3.new(v790, 0, v791)
				local v793 = v792.Magnitude
				if v793 <= 0.05 then
					continue
				end
				local v794 = v_u_10.meleeInArc(p771, v792, p773, nil)
				local v795 = v792.Unit:Dot(p773)
				local v796 = math.clamp(v795, -1, 1)
				local v797 = math.acos(v796)
				if not v794 then
					if v793 <= v776 and v797 <= v785 + 0.4363323129985824 then
						v794 = true
					elseif v793 <= 2.6 then
						v794 = v797 <= 1.7453292519943295
					else
						v794 = false
					end
				end
				if not v794 then
					continue
				end
				local v798
				if v782 then
					local v799 = v789.X - v782.X
					local v800 = v789.Z - v782.Z
					v798 = Vector3.new(v799, 0, v800).Magnitude
				else
					v798 = v797 * 4 + v793 * 0.2
				end
				if v798 >= v786 then
					continue
				end
				v787 = v792
				v786 = v798
			end
			if v787 then
				local v801 = v787.Unit
				local v802 = v801:Dot(p773)
				local v803 = math.clamp(v802, -1, 1)
				if math.acos(v803) > 0.9599310885968813 then
					return p773
				else
					return v801
				end
			else
				return p773
			end
		else
			return p773
		end
	else
		return p773
	end
end
local function v_u_856() -- name: swing
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (copy) v_u_585, (ref) v_u_22, (ref) v_u_9, (ref) v_u_10, (ref) v_u_21, (ref) v_u_32, (ref) v_u_770, (ref) v_u_18, (copy) v_u_99, (copy) v_u_856, (ref) v_u_38, (copy) v_u_584, (ref) v_u_1552, (ref) v_u_1679, (copy) v_u_804, (copy) v_u_131, (copy) v_u_2, (copy) v_u_76
	local v_u_805 = v_u_17.Character
	if not (v_u_805 and v_u_805.Parent) then
		v_u_805 = nil
	end
	local v806 = v_u_17.Character
	if not (v806 and v806.Parent) then
		v806 = nil
	end
	if v806 then
		v806 = v806:FindFirstChild("HumanoidRootPart")
	end
	if v_u_805 and v806 then
		if v_u_8.rideNo("melee") then
			return
		else
			local v807 = os.clock()
			local v_u_808
			if v_u_585.pending() and v_u_585.stats then
				v_u_808 = v_u_585.stats
			else
				v_u_808 = v_u_22
			end
			local v809 = not v_u_808 or v_u_808.kind ~= "melee"
			local v810, v811 = v_u_8.perkPack()
			local v_u_812
			if v809 then
				v_u_812 = v_u_9.shared.PerkWeapon.shove(v_u_10.SHOVE, v810, v811)
			else
				v_u_812 = v_u_808
			end
			local v_u_813
			if v809 then
				v_u_813 = "fists"
			elseif v_u_808 == v_u_22 then
				v_u_813 = v_u_21
			else
				v_u_813 = v_u_585.id
			end
			if v807 < v_u_32 then
				if not v_u_770 and v_u_32 - v807 <= 0.25 then
					v_u_770 = true
					task.delay(v_u_32 - v807 + 0.01, function()
						-- upvalues: (ref) v_u_770, (ref) v_u_18, (ref) v_u_99, (ref) v_u_585, (ref) v_u_22, (copy) v_u_808, (ref) v_u_17, (copy) v_u_805, (ref) v_u_856
						v_u_770 = false
						if v_u_18 and v_u_99() then
							local v814
							if v_u_585.pending() and v_u_585.stats then
								v814 = v_u_585.stats
							else
								v814 = v_u_22
							end
							if v814 == v_u_808 then
								local v815 = v_u_17.Character
								if not (v815 and v815.Parent) then
									v815 = nil
								end
								if v815 == v_u_805 then
									v_u_856()
								end
							end
						end
					end)
				end
				return
			else
				local v816 = tonumber(v_u_805:GetAttribute("Stamina"))
				local v_u_817 = v_u_9.shared.KatanaRules
				local v818
				if v_u_817 == nil or v809 then
					v818 = false
				else
					local v819 = v_u_9.config.flag
					local v820, v821 = pcall(v819, "Katana")
					v818 = v_u_817.thirdByAttr(v_u_813, v_u_805:GetAttribute("KatanaChain"), v807 - v_u_38, not v820 or v821 ~= false)
					if v818 then
						v_u_812 = v_u_817.heavyStats(v_u_812)
					end
				end
				local v822 = v_u_9.shared.PerkWeapon.swing
				local v823 = {
					["perk"] = v810,
					["chain"] = v_u_584.rhChain,
					["lastHit"] = v_u_584.meleeHitT
				}
				local v824
				if v_u_10.meleeCycle then
					v824 = v_u_10.meleeCycle(v_u_812, v816)
				else
					v824 = v_u_812.meleeTime or 0.7
				end
				local v825, v826, v827 = v822(v823, v807, v824, v_u_812.staminaCost or 10)
				if v_u_805:GetAttribute("Exhausted") == true or v816 and v816 < v826 * 0.5 then
					v_u_1552 = "EXHAUSTED"
					v_u_1679 = os.clock() + 0.8
				else
					v_u_584.rhChain = v827
					v_u_32 = v807 + v825
					v_u_38 = v807
					local v828 = v_u_804
					local v829 = v806.Position
					local v830 = v_u_131()
					local v831 = -math.sin(v830)
					local v832 = -math.cos(v830)
					local v_u_833 = v828(v_u_812, v829, (Vector3.new(v831, 0, v832)))
					v_u_9.net.fire("combat.melee", {
						["d"] = v_u_833
					})
					if (tonumber(v_u_805:GetAttribute("SwingSlowTime")) or 0) > 0 then
						v_u_805:SetAttribute("MeleeSwingAt", v_u_2.now())
					end
					if v818 then
						local v_u_834 = v806.Position
						task.delay(v_u_817.HEAVY.swish, function()
							-- upvalues: (ref) v_u_76, (copy) v_u_817, (copy) v_u_834
							v_u_76(v_u_817.HEAVY_SOUND, v_u_834, "swing")
						end)
					else
						v_u_76(v_u_813, v806.Position, "swing")
					end
					v_u_9.emit("weapon.melee", v809 and "shove" or v_u_813)
					local v835 = v_u_585.note
					local v836 = string.format
					local v837 = os.clock()
					local v838 = tostring(v_u_813)
					local v839 = v_u_585.pending
					v835(v836("%.3f swing %s pending=%s", v837, v838, (tostring(v839()))))
					local v840 = v_u_812.meleeRange
					local v_u_841 = tonumber(v840)
					if not v_u_841 then
						local v842 = v_u_812.range
						v_u_841 = tonumber(v842) or 4
					end
					local v843 = task.delay
					local v844 = v_u_812.meleeWindup
					local v845 = tonumber(v844) or 0.12
					v843(math.max(0.05, v845), function()
						-- upvalues: (ref) v_u_17, (ref) v_u_9, (copy) v_u_805, (copy) v_u_841, (ref) v_u_10, (ref) v_u_812, (copy) v_u_833, (ref) v_u_76, (copy) v_u_813, (ref) v_u_584
						local v846 = v_u_17.Character
						if not (v846 and v846.Parent) then
							v846 = nil
						end
						if v846 then
							v846 = v846:FindFirstChild("HumanoidRootPart")
						end
						local v847 = v_u_9
						if v847 then
							v847 = v_u_9.controllers.ZombieRender
						end
						if v846 and (v847 and v847.targets) then
							local v848 = v_u_17.Character
							if not (v848 and v848.Parent) then
								v848 = nil
							end
							if v848 == v_u_805 then
								local v849 = v847.targets
								local v850 = v846.Position
								local v851 = v_u_841 + 2
								local v852, v853 = pcall(v849, v850, v851)
								for _, v854 in (not v852 or type(v853) ~= "table") and {} or v853 do
									local v855 = v854.position
									if typeof(v855) ~= "Vector3" or (v854.visible == false or not v_u_10.meleeInArc(v_u_812, v855 - v846.Position, v_u_833, nil)) then
										continue
									end
									v_u_76(v_u_813, v855, "hit")
									v_u_584.meleeHitT = os.clock()
									return
								end
								return
							end
						end
					end)
				end
			end
		end
	else
		return
	end
end
local function v_u_861() -- name: throwables
	-- upvalues: (copy) v_u_17
	local v857 = {}
	local v858 = v_u_17.Character
	if not (v858 and v858.Parent) then
		v858 = nil
	end
	if v858 then
		v858 = v858:GetAttribute("ThrowableList")
	end
	if type(v858) == "string" then
		for v859 in string.gmatch(v858, "[^,]+") do
			local v860 = string.match(v859, "^([^:]+)")
			if not v860 then
				continue
			end
			table.insert(v857, v860)
		end
	end
	return v857
end
local function v_u_924() -- name: throwTarget
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (ref) v_u_9, (ref) v_u_1716, (ref) v_u_42, (copy) v_u_4, (copy) v_u_113, (ref) v_u_61, (copy) v_u_131, (copy) v_u_66, (copy) v_u_6
	local v862 = v_u_17.Character
	if not (v862 and v862.Parent) then
		v862 = nil
	end
	local v863 = v_u_17.Character
	if not (v863 and v863.Parent) then
		v863 = nil
	end
	if v863 then
		v863 = v863:FindFirstChild("HumanoidRootPart")
	end
	if not (v862 and v863) then
		return nil, nil
	end
	local v864 = v_u_17.Character
	if not (v864 and v864.Parent) then
		v864 = nil
	end
	if v864 then
		v864 = v864:GetAttribute("Throwable")
	end
	local v865
	if type(v864) == "string" then
		v865 = v_u_8.perkThrow(v864) or nil
	else
		v865 = nil
	end
	if not v865 then
		return nil, nil
	end
	local v866 = v862:FindFirstChild("RightHand")
	local v867
	if v866 then
		v867 = v866.Position + Vector3.new(0, 0.4, 0)
	else
		v867 = v863.Position + Vector3.new(0, 1.6, 0)
	end
	local v868 = v_u_9
	if v868 then
		v868 = v_u_9.controllers.Input
	end
	local v869, v870, v871, v872, v873, v874, v875
	if not v_u_1716 or v_u_42 then
		v919 = v868 and v868.aimPoint
		if v919 then
			v919 = v868.aimPoint()
		end
		if typeof(v919) ~= "Vector3" then
			v869 = v863.Position
			v870 = v_u_131()
			v871 = -math.sin(v870)
			v872 = -math.cos(v870)
			v919 = v869 + Vector3.new(v871, 0, v872) * v865.range * 0.6
		end
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	local v876 = v_u_9
	if v876 then
		v876 = v_u_9.controllers.Input
	end
	local v877, v878, v879, v880, v881, v882, v883, v884, v885, v886
	if not (v876 and v876.device) then
		v895 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		if v895 == "Keyboard" or v_u_113() ~= nil then
			v919 = v868 and v868.aimPoint
			if v919 then
				v919 = v868.aimPoint()
			end
			if typeof(v919) ~= "Vector3" then
				v869 = v863.Position
				v870 = v_u_131()
				v871 = -math.sin(v870)
				v872 = -math.cos(v870)
				v919 = v869 + Vector3.new(v871, 0, v872) * v865.range * 0.6
			end
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v902 = nil
		v903 = v_u_9
		if v903 then
			v903 = v_u_9.controllers.Input
		end
		if not (v903 and v903.device) then
			v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			if v908 == "Touch" then
				v877 = v868 and v868.touch
				if v877 then
					v877 = v868.touch()
				end
				if v877 and v877.aimDeflection then
					v878 = v877.aimDeflection
					v879, v880 = pcall(v878, v877)
					if v879 then
						if type(v880) == "number" then
							v902 = v880
						end
					end
				elseif v877 and v877.aimVector then
					v881 = v877.aimVector
					v882, v883 = pcall(v881, v877)
					if v882 and typeof(v883) == "Vector2" then
						v902 = v883.Magnitude
					end
				end
			elseif v908 == "Gamepad" then
				v884 = v_u_9.lib.VirtualPad.gamepadState
				v885, v886 = pcall(v884)
				if v885 and type(v886) == "table" then
					for v911, v912 in v886 do
						if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
					end
				end
			end
			if v902 and v902 > 0.15 then
				v_u_61 = math.clamp(v902, 0.15, 1)
			end
			v913 = v863.Position
			v914 = v_u_131()
			v915 = -math.sin(v914)
			v916 = -math.cos(v914)
			v917 = Vector3.new(v915, 0, v916)
			v918 = v865.range * v_u_61
			v919 = v913 + v917 * math.max(4, v918)
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v906 = v903.device
		v907, v908 = pcall(v906)
		if v907 and type(v908) == "string" then
			if v908 == "Touch" then
				v877 = v868 and v868.touch
				if v877 then
					v877 = v868.touch()
				end
				if v877 and v877.aimDeflection then
					v878 = v877.aimDeflection
					v879, v880 = pcall(v878, v877)
					if v879 then
						if type(v880) == "number" then
							v902 = v880
						end
					end
				elseif v877 and v877.aimVector then
					v881 = v877.aimVector
					v882, v883 = pcall(v881, v877)
					if v882 and typeof(v883) == "Vector2" then
						v902 = v883.Magnitude
					end
				end
			elseif v908 == "Gamepad" then
				v884 = v_u_9.lib.VirtualPad.gamepadState
				v885, v886 = pcall(v884)
				if v885 and type(v886) == "table" then
					for v911, v912 in v886 do
						if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
					end
				end
			end
			if v902 and v902 > 0.15 then
				v_u_61 = math.clamp(v902, 0.15, 1)
			end
			v913 = v863.Position
			v914 = v_u_131()
			v915 = -math.sin(v914)
			v916 = -math.cos(v914)
			v917 = Vector3.new(v915, 0, v916)
			v918 = v865.range * v_u_61
			v919 = v913 + v917 * math.max(4, v918)
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		if v908 == "Touch" then
			v877 = v868 and v868.touch
			if v877 then
				v877 = v868.touch()
			end
			if v877 and v877.aimDeflection then
				v878 = v877.aimDeflection
				v879, v880 = pcall(v878, v877)
				if v879 then
					if type(v880) == "number" then
						v902 = v880
					end
				end
			elseif v877 and v877.aimVector then
				v881 = v877.aimVector
				v882, v883 = pcall(v881, v877)
				if v882 and typeof(v883) == "Vector2" then
					v902 = v883.Magnitude
				end
			end
		elseif v908 == "Gamepad" then
			v884 = v_u_9.lib.VirtualPad.gamepadState
			v885, v886 = pcall(v884)
			if v885 and type(v886) == "table" then
				for v911, v912 in v886 do
					if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
						continue
					end
					v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
				end
			end
		end
		if v902 and v902 > 0.15 then
			v_u_61 = math.clamp(v902, 0.15, 1)
		end
		v913 = v863.Position
		v914 = v_u_131()
		v915 = -math.sin(v914)
		v916 = -math.cos(v914)
		v917 = Vector3.new(v915, 0, v916)
		v918 = v865.range * v_u_61
		v919 = v913 + v917 * math.max(4, v918)
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	local v893 = v876.device
	local v894, v895 = pcall(v893)
	if v894 and type(v895) == "string" then
		if v895 == "Keyboard" or v_u_113() ~= nil then
			v919 = v868 and v868.aimPoint
			if v919 then
				v919 = v868.aimPoint()
			end
			if typeof(v919) ~= "Vector3" then
				v869 = v863.Position
				v870 = v_u_131()
				v871 = -math.sin(v870)
				v872 = -math.cos(v870)
				v919 = v869 + Vector3.new(v871, 0, v872) * v865.range * 0.6
			end
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v902 = nil
		v903 = v_u_9
		if v903 then
			v903 = v_u_9.controllers.Input
		end
		if not (v903 and v903.device) then
			v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			if v908 == "Touch" then
				v877 = v868 and v868.touch
				if v877 then
					v877 = v868.touch()
				end
				if v877 and v877.aimDeflection then
					v878 = v877.aimDeflection
					v879, v880 = pcall(v878, v877)
					if v879 then
						if type(v880) == "number" then
							v902 = v880
						end
					end
				elseif v877 and v877.aimVector then
					v881 = v877.aimVector
					v882, v883 = pcall(v881, v877)
					if v882 and typeof(v883) == "Vector2" then
						v902 = v883.Magnitude
					end
				end
			elseif v908 == "Gamepad" then
				v884 = v_u_9.lib.VirtualPad.gamepadState
				v885, v886 = pcall(v884)
				if v885 and type(v886) == "table" then
					for v911, v912 in v886 do
						if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
					end
				end
			end
			if v902 and v902 > 0.15 then
				v_u_61 = math.clamp(v902, 0.15, 1)
			end
			v913 = v863.Position
			v914 = v_u_131()
			v915 = -math.sin(v914)
			v916 = -math.cos(v914)
			v917 = Vector3.new(v915, 0, v916)
			v918 = v865.range * v_u_61
			v919 = v913 + v917 * math.max(4, v918)
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v906 = v903.device
		v907, v908 = pcall(v906)
		if v907 and type(v908) == "string" then
			if v908 == "Touch" then
				v877 = v868 and v868.touch
				if v877 then
					v877 = v868.touch()
				end
				if v877 and v877.aimDeflection then
					v878 = v877.aimDeflection
					v879, v880 = pcall(v878, v877)
					if v879 then
						if type(v880) == "number" then
							v902 = v880
						end
					end
				elseif v877 and v877.aimVector then
					v881 = v877.aimVector
					v882, v883 = pcall(v881, v877)
					if v882 and typeof(v883) == "Vector2" then
						v902 = v883.Magnitude
					end
				end
			elseif v908 == "Gamepad" then
				v884 = v_u_9.lib.VirtualPad.gamepadState
				v885, v886 = pcall(v884)
				if v885 and type(v886) == "table" then
					for v911, v912 in v886 do
						if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
							continue
						end
						v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
					end
				end
			end
			if v902 and v902 > 0.15 then
				v_u_61 = math.clamp(v902, 0.15, 1)
			end
			v913 = v863.Position
			v914 = v_u_131()
			v915 = -math.sin(v914)
			v916 = -math.cos(v914)
			v917 = Vector3.new(v915, 0, v916)
			v918 = v865.range * v_u_61
			v919 = v913 + v917 * math.max(4, v918)
			v920 = v919.X - v867.X
			v921 = v919.Z - v867.Z
			v922 = Vector3.new(v920, 0, v921)
			if v922.Magnitude > v865.range then
				v873 = v867.X
				v874 = v919.Y
				v875 = v867.Z
				v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
			end
			v_u_66.FilterDescendantsInstances = { v862 }
			v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
			if v923 then
				v919 = v923.Position
			end
			return v867, v919
		end
		v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		if v908 == "Touch" then
			v877 = v868 and v868.touch
			if v877 then
				v877 = v868.touch()
			end
			if v877 and v877.aimDeflection then
				v878 = v877.aimDeflection
				v879, v880 = pcall(v878, v877)
				if v879 then
					if type(v880) == "number" then
						v902 = v880
					end
				end
			elseif v877 and v877.aimVector then
				v881 = v877.aimVector
				v882, v883 = pcall(v881, v877)
				if v882 and typeof(v883) == "Vector2" then
					v902 = v883.Magnitude
				end
			end
		elseif v908 == "Gamepad" then
			v884 = v_u_9.lib.VirtualPad.gamepadState
			v885, v886 = pcall(v884)
			if v885 and type(v886) == "table" then
				for v911, v912 in v886 do
					if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
						continue
					end
					v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
				end
			end
		end
		if v902 and v902 > 0.15 then
			v_u_61 = math.clamp(v902, 0.15, 1)
		end
		v913 = v863.Position
		v914 = v_u_131()
		v915 = -math.sin(v914)
		v916 = -math.cos(v914)
		v917 = Vector3.new(v915, 0, v916)
		v918 = v865.range * v_u_61
		v919 = v913 + v917 * math.max(4, v918)
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	v895 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
	if v895 == "Keyboard" or v_u_113() ~= nil then
		v919 = v868 and v868.aimPoint
		if v919 then
			v919 = v868.aimPoint()
		end
		if typeof(v919) ~= "Vector3" then
			v869 = v863.Position
			v870 = v_u_131()
			v871 = -math.sin(v870)
			v872 = -math.cos(v870)
			v919 = v869 + Vector3.new(v871, 0, v872) * v865.range * 0.6
		end
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	local v902 = nil
	local v903 = v_u_9
	if v903 then
		v903 = v_u_9.controllers.Input
	end
	if not (v903 and v903.device) then
		v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		if v908 == "Touch" then
			v877 = v868 and v868.touch
			if v877 then
				v877 = v868.touch()
			end
			if v877 and v877.aimDeflection then
				v878 = v877.aimDeflection
				v879, v880 = pcall(v878, v877)
				if v879 then
					if type(v880) == "number" then
						v902 = v880
					end
				end
			elseif v877 and v877.aimVector then
				v881 = v877.aimVector
				v882, v883 = pcall(v881, v877)
				if v882 and typeof(v883) == "Vector2" then
					v902 = v883.Magnitude
				end
			end
		elseif v908 == "Gamepad" then
			v884 = v_u_9.lib.VirtualPad.gamepadState
			v885, v886 = pcall(v884)
			if v885 and type(v886) == "table" then
				for v911, v912 in v886 do
					if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
						continue
					end
					v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
				end
			end
		end
		if v902 and v902 > 0.15 then
			v_u_61 = math.clamp(v902, 0.15, 1)
		end
		v913 = v863.Position
		v914 = v_u_131()
		v915 = -math.sin(v914)
		v916 = -math.cos(v914)
		v917 = Vector3.new(v915, 0, v916)
		v918 = v865.range * v_u_61
		v919 = v913 + v917 * math.max(4, v918)
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	local v906 = v903.device
	local v907, v908 = pcall(v906)
	if v907 and type(v908) == "string" then
		if v908 == "Touch" then
			v877 = v868 and v868.touch
			if v877 then
				v877 = v868.touch()
			end
			if v877 and v877.aimDeflection then
				v878 = v877.aimDeflection
				v879, v880 = pcall(v878, v877)
				if v879 then
					if type(v880) == "number" then
						v902 = v880
					end
				end
			elseif v877 and v877.aimVector then
				v881 = v877.aimVector
				v882, v883 = pcall(v881, v877)
				if v882 and typeof(v883) == "Vector2" then
					v902 = v883.Magnitude
				end
			end
		elseif v908 == "Gamepad" then
			v884 = v_u_9.lib.VirtualPad.gamepadState
			v885, v886 = pcall(v884)
			if v885 and type(v886) == "table" then
				for v911, v912 in v886 do
					if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
						continue
					end
					v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
				end
			end
		end
		if v902 and v902 > 0.15 then
			v_u_61 = math.clamp(v902, 0.15, 1)
		end
		v913 = v863.Position
		v914 = v_u_131()
		v915 = -math.sin(v914)
		v916 = -math.cos(v914)
		v917 = Vector3.new(v915, 0, v916)
		v918 = v865.range * v_u_61
		v919 = v913 + v917 * math.max(4, v918)
		v920 = v919.X - v867.X
		v921 = v919.Z - v867.Z
		v922 = Vector3.new(v920, 0, v921)
		if v922.Magnitude > v865.range then
			v873 = v867.X
			v874 = v919.Y
			v875 = v867.Z
			v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
		end
		v_u_66.FilterDescendantsInstances = { v862 }
		v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
		if v923 then
			v919 = v923.Position
		end
		return v867, v919
	end
	v908 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
	if v908 == "Touch" then
		v877 = v868 and v868.touch
		if v877 then
			v877 = v868.touch()
		end
		if v877 and v877.aimDeflection then
			v878 = v877.aimDeflection
			v879, v880 = pcall(v878, v877)
			if v879 then
				if type(v880) == "number" then
					v902 = v880
				end
			end
		elseif v877 and v877.aimVector then
			v881 = v877.aimVector
			v882, v883 = pcall(v881, v877)
			if v882 and typeof(v883) == "Vector2" then
				v902 = v883.Magnitude
			end
		end
	elseif v908 == "Gamepad" then
		v884 = v_u_9.lib.VirtualPad.gamepadState
		v885, v886 = pcall(v884)
		if v885 and type(v886) == "table" then
			for v911, v912 in v886 do
				if v912.KeyCode ~= Enum.KeyCode.Thumbstick2 then
					continue
				end
				v902 = Vector2.new(v912.Position.X, v912.Position.Y).Magnitude
			end
		end
	end
	if v902 and v902 > 0.15 then
		v_u_61 = math.clamp(v902, 0.15, 1)
	end
	local v913 = v863.Position
	local v914 = v_u_131()
	local v915 = -math.sin(v914)
	local v916 = -math.cos(v914)
	local v917 = Vector3.new(v915, 0, v916)
	local v918 = v865.range * v_u_61
	local v919 = v913 + v917 * math.max(4, v918)
	local v920 = v919.X - v867.X
	local v921 = v919.Z - v867.Z
	local v922 = Vector3.new(v920, 0, v921)
	if v922.Magnitude > v865.range then
		v873 = v867.X
		v874 = v919.Y
		v875 = v867.Z
		v919 = Vector3.new(v873, v874, v875) + v922.Unit * v865.range
	end
	v_u_66.FilterDescendantsInstances = { v862 }
	local v923 = v_u_6:Raycast(v919 + Vector3.new(0, 6, 0), Vector3.new(0, -40, 0), v_u_66)
	if v923 then
		v919 = v923.Position
	end
	return v867, v919
end
local v_u_925 = {
	["o"] = Vector3.new(0, 0, 0),
	["t"] = Vector3.new(0, 0, 0),
	["path"] = nil,
	["land"] = Vector3.new(0, 0, 0),
	["blocked"] = false
}
local function v_u_933(p926, p927, p928, p929) -- name: arcCastLocal
	-- upvalues: (copy) v_u_6, (copy) v_u_140, (copy) v_u_7
	for _ = 1, 8 do
		p929.FilterDescendantsInstances = p928
		local v930 = v_u_6:Raycast(p926, p927 - p926, p929)
		if not v930 then
			return nil
		end
		local v931 = v930.Instance
		local v932 = v_u_140(v931)
		if v_u_7:HasTag(v931, "HushWindow") and v931:GetAttribute("Broken") ~= true then
			table.insert(p928, v931)
		elseif v932 and v932:FindFirstChildOfClass("Humanoid") then
			table.insert(p928, v932)
		else
			if v931.Transparency < 0.98 or v931.CanCollide then
				return v930
			end
			table.insert(p928, v931)
		end
	end
	return nil
end
local function v_u_981(p934, p935) -- name: throwPath
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (copy) v_u_6, (copy) v_u_933
	local v936 = v_u_17.Character
	if not (v936 and v936.Parent) then
		v936 = nil
	end
	if v936 then
		v936 = v936:GetAttribute("Throwable")
	end
	local v937
	if type(v936) == "string" then
		v937 = v_u_8.perkThrow(v936) or nil
	else
		v937 = nil
	end
	local v938 = not v937 and 40 or v937.range
	local v939 = v_u_17.Character
	if not (v939 and v939.Parent) then
		v939 = nil
	end
	if v939 then
		v939 = v939:FindFirstChild("HumanoidRootPart")
	end
	local v940 = p935.X - p934.X
	local v941 = p935.Z - p934.Z
	local v942 = Vector3.new(v940, 0, v941)
	local v943 = v942.Magnitude
	if v943 < 1 then
		local v944 = not v939 and Vector3.new(0, 0, -1) or v939.CFrame.LookVector
		local v945 = v944.X
		local v946 = v944.Z
		v942 = Vector3.new(v945, 0, v946)
		v943 = 2
	end
	local v947 = math.min(v943, v938)
	local v948 = p934.X
	local v949 = p935.Y
	local v950 = p934.Z
	local v951 = Vector3.new(v948, v949, v950) + v942.Unit * v947
	if v939 then
		local v952 = v951.Y - v939.Position.Y
		if math.abs(v952) > 12 then
			local v953 = v951.X
			local v954 = v939.Position.Y - 2.5
			local v955 = v951.Z
			v951 = Vector3.new(v953, v954, v955)
		end
	end
	local v956 = 2.5 + v947 * 0.16
	local v957 = {}
	local v958 = {}
	local v959 = v_u_6:FindFirstChild("HushCombat")
	local v960 = v_u_6:FindFirstChild("HushLocal")
	local v961 = v_u_17.Character
	if not (v961 and v961.Parent) then
		v961 = nil
	end
	__set_list(v958, 1, {v959, v960, v961})
	for _, v962 in v958 do
		table.insert(v957, v962)
	end
	local v963 = v_u_6:FindFirstChild("Raid")
	if v963 then
		for _, v964 in { "Items", "Extracts", "Spawns" } do
			local v965 = v963:FindFirstChild(v964)
			if not v965 then
				continue
			end
			table.insert(v957, v965)
		end
	end
	local v966 = RaycastParams.new()
	v966.FilterType = Enum.RaycastFilterType.Exclude
	local v967 = p934
	local v968 = { p934 }
	for v969 = 1, 12 do
		local v970 = v969 / 12
		local v971 = p934:Lerp(v951, v970)
		local v972 = 4 * v956 * v970 * (1 - v970)
		local v973 = v971 + Vector3.new(0, v972, 0)
		local v974 = v_u_933(v967, v973, v957, v966)
		if v974 then
			local v975 = v974.Position + v974.Normal * 0.3
			local v976 = v_u_6:Raycast(v975 + Vector3.new(0, 0.2, 0), Vector3.new(0, -60, 0), v966)
			local v977
			if v976 then
				v977 = v976.Position + Vector3.new(0, 0.15, 0)
			else
				v977 = v975
			end
			table.insert(v968, v975)
			if (v977 - v975).Magnitude > 0.2 then
				table.insert(v968, v977)
			end
			local v978 = v977.X - v951.X
			local v979 = v977.Z - v951.Z
			return v968, v977, Vector3.new(v978, 0, v979).Magnitude > 1
		end
		table.insert(v968, v973)
		v967 = v973
	end
	v966.FilterDescendantsInstances = v957
	local v980 = v_u_6:Raycast(v951 + Vector3.new(0, 1, 0), Vector3.new(0, -60, 0), v966)
	if v980 then
		v951 = v980.Position + Vector3.new(0, 0.15, 0)
	end
	v968[#v968] = v951
	return v968, v951, false
end
local function v_u_1003(p982, p983) -- name: arcPoints
	-- upvalues: (copy) v_u_925, (copy) v_u_981
	local v984 = v_u_925.path
	if v984 and ((p982 - v_u_925.o).Magnitude < 0.05 and (p983 - v_u_925.t).Magnitude < 0.05) then
		return v984, v_u_925.land, v_u_925.blocked
	end
	local v985, v986, v987 = v_u_981(p982, p983)
	local v988 = 0
	for v989 = 2, #v985 do
		v988 = v988 + (v985[v989] - v985[v989 - 1]).Magnitude
	end
	local v990 = 2
	local v991 = 0
	local v992 = {}
	for v993 = 1, 14 do
		local v994 = v988 * v993 / 14
		while v990 < #v985 and v991 + (v985[v990] - v985[v990 - 1]).Magnitude < v994 do
			v991 = v991 + (v985[v990] - v985[v990 - 1]).Magnitude
			v990 = v990 + 1
		end
		local v995 = v985[v990 - 1]
		local v996 = v985[v990]
		local v997 = (v996 - v995).Magnitude
		if v997 > 0.0001 then
			local v998 = (v994 - v991) / v997
			v996 = v995:Lerp(v996, (math.clamp(v998, 0, 1)))
		end
		table.insert(v992, v996)
	end
	local v999 = v_u_925
	local v1000 = v_u_925
	local v1001 = v_u_925
	local v1002 = v_u_925
	v_u_925.o = p982
	v999.t = p983
	v1000.path = v992
	v1001.land = v986
	v1002.blocked = v987
	return v992, v986, v987
end
local function v_u_1010() -- name: doThrow
	-- upvalues: (copy) v_u_8, (copy) v_u_17, (ref) v_u_1552, (ref) v_u_1679, (copy) v_u_924, (ref) v_u_9
	if v_u_8.rideNo("throw") then
		return
	else
		local v1004 = v_u_17.Character
		if not (v1004 and v1004.Parent) then
			v1004 = nil
		end
		if v1004 then
			v1004 = v1004:GetAttribute("Throwable")
		end
		if type(v1004) == "string" and v1004 ~= "" then
			local _, v1005 = v_u_924()
			if v1005 then
				v_u_9.net.fire("combat.throw", {
					["id"] = v1004,
					["p"] = v1005
				})
				v_u_9.emit("weapon.throw", v1004)
				local v1006 = v_u_17.Character
				if not (v1006 and v1006.Parent) then
					v1006 = nil
				end
				if v1006 then
					v1006 = v1006:FindFirstChild("HumanoidRootPart")
				end
				if v1006 then
					local v1007 = v1006.Position
					local v1008 = v_u_9
					if v1008 then
						v1008 = v_u_9.controllers.Audio
					end
					if v1008 and v1008.play3D then
						local v1009 = v1008.play3D
						pcall(v1009, "item_throw", v1007, nil)
					end
				end
			end
		else
			v_u_1552 = "NO THROWABLE"
			v_u_1679 = os.clock() + 1
			return
		end
	end
end
local function v_u_1016() -- name: cycleThrowable
	-- upvalues: (copy) v_u_861, (ref) v_u_1552, (ref) v_u_1679, (copy) v_u_17, (ref) v_u_9, (copy) v_u_8
	local v1011 = v_u_861()
	if #v1011 == 0 then
		v_u_1552 = "NO THROWABLE"
		v_u_1679 = os.clock() + 1
	else
		local v1012 = v_u_17.Character
		if not (v1012 and v1012.Parent) then
			v1012 = nil
		end
		if v1012 then
			v1012 = v1012:GetAttribute("Throwable")
		end
		local v1013 = v1011[(table.find(v1011, v1012) or 0) % #v1011 + 1]
		v_u_9.net.fire("combat.throw", {
			["id"] = nil,
			["select"] = true,
			["id"] = v1013
		})
		local v1014 = v_u_8.throwDef(v1013)
		local v1015 = string.upper
		if v1014 then
			v1013 = v1014.name or v1013
		end
		v_u_1552 = v1015(v1013)
		v_u_1679 = os.clock() + 1.4
	end
end
function v_u_8.selectThrowable(p1017) -- name: selectThrowable
	-- upvalues: (copy) v_u_8, (ref) v_u_9
	if v_u_8.throwDef(p1017) then
		v_u_9.net.fire("combat.throw", {
			["id"] = nil,
			["select"] = true,
			["id"] = p1017
		})
	end
end
local function v_u_1039() -- name: throwHintText
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (copy) v_u_861
	local v1018 = v_u_9
	if v1018 then
		v1018 = v_u_9.controllers.Input
	end
	local v1019, v1020, v1021, v1022, v1023, v1024, v1025, v1026, v1027, v1028, v1029, v1030
	if not (v1018 and v1018.device) then
		v1033 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		v1034 = #v_u_861() > 1
		if v1033 == "Touch" then
			return "Drag to aim  \194\183  lift to throw  \194\183  CANCEL to put away" .. (v1034 and "  \194\183  THROW: next" or "")
		end
		v1035 = v_u_9
		if v1035 then
			v1035 = v_u_9.controllers.Input
		end
		if v1035 and v1035.hint then
			v1019 = v1035.hint
			v1020, v1021 = pcall(v1019, "fire")
			v1022 = (not v1020 or type(v1021) ~= "string") and "" or v1021
		else
			v1022 = ""
		end
		v1036 = v_u_9
		if v1036 then
			v1036 = v_u_9.controllers.Input
		end
		if v1036 and v1036.hint then
			v1023 = v1036.hint
			v1024, v1025 = pcall(v1023, "aim")
			v1026 = (not v1024 or type(v1025) ~= "string") and "" or v1025
		else
			v1026 = ""
		end
		v1037 = v_u_9
		if v1037 then
			v1037 = v_u_9.controllers.Input
		end
		if v1037 and v1037.hint then
			v1027 = v1037.hint
			v1028, v1029 = pcall(v1027, "throw")
			v1030 = (not v1028 or type(v1029) ~= "string") and "" or v1029
		else
			v1030 = ""
		end
		if v1033 == "Gamepad" then
			return v1022 .. " to throw  \194\183  " .. v1026 .. " cancel"
		end
		v1038 = (v1022 == "LMB" and "Click" or v1022) .. " to throw  \194\183  " .. (v1026 == "RMB" and "Right click" or v1026) .. " cancel"
		if v1034 and v1030 ~= "" then
			v1038 = v1038 .. "  \194\183  " .. v1030 .. " next"
		end
		return v1038
	end
	local v1031 = v1018.device
	local v1032, v1033 = pcall(v1031)
	if v1032 and type(v1033) == "string" then
		v1034 = #v_u_861() > 1
		if v1033 == "Touch" then
			return "Drag to aim  \194\183  lift to throw  \194\183  CANCEL to put away" .. (v1034 and "  \194\183  THROW: next" or "")
		end
		v1035 = v_u_9
		if v1035 then
			v1035 = v_u_9.controllers.Input
		end
		if v1035 and v1035.hint then
			v1019 = v1035.hint
			v1020, v1021 = pcall(v1019, "fire")
			v1022 = (not v1020 or type(v1021) ~= "string") and "" or v1021
		else
			v1022 = ""
		end
		v1036 = v_u_9
		if v1036 then
			v1036 = v_u_9.controllers.Input
		end
		if v1036 and v1036.hint then
			v1023 = v1036.hint
			v1024, v1025 = pcall(v1023, "aim")
			v1026 = (not v1024 or type(v1025) ~= "string") and "" or v1025
		else
			v1026 = ""
		end
		v1037 = v_u_9
		if v1037 then
			v1037 = v_u_9.controllers.Input
		end
		if v1037 and v1037.hint then
			v1027 = v1037.hint
			v1028, v1029 = pcall(v1027, "throw")
			v1030 = (not v1028 or type(v1029) ~= "string") and "" or v1029
		else
			v1030 = ""
		end
		if v1033 == "Gamepad" then
			return v1022 .. " to throw  \194\183  " .. v1026 .. " cancel"
		end
		v1038 = (v1022 == "LMB" and "Click" or v1022) .. " to throw  \194\183  " .. (v1026 == "RMB" and "Right click" or v1026) .. " cancel"
		if v1034 and v1030 ~= "" then
			v1038 = v1038 .. "  \194\183  " .. v1030 .. " next"
		end
		return v1038
	end
	v1033 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
	local v1034 = #v_u_861() > 1
	if v1033 == "Touch" then
		return "Drag to aim  \194\183  lift to throw  \194\183  CANCEL to put away" .. (v1034 and "  \194\183  THROW: next" or "")
	end
	local v1035 = v_u_9
	if v1035 then
		v1035 = v_u_9.controllers.Input
	end
	if v1035 and v1035.hint then
		v1019 = v1035.hint
		v1020, v1021 = pcall(v1019, "fire")
		v1022 = (not v1020 or type(v1021) ~= "string") and "" or v1021
	else
		v1022 = ""
	end
	local v1036 = v_u_9
	if v1036 then
		v1036 = v_u_9.controllers.Input
	end
	if v1036 and v1036.hint then
		v1023 = v1036.hint
		v1024, v1025 = pcall(v1023, "aim")
		v1026 = (not v1024 or type(v1025) ~= "string") and "" or v1025
	else
		v1026 = ""
	end
	local v1037 = v_u_9
	if v1037 then
		v1037 = v_u_9.controllers.Input
	end
	if v1037 and v1037.hint then
		v1027 = v1037.hint
		v1028, v1029 = pcall(v1027, "throw")
		v1030 = (not v1028 or type(v1029) ~= "string") and "" or v1029
	else
		v1030 = ""
	end
	if v1033 == "Gamepad" then
		return v1022 .. " to throw  \194\183  " .. v1026 .. " cancel"
	end
	local v1038 = (v1022 == "LMB" and "Click" or v1022) .. " to throw  \194\183  " .. (v1026 == "RMB" and "Right click" or v1026) .. " cancel"
	if v1034 and v1030 ~= "" then
		v1038 = v1038 .. "  \194\183  " .. v1030 .. " next"
	end
	return v1038
end
local function v_u_1044() -- name: throwLabel
	-- upvalues: (copy) v_u_17, (copy) v_u_8
	local v1040 = v_u_17.Character
	if not (v1040 and v1040.Parent) then
		v1040 = nil
	end
	if v1040 then
		v1040 = v1040:GetAttribute("Throwable")
	end
	local v1041 = type(v1040) == "string" and v_u_8.throwDef(v1040) or nil
	local v1042 = v_u_17.Character
	if not (v1042 and v1042.Parent) then
		v1042 = nil
	end
	if v1042 then
		v1042 = v1042:GetAttribute("Throwables")
	end
	local v1043 = tonumber(v1042)
	return string.upper(v1041 and v1041.name or "THROWABLE") .. ((not v1043 or v1043 <= 1) and "" or "  x" .. v1043)
end
local function v_u_1063() -- name: enterThrowMode
	-- upvalues: (ref) v_u_18, (copy) v_u_99, (copy) v_u_8, (copy) v_u_17, (ref) v_u_1552, (ref) v_u_1679, (ref) v_u_1716, (ref) v_u_60, (ref) v_u_9, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_13, (copy) v_u_1039, (copy) v_u_4, (ref) v_u_62
	if not v_u_18 or (not v_u_99() or v_u_8.rideNo("throw")) then
		return false
	end
	local v1045 = v_u_17.Character
	if not (v1045 and v1045.Parent) then
		v1045 = nil
	end
	if v1045 then
		v1045 = v1045:GetAttribute("Throwable")
	end
	if type(v1045) ~= "string" or (v1045 == "" or not v_u_8.throwDef(v1045)) then
		v_u_1552 = "NO THROWABLE"
		v_u_1679 = os.clock() + 1
		return false
	end
	if v1045 == "throw_firecracker" then
		v_u_1552 = "FIRECRACKERS: THROW THEM FAR"
		v_u_1679 = os.clock() + 1.6
	end
	v_u_1716 = true
	v_u_60 = os.clock()
	local v1046 = v_u_9.lib.GrenadeFx.hold
	pcall(v1046, true, v1045)
	v_u_27 = false
	v_u_1581 = false
	local v1047 = v_u_13.throwHint
	local v1048 = v_u_1039()
	local v1049 = v_u_9
	if v1049 then
		v1049 = v_u_9.controllers.Input
	end
	local v1050, v1051, v1052, v1053, v1054
	if v1049 and v1049.device then
		local v1055 = v1049.device
		local v1056
		v1056, v1050 = pcall(v1055)
		if v1056 and type(v1050) == "string" then
			v1051 = v1050 == "Touch"
			pcall(v1047, v1048, v1051)
			if not v_u_62 then
				v1062 = v_u_17.Character
				if not (v1062 and v1062.Parent) then
					v1062 = nil
				end
				if v1062 then
					v1062 = v1062:FindFirstChild("HumanoidRootPart")
				end
				if v1062 then
					v1052 = v1062.Position
					v1053 = v_u_9
					if v1053 then
						v1053 = v_u_9.controllers.Audio
					end
					if v1053 and v1053.play3D then
						v1054 = v1053.play3D
						pcall(v1054, "item_flashlight", v1052, nil)
					end
				end
				return true
			end
		else
			v1050 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			v1051 = v1050 == "Touch"
			pcall(v1047, v1048, v1051)
			if not v_u_62 then
				v1062 = v_u_17.Character
				if not (v1062 and v1062.Parent) then
					v1062 = nil
				end
				if v1062 then
					v1062 = v1062:FindFirstChild("HumanoidRootPart")
				end
				if v1062 then
					v1052 = v1062.Position
					v1053 = v_u_9
					if v1053 then
						v1053 = v_u_9.controllers.Audio
					end
					if v1053 and v1053.play3D then
						v1054 = v1053.play3D
						pcall(v1054, "item_flashlight", v1052, nil)
					end
				end
				return true
			end
		end
	else
		v1050 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		v1051 = v1050 == "Touch"
		pcall(v1047, v1048, v1051)
		if not v_u_62 then
			v1062 = v_u_17.Character
			if not (v1062 and v1062.Parent) then
				v1062 = nil
			end
			if v1062 then
				v1062 = v1062:FindFirstChild("HumanoidRootPart")
			end
			if v1062 then
				v1052 = v1062.Position
				v1053 = v_u_9
				if v1053 then
					v1053 = v_u_9.controllers.Audio
				end
				if v1053 and v1053.play3D then
					v1054 = v1053.play3D
					pcall(v1054, "item_flashlight", v1052, nil)
				end
			end
			return true
		end
	end
	local v1057 = v_u_62
	local v1058 = v_u_9
	if v1058 then
		v1058 = v_u_9.controllers.Input
	end
	local v1059
	if v1058 and v1058.device then
		local v1060 = v1058.device
		local v1061
		v1061, v1059 = pcall(v1060)
		if v1061 and type(v1059) == "string" then
			v1057.Visible = v1059 == "Touch"
		else
			v1059 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			v1057.Visible = v1059 == "Touch"
		end
	else
		v1059 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
		v1057.Visible = v1059 == "Touch"
	end
	local v1062 = v_u_17.Character
	if not (v1062 and v1062.Parent) then
		v1062 = nil
	end
	if v1062 then
		v1062 = v1062:FindFirstChild("HumanoidRootPart")
	end
	if v1062 then
		v1052 = v1062.Position
		v1053 = v_u_9
		if v1053 then
			v1053 = v_u_9.controllers.Audio
		end
		if v1053 and v1053.play3D then
			v1054 = v1053.play3D
			pcall(v1054, "item_flashlight", v1052, nil)
		end
	end
	return true
end
function v_u_8.ride() -- name: ride
	-- upvalues: (copy) v_u_8, (ref) v_u_9
	local v1064 = v_u_8._wr
	local v1065
	if v1064 or (v_u_9 == nil or os.clock() - v_u_8._wrT <= 10) then
		v1065 = v1064
	else
		v_u_8._wrT = os.clock()
		local function v1066()
			-- upvalues: (ref) v_u_9
			return v_u_9.lib.WeaponRide
		end
		local v1067
		v1067, v1065 = pcall(v1066)
		if v1067 and type(v1065) == "table" then
			v_u_8._wr = v1065
			local v1068 = v1065.init
			local v1069 = v_u_9
			pcall(v1068, v1069)
		else
			v1065 = v1064
		end
	end
	return v1065 or nil
end
function v_u_8.rideKind(p1070) -- name: rideKind
	-- upvalues: (copy) v_u_8
	local v1071 = v_u_8.ride()
	if v1071 == nil then
		return nil
	else
		return v1071.of(p1070)
	end
end
function v_u_8.rideCar(p1072) -- name: rideCar
	-- upvalues: (copy) v_u_8
	if p1072:GetAttribute("RideVehicle") == nil then
		return nil
	else
		local v1073 = v_u_8.ride()
		if v1073 == nil then
			return nil
		else
			return v1073.model(p1072)
		end
	end
end
function v_u_8.rideNo(p1074) -- name: rideNo
	-- upvalues: (copy) v_u_8, (copy) v_u_17
	local v1075 = v_u_8.rideKind
	local v1076 = v_u_17.Character
	if not (v1076 and v1076.Parent) then
		v1076 = nil
	end
	local v1077 = v1075(v1076)
	if v1077 == nil then
		return false
	end
	local v1078 = v_u_8.ride()
	local v1079
	if p1074 == "draw" then
		if v1078 == nil then
			v1079 = false
		else
			v1079 = not v1078.canDraw(v1077)
		end
	else
		v1079 = true
	end
	return v1079
end
function v_u_8.rideFrame(p1080) -- name: rideFrame
	-- upvalues: (copy) v_u_8, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_770, (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62, (copy) v_u_603, (copy) v_u_585
	local v1081 = v_u_8.rideKind(p1080) or "none"
	if v1081 ~= v_u_8._rk then
		v_u_8._rk = v1081
		if v1081 == "busy" or v1081 == "driver" then
			v_u_27 = false
			v_u_1581 = false
			v_u_770 = false
			if v_u_1716 then
				v_u_1716 = false
				local v1082 = v_u_9.lib.GrenadeFx.hold
				pcall(v1082, false)
				v_u_12.arcPreview(nil)
				local v1083 = v_u_13.throwHint
				pcall(v1083, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
			v_u_603()
			v_u_585.t = 0
		end
	end
end
local function v_u_1087() -- name: onFireBegin
	-- upvalues: (ref) v_u_18, (copy) v_u_99, (ref) v_u_1716, (ref) v_u_60, (copy) v_u_1010, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_1575, (copy) v_u_585, (ref) v_u_22, (copy) v_u_856
	if v_u_18 and v_u_99() then
		if v_u_1716 then
			if os.clock() - v_u_60 > 0.08 then
				v_u_1010()
				if not v_u_1716 then
					return
				end
				v_u_1716 = false
				local v1084 = v_u_9.lib.GrenadeFx.hold
				pcall(v1084, false)
				v_u_12.arcPreview(nil)
				local v1085 = v_u_13.throwHint
				pcall(v1085, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		else
			v_u_27 = true
			v_u_1581 = false
			v_u_1575 = false
			local v1086
			if v_u_585.pending() and v_u_585.stats then
				v1086 = v_u_585.stats
			else
				v1086 = v_u_22
			end
			if v1086 and v1086.kind == "melee" then
				v_u_856()
			end
		end
	else
		return
	end
end
local function v_u_1088() -- name: onFireEnd
	-- upvalues: (ref) v_u_27, (ref) v_u_1581, (ref) v_u_1575
	v_u_27 = false
	v_u_1581 = false
	v_u_1575 = false
end
local v_u_1089 = 0
local function v_u_1102() -- name: cycleFireMode
	-- upvalues: (ref) v_u_18, (copy) v_u_99, (ref) v_u_22, (ref) v_u_1089, (copy) v_u_17, (ref) v_u_1552, (ref) v_u_1679, (ref) v_u_9
	if not v_u_18 or (not v_u_99() or (not v_u_22 or v_u_22.kind ~= "firearm")) then
		return nil
	end
	local v1090 = os.clock()
	if v1090 - v_u_1089 < 0.2 then
		return nil
	end
	local v1091 = v_u_17.Character
	if not (v1091 and v1091.Parent) then
		v1091 = nil
	end
	if v1091 then
		v1091 = v1091:GetAttribute("FireModes")
	end
	if type(v1091) ~= "string" or not string.find(v1091, ",", 1, true) then
		local v1092 = string.upper
		local v1093 = v_u_17.Character
		if not (v1093 and v1093.Parent) then
			v1093 = nil
		end
		if v1093 then
			v1093 = v1093:GetAttribute("FireMode")
		end
		v_u_1552 = v1092((tostring(v1093 or "SEMI"))) .. " ONLY"
		v_u_1679 = os.clock() + 0.8
		return nil
	end
	v_u_1089 = v1090
	v_u_9.net.fire("combat.mode", {})
	local v1094 = string.split(v1091, ",")
	local v1095 = table.find
	local v1096 = v_u_17.Character
	if not (v1096 and v1096.Parent) then
		v1096 = nil
	end
	if v1096 then
		v1096 = v1096:GetAttribute("FireMode")
	end
	local v1097 = v1094[(v1095(v1094, v1096) or 1) % #v1094 + 1] or ""
	v_u_1552 = string.upper(v1097)
	v_u_1679 = os.clock() + 1
	local v1098 = v_u_17.Character
	if not (v1098 and v1098.Parent) then
		v1098 = nil
	end
	if v1098 then
		v1098 = v1098:FindFirstChild("HumanoidRootPart")
	end
	if v1098 then
		local v1099 = v1098.Position
		local v1100 = v_u_9
		if v1100 then
			v1100 = v_u_9.controllers.Audio
		end
		if v1100 and v1100.play3D then
			local v1101 = v1100.play3D
			pcall(v1101, "wpn_dry", v1099, nil)
		end
	end
	return v1097
end
local function v_u_1103() -- name: onReloadBegin
	-- upvalues: (ref) v_u_18, (copy) v_u_99, (ref) v_u_33, (ref) v_u_1594
	if v_u_18 and v_u_99() then
		v_u_33 = os.clock()
		v_u_1594 = false
	end
end
local function v_u_1105() -- name: onReloadEnd
	-- upvalues: (ref) v_u_33, (ref) v_u_18, (ref) v_u_1594, (copy) v_u_672, (copy) v_u_658
	local v1104 = v_u_33
	v_u_33 = nil
	if v_u_18 and v1104 then
		if not (v_u_1594 or v_u_672()) then
			v_u_658()
		end
	end
end
local function v_u_1135() -- name: bindAll
	-- upvalues: (ref) v_u_9, (copy) v_u_20, (copy) v_u_1087, (copy) v_u_1088, (copy) v_u_1103, (copy) v_u_1105, (copy) v_u_1102, (copy) v_u_17, (ref) v_u_18, (ref) v_u_1552, (ref) v_u_1679, (copy) v_u_99, (copy) v_u_856, (copy) v_u_639, (ref) v_u_35, (ref) v_u_1716, (ref) v_u_12, (copy) v_u_1010, (ref) v_u_13, (ref) v_u_62, (copy) v_u_1063, (copy) v_u_861, (copy) v_u_1016, (copy) v_u_19, (copy) v_u_4, (ref) v_u_33, (ref) v_u_1594, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_1575, (copy) v_u_672, (copy) v_u_658
	local v_u_1106 = v_u_9
	if v_u_1106 then
		v_u_1106 = v_u_9.controllers.Input
	end
	local function v1114(p1107, p_u_1108, p_u_1109) -- name: bind
		-- upvalues: (copy) v_u_1106, (ref) v_u_20
		if v_u_1106 and v_u_1106.bind then
			local v1110 = v_u_1106.bind
			local v1111, v1112 = pcall(v1110, p1107, function()
				-- upvalues: (copy) p_u_1108
				if p_u_1108 then
					p_u_1108()
				end
			end, function()
				-- upvalues: (copy) p_u_1109
				if p_u_1109 then
					p_u_1109()
				end
			end)
			if v1111 and type(v1112) == "function" then
				local v1113 = v_u_20
				table.insert(v1113, v1112)
				return
			end
		end
	end
	if v_u_1106 and v_u_1106.bind then
		v1114("fire", v_u_1087, v_u_1088)
		v1114("reload", v_u_1103, v_u_1105)
		v1114("fireMode", function()
			-- upvalues: (ref) v_u_1102
			v_u_1102()
		end)
		v1114("sprint", function()
			-- upvalues: (ref) v_u_17, (ref) v_u_18, (ref) v_u_1552, (ref) v_u_1679
			local v1115 = v_u_17.Character
			if not (v1115 and v1115.Parent) then
				v1115 = nil
			end
			if v_u_18 and (v1115 and v1115:GetAttribute("Exhausted") == true) then
				v_u_1552 = "EXHAUSTED"
				v_u_1679 = os.clock() + 0.9
			end
		end)
		v1114("melee", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_856
			if v_u_18 and v_u_99() then
				v_u_856()
			end
		end)
		v1114("swap", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_639
			if v_u_18 and v_u_99(true) then
				v_u_639("next")
			end
		end)
		v1114("primary", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_639
			if v_u_18 and v_u_99(true) then
				v_u_639("primary")
			end
		end)
		v1114("secondary", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_639
			if v_u_18 and v_u_99(true) then
				v_u_639("secondary")
			end
		end)
		v1114("meleeSlot", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_639
			if v_u_18 and v_u_99(true) then
				v_u_639("melee")
			end
		end)
		v1114("throw", function()
			-- upvalues: (ref) v_u_18, (ref) v_u_99, (ref) v_u_35
			if v_u_18 and v_u_99() then
				v_u_35 = os.clock()
			end
		end, function()
			-- upvalues: (ref) v_u_35, (ref) v_u_1716, (ref) v_u_12, (ref) v_u_18, (ref) v_u_99, (ref) v_u_1010, (ref) v_u_9, (ref) v_u_13, (ref) v_u_62, (ref) v_u_1063, (ref) v_u_861, (ref) v_u_1016
			local v1116 = v_u_35
			v_u_35 = nil
			if not v_u_1716 then
				v_u_12.arcPreview(nil)
			end
			if v_u_18 and (v1116 and v_u_99()) then
				if os.clock() - v1116 >= 0.25 then
					v_u_1010()
					if not v_u_1716 then
						return
					end
					v_u_1716 = false
					local v1117 = v_u_9.lib.GrenadeFx.hold
					pcall(v1117, false)
					v_u_12.arcPreview(nil)
					local v1118 = v_u_13.throwHint
					pcall(v1118, nil)
					if v_u_62 then
						v_u_62.Visible = false
						return
					end
				else
					if not v_u_1716 then
						v_u_1063()
						return
					end
					if #v_u_861() > 1 then
						v_u_1016()
						return
					end
					if not v_u_1716 then
						return
					end
					v_u_1716 = false
					local v1119 = v_u_9.lib.GrenadeFx.hold
					pcall(v1119, false)
					v_u_12.arcPreview(nil)
					local v1120 = v_u_13.throwHint
					pcall(v1120, nil)
					if v_u_62 then
						v_u_62.Visible = false
					end
				end
			end
		end)
		v1114("aim", function()
			-- upvalues: (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62
			if v_u_1716 then
				if not v_u_1716 then
					return
				end
				v_u_1716 = false
				local v1121 = v_u_9.lib.GrenadeFx.hold
				pcall(v1121, false)
				v_u_12.arcPreview(nil)
				local v1122 = v_u_13.throwHint
				pcall(v1122, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		end)
		v1114("throwCancel", function()
			-- upvalues: (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62
			if v_u_1716 then
				v_u_1716 = false
				local v1123 = v_u_9.lib.GrenadeFx.hold
				pcall(v1123, false)
				v_u_12.arcPreview(nil)
				local v1124 = v_u_13.throwHint
				pcall(v1124, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		end)
	else
		local v1125 = v_u_19
		local v1126 = v_u_4.InputBegan
		local function v1129(p1127, p1128)
			-- upvalues: (ref) v_u_1087, (ref) v_u_18, (ref) v_u_99, (ref) v_u_33, (ref) v_u_1594, (ref) v_u_856, (ref) v_u_639, (ref) v_u_1010
			if p1128 then
				return
			elseif p1127.UserInputType == Enum.UserInputType.MouseButton1 or p1127.KeyCode == Enum.KeyCode.ButtonR2 then
				v_u_1087()
			elseif p1127.KeyCode == Enum.KeyCode.R or p1127.KeyCode == Enum.KeyCode.ButtonX then
				if v_u_18 then
					if v_u_99() then
						v_u_33 = os.clock()
						v_u_1594 = false
					end
				end
			else
				if p1127.KeyCode == Enum.KeyCode.V then
					v_u_856()
					return
				end
				if p1127.KeyCode == Enum.KeyCode.X then
					v_u_639("next")
					return
				end
				if p1127.KeyCode == Enum.KeyCode.Three then
					v_u_639("melee")
					return
				end
				if p1127.KeyCode == Enum.KeyCode.G then
					v_u_1010()
				end
			end
		end
		table.insert(v1125, v1126:Connect(v1129))
		local v1130 = v_u_19
		local v1131 = v_u_4.InputEnded
		local function v1134(p1132)
			-- upvalues: (ref) v_u_27, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_33, (ref) v_u_18, (ref) v_u_1594, (ref) v_u_672, (ref) v_u_658
			if p1132.UserInputType == Enum.UserInputType.MouseButton1 or p1132.KeyCode == Enum.KeyCode.ButtonR2 then
				v_u_27 = false
				v_u_1581 = false
				v_u_1575 = false
			elseif p1132.KeyCode == Enum.KeyCode.R or p1132.KeyCode == Enum.KeyCode.ButtonX then
				local v1133 = v_u_33
				v_u_33 = nil
				if v_u_18 then
					if not v1133 then
						return
					end
					if not (v_u_1594 or v_u_672()) then
						v_u_658()
					end
				end
			end
		end
		table.insert(v1130, v1131:Connect(v1134))
	end
end
local function v_u_1237(p_u_1136) -- name: onFx
	-- upvalues: (ref) v_u_18, (ref) v_u_12, (copy) v_u_17, (ref) v_u_9, (ref) v_u_10, (copy) v_u_6, (ref) v_u_13, (copy) v_u_3, (copy) v_u_376, (ref) v_u_14, (copy) v_u_8, (copy) v_u_416, (copy) v_u_76, (copy) v_u_113, (copy) v_u_168
	if not v_u_18 or (type(p_u_1136) ~= "table" or not v_u_12.isMounted()) then
		return
	end
	local v1137 = v_u_17.Character
	if not (v1137 and v1137.Parent) then
		v1137 = nil
	end
	if v1137 then
		v1137 = v1137:FindFirstChild("HumanoidRootPart")
	end
	local v1138
	if v1137 then
		v1138 = v1137.Position
	else
		v1138 = nil
	end
	local v1139 = p_u_1136.k
	if v1139 == "throw" or (v1139 == "gland" or (v1139 == "flashbang" or (v1139 == "flashhit" or (v1139 == "smokepop" or v1139 == "explode")))) then
		local v1140 = v_u_9.lib.GrenadeFx.onFx
		pcall(v1140, p_u_1136)
	end
	if v1139 ~= "shot" then
		if v1139 == "melee" then
			local v1141 = p_u_1136.p
			if typeof(v1141) == "Vector3" then
				v_u_12.blood(v1141, Vector3.new(0, 1, 0), 0.6)
				v_u_76(nil, v1141, "hit")
				return
			end
			return
		elseif v1139 == "glass" then
			local v1142 = p_u_1136.p
			if typeof(v1142) == "Vector3" then
				v_u_12.glass(p_u_1136.p)
				local v1143 = p_u_1136.p
				local v1144 = v_u_9
				if v1144 then
					v1144 = v_u_9.controllers.Audio
				end
				if v1144 and v1144.play3D then
					local v1145 = v1144.play3D
					pcall(v1145, "glass_break", v1143, nil)
					return
				end
			end
			return
		elseif v1139 == "shatter" then
			local v1146 = p_u_1136.p
			if typeof(v1146) == "Vector3" then
				v_u_12.glass(p_u_1136.p)
				local v1147 = p_u_1136.p
				local v1148 = v_u_9
				if v1148 then
					v1148 = v_u_9.controllers.Audio
				end
				if v1148 and v1148.play3D then
					local v1149 = v1148.play3D
					pcall(v1149, "item_bottle_break", v1147, nil)
					return
				end
			end
			return
		elseif v1139 == "throw" then
			local v1150 = p_u_1136.path
			if type(v1150) == "table" then
				local v1151 = p_u_1136.t
				if type(v1151) == "number" then
					local v_u_1152 = 0
					if p_u_1136.s == v_u_17.UserId and v_u_113() ~= nil then
						local function v1153()
							-- upvalues: (ref) v_u_9
							return v_u_9.lib.Viewmodel.throwLead()
						end
						local v1154, v1155 = pcall(v1153)
						if v1154 and type(v1155) == "number" then
							local v1156 = p_u_1136.t - 0.15
							local v1157 = math.max(0, v1156)
							v_u_1152 = math.clamp(v1155, 0, v1157)
						end
					end
					if v_u_1152 > 0.02 then
						local v_u_1158 = p_u_1136.id
						local v_u_1159 = p_u_1136.path
						local v_u_1160 = p_u_1136.t
						task.delay(v_u_1152, function()
							-- upvalues: (ref) v_u_18, (ref) v_u_12, (copy) v_u_1158, (copy) v_u_1159, (copy) v_u_1160, (ref) v_u_1152
							if v_u_18 then
								v_u_12.projectile(v_u_1158, v_u_1159, v_u_1160 - v_u_1152)
							end
						end)
					else
						v_u_12.projectile(p_u_1136.id, p_u_1136.path, p_u_1136.t)
					end
					if p_u_1136.s == v_u_17.UserId then
						if p_u_1136.s == v_u_17.UserId then
							v_u_168.throwLand = p_u_1136.path[#p_u_1136.path]
						end
						return
					else
						local v1161 = p_u_1136.path[1]
						if typeof(v1161) == "Vector3" then
							local v1162 = p_u_1136.path[1]
							local v1163 = v_u_9
							if v1163 then
								v1163 = v_u_9.controllers.Audio
							end
							if v1163 and v1163.play3D then
								local v1164 = v1163.play3D
								pcall(v1164, "item_throw", v1162, nil)
							end
						elseif p_u_1136.s == v_u_17.UserId then
							v_u_168.throwLand = p_u_1136.path[#p_u_1136.path]
						end
					end
				else
					return
				end
			else
				return
			end
		else
			if v1139 == "fuse" then
				local v_u_1165 = p_u_1136.p
				if typeof(v_u_1165) == "Vector3" then
					task.spawn(function()
						-- upvalues: (copy) p_u_1136, (ref) v_u_18, (copy) v_u_1165, (ref) v_u_9
						local v1166 = p_u_1136.fuse
						local v1167 = tonumber(v1166) or 3
						local v1168 = os.clock()
						while os.clock() - v1168 < v1167 and v_u_18 do
							local v1169 = v_u_1165
							local v1170 = {
								["roll"] = nil,
								["volume"] = 1.3,
								["roll"] = { 12, 80 }
							}
							local v1171 = v_u_9
							if v1171 then
								v1171 = v_u_9.controllers.Audio
							end
							if v1171 and v1171.play3D then
								local v1172 = v1171.play3D
								pcall(v1172, "item_flashlight", v1169, v1170)
							end
							local v1173 = v1167 - (os.clock() - v1168)
							local v1174 = task.wait
							local v1175 = v1173 / 8
							v1174((math.clamp(v1175, 0.08, 0.35)))
						end
					end)
					return
				end
			elseif v1139 == "explode" then
				local v1176 = p_u_1136.p
				if typeof(v1176) == "Vector3" then
					local v1177 = v_u_12.explosion
					local v1178 = p_u_1136.r
					v1177(v1176, tonumber(v1178) or 18)
					local v1179 = not v1138 and 100 or (v1176 - v1138).Magnitude
					local v1180 = v_u_9
					if v1180 then
						v1180 = v_u_9.controllers.Audio
					end
					if v1180 and v1180.explosion then
						local v1181 = v1180.explosion
						local v1182 = p_u_1136.r
						local v1183 = tonumber(v1182) or 18
						pcall(v1181, v1176, v1183)
					else
						local v1184 = v1179 < 150 and "ev_explosion" or "ev_explosion_far"
						local v1185 = v_u_9
						if v1185 then
							v1185 = v_u_9.controllers.Audio
						end
						if v1185 and v1185.play3D then
							local v1186 = v1185.play3D
							pcall(v1186, v1184, v1176, nil)
						end
					end
					local v1187 = v_u_9
					if v1187 then
						v1187 = v_u_9.controllers.Camera
					end
					if v1187 and v1187.shake then
						local v1188 = v1187.shake
						local v1189 = 1.1 - v1179 / 90
						local v1190 = math.clamp(v1189, 0.05, 1)
						pcall(v1188, v1190, 0.6)
						return
					end
				end
			elseif v1139 == "flare" then
				local v1191 = p_u_1136.p
				if typeof(v1191) == "Vector3" then
					local v1192 = p_u_1136.p
					local v1193 = v_u_9
					if v1193 then
						v1193 = v_u_9.controllers.Audio
					end
					if v1193 and v1193.play3D then
						local v1194 = v1193.play3D
						pcall(v1194, "ev_flare_ignite", v1192, nil)
						return
					end
				end
			elseif v1139 == "flareshell" or v1139 == "flarebeacon" then
				local v1195 = v_u_9.lib.FlareShellFx.onFx
				pcall(v1195, p_u_1136)
			end
			return
		end
	end
	local v_u_1196 = p_u_1136.o
	if typeof(v_u_1196) ~= "Vector3" then
		return
	end
	local v1197 = not v1138 and 0 or (v_u_1196 - v1138).Magnitude
	local v_u_1198 = v_u_10.stats(p_u_1136.w, nil)
	local v1199 = v_u_6.CurrentCamera
	if v1199 and (v1197 <= 150 and p_u_1136.s ~= v_u_17.UserId) then
		local _, v1200 = v1199:WorldToViewportPoint(v_u_1196)
		local v1201, v1202, v1203, v1204, v1205, v1206, v1207, v1208, v1209
		if v1200 then
			local v1210 = v_u_9
			if v1210 then
				v1210 = v_u_9.controllers.Vision
			end
			local v1211
			if v1210 and v1210.isVisible then
				local v1212 = v1210.isVisible
				local v1213, v1214 = pcall(v1212, v_u_1196)
				v1211 = not v1213 and true or v1214 ~= false
			else
				v1211 = true
			end
			if v1211 then
				v_u_9.emit("weapon.remoteShot", v_u_1196, p_u_1136.w, p_u_1136.sup == true)
			else
				v1201 = v1199.CFrame:VectorToObjectSpace(v_u_1196 - v1199.CFrame.Position)
				v1202 = v1199.CFrame.UpVector
				v1203 = v1202.X
				v1204 = v1202.Z
				v1205 = Vector3.new(v1203, 0, v1204)
				v1206 = v1199.CFrame.RightVector
				v1207 = v_u_1196 - (v1138 or v1199.CFrame.Position)
				v1208 = v1207:Dot(v1206)
				if v1205.Magnitude > 0.01 then
					v1209 = v1207:Dot(v1205.Unit)
				else
					v1209 = -v1201.Z
				end
				v_u_13.shotMarker(math.atan2(v1208, v1209), p_u_1136.sup and 0.4 or 1 - v1197 / 200)
				v_u_9.emit("weapon.remoteShot", v_u_1196, p_u_1136.w, p_u_1136.sup == true)
			end
		else
			v1201 = v1199.CFrame:VectorToObjectSpace(v_u_1196 - v1199.CFrame.Position)
			v1202 = v1199.CFrame.UpVector
			v1203 = v1202.X
			v1204 = v1202.Z
			v1205 = Vector3.new(v1203, 0, v1204)
			v1206 = v1199.CFrame.RightVector
			v1207 = v_u_1196 - (v1138 or v1199.CFrame.Position)
			v1208 = v1207:Dot(v1206)
			if v1205.Magnitude > 0.01 then
				v1209 = v1207:Dot(v1205.Unit)
			else
				v1209 = -v1201.Z
			end
			v_u_13.shotMarker(math.atan2(v1208, v1209), p_u_1136.sup and 0.4 or 1 - v1197 / 200)
			v_u_9.emit("weapon.remoteShot", v_u_1196, p_u_1136.w, p_u_1136.sup == true)
		end
	end
	local v_u_1215 = v_u_9
	if v_u_1215 then
		v_u_1215 = v_u_9.controllers.Audio
	end
	if v_u_1215 and v_u_1215.gunshot then
		local v1216 = v_u_1215.gunshot
		local v1217 = p_u_1136.w
		local v1218 = p_u_1136.sup == true
		pcall(v1216, v1217, v_u_1196, v1218, false)
	end
	if v1197 > 170 then
		return
	end
	local v1219 = v_u_3:GetPlayerByUserId(p_u_1136.s)
	if v1219 then
		v1219 = v1219.Character
	end
	local v1220 = p_u_1136.sd == 2 and 2 or 1
	local v1221 = v_u_376(v1219, v1220) or CFrame.lookAt(v_u_1196, v_u_1196 + (p_u_1136.d or Vector3.new(0, 0, 1)))
	local v1222 = v_u_3:GetPlayerByUserId(p_u_1136.s or 0)
	local v1223, v1224
	if v_u_14 and v1222 then
		v1223, v1224 = v_u_14.tints(v1222, p_u_1136.w)
	else
		v1224 = nil
		v1223 = nil
	end
	local v1225 = v_u_9
	if v1225 then
		v1225 = v_u_9.controllers.Vision
	end
	local v1226
	if v1225 and v1225.isVisible then
		local v1227 = v1225.isVisible
		local v1228, v1229 = pcall(v1227, v_u_1196)
		v1226 = not v1228 and true or v1229 ~= false
	else
		v1226 = true
	end
	if v1226 or v1197 < 30 then
		local v1230 = v_u_8._feel(v_u_1198)
		v_u_12.muzzle(v1221, (v_u_1198 and (v_u_1198.flash or 1) or 1) * (not v1230 and 1 or v1230.flash), p_u_1136.sup == true, v1224)
		if v1230 and (p_u_1136.sup ~= true and v1197 < 90) then
			local function v1231()
				-- upvalues: (ref) v_u_9, (copy) v_u_1215, (copy) v_u_1196, (copy) v_u_1198
				v_u_9.lib.ShotgunFeel.boom(v_u_1215, v_u_1196, v_u_1198, false)
			end
			pcall(v1231)
		end
		v_u_416(v1219, v_u_1198, v1220)
	end
	local v1232 = p_u_1136.h
	if type(v1232) == "table" then
		for v1233, v1234 in p_u_1136.h do
			local v1235 = v1234.p
			if typeof(v1235) ~= "Vector3" then
				continue
			end
			if v_u_1198 and (v_u_1198.tracer and (v1233 <= 4 and not v1234.nt)) then
				v_u_12.tracer(v1221.Position, v1235, p_u_1136.sup and 0.35 or 0.9, v1223)
			end
			if v1234.kl == true and (v_u_14 and v1222) then
				v_u_14.killAt(v1222, p_u_1136.w, v1235)
			end
			if v1234.m == "Air" then
				continue
			end
			if v1234.m == "Flesh" then
				v_u_12.blood(v1235, (v_u_1196 - v1235).Unit, 0.7)
			else
				v_u_12.impact(v1235, v1234.n, v1234.m)
			end
		end
	end
	if v_u_1198 and (v_u_1198.casing and (v1219 and v1197 < 80)) then
		if v1219 then
			v1219 = v1219:FindFirstChild(v1220 == 2 and "HeldWeapon2" or "HeldWeapon")
		end
		if not (v1219 and v1219:IsA("Model")) then
			v1219 = nil
		end
		local v1236
		if v1219 then
			v1236 = v1219.PrimaryPart or v1219:FindFirstChild("Handle", true)
			if v1236 then
				v1236 = v1236:FindFirstChild("Eject")
			end
			if not (v1236 and v1236:IsA("Attachment")) then
				v1236 = nil
			end
		else
			v1236 = nil
		end
		if v1236 then
			v_u_12.casing(v1236.WorldCFrame, v_u_1198.casing)
			return
		end
	end
end
local function v_u_1245(p1238) -- name: onHit
	-- upvalues: (ref) v_u_18, (ref) v_u_13, (ref) v_u_1552, (ref) v_u_1679, (ref) v_u_9, (ref) v_u_14, (ref) v_u_21, (copy) v_u_17, (ref) v_u_38, (copy) v_u_584, (copy) v_u_76, (ref) v_u_22, (ref) v_u_12
	if v_u_18 and type(p1238) == "table" then
		local v1239 = v_u_13.pulse
		local v1240 = p1238.kind
		v1239((tostring(v1240)))
		if p1238.kind ~= "kill" then
			if p1238.armor == true and (p1238.part ~= "arm" and p1238.part ~= "leg") then
				v_u_1552 = "ARMORED"
				v_u_1679 = os.clock() + 0.9
			elseif p1238.crippled == "legless" then
				v_u_1552 = "LEGS GONE"
				v_u_1679 = os.clock() + 1
			elseif p1238.knockdown == true then
				v_u_1552 = "KNOCKED DOWN"
				v_u_1679 = os.clock() + 1
			elseif p1238.crippled == "limp" then
				v_u_1552 = "LEG HIT"
				v_u_1679 = os.clock() + 0.8
			elseif p1238.crippled == "arms" then
				v_u_1552 = "ARMS HIT"
				v_u_1679 = os.clock() + 0.8
			end
		end
		local v1241 = p1238.pos
		if p1238.kind == "kill" and typeof(v1241) == "Vector3" then
			local v1242 = v_u_9
			if v1242 then
				v1242 = v_u_9.controllers.Camera
			end
			if v1242 and v1242.shake then
				local v1243 = v1242.shake
				pcall(v1243, 0.05, 0.08)
			end
			if v_u_14 and v_u_21 then
				v_u_14.killAt(v_u_17, v_u_21, v1241)
			end
		end
		if os.clock() - v_u_38 < 0.9 then
			local v1244 = p1238.pos
			if typeof(v1244) == "Vector3" then
				if os.clock() - (v_u_584.meleeHitT or 0) > 1.2 then
					v_u_76((not v_u_22 or v_u_22.kind ~= "melee") and "fists" or v_u_21, v1244, "hit")
				end
				v_u_12.blood(v1244, Vector3.new(0, 1, 0), 1)
			end
		end
	end
end
local v_u_1246 = {}
local function v_u_1264() -- name: watchFlares
	-- upvalues: (copy) v_u_6, (copy) v_u_1246, (ref) v_u_9, (copy) v_u_19
	local v1247 = v_u_6:FindFirstChild("HushCombat")
	if v1247 then
		local function v1253(p1248) -- name: add
			-- upvalues: (ref) v_u_1246, (ref) v_u_9
			if p1248.Name == "Flare" and (p1248:IsA("BasePart") and not v_u_1246[p1248]) then
				local v1249 = v_u_9
				if v1249 then
					v1249 = v_u_9.controllers.Audio
				end
				if v1249 and v1249.loop then
					local v1250 = v1249.loop
					local v1251, v1252 = pcall(v1250, "ev_flare_loop", p1248)
					if v1251 then
						v_u_1246[p1248] = v1252 or true
					end
				end
			end
		end
		for _, v1254 in v1247:GetChildren() do
			v1253(v1254)
		end
		local v1255 = v_u_19
		local v1256 = v1247.ChildAdded
		table.insert(v1255, v1256:Connect(v1253))
		local v1257 = v_u_19
		local v1258 = v1247.ChildRemoved
		local function v1263(p1259)
			-- upvalues: (ref) v_u_1246
			local v1260 = v_u_1246[p1259]
			v_u_1246[p1259] = nil
			if type(v1260) == "table" then
				local v1261 = v1260.stop
				if type(v1261) == "function" then
					local v1262 = v1260.stop
					pcall(v1262, v1260)
					return
				end
			end
			if typeof(v1260) == "Instance" then
				v1260:Destroy()
			end
		end
		table.insert(v1257, v1258:Connect(v1263))
	end
end
local function v_u_1278() -- name: teardown
	-- upvalues: (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62, (ref) v_u_1577, (ref) v_u_18, (copy) v_u_20, (copy) v_u_19, (copy) v_u_1246, (ref) v_u_1564, (copy) v_u_377, (copy) v_u_378, (ref) v_u_27, (ref) v_u_21, (ref) v_u_22, (copy) v_u_8, (copy) v_u_4, (ref) v_u_1641, (ref) v_u_42
	if v_u_1716 then
		v_u_1716 = false
		local v1265 = v_u_9.lib.GrenadeFx.hold
		pcall(v1265, false)
		v_u_12.arcPreview(nil)
		local v1266 = v_u_13.throwHint
		pcall(v1266, nil)
		if v_u_62 then
			v_u_62.Visible = false
		end
	end
	v_u_1577 = nil
	v_u_18 = false
	for _, v1267 in v_u_20 do
		pcall(v1267)
	end
	table.clear(v_u_20)
	for _, v1268 in v_u_19 do
		v1268:Disconnect()
	end
	table.clear(v_u_19)
	table.clear(v_u_1246)
	v_u_12.unmount()
	v_u_13.unmount()
	v_u_1564 = false
	table.clear(v_u_377)
	table.clear(v_u_378)
	v_u_27 = false
	v_u_21 = nil
	v_u_22 = nil
	local v1269 = v_u_8._tw
	local v1270 = v_u_8._tw
	local v1271 = v_u_8._tw
	local v1272 = v_u_8._tw
	v1269.on = false
	v1270.was = false
	v1271.m2 = 0
	v1272.side = 1
	v_u_4.MouseIconEnabled = true
	local v1273 = v_u_9
	if v1273 then
		v1273 = v_u_9.controllers.Camera
	end
	if v1273 and v1273.setAimShift then
		local v1274 = v1273.setAimShift
		pcall(v1274, nil)
	end
	v_u_1641 = -1
	if v_u_42 then
		v_u_42 = nil
		local v1275 = v_u_9
		if v1275 then
			v1275 = v_u_9.controllers.Input
		end
		if v1275 then
			local v1276 = v1275.setAimOverride
			if type(v1276) == "function" then
				local v1277 = v1275.setAimOverride
				pcall(v1277, nil)
				return
			end
		end
	end
end
local function v_u_1309() -- name: setup
	-- upvalues: (ref) v_u_18, (ref) v_u_12, (ref) v_u_13, (copy) v_u_1135, (copy) v_u_1264, (ref) v_u_9, (ref) v_u_57, (ref) v_u_62, (copy) v_u_19, (copy) v_u_4, (ref) v_u_1716, (copy) v_u_5, (copy) v_u_1237, (copy) v_u_1245, (copy) v_u_6
	if not v_u_18 then
		v_u_18 = true
		v_u_12.mount()
		v_u_13.mount()
		v_u_1135()
		v_u_1264()
		local v1279 = v_u_9
		if v1279 then
			v1279 = v_u_9.controllers.Input
		end
		if v1279 and (v1279.touchButton and not (v_u_57 and v_u_57.Parent)) then
			local v1280 = v1279.touchButton
			local v1281 = {
				["text"] = "THROW",
				["anchor"] = "BR",
				["pos"] = nil,
				["size"] = 48,
				["places"] = nil,
				["pos"] = Vector2.new(-352, -84),
				["places"] = { "Raid", "Hideout" }
			}
			local v1282, v1283 = pcall(v1280, "throw", v1281)
			if v1282 and (typeof(v1283) == "Instance" and v1283:IsA("GuiObject")) then
				v_u_57 = v1283
			end
		end
		if v1279 and (v1279.touchButton and not (v_u_62 and v_u_62.Parent)) then
			local v1284 = v1279.touchButton
			local v1285 = {
				["text"] = "CANCEL",
				["anchor"] = "BR",
				["pos"] = nil,
				["size"] = 52,
				["pos"] = Vector2.new(-356, -128)
			}
			local v1286, v1287 = pcall(v1284, "throwCancel", v1285)
			if v1286 and (typeof(v1287) == "Instance" and v1287:IsA("GuiObject")) then
				v_u_62 = v1287
				v1287.Visible = false
			end
		end
		local v1288 = v_u_19
		local v1289 = v_u_4.InputBegan
		local function v1293(p1290)
			-- upvalues: (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62
			if p1290.KeyCode == Enum.KeyCode.Escape and v_u_1716 then
				if not v_u_1716 then
					return
				end
				v_u_1716 = false
				local v1291 = v_u_9.lib.GrenadeFx.hold
				pcall(v1291, false)
				v_u_12.arcPreview(nil)
				local v1292 = v_u_13.throwHint
				pcall(v1292, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		end
		table.insert(v1288, v1289:Connect(v1293))
		local v1294 = v_u_19
		local v1295 = v_u_5.MenuOpened
		local function v1298()
			-- upvalues: (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62
			if v_u_1716 then
				v_u_1716 = false
				local v1296 = v_u_9.lib.GrenadeFx.hold
				pcall(v1296, false)
				v_u_12.arcPreview(nil)
				local v1297 = v_u_13.throwHint
				pcall(v1297, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		end
		table.insert(v1294, v1295:Connect(v1298))
		local v1299 = v_u_19
		local v1300 = v_u_9.net.listen
		local v1301 = v_u_1237
		table.insert(v1299, v1300("combat.fx", v1301))
		local v1302 = v_u_19
		local v1303 = v_u_9.net.listen
		local v1304 = v_u_1245
		table.insert(v1302, v1303("combat.hit", v1304))
		local v1305 = v_u_19
		local v1306 = v_u_6.ChildAdded
		local function v1308(p1307)
			-- upvalues: (ref) v_u_1264
			if p1307.Name == "HushCombat" then
				v_u_1264()
			end
		end
		table.insert(v1305, v1306:Connect(v1308))
	end
end
local function v_u_1311(p1310, _) -- name: onPlace
	-- upvalues: (copy) v_u_1278, (copy) v_u_1309
	if p1310 == "Raid" or p1310 == "Hideout" then
		v_u_1278()
		v_u_1309()
	else
		v_u_1278()
	end
end
function v_u_8.perkPack() -- name: perkPack
	-- upvalues: (copy) v_u_8, (ref) v_u_9, (copy) v_u_17, (ref) v_u_22
	local v1312 = v_u_8._pk
	if os.clock() >= v1312.t then
		v1312.t = os.clock() + 1
		if v_u_9.shared.PerkWeapon.refresh(v1312, v_u_17, v_u_9.config, v_u_9.shared.GameMode, game:GetService("ReplicatedStorage")) then
			v_u_22 = nil
		end
	end
	local v1313 = v_u_17.Character
	if not (v1313 and v1313.Parent) then
		v1313 = nil
	end
	if v1313 then
		v1313 = v1313:GetAttribute("WeaponSlot")
	end
	if v1312.slot ~= v1313 then
		v1312.slot = v1313
		v_u_22 = nil
	end
	return v1312.perk, v1312.training
end
function v_u_8.calmSpread(p1314, p1315, p1316) -- name: calmSpread
	-- upvalues: (ref) v_u_9, (copy) v_u_8, (copy) v_u_17
	return v_u_9.shared.PerkWeapon.cone(p1314, v_u_8.perkPack(), p1315, p1316, v_u_17:GetAttribute("PerkCalmOn") == true)
end
function v_u_8.throwDef(p1317) -- name: throwDef
	-- upvalues: (ref) v_u_9, (ref) v_u_10
	return v_u_9.shared.GrenadeRules.throwDef(p1317, v_u_10.throwable(p1317))
end
function v_u_8.perkThrow(p1318) -- name: perkThrow
	-- upvalues: (ref) v_u_9, (copy) v_u_8
	return v_u_9.shared.PerkWeapon.throw(v_u_8.throwDef(p1318), (v_u_8.perkPack()))
end
local v_u_1319 = ""
local function v_u_1347() -- name: syncWeapon
	-- upvalues: (copy) v_u_17, (ref) v_u_1319, (ref) v_u_22, (copy) v_u_8, (ref) v_u_9, (copy) v_u_79, (ref) v_u_21, (copy) v_u_585, (copy) v_u_584, (copy) v_u_603, (ref) v_u_1573, (ref) v_u_24, (ref) v_u_1581, (ref) v_u_27, (ref) v_u_52, (ref) v_u_50, (ref) v_u_10, (ref) v_u_25, (ref) v_u_23
	local v1320 = v_u_17.Character
	if not (v1320 and v1320.Parent) then
		v1320 = nil
	end
	if v1320 then
		v1320 = v1320:GetAttribute("Weapon")
	end
	if type(v1320) ~= "string" or v1320 == "" then
		v1320 = nil
	end
	local v1321 = v_u_17.Character
	if not (v1321 and v1321.Parent) then
		v1321 = nil
	end
	if v1321 then
		v1321 = v1321:GetAttribute("WeaponMods")
	end
	local v1322 = type(v1321) ~= "string" and "" or v1321
	if v1322 ~= v_u_1319 then
		v_u_1319 = v1322
		v_u_22 = nil
	end
	v_u_8.perkPack()
	local v1323 = v_u_9.lib.TwinFire.read(v_u_79, v_u_21, v_u_9.shared.TwinRules)
	v_u_8._tw.on = v1323
	if v1323 ~= v_u_8._tw.was then
		v_u_8._tw.was = v1323
		v_u_22 = nil
		v_u_8._tw.side = 1
		v_u_8._tw.last2 = -1
	end
	local v1324 = v_u_17.Character
	if not (v1324 and v1324.Parent) then
		v1324 = nil
	end
	if v1324 then
		v1324 = v1324:GetAttribute("WeaponUid")
	end
	if v1324 ~= v_u_585.lastUid then
		v_u_585.lastUid = v1324
		if v_u_584.t > 0 and v_u_584.uid ~= v1324 then
			v_u_603()
		end
	end
	if v1320 ~= v_u_21 then
		v_u_8._pk.prevId = v_u_21
		v_u_21 = v1320
		v_u_22 = nil
		v_u_1573 = 0
		v_u_24 = 0
		v_u_1581 = v_u_27
		v_u_52 = -1
		if v1320 then
			v_u_50 = v1320
		end
	end
	if v_u_21 and not v_u_22 then
		local v1325
		if v_u_1319 == "" then
			v1325 = nil
		else
			v1325 = string.split(v_u_1319, ",")
		end
		local v1326, v1327 = v_u_8.perkPack()
		local v1328 = v_u_8._pk.prevId
		local v1329
		if v1328 == nil then
			v1329 = nil
		else
			local v1330 = v_u_10.stats
			local v1331
			v1331, v1329 = pcall(v1330, v1328, nil)
			if not v1331 then
				v1329 = nil
			end
			v_u_8._pk.prevId = nil
		end
		local v1332 = v_u_10.forHand
		local v1333 = v_u_21
		local v1334 = {
			["perk"] = v1326
		}
		local v1335 = v_u_17.Character
		if not (v1335 and v1335.Parent) then
			v1335 = nil
		end
		if v1335 then
			v1335 = v1335:GetAttribute("WeaponSlot")
		end
		v1334.slot = v1335
		v1334.prevStats = v1329
		v1334.training = v1327
		v1334.inst = v1323 and {
			["tw"] = true
		} or nil
		local v1336, v1337 = pcall(v1332, v1333, v1325, v1334)
		if not v1336 or v1337 == nil then
			v1337 = v_u_10.stats(v_u_21, v1325)
		end
		v_u_22 = v1337
		if v_u_22 and v_u_22.kind == "firearm" then
			v_u_22 = table.clone(v_u_22)
			local v1338 = v_u_22
			local v1339 = v_u_17.Character
			if not (v1339 and v1339.Parent) then
				v1339 = nil
			end
			if v1339 then
				v1339 = v1339:GetAttribute("Suppressed")
			end
			v1338.suppressed = v1339 == true
			local v1340 = v_u_22
			local v1341 = v_u_17.Character
			if not (v1341 and v1341.Parent) then
				v1341 = nil
			end
			if v1341 then
				v1341 = v1341:GetAttribute("MagSize")
			end
			v1340.capacity = tonumber(v1341) or v_u_22.capacity
		end
	end
	if v_u_22 and v_u_22.kind == "firearm" then
		local v1342 = v_u_17.Character
		if not (v1342 and v1342.Parent) then
			v1342 = nil
		end
		if v1342 then
			v1342 = v1342:GetAttribute("Suppressed")
		end
		local v1343 = v1342 == true
		if v_u_22.suppressed ~= v1343 then
			v_u_22 = table.clone(v_u_22)
			v_u_22.suppressed = v1343
		end
		local v1344 = v_u_17.Character
		if not (v1344 and v1344.Parent) then
			v1344 = nil
		end
		if v1344 then
			v1344 = v1344:GetAttribute("Ammo")
		end
		local v1345 = tonumber(v1344) or 0
		if v1345 == v_u_52 then
			if os.clock() - v_u_25 > 0.6 and v_u_23 ~= v1345 then
				v_u_23 = v1345
			end
			if v1323 then
				v_u_9.lib.TwinFire.sync(v_u_8._tw, v_u_79, os.clock(), v_u_25)
			end
		else
			v_u_52 = v1345
			if os.clock() - v_u_25 > 0.35 or v1345 < v_u_23 then
				v_u_23 = v1345
				if v1323 then
					v_u_9.lib.TwinFire.sync(v_u_8._tw, v_u_79, os.clock(), v_u_25)
				end
			else
				local v1346 = v_u_17.Character
				if not (v1346 and v1346.Parent) then
					v1346 = nil
				end
				if v1346 then
					v1346 = v1346:GetAttribute("Reloading")
				end
				if v1346 == true then
					v_u_23 = v1345
					if v1323 then
						v_u_9.lib.TwinFire.sync(v_u_8._tw, v_u_79, os.clock(), v_u_25)
					end
				elseif v1323 then
					v_u_9.lib.TwinFire.sync(v_u_8._tw, v_u_79, os.clock(), v_u_25)
				end
			end
		end
	end
end
local v_u_1348 = false
local function v_u_1359() -- name: reloadSounds
	-- upvalues: (copy) v_u_17, (copy) v_u_585, (copy) v_u_594, (ref) v_u_1348, (ref) v_u_21, (ref) v_u_51, (ref) v_u_11, (copy) v_u_2, (ref) v_u_9
	local v1349 = v_u_17.Character
	if not (v1349 and v1349.Parent) then
		v1349 = nil
	end
	if v1349 then
		v1349 = v1349:GetAttribute("Reloading")
	end
	local v1350 = v1349 == true and not v_u_585.pending()
	if v1350 then
		v1350 = not v_u_594.pending()
	end
	if v1350 and (not v_u_1348 and v_u_21) then
		v_u_51 = v_u_51 + 1
		if v_u_11 and v_u_11.weapons then
			local _ = v_u_11.weapons[v_u_21]
		end
		local v1351 = v_u_17.Character
		if not (v1351 and v1351.Parent) then
			v1351 = nil
		end
		if v1351 then
			v1351 = v1351:GetAttribute("ReloadEndsAt")
		end
		local v1352 = (tonumber(v1351) or 0) - v_u_2.now()
		local v1353 = math.max(0.3, v1352)
		v_u_9.emit("weapon.reload", v1353)
		local v1354 = v_u_17.Character
		if not (v1354 and v1354.Parent) then
			v1354 = nil
		end
		if v1354 then
			v1354 = v1354:GetAttribute("Jammed")
		end
		if v1354 == true then
			local v1355 = v_u_17.Character
			if not (v1355 and v1355.Parent) then
				v1355 = nil
			end
			if v1355 then
				v1355 = v1355:FindFirstChild("HumanoidRootPart")
			end
			if v1355 then
				local v1356 = v1355.Position
				local v1357 = v_u_9
				if v1357 then
					v1357 = v_u_9.controllers.Audio
				end
				if v1357 and v1357.play3D then
					local v1358 = v1357.play3D
					pcall(v1358, "rel_slide", v1356, nil)
				end
			end
		end
	end
	v_u_1348 = v1350
end
function v_u_8.step(p_u_1360) -- name: step
	-- upvalues: (ref) v_u_18, (copy) v_u_17, (copy) v_u_433, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_1564, (copy) v_u_4, (copy) v_u_1347, (copy) v_u_8, (copy) v_u_1359, (copy) v_u_585, (ref) v_u_1552, (ref) v_u_1679, (ref) v_u_22, (ref) v_u_57, (ref) v_u_1559, (ref) v_u_1572, (copy) v_u_138, (ref) v_u_1573, (ref) v_u_25, (copy) v_u_99, (ref) v_u_27, (copy) v_u_769, (ref) v_u_1575, (ref) v_u_1581, (ref) v_u_1562, (ref) v_u_10, (copy) v_u_856, (ref) v_u_33, (ref) v_u_1594, (copy) v_u_1102, (copy) v_u_106, (ref) v_u_1641, (ref) v_u_1577, (ref) v_u_1584, (copy) v_u_2, (ref) v_u_1716, (ref) v_u_60, (ref) v_u_62, (copy) v_u_1063, (ref) v_u_1672, (copy) v_u_1039, (ref) v_u_35, (copy) v_u_924, (copy) v_u_1003, (copy) v_u_6, (ref) v_u_15, (copy) v_u_113, (ref) v_u_42, (copy) v_u_376, (copy) v_u_371, (copy) v_u_131, (ref) v_u_39, (ref) v_u_1723, (ref) v_u_1724, (copy) v_u_49, (copy) v_u_594, (copy) v_u_584, (ref) v_u_1747, (ref) v_u_1654, (ref) v_u_1748, (copy) v_u_1044, (ref) v_u_23, (ref) v_u_1319, (ref) v_u_1604, (copy) v_u_3
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v1547, v1548, v1549, v1550, v1551, v1553, v1554, v1555, v1556, v1557, v1558, v1560, v1561, v1563, v1565, v1566, v1567, v1568, v1569, v1570, v1571, v1574, v1576, v1578, v1579, v1580, v1582, v1583, v1585, v1586, v1587, v1588, v1589, v1590, v1591, v1592, v1593, v1595, v1596, v1597, v1598, v1599, v1600, v1601, v1602, v1603, v1605, v1606, v1607, v1608, v1609, v1610, v1611, v1612, v1613, v1614, v1615, v1616, v1617, v1618, v1619, v1620, v1621, v1622, v1623, v1624, v1625, v1626, v1627, v1628, v1629, v1630, v1631, v1632, v1633, v1634, v1635, v1636, v1637, v1638, v1639, v1640, v1642, v1643, v1644, v1645, v1646, v1647, v1648, v1649, v1650, v1651, v1652, v1653, v1655, v1656, v1657, v1658, v1659, v1660, v1661, v1662, v1663, v1664, v1665, v1666, v1667, v1668, v1669, v1670, v1671, v1673, v1674, v1675, v1676, v1677, v1678, v1680, v1681, v1682, v1683, v1684, v1685, v1686, v1687, v1688, v1689, v1690, v1691, v1692, v1693, v1694, v1695, v1696, v1697, v1698, v1699, v1700, v1701, v1702, v1703, v1704, v1705, v1706, v1707, v1708, v1709, v1710, v1711, v1712, v1713, v1714, v1715, v1717, v1718, v1719, v1720, v1721, v1722, v1725, v1726, v1727, v1728, v1729, v1730, v1731, v1732, v1733, v1734, v1735, v1736, v1737, v1738, v1739, v1740, v1741, v1742, v1743, v1744, v1745, v1746, v1749, v1750, v1751, v1752, v1753
	local v1547, v1548, v1549, v1550, v1551, v_u_1552, v1553, v1554, v1555, v1556, v1557, v1558, v_u_1559, v1560, v1561, v_u_1562, v1563, v_u_1564, v1565, v1566, v1567, v1568, v1569, v1570, v1571, v_u_1572, v_u_1573, v1574, v_u_1575, v1576, v_u_1577, v1578, v1579, v1580, v_u_1581, v1582, v1583, v_u_1584, v1585, v1586, v1587, v1588, v1589, v1590, v1591, v1592, v1593, v_u_1594, v1595, v1596, v1597, v1598, v1599, v1600, v1601, v1602, v1603, v_u_1604, v1605, v1606, v1607, v1608, v1609, v1610, v1611, v1612, v1613, v1614, v1615, v1616, v1617, v1618, v1619, v1620, v1621, v1622, v1623, v1624, v1625, v1626, v1627, v1628, v1629, v1630, v1631, v1632, v1633, v1634, v1635, v1636, v1637, v1638, v1639, v1640, v_u_1641, v1642, v1643, v1644, v1645, v1646, v1647, v1648, v1649, v1650, v1651, v1652, v1653, v_u_1654, v1655, v1656, v1657, v1658, v1659, v1660, v1661, v1662, v1663, v1664, v1665, v1666, v1667, v1668, v1669, v1670, v1671, v_u_1672, v1673, v1674, v1675, v1676, v1677, v1678, v_u_1679, v1680, v1681, v1682, v1683, v1684, v1685, v1686, v1687, v1688, v1689, v1690, v1691, v1692, v1693, v1694, v1695, v1696, v1697, v1698, v1699, v1700, v1701, v1702, v1703, v1704, v1705, v1706, v1707, v1708, v1709, v1710, v1711, v1712, v1713, v1714, v1715, v_u_1716, v1717, v1718, v1719, v1720, v1721, v1722, v_u_1723, v_u_1724, v1725, v1726, v1727, v1728, v1729, v1730, v1731, v1732, v1733, v1734, v1735, v1736, v1737, v1738, v1739, v1740, v1741, v1742, v1743, v1744, v1745, v1746, v_u_1747, v_u_1748, v1749, v1750, v1751, v1752, v1753
	local v1754 = 28
	while true do
		if v1754 == 1 then
			v1626 = v_u_9
			if v1626 then
				v1626 = v_u_9.controllers.Input
			end
			if v1626 and v1626.device then
				v1750 = v1626.device
				v1547, v1658 = pcall(v1750)
				if v1547 and type(v1658) == "string" then
					if v1658 == "Keyboard" and not v_u_42 then
						v1651 = v_u_4:GetMouseLocation()
					else
						v1549, v1652 = v1605:WorldToViewportPoint(v1685)
						if v1652 then
							v1651 = Vector2.new(v1549.X, v1549.Y)
						else
							v1651 = v1550
						end
					end
				else
					v1658 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					if v1658 == "Keyboard" and not v_u_42 then
						v1651 = v_u_4:GetMouseLocation()
					else
						v1549, v1652 = v1605:WorldToViewportPoint(v1685)
						if v1652 then
							v1651 = Vector2.new(v1549.X, v1549.Y)
						else
							v1651 = v1550
						end
					end
				end
			else
				v1658 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
				if v1658 == "Keyboard" and not v_u_42 then
					v1651 = v_u_4:GetMouseLocation()
				else
					v1549, v1652 = v1605:WorldToViewportPoint(v1685)
					if v1652 then
						v1651 = Vector2.new(v1549.X, v1549.Y)
					else
						v1651 = v1550
					end
				end
			end
			if v1741.kind == "firearm" then
				v1659 = v_u_8.calmSpread(v_u_10.spread(v1741, v1638, v1556.AssemblyLinearVelocity.Magnitude > 2, v_u_1573, v1555:GetAttribute("Sprinting") == true), v1741, v1638)
				v1621 = (v1685 - v1593.Position).Magnitude
				v1622 = math.max(4, v1621)
				v1643 = math.rad(v1659)
				v1644 = math.tan(v1643) * v1622
				v1624 = v1605:WorldToViewportPoint(v1685)
				v1625 = v1605:WorldToViewportPoint(v1685 + v1605.CFrame.RightVector * v1644)
				v1660 = (Vector2.new(v1625.X, v1625.Y) - Vector2.new(v1624.X, v1624.Y)).Magnitude
				if v1664 and v1731 then
					v1731.setSpread(v1659)
					v1550, v1704, v1670 = v1731.crosshair(v1659, v1685)
					if not v1550 then
						v1670 = v1587
						v1704 = v1660
						v1550 = v1651
					end
					v1606 = v1731.adsBlend() >= 0.6
					v1587 = v1670
				else
					v1704 = v1660
					v1550 = v1651
				end
			else
				v1704 = 11
				if v1664 and v1731 then
					v1550 = v1731.crosshair(0, nil)
					if not v1550 then
						v1550 = v1651
					end
				else
					v1550 = v1651
				end
			end
			if v1638 then
				v1754 = 23
			else
				v1754 = 24
			end
		elseif v1754 == 2 then
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 3 then
			v1669 = v1751 == "Touch"
			pcall(v1608, v1705, v1669)
			if v_u_62 then
				v1754 = 13
			else
				v1754 = 12
			end
		elseif v1754 == 4 then
			v1751 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			v1669 = v1751 == "Touch"
			pcall(v1608, v1705, v1669)
			if v_u_62 then
				v1754 = 13
			else
				v1754 = 27
			end
		elseif v1754 == 5 then
			v1627 = v_u_17.Character
			if not (v1627 and v1627.Parent) then
				v1627 = nil
			end
			if v1627 then
				v1627 = v1627:GetAttribute("Throwable")
			end
			if v1602 and (type(v1627) == "string" and v1627 ~= "") then
				v1754 = 8
			else
				v1754 = 7
			end
		elseif v1754 == 6 then
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 7 then
			if v_u_1716 then
				v_u_1716 = false
				v1752 = v_u_9.lib.GrenadeFx.hold
				pcall(v1752, false)
				v_u_12.arcPreview(nil)
				v1671 = v_u_13.throwHint
				pcall(v1671, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 8 then
			if v1742 - v_u_1672 > 0.5 then
				v1754 = 9
			else
				v1754 = 22
			end
		elseif v1754 == 9 then
			v1607 = v_u_9.lib.GrenadeFx.hold
			pcall(v1607, true, v1627)
			v_u_1672 = v1742
			v1608 = v_u_13.throwHint
			v1705 = v_u_1039()
			v1609 = v_u_9
			if v1609 then
				v1609 = v_u_9.controllers.Input
			end
			if v1609 and v1609.device then
				v1754 = 11
			else
				v1754 = 10
			end
		elseif v1754 == 10 then
			v1751 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
			v1669 = v1751 == "Touch"
			pcall(v1608, v1705, v1669)
			if v_u_62 then
				v1754 = 13
			else
				v1754 = 2
			end
		elseif v1754 == 11 then
			v1588 = v1609.device
			v1589, v1751 = pcall(v1588)
			if v1589 and type(v1751) == "string" then
				v1754 = 3
			else
				v1754 = 4
			end
		elseif v1754 == 12 then
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 13 then
			v1717 = v_u_62
			v1753 = v_u_9
			if v1753 then
				v1753 = v_u_9.controllers.Input
			end
			if v1753 and v1753.device then
				v1628 = v1753.device
				v1629, v1636 = pcall(v1628)
				if v1629 and type(v1636) == "string" then
					v1717.Visible = v1636 == "Touch"
				else
					v1636 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					v1717.Visible = v1636 == "Touch"
				end
			else
				v1636 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
				v1717.Visible = v1636 == "Touch"
			end
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 14 then
			v1646 = v_u_17.Character
			if not (v1646 and v1646.Parent) then
				v1646 = nil
			end
			if v1646 then
				v1646 = v1646:GetAttribute("ReloadEndsAt")
			end
			v1647 = tonumber(v1646) or 0
			v1648 = v_u_17.Character
			if not (v1648 and v1648.Parent) then
				v1648 = nil
			end
			if v1648 then
				v1648 = v1648:GetAttribute("Reloading")
			end
			v1623 = v1648 == true and not v_u_585.pending()
			if v1623 then
				v1623 = not v_u_594.pending()
			end
			v1645 = 0
			if v1623 or not v_u_584.on() then
				if v1623 and v1647 > 0 then
					v1746 = v_u_2.now()
					if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
						if v1647 ~= v_u_1747 then
							if v_u_1747 == 0 and v_u_584.t == 0 then
								v_u_594.riseT = os.clock()
							end
							v_u_1747 = v1647
							v_u_1748 = v1746
							if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
								v_u_1748 = v1746 - (os.clock() - v_u_584.t)
							end
							v_u_584.t = 0
						end
					else
						v_u_1747 = v1647
						v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
					end
					v1749 = v1746 - v_u_1748
					v1714 = v1647 - v_u_1748
					v1715 = v1749 / math.max(0.1, v1714)
					v1645 = math.clamp(v1715, 0, 1)
				else
					v_u_1747 = 0
				end
			else
				v1661 = os.clock() - v_u_584.t
				v1551 = v_u_584.dur
				v1653 = v1661 / math.max(0.1, v1551)
				v1645 = math.clamp(v1653, 0, 0.97)
				v1623 = true
			end
			v_u_1654 = v1645
			if v_u_1679 < v1742 then
				v_u_1552 = ""
			end
			if v1703 then
				v1655 = v_u_13.update
				v1720 = {
					["visible"] = nil,
					["aiming"] = true,
					["melee"] = true,
					["ammo"] = 0,
					["mag"] = 0,
					["reloading"] = false,
					["reloadFrac"] = 0,
					["jammed"] = false,
					["hint"] = "",
					["note"] = nil
				}
				if v1602 then
					v1662 = v1550 ~= nil
				else
					v1662 = v1602
				end
				v1720.visible = v1662
				if v1742 < v_u_1679 and v_u_1552 ~= "" then
					v1721 = v_u_1552
				else
					v1721 = v_u_1044()
				end
				v1720.note = v1721
				v1655(v1550, v1704, v1720)
			else
				v1690 = v_u_13.update
				v1691 = {}
				if v1602 then
					v1692 = v1550 ~= nil
				else
					v1692 = v1602
				end
				v1691.visible = v1692
				v1691.aiming = v1638
				if v1741 == nil then
					v1693 = false
				else
					v1693 = v1741.kind == "melee"
				end
				v1691.melee = v1693
				v1691.ammo = v_u_23
				v1691.mag = not v1741 and 0 or v1741.capacity
				v1691.reloading = v1623
				v1691.reloadFrac = v1645
				v1553 = v_u_17.Character
				if not (v1553 and v1553.Parent) then
					v1553 = nil
				end
				if v1553 then
					v1553 = v1553:GetAttribute("Jammed")
				end
				v1691.jammed = v1553 == true
				v1694 = v_u_9
				if v1694 then
					v1694 = v_u_9.controllers.Input
				end
				if v1694 and v1694.hint then
					v1597 = v1694.hint
					v1598, v1695 = pcall(v1597, "reload")
					v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
				else
					v1554 = ""
				end
				v1691.hint = v1554
				v1691.note = v_u_1552
				if v1664 then
					v1563 = nil
				else
					v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
				end
				v1691.sight = v1563
				v1691.adsHide = v1606
				v1691.blockedAt = v1587
				v1690(v1550, v1704, v1691)
			end
			if v1602 then
				if v1550 == nil then
					v1602 = false
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				else
					v1656 = v_u_9
					if v1656 then
						v1656 = v_u_9.controllers.Input
					end
					if v1656 and v1656.device then
						v1698 = v1656.device
						v1603, v1565 = pcall(v1698)
						if v1603 and type(v1565) == "string" then
							v1602 = v1565 == "Keyboard"
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
					else
						v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
						v1602 = v1565 == "Keyboard"
					end
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
			else
				if v1602 then
					v_u_1564 = true
					if v_u_4.MouseIconEnabled then
						v_u_4.MouseIconEnabled = false
					end
				elseif v_u_1564 then
					v_u_1564 = false
					v_u_4.MouseIconEnabled = true
				end
				if v1742 - v_u_1604 <= 0.033 then
					return
				end
			end
			v_u_1604 = v1742
			v1699 = {}
			v1700 = v_u_113() ~= nil
			if v1700 then
				v1701 = v_u_49.get()
			else
				v1701 = nil
			end
			for v1765, v1766 in v_u_3:GetPlayers() do
				v1702 = v1766.Character
				if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
					v1718 = v1766.UserId
					v1699[tostring(v1718)] = true
				else
					if not v1702 or v1702:GetAttribute("Laser") ~= true then
						continue
					end
					if v1702 then
						v1657 = v1702:FindFirstChild("HeldWeapon")
					else
						v1657 = v1702
					end
					if not (v1657 and v1657:IsA("Model")) then
						v1657 = nil
					end
					if v1657 then
						v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
						if v1566 then
							v1566 = v1566:FindFirstChild("LaserEmitter")
						end
						if not (v1566 and v1566:IsA("Attachment")) then
							v1566 = nil
						end
					else
						v1566 = nil
					end
					if not v1566 then
						continue
					end
					v1666 = v1766.UserId
					v1667 = tostring(v1666)
					v1668 = v1566.WorldPosition
					if v1766 == v_u_17 then
						v1630 = v_u_106()
					else
						v1630 = v1702:GetAttribute("Aiming") == true
					end
					v1631 = v_u_12.laserDir
					v1632 = v1566.WorldCFrame
					if v1766 == v_u_17 then
						v1633 = v_u_131()
					else
						v1633 = v1702:GetAttribute("AimYaw")
					end
					if v1766 == v_u_17 then
						v1634 = v_u_371(v1668.Y)
					else
						v1634 = nil
					end
					v1567 = not v1630
					if not v1567 then
						if v1701 == nil then
							v1567 = false
						else
							v1567 = v1701.followBarrel(v1700)
						end
					end
					v1635 = v1631(v1632, v1633, v1634, v1567)
					v1568 = v_u_8._laserParams(v1702)
					v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
					if v1569 then
						v1719 = v1569.Position
					else
						v1719 = v1668 + v1635 * 120
					end
					if v1701 ~= nil and v1701.followBarrel(v1700) then
						v1599 = v_u_49.clip
						if v1569 then
							v1600 = v1569.Distance
						else
							v1600 = v1701.MAX_LEN
						end
						v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
					end
					if v1766 == v_u_17 then
						v_u_12.laser(v1667, v1668, v1719)
						v1699[v1667] = true
					else
						v1570 = v_u_9
						if v1570 then
							v1570 = v_u_9.controllers.Vision
						end
						if v1570 and v1570.isVisible then
							v1649 = v1570.isVisible
							v1650, v1601 = pcall(v1649, v1668)
							v1696 = not v1650 and true or v1601 ~= false
						else
							v1696 = true
						end
						if v1696 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v_u_12.laser(v1667, nil, nil)
							v1699[v1667] = true
						end
					end
				end
			end
			v_u_12.clearLasers(v1699)
			return
		elseif v1754 == 15 then
			v1548 = v_u_15.owned
			v1697 = v_u_9
			v1730 = v_u_9
			if v1730 then
				v1730 = v_u_9.controllers.Input
			end
			if v1730 and v1730.device then
				v1663 = v1730.device
				v1590, v1591 = pcall(v1663)
				if v1590 and type(v1591) == "string" then
					v1592 = v1548(v1697, v1591 == "Keyboard") == true
				else
					v1591 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					v1592 = v1548(v1697, v1591 == "Keyboard") == true
				end
			else
				v1591 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
				v1592 = v1548(v1697, v1591 == "Keyboard") == true
			end
			if v1741 == nil and not v1703 then
				v1602 = v1703
			elseif v1602 then
				if v1605 == nil then
					v1602 = false
				else
					v1602 = not v1592
				end
			end
			v1550 = nil
			v1704 = 10
			if v1703 then
				v1731 = nil
			else
				v1731 = v_u_113()
			end
			if v1731 == nil then
				v1664 = false
			else
				v1664 = not v_u_42
			end
			v1587 = nil
			v1606 = false
			if v1703 and v1605 then
				v_u_12.aimLine(nil, nil)
				v1704 = 11
				v1673 = v_u_9
				if v1673 then
					v1673 = v_u_9.controllers.Input
				end
				if v1673 and v1673.device then
					v1674 = v1673.device
					v1665, v1732 = pcall(v1674)
					if v1665 and type(v1732) == "string" then
						if v1732 == "Keyboard" and not v_u_42 then
							v1550 = v_u_4:GetMouseLocation()
						elseif v1642 then
							v1682, v1683 = v1605:WorldToViewportPoint(v1642)
							if v1683 then
								v1550 = Vector2.new(v1682.X, v1682.Y)
							end
						end
					else
						v1732 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
						if v1732 == "Keyboard" and not v_u_42 then
							v1550 = v_u_4:GetMouseLocation()
						elseif v1642 then
							v1682, v1683 = v1605:WorldToViewportPoint(v1642)
							if v1683 then
								v1550 = Vector2.new(v1682.X, v1682.Y)
							end
						end
					end
				else
					v1732 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					if v1732 == "Keyboard" and not v_u_42 then
						v1550 = v_u_4:GetMouseLocation()
					elseif v1642 then
						v1682, v1683 = v1605:WorldToViewportPoint(v1642)
						if v1683 then
							v1550 = Vector2.new(v1682.X, v1682.Y)
						end
					end
				end
				v1646 = v_u_17.Character
				if not (v1646 and v1646.Parent) then
					v1646 = nil
				end
				if v1646 then
					v1646 = v1646:GetAttribute("ReloadEndsAt")
				end
				v1647 = tonumber(v1646) or 0
				v1648 = v_u_17.Character
				if not (v1648 and v1648.Parent) then
					v1648 = nil
				end
				if v1648 then
					v1648 = v1648:GetAttribute("Reloading")
				end
				v1623 = v1648 == true and not v_u_585.pending()
				if v1623 then
					v1623 = not v_u_594.pending()
				end
				v1645 = 0
				if v1623 or not v_u_584.on() then
					if v1623 and v1647 > 0 then
						v1746 = v_u_2.now()
						if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
							if v1647 ~= v_u_1747 then
								if v_u_1747 == 0 and v_u_584.t == 0 then
									v_u_594.riseT = os.clock()
								end
								v_u_1747 = v1647
								v_u_1748 = v1746
								if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
									v_u_1748 = v1746 - (os.clock() - v_u_584.t)
								end
								v_u_584.t = 0
							end
						else
							v_u_1747 = v1647
							v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
						end
						v1749 = v1746 - v_u_1748
						v1714 = v1647 - v_u_1748
						v1715 = v1749 / math.max(0.1, v1714)
						v1645 = math.clamp(v1715, 0, 1)
					else
						v_u_1747 = 0
					end
				else
					v1661 = os.clock() - v_u_584.t
					v1551 = v_u_584.dur
					v1653 = v1661 / math.max(0.1, v1551)
					v1645 = math.clamp(v1653, 0, 0.97)
					v1623 = true
				end
				v_u_1654 = v1645
				if v_u_1679 < v1742 then
					v_u_1552 = ""
				end
				if v1703 then
					v1655 = v_u_13.update
					v1720 = {
						["visible"] = nil,
						["aiming"] = true,
						["melee"] = true,
						["ammo"] = 0,
						["mag"] = 0,
						["reloading"] = false,
						["reloadFrac"] = 0,
						["jammed"] = false,
						["hint"] = "",
						["note"] = nil
					}
					if v1602 then
						v1662 = v1550 ~= nil
					else
						v1662 = v1602
					end
					v1720.visible = v1662
					if v1742 < v_u_1679 and v_u_1552 ~= "" then
						v1721 = v_u_1552
					else
						v1721 = v_u_1044()
					end
					v1720.note = v1721
					v1655(v1550, v1704, v1720)
				else
					v1690 = v_u_13.update
					v1691 = {}
					if v1602 then
						v1692 = v1550 ~= nil
					else
						v1692 = v1602
					end
					v1691.visible = v1692
					v1691.aiming = v1638
					if v1741 == nil then
						v1693 = false
					else
						v1693 = v1741.kind == "melee"
					end
					v1691.melee = v1693
					v1691.ammo = v_u_23
					v1691.mag = not v1741 and 0 or v1741.capacity
					v1691.reloading = v1623
					v1691.reloadFrac = v1645
					v1553 = v_u_17.Character
					if not (v1553 and v1553.Parent) then
						v1553 = nil
					end
					if v1553 then
						v1553 = v1553:GetAttribute("Jammed")
					end
					v1691.jammed = v1553 == true
					v1694 = v_u_9
					if v1694 then
						v1694 = v_u_9.controllers.Input
					end
					if v1694 and v1694.hint then
						v1597 = v1694.hint
						v1598, v1695 = pcall(v1597, "reload")
						v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
					else
						v1554 = ""
					end
					v1691.hint = v1554
					v1691.note = v_u_1552
					if v1664 then
						v1563 = nil
					else
						v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
					end
					v1691.sight = v1563
					v1691.adsHide = v1606
					v1691.blockedAt = v1587
					v1690(v1550, v1704, v1691)
				end
				if v1602 then
					if v1550 == nil then
						v1602 = false
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					else
						v1656 = v_u_9
						if v1656 then
							v1656 = v_u_9.controllers.Input
						end
						if v1656 and v1656.device then
							v1698 = v1656.device
							v1603, v1565 = pcall(v1698)
							if v1603 and type(v1565) == "string" then
								v1602 = v1565 == "Keyboard"
							else
								v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
								v1602 = v1565 == "Keyboard"
							end
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					end
				else
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
				v_u_1604 = v1742
				v1699 = {}
				v1700 = v_u_113() ~= nil
				if v1700 then
					v1701 = v_u_49.get()
				else
					v1701 = nil
				end
				for v1765, v1766 in v_u_3:GetPlayers() do
					v1702 = v1766.Character
					if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
						v1718 = v1766.UserId
						v1699[tostring(v1718)] = true
					else
						if not v1702 or v1702:GetAttribute("Laser") ~= true then
							continue
						end
						if v1702 then
							v1657 = v1702:FindFirstChild("HeldWeapon")
						else
							v1657 = v1702
						end
						if not (v1657 and v1657:IsA("Model")) then
							v1657 = nil
						end
						if v1657 then
							v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
							if v1566 then
								v1566 = v1566:FindFirstChild("LaserEmitter")
							end
							if not (v1566 and v1566:IsA("Attachment")) then
								v1566 = nil
							end
						else
							v1566 = nil
						end
						if not v1566 then
							continue
						end
						v1666 = v1766.UserId
						v1667 = tostring(v1666)
						v1668 = v1566.WorldPosition
						if v1766 == v_u_17 then
							v1630 = v_u_106()
						else
							v1630 = v1702:GetAttribute("Aiming") == true
						end
						v1631 = v_u_12.laserDir
						v1632 = v1566.WorldCFrame
						if v1766 == v_u_17 then
							v1633 = v_u_131()
						else
							v1633 = v1702:GetAttribute("AimYaw")
						end
						if v1766 == v_u_17 then
							v1634 = v_u_371(v1668.Y)
						else
							v1634 = nil
						end
						v1567 = not v1630
						if not v1567 then
							if v1701 == nil then
								v1567 = false
							else
								v1567 = v1701.followBarrel(v1700)
							end
						end
						v1635 = v1631(v1632, v1633, v1634, v1567)
						v1568 = v_u_8._laserParams(v1702)
						v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
						if v1569 then
							v1719 = v1569.Position
						else
							v1719 = v1668 + v1635 * 120
						end
						if v1701 ~= nil and v1701.followBarrel(v1700) then
							v1599 = v_u_49.clip
							if v1569 then
								v1600 = v1569.Distance
							else
								v1600 = v1701.MAX_LEN
							end
							v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
						end
						if v1766 == v_u_17 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v1570 = v_u_9
							if v1570 then
								v1570 = v_u_9.controllers.Vision
							end
							if v1570 and v1570.isVisible then
								v1649 = v1570.isVisible
								v1650, v1601 = pcall(v1649, v1668)
								v1696 = not v1650 and true or v1601 ~= false
							else
								v1696 = true
							end
							if v1696 then
								v_u_12.laser(v1667, v1668, v1719)
								v1699[v1667] = true
							else
								v_u_12.laser(v1667, nil, nil)
								v1699[v1667] = true
							end
						end
					end
				end
				v_u_12.clearLasers(v1699)
				return
			end
			if v1602 and (v1605 and v1741) then
				v1754 = 17
			else
				v1754 = 16
			end
		elseif v1754 == 16 then
			v_u_12.aimLine(nil, nil)
			v1646 = v_u_17.Character
			if not (v1646 and v1646.Parent) then
				v1646 = nil
			end
			if v1646 then
				v1646 = v1646:GetAttribute("ReloadEndsAt")
			end
			v1647 = tonumber(v1646) or 0
			v1648 = v_u_17.Character
			if not (v1648 and v1648.Parent) then
				v1648 = nil
			end
			if v1648 then
				v1648 = v1648:GetAttribute("Reloading")
			end
			v1623 = v1648 == true and not v_u_585.pending()
			if v1623 then
				v1623 = not v_u_594.pending()
			end
			v1645 = 0
			if v1623 or not v_u_584.on() then
				if v1623 and v1647 > 0 then
					v1746 = v_u_2.now()
					if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
						if v1647 ~= v_u_1747 then
							if v_u_1747 == 0 and v_u_584.t == 0 then
								v_u_594.riseT = os.clock()
							end
							v_u_1747 = v1647
							v_u_1748 = v1746
							if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
								v_u_1748 = v1746 - (os.clock() - v_u_584.t)
							end
							v_u_584.t = 0
						end
					else
						v_u_1747 = v1647
						v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
					end
					v1749 = v1746 - v_u_1748
					v1714 = v1647 - v_u_1748
					v1715 = v1749 / math.max(0.1, v1714)
					v1645 = math.clamp(v1715, 0, 1)
				else
					v_u_1747 = 0
				end
			else
				v1661 = os.clock() - v_u_584.t
				v1551 = v_u_584.dur
				v1653 = v1661 / math.max(0.1, v1551)
				v1645 = math.clamp(v1653, 0, 0.97)
				v1623 = true
			end
			v_u_1654 = v1645
			if v_u_1679 < v1742 then
				v_u_1552 = ""
			end
			if v1703 then
				v1655 = v_u_13.update
				v1720 = {
					["visible"] = nil,
					["aiming"] = true,
					["melee"] = true,
					["ammo"] = 0,
					["mag"] = 0,
					["reloading"] = false,
					["reloadFrac"] = 0,
					["jammed"] = false,
					["hint"] = "",
					["note"] = nil
				}
				if v1602 then
					v1662 = v1550 ~= nil
				else
					v1662 = v1602
				end
				v1720.visible = v1662
				if v1742 < v_u_1679 and v_u_1552 ~= "" then
					v1721 = v_u_1552
				else
					v1721 = v_u_1044()
				end
				v1720.note = v1721
				v1655(v1550, v1704, v1720)
			else
				v1690 = v_u_13.update
				v1691 = {}
				if v1602 then
					v1692 = v1550 ~= nil
				else
					v1692 = v1602
				end
				v1691.visible = v1692
				v1691.aiming = v1638
				if v1741 == nil then
					v1693 = false
				else
					v1693 = v1741.kind == "melee"
				end
				v1691.melee = v1693
				v1691.ammo = v_u_23
				v1691.mag = not v1741 and 0 or v1741.capacity
				v1691.reloading = v1623
				v1691.reloadFrac = v1645
				v1553 = v_u_17.Character
				if not (v1553 and v1553.Parent) then
					v1553 = nil
				end
				if v1553 then
					v1553 = v1553:GetAttribute("Jammed")
				end
				v1691.jammed = v1553 == true
				v1694 = v_u_9
				if v1694 then
					v1694 = v_u_9.controllers.Input
				end
				if v1694 and v1694.hint then
					v1597 = v1694.hint
					v1598, v1695 = pcall(v1597, "reload")
					v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
				else
					v1554 = ""
				end
				v1691.hint = v1554
				v1691.note = v_u_1552
				if v1664 then
					v1563 = nil
				else
					v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
				end
				v1691.sight = v1563
				v1691.adsHide = v1606
				v1691.blockedAt = v1587
				v1690(v1550, v1704, v1691)
			end
			if v1602 then
				if v1550 == nil then
					v1602 = false
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				else
					v1656 = v_u_9
					if v1656 then
						v1656 = v_u_9.controllers.Input
					end
					if v1656 and v1656.device then
						v1698 = v1656.device
						v1603, v1565 = pcall(v1698)
						if v1603 and type(v1565) == "string" then
							v1602 = v1565 == "Keyboard"
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
					else
						v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
						v1602 = v1565 == "Keyboard"
					end
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
			else
				if v1602 then
					v_u_1564 = true
					if v_u_4.MouseIconEnabled then
						v_u_4.MouseIconEnabled = false
					end
				elseif v_u_1564 then
					v_u_1564 = false
					v_u_4.MouseIconEnabled = true
				end
				if v1742 - v_u_1604 <= 0.033 then
					return
				end
			end
			v_u_1604 = v1742
			v1699 = {}
			v1700 = v_u_113() ~= nil
			if v1700 then
				v1701 = v_u_49.get()
			else
				v1701 = nil
			end
			for v1765, v1766 in v_u_3:GetPlayers() do
				v1702 = v1766.Character
				if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
					v1718 = v1766.UserId
					v1699[tostring(v1718)] = true
				else
					if not v1702 or v1702:GetAttribute("Laser") ~= true then
						continue
					end
					if v1702 then
						v1657 = v1702:FindFirstChild("HeldWeapon")
					else
						v1657 = v1702
					end
					if not (v1657 and v1657:IsA("Model")) then
						v1657 = nil
					end
					if v1657 then
						v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
						if v1566 then
							v1566 = v1566:FindFirstChild("LaserEmitter")
						end
						if not (v1566 and v1566:IsA("Attachment")) then
							v1566 = nil
						end
					else
						v1566 = nil
					end
					if not v1566 then
						continue
					end
					v1666 = v1766.UserId
					v1667 = tostring(v1666)
					v1668 = v1566.WorldPosition
					if v1766 == v_u_17 then
						v1630 = v_u_106()
					else
						v1630 = v1702:GetAttribute("Aiming") == true
					end
					v1631 = v_u_12.laserDir
					v1632 = v1566.WorldCFrame
					if v1766 == v_u_17 then
						v1633 = v_u_131()
					else
						v1633 = v1702:GetAttribute("AimYaw")
					end
					if v1766 == v_u_17 then
						v1634 = v_u_371(v1668.Y)
					else
						v1634 = nil
					end
					v1567 = not v1630
					if not v1567 then
						if v1701 == nil then
							v1567 = false
						else
							v1567 = v1701.followBarrel(v1700)
						end
					end
					v1635 = v1631(v1632, v1633, v1634, v1567)
					v1568 = v_u_8._laserParams(v1702)
					v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
					if v1569 then
						v1719 = v1569.Position
					else
						v1719 = v1668 + v1635 * 120
					end
					if v1701 ~= nil and v1701.followBarrel(v1700) then
						v1599 = v_u_49.clip
						if v1569 then
							v1600 = v1569.Distance
						else
							v1600 = v1701.MAX_LEN
						end
						v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
					end
					if v1766 == v_u_17 then
						v_u_12.laser(v1667, v1668, v1719)
						v1699[v1667] = true
					else
						v1570 = v_u_9
						if v1570 then
							v1570 = v_u_9.controllers.Vision
						end
						if v1570 and v1570.isVisible then
							v1649 = v1570.isVisible
							v1650, v1601 = pcall(v1649, v1668)
							v1696 = not v1650 and true or v1601 ~= false
						else
							v1696 = true
						end
						if v1696 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v_u_12.laser(v1667, nil, nil)
							v1699[v1667] = true
						end
					end
				end
			end
			v_u_12.clearLasers(v1699)
			return
		elseif v1754 == 17 then
			v1593 = v_u_376(v1555)
			v1675 = v1593.Position.Y
			v1684 = v1556.Position.Y + 0.6
			v1733 = math.max(v1675, v1684)
			v1685 = v_u_371(v1733)
			if not v1685 then
				v1734 = v1556.Position
				v1735 = v_u_131()
				v1686 = -math.sin(v1735)
				v1613 = -math.cos(v1735)
				v1685 = v1734 + Vector3.new(v1686, 0, v1613) * 25
			end
			v1676 = v_u_8._wr
			if v1676 and v_u_8._rk == "lean" then
				v1687 = v1676.track
				v1736 = v1556.Position
				v1614 = v1556.Position.X
				v1737 = v1556.Position.Z
				v1688 = v1685 - Vector3.new(v1614, v1733, v1737)
				v1615 = v_u_131()
				v1677 = -math.sin(v1615)
				v1689 = -math.cos(v1615)
				v1678, v1616 = v1687(v1555, v1736, v1688, (Vector3.new(v1677, 0, v1689)))
				if v1616 and v1616.hint then
					v_u_1552 = v1616.hint
					v_u_1679 = os.clock() + 1.2
				end
			else
				v1616 = nil
				v1678 = nil
			end
			if v_u_39 == nil then
				v1754 = 19
			else
				v1754 = 18
			end
		elseif v1754 == 18 then
			v1722 = v_u_9
			if v1722 then
				v1722 = v_u_9.controllers.Input
			end
			if v1722 and v1722.device then
				v1680 = v1722.device
				v1681, v1706 = pcall(v1680)
				if v1681 and type(v1706) == "string" then
					if (v1706 == "Keyboard" or v1664) and not v_u_42 then
						v1617 = os.clock()
						v_u_1723 = v1685
						v_u_1724 = v1617
					end
				else
					v1706 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					if (v1706 == "Keyboard" or v1664) and not v_u_42 then
						v1617 = os.clock()
						v_u_1723 = v1685
						v_u_1724 = v1617
					end
				end
			else
				v1706 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
				if (v1706 == "Keyboard" or v1664) and not v_u_42 then
					v1617 = os.clock()
					v_u_1723 = v1685
					v_u_1724 = v1617
				end
			end
			if v1664 then
				v1754 = 20
			else
				v1754 = 21
			end
		elseif v1754 == 19 then
			if v1664 then
				v1754 = 20
			else
				v1754 = 1
			end
		elseif v1754 == 20 then
			v1651 = Vector2.new(v1605.ViewportSize.X * 0.5, v1605.ViewportSize.Y * 0.5)
			v1725 = v_u_49
			v1618 = v_u_49
			v1619 = v_u_49
			v1707 = (v1685 - v1605.CFrame.Position).Magnitude
			v1708 = v_u_39 ~= nil
			v1725.dist = v1707
			v1618.distAt = v1742
			v1619.zombie = v1708
			if v1741.kind == "firearm" then
				v1659 = v_u_8.calmSpread(v_u_10.spread(v1741, v1638, v1556.AssemblyLinearVelocity.Magnitude > 2, v_u_1573, v1555:GetAttribute("Sprinting") == true), v1741, v1638)
				v1621 = (v1685 - v1593.Position).Magnitude
				v1622 = math.max(4, v1621)
				v1643 = math.rad(v1659)
				v1644 = math.tan(v1643) * v1622
				v1624 = v1605:WorldToViewportPoint(v1685)
				v1625 = v1605:WorldToViewportPoint(v1685 + v1605.CFrame.RightVector * v1644)
				v1660 = (Vector2.new(v1625.X, v1625.Y) - Vector2.new(v1624.X, v1624.Y)).Magnitude
				if v1664 and v1731 then
					v1731.setSpread(v1659)
					v1550, v1704, v1670 = v1731.crosshair(v1659, v1685)
					if not v1550 then
						v1670 = v1587
						v1704 = v1660
						v1550 = v1651
					end
					v1606 = v1731.adsBlend() >= 0.6
					v1587 = v1670
				else
					v1704 = v1660
					v1550 = v1651
				end
			else
				v1704 = 11
				if v1664 and v1731 then
					v1550 = v1731.crosshair(0, nil)
					if not v1550 then
						v1550 = v1651
					end
				else
					v1550 = v1651
				end
			end
			if not v1638 then
				v_u_12.aimLine(nil, nil)
				v1646 = v_u_17.Character
				if not (v1646 and v1646.Parent) then
					v1646 = nil
				end
				if v1646 then
					v1646 = v1646:GetAttribute("ReloadEndsAt")
				end
				v1647 = tonumber(v1646) or 0
				v1648 = v_u_17.Character
				if not (v1648 and v1648.Parent) then
					v1648 = nil
				end
				if v1648 then
					v1648 = v1648:GetAttribute("Reloading")
				end
				v1623 = v1648 == true and not v_u_585.pending()
				if v1623 then
					v1623 = not v_u_594.pending()
				end
				v1645 = 0
				if v1623 or not v_u_584.on() then
					if v1623 and v1647 > 0 then
						v1746 = v_u_2.now()
						if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
							if v1647 ~= v_u_1747 then
								if v_u_1747 == 0 and v_u_584.t == 0 then
									v_u_594.riseT = os.clock()
								end
								v_u_1747 = v1647
								v_u_1748 = v1746
								if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
									v_u_1748 = v1746 - (os.clock() - v_u_584.t)
								end
								v_u_584.t = 0
							end
						else
							v_u_1747 = v1647
							v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
						end
						v1749 = v1746 - v_u_1748
						v1714 = v1647 - v_u_1748
						v1715 = v1749 / math.max(0.1, v1714)
						v1645 = math.clamp(v1715, 0, 1)
					else
						v_u_1747 = 0
					end
				else
					v1661 = os.clock() - v_u_584.t
					v1551 = v_u_584.dur
					v1653 = v1661 / math.max(0.1, v1551)
					v1645 = math.clamp(v1653, 0, 0.97)
					v1623 = true
				end
				v_u_1654 = v1645
				if v_u_1679 < v1742 then
					v_u_1552 = ""
				end
				if v1703 then
					v1655 = v_u_13.update
					v1720 = {
						["visible"] = nil,
						["aiming"] = true,
						["melee"] = true,
						["ammo"] = 0,
						["mag"] = 0,
						["reloading"] = false,
						["reloadFrac"] = 0,
						["jammed"] = false,
						["hint"] = "",
						["note"] = nil
					}
					if v1602 then
						v1662 = v1550 ~= nil
					else
						v1662 = v1602
					end
					v1720.visible = v1662
					if v1742 < v_u_1679 and v_u_1552 ~= "" then
						v1721 = v_u_1552
					else
						v1721 = v_u_1044()
					end
					v1720.note = v1721
					v1655(v1550, v1704, v1720)
				else
					v1690 = v_u_13.update
					v1691 = {}
					if v1602 then
						v1692 = v1550 ~= nil
					else
						v1692 = v1602
					end
					v1691.visible = v1692
					v1691.aiming = v1638
					if v1741 == nil then
						v1693 = false
					else
						v1693 = v1741.kind == "melee"
					end
					v1691.melee = v1693
					v1691.ammo = v_u_23
					v1691.mag = not v1741 and 0 or v1741.capacity
					v1691.reloading = v1623
					v1691.reloadFrac = v1645
					v1553 = v_u_17.Character
					if not (v1553 and v1553.Parent) then
						v1553 = nil
					end
					if v1553 then
						v1553 = v1553:GetAttribute("Jammed")
					end
					v1691.jammed = v1553 == true
					v1694 = v_u_9
					if v1694 then
						v1694 = v_u_9.controllers.Input
					end
					if v1694 and v1694.hint then
						v1597 = v1694.hint
						v1598, v1695 = pcall(v1597, "reload")
						v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
					else
						v1554 = ""
					end
					v1691.hint = v1554
					v1691.note = v_u_1552
					if v1664 then
						v1563 = nil
					else
						v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
					end
					v1691.sight = v1563
					v1691.adsHide = v1606
					v1691.blockedAt = v1587
					v1690(v1550, v1704, v1691)
				end
				if v1602 then
					if v1550 == nil then
						v1602 = false
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					else
						v1656 = v_u_9
						if v1656 then
							v1656 = v_u_9.controllers.Input
						end
						if v1656 and v1656.device then
							v1698 = v1656.device
							v1603, v1565 = pcall(v1698)
							if v1603 and type(v1565) == "string" then
								v1602 = v1565 == "Keyboard"
							else
								v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
								v1602 = v1565 == "Keyboard"
							end
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					end
				else
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
				v_u_1604 = v1742
				v1699 = {}
				v1700 = v_u_113() ~= nil
				if v1700 then
					v1701 = v_u_49.get()
				else
					v1701 = nil
				end
				for v1765, v1766 in v_u_3:GetPlayers() do
					v1702 = v1766.Character
					if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
						v1718 = v1766.UserId
						v1699[tostring(v1718)] = true
					else
						if not v1702 or v1702:GetAttribute("Laser") ~= true then
							continue
						end
						if v1702 then
							v1657 = v1702:FindFirstChild("HeldWeapon")
						else
							v1657 = v1702
						end
						if not (v1657 and v1657:IsA("Model")) then
							v1657 = nil
						end
						if v1657 then
							v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
							if v1566 then
								v1566 = v1566:FindFirstChild("LaserEmitter")
							end
							if not (v1566 and v1566:IsA("Attachment")) then
								v1566 = nil
							end
						else
							v1566 = nil
						end
						if not v1566 then
							continue
						end
						v1666 = v1766.UserId
						v1667 = tostring(v1666)
						v1668 = v1566.WorldPosition
						if v1766 == v_u_17 then
							v1630 = v_u_106()
						else
							v1630 = v1702:GetAttribute("Aiming") == true
						end
						v1631 = v_u_12.laserDir
						v1632 = v1566.WorldCFrame
						if v1766 == v_u_17 then
							v1633 = v_u_131()
						else
							v1633 = v1702:GetAttribute("AimYaw")
						end
						if v1766 == v_u_17 then
							v1634 = v_u_371(v1668.Y)
						else
							v1634 = nil
						end
						v1567 = not v1630
						if not v1567 then
							if v1701 == nil then
								v1567 = false
							else
								v1567 = v1701.followBarrel(v1700)
							end
						end
						v1635 = v1631(v1632, v1633, v1634, v1567)
						v1568 = v_u_8._laserParams(v1702)
						v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
						if v1569 then
							v1719 = v1569.Position
						else
							v1719 = v1668 + v1635 * 120
						end
						if v1701 ~= nil and v1701.followBarrel(v1700) then
							v1599 = v_u_49.clip
							if v1569 then
								v1600 = v1569.Distance
							else
								v1600 = v1701.MAX_LEN
							end
							v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
						end
						if v1766 == v_u_17 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v1570 = v_u_9
							if v1570 then
								v1570 = v_u_9.controllers.Vision
							end
							if v1570 and v1570.isVisible then
								v1649 = v1570.isVisible
								v1650, v1601 = pcall(v1649, v1668)
								v1696 = not v1650 and true or v1601 ~= false
							else
								v1696 = true
							end
							if v1696 then
								v_u_12.laser(v1667, v1668, v1719)
								v1699[v1667] = true
							else
								v_u_12.laser(v1667, nil, nil)
								v1699[v1667] = true
							end
						end
					end
				end
				v_u_12.clearLasers(v1699)
				return
			end
			v1709 = v_u_17.Character
			if not (v1709 and v1709.Parent) then
				v1709 = nil
			end
			if v1709 then
				v1709 = v1709:GetAttribute("Laser")
			end
			if v1709 == true or (v1741.kind ~= "firearm" or v1664) then
				v_u_12.aimLine(nil, nil)
			else
				v1710 = v1593.Position
				v1620 = v1685 - v1710
				v1711 = v1620.Magnitude
				v1726 = math.min(v1711, 26)
				v1727 = v_u_12.aimLine
				v1728 = v1710 + (v1678 or v1620.Unit) * v1726
				if v1616 then
					v1712 = v1616.tint
				else
					v1712 = v1616
				end
				if v1616 then
					v1616 = v1616.stop
				end
				v1727(v1710, v1728, v1712, v1616)
			end
			v1754 = 14
		elseif v1754 == 21 then
			v1626 = v_u_9
			if v1626 then
				v1626 = v_u_9.controllers.Input
			end
			if v1626 and v1626.device then
				v1750 = v1626.device
				v1547, v1658 = pcall(v1750)
				if v1547 and type(v1658) == "string" then
					if v1658 == "Keyboard" and not v_u_42 then
						v1651 = v_u_4:GetMouseLocation()
					else
						v1549, v1652 = v1605:WorldToViewportPoint(v1685)
						if v1652 then
							v1651 = Vector2.new(v1549.X, v1549.Y)
						else
							v1651 = v1550
						end
					end
				else
					v1658 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					if v1658 == "Keyboard" and not v_u_42 then
						v1651 = v_u_4:GetMouseLocation()
					else
						v1549, v1652 = v1605:WorldToViewportPoint(v1685)
						if v1652 then
							v1651 = Vector2.new(v1549.X, v1549.Y)
						else
							v1651 = v1550
						end
					end
				end
			else
				v1658 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
				if v1658 == "Keyboard" and not v_u_42 then
					v1651 = v_u_4:GetMouseLocation()
				else
					v1549, v1652 = v1605:WorldToViewportPoint(v1685)
					if v1652 then
						v1651 = Vector2.new(v1549.X, v1549.Y)
					else
						v1651 = v1550
					end
				end
			end
			if v1741.kind == "firearm" then
				v1659 = v_u_8.calmSpread(v_u_10.spread(v1741, v1638, v1556.AssemblyLinearVelocity.Magnitude > 2, v_u_1573, v1555:GetAttribute("Sprinting") == true), v1741, v1638)
				v1621 = (v1685 - v1593.Position).Magnitude
				v1622 = math.max(4, v1621)
				v1643 = math.rad(v1659)
				v1644 = math.tan(v1643) * v1622
				v1624 = v1605:WorldToViewportPoint(v1685)
				v1625 = v1605:WorldToViewportPoint(v1685 + v1605.CFrame.RightVector * v1644)
				v1660 = (Vector2.new(v1625.X, v1625.Y) - Vector2.new(v1624.X, v1624.Y)).Magnitude
				if v1664 and v1731 then
					v1731.setSpread(v1659)
					v1550, v1704, v1670 = v1731.crosshair(v1659, v1685)
					if not v1550 then
						v1670 = v1587
						v1704 = v1660
						v1550 = v1651
					end
					v1606 = v1731.adsBlend() >= 0.6
					v1587 = v1670
				else
					v1704 = v1660
					v1550 = v1651
				end
			else
				v1704 = 11
				if v1664 and v1731 then
					v1550 = v1731.crosshair(0, nil)
					if not v1550 then
						v1550 = v1651
					end
				else
					v1550 = v1651
				end
			end
			if v1638 then
				v1754 = 26
			else
				v1754 = 24
			end
		elseif v1754 == 22 then
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		elseif v1754 == 23 then
			v1709 = v_u_17.Character
			if not (v1709 and v1709.Parent) then
				v1709 = nil
			end
			if v1709 then
				v1709 = v1709:GetAttribute("Laser")
			end
			if v1709 == true or (v1741.kind ~= "firearm" or v1664) then
				v_u_12.aimLine(nil, nil)
			else
				v1710 = v1593.Position
				v1620 = v1685 - v1710
				v1711 = v1620.Magnitude
				v1726 = math.min(v1711, 26)
				v1727 = v_u_12.aimLine
				v1728 = v1710 + (v1678 or v1620.Unit) * v1726
				if v1616 then
					v1712 = v1616.tint
				else
					v1712 = v1616
				end
				if v1616 then
					v1616 = v1616.stop
				end
				v1727(v1710, v1728, v1712, v1616)
			end
			v1754 = 14
		elseif v1754 == 24 then
			v_u_12.aimLine(nil, nil)
			v1646 = v_u_17.Character
			if not (v1646 and v1646.Parent) then
				v1646 = nil
			end
			if v1646 then
				v1646 = v1646:GetAttribute("ReloadEndsAt")
			end
			v1647 = tonumber(v1646) or 0
			v1648 = v_u_17.Character
			if not (v1648 and v1648.Parent) then
				v1648 = nil
			end
			if v1648 then
				v1648 = v1648:GetAttribute("Reloading")
			end
			v1623 = v1648 == true and not v_u_585.pending()
			if v1623 then
				v1623 = not v_u_594.pending()
			end
			v1645 = 0
			if v1623 or not v_u_584.on() then
				if v1623 and v1647 > 0 then
					v1746 = v_u_2.now()
					if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
						if v1647 ~= v_u_1747 then
							if v_u_1747 == 0 and v_u_584.t == 0 then
								v_u_594.riseT = os.clock()
							end
							v_u_1747 = v1647
							v_u_1748 = v1746
							if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
								v_u_1748 = v1746 - (os.clock() - v_u_584.t)
							end
							v_u_584.t = 0
						end
					else
						v_u_1747 = v1647
						v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
					end
					v1749 = v1746 - v_u_1748
					v1714 = v1647 - v_u_1748
					v1715 = v1749 / math.max(0.1, v1714)
					v1645 = math.clamp(v1715, 0, 1)
				else
					v_u_1747 = 0
				end
			else
				v1661 = os.clock() - v_u_584.t
				v1551 = v_u_584.dur
				v1653 = v1661 / math.max(0.1, v1551)
				v1645 = math.clamp(v1653, 0, 0.97)
				v1623 = true
			end
			v_u_1654 = v1645
			if v_u_1679 < v1742 then
				v_u_1552 = ""
			end
			if v1703 then
				v1655 = v_u_13.update
				v1720 = {
					["visible"] = nil,
					["aiming"] = true,
					["melee"] = true,
					["ammo"] = 0,
					["mag"] = 0,
					["reloading"] = false,
					["reloadFrac"] = 0,
					["jammed"] = false,
					["hint"] = "",
					["note"] = nil
				}
				if v1602 then
					v1662 = v1550 ~= nil
				else
					v1662 = v1602
				end
				v1720.visible = v1662
				if v1742 < v_u_1679 and v_u_1552 ~= "" then
					v1721 = v_u_1552
				else
					v1721 = v_u_1044()
				end
				v1720.note = v1721
				v1655(v1550, v1704, v1720)
			else
				v1690 = v_u_13.update
				v1691 = {}
				if v1602 then
					v1692 = v1550 ~= nil
				else
					v1692 = v1602
				end
				v1691.visible = v1692
				v1691.aiming = v1638
				if v1741 == nil then
					v1693 = false
				else
					v1693 = v1741.kind == "melee"
				end
				v1691.melee = v1693
				v1691.ammo = v_u_23
				v1691.mag = not v1741 and 0 or v1741.capacity
				v1691.reloading = v1623
				v1691.reloadFrac = v1645
				v1553 = v_u_17.Character
				if not (v1553 and v1553.Parent) then
					v1553 = nil
				end
				if v1553 then
					v1553 = v1553:GetAttribute("Jammed")
				end
				v1691.jammed = v1553 == true
				v1694 = v_u_9
				if v1694 then
					v1694 = v_u_9.controllers.Input
				end
				if v1694 and v1694.hint then
					v1597 = v1694.hint
					v1598, v1695 = pcall(v1597, "reload")
					v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
				else
					v1554 = ""
				end
				v1691.hint = v1554
				v1691.note = v_u_1552
				if v1664 then
					v1563 = nil
				else
					v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
				end
				v1691.sight = v1563
				v1691.adsHide = v1606
				v1691.blockedAt = v1587
				v1690(v1550, v1704, v1691)
			end
			if v1602 then
				if v1550 == nil then
					v1602 = false
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				else
					v1656 = v_u_9
					if v1656 then
						v1656 = v_u_9.controllers.Input
					end
					if v1656 and v1656.device then
						v1698 = v1656.device
						v1603, v1565 = pcall(v1698)
						if v1603 and type(v1565) == "string" then
							v1602 = v1565 == "Keyboard"
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
					else
						v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
						v1602 = v1565 == "Keyboard"
					end
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
			else
				if v1602 then
					v_u_1564 = true
					if v_u_4.MouseIconEnabled then
						v_u_4.MouseIconEnabled = false
					end
				elseif v_u_1564 then
					v_u_1564 = false
					v_u_4.MouseIconEnabled = true
				end
				if v1742 - v_u_1604 <= 0.033 then
					return
				end
			end
			v_u_1604 = v1742
			v1699 = {}
			v1700 = v_u_113() ~= nil
			if v1700 then
				v1701 = v_u_49.get()
			else
				v1701 = nil
			end
			for v1765, v1766 in v_u_3:GetPlayers() do
				v1702 = v1766.Character
				if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
					v1718 = v1766.UserId
					v1699[tostring(v1718)] = true
				else
					if not v1702 or v1702:GetAttribute("Laser") ~= true then
						continue
					end
					if v1702 then
						v1657 = v1702:FindFirstChild("HeldWeapon")
					else
						v1657 = v1702
					end
					if not (v1657 and v1657:IsA("Model")) then
						v1657 = nil
					end
					if v1657 then
						v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
						if v1566 then
							v1566 = v1566:FindFirstChild("LaserEmitter")
						end
						if not (v1566 and v1566:IsA("Attachment")) then
							v1566 = nil
						end
					else
						v1566 = nil
					end
					if not v1566 then
						continue
					end
					v1666 = v1766.UserId
					v1667 = tostring(v1666)
					v1668 = v1566.WorldPosition
					if v1766 == v_u_17 then
						v1630 = v_u_106()
					else
						v1630 = v1702:GetAttribute("Aiming") == true
					end
					v1631 = v_u_12.laserDir
					v1632 = v1566.WorldCFrame
					if v1766 == v_u_17 then
						v1633 = v_u_131()
					else
						v1633 = v1702:GetAttribute("AimYaw")
					end
					if v1766 == v_u_17 then
						v1634 = v_u_371(v1668.Y)
					else
						v1634 = nil
					end
					v1567 = not v1630
					if not v1567 then
						if v1701 == nil then
							v1567 = false
						else
							v1567 = v1701.followBarrel(v1700)
						end
					end
					v1635 = v1631(v1632, v1633, v1634, v1567)
					v1568 = v_u_8._laserParams(v1702)
					v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
					if v1569 then
						v1719 = v1569.Position
					else
						v1719 = v1668 + v1635 * 120
					end
					if v1701 ~= nil and v1701.followBarrel(v1700) then
						v1599 = v_u_49.clip
						if v1569 then
							v1600 = v1569.Distance
						else
							v1600 = v1701.MAX_LEN
						end
						v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
					end
					if v1766 == v_u_17 then
						v_u_12.laser(v1667, v1668, v1719)
						v1699[v1667] = true
					else
						v1570 = v_u_9
						if v1570 then
							v1570 = v_u_9.controllers.Vision
						end
						if v1570 and v1570.isVisible then
							v1649 = v1570.isVisible
							v1650, v1601 = pcall(v1649, v1668)
							v1696 = not v1650 and true or v1601 ~= false
						else
							v1696 = true
						end
						if v1696 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v_u_12.laser(v1667, nil, nil)
							v1699[v1667] = true
						end
					end
				end
			end
			v_u_12.clearLasers(v1699)
			return
		elseif v1754 == 25 then
			v1592 = false
			if v1741 == nil and not v1703 then
				v1602 = v1703
			elseif v1602 then
				if v1605 == nil then
					v1602 = false
				else
					v1602 = not v1592
				end
			end
			v1550 = nil
			v1704 = 10
			if v1703 then
				v1731 = nil
			else
				v1731 = v_u_113()
			end
			if v1731 == nil then
				v1664 = false
			else
				v1664 = not v_u_42
			end
			v1587 = nil
			v1606 = false
			if v1703 and v1605 then
				v_u_12.aimLine(nil, nil)
				v1704 = 11
				v1673 = v_u_9
				if v1673 then
					v1673 = v_u_9.controllers.Input
				end
				if v1673 and v1673.device then
					v1674 = v1673.device
					v1665, v1732 = pcall(v1674)
					if v1665 and type(v1732) == "string" then
						if v1732 == "Keyboard" and not v_u_42 then
							v1550 = v_u_4:GetMouseLocation()
						elseif v1642 then
							v1682, v1683 = v1605:WorldToViewportPoint(v1642)
							if v1683 then
								v1550 = Vector2.new(v1682.X, v1682.Y)
							end
						end
					else
						v1732 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
						if v1732 == "Keyboard" and not v_u_42 then
							v1550 = v_u_4:GetMouseLocation()
						elseif v1642 then
							v1682, v1683 = v1605:WorldToViewportPoint(v1642)
							if v1683 then
								v1550 = Vector2.new(v1682.X, v1682.Y)
							end
						end
					end
				else
					v1732 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
					if v1732 == "Keyboard" and not v_u_42 then
						v1550 = v_u_4:GetMouseLocation()
					elseif v1642 then
						v1682, v1683 = v1605:WorldToViewportPoint(v1642)
						if v1683 then
							v1550 = Vector2.new(v1682.X, v1682.Y)
						end
					end
				end
				v1646 = v_u_17.Character
				if not (v1646 and v1646.Parent) then
					v1646 = nil
				end
				if v1646 then
					v1646 = v1646:GetAttribute("ReloadEndsAt")
				end
				v1647 = tonumber(v1646) or 0
				v1648 = v_u_17.Character
				if not (v1648 and v1648.Parent) then
					v1648 = nil
				end
				if v1648 then
					v1648 = v1648:GetAttribute("Reloading")
				end
				v1623 = v1648 == true and not v_u_585.pending()
				if v1623 then
					v1623 = not v_u_594.pending()
				end
				v1645 = 0
				if v1623 or not v_u_584.on() then
					if v1623 and v1647 > 0 then
						v1746 = v_u_2.now()
						if v1647 == v_u_1747 or (v_u_1747 <= 0 or (v_u_1654 <= 0 or (v_u_1654 >= 0.995 or v1746 >= v1647))) then
							if v1647 ~= v_u_1747 then
								if v_u_1747 == 0 and v_u_584.t == 0 then
									v_u_594.riseT = os.clock()
								end
								v_u_1747 = v1647
								v_u_1748 = v1746
								if v_u_584.t > 0 and os.clock() - v_u_584.t < v_u_584.win + 0.5 then
									v_u_1748 = v1746 - (os.clock() - v_u_584.t)
								end
								v_u_584.t = 0
							end
						else
							v_u_1747 = v1647
							v_u_1748 = (v1746 - v_u_1654 * v1647) / (1 - v_u_1654)
						end
						v1749 = v1746 - v_u_1748
						v1714 = v1647 - v_u_1748
						v1715 = v1749 / math.max(0.1, v1714)
						v1645 = math.clamp(v1715, 0, 1)
					else
						v_u_1747 = 0
					end
				else
					v1661 = os.clock() - v_u_584.t
					v1551 = v_u_584.dur
					v1653 = v1661 / math.max(0.1, v1551)
					v1645 = math.clamp(v1653, 0, 0.97)
					v1623 = true
				end
				v_u_1654 = v1645
				if v_u_1679 < v1742 then
					v_u_1552 = ""
				end
				if v1703 then
					v1655 = v_u_13.update
					v1720 = {
						["visible"] = nil,
						["aiming"] = true,
						["melee"] = true,
						["ammo"] = 0,
						["mag"] = 0,
						["reloading"] = false,
						["reloadFrac"] = 0,
						["jammed"] = false,
						["hint"] = "",
						["note"] = nil
					}
					if v1602 then
						v1662 = v1550 ~= nil
					else
						v1662 = v1602
					end
					v1720.visible = v1662
					if v1742 < v_u_1679 and v_u_1552 ~= "" then
						v1721 = v_u_1552
					else
						v1721 = v_u_1044()
					end
					v1720.note = v1721
					v1655(v1550, v1704, v1720)
				else
					v1690 = v_u_13.update
					v1691 = {}
					if v1602 then
						v1692 = v1550 ~= nil
					else
						v1692 = v1602
					end
					v1691.visible = v1692
					v1691.aiming = v1638
					if v1741 == nil then
						v1693 = false
					else
						v1693 = v1741.kind == "melee"
					end
					v1691.melee = v1693
					v1691.ammo = v_u_23
					v1691.mag = not v1741 and 0 or v1741.capacity
					v1691.reloading = v1623
					v1691.reloadFrac = v1645
					v1553 = v_u_17.Character
					if not (v1553 and v1553.Parent) then
						v1553 = nil
					end
					if v1553 then
						v1553 = v1553:GetAttribute("Jammed")
					end
					v1691.jammed = v1553 == true
					v1694 = v_u_9
					if v1694 then
						v1694 = v_u_9.controllers.Input
					end
					if v1694 and v1694.hint then
						v1597 = v1694.hint
						v1598, v1695 = pcall(v1597, "reload")
						v1554 = (not v1598 or (type(v1695) ~= "string" or v1695 == "")) and "" or "[" .. v1695 .. "]"
					else
						v1554 = ""
					end
					v1691.hint = v1554
					v1691.note = v_u_1552
					if v1664 then
						v1563 = nil
					else
						v1563 = (string.find(v_u_1319, "att_scope_4x", 1, true) or string.find(v_u_1319, "att_scope_8x", 1, true)) and "scope" or ((string.find(v_u_1319, "att_reddot", 1, true) or string.find(v_u_1319, "att_holo", 1, true)) and "reddot" or nil)
					end
					v1691.sight = v1563
					v1691.adsHide = v1606
					v1691.blockedAt = v1587
					v1690(v1550, v1704, v1691)
				end
				if v1602 then
					if v1550 == nil then
						v1602 = false
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					else
						v1656 = v_u_9
						if v1656 then
							v1656 = v_u_9.controllers.Input
						end
						if v1656 and v1656.device then
							v1698 = v1656.device
							v1603, v1565 = pcall(v1698)
							if v1603 and type(v1565) == "string" then
								v1602 = v1565 == "Keyboard"
							else
								v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
								v1602 = v1565 == "Keyboard"
							end
						else
							v1565 = v_u_4.TouchEnabled and not v_u_4.KeyboardEnabled and "Touch" or "Keyboard"
							v1602 = v1565 == "Keyboard"
						end
						if v1602 then
							v_u_1564 = true
							if v_u_4.MouseIconEnabled then
								v_u_4.MouseIconEnabled = false
							end
						elseif v_u_1564 then
							v_u_1564 = false
							v_u_4.MouseIconEnabled = true
						end
						if v1742 - v_u_1604 <= 0.033 then
							return
						end
					end
				else
					if v1602 then
						v_u_1564 = true
						if v_u_4.MouseIconEnabled then
							v_u_4.MouseIconEnabled = false
						end
					elseif v_u_1564 then
						v_u_1564 = false
						v_u_4.MouseIconEnabled = true
					end
					if v1742 - v_u_1604 <= 0.033 then
						return
					end
				end
				v_u_1604 = v1742
				v1699 = {}
				v1700 = v_u_113() ~= nil
				if v1700 then
					v1701 = v_u_49.get()
				else
					v1701 = nil
				end
				for v1765, v1766 in v_u_3:GetPlayers() do
					v1702 = v1766.Character
					if v1766 == v_u_17 and (v1701 ~= nil and v1701.loopSkipsOwn(v1700, v1742, v_u_49.at)) then
						v1718 = v1766.UserId
						v1699[tostring(v1718)] = true
					else
						if not v1702 or v1702:GetAttribute("Laser") ~= true then
							continue
						end
						if v1702 then
							v1657 = v1702:FindFirstChild("HeldWeapon")
						else
							v1657 = v1702
						end
						if not (v1657 and v1657:IsA("Model")) then
							v1657 = nil
						end
						if v1657 then
							v1566 = v1657.PrimaryPart or v1657:FindFirstChild("Handle", true)
							if v1566 then
								v1566 = v1566:FindFirstChild("LaserEmitter")
							end
							if not (v1566 and v1566:IsA("Attachment")) then
								v1566 = nil
							end
						else
							v1566 = nil
						end
						if not v1566 then
							continue
						end
						v1666 = v1766.UserId
						v1667 = tostring(v1666)
						v1668 = v1566.WorldPosition
						if v1766 == v_u_17 then
							v1630 = v_u_106()
						else
							v1630 = v1702:GetAttribute("Aiming") == true
						end
						v1631 = v_u_12.laserDir
						v1632 = v1566.WorldCFrame
						if v1766 == v_u_17 then
							v1633 = v_u_131()
						else
							v1633 = v1702:GetAttribute("AimYaw")
						end
						if v1766 == v_u_17 then
							v1634 = v_u_371(v1668.Y)
						else
							v1634 = nil
						end
						v1567 = not v1630
						if not v1567 then
							if v1701 == nil then
								v1567 = false
							else
								v1567 = v1701.followBarrel(v1700)
							end
						end
						v1635 = v1631(v1632, v1633, v1634, v1567)
						v1568 = v_u_8._laserParams(v1702)
						v1569 = v_u_6:Raycast(v1668, v1635 * 120, v1568)
						if v1569 then
							v1719 = v1569.Position
						else
							v1719 = v1668 + v1635 * 120
						end
						if v1701 ~= nil and v1701.followBarrel(v1700) then
							v1599 = v_u_49.clip
							if v1569 then
								v1600 = v1569.Distance
							else
								v1600 = v1701.MAX_LEN
							end
							v1719 = v1668 + v1635 * v1599(v1701, v1668, v1635, v1600)
						end
						if v1766 == v_u_17 then
							v_u_12.laser(v1667, v1668, v1719)
							v1699[v1667] = true
						else
							v1570 = v_u_9
							if v1570 then
								v1570 = v_u_9.controllers.Vision
							end
							if v1570 and v1570.isVisible then
								v1649 = v1570.isVisible
								v1650, v1601 = pcall(v1649, v1668)
								v1696 = not v1650 and true or v1601 ~= false
							else
								v1696 = true
							end
							if v1696 then
								v_u_12.laser(v1667, v1668, v1719)
								v1699[v1667] = true
							else
								v_u_12.laser(v1667, nil, nil)
								v1699[v1667] = true
							end
						end
					end
				end
				v_u_12.clearLasers(v1699)
				return
			end
			if v1602 and (v1605 and v1741) then
				v1754 = 17
			else
				v1754 = 16
			end
		elseif v1754 == 26 then
			v1709 = v_u_17.Character
			if not (v1709 and v1709.Parent) then
				v1709 = nil
			end
			if v1709 then
				v1709 = v1709:GetAttribute("Laser")
			end
			if v1709 == true or (v1741.kind ~= "firearm" or v1664) then
				v_u_12.aimLine(nil, nil)
			else
				v1710 = v1593.Position
				v1620 = v1685 - v1710
				v1711 = v1620.Magnitude
				v1726 = math.min(v1711, 26)
				v1727 = v_u_12.aimLine
				v1728 = v1710 + (v1678 or v1620.Unit) * v1726
				if v1616 then
					v1712 = v1616.tint
				else
					v1712 = v1616
				end
				if v1616 then
					v1616 = v1616.stop
				end
				v1727(v1710, v1728, v1712, v1616)
			end
			v1754 = 14
		elseif v1754 == 27 then
			v1642 = nil
			if v_u_1716 or v_u_35 and v1742 - v_u_35 > 0.15 then
				v1610, v1611 = v_u_924()
				if v1610 and v1611 then
					v1612, v1642, v1586 = v_u_1003(v1610, v1611)
					v_u_12.arcPreview(v1612, v1642, v1586)
				end
			end
			v1605 = v_u_6.CurrentCamera
			v1703 = v_u_1716
			if v1703 then
				v1703 = v1605 ~= nil
			end
			if v_u_15 == nil then
				v1754 = 25
			else
				v1754 = 15
			end
		else
			if not v_u_18 then
				return
			end
			v1555 = v_u_17.Character
			if not (v1555 and v1555.Parent) then
				v1555 = nil
			end
			v1556 = v_u_17.Character
			if not (v1556 and v1556.Parent) then
				v1556 = nil
			end
			if v1556 then
				v1556 = v1556:FindFirstChild("HumanoidRootPart")
			end
			v_u_433(p_u_1360)
			v1713 = function()
				-- upvalues: (ref) v_u_9, (copy) p_u_1360
				v_u_9.lib.RotarySpin.step(p_u_1360)
			end
			pcall(v1713)
			v_u_12.step(p_u_1360)
			v_u_13.stepMarkers(p_u_1360)
			if not (v1555 and v1556) then
				v_u_13.update(nil, 0, {
					["visible"] = false
				})
				if v_u_1564 then
					v_u_1564 = false
					v_u_4.MouseIconEnabled = true
				end
				return
			end
			v_u_1347()
			v_u_8.rideFrame(v1555)
			v_u_1359()
			v1729 = v1555:GetAttribute("MeleeRefusedAt")
			if v_u_585.refusedChar == v1555 then
				if v1729 ~= v_u_585.refusedSeen then
					v_u_585.refusedSeen = v1729
					if type(v1729) == "number" then
						v_u_1552 = "EXHAUSTED"
						v_u_1679 = os.clock() + 0.9
						v1738 = v_u_585
						v1738.refusedCues = v1738.refusedCues + 1
						v1739 = v_u_9
						if v1739 then
							v1739 = v_u_9.controllers.Audio
						end
						if v1739 and v1739.ui then
							v1557 = v1739.ui
							pcall(v1557, "error")
						end
						v1740 = v_u_9
						if v1740 then
							v1740 = v_u_9.controllers.CharacterAnim
						end
						if v1740 and v1740.flinch then
							v1558 = v1740.flinch
							pcall(v1558, v1555, 0.25)
						end
					end
				end
			else
				v_u_585.refusedChar = v1555
				v_u_585.refusedSeen = v1729
			end
			v1741 = v_u_22
			v1742 = os.clock()
			if v_u_57 and v1742 - v_u_1559 > 0.5 then
				v_u_1559 = v1742
				v1743 = v_u_17.Character
				if not (v1743 and v1743.Parent) then
					v1743 = nil
				end
				if v1743 then
					v1743 = v1743:GetAttribute("ThrowableList")
				end
				if type(v1743) == "string" then
					v1571 = v1743 ~= ""
				else
					v1571 = false
				end
				if v_u_57.Visible ~= v1571 then
					v_u_57.Visible = v1571
				end
			end
			if v1742 - v_u_1572 > 0.3 then
				v_u_1572 = v1742
				v_u_138()
			end
			if v1741 and v1741.kind == "firearm" then
				v1560 = v_u_1573 - v1741.bloomRecover * p_u_1360 * (v1742 - v_u_25 > 0.15 and 1 or 0.3)
				v_u_1573 = math.max(0, v1560)
			end
			v1602 = v_u_99()
			if v_u_585.pending() and v_u_585.stats then
				v1744 = v_u_585.stats
			else
				v1744 = v_u_22
			end
			if v_u_27 and (v1602 and v1744) then
				if v1744.kind == "firearm" then
					v1745 = v_u_17.Character
					if not (v1745 and v1745.Parent) then
						v1745 = nil
					end
					if v1745 then
						v1745 = v1745:GetAttribute("FireMode")
					end
					if type(v1745) ~= "string" or not table.find(v1744.fireModes, v1745) then
						v1745 = v1744.fireModes[1]
					end
					v1578 = v_u_9
					if v1578 then
						v1578 = v_u_9.controllers.Input
					end
					if v1578 == nil then
						v1574 = false
					else
						v1561 = v1578.fireRepeat
						if type(v1561) == "function" then
							v1574 = v1578.fireRepeat() == true
						else
							v1574 = false
						end
					end
					if v1745 == "auto" then
						v1579 = not v1574
						if not v1579 then
							v1637 = v1578.aimSentAge
							v1579 = type(v1637) ~= "function" and true or v1578.aimSentAge() >= 0.07
						end
						if v1579 and (v_u_769() and v1574) then
							v_u_1575 = false
						end
					elseif v_u_1581 then
						if v1574 and (v_u_1562 <= v1742 and v_u_769()) then
							v_u_1562 = v1742 + v_u_10.semiInterval(v1744)
							v_u_1575 = false
						end
					else
						v1576 = not v1574
						if not v1576 then
							v1580 = v1578.aimSentAge
							v1576 = type(v1580) ~= "function" and true or v1578.aimSentAge() >= 0.07
						end
						if v1576 and v_u_769() then
							v_u_1581 = true
							v_u_1562 = v1742 + v_u_10.semiInterval(v1744)
						end
					end
				elseif v1744.kind == "melee" then
					v_u_856()
				end
			end
			if v_u_33 and (not v_u_1594 and v1742 - v_u_33 > 0.45) then
				v_u_1594 = true
				v_u_1102()
			end
			v1638 = v_u_106()
			v1639 = v_u_9
			if v1639 then
				v1639 = v_u_9.controllers.Camera
			end
			if v1638 and (v1741 and v1741.kind == "firearm") then
				v1582 = v_u_17.Character
				if not (v1582 and v1582.Parent) then
					v1582 = nil
				end
				if v1582 then
					v1582 = v1582:GetAttribute("AimShift")
				end
				v1640 = tonumber(v1582) or v1741.aimShift
			else
				v1640 = nil
			end
			if v1640 ~= v_u_1641 and (v1639 and v1639.setAimShift) then
				v_u_1641 = v1640
				v1595 = v1639.setAimShift
				pcall(v1595, v1640)
			end
			v1583 = v1555:GetAttribute("ThrowReadyAt")
			if v1555 == v_u_1577 then
				if v1583 ~= v_u_1584 then
					v_u_1584 = v1583
					if type(v1583) == "number" and v_u_2.now() - v1583 < 3 then
						if v_u_1716 and v1742 - v_u_60 > 0.3 then
							if v_u_1716 then
								v_u_1716 = false
								v1596 = v_u_9.lib.GrenadeFx.hold
								pcall(v1596, false)
								v_u_12.arcPreview(nil)
								v1585 = v_u_13.throwHint
								pcall(v1585, nil)
								if v_u_62 then
									v_u_62.Visible = false
								end
							end
						elseif not v_u_1716 then
							v_u_1063()
						end
					end
				end
			else
				v_u_1577 = v1555
				v_u_1584 = v1583
			end
			if v_u_1716 then
				v1754 = 5
			else
				v1754 = 6
			end
		end
	end
end
function v_u_49.clip(p1767, p1768, p1769, p1770) -- name: clip
	-- upvalues: (copy) v_u_203, (ref) v_u_9
	local v1771, v1772 = v_u_203(p1768, p1769, p1770, p1768)
	if v1771 ~= nil and v1772 ~= nil then
		local v1773 = v_u_9
		if v1773 then
			v1773 = v_u_9.controllers.Vision
		end
		local v1774
		if v1773 and v1773.isVisible then
			local v1775 = v1773.isVisible
			local v1776, v1777 = pcall(v1775, v1772)
			v1774 = not v1776 and true or v1777 ~= false
		else
			v1774 = true
		end
		if v1774 then
			return p1767.rigEnd(p1770, v1771)
		end
	end
	return p1770
end
function v_u_8.fpLaser(p1778, _) -- name: fpLaser
	-- upvalues: (copy) v_u_17, (ref) v_u_18, (ref) v_u_12, (copy) v_u_113, (copy) v_u_49, (ref) v_u_9, (copy) v_u_6, (copy) v_u_8, (copy) v_u_131, (copy) v_u_106
	local v1779 = v_u_17.Character
	if not (v1779 and v1779.Parent) then
		v1779 = nil
	end
	if v_u_18 and (v_u_12 ~= nil and (v1779 ~= nil and v_u_113() ~= nil)) then
		local v1780 = v_u_17.UserId
		local v1781 = tostring(v1780)
		if v1779:GetAttribute("Dead") == true or v1779:GetAttribute("Laser") ~= true then
			v_u_49.at = 0
			v_u_12.laser(v1781, nil, nil)
			return
		else
			local v1782 = v_u_49.get()
			if v1782 == nil then
				v_u_49.at = 0
			else
				local function v1784()
					-- upvalues: (ref) v_u_9
					local v1783 = v_u_9.lib.Viewmodel
					return v1783.laserState(), v1783.isVisible()
				end
				local v1785, v1786, v1787 = pcall(v1784)
				if not v1785 or type(v1786) ~= "table" then
					v1786 = nil
				end
				local v1788 = v1782.source
				local v1789 = true
				local v1790 = true
				local v1791 = v1786 ~= nil
				if v1785 then
					v1785 = v1787 == true
				end
				local v1792 = v1788(v1789, v1790, v1791, v1785)
				local v1793 = os.clock()
				local v1794 = v1782.aimDist(v_u_49.dist, v1793 - v_u_49.distAt)
				if v1792 == "viewmodel" and v1786 ~= nil then
					local v1795 = v1786.pos
					local v1796 = v1782.followBarrel(true)
					local v1797 = 0
					local v1798
					if v1796 then
						v1798 = v1782.barrelDir(v1786.look)
					else
						local v1799, v1800 = v1782.fromCFrame(p1778)
						local v1801 = v1782.fromCFrame(v1786.gunCam)
						v1798, v1794, v1797 = v1782.viewDir(v1799, v1800, v1801, v1786.hold, v1786.adsRoll, v1786.ads, {
							["x"] = v1795.X,
							["y"] = v1795.Y,
							["z"] = v1795.Z
						}, v1794)
					end
					local v1802 = v1782.mode(v1786.shown == true, v1786.gunShown == true, v1786.overlayHide == true)
					if v1798 == nil then
						v_u_12.laser(v1781, nil, nil)
					else
						local v1803 = v1798.x
						local v1804 = v1798.y
						local v1805 = v1798.z
						local v1806 = Vector3.new(v1803, v1804, v1805)
						local v1807 = v_u_6:Raycast(v1795, v1806 * v1782.MAX_LEN, v_u_8._laserParams(v1779))
						local v1808 = v1782.endDist
						local v1809
						if v1807 then
							v1809 = v1807.Distance
						else
							v1809 = nil
						end
						local v1810 = not v1796
						if v1810 then
							v1810 = v_u_49.zombie == true
						end
						local v1811 = v1808(v1809, v1794, v1810, v1797)
						if v1796 then
							v1811 = v_u_49.clip(v1782, v1795, v1806, v1811)
						end
						local v1812 = v1795 + v1806 * v1811
						if v1802 == "beam" then
							v_u_12.laser(v1781, v1795, v1812, v_u_49.beamOpts)
						elseif v1802 == "dot" then
							v_u_12.laser(v1781, v1795, v1812, v_u_49.dotOpts)
						else
							v_u_12.laser(v1781, nil, nil)
						end
					end
				elseif v1792 == "world" then
					local v1813
					if v1779 then
						v1813 = v1779:FindFirstChild("HeldWeapon")
					else
						v1813 = v1779
					end
					if not (v1813 and v1813:IsA("Model")) then
						v1813 = nil
					end
					local v1814
					if v1813 then
						v1814 = v1813.PrimaryPart or v1813:FindFirstChild("Handle", true)
						if v1814 then
							v1814 = v1814:FindFirstChild("LaserEmitter")
						end
						if not (v1814 and v1814:IsA("Attachment")) then
							v1814 = nil
						end
					else
						v1814 = nil
					end
					if v1814 then
						local v1815 = v1814.WorldPosition
						local v1816 = p1778.Position + p1778.LookVector * v1794
						local v1817 = v_u_12.laserDir(v1814.WorldCFrame, v_u_131(), v1816, not v_u_106() or v1782.followBarrel(true))
						local v1818 = v_u_6:Raycast(v1815, v1817 * 120, v_u_8._laserParams(v1779))
						local v1819
						if v1818 then
							v1819 = v1818.Position
						else
							v1819 = v1815 + v1817 * 120
						end
						if v1782.followBarrel(true) then
							local v1820 = v_u_49.clip
							local v1821
							if v1818 then
								v1821 = v1818.Distance
							else
								v1821 = v1782.MAX_LEN
							end
							v1819 = v1815 + v1817 * v1820(v1782, v1815, v1817, v1821)
						end
						v_u_12.laser(v1781, v1815, v1819)
					else
						v_u_12.laser(v1781, nil, nil)
					end
				else
					v_u_12.laser(v1781, nil, nil)
				end
				v_u_49.at = v1793
			end
		end
	else
		v_u_49.at = 0
		return
	end
end
function v_u_8.faceTarget() -- name: faceTarget
	-- upvalues: (ref) v_u_1723, (ref) v_u_1724
	if v_u_1723 == nil or os.clock() - v_u_1724 >= 0.12 then
		return nil
	else
		return v_u_1723
	end
end
function v_u_8.state() -- name: state
	-- upvalues: (ref) v_u_21, (ref) v_u_23, (copy) v_u_8, (ref) v_u_22, (copy) v_u_17, (copy) v_u_584, (copy) v_u_585, (copy) v_u_594, (ref) v_u_1716, (ref) v_u_18
	local v1822 = {
		["weapon"] = v_u_21,
		["ammo"] = v_u_23,
		["twin"] = v_u_8._tw.on
	}
	local v1823
	if v_u_8._tw.on then
		v1823 = v_u_8._tw.m2
	else
		v1823 = nil
	end
	v1822.ammo2 = v1823
	v1822.mag = not v_u_22 and 0 or v_u_22.capacity
	local v1824 = v_u_17.Character
	if not (v1824 and v1824.Parent) then
		v1824 = nil
	end
	if v1824 then
		v1824 = v1824:GetAttribute("AmmoReserve")
	end
	v1822.reserve = v1824
	local v1825 = v_u_17.Character
	if not (v1825 and v1825.Parent) then
		v1825 = nil
	end
	if v1825 then
		v1825 = v1825:GetAttribute("FireMode")
	end
	v1822.mode = v1825
	local v1826 = v_u_17.Character
	if not (v1826 and v1826.Parent) then
		v1826 = nil
	end
	if v1826 then
		v1826 = v1826:GetAttribute("Reloading")
	end
	local v1827 = (v1826 == true or v_u_584.on()) and not v_u_585.pending()
	if v1827 then
		v1827 = not v_u_594.pending()
	end
	v1822.reloading = v1827
	local v1828 = v_u_17.Character
	if not (v1828 and v1828.Parent) then
		v1828 = nil
	end
	if v1828 then
		v1828 = v1828:GetAttribute("Jammed")
	end
	v1822.jammed = v1828 == true
	local v1829 = v_u_17.Character
	if not (v1829 and v1829.Parent) then
		v1829 = nil
	end
	if v1829 then
		v1829 = v1829:GetAttribute("Throwable")
	end
	v1822.throwable = v1829
	v1822.throwMode = v_u_1716
	v1822.active = v_u_18
	return v1822
end
function v_u_8.hudState() -- name: hudState
	-- upvalues: (ref) v_u_18, (ref) v_u_21, (ref) v_u_22, (copy) v_u_17, (copy) v_u_584, (copy) v_u_585, (copy) v_u_594, (ref) v_u_23, (ref) v_u_1654, (copy) v_u_8, (ref) v_u_9, (copy) v_u_79
	if not (v_u_18 and (v_u_21 and v_u_22)) then
		return nil
	end
	local v1830 = v_u_17.Character
	if not (v1830 and v1830.Parent) then
		v1830 = nil
	end
	if v1830 then
		v1830 = v1830:GetAttribute("Weapon")
	end
	if v1830 ~= v_u_21 then
		return nil
	end
	local v1831 = v_u_22.kind == "firearm"
	local v1832 = v_u_17.Character
	if not (v1832 and v1832.Parent) then
		v1832 = nil
	end
	if v1832 then
		v1832 = v1832:GetAttribute("Reloading")
	end
	local v1833 = (v1832 == true or v_u_584.on()) and not v_u_585.pending()
	if v1833 then
		v1833 = not v_u_594.pending()
	end
	local v1834 = {
		["magSize"] = not v1831 and 0 or v_u_22.capacity,
		["ammo"] = not v1831 and 0 or v_u_23
	}
	local v1835
	if v1831 then
		local v1836 = v_u_17.Character
		if not (v1836 and v1836.Parent) then
			v1836 = nil
		end
		if v1836 then
			v1836 = v1836:GetAttribute("AmmoReserve")
		end
		v1835 = tonumber(v1836) or 0
	else
		v1835 = 0
	end
	v1834.reserve = v1835
	local v1837, v1838, v1839, v1840, v1841, v1842
	if not v1831 then
		v1846 = v_u_17.Character
		if not (v1846 and v1846.Parent) then
			v1846 = nil
		end
		if v1846 then
			v1846 = v1846:GetAttribute("FireMode")
		end
		v1834.mode = v1846
		v1834.reloading = v1833
		v1834.reloadProgress = not v1833 and 0 or v_u_1654
		if v1833 then
			v1837 = v_u_17.Character
			if not (v1837 and v1837.Parent) then
				v1837 = nil
			end
			if v1837 then
				v1837 = v1837:GetAttribute("ReloadSlow")
			end
			v1838 = v1837 ~= true and v_u_584.on()
			if v1838 then
				v1839 = v_u_17.Character
				if not (v1839 and v1839.Parent) then
					v1839 = nil
				end
				if v1839 then
					v1839 = v1839:GetAttribute("Sprinting")
				end
				v1838 = v1839 == true
			end
		else
			v1838 = v1833
		end
		v1834.reloadSlow = v1838
		if v1833 then
			v1833 = os.clock() - v_u_594.riseT >= v_u_594.minAge
		end
		v1834.reloadCancel = v1833
		v1847 = v_u_17.Character
		if not (v1847 and v1847.Parent) then
			v1847 = nil
		end
		if v1847 then
			v1847 = v1847:GetAttribute("Jammed")
		end
		v1834.jammed = v1847 == true
		v1834.weaponId = v_u_21
		if v1831 then
			v1840 = v_u_8._tw.on
		else
			v1840 = v1831
		end
		v1834.twin = v1840
		if v1831 and v_u_8._tw.on then
			v1841 = v_u_8._tw.m2
		else
			v1841 = nil
		end
		v1834.ammo2 = v1841
		if v1831 and v_u_8._tw.on then
			v1842 = v_u_9.lib.TwinFire.cap2(v_u_79, v_u_22)
		else
			v1842 = nil
		end
		v1834.magSize2 = v1842
		return v1834
	end
	local v1843 = table.find
	local v1844 = v_u_22.fireModes
	local v1845 = v_u_17.Character
	if not (v1845 and v1845.Parent) then
		v1845 = nil
	end
	if v1845 then
		v1845 = v1845:GetAttribute("FireMode")
	end
	if not v1843(v1844, v1845 or "") then
		v1846 = v_u_22.fireModes[1]
		v1834.mode = v1846
		v1834.reloading = v1833
		v1834.reloadProgress = not v1833 and 0 or v_u_1654
		if v1833 then
			v1837 = v_u_17.Character
			if not (v1837 and v1837.Parent) then
				v1837 = nil
			end
			if v1837 then
				v1837 = v1837:GetAttribute("ReloadSlow")
			end
			v1838 = v1837 ~= true and v_u_584.on()
			if v1838 then
				v1839 = v_u_17.Character
				if not (v1839 and v1839.Parent) then
					v1839 = nil
				end
				if v1839 then
					v1839 = v1839:GetAttribute("Sprinting")
				end
				v1838 = v1839 == true
			end
		else
			v1838 = v1833
		end
		v1834.reloadSlow = v1838
		if v1833 then
			v1833 = os.clock() - v_u_594.riseT >= v_u_594.minAge
		end
		v1834.reloadCancel = v1833
		v1847 = v_u_17.Character
		if not (v1847 and v1847.Parent) then
			v1847 = nil
		end
		if v1847 then
			v1847 = v1847:GetAttribute("Jammed")
		end
		v1834.jammed = v1847 == true
		v1834.weaponId = v_u_21
		if v1831 then
			v1840 = v_u_8._tw.on
		else
			v1840 = v1831
		end
		v1834.twin = v1840
		if v1831 and v_u_8._tw.on then
			v1841 = v_u_8._tw.m2
		else
			v1841 = nil
		end
		v1834.ammo2 = v1841
		if v1831 and v_u_8._tw.on then
			v1842 = v_u_9.lib.TwinFire.cap2(v_u_79, v_u_22)
		else
			v1842 = nil
		end
		v1834.magSize2 = v1842
		return v1834
	end
	local v1846 = v_u_17.Character
	if not (v1846 and v1846.Parent) then
		v1846 = nil
	end
	if v1846 then
		v1846 = v1846:GetAttribute("FireMode")
	end
	v1834.mode = v1846
	v1834.reloading = v1833
	v1834.reloadProgress = not v1833 and 0 or v_u_1654
	if v1833 then
		v1837 = v_u_17.Character
		if not (v1837 and v1837.Parent) then
			v1837 = nil
		end
		if v1837 then
			v1837 = v1837:GetAttribute("ReloadSlow")
		end
		v1838 = v1837 ~= true and v_u_584.on()
		if v1838 then
			v1839 = v_u_17.Character
			if not (v1839 and v1839.Parent) then
				v1839 = nil
			end
			if v1839 then
				v1839 = v1839:GetAttribute("Sprinting")
			end
			v1838 = v1839 == true
		end
	else
		v1838 = v1833
	end
	v1834.reloadSlow = v1838
	if v1833 then
		v1833 = os.clock() - v_u_594.riseT >= v_u_594.minAge
	end
	v1834.reloadCancel = v1833
	local v1847 = v_u_17.Character
	if not (v1847 and v1847.Parent) then
		v1847 = nil
	end
	if v1847 then
		v1847 = v1847:GetAttribute("Jammed")
	end
	v1834.jammed = v1847 == true
	v1834.weaponId = v_u_21
	if v1831 then
		v1840 = v_u_8._tw.on
	else
		v1840 = v1831
	end
	v1834.twin = v1840
	if v1831 and v_u_8._tw.on then
		v1841 = v_u_8._tw.m2
	else
		v1841 = nil
	end
	v1834.ammo2 = v1841
	if v1831 and v_u_8._tw.on then
		v1842 = v_u_9.lib.TwinFire.cap2(v_u_79, v_u_22)
	else
		v1842 = nil
	end
	v1834.magSize2 = v1842
	return v1834
end
function v_u_8.isThrowMode() -- name: isThrowMode
	-- upvalues: (ref) v_u_1716
	return v_u_1716 == true
end
function v_u_8.cycleFireMode() -- name: cycleFireMode
	-- upvalues: (copy) v_u_1102
	return v_u_1102()
end
function v_u_8.fireOnce() -- name: fireOnce
	-- upvalues: (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_24, (copy) v_u_769
	v_u_1581 = false
	v_u_1575 = false
	v_u_24 = 0
	return v_u_769()
end
function v_u_8.init(p_u_1848) -- name: init
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (copy) v_u_8, (ref) v_u_42, (copy) v_u_17, (ref) v_u_31, (ref) v_u_1581, (ref) v_u_1575, (copy) v_u_769, (ref) v_u_22, (copy) v_u_131, (ref) v_u_24, (copy) v_u_138, (copy) v_u_371, (ref) v_u_39, (ref) v_u_32, (copy) v_u_856, (copy) v_u_658, (copy) v_u_584, (ref) v_u_33, (ref) v_u_1594, (ref) v_u_18, (copy) v_u_672, (copy) v_u_594, (copy) v_u_639, (copy) v_u_585, (ref) v_u_21, (ref) v_u_23, (copy) v_u_1087, (ref) v_u_27, (copy) v_u_168, (copy) v_u_43, (copy) v_u_203, (copy) v_u_924, (copy) v_u_925, (copy) v_u_981, (copy) v_u_1010, (copy) v_u_49, (copy) v_u_113, (copy) v_u_1063, (ref) v_u_1716, (ref) v_u_62, (copy) v_u_1039
	v_u_9 = p_u_1848
	v_u_10 = p_u_1848.shared.Weapons
	local v1849, v1850 = pcall(function()
		-- upvalues: (copy) p_u_1848
		return p_u_1848.shared.Sounds
	end)
	if not v1849 then
		v1850 = nil
	end
	v_u_11 = v1850
	v_u_12 = p_u_1848.lib.WeaponFx
	v_u_13 = p_u_1848.lib.WeaponFxReticle
	local function v1851()
		-- upvalues: (ref) v_u_14, (copy) p_u_1848
		v_u_14 = p_u_1848.lib.SkinFx
	end
	pcall(v1851)
	pcall(function()
		-- upvalues: (copy) p_u_1848
		p_u_1848.shared.SkinTex.start()
	end)
	pcall(function()
		-- upvalues: (copy) p_u_1848
		p_u_1848.lib.FlareShellFx.init(p_u_1848)
	end)
	pcall(function()
		-- upvalues: (copy) p_u_1848
		p_u_1848.lib.GrenadeFx.init(p_u_1848)
	end)
	pcall(function()
		-- upvalues: (copy) p_u_1848
		p_u_1848.lib.RotarySpin.init(p_u_1848)
	end)
	local v1852, v1853 = pcall(function()
		-- upvalues: (copy) p_u_1848
		return p_u_1848.lib.UiPointer
	end)
	if not v1852 then
		v1853 = nil
	end
	v_u_15 = v1853
	p_u_1848.command("weapon.state", function()
		-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_42, (ref) v_u_17, (ref) v_u_31
		local v1854 = v_u_8.state()
		local v1855 = string.format
		local v1856 = "active=%s weapon=%s ammo=%s/%s reserve=%s mode=%s reloading=%s jammed=%s throwable=%s fx=%s debugAim=%s wantYaw=%s serverAimYaw=%s shotSeq=%d"
		local v1857 = v1854.active
		local v1858 = tostring(v1857)
		local v1859 = v1854.weapon
		local v1860 = tostring(v1859)
		local v1861 = v1854.ammo
		local v1862 = tostring(v1861)
		local v1863 = v1854.mag
		local v1864 = tostring(v1863)
		local v1865 = v1854.reserve
		local v1866 = tostring(v1865)
		local v1867 = v1854.mode
		local v1868 = tostring(v1867)
		local v1869 = v1854.reloading
		local v1870 = tostring(v1869)
		local v1871 = v1854.jammed
		local v1872 = tostring(v1871)
		local v1873 = v1854.throwable
		local v1874 = tostring(v1873)
		local v1875 = v_u_12.isMounted
		local v1876 = tostring(v1875())
		local v1877 = not v_u_42 and "off" or string.format("%.1f,%.1f", v_u_42.X, v_u_42.Z)
		local v1878 = v_u_42
		local v1879
		if v1878 then
			v1879 = v_u_17.Character
			if not (v1879 and v1879.Parent) then
				v1879 = nil
			end
			if v1879 then
				v1879 = v1879:FindFirstChild("HumanoidRootPart")
			end
		else
			v1879 = nil
		end
		local v1880
		if v1878 and v1879 then
			local v1881 = v1878.X - v1879.Position.X
			local v1882 = v1878.Z - v1879.Position.Z
			local v1883 = Vector3.new(v1881, 0, v1882)
			if v1883.Magnitude < 0.8 then
				v1880 = nil
			else
				local v1884 = -v1883.X
				local v1885 = -v1883.Z
				v1880 = math.atan2(v1884, v1885)
			end
		else
			v1880 = nil
		end
		local v1886 = not v1880 and "-" or string.format("%.2f", v1880)
		local v1887 = v_u_17.Character
		if not (v1887 and v1887.Parent) then
			v1887 = nil
		end
		if v1887 then
			v1887 = v1887:GetAttribute("AimYaw")
		end
		return v1855(v1856, v1858, v1860, v1862, v1864, v1866, v1868, v1870, v1872, v1874, v1876, v1877, v1886, tostring(v1887), v_u_31)
	end)
	p_u_1848.command("weapon.fire", function(p1888)
		-- upvalues: (ref) v_u_42, (ref) v_u_17, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_769, (ref) v_u_22, (ref) v_u_10
		local v1889 = p1888[1]
		local v1890 = tonumber(v1889) or 1
		local v_u_1891 = math.clamp(v1890, 1, 60)
		local v_u_1892 = 0
		local v_u_1893 = 0
		task.spawn(function()
			-- upvalues: (copy) v_u_1891, (ref) v_u_42, (ref) v_u_17, (ref) v_u_1893, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_769, (ref) v_u_1892, (ref) v_u_22, (ref) v_u_10
			for _ = 1, v_u_1891 do
				if v_u_42 then
					local v1894 = os.clock() + 1.5
					local v1895 = false
					while os.clock() < v1894 do
						local v1896 = v_u_42
						local v1897
						if v1896 then
							v1897 = v_u_17.Character
							if not (v1897 and v1897.Parent) then
								v1897 = nil
							end
							if v1897 then
								v1897 = v1897:FindFirstChild("HumanoidRootPart")
							end
						else
							v1897 = nil
						end
						local v1898
						if v1896 and v1897 then
							local v1899 = v1896.X - v1897.Position.X
							local v1900 = v1896.Z - v1897.Position.Z
							local v1901 = Vector3.new(v1899, 0, v1900)
							if v1901.Magnitude < 0.8 then
								v1898 = nil
							else
								local v1902 = -v1901.X
								local v1903 = -v1901.Z
								v1898 = math.atan2(v1902, v1903)
							end
						else
							v1898 = nil
						end
						local v1904 = v_u_17.Character
						if not (v1904 and v1904.Parent) then
							v1904 = nil
						end
						if v1904 then
							v1904 = v1904:GetAttribute("AimYaw")
						end
						if not v1898 then
							v1895 = true
							break
						end
						if type(v1904) == "number" then
							local v1905 = (v1898 - v1904 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
							if math.abs(v1905) < 0.05 then
								v1895 = true
								break
							end
						end
						task.wait(0.05)
					end
					if not v1895 then
						v_u_1893 = v_u_1893 + 1
					end
				end
				v_u_1581 = false
				v_u_1575 = false
				if v_u_769() then
					v_u_1892 = v_u_1892 + 1
				end
				task.wait(not v_u_22 and 0.2 or v_u_10.interval(v_u_22) + 0.02)
			end
			v_u_17:SetAttribute("WeaponFireResult", v_u_1892)
			v_u_17:SetAttribute("WeaponFireUnsynced", v_u_1893)
		end)
		return "firing " .. v_u_1891
	end)
	p_u_1848.command("weapon.flickfire", function(p1906)
		-- upvalues: (ref) v_u_17, (ref) v_u_131, (ref) v_u_42, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_24, (ref) v_u_769
		local v1907 = v_u_17.Character
		if not (v1907 and v1907.Parent) then
			v1907 = nil
		end
		if v1907 then
			v1907 = v1907:FindFirstChild("HumanoidRootPart")
		end
		if not v1907 then
			return "no root"
		end
		local v1908 = p1906[1]
		local v1909 = tonumber(v1908) or 120
		local v1910 = v_u_131() + math.rad(v1909)
		local v1911 = v1907.Position
		local v1912 = -math.sin(v1910)
		local v1913 = -math.cos(v1910)
		local v1914 = v1911 + Vector3.new(v1912, 0, v1913) * 20
		v_u_42 = v1914
		local v1915 = v_u_9
		if v1915 then
			v1915 = v_u_9.controllers.Input
		end
		if v1915 then
			local v1916 = v1915.setAimOverride
			if type(v1916) == "function" then
				local v1917 = v1915.setAimOverride
				pcall(v1917, v1914)
			end
		end
		v_u_8._noAy = p1906[2] == "noay"
		v_u_1581 = false
		v_u_1575 = false
		v_u_24 = 0
		local v1918 = v_u_769()
		v_u_8._noAy = false
		local v1919 = string.format
		local v1920 = "fired=%s yaw=%.0f serverAimYaw=%s"
		local v1921 = tostring(v1918)
		local v1922 = math.deg(v1910)
		local v1923 = v_u_17.Character
		if not (v1923 and v1923.Parent) then
			v1923 = nil
		end
		if v1923 then
			v1923 = v1923:GetAttribute("AimYaw")
		end
		return v1919(v1920, v1921, v1922, (tostring(v1923)))
	end)
	p_u_1848.command("weapon.aim", function(p1924)
		-- upvalues: (ref) v_u_42, (ref) v_u_9
		local v1925 = p1924[1]
		local v1926 = tonumber(v1925)
		local v1927 = p1924[2]
		local v1928 = tonumber(v1927)
		if not (v1926 and v1928) then
			v_u_42 = nil
			local v1929 = v_u_9
			if v1929 then
				v1929 = v_u_9.controllers.Input
			end
			if v1929 then
				local v1930 = v1929.setAimOverride
				if type(v1930) == "function" then
					local v1931 = v1929.setAimOverride
					pcall(v1931, nil)
				end
			end
			return "aim cleared"
		end
		local v1932 = Vector3.new(v1926, 0, v1928)
		v_u_42 = v1932
		local v1933 = v_u_9
		if v1933 then
			v1933 = v_u_9.controllers.Input
		end
		local v1934
		if v1933 then
			local v1935 = v1933.setAimOverride
			if type(v1935) == "function" then
				local v1936 = v1933.setAimOverride
				v1934 = pcall(v1936, v1932)
			else
				v1934 = false
			end
		else
			v1934 = false
		end
		return string.format("aim at %s,%s input=%s", tostring(v1926), tostring(v1928), v1934 and "override" or "MISSING Input.setAimOverride (server AimYaw not driven)")
	end)
	p_u_1848.command("weapon.aimpick", function()
		-- upvalues: (ref) v_u_17, (ref) v_u_138, (ref) v_u_371, (ref) v_u_39
		local v1937 = v_u_17.Character
		if not (v1937 and v1937.Parent) then
			v1937 = nil
		end
		if v1937 then
			v1937 = v1937:FindFirstChild("HumanoidRootPart")
		end
		if not v1937 then
			return "no root"
		end
		v_u_138()
		local v1938 = v_u_371(v1937.Position.Y + 1.2)
		local v1939 = v_u_39
		local v1940 = string.format
		local v1941 = "target=%s zombie=%s corpse=%s lying=%s"
		local v1942 = tostring(v1938)
		local v1943 = not v1939 and "-" or v1939.Name
		local v1944
		if v1939 == nil then
			v1944 = false
		else
			v1944 = v1939:GetAttribute("Corpse") == true
		end
		local v1945 = tostring(v1944)
		local v1946
		if v1939 == nil then
			v1946 = false
		else
			v1946 = v1939:GetAttribute("Lying") == true
		end
		return v1940(v1941, v1942, v1943, v1945, (tostring(v1946)))
	end)
	p_u_1848.command("weapon.melee", function()
		-- upvalues: (ref) v_u_32, (ref) v_u_856
		v_u_32 = 0
		v_u_856()
		return "swing"
	end)
	p_u_1848.command("weapon.reload", function()
		-- upvalues: (ref) v_u_658, (ref) v_u_584
		v_u_658()
		local v1947 = string.format
		local v1948 = v_u_584.on
		return v1947("predicted=%s dur=%.2f win=%.2f", tostring(v1948()), v_u_584.dur, v_u_584.win)
	end)
	p_u_1848.command("weapon.reloadtap", function()
		-- upvalues: (ref) v_u_33, (ref) v_u_1594, (ref) v_u_18, (ref) v_u_672, (ref) v_u_658, (ref) v_u_8, (ref) v_u_594, (ref) v_u_584
		v_u_33 = os.clock()
		v_u_1594 = false
		local v1949 = v_u_33
		v_u_33 = nil
		if v_u_18 and (v1949 and not (v_u_1594 or v_u_672())) then
			v_u_658()
		end
		local v1950 = v_u_8.hudState()
		local v1951 = string.format
		local v1952 = "cancels=%d pending=%s predicted=%s hudReloading=%s slow=%s canCancel=%s"
		local v1953 = v_u_594.n
		local v1954 = v_u_594.pending
		local v1955 = tostring(v1954())
		local v1956 = v_u_584.on
		local v1957 = tostring(v1956())
		local v1958
		if v1950 then
			v1958 = v1950.reloading
		else
			v1958 = v1950
		end
		local v1959 = tostring(v1958)
		local v1960
		if v1950 then
			v1960 = v1950.reloadSlow
		else
			v1960 = v1950
		end
		local v1961 = tostring(v1960)
		if v1950 then
			v1950 = v1950.reloadCancel
		end
		return v1951(v1952, v1953, v1955, v1957, v1959, v1961, (tostring(v1950)))
	end)
	p_u_1848.command("weapon.equip", function(p1962)
		-- upvalues: (ref) v_u_639, (ref) v_u_585
		v_u_639(p1962[1] or "next")
		local v1963 = string.format
		local v1964 = v_u_585.pending
		local v1965 = tostring(v1964())
		local v1966 = v_u_585.slot
		local v1967 = tostring(v1966)
		local v1968 = v_u_585.id
		return v1963("pending=%s target=%s id=%s", v1965, v1967, (tostring(v1968)))
	end)
	p_u_1848.command("weapon.switchstate", function()
		-- upvalues: (ref) v_u_9, (ref) v_u_17, (ref) v_u_8, (ref) v_u_21, (ref) v_u_584, (ref) v_u_585, (ref) v_u_23
		local v_u_1969 = v_u_9
		if v_u_1969 then
			v_u_1969 = v_u_9.controllers.CharacterAnim
		end
		local function v1972()
			-- upvalues: (copy) v_u_1969, (ref) v_u_17
			if not (v_u_1969 and v_u_1969.reloadState) then
				return nil
			end
			local v1970 = v_u_1969.reloadState
			local v1971 = v_u_17.Character
			if not (v1971 and v1971.Parent) then
				v1971 = nil
			end
			return v1970(v1971)
		end
		local v1973, v1974 = pcall(v1972)
		local v1975 = v_u_8.hudState()
		local v1976 = string.format
		local v1977 = "weapon=%s uid=%s attrReloading=%s hudReloading=%s predReload=%s pending=%s animReloading=%s ammo=%s/%s mode=%s refusedCues=%d"
		local v1978 = v_u_21
		local v1979 = tostring(v1978)
		local v1980 = v_u_17.Character
		if not (v1980 and v1980.Parent) then
			v1980 = nil
		end
		if v1980 then
			v1980 = v1980:GetAttribute("WeaponUid")
		end
		local v1981 = tostring(v1980)
		local v1982 = v_u_17.Character
		if not (v1982 and v1982.Parent) then
			v1982 = nil
		end
		if v1982 then
			v1982 = v1982:GetAttribute("Reloading")
		end
		local v1983 = tostring(v1982)
		local v1984
		if v1975 then
			v1984 = v1975.reloading
		else
			v1984 = v1975
		end
		local v1985 = tostring(v1984)
		local v1986 = v_u_584.on
		local v1987 = tostring(v1986())
		local v1988 = v_u_585.pending
		local v1989 = tostring(v1988())
		local v1990 = tostring(v1973 and v1974)
		local v1991 = v_u_23
		local v1992 = tostring(v1991)
		local v1993 = v_u_17.Character
		if not (v1993 and v1993.Parent) then
			v1993 = nil
		end
		if v1993 then
			v1993 = v1993:GetAttribute("Ammo")
		end
		local v1994 = tostring(v1993)
		if v1975 then
			v1975 = v1975.mode
		end
		return v1976(v1977, v1979, v1981, v1983, v1985, v1987, v1989, v1990, v1992, v1994, tostring(v1975), v_u_585.refusedCues)
	end)
	p_u_1848.command("weapon.seq", function(p1995)
		-- upvalues: (ref) v_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_585, (ref) v_u_23, (ref) v_u_24, (ref) v_u_1575, (ref) v_u_769, (ref) v_u_22, (ref) v_u_10, (ref) v_u_584, (ref) v_u_639, (ref) v_u_1087, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_658
		local v_u_1996 = table.clone(p1995)
		local v_u_1997 = {}
		local v_u_1998 = os.clock()
		local v_u_1999 = true
		local function v_u_2004(p2000) -- name: add
			-- upvalues: (copy) v_u_1997, (ref) v_u_17, (copy) v_u_1998
			local v2001 = v_u_1997
			local v2002 = string.format
			local v2003 = os.clock()
			table.insert(v2001, v2002("%.3f %s", v2003, p2000))
			v_u_17:SetAttribute("WeaponSeqLog", string.format("t0=%.3f ", v_u_1998) .. table.concat(v_u_1997, " | "))
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_1999, (ref) v_u_8, (ref) v_u_9, (ref) v_u_17, (ref) v_u_585, (copy) v_u_2004
			local v2005 = ""
			while v_u_1999 do
				local v2006 = v_u_8.hudState()
				local v_u_2007 = v_u_9
				if v_u_2007 then
					v_u_2007 = v_u_9.controllers.CharacterAnim
				end
				local function v2010()
					-- upvalues: (copy) v_u_2007, (ref) v_u_17
					if not (v_u_2007 and v_u_2007.reloadState) then
						return nil
					end
					local v2008 = v_u_2007.reloadState
					local v2009 = v_u_17.Character
					if not (v2009 and v2009.Parent) then
						v2009 = nil
					end
					return v2008(v2009)
				end
				local v2011, v2012 = pcall(v2010)
				local v2013 = string.format
				local v2014 = "w=%s attrR=%s hudR=%s anim=%s pend=%s ammo=%s"
				local v2015 = v_u_17.Character
				if not (v2015 and v2015.Parent) then
					v2015 = nil
				end
				if v2015 then
					v2015 = v2015:GetAttribute("Weapon")
				end
				local v2016 = tostring(v2015)
				local v2017 = v_u_17.Character
				if not (v2017 and v2017.Parent) then
					v2017 = nil
				end
				if v2017 then
					v2017 = v2017:GetAttribute("Reloading")
				end
				local v2018 = tostring(v2017)
				if v2006 then
					v2006 = v2006.reloading
				end
				local v2019 = tostring(v2006)
				local v2020 = tostring(v2011 and v2012)
				local v2021 = v_u_585.pending
				local v2022 = tostring(v2021())
				local v2023 = v_u_17.Character
				if not (v2023 and v2023.Parent) then
					v2023 = nil
				end
				if v2023 then
					v2023 = v2023:GetAttribute("Ammo")
				end
				local v2024 = v2013(v2014, v2016, v2018, v2019, v2020, v2022, (tostring(v2023)))
				if v2024 == v2005 then
					v2024 = v2005
				else
					v_u_2004("see " .. v2024)
				end
				task.wait()
				v2005 = v2024
			end
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_1996, (ref) v_u_23, (ref) v_u_24, (ref) v_u_1575, (ref) v_u_769, (ref) v_u_22, (ref) v_u_10, (copy) v_u_2004, (ref) v_u_584, (ref) v_u_639, (ref) v_u_585, (ref) v_u_1087, (ref) v_u_27, (ref) v_u_1581, (ref) v_u_658, (ref) v_u_9, (ref) v_u_17, (ref) v_u_1999
			for _, v2025 in v_u_1996 do
				local v2026, v2027 = string.match(v2025, "^([^:]+):?(.*)$")
				if v2026 == "empty" then
					local v2028 = 0
					while v_u_23 > 0 and v2028 < 120 do
						v2028 = v2028 + 1
						v_u_24 = 0
						v_u_1575 = false
						v_u_769()
						local v2029 = task.wait
						local v2030 = (not v_u_22 and 0.1 or v_u_10.interval(v_u_22)) + 0.03
						v2029((math.max(0.06, v2030)))
					end
					local v2031 = v_u_23
					v_u_2004("empty mag=" .. tostring(v2031))
					task.wait(0.05)
					v_u_1575 = false
					v_u_24 = 0
					v_u_769()
					local v2032 = v_u_2004
					local v2033 = v_u_584.on
					v2032("dry predReload=" .. tostring(v2033()))
				elseif v2026 == "w" then
					task.wait(tonumber(v2027) or 0.1)
				elseif v2026 == "eq" then
					v_u_639(v2027 == "" and "next" or v2027)
					local v2034 = v_u_2004
					local v2035 = tostring(v2027)
					local v2036 = v_u_585.id
					v2034("eq " .. v2035 .. " -> " .. tostring(v2036))
				elseif v2026 == "click" then
					v_u_1087()
					task.wait()
					v_u_27 = false
					v_u_1581 = false
					v_u_1575 = false
					v_u_2004("click")
				elseif v2026 == "hold" then
					v_u_1087()
					v_u_2004("hold")
				elseif v2026 == "release" then
					v_u_27 = false
					v_u_1581 = false
					v_u_1575 = false
					v_u_2004("release")
				elseif v2026 == "rl" then
					v_u_658()
					local v2037 = v_u_2004
					local v2038 = v_u_584.on
					v2037("rl predReload=" .. tostring(v2038()))
				elseif v2026 == "pad" then
					local v2039 = v_u_9.lib.VirtualPad
					local v2040 = v2039 and v2039.code
					if v2040 then
						v2040 = v2039.code(v2027)
					end
					if v2040 then
						v2039.press(v2040, 0.05)
					end
					v_u_2004("pad " .. v2027)
				else
					if v2026 ~= "act" then
						continue
					end
					v_u_17:SetAttribute("HushClientCmd", "input.action " .. v2027)
					v_u_2004("act " .. v2027)
				end
			end
			task.wait(3)
			v_u_1999 = false
			v_u_2004("end")
		end)
		return "seq started (" .. #v_u_1996 .. " steps)"
	end)
	p_u_1848.command("weapon.cqb", function(p2041)
		-- upvalues: (ref) v_u_168, (ref) v_u_42, (ref) v_u_9, (ref) v_u_17, (ref) v_u_138, (ref) v_u_43, (ref) v_u_203, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_24, (ref) v_u_23, (ref) v_u_769, (ref) v_u_22, (ref) v_u_10
		local v_u_2042 = p2041[1] or "log"
		if v_u_2042 == "off" then
			local v2043 = v_u_168
			v_u_168.cursor = nil
			v2043.legacy = false
			v_u_42 = nil
			local v2044 = v_u_9
			if v2044 then
				v2044 = v_u_9.controllers.Input
			end
			if v2044 then
				local v2045 = v2044.setAimOverride
				if type(v2045) == "function" then
					local v2046 = v2044.setAimOverride
					pcall(v2046, nil)
				end
			end
			return "cursor off"
		end
		if v_u_2042 == "log" then
			if p2041[2] == "reset" then
				v_u_168.log = {}
				return "log reset"
			end
			local v2047 = v_u_168.log or {}
			local v2048 = #v2047
			local v2049 = p2041[2]
			local v2050 = v2048 - (tonumber(v2049) or 40) + 1
			local v2051 = {}
			for v2052 = math.max(1, v2050), #v2047 do
				local v2053 = v2047[v2052]
				table.insert(v2051, v2053)
			end
			return string.format("%d entries | %s", #v2047, table.concat(v2051, " | "))
		end
		local v_u_2054 = v_u_17.Character
		if not (v_u_2054 and v_u_2054.Parent) then
			v_u_2054 = nil
		end
		if v_u_2054 then
			v_u_2054 = v_u_2054:FindFirstChild("HumanoidRootPart")
		end
		if not v_u_2054 then
			return "no root"
		end
		local v_u_2055 = nil
		local v2056 = 2
		if v_u_2042 == "at" then
			local v2057 = p2041[2]
			local v2058 = tonumber(v2057)
			local v2059 = p2041[3]
			local v2060 = tonumber(v2059)
			local v2061 = p2041[4]
			local v2062 = tonumber(v2061)
			if not (v2058 and (v2060 and v2062)) then
				return "usage: weapon.cqb at <x> <y> <z> [n] [legacy]"
			end
			v_u_2055 = Vector3.new(v2058, v2060, v2062)
			v2056 = 5
		elseif v_u_2042 ~= "head" and (v_u_2042 ~= "body" and v_u_2042 ~= "both") then
			return "usage: weapon.cqb head|body|both|at|off|log"
		end
		local v_u_2063 = v_u_9
		if v_u_2063 then
			v_u_2063 = v_u_9.controllers.Camera
		end
		local v2065, v2066 = pcall(function()
			-- upvalues: (copy) v_u_2063
			local v2064 = v_u_2063 and v_u_2063.yaw
			if v2064 then
				v2064 = v_u_2063.yaw()
			end
			return v2064
		end)
		local v2067 = v_u_9.shared.Iso
		local v2068 = v2067.lookVector
		if not v2065 or type(v2066) ~= "number" then
			v2066 = v2067.BASE_YAW
		end
		local v_u_2069 = v2068(v2066, v2067.PITCH)
		local function v_u_2084(p2070) -- name: pick
			-- upvalues: (ref) v_u_2055, (ref) v_u_138, (ref) v_u_43, (copy) v_u_2054, (ref) v_u_203, (copy) v_u_2069
			if v_u_2055 then
				return v_u_2055
			end
			v_u_138()
			local v2071 = (1 / 0)
			local v2072 = nil
			for _, v2073 in v_u_43 do
				local v2074 = v2073:FindFirstChild("HumanoidRootPart")
				if not v2074 or (not v2073.Parent or (v2074.Position - v_u_2054.Position).Magnitude >= v2071) then
					continue
				end
				v2071 = (v2074.Position - v_u_2054.Position).Magnitude
				v2072 = v2073
			end
			if not v2072 then
				return nil
			end
			local v2075 = p2070 == "head" and { "Head" } or { "UpperTorso", "LowerTorso", "Torso" }
			local v2076 = p2070 == "head" and "head" or "torso"
			local v2077 = nil
			for _, v2078 in v2075 do
				local v2079 = v2072:FindFirstChild(v2078)
				if not (v2079 and v2079:IsA("BasePart")) then
					continue
				end
				for _, v2080 in { Vector3.new(0, 0, 0), Vector3.new(0, -0.35, 0), Vector3.new(0, 0.3, 0) } do
					local v2081 = v2079.Position + v2079.CFrame:VectorToWorldSpace(v2080 * v2079.Size.Y)
					local _, _, v2082, _, v2083 = v_u_203(v2081 - v_u_2069 * 120, v_u_2069, 240, v_u_2054.Position)
					if v2082 == v2072 and v2083 == v2076 then
						return v2081
					end
					v2077 = v2077 or v2081
				end
			end
			return v2077
		end
		local v2085 = v_u_2084(v_u_2042 == "head" and "head" or "body")
		if not v2085 then
			return "no drawn zombie"
		end
		local v2086 = p2041[v2056]
		local v2087 = tonumber(v2086) or (v_u_2042 == "both" and 2 or 1)
		local v_u_2088 = math.clamp(v2087, 1, 30)
		v_u_168.legacy = table.find(p2041, "legacy") ~= nil
		v_u_168.log = v_u_168.log or {}
		v_u_168.cursor = v2085
		local v2089 = v2085 - v_u_2069 * 120
		local v2090 = v2089 + v_u_2069 * ((v_u_2054.Position.Y - v2089.Y) / v_u_2069.Y)
		v_u_42 = v2090
		local v2091 = v_u_9
		if v2091 then
			v2091 = v_u_9.controllers.Input
		end
		if v2091 then
			local v2092 = v2091.setAimOverride
			if type(v2092) == "function" then
				local v2093 = v2091.setAimOverride
				pcall(v2093, v2090)
			end
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_2088, (copy) v_u_2042, (copy) v_u_2084, (ref) v_u_168, (copy) v_u_2069, (copy) v_u_2054, (ref) v_u_42, (ref) v_u_9, (ref) v_u_1581, (ref) v_u_1575, (ref) v_u_24, (ref) v_u_23, (ref) v_u_769, (ref) v_u_22, (ref) v_u_10
			for v2094 = 1, v_u_2088 do
				local v2095
				if v_u_2042 == "both" then
					v2095 = v2094 % 2 == 1 and "body" or "head"
				else
					v2095 = v_u_2042
				end
				local v2096 = v_u_2084(v2095)
				if v2096 then
					v_u_168.cursor = v2096
					local v2097 = v2096 - v_u_2069 * 120
					local v2098 = v2097 + v_u_2069 * ((v_u_2054.Position.Y - v2097.Y) / v_u_2069.Y)
					v_u_42 = v2098
					local v2099 = v_u_9
					if v2099 then
						v2099 = v_u_9.controllers.Input
					end
					if v2099 then
						local v2100 = v2099.setAimOverride
						if type(v2100) == "function" then
							local v2101 = v2099.setAimOverride
							pcall(v2101, v2098)
						end
					end
				end
				task.wait(0.12)
				v_u_1581 = false
				v_u_1575 = false
				v_u_24 = 0
				local v2102 = v_u_23
				v_u_23 = math.max(v2102, 1)
				v_u_769()
				task.wait(not v_u_22 and 0.2 or v_u_10.interval(v_u_22) + 0.03)
			end
			local v2103 = v_u_168
			v_u_168.cursor = nil
			v2103.legacy = false
			v_u_42 = nil
			local v2104 = v_u_9
			if v2104 then
				v2104 = v_u_9.controllers.Input
			end
			if v2104 then
				local v2105 = v2104.setAimOverride
				if type(v2105) == "function" then
					local v2106 = v2104.setAimOverride
					pcall(v2106, nil)
					return
				end
			end
		end)
		local v2107 = string.format
		local v2108 = v2085.X
		local v2109 = v2085.Y
		local v2110 = v2085.Z
		local v2111 = v2090.X
		local v2112 = v2090.Z
		local v2113 = v2090.X - v_u_2054.Position.X
		local v2114 = v2090.Z - v_u_2054.Position.Z
		local v2115 = Vector3.new(v2113, 0, v2114).Magnitude
		local v2116 = v_u_168.legacy
		return v2107("cursor %.2f,%.2f,%.2f plane %.2f,%.2f (%.2f studs) legacy=%s n=%d", v2108, v2109, v2110, v2111, v2112, v2115, tostring(v2116), v_u_2088)
	end)
	p_u_1848.command("weapon.throwtest", function(p2117)
		-- upvalues: (ref) v_u_168, (ref) v_u_17, (ref) v_u_42, (ref) v_u_9, (ref) v_u_924, (ref) v_u_925, (ref) v_u_981, (ref) v_u_1010
		if p2117[1] == "last" then
			local v2118 = v_u_168.throwLand
			return not v2118 and "no throw seen" or string.format("server land %.2f,%.2f,%.2f", v2118.X, v2118.Y, v2118.Z)
		end
		local v2119 = p2117[1]
		local v2120 = tonumber(v2119)
		local v2121 = p2117[2]
		local v2122 = tonumber(v2121)
		local v2123 = v_u_17.Character
		if not (v2123 and v2123.Parent) then
			v2123 = nil
		end
		if v2123 then
			v2123 = v2123:FindFirstChild("HumanoidRootPart")
		end
		if not (v2120 and (v2122 and v2123)) then
			return "usage: weapon.throwtest <x> <z> [throw] | last"
		end
		local v2124 = v2123.Position.Y
		local v2125 = Vector3.new(v2120, v2124, v2122)
		v_u_42 = v2125
		local v2126 = v_u_9
		if v2126 then
			v2126 = v_u_9.controllers.Input
		end
		if v2126 then
			local v2127 = v2126.setAimOverride
			if type(v2127) == "function" then
				local v2128 = v2126.setAimOverride
				pcall(v2128, v2125)
			end
		end
		v_u_168.throwLand = nil
		task.wait(0.15)
		local v2129, v2130 = v_u_924()
		if not (v2129 and v2130) then
			return "no throw target (throwable?)"
		end
		v_u_925.path = nil
		local v2131, v2132, v2133 = v_u_981(v2129, v2130)
		local v2134 = {}
		for _, v2135 in v2131 do
			local v2136 = string.format
			local v2137 = v2135.X
			local v2138 = v2135.Y
			local v2139 = v2135.Z
			table.insert(v2134, v2136("%.1f,%.1f,%.1f", v2137, v2138, v2139))
		end
		if p2117[3] == "throw" then
			v_u_1010()
		end
		v_u_42 = nil
		local v2140 = v_u_9
		if v2140 then
			v2140 = v_u_9.controllers.Input
		end
		if v2140 then
			local v2141 = v2140.setAimOverride
			if type(v2141) == "function" then
				local v2142 = v2140.setAimOverride
				pcall(v2142, nil)
			end
		end
		local v2143 = string.format("throwtest hand %.1f,%.1f,%.1f target %.1f,%.1f,%.1f blocked=%s land %.2f,%.2f,%.2f path[%d] %s", v2129.X, v2129.Y, v2129.Z, v2130.X, v2130.Y, v2130.Z, tostring(v2133), v2132.X, v2132.Y, v2132.Z, #v2131, table.concat(v2134, " "))
		v_u_168.log = v_u_168.log or {}
		local v2144 = v_u_168.log
		table.insert(v2144, v2143)
		return v2143
	end)
	p_u_1848.command("weapon.throw", function()
		-- upvalues: (ref) v_u_1010, (ref) v_u_17
		v_u_1010()
		local v2145 = "throw "
		local v2146 = v_u_17.Character
		if not (v2146 and v2146.Parent) then
			v2146 = nil
		end
		if v2146 then
			v2146 = v2146:GetAttribute("Throwable")
		end
		return v2145 .. tostring(v2146)
	end)
	p_u_1848.command("weapon.fprange", function()
		-- upvalues: (ref) v_u_49, (ref) v_u_22, (ref) v_u_113
		local v2147 = v_u_49.rng
		local v2148 = string.format
		local v2149 = "range=%s under=%s note=%s farReach=%s fp=%s checkedAgo=%.1fs"
		local v2150 = v_u_22
		if v2150 then
			v2150 = v_u_22.range
		end
		local v2151 = tostring(v2150)
		local v2152 = not v2147.under and "none" or string.format("%.0f", v2147.under)
		local v2153 = v2147.note or "none"
		local v2154 = tostring(v2153)
		local v2155 = v2147.far
		local v2156 = tostring(v2155)
		local v2157 = v_u_113() ~= nil
		return v2148(v2149, v2151, v2152, v2154, v2156, tostring(v2157), os.clock() - v2147.at)
	end)
	p_u_1848.command("weapon.throwmode", function(p2158)
		-- upvalues: (ref) v_u_1063, (ref) v_u_1716, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13, (ref) v_u_62, (ref) v_u_1010, (ref) v_u_924, (ref) v_u_17, (ref) v_u_1039
		local v2159 = p2158[1]
		if v2159 == "on" then
			v_u_1063()
		elseif v2159 == "off" then
			if v_u_1716 then
				v_u_1716 = false
				local v2160 = v_u_9.lib.GrenadeFx.hold
				pcall(v2160, false)
				v_u_12.arcPreview(nil)
				local v2161 = v_u_13.throwHint
				pcall(v2161, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		elseif v2159 == "throw" and v_u_1716 then
			v_u_1010()
			if v_u_1716 then
				v_u_1716 = false
				local v2162 = v_u_9.lib.GrenadeFx.hold
				pcall(v2162, false)
				v_u_12.arcPreview(nil)
				local v2163 = v_u_13.throwHint
				pcall(v2163, nil)
				if v_u_62 then
					v_u_62.Visible = false
				end
			end
		end
		local _, v2164 = v_u_924()
		local v2165 = string.format
		local v2166 = "throwMode=%s throwable=%s hint=%s landing=%s"
		local v2167 = v_u_1716
		local v2168 = tostring(v2167)
		local v2169 = v_u_17.Character
		if not (v2169 and v2169.Parent) then
			v2169 = nil
		end
		if v2169 then
			v2169 = v2169:GetAttribute("Throwable")
		end
		return v2165(v2166, v2168, tostring(v2169), not v_u_1716 and "-" or v_u_1039(), not v2164 and "-" or string.format("%.1f,%.1f,%.1f", v2164.X, v2164.Y, v2164.Z))
	end)
end
function v_u_8.start() -- name: start
	-- upvalues: (ref) v_u_9, (copy) v_u_1311, (copy) v_u_1309
	local v2170 = v_u_9.session
	if v2170 and v2170.onPlaceChanged then
		v2170.onPlaceChanged(v_u_1311)
	else
		v_u_1309()
	end
end
return v_u_8