-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / PerkSight

local v_u_37 = {
	["NIGHT_TINT"] = 0.92,
	["NIGHT_NAME"] = "HushPerkNight",
	["FADE"] = 1.5,
	["POLL"] = 0.5,
	["NOTE_ATTR"] = "PerkOpticNote",
	["NOTE_HEAD"] = "OPTIC DRILL",
	["readPerk"] = function(p1) -- name: readPerk
		local v2 = {
			["keen"] = 0,
			["narrow"] = 0,
			["night"] = 0,
			["aim"] = 1,
			["extra"] = 1
		}
		if type(p1) ~= "function" then
			return v2
		end
		local v3, v4 = pcall(p1, "Perk_keenVision")
		if not v3 then
			v4 = nil
		end
		v2.keen = v4 == true and 1 or ((type(v4) ~= "number" or (v4 ~= v4 or (v4 == (1 / 0) or (v4 == (-1 / 0) or v4 <= 0)))) and 0 or v4)
		local v5, v6 = pcall(p1, "Perk_narrowVision")
		if not v5 then
			v6 = nil
		end
		v2.narrow = v6 == true and 1 or ((type(v6) ~= "number" or (v6 ~= v6 or (v6 == (1 / 0) or (v6 == (-1 / 0) or v6 <= 0)))) and 0 or v6)
		local v7, v8 = pcall(p1, "Perk_nightBlind")
		if not v7 then
			v8 = nil
		end
		v2.night = v8 == true and 1 or ((type(v8) ~= "number" or (v8 ~= v8 or (v8 == (1 / 0) or (v8 == (-1 / 0) or v8 <= 0)))) and 0 or v8)
		local v9, v10 = pcall(p1, "Perk_opticAimMul")
		if not v9 then
			v10 = nil
		end
		v2.aim = (type(v10) ~= "number" or (v10 ~= v10 or (v10 <= 0 or v10 >= 1))) and 1 or v10
		local v11, v12 = pcall(p1, "Perk_opticExtraMul")
		if not v11 then
			v12 = nil
		end
		v2.extra = (type(v12) ~= "number" or (v12 ~= v12 or (v12 <= 0 or v12 >= 1))) and 1 or v12
		return v2
	end,
	["noteOf"] = function(p13, p14) -- name: noteOf
		-- upvalues: (copy) v_u_37
		local v15 = (type(p13) ~= "number" or (p13 ~= p13 or (p13 <= 0 or p13 >= 1))) and 1 or p13
		local v16 = (type(p14) ~= "number" or (p14 ~= p14 or (p14 <= 0 or p14 >= 1))) and 1 or p14
		if v15 >= 1 and v16 >= 1 then
			return nil
		end
		local v17 = {}
		if v15 < 1 then
			local v18 = (1 - v15) * 100 + 0.5
			local v19 = math.floor(v18)
			table.insert(v17, ("sight ready %d percent sooner"):format(v19))
		end
		if v16 < 1 then
			local v20 = (1 - v16) * 100 + 0.5
			local v21 = math.floor(v20)
			table.insert(v17, ("extra optic time cut by %d percent"):format(v21))
		end
		return v_u_37.NOTE_HEAD .. ": " .. table.concat(v17, ", ")
	end,
	["tint"] = function(p22) -- name: tint
		-- upvalues: (copy) v_u_37
		return p22 ~= true and 1 or v_u_37.NIGHT_TINT
	end,
	["evaluate"] = function(p23, p24) -- name: evaluate
		-- upvalues: (copy) v_u_37
		if type(p23) ~= "table" then
			p23 = v_u_37.readPerk(nil)
		end
		local v25 = type(p24) ~= "table" and {} or p24
		local v26
		if v25.viewMode == "fptp" then
			v26 = v25.pvpve ~= true
		else
			v26 = false
		end
		if not v26 then
			return {
				["active"] = false,
				["keen"] = 0,
				["narrow"] = 0,
				["night"] = false,
				["note"] = nil
			}
		end
		local v27 = p23.night
		local v28
		if (v27 == true and 1 or ((type(v27) ~= "number" or (v27 ~= v27 or (v27 == (1 / 0) or (v27 == (-1 / 0) or v27 <= 0)))) and 0 or v27)) > 0 then
			v28 = v25.time == "Dusk" and true or v25.time == "Night"
		else
			v28 = false
		end
		local v29 = {
			["active"] = true,
			["keen"] = nil,
			["narrow"] = nil,
			["night"] = nil,
			["note"] = nil
		}
		local v30 = p23.keen
		v29.keen = v30 == true and 1 or ((type(v30) ~= "number" or (v30 ~= v30 or (v30 == (1 / 0) or (v30 == (-1 / 0) or v30 <= 0)))) and 0 or v30)
		local v31 = p23.narrow
		v29.narrow = v31 == true and 1 or ((type(v31) ~= "number" or (v31 ~= v31 or (v31 == (1 / 0) or (v31 == (-1 / 0) or v31 <= 0)))) and 0 or v31)
		v29.night = v28
		v29.note = v_u_37.noteOf(p23.aim, p23.extra)
		return v29
	end,
	["fovCeilFor"] = function(p32, p33) -- name: fovCeilFor
		local v34
		if type(p32) == "table" then
			local v35 = p32.keen
			v34 = v35 == true and 1 or ((type(v35) ~= "number" or (v35 ~= v35 or (v35 == (1 / 0) or (v35 == (-1 / 0) or v35 <= 0)))) and 0 or v35)
		else
			v34 = 0
		end
		local v36 = type(p33) == "table" and p33.pvpve == true and 0 or v34
		return v36 >= 2 and 100 or (v36 >= 1 and 95 or 90)
	end
}
local v_u_38 = false
local v_u_39 = {}
function v_u_37.fovCeilOf(p_u_40) -- name: fovCeilOf
	-- upvalues: (copy) v_u_37
	if p_u_40 == nil then
		return 90
	end
	local function v51()
		-- upvalues: (ref) v_u_37, (copy) p_u_40
		local v41 = v_u_37.fovCeilFor
		local v_u_42 = p_u_40
		local v44 = v_u_37.readPerk(function(p43)
			-- upvalues: (copy) v_u_42
			return v_u_42:GetAttribute(p43)
		end)
		local v45 = {}
		local v49, v50 = pcall(function()
			local v46 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
			local v47
			if v46 then
				v47 = v46:FindFirstChild("Shared")
			else
				v47 = nil
			end
			local v48
			if v47 then
				v48 = v47:FindFirstChild("GameMode")
			else
				v48 = nil
			end
			if v48 then
				return require(v48).isPvpve()
			else
				return false
			end
		end)
		if v49 then
			v49 = v50 == true
		end
		v45.pvpve = v49
		return v41(v44, v45)
	end
	local v52, v53 = pcall(v51)
	return (not v52 or type(v53) ~= "number") and 90 or v53
end
function v_u_37.stop() -- name: stop
	-- upvalues: (ref) v_u_39, (ref) v_u_38
	for _, v54 in v_u_39 do
		pcall(v54)
	end
	v_u_39 = {}
	v_u_38 = false
end
function v_u_37.start(_) -- name: start
	-- upvalues: (ref) v_u_38, (copy) v_u_37, (ref) v_u_39
	if v_u_38 then
		return
	else
		local v55 = game:GetService("Players")
		local v_u_56 = game:GetService("Lighting")
		local v_u_57 = game:GetService("TweenService")
		local v_u_58 = v55.LocalPlayer
		if v_u_58 ~= nil then
			v_u_38 = true
			local v_u_59 = "FpCamMath"
			local v61, v_u_62 = pcall(function()
				-- upvalues: (copy) v_u_59
				local v60 = script.Parent:FindFirstChild(v_u_59)
				if v60 then
					return require(v60)
				else
					return nil
				end
			end)
			if not v61 or type(v_u_62) ~= "table" then
				v_u_62 = nil
			end
			local v_u_63 = "ViewVis"
			local v65, v_u_66 = pcall(function()
				-- upvalues: (copy) v_u_63
				local v64 = script.Parent:FindFirstChild(v_u_63)
				if v64 then
					return require(v64)
				else
					return nil
				end
			end)
			if not v65 or type(v_u_66) ~= "table" then
				v_u_66 = nil
			end
			local v_u_67 = nil
			local v_u_68 = nil
			local v_u_69 = ""
			local v_u_70 = false
			local function v_u_74(p71) -- name: getEffect
				-- upvalues: (ref) v_u_67, (copy) v_u_56, (ref) v_u_37
				if v_u_67 ~= nil and v_u_67.Parent == v_u_56 then
					return v_u_67
				end
				local v72 = v_u_56:FindFirstChild(v_u_37.NIGHT_NAME)
				if v72 ~= nil and v72:IsA("ColorCorrectionEffect") then
					v_u_67 = v72
					return v72
				end
				if not p71 then
					return nil
				end
				local v73 = Instance.new("ColorCorrectionEffect")
				v73.Name = v_u_37.NIGHT_NAME
				v73.TintColor = Color3.new(1, 1, 1)
				v73.Parent = v_u_56
				v_u_67 = v73
				return v73
			end
			local function v_u_83(p75) -- name: setNight
				-- upvalues: (copy) v_u_74, (ref) v_u_68, (ref) v_u_37, (copy) v_u_57, (ref) v_u_67, (copy) v_u_56, (ref) v_u_70
				local v_u_76 = v_u_74(p75)
				if v_u_76 ~= nil then
					if v_u_68 ~= nil then
						local function v77()
							-- upvalues: (ref) v_u_68
							v_u_68:Cancel()
						end
						pcall(v77)
						v_u_68 = nil
					end
					local v_u_78 = v_u_37.tint(p75)
					local function v80()
						-- upvalues: (ref) v_u_57, (copy) v_u_76, (ref) v_u_37, (copy) v_u_78
						local v79 = v_u_57:Create(v_u_76, TweenInfo.new(v_u_37.FADE, Enum.EasingStyle.Sine), {
							["TintColor"] = Color3.new(v_u_78, v_u_78, v_u_78)
						})
						v79:Play()
						return v79
					end
					local v81, v82 = pcall(v80)
					if v81 then
						v_u_68 = v82
					else
						v_u_76.TintColor = Color3.new(v_u_78, v_u_78, v_u_78)
					end
					if not p75 then
						task.delay(v_u_37.FADE + 0.1, function()
							-- upvalues: (ref) v_u_67, (ref) v_u_56, (ref) v_u_70
							if v_u_67 ~= nil and (v_u_67.Parent == v_u_56 and not v_u_70) then
								v_u_67:Destroy()
								v_u_67 = nil
							end
						end)
					end
				end
			end
			local function v_u_109() -- name: apply
				-- upvalues: (copy) v_u_58, (ref) v_u_37, (ref) v_u_69, (copy) v_u_62, (copy) v_u_66, (ref) v_u_70, (copy) v_u_83
				local v84 = v_u_58:GetAttribute("AtmoTime")
				local v85 = {
					["viewMode"] = v_u_58:GetAttribute("ViewMode") == "fptp" and "fptp" or "classic"
				}
				local v89, v90 = pcall(function()
					local v86 = game:GetService("ReplicatedStorage"):FindFirstChild("Hush")
					local v87
					if v86 then
						v87 = v86:FindFirstChild("Shared")
					else
						v87 = nil
					end
					local v88
					if v87 then
						v88 = v87:FindFirstChild("GameMode")
					else
						v88 = nil
					end
					if v88 then
						return require(v88).isPvpve()
					else
						return false
					end
				end)
				if v89 then
					v89 = v90 == true
				end
				v85.pvpve = v89
				v85.time = type(v84) ~= "string" and "" or v84
				local v_u_91 = v_u_58
				local v_u_93 = v_u_37.evaluate(v_u_37.readPerk(function(p92)
					-- upvalues: (copy) v_u_91
					return v_u_91:GetAttribute(p92)
				end), v85)
				local v94 = v_u_93.keen
				local v95 = tostring(v94)
				local v96 = v_u_93.narrow
				local v97 = tostring(v96)
				local v98 = v_u_93.active
				local v99 = tostring(v98)
				local v100 = v_u_93.night
				local v101 = tostring(v100)
				local v102 = v_u_93.note
				local v103 = ("%s.%s.%s.%s.%s"):format(v95, v97, v99, v101, (tostring(v102)))
				if v103 ~= v_u_69 then
					v_u_69 = v103
					if v_u_62 ~= nil then
						local v104 = v_u_62.setFovCeil
						local v105 = not v_u_93.active and 90 or v_u_62.fovCeilFor(v_u_93.keen)
						pcall(v104, v105)
					end
					if v_u_66 ~= nil then
						local v106 = v_u_66.setNear
						local v107
						if v_u_93.active then
							v107 = v_u_66.nearFor(v_u_93.keen, v_u_93.narrow)
						else
							v107 = v_u_66.NEAR_BASE
						end
						pcall(v106, v107)
					end
					if v_u_93.night ~= v_u_70 then
						v_u_70 = v_u_93.night
						v_u_83(v_u_70)
					end
					local function v108()
						-- upvalues: (ref) v_u_58, (ref) v_u_37, (copy) v_u_93
						v_u_58:SetAttribute(v_u_37.NOTE_ATTR, v_u_93.note)
					end
					pcall(v108)
				end
			end
			local function v116(p_u_110) -- name: hook
				-- upvalues: (copy) v_u_58, (copy) v_u_109, (ref) v_u_39
				local function v111()
					-- upvalues: (ref) v_u_58, (copy) p_u_110
					return v_u_58:GetAttributeChangedSignal(p_u_110)
				end
				local v112, v113 = pcall(v111)
				if v112 then
					local v_u_114 = v113:Connect(v_u_109)
					local v115 = v_u_39
					table.insert(v115, function()
						-- upvalues: (copy) v_u_114
						v_u_114:Disconnect()
					end)
				end
			end
			local v_u_117 = v_u_67
			local v_u_118 = v_u_68
			for _, v119 in {
				"ViewMode",
				"AtmoTime",
				"Perk_keenVision",
				"Perk_narrowVision",
				"Perk_nightBlind",
				"Perk_opticAimMul",
				"Perk_opticExtraMul"
			} do
				v116(v119)
			end
			local v_u_120 = true
			local v121 = v_u_39
			local function v126()
				-- upvalues: (ref) v_u_120, (ref) v_u_118, (ref) v_u_117, (copy) v_u_62, (copy) v_u_66
				v_u_120 = false
				if v_u_118 ~= nil then
					local function v122()
						-- upvalues: (ref) v_u_118
						v_u_118:Cancel()
					end
					pcall(v122)
					v_u_118 = nil
				end
				if v_u_117 ~= nil then
					local function v123()
						-- upvalues: (ref) v_u_117
						v_u_117:Destroy()
					end
					pcall(v123)
					v_u_117 = nil
				end
				if v_u_62 ~= nil then
					local v124 = v_u_62.setFovCeil
					pcall(v124, 90)
				end
				if v_u_66 ~= nil then
					local v125 = v_u_66.setNear
					pcall(v125, nil)
				end
			end
			table.insert(v121, v126)
			task.spawn(function()
				-- upvalues: (ref) v_u_120, (copy) v_u_109, (ref) v_u_37
				while v_u_120 do
					local v127 = v_u_109
					pcall(v127)
					task.wait(v_u_37.POLL)
				end
			end)
			pcall(v_u_109)
		end
	end
end
return v_u_37