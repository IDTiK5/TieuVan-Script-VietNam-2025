-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioMusic

local v_u_1 = {}
local v_u_2 = {
	["menu"] = 2,
	["hideout"] = 2,
	["calm"] = 2.5,
	["tension"] = 2,
	["chase"] = 1.5,
	["extract"] = 1.5,
	["debrief"] = 2,
	["silent"] = 2
}
local v_u_3 = {
	["menu"] = 3,
	["hideout"] = 3,
	["calm"] = 5,
	["tension"] = 2.5,
	["chase"] = 1,
	["extract"] = 2,
	["debrief"] = 2.5
}
local v_u_4 = {
	["menu"] = "mus_menu",
	["hideout"] = "mus_hideout",
	["calm"] = "mus_calm",
	["tension"] = "mus_tension",
	["chase"] = "mus_chase",
	["extract"] = "mus_extract",
	["debrief"] = "mus_debrief"
}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = "silent"
local v_u_8 = nil
local v_u_9 = 0
local v_u_10 = false
local v_u_11 = nil
local v_u_12 = ""
local v_u_13 = 0
local v_u_14 = nil
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = {}
local v_u_18 = 0
local v_u_19 = "calm"
local v_u_20 = 0
local v_u_21 = 1
local v_u_22 = 0
local v_u_23 = 1
local v_u_24 = Random.new()
local v_u_25 = 0
local v_u_26 = {}
local v_u_27 = nil
v_u_1.onChanged = nil
local function v_u_32(p28) -- name: nextVariant
	-- upvalues: (ref) v_u_6, (copy) v_u_26, (copy) v_u_17, (copy) v_u_24
	local v29 = v_u_6.defs[p28]
	if not v29 or #v29.v == 0 then
		return nil
	end
	local v30 = v_u_26[p28]
	if v30 and v29.v[v30] then
		return v30
	end
	local v31 = (v_u_17[p28] or v_u_24:NextInteger(0, #v29.v - 1)) % #v29.v + 1
	v_u_17[p28] = v31
	return v31
end
local function v_u_34(p33) -- name: isMusic
	-- upvalues: (ref) v_u_5
	return p33.sound.SoundGroup == v_u_5.groups.Music
end
local function v_u_42(p35, p36, p37, p38, p39) -- name: tryStart
	-- upvalues: (copy) v_u_4, (ref) v_u_11, (ref) v_u_5, (ref) v_u_15, (copy) v_u_34, (copy) v_u_32, (copy) v_u_3, (ref) v_u_23, (ref) v_u_21, (ref) v_u_25, (ref) v_u_12, (ref) v_u_13
	local v40 = v_u_4[p35]
	if not v40 then
		return true
	end
	if v_u_11 and v_u_11:alive() then
		return true
	end
	v_u_11 = nil
	if #v_u_5.groupVoices("Music") > 0 then
		if p36 - v_u_15 < 4 then
			return false
		end
		v_u_5.stopAll(v_u_34, 0)
	end
	local v41 = p37 or v_u_32(v40)
	if not v41 then
		return true
	end
	if p38 == nil then
		if p35 == "calm" then
			p38 = false
		else
			p38 = p35 ~= "debrief"
		end
	end
	v_u_11 = v_u_5.play(v40, {
		["variant"] = nil,
		["loop"] = nil,
		["fadeIn"] = nil,
		["priority"] = 9,
		["volume"] = nil,
		["ignoreMax"] = true,
		["variant"] = v41,
		["loop"] = p38,
		["fadeIn"] = p39 or (v_u_3[p35] or 3),
		["volume"] = v_u_23 * v_u_21
	})
	v_u_25 = p36 + 4
	v_u_12 = v40
	v_u_13 = p36
	return true
end
local function v_u_50(p43) -- name: apply
	-- upvalues: (ref) v_u_7, (ref) v_u_14, (copy) v_u_2, (ref) v_u_11, (ref) v_u_12, (ref) v_u_16, (copy) v_u_24, (ref) v_u_15, (copy) v_u_42, (copy) v_u_1
	if p43 ~= v_u_7 then
		local v44 = v_u_7
		v_u_7 = p43
		v_u_14 = nil
		local v45 = p43 == "chase" and 0.7 or (v_u_2[v44] or 2)
		if v_u_11 then
			v_u_11:stop(v45)
			v_u_11 = nil
			v_u_12 = ""
		end
		v_u_16 = 0
		if p43 ~= "silent" then
			if p43 == "calm" then
				local v46 = os.clock()
				local v47
				if v44 == "tension" or v44 == "chase" then
					v47 = v_u_24:NextNumber(6, 14)
				else
					v47 = v_u_24:NextNumber(2, 5)
				end
				v_u_16 = v46 + v47
			else
				local v48 = os.clock()
				v_u_14 = p43
				v_u_15 = v48
				if v_u_42(p43, v48) then
					v_u_14 = nil
				end
			end
		end
		local v49 = v_u_1.onChanged
		if v49 then
			task.spawn(v49, p43)
		end
	end
end
function v_u_1.set(p51) -- name: set
	-- upvalues: (ref) v_u_27, (copy) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_50
	local v52 = v_u_27
	if v52 then
		if p51 == "auto" then
			v52.resumeForced = nil
		elseif p51 == "silent" or v_u_4[p51] then
			v52.resume = p51
			v52.resumeForced = p51
		end
	elseif p51 == "auto" then
		v_u_8 = nil
		return
	elseif p51 == "silent" or v_u_4[p51] then
		v_u_8 = p51
		v_u_9 = (p51 ~= "calm" and (p51 ~= "tension" and p51 ~= "chase") or not v_u_10) and (1 / 0) or os.clock() + 12
		v_u_50(p51)
	else
		warn("[HUSH:Audio] unknown music state:", p51)
	end
end
function v_u_1.setAuto(p53) -- name: setAuto
	-- upvalues: (ref) v_u_27, (ref) v_u_10, (ref) v_u_8, (ref) v_u_19, (ref) v_u_20, (copy) v_u_50
	local v54 = v_u_27
	if v54 then
		v54.resumeAuto = p53
		if p53 then
			v54.resume = "calm"
			v54.resumeForced = nil
		end
	else
		v_u_10 = p53
		if p53 then
			v_u_8 = nil
			v_u_19 = "calm"
			v_u_20 = os.clock()
			v_u_50("calm")
		end
	end
end
function v_u_1.setThreat(p55) -- name: setThreat
	-- upvalues: (ref) v_u_18
	v_u_18 = math.clamp(p55, 0, 1)
end
function v_u_1.duck(p56, p57) -- name: duck
	-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_11, (ref) v_u_23
	local v58 = v_u_21
	local v59 = 1 - math.clamp(p56, 0, 0.9)
	v_u_21 = math.min(v58, v59)
	local v60 = v_u_22
	local v61 = os.clock() + p57
	v_u_22 = math.max(v60, v61)
	if v_u_11 then
		v_u_11:setVolume(v_u_23 * v_u_21, 0.15)
	end
end
function v_u_1.setVolume(p62) -- name: setVolume
	-- upvalues: (ref) v_u_23, (ref) v_u_11, (ref) v_u_21
	v_u_23 = p62
	if v_u_11 then
		v_u_11:setVolume(v_u_23 * v_u_21, 0.5)
	end
end
function v_u_1.state() -- name: state
	-- upvalues: (ref) v_u_27, (ref) v_u_7
	return v_u_27 and "audition" or v_u_7
end
function v_u_1.states() -- name: states
	return {
		"menu",
		"hideout",
		"calm",
		"tension",
		"chase",
		"extract",
		"debrief"
	}
end
function v_u_1.candidates(p63) -- name: candidates
	-- upvalues: (copy) v_u_4, (ref) v_u_6
	local v64 = v_u_4[p63]
	local v65 = v64 and v_u_6
	if v65 then
		v65 = v_u_6.defs[v64]
	end
	return not v65 and {} or v65.v
end
function v_u_1.prefer(p66, p67) -- name: prefer
	-- upvalues: (copy) v_u_4, (ref) v_u_6, (copy) v_u_26, (ref) v_u_27, (ref) v_u_7, (copy) v_u_2, (ref) v_u_11, (ref) v_u_12, (ref) v_u_14, (ref) v_u_15, (copy) v_u_42
	local v68 = v_u_4[p66]
	local v69
	if v68 then
		v69 = v_u_6.defs[v68]
	else
		v69 = v68
	end
	if not (v69 and v68) then
		return nil
	end
	local v70 = tonumber(p67)
	if v70 == nil then
		v_u_26[v68] = nil
		return nil
	end
	local v71 = nil
	if v70 >= 1 and (v70 <= #v69.v and v70 == math.floor(v70)) then
		v71 = v70
	else
		for v72, v73 in v69.v do
			if v73.id ~= v70 then
				continue
			end
			v71 = v72
		end
		if not v71 and v70 >= 1000 then
			local v74 = v69.v
			table.insert(v74, {
				["id"] = v70
			})
			v71 = #v69.v
		end
	end
	if not v71 then
		return nil
	end
	v_u_26[v68] = v71
	if not v_u_27 and v_u_7 == p66 then
		local v75 = v_u_2[p66] or 2
		if v_u_11 then
			v_u_11:stop(v75)
			v_u_11 = nil
			v_u_12 = ""
		end
		local v76 = os.clock()
		v_u_14 = p66
		v_u_15 = v76
		if v_u_42(p66, v76) then
			v_u_14 = nil
		end
	end
	return v71
end
function v_u_1.preferred(p77) -- name: preferred
	-- upvalues: (copy) v_u_4, (copy) v_u_26
	local v78 = v_u_4[p77]
	if v78 then
		return v_u_26[v78]
	else
		return nil
	end
end
function v_u_1.audition(p79, p80, p81, p82) -- name: audition
	-- upvalues: (copy) v_u_1, (ref) v_u_27, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_14, (ref) v_u_16
	local v83 = {}
	for _, v84 in p79 do
		for v85 = 1, #v_u_1.candidates(v84) do
			table.insert(v83, {
				["state"] = v84,
				["vi"] = v85
			})
		end
	end
	if #v83 == 0 then
		return 0
	end
	local v86 = v_u_27
	local v87 = {
		["queue"] = nil,
		["i"] = 0,
		["seconds"] = nil,
		["nextAt"] = 0,
		["starting"] = false,
		["resume"] = nil,
		["resumeForced"] = nil,
		["resumeAuto"] = nil,
		["onTrack"] = nil,
		["onDone"] = nil,
		["queue"] = v83,
		["seconds"] = math.max(3, p80)
	}
	local v88
	if v86 then
		v88 = v86.resume
	else
		v88 = v_u_7
	end
	v87.resume = v88
	local v89
	if v86 then
		v89 = v86.resumeForced
	else
		v89 = v_u_8
	end
	v87.resumeForced = v89
	local v90
	if v86 then
		v90 = v86.resumeAuto
	else
		v90 = v_u_10
	end
	v87.resumeAuto = v90
	v87.onTrack = p81
	v87.onDone = p82
	v_u_27 = v87
	v_u_14 = nil
	v_u_16 = 0
	return #v83
end
function v_u_1.stopAudition() -- name: stopAudition
	-- upvalues: (ref) v_u_27, (ref) v_u_11, (ref) v_u_12, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_19, (ref) v_u_20, (copy) v_u_50
	local v91 = v_u_27
	if v91 then
		v_u_27 = nil
		if v_u_11 then
			v_u_11:stop(1.2)
			v_u_11 = nil
			v_u_12 = ""
		end
		v_u_10 = v91.resumeAuto
		v_u_8 = v91.resumeForced
		v_u_9 = (1 / 0)
		v_u_7 = "audition"
		if v_u_10 and not v_u_8 then
			v_u_19 = "calm"
			v_u_20 = os.clock()
			v_u_50("calm")
		else
			v_u_50(v91.resume)
		end
		local v92 = v91.onDone
		if v92 then
			task.spawn(v92)
		end
	end
end
function v_u_1.auditioning() -- name: auditioning
	-- upvalues: (ref) v_u_27
	return v_u_27 ~= nil
end
local function v_u_99(p93) -- name: stepAudition
	-- upvalues: (ref) v_u_27, (copy) v_u_42, (copy) v_u_1, (ref) v_u_11, (ref) v_u_13, (ref) v_u_12, (ref) v_u_15
	local v94 = v_u_27
	if v94 then
		if v94.starting then
			local v95 = v94.queue[v94.i]
			if v_u_42(v95.state, p93, v95.vi, true, 0.8) then
				v94.starting = false
				v94.nextAt = (1 / 0)
				local v96 = v94.onTrack
				local v97 = v_u_1.candidates(v95.state)
				local v98 = v97[v95.vi]
				if v96 then
					task.spawn(v96, v95.state, v95.vi, #v97, not v98 and 0 or v98.id)
				end
			end
		else
			if v94.nextAt == (1 / 0) then
				if v_u_11 and (v_u_11:alive() and v_u_11.voice.sound.IsLoaded) then
					v94.nextAt = p93 + v94.seconds
				elseif not v_u_11 or (not v_u_11:alive() or p93 - v_u_13 > 20) then
					v94.nextAt = p93
				end
			end
			if v94.nextAt <= p93 then
				v94.i = v94.i + 1
				if v94.i > #v94.queue then
					v_u_1.stopAudition()
					return
				end
				if v_u_11 then
					v_u_11:stop(0.8)
					v_u_11 = nil
					v_u_12 = ""
				end
				v_u_15 = p93
				v94.starting = true
			end
		end
	else
		return
	end
end
function v_u_1.threat() -- name: threat
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v_u_1.busCount() -- name: busCount
	-- upvalues: (ref) v_u_5
	return v_u_5 and #v_u_5.groupVoices("Music") or 0
end
local function v_u_104(p100) -- name: autoPick
	-- upvalues: (ref) v_u_20, (ref) v_u_19, (ref) v_u_18
	local v101 = p100 - v_u_20
	local v102 = v_u_19
	local v103
	if v_u_19 == "calm" then
		v103 = v_u_18 >= 0.75 and "chase" or (v_u_18 >= 0.3 and "tension" or v102)
	elseif v_u_19 == "tension" then
		v103 = v_u_18 >= 0.75 and "chase" or (v_u_18 < 0.12 and v101 > 14 and "calm" or v102)
	else
		v103 = v_u_19 == "chase" and (v_u_18 < 0.45 and v101 > 7) and (v_u_18 >= 0.12 and "tension" or "calm") or v102
	end
	if v103 ~= v_u_19 then
		v_u_19 = v103
		v_u_20 = p100
	end
	return v_u_19
end
local function v_u_110() -- name: guardBus
	-- upvalues: (ref) v_u_5, (ref) v_u_11
	local v105 = v_u_5.groupVoices("Music")
	if #v105 ~= 0 then
		local v106
		if v_u_11 and v_u_11:alive() then
			v106 = v_u_11.voice
		else
			v106 = nil
		end
		local v_u_107 = {}
		for _, v108 in v105 do
			if v108 == v106 or v108.stopAfterFade then
				continue
			end
			table.insert(v_u_107, v108)
		end
		if #v_u_107 > 0 then
			v_u_5.stopAll(function(p109)
				-- upvalues: (copy) v_u_107
				return table.find(v_u_107, p109) ~= nil
			end, 0.5)
		end
	end
end
function v_u_1.step(p111) -- name: step
	-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_11, (ref) v_u_23, (ref) v_u_27, (copy) v_u_110, (copy) v_u_99, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_50, (copy) v_u_104, (ref) v_u_14, (ref) v_u_7, (copy) v_u_42, (ref) v_u_13, (ref) v_u_12, (ref) v_u_25, (ref) v_u_16, (copy) v_u_24, (ref) v_u_15, (copy) v_u_2, (copy) v_u_1
	local v112 = os.clock()
	if v_u_21 < 1 and v_u_22 < v112 then
		local v113 = v_u_21 + p111 * 0.6
		v_u_21 = math.min(1, v113)
		if v_u_11 then
			v_u_11:setVolume(v_u_23 * v_u_21, 0.2)
		end
	end
	if v_u_27 then
		v_u_110()
		v_u_99(v112)
	else
		if v_u_8 and v_u_9 < v112 then
			v_u_8 = nil
		end
		if v_u_10 and not v_u_8 then
			v_u_50((v_u_104(v112)))
		end
		v_u_110()
		if v_u_14 then
			if v_u_14 == v_u_7 then
				if v_u_42(v_u_14, v112) then
					v_u_14 = nil
				end
			else
				v_u_14 = nil
			end
		end
		if v_u_11 and (v_u_11:alive() and (not v_u_11.voice.sound.IsLoaded and v112 - v_u_13 > 20)) then
			if v_u_11 then
				v_u_11:stop(0)
				v_u_11 = nil
				v_u_12 = ""
			end
			v_u_25 = v112
			if v_u_7 == "calm" then
				v_u_16 = v112 + 1
			end
		end
		if v_u_7 == "calm" then
			if v_u_11 and not v_u_11:alive() then
				v_u_11 = nil
				v_u_16 = v112 + v_u_24:NextNumber(40, 110)
				return
			end
			if not v_u_11 and (not v_u_14 and (v_u_16 <= v112 and v_u_16 > 0)) then
				v_u_16 = 0
				local v114 = os.clock()
				v_u_14 = "calm"
				v_u_15 = v114
				if v_u_42("calm", v114) then
					v_u_14 = nil
					return
				end
			end
		elseif v_u_7 == "debrief" and (v_u_11 and not v_u_11:alive()) then
			v_u_11 = nil
			if v_u_8 == nil or v_u_8 == "debrief" then
				v_u_8 = "menu"
				v_u_9 = (1 / 0)
				if v_u_7 == "menu" then
					return
				end
				local v115 = v_u_7
				v_u_7 = "menu"
				v_u_14 = nil
				local v116 = v_u_2[v115] or 2
				if v_u_11 then
					v_u_11:stop(v116)
					v_u_11 = nil
					v_u_12 = ""
				end
				v_u_16 = 0
				local v117 = os.clock()
				v_u_14 = "menu"
				v_u_15 = v117
				if v_u_42("menu", v117) then
					v_u_14 = nil
				end
				local v118 = v_u_1.onChanged
				if v118 then
					task.spawn(v118, "menu")
					return
				end
			end
		elseif v_u_7 ~= "silent" and not (v_u_14 or v_u_11 and v_u_11:alive()) and v_u_25 <= v112 then
			v_u_11 = nil
			local v119 = v_u_7
			local v120 = os.clock()
			v_u_14 = v119
			v_u_15 = v120
			if v_u_42(v119, v120) then
				v_u_14 = nil
			end
		end
	end
end
function v_u_1.init(p121, p122) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	v_u_5 = p121
	v_u_6 = p122
end
return v_u_1