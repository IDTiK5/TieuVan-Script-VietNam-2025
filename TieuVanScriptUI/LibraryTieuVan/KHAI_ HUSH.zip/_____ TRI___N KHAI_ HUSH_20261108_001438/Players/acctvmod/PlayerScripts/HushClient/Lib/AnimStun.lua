-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AnimStun

local v_u_30 = {
	["deltas"] = function(p1, p2, p3) -- name: deltas
		local v4 = {}
		if p1 ~= p1 or p1 <= 0 then
			return v4
		end
		local v5 = math.min(1, p1)
		local v6 = CFrame.new(0, p3 * -0.15 * v5, 0)
		local v7 = CFrame.Angles
		local v8 = 3.7699111843077517 * p2
		v4.Root = v6 * v7(0, 0, math.sin(v8) * 0.06 * v5)
		local v9 = CFrame.Angles
		local v10 = 5.026548245743669 * p2
		local v11 = v5 * (math.sin(v10) * 0.05 + 0.28)
		local v12 = 3.7699111843077517 * p2
		v4.Waist = v9(v11, math.sin(v12) * 0.12 * v5, 0)
		local v13 = CFrame.Angles
		local v14 = 6.911503837897546 * p2
		local v15 = v5 * (math.sin(v14) * 0.12 + 0.35)
		local v16 = 4.39822971502571 * p2
		local v17 = math.sin(v16) * 0.25 * v5
		local v18 = 4.39822971502571 * p2
		v4.Neck = v13(v15, v17, math.cos(v18) * 0.18 * v5)
		v4.LeftShoulder = CFrame.Angles(v5 * -0.5, 0, 0)
		v4.RightShoulder = CFrame.Angles(v5 * -0.5, 0, 0)
		v4.LeftHip = CFrame.Angles(v5 * 0.2, 0, 0)
		v4.RightHip = CFrame.Angles(v5 * 0.2, 0, 0)
		v4.LeftKnee = CFrame.Angles(v5 * -0.25, 0, 0)
		v4.RightKnee = CFrame.Angles(v5 * -0.25, 0, 0)
		return v4
	end,
	["overlay"] = function(p19, p20, p21, p22) -- name: overlay
		-- upvalues: (copy) v_u_30
		local v23 = v_u_30.deltas
		local v24
		if type(p19) == "table" then
			local v25 = p19.scale
			v24 = type(v25) ~= "number" and 1 or p19.scale
		else
			v24 = 1
		end
		local v26 = false
		for v27, v28 in v23(p22, p21, v24) do
			if not p20.joints[v27] then
				continue
			end
			p20.T[v27] = p20.T[v27] * v28
			v26 = true
		end
		if v26 then
			for _, v29 in p20.order do
				p20:fk(v29.name)
			end
		end
	end
}
local v_u_31 = {
	["cctx"] = nil,
	["SR"] = nil,
	["SC"] = nil,
	["flagAt"] = -1000000000,
	["flagOn"] = true,
	["off"] = false,
	["seen"] = nil,
	["seen"] = setmetatable({}, {
		["__mode"] = "k"
	})
}
v_u_30._S = v_u_31
function v_u_30.init(p_u_32) -- name: init
	-- upvalues: (copy) v_u_31
	v_u_31.cctx = p_u_32
	local v33, v34, v35 = pcall(function()
		-- upvalues: (copy) p_u_32
		return p_u_32.shared.StunRules, p_u_32.lib.ServerClock
	end)
	local v36 = v_u_31
	if not v33 or type(v34) ~= "table" then
		v34 = nil
	end
	v36.SR = v34
	local v37 = v_u_31
	if v33 and type(v35) == "table" then
		local v38 = v35.now
		if type(v38) ~= "function" then
			v35 = nil
		end
	else
		v35 = nil
	end
	v37.SC = v35
	local v39
	if v_u_31.SR == nil then
		v39 = false
	else
		v39 = v_u_31.SC ~= nil
	end
	return v39
end
function v_u_30.pass(p40, p41, p42) -- name: pass
	-- upvalues: (copy) v_u_31, (copy) v_u_30
	local v43 = v_u_31.SR
	local v44 = p40.model
	if v_u_31.off or (v43 == nil or (v_u_31.SC == nil or v44 == nil)) then
		return
	else
		if p42 - v_u_31.flagAt > 2 then
			v_u_31.flagAt = p42
			local function v45()
				-- upvalues: (ref) v_u_31
				return v_u_31.cctx.config.flag("DjStun")
			end
			local v46, v47 = pcall(v45)
			local v48 = v_u_31
			if v46 then
				v46 = v47 == false
			end
			v48.flagOn = not v46
		end
		local v49 = not v_u_31.flagOn and 0 or v43.remaining(v44:GetAttribute(v43.ATTR), v_u_31.SC.now())
		local v50 = v_u_31.seen[v44]
		if v49 <= 0 then
			v_u_31.seen[v44] = nil
			return
		else
			if v50 == nil or p42 - v50.last > 0.5 then
				v50 = {
					["t0"] = p42,
					["last"] = p42
				}
				v_u_31.seen[v44] = v50
			end
			v50.last = p42
			local v51 = v43.weight(p42 - v50.t0, v49)
			if v51 > 0 then
				local v52 = v_u_30.overlay
				local v53, v54 = pcall(v52, p40, p41, p42, v51)
				if not v53 then
					v_u_31.off = true
					warn("[AnimStun] stun pose failed, switched off:", v54)
				end
			end
		end
	end
end
return v_u_30