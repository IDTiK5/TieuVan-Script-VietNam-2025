-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Controllers / Vision

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Iso"))
local v_u_4 = {
	["name"] = "Vision",
	["order"] = 14
}
local v_u_5 = {
	["Day"] = 70,
	["Dusk"] = 50,
	["Night"] = 30
}
local v_u_6 = {
	["Day"] = 0.5,
	["Dusk"] = 0.6,
	["Night"] = 0.72
}
local v_u_7 = {
	["Clear"] = 1,
	["Rain"] = 0.95,
	["Storm"] = 0.85,
	["Fog"] = 0.72
}
local v_u_8 = nil
local v_u_9 = v1.LocalPlayer
local v_u_10 = {}
local v_u_11 = false
local v_u_12 = "Menu"
local v_u_13 = nil
local v_u_14 = false
local v_u_15 = true
local v_u_16 = true
local v_u_17 = false
local v_u_18 = 50
local v_u_19 = 0.5
local v_u_20 = 0
local v_u_21 = false
local v_u_22 = 0
local v_u_23 = 1
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = 3
local v_u_27 = 0
local v_u_28 = nil
local v_u_29 = {
	[0] = 8,
	[1] = 12,
	[2] = 24,
	[3] = 40
}
local v_u_30 = {
	[0] = 3,
	[1] = 2,
	[2] = 1,
	[3] = 1
}
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = 0
local v_u_34 = 0
local v_u_35 = false
local v_u_36 = false
local v_u_37 = false
local v_u_38 = nil
local v_u_39 = {}
local v_u_40 = nil
local v_u_41 = {
	["acc"] = (1 / 0),
	["root"] = nil,
	["multi"] = false,
	["under"] = false,
	["gate"] = false,
	["eyeY"] = 0,
	["light"] = false
}
local v_u_42 = {
	["on"] = false,
	["cam"] = nil,
	["shown"] = 0,
	["asked"] = 0,
	["cam"] = {
		["x"] = 0,
		["y"] = 0,
		["z"] = 0,
		["lookX"] = 0,
		["lookY"] = 0,
		["lookZ"] = -1,
		["tanHalfV"] = 0.7,
		["aspect"] = 1.78,
		["pad"] = 2,
		["valid"] = false
	}
}
local v_u_43 = {
	["on"] = false,
	["applied"] = false,
	["half"] = 55,
	["mag"] = 1,
	["wid"] = "",
	["mods"] = "",
	["sightMag"] = 1,
	["class"] = ""
}
local function v_u_46(p44) -- name: raidAttr
	-- upvalues: (ref) v_u_13
	local v45 = v_u_13
	if v45 and v45.Parent then
		return v45:GetAttribute(p44)
	else
		return nil
	end
end
local v_u_47 = nil
local function v_u_55() -- name: huntForced
	-- upvalues: (ref) v_u_47, (ref) v_u_8, (ref) v_u_13
	if v_u_47 == nil then
		local function v48()
			-- upvalues: (ref) v_u_8
			return v_u_8.shared.HuntRules
		end
		local v49, v50 = pcall(v48)
		if not v49 or type(v50) ~= "table" then
			v50 = false
		end
		v_u_47 = v50
	end
	if v_u_47 == false or v_u_13 == nil then
		return false
	end
	local v51 = v_u_47.coneForced
	local v52 = v_u_13
	local v53, v54 = pcall(v51, v52)
	if v53 then
		v53 = v54 == true
	end
	return v53
end
local function v_u_66(p56, p57) -- name: detectFlashlight
	-- upvalues: (ref) v_u_8, (copy) v_u_9
	local v58 = v_u_8
	if v58 then
		v58 = v_u_8.controllers.Atmosphere
	end
	if p57 ~= true and (v58 and v58.flashlightOn) then
		local v59 = v58.flashlightOn
		local v60, v61 = pcall(v59)
		if v60 and type(v61) == "boolean" then
			return v61
		end
	end
	for _, v62 in { "Flashlight", "FlashlightOn" } do
		local v63 = p56:GetAttribute(v62)
		if v63 ~= nil then
			return v63 == true
		end
		local v64
		if p57 == true then
			v64 = nil
		else
			v64 = v_u_9:GetAttribute(v62)
		end
		if v64 == nil then
			continue
		end
		return v64 == true
	end
	for _, v65 in p56:GetDescendants() do
		if not v65:IsA("SpotLight") or (not v65.Enabled or v65.Brightness <= 0.05) then
			continue
		end
		return true
	end
	return false
end
local function v_u_79(p67) -- name: facingOf
	-- upvalues: (ref) v_u_8, (copy) v_u_3
	local v68 = v_u_8
	if v68 then
		v68 = v_u_8.controllers.Input
	end
	if v68 and v68.aimPoint then
		local v69 = v68.aimPoint
		local v70, v71 = pcall(v69)
		if v70 and typeof(v71) == "Vector3" then
			local v72 = v71.X - p67.Position.X
			local v73 = v71.Z - p67.Position.Z
			local v74 = Vector3.new(v72, 0, v73)
			if v74.Magnitude > 1.5 then
				return v_u_3.flatAngle(v74)
			end
		end
	end
	local v75 = p67.CFrame.LookVector
	local v76 = v_u_3.flatAngle
	local v77 = v75.X
	local v78 = v75.Z
	return v76((Vector3.new(v77, 0, v78)))
end
local function v_u_90(p80, p81) -- name: facingOfMate
	-- upvalues: (copy) v_u_3
	local v82
	if p81 then
		v82 = p81:GetAttribute("AimYaw")
	else
		v82 = nil
	end
	if type(v82) == "number" and v82 == v82 then
		local v83 = v_u_3.flatAngle
		local v84 = -math.sin(v82)
		local v85 = -math.cos(v82)
		return v83((Vector3.new(v84, 0, v85)))
	end
	local v86 = p80.CFrame.LookVector
	local v87 = v_u_3.flatAngle
	local v88 = v86.X
	local v89 = v86.Z
	return v87((Vector3.new(v88, 0, v89)))
end
local function v_u_107() -- name: drawDebug
	-- upvalues: (copy) v_u_10, (ref) v_u_38, (copy) v_u_39
	local v91 = v_u_10.Poly
	if not v_u_38 or v_u_38.Parent == nil then
		local v92 = Instance.new("Folder")
		v92.Name = "VisionDebug"
		local v93 = workspace:FindFirstChild("HushLocal")
		if not v93 then
			v93 = Instance.new("Folder")
			v93.Name = "HushLocal"
			v93.Parent = workspace
		end
		v92.Parent = v93
		v_u_38 = v92
	end
	local v94 = v91.count / 3
	local v95 = math.ceil(v94)
	for v96 = #v_u_39 + 1, v95 do
		local v97 = Instance.new("Part")
		v97.Name = "Pt"
		v97.Anchored = true
		v97.CanCollide = false
		v97.CanQuery = false
		v97.CanTouch = false
		v97.CastShadow = false
		v97.Material = Enum.Material.Neon
		v97.Color = Color3.fromRGB(232, 163, 61)
		v97.Size = Vector3.new(0.35, 0.35, 0.35)
		v97.Parent = v_u_38
		v_u_39[v96] = v97
	end
	local v98 = v91.center
	for v99, v100 in v_u_39 do
		local v101 = (v99 - 1) * 3 + 1
		if v101 <= v91.count then
			local v102 = v91.ptA[v101]
			local v103 = v91.ptR[v101]
			local v104 = v98.X + math.cos(v102) * v103
			local v105 = v98.Y
			local v106 = v98.Z + math.sin(v102) * v103
			v100.Position = Vector3.new(v104, v105, v106)
			v100.Transparency = 0
		else
			v100.Transparency = 1
		end
	end
end
local function v_u_110() -- name: awarenessNow
	-- upvalues: (ref) v_u_13, (copy) v_u_10
	local v108 = v_u_13
	local v109
	if v108 and v108.Parent then
		v109 = v108:GetAttribute("PvpAwareness")
	else
		v109 = nil
	end
	if v_u_10.Rules then
		return v_u_10.Rules.awareness(v109)
	else
		return (type(v109) ~= "number" or v109 <= 0) and 4 or v109
	end
end
local function v_u_128(p111) -- name: scopeWeapon
	-- upvalues: (copy) v_u_43, (ref) v_u_8
	local v112 = p111:GetAttribute("Weapon")
	local v113 = p111:GetAttribute("WeaponMods")
	local v_u_114 = type(v112) ~= "string" and "" or v112
	local v_u_115 = type(v113) ~= "string" and "" or v113
	if v_u_43.wid ~= v_u_114 or v_u_43.mods ~= v_u_115 then
		local v116 = v_u_43
		v_u_43.wid = v_u_114
		v116.mods = v_u_115
		local v117 = v_u_43
		v_u_43.sightMag = 1
		v117.class = ""
		local function v127()
			-- upvalues: (copy) v_u_114, (ref) v_u_8, (copy) v_u_115, (ref) v_u_43
			local v118
			if v_u_114 == "" then
				v118 = nil
			else
				v118 = v_u_8.shared.Weapons.get(v_u_114)
			end
			if v118 then
				local v119
				if v_u_115 == "" then
					v119 = nil
				else
					v119 = string.split(v_u_115, ",")
				end
				local v120 = v_u_8.shared.Sights
				local v121 = v120.get(v120.of(v_u_114, v119, v118))
				local v122 = v_u_43
				local v123
				if v121 then
					local v124 = v121.mag
					v123 = type(v124) ~= "number" and 1 or v121.mag
				else
					v123 = 1
				end
				v122.sightMag = v123
				local v125 = v_u_43
				local v126 = v118.class
				v125.class = type(v126) ~= "string" and "" or v118.class
			end
		end
		pcall(v127)
	end
	return v_u_43.sightMag, v_u_43.class
end
local function v_u_132() -- name: resetScope
	-- upvalues: (copy) v_u_43, (copy) v_u_10, (ref) v_u_8
	if v_u_43.applied or v_u_43.half ~= 55 then
		v_u_43.applied = false
		v_u_43.on = false
		v_u_43.half = 55
		v_u_43.mag = 1
		if v_u_10.Poly then
			local v129 = v_u_10.Poly.setHalfAngle
			local v130 = v_u_43.half
			v129((math.rad(v130)))
		end
		local v131 = v_u_8
		if v131 then
			v131 = v_u_8.controllers.Camera
		end
		if v131 and v131.setScopeView then
			v131.setScopeView(nil, nil)
		end
	end
end
local function v_u_150() -- name: fpCamera
	-- upvalues: (copy) v_u_42
	local v133 = workspace.CurrentCamera
	if v133 then
		local v134 = v_u_42.cam
		local v135 = v133.CFrame
		local v136 = v135.Position
		local v137 = v135.LookVector
		local v138 = v136.X
		local v139 = v136.Y
		local v140 = v136.Z
		v134.x = v138
		v134.y = v139
		v134.z = v140
		local v141 = v137.X
		local v142 = v137.Y
		local v143 = v137.Z
		v134.lookX = v141
		v134.lookY = v142
		v134.lookZ = v143
		local v144 = v133.FieldOfView
		local v145 = math.max(v144, 60)
		local v146 = math.rad(v145) * 0.5
		v134.tanHalfV = math.tan(v146)
		local v147 = v133.ViewportSize
		local v148
		if v147.Y > 0 then
			local v149 = v147.X / v147.Y
			v148 = math.clamp(v149, 0.5, 4)
		else
			v148 = 1.78
		end
		v134.aspect = v148
		v134.valid = true
	else
		v_u_42.cam.valid = false
	end
end
function v_u_4.visibility(p151) -- name: visibility
	-- upvalues: (copy) v_u_42, (copy) v_u_41, (ref) v_u_36, (copy) v_u_10
	if v_u_42.on then
		return 1
	end
	if v_u_41.gate and typeof(p151) == "Vector3" then
		local v152 = p151.Y - v_u_41.eyeY
		if v152 > 14 or v_u_36 and v152 < -14 then
			return 0
		end
	end
	local v153 = v_u_10.Poly
	return (not v_u_36 or (not v153 or typeof(p151) ~= "Vector3")) and 1 or v153.visibility(p151, 2.5)
end
function v_u_4.zombieVisibility(p154) -- name: zombieVisibility
	-- upvalues: (copy) v_u_42, (copy) v_u_10, (copy) v_u_46, (copy) v_u_4, (copy) v_u_41, (ref) v_u_36
	if not v_u_42.on then
		local v155
		if v_u_10.Rules == nil then
			v155 = false
		else
			v155 = v_u_10.Rules.zombiesAlways(v_u_46("PvpZombiesAlways")) or false
		end
		if not v155 then
			return v_u_4.visibility(p154)
		end
		local v156
		if v_u_41.gate and typeof(p154) == "Vector3" then
			local v157 = p154.Y - v_u_41.eyeY
			v156 = v157 <= 14 and v_u_36
			if v156 then
				v156 = v157 < -14
			end
		else
			v156 = false
		end
		return v_u_10.Rules.zombieVisibility(1, v156, true)
	end
	local v158 = v_u_10.ViewVis
	local v159 = v_u_42.cam
	if v158 == nil or (not v159.valid or typeof(p154) ~= "Vector3") then
		return 1
	end
	local v160 = v158.zombie(p154.X, p154.Y, p154.Z, v159)
	local v161 = v_u_42
	v161.asked = v161.asked + 1
	if v160 > 0 then
		local v162 = v_u_42
		v162.shown = v162.shown + 1
	end
	return v160
end
function v_u_4.isVisible(p163) -- name: isVisible
	-- upvalues: (copy) v_u_4
	return v_u_4.visibility(p163) >= 0.5
end
function v_u_4.isInside() -- name: isInside
	-- upvalues: (copy) v_u_10
	if v_u_10.Cut then
		return v_u_10.Cut.inside()
	else
		return nil
	end
end
function v_u_4.range() -- name: range
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v_u_4.facing() -- name: facing
	-- upvalues: (copy) v_u_10
	return not v_u_10.Poly and 0 or v_u_10.Poly.facing
end
function v_u_4.setEnabled(p164) -- name: setEnabled
	-- upvalues: (ref) v_u_15, (copy) v_u_10
	v_u_15 = p164
	if v_u_10.Mesh then
		v_u_10.Mesh.setVisible(p164)
	end
end
local function v_u_166() -- name: teardownRaid
	-- upvalues: (ref) v_u_36, (copy) v_u_132, (ref) v_u_13, (copy) v_u_10, (ref) v_u_11, (copy) v_u_41, (copy) v_u_39, (ref) v_u_38, (ref) v_u_21
	v_u_36 = false
	v_u_132()
	v_u_13 = nil
	if v_u_10.Mesh then
		v_u_10.Mesh.destroy()
	end
	if v_u_10.Poly then
		v_u_10.Poly.invalidate()
	end
	if v_u_10.Actors then
		v_u_10.Actors.reset()
	end
	if v_u_10.Reveal then
		v_u_10.Reveal.reset()
		v_u_11 = false
	end
	if v_u_10.Cut then
		v_u_10.Cut.setReveal(nil)
		v_u_10.Cut.setLevels(nil)
		v_u_10.Cut.setUnder(false)
		v_u_10.Cut.setTokyo(nil, false)
		v_u_10.Reveal.setSameFloor(false)
	end
	v_u_41.root = nil
	v_u_41.multi = false
	v_u_41.under = false
	v_u_41.gate = false
	v_u_41.acc = (1 / 0)
	for _, v165 in v_u_39 do
		v165:Destroy()
	end
	table.clear(v_u_39)
	if v_u_38 then
		v_u_38:Destroy()
		v_u_38 = nil
	end
	v_u_21 = false
end
local function v_u_192(p167) -- name: checkLevels
	-- upvalues: (ref) v_u_12, (ref) v_u_8, (copy) v_u_41, (copy) v_u_10
	local v_u_168 = nil
	if v_u_12 == "Raid" then
		local function v169()
			-- upvalues: (ref) v_u_168, (ref) v_u_8
			v_u_168 = v_u_8.shared.MapInfo.fromRuntime()
		end
		pcall(v169)
	end
	if p167 then
		local v170 = v_u_41
		local v171
		if type(v_u_168) == "table" then
			v171 = v_u_168.underground == true
		else
			v171 = false
		end
		v170.under = v171
		v_u_10.Cut.setUnder(false)
		v_u_10.Cut.setTokyo(nil, false)
		v_u_10.Reveal.setSameFloor(false)
		local v172 = v_u_41.under
		if v_u_41.light ~= v172 then
			v_u_41.light = v172
			local v173 = v_u_8
			if v173 then
				v173 = v_u_8.controllers.Input
			end
			if v173 and v173.setTouchLightMain then
				local v174 = v173.setTouchLightMain
				pcall(v174, v172)
			end
		end
	else
		local v175
		if type(v_u_168) == "table" then
			local v176 = v_u_168.levels
			if type(v176) == "table" then
				v175 = #v_u_168.levels > 1
			else
				v175 = false
			end
		else
			v175 = false
		end
		local v177
		if v175 then
			v177 = workspace:FindFirstChild("Raid")
		else
			v177 = nil
		end
		local v178 = v_u_41
		if v175 then
			v175 = v177 ~= nil
		end
		v178.multi = v175
		local v179 = v_u_41
		local v180
		if type(v_u_168) == "table" then
			v180 = v_u_168.underground == true
		else
			v180 = false
		end
		v179.under = v180
		local v181 = v_u_10.Cut.setUnder
		local v182
		if type(v_u_168) == "table" then
			v182 = v_u_168.id
		else
			v182 = nil
		end
		v181(v182)
		local v183
		if type(v_u_168) == "table" then
			local v184 = v_u_8.config.flag
			local v185, v186 = pcall(v184, "TokyoCutV2")
			if v185 and v186 == false then
				v183 = false
			else
				v183 = v_u_10.Cut.v2Map(v_u_168.id)
			end
		else
			v183 = false
		end
		local v187 = v_u_10.Cut.setTokyo
		local v188
		if type(v_u_168) == "table" then
			v188 = v_u_168.id
		else
			v188 = nil
		end
		v187(v188, v183)
		v_u_10.Reveal.setSameFloor(v183)
		if v_u_41.root ~= v177 then
			v_u_41.root = v177
			v_u_10.Cut.setLevels(v177)
		end
		local v189 = v_u_41.under
		if v_u_41.light ~= v189 then
			v_u_41.light = v189
			local v190 = v_u_8
			if v190 then
				v190 = v_u_8.controllers.Input
			end
			if v190 and v190.setTouchLightMain then
				local v191 = v190.setTouchLightMain
				pcall(v191, v189)
			end
		end
	end
end
local function v_u_195(p193) -- name: onPlace
	-- upvalues: (ref) v_u_12, (copy) v_u_166, (copy) v_u_10, (ref) v_u_8, (ref) v_u_13
	v_u_12 = p193
	if p193 ~= "Raid" then
		v_u_166()
	end
	if p193 ~= "Raid" and (p193 ~= "Hideout" and v_u_10.Cut) then
		v_u_10.Cut.reset()
	end
	if p193 == "Raid" then
		task.spawn(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_12, (ref) v_u_13
			local v194 = v_u_8.session.waitForRaid(90)
			if v_u_12 == "Raid" then
				v_u_13 = v194
			end
		end)
	end
end
function v_u_4.init(p_u_196) -- name: init
	-- upvalues: (ref) v_u_8, (copy) v_u_10, (ref) v_u_40, (ref) v_u_17, (copy) v_u_39, (ref) v_u_38, (ref) v_u_12, (ref) v_u_16, (ref) v_u_36, (ref) v_u_18, (ref) v_u_19, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (ref) v_u_28, (ref) v_u_23, (ref) v_u_35, (ref) v_u_11, (copy) v_u_46, (copy) v_u_43, (copy) v_u_9, (copy) v_u_4, (ref) v_u_27, (copy) v_u_41, (copy) v_u_42, (ref) v_u_37, (ref) v_u_15
	v_u_8 = p_u_196
	local function v197()
		-- upvalues: (ref) v_u_10, (copy) p_u_196
		v_u_10.Index = p_u_196.lib.VisionIndex
		v_u_10.Poly = p_u_196.lib.VisionPoly
		v_u_10.Mesh = p_u_196.lib.VisionMesh
		v_u_10.Cut = p_u_196.lib.VisionCut
		v_u_10.Actors = p_u_196.lib.VisionActors
		v_u_10.Reveal = p_u_196.lib.ZombieReveal
	end
	local v198, v199 = pcall(v197)
	local function v200()
		-- upvalues: (ref) v_u_10, (copy) p_u_196
		v_u_10.Rules = p_u_196.lib.VisionRules
	end
	pcall(v200)
	local function v201()
		-- upvalues: (ref) v_u_10, (copy) p_u_196
		v_u_10.ViewVis = p_u_196.lib.ViewVis
	end
	pcall(v201)
	local function v202()
		-- upvalues: (ref) v_u_10, (copy) p_u_196
		v_u_10.Scope = p_u_196.lib.ScopeCone
	end
	pcall(v202)
	local function v203()
		-- upvalues: (ref) v_u_10, (copy) p_u_196
		v_u_10.ObsCone = p_u_196.lib.ReviewVisionCone
		v_u_10.ObsCone.init(p_u_196)
	end
	pcall(v203)
	if not v198 then
		v_u_40 = tostring(v199)
		error(v199)
	end
	p_u_196.command("vision.debug", function(p204)
		-- upvalues: (ref) v_u_17, (ref) v_u_39, (ref) v_u_38, (ref) v_u_10
		v_u_17 = p204[1] == "1"
		if not v_u_17 then
			for _, v205 in v_u_39 do
				v205:Destroy()
			end
			table.clear(v_u_39)
			if v_u_38 then
				v_u_38:Destroy()
				v_u_38 = nil
			end
		end
		return "vision debug " .. (v_u_17 and "on" or "off") .. " | " .. v_u_10.Index.stats()
	end)
	p_u_196.command("vision.info", function()
		-- upvalues: (ref) v_u_10, (ref) v_u_12, (ref) v_u_16, (ref) v_u_36, (ref) v_u_18, (ref) v_u_19, (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (ref) v_u_28, (ref) v_u_23, (ref) v_u_35, (ref) v_u_11, (ref) v_u_46, (ref) v_u_43
		local v206 = v_u_10.Poly
		local v207 = v_u_10.Cut.stats()
		local v208 = string.format
		local v209 = v_u_12
		local v210 = v_u_16
		local v211 = tostring(v210)
		local v212 = v_u_36
		local v213 = tostring(v212)
		local v214 = v_u_18
		local v215 = v_u_19
		local v216 = v_u_10.Cut.inside
		local v217 = tostring(v216())
		local v218 = v_u_10.Cut.peeking
		local v219 = tostring(v218())
		local v220 = v206.rays
		local v221 = v206.count
		local v222 = v206.cornerUsed or 0
		local v223 = v206.cornerUseful or 0
		local v224 = v206.cornerCands or 0
		local v225 = v206.behindCast
		local v226 = tostring(v225)
		local v227 = v_u_24
		local v228 = v_u_25
		local v229 = v_u_26
		local v230 = v_u_28 and "(pinned)" or ""
		local v231 = v_u_23
		local v232 = v207.cut
		local v233 = v207.faded
		local v234 = v207.loose or 0
		local v235 = v_u_10.Mesh.exists
		local v236 = tostring(v235())
		local v237 = v_u_10.Mesh.failed() or ""
		local v238 = v_u_35
		local v239 = v208("place=%s cone=%s active=%s range=%.1f dark=%.2f inside=%s peek=%s rays=%d pts=%d corners=%d/%d/%d behind=%s polyMs=%.2f (compute %.2f) q=%d%s every=%d cut=%d faded=%d loose=%d shroud=%s %s mates=%d flash=%s", v209, v211, v213, v214, v215, v217, v219, v220, v221, v222, v223, v224, v226, v227, v228, v229, v230, v231, v232, v233, v234, v236, tostring(v237), v_u_10.Actors.highlightCount(), (tostring(v238)))
		local v240 = v_u_11
		local v241 = string.format(" | reveal on=%s targets=%d covered=%d outlines=%d faded=%d", tostring(v240), v_u_10.Reveal.stats().targets, v_u_10.Reveal.stats().covered, v_u_10.Reveal.stats().silhouettes, v207.revealed or 0)
		local v242 = string.format
		local v243 = v_u_46
		local v244 = tostring(v243("PvpScope"))
		local v245 = v_u_43.on
		local v246 = tostring(v245)
		local v247 = v_u_43.applied
		return v239 .. v241 .. v242(" | scope attr=%s on=%s applied=%s mag=%.1f half=%.1f", v244, v246, tostring(v247), v_u_43.mag, v_u_43.half) .. " | " .. v_u_10.Index.stats()
	end)
	p_u_196.command("vision.at", function(p248)
		-- upvalues: (ref) v_u_9, (ref) v_u_4
		local v249 = p248[1]
		local v250 = tonumber(v249)
		local v251 = p248[2]
		local v252 = tonumber(v251)
		if not (v250 and v252) then
			return "usage: vision.at <x> <z>"
		end
		local v253 = v_u_9.Character
		local v254
		if v253 then
			v254 = v253:FindFirstChild("HumanoidRootPart")
			v253:FindFirstChildOfClass("Humanoid")
		else
			v254 = nil
		end
		local v255 = not v254 and 3 or v254.Position.Y
		return string.format("visibility=%.2f", v_u_4.visibility((Vector3.new(v250, v255, v252))))
	end)
	p_u_196.command("vision.quality", function(p256)
		-- upvalues: (ref) v_u_28, (ref) v_u_26, (ref) v_u_27
		local v257 = p256[1]
		local v258 = tonumber(v257)
		if v258 then
			local v259 = math.floor(v258)
			v_u_28 = math.clamp(v259, 0, 3)
			v_u_26 = v_u_28
		else
			if p256[1] ~= "auto" then
				return "usage: vision.quality <0-3|auto>"
			end
			v_u_28 = nil
			v_u_27 = os.clock()
		end
		return string.format("quality %d %s", v_u_26, v_u_28 and "pinned" or "auto")
	end)
	p_u_196.command("vision.level", function(p260)
		-- upvalues: (ref) v_u_10, (ref) v_u_41, (ref) v_u_18, (ref) v_u_4
		local v261 = v_u_10.Cut.levelStats()
		local v262 = string.format
		local v263 = v_u_41.multi
		local v264 = tostring(v263)
		local v265 = v_u_41.under
		local v266 = tostring(v265)
		local v267 = v_u_41.gate
		local v268 = tostring(v267)
		local v269 = v261.active
		local v270 = tostring(v269)
		local v271 = v261.level
		local v272 = v261.registered
		local v273 = v261.hidden
		local v274 = v261.byHeight
		local v275 = v261.unbanded
		local v276 = v261.roofs
		local v277 = v261.pending
		local v278 = v261.changes
		local v279 = v261.lastMs
		local v280 = v261.maxMs
		local v281 = v_u_18
		local v282 = v_u_41.light
		local v283 = v262("multi=%s under=%s gate=%s active=%s level=L%d registered=%d hidden=%d byHeight=%d unbanded=%d roofs=%d pending=%d changes=%d lastMs=%.2f maxMs=%.2f range=%.1f light=%s", v264, v266, v268, v270, v271, v272, v273, v274, v275, v276, v277, v278, v279, v280, v281, (tostring(v282)))
		if p260[1] == "vis" then
			local v284 = p260[2]
			local v285 = tonumber(v284)
			local v286 = p260[3]
			local v287 = tonumber(v286)
			local v288 = p260[4]
			local v289 = tonumber(v288)
			if v285 and (v287 and v289) then
				v283 = v283 .. string.format(" | eyeY=%.1f visibility=%.2f", v_u_41.eyeY, v_u_4.visibility((Vector3.new(v285, v287, v289))))
			end
		end
		if p260[1] == "check" and p260[2] then
			local v290 = game
			for v291 in string.gmatch(p260[2], "[^%.]+") do
				if not v290 then
					continue
				end
				v290 = v290:FindFirstChild(v291)
			end
			local v292 = " | "
			local v293
			if v290 then
				local v294 = v290:GetFullName()
				local v295 = v_u_10.Cut.levelHidden
				local v296 = tostring(v295(v290))
				local v297 = not v290:IsA("BasePart") and "-" or v290.LocalTransparencyModifier
				v293 = v294 .. " hidden=" .. v296 .. " ltm=" .. tostring(v297)
			else
				v293 = "not found"
			end
			v283 = v283 .. v292 .. v293
		end
		return v283
	end)
	p_u_196.command("vision.fp", function(p298)
		-- upvalues: (ref) v_u_42, (ref) v_u_36, (ref) v_u_37, (ref) v_u_41, (ref) v_u_4
		local v299 = v_u_42.cam
		local v300 = string.format
		local v301 = v_u_42.on
		local v302 = tostring(v301)
		local v303 = v_u_36
		local v304 = tostring(v303)
		local v305 = v_u_37
		local v306 = tostring(v305)
		local v307 = v_u_41.gate
		local v308 = tostring(v307)
		local v309 = v299.valid
		local v310 = v300("fp=%s cone=%s cut=%s gate=%s camValid=%s look=(%.2f,%.2f,%.2f) tanHalfV=%.3f aspect=%.2f asked=%d shown=%d", v302, v304, v306, v308, tostring(v309), v299.lookX, v299.lookY, v299.lookZ, v299.tanHalfV, v299.aspect, v_u_42.asked, v_u_42.shown)
		if p298[1] == "at" then
			local v311 = p298[2]
			local v312 = tonumber(v311)
			local v313 = p298[3]
			local v314 = tonumber(v313)
			local v315 = p298[4]
			local v316 = tonumber(v315)
			if v312 and (v314 and v316) then
				v310 = v310 .. string.format(" | zombie=%.2f visibility=%.2f", v_u_4.zombieVisibility((Vector3.new(v312, v314, v316))), v_u_4.visibility((Vector3.new(v312, v314, v316))))
			end
		end
		return v310
	end)
	p_u_196.command("vision.enable", function(p317)
		-- upvalues: (ref) v_u_4, (ref) v_u_15
		v_u_4.setEnabled(p317[1] ~= "0")
		local v318 = v_u_15
		return "enabled " .. tostring(v318)
	end)
end
function v_u_4.start() -- name: start
	-- upvalues: (copy) v_u_10, (ref) v_u_8, (ref) v_u_16, (copy) v_u_9, (copy) v_u_195
	v_u_10.Index.start()
	task.spawn(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_16, (ref) v_u_9
		local v319 = v_u_8.config
		if v319 and v319.watchFlag then
			v319.watchFlag("VisionCone", function(p320)
				-- upvalues: (ref) v_u_16, (ref) v_u_9
				v_u_16 = p320 ~= false
				v_u_9:SetAttribute("VisCone", v_u_16)
			end)
		end
	end)
	v_u_8.session.onPlaceChanged(function(p321)
		-- upvalues: (ref) v_u_195
		v_u_195(p321)
	end)
end
function v_u_4.step(p322) -- name: step
	-- upvalues: (copy) v_u_9, (ref) v_u_8, (ref) v_u_37, (ref) v_u_12, (ref) v_u_15, (ref) v_u_13, (copy) v_u_10, (ref) v_u_16, (copy) v_u_55, (ref) v_u_14, (copy) v_u_166, (ref) v_u_36, (copy) v_u_42, (copy) v_u_41, (copy) v_u_150, (copy) v_u_192, (ref) v_u_32, (copy) v_u_79, (copy) v_u_3, (ref) v_u_11, (ref) v_u_34, (ref) v_u_35, (copy) v_u_66, (copy) v_u_5, (copy) v_u_7, (copy) v_u_43, (copy) v_u_128, (copy) v_u_132, (ref) v_u_18, (copy) v_u_6, (ref) v_u_19, (ref) v_u_22, (ref) v_u_23, (copy) v_u_90, (copy) v_u_110, (ref) v_u_25, (ref) v_u_21, (ref) v_u_20, (ref) v_u_24, (ref) v_u_28, (ref) v_u_26, (ref) v_u_27, (copy) v_u_29, (copy) v_u_30, (ref) v_u_17, (copy) v_u_107, (ref) v_u_31, (copy) v_u_4, (ref) v_u_33, (ref) v_u_40
	local v323 = v_u_9.Character
	local v324, v325
	if v323 then
		v324 = v323:FindFirstChild("HumanoidRootPart")
		v325 = v323:FindFirstChildOfClass("Humanoid")
	else
		v323 = nil
		v324 = nil
		v325 = nil
	end
	local v326 = v_u_8.controllers.Camera
	local v327 = not (v326 and v326.mode) and "iso" or v326.mode()
	local v328
	if v_u_12 == "Raid" or v_u_12 == "Hideout" then
		v328 = v327 ~= "scripted"
	else
		v328 = false
	end
	v_u_37 = v328
	local v329
	if v323 == nil then
		v329 = false
	else
		v329 = v323:GetAttribute("Dead") == true
	end
	local v330 = nil
	local v331 = nil
	local v332
	if v327 == "spectate" and (v_u_15 and v_u_12 == "Raid") then
		local v333 = v_u_13
		local v334
		if v333 and v333.Parent then
			v334 = v333:GetAttribute("PvpCone")
		else
			v334 = nil
		end
		if v334 == true then
			if v326 and v326.subject then
				v332 = v326.subject()
			else
				v332 = nil
			end
			if v332 == nil or (v332.Parent == nil or v323 ~= nil and v332:IsDescendantOf(v323)) then
				v332 = v330
			else
				v331 = v332.Parent
				if v331 == nil or (not v331:IsA("Model") or v331 == workspace) then
					v331 = nil
				end
			end
		else
			v332 = v330
		end
	else
		v332 = v330
	end
	local v335, v336, v337, v338, v339, v340, v341, v342, v343, v344, v345, v346, v347, v348, v349, v350, v351, v352, v353, v354, v355, v356, v357, v358, v359, v360, v361, v362, v363, v364, v365, v366, v367, v368, v369, v370, v371, v372, v373, v374, v375, v376, v377, v378, v379, v380, v381, v382, v383, v384, v385, v386, v387, v388, v389, v390, v391, v392, v393, v394, v395, v396, v397, v398, v399, v400, v401, v402, v403, v404, v405, v406, v407, v408, v409, v410, v411, v412, v413, v414, v415, v416, v417, v418, v419, v420, v421, v422, v423, v424, v425, v426, v427, v428, v429, v430, v431, v432, v433, v434, v435, v436, v437, v438, v439, v440, v441, v442, v443, v444, v445, v446, v447, v448, v449, v450, v451, v452, v453, v454, v455, v456, v457, v458, v459, v460, v461, v462, v463, v464, v465, v466, v467, v468, v469, v470, v471, v472, v473, v474, v475, v476, v477, v478, v479, v480, v481, v482, v483, v484, v485, v486, v487
	if v332 ~= nil or v_u_10.ObsCone == nil then
		v488 = nil
		if v488 == nil then
			if v_u_14 then
				v_u_14 = false
				v_u_166()
			end
		else
			v_u_14 = true
		end
		v335 = v332 ~= nil
		if v332 == nil then
			v336 = v324
		else
			v336 = v332
		end
		if v332 == nil then
			v337 = v323
		else
			v337 = v331
		end
		if v332 ~= nil then
			if v331 == nil then
				v325 = nil
			else
				v325 = v331:FindFirstChildOfClass("Humanoid")
			end
		end
		v338 = v_u_15
		if v338 then
			if v_u_16 or v_u_55() then
				if v_u_12 == "Raid" then
					v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
				else
					v338 = false
				end
			else
				v338 = false
				v339 = v_u_13
				if v339 and v339.Parent then
					v340 = v339:GetAttribute("PvpCone")
				else
					v340 = nil
				end
				if v340 == true then
					if v_u_12 == "Raid" then
						v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
					else
						v338 = false
					end
				end
			end
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		else
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		end
	end
	local v488 = v_u_10.ObsCone.source(v_u_15)
	if v488 == nil then
		if v488 == nil then
			if v_u_14 then
				v_u_14 = false
				v_u_166()
			end
		else
			v_u_14 = true
		end
		v335 = v332 ~= nil
		if v332 == nil then
			v336 = v324
		else
			v336 = v332
		end
		if v332 == nil then
			v337 = v323
		else
			v337 = v331
		end
		if v332 ~= nil then
			if v331 == nil then
				v325 = nil
			else
				v325 = v331:FindFirstChildOfClass("Humanoid")
			end
		end
		v338 = v_u_15
		if v338 then
			if v_u_16 or v_u_55() then
				if v_u_12 == "Raid" then
					v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
				else
					v338 = false
				end
			else
				v338 = false
				v339 = v_u_13
				if v339 and v339.Parent then
					v340 = v339:GetAttribute("PvpCone")
				else
					v340 = nil
				end
				if v340 == true then
					if v_u_12 == "Raid" then
						v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
					else
						v338 = false
					end
				end
			end
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		else
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		end
	end
	local v489 = v_u_13
	v_u_13 = v488.folder
	if v_u_16 or v_u_55() then
		v332 = v488.root
		v331 = v488.char
		if v488 == nil then
			if v_u_14 then
				v_u_14 = false
				v_u_166()
			end
		else
			v_u_14 = true
		end
		v335 = v332 ~= nil
		if v332 == nil then
			v336 = v324
		else
			v336 = v332
		end
		if v332 == nil then
			v337 = v323
		else
			v337 = v331
		end
		if v332 ~= nil then
			if v331 == nil then
				v325 = nil
			else
				v325 = v331:FindFirstChildOfClass("Humanoid")
			end
		end
		v338 = v_u_15
		if v338 then
			if v_u_16 or v_u_55() then
				if v_u_12 == "Raid" then
					v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
				else
					v338 = false
				end
			else
				v338 = false
				v339 = v_u_13
				if v339 and v339.Parent then
					v340 = v339:GetAttribute("PvpCone")
				else
					v340 = nil
				end
				if v340 == true then
					if v_u_12 == "Raid" then
						v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
					else
						v338 = false
					end
				end
			end
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		else
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		end
	else
		local v490 = v_u_13
		local v491
		if v490 and v490.Parent then
			v491 = v490:GetAttribute("PvpCone")
		else
			v491 = nil
		end
		if v491 ~= true then
			v488 = nil
			v_u_13 = v489
			if v488 == nil then
				if v_u_14 then
					v_u_14 = false
					v_u_166()
				end
			else
				v_u_14 = true
			end
			v335 = v332 ~= nil
			if v332 == nil then
				v336 = v324
			else
				v336 = v332
			end
			if v332 == nil then
				v337 = v323
			else
				v337 = v331
			end
			if v332 ~= nil then
				if v331 == nil then
					v325 = nil
				else
					v325 = v331:FindFirstChildOfClass("Humanoid")
				end
			end
			v338 = v_u_15
			if v338 then
				if v_u_16 or v_u_55() then
					if v_u_12 == "Raid" then
						v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
					else
						v338 = false
					end
				else
					v338 = false
					v339 = v_u_13
					if v339 and v339.Parent then
						v340 = v339:GetAttribute("PvpCone")
					else
						v340 = nil
					end
					if v340 == true then
						if v_u_12 == "Raid" then
							v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
						else
							v338 = false
						end
					end
				end
				v_u_36 = v338
				if v488 ~= nil then
					v_u_36 = true
				end
				v341 = v_u_8
				if v341 then
					v341 = v_u_8.controllers.FpView
				end
				if v341 and v341.viewOn then
					v342 = v341.viewOn
					v343, v344 = pcall(v342)
					if v343 then
						v343 = v344 == true
					end
				else
					v343 = false
				end
				if v343 then
					v_u_36 = false
					v_u_37 = false
					if not v_u_42.on then
						v_u_42.on = true
						v345 = v_u_42
						v_u_42.asked = 0
						v345.shown = 0
						if v_u_10.Cut then
							v_u_10.Cut.reset()
							v_u_10.Cut.setLevels(nil)
							v_u_10.Cut.setUnder(false)
							v_u_10.Cut.setTokyo(nil, false)
							v_u_10.Reveal.setSameFloor(false)
						end
						v_u_41.root = nil
						v_u_41.multi = false
						v_u_41.gate = false
					end
					v_u_150()
				elseif v_u_42.on then
					v_u_42.on = false
					v_u_42.cam.valid = false
					v_u_41.acc = (1 / 0)
				end
				v346 = v_u_41
				v346.acc = v346.acc + p322
				if v_u_41.acc >= 1 then
					v_u_41.acc = 0
					v_u_192(v_u_42.on)
				end
				if v326 and v326.subject then
					v347 = v326.subject()
				else
					v347 = v324
				end
				v348 = v_u_41
				v349 = not v_u_42.on and v_u_41.multi
				if v349 then
					if v_u_12 == "Raid" and v347 ~= nil then
						v349 = v347.Parent ~= nil
					else
						v349 = false
					end
				end
				v348.gate = v349
				if v_u_41.gate and v347 then
					v_u_41.eyeY = v347.Position.Y + 1.5
				end
				v_u_32 = v_u_32 + p322
				if v_u_32 > 30 then
					v_u_32 = 0
					v_u_10.Index.purge()
				end
				v350 = workspace.CurrentCamera
				if v_u_37 and v350 then
					if v326 and v326.subject then
						v351 = v326.subject()
					else
						v351 = v324
					end
					if v_u_12 == "Hideout" then
						v352 = {}
						if v323 then
							table.insert(v352, v323)
						end
						if v351 then
							v353 = v351.Parent
						else
							v353 = v351
						end
						if v353 and (v353 ~= v323 and v353 ~= workspace) then
							table.insert(v352, v353)
						end
						v354 = v_u_10.Cut.setLoose
						v355 = workspace:FindFirstChild("HushLocal")
						if v355 then
							v356 = v355:FindFirstChild("Hideout") or v355
						else
							v356 = workspace
						end
						v354(v356, v352)
					else
						v_u_10.Cut.setLoose(nil)
					end
					v357 = v_u_10.Cut.setFacing
					if v_u_12 == "Raid" and (v324 and not v329) then
						v358 = v_u_79(v324)
					else
						v358 = nil
					end
					v357(v358)
					if v326 and v326.yaw then
						v359 = v326.yaw()
					else
						v359 = v_u_3.BASE_YAW
					end
					v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
					v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
					if v361 then
						v361 = v327 == "iso"
					end
					if v361 and v324 then
						v362 = v324.Position
					else
						v362 = nil
					end
					if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
						v362 = v351.Position
					end
					if v362 then
						v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
						v_u_10.Cut.setReveal(v_u_10.Reveal.points)
						v_u_11 = true
					elseif v_u_11 then
						v_u_10.Reveal.reset()
						v_u_10.Cut.setReveal(nil)
						v_u_11 = false
					end
					v363 = v_u_10.Cut.update
					if v351 and v351.Parent then
						v364 = v351.Position
					else
						v364 = nil
					end
					v363(p322, v364, v350.CFrame.Position, v359, v360)
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
					v_u_34 = v_u_34 + p322
					if v_u_34 > 0.5 then
						v_u_34 = 0
						if v337 == nil then
							v365 = false
						else
							v365 = v_u_66(v337, v335)
						end
						v_u_35 = v365
					end
					v366 = v_u_13
					if v366 and v366.Parent then
						v367 = v366:GetAttribute("TimeOfDay")
					else
						v367 = nil
					end
					v368 = v_u_13
					if v368 and v368.Parent then
						v369 = v368:GetAttribute("Weather")
					else
						v369 = nil
					end
					v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
					v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
					if v_u_55() then
						v371 = math.max(v371, 42)
					end
					if v_u_35 then
						v371 = math.max(v371, 55)
					end
					v372 = nil
					v373 = nil
					v374 = v_u_8.controllers.NightVision
					if v374 == nil or (v374.visionMods == nil or v335) then
						v375 = v373
						v376 = v372
					else
						v377 = v374.visionMods
						v378, v379, v376, v375 = pcall(v377, v370, v369)
						if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
							v371 = math.max(v371, v379)
						else
							v375 = v373
							v376 = v372
						end
					end
					if v335 then
						v380 = nil
					else
						v381 = v_u_13
						if v381 and v381.Parent then
							v380 = v381:GetAttribute("PvpScope")
						else
							v380 = nil
						end
					end
					v382 = 55
					if v488 == nil then
						if v_u_10.Scope == nil or v380 ~= true then
							if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
								if v_u_43.applied then
									v_u_132()
								end
							else
								v_u_43.applied = true
								v383 = v376 == nil and 55 or math.deg(v376)
								v384 = v_u_43
								if v_u_10.Scope ~= nil then
									v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
								end
								v384.half = v383
								v385 = v_u_10.Poly.setHalfAngle
								v386 = v_u_43.half
								v385((math.rad(v386)))
							end
						else
							v387 = nil
							v388 = nil
							v389 = v_u_10.Scope.active
							v390 = v_u_36
							v391 = v_u_8
							if v391 then
								v391 = v_u_8.controllers.Input
							end
							if v391 and v391.isAiming then
								v392 = v391.isAiming
								v393, v394 = pcall(v392)
								if v393 then
									v395 = v394 == true
								else
									v395 = v323:GetAttribute("Aiming") == true
								end
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
							if v389(v380, v390, v343, v395) then
								v396, v397 = v_u_128(v323)
								v398 = v_u_10.Scope.mag(v396, v397)
								v399 = v324.AssemblyLinearVelocity
								v400 = v_u_10.Scope.evaluate
								v401 = v399.X * v399.X + v399.Z * v399.Z
								v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
								v_u_43.mag = v398
							end
							if v376 ~= nil then
								v402 = math.deg(v376)
								v382 = math.min(v382, v402)
							end
							v_u_43.on = v387 ~= nil
							v_u_43.applied = true
							v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
							v403 = v_u_10.Poly.setHalfAngle
							v404 = v_u_43.half
							v403((math.rad(v404)))
							if v326 and v326.setScopeView then
								v326.setScopeView(v387, v388)
							end
						end
					else
						v405 = v_u_43
						v406 = v_u_10.ObsCone.scope
						v407 = v_u_13
						if v407 and v407.Parent then
							v408 = v407:GetAttribute("PvpScope")
						else
							v408 = nil
						end
						v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
						v405.half = v409
						v411 = v_u_43
						v412 = v_u_43
						v413 = v_u_43
						v414 = v488.sightMag
						v411.on = v410
						v412.applied = true
						v413.mag = v414
						v415 = v_u_10.Poly.setHalfAngle
						v416 = v_u_43.half
						v415((math.rad(v416)))
					end
					v417 = v_u_18
					v418 = v371 - v_u_18
					v419 = p322 * 2.5
					v_u_18 = v417 + v418 * math.min(1, v419)
					v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
					v421 = v_u_13
					if v421 and v421.Parent then
						v422 = v421:GetAttribute("HuntDark")
					else
						v422 = nil
					end
					if type(v422) == "number" then
						v420 = math.clamp(v422, 0, 1)
					end
					v423 = v_u_13
					if v423 and v423.Parent then
						v424 = v423:GetAttribute("PvpDark")
					else
						v424 = nil
					end
					if type(v424) == "number" then
						v420 = math.clamp(v424, 0, 1)
					end
					if v375 ~= nil then
						v420 = v420 * v375
					end
					v425 = v_u_19
					v426 = v420 - v_u_19
					v427 = p322 * 2
					v_u_19 = v425 + v426 * math.min(1, v427)
					v_u_22 = v_u_22 + 1
					if v_u_22 % v_u_23 == 0 then
						v428 = os.clock()
						v429 = v336.Position + Vector3.new(0, 1.5, 0)
						v430 = v_u_10.Poly.compute
						if v335 then
							v431 = v_u_90(v336, v337)
						else
							v431 = v_u_79(v336)
						end
						v430(v429, v431, v_u_18, v_u_110())
						v432 = os.clock()
						v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
						v433 = not v325 and 2 or v325.HipHeight
						v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
						if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
							v435 = v434 - v_u_20
							if math.abs(v435) < 8 then
								v434 = v_u_20
							end
						end
						if v_u_21 then
							v436 = v434 - v_u_20
							if math.abs(v436) > 4 then
								v_u_20 = v434
								v_u_21 = true
								v437 = v_u_10.Mesh.ensure
								v438 = workspace:FindFirstChild("HushLocal")
								if not v438 then
									v438 = Instance.new("Folder")
									v438.Name = "HushLocal"
									v438.Parent = workspace
								end
								v437(v438)
								v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
								v_u_10.Mesh.update(v_u_20)
								v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
								v439 = os.clock()
								v440 = v_u_10.Poly
								if v_u_28 then
									v_u_26 = v_u_28
								elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
									v_u_26 = v_u_26 - 1
									v_u_27 = v439 + 1.5
								elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
									v441 = v440.cornerUseful or 0
									v442 = v_u_29[v_u_26 + 1]
									v443 = math.min(v441, v442)
									v444 = v_u_29[v_u_26]
									v445 = (v443 - math.min(v441, v444)) * 2
									v446 = v_u_25
									v447 = v440.rays or 1
									v448 = v446 / math.max(v447, 1)
									v449 = v_u_24 - v_u_25
									v450 = math.max(v449, 0)
									if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
										v_u_26 = v_u_26 + 1
										v_u_27 = v439
									end
								end
								v440.MAX_CORNERS = v_u_29[v_u_26] or 40
								if v_u_24 > 2.4 then
									v451 = v_u_30[v_u_26] or 1
									v452 = math.max(v451, 2)
								else
									v452 = v_u_30[v_u_26] or 1
								end
								v_u_23 = v452
								if v_u_17 then
									v_u_107()
								end
							else
								v453 = v_u_20
								v454 = v434 - v_u_20
								v455 = p322 * 10 * v_u_23
								v_u_20 = v453 + v454 * math.min(1, v455)
								v437 = v_u_10.Mesh.ensure
								v438 = workspace:FindFirstChild("HushLocal")
								if not v438 then
									v438 = Instance.new("Folder")
									v438.Name = "HushLocal"
									v438.Parent = workspace
								end
								v437(v438)
								v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
								v_u_10.Mesh.update(v_u_20)
								v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
								v439 = os.clock()
								v440 = v_u_10.Poly
								if v_u_28 then
									v_u_26 = v_u_28
								elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
									v_u_26 = v_u_26 - 1
									v_u_27 = v439 + 1.5
								elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
									v441 = v440.cornerUseful or 0
									v442 = v_u_29[v_u_26 + 1]
									v443 = math.min(v441, v442)
									v444 = v_u_29[v_u_26]
									v445 = (v443 - math.min(v441, v444)) * 2
									v446 = v_u_25
									v447 = v440.rays or 1
									v448 = v446 / math.max(v447, 1)
									v449 = v_u_24 - v_u_25
									v450 = math.max(v449, 0)
									if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
										v_u_26 = v_u_26 + 1
										v_u_27 = v439
									end
								end
								v440.MAX_CORNERS = v_u_29[v_u_26] or 40
								if v_u_24 > 2.4 then
									v451 = v_u_30[v_u_26] or 1
									v452 = math.max(v451, 2)
								else
									v452 = v_u_30[v_u_26] or 1
								end
								v_u_23 = v452
								if v_u_17 then
									v_u_107()
								end
							end
						else
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
						if not v_u_36 and v_u_43.applied then
							v_u_132()
						end
						if v_u_36 and v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(v_u_15)
						end
						v_u_31 = v_u_31 + p322
						if v_u_31 >= 0.05 then
							v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
							v_u_31 = 0
						end
						v_u_33 = v_u_33 + p322
						if v_u_33 > 0.5 then
							v_u_33 = 0
							v456 = v_u_10.Cut.stats()
							v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
							v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
							v_u_9:SetAttribute("VisActive", v_u_36)
							v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
							v_u_9:SetAttribute("VisFp", v_u_42.on)
							v457 = v_u_9
							v458 = v_u_18 * 10 + 0.5
							v457:SetAttribute("VisRange", math.floor(v458) / 10)
							v459 = v_u_13
							if v459 and v459.Parent then
								v460 = v459:GetAttribute("PvpScope")
							else
								v460 = nil
							end
							if v460 == true then
								v461 = v_u_9
								v462 = "VisScope"
								if v_u_43.on then
									v463 = v_u_43.mag * 10 + 0.5
									v464 = math.floor(v463) / 10
								else
									v464 = 0
								end
								v461:SetAttribute(v462, v464)
								v465 = v_u_9
								v466 = v_u_43.half * 10 + 0.5
								v465:SetAttribute("VisHalf", math.floor(v466) / 10)
							elseif v_u_9:GetAttribute("VisScope") ~= nil then
								v_u_9:SetAttribute("VisScope", nil)
								v_u_9:SetAttribute("VisHalf", nil)
							end
							v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
							v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
							v467 = v_u_9
							v468 = v_u_24 * 100 + 0.5
							v467:SetAttribute("VisMs", math.floor(v468) / 100)
							v_u_9:SetAttribute("VisCut", v456.cut)
							v_u_9:SetAttribute("VisFaded", v456.faded)
							v469 = v_u_10.Reveal.stats()
							v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
							v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
							if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
								v470 = v_u_10.Cut.tokyoStats()
								v471 = v_u_9
								v472 = "VisOcc"
								if v_u_10.Cut.tokyoOn() then
									v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
								else
									v473 = nil
								end
								v471:SetAttribute(v472, v473)
								v474 = v_u_9
								v475 = "VisUnder"
								if v_u_10.Cut.tokyoOn() then
									v476 = v_u_10.Cut.underOn()
								else
									v476 = nil
								end
								v474:SetAttribute(v475, v476)
							end
							if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
								v477 = v_u_10.Cut.levelStats()
								v478 = v_u_9
								v479 = "VisLevel"
								if v_u_41.multi then
									v480 = "L" .. v477.level
								else
									v480 = nil
								end
								v478:SetAttribute(v479, v480)
								v481 = v_u_9
								v482 = "VisLevelHidden"
								if v_u_41.multi then
									v483 = v477.hidden
								else
									v483 = nil
								end
								v481:SetAttribute(v482, v483)
								v484 = v_u_9
								v485 = "VisLevelPending"
								if v_u_41.multi then
									v486 = v477.pending
								else
									v486 = nil
								end
								v484:SetAttribute(v485, v486)
							end
							v487 = v_u_10.Mesh.failed() or v_u_40
							if v487 then
								v_u_9:SetAttribute("VisError", v487)
							end
						end
					else
						if not v_u_36 and v_u_43.applied then
							v_u_132()
						end
						if v_u_36 and v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(v_u_15)
						end
						v_u_31 = v_u_31 + p322
						if v_u_31 >= 0.05 then
							v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
							v_u_31 = 0
						end
						v_u_33 = v_u_33 + p322
						if v_u_33 > 0.5 then
							v_u_33 = 0
							v456 = v_u_10.Cut.stats()
							v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
							v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
							v_u_9:SetAttribute("VisActive", v_u_36)
							v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
							v_u_9:SetAttribute("VisFp", v_u_42.on)
							v457 = v_u_9
							v458 = v_u_18 * 10 + 0.5
							v457:SetAttribute("VisRange", math.floor(v458) / 10)
							v459 = v_u_13
							if v459 and v459.Parent then
								v460 = v459:GetAttribute("PvpScope")
							else
								v460 = nil
							end
							if v460 == true then
								v461 = v_u_9
								v462 = "VisScope"
								if v_u_43.on then
									v463 = v_u_43.mag * 10 + 0.5
									v464 = math.floor(v463) / 10
								else
									v464 = 0
								end
								v461:SetAttribute(v462, v464)
								v465 = v_u_9
								v466 = v_u_43.half * 10 + 0.5
								v465:SetAttribute("VisHalf", math.floor(v466) / 10)
							elseif v_u_9:GetAttribute("VisScope") ~= nil then
								v_u_9:SetAttribute("VisScope", nil)
								v_u_9:SetAttribute("VisHalf", nil)
							end
							v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
							v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
							v467 = v_u_9
							v468 = v_u_24 * 100 + 0.5
							v467:SetAttribute("VisMs", math.floor(v468) / 100)
							v_u_9:SetAttribute("VisCut", v456.cut)
							v_u_9:SetAttribute("VisFaded", v456.faded)
							v469 = v_u_10.Reveal.stats()
							v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
							v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
							if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
								v470 = v_u_10.Cut.tokyoStats()
								v471 = v_u_9
								v472 = "VisOcc"
								if v_u_10.Cut.tokyoOn() then
									v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
								else
									v473 = nil
								end
								v471:SetAttribute(v472, v473)
								v474 = v_u_9
								v475 = "VisUnder"
								if v_u_10.Cut.tokyoOn() then
									v476 = v_u_10.Cut.underOn()
								else
									v476 = nil
								end
								v474:SetAttribute(v475, v476)
							end
							if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
								v477 = v_u_10.Cut.levelStats()
								v478 = v_u_9
								v479 = "VisLevel"
								if v_u_41.multi then
									v480 = "L" .. v477.level
								else
									v480 = nil
								end
								v478:SetAttribute(v479, v480)
								v481 = v_u_9
								v482 = "VisLevelHidden"
								if v_u_41.multi then
									v483 = v477.hidden
								else
									v483 = nil
								end
								v481:SetAttribute(v482, v483)
								v484 = v_u_9
								v485 = "VisLevelPending"
								if v_u_41.multi then
									v486 = v477.pending
								else
									v486 = nil
								end
								v484:SetAttribute(v485, v486)
							end
							v487 = v_u_10.Mesh.failed() or v_u_40
							if v487 then
								v_u_9:SetAttribute("VisError", v487)
							end
						end
					end
				else
					if v_u_10.Poly.valid and not v_u_36 then
						v_u_10.Poly.invalidate()
						if v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(false)
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
					return
				end
			else
				v_u_36 = v338
				if v488 ~= nil then
					v_u_36 = true
				end
				v341 = v_u_8
				if v341 then
					v341 = v_u_8.controllers.FpView
				end
				if v341 and v341.viewOn then
					v342 = v341.viewOn
					v343, v344 = pcall(v342)
					if v343 then
						v343 = v344 == true
					end
				else
					v343 = false
				end
				if v343 then
					v_u_36 = false
					v_u_37 = false
					if not v_u_42.on then
						v_u_42.on = true
						v345 = v_u_42
						v_u_42.asked = 0
						v345.shown = 0
						if v_u_10.Cut then
							v_u_10.Cut.reset()
							v_u_10.Cut.setLevels(nil)
							v_u_10.Cut.setUnder(false)
							v_u_10.Cut.setTokyo(nil, false)
							v_u_10.Reveal.setSameFloor(false)
						end
						v_u_41.root = nil
						v_u_41.multi = false
						v_u_41.gate = false
					end
					v_u_150()
				elseif v_u_42.on then
					v_u_42.on = false
					v_u_42.cam.valid = false
					v_u_41.acc = (1 / 0)
				end
				v346 = v_u_41
				v346.acc = v346.acc + p322
				if v_u_41.acc >= 1 then
					v_u_41.acc = 0
					v_u_192(v_u_42.on)
				end
				if v326 and v326.subject then
					v347 = v326.subject()
				else
					v347 = v324
				end
				v348 = v_u_41
				v349 = not v_u_42.on and v_u_41.multi
				if v349 then
					if v_u_12 == "Raid" and v347 ~= nil then
						v349 = v347.Parent ~= nil
					else
						v349 = false
					end
				end
				v348.gate = v349
				if v_u_41.gate and v347 then
					v_u_41.eyeY = v347.Position.Y + 1.5
				end
				v_u_32 = v_u_32 + p322
				if v_u_32 > 30 then
					v_u_32 = 0
					v_u_10.Index.purge()
				end
				v350 = workspace.CurrentCamera
				if v_u_37 and v350 then
					if v326 and v326.subject then
						v351 = v326.subject()
					else
						v351 = v324
					end
					if v_u_12 == "Hideout" then
						v352 = {}
						if v323 then
							table.insert(v352, v323)
						end
						if v351 then
							v353 = v351.Parent
						else
							v353 = v351
						end
						if v353 and (v353 ~= v323 and v353 ~= workspace) then
							table.insert(v352, v353)
						end
						v354 = v_u_10.Cut.setLoose
						v355 = workspace:FindFirstChild("HushLocal")
						if v355 then
							v356 = v355:FindFirstChild("Hideout") or v355
						else
							v356 = workspace
						end
						v354(v356, v352)
					else
						v_u_10.Cut.setLoose(nil)
					end
					v357 = v_u_10.Cut.setFacing
					if v_u_12 == "Raid" and (v324 and not v329) then
						v358 = v_u_79(v324)
					else
						v358 = nil
					end
					v357(v358)
					if v326 and v326.yaw then
						v359 = v326.yaw()
					else
						v359 = v_u_3.BASE_YAW
					end
					v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
					v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
					if v361 then
						v361 = v327 == "iso"
					end
					if v361 and v324 then
						v362 = v324.Position
					else
						v362 = nil
					end
					if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
						v362 = v351.Position
					end
					if v362 then
						v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
						v_u_10.Cut.setReveal(v_u_10.Reveal.points)
						v_u_11 = true
					elseif v_u_11 then
						v_u_10.Reveal.reset()
						v_u_10.Cut.setReveal(nil)
						v_u_11 = false
					end
					v363 = v_u_10.Cut.update
					if v351 and v351.Parent then
						v364 = v351.Position
					else
						v364 = nil
					end
					v363(p322, v364, v350.CFrame.Position, v359, v360)
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
					v_u_34 = v_u_34 + p322
					if v_u_34 > 0.5 then
						v_u_34 = 0
						if v337 == nil then
							v365 = false
						else
							v365 = v_u_66(v337, v335)
						end
						v_u_35 = v365
					end
					v366 = v_u_13
					if v366 and v366.Parent then
						v367 = v366:GetAttribute("TimeOfDay")
					else
						v367 = nil
					end
					v368 = v_u_13
					if v368 and v368.Parent then
						v369 = v368:GetAttribute("Weather")
					else
						v369 = nil
					end
					v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
					v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
					if v_u_55() then
						v371 = math.max(v371, 42)
					end
					if v_u_35 then
						v371 = math.max(v371, 55)
					end
					v372 = nil
					v373 = nil
					v374 = v_u_8.controllers.NightVision
					if v374 == nil or (v374.visionMods == nil or v335) then
						v375 = v373
						v376 = v372
					else
						v377 = v374.visionMods
						v378, v379, v376, v375 = pcall(v377, v370, v369)
						if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
							v371 = math.max(v371, v379)
						else
							v375 = v373
							v376 = v372
						end
					end
					if v335 then
						v380 = nil
					else
						v381 = v_u_13
						if v381 and v381.Parent then
							v380 = v381:GetAttribute("PvpScope")
						else
							v380 = nil
						end
					end
					v382 = 55
					if v488 == nil then
						if v_u_10.Scope == nil or v380 ~= true then
							if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
								if v_u_43.applied then
									v_u_132()
								end
							else
								v_u_43.applied = true
								v383 = v376 == nil and 55 or math.deg(v376)
								v384 = v_u_43
								if v_u_10.Scope ~= nil then
									v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
								end
								v384.half = v383
								v385 = v_u_10.Poly.setHalfAngle
								v386 = v_u_43.half
								v385((math.rad(v386)))
							end
						else
							v387 = nil
							v388 = nil
							v389 = v_u_10.Scope.active
							v390 = v_u_36
							v391 = v_u_8
							if v391 then
								v391 = v_u_8.controllers.Input
							end
							if v391 and v391.isAiming then
								v392 = v391.isAiming
								v393, v394 = pcall(v392)
								if v393 then
									v395 = v394 == true
								else
									v395 = v323:GetAttribute("Aiming") == true
								end
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
							if v389(v380, v390, v343, v395) then
								v396, v397 = v_u_128(v323)
								v398 = v_u_10.Scope.mag(v396, v397)
								v399 = v324.AssemblyLinearVelocity
								v400 = v_u_10.Scope.evaluate
								v401 = v399.X * v399.X + v399.Z * v399.Z
								v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
								v_u_43.mag = v398
							end
							if v376 ~= nil then
								v402 = math.deg(v376)
								v382 = math.min(v382, v402)
							end
							v_u_43.on = v387 ~= nil
							v_u_43.applied = true
							v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
							v403 = v_u_10.Poly.setHalfAngle
							v404 = v_u_43.half
							v403((math.rad(v404)))
							if v326 and v326.setScopeView then
								v326.setScopeView(v387, v388)
							end
						end
					else
						v405 = v_u_43
						v406 = v_u_10.ObsCone.scope
						v407 = v_u_13
						if v407 and v407.Parent then
							v408 = v407:GetAttribute("PvpScope")
						else
							v408 = nil
						end
						v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
						v405.half = v409
						v411 = v_u_43
						v412 = v_u_43
						v413 = v_u_43
						v414 = v488.sightMag
						v411.on = v410
						v412.applied = true
						v413.mag = v414
						v415 = v_u_10.Poly.setHalfAngle
						v416 = v_u_43.half
						v415((math.rad(v416)))
					end
					v417 = v_u_18
					v418 = v371 - v_u_18
					v419 = p322 * 2.5
					v_u_18 = v417 + v418 * math.min(1, v419)
					v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
					v421 = v_u_13
					if v421 and v421.Parent then
						v422 = v421:GetAttribute("HuntDark")
					else
						v422 = nil
					end
					if type(v422) == "number" then
						v420 = math.clamp(v422, 0, 1)
					end
					v423 = v_u_13
					if v423 and v423.Parent then
						v424 = v423:GetAttribute("PvpDark")
					else
						v424 = nil
					end
					if type(v424) == "number" then
						v420 = math.clamp(v424, 0, 1)
					end
					if v375 ~= nil then
						v420 = v420 * v375
					end
					v425 = v_u_19
					v426 = v420 - v_u_19
					v427 = p322 * 2
					v_u_19 = v425 + v426 * math.min(1, v427)
					v_u_22 = v_u_22 + 1
					if v_u_22 % v_u_23 == 0 then
						v428 = os.clock()
						v429 = v336.Position + Vector3.new(0, 1.5, 0)
						v430 = v_u_10.Poly.compute
						if v335 then
							v431 = v_u_90(v336, v337)
						else
							v431 = v_u_79(v336)
						end
						v430(v429, v431, v_u_18, v_u_110())
						v432 = os.clock()
						v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
						v433 = not v325 and 2 or v325.HipHeight
						v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
						if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
							v435 = v434 - v_u_20
							if math.abs(v435) < 8 then
								v434 = v_u_20
							end
						end
						if v_u_21 then
							v436 = v434 - v_u_20
							if math.abs(v436) > 4 then
								v_u_20 = v434
								v_u_21 = true
								v437 = v_u_10.Mesh.ensure
								v438 = workspace:FindFirstChild("HushLocal")
								if not v438 then
									v438 = Instance.new("Folder")
									v438.Name = "HushLocal"
									v438.Parent = workspace
								end
								v437(v438)
								v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
								v_u_10.Mesh.update(v_u_20)
								v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
								v439 = os.clock()
								v440 = v_u_10.Poly
								if v_u_28 then
									v_u_26 = v_u_28
								elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
									v_u_26 = v_u_26 - 1
									v_u_27 = v439 + 1.5
								elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
									v441 = v440.cornerUseful or 0
									v442 = v_u_29[v_u_26 + 1]
									v443 = math.min(v441, v442)
									v444 = v_u_29[v_u_26]
									v445 = (v443 - math.min(v441, v444)) * 2
									v446 = v_u_25
									v447 = v440.rays or 1
									v448 = v446 / math.max(v447, 1)
									v449 = v_u_24 - v_u_25
									v450 = math.max(v449, 0)
									if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
										v_u_26 = v_u_26 + 1
										v_u_27 = v439
									end
								end
								v440.MAX_CORNERS = v_u_29[v_u_26] or 40
								if v_u_24 > 2.4 then
									v451 = v_u_30[v_u_26] or 1
									v452 = math.max(v451, 2)
								else
									v452 = v_u_30[v_u_26] or 1
								end
								v_u_23 = v452
								if v_u_17 then
									v_u_107()
								end
							else
								v453 = v_u_20
								v454 = v434 - v_u_20
								v455 = p322 * 10 * v_u_23
								v_u_20 = v453 + v454 * math.min(1, v455)
								v437 = v_u_10.Mesh.ensure
								v438 = workspace:FindFirstChild("HushLocal")
								if not v438 then
									v438 = Instance.new("Folder")
									v438.Name = "HushLocal"
									v438.Parent = workspace
								end
								v437(v438)
								v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
								v_u_10.Mesh.update(v_u_20)
								v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
								v439 = os.clock()
								v440 = v_u_10.Poly
								if v_u_28 then
									v_u_26 = v_u_28
								elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
									v_u_26 = v_u_26 - 1
									v_u_27 = v439 + 1.5
								elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
									v441 = v440.cornerUseful or 0
									v442 = v_u_29[v_u_26 + 1]
									v443 = math.min(v441, v442)
									v444 = v_u_29[v_u_26]
									v445 = (v443 - math.min(v441, v444)) * 2
									v446 = v_u_25
									v447 = v440.rays or 1
									v448 = v446 / math.max(v447, 1)
									v449 = v_u_24 - v_u_25
									v450 = math.max(v449, 0)
									if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
										v_u_26 = v_u_26 + 1
										v_u_27 = v439
									end
								end
								v440.MAX_CORNERS = v_u_29[v_u_26] or 40
								if v_u_24 > 2.4 then
									v451 = v_u_30[v_u_26] or 1
									v452 = math.max(v451, 2)
								else
									v452 = v_u_30[v_u_26] or 1
								end
								v_u_23 = v452
								if v_u_17 then
									v_u_107()
								end
							end
						else
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
						if not v_u_36 and v_u_43.applied then
							v_u_132()
						end
						if v_u_36 and v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(v_u_15)
						end
						v_u_31 = v_u_31 + p322
						if v_u_31 >= 0.05 then
							v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
							v_u_31 = 0
						end
						v_u_33 = v_u_33 + p322
						if v_u_33 > 0.5 then
							v_u_33 = 0
							v456 = v_u_10.Cut.stats()
							v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
							v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
							v_u_9:SetAttribute("VisActive", v_u_36)
							v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
							v_u_9:SetAttribute("VisFp", v_u_42.on)
							v457 = v_u_9
							v458 = v_u_18 * 10 + 0.5
							v457:SetAttribute("VisRange", math.floor(v458) / 10)
							v459 = v_u_13
							if v459 and v459.Parent then
								v460 = v459:GetAttribute("PvpScope")
							else
								v460 = nil
							end
							if v460 == true then
								v461 = v_u_9
								v462 = "VisScope"
								if v_u_43.on then
									v463 = v_u_43.mag * 10 + 0.5
									v464 = math.floor(v463) / 10
								else
									v464 = 0
								end
								v461:SetAttribute(v462, v464)
								v465 = v_u_9
								v466 = v_u_43.half * 10 + 0.5
								v465:SetAttribute("VisHalf", math.floor(v466) / 10)
							elseif v_u_9:GetAttribute("VisScope") ~= nil then
								v_u_9:SetAttribute("VisScope", nil)
								v_u_9:SetAttribute("VisHalf", nil)
							end
							v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
							v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
							v467 = v_u_9
							v468 = v_u_24 * 100 + 0.5
							v467:SetAttribute("VisMs", math.floor(v468) / 100)
							v_u_9:SetAttribute("VisCut", v456.cut)
							v_u_9:SetAttribute("VisFaded", v456.faded)
							v469 = v_u_10.Reveal.stats()
							v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
							v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
							if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
								v470 = v_u_10.Cut.tokyoStats()
								v471 = v_u_9
								v472 = "VisOcc"
								if v_u_10.Cut.tokyoOn() then
									v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
								else
									v473 = nil
								end
								v471:SetAttribute(v472, v473)
								v474 = v_u_9
								v475 = "VisUnder"
								if v_u_10.Cut.tokyoOn() then
									v476 = v_u_10.Cut.underOn()
								else
									v476 = nil
								end
								v474:SetAttribute(v475, v476)
							end
							if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
								v477 = v_u_10.Cut.levelStats()
								v478 = v_u_9
								v479 = "VisLevel"
								if v_u_41.multi then
									v480 = "L" .. v477.level
								else
									v480 = nil
								end
								v478:SetAttribute(v479, v480)
								v481 = v_u_9
								v482 = "VisLevelHidden"
								if v_u_41.multi then
									v483 = v477.hidden
								else
									v483 = nil
								end
								v481:SetAttribute(v482, v483)
								v484 = v_u_9
								v485 = "VisLevelPending"
								if v_u_41.multi then
									v486 = v477.pending
								else
									v486 = nil
								end
								v484:SetAttribute(v485, v486)
							end
							v487 = v_u_10.Mesh.failed() or v_u_40
							if v487 then
								v_u_9:SetAttribute("VisError", v487)
							end
						end
					else
						if not v_u_36 and v_u_43.applied then
							v_u_132()
						end
						if v_u_36 and v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(v_u_15)
						end
						v_u_31 = v_u_31 + p322
						if v_u_31 >= 0.05 then
							v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
							v_u_31 = 0
						end
						v_u_33 = v_u_33 + p322
						if v_u_33 > 0.5 then
							v_u_33 = 0
							v456 = v_u_10.Cut.stats()
							v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
							v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
							v_u_9:SetAttribute("VisActive", v_u_36)
							v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
							v_u_9:SetAttribute("VisFp", v_u_42.on)
							v457 = v_u_9
							v458 = v_u_18 * 10 + 0.5
							v457:SetAttribute("VisRange", math.floor(v458) / 10)
							v459 = v_u_13
							if v459 and v459.Parent then
								v460 = v459:GetAttribute("PvpScope")
							else
								v460 = nil
							end
							if v460 == true then
								v461 = v_u_9
								v462 = "VisScope"
								if v_u_43.on then
									v463 = v_u_43.mag * 10 + 0.5
									v464 = math.floor(v463) / 10
								else
									v464 = 0
								end
								v461:SetAttribute(v462, v464)
								v465 = v_u_9
								v466 = v_u_43.half * 10 + 0.5
								v465:SetAttribute("VisHalf", math.floor(v466) / 10)
							elseif v_u_9:GetAttribute("VisScope") ~= nil then
								v_u_9:SetAttribute("VisScope", nil)
								v_u_9:SetAttribute("VisHalf", nil)
							end
							v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
							v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
							v467 = v_u_9
							v468 = v_u_24 * 100 + 0.5
							v467:SetAttribute("VisMs", math.floor(v468) / 100)
							v_u_9:SetAttribute("VisCut", v456.cut)
							v_u_9:SetAttribute("VisFaded", v456.faded)
							v469 = v_u_10.Reveal.stats()
							v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
							v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
							if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
								v470 = v_u_10.Cut.tokyoStats()
								v471 = v_u_9
								v472 = "VisOcc"
								if v_u_10.Cut.tokyoOn() then
									v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
								else
									v473 = nil
								end
								v471:SetAttribute(v472, v473)
								v474 = v_u_9
								v475 = "VisUnder"
								if v_u_10.Cut.tokyoOn() then
									v476 = v_u_10.Cut.underOn()
								else
									v476 = nil
								end
								v474:SetAttribute(v475, v476)
							end
							if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
								v477 = v_u_10.Cut.levelStats()
								v478 = v_u_9
								v479 = "VisLevel"
								if v_u_41.multi then
									v480 = "L" .. v477.level
								else
									v480 = nil
								end
								v478:SetAttribute(v479, v480)
								v481 = v_u_9
								v482 = "VisLevelHidden"
								if v_u_41.multi then
									v483 = v477.hidden
								else
									v483 = nil
								end
								v481:SetAttribute(v482, v483)
								v484 = v_u_9
								v485 = "VisLevelPending"
								if v_u_41.multi then
									v486 = v477.pending
								else
									v486 = nil
								end
								v484:SetAttribute(v485, v486)
							end
							v487 = v_u_10.Mesh.failed() or v_u_40
							if v487 then
								v_u_9:SetAttribute("VisError", v487)
							end
						end
					end
				else
					if v_u_10.Poly.valid and not v_u_36 then
						v_u_10.Poly.invalidate()
						if v_u_10.Mesh.exists() then
							v_u_10.Mesh.setVisible(false)
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
					return
				end
			end
		end
		v332 = v488.root
		v331 = v488.char
		if v488 == nil then
			if v_u_14 then
				v_u_14 = false
				v_u_166()
			end
		else
			v_u_14 = true
		end
		v335 = v332 ~= nil
		if v332 == nil then
			v336 = v324
		else
			v336 = v332
		end
		if v332 == nil then
			v337 = v323
		else
			v337 = v331
		end
		if v332 ~= nil then
			if v331 == nil then
				v325 = nil
			else
				v325 = v331:FindFirstChildOfClass("Humanoid")
			end
		end
		v338 = v_u_15
		if v338 then
			if v_u_16 or v_u_55() then
				if v_u_12 == "Raid" then
					v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
				else
					v338 = false
				end
			else
				v338 = false
				v339 = v_u_13
				if v339 and v339.Parent then
					v340 = v339:GetAttribute("PvpCone")
				else
					v340 = nil
				end
				if v340 == true then
					if v_u_12 == "Raid" then
						v338 = v324 ~= nil and (not v329 and v327 == "iso") and true or v335
					else
						v338 = false
					end
				end
			end
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		else
			v_u_36 = v338
			if v488 ~= nil then
				v_u_36 = true
			end
			v341 = v_u_8
			if v341 then
				v341 = v_u_8.controllers.FpView
			end
			if v341 and v341.viewOn then
				v342 = v341.viewOn
				v343, v344 = pcall(v342)
				if v343 then
					v343 = v344 == true
				end
			else
				v343 = false
			end
			if v343 then
				v_u_36 = false
				v_u_37 = false
				if not v_u_42.on then
					v_u_42.on = true
					v345 = v_u_42
					v_u_42.asked = 0
					v345.shown = 0
					if v_u_10.Cut then
						v_u_10.Cut.reset()
						v_u_10.Cut.setLevels(nil)
						v_u_10.Cut.setUnder(false)
						v_u_10.Cut.setTokyo(nil, false)
						v_u_10.Reveal.setSameFloor(false)
					end
					v_u_41.root = nil
					v_u_41.multi = false
					v_u_41.gate = false
				end
				v_u_150()
			elseif v_u_42.on then
				v_u_42.on = false
				v_u_42.cam.valid = false
				v_u_41.acc = (1 / 0)
			end
			v346 = v_u_41
			v346.acc = v346.acc + p322
			if v_u_41.acc >= 1 then
				v_u_41.acc = 0
				v_u_192(v_u_42.on)
			end
			if v326 and v326.subject then
				v347 = v326.subject()
			else
				v347 = v324
			end
			v348 = v_u_41
			v349 = not v_u_42.on and v_u_41.multi
			if v349 then
				if v_u_12 == "Raid" and v347 ~= nil then
					v349 = v347.Parent ~= nil
				else
					v349 = false
				end
			end
			v348.gate = v349
			if v_u_41.gate and v347 then
				v_u_41.eyeY = v347.Position.Y + 1.5
			end
			v_u_32 = v_u_32 + p322
			if v_u_32 > 30 then
				v_u_32 = 0
				v_u_10.Index.purge()
			end
			v350 = workspace.CurrentCamera
			if v_u_37 and v350 then
				if v326 and v326.subject then
					v351 = v326.subject()
				else
					v351 = v324
				end
				if v_u_12 == "Hideout" then
					v352 = {}
					if v323 then
						table.insert(v352, v323)
					end
					if v351 then
						v353 = v351.Parent
					else
						v353 = v351
					end
					if v353 and (v353 ~= v323 and v353 ~= workspace) then
						table.insert(v352, v353)
					end
					v354 = v_u_10.Cut.setLoose
					v355 = workspace:FindFirstChild("HushLocal")
					if v355 then
						v356 = v355:FindFirstChild("Hideout") or v355
					else
						v356 = workspace
					end
					v354(v356, v352)
				else
					v_u_10.Cut.setLoose(nil)
				end
				v357 = v_u_10.Cut.setFacing
				if v_u_12 == "Raid" and (v324 and not v329) then
					v358 = v_u_79(v324)
				else
					v358 = nil
				end
				v357(v358)
				if v326 and v326.yaw then
					v359 = v326.yaw()
				else
					v359 = v_u_3.BASE_YAW
				end
				v360 = not (v326 and v326.right) and Vector3.new(1, 0, 0) or v326.right()
				v361 = v_u_15 and (v_u_12 == "Raid" and v324 ~= nil and not v329)
				if v361 then
					v361 = v327 == "iso"
				end
				if v361 and v324 then
					v362 = v324.Position
				else
					v362 = nil
				end
				if not v362 and (v_u_15 and (v_u_12 == "Raid" and (v327 == "spectate" and (v351 and (v351.Parent and not (v323 and v351:IsDescendantOf(v323))))))) then
					v362 = v351.Position
				end
				if v362 then
					v_u_10.Reveal.update(p322, v_u_8, v362, v350.CFrame.Position)
					v_u_10.Cut.setReveal(v_u_10.Reveal.points)
					v_u_11 = true
				elseif v_u_11 then
					v_u_10.Reveal.reset()
					v_u_10.Cut.setReveal(nil)
					v_u_11 = false
				end
				v363 = v_u_10.Cut.update
				if v351 and v351.Parent then
					v364 = v351.Position
				else
					v364 = nil
				end
				v363(p322, v364, v350.CFrame.Position, v359, v360)
			elseif v_u_11 then
				v_u_10.Reveal.reset()
				v_u_10.Cut.setReveal(nil)
				v_u_11 = false
			end
			if v_u_36 and (v336 ~= nil and (v337 ~= nil or v335)) then
				v_u_34 = v_u_34 + p322
				if v_u_34 > 0.5 then
					v_u_34 = 0
					if v337 == nil then
						v365 = false
					else
						v365 = v_u_66(v337, v335)
					end
					v_u_35 = v365
				end
				v366 = v_u_13
				if v366 and v366.Parent then
					v367 = v366:GetAttribute("TimeOfDay")
				else
					v367 = nil
				end
				v368 = v_u_13
				if v368 and v368.Parent then
					v369 = v368:GetAttribute("Weather")
				else
					v369 = nil
				end
				v370 = v_u_41.under and v336.Position.Y < v_u_8.shared.HollowLevels.SURFACE_Y and "Night" or v367
				v371 = (v_u_5[type(v370) ~= "string" and "Day" or v370] or 70) * (v_u_7[type(v369) ~= "string" and "Clear" or v369] or 1)
				if v_u_55() then
					v371 = math.max(v371, 42)
				end
				if v_u_35 then
					v371 = math.max(v371, 55)
				end
				v372 = nil
				v373 = nil
				v374 = v_u_8.controllers.NightVision
				if v374 == nil or (v374.visionMods == nil or v335) then
					v375 = v373
					v376 = v372
				else
					v377 = v374.visionMods
					v378, v379, v376, v375 = pcall(v377, v370, v369)
					if v378 and (type(v379) == "number" and (type(v376) == "number" and type(v375) == "number")) then
						v371 = math.max(v371, v379)
					else
						v375 = v373
						v376 = v372
					end
				end
				if v335 then
					v380 = nil
				else
					v381 = v_u_13
					if v381 and v381.Parent then
						v380 = v381:GetAttribute("PvpScope")
					else
						v380 = nil
					end
				end
				v382 = 55
				if v488 == nil then
					if v_u_10.Scope == nil or v380 ~= true then
						if v376 == nil and (not v_u_43.applied or v_u_43.half >= 54.95) then
							if v_u_43.applied then
								v_u_132()
							end
						else
							v_u_43.applied = true
							v383 = v376 == nil and 55 or math.deg(v376)
							v384 = v_u_43
							if v_u_10.Scope ~= nil then
								v383 = v_u_10.Scope.blendHalf(v_u_43.half, v383, p322)
							end
							v384.half = v383
							v385 = v_u_10.Poly.setHalfAngle
							v386 = v_u_43.half
							v385((math.rad(v386)))
						end
					else
						v387 = nil
						v388 = nil
						v389 = v_u_10.Scope.active
						v390 = v_u_36
						v391 = v_u_8
						if v391 then
							v391 = v_u_8.controllers.Input
						end
						if v391 and v391.isAiming then
							v392 = v391.isAiming
							v393, v394 = pcall(v392)
							if v393 then
								v395 = v394 == true
							else
								v395 = v323:GetAttribute("Aiming") == true
							end
						else
							v395 = v323:GetAttribute("Aiming") == true
						end
						if v389(v380, v390, v343, v395) then
							v396, v397 = v_u_128(v323)
							v398 = v_u_10.Scope.mag(v396, v397)
							v399 = v324.AssemblyLinearVelocity
							v400 = v_u_10.Scope.evaluate
							v401 = v399.X * v399.X + v399.Z * v399.Z
							v371, v382, v387, v388 = v400(true, v398, v397, v371, math.sqrt(v401), v323:GetAttribute("AimShift"))
							v_u_43.mag = v398
						end
						if v376 ~= nil then
							v402 = math.deg(v376)
							v382 = math.min(v382, v402)
						end
						v_u_43.on = v387 ~= nil
						v_u_43.applied = true
						v_u_43.half = v_u_10.Scope.blendHalf(v_u_43.half, v382, p322)
						v403 = v_u_10.Poly.setHalfAngle
						v404 = v_u_43.half
						v403((math.rad(v404)))
						if v326 and v326.setScopeView then
							v326.setScopeView(v387, v388)
						end
					end
				else
					v405 = v_u_43
					v406 = v_u_10.ObsCone.scope
					v407 = v_u_13
					if v407 and v407.Parent then
						v408 = v407:GetAttribute("PvpScope")
					else
						v408 = nil
					end
					v371, v409, v410 = v406(v488, v408, v_u_36, v371, v_u_43.half, p322)
					v405.half = v409
					v411 = v_u_43
					v412 = v_u_43
					v413 = v_u_43
					v414 = v488.sightMag
					v411.on = v410
					v412.applied = true
					v413.mag = v414
					v415 = v_u_10.Poly.setHalfAngle
					v416 = v_u_43.half
					v415((math.rad(v416)))
				end
				v417 = v_u_18
				v418 = v371 - v_u_18
				v419 = p322 * 2.5
				v_u_18 = v417 + v418 * math.min(1, v419)
				v420 = v_u_6[type(v370) ~= "string" and "Day" or v370] or 0.5
				v421 = v_u_13
				if v421 and v421.Parent then
					v422 = v421:GetAttribute("HuntDark")
				else
					v422 = nil
				end
				if type(v422) == "number" then
					v420 = math.clamp(v422, 0, 1)
				end
				v423 = v_u_13
				if v423 and v423.Parent then
					v424 = v423:GetAttribute("PvpDark")
				else
					v424 = nil
				end
				if type(v424) == "number" then
					v420 = math.clamp(v424, 0, 1)
				end
				if v375 ~= nil then
					v420 = v420 * v375
				end
				v425 = v_u_19
				v426 = v420 - v_u_19
				v427 = p322 * 2
				v_u_19 = v425 + v426 * math.min(1, v427)
				v_u_22 = v_u_22 + 1
				if v_u_22 % v_u_23 == 0 then
					v428 = os.clock()
					v429 = v336.Position + Vector3.new(0, 1.5, 0)
					v430 = v_u_10.Poly.compute
					if v335 then
						v431 = v_u_90(v336, v337)
					else
						v431 = v_u_79(v336)
					end
					v430(v429, v431, v_u_18, v_u_110())
					v432 = os.clock()
					v_u_25 = v_u_25 * 0.8 + (v432 - v428) * 1000 * 0.2
					v433 = not v325 and 2 or v325.HipHeight
					v434 = v336.Position.Y - v433 - v336.Size.Y * 0.5 + 0.55
					if v_u_21 and (v325 ~= nil and v325.FloorMaterial == Enum.Material.Air) then
						v435 = v434 - v_u_20
						if math.abs(v435) < 8 then
							v434 = v_u_20
						end
					end
					if v_u_21 then
						v436 = v434 - v_u_20
						if math.abs(v436) > 4 then
							v_u_20 = v434
							v_u_21 = true
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						else
							v453 = v_u_20
							v454 = v434 - v_u_20
							v455 = p322 * 10 * v_u_23
							v_u_20 = v453 + v454 * math.min(1, v455)
							v437 = v_u_10.Mesh.ensure
							v438 = workspace:FindFirstChild("HushLocal")
							if not v438 then
								v438 = Instance.new("Folder")
								v438.Name = "HushLocal"
								v438.Parent = workspace
							end
							v437(v438)
							v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
							v_u_10.Mesh.update(v_u_20)
							v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
							v439 = os.clock()
							v440 = v_u_10.Poly
							if v_u_28 then
								v_u_26 = v_u_28
							elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
								v_u_26 = v_u_26 - 1
								v_u_27 = v439 + 1.5
							elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
								v441 = v440.cornerUseful or 0
								v442 = v_u_29[v_u_26 + 1]
								v443 = math.min(v441, v442)
								v444 = v_u_29[v_u_26]
								v445 = (v443 - math.min(v441, v444)) * 2
								v446 = v_u_25
								v447 = v440.rays or 1
								v448 = v446 / math.max(v447, 1)
								v449 = v_u_24 - v_u_25
								v450 = math.max(v449, 0)
								if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
									v_u_26 = v_u_26 + 1
									v_u_27 = v439
								end
							end
							v440.MAX_CORNERS = v_u_29[v_u_26] or 40
							if v_u_24 > 2.4 then
								v451 = v_u_30[v_u_26] or 1
								v452 = math.max(v451, 2)
							else
								v452 = v_u_30[v_u_26] or 1
							end
							v_u_23 = v452
							if v_u_17 then
								v_u_107()
							end
						end
					else
						v_u_20 = v434
						v_u_21 = true
						v437 = v_u_10.Mesh.ensure
						v438 = workspace:FindFirstChild("HushLocal")
						if not v438 then
							v438 = Instance.new("Folder")
							v438.Name = "HushLocal"
							v438.Parent = workspace
						end
						v437(v438)
						v_u_10.Mesh.setDarkness(not v_u_15 and 0 or v_u_19)
						v_u_10.Mesh.update(v_u_20)
						v_u_24 = v_u_24 * 0.8 + (os.clock() - v428) * 1000 * 0.2
						v439 = os.clock()
						v440 = v_u_10.Poly
						if v_u_28 then
							v_u_26 = v_u_28
						elseif v_u_24 / v_u_23 > 0.85 and (v_u_26 > 0 and v_u_27 < v439) then
							v_u_26 = v_u_26 - 1
							v_u_27 = v439 + 1.5
						elseif v_u_26 < 3 and v_u_27 + 4 < v439 then
							v441 = v440.cornerUseful or 0
							v442 = v_u_29[v_u_26 + 1]
							v443 = math.min(v441, v442)
							v444 = v_u_29[v_u_26]
							v445 = (v443 - math.min(v441, v444)) * 2
							v446 = v_u_25
							v447 = v440.rays or 1
							v448 = v446 / math.max(v447, 1)
							v449 = v_u_24 - v_u_25
							v450 = math.max(v449, 0)
							if (v_u_25 + v448 * v445 + v450) / v_u_30[v_u_26 + 1] < 0.7 then
								v_u_26 = v_u_26 + 1
								v_u_27 = v439
							end
						end
						v440.MAX_CORNERS = v_u_29[v_u_26] or 40
						if v_u_24 > 2.4 then
							v451 = v_u_30[v_u_26] or 1
							v452 = math.max(v451, 2)
						else
							v452 = v_u_30[v_u_26] or 1
						end
						v_u_23 = v452
						if v_u_17 then
							v_u_107()
						end
					end
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				else
					if not v_u_36 and v_u_43.applied then
						v_u_132()
					end
					if v_u_36 and v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(v_u_15)
					end
					v_u_31 = v_u_31 + p322
					if v_u_31 >= 0.05 then
						v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
						v_u_31 = 0
					end
					v_u_33 = v_u_33 + p322
					if v_u_33 > 0.5 then
						v_u_33 = 0
						v456 = v_u_10.Cut.stats()
						v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
						v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
						v_u_9:SetAttribute("VisActive", v_u_36)
						v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
						v_u_9:SetAttribute("VisFp", v_u_42.on)
						v457 = v_u_9
						v458 = v_u_18 * 10 + 0.5
						v457:SetAttribute("VisRange", math.floor(v458) / 10)
						v459 = v_u_13
						if v459 and v459.Parent then
							v460 = v459:GetAttribute("PvpScope")
						else
							v460 = nil
						end
						if v460 == true then
							v461 = v_u_9
							v462 = "VisScope"
							if v_u_43.on then
								v463 = v_u_43.mag * 10 + 0.5
								v464 = math.floor(v463) / 10
							else
								v464 = 0
							end
							v461:SetAttribute(v462, v464)
							v465 = v_u_9
							v466 = v_u_43.half * 10 + 0.5
							v465:SetAttribute("VisHalf", math.floor(v466) / 10)
						elseif v_u_9:GetAttribute("VisScope") ~= nil then
							v_u_9:SetAttribute("VisScope", nil)
							v_u_9:SetAttribute("VisHalf", nil)
						end
						v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
						v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
						v467 = v_u_9
						v468 = v_u_24 * 100 + 0.5
						v467:SetAttribute("VisMs", math.floor(v468) / 100)
						v_u_9:SetAttribute("VisCut", v456.cut)
						v_u_9:SetAttribute("VisFaded", v456.faded)
						v469 = v_u_10.Reveal.stats()
						v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
						v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
						if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
							v470 = v_u_10.Cut.tokyoStats()
							v471 = v_u_9
							v472 = "VisOcc"
							if v_u_10.Cut.tokyoOn() then
								v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
							else
								v473 = nil
							end
							v471:SetAttribute(v472, v473)
							v474 = v_u_9
							v475 = "VisUnder"
							if v_u_10.Cut.tokyoOn() then
								v476 = v_u_10.Cut.underOn()
							else
								v476 = nil
							end
							v474:SetAttribute(v475, v476)
						end
						if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
							v477 = v_u_10.Cut.levelStats()
							v478 = v_u_9
							v479 = "VisLevel"
							if v_u_41.multi then
								v480 = "L" .. v477.level
							else
								v480 = nil
							end
							v478:SetAttribute(v479, v480)
							v481 = v_u_9
							v482 = "VisLevelHidden"
							if v_u_41.multi then
								v483 = v477.hidden
							else
								v483 = nil
							end
							v481:SetAttribute(v482, v483)
							v484 = v_u_9
							v485 = "VisLevelPending"
							if v_u_41.multi then
								v486 = v477.pending
							else
								v486 = nil
							end
							v484:SetAttribute(v485, v486)
						end
						v487 = v_u_10.Mesh.failed() or v_u_40
						if v487 then
							v_u_9:SetAttribute("VisError", v487)
						end
					end
				end
			else
				if v_u_10.Poly.valid and not v_u_36 then
					v_u_10.Poly.invalidate()
					if v_u_10.Mesh.exists() then
						v_u_10.Mesh.setVisible(false)
					end
				end
				if not v_u_36 and v_u_43.applied then
					v_u_132()
				end
				if v_u_36 and v_u_10.Mesh.exists() then
					v_u_10.Mesh.setVisible(v_u_15)
				end
				v_u_31 = v_u_31 + p322
				if v_u_31 >= 0.05 then
					v_u_10.Actors.update(v_u_31, v_u_4.visibility, v_u_12 == "Raid")
					v_u_31 = 0
				end
				v_u_33 = v_u_33 + p322
				if v_u_33 > 0.5 then
					v_u_33 = 0
					v456 = v_u_10.Cut.stats()
					v_u_9:SetAttribute("VisInside", v_u_10.Cut.inside() or "")
					v_u_9:SetAttribute("VisPeek", v_u_10.Cut.peeking() or "")
					v_u_9:SetAttribute("VisActive", v_u_36)
					v_u_9:SetAttribute("VisSpec", not v335 and "" or (v331 == nil and "part" or v331.Name))
					v_u_9:SetAttribute("VisFp", v_u_42.on)
					v457 = v_u_9
					v458 = v_u_18 * 10 + 0.5
					v457:SetAttribute("VisRange", math.floor(v458) / 10)
					v459 = v_u_13
					if v459 and v459.Parent then
						v460 = v459:GetAttribute("PvpScope")
					else
						v460 = nil
					end
					if v460 == true then
						v461 = v_u_9
						v462 = "VisScope"
						if v_u_43.on then
							v463 = v_u_43.mag * 10 + 0.5
							v464 = math.floor(v463) / 10
						else
							v464 = 0
						end
						v461:SetAttribute(v462, v464)
						v465 = v_u_9
						v466 = v_u_43.half * 10 + 0.5
						v465:SetAttribute("VisHalf", math.floor(v466) / 10)
					elseif v_u_9:GetAttribute("VisScope") ~= nil then
						v_u_9:SetAttribute("VisScope", nil)
						v_u_9:SetAttribute("VisHalf", nil)
					end
					v_u_9:SetAttribute("VisRays", v_u_10.Poly.rays)
					v_u_9:SetAttribute("VisPts", v_u_10.Poly.count)
					v467 = v_u_9
					v468 = v_u_24 * 100 + 0.5
					v467:SetAttribute("VisMs", math.floor(v468) / 100)
					v_u_9:SetAttribute("VisCut", v456.cut)
					v_u_9:SetAttribute("VisFaded", v456.faded)
					v469 = v_u_10.Reveal.stats()
					v_u_9:SetAttribute("VisReveal", string.format("%d/%d/%d/%d", v469.targets, v469.covered, v469.silhouettes, v456.revealed or 0))
					v_u_9:SetAttribute("VisShroud", v_u_10.Mesh.exists())
					if v_u_10.Cut.tokyoOn() or v_u_9:GetAttribute("VisOcc") ~= nil then
						v470 = v_u_10.Cut.tokyoStats()
						v471 = v_u_9
						v472 = "VisOcc"
						if v_u_10.Cut.tokyoOn() then
							v473 = string.format("%d/%d/%d/%d/%d/%.2f/%.2f/%.2f/%d", v470.groups, v470.inst, v470.fx, v470.over, v470.vol, v470.ms, v470.avg, v470.maxMs, v470.pending)
						else
							v473 = nil
						end
						v471:SetAttribute(v472, v473)
						v474 = v_u_9
						v475 = "VisUnder"
						if v_u_10.Cut.tokyoOn() then
							v476 = v_u_10.Cut.underOn()
						else
							v476 = nil
						end
						v474:SetAttribute(v475, v476)
					end
					if v_u_41.multi or v_u_9:GetAttribute("VisLevel") ~= nil then
						v477 = v_u_10.Cut.levelStats()
						v478 = v_u_9
						v479 = "VisLevel"
						if v_u_41.multi then
							v480 = "L" .. v477.level
						else
							v480 = nil
						end
						v478:SetAttribute(v479, v480)
						v481 = v_u_9
						v482 = "VisLevelHidden"
						if v_u_41.multi then
							v483 = v477.hidden
						else
							v483 = nil
						end
						v481:SetAttribute(v482, v483)
						v484 = v_u_9
						v485 = "VisLevelPending"
						if v_u_41.multi then
							v486 = v477.pending
						else
							v486 = nil
						end
						v484:SetAttribute(v485, v486)
					end
					v487 = v_u_10.Mesh.failed() or v_u_40
					if v487 then
						v_u_9:SetAttribute("VisError", v487)
					end
				end
				return
			end
		end
	end
end
return v_u_4