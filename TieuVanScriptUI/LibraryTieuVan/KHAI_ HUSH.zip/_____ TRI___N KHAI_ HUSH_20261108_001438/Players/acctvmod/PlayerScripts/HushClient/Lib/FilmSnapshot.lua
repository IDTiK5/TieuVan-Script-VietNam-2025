-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmSnapshot

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("HushUI"))
local v_u_4 = require(script.Parent:WaitForChild("SnapshotCore"))
local v_u_5 = v_u_3.Theme
local v_u_6 = v_u_5.color
local v7 = {}
local v_u_8 = v1.LocalPlayer
function v7.build(p_u_9) -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_6, (copy) v_u_5
	if not (v_u_2:IsStudio() and v_u_4.available()) then
		return nil
	end
	local v10 = p_u_9.body
	local v_u_11 = true
	p_u_9.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_11
		v_u_11 = false
	end)
	local v12 = p_u_9.order or 1000
	local v_u_13 = v_u_4.DEFAULT_RADIUS
	local v_u_14 = "-"
	local v_u_15 = 0
	local v_u_16 = false
	local v_u_17 = nil
	local v_u_18 = nil
	local v19 = nil
	local function v22(p20) -- name: setRadius
		-- upvalues: (ref) v_u_13, (ref) v_u_4, (ref) v_u_17, (ref) v_u_8, (ref) v_u_16, (ref) v_u_14, (ref) v_u_15
		v_u_13 = v_u_4.clampRadius(p20)
		if v_u_17 then
			local v21 = v_u_13
			v_u_17.Text = tostring(v21)
		end
		v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_13, v_u_16 and 1 or 0, v_u_14, v_u_15))
	end
	local v23 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Snapshot for Blender  \194\183  Studio only",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v10,
		["color"] = v_u_6.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	v12 = v12 + 1
	v23.LayoutOrder = v12
	local v24 = v_u_3.label({
		["parent"] = nil,
		["text"] = "Copies the world around you as you see it (buildings, props, loot, zombies, avatars, lights, the wall fade) into one model for Blender. Terrain is not copied. Nothing of the game changes.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v10,
		["color"] = v_u_6.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v12 = v12 + 1
	v24.LayoutOrder = v12
	local v25 = v_u_3.new("Frame", {
		["Name"] = "SnapRadiusRow",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(36))
	}, v10)
	v12 = v12 + 1
	v25.LayoutOrder = v12
	v_u_3.layout(v25, "h", 6)
	v_u_3.label({
		["parent"] = nil,
		["text"] = "Radius (studs)",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v25,
		["color"] = v_u_6.text2,
		["size"] = UDim2.new(0, 96, 1, 0)
	}).LayoutOrder = 1
	local v26 = v_u_3.input
	local v27 = {
		["parent"] = nil,
		["name"] = "SnapRadius",
		["size"] = nil,
		["text"] = nil,
		["placeholder"] = "200",
		["parent"] = v25,
		["size"] = UDim2.new(0, 80, 1, 0)
	}
	local v28 = v_u_13
	v27.text = tostring(v28)
	local v29, v_u_30 = v26(v27)
	v29.LayoutOrder = 2
	v_u_17 = v_u_30
	v_u_30.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_30, (ref) v_u_13, (ref) v_u_4, (ref) v_u_17, (ref) v_u_8, (ref) v_u_16, (ref) v_u_14, (ref) v_u_15
		local v31 = v_u_30.Text
		v_u_13 = v_u_4.clampRadius(v31)
		if v_u_17 then
			local v32 = v_u_13
			v_u_17.Text = tostring(v32)
		end
		v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_13, v_u_16 and 1 or 0, v_u_14, v_u_15))
	end)
	local v_u_33 = v19
	local v_u_34 = v_u_11
	local v35 = v12
	local v_u_36 = v_u_17
	local v_u_37 = v_u_13
	local v_u_38 = v_u_15
	local v_u_39 = v_u_14
	local v_u_40 = v_u_16
	local v41 = 2
	for _, v_u_42 in {
		50,
		100,
		200,
		500,
		1000
	} do
		v41 = v41 + 1
		local v45 = v_u_3.button({
			["parent"] = nil,
			["text"] = nil,
			["kind"] = "secondary",
			["height"] = nil,
			["width"] = 52,
			["maxTextWidth"] = 40,
			["onClick"] = nil,
			["parent"] = v25,
			["text"] = tostring(v_u_42),
			["height"] = v_u_5.touch(32),
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) v_u_42, (ref) v_u_37, (ref) v_u_4, (ref) v_u_36, (ref) v_u_8, (ref) v_u_40, (ref) v_u_39, (ref) v_u_38
				local v43 = v_u_42
				v_u_37 = v_u_4.clampRadius(v43)
				if v_u_36 then
					local v44 = v_u_37
					v_u_36.Text = tostring(v44)
				end
				v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
			end
		})
		v45.Name = "SnapRadius_" .. v_u_42
		v45.LayoutOrder = v41
	end
	local v46 = v_u_3.new("Frame", {
		["Name"] = "SnapActions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(34))
	}, v10)
	v12 = v35 + 1
	v46.LayoutOrder = v12
	v_u_3.layout(v46, "h", 8)
	local function v_u_60(p47) -- name: take
		-- upvalues: (ref) v_u_40, (ref) v_u_37, (ref) v_u_4, (ref) v_u_36, (ref) v_u_8, (ref) v_u_39, (ref) v_u_38, (copy) v_u_30, (ref) v_u_33, (copy) p_u_9, (ref) v_u_34, (ref) v_u_18
		if not v_u_40 then
			if p47 == nil then
				local v48 = v_u_30.Text
				v_u_37 = v_u_4.clampRadius(v48)
				if v_u_36 then
					local v49 = v_u_37
					v_u_36.Text = tostring(v49)
				end
				v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
			else
				v_u_37 = v_u_4.clampRadius(p47)
				if v_u_36 then
					local v50 = v_u_37
					v_u_36.Text = tostring(v50)
				end
				v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
			end
			v_u_33.Text = ""
			v_u_33.Visible = false
			v_u_8:SetAttribute("FilmSnapError", "")
			v_u_40 = true
			v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
			local v51 = p_u_9.handle
			if v51 and v51.status then
				v51.status("Taking the snapshot ...", nil)
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_4, (ref) v_u_37, (ref) v_u_40, (ref) v_u_34, (ref) v_u_39, (ref) v_u_38, (ref) v_u_18, (ref) v_u_8, (ref) p_u_9, (ref) v_u_33
				local v52 = {
					["radius"] = v_u_37
				}
				local v53, v54 = v_u_4.take(v52)
				v_u_40 = false
				if v_u_34 then
					if v53 then
						v_u_39 = v53.name
						v_u_38 = v53.parts
						local v55 = v_u_4.summary(v53)
						v_u_18.Text = v55
						v_u_18.Visible = true
						v_u_8:SetAttribute("FilmSnapResult", v55)
						local v56 = p_u_9.handle
						if v56 and v56.status then
							v56.status(v55, "success")
						end
					else
						local v57 = v54 or "Snapshot failed." or ""
						v_u_33.Text = v57
						v_u_33.Visible = v57 ~= ""
						v_u_8:SetAttribute("FilmSnapError", v57)
						local v58 = v54 or "Snapshot failed."
						local v59 = p_u_9.handle
						if v59 and v59.status then
							v59.status(v58, "danger")
						end
					end
					v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
				end
			end)
		end
	end
	local function v_u_64() -- name: clear
		-- upvalues: (ref) v_u_4, (ref) v_u_18, (ref) v_u_8, (ref) v_u_39, (ref) v_u_38, (copy) p_u_9, (ref) v_u_37, (ref) v_u_40
		local v61 = v_u_4.clear()
		v_u_18.Text = ""
		v_u_18.Visible = false
		v_u_8:SetAttribute("FilmSnapResult", "")
		v_u_39 = "-"
		v_u_38 = 0
		local v62 = v61 <= 0 and "No snapshots to remove." or string.format("Removed %d snapshot(s).", v61)
		local v63 = p_u_9.handle
		if v63 and v63.status then
			v63.status(v62, nil)
		end
		v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
	end
	local v76 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Take snapshot",
		["kind"] = "primary",
		["height"] = nil,
		["width"] = 170,
		["maxTextWidth"] = 156,
		["onClick"] = nil,
		["parent"] = v46,
		["height"] = v_u_5.touch(34),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_40, (copy) v_u_30, (ref) v_u_37, (ref) v_u_4, (ref) v_u_36, (ref) v_u_8, (ref) v_u_39, (ref) v_u_38, (ref) v_u_33, (copy) p_u_9, (ref) v_u_34, (ref) v_u_18
			if not v_u_40 then
				local v65 = v_u_30.Text
				v_u_37 = v_u_4.clampRadius(v65)
				if v_u_36 then
					local v66 = v_u_37
					v_u_36.Text = tostring(v66)
				end
				v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
				v_u_33.Text = ""
				v_u_33.Visible = false
				v_u_8:SetAttribute("FilmSnapError", "")
				v_u_40 = true
				v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
				local v67 = p_u_9.handle
				if v67 and v67.status then
					v67.status("Taking the snapshot ...", nil)
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_4, (ref) v_u_37, (ref) v_u_40, (ref) v_u_34, (ref) v_u_39, (ref) v_u_38, (ref) v_u_18, (ref) v_u_8, (ref) p_u_9, (ref) v_u_33
					local v68 = {
						["radius"] = v_u_37
					}
					local v69, v70 = v_u_4.take(v68)
					v_u_40 = false
					if v_u_34 then
						if v69 then
							v_u_39 = v69.name
							v_u_38 = v69.parts
							local v71 = v_u_4.summary(v69)
							v_u_18.Text = v71
							v_u_18.Visible = true
							v_u_8:SetAttribute("FilmSnapResult", v71)
							local v72 = p_u_9.handle
							if v72 and v72.status then
								v72.status(v71, "success")
							end
						else
							local v73 = v70 or "Snapshot failed." or ""
							v_u_33.Text = v73
							v_u_33.Visible = v73 ~= ""
							v_u_8:SetAttribute("FilmSnapError", v73)
							local v74 = v70 or "Snapshot failed."
							local v75 = p_u_9.handle
							if v75 and v75.status then
								v75.status(v74, "danger")
							end
						end
						v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
					end
				end)
			end
		end
	})
	v76.Name = "SnapTake"
	v76.LayoutOrder = 1
	local v77 = v_u_3.button({
		["parent"] = nil,
		["text"] = "Clear snapshots",
		["kind"] = "secondary",
		["height"] = nil,
		["width"] = 150,
		["maxTextWidth"] = 136,
		["onClick"] = nil,
		["parent"] = v46,
		["height"] = v_u_5.touch(34),
		["onClick"] = v_u_64
	})
	v77.Name = "SnapClear"
	v77.LayoutOrder = 2
	local v78 = v_u_3.label({
		["parent"] = nil,
		["name"] = "SnapResult",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v10,
		["color"] = v_u_6.success,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v12 = v12 + 1
	v78.LayoutOrder = v12
	v78.Visible = false
	v19 = v_u_3.label({
		["parent"] = nil,
		["name"] = "SnapError",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v10,
		["color"] = v_u_6.danger,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v12 = v12 + 1
	v19.LayoutOrder = v12
	v19.Visible = false
	local v79 = v_u_3.label({
		["parent"] = nil,
		["text"] = "How to get it into Blender",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v10,
		["color"] = v_u_6.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	})
	v12 = v12 + 1
	v79.LayoutOrder = v12
	local v80 = v12
	for _, v81 in v_u_4.HELP do
		local v82 = v_u_3.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["size"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["parent"] = v10,
			["text"] = v81,
			["color"] = v_u_6.text2,
			["size"] = UDim2.new(1, 0, 0, 0)
		})
		v12 = v80 + 1
		v82.LayoutOrder = v12
		v80 = v12
	end
	local v83 = {
		["take"] = v_u_60,
		["setRadius"] = v22,
		["clear"] = v_u_64,
		["state"] = function() -- name: state
			-- upvalues: (ref) v_u_37, (ref) v_u_40, (ref) v_u_39, (ref) v_u_38
			return {
				["radius"] = v_u_37,
				["running"] = v_u_40,
				["last"] = v_u_39,
				["parts"] = v_u_38
			}
		end
	}
	if v_u_2:IsStudio() then
		local v_u_89 = v_u_8:GetAttributeChangedSignal("FilmSnapCmd"):Connect(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_60, (ref) v_u_37, (ref) v_u_4, (ref) v_u_36, (ref) v_u_40, (ref) v_u_39, (ref) v_u_38, (copy) v_u_64
			local v84 = v_u_8:GetAttribute("FilmSnapCmd")
			if type(v84) == "string" and v84 ~= "" then
				v_u_8:SetAttribute("FilmSnapCmd", nil)
				local v85, v86 = string.match(v84, "^(%a+)%s*(.*)$")
				if v85 == "take" then
					local v87 = v_u_60
					if v86 == "" then
						v86 = nil
					end
					v87(v86)
					return
				elseif v85 == "radius" then
					v_u_37 = v_u_4.clampRadius(v86)
					if v_u_36 then
						local v88 = v_u_37
						v_u_36.Text = tostring(v88)
					end
					v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
				elseif v85 == "clear" then
					v_u_64()
				end
			else
				return
			end
		end)
		p_u_9.gui.Destroying:Connect(function()
			-- upvalues: (copy) v_u_89
			v_u_89:Disconnect()
		end)
	end
	v_u_8:SetAttribute("FilmSnap", string.format("radius=%d|busy=%d|last=%s|parts=%d", v_u_37, v_u_40 and 1 or 0, v_u_39, v_u_38))
	return v83
end
return v7