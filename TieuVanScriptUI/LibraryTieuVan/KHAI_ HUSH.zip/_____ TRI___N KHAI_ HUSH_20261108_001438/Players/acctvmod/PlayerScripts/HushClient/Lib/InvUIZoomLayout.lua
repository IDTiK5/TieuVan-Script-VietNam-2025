-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / InvUIZoomLayout

local v_u_19 = {
	["GAP"] = 4,
	["LABEL_TOUCH"] = 56,
	["LABEL_MOUSE"] = 46,
	["FIT_MOUSE"] = 36,
	["BLOCK_GAP"] = 12,
	["HINT_GAP"] = 22,
	["MIN_STATS"] = 96,
	["STATS_WANT"] = 240,
	["TITLE_MIN"] = 60,
	["LABEL_MIN"] = 44,
	["TABS_MIN"] = 220,
	["STATS_MAX"] = 420,
	["CLOSE_EDGE"] = 6,
	["MAP_GAP"] = 14,
	["labelW"] = function(p1) -- name: labelW
		-- upvalues: (copy) v_u_19
		if p1 then
			return v_u_19.LABEL_TOUCH
		else
			return v_u_19.LABEL_MOUSE
		end
	end,
	["fitW"] = function(p2) -- name: fitW
		-- upvalues: (copy) v_u_19
		local v3 = v_u_19.FIT_MOUSE
		return math.max(p2, v3)
	end,
	["blockW"] = function(p4, p5, p6, p7) -- name: blockW
		-- upvalues: (copy) v_u_19
		local v8 = p4 + p6 + p5 + p6 + p4
		if p7 then
			v8 = v8 + (p6 + v_u_19.fitW(p4))
		end
		return v8
	end,
	["headNeed"] = function(p9, p10) -- name: headNeed
		return (p10 == false and 10 or 4) + p9 + 6
	end,
	["hintsWidth"] = function(p11, p12, p13) -- name: hintsWidth
		local v14 = 0
		for v15, v16 in p11 do
			local v17 = #v16.text * p12
			local v18 = math.ceil(v17)
			if v16.chip then
				v18 = v18 + (p13 + 6)
			end
			v14 = v14 + v18
			if v15 <= 1 then
				continue
			end
			v14 = v14 + 24
		end
		return v14
	end
}
local function v_u_29(p20, p21, p22, p23, p24, p25) -- name: parts
	-- upvalues: (copy) v_u_19
	local v26 = v_u_19.blockW(p22, p23, p24, p25)
	local v27 = {
		["x"] = p20 + p22 + p24,
		["y"] = p21,
		["w"] = p23,
		["h"] = p22
	}
	local v28 = {
		["x"] = v27.x + p23 + p24,
		["y"] = p21,
		["w"] = p22,
		["h"] = p22
	}
	return {
		["block"] = {
			["x"] = p20,
			["y"] = p21,
			["w"] = v26,
			["h"] = p22
		},
		["minus"] = {
			["x"] = p20,
			["y"] = p21,
			["w"] = p22,
			["h"] = p22
		},
		["label"] = v27,
		["plus"] = v28,
		["fit"] = p25 and {
			["x"] = v28.x + p22 + p24,
			["y"] = p21,
			["w"] = v_u_19.fitW(p22),
			["h"] = p22
		} or nil,
		["labelIsFit"] = not p25
	}
end
function v_u_19.header(p30) -- name: header
	-- upvalues: (copy) v_u_19, (copy) v_u_29
	local v31 = p30.w
	local v32 = p30.h
	local v33 = p30.touchPx
	local v34 = p30.labelW
	local v35 = p30.gap or v_u_19.GAP
	local v36 = p30.titleX or 16
	local v37 = p30.statsX
	local v38 = p30.closeW
	local v39 = p30.mapBtnW or 0
	local v40 = p30.hintsW or 0
	local v41 = v32 - 6
	local v42 = math.min(v38, v41)
	local v43 = v31 - v_u_19.CLOSE_EDGE - v38
	local v44 = (v32 - v42) / 2
	local v45 = {
		["x"] = v43,
		["y"] = math.floor(v44),
		["w"] = v38,
		["h"] = v42
	}
	local v46 = v45.x
	local v47
	if v39 > 0 then
		local v48 = v45.x - v_u_19.MAP_GAP - v39
		local v49 = (v32 - v42) / 2
		v47 = {
			["x"] = v48,
			["y"] = math.floor(v49),
			["w"] = v39,
			["h"] = v42
		}
		v46 = v47.x
	else
		v47 = nil
	end
	local v50 = v46 - v_u_19.BLOCK_GAP
	local v51 = (v32 - v33) / 2
	local v52 = math.floor(v51)
	local v53 = v36 + v_u_19.TITLE_MIN + 8
	local v54 = {
		{ true, v37, true },
		{ true, math.min(v37, v53), true },
		{ false, v37, true },
		{ false, math.min(v37, v53), true },
		{ false, math.min(v37, v53), false }
	}
	local v55 = #v54
	for v56, v57 in v54 do
		local v58 = v50 - v_u_19.blockW(v33, v34, v35, v57[1])
		local v59
		if v57[3] then
			v59 = v58 - v_u_19.BLOCK_GAP - v57[2] - v_u_19.MIN_STATS
		else
			v59 = v58 - (v36 + v_u_19.TITLE_MIN + 8)
		end
		if v59 < 0 then
			continue
		end
		v55 = v56
	end
	local v60 = v54[v55]
	local v61 = v60[1]
	local v62 = v60[2]
	local v63 = v_u_29
	local v64 = v50 - v_u_19.blockW(v33, v34, v35, v61)
	local v65 = v63(math.max(0, v64), v52, v33, v34, v35, v61)
	local v66 = v65.block.x
	local v67 = v66 - v_u_19.HINT_GAP
	local v68 = v67 - v40
	local v69 = false
	local v70
	if v60[3] then
		local v71 = v_u_19.STATS_MAX
		local v72 = v68 - v62 - 8
		v70 = math.min(v71, v72)
		if v40 > 0 and v_u_19.STATS_WANT <= v70 then
			v69 = true
		else
			local v73 = v_u_19.STATS_MAX
			local v74 = v66 - v_u_19.BLOCK_GAP - v62 - 8
			v70 = math.min(v73, v74)
		end
	else
		v70 = 0
	end
	local v75 = {
		["block"] = v65.block,
		["minus"] = v65.minus,
		["label"] = v65.label,
		["plus"] = v65.plus,
		["fit"] = v65.fit,
		["labelIsFit"] = v65.labelIsFit,
		["close"] = v45,
		["map"] = v47
	}
	local v76 = v62 - v36 - 8
	v75.titleW = math.max(0, v76)
	v75.statsX = v62
	v75.statsW = math.max(0, v70)
	v75.hintsRight = v67
	v75.hintsLeft = v68
	v75.hintsVisible = v69
	v75.stage = v55 - 1
	return v75
end
function v_u_19.labelMinFor(p77) -- name: labelMinFor
	local v78 = p77 * 2.48
	return math.ceil(v78) + 8
end
function v_u_19.columnFits(p79, p80) -- name: columnFits
	-- upvalues: (copy) v_u_19
	if p79.narrow == true or p79.rw == nil then
		return true
	end
	local v81 = p79.cell * 2 + (p80.chrome or 34)
	if (p79.headerH or 0) == 0 then
		local v82 = p79.tight == true and 12 or 16
		local v83 = v_u_19.blockW(p80.touchPx, p80.labelMin or v_u_19.LABEL_MIN, p80.gap or v_u_19.GAP, false) + v82 * 2
		v81 = math.max(v81, v83)
	end
	return v81 <= p79.rw
end
function v_u_19.alignTop(p84, p85, p86) -- name: alignTop
	-- upvalues: (copy) v_u_19
	local v87 = p86 == false and 56 or 38
	local v88 = v_u_19.headNeed
	local v89 = math.max(v87, v88(p85, p86))
	return math.min(p84, v89)
end
function v_u_19.columnHead(p90) -- name: columnHead
	-- upvalues: (copy) v_u_19, (copy) v_u_29
	local v91 = p90.panelW
	local v92 = p90.inset
	local v93 = p90.tight == true
	local v94 = p90.touchPx
	local v95 = p90.labelW
	local v96 = p90.gap or v_u_19.GAP
	local v97 = p90.labelMin or v_u_19.LABEL_MIN
	local v98 = math.min(v95, v97)
	local v99 = v91 - v92 * 2
	local v100 = p90.tabs == true
	local v101
	if v100 then
		v101 = p90.tabsMin or v_u_19.TABS_MIN
	else
		v101 = p90.titleMin or 64
	end
	local v102 = v95
	local v103 = v93 and 4 or 10
	local v104 = v93 and 38 or 56
	local v105 = true
	local v106 = 0
	for v107, v108 in { true, false } do
		if v101 > v99 - v_u_19.blockW(v94, v95, v96, v108) - 8 then
			continue
		end
		v106 = v107
		v105 = v108
	end
	local v109 = false
	local v110
	if v106 == 0 and not v100 then
		local v111 = v99 - v94 * 2 - v96 * 2
		v110 = math.min(v95, v111)
		if v98 <= v110 then
			v105 = false
			v109 = true
			v106 = 3
		else
			v110 = v102
		end
	else
		v110 = v102
	end
	local v112 = v106 == 0
	if v112 then
		if v99 < v_u_19.blockW(v94, v95, v96, true) then
			local v113 = v99 - v94 * 2 - v96 * 2
			local v114 = math.min(v95, v113)
			v110 = math.max(v98, v114)
			v105 = false
		else
			v105 = true
		end
	end
	local v115 = v_u_19.blockW(v94, v110, v96, v105)
	local v116 = nil
	local v117 = nil
	local v118 = nil
	local v119
	if v112 then
		if v100 then
			v103 = v94 + 4 + 4
		elseif v93 then
			v117 = v99
			v99 = v118
			v116 = v117
			local v120 = v117
			v117 = v116
			v120 = v116
			v103 = 34
		else
			v117 = v99
			v99 = v118
			v116 = v117
			local v121 = v117
			v117 = v116
			v121 = v116
			v103 = 52
		end
		v119 = v103 + v94 + 6
	elseif v100 then
		v99 = v99 - v115 - 8
		v119 = v94 + 4 + 8
		v103 = 4
	elseif v109 then
		local v122 = v103 + v94 + 6
		v119 = math.max(v104, v122)
		v99 = v118
		v116 = 0
		v117 = 0
	else
		v116 = v99 - v115 - 8
		local v123 = v103 + v94 + 6
		v119 = math.max(v104, v123)
		v99 = v118
		v117 = v116
	end
	local v124 = v_u_29
	local v125 = v91 - v92 - v115
	local v126 = v124(math.max(0, v125), v103, v94, v110, v96, v105)
	return {
		["block"] = v126.block,
		["minus"] = v126.minus,
		["label"] = v126.label,
		["plus"] = v126.plus,
		["fit"] = v126.fit,
		["labelIsFit"] = v126.labelIsFit,
		["titleW"] = v116,
		["subW"] = v117,
		["titleHidden"] = v109,
		["tabsW"] = v99,
		["top"] = v119,
		["secondRow"] = v112,
		["stage"] = v112 and 3 or (v109 and 2 or (v105 and 0 or 1))
	}
end
return v_u_19