-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ShotgunFeel

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {}
local v_u_3 = nil
local v_u_4 = -10
local v_u_5 = true
function v_u_2._inject(p6) -- name: _inject
	-- upvalues: (ref) v_u_3
	v_u_3 = p6
end
function v_u_2.get(p7) -- name: get
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (ref) v_u_5, (ref) v_u_3
	if type(p7) == "table" and p7.pellets then
		local v8 = os.clock()
		if v8 - v_u_4 > 2 then
			v_u_4 = v8
			local function v11()
				-- upvalues: (ref) v_u_1
				local v9 = require
				local v10 = v_u_1:FindFirstChild("Hush")
				if v10 then
					v10 = v10:FindFirstChild("Shared")
				end
				return v9(v10.Config).flag("ShotgunPunch")
			end
			local v12, v13 = pcall(v11)
			v_u_5 = not v12 or v13 ~= false
		end
		if v_u_5 then
			if not v_u_3 then
				local function v16()
					-- upvalues: (ref) v_u_1
					local v14 = require
					local v15 = v_u_1:FindFirstChild("Hush")
					if v15 then
						v15 = v15:FindFirstChild("Shared")
					end
					return v14(v15.Weapons)
				end
				local v17, v18 = pcall(v16)
				if v17 then
					v_u_3 = v18
				end
			end
			local v19 = v_u_3
			if not v19 then
				return nil
			end
			local v20 = v19.punchShare(p7)
			return v20 > 0 and {
				["flash"] = 1 + 0.55 * v20,
				["shake"] = 1 + 0.8999999999999999 * v20,
				["kick"] = 1 + 0.3500000000000001 * v20,
				["share"] = v20
			} or nil
		end
	end
	return nil
end
function v_u_2.boom(p21, p22, p23, p24) -- name: boom
	-- upvalues: (copy) v_u_2
	local v25 = v_u_2.get(p23)
	if v25 and (p21 and p21.play3D) then
		local v26 = p21.play3D
		local v27 = {
			["pitch"] = 0.62,
			["volume"] = nil,
			["roll"] = nil,
			["volume"] = (p24 and 0.55 or 0.4) * v25.share,
			["roll"] = { 6, 140 }
		}
		pcall(v26, "wpn_far_heavy", p22, v27)
	end
end
return v_u_2