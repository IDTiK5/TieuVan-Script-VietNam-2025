-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HuntTrapView

local v_u_20 = {
	["MAX"] = 16,
	["MAX_PINGS"] = 6,
	["JAW_OPEN"] = 38,
	["JAW_SHUT"] = 4,
	["JAW_SPRUNG"] = 90,
	["SNAP_SEC"] = 0.12,
	["BLINK"] = 0.9,
	["diff"] = function(p1, p2) -- name: diff
		local v3 = {}
		local v4 = {}
		local v5 = {}
		if type(p2) == "table" then
			for _, v6 in p2 do
				if type(v6) ~= "table" then
					continue
				end
				local v7 = v6.i
				if type(v7) ~= "number" or (v6.i ~= v6.i or v3[v6.i] ~= nil) then
					continue
				end
				v3[v6.i] = true
				if p1[v6.i] ~= nil then
					continue
				end
				local v8 = v6.i
				table.insert(v4, v8)
			end
		end
		for v9 in p1 do
			if v3[v9] ~= nil then
				continue
			end
			table.insert(v5, v9)
		end
		table.sort(v4)
		table.sort(v5)
		return v4, v5
	end,
	["jaw"] = function(p10) -- name: jaw
		-- upvalues: (copy) v_u_20
		local v11 = (type(p10) ~= "number" or p10 ~= p10) and 1 or math.clamp(p10, 0, 1)
		return v_u_20.JAW_SHUT + (v_u_20.JAW_OPEN - v_u_20.JAW_SHUT) * v11
	end,
	["pingAlpha"] = function(p12, p13) -- name: pingAlpha
		local v14 = (type(p13) ~= "number" or p13 <= 0) and 4 or p13
		local v15 = (type(p12) ~= "number" or p12 ~= p12) and 0 or p12
		if v15 < 0 or v14 <= v15 then
			return 0
		end
		local v16 = v15 / 0.15
		local v17 = math.clamp(v16, 0, 1)
		local v18 = (v14 - v15) / (v14 * 0.4)
		local v19 = math.clamp(v18, 0, 1)
		return math.min(v17, v19)
	end
}
local v_u_21 = Color3.fromRGB(70, 74, 82)
local v_u_22 = Color3.fromRGB(122, 128, 138)
local v_u_23 = Color3.fromRGB(120, 66, 38)
local v_u_24 = Color3.fromRGB(255, 50, 40)
local function v_u_31(p25, p26, p27, p28, p29) -- name: part
	local v30 = Instance.new("Part")
	v30.Name = p26
	v30.Size = p27
	v30.Color = p28
	v30.Material = p29 or Enum.Material.Metal
	v30.Anchored = true
	v30.CanCollide = false
	v30.CanQuery = false
	v30.CanTouch = false
	v30.CastShadow = false
	v30.TopSurface = Enum.SurfaceType.Smooth
	v30.BottomSurface = Enum.SurfaceType.Smooth
	v30.Parent = p25
	return v30
end
local function v_u_41(p32) -- name: buildBear
	-- upvalues: (copy) v_u_31, (copy) v_u_21, (copy) v_u_23, (copy) v_u_22
	local v33 = v_u_31(p32, "Plate", Vector3.new(2.8, 0.18, 2.2), v_u_21)
	local v34 = v_u_31(p32, "Ring", Vector3.new(2.4, 0.12, 1.8), v_u_23)
	local v35 = {}
	for _, v36 in { -1, 1 } do
		local v37 = v_u_31(p32, "Jaw", Vector3.new(1.8, 0.16, 2), v_u_22)
		local v38 = {}
		for v39 = -2, 2 do
			local v40 = {
				["part"] = v_u_31(p32, "Tooth", Vector3.new(0.14, 0.3, 0.14), v_u_22),
				["z"] = v39 * 0.4
			}
			table.insert(v38, v40)
		end
		table.insert(v35, {
			["part"] = v37,
			["side"] = v36,
			["teeth"] = v38
		})
	end
	return {
		["plate"] = v33,
		["ring"] = v34,
		["jaws"] = v35
	}
end
v_u_20.HINGE_Y = 0.17
v_u_20.HINGE_Z = 0.5
local function v_u_49(p42) -- name: bindBear
	-- upvalues: (copy) v_u_20
	local v43 = p42:GetPivot()
	local v44 = p42:GetScale()
	local v45 = {}
	for _, v46 in {
		{ "JawFront", 1 },
		{ "TeethFront", 1 },
		{ "JawBack", -1 },
		{ "TeethBack", -1 }
	} do
		local v47 = p42:FindFirstChild(v46[1], true)
		if v47 == nil or not v47:IsA("BasePart") then
			continue
		end
		local v48 = {
			["part"] = v47,
			["sign"] = v46[2],
			["rel"] = v43:ToObjectSpace(v47.CFrame),
			["hinge"] = CFrame.new(0, v_u_20.HINGE_Y * v44, -v46[2] * v_u_20.HINGE_Z * v44)
		}
		table.insert(v45, v48)
	end
	return {
		["pivot"] = v43,
		["jaws"] = v45
	}
end
local function v_u_53(p50) -- name: bindAlarm
	-- upvalues: (copy) v_u_24
	local v51 = p50:FindFirstChild("Led", true)
	if v51 == nil or not v51:IsA("BasePart") then
		return {
			["led"] = nil,
			["light"] = nil
		}
	end
	local v52 = Instance.new("PointLight")
	v52.Color = v_u_24
	v52.Range = 9
	v52.Brightness = 0
	v52.Shadows = false
	v52.Parent = v51
	return {
		["led"] = v51,
		["light"] = v52
	}
end
local function v_u_60(p54) -- name: buildAlarm
	-- upvalues: (copy) v_u_31, (copy) v_u_21, (copy) v_u_22, (copy) v_u_24
	local v55 = v_u_31(p54, "Base", Vector3.new(1.2, 0.25, 1.2), v_u_21)
	local v56 = v_u_31(p54, "Post", Vector3.new(0.22, 1.9, 0.22), v_u_22)
	local v57 = v_u_31(p54, "Head", Vector3.new(0.9, 0.55, 0.6), v_u_21)
	local v58 = v_u_31(p54, "Lens", Vector3.new(0.38, 0.38, 0.38), v_u_24, Enum.Material.Neon)
	v58.Shape = Enum.PartType.Ball
	local v59 = Instance.new("PointLight")
	v59.Color = v_u_24
	v59.Range = 9
	v59.Brightness = 0
	v59.Shadows = false
	v59.Parent = v58
	return {
		["base"] = v55,
		["post"] = v56,
		["head"] = v57,
		["lens"] = v58,
		["light"] = v59
	}
end
function v_u_20.new(p_u_61) -- name: new
	-- upvalues: (copy) v_u_49, (copy) v_u_53, (copy) v_u_41, (copy) v_u_60, (copy) v_u_20, (copy) v_u_31
	local v_u_62 = {}
	local v_u_63 = p_u_61.rules
	local v_u_64 = p_u_61.now or os.clock
	local v_u_65 = Instance.new("Folder")
	v_u_65.Name = "HuntTrapsLocal"
	v_u_65.Parent = p_u_61.parent or workspace
	local v_u_66 = {}
	local v_u_67 = {}
	local v_u_68 = true
	local v_u_69 = {}
	local function v_u_83(p70, p71) -- name: make
		-- upvalues: (copy) v_u_64, (copy) p_u_61, (ref) v_u_49, (ref) v_u_53, (ref) v_u_41, (ref) v_u_60, (copy) v_u_65
		local v72 = Instance.new("Model")
		local v73 = p70.i
		v72.Name = "HuntTrap" .. tostring(v73)
		local v74 = {
			["kind"] = nil,
			["pos"] = nil,
			["model"] = nil,
			["open"] = 1,
			["sprung"] = false,
			["tripped"] = 0,
			["mine"] = nil,
			["yaw"] = nil,
			["born"] = nil,
			["kind"] = p70.kd
		}
		local v75 = p70.x
		local v76 = p70.y
		local v77 = p70.z
		v74.pos = Vector3.new(v75, v76, v77)
		v74.model = v72
		v74.mine = p71
		v74.yaw = p70.i * 2.3 % 6.283185307179586
		v74.born = v_u_64()
		local v78 = p_u_61.templates
		if v78 then
			v78 = p_u_61.templates[p70.kd]
		end
		if v78 == nil then
			if p70.kd == "bear" then
				v74.parts = v_u_41(v72)
			else
				v74.parts = v_u_60(v72)
			end
		else
			local v79 = v78:Clone()
			v79.Parent = v72
			for _, v80 in v79:GetDescendants() do
				if not v80:IsA("BasePart") then
					continue
				end
				v80.Anchored = true
				v80.CanCollide = false
				v80.CanQuery = false
				v80.CanTouch = false
				v80.CastShadow = false
			end
			if v79:IsA("Model") then
				v79:PivotTo(CFrame.new(v74.pos) * CFrame.Angles(0, v74.yaw, 0))
				local v81
				if p70.kd == "bear" then
					v81 = v_u_49(v79)
				else
					v81 = v_u_53(v79)
				end
				v74.tpl = v81
			end
			v74.template = true
		end
		if p71 then
			local v82 = Instance.new("Highlight")
			v82.FillTransparency = 1
			v82.OutlineColor = Color3.fromRGB(255, 190, 70)
			v82.OutlineTransparency = 0.35
			v82.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
			v82.Parent = v72
		end
		v72.Parent = v_u_65
		return v74
	end
	local function v_u_98(p84) -- name: pose
		-- upvalues: (ref) v_u_20
		local v85 = CFrame.new(p84.pos) * CFrame.Angles(0, p84.yaw, 0)
		local v86 = p84.parts
		if v86 == nil then
			local v87 = p84.tpl
			if v87 ~= nil and v87.jaws ~= nil then
				local v88 = v_u_20.JAW_SPRUNG * (1 - p84.open)
				for _, v89 in v87.jaws do
					if v89.part.Parent == nil then
						continue
					end
					local v90 = v89.part
					local v91 = v87.pivot * v89.hinge
					local v92 = CFrame.Angles
					local v93 = v89.sign * v88
					v90.CFrame = v91 * v92(math.rad(v93), 0, 0) * v89.hinge:Inverse() * v89.rel
				end
			end
			return
		elseif p84.kind == "bear" then
			v86.plate.CFrame = v85 * CFrame.new(0, 0.09, 0)
			v86.ring.CFrame = v85 * CFrame.new(0, 0.2, 0)
			local v94 = v_u_20.jaw(p84.open)
			for _, v95 in v86.jaws do
				local v96 = v85 * CFrame.new(v95.side * 1.15, 0.2, 0) * CFrame.Angles(0, 0, -v95.side * math.rad(v94))
				v95.part.CFrame = v96 * CFrame.new(-v95.side * 0.9, 0.08, 0)
				for _, v97 in v95.teeth do
					v97.part.CFrame = v96 * CFrame.new(-v95.side * 1.75, 0.22, v97.z)
				end
			end
		else
			v86.base.CFrame = v85 * CFrame.new(0, 0.12, 0)
			v86.post.CFrame = v85 * CFrame.new(0, 1.2, 0)
			v86.head.CFrame = v85 * CFrame.new(0, 2.3, 0)
			v86.lens.CFrame = v85 * CFrame.new(0, 2.3, -0.38)
		end
	end
	function v_u_62.apply(p99) -- name: apply
		-- upvalues: (ref) v_u_68, (ref) v_u_20, (copy) v_u_66, (copy) v_u_62, (copy) v_u_83, (copy) v_u_98, (copy) v_u_64, (copy) p_u_61, (ref) v_u_69
		if not v_u_68 or type(p99) ~= "table" then
			return
		end
		local v100, v101 = v_u_20.diff(v_u_66, p99.list)
		for _, v102 in v101 do
			local v103 = v_u_66[v102]
			if v103 == nil then
				continue
			end
			v_u_66[v102] = nil
			if not v103.model then
				continue
			end
			v103.model:Destroy()
		end
		local v104 = {}
		local v105 = p99.list
		if type(v105) == "table" then
			for _, v106 in p99.list do
				if type(v106) ~= "table" then
					continue
				end
				local v107 = v106.i
				if type(v107) ~= "number" then
					continue
				end
				v104[v106.i] = v106
			end
		end
		local v108 = p99.mine == true
		for _, v109 in v100 do
			if v_u_62.count() >= v_u_20.MAX then
				break
			end
			local v110 = v104[v109]
			if not v110 or v110.kd ~= "bear" and v110.kd ~= "alarm" then
				continue
			end
			local v111 = v110.x
			if type(v111) ~= "number" then
				continue
			end
			local v112 = v110.y
			if type(v112) ~= "number" then
				continue
			end
			local v113 = v110.z
			if type(v113) ~= "number" then
				continue
			end
			v_u_66[v109] = v_u_83(v110, v108)
			v_u_98(v_u_66[v109])
		end
		for v114, v115 in v_u_66 do
			local v116 = v104[v114]
			if v116 == nil then
				continue
			end
			if v116.sp == true and not v115.sprung then
				v115.sprung = true
				v115.snapAt = v_u_64()
				local v117 = p_u_61.play
				if type(v117) == "function" then
					local v118 = p_u_61.play
					local v119 = v115.pos
					pcall(v118, "trapSnap", v119)
				end
			end
			if v116.tr == true and v115.tripped == 0 then
				v115.tripped = v_u_64()
				local v120 = p_u_61.play
				if type(v120) ~= "function" then
					continue
				end
				local v121 = p_u_61.play
				local v122 = v115.pos
				pcall(v121, "alarm", v122)
			else
				if v116.tr == true then
					continue
				end
				v115.tripped = 0
			end
		end
		v_u_69 = {
			["bear"] = 0,
			["alarm"] = 0
		}
		for _, v123 in v_u_66 do
			v_u_69[v123.kind] = (v_u_69[v123.kind] or 0) + 1
		end
	end
	function v_u_62.ping(p124) -- name: ping
		-- upvalues: (ref) v_u_68, (copy) v_u_63, (copy) v_u_67, (ref) v_u_20, (ref) v_u_31, (copy) v_u_65, (copy) v_u_64
		if v_u_68 and type(p124) == "table" then
			local v125 = p124.x
			if type(v125) == "number" then
				local v126 = p124.z
				if type(v126) == "number" then
					local v127 = p124.kind ~= "alarm" and p124.kind ~= "broken" and "bear" or p124.kind
					local v128 = p124.sec
					local v129
					if type(v128) == "number" then
						local v130 = p124.sec
						v129 = math.clamp(v130, 1, 10)
					else
						v129 = 4
					end
					local v131 = p124.c
					local v132 = type(v131) ~= "number" and 0 or p124.c
					local v133 = Color3.fromRGB(240, 240, 240)
					if v132 > 0 and (v_u_63 and v_u_63.fpColor) then
						local v134, v135, v136 = v_u_63.fpColor(v132)
						v133 = Color3.fromRGB(v134, v135, v136)
					end
					local v137 = p124.x
					local v138 = p124.y
					local v139 = (type(v138) ~= "number" and 0 or p124.y) + 0.1
					local v140 = p124.z
					local v141 = Vector3.new(v137, v139, v140)
					while #v_u_67 >= v_u_20.MAX_PINGS do
						local v142 = table.remove(v_u_67, 1)
						v142.ring:Destroy()
						v142.anchor:Destroy()
					end
					local v143 = v_u_31(v_u_65, "PingRing", Vector3.new(0.12, 2, 2), v133, Enum.Material.Neon)
					v143.Shape = Enum.PartType.Cylinder
					local v144 = v_u_31(v_u_65, "PingAnchor", Vector3.new(0.2, 0.2, 0.2), v133)
					v144.Transparency = 1
					v144.Position = v141 + Vector3.new(0, 3.5, 0)
					local v145 = Instance.new("BillboardGui")
					v145.Name = "PingMark"
					v145.AlwaysOnTop = true
					v145.Size = UDim2.fromOffset(56, 56)
					v145.LightInfluence = 0
					v145.Adornee = v144
					local v146 = Instance.new("Frame")
					v146.Name = "Circle"
					v146.AnchorPoint = Vector2.new(0.5, 0.5)
					v146.Position = UDim2.fromScale(0.5, 0.5)
					v146.Size = UDim2.fromScale(1, 1)
					v146.BackgroundColor3 = Color3.fromRGB(10, 10, 12)
					v146.BackgroundTransparency = 0.25
					v146.BorderSizePixel = 0
					v146.Parent = v145
					local v147 = Instance.new("UICorner")
					v147.CornerRadius = UDim.new(0.5, 0)
					v147.Parent = v146
					local v148 = Instance.new("UIStroke")
					v148.Color = v133
					v148.Thickness = 3
					v148.Parent = v146
					local v149 = Instance.new("TextLabel")
					v149.Name = "Mark"
					v149.BackgroundTransparency = 1
					v149.Size = UDim2.fromScale(1, 1)
					v149.Text = v127 == "broken" and "X" or "!"
					v149.TextColor3 = v133
					v149.TextScaled = true
					v149.Font = Enum.Font.GothamBlack
					v149.Parent = v146
					v145.Parent = v144
					local v150 = v_u_67
					local v151 = {
						["ring"] = v143,
						["gui"] = v145,
						["anchor"] = v144,
						["circle"] = v146,
						["stroke"] = v148,
						["mark"] = v149,
						["pos"] = v141,
						["born"] = v_u_64(),
						["sec"] = v129,
						["kind"] = v127,
						["radius"] = v127 == "alarm" and (v_u_63 and v_u_63.ALARM_R or 6) or 3
					}
					table.insert(v150, v151)
					return
				end
			end
		end
	end
	function v_u_62.step(p152) -- name: step
		-- upvalues: (ref) v_u_68, (copy) v_u_64, (copy) v_u_66, (ref) v_u_20, (copy) v_u_98, (copy) v_u_67
		if v_u_68 then
			local v153 = v_u_64()
			for _, v154 in v_u_66 do
				if v154.kind == "bear" then
					local v155 = v154.sprung and 0 or 1
					if v154.open == v155 then
						continue
					end
					local v156 = p152 / v_u_20.SNAP_SEC
					local v157
					if v155 < v154.open then
						local v158 = v154.open - v156
						v157 = math.max(v155, v158)
					else
						local v159 = v154.open + v156
						v157 = math.min(v155, v159)
					end
					v154.open = v157
					v_u_98(v154)
				elseif v154.tpl == nil or v154.tpl.led == nil then
					if v154.parts == nil then
						continue
					end
					local v160 = (v153 - v154.born) % v_u_20.BLINK < v_u_20.BLINK * 0.25
					local v161
					if v154.tripped == 0 then
						v161 = false
					else
						v161 = v153 - v154.tripped < 1.5
					end
					v154.parts.lens.Transparency = (v160 or v161) and 0 or 0.7
					v154.parts.light.Brightness = v161 and 2.5 or (v160 and 0.8 or 0)
				else
					local v162 = (v153 - v154.born) % v_u_20.BLINK < v_u_20.BLINK * 0.25
					local v163
					if v154.tripped == 0 then
						v163 = false
					else
						v163 = v153 - v154.tripped < 1.5
					end
					v154.tpl.led.Transparency = (v162 or v163) and 0 or 0.7
					v154.tpl.light.Brightness = v163 and 2.5 or (v162 and 0.8 or 0)
				end
			end
			local v164 = 1
			while v164 <= #v_u_67 do
				local v165 = v_u_67[v164]
				local v166 = v153 - v165.born
				local v167 = v_u_20.pingAlpha(v166, v165.sec)
				if v167 <= 0 and v165.sec <= v166 then
					v165.ring:Destroy()
					v165.anchor:Destroy()
					table.remove(v_u_67, v164)
				else
					local v168 = v166 % 1.2 / 1.2
					local v169 = v165.radius * 2 * (0.25 + 0.75 * v168)
					v165.ring.Size = Vector3.new(0.12, v169, v169)
					v165.ring.CFrame = CFrame.new(v165.pos) * CFrame.Angles(0, 0, 1.5707963267948966)
					v165.ring.Transparency = 1 - v167 * (1 - v168) * 0.8
					local v170 = v166 * 9
					local v171 = math.sin(v170) * 0.12 + 1
					v165.gui.Size = UDim2.fromOffset(v171 * 56, v171 * 56)
					v165.circle.BackgroundTransparency = 1 - v167 * 0.75
					v165.stroke.Transparency = 1 - v167
					v165.mark.TextTransparency = 1 - v167
					v164 = v164 + 1
				end
			end
		end
	end
	function v_u_62.count() -- name: count
		-- upvalues: (copy) v_u_66
		local v172 = 0
		for _ in v_u_66 do
			v172 = v172 + 1
		end
		return v172
	end
	function v_u_62.kinds() -- name: kinds
		-- upvalues: (ref) v_u_69
		return {
			["bear"] = v_u_69.bear or 0,
			["alarm"] = v_u_69.alarm or 0
		}
	end
	function v_u_62.pings() -- name: pings
		-- upvalues: (copy) v_u_67
		return #v_u_67
	end
	function v_u_62.ids() -- name: ids
		-- upvalues: (copy) v_u_66
		local v173 = {}
		for v174 in v_u_66 do
			table.insert(v173, v174)
		end
		table.sort(v173)
		return v173
	end
	function v_u_62.info(p175) -- name: info
		-- upvalues: (copy) v_u_66
		local v176 = v_u_66[p175]
		return v176 ~= nil and {
			["kind"] = v176.kind,
			["sprung"] = v176.sprung,
			["open"] = v176.open,
			["tripped"] = v176.tripped ~= 0,
			["mine"] = v176.mine
		} or nil
	end
	function v_u_62.clear() -- name: clear
		-- upvalues: (copy) v_u_66, (copy) v_u_67, (ref) v_u_69
		for v177 in v_u_66 do
			local v178 = v_u_66[v177]
			if v178 == nil then
				continue
			end
			v_u_66[v177] = nil
			if not v178.model then
				continue
			end
			v178.model:Destroy()
		end
		for _, v179 in v_u_67 do
			v179.ring:Destroy()
			v179.anchor:Destroy()
		end
		table.clear(v_u_67)
		v_u_69 = {}
	end
	function v_u_62.destroy() -- name: destroy
		-- upvalues: (ref) v_u_68, (copy) v_u_62, (copy) v_u_65
		v_u_68 = false
		v_u_62.clear()
		v_u_65:Destroy()
	end
	v_u_62.folder = v_u_65
	return v_u_62
end
return v_u_20