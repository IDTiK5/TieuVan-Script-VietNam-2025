-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioEars

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = false
local v_u_11 = 0
local v_u_12 = -100
local v_u_13 = nil
local v_u_14 = ""
local v_u_15 = nil
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = false
local v_u_19 = {
	["low"] = 0,
	["mid"] = 0,
	["high"] = 0
}
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = 0
local v_u_24 = false
function v_u_3.init(p25, p26, p27, p28) -- name: init
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_2, (ref) v_u_9, (copy) v_u_20, (copy) v_u_21, (ref) v_u_10
	v_u_5 = p25
	v_u_6 = p26
	v_u_7 = p27
	v_u_8 = p28
	local function v29()
		-- upvalues: (ref) v_u_2
		return require(v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items"))
	end
	local v30, v31 = pcall(v29)
	if not v30 then
		v31 = nil
	end
	v_u_9 = v31
	for _, v32 in { "Music", "SFX", "Ambience" } do
		local v33 = v_u_6.groups[v32]
		local v34
		if v33 then
			v34 = v33:FindFirstChild("Ears")
			if not v34 then
				v34 = Instance.new("EqualizerSoundEffect")
				v34.Name = "Ears"
				v34.Priority = 6
				v34.Enabled = false
				v34.Parent = v33
			end
		else
			v34 = nil
		end
		if not v34 then
			continue
		end
		local v35 = v_u_20
		table.insert(v35, v34)
	end
	for _, v36 in { "SFX", "Ambience" } do
		local v37 = v_u_6.groups[v36]
		local v38
		if v37 then
			v38 = v37:FindFirstChild("HearAmp")
			if not v38 then
				v38 = Instance.new("CompressorSoundEffect")
				v38.Name = "HearAmp"
				v38.Priority = 7
				v38.Enabled = false
				v38.Parent = v37
			end
		else
			v38 = nil
		end
		if not v38 then
			continue
		end
		v38.Attack = 0.003
		v38.Release = 0.25
		local v39 = v_u_21
		table.insert(v39, v38)
	end
	v_u_10 = true
end
function v_u_3.resolveGear(p40, p41, p42) -- name: resolveGear
	if type(p40) == "string" and p40 ~= "" then
		return p40
	else
		return (p41 ~= "Hideout" or (type(p42) ~= "string" or #p42 > 40)) and "" or p42
	end
end
function v_u_3.shareOf(p43) -- name: shareOf
	if type(p43) ~= "table" then
		return 1
	end
	local v44 = p43.trauma
	return (type(v44) ~= "number" or v44 ~= v44) and 1 or math.clamp(v44, 0, 1)
end
function v_u_3.shotAdd(p45, p46, p47, p48, p49) -- name: shotAdd
	local v50 = p45 / 150 * 0.05 * p46
	if p47 then
		v50 = v50 * 0.2
	end
	if p48 then
		v50 = v50 * 1.6
	end
	return v50 * p49
end
local function v_u_58() -- name: readGear
	-- upvalues: (ref) v_u_15, (copy) v_u_4, (copy) v_u_3, (ref) v_u_14, (ref) v_u_13, (ref) v_u_9
	local v51
	if v_u_15 == nil then
		local v52 = v_u_4.Character
		local v53 = v_u_3.resolveGear
		if v52 then
			v52 = v52:GetAttribute("Ears")
		end
		v51 = v53(v52, v_u_4:GetAttribute("Place"), v_u_4:GetAttribute("HideoutEars"))
	else
		v51 = v_u_15 == "none" and "" or v_u_15
	end
	if v51 ~= v_u_14 then
		v_u_14 = v51
		v_u_13 = nil
		if v51 ~= "" and v_u_9 then
			local v54 = v_u_9.get
			local v55, v56 = pcall(v54, v51)
			if v55 and type(v56) == "table" then
				local v57 = v56.hearing
				if type(v57) == "table" then
					v_u_13 = v56.hearing
				end
			end
		end
	end
end
function v_u_3.gearId() -- name: gearId
	-- upvalues: (ref) v_u_14
	return v_u_14
end
function v_u_3.trauma() -- name: trauma
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_3.ringWanted() -- name: ringWanted
	-- upvalues: (ref) v_u_23
	return v_u_23 > 0.02
end
function v_u_3.traumaMul() -- name: traumaMul
	-- upvalues: (copy) v_u_58, (copy) v_u_3, (ref) v_u_13
	v_u_58()
	return v_u_3.shareOf(v_u_13)
end
function v_u_3.boost() -- name: boost
	-- upvalues: (ref) v_u_13
	if not v_u_13 then
		return 1
	end
	local v59 = v_u_13.boost or 1
	return math.clamp(v59, 0.4, 2.5)
end
function v_u_3.shotMul() -- name: shotMul
	-- upvalues: (ref) v_u_13
	if not v_u_13 then
		return 1
	end
	local v60 = v_u_13.shot or 1
	return math.clamp(v60, 0.2, 1.2)
end
function v_u_3.onShot(p61, p62, p63, p64, p65) -- name: onShot
	-- upvalues: (ref) v_u_10, (ref) v_u_8, (copy) v_u_3, (ref) v_u_24, (ref) v_u_11, (ref) v_u_12
	if v_u_10 then
		local v66
		if p64 then
			v66 = 1
		else
			local v67 = 1 - p62 / 14
			v66 = math.clamp(v67, 0, 1) ^ 1.5
		end
		if v66 > 0.02 then
			local v68 = 150
			if v_u_8 and p61 then
				local v69 = v_u_8.get
				local v70, v71 = pcall(v69, p61)
				if v70 and type(v71) == "table" then
					local v72 = v71.noise
					if type(v72) == "number" then
						v68 = v71.noise
					end
				end
			end
			local v73 = v_u_3.shotAdd(v68, v66, p63, p65, v_u_3.traumaMul())
			if v73 > 0 then
				if v_u_24 then
					return
				end
				local v74 = v_u_11 + v73
				v_u_11 = math.min(1, v74)
				v_u_12 = os.clock()
			end
		end
	else
		return
	end
end
function v_u_3.onBlast(p75) -- name: onBlast
	-- upvalues: (ref) v_u_10, (ref) v_u_24, (copy) v_u_3, (ref) v_u_11, (ref) v_u_12
	if v_u_10 and not v_u_24 then
		local v_u_76 = math.clamp(p75, 0, 1) * v_u_3.traumaMul()
		if v_u_76 > 0.02 then
			task.delay(0.45, function()
				-- upvalues: (ref) v_u_11, (copy) v_u_76, (ref) v_u_12
				local v77 = v_u_11
				local v78 = v_u_76
				local v79 = math.min(1, v78)
				v_u_11 = math.max(v77, v79)
				v_u_12 = os.clock()
			end)
		end
	else
		return
	end
end
function v_u_3.reset() -- name: reset
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_18, (ref) v_u_23, (ref) v_u_22
	v_u_11 = 0
	v_u_12 = -100
	v_u_18 = false
	v_u_23 = 0
	if v_u_22 then
		local function v80()
			-- upvalues: (ref) v_u_22
			v_u_22:stop(0.3)
		end
		pcall(v80)
		v_u_22 = nil
	end
end
function v_u_3.observer(p81) -- name: observer
	-- upvalues: (ref) v_u_24, (copy) v_u_3
	v_u_24 = p81 == true
	if v_u_24 then
		v_u_3.reset()
	end
end
local v_u_82 = nil
function v_u_3.packed() -- name: packed
	-- upvalues: (ref) v_u_82, (copy) v_u_2, (ref) v_u_14, (ref) v_u_11
	if v_u_82 == nil then
		local v83 = v_u_2:FindFirstChild("Hush")
		local v84
		if v83 then
			v84 = v83:FindFirstChild("Shared")
		else
			v84 = nil
		end
		local v85
		if v84 then
			v85 = v84:FindFirstChild("ReviewEarsRules")
		else
			v85 = nil
		end
		if v85 and v85:IsA("ModuleScript") then
			local v86 = require
			local v87, v88 = pcall(v86, v85)
			if not v87 then
				v88 = nil
			end
			v_u_82 = v88
		end
	end
	if v_u_82 == nil then
		return 0
	end
	local v89 = v_u_82.pack
	local v90 = v_u_14
	local v91 = v_u_11
	local v92, v93 = pcall(v89, v90, v91)
	return (not v92 or type(v93) ~= "number") and 0 or v93
end
function v_u_3.text() -- name: text
	-- upvalues: (ref) v_u_14, (ref) v_u_11, (copy) v_u_19, (ref) v_u_23, (copy) v_u_3, (ref) v_u_13
	return string.format("gear %s | trauma %.2f | eq %.1f/%.1f/%.1f dB | ring %.2f | boost x%.2f shot x%.2f traumaMul %.2f%s", v_u_14 == "" and "none" or v_u_14, v_u_11, v_u_19.low, v_u_19.mid, v_u_19.high, v_u_23, v_u_3.boost(), v_u_3.shotMul(), v_u_3.traumaMul(), not (v_u_13 and v_u_13.amp) and "" or string.format(" amp %d/%d/+%d", v_u_13.amp[1], v_u_13.amp[2], v_u_13.amp[3]))
end
local function v_u_117(p94) -- name: applyFx
	-- upvalues: (ref) v_u_13, (ref) v_u_11, (copy) v_u_19, (copy) v_u_20, (copy) v_u_21
	local v95 = v_u_13
	local v96 = not (v95 and v95.eq) and { 0, 0, 0 } or v95.eq
	local v97 = v_u_11 ^ 0.85
	local v98 = (v96[1] or 0) + v97 * -7
	local v99 = (v96[2] or 0) + v97 * -16
	local v100 = (v96[3] or 0) + v97 * -34
	local v101 = p94 * 3.5
	local v102 = math.min(1, v101)
	local v103 = v_u_19
	v103.low = v103.low + (v98 - v_u_19.low) * v102
	local v104 = v_u_19
	v104.mid = v104.mid + (v99 - v_u_19.mid) * v102
	local v105 = v_u_19
	v105.high = v105.high + (v100 - v_u_19.high) * v102
	local v106 = v_u_19.low
	local v107
	if math.abs(v106) > 0.15 then
		v107 = true
	else
		local v108 = v_u_19.mid
		if math.abs(v108) > 0.15 then
			v107 = true
		else
			local v109 = v_u_19.high
			v107 = math.abs(v109) > 0.15
		end
	end
	for _, v110 in v_u_20 do
		v110.Enabled = v107
		local v111 = v_u_19.low
		v110.LowGain = math.clamp(v111, -80, 10)
		local v112 = v_u_19.mid
		v110.MidGain = math.clamp(v112, -80, 10)
		local v113 = v_u_19.high
		v110.HighGain = math.clamp(v113, -80, 10)
	end
	local v114
	if v95 and v95.amp then
		v114 = v95.amp
	else
		v114 = nil
	end
	for _, v115 in v_u_21 do
		if v114 then
			v115.Threshold = v114[1]
			v115.Ratio = v114[2]
			local v116 = v114[3]
			v115.GainMakeup = math.clamp(v116, 0, 30)
			v115.Enabled = true
		else
			if not v115.Enabled then
				continue
			end
			v115.Enabled = false
		end
	end
end
local function v_u_125(p118) -- name: applyRing
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_23, (ref) v_u_22, (ref) v_u_6
	local v119 = v_u_11 <= 0.18 and 0 or ((v_u_11 - 0.18) / 0.8200000000000001) ^ 0.9 * 0.55 + 0.12
	local v120 = os.clock() - v_u_12 < 0.35 and 0 or v119
	local v121 = v_u_23
	local v122 = v120 - v_u_23
	local v123 = p118 * (v_u_23 < v120 and 2.5 or 1.2)
	v_u_23 = v121 + v122 * math.min(1, v123)
	if v_u_23 > 0.02 then
		if not v_u_22 and v_u_6 then
			local v124 = {
				["volume"] = nil,
				["group"] = "UI",
				["occlude"] = false,
				["volume"] = v_u_23
			}
			v_u_22 = v_u_6.bed("ev_ringing", v124)
		end
		if v_u_22 then
			v_u_22:setVolume(v_u_23, 0.1)
			return
		end
	elseif v_u_22 then
		v_u_22:stop(0.6)
		v_u_22 = nil
	end
end
function v_u_3.step(p126) -- name: step
	-- upvalues: (ref) v_u_10, (ref) v_u_16, (copy) v_u_58, (ref) v_u_11, (ref) v_u_12, (copy) v_u_117, (copy) v_u_125, (ref) v_u_18, (ref) v_u_5, (ref) v_u_17, (copy) v_u_4, (ref) v_u_14, (copy) v_u_19, (ref) v_u_13
	if v_u_10 then
		local v127 = os.clock()
		if v_u_16 <= v127 then
			v_u_16 = v127 + 0.5
			v_u_58()
		end
		if v_u_11 > 0 and v127 - v_u_12 > 1.4 then
			local v128 = v_u_11 - p126 * 0.035
			v_u_11 = math.max(0, v128)
		end
		v_u_117(p126)
		v_u_125(p126)
		if v_u_11 > 0.45 and not v_u_18 then
			v_u_18 = true
			local function v129()
				-- upvalues: (ref) v_u_5
				v_u_5.lib.HushUI.toast("EARS RINGING", "warn", "Shooting without hearing protection dulls everything for a while. A headset stops it.", 5)
			end
			pcall(v129)
		end
		if v_u_17 <= v127 then
			v_u_17 = v127 + 0.5
			local v130 = v_u_11 * 100 + 0.5
			local v131 = math.floor(v130) / 100
			if v_u_4:GetAttribute("EarTrauma") ~= v131 then
				v_u_4:SetAttribute("EarTrauma", v131)
			end
			if v_u_4:GetAttribute("EarsGear") ~= v_u_14 then
				v_u_4:SetAttribute("EarsGear", v_u_14)
			end
			v_u_4:SetAttribute("EarsEq", string.format("%.1f/%.1f/%.1f", v_u_19.low, v_u_19.mid, v_u_19.high))
			v_u_4:SetAttribute("EarsAmp", not (v_u_13 and v_u_13.amp) and 0 or v_u_13.amp[3])
		end
	end
end
function v_u_3.debugTrauma(p132) -- name: debugTrauma
	-- upvalues: (ref) v_u_11, (ref) v_u_12
	v_u_11 = math.clamp(p132, 0, 1)
	v_u_12 = os.clock()
end
function v_u_3.debugGear(p133) -- name: debugGear
	-- upvalues: (ref) v_u_15, (ref) v_u_16, (copy) v_u_58
	if p133 == nil or p133 == "auto" then
		v_u_15 = nil
	else
		v_u_15 = p133
	end
	v_u_16 = 0
	v_u_58()
end
return v_u_3