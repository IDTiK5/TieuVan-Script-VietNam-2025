-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HudLayout

local v_u_1 = {}
local v_u_2 = {
	["CORNER_TOP"] = 10,
	["CLOCK_H"] = 28,
	["TAG_H"] = 36,
	["WEAPON_Y"] = 42,
	["WEAPON_W"] = 210,
	["WEAPON_H"] = 56,
	["WEAPON_MIN_SCALE"] = 0.7,
	["GAP"] = 6,
	["CLOCK_VIS"] = 116,
	["SIREN_R"] = 128,
	["SIREN_W"] = 52,
	["TAG_GAP"] = 16,
	["TAG_W"] = 120,
	["BAND_W"] = 266,
	["BAND_GAP"] = 6,
	["NOTICE_TOP"] = 54,
	["NOTICE_CARD_H"] = 44,
	["NOTICE_GAP"] = 6,
	["NOTICE_MAX"] = 2,
	["NOTICE_MAX_W"] = 300,
	["NOTICE_MIN_W"] = 150,
	["NOTICE_PREF_W"] = 170,
	["NOTICE_VIEW_GAP"] = 8,
	["NOTICE_FRAC"] = 0.3333333333333333,
	["SQUAD_W"] = 176,
	["SQUAD_ROW_H"] = 18,
	["SQUAD_GAP"] = 3,
	["SQUAD_MARGIN_L"] = 8,
	["SQUAD_MARGIN_B"] = 6,
	["VITALS_H"] = 76,
	["NOISE_W"] = 168,
	["NOISE_H"] = 16,
	["PROMPT_H"] = 60,
	["DESK_EDGE"] = 40,
	["DESK_WEAPON_W"] = 296,
	["DESK_WEAPON_H"] = 76,
	["DESK_WARN_H"] = 24,
	["DESK_WARN_GAP"] = 8,
	["DESK_QUICK_W"] = 296,
	["DESK_QUICK_H"] = 84,
	["DESK_QUICK_BOTTOM"] = 34,
	["DESK_TIPS_W"] = 560,
	["DESK_TIPS_H"] = 20,
	["DESK_TIPS_BOTTOM"] = 8
}
v_u_1.K = v_u_2
v_u_1.BLOCKS = {
	{
		["name"] = "Vitals",
		["anchor"] = "TL",
		["movable"] = false,
		["default"] = "top left, right of the SNEAK / MORE column, 256 x 76"
	},
	{
		["name"] = "Noise",
		["anchor"] = "TL",
		["movable"] = true,
		["default"] = "under the vitals, 168 x 16"
	},
	{
		["name"] = "Clock",
		["anchor"] = "TR",
		["movable"] = true,
		["default"] = "top right corner, right edge level with the BAG button\'s right edge, 28 high"
	},
	{
		["name"] = "RaidModTag",
		["anchor"] = "TR",
		["movable"] = false,
		["default"] = "left of the clock row (follows the clock), 36 high"
	},
	{
		["name"] = "Weapon",
		["anchor"] = "TR",
		["movable"] = true,
		["default"] = "top right corner under the clock row, 210 wide, scaled to end above the three buttons"
	},
	{
		["name"] = "Squad",
		["anchor"] = "BL",
		["movable"] = true,
		["default"] = "bottom left corner under the move stick, rows of 18, not clickable"
	},
	{
		["name"] = "LevelPlate",
		["anchor"] = "TL",
		["movable"] = false,
		["default"] = "left band, first block (the Hollow\'s level and zone line, 230 x 16)"
	},
	{
		["name"] = "FreeRaidTag",
		["anchor"] = "TL",
		["movable"] = false,
		["default"] = "left band, under the level plate"
	},
	{
		["name"] = "Quick",
		["anchor"] = "TL",
		["movable"] = false,
		["default"] = "left band: the weight line (only above 75 percent of the limit)"
	},
	{
		["name"] = "EventBar",
		["anchor"] = "TL",
		["movable"] = false,
		["default"] = "left band: up to two event chips"
	},
	{
		["name"] = "Tasks",
		["anchor"] = "TL",
		["movable"] = true,
		["default"] = "left band: the task tracker"
	},
	{
		["name"] = "Extracts",
		["anchor"] = "TL",
		["movable"] = true,
		["default"] = "left band, on demand (it takes the whole band)"
	},
	{
		["name"] = "Notices",
		["anchor"] = "TL",
		["movable"] = true,
		["default"] = "top, between the left band and the weapon block: compact cards, two at most"
	},
	{
		["name"] = "inventory",
		["anchor"] = "TR",
		["movable"] = false,
		["default"] = "BAG, top right row, centre y 104 (pad px)"
	},
	{
		["name"] = "map",
		["anchor"] = "TR",
		["movable"] = false,
		["default"] = "MAP, top right row"
	},
	{
		["name"] = "menu",
		["anchor"] = "TR",
		["movable"] = false,
		["default"] = "MENU, top right row"
	},
	{
		["name"] = "ads",
		["anchor"] = "BR",
		["movable"] = false,
		["default"] = "ADS, right of RELOAD, level with it (FP/TP only)"
	},
	{
		["name"] = "viewToggle",
		["anchor"] = "BR",
		["movable"] = false,
		["default"] = "VIEW, left of RELOAD under the top right row (FP/TP only)"
	}
}
local v_u_3 = {}
for _, v4 in v_u_1.BLOCKS do
	v_u_3[v4.name] = v4
end
function v_u_1.anchorPoint(p5) -- name: anchorPoint
	if p5 == "TR" then
		return Vector2.new(1, 0)
	elseif p5 == "BL" then
		return Vector2.new(0, 1)
	elseif p5 == "BR" then
		return Vector2.new(1, 1)
	elseif p5 == "C" then
		return Vector2.new(0.5, 0.5)
	else
		return Vector2.new(0, 0)
	end
end
function v_u_1.hudScale(p6, p7) -- name: hudScale
	local v8 = p6.Y / 1080 * 1.1
	local v9 = math.min(1.6, v8)
	local v10 = math.max(0.8, v9) * (p7 or 1)
	local v11 = p6.X
	local v12 = p6.Y
	if math.min(v11, v12) < 600 then
		local v13 = p6.Y / 450 * 100
		local v14 = math.floor(v13) / 100
		local v15 = math.max(0.8, v14)
		local v16 = math.min(v15, v10)
		v10 = math.max(0.75, v16)
	end
	local v17 = math.min(2.2, v10)
	local v18 = math.max(0.5, v17) * 100 + 0.5
	return math.floor(v18) / 100
end
function v_u_1.cluster(p19) -- name: cluster
	-- upvalues: (copy) v_u_2
	local v20 = p19.rowRight
	local v21 = math.max(8, v20)
	local v22 = v_u_2.WEAPON_Y
	local v23 = (p19.rowTop - v_u_2.GAP - v22) / v_u_2.WEAPON_H
	local v24 = v_u_2.WEAPON_MIN_SCALE
	local v25 = math.min(1, v23)
	local v26 = math.max(v24, v25)
	return {
		["right"] = v21,
		["clockTop"] = v_u_2.CORNER_TOP,
		["clockH"] = v_u_2.CLOCK_H,
		["weaponY"] = v22,
		["weaponScale"] = v26,
		["weaponBottom"] = v22 + v_u_2.WEAPON_H * v26
	}
end
function v_u_1.noticeRight(p27) -- name: noticeRight
	-- upvalues: (copy) v_u_2
	local v28 = p27.refW - p27.right - v_u_2.WEAPON_W * (p27.weaponScale or 1) - 10
	if p27.rowLeft then
		local v29 = p27.rowLeft - 8
		v28 = math.min(v28, v29)
	end
	return v28
end
function v_u_1.noticeBottom() -- name: noticeBottom
	-- upvalues: (copy) v_u_2
	return v_u_2.NOTICE_TOP + v_u_2.NOTICE_MAX * v_u_2.NOTICE_CARD_H + (v_u_2.NOTICE_MAX - 1) * v_u_2.NOTICE_GAP
end
function v_u_1.vitalsWidth(p30) -- name: vitalsWidth
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v31 = v_u_1.noticeRight(p30) - v_u_2.NOTICE_PREF_W - 8 - p30.left
	local v32 = math.floor(v31)
	local v33 = math.min(256, v32)
	return math.max(180, v33)
end
function v_u_1.notice(p34) -- name: notice
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v35 = p34.bandLeft + v_u_2.BAND_W + 8
	if p34.vitalsRight then
		local v36 = p34.vitalsRight + 8
		v35 = math.max(v35, v36)
	end
	local v37 = v_u_1.noticeRight(p34)
	if p34.viewLeft and (p34.viewTop and p34.viewTop < v_u_1.noticeBottom()) then
		local v38 = p34.viewLeft - v_u_2.NOTICE_VIEW_GAP
		v37 = math.min(v37, v38)
	end
	local v39 = v_u_2.NOTICE_MAX_W
	local v40 = v37 - v35
	local v41 = math.min(v39, v40)
	local v42 = math.floor(v41)
	local v43 = v_u_2.NOTICE_TOP + v_u_2.NOTICE_CARD_H
	local v44 = p34.refH * v_u_2.NOTICE_FRAC
	local v45 = math.floor(v44)
	local v46 = math.max(v43, v45)
	return {
		["x0"] = v35,
		["x1"] = v35 + v42,
		["w"] = v42,
		["top"] = v_u_2.NOTICE_TOP,
		["y1"] = v46
	}
end
function v_u_1.firstSentence(p47, p48) -- name: firstSentence
	if type(p47) ~= "string" then
		return ""
	end
	local v49 = string.gsub(p47, "^%s+", "")
	local v50 = string.match(v49, "^[^\n]*") or ""
	local v51 = string.find(v50, "[%.!%?]%s")
	if v51 then
		v50 = string.sub(v50, 1, v51)
	end
	local v52 = string.gsub(v50, "%s+$", "")
	local v53 = p48 or 60
	if v53 < #v52 then
		v52 = string.sub(v52, 1, v53)
		local v54 = string.find(v52, "%s[^%s]*$")
		if v54 and v53 * 0.5 < v54 then
			local v55 = v54 - 1
			return string.sub(v52, 1, v55)
		end
	end
	return v52
end
function v_u_1.squad(p56, p57) -- name: squad
	-- upvalues: (copy) v_u_2
	local v58 = math.floor(p57)
	local v59 = math.min(3, v58)
	local v60 = math.max(0, v59)
	local v61 = v60 == 0 and 0 or v60 * v_u_2.SQUAD_ROW_H + (v60 - 1) * v_u_2.SQUAD_GAP
	local v62 = p56.refH - v_u_2.SQUAD_MARGIN_B
	return {
		["x0"] = v_u_2.SQUAD_MARGIN_L,
		["y0"] = v62 - v61,
		["x1"] = v_u_2.SQUAD_MARGIN_L + v_u_2.SQUAD_W,
		["y1"] = v62
	}
end
function v_u_1.deskBottom(p63, p64) -- name: deskBottom
	-- upvalues: (copy) v_u_2
	local v65 = v_u_2.DESK_EDGE
	local v66 = p63 - v65
	local v67 = p64 - v65
	local v68 = {
		v66 - v_u_2.DESK_WEAPON_W,
		v67 - v_u_2.DESK_WEAPON_H,
		v66,
		v67
	}
	local v69 = {
		v68[1],
		v68[2] - v_u_2.DESK_WARN_GAP - v_u_2.DESK_WARN_H,
		v66,
		v68[2] - v_u_2.DESK_WARN_GAP
	}
	local v70 = p63 / 2
	local v71 = p64 - v_u_2.DESK_QUICK_BOTTOM
	local v72 = p64 - v_u_2.DESK_TIPS_BOTTOM
	return {
		["weapon"] = v68,
		["warn"] = v69,
		["quick"] = {
			v70 - v_u_2.DESK_QUICK_W / 2,
			v71 - v_u_2.DESK_QUICK_H,
			v70 + v_u_2.DESK_QUICK_W / 2,
			v71
		},
		["tips"] = {
			v70 - v_u_2.DESK_TIPS_W / 2,
			v72 - v_u_2.DESK_TIPS_H,
			v70 + v_u_2.DESK_TIPS_W / 2,
			v72
		}
	}
end
function v_u_1.noticeBandRect(p73) -- name: noticeBandRect
	-- upvalues: (copy) v_u_2
	if type(p73) == "table" then
		local v74 = p73.x0
		local v75 = p73.x1
		local v76 = p73.top
		local v77 = p73.y1
		if type(v74) ~= "number" or (v74 ~= v74 or v74 == (1 / 0)) or v74 == (-1 / 0) or (type(v75) ~= "number" or (v75 ~= v75 or v75 == (1 / 0)) or v75 == (-1 / 0) or (type(v76) ~= "number" or (v76 ~= v76 or v76 == (1 / 0)) or v76 == (-1 / 0) or (type(v77) ~= "number" or (v77 ~= v77 or v77 == (1 / 0)) or v77 == (-1 / 0)))) then
			return nil
		else
			return v75 - v74 >= v_u_2.NOTICE_MIN_W - 1e-9 and v77 > v76 and {
				v74,
				v76,
				v75,
				v77
			} or nil
		end
	else
		return nil
	end
end
function v_u_1.compute(p78, p79) -- name: compute
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v80 = p79.tc
	local v81 = type(v80) == "table" and v80.layoutRects and (v80.geometry and v80.topRowRects)
	if v81 then
		v81 = v80.scaleFor
	end
	assert(v81, "HudLayout.compute needs opts.tc (TouchControls)")
	local v_u_82 = p79.safe or {
		["left"] = 0,
		["top"] = 0,
		["right"] = 0,
		["bottom"] = 0
	}
	local v83 = p79.padSize or p78
	local v_u_84 = v_u_1.hudScale(p78, p79.uiMul or 1)
	local v_u_85 = v80.scaleFor(v83, p79.touchSize or 2)
	local v86 = v_u_85 / v_u_84
	local v87 = Vector2.new(v83.X / v_u_85, v83.Y / v_u_85)
	local v88 = {
		["stick"] = nil,
		["fixed"] = nil,
		["phone"] = true,
		["fptp"] = nil,
		["stick"] = p79.stick,
		["fixed"] = p79.fixed,
		["fptp"] = p79.fptp == true
	}
	local v89 = v80.layoutRects(v87, v88)
	local v90 = v80.topRowRects(v87, v_u_85, true)
	local v91 = v80.geometry(v87, v88)
	local v92 = (v83.X - v_u_82.left - v_u_82.right) / v_u_84
	local v93 = (v83.Y - v_u_82.top - v_u_82.bottom) / v_u_84
	local function v95(p94) -- name: h
		-- upvalues: (copy) v_u_85, (copy) v_u_82, (copy) v_u_84
		return {
			(p94[1] * v_u_85 - v_u_82.left) / v_u_84,
			(p94[2] * v_u_85 - v_u_82.top) / v_u_84,
			(p94[3] * v_u_85 - v_u_82.left) / v_u_84,
			(p94[4] * v_u_85 - v_u_82.top) / v_u_84
		}
	end
	local v96 = {}
	for _, v97 in { "inventory", "map", "menu" } do
		v96[v97] = v95(v90[v97])
	end
	for _, v98 in {
		"sneak",
		"more",
		"reload",
		"swap",
		"interact",
		"throwCancel"
	} do
		v96[v98] = v95(v89[v98])
	end
	if p79.fptp == true then
		v96.ads = v95(v89.ads)
		v96.viewToggle = v95(v89.viewToggle)
	end
	v96.aim = v95(v89._aimStick)
	v96.plate = v95(v89._plate)
	local v99 = Vector2.new(v91.hintOff.X, v87.Y + v91.hintOff.Y)
	if v91.fixed then
		v99 = Vector2.new(v91.fixedOff.X, v87.Y + v91.fixedOff.Y)
	end
	v96.moveStick = v95({
		v99.X - v91.moveR,
		v99.Y - v91.moveR,
		v99.X + v91.moveR,
		v99.Y + v91.moveR
	})
	local v100
	if v91.fixed then
		v100 = v89._moveFixed
	else
		v100 = v89._moveHint
	end
	v96.moveHint = v95(v100)
	v96.tray = v95(v89._tray)
	local v101 = v96.sneak[3]
	local v102 = v96.more[3]
	local v103 = math.max(v101, v102)
	local v104 = (1 / 0)
	local v105 = 0
	local v106 = (1 / 0)
	for _, v107 in { "inventory", "map", "menu" } do
		local v108 = v96[v107][2]
		v104 = math.min(v104, v108)
		local v109 = v96[v107][3]
		v105 = math.max(v105, v109)
		local v110 = v96[v107][1]
		v106 = math.min(v106, v110)
	end
	local v111 = v_u_1.cluster({
		["rowTop"] = v104,
		["rowRight"] = v92 - v105
	})
	local v112 = v111.right
	local v113 = v103 + 16 * v86
	local v114 = p79.barX or 0
	local v115 = math.max(v113, v114)
	local v116 = 12 * v86
	local v117 = v96.moveStick[2]
	local v118 = v116 + 96
	local v119 = v117 - 8 * v86
	local v120 = v_u_1.vitalsWidth({
		["refW"] = v92,
		["left"] = v115,
		["right"] = v112,
		["weaponScale"] = v111.weaponScale,
		["rowLeft"] = v106
	})
	v96.Vitals = {
		v115,
		v116,
		v115 + v120,
		v116 + v_u_2.VITALS_H
	}
	local v121 = {}
	local v122 = v116 + 78
	local v123 = v_u_2.NOISE_W
	__set_list(v121, 1, {v115, v122, v115 + math.min(v123, v120), v116 + 78 + v_u_2.NOISE_H})
	v96.Noise = v121
	local v124 = v92 - v112
	local v125 = v124 - v_u_2.CLOCK_VIS
	if p79.siren then
		v125 = v124 - (v_u_2.SIREN_R - 0) - v_u_2.SIREN_W
	end
	v96.Clock = {
		v125,
		v111.clockTop,
		v124,
		v111.clockTop + v111.clockH
	}
	if p79.modTag ~= false then
		local v126 = v125 - v_u_2.TAG_GAP
		local v127 = v111.clockTop + v111.clockH / 2
		v96.RaidModTag = {
			v126 - v_u_2.TAG_W,
			v127 - v_u_2.TAG_H / 2,
			v126,
			v127 + v_u_2.TAG_H / 2
		}
	end
	v96.Weapon = {
		v124 - v_u_2.WEAPON_W * v111.weaponScale,
		v111.weaponY,
		v124,
		v111.weaponBottom
	}
	local v128 = p79.squad == nil and 3 or p79.squad
	if v128 > 0 then
		local v129 = v_u_1.squad({
			["refH"] = v93
		}, v128)
		v96.Squad = {
			v129.x0,
			v129.y0,
			v129.x1,
			v129.y1
		}
	end
	local v130 = v118
	if p79.extracts then
		local v131 = {}
		local v132 = v113 + v_u_2.BAND_W
		local v133 = v118 + 130
		__set_list(v131, 1, {v113, v118, v132, (math.min(v119, v133))})
		v96.Extracts = v131
	else
		local v134
		if p79.levelPlate and v130 + 16 <= v119 + 2 then
			v96.LevelPlate = {
				v113,
				v130,
				v113 + 230,
				v130 + 16
			}
			v130 = v130 + (16 + v_u_2.BAND_GAP)
			v134 = v130
		else
			v134 = v130
		end
		if p79.freeTag and v134 + 22 <= v119 + 2 then
			v96.FreeRaidTag = {
				v113,
				v134,
				v113 + 150,
				v134 + 22
			}
			v130 = v134 + (22 + v_u_2.BAND_GAP)
			v134 = v130
		end
		if p79.weight and v134 + 16 <= v119 + 2 then
			v96.Quick = {
				v113,
				v134,
				v113 + 150,
				v134 + 16
			}
			v130 = v134 + (16 + v_u_2.BAND_GAP)
			v134 = v130
		end
		local v135 = p79.events == nil and 2 or p79.events
		local v136 = (v119 - v134 + 4) / 28
		local v137 = math.floor(v136)
		local v138 = math.max(0, v137)
		local v139 = math.min(v135, v138)
		if v139 > 0 then
			local v140 = v139 * 24 + (v139 - 1) * 4
			local v141 = v_u_2.BAND_W - 20
			if v134 + v140 <= v119 + 2 then
				v96.EventBar = {
					v113,
					v134,
					v113 + v141,
					v134 + v140
				}
				v130 = v134 + (v140 + v_u_2.BAND_GAP)
				v134 = v130
			end
		end
		if p79.tasks then
			local v142 = v_u_2.BAND_W - 20
			if v134 + 26 <= v119 + 2 then
				v96.Tasks = {
					v113,
					v134,
					v113 + v142,
					v134 + 26
				}
				v130 = v134 + (26 + v_u_2.BAND_GAP)
			end
		end
	end
	local v143 = v96.viewToggle
	local v144 = v_u_1.notice
	local v145 = {
		["refW"] = v92,
		["refH"] = v93,
		["bandLeft"] = v113,
		["right"] = v112,
		["weaponScale"] = v111.weaponScale,
		["rowLeft"] = v106,
		["vitalsRight"] = v115 + v120
	}
	local v146
	if v143 then
		v146 = v143[1]
	else
		v146 = nil
	end
	v145.viewLeft = v146
	local v147
	if v143 then
		v147 = v143[2]
	else
		v147 = nil
	end
	v145.viewTop = v147
	local v148 = v144(v145)
	local v149 = p79.cards == nil and 2 or p79.cards
	if v149 > 0 then
		v96.Notices = {
			v148.x0,
			v148.top,
			v148.x0 + v148.w,
			v148.top + v149 * v_u_2.NOTICE_CARD_H + (v149 - 1) * v_u_2.NOTICE_GAP
		}
	end
	local v150 = v96.swap[1]
	local v151 = v96.interact[1]
	local v152 = math.min(v150, v151) - 10 * v86
	if v96.viewToggle then
		local v153 = v96.viewToggle[1] - 10 * v86
		v152 = math.min(v152, v153)
	end
	local v154 = v96.moveStick[3]
	if v96.Squad then
		local v155 = v96.Squad[3] + 8
		v154 = math.max(v154, v155)
	end
	v96.Prompt = {
		v154,
		v93 - 26 * v86 - v_u_2.PROMPT_H,
		v152,
		v93 - 26 * v86
	}
	return {
		["rects"] = v96,
		["meta"] = {
			["hs"] = v_u_84,
			["ts"] = v_u_85,
			["k"] = v86,
			["refW"] = v92,
			["refH"] = v93,
			["bandLeft"] = v113,
			["right"] = v112,
			["listY"] = v118,
			["listBottom"] = v119,
			["vitalsW"] = v120,
			["weaponScale"] = v111.weaponScale,
			["rowTop"] = v104,
			["notice"] = v148
		}
	}
end
local v_u_156 = {}
local v_u_157 = {}
local v_u_158 = 0
function v_u_1.isMovable(p159) -- name: isMovable
	-- upvalues: (copy) v_u_3
	local v160 = v_u_3[p159]
	local v161
	if v160 == nil then
		v161 = false
	else
		v161 = v160.movable == true
	end
	return v161
end
function v_u_1.setOverride(p162, p163) -- name: setOverride
	-- upvalues: (copy) v_u_1, (copy) v_u_156, (copy) v_u_157
	if not v_u_1.isMovable(p162) then
		return false
	end
	if p163 == nil then
		if v_u_156[p162] ~= nil then
			v_u_156[p162] = nil
			for _, v164 in v_u_157 do
				pcall(v164)
			end
		end
		return true
	end
	local v165 = p163.fx
	local v166 = p163.fy
	if type(v165) ~= "number" or (type(v166) ~= "number" or (v165 ~= v165 or v166 ~= v166)) then
		return false
	end
	local v167 = math.min(1, v165)
	local v168 = math.max(0, v167)
	local v169 = math.min(1, v166)
	local v170 = math.max(0, v169)
	local v171 = v_u_156[p162]
	if v171 and (v171.fx == v168 and v171.fy == v170) then
		return true
	end
	v_u_156[p162] = {
		["fx"] = v168,
		["fy"] = v170
	}
	for _, v172 in v_u_157 do
		pcall(v172)
	end
	return true
end
function v_u_1.getOverride(p173) -- name: getOverride
	-- upvalues: (copy) v_u_156
	local v174 = v_u_156[p173]
	return v174 and {
		["fx"] = v174.fx,
		["fy"] = v174.fy
	} or nil
end
function v_u_1.clearOverrides() -- name: clearOverrides
	-- upvalues: (copy) v_u_156, (copy) v_u_157
	if next(v_u_156) ~= nil then
		table.clear(v_u_156)
		for _, v175 in v_u_157 do
			pcall(v175)
		end
	end
end
function v_u_1.overrides() -- name: overrides
	-- upvalues: (copy) v_u_156
	local v176 = {}
	for v177, v178 in v_u_156 do
		v176[v177] = {
			["fx"] = v178.fx,
			["fy"] = v178.fy
		}
	end
	return v176
end
function v_u_1.onChanged(p179) -- name: onChanged
	-- upvalues: (ref) v_u_158, (copy) v_u_157
	v_u_158 = v_u_158 + 1
	local v_u_180 = v_u_158
	v_u_157[v_u_180] = p179
	return function()
		-- upvalues: (ref) v_u_157, (copy) v_u_180
		v_u_157[v_u_180] = nil
	end
end
local v_u_181 = {
	["Clock"] = {
		["w"] = v_u_2.CLOCK_VIS,
		["h"] = v_u_2.CLOCK_H
	},
	["Weapon"] = {
		["w"] = v_u_2.WEAPON_W * v_u_2.WEAPON_MIN_SCALE,
		["h"] = v_u_2.WEAPON_H * v_u_2.WEAPON_MIN_SCALE
	},
	["Squad"] = {
		["w"] = v_u_2.SQUAD_W,
		["h"] = v_u_2.SQUAD_ROW_H
	},
	["Noise"] = {
		["w"] = v_u_2.NOISE_W,
		["h"] = v_u_2.NOISE_H
	},
	["Tasks"] = {
		["w"] = nil,
		["h"] = 26,
		["w"] = v_u_2.BAND_W - 20
	},
	["Extracts"] = {
		["w"] = nil,
		["h"] = 130,
		["w"] = v_u_2.BAND_W
	},
	["Notices"] = {
		["w"] = v_u_2.NOTICE_MIN_W,
		["h"] = v_u_2.NOTICE_CARD_H
	}
}
function v_u_1.keep(p182, p183, p184, p185, p186, p187) -- name: keep
	-- upvalues: (copy) v_u_3, (copy) v_u_181, (copy) v_u_2
	local v188 = v_u_3[p182]
	local v189 = v_u_181[p182]
	if not v188 or (not v189 or (type(p185) ~= "number" or (type(p186) ~= "number" or (p185 ~= p185 or (p186 ~= p186 or (p185 <= 1 or (p186 <= 1 or (p183 ~= p183 or p184 ~= p184)))))))) then
		return p183, p184
	end
	local v190 = v188.anchor == "TR" and true or v188.anchor == "BR"
	local v191 = v188.anchor == "BL" and true or v188.anchor == "BR"
	local v192 = v189.w
	local v193 = v189.h
	if p182 == "Weapon" and (type(p187) == "number" and p187 == p187) then
		local v194 = v_u_2.WEAPON_MIN_SCALE
		local v195 = math.min(1, p187)
		local v196 = math.max(v194, v195)
		v192 = v_u_2.WEAPON_W * v196
		v193 = v_u_2.WEAPON_H * v196
	end
	local v197 = p183 * p185
	local v198 = not v190 and 0 or v192
	local v199
	if v190 then
		v199 = p185
	else
		v199 = p185 - v192
	end
	local v200 = math.min(v199, v197)
	local v201 = math.max(v198, v200)
	local v202 = p184 * p186
	local v203 = not v191 and 0 or v193
	local v204
	if v191 then
		v204 = p186
	else
		v204 = p186 - v193
	end
	local v205 = math.min(v204, v202)
	local v206 = math.max(v203, v205)
	return v201 / p185, v206 / p186
end
local v_u_207 = nil
local v_u_208 = nil
local v_u_209 = nil
function v_u_1.setFrame(p210, p211, p212) -- name: setFrame
	-- upvalues: (ref) v_u_207, (ref) v_u_208, (ref) v_u_209
	if type(p210) == "number" and (type(p211) == "number" and (p210 == p210 and (p211 == p211 and (p210 > 1 and p211 > 1)))) then
		v_u_207 = p210
		v_u_208 = p211
		v_u_209 = p212
	else
		v_u_207 = nil
		v_u_208 = nil
		v_u_209 = nil
	end
end
function v_u_1.frame() -- name: frame
	-- upvalues: (ref) v_u_207, (ref) v_u_208
	return v_u_207, v_u_208
end
local function v_u_215(p213, p214) -- name: kept
	-- upvalues: (ref) v_u_207, (ref) v_u_208, (copy) v_u_1, (ref) v_u_209
	if v_u_207 and v_u_208 then
		return v_u_1.keep(p213, p214.fx, p214.fy, v_u_207, v_u_208, v_u_209)
	else
		return p214.fx, p214.fy
	end
end
function v_u_1.position(p216, p217) -- name: position
	-- upvalues: (copy) v_u_156, (ref) v_u_207, (ref) v_u_208, (copy) v_u_1, (ref) v_u_209
	local v218 = v_u_156[p216]
	if not v218 then
		return p217
	end
	local v219, v220
	if v_u_207 and v_u_208 then
		v219, v220 = v_u_1.keep(p216, v218.fx, v218.fy, v_u_207, v_u_208, v_u_209)
	else
		v219 = v218.fx
		v220 = v218.fy
	end
	return UDim2.fromScale(v219, v220)
end
function v_u_1.fractions(p221) -- name: fractions
	-- upvalues: (copy) v_u_156, (copy) v_u_215
	local v222 = v_u_156[p221]
	if v222 then
		return v_u_215(p221, v222)
	else
		return nil, nil
	end
end
function v_u_1.vehicleAvoid(p223, p224, p225, p226, p227) -- name: vehicleAvoid
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v228 = {}
	local v229
	if type(p223) == "number" and (type(p224) == "number" and (p223 == p223 and (p224 == p224 and (p223 > 1 and (p224 > 1 and p223 < 1000000))))) then
		v229 = p224 < 1000000
	else
		v229 = false
	end
	if not v229 then
		return v228
	end
	if p225 == true then
		local v230, v231 = v_u_1.fractions("Squad")
		local v232 = v_u_2.SQUAD_MARGIN_L
		local v233 = p224 - v_u_2.SQUAD_MARGIN_B
		if v230 and v231 then
			v232 = v230 * p223
			v233 = v231 * p224
		end
		local v234 = {
			v232,
			v233 - (3 * v_u_2.SQUAD_ROW_H + 2 * v_u_2.SQUAD_GAP),
			v232 + v_u_2.SQUAD_W,
			v233
		}
		table.insert(v228, v234)
		local v235 = v_u_1.noticeBandRect(p227)
		if v235 then
			table.insert(v228, v235)
		end
	end
	if p225 ~= true then
		local v236 = v_u_1.deskBottom(p223, p224)
		local v237 = {}
		local v238 = v236.quick[1]
		local v239 = v236.tips[1]
		local v240 = math.min(v238, v239)
		local v241 = v236.quick[2]
		local v242 = v236.quick[3]
		local v243 = v236.tips[3]
		__set_list(v237, 1, {v240, v241, math.max(v242, v243), v236.tips[4]})
		table.insert(v228, v237)
		if p226 == "passenger" then
			local v244 = {
				v236.warn[1],
				v236.warn[2],
				v236.weapon[3],
				v236.weapon[4]
			}
			table.insert(v228, v244)
		end
	end
	if p226 == "passenger" then
		local v245, v246 = v_u_1.fractions("Weapon")
		if v245 and v246 then
			local v247 = v245 * p223
			local v248 = v246 * p224
			local v249 = {
				v247 - v_u_2.WEAPON_W,
				v248,
				v247,
				v248 + v_u_2.WEAPON_H
			}
			table.insert(v228, v249)
		end
	end
	return v228
end
return v_u_1