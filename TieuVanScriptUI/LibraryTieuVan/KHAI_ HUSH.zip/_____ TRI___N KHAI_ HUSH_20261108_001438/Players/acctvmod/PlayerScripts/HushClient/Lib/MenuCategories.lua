-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuCategories

local v_u_1 = {}
local v2 = {}
local v3 = {
	["id"] = "collection",
	["text"] = "COLLECTION",
	["group"] = 2,
	["scene"] = "vault",
	["shot"] = "shelf",
	["oldTab"] = "collection",
	["subs"] = nil,
	["subs"] = {
		{
			["id"] = "collection",
			["text"] = "COLLECTION",
			["page"] = nil,
			["page"] = { "MenuBook", "collection" }
		},
		{
			["id"] = "badges",
			["text"] = "BADGES",
			["page"] = nil,
			["page"] = { "MenuBadges" }
		},
		{
			["id"] = "leaderboard",
			["text"] = "LEADERBOARD",
			["page"] = nil,
			["page"] = { "MenuBook", "leaderboard" }
		}
	}
}
__set_list(v2, 1, {{
	["id"] = "deploy",
	["text"] = "DEPLOY",
	["group"] = 1,
	["scene"] = "street",
	["shot"] = "play",
	["page"] = nil,
	["action"] = "deploy",
	["oldTab"] = "play",
	["page"] = { "MenuPlay" }
}, {
	["id"] = "starter",
	["text"] = "STARTER PACK",
	["group"] = 1,
	["scene"] = "street",
	["shot"] = "wide",
	["page"] = nil,
	["oldTab"] = "starter",
	["page"] = { "MenuGroupStarter" }
}, {
	["id"] = "character",
	["text"] = "CHARACTER",
	["group"] = 1,
	["scene"] = "street",
	["shot"] = "character",
	["page"] = nil,
	["oldTab"] = "character",
	["page"] = { "MenuCharacter" }
}, {
	["id"] = "traders",
	["text"] = "TRADERS",
	["group"] = 1,
	["scene"] = "traders",
	["shot"] = "all",
	["page"] = nil,
	["oldTab"] = "traders",
	["page"] = { "MenuTraders" }
}, {
	["id"] = "market",
	["text"] = "MARKET",
	["group"] = 1,
	["scene"] = "market",
	["shot"] = "stall",
	["page"] = nil,
	["flag"] = "Blackmarket",
	["rule"] = "blackmarket",
	["ruleNil"] = true,
	["oldTab"] = "market",
	["page"] = { "MenuMarket" }
}, {
	["id"] = "crafting",
	["text"] = "CRAFTING",
	["group"] = 1,
	["scene"] = "hideout",
	["shot"] = "workbench",
	["page"] = nil,
	["flag"] = "Crafting",
	["page"] = { "MenuCrafting" }
}, {
	["id"] = "skills",
	["text"] = "SKILLS",
	["group"] = 1,
	["scene"] = "street",
	["shot"] = "wide",
	["page"] = nil,
	["page"] = { "MenuSkills" }
}, {
	["id"] = "tasks",
	["text"] = "TASKS",
	["group"] = 1,
	["scene"] = "street",
	["shot"] = "wide",
	["page"] = nil,
	["oldTab"] = "tasks",
	["page"] = { "MenuTasks" }
}, {
	["id"] = "hideout",
	["text"] = "HIDEOUT",
	["group"] = 1,
	["scene"] = "hideout",
	["shot"] = "overview",
	["action"] = "hideout",
	["oldTab"] = "hideout"
}, {
	["id"] = "clan",
	["text"] = "CLAN",
	["group"] = 2,
	["scene"] = "clan",
	["shot"] = "banner",
	["page"] = nil,
	["rule"] = "clans",
	["oldTab"] = "clan",
	["page"] = { "MenuClan" }
}, {
	["id"] = "pass",
	["text"] = "PASS",
	["group"] = 2,
	["scene"] = "vault",
	["shot"] = "locker",
	["page"] = nil,
	["rule"] = "seasonPass",
	["oldTab"] = "pass",
	["page"] = { "MenuPass" }
}, {
	["id"] = "store",
	["text"] = "STORE",
	["group"] = 2,
	["scene"] = "vault",
	["shot"] = "locker",
	["page"] = nil,
	["oldTab"] = "store",
	["page"] = { "MenuStore" }
}, v3, {
	["id"] = "settings",
	["text"] = "SETTINGS",
	["group"] = 3,
	["scene"] = "sky",
	["shot"] = "up",
	["page"] = nil,
	["oldTab"] = "settings",
	["page"] = { "MenuSettings" }
}})
v_u_1.HOME = v2
v_u_1.HIDEOUT = {
	{
		["id"] = "hideout_enter",
		["text"] = "ENTER",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "enter",
		["action"] = "enterHideout",
		["parent"] = "hideout"
	},
	{
		["id"] = "hideout_stash",
		["text"] = "STASH",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "stash_rack",
		["parent"] = "hideout"
	},
	{
		["id"] = "hideout_workbench",
		["text"] = "WORKBENCH",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "workbench",
		["page"] = nil,
		["parent"] = "hideout",
		["page"] = { "MenuCrafting" }
	},
	{
		["id"] = "hideout_med",
		["text"] = "MED STATION",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "med_station",
		["parent"] = "hideout"
	},
	{
		["id"] = "hideout_gunsmith",
		["text"] = "GUNSMITH",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "gunsmith",
		["parent"] = "hideout"
	},
	{
		["id"] = "hideout_terminal",
		["text"] = "TERMINAL",
		["group"] = 1,
		["scene"] = "hideout",
		["shot"] = "terminal",
		["parent"] = "hideout"
	},
	{
		["id"] = "hm_generator",
		["text"] = "GENERATOR",
		["group"] = 2,
		["scene"] = "hideout",
		["shot"] = "generator",
		["parent"] = "hideout"
	},
	{
		["id"] = "hm_radio",
		["text"] = "RADIO",
		["group"] = 2,
		["scene"] = "hideout",
		["shot"] = "radio",
		["parent"] = "hideout"
	},
	{
		["id"] = "hm_shooting_range",
		["text"] = "RANGE",
		["group"] = 2,
		["scene"] = "hideout",
		["shot"] = "shooting_range",
		["parent"] = "hideout"
	},
	{
		["id"] = "hm_trophy_wall",
		["text"] = "TROPHY WALL",
		["group"] = 2,
		["scene"] = "hideout",
		["shot"] = "trophy_wall",
		["parent"] = "hideout"
	}
}
local function v_u_10(p4, p5) -- name: listed
	local v6 = p5.flags or {}
	local v7 = p5.rules or {}
	if p5.hidden ~= nil and p5.hidden[p4.id] == true then
		return false
	end
	if p4.parent ~= nil and p5.hideoutV2 ~= true then
		return false
	end
	if p4.id == "crafting" and v6.Crafting ~= true then
		return false
	end
	if p4.id == "starter" and p5.starter ~= true then
		return false
	end
	local v8 = p4.flag == nil or v6[p4.flag] ~= false
	if v8 and (p4.id == "market" and p5.marketBlocked == true) then
		v8 = false
	end
	if v8 and p4.rule ~= nil then
		local v9 = v7[p4.rule]
		v8 = v9 == true
		if not v8 and p4.ruleNil == true then
			v8 = v9 == nil
		end
	end
	return v8
end
function v_u_1.visible(p11, p12) -- name: visible
	-- upvalues: (copy) v_u_10
	local v13 = {}
	for _, v14 in p11 do
		if not v_u_10(v14, p12) then
			continue
		end
		table.insert(v13, v14)
	end
	return v13
end
function v_u_1.byId(p15) -- name: byId
	-- upvalues: (copy) v_u_1
	for _, v16 in v_u_1.HOME do
		if v16.id ~= p15 then
			continue
		end
		return v16
	end
	for _, v17 in v_u_1.HIDEOUT do
		if v17.id ~= p15 then
			continue
		end
		return v17
	end
	return nil
end
local v_u_18 = {
	["play"] = { "deploy" },
	["starter"] = { "starter" },
	["character"] = { "character" },
	["traders"] = { "traders" },
	["market"] = { "market" },
	["tasks"] = { "tasks" },
	["hideout"] = { "hideout" },
	["pass"] = { "pass" },
	["clan"] = { "clan" },
	["store"] = { "store" },
	["settings"] = { "settings" },
	["collection"] = { "collection", "collection" },
	["badges"] = { "collection", "badges" },
	["leaderboard"] = { "collection", "leaderboard" },
	["skins"] = { "character", "skins" }
}
function v_u_1.fromOldTab(p19) -- name: fromOldTab
	-- upvalues: (copy) v_u_18
	local v20 = v_u_18[p19]
	if v20 == nil then
		return nil, nil
	else
		return v20[1], v20[2]
	end
end
function v_u_1.backOf(p21) -- name: backOf
	-- upvalues: (copy) v_u_1
	local v22 = v_u_1.byId(p21)
	return (v22 == nil or v22.parent ~= "hideout") and "home" or "hideout"
end
return v_u_1