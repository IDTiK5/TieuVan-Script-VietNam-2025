-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioWorld

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("CollectionService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = v_u_2.LocalPlayer
local v_u_10 = Random.new()
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = nil
local v_u_14 = Vector3.new(0, 0, 0)
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = nil
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = true
local v_u_21 = 0
local v_u_22 = -100
local v_u_23 = 0
local v_u_24 = Vector3.new(0, 0, 0)
local v_u_25 = false
local v_u_26 = {
	["ZR_RANGE"] = 60,
	["scale"] = 1,
	["farVoices"] = 0,
	["hbVol"] = 0,
	["hbAt"] = 0,
	["boostVol"] = 0,
	["boostUntil"] = 0
}
local function v_u_53(p27, p28, p29, p30) -- name: onHumanState
	-- upvalues: (ref) v_u_12, (ref) v_u_22, (ref) v_u_14, (ref) v_u_6, (copy) v_u_10, (ref) v_u_16, (ref) v_u_15
	if p29 == v_u_12.dead then
		if p30 - v_u_22 < 20 then
			return
		else
			local v31 = p27.x
			local v32 = p27.y + 4.8
			local v33 = p27.z
			local v34 = Vector3.new(v31, v32, v33)
			if (v34 - v_u_14).Magnitude <= 90 then
				v_u_6.zombie("humanDeath", v34, p27.typeId, true)
			end
		end
	else
		if p29 == v_u_12.stagger then
			if v_u_10:NextNumber() < 0.7 then
				if p30 - v_u_22 < 20 then
					return
				else
					local v35 = p27.x
					local v36 = p27.y + 4.8
					local v37 = p27.z
					local v38 = Vector3.new(v35, v36, v37)
					if (v38 - v_u_14).Magnitude <= 90 then
						v_u_6.zombie("humanPain", v38, p27.typeId, true)
					end
				end
			end
		elseif p29 == v_u_12.flee then
			if v_u_10:NextNumber() < 0.35 then
				if p30 - v_u_22 < 20 then
					return
				else
					local v39 = p27.x
					local v40 = p27.y + 4.8
					local v41 = p27.z
					local v42 = Vector3.new(v39, v40, v41)
					if (v42 - v_u_14).Magnitude > 90 then
						return
					else
						if p30 - v_u_16 >= 1 then
							v_u_16 = p30
							v_u_15 = 0
						end
						local v43
						if v_u_15 >= 4 then
							v43 = false
						else
							v_u_15 = v_u_15 + 1
							v43 = true
						end
						if v43 then
							v_u_6.zombie("humanPain", v42, p27.typeId, true)
						end
					end
				end
			end
		else
			if p29 == v_u_12.chase and (p28 == v_u_12.idle or (p28 == v_u_12.wander or (p28 == v_u_12.investigate or p28 == v_u_12.dormant))) then
				if p30 - v_u_22 >= 20 then
					local v44 = p27.x
					local v45 = p27.y + 4.8
					local v46 = p27.z
					local v47 = Vector3.new(v44, v45, v46)
					if (v47 - v_u_14).Magnitude <= 140 then
						v_u_6.zombie("humanShout", v47, p27.typeId, true)
					end
				end
				p27.nextVoice = p30 + v_u_10:NextNumber(5, 9)
				return
			end
			if p29 == v_u_12.aim and v_u_10:NextNumber() < 0.25 then
				if p30 - v_u_22 < 20 then
					return
				end
				local v48 = p27.x
				local v49 = p27.y + 4.8
				local v50 = p27.z
				local v51 = Vector3.new(v48, v49, v50)
				if (v51 - v_u_14).Magnitude > 140 then
					return
				end
				if p30 - v_u_16 >= 1 then
					v_u_16 = p30
					v_u_15 = 0
				end
				local v52
				if v_u_15 >= 4 then
					v52 = false
				else
					v_u_15 = v_u_15 + 1
					v52 = true
				end
				if not v52 then
					return
				end
				v_u_6.zombie("humanShout", v51, p27.typeId, true)
			end
		end
		return
	end
end
local function v_u_90(_, p54, p55, p56, p57, _, p58, p59, p60) -- name: onRecord
	-- upvalues: (copy) v_u_11, (ref) v_u_8, (copy) v_u_10, (copy) v_u_53, (ref) v_u_12, (ref) v_u_20, (ref) v_u_14, (copy) v_u_26, (ref) v_u_6, (ref) v_u_16, (ref) v_u_15
	local v61 = os.clock()
	local v62 = v_u_11[p54]
	if v62 then
		local v63 = v62.state
		v62.x = p55
		v62.y = p56
		v62.z = p57
		v62.flags = p60
		v62.seen = v61
		if p59 ~= v63 then
			v62.state = p59
			if v62.human then
				v_u_53(v62, v63, p59, v61)
				return
			end
			if p59 == v_u_12.scream then
				if v_u_20 then
					local v64 = v62.x
					local v65 = v62.y + 4.5
					local v66 = v62.z
					local v67 = Vector3.new(v64, v65, v66)
					if (v67 - v_u_14).Magnitude <= 260 * v_u_26.scale then
						v_u_6.zombie("scream", v67, v62.typeId, true)
					end
				else
					return
				end
			end
			if p59 == v_u_12.attack and v61 - v62.lastAttack > 0.8 then
				v62.lastAttack = v61
				if v_u_20 then
					local v68 = v62.x
					local v69 = v62.y + 4.5
					local v70 = v62.z
					local v71 = Vector3.new(v68, v69, v70)
					if (v71 - v_u_14).Magnitude <= 75 * v_u_26.scale then
						v_u_6.zombie("attack", v71, v62.typeId, true)
					end
				else
					return
				end
			end
			if p59 == v_u_12.dead then
				if v_u_20 then
					local v72 = v62.x
					local v73 = v62.y + 4.5
					local v74 = v62.z
					local v75 = Vector3.new(v72, v73, v74)
					if (v75 - v_u_14).Magnitude <= 75 * v_u_26.scale then
						v_u_6.zombie("die", v75, v62.typeId, true)
					end
				else
					return
				end
			end
			if p59 == v_u_12.stagger then
				if v_u_10:NextNumber() < 0.6 then
					if v_u_20 then
						local v76 = v62.x
						local v77 = v62.y + 4.5
						local v78 = v62.z
						local v79 = Vector3.new(v76, v77, v78)
						if (v79 - v_u_14).Magnitude > 75 * v_u_26.scale then
							return
						else
							if v61 - v_u_16 >= 1 then
								v_u_16 = v61
								v_u_15 = 0
							end
							local v80
							if v_u_15 >= 4 then
								v80 = false
							else
								v_u_15 = v_u_15 + 1
								v80 = true
							end
							if v80 then
								v_u_6.zombie("pain", v79, v62.typeId, true)
							end
						end
					else
						return
					end
				end
			else
				if p59 == v_u_12.chase and (v63 == v_u_12.idle or (v63 == v_u_12.wander or (v63 == v_u_12.investigate or (v63 == v_u_12.dormant or v63 == v_u_12.lying)))) then
					if v_u_20 then
						local v81 = v62.x
						local v82 = v62.y + 4.5
						local v83 = v62.z
						local v84 = Vector3.new(v81, v82, v83)
						if (v84 - v_u_14).Magnitude <= 75 * v_u_26.scale then
							if v61 - v_u_16 >= 1 then
								v_u_16 = v61
								v_u_15 = 0
							end
							local v85
							if v_u_15 >= 4 then
								v85 = false
							else
								v_u_15 = v_u_15 + 1
								v85 = true
							end
							if v85 then
								v_u_6.zombie("alert", v84, v62.typeId, true)
							end
						end
					end
					v62.nextVoice = v61 + v_u_10:NextNumber(2, 4)
					return
				end
				if p59 == v_u_12.bash then
					v62.nextBash = v61
				end
			end
		end
	else
		local v86 = {
			["x"] = nil,
			["y"] = nil,
			["z"] = nil,
			["typeId"] = nil,
			["state"] = nil,
			["flags"] = nil,
			["seen"] = nil,
			["nextVoice"] = nil,
			["nextBash"] = 0,
			["lastAttack"] = 0,
			["px"] = nil,
			["pz"] = nil,
			["stride"] = 0,
			["human"] = nil,
			["x"] = p55,
			["y"] = p56,
			["z"] = p57
		}
		local v87 = v_u_8 and v_u_8.byIndex
		if v87 then
			v87 = v_u_8.byIndex[p58]
		end
		v86.typeId = not v87 and "walker" or v87.id
		v86.state = p59
		v86.flags = p60
		v86.seen = v61
		v86.nextVoice = v61 + v_u_10:NextNumber(1, 9)
		v86.px = p55
		v86.pz = p57
		local v88 = v_u_8 and v_u_8.byIndex
		if v88 then
			v88 = v_u_8.byIndex[p58]
		end
		local v89
		if v88 == nil then
			v89 = false
		else
			v89 = v88.human == true
		end
		v86.human = v89
		v_u_11[p54] = v86
	end
end
local v_u_91 = 0
local v_u_92 = 0
local function v_u_169(p93) -- name: stepZombies
	-- upvalues: (ref) v_u_92, (ref) v_u_91, (copy) v_u_26, (ref) v_u_6, (ref) v_u_20, (copy) v_u_11, (ref) v_u_14, (ref) v_u_12, (copy) v_u_10, (ref) v_u_22, (ref) v_u_16, (ref) v_u_15, (ref) v_u_25, (ref) v_u_24, (ref) v_u_23, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19
	if p93 - v_u_92 >= 1 then
		v_u_92 = p93
		v_u_91 = 0
	end
	local v94 = v_u_26
	local v95 = v_u_6
	if v95 then
		v95 = v_u_6.hearing
	end
	local v96
	if type(v95) == "function" then
		local v97, v98 = pcall(v95)
		v96 = (not v97 or (type(v98) ~= "number" or v98 < 1)) and 1 or v98
	else
		v96 = 1
	end
	v94.scale = v96
	local v99 = v_u_26.scale
	local v100
	if v99 > 1.02 then
		v100 = not v_u_20
	else
		v100 = false
	end
	local v101 = 0
	local v102 = 0
	local v103 = nil
	local v104 = 0
	local v105 = 0
	local v106 = 0
	local v107 = 0
	local v108 = 0
	for v109, v110 in v_u_11 do
		if p93 - v110.seen > 2 then
			v103 = v103 or {}
			table.insert(v103, v109)
		else
			local v111 = v110.x - v_u_14.X
			local v112 = v110.z - v_u_14.Z
			local v113 = v111 * v111 + v112 * v112
			local v114 = math.sqrt(v113)
			local v115 = v110.state
			if v115 == v_u_12.dead then
				continue
			end
			if v110.human then
				if (v115 == v_u_12.chase or v115 == v_u_12.aim) and v114 < 90 then
					v104 = v104 + 1
				end
				if v115 ~= v_u_12.chase and v115 ~= v_u_12.aim or v110.nextVoice > p93 then
					continue
				end
				v110.nextVoice = p93 + v_u_10:NextNumber(6, 14)
				if v_u_10:NextNumber() >= 0.45 then
					continue
				end
				if p93 - v_u_22 < 20 then
					continue
				end
				local v116 = v110.x
				local v117 = v110.y + 4.8
				local v118 = v110.z
				local v119 = Vector3.new(v116, v117, v118)
				if (v119 - v_u_14).Magnitude > 140 then
					continue
				end
				if p93 - v_u_16 >= 1 then
					v_u_16 = p93
					v_u_15 = 0
				end
				local v120
				if v_u_15 >= 4 then
					v120 = false
				else
					v_u_15 = v_u_15 + 1
					v120 = true
				end
				if not v120 then
					continue
				end
				v_u_6.zombie("humanShout", v119, v110.typeId, true)
			else
				if v114 < 45 then
					v105 = v105 + 1
					v106 = v106 + v110.x
					v107 = v107 + v110.y
					v101 = v101 + v110.z
					v102 = v102 + 1
				end
				local v121 = v110.flags
				local v122 = bit32.btest(v121, 128)
				if (v115 == v_u_12.chase or (v115 == v_u_12.attack or v115 == v_u_12.bash)) and v114 < 60 then
					v104 = v104 + (v122 and 1 or 0.5)
				end
				if (v115 == v_u_12.attack or v115 == v_u_12.bash) and v114 < 14 then
					v108 = v108 + 1
				end
				local v123 = v110.x - v110.px
				local v124 = v110.z - v110.pz
				local v125 = v123 * v123 + v124 * v124
				local v126 = math.sqrt(v125)
				local v127 = v110.x
				local v128 = v110.z
				v110.px = v127
				v110.pz = v128
				if v114 < 30 * v99 and (v126 > 0.05 and v126 < 8) then
					v110.stride = v110.stride + v126
					local v129 = v110.flags
					local v130 = bit32.btest(v129, 8)
					if (v130 and 5 or (v110.typeId == "brute" and 3.6 or 2.6)) <= v110.stride then
						v110.stride = 0
						if v_u_91 < 7 then
							v_u_91 = v_u_91 + 1
							local v131 = v110.x
							local v132 = v110.y
							local v133 = v110.z
							local v134 = Vector3.new(v131, v132, v133)
							local v135 = (v130 and 0.55 or (v110.typeId == "brute" and 0.6 or 0.32)) * (1 - v114 / (30 * v99) * 0.6) * v99
							local v136 = v_u_6._voices.play("step_dirt", {
								["pos"] = v134,
								["volume"] = v135,
								["pitch"] = v110.typeId == "brute" and 0.75 or 0.85
							})
							v_u_6._voices.occludeNow(v136)
						end
					end
				else
					v110.stride = 0
				end
				if v115 == v_u_12.bash and (v110.nextBash <= p93 and (v_u_20 and not v_u_25)) then
					v110.nextBash = p93 + v_u_10:NextNumber(0.9, 1.4)
					if v114 < 140 then
						local v137 = v_u_6.zombie
						local v138 = v110.x
						local v139 = v110.y + 3
						local v140 = v110.z
						v137("bash", Vector3.new(v138, v139, v140), v110.typeId, true)
					end
				end
				if v100 and (v_u_26.ZR_RANGE + 2 < v114 and (v114 < v_u_26.ZR_RANGE * v99 and (v110.nextVoice <= p93 and (v115 ~= v_u_12.dormant and v115 ~= v_u_12.lying)))) then
					local v141
					if v115 == v_u_12.chase then
						v141 = v_u_10:NextNumber(2.5, 5)
					else
						v141 = v_u_10:NextNumber(6, 14)
					end
					v110.nextVoice = p93 + v141
					if v_u_10:NextNumber() < 0.75 then
						if p93 - v_u_16 >= 1 then
							v_u_16 = p93
							v_u_15 = 0
						end
						local v142
						if v_u_15 >= 4 then
							v142 = false
						else
							v_u_15 = v_u_15 + 1
							v142 = true
						end
						if v142 then
							local v143 = v_u_26
							v143.farVoices = v143.farVoices + 1
							local v144 = v115 == v_u_12.chase and (v110.typeId == "runner" or v110.typeId == "screamer") and "alert" or "groan"
							local v145 = v_u_6.zombie
							local v146 = v110.x
							local v147 = v110.y + 4.5
							local v148 = v110.z
							v145(v144, Vector3.new(v146, v147, v148), v110.typeId, true)
						end
					end
				end
				if v110.nextVoice > p93 or v114 >= 75 * v99 then
					continue
				end
				local v149 = "groan"
				local v150 = 7
				local v151 = 18
				if v115 == v_u_12.chase then
					v150 = 2.2
					v151 = 4.5
					if v110.typeId == "runner" or v110.typeId == "screamer" then
						v149 = "alert"
					end
				elseif v115 == v_u_12.investigate then
					v151 = 9
					v150 = 4
				elseif v115 == v_u_12.dormant or v115 == v_u_12.lying then
					v151 = 30
					v150 = 14
				elseif v115 == v_u_12.stagger or (v115 == v_u_12.aim or v115 == v_u_12.flee) then
					v151 = 6
					v149 = ""
					v150 = 3
				end
				v110.nextVoice = p93 + v_u_10:NextNumber(v150, v151)
				if v149 == "" or (v_u_10:NextNumber() >= 0.75 or v110.typeId == "looter") then
					continue
				end
				if not v_u_20 then
					continue
				end
				local v152 = v110.x
				local v153 = v110.y + 4.5
				local v154 = v110.z
				local v155 = Vector3.new(v152, v153, v154)
				if (v155 - v_u_14).Magnitude > (v149 == "scream" and 260 or 75) * v_u_26.scale then
					continue
				end
				if p93 - v_u_16 >= 1 then
					v_u_16 = p93
					v_u_15 = 0
				end
				local v156
				if v_u_15 >= 4 then
					v156 = false
				else
					v_u_15 = v_u_15 + 1
					v156 = true
				end
				if not v156 then
					continue
				end
				v_u_6.zombie(v149, v155, v110.typeId, true)
			end
		end
	end
	if v103 then
		for _, v157 in v103 do
			v_u_11[v157] = nil
		end
	end
	local v158 = (v105 - 5) / 14
	local v159 = math.clamp(v158, 0, 1)
	local v160
	if v102 > 0 then
		local v161 = v106 / v102
		local v162 = v107 / v102 + 3
		local v163 = v101 / v102
		v160 = Vector3.new(v161, v162, v163)
	else
		v160 = v_u_24
	end
	if p93 < v_u_23 then
		v159 = math.max(v159, 0.55)
		if v102 == 0 then
			v160 = v_u_24
		end
	end
	if v159 > 0.02 then
		if not (v_u_17 and v_u_17:alive()) then
			v_u_17 = v_u_6._voices.bed("z_horde", {
				["pos"] = nil,
				["volume"] = 0.01,
				["fadeIn"] = 2,
				["group"] = "AmbWorld",
				["pos"] = v160
			})
		end
		if v_u_17 then
			v_u_17:setPosition(v160)
			local v164 = v159 - v_u_18
			if math.abs(v164) > 0.04 then
				v_u_18 = v159
				v_u_17:setVolume((v159 * 1.1 + 0.25) * v99, 1.2)
			end
		end
	elseif v_u_17 then
		v_u_17:stop(3)
		v_u_17 = nil
		v_u_18 = 0
	end
	local v165 = v104 / 3
	local v166 = math.clamp(v165, 0, 1) * 0.8 + math.clamp(v108, 0, 1) * 0.5
	local v167 = (v105 - 6) / 20
	local v168 = v166 + math.clamp(v167, 0, 0.3)
	v_u_19 = math.clamp(v168, 0, 1)
end
v_u_5._record = v_u_90
function v_u_5.threat() -- name: threat
	-- upvalues: (ref) v_u_19
	return v_u_19
end
function v_u_5.zombieCount() -- name: zombieCount
	-- upvalues: (copy) v_u_11
	local v170 = 0
	for _ in v_u_11 do
		v170 = v170 + 1
	end
	return v170
end
function v_u_5.noteExternalZombie() -- name: noteExternalZombie
	-- upvalues: (ref) v_u_21
	v_u_21 = os.clock()
end
function v_u_5.noteExternalHuman() -- name: noteExternalHuman
	-- upvalues: (ref) v_u_22
	v_u_22 = os.clock()
end
function v_u_5.externalHorde(p171) -- name: externalHorde
	-- upvalues: (ref) v_u_23, (ref) v_u_24
	v_u_23 = os.clock() + 5
	v_u_24 = p171 + Vector3.new(0, 3, 0)
end
local v_u_172 = {}
local function v_u_176(p173) -- name: cancelReload
	for _, v174 in p173.reload do
		local v175 = task.cancel
		pcall(v175, v174)
	end
	table.clear(p173.reload)
end
local function v_u_196(p_u_177) -- name: startReload
	-- upvalues: (copy) v_u_176, (ref) v_u_7, (copy) v_u_1, (ref) v_u_6, (copy) v_u_9
	v_u_176(p_u_177)
	local v178 = p_u_177.model:GetAttribute("Weapon")
	if type(v178) == "string" and v178 ~= "" then
		local v179 = v_u_7.weapons[v178]
		if v179 then
			local v180 = v179.reloadTime
			local v181 = p_u_177.model:GetAttribute("ReloadEndsAt")
			local v182 = type(v181) ~= "number" and 0 or v181 - v_u_1.now()
			if v182 > 0.3 and v182 < 10 then
				v180 = v182
			else
				local v183 = v_u_6._weapons
				if v183 and v183.get then
					local v184 = v183.get
					local v185, v186 = pcall(v184, v178)
					if v185 and type(v186) == "table" then
						local v187 = v186.reloadTime
						if type(v187) == "number" then
							v180 = v186.reloadTime
						end
					end
				end
			end
			for _, v_u_188 in v179.reload do
				local v194 = task.delay(v_u_188.t * v180, function()
					-- upvalues: (copy) p_u_177, (ref) v_u_9, (ref) v_u_6, (copy) v_u_188
					local v189 = p_u_177.root
					local v190
					if v189 and v189.Parent then
						v190 = v189.Position
					else
						v190 = nil
					end
					if v190 then
						if p_u_177.model:GetAttribute("Reloading") == true then
							v_u_6.play3D(v_u_188.s, v190 + Vector3.new(0, 1, 0), {
								["volume"] = nil,
								["auto"] = true,
								["volume"] = p_u_177.isLocal and 1.15 or 0.9
							})
						else
							local v191 = p_u_177
							local v192 = v_u_9:GetAttribute("PredReloadAt")
							local v193 = v191.isLocal
							if v193 then
								if type(v192) == "number" then
									v193 = os.clock() - v192 < 1.8
								else
									v193 = false
								end
							end
							if not v193 then
								return
							end
							v_u_6.play3D(v_u_188.s, v190 + Vector3.new(0, 1, 0), {
								["volume"] = nil,
								["auto"] = true,
								["volume"] = p_u_177.isLocal and 1.15 or 0.9
							})
						end
					end
				end)
				local v195 = p_u_177.reload
				table.insert(v195, v194)
			end
		end
	else
		return
	end
end
local v_u_197 = {
	["Bandage"] = { "item_bandage", 1.6 },
	["Search"] = { "item_search", 1.8 },
	["Use"] = { "item_pills", 0 },
	["Revive"] = { "cloth", 1.2 }
}
local function v_u_211(p_u_198, p_u_199) -- name: startAction
	-- upvalues: (copy) v_u_197, (copy) v_u_9, (ref) v_u_6, (copy) v_u_10
	if p_u_198.actionThread then
		local v200 = task.cancel
		local v201 = p_u_198.actionThread
		pcall(v200, v201)
		p_u_198.actionThread = nil
	end
	local v_u_202 = v_u_197[p_u_199]
	if v_u_202 then
		p_u_198.actionThread = task.spawn(function()
			-- upvalues: (copy) p_u_198, (copy) p_u_199, (ref) v_u_9, (ref) v_u_6, (copy) v_u_202, (ref) v_u_10
			while p_u_198.model.Parent do
				if p_u_198.model:GetAttribute("Action") ~= p_u_199 then
					local v203 = p_u_199
					local v204 = p_u_198.isLocal
					if v204 then
						if v_u_9:GetAttribute("PredAction") == v203 then
							local v205 = v_u_9
							v204 = os.clock() < (tonumber(v205:GetAttribute("PredActionEnds")) or 0)
						else
							v204 = false
						end
					end
					if not v204 then
						break
					end
				end
				local v206 = p_u_198.root
				local v207
				if v206 and v206.Parent then
					v207 = v206.Position
				else
					v207 = nil
				end
				if v207 then
					v_u_6.play3D(v_u_202[1], v207, {
						["auto"] = true
					})
					if p_u_199 == "Search" and v_u_10:NextNumber() < 0.5 then
						task.delay(0.6, function()
							-- upvalues: (ref) p_u_198, (ref) v_u_6
							local v208 = p_u_198.root
							local v209
							if v208 and v208.Parent then
								v209 = v208.Position
							else
								v209 = nil
							end
							if v209 then
								v_u_6.play3D("item_rummage", v209, {
									["auto"] = true
								})
							end
						end)
					end
				end
				local v210 = v_u_202[2]
				if v210 <= 0 then
					break
				end
				task.wait(v210 * v_u_10:NextNumber(0.85, 1.15))
			end
			p_u_198.actionThread = nil
		end)
	end
end
local function v_u_217(p212) -- name: untrack
	-- upvalues: (copy) v_u_172, (copy) v_u_176
	local v213 = v_u_172[p212]
	if v213 then
		v_u_172[p212] = nil
		for _, v214 in v213.conns do
			v214:Disconnect()
		end
		v_u_176(v213)
		if v213.actionThread then
			local v215 = task.cancel
			local v216 = v213.actionThread
			pcall(v215, v216)
		end
		if v213.heartbeat then
			v213.heartbeat:stop(1)
		end
	end
end
local function v_u_237(p218) -- name: updateHeartbeat
	-- upvalues: (ref) v_u_6, (copy) v_u_26
	if p218.isLocal then
		local v219 = p218.model:GetAttribute("Dead") == true
		local v220
		if p218.model:GetAttribute("Downed") == true then
			v220 = not v219
		else
			v220 = false
		end
		local v221 = p218.model:GetAttribute("Hp")
		local v222 = v_u_6
		if v222 then
			v222 = v_u_6._guard
		end
		local v223
		if v222 then
			v223 = v222.lowHp(p218.lowOn == true, v221)
		elseif type(v221) == "number" and v221 > 0 then
			v223 = v221 < 30
		else
			v223 = false
		end
		p218.lowOn = v223
		local v224 = (not v_u_6 or (not v_u_6.infection or v219)) and 0 or v_u_6.infection()
		local v225
		if v224 > 0 then
			v225 = true
		elseif p218.model:GetAttribute("Infected") == true then
			v225 = not v219
		else
			v225 = false
		end
		local v226 = not v225 and 0 or 0.12 + 0.18 * v224
		local v227
		if v225 and (v_u_6 and v_u_6.infectionBedVol) then
			local v228 = v_u_6.infectionBedVol
			local v229
			v229, v227 = pcall(v228)
			if v229 then
				if type(v227) ~= "number" then
					v227 = v226
				end
			else
				v227 = v226
			end
		else
			v227 = v226
		end
		if v225 and os.clock() < v_u_26.boostUntil then
			local v230 = v_u_26.boostVol
			v227 = math.max(v227, v230)
		end
		local v231
		if v220 then
			v231 = 1
		elseif v223 then
			v231 = math.max(0.6, v227)
		else
			v231 = v227
		end
		local v232
		if v220 or (v223 or v227 > 0) then
			v232 = not v219
		else
			v232 = false
		end
		v_u_26.hbVol = not v232 and 0 or v231
		if v232 and not (p218.heartbeat and p218.heartbeat:alive()) then
			p218.heartbeat = v_u_6._voices.bed("ev_heartbeat", {
				["volume"] = nil,
				["fadeIn"] = 1.5,
				["volume"] = v231
			})
		elseif v232 and p218.heartbeat then
			p218.heartbeat:setVolume(v231, 0.5)
		elseif not v232 and p218.heartbeat then
			p218.heartbeat:stop(2)
			p218.heartbeat = nil
		end
		local v233 = v_u_6._controller("Camera")
		local v234
		if v219 then
			if v233 == nil or v233.mode == nil then
				v234 = false
			else
				v234 = v233.mode() == "spectate"
			end
		else
			v234 = v219
		end
		local v235 = v_u_6._setMuffle
		local v236
		if v219 then
			v236 = v234 and 0.15 or 0.85
		else
			v236 = v220 and 0.75 or 0
		end
		v235(v236)
	end
end
local function v_u_318(p_u_238, p239) -- name: track
	-- upvalues: (copy) v_u_172, (copy) v_u_9, (copy) v_u_196, (copy) v_u_176, (ref) v_u_6, (copy) v_u_211, (copy) v_u_197, (copy) v_u_237, (ref) v_u_7, (copy) v_u_217
	if not v_u_172[p_u_238] then
		local v_u_240 = {
			["model"] = nil,
			["root"] = nil,
			["hum"] = nil,
			["isLocal"] = nil,
			["dist"] = 0,
			["lastPos"] = nil,
			["externalSteps"] = 0,
			["conns"] = nil,
			["reload"] = nil,
			["actionThread"] = nil,
			["lastHp"] = 100,
			["lastHurt"] = 0,
			["lastShotAt"] = 0,
			["heartbeat"] = nil,
			["model"] = p_u_238,
			["isLocal"] = p239 == v_u_9,
			["conns"] = {},
			["reload"] = {}
		}
		v_u_172[p_u_238] = v_u_240
		local v241 = p_u_238:GetAttribute("Hp")
		if type(v241) == "number" then
			v_u_240.lastHp = v241
		end
		local v242 = p_u_238:GetAttribute("LastShotAt")
		if type(v242) == "number" then
			v_u_240.lastShotAt = v242
		end
		local function v_u_246()
			-- upvalues: (copy) p_u_238, (copy) v_u_240, (ref) v_u_9, (ref) v_u_196, (ref) v_u_176
			if p_u_238:GetAttribute("Reloading") == true then
				local v243 = v_u_240
				local v244 = v_u_9:GetAttribute("PredReloadAt")
				local v245 = v243.isLocal
				if v245 then
					if type(v244) == "number" then
						v245 = os.clock() - v244 < 1.8
					else
						v245 = false
					end
				end
				if not v245 or #v_u_240.reload <= 0 then
					v_u_196(v_u_240)
				end
			else
				v_u_176(v_u_240)
				return
			end
		end
		local v247 = v_u_240.conns
		local v248 = p_u_238:GetAttributeChangedSignal("Reloading")
		table.insert(v247, v248:Connect(function()
			-- upvalues: (copy) v_u_246
			local v249 = v_u_246
			pcall(v249)
		end))
		local function v_u_253()
			-- upvalues: (copy) v_u_240, (copy) p_u_238, (ref) v_u_6
			local v250 = v_u_240.root
			local v251
			if v250 and v250.Parent then
				v251 = v250.Position
			else
				v251 = nil
			end
			local v252 = p_u_238:GetAttribute("Weapon")
			if v251 and (type(v252) == "string" and v252 ~= "") then
				v_u_6.play3D("wpn_equip", v251 + Vector3.new(0, 1, 0), {
					["volume"] = nil,
					["auto"] = true,
					["volume"] = v_u_240.isLocal and 1 or 0.8
				})
			end
		end
		local v254 = v_u_240.conns
		local v255 = p_u_238:GetAttributeChangedSignal("Weapon")
		table.insert(v254, v255:Connect(function()
			-- upvalues: (copy) v_u_253
			local v256 = v_u_253
			pcall(v256)
		end))
		local function v_u_260()
			-- upvalues: (copy) p_u_238, (copy) v_u_240, (ref) v_u_211
			local v257 = p_u_238:GetAttribute("Action")
			if type(v257) == "string" and v257 ~= "" then
				if v_u_240.predKind == v257 and os.clock() - (v_u_240.predAt or 0) < 2 then
					v_u_240.predKind = nil
				else
					v_u_211(v_u_240, v257)
				end
			else
				if v_u_240.actionThread then
					local v258 = task.cancel
					local v259 = v_u_240.actionThread
					pcall(v258, v259)
					v_u_240.actionThread = nil
				end
				return
			end
		end
		local v261 = v_u_240.conns
		local v262 = p_u_238:GetAttributeChangedSignal("Action")
		table.insert(v261, v262:Connect(function()
			-- upvalues: (copy) v_u_260
			local v263 = v_u_260
			pcall(v263)
		end))
		if v_u_240.isLocal then
			local v264 = v_u_240.conns
			local v265 = v_u_9:GetAttributeChangedSignal("PredReloadAt")
			local function v271()
				-- upvalues: (copy) v_u_240, (ref) v_u_9, (copy) p_u_238, (ref) v_u_196
				local v266 = v_u_240
				local v267 = v_u_9:GetAttribute("PredReloadAt")
				local v268 = v266.isLocal
				if v268 then
					if type(v267) == "number" then
						v268 = os.clock() - v267 < 1.8
					else
						v268 = false
					end
				end
				if v268 and p_u_238:GetAttribute("Reloading") ~= true then
					local v269 = v_u_196
					local v270 = v_u_240
					pcall(v269, v270)
				end
			end
			table.insert(v264, v265:Connect(v271))
			local v272 = v_u_240.conns
			local v273 = v_u_9:GetAttributeChangedSignal("PredAction")
			local function v282()
				-- upvalues: (ref) v_u_9, (ref) v_u_197, (copy) p_u_238, (copy) v_u_240, (ref) v_u_211
				local v274 = v_u_9:GetAttribute("PredAction")
				if type(v274) == "string" and (v_u_197[v274] and p_u_238:GetAttribute("Action") ~= v274) then
					local v275 = v_u_240.isLocal
					if v275 then
						if v_u_9:GetAttribute("PredAction") == v274 then
							local v276 = v_u_9
							v275 = os.clock() < (tonumber(v276:GetAttribute("PredActionEnds")) or 0)
						else
							v275 = false
						end
					end
					if v275 then
						local v277 = v_u_211
						local v278 = v_u_240
						pcall(v277, v278, v274)
						local v279 = v_u_240
						local v280 = v_u_240
						local v281 = os.clock()
						v279.predKind = v274
						v280.predAt = v281
					end
				end
			end
			table.insert(v272, v273:Connect(v282))
		end
		local function v_u_285()
			-- upvalues: (copy) p_u_238, (copy) v_u_240, (ref) v_u_6, (ref) v_u_237
			local v283 = p_u_238:GetAttribute("Hp")
			if type(v283) == "number" then
				local v284 = os.clock()
				if v_u_240.isLocal and (v283 < v_u_240.lastHp - 4 and (v284 - v_u_240.lastHurt > 0.7 and v283 > 0)) then
					v_u_240.lastHurt = v284
					v_u_6.play("ev_hurt", {
						["auto"] = true
					})
				end
				v_u_240.lastHp = v283
				v_u_237(v_u_240)
			end
		end
		local v286 = v_u_240.conns
		local v287 = p_u_238:GetAttributeChangedSignal("Hp")
		table.insert(v286, v287:Connect(function()
			-- upvalues: (copy) v_u_285
			local v288 = v_u_285
			pcall(v288)
		end))
		local function v_u_291()
			-- upvalues: (copy) v_u_240, (copy) p_u_238, (ref) v_u_6, (ref) v_u_237
			local v289 = v_u_240.root
			local v290
			if v289 and v289.Parent then
				v290 = v289.Position
			else
				v290 = nil
			end
			if p_u_238:GetAttribute("Downed") == true and v290 then
				v_u_6.play3D("bodyfall", v290, {
					["auto"] = true
				})
			end
			v_u_237(v_u_240)
		end
		local v292 = v_u_240.conns
		local v293 = p_u_238:GetAttributeChangedSignal("Downed")
		table.insert(v292, v293:Connect(function()
			-- upvalues: (copy) v_u_291
			local v294 = v_u_291
			pcall(v294)
		end))
		local function v_u_297()
			-- upvalues: (copy) p_u_238, (copy) v_u_240, (ref) v_u_6, (ref) v_u_237
			if p_u_238:GetAttribute("Dead") == true then
				local v295 = v_u_240.root
				local v296
				if v295 and v295.Parent then
					v296 = v295.Position
				else
					v296 = nil
				end
				if v296 then
					v_u_6.play3D("bodyfall", v296, {
						["auto"] = true
					})
				end
				if v_u_240.isLocal then
					v_u_6.ui("death")
					v_u_6.setMusicState("silent")
				end
			end
			v_u_237(v_u_240)
		end
		local v298 = v_u_240.conns
		local v299 = p_u_238:GetAttributeChangedSignal("Dead")
		table.insert(v298, v299:Connect(function()
			-- upvalues: (copy) v_u_297
			local v300 = v_u_297
			pcall(v300)
		end))
		local function v_u_310()
			-- upvalues: (copy) p_u_238, (copy) v_u_240, (ref) v_u_7, (ref) v_u_6
			local v301 = p_u_238:GetAttribute("LastShotAt")
			if type(v301) == "number" and v301 > v_u_240.lastShotAt then
				v_u_240.lastShotAt = v301
				local v_u_302 = p_u_238:GetAttribute("Weapon")
				local v303 = v_u_240.root
				local v_u_304
				if v303 and v303.Parent then
					v_u_304 = v303.Position
				else
					v_u_304 = nil
				end
				if v_u_304 and (type(v_u_302) == "string" and v_u_7.weapons[v_u_302]) then
					local v_u_305 = v_u_240
					local v_u_306 = p_u_238:GetAttribute("Suppressed") == true
					task.delay(0.12, function()
						-- upvalues: (copy) v_u_305, (copy) v_u_304, (ref) v_u_6, (copy) v_u_302, (copy) v_u_306
						local v307 = v_u_305.root
						local v308
						if v307 and v307.Parent then
							v308 = v307.Position
						else
							v308 = nil
						end
						local v309 = v308 or v_u_304
						v_u_6._autoGunshot(v_u_302, v309 + Vector3.new(0, 1.5, 0), v_u_305.isLocal, v_u_306)
					end)
				end
			end
		end
		local v311 = v_u_240.conns
		local v312 = p_u_238:GetAttributeChangedSignal("LastShotAt")
		table.insert(v311, v312:Connect(function()
			-- upvalues: (copy) v_u_310
			local v313 = v_u_310
			pcall(v313)
		end))
		local v314 = v_u_240.conns
		local v315 = p_u_238.AncestryChanged
		local function v317(_, p316)
			-- upvalues: (ref) v_u_217, (copy) p_u_238
			if p316 == nil then
				v_u_217(p_u_238)
			end
		end
		table.insert(v314, v315:Connect(v317))
		v_u_237(v_u_240)
	end
end
function v_u_5.noteExternalFootstep(p319) -- name: noteExternalFootstep
	-- upvalues: (copy) v_u_172
	local v320 = v_u_172[p319]
	if v320 then
		v320.externalSteps = os.clock()
	end
end
local v_u_321 = 0
local function v_u_343(p322, p323) -- name: stepCharacters
	-- upvalues: (ref) v_u_321, (copy) v_u_2, (copy) v_u_172, (copy) v_u_318, (ref) v_u_14, (ref) v_u_6, (copy) v_u_217
	if v_u_321 <= p322 then
		v_u_321 = p322 + 0.5
		for _, v324 in v_u_2:GetPlayers() do
			local v325 = v324.Character
			if not v325 or v_u_172[v325] then
				continue
			end
			v_u_318(v325, v324)
		end
	end
	local v326 = nil
	for v327, v328 in v_u_172 do
		if v327.Parent then
			if not (v328.root and v328.root.Parent) then
				v328.root = v327:FindFirstChild("HumanoidRootPart")
				v328.hum = v327:FindFirstChildOfClass("Humanoid")
				v328.lastPos = nil
				if not v328.root then
					continue
				end
			end
			local v329 = v328.root.Position
			local v330 = v328.lastPos
			v328.lastPos = v329
			if not v330 or p322 - v328.externalSteps < 2 then
				continue
			end
			if v328.isLocal or (v329 - v_u_14).Magnitude <= 90 then
				local v331 = v328.hum
				if v331 and (v331.FloorMaterial ~= Enum.Material.Air and v327:GetAttribute("Dead") ~= true) then
					local v332 = v329.X - v330.X
					local v333 = v329.Z - v330.Z
					local v334 = Vector3.new(v332, 0, v333).Magnitude
					if v334 > 6 then
						continue
					end
					local v335 = v334 / math.max(p323, 0.001)
					if v335 < 1.5 then
						local v336 = v328.dist
						v328.dist = math.min(v336, 2.4200000000000004)
					else
						v328.dist = v328.dist + v334
						local v337 = 4.4 * (0.6 + v335 / 26)
						local v338 = math.clamp(v337, 3, 6.5)
						if v338 > v328.dist then
							continue
						end
						v328.dist = v328.dist - v338
						local v339 = v327:GetAttribute("Sneaking") == true
						local v340 = v327:GetAttribute("Sprinting") == true and true or v335 > 15
						local v341 = v327:GetAttribute("Downed") == true and 0.4 or (v339 and 0.35 or (v340 and 1.25 or 0.85))
						v_u_6._step(v327, v331.FloorMaterial, v329 - Vector3.new(0, 2.8, 0), v341 * (v328.isLocal and 1 or 0.9), true)
					end
				else
					v328.dist = 0
				end
			else
				v328.dist = 0
			end
		else
			v326 = v326 or {}
			table.insert(v326, v327)
		end
	end
	if v326 then
		for _, v342 in v326 do
			v_u_217(v342)
		end
	end
end
local v_u_344 = {}
local v_u_345 = {}
local function v_u_349(p_u_346) -- name: pivotPos
	if p_u_346:IsA("Model") then
		local v347, v348 = pcall(function()
			-- upvalues: (copy) p_u_346
			return p_u_346:GetPivot()
		end)
		if v347 then
			return v348.Position
		end
	elseif p_u_346:IsA("BasePart") then
		return p_u_346.Position
	end
	return nil
end
local v_u_350 = {}
local v_u_351 = {}
local v_u_352 = {
	["open"] = 0,
	["close"] = 0,
	["creak"] = 0,
	["echoDropped"] = 0,
	["claimDropped"] = 0,
	["own"] = 0
}
local function v_u_361(p353, p354, p355) -- name: claimDoor
	-- upvalues: (ref) v_u_350
	if p353 == "" then
		return false
	end
	local v356 = os.clock()
	local v357 = p353 .. "|" .. p354
	local v358 = v_u_350[v357]
	if v358 and v356 - v358 < 3 then
		return true
	end
	if v358 == nil then
		for v359, v360 in v_u_350 do
			if v356 - v360 <= 3 then
				continue
			end
			v_u_350[v359] = nil
		end
	end
	v_u_350[v357] = v356
	if not p355 then
		v_u_350[p353 .. "|" .. (p354 == "open" and "close" or "open")] = nil
	end
	return false
end
function v_u_5.doorStats() -- name: doorStats
	-- upvalues: (copy) v_u_9, (copy) v_u_352
	local function v362()
		-- upvalues: (ref) v_u_9, (ref) v_u_352
		v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
	end
	pcall(v362)
	local v363 = v_u_9
	return tostring(v363:GetAttribute("AudioDoorPlays"))
end
local function v_u_366(p364) -- name: doorModelOf
	-- upvalues: (copy) v_u_3
	local v365 = p364.Parent
	while v365 and v365 ~= workspace do
		if v365:IsA("Model") and v_u_3:HasTag(v365, "HushDoor") then
			return v365
		end
		v365 = v365.Parent
	end
	return nil
end
local function v_u_381(p_u_367) -- name: watchDoor
	-- upvalues: (copy) v_u_345, (ref) v_u_25, (copy) v_u_349, (ref) v_u_14, (copy) v_u_361, (copy) v_u_352, (copy) v_u_9, (ref) v_u_6, (copy) v_u_10
	if not v_u_345[p_u_367] then
		local v_u_368 = p_u_367:GetAttribute("State")
		v_u_345[p_u_367] = { (p_u_367:GetAttributeChangedSignal("State"):Connect(function()
				-- upvalues: (copy) p_u_367, (ref) v_u_25, (ref) v_u_368, (ref) v_u_349, (ref) v_u_14, (ref) v_u_361, (ref) v_u_352, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10
				local v369 = p_u_367:GetAttribute("State")
				if v_u_25 then
					v_u_368 = v369
					return
				else
					local v370 = v_u_349(p_u_367)
					if v370 and (v370 - v_u_14).Magnitude <= 160 then
						local v371 = p_u_367:GetAttribute("Metal") == true
						local v372 = p_u_367:GetAttribute("DoorId")
						local v373 = type(v372) ~= "string" and "" or v372
						if (v369 == "Open" and v_u_368 == "Closed" or v369 == "Closed") and v_u_361(v373, v369 == "Open" and "open" or "close") then
							local v374 = v_u_352
							v374.claimDropped = v374.claimDropped + 1
							local function v375()
								-- upvalues: (ref) v_u_9, (ref) v_u_352
								v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
							end
							pcall(v375)
							v_u_368 = v369
						else
							if v369 == "Open" and v_u_368 == "Closed" then
								v_u_6.play3D(v371 and "door_metal" or "door_open", v370, {
									["auto"] = true,
									["delay"] = 0.12
								})
								local v376 = v_u_352
								v376.open = v376.open + 1
								if v_u_10:NextNumber() < 0.35 then
									v_u_6.play3D("door_creak", v370, {
										["auto"] = true,
										["delay"] = 0.2,
										["volume"] = 0.7
									})
									local v377 = v_u_352
									v377.creak = v377.creak + 1
								end
								local function v378()
									-- upvalues: (ref) v_u_9, (ref) v_u_352
									v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
								end
								pcall(v378)
							elseif v369 == "Closed" then
								v_u_6.play3D(v371 and "door_metal" or "door_close", v370, {
									["auto"] = true,
									["delay"] = 0.12
								})
								local v379 = v_u_352
								v379.close = v379.close + 1
								local function v380()
									-- upvalues: (ref) v_u_9, (ref) v_u_352
									v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
								end
								pcall(v380)
							elseif v369 == "Broken" then
								v_u_6.play3D("door_kick", v370, {
									["auto"] = true,
									["delay"] = 0.05
								})
							end
							v_u_368 = v369
						end
					else
						v_u_368 = v369
						return
					end
				end
			end)) }
	end
end
local function v_u_384(p_u_382) -- name: watchWindow
	-- upvalues: (copy) v_u_345, (ref) v_u_25, (copy) v_u_349, (ref) v_u_14, (ref) v_u_6
	if not v_u_345[p_u_382] then
		v_u_345[p_u_382] = { (p_u_382:GetAttributeChangedSignal("Broken"):Connect(function()
				-- upvalues: (copy) p_u_382, (ref) v_u_25, (ref) v_u_349, (ref) v_u_14, (ref) v_u_6
				if p_u_382:GetAttribute("Broken") == true and not v_u_25 then
					local v383 = v_u_349(p_u_382)
					if v383 and (v383 - v_u_14).Magnitude < 250 then
						v_u_6.play3D("glass_break", v383, {
							["auto"] = true,
							["delay"] = 0.1
						})
					end
				end
			end)) }
	end
end
local function v_u_388(p385) -- name: unwatch
	-- upvalues: (copy) v_u_345
	local v386 = v_u_345[p385]
	if v386 then
		for _, v387 in v386 do
			v387:Disconnect()
		end
		v_u_345[p385] = nil
	end
end
local function v_u_403() -- name: hookTags
	-- upvalues: (copy) v_u_344, (copy) v_u_3, (copy) v_u_381, (copy) v_u_384, (copy) v_u_388
	if #v_u_344 <= 0 then
		for _, v389 in v_u_3:GetTagged("HushDoor") do
			v_u_381(v389)
		end
		for _, v390 in v_u_3:GetTagged("HushWindow") do
			v_u_384(v390)
		end
		local v391 = v_u_344
		local v392 = v_u_3:GetInstanceAddedSignal("HushDoor")
		local v393 = v_u_381
		table.insert(v391, v392:Connect(v393))
		local v394 = v_u_344
		local v395 = v_u_3:GetInstanceRemovedSignal("HushDoor")
		local v396 = v_u_388
		table.insert(v394, v395:Connect(v396))
		local v397 = v_u_344
		local v398 = v_u_3:GetInstanceAddedSignal("HushWindow")
		local v399 = v_u_384
		table.insert(v397, v398:Connect(v399))
		local v400 = v_u_344
		local v401 = v_u_3:GetInstanceRemovedSignal("HushWindow")
		local v402 = v_u_388
		table.insert(v400, v401:Connect(v402))
	end
end
local function v_u_407() -- name: unhookTags
	-- upvalues: (copy) v_u_344, (copy) v_u_345
	for _, v404 in v_u_344 do
		v404:Disconnect()
	end
	table.clear(v_u_344)
	for _, v405 in v_u_345 do
		for _, v406 in v405 do
			v406:Disconnect()
		end
	end
	table.clear(v_u_345)
end
local v_u_408 = {}
local v_u_409 = nil
local v_u_410 = {}
local v_u_411 = nil
local function v_u_432(p412, p413) -- name: noteOwnDoorAct
	-- upvalues: (copy) v_u_9, (copy) v_u_366, (copy) v_u_351, (ref) v_u_350, (copy) v_u_352, (ref) v_u_410
	if p413 == nil or p413 == v_u_9 then
		local v414 = p412:GetAttribute("Kind")
		if v414 == "door" or v414 == "doorKey" then
			local v415 = v_u_366(p412)
			if v415 then
				local v416 = v415:GetAttribute("DoorId")
				if type(v416) == "string" and v416 ~= "" then
					if v414 ~= "door" or v415:GetAttribute("State") ~= "Broken" and type(v415:GetAttribute("Locked")) ~= "string" then
						if v414 == "door" then
							local v417 = os.clock()
							local v418 = v_u_351[v416]
							local v419
							if v418 and v417 - v418.t < 3 then
								v419 = v418.what == "open" and "close" or "open"
							else
								v419 = v415:GetAttribute("State") == "Open" and "close" or "open"
							end
							v_u_351[v416] = {
								["what"] = v419,
								["t"] = v417
							}
							v_u_350[v416 .. "|" .. v419] = nil
							if v416 ~= "" then
								local v420 = os.clock()
								local v421 = v416 .. "|" .. v419
								local v422 = v_u_350[v421]
								if not v422 or v420 - v422 >= 3 then
									if v422 == nil then
										for v423, v424 in v_u_350 do
											if v420 - v424 <= 3 then
												continue
											end
											v_u_350[v423] = nil
										end
									end
									v_u_350[v421] = v420
								end
							end
							local v425 = v_u_352
							v425.own = v425.own + 1
							local function v426()
								-- upvalues: (ref) v_u_9, (ref) v_u_352
								v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
							end
							pcall(v426)
						end
						local v427 = os.clock()
						for v428, v429 in v_u_410 do
							if v427 - v429[#v429] <= 3 then
								continue
							end
							v_u_410[v428] = nil
						end
						local v430 = v416 .. (v414 == "door" and "|toggle" or "|unlock")
						local v431 = v_u_410[v430]
						if not v431 then
							v431 = {}
							v_u_410[v430] = v431
						end
						table.insert(v431, v427)
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_438(p433, p434) -- name: ownEcho
	-- upvalues: (ref) v_u_410
	local v435 = p433 .. "|" .. p434
	local v436 = v_u_410[v435]
	if v436 then
		local v437 = os.clock()
		while #v436 > 0 and v437 - v436[1] > 3 do
			table.remove(v436, 1)
		end
		if #v436 == 0 then
			v_u_410[v435] = nil
			return false
		else
			table.remove(v436, 1)
			return true
		end
	else
		return false
	end
end
function v_u_5._ownEchoTest() -- name: _ownEchoTest
	-- upvalues: (ref) v_u_410, (copy) v_u_438
	local v439 = v_u_410
	v_u_410 = {
		["T1|toggle"] = { os.clock() - 5, os.clock() - 1, os.clock() - 0.5 }
	}
	local v440 = {
		v_u_438("T1", "toggle") == true,
		v_u_438("T1", "toggle") == true,
		v_u_438("T1", "toggle") == false,
		v_u_438("T2", "toggle") == false,
		v_u_438("T1", "unlock") == false
	}
	v_u_410 = v439
	for v441, v442 in v440 do
		if v442 then
			continue
		end
		return "fail step " .. v441
	end
	return "ok"
end
function v_u_5._claimTest() -- name: _claimTest
	-- upvalues: (ref) v_u_350
	local v443 = v_u_350
	v_u_350 = {}
	local v444 = {}
	local v445 = os.clock()
	local v446 = v_u_350["T1|open"]
	local v447
	if v446 and v445 - v446 < 3 then
		v447 = true
	else
		if v446 == nil then
			for v448, v449 in v_u_350 do
				if v445 - v449 <= 3 then
					continue
				end
				v_u_350[v448] = nil
			end
		end
		v_u_350["T1|open"] = v445
		v447 = false
	end
	local v450 = v447 == false
	local v451 = os.clock()
	local v452 = v_u_350["T1|open"]
	local v453
	if v452 and v451 - v452 < 3 then
		v453 = true
	else
		if v452 == nil then
			for v454, v455 in v_u_350 do
				if v451 - v455 <= 3 then
					continue
				end
				v_u_350[v454] = nil
			end
		end
		v_u_350["T1|open"] = v451
		v_u_350["T1|close"] = nil
		v453 = false
	end
	local v456 = v453 == true
	local v457 = os.clock()
	local v458 = v_u_350["T1|close"]
	local v459
	if v458 and v457 - v458 < 3 then
		v459 = true
	else
		if v458 == nil then
			for v460, v461 in v_u_350 do
				if v457 - v461 <= 3 then
					continue
				end
				v_u_350[v460] = nil
			end
		end
		v_u_350["T1|close"] = v457
		v_u_350["T1|open"] = nil
		v459 = false
	end
	local v462 = v459 == false
	local v463 = os.clock()
	local v464 = v_u_350["T1|open"]
	local v465
	if v464 and v463 - v464 < 3 then
		v465 = true
	else
		if v464 == nil then
			for v466, v467 in v_u_350 do
				if v463 - v467 <= 3 then
					continue
				end
				v_u_350[v466] = nil
			end
		end
		v_u_350["T1|open"] = v463
		v_u_350["T1|close"] = nil
		v465 = false
	end
	local v468 = v465 == false
	local v469 = os.clock()
	local v470 = v_u_350["T2|open"]
	local v471
	if v470 and v469 - v470 < 3 then
		v471 = true
	else
		if v470 == nil then
			for v472, v473 in v_u_350 do
				if v469 - v473 <= 3 then
					continue
				end
				v_u_350[v472] = nil
			end
		end
		v_u_350["T2|open"] = v469
		v_u_350["T2|close"] = nil
		v471 = false
	end
	__set_list(v444, 1, {v450, v456, v462, v468, v471 == false, false == false})
	v_u_350 = v443
	for v474, v475 in v444 do
		if v475 then
			continue
		end
		return "fail step " .. v474
	end
	return "ok"
end
local function v_u_478(p476) -- name: isMetalDoor
	-- upvalues: (copy) v_u_3
	if p476 == "" then
		return false
	end
	for _, v477 in v_u_3:GetTagged("HushDoor") do
		if v477:GetAttribute("DoorId") ~= p476 then
			continue
		end
		return v477:GetAttribute("Metal") == true
	end
	return false
end
local function v_u_502(p479) -- name: onDoorFx
	-- upvalues: (ref) v_u_25, (copy) v_u_408, (ref) v_u_6, (ref) v_u_14, (copy) v_u_438, (copy) v_u_352, (copy) v_u_9, (ref) v_u_350, (copy) v_u_478, (copy) v_u_10
	if type(p479) == "table" then
		local v480 = p479.kind
		local v481 = p479.pos
		if type(v480) == "string" and typeof(v481) == "Vector3" then
			v_u_25 = true
			local v482 = p479.id or ""
			local v483 = tostring(v482)
			if v480 == "alarm" then
				local v484 = v_u_408[v483]
				if v484 and v484.bed:alive() then
					v484.untilT = os.clock() + 16
				else
					local v485 = v_u_6._voices.bed("ev_car_alarm", {
						["pos"] = nil,
						["fadeIn"] = 0.05,
						["pos"] = v481
					})
					if v485 then
						v_u_408[v483] = {
							["bed"] = v485,
							["untilT"] = os.clock() + 16
						}
					end
					if (v481 - v_u_14).Magnitude < 200 then
						v_u_6.threatHint(0.4)
					end
				end
			elseif v480 == "alarmStop" then
				local v486 = v_u_408[v483]
				if v486 then
					v486.bed:stop(0.4)
					v_u_408[v483] = nil
				end
				return
			elseif (v481 - v_u_14).Magnitude > 200 then
				return
			elseif (v480 == "open" or v480 == "close") and (v483 ~= "" and v_u_438(v483, "toggle")) then
				local v487 = v_u_352
				v487.echoDropped = v487.echoDropped + 1
				local function v488()
					-- upvalues: (ref) v_u_9, (ref) v_u_352
					v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
				end
				pcall(v488)
				return
			elseif v480 == "unlock" and (v483 ~= "" and v_u_438(v483, "unlock")) then
				return
			else
				if v480 == "open" or v480 == "close" then
					local v489
					if v483 == "" then
						v489 = false
					else
						local v490 = os.clock()
						local v491 = v483 .. "|" .. v480
						local v492 = v_u_350[v491]
						if v492 and v490 - v492 < 3 then
							v489 = true
						else
							if v492 == nil then
								for v493, v494 in v_u_350 do
									if v490 - v494 <= 3 then
										continue
									end
									v_u_350[v493] = nil
								end
							end
							v_u_350[v491] = v490
							v_u_350[v483 .. "|" .. (v480 == "open" and "close" or "open")] = nil
							v489 = false
						end
					end
					if v489 then
						local v495 = v_u_352
						v495.claimDropped = v495.claimDropped + 1
						local function v496()
							-- upvalues: (ref) v_u_9, (ref) v_u_352
							v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
						end
						pcall(v496)
						return
					end
				end
				if v480 == "open" then
					v_u_6.play3D(v_u_478(v483) and "door_metal" or "door_open", v481, {
						["auto"] = true
					})
					local v497 = v_u_352
					v497.open = v497.open + 1
					if v_u_10:NextNumber() < 0.35 then
						v_u_6.play3D("door_creak", v481, {
							["auto"] = true,
							["delay"] = 0.2,
							["volume"] = 0.7
						})
						local v498 = v_u_352
						v498.creak = v498.creak + 1
					end
					local function v499()
						-- upvalues: (ref) v_u_9, (ref) v_u_352
						v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
					end
					pcall(v499)
					return
				elseif v480 == "close" then
					v_u_6.play3D(v_u_478(v483) and "door_metal" or "door_close", v481, {
						["auto"] = true
					})
					local v500 = v_u_352
					v500.close = v500.close + 1
					local function v501()
						-- upvalues: (ref) v_u_9, (ref) v_u_352
						v_u_9:SetAttribute("AudioDoorPlays", string.format("open=%d close=%d creak=%d own=%d echoDropped=%d claimDropped=%d", v_u_352.open, v_u_352.close, v_u_352.creak, v_u_352.own, v_u_352.echoDropped, v_u_352.claimDropped))
					end
					pcall(v501)
					return
				elseif v480 == "slam" then
					v_u_6.play3D("door_slam", v481, {
						["auto"] = true
					})
					return
				elseif v480 == "unlock" then
					v_u_6.play3D("door_locked", v481, {
						["auto"] = true,
						["pitch"] = 1.25,
						["volume"] = 0.6
					})
					return
				elseif v480 == "locked" then
					v_u_6.play3D("door_locked", v481, {
						["auto"] = true
					})
					return
				elseif v480 == "kick" then
					v_u_6.play3D("door_kick", v481, {
						["auto"] = true
					})
					return
				elseif v480 == "bash" then
					v_u_6.play3D("z_bash", v481, {
						["auto"] = true
					})
					return
				elseif v480 == "break" then
					v_u_6.play3D("door_kick", v481, {
						["auto"] = true
					})
					v_u_6.play3D("door_slam", v481, {
						["auto"] = true,
						["delay"] = 0.18,
						["volume"] = 0.7
					})
					return
				elseif v480 == "pry" then
					v_u_6.play3D("door_creak", v481, {
						["auto"] = true,
						["pitch"] = 0.85
					})
					v_u_6.play3D("mel_hit_blunt", v481, {
						["auto"] = true,
						["volume"] = 0.5
					})
				elseif v480 == "window" then
					v_u_6.play3D("glass_break", v481, {
						["auto"] = true
					})
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_512() -- name: connectDoorFx
	-- upvalues: (ref) v_u_411, (copy) v_u_432, (ref) v_u_409, (copy) v_u_4, (ref) v_u_25, (copy) v_u_502
	if not v_u_411 then
		v_u_411 = game:GetService("ProximityPromptService").PromptTriggered:Connect(function(p503, p504)
			-- upvalues: (ref) v_u_432
			local v505 = v_u_432
			pcall(v505, p503, p504)
		end)
	end
	if not v_u_409 then
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_409, (ref) v_u_25, (ref) v_u_502
			local v506 = v_u_4:WaitForChild("HushNet", 60)
			if not v506 then
				return
			end
			local v507 = nil
			for _ = 1, 60 do
				v507 = v506:FindFirstChild("door.fx")
				if v507 then
					break
				end
				task.wait(1)
			end
			if v507 and (v507:IsA("RemoteEvent") and not v_u_409) then
				v_u_25 = true
				v_u_409 = v507.OnClientEvent:Connect(function(p508)
					-- upvalues: (ref) v_u_502
					local v509 = v_u_502
					local v510, v511 = pcall(v509, p508)
					if not v510 then
						warn("[HUSH:Audio] door.fx:", v511)
					end
				end)
			end
		end)
	end
end
local function v_u_518(p513) -- name: stepAlarms
	-- upvalues: (copy) v_u_408
	local v514 = nil
	for v515, v516 in v_u_408 do
		if v516.untilT >= p513 and v516.bed:alive() then
			continue
		end
		v514 = v514 or {}
		table.insert(v514, v515)
	end
	if v514 then
		for _, v517 in v514 do
			v_u_408[v517].bed:stop(0.6)
			v_u_408[v517] = nil
		end
	end
end
local v_u_519 = {}
local v_u_520 = {}
local function v_u_528(p_u_521) -- name: eventPos
	if p_u_521:IsA("BasePart") then
		return p_u_521.Position, p_u_521
	elseif p_u_521:IsA("Attachment") then
		return p_u_521.WorldPosition, p_u_521
	elseif p_u_521:IsA("Model") then
		local v522 = p_u_521.PrimaryPart
		local v523, v524 = pcall(function()
			-- upvalues: (copy) p_u_521
			return p_u_521:GetPivot()
		end)
		local v525
		if v523 then
			v525 = v524.Position
		else
			v525 = nil
		end
		return v525, v522
	else
		local v526 = p_u_521:GetAttribute("Position")
		if typeof(v526) == "Vector3" then
			return v526, nil
		else
			local v527 = p_u_521:GetAttribute("CFrame")
			if typeof(v527) == "CFrame" then
				return v527.Position, nil
			else
				return nil, nil
			end
		end
	end
end
local function v_u_539(p529) -- name: onEvent
	-- upvalues: (copy) v_u_528, (ref) v_u_6, (ref) v_u_14, (ref) v_u_25, (copy) v_u_520
	local v530 = string.lower
	local v531 = p529:GetAttribute("Kind") or p529.Name
	local v532 = v530((tostring(v531)))
	local v533, v534 = v_u_528(p529)
	local v535 = {}
	if string.find(v532, "heli") then
		local v536 = v_u_6._voices.bed("ev_heli", {
			["pos"] = nil,
			["follow"] = nil,
			["fadeIn"] = 6,
			["occlude"] = false,
			["pos"] = v533 or v_u_14 + Vector3.new(0, 80, -400),
			["follow"] = v534
		})
		if v536 then
			table.insert(v535, v536)
		end
	elseif string.find(v532, "airdrop") or string.find(v532, "plane") then
		v_u_6.play3D("ev_heli_flyby", v533 or v_u_14 + Vector3.new(0, 120, 0), {
			["auto"] = true
		})
	elseif string.find(v532, "horde") then
		v_u_6.zombie("scream", v533 or v_u_14 + Vector3.new(300, 0, 0), "screamer", true)
	elseif string.find(v532, "alarm") then
		local v537 = v533 and not v_u_25 and v_u_6._voices.bed("ev_car_alarm", {
			["pos"] = nil,
			["fadeIn"] = 0.1,
			["pos"] = v533
		})
		if v537 then
			table.insert(v535, v537)
		end
	elseif string.find(v532, "flare") then
		if v533 then
			v_u_6.play3D("ev_flare_ignite", v533, {
				["auto"] = true
			})
			local v538 = v_u_6._voices.bed("ev_flare_loop", {
				["pos"] = nil,
				["follow"] = nil,
				["fadeIn"] = 0.5,
				["pos"] = v533,
				["follow"] = v534
			})
			if v538 then
				table.insert(v535, v538)
			end
		end
	elseif string.find(v532, "explo") and v533 then
		v_u_6.explosion(v533)
	end
	if #v535 > 0 then
		v_u_520[p529] = v535
	end
end
local function v_u_543(p540) -- name: onEventRemoved
	-- upvalues: (copy) v_u_520
	local v541 = v_u_520[p540]
	if v541 then
		for _, v542 in v541 do
			v542:stop(4)
		end
		v_u_520[p540] = nil
	end
end
function v_u_5.attachRaid(p544) -- name: attachRaid
	-- upvalues: (copy) v_u_5, (copy) v_u_403, (ref) v_u_13, (copy) v_u_4, (ref) v_u_8, (copy) v_u_90, (copy) v_u_512, (ref) v_u_6, (copy) v_u_539, (copy) v_u_519, (copy) v_u_543
	v_u_5.detachRaid()
	v_u_403()
	if not v_u_13 then
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_13, (ref) v_u_8, (ref) v_u_90
			local v545 = v_u_4:WaitForChild("HushNet", 60)
			if not v545 then
				return
			end
			local v546 = nil
			for _ = 1, 120 do
				v546 = v545:FindFirstChild("zombie.snap")
				if v546 then
					break
				end
				task.wait(1)
			end
			if v546 and (v546:IsA("UnreliableRemoteEvent") and not v_u_13) then
				v_u_13 = v546.OnClientEvent:Connect(function(p547)
					-- upvalues: (ref) v_u_8, (ref) v_u_90
					if type(p547) == "buffer" and (v_u_8 and v_u_8.decode) then
						local v548 = v_u_8.decode
						local v549 = v_u_90
						pcall(v548, p547, v549)
					end
				end)
			end
		end)
	end
	v_u_512()
	local v550 = p544:FindFirstChild("Events")
	if v550 and not v_u_6._hasRaidClient() then
		for _, v551 in v550:GetChildren() do
			local v552 = v_u_539
			pcall(v552, v551)
		end
		local v553 = v_u_519
		local v554 = v550.ChildAdded
		local function v557(p555)
			-- upvalues: (ref) v_u_539
			local v556 = v_u_539
			pcall(v556, p555)
		end
		table.insert(v553, v554:Connect(v557))
		local v558 = v_u_519
		local v559 = v550.ChildRemoved
		local v560 = v_u_543
		table.insert(v558, v559:Connect(v560))
	end
end
function v_u_5.detachRaid() -- name: detachRaid
	-- upvalues: (copy) v_u_519, (copy) v_u_520, (copy) v_u_408, (copy) v_u_407, (copy) v_u_11, (ref) v_u_17, (ref) v_u_19
	for _, v561 in v_u_519 do
		v561:Disconnect()
	end
	table.clear(v_u_519)
	for _, v562 in v_u_520 do
		for _, v563 in v562 do
			v563:stop(4)
		end
	end
	table.clear(v_u_520)
	for _, v564 in v_u_408 do
		v564.bed:stop(1)
	end
	table.clear(v_u_408)
	v_u_407()
	table.clear(v_u_11)
	if v_u_17 then
		v_u_17:stop(2)
		v_u_17 = nil
	end
	v_u_19 = 0
end
function v_u_5.heartbeatBoost(p565, p566) -- name: heartbeatBoost
	-- upvalues: (copy) v_u_26
	local v567 = os.clock()
	local v568
	if v567 < v_u_26.boostUntil then
		v568 = v_u_26.boostVol
	else
		v568 = false
	end
	v_u_26.boostVol = math.clamp(p565, 0, 1)
	v_u_26.boostUntil = p565 <= 0 and 0 or v567 + math.max(0, p566)
	local v569
	if p565 > 0 then
		v569 = v_u_26.boostVol
	else
		v569 = false
	end
	if v568 ~= v569 then
		v_u_26.hbAt = 0
	end
end
function v_u_5.heartbeatWanted() -- name: heartbeatWanted
	-- upvalues: (copy) v_u_26
	return v_u_26.hbVol > 0
end
function v_u_5.hearRadii(p570) -- name: hearRadii
	-- upvalues: (copy) v_u_26, (ref) v_u_6
	local v571 = p570 or v_u_26.scale
	local v572 = v_u_6 and (v_u_6._controller and v_u_6._controller("ZombieRender")) and "ZombieRender" or "AudioWorld"
	local v573 = string.format
	local v574 = "voices by %s: near %d, far band %s, own %d, scream %d, feet %d (far voices so far %d)"
	local v575 = v_u_26.ZR_RANGE
	local v576
	if v571 > 1.02 then
		local v577 = string.format
		local v578 = v_u_26.ZR_RANGE + 2
		local v579 = v_u_26.ZR_RANGE * v571 + 0.5
		v576 = v577("%d..%d", v578, (math.floor(v579)))
	else
		v576 = "off"
	end
	local v580 = 75 * v571 + 0.5
	local v581 = math.floor(v580)
	local v582 = 260 * v571 + 0.5
	local v583 = math.floor(v582)
	local v584 = 30 * v571 + 0.5
	return v573(v574, v572, v575, v576, v581, v583, math.floor(v584), v_u_26.farVoices)
end
function v_u_5.setZombieVoices(p585) -- name: setZombieVoices
	-- upvalues: (ref) v_u_20
	v_u_20 = p585
end
function v_u_5.step(p586, p587) -- name: step
	-- upvalues: (ref) v_u_14, (copy) v_u_343, (copy) v_u_26, (copy) v_u_172, (copy) v_u_237, (copy) v_u_9, (copy) v_u_169, (copy) v_u_518, (ref) v_u_6, (ref) v_u_20, (ref) v_u_21
	v_u_14 = p587
	local v588 = os.clock()
	v_u_343(v588, p586)
	if v_u_26.hbAt <= v588 then
		v_u_26.hbAt = v588 + 1
		for _, v589 in v_u_172 do
			if not v589.isLocal then
				continue
			end
			v_u_237(v589)
		end
		local v590 = v_u_9
		local v591 = v_u_26.hbVol * 100 + 0.5
		v590:SetAttribute("AudioHeartbeat", math.floor(v591) / 100)
	end
	v_u_169(v588)
	v_u_518(v588)
	local v592
	if v_u_6._controller("ZombieRender") == nil then
		v592 = v588 - v_u_21 > 8
	else
		v592 = false
	end
	v_u_20 = v592
end
function v_u_5.init(p593, p594, p595) -- name: init
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_12
	v_u_6 = p593
	v_u_7 = p594
	v_u_8 = p595
	if p595 and p595.STATE then
		v_u_12 = p595.STATE
	else
		v_u_12 = {
			["idle"] = 0,
			["wander"] = 1,
			["investigate"] = 2,
			["chase"] = 3,
			["attack"] = 4,
			["bash"] = 5,
			["stagger"] = 6,
			["dead"] = 7,
			["scream"] = 8,
			["aim"] = 9,
			["lying"] = 10,
			["dormant"] = 11,
			["rise"] = 12,
			["flee"] = 13
		}
	end
end
return v_u_5