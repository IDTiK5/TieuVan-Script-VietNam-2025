-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarketTrade

local v_u_1 = game:GetService("Players")
return {
	["new"] = function(p_u_2, p_u_3) -- name: new
		-- upvalues: (copy) v_u_1
		local v_u_4 = p_u_2.ui
		local v_u_5 = p_u_2.theme
		local v_u_6 = p_u_2.C
		local v_u_7 = p_u_2.h
		local v_u_8 = p_u_2.data
		local v_u_9 = p_u_2.mc
		local v_u_10 = p_u_2.phone == true
		local v_u_11 = "TradeView"
		local v12, v_u_13 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_11
			return p_u_2.mc.cctx.shared[v_u_11]
		end)
		if not v12 or type(v_u_13) ~= "table" then
			v_u_13 = nil
		end
		local v_u_14 = "TradeRules"
		local v15, v_u_16 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_14
			return p_u_2.mc.cctx.shared[v_u_14]
		end)
		if not v15 or type(v_u_16) ~= "table" then
			v_u_16 = nil
		end
		local v_u_17 = "MenuMarketTradeKit"
		local v18, v_u_19 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_17
			return p_u_2.mc.cctx.lib[v_u_17]
		end)
		if not v18 or type(v_u_19) ~= "table" then
			v_u_19 = nil
		end
		local v_u_20 = "MenuCratesCopies"
		local v21, v_u_22 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_20
			return p_u_2.mc.cctx.lib[v_u_20]
		end)
		if not v21 or type(v_u_22) ~= "table" then
			v_u_22 = nil
		end
		local v_u_23 = "TallyMark"
		local v24, v_u_25 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_23
			return p_u_2.mc.cctx.lib[v_u_23]
		end)
		if not v24 or type(v_u_25) ~= "table" then
			v_u_25 = nil
		end
		local v_u_26 = "Skins"
		local v27, v_u_28 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_26
			return p_u_2.mc.cctx.shared[v_u_26]
		end)
		if not v27 or type(v_u_28) ~= "table" then
			v_u_28 = nil
		end
		local v_u_29 = "Items"
		local v30, v31 = pcall(function()
			-- upvalues: (copy) p_u_2, (copy) v_u_29
			return p_u_2.mc.cctx.shared[v_u_29]
		end)
		local _ = v30 and type(v31) == "table"
		local v_u_32 = nil
		local function v33()
			-- upvalues: (ref) v_u_32, (copy) v_u_9
			v_u_32 = v_u_9.cctx.controllers.TradeNotes
		end
		pcall(v33)
		local v_u_34 = {
			["frame"] = p_u_3
		}
		if v_u_13 == nil or (v_u_19 == nil or v_u_32 == nil) then
			p_u_2.mc.kit.empty(p_u_3, "Trading could not be loaded. Close and reopen the menu.")
			return v_u_34
		end
		local v_u_35 = v_u_1.LocalPlayer
		local v_u_36 = v_u_35.UserId
		local v_u_37 = true
		local v_u_38 = false
		local v_u_39 = {}
		local v_u_40 = os.clock
		local v_u_41 = v_u_32.state()
		local v_u_42 = {
			["result"] = nil,
			["history"] = false
		}
		local v_u_43 = nil
		local v_u_44 = "you"
		local v_u_45 = v_u_40()
		local v_u_46 = 0
		local v_u_47 = nil
		local v_u_48 = -1000000000
		local v_u_49 = false
		local v_u_50 = ""
		local v_u_51 = {
			["give"] = nil,
			["get"] = nil,
			["giveCash"] = nil,
			["getCash"] = nil,
			["give"] = {},
			["get"] = {}
		}
		local v_u_52 = "off"
		local v_u_53 = {}
		local v_u_54 = {}
		local v_u_55 = v_u_22 and (v_u_22.NAMES or {}) or {}
		local v_u_56 = {}
		local v_u_57 = {}
		local v_u_58 = nil
		local v_u_59 = false
		local v_u_60 = ""
		local v_u_61 = {}
		local v_u_62 = v_u_4.new("Frame", {
			["Name"] = "Host",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}, p_u_3)
		local v_u_63 = v_u_32.backend()
		local function v_u_65() -- name: stash
			-- upvalues: (ref) v_u_63, (ref) v_u_32, (copy) v_u_8
			v_u_63 = v_u_32.backend()
			if v_u_63 ~= nil then
				local v64 = v_u_63.stash
				if type(v64) == "function" then
					return v_u_63:stash()
				end
			end
			return v_u_8:stash()
		end
		local function v70(p66) -- name: condition
			-- upvalues: (copy) v_u_13
			if p66 then
				p66 = p66.dur
			end
			if type(p66) ~= "number" or p66 >= 0.995 then
				return nil
			end
			local v67 = v_u_13.text
			local v68 = p66 * 100 + 0.5
			local v69 = math.floor(v68)
			return v67("condition", (math.clamp(v69, 0, 100)))
		end
		local v_u_91 = {
			["nameOf"] = function(p71) -- name: nameOf
				-- upvalues: (copy) v_u_7
				return v_u_7.name(p71)
			end,
			["skinName"] = function(p72) -- name: skinName
				-- upvalues: (copy) v_u_28
				local v73
				if v_u_28 then
					v73 = v_u_28.get(p72)
				else
					v73 = nil
				end
				if v73 and v_u_28 then
					return v_u_28.displayName(v73)
				else
					return tostring(p72)
				end
			end,
			["condition"] = v70,
			["foundBy"] = function(p74) -- name: foundBy
				-- upvalues: (copy) v_u_22, (copy) v_u_55, (copy) v_u_56, (ref) v_u_1, (ref) v_u_37, (ref) v_u_38, (copy) v_u_34, (copy) v_u_36
				if v_u_22 ~= nil then
					local v75 = v_u_22.foundBy
					if type(v75) == "function" then
						local v76 = v_u_22.originId
						if type(v76) == "function" then
							local v_u_77 = v_u_22.originId(p74)
							if type(v_u_77) == "number" and (v_u_55[v_u_77] == nil and not v_u_56[v_u_77]) then
								v_u_56[v_u_77] = true
								task.spawn(function()
									-- upvalues: (ref) v_u_1, (copy) v_u_77, (ref) v_u_55, (ref) v_u_37, (ref) v_u_38, (ref) v_u_34
									local function v78()
										-- upvalues: (ref) v_u_1, (ref) v_u_77
										return v_u_1:GetNameFromUserIdAsync(v_u_77)
									end
									local v79, v80 = pcall(v78)
									if v79 and type(v80) == "string" then
										v_u_55[v_u_77] = v80
										if v_u_37 and v_u_38 then
											v_u_34.render(true)
										end
									end
								end)
							end
						end
						local v81 = v_u_22.foundBy
						local v82 = v_u_36
						local v83 = v_u_55
						local v84, v85 = pcall(v81, p74, v82, v83)
						if v84 then
							return v85
						end
					end
				end
				return nil
			end,
			["tallyText"] = function(p86) -- name: tallyText
				-- upvalues: (copy) v_u_25, (copy) v_u_13
				if v_u_25 ~= nil then
					local v87 = v_u_25.chipText
					if type(v87) == "function" then
						local v88 = v_u_25.chipText
						local v89, v90 = pcall(v88, p86)
						if v89 and type(v90) == "string" then
							return v90
						end
					end
				end
				return v_u_13.text("tally", (tostring(p86)))
			end
		}
		local v_u_92 = {
			["mc"] = v_u_9,
			["ui"] = v_u_4,
			["C"] = v_u_6,
			["theme"] = v_u_5,
			["h"] = v_u_7,
			["View"] = v_u_13,
			["notes"] = v_u_32,
			["condition"] = v70
		}
		local function v_u_96() -- name: clearHost
			-- upvalues: (copy) v_u_54, (copy) v_u_61, (copy) v_u_62, (copy) v_u_53
			for _, v93 in v_u_54 do
				pcall(v93)
			end
			table.clear(v_u_54)
			for _, v_u_94 in v_u_61 do
				pcall(function()
					-- upvalues: (copy) v_u_94
					v_u_94:Disconnect()
				end)
			end
			table.clear(v_u_61)
			for _, v95 in v_u_62:GetChildren() do
				v95:Destroy()
			end
			table.clear(v_u_53)
		end
		local function v_u_100() -- name: sizeNow
			-- upvalues: (copy) v_u_7, (copy) p_u_3, (copy) p_u_2
			local function v97()
				-- upvalues: (ref) v_u_7, (ref) p_u_3
				return v_u_7.designSize(p_u_3, false)
			end
			local v98, v99 = pcall(v97)
			if v98 and (typeof(v99) == "Vector2" and v99.X > 40) then
				return v99
			else
				return Vector2.new(p_u_2.compact and 800 or 1700, p_u_2.compact and 330 or 800)
			end
		end
		local function v_u_108(p101, p102, p103, p104, p105, p106) -- name: btn
			-- upvalues: (copy) v_u_5, (copy) v_u_7
			local v107 = p106 or {}
			v107.name = p104
			v107.height = v107.height or v_u_5.touch(44)
			return v_u_7.button(p101, p102, p103, p105, v107)
		end
		local function v_u_114(p109, p110, p111, p112) -- name: notice
			-- upvalues: (copy) v_u_4, (copy) v_u_6
			local v113 = v_u_4.new("Frame", {
				["Name"] = "Notice",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.2,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_6.raised,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = p111
			}, p109)
			v_u_4.stroke(v113, p112 or v_u_6.line)
			v_u_4.pad(v113, {
				12,
				12,
				8,
				8
			})
			v_u_4.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "small",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v113,
				["text"] = p110,
				["color"] = v_u_6.text
			})
			return v113
		end
		local function v_u_118(p115) -- name: loadPlayers
			-- upvalues: (ref) v_u_49, (ref) v_u_37, (copy) v_u_40, (ref) v_u_48, (ref) v_u_32, (ref) v_u_47, (ref) v_u_38, (ref) v_u_52, (copy) v_u_34
			if v_u_49 or not v_u_37 then
				return
			elseif p115 == true or v_u_40() - v_u_48 >= 6 then
				v_u_49 = true
				v_u_48 = v_u_40()
				task.spawn(function()
					-- upvalues: (ref) v_u_32, (ref) v_u_49, (ref) v_u_37, (ref) v_u_47, (ref) v_u_38, (ref) v_u_52, (ref) v_u_34
					local v116 = v_u_32.get("tradePlayers")
					v_u_49 = false
					if v_u_37 then
						if type(v116) == "table" then
							local v117 = v116.rows
							if type(v117) == "table" then
								v_u_47 = v116
								if v_u_38 and v_u_52 == "players" then
									v_u_34.render(true)
								end
							end
						end
					end
				end)
			end
		end
		local function v_u_202(p119, p_u_120, p121) -- name: addButtons
			-- upvalues: (copy) v_u_5, (copy) v_u_13, (copy) v_u_4, (ref) v_u_41, (copy) v_u_8, (copy) v_u_16, (ref) v_u_32, (copy) v_u_19, (ref) v_u_92, (copy) v_u_65, (ref) v_u_63, (copy) v_u_53, (copy) v_u_108
			local _ = #(p_u_120.me.lines or {}) >= v_u_13.LINES_MAX
			local function v_u_131(p122) -- name: reasonFor
				-- upvalues: (ref) v_u_8, (ref) v_u_16, (ref) v_u_13
				local function v123()
					-- upvalues: (ref) v_u_8
					return v_u_8:eligibility()
				end
				local v124, v125 = pcall(v123)
				if v124 and type(v125) == "table" then
					local v126 = v125.checkInst
					if type(v126) == "function" then
						local v127 = {
							["topLevel"] = true,
							["insured"] = nil,
							["restricted"] = false,
							["denyPaid"] = false,
							["crates"] = true,
							["resolved"] = true,
							["tradeFailed"] = false,
							["insured"] = v_u_8:insured(p122.uid)
						}
						local v128, v129, v130 = v125.checkInst(p122, v127)
						if v128 then
							if type(v130) == "table" and v130.unload == true then
								return v_u_13.rtext("unload", "Unload it first.")
							else
								return nil
							end
						else
							return v_u_16 and v_u_16.CODE_TEXT[v129 or ""] or v_u_13.rtext("cannotWith", "That cannot be traded with this player.")
						end
					end
				end
				return nil
			end
			local function v_u_137(p132, p133) -- name: inTrade
				-- upvalues: (ref) v_u_41, (copy) p_u_120
				local v134 = v_u_41
				local v135
				if type(v134) == "table" then
					v135 = v_u_41.s
				else
					v135 = nil
				end
				for _, v136 in (v135 or p_u_120).me.lines or {} do
					if v136.kind ~= p132 or v136.uid ~= p133 then
						continue
					end
					return true
				end
				return false
			end
			local function v_u_141(p138, p139, p140) -- name: add
				-- upvalues: (ref) v_u_32
				return v_u_32.op("tradeAdd", {
					["kind"] = p138,
					["uid"] = p139,
					["n"] = p140
				}).ok == true
			end
			local function v_u_143() -- name: openItems
				-- upvalues: (ref) v_u_19, (ref) v_u_92, (ref) v_u_65, (copy) v_u_141, (copy) v_u_137, (copy) v_u_131
				local v142 = {
					["stash"] = nil,
					["add"] = nil,
					["inTrade"] = nil,
					["reasonOf"] = nil,
					["cases"] = false,
					["stash"] = v_u_65,
					["add"] = v_u_141,
					["inTrade"] = v_u_137,
					["reasonOf"] = v_u_131
				}
				return v_u_19.pickItems(v_u_92, v142)
			end
			local function v_u_145() -- name: openCases
				-- upvalues: (ref) v_u_19, (ref) v_u_92, (ref) v_u_65, (copy) v_u_141, (copy) v_u_137, (copy) v_u_131
				local v144 = {
					["stash"] = nil,
					["add"] = nil,
					["inTrade"] = nil,
					["reasonOf"] = nil,
					["cases"] = true,
					["stash"] = v_u_65,
					["add"] = v_u_141,
					["inTrade"] = v_u_137,
					["reasonOf"] = v_u_131
				}
				return v_u_19.pickItems(v_u_92, v144)
			end
			local function v_u_147() -- name: openSkins
				-- upvalues: (ref) v_u_19, (ref) v_u_92, (copy) v_u_141, (copy) v_u_137
				local v146 = {
					["add"] = v_u_141,
					["inTrade"] = v_u_137
				}
				return v_u_19.pickSkins(v_u_92, v146)
			end
			local function v162() -- name: openCash
				-- upvalues: (ref) v_u_41, (copy) p_u_120, (ref) v_u_19, (ref) v_u_92, (ref) v_u_63, (ref) v_u_32, (ref) v_u_8, (ref) v_u_13, (ref) v_u_16
				local v148 = v_u_41
				local v149
				if type(v148) == "table" then
					v149 = v_u_41.s
				else
					v149 = nil
				end
				local v150 = v149 or p_u_120
				local v151 = v_u_19.cashDialog
				local v152 = v_u_92
				local v153 = {
					["cash"] = v150.me.cash
				}
				v_u_63 = v_u_32.backend()
				local v154
				if v_u_63 == nil then
					v154 = v_u_8:cash()
				else
					local v155 = v_u_63.cash
					if type(v155) == "function" then
						v154 = v_u_63:cash()
					else
						v154 = v_u_8:cash()
					end
				end
				v153.have = v154
				function v153.fee(p156) -- name: fee
					-- upvalues: (ref) v_u_13, (ref) v_u_16
					local v157 = v_u_13.rtext
					local v158 = "feeNote"
					local v159 = "5 percent fee on cash. They receive %s."
					local v160 = v_u_13.money
					if v_u_16 then
						p156 = v_u_16.net(p156) or p156
					end
					return v157(v158, v159, v160(p156))
				end
				function v153.onSet(p161) -- name: onSet
					-- upvalues: (ref) v_u_32
					return v_u_32.op("tradeCash", {
						["n"] = p161
					}).ok == true
				end
				return v151(v152, v153)
			end
			v_u_53.openers = {
				["item"] = v_u_143,
				["case"] = v_u_145,
				["skin"] = v_u_147,
				["cash"] = v162
			}
			local v163 = v_u_108
			local v164 = v_u_13.TEXT.addItem
			local function v168()
				-- upvalues: (copy) p_u_120, (ref) v_u_13, (ref) v_u_4, (copy) v_u_143
				if #(p_u_120.me.lines or {}) >= v_u_13.LINES_MAX then
					local v165, v166 = v_u_13.rtext("tooMany", "A trade holds at most 16 lines.")
					if type(v165) == "string" and v165 ~= "" then
						local v167 = v_u_4.toast
						pcall(v167, v165, v166 or "warn")
					end
				else
					v_u_143()
				end
			end
			local v169 = {
				["size"] = nil,
				["order"] = 1,
				["maxTextWidth"] = 140
			}
			local v170 = UDim2.new
			local v171 = p121 * 3 / 4
			v169.size = v170(0.25, -math.ceil(v171), 0, v_u_5.touch(44))
			local v172 = v163(p119, v164, "secondary", "AddItem", v168, v169)
			local v173 = v_u_108
			local v174 = v_u_13.TEXT.addCase
			local function v178()
				-- upvalues: (copy) p_u_120, (ref) v_u_13, (ref) v_u_4, (copy) v_u_145
				if #(p_u_120.me.lines or {}) >= v_u_13.LINES_MAX then
					local v175, v176 = v_u_13.rtext("tooMany", "A trade holds at most 16 lines.")
					if type(v175) == "string" and v175 ~= "" then
						local v177 = v_u_4.toast
						pcall(v177, v175, v176 or "warn")
					end
				else
					v_u_145()
				end
			end
			local v179 = {
				["size"] = nil,
				["order"] = 2,
				["maxTextWidth"] = 140
			}
			local v180 = UDim2.new
			local v181 = p121 * 3 / 4
			v179.size = v180(0.25, -math.ceil(v181), 0, v_u_5.touch(44))
			local v182 = v173(p119, v174, "secondary", "AddCase", v178, v179)
			local v183 = v_u_108
			local v184 = v_u_13.TEXT.addSkin
			local function v188()
				-- upvalues: (copy) p_u_120, (ref) v_u_13, (ref) v_u_4, (copy) v_u_147
				if #(p_u_120.me.lines or {}) >= v_u_13.LINES_MAX then
					local v185, v186 = v_u_13.rtext("tooMany", "A trade holds at most 16 lines.")
					if type(v185) == "string" and v185 ~= "" then
						local v187 = v_u_4.toast
						pcall(v187, v185, v186 or "warn")
					end
				else
					v_u_147()
				end
			end
			local v189 = {
				["size"] = nil,
				["order"] = 3,
				["maxTextWidth"] = 140
			}
			local v190 = UDim2.new
			local v191 = p121 * 3 / 4
			v189.size = v190(0.25, -math.ceil(v191), 0, v_u_5.touch(44))
			local v192 = v183(p119, v184, "secondary", "AddSkin", v188, v189)
			local v193 = v_u_108
			local v194 = v_u_13.TEXT.cash
			local v195 = {
				["size"] = nil,
				["order"] = 4,
				["maxTextWidth"] = 140
			}
			local v196 = UDim2.new
			local v197 = p121 * 3 / 4
			v195.size = v196(0.25, -math.ceil(v197), 0, v_u_5.touch(44))
			local v198 = v193(p119, v194, "secondary", "Cash", v162, v195)
			local v199 = v_u_53
			local v200 = v_u_53
			local v201 = v_u_53
			v_u_53.addItem = v172
			v199.addCase = v182
			v200.addSkin = v192
			v201.addCash = v198
		end
		local function v_u_221(p203, p204, p205, p206) -- name: notesBlock
			-- upvalues: (copy) v_u_13, (copy) v_u_4, (copy) v_u_6, (ref) v_u_41
			local v207 = v_u_13.cashLines(p204)
			local v208 = v_u_4.new("Frame", {
				["Name"] = "Notes",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = p205
			}, p203)
			v_u_4.layout(v208, "v", 2)
			local v209 = 0
			local v210 = v207.firNote
			v209 = v209 + 1
			v_u_4.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v208,
				["name"] = "Note" .. v209,
				["text"] = v210,
				["color"] = v_u_6.text2,
				["order"] = v209
			})
			local v211 = v207.feeNote
			v209 = v209 + 1
			v_u_4.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "micro",
				["color"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["order"] = nil,
				["parent"] = v208,
				["name"] = "Note" .. v209,
				["text"] = v211,
				["color"] = v_u_6.text2,
				["order"] = v209
			})
			local v212
			if v207.youGet then
				local v213 = v207.youGet
				local v214 = v_u_6.success
				v209 = v209 + 1
				v_u_4.label({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v208,
					["name"] = "Note" .. v209,
					["text"] = v213,
					["color"] = v214 or v_u_6.text2,
					["order"] = v209
				})
				v212 = v209
			else
				v212 = v209
			end
			local v215 = v_u_41
			local v216
			if type(v215) == "table" then
				local v217 = v_u_41.limits
				if type(v217) == "table" then
					local v218 = v_u_41.limits.line or ""
					local v219 = tostring(v218)
					local v220 = v_u_41.limits.resets
					v216 = v219 .. (type(v220) ~= "string" and "" or " " .. v_u_41.limits.resets)
				else
					v216 = ""
				end
			else
				v216 = ""
			end
			if v216 ~= "" and not p206 then
				v209 = v212 + 1
				v_u_4.label({
					["parent"] = nil,
					["name"] = nil,
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = v208,
					["name"] = "Note" .. v209,
					["text"] = v216,
					["color"] = v_u_6.text2,
					["order"] = v209
				})
			end
			return v208
		end
		local function v_u_230(p222, p223, p224, p225, p226) -- name: statusChip
			-- upvalues: (copy) v_u_7, (copy) v_u_13, (copy) v_u_6
			local v227 = v_u_7.pill
			local v228
			if p223 then
				v228 = v_u_13.TEXT.ready
			else
				v228 = v_u_13.TEXT.notReadyChip
			end
			local v229
			if p223 then
				v229 = v_u_6.success
			else
				v229 = v_u_6.muted
			end
			return v227(p222, v228, v229, {
				["name"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["solid"] = nil,
				["h"] = 20,
				["name"] = p224,
				["position"] = p225,
				["anchor"] = p226,
				["solid"] = p223
			})
		end
		local function v_u_239(p231, p232, _) -- name: rowsFor
			-- upvalues: (copy) v_u_13, (copy) v_u_91
			local v233 = {}
			for _, v234 in p231.lines or {} do
				local v235 = #v233 + 1
				local v236 = v_u_13.rowModel
				local v237 = v_u_91
				local v238
				if p232 then
					v238 = p232[v_u_13.keyOf(v234)]
				else
					v238 = nil
				end
				v233[v235] = v236(v234, v237, v238)
			end
			return v233
		end
		local function v_u_256(p240, p241, p242, p243, p244, p245) -- name: fillSide
			-- upvalues: (copy) v_u_239, (copy) v_u_4, (copy) v_u_13, (copy) v_u_6, (copy) v_u_19, (ref) v_u_92, (copy) v_u_5, (copy) v_u_57, (ref) v_u_32, (ref) v_u_37, (copy) v_u_54
			local v246 = v_u_239(p241, p245)
			if #v246 == 0 and (p241.cash or 0) == 0 then
				v_u_4.label({
					["parent"] = nil,
					["name"] = "Empty",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["wrap"] = true,
					["autoY"] = true,
					["order"] = nil,
					["parent"] = p240,
					["text"] = v_u_13.TEXT.emptySide,
					["color"] = v_u_6.muted,
					["order"] = p244 + 1
				})
				p244 = p244 + 1
			end
			for _, v247 in v246 do
				p244 = p244 + 1
				local v254 = v_u_19.row(v_u_92, p240, v247, {
					["h"] = v_u_5.touch(p243.rowH),
					["order"] = p244,
					["remove"] = p242 and function(p248)
						-- upvalues: (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
						local v_u_249 = {
							["line"] = p248.line
						}
						if not v_u_57.tradeRemove then
							v_u_57.tradeRemove = true
							local v_u_250 = "tradeRemove"
							local v_u_251 = nil
							task.spawn(function()
								-- upvalues: (ref) v_u_32, (copy) v_u_250, (copy) v_u_249, (ref) v_u_57, (copy) v_u_251, (ref) v_u_37
								local v252 = v_u_32.op(v_u_250, v_u_249 or {})
								v_u_57[v_u_250] = nil
								if v_u_251 then
									local v253 = v_u_251
									pcall(v253, v252)
								end
								if v_u_37 then
									v_u_32.refresh(true)
								end
							end)
						end
					end or nil
				}).release
				local v255 = v_u_54
				table.insert(v255, v254)
			end
			if (p241.cash or 0) > 0 then
				p244 = p244 + 1
				v_u_19.cashRow(v_u_92, p240, v_u_13.money(p241.cash), p244, {
					["h"] = v_u_5.touch(44)
				})
			end
			return p244
		end
		local function v_u_259(p257) -- name: centerCard
			-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_62
			local v258 = v_u_4.new("Frame", {
				["Name"] = "Card",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["BackgroundColor3"] = v_u_6.raised,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(0.86, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y
			}, v_u_62)
			v_u_4.new("UISizeConstraint", {
				["MaxSize"] = Vector2.new(p257, 9999)
			}, v258)
			v_u_4.stroke(v258, v_u_6.lineStrong)
			v_u_4.pad(v258, {
				20,
				20,
				16,
				16
			})
			v_u_4.layout(v258, "v", 10, "center")
			return v258
		end
		local function v_u_264() -- name: buildOff
			-- upvalues: (copy) v_u_259, (copy) v_u_13, (ref) v_u_41, (copy) v_u_4, (copy) v_u_6, (copy) v_u_108, (ref) v_u_32, (copy) v_u_5
			local v260 = v_u_259(520)
			local v261 = v_u_13.TEXT.closedDefault
			local v262 = v_u_41
			if type(v262) == "table" then
				local v263 = v_u_41.why
				if type(v263) == "string" then
					v261 = v_u_41.why
				elseif v_u_41 == nil then
					v261 = v_u_13.TEXT.pickLoading
				end
			elseif v_u_41 == nil then
				v261 = v_u_13.TEXT.pickLoading
			end
			v_u_4.label({
				["parent"] = nil,
				["name"] = "Text",
				["text"] = nil,
				["style"] = "body",
				["color"] = nil,
				["align"] = "center",
				["wrap"] = true,
				["autoY"] = true,
				["size"] = nil,
				["order"] = 1,
				["parent"] = v260,
				["text"] = v261,
				["color"] = v_u_6.text2,
				["size"] = UDim2.new(1, 0, 0, 0)
			})
			if v_u_41 ~= nil then
				v_u_108(v260, v_u_13.TEXT.reload, "secondary", "Reload", function()
					-- upvalues: (ref) v_u_32
					v_u_32.refresh(true)
				end, {
					["size"] = nil,
					["order"] = 2,
					["size"] = UDim2.fromOffset(200, v_u_5.touch(44))
				})
			end
		end
		local v_u_599 = {
			["players"] = function() -- name: buildPlayers
				-- upvalues: (copy) v_u_100, (copy) v_u_13, (copy) v_u_10, (copy) v_u_5, (copy) v_u_4, (copy) v_u_62, (ref) v_u_50, (copy) v_u_34, (copy) v_u_108, (copy) v_u_42, (copy) v_u_53, (ref) v_u_41, (copy) v_u_114, (copy) v_u_6, (ref) v_u_32, (copy) v_u_19, (ref) v_u_92, (ref) v_u_47, (copy) v_u_7, (copy) v_u_57, (ref) v_u_37
				local v265 = v_u_100()
				local v266 = v_u_13.layout
				local v267 = v265.X
				local v268 = v265.Y
				local v269 = v_u_10
				local function v270()
					-- upvalues: (ref) v_u_5
					return v_u_5.viewport()
				end
				local v271, v272 = pcall(v270)
				local v273
				if v271 and (typeof(v272) == "Vector2" and v272.X > 40) then
					v273 = v272.X
				else
					v273 = nil
				end
				local v274 = v266(v267, v268, v269, v273)
				local v275 = v_u_4.new("Frame", {
					["Name"] = "Top",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(44))
				}, v_u_62)
				local _, v_u_276 = v_u_4.input({
					["parent"] = nil,
					["name"] = "Search",
					["placeholder"] = nil,
					["size"] = nil,
					["maxLength"] = 24,
					["text"] = nil,
					["parent"] = v275,
					["placeholder"] = v_u_13.TEXT.search,
					["size"] = UDim2.new(1, -132, 0, v_u_5.touch(40)),
					["text"] = v_u_50
				})
				v_u_276.FocusLost:Connect(function()
					-- upvalues: (ref) v_u_50, (copy) v_u_276, (ref) v_u_34
					v_u_50 = v_u_276.Text
					v_u_34.render(true)
				end)
				v_u_53.histBtn = v_u_108(v275, v_u_13.TEXT.history, "secondary", "History", function()
					-- upvalues: (ref) v_u_42, (ref) v_u_34
					v_u_42.history = true
					v_u_34.render(true)
				end, {
					["width"] = 124,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["maxTextWidth"] = 108,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, 0, 0, 0),
					["size"] = UDim2.fromOffset(124, v_u_5.touch(44))
				})
				local v277 = v_u_4.list({
					["parent"] = nil,
					["name"] = "List",
					["position"] = nil,
					["size"] = nil,
					["gap"] = 6,
					["parent"] = v_u_62,
					["position"] = UDim2.fromOffset(0, v_u_5.touch(44) + 8),
					["size"] = UDim2.new(1, 0, 1, -(v_u_5.touch(44) + 8 + 22 + 4))
				})
				v_u_53.list = v277
				local v278 = 0
				local v279 = v_u_41
				if type(v279) == "table" and v_u_41.ok == false then
					local v280 = v_u_41.why
					if type(v280) == "string" then
						local v281 = v_u_114
						local v282 = v_u_41.why
						v278 = v278 + 1
						v281(v277, v282, v278, v_u_6.accent)
					end
				end
				local v283 = v_u_32.reqs()
				if #v283 > 0 then
					local v284 = v_u_19.section
					local v285 = v_u_92
					local v286 = v_u_13.TEXT.requestsTitle
					v278 = v278 + 1
					v284(v285, v277, v286, v278)
					for _, v287 in v283 do
						local v288 = v_u_5.touch(54)
						local v289 = v_u_4.new
						local v290 = {
							["Name"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.12,
							["BorderSizePixel"] = 0,
							["Size"] = nil,
							["LayoutOrder"] = nil
						}
						local v291 = v287.from
						v290.Name = "Request_" .. tostring(v291)
						v290.BackgroundColor3 = v_u_6.raised
						v290.Size = UDim2.new(1, 0, 0, v288)
						v278 = v278 + 1
						v290.LayoutOrder = v278
						local v292 = v289("Frame", v290, v277)
						v_u_4.stroke(v292, v_u_6.accent)
						local v293 = v274.mode == "wide" and 112 or 100
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "bodyStrong",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v292,
							["text"] = v_u_13.rtext("wants", "%s wants to trade.", v287.name),
							["color"] = v_u_6.text,
							["position"] = UDim2.fromOffset(12, 0),
							["size"] = UDim2.new(1, -(v293 * 3 + 36), 1, 0)
						})
						local v294 = v_u_4.new("Frame", {
							["Name"] = "Buttons",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(1, 0.5),
							["Position"] = UDim2.new(1, -8, 0.5, 0),
							["Size"] = UDim2.fromOffset(v293 * 3 + 12, v_u_5.touch(44))
						}, v292)
						v_u_4.layout(v294, "h", 6)
						local v_u_295 = v287.from
						v_u_108(v294, v_u_13.TEXT.accept, "primary", "Accept", function()
							-- upvalues: (ref) v_u_32, (copy) v_u_295
							task.spawn(v_u_32.answer, v_u_295, true, false)
						end, {
							["size"] = nil,
							["order"] = 1,
							["maxTextWidth"] = nil,
							["size"] = UDim2.fromOffset(v293, v_u_5.touch(44)),
							["maxTextWidth"] = v293 - 12
						})
						v_u_108(v294, v_u_13.TEXT.decline, "secondary", "Decline", function()
							-- upvalues: (ref) v_u_32, (copy) v_u_295
							task.spawn(v_u_32.answer, v_u_295, false, false)
						end, {
							["size"] = nil,
							["order"] = 2,
							["maxTextWidth"] = nil,
							["size"] = UDim2.fromOffset(v293, v_u_5.touch(44)),
							["maxTextWidth"] = v293 - 12
						})
						v_u_108(v294, v_u_13.TEXT.block, "ghost", "Block", function()
							-- upvalues: (ref) v_u_32, (copy) v_u_295
							task.spawn(v_u_32.answer, v_u_295, false, true)
						end, {
							["size"] = nil,
							["order"] = 3,
							["maxTextWidth"] = nil,
							["size"] = UDim2.fromOffset(v293, v_u_5.touch(44)),
							["maxTextWidth"] = v293 - 12
						})
					end
				end
				local v296 = v_u_19.section
				local v297 = v_u_92
				local v298 = v_u_13.TEXT.playersTitle
				v278 = v278 + 1
				v296(v297, v277, v298, v278)
				local v299 = v_u_47
				local v300 = type(v299) ~= "table" and {} or v_u_13.filterPlayers(v_u_47.rows, v_u_50)
				if v_u_47 == nil then
					local v301 = v_u_4.label
					local v302 = {
						["parent"] = nil,
						["name"] = "Loading",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v277,
						["text"] = v_u_13.TEXT.pickLoading,
						["color"] = v_u_6.text2
					}
					v278 = v278 + 1
					v302.order = v278
					v301(v302)
				elseif #v300 == 0 then
					local v303 = v_u_4.label
					local v304 = {
						["parent"] = nil,
						["name"] = "Empty",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v277
					}
					local v305
					if v_u_50 == "" then
						v305 = v_u_47.why or v_u_13.TEXT.noPlayers
					else
						v305 = v_u_13.TEXT.noMatch
					end
					v304.text = v305
					v304.color = v_u_6.text2
					v278 = v278 + 1
					v304.order = v278
					v303(v304)
				end
				for _, v306 in v300 do
					local v307 = v_u_5.touch(v274.rowH)
					local v308 = v_u_4.new
					local v309 = {
						["Name"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = nil,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil
					}
					local v310 = v306.u
					v309.Name = "Player_" .. tostring(v310)
					v309.BackgroundColor3 = v_u_6.raised
					v309.BackgroundTransparency = v306.ok and 0.15 or 0.5
					v309.Size = UDim2.new(1, 0, 0, v307)
					v278 = v278 + 1
					v309.LayoutOrder = v278
					local v311 = v308("Frame", v309, v277)
					v_u_4.stroke(v311, v_u_6.line)
					v311:SetAttribute("Ok", v306.ok == true)
					local v312 = v_u_4.new("Frame", {
						["Name"] = "NameLine",
						["BackgroundTransparency"] = 1,
						["Position"] = nil,
						["Size"] = nil,
						["Position"] = UDim2.fromOffset(12, 0),
						["Size"] = UDim2.new(1, -142, 1, 0)
					}, v311)
					v_u_4.layout(v312, "h", 8)
					local v313 = v_u_4.label
					local v314 = {
						["parent"] = nil,
						["name"] = "Name",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["autoX"] = true,
						["size"] = nil,
						["track"] = false,
						["order"] = 1,
						["parent"] = v312
					}
					local v315 = v306.n
					v314.text = tostring(v315)
					local v316
					if v306.ok then
						v316 = v_u_6.text
					else
						v316 = v_u_6.text2
					end
					v314.color = v316
					v314.size = UDim2.fromOffset(0, v307)
					v313(v314)
					local v317 = v306.d
					if type(v317) == "string" and (v306.d ~= "" and v306.d ~= v306.n) then
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Display",
							["text"] = nil,
							["style"] = "micro",
							["color"] = nil,
							["autoX"] = true,
							["size"] = nil,
							["track"] = false,
							["order"] = 2,
							["parent"] = v312,
							["text"] = v306.d,
							["color"] = v_u_6.text2,
							["size"] = UDim2.fromOffset(0, v307)
						})
					end
					if v306.sq then
						v_u_7.pill(v312, v_u_13.TEXT.squadChip, v_u_6.info, {
							["name"] = "Squad",
							["order"] = 3,
							["h"] = 18
						})
					end
					if v306.ok then
						local v_u_318 = v306.u
						v_u_108(v311, v_u_13.TEXT.ask, "primary", "Ask", function()
							-- upvalues: (copy) v_u_318, (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
							local v_u_319 = {
								["to"] = v_u_318
							}
							if not v_u_57.tradeAsk then
								v_u_57.tradeAsk = true
								local v_u_320 = "tradeAsk"
								local v_u_321 = nil
								task.spawn(function()
									-- upvalues: (ref) v_u_32, (copy) v_u_320, (copy) v_u_319, (ref) v_u_57, (copy) v_u_321, (ref) v_u_37
									local v322 = v_u_32.op(v_u_320, v_u_319 or {})
									v_u_57[v_u_320] = nil
									if v_u_321 then
										local v323 = v_u_321
										pcall(v323, v322)
									end
									if v_u_37 then
										v_u_32.refresh(true)
									end
								end)
							end
						end, {
							["size"] = nil,
							["anchor"] = nil,
							["position"] = nil,
							["maxTextWidth"] = 96,
							["size"] = UDim2.fromOffset(112, v_u_5.touch(44)),
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, -8, 0.5, 0)
						})
					else
						v_u_4.label({
							["parent"] = nil,
							["name"] = "NotNow",
							["text"] = nil,
							["style"] = "caps",
							["color"] = nil,
							["align"] = "right",
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["track"] = false,
							["parent"] = v311,
							["text"] = v_u_13.TEXT.notNow,
							["color"] = v_u_6.muted,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, -14, 0.5, 0),
							["size"] = UDim2.fromOffset(100, 24)
						})
					end
				end
				local v324 = ""
				local v325 = v_u_41
				if type(v325) == "table" then
					local v326 = v_u_41.limits
					if type(v326) == "table" then
						local v327 = v_u_41.limits.line or ""
						local v328 = tostring(v327)
						local v329 = v_u_41.limits.resets
						v324 = v328 .. (type(v329) ~= "string" and "" or " " .. v_u_41.limits.resets)
					end
				end
				v_u_53.limits = v_u_4.label({
					["parent"] = nil,
					["name"] = "Limits",
					["text"] = nil,
					["style"] = "micro",
					["color"] = nil,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v_u_62,
					["text"] = v324,
					["color"] = v_u_6.text2,
					["anchor"] = Vector2.new(0, 1),
					["position"] = UDim2.new(0, 2, 1, 0),
					["size"] = UDim2.new(1, -4, 0, 22)
				})
			end,
			["ask"] = function() -- name: buildAsk
				-- upvalues: (ref) v_u_41, (copy) v_u_4, (copy) v_u_6, (copy) v_u_62, (copy) v_u_13, (copy) v_u_53, (copy) v_u_108, (copy) v_u_57, (ref) v_u_32, (ref) v_u_37, (copy) v_u_5, (copy) v_u_40
				local v330 = v_u_41
				local v331
				if type(v330) == "table" then
					v331 = v_u_41.s
				else
					v331 = nil
				end
				local v332 = v331 or {}
				local v333 = v_u_4.new("Frame", {
					["Name"] = "AskCard",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.12,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["BackgroundColor3"] = v_u_6.raised,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.new(0, 460, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v_u_62)
				v333.Size = UDim2.new(0.8, 0, 0, 0)
				v_u_4.new("UISizeConstraint", {
					["MaxSize"] = Vector2.new(520, 9999)
				}, v333)
				v_u_4.stroke(v333, v_u_6.lineStrong)
				v_u_4.pad(v333, {
					20,
					20,
					18,
					18
				})
				v_u_4.layout(v333, "v", 10, "center")
				local v334 = v_u_4.label
				local v335 = {
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["align"] = "center",
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = 1,
					["parent"] = v333
				}
				local v336 = v_u_13.rtext
				local v337 = v332.name or "them"
				v335.text = v336("waiting", "Waiting for %s.", (tostring(v337)))
				v335.color = v_u_6.text
				v335.size = UDim2.new(1, 0, 0, 0)
				v334(v335)
				local v338 = v_u_53
				local v339 = v_u_4.label
				local v340 = {
					["parent"] = nil,
					["name"] = "Left",
					["text"] = nil,
					["style"] = "small",
					["color"] = nil,
					["align"] = "center",
					["wrap"] = true,
					["autoY"] = true,
					["size"] = nil,
					["order"] = 2,
					["parent"] = v333
				}
				local v341 = v_u_13.text
				local v342 = v332.left
				v340.text = v341("waitingSub", tonumber(v342) or 0)
				v340.color = v_u_6.text2
				v340.size = UDim2.new(1, 0, 0, 0)
				v338.askLeft = v339(v340)
				v_u_108(v333, v_u_13.TEXT.cancel, "secondary", "Cancel", function()
					-- upvalues: (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
					if not v_u_57.tradeCancel then
						v_u_57.tradeCancel = true
						local v_u_343 = "tradeCancel"
						local v_u_344 = nil
						local v_u_345 = nil
						task.spawn(function()
							-- upvalues: (ref) v_u_32, (copy) v_u_343, (copy) v_u_344, (ref) v_u_57, (copy) v_u_345, (ref) v_u_37
							local v346 = v_u_32.op(v_u_343, v_u_344 or {})
							v_u_57[v_u_343] = nil
							if v_u_345 then
								local v347 = v_u_345
								pcall(v347, v346)
							end
							if v_u_37 then
								v_u_32.refresh(true)
							end
						end)
					end
				end, {
					["size"] = nil,
					["order"] = 3,
					["size"] = UDim2.fromOffset(200, v_u_5.touch(44))
				})
				local v348 = v_u_53
				local v349 = v_u_40()
				local v350 = v332.left
				v348.askEnds = v349 + (tonumber(v350) or 30)
			end,
			["edit"] = function() -- name: buildEdit
				-- upvalues: (ref) v_u_41, (ref) v_u_51, (copy) v_u_239, (copy) v_u_100, (copy) v_u_13, (copy) v_u_10, (copy) v_u_5, (copy) v_u_4, (copy) v_u_62, (copy) v_u_6, (copy) v_u_53, (copy) v_u_108, (copy) v_u_57, (ref) v_u_32, (ref) v_u_37, (ref) v_u_43, (copy) v_u_230, (copy) v_u_256, (copy) v_u_202, (copy) v_u_221, (ref) v_u_44, (copy) v_u_34, (ref) v_u_46, (copy) v_u_40
				local v351 = v_u_41
				local v_u_352
				if type(v351) == "table" then
					v_u_352 = v_u_41.s
				else
					v_u_352 = nil
				end
				if v_u_352 ~= nil then
					v_u_51.give = v_u_239(v_u_352.me, nil)
					v_u_51.get = v_u_239(v_u_352.you, nil)
					local v353 = v_u_51
					local v354 = v_u_51
					local v355 = v_u_352.me.cash
					local v356 = v_u_352.fee and v_u_352.fee.youGet or v_u_352.you.cash
					v353.giveCash = v355
					v354.getCash = v356
					local v357 = v_u_100()
					local v358 = v_u_13.layout
					local v359 = v357.X
					local v360 = v357.Y
					local v361 = v_u_10
					local function v362()
						-- upvalues: (ref) v_u_5
						return v_u_5.viewport()
					end
					local v363, v364 = pcall(v362)
					local v365
					if v363 and (typeof(v364) == "Vector2" and v364.X > 40) then
						v365 = v364.X
					else
						v365 = nil
					end
					local v366 = v358(v359, v360, v361, v365)
					local v367 = v366.mode == "wide"
					local v368 = v_u_5.touch(44) + (v367 and 10 or 6)
					if v367 then
						local v369 = v_u_4.new("Frame", {
							["Name"] = "Head",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, 0, 0, 34)
						}, v_u_62)
						local v370 = v_u_4.label
						local v371 = {
							["parent"] = nil,
							["name"] = "With",
							["text"] = nil,
							["style"] = "h3",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v369
						}
						local v372 = v_u_13.text
						local v373 = v_u_352.you.name
						v371.text = v372("tradeWith", (tostring(v373)))
						v371.color = v_u_6.text
						v371.position = UDim2.fromOffset(2, 0)
						v371.size = UDim2.new(0.5, 0, 1, 0)
						v370(v371)
						v_u_53.status = v_u_4.label({
							["parent"] = nil,
							["name"] = "Status",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v369,
							["text"] = v_u_13.statusLine(v_u_352),
							["color"] = v_u_6.text2,
							["position"] = UDim2.fromScale(0.45, 0),
							["size"] = UDim2.fromScale(0.55, 1)
						})
					end
					local v374 = v_u_13.readyState(v_u_352)
					local v375 = v_u_4.new("Frame", {
						["Name"] = "Bar",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.fromScale(0, 1),
						["Size"] = UDim2.new(1, 0, 0, v368)
					}, v_u_62)
					v_u_108(v375, v_u_13.TEXT.cancel, "secondary", "Cancel", function()
						-- upvalues: (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
						if not v_u_57.tradeCancel then
							v_u_57.tradeCancel = true
							local v_u_376 = "tradeCancel"
							local v_u_377 = nil
							local v_u_378 = nil
							task.spawn(function()
								-- upvalues: (ref) v_u_32, (copy) v_u_376, (copy) v_u_377, (ref) v_u_57, (copy) v_u_378, (ref) v_u_37
								local v379 = v_u_32.op(v_u_376, v_u_377 or {})
								v_u_57[v_u_376] = nil
								if v_u_378 then
									local v380 = v_u_378
									pcall(v380, v379)
								end
								if v_u_37 then
									v_u_32.refresh(true)
								end
							end)
						end
					end, {
						["size"] = nil,
						["anchor"] = nil,
						["position"] = nil,
						["maxTextWidth"] = 130,
						["size"] = UDim2.fromOffset(150, v_u_5.touch(44)),
						["anchor"] = Vector2.new(0, 0.5),
						["position"] = UDim2.fromScale(0, 0.5)
					})
					local v394, v395 = v_u_108(v375, v374.text, v374.on and "secondary" or "primary", "Ready", function()
						-- upvalues: (ref) v_u_41, (ref) v_u_13, (ref) v_u_43, (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
						local v381 = v_u_41
						local v382
						if type(v381) == "table" then
							v382 = v_u_41.s
						else
							v382 = nil
						end
						if v382 == nil then
							return
						else
							local v383 = v_u_13.readyState(v382)
							if not v383.on then
								v_u_43 = v_u_13.approve(v_u_43, v382)
							end
							local v_u_384 = {
								["ver"] = v382.ver,
								["on"] = not v383.on
							}
							if not v_u_57.tradeReady then
								v_u_57.tradeReady = true
								local v_u_385 = "tradeReady"
								local v_u_386 = nil
								task.spawn(function()
									-- upvalues: (ref) v_u_32, (copy) v_u_385, (copy) v_u_384, (ref) v_u_57, (copy) v_u_386, (ref) v_u_37
									local v387 = v_u_32.op(v_u_385, v_u_384 or {})
									v_u_57[v_u_385] = nil
									if v_u_386 then
										local v388 = v_u_386
										pcall(v388, v387)
									end
									if v_u_37 then
										v_u_32.refresh(true)
									end
								end)
							end
						end
					end, {
						["size"] = UDim2.fromOffset(v_u_13.READY_W, v_u_5.touch(44)),
						["anchor"] = Vector2.new(1, 0.5),
						["position"] = UDim2.fromScale(1, 0.5),
						["maxTextWidth"] = v_u_13.READY_W - 20,
						["disabled"] = not v374.enabled,
						["onDisabledClick"] = function() -- name: onDisabledClick
							-- upvalues: (ref) v_u_13, (ref) v_u_41, (copy) v_u_352, (ref) v_u_4
							local v389 = v_u_13.readyState
							local v390 = v_u_41
							local v391
							if type(v390) == "table" then
								v391 = v_u_41.s
							else
								v391 = nil
							end
							local v392 = v389(v391 or v_u_352).why or v_u_13.rtext("room", "Not enough room in your stash.")
							if type(v392) == "string" and v392 ~= "" then
								local v393 = v_u_4.toast
								pcall(v393, v392, "warn")
							end
						end
					})
					local v396 = v_u_53
					v_u_53.ready = v394
					v396.readyApi = v395
					if not v367 then
						v_u_53.status = v_u_4.label({
							["parent"] = nil,
							["name"] = "Status",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["align"] = "center",
							["wrap"] = true,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v375,
							["text"] = v_u_13.statusLine(v_u_352),
							["color"] = v_u_6.text2,
							["position"] = UDim2.fromOffset(160, 0),
							["size"] = UDim2.new(1, -390, 1, 0)
						})
					end
					if v367 then
						local v397 = v368 + 6
						local v398 = UDim2.new(0.5, -6, 1, -(40 + v397 + 66))
						for _, v399 in { true, false } do
							local v400
							if v399 then
								v400 = v_u_352.me
							else
								v400 = v_u_352.you
							end
							local v401 = v_u_4.new("Frame", {
								["Name"] = nil,
								["BackgroundColor3"] = nil,
								["BackgroundTransparency"] = 0.35,
								["BorderSizePixel"] = 0,
								["Position"] = nil,
								["Size"] = nil,
								["Name"] = v399 and "ColYou" or "ColThey",
								["BackgroundColor3"] = v_u_6.bgDeep,
								["Position"] = UDim2.new(v399 and 0 or 0.5, v399 and 0 or 6, 0, 40),
								["Size"] = v398
							}, v_u_62)
							v_u_4.stroke(v401, v_u_6.line)
							local v402 = v_u_4.new("Frame", {
								["Name"] = "Head",
								["BackgroundTransparency"] = 1,
								["Size"] = nil,
								["Size"] = UDim2.new(1, 0, 0, 34)
							}, v401)
							local v403 = v_u_4.label
							local v404 = {
								["parent"] = nil,
								["name"] = "Title",
								["text"] = nil,
								["style"] = "caps",
								["color"] = nil,
								["position"] = nil,
								["size"] = nil,
								["fit"] = true,
								["track"] = false,
								["parent"] = v402
							}
							local v405
							if v399 then
								v405 = v_u_13.TEXT.youOffer
							else
								v405 = v_u_13.TEXT.theyOffer
							end
							v404.text = v405
							v404.color = v_u_6.text
							v404.position = UDim2.fromOffset(12, 0)
							v404.size = UDim2.new(0.6, 0, 1, 0)
							v403(v404)
							v_u_230(v402, v400.ready == true, "ReadyChip", UDim2.new(1, -10, 0.5, 0), Vector2.new(1, 0.5))
							local v406 = not v399 and 0 or v_u_5.touch(44) + 10
							v_u_256(v_u_4.list({
								["parent"] = nil,
								["name"] = "List",
								["position"] = nil,
								["size"] = nil,
								["gap"] = 6,
								["parent"] = v401,
								["position"] = UDim2.fromOffset(6, 36),
								["size"] = UDim2.new(1, -12, 1, -(36 + v406 + 4))
							}), v400, v399, v366, 0, nil)
							if not v399 then
								continue
							end
							local v407 = v_u_4.new("Frame", {
								["Name"] = "Add",
								["BackgroundTransparency"] = 1,
								["AnchorPoint"] = nil,
								["Position"] = nil,
								["Size"] = nil,
								["AnchorPoint"] = Vector2.new(0, 1),
								["Position"] = UDim2.new(0, 6, 1, -6),
								["Size"] = UDim2.new(1, -12, 0, v_u_5.touch(44))
							}, v401)
							v_u_4.layout(v407, "h", 6)
							v_u_202(v407, v_u_352, 6)
						end
						v_u_221(v_u_4.new("Frame", {
							["Name"] = "NotesHost",
							["BackgroundTransparency"] = 1,
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["AnchorPoint"] = Vector2.new(0, 1),
							["Position"] = UDim2.new(0, 2, 1, -v397),
							["Size"] = UDim2.new(1, -4, 0, 66)
						}, v_u_62), v_u_352, 1, false)
					else
						local v408 = v_u_5.touch(44)
						local v409 = v_u_4.tabs
						local v410 = {
							["parent"] = nil,
							["name"] = "Seg",
							["position"] = nil,
							["size"] = nil,
							["tabs"] = nil,
							["selected"] = nil,
							["onChange"] = nil,
							["parent"] = v_u_62,
							["position"] = UDim2.fromOffset(0, 0),
							["size"] = UDim2.new(0, 300, 0, v408)
						}
						local v411 = {}
						local v412 = {
							["id"] = "you",
							["text"] = nil,
							["text"] = v_u_13.TEXT.you .. " (" .. #v_u_352.me.lines .. ")"
						}
						local v413 = {
							["id"] = "they",
							["text"] = nil
						}
						local v414 = v_u_352.you.name
						v413.text = tostring(v414):sub(1, 12) .. " (" .. #v_u_352.you.lines .. ")"
						__set_list(v411, 1, {v412, v413})
						v410.tabs = v411
						v410.selected = v_u_44
						function v410.onChange(p415) -- name: onChange
							-- upvalues: (ref) v_u_44, (ref) v_u_34
							v_u_44 = p415
							v_u_34.render(true)
						end
						local _, _ = v409(v410)
						local v416 = v408 + 4
						if v_u_44 == "you" then
							local v417 = v_u_4.new("Frame", {
								["Name"] = "Add",
								["BackgroundTransparency"] = 1,
								["Position"] = nil,
								["Size"] = nil,
								["Position"] = UDim2.new(0, 308, 0, 0),
								["Size"] = UDim2.new(1, -308, 0, v408)
							}, v_u_62)
							v_u_4.layout(v417, "h", 6)
							v_u_202(v417, v_u_352, 6)
						end
						local v418 = v_u_4.list({
							["parent"] = nil,
							["name"] = "List",
							["position"] = nil,
							["size"] = nil,
							["gap"] = 6,
							["parent"] = v_u_62,
							["position"] = UDim2.fromOffset(0, v416),
							["size"] = UDim2.new(1, 0, 1, -(v416 + v368 + 4))
						})
						local v419
						if v_u_44 == "you" then
							v419 = v_u_352.me
						else
							v419 = v_u_352.you
						end
						v_u_221(v418, v_u_352, v_u_256(v418, v419, v_u_44 == "you", v366, 0, nil) + 1, false)
					end
					local v420 = v_u_40()
					local v421 = v_u_352.lockLeft
					v_u_46 = v420 + (tonumber(v421) or 0)
				end
			end,
			["review"] = function() -- name: buildReview
				-- upvalues: (ref) v_u_41, (copy) v_u_100, (copy) v_u_13, (copy) v_u_10, (copy) v_u_5, (ref) v_u_43, (copy) v_u_91, (ref) v_u_51, (copy) v_u_4, (copy) v_u_62, (copy) v_u_6, (copy) v_u_53, (copy) v_u_19, (ref) v_u_92, (copy) v_u_54, (copy) v_u_221, (copy) v_u_108, (copy) v_u_57, (ref) v_u_32, (ref) v_u_37, (ref) v_u_46, (copy) v_u_40, (copy) v_u_34, (copy) v_u_61
				local v422 = v_u_41
				local v423
				if type(v422) == "table" then
					v423 = v_u_41.s
				else
					v423 = nil
				end
				if v423 ~= nil then
					local v424 = v_u_100()
					local v425 = v_u_13.layout
					local v426 = v424.X
					local v427 = v424.Y
					local v428 = v_u_10
					local function v429()
						-- upvalues: (ref) v_u_5
						return v_u_5.viewport()
					end
					local v430, v431 = pcall(v429)
					local v432
					if v430 and (typeof(v431) == "Vector2" and v431.X > 40) then
						v432 = v431.X
					else
						v432 = nil
					end
					local v_u_433 = v425(v426, v427, v428, v432)
					local v434 = v_u_13.marks(v423, v_u_43 and v_u_43.prev or nil)
					local v435 = v_u_13.summary(v423, v_u_91, v434)
					local v436 = v_u_51
					local v437 = v_u_51
					local v438 = v435.give
					local v439 = v435.get
					v436.give = v438
					v437.get = v439
					local v440 = v_u_51
					local v441 = v_u_51
					local v442
					if v435.giveCash then
						v442 = v435.giveCash.cash or nil
					else
						v442 = nil
					end
					local v443
					if v435.getCash then
						v443 = v435.getCash.cash or nil
					else
						v443 = nil
					end
					v440.giveCash = v442
					v441.getCash = v443
					local v_u_444 = v_u_10 or v424.Y < 330
					local v445 = v_u_5.touch(44) + (v_u_433.mode == "wide" and 10 or 6)
					local v446 = v_u_5.touch(44) + 8
					local v447 = v445 + 4 + v446 + 8
					local v448
					if v_u_433.mode == "wide" then
						v448 = not v_u_444
					else
						v448 = false
					end
					local v449
					if v448 then
						local v450 = v_u_4.new("Frame", {
							["Name"] = "Head",
							["BackgroundTransparency"] = 1,
							["Size"] = nil,
							["Size"] = UDim2.new(1, 0, 0, 34)
						}, v_u_62)
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = nil,
							["style"] = "h3",
							["color"] = nil,
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v450,
							["text"] = v_u_13.TEXT.reviewTitle,
							["color"] = v_u_6.text,
							["position"] = UDim2.fromOffset(2, 0),
							["size"] = UDim2.new(0.4, 0, 1, 0)
						})
						v_u_53.status = v_u_4.label({
							["parent"] = nil,
							["name"] = "Status",
							["text"] = nil,
							["style"] = "small",
							["color"] = nil,
							["align"] = "right",
							["position"] = nil,
							["size"] = nil,
							["fit"] = true,
							["track"] = false,
							["parent"] = v450,
							["text"] = v_u_13.statusLine(v423),
							["color"] = v_u_6.text2,
							["position"] = UDim2.fromScale(0.4, 0),
							["size"] = UDim2.fromScale(0.6, 1)
						})
						v449 = 38
					else
						v449 = 0
					end
					local v_u_451 = v_u_4.list({
						["parent"] = nil,
						["name"] = "Review",
						["position"] = nil,
						["size"] = nil,
						["gap"] = 6,
						["parent"] = v_u_62,
						["position"] = UDim2.fromOffset(0, v449),
						["size"] = UDim2.new(1, 0, 1, -(v449 + v447))
					})
					v_u_53.scroll = v_u_451
					local v_u_452 = 0
					local function v472(p453, p454) -- name: rowsOut
						-- upvalues: (ref) v_u_19, (ref) v_u_92, (copy) v_u_451, (copy) v_u_444, (ref) v_u_5, (copy) v_u_433, (ref) v_u_452, (ref) v_u_4, (ref) v_u_54, (ref) v_u_13, (ref) v_u_6
						for _, v455 in p453 do
							local v456 = v_u_19.row
							local v457 = v_u_92
							local v458 = v_u_451
							local v459 = {
								["h"] = v_u_444 and 38 or v_u_5.touch(v_u_433.rowH)
							}
							v_u_452 = v_u_452 + 1
							v459.order = v_u_452
							v459.compact = v_u_444
							local v_u_460 = v456(v457, v458, v455, v459)
							v_u_460.frame.Selectable = true
							local function v461()
								-- upvalues: (copy) v_u_460, (ref) v_u_4
								v_u_460.frame.SelectionImageObject = v_u_4.selectionImage()
							end
							pcall(v461)
							local v462 = v_u_460.release
							local v463 = v_u_54
							table.insert(v463, v462)
						end
						if p454 ~= nil then
							local v464 = v_u_19.cashRow
							local v465 = v_u_92
							local v466 = v_u_451
							local v467 = p454.text
							v_u_452 = v_u_452 + 1
							local v_u_468 = v464(v465, v466, v467, v_u_452, {
								["h"] = v_u_444 and 34 or v_u_5.touch(44),
								["mark"] = p454.mark
							})
							v_u_468.Selectable = true
							local function v469()
								-- upvalues: (copy) v_u_468, (ref) v_u_4
								v_u_468.SelectionImageObject = v_u_4.selectionImage()
							end
							pcall(v469)
							if p454.gross then
								v_u_468:SetAttribute("Gross", p454.gross)
							end
						end
						if #p453 == 0 and p454 == nil then
							local v470 = v_u_4.label
							local v471 = {
								["parent"] = nil,
								["name"] = "Nothing",
								["text"] = nil,
								["style"] = "small",
								["color"] = nil,
								["wrap"] = true,
								["autoY"] = true,
								["order"] = nil,
								["parent"] = v_u_451,
								["text"] = v_u_13.TEXT.nothing,
								["color"] = v_u_6.muted
							}
							v_u_452 = v_u_452 + 1
							v471.order = v_u_452
							v470(v471)
						end
					end
					if not v448 then
						local v473 = v_u_19.section
						local v474 = v_u_92
						local v475 = v_u_13.TEXT.reviewTitle
						v_u_452 = v_u_452 + 1
						local v476 = v473(v474, v_u_451, v475, v_u_452, v_u_13.statusLine(v423))
						v476.Name = "SectionTitle"
						v_u_53.status = v476:FindFirstChild("Right")
					end
					local v477 = v_u_19.section
					local v478 = v_u_92
					local v479 = v_u_13.text("youGive")
					v_u_452 = v_u_452 + 1
					v477(v478, v_u_451, v479, v_u_452).Name = "SectionGive"
					v472(v435.give, v435.giveCash)
					local v480 = v_u_19.section
					local v481 = v_u_92
					local v482 = v_u_13.text("youGet")
					v_u_452 = v_u_452 + 1
					v480(v481, v_u_451, v482, v_u_452).Name = "SectionGet"
					v472(v435.get, v435.getCash)
					local v483 = v_u_221
					v_u_452 = v_u_452 + 1
					v483(v_u_451, v423, v_u_452, false)
					local v484 = v_u_4.new("Frame", {
						["Name"] = "Bar",
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.fromScale(0, 1),
						["Size"] = UDim2.new(1, 0, 0, v445)
					}, v_u_62)
					v_u_108(v484, v_u_13.TEXT.cancel, "secondary", "Cancel", function()
						-- upvalues: (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
						if not v_u_57.tradeCancel then
							v_u_57.tradeCancel = true
							local v_u_485 = "tradeCancel"
							local v_u_486 = nil
							local v_u_487 = nil
							task.spawn(function()
								-- upvalues: (ref) v_u_32, (copy) v_u_485, (copy) v_u_486, (ref) v_u_57, (copy) v_u_487, (ref) v_u_37
								local v488 = v_u_32.op(v_u_485, v_u_486 or {})
								v_u_57[v_u_485] = nil
								if v_u_487 then
									local v489 = v_u_487
									pcall(v489, v488)
								end
								if v_u_37 then
									v_u_32.refresh(true)
								end
							end)
						end
					end, {
						["size"] = nil,
						["anchor"] = nil,
						["position"] = nil,
						["maxTextWidth"] = 130,
						["size"] = UDim2.fromOffset(150, v_u_5.touch(44)),
						["anchor"] = Vector2.new(0, 0.5),
						["position"] = UDim2.fromScale(0, 0.5)
					})
					v_u_108(v484, v_u_13.TEXT.backToEdit, "secondary", "Unready", function()
						-- upvalues: (ref) v_u_41, (ref) v_u_57, (ref) v_u_32, (ref) v_u_37
						local v490 = v_u_41
						local v491
						if type(v490) == "table" then
							v491 = v_u_41.s
						else
							v491 = nil
						end
						if v491 then
							local v_u_492 = {
								["ver"] = nil,
								["on"] = false,
								["ver"] = v491.ver
							}
							if v_u_57.tradeReady then
								return
							end
							v_u_57.tradeReady = true
							local v_u_493 = "tradeReady"
							local v_u_494 = nil
							task.spawn(function()
								-- upvalues: (ref) v_u_32, (copy) v_u_493, (copy) v_u_492, (ref) v_u_57, (copy) v_u_494, (ref) v_u_37
								local v495 = v_u_32.op(v_u_493, v_u_492 or {})
								v_u_57[v_u_493] = nil
								if v_u_494 then
									local v496 = v_u_494
									pcall(v496, v495)
								end
								if v_u_37 then
									v_u_32.refresh(true)
								end
							end)
						end
					end, {
						["size"] = nil,
						["anchor"] = nil,
						["position"] = nil,
						["maxTextWidth"] = 210,
						["size"] = UDim2.fromOffset(230, v_u_5.touch(44)),
						["anchor"] = Vector2.new(1, 0.5),
						["position"] = UDim2.fromScale(1, 0.5)
					})
					local v497 = v_u_4.new("Frame", {
						["Name"] = "ConfirmRow",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.2,
						["BorderSizePixel"] = 0,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = v_u_6.bgDeep,
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(0, 0, 1, -(v445 + 4)),
						["Size"] = UDim2.new(1, 0, 0, v446)
					}, v_u_62)
					v_u_53.confStroke = v_u_4.stroke(v497, v_u_6.success, 2)
					local v498 = v_u_13.confirmSpot
					local v499 = v424.X
					local v500 = v498((math.max(v499, 1)))
					v_u_53.confHint = v_u_4.label({
						["parent"] = nil,
						["name"] = "Hint",
						["text"] = "",
						["style"] = "micro",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["wrap"] = true,
						["fit"] = true,
						["track"] = false,
						["parent"] = v497,
						["color"] = v_u_6.text2,
						["position"] = UDim2.fromOffset(v500.x + v500.w + 12, 0),
						["size"] = UDim2.new(1, -(v500.x + v500.w + 12 + 8), 1, 0)
					})
					local v520, v521 = v_u_108(v497, v_u_13.TEXT.confirm, "primary", "Confirm", function()
						-- upvalues: (ref) v_u_41, (ref) v_u_13, (ref) v_u_46, (ref) v_u_40, (copy) v_u_451, (ref) v_u_57, (ref) v_u_32, (ref) v_u_37, (ref) v_u_4
						local v501 = v_u_41
						local v502
						if type(v501) == "table" then
							v502 = v_u_41.s
						else
							v502 = nil
						end
						if v502 == nil then
							return
						else
							local v503 = v_u_13.confirmState
							local v504 = v_u_46 - v_u_40()
							local v505 = v503(v502, math.max(0, v504), v_u_13.atEnd(v_u_451.AbsoluteCanvasSize.Y, v_u_451.AbsoluteWindowSize.Y, v_u_451.CanvasPosition.Y))
							if v505.enabled then
								local v_u_506 = {
									["ver"] = v502.ver
								}
								if not v_u_57.tradeConfirm then
									v_u_57.tradeConfirm = true
									local v_u_507 = "tradeConfirm"
									local v_u_508 = nil
									task.spawn(function()
										-- upvalues: (ref) v_u_32, (copy) v_u_507, (copy) v_u_506, (ref) v_u_57, (copy) v_u_508, (ref) v_u_37
										local v509 = v_u_32.op(v_u_507, v_u_506 or {})
										v_u_57[v_u_507] = nil
										if v_u_508 then
											local v510 = v_u_508
											pcall(v510, v509)
										end
										if v_u_37 then
											v_u_32.refresh(true)
										end
									end)
								end
							else
								local v511 = v505.why or v505.text
								if type(v511) == "string" and v511 ~= "" then
									local v512 = v_u_4.toast
									pcall(v512, v511, "info")
								end
								return
							end
						end
					end, {
						["size"] = UDim2.fromOffset(v500.w, v_u_5.touch(44)),
						["anchor"] = Vector2.new(0, 0.5),
						["position"] = UDim2.new(0, v500.x, 0.5, 0),
						["maxTextWidth"] = v500.w - 20,
						["onDisabledClick"] = function() -- name: onDisabledClick
							-- upvalues: (ref) v_u_41, (ref) v_u_13, (ref) v_u_46, (ref) v_u_40, (copy) v_u_451, (ref) v_u_4
							local v513 = v_u_41
							local v514
							if type(v513) == "table" then
								v514 = v_u_41.s
							else
								v514 = nil
							end
							if v514 then
								local v515 = v_u_13.confirmState
								local v516 = v_u_46 - v_u_40()
								local v517 = v515(v514, math.max(0, v516), v_u_13.atEnd(v_u_451.AbsoluteCanvasSize.Y, v_u_451.AbsoluteWindowSize.Y, v_u_451.CanvasPosition.Y))
								local v518 = v517.why or v517.text
								if type(v518) == "string" and v518 ~= "" then
									local v519 = v_u_4.toast
									pcall(v519, v518, "info")
								end
							end
						end
					})
					local v522 = v_u_53
					v_u_53.confirm = v520
					v522.confirmApi = v521
					local v523 = v_u_40()
					local v524 = v423.lockLeft
					v_u_46 = v523 + (tonumber(v524) or 0)
					local function v525() -- name: recheck
						-- upvalues: (ref) v_u_37, (ref) v_u_53, (ref) v_u_34
						if v_u_37 and v_u_53.confirmApi ~= nil then
							v_u_34.tick()
						end
					end
					local v526 = v_u_61
					local v527 = v_u_451:GetPropertyChangedSignal("CanvasPosition")
					table.insert(v526, v527:Connect(v525))
					local v528 = v_u_61
					local v529 = v_u_451:GetPropertyChangedSignal("AbsoluteCanvasSize")
					table.insert(v528, v529:Connect(v525))
					local v530 = v_u_61
					local v531 = v_u_451:GetPropertyChangedSignal("AbsoluteWindowSize")
					table.insert(v530, v531:Connect(v525))
				end
			end,
			["finishing"] = function() -- name: buildFinishing
				-- upvalues: (copy) v_u_259, (ref) v_u_41, (copy) v_u_13, (copy) v_u_4, (copy) v_u_6, (copy) v_u_53
				local v532 = v_u_259(520)
				local v533 = v_u_41
				local v534, v535
				if type(v533) == "table" then
					local v536 = v_u_41.finishing
					v534 = type(v536) == "string" and v_u_41.finishing
					if v534 then
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = nil,
							["style"] = "h3",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["order"] = 1,
							["parent"] = v532,
							["text"] = v_u_13.TEXT.finishingTitle,
							["color"] = v_u_6.text,
							["size"] = UDim2.new(1, 0, 0, 30)
						})
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["align"] = "center",
							["wrap"] = true,
							["autoY"] = true,
							["size"] = nil,
							["order"] = 2,
							["parent"] = v532,
							["text"] = v534,
							["color"] = v_u_6.text2,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v535 = v_u_4.progress({
							["parent"] = nil,
							["size"] = nil,
							["value"] = 0.3,
							["parent"] = v532,
							["size"] = UDim2.new(1, 0, 0, 6)
						})
						v535.frame.LayoutOrder = 3
						v_u_53.bar = v535
					else
						v534 = v_u_13.rtext("completing", "Completing the trade. This takes a few seconds.")
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Title",
							["text"] = nil,
							["style"] = "h3",
							["color"] = nil,
							["align"] = "center",
							["size"] = nil,
							["order"] = 1,
							["parent"] = v532,
							["text"] = v_u_13.TEXT.finishingTitle,
							["color"] = v_u_6.text,
							["size"] = UDim2.new(1, 0, 0, 30)
						})
						v_u_4.label({
							["parent"] = nil,
							["name"] = "Text",
							["text"] = nil,
							["style"] = "body",
							["color"] = nil,
							["align"] = "center",
							["wrap"] = true,
							["autoY"] = true,
							["size"] = nil,
							["order"] = 2,
							["parent"] = v532,
							["text"] = v534,
							["color"] = v_u_6.text2,
							["size"] = UDim2.new(1, 0, 0, 0)
						})
						v535 = v_u_4.progress({
							["parent"] = nil,
							["size"] = nil,
							["value"] = 0.3,
							["parent"] = v532,
							["size"] = UDim2.new(1, 0, 0, 6)
						})
						v535.frame.LayoutOrder = 3
						v_u_53.bar = v535
					end
				else
					v534 = v_u_13.rtext("completing", "Completing the trade. This takes a few seconds.")
					v_u_4.label({
						["parent"] = nil,
						["name"] = "Title",
						["text"] = nil,
						["style"] = "h3",
						["color"] = nil,
						["align"] = "center",
						["size"] = nil,
						["order"] = 1,
						["parent"] = v532,
						["text"] = v_u_13.TEXT.finishingTitle,
						["color"] = v_u_6.text,
						["size"] = UDim2.new(1, 0, 0, 30)
					})
					v_u_4.label({
						["parent"] = nil,
						["name"] = "Text",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["align"] = "center",
						["wrap"] = true,
						["autoY"] = true,
						["size"] = nil,
						["order"] = 2,
						["parent"] = v532,
						["text"] = v534,
						["color"] = v_u_6.text2,
						["size"] = UDim2.new(1, 0, 0, 0)
					})
					v535 = v_u_4.progress({
						["parent"] = nil,
						["size"] = nil,
						["value"] = 0.3,
						["parent"] = v532,
						["size"] = UDim2.new(1, 0, 0, 6)
					})
					v535.frame.LayoutOrder = 3
					v_u_53.bar = v535
					return
				end
			end,
			["result"] = function() -- name: buildResult
				-- upvalues: (copy) v_u_42, (copy) v_u_100, (copy) v_u_13, (copy) v_u_10, (copy) v_u_5, (copy) v_u_4, (copy) v_u_62, (copy) v_u_6, (copy) v_u_19, (ref) v_u_92, (copy) v_u_54, (ref) v_u_51, (copy) v_u_108, (ref) v_u_43, (copy) v_u_34
				local v537 = v_u_42.result
				local v538 = v_u_100()
				local v539 = v_u_13.layout
				local v540 = v538.X
				local v541 = v538.Y
				local v542 = v_u_10
				local function v543()
					-- upvalues: (ref) v_u_5
					return v_u_5.viewport()
				end
				local v544, v545 = pcall(v543)
				local v546
				if v544 and (typeof(v545) == "Vector2" and v545.X > 40) then
					v546 = v545.X
				else
					v546 = nil
				end
				local v547 = v539(v540, v541, v542, v546)
				local v548 = v_u_4.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 36)
				}, v_u_62)
				v_u_4.label({
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v548,
					["text"] = v_u_13.TEXT.resultTitle,
					["color"] = v_u_6.success,
					["position"] = UDim2.fromOffset(2, 0),
					["size"] = UDim2.new(0.6, 0, 1, 0)
				})
				local v549 = v_u_10 or v538.Y < 330
				local v550 = v_u_5.touch(v549 and 44 or 52)
				local v551 = v_u_4.list({
					["parent"] = nil,
					["name"] = "Result",
					["position"] = nil,
					["size"] = nil,
					["gap"] = 6,
					["parent"] = v_u_62,
					["position"] = UDim2.fromOffset(0, 40),
					["size"] = UDim2.new(1, 0, 1, -(40 + v550 + 6))
				})
				local v552 = 0
				local v553 = v_u_19.section
				local v554 = v_u_92
				local v555 = v_u_13.TEXT.resultGave
				v552 = v552 + 1
				v553(v554, v551, v555, v552)
				for _, v556 in v537.gaveRows do
					local v557 = v_u_19.row
					local v558 = v_u_92
					local v559 = {
						["h"] = v549 and 38 or v_u_5.touch(v547.rowH)
					}
					v552 = v552 + 1
					v559.order = v552
					v559.compact = v549
					local v560 = v557(v558, v551, v556, v559).release
					local v561 = v_u_54
					table.insert(v561, v560)
				end
				if (v_u_51.giveCash or 0) > 0 then
					local v562 = v_u_19.cashRow
					local v563 = v_u_92
					local v564 = v_u_13.money(v_u_51.giveCash)
					v552 = v552 + 1
					v562(v563, v551, v564, v552, {
						["h"] = v_u_5.touch(44)
					})
				elseif #v537.gaveRows == 0 then
					local v565 = v_u_4.label
					local v566 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v551,
						["text"] = v_u_13.TEXT.nothing,
						["color"] = v_u_6.muted
					}
					v552 = v552 + 1
					v566.order = v552
					v565(v566)
				end
				local v567 = v_u_19.section
				local v568 = v_u_92
				local v569 = v_u_13.TEXT.resultGot
				v552 = v552 + 1
				v567(v568, v551, v569, v552, v537.gotLine)
				for _, v570 in v537.gotRows do
					local v571 = v_u_19.row
					local v572 = v_u_92
					local v573 = {
						["h"] = v549 and 38 or v_u_5.touch(v547.rowH)
					}
					v552 = v552 + 1
					v573.order = v552
					v573.compact = v549
					local v574 = v571(v572, v551, v570, v573).release
					local v575 = v_u_54
					table.insert(v575, v574)
				end
				if v537.gotCash > 0 then
					local v576 = v_u_19.cashRow
					local v577 = v_u_92
					local v578 = v_u_13.money(v537.gotCash)
					v552 = v552 + 1
					v576(v577, v551, v578, v552, {
						["h"] = v_u_5.touch(44)
					})
				elseif #v537.gotRows == 0 then
					local v579 = v_u_4.label
					local v580 = {
						["parent"] = nil,
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v551,
						["text"] = v537.gotLine,
						["color"] = v_u_6.text2
					}
					v552 = v552 + 1
					v580.order = v552
					v579(v580)
				end
				if v537.feeLine then
					local v581 = v_u_4.label
					local v582 = {
						["parent"] = nil,
						["name"] = "Fee",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v551,
						["text"] = v537.feeLine,
						["color"] = v_u_6.text2
					}
					v552 = v552 + 1
					v582.order = v552
					v581(v582)
				end
				if v537.overflowLine then
					local v583 = v_u_4.label
					local v584 = {
						["parent"] = nil,
						["name"] = "Overflow",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = v551,
						["text"] = v537.overflowLine,
						["color"] = v_u_6.accent
					}
					v552 = v552 + 1
					v584.order = v552
					v583(v584)
				end
				v_u_108(v_u_4.new("Frame", {
					["Name"] = "Bar",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, v550)
				}, v_u_62), v_u_13.TEXT.resultDone, "primary", "Done", function()
					-- upvalues: (ref) v_u_42, (ref) v_u_51, (ref) v_u_43, (ref) v_u_34
					v_u_42.result = nil
					v_u_51 = {
						["give"] = {},
						["get"] = {}
					}
					v_u_43 = nil
					v_u_34.render(true)
				end, {
					["size"] = UDim2.fromOffset(220, v_u_5.touch(44)),
					["anchor"] = Vector2.new(1, 0.5),
					["position"] = UDim2.fromScale(1, 0.5)
				})
			end,
			["history"] = function() -- name: buildHistory
				-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_62, (copy) v_u_108, (copy) v_u_13, (copy) v_u_42, (copy) v_u_34, (copy) v_u_6, (ref) v_u_41, (copy) v_u_55, (copy) v_u_56, (ref) v_u_1, (ref) v_u_37, (ref) v_u_38
				local v585 = v_u_4.new("Frame", {
					["Name"] = "Head",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, v_u_5.touch(44))
				}, v_u_62)
				v_u_108(v585, v_u_13.TEXT.back, "secondary", "Back", function()
					-- upvalues: (ref) v_u_42, (ref) v_u_34
					v_u_42.history = false
					v_u_34.render(true)
				end, {
					["size"] = UDim2.fromOffset(120, v_u_5.touch(44)),
					["position"] = UDim2.fromOffset(0, 0)
				})
				v_u_4.label({
					["parent"] = nil,
					["name"] = "Title",
					["text"] = nil,
					["style"] = "h3",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["fit"] = true,
					["track"] = false,
					["parent"] = v585,
					["text"] = v_u_13.TEXT.historyTitle,
					["color"] = v_u_6.text,
					["position"] = UDim2.fromOffset(136, 0),
					["size"] = UDim2.new(1, -136, 1, 0)
				})
				local v586 = v_u_4.list({
					["parent"] = nil,
					["name"] = "List",
					["position"] = nil,
					["size"] = nil,
					["gap"] = 6,
					["parent"] = v_u_62,
					["position"] = UDim2.fromOffset(0, v_u_5.touch(44) + 8),
					["size"] = UDim2.new(1, 0, 1, -(v_u_5.touch(44) + 8))
				})
				local v587 = v_u_41
				local v588
				if type(v587) == "table" then
					local v589 = v_u_41.recent
					v588 = type(v589) ~= "table" and {} or v_u_41.recent
				else
					v588 = {}
				end
				if #v588 == 0 then
					v_u_4.label({
						["parent"] = nil,
						["name"] = "Empty",
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = 1,
						["parent"] = v586,
						["text"] = v_u_13.TEXT.noHistory,
						["color"] = v_u_6.text2
					})
				end
				for v590, v591 in v588 do
					local v_u_592 = v591.w
					if type(v_u_592) == "number" and (v_u_55[v_u_592] == nil and not v_u_56[v_u_592]) then
						v_u_56[v_u_592] = true
						task.spawn(function()
							-- upvalues: (ref) v_u_1, (copy) v_u_592, (ref) v_u_55, (ref) v_u_37, (ref) v_u_38, (ref) v_u_34
							local function v593()
								-- upvalues: (ref) v_u_1, (ref) v_u_592
								return v_u_1:GetNameFromUserIdAsync(v_u_592)
							end
							local v594, v595 = pcall(v593)
							if v594 and type(v595) == "string" then
								v_u_55[v_u_592] = v595
								if v_u_37 and v_u_38 then
									v_u_34.render(true)
								end
							end
						end)
					end
					local v596 = v_u_13.historyRow(v591, v_u_55)
					local v597 = v_u_5.touch(56)
					local v598 = v_u_4.new("Frame", {
						["Name"] = "Receipt",
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.15,
						["BorderSizePixel"] = 0,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["BackgroundColor3"] = v_u_6.raised,
						["Size"] = UDim2.new(1, 0, 0, v597),
						["LayoutOrder"] = v590
					}, v586)
					v_u_4.stroke(v598, v_u_6.line)
					v_u_4.label({
						["parent"] = nil,
						["name"] = "Who",
						["text"] = nil,
						["style"] = "bodyStrong",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v598,
						["text"] = v596.who,
						["color"] = v_u_6.text,
						["position"] = UDim2.fromOffset(12, 5),
						["size"] = UDim2.new(0.5, -12, 0, 22)
					})
					v_u_4.label({
						["parent"] = nil,
						["name"] = "Date",
						["text"] = nil,
						["style"] = "micro",
						["color"] = nil,
						["align"] = "right",
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v598,
						["text"] = v596.date,
						["color"] = v_u_6.text2,
						["position"] = UDim2.fromScale(0.5, 0),
						["size"] = UDim2.new(0.5, -12, 0, 26)
					})
					v_u_4.label({
						["parent"] = nil,
						["name"] = "What",
						["text"] = nil,
						["style"] = "small",
						["color"] = nil,
						["position"] = nil,
						["size"] = nil,
						["fit"] = true,
						["track"] = false,
						["parent"] = v598,
						["text"] = v_u_13.text("histGave", v596.gave) .. "    " .. v_u_13.text("histGot", v596.got) .. (not v596.fee and "" or "    " .. v_u_13.text("histFee", v596.fee)),
						["color"] = v_u_6.text2,
						["position"] = UDim2.fromOffset(12, 30),
						["size"] = UDim2.new(1, -24, 0, 22)
					})
				end
			end,
			["off"] = v_u_264
		}
		local function v_u_628() -- name: sigNow
			-- upvalues: (ref) v_u_41, (copy) v_u_13, (copy) v_u_42, (ref) v_u_44, (ref) v_u_50, (ref) v_u_32, (ref) v_u_47
			local v600 = v_u_41
			local v601
			if type(v600) == "table" then
				v601 = v_u_41.s
			else
				v601 = nil
			end
			local v602 = {}
			local v603 = v_u_13.pageOf(v_u_41, v_u_42)
			local v604 = v_u_44
			local v605 = tostring(v604)
			local v606 = v_u_50
			local v607 = tostring(v606)
			local v608 = #v_u_32.reqs()
			local v609 = tostring(v608)
			local v610 = v_u_47 and #v_u_47.rows or -1
			local v611 = tostring(v610)
			local v612 = v_u_42.result ~= nil
			__set_list(v602, 1, {v603, v605, v607, v609, v611, (tostring(v612))})
			if v601 ~= nil then
				local v613 = v_u_13.sigOf
				table.insert(v602, v613(v601))
				local v614 = v601.ver
				local v615 = tostring(v614)
				local v616 = v601.me
				if v616 then
					v616 = v601.me.ready
				end
				local v617 = tostring(v616)
				local v618 = v601.you
				if v618 then
					v618 = v601.you.ready
				end
				local v619 = tostring(v618)
				local v620 = v601.me
				if v620 then
					v620 = v601.me.confirm
				end
				local v621 = tostring(v620)
				local v622 = v601.you
				if v622 then
					v622 = v601.you.confirm
				end
				local v623 = tostring(v622)
				local v624 = v601.canReady
				local v625 = tostring(v624)
				local v626 = v601.phase
				local v627 = v615 .. v617 .. v619 .. v621 .. v623 .. v625 .. tostring(v626)
				table.insert(v602, v627)
			end
			return table.concat(v602, "|")
		end
		function v_u_34.render(p629) -- name: render
			-- upvalues: (ref) v_u_37, (copy) v_u_628, (ref) v_u_60, (copy) v_u_13, (ref) v_u_41, (copy) v_u_42, (ref) v_u_52, (copy) v_u_96, (copy) v_u_599, (copy) v_u_264, (copy) v_u_35, (copy) p_u_3, (copy) v_u_4, (copy) v_u_62, (copy) v_u_118, (copy) v_u_10, (ref) v_u_38, (ref) v_u_59, (copy) p_u_2, (copy) v_u_34
			if v_u_37 then
				local v630 = v_u_628()
				if p629 == true or v630 ~= v_u_60 then
					v_u_60 = v630
					local v631 = v_u_13.pageOf(v_u_41, v_u_42)
					local v632 = v631 == v_u_52
					v_u_52 = v631
					local function v643() -- name: build
						-- upvalues: (ref) v_u_96, (ref) v_u_599, (ref) v_u_52, (ref) v_u_264, (ref) v_u_35, (ref) p_u_3, (ref) v_u_41
						v_u_96()
						local v633 = v_u_599[v_u_52] or v_u_264
						local v634, v_u_635 = pcall(v633)
						if not v634 then
							warn("[MenuMarketTrade] page failed:", v_u_52, v_u_635)
							local function v637()
								-- upvalues: (ref) v_u_35, (ref) v_u_52, (copy) v_u_635
								local v636 = v_u_635
								v_u_35:SetAttribute("ClientError", "trade " .. v_u_52 .. ": " .. tostring(v636))
							end
							pcall(v637)
						end
						p_u_3:SetAttribute("TradePage", v_u_52)
						local v638 = p_u_3
						local v639 = "TradePhase"
						local v640 = v_u_41
						local v641
						if type(v640) == "table" then
							local v642 = v_u_41.phase
							v641 = tostring(v642)
						else
							v641 = "?"
						end
						v638:SetAttribute(v639, v641)
					end
					if v632 then
						local v644 = v_u_4.keepScroll
						local v645 = v_u_62
						if not pcall(v644, v645, v643) then
							v643()
						end
					else
						v643()
					end
					if v_u_52 == "players" then
						v_u_118(false)
					end
					local v646 = v_u_10 and v_u_38
					if v646 then
						v646 = (v_u_52 == "edit" or (v_u_52 == "review" or v_u_52 == "finishing")) and true or v_u_52 == "result"
					end
					if v_u_59 ~= v646 then
						v_u_59 = v646
						local v647 = p_u_2.setSubRowVisible
						pcall(v647, not v646)
					end
					v_u_34.tick()
				end
			else
				return
			end
		end
		function v_u_34.tick() -- name: tick
			-- upvalues: (ref) v_u_37, (ref) v_u_41, (ref) v_u_52, (copy) v_u_53, (copy) v_u_13, (copy) v_u_40, (ref) v_u_46, (copy) v_u_6
			if v_u_37 then
				local v648 = v_u_41
				local v649
				if type(v648) == "table" then
					v649 = v_u_41.s
				else
					v649 = nil
				end
				if v_u_52 == "ask" and (v_u_53.askLeft ~= nil and v_u_53.askEnds ~= nil) then
					local v650 = v_u_53.askLeft
					local v651 = v_u_13.text
					local v652 = v_u_53.askEnds - v_u_40()
					local v653 = math.ceil(v652)
					v650.Text = v651("waitingSub", (math.max(0, v653)))
				end
				if v_u_52 == "review" and (v649 ~= nil and v_u_53.confirmApi ~= nil) then
					local v654 = v_u_53.scroll
					local v655 = v654 == nil and true or v_u_13.atEnd(v654.AbsoluteCanvasSize.Y, v654.AbsoluteWindowSize.Y, v654.CanvasPosition.Y)
					local v656 = v_u_13.confirmState
					local v657 = v_u_46 - v_u_40()
					local v658 = v656(v649, math.max(0, v657), v655)
					v_u_53.confirmApi.setText(v658.text)
					v_u_53.confirmApi.setEnabled(v658.enabled)
					local v659 = v658.enabled and "primary" or "secondary"
					if v_u_53.confKind ~= v659 then
						v_u_53.confKind = v659
						local v660 = v_u_53.confirmApi.setKind
						pcall(v660, v659)
					end
					v_u_53.confirm:SetAttribute("State", v658.enabled and "ready" or (v658.done and "done" or (v658.wait and "lock" or "end")))
					if v_u_53.confHint then
						v_u_53.confHint.Text = v658.why or (not v658.done and "" or v_u_13.statusLine(v649))
					end
					if v_u_53.confStroke then
						local v661 = v_u_53.confStroke
						local v662
						if v658.enabled then
							v662 = v_u_6.success
						else
							v662 = v_u_6.lineStrong
						end
						v661.Color = v662
					end
				end
				if v_u_52 == "finishing" and v_u_53.bar ~= nil then
					v_u_53.bar.set(v_u_40() * 0.25 % 1)
				end
			end
		end
		local function v674(p663) -- name: onEvent
			-- upvalues: (ref) v_u_37, (ref) v_u_41, (copy) v_u_42, (ref) v_u_32, (ref) v_u_45, (copy) v_u_40, (ref) v_u_46, (copy) v_u_13, (ref) v_u_51, (ref) v_u_43, (ref) v_u_47, (ref) v_u_38, (copy) v_u_34
			if v_u_37 then
				local v664 = p663.k
				if v664 ~= "done" then
					local v665 = v_u_41
					if type(v665) == "table" and v_u_42.result ~= nil then
						local v666 = v_u_32.state()
						if type(v666) == "table" and (v666.phase == "ask" or v666.phase == "edit") then
							v_u_42.result = nil
						end
					end
				end
				if v664 == "upd" or v664 == "state" then
					v_u_41 = v_u_32.state()
					local v667 = v_u_41
					local v668
					if type(v667) == "table" then
						v668 = v_u_41.s
					else
						v668 = nil
					end
					if v668 ~= nil and v668.lockLeft ~= nil then
						v_u_45 = v_u_40()
						local v669 = v_u_40()
						local v670 = v668.lockLeft
						v_u_46 = v669 + (tonumber(v670) or 0)
					end
				elseif v664 == "done" then
					v_u_41 = v_u_32.state()
					v_u_42.result = v_u_13.receiptRows(p663.beleg, v_u_51.give, v_u_51.get)
					local v671 = p663.beleg
					if type(v671) == "table" then
						local v672 = p663.beleg.got
						if type(v672) == "table" and v_u_51.getCash == nil then
							v_u_51.getCash = v672.cash
						end
					end
					v_u_51.get = v_u_51.get
					v_u_42.result.gaveRows = v_u_51.give
					v_u_42.result.gotRows = v_u_51.get
				elseif v664 == "end" then
					v_u_41 = v_u_32.state()
					v_u_43 = nil
					v_u_42.result = v_u_42.result
				elseif v664 == "backend" then
					v_u_41 = v_u_32.state()
					local v673 = v_u_42
					v_u_42.result = nil
					v673.history = false
					v_u_47 = nil
				else
					v_u_41 = v_u_32.state()
				end
				if v_u_38 then
					v_u_34.render(false)
				end
			end
		end
		local v675 = {
			["Disconnect"] = v_u_32.subscribe(v674)
		}
		table.insert(v_u_39, v675)
		local v678 = {
			["Disconnect"] = p_u_2.onTick(function()
				-- upvalues: (ref) v_u_38, (ref) v_u_37, (ref) v_u_41, (ref) v_u_32, (ref) v_u_52, (copy) v_u_118
				if v_u_38 and v_u_37 then
					local v676 = v_u_41
					local v677 = type(v676) ~= "table" and "none" or v_u_41.phase
					if v_u_32.stateAge() > (v677 == "none" and 8 or 4) then
						v_u_32.refresh(false)
					end
					if v_u_52 == "players" then
						v_u_118(false)
					end
				end
			end)
		}
		table.insert(v_u_39, v678)
		task.spawn(function()
			-- upvalues: (ref) v_u_37, (ref) v_u_38, (copy) v_u_34
			while v_u_37 do
				task.wait(0.25)
				if not (v_u_38 and v_u_37) then
					continue
				end
				local v679 = v_u_34.tick
				pcall(v679)
			end
		end)
		pcall(function()
			-- upvalues: (copy) v_u_39, (copy) p_u_3, (ref) v_u_37, (ref) v_u_38, (copy) v_u_34
			local v680 = v_u_39
			local v681 = p_u_3:GetPropertyChangedSignal("AbsoluteSize")
			local function v682()
				-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_34
				if v_u_37 and v_u_38 then
					task.defer(function()
						-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_34
						if v_u_37 and v_u_38 then
							v_u_34.render(true)
						end
					end)
				end
			end
			table.insert(v680, v681:Connect(v682))
		end)
		function v_u_34.show() -- name: show
			-- upvalues: (ref) v_u_38, (ref) v_u_41, (ref) v_u_32, (ref) v_u_49, (ref) v_u_37, (ref) v_u_48, (copy) v_u_40, (ref) v_u_47, (ref) v_u_52, (copy) v_u_34
			v_u_38 = true
			v_u_41 = v_u_32.state()
			v_u_32.refresh(true)
			if not v_u_49 and v_u_37 then
				v_u_49 = true
				v_u_48 = v_u_40()
				task.spawn(function()
					-- upvalues: (ref) v_u_32, (ref) v_u_49, (ref) v_u_37, (ref) v_u_47, (ref) v_u_38, (ref) v_u_52, (ref) v_u_34
					local v683 = v_u_32.get("tradePlayers")
					v_u_49 = false
					if v_u_37 then
						if type(v683) == "table" then
							local v684 = v683.rows
							if type(v684) == "table" then
								v_u_47 = v683
								if v_u_38 and v_u_52 == "players" then
									v_u_34.render(true)
								end
							end
						end
					end
				end)
			end
			v_u_34.render(true)
		end
		function v_u_34.hide() -- name: hide
			-- upvalues: (ref) v_u_38, (ref) v_u_59, (copy) p_u_2
			v_u_38 = false
			if v_u_59 ~= false then
				v_u_59 = false
				local v685 = p_u_2.setSubRowVisible
				pcall(v685, true)
			end
		end
		function v_u_34.refresh(_) -- name: refresh
			-- upvalues: (ref) v_u_38, (copy) v_u_34
			if v_u_38 then
				v_u_34.render(false)
			end
		end
		function v_u_34.reload() -- name: reload
			-- upvalues: (ref) v_u_47, (ref) v_u_48, (ref) v_u_32, (ref) v_u_49, (ref) v_u_37, (copy) v_u_40, (ref) v_u_38, (ref) v_u_52, (copy) v_u_34
			v_u_47 = nil
			v_u_48 = -1000000000
			v_u_32.refresh(true)
			if not v_u_49 and v_u_37 then
				v_u_49 = true
				v_u_48 = v_u_40()
				task.spawn(function()
					-- upvalues: (ref) v_u_32, (ref) v_u_49, (ref) v_u_37, (ref) v_u_47, (ref) v_u_38, (ref) v_u_52, (ref) v_u_34
					local v686 = v_u_32.get("tradePlayers")
					v_u_49 = false
					if v_u_37 then
						if type(v686) == "table" then
							local v687 = v686.rows
							if type(v687) == "table" then
								v_u_47 = v686
								if v_u_38 and v_u_52 == "players" then
									v_u_34.render(true)
								end
							end
						end
					end
				end)
			end
			v_u_34.render(true)
		end
		function v_u_34.onNote(_) -- name: onNote end
		function v_u_34.destroy() -- name: destroy
			-- upvalues: (ref) v_u_37, (ref) v_u_38, (ref) v_u_59, (copy) p_u_2, (copy) v_u_96, (copy) v_u_39
			v_u_37 = false
			v_u_38 = false
			if v_u_59 ~= false then
				v_u_59 = false
				local v688 = p_u_2.setSubRowVisible
				pcall(v688, true)
			end
			v_u_96()
			for _, v_u_689 in v_u_39 do
				pcall(function()
					-- upvalues: (copy) v_u_689
					v_u_689:Disconnect()
				end)
			end
			table.clear(v_u_39)
		end
		function v_u_34.state() -- name: state
			-- upvalues: (ref) v_u_41, (ref) v_u_52, (ref) v_u_44, (ref) v_u_46, (copy) v_u_40, (copy) v_u_53, (ref) v_u_32, (ref) v_u_47, (copy) v_u_42
			local v690 = v_u_41
			local v691
			if type(v690) == "table" then
				v691 = v_u_41.s
			else
				v691 = nil
			end
			local v692 = {
				["page"] = v_u_52
			}
			local v693 = v_u_41
			local v694
			if type(v693) == "table" then
				v694 = v_u_41.phase
			else
				v694 = nil
			end
			v692.phase = v694
			local v695 = v_u_41
			local v696
			if type(v695) == "table" then
				v696 = v_u_41.tab
			else
				v696 = nil
			end
			v692.tab = v696
			v692.seg = v_u_44
			v692.hasView = v691 ~= nil
			v692.lines = v691 and (v691.me and v691.you) and {
				["me"] = #v691.me.lines,
				["you"] = #v691.you.lines
			} or nil
			local v697
			if v691 then
				v697 = v691.ver
			else
				v697 = nil
			end
			v692.ver = v697
			local v698 = v_u_46 - v_u_40()
			local v699 = math.ceil(v698)
			v692.lockLeft = math.max(0, v699)
			local v700
			if v_u_53.confirm then
				v700 = v_u_53.confirm:GetAttribute("State")
			else
				v700 = nil
			end
			v692.confirm = v700
			v692.reqs = #v_u_32.reqs()
			v692.players = v_u_47 and #v_u_47.rows or nil
			v692.result = v_u_42.result ~= nil
			return v692
		end
		function v_u_34.act(p701, p702, p703) -- name: act
			-- upvalues: (ref) v_u_41, (copy) v_u_57, (ref) v_u_32, (ref) v_u_37, (ref) v_u_43, (copy) v_u_13, (copy) v_u_42, (copy) v_u_34, (copy) v_u_53, (ref) v_u_58, (ref) v_u_44
			local v704 = v_u_41
			local v705
			if type(v704) == "table" then
				v705 = v_u_41.s
			else
				v705 = nil
			end
			if p701 == "ask" then
				local v_u_706 = {
					["to"] = tonumber(p702)
				}
				if not v_u_57.tradeAsk then
					v_u_57.tradeAsk = true
					local v_u_707 = "tradeAsk"
					local v_u_708 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_707, (copy) v_u_706, (ref) v_u_57, (copy) v_u_708, (ref) v_u_37
						local v709 = v_u_32.op(v_u_707, v_u_706 or {})
						v_u_57[v_u_707] = nil
						if v_u_708 then
							local v710 = v_u_708
							pcall(v710, v709)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "cancel" then
				if not v_u_57.tradeCancel then
					v_u_57.tradeCancel = true
					local v_u_711 = "tradeCancel"
					local v_u_712 = nil
					local v_u_713 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_711, (copy) v_u_712, (ref) v_u_57, (copy) v_u_713, (ref) v_u_37
						local v714 = v_u_32.op(v_u_711, v_u_712 or {})
						v_u_57[v_u_711] = nil
						if v_u_713 then
							local v715 = v_u_713
							pcall(v715, v714)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "ready" and v705 then
				v_u_43 = v_u_13.approve(v_u_43, v705)
				local v_u_716 = {
					["ver"] = nil,
					["on"] = true,
					["ver"] = v705.ver
				}
				if not v_u_57.tradeReady then
					v_u_57.tradeReady = true
					local v_u_717 = "tradeReady"
					local v_u_718 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_717, (copy) v_u_716, (ref) v_u_57, (copy) v_u_718, (ref) v_u_37
						local v719 = v_u_32.op(v_u_717, v_u_716 or {})
						v_u_57[v_u_717] = nil
						if v_u_718 then
							local v720 = v_u_718
							pcall(v720, v719)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "unready" and v705 then
				local v_u_721 = {
					["ver"] = nil,
					["on"] = false,
					["ver"] = v705.ver
				}
				if not v_u_57.tradeReady then
					v_u_57.tradeReady = true
					local v_u_722 = "tradeReady"
					local v_u_723 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_722, (copy) v_u_721, (ref) v_u_57, (copy) v_u_723, (ref) v_u_37
						local v724 = v_u_32.op(v_u_722, v_u_721 or {})
						v_u_57[v_u_722] = nil
						if v_u_723 then
							local v725 = v_u_723
							pcall(v725, v724)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "confirm" and v705 then
				local v_u_726 = {
					["ver"] = v705.ver
				}
				if not v_u_57.tradeConfirm then
					v_u_57.tradeConfirm = true
					local v_u_727 = "tradeConfirm"
					local v_u_728 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_727, (copy) v_u_726, (ref) v_u_57, (copy) v_u_728, (ref) v_u_37
						local v729 = v_u_32.op(v_u_727, v_u_726 or {})
						v_u_57[v_u_727] = nil
						if v_u_728 then
							local v730 = v_u_728
							pcall(v730, v729)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "remove" then
				local v_u_731 = {
					["line"] = tonumber(p702)
				}
				if not v_u_57.tradeRemove then
					v_u_57.tradeRemove = true
					local v_u_732 = "tradeRemove"
					local v_u_733 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_732, (copy) v_u_731, (ref) v_u_57, (copy) v_u_733, (ref) v_u_37
						local v734 = v_u_32.op(v_u_732, v_u_731 or {})
						v_u_57[v_u_732] = nil
						if v_u_733 then
							local v735 = v_u_733
							pcall(v735, v734)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "add" then
				local v_u_736 = {
					["kind"] = tostring(p702),
					["uid"] = tostring(p703)
				}
				if not v_u_57.tradeAdd then
					v_u_57.tradeAdd = true
					local v_u_737 = "tradeAdd"
					local v_u_738 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_737, (copy) v_u_736, (ref) v_u_57, (copy) v_u_738, (ref) v_u_37
						local v739 = v_u_32.op(v_u_737, v_u_736 or {})
						v_u_57[v_u_737] = nil
						if v_u_738 then
							local v740 = v_u_738
							pcall(v740, v739)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "cash" then
				local v_u_741 = {
					["n"] = tonumber(p702) or 0
				}
				if not v_u_57.tradeCash then
					v_u_57.tradeCash = true
					local v_u_742 = "tradeCash"
					local v_u_743 = nil
					task.spawn(function()
						-- upvalues: (ref) v_u_32, (copy) v_u_742, (copy) v_u_741, (ref) v_u_57, (copy) v_u_743, (ref) v_u_37
						local v744 = v_u_32.op(v_u_742, v_u_741 or {})
						v_u_57[v_u_742] = nil
						if v_u_743 then
							local v745 = v_u_743
							pcall(v745, v744)
						end
						if v_u_37 then
							v_u_32.refresh(true)
						end
					end)
				end
			elseif p701 == "done" then
				v_u_42.result = nil
				v_u_34.render(true)
			elseif p701 == "history" then
				v_u_42.history = p702 ~= "off"
				v_u_34.render(true)
			elseif p701 == "back" then
				v_u_42.history = false
				v_u_34.render(true)
			elseif p701 == "answer" then
				task.spawn(v_u_32.answer, tonumber(p702) or 0, p703 ~= "no", p703 == "block")
			elseif p701 == "pick" then
				local v746 = v_u_53.openers
				if v746 then
					v746 = v_u_53.openers[tostring(p702)]
				end
				if v746 == nil then
					return "no such window (open the offer first)"
				end
				v_u_58 = v746()
			elseif p701 == "closepick" then
				if v_u_58 and (v_u_58.modal and v_u_58.modal.close) then
					v_u_58.modal.close()
				end
			elseif p701 == "copies" then
				if v_u_58 and v_u_58.showCopies then
					v_u_58.showCopies(tostring(p702), 0)
				end
			else
				if p701 ~= "seg" then
					return "unknown"
				end
				v_u_44 = p702 == "they" and "they" or "you"
				v_u_34.render(true)
			end
			return "ok " .. p701
		end
		function v_u_34.rows() -- name: rows
			-- upvalues: (copy) v_u_62
			local v747 = {}
			for _, v748 in v_u_62:GetDescendants() do
				if v748.Name ~= "Row" and v748.Name ~= "CashRow" then
					continue
				end
				local v749 = v748.Name
				local v750 = v748:GetAttribute("Key") or ""
				local v751 = tostring(v750)
				local v752 = v748:GetAttribute("Mark") or ""
				local v753 = tostring(v752)
				table.insert(v747, ("%s %s %s"):format(v749, v751, v753))
			end
			return v747
		end
		function v_u_34.host() -- name: host
			-- upvalues: (copy) v_u_62
			return v_u_62
		end
		function v_u_34.refs() -- name: refs
			-- upvalues: (copy) v_u_53
			return v_u_53
		end
		v_u_34.frame = p_u_3
		task.defer(function()
			-- upvalues: (ref) v_u_37, (copy) v_u_34
			if v_u_37 then
				v_u_34.render(true)
			end
		end)
		return v_u_34
	end
}