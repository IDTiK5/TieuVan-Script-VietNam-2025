-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuKillCard

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = {}
local v_u_4 = {
	"anim",
	"bg",
	"frame",
	"title"
}
local v_u_5 = utf8.char(57346)
function v3.new(p_u_6, p7) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_2, (copy) v_u_4
	local v_u_8 = p_u_6.ui
	local v_u_9 = p_u_6.theme
	local v_u_10 = v_u_9.color
	local v_u_11 = p_u_6.cctx
	local v_u_12 = v_u_11.shared
	local v_u_13 = v_u_12.PvpCardModel.TEXT
	local v_u_14 = v_u_12.KillCardLocker
	local v_u_15 = v_u_14.TEXT
	local v_u_16 = v_u_12.KillCardLook
	local v_u_17 = v_u_12.KillCardPoses
	local v_u_18 = v_u_12.KillCardAnim
	local v_u_19 = v_u_12.KillCardCosmetics
	local v_u_20 = v_u_12.KillCardArt
	local v_u_21 = v_u_12.TitleRarity
	local v_u_22 = v_u_1.LocalPlayer
	local v_u_23 = not v_u_22 and 0 or v_u_22.UserId
	local v_u_24 = {}
	local v_u_25 = v_u_8.new("Frame", {
		["Name"] = "KillCardLocker",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, p7)
	local v26, v27 = pcall(function()
		-- upvalues: (copy) v_u_12
		return v_u_12.GameMode.rule("killCardCosmetics")
	end)
	if not v26 or v27 ~= true then
		v_u_8.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v_u_25,
			["text"] = v_u_13.pvpOnly,
			["color"] = v_u_10.text2,
			["position"] = UDim2.fromOffset(0, 8),
			["size"] = UDim2.new(1, 0, 0, 40)
		})
		function v_u_24.show() -- name: show end
		function v_u_24.hide() -- name: hide end
		function v_u_24.refresh() -- name: refresh end
		function v_u_24.tick() -- name: tick end
		function v_u_24.draw() -- name: draw end
		function v_u_24.destroy() -- name: destroy
			-- upvalues: (copy) v_u_25
			v_u_25:Destroy()
		end
		return v_u_24
	end
	local v_u_28 = "anim"
	local v_u_29 = v_u_14.selection(nil)
	local v_u_30 = nil
	local v_u_31 = nil
	local v_u_32 = false
	local v_u_33 = nil
	local v_u_34 = nil
	local v_u_35 = os.clock()
	local v_u_36 = v_u_14.layout(796, 240, 44)
	local v_u_37 = v_u_8.new("Frame", {
		["Name"] = "Plate",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["BackgroundColor3"] = v_u_10.raised
	}, v_u_25)
	local v_u_38 = v_u_8.stroke(v_u_37, v_u_10.line)
	local v_u_39 = v_u_8.new("ImageLabel", {
		["Name"] = "Thumb",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Image"] = nil,
		["ImageTransparency"] = 0,
		["ScaleType"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Image"] = ("rbxthumb://type=Avatar&id=%d&w=420&h=420"):format(v_u_23),
		["ScaleType"] = Enum.ScaleType.Crop,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_37)
	local v_u_40 = v_u_8.label({
		["parent"] = nil,
		["name"] = "PreviewTag",
		["text"] = nil,
		["style"] = "micro",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 9,
		["parent"] = v_u_37,
		["text"] = v_u_13.preview,
		["color"] = v_u_10.accent,
		["position"] = UDim2.fromOffset(8, 6),
		["size"] = UDim2.fromOffset(90, 16)
	})
	v_u_40.Visible = false
	local v_u_41 = v_u_8.button({
		["parent"] = nil,
		["name"] = "Replay",
		["text"] = nil,
		["kind"] = "ghost",
		["size"] = nil,
		["position"] = nil,
		["anchor"] = nil,
		["zindex"] = 10,
		["onClick"] = nil,
		["parent"] = v_u_37,
		["text"] = v_u_13.replay,
		["size"] = UDim2.fromOffset(96, v_u_9.touch(44)),
		["position"] = UDim2.new(1, -4, 1, -4),
		["anchor"] = Vector2.new(1, 1),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_34, (ref) v_u_29
			if v_u_34 then
				v_u_34.play(v_u_29.anim, os.clock())
			end
		end
	})
	local v_u_42 = v_u_8.new("Frame", {
		["Name"] = "InfoBack",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.08,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = v_u_10.bg
	}, v_u_25)
	v_u_8.stroke(v_u_42, v_u_10.line)
	local v_u_43 = v_u_8.new("Frame", {
		["Name"] = "Info",
		["BackgroundTransparency"] = 1
	}, v_u_25)
	local v_u_44 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Name",
		["text"] = "",
		["style"] = "h3",
		["fit"] = true,
		["track"] = false,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_43,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(1, 0, 0, 26)
	})
	local v_u_45 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Rarity",
		["text"] = "",
		["style"] = "small",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_43,
		["position"] = UDim2.fromOffset(0, 28),
		["size"] = UDim2.new(1, 0, 0, 16)
	})
	local v_u_46 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Source",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_43,
		["color"] = v_u_10.text2,
		["position"] = UDim2.fromOffset(0, 48),
		["size"] = UDim2.new(1, 0, 0, 32)
	})
	local v_u_47 = v_u_29
	local v_u_48 = v_u_34
	local v_u_49 = nil
	local v_u_50 = 0
	local v_u_51 = nil
	local v_u_52 = -1
	local v_u_53 = 0
	local v_u_54 = 0
	local v_u_55 = {}
	local v_u_56 = {}
	for _, v57 in { v_u_44, v_u_45, v_u_46 } do
		v_u_8.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 8),
			["PaddingRight"] = UDim.new(0, 8)
		}, v57)
	end
	local v_u_58, v_u_59 = v_u_8.button({
		["parent"] = nil,
		["name"] = "Equip",
		["text"] = nil,
		["kind"] = "primary",
		["size"] = nil,
		["position"] = nil,
		["parent"] = v_u_43,
		["text"] = v_u_13.equip,
		["size"] = UDim2.new(1, 0, 0, v_u_9.touch(44)),
		["position"] = UDim2.fromOffset(0, 88)
	})
	local v_u_69, v_u_70 = v_u_8.button({
		["parent"] = nil,
		["name"] = "Buy",
		["text"] = nil,
		["kind"] = "primary",
		["size"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_43,
		["text"] = v_u_15.buy,
		["size"] = UDim2.new(1, 0, 0, v_u_9.touch(44)),
		["position"] = UDim2.fromOffset(0, 88),
		["onClick"] = function() -- name: onClick
			-- upvalues: (ref) v_u_30, (ref) v_u_31, (copy) p_u_6
			local v60 = v_u_30
			local v61 = v_u_31
			if v60 ~= nil and (v61 ~= nil and v60.shop == true) then
				local v62 = v60.tier
				if type(v62) == "number" and (v60.tier >= 1 and v60.tier <= 4) then
					local v63 = v60.tier
					local v64 = v60.tier
					if v63 == math.floor(v64) then
						local v65 = v60.id
						if type(v65) == "string" and v61.payload.cosmetic == v60.id then
							local v66 = p_u_6.op
							local v67 = {
								["op"] = "storeBuy",
								["id"] = nil,
								["cosmetic"] = nil
							}
							local v68 = v60.tier
							v67.id = "kc_tier_" .. tostring(v68)
							v67.cosmetic = v60.id
							v66(v67)
						end
					end
				end
			end
		end
	})
	v_u_69.Visible = false
	local v_u_71 = v_u_8.label({
		["parent"] = nil,
		["name"] = "Note",
		["text"] = "",
		["style"] = "micro",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "top",
		["position"] = nil,
		["size"] = nil,
		["track"] = false,
		["parent"] = v_u_43,
		["color"] = v_u_10.muted,
		["position"] = UDim2.fromOffset(0, 138),
		["size"] = UDim2.new(1, 0, 0, 30)
	})
	v_u_71.Visible = false
	v_u_8.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 8),
		["PaddingRight"] = UDim.new(0, 8)
	}, v_u_71)
	pcall(function()
		-- upvalues: (copy) v_u_70
		v_u_70.label.RichText = true
	end)
	local v_u_72 = v_u_9.touch(36)
	local v_u_74, v_u_75 = v_u_8.tabs({
		["parent"] = v_u_25,
		["tabs"] = {
			{
				["id"] = "anim",
				["text"] = nil,
				["text"] = v_u_13.tabAnim
			},
			{
				["id"] = "bg",
				["text"] = nil,
				["text"] = v_u_13.tabBg
			},
			{
				["id"] = "frame",
				["text"] = nil,
				["text"] = v_u_13.tabFrame
			},
			{
				["id"] = "title",
				["text"] = nil,
				["text"] = v_u_13.tabTitle
			}
		},
		["selected"] = v_u_28,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(1, 0, 0, v_u_72),
		["onChange"] = function(p73) -- name: onChange
			-- upvalues: (ref) v_u_28, (ref) v_u_30, (copy) v_u_24
			v_u_28 = p73
			v_u_30 = nil
			v_u_24.draw()
		end
	})
	local v_u_76 = v_u_8.new("ScrollingFrame", {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollingDirection"] = nil,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, v_u_25)
	local v_u_77 = v_u_8.new("UIGridLayout", {
		["CellSize"] = UDim2.fromOffset(150, v_u_9.touch(58)),
		["CellPadding"] = UDim2.fromOffset(6, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["FillDirection"] = Enum.FillDirection.Horizontal
	}, v_u_76)
	v_u_8.new("UIPadding", {
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingBottom"] = UDim.new(0, 8),
		["PaddingRight"] = UDim.new(0, 6)
	}, v_u_76)
	local v_u_78 = v_u_8.new("Frame", {
		["Name"] = "Empty",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_10.raised
	}, v_u_25)
	v_u_8.stroke(v_u_78, v_u_10.line)
	local v_u_79 = v_u_8.label({
		["parent"] = nil,
		["name"] = "EmptyText",
		["text"] = nil,
		["style"] = "small",
		["color"] = nil,
		["wrap"] = true,
		["valign"] = "center",
		["align"] = "center",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v_u_78,
		["text"] = v_u_13.empty,
		["color"] = v_u_10.text2,
		["position"] = UDim2.fromOffset(12, 8),
		["size"] = UDim2.new(1, -24, 1, -16)
	})
	local function v_u_84() -- name: panelSize
		-- upvalues: (copy) v_u_25, (copy) v_u_9, (ref) v_u_36
		local v80 = v_u_25.AbsoluteSize
		local v_u_81 = 1
		local function v83()
			-- upvalues: (ref) v_u_81, (ref) v_u_9
			local v82 = v_u_9.uiScale
			v_u_81 = math.max(0.1, v82())
		end
		pcall(v83)
		if v80.X > 0 and v80.Y > 0 then
			return v80.X / v_u_81, v80.Y / v_u_81
		else
			return v_u_36.right.x1, v_u_36.left.y1
		end
	end
	function v_u_24.relayout(p85, p86) -- name: relayout
		-- upvalues: (copy) v_u_84, (ref) v_u_36, (copy) v_u_14, (copy) v_u_9, (copy) v_u_72, (copy) v_u_37, (copy) v_u_43, (copy) v_u_42, (copy) v_u_44, (copy) v_u_45, (copy) v_u_46, (copy) v_u_58, (copy) v_u_69, (copy) v_u_71, (ref) v_u_31, (copy) v_u_40, (copy) v_u_41, (ref) v_u_53, (ref) v_u_54, (ref) v_u_49, (copy) v_u_74, (copy) v_u_76, (copy) v_u_77, (copy) v_u_78, (ref) v_u_50, (ref) v_u_32, (copy) v_u_24
		if p85 == nil or p86 == nil then
			p85, p86 = v_u_84()
		end
		v_u_36 = v_u_14.layout(p85, p86, v_u_9.touch(44), v_u_72, v_u_9.touch(58))
		local v87 = v_u_37
		local v88 = v_u_36.plate
		v87.Position = UDim2.fromOffset(v88.x0, v88.y0)
		v87.Size = UDim2.fromOffset(v88.x1 - v88.x0, v88.y1 - v88.y0)
		local v89 = v_u_43
		local v90 = v_u_36.info
		v89.Position = UDim2.fromOffset(v90.x0, v90.y0)
		v89.Size = UDim2.fromOffset(v90.x1 - v90.x0, v90.y1 - v90.y0)
		local v91 = v_u_42
		local v92 = v_u_36.info
		v91.Position = UDim2.fromOffset(v92.x0, v92.y0)
		v91.Size = UDim2.fromOffset(v92.x1 - v92.x0, v92.y1 - v92.y0)
		local v93 = v_u_36.info.x0
		local v94 = v_u_36.info.y0
		local v95 = v_u_44
		local v96 = v_u_36.name
		v95.Position = UDim2.fromOffset(v96.x0 - v93, v96.y0 - v94)
		v95.Size = UDim2.fromOffset(v96.x1 - v96.x0, v96.y1 - v96.y0)
		local v97 = v_u_45
		local v98 = v_u_36.rarity
		v97.Position = UDim2.fromOffset(v98.x0 - v93, v98.y0 - v94)
		v97.Size = UDim2.fromOffset(v98.x1 - v98.x0, v98.y1 - v98.y0)
		local v99 = v_u_46
		local v100 = v_u_36.source
		v99.Position = UDim2.fromOffset(v100.x0 - v93, v100.y0 - v94)
		v99.Size = UDim2.fromOffset(v100.x1 - v100.x0, v100.y1 - v100.y0)
		local v101 = v_u_58
		local v102 = v_u_36.action
		v101.Position = UDim2.fromOffset(v102.x0 - v93, v102.y0 - v94)
		v101.Size = UDim2.fromOffset(v102.x1 - v102.x0, v102.y1 - v102.y0)
		local v103 = v_u_69
		local v104 = v_u_36.action
		v103.Position = UDim2.fromOffset(v104.x0 - v93, v104.y0 - v94)
		v103.Size = UDim2.fromOffset(v104.x1 - v104.x0, v104.y1 - v104.y0)
		local v105 = v_u_71
		local v106 = v_u_36.note
		v105.Position = UDim2.fromOffset(v106.x0 - v93, v106.y0 - v94)
		v105.Size = UDim2.fromOffset(v106.x1 - v106.x0, v106.y1 - v106.y0)
		local v107 = v_u_71
		local v108
		if v_u_31 == nil or v_u_31.note == nil then
			v108 = false
		else
			v108 = v_u_36.note.y1 - v_u_36.note.y0 >= 12
		end
		v107.Visible = v108
		local v109 = v_u_36.plate
		v_u_40.Position = UDim2.fromOffset(v_u_36.tag.x0 - v109.x0, v_u_36.tag.y0 - v109.y0)
		v_u_40.Size = UDim2.fromOffset(v_u_36.tag.x1 - v_u_36.tag.x0, v_u_36.tag.y1 - v_u_36.tag.y0)
		v_u_41.AnchorPoint = Vector2.new(0, 0)
		v_u_41.Position = UDim2.fromOffset(v_u_36.replay.x0 - v109.x0, v_u_36.replay.y0 - v109.y0)
		v_u_41.Size = UDim2.fromOffset(v_u_36.replay.x1 - v_u_36.replay.x0, v_u_36.replay.y1 - v_u_36.replay.y0)
		local v110 = v109.x1 - v109.x0
		local v111 = v109.y1 - v109.y0
		v_u_53 = v110
		v_u_54 = v111
		if v_u_49 then
			local v112 = v_u_49.resize
			if type(v112) == "function" then
				v_u_49.resize(v_u_53, v_u_54)
			end
		end
		local v113 = v_u_74
		local v114 = v_u_36.tabs
		v113.Position = UDim2.fromOffset(v114.x0, v114.y0)
		v113.Size = UDim2.fromOffset(v114.x1 - v114.x0, v114.y1 - v114.y0)
		local v115 = v_u_76
		local v116 = v_u_36.grid
		v115.Position = UDim2.fromOffset(v116.x0, v116.y0)
		v115.Size = UDim2.fromOffset(v116.x1 - v116.x0, v116.y1 - v116.y0)
		v_u_77.CellSize = UDim2.fromOffset(v_u_36.cellW, v_u_36.cellH)
		local v117 = v_u_78
		local v118 = {
			["x0"] = v_u_36.grid.x0,
			["y0"] = v_u_36.grid.y0 + 2,
			["x1"] = v_u_36.grid.x1
		}
		local v119 = v_u_36.grid.y0 + 2
		local v120 = v_u_36.grid.y1 - v_u_36.grid.y0
		v118.y1 = v119 + math.min(96, v120)
		v117.Position = UDim2.fromOffset(v118.x0, v118.y0)
		v117.Size = UDim2.fromOffset(v118.x1 - v118.x0, v118.y1 - v118.y0)
		if v_u_36.cellW ~= v_u_50 then
			v_u_50 = v_u_36.cellW
			if v_u_32 then
				v_u_24.draw()
			end
		end
	end
	v_u_25:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_24
		v_u_24.relayout()
	end)
	local function v_u_128() -- name: paintLayers
		-- upvalues: (ref) v_u_51, (ref) v_u_49, (copy) v_u_11, (copy) v_u_37, (ref) v_u_47, (copy) v_u_16, (copy) v_u_20, (ref) v_u_53, (ref) v_u_54, (ref) v_u_35, (ref) v_u_52, (copy) p_u_6, (copy) v_u_14, (copy) v_u_40
		if v_u_51 then
			local v121 = v_u_51.destroy
			pcall(v121)
			v_u_51 = nil
		end
		if v_u_49 then
			local v122 = v_u_49.destroy
			pcall(v122)
			v_u_49 = nil
		end
		local v123 = v_u_11.lib.KillCardFx
		v_u_51 = v123.bg(v_u_37, v_u_47.bg, v_u_16, v_u_20)
		local v124 = {
			["z"] = 5,
			["w"] = nil,
			["h"] = nil,
			["w"] = v_u_53,
			["h"] = v_u_54
		}
		v_u_49 = v123.frame(v_u_37, v_u_47.frame, v_u_16, v_u_20, v124)
		v_u_35 = os.clock()
		v_u_52 = -1
		local v125 = p_u_6.profile
		local v126
		if type(v125) == "table" then
			v126 = v125.kc
		else
			v126 = nil
		end
		local v127 = v_u_14.selection(v126)
		v_u_40.Visible = (v_u_47.anim ~= v127.anim or v_u_47.bg ~= v127.bg) and true or v_u_47.frame ~= v127.frame
	end
	local function v_u_139() -- name: ensureRig
		-- upvalues: (ref) v_u_48, (copy) v_u_11, (copy) v_u_37, (copy) v_u_18, (copy) v_u_23
		if v_u_48 == nil then
			local v129 = v_u_11.lib.KillCardRig
			local v130 = v129.new
			local v131 = {
				["parent"] = nil,
				["AnimRig"] = nil,
				["Poses"] = nil,
				["Anim"] = nil,
				["deps"] = nil,
				["zindex"] = 4,
				["parent"] = v_u_37,
				["AnimRig"] = v_u_11.lib.AnimRig,
				["Poses"] = v_u_11.lib.FilmPhotoPoses,
				["Anim"] = v_u_18,
				["deps"] = v129.depsOf(v_u_11)
			}
			local v132, v133 = pcall(v130, v131)
			if v132 then
				local v134 = v133.load
				local v135 = v_u_23
				local v136, v137 = pcall(v134, v135)
				if v136 and v137 ~= "thumb" then
					v_u_48 = v133
				else
					local v138 = v133.destroy
					pcall(v138)
				end
			else
				return
			end
		else
			return
		end
	end
	local v_u_140 = {
		["equipped"] = v_u_13.equipped,
		["owned"] = v_u_13.owned,
		["locked"] = v_u_13.locked
	}
	local function v_u_161(p_u_141) -- name: describe
		-- upvalues: (ref) v_u_30, (ref) v_u_31, (copy) v_u_44, (copy) v_u_45, (copy) v_u_46, (copy) v_u_71, (copy) v_u_58, (copy) v_u_69, (copy) v_u_42, (copy) p_u_6, (copy) v_u_21, (copy) v_u_9, (copy) v_u_38, (ref) v_u_28, (copy) v_u_14, (copy) v_u_19, (copy) v_u_13, (copy) v_u_140, (copy) v_u_59, (copy) v_u_20, (copy) v_u_70, (copy) v_u_15, (ref) v_u_5, (ref) v_u_36, (copy) v_u_22
		v_u_30 = p_u_141
		v_u_31 = nil
		if p_u_141 == nil then
			local v142 = v_u_45
			local v143 = v_u_46
			local v144 = v_u_71
			v_u_44.Text = ""
			v142.Text = ""
			v143.Text = ""
			v144.Text = ""
			local v145 = v_u_69
			local v146 = v_u_71
			v_u_58.Visible = false
			v145.Visible = false
			v146.Visible = false
			v_u_42.Visible = false
		else
			v_u_42.Visible = true
			local v147 = p_u_6.profile
			local v148
			if type(v147) == "table" then
				v148 = v147.kc
			else
				v148 = nil
			end
			v_u_44.Text = p_u_141.name
			local v149 = v_u_21.textColor(p_u_141.rarity, v_u_9)
			v_u_44.TextColor3 = v149
			local function v150()
				-- upvalues: (ref) v_u_38, (ref) v_u_21, (copy) p_u_141, (ref) v_u_9
				v_u_38.Color = v_u_21.color(p_u_141.rarity, v_u_9)
			end
			pcall(v150)
			local v_u_151
			if v_u_28 == "title" then
				v_u_151 = p_u_141.worn and "equipped" or (p_u_141.owned and "owned" or "locked")
				v_u_45.Text = v_u_21.label(p_u_141.rarity)
				local v152 = v_u_46
				local v153
				if p_u_141.owned then
					v153 = ""
				elseif p_u_141.shop == true then
					v153 = v_u_14.sourceText(p_u_141, v_u_19)
				else
					v153 = v_u_13.titleLockedSource
				end
				v152.Text = v153
			else
				v_u_151 = v_u_14.stateOf(p_u_141, v148)
				v_u_45.Text = (v_u_21.LABELS[p_u_141.rarity] or "") .. "  \194\183  " .. v_u_140[v_u_151]
				v_u_46.Text = v_u_14.sourceText(p_u_141, v_u_19)
			end
			v_u_45.TextColor3 = v149
			v_u_58.Visible = true
			if v_u_151 == "equipped" then
				v_u_59.setKind("secondary")
				v_u_59.setText(v_u_13.equipped)
				v_u_59.setEnabled(false)
			elseif v_u_151 == "owned" then
				v_u_59.setKind("primary")
				v_u_59.setText(v_u_13.equip)
				v_u_59.setEnabled(true)
			else
				v_u_58.Visible = false
			end
			local v154 = v_u_14.buyOffer(p_u_141, v_u_28, v_u_151, v_u_19, v_u_20)
			v_u_31 = v154
			v_u_69.Visible = v154 ~= nil
			if v154 ~= nil then
				local v_u_155 = v154.price
				local function v157()
					-- upvalues: (ref) v_u_70, (ref) v_u_15, (ref) v_u_5, (copy) v_u_155
					v_u_70.label.RichText = true
					local v156 = v_u_155
					v_u_70.label.Text = ("%s  <font face=\"GothamBold\">%s</font> %s"):format(v_u_15.buy, v_u_5, (tostring(v156)))
				end
				pcall(v157)
				v_u_69:SetAttribute("Price", v_u_155)
			end
			v_u_71.Text = (v154 == nil or v154.note == nil) and "" or v154.note
			local v158 = v_u_71
			local v159
			if v154 == nil or v154.note == nil then
				v159 = false
			else
				v159 = v_u_36.note.y1 - v_u_36.note.y0 >= 12
			end
			v158.Visible = v159
			if v_u_22 then
				local function v160()
					-- upvalues: (ref) v_u_22, (ref) v_u_28, (copy) p_u_141, (ref) v_u_151
					v_u_22:SetAttribute("MenuKillCard", ("%s %s %s"):format(v_u_28, p_u_141.id, v_u_151))
				end
				pcall(v160)
			end
		end
	end
	v_u_59.setText(v_u_13.equip)
	v_u_58.Activated:Connect(function()
		-- upvalues: (ref) v_u_30, (ref) v_u_28, (copy) v_u_14, (copy) p_u_6
		local v162 = v_u_30
		if v162 ~= nil then
			local v163
			if v_u_28 == "title" then
				v163 = v_u_14.titlePayload(v162)
			else
				local v164 = v_u_14.equipPayload
				local v165 = p_u_6.profile
				local v166
				if type(v165) == "table" then
					v166 = v165.kc
				else
					v166 = nil
				end
				v163 = v164(v162, v166)
			end
			if v163 ~= nil then
				p_u_6.op(v163)
			end
		end
	end)
	local function v_u_195(p167, p168, p_u_169, p_u_170) -- name: thumbFor
		-- upvalues: (copy) v_u_8, (copy) v_u_10, (ref) v_u_28, (copy) v_u_16, (copy) v_u_20
		local v_u_171 = v_u_8.new("Frame", {
			["Name"] = "Thumb",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_10.raised2 or v_u_10.raised,
			["Position"] = UDim2.fromOffset(p_u_169.x0, p_u_169.y0),
			["Size"] = UDim2.fromOffset(p_u_169.x1 - p_u_169.x0, p_u_169.y1 - p_u_169.y0)
		}, p167)
		if v_u_28 == "bg" then
			local v172 = v_u_16.BACKGROUNDS[p168.id]
			if v172 then
				local v173 = v172.stops[1]
				local v174 = v172.stops[2] or v172.stops[1]
				v_u_171.BackgroundColor3 = Color3.new(1, 1, 1)
				v_u_8.new("UIGradient", {
					["Rotation"] = 90,
					["Color"] = nil,
					["Color"] = ColorSequence.new(Color3.fromRGB(v173[1], v173[2], v173[3]), Color3.fromRGB(v174[1], v174[2], v174[3]))
				}, v_u_171)
			end
			v_u_8.stroke(v_u_171, v_u_10.lineStrong)
			local v175
			if v_u_20 == nil then
				v175 = nil
			else
				local v176 = v_u_20.background
				if type(v176) == "function" then
					v175 = v_u_20.background(p168.id)
				else
					v175 = nil
				end
			end
			if v175 ~= nil then
				local v177 = v175.base
				if type(v177) == "string" and v175.base ~= "" then
					v_u_8.new("ImageLabel", {
						["Name"] = "ThumbImage",
						["BackgroundTransparency"] = 1,
						["BorderSizePixel"] = 0,
						["Image"] = nil,
						["ScaleType"] = nil,
						["Size"] = nil,
						["Image"] = v175.base,
						["ScaleType"] = Enum.ScaleType.Crop,
						["Size"] = UDim2.fromScale(1, 1)
					}, v_u_171)
				end
			end
			if p_u_170 then
				v_u_171.BackgroundTransparency = 0.35
			end
			return
		elseif v_u_28 == "frame" then
			local v178 = v_u_16.FRAMES[p168.id]
			v_u_171.BackgroundColor3 = v_u_10.bg
			local v179 = v178 and (v178.stroke or { 120, 30, 34 }) or { 120, 30, 34 }
			local v180
			if v_u_20 == nil then
				v180 = nil
			else
				local v181 = v_u_20.frame
				if type(v181) == "function" then
					v180 = v_u_20.frame(p168.id)
				else
					v180 = nil
				end
			end
			local v182, v183, v184
			if v180 == nil then
				v182 = v_u_8.stroke
				v183 = Color3.fromRGB(v179[1], v179[2], v179[3])
				v184 = v178 and v178.px or 2
				v182(v_u_171, v183, (math.clamp(v184, 2, 4)))
			else
				local v185 = v180.image
				if type(v185) == "string" and v180.image ~= "" then
					local v186 = v_u_20.sliceRect
					if type(v186) == "function" then
						local v187 = v_u_20.sliceRect()
						v_u_8.new("ImageLabel", {
							["Name"] = "ThumbImage",
							["BackgroundTransparency"] = 1,
							["BorderSizePixel"] = 0,
							["Image"] = nil,
							["ScaleType"] = nil,
							["SliceCenter"] = nil,
							["SliceScale"] = nil,
							["Size"] = nil,
							["Image"] = v180.image,
							["ScaleType"] = Enum.ScaleType.Slice,
							["SliceCenter"] = Rect.new(v187[1], v187[2], v187[3], v187[4]),
							["SliceScale"] = v_u_20.sliceScale(p_u_169.x1 - p_u_169.x0, p_u_169.y1 - p_u_169.y0),
							["Size"] = UDim2.fromScale(1, 1)
						}, v_u_171)
						v_u_8.stroke(v_u_171, v_u_10.line, 1)
						if p_u_170 then
							v_u_171.BackgroundTransparency = 0.35
						end
						return
					end
					v182 = v_u_8.stroke
					v183 = Color3.fromRGB(v179[1], v179[2], v179[3])
					v184 = v178 and v178.px or 2
					v182(v_u_171, v183, (math.clamp(v184, 2, 4)))
				else
					v182 = v_u_8.stroke
					v183 = Color3.fromRGB(v179[1], v179[2], v179[3])
					v184 = v178 and v178.px or 2
					v182(v_u_171, v183, (math.clamp(v184, 2, 4)))
				end
			end
			if p_u_170 then
				v_u_171.BackgroundTransparency = 0.35
			end
		else
			v_u_171.BackgroundColor3 = v_u_10.accentDeep
			local v_u_188 = v_u_28 == "title" and "star" or "hand"
			local function v194()
				-- upvalues: (ref) v_u_8, (copy) v_u_188, (copy) p_u_169, (copy) p_u_170, (ref) v_u_10, (copy) v_u_171
				local v189 = v_u_8.icon
				local v190 = v_u_188
				local v191 = {}
				local v192 = (p_u_169.x1 - p_u_169.x0) * 0.6
				v191.size = math.floor(v192)
				local v193
				if p_u_170 then
					v193 = v_u_10.muted
				else
					v193 = v_u_10.accent
				end
				v191.color = v193
				v191.position = UDim2.fromScale(0.5, 0.5)
				v191.anchor = Vector2.new(0.5, 0.5)
				v189(v190, v191).Parent = v_u_171
			end
			pcall(v194)
			if p_u_170 then
				v_u_171.BackgroundTransparency = 0.35
			end
		end
	end
	local function v_u_226(p_u_196, p197, p198, p199) -- name: cellFor
		-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_76, (copy) v_u_21, (copy) v_u_9, (copy) v_u_14, (ref) v_u_28, (copy) v_u_19, (copy) v_u_20, (ref) v_u_36, (copy) v_u_195, (ref) v_u_5, (copy) v_u_140, (ref) v_u_47, (copy) v_u_128, (ref) v_u_48, (copy) v_u_24, (copy) v_u_55, (copy) v_u_56
		local v200 = v_u_8.new
		local v201 = "TextButton"
		local v202 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["Name"] = "Piece_" .. p_u_196.id
		}
		local v203
		if p199 then
			v203 = v_u_10.accentDeep
		else
			v203 = v_u_10.raised
		end
		v202.BackgroundColor3 = v203
		v202.LayoutOrder = p197
		local v204 = v200(v201, v202, v_u_76)
		v204.SelectionImageObject = v_u_8.selectionImage()
		local v205 = v_u_21.color(p_u_196.rarity, v_u_9)
		local v206 = v_u_21.textColor(p_u_196.rarity, v_u_9)
		local v207 = v_u_8.stroke
		local v208
		if p199 then
			v208 = v_u_10.accent
		else
			v208 = v_u_10.line
		end
		v207(v204, v208, p199 and 2 or 1, 0)
		local v209 = v_u_14.buyOffer(p_u_196, v_u_28, p198, v_u_19, v_u_20)
		local v210 = v_u_14.cellLayout(v_u_36.cellW, v_u_36.cellH, v209 ~= nil)
		v_u_8.new("Frame", {
			["Name"] = "Stripe",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundTransparency"] = nil,
			["BackgroundColor3"] = v205,
			["Size"] = UDim2.new(0, 4, 1, 0),
			["BackgroundTransparency"] = p198 == "locked" and 0.5 or 0
		}, v204)
		v_u_195(v204, p_u_196, v210.thumb, p198 == "locked")
		local v211 = v_u_8.label
		local v212 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "h3",
			["fit"] = true,
			["track"] = false,
			["color"] = nil,
			["parent"] = v204,
			["text"] = p_u_196.name
		}
		if p198 == "locked" then
			v206 = v_u_10.text2
		end
		v212.color = v206
		local v213 = v211(v212)
		local v214 = v210.name
		v213.Position = UDim2.fromOffset(v214.x0, v214.y0)
		v213.Size = UDim2.fromOffset(v214.x1 - v214.x0, v214.y1 - v214.y0)
		if v209 == nil then
			local v215 = v_u_8.label
			local v216 = {
				["parent"] = nil,
				["name"] = "State",
				["text"] = nil,
				["style"] = "micro",
				["track"] = false,
				["color"] = nil,
				["parent"] = v204,
				["text"] = v_u_140[p198]
			}
			local v217
			if p198 == "equipped" then
				v217 = v_u_10.accent
			elseif p198 == "owned" then
				v217 = v_u_10.text2
			else
				v217 = v_u_10.muted
			end
			v216.color = v217
			local v218 = v215(v216)
			local v219 = v210.state
			v218.Position = UDim2.fromOffset(v219.x0, v219.y0)
			v218.Size = UDim2.fromOffset(v219.x1 - v219.x0, v219.y1 - v219.y0)
		else
			local v220 = v_u_8.label({
				["parent"] = nil,
				["name"] = "Price",
				["text"] = "",
				["style"] = "small",
				["track"] = false,
				["color"] = nil,
				["parent"] = v204,
				["color"] = v_u_10.accent
			})
			v220.RichText = true
			local v221 = v_u_5
			local v222 = v209.price
			v220.Text = ("<font face=\"GothamBold\">%s</font> %s"):format(v221, (tostring(v222)))
			local v223 = v210.chip
			v220.Position = UDim2.fromOffset(v223.x0, v223.y0)
			v220.Size = UDim2.fromOffset(v223.x1 - v223.x0, v223.y1 - v223.y0)
		end
		local function v224() -- name: tap
			-- upvalues: (ref) v_u_28, (ref) v_u_47, (copy) p_u_196, (ref) v_u_128, (ref) v_u_48, (ref) v_u_24
			if v_u_28 ~= "title" then
				v_u_47[v_u_28] = p_u_196.id
				v_u_128()
				if v_u_28 == "anim" and v_u_48 then
					v_u_48.play(v_u_47.anim, os.clock())
				end
			end
			v_u_24.draw(p_u_196.id)
		end
		v204.Activated:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_28, (ref) v_u_47, (copy) p_u_196, (ref) v_u_128, (ref) v_u_48, (ref) v_u_24
			local function v225()
				-- upvalues: (ref) v_u_8, (ref) v_u_9
				v_u_8.sound(v_u_9.sounds.click)
			end
			pcall(v225)
			if v_u_28 ~= "title" then
				v_u_47[v_u_28] = p_u_196.id
				v_u_128()
				if v_u_28 == "anim" and v_u_48 then
					v_u_48.play(v_u_47.anim, os.clock())
				end
			end
			v_u_24.draw(p_u_196.id)
		end)
		v_u_55[p_u_196.id] = v224
		v_u_56[p_u_196.id] = v204
	end
	local v_u_227 = {
		["anim"] = v_u_15.emptyAnim,
		["bg"] = v_u_15.emptyBg,
		["frame"] = v_u_15.emptyFrame,
		["title"] = v_u_15.emptyTitle
	}
	function v_u_24.draw(p_u_228) -- name: draw
		-- upvalues: (copy) v_u_25, (copy) v_u_8, (copy) v_u_76, (copy) v_u_56, (copy) v_u_55, (copy) p_u_6, (ref) v_u_28, (copy) v_u_21, (copy) v_u_14, (copy) v_u_12, (copy) v_u_19, (copy) v_u_16, (copy) v_u_17, (copy) v_u_78, (copy) v_u_79, (copy) v_u_227, (copy) v_u_13, (ref) v_u_30, (copy) v_u_226, (copy) v_u_10, (copy) v_u_161
		if type(p_u_228) ~= "string" then
			p_u_228 = nil
		end
		if v_u_25.Parent then
			v_u_8.keepScroll(v_u_76, function()
				-- upvalues: (ref) v_u_56, (ref) v_u_55, (ref) p_u_6, (ref) v_u_28, (ref) v_u_21, (ref) v_u_14, (ref) v_u_12, (ref) v_u_19, (ref) v_u_16, (ref) v_u_17, (ref) v_u_78, (ref) v_u_79, (ref) v_u_227, (ref) v_u_13, (ref) p_u_228, (ref) v_u_30, (ref) v_u_226, (ref) v_u_10, (ref) v_u_161
				for _, v229 in v_u_56 do
					v229:Destroy()
				end
				table.clear(v_u_56)
				table.clear(v_u_55)
				local v230 = p_u_6.profile
				local v231
				if type(v230) == "table" then
					v231 = v230.kc
				else
					v231 = nil
				end
				local v232
				if v_u_28 == "title" then
					local function v237(p233)
						-- upvalues: (ref) v_u_21
						local v234 = v_u_21.rarityOf
						local v235, v236 = pcall(v234, p233)
						return (not v235 or type(v236) ~= "number") and 1 or v236
					end
					local v238 = v_u_14.titles
					local v239 = p_u_6.profile
					local v240
					if v_u_12.Tasks then
						v240 = v_u_12.Tasks.titles
					else
						v240 = nil
					end
					v232 = v238(v239, v240, v237, v_u_19)
				else
					v232 = v_u_14.catalog(v_u_28, v_u_16, v_u_17, v_u_19)
				end
				v_u_78.Visible = #v232 == 0
				v_u_79.Text = v_u_227[v_u_28] or v_u_13.empty
				local v241 = nil
				for v242, v243 in v232 do
					local v244
					if v_u_28 == "title" then
						v244 = v243.worn and "equipped" or (v243.owned and "owned" or "locked")
					else
						v244 = v_u_14.stateOf(v243, v231)
					end
					local v245
					if p_u_228 == nil or v243.id ~= p_u_228 then
						if p_u_228 == nil and v_u_30 ~= nil then
							v245 = v_u_30.id == v243.id
						else
							v245 = false
						end
					else
						v245 = true
					end
					if v245 then
						v241 = v243
					end
					v_u_226(v243, v242, v244, v245)
				end
				if v241 == nil and #v232 > 0 then
					for _, v246 in v232 do
						local v247
						if v_u_28 == "title" then
							v247 = v246.worn
						else
							v247 = v_u_14.wornId(v231, v_u_28) == v246.id
						end
						if not v247 then
							continue
						end
						v241 = v246
					end
					v241 = v241 or v232[1]
					local v248 = v_u_56[v241.id]
					if v248 then
						v248.BackgroundColor3 = v_u_10.accentDeep
					end
				end
				v_u_161(v241)
			end)
		end
	end
	local function v_u_251() -- name: step
		-- upvalues: (ref) v_u_32, (copy) v_u_25, (ref) v_u_48, (copy) v_u_39, (ref) v_u_35, (ref) v_u_52, (ref) v_u_51, (ref) v_u_49
		if v_u_32 and v_u_25.Parent then
			local v249 = os.clock()
			if v_u_48 then
				v_u_48.step(v249)
				if v_u_48.state().shown then
					v_u_39.Visible = false
				end
			end
			local v250 = v249 - v_u_35
			if v250 - v_u_52 >= 0.03333333333333333 then
				v_u_52 = v250
				if v_u_51 then
					v_u_51.step(v250)
				end
				if v_u_49 then
					v_u_49.step(v250)
				end
			end
		end
	end
	function v_u_24.show() -- name: show
		-- upvalues: (ref) v_u_32, (copy) v_u_24, (ref) v_u_47, (copy) v_u_14, (copy) p_u_6, (copy) v_u_139, (copy) v_u_128, (ref) v_u_48, (ref) v_u_33, (ref) v_u_2, (copy) v_u_251
		if not v_u_32 then
			v_u_32 = true
			v_u_24.relayout()
			local v252 = v_u_14.selection
			local v253 = p_u_6.profile
			local v254
			if type(v253) == "table" then
				v254 = v253.kc
			else
				v254 = nil
			end
			v_u_47 = v252(v254)
			v_u_139()
			v_u_128()
			if v_u_48 then
				v_u_48.play(v_u_47.anim, os.clock())
			end
			v_u_24.draw()
			v_u_33 = v_u_2.Heartbeat:Connect(v_u_251)
		end
	end
	function v_u_24.hide() -- name: hide
		-- upvalues: (ref) v_u_32, (ref) v_u_33
		v_u_32 = false
		if v_u_33 then
			v_u_33:Disconnect()
			v_u_33 = nil
		end
	end
	function v_u_24.refresh(p255) -- name: refresh
		-- upvalues: (ref) v_u_32, (copy) v_u_24
		if p255 == nil or (p255 == "profile" or p255 == "result") then
			if v_u_32 then
				v_u_24.draw()
			end
		end
	end
	function v_u_24.tick() -- name: tick end
	function v_u_24.destroy() -- name: destroy
		-- upvalues: (copy) v_u_24, (ref) v_u_51, (ref) v_u_49, (ref) v_u_48, (copy) v_u_25
		v_u_24.hide()
		if v_u_51 then
			local v256 = v_u_51.destroy
			pcall(v256)
			v_u_51 = nil
		end
		if v_u_49 then
			local v257 = v_u_49.destroy
			pcall(v257)
			v_u_49 = nil
		end
		if v_u_48 then
			local v258 = v_u_48.destroy
			pcall(v258)
			v_u_48 = nil
		end
		v_u_25:Destroy()
	end
	function v_u_24.state() -- name: state
		-- upvalues: (ref) v_u_28, (ref) v_u_47, (ref) v_u_30, (copy) v_u_76, (ref) v_u_48, (ref) v_u_32, (ref) v_u_31, (ref) v_u_36, (ref) v_u_51, (ref) v_u_49
		local v259 = {
			["kind"] = v_u_28,
			["sel"] = table.clone(v_u_47)
		}
		local v260 = v_u_30
		if v260 then
			v260 = v_u_30.id
		end
		v259.focus = v260
		v259.cells = #v_u_76:GetChildren()
		local v261
		if v_u_48 then
			v261 = v_u_48.state()
		else
			v261 = nil
		end
		v259.rig = v261
		v259.shown = v_u_32
		v259.offer = v_u_31
		v259.mode = v_u_36.mode
		local v262
		if v_u_51 then
			v262 = v_u_51.info
		else
			v262 = nil
		end
		v259.bgInfo = v262
		local v263
		if v_u_49 == nil then
			v263 = false
		else
			v263 = v_u_49.isImage == true
		end
		v259.frameImage = v263
		return v259
	end
	function v_u_24.layout() -- name: layout
		-- upvalues: (ref) v_u_36
		return v_u_36
	end
	function v_u_24.select(p264) -- name: select
		-- upvalues: (copy) v_u_55
		local v265 = v_u_55[p264]
		if not v265 then
			return false
		end
		v265()
		return true
	end
	function v_u_24.cell(p266) -- name: cell
		-- upvalues: (copy) v_u_56
		return v_u_56[p266]
	end
	function v_u_24.equipButton() -- name: equipButton
		-- upvalues: (copy) v_u_58
		return v_u_58
	end
	function v_u_24.buyButton() -- name: buyButton
		-- upvalues: (copy) v_u_69
		return v_u_69
	end
	function v_u_24.noteLabel() -- name: noteLabel
		-- upvalues: (copy) v_u_71
		return v_u_71
	end
	function v_u_24.setKind(p267) -- name: setKind
		-- upvalues: (ref) v_u_4, (copy) v_u_75
		if table.find(v_u_4, p267) then
			v_u_75.select(p267)
		end
	end
	v_u_24.relayout(v_u_36.right.x1, v_u_36.left.y1)
	return v_u_24
end
v3.mount = v3.new
return v3