-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioAmbience

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("CollectionService")
local v_u_4 = {}
local v_u_5 = {
	["acc"] = (1 / 0),
	["litAcc"] = (1 / 0),
	["mods"] = nil,
	["pub"] = nil
}
local v_u_6 = nil
local function v_u_11(p7) -- name: tokyoLevels
	-- upvalues: (ref) v_u_6, (copy) v_u_2
	if v_u_6 == nil then
		local function v8()
			-- upvalues: (ref) v_u_2
			return require((v_u_2:WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("TokyoSounds", 5)))
		end
		local v9, v10 = pcall(v8)
		if not v9 or (type(v10) ~= "table" or not v10.levels) then
			v10 = false
		end
		v_u_6 = v10
	end
	if v_u_6 then
		return v_u_6.levels(p7)
	else
		return nil
	end
end
local function v_u_17(p12) -- name: litNear
	-- upvalues: (copy) v_u_3
	for _, v13 in v_u_3:GetTagged("HushLight") do
		if not v13:IsA("BasePart") or v13:GetAttribute("Dead") == true then
			continue
		end
		local v14 = v13.Position - p12
		local v15 = v14.Y
		if math.abs(v15) >= 10 or v14.X * v14.X + v14.Z * v14.Z >= 900 then
			continue
		end
		local v16 = v13:FindFirstChildWhichIsA("Light")
		if (not v16 or (not v16.Enabled or v16.Brightness <= 0.05)) and (v16 or (v13.Material ~= Enum.Material.Neon or v13.Transparency >= 0.5)) then
			continue
		end
		return true
	end
	return false
end
local v_u_18 = nil
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = {
	["place"] = "Menu",
	["time"] = "Dusk",
	["weather"] = "Rain",
	["indoor"] = false,
	["kind"] = nil
}
local v_u_22 = 0
local v_u_23 = 0
local v_u_24 = Vector3.new(0, 0, 0)
local v_u_25 = Random.new()
local v_u_26 = true
local function v_u_34(p27) -- name: targetsFor
	-- upvalues: (copy) v_u_11
	local v28 = {}
	local v29 = p27.place
	if v29 == "Menu" then
		v28.amb_rain = 0.8
		v28.amb_wind = 0.55
		return v28
	end
	if v29 ~= "Hideout" then
		if v29 == "Raid" and p27.under then
			v28.amb_room = 0.45
			if p27.lit then
				v28.amb_hum = 0.35
			end
			if p27.zone == "res" then
				v28.amb_fan = 0.55
				return v28
			end
		elseif v29 == "Raid" and (p27.tokyo == true and v_u_11(p27) ~= nil) then
			for v30, v31 in v_u_11(p27) do
				v28[v30] = v31
			end
			v28.amb_wind = 0.2
			if p27.indoor then
				v28.amb_room = 0.8
				return v28
			end
		elseif v29 == "Raid" then
			local v32 = p27.weather
			v28.amb_wind = v32 == "Storm" and 1 or (v32 == "Fog" and 0.45 or (v32 == "Rain" and 0.55 or (v32 == "Snow" and ((p27.snow or 1) >= 3 and 1 or 0.9) or 0.7)))
			if v32 == "Rain" then
				v28.amb_rain = 0.85
			elseif v32 == "Storm" then
				v28.amb_storm = 0.9
				v28.amb_rain = 0.5
			end
			if (p27.ashHum or 0) > 0.01 then
				local v33 = p27.ashHum * (1 + 0.6 * (p27.ashSurge or 0))
				v28.amb_ashhum = math.min(1, v33)
			end
			if (p27.time == "Night" or p27.time == "Dusk") and (v32 ~= "Storm" and v32 ~= "Snow") then
				v28.amb_crickets = p27.time == "Night" and (v32 == "Rain" and 0.35 or 0.9) or 0.4
			end
			if p27.indoor then
				v28.amb_room = 0.8
			end
		end
		return v28
	end
	v28.amb_fan = 0.45
	v28.amb_room = 0.6
	v28.amb_wind = 0.12
	return v28
end
v_u_4.targetsFor = v_u_34
local function v_u_44(p35) -- name: apply
	-- upvalues: (ref) v_u_26, (copy) v_u_34, (copy) v_u_21, (copy) v_u_19, (ref) v_u_18, (copy) v_u_20
	if v_u_26 then
		local v36 = v_u_34(v_u_21)
		for v37, v38 in v36 do
			local v39 = v_u_19[v37]
			if v39 and v39:alive() or v38 <= 0 then
				if not v39 or v_u_20[v37] == v38 then
					continue
				end
				v39:setVolume(v38, p35)
				v_u_20[v37] = v38
			else
				local v40 = {
					["volume"] = v38,
					["fadeIn"] = p35,
					["group"] = ((v37 == "amb_room" or v37 == "amb_fan") and true or v37 == "amb_hum") and "AmbIn" or nil
				}
				v_u_19[v37] = v_u_18.bed(v37, v40)
				v_u_20[v37] = v38
			end
		end
		local v41 = {}
		for v42 in v_u_19 do
			if v36[v42] then
				continue
			end
			table.insert(v41, v42)
		end
		for _, v43 in v41 do
			v_u_19[v43]:stop(p35)
			v_u_19[v43] = nil
			v_u_20[v43] = nil
		end
	end
end
function v_u_4.setScene(p45, p46) -- name: setScene
	-- upvalues: (copy) v_u_21, (copy) v_u_44
	local v47 = false
	for v48, v49 in p45 do
		if v_u_21[v48] == v49 then
			continue
		end
		v_u_21[v48] = v49
		v47 = true
	end
	if v47 then
		v_u_44(p46 or 3)
	end
end
function v_u_4.scene() -- name: scene
	-- upvalues: (copy) v_u_21
	return v_u_21
end
function v_u_4.bedList() -- name: bedList
	-- upvalues: (copy) v_u_19
	local v50 = {}
	for v51 in v_u_19 do
		table.insert(v50, v51)
	end
	table.sort(v50)
	return table.concat(v50, ",")
end
function v_u_4.setEnabled(p52, p53) -- name: setEnabled
	-- upvalues: (ref) v_u_26, (copy) v_u_19, (copy) v_u_20, (copy) v_u_44
	v_u_26 = p52
	if p52 then
		v_u_44(p53 or 2)
	else
		for _, v54 in v_u_19 do
			v54:stop(p53 or 1.5)
		end
		table.clear(v_u_19)
		table.clear(v_u_20)
	end
end
local function v_u_63() -- name: pickOneShot
	-- upvalues: (copy) v_u_21, (copy) v_u_25
	if v_u_21.under then
		return "amb_creak"
	end
	local v55 = v_u_21.weather
	local v56 = v_u_21.time == "Night"
	local v57 = {}
	local v58 = { "amb_dogs", v56 and 3 or (v_u_21.time == "Dusk" and 2 or 1) }
	__set_list(v57, 1, {{ "amb_wind_gust", v55 == "Storm" and 5 or (v55 == "Clear" and 2 or 3) }, v58, { "amb_siren_far", 1.2 }, { "amb_crow", v56 and 0 or 2 }, { "amb_scream_far", v56 and 1.2 or 0.5 }, { "amb_creak", 1.5 }, { "amb_gunfire_far", 0.8 }, { "amb_wolves", v56 and 1 or 0 }})
	local v59 = 0
	for _, v60 in v57 do
		v59 = v59 + v60[2]
	end
	local v61 = v_u_25:NextNumber() * v59
	for _, v62 in v57 do
		v61 = v61 - v62[2]
		if v61 > 0 then
			continue
		end
		return v62[1]
	end
	return nil
end
v_u_4.ASH_HUM = {
	{
		-560,
		-484,
		-224,
		-308,
		0.9
	},
	{
		-543,
		-300,
		-525,
		300,
		0.8
	},
	{
		-500,
		-300,
		-190,
		-10,
		0.5
	},
	{
		-230,
		-45,
		230,
		345,
		0.25
	}
}
function v_u_4.ashHumAt(p64, p65) -- name: ashHumAt
	-- upvalues: (copy) v_u_4
	for _, v66 in v_u_4.ASH_HUM do
		if v66[1] > p64 or (p64 > v66[3] or (v66[2] > p65 or p65 > v66[4])) then
			continue
		end
		return v66[5]
	end
	return 0
end
function v_u_4.surgeLevel(p67, p68, p69, p70) -- name: surgeLevel
	if type(p68) == "number" and (p68 <= p70 and (type(p69) ~= "number" or p70 <= p69 + 1)) then
		return 1
	end
	if type(p67) ~= "number" or p67 > p70 then
		return 0
	end
	local v71 = (p70 - p67) / 4
	return math.clamp(v71, 0, 1) * 0.8
end
function v_u_4.step(p72, p73) -- name: step
	-- upvalues: (ref) v_u_24, (ref) v_u_26, (copy) v_u_21, (ref) v_u_23, (ref) v_u_18, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_17, (copy) v_u_1, (ref) v_u_22, (copy) v_u_25, (copy) v_u_63
	v_u_24 = p73
	if v_u_26 then
		local v74 = (v_u_21.indoor or v_u_21.under) and v_u_21.place == "Raid" and 1 or (v_u_21.place == "Hideout" and 1 or 0)
		local v75 = v_u_23 - v74
		if math.abs(v75) > 0.005 then
			local v76 = v_u_23
			local v77 = v74 - v_u_23
			local v78 = p72 * 2.5
			v_u_23 = v76 + v77 * math.min(1, v78)
			local v79 = v_u_18.groups
			local v80 = v_u_18.effects.walls
			if v80 then
				v80.Enabled = v_u_23 > 0.02
				v80.HighGain = v_u_23 * -30
				v80.MidGain = v_u_23 * -12
				v80.LowGain = 0
			end
			if v79.AmbOut then
				v79.AmbOut.Volume = 1 - v_u_23 * 0.45
			end
			if v79.AmbIn then
				v79.AmbIn.Volume = v_u_23
			end
		end
		if v_u_21.place == "Raid" then
			local v81 = v_u_5
			v81.acc = v81.acc + p72
			if v_u_5.acc >= 0.5 then
				v_u_5.acc = 0
				if v_u_5.mods == nil then
					local function v83()
						-- upvalues: (ref) v_u_2
						local v82 = v_u_2:WaitForChild("Hush"):WaitForChild("Shared")
						return {
							["MapInfo"] = require(v82:WaitForChild("MapInfo")),
							["HollowLevels"] = require(v82:WaitForChild("HollowLevels"))
						}
					end
					local v84, v85 = pcall(v83)
					local v86 = v_u_5
					if not v84 then
						v85 = false
					end
					v86.mods = v85
				end
				local v87 = v_u_5.mods or nil
				local v88
				if v87 then
					v88 = v87.MapInfo.fromRuntime()
				else
					v88 = v87
				end
				local v89
				if type(v88) == "table" and v88.underground == true then
					v89 = v_u_24.Y < v87.HollowLevels.SURFACE_Y
				else
					v89 = false
				end
				if v89 then
					local v90 = v87.MapInfo.zoneAt(v88, v_u_24)
					local v91 = v_u_21.lit == true
					local v92 = v_u_5
					v92.litAcc = v92.litAcc + 0.5
					if v_u_5.litAcc >= 1 or not v_u_21.under then
						v_u_5.litAcc = 0
						v91 = v_u_17(v_u_24)
					end
					v_u_4.setScene({
						["under"] = true,
						["zone"] = nil,
						["lit"] = nil,
						["zone"] = v90,
						["lit"] = v91
					}, 2.5)
				elseif v_u_21.under then
					v_u_4.setScene({
						["under"] = false,
						["zone"] = "",
						["lit"] = false
					}, 2.5)
				end
				local v93 = v_u_2:FindFirstChild("HushRuntime")
				if v93 and v93:GetAttribute("MapId") == "unknown5" then
					local v94 = v93:FindFirstChild("Raid")
					local v95 = not v94 and 0 or v_u_4.surgeLevel(v94:GetAttribute("AshSurgeWarn"), v94:GetAttribute("AshSurgeAt"), v94:GetAttribute("AshSurgeEnd"), v_u_1.now())
					local v96 = v_u_4.setScene
					local v97 = {
						["ashHum"] = v_u_4.ashHumAt(v_u_24.X, v_u_24.Z)
					}
					local v98 = v95 * 10 + 0.5
					v97.ashSurge = math.floor(v98) / 10
					v96(v97, 1.5)
				elseif (v_u_21.ashHum or 0) ~= 0 then
					v_u_4.setScene({
						["ashHum"] = 0,
						["ashSurge"] = 0
					}, 2)
				end
				local v99
				if v_u_21.under then
					local v100 = string.format
					local v101 = v_u_21.zone
					local v102 = tostring(v101)
					local v103 = v_u_21.lit
					v99 = v100("%s|%s|%s", v102, tostring(v103), v_u_4.bedList())
				else
					v99 = nil
				end
				if v99 ~= v_u_5.pub then
					v_u_5.pub = v99
					local v104 = game:GetService("Players").LocalPlayer
					if v104 then
						v104:SetAttribute("AmbUnder", v99)
					end
				end
			end
			local v105 = os.clock()
			if v_u_22 == 0 then
				v_u_22 = v105 + v_u_25:NextNumber(6, 14)
			end
			if v_u_22 <= v105 then
				v_u_22 = v105 + v_u_25:NextNumber(10, 35)
				local v106 = v_u_63()
				if v106 and v_u_21.under then
					local v107 = v_u_25:NextNumber() * 3.141592653589793 * 2
					local v108 = v_u_25:NextNumber(30, 120)
					local v109 = v_u_24
					local v110 = math.cos(v107) * v108
					local v111 = v_u_25:NextNumber(-2, 6)
					local v112 = math.sin(v107) * v108
					local v113 = {
						["pos"] = nil,
						["occlude"] = false,
						["lowpass"] = 0.45,
						["group"] = "AmbIn",
						["pos"] = v109 + Vector3.new(v110, v111, v112)
					}
					v_u_18.play(v106, v113)
					return
				end
				if v106 then
					local v114 = v_u_25:NextNumber() * 3.141592653589793 * 2
					local v115 = v_u_25:NextNumber(150, 450)
					local v116 = v_u_24
					local v117 = math.cos(v114) * v115
					local v118 = v_u_25:NextNumber(5, 25)
					local v119 = math.sin(v114) * v115
					local v120 = {
						["pos"] = nil,
						["occlude"] = false,
						["lowpass"] = 0.25,
						["group"] = "AmbOut",
						["pos"] = v116 + Vector3.new(v117, v118, v119)
					}
					v_u_18.play(v106, v120)
				end
			end
		elseif v_u_21.under then
			v_u_4.setScene({
				["under"] = false,
				["zone"] = "",
				["lit"] = false
			}, 2)
		end
	else
		return
	end
end
function v_u_4.setIndoor(p121, p122) -- name: setIndoor
	-- upvalues: (copy) v_u_4
	v_u_4.setScene({
		["indoor"] = p121,
		["kind"] = p122 or ""
	}, 1.5)
end
function v_u_4.init(p123) -- name: init
	-- upvalues: (ref) v_u_18
	v_u_18 = p123
end
return v_u_4