-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / ReviewListenerFx

local v_u_1 = {}
local v_u_2 = {}
function v_u_1.use(p3) -- name: use
	-- upvalues: (ref) v_u_2
	v_u_2 = type(p3) ~= "table" and {} or p3
end
local v_u_4 = {
	["flash"] = "gren_flash",
	["smoke"] = "gren_smoke_pop",
	["bounce"] = "gren_bounce"
}
function v_u_1.handle(p5, p6, p7) -- name: handle
	-- upvalues: (ref) v_u_2, (copy) v_u_4
	local v8
	if v_u_2.listener == nil then
		v8 = require(script.Parent:WaitForChild("ReviewListener"))
	else
		v8 = v_u_2.listener
	end
	local v9 = v8.fxRoute(p5)
	if v9 == nil or type(p6) ~= "table" then
		return nil
	elseif v9 == "shot" then
		local v10 = p5.o
		local v11
		if v_u_2.isVector == nil then
			v11 = typeof(v10) == "Vector3"
		else
			v11 = v_u_2.isVector(v10) == true
		end
		if v11 then
			local v12 = p6.gunshot
			if type(v12) == "function" then
				local v13 = p5.w
				local v14
				if type(v13) == "string" then
					v14 = p5.w
				else
					v14 = nil
				end
				local v15 = p5.sup == true
				p6.gunshot(v14, p5.o, v15, false)
				if not v15 and type(p7) == "table" then
					local v16 = p7.boom
					if type(v16) == "function" then
						local v17 = p5.o
						local v18 = p6.earDistance
						local v19
						if type(v18) == "function" then
							local v20 = p6.earDistance
							local v21
							v21, v19 = pcall(v20, v17)
							if not v21 or (type(v19) ~= "number" or v19 ~= v19) then
								v19 = nil
							end
						else
							v19 = nil
						end
						if v19 ~= nil and v19 < 90 then
							local v22 = p7.boom
							local v23 = p5.o
							pcall(v22, v23, v14)
						end
					end
				end
				return "shot"
			end
		end
		return nil
	else
		local v24 = v_u_4[v9]
		if v24 == nil then
			local v25 = p5.p
			local v26
			if v_u_2.isVector == nil then
				v26 = typeof(v25) == "Vector3"
			else
				v26 = v_u_2.isVector(v25) == true
			end
			if v26 then
				local v27 = p6.explosion
				if type(v27) == "function" then
					local v28 = p6.explosion
					local v29 = p5.p
					local v30 = p5.r
					local v31 = tonumber(v30)
					v28(v29, (v31 == nil or v31 ~= v31) and 18 or (v31 < 1 and 1 or (v31 > 120 and 120 or v31)))
					if v9 == "frag" then
						local v32 = p6.play3D
						if type(v32) == "function" then
							local v33 = p5.p
							local v34 = p6.earDistance
							local v35
							if type(v34) == "function" then
								local v36 = p6.earDistance
								local v37
								v37, v35 = pcall(v36, v33)
								if not v37 or (type(v35) ~= "number" or v35 ~= v35) then
									v35 = nil
								end
							else
								v35 = nil
							end
							p6.play3D((v35 or 100) < 150 and "gren_frag" or "gren_frag_far", p5.p)
						end
					end
					return v9
				end
			end
			return nil
		else
			local v38 = p5.p
			local v39
			if v_u_2.isVector == nil then
				v39 = typeof(v38) == "Vector3"
			else
				v39 = v_u_2.isVector(v38) == true
			end
			if v39 then
				local v40 = p6.play3D
				if type(v40) == "function" then
					p6.play3D(v24, p5.p)
					return v9
				end
			end
			return nil
		end
	end
end
local v_u_41 = false
function v_u_1.install(p_u_42, p_u_43, p_u_44) -- name: install
	-- upvalues: (ref) v_u_41, (copy) v_u_1
	if v_u_41 then
		return true
	end
	local v45
	if type(p_u_42) == "table" then
		v45 = p_u_42.net
	else
		v45 = nil
	end
	if type(v45) == "table" then
		local v46 = v45.listen
		if type(v46) == "function" and type(p_u_44) == "function" then
			local v_u_53 = {
				["boom"] = function(p47, p48) -- name: boom
					-- upvalues: (copy) p_u_42, (copy) p_u_43
					local v49 = p_u_42.lib
					if v49 then
						v49 = p_u_42.lib.ShotgunFeel
					end
					local v50 = p_u_42.shared
					if v50 then
						v50 = p_u_42.shared.Weapons
					end
					if type(v49) == "table" then
						local v51 = v49.boom
						if type(v51) == "function" and type(v50) == "table" then
							local v52 = v50.stats
							if type(v52) == "function" then
								v49.boom(p_u_43, p47, v50.stats(p48, nil), false)
							end
						end
					end
				end
			}
			local v54 = v45.listen
			local function v59(p55)
				-- upvalues: (copy) p_u_44, (ref) v_u_1, (copy) p_u_43, (copy) v_u_53
				if p_u_44() == true then
					local v56 = v_u_1.handle
					local v57 = p_u_43
					local v58 = v_u_53
					pcall(v56, p55, v57, v58)
				end
			end
			local v60 = pcall(v54, "combat.fx", v59)
			v_u_41 = v60
			return v60
		end
	end
	return false
end
function v_u_1._reset() -- name: _reset
	-- upvalues: (ref) v_u_41
	v_u_41 = false
end
return v_u_1