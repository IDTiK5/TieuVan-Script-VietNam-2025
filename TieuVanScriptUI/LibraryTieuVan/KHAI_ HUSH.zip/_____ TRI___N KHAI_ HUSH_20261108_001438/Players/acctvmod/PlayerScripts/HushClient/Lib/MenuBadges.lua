-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuBadges

local v_u_1 = game:GetService("Players")
local v2 = {}
local v_u_3 = {
	{
		["id"] = "all",
		["text"] = "All"
	},
	{
		["id"] = "earned",
		["text"] = "Earned"
	},
	{
		["id"] = "locked",
		["text"] = "Locked"
	}
}
function v2.new(p_u_4, p5) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v_u_6 = p_u_4.ui
	local v_u_7 = p_u_4.theme
	local v_u_8 = v_u_7.color
	local v_u_9 = p_u_4.kit
	local v10 = p_u_4.cctx
	local v_u_11 = v10.shared.Badges
	local v_u_12 = v10.lib.HUDBadge
	local v_u_13 = v_u_1.LocalPlayer
	local v14 = p_u_4.compact()
	local v_u_15 = {}
	local v_u_16 = "all"
	local _, v17 = v_u_6.panel({
		["parent"] = nil,
		["name"] = "Badges",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 16,
		["parent"] = p5,
		["position"] = UDim2.fromOffset(24, 8),
		["size"] = UDim2.new(1, -48, 1, -8)
	})
	local v18 = v_u_6.new("Frame", {
		["Name"] = "Head",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 44)
	}, v17)
	v_u_6.label({
		["parent"] = nil,
		["text"] = "Badges",
		["style"] = "h2",
		["size"] = nil,
		["parent"] = v18,
		["size"] = UDim2.new(0.5, 0, 0, 30)
	})
	local v_u_19 = v_u_6.label({
		["parent"] = nil,
		["name"] = "Count",
		["text"] = "",
		["style"] = "monoS",
		["align"] = "right",
		["position"] = nil,
		["size"] = nil,
		["parent"] = v18,
		["position"] = UDim2.fromScale(0.5, 0),
		["size"] = UDim2.new(0.5, 0, 0, 30)
	})
	local v20 = v_u_7.touch(36)
	local _, _ = v_u_6.tabs({
		["parent"] = nil,
		["tabs"] = nil,
		["selected"] = "all",
		["position"] = nil,
		["size"] = nil,
		["onChange"] = nil,
		["parent"] = v17,
		["tabs"] = v_u_3,
		["position"] = UDim2.fromOffset(0, 44),
		["size"] = UDim2.new(1, 0, 0, v20),
		["onChange"] = function(p21) -- name: onChange
			-- upvalues: (ref) v_u_16, (copy) v_u_15
			v_u_16 = p21
			v_u_15.draw()
		end
	})
	local v22 = 44 + v20 + 10
	local v_u_23 = v_u_6.list({
		["parent"] = nil,
		["name"] = "List",
		["position"] = nil,
		["size"] = nil,
		["gap"] = 14,
		["padding"] = nil,
		["parent"] = v17,
		["position"] = UDim2.fromOffset(0, v22),
		["size"] = UDim2.new(1, 0, 1, -v22),
		["padding"] = {
			0,
			6,
			0,
			8
		}
	})
	local v_u_24 = v14 and 96 or 104
	local v25 = v_u_7.safeRefSize().X - 48 - 32 - 14
	local v26 = (v25 + 8) / ((v14 and 236 or 270) + 8)
	local v27 = math.floor(v26)
	local v28 = math.max(2, v27)
	local v29 = (v25 + 8) / v28
	local v_u_30 = math.floor(v29) - 8
	local v_u_31 = v14 and 54 or 62
	local function v_u_82(p32, p_u_33, p_u_34, p35) -- name: tile
		-- upvalues: (copy) v_u_12, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6, (copy) v_u_31, (copy) v_u_30, (copy) v_u_24, (copy) v_u_11
		local v36 = p_u_34.badges
		local v_u_37
		if type(v36) == "table" then
			local v38 = p_u_34.badges[p_u_33.id]
			v_u_37 = tonumber(v38) or nil
		else
			v_u_37 = nil
		end
		local v_u_39 = v_u_37 ~= nil
		local v_u_40
		if v_u_39 then
			v_u_40 = v_u_12.tierColor(v_u_7, p_u_33.tier)
		else
			v_u_40 = v_u_8.muted
		end
		local v41 = v_u_6.new
		local v42 = "TextButton"
		local v43 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["ClipsDescendants"] = true,
			["Name"] = p_u_33.id
		}
		local v44
		if v_u_39 then
			v44 = v_u_8.raised
		else
			v44 = v_u_8.bg
		end
		v43.BackgroundColor3 = v44
		v43.BackgroundTransparency = v_u_39 and 0.1 or 0.35
		v43.LayoutOrder = p35
		local v45 = v41(v42, v43, p32)
		v45.SelectionImageObject = v_u_6.selectionImage()
		local v46 = v_u_6.stroke
		local v47
		if v_u_39 then
			v47 = v_u_40
		else
			v47 = v_u_8.line
		end
		v46(v45, v47, 1, v_u_39 and 0.45 or 0)
		if v_u_39 then
			v_u_6.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_40,
				["Size"] = UDim2.new(0, 3, 1, 0)
			}, v45)
		end
		local v48 = v_u_12.emblem(v_u_6, v_u_7, p_u_33, v_u_31, v_u_39)
		v48.AnchorPoint = Vector2.new(0, 0.5)
		v48.Position = UDim2.new(0, 10, 0.5, 0)
		v48.Parent = v45
		local v49 = v_u_31 + 20
		local v50 = v_u_30 - v49 - 12
		local v51 = v_u_6.label
		local v52 = {
			["parent"] = nil,
			["name"] = "Name",
			["text"] = nil,
			["style"] = "h3",
			["textSize"] = 16,
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v45,
			["text"] = p_u_33.name
		}
		local v53
		if v_u_39 then
			v53 = v_u_8.text
		else
			v53 = v_u_8.text2
		end
		v52.color = v53
		v52.position = UDim2.fromOffset(v49, 10)
		v52.size = UDim2.fromOffset(v50, 20)
		v51(v52)
		local v54 = v_u_6.label
		local v55 = {
			["parent"] = nil,
			["name"] = "Desc",
			["text"] = nil,
			["style"] = "small",
			["textSize"] = 12,
			["color"] = nil,
			["wrap"] = true,
			["valign"] = "top",
			["position"] = nil,
			["size"] = nil,
			["parent"] = v45,
			["text"] = p_u_33.desc
		}
		local v56
		if v_u_39 then
			v56 = v_u_8.text2
		else
			v56 = v_u_8.muted
		end
		v55.color = v56
		v55.position = UDim2.fromOffset(v49, 32)
		v55.size = UDim2.fromOffset(v50, 30)
		v54(v55).TextTruncate = Enum.TextTruncate.AtEnd
		local v57 = v_u_24 - 26
		if v_u_39 then
			local v58 = v_u_6.label
			local v59 = {
				["parent"] = nil,
				["name"] = "State",
				["text"] = nil,
				["style"] = "monoS",
				["textSize"] = 11,
				["color"] = nil,
				["position"] = nil,
				["size"] = nil,
				["track"] = false,
				["parent"] = v45
			}
			local v60 = os.date
			local v61, v62 = pcall(v60, "%d %b %Y", v_u_37)
			v59.text = "Earned " .. ((not v61 or type(v62) ~= "string") and "" or string.upper(v62))
			v59.color = v_u_40
			v59.position = UDim2.fromOffset(v49, v57)
			v59.size = UDim2.fromOffset(v50 - 44, 16)
			v58(v59)
			if os.time() - v_u_37 < 86400 then
				v_u_6.badge("NEW", "accent", {
					["parent"] = nil,
					["name"] = "New",
					["anchor"] = nil,
					["position"] = nil,
					["height"] = 16,
					["parent"] = v45,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, -8, 0, v57 - 1)
				})
			end
		else
			local v63, v64 = v_u_11.progress(p_u_33, p_u_34)
			if v63 == nil or (v64 == nil or v_u_11.isSingleStep(p_u_33, p_u_34)) then
				v_u_6.label({
					["parent"] = nil,
					["name"] = "State",
					["text"] = "Not earned yet",
					["style"] = "micro",
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = v45,
					["color"] = v_u_8.muted,
					["position"] = UDim2.fromOffset(v49, v57),
					["size"] = UDim2.fromOffset(v50 - 56, 16)
				})
			else
				local v65 = v_u_6.progress
				local v66 = {
					["parent"] = v45
				}
				local v67 = v63 / math.max(1, v64)
				v66.value = math.clamp(v67, 0, 1)
				v66.color = v_u_8.text2
				v66.size = UDim2.fromOffset(v50, 3)
				v66.position = UDim2.fromOffset(v49, v57 - 4)
				v65(v66)
				v_u_6.label({
					["parent"] = nil,
					["name"] = "State",
					["text"] = nil,
					["style"] = "monoS",
					["textSize"] = 11,
					["color"] = nil,
					["position"] = nil,
					["size"] = nil,
					["track"] = false,
					["parent"] = v45,
					["text"] = v_u_11.progressText(p_u_33, p_u_34) or "",
					["color"] = v_u_8.text2,
					["position"] = UDim2.fromOffset(v49, v57 + 2),
					["size"] = UDim2.fromOffset(v50, 16)
				})
			end
			if p_u_33.how then
				v_u_6.badge("HOW TO", "muted", {
					["parent"] = nil,
					["name"] = "How",
					["anchor"] = nil,
					["position"] = nil,
					["height"] = 16,
					["parent"] = v45,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, -8, 0, v57 - 1)
				})
			end
		end
		v_u_6.tooltip(v45, function()
			-- upvalues: (ref) v_u_12, (copy) p_u_33, (copy) v_u_39, (copy) v_u_37, (ref) v_u_11, (copy) p_u_34, (copy) v_u_40
			local v68 = {}
			local v69 = {
				["label"] = "Tier",
				["value"] = nil
			}
			local v70 = v_u_12.TIER_NAMES
			local v71 = p_u_33.tier
			v69.value = v70[math.clamp(v71, 1, 4)]
			__set_list(v68, 1, {v69})
			if v_u_39 then
				local v72 = {
					["label"] = "Earned",
					["value"] = nil
				}
				local v73 = v_u_37
				local v74 = os.date
				local v75, v76 = pcall(v74, "%d %b %Y", v73)
				v72.value = (not v75 or type(v76) ~= "string") and "" or string.upper(v76)
				table.insert(v68, v72)
			else
				local v77
				if v_u_11.isSingleStep(p_u_33, p_u_34) then
					v77 = nil
				else
					v77 = v_u_11.progressText(p_u_33, p_u_34)
				end
				table.insert(v68, {
					["label"] = "Progress",
					["value"] = nil,
					["value"] = v77 or "Not earned yet"
				})
				if p_u_33.exitsAll then
					local v78 = v_u_11.exitsMissing(p_u_34)
					if #v78 > 0 then
						local v79 = {
							["label"] = "Missing",
							["value"] = nil,
							["value"] = table.concat(v78, ", ")
						}
						table.insert(v68, v79)
					end
				end
			end
			local v80 = {
				["title"] = string.upper(p_u_33.name)
			}
			local v81
			if p_u_33.how then
				v81 = p_u_33.desc .. "\n" .. p_u_33.how
			else
				v81 = p_u_33.desc
			end
			v80.body = v81
			v80.lines = v68
			v80.color = v_u_40
			return v80
		end)
	end
	function v_u_15.draw() -- name: draw
		-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_9, (copy) p_u_4, (copy) v_u_11, (copy) v_u_19, (copy) v_u_13, (ref) v_u_16, (copy) v_u_30, (copy) v_u_24, (copy) v_u_82
		v_u_6.keepScroll(v_u_23, function()
			-- upvalues: (ref) v_u_9, (ref) v_u_23, (ref) p_u_4, (ref) v_u_11, (ref) v_u_19, (ref) v_u_13, (ref) v_u_16, (ref) v_u_6, (ref) v_u_30, (ref) v_u_24, (ref) v_u_82
			v_u_9.clear(v_u_23)
			local v83 = p_u_4.profile
			local v84 = type(v83) ~= "table" and {} or p_u_4.profile
			local v85 = v84.badges
			local v86 = type(v85) ~= "table" and {} or v84.badges
			local v87 = 0
			for _, v88 in v_u_11.list do
				if v86[v88.id] == nil then
					continue
				end
				v87 = v87 + 1
			end
			v_u_19.Text = ("%d / %d EARNED"):format(v87, #v_u_11.list)
			v_u_13:SetAttribute("MenuBadges", ("%d/%d"):format(v87, #v_u_11.list))
			local v89 = 0
			local v90 = false
			for v91, v92 in v_u_11.GROUPS do
				local v93 = 0
				local v94 = 0
				local v95 = {}
				for _, v96 in v_u_11.list do
					if v96.group ~= v92.id then
						continue
					end
					v93 = v93 + 1
					local v97 = v86[v96.id] ~= nil
					if v97 then
						v94 = v94 + 1
					end
					if v_u_16 ~= "all" and (v_u_16 ~= "earned" or not v97) and (v_u_16 ~= "locked" or v97) then
						continue
					end
					table.insert(v95, v96)
				end
				if #v95 <= 0 then
					break
				end
				table.sort(v95, function(p98, p99)
					return p98.order < p99.order
				end)
				v89 = v89 + 1
				local v100 = v_u_6.new("Frame", {
					["Name"] = nil,
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = nil,
					["Name"] = "Group_" .. v92.id,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["LayoutOrder"] = v91
				}, v_u_23)
				v_u_6.layout(v100, "v", 8)
				v_u_9.section(v100, v92.name, 1, ("%d / %d"):format(v94, v93))
				local v101 = v_u_6.new("Frame", {
					["Name"] = "Grid",
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y
				}, v100)
				v_u_6.new("UIGridLayout", {
					["CellSize"] = UDim2.fromOffset(v_u_30, v_u_24),
					["CellPadding"] = UDim2.fromOffset(8, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder
				}, v101)
				v90 = true
				for v102, v103 in v95 do
					v_u_82(v101, v103, v84, v102)
				end
			end
			if not v90 then
				v_u_9.empty(v_u_23, v_u_16 == "earned" and "No badges earned yet. Extract, fight and explore to earn them." or "Every badge earned. Well done, survivor.", 1)
			end
		end)
	end
	function v_u_15.show() -- name: show
		-- upvalues: (copy) v_u_15
		v_u_15.draw()
	end
	function v_u_15.hide() -- name: hide end
	function v_u_15.refresh(p104) -- name: refresh
		-- upvalues: (copy) v_u_15
		if p104 == "profile" then
			v_u_15.draw()
		end
	end
	function v_u_15.destroy() -- name: destroy end
	return v_u_15
end
return v2