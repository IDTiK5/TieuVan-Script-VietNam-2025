-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuStoreGuard

local v1 = {}
local v_u_2 = utf8.char(57346)
function v1.new(p_u_3, p_u_4) -- name: new
	-- upvalues: (copy) v_u_2
	local v_u_5 = p_u_3.ui
	local v6 = p_u_3.theme
	local v_u_7 = v6.color
	local v_u_8 = v6.isPhone()
	local v9 = {}
	local v_u_10 = p_u_3.cctx.shared.ConnGuard
	function v9.youHave(p11) -- name: youHave
		local v12 = 0
		local v13
		if p11 then
			v13 = p11.free
		else
			v13 = p11
		end
		local v14 = tonumber(v13) or 0
		local v15 = math.floor(v14)
		local v16 = math.max(v12, v15)
		local v17 = 0
		if p11 then
			p11 = p11.extra
		end
		local v18 = tonumber(p11) or 0
		local v19 = math.floor(v18)
		return ("You have: %d free today, %d extra"):format(v16, (math.max(v17, v19)))
	end
	local v_u_20 = v_u_8 and 56 or 84
	local v21 = v6.touch(40)
	local v_u_22 = v_u_20 + 78 + v21
	local function v_u_69(p23, p_u_24, p25, p26, p27) -- name: tile
		-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_20, (copy) p_u_4, (ref) v_u_2, (copy) v_u_10
		local v28 = p_u_24.tag ~= nil
		local v29 = v_u_5.new
		local v30 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil
		}
		local v31 = p_u_24.id
		v30.Name = "Guard_" .. tostring(v31)
		v30.BackgroundColor3 = v_u_7.raised
		v30.LayoutOrder = p27
		v30.Size = UDim2.fromOffset(p25, p26)
		local v32 = v29("Frame", v30, p23)
		local v33 = v_u_5.stroke
		local v34
		if v28 then
			v34 = v_u_7.accent
		else
			v34 = v_u_7.lineStrong
		end
		v33(v32, v34, 1, v28 and 0.1 or 0.3)
		local v35 = v_u_5.new
		local v36 = "Frame"
		local v37 = {
			["Name"] = "Accent",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil
		}
		local v38
		if v28 then
			v38 = v_u_7.accent
		else
			v38 = v_u_7.info
		end
		v37.BackgroundColor3 = v38
		v37.Size = UDim2.new(1, 0, 0, 2)
		v35(v36, v37, v32)
		local v39 = p_u_24.grants
		if v39 then
			v39 = p_u_24.grants.guard
		end
		local v_u_40 = tonumber(v39) or 0
		local v41 = v_u_20
		local v42
		if p_u_4.icon then
			local v43 = p_u_4.icon
			local v44 = p_u_24.id
			v42 = v43((tostring(v44)))
		else
			v42 = nil
		end
		if v42 then
			local v45 = v_u_5.new("ImageLabel", {
				["Name"] = "GuardIcon",
				["BackgroundTransparency"] = 1,
				["Image"] = nil,
				["ScaleType"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = v42,
				["ScaleType"] = Enum.ScaleType.Fit,
				["Position"] = UDim2.fromOffset(8, 8),
				["Size"] = UDim2.fromOffset(v41, v41)
			}, v32)
			local v46 = p_u_24.id
			v45:SetAttribute("Source", "art/store_icons/" .. tostring(v46) .. ".png")
		else
			local v47 = v_u_5.icon
			local v48 = "shield"
			local v49 = {
				["size"] = nil,
				["color"] = nil,
				["thickness"] = 3
			}
			local v50 = v41 * 0.6
			v49.size = math.floor(v50)
			local v51
			if v28 then
				v51 = v_u_7.accent
			else
				v51 = v_u_7.info
			end
			v49.color = v51
			local v52 = v47(v48, v49)
			v52.Position = UDim2.fromOffset(14, 14)
			v52.Parent = v32
		end
		local v53 = v41 + 8 + 8
		local v54 = v_u_5.label
		local v55 = {
			["parent"] = nil,
			["name"] = "Count",
			["text"] = nil,
			["style"] = "h2",
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v32,
			["text"] = "+" .. tostring(v_u_40),
			["position"] = UDim2.fromOffset(v53, 10)
		}
		local v56 = UDim2.fromOffset
		local v57 = p25 - v53 - 8
		v55.size = v56(math.max(40, v57), 28)
		v54(v55)
		local v58 = v_u_5.label
		local v59 = {
			["parent"] = nil,
			["name"] = "Unit",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v32,
			["text"] = v_u_40 == 1 and "extra charge" or "extra charges",
			["color"] = v_u_7.text2,
			["position"] = UDim2.fromOffset(v53, 40)
		}
		local v60 = UDim2.fromOffset
		local v61 = p25 - v53 - 8
		v59.size = v60(math.max(40, v61), 16)
		v58(v59)
		if p_u_24.tag then
			local v62 = v_u_5.badge
			local v63 = p_u_24.tag
			v62(tostring(v63), "accent", {
				["parent"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["height"] = 16,
				["parent"] = v32,
				["anchor"] = Vector2.new(1, 0),
				["position"] = UDim2.new(1, -8, 0, 10)
			})
		end
		local v_u_64 = v_u_5.label({
			["parent"] = nil,
			["name"] = "PerCharge",
			["text"] = "",
			["style"] = "micro",
			["color"] = nil,
			["rich"] = true,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v32,
			["color"] = v_u_7.muted,
			["position"] = UDim2.fromOffset(12, v_u_20 + 14),
			["size"] = UDim2.new(1, -24, 0, 14)
		})
		local v65 = p_u_24.price
		local v66 = tonumber(v65)
		if v66 and v_u_40 > 0 then
			v_u_64.Text = ("<font face=\"GothamBold\">%s</font> %.1f per charge"):format(v_u_2, v66 / v_u_40)
		else
			v_u_64.Text = ""
		end
		p_u_4.onPrice(p_u_24, function()
			-- upvalues: (copy) v_u_64, (copy) p_u_24, (copy) v_u_40, (ref) v_u_2
			if v_u_64.Parent then
				local v67 = p_u_24.price
				local v68 = tonumber(v67)
				if v68 and v_u_40 > 0 then
					v_u_64.Text = ("<font face=\"GothamBold\">%s</font> %.1f per charge"):format(v_u_2, v68 / v_u_40)
					return
				end
				v_u_64.Text = ""
			end
		end)
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Rules",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v32,
			["text"] = v_u_10.PACK_LINE,
			["color"] = v_u_7.text2,
			["position"] = UDim2.fromOffset(12, v_u_20 + 32),
			["size"] = UDim2.new(1, -24, 0, 36)
		}).TextYAlignment = Enum.TextYAlignment.Top
		p_u_4.buy(v32, p_u_24, UDim2.new(0.5, 0, 1, -10), Vector2.new(0.5, 1), p25 - 24)
		return v32
	end
	function v9.build(p70, p71, p72, p73, p74) -- name: build
		-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_7, (copy) v_u_22, (copy) v_u_69, (copy) p_u_3, (copy) v_u_10
		local v75 = p73 - 28
		local v76 = #p71
		local v77 = math.min(3, v76)
		local v78 = math.max(1, v77)
		local v79 = (v75 - (v78 - 1) * 10) / v78
		local v80 = math.floor(v79)
		local v81 = v_u_8 and 52 or 50
		local v82 = v_u_5.new("Frame", {
			["Name"] = "GuardGroup",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundColor3"] = v_u_7.raised,
			["LayoutOrder"] = p74,
			["Size"] = UDim2.fromOffset(p73, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, p70)
		v_u_5.stroke(v82, v_u_7.line, 1, 0.3)
		v_u_5.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 14),
			["PaddingRight"] = UDim.new(0, 14),
			["PaddingTop"] = UDim.new(0, 10),
			["PaddingBottom"] = UDim.new(0, 12)
		}, v82)
		v_u_5.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Vertical,
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 10)
		}, v82).HorizontalAlignment = Enum.HorizontalAlignment.Left
		local v83 = v_u_5.new("Frame", {
			["Name"] = "Head",
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = 1,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v75, v81 - 10)
		}, v82)
		local v84 = v_u_5.label
		local v85 = {
			["parent"] = nil,
			["name"] = "Title",
			["text"] = "CONNECTION GUARD",
			["style"] = "h3",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83,
			["position"] = UDim2.fromOffset(0, 0)
		}
		local v86 = UDim2.fromOffset
		local v87 = v75 * 0.5
		v85.size = v86(math.floor(v87), 22)
		v84(v85)
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Blurb",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83,
			["text"] = v_u_8 and "A charge keeps your gear if your connection drops." or "A charge keeps what you brought into the raid if your connection drops.",
			["color"] = v_u_7.text2,
			["position"] = UDim2.fromOffset(0, 24),
			["size"] = UDim2.fromOffset(v75, 16)
		})
		local v88 = v_u_5.label
		local v89 = {
			["parent"] = nil,
			["name"] = "YouHave",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["align"] = "right",
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["parent"] = v83
		}
		local v90 = 0
		local v91
		if p72 then
			v91 = p72.free
		else
			v91 = p72
		end
		local v92 = tonumber(v91) or 0
		local v93 = math.floor(v92)
		local v94 = math.max(v90, v93)
		local v95 = 0
		local v96
		if p72 then
			v96 = p72.extra
		else
			v96 = p72
		end
		local v97 = tonumber(v96) or 0
		local v98 = math.floor(v97)
		v89.text = ("You have: %d free today, %d extra"):format(v94, (math.max(v95, v98)))
		v89.color = v_u_7.accent
		v89.position = UDim2.new(1, 0, 0, 2)
		local v99 = UDim2.fromOffset
		local v100 = v75 * 0.5
		v89.size = v99(math.floor(v100), 18)
		local v101 = v88(v89)
		v101.AnchorPoint = Vector2.new(1, 0)
		if v_u_8 then
			v101.TextTruncate = Enum.TextTruncate.AtEnd
		end
		local v102 = v_u_5.new("Frame", {
			["Name"] = "Tiles",
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = 2,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(v75, v_u_22)
		}, v82)
		for v103, v104 in p71 do
			v_u_69(v102, v104, v80, v_u_22, v103).Position = UDim2.fromOffset((v103 - 1) * (v80 + 10), 0)
		end
		local v105 = v_u_5.new("Frame", {
			["Name"] = "Warn",
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = 3,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.fromOffset(v75, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y
		}, v82)
		v_u_5.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Vertical,
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Padding"] = UDim.new(0, 4)
		}, v105)
		local v106 = {}
		local v_u_107 = false
		local function v108()
			-- upvalues: (ref) v_u_107, (ref) p_u_3
			v_u_107 = p_u_3.cctx.shared.GameMode.rule("pvp") == true
		end
		pcall(v108)
		for _, v109 in v_u_10.refusalCases(v_u_107) do
			local v110 = "\226\128\162 " .. v109.text
			table.insert(v106, v110)
		end
		v_u_5.label({
			["parent"] = nil,
			["name"] = "WarnTitle",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["rich"] = true,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v105,
			["text"] = "<b>" .. v_u_10.WARN_TITLE .. "</b>",
			["color"] = v_u_7.accent
		}).LayoutOrder = 1
		local v111 = {}
		for _, v112 in v106 do
			local v113 = string.gsub(v112, "&", "&amp;")
			local v114 = string.gsub(v113, "<", "&lt;")
			local v115 = string.gsub(v114, ">", "&gt;")
			table.insert(v111, v115)
		end
		local v116 = v_u_5.label({
			["parent"] = nil,
			["name"] = "WarnCases",
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["rich"] = true,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v105,
			["text"] = "<b>" .. table.concat(v111, "\n") .. "</b>",
			["color"] = v_u_7.text
		})
		v116.LayoutOrder = 2
		v116.TextYAlignment = Enum.TextYAlignment.Top
		if p72 then
			p72 = p72.cap
		end
		local v117 = tonumber(p72) or 99
		local v118 = math.floor(v117)
		v_u_5.label({
			["parent"] = nil,
			["name"] = "Fine",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["track"] = false,
			["parent"] = v82,
			["text"] = ("Free charges are used first. Extra charges never expire. You can hold up to %d."):format(v118),
			["color"] = v_u_7.muted
		}).LayoutOrder = 4
		return v82
	end
	return v9
end
return v1