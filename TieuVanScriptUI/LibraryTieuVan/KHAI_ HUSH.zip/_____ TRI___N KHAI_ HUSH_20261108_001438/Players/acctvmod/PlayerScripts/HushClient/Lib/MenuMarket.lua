-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuMarket

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
local v_u_6 = {
	{
		["id"] = "browse",
		["text"] = "Browse"
	},
	{
		["id"] = "crates",
		["text"] = "Crates"
	},
	{
		["id"] = "sell",
		["text"] = "Sell"
	},
	{
		["id"] = "mine",
		["text"] = "My listings"
	}
}
local v_u_7 = {
	["sub"] = "browse"
}
v_u_4.MEMORY = v_u_7
function v_u_4.new(p_u_8, p_u_9) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_2
	local v_u_10 = p_u_8.ui
	local v_u_11 = p_u_8.theme
	local v_u_12 = v_u_11.color
	local v_u_13 = p_u_8.kit
	local v_u_14 = p_u_8.compact()
	local v_u_15 = v_u_11.isPhone()
	local v_u_16 = {}
	local v_u_17 = "MenuMarketData"
	local v18, v_u_19 = pcall(function()
		-- upvalues: (copy) p_u_8, (copy) v_u_17
		return p_u_8.cctx.lib[v_u_17]
	end)
	if not v18 or type(v_u_19) ~= "table" then
		warn("[MenuMarket] lib missing:", "MenuMarketData", v_u_19)
		v_u_19 = nil
	end
	local v_u_20 = table.clone(v_u_6)
	local v_u_21 = false
	local v22, v23 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.cctx.lib.MenuMarketCrates
	end)
	local v_u_24 = v22
	if v_u_24 then
		if type(v23) == "table" then
			local v25 = v23.new
			if type(v25) == "function" and type(v_u_19) == "table" then
				local v26 = v_u_19.crateTab
				v_u_24 = type(v26) == "function"
			else
				v_u_24 = false
			end
		else
			v_u_24 = false
		end
	end
	if not v_u_24 then
		for v27 = #v_u_20, 1, -1 do
			if v_u_20[v27].id ~= "crates" then
				continue
			end
			table.remove(v_u_20, v27)
		end
	end
	local v28, v29 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.cctx.lib.MenuMarketMine
	end)
	local v30, v31 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.cctx.config.flag("BuyOrders")
	end)
	if v28 and type(v29) == "table" then
		local v32 = v29.newOrders
		if type(v32) == "function" and (not v30 or v31 ~= false) then
			table.insert(v_u_20, {
				["id"] = "orders",
				["text"] = nil,
				["text"] = v_u_14 and "Orders" or "My orders"
			})
			v_u_21 = true
		end
	end
	local v_u_33 = nil
	local v_u_34 = nil
	local v35, v36 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.cctx.lib.MenuMarketTrade
	end)
	local function v37()
		-- upvalues: (ref) v_u_33, (copy) p_u_8, (ref) v_u_34
		v_u_33 = p_u_8.cctx.controllers.TradeNotes
		v_u_34 = p_u_8.cctx.shared.TradeView
	end
	pcall(v37)
	local v_u_38 = v35
	if v_u_38 then
		if type(v36) == "table" then
			local v39 = v36.new
			if type(v39) == "function" then
				local v40 = v_u_33
				if type(v40) == "table" then
					local v41 = v_u_34
					v_u_38 = type(v41) == "table"
				else
					v_u_38 = false
				end
			else
				v_u_38 = false
			end
		else
			v_u_38 = false
		end
	end
	if v_u_38 then
		table.insert(v_u_20, {
			["id"] = "trade",
			["text"] = "Trade"
		})
	end
	local v42 = game:GetService("RunService"):IsStudio()
	if v42 then
		v42 = v_u_5:GetAttribute("BmUiFake") == true
	end
	local v_u_43 = v_u_19.new(p_u_8, {
		["fake"] = v42
	})
	local v_u_44 = v_u_43.rules
	local v_u_45 = true
	local v_u_46 = false
	local v47 = v_u_7.sub
	local v48 = v47 == "orders" and not v_u_21 and "browse" or v47
	local v49 = v48 == "crates" and not v_u_24 and "browse" or v48
	local function v_u_52() -- name: tradeTabOn
		-- upvalues: (ref) v_u_38, (copy) p_u_8, (ref) v_u_34, (ref) v_u_5, (ref) v_u_33
		if not v_u_38 then
			return false
		end
		local v_u_50 = nil
		local function v51()
			-- upvalues: (ref) v_u_50, (ref) p_u_8
			v_u_50 = p_u_8.cctx.config.flag("Trade")
		end
		pcall(v51)
		return v_u_34.tabOn({
			["module"] = true,
			["flag"] = nil,
			["paid"] = nil,
			["tab"] = nil,
			["flag"] = v_u_50,
			["paid"] = v_u_5:GetAttribute("PaidTrading") == true,
			["tab"] = v_u_33.tabState()
		})
	end
	local v_u_53 = v49 == "trade" and not v_u_52() and "browse" or v49
	local v_u_54 = {}
	local v_u_55 = {}
	local v_u_56 = 0
	local v_u_57 = nil
	local v_u_58 = nil
	local v_u_59 = {
		["mc"] = nil,
		["ui"] = nil,
		["theme"] = nil,
		["C"] = nil,
		["kit"] = nil,
		["data"] = nil,
		["rules"] = nil,
		["compact"] = nil,
		["phone"] = nil,
		["Data"] = nil,
		["state"] = nil,
		["fake"] = nil,
		["mc"] = p_u_8,
		["ui"] = v_u_10,
		["theme"] = v_u_11,
		["C"] = v_u_12,
		["kit"] = v_u_13,
		["data"] = v_u_43,
		["rules"] = v_u_44,
		["compact"] = v_u_14,
		["phone"] = v_u_15,
		["Data"] = v_u_19,
		["fake"] = v_u_43.fake,
		["player"] = v_u_5
	}
	v_u_16.ctx = v_u_59
	v_u_16.data = v_u_43
	v_u_16.api = v_u_59
	local v_u_60 = {}
	v_u_59.h = v_u_60
	function v_u_60.scale(p_u_61) -- name: scale
		-- upvalues: (copy) v_u_10, (copy) v_u_11
		local function v62()
			-- upvalues: (ref) v_u_10, (copy) p_u_61
			return v_u_10.pointer().scaleOf(p_u_61)
		end
		local v63, v64 = pcall(v62)
		if v63 and (type(v64) == "number" and v64 > 0) then
			return v64
		else
			return v_u_11.uiScale()
		end
	end
	function v_u_60.designSize(p65, p66) -- name: designSize
		-- upvalues: (copy) v_u_11, (copy) v_u_60
		local v67 = p65.AbsoluteSize
		if p66 and p65:IsA("ScrollingFrame") then
			v67 = p65.AbsoluteWindowSize
		end
		local v68 = p65:FindFirstAncestorWhichIsA("LayerCollector")
		if v68 then
			v68 = v68:FindFirstChild("Root")
		end
		local v69 = v_u_11.safeRefSize()
		if v68 and (v68:IsA("GuiObject") and (v68.AbsoluteSize.X > 40 and (v68.AbsoluteSize.Y > 40 and v67.X > 0))) then
			return Vector2.new(v67.X / v68.AbsoluteSize.X * v69.X, v67.Y / v68.AbsoluteSize.Y * v69.Y)
		end
		local v70 = v_u_60.scale(p65)
		return Vector2.new(v67.X / v70, v67.Y / v70)
	end
	function v_u_60.money(p71) -- name: money
		-- upvalues: (copy) v_u_19
		return v_u_19.money(p71)
	end
	function v_u_60.text(p72, p73) -- name: text
		-- upvalues: (copy) v_u_19, (copy) v_u_44
		return v_u_19.text(v_u_44, p72, p73)
	end
	function v_u_60.item(p74) -- name: item
		-- upvalues: (copy) v_u_13
		return v_u_13.itemDef(p74)
	end
	function v_u_60.name(p75) -- name: name
		-- upvalues: (copy) v_u_13
		return v_u_13.itemName(p75)
	end
	function v_u_60.now() -- name: now
		-- upvalues: (copy) v_u_43
		return v_u_43:clock()
	end
	function v_u_60.serverNow() -- name: serverNow
		-- upvalues: (copy) v_u_19, (copy) v_u_59, (copy) v_u_43
		return v_u_19.serverNow(v_u_59.state, v_u_43:clock())
	end
	function v_u_60.button(p76, p77, p78, p79, p80) -- name: button
		-- upvalues: (copy) v_u_10, (copy) v_u_11
		local v81 = p80 or {}
		local v82, v83 = v_u_10.button({
			["parent"] = p76,
			["text"] = p77,
			["kind"] = p78 or "secondary",
			["height"] = v81.height or v_u_11.control,
			["width"] = v81.width,
			["size"] = v81.size,
			["position"] = v81.position,
			["anchor"] = v81.anchor,
			["order"] = v81.order,
			["onClick"] = p79,
			["disabled"] = v81.disabled,
			["name"] = v81.name,
			["maxTextWidth"] = v81.maxTextWidth,
			["icon"] = v81.icon,
			["zindex"] = v81.zindex,
			["onDisabledClick"] = v81.onDisabledClick
		})
		return v82, v83
	end
	function v_u_60.pill(p84, p85, p86, p87) -- name: pill
		-- upvalues: (copy) v_u_10, (copy) v_u_12
		local v88 = p87 or {}
		local v89 = v_u_10.new
		local v90 = "Frame"
		local v91 = {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["ZIndex"] = nil,
			["Name"] = v88.name or "Pill"
		}
		local v92
		if v88.solid then
			v92 = p86
		else
			v92 = v_u_12.bgDeep
		end
		v91.BackgroundColor3 = v92
		v91.BackgroundTransparency = v88.solid and 0 or 0.2
		v91.AutomaticSize = Enum.AutomaticSize.X
		v91.Size = UDim2.fromOffset(0, v88.h or 18)
		v91.LayoutOrder = v88.order or 0
		v91.Position = v88.position or UDim2.new()
		v91.AnchorPoint = v88.anchor or Vector2.zero
		v91.ZIndex = v88.zindex or 2
		local v93 = v89(v90, v91)
		if not v88.solid then
			v_u_10.stroke(v93, p86, 1, 0.3)
		end
		v_u_10.pad(v93, {
			6,
			6,
			0,
			0
		})
		local v94 = v_u_10.label
		local v95 = {
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "micro",
			["color"] = nil,
			["autoX"] = true,
			["size"] = nil,
			["track"] = false,
			["zindex"] = nil,
			["parent"] = v93,
			["text"] = p85
		}
		if v88.solid then
			p86 = v_u_12.bgDeep
		end
		v95.color = p86
		v95.size = UDim2.fromOffset(0, v88.h or 18)
		v95.zindex = (v88.zindex or 2) + 1
		v94(v95)
		if p84 then
			v93.Parent = p84
		end
		return v93
	end
	local v_u_96 = nil
	local function v97()
		-- upvalues: (ref) v_u_96, (copy) p_u_8
		v_u_96 = p_u_8.cctx.shared.PaidBadge
	end
	pcall(v97)
	local v_u_98 = v_u_11.cond.time
	function v_u_60.paidOf(p99) -- name: paidOf
		-- upvalues: (ref) v_u_96
		return v_u_96 == nil and {
			["paid"] = false,
			["insurable"] = true
		} or v_u_96.fromFlag(p99)
	end
	function v_u_60.paidOfInst(p100, p101) -- name: paidOfInst
		-- upvalues: (ref) v_u_96
		return v_u_96 == nil and {
			["paid"] = false,
			["insurable"] = true
		} or v_u_96.paidInfo(p100, p101)
	end
	function v_u_60.paidPill(p102, p103, p104) -- name: paidPill
		-- upvalues: (ref) v_u_96, (copy) v_u_60, (copy) v_u_98
		if v_u_96 == nil or (type(p103) ~= "table" or p103.paid ~= true) then
			return nil
		end
		local v105 = v_u_60.pill(p102, "", v_u_98, {
			["name"] = "PaidMark",
			["order"] = nil,
			["h"] = nil,
			["order"] = p104 and (p104.order or 0) or 0,
			["h"] = p104 and p104.h or 18
		})
		local v106 = v105:FindFirstChild("Text")
		if v106 then
			v106.RichText = true
			v106.Text = v_u_96.rich(p103)
		end
		v105:SetAttribute("Paid", true)
		v105:SetAttribute("Insurable", p103.insurable == true)
		return v105
	end
	function v_u_60.icon(p107, p108, p109, p110) -- name: icon
		-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_13, (copy) v_u_11, (copy) p_u_8
		local v111 = p110 or {}
		local v112 = v_u_10.new("Frame", {
			["Name"] = "IconBox",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.15,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["LayoutOrder"] = nil,
			["ClipsDescendants"] = true,
			["BackgroundColor3"] = v_u_12.raised,
			["Size"] = UDim2.fromOffset(p109, p109),
			["Position"] = v111.position or UDim2.new(),
			["AnchorPoint"] = v111.anchor or Vector2.zero,
			["LayoutOrder"] = v111.order or 0
		}, p107)
		local v113 = v_u_13.itemDef(p108)
		local v114 = v_u_10.new("Frame", {
			["Name"] = "Tint",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_11.rarityColor(not v113 and 1 or (v113.shown or v113.rarity)),
			["BackgroundTransparency"] = v_u_11.alpha.rarity,
			["Size"] = UDim2.fromScale(1, 1)
		}, v112)
		v_u_10.new("UIGradient", {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new(0.35, 0)
		}, v114)
		v_u_10.stroke(v112, v_u_11.rarityColor(not v113 and 1 or (v113.shown or v113.rarity)):Lerp(v_u_12.line, 0.55))
		local v115 = nil
		local v_u_116 = nil
		local function v117()
			-- upvalues: (ref) v_u_116, (ref) p_u_8
			v_u_116 = p_u_8.cctx.lib.ItemIcons
		end
		pcall(v117)
		local v_u_118
		if v_u_116 then
			local v119 = v_u_116.get
			local v120 = {
				["parent"] = nil,
				["size"] = nil,
				["position"] = nil,
				["zindex"] = 2,
				["parent"] = v112,
				["size"] = UDim2.new(1, -6, 1, -6),
				["position"] = UDim2.fromOffset(3, 3)
			}
			local v121
			v121, v_u_118 = pcall(v119, p108, false, v120)
			if not v121 or typeof(v_u_118) ~= "Instance" then
				v_u_118 = v115
			end
		else
			v_u_118 = v115
		end
		if not v_u_118 then
			local v122 = v_u_10.icon
			local v123 = {
				["parent"] = v112
			}
			local v124 = p109 * 0.4
			v123.size = math.floor(v124)
			v123.color = v_u_12.text2
			v123.position = UDim2.fromScale(0.5, 0.5)
			v123.anchor = Vector2.new(0.5, 0.5)
			v122("loot", v123)
		end
		return v112, function()
			-- upvalues: (ref) v_u_118, (ref) v_u_116
			if v_u_118 and v_u_116 then
				local v125 = v_u_116.release
				local v126 = v_u_118
				pcall(v125, v126)
				v_u_118 = nil
			end
		end
	end
	function v_u_60.condition(p127, p128, p129, p130) -- name: condition
		-- upvalues: (copy) v_u_10, (copy) v_u_12
		local v131 = p130 or {}
		local v132 = v_u_10.new("Frame", {
			["Name"] = "Condition",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.fromOffset(p129, v131.h or 16),
			["LayoutOrder"] = v131.order or 0
		}, p127)
		local v133
		if p128.kind == "good" then
			v133 = v_u_12.success
		elseif p128.kind == "worn" then
			v133 = v_u_12.accent
		else
			v133 = v_u_12.danger
		end
		local v134 = p129 - 56
		local v135 = math.max(24, v134)
		v_u_10.progress({
			["parent"] = v132,
			["size"] = UDim2.fromOffset(v135, 4),
			["position"] = UDim2.new(0, 0, 0.5, -2),
			["value"] = p128.pct / 100,
			["color"] = v133
		})
		local v136
		if p128.uses then
			v136 = ("%d of %d uses"):format(p128.uses.left, p128.uses.total)
		else
			v136 = ("%d%%"):format(p128.pct)
		end
		v_u_10.label({
			["parent"] = nil,
			["name"] = "Pct",
			["text"] = nil,
			["style"] = "monoS",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["track"] = false,
			["fit"] = true,
			["parent"] = v132,
			["text"] = v136,
			["color"] = v133,
			["position"] = UDim2.fromOffset(v135 + 6, 0),
			["size"] = UDim2.new(1, -(v135 + 6), 1, 0)
		})
		return v132
	end
	function v_u_60.toggleRow(p137, p138, p139, p_u_140, p141) -- name: toggleRow
		-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_11
		local v_u_142 = p139
		local v_u_143 = v_u_10.new("TextButton", {
			["Name"] = "Toggle",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.2,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Selectable"] = true,
			["BackgroundColor3"] = v_u_12.raised,
			["Size"] = UDim2.new(1, 0, 0, v_u_11.touch(40)),
			["LayoutOrder"] = p141 or 0
		}, p137)
		v_u_143.SelectionImageObject = v_u_10.selectionImage()
		local v144 = v_u_10.stroke
		local v145
		if v_u_142 then
			v145 = v_u_12.accent
		else
			v145 = v_u_12.line
		end
		local v_u_146 = v144(v_u_143, v145)
		local v147 = v_u_10.new("Frame", {
			["Name"] = "Box",
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 12, 0.5, 0),
			["Size"] = UDim2.fromOffset(16, 16)
		}, v_u_143)
		v_u_10.stroke(v147, v_u_12.lineStrong)
		local v_u_148 = v_u_10.new("Frame", {
			["Name"] = "On",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = nil,
			["BackgroundColor3"] = v_u_12.accent,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(8, 8),
			["Visible"] = v_u_142
		}, v147)
		local v149 = v_u_10.label
		local v150 = {
			["parent"] = nil,
			["name"] = "Text",
			["text"] = nil,
			["style"] = "body",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["fit"] = true,
			["track"] = false,
			["parent"] = v_u_143,
			["text"] = p138
		}
		local v151
		if v_u_142 then
			v151 = v_u_12.text
		else
			v151 = v_u_12.text2
		end
		v150.color = v151
		v150.position = UDim2.fromOffset(40, 0)
		v150.size = UDim2.new(1, -52, 1, 0)
		local v_u_152 = v149(v150)
		local v153 = {
			["btn"] = v_u_143
		}
		v_u_143.Activated:Connect(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_142, (copy) v_u_148, (copy) v_u_146, (ref) v_u_12, (copy) v_u_152, (copy) v_u_143, (copy) p_u_140
			v_u_10.sound(v_u_11.sounds.click)
			v_u_142 = not v_u_142
			v_u_148.Visible = v_u_142
			local v154 = v_u_146
			local v155
			if v_u_142 then
				v155 = v_u_12.accent
			else
				v155 = v_u_12.line
			end
			v154.Color = v155
			local v156 = v_u_152
			local v157
			if v_u_142 then
				v157 = v_u_12.text
			else
				v157 = v_u_12.text2
			end
			v156.TextColor3 = v157
			v_u_143:SetAttribute("On", v_u_142)
			p_u_140(v_u_142)
		end)
		function v153.set(p158) -- name: set
			-- upvalues: (ref) v_u_142, (copy) v_u_148, (copy) v_u_146, (ref) v_u_12, (copy) v_u_152, (copy) v_u_143
			v_u_142 = p158
			v_u_148.Visible = v_u_142
			local v159 = v_u_146
			local v160
			if v_u_142 then
				v160 = v_u_12.accent
			else
				v160 = v_u_12.line
			end
			v159.Color = v160
			local v161 = v_u_152
			local v162
			if v_u_142 then
				v162 = v_u_12.text
			else
				v162 = v_u_12.text2
			end
			v161.TextColor3 = v162
			v_u_143:SetAttribute("On", v_u_142)
		end
		function v153.get() -- name: get
			-- upvalues: (ref) v_u_142
			return v_u_142
		end
		v_u_148.Visible = v_u_142
		local v163
		if v_u_142 then
			v163 = v_u_12.accent
		else
			v163 = v_u_12.line
		end
		v_u_146.Color = v163
		local v164
		if v_u_142 then
			v164 = v_u_12.text
		else
			v164 = v_u_12.text2
		end
		v_u_152.TextColor3 = v164
		v_u_143:SetAttribute("On", v_u_142)
		return v153
	end
	function v_u_60.note(p165, p166, p167, p168) -- name: note
		-- upvalues: (copy) v_u_10, (copy) v_u_12
		return v_u_10.label({
			["parent"] = nil,
			["text"] = nil,
			["style"] = "small",
			["color"] = nil,
			["wrap"] = true,
			["autoY"] = true,
			["order"] = nil,
			["parent"] = p165,
			["text"] = p166,
			["color"] = p167 or v_u_12.text2,
			["order"] = p168 or 0
		})
	end
	function v_u_59.onTick(p169) -- name: onTick
		-- upvalues: (ref) v_u_56, (copy) v_u_55
		v_u_56 = v_u_56 + 1
		local v_u_170 = v_u_56
		v_u_55[v_u_170] = p169
		return function()
			-- upvalues: (ref) v_u_55, (copy) v_u_170
			v_u_55[v_u_170] = nil
		end
	end
	function v_u_59.isVisible() -- name: isVisible
		-- upvalues: (ref) v_u_46, (ref) v_u_45
		local v171 = v_u_46
		if v171 then
			v171 = v_u_45
		end
		return v171
	end
	function v_u_59.modalOpen() -- name: modalOpen
		-- upvalues: (copy) v_u_10
		local v172 = v_u_10.modalCount
		local v173, v174 = pcall(v172)
		if v173 then
			if type(v174) == "number" then
				v173 = v174 > 0
			else
				v173 = false
			end
		end
		return v173
	end
	function v_u_59.canList() -- name: canList
		-- upvalues: (copy) v_u_59, (copy) v_u_60, (copy) v_u_19, (copy) v_u_44
		local v175 = v_u_59.state
		if type(v175) ~= "table" or v175.ok == false then
			return false, v_u_60.text("STORE")
		end
		if v175.ds == "down" then
			return false, v_u_60.text("STORE")
		end
		local v176 = v_u_19.chip(v175, v_u_44)
		if v176.blocked then
			return false, v176.reason
		end
		local v177 = v175.can
		local v178 = type(v177) ~= "table" and {} or v175.can
		if v178.list ~= false then
			local v179 = v175.on
			if type(v179) ~= "table" or v175.on.scope ~= false then
				return true, nil
			end
		end
		local v180 = v178.why
		local v181 = v178.text
		local v182
		if type(v181) == "string" and v178.text ~= "" then
			v182 = v178.text
			return false, v182
		else
			if v180 == "SCOPE" then
				v182 = v_u_19.TEXT.scopeClosed
			else
				local v183 = v175.on
				if type(v183) ~= "table" or v175.on.scope ~= false then
					if v176.kind == "paused" then
						v182 = v176.reason
					elseif v176.kind == "closed" then
						v182 = v_u_19.TEXT.closed
					else
						v182 = v_u_60.text(v180 or "OFF_LIST")
					end
					return false, v182
				end
				v182 = v_u_19.TEXT.scopeClosed
			end
			return false, v182
		end
	end
	local v184
	if v_u_14 then
		v184 = UDim2.fromOffset(v_u_15 and 12 or 20, v_u_15 and 2 or 6)
	else
		v184 = UDim2.fromOffset(24, 8)
	end
	local v185
	if v_u_14 then
		v185 = UDim2.new(1, -(v_u_15 and 24 or 40), 1, -(v_u_15 and 2 or 6))
	else
		v185 = UDim2.new(1, -48, 1, -8)
	end
	local _, v186 = v_u_10.panel({
		["parent"] = nil,
		["name"] = "Market",
		["position"] = nil,
		["size"] = nil,
		["padding"] = 0,
		["parent"] = p_u_9,
		["position"] = v184,
		["size"] = v185
	})
	local v187 = v_u_14 and 10 or 16
	local v188 = v_u_14 and 32 or 56
	local v_u_189 = v_u_11.touch(40)
	local v_u_190 = v_u_14 and 4 or 8
	local v_u_191 = v_u_10.new("Frame", {
		["Name"] = "Inner",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}, v186)
	v_u_10.pad(v_u_191, {
		v187,
		v187,
		v_u_14 and 6 or 10,
		v_u_14 and 4 or 8
	})
	local v192 = v_u_10.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v188)
	}, v_u_191)
	v_u_10.label({
		["parent"] = nil,
		["name"] = "Title",
		["text"] = "Blackmarket",
		["style"] = nil,
		["textSize"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = v192,
		["style"] = v_u_14 and "h3" or "h1",
		["textSize"] = v_u_14 and 20 or 30,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(0.5, 0, 0, v_u_14 and 32 or 36)
	})
	if not v_u_14 then
		v_u_10.label({
			["parent"] = nil,
			["name"] = "Sub",
			["text"] = "Player market, Cash only",
			["style"] = "caps",
			["color"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = v192,
			["color"] = v_u_12.text2,
			["position"] = UDim2.fromOffset(0, 36),
			["size"] = UDim2.new(0.5, 0, 0, 16)
		})
	end
	v_u_60.pill(v192, "FAKE DATA", v_u_12.info, {
		["name"] = "FakeTag",
		["position"] = nil,
		["h"] = 18,
		["position"] = UDim2.new(0, v_u_14 and 150 or 230, 0, v_u_14 and 7 or 11)
	}).Visible = v_u_43.fake
	local v193 = v_u_10.new("Frame", {
		["Name"] = "ChipBox",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(v_u_14 and 0.62 or 0.5, 0, 1, 0)
	}, v192)
	local v194 = v_u_10.new
	local v195 = "Frame"
	local v196 = {
		["Name"] = "Chip",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_12.bgDeep,
		["AnchorPoint"] = Vector2.new(1, v_u_14 and 0.5 or 0)
	}
	local v197
	if v_u_14 then
		v197 = UDim2.new(1, 0, 0.5, 0)
	else
		v197 = UDim2.new(1, 0, 0, 4)
	end
	v196.Position = v197
	v196.Size = UDim2.fromOffset(v_u_14 and 84 or 104, v_u_14 and 24 or 28)
	local v198 = v194(v195, v196, v193)
	local v_u_199 = v_u_10.stroke(v198, v_u_12.line)
	local v_u_200 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "...",
		["style"] = "caps",
		["textSize"] = nil,
		["align"] = "center",
		["size"] = nil,
		["color"] = nil,
		["parent"] = v198,
		["textSize"] = v_u_14 and 13 or 15,
		["size"] = UDim2.fromScale(1, 1),
		["color"] = v_u_12.text2
	})
	local v201 = v_u_10.label
	local v202 = {
		["parent"] = nil,
		["name"] = "Reason",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["align"] = "right",
		["size"] = nil,
		["position"] = nil,
		["wrap"] = false,
		["track"] = false,
		["fit"] = nil,
		["parent"] = v193,
		["color"] = v_u_12.text2
	}
	local v203
	if v_u_14 then
		v203 = UDim2.new(1, -94, 1, 0)
	else
		v203 = UDim2.new(1, 0, 0, 18)
	end
	v202.size = v203
	local v204
	if v_u_14 then
		v204 = UDim2.fromOffset(0, 0)
	else
		v204 = UDim2.fromOffset(0, 36)
	end
	v202.position = v204
	v202.fit = v_u_14
	local v_u_205 = v201(v202)
	local v_u_206 = v188 + v_u_190
	local v_u_207 = v_u_10.new("Frame", {
		["Name"] = "RestockStripHost",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Position"] = UDim2.fromOffset(0, v_u_206),
		["Size"] = UDim2.new(1, 0, 0, 0)
	}, v_u_191)
	local v_u_208 = 0
	local v_u_209 = v_u_10.new("Frame", {
		["Name"] = "SubRow",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_206),
		["Size"] = UDim2.new(1, 0, 0, v_u_189)
	}, v_u_191)
	local function v_u_213() -- name: visibleSubs
		-- upvalues: (copy) v_u_20, (ref) v_u_24, (copy) v_u_19, (copy) v_u_59, (copy) v_u_52
		local v210 = {}
		for _, v211 in v_u_20 do
			if v211.id == "crates" then
				local v212 = v_u_24
				if v212 then
					v212 = v_u_19.crateTab(v_u_59.state)
				end
				if not v212 then
					continue
				end
			end
			if v211.id == "trade" and not v_u_52() then
				continue
			end
			table.insert(v210, v211)
		end
		return v210
	end
	local function v_u_220() -- name: computeTabsW
		-- upvalues: (copy) v_u_213, (copy) v_u_11
		local v214 = v_u_213()
		local v215 = 0
		for _, v216 in v214 do
			local v217 = v_u_11.touch(24)
			local v218 = #v216.text * 7.8
			local v219 = math.ceil(v218) + 8
			v215 = v215 + math.max(v217, v219)
		end
		return v215 + (#v214 - 1) * 24 + 16
	end
	local v_u_221 = v_u_220()
	v_u_59.visibleSubs = v_u_213
	v_u_59.cratesPage = v_u_24
	local v_u_223, v_u_224 = v_u_10.tabs({
		["parent"] = nil,
		["name"] = "SubTabs",
		["position"] = nil,
		["size"] = nil,
		["tabs"] = nil,
		["selected"] = nil,
		["onChange"] = nil,
		["parent"] = v_u_209,
		["position"] = UDim2.fromOffset(0, 0),
		["size"] = UDim2.new(0, v_u_221, 1, 0),
		["tabs"] = v_u_20,
		["selected"] = v_u_53,
		["onChange"] = function(p222) -- name: onChange
			-- upvalues: (copy) v_u_16
			v_u_16.showSub(p222)
		end
	})
	local v_u_225 = v_u_11.touch(40)
	local _, _ = v_u_10.iconButton({
		["parent"] = nil,
		["icon"] = "info",
		["size"] = nil,
		["kind"] = "secondary",
		["name"] = "Info",
		["anchor"] = nil,
		["position"] = nil,
		["onClick"] = nil,
		["parent"] = v_u_209,
		["size"] = v_u_225,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, 0, 0, 0),
		["onClick"] = function() -- name: onClick
			-- upvalues: (copy) v_u_16
			v_u_16.info()
		end
	})
	local v_u_226 = v_u_10.new("Frame", {
		["Name"] = "SubHost",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(v_u_221 + 12, 0),
		["Size"] = UDim2.new(1, -(v_u_221 + 12 + v_u_225 + 8), 1, 0)
	}, v_u_209)
	local function v_u_231() -- name: applyTabs
		-- upvalues: (ref) v_u_24, (ref) v_u_38, (copy) v_u_19, (copy) v_u_59, (copy) v_u_223, (copy) v_u_52, (copy) v_u_209, (ref) v_u_221, (copy) v_u_220, (copy) v_u_226, (copy) v_u_225, (ref) v_u_53, (copy) v_u_16
		if v_u_24 or v_u_38 then
			local v227 = v_u_24
			if v227 then
				v227 = v_u_19.crateTab(v_u_59.state)
			end
			local v228 = v_u_223:FindFirstChild("Tab_crates", true)
			if v228 and v228:IsA("GuiObject") then
				v228.Visible = v227
			end
			local v229 = v_u_52()
			local v230 = v_u_223:FindFirstChild("Tab_trade", true)
			if v230 and v230:IsA("GuiObject") then
				v230.Visible = v229
			end
			v_u_209:SetAttribute("TradeTab", v229)
			v_u_221 = v_u_220()
			v_u_223.Size = UDim2.new(0, v_u_221, 1, 0)
			v_u_226.Position = UDim2.fromOffset(v_u_221 + 12, 0)
			v_u_226.Size = UDim2.new(1, -(v_u_221 + 12 + v_u_225 + 8), 1, 0)
			v_u_209:SetAttribute("CratesTab", v227)
			if not v227 and v_u_53 == "crates" then
				v_u_16.showSub("browse")
			end
			if not v229 and v_u_53 == "trade" then
				v_u_16.showSub("browse")
			end
		end
	end
	local v_u_232 = v_u_14 and 24 or 28
	local v_u_233 = v_u_10.new("Frame", {
		["Name"] = "Banner",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_12.raised,
		["Size"] = UDim2.new(1, 0, 0, v_u_232)
	}, v_u_191)
	local v_u_234 = v_u_10.stroke(v_u_233, v_u_12.line)
	local v_u_235 = v_u_10.new("Frame", {
		["Name"] = "Tick",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_12.accent,
		["Size"] = UDim2.new(0, 3, 1, 0)
	}, v_u_233)
	local v_u_236 = v_u_10.label({
		["parent"] = nil,
		["name"] = "Text",
		["text"] = "",
		["style"] = "small",
		["color"] = nil,
		["position"] = nil,
		["size"] = nil,
		["fit"] = true,
		["track"] = false,
		["parent"] = v_u_233,
		["color"] = v_u_12.text,
		["position"] = UDim2.fromOffset(12, 0),
		["size"] = UDim2.new(1, -20, 1, 0)
	})
	local v_u_237 = false
	local v_u_238 = v_u_206 + v_u_189 + v_u_190
	local v_u_239 = v_u_10.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_238),
		["Size"] = UDim2.new(1, 0, 1, -v_u_238)
	}, v_u_191)
	v_u_59.body = v_u_239
	v_u_59.subHost = v_u_226
	v_u_59.subRow = v_u_209
	v_u_59.inner = v_u_191
	v_u_59.page = p_u_9
	local v_u_240 = false
	local v_u_241 = nil
	local function v242()
		-- upvalues: (ref) v_u_241, (copy) p_u_8
		v_u_241 = p_u_8.cctx.lib.MenuMarketLayout
	end
	pcall(v242)
	local function v_u_257() -- name: layoutBody
		-- upvalues: (ref) v_u_241, (copy) v_u_14, (copy) v_u_15, (copy) v_u_189, (ref) v_u_208, (ref) v_u_237, (ref) v_u_240, (copy) v_u_190, (copy) v_u_206, (copy) v_u_232, (copy) v_u_207, (copy) v_u_209, (copy) v_u_233, (ref) v_u_238, (copy) v_u_239, (ref) v_u_57, (ref) v_u_58
		local v243 = nil
		local v244
		if v_u_241 == nil then
			v244 = v243
		else
			local v245 = v_u_241.stack
			local v246 = {
				["compact"] = v_u_14,
				["phone"] = v_u_15,
				["subH"] = v_u_189,
				["stripPx"] = v_u_208,
				["bannerShown"] = v_u_237,
				["subHidden"] = v_u_240
			}
			local v247
			v247, v244 = pcall(v245, v246)
			if v247 then
				if type(v244) ~= "table" then
					v244 = v243
				end
			else
				v244 = v243
			end
		end
		if v244 == nil then
			local v248
			if v_u_208 > 0 then
				local v249 = v_u_240
				if v249 then
					v249 = v_u_14
				end
				v248 = not v249
			else
				v248 = false
			end
			local v250 = not v248 and 0 or v_u_208 + v_u_190
			local v251
			if v_u_240 then
				v251 = v_u_206
			else
				v251 = v_u_206 + v_u_189 + v_u_190
			end
			local v252 = v251 + v250
			v244 = {
				["stripShown"] = v248,
				["subRowY"] = v_u_206 + v250
			}
			local v253
			if v_u_237 then
				v253 = v252
			else
				v253 = nil
			end
			v244.bannerY = v253
			v244.bodyY = v252 + (not v_u_237 and 0 or v_u_232 + v_u_190)
		end
		v_u_207.Visible = v244.stripShown
		v_u_207.Size = UDim2.new(1, 0, 0, v_u_208)
		v_u_209.Position = UDim2.fromOffset(0, v244.subRowY)
		if v244.bannerY ~= nil then
			v_u_233.Position = UDim2.fromOffset(0, v244.bannerY)
		end
		v_u_233.Visible = v_u_237
		local v254 = v244.bodyY
		v_u_238 = v254
		v_u_239.Position = UDim2.fromOffset(0, v254)
		v_u_239.Size = UDim2.new(1, 0, 1, -v254)
		if v_u_57 and v_u_57.isOpen() then
			local v255 = v_u_57.layout
			pcall(v255)
		end
		if v_u_58 and v_u_58.pageOpen() then
			local v256 = v_u_58.page().layout
			pcall(v256)
		end
	end
	v_u_59.layoutBody = v_u_257
	function v_u_59.setStripHeight(p258) -- name: setStripHeight
		-- upvalues: (ref) v_u_208, (copy) v_u_257
		v_u_208 = math.max(0, p258)
		v_u_257()
	end
	local function v_u_269() -- name: paintChip
		-- upvalues: (copy) v_u_59, (copy) v_u_19, (copy) v_u_44, (copy) v_u_12, (copy) v_u_200, (copy) v_u_199, (copy) v_u_205, (copy) p_u_9, (copy) v_u_231, (copy) v_u_236, (copy) v_u_235, (copy) v_u_234, (ref) v_u_237, (copy) v_u_257, (copy) v_u_14
		local v259 = v_u_59.state
		local v260 = v_u_19.chip(v259, v_u_44)
		local v261
		if v260.kind == "open" then
			v261 = v_u_12.success
		elseif v260.kind == "paused" then
			v261 = v_u_12.info
		elseif v260.kind == "limited" then
			v261 = v_u_12.accent
		elseif v260.kind == "closed" then
			v261 = v_u_12.danger
		else
			v261 = v_u_12.text2
		end
		v_u_200.Text = v260.text
		v_u_200.TextColor3 = v261
		v_u_199.Color = v261
		v_u_205.Text = v260.reason or ""
		v_u_205.Visible = v260.reason ~= nil
		p_u_9:SetAttribute("MarketChip", v260.kind)
		v_u_231()
		local v262 = v_u_19.banner(v259)
		local v263 = nil
		local v264 = v_u_12.accent
		if v262 then
			v263 = v262.text
			if v262.kind == "down" then
				v264 = v_u_12.danger
			else
				v264 = v_u_12.accent
			end
		elseif v260.kind == "closed" or v260.kind == "paused" then
			v263 = v260.reason
			if v260.kind == "closed" then
				v264 = v_u_12.danger
			else
				v264 = v_u_12.info
			end
		end
		if v263 ~= nil then
			v_u_236.Text = v263
			v_u_235.BackgroundColor3 = v264
			v_u_234.Color = v264:Lerp(v_u_12.line, 0.6)
		end
		local v265 = v263 ~= nil
		if v265 ~= v_u_237 then
			v_u_237 = v265
			v_u_257()
		end
		p_u_9:SetAttribute("MarketBanner", v263 or "")
		if v_u_14 then
			v_u_205.Visible = false
		else
			local v266 = v_u_205
			local v267
			if v260.reason == nil then
				v267 = false
			else
				local v268
				if v263 == nil then
					v268 = false
				else
					v268 = v263 == v260.reason
				end
				v267 = not v268
			end
			v266.Visible = v267
		end
	end
	local v_u_270 = {}
	local v_u_271 = {}
	local v_u_272 = false
	local v_u_273 = (-1 / 0)
	function v_u_59.refreshState(p_u_274) -- name: refreshState
		-- upvalues: (ref) v_u_272, (ref) v_u_45, (copy) v_u_43, (ref) v_u_273, (copy) v_u_59, (copy) v_u_269, (copy) v_u_270
		if not v_u_272 and v_u_45 then
			v_u_272 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_43, (ref) v_u_273, (copy) p_u_274, (ref) v_u_272, (ref) v_u_45, (ref) v_u_59, (ref) v_u_269, (ref) v_u_270
				local v275 = v_u_43:clock() - v_u_273
				if p_u_274 and v275 < 0.6 then
					task.wait(0.6 - v275)
				end
				v_u_273 = v_u_43:clock()
				local v276 = v_u_43:state(p_u_274 and 0 or 2)
				v_u_272 = false
				if v_u_45 then
					v_u_59.state = v276
					v_u_269()
					for _, v277 in v_u_270 do
						if not v277.onState then
							continue
						end
						local v278 = v277.onState
						local v279 = v_u_59.state
						pcall(v278, v279)
					end
				end
			end)
		end
	end
	function v_u_59.onState(p280) -- name: onState
		-- upvalues: (copy) v_u_270
		local v_u_281 = {
			["onState"] = p280
		}
		local v282 = v_u_270
		table.insert(v282, v_u_281)
		return function()
			-- upvalues: (ref) v_u_270, (copy) v_u_281
			local v283 = table.find(v_u_270, v_u_281)
			if v283 then
				table.remove(v_u_270, v283)
			end
		end
	end
	local function v_u_295(p284) -- name: buildPage
		-- upvalues: (copy) v_u_271, (copy) p_u_8, (copy) v_u_10, (copy) v_u_239, (copy) v_u_59, (ref) v_u_5, (copy) v_u_13
		if v_u_271[p284] then
			return v_u_271[p284]
		end
		local v_u_285 = ({
			["browse"] = "MenuMarketBrowse",
			["crates"] = "MenuMarketCrates",
			["trade"] = "MenuMarketTrade",
			["sell"] = "MenuMarketSell",
			["mine"] = "MenuMarketMine",
			["orders"] = "MenuMarketMine"
		})[p284]
		local v_u_286 = p_u_8
		local v287, v288 = pcall(function()
			-- upvalues: (copy) v_u_286, (copy) v_u_285
			return v_u_286.cctx.lib[v_u_285]
		end)
		if not v287 or type(v288) ~= "table" then
			warn("[MenuMarket] lib missing:", v_u_285, v288)
			v288 = nil
		end
		local v289 = v_u_10.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Visible"] = false,
			["Name"] = "Sub_" .. p284,
			["Size"] = UDim2.fromScale(1, 1)
		}, v_u_239)
		local v290 = {
			["frame"] = v289
		}
		local v291
		if v288 then
			if p284 == "orders" then
				v291 = v288.newOrders
			else
				v291 = v288.new
			end
		else
			v291 = nil
		end
		if v288 and type(v291) == "function" then
			local v292 = v_u_59
			local v293, v294 = pcall(v291, v292, v289)
			if v293 then
				v294.frame = v294.frame or v289
				v290 = v294
			else
				warn("[MenuMarket] page failed:", p284, v294)
				v_u_5:SetAttribute("ClientError", "market " .. p284 .. ": " .. tostring(v294))
				v_u_13.empty(v289, "This page could not be loaded. Close and reopen the menu. If it stays, rejoin HUSH.")
			end
		else
			v_u_13.empty(v289, "This page is not available.")
		end
		v_u_271[p284] = v290
		return v290
	end
	local function v_u_305(p296) -- name: showPage
		-- upvalues: (copy) v_u_271, (copy) v_u_295, (copy) v_u_226
		for v297, v298 in v_u_271 do
			if v297 == p296 then
				continue
			end
			if v298.frame then
				v298.frame.Visible = false
			end
			local v299 = v298.hide
			if type(v299) ~= "function" then
				continue
			end
			local v300 = v298.hide
			pcall(v300)
		end
		local v301 = v_u_295(p296)
		if v301.frame then
			v301.frame.Visible = true
		end
		local v302 = v301.show
		if type(v302) == "function" then
			local v303 = v301.show
			pcall(v303)
		end
		for _, v304 in v_u_226:GetChildren() do
			if v304:GetAttribute("PageControl") == nil then
				continue
			end
			v304.Visible = v304:GetAttribute("PageControl") == p296
		end
	end
	function v_u_59.controlFrame(p306, p307) -- name: controlFrame
		-- upvalues: (copy) v_u_10, (ref) v_u_53, (copy) v_u_226
		local v308 = v_u_10.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Visible"] = nil,
			["Name"] = p307 or "Controls_" .. p306,
			["Size"] = UDim2.fromScale(1, 1),
			["Visible"] = p306 == v_u_53
		}, v_u_226)
		v308:SetAttribute("PageControl", p306)
		return v308
	end
	function v_u_16.showSub(p309, p310) -- name: showSub
		-- upvalues: (ref) v_u_21, (ref) v_u_24, (copy) v_u_19, (copy) v_u_59, (copy) v_u_52, (ref) v_u_57, (ref) v_u_58, (ref) v_u_53, (ref) v_u_7, (copy) v_u_224, (copy) v_u_305, (copy) p_u_9, (copy) v_u_271
		local v311, v312, v313, v314
		if p309 == "browse" or (p309 == "sell" or (p309 == "mine" or p309 == "orders" and v_u_21)) then
			if v_u_57 and v_u_57.isOpen() then
				v_u_57.close(true)
			end
			if v_u_58 and v_u_58.pageOpen() then
				v_u_58.closePage(true)
			end
			v_u_53 = p309
			v_u_7.sub = p309
			if v_u_224.get() ~= p309 then
				v311 = v_u_224.select
				pcall(v311, p309, true)
			end
			v_u_305(p309)
			p_u_9:SetAttribute("MarketSub", p309)
			v312 = p309 == "sell" and (p310 and v_u_271.sell)
			if v312 then
				v313 = v312.select
				if type(v313) == "function" then
					v314 = v312.select
					pcall(v314, p310)
				end
			end
		else
			if p309 == "crates" then
				local v315 = v_u_24
				if v315 then
					v315 = v_u_19.crateTab(v_u_59.state)
				end
				if v315 then
					if v_u_57 and v_u_57.isOpen() then
						v_u_57.close(true)
					end
					if v_u_58 and v_u_58.pageOpen() then
						v_u_58.closePage(true)
					end
					v_u_53 = p309
					v_u_7.sub = p309
					if v_u_224.get() ~= p309 then
						v311 = v_u_224.select
						pcall(v311, p309, true)
					end
					v_u_305(p309)
					p_u_9:SetAttribute("MarketSub", p309)
					v312 = p309 == "sell" and (p310 and v_u_271.sell)
					if v312 then
						v313 = v312.select
						if type(v313) == "function" then
							v314 = v312.select
							pcall(v314, p310)
						end
					end
					return
				end
				if p309 ~= "trade" or not v_u_52() then
					return
				end
			elseif p309 ~= "trade" or not v_u_52() then
				return
			end
			if v_u_57 and v_u_57.isOpen() then
				v_u_57.close(true)
			end
			if v_u_58 and v_u_58.pageOpen() then
				v_u_58.closePage(true)
			end
			v_u_53 = p309
			v_u_7.sub = p309
			if v_u_224.get() ~= p309 then
				v311 = v_u_224.select
				pcall(v311, p309, true)
			end
			v_u_305(p309)
			p_u_9:SetAttribute("MarketSub", p309)
			v312 = p309 == "sell" and (p310 and v_u_271.sell)
			if v312 then
				v313 = v312.select
				if type(v313) == "function" then
					v314 = v312.select
					pcall(v314, p310)
				end
			end
		end
	end
	function v_u_16.cycle(p316) -- name: cycle
		-- upvalues: (copy) v_u_213, (ref) v_u_53, (copy) v_u_16
		local v317 = v_u_213()
		local v318 = 1
		for v319, v320 in v317 do
			if v320.id ~= v_u_53 then
				continue
			end
			v318 = v319
		end
		local v321 = (v318 - 1 + (p316 >= 0 and 1 or -1)) % #v317 + 1
		v_u_16.showSub(v317[v321].id)
		return v317[v321].id
	end
	function v_u_16.subs() -- name: subs
		-- upvalues: (copy) v_u_213
		local v322 = {}
		for _, v323 in v_u_213() do
			local v324 = v323.id
			table.insert(v322, v324)
		end
		return v322
	end
	local function v_u_335() -- name: ensureItemPage
		-- upvalues: (ref) v_u_57, (copy) p_u_8, (copy) v_u_59, (copy) v_u_191, (ref) v_u_5
		if v_u_57 then
			return v_u_57
		end
		local v_u_325 = p_u_8
		local v_u_326 = "MenuMarketItem"
		local v327, v328 = pcall(function()
			-- upvalues: (copy) v_u_325, (copy) v_u_326
			return v_u_325.cctx.lib[v_u_326]
		end)
		if not v327 or type(v328) ~= "table" then
			warn("[MenuMarket] lib missing:", "MenuMarketItem", v328)
			v328 = nil
		end
		if v328 then
			local v329 = v328.new
			if type(v329) == "function" then
				local v330 = v328.new
				local v331 = v_u_59
				local v332 = v_u_191
				local v333, v334 = pcall(v330, v331, v332)
				if v333 then
					v_u_57 = v334
				else
					warn("[MenuMarket] item page failed:", v334)
					v_u_5:SetAttribute("ClientError", "market item: " .. tostring(v334))
				end
			end
		end
		return v_u_57
	end
	function v_u_16.pageOf(p336) -- name: pageOf
		-- upvalues: (ref) v_u_58, (copy) v_u_271
		if p336 == "restock" then
			return v_u_58
		else
			return v_u_271[p336]
		end
	end
	function v_u_16.itemPage() -- name: itemPage
		-- upvalues: (ref) v_u_57
		return v_u_57
	end
	function v_u_16.openItem(p337) -- name: openItem
		-- upvalues: (ref) v_u_53, (ref) v_u_58, (copy) v_u_335
		local _ = v_u_53 == "browse"
		if v_u_58 and v_u_58.pageOpen() then
			v_u_58.closePage(true)
		end
		local v338 = v_u_335()
		if v338 then
			v338.open(p337)
		end
	end
	v_u_59.nav = {
		["sub"] = function(p339, p340) -- name: sub
			-- upvalues: (copy) v_u_16
			v_u_16.showSub(p339, p340)
		end,
		["openItem"] = function(p341) -- name: openItem
			-- upvalues: (copy) v_u_16
			v_u_16.openItem(p341)
		end,
		["sell"] = function(p342) -- name: sell
			-- upvalues: (copy) v_u_16
			v_u_16.showSub("sell", p342)
		end,
		["back"] = function() -- name: back
			-- upvalues: (ref) v_u_57
			if not (v_u_57 and v_u_57.isOpen()) then
				return false
			end
			v_u_57.close()
			return true
		end,
		["restock"] = function() -- name: restock
			-- upvalues: (ref) v_u_58
			if v_u_58 then
				v_u_58.openPage()
			end
		end,
		["info"] = function() -- name: info
			-- upvalues: (copy) v_u_16
			v_u_16.info()
		end
	}
	function v_u_59.itemTop() -- name: itemTop
		-- upvalues: (ref) v_u_238
		return v_u_238
	end
	function v_u_59.setSubRowVisible(p343) -- name: setSubRowVisible
		-- upvalues: (copy) v_u_209, (ref) v_u_240, (copy) v_u_257
		v_u_209.Visible = p343
		v_u_240 = not p343
		v_u_257()
	end
	local v_u_344 = "MenuMarketRestock"
	local v345, v346 = pcall(function()
		-- upvalues: (copy) p_u_8, (copy) v_u_344
		return p_u_8.cctx.lib[v_u_344]
	end)
	if not v345 or type(v346) ~= "table" then
		warn("[MenuMarket] lib missing:", "MenuMarketRestock", v346)
		v346 = nil
	end
	if v346 ~= nil then
		local v347 = v346.new
		if type(v347) == "function" then
			local v348 = v_u_19.rsStripOf
			if type(v348) == "function" then
				local v349 = v346.new
				local v350, v351 = pcall(v349, v_u_59, v_u_207)
				if v350 and type(v351) == "table" then
					v_u_58 = v351
					v_u_59.rs = v351
				else
					warn("[MenuMarket] restock failed:", v351)
					v_u_5:SetAttribute("ClientError", "market restock: " .. tostring(v351))
				end
			end
		end
	end
	function v_u_16.info() -- name: info
		-- upvalues: (copy) v_u_59, (copy) v_u_19, (ref) v_u_24, (ref) v_u_58, (ref) v_u_21, (copy) v_u_10, (copy) v_u_12
		local v352 = v_u_59.state
		local v353
		if type(v352) == "table" then
			local v354 = v352.tune
			v353 = type(v354) ~= "table" and {} or v352.tune
		else
			v353 = {}
		end
		local v355
		if type(v352) == "table" then
			local v356 = v352.allow
			v355 = type(v356) ~= "table" and {} or v352.allow
		else
			v355 = {}
		end
		local v357 = v353.feePct or 5
		local v358 = v353.listingDays or 3
		local v359 = v353.cooldown or 30
		local v_u_360 = {
			("Sell items from your stash for Cash. An item leaves your stash when you list it. Other players buy it, and the Cash comes to you. Listings stay for %d days; an item nobody buys comes back to your stash."):format(v358),
			("The market keeps %d percent of the price. The form shows what you receive before you list."):format(v357),
			"Weapons are sold without attachments, bags and rigs only when empty. Quest items, keys to the story and containers for your secure slot cannot be traded.",
			v_u_19.infoAllowLine(v355, v353.feePct or 5),
			("When you buy, your Cash is set aside until the sale is done. After a purchase you can buy again in %d seconds."):format(v359),
			"Prices are per unit. A stack is one listing. The cheapest listing of an item is always shown first."
		}
		local v361 = v_u_19.infoListLine
		local v362
		if type(v352) == "table" then
			v362 = v352.list
		else
			v362 = nil
		end
		local v363 = v361(v362)
		if v363 ~= nil then
			table.insert(v_u_360, v363)
		end
		local v364 = v_u_24
		if v364 then
			v364 = v_u_19.crateTab(v_u_59.state)
		end
		if v364 then
			local v365 = v_u_19.cm
			local v366
			if v365 == nil then
				v366 = nil
			else
				local v367 = v365.TEXT
				if type(v367) == "table" then
					v366 = v365.TEXT.info
				else
					v366 = nil
				end
			end
			local v368 = (type(v366) ~= "string" or v366 == "") and "Cases: every account can sell them. Buying cases depends on Roblox rules for random items in your region and age group." or v366
			table.insert(v_u_360, v368)
		end
		if v_u_58 and v_u_58.active() then
			table.insert(v_u_360, "A market restock sells goods at a fixed price for a limited time, with a limit per account. Open VIEW RESTOCK, choose an amount, then BUY and CONFIRM. Your purchase comes to your mail.")
		end
		if v_u_21 then
			table.insert(v_u_360, "A buy order sets your Cash aside and waits for a seller. Open an item, choose BOOK, then PLACE ORDER. A filled order arrives in your mail. You can sell into a waiting order with SELL NOW.")
		end
		local v372 = {
			["title"] = "Blackmarket",
			["width"] = 560,
			["build"] = nil,
			["buttons"] = nil,
			["build"] = function(p369) -- name: build
				-- upvalues: (copy) v_u_360, (ref) v_u_10, (ref) v_u_12
				for v370, v371 in v_u_360 do
					v_u_10.label({
						["parent"] = nil,
						["text"] = nil,
						["style"] = "body",
						["color"] = nil,
						["wrap"] = true,
						["autoY"] = true,
						["order"] = nil,
						["parent"] = p369,
						["text"] = v371,
						["color"] = v_u_12.text2,
						["order"] = v370
					})
				end
			end,
			["buttons"] = {
				{
					["text"] = "Close",
					["kind"] = "primary"
				}
			}
		}
		v_u_10.modal(v372)
	end
	local v_u_373 = nil
	local function v_u_375() -- name: tipTarget
		-- upvalues: (copy) v_u_223
		local v374 = v_u_223:FindFirstChild("Tab_sell", true)
		if v374 and v374:IsA("GuiObject") then
			return v374
		else
			return nil
		end
	end
	local function v_u_389() -- name: startTip
		-- upvalues: (copy) p_u_8, (copy) p_u_9, (copy) v_u_375, (ref) v_u_46, (ref) v_u_45, (ref) v_u_57, (ref) v_u_373
		local v_u_376 = nil
		local function v377()
			-- upvalues: (ref) v_u_376, (ref) p_u_8
			v_u_376 = p_u_8.cctx.lib.MenuTipOnce
		end
		pcall(v377)
		if v_u_376 then
			local v378 = v_u_376.show
			if type(v378) == "function" then
				local v379 = v_u_376.show
				local v380 = p_u_8
				local v383 = {
					["host"] = p_u_9,
					["target"] = v_u_375,
					["active"] = function() -- name: active
						-- upvalues: (ref) v_u_46, (ref) v_u_45, (ref) v_u_57
						local v381 = v_u_46 and v_u_45
						if v381 then
							local v382 = v_u_57
							if v382 then
								v382 = v_u_57.isOpen()
							end
							v381 = not v382
						end
						return v381
					end,
					["sides"] = { "below", "right" }
				}
				local v384, v385 = pcall(v379, v380, "bmIntro", v383)
				if v384 then
					v_u_373 = v385
				end
				local function v386()
					-- upvalues: (ref) v_u_376, (ref) p_u_8
					return v_u_376.decide("bmIntro", p_u_8.profile, nil)
				end
				local v387, v388 = pcall(v386)
				p_u_9:SetAttribute("MarketTip", not v387 and "error" or tostring(v388))
				return
			end
		end
	end
	local v_u_390 = true
	function v_u_16.show() -- name: show
		-- upvalues: (ref) v_u_45, (ref) v_u_46, (copy) p_u_9, (copy) v_u_59, (ref) v_u_390, (copy) v_u_43, (copy) v_u_305, (ref) v_u_53, (ref) v_u_57, (ref) v_u_58, (copy) v_u_389
		if v_u_45 then
			v_u_46 = true
			p_u_9:SetAttribute("MarketOpen", true)
			v_u_59.refreshState(true)
			if v_u_390 then
				v_u_390 = false
				task.spawn(function()
					-- upvalues: (ref) v_u_43
					v_u_43:mine(true)
				end)
			end
			v_u_305(v_u_53)
			if v_u_57 and v_u_57.isOpen() then
				local v391 = v_u_57.layout
				pcall(v391)
			end
			if v_u_58 then
				local v392 = v_u_58.show
				pcall(v392)
			end
			v_u_389()
		end
	end
	function v_u_16.hide() -- name: hide
		-- upvalues: (ref) v_u_46, (copy) p_u_9, (ref) v_u_373, (copy) v_u_271, (ref) v_u_58
		v_u_46 = false
		p_u_9:SetAttribute("MarketOpen", false)
		if v_u_373 then
			local v393 = v_u_373.dismiss
			pcall(v393, "left")
			v_u_373 = nil
		end
		for _, v394 in v_u_271 do
			local v395 = v394.hide
			if type(v395) ~= "function" then
				continue
			end
			local v396 = v394.hide
			pcall(v396)
		end
		if v_u_58 then
			local v397 = v_u_58.hide
			pcall(v397)
		end
	end
	function v_u_16.refresh(p398, p399) -- name: refresh
		-- upvalues: (ref) v_u_45, (copy) v_u_271, (ref) v_u_57
		if v_u_45 then
			if p398 == "profile" or p398 == "result" then
				for _, v400 in v_u_271 do
					local v401 = v400.refresh
					if type(v401) ~= "function" then
						continue
					end
					local v402 = v400.refresh
					pcall(v402, p398, p399)
				end
				if v_u_57 and v_u_57.isOpen() then
					local v403 = v_u_57.refresh
					if type(v403) == "function" then
						local v404 = v_u_57.refresh
						pcall(v404, p398, p399)
					end
				end
			end
		end
	end
	function v_u_16.destroy() -- name: destroy
		-- upvalues: (ref) v_u_45, (ref) v_u_46, (ref) v_u_373, (copy) v_u_271, (ref) v_u_57, (ref) v_u_58, (copy) v_u_54, (ref) v_u_4, (copy) v_u_16, (copy) v_u_43
		v_u_45 = false
		v_u_46 = false
		if v_u_373 then
			local v405 = v_u_373.detach
			pcall(v405)
			v_u_373 = nil
		end
		for _, v406 in v_u_271 do
			local v407 = v406.destroy
			if type(v407) ~= "function" then
				continue
			end
			local v408 = v406.destroy
			pcall(v408)
		end
		if v_u_57 then
			local v409 = v_u_57.destroy
			if type(v409) == "function" then
				local v410 = v_u_57.destroy
				pcall(v410)
			end
		end
		if v_u_58 then
			local v411 = v_u_58.destroy
			pcall(v411)
		end
		for _, v_u_412 in v_u_54 do
			pcall(function()
				-- upvalues: (copy) v_u_412
				v_u_412:Disconnect()
			end)
		end
		table.clear(v_u_54)
		if v_u_4._cur == v_u_16 then
			v_u_4._cur = nil
		end
		v_u_43:destroy()
	end
	local v414 = {
		["Disconnect"] = v_u_43:onChange(function(p413)
			-- upvalues: (copy) v_u_59
			if p413 == "result" or p413 == "note" then
				v_u_59.refreshState(true)
			end
		end)
	}
	table.insert(v_u_54, v414)
	local v421 = {
		["Disconnect"] = v_u_43:onNote(function(p415)
			-- upvalues: (copy) v_u_271, (ref) v_u_57
			for _, v416 in v_u_271 do
				local v417 = v416.onNote
				if type(v417) ~= "function" then
					continue
				end
				local v418 = v416.onNote
				pcall(v418, p415)
			end
			if v_u_57 and v_u_57.isOpen() then
				local v419 = v_u_57.onNote
				if type(v419) == "function" then
					local v420 = v_u_57.onNote
					pcall(v420, p415)
				end
			end
		end)
	}
	table.insert(v_u_54, v421)
	if v_u_38 then
		local v423 = {
			["Disconnect"] = v_u_33.subscribe(function(p422)
				-- upvalues: (copy) v_u_231
				if p422.k == "state" or p422.k == "backend" then
					v_u_231()
				end
			end)
		}
		table.insert(v_u_54, v423)
		local v424 = v_u_5:GetAttributeChangedSignal("PaidTrading")
		table.insert(v_u_54, v424:Connect(function()
			-- upvalues: (ref) v_u_33, (copy) v_u_231
			v_u_33.refresh(true)
			v_u_231()
		end))
		v_u_33.refresh(false)
		task.defer(v_u_231)
	end
	for _, v425 in { "BmBadge", "BmPending" } do
		local v426 = v_u_5:GetAttributeChangedSignal(v425)
		table.insert(v_u_54, v426:Connect(function()
			-- upvalues: (ref) v_u_46, (copy) v_u_59, (copy) v_u_271
			if v_u_46 then
				v_u_59.refreshState(true)
				local v427 = v_u_271.mine
				if v427 then
					local v428 = v427.reload
					if type(v428) == "function" then
						local v429 = v427.reload
						pcall(v429)
					end
				end
			end
		end))
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_45, (ref) v_u_46, (copy) v_u_55, (copy) v_u_59, (ref) v_u_58
		local v430 = 0
		while v_u_45 do
			task.wait(1)
			if not v_u_45 then
				break
			end
			if v_u_46 then
				v430 = v430 + 1
				for _, v431 in v_u_55 do
					pcall(v431)
				end
				if v430 % 8 ~= 0 then
					break
				end
				v_u_59.refreshState(false)
			else
				if not v_u_58 then
					continue
				end
				local v432 = v_u_58.toasts
				pcall(v432)
			end
		end
	end)
	function v_u_16.onBack() -- name: onBack
		-- upvalues: (ref) v_u_58, (ref) v_u_57, (ref) v_u_53, (copy) v_u_16
		if v_u_58 and v_u_58.pageOpen() then
			v_u_58.closePage()
			return true
		end
		if v_u_57 and v_u_57.isOpen() then
			v_u_57.close()
			return true
		end
		if v_u_53 == "browse" then
			return false
		end
		v_u_16.showSub("browse")
		return true
	end
	local v433, v434 = pcall(function()
		-- upvalues: (copy) p_u_8
		return p_u_8.cctx.lib.VirtualPad
	end)
	if v433 and v434 then
		local v435 = v434.InputBegan
		local function v439(p436, _)
			-- upvalues: (ref) v_u_46, (ref) v_u_45, (copy) v_u_59, (ref) v_u_3, (copy) v_u_16, (copy) v_u_10, (ref) v_u_57, (ref) v_u_58
			if v_u_46 and (v_u_45 and not v_u_59.modalOpen()) then
				if v_u_3:GetFocusedTextBox() == nil then
					local v437 = p436.KeyCode
					if v437 == Enum.KeyCode.ButtonB then
						if v_u_16.onBack() then
							local v438 = v_u_10.takeBack
							pcall(v438)
							return
						end
					elseif (v437 == Enum.KeyCode.ButtonL2 or v437 == Enum.KeyCode.ButtonR2) and not (v_u_57 and v_u_57.isOpen() or v_u_58 and v_u_58.pageOpen()) then
						v_u_16.cycle(v437 == Enum.KeyCode.ButtonR2 and 1 or -1)
					end
				end
			else
				return
			end
		end
		table.insert(v_u_54, v435:Connect(v439))
	end
	function v_u_16.audit(_) -- name: audit
		-- upvalues: (copy) v_u_11, (copy) v_u_191, (copy) p_u_9
		local v440 = v_u_11.viewport()
		local v441 = v_u_191.AbsolutePosition
		local v442 = v_u_191.AbsoluteSize
		local function v448(p443) -- name: scrolled
			-- upvalues: (ref) p_u_9
			local v444 = p443.Parent
			while v444 and v444 ~= p_u_9 do
				if v444:IsA("ScrollingFrame") then
					local v445 = p443.AbsolutePosition + p443.AbsoluteSize / 2
					local v446 = v444.AbsolutePosition
					local v447 = v444.AbsoluteWindowSize
					if v445.X < v446.X - 1 or (v445.Y < v446.Y - 1 or (v445.X > v446.X + v447.X + 1 or v445.Y > v446.Y + v447.Y + 1)) then
						return true
					end
				end
				v444 = v444.Parent
			end
			return false
		end
		local function v450(p449) -- name: shownObj
			-- upvalues: (ref) p_u_9
			while p449 and p449 ~= p_u_9 do
				if p449:IsA("GuiObject") and not p449.Visible then
					return false
				end
				p449 = p449.Parent
			end
			return true
		end
		local v451 = 0
		local v452 = 0
		local v453 = {}
		local v454 = {}
		local v455 = {}
		for _, v456 in p_u_9:GetDescendants() do
			if not v456:IsA("GuiObject") or (not v450(v456) or (v456.AbsoluteSize.X <= 0 or (v456.AbsoluteSize.Y <= 0 or v448(v456)))) then
				continue
			end
			v451 = v451 + 1
			local v457 = v456:GetFullName():gsub("^.*Market%.", "")
			if v456:IsA("GuiButton") and (v456.Selectable ~= false and v456.Name ~= "Hit") then
				v452 = v452 + 1
				local v458 = v456.AbsoluteSize.X
				local v459 = v456.AbsoluteSize.Y
				if math.min(v458, v459) < 43.5 then
					local v460 = v456.AbsoluteSize.X
					local v461 = v456.AbsoluteSize.Y
					table.insert(v455, ("%s %dx%d"):format(v457, v460, v461))
				end
			end
			if v456:IsA("TextLabel") or v456:IsA("TextButton") then
				if v456.Text == "" or (v456.TextScaled or v456.TextTruncate ~= Enum.TextTruncate.None) then
					if v456.Text ~= "" and (v456.TextScaled and not v456.TextFits) then
						local v462 = v456.Text
						local v463 = string.sub(v462, 1, 24)
						table.insert(v453, ("%s %q scaled text does not fit"):format(v457, v463))
					end
				else
					local v464 = v456.TextBounds
					if v464.X > v456.AbsoluteSize.X + 1.5 or v456.TextWrapped and v464.Y > v456.AbsoluteSize.Y + 1.5 then
						local v465 = v456.Text
						local v466 = string.sub(v465, 1, 24)
						local v467 = v464.X
						local v468 = v464.Y
						local v469 = v456.AbsoluteSize.X
						local v470 = v456.AbsoluteSize.Y
						table.insert(v453, ("%s %q %dx%d in %dx%d"):format(v457, v466, v467, v468, v469, v470))
					end
				end
			end
			local v471 = v456.AbsolutePosition
			local v472 = v456.AbsoluteSize
			if v456.Name == "Grain" or v471.X >= v441.X - 2 and (v471.Y >= v441.Y - 2 and (v471.X + v472.X <= v441.X + v442.X + 2 and v471.Y + v472.Y <= v441.Y + v442.Y + 2)) or v456:FindFirstAncestorWhichIsA("ScrollingFrame") then
				continue
			end
			local v473 = v471.X
			local v474 = v471.Y
			local v475 = v472.X
			local v476 = v472.Y
			table.insert(v454, ("%s at %d,%d %dx%d"):format(v457, v473, v474, v475, v476))
		end
		local function v482(p477) -- name: head
			local v478 = #p477
			local v479 = {}
			for v480 = 1, math.min(v478, 6) do
				local v481 = p477[v480]
				table.insert(v479, v481)
			end
			return table.concat(v479, " ; ")
		end
		local _ = v440.X > 0
		local v483 = ("shown=%d buttons=%d small=%d overflow=%d outside=%d viewport=%dx%d%s%s%s"):format(v451, v452, #v455, #v453, #v454, v440.X, v440.Y, #v455 <= 0 and "" or " | SMALL " .. v482(v455), #v453 <= 0 and "" or " | OVERFLOW " .. v482(v453), #v454 <= 0 and "" or " | OUTSIDE " .. v482(v454))
		local v484 = ""
		return v483 .. v484
	end
	v_u_4._cur = v_u_16
	task.defer(function()
		-- upvalues: (ref) v_u_45, (copy) v_u_59
		if v_u_45 then
			v_u_59.refreshState(true)
		end
	end)
	task.defer(function()
		-- upvalues: (ref) v_u_45, (copy) v_u_224, (ref) v_u_53
		if v_u_45 then
			local v485 = v_u_224.select
			local v486 = v_u_53
			pcall(v485, v486, true)
		end
	end)
	function v_u_59.reloadAll() -- name: reloadAll
		-- upvalues: (copy) v_u_271, (ref) v_u_57, (ref) v_u_58
		for _, v487 in v_u_271 do
			local v488 = v487.reload
			if type(v488) ~= "function" then
				continue
			end
			local v489 = v487.reload
			pcall(v489)
		end
		if v_u_57 and v_u_57.isOpen() then
			local v490 = v_u_57.reload
			if type(v490) == "function" then
				local v491 = v_u_57.reload
				pcall(v491)
			end
		end
		if v_u_58 then
			local v492 = v_u_58.reload
			pcall(v492)
		end
	end
	return v_u_16
end
v_u_4.COMMANDS = {
	"fake",
	"scenario",
	"advance",
	"sub",
	"item",
	"sell",
	"state",
	"page",
	"audit"
}
function v_u_4.command(p493, p494, p495) -- name: command
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_7
	local v496 = v_u_4._cur
	if p494 == "fake" then
		local v497 = p495[1] ~= "off"
		v_u_5:SetAttribute("BmUiFake", v497)
		local v498 = p493.controllers.Menu
		if v498 then
			local v499 = v498.rebuild
			if type(v499) == "function" then
				task.defer(v498.rebuild)
			end
		end
		return "fake " .. (v497 and "on" or "off") .. " (the menu rebuilds)"
	end
	if not v496 then
		return "the market tab is not open (menu.tab market)"
	end
	local v500 = v496.ctx
	if p494 == "scenario" then
		if not v496.data.fakeSrv then
			return "fake data is off (market.fake on)"
		end
		local v501 = v496.data.fakeSrv:scenario(p495[1] or "normal")
		v496.data:invalidate()
		v500.refreshState(true)
		v500.reloadAll()
		if not v501 then
			return "unknown scenario"
		end
		local v502 = "scenario "
		local v503 = p495[1] or "normal"
		local v504 = tostring(v503)
		local v505
		if v496.data.fakeSrv.manyId and p495[1] == "many" then
			local v506 = v496.data.fakeSrv.manyId
			v505 = " item " .. tostring(v506)
		else
			v505 = ""
		end
		return v502 .. v504 .. v505
	end
	if p494 == "advance" then
		if not v496.data.fakeSrv then
			return "fake data is off (market.fake on)"
		end
		local v507 = v496.data.fakeSrv
		local v508 = p495[1]
		v507:advance(tonumber(v508) or 10)
		v496.data:invalidate()
		v500.refreshState(true)
		local v509 = p495[1]
		local v510 = tonumber(v509) or 10
		return "advanced " .. tostring(v510)
	end
	if p494 == "sub" then
		v496.showSub(p495[1] or "browse", p495[2])
		local v511 = p495[1] or "browse"
		return "sub " .. tostring(v511)
	end
	if p494 == "item" then
		v496.showSub("browse")
		v496.openItem(p495[1] or "")
		local v512 = p495[1]
		return "item " .. tostring(v512)
	end
	if p494 == "sell" then
		v496.showSub("sell", p495[1])
		local v513 = p495[1]
		return "sell " .. tostring(v513)
	end
	if p494 ~= "state" then
		if p494 ~= "page" then
			return p494 ~= "audit" and "unknown market command" or (not v496.audit and "no audit" or v496.audit(p495))
		end
		local v514 = p495[1] or ""
		local v515 = p495[2] or "state"
		local v516
		if v514 == "item" then
			v516 = v496.itemPage()
		else
			v516 = v496.pageOf(v514)
		end
		if v516 then
			local v517 = v516[v515]
			if type(v517) == "function" then
				local v518 = {}
				for v519 = 3, #p495 do
					local v520 = #v518 + 1
					local v521 = p495[v519]
					v518[v520] = tonumber(v521) or p495[v519]
				end
				local v522 = table.pack
				local v523 = v516[v515]
				local v524 = table.unpack
				local v525 = v522(pcall(v523, v524(v518)))
				if not v525[1] then
					local v526 = v525[2]
					return "ERROR " .. tostring(v526)
				end
				local v527 = v525[2]
				if type(v527) ~= "table" then
					return tostring(v527)
				end
				local v528 = {}
				for v529, v530 in v527 do
					if type(v530) == "table" or typeof(v530) == "Instance" then
						continue
					end
					v528[#v528 + 1] = ("%s=%s"):format(tostring(v529), (tostring(v530)))
				end
				table.sort(v528)
				return table.concat(v528, " ")
			end
		end
		return ("no function %s on page %s"):format(v515, v514)
	end
	local v531 = v500.state
	local v532 = v500.Data.chip(v531, v500.rules)
	local v533 = "sub=%s chip=%s/%s reason=%s fake=%s ds=%s buyIn=%s allow=%s banner=%s"
	local v534 = v_u_7.sub
	local v535 = tostring(v534)
	local v536 = v532.kind
	local v537 = v532.text
	local v538 = v532.reason
	local v539 = tostring(v538)
	local v540 = v500.fake
	local v541 = tostring(v540)
	local v542
	if v531 then
		v542 = v531.ds
	else
		v542 = v531
	end
	local v543 = tostring(v542)
	local v544
	if v531 then
		v544 = v531.buyIn
	else
		v544 = v531
	end
	local v545 = tostring(v544)
	local v546
	if v531 and v531.allow then
		local v547 = v531.allow.used
		local v548 = tostring(v547)
		local v549 = v531.allow.limit
		v546 = ("%s/%s"):format(v548, (tostring(v549)))
	else
		v546 = "-"
	end
	local v550 = v500.page
	return v533:format(v535, v536, v537, v539, v541, v543, v545, v546, (tostring(v550:GetAttribute("MarketBanner"))))
end
local v_u_551 = {
	["at"] = (-1 / 0),
	["busy"] = false
}
function v_u_4.prime(p_u_552) -- name: prime
	-- upvalues: (copy) v_u_551, (copy) v_u_5
	local v553 = os.clock()
	if v_u_551.busy or v553 - v_u_551.at < 120 then
		return false
	end
	local v_u_554 = "MenuMarketData"
	local v555, v_u_556 = pcall(function()
		-- upvalues: (copy) p_u_552, (copy) v_u_554
		return p_u_552.cctx.lib[v_u_554]
	end)
	if not v555 or type(v_u_556) ~= "table" then
		warn("[MenuMarket] lib missing:", "MenuMarketData", v_u_556)
		v_u_556 = nil
	end
	if v_u_556 ~= nil then
		local v557 = v_u_556.rsDot
		if type(v557) == "function" then
			v_u_551.busy = true
			v_u_551.at = v553
			task.spawn(function()
				-- upvalues: (ref) v_u_551, (copy) v_u_556, (ref) v_u_5
				local v559, v560 = pcall(function()
					local v558 = game:GetService("ReplicatedStorage"):FindFirstChild("HushNet")
					if v558 then
						v558 = v558:FindFirstChild("menu.get")
					end
					if v558 and v558:IsA("RemoteFunction") then
						return v558:InvokeServer({
							["what"] = "bmState"
						})
					else
						return nil
					end
				end)
				v_u_551.busy = false
				if v559 and (type(v560) == "table" and v560.ok ~= false) then
					v560._at = os.clock()
					local v561 = v_u_556.serverNow(v560, v560._at)
					local v562
					if v561 == nil then
						v562 = false
					else
						v562 = v_u_556.rsDot(v560.rk, v561)
					end
					v_u_5:SetAttribute("RsLive", v562 and true or nil)
				end
			end)
			return true
		end
	end
	return false
end
return v_u_4