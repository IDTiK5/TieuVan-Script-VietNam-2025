-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / AudioLoopGuard

local v_u_1 = game:GetService("Players")
local v_u_2 = {
	["LOW_ON"] = 30,
	["LOW_OFF"] = 33,
	["WATCH"] = 10,
	["SCAN"] = 1,
	["DEFAULT_CAP"] = 6,
	["FADE"] = 0.4,
	["CAPS"] = {
		["ev_heartbeat"] = 4,
		["ev_siren"] = 2.5,
		["amb_radio"] = 2.5
	},
	["PLAYER"] = {
		["ev_heartbeat"] = true,
		["ev_ringing"] = true,
		["ev_tinnitus"] = true
	},
	["WORLD"] = {
		["ev_flare_loop"] = true,
		["ev_siren"] = true,
		["ev_car_alarm"] = true,
		["ev_heli"] = true,
		["ev_heli_rotor"] = true
	},
	["CINE_END"] = {
		["flash"] = true,
		["white"] = true,
		["card"] = true,
		["leaving"] = true
	}
}
local v_u_3 = nil
local v_u_4 = {
	["heartbeatWanted"] = function() -- name: heartbeatWanted
		return false
	end,
	["ringWanted"] = function() -- name: ringWanted
		return false
	end,
	["resetEars"] = function() -- name: resetEars end
}
local v_u_5 = {
	["sweeps"] = 0,
	["swept"] = 0,
	["kills"] = 0,
	["caps"] = 0,
	["lastSweep"] = "-",
	["lastKill"] = "-"
}
local v_u_6 = {}
local v_u_7 = {}
v_u_2.EXTERNAL = {}
local v_u_8 = 0
local v_u_9 = nil
local v_u_10 = false
local v_u_11 = false
local v_u_12 = nil
function v_u_2.lowHp(p13, p14) -- name: lowHp
	-- upvalues: (copy) v_u_2
	if type(p14) == "number" and (p14 == p14 and p14 > 0) then
		if p13 then
			return p14 < v_u_2.LOW_OFF
		else
			return p14 < v_u_2.LOW_ON
		end
	else
		return false
	end
end
function v_u_2.capFor(p15, p16, p17) -- name: capFor
	-- upvalues: (copy) v_u_2
	if p17 == true then
		return nil
	elseif type(p15) == "table" and (p15.loop == true and p15.group ~= "Music") then
		local v18 = v_u_2.CAPS[p16]
		if v18 then
			return v18
		elseif string.sub(p16, 1, 4) == "amb_" then
			return nil
		else
			return v_u_2.DEFAULT_CAP
		end
	else
		return nil
	end
end
function v_u_2.legit(p19, p20, p21, p22, p23) -- name: legit
	if p21 == nil then
		return false
	end
	if p19 == "ev_heartbeat" then
		return p22.heartbeatWanted()
	end
	if p19 == "ev_ringing" then
		return p22.ringWanted()
	end
	if p19 ~= "ev_flare_loop" then
		return true
	end
	local v24 = p21.guardUntil
	if type(v24) == "number" then
		return p23 < v24
	end
	local v25
	if p21.opts then
		v25 = p21.opts.follow
	else
		v25 = p20.follow
	end
	if v25 == nil then
		return true
	end
	local v26
	if typeof(v25) == "Instance" then
		v26 = v25.Parent ~= nil
	else
		v26 = false
	end
	return v26
end
function v_u_2.register(p27, p28) -- name: register
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	if type(p27) ~= "string" or (p27 == "" or type(p28) ~= "table") then
		return false
	end
	local v29 = p28.playing
	if type(v29) == "function" then
		local v30 = p28.wanted
		if type(v30) == "function" then
			local v31 = p28.stop
			if type(v31) == "function" then
				v_u_2.EXTERNAL[p27] = p28
				v_u_7[p27] = nil
				return true
			end
		end
	end
	return false
end
function v_u_2.unregister(p32) -- name: unregister
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	v_u_2.EXTERNAL[p32] = nil
	v_u_7[p32] = nil
end
function v_u_2.scanExternal(p33) -- name: scanExternal
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (ref) v_u_5
	for v34, v35 in v_u_2.EXTERNAL do
		local v36 = v35.playing
		local v37, v38 = pcall(v36)
		local v39 = v35.wanted
		local v40, v41 = pcall(v39)
		if v37 and (v40 and (v38 == true and v41 ~= true)) then
			local v42 = v_u_7[v34]
			if v42 == nil then
				v_u_7[v34] = p33
			else
				if p33 - v42 < v_u_2.WATCH then
					continue
				end
				v_u_7[v34] = nil
				local v43 = v_u_5
				v43.kills = v43.kills + 1
				v_u_5.lastKill = v34 .. ":unwanted"
				local v44 = v35.stop
				pcall(v44, 1)
			end
		else
			v_u_7[v34] = nil
		end
	end
end
function v_u_2.sweepExternal(p45, p46) -- name: sweepExternal
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (ref) v_u_5
	local v47 = 0
	for v48, v49 in v_u_2.EXTERNAL do
		if v49.world ~= true then
			continue
		end
		local v50 = v49.playing
		local v51, v52 = pcall(v50)
		if v51 and v52 == true then
			v47 = v47 + 1
			local v53 = v49.stop
			pcall(v53, p46 or 1)
		end
		v_u_7[v48] = nil
	end
	if v47 > 0 then
		local v54 = v_u_5
		v54.sweeps = v54.sweeps + 1
		local v55 = v_u_5
		v55.swept = v55.swept + v47
		v_u_5.lastSweep = string.format("%s:%d", p45, v47)
	end
	return v47
end
function v_u_2.transitions(p56, p57, p58, p59, p60, p61, p62) -- name: transitions
	-- upvalues: (copy) v_u_2
	local v63 = {}
	if p56 and p57 ~= p58 then
		table.insert(v63, "body")
	end
	if p60 and not p59 then
		table.insert(v63, "dead")
	end
	if p62 ~= p61 and (type(p62) == "string" and v_u_2.CINE_END[p62]) then
		table.insert(v63, "raidend")
	end
	return v63
end
function v_u_2.sweep(p64, p_u_65, p66) -- name: sweep
	-- upvalues: (ref) v_u_3, (ref) v_u_5
	if not v_u_3 then
		return 0
	end
	local v_u_67 = {}
	local v_u_68 = 0
	v_u_3.stopAll(function(p69)
		-- upvalues: (copy) p_u_65, (copy) v_u_67, (ref) v_u_68
		for _, v70 in p_u_65 do
			if not v70[p69.name] then
				continue
			end
			v71 = true
		end
		local v71 = false
		if not v71 then
			return false
		end
		if not v_u_67[p69] then
			v_u_67[p69] = true
			v_u_68 = v_u_68 + 1
		end
		return true
	end, p66 or 1)
	local v72 = v_u_5
	v72.sweeps = v72.sweeps + 1
	local v73 = v_u_5
	v73.swept = v73.swept + v_u_68
	v_u_5.lastSweep = string.format("%s:%d", p64, v_u_68)
	return v_u_68
end
function v_u_2.limit(p74, p75) -- name: limit
	if type(p74) == "table" and type(p75) == "number" then
		p74.guardUntil = os.clock() + p75
	end
end
function v_u_2.onPlace(p76, _) -- name: onPlace
	-- upvalues: (copy) v_u_2, (ref) v_u_3, (ref) v_u_4
	if p76 ~= "Raid" then
		v_u_2.sweepExternal("place:" .. p76, 1)
	end
	if v_u_3 then
		if p76 == "Raid" then
			v_u_2.sweep("place:" .. p76, { v_u_2.PLAYER }, 0.3)
		else
			v_u_2.sweep("place:" .. p76, { v_u_2.PLAYER, v_u_2.WORLD }, 1)
			v_u_4.resetEars()
		end
	else
		return
	end
end
local function v_u_82(p_u_77, p78, p79) -- name: kill
	-- upvalues: (ref) v_u_5, (ref) v_u_3
	local v80 = v_u_5
	v80.kills = v80.kills + 1
	v_u_5.lastKill = string.format("%s:%s", p_u_77.name, p79)
	if p78 then
		p78:stop(1)
	else
		v_u_3.stopAll(function(p81)
			-- upvalues: (copy) p_u_77
			return p81 == p_u_77
		end, 1)
	end
end
function v_u_2.scan(p83) -- name: scan
	-- upvalues: (copy) v_u_2, (ref) v_u_3, (ref) v_u_4, (copy) v_u_6, (copy) v_u_82
	v_u_2.scanExternal(p83)
	if v_u_3 then
		local v84 = {}
		for _, v85 in v_u_3.activeVoices() do
			local v86 = v85.name
			if not v85.busy or (v85.endsAt ~= (1 / 0) or (v85.stopAfterFade or not (v_u_2.PLAYER[v86] or v_u_2.WORLD[v86]))) then
				continue
			end
			local v87 = v_u_3.bedOf(v85)
			local v88 = v87 or v85
			v84[v88] = true
			if v_u_2.legit(v86, v85, v87, v_u_4, p83) then
				v_u_6[v88] = nil
			else
				local v89 = v_u_6[v88]
				if v89 and (v87 ~= nil or v89.serial == v85.serial) then
					if p83 - v89.t < v_u_2.WATCH then
						continue
					end
					v_u_6[v88] = nil
					v_u_82(v85, v87, v87 and "bed" or "orphan")
				else
					v_u_6[v88] = {
						["t"] = p83,
						["serial"] = v85.serial
					}
				end
			end
		end
		for v90 in v_u_6 do
			if v84[v90] then
				continue
			end
			v_u_6[v90] = nil
		end
	end
end
function v_u_2.step(_) -- name: step
	-- upvalues: (ref) v_u_3, (copy) v_u_1, (copy) v_u_2, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (ref) v_u_4, (ref) v_u_8
	if v_u_3 then
		local v91 = v_u_1.LocalPlayer
		if v91 then
			local v92 = v91.Character
			local v93
			if v92 == nil then
				v93 = false
			else
				v93 = v92:GetAttribute("Dead") == true
			end
			local v94 = v91:GetAttribute("EndCine")
			local v95 = v_u_2.transitions(v_u_10, v_u_9, v92, v_u_11, v93, v_u_12, v94)
			v_u_9 = v92
			v_u_10 = true
			v_u_11 = v93
			v_u_12 = v94
			for _, v96 in v95 do
				v_u_2.sweep(v96, { v_u_2.PLAYER }, v96 == "body" and 0.3 or 1)
				v_u_4.resetEars()
			end
		end
		local v97 = os.clock()
		if v_u_8 <= v97 then
			v_u_8 = v97 + v_u_2.SCAN
			v_u_2.scan(v97)
		end
	end
end
function v_u_2.capHandle(p_u_98, p99) -- name: capHandle
	-- upvalues: (ref) v_u_5, (copy) v_u_2
	if type(p_u_98) == "table" then
		local v100 = p_u_98.stop
		if type(v100) == "function" then
			local v101 = v_u_5
			v101.caps = v101.caps + 1
			task.delay(p99, function()
				-- upvalues: (copy) p_u_98, (ref) v_u_2
				local v102 = p_u_98.stop
				local v103 = p_u_98
				local v104 = v_u_2.FADE
				pcall(v102, v103, v104)
			end)
			return
		end
	end
end
function v_u_2.stats() -- name: stats
	-- upvalues: (ref) v_u_5
	return string.format("sweeps %d swept %d kills %d caps %d | last sweep %s | last kill %s", v_u_5.sweeps, v_u_5.swept, v_u_5.kills, v_u_5.caps, v_u_5.lastSweep, v_u_5.lastKill)
end
function v_u_2.reset() -- name: reset
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (ref) v_u_5
	table.clear(v_u_6)
	table.clear(v_u_7)
	v_u_5 = {
		["sweeps"] = 0,
		["swept"] = 0,
		["kills"] = 0,
		["caps"] = 0,
		["lastSweep"] = "-",
		["lastKill"] = "-"
	}
end
function v_u_2._resetState() -- name: _resetState
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_8, (copy) v_u_6, (copy) v_u_7
	v_u_9 = nil
	v_u_10 = false
	v_u_11 = false
	v_u_12 = nil
	v_u_8 = 0
	table.clear(v_u_6)
	table.clear(v_u_7)
end
function v_u_2.init(p105, p_u_106, p107) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_2
	v_u_3 = p_u_106
	if p107 then
		v_u_4 = p107
	end
	if p105 and p105.command then
		p105.command("audio.loops", function()
			-- upvalues: (copy) p_u_106, (ref) v_u_2, (ref) v_u_4
			local v108 = os.clock()
			local v109 = {}
			for _, v110 in p_u_106.activeVoices() do
				if not v110.busy or v110.endsAt ~= (1 / 0) then
					continue
				end
				local v111 = p_u_106.bedOf(v110)
				local v112 = v110.sound
				local v113 = v_u_2.PLAYER[v110.name] or v_u_2.WORLD[v110.name]
				local v114
				if v113 then
					local v115 = v_u_2.legit
					local v116 = v110.name
					local v117 = v_u_4
					v114 = tostring(v115(v116, v110, v111, v117, v108))
				else
					v114 = "-"
				end
				local v118 = string.format
				local v119 = v110.name
				local v120 = not v112 and -1 or v112.Volume
				local v121 = v108 - v110.started
				local v122 = not (v112 and v112.SoundGroup) and "-" or v112.SoundGroup.Name
				local v123 = v110.stopAfterFade and " fading" or ""
				table.insert(v109, v118("%s vol %.2f age %.0fs %s group %s legit %s%s", v119, v120, v121, v111 and "bed" or (v113 and "ORPHAN" or "voice"), v122, v114, v123))
			end
			for v124, v125 in v_u_2.EXTERNAL do
				local v126 = v125.playing
				local v127, v128 = pcall(v126)
				local v129 = v125.wanted
				local v130, v131 = pcall(v129)
				if not v127 or v128 ~= true then
					continue
				end
				local v132 = string.format
				local v133 = "%s foreign loop wanted %s world %s"
				if v130 then
					v130 = v131 == true
				end
				local v134 = tostring(v130)
				local v135 = v125.world == true
				local v136 = tostring(v135)
				table.insert(v109, v132(v133, v124, v134, v136))
			end
			table.sort(v109)
			return #v109 <= 0 and "no looping voices" or table.concat(v109, "\n")
		end)
		p105.command("audio.guard", function(p137)
			-- upvalues: (ref) v_u_2, (copy) p_u_106
			if p137[1] == "sweep" then
				return "swept " .. v_u_2.sweep("manual", { v_u_2.PLAYER, v_u_2.WORLD }, 0.5) .. " | " .. v_u_2.stats()
			end
			if p137[1] ~= "leak" then
				return v_u_2.stats()
			end
			local v138 = p137[2] or "ev_heartbeat"
			return not p_u_106.play(v138, {
				["loop"] = true,
				["volume"] = 0.6
			}) and "no voice" or "leaked " .. v138 .. " (the watchdog stops it after " .. v_u_2.WATCH .. " s)"
		end)
	end
end
return v_u_2