-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / HideoutClan

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_11 = {
	["THICK"] = 0.3,
	["WALLS"] = {
		{
			["face"] = "E",
			["name"] = "ClanBanner",
			["x"] = 35.85,
			["y"] = 6.2,
			["z"] = -18,
			["yaw"] = 90,
			["w"] = 7,
			["h"] = 3
		},
		{
			["face"] = "W",
			["name"] = "ClanBannerW",
			["x"] = -35.85,
			["y"] = 6,
			["z"] = -8,
			["yaw"] = -90,
			["w"] = 7,
			["h"] = 3
		},
		{
			["face"] = "S",
			["name"] = "ClanBannerS",
			["x"] = -9.5,
			["y"] = 6.2,
			["z"] = 29.85,
			["yaw"] = 0,
			["w"] = 7,
			["h"] = 3
		},
		{
			["face"] = "N",
			["name"] = "ClanBannerN",
			["x"] = 34.35,
			["y"] = 6.2,
			["z"] = -29.85,
			["yaw"] = 180,
			["w"] = 2.9,
			["h"] = 1.8
		}
	},
	["CF"] = CFrame.new(35.85, 6.2, -18) * CFrame.Angles(0, 1.5707963267948966, 0),
	["SIZE"] = Vector3.new(7, 3, 0.3),
	["NAME_MAX"] = 20,
	["cfOf"] = function(p3) -- name: cfOf
		local v4 = CFrame.new(p3.x, p3.y, p3.z)
		local v5 = CFrame.Angles
		local v6 = p3.yaw
		return v4 * v5(0, math.rad(v6), 0)
	end,
	["sizeOf"] = function(p7) -- name: sizeOf
		-- upvalues: (copy) v_u_11
		local v8 = p7.w
		local v9 = p7.h
		local v10 = v_u_11.THICK
		return Vector3.new(v8, v9, v10)
	end
}
local v_u_12 = {
	["signs"] = nil,
	["conn"] = nil,
	["cctx"] = nil,
	["token"] = 0,
	["clan"] = nil,
	["attrConns"] = nil,
	["anim"] = nil,
	["lastStyle"] = nil,
	["signs"] = {},
	["attrConns"] = {}
}
v_u_11.BANNERS = {
	{
		["bg"] = { 22, 27, 34 },
		["edge"] = { 232, 163, 61 }
	},
	{
		["bg"] = { 14, 18, 22 },
		["edge"] = { 140, 152, 166 }
	},
	{
		["bg"] = { 28, 18, 18 },
		["edge"] = { 214, 84, 72 }
	},
	{
		["bg"] = { 16, 26, 20 },
		["edge"] = { 96, 190, 120 }
	},
	{
		["bg"] = { 14, 20, 32 },
		["edge"] = { 86, 150, 236 }
	},
	{
		["bg"] = { 26, 20, 32 },
		["edge"] = { 170, 122, 236 }
	}
}
v_u_11.TRIMS = { 3, 6, 9 }
v_u_11.MEDAL_PX = 26
function v_u_11.look(p13) -- name: look
	-- upvalues: (copy) v_u_11
	if type(p13) ~= "table" then
		return nil
	end
	local v14 = p13.banner
	local v15 = type(v14) ~= "table" and {} or p13.banner
	local v16 = v_u_11.BANNERS
	local v17 = v15.id
	local v18 = v16[type(v17) ~= "number" and 1 or v15.id] or v_u_11.BANNERS[1]
	local v19 = p13.brackets
	local v20 = type(v19) ~= "table" and { "[", "]" } or p13.brackets
	local v21 = v_u_11.TRIMS
	local v22 = v15.trim
	local v23 = v21[type(v22) ~= "number" and 1 or v15.trim] or v_u_11.TRIMS[1]
	local v24 = {
		["open"] = v20[1],
		["close"] = v20[2]
	}
	local v25 = p13.color
	local v26
	if type(v25) == "table" and #p13.color > 0 then
		v26 = p13.color
	else
		v26 = nil
	end
	v24.hexes = v26
	v24.grad = p13.grad == true
	v24.anim = p13.anim == true
	v24.bg = v18.bg
	v24.edge = v18.edge
	v24.trim = v23
	local v27 = p13.medal
	local v28
	if type(v27) == "number" then
		v28 = p13.medal
	else
		v28 = nil
	end
	v24.medal = v28
	return v24
end
local function v_u_34(p_u_29, p_u_30) -- name: validTag
	local v31, v32 = pcall(function()
		-- upvalues: (copy) p_u_29, (copy) p_u_30
		return p_u_29.shared.ClanTag.valid(p_u_30)
	end)
	if v31 then
		return v32 == true
	end
	local v33
	if type(p_u_30) == "string" and (#p_u_30 >= 3 and (#p_u_30 <= 4 and string.find(p_u_30, "^[A-Z0-9]+$") ~= nil)) then
		v33 = string.find(p_u_30, "[A-Z]") ~= nil
	else
		v33 = false
	end
	return v33
end
function v_u_11.plate(p35, p36) -- name: plate
	-- upvalues: (copy) v_u_34, (copy) v_u_11
	if type(p35) ~= "table" then
		return nil
	end
	local v37 = p35.tag
	local v38
	if p36 then
		v38 = v_u_34(p36, v37)
	elseif type(v37) == "string" and (#v37 >= 3 and (#v37 <= 4 and string.find(v37, "^[A-Z0-9]+$") ~= nil)) then
		v38 = string.find(v37, "[A-Z]") ~= nil
	else
		v38 = false
	end
	if not v38 then
		return nil
	end
	local v39 = p35.name
	local v40 = type(v39) ~= "string" and "" or p35.name
	local v41 = string.gsub(v40, "[%c]", " ")
	local v42 = v_u_11.NAME_MAX
	local v43 = {
		["tag"] = v37,
		["name"] = string.sub(v41, 1, v42)
	}
	local v44 = p35.id
	v43.cid = type(v44) ~= "string" and "" or p35.id
	return v43
end
local function v_u_62(p45, p46, p47, p48, p49, p50, p51) -- name: applySign
	local v52 = p45.tagL
	local v53 = p45.nameL
	local v54 = p45.frame
	local v55 = p45.stroke
	local v56 = p45.grad
	local v57 = p45.tagStroke
	local v58 = p45.medalF
	v53.Text = p46.name
	v52.TextTransparency = 0
	if p47 == nil then
		v52.Text = "[" .. p46.tag .. "]"
		v52.TextColor3 = p48 or Color3.fromRGB(232, 163, 61)
		if v56 then
			v56.Enabled = false
		end
		if v57 then
			v57.Enabled = false
		end
		if v54 then
			v54.BackgroundColor3 = Color3.fromRGB(22, 27, 34)
		end
		if v55 then
			v55.Color = Color3.fromRGB(232, 163, 61)
			v55.Thickness = 3
		end
		if v58 then
			v58.Visible = false
		end
	else
		v52.Text = p47.open .. p46.tag .. p47.close
		if v54 then
			v54.BackgroundColor3 = Color3.fromRGB(p47.bg[1], p47.bg[2], p47.bg[3])
		end
		if v55 then
			v55.Color = Color3.fromRGB(p47.edge[1], p47.edge[2], p47.edge[3])
			v55.Thickness = p47.trim
		end
		local v_u_59 = p47.hexes
		if v_u_59 == nil or (v56 == nil or (not p47.grad or (#v_u_59 <= 1 or p49 == nil))) then
			if v56 then
				v56.Enabled = false
			end
			local v60, v61 = pcall(function()
				-- upvalues: (copy) v_u_59
				return Color3.fromHex(v_u_59[1])
			end)
			if v_u_59 == nil or not v60 then
				v52.TextColor3 = p48 or Color3.fromRGB(232, 163, 61)
			else
				v52.TextColor3 = v61
			end
		else
			v56.Color = p49
			v56.Enabled = true
			v52.TextColor3 = Color3.new(1, 1, 1)
		end
		if v57 then
			v57.Enabled = v_u_59 ~= nil
			v57.Transparency = p50
		end
		if v58 then
			v58.Visible = p51 ~= nil
			if p51 ~= nil then
				v58.BackgroundColor3 = p51
			end
		end
	end
end
local function v_u_108(p_u_63) -- name: paint
	-- upvalues: (copy) v_u_12, (copy) v_u_11, (copy) v_u_2, (copy) v_u_62
	local v64 = v_u_12.signs
	if #v64 == 0 then
		return
	else
		local v65 = v_u_11.plate(v_u_12.clan, p_u_63)
		local v66 = v_u_12
		local function v69()
			-- upvalues: (copy) p_u_63, (ref) v_u_2
			local v67 = p_u_63.lib.ClanTagText
			local v68 = v_u_2.LocalPlayer
			if v67 == nil or (v68 == nil or v67.styleOf == nil) then
				return nil
			else
				return v67.styleOf(v68)
			end
		end
		local v70, v71 = pcall(v69)
		if not v70 then
			v71 = nil
		end
		v66.lastStyle = v71
		if v_u_12.anim ~= nil then
			local function v72()
				-- upvalues: (ref) v_u_12
				v_u_12.anim:Disconnect()
			end
			pcall(v72)
			v_u_12.anim = nil
		end
		local v_u_73 = {}
		for _, v74 in v64 do
			if not (v74.part and v74.part.Parent) then
				continue
			end
			v74.part.Transparency = v65 and 0 or 1
			v74.gui.Enabled = v65 ~= nil
			table.insert(v_u_73, v74)
		end
		if v65 and #v_u_73 ~= 0 then
			local v75 = v_u_11.look(v_u_12.lastStyle)
			local v_u_76 = v65.cid
			local v_u_77 = nil
			local function v79()
				-- upvalues: (copy) p_u_63, (copy) v_u_76, (ref) v_u_77
				local v78 = p_u_63.shared.ClanTag.color(v_u_76, 0.55, 0.95)
				if typeof(v78) == "Color3" then
					v_u_77 = v78
				end
			end
			pcall(v79)
			local v80 = v_u_77
			local v_u_81 = nil
			local v_u_82 = 0.35
			local v83 = nil
			local v84
			if v75 == nil then
				v84 = v83
			else
				local v_u_85 = v75.hexes
				if v_u_85 ~= nil and (v75.grad and #v_u_85 > 1) then
					pcall(function()
						-- upvalues: (copy) v_u_85, (ref) v_u_81
						local v86 = {}
						for v87, v88 in v_u_85 do
							local v89 = ColorSequenceKeypoint.new
							local v90 = (v87 - 1) / (#v_u_85 - 1)
							local v91 = Color3.fromHex
							table.insert(v86, v89(v90, v91(v88)))
						end
						v_u_81 = ColorSequence.new(v86)
					end)
				end
				local function v93()
					-- upvalues: (copy) p_u_63, (ref) v_u_12, (ref) v_u_82
					local v92 = p_u_63.lib.ClanTagText.outline(v_u_12.lastStyle)
					if type(v92) == "number" then
						v_u_82 = v92
					end
				end
				pcall(v93)
				local v94, v95 = pcall(function()
					-- upvalues: (copy) p_u_63
					return p_u_63.shared.ClanStyle.MEDALS
				end)
				local v_u_96
				if v94 and (type(v95) == "table" and v75.medal) then
					v_u_96 = v95[v75.medal]
				else
					v_u_96 = nil
				end
				if v_u_96 == nil then
					v84 = v83
				else
					local v97
					v97, v84 = pcall(function()
						-- upvalues: (copy) v_u_96
						return Color3.fromHex(v_u_96)
					end)
					if not v97 then
						v84 = v83
					end
				end
			end
			for _, v98 in v_u_73 do
				v_u_62(v98, v65, v75, v80, v_u_81, v_u_82, v84)
			end
			if v75 ~= nil and v75.anim then
				local v_u_99 = 0
				local v_u_100 = os.clock()
				local v101, v102 = pcall(function()
					return game:GetService("RunService")
				end)
				if v101 then
					v_u_12.anim = v102.Heartbeat:Connect(function(p103)
						-- upvalues: (ref) v_u_99, (copy) p_u_63, (ref) v_u_12, (copy) v_u_100, (copy) v_u_73
						v_u_99 = v_u_99 + p103
						if v_u_99 >= 0.03333333333333333 then
							v_u_99 = 0
							local v_u_104 = 0
							local function v105()
								-- upvalues: (ref) v_u_104, (ref) p_u_63, (ref) v_u_12, (ref) v_u_100
								v_u_104 = p_u_63.lib.ClanTagText.animAlpha(v_u_12.lastStyle, os.clock() - v_u_100)
							end
							pcall(v105)
							local v106 = v_u_104
							for _, v107 in v_u_73 do
								if not v107.tagL.Parent then
									continue
								end
								v107.tagL.TextTransparency = v106
							end
						end
					end)
				end
			end
		end
	end
end
function v_u_11.destroy() -- name: destroy
	-- upvalues: (copy) v_u_12
	local v109 = v_u_12
	v109.token = v109.token + 1
	if v_u_12.conn then
		local v110 = v_u_12.conn
		if typeof(v110) == "RBXScriptConnection" then
			v_u_12.conn:Disconnect()
		else
			local v111 = v_u_12.conn
			if type(v111) == "function" then
				local v112 = v_u_12.conn
				pcall(v112)
			end
		end
		v_u_12.conn = nil
	end
	for _, v113 in v_u_12.signs do
		if not v113.part then
			continue
		end
		v113.part:Destroy()
	end
	if v_u_12.anim ~= nil then
		local function v114()
			-- upvalues: (ref) v_u_12
			v_u_12.anim:Disconnect()
		end
		pcall(v114)
		v_u_12.anim = nil
	end
	for _, v_u_115 in v_u_12.attrConns do
		pcall(function()
			-- upvalues: (copy) v_u_115
			v_u_115:Disconnect()
		end)
	end
	v_u_12.attrConns = {}
	v_u_12.signs = {}
	local v116 = v_u_12
	local v117 = v_u_12
	v_u_12.clan = nil
	v116.cctx = nil
	v117.lastStyle = nil
end
local function v_u_147(p118, p119, p_u_120) -- name: buildSign
	-- upvalues: (copy) v_u_11, (copy) v_u_1
	local v121 = p_u_120.w
	local v122 = p_u_120.h
	local v_u_123 = Instance.new("Part")
	v_u_123.Name = p_u_120.name
	v_u_123.Anchored = true
	v_u_123.CanCollide = false
	v_u_123.CanTouch = false
	v_u_123.CanQuery = false
	v_u_123.CastShadow = false
	v_u_123.Size = v_u_11.sizeOf(p_u_120)
	v_u_123.CFrame = CFrame.new(p119) * v_u_11.cfOf(p_u_120)
	v_u_123.Color = Color3.fromRGB(30, 34, 38)
	v_u_123.Material = Enum.Material.Metal
	v_u_123.Transparency = 1
	v_u_123.TopSurface = Enum.SurfaceType.Smooth
	v_u_123.BottomSurface = Enum.SurfaceType.Smooth
	local function v124()
		-- upvalues: (copy) v_u_123, (copy) p_u_120, (ref) v_u_1
		v_u_123:SetAttribute("BuildingId", "hideout")
		v_u_123:SetAttribute("Face", p_u_120.face)
		v_u_123:SetAttribute("Cut", true)
		v_u_1:AddTag(v_u_123, "HushWall")
	end
	pcall(v124)
	local v125 = Instance.new("SurfaceGui")
	v125.Name = "ClanBannerGui"
	v125.Face = Enum.NormalId.Front
	v125.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	v125.PixelsPerStud = 50
	v125.LightInfluence = 0.3
	v125.Enabled = false
	v125.Parent = v_u_123
	local v126 = Instance.new("Frame")
	v126.Name = "Plate"
	v126.BackgroundColor3 = Color3.fromRGB(22, 27, 34)
	v126.BackgroundTransparency = 0.05
	v126.BorderSizePixel = 0
	v126.Size = UDim2.fromScale(1, 1)
	v126.Parent = v125
	local v127 = Instance.new("UIStroke")
	v127.Color = Color3.fromRGB(232, 163, 61)
	v127.Thickness = 3
	v127.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v127.Parent = v126
	local v128 = Instance.new("TextLabel")
	v128.Name = "Tag"
	v128.BackgroundTransparency = 1
	v128.Size = UDim2.new(1, -24, 0.62, 0)
	v128.Position = UDim2.fromOffset(12, 6)
	v128.Font = Enum.Font.GothamBlack
	v128.TextScaled = true
	v128.TextColor3 = Color3.fromRGB(232, 163, 61)
	v128.Text = ""
	v128.Parent = v126
	local v129 = Instance.new("TextLabel")
	v129.Name = "ClanName"
	v129.BackgroundTransparency = 1
	v129.Size = UDim2.new(1, -24, 0.24, 0)
	v129.Position = UDim2.new(0, 12, 0.68, 0)
	v129.Font = Enum.Font.GothamMedium
	v129.TextScaled = true
	v129.TextColor3 = Color3.fromRGB(230, 232, 235)
	v129.Text = ""
	v129.Parent = v126
	for _, v130 in { v128, v129 } do
		local v131 = Instance.new("UITextSizeConstraint")
		v131.MaxTextSize = v130 == v128 and 110 or 40
		v131.MinTextSize = 8
		v131.Parent = v130
	end
	local v132 = Instance.new("UIGradient")
	v132.Enabled = false
	v132.Parent = v128
	local v133 = Instance.new("UIStroke")
	v133.Color = Color3.new(0, 0, 0)
	v133.Thickness = 1
	v133.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
	v133.Enabled = false
	v133.Parent = v128
	local v134 = v_u_11.MEDAL_PX
	local v135 = v121 / 7
	local v136 = v134 * math.min(1, v135) + 0.5
	local v137 = math.floor(v136)
	local v138 = math.max(10, v137)
	local v139 = Instance.new("Frame")
	v139.Name = "Medal"
	v139.BorderSizePixel = 0
	v139.AnchorPoint = Vector2.new(1, 0)
	local v140 = UDim2.new
	local v141 = v121 * 2
	local v142 = math.floor(v141)
	local v143 = -math.min(14, v142)
	local v144 = v122 * 5
	local v145 = math.floor(v144)
	v139.Position = v140(1, v143, 0, (math.min(14, v145)))
	v139.Size = UDim2.fromOffset(v138, v138)
	v139.Visible = false
	v139.Parent = v126
	local v146 = Instance.new("UICorner")
	v146.CornerRadius = UDim.new(1, 0)
	v146.Parent = v139
	v_u_123.Parent = p118
	return {
		["wall"] = p_u_120,
		["part"] = v_u_123,
		["gui"] = v125,
		["frame"] = v126,
		["stroke"] = v127,
		["tagL"] = v128,
		["nameL"] = v129,
		["grad"] = v132,
		["tagStroke"] = v133,
		["medalF"] = v139
	}
end
function v_u_11.build(p_u_148, p149, p150, _) -- name: build
	-- upvalues: (copy) v_u_11, (copy) v_u_12, (copy) v_u_147, (copy) v_u_2, (copy) v_u_108, (copy) v_u_34
	v_u_11.destroy()
	local v_u_151 = false
	local function v152()
		-- upvalues: (ref) v_u_151, (copy) p_u_148
		v_u_151 = p_u_148.shared.GameMode.rule("clans") == true
	end
	pcall(v152)
	if v_u_151 then
		v_u_12.cctx = p_u_148
		for _, v153 in v_u_11.WALLS do
			local v154 = v_u_12.signs
			local v155 = v_u_147(p149, p150, v153)
			table.insert(v154, v155)
		end
		local function v161()
			-- upvalues: (ref) v_u_2, (ref) v_u_12, (ref) v_u_108, (copy) p_u_148
			local v156 = v_u_2.LocalPlayer
			if v156 ~= nil then
				for _, v157 in { "ClanStyle", "ShowClanColors" } do
					local v158 = v_u_12.attrConns
					local v159 = v156:GetAttributeChangedSignal(v157)
					local function v160()
						-- upvalues: (ref) v_u_108, (ref) p_u_148
						v_u_108(p_u_148)
					end
					table.insert(v158, v159:Connect(v160))
				end
			end
		end
		pcall(v161)
		local function v165()
			-- upvalues: (copy) p_u_148, (ref) v_u_12, (ref) v_u_108
			return p_u_148.net.listen("menu.state", function(p162)
				-- upvalues: (ref) v_u_12, (ref) v_u_108, (ref) p_u_148
				if type(p162) == "table" then
					local v163 = p162.profile
					if type(v163) == "table" then
						local v164 = v163.clan
						if type(v164) == "table" then
							v_u_12.clan = v163.clan
							v_u_108(p_u_148)
						else
							if type(v163) == "table" then
								v_u_12.clan = nil
							end
							v_u_108(p_u_148)
						end
					else
						if type(v163) == "table" then
							v_u_12.clan = nil
						end
						v_u_108(p_u_148)
					end
				end
			end)
		end
		local v166, v167 = pcall(v165)
		if v166 then
			v_u_12.conn = v167
		end
		local v168 = v_u_12
		v168.token = v168.token + 1
		local v_u_169 = v_u_12.token
		task.spawn(function()
			-- upvalues: (copy) p_u_148, (ref) v_u_12, (copy) v_u_169, (ref) v_u_108, (ref) v_u_2, (ref) v_u_34
			local v170 = p_u_148.net.invoke
			local v171, v172 = pcall(v170, "menu.get", {
				["what"] = "profile"
			})
			if v_u_12.token ~= v_u_169 or (not v171 or type(v172) ~= "table") then
				local v173 = v_u_2.LocalPlayer
				if v173 then
					v173 = v_u_2.LocalPlayer:GetAttribute("ClanTag")
				end
				if v_u_12.token == v_u_169 and v_u_34(p_u_148, v173) then
					v_u_12.clan = {
						["tag"] = nil,
						["name"] = "",
						["id"] = nil,
						["tag"] = v173,
						["id"] = v_u_2.LocalPlayer:GetAttribute("ClanId")
					}
					v_u_108(p_u_148)
				end
				return
			end
			if type(v172) == "table" then
				local v174 = v172.clan
				if type(v174) == "table" then
					v_u_12.clan = v172.clan
					v_u_108(p_u_148)
				else
					if type(v172) == "table" then
						v_u_12.clan = nil
					end
					v_u_108(p_u_148)
				end
			else
				if type(v172) == "table" then
					v_u_12.clan = nil
				end
				v_u_108(p_u_148)
				return
			end
		end)
	end
end
return v_u_11