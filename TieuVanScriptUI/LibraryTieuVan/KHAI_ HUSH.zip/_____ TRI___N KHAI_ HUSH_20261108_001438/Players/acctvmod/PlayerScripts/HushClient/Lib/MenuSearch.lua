-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MenuSearch

local v_u_1
if script and (script.Parent and script.Parent:FindFirstChild("ServerClock")) then
	v_u_1 = require(script.Parent.ServerClock)
else
	v_u_1 = {
		["now"] = function() -- name: now
			return workspace:GetServerTimeNow()
		end
	}
end
local v_u_2 = {
	["REGION_NAMES"] = {
		["NA"] = "North America",
		["SA"] = "South America",
		["EU"] = "Europe",
		["AS"] = "Asia",
		["OC"] = "Oceania",
		["MEA"] = "Middle East & Africa"
	},
	["FOUND_HOLD"] = 1.6,
	["SEATS_FALLBACK"] = 12
}
local v_u_3 = nil
local v_u_4 = (-1 / 0)
function v_u_2.fallbackSeats() -- name: fallbackSeats
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_2
	if v_u_3 == nil and os.clock() - v_u_4 >= 5 then
		v_u_4 = os.clock()
		local function v6()
			-- upvalues: (ref) v_u_3
			local v5 = game:GetService("ReplicatedStorage").Hush.Shared
			v_u_3 = {
				["RS"] = require(v5.RaidSize),
				["C"] = require(v5.Config),
				["GM"] = require(v5.GameMode)
			}
		end
		pcall(v6)
	end
	if v_u_3 then
		local v7 = v_u_3.RS.max
		local v8 = v_u_3.C
		local v9 = v_u_3.GM
		local v10, v11 = pcall(v7, v8, v9)
		if v10 and type(v11) == "number" then
			return v11
		end
	end
	return v_u_2.SEATS_FALLBACK
end
function v_u_2.setSizeSource(p12, p13, p14) -- name: setSizeSource
	-- upvalues: (ref) v_u_3, (ref) v_u_4
	v_u_3 = p12 ~= nil and {
		["RS"] = p12,
		["C"] = p13,
		["GM"] = p14
	} or nil
	v_u_4 = (-1 / 0)
end
function v_u_2.seatsFor(p15) -- name: seatsFor
	-- upvalues: (copy) v_u_2, (ref) v_u_3
	local v16 = v_u_2.fallbackSeats()
	if v_u_3 then
		local v17 = v_u_3.RS.cap
		local v18, v19 = pcall(v17, p15, v16)
		if v18 and type(v19) == "number" then
			return v19
		end
	end
	return v16
end
local v_u_20 = {
	["depKey"] = nil,
	["depAt"] = 0,
	["searchKey"] = nil,
	["own"] = (1 / 0),
	["startAt"] = nil,
	["seenAt"] = nil
}
v_u_2.WAIT_SLACK = 8
v_u_2.WAIT_CAP = 300
function v_u_2.now() -- name: now
	-- upvalues: (copy) v_u_1
	return v_u_1.now()
end
v_u_2.CLOCK_MAX = 5999
function v_u_2.clock(p21) -- name: clock
	-- upvalues: (copy) v_u_2
	local v22 = tonumber(p21) or 0
	local v23
	if v22 == v22 then
		local v24 = math.ceil(v22)
		local v25 = v_u_2.CLOCK_MAX
		v23 = math.clamp(v24, 0, v25)
	else
		v23 = 0
	end
	return ("%d:%02d"):format(v23 // 60, v23 % 60)
end
function v_u_2.state(p26) -- name: state
	-- upvalues: (copy) v_u_20, (copy) v_u_2
	if type(p26) ~= "table" then
		v_u_20.depKey = nil
		return nil
	end
	local v27 = p26.searching
	if type(v27) ~= "table" then
		local v28 = p26.deploying
		if type(v28) ~= "table" or v28.tutorial == true then
			v_u_20.depKey = nil
			return nil
		end
		local v29 = v28.match
		local v30
		if type(v29) == "table" then
			v30 = v28.match
		else
			v30 = nil
		end
		local v31 = v28.squadId
		local v32 = tostring(v31)
		local v33 = v28.at
		local v34 = v32 .. "|" .. tostring(v33)
		if v_u_20.depKey ~= v34 then
			v_u_20.depKey = v34
			v_u_20.depAt = os.clock()
		end
		local v35
		if v30 == nil then
			v35 = false
		else
			v35 = v30.k == "new" and true or v30.k == "join"
		end
		local v36 = {
			["phase"] = nil,
			["remaining"] = 0,
			["total"] = 1,
			["frac"] = 0,
			["found"] = nil,
			["seats"] = nil,
			["squads"] = nil,
			["region"] = nil,
			["regionName"] = nil,
			["match"] = nil,
			["phase"] = v35 and os.clock() - v_u_20.depAt < v_u_2.FOUND_HOLD and "found" or "deploying"
		}
		local v37
		if v30 then
			local v38 = v30.t
			v37 = tonumber(v38)
		else
			v37 = nil
		end
		v36.found = v37
		v36.seats = v_u_2.fallbackSeats()
		local v39
		if v30 then
			local v40 = v30.s
			v39 = tonumber(v40)
		else
			v39 = nil
		end
		v36.squads = v39
		local v41
		if v30 then
			v41 = v30.region
		else
			v41 = nil
		end
		v36.region = v41
		local v42
		if v30 then
			local v43 = v30.region
			if type(v43) == "string" then
				v42 = v_u_2.REGION_NAMES[v43]
			else
				v42 = nil
			end
		else
			v42 = nil
		end
		v36.regionName = v42
		v36.match = v30
		return v36
	end
	v_u_20.depKey = nil
	local v44 = v_u_2.now()
	local v45 = v27.since
	local v46 = tonumber(v45) or v44
	local v47 = v27.since
	local v48 = tostring(v47)
	if v_u_20.searchKey ~= v48 then
		v_u_20.searchKey = v48
		v_u_20.own = (1 / 0)
		v_u_20.startAt = nil
		v_u_20.seenAt = nil
	end
	local v49 = v27.own
	local v50 = tonumber(v49)
	if not v50 then
		local v51 = v27.wait
		v50 = v46 + (tonumber(v51) or 0)
	end
	if v50 < v_u_20.own then
		v_u_20.own = v50
	end
	local v52 = v_u_20.own
	local v53 = v52 - v44
	local v54 = math.max(0, v53)
	local v55 = v52 - v46
	local v56 = math.max(1, v55)
	local v57 = v27.wait
	local v58 = tonumber(v57)
	local v59
	if v58 and v58 > 0 then
		v59 = v58
	else
		v59 = v_u_2.WAIT_CAP
	end
	local v60 = v59 + v_u_2.WAIT_SLACK
	local v61
	if v54 <= v60 then
		v61 = v56 <= v60 + 1
	else
		v61 = false
	end
	if v61 then
		v_u_20.seenAt = nil
	else
		v_u_20.seenAt = v_u_20.seenAt or os.clock()
		if not v58 or v58 <= 0 then
			v58 = v_u_2.WAIT_CAP
		end
		local v62 = v58 - (os.clock() - v_u_20.seenAt)
		v54 = math.max(0, v62)
		v56 = math.max(1, v58)
	end
	local v63 = v27.deadline
	local v64 = tonumber(v63)
	local v65
	if v61 and (v64 and (v64 < v52 - 0.75 and (v64 - v44 > 0 and v64 - v44 <= v60))) then
		v65 = v64 - v44
	else
		v65 = nil
	end
	local v66 = v54 > 0 and "searching" or "starting"
	if v66 == "starting" then
		v_u_20.startAt = v_u_20.startAt or os.clock()
	else
		v_u_20.startAt = nil
	end
	local v67 = v27.found
	local v68 = tonumber(v67)
	local v69 = {
		["phase"] = v66,
		["remaining"] = v54,
		["soon"] = v65,
		["total"] = v56
	}
	local v70 = v54 / v56
	v69.frac = math.clamp(v70, 0, 1)
	v69.startedFor = not v_u_20.startAt and 0 or os.clock() - v_u_20.startAt
	v69.found = v68
	local v71 = v27.seats
	v69.seats = tonumber(v71) or v_u_2.fallbackSeats()
	local v72 = v27.squads
	v69.squads = tonumber(v72)
	v69.region = v27.region
	local v73 = v27.region
	local v74
	if type(v73) == "string" then
		v74 = v_u_2.REGION_NAMES[v73]
	else
		v74 = nil
	end
	v69.regionName = v74
	v69.rookie = v27.rookie == true
	return v69
end
function v_u_2.found(p75) -- name: found
	-- upvalues: (copy) v_u_2
	if type(p75) == "table" then
		local v76 = p75.found
		if tonumber(v76) then
			local v77 = p75.found
			local v78 = p75.seats
			return ("%d / %d"):format(v77, tonumber(v78) or v_u_2.fallbackSeats())
		end
	end
	return nil
end
function v_u_2.matchLine(p79) -- name: matchLine
	-- upvalues: (copy) v_u_2
	if type(p79) == "table" then
		local v80 = p79.k
		if type(v80) == "string" then
			local v81 = p79.region
			local v82
			if type(v81) == "string" then
				v82 = v_u_2.REGION_NAMES[v81]
			else
				v82 = nil
			end
			local v83 = not v82 and "" or "  \194\183  " .. v82
			if p79.k == "new" then
				local v84 = p79.s
				local v85 = (tonumber(v84) or 0) - 1
				if v85 >= 1 then
					return ("Joining a raid with %d other squad%s%s"):format(v85, v85 == 1 and "" or "s", v83)
				else
					local v86 = p79.t
					local v87 = tonumber(v86)
					if v87 and v87 > 0 then
						return ("Joining a raid with %d survivors%s"):format(v87, v83)
					else
						return "Joining a raid with other squads" .. v83
					end
				end
			elseif p79.k == "join" then
				return "Joining a raid in progress" .. v83
			else
				return "Starting a new raid" .. v83
			end
		end
	end
	return nil
end
return v_u_2