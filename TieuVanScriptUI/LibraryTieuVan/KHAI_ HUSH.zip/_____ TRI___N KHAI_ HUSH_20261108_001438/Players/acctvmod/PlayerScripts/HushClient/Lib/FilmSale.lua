-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / FilmSale

local v1 = game:GetService("Players")
local v_u_2 = require(script.Parent:WaitForChild("HushUI"))
local v_u_3 = v_u_2.Theme
local v_u_4 = v_u_3.color
local v_u_5 = {}
local v_u_6 = v1.LocalPlayer
v_u_5.PRODUCTS = {
	{
		["id"] = "bundle_minigun",
		["title"] = "MINIGUN BUNDLE",
		["short"] = "MINIGUN"
	},
	{
		["id"] = "bundle_nvg_raid",
		["title"] = "NVG DUAL + RAID PACK",
		["short"] = "NVG + RAID"
	},
	{
		["id"] = "bundle_katana_vial",
		["title"] = "KATANA + VIAL PACK",
		["short"] = "KATANA + VIAL"
	}
}
function v_u_5.lines(p7) -- name: lines
	-- upvalues: (copy) v_u_5
	local v8 = {}
	if type(p7) == "table" then
		local v9 = p7.sales
		if type(v9) == "table" then
			for _, v10 in v_u_5.PRODUCTS do
				local v11 = p7.sales[v10.id]
				if type(v11) ~= "table" then
					continue
				end
				local v12 = v11.state == "running" and "ok" or (v11.state == "ended" and "warn" or "muted")
				local v13 = {
					["name"] = "State_" .. v10.id
				}
				local v14 = v10.title
				local v15 = v11.line or v11.state
				v13.text = ("%s  %s"):format(v14, (tostring(v15)))
				v13.kind = v12
				table.insert(v8, v13)
				if v11.state ~= "running" then
					continue
				end
				local v16 = v11.left
				if type(v16) ~= "number" then
					continue
				end
				local v17 = {
					["name"] = nil,
					["text"] = nil,
					["kind"] = "text",
					["name"] = "Left_" .. v10.id
				}
				local v18 = "Ends in "
				local v19 = v11.left
				local v20
				if type(v19) == "number" and (v19 == v19 and (v19 > 0 and v19 ~= (1 / 0))) then
					local v21 = v19 - 1e-9
					v20 = math.ceil(v21)
				else
					v20 = 0
				end
				v17.text = v18 .. ("%02d:%02d:%02d"):format(v20 // 3600, v20 % 3600 // 60, v20 % 60) .. " (server time)"
				table.insert(v8, v17)
			end
			if #v8 == 0 then
				return v8
			end
			local v22 = {
				["name"] = "Store",
				["text"] = nil,
				["kind"] = nil
			}
			local v23 = p7.backend
			local v24 = tostring(v23)
			local v25 = p7.v
			local v26 = tostring(v25)
			local v27 = p7.good and "OK" or "NOT YET (the bundle stays COMING SOON)"
			local v28 = p7.claimed
			v22.text = ("store %s  \194\183  v%s  \194\183  read %s%s"):format(v24, v26, v27, type(v28) == "number" and p7.claimed > 0 and "  \194\183  this server started the window" or "")
			v22.kind = p7.good and "muted" or "warn"
			table.insert(v8, v22)
			return v8
		end
	end
	return v8
end
function v_u_5.build(p_u_29) -- name: build
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6
	local v_u_30 = p_u_29.body
	local v_u_31 = p_u_29.api
	local v_u_32 = true
	p_u_29.gui.Destroying:Connect(function()
		-- upvalues: (ref) v_u_32
		v_u_32 = false
	end)
	local v_u_33 = #v_u_5.PRODUCTS
	v_u_2.label({
		["parent"] = nil,
		["text"] = "Store sale  \194\183  limited time products",
		["style"] = "caps",
		["color"] = nil,
		["size"] = nil,
		["parent"] = v_u_30,
		["color"] = v_u_4.accent,
		["size"] = UDim2.new(1, 0, 0, 22)
	}).LayoutOrder = p_u_29.order()
	local v_u_34 = v_u_2.new("Frame", {
		["Name"] = "SaleList",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}, v_u_30)
	v_u_2.layout(v_u_34, "v", 2)
	v_u_34.LayoutOrder = p_u_29.order()
	local v35 = v_u_2.new("Frame", {
		["Name"] = "SaleSelBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_3.touch(32))
	}, v_u_30)
	v35.LayoutOrder = p_u_29.order()
	v_u_2.layout(v35, "h", 6)
	local v_u_36 = v_u_2.new("Frame", {
		["Name"] = "SaleBar",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_3.touch(32))
	}, v_u_30)
	v_u_36.LayoutOrder = p_u_29.order()
	v_u_2.layout(v_u_36, "h", 6)
	local v_u_37 = v_u_2.label({
		["parent"] = nil,
		["name"] = "SaleStatus",
		["text"] = "Open to read.",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["parent"] = v_u_30,
		["color"] = v_u_4.text2,
		["size"] = UDim2.new(1, 0, 0, 0)
	})
	v_u_37.LayoutOrder = p_u_29.order()
	v_u_2.label({
		["parent"] = nil,
		["name"] = "SaleNote",
		["style"] = "small",
		["color"] = nil,
		["size"] = nil,
		["wrap"] = true,
		["autoY"] = true,
		["text"] = "The window starts by itself at the first live server boot and runs for the length set in Store.LIMITED_HOURS. Here you can only extend it, stop it or start it again; the button PRODUCT picks which sale the other buttons work on. A bundle that was paid just before the end is always delivered.",
		["parent"] = v_u_30,
		["color"] = v_u_4.muted,
		["size"] = UDim2.new(1, 0, 0, 0)
	}).LayoutOrder = p_u_29.order()
	local v_u_38 = false
	local v_u_39 = (-1 / 0)
	local v_u_40 = nil
	local v_u_41 = 0
	local v_u_42 = {}
	local function v_u_60(p43) -- name: paint
		-- upvalues: (copy) v_u_34, (ref) v_u_5, (ref) v_u_4, (ref) v_u_2, (ref) v_u_33, (ref) v_u_6
		for _, v44 in v_u_34:GetChildren() do
			if not v44:IsA("GuiObject") then
				continue
			end
			v44:Destroy()
		end
		for v45, v46 in v_u_5.lines(p43) do
			local v47
			if v46.kind == "ok" then
				v47 = v_u_4.success
			elseif v46.kind == "warn" then
				v47 = v_u_4.danger
			elseif v46.kind == "muted" then
				v47 = v_u_4.muted
			else
				v47 = v_u_4.text2
			end
			v_u_2.label({
				["parent"] = nil,
				["name"] = nil,
				["text"] = nil,
				["style"] = "monoS",
				["color"] = nil,
				["size"] = nil,
				["wrap"] = true,
				["autoY"] = true,
				["parent"] = v_u_34,
				["name"] = v46.name,
				["text"] = v46.text,
				["color"] = v47,
				["size"] = UDim2.new(1, 0, 0, 0)
			}).LayoutOrder = v45
		end
		local v48
		if type(p43) == "table" then
			local v49 = p43.sales
			if type(v49) == "table" then
				v48 = p43.sales[v_u_5.PRODUCTS[v_u_33].id]
			else
				v48 = nil
			end
		else
			v48 = nil
		end
		if type(v48) == "table" then
			local v50 = v_u_6
			local v51 = v_u_5.PRODUCTS[v_u_33].id
			local v52 = v48.state
			local v53 = tostring(v52)
			local v54 = v48.left
			local v55 = tonumber(v54) or 0
			local v56 = math.floor(v55)
			local v57 = p43.v
			local v58 = tostring(v57)
			local v59 = p43.good == true
			v50:SetAttribute("FilmSale", ("%s=%s|%d|v%s|%s"):format(v51, v53, v56, v58, (tostring(v59))))
		end
	end
	local function v_u_70(p61, p62) -- name: send
		-- upvalues: (ref) v_u_38, (copy) v_u_31, (ref) v_u_2, (copy) v_u_37, (ref) v_u_4, (ref) v_u_5, (ref) v_u_33, (ref) v_u_32, (ref) v_u_39, (copy) v_u_60
		if not v_u_38 and v_u_31 then
			local v63 = v_u_31.call
			if type(v63) == "function" then
				v_u_38 = true
				v_u_2.setText(v_u_37, "Working ...")
				v_u_37.TextColor3 = v_u_4.text2
				v_u_31.call("store.limited", {
					["cmd"] = p61,
					["product"] = v_u_5.PRODUCTS[v_u_33].id,
					["hours"] = p62
				}, function(p64)
					-- upvalues: (ref) v_u_38, (ref) v_u_32, (ref) v_u_39, (ref) v_u_60, (ref) v_u_2, (ref) v_u_37, (ref) v_u_4
					v_u_38 = false
					if v_u_32 then
						v_u_39 = os.clock()
						if type(p64) == "table" then
							if p64.data then
								v_u_60(p64.data)
							end
							local v65 = p64.msg or (p64.ok and "Done." or "Refused.")
							local v66 = tostring(v65)
							local v67 = p64.ok ~= true
							v_u_2.setText(v_u_37, v66)
							local v68 = v_u_37
							local v69
							if v67 then
								v69 = v_u_4.danger
							else
								v69 = v_u_4.text2
							end
							v68.TextColor3 = v69
						else
							v_u_2.setText(v_u_37, "The server did not answer.")
							v_u_37.TextColor3 = v_u_4.danger
						end
					else
						return
					end
				end)
				return
			end
		end
	end
	local function v_u_80(p_u_71, p72, p_u_73, p_u_74) -- name: guarded
		-- upvalues: (ref) v_u_40, (ref) v_u_41, (copy) v_u_70, (ref) v_u_2, (copy) v_u_37, (ref) v_u_4, (ref) v_u_32
		local v75 = os.clock()
		if v_u_40 == p_u_71 and v75 - v_u_41 <= 6 then
			v_u_40 = nil
			if p_u_74 and p_u_74.setText then
				p_u_74.setText(p_u_73)
			end
			v_u_70(p_u_71, p72)
		else
			v_u_40 = p_u_71
			v_u_41 = v75
			local v76, v77 = ("Press %s again within %d seconds to confirm."):format(p_u_73, 6)
			v_u_2.setText(v_u_37, v76)
			local v78 = v_u_37
			local v79
			if v77 then
				v79 = v_u_4.danger
			else
				v79 = v_u_4.text2
			end
			v78.TextColor3 = v79
			if p_u_74 and p_u_74.setText then
				p_u_74.setText("Confirm")
			end
			task.delay(6, function()
				-- upvalues: (ref) v_u_32, (ref) v_u_40, (copy) p_u_71, (ref) v_u_41, (copy) p_u_74, (copy) p_u_73
				if v_u_32 and (v_u_40 == p_u_71 and os.clock() - v_u_41 >= 5.9) then
					v_u_40 = nil
					if p_u_74 and p_u_74.setText then
						p_u_74.setText(p_u_73)
					end
				end
			end)
		end
	end
	local function v91(p81, p82, p83, p_u_84, p85) -- name: add
		-- upvalues: (ref) v_u_2, (copy) v_u_36, (copy) v_u_42
		local v_u_86 = {}
		local v87 = {
			["parent"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["height"] = 32,
			["width"] = 120,
			["maxTextWidth"] = 108,
			["onClick"] = nil,
			["parent"] = p85 or v_u_36,
			["text"] = p82,
			["kind"] = p83,
			["onClick"] = function() -- name: onClick
				-- upvalues: (copy) p_u_84, (copy) v_u_86
				p_u_84(v_u_86)
			end
		}
		local v88, v_u_89 = v_u_2.button(v87)
		v88.Name = p81
		v_u_86.btn = v88
		function v_u_86.setText(p90)
			-- upvalues: (copy) v_u_89, (ref) v_u_2
			if v_u_89 and v_u_89.label then
				v_u_2.setText(v_u_89.label, p90)
			end
		end
		v_u_42[p81] = v_u_86
		return v_u_86
	end
	v91("SaleProduct", v_u_5.PRODUCTS[v_u_33].short, "ghost", function(p92)
		-- upvalues: (ref) v_u_40, (copy) v_u_42, (ref) v_u_33, (ref) v_u_5, (ref) v_u_2, (copy) v_u_37, (ref) v_u_4, (copy) v_u_70
		v_u_40 = nil
		for _, v93 in { "SaleStop", "SaleRestart" } do
			local v94 = v_u_42[v93]
			if not (v94 and v94.setText) then
				continue
			end
			v94.setText(v93 == "SaleStop" and "Stop sale" or "Restart")
		end
		v_u_33 = v_u_33 % #v_u_5.PRODUCTS + 1
		p92.setText(v_u_5.PRODUCTS[v_u_33].short)
		local v95 = "The buttons now work on: " .. v_u_5.PRODUCTS[v_u_33].title
		v_u_2.setText(v_u_37, v95)
		v_u_37.TextColor3 = v_u_4.text2
		v_u_70("status", nil)
	end, v35)
	v91("SaleRefresh", "Refresh", "secondary", function()
		-- upvalues: (copy) v_u_70
		v_u_70("status", nil)
	end)
	v91("SaleExtend", "Extend 24 h", "ghost", function()
		-- upvalues: (copy) v_u_70
		v_u_70("extend", 24)
	end)
	v91("SaleStop", "Stop sale", "ghost", function(p96)
		-- upvalues: (copy) v_u_80
		v_u_80("stop", nil, "Stop sale", p96)
	end)
	v91("SaleRestart", "Restart", "ghost", function(p97)
		-- upvalues: (copy) v_u_80
		v_u_80("restart", nil, "Restart", p97)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_32, (copy) p_u_29, (copy) v_u_30, (ref) v_u_39, (copy) v_u_70
		local v98 = false
		while v_u_32 do
			local v99 = p_u_29.gui.Enabled
			if v99 then
				v99 = v_u_30.Visible
			end
			if v99 and (not v98 or os.clock() - v_u_39 >= 10) then
				v_u_39 = os.clock()
				v_u_70("status", nil)
			end
			task.wait(0.5)
			v98 = v99
		end
	end)
	return {
		["refresh"] = function() -- name: refresh
			-- upvalues: (copy) v_u_70
			v_u_70("status", nil)
		end
	}
end
return v_u_5