-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / GroupStarterLayout

local v_u_99 = {
	["MARGIN"] = 12,
	["MAX_CARD_W"] = 760,
	["PAD"] = 16,
	["GAP"] = 10,
	["TITLE_SIZE"] = 22,
	["BODY_SIZE"] = 15,
	["NAME_SIZE"] = 14,
	["COUNT_SIZE"] = 14,
	["STATUS_SIZE"] = 15,
	["ICON"] = 76,
	["TILE_W"] = 124,
	["NAME_LINES"] = 2,
	["COUNT_W"] = 44,
	["COUNT_H"] = 20,
	["BTN_MAX_W"] = 360,
	["TOUCH_MIN_REAL"] = 44,
	["CHAR"] = 0.62,
	["STATUS_MIN_LINES"] = 2,
	["LINE_EXTRA_TITLE"] = 6,
	["LINE_EXTRA"] = 5,
	["textW"] = function(p1, p2) -- name: textW
		-- upvalues: (copy) v_u_99
		local v3 = (utf8.len(p1) or #p1) * p2 * v_u_99.CHAR + 2
		return math.ceil(v3)
	end,
	["lines"] = function(p4, p5, p6) -- name: lines
		-- upvalues: (copy) v_u_99
		if p4 == "" then
			return 1
		end
		local v7 = v_u_99.textW(p4, p5) / math.max(1, p6)
		local v8 = math.ceil(v7)
		return math.max(1, v8)
	end,
	["layout"] = function(p9, p10, p11) -- name: layout
		-- upvalues: (copy) v_u_99
		local v12 = v_u_99
		local v13 = type(p11) ~= "table" and {} or p11
		local v14 = v13.count
		local v15
		if type(v14) == "number" and v13.count >= 1 then
			local v16 = v13.count
			v15 = math.floor(v16)
		else
			v15 = 4
		end
		local v17 = v13.scale
		local v18 = (type(v17) ~= "number" or v13.scale <= 0) and 1 or v13.scale
		local v19 = v13.texts
		local v20 = type(v19) ~= "table" and {} or v13.texts
		local v21 = v12.MAX_CARD_W
		local v22 = p9 - 2 * v12.MARGIN
		local v23 = math.min(v21, v22)
		local v24 = math.max(120, v23)
		local v25 = (p9 - v24) / 2
		local v26 = math.floor(v25)
		local v27 = v24 - 2 * v12.PAD
		local v28 = v12.PAD
		local v29 = v12.PAD
		local v30 = v12.lines
		local v31 = v20.title or ""
		local v32 = {
			["x"] = v29,
			["y"] = v28,
			["w"] = v27,
			["h"] = v30(tostring(v31), v12.TITLE_SIZE, v27) * (v12.TITLE_SIZE + v12.LINE_EXTRA_TITLE)
		}
		local v33 = v28 + (v32.h + v12.GAP)
		local v34 = v12.PAD
		local v35 = v12.lines
		local v36 = v20.body or ""
		local v37 = {
			["x"] = v34,
			["y"] = v33,
			["w"] = v27,
			["h"] = v35(tostring(v36), v12.BODY_SIZE, v27) * (v12.BODY_SIZE + v12.LINE_EXTRA)
		}
		local v38 = v33 + (v37.h + v12.GAP + 4)
		local v39 = v12.ICON + 4 + v12.NAME_LINES * (v12.NAME_SIZE + 2)
		local v40 = v12.TILE_W
		local v41
		if v27 < v15 * v40 + (v15 - 1) * v12.GAP then
			local v42 = (v27 + v12.GAP) / (v12.TILE_W + v12.GAP)
			local v43 = math.floor(v42)
			local v44 = v15 / math.max(2, v43)
			local v45 = v15 / math.ceil(v44)
			local v46 = math.ceil(v45)
			local v47 = math.min(v15, v46)
			v41 = math.max(1, v47)
			local v48 = v12.TILE_W
			local v49 = (v27 - (v41 - 1) * v12.GAP) / v41
			local v50 = math.floor(v49)
			local v51 = math.min(v48, v50)
			v40 = math.max(1, v51)
		else
			v41 = v15
		end
		local v52 = v15 / v41
		local v53 = math.ceil(v52)
		local v54 = v41 * v40 + (v41 - 1) * v12.GAP
		local v55 = v12.PAD
		local v56 = (v27 - v54) / 2
		local v57 = v55 + math.floor(v56)
		local v58 = {}
		for v59 = 1, v15 do
			local v60 = (v59 - 1) % v41
			local v61 = (v59 - 1) / v41
			local v62 = math.floor(v61)
			local v63 = v57 + v60 * (v40 + v12.GAP)
			local v64 = v38 + v62 * (v39 + v12.GAP)
			local v65 = v12.ICON
			local v66 = math.min(v65, v40)
			local v67 = (v40 - v66) / 2
			local v68 = {
				["x"] = v63 + math.floor(v67),
				["y"] = v64,
				["w"] = v66,
				["h"] = v66
			}
			local v69 = v12.COUNT_W
			local v70 = math.min(v69, v66)
			local v71 = {
				["box"] = {
					["x"] = v63,
					["y"] = v64,
					["w"] = v40,
					["h"] = v39
				},
				["icon"] = v68,
				["count"] = {
					["x"] = v68.x + v68.w - v70,
					["y"] = v68.y + v68.h - v12.COUNT_H,
					["w"] = v70,
					["h"] = v12.COUNT_H
				},
				["name"] = {
					["x"] = v63,
					["y"] = v64 + v66 + 4,
					["w"] = v40,
					["h"] = v12.NAME_LINES * (v12.NAME_SIZE + 2)
				}
			}
			table.insert(v58, v71)
		end
		local v72 = v38 + (v53 * v39 + (v53 - 1) * v12.GAP + v12.GAP + 6)
		local v73 = v13.btnH
		local v74 = type(v73) ~= "number" and 44 or v13.btnH
		if v13.touch == true then
			local v75 = v12.TOUCH_MIN_REAL / v18
			local v76 = math.ceil(v75)
			v74 = math.max(v74, v76)
		end
		local v77 = v12.BTN_MAX_W
		local v78 = math.min(v27, v77)
		local v79 = v12.PAD
		local v80 = (v27 - v78) / 2
		local v81 = {
			["x"] = v79 + math.floor(v80),
			["y"] = v72,
			["w"] = v78,
			["h"] = v74
		}
		local v82 = v72 + (v74 + v12.GAP)
		local v83 = v12.STATUS_MIN_LINES
		local v84 = v12.lines
		local v85 = v20.status or ""
		local v86 = tostring(v85)
		local v87 = v12.STATUS_SIZE
		local v88 = math.max(v83, v84(v86, v87, v27))
		local v89 = {
			["x"] = v12.PAD,
			["y"] = v82,
			["w"] = v27,
			["h"] = v88 * (v12.STATUS_SIZE + v12.LINE_EXTRA)
		}
		local v90 = v82 + (v89.h + v12.PAD)
		local v91 = {}
		for _, v92 in v58 do
			local v93 = {}
			local v94 = v92.box
			v93.box = {
				["x"] = v94.x + v26,
				["y"] = v94.y + v12.MARGIN,
				["w"] = v94.w,
				["h"] = v94.h
			}
			local v95 = v92.icon
			v93.icon = {
				["x"] = v95.x + v26,
				["y"] = v95.y + v12.MARGIN,
				["w"] = v95.w,
				["h"] = v95.h
			}
			local v96 = v92.count
			v93.count = {
				["x"] = v96.x + v26,
				["y"] = v96.y + v12.MARGIN,
				["w"] = v96.w,
				["h"] = v96.h
			}
			local v97 = v92.name
			v93.name = {
				["x"] = v97.x + v26,
				["y"] = v97.y + v12.MARGIN,
				["w"] = v97.w,
				["h"] = v97.h
			}
			table.insert(v91, v93)
		end
		local v98 = v90 + 2 * v12.MARGIN
		return {
			["card"] = {
				["x"] = v26,
				["y"] = v12.MARGIN,
				["w"] = v24,
				["h"] = v90
			},
			["title"] = {
				["x"] = v32.x + v26,
				["y"] = v32.y + v12.MARGIN,
				["w"] = v32.w,
				["h"] = v32.h
			},
			["body"] = {
				["x"] = v37.x + v26,
				["y"] = v37.y + v12.MARGIN,
				["w"] = v37.w,
				["h"] = v37.h
			},
			["tiles"] = v91,
			["button"] = {
				["x"] = v81.x + v26,
				["y"] = v81.y + v12.MARGIN,
				["w"] = v81.w,
				["h"] = v81.h
			},
			["status"] = {
				["x"] = v89.x + v26,
				["y"] = v89.y + v12.MARGIN,
				["w"] = v89.w,
				["h"] = v89.h
			},
			["cols"] = v41,
			["rows"] = v53,
			["content"] = {
				["w"] = p9,
				["h"] = math.max(p10, v98)
			},
			["scroll"] = p10 < v98
		}
	end
}
return v_u_99