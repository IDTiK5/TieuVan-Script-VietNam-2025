-- Decompiled with Delta | Players / acctvmod / PlayerScripts / HushClient / Lib / MailStub

local v1 = {
	["PRESETS"] = {
		"deliveries",
		"mixed",
		"expiry",
		"full",
		"empty",
		"cargo",
		"cargowarn"
	}
}
local function v_u_6(p2) -- name: recount
	local v3 = 0
	local v4 = 0
	for _, v5 in p2.entries do
		if v5.kind ~= "delivery" then
			continue
		end
		if v5.src == "bm" then
			v4 = v4 + 1
		else
			v3 = v3 + 1
		end
	end
	p2.deliveries = {
		["waiting"] = nil,
		["bm"] = nil,
		["store"] = nil,
		["bmMax"] = 10,
		["bmDays"] = 14,
		["waiting"] = v4 + v3,
		["bm"] = v4,
		["store"] = v3
	}
	p2.count = #p2.entries
end
local function v_u_45(p7, p8) -- name: cargoPackage
	local v9 = {}
	local v10 = {
		["id"] = "rifle_akm",
		["n"] = 1,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_11 = "rifle_akm"
	local v13, v14 = pcall(function()
		-- upvalues: (copy) v_u_11
		local v12 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_11)
		if v12 then
			return v12.name
		else
			return nil
		end
	end)
	v10.name = (not v13 or type(v14) ~= "string") and "rifle_akm" or v14
	local v15 = {
		["id"] = "ammo_556_3",
		["n"] = 90,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_16 = "ammo_556_3"
	local v18, v19 = pcall(function()
		-- upvalues: (copy) v_u_16
		local v17 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_16)
		if v17 then
			return v17.name
		else
			return nil
		end
	end)
	v15.name = (not v18 or type(v19) ~= "string") and "ammo_556_3" or v19
	local v20 = {
		["id"] = "med_medkit",
		["n"] = 2,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_21 = "med_medkit"
	local v23, v24 = pcall(function()
		-- upvalues: (copy) v_u_21
		local v22 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_21)
		if v22 then
			return v22.name
		else
			return nil
		end
	end)
	v20.name = (not v23 or type(v24) ~= "string") and "med_medkit" or v24
	local v25 = {
		["id"] = "med_bandage",
		["n"] = 4,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_26 = "med_bandage"
	local v28, v29 = pcall(function()
		-- upvalues: (copy) v_u_26
		local v27 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_26)
		if v27 then
			return v27.name
		else
			return nil
		end
	end)
	v25.name = (not v28 or type(v29) ~= "string") and "med_bandage" or v29
	local v30 = {
		["id"] = "food_mre",
		["n"] = 2,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_31 = "food_mre"
	local v33, v34 = pcall(function()
		-- upvalues: (copy) v_u_31
		local v32 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_31)
		if v32 then
			return v32.name
		else
			return nil
		end
	end)
	v30.name = (not v33 or type(v34) ~= "string") and "food_mre" or v34
	local v35 = {
		["id"] = "food_water",
		["n"] = 2,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_36 = "food_water"
	local v38, v39 = pcall(function()
		-- upvalues: (copy) v_u_36
		local v37 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_36)
		if v37 then
			return v37.name
		else
			return nil
		end
	end)
	v35.name = (not v38 or type(v39) ~= "string") and "food_water" or v39
	local v40 = {
		["id"] = "helmet_military",
		["n"] = 1,
		["dur"] = 1,
		["name"] = nil
	}
	local v_u_41 = "helmet_military"
	local v43, v44 = pcall(function()
		-- upvalues: (copy) v_u_41
		local v42 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_41)
		if v42 then
			return v42.name
		else
			return nil
		end
	end)
	v40.name = (not v43 or type(v44) ~= "string") and "helmet_military" or v44
	__set_list(v9, 1, {v10, v15, v20, v25, v30, v35, v40})
	return {
		["id"] = "cstub1",
		["kind"] = "delivery",
		["src"] = "lift",
		["tag"] = "CARGO",
		["title"] = "Cargo package",
		["items"] = nil,
		["at"] = nil,
		["exp"] = nil,
		["expLeft"] = nil,
		["warn"] = nil,
		["count"] = nil,
		["stubFull"] = true,
		["items"] = v9,
		["at"] = p7 - 3600,
		["exp"] = p7 + p8,
		["expLeft"] = p8,
		["warn"] = p8 <= 259200,
		["count"] = #v9
	}
end
function v1.build(p46, p47, p48) -- name: build
	-- upvalues: (copy) v_u_45, (copy) v_u_6
	local v49 = math.floor(p47)
	local v50
	if p46 == "deliveries" or (p46 == "mixed" or (p46 == "expiry" or p46 == "full")) then
		local v_u_51 = "ammo_556_3"
		local v53, v54 = pcall(function()
			-- upvalues: (copy) v_u_51
			local v52 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_51)
			if v52 then
				return v52.name
			else
				return nil
			end
		end)
		local v55 = ((not v53 or type(v54) ~= "string") and "ammo_556_3" or v54) .. " x 60"
		local v56 = {}
		local v57 = {
			["id"] = "ammo_556_3",
			["n"] = 60,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_58 = "ammo_556_3"
		local v60, v61 = pcall(function()
			-- upvalues: (copy) v_u_58
			local v59 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_58)
			if v59 then
				return v59.name
			else
				return nil
			end
		end)
		v57.name = (not v60 or type(v61) ~= "string") and "ammo_556_3" or v61
		__set_list(v56, 1, {v57})
		local v62 = v49 - 7200
		local v63 = {
			["id"] = "dstub1",
			["kind"] = "delivery",
			["src"] = "bm",
			["title"] = nil,
			["items"] = nil,
			["at"] = nil,
			["ready"] = true,
			["readyAt"] = nil,
			["left"] = 0,
			["title"] = v55,
			["items"] = v56,
			["at"] = v62,
			["readyAt"] = v62,
			["exp"] = (v49 or v62) + 1036800,
			["expLeft"] = 1036800
		}
		local v_u_64 = "vest_platecarrier"
		local v66, v67 = pcall(function()
			-- upvalues: (copy) v_u_64
			local v65 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_64)
			if v65 then
				return v65.name
			else
				return nil
			end
		end)
		local v68 = (not v66 or type(v67) ~= "string") and "vest_platecarrier" or v67
		local v69 = {}
		local v70 = {
			["id"] = "vest_platecarrier",
			["n"] = 1,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_71 = "vest_platecarrier"
		local v73, v74 = pcall(function()
			-- upvalues: (copy) v_u_71
			local v72 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_71)
			if v72 then
				return v72.name
			else
				return nil
			end
		end)
		v70.name = (not v73 or type(v74) ~= "string") and "vest_platecarrier" or v74
		__set_list(v69, 1, {v70})
		local v75 = v49 - 950400
		local v76 = {
			["id"] = "dstub2",
			["kind"] = "delivery",
			["src"] = "bm",
			["title"] = nil,
			["items"] = nil,
			["at"] = nil,
			["ready"] = true,
			["readyAt"] = nil,
			["left"] = 0,
			["title"] = v68,
			["items"] = v69,
			["at"] = v75,
			["readyAt"] = v75,
			["exp"] = (v49 or v75) + 187200,
			["expLeft"] = 187200
		}
		local v_u_77 = "med_medkit"
		local v79, v80 = pcall(function()
			-- upvalues: (copy) v_u_77
			local v78 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_77)
			if v78 then
				return v78.name
			else
				return nil
			end
		end)
		local v81 = (not v79 or type(v80) ~= "string") and "med_medkit" or v80
		local v82 = {}
		local v83 = {
			["id"] = "med_medkit",
			["n"] = 1,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_84 = "med_medkit"
		local v86, v87 = pcall(function()
			-- upvalues: (copy) v_u_84
			local v85 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_84)
			if v85 then
				return v85.name
			else
				return nil
			end
		end)
		v83.name = (not v86 or type(v87) ~= "string") and "med_medkit" or v87
		__set_list(v82, 1, {v83})
		local v88 = v49 - 1123200 - 68400
		local v89 = {
			["id"] = "dstub3",
			["kind"] = "delivery",
			["src"] = "bm",
			["title"] = nil,
			["items"] = nil,
			["at"] = nil,
			["ready"] = true,
			["readyAt"] = nil,
			["left"] = 0,
			["title"] = v81,
			["items"] = v82,
			["at"] = v88,
			["readyAt"] = v88,
			["exp"] = (v49 or v88) + 18000,
			["expLeft"] = 18000
		}
		local v90 = {}
		local v91 = {
			["id"] = "rifle_akm",
			["n"] = 1,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_92 = "rifle_akm"
		local v94, v95 = pcall(function()
			-- upvalues: (copy) v_u_92
			local v93 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_92)
			if v93 then
				return v93.name
			else
				return nil
			end
		end)
		v91.name = (not v94 or type(v95) ~= "string") and "rifle_akm" or v95
		local v96 = {
			["id"] = "ammo_556_3",
			["n"] = 120,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_97 = "ammo_556_3"
		local v99, v100 = pcall(function()
			-- upvalues: (copy) v_u_97
			local v98 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_97)
			if v98 then
				return v98.name
			else
				return nil
			end
		end)
		v96.name = (not v99 or type(v100) ~= "string") and "ammo_556_3" or v100
		local v101 = {
			["id"] = "med_medkit",
			["n"] = 2,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_102 = "med_medkit"
		local v104, v105 = pcall(function()
			-- upvalues: (copy) v_u_102
			local v103 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_102)
			if v103 then
				return v103.name
			else
				return nil
			end
		end)
		v101.name = (not v104 or type(v105) ~= "string") and "med_medkit" or v105
		local v106 = {
			["id"] = "med_bandage",
			["n"] = 6,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_107 = "med_bandage"
		local v109, v110 = pcall(function()
			-- upvalues: (copy) v_u_107
			local v108 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_107)
			if v108 then
				return v108.name
			else
				return nil
			end
		end)
		v106.name = (not v109 or type(v110) ~= "string") and "med_bandage" or v110
		local v111 = {
			["id"] = "med_painkillers",
			["n"] = 4,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_112 = "med_painkillers"
		local v114, v115 = pcall(function()
			-- upvalues: (copy) v_u_112
			local v113 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_112)
			if v113 then
				return v113.name
			else
				return nil
			end
		end)
		v111.name = (not v114 or type(v115) ~= "string") and "med_painkillers" or v115
		local v116 = {
			["id"] = "food_mre",
			["n"] = 3,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_117 = "food_mre"
		local v119, v120 = pcall(function()
			-- upvalues: (copy) v_u_117
			local v118 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_117)
			if v118 then
				return v118.name
			else
				return nil
			end
		end)
		v116.name = (not v119 or type(v120) ~= "string") and "food_mre" or v120
		local v121 = {
			["id"] = "food_water",
			["n"] = 3,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_122 = "food_water"
		local v124, v125 = pcall(function()
			-- upvalues: (copy) v_u_122
			local v123 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_122)
			if v123 then
				return v123.name
			else
				return nil
			end
		end)
		v121.name = (not v124 or type(v125) ~= "string") and "food_water" or v125
		local v126 = {
			["id"] = "helmet_military",
			["n"] = 1,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_127 = "helmet_military"
		local v129, v130 = pcall(function()
			-- upvalues: (copy) v_u_127
			local v128 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_127)
			if v128 then
				return v128.name
			else
				return nil
			end
		end)
		v126.name = (not v129 or type(v130) ~= "string") and "helmet_military" or v130
		local v131 = {
			["id"] = "bag_tactical",
			["n"] = 1,
			["dur"] = 1,
			["name"] = nil
		}
		local v_u_132 = "bag_tactical"
		local v134, v135 = pcall(function()
			-- upvalues: (copy) v_u_132
			local v133 = require(game:GetService("ReplicatedStorage"):WaitForChild("Hush"):WaitForChild("Shared"):WaitForChild("Items")).get(v_u_132)
			if v133 then
				return v133.name
			else
				return nil
			end
		end)
		v131.name = (not v134 or type(v135) ~= "string") and "bag_tactical" or v135
		__set_list(v90, 1, {v91, v96, v101, v106, v111, v116, v121, v126, v131})
		local v136 = v49 - 10800
		local v137 = {
			["id"] = "dstub4",
			["kind"] = "delivery",
			["src"] = "store",
			["title"] = "Survivor Starter Pack",
			["items"] = nil,
			["at"] = nil,
			["ready"] = true,
			["readyAt"] = nil,
			["left"] = 0,
			["items"] = v90,
			["at"] = v136,
			["readyAt"] = v136
		}
		v89.stubFull = true
		v137.stubStage = 0
		if p46 == "full" then
			v63.stubFull = true
			v76.stubFull = true
			v137.stubStage = 1
			v50 = {
				v63,
				v76,
				v89,
				v137
			}
		else
			v50 = {
				v63,
				v76,
				v89,
				v137
			}
		end
	else
		v50 = {}
	end
	if p46 == "mixed" and p48 then
		for _, v138 in p48 do
			table.insert(v50, v138)
		end
	end
	local v139 = {
		["entries"] = nil,
		["count"] = nil,
		["capacity"] = 20,
		["serverTime"] = nil,
		["rule"] = "An insured item comes back if you died and nobody carried it out.",
		["tips"] = nil,
		["switch"] = nil,
		["expiredNote"] = nil,
		["stubDeliveries"] = true,
		["entries"] = v50,
		["count"] = #v50,
		["serverTime"] = v49,
		["tips"] = {
			["mailStore"] = false,
			["mailBm"] = false
		},
		["switch"] = {
			["on"] = true
		},
		["expiredNote"] = p46 == "expiry" and 2 or nil
	}
	if p46 == "empty" then
		v139.expiredNote = nil
	end
	if p46 == "cargo" then
		v139.cargo = v_u_45(v49, 601200)
	elseif p46 == "cargowarn" then
		v139.cargo = v_u_45(v49, 187200)
	end
	v_u_6(v139)
	return v139
end
function v1.fresh(p140, p141) -- name: fresh
	-- upvalues: (copy) v_u_6
	if type(p140) == "table" then
		local v142 = p140.entries
		if type(v142) == "table" then
			p140.serverTime = math.floor(p141)
			local v143 = p140.cargo
			if type(v143) == "table" then
				local v144 = v143.exp
				if type(v144) == "number" then
					if v143.exp <= p141 then
						p140.cargo = nil
						p140.cargoExpired = true
					else
						v143.expLeft = v143.exp - p141
						v143.warn = v143.expLeft <= 259200
					end
				end
			end
			local v145 = 0
			for v146 = #p140.entries, 1, -1 do
				local v147 = p140.entries[v146]
				if v147.kind ~= "delivery" then
					continue
				end
				local v148 = v147.exp
				if type(v148) ~= "number" or v147.exp <= 0 then
					continue
				end
				if v147.exp <= p141 then
					table.remove(p140.entries, v146)
					v145 = v145 + 1
				else
					v147.expLeft = v147.exp - p141
				end
			end
			if v145 > 0 then
				p140.expiredNote = (p140.expiredNote or 0) + v145
				v_u_6(p140)
			end
			return
		end
	end
end
local function v_u_156(p149, p150, p151) -- name: attempt
	local v152 = #p151.items
	if p151.stubFull then
		return 0, v152, true
	end
	if p151.stubStage ~= nil then
		local v153 = p151.stubStage
		p151.stubStage = v153 + 1
		if v153 == 0 then
			local v154 = v152 - 1
			local v155 = math.min(5, v154)
			for _ = 1, v155 do
				table.remove(p151.items, 1)
			end
			return v155, #p151.items, true
		end
		if v153 == 1 then
			return 0, v152, true
		end
	end
	table.remove(p149.entries, p150)
	return v152, 0, false
end
function v1.claim(p157, p158, p159) -- name: claim
	-- upvalues: (copy) v_u_156, (copy) v_u_6
	if type(p157) == "table" then
		local v160 = p157.entries
		if type(v160) == "table" then
			local v161 = p157.cargo
			if type(v161) == "table" and p157.cargo.id == p158 then
				local v162 = #p157.cargo.items
				local v163 = p157.cargo.title
				local v164 = p157.cargo
				local v165, v166
				if type(v164) == "table" then
					v165 = #v164.items
					if v164.stubFull then
						v164.stubFull = false
						v166 = 0
					else
						p157.cargo = nil
						v166 = v165
						v165 = 0
					end
				else
					v166 = 0
					v165 = 0
				end
				return v166 == 0 and {
					["op"] = "mailClaim",
					["ok"] = false,
					["msg"] = "Your stash is full. Make room first.",
					["data"] = nil,
					["data"] = {
						["moved"] = 0,
						["left"] = nil,
						["full"] = true,
						["cargo"] = true,
						["left"] = v165
					}
				} or {
					["op"] = "mailClaim",
					["ok"] = true,
					["msg"] = nil,
					["data"] = nil,
					["msg"] = ("%s is in your stash"):format(v163),
					["data"] = {
						["moved"] = nil,
						["left"] = 0,
						["full"] = false,
						["cargo"] = true,
						["total"] = nil,
						["moved"] = v166,
						["total"] = v162
					}
				}
			end
			if p158 ~= "all" then
				for v167, v168 in p157.entries do
					if v168.id ~= p158 or v168.kind ~= "delivery" then
						continue
					end
					local v169 = #v168.items
					local v170 = v168.title
					local v171, v172, v173 = v_u_156(p157, v167, v168)
					v_u_6(p157)
					return v171 == 0 and {
						["op"] = "mailClaim",
						["ok"] = false,
						["msg"] = "Your stash is full. Make room first.",
						["data"] = nil,
						["data"] = {
							["moved"] = 0,
							["left"] = nil,
							["full"] = true,
							["left"] = v172
						}
					} or (v172 > 0 and {
						["op"] = "mailClaim",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = ("%d of %d moved. Make room for the rest."):format(v171, v169),
						["data"] = {
							["moved"] = v171,
							["left"] = v172,
							["full"] = v173
						}
					} or {
						["op"] = "mailClaim",
						["ok"] = true,
						["msg"] = nil,
						["data"] = nil,
						["msg"] = ("%s is in your stash"):format(v170),
						["data"] = {
							["moved"] = nil,
							["left"] = 0,
							["full"] = false,
							["moved"] = v171
						}
					})
				end
				return nil
			end
			local v174 = {}
			for _, v175 in p157.entries do
				if v175.kind ~= "delivery" then
					continue
				end
				table.insert(v174, v175)
			end
			local v176 = 0
			local v177 = 0
			local v178 = p157.cargo
			local v179
			if type(v178) == "table" then
				local v180 = p157.cargo
				local v181
				if type(v180) == "table" then
					v181 = #v180.items
					if v180.stubFull then
						v180.stubFull = false
						v181 = 0
						v179 = true
					else
						p157.cargo = nil
						v179 = false
					end
				else
					v181 = 0
					v179 = false
				end
				v176 = v176 + v181
			else
				v179 = false
			end
			for _, v182 in v174 do
				if not v179 then
					local v183 = table.find(p157.entries, v182)
					if not v183 then
						continue
					end
					local v184, v185, v186 = v_u_156(p157, v183, v182)
					if v184 > 0 and v185 == 0 then
						v176 = v176 + 1
					elseif v184 > 0 then
						v176 = v176 + 1
						v177 = v177 + 1
					end
					if not v186 then
						continue
					end
					v179 = true
				end
			end
			for v187 = #p157.entries, 1, -1 do
				local v188 = p157.entries[v187]
				if v188.kind == "delivery" then
					continue
				end
				local v189 = v188.readyAt
				if type(v189) ~= "number" or (v188.readyAt > p159 or v188.id == "stub3") then
					continue
				end
				table.remove(p157.entries, v187)
				v176 = v176 + 1
			end
			v_u_6(p157)
			if v176 == 0 then
				return {
					["op"] = "mailClaim",
					["ok"] = false,
					["msg"] = "Your stash is full. Make room first.",
					["data"] = nil,
					["data"] = {
						["full"] = true
					}
				}
			end
			local v190 = v176 == 1 and "1 item is in your stash" or ("%d items are in your stash"):format(v176)
			if v179 then
				v190 = v190 .. ". Your stash is full, the rest stays in your mail."
			end
			return {
				["op"] = "mailClaim",
				["ok"] = true,
				["msg"] = nil,
				["data"] = nil,
				["msg"] = v190,
				["data"] = {
					["moved"] = v176,
					["left"] = v177,
					["full"] = v179
				}
			}
		end
	end
	return nil
end
return v1